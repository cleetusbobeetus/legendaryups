setblock 471 27 494 minecraft:terracotta
fill 471 27 495 471 27 498 minecraft:red_terracotta
setblock 471 27 499 minecraft:terracotta
fill 471 27 500 471 30 500 minecraft:red_terracotta
setblock 471 27 504 minecraft:terracotta
fill 472 27 464 472 30 464 minecraft:red_terracotta
fill 472 27 466 472 28 466 minecraft:red_terracotta
fill 472 27 476 472 27 477 minecraft:red_terracotta
setblock 472 27 478 minecraft:terracotta
fill 472 27 479 472 30 479 minecraft:red_terracotta
setblock 472 27 483 minecraft:terracotta
fill 472 27 484 472 30 484 minecraft:red_terracotta
setblock 472 27 488 minecraft:terracotta
fill 472 27 489 472 30 489 minecraft:red_terracotta
fill 472 27 491 472 28 491 minecraft:red_terracotta
setblock 472 27 503 minecraft:terracotta
fill 472 27 504 472 30 504 minecraft:red_terracotta
fill 473 27 478 473 28 478 minecraft:red_terracotta
setblock 473 27 482 minecraft:terracotta
fill 473 27 483 473 30 483 minecraft:red_terracotta
setblock 473 27 487 minecraft:terracotta
fill 473 27 488 473 30 488 minecraft:red_terracotta
setblock 473 27 503 minecraft:red_terracotta
fill 474 27 482 474 28 482 minecraft:red_terracotta
setblock 475 27 465 minecraft:terracotta
setblock 476 27 464 minecraft:terracotta
fill 476 27 465 476 30 465 minecraft:red_terracotta
setblock 476 27 504 minecraft:terracotta
fill 477 27 464 477 30 464 minecraft:red_terracotta
fill 477 27 504 477 29 504 minecraft:red_terracotta
setblock 481 27 464 minecraft:terracotta
fill 482 27 464 485 27 464 minecraft:red_terracotta
setblock 485 27 504 minecraft:red_terracotta
setblock 486 27 464 minecraft:terracotta
fill 486 27 465 486 30 465 minecraft:red_terracotta
setblock 486 27 504 minecraft:terracotta
fill 487 27 464 487 30 464 minecraft:red_terracotta
fill 487 27 504 487 30 504 minecraft:red_terracotta
fill 488 27 503 488 30 503 minecraft:red_terracotta
setblock 489 27 466 minecraft:terracotta
setblock 490 27 465 minecraft:terracotta
fill 490 27 466 490 30 466 minecraft:red_terracotta
setblock 491 27 464 minecraft:terracotta
fill 491 27 465 491 30 465 minecraft:red_terracotta
fill 491 27 502 491 28 502 minecraft:red_terracotta
setblock 491 27 504 minecraft:terracotta
fill 492 27 464 492 30 464 minecraft:red_terracotta
setblock 492 27 503 minecraft:terracotta
fill 492 27 504 492 30 504 minecraft:red_terracotta
setblock 493 27 502 minecraft:terracotta
fill 493 27 503 493 30 503 minecraft:red_terracotta
setblock 494 27 466 minecraft:terracotta
fill 494 27 502 494 30 502 minecraft:red_terracotta
setblock 495 27 465 minecraft:terracotta
fill 495 27 466 495 30 466 minecraft:red_terracotta
setblock 496 27 464 minecraft:terracotta
fill 496 27 465 496 30 465 minecraft:red_terracotta
setblock 496 27 504 minecraft:terracotta
fill 497 27 464 497 30 464 minecraft:red_terracotta
setblock 497 27 503 minecraft:terracotta
fill 497 27 504 497 30 504 minecraft:red_terracotta
fill 498 27 503 501 27 503 minecraft:red_terracotta
setblock 501 27 464 minecraft:terracotta
setblock 501 27 504 minecraft:terracotta
fill 502 27 464 502 30 464 minecraft:red_terracotta
fill 502 27 504 502 30 504 minecraft:red_terracotta
setblock 506 27 504 minecraft:terracotta
fill 507 27 464 507 30 464 minecraft:red_terracotta
setblock 507 27 503 minecraft:terracotta
fill 507 27 504 507 30 504 minecraft:red_terracotta
fill 508 27 503 508 30 503 minecraft:red_terracotta
setblock 509 27 485 minecraft:red_terracotta
setblock 510 27 480 minecraft:terracotta
fill 510 27 481 510 30 481 minecraft:red_terracotta
setblock 510 27 485 minecraft:terracotta
fill 510 27 486 510 30 486 minecraft:red_terracotta
setblock 510 27 489 minecraft:red_terracotta
setblock 510 27 490 minecraft:terracotta
fill 510 27 491 510 29 492 minecraft:red_terracotta
setblock 510 27 500 minecraft:terracotta
fill 510 27 501 510 30 501 minecraft:red_terracotta
setblock 511 27 464 minecraft:terracotta
fill 511 27 465 511 30 465 minecraft:red_terracotta
fill 511 27 467 511 28 467 minecraft:red_terracotta
setblock 511 27 479 minecraft:terracotta
fill 511 27 480 511 30 480 minecraft:red_terracotta
setblock 511 27 484 minecraft:terracotta
fill 511 27 485 511 30 485 minecraft:red_terracotta
setblock 511 27 489 minecraft:terracotta
fill 511 27 490 511 30 490 minecraft:red_terracotta
setblock 511 27 494 minecraft:terracotta
fill 511 27 495 511 30 495 minecraft:red_terracotta
setblock 511 27 499 minecraft:terracotta
fill 511 27 500 511 30 500 minecraft:red_terracotta
setblock 511 27 504 minecraft:terracotta
fill 471 28 464 471 28 467 minecraft:red_terracotta
setblock 471 28 468 minecraft:terracotta
fill 471 28 469 471 31 469 minecraft:red_terracotta
setblock 471 28 473 minecraft:terracotta
fill 471 28 474 471 28 477 minecraft:red_terracotta
setblock 471 28 478 minecraft:terracotta
fill 471 28 479 471 31 479 minecraft:red_terracotta
setblock 471 28 483 minecraft:terracotta
fill 471 28 484 471 31 484 minecraft:red_terracotta
setblock 471 28 488 minecraft:terracotta
fill 471 28 489 471 31 489 minecraft:red_terracotta
setblock 471 28 493 minecraft:terracotta
fill 471 28 494 471 28 497 minecraft:red_terracotta
setblock 471 28 498 minecraft:terracotta
fill 471 28 499 471 31 499 minecraft:red_terracotta
setblock 471 28 503 minecraft:terracotta
fill 471 28 504 471 31 504 minecraft:red_terracotta
fill 472 28 465 473 28 465 minecraft:red_terracotta
setblock 472 28 467 minecraft:terracotta
fill 472 28 468 472 31 468 minecraft:red_terracotta
fill 472 28 475 472 28 476 minecraft:red_terracotta
setblock 472 28 477 minecraft:terracotta
fill 472 28 478 472 31 478 minecraft:red_terracotta
setblock 472 28 482 minecraft:terracotta
fill 472 28 483 472 31 483 minecraft:red_terracotta
setblock 472 28 487 minecraft:terracotta
fill 472 28 488 472 31 488 minecraft:red_terracotta
setblock 472 28 503 minecraft:red_terracotta
setblock 473 28 481 minecraft:terracotta
fill 473 28 482 473 31 482 minecraft:red_terracotta
setblock 473 28 486 minecraft:terracotta
fill 473 28 487 473 31 487 minecraft:red_terracotta
fill 473 28 489 473 29 489 minecraft:red_terracotta
setblock 474 28 465 minecraft:terracotta
setblock 474 28 485 minecraft:terracotta
setblock 475 28 464 minecraft:terracotta
fill 475 28 465 475 31 465 minecraft:red_terracotta
setblock 475 28 504 minecraft:terracotta
fill 476 28 464 476 31 464 minecraft:red_terracotta
fill 476 28 504 476 31 504 minecraft:red_terracotta
fill 477 28 465 477 29 465 minecraft:red_terracotta
setblock 480 28 464 minecraft:terracotta
fill 481 28 464 484 28 464 minecraft:red_terracotta
setblock 484 28 465 minecraft:terracotta
setblock 484 28 504 minecraft:red_terracotta
setblock 485 28 464 minecraft:terracotta
fill 485 28 465 485 31 465 minecraft:red_terracotta
setblock 485 28 504 minecraft:terracotta
fill 486 28 464 486 31 464 minecraft:red_terracotta
fill 486 28 504 486 31 504 minecraft:red_terracotta
setblock 487 28 466 minecraft:red_terracotta
fill 487 28 503 487 31 503 minecraft:red_terracotta
setblock 488 28 466 minecraft:terracotta
setblock 489 28 465 minecraft:terracotta
fill 489 28 466 489 31 466 minecraft:red_terracotta
setblock 490 28 464 minecraft:terracotta
fill 490 28 465 490 31 465 minecraft:red_terracotta
setblock 490 28 504 minecraft:terracotta
fill 491 28 464 491 31 464 minecraft:red_terracotta
setblock 491 28 503 minecraft:terracotta
fill 491 28 504 491 31 504 minecraft:red_terracotta
setblock 492 28 502 minecraft:terracotta
fill 492 28 503 492 31 503 minecraft:red_terracotta
setblock 493 28 466 minecraft:terracotta
fill 493 28 502 493 31 502 minecraft:red_terracotta
setblock 494 28 465 minecraft:terracotta
fill 494 28 466 494 31 466 minecraft:red_terracotta
setblock 495 28 464 minecraft:terracotta
fill 495 28 465 495 31 465 minecraft:red_terracotta
setblock 495 28 504 minecraft:terracotta
fill 496 28 464 496 31 464 minecraft:red_terracotta
setblock 496 28 503 minecraft:terracotta
fill 496 28 504 496 31 504 minecraft:red_terracotta
fill 497 28 503 500 28 503 minecraft:red_terracotta
setblock 500 28 464 minecraft:terracotta
setblock 500 28 504 minecraft:terracotta
fill 501 28 464 501 31 464 minecraft:red_terracotta
setblock 501 28 503 minecraft:terracotta
fill 501 28 504 501 31 504 minecraft:red_terracotta
fill 503 28 464 504 28 464 minecraft:red_terracotta
setblock 505 28 464 minecraft:terracotta
setblock 505 28 503 minecraft:red_terracotta
setblock 505 28 504 minecraft:terracotta
fill 506 28 464 506 31 464 minecraft:red_terracotta
setblock 506 28 503 minecraft:terracotta
fill 506 28 504 506 31 504 minecraft:red_terracotta
fill 507 28 503 507 31 503 minecraft:red_terracotta
fill 509 28 483 509 28 484 minecraft:red_terracotta
setblock 509 28 485 minecraft:terracotta
fill 509 28 486 509 28 489 minecraft:red_terracotta
setblock 510 28 464 minecraft:terracotta
fill 510 28 480 510 31 480 minecraft:red_terracotta
setblock 510 28 484 minecraft:terracotta
fill 510 28 485 510 31 485 minecraft:red_terracotta
setblock 510 28 489 minecraft:terracotta
fill 510 28 490 510 31 490 minecraft:red_terracotta
setblock 510 28 493 minecraft:red_terracotta
setblock 510 28 494 minecraft:terracotta
fill 510 28 495 510 31 495 minecraft:red_terracotta
fill 510 28 497 510 29 497 minecraft:red_terracotta
setblock 510 28 499 minecraft:terracotta
fill 510 28 500 510 31 500 minecraft:red_terracotta
setblock 510 28 504 minecraft:terracotta
fill 511 28 464 511 31 464 minecraft:red_terracotta
setblock 511 28 468 minecraft:terracotta
fill 511 28 476 511 29 476 minecraft:red_terracotta
setblock 511 28 478 minecraft:terracotta
fill 511 28 479 511 31 479 minecraft:red_terracotta
setblock 511 28 483 minecraft:terracotta
fill 511 28 484 511 31 484 minecraft:red_terracotta
setblock 511 28 488 minecraft:terracotta
fill 511 28 489 511 31 489 minecraft:red_terracotta
setblock 511 28 493 minecraft:terracotta
fill 511 28 494 511 31 494 minecraft:red_terracotta
setblock 511 28 498 minecraft:terracotta
fill 511 28 499 511 31 499 minecraft:red_terracotta
setblock 511 28 503 minecraft:terracotta
fill 511 28 504 511 31 504 minecraft:red_terracotta
fill 471 29 464 471 29 466 minecraft:red_terracotta
setblock 471 29 467 minecraft:terracotta
fill 471 29 468 471 32 468 minecraft:red_terracotta
fill 471 29 470 471 29 471 minecraft:red_terracotta
setblock 471 29 472 minecraft:terracotta
fill 471 29 473 471 29 476 minecraft:red_terracotta
setblock 471 29 477 minecraft:terracotta
fill 471 29 478 471 32 478 minecraft:red_terracotta
setblock 471 29 482 minecraft:terracotta
fill 471 29 483 471 32 483 minecraft:red_terracotta
setblock 471 29 487 minecraft:terracotta
fill 471 29 488 471 32 488 minecraft:red_terracotta
setblock 471 29 492 minecraft:terracotta
fill 471 29 493 471 29 496 minecraft:red_terracotta
setblock 471 29 497 minecraft:terracotta
fill 471 29 498 471 32 498 minecraft:red_terracotta
setblock 471 29 502 minecraft:terracotta
fill 471 29 503 471 32 503 minecraft:red_terracotta
setblock 472 29 465 minecraft:red_terracotta
setblock 472 29 466 minecraft:terracotta
fill 472 29 467 472 32 467 minecraft:red_terracotta
fill 472 29 469 472 29 470 minecraft:red_terracotta
setblock 472 29 471 minecraft:terracotta
fill 472 29 472 472 29 475 minecraft:red_terracotta
setblock 472 29 476 minecraft:terracotta
fill 472 29 477 472 32 477 minecraft:red_terracotta
setblock 472 29 481 minecraft:terracotta
fill 472 29 482 472 32 482 minecraft:red_terracotta
setblock 472 29 486 minecraft:terracotta
fill 472 29 487 472 32 487 minecraft:red_terracotta
setblock 472 29 491 minecraft:terracotta
fill 472 29 492 472 32 492 minecraft:red_terracotta
setblock 473 29 465 minecraft:terracotta
setblock 473 29 480 minecraft:terracotta
fill 473 29 481 473 32 481 minecraft:red_terracotta
setblock 473 29 485 minecraft:terracotta
fill 473 29 486 473 32 486 minecraft:red_terracotta
setblock 474 29 464 minecraft:terracotta
fill 474 29 465 474 32 465 minecraft:red_terracotta
setblock 474 29 484 minecraft:terracotta
fill 474 29 485 474 30 485 minecraft:red_terracotta
setblock 474 29 504 minecraft:terracotta
fill 475 29 464 475 32 464 minecraft:red_terracotta
fill 475 29 504 475 32 504 minecraft:red_terracotta
setblock 478 29 465 minecraft:terracotta
setblock 479 29 464 minecraft:terracotta
fill 479 29 465 482 29 465 minecraft:red_terracotta
fill 480 29 464 483 29 464 minecraft:red_terracotta
setblock 483 29 465 minecraft:terracotta
setblock 484 29 464 minecraft:terracotta
fill 484 29 465 484 32 465 minecraft:red_terracotta
setblock 484 29 504 minecraft:terracotta
fill 485 29 464 485 32 464 minecraft:red_terracotta
fill 485 29 504 485 32 504 minecraft:red_terracotta
setblock 486 29 466 minecraft:red_terracotta
setblock 487 29 466 minecraft:terracotta
setblock 488 29 465 minecraft:terracotta
fill 488 29 466 488 32 466 minecraft:red_terracotta
setblock 489 29 464 minecraft:terracotta
fill 489 29 465 489 32 465 minecraft:red_terracotta
setblock 489 29 504 minecraft:terracotta
fill 490 29 464 490 32 464 minecraft:red_terracotta
setblock 490 29 502 minecraft:red_terracotta
setblock 490 29 503 minecraft:terracotta
fill 490 29 504 490 32 504 minecraft:red_terracotta
setblock 491 29 502 minecraft:terracotta
fill 491 29 503 491 32 503 minecraft:red_terracotta
setblock 492 29 466 minecraft:terracotta
fill 492 29 502 492 32 502 minecraft:red_terracotta
setblock 493 29 465 minecraft:terracotta
fill 493 29 466 493 32 466 minecraft:red_terracotta
setblock 494 29 464 minecraft:terracotta
fill 494 29 465 494 32 465 minecraft:red_terracotta
setblock 494 29 504 minecraft:terracotta
fill 495 29 464 495 32 464 minecraft:red_terracotta
setblock 495 29 503 minecraft:terracotta
fill 495 29 504 495 32 504 minecraft:red_terracotta
fill 496 29 503 499 29 503 minecraft:red_terracotta
setblock 498 29 465 minecraft:terracotta
setblock 499 29 464 minecraft:terracotta
setblock 499 29 504 minecraft:terracotta
fill 500 29 464 500 32 464 minecraft:red_terracotta
setblock 500 29 503 minecraft:terracotta
fill 500 29 504 500 32 504 minecraft:red_terracotta
setblock 503 29 464 minecraft:red_terracotta
setblock 504 29 464 minecraft:terracotta
setblock 504 29 504 minecraft:terracotta
fill 505 29 464 505 32 464 minecraft:red_terracotta
setblock 505 29 503 minecraft:terracotta
fill 505 29 504 505 32 504 minecraft:red_terracotta
fill 506 29 503 506 32 503 minecraft:red_terracotta
setblock 509 29 464 minecraft:terracotta
fill 509 29 465 510 31 465 minecraft:red_terracotta
fill 509 29 482 509 29 483 minecraft:red_terracotta
setblock 509 29 484 minecraft:terracotta
fill 509 29 485 509 29 488 minecraft:red_terracotta
setblock 509 29 489 minecraft:terracotta
fill 509 29 490 509 31 491 minecraft:red_terracotta
setblock 509 29 504 minecraft:terracotta
fill 510 29 464 510 32 464 minecraft:red_terracotta
fill 510 29 466 510 30 466 minecraft:red_terracotta
fill 510 29 479 510 32 479 minecraft:red_terracotta
setblock 510 29 483 minecraft:terracotta
fill 510 29 484 510 32 484 minecraft:red_terracotta
setblock 510 29 488 minecraft:terracotta
fill 510 29 489 510 32 489 minecraft:red_terracotta
setblock 510 29 493 minecraft:terracotta
fill 510 29 494 510 32 494 minecraft:red_terracotta
fill 510 29 496 510 30 496 minecraft:red_terracotta
setblock 510 29 498 minecraft:terracotta
fill 510 29 499 510 32 499 minecraft:red_terracotta
setblock 510 29 503 minecraft:terracotta
fill 510 29 504 510 32 504 minecraft:red_terracotta
setblock 511 29 467 minecraft:terracotta
fill 511 29 468 511 29 471 minecraft:red_terracotta
fill 511 29 475 511 30 475 minecraft:red_terracotta
setblock 511 29 477 minecraft:terracotta
fill 511 29 478 511 32 478 minecraft:red_terracotta
setblock 511 29 482 minecraft:terracotta
fill 511 29 483 511 32 483 minecraft:red_terracotta
setblock 511 29 487 minecraft:terracotta
fill 511 29 488 511 32 488 minecraft:red_terracotta
setblock 511 29 492 minecraft:terracotta
fill 511 29 493 511 32 493 minecraft:red_terracotta
setblock 511 29 497 minecraft:terracotta
fill 511 29 498 511 32 498 minecraft:red_terracotta
setblock 511 29 502 minecraft:terracotta
fill 511 29 503 511 32 503 minecraft:red_terracotta
fill 471 30 464 471 30 465 minecraft:red_terracotta
setblock 471 30 466 minecraft:terracotta
fill 471 30 467 471 33 467 minecraft:red_terracotta
setblock 471 30 470 minecraft:red_terracotta
setblock 471 30 471 minecraft:terracotta
fill 471 30 472 471 30 475 minecraft:red_terracotta
setblock 471 30 476 minecraft:terracotta
fill 471 30 477 471 33 477 minecraft:red_terracotta
setblock 471 30 481 minecraft:terracotta
fill 471 30 482 471 33 482 minecraft:red_terracotta
setblock 471 30 486 minecraft:terracotta
fill 471 30 487 471 33 487 minecraft:red_terracotta
setblock 471 30 491 minecraft:terracotta
fill 471 30 492 471 30 495 minecraft:red_terracotta
setblock 471 30 496 minecraft:terracotta
fill 471 30 497 471 33 497 minecraft:red_terracotta
setblock 471 30 501 minecraft:terracotta
fill 471 30 502 471 33 502 minecraft:red_terracotta
setblock 472 30 465 minecraft:terracotta
fill 472 30 466 475 30 466 minecraft:red_terracotta
setblock 472 30 469 minecraft:red_terracotta
setblock 472 30 470 minecraft:terracotta
fill 472 30 471 472 30 474 minecraft:red_terracotta
setblock 472 30 475 minecraft:terracotta
fill 472 30 476 472 33 476 minecraft:red_terracotta
setblock 472 30 480 minecraft:terracotta
fill 472 30 481 472 33 481 minecraft:red_terracotta
setblock 472 30 485 minecraft:terracotta
fill 472 30 486 472 33 486 minecraft:red_terracotta
setblock 472 30 490 minecraft:terracotta
fill 472 30 491 472 33 491 minecraft:red_terracotta
fill 472 30 493 472 31 493 minecraft:red_terracotta
setblock 473 30 464 minecraft:terracotta
fill 473 30 465 473 33 465 minecraft:red_terracotta
fill 473 30 467 473 30 468 minecraft:red_terracotta
setblock 473 30 474 minecraft:light[level=14]
setblock 473 30 479 minecraft:terracotta
fill 473 30 480 473 32 480 minecraft:red_terracotta
setblock 473 30 484 minecraft:terracotta
fill 473 30 485 473 33 485 minecraft:red_terracotta
setblock 473 30 489 minecraft:terracotta
fill 473 30 490 473 33 490 minecraft:red_terracotta
setblock 473 30 498 minecraft:light[level=14]
setblock 473 30 504 minecraft:terracotta
fill 474 30 464 474 33 464 minecraft:red_terracotta
setblock 474 30 484 minecraft:red_terracotta
fill 474 30 504 474 33 504 minecraft:red_terracotta
setblock 477 30 465 minecraft:terracotta
setblock 478 30 464 minecraft:terracotta
fill 478 30 465 481 30 465 minecraft:red_terracotta
fill 479 30 464 482 30 464 minecraft:red_terracotta
setblock 481 30 466 minecraft:light[level=14]
setblock 481 30 474 minecraft:light[level=14]
setblock 481 30 482 minecraft:light[level=14]
setblock 481 30 490 minecraft:light[level=14]
setblock 481 30 498 minecraft:light[level=14]
setblock 482 30 465 minecraft:terracotta
setblock 483 30 464 minecraft:terracotta
fill 483 30 465 483 33 465 minecraft:red_terracotta
setblock 483 30 504 minecraft:terracotta
fill 484 30 464 484 33 464 minecraft:red_terracotta
fill 484 30 466 485 30 466 minecraft:red_terracotta
fill 484 30 504 484 33 504 minecraft:red_terracotta
setblock 486 30 466 minecraft:terracotta
fill 486 30 503 486 32 503 minecraft:red_terracotta
setblock 487 30 465 minecraft:terracotta
fill 487 30 466 487 33 466 minecraft:red_terracotta
setblock 488 30 464 minecraft:terracotta
fill 488 30 465 488 33 465 minecraft:red_terracotta
fill 488 30 467 489 30 467 minecraft:red_terracotta
setblock 488 30 504 minecraft:terracotta
fill 489 30 464 489 33 464 minecraft:red_terracotta
setblock 489 30 474 minecraft:light[level=14]
setblock 489 30 482 minecraft:light[level=14]
setblock 489 30 490 minecraft:light[level=14]
setblock 489 30 498 minecraft:light[level=14]
setblock 489 30 503 minecraft:terracotta
fill 489 30 504 489 33 504 minecraft:red_terracotta
setblock 490 30 467 minecraft:terracotta
setblock 490 30 502 minecraft:terracotta
fill 490 30 503 490 33 503 minecraft:red_terracotta
setblock 491 30 466 minecraft:terracotta
fill 491 30 467 492 32 467 minecraft:red_terracotta
fill 491 30 502 491 33 502 minecraft:red_terracotta
setblock 492 30 465 minecraft:terracotta
fill 492 30 466 492 33 466 minecraft:red_terracotta
setblock 493 30 464 minecraft:terracotta
fill 493 30 465 493 33 465 minecraft:red_terracotta
setblock 493 30 504 minecraft:terracotta
fill 494 30 464 494 33 464 minecraft:red_terracotta
setblock 494 30 503 minecraft:terracotta
fill 494 30 504 494 33 504 minecraft:red_terracotta
fill 495 30 495 495 31 495 minecraft:orange_concrete
setblock 495 30 502 minecraft:terracotta
fill 495 30 503 498 30 503 minecraft:red_terracotta
setblock 497 30 465 minecraft:terracotta
setblock 497 30 466 minecraft:light[level=14]
setblock 497 30 474 minecraft:light[level=14]
setblock 497 30 490 minecraft:light[level=14]
setblock 497 30 498 minecraft:light[level=14]
setblock 498 30 464 minecraft:terracotta
fill 498 30 465 498 33 465 minecraft:red_terracotta
setblock 498 30 504 minecraft:terracotta
fill 499 30 464 499 33 464 minecraft:red_terracotta
setblock 499 30 503 minecraft:terracotta
fill 499 30 504 499 33 504 minecraft:red_terracotta
setblock 500 30 503 minecraft:red_terracotta
setblock 503 30 464 minecraft:terracotta
setblock 503 30 504 minecraft:terracotta
fill 504 30 464 504 33 464 minecraft:red_terracotta
setblock 504 30 503 minecraft:terracotta
fill 504 30 504 504 33 504 minecraft:red_terracotta
setblock 505 30 466 minecraft:light[level=14]
setblock 505 30 474 minecraft:light[level=14]
setblock 505 30 482 minecraft:light[level=14]
setblock 505 30 490 minecraft:light[level=14]
setblock 505 30 498 minecraft:light[level=14]
fill 505 30 503 505 33 503 minecraft:red_terracotta
setblock 507 30 465 minecraft:terracotta
setblock 508 30 464 minecraft:terracotta
fill 508 30 465 508 33 465 minecraft:red_terracotta
fill 508 30 486 508 30 488 minecraft:red_terracotta
setblock 508 30 504 minecraft:terracotta
fill 509 30 464 509 33 464 minecraft:red_terracotta
setblock 509 30 482 minecraft:red_terracotta
setblock 509 30 483 minecraft:terracotta
fill 509 30 484 509 30 487 minecraft:red_terracotta
setblock 509 30 488 minecraft:terracotta
fill 509 30 489 509 33 489 minecraft:red_terracotta
setblock 509 30 492 minecraft:red_terracotta
setblock 509 30 493 minecraft:terracotta
setblock 509 30 503 minecraft:terracotta
fill 509 30 504 509 33 504 minecraft:red_terracotta
setblock 510 30 467 minecraft:terracotta
fill 510 30 468 511 32 468 minecraft:red_terracotta
setblock 510 30 482 minecraft:terracotta
fill 510 30 483 510 33 483 minecraft:red_terracotta
setblock 510 30 487 minecraft:terracotta
fill 510 30 488 510 33 488 minecraft:red_terracotta
setblock 510 30 491 minecraft:red_terracotta
setblock 510 30 492 minecraft:terracotta
fill 510 30 493 510 33 493 minecraft:red_terracotta
setblock 510 30 497 minecraft:terracotta
fill 510 30 498 510 33 498 minecraft:red_terracotta
setblock 510 30 502 minecraft:terracotta
fill 510 30 503 510 33 503 minecraft:red_terracotta
setblock 511 30 466 minecraft:terracotta
fill 511 30 467 511 33 467 minecraft:red_terracotta
fill 511 30 469 511 30 470 minecraft:red_terracotta
setblock 511 30 471 minecraft:terracotta
fill 511 30 472 511 31 474 minecraft:red_terracotta
setblock 511 30 476 minecraft:terracotta
fill 511 30 477 511 33 477 minecraft:red_terracotta
setblock 511 30 481 minecraft:terracotta
fill 511 30 482 511 33 482 minecraft:red_terracotta
setblock 511 30 486 minecraft:terracotta
fill 511 30 487 511 33 487 minecraft:red_terracotta
setblock 511 30 491 minecraft:terracotta
fill 511 30 492 511 33 492 minecraft:red_terracotta
setblock 511 30 496 minecraft:terracotta
fill 511 30 497 511 33 497 minecraft:red_terracotta
setblock 511 30 501 minecraft:terracotta
fill 511 30 502 511 33 502 minecraft:red_terracotta
setblock 471 31 464 minecraft:red_terracotta
setblock 471 31 465 minecraft:terracotta
fill 471 31 466 474 31 466 minecraft:red_terracotta
setblock 471 31 470 minecraft:terracotta
fill 471 31 471 471 31 474 minecraft:red_terracotta
setblock 471 31 475 minecraft:terracotta
fill 471 31 476 471 34 476 minecraft:red_terracotta
setblock 471 31 480 minecraft:terracotta
fill 471 31 481 471 34 481 minecraft:red_terracotta
setblock 471 31 485 minecraft:terracotta
fill 471 31 486 471 34 486 minecraft:red_terracotta
setblock 471 31 490 minecraft:terracotta
fill 471 31 491 471 31 494 minecraft:red_terracotta
setblock 471 31 495 minecraft:terracotta
fill 471 31 496 471 34 496 minecraft:red_terracotta
setblock 471 31 500 minecraft:terracotta
fill 471 31 501 471 33 501 minecraft:red_terracotta
setblock 472 31 464 minecraft:terracotta
fill 472 31 465 472 34 465 minecraft:red_terracotta
setblock 472 31 469 minecraft:terracotta
fill 472 31 470 472 31 473 minecraft:red_terracotta
setblock 472 31 474 minecraft:terracotta
fill 472 31 475 472 34 475 minecraft:red_terracotta
setblock 472 31 479 minecraft:terracotta
fill 472 31 480 472 34 480 minecraft:red_terracotta
setblock 472 31 484 minecraft:terracotta
fill 472 31 485 472 34 485 minecraft:red_terracotta
setblock 472 31 489 minecraft:terracotta
fill 472 31 490 472 34 490 minecraft:red_terracotta
setblock 472 31 504 minecraft:terracotta
fill 473 31 464 473 34 464 minecraft:red_terracotta
setblock 473 31 467 minecraft:red_terracotta
setblock 473 31 468 minecraft:terracotta
fill 473 31 469 473 33 470 minecraft:red_terracotta
setblock 473 31 479 minecraft:red_terracotta
setblock 473 31 483 minecraft:terracotta
fill 473 31 484 473 34 484 minecraft:red_terracotta
setblock 473 31 488 minecraft:terracotta
fill 473 31 489 473 34 489 minecraft:red_terracotta
fill 473 31 504 473 33 504 minecraft:red_terracotta
setblock 475 31 466 minecraft:terracotta
setblock 476 31 465 minecraft:terracotta
fill 476 31 466 476 34 466 minecraft:red_terracotta
setblock 477 31 464 minecraft:terracotta
fill 477 31 465 480 31 465 minecraft:red_terracotta
fill 478 31 464 481 31 464 minecraft:red_terracotta
setblock 481 31 465 minecraft:terracotta
setblock 482 31 464 minecraft:terracotta
fill 482 31 465 482 33 466 minecraft:red_terracotta
setblock 482 31 504 minecraft:terracotta
fill 483 31 464 483 34 464 minecraft:red_terracotta
fill 483 31 466 484 31 466 minecraft:red_terracotta
fill 483 31 504 483 34 504 minecraft:red_terracotta
setblock 485 31 466 minecraft:terracotta
setblock 486 31 465 minecraft:terracotta
fill 486 31 466 486 33 467 minecraft:red_terracotta
setblock 487 31 464 minecraft:terracotta
fill 487 31 465 487 34 465 minecraft:red_terracotta
fill 487 31 467 488 31 467 minecraft:red_terracotta
setblock 487 31 504 minecraft:terracotta
fill 488 31 464 488 34 464 minecraft:red_terracotta
setblock 488 31 503 minecraft:terracotta
fill 488 31 504 488 34 504 minecraft:red_terracotta
setblock 489 31 467 minecraft:terracotta
setblock 489 31 502 minecraft:terracotta
fill 489 31 503 489 34 503 minecraft:red_terracotta
setblock 490 31 466 minecraft:terracotta
fill 490 31 467 490 34 467 minecraft:red_terracotta
fill 490 31 502 490 34 502 minecraft:red_terracotta
setblock 491 31 465 minecraft:terracotta
fill 491 31 466 491 34 466 minecraft:red_terracotta
setblock 492 31 464 minecraft:terracotta
fill 492 31 465 492 34 465 minecraft:red_terracotta
setblock 492 31 504 minecraft:terracotta
fill 493 31 464 493 34 464 minecraft:red_terracotta
setblock 493 31 467 minecraft:red_terracotta
setblock 493 31 503 minecraft:terracotta
fill 493 31 504 493 34 504 minecraft:red_terracotta
setblock 494 31 502 minecraft:terracotta
fill 494 31 503 497 31 503 minecraft:red_terracotta
setblock 495 31 466 minecraft:terracotta
setblock 496 31 465 minecraft:terracotta
setblock 496 31 466 minecraft:red_terracotta
setblock 497 31 464 minecraft:terracotta
fill 497 31 465 497 34 465 minecraft:red_terracotta
setblock 497 31 504 minecraft:terracotta
fill 498 31 464 498 34 464 minecraft:red_terracotta
setblock 498 31 503 minecraft:terracotta
fill 498 31 504 498 34 504 minecraft:red_terracotta
setblock 499 31 503 minecraft:red_terracotta
setblock 502 31 464 minecraft:terracotta
setblock 502 31 504 minecraft:terracotta
fill 503 31 464 503 34 464 minecraft:red_terracotta
fill 503 31 504 503 34 504 minecraft:red_terracotta
fill 504 31 503 504 33 503 minecraft:red_terracotta
setblock 505 31 465 minecraft:red_terracotta
setblock 506 31 465 minecraft:terracotta
setblock 507 31 464 minecraft:terracotta
fill 507 31 465 507 34 465 minecraft:red_terracotta
setblock 507 31 504 minecraft:terracotta
fill 508 31 464 508 34 464 minecraft:red_terracotta
fill 508 31 484 508 31 487 minecraft:red_terracotta
setblock 508 31 488 minecraft:terracotta
fill 508 31 489 508 32 491 minecraft:red_terracotta
setblock 508 31 503 minecraft:terracotta
fill 508 31 504 508 34 504 minecraft:red_terracotta
setblock 509 31 481 minecraft:red_terracotta
setblock 509 31 482 minecraft:terracotta
fill 509 31 483 509 31 486 minecraft:red_terracotta
setblock 509 31 487 minecraft:terracotta
fill 509 31 488 509 34 488 minecraft:red_terracotta
setblock 509 31 492 minecraft:terracotta
fill 509 31 493 509 33 494 minecraft:red_terracotta
fill 509 31 503 509 34 503 minecraft:red_terracotta
setblock 510 31 466 minecraft:terracotta
fill 510 31 467 510 34 467 minecraft:red_terracotta
fill 510 31 469 510 31 470 minecraft:red_terracotta
fill 510 31 478 510 33 478 minecraft:red_terracotta
setblock 510 31 481 minecraft:terracotta
fill 510 31 482 510 34 482 minecraft:red_terracotta
setblock 510 31 486 minecraft:terracotta
fill 510 31 487 510 34 487 minecraft:red_terracotta
setblock 510 31 491 minecraft:terracotta
fill 510 31 492 510 34 492 minecraft:red_terracotta
setblock 510 31 496 minecraft:terracotta
fill 510 31 497 510 34 497 minecraft:red_terracotta
setblock 510 31 501 minecraft:terracotta
fill 510 31 502 510 34 502 minecraft:red_terracotta
setblock 511 31 465 minecraft:terracotta
fill 511 31 466 511 34 466 minecraft:red_terracotta
setblock 511 31 469 minecraft:red_terracotta
setblock 511 31 470 minecraft:terracotta
fill 511 31 471 511 34 471 minecraft:red_terracotta
setblock 511 31 475 minecraft:terracotta
fill 511 31 476 511 34 476 minecraft:red_terracotta
setblock 511 31 480 minecraft:terracotta
fill 511 31 481 511 34 481 minecraft:red_terracotta
setblock 511 31 485 minecraft:terracotta
fill 511 31 486 511 34 486 minecraft:red_terracotta
setblock 511 31 490 minecraft:terracotta
fill 511 31 491 511 34 491 minecraft:red_terracotta
setblock 511 31 495 minecraft:terracotta
fill 511 31 496 511 34 496 minecraft:red_terracotta
setblock 511 31 500 minecraft:terracotta
fill 511 31 501 511 34 501 minecraft:red_terracotta
setblock 471 32 464 minecraft:terracotta
fill 471 32 465 471 34 466 minecraft:red_terracotta
setblock 471 32 469 minecraft:terracotta
fill 471 32 470 471 32 473 minecraft:red_terracotta
setblock 471 32 474 minecraft:terracotta
fill 471 32 475 471 35 475 minecraft:red_terracotta
setblock 471 32 479 minecraft:terracotta
fill 471 32 480 471 35 480 minecraft:red_terracotta
setblock 471 32 484 minecraft:terracotta
fill 471 32 485 471 35 485 minecraft:red_terracotta
setblock 471 32 489 minecraft:terracotta
fill 471 32 490 471 32 493 minecraft:red_terracotta
setblock 471 32 494 minecraft:terracotta
fill 471 32 495 471 35 495 minecraft:red_terracotta
setblock 471 32 499 minecraft:terracotta
fill 471 32 500 471 33 500 minecraft:red_terracotta
setblock 471 32 504 minecraft:terracotta
fill 472 32 464 472 35 464 minecraft:red_terracotta
fill 472 32 466 473 32 466 minecraft:red_terracotta
setblock 472 32 468 minecraft:terracotta
fill 472 32 469 472 32 472 minecraft:red_terracotta
setblock 472 32 473 minecraft:terracotta
fill 472 32 474 472 35 474 minecraft:red_terracotta
setblock 472 32 478 minecraft:terracotta
fill 472 32 479 472 35 479 minecraft:red_terracotta
setblock 472 32 483 minecraft:terracotta
fill 472 32 484 472 35 484 minecraft:red_terracotta
setblock 472 32 488 minecraft:terracotta
fill 472 32 489 472 35 489 minecraft:red_terracotta
setblock 472 32 493 minecraft:terracotta
fill 472 32 494 472 34 494 minecraft:red_terracotta
fill 472 32 504 472 34 504 minecraft:red_terracotta
setblock 473 32 467 minecraft:terracotta
fill 473 32 468 473 35 468 minecraft:red_terracotta
setblock 473 32 471 minecraft:red_terracotta
setblock 473 32 472 minecraft:terracotta
setblock 473 32 482 minecraft:terracotta
fill 473 32 483 473 33 483 minecraft:red_terracotta
setblock 473 32 487 minecraft:terracotta
fill 473 32 488 473 34 488 minecraft:red_terracotta
setblock 474 32 466 minecraft:terracotta
setblock 475 32 465 minecraft:terracotta
fill 475 32 466 475 34 466 minecraft:red_terracotta
setblock 476 32 464 minecraft:terracotta
fill 476 32 465 479 32 465 minecraft:red_terracotta
fill 477 32 464 480 32 464 minecraft:red_terracotta
fill 477 32 466 477 33 466 minecraft:red_terracotta
setblock 480 32 465 minecraft:terracotta
setblock 481 32 464 minecraft:terracotta
fill 481 32 465 481 34 466 minecraft:red_terracotta
fill 482 32 464 482 35 464 minecraft:red_terracotta
fill 482 32 504 482 35 504 minecraft:red_terracotta
setblock 483 32 466 minecraft:red_terracotta
setblock 484 32 466 minecraft:terracotta
setblock 485 32 465 minecraft:terracotta
fill 485 32 466 485 34 467 minecraft:red_terracotta
fill 485 32 503 485 33 503 minecraft:red_terracotta
setblock 486 32 464 minecraft:terracotta
fill 486 32 465 486 35 465 minecraft:red_terracotta
setblock 486 32 504 minecraft:terracotta
fill 487 32 464 487 35 464 minecraft:red_terracotta
setblock 487 32 467 minecraft:red_terracotta
setblock 487 32 503 minecraft:terracotta
fill 487 32 504 487 35 504 minecraft:red_terracotta
setblock 488 32 467 minecraft:terracotta
fill 488 32 503 488 35 503 minecraft:red_terracotta
setblock 489 32 466 minecraft:terracotta
fill 489 32 467 489 35 467 minecraft:red_terracotta
fill 489 32 502 489 34 502 minecraft:red_terracotta
setblock 490 32 465 minecraft:terracotta
fill 490 32 466 490 35 466 minecraft:red_terracotta
setblock 491 32 464 minecraft:terracotta
fill 491 32 465 491 35 465 minecraft:red_terracotta
setblock 491 32 504 minecraft:terracotta
fill 492 32 464 492 35 464 minecraft:red_terracotta
setblock 492 32 503 minecraft:terracotta
fill 492 32 504 492 35 504 minecraft:red_terracotta
setblock 493 32 467 minecraft:terracotta
setblock 493 32 502 minecraft:terracotta
fill 493 32 503 496 32 503 minecraft:red_terracotta
setblock 494 32 466 minecraft:terracotta
setblock 495 32 465 minecraft:terracotta
fill 495 32 466 495 33 466 minecraft:red_terracotta
setblock 496 32 464 minecraft:terracotta
fill 496 32 465 496 34 465 minecraft:red_terracotta
setblock 496 32 504 minecraft:terracotta
fill 497 32 464 497 35 464 minecraft:red_terracotta
setblock 497 32 503 minecraft:terracotta
fill 497 32 504 497 35 504 minecraft:red_terracotta
setblock 498 32 503 minecraft:red_terracotta
setblock 501 32 464 minecraft:terracotta
setblock 501 32 504 minecraft:terracotta
fill 502 32 464 502 35 464 minecraft:red_terracotta
fill 502 32 504 502 35 504 minecraft:red_terracotta
setblock 504 32 465 minecraft:red_terracotta
setblock 505 32 465 minecraft:terracotta
setblock 506 32 464 minecraft:terracotta
fill 506 32 465 506 35 465 minecraft:red_terracotta
setblock 506 32 504 minecraft:terracotta
fill 507 32 464 507 35 464 minecraft:red_terracotta
setblock 507 32 503 minecraft:terracotta
fill 507 32 504 507 35 504 minecraft:red_terracotta
fill 508 32 484 508 32 486 minecraft:red_terracotta
setblock 508 32 487 minecraft:terracotta
fill 508 32 488 508 35 488 minecraft:red_terracotta
setblock 508 32 492 minecraft:terracotta
fill 508 32 503 508 35 503 minecraft:red_terracotta
setblock 509 32 465 minecraft:red_terracotta
setblock 509 32 466 minecraft:terracotta
fill 509 32 467 509 35 467 minecraft:red_terracotta
setblock 509 32 481 minecraft:terracotta
fill 509 32 482 509 32 485 minecraft:red_terracotta
setblock 509 32 486 minecraft:terracotta
fill 509 32 487 509 35 487 minecraft:red_terracotta
setblock 509 32 490 minecraft:red_terracotta
setblock 509 32 491 minecraft:terracotta
fill 509 32 492 509 35 492 minecraft:red_terracotta
setblock 509 32 495 minecraft:red_terracotta
setblock 509 32 496 minecraft:terracotta
setblock 510 32 465 minecraft:terracotta
fill 510 32 466 510 35 466 minecraft:red_terracotta
setblock 510 32 469 minecraft:red_terracotta
setblock 510 32 470 minecraft:terracotta
fill 510 32 471 510 33 473 minecraft:red_terracotta
fill 510 32 477 510 34 477 minecraft:red_terracotta
setblock 510 32 480 minecraft:terracotta
fill 510 32 481 510 35 481 minecraft:red_terracotta
setblock 510 32 485 minecraft:terracotta
fill 510 32 486 510 35 486 minecraft:red_terracotta
setblock 510 32 490 minecraft:terracotta
fill 510 32 491 510 35 491 minecraft:red_terracotta
setblock 510 32 495 minecraft:terracotta
fill 510 32 496 510 35 496 minecraft:red_terracotta
setblock 510 32 500 minecraft:terracotta
fill 510 32 501 510 34 501 minecraft:red_terracotta
setblock 511 32 464 minecraft:terracotta
fill 511 32 465 511 35 465 minecraft:red_terracotta
setblock 511 32 469 minecraft:terracotta
fill 511 32 470 511 35 470 minecraft:red_terracotta
fill 511 32 472 511 32 473 minecraft:red_terracotta
setblock 511 32 474 minecraft:terracotta
fill 511 32 475 511 35 475 minecraft:red_terracotta
setblock 511 32 479 minecraft:terracotta
fill 511 32 480 511 35 480 minecraft:red_terracotta
setblock 511 32 484 minecraft:terracotta
fill 511 32 485 511 35 485 minecraft:red_terracotta
setblock 511 32 489 minecraft:terracotta
fill 511 32 490 511 35 490 minecraft:red_terracotta
setblock 511 32 494 minecraft:terracotta
fill 511 32 495 511 35 495 minecraft:red_terracotta
setblock 511 32 499 minecraft:terracotta
fill 511 32 500 511 35 500 minecraft:red_terracotta
setblock 511 32 504 minecraft:terracotta
fill 471 33 464 471 36 464 minecraft:red_terracotta
setblock 471 33 468 minecraft:terracotta
fill 471 33 469 471 33 472 minecraft:red_terracotta
setblock 471 33 473 minecraft:terracotta
fill 471 33 474 471 36 474 minecraft:red_terracotta
setblock 471 33 478 minecraft:terracotta
fill 471 33 479 471 36 479 minecraft:red_terracotta
setblock 471 33 483 minecraft:terracotta
fill 471 33 484 471 36 484 minecraft:red_terracotta
setblock 471 33 488 minecraft:terracotta
fill 471 33 489 471 33 492 minecraft:red_terracotta
setblock 471 33 493 minecraft:terracotta
fill 471 33 494 471 36 494 minecraft:red_terracotta
setblock 471 33 498 minecraft:terracotta
setblock 471 33 499 minecraft:red_terracotta
setblock 471 33 503 minecraft:terracotta
fill 471 33 504 471 35 504 minecraft:red_terracotta
setblock 472 33 466 minecraft:red_terracotta
setblock 472 33 467 minecraft:terracotta
fill 472 33 468 472 33 471 minecraft:red_terracotta
setblock 472 33 472 minecraft:terracotta
fill 472 33 473 473 35 473 minecraft:red_terracotta
setblock 472 33 477 minecraft:terracotta
fill 472 33 478 472 35 478 minecraft:red_terracotta
setblock 472 33 482 minecraft:terracotta
fill 472 33 483 472 36 483 minecraft:red_terracotta
setblock 472 33 487 minecraft:terracotta
fill 472 33 488 472 36 488 minecraft:red_terracotta
setblock 472 33 492 minecraft:terracotta
fill 472 33 493 472 36 493 minecraft:red_terracotta
setblock 473 33 466 minecraft:terracotta
fill 473 33 467 473 36 467 minecraft:red_terracotta
setblock 473 33 471 minecraft:terracotta
fill 473 33 472 473 36 472 minecraft:red_terracotta
setblock 473 33 482 minecraft:red_terracotta
setblock 473 33 486 minecraft:terracotta
fill 473 33 487 473 34 487 minecraft:red_terracotta
setblock 474 33 465 minecraft:terracotta
fill 474 33 466 474 35 466 minecraft:red_terracotta
setblock 475 33 464 minecraft:terracotta
fill 475 33 465 478 33 465 minecraft:red_terracotta
fill 476 33 464 479 33 464 minecraft:red_terracotta
setblock 479 33 465 minecraft:terracotta
fill 479 33 466 480 33 466 minecraft:red_terracotta
setblock 480 33 464 minecraft:terracotta
fill 480 33 465 480 36 465 minecraft:red_terracotta
fill 481 33 464 481 36 464 minecraft:red_terracotta
setblock 483 33 466 minecraft:terracotta
setblock 484 33 465 minecraft:terracotta
fill 484 33 466 484 35 467 minecraft:red_terracotta
setblock 485 33 464 minecraft:terracotta
fill 485 33 465 485 36 465 minecraft:red_terracotta
setblock 485 33 504 minecraft:terracotta
fill 486 33 464 486 36 464 minecraft:red_terracotta
setblock 486 33 503 minecraft:terracotta
fill 486 33 504 486 36 504 minecraft:red_terracotta
setblock 487 33 467 minecraft:terracotta
fill 487 33 503 487 36 503 minecraft:red_terracotta
setblock 488 33 466 minecraft:terracotta
fill 488 33 467 488 36 467 minecraft:red_terracotta
setblock 489 33 465 minecraft:terracotta
fill 489 33 466 489 36 466 minecraft:red_terracotta
setblock 490 33 464 minecraft:terracotta
fill 490 33 465 490 36 465 minecraft:red_terracotta
setblock 490 33 504 minecraft:terracotta
fill 491 33 464 491 36 464 minecraft:red_terracotta
setblock 491 33 467 minecraft:red_terracotta
setblock 491 33 503 minecraft:terracotta
fill 491 33 504 491 36 504 minecraft:red_terracotta
setblock 492 33 467 minecraft:terracotta
setblock 492 33 502 minecraft:terracotta
fill 492 33 503 495 33 503 minecraft:red_terracotta
setblock 493 33 466 minecraft:terracotta
setblock 494 33 465 minecraft:terracotta
fill 494 33 466 494 34 466 minecraft:red_terracotta
setblock 495 33 464 minecraft:terracotta
fill 495 33 465 495 35 465 minecraft:red_terracotta
setblock 495 33 504 minecraft:terracotta
fill 496 33 464 496 36 464 minecraft:red_terracotta
setblock 496 33 503 minecraft:terracotta
fill 496 33 504 496 36 504 minecraft:red_terracotta
setblock 497 33 503 minecraft:red_terracotta
setblock 500 33 464 minecraft:terracotta
setblock 500 33 504 minecraft:terracotta
fill 501 33 464 501 35 464 minecraft:red_terracotta
fill 501 33 504 501 35 504 minecraft:red_terracotta
setblock 504 33 465 minecraft:terracotta
setblock 505 33 464 minecraft:terracotta
fill 505 33 465 505 36 465 minecraft:red_terracotta
setblock 505 33 504 minecraft:terracotta
fill 506 33 464 506 36 464 minecraft:red_terracotta
setblock 506 33 503 minecraft:terracotta
fill 506 33 504 506 36 504 minecraft:red_terracotta
fill 507 33 488 507 35 489 minecraft:red_terracotta
fill 507 33 503 507 35 503 minecraft:red_terracotta
setblock 508 33 466 minecraft:terracotta
fill 508 33 484 508 33 485 minecraft:red_terracotta
setblock 508 33 486 minecraft:terracotta
fill 508 33 487 508 36 487 minecraft:red_terracotta
fill 508 33 489 508 33 490 minecraft:red_terracotta
setblock 508 33 491 minecraft:terracotta
fill 508 33 492 508 35 493 minecraft:red_terracotta
setblock 509 33 465 minecraft:terracotta
fill 509 33 466 509 34 466 minecraft:red_terracotta
fill 509 33 468 509 33 469 minecraft:red_terracotta
fill 509 33 481 509 33 484 minecraft:red_terracotta
setblock 509 33 485 minecraft:terracotta
fill 509 33 486 509 36 486 minecraft:red_terracotta
setblock 509 33 490 minecraft:terracotta
fill 509 33 491 509 36 491 minecraft:red_terracotta
setblock 509 33 495 minecraft:terracotta
fill 509 33 496 509 36 496 minecraft:red_terracotta
setblock 510 33 464 minecraft:terracotta
fill 510 33 465 510 36 465 minecraft:red_terracotta
setblock 510 33 468 minecraft:red_terracotta
setblock 510 33 469 minecraft:terracotta
fill 510 33 470 510 36 470 minecraft:red_terracotta
setblock 510 33 474 minecraft:terracotta
fill 510 33 475 510 35 476 minecraft:red_terracotta
setblock 510 33 479 minecraft:terracotta
fill 510 33 480 510 36 480 minecraft:red_terracotta
setblock 510 33 484 minecraft:terracotta
fill 510 33 485 510 36 485 minecraft:red_terracotta
setblock 510 33 489 minecraft:terracotta
fill 510 33 490 510 36 490 minecraft:red_terracotta
setblock 510 33 494 minecraft:terracotta
fill 510 33 495 510 36 495 minecraft:red_terracotta
setblock 510 33 499 minecraft:terracotta
fill 510 33 500 510 34 500 minecraft:red_terracotta
setblock 510 33 504 minecraft:terracotta
fill 511 33 464 511 36 464 minecraft:red_terracotta
setblock 511 33 468 minecraft:terracotta
fill 511 33 469 511 36 469 minecraft:red_terracotta
setblock 511 33 472 minecraft:red_terracotta
setblock 511 33 473 minecraft:terracotta
fill 511 33 474 511 36 474 minecraft:red_terracotta
setblock 511 33 478 minecraft:terracotta
fill 511 33 479 511 36 479 minecraft:red_terracotta
setblock 511 33 483 minecraft:terracotta
fill 511 33 484 511 36 484 minecraft:red_terracotta
setblock 511 33 488 minecraft:terracotta
fill 511 33 489 511 36 489 minecraft:red_terracotta
setblock 511 33 493 minecraft:terracotta
fill 511 33 494 511 36 494 minecraft:red_terracotta
setblock 511 33 498 minecraft:terracotta
fill 511 33 499 511 36 499 minecraft:red_terracotta
setblock 511 33 503 minecraft:terracotta
fill 511 33 504 511 35 504 minecraft:red_terracotta
setblock 471 34 467 minecraft:terracotta
fill 471 34 468 471 34 471 minecraft:red_terracotta
setblock 471 34 472 minecraft:terracotta
fill 471 34 473 471 37 473 minecraft:red_terracotta
setblock 471 34 477 minecraft:terracotta
fill 471 34 478 471 37 478 minecraft:red_terracotta
setblock 471 34 482 minecraft:terracotta
fill 471 34 483 471 37 483 minecraft:red_terracotta
setblock 471 34 487 minecraft:terracotta
fill 471 34 488 471 34 491 minecraft:red_terracotta
setblock 471 34 492 minecraft:terracotta
fill 471 34 493 471 37 493 minecraft:red_terracotta
setblock 471 34 497 minecraft:terracotta
setblock 471 34 503 minecraft:red_terracotta
setblock 472 34 466 minecraft:terracotta
fill 472 34 467 472 34 470 minecraft:red_terracotta
setblock 472 34 471 minecraft:terracotta
fill 472 34 472 472 37 472 minecraft:red_terracotta
setblock 472 34 476 minecraft:terracotta
fill 472 34 477 472 36 477 minecraft:red_terracotta
setblock 472 34 481 minecraft:terracotta
fill 472 34 482 472 35 482 minecraft:red_terracotta
setblock 472 34 486 minecraft:terracotta
fill 472 34 487 472 37 487 minecraft:red_terracotta
setblock 472 34 491 minecraft:terracotta
fill 472 34 492 472 36 492 minecraft:red_terracotta
setblock 473 34 465 minecraft:terracotta
fill 473 34 466 473 35 466 minecraft:red_terracotta
setblock 473 34 469 minecraft:red_terracotta
setblock 473 34 470 minecraft:terracotta
fill 473 34 471 473 37 471 minecraft:red_terracotta
setblock 473 34 485 minecraft:terracotta
setblock 473 34 486 minecraft:red_terracotta
setblock 473 34 490 minecraft:terracotta
setblock 474 34 464 minecraft:terracotta
fill 474 34 465 477 34 465 minecraft:red_terracotta
fill 475 34 464 478 34 464 minecraft:red_terracotta
setblock 478 34 465 minecraft:terracotta
setblock 479 34 464 minecraft:terracotta
fill 479 34 465 479 37 465 minecraft:red_terracotta
fill 480 34 464 480 37 464 minecraft:red_terracotta
fill 480 34 466 480 35 466 minecraft:red_terracotta
setblock 482 34 465 minecraft:red_terracotta
setblock 482 34 466 minecraft:terracotta
setblock 483 34 465 minecraft:terracotta
fill 483 34 466 483 36 467 minecraft:red_terracotta
setblock 484 34 464 minecraft:terracotta
fill 484 34 465 484 37 465 minecraft:red_terracotta
setblock 484 34 504 minecraft:terracotta
fill 485 34 464 485 37 464 minecraft:red_terracotta
setblock 485 34 503 minecraft:terracotta
fill 485 34 504 485 37 504 minecraft:red_terracotta
setblock 486 34 466 minecraft:red_terracotta
setblock 486 34 467 minecraft:terracotta
fill 486 34 503 486 37 503 minecraft:red_terracotta
setblock 487 34 466 minecraft:terracotta
fill 487 34 467 487 37 467 minecraft:red_terracotta
setblock 488 34 465 minecraft:terracotta
fill 488 34 466 488 37 466 minecraft:red_terracotta
setblock 489 34 464 minecraft:terracotta
fill 489 34 465 489 37 465 minecraft:red_terracotta
setblock 489 34 504 minecraft:terracotta
fill 490 34 464 490 37 464 minecraft:red_terracotta
setblock 490 34 503 minecraft:terracotta
fill 490 34 504 490 37 504 minecraft:red_terracotta
setblock 491 34 467 minecraft:terracotta
setblock 491 34 502 minecraft:terracotta
fill 491 34 503 494 34 503 minecraft:red_terracotta
setblock 492 34 466 minecraft:terracotta
setblock 492 34 467 minecraft:red_terracotta
setblock 493 34 465 minecraft:terracotta
fill 493 34 466 493 35 466 minecraft:red_terracotta
setblock 494 34 464 minecraft:terracotta
fill 494 34 465 494 36 465 minecraft:red_terracotta
setblock 494 34 504 minecraft:terracotta
fill 495 34 464 495 36 464 minecraft:red_terracotta
setblock 495 34 503 minecraft:terracotta
fill 495 34 504 495 36 504 minecraft:red_terracotta
setblock 499 34 464 minecraft:terracotta
setblock 499 34 504 minecraft:terracotta
fill 500 34 464 500 35 464 minecraft:red_terracotta
fill 500 34 504 500 35 504 minecraft:red_terracotta
setblock 504 34 464 minecraft:terracotta
fill 504 34 465 504 35 465 minecraft:red_terracotta
setblock 504 34 504 minecraft:terracotta
fill 505 34 464 505 37 464 minecraft:red_terracotta
setblock 505 34 503 minecraft:terracotta
fill 505 34 504 505 37 504 minecraft:red_terracotta
fill 506 34 503 506 35 503 minecraft:red_terracotta
setblock 507 34 490 minecraft:red_terracotta
setblock 508 34 465 minecraft:terracotta
setblock 508 34 466 minecraft:red_terracotta
setblock 508 34 484 minecraft:red_terracotta
setblock 508 34 485 minecraft:terracotta
fill 508 34 486 508 36 486 minecraft:red_terracotta
setblock 508 34 489 minecraft:red_terracotta
setblock 508 34 490 minecraft:terracotta
fill 508 34 491 508 37 491 minecraft:red_terracotta
setblock 508 34 494 minecraft:red_terracotta
setblock 509 34 464 minecraft:terracotta
fill 509 34 465 509 36 465 minecraft:red_terracotta
setblock 509 34 468 minecraft:red_terracotta
setblock 509 34 469 minecraft:terracotta
fill 509 34 470 509 36 470 minecraft:red_terracotta
fill 509 34 481 509 34 483 minecraft:red_terracotta
setblock 509 34 484 minecraft:terracotta
fill 509 34 485 509 37 485 minecraft:red_terracotta
setblock 509 34 489 minecraft:terracotta
fill 509 34 490 509 37 490 minecraft:red_terracotta
setblock 509 34 493 minecraft:red_terracotta
setblock 509 34 494 minecraft:terracotta
fill 509 34 495 509 37 495 minecraft:red_terracotta
setblock 509 34 504 minecraft:terracotta
fill 510 34 464 510 37 464 minecraft:red_terracotta
setblock 510 34 468 minecraft:terracotta
fill 510 34 469 510 37 469 minecraft:red_terracotta
fill 510 34 471 510 34 472 minecraft:red_terracotta
setblock 510 34 473 minecraft:terracotta
fill 510 34 474 510 37 474 minecraft:red_terracotta
setblock 510 34 478 minecraft:terracotta
fill 510 34 479 510 36 479 minecraft:red_terracotta
setblock 510 34 483 minecraft:terracotta
fill 510 34 484 510 37 484 minecraft:red_terracotta
setblock 510 34 488 minecraft:terracotta
fill 510 34 489 510 37 489 minecraft:red_terracotta
setblock 510 34 493 minecraft:terracotta
fill 510 34 494 510 37 494 minecraft:red_terracotta
setblock 510 34 498 minecraft:terracotta
setblock 510 34 499 minecraft:red_terracotta
setblock 510 34 503 minecraft:terracotta
fill 510 34 504 510 36 504 minecraft:red_terracotta
setblock 511 34 467 minecraft:terracotta
fill 511 34 468 511 37 468 minecraft:red_terracotta
setblock 511 34 472 minecraft:terracotta
fill 511 34 473 511 37 473 minecraft:red_terracotta
setblock 511 34 477 minecraft:terracotta
fill 511 34 478 511 37 478 minecraft:red_terracotta
setblock 511 34 482 minecraft:terracotta
fill 511 34 483 511 37 483 minecraft:red_terracotta
setblock 511 34 487 minecraft:terracotta
fill 511 34 488 511 37 488 minecraft:red_terracotta
setblock 511 34 492 minecraft:terracotta
fill 511 34 493 511 37 493 minecraft:red_terracotta
setblock 511 34 497 minecraft:terracotta
fill 511 34 498 511 37 498 minecraft:red_terracotta
setblock 511 34 502 minecraft:terracotta
fill 511 34 503 511 35 503 minecraft:red_terracotta
setblock 471 35 465 minecraft:red_terracotta
setblock 471 35 466 minecraft:terracotta
fill 471 35 467 471 35 470 minecraft:red_terracotta
setblock 471 35 471 minecraft:terracotta
fill 471 35 472 471 38 472 minecraft:red_terracotta
setblock 471 35 476 minecraft:terracotta
fill 471 35 477 471 38 477 minecraft:red_terracotta
setblock 471 35 481 minecraft:terracotta
fill 471 35 482 471 38 482 minecraft:red_terracotta
setblock 471 35 486 minecraft:terracotta
fill 471 35 487 471 35 490 minecraft:red_terracotta
setblock 471 35 491 minecraft:terracotta
fill 471 35 492 471 38 492 minecraft:red_terracotta
setblock 471 35 496 minecraft:terracotta
setblock 471 35 497 minecraft:red_terracotta
setblock 472 35 465 minecraft:terracotta
fill 472 35 466 472 35 469 minecraft:red_terracotta
setblock 472 35 470 minecraft:terracotta
fill 472 35 471 472 38 471 minecraft:red_terracotta
setblock 472 35 475 minecraft:terracotta
fill 472 35 476 472 37 476 minecraft:red_terracotta
setblock 472 35 480 minecraft:terracotta
setblock 472 35 481 minecraft:red_terracotta
setblock 472 35 485 minecraft:terracotta
fill 472 35 486 472 36 486 minecraft:red_terracotta
setblock 472 35 490 minecraft:terracotta
fill 472 35 491 472 37 491 minecraft:red_terracotta
setblock 473 35 464 minecraft:terracotta
fill 473 35 465 476 35 465 minecraft:red_terracotta
setblock 473 35 469 minecraft:terracotta
fill 473 35 470 473 37 470 minecraft:red_terracotta
fill 474 35 464 477 35 464 minecraft:red_terracotta
setblock 477 35 465 minecraft:terracotta
setblock 478 35 464 minecraft:terracotta
fill 478 35 465 478 36 465 minecraft:red_terracotta
fill 479 35 464 479 38 464 minecraft:red_terracotta
setblock 481 35 465 minecraft:red_terracotta
setblock 481 35 466 minecraft:terracotta
setblock 482 35 465 minecraft:terracotta
fill 482 35 466 482 38 466 minecraft:red_terracotta
setblock 483 35 464 minecraft:terracotta
fill 483 35 465 483 38 465 minecraft:red_terracotta
setblock 483 35 504 minecraft:terracotta
fill 484 35 464 484 38 464 minecraft:red_terracotta
fill 484 35 504 484 38 504 minecraft:red_terracotta
setblock 485 35 466 minecraft:red_terracotta
setblock 485 35 467 minecraft:terracotta
fill 485 35 503 485 37 503 minecraft:red_terracotta
setblock 486 35 466 minecraft:terracotta
fill 486 35 467 486 37 467 minecraft:red_terracotta
setblock 487 35 465 minecraft:terracotta
fill 487 35 466 487 38 466 minecraft:red_terracotta
setblock 488 35 464 minecraft:terracotta
fill 488 35 465 488 38 465 minecraft:red_terracotta
setblock 488 35 504 minecraft:terracotta
fill 489 35 464 489 38 464 minecraft:red_terracotta
setblock 489 35 503 minecraft:terracotta
fill 489 35 504 489 38 504 minecraft:red_terracotta
setblock 490 35 467 minecraft:terracotta
fill 490 35 503 493 35 503 minecraft:red_terracotta
setblock 491 35 466 minecraft:terracotta
setblock 491 35 467 minecraft:red_terracotta
setblock 492 35 465 minecraft:terracotta
fill 492 35 466 492 36 466 minecraft:red_terracotta
setblock 493 35 464 minecraft:terracotta
fill 493 35 465 493 36 465 minecraft:red_terracotta
setblock 493 35 504 minecraft:terracotta
fill 494 35 464 494 37 464 minecraft:red_terracotta
setblock 494 35 503 minecraft:terracotta
fill 494 35 504 494 37 504 minecraft:red_terracotta
setblock 498 35 464 minecraft:terracotta
setblock 498 35 504 minecraft:terracotta
setblock 499 35 464 minecraft:red_terracotta
setblock 499 35 504 minecraft:red_terracotta
setblock 503 35 464 minecraft:terracotta
setblock 503 35 504 minecraft:terracotta
fill 504 35 464 504 37 464 minecraft:red_terracotta
fill 504 35 504 504 37 504 minecraft:red_terracotta
setblock 507 35 465 minecraft:terracotta
setblock 507 35 490 minecraft:terracotta
setblock 507 35 491 minecraft:red_terracotta
setblock 508 35 464 minecraft:terracotta
fill 508 35 465 508 36 465 minecraft:red_terracotta
setblock 508 35 485 minecraft:red_terracotta
setblock 508 35 489 minecraft:terracotta
fill 508 35 490 508 38 490 minecraft:red_terracotta
setblock 508 35 494 minecraft:terracotta
setblock 508 35 504 minecraft:terracotta
fill 509 35 464 509 37 464 minecraft:red_terracotta
setblock 509 35 468 minecraft:terracotta
fill 509 35 469 509 36 469 minecraft:red_terracotta
fill 509 35 471 510 35 471 minecraft:red_terracotta
setblock 509 35 482 minecraft:red_terracotta
setblock 509 35 483 minecraft:terracotta
fill 509 35 484 509 37 484 minecraft:red_terracotta
setblock 509 35 488 minecraft:terracotta
fill 509 35 489 509 38 489 minecraft:red_terracotta
setblock 509 35 493 minecraft:terracotta
fill 509 35 494 509 38 494 minecraft:red_terracotta
fill 509 35 504 509 36 504 minecraft:red_terracotta
setblock 510 35 467 minecraft:terracotta
fill 510 35 468 510 38 468 minecraft:red_terracotta
setblock 510 35 472 minecraft:terracotta
fill 510 35 473 510 38 473 minecraft:red_terracotta
setblock 510 35 477 minecraft:terracotta
fill 510 35 478 510 36 478 minecraft:red_terracotta
setblock 510 35 482 minecraft:terracotta
fill 510 35 483 510 38 483 minecraft:red_terracotta
setblock 510 35 487 minecraft:terracotta
fill 510 35 488 510 38 488 minecraft:red_terracotta
setblock 510 35 492 minecraft:terracotta
fill 510 35 493 510 38 493 minecraft:red_terracotta
setblock 510 35 497 minecraft:terracotta
fill 510 35 498 510 36 498 minecraft:red_terracotta
setblock 511 35 466 minecraft:terracotta
fill 511 35 467 511 38 467 minecraft:red_terracotta
setblock 511 35 471 minecraft:terracotta
fill 511 35 472 511 38 472 minecraft:red_terracotta
setblock 511 35 476 minecraft:terracotta
fill 511 35 477 511 38 477 minecraft:red_terracotta
setblock 511 35 481 minecraft:terracotta
fill 511 35 482 511 38 482 minecraft:red_terracotta
setblock 511 35 486 minecraft:terracotta
fill 511 35 487 511 38 487 minecraft:red_terracotta
setblock 511 35 491 minecraft:terracotta
fill 511 35 492 511 38 492 minecraft:red_terracotta
setblock 511 35 496 minecraft:terracotta
fill 511 35 497 511 38 497 minecraft:red_terracotta
setblock 511 35 501 minecraft:terracotta
setblock 511 35 502 minecraft:red_terracotta
setblock 471 36 465 minecraft:terracotta
fill 471 36 466 471 36 469 minecraft:red_terracotta
setblock 471 36 470 minecraft:terracotta
fill 471 36 471 471 39 471 minecraft:red_terracotta
setblock 471 36 475 minecraft:terracotta
fill 471 36 476 471 39 476 minecraft:red_terracotta
setblock 471 36 480 minecraft:terracotta
fill 471 36 481 471 38 481 minecraft:red_terracotta
setblock 471 36 485 minecraft:terracotta
fill 471 36 486 471 36 489 minecraft:red_terracotta
setblock 471 36 490 minecraft:terracotta
fill 471 36 491 471 39 491 minecraft:red_terracotta
setblock 471 36 495 minecraft:terracotta
fill 471 36 496 471 37 496 minecraft:red_terracotta
setblock 472 36 464 minecraft:terracotta
fill 472 36 465 472 36 468 minecraft:red_terracotta
setblock 472 36 469 minecraft:terracotta
fill 472 36 470 472 39 470 minecraft:red_terracotta
setblock 472 36 473 minecraft:red_terracotta
setblock 472 36 474 minecraft:terracotta
fill 472 36 475 472 39 475 minecraft:red_terracotta
setblock 472 36 484 minecraft:terracotta
setblock 472 36 485 minecraft:red_terracotta
setblock 472 36 489 minecraft:terracotta
fill 472 36 490 472 37 490 minecraft:red_terracotta
fill 473 36 464 475 36 465 minecraft:red_terracotta
setblock 473 36 468 minecraft:terracotta
fill 473 36 469 473 37 469 minecraft:red_terracotta
setblock 476 36 464 minecraft:red_terracotta
setblock 476 36 465 minecraft:terracotta
setblock 477 36 464 minecraft:terracotta
setblock 477 36 465 minecraft:red_terracotta
fill 478 36 464 478 38 464 minecraft:red_terracotta
setblock 481 36 465 minecraft:terracotta
setblock 481 36 466 minecraft:red_terracotta
setblock 482 36 464 minecraft:terracotta
fill 482 36 465 482 39 465 minecraft:red_terracotta
setblock 482 36 504 minecraft:terracotta
fill 483 36 464 483 39 464 minecraft:red_terracotta
fill 483 36 504 483 39 504 minecraft:red_terracotta
setblock 484 36 466 minecraft:red_terracotta
setblock 484 36 467 minecraft:terracotta
setblock 485 36 466 minecraft:terracotta
fill 485 36 467 485 37 467 minecraft:red_terracotta
setblock 486 36 465 minecraft:terracotta
fill 486 36 466 486 39 466 minecraft:red_terracotta
setblock 487 36 464 minecraft:terracotta
fill 487 36 465 487 39 465 minecraft:red_terracotta
setblock 487 36 504 minecraft:terracotta
fill 488 36 464 488 39 464 minecraft:red_terracotta
fill 488 36 501 489 37 502 minecraft:orange_concrete
setblock 488 36 503 minecraft:terracotta
fill 488 36 504 488 39 504 minecraft:red_terracotta
setblock 489 36 467 minecraft:terracotta
fill 489 36 503 492 36 503 minecraft:red_terracotta
setblock 490 36 466 minecraft:terracotta
setblock 490 36 467 minecraft:red_terracotta
setblock 491 36 465 minecraft:terracotta
setblock 491 36 466 minecraft:red_terracotta
setblock 492 36 464 minecraft:terracotta
fill 492 36 465 492 37 465 minecraft:red_terracotta
setblock 492 36 504 minecraft:terracotta
fill 493 36 464 493 37 464 minecraft:red_terracotta
fill 493 36 504 493 37 504 minecraft:red_terracotta
setblock 502 36 464 minecraft:terracotta
setblock 502 36 504 minecraft:terracotta
setblock 503 36 464 minecraft:red_terracotta
fill 503 36 504 503 37 504 minecraft:red_terracotta
setblock 506 36 465 minecraft:terracotta
setblock 507 36 464 minecraft:terracotta
setblock 507 36 465 minecraft:red_terracotta
setblock 507 36 490 minecraft:red_terracotta
setblock 507 36 504 minecraft:terracotta
fill 508 36 464 508 38 464 minecraft:red_terracotta
setblock 508 36 488 minecraft:terracotta
fill 508 36 489 508 38 489 minecraft:red_terracotta
setblock 508 36 492 minecraft:red_terracotta
setblock 508 36 493 minecraft:terracotta
fill 508 36 494 508 37 494 minecraft:red_terracotta
fill 508 36 504 508 37 504 minecraft:red_terracotta
setblock 509 36 468 minecraft:red_terracotta
setblock 509 36 471 minecraft:red_terracotta
setblock 509 36 483 minecraft:red_terracotta
setblock 509 36 487 minecraft:terracotta
fill 509 36 488 509 39 488 minecraft:red_terracotta
setblock 509 36 492 minecraft:terracotta
fill 509 36 493 509 39 493 minecraft:red_terracotta
setblock 510 36 466 minecraft:terracotta
fill 510 36 467 510 37 467 minecraft:red_terracotta
setblock 510 36 471 minecraft:terracotta
fill 510 36 472 510 39 472 minecraft:red_terracotta
setblock 510 36 475 minecraft:red_terracotta
setblock 510 36 476 minecraft:terracotta
fill 510 36 477 510 37 477 minecraft:red_terracotta
setblock 510 36 481 minecraft:terracotta
fill 510 36 482 510 37 482 minecraft:red_terracotta
setblock 510 36 486 minecraft:terracotta
fill 510 36 487 510 39 487 minecraft:red_terracotta
setblock 510 36 491 minecraft:terracotta
fill 510 36 492 510 39 492 minecraft:red_terracotta
setblock 510 36 496 minecraft:terracotta
fill 510 36 497 510 37 497 minecraft:red_terracotta
setblock 511 36 465 minecraft:terracotta
fill 511 36 466 511 38 466 minecraft:red_terracotta
setblock 511 36 470 minecraft:terracotta
fill 511 36 471 511 39 471 minecraft:red_terracotta
setblock 511 36 475 minecraft:terracotta
fill 511 36 476 511 39 476 minecraft:red_terracotta
setblock 511 36 480 minecraft:terracotta
fill 511 36 481 511 39 481 minecraft:red_terracotta
setblock 511 36 485 minecraft:terracotta
fill 511 36 486 511 39 486 minecraft:red_terracotta
setblock 511 36 490 minecraft:terracotta
fill 511 36 491 511 39 491 minecraft:red_terracotta
setblock 511 36 495 minecraft:terracotta
fill 511 36 496 511 39 496 minecraft:red_terracotta
setblock 511 36 500 minecraft:terracotta
setblock 471 37 464 minecraft:terracotta
fill 471 37 465 471 37 468 minecraft:red_terracotta
setblock 471 37 469 minecraft:terracotta
fill 471 37 470 471 40 470 minecraft:red_terracotta
setblock 471 37 474 minecraft:terracotta
fill 471 37 475 471 40 475 minecraft:red_terracotta
setblock 471 37 479 minecraft:terracotta
fill 471 37 480 471 38 480 minecraft:red_terracotta
setblock 471 37 484 minecraft:terracotta
fill 471 37 485 471 37 488 minecraft:red_terracotta
setblock 471 37 489 minecraft:terracotta
fill 471 37 490 471 40 490 minecraft:red_terracotta
setblock 471 37 494 minecraft:terracotta
fill 471 37 495 471 38 495 minecraft:red_terracotta
fill 472 37 464 472 37 467 minecraft:red_terracotta
setblock 472 37 468 minecraft:terracotta
fill 472 37 469 472 40 469 minecraft:red_terracotta
setblock 472 37 473 minecraft:terracotta
fill 472 37 474 472 40 474 minecraft:red_terracotta
setblock 472 37 488 minecraft:terracotta
setblock 472 37 489 minecraft:red_terracotta
fill 473 37 464 475 37 464 minecraft:red_terracotta
setblock 476 37 464 minecraft:terracotta
setblock 477 37 464 minecraft:red_terracotta
setblock 480 37 465 minecraft:terracotta
setblock 481 37 464 minecraft:terracotta
fill 481 37 465 481 40 465 minecraft:red_terracotta
fill 482 37 464 482 40 464 minecraft:red_terracotta
setblock 482 37 504 minecraft:red_terracotta
setblock 483 37 466 minecraft:red_terracotta
setblock 484 37 466 minecraft:terracotta
setblock 484 37 467 minecraft:red_terracotta
setblock 485 37 465 minecraft:terracotta
fill 485 37 466 485 39 466 minecraft:red_terracotta
setblock 486 37 464 minecraft:terracotta
fill 486 37 465 486 40 465 minecraft:red_terracotta
setblock 486 37 504 minecraft:terracotta
fill 487 37 464 487 40 464 minecraft:red_terracotta
setblock 487 37 503 minecraft:terracotta
fill 487 37 504 487 40 504 minecraft:red_terracotta
setblock 488 37 467 minecraft:terracotta
fill 488 37 503 490 37 503 minecraft:red_terracotta
setblock 489 37 466 minecraft:terracotta
fill 489 37 474 490 38 475 minecraft:orange_concrete
setblock 490 37 465 minecraft:terracotta
setblock 490 37 466 minecraft:red_terracotta
setblock 491 37 464 minecraft:terracotta
fill 491 37 465 491 38 465 minecraft:red_terracotta
setblock 491 37 504 minecraft:terracotta
fill 492 37 464 492 38 464 minecraft:red_terracotta
fill 492 37 504 492 38 504 minecraft:red_terracotta
setblock 506 37 464 minecraft:terracotta
setblock 506 37 504 minecraft:terracotta
fill 507 37 464 507 38 464 minecraft:red_terracotta
setblock 507 37 504 minecraft:red_terracotta
setblock 508 37 487 minecraft:terracotta
fill 508 37 488 508 38 488 minecraft:red_terracotta
setblock 508 37 492 minecraft:terracotta
fill 508 37 493 508 38 493 minecraft:red_terracotta
setblock 509 37 486 minecraft:terracotta
fill 509 37 487 509 38 487 minecraft:red_terracotta
setblock 509 37 491 minecraft:terracotta
fill 509 37 492 509 40 492 minecraft:red_terracotta
setblock 509 37 496 minecraft:terracotta
setblock 510 37 466 minecraft:red_terracotta
setblock 510 37 470 minecraft:terracotta
fill 510 37 471 510 40 471 minecraft:red_terracotta
setblock 510 37 475 minecraft:terracotta
fill 510 37 476 510 40 476 minecraft:red_terracotta
setblock 510 37 480 minecraft:terracotta
setblock 510 37 481 minecraft:red_terracotta
setblock 510 37 485 minecraft:terracotta
fill 510 37 486 510 39 486 minecraft:red_terracotta
setblock 510 37 490 minecraft:terracotta
fill 510 37 491 510 40 491 minecraft:red_terracotta
setblock 510 37 495 minecraft:terracotta
fill 510 37 496 510 40 496 minecraft:red_terracotta
setblock 511 37 464 minecraft:terracotta
setblock 511 37 465 minecraft:red_terracotta
setblock 511 37 469 minecraft:terracotta
fill 511 37 470 511 40 470 minecraft:red_terracotta
setblock 511 37 474 minecraft:terracotta
fill 511 37 475 511 40 475 minecraft:red_terracotta
setblock 511 37 479 minecraft:terracotta
fill 511 37 480 511 40 480 minecraft:red_terracotta
setblock 511 37 484 minecraft:terracotta
fill 511 37 485 511 40 485 minecraft:red_terracotta
setblock 511 37 489 minecraft:terracotta
fill 511 37 490 511 40 490 minecraft:red_terracotta
setblock 511 37 494 minecraft:terracotta
fill 511 37 495 511 40 495 minecraft:red_terracotta
fill 471 38 464 471 38 467 minecraft:red_terracotta
setblock 471 38 468 minecraft:terracotta
fill 471 38 469 471 41 469 minecraft:red_terracotta
setblock 471 38 473 minecraft:terracotta
fill 471 38 474 471 41 474 minecraft:red_terracotta
setblock 471 38 478 minecraft:terracotta
fill 471 38 479 471 41 479 minecraft:red_terracotta
setblock 471 38 483 minecraft:terracotta
fill 471 38 484 471 38 487 minecraft:red_terracotta
setblock 471 38 488 minecraft:terracotta
fill 471 38 489 471 39 489 minecraft:red_terracotta
setblock 471 38 493 minecraft:terracotta
fill 471 38 494 471 39 494 minecraft:red_terracotta
setblock 472 38 464 minecraft:red_terracotta
setblock 472 38 466 minecraft:red_terracotta
setblock 472 38 467 minecraft:terracotta
fill 472 38 468 472 39 468 minecraft:red_terracotta
setblock 472 38 472 minecraft:terracotta
fill 472 38 473 472 41 473 minecraft:red_terracotta
setblock 473 38 466 minecraft:light[level=14]
setblock 473 38 474 minecraft:light[level=14]
setblock 473 38 482 minecraft:light[level=14]
setblock 473 38 490 minecraft:light[level=14]
setblock 473 38 498 minecraft:light[level=14]
setblock 480 38 464 minecraft:terracotta
setblock 480 38 465 minecraft:red_terracotta
fill 481 38 464 481 41 464 minecraft:red_terracotta
setblock 481 38 466 minecraft:light[level=14]
setblock 481 38 474 minecraft:light[level=14]
setblock 481 38 482 minecraft:light[level=14]
setblock 481 38 490 minecraft:light[level=14]
setblock 481 38 498 minecraft:light[level=14]
setblock 483 38 466 minecraft:terracotta
setblock 484 38 465 minecraft:terracotta
fill 484 38 466 484 39 466 minecraft:red_terracotta
setblock 485 38 464 minecraft:terracotta
fill 485 38 465 485 41 465 minecraft:red_terracotta
setblock 485 38 504 minecraft:terracotta
fill 486 38 464 486 41 464 minecraft:red_terracotta
setblock 486 38 503 minecraft:terracotta
fill 486 38 504 486 41 504 minecraft:red_terracotta
fill 487 38 503 489 38 503 minecraft:red_terracotta
setblock 488 38 466 minecraft:terracotta
setblock 489 38 465 minecraft:terracotta
setblock 489 38 466 minecraft:red_terracotta
setblock 489 38 482 minecraft:light[level=14]
setblock 489 38 490 minecraft:light[level=14]
setblock 489 38 498 minecraft:light[level=14]
setblock 490 38 464 minecraft:terracotta
setblock 490 38 465 minecraft:red_terracotta
setblock 490 38 504 minecraft:terracotta
fill 491 38 464 491 39 464 minecraft:red_terracotta
fill 491 38 504 491 39 504 minecraft:red_terracotta
setblock 497 38 466 minecraft:light[level=14]
setblock 497 38 474 minecraft:light[level=14]
setblock 497 38 490 minecraft:light[level=14]
setblock 497 38 498 minecraft:light[level=14]
setblock 505 38 464 minecraft:terracotta
setblock 505 38 466 minecraft:light[level=14]
setblock 505 38 474 minecraft:light[level=14]
setblock 505 38 482 minecraft:light[level=14]
setblock 505 38 490 minecraft:light[level=14]
setblock 505 38 498 minecraft:light[level=14]
setblock 505 38 504 minecraft:terracotta
setblock 506 38 464 minecraft:red_terracotta
setblock 506 38 504 minecraft:red_terracotta
setblock 508 38 491 minecraft:terracotta
fill 508 38 492 508 39 492 minecraft:red_terracotta
setblock 509 38 486 minecraft:red_terracotta
setblock 509 38 490 minecraft:terracotta
fill 509 38 491 509 40 491 minecraft:red_terracotta
setblock 509 38 495 minecraft:terracotta
setblock 510 38 469 minecraft:terracotta
fill 510 38 470 510 40 470 minecraft:red_terracotta
setblock 510 38 474 minecraft:terracotta
fill 510 38 475 510 41 475 minecraft:red_terracotta
setblock 510 38 484 minecraft:terracotta
fill 510 38 485 510 39 485 minecraft:red_terracotta
setblock 510 38 489 minecraft:terracotta
fill 510 38 490 510 41 490 minecraft:red_terracotta
setblock 510 38 494 minecraft:terracotta
fill 510 38 495 510 41 495 minecraft:red_terracotta
setblock 511 38 468 minecraft:terracotta
fill 511 38 469 511 41 469 minecraft:red_terracotta
setblock 511 38 473 minecraft:terracotta
fill 511 38 474 511 41 474 minecraft:red_terracotta
setblock 511 38 478 minecraft:terracotta
fill 511 38 479 511 41 479 minecraft:red_terracotta
setblock 511 38 483 minecraft:terracotta
fill 511 38 484 511 40 484 minecraft:red_terracotta
setblock 511 38 488 minecraft:terracotta
fill 511 38 489 511 41 489 minecraft:red_terracotta
setblock 511 38 493 minecraft:terracotta
fill 511 38 494 511 41 494 minecraft:red_terracotta
setblock 511 38 498 minecraft:terracotta
fill 471 39 465 471 39 466 minecraft:red_terracotta
setblock 471 39 467 minecraft:terracotta
fill 471 39 468 471 42 468 minecraft:red_terracotta
setblock 471 39 472 minecraft:terracotta
fill 471 39 473 471 42 473 minecraft:red_terracotta
setblock 471 39 477 minecraft:terracotta
fill 471 39 478 471 42 478 minecraft:red_terracotta
setblock 471 39 487 minecraft:terracotta
setblock 471 39 488 minecraft:red_terracotta
setblock 471 39 492 minecraft:terracotta
fill 471 39 493 471 40 493 minecraft:red_terracotta
setblock 472 39 471 minecraft:terracotta
fill 472 39 472 472 42 472 minecraft:red_terracotta
setblock 479 39 464 minecraft:terracotta
fill 480 39 464 480 42 464 minecraft:red_terracotta
setblock 483 39 465 minecraft:terracotta
setblock 483 39 466 minecraft:red_terracotta
setblock 484 39 464 minecraft:terracotta
fill 484 39 465 484 42 465 minecraft:red_terracotta
setblock 484 39 504 minecraft:terracotta
fill 485 39 464 485 42 464 minecraft:red_terracotta
fill 485 39 504 485 42 504 minecraft:red_terracotta
fill 486 39 503 487 39 503 minecraft:red_terracotta
setblock 487 39 466 minecraft:terracotta
setblock 488 39 465 minecraft:terracotta
setblock 489 39 464 minecraft:terracotta
setblock 489 39 465 minecraft:red_terracotta
setblock 489 39 504 minecraft:terracotta
fill 490 39 464 490 40 464 minecraft:red_terracotta
fill 490 39 504 490 42 504 minecraft:red_terracotta
setblock 508 39 491 minecraft:red_terracotta
setblock 509 39 489 minecraft:terracotta
fill 509 39 490 509 40 490 minecraft:red_terracotta
setblock 509 39 494 minecraft:terracotta
setblock 509 39 495 minecraft:red_terracotta
setblock 510 39 469 minecraft:red_terracotta
setblock 510 39 473 minecraft:terracotta
fill 510 39 474 510 42 474 minecraft:red_terracotta
setblock 510 39 488 minecraft:terracotta
fill 510 39 489 510 41 489 minecraft:red_terracotta
setblock 510 39 493 minecraft:terracotta
fill 510 39 494 510 42 494 minecraft:red_terracotta
setblock 511 39 467 minecraft:terracotta
fill 511 39 468 511 40 468 minecraft:red_terracotta
setblock 511 39 472 minecraft:terracotta
fill 511 39 473 511 42 473 minecraft:red_terracotta
setblock 511 39 477 minecraft:terracotta
fill 511 39 478 511 42 478 minecraft:red_terracotta
setblock 511 39 482 minecraft:terracotta
fill 511 39 483 511 40 483 minecraft:red_terracotta
setblock 511 39 487 minecraft:terracotta
fill 511 39 488 511 42 488 minecraft:red_terracotta
setblock 511 39 492 minecraft:terracotta
fill 511 39 493 511 42 493 minecraft:red_terracotta
setblock 511 39 497 minecraft:terracotta
setblock 471 40 466 minecraft:terracotta
fill 471 40 467 471 43 467 minecraft:red_terracotta
setblock 471 40 471 minecraft:terracotta
fill 471 40 472 471 43 472 minecraft:red_terracotta
setblock 471 40 476 minecraft:terracotta
fill 471 40 477 471 43 477 minecraft:red_terracotta
setblock 471 40 491 minecraft:terracotta
setblock 471 40 492 minecraft:red_terracotta
setblock 472 40 470 minecraft:terracotta
fill 472 40 471 472 43 471 minecraft:red_terracotta
setblock 472 40 475 minecraft:terracotta
fill 479 40 464 479 43 464 minecraft:red_terracotta
setblock 482 40 465 minecraft:terracotta
setblock 482 40 504 minecraft:red_terracotta
setblock 483 40 464 minecraft:terracotta
fill 483 40 465 483 43 465 minecraft:red_terracotta
setblock 483 40 504 minecraft:terracotta
fill 484 40 464 484 43 464 minecraft:red_terracotta
fill 484 40 504 484 43 504 minecraft:red_terracotta
setblock 487 40 465 minecraft:terracotta
setblock 488 40 464 minecraft:terracotta
setblock 488 40 465 minecraft:red_terracotta
setblock 488 40 504 minecraft:terracotta
fill 489 40 464 489 41 464 minecraft:red_terracotta
fill 489 40 504 489 43 504 minecraft:red_terracotta
setblock 509 40 493 minecraft:terracotta
setblock 509 40 494 minecraft:red_terracotta
setblock 510 40 472 minecraft:terracotta
fill 510 40 473 510 43 473 minecraft:red_terracotta
setblock 510 40 487 minecraft:terracotta
setblock 510 40 488 minecraft:red_terracotta
setblock 510 40 492 minecraft:terracotta
fill 510 40 493 510 43 493 minecraft:red_terracotta
setblock 511 40 471 minecraft:terracotta
fill 511 40 472 511 43 472 minecraft:red_terracotta
setblock 511 40 476 minecraft:terracotta
fill 511 40 477 511 43 477 minecraft:red_terracotta
setblock 511 40 481 minecraft:terracotta
setblock 511 40 486 minecraft:terracotta
fill 511 40 487 511 41 487 minecraft:red_terracotta
setblock 511 40 491 minecraft:terracotta
fill 511 40 492 511 43 492 minecraft:red_terracotta
setblock 511 40 496 minecraft:terracotta
fill 511 40 497 511 43 497 minecraft:red_terracotta
setblock 471 41 466 minecraft:red_terracotta
setblock 471 41 470 minecraft:terracotta
fill 471 41 471 471 44 471 minecraft:red_terracotta
setblock 471 41 475 minecraft:terracotta
fill 471 41 476 471 44 476 minecraft:red_terracotta
setblock 472 41 469 minecraft:terracotta
fill 472 41 470 472 43 470 minecraft:red_terracotta
setblock 472 41 474 minecraft:terracotta
fill 472 41 475 472 44 475 minecraft:red_terracotta
setblock 481 41 465 minecraft:terracotta
setblock 482 41 464 minecraft:terracotta
fill 482 41 465 482 44 465 minecraft:red_terracotta
setblock 482 41 504 minecraft:terracotta
fill 483 41 464 483 44 464 minecraft:red_terracotta
fill 483 41 504 483 44 504 minecraft:red_terracotta
fill 485 41 503 486 42 503 minecraft:red_terracotta
setblock 486 41 465 minecraft:terracotta
setblock 487 41 464 minecraft:terracotta
setblock 487 41 465 minecraft:red_terracotta
setblock 487 41 504 minecraft:terracotta
fill 488 41 464 488 43 464 minecraft:red_terracotta
fill 488 41 504 488 44 504 minecraft:red_terracotta
setblock 510 41 471 minecraft:terracotta
fill 510 41 472 510 44 472 minecraft:red_terracotta
setblock 510 41 476 minecraft:terracotta
fill 510 41 477 510 44 477 minecraft:red_terracotta
setblock 510 41 491 minecraft:terracotta
fill 510 41 492 510 42 492 minecraft:red_terracotta
setblock 511 41 470 minecraft:terracotta
fill 511 41 471 511 44 471 minecraft:red_terracotta
setblock 511 41 475 minecraft:terracotta
fill 511 41 476 511 44 476 minecraft:red_terracotta
setblock 511 41 480 minecraft:terracotta
setblock 511 41 486 minecraft:red_terracotta
setblock 511 41 490 minecraft:terracotta
fill 511 41 491 511 44 491 minecraft:red_terracotta
setblock 511 41 495 minecraft:terracotta
fill 511 41 496 511 44 496 minecraft:red_terracotta
setblock 471 42 469 minecraft:terracotta
fill 471 42 470 471 45 470 minecraft:red_terracotta
setblock 471 42 474 minecraft:terracotta
fill 471 42 475 471 45 475 minecraft:red_terracotta
setblock 471 42 479 minecraft:terracotta
setblock 472 42 473 minecraft:terracotta
fill 472 42 474 472 45 474 minecraft:red_terracotta
setblock 481 42 464 minecraft:terracotta
fill 481 42 465 481 45 465 minecraft:red_terracotta
setblock 481 42 504 minecraft:terracotta
fill 482 42 464 482 45 464 minecraft:red_terracotta
fill 482 42 504 482 45 504 minecraft:red_terracotta
fill 483 42 503 484 44 503 minecraft:red_terracotta
setblock 485 42 465 minecraft:terracotta
setblock 486 42 464 minecraft:terracotta
setblock 486 42 465 minecraft:red_terracotta
setblock 486 42 504 minecraft:terracotta
fill 487 42 464 487 45 464 minecraft:red_terracotta
setblock 487 42 503 minecraft:terracotta
fill 487 42 504 487 45 504 minecraft:red_terracotta
fill 510 42 471 510 45 471 minecraft:red_terracotta
setblock 510 42 475 minecraft:terracotta
fill 510 42 476 510 45 476 minecraft:red_terracotta
fill 510 42 478 510 43 478 minecraft:red_terracotta
setblock 510 42 491 minecraft:red_terracotta
setblock 510 42 495 minecraft:terracotta
setblock 511 42 469 minecraft:terracotta
fill 511 42 470 511 45 470 minecraft:red_terracotta
setblock 511 42 474 minecraft:terracotta
fill 511 42 475 511 45 475 minecraft:red_terracotta
setblock 511 42 479 minecraft:terracotta
fill 511 42 480 511 44 481 minecraft:red_terracotta
setblock 511 42 489 minecraft:terracotta
fill 511 42 490 511 43 490 minecraft:red_terracotta
setblock 511 42 494 minecraft:terracotta
fill 511 42 495 511 45 495 minecraft:red_terracotta
setblock 471 43 468 minecraft:terracotta
fill 471 43 469 471 46 469 minecraft:red_terracotta
setblock 471 43 473 minecraft:terracotta
fill 471 43 474 471 46 474 minecraft:red_terracotta
setblock 471 43 478 minecraft:terracotta
fill 471 43 479 471 46 479 minecraft:red_terracotta
setblock 472 43 472 minecraft:terracotta
fill 472 43 473 472 46 473 minecraft:red_terracotta
setblock 472 43 476 minecraft:red_terracotta
fill 478 43 464 478 44 464 minecraft:red_terracotta
setblock 479 43 504 minecraft:red_terracotta
setblock 480 43 464 minecraft:terracotta
setblock 480 43 504 minecraft:terracotta
fill 481 43 464 481 46 464 minecraft:red_terracotta
fill 481 43 504 481 46 504 minecraft:red_terracotta
fill 482 43 503 482 46 503 minecraft:red_terracotta
setblock 484 43 465 minecraft:terracotta
setblock 485 43 464 minecraft:terracotta
fill 485 43 465 485 46 465 minecraft:red_terracotta
setblock 485 43 503 minecraft:red_terracotta
setblock 485 43 504 minecraft:terracotta
fill 486 43 464 486 46 464 minecraft:red_terracotta
setblock 486 43 503 minecraft:terracotta
fill 486 43 504 486 46 504 minecraft:red_terracotta
fill 487 43 503 488 45 503 minecraft:red_terracotta
setblock 490 43 504 minecraft:terracotta
fill 503 43 504 503 44 504 minecraft:red_terracotta
setblock 510 43 474 minecraft:terracotta
fill 510 43 475 510 46 475 minecraft:red_terracotta
setblock 510 43 479 minecraft:terracotta
setblock 510 43 494 minecraft:terracotta
fill 511 43 469 511 45 469 minecraft:red_terracotta
setblock 511 43 473 minecraft:terracotta
fill 511 43 474 511 46 474 minecraft:red_terracotta
setblock 511 43 478 minecraft:terracotta
fill 511 43 479 511 46 479 minecraft:red_terracotta
setblock 511 43 493 minecraft:terracotta
fill 511 43 494 511 46 494 minecraft:red_terracotta
setblock 471 44 467 minecraft:terracotta
fill 471 44 468 471 47 468 minecraft:red_terracotta
setblock 471 44 472 minecraft:terracotta
fill 471 44 473 471 47 473 minecraft:red_terracotta
setblock 471 44 477 minecraft:terracotta
fill 471 44 478 471 47 478 minecraft:red_terracotta
fill 471 44 480 471 45 480 minecraft:red_terracotta
setblock 472 44 471 minecraft:terracotta
fill 472 44 472 472 47 472 minecraft:red_terracotta
setblock 472 44 476 minecraft:terracotta
fill 472 44 477 472 47 477 minecraft:red_terracotta
fill 477 44 464 477 45 464 minecraft:red_terracotta
setblock 478 44 504 minecraft:red_terracotta
setblock 479 44 464 minecraft:terracotta
setblock 479 44 504 minecraft:terracotta
fill 480 44 464 480 46 465 minecraft:red_terracotta
setblock 480 44 503 minecraft:terracotta
fill 480 44 504 480 47 504 minecraft:red_terracotta
fill 481 44 503 481 47 503 minecraft:red_terracotta
fill 482 44 502 485 44 502 minecraft:red_terracotta
setblock 483 44 465 minecraft:terracotta
setblock 484 44 464 minecraft:terracotta
fill 484 44 465 484 47 465 minecraft:red_terracotta
setblock 484 44 504 minecraft:terracotta
fill 485 44 464 485 47 464 minecraft:red_terracotta
setblock 485 44 503 minecraft:terracotta
fill 485 44 504 485 47 504 minecraft:red_terracotta
setblock 486 44 502 minecraft:terracotta
fill 486 44 503 486 47 503 minecraft:red_terracotta
setblock 489 44 504 minecraft:terracotta
fill 490 44 504 490 47 504 minecraft:red_terracotta
fill 498 44 477 498 45 478 minecraft:magma_block
fill 500 44 504 502 45 504 minecraft:red_terracotta
setblock 504 44 504 minecraft:terracotta
fill 505 44 504 505 47 504 minecraft:red_terracotta
setblock 509 44 474 minecraft:terracotta
fill 509 44 475 509 45 477 minecraft:red_terracotta
setblock 510 44 473 minecraft:terracotta
fill 510 44 474 510 47 474 minecraft:red_terracotta
setblock 510 44 478 minecraft:terracotta
fill 510 44 479 510 46 480 minecraft:red_terracotta
setblock 511 44 472 minecraft:terracotta
fill 511 44 473 511 47 473 minecraft:red_terracotta
setblock 511 44 477 minecraft:terracotta
fill 511 44 478 511 47 478 minecraft:red_terracotta
setblock 511 44 482 minecraft:terracotta
setblock 511 44 492 minecraft:terracotta
fill 511 44 493 511 46 493 minecraft:red_terracotta
setblock 511 44 497 minecraft:terracotta
fill 471 45 467 471 48 467 minecraft:red_terracotta
setblock 471 45 471 minecraft:terracotta
fill 471 45 472 471 48 472 minecraft:red_terracotta
setblock 471 45 476 minecraft:terracotta
fill 471 45 477 471 48 477 minecraft:red_terracotta
fill 472 45 471 472 47 471 minecraft:red_terracotta
setblock 472 45 475 minecraft:terracotta
fill 472 45 476 472 48 476 minecraft:red_terracotta
fill 476 45 464 476 46 464 minecraft:red_terracotta
setblock 477 45 504 minecraft:red_terracotta
setblock 478 45 464 minecraft:terracotta
setblock 478 45 503 minecraft:red_terracotta
setblock 478 45 504 minecraft:terracotta
fill 479 45 464 479 47 465 minecraft:red_terracotta
setblock 479 45 503 minecraft:terracotta
fill 479 45 504 479 48 504 minecraft:red_terracotta
setblock 480 45 502 minecraft:terracotta
fill 480 45 503 480 48 503 minecraft:red_terracotta
fill 481 45 502 484 45 502 minecraft:red_terracotta
setblock 482 45 465 minecraft:terracotta
setblock 483 45 464 minecraft:terracotta
fill 483 45 465 483 48 465 minecraft:red_terracotta
setblock 483 45 503 minecraft:red_terracotta
setblock 483 45 504 minecraft:terracotta
fill 484 45 464 484 48 464 minecraft:red_terracotta
setblock 484 45 503 minecraft:terracotta
fill 484 45 504 484 48 504 minecraft:red_terracotta
setblock 485 45 502 minecraft:terracotta
fill 485 45 503 485 48 503 minecraft:red_terracotta
fill 486 45 502 487 47 502 minecraft:red_terracotta
setblock 488 45 504 minecraft:terracotta
setblock 489 45 503 minecraft:terracotta
fill 489 45 504 489 48 504 minecraft:red_terracotta
fill 491 45 504 491 46 504 minecraft:red_terracotta
setblock 497 45 504 minecraft:red_terracotta
setblock 498 45 504 minecraft:terracotta
fill 499 45 504 499 48 504 minecraft:red_terracotta
fill 500 45 503 503 45 503 minecraft:red_terracotta
setblock 503 45 504 minecraft:terracotta
fill 504 45 504 504 48 504 minecraft:red_terracotta
fill 509 45 474 509 47 474 minecraft:red_terracotta
setblock 509 45 478 minecraft:terracotta
setblock 510 45 472 minecraft:terracotta
fill 510 45 473 510 48 473 minecraft:red_terracotta
setblock 510 45 477 minecraft:terracotta
fill 510 45 478 510 48 478 minecraft:red_terracotta
setblock 510 45 481 minecraft:red_terracotta
setblock 511 45 471 minecraft:terracotta
fill 511 45 472 511 48 472 minecraft:red_terracotta
setblock 511 45 476 minecraft:terracotta
fill 511 45 477 511 48 477 minecraft:red_terracotta
setblock 511 45 480 minecraft:red_terracotta
setblock 511 45 481 minecraft:terracotta
fill 511 45 482 511 47 483 minecraft:red_terracotta
setblock 511 45 492 minecraft:red_terracotta
setblock 511 45 496 minecraft:terracotta
fill 511 45 497 511 47 498 minecraft:red_terracotta
setblock 471 46 470 minecraft:terracotta
fill 471 46 471 471 49 471 minecraft:red_terracotta
setblock 471 46 475 minecraft:terracotta
fill 471 46 476 471 49 476 minecraft:red_terracotta
setblock 471 46 480 minecraft:terracotta
fill 471 46 481 471 49 481 minecraft:red_terracotta
fill 471 46 497 471 46 499 minecraft:red_terracotta
setblock 472 46 474 minecraft:terracotta
fill 472 46 475 472 49 475 minecraft:red_terracotta
setblock 472 46 478 minecraft:red_terracotta
setblock 473 46 466 minecraft:light[level=14]
setblock 473 46 474 minecraft:light[level=14]
setblock 473 46 482 minecraft:light[level=14]
setblock 473 46 490 minecraft:light[level=14]
setblock 473 46 498 minecraft:light[level=14]
fill 474 46 464 475 47 464 minecraft:red_terracotta
fill 475 46 504 476 46 504 minecraft:red_terracotta
setblock 477 46 464 minecraft:terracotta
setblock 477 46 503 minecraft:red_terracotta
setblock 477 46 504 minecraft:terracotta
fill 478 46 464 478 48 465 minecraft:red_terracotta
setblock 478 46 503 minecraft:terracotta
fill 478 46 504 478 49 504 minecraft:red_terracotta
setblock 479 46 502 minecraft:terracotta
fill 479 46 503 479 49 503 minecraft:red_terracotta
fill 480 46 502 483 46 502 minecraft:red_terracotta
setblock 481 46 465 minecraft:terracotta
setblock 481 46 466 minecraft:light[level=14]
setblock 481 46 474 minecraft:light[level=14]
setblock 481 46 482 minecraft:light[level=14]
setblock 481 46 490 minecraft:light[level=14]
setblock 481 46 498 minecraft:light[level=14]
fill 481 46 501 484 46 501 minecraft:red_terracotta
setblock 482 46 464 minecraft:terracotta
fill 482 46 465 482 49 465 minecraft:red_terracotta
setblock 482 46 504 minecraft:terracotta
fill 483 46 464 483 49 464 minecraft:red_terracotta
setblock 483 46 503 minecraft:terracotta
fill 483 46 504 483 49 504 minecraft:red_terracotta
setblock 484 46 502 minecraft:terracotta
fill 484 46 503 484 49 503 minecraft:red_terracotta
setblock 485 46 501 minecraft:terracotta
fill 485 46 502 485 49 502 minecraft:red_terracotta
setblock 487 46 464 minecraft:terracotta
setblock 487 46 503 minecraft:red_terracotta
setblock 487 46 504 minecraft:terracotta
setblock 488 46 502 minecraft:red_terracotta
setblock 488 46 503 minecraft:terracotta
fill 488 46 504 488 49 504 minecraft:red_terracotta
setblock 489 46 466 minecraft:light[level=14]
setblock 489 46 474 minecraft:light[level=14]
setblock 489 46 482 minecraft:light[level=14]
setblock 489 46 490 minecraft:light[level=14]
setblock 489 46 498 minecraft:light[level=14]
fill 489 46 503 490 48 503 minecraft:red_terracotta
setblock 492 46 504 minecraft:terracotta
fill 493 46 504 496 46 504 minecraft:red_terracotta
setblock 497 46 466 minecraft:light[level=14]
setblock 497 46 474 minecraft:light[level=14]
setblock 497 46 490 minecraft:light[level=14]
setblock 497 46 498 minecraft:light[level=14]
setblock 497 46 503 minecraft:red_terracotta
setblock 497 46 504 minecraft:terracotta
setblock 498 46 503 minecraft:terracotta
fill 498 46 504 498 49 504 minecraft:red_terracotta
fill 499 46 503 502 46 503 minecraft:red_terracotta
fill 500 46 504 501 46 504 minecraft:red_terracotta
fill 501 46 502 501 48 502 minecraft:red_terracotta
setblock 502 46 504 minecraft:terracotta
setblock 503 46 503 minecraft:terracotta
fill 503 46 504 503 49 504 minecraft:red_terracotta
fill 504 46 503 504 49 503 minecraft:red_terracotta
setblock 505 46 466 minecraft:light[level=14]
setblock 505 46 474 minecraft:light[level=14]
setblock 505 46 482 minecraft:light[level=14]
setblock 505 46 490 minecraft:light[level=14]
setblock 505 46 498 minecraft:light[level=14]
setblock 506 46 504 minecraft:red_terracotta
fill 509 46 475 509 46 476 minecraft:red_terracotta
setblock 509 46 477 minecraft:terracotta
fill 509 46 478 509 48 479 minecraft:red_terracotta
fill 510 46 472 510 48 472 minecraft:red_terracotta
setblock 510 46 476 minecraft:terracotta
fill 510 46 477 510 49 477 minecraft:red_terracotta
setblock 510 46 481 minecraft:terracotta
setblock 511 46 470 minecraft:terracotta
fill 511 46 471 511 49 471 minecraft:red_terracotta
setblock 511 46 475 minecraft:terracotta
fill 511 46 476 511 49 476 minecraft:red_terracotta
setblock 511 46 480 minecraft:terracotta
fill 511 46 481 511 49 481 minecraft:red_terracotta
setblock 511 46 484 minecraft:red_terracotta
setblock 511 46 495 minecraft:terracotta
fill 511 46 496 511 47 496 minecraft:red_terracotta
setblock 511 46 499 minecraft:red_terracotta
setblock 471 47 469 minecraft:terracotta
fill 471 47 470 471 50 470 minecraft:red_terracotta
setblock 471 47 474 minecraft:terracotta
fill 471 47 475 471 50 475 minecraft:red_terracotta
setblock 471 47 479 minecraft:terracotta
fill 471 47 480 471 50 480 minecraft:red_terracotta
fill 471 47 497 471 47 498 minecraft:red_terracotta
setblock 471 47 499 minecraft:terracotta
fill 471 47 500 471 49 501 minecraft:red_terracotta
setblock 472 47 473 minecraft:terracotta
fill 472 47 474 472 49 474 minecraft:red_terracotta
setblock 472 47 478 minecraft:terracotta
fill 472 47 479 472 50 479 minecraft:red_terracotta
fill 473 47 464 473 49 464 minecraft:red_terracotta
fill 473 47 504 475 47 504 minecraft:red_terracotta
setblock 476 47 464 minecraft:terracotta
setblock 476 47 503 minecraft:red_terracotta
setblock 476 47 504 minecraft:terracotta
fill 477 47 464 477 49 465 minecraft:red_terracotta
setblock 477 47 502 minecraft:red_terracotta
setblock 477 47 503 minecraft:terracotta
fill 477 47 504 477 50 504 minecraft:red_terracotta
setblock 478 47 502 minecraft:terracotta
fill 478 47 503 478 50 503 minecraft:red_terracotta
setblock 479 47 501 minecraft:terracotta
fill 479 47 502 482 47 502 minecraft:red_terracotta
setblock 480 47 464 minecraft:red_terracotta
setblock 480 47 465 minecraft:terracotta
fill 480 47 501 483 47 501 minecraft:red_terracotta
setblock 481 47 464 minecraft:terracotta
fill 481 47 465 481 50 465 minecraft:red_terracotta
setblock 481 47 504 minecraft:terracotta
fill 482 47 464 482 50 464 minecraft:red_terracotta
setblock 482 47 503 minecraft:terracotta
fill 482 47 504 482 50 504 minecraft:red_terracotta
setblock 483 47 502 minecraft:terracotta
fill 483 47 503 483 50 503 minecraft:red_terracotta
setblock 484 47 501 minecraft:terracotta
fill 484 47 502 484 50 502 minecraft:red_terracotta
fill 485 47 501 486 49 501 minecraft:red_terracotta
setblock 486 47 464 minecraft:terracotta
setblock 486 47 504 minecraft:terracotta
fill 487 47 464 487 48 464 minecraft:red_terracotta
setblock 487 47 503 minecraft:terracotta
fill 487 47 504 487 50 504 minecraft:red_terracotta
setblock 488 47 502 minecraft:terracotta
fill 488 47 503 488 50 503 minecraft:red_terracotta
setblock 491 47 503 minecraft:red_terracotta
setblock 491 47 504 minecraft:terracotta
fill 492 47 504 495 47 504 minecraft:red_terracotta
fill 495 47 503 496 47 503 minecraft:red_terracotta
setblock 496 47 504 minecraft:terracotta
setblock 497 47 503 minecraft:terracotta
fill 497 47 504 497 50 504 minecraft:red_terracotta
setblock 498 47 502 minecraft:terracotta
fill 498 47 503 501 47 503 minecraft:red_terracotta
fill 499 47 502 500 49 502 minecraft:red_terracotta
setblock 500 47 504 minecraft:red_terracotta
setblock 501 47 464 minecraft:terracotta
setblock 501 47 504 minecraft:terracotta
fill 502 47 464 504 48 464 minecraft:red_terracotta
setblock 502 47 502 minecraft:red_terracotta
setblock 502 47 503 minecraft:terracotta
fill 502 47 504 502 50 504 minecraft:red_terracotta
setblock 503 47 502 minecraft:terracotta
fill 503 47 503 503 50 503 minecraft:red_terracotta
fill 505 47 503 505 48 503 minecraft:red_terracotta
setblock 506 47 504 minecraft:terracotta
setblock 509 47 475 minecraft:red_terracotta
setblock 509 47 476 minecraft:terracotta
fill 509 47 477 509 49 477 minecraft:red_terracotta
setblock 509 47 480 minecraft:red_terracotta
setblock 510 47 475 minecraft:terracotta
fill 510 47 476 510 50 476 minecraft:red_terracotta
setblock 510 47 479 minecraft:red_terracotta
setblock 510 47 480 minecraft:terracotta
fill 510 47 481 510 49 482 minecraft:red_terracotta
fill 511 47 470 511 48 470 minecraft:red_terracotta
setblock 511 47 474 minecraft:terracotta
fill 511 47 475 511 50 475 minecraft:red_terracotta
setblock 511 47 479 minecraft:terracotta
fill 511 47 480 511 50 480 minecraft:red_terracotta
setblock 511 47 484 minecraft:terracotta
setblock 511 47 495 minecraft:red_terracotta
setblock 511 47 499 minecraft:terracotta
fill 471 48 464 472 50 464 minecraft:red_terracotta
setblock 471 48 468 minecraft:terracotta
fill 471 48 469 471 49 469 minecraft:red_terracotta
setblock 471 48 473 minecraft:terracotta
fill 471 48 474 471 51 474 minecraft:red_terracotta
setblock 471 48 478 minecraft:terracotta
fill 471 48 479 471 51 479 minecraft:red_terracotta
setblock 471 48 482 minecraft:red_terracotta
setblock 471 48 497 minecraft:red_terracotta
setblock 471 48 498 minecraft:terracotta
fill 471 48 499 471 51 499 minecraft:red_terracotta
setblock 471 48 502 minecraft:red_terracotta
setblock 471 48 503 minecraft:terracotta
setblock 472 48 472 minecraft:terracotta
fill 472 48 473 472 49 473 minecraft:red_terracotta
setblock 472 48 477 minecraft:terracotta
fill 472 48 478 472 50 478 minecraft:red_terracotta
fill 472 48 504 474 48 504 minecraft:red_terracotta
setblock 474 48 464 minecraft:red_terracotta
fill 474 48 503 475 48 503 minecraft:red_terracotta
setblock 475 48 464 minecraft:terracotta
setblock 475 48 504 minecraft:terracotta
fill 476 48 464 476 50 465 minecraft:red_terracotta
setblock 476 48 502 minecraft:red_terracotta
setblock 476 48 503 minecraft:terracotta
fill 476 48 504 476 51 504 minecraft:red_terracotta
setblock 477 48 502 minecraft:terracotta
fill 477 48 503 477 51 503 minecraft:red_terracotta
setblock 478 48 501 minecraft:terracotta
fill 478 48 502 481 48 502 minecraft:red_terracotta
setblock 479 48 464 minecraft:red_terracotta
setblock 479 48 465 minecraft:terracotta
fill 479 48 501 482 48 501 minecraft:red_terracotta
setblock 480 48 464 minecraft:terracotta
fill 480 48 465 480 51 465 minecraft:red_terracotta
setblock 480 48 504 minecraft:terracotta
fill 481 48 464 481 51 464 minecraft:red_terracotta
setblock 481 48 503 minecraft:terracotta
fill 481 48 504 481 51 504 minecraft:red_terracotta
setblock 482 48 500 minecraft:red_terracotta
setblock 482 48 502 minecraft:terracotta
fill 482 48 503 482 51 503 minecraft:red_terracotta
setblock 483 48 501 minecraft:terracotta
fill 483 48 502 483 51 502 minecraft:red_terracotta
setblock 484 48 465 minecraft:terracotta
fill 484 48 501 484 51 501 minecraft:red_terracotta
setblock 485 48 464 minecraft:terracotta
setblock 485 48 504 minecraft:terracotta
fill 486 48 464 486 50 464 minecraft:red_terracotta
setblock 486 48 502 minecraft:red_terracotta
setblock 486 48 503 minecraft:terracotta
fill 486 48 504 486 51 504 minecraft:red_terracotta
setblock 487 48 502 minecraft:terracotta
fill 487 48 503 487 51 503 minecraft:red_terracotta
fill 488 48 502 488 50 502 minecraft:red_terracotta
setblock 490 48 504 minecraft:terracotta
setblock 491 48 503 minecraft:terracotta
fill 491 48 504 494 48 504 minecraft:red_terracotta
fill 492 48 503 495 48 503 minecraft:red_terracotta
setblock 495 48 504 minecraft:terracotta
setblock 496 48 502 minecraft:red_terracotta
setblock 496 48 503 minecraft:terracotta
fill 496 48 504 496 51 504 minecraft:red_terracotta
setblock 497 48 502 minecraft:terracotta
fill 497 48 503 500 48 503 minecraft:red_terracotta
fill 498 48 502 498 51 502 minecraft:red_terracotta
setblock 499 48 464 minecraft:red_terracotta
setblock 500 48 464 minecraft:terracotta
setblock 500 48 504 minecraft:terracotta
fill 501 48 464 501 51 464 minecraft:red_terracotta
setblock 501 48 503 minecraft:terracotta
fill 501 48 504 501 51 504 minecraft:red_terracotta
setblock 502 48 502 minecraft:terracotta
fill 502 48 503 502 51 503 minecraft:red_terracotta
fill 503 48 502 503 49 502 minecraft:red_terracotta
setblock 505 48 504 minecraft:terracotta
fill 506 48 504 506 50 504 minecraft:red_terracotta
setblock 509 48 475 minecraft:terracotta
fill 509 48 476 509 49 476 minecraft:red_terracotta
setblock 509 48 480 minecraft:terracotta
setblock 510 48 474 minecraft:terracotta
fill 510 48 475 510 51 475 minecraft:red_terracotta
setblock 510 48 479 minecraft:terracotta
fill 510 48 480 510 51 480 minecraft:red_terracotta
setblock 511 48 473 minecraft:terracotta
fill 511 48 474 511 51 474 minecraft:red_terracotta
setblock 511 48 478 minecraft:terracotta
fill 511 48 479 511 51 479 minecraft:red_terracotta
setblock 511 48 482 minecraft:red_terracotta
setblock 511 48 483 minecraft:terracotta
fill 511 48 484 511 51 484 minecraft:red_terracotta
setblock 511 48 497 minecraft:red_terracotta
setblock 511 48 498 minecraft:terracotta
fill 511 48 499 511 48 500 minecraft:red_terracotta
fill 471 49 465 471 49 466 minecraft:red_terracotta
setblock 471 49 468 minecraft:red_terracotta
setblock 471 49 472 minecraft:terracotta
fill 471 49 473 471 51 473 minecraft:red_terracotta
setblock 471 49 477 minecraft:terracotta
fill 471 49 478 471 52 478 minecraft:red_terracotta
setblock 471 49 482 minecraft:terracotta
fill 471 49 498 471 50 498 minecraft:red_terracotta
setblock 471 49 502 minecraft:terracotta
fill 471 49 503 471 51 504 minecraft:red_terracotta
setblock 472 49 476 minecraft:terracotta
fill 472 49 477 472 50 477 minecraft:red_terracotta
fill 472 49 504 473 49 504 minecraft:red_terracotta
fill 473 49 503 474 49 503 minecraft:red_terracotta
setblock 474 49 464 minecraft:terracotta
setblock 474 49 504 minecraft:terracotta
fill 475 49 464 475 51 465 minecraft:red_terracotta
setblock 475 49 502 minecraft:red_terracotta
setblock 475 49 503 minecraft:terracotta
fill 475 49 504 475 52 504 minecraft:red_terracotta
setblock 476 49 502 minecraft:terracotta
fill 476 49 503 476 52 503 minecraft:red_terracotta
fill 477 49 502 480 49 502 minecraft:red_terracotta
setblock 478 49 464 minecraft:red_terracotta
setblock 478 49 465 minecraft:terracotta
fill 478 49 501 481 49 501 minecraft:red_terracotta
setblock 479 49 464 minecraft:terracotta
fill 479 49 465 479 52 465 minecraft:red_terracotta
setblock 479 49 504 minecraft:terracotta
fill 480 49 464 480 52 464 minecraft:red_terracotta
setblock 480 49 503 minecraft:terracotta
fill 480 49 504 480 52 504 minecraft:red_terracotta
setblock 481 49 502 minecraft:terracotta
fill 481 49 503 481 52 503 minecraft:red_terracotta
setblock 482 49 501 minecraft:terracotta
fill 482 49 502 482 52 502 minecraft:red_terracotta
setblock 483 49 465 minecraft:terracotta
fill 483 49 501 483 51 501 minecraft:red_terracotta
setblock 484 49 464 minecraft:terracotta
setblock 484 49 504 minecraft:terracotta
fill 485 49 464 485 52 464 minecraft:red_terracotta
setblock 485 49 503 minecraft:terracotta
fill 485 49 504 485 52 504 minecraft:red_terracotta
setblock 486 49 502 minecraft:terracotta
fill 486 49 503 486 52 503 minecraft:red_terracotta
fill 487 49 502 487 51 502 minecraft:red_terracotta
setblock 489 49 503 minecraft:red_terracotta
setblock 489 49 504 minecraft:terracotta
setblock 490 49 503 minecraft:terracotta
fill 490 49 504 493 49 504 minecraft:red_terracotta
fill 491 49 503 494 49 503 minecraft:red_terracotta
setblock 494 49 504 minecraft:terracotta
setblock 495 49 502 minecraft:red_terracotta
setblock 495 49 503 minecraft:terracotta
fill 495 49 504 495 52 504 minecraft:red_terracotta
setblock 496 49 502 minecraft:terracotta
fill 496 49 503 499 49 503 minecraft:red_terracotta
fill 497 49 502 497 52 502 minecraft:red_terracotta
setblock 498 49 464 minecraft:red_terracotta
setblock 499 49 464 minecraft:terracotta
setblock 499 49 504 minecraft:terracotta
fill 500 49 464 500 52 464 minecraft:red_terracotta
setblock 500 49 503 minecraft:terracotta
fill 500 49 504 500 52 504 minecraft:red_terracotta
setblock 501 49 502 minecraft:terracotta
fill 501 49 503 501 52 503 minecraft:red_terracotta
fill 502 49 464 503 49 464 minecraft:red_terracotta
fill 502 49 502 502 50 502 minecraft:red_terracotta
setblock 504 49 464 minecraft:terracotta
setblock 504 49 504 minecraft:terracotta
fill 505 49 504 505 51 504 minecraft:red_terracotta
setblock 509 49 478 minecraft:red_terracotta
setblock 509 49 479 minecraft:terracotta
setblock 509 49 480 minecraft:red_terracotta
setblock 510 49 473 minecraft:terracotta
fill 510 49 474 510 50 474 minecraft:red_terracotta
setblock 510 49 478 minecraft:terracotta
fill 510 49 479 510 52 479 minecraft:red_terracotta
setblock 511 49 472 minecraft:terracotta
fill 511 49 473 511 52 473 minecraft:red_terracotta
setblock 511 49 477 minecraft:terracotta
fill 511 49 478 511 52 478 minecraft:red_terracotta
setblock 511 49 482 minecraft:terracotta
fill 511 49 483 511 52 483 minecraft:red_terracotta
setblock 471 50 465 minecraft:red_terracotta
setblock 471 50 466 minecraft:terracotta
setblock 471 50 471 minecraft:terracotta
fill 471 50 472 471 51 472 minecraft:red_terracotta
setblock 471 50 476 minecraft:terracotta
fill 471 50 477 471 53 477 minecraft:red_terracotta
setblock 471 50 481 minecraft:terracotta
fill 471 50 482 471 52 482 minecraft:red_terracotta
setblock 471 50 500 minecraft:red_terracotta
setblock 471 50 501 minecraft:terracotta
fill 471 50 502 471 53 502 minecraft:red_terracotta
setblock 472 50 475 minecraft:terracotta
setblock 472 50 476 minecraft:red_terracotta
setblock 472 50 504 minecraft:red_terracotta
setblock 473 50 464 minecraft:terracotta
setblock 473 50 503 minecraft:red_terracotta
setblock 473 50 504 minecraft:terracotta
fill 474 50 464 474 53 464 minecraft:red_terracotta
setblock 474 50 503 minecraft:terracotta
fill 474 50 504 474 53 504 minecraft:red_terracotta
setblock 475 50 502 minecraft:terracotta
fill 475 50 503 475 53 503 minecraft:red_terracotta
fill 476 50 502 479 50 502 minecraft:red_terracotta
setblock 477 50 464 minecraft:red_terracotta
setblock 477 50 465 minecraft:terracotta
fill 477 50 501 480 50 501 minecraft:red_terracotta
setblock 478 50 464 minecraft:terracotta
fill 478 50 465 478 53 465 minecraft:red_terracotta
setblock 478 50 504 minecraft:terracotta
fill 479 50 464 479 53 464 minecraft:red_terracotta
setblock 479 50 503 minecraft:terracotta
fill 479 50 504 479 53 504 minecraft:red_terracotta
setblock 480 50 502 minecraft:terracotta
fill 480 50 503 480 53 503 minecraft:red_terracotta
setblock 481 50 501 minecraft:terracotta
fill 481 50 502 481 53 502 minecraft:red_terracotta
setblock 482 50 465 minecraft:terracotta
fill 482 50 501 482 52 501 minecraft:red_terracotta
setblock 483 50 464 minecraft:terracotta
setblock 483 50 465 minecraft:red_terracotta
setblock 483 50 504 minecraft:terracotta
fill 484 50 464 484 53 464 minecraft:red_terracotta
setblock 484 50 503 minecraft:terracotta
fill 484 50 504 484 53 504 minecraft:red_terracotta
setblock 485 50 501 minecraft:red_terracotta
setblock 485 50 502 minecraft:terracotta
fill 485 50 503 485 53 503 minecraft:red_terracotta
fill 486 50 502 486 51 502 minecraft:red_terracotta
setblock 488 50 504 minecraft:terracotta
setblock 489 50 503 minecraft:terracotta
fill 489 50 504 492 50 504 minecraft:red_terracotta
fill 490 50 503 493 50 503 minecraft:red_terracotta
setblock 493 50 504 minecraft:terracotta
setblock 494 50 503 minecraft:terracotta
fill 494 50 504 494 53 504 minecraft:red_terracotta
setblock 495 50 502 minecraft:terracotta
fill 495 50 503 498 50 503 minecraft:red_terracotta
fill 496 50 502 496 52 502 minecraft:red_terracotta
setblock 498 50 464 minecraft:terracotta
setblock 498 50 504 minecraft:terracotta
fill 499 50 464 499 53 464 minecraft:red_terracotta
setblock 499 50 502 minecraft:red_terracotta
setblock 499 50 503 minecraft:terracotta
fill 499 50 504 499 53 504 minecraft:red_terracotta
setblock 500 50 502 minecraft:terracotta
fill 500 50 503 500 53 503 minecraft:red_terracotta
fill 501 50 502 501 51 502 minecraft:red_terracotta
setblock 502 50 464 minecraft:red_terracotta
setblock 503 50 464 minecraft:terracotta
setblock 503 50 504 minecraft:terracotta
setblock 504 50 464 minecraft:red_terracotta
setblock 504 50 503 minecraft:terracotta
fill 504 50 504 504 53 504 minecraft:red_terracotta
setblock 509 50 478 minecraft:terracotta
setblock 509 50 479 minecraft:red_terracotta
setblock 510 50 477 minecraft:terracotta
fill 510 50 478 510 53 478 minecraft:red_terracotta
setblock 510 50 481 minecraft:red_terracotta
setblock 510 50 482 minecraft:terracotta
setblock 511 50 471 minecraft:terracotta
fill 511 50 472 511 51 472 minecraft:red_terracotta
setblock 511 50 476 minecraft:terracotta
fill 511 50 477 511 53 477 minecraft:red_terracotta
setblock 511 50 481 minecraft:terracotta
fill 511 50 482 511 53 482 minecraft:red_terracotta
setblock 471 51 464 minecraft:red_terracotta
setblock 471 51 465 minecraft:terracotta
fill 471 51 466 471 54 466 minecraft:red_terracotta
setblock 471 51 475 minecraft:terracotta
fill 471 51 476 471 52 476 minecraft:red_terracotta
setblock 471 51 480 minecraft:terracotta
fill 471 51 481 471 54 481 minecraft:red_terracotta
setblock 471 51 500 minecraft:terracotta
fill 471 51 501 471 54 501 minecraft:red_terracotta
setblock 472 51 464 minecraft:terracotta
fill 472 51 502 472 51 503 minecraft:red_terracotta
setblock 472 51 504 minecraft:terracotta
fill 473 51 464 473 54 464 minecraft:red_terracotta
setblock 473 51 503 minecraft:terracotta
fill 473 51 504 473 54 504 minecraft:red_terracotta
fill 474 51 465 474 52 465 minecraft:red_terracotta
fill 474 51 503 474 54 503 minecraft:red_terracotta
fill 475 51 502 478 51 502 minecraft:red_terracotta
setblock 476 51 464 minecraft:red_terracotta
setblock 476 51 465 minecraft:terracotta
setblock 477 51 464 minecraft:terracotta
fill 477 51 465 477 54 465 minecraft:red_terracotta
fill 477 51 501 479 51 501 minecraft:red_terracotta
setblock 477 51 504 minecraft:terracotta
fill 478 51 464 478 54 464 minecraft:red_terracotta
setblock 478 51 503 minecraft:terracotta
fill 478 51 504 478 54 504 minecraft:red_terracotta
setblock 479 51 502 minecraft:terracotta
fill 479 51 503 479 54 503 minecraft:red_terracotta
setblock 480 51 501 minecraft:terracotta
fill 480 51 502 480 54 502 minecraft:red_terracotta
setblock 481 51 465 minecraft:terracotta
fill 481 51 501 481 53 501 minecraft:red_terracotta
setblock 482 51 464 minecraft:terracotta
fill 482 51 465 482 52 465 minecraft:red_terracotta
setblock 482 51 504 minecraft:terracotta
fill 483 51 464 483 54 464 minecraft:red_terracotta
setblock 483 51 503 minecraft:terracotta
fill 483 51 504 483 54 504 minecraft:red_terracotta
setblock 484 51 502 minecraft:terracotta
fill 484 51 503 484 54 503 minecraft:red_terracotta
fill 485 51 502 485 52 502 minecraft:red_terracotta
setblock 487 51 504 minecraft:terracotta
setblock 488 51 503 minecraft:terracotta
fill 488 51 504 491 51 504 minecraft:red_terracotta
fill 489 51 503 492 51 503 minecraft:red_terracotta
setblock 492 51 504 minecraft:terracotta
setblock 493 51 503 minecraft:terracotta
fill 493 51 504 493 54 504 minecraft:red_terracotta
fill 494 51 503 497 51 503 minecraft:red_terracotta
setblock 495 51 502 minecraft:red_terracotta
setblock 497 51 464 minecraft:terracotta
setblock 497 51 504 minecraft:terracotta
fill 498 51 464 498 54 464 minecraft:red_terracotta
setblock 498 51 503 minecraft:terracotta
fill 498 51 504 498 54 504 minecraft:red_terracotta
setblock 499 51 502 minecraft:terracotta
fill 499 51 503 499 54 503 minecraft:red_terracotta
fill 500 51 502 500 52 502 minecraft:red_terracotta
setblock 502 51 464 minecraft:terracotta
setblock 502 51 504 minecraft:terracotta
setblock 503 51 464 minecraft:red_terracotta
setblock 503 51 503 minecraft:terracotta
fill 503 51 504 503 54 504 minecraft:red_terracotta
setblock 510 51 476 minecraft:terracotta
fill 510 51 477 510 52 477 minecraft:red_terracotta
setblock 510 51 481 minecraft:terracotta
fill 510 51 482 510 52 482 minecraft:red_terracotta
setblock 511 51 475 minecraft:terracotta
fill 511 51 476 511 54 476 minecraft:red_terracotta
setblock 511 51 480 minecraft:terracotta
fill 511 51 481 511 54 481 minecraft:red_terracotta
setblock 471 52 464 minecraft:terracotta
fill 471 52 465 471 55 465 minecraft:red_terracotta
setblock 471 52 475 minecraft:red_terracotta
setblock 471 52 479 minecraft:terracotta
fill 471 52 480 471 55 480 minecraft:red_terracotta
fill 471 52 500 471 55 500 minecraft:red_terracotta
setblock 471 52 503 minecraft:red_terracotta
setblock 471 52 504 minecraft:terracotta
fill 472 52 464 472 55 464 minecraft:red_terracotta
setblock 472 52 502 minecraft:red_terracotta
setblock 472 52 503 minecraft:terracotta
fill 472 52 504 472 55 504 minecraft:red_terracotta
fill 473 52 503 473 55 503 minecraft:red_terracotta
fill 474 52 502 477 52 502 minecraft:red_terracotta
setblock 475 52 464 minecraft:red_terracotta
setblock 475 52 465 minecraft:terracotta
setblock 476 52 464 minecraft:terracotta
fill 476 52 465 476 55 465 minecraft:red_terracotta
setblock 476 52 504 minecraft:terracotta
fill 477 52 464 477 55 464 minecraft:red_terracotta
fill 477 52 501 478 52 501 minecraft:red_terracotta
setblock 477 52 503 minecraft:terracotta
fill 477 52 504 477 55 504 minecraft:red_terracotta
setblock 478 52 502 minecraft:terracotta
fill 478 52 503 478 55 503 minecraft:red_terracotta
setblock 479 52 501 minecraft:terracotta
fill 479 52 502 479 55 502 minecraft:red_terracotta
setblock 480 52 465 minecraft:terracotta
fill 480 52 501 480 53 501 minecraft:red_terracotta
setblock 481 52 464 minecraft:terracotta
fill 481 52 465 481 54 465 minecraft:red_terracotta
setblock 481 52 504 minecraft:terracotta
fill 482 52 464 482 55 464 minecraft:red_terracotta
setblock 482 52 503 minecraft:terracotta
fill 482 52 504 482 55 504 minecraft:red_terracotta
setblock 483 52 502 minecraft:terracotta
fill 483 52 503 483 55 503 minecraft:red_terracotta
fill 484 52 502 484 53 502 minecraft:red_terracotta
setblock 486 52 504 minecraft:terracotta
setblock 487 52 503 minecraft:terracotta
fill 487 52 504 490 52 504 minecraft:red_terracotta
fill 488 52 503 491 52 503 minecraft:red_terracotta
setblock 491 52 504 minecraft:terracotta
setblock 492 52 503 minecraft:terracotta
fill 492 52 504 492 55 504 minecraft:red_terracotta
fill 493 52 503 496 52 503 minecraft:red_terracotta
setblock 496 52 504 minecraft:terracotta
fill 497 52 464 497 55 464 minecraft:red_terracotta
setblock 497 52 503 minecraft:terracotta
fill 497 52 504 497 55 504 minecraft:red_terracotta
setblock 498 52 502 minecraft:terracotta
fill 498 52 503 498 55 503 minecraft:red_terracotta
setblock 499 52 502 minecraft:red_terracotta
setblock 501 52 464 minecraft:terracotta
setblock 501 52 504 minecraft:terracotta
fill 502 52 464 502 55 464 minecraft:red_terracotta
setblock 502 52 503 minecraft:terracotta
fill 502 52 504 502 55 504 minecraft:red_terracotta
setblock 510 52 480 minecraft:terracotta
fill 510 52 481 510 53 481 minecraft:red_terracotta
setblock 511 52 474 minecraft:terracotta
fill 511 52 475 511 54 475 minecraft:red_terracotta
setblock 511 52 479 minecraft:terracotta
fill 511 52 480 511 55 480 minecraft:red_terracotta
setblock 511 52 484 minecraft:terracotta
fill 471 53 464 471 56 464 minecraft:red_terracotta
setblock 471 53 478 minecraft:terracotta
fill 471 53 479 471 54 479 minecraft:red_terracotta
setblock 471 53 503 minecraft:terracotta
fill 471 53 504 471 56 504 minecraft:red_terracotta
setblock 472 53 502 minecraft:terracotta
fill 472 53 503 472 56 503 minecraft:red_terracotta
setblock 473 53 465 minecraft:red_terracotta
setblock 474 53 465 minecraft:terracotta
fill 474 53 502 476 53 502 minecraft:red_terracotta
setblock 475 53 464 minecraft:terracotta
fill 475 53 465 475 56 465 minecraft:red_terracotta
setblock 475 53 504 minecraft:terracotta
fill 476 53 464 476 56 464 minecraft:red_terracotta
setblock 476 53 503 minecraft:terracotta
fill 476 53 504 476 56 504 minecraft:red_terracotta
setblock 477 53 502 minecraft:terracotta
fill 477 53 503 477 56 503 minecraft:red_terracotta
setblock 478 53 501 minecraft:terracotta
fill 478 53 502 478 56 502 minecraft:red_terracotta
setblock 479 53 465 minecraft:terracotta
setblock 479 53 501 minecraft:red_terracotta
setblock 480 53 464 minecraft:terracotta
fill 480 53 465 480 56 465 minecraft:red_terracotta
setblock 480 53 504 minecraft:terracotta
fill 481 53 464 481 56 464 minecraft:red_terracotta
setblock 481 53 503 minecraft:terracotta
fill 481 53 504 481 56 504 minecraft:red_terracotta
setblock 482 53 502 minecraft:terracotta
fill 482 53 503 482 56 503 minecraft:red_terracotta
fill 483 53 502 483 54 502 minecraft:red_terracotta
setblock 485 53 504 minecraft:terracotta
setblock 486 53 503 minecraft:terracotta
fill 486 53 504 489 53 504 minecraft:red_terracotta
fill 487 53 503 488 53 503 minecraft:red_terracotta
setblock 490 53 504 minecraft:terracotta
fill 491 53 504 491 56 504 minecraft:red_terracotta
fill 492 53 503 495 53 503 minecraft:red_terracotta
setblock 495 53 504 minecraft:terracotta
fill 496 53 464 496 56 464 minecraft:red_terracotta
setblock 496 53 503 minecraft:terracotta
fill 496 53 504 496 56 504 minecraft:red_terracotta
setblock 497 53 502 minecraft:terracotta
fill 497 53 503 497 56 503 minecraft:red_terracotta
setblock 500 53 464 minecraft:terracotta
setblock 500 53 504 minecraft:terracotta
fill 501 53 464 501 56 464 minecraft:red_terracotta
setblock 501 53 503 minecraft:terracotta
fill 501 53 504 501 56 504 minecraft:red_terracotta
setblock 510 53 479 minecraft:terracotta
setblock 510 53 480 minecraft:red_terracotta
setblock 511 53 474 minecraft:red_terracotta
setblock 511 53 478 minecraft:terracotta
fill 511 53 479 511 56 479 minecraft:red_terracotta
setblock 511 53 483 minecraft:terracotta
fill 511 53 484 511 56 484 minecraft:red_terracotta
setblock 471 54 467 minecraft:terracotta
setblock 471 54 502 minecraft:terracotta
fill 471 54 503 471 57 503 minecraft:red_terracotta
setblock 472 54 465 minecraft:red_terracotta
fill 472 54 502 472 57 502 minecraft:red_terracotta
setblock 473 54 465 minecraft:terracotta
setblock 473 54 466 minecraft:light[level=14]
setblock 473 54 474 minecraft:light[level=14]
setblock 473 54 482 minecraft:light[level=14]
setblock 473 54 490 minecraft:light[level=14]
setblock 473 54 498 minecraft:light[level=14]
setblock 474 54 464 minecraft:terracotta
fill 474 54 465 474 57 465 minecraft:red_terracotta
fill 474 54 502 475 54 502 minecraft:red_terracotta
setblock 474 54 504 minecraft:terracotta
fill 475 54 464 475 57 464 minecraft:red_terracotta
setblock 475 54 503 minecraft:terracotta
schedule function dropper:buildpart/118_2 1t
