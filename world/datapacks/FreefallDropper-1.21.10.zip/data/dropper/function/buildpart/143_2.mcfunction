fill 521 264 557 521 269 557 minecraft:black_concrete
fill 523 264 557 523 284 557 minecraft:black_concrete
setblock 524 264 557 minecraft:white_concrete
fill 531 264 599 531 269 599 minecraft:black_concrete
fill 537 264 557 537 269 557 minecraft:black_concrete
setblock 540 264 557 minecraft:sea_lantern
fill 547 264 599 547 269 599 minecraft:black_concrete
fill 553 264 557 553 269 557 minecraft:black_concrete
fill 559 264 564 559 271 565 minecraft:black_concrete
setblock 559 264 566 minecraft:white_stained_glass
fill 559 264 567 559 269 567 minecraft:black_concrete
fill 559 264 583 559 269 583 minecraft:black_concrete
setblock 559 264 585 minecraft:sea_lantern
fill 559 264 593 559 277 593 minecraft:black_concrete
setblock 517 265 582 minecraft:white_concrete
fill 524 265 557 524 272 557 minecraft:black_concrete
fill 524 265 599 526 286 599 minecraft:black_concrete
setblock 525 265 557 minecraft:white_concrete
setblock 527 265 599 minecraft:white_concrete
fill 540 265 557 540 307 557 minecraft:black_concrete
fill 559 265 566 559 279 566 minecraft:black_concrete
fill 559 265 585 559 287 585 minecraft:black_concrete
fill 517 266 582 517 278 582 minecraft:black_concrete
setblock 517 266 593 minecraft:sea_lantern
fill 525 266 557 525 307 557 minecraft:black_concrete
fill 527 266 599 527 307 599 minecraft:black_concrete
setblock 559 266 588 minecraft:white_stained_glass
setblock 559 266 595 minecraft:white_concrete
setblock 517 267 567 minecraft:white_stained_glass
fill 517 267 568 517 307 568 minecraft:black_concrete
fill 517 267 593 517 288 593 minecraft:black_concrete
setblock 559 267 579 minecraft:sea_lantern
fill 559 267 588 559 296 588 minecraft:black_concrete
fill 559 267 595 559 307 595 minecraft:black_concrete
fill 517 268 567 517 307 567 minecraft:black_concrete
setblock 517 268 587 minecraft:sea_lantern
setblock 517 268 590 minecraft:white_stained_glass
fill 517 268 594 517 307 595 minecraft:black_concrete
setblock 517 268 596 minecraft:sea_lantern
setblock 520 268 560 minecraft:light[level=14]
setblock 520 268 568 minecraft:light[level=14]
setblock 520 268 576 minecraft:light[level=14]
setblock 520 268 584 minecraft:light[level=14]
setblock 520 268 592 minecraft:light[level=14]
setblock 528 268 560 minecraft:light[level=14]
setblock 528 268 568 minecraft:light[level=14]
setblock 528 268 576 minecraft:light[level=14]
setblock 528 268 584 minecraft:light[level=14]
setblock 528 268 592 minecraft:light[level=14]
setblock 536 268 560 minecraft:light[level=14]
setblock 536 268 568 minecraft:light[level=14]
setblock 536 268 584 minecraft:light[level=14]
setblock 536 268 592 minecraft:light[level=14]
setblock 544 268 560 minecraft:light[level=14]
setblock 544 268 568 minecraft:light[level=14]
setblock 544 268 576 minecraft:light[level=14]
setblock 544 268 584 minecraft:light[level=14]
setblock 544 268 592 minecraft:light[level=14]
setblock 552 268 557 minecraft:white_stained_glass
setblock 552 268 560 minecraft:light[level=14]
setblock 552 268 568 minecraft:light[level=14]
setblock 552 268 576 minecraft:light[level=14]
setblock 552 268 584 minecraft:light[level=14]
setblock 552 268 592 minecraft:light[level=14]
fill 559 268 579 559 307 579 minecraft:black_concrete
setblock 559 268 597 minecraft:white_stained_glass
fill 559 268 598 559 307 598 minecraft:black_concrete
fill 517 269 587 517 307 587 minecraft:black_concrete
fill 517 269 590 517 292 591 minecraft:black_concrete
setblock 517 269 592 minecraft:white_stained_glass
fill 517 269 596 517 283 596 minecraft:black_concrete
setblock 536 269 557 minecraft:white_stained_glass
fill 552 269 557 552 271 557 minecraft:black_concrete
fill 559 269 597 559 282 597 minecraft:black_concrete
fill 517 270 565 517 273 565 minecraft:white_concrete
fill 517 270 566 517 307 566 minecraft:black_concrete
fill 517 270 581 517 272 581 minecraft:white_concrete
fill 517 270 592 517 307 592 minecraft:black_concrete
fill 517 270 597 517 272 597 minecraft:white_concrete
fill 521 270 557 521 272 557 minecraft:white_concrete
fill 531 270 599 531 272 599 minecraft:white_concrete
fill 536 270 557 536 303 557 minecraft:black_concrete
fill 537 270 557 537 272 557 minecraft:white_concrete
fill 547 270 599 547 272 599 minecraft:white_concrete
fill 553 270 557 553 272 557 minecraft:white_concrete
fill 559 270 567 559 272 567 minecraft:white_concrete
fill 559 270 583 559 272 583 minecraft:white_concrete
setblock 559 270 591 minecraft:sea_lantern
setblock 556 271 599 minecraft:sea_lantern
fill 559 271 591 559 297 591 minecraft:black_concrete
setblock 552 272 557 minecraft:white_concrete
fill 556 272 599 556 307 599 minecraft:black_concrete
fill 559 272 564 559 286 564 minecraft:black_concrete
setblock 559 272 565 minecraft:white_stained_glass
setblock 559 272 587 minecraft:white_stained_glass
setblock 517 273 579 minecraft:white_stained_glass
fill 517 273 581 517 287 581 minecraft:black_concrete
fill 517 273 597 517 287 597 minecraft:black_concrete
fill 521 273 557 521 279 557 minecraft:black_concrete
setblock 524 273 557 minecraft:white_stained_glass
fill 531 273 599 531 287 599 minecraft:black_concrete
fill 537 273 557 537 287 557 minecraft:black_concrete
fill 547 273 599 547 287 599 minecraft:black_concrete
fill 552 273 557 553 274 557 minecraft:black_concrete
setblock 559 273 558 minecraft:white_concrete
fill 559 273 565 559 276 565 minecraft:black_concrete
fill 559 273 567 559 287 567 minecraft:black_concrete
fill 559 273 583 559 287 583 minecraft:black_concrete
fill 559 273 587 559 285 587 minecraft:black_concrete
setblock 559 273 596 minecraft:white_stained_glass
fill 517 274 557 517 307 557 minecraft:black_concrete
setblock 517 274 558 minecraft:white_stained_glass
fill 517 274 559 517 307 559 minecraft:black_concrete
fill 517 274 565 517 287 565 minecraft:black_concrete
fill 517 274 579 517 283 579 minecraft:black_concrete
setblock 521 274 599 minecraft:white_concrete
fill 524 274 557 524 307 557 minecraft:black_concrete
fill 559 274 558 559 298 558 minecraft:black_concrete
fill 559 274 596 559 307 596 minecraft:black_concrete
fill 517 275 558 517 297 558 minecraft:black_concrete
fill 517 275 569 517 281 571 minecraft:black_concrete
setblock 517 275 572 minecraft:white_stained_glass
fill 518 275 599 518 307 599 minecraft:black_concrete
setblock 519 275 599 minecraft:white_concrete
fill 520 275 599 521 282 599 minecraft:black_concrete
setblock 536 275 599 minecraft:white_stained_glass
fill 539 275 599 539 307 599 minecraft:black_concrete
setblock 540 275 599 minecraft:sea_lantern
setblock 541 275 599 minecraft:black_concrete
fill 548 275 599 548 307 599 minecraft:black_concrete
setblock 549 275 599 minecraft:sea_lantern
setblock 552 275 557 minecraft:white_stained_glass
fill 553 275 557 553 287 557 minecraft:black_concrete
setblock 559 275 562 minecraft:white_concrete
fill 517 276 572 517 286 572 minecraft:black_concrete
setblock 519 276 557 minecraft:white_stained_glass
fill 519 276 599 519 304 599 minecraft:black_concrete
fill 520 276 557 520 301 557 minecraft:black_concrete
setblock 520 276 560 minecraft:light[level=14]
setblock 520 276 568 minecraft:light[level=14]
setblock 520 276 576 minecraft:light[level=14]
setblock 520 276 584 minecraft:light[level=14]
setblock 520 276 592 minecraft:light[level=14]
setblock 528 276 560 minecraft:light[level=14]
setblock 528 276 568 minecraft:light[level=14]
setblock 528 276 576 minecraft:light[level=14]
setblock 528 276 584 minecraft:light[level=14]
setblock 528 276 592 minecraft:light[level=14]
setblock 536 276 560 minecraft:light[level=14]
setblock 536 276 568 minecraft:light[level=14]
setblock 536 276 584 minecraft:light[level=14]
setblock 536 276 592 minecraft:light[level=14]
fill 536 276 599 536 301 599 minecraft:black_concrete
setblock 540 276 599 minecraft:black_concrete
setblock 541 276 599 minecraft:white_concrete
setblock 544 276 560 minecraft:light[level=14]
setblock 544 276 568 minecraft:light[level=14]
setblock 544 276 576 minecraft:light[level=14]
setblock 544 276 584 minecraft:light[level=14]
setblock 544 276 592 minecraft:light[level=14]
fill 549 276 599 549 296 599 minecraft:black_concrete
fill 552 276 557 552 307 557 minecraft:black_concrete
setblock 552 276 560 minecraft:light[level=14]
setblock 552 276 568 minecraft:light[level=14]
setblock 552 276 576 minecraft:light[level=14]
setblock 552 276 584 minecraft:light[level=14]
setblock 552 276 592 minecraft:light[level=14]
fill 559 276 562 559 307 562 minecraft:black_concrete
fill 519 277 557 519 307 557 minecraft:black_concrete
fill 526 277 557 526 307 557 minecraft:black_concrete
setblock 527 277 557 minecraft:white_stained_glass
fill 528 277 557 528 307 557 minecraft:black_concrete
setblock 532 277 557 minecraft:sea_lantern
fill 533 277 557 535 285 557 minecraft:black_concrete
setblock 540 277 599 minecraft:white_stained_glass
fill 541 277 599 541 307 599 minecraft:black_concrete
setblock 543 277 557 minecraft:white_concrete
setblock 545 277 599 minecraft:white_stained_glass
setblock 559 277 565 minecraft:white_concrete
fill 527 278 557 527 307 557 minecraft:black_concrete
fill 530 278 575 532 278 577 minecraft:redstone_block
fill 532 278 557 532 307 557 minecraft:black_concrete
fill 536 278 570 538 278 572 minecraft:redstone_block
setblock 537 278 599 minecraft:white_concrete
fill 538 278 579 540 278 581 minecraft:redstone_block
fill 540 278 599 540 307 599 minecraft:black_concrete
fill 543 278 557 543 279 557 minecraft:black_concrete
fill 545 278 599 545 307 599 minecraft:black_concrete
fill 559 278 565 559 280 565 minecraft:black_concrete
setblock 559 278 593 minecraft:white_stained_glass
setblock 517 279 582 minecraft:white_concrete
fill 518 279 558 519 280 582 minecraft:blue_concrete
fill 518 279 583 518 280 583 minecraft:white_concrete
fill 518 279 584 525 280 586 minecraft:blue_concrete
fill 518 279 587 518 280 587 minecraft:white_concrete
fill 518 279 588 520 280 590 minecraft:blue_concrete
fill 518 279 591 518 280 591 minecraft:white_concrete
fill 518 279 592 520 280 598 minecraft:blue_concrete
fill 519 279 583 536 280 583 minecraft:blue_concrete
fill 519 279 587 542 280 587 minecraft:blue_concrete
fill 519 279 591 523 280 591 minecraft:blue_concrete
fill 520 279 558 521 280 565 minecraft:blue_concrete
fill 520 279 566 520 280 566 minecraft:white_concrete
fill 520 279 567 527 280 569 minecraft:blue_concrete
fill 520 279 570 520 280 570 minecraft:white_concrete
fill 520 279 571 522 280 573 minecraft:blue_concrete
fill 520 279 574 520 280 574 minecraft:white_concrete
fill 520 279 575 522 280 582 minecraft:blue_concrete
fill 521 279 566 538 280 566 minecraft:blue_concrete
fill 521 279 570 535 279 570 minecraft:blue_concrete
fill 521 279 574 544 279 574 minecraft:blue_concrete
fill 521 279 588 528 280 588 minecraft:blue_concrete
fill 521 279 589 521 280 589 minecraft:white_concrete
fill 521 279 590 531 280 590 minecraft:blue_concrete
fill 521 279 592 534 280 592 minecraft:blue_concrete
fill 521 279 593 521 280 593 minecraft:white_concrete
fill 521 279 594 523 280 598 minecraft:blue_concrete
fill 522 279 558 524 280 560 minecraft:blue_concrete
fill 522 279 561 522 280 561 minecraft:white_concrete
fill 522 279 562 524 280 565 minecraft:blue_concrete
fill 522 279 589 539 280 589 minecraft:blue_concrete
fill 522 279 593 545 280 593 minecraft:blue_concrete
fill 523 279 561 527 280 561 minecraft:blue_concrete
fill 523 279 571 530 280 571 minecraft:blue_concrete
fill 523 279 572 523 280 572 minecraft:white_concrete
fill 523 279 573 533 280 573 minecraft:blue_concrete
fill 523 279 575 529 279 575 minecraft:blue_concrete
fill 523 279 576 523 280 576 minecraft:white_concrete
fill 523 279 577 525 280 579 minecraft:blue_concrete
fill 523 279 580 523 280 580 minecraft:white_concrete
fill 523 279 581 525 280 582 minecraft:blue_concrete
fill 524 279 572 535 279 572 minecraft:blue_concrete
fill 524 279 576 529 279 576 minecraft:blue_concrete
fill 524 279 580 537 279 580 minecraft:blue_concrete
fill 524 279 591 524 280 591 minecraft:white_concrete
fill 524 279 594 531 280 594 minecraft:blue_concrete
fill 524 279 595 524 280 595 minecraft:white_concrete
fill 524 279 596 526 280 598 minecraft:blue_concrete
fill 525 279 558 532 280 558 minecraft:blue_concrete
fill 525 279 559 525 280 559 minecraft:white_concrete
fill 525 279 560 535 280 560 minecraft:blue_concrete
fill 525 279 562 538 280 562 minecraft:blue_concrete
fill 525 279 563 525 280 563 minecraft:white_concrete
fill 525 279 564 527 280 565 minecraft:blue_concrete
fill 525 279 591 542 280 591 minecraft:blue_concrete
fill 525 279 595 542 280 595 minecraft:blue_concrete
fill 526 279 559 543 280 559 minecraft:blue_concrete
fill 526 279 563 549 280 563 minecraft:blue_concrete
fill 526 279 577 529 279 577 minecraft:blue_concrete
fill 526 279 578 526 280 578 minecraft:white_concrete
fill 526 279 579 536 280 579 minecraft:blue_concrete
fill 526 279 581 533 280 581 minecraft:blue_concrete
fill 526 279 582 526 280 582 minecraft:white_concrete
fill 526 279 584 528 280 585 minecraft:blue_concrete
fill 526 279 586 526 280 586 minecraft:white_concrete
fill 527 279 578 544 279 578 minecraft:blue_concrete
fill 527 279 582 550 279 582 minecraft:blue_concrete
fill 527 279 586 531 280 586 minecraft:blue_concrete
fill 527 279 596 534 280 596 minecraft:blue_concrete
fill 527 279 597 527 280 597 minecraft:white_concrete
fill 527 279 598 537 280 598 minecraft:blue_concrete
fill 528 279 561 528 280 561 minecraft:white_concrete
fill 528 279 564 535 280 564 minecraft:blue_concrete
fill 528 279 565 528 280 565 minecraft:white_concrete
fill 528 279 567 530 280 568 minecraft:blue_concrete
fill 528 279 569 528 280 569 minecraft:white_concrete
fill 528 279 597 545 280 597 minecraft:blue_concrete
fill 529 279 561 546 280 561 minecraft:blue_concrete
fill 529 279 565 546 280 565 minecraft:blue_concrete
fill 529 279 569 552 279 569 minecraft:blue_concrete
fill 529 279 584 529 280 584 minecraft:white_concrete
fill 529 279 585 539 280 585 minecraft:blue_concrete
fill 529 279 588 529 280 588 minecraft:white_concrete
fill 530 279 584 547 280 584 minecraft:blue_concrete
fill 530 279 588 553 280 588 minecraft:blue_concrete
fill 531 279 567 531 280 567 minecraft:white_concrete
fill 531 279 568 541 280 568 minecraft:blue_concrete
fill 531 279 571 531 280 571 minecraft:white_concrete
fill 532 279 567 549 280 567 minecraft:blue_concrete
fill 532 279 571 535 279 571 minecraft:blue_concrete
fill 532 279 586 532 280 586 minecraft:white_concrete
fill 532 279 590 532 280 590 minecraft:white_concrete
fill 532 279 594 532 280 594 minecraft:white_concrete
fill 533 279 558 533 280 558 minecraft:white_concrete
fill 533 279 575 533 279 577 minecraft:blue_concrete
fill 533 279 586 550 280 586 minecraft:blue_concrete
fill 533 279 590 550 280 590 minecraft:blue_concrete
fill 533 279 594 556 280 594 minecraft:blue_concrete
fill 534 279 558 557 280 558 minecraft:blue_concrete
fill 534 279 573 534 280 573 minecraft:white_concrete
fill 534 279 575 534 279 576 minecraft:blue_concrete
setblock 534 279 577 minecraft:white_concrete
fill 534 279 581 534 280 581 minecraft:white_concrete
fill 535 279 573 552 279 573 minecraft:blue_concrete
fill 535 279 581 537 279 581 minecraft:blue_concrete
fill 535 279 592 535 280 592 minecraft:white_concrete
fill 535 279 596 535 280 596 minecraft:white_concrete
fill 536 279 560 536 280 560 minecraft:white_concrete
fill 536 279 564 536 280 564 minecraft:white_concrete
fill 536 279 592 553 280 592 minecraft:blue_concrete
fill 536 279 596 558 280 596 minecraft:blue_concrete
fill 537 279 560 554 280 560 minecraft:blue_concrete
fill 537 279 564 558 280 564 minecraft:blue_concrete
setblock 537 279 579 minecraft:white_concrete
fill 537 279 583 537 280 583 minecraft:white_concrete
fill 537 279 599 537 307 599 minecraft:black_concrete
fill 538 279 575 541 279 577 minecraft:blue_concrete
fill 538 279 583 558 280 583 minecraft:blue_concrete
fill 538 279 598 538 280 598 minecraft:white_concrete
fill 539 279 562 539 280 562 minecraft:white_concrete
fill 539 279 566 539 280 566 minecraft:white_concrete
setblock 539 279 570 minecraft:white_concrete
fill 539 279 571 541 279 572 minecraft:blue_concrete
fill 539 279 598 556 280 598 minecraft:blue_concrete
fill 540 279 562 557 280 562 minecraft:blue_concrete
fill 540 279 566 557 280 566 minecraft:blue_concrete
fill 540 279 570 558 280 570 minecraft:blue_concrete
fill 540 279 585 540 280 585 minecraft:white_concrete
fill 540 279 589 540 280 589 minecraft:white_concrete
fill 541 279 579 547 279 581 minecraft:blue_concrete
fill 541 279 585 558 280 585 minecraft:blue_concrete
fill 541 279 589 558 280 589 minecraft:blue_concrete
fill 542 279 568 542 280 568 minecraft:white_concrete
fill 542 279 571 549 280 571 minecraft:blue_concrete
fill 542 279 572 542 280 572 minecraft:white_concrete
fill 542 279 575 555 280 575 minecraft:blue_concrete
fill 542 279 576 542 280 576 minecraft:white_concrete
fill 542 279 577 558 280 577 minecraft:blue_concrete
fill 543 279 568 558 280 568 minecraft:blue_concrete
fill 543 279 572 558 280 572 minecraft:blue_concrete
fill 543 279 576 547 280 576 minecraft:blue_concrete
fill 543 279 587 543 280 587 minecraft:white_concrete
fill 543 279 591 543 280 591 minecraft:white_concrete
fill 543 279 595 543 280 595 minecraft:white_concrete
fill 544 279 559 544 280 559 minecraft:white_concrete
fill 544 279 587 558 280 587 minecraft:blue_concrete
fill 544 279 591 558 280 591 minecraft:blue_concrete
fill 544 279 595 548 280 595 minecraft:blue_concrete
fill 545 279 559 558 280 559 minecraft:blue_concrete
fill 545 279 574 545 280 574 minecraft:white_concrete
fill 545 279 578 545 280 578 minecraft:white_concrete
fill 546 279 574 558 280 574 minecraft:blue_concrete
fill 546 279 578 558 280 578 minecraft:blue_concrete
fill 546 279 593 546 280 593 minecraft:white_concrete
fill 546 279 597 546 280 597 minecraft:white_concrete
fill 547 279 561 547 280 561 minecraft:white_concrete
fill 547 279 565 547 280 565 minecraft:white_concrete
fill 547 279 593 558 280 593 minecraft:blue_concrete
fill 547 279 597 558 280 597 minecraft:blue_concrete
fill 548 279 561 558 280 561 minecraft:blue_concrete
fill 548 279 565 558 280 565 minecraft:blue_concrete
fill 548 279 576 548 280 576 minecraft:white_concrete
fill 548 279 579 555 280 579 minecraft:blue_concrete
fill 548 279 580 548 280 580 minecraft:white_concrete
fill 548 279 581 558 280 581 minecraft:blue_concrete
fill 548 279 584 548 280 584 minecraft:white_concrete
fill 549 279 576 558 280 576 minecraft:blue_concrete
fill 549 279 580 558 280 580 minecraft:blue_concrete
fill 549 279 584 558 280 584 minecraft:blue_concrete
fill 549 279 595 549 280 595 minecraft:white_concrete
fill 550 279 563 550 280 563 minecraft:white_concrete
fill 550 279 567 550 280 567 minecraft:white_concrete
fill 550 279 571 550 280 571 minecraft:white_concrete
fill 550 279 595 558 280 595 minecraft:blue_concrete
fill 551 279 563 558 280 563 minecraft:blue_concrete
fill 551 279 567 558 280 567 minecraft:blue_concrete
fill 551 279 571 555 280 571 minecraft:blue_concrete
fill 551 279 582 551 280 582 minecraft:white_concrete
fill 551 279 586 551 280 586 minecraft:white_concrete
fill 551 279 590 551 280 590 minecraft:white_concrete
fill 552 279 582 558 280 582 minecraft:blue_concrete
fill 552 279 586 558 280 586 minecraft:blue_concrete
fill 552 279 590 556 280 590 minecraft:blue_concrete
fill 553 279 569 553 280 569 minecraft:white_concrete
fill 553 279 573 553 280 573 minecraft:white_concrete
fill 554 279 569 558 280 569 minecraft:blue_concrete
fill 554 279 573 558 280 573 minecraft:blue_concrete
fill 554 279 588 554 280 588 minecraft:white_concrete
fill 554 279 592 554 280 592 minecraft:white_concrete
fill 555 279 560 555 280 560 minecraft:white_concrete
fill 555 279 588 558 280 588 minecraft:blue_concrete
fill 555 279 592 558 280 592 minecraft:blue_concrete
fill 556 279 560 558 280 560 minecraft:blue_concrete
fill 556 279 571 556 280 571 minecraft:white_concrete
fill 556 279 575 556 280 575 minecraft:white_concrete
fill 556 279 579 556 280 579 minecraft:white_concrete
fill 557 279 571 558 280 571 minecraft:blue_concrete
fill 557 279 575 558 280 575 minecraft:blue_concrete
fill 557 279 579 558 280 579 minecraft:blue_concrete
fill 557 279 590 557 280 590 minecraft:white_concrete
fill 557 279 594 557 280 594 minecraft:white_concrete
fill 557 279 598 557 280 598 minecraft:white_concrete
fill 558 279 558 558 280 558 minecraft:white_concrete
fill 558 279 562 558 280 562 minecraft:white_concrete
fill 558 279 566 558 280 566 minecraft:white_concrete
fill 558 279 590 558 280 590 minecraft:blue_concrete
fill 558 279 594 558 280 594 minecraft:blue_concrete
fill 558 279 598 558 280 598 minecraft:blue_concrete
fill 559 279 593 559 307 593 minecraft:black_concrete
setblock 517 280 573 minecraft:white_stained_glass
fill 517 280 582 517 307 582 minecraft:black_concrete
setblock 521 280 557 minecraft:white_stained_glass
fill 521 280 570 534 280 570 minecraft:blue_concrete
fill 521 280 574 528 280 574 minecraft:blue_concrete
fill 523 280 575 528 280 575 minecraft:blue_concrete
fill 524 280 572 534 280 572 minecraft:blue_concrete
fill 524 280 576 528 280 576 minecraft:blue_concrete
fill 524 280 580 536 280 580 minecraft:blue_concrete
fill 526 280 577 528 280 577 minecraft:blue_concrete
fill 527 280 578 528 280 578 minecraft:blue_concrete
fill 527 280 582 536 280 582 minecraft:blue_concrete
fill 529 280 569 534 280 569 minecraft:blue_concrete
fill 529 280 574 529 280 578 minecraft:sea_lantern
fill 530 280 574 538 280 574 minecraft:sea_lantern
fill 530 280 575 532 280 577 minecraft:blue_concrete
fill 530 280 578 541 280 578 minecraft:sea_lantern
fill 532 280 571 534 280 571 minecraft:blue_concrete
fill 533 280 575 534 280 577 minecraft:sea_lantern
fill 535 280 569 535 280 573 minecraft:sea_lantern
fill 535 280 581 536 280 581 minecraft:blue_concrete
fill 536 280 569 539 280 569 minecraft:sea_lantern
fill 536 280 570 538 280 572 minecraft:blue_concrete
fill 536 280 573 539 280 573 minecraft:sea_lantern
fill 537 280 579 537 280 582 minecraft:sea_lantern
fill 538 280 575 538 280 577 minecraft:sea_lantern
fill 538 280 579 540 280 581 minecraft:blue_concrete
fill 538 280 582 541 280 582 minecraft:sea_lantern
fill 539 280 570 539 280 572 minecraft:sea_lantern
fill 539 280 574 541 280 577 minecraft:blue_concrete
fill 540 280 569 552 280 569 minecraft:blue_concrete
fill 540 280 571 541 280 573 minecraft:blue_concrete
fill 541 280 579 541 280 581 minecraft:sea_lantern
fill 542 280 573 544 280 574 minecraft:blue_concrete
fill 542 280 578 544 280 582 minecraft:blue_concrete
setblock 543 280 557 minecraft:white_stained_glass
fill 545 280 573 552 280 573 minecraft:blue_concrete
fill 545 280 579 547 280 582 minecraft:blue_concrete
fill 548 280 582 550 280 582 minecraft:blue_concrete
setblock 559 280 566 minecraft:white_stained_glass
fill 517 281 573 517 288 573 minecraft:black_concrete
fill 521 281 557 521 282 557 minecraft:black_concrete
fill 543 281 557 543 307 557 minecraft:black_concrete
setblock 559 281 565 minecraft:white_stained_glass
fill 559 281 566 559 307 566 minecraft:black_concrete
setblock 517 282 569 minecraft:white_concrete
fill 517 282 570 517 286 571 minecraft:black_concrete
setblock 517 282 583 minecraft:white_concrete
fill 559 282 565 559 302 565 minecraft:black_concrete
fill 517 283 569 517 307 569 minecraft:black_concrete
fill 517 283 574 517 307 574 minecraft:black_concrete
setblock 517 283 575 minecraft:white_stained_glass
fill 517 283 576 517 307 576 minecraft:black_concrete
fill 517 283 583 517 307 583 minecraft:black_concrete
fill 520 283 599 520 290 599 minecraft:black_concrete
setblock 521 283 557 minecraft:sea_lantern
setblock 521 283 599 minecraft:white_concrete
setblock 522 283 557 minecraft:white_concrete
setblock 559 283 597 minecraft:white_concrete
fill 517 284 575 517 290 575 minecraft:black_concrete
setblock 517 284 579 minecraft:sea_lantern
setblock 517 284 596 minecraft:white_concrete
setblock 520 284 560 minecraft:light[level=14]
setblock 520 284 568 minecraft:light[level=14]
setblock 520 284 576 minecraft:light[level=14]
setblock 520 284 584 minecraft:light[level=14]
setblock 520 284 592 minecraft:light[level=14]
fill 521 284 557 522 284 557 minecraft:black_concrete
fill 521 284 599 521 298 599 minecraft:black_concrete
setblock 528 284 560 minecraft:light[level=14]
setblock 528 284 568 minecraft:light[level=14]
setblock 528 284 576 minecraft:light[level=14]
setblock 528 284 584 minecraft:light[level=14]
setblock 528 284 592 minecraft:light[level=14]
setblock 536 284 560 minecraft:light[level=14]
setblock 536 284 568 minecraft:light[level=14]
setblock 536 284 584 minecraft:light[level=14]
setblock 536 284 592 minecraft:light[level=14]
setblock 541 284 557 minecraft:white_concrete
setblock 544 284 560 minecraft:light[level=14]
setblock 544 284 568 minecraft:light[level=14]
setblock 544 284 576 minecraft:light[level=14]
setblock 544 284 584 minecraft:light[level=14]
setblock 544 284 592 minecraft:light[level=14]
fill 545 284 557 546 284 557 minecraft:white_concrete
setblock 552 284 560 minecraft:light[level=14]
setblock 552 284 568 minecraft:light[level=14]
setblock 552 284 576 minecraft:light[level=14]
setblock 552 284 584 minecraft:light[level=14]
setblock 552 284 592 minecraft:light[level=14]
setblock 554 284 557 minecraft:sea_lantern
fill 555 284 557 556 307 557 minecraft:black_concrete
setblock 559 284 569 minecraft:white_concrete
fill 559 284 570 559 285 570 minecraft:black_concrete
fill 559 284 597 559 298 597 minecraft:black_concrete
fill 517 285 579 517 307 579 minecraft:black_concrete
fill 517 285 596 517 304 596 minecraft:black_concrete
setblock 521 285 557 minecraft:white_concrete
fill 522 285 557 522 307 557 minecraft:black_concrete
setblock 523 285 557 minecraft:white_concrete
fill 532 285 599 533 303 599 minecraft:black_concrete
setblock 534 285 599 minecraft:white_concrete
fill 541 285 557 541 295 557 minecraft:black_concrete
fill 545 285 557 546 286 557 minecraft:black_concrete
fill 554 285 557 554 307 557 minecraft:black_concrete
fill 559 285 569 559 307 569 minecraft:black_concrete
setblock 559 285 578 minecraft:sea_lantern
setblock 517 286 585 minecraft:sea_lantern
fill 521 286 557 521 287 557 minecraft:black_concrete
fill 523 286 557 523 307 557 minecraft:black_concrete
fill 533 286 557 534 306 557 minecraft:black_concrete
fill 534 286 599 534 307 599 minecraft:black_concrete
setblock 535 286 557 minecraft:white_stained_glass
setblock 559 286 559 minecraft:white_stained_glass
setblock 559 286 570 minecraft:white_stained_glass
fill 559 286 578 559 307 578 minecraft:black_concrete
setblock 559 286 587 minecraft:sea_lantern
fill 517 287 570 517 307 570 minecraft:black_concrete
setblock 517 287 571 minecraft:white_stained_glass
setblock 517 287 572 minecraft:white_concrete
setblock 517 287 580 minecraft:white_stained_glass
fill 517 287 585 517 307 585 minecraft:black_concrete
fill 524 287 599 525 307 599 minecraft:black_concrete
setblock 526 287 599 minecraft:white_concrete
fill 531 287 587 533 288 587 minecraft:white_concrete
fill 532 287 586 532 288 586 minecraft:white_concrete
fill 532 287 588 532 288 588 minecraft:white_concrete
fill 535 287 557 535 307 557 minecraft:black_concrete
fill 539 287 589 540 288 590 minecraft:blue_concrete
fill 545 287 557 545 294 557 minecraft:black_concrete
setblock 546 287 557 minecraft:sea_lantern
setblock 547 287 557 minecraft:white_concrete
fill 548 287 557 549 307 557 minecraft:black_concrete
fill 559 287 559 559 307 559 minecraft:black_concrete
setblock 559 287 564 minecraft:white_concrete
fill 559 287 570 559 307 570 minecraft:black_concrete
fill 559 287 587 559 292 587 minecraft:black_concrete
fill 517 288 565 517 290 565 minecraft:white_concrete
fill 517 288 571 517 302 572 minecraft:black_concrete
fill 517 288 580 517 307 580 minecraft:black_concrete
fill 517 288 581 517 290 581 minecraft:white_concrete
fill 517 288 597 517 290 597 minecraft:white_concrete
fill 521 288 557 521 290 557 minecraft:white_concrete
fill 526 288 599 526 295 599 minecraft:black_concrete
setblock 531 288 557 minecraft:sea_lantern
fill 531 288 599 531 290 599 minecraft:white_concrete
setblock 535 288 599 minecraft:sea_lantern
fill 537 288 557 537 290 557 minecraft:white_concrete
fill 546 288 557 547 307 557 minecraft:black_concrete
fill 547 288 599 547 290 599 minecraft:white_concrete
fill 553 288 557 553 290 557 minecraft:white_concrete
fill 559 288 564 559 293 564 minecraft:black_concrete
fill 559 288 567 559 290 567 minecraft:white_concrete
fill 559 288 583 559 290 583 minecraft:white_concrete
fill 559 288 584 559 288 585 minecraft:sea_lantern
setblock 517 289 573 minecraft:white_concrete
setblock 517 289 593 minecraft:white_concrete
fill 531 289 557 531 307 557 minecraft:black_concrete
fill 535 289 599 535 307 599 minecraft:black_concrete
fill 559 289 584 559 293 585 minecraft:black_concrete
setblock 517 290 562 minecraft:white_stained_glass
fill 517 290 563 517 290 564 minecraft:black_concrete
fill 517 290 573 517 307 573 minecraft:black_concrete
fill 517 290 593 517 292 593 minecraft:black_concrete
setblock 559 290 574 minecraft:white_concrete
fill 559 290 575 559 307 575 minecraft:black_concrete
fill 517 291 562 517 307 563 minecraft:black_concrete
setblock 517 291 564 minecraft:white_stained_glass
fill 517 291 565 517 296 565 minecraft:black_concrete
setblock 517 291 575 minecraft:sea_lantern
fill 517 291 581 517 296 581 minecraft:black_concrete
fill 517 291 597 517 296 597 minecraft:black_concrete
setblock 520 291 599 minecraft:white_concrete
fill 521 291 557 521 296 557 minecraft:black_concrete
fill 531 291 599 531 296 599 minecraft:black_concrete
fill 537 291 557 537 296 557 minecraft:black_concrete
setblock 538 291 557 minecraft:white_concrete
fill 539 291 557 539 298 557 minecraft:black_concrete
fill 547 291 599 547 296 599 minecraft:black_concrete
fill 553 291 557 553 296 557 minecraft:black_concrete
setblock 559 291 563 minecraft:sea_lantern
fill 559 291 567 559 296 567 minecraft:black_concrete
fill 559 291 574 559 303 574 minecraft:black_concrete
fill 559 291 581 559 292 581 minecraft:white_stained_glass
fill 559 291 583 559 296 583 minecraft:black_concrete
fill 517 292 564 517 307 564 minecraft:black_concrete
fill 517 292 575 517 293 575 minecraft:black_concrete
setblock 520 292 560 minecraft:light[level=14]
setblock 520 292 568 minecraft:light[level=14]
setblock 520 292 576 minecraft:light[level=14]
setblock 520 292 584 minecraft:light[level=14]
setblock 520 292 592 minecraft:light[level=14]
fill 520 292 599 520 307 599 minecraft:black_concrete
setblock 528 292 560 minecraft:light[level=14]
setblock 528 292 568 minecraft:light[level=14]
setblock 528 292 576 minecraft:light[level=14]
setblock 528 292 584 minecraft:light[level=14]
setblock 528 292 592 minecraft:light[level=14]
fill 530 292 589 530 293 590 minecraft:blue_concrete
setblock 536 292 560 minecraft:light[level=14]
setblock 536 292 568 minecraft:light[level=14]
setblock 536 292 584 minecraft:light[level=14]
setblock 536 292 592 minecraft:light[level=14]
fill 537 292 566 538 293 567 minecraft:white_concrete
fill 538 292 557 538 307 557 minecraft:black_concrete
setblock 544 292 560 minecraft:light[level=14]
setblock 544 292 568 minecraft:light[level=14]
setblock 544 292 576 minecraft:light[level=14]
setblock 544 292 584 minecraft:light[level=14]
setblock 544 292 592 minecraft:light[level=14]
setblock 550 292 557 minecraft:white_concrete
setblock 551 292 599 minecraft:white_concrete
setblock 552 292 560 minecraft:light[level=14]
setblock 552 292 568 minecraft:light[level=14]
setblock 552 292 576 minecraft:light[level=14]
setblock 552 292 584 minecraft:light[level=14]
setblock 552 292 592 minecraft:light[level=14]
fill 552 292 599 553 294 599 minecraft:black_concrete
fill 559 292 563 559 307 563 minecraft:black_concrete
fill 517 293 590 517 307 590 minecraft:black_concrete
setblock 517 293 591 minecraft:sea_lantern
setblock 517 293 593 minecraft:white_concrete
fill 550 293 557 550 307 557 minecraft:black_concrete
fill 551 293 599 551 307 599 minecraft:black_concrete
fill 559 293 581 559 307 581 minecraft:black_concrete
setblock 559 293 587 minecraft:white_stained_glass
setblock 517 294 575 minecraft:white_concrete
fill 517 294 591 517 307 591 minecraft:black_concrete
fill 517 294 593 517 307 593 minecraft:black_concrete
setblock 559 294 564 minecraft:white_concrete
fill 559 294 584 559 307 584 minecraft:black_concrete
setblock 559 294 585 minecraft:white_stained_glass
fill 559 294 587 559 307 587 minecraft:black_concrete
fill 517 295 575 517 307 575 minecraft:black_concrete
setblock 538 295 599 minecraft:white_concrete
setblock 545 295 557 minecraft:white_concrete
setblock 552 295 599 minecraft:white_concrete
fill 553 295 599 553 307 599 minecraft:black_concrete
fill 559 295 564 559 307 564 minecraft:black_concrete
fill 559 295 585 559 307 585 minecraft:black_concrete
setblock 518 296 557 minecraft:sea_lantern
setblock 526 296 599 minecraft:white_stained_glass
fill 538 296 599 538 307 599 minecraft:black_concrete
setblock 541 296 557 minecraft:white_stained_glass
fill 545 296 557 545 307 557 minecraft:black_concrete
fill 552 296 599 552 307 599 minecraft:black_concrete
setblock 559 296 592 minecraft:white_concrete
fill 517 297 565 517 299 565 minecraft:white_concrete
fill 517 297 581 517 299 581 minecraft:white_concrete
fill 517 297 597 517 299 597 minecraft:white_concrete
fill 518 297 557 518 307 557 minecraft:black_concrete
fill 521 297 557 521 299 557 minecraft:white_concrete
fill 526 297 599 526 307 599 minecraft:black_concrete
fill 531 297 599 531 299 599 minecraft:white_concrete
fill 537 297 557 537 299 557 minecraft:white_concrete
fill 541 297 557 541 307 557 minecraft:black_concrete
fill 547 297 599 547 299 599 minecraft:white_concrete
setblock 549 297 599 minecraft:white_concrete
fill 553 297 557 553 299 557 minecraft:white_concrete
fill 559 297 567 559 300 567 minecraft:white_concrete
fill 559 297 583 559 299 583 minecraft:white_concrete
setblock 559 297 588 minecraft:white_concrete
fill 559 297 592 559 307 592 minecraft:black_concrete
setblock 517 298 558 minecraft:white_stained_glass
fill 549 298 599 549 307 599 minecraft:black_concrete
fill 559 298 588 559 307 588 minecraft:black_concrete
setblock 559 298 591 minecraft:white_concrete
fill 517 299 558 517 307 558 minecraft:black_concrete
setblock 521 299 599 minecraft:white_stained_glass
fill 536 299 591 536 300 592 minecraft:white_concrete
fill 537 299 591 537 300 591 minecraft:white_concrete
setblock 539 299 557 minecraft:white_concrete
setblock 559 299 558 minecraft:sea_lantern
fill 559 299 591 559 307 591 minecraft:black_concrete
setblock 559 299 597 minecraft:white_concrete
fill 517 300 565 517 304 565 minecraft:black_concrete
fill 517 300 581 517 307 581 minecraft:black_concrete
fill 517 300 597 517 303 597 minecraft:black_concrete
setblock 520 300 560 minecraft:light[level=14]
setblock 520 300 568 minecraft:light[level=14]
setblock 520 300 576 minecraft:light[level=14]
setblock 520 300 584 minecraft:light[level=14]
setblock 520 300 592 minecraft:light[level=14]
fill 521 300 557 521 307 557 minecraft:black_concrete
fill 521 300 599 521 307 599 minecraft:black_concrete
setblock 528 300 560 minecraft:light[level=14]
setblock 528 300 568 minecraft:light[level=14]
setblock 528 300 576 minecraft:light[level=14]
setblock 528 300 584 minecraft:light[level=14]
setblock 528 300 592 minecraft:light[level=14]
fill 531 300 599 531 307 599 minecraft:black_concrete
setblock 536 300 560 minecraft:light[level=14]
setblock 536 300 568 minecraft:light[level=14]
setblock 536 300 576 minecraft:light[level=14]
setblock 536 300 584 minecraft:light[level=14]
fill 537 300 557 537 307 557 minecraft:black_concrete
fill 539 300 557 539 303 557 minecraft:black_concrete
setblock 544 300 560 minecraft:light[level=14]
setblock 544 300 568 minecraft:light[level=14]
setblock 544 300 576 minecraft:light[level=14]
setblock 544 300 584 minecraft:light[level=14]
setblock 544 300 592 minecraft:light[level=14]
fill 547 300 599 547 307 599 minecraft:black_concrete
setblock 552 300 560 minecraft:light[level=14]
setblock 552 300 568 minecraft:light[level=14]
setblock 552 300 576 minecraft:light[level=14]
setblock 552 300 584 minecraft:light[level=14]
setblock 552 300 592 minecraft:light[level=14]
fill 553 300 557 553 307 557 minecraft:black_concrete
fill 559 300 558 559 307 558 minecraft:black_concrete
fill 559 300 583 559 307 583 minecraft:black_concrete
fill 559 300 597 559 307 597 minecraft:black_concrete
setblock 557 301 557 minecraft:sea_lantern
fill 559 301 567 559 307 567 minecraft:black_concrete
setblock 520 302 557 minecraft:sea_lantern
setblock 536 302 599 minecraft:white_concrete
fill 557 302 557 557 307 557 minecraft:black_concrete
setblock 517 303 571 minecraft:white_concrete
fill 517 303 572 517 307 572 minecraft:black_concrete
fill 520 303 557 520 307 557 minecraft:black_concrete
fill 536 303 599 536 307 599 minecraft:black_concrete
setblock 559 303 565 minecraft:sea_lantern
fill 517 304 571 517 307 571 minecraft:black_concrete
setblock 517 304 597 minecraft:sea_lantern
setblock 532 304 599 minecraft:white_stained_glass
fill 533 304 599 533 307 599 minecraft:black_concrete
setblock 536 304 557 minecraft:sea_lantern
setblock 539 304 557 minecraft:white_stained_glass
setblock 542 304 599 minecraft:sea_lantern
fill 543 304 599 544 307 599 minecraft:black_concrete
fill 559 304 565 559 307 565 minecraft:black_concrete
setblock 559 304 574 minecraft:white_concrete
setblock 517 305 565 minecraft:sea_lantern
setblock 517 305 596 minecraft:white_concrete
fill 517 305 597 517 307 597 minecraft:black_concrete
setblock 519 305 599 minecraft:white_stained_glass
fill 532 305 599 532 307 599 minecraft:black_concrete
fill 536 305 557 536 307 557 minecraft:black_concrete
setblock 539 305 557 minecraft:black_concrete
fill 542 305 599 542 307 599 minecraft:black_concrete
fill 559 305 574 559 307 574 minecraft:black_concrete
fill 517 306 565 517 307 565 minecraft:black_concrete
fill 517 306 596 517 307 596 minecraft:black_concrete
fill 519 306 599 519 307 599 minecraft:black_concrete
setblock 539 306 557 minecraft:sea_lantern
setblock 530 307 557 minecraft:sea_lantern
setblock 533 307 557 minecraft:white_concrete
setblock 534 307 557 minecraft:black_concrete
setblock 539 307 557 minecraft:black_concrete
