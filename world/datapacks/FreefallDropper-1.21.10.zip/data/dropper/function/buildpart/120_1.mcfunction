fill 0 162 527 0 168 527 minecraft:gray_concrete
setblock 0 162 543 minecraft:light_blue_stained_glass
fill 5 162 529 10 163 529 minecraft:black_concrete
fill 6 162 524 6 163 525 minecraft:cyan_concrete
fill 6 162 526 11 163 528 minecraft:black_concrete
fill 6 162 530 7 163 534 minecraft:black_concrete
fill 7 162 522 7 163 524 minecraft:cyan_concrete
fill 7 162 525 20 162 525 minecraft:black_concrete
fill 7 162 535 7 163 536 minecraft:black_concrete
setblock 7 162 552 minecraft:light_blue_stained_glass
fill 8 162 520 8 163 523 minecraft:cyan_concrete
fill 8 162 524 20 163 524 minecraft:black_concrete
fill 8 162 530 8 163 533 minecraft:black_concrete
fill 8 162 534 11 163 538 minecraft:cyan_concrete
fill 9 162 519 10 163 522 minecraft:cyan_concrete
fill 9 162 523 19 163 523 minecraft:black_concrete
fill 9 162 530 9 163 530 minecraft:black_concrete
fill 9 162 531 11 163 533 minecraft:cyan_concrete
fill 9 162 539 11 163 539 minecraft:cyan_concrete
fill 10 162 518 12 163 518 minecraft:black_concrete
fill 10 162 530 13 162 530 minecraft:cyan_concrete
fill 10 162 540 11 163 540 minecraft:cyan_concrete
fill 11 162 517 24 163 517 minecraft:black_concrete
fill 11 162 519 18 163 521 minecraft:cyan_concrete
fill 11 162 522 17 163 522 minecraft:black_concrete
fill 11 162 529 14 162 529 minecraft:cyan_concrete
fill 11 162 541 12 163 541 minecraft:cyan_concrete
fill 12 162 516 23 163 516 minecraft:black_concrete
fill 12 162 526 12 162 527 minecraft:black_concrete
fill 12 162 528 15 162 528 minecraft:cyan_concrete
fill 12 162 531 12 162 532 minecraft:cyan_concrete
fill 12 162 533 16 162 540 minecraft:black_concrete
fill 12 162 542 12 163 542 minecraft:cyan_concrete
fill 13 162 518 14 163 518 minecraft:cyan_concrete
fill 13 162 526 15 162 526 minecraft:black_concrete
fill 13 162 527 16 162 527 minecraft:cyan_concrete
fill 13 162 531 16 162 532 minecraft:black_concrete
fill 13 162 541 19 163 542 minecraft:black_concrete
fill 14 162 515 22 163 515 minecraft:black_concrete
fill 14 162 530 15 162 530 minecraft:black_concrete
fill 14 162 543 21 163 543 minecraft:black_concrete
fill 15 162 518 25 163 518 minecraft:black_concrete
fill 15 162 529 18 163 529 minecraft:dark_oak_planks
fill 16 162 514 20 163 514 minecraft:black_concrete
setblock 16 162 526 minecraft:cyan_concrete
fill 16 162 528 19 162 528 minecraft:dark_oak_planks
fill 16 162 530 19 162 530 minecraft:dark_oak_planks
fill 16 162 544 23 163 544 minecraft:black_concrete
fill 17 162 526 19 162 526 minecraft:black_concrete
fill 17 162 527 20 162 527 minecraft:dark_oak_planks
fill 17 162 531 20 162 531 minecraft:dark_oak_planks
fill 17 162 532 18 162 537 minecraft:cyan_concrete
fill 17 162 538 17 163 540 minecraft:black_concrete
fill 18 162 522 21 163 522 minecraft:cyan_concrete
fill 18 162 538 20 163 539 minecraft:cyan_concrete
fill 18 162 540 18 163 540 minecraft:black_concrete
fill 19 162 519 25 163 519 minecraft:black_concrete
fill 19 162 520 19 163 521 minecraft:cyan_concrete
fill 19 162 532 19 162 534 minecraft:black_concrete
fill 19 162 535 19 163 537 minecraft:cyan_concrete
fill 19 162 540 23 163 540 minecraft:cyan_concrete
fill 20 162 520 26 163 520 minecraft:black_concrete
fill 20 162 521 20 163 521 minecraft:cyan_concrete
fill 20 162 523 22 163 523 minecraft:cyan_concrete
fill 20 162 526 22 163 526 minecraft:dark_oak_planks
fill 20 162 532 22 163 532 minecraft:dark_oak_planks
fill 20 162 533 21 162 537 minecraft:black_concrete
fill 20 162 541 26 163 541 minecraft:cyan_concrete
fill 20 162 542 20 163 542 minecraft:black_concrete
fill 21 162 513 21 163 514 minecraft:cyan_concrete
fill 21 162 521 26 163 521 minecraft:black_concrete
fill 21 162 524 22 162 525 minecraft:cyan_concrete
fill 21 162 538 34 163 538 minecraft:black_concrete
fill 21 162 539 21 163 539 minecraft:cyan_concrete
fill 21 162 542 30 163 542 minecraft:cyan_concrete
fill 21 162 545 21 163 545 minecraft:black_concrete
fill 22 162 514 26 163 514 minecraft:cyan_concrete
fill 22 162 522 26 163 522 minecraft:black_concrete
fill 22 162 527 25 162 527 minecraft:dark_oak_planks
fill 22 162 531 25 162 531 minecraft:dark_oak_planks
fill 22 162 533 34 162 533 minecraft:cyan_concrete
fill 22 162 534 22 163 537 minecraft:black_concrete
fill 22 162 539 33 163 539 minecraft:black_concrete
fill 22 162 543 28 163 543 minecraft:cyan_concrete
fill 23 162 515 27 163 515 minecraft:cyan_concrete
fill 23 162 523 25 162 526 minecraft:black_concrete
fill 23 162 528 26 162 528 minecraft:dark_oak_planks
fill 23 162 530 26 162 530 minecraft:dark_oak_planks
setblock 23 162 532 minecraft:cyan_concrete
fill 23 162 534 32 163 534 minecraft:cyan_concrete
fill 23 162 535 24 163 537 minecraft:black_concrete
fill 24 162 516 28 163 516 minecraft:cyan_concrete
fill 24 162 529 27 163 529 minecraft:dark_oak_planks
fill 24 162 532 29 162 532 minecraft:black_concrete
fill 24 162 540 32 163 540 minecraft:black_concrete
fill 24 162 544 26 163 544 minecraft:cyan_concrete
fill 25 162 517 28 163 517 minecraft:cyan_concrete
fill 25 162 535 30 163 535 minecraft:cyan_concrete
fill 25 162 536 34 163 537 minecraft:black_concrete
fill 26 162 518 29 163 519 minecraft:cyan_concrete
fill 26 162 523 26 162 525 minecraft:black_concrete
fill 26 162 526 28 162 527 minecraft:cyan_concrete
fill 26 162 531 31 162 531 minecraft:black_concrete
fill 27 162 520 29 163 525 minecraft:cyan_concrete
setblock 27 162 528 minecraft:cyan_concrete
fill 27 162 530 32 162 530 minecraft:black_concrete
fill 27 162 541 30 163 541 minecraft:black_concrete
fill 28 162 515 28 163 515 minecraft:black_concrete
fill 28 162 528 33 162 529 minecraft:black_concrete
fill 29 162 516 30 163 517 minecraft:black_concrete
fill 29 162 526 34 162 527 minecraft:black_concrete
fill 30 162 518 32 163 525 minecraft:black_concrete
fill 30 162 532 35 163 532 minecraft:cyan_concrete
fill 31 162 517 31 163 517 minecraft:black_concrete
fill 31 162 535 35 163 535 minecraft:black_concrete
fill 31 162 541 31 163 541 minecraft:cyan_concrete
fill 32 162 531 36 163 531 minecraft:cyan_concrete
fill 33 162 519 33 163 525 minecraft:black_concrete
fill 33 162 530 36 163 530 minecraft:cyan_concrete
fill 33 162 534 36 163 534 minecraft:black_concrete
fill 34 162 520 34 163 525 minecraft:black_concrete
fill 34 162 528 36 163 529 minecraft:cyan_concrete
fill 35 162 522 35 163 525 minecraft:black_concrete
fill 35 162 526 36 163 527 minecraft:cyan_concrete
fill 35 162 533 36 163 533 minecraft:black_concrete
fill 35 162 536 35 163 536 minecraft:black_concrete
setblock 36 162 510 minecraft:light_blue_stained_glass
fill 36 162 524 36 163 525 minecraft:cyan_concrete
fill 36 162 532 36 163 532 minecraft:black_concrete
fill 37 162 529 37 163 529 minecraft:cyan_concrete
fill 42 162 530 42 174 530 minecraft:gray_concrete
fill 42 162 546 42 206 546 minecraft:gray_concrete
fill 0 163 519 0 165 519 minecraft:gray_concrete
fill 0 163 543 0 166 543 minecraft:gray_concrete
fill 1 163 511 4 163 551 minecraft:black_concrete
setblock 4 163 510 minecraft:light_blue_stained_glass
fill 5 163 511 5 163 528 minecraft:black_concrete
fill 5 163 530 5 163 551 minecraft:black_concrete
fill 6 163 511 6 163 523 minecraft:black_concrete
fill 6 163 535 6 163 551 minecraft:black_concrete
fill 7 163 511 7 163 521 minecraft:black_concrete
fill 7 163 525 15 163 525 minecraft:black_concrete
fill 7 163 537 7 163 551 minecraft:black_concrete
fill 7 163 552 7 206 552 minecraft:gray_concrete
fill 8 163 511 8 163 519 minecraft:black_concrete
fill 8 163 539 8 163 551 minecraft:black_concrete
fill 9 163 511 9 163 518 minecraft:black_concrete
fill 9 163 540 9 163 551 minecraft:black_concrete
fill 10 163 511 10 163 517 minecraft:black_concrete
fill 10 163 530 11 163 530 minecraft:cyan_concrete
fill 10 163 541 10 163 551 minecraft:black_concrete
fill 11 163 511 11 163 516 minecraft:black_concrete
setblock 11 163 529 minecraft:cyan_concrete
fill 11 163 542 11 163 551 minecraft:black_concrete
fill 12 163 511 13 163 515 minecraft:black_concrete
fill 12 163 526 13 163 526 minecraft:black_concrete
fill 12 163 527 14 163 531 minecraft:dark_oak_planks
setblock 12 163 532 minecraft:cyan_concrete
fill 12 163 533 15 163 540 minecraft:black_concrete
fill 12 163 543 13 163 551 minecraft:black_concrete
setblock 13 163 532 minecraft:black_concrete
fill 14 163 511 15 163 514 minecraft:black_concrete
fill 14 163 526 19 163 526 minecraft:dark_oak_planks
fill 14 163 532 19 163 532 minecraft:dark_oak_planks
fill 14 163 544 15 163 551 minecraft:black_concrete
fill 15 163 527 18 163 528 minecraft:dark_oak_planks
fill 15 163 530 18 163 531 minecraft:dark_oak_planks
fill 16 163 511 20 163 513 minecraft:black_concrete
fill 16 163 525 26 163 525 minecraft:dark_oak_planks
fill 16 163 533 26 163 533 minecraft:dark_oak_planks
fill 16 163 534 16 163 540 minecraft:black_concrete
fill 16 163 545 20 163 551 minecraft:black_concrete
fill 17 163 534 18 163 537 minecraft:cyan_concrete
fill 19 163 527 19 163 528 minecraft:sea_lantern
fill 19 163 530 19 163 531 minecraft:sea_lantern
fill 19 163 534 21 163 534 minecraft:black_concrete
setblock 20 163 527 minecraft:sea_lantern
setblock 20 163 531 minecraft:sea_lantern
fill 20 163 535 21 163 537 minecraft:black_concrete
setblock 21 163 510 minecraft:light_blue_stained_glass
fill 21 163 511 41 163 512 minecraft:black_concrete
fill 21 163 524 22 163 524 minecraft:cyan_concrete
fill 21 163 546 41 163 551 minecraft:black_concrete
fill 22 163 510 22 206 510 minecraft:gray_concrete
fill 22 163 513 41 163 513 minecraft:black_concrete
fill 22 163 527 23 163 527 minecraft:sea_lantern
fill 22 163 531 23 163 531 minecraft:sea_lantern
fill 22 163 545 41 163 545 minecraft:black_concrete
fill 23 163 523 26 163 524 minecraft:black_concrete
fill 23 163 526 28 163 526 minecraft:dark_oak_planks
setblock 23 163 528 minecraft:sea_lantern
setblock 23 163 530 minecraft:sea_lantern
fill 23 163 532 28 163 532 minecraft:dark_oak_planks
fill 24 163 527 30 163 528 minecraft:dark_oak_planks
fill 24 163 530 30 163 531 minecraft:dark_oak_planks
fill 27 163 514 41 163 514 minecraft:black_concrete
fill 27 163 533 34 163 533 minecraft:cyan_concrete
fill 27 163 544 41 163 544 minecraft:black_concrete
fill 28 163 529 30 163 529 minecraft:dark_oak_planks
fill 29 163 515 41 163 515 minecraft:black_concrete
fill 29 163 526 34 163 526 minecraft:black_concrete
setblock 29 163 532 minecraft:black_concrete
fill 29 163 543 41 163 543 minecraft:black_concrete
fill 31 163 516 41 163 516 minecraft:black_concrete
fill 31 163 527 31 163 531 minecraft:black_concrete
fill 31 163 542 41 163 542 minecraft:black_concrete
fill 32 163 517 41 163 517 minecraft:black_concrete
fill 32 163 527 32 163 530 minecraft:black_concrete
fill 32 163 541 41 163 541 minecraft:black_concrete
fill 33 163 518 41 163 518 minecraft:black_concrete
fill 33 163 527 33 163 529 minecraft:black_concrete
fill 33 163 540 41 163 540 minecraft:black_concrete
fill 34 163 519 41 163 519 minecraft:black_concrete
setblock 34 163 527 minecraft:black_concrete
fill 34 163 539 41 163 539 minecraft:black_concrete
fill 35 163 520 41 163 521 minecraft:black_concrete
fill 35 163 537 41 163 538 minecraft:black_concrete
fill 36 163 510 36 170 510 minecraft:gray_concrete
fill 36 163 522 41 163 523 minecraft:black_concrete
fill 36 163 535 41 163 536 minecraft:black_concrete
fill 37 163 524 41 163 528 minecraft:black_concrete
fill 37 163 530 41 163 534 minecraft:black_concrete
fill 38 163 529 41 163 529 minecraft:black_concrete
fill 42 163 518 42 164 518 minecraft:sea_lantern
fill 42 163 527 42 203 527 minecraft:gray_concrete
setblock 42 163 528 minecraft:white_concrete
setblock 42 163 538 minecraft:white_concrete
setblock 0 164 551 minecraft:light_blue_stained_glass
fill 0 164 552 0 206 552 minecraft:gray_concrete
fill 4 164 510 4 170 510 minecraft:gray_concrete
fill 9 164 529 11 164 529 minecraft:dark_oak_planks
fill 10 164 527 11 164 528 minecraft:dark_oak_planks
fill 10 164 530 11 164 531 minecraft:dark_oak_planks
fill 11 164 526 13 164 526 minecraft:dark_oak_planks
fill 11 164 532 13 164 532 minecraft:dark_oak_planks
fill 12 164 525 15 164 525 minecraft:dark_oak_planks
fill 12 164 533 15 164 533 minecraft:dark_oak_planks
fill 15 164 524 27 164 524 minecraft:dark_oak_planks
fill 15 164 534 27 164 534 minecraft:dark_oak_planks
fill 20 164 523 22 166 523 minecraft:dark_oak_planks
fill 20 164 535 22 166 535 minecraft:dark_oak_planks
fill 21 164 510 21 199 510 minecraft:gray_concrete
fill 27 164 525 30 164 525 minecraft:dark_oak_planks
fill 27 164 533 30 164 533 minecraft:dark_oak_planks
fill 29 164 526 31 164 526 minecraft:dark_oak_planks
fill 29 164 532 31 164 532 minecraft:dark_oak_planks
fill 31 164 527 32 164 531 minecraft:dark_oak_planks
setblock 33 164 529 minecraft:dark_oak_planks
fill 40 164 552 40 206 552 minecraft:gray_concrete
setblock 41 164 552 minecraft:white_concrete
fill 42 164 528 42 200 528 minecraft:gray_concrete
fill 42 164 538 42 180 538 minecraft:gray_concrete
fill 42 164 552 42 202 552 minecraft:gray_concrete
setblock 0 165 512 minecraft:white_concrete
fill 0 165 551 0 206 551 minecraft:gray_concrete
setblock 3 165 513 minecraft:light[level=11]
setblock 3 165 521 minecraft:light[level=11]
setblock 3 165 529 minecraft:light[level=11]
setblock 3 165 537 minecraft:light[level=11]
setblock 3 165 545 minecraft:light[level=11]
fill 8 165 528 8 166 530 minecraft:dark_oak_planks
setblock 8 165 552 minecraft:sea_lantern
fill 9 165 527 9 165 528 minecraft:dark_oak_planks
fill 9 165 530 9 165 531 minecraft:dark_oak_planks
setblock 10 165 526 minecraft:dark_oak_planks
setblock 10 165 532 minecraft:dark_oak_planks
setblock 11 165 513 minecraft:light[level=11]
setblock 11 165 521 minecraft:light[level=11]
fill 11 165 525 12 165 525 minecraft:dark_oak_planks
setblock 11 165 529 minecraft:light[level=11]
fill 11 165 533 12 165 533 minecraft:dark_oak_planks
setblock 11 165 537 minecraft:light[level=11]
setblock 11 165 545 minecraft:light[level=11]
setblock 11 165 552 minecraft:sea_lantern
fill 13 165 524 15 165 524 minecraft:dark_oak_planks
fill 13 165 534 15 165 534 minecraft:dark_oak_planks
fill 16 165 523 19 166 523 minecraft:dark_oak_planks
fill 16 165 535 19 166 535 minecraft:dark_oak_planks
setblock 18 165 552 minecraft:sea_lantern
setblock 19 165 513 minecraft:light[level=11]
setblock 19 165 521 minecraft:light[level=11]
setblock 19 165 537 minecraft:light[level=11]
setblock 19 165 545 minecraft:light[level=11]
fill 23 165 523 26 166 523 minecraft:dark_oak_planks
fill 23 165 535 26 166 535 minecraft:dark_oak_planks
setblock 27 165 513 minecraft:light[level=11]
setblock 27 165 521 minecraft:light[level=11]
fill 27 165 524 29 165 524 minecraft:dark_oak_planks
setblock 27 165 529 minecraft:light[level=11]
fill 27 165 534 29 165 534 minecraft:dark_oak_planks
setblock 27 165 537 minecraft:light[level=11]
setblock 27 165 545 minecraft:light[level=11]
setblock 29 165 552 minecraft:white_concrete
fill 30 165 525 31 165 525 minecraft:dark_oak_planks
fill 30 165 533 31 165 533 minecraft:dark_oak_planks
setblock 32 165 526 minecraft:dark_oak_planks
setblock 32 165 532 minecraft:dark_oak_planks
fill 33 165 527 33 165 528 minecraft:dark_oak_planks
fill 33 165 530 33 165 531 minecraft:dark_oak_planks
fill 34 165 528 34 166 530 minecraft:dark_oak_planks
setblock 35 165 513 minecraft:light[level=11]
setblock 35 165 521 minecraft:light[level=11]
setblock 35 165 529 minecraft:light[level=11]
setblock 35 165 537 minecraft:light[level=11]
setblock 35 165 545 minecraft:light[level=11]
setblock 41 165 510 minecraft:light_blue_stained_glass
fill 41 165 552 41 166 552 minecraft:gray_concrete
fill 42 165 510 42 206 510 minecraft:gray_concrete
fill 42 165 518 42 187 518 minecraft:gray_concrete
fill 0 166 512 0 206 512 minecraft:gray_concrete
setblock 0 166 519 minecraft:light_blue_stained_glass
fill 0 166 525 0 189 525 minecraft:gray_concrete
setblock 0 166 526 minecraft:light_blue_stained_glass
setblock 0 166 528 minecraft:sea_lantern
setblock 8 166 527 minecraft:dark_oak_planks
setblock 8 166 531 minecraft:dark_oak_planks
setblock 8 166 552 minecraft:light_blue_stained_glass
setblock 9 166 526 minecraft:dark_oak_planks
setblock 9 166 532 minecraft:dark_oak_planks
fill 10 166 525 11 166 525 minecraft:dark_oak_planks
fill 10 166 533 11 166 533 minecraft:dark_oak_planks
fill 11 166 552 11 171 552 minecraft:gray_concrete
fill 12 166 524 13 166 524 minecraft:dark_oak_planks
fill 12 166 534 13 166 534 minecraft:dark_oak_planks
setblock 13 166 552 minecraft:light_blue_stained_glass
fill 14 166 523 15 166 523 minecraft:dark_oak_planks
fill 14 166 535 15 166 535 minecraft:dark_oak_planks
fill 18 166 552 18 167 552 minecraft:gray_concrete
fill 27 166 523 28 166 523 minecraft:dark_oak_planks
fill 27 166 535 28 166 535 minecraft:dark_oak_planks
fill 29 166 524 30 166 524 minecraft:dark_oak_planks
fill 29 166 534 30 166 534 minecraft:dark_oak_planks
fill 29 166 552 29 206 552 minecraft:gray_concrete
fill 31 166 525 32 166 525 minecraft:dark_oak_planks
fill 31 166 533 32 166 533 minecraft:dark_oak_planks
setblock 33 166 510 minecraft:white_concrete
setblock 33 166 526 minecraft:dark_oak_planks
setblock 33 166 532 minecraft:dark_oak_planks
setblock 34 166 527 minecraft:dark_oak_planks
setblock 34 166 531 minecraft:dark_oak_planks
fill 41 166 510 41 206 510 minecraft:gray_concrete
setblock 42 166 513 minecraft:sea_lantern
fill 42 166 514 42 200 514 minecraft:gray_concrete
setblock 42 166 543 minecraft:white_concrete
setblock 42 166 548 minecraft:sea_lantern
fill 0 167 519 0 206 519 minecraft:gray_concrete
fill 0 167 526 0 206 526 minecraft:gray_concrete
fill 0 167 528 0 190 528 minecraft:gray_concrete
setblock 0 167 543 minecraft:light_blue_stained_glass
fill 6 167 540 6 175 540 minecraft:iron_block
fill 8 167 527 17 167 531 minecraft:spruce_planks
fill 8 167 552 8 206 552 minecraft:gray_concrete
fill 9 167 526 18 167 526 minecraft:spruce_planks
fill 9 167 532 18 167 532 minecraft:spruce_planks
fill 10 167 525 32 167 525 minecraft:spruce_planks
fill 10 167 533 32 167 533 minecraft:spruce_planks
fill 12 167 524 30 167 524 minecraft:spruce_planks
fill 12 167 534 30 167 534 minecraft:spruce_planks
fill 13 167 552 13 207 552 minecraft:gray_concrete
fill 14 167 523 28 167 523 minecraft:spruce_planks
fill 14 167 535 28 167 535 minecraft:spruce_planks
setblock 14 167 552 minecraft:light_blue_stained_glass
setblock 20 167 552 minecraft:sea_lantern
fill 21 167 552 21 206 552 minecraft:gray_concrete
fill 24 167 526 33 167 526 minecraft:spruce_planks
fill 24 167 532 33 167 532 minecraft:spruce_planks
fill 25 167 527 34 167 531 minecraft:spruce_planks
fill 33 167 510 33 170 510 minecraft:gray_concrete
setblock 41 167 552 minecraft:light_blue_stained_glass
fill 42 167 513 42 191 513 minecraft:gray_concrete
fill 42 167 543 42 204 543 minecraft:gray_concrete
fill 42 167 548 42 170 548 minecraft:gray_concrete
setblock 42 167 550 minecraft:sea_lantern
setblock 0 168 518 minecraft:white_concrete
fill 0 168 543 0 202 543 minecraft:gray_concrete
setblock 0 168 548 minecraft:light_blue_stained_glass
fill 13 168 526 13 169 527 minecraft:light_blue_stained_glass
fill 14 168 552 14 170 552 minecraft:gray_concrete
setblock 18 168 552 minecraft:white_concrete
fill 20 168 552 20 175 552 minecraft:gray_concrete
setblock 25 168 510 minecraft:white_concrete
fill 28 168 529 28 171 529 minecraft:stripped_dark_oak_log
fill 41 168 552 41 203 552 minecraft:gray_concrete
setblock 42 168 542 minecraft:white_concrete
fill 42 168 550 42 204 550 minecraft:gray_concrete
fill 0 169 518 0 170 518 minecraft:gray_concrete
setblock 0 169 527 minecraft:white_concrete
fill 0 169 548 0 188 548 minecraft:gray_concrete
fill 18 169 552 18 203 552 minecraft:gray_concrete
setblock 19 169 552 minecraft:light_blue_stained_glass
fill 25 169 510 25 206 510 minecraft:gray_concrete
setblock 42 169 531 minecraft:light_blue_stained_glass
fill 42 169 542 42 198 542 minecraft:gray_concrete
setblock 42 169 545 minecraft:light_blue_stained_glass
fill 0 170 527 0 206 527 minecraft:gray_concrete
setblock 0 170 544 minecraft:sea_lantern
fill 0 170 545 0 186 545 minecraft:gray_concrete
setblock 1 170 552 minecraft:sea_lantern
setblock 5 170 552 minecraft:light_blue_stained_glass
setblock 13 170 510 minecraft:sea_lantern
fill 19 170 552 19 206 552 minecraft:gray_concrete
setblock 28 170 552 minecraft:sea_lantern
setblock 32 170 510 minecraft:light_blue_stained_glass
setblock 42 170 522 minecraft:light_blue_stained_glass
fill 42 170 531 42 203 531 minecraft:gray_concrete
fill 42 170 545 42 173 545 minecraft:gray_concrete
fill 0 171 518 0 173 518 minecraft:cyan_concrete
fill 0 171 534 0 173 534 minecraft:cyan_concrete
fill 0 171 544 0 202 544 minecraft:gray_concrete
setblock 0 171 549 minecraft:light_blue_stained_glass
fill 0 171 550 0 173 550 minecraft:cyan_concrete
fill 1 171 552 1 175 552 minecraft:gray_concrete
setblock 2 171 552 minecraft:sea_lantern
fill 4 171 510 4 173 510 minecraft:cyan_concrete
fill 5 171 552 5 180 552 minecraft:gray_concrete
fill 13 171 510 13 199 510 minecraft:gray_concrete
fill 14 171 552 14 173 552 minecraft:cyan_concrete
fill 20 171 510 20 173 510 minecraft:cyan_concrete
setblock 28 171 510 minecraft:light_blue_stained_glass
fill 28 171 552 28 206 552 minecraft:gray_concrete
fill 30 171 552 30 173 552 minecraft:cyan_concrete
fill 32 171 510 32 192 510 minecraft:gray_concrete
setblock 33 171 510 minecraft:light_blue_stained_glass
fill 36 171 510 36 173 510 minecraft:cyan_concrete
fill 42 171 520 42 173 520 minecraft:cyan_concrete
fill 42 171 522 42 206 522 minecraft:gray_concrete
setblock 42 171 532 minecraft:sea_lantern
fill 42 171 536 42 173 536 minecraft:cyan_concrete
setblock 42 171 548 minecraft:white_concrete
fill 0 172 549 0 182 549 minecraft:gray_concrete
setblock 1 172 510 minecraft:sea_lantern
fill 2 172 552 2 202 552 minecraft:gray_concrete
setblock 11 172 552 minecraft:light_blue_stained_glass
fill 28 172 510 28 207 510 minecraft:gray_concrete
fill 28 172 525 28 181 533 minecraft:white_wool
fill 33 172 510 33 202 510 minecraft:gray_concrete
fill 42 172 532 42 207 532 minecraft:gray_concrete
fill 42 172 548 42 207 548 minecraft:gray_concrete
setblock 0 173 529 minecraft:sea_lantern
fill 1 173 510 1 202 510 minecraft:gray_concrete
setblock 3 173 513 minecraft:light[level=11]
setblock 3 173 521 minecraft:light[level=11]
setblock 3 173 529 minecraft:light[level=11]
setblock 3 173 537 minecraft:light[level=11]
setblock 3 173 545 minecraft:light[level=11]
fill 9 173 543 9 174 543 minecraft:light_blue_stained_glass
setblock 11 173 513 minecraft:light[level=11]
setblock 11 173 521 minecraft:light[level=11]
setblock 11 173 529 minecraft:light[level=11]
setblock 11 173 537 minecraft:light[level=11]
setblock 11 173 545 minecraft:light[level=11]
fill 11 173 552 11 175 552 minecraft:gray_concrete
setblock 19 173 513 minecraft:light[level=11]
setblock 19 173 521 minecraft:light[level=11]
setblock 19 173 529 minecraft:light[level=11]
setblock 19 173 537 minecraft:light[level=11]
setblock 19 173 545 minecraft:light[level=11]
setblock 27 173 513 minecraft:light[level=11]
setblock 27 173 521 minecraft:light[level=11]
setblock 27 173 529 minecraft:light[level=11]
setblock 27 173 537 minecraft:light[level=11]
setblock 27 173 545 minecraft:light[level=11]
setblock 35 173 513 minecraft:light[level=11]
setblock 35 173 521 minecraft:light[level=11]
setblock 35 173 529 minecraft:light[level=11]
setblock 35 173 537 minecraft:light[level=11]
setblock 35 173 545 minecraft:light[level=11]
setblock 42 173 541 minecraft:white_concrete
fill 0 174 518 0 179 518 minecraft:gray_concrete
fill 0 174 529 0 174 531 minecraft:gray_concrete
setblock 0 174 532 minecraft:sea_lantern
fill 0 174 533 0 179 534 minecraft:gray_concrete
fill 0 174 550 0 179 550 minecraft:gray_concrete
fill 4 174 510 4 179 510 minecraft:gray_concrete
fill 14 174 535 14 175 535 minecraft:cyan_stained_glass
fill 14 174 552 14 179 552 minecraft:gray_concrete
fill 20 174 510 20 179 510 minecraft:gray_concrete
fill 30 174 552 30 175 552 minecraft:gray_concrete
fill 36 174 510 36 179 510 minecraft:gray_concrete
fill 42 174 520 42 179 520 minecraft:gray_concrete
fill 42 174 536 42 179 536 minecraft:gray_concrete
fill 42 174 541 42 202 541 minecraft:gray_concrete
setblock 42 174 545 minecraft:light_blue_stained_glass
setblock 0 175 529 minecraft:white_concrete
fill 0 175 530 0 202 532 minecraft:gray_concrete
setblock 36 175 552 minecraft:sea_lantern
setblock 42 175 516 minecraft:white_concrete
fill 42 175 517 42 202 517 minecraft:gray_concrete
setblock 42 175 530 minecraft:light_blue_stained_glass
fill 42 175 545 42 204 545 minecraft:gray_concrete
fill 0 176 529 0 199 529 minecraft:gray_concrete
setblock 1 176 552 minecraft:light_blue_stained_glass
fill 5 176 521 5 177 522 minecraft:cyan_stained_glass
setblock 6 176 552 minecraft:white_concrete
setblock 11 176 552 minecraft:white_concrete
setblock 20 176 552 minecraft:white_concrete
fill 26 176 510 26 177 510 minecraft:sea_lantern
setblock 30 176 552 minecraft:sea_lantern
fill 36 176 552 36 206 552 minecraft:gray_concrete
fill 42 176 516 42 178 516 minecraft:gray_concrete
setblock 42 176 525 minecraft:sea_lantern
fill 42 176 530 42 203 530 minecraft:gray_concrete
fill 42 176 533 42 202 534 minecraft:gray_concrete
setblock 42 176 535 minecraft:sea_lantern
setblock 0 177 520 minecraft:white_concrete
setblock 0 177 546 minecraft:white_concrete
fill 1 177 552 1 196 552 minecraft:gray_concrete
fill 6 177 552 6 203 552 minecraft:gray_concrete
fill 11 177 552 11 206 552 minecraft:gray_concrete
fill 20 177 552 20 206 552 minecraft:gray_concrete
setblock 27 177 552 minecraft:white_concrete
fill 30 177 552 30 179 552 minecraft:gray_concrete
fill 42 177 525 42 204 525 minecraft:gray_concrete
fill 42 177 535 42 206 535 minecraft:gray_concrete
setblock 0 178 515 minecraft:light_blue_stained_glass
setblock 0 178 516 minecraft:sea_lantern
fill 0 178 520 0 206 520 minecraft:gray_concrete
fill 0 178 546 0 206 546 minecraft:gray_concrete
fill 26 178 510 26 182 510 minecraft:gray_concrete
fill 27 178 552 27 205 552 minecraft:gray_concrete
fill 0 179 515 0 203 516 minecraft:gray_concrete
setblock 5 179 510 minecraft:sea_lantern
setblock 7 179 510 minecraft:sea_lantern
fill 32 179 528 33 180 528 minecraft:cyan_stained_glass
setblock 42 179 516 minecraft:sea_lantern
setblock 42 179 539 minecraft:white_concrete
fill 0 180 518 0 182 518 minecraft:cyan_concrete
fill 0 180 533 0 184 533 minecraft:gray_concrete
fill 0 180 534 0 182 534 minecraft:cyan_concrete
fill 0 180 550 0 182 550 minecraft:cyan_concrete
fill 4 180 510 4 182 510 minecraft:cyan_concrete
fill 5 180 510 5 202 510 minecraft:gray_concrete
fill 7 180 510 7 181 510 minecraft:gray_concrete
fill 14 180 552 14 182 552 minecraft:cyan_concrete
fill 20 180 510 20 182 510 minecraft:cyan_concrete
fill 30 180 552 30 182 552 minecraft:cyan_concrete
fill 36 180 510 36 182 510 minecraft:cyan_concrete
fill 42 180 516 42 197 516 minecraft:gray_concrete
fill 42 180 520 42 182 520 minecraft:cyan_concrete
fill 42 180 536 42 182 536 minecraft:cyan_concrete
fill 42 180 539 42 193 539 minecraft:gray_concrete
setblock 3 181 513 minecraft:light[level=11]
setblock 3 181 521 minecraft:light[level=11]
setblock 3 181 529 minecraft:light[level=11]
setblock 3 181 537 minecraft:light[level=11]
setblock 3 181 545 minecraft:light[level=11]
setblock 5 181 552 minecraft:light_blue_stained_glass
setblock 11 181 513 minecraft:light[level=11]
setblock 11 181 521 minecraft:light[level=11]
setblock 11 181 529 minecraft:light[level=11]
setblock 11 181 537 minecraft:light[level=11]
setblock 11 181 545 minecraft:light[level=11]
setblock 19 181 513 minecraft:light[level=11]
setblock 19 181 521 minecraft:light[level=11]
setblock 19 181 529 minecraft:light[level=11]
setblock 19 181 537 minecraft:light[level=11]
setblock 19 181 545 minecraft:light[level=11]
setblock 22 181 552 minecraft:sea_lantern
setblock 27 181 513 minecraft:light[level=11]
setblock 27 181 521 minecraft:light[level=11]
setblock 27 181 529 minecraft:light[level=11]
setblock 27 181 537 minecraft:light[level=11]
setblock 27 181 545 minecraft:light[level=11]
setblock 35 181 513 minecraft:light[level=11]
setblock 35 181 521 minecraft:light[level=11]
setblock 35 181 529 minecraft:light[level=11]
setblock 35 181 537 minecraft:light[level=11]
setblock 35 181 545 minecraft:light[level=11]
setblock 42 181 538 minecraft:sea_lantern
fill 5 182 552 5 208 552 minecraft:gray_concrete
setblock 7 182 510 minecraft:sea_lantern
setblock 15 182 510 minecraft:light_blue_stained_glass
fill 22 182 552 22 204 552 minecraft:gray_concrete
fill 28 182 529 28 183 529 minecraft:stripped_dark_oak_log
fill 42 182 538 42 206 538 minecraft:gray_concrete
fill 0 183 518 0 188 518 minecraft:gray_concrete
setblock 0 183 522 minecraft:sea_lantern
fill 0 183 534 0 188 534 minecraft:gray_concrete
setblock 0 183 549 minecraft:sea_lantern
fill 0 183 550 0 188 550 minecraft:gray_concrete
fill 4 183 510 4 188 510 minecraft:gray_concrete
fill 7 183 510 7 196 510 minecraft:gray_concrete
fill 14 183 552 14 188 552 minecraft:gray_concrete
fill 15 183 510 15 206 510 minecraft:gray_concrete
fill 20 183 510 20 188 510 minecraft:gray_concrete
setblock 26 183 510 minecraft:light_blue_stained_glass
fill 30 183 552 30 188 552 minecraft:gray_concrete
fill 36 183 510 36 188 510 minecraft:gray_concrete
fill 42 183 520 42 188 520 minecraft:gray_concrete
fill 42 183 536 42 188 536 minecraft:gray_concrete
setblock 0 184 513 minecraft:light_blue_stained_glass
fill 0 184 522 0 195 522 minecraft:gray_concrete
fill 0 184 549 0 206 549 minecraft:gray_concrete
setblock 4 184 552 minecraft:sea_lantern
fill 26 184 510 26 188 510 minecraft:gray_concrete
setblock 38 184 510 minecraft:light_blue_stained_glass
fill 0 185 513 0 207 513 minecraft:gray_concrete
setblock 0 185 533 minecraft:light_blue_stained_glass
fill 4 185 552 4 206 552 minecraft:gray_concrete
fill 12 185 513 14 188 515 minecraft:light_blue_stained_glass
setblock 34 185 510 minecraft:white_concrete
fill 38 185 510 38 207 510 minecraft:gray_concrete
fill 0 186 533 0 188 533 minecraft:gray_concrete
fill 34 186 510 34 206 510 minecraft:gray_concrete
setblock 0 187 545 minecraft:light_blue_stained_glass
fill 8 187 510 8 206 510 minecraft:gray_concrete
setblock 9 187 510 minecraft:light_blue_stained_glass
setblock 40 187 510 minecraft:white_concrete
fill 0 188 545 0 203 545 minecraft:gray_concrete
fill 9 188 510 9 206 510 minecraft:gray_concrete
fill 40 188 510 40 202 510 minecraft:gray_concrete
setblock 42 188 518 minecraft:light_blue_stained_glass
fill 0 189 518 0 191 518 minecraft:cyan_concrete
setblock 0 189 533 minecraft:sea_lantern
fill 0 189 534 0 191 534 minecraft:cyan_concrete
setblock 0 189 548 minecraft:sea_lantern
fill 0 189 550 0 191 550 minecraft:cyan_concrete
setblock 3 189 513 minecraft:light[level=11]
setblock 3 189 521 minecraft:light[level=11]
fill 3 189 522 5 192 524 minecraft:light_blue_stained_glass
setblock 3 189 529 minecraft:light[level=11]
setblock 3 189 537 minecraft:light[level=11]
setblock 3 189 545 minecraft:light[level=11]
fill 4 189 510 4 191 510 minecraft:cyan_concrete
setblock 11 189 513 minecraft:light[level=11]
setblock 11 189 521 minecraft:light[level=11]
setblock 11 189 529 minecraft:light[level=11]
setblock 11 189 537 minecraft:light[level=11]
setblock 11 189 545 minecraft:light[level=11]
fill 14 189 552 14 191 552 minecraft:cyan_concrete
setblock 19 189 513 minecraft:light[level=11]
setblock 19 189 521 minecraft:light[level=11]
setblock 19 189 529 minecraft:light[level=11]
setblock 19 189 537 minecraft:light[level=11]
setblock 19 189 545 minecraft:light[level=11]
fill 20 189 510 20 191 510 minecraft:cyan_concrete
setblock 24 189 510 minecraft:sea_lantern
setblock 26 189 510 minecraft:light_blue_stained_glass
setblock 27 189 513 minecraft:light[level=11]
setblock 27 189 521 minecraft:light[level=11]
setblock 27 189 529 minecraft:light[level=11]
setblock 27 189 537 minecraft:light[level=11]
setblock 27 189 545 minecraft:light[level=11]
fill 28 189 521 28 190 522 minecraft:light_blue_stained_glass
fill 30 189 552 30 191 552 minecraft:cyan_concrete
setblock 35 189 513 minecraft:light[level=11]
setblock 35 189 521 minecraft:light[level=11]
setblock 35 189 529 minecraft:light[level=11]
setblock 35 189 537 minecraft:light[level=11]
setblock 35 189 545 minecraft:light[level=11]
fill 36 189 510 36 191 510 minecraft:cyan_concrete
fill 36 189 540 38 192 542 minecraft:light_blue_stained_glass
fill 42 189 518 42 202 518 minecraft:gray_concrete
fill 42 189 520 42 191 520 minecraft:cyan_concrete
fill 42 189 536 42 191 536 minecraft:cyan_concrete
setblock 0 190 525 minecraft:white_concrete
fill 0 190 533 0 204 533 minecraft:gray_concrete
fill 0 190 548 0 206 548 minecraft:gray_concrete
setblock 12 190 510 minecraft:light_blue_stained_glass
fill 24 190 510 24 206 510 minecraft:gray_concrete
fill 26 190 510 26 207 510 minecraft:gray_concrete
setblock 35 190 552 minecraft:white_concrete
setblock 0 191 517 minecraft:white_concrete
fill 0 191 525 0 206 525 minecraft:gray_concrete
setblock 0 191 528 minecraft:white_concrete
setblock 0 191 547 minecraft:sea_lantern
fill 12 191 510 12 203 510 minecraft:gray_concrete
setblock 16 191 552 minecraft:light_blue_stained_glass
fill 35 191 552 35 207 552 minecraft:gray_concrete
fill 0 192 517 0 197 518 minecraft:gray_concrete
fill 0 192 528 0 206 528 minecraft:gray_concrete
fill 0 192 534 0 194 534 minecraft:gray_concrete
fill 0 192 547 0 206 547 minecraft:gray_concrete
fill 0 192 550 0 197 550 minecraft:gray_concrete
fill 4 192 510 4 197 510 minecraft:gray_concrete
fill 14 192 552 14 197 552 minecraft:gray_concrete
fill 16 192 552 16 202 552 minecraft:gray_concrete
fill 20 192 510 20 197 510 minecraft:gray_concrete
fill 30 192 552 30 197 552 minecraft:gray_concrete
fill 36 192 510 36 197 510 minecraft:gray_concrete
setblock 42 192 513 minecraft:light_blue_stained_glass
setblock 42 192 515 minecraft:light_blue_stained_glass
fill 42 192 520 42 197 520 minecraft:gray_concrete
fill 42 192 536 42 197 536 minecraft:gray_concrete
setblock 32 193 510 minecraft:white_concrete
fill 42 193 513 42 197 513 minecraft:gray_concrete
fill 42 193 515 42 203 515 minecraft:gray_concrete
setblock 0 194 535 minecraft:light_blue_stained_glass
fill 0 194 536 0 203 536 minecraft:gray_concrete
setblock 0 194 537 minecraft:white_concrete
fill 25 194 552 25 208 552 minecraft:gray_concrete
setblock 26 194 552 minecraft:sea_lantern
fill 32 194 510 32 206 510 minecraft:gray_concrete
fill 32 194 526 33 195 527 minecraft:light_blue_stained_glass
setblock 42 194 539 minecraft:sea_lantern
setblock 0 195 534 minecraft:light_blue_stained_glass
fill 0 195 535 0 199 535 minecraft:gray_concrete
fill 0 195 537 0 203 537 minecraft:gray_concrete
fill 12 195 546 14 198 548 minecraft:light_blue_stained_glass
fill 26 195 552 26 206 552 minecraft:gray_concrete
setblock 42 195 519 minecraft:white_concrete
fill 42 195 539 42 204 539 minecraft:gray_concrete
setblock 42 195 544 minecraft:light_blue_stained_glass
fill 0 196 522 0 197 522 minecraft:sea_lantern
fill 0 196 534 0 197 534 minecraft:gray_concrete
fill 42 196 519 42 206 519 minecraft:gray_concrete
setblock 42 196 544 minecraft:gray_concrete
setblock 1 197 552 minecraft:light_blue_stained_glass
setblock 3 197 513 minecraft:light[level=11]
setblock 3 197 521 minecraft:light[level=11]
setblock 3 197 529 minecraft:light[level=11]
setblock 3 197 537 minecraft:light[level=11]
setblock 3 197 545 minecraft:light[level=11]
setblock 7 197 510 minecraft:sea_lantern
setblock 11 197 513 minecraft:light[level=11]
setblock 11 197 521 minecraft:light[level=11]
setblock 11 197 529 minecraft:light[level=11]
setblock 11 197 537 minecraft:light[level=11]
setblock 11 197 545 minecraft:light[level=11]
setblock 19 197 513 minecraft:light[level=11]
setblock 19 197 521 minecraft:light[level=11]
setblock 19 197 529 minecraft:light[level=11]
setblock 19 197 537 minecraft:light[level=11]
setblock 19 197 545 minecraft:light[level=11]
setblock 27 197 513 minecraft:light[level=11]
setblock 27 197 521 minecraft:light[level=11]
setblock 27 197 529 minecraft:light[level=11]
setblock 27 197 537 minecraft:light[level=11]
setblock 27 197 545 minecraft:light[level=11]
setblock 35 197 513 minecraft:light[level=11]
setblock 35 197 521 minecraft:light[level=11]
setblock 35 197 529 minecraft:light[level=11]
setblock 35 197 537 minecraft:light[level=11]
setblock 35 197 545 minecraft:light[level=11]
setblock 42 197 544 minecraft:sea_lantern
fill 0 198 510 0 206 510 minecraft:gray_concrete
setblock 0 198 511 minecraft:light_blue_stained_glass
fill 0 198 517 0 206 517 minecraft:gray_concrete
fill 0 198 518 0 200 518 minecraft:cyan_concrete
setblock 0 198 522 minecraft:gray_concrete
fill 0 198 534 0 200 534 minecraft:cyan_concrete
fill 0 198 550 0 200 550 minecraft:cyan_concrete
fill 1 198 552 1 204 552 minecraft:gray_concrete
fill 4 198 510 4 200 510 minecraft:cyan_concrete
fill 7 198 510 7 206 510 minecraft:gray_concrete
setblock 14 198 510 minecraft:light_blue_stained_glass
fill 14 198 552 14 200 552 minecraft:cyan_concrete
fill 20 198 510 20 200 510 minecraft:cyan_concrete
fill 30 198 552 30 200 552 minecraft:cyan_concrete
fill 36 198 510 36 200 510 minecraft:cyan_concrete
setblock 42 198 513 minecraft:white_concrete
setblock 42 198 516 minecraft:sea_lantern
fill 42 198 520 42 200 520 minecraft:cyan_concrete
setblock 42 198 526 minecraft:white_concrete
fill 42 198 536 42 200 536 minecraft:cyan_concrete
fill 42 198 544 42 206 544 minecraft:gray_concrete
fill 0 199 511 0 206 511 minecraft:gray_concrete
setblock 0 199 522 minecraft:sea_lantern
setblock 0 199 523 minecraft:white_concrete
setblock 2 199 510 minecraft:sea_lantern
fill 14 199 510 14 205 510 minecraft:gray_concrete
fill 42 199 513 42 206 513 minecraft:gray_concrete
fill 42 199 516 42 206 516 minecraft:gray_concrete
fill 42 199 526 42 206 526 minecraft:gray_concrete
setblock 42 199 542 minecraft:white_concrete
fill 0 200 522 0 203 523 minecraft:gray_concrete
setblock 0 200 529 minecraft:sea_lantern
setblock 0 200 535 minecraft:sea_lantern
fill 2 200 510 2 206 510 minecraft:gray_concrete
setblock 13 200 510 minecraft:sea_lantern
setblock 21 200 510 minecraft:light_blue_stained_glass
setblock 31 200 552 minecraft:light_blue_stained_glass
fill 42 200 542 42 206 542 minecraft:gray_concrete
fill 0 201 518 0 206 518 minecraft:gray_concrete
fill 0 201 529 0 202 529 minecraft:gray_concrete
fill 0 201 534 0 206 535 minecraft:gray_concrete
fill 0 201 550 0 206 550 minecraft:gray_concrete
fill 4 201 510 4 206 510 minecraft:gray_concrete
fill 13 201 510 13 206 510 minecraft:gray_concrete
fill 14 201 552 14 202 552 minecraft:gray_concrete
fill 20 201 510 21 201 510 minecraft:gray_concrete
fill 30 201 552 31 204 552 minecraft:gray_concrete
fill 36 201 510 36 206 510 minecraft:gray_concrete
setblock 42 201 514 minecraft:white_concrete
fill 42 201 520 42 202 520 minecraft:gray_concrete
setblock 42 201 528 minecraft:sea_lantern
fill 42 201 536 42 206 536 minecraft:gray_concrete
setblock 20 202 510 minecraft:sea_lantern
fill 21 202 510 21 204 510 minecraft:gray_concrete
fill 36 202 548 36 216 548 minecraft:iron_block
fill 42 202 514 42 206 514 minecraft:gray_concrete
fill 42 202 528 42 203 528 minecraft:gray_concrete
fill 0 203 529 0 203 530 minecraft:black_concrete
fill 0 203 531 0 203 532 minecraft:gray_concrete
setblock 0 203 540 minecraft:black_concrete
fill 0 203 543 0 203 544 minecraft:black_concrete
setblock 1 203 510 minecraft:sea_lantern
setblock 2 203 552 minecraft:black_concrete
setblock 5 203 510 minecraft:light_blue_stained_glass
fill 8 203 523 8 204 523 minecraft:light_blue_stained_glass
fill 11 203 544 15 204 548 minecraft:black_concrete
fill 13 203 549 13 203 550 minecraft:black_concrete
setblock 14 203 552 minecraft:sea_lantern
fill 16 203 552 16 204 552 minecraft:black_concrete
setblock 18 203 510 minecraft:black_concrete
fill 20 203 510 20 206 510 minecraft:gray_concrete
setblock 33 203 510 minecraft:black_concrete
fill 33 203 528 33 204 528 minecraft:light_blue_stained_glass
setblock 39 203 552 minecraft:black_concrete
setblock 40 203 510 minecraft:black_concrete
fill 42 203 517 42 203 518 minecraft:black_concrete
setblock 42 203 520 minecraft:black_concrete
setblock 42 203 523 minecraft:sea_lantern
setblock 42 203 529 minecraft:black_concrete
setblock 42 203 533 minecraft:black_concrete
fill 42 203 534 42 206 534 minecraft:gray_concrete
setblock 42 203 541 minecraft:black_concrete
setblock 42 203 552 minecraft:black_concrete
setblock 0 204 515 minecraft:black_concrete
fill 0 204 516 0 206 516 minecraft:gray_concrete
fill 0 204 522 0 206 522 minecraft:gray_concrete
setblock 0 204 523 minecraft:black_concrete
fill 0 204 529 0 206 530 minecraft:gray_concrete
setblock 0 204 531 minecraft:black_concrete
fill 0 204 532 0 205 532 minecraft:gray_concrete
fill 0 204 536 0 204 537 minecraft:black_concrete
fill 0 204 540 0 206 540 minecraft:gray_concrete
fill 0 204 543 0 206 544 minecraft:gray_concrete
setblock 0 204 545 minecraft:black_concrete
fill 1 204 510 1 206 510 minecraft:gray_concrete
fill 2 204 552 2 206 552 minecraft:gray_concrete
fill 5 204 510 5 206 510 minecraft:gray_concrete
setblock 6 204 552 minecraft:black_concrete
fill 9 204 523 10 205 523 minecraft:light_blue_stained_glass
setblock 10 204 510 minecraft:black_concrete
setblock 12 204 510 minecraft:black_concrete
setblock 12 204 552 minecraft:black_concrete
fill 14 204 552 14 206 552 minecraft:gray_concrete
setblock 16 204 510 minecraft:black_concrete
fill 18 204 510 18 206 510 minecraft:gray_concrete
setblock 18 204 552 minecraft:black_concrete
fill 33 204 510 33 206 510 minecraft:gray_concrete
setblock 37 204 552 minecraft:black_concrete
setblock 39 204 552 minecraft:gray_concrete
fill 40 204 510 40 206 510 minecraft:gray_concrete
setblock 41 204 552 minecraft:black_concrete
setblock 42 204 515 minecraft:light_blue_stained_glass
fill 42 204 517 42 206 518 minecraft:gray_concrete
fill 42 204 520 42 205 520 minecraft:gray_concrete
fill 42 204 523 42 207 523 minecraft:gray_concrete
fill 42 204 527 42 204 528 minecraft:black_concrete
fill 42 204 529 42 206 529 minecraft:gray_concrete
setblock 42 204 530 minecraft:light_blue_stained_glass
setblock 42 204 531 minecraft:black_concrete
fill 42 204 533 42 206 533 minecraft:gray_concrete
setblock 42 204 541 minecraft:gray_concrete
fill 42 204 552 42 206 552 minecraft:gray_concrete
fill 0 205 515 0 206 515 minecraft:gray_concrete
fill 0 205 523 0 206 523 minecraft:gray_concrete
fill 0 205 531 0 206 531 minecraft:gray_concrete
setblock 0 205 533 minecraft:black_concrete
fill 0 205 536 0 206 537 minecraft:gray_concrete
fill 0 205 538 0 205 539 minecraft:black_concrete
fill 0 205 545 0 206 545 minecraft:gray_concrete
setblock 1 205 552 minecraft:black_concrete
setblock 3 205 513 minecraft:light[level=11]
setblock 3 205 521 minecraft:light[level=11]
setblock 3 205 529 minecraft:light[level=11]
setblock 3 205 537 minecraft:light[level=11]
setblock 3 205 545 minecraft:light[level=11]
fill 6 205 552 6 206 552 minecraft:gray_concrete
fill 10 205 510 10 206 510 minecraft:gray_concrete
setblock 11 205 510 minecraft:black_concrete
setblock 11 205 513 minecraft:light[level=11]
setblock 11 205 521 minecraft:light[level=11]
setblock 11 205 529 minecraft:light[level=11]
setblock 11 205 537 minecraft:light[level=11]
setblock 11 205 545 minecraft:light[level=11]
fill 12 205 510 12 206 510 minecraft:gray_concrete
fill 12 205 546 14 209 546 minecraft:black_wool
fill 12 205 552 12 206 552 minecraft:gray_concrete
fill 16 205 510 16 206 510 minecraft:gray_concrete
fill 16 205 552 16 206 552 minecraft:gray_concrete
fill 18 205 552 18 206 552 minecraft:gray_concrete
setblock 19 205 513 minecraft:light[level=11]
setblock 19 205 521 minecraft:light[level=11]
setblock 19 205 529 minecraft:light[level=11]
setblock 19 205 537 minecraft:light[level=11]
setblock 19 205 545 minecraft:light[level=11]
setblock 21 205 510 minecraft:black_concrete
setblock 22 205 552 minecraft:white_concrete
setblock 27 205 513 minecraft:light[level=11]
setblock 27 205 521 minecraft:light[level=11]
setblock 27 205 529 minecraft:light[level=11]
setblock 27 205 537 minecraft:light[level=11]
setblock 27 205 545 minecraft:light[level=11]
fill 30 205 552 30 206 552 minecraft:gray_concrete
fill 31 205 552 32 205 552 minecraft:black_concrete
fill 33 205 552 33 206 552 minecraft:gray_concrete
setblock 35 205 510 minecraft:black_concrete
setblock 35 205 513 minecraft:light[level=11]
setblock 35 205 521 minecraft:light[level=11]
setblock 35 205 529 minecraft:light[level=11]
setblock 35 205 537 minecraft:light[level=11]
setblock 35 205 545 minecraft:light[level=11]
fill 37 205 552 37 206 552 minecraft:gray_concrete
setblock 39 205 552 minecraft:black_concrete
fill 41 205 552 41 206 552 minecraft:gray_concrete
fill 42 205 515 42 207 515 minecraft:gray_concrete
setblock 42 205 525 minecraft:black_concrete
fill 42 205 527 42 206 528 minecraft:gray_concrete
setblock 42 205 530 minecraft:sea_lantern
fill 42 205 531 42 206 531 minecraft:gray_concrete
setblock 42 205 539 minecraft:white_concrete
setblock 42 205 541 minecraft:black_concrete
setblock 42 205 543 minecraft:black_concrete
setblock 42 205 545 minecraft:black_concrete
setblock 42 205 549 minecraft:light_blue_stained_glass
setblock 42 205 550 minecraft:black_concrete
setblock 0 206 532 minecraft:sea_lantern
setblock 0 206 533 minecraft:gray_concrete
fill 0 206 538 0 206 539 minecraft:gray_concrete
setblock 1 206 552 minecraft:gray_concrete
setblock 11 206 510 minecraft:gray_concrete
setblock 14 206 510 minecraft:white_concrete
setblock 21 206 510 minecraft:gray_concrete
setblock 22 206 552 minecraft:gray_concrete
setblock 27 206 552 minecraft:white_concrete
fill 31 206 552 32 206 552 minecraft:gray_concrete
setblock 35 206 510 minecraft:gray_concrete
setblock 39 206 552 minecraft:gray_concrete
setblock 42 206 520 minecraft:white_concrete
setblock 42 206 525 minecraft:gray_concrete
setblock 42 206 530 minecraft:gray_concrete
setblock 42 206 539 minecraft:gray_concrete
setblock 42 206 541 minecraft:gray_concrete
setblock 42 206 543 minecraft:gray_concrete
fill 42 206 545 42 207 545 minecraft:gray_concrete
fill 42 206 549 42 208 549 minecraft:gray_concrete
setblock 42 206 550 minecraft:light_blue_stained_glass
fill 0 207 510 0 208 512 minecraft:black_concrete
fill 0 207 514 0 209 517 minecraft:black_concrete
fill 0 207 518 0 209 518 minecraft:cyan_concrete
fill 0 207 519 0 207 533 minecraft:black_concrete
fill 0 207 534 0 209 534 minecraft:cyan_concrete
fill 0 207 535 0 218 537 minecraft:black_concrete
setblock 0 207 538 minecraft:gray_concrete
fill 0 207 539 0 211 549 minecraft:black_concrete
fill 0 207 550 0 209 550 minecraft:cyan_concrete
setblock 0 207 551 minecraft:light_blue_stained_glass
fill 0 207 552 4 240 552 minecraft:black_concrete
fill 1 207 510 2 230 510 minecraft:black_concrete
fill 4 207 510 4 209 510 minecraft:cyan_concrete
fill 5 207 510 13 207 510 minecraft:black_concrete
fill 6 207 552 12 208 552 minecraft:black_concrete
setblock 14 207 510 minecraft:gray_concrete
fill 14 207 552 14 209 552 minecraft:cyan_concrete
fill 15 207 510 19 207 510 minecraft:black_concrete
fill 15 207 552 24 225 552 minecraft:black_concrete
fill 20 207 510 20 209 510 minecraft:cyan_concrete
fill 21 207 510 25 207 510 minecraft:black_concrete
fill 26 207 552 29 244 552 minecraft:black_concrete
setblock 27 207 510 minecraft:black_concrete
fill 29 207 510 35 207 510 minecraft:black_concrete
fill 30 207 552 30 209 552 minecraft:cyan_concrete
fill 31 207 552 33 208 552 minecraft:black_concrete
fill 36 207 510 36 209 510 minecraft:cyan_concrete
fill 36 207 552 42 208 552 minecraft:black_concrete
fill 37 207 510 37 280 510 minecraft:black_concrete
fill 39 207 510 42 207 510 minecraft:black_concrete
fill 42 207 511 42 219 514 minecraft:black_concrete
fill 42 207 516 42 207 519 minecraft:black_concrete
fill 42 207 520 42 209 520 minecraft:cyan_concrete
fill 42 207 521 42 216 522 minecraft:black_concrete
fill 42 207 524 42 208 527 minecraft:black_concrete
setblock 42 207 528 minecraft:white_concrete
fill 42 207 529 42 208 531 minecraft:black_concrete
fill 42 207 533 42 207 535 minecraft:black_concrete
fill 42 207 536 42 209 536 minecraft:cyan_concrete
fill 42 207 537 42 207 544 minecraft:black_concrete
setblock 42 207 546 minecraft:sea_lantern
fill 42 207 547 42 307 547 minecraft:black_concrete
fill 42 207 550 42 215 551 minecraft:black_concrete
fill 0 208 513 0 239 513 minecraft:black_concrete
fill 0 208 519 0 208 524 minecraft:black_concrete
fill 0 208 525 0 209 525 minecraft:gray_concrete
fill 0 208 526 0 208 532 minecraft:black_concrete
setblock 0 208 533 minecraft:sea_lantern
fill 0 208 538 0 227 538 minecraft:black_concrete
fill 0 208 551 0 209 551 minecraft:gray_concrete
fill 3 208 510 3 270 510 minecraft:black_concrete
setblock 5 208 510 minecraft:black_concrete
setblock 6 208 510 minecraft:light_blue_stained_glass
fill 7 208 510 9 211 510 minecraft:black_concrete
setblock 10 208 510 minecraft:gray_concrete
fill 11 208 510 16 224 510 minecraft:black_concrete
fill 13 208 545 13 209 545 minecraft:black_wool
fill 13 208 547 13 209 547 minecraft:black_wool
fill 13 208 552 13 307 552 minecraft:black_concrete
setblock 17 208 510 minecraft:gray_concrete
fill 18 208 510 19 255 510 minecraft:black_concrete
fill 21 208 510 22 281 510 minecraft:black_concrete
setblock 23 208 510 minecraft:gray_concrete
fill 24 208 510 26 208 510 minecraft:black_concrete
setblock 27 208 510 minecraft:gray_concrete
fill 28 208 510 28 218 510 minecraft:black_concrete
setblock 29 208 510 minecraft:gray_concrete
fill 30 208 510 30 224 510 minecraft:black_concrete
setblock 31 208 510 minecraft:white_concrete
fill 32 208 510 35 208 510 minecraft:black_concrete
fill 34 208 552 35 237 552 minecraft:black_concrete
fill 37 208 535 37 221 535 minecraft:iron_block
fill 38 208 510 40 245 510 minecraft:black_concrete
fill 41 208 510 42 208 510 minecraft:gray_concrete
fill 42 208 515 42 208 517 minecraft:black_concrete
fill 42 208 518 42 208 519 minecraft:gray_concrete
fill 42 208 523 42 267 523 minecraft:black_concrete
setblock 42 208 528 minecraft:black_concrete
fill 42 208 532 42 208 534 minecraft:black_concrete
setblock 42 208 535 minecraft:gray_concrete
fill 42 208 537 42 218 538 minecraft:black_concrete
setblock 42 208 539 minecraft:gray_concrete
fill 42 208 540 42 208 543 minecraft:black_concrete
setblock 42 208 544 minecraft:gray_concrete
fill 42 208 545 42 289 546 minecraft:black_concrete
setblock 42 208 548 minecraft:black_concrete
fill 0 209 510 0 307 510 minecraft:black_concrete
setblock 0 209 511 minecraft:gray_concrete
fill 0 209 512 0 307 512 minecraft:black_concrete
fill 0 209 519 0 249 520 minecraft:black_concrete
setblock 0 209 521 minecraft:gray_concrete
fill 0 209 522 0 243 523 minecraft:black_concrete
setblock 0 209 524 minecraft:light_blue_stained_glass
fill 0 209 526 0 221 529 minecraft:black_concrete
setblock 0 209 530 minecraft:white_concrete
fill 0 209 531 0 216 533 minecraft:black_concrete
setblock 5 209 510 minecraft:gray_concrete
fill 5 209 552 6 225 552 minecraft:black_concrete
fill 6 209 510 6 256 510 minecraft:black_concrete
setblock 7 209 552 minecraft:gray_concrete
fill 8 209 552 12 230 552 minecraft:black_concrete
fill 10 209 510 10 250 510 minecraft:black_concrete
fill 17 209 510 17 247 510 minecraft:black_concrete
fill 23 209 510 25 215 510 minecraft:black_concrete
fill 25 209 552 25 246 552 minecraft:black_concrete
setblock 26 209 510 minecraft:light_blue_stained_glass
fill 27 209 510 27 294 510 minecraft:black_concrete
fill 29 209 510 29 221 510 minecraft:black_concrete
fill 31 209 510 31 246 510 minecraft:black_concrete
fill 31 209 552 32 245 552 minecraft:black_concrete
setblock 32 209 510 minecraft:gray_concrete
fill 33 209 510 35 214 510 minecraft:black_concrete
setblock 33 209 552 minecraft:sea_lantern
fill 36 209 552 39 211 552 minecraft:black_concrete
setblock 40 209 552 minecraft:white_concrete
fill 41 209 510 42 213 510 minecraft:black_concrete
fill 41 209 552 42 286 552 minecraft:black_concrete
fill 42 209 515 42 212 516 minecraft:black_concrete
fill 42 209 517 42 209 518 minecraft:gray_concrete
fill 42 209 519 42 307 519 minecraft:black_concrete
fill 42 209 524 42 212 526 minecraft:black_concrete
setblock 42 209 527 minecraft:gray_concrete
setblock 42 209 528 minecraft:light_blue_stained_glass
fill 42 209 529 42 232 530 minecraft:black_concrete
setblock 42 209 531 minecraft:gray_concrete
fill 42 209 532 42 258 533 minecraft:black_concrete
setblock 42 209 534 minecraft:light_blue_stained_glass
fill 42 209 535 42 239 535 minecraft:black_concrete
fill 42 209 539 42 217 541 minecraft:black_concrete
setblock 42 209 542 minecraft:white_concrete
fill 42 209 543 42 219 544 minecraft:black_concrete
setblock 42 209 548 minecraft:gray_concrete
fill 42 209 549 42 227 549 minecraft:black_concrete
fill 0 210 511 0 215 511 minecraft:black_concrete
fill 0 210 514 0 212 516 minecraft:black_concrete
setblock 0 210 517 minecraft:white_concrete
fill 0 210 518 0 215 518 minecraft:black_concrete
fill 0 210 521 0 239 521 minecraft:black_concrete
fill 0 210 524 0 264 525 minecraft:black_concrete
fill 0 210 530 0 228 530 minecraft:black_concrete
fill 0 210 534 0 215 534 minecraft:black_concrete
fill 0 210 550 0 212 551 minecraft:black_concrete
fill 4 210 510 5 215 510 minecraft:black_concrete
fill 7 210 552 7 266 552 minecraft:black_concrete
fill 14 210 552 14 215 552 minecraft:black_concrete
fill 20 210 510 20 215 510 minecraft:black_concrete
fill 26 210 510 26 212 510 minecraft:black_concrete
fill 30 210 552 30 215 552 minecraft:black_concrete
fill 32 210 510 32 233 510 minecraft:black_concrete
fill 33 210 552 33 307 552 minecraft:black_concrete
fill 36 210 510 36 215 510 minecraft:black_concrete
fill 40 210 552 40 243 552 minecraft:black_concrete
fill 42 210 517 42 233 518 minecraft:black_concrete
fill 42 210 520 42 215 520 minecraft:black_concrete
fill 42 210 527 42 214 528 minecraft:black_concrete
fill 42 210 531 42 236 531 minecraft:black_concrete
fill 42 210 534 42 307 534 minecraft:black_concrete
fill 42 210 536 42 215 536 minecraft:black_concrete
fill 42 210 542 42 212 542 minecraft:black_concrete
fill 42 210 548 42 305 548 minecraft:black_concrete
fill 0 211 517 0 229 517 minecraft:black_concrete
fill 17 211 518 18 212 518 minecraft:light_blue_stained_glass
fill 0 212 539 0 241 540 minecraft:black_concrete
setblock 0 212 541 minecraft:light_blue_stained_glass
fill 0 212 542 0 214 549 minecraft:black_concrete
fill 7 212 510 8 244 510 minecraft:black_concrete
setblock 9 212 510 minecraft:light_blue_stained_glass
setblock 36 212 552 minecraft:light_blue_stained_glass
fill 37 212 552 39 229 552 minecraft:black_concrete
fill 0 213 514 0 247 515 minecraft:black_concrete
setblock 0 213 516 minecraft:light_blue_stained_glass
fill 0 213 541 0 307 541 minecraft:black_concrete
setblock 0 213 550 minecraft:light_blue_stained_glass
setblock 0 213 551 minecraft:black_concrete
setblock 3 213 513 minecraft:light[level=11]
setblock 3 213 521 minecraft:light[level=11]
setblock 3 213 529 minecraft:light[level=11]
setblock 3 213 537 minecraft:light[level=11]
setblock 3 213 545 minecraft:light[level=11]
fill 9 213 510 9 217 510 minecraft:black_concrete
setblock 11 213 513 minecraft:light[level=11]
setblock 11 213 521 minecraft:light[level=11]
setblock 11 213 529 minecraft:light[level=11]
setblock 11 213 537 minecraft:light[level=11]
setblock 11 213 545 minecraft:light[level=11]
setblock 19 213 513 minecraft:light[level=11]
setblock 19 213 521 minecraft:light[level=11]
setblock 19 213 529 minecraft:light[level=11]
setblock 19 213 537 minecraft:light[level=11]
setblock 19 213 545 minecraft:light[level=11]
setblock 26 213 510 minecraft:light_blue_stained_glass
setblock 27 213 513 minecraft:light[level=11]
setblock 27 213 521 minecraft:light[level=11]
setblock 27 213 529 minecraft:light[level=11]
setblock 27 213 537 minecraft:light[level=11]
setblock 27 213 545 minecraft:light[level=11]
setblock 35 213 513 minecraft:light[level=11]
setblock 35 213 521 minecraft:light[level=11]
setblock 35 213 529 minecraft:light[level=11]
setblock 35 213 537 minecraft:light[level=11]
setblock 35 213 545 minecraft:light[level=11]
fill 36 213 552 36 232 552 minecraft:black_concrete
fill 42 213 515 42 242 515 minecraft:black_concrete
setblock 42 213 516 minecraft:white_concrete
setblock 42 213 524 minecraft:sea_lantern
fill 42 213 525 42 283 526 minecraft:black_concrete
setblock 42 213 542 minecraft:light_blue_stained_glass
fill 0 214 516 0 292 516 minecraft:black_concrete
fill 0 214 550 0 215 550 minecraft:black_concrete
setblock 0 214 551 minecraft:light_blue_stained_glass
fill 26 214 510 26 307 510 minecraft:black_concrete
setblock 41 214 510 minecraft:sea_lantern
fill 42 214 510 42 307 510 minecraft:black_concrete
fill 42 214 516 42 230 516 minecraft:black_concrete
fill 42 214 524 42 307 524 minecraft:black_concrete
setblock 42 214 542 minecraft:sea_lantern
fill 0 215 542 0 221 548 minecraft:black_concrete
setblock 0 215 549 minecraft:light_blue_stained_glass
fill 0 215 551 0 232 551 minecraft:black_concrete
fill 33 215 510 33 304 510 minecraft:black_concrete
setblock 34 215 510 minecraft:white_concrete
fill 35 215 510 35 239 510 minecraft:black_concrete
fill 41 215 510 41 287 510 minecraft:black_concrete
setblock 42 215 527 minecraft:light_blue_stained_glass
fill 42 215 528 42 275 528 minecraft:black_concrete
fill 42 215 542 42 261 542 minecraft:black_concrete
setblock 0 216 511 minecraft:light_blue_stained_glass
fill 0 216 518 0 218 518 minecraft:cyan_concrete
fill 0 216 534 0 218 534 minecraft:cyan_concrete
fill 0 216 549 0 228 549 minecraft:black_concrete
fill 0 216 550 0 218 550 minecraft:cyan_concrete
fill 4 216 510 4 218 510 minecraft:cyan_concrete
fill 5 216 510 5 230 510 minecraft:black_concrete
fill 14 216 552 14 218 552 minecraft:cyan_concrete
fill 20 216 510 20 218 510 minecraft:cyan_concrete
fill 23 216 510 23 257 510 minecraft:black_concrete
setblock 24 216 510 minecraft:sea_lantern
fill 25 216 510 25 241 510 minecraft:black_concrete
fill 30 216 552 30 218 552 minecraft:cyan_concrete
fill 34 216 510 34 240 510 minecraft:black_concrete
fill 36 216 510 36 218 510 minecraft:cyan_concrete
fill 42 216 520 42 218 520 minecraft:cyan_concrete
fill 42 216 527 42 219 527 minecraft:black_concrete
fill 42 216 536 42 218 536 minecraft:cyan_concrete
fill 42 216 550 42 307 550 minecraft:black_concrete
setblock 42 216 551 minecraft:sea_lantern
fill 0 217 511 0 250 511 minecraft:black_concrete
fill 0 217 531 0 244 532 minecraft:black_concrete
setblock 0 217 533 minecraft:sea_lantern
fill 8 217 516 8 218 518 minecraft:cyan_stained_glass
fill 9 217 517 9 218 517 minecraft:cyan_stained_glass
fill 24 217 510 24 290 510 minecraft:black_concrete
setblock 42 217 521 minecraft:sea_lantern
fill 42 217 522 42 307 522 minecraft:black_concrete
fill 42 217 551 42 307 551 minecraft:black_concrete
fill 0 218 533 0 237 533 minecraft:black_concrete
setblock 9 218 510 minecraft:white_concrete
fill 42 218 521 42 238 521 minecraft:black_concrete
fill 42 218 539 42 249 539 minecraft:black_concrete
setblock 42 218 540 minecraft:white_concrete
fill 42 218 541 42 307 541 minecraft:black_concrete
fill 0 219 518 0 233 518 minecraft:black_concrete
fill 0 219 534 0 233 534 minecraft:black_concrete
setblock 0 219 535 minecraft:light_blue_stained_glass
fill 0 219 536 0 222 537 minecraft:black_concrete
fill 0 219 550 0 233 550 minecraft:black_concrete
fill 4 219 510 4 233 510 minecraft:black_concrete
fill 9 219 510 9 224 510 minecraft:black_concrete
setblock 14 219 552 minecraft:black_concrete
fill 20 219 510 20 233 510 minecraft:black_concrete
setblock 28 219 510 minecraft:sea_lantern
fill 30 219 552 30 221 552 minecraft:black_concrete
fill 36 219 510 36 233 510 minecraft:black_concrete
fill 42 219 520 42 233 520 minecraft:black_concrete
fill 42 219 536 42 232 536 minecraft:black_concrete
fill 42 219 537 42 220 537 minecraft:sea_lantern
fill 42 219 538 42 222 538 minecraft:black_concrete
fill 42 219 540 42 258 540 minecraft:black_concrete
fill 0 220 535 0 249 535 minecraft:black_concrete
setblock 14 220 552 minecraft:light_blue_stained_glass
fill 28 220 510 28 307 510 minecraft:black_concrete
fill 36 220 515 38 222 517 minecraft:light_blue_stained_glass
fill 42 220 511 42 264 513 minecraft:black_concrete
setblock 42 220 514 minecraft:light_blue_stained_glass
setblock 42 220 527 minecraft:sea_lantern
fill 42 220 543 42 307 543 minecraft:black_concrete
setblock 42 220 544 minecraft:light_blue_stained_glass
setblock 3 221 513 minecraft:light[level=11]
setblock 3 221 521 minecraft:light[level=11]
fill 3 221 527 5 222 529 minecraft:light_blue_stained_glass
setblock 3 221 537 minecraft:light[level=11]
setblock 3 221 545 minecraft:light[level=11]
setblock 11 221 513 minecraft:light[level=11]
setblock 11 221 521 minecraft:light[level=11]
setblock 11 221 529 minecraft:light[level=11]
setblock 11 221 537 minecraft:light[level=11]
setblock 11 221 545 minecraft:light[level=11]
fill 14 221 552 14 224 552 minecraft:black_concrete
setblock 19 221 513 minecraft:light[level=11]
setblock 19 221 521 minecraft:light[level=11]
setblock 19 221 529 minecraft:light[level=11]
setblock 19 221 537 minecraft:light[level=11]
setblock 19 221 545 minecraft:light[level=11]
setblock 27 221 513 minecraft:light[level=11]
setblock 27 221 521 minecraft:light[level=11]
setblock 27 221 529 minecraft:light[level=11]
setblock 27 221 537 minecraft:light[level=11]
setblock 27 221 545 minecraft:light[level=11]
setblock 35 221 513 minecraft:light[level=11]
setblock 35 221 521 minecraft:light[level=11]
setblock 35 221 529 minecraft:light[level=11]
setblock 35 221 537 minecraft:light[level=11]
setblock 35 221 545 minecraft:light[level=11]
fill 42 221 514 42 289 514 minecraft:black_concrete
fill 42 221 527 42 266 527 minecraft:black_concrete
fill 42 221 537 42 242 537 minecraft:black_concrete
fill 42 221 544 42 269 544 minecraft:black_concrete
setblock 0 222 526 minecraft:sea_lantern
fill 0 222 527 0 230 529 minecraft:black_concrete
fill 0 222 542 0 227 545 minecraft:black_concrete
setblock 0 222 546 minecraft:sea_lantern
fill 0 222 547 0 238 548 minecraft:black_concrete
setblock 29 222 510 minecraft:sea_lantern
setblock 30 222 552 minecraft:light_blue_stained_glass
fill 0 223 526 0 307 526 minecraft:black_concrete
setblock 0 223 536 minecraft:white_concrete
fill 0 223 537 0 253 537 minecraft:black_concrete
fill 0 223 546 0 233 546 minecraft:black_concrete
fill 29 223 510 29 307 510 minecraft:black_concrete
fill 30 223 552 30 233 552 minecraft:black_concrete
setblock 42 223 538 minecraft:white_concrete
fill 0 224 536 0 274 536 minecraft:black_concrete
fill 42 224 538 42 244 538 minecraft:black_concrete
setblock 9 225 510 minecraft:white_concrete
setblock 11 225 510 minecraft:sea_lantern
fill 12 225 510 16 230 510 minecraft:black_concrete
setblock 14 225 552 minecraft:light_blue_stained_glass
setblock 30 225 510 minecraft:sea_lantern
setblock 5 226 552 minecraft:white_concrete
fill 6 226 552 6 307 552 minecraft:black_concrete
fill 9 226 510 9 248 510 minecraft:black_concrete
fill 11 226 510 11 307 510 minecraft:black_concrete
fill 14 226 552 18 233 552 minecraft:black_concrete
setblock 19 226 552 minecraft:light_blue_stained_glass
fill 20 226 552 24 227 552 minecraft:black_concrete
fill 30 226 510 30 280 510 minecraft:black_concrete
fill 5 227 552 5 229 552 minecraft:black_concrete
fill 19 227 552 19 237 552 minecraft:black_concrete
setblock 0 228 538 minecraft:sea_lantern
fill 0 228 542 0 231 544 minecraft:black_concrete
setblock 0 228 545 minecraft:white_concrete
fill 10 228 528 10 228 531 minecraft:iron_block
setblock 10 228 532 minecraft:black_concrete
fill 10 228 533 10 228 536 minecraft:iron_block
fill 11 228 526 11 228 527 minecraft:iron_block
setblock 11 228 528 minecraft:black_concrete
setblock 11 228 529 minecraft:gray_concrete
fill 11 228 530 11 228 531 minecraft:black_concrete
setblock 11 228 532 minecraft:gray_concrete
fill 11 228 533 11 228 534 minecraft:black_concrete
setblock 11 228 535 minecraft:gray_concrete
fill 11 228 536 12 228 536 minecraft:black_concrete
fill 11 228 537 11 228 538 minecraft:iron_block
fill 12 228 524 12 228 525 minecraft:iron_block
fill 12 228 526 12 228 527 minecraft:black_concrete
setblock 12 228 528 minecraft:gray_concrete
fill 12 228 529 12 228 530 minecraft:black_concrete
setblock 12 228 531 minecraft:gray_concrete
fill 12 228 532 12 228 533 minecraft:black_concrete
setblock 12 228 534 minecraft:gray_concrete
fill 12 228 535 13 228 535 minecraft:black_concrete
setblock 12 228 537 minecraft:gray_concrete
fill 12 228 538 13 228 538 minecraft:black_concrete
fill 12 228 539 12 228 540 minecraft:iron_block
fill 13 228 523 13 228 524 minecraft:iron_block
fill 13 228 525 13 228 526 minecraft:black_concrete
setblock 13 228 527 minecraft:gray_concrete
fill 13 228 528 13 228 529 minecraft:black_concrete
setblock 13 228 530 minecraft:gray_concrete
fill 13 228 531 13 228 532 minecraft:black_concrete
setblock 13 228 533 minecraft:gray_concrete
fill 13 228 534 14 228 534 minecraft:black_concrete
setblock 13 228 536 minecraft:gray_concrete
fill 13 228 537 14 228 537 minecraft:black_concrete
setblock 13 228 539 minecraft:gray_concrete
fill 13 228 540 13 228 541 minecraft:iron_block
fill 14 228 522 14 228 523 minecraft:iron_block
fill 14 228 524 14 228 525 minecraft:black_concrete
setblock 14 228 526 minecraft:gray_concrete
fill 14 228 527 14 228 528 minecraft:black_concrete
setblock 14 228 529 minecraft:gray_concrete
fill 14 228 530 14 228 531 minecraft:black_concrete
setblock 14 228 532 minecraft:gray_concrete
fill 14 228 533 15 228 533 minecraft:black_concrete
setblock 14 228 535 minecraft:gray_concrete
fill 14 228 536 15 228 536 minecraft:black_concrete
setblock 14 228 538 minecraft:gray_concrete
fill 14 228 539 14 228 540 minecraft:black_concrete
fill 14 228 541 14 228 542 minecraft:iron_block
setblock 15 228 522 minecraft:iron_block
fill 15 228 523 15 228 524 minecraft:black_concrete
setblock 15 228 525 minecraft:gray_concrete
fill 15 228 526 15 228 527 minecraft:black_concrete
setblock 15 228 528 minecraft:gray_concrete
fill 15 228 529 15 228 530 minecraft:black_concrete
setblock 15 228 531 minecraft:gray_concrete
fill 15 228 532 16 228 532 minecraft:black_concrete
setblock 15 228 534 minecraft:gray_concrete
fill 15 228 535 16 228 535 minecraft:black_concrete
setblock 15 228 537 minecraft:gray_concrete
fill 15 228 538 15 228 539 minecraft:black_concrete
setblock 15 228 540 minecraft:gray_concrete
fill 15 228 541 16 228 541 minecraft:black_concrete
setblock 15 228 542 minecraft:iron_block
fill 16 228 521 17 228 521 minecraft:iron_block
fill 16 228 522 16 228 523 minecraft:black_concrete
setblock 16 228 524 minecraft:gray_concrete
fill 16 228 525 16 228 526 minecraft:black_concrete
setblock 16 228 527 minecraft:gray_concrete
fill 16 228 528 16 228 529 minecraft:black_concrete
setblock 16 228 530 minecraft:gray_concrete
fill 16 228 531 17 228 531 minecraft:black_concrete
setblock 16 228 533 minecraft:gray_concrete
fill 16 228 534 17 228 534 minecraft:black_concrete
setblock 16 228 536 minecraft:gray_concrete
fill 16 228 537 16 228 538 minecraft:black_concrete
setblock 16 228 539 minecraft:gray_concrete
fill 16 228 540 17 228 540 minecraft:black_concrete
setblock 16 228 542 minecraft:gray_concrete
fill 16 228 543 17 228 543 minecraft:iron_block
setblock 17 228 522 minecraft:black_concrete
setblock 17 228 523 minecraft:gray_concrete
fill 17 228 524 17 228 525 minecraft:black_concrete
setblock 17 228 526 minecraft:gray_concrete
fill 17 228 527 17 228 528 minecraft:black_concrete
setblock 17 228 529 minecraft:gray_concrete
fill 17 228 530 18 228 530 minecraft:black_concrete
setblock 17 228 532 minecraft:gray_concrete
fill 17 228 533 18 228 533 minecraft:black_concrete
setblock 17 228 535 minecraft:gray_concrete
fill 17 228 536 17 228 537 minecraft:black_concrete
setblock 17 228 538 minecraft:gray_concrete
fill 17 228 539 18 228 539 minecraft:black_concrete
setblock 17 228 541 minecraft:gray_concrete
fill 17 228 542 18 228 542 minecraft:black_concrete
fill 18 228 520 21 228 520 minecraft:iron_block
setblock 18 228 521 minecraft:black_concrete
setblock 18 228 522 minecraft:gray_concrete
fill 18 228 523 18 228 524 minecraft:black_concrete
setblock 18 228 525 minecraft:gray_concrete
fill 18 228 526 18 228 527 minecraft:black_concrete
setblock 18 228 528 minecraft:gray_concrete
fill 18 228 529 19 228 529 minecraft:black_concrete
setblock 18 228 531 minecraft:gray_concrete
fill 18 228 532 19 228 532 minecraft:black_concrete
setblock 18 228 534 minecraft:gray_concrete
fill 18 228 535 18 228 536 minecraft:black_concrete
setblock 18 228 537 minecraft:gray_concrete
fill 18 228 538 19 228 538 minecraft:black_concrete
setblock 18 228 540 minecraft:gray_concrete
fill 18 228 541 19 228 541 minecraft:black_concrete
setblock 18 228 543 minecraft:gray_concrete
fill 18 228 544 21 228 544 minecraft:iron_block
setblock 19 228 521 minecraft:gray_concrete
fill 19 228 522 19 228 523 minecraft:black_concrete
setblock 19 228 524 minecraft:gray_concrete
fill 19 228 525 19 228 526 minecraft:black_concrete
setblock 19 228 527 minecraft:gray_concrete
fill 19 228 528 20 228 528 minecraft:black_concrete
setblock 19 228 530 minecraft:gray_concrete
fill 19 228 531 20 228 531 minecraft:black_concrete
setblock 19 228 533 minecraft:gray_concrete
fill 19 228 534 19 228 535 minecraft:black_concrete
setblock 19 228 536 minecraft:gray_concrete
fill 19 228 537 20 228 537 minecraft:black_concrete
setblock 19 228 539 minecraft:gray_concrete
fill 19 228 540 20 228 540 minecraft:black_concrete
setblock 19 228 542 minecraft:gray_concrete
fill 19 228 543 20 228 543 minecraft:black_concrete
fill 20 228 521 20 228 522 minecraft:black_concrete
setblock 20 228 523 minecraft:gray_concrete
fill 20 228 524 20 228 525 minecraft:black_concrete
setblock 20 228 526 minecraft:gray_concrete
fill 20 228 527 21 228 527 minecraft:black_concrete
setblock 20 228 529 minecraft:gray_concrete
fill 20 228 530 21 228 530 minecraft:black_concrete
fill 20 228 533 20 228 534 minecraft:black_concrete
setblock 20 228 535 minecraft:gray_concrete
fill 20 228 536 21 228 536 minecraft:black_concrete
setblock 20 228 538 minecraft:gray_concrete
fill 20 228 539 21 228 539 minecraft:black_concrete
setblock 20 228 541 minecraft:gray_concrete
fill 20 228 542 21 228 542 minecraft:black_concrete
fill 20 228 552 22 230 552 minecraft:black_concrete
setblock 21 228 521 minecraft:black_concrete
setblock 21 228 522 minecraft:gray_concrete
fill 21 228 523 21 228 524 minecraft:black_concrete
setblock 21 228 525 minecraft:gray_concrete
fill 21 228 526 22 228 526 minecraft:black_concrete
setblock 21 228 528 minecraft:gray_concrete
fill 21 228 529 22 228 529 minecraft:black_concrete
setblock 21 228 534 minecraft:gray_concrete
fill 21 228 535 22 228 535 minecraft:black_concrete
setblock 21 228 537 minecraft:gray_concrete
fill 21 228 538 22 228 538 minecraft:black_concrete
setblock 21 228 540 minecraft:gray_concrete
fill 21 228 541 22 228 541 minecraft:black_concrete
setblock 21 228 543 minecraft:gray_concrete
setblock 22 228 520 minecraft:black_concrete
setblock 22 228 521 minecraft:gray_concrete
fill 22 228 522 22 228 523 minecraft:black_concrete
setblock 22 228 524 minecraft:gray_concrete
fill 22 228 525 23 228 525 minecraft:black_concrete
setblock 22 228 527 minecraft:gray_concrete
fill 22 228 528 23 228 528 minecraft:black_concrete
setblock 22 228 536 minecraft:gray_concrete
fill 22 228 537 23 228 537 minecraft:black_concrete
setblock 22 228 539 minecraft:gray_concrete
fill 22 228 540 23 228 540 minecraft:black_concrete
setblock 22 228 542 minecraft:gray_concrete
fill 22 228 543 22 228 544 minecraft:black_concrete
fill 23 228 520 26 228 520 minecraft:iron_block
fill 23 228 521 23 228 522 minecraft:black_concrete
setblock 23 228 523 minecraft:gray_concrete
fill 23 228 524 24 228 524 minecraft:black_concrete
setblock 23 228 526 minecraft:gray_concrete
fill 23 228 527 24 228 527 minecraft:black_concrete
setblock 23 228 529 minecraft:gray_concrete
fill 23 228 530 24 228 530 minecraft:black_concrete
setblock 23 228 534 minecraft:black_concrete
setblock 23 228 535 minecraft:gray_concrete
fill 23 228 536 24 228 536 minecraft:black_concrete
setblock 23 228 538 minecraft:gray_concrete
fill 23 228 539 24 228 539 minecraft:black_concrete
setblock 23 228 541 minecraft:gray_concrete
fill 23 228 542 23 228 543 minecraft:black_concrete
fill 23 228 544 26 228 544 minecraft:iron_block
setblock 23 228 552 minecraft:light_blue_stained_glass
setblock 24 228 521 minecraft:black_concrete
setblock 24 228 522 minecraft:gray_concrete
fill 24 228 523 25 228 523 minecraft:black_concrete
setblock 24 228 525 minecraft:gray_concrete
fill 24 228 526 25 228 526 minecraft:black_concrete
setblock 24 228 528 minecraft:gray_concrete
fill 24 228 529 25 228 529 minecraft:black_concrete
setblock 24 228 531 minecraft:gray_concrete
setblock 24 228 533 minecraft:black_concrete
setblock 24 228 534 minecraft:gray_concrete
fill 24 228 535 25 228 535 minecraft:black_concrete
setblock 24 228 537 minecraft:gray_concrete
fill 24 228 538 25 228 538 minecraft:black_concrete
setblock 24 228 540 minecraft:gray_concrete
fill 24 228 541 24 228 542 minecraft:black_concrete
setblock 24 228 543 minecraft:gray_concrete
fill 24 228 552 24 263 552 minecraft:black_concrete
setblock 25 228 521 minecraft:gray_concrete
fill 25 228 522 26 228 522 minecraft:black_concrete
setblock 25 228 524 minecraft:gray_concrete
fill 25 228 525 26 228 525 minecraft:black_concrete
setblock 25 228 527 minecraft:gray_concrete
fill 25 228 528 26 228 528 minecraft:black_concrete
setblock 25 228 530 minecraft:gray_concrete
fill 25 228 531 25 228 532 minecraft:black_concrete
setblock 25 228 533 minecraft:gray_concrete
fill 25 228 534 26 228 534 minecraft:black_concrete
setblock 25 228 536 minecraft:gray_concrete
fill 25 228 537 26 228 537 minecraft:black_concrete
setblock 25 228 539 minecraft:gray_concrete
fill 25 228 540 25 228 541 minecraft:black_concrete
setblock 25 228 542 minecraft:gray_concrete
fill 25 228 543 26 228 543 minecraft:black_concrete
setblock 26 228 521 minecraft:black_concrete
setblock 26 228 523 minecraft:gray_concrete
fill 26 228 524 27 228 524 minecraft:black_concrete
setblock 26 228 526 minecraft:gray_concrete
fill 26 228 527 27 228 527 minecraft:black_concrete
setblock 26 228 529 minecraft:gray_concrete
fill 26 228 530 26 228 531 minecraft:black_concrete
setblock 26 228 532 minecraft:gray_concrete
fill 26 228 533 27 228 533 minecraft:black_concrete
setblock 26 228 535 minecraft:gray_concrete
fill 26 228 536 27 228 536 minecraft:black_concrete
setblock 26 228 538 minecraft:gray_concrete
fill 26 228 539 26 228 540 minecraft:black_concrete
setblock 26 228 541 minecraft:gray_concrete
fill 26 228 542 27 228 542 minecraft:black_concrete
fill 27 228 521 28 228 521 minecraft:iron_block
setblock 27 228 522 minecraft:gray_concrete
fill 27 228 523 28 228 523 minecraft:black_concrete
setblock 27 228 525 minecraft:gray_concrete
fill 27 228 526 28 228 526 minecraft:black_concrete
setblock 27 228 528 minecraft:gray_concrete
fill 27 228 529 27 228 530 minecraft:black_concrete
setblock 27 228 531 minecraft:gray_concrete
fill 27 228 532 28 228 532 minecraft:black_concrete
setblock 27 228 534 minecraft:gray_concrete
fill 27 228 535 28 228 535 minecraft:black_concrete
setblock 27 228 537 minecraft:gray_concrete
fill 27 228 538 27 228 539 minecraft:black_concrete
setblock 27 228 540 minecraft:gray_concrete
fill 27 228 541 28 228 541 minecraft:black_concrete
fill 27 228 543 28 228 543 minecraft:iron_block
setblock 28 228 522 minecraft:black_concrete
setblock 28 228 524 minecraft:gray_concrete
fill 28 228 525 29 228 525 minecraft:black_concrete
setblock 28 228 527 minecraft:gray_concrete
fill 28 228 528 28 228 529 minecraft:black_concrete
setblock 28 228 530 minecraft:gray_concrete
fill 28 228 531 29 228 531 minecraft:black_concrete
setblock 28 228 533 minecraft:gray_concrete
fill 28 228 534 29 228 534 minecraft:black_concrete
setblock 28 228 536 minecraft:gray_concrete
fill 28 228 537 28 228 538 minecraft:black_concrete
setblock 28 228 539 minecraft:gray_concrete
fill 28 228 540 29 228 540 minecraft:black_concrete
setblock 28 228 542 minecraft:gray_concrete
fill 29 228 522 30 228 522 minecraft:iron_block
setblock 29 228 523 minecraft:gray_concrete
fill 29 228 524 30 228 524 minecraft:black_concrete
setblock 29 228 526 minecraft:gray_concrete
fill 29 228 527 29 228 528 minecraft:black_concrete
setblock 29 228 529 minecraft:gray_concrete
fill 29 228 530 30 228 530 minecraft:black_concrete
setblock 29 228 532 minecraft:gray_concrete
fill 29 228 533 30 228 533 minecraft:black_concrete
setblock 29 228 535 minecraft:gray_concrete
fill 29 228 536 29 228 537 minecraft:black_concrete
setblock 29 228 538 minecraft:gray_concrete
fill 29 228 539 30 228 539 minecraft:black_concrete
setblock 29 228 541 minecraft:gray_concrete
fill 29 228 542 30 228 542 minecraft:iron_block
fill 30 228 523 31 228 523 minecraft:iron_block
setblock 30 228 525 minecraft:gray_concrete
fill 30 228 526 30 228 527 minecraft:black_concrete
setblock 30 228 528 minecraft:gray_concrete
fill 30 228 529 31 228 529 minecraft:black_concrete
setblock 30 228 531 minecraft:gray_concrete
fill 30 228 532 31 228 532 minecraft:black_concrete
setblock 30 228 534 minecraft:gray_concrete
fill 30 228 535 30 228 536 minecraft:black_concrete
setblock 30 228 537 minecraft:gray_concrete
fill 30 228 538 31 228 538 minecraft:black_concrete
setblock 30 228 540 minecraft:gray_concrete
fill 30 228 541 31 228 541 minecraft:iron_block
fill 31 228 524 32 228 524 minecraft:iron_block
fill 31 228 525 31 228 526 minecraft:black_concrete
setblock 31 228 527 minecraft:gray_concrete
fill 31 228 528 32 228 528 minecraft:black_concrete
setblock 31 228 530 minecraft:gray_concrete
fill 31 228 531 32 228 531 minecraft:black_concrete
setblock 31 228 533 minecraft:gray_concrete
fill 31 228 534 31 228 535 minecraft:black_concrete
setblock 31 228 536 minecraft:gray_concrete
fill 31 228 537 32 228 537 minecraft:black_concrete
setblock 31 228 539 minecraft:gray_concrete
fill 31 228 540 32 228 540 minecraft:iron_block
setblock 32 228 525 minecraft:iron_block
setblock 32 228 526 minecraft:gray_concrete
setblock 32 228 527 minecraft:black_concrete
setblock 32 228 529 minecraft:gray_concrete
fill 32 228 530 33 228 530 minecraft:black_concrete
setblock 32 228 532 minecraft:gray_concrete
fill 32 228 533 32 228 534 minecraft:black_concrete
setblock 32 228 535 minecraft:gray_concrete
fill 32 228 536 33 228 536 minecraft:black_concrete
setblock 32 228 538 minecraft:gray_concrete
setblock 32 228 539 minecraft:iron_block
fill 33 228 526 33 228 527 minecraft:iron_block
setblock 33 228 528 minecraft:gray_concrete
setblock 33 228 529 minecraft:black_concrete
setblock 33 228 531 minecraft:gray_concrete
fill 33 228 532 33 228 533 minecraft:black_concrete
setblock 33 228 534 minecraft:gray_concrete
setblock 33 228 535 minecraft:black_concrete
fill 33 228 537 33 228 538 minecraft:iron_block
fill 34 228 528 34 228 531 minecraft:iron_block
setblock 34 228 532 minecraft:black_concrete
fill 34 228 533 34 228 536 minecraft:iron_block
setblock 42 228 549 minecraft:light_blue_stained_glass
setblock 0 229 530 minecraft:sea_lantern
fill 0 229 538 0 261 538 minecraft:black_concrete
fill 0 229 545 0 267 545 minecraft:black_concrete
setblock 0 229 549 minecraft:sea_lantern
fill 1 229 511 1 229 515 minecraft:orange_terracotta
setblock 1 229 516 minecraft:white_concrete
fill 1 229 517 1 229 523 minecraft:orange_terracotta
setblock 1 229 524 minecraft:white_concrete
fill 1 229 525 1 229 531 minecraft:orange_terracotta
setblock 1 229 532 minecraft:white_concrete
fill 1 229 533 1 229 539 minecraft:orange_terracotta
setblock 1 229 540 minecraft:white_concrete
fill 1 229 541 1 229 547 minecraft:orange_terracotta
setblock 1 229 548 minecraft:white_concrete
fill 1 229 549 5 229 551 minecraft:orange_terracotta
fill 2 229 511 2 229 514 minecraft:orange_terracotta
setblock 2 229 515 minecraft:white_concrete
fill 2 229 516 2 229 522 minecraft:orange_terracotta
setblock 2 229 523 minecraft:white_concrete
fill 2 229 524 2 229 530 minecraft:orange_terracotta
setblock 2 229 531 minecraft:white_concrete
fill 2 229 532 2 229 538 minecraft:orange_terracotta
setblock 2 229 539 minecraft:white_concrete
fill 2 229 540 2 229 546 minecraft:orange_terracotta
setblock 2 229 547 minecraft:white_concrete
fill 2 229 548 8 229 548 minecraft:orange_terracotta
fill 3 229 511 3 229 513 minecraft:orange_terracotta
setblock 3 229 514 minecraft:white_concrete
fill 3 229 515 3 229 521 minecraft:orange_terracotta
setblock 3 229 522 minecraft:white_concrete
fill 3 229 523 3 229 529 minecraft:orange_terracotta
setblock 3 229 530 minecraft:white_concrete
fill 3 229 531 3 229 537 minecraft:orange_terracotta
setblock 3 229 538 minecraft:white_concrete
fill 3 229 539 3 229 545 minecraft:orange_terracotta
setblock 3 229 546 minecraft:white_concrete
fill 3 229 547 9 229 547 minecraft:orange_terracotta
fill 4 229 511 4 229 512 minecraft:orange_terracotta
setblock 4 229 513 minecraft:white_concrete
fill 4 229 514 4 229 520 minecraft:orange_terracotta
setblock 4 229 521 minecraft:white_concrete
fill 4 229 522 4 229 528 minecraft:orange_terracotta
setblock 4 229 529 minecraft:white_concrete
fill 4 229 530 4 229 536 minecraft:orange_terracotta
setblock 4 229 537 minecraft:white_concrete
fill 4 229 538 4 229 544 minecraft:orange_terracotta
setblock 4 229 545 minecraft:white_concrete
fill 4 229 546 10 229 546 minecraft:orange_terracotta
setblock 5 229 511 minecraft:orange_terracotta
setblock 5 229 512 minecraft:white_concrete
fill 5 229 513 5 229 519 minecraft:orange_terracotta
setblock 5 229 520 minecraft:white_concrete
fill 5 229 521 5 229 527 minecraft:orange_terracotta
setblock 5 229 528 minecraft:white_concrete
fill 5 229 529 5 229 535 minecraft:orange_terracotta
setblock 5 229 536 minecraft:white_concrete
fill 5 229 537 5 229 543 minecraft:orange_terracotta
setblock 5 229 544 minecraft:white_concrete
fill 5 229 545 11 229 545 minecraft:orange_terracotta
setblock 6 229 511 minecraft:white_concrete
fill 6 229 512 6 229 518 minecraft:orange_terracotta
setblock 6 229 519 minecraft:white_concrete
fill 6 229 520 6 229 526 minecraft:orange_terracotta
setblock 6 229 527 minecraft:white_concrete
fill 6 229 528 6 229 534 minecraft:orange_terracotta
setblock 6 229 535 minecraft:white_concrete
fill 6 229 536 6 229 542 minecraft:orange_terracotta
setblock 6 229 543 minecraft:white_concrete
fill 6 229 544 12 229 544 minecraft:orange_terracotta
fill 6 229 549 6 229 550 minecraft:orange_terracotta
setblock 6 229 551 minecraft:white_concrete
fill 7 229 511 7 229 517 minecraft:orange_terracotta
setblock 7 229 518 minecraft:white_concrete
fill 7 229 519 7 229 525 minecraft:orange_terracotta
setblock 7 229 526 minecraft:white_concrete
fill 7 229 527 7 229 533 minecraft:orange_terracotta
setblock 7 229 534 minecraft:white_concrete
fill 7 229 535 7 229 541 minecraft:orange_terracotta
setblock 7 229 542 minecraft:white_concrete
fill 7 229 543 13 229 543 minecraft:orange_terracotta
setblock 7 229 549 minecraft:orange_terracotta
setblock 7 229 550 minecraft:white_concrete
fill 7 229 551 13 229 551 minecraft:orange_terracotta
fill 8 229 511 8 229 516 minecraft:orange_terracotta
setblock 8 229 517 minecraft:white_concrete
fill 8 229 518 8 229 524 minecraft:orange_terracotta
setblock 8 229 525 minecraft:white_concrete
fill 8 229 526 8 229 532 minecraft:orange_terracotta
setblock 8 229 533 minecraft:white_concrete
fill 8 229 534 8 229 540 minecraft:orange_terracotta
setblock 8 229 541 minecraft:white_concrete
fill 8 229 542 14 229 542 minecraft:orange_terracotta
setblock 8 229 549 minecraft:white_concrete
fill 8 229 550 14 229 550 minecraft:orange_terracotta
fill 9 229 511 9 229 515 minecraft:orange_terracotta
setblock 9 229 516 minecraft:white_concrete
fill 9 229 517 9 229 523 minecraft:orange_terracotta
setblock 9 229 524 minecraft:white_concrete
fill 9 229 525 9 229 531 minecraft:orange_terracotta
setblock 9 229 532 minecraft:white_concrete
fill 9 229 533 9 229 539 minecraft:orange_terracotta
setblock 9 229 540 minecraft:white_concrete
fill 9 229 541 15 229 541 minecraft:orange_terracotta
setblock 9 229 548 minecraft:white_concrete
fill 9 229 549 15 229 549 minecraft:orange_terracotta
fill 10 229 511 10 229 514 minecraft:orange_terracotta
setblock 10 229 515 minecraft:white_concrete
fill 10 229 516 10 229 522 minecraft:orange_terracotta
setblock 10 229 523 minecraft:white_concrete
fill 10 229 524 10 229 530 minecraft:orange_terracotta
setblock 10 229 531 minecraft:white_concrete
fill 10 229 532 10 229 538 minecraft:orange_terracotta
setblock 10 229 539 minecraft:white_concrete
fill 10 229 540 16 229 540 minecraft:orange_terracotta
setblock 10 229 547 minecraft:white_concrete
fill 10 229 548 16 229 548 minecraft:orange_terracotta
fill 11 229 511 11 229 513 minecraft:orange_terracotta
setblock 11 229 514 minecraft:white_concrete
fill 11 229 515 11 229 521 minecraft:orange_terracotta
setblock 11 229 522 minecraft:white_concrete
fill 11 229 523 11 229 529 minecraft:orange_terracotta
setblock 11 229 530 minecraft:white_concrete
fill 11 229 531 11 229 537 minecraft:orange_terracotta
setblock 11 229 538 minecraft:white_concrete
fill 11 229 539 17 229 539 minecraft:orange_terracotta
setblock 11 229 546 minecraft:white_concrete
fill 11 229 547 17 229 547 minecraft:orange_terracotta
fill 12 229 511 12 229 512 minecraft:orange_terracotta
setblock 12 229 513 minecraft:white_concrete
fill 12 229 514 12 229 520 minecraft:orange_terracotta
setblock 12 229 521 minecraft:white_concrete
fill 12 229 522 12 229 528 minecraft:orange_terracotta
setblock 12 229 529 minecraft:white_concrete
fill 12 229 530 12 229 536 minecraft:orange_terracotta
setblock 12 229 537 minecraft:white_concrete
fill 12 229 538 18 229 538 minecraft:orange_terracotta
setblock 12 229 545 minecraft:white_concrete
fill 12 229 546 18 229 546 minecraft:orange_terracotta
setblock 13 229 511 minecraft:orange_terracotta
setblock 13 229 512 minecraft:white_concrete
fill 13 229 513 13 229 519 minecraft:orange_terracotta
setblock 13 229 520 minecraft:white_concrete
fill 13 229 521 13 229 527 minecraft:orange_terracotta
setblock 13 229 528 minecraft:white_concrete
fill 13 229 529 13 229 535 minecraft:orange_terracotta
setblock 13 229 536 minecraft:white_concrete
fill 13 229 537 19 229 537 minecraft:orange_terracotta
setblock 13 229 544 minecraft:white_concrete
fill 13 229 545 19 229 545 minecraft:orange_terracotta
setblock 14 229 511 minecraft:white_concrete
fill 14 229 512 14 229 518 minecraft:orange_terracotta
setblock 14 229 519 minecraft:white_concrete
fill 14 229 520 14 229 526 minecraft:orange_terracotta
setblock 14 229 527 minecraft:white_concrete
fill 14 229 528 14 229 534 minecraft:orange_terracotta
setblock 14 229 535 minecraft:white_concrete
fill 14 229 536 20 229 536 minecraft:orange_terracotta
setblock 14 229 543 minecraft:white_concrete
fill 14 229 544 20 229 544 minecraft:orange_terracotta
setblock 14 229 551 minecraft:white_concrete
fill 15 229 511 15 229 517 minecraft:orange_terracotta
setblock 15 229 518 minecraft:white_concrete
fill 15 229 519 15 229 525 minecraft:orange_terracotta
setblock 15 229 526 minecraft:white_concrete
fill 15 229 527 15 229 533 minecraft:orange_terracotta
setblock 15 229 534 minecraft:white_concrete
fill 15 229 535 21 229 535 minecraft:orange_terracotta
setblock 15 229 542 minecraft:white_concrete
fill 15 229 543 21 229 543 minecraft:orange_terracotta
setblock 15 229 550 minecraft:white_concrete
fill 15 229 551 21 229 551 minecraft:orange_terracotta
fill 16 229 511 16 229 516 minecraft:orange_terracotta
setblock 16 229 517 minecraft:white_concrete
fill 16 229 518 16 229 524 minecraft:orange_terracotta
setblock 16 229 525 minecraft:white_concrete
fill 16 229 526 16 229 532 minecraft:orange_terracotta
setblock 16 229 533 minecraft:white_concrete
fill 16 229 534 19 229 534 minecraft:orange_terracotta
setblock 16 229 541 minecraft:white_concrete
fill 16 229 542 22 229 542 minecraft:orange_terracotta
setblock 16 229 549 minecraft:white_concrete
fill 16 229 550 22 229 550 minecraft:orange_terracotta
fill 17 229 511 17 229 515 minecraft:orange_terracotta
setblock 17 229 516 minecraft:white_concrete
fill 17 229 517 17 229 523 minecraft:orange_terracotta
setblock 17 229 524 minecraft:white_concrete
fill 17 229 525 17 229 531 minecraft:orange_terracotta
setblock 17 229 532 minecraft:white_concrete
fill 17 229 533 19 229 533 minecraft:orange_terracotta
setblock 17 229 540 minecraft:white_concrete
fill 17 229 541 23 229 541 minecraft:orange_terracotta
setblock 17 229 548 minecraft:white_concrete
fill 17 229 549 23 229 549 minecraft:orange_terracotta
fill 18 229 511 18 229 514 minecraft:orange_terracotta
setblock 18 229 515 minecraft:white_concrete
fill 18 229 516 18 229 522 minecraft:orange_terracotta
setblock 18 229 523 minecraft:white_concrete
fill 18 229 524 18 229 530 minecraft:orange_terracotta
fill 18 229 531 18 230 531 minecraft:white_concrete
fill 18 229 532 19 229 532 minecraft:orange_terracotta
setblock 18 229 539 minecraft:white_concrete
fill 18 229 540 24 229 540 minecraft:orange_terracotta
setblock 18 229 547 minecraft:white_concrete
fill 18 229 548 24 229 548 minecraft:orange_terracotta
fill 19 229 511 19 229 513 minecraft:orange_terracotta
setblock 19 229 514 minecraft:white_concrete
fill 19 229 515 19 229 521 minecraft:orange_terracotta
setblock 19 229 522 minecraft:white_concrete
fill 19 229 523 19 229 529 minecraft:orange_terracotta
setblock 19 229 530 minecraft:white_concrete
setblock 19 229 531 minecraft:orange_terracotta
setblock 19 229 538 minecraft:white_concrete
fill 19 229 539 25 229 539 minecraft:orange_terracotta
setblock 19 229 546 minecraft:white_concrete
fill 19 229 547 25 229 547 minecraft:orange_terracotta
fill 20 229 511 20 229 512 minecraft:orange_terracotta
setblock 20 229 513 minecraft:white_concrete
fill 20 229 514 20 229 520 minecraft:orange_terracotta
setblock 20 229 521 minecraft:white_concrete
fill 20 229 522 20 229 528 minecraft:orange_terracotta
setblock 20 229 529 minecraft:white_concrete
fill 20 229 530 20 230 531 minecraft:orange_concrete
fill 20 229 533 20 230 534 minecraft:orange_concrete
setblock 20 229 537 minecraft:white_concrete
fill 20 229 538 26 229 538 minecraft:orange_terracotta
setblock 20 229 545 minecraft:white_concrete
fill 20 229 546 26 229 546 minecraft:orange_terracotta
setblock 21 229 511 minecraft:orange_terracotta
setblock 21 229 512 minecraft:white_concrete
fill 21 229 513 21 229 519 minecraft:orange_terracotta
setblock 21 229 520 minecraft:white_concrete
fill 21 229 521 21 229 527 minecraft:orange_terracotta
setblock 21 229 528 minecraft:white_concrete
fill 21 229 529 27 229 529 minecraft:orange_terracotta
fill 21 229 530 21 230 530 minecraft:orange_concrete
fill 21 229 534 21 230 534 minecraft:orange_concrete
setblock 21 229 536 minecraft:white_concrete
fill 21 229 537 27 229 537 minecraft:orange_terracotta
setblock 21 229 544 minecraft:white_concrete
fill 21 229 545 27 229 545 minecraft:orange_terracotta
setblock 22 229 511 minecraft:white_concrete
fill 22 229 512 22 229 518 minecraft:orange_terracotta
setblock 22 229 519 minecraft:white_concrete
fill 22 229 520 22 229 526 minecraft:orange_terracotta
setblock 22 229 527 minecraft:white_concrete
fill 22 229 528 28 229 528 minecraft:orange_terracotta
setblock 22 229 535 minecraft:white_concrete
fill 22 229 536 28 229 536 minecraft:orange_terracotta
setblock 22 229 543 minecraft:white_concrete
fill 22 229 544 28 229 544 minecraft:orange_terracotta
setblock 22 229 551 minecraft:white_concrete
fill 23 229 511 23 229 517 minecraft:orange_terracotta
setblock 23 229 518 minecraft:white_concrete
fill 23 229 519 23 229 525 minecraft:orange_terracotta
setblock 23 229 526 minecraft:white_concrete
fill 23 229 527 29 229 527 minecraft:orange_terracotta
fill 23 229 530 24 230 530 minecraft:orange_concrete
fill 23 229 534 24 230 534 minecraft:orange_concrete
fill 23 229 535 29 229 535 minecraft:orange_terracotta
setblock 23 229 542 minecraft:white_concrete
fill 23 229 543 29 229 543 minecraft:orange_terracotta
setblock 23 229 550 minecraft:white_concrete
fill 23 229 551 29 229 551 minecraft:orange_terracotta
fill 23 229 552 23 272 552 minecraft:black_concrete
fill 24 229 511 24 229 516 minecraft:orange_terracotta
setblock 24 229 517 minecraft:white_concrete
fill 24 229 518 24 229 524 minecraft:orange_terracotta
setblock 24 229 525 minecraft:white_concrete
fill 24 229 526 30 229 526 minecraft:orange_terracotta
fill 24 229 531 24 230 531 minecraft:orange_concrete
fill 24 229 533 24 230 533 minecraft:orange_concrete
setblock 24 229 541 minecraft:white_concrete
fill 24 229 542 30 229 542 minecraft:orange_terracotta
setblock 24 229 549 minecraft:white_concrete
fill 24 229 550 30 229 550 minecraft:orange_terracotta
fill 25 229 511 25 229 515 minecraft:orange_terracotta
setblock 25 229 516 minecraft:white_concrete
fill 25 229 517 25 229 523 minecraft:orange_terracotta
setblock 25 229 524 minecraft:white_concrete
fill 25 229 525 31 229 525 minecraft:orange_terracotta
fill 25 229 530 25 229 531 minecraft:orange_terracotta
setblock 25 229 532 minecraft:white_concrete
fill 25 229 533 30 229 534 minecraft:orange_terracotta
setblock 25 229 540 minecraft:white_concrete
fill 25 229 541 31 229 541 minecraft:orange_terracotta
setblock 25 229 548 minecraft:white_concrete
fill 25 229 549 31 229 549 minecraft:orange_terracotta
fill 26 229 511 26 229 514 minecraft:orange_terracotta
setblock 26 229 515 minecraft:white_concrete
fill 26 229 516 26 229 522 minecraft:orange_terracotta
setblock 26 229 523 minecraft:white_concrete
fill 26 229 524 32 229 524 minecraft:orange_terracotta
setblock 26 229 530 minecraft:orange_terracotta
setblock 26 229 531 minecraft:white_concrete
fill 26 229 532 32 229 532 minecraft:orange_terracotta
setblock 26 229 539 minecraft:white_concrete
fill 26 229 540 32 229 540 minecraft:orange_terracotta
setblock 26 229 547 minecraft:white_concrete
fill 26 229 548 32 229 548 minecraft:orange_terracotta
fill 27 229 511 27 229 513 minecraft:orange_terracotta
setblock 27 229 514 minecraft:white_concrete
fill 27 229 515 27 229 521 minecraft:orange_terracotta
setblock 27 229 522 minecraft:white_concrete
fill 27 229 523 33 229 523 minecraft:orange_terracotta
setblock 27 229 530 minecraft:white_concrete
fill 27 229 531 33 229 531 minecraft:orange_terracotta
setblock 27 229 538 minecraft:white_concrete
fill 27 229 539 33 229 539 minecraft:orange_terracotta
setblock 27 229 546 minecraft:white_concrete
fill 27 229 547 33 229 547 minecraft:orange_terracotta
fill 28 229 511 28 229 512 minecraft:orange_terracotta
setblock 28 229 513 minecraft:white_concrete
fill 28 229 514 28 229 520 minecraft:orange_terracotta
setblock 28 229 521 minecraft:white_concrete
fill 28 229 522 34 229 522 minecraft:orange_terracotta
setblock 28 229 529 minecraft:white_concrete
fill 28 229 530 34 229 530 minecraft:orange_terracotta
setblock 28 229 537 minecraft:white_concrete
fill 28 229 538 34 229 538 minecraft:orange_terracotta
setblock 28 229 545 minecraft:white_concrete
fill 28 229 546 34 229 546 minecraft:orange_terracotta
setblock 29 229 511 minecraft:orange_terracotta
setblock 29 229 512 minecraft:white_concrete
fill 29 229 513 29 229 519 minecraft:orange_terracotta
setblock 29 229 520 minecraft:white_concrete
fill 29 229 521 35 229 521 minecraft:orange_terracotta
setblock 29 229 528 minecraft:white_concrete
fill 29 229 529 35 229 529 minecraft:orange_terracotta
setblock 29 229 536 minecraft:white_concrete
fill 29 229 537 35 229 537 minecraft:orange_terracotta
setblock 29 229 544 minecraft:white_concrete
fill 29 229 545 35 229 545 minecraft:orange_terracotta
setblock 30 229 511 minecraft:white_concrete
fill 30 229 512 30 229 518 minecraft:orange_terracotta
setblock 30 229 519 minecraft:white_concrete
fill 30 229 520 36 229 520 minecraft:orange_terracotta
setblock 30 229 527 minecraft:white_concrete
fill 30 229 528 36 229 528 minecraft:orange_terracotta
setblock 30 229 535 minecraft:white_concrete
fill 30 229 536 36 229 536 minecraft:orange_terracotta
setblock 30 229 543 minecraft:white_concrete
fill 30 229 544 36 229 544 minecraft:orange_terracotta
setblock 30 229 551 minecraft:white_concrete
fill 31 229 511 31 229 517 minecraft:orange_terracotta
setblock 31 229 518 minecraft:white_concrete
fill 31 229 519 37 229 519 minecraft:orange_terracotta
setblock 31 229 526 minecraft:white_concrete
fill 31 229 527 37 229 527 minecraft:orange_terracotta
setblock 31 229 533 minecraft:orange_terracotta
setblock 31 229 534 minecraft:white_concrete
fill 31 229 535 37 229 535 minecraft:orange_terracotta
setblock 31 229 542 minecraft:white_concrete
fill 31 229 543 37 229 543 minecraft:orange_terracotta
setblock 31 229 550 minecraft:white_concrete
fill 31 229 551 37 229 551 minecraft:orange_terracotta
fill 32 229 511 32 229 516 minecraft:orange_terracotta
setblock 32 229 517 minecraft:white_concrete
fill 32 229 518 38 229 518 minecraft:orange_terracotta
setblock 32 229 525 minecraft:white_concrete
fill 32 229 526 38 229 526 minecraft:orange_terracotta
setblock 32 229 533 minecraft:white_concrete
fill 32 229 534 38 229 534 minecraft:orange_terracotta
setblock 32 229 541 minecraft:white_concrete
fill 32 229 542 38 229 542 minecraft:orange_terracotta
setblock 32 229 549 minecraft:white_concrete
fill 32 229 550 38 229 550 minecraft:orange_terracotta
fill 33 229 511 33 229 515 minecraft:orange_terracotta
setblock 33 229 516 minecraft:white_concrete
fill 33 229 517 39 229 517 minecraft:orange_terracotta
setblock 33 229 524 minecraft:white_concrete
fill 33 229 525 39 229 525 minecraft:orange_terracotta
setblock 33 229 532 minecraft:white_concrete
fill 33 229 533 39 229 533 minecraft:orange_terracotta
setblock 33 229 540 minecraft:white_concrete
fill 33 229 541 39 229 541 minecraft:orange_terracotta
setblock 33 229 548 minecraft:white_concrete
fill 33 229 549 39 229 549 minecraft:orange_terracotta
fill 34 229 511 34 229 514 minecraft:orange_terracotta
setblock 34 229 515 minecraft:white_concrete
fill 34 229 516 40 229 516 minecraft:orange_terracotta
setblock 34 229 523 minecraft:white_concrete
fill 34 229 524 40 229 524 minecraft:orange_terracotta
setblock 34 229 531 minecraft:white_concrete
fill 34 229 532 40 229 532 minecraft:orange_terracotta
setblock 34 229 539 minecraft:white_concrete
fill 34 229 540 40 229 540 minecraft:orange_terracotta
setblock 34 229 547 minecraft:white_concrete
fill 34 229 548 40 229 548 minecraft:orange_terracotta
fill 35 229 511 35 229 513 minecraft:orange_terracotta
setblock 35 229 514 minecraft:white_concrete
fill 35 229 515 41 229 515 minecraft:orange_terracotta
setblock 35 229 522 minecraft:white_concrete
fill 35 229 523 41 229 523 minecraft:orange_terracotta
setblock 35 229 530 minecraft:white_concrete
fill 35 229 531 41 229 531 minecraft:orange_terracotta
setblock 35 229 538 minecraft:white_concrete
fill 35 229 539 41 229 539 minecraft:orange_terracotta
setblock 35 229 546 minecraft:white_concrete
fill 35 229 547 41 229 547 minecraft:orange_terracotta
fill 36 229 511 36 229 512 minecraft:orange_terracotta
setblock 36 229 513 minecraft:white_concrete
fill 36 229 514 41 229 514 minecraft:orange_terracotta
setblock 36 229 521 minecraft:white_concrete
fill 36 229 522 41 229 522 minecraft:orange_terracotta
setblock 36 229 529 minecraft:white_concrete
fill 36 229 530 41 229 530 minecraft:orange_terracotta
setblock 36 229 537 minecraft:white_concrete
fill 36 229 538 41 229 538 minecraft:orange_terracotta
setblock 36 229 545 minecraft:white_concrete
fill 36 229 546 41 229 546 minecraft:orange_terracotta
setblock 37 229 511 minecraft:orange_terracotta
setblock 37 229 512 minecraft:white_concrete
fill 37 229 513 41 229 513 minecraft:orange_terracotta
setblock 37 229 520 minecraft:white_concrete
fill 37 229 521 41 229 521 minecraft:orange_terracotta
setblock 37 229 528 minecraft:white_concrete
fill 37 229 529 41 229 529 minecraft:orange_terracotta
setblock 37 229 536 minecraft:white_concrete
fill 37 229 537 41 229 537 minecraft:orange_terracotta
setblock 37 229 544 minecraft:white_concrete
fill 37 229 545 41 229 545 minecraft:orange_terracotta
setblock 38 229 511 minecraft:white_concrete
fill 38 229 512 41 229 512 minecraft:orange_terracotta
setblock 38 229 519 minecraft:white_concrete
fill 38 229 520 41 229 520 minecraft:orange_terracotta
setblock 38 229 527 minecraft:white_concrete
fill 38 229 528 41 229 528 minecraft:orange_terracotta
setblock 38 229 535 minecraft:white_concrete
fill 38 229 536 41 229 536 minecraft:orange_terracotta
setblock 38 229 543 minecraft:white_concrete
fill 38 229 544 41 229 544 minecraft:orange_terracotta
setblock 38 229 551 minecraft:white_concrete
fill 39 229 511 41 229 511 minecraft:orange_terracotta
setblock 39 229 518 minecraft:white_concrete
fill 39 229 519 41 229 519 minecraft:orange_terracotta
setblock 39 229 526 minecraft:white_concrete
fill 39 229 527 41 229 527 minecraft:orange_terracotta
setblock 39 229 534 minecraft:white_concrete
fill 39 229 535 41 229 535 minecraft:orange_terracotta
setblock 39 229 542 minecraft:white_concrete
fill 39 229 543 41 229 543 minecraft:orange_terracotta
setblock 39 229 550 minecraft:white_concrete
fill 39 229 551 41 229 551 minecraft:orange_terracotta
setblock 40 229 517 minecraft:white_concrete
fill 40 229 518 41 229 518 minecraft:orange_terracotta
setblock 40 229 525 minecraft:white_concrete
fill 40 229 526 41 229 526 minecraft:orange_terracotta
setblock 40 229 533 minecraft:white_concrete
fill 40 229 534 41 229 534 minecraft:orange_terracotta
setblock 40 229 541 minecraft:white_concrete
fill 40 229 542 41 229 542 minecraft:orange_terracotta
setblock 40 229 549 minecraft:white_concrete
fill 40 229 550 41 229 550 minecraft:orange_terracotta
setblock 41 229 516 minecraft:white_concrete
setblock 41 229 517 minecraft:orange_terracotta
setblock 41 229 524 minecraft:white_concrete
setblock 41 229 525 minecraft:orange_terracotta
setblock 41 229 532 minecraft:white_concrete
setblock 41 229 533 minecraft:orange_terracotta
setblock 41 229 540 minecraft:white_concrete
setblock 41 229 541 minecraft:orange_terracotta
setblock 41 229 548 minecraft:white_concrete
setblock 41 229 549 minecraft:orange_terracotta
setblock 42 229 549 minecraft:black_concrete
setblock 0 230 517 minecraft:light_blue_stained_glass
fill 0 230 530 0 307 530 minecraft:black_concrete
fill 0 230 549 0 235 549 minecraft:black_concrete
setblock 5 230 552 minecraft:light_blue_stained_glass
fill 10 230 528 10 230 536 minecraft:iron_block
fill 11 230 526 11 230 531 minecraft:iron_block
fill 11 230 533 11 230 538 minecraft:iron_block
fill 12 230 524 12 230 527 minecraft:iron_block
fill 12 230 537 12 230 540 minecraft:iron_block
fill 13 230 523 13 230 525 minecraft:iron_block
fill 13 230 539 13 230 541 minecraft:iron_block
fill 14 230 522 14 230 524 minecraft:iron_block
fill 14 230 540 14 230 542 minecraft:iron_block
fill 15 230 522 15 230 523 minecraft:iron_block
fill 15 230 541 15 230 542 minecraft:iron_block
fill 16 230 521 17 230 522 minecraft:iron_block
fill 16 230 542 17 230 543 minecraft:iron_block
fill 18 230 520 21 230 521 minecraft:iron_block
fill 18 230 527 18 230 530 minecraft:white_concrete
fill 18 230 532 18 230 537 minecraft:white_concrete
fill 18 230 543 21 230 544 minecraft:iron_block
fill 22 230 520 26 230 520 minecraft:iron_block
fill 22 230 544 26 230 544 minecraft:iron_block
fill 23 230 521 28 230 521 minecraft:iron_block
fill 23 230 543 28 230 543 minecraft:iron_block
fill 27 230 522 30 230 522 minecraft:iron_block
fill 27 230 542 30 230 542 minecraft:iron_block
fill 29 230 523 31 230 523 minecraft:iron_block
fill 29 230 541 31 230 541 minecraft:iron_block
fill 30 230 524 32 230 524 minecraft:iron_block
fill 30 230 540 32 230 540 minecraft:iron_block
fill 31 230 525 32 230 525 minecraft:iron_block
fill 31 230 539 32 230 539 minecraft:iron_block
fill 32 230 526 33 230 527 minecraft:iron_block
fill 32 230 537 33 230 538 minecraft:iron_block
fill 33 230 528 34 230 531 minecraft:iron_block
fill 33 230 533 34 230 536 minecraft:iron_block
setblock 34 230 532 minecraft:iron_block
fill 37 230 552 38 261 552 minecraft:black_concrete
setblock 39 230 552 minecraft:light_blue_stained_glass
setblock 42 230 549 minecraft:sea_lantern
fill 0 231 517 0 307 517 minecraft:black_concrete
fill 0 231 527 0 234 528 minecraft:black_concrete
setblock 0 231 529 minecraft:white_concrete
setblock 1 231 510 minecraft:light_blue_stained_glass
fill 2 231 510 2 261 510 minecraft:black_concrete
setblock 5 231 510 minecraft:light_blue_stained_glass
setblock 5 231 552 minecraft:black_concrete
fill 8 231 552 10 235 552 minecraft:black_concrete
setblock 11 231 552 minecraft:sea_lantern
setblock 12 231 510 minecraft:white_concrete
fill 12 231 552 12 307 552 minecraft:black_concrete
fill 13 231 510 16 234 510 minecraft:black_concrete
fill 18 231 527 18 236 529 minecraft:white_concrete
fill 18 231 530 18 234 534 minecraft:red_concrete
fill 18 231 535 18 236 537 minecraft:white_concrete
fill 20 231 552 20 307 552 minecraft:black_concrete
setblock 21 231 552 minecraft:light_blue_stained_glass
fill 22 231 552 22 257 552 minecraft:black_concrete
fill 39 231 552 39 269 552 minecraft:black_concrete
setblock 42 231 516 minecraft:white_concrete
fill 42 231 549 42 245 549 minecraft:black_concrete
fill 0 232 529 0 236 529 minecraft:black_concrete
setblock 0 232 542 minecraft:light_blue_stained_glass
fill 0 232 543 0 251 543 minecraft:black_concrete
setblock 0 232 544 minecraft:light_blue_stained_glass
fill 1 232 510 1 273 510 minecraft:black_concrete
fill 5 232 510 5 254 510 minecraft:black_concrete
setblock 5 232 552 minecraft:sea_lantern
fill 11 232 552 11 258 552 minecraft:black_concrete
fill 12 232 510 12 259 510 minecraft:black_concrete
fill 21 232 552 21 307 552 minecraft:black_concrete
fill 42 232 516 42 307 516 minecraft:black_concrete
fill 0 233 542 0 277 542 minecraft:black_concrete
fill 0 233 544 0 256 544 minecraft:black_concrete
setblock 0 233 551 minecraft:light_blue_stained_glass
fill 5 233 552 5 307 552 minecraft:black_concrete
setblock 36 233 552 minecraft:white_concrete
fill 42 233 529 42 260 529 minecraft:black_concrete
setblock 42 233 530 minecraft:light_blue_stained_glass
setblock 42 233 536 minecraft:white_concrete
fill 0 234 518 0 236 518 minecraft:cyan_concrete
fill 0 234 534 0 236 534 minecraft:cyan_concrete
setblock 0 234 546 minecraft:light_blue_stained_glass
fill 0 234 550 0 236 550 minecraft:cyan_concrete
fill 0 234 551 0 300 551 minecraft:black_concrete
fill 4 234 510 4 236 510 minecraft:cyan_concrete
fill 14 234 552 14 236 552 minecraft:cyan_concrete
fill 15 234 552 18 244 552 minecraft:black_concrete
fill 20 234 510 20 236 510 minecraft:cyan_concrete
fill 30 234 552 30 236 552 minecraft:cyan_concrete
setblock 32 234 510 minecraft:sea_lantern
fill 36 234 510 36 236 510 minecraft:cyan_concrete
fill 36 234 552 36 239 552 minecraft:black_concrete
fill 42 234 517 42 271 517 minecraft:black_concrete
setblock 42 234 518 minecraft:white_concrete
fill 42 234 520 42 236 520 minecraft:cyan_concrete
setblock 42 234 530 minecraft:sea_lantern
fill 42 234 536 42 236 536 minecraft:cyan_concrete
fill 0 235 527 0 260 527 minecraft:black_concrete
setblock 0 235 528 minecraft:light_blue_stained_glass
fill 0 235 546 0 251 546 minecraft:black_concrete
fill 13 235 510 14 245 510 minecraft:black_concrete
setblock 15 235 510 minecraft:sea_lantern
fill 16 235 510 16 244 510 minecraft:black_concrete
fill 18 235 530 18 236 534 minecraft:white_concrete
fill 32 235 510 32 248 510 minecraft:black_concrete
setblock 42 235 518 minecraft:black_concrete
fill 42 235 530 42 247 530 minecraft:black_concrete
fill 0 236 528 0 307 528 minecraft:black_concrete
setblock 0 236 549 minecraft:light_blue_stained_glass
setblock 8 236 552 minecraft:light_blue_stained_glass
fill 9 236 552 10 238 552 minecraft:black_concrete
fill 15 236 510 15 307 510 minecraft:black_concrete
setblock 42 236 518 minecraft:sea_lantern
fill 0 237 518 0 242 518 minecraft:black_concrete
setblock 0 237 529 minecraft:light_blue_stained_glass
setblock 0 237 534 minecraft:black_concrete
fill 0 237 549 0 242 550 minecraft:black_concrete
setblock 3 237 513 minecraft:light[level=11]
setblock 3 237 521 minecraft:light[level=11]
setblock 3 237 529 minecraft:light[level=11]
setblock 3 237 537 minecraft:light[level=11]
setblock 3 237 545 minecraft:light[level=11]
fill 4 237 510 4 242 510 minecraft:black_concrete
fill 8 237 552 8 291 552 minecraft:black_concrete
setblock 11 237 513 minecraft:light[level=11]
setblock 11 237 521 minecraft:light[level=11]
setblock 11 237 529 minecraft:light[level=11]
setblock 11 237 537 minecraft:light[level=11]
setblock 11 237 545 minecraft:light[level=11]
fill 14 237 552 14 241 552 minecraft:black_concrete
setblock 19 237 513 minecraft:light[level=11]
setblock 19 237 521 minecraft:light[level=11]
setblock 19 237 529 minecraft:light[level=11]
setblock 19 237 537 minecraft:light[level=11]
setblock 19 237 545 minecraft:light[level=11]
fill 20 237 510 20 242 510 minecraft:black_concrete
setblock 27 237 513 minecraft:light[level=11]
setblock 27 237 521 minecraft:light[level=11]
setblock 27 237 529 minecraft:light[level=11]
setblock 27 237 537 minecraft:light[level=11]
setblock 27 237 545 minecraft:light[level=11]
fill 30 237 552 30 242 552 minecraft:black_concrete
setblock 35 237 513 minecraft:light[level=11]
setblock 35 237 521 minecraft:light[level=11]
setblock 35 237 529 minecraft:light[level=11]
setblock 35 237 537 minecraft:light[level=11]
setblock 35 237 545 minecraft:light[level=11]
fill 36 237 510 36 242 510 minecraft:black_concrete
fill 42 237 518 42 275 518 minecraft:black_concrete
fill 42 237 520 42 242 520 minecraft:black_concrete
setblock 42 237 531 minecraft:light_blue_stained_glass
fill 42 237 536 42 242 536 minecraft:black_concrete
fill 0 238 529 0 288 529 minecraft:black_concrete
fill 0 238 533 0 238 534 minecraft:sea_lantern
setblock 19 238 552 minecraft:light_blue_stained_glass
setblock 34 238 552 minecraft:light_blue_stained_glass
fill 35 238 552 35 241 552 minecraft:black_concrete
fill 42 238 531 42 307 531 minecraft:black_concrete
fill 0 239 533 0 242 534 minecraft:black_concrete
setblock 0 239 547 minecraft:sea_lantern
fill 0 239 548 0 307 548 minecraft:black_concrete
fill 3 239 537 5 242 539 minecraft:light_blue_stained_glass
fill 9 239 552 9 279 552 minecraft:black_concrete
setblock 10 239 552 minecraft:sea_lantern
fill 19 239 552 19 245 552 minecraft:black_concrete
fill 34 239 552 34 307 552 minecraft:black_concrete
setblock 42 239 521 minecraft:white_concrete
setblock 0 240 513 minecraft:light_blue_stained_glass
setblock 0 240 521 minecraft:sea_lantern
fill 0 240 547 0 242 547 minecraft:black_concrete
fill 10 240 552 10 244 552 minecraft:black_concrete
setblock 35 240 510 minecraft:sea_lantern
setblock 36 240 552 minecraft:white_concrete
fill 42 240 521 42 251 521 minecraft:black_concrete
setblock 42 240 535 minecraft:light_blue_stained_glass
fill 0 241 513 0 300 513 minecraft:black_concrete
fill 0 241 521 0 246 521 minecraft:black_concrete
fill 0 241 552 2 267 552 minecraft:black_concrete
fill 3 241 552 3 242 552 minecraft:white_concrete
fill 4 241 552 4 307 552 minecraft:black_concrete
fill 33 241 513 35 244 515 minecraft:light_blue_stained_glass
setblock 34 241 510 minecraft:white_concrete
fill 35 241 510 35 307 510 minecraft:black_concrete
fill 36 241 552 36 307 552 minecraft:black_concrete
fill 42 241 535 42 268 535 minecraft:black_concrete
setblock 0 242 539 minecraft:light_blue_stained_glass
fill 0 242 540 0 307 540 minecraft:black_concrete
setblock 14 242 552 minecraft:light_blue_stained_glass
setblock 25 242 510 minecraft:white_concrete
fill 34 242 510 34 267 510 minecraft:black_concrete
setblock 35 242 552 minecraft:light_blue_stained_glass
fill 0 243 518 0 245 518 minecraft:cyan_concrete
fill 0 243 533 0 307 533 minecraft:black_concrete
fill 0 243 534 0 245 534 minecraft:cyan_concrete
fill 0 243 539 0 307 539 minecraft:black_concrete
setblock 0 243 547 minecraft:sea_lantern
fill 0 243 549 0 298 549 minecraft:black_concrete
fill 0 243 550 0 245 550 minecraft:cyan_concrete
fill 1 243 519 7 243 519 minecraft:black_concrete
fill 3 243 517 7 243 518 minecraft:black_concrete
fill 3 243 520 7 243 521 minecraft:black_concrete
fill 3 243 552 3 271 552 minecraft:black_concrete
fill 4 243 510 4 245 510 minecraft:cyan_concrete
fill 14 243 552 14 245 552 minecraft:cyan_concrete
fill 20 243 510 20 245 510 minecraft:cyan_concrete
fill 25 243 510 25 274 510 minecraft:black_concrete
fill 30 243 552 30 245 552 minecraft:cyan_concrete
fill 35 243 552 35 307 552 minecraft:black_concrete
fill 36 243 510 36 245 510 minecraft:cyan_concrete
setblock 42 243 515 minecraft:sea_lantern
fill 42 243 520 42 245 520 minecraft:cyan_concrete
fill 42 243 536 42 245 536 minecraft:cyan_concrete
setblock 42 243 537 minecraft:sea_lantern
setblock 0 244 522 minecraft:light_blue_stained_glass
fill 0 244 523 0 301 523 minecraft:black_concrete
fill 0 244 547 0 248 547 minecraft:black_concrete
fill 2 244 527 18 244 535 minecraft:black_wool
fill 3 244 517 4 244 521 minecraft:black_concrete
fill 3 244 524 39 244 526 minecraft:black_wool
fill 3 244 536 39 244 538 minecraft:black_wool
fill 4 244 522 38 244 523 minecraft:black_wool
fill 4 244 539 38 244 540 minecraft:black_wool
fill 5 244 517 5 244 519 minecraft:black_concrete
fill 5 244 520 37 244 521 minecraft:black_wool
fill 5 244 541 37 244 542 minecraft:black_wool
fill 6 244 517 6 244 518 minecraft:black_concrete
fill 6 244 519 36 244 519 minecraft:black_wool
fill 6 244 543 36 244 543 minecraft:black_wool
setblock 7 244 517 minecraft:black_concrete
fill 7 244 518 35 244 518 minecraft:black_wool
fill 7 244 544 35 244 544 minecraft:black_wool
fill 8 244 517 34 244 517 minecraft:black_wool
fill 8 244 545 34 244 545 minecraft:black_wool
fill 9 244 516 33 244 516 minecraft:black_wool
fill 9 244 546 33 244 546 minecraft:black_wool
fill 10 244 515 32 244 515 minecraft:black_wool
fill 10 244 547 32 244 547 minecraft:black_wool
fill 12 244 514 30 244 514 minecraft:black_wool
fill 12 244 548 30 244 548 minecraft:black_wool
fill 14 244 513 28 244 513 minecraft:black_wool
fill 14 244 549 28 244 549 minecraft:black_wool
fill 17 244 512 25 244 512 minecraft:black_wool
fill 17 244 550 25 244 550 minecraft:black_wool
fill 19 244 527 19 272 530 minecraft:black_wool
fill 19 244 533 19 272 535 minecraft:black_wool
fill 20 244 527 40 244 528 minecraft:black_wool
fill 20 244 534 20 272 535 minecraft:black_wool
fill 21 244 535 40 244 535 minecraft:black_wool
fill 25 244 529 40 244 529 minecraft:black_wool
fill 25 244 534 40 244 534 minecraft:black_wool
fill 26 244 530 40 244 533 minecraft:black_wool
setblock 40 244 552 minecraft:light_blue_stained_glass
fill 42 244 515 42 284 515 minecraft:black_concrete
setblock 42 244 537 minecraft:black_concrete
fill 0 245 522 0 307 522 minecraft:black_concrete
setblock 0 245 531 minecraft:sea_lantern
fill 0 245 532 0 269 532 minecraft:black_concrete
fill 2 245 530 18 245 532 minecraft:black_wool
setblock 3 245 513 minecraft:light[level=11]
setblock 3 245 521 minecraft:light[level=11]
fill 3 245 525 18 245 529 minecraft:black_wool
fill 3 245 533 18 245 537 minecraft:black_wool
setblock 3 245 545 minecraft:light[level=11]
fill 4 245 519 35 246 519 minecraft:black_wool
fill 4 245 523 38 245 524 minecraft:black_wool
fill 4 245 538 38 245 539 minecraft:black_wool
fill 5 245 521 37 245 522 minecraft:black_wool
fill 5 245 540 37 245 541 minecraft:black_wool
fill 6 245 520 36 245 520 minecraft:black_wool
fill 6 245 542 36 245 542 minecraft:black_wool
setblock 7 245 510 minecraft:white_concrete
fill 7 245 543 35 246 543 minecraft:black_wool
fill 8 245 510 8 259 510 minecraft:black_concrete
fill 8 245 518 34 246 518 minecraft:black_wool
fill 8 245 544 34 246 544 minecraft:black_wool
fill 9 245 517 33 246 517 minecraft:black_wool
fill 9 245 545 33 246 545 minecraft:black_wool
fill 10 245 516 32 245 516 minecraft:black_wool
fill 10 245 546 32 245 546 minecraft:black_wool
setblock 10 245 552 minecraft:light_blue_stained_glass
setblock 11 245 513 minecraft:light[level=11]
fill 11 245 515 31 245 515 minecraft:black_wool
fill 11 245 547 31 245 547 minecraft:black_wool
fill 13 245 514 29 245 514 minecraft:black_wool
fill 13 245 548 29 245 548 minecraft:black_wool
fill 15 245 513 27 245 513 minecraft:black_wool
fill 15 245 549 27 245 549 minecraft:black_wool
fill 15 245 552 16 254 552 minecraft:black_concrete
setblock 16 245 510 minecraft:sea_lantern
setblock 17 245 552 minecraft:sea_lantern
setblock 18 245 552 minecraft:black_concrete
fill 19 245 525 39 245 526 minecraft:black_wool
fill 19 245 536 39 245 537 minecraft:black_wool
fill 20 245 512 22 245 512 minecraft:black_wool
fill 20 245 527 21 249 528 minecraft:black_wool
fill 20 245 550 22 245 550 minecraft:black_wool
fill 21 245 535 39 246 535 minecraft:black_wool
fill 22 245 527 39 246 527 minecraft:black_wool
fill 23 245 528 39 245 528 minecraft:black_wool
fill 25 245 529 39 247 529 minecraft:black_wool
fill 25 245 534 39 246 534 minecraft:black_wool
fill 26 245 530 39 247 533 minecraft:black_wool
fill 26 245 552 27 265 552 minecraft:black_concrete
setblock 28 245 552 minecraft:light_blue_stained_glass
fill 29 245 552 29 275 552 minecraft:black_concrete
setblock 35 245 513 minecraft:light[level=11]
setblock 35 245 545 minecraft:light[level=11]
fill 40 245 530 40 245 532 minecraft:black_wool
fill 40 245 552 40 290 552 minecraft:black_concrete
fill 42 245 537 42 245 538 minecraft:sea_lantern
fill 0 246 518 0 251 518 minecraft:black_concrete
fill 0 246 531 0 273 531 minecraft:black_concrete
fill 0 246 534 0 251 534 minecraft:black_concrete
fill 0 246 550 0 251 550 minecraft:black_concrete
fill 3 246 527 18 246 535 minecraft:black_wool
fill 4 246 510 4 251 510 minecraft:black_concrete
fill 4 246 524 38 246 526 minecraft:black_wool
fill 4 246 536 38 246 538 minecraft:black_wool
fill 5 246 522 37 246 523 minecraft:black_wool
fill 5 246 539 37 246 540 minecraft:black_wool
fill 6 246 521 36 247 521 minecraft:black_wool
fill 6 246 541 36 247 541 minecraft:black_wool
setblock 7 246 510 minecraft:light_blue_stained_glass
fill 7 246 520 35 247 520 minecraft:black_wool
fill 7 246 542 35 247 542 minecraft:black_wool
fill 10 246 552 10 260 552 minecraft:black_concrete
fill 11 246 516 31 247 516 minecraft:black_wool
fill 11 246 546 31 247 546 minecraft:black_wool
fill 12 246 515 30 246 515 minecraft:black_wool
fill 12 246 547 30 246 547 minecraft:black_wool
fill 13 246 510 13 271 510 minecraft:black_concrete
setblock 14 246 510 minecraft:light_blue_stained_glass
fill 14 246 514 28 246 514 minecraft:black_wool
fill 14 246 548 28 246 548 minecraft:black_wool
fill 14 246 552 14 251 552 minecraft:black_concrete
fill 16 246 510 16 294 510 minecraft:black_concrete
fill 17 246 513 25 246 513 minecraft:black_wool
fill 17 246 549 25 246 549 minecraft:black_wool
fill 17 246 552 17 307 552 minecraft:black_concrete
fill 18 246 552 19 246 552 minecraft:white_concrete
fill 19 246 532 19 272 532 minecraft:black_wool
fill 20 246 510 20 251 510 minecraft:black_concrete
fill 24 246 528 39 246 528 minecraft:black_wool
fill 28 246 552 28 307 552 minecraft:black_concrete
fill 30 246 552 31 251 552 minecraft:black_concrete
setblock 32 246 552 minecraft:light_blue_stained_glass
fill 36 246 510 36 251 510 minecraft:black_concrete
setblock 38 246 510 minecraft:white_concrete
fill 39 246 510 40 305 510 minecraft:black_concrete
fill 42 246 520 42 251 520 minecraft:black_concrete
fill 42 246 536 42 251 538 minecraft:black_concrete
setblock 42 246 549 minecraft:light_blue_stained_glass
setblock 0 247 521 minecraft:white_concrete
fill 3 247 529 18 247 533 minecraft:black_wool
fill 4 247 519 6 249 519 minecraft:black_wool
fill 4 247 525 18 247 528 minecraft:black_wool
fill 4 247 534 18 247 537 minecraft:black_wool
fill 5 247 523 37 247 524 minecraft:black_wool
fill 5 247 538 37 247 539 minecraft:black_wool
fill 6 247 522 36 248 522 minecraft:black_wool
fill 6 247 540 36 248 540 minecraft:black_wool
fill 7 247 510 7 299 510 minecraft:black_concrete
fill 8 247 519 34 248 519 minecraft:black_wool
fill 8 247 543 34 248 543 minecraft:black_wool
fill 9 247 518 33 248 518 minecraft:black_wool
fill 9 247 544 33 248 544 minecraft:black_wool
fill 10 247 517 32 247 517 minecraft:black_wool
fill 10 247 545 32 247 545 minecraft:black_wool
fill 13 247 515 29 247 515 minecraft:black_wool
fill 13 247 547 29 247 547 minecraft:black_wool
fill 14 247 510 14 307 510 minecraft:black_concrete
fill 15 247 514 27 247 514 minecraft:black_wool
fill 15 247 548 27 247 548 minecraft:black_wool
fill 18 247 552 19 249 552 minecraft:black_concrete
fill 19 247 513 23 247 513 minecraft:black_wool
fill 19 247 525 38 247 526 minecraft:black_wool
fill 19 247 536 38 247 537 minecraft:black_wool
fill 19 247 549 23 247 549 minecraft:black_wool
fill 21 247 535 38 248 535 minecraft:black_wool
fill 22 247 527 38 248 527 minecraft:black_wool
fill 24 247 528 38 248 528 minecraft:black_wool
fill 25 247 534 38 248 534 minecraft:black_wool
setblock 25 247 552 minecraft:white_concrete
setblock 31 247 510 minecraft:sea_lantern
setblock 32 247 552 minecraft:white_concrete
fill 38 247 510 38 307 510 minecraft:black_concrete
fill 42 247 549 42 258 549 minecraft:black_concrete
fill 0 248 514 0 307 514 minecraft:black_concrete
setblock 0 248 515 minecraft:light_blue_stained_glass
fill 0 248 521 0 272 521 minecraft:black_concrete
fill 4 248 527 18 248 535 minecraft:black_wool
fill 5 248 518 5 249 518 minecraft:black_wool
fill 5 248 520 5 249 520 minecraft:black_wool
fill 5 248 524 37 248 526 minecraft:black_wool
fill 5 248 536 37 248 538 minecraft:black_wool
fill 6 248 523 36 249 523 minecraft:black_wool
fill 6 248 539 36 249 539 minecraft:black_wool
fill 7 248 521 35 249 521 minecraft:black_wool
fill 7 248 541 35 249 541 minecraft:black_wool
fill 8 248 520 34 249 520 minecraft:black_wool
fill 8 248 542 34 249 542 minecraft:black_wool
fill 11 248 517 31 249 517 minecraft:black_wool
fill 11 248 545 31 249 545 minecraft:black_wool
fill 12 248 516 30 248 516 minecraft:black_wool
fill 12 248 546 30 248 546 minecraft:black_wool
fill 14 248 515 28 248 515 minecraft:black_wool
fill 14 248 547 28 248 547 minecraft:black_wool
setblock 17 248 510 minecraft:white_concrete
fill 17 248 514 25 248 514 minecraft:black_wool
fill 17 248 548 25 248 548 minecraft:black_wool
fill 25 248 529 38 248 529 minecraft:black_wool
fill 25 248 552 25 307 552 minecraft:black_concrete
fill 26 248 530 38 249 533 minecraft:black_wool
fill 31 248 510 31 293 510 minecraft:black_concrete
fill 32 248 552 32 293 552 minecraft:black_concrete
schedule function dropper:buildpart/120_2 1t
