fill 58 190 470 60 190 470 minecraft:basalt
fill 58 190 472 58 191 472 minecraft:basalt
fill 58 190 490 58 191 490 minecraft:basalt
setblock 59 190 469 minecraft:magma_block
setblock 59 190 493 minecraft:magma_block
fill 60 190 468 60 190 469 minecraft:basalt
fill 60 190 476 61 196 476 minecraft:basalt
fill 60 190 479 60 197 483 minecraft:basalt
fill 60 190 485 61 190 485 minecraft:basalt
fill 60 190 493 60 190 494 minecraft:basalt
fill 61 190 469 61 191 469 minecraft:basalt
fill 61 190 477 61 196 477 minecraft:basalt
fill 61 190 486 61 196 486 minecraft:basalt
fill 61 190 493 61 191 493 minecraft:basalt
fill 62 190 475 62 197 475 minecraft:basalt
fill 62 190 487 62 197 487 minecraft:basalt
setblock 62 190 495 minecraft:magma_block
setblock 63 190 466 minecraft:basalt
fill 63 190 474 63 197 474 minecraft:basalt
fill 63 190 488 63 197 488 minecraft:basalt
fill 63 190 495 63 190 496 minecraft:basalt
fill 64 190 473 64 196 473 minecraft:basalt
fill 64 190 489 64 197 489 minecraft:basalt
fill 64 190 495 65 191 495 minecraft:basalt
fill 65 190 472 66 197 472 minecraft:basalt
fill 65 190 490 66 197 490 minecraft:basalt
setblock 66 190 465 minecraft:basalt
fill 66 190 471 66 196 471 minecraft:basalt
fill 66 190 497 69 190 497 minecraft:basalt
fill 68 190 465 70 190 465 minecraft:basalt
fill 68 190 471 70 196 471 minecraft:basalt
fill 68 190 491 72 190 491 minecraft:basalt
fill 69 190 470 69 196 470 minecraft:basalt
setblock 71 190 465 minecraft:magma_block
setblock 71 190 471 minecraft:magma_block
fill 71 190 497 73 190 497 minecraft:basalt
fill 72 190 465 74 190 465 minecraft:basalt
fill 72 190 471 72 197 471 minecraft:basalt
fill 72 190 500 79 190 500 minecraft:quartz_block
fill 73 190 464 73 230 464 minecraft:quartz_block
fill 73 190 501 77 190 504 minecraft:quartz_block
fill 74 190 466 76 190 466 minecraft:basalt
fill 74 190 472 75 197 472 minecraft:basalt
fill 74 190 490 75 197 490 minecraft:basalt
fill 74 190 496 76 190 496 minecraft:basalt
setblock 74 190 497 minecraft:magma_block
fill 75 190 471 75 196 471 minecraft:basalt
fill 76 190 473 76 197 473 minecraft:basalt
fill 76 190 489 76 197 489 minecraft:basalt
setblock 77 190 466 minecraft:magma_block
fill 77 190 467 78 190 468 minecraft:basalt
fill 77 190 474 77 197 474 minecraft:basalt
fill 77 190 488 78 196 488 minecraft:basalt
setblock 77 190 496 minecraft:magma_block
fill 78 190 475 78 197 475 minecraft:basalt
fill 78 190 487 78 197 487 minecraft:basalt
fill 78 190 501 80 190 503 minecraft:quartz_block
setblock 79 190 468 minecraft:basalt
fill 79 190 476 79 196 477 minecraft:basalt
fill 79 190 485 79 190 486 minecraft:basalt
fill 79 190 499 83 190 499 minecraft:black_concrete
setblock 80 190 468 minecraft:magma_block
fill 80 190 470 82 190 470 minecraft:basalt
fill 80 190 479 80 197 479 minecraft:basalt
setblock 80 190 480 minecraft:magma_block
fill 80 190 481 80 197 482 minecraft:basalt
setblock 80 190 483 minecraft:magma_block
fill 80 190 492 82 190 492 minecraft:basalt
setblock 80 190 494 minecraft:basalt
fill 80 190 504 82 190 504 minecraft:quartz_block
fill 81 190 481 81 196 481 minecraft:basalt
fill 81 190 491 82 191 491 minecraft:basalt
fill 81 190 502 81 190 503 minecraft:quartz_block
fill 83 190 472 83 190 474 minecraft:basalt
fill 83 190 488 83 190 490 minecraft:basalt
setblock 83 190 491 minecraft:magma_block
fill 83 190 494 83 190 498 minecraft:black_concrete
fill 84 190 473 84 190 474 minecraft:basalt
fill 84 190 488 84 190 489 minecraft:basalt
setblock 85 190 475 minecraft:basalt
fill 85 190 478 85 191 479 minecraft:basalt
fill 85 190 481 85 191 482 minecraft:basalt
fill 85 190 484 85 191 485 minecraft:basalt
setblock 86 190 477 minecraft:basalt
setblock 86 190 478 minecraft:magma_block
fill 86 190 479 86 190 480 minecraft:basalt
setblock 86 190 481 minecraft:magma_block
fill 86 190 482 86 190 483 minecraft:basalt
setblock 86 190 484 minecraft:magma_block
setblock 86 190 485 minecraft:basalt
setblock 50 191 466 minecraft:light[level=14]
setblock 50 191 474 minecraft:light[level=14]
setblock 50 191 482 minecraft:light[level=14]
setblock 50 191 490 minecraft:light[level=14]
setblock 50 191 498 minecraft:light[level=14]
setblock 55 191 477 minecraft:basalt
setblock 55 191 478 minecraft:magma_block
setblock 55 191 481 minecraft:magma_block
setblock 55 191 484 minecraft:magma_block
fill 56 191 474 57 191 474 minecraft:basalt
setblock 56 191 486 minecraft:basalt
setblock 56 191 488 minecraft:basalt
setblock 57 191 473 minecraft:basalt
setblock 58 191 466 minecraft:light[level=14]
setblock 58 191 471 minecraft:magma_block
setblock 58 191 498 minecraft:light[level=14]
fill 59 191 470 60 191 470 minecraft:basalt
setblock 60 191 469 minecraft:basalt
fill 60 191 485 60 196 485 minecraft:basalt
setblock 60 191 493 minecraft:basalt
fill 61 191 478 61 197 478 minecraft:basalt
setblock 61 191 479 minecraft:magma_block
fill 61 191 483 61 196 484 minecraft:basalt
setblock 61 191 485 minecraft:magma_block
fill 62 191 468 63 191 468 minecraft:basalt
fill 62 191 476 62 197 476 minecraft:basalt
fill 62 191 486 62 197 486 minecraft:basalt
fill 63 191 467 65 191 467 minecraft:basalt
fill 63 191 475 63 197 475 minecraft:basalt
fill 63 191 487 63 197 487 minecraft:basalt
setblock 63 191 495 minecraft:basalt
fill 64 191 474 64 197 474 minecraft:basalt
fill 64 191 488 64 196 488 minecraft:basalt
fill 65 191 473 65 197 473 minecraft:basalt
fill 65 191 489 65 197 489 minecraft:basalt
fill 66 191 466 68 191 466 minecraft:basalt
setblock 66 191 474 minecraft:light[level=14]
setblock 66 191 482 minecraft:light[level=14]
fill 66 191 496 68 191 496 minecraft:basalt
setblock 66 191 498 minecraft:light[level=14]
fill 67 191 472 68 196 472 minecraft:basalt
fill 67 191 490 68 196 490 minecraft:basalt
fill 68 191 491 69 197 491 minecraft:basalt
fill 68 191 500 69 192 504 minecraft:quartz_block
fill 70 191 466 72 191 466 minecraft:basalt
setblock 70 191 491 minecraft:magma_block
fill 70 191 496 72 191 496 minecraft:basalt
fill 70 191 500 74 191 503 minecraft:quartz_block
fill 71 191 471 71 197 471 minecraft:basalt
fill 71 191 491 72 197 491 minecraft:basalt
fill 72 191 472 72 197 472 minecraft:basalt
fill 72 191 490 72 197 490 minecraft:basalt
fill 72 191 504 76 191 504 minecraft:quartz_block
setblock 73 191 466 minecraft:magma_block
setblock 73 191 472 minecraft:magma_block
setblock 73 191 490 minecraft:magma_block
setblock 73 191 496 minecraft:magma_block
setblock 74 191 466 minecraft:basalt
setblock 74 191 474 minecraft:light[level=14]
setblock 74 191 482 minecraft:light[level=14]
setblock 74 191 496 minecraft:basalt
setblock 74 191 498 minecraft:light[level=14]
fill 75 191 473 75 197 473 minecraft:basalt
fill 75 191 489 75 197 489 minecraft:basalt
fill 75 191 499 82 191 499 minecraft:black_concrete
fill 75 191 502 75 191 503 minecraft:quartz_block
setblock 76 191 474 minecraft:magma_block
fill 76 191 488 76 197 488 minecraft:basalt
fill 76 191 494 78 191 494 minecraft:basalt
setblock 76 191 495 minecraft:magma_block
fill 77 191 467 77 191 468 minecraft:basalt
fill 77 191 475 77 197 475 minecraft:basalt
fill 77 191 487 77 197 487 minecraft:basalt
setblock 77 191 495 minecraft:basalt
setblock 78 191 468 minecraft:basalt
fill 78 191 476 78 197 476 minecraft:basalt
fill 78 191 486 79 196 486 minecraft:basalt
fill 79 191 469 80 191 469 minecraft:basalt
fill 79 191 478 79 197 478 minecraft:basalt
setblock 79 191 479 minecraft:magma_block
fill 79 191 483 79 196 484 minecraft:basalt
setblock 79 191 485 minecraft:magma_block
fill 79 191 493 80 191 493 minecraft:basalt
fill 80 191 470 81 191 470 minecraft:basalt
fill 80 191 480 80 197 480 minecraft:basalt
fill 80 191 483 80 197 483 minecraft:basalt
fill 80 191 492 81 191 492 minecraft:basalt
fill 81 191 471 81 191 472 minecraft:basalt
fill 81 191 490 81 192 490 minecraft:basalt
setblock 82 191 466 minecraft:light[level=14]
setblock 82 191 471 minecraft:basalt
setblock 82 191 472 minecraft:magma_block
setblock 82 191 490 minecraft:magma_block
setblock 82 191 498 minecraft:light[level=14]
fill 83 191 473 83 191 474 minecraft:basalt
fill 83 191 488 83 191 489 minecraft:basalt
setblock 84 191 474 minecraft:basalt
setblock 84 191 488 minecraft:basalt
setblock 85 191 477 minecraft:magma_block
setblock 85 191 480 minecraft:magma_block
setblock 85 191 483 minecraft:magma_block
fill 47 192 468 47 199 468 minecraft:light_gray_concrete
fill 47 192 476 47 199 476 minecraft:light_gray_concrete
fill 47 192 484 47 199 484 minecraft:light_gray_concrete
fill 47 192 492 47 199 492 minecraft:light_gray_concrete
fill 47 192 500 47 199 500 minecraft:light_gray_concrete
fill 50 192 505 50 199 505 minecraft:light_gray_concrete
fill 54 192 463 54 199 463 minecraft:light_gray_concrete
setblock 57 192 474 minecraft:basalt
setblock 57 192 476 minecraft:magma_block
fill 57 192 477 57 193 477 minecraft:basalt
setblock 57 192 488 minecraft:magma_block
fill 58 192 488 58 193 488 minecraft:basalt
fill 58 192 505 58 199 505 minecraft:light_gray_concrete
fill 61 192 479 61 196 482 minecraft:basalt
fill 61 192 485 62 197 485 minecraft:basalt
fill 62 192 463 62 199 463 minecraft:light_gray_concrete
fill 62 192 477 62 197 478 minecraft:basalt
fill 62 192 484 62 197 484 minecraft:basalt
setblock 63 192 468 minecraft:magma_block
fill 63 192 476 63 197 476 minecraft:basalt
setblock 63 192 486 minecraft:magma_block
setblock 63 192 494 minecraft:basalt
fill 64 192 475 64 197 475 minecraft:basalt
fill 64 192 487 64 197 487 minecraft:basalt
fill 64 192 501 67 192 504 minecraft:quartz_block
fill 65 192 474 65 197 474 minecraft:basalt
fill 65 192 488 65 197 488 minecraft:basalt
fill 65 192 500 67 192 500 minecraft:quartz_block
setblock 66 192 467 minecraft:magma_block
setblock 66 192 473 minecraft:magma_block
fill 66 192 489 67 197 489 minecraft:basalt
fill 66 192 505 66 199 505 minecraft:light_gray_concrete
fill 67 192 473 67 197 473 minecraft:basalt
setblock 69 192 467 minecraft:basalt
setblock 69 192 472 minecraft:magma_block
setblock 69 192 490 minecraft:magma_block
fill 69 192 495 71 192 495 minecraft:basalt
fill 70 192 463 70 199 463 minecraft:light_gray_concrete
fill 70 192 472 71 197 472 minecraft:basalt
fill 70 192 490 70 197 491 minecraft:basalt
fill 70 192 500 70 192 503 minecraft:quartz_block
fill 71 192 490 71 197 490 minecraft:basalt
fill 71 192 499 76 192 499 minecraft:black_concrete
setblock 72 192 495 minecraft:magma_block
fill 73 192 472 73 196 473 minecraft:basalt
fill 73 192 489 73 197 490 minecraft:basalt
fill 74 192 473 74 197 473 minecraft:basalt
fill 74 192 489 74 197 489 minecraft:basalt
fill 74 192 494 74 193 494 minecraft:basalt
fill 74 192 505 74 199 505 minecraft:light_gray_concrete
fill 75 192 474 76 197 474 minecraft:basalt
setblock 75 192 488 minecraft:magma_block
setblock 75 192 494 minecraft:magma_block
fill 76 192 468 77 192 468 minecraft:basalt
fill 76 192 475 76 196 475 minecraft:basalt
fill 76 192 487 76 196 487 minecraft:basalt
fill 76 192 494 77 192 494 minecraft:basalt
fill 77 192 469 77 193 469 minecraft:basalt
fill 77 192 476 77 197 476 minecraft:basalt
setblock 77 192 486 minecraft:basalt
fill 77 192 493 77 193 493 minecraft:basalt
fill 78 192 463 78 199 463 minecraft:light_gray_concrete
setblock 78 192 469 minecraft:magma_block
fill 78 192 477 78 197 477 minecraft:basalt
setblock 78 192 478 minecraft:magma_block
setblock 78 192 484 minecraft:magma_block
fill 78 192 485 79 197 485 minecraft:basalt
setblock 78 192 493 minecraft:magma_block
fill 79 192 479 79 196 482 minecraft:basalt
setblock 81 192 472 minecraft:basalt
fill 82 192 505 82 199 505 minecraft:light_gray_concrete
setblock 83 192 474 minecraft:basalt
setblock 83 192 488 minecraft:basalt
setblock 84 192 479 minecraft:magma_block
fill 84 192 480 84 192 481 minecraft:basalt
setblock 84 192 482 minecraft:magma_block
setblock 84 192 485 minecraft:magma_block
fill 86 192 463 86 199 463 minecraft:light_gray_concrete
fill 89 192 468 89 199 468 minecraft:light_gray_concrete
fill 89 192 476 89 199 476 minecraft:light_gray_concrete
fill 89 192 484 89 199 484 minecraft:light_gray_concrete
fill 89 192 492 89 199 492 minecraft:light_gray_concrete
fill 89 192 500 89 199 500 minecraft:light_gray_concrete
fill 50 193 467 50 193 469 minecraft:gray_concrete
fill 51 193 466 53 193 466 minecraft:gray_concrete
fill 51 193 470 53 193 470 minecraft:gray_concrete
fill 54 193 467 54 193 469 minecraft:gray_concrete
setblock 57 193 476 minecraft:basalt
setblock 57 193 478 minecraft:basalt
setblock 57 193 484 minecraft:basalt
fill 58 193 504 61 193 504 minecraft:quartz_block
fill 59 193 488 59 194 488 minecraft:basalt
setblock 59 193 489 minecraft:magma_block
fill 59 193 502 66 193 503 minecraft:quartz_block
fill 60 193 500 66 193 501 minecraft:quartz_block
setblock 62 193 470 minecraft:magma_block
setblock 62 193 479 minecraft:magma_block
fill 62 193 480 62 197 481 minecraft:basalt
setblock 62 193 482 minecraft:magma_block
fill 62 193 483 62 197 483 minecraft:basalt
fill 63 193 470 63 194 470 minecraft:basalt
fill 63 193 477 63 197 477 minecraft:basalt
fill 63 193 485 63 197 486 minecraft:basalt
fill 64 193 504 66 193 504 minecraft:quartz_block
fill 66 193 473 66 197 474 minecraft:basalt
fill 66 193 488 66 197 488 minecraft:basalt
fill 67 193 499 72 193 499 minecraft:black_concrete
setblock 68 193 468 minecraft:magma_block
fill 68 193 473 70 197 473 minecraft:basalt
setblock 68 193 489 minecraft:magma_block
fill 68 193 494 70 193 494 minecraft:basalt
fill 69 193 472 69 197 472 minecraft:basalt
fill 69 193 489 69 197 490 minecraft:basalt
fill 70 193 489 72 196 489 minecraft:basalt
setblock 71 193 473 minecraft:magma_block
setblock 71 193 494 minecraft:magma_block
fill 72 193 473 72 197 473 minecraft:basalt
fill 74 193 474 74 197 474 minecraft:basalt
fill 74 193 488 75 197 488 minecraft:basalt
setblock 75 193 494 minecraft:basalt
setblock 77 193 477 minecraft:magma_block
fill 77 193 485 77 197 485 minecraft:basalt
setblock 77 193 486 minecraft:magma_block
fill 78 193 478 78 197 484 minecraft:basalt
setblock 82 193 487 minecraft:basalt
setblock 83 193 478 minecraft:magma_block
fill 83 193 479 83 193 480 minecraft:basalt
setblock 83 193 481 minecraft:magma_block
fill 83 193 482 83 193 483 minecraft:basalt
setblock 83 193 484 minecraft:magma_block
fill 51 194 504 53 197 504 minecraft:quartz_block
fill 52 194 503 61 194 503 minecraft:quartz_block
fill 53 194 501 61 194 502 minecraft:quartz_block
fill 54 194 500 62 194 500 minecraft:quartz_block
fill 56 194 504 60 194 504 minecraft:quartz_block
fill 57 194 480 58 194 480 minecraft:basalt
setblock 57 194 482 minecraft:basalt
setblock 58 194 476 minecraft:magma_block
fill 58 194 477 58 194 478 minecraft:basalt
setblock 58 194 479 minecraft:magma_block
setblock 58 194 484 minecraft:basalt
setblock 58 194 485 minecraft:magma_block
setblock 58 194 486 minecraft:basalt
setblock 61 194 472 minecraft:magma_block
setblock 61 194 490 minecraft:magma_block
fill 62 194 479 63 194 479 minecraft:basalt
fill 62 194 482 62 197 482 minecraft:basalt
setblock 62 194 501 minecraft:quartz_block
fill 63 194 478 63 197 478 minecraft:basalt
fill 63 194 483 63 197 484 minecraft:basalt
fill 63 194 499 68 194 499 minecraft:black_concrete
fill 64 194 476 64 196 476 minecraft:basalt
setblock 64 194 477 minecraft:magma_block
fill 64 194 485 64 196 485 minecraft:basalt
setblock 64 194 486 minecraft:magma_block
setblock 64 194 492 minecraft:magma_block
setblock 65 194 469 minecraft:basalt
fill 65 194 475 66 194 475 minecraft:basalt
fill 65 194 487 66 194 487 minecraft:basalt
setblock 65 194 493 minecraft:basalt
setblock 67 194 469 minecraft:basalt
fill 67 194 474 68 197 474 minecraft:basalt
setblock 67 194 488 minecraft:magma_block
setblock 67 194 493 minecraft:basalt
fill 68 194 488 68 197 489 minecraft:basalt
fill 69 194 494 71 194 494 minecraft:basalt
fill 70 194 468 71 194 468 minecraft:basalt
fill 71 194 473 71 197 473 minecraft:basalt
fill 72 194 474 72 197 474 minecraft:basalt
fill 72 194 488 73 194 488 minecraft:basalt
fill 72 194 493 73 194 493 minecraft:basalt
setblock 73 194 474 minecraft:magma_block
fill 74 194 475 75 197 475 minecraft:basalt
fill 74 194 487 75 197 487 minecraft:basalt
setblock 76 194 470 minecraft:magma_block
setblock 76 194 476 minecraft:magma_block
fill 76 194 477 77 197 477 minecraft:basalt
setblock 76 194 485 minecraft:magma_block
fill 76 194 486 77 197 486 minecraft:basalt
setblock 76 194 492 minecraft:basalt
fill 77 194 478 77 197 479 minecraft:basalt
fill 77 194 483 77 197 484 minecraft:basalt
setblock 79 194 472 minecraft:magma_block
setblock 79 194 490 minecraft:magma_block
setblock 82 194 476 minecraft:basalt
setblock 82 194 477 minecraft:magma_block
fill 82 194 478 82 194 482 minecraft:basalt
setblock 82 194 483 minecraft:magma_block
fill 82 194 484 82 194 485 minecraft:basalt
setblock 82 194 486 minecraft:magma_block
fill 83 194 480 83 194 482 minecraft:basalt
fill 48 195 498 52 195 501 minecraft:quartz_block
fill 48 195 504 50 197 504 minecraft:quartz_block
fill 49 195 502 55 195 503 minecraft:quartz_block
fill 50 195 497 52 196 497 minecraft:quartz_block
fill 51 195 496 52 196 496 minecraft:quartz_block
fill 53 195 500 56 195 501 minecraft:quartz_block
setblock 56 195 502 minecraft:quartz_block
setblock 57 195 500 minecraft:quartz_block
fill 58 195 479 58 195 481 minecraft:basalt
fill 59 195 499 65 195 499 minecraft:black_concrete
setblock 60 195 475 minecraft:basalt
setblock 61 195 489 minecraft:basalt
fill 62 195 479 62 197 479 minecraft:basalt
setblock 63 195 479 minecraft:magma_block
fill 63 195 480 63 197 481 minecraft:basalt
setblock 63 195 482 minecraft:magma_block
setblock 63 195 490 minecraft:basalt
fill 64 195 477 64 197 478 minecraft:basalt
fill 64 195 484 64 197 484 minecraft:basalt
fill 64 195 486 65 197 486 minecraft:basalt
fill 65 195 475 65 197 476 minecraft:basalt
fill 65 195 487 65 197 487 minecraft:basalt
setblock 66 195 475 minecraft:magma_block
setblock 66 195 487 minecraft:magma_block
setblock 66 195 492 minecraft:basalt
fill 67 195 475 67 196 475 minecraft:basalt
fill 67 195 487 67 196 488 minecraft:basalt
setblock 69 195 474 minecraft:magma_block
fill 69 195 488 71 197 488 minecraft:basalt
fill 70 195 474 71 196 474 minecraft:basalt
setblock 72 195 488 minecraft:magma_block
setblock 72 195 493 minecraft:basalt
fill 73 195 474 73 197 475 minecraft:basalt
fill 73 195 487 73 196 488 minecraft:basalt
fill 75 195 476 76 197 476 minecraft:basalt
fill 75 195 486 75 197 486 minecraft:basalt
setblock 75 195 492 minecraft:basalt
fill 76 195 478 76 196 478 minecraft:basalt
fill 76 195 484 76 196 485 minecraft:basalt
fill 77 195 480 77 197 482 minecraft:basalt
fill 77 195 490 78 195 490 minecraft:basalt
setblock 78 195 472 minecraft:basalt
setblock 78 195 489 minecraft:magma_block
setblock 81 195 476 minecraft:magma_block
setblock 81 195 477 minecraft:basalt
setblock 81 195 485 minecraft:magma_block
setblock 81 195 486 minecraft:basalt
fill 82 195 479 82 195 483 minecraft:basalt
fill 48 196 464 48 197 469 minecraft:quartz_block
fill 48 196 472 49 196 477 minecraft:quartz_block
fill 48 196 480 49 196 485 minecraft:quartz_block
fill 48 196 488 49 197 493 minecraft:quartz_block
fill 48 196 496 49 196 501 minecraft:quartz_block
fill 49 196 465 49 196 471 minecraft:quartz_block
fill 49 196 478 49 196 479 minecraft:quartz_block
fill 49 196 486 49 196 487 minecraft:quartz_block
fill 49 196 494 52 196 495 minecraft:quartz_block
fill 49 196 502 49 196 503 minecraft:quartz_block
fill 50 196 465 87 196 465 minecraft:quartz_block
fill 50 196 491 52 196 493 minecraft:quartz_block
setblock 50 196 496 minecraft:quartz_block
fill 50 196 498 50 196 500 minecraft:quartz_block
fill 50 196 503 88 196 503 minecraft:quartz_block
fill 51 196 464 56 197 464 minecraft:quartz_block
fill 51 196 498 51 196 499 minecraft:quartz_block
setblock 52 196 498 minecraft:quartz_block
fill 53 196 498 53 197 499 minecraft:black_concrete
fill 54 196 499 61 196 499 minecraft:black_concrete
fill 56 196 504 61 197 504 minecraft:quartz_block
fill 59 196 464 64 197 464 minecraft:quartz_block
setblock 59 196 479 minecraft:magma_block
fill 59 196 480 59 196 481 minecraft:basalt
setblock 59 196 482 minecraft:magma_block
setblock 59 196 483 minecraft:basalt
setblock 61 196 475 minecraft:basalt
fill 63 196 479 64 196 479 minecraft:basalt
fill 63 196 482 64 196 482 minecraft:basalt
fill 64 196 480 64 196 481 minecraft:basalt
fill 64 196 483 64 197 483 minecraft:basalt
setblock 64 196 490 minecraft:basalt
fill 64 196 504 69 197 504 minecraft:quartz_block
setblock 65 196 471 minecraft:magma_block
setblock 65 196 477 minecraft:magma_block
fill 65 196 485 65 197 485 minecraft:basalt
setblock 65 196 491 minecraft:basalt
fill 66 196 475 66 197 476 minecraft:basalt
fill 66 196 486 66 197 487 minecraft:basalt
fill 67 196 464 72 197 464 minecraft:quartz_block
setblock 67 196 471 minecraft:basalt
setblock 68 196 470 minecraft:magma_block
fill 68 196 475 70 196 475 minecraft:basalt
fill 68 196 487 70 196 487 minecraft:basalt
fill 68 196 492 69 196 492 minecraft:basalt
fill 69 196 474 69 197 474 minecraft:basalt
fill 70 196 470 72 196 470 minecraft:basalt
fill 71 196 475 71 197 475 minecraft:magma_block
fill 71 196 487 71 197 487 minecraft:magma_block
fill 71 196 492 72 196 492 minecraft:basalt
fill 72 196 475 72 197 475 minecraft:basalt
fill 72 196 487 72 197 488 minecraft:basalt
fill 72 196 504 77 197 504 minecraft:quartz_block
setblock 73 196 471 minecraft:basalt
setblock 74 196 471 minecraft:magma_block
fill 74 196 476 74 197 476 minecraft:basalt
setblock 74 196 486 minecraft:magma_block
fill 75 196 464 80 197 464 minecraft:quartz_block
fill 75 196 477 75 197 477 minecraft:basalt
fill 75 196 485 75 197 485 minecraft:basalt
fill 76 196 479 76 196 483 minecraft:basalt
setblock 77 196 473 minecraft:magma_block
setblock 78 196 474 minecraft:basalt
fill 80 196 476 80 196 477 minecraft:basalt
setblock 80 196 478 minecraft:magma_block
setblock 80 196 484 minecraft:magma_block
fill 80 196 485 80 196 486 minecraft:basalt
fill 80 196 504 85 197 504 minecraft:quartz_block
fill 81 196 479 81 196 480 minecraft:basalt
fill 81 196 482 81 196 483 minecraft:basalt
fill 83 196 464 88 197 464 minecraft:quartz_block
fill 87 196 466 87 196 502 minecraft:quartz_block
fill 88 196 467 88 197 472 minecraft:quartz_block
fill 88 196 475 88 197 480 minecraft:quartz_block
fill 88 196 483 88 197 488 minecraft:quartz_block
fill 88 196 491 88 197 496 minecraft:quartz_block
fill 88 196 499 88 197 502 minecraft:quartz_block
fill 88 196 504 88 197 504 minecraft:quartz_block
fill 48 197 472 48 197 477 minecraft:quartz_block
fill 48 197 480 48 197 485 minecraft:quartz_block
fill 48 197 496 48 197 501 minecraft:quartz_block
fill 49 197 487 52 198 487 minecraft:quartz_block
fill 49 197 494 50 197 494 minecraft:quartz_block
fill 50 197 488 51 197 493 minecraft:quartz_block
fill 52 197 486 52 198 486 minecraft:quartz_block
fill 52 197 488 52 197 492 minecraft:quartz_block
fill 53 197 493 53 197 497 minecraft:black_concrete
fill 54 197 499 55 197 499 minecraft:black_concrete
setblock 61 197 476 minecraft:basalt
setblock 61 197 477 minecraft:magma_block
setblock 61 197 479 minecraft:basalt
setblock 61 197 480 minecraft:magma_block
fill 61 197 481 61 197 482 minecraft:basalt
setblock 61 197 483 minecraft:magma_block
setblock 61 197 484 minecraft:basalt
setblock 61 197 486 minecraft:magma_block
setblock 63 197 479 minecraft:basalt
setblock 63 197 482 minecraft:basalt
setblock 64 197 473 minecraft:magma_block
setblock 64 197 476 minecraft:magma_block
fill 64 197 479 64 197 482 minecraft:magma_block
setblock 64 197 485 minecraft:magma_block
setblock 64 197 488 minecraft:magma_block
setblock 65 197 477 minecraft:basalt
fill 65 197 478 65 197 480 minecraft:magma_block
fill 65 197 482 65 197 484 minecraft:magma_block
setblock 66 197 477 minecraft:magma_block
setblock 66 197 485 minecraft:magma_block
setblock 67 197 472 minecraft:magma_block
fill 67 197 475 67 197 476 minecraft:magma_block
fill 67 197 486 67 197 487 minecraft:magma_block
setblock 67 197 488 minecraft:basalt
setblock 67 197 490 minecraft:magma_block
fill 68 197 471 68 197 472 minecraft:basalt
setblock 68 197 475 minecraft:basalt
fill 68 197 476 69 197 476 minecraft:magma_block
fill 68 197 486 69 197 486 minecraft:magma_block
setblock 68 197 487 minecraft:basalt
setblock 68 197 490 minecraft:basalt
setblock 69 197 471 minecraft:basalt
fill 69 197 475 70 197 475 minecraft:magma_block
fill 69 197 487 70 197 487 minecraft:magma_block
setblock 70 197 471 minecraft:magma_block
setblock 70 197 474 minecraft:magma_block
setblock 70 197 489 minecraft:magma_block
setblock 71 197 474 minecraft:basalt
fill 71 197 476 73 197 476 minecraft:magma_block
fill 71 197 486 73 197 486 minecraft:magma_block
fill 71 197 489 72 197 489 minecraft:basalt
setblock 73 197 472 minecraft:basalt
setblock 73 197 473 minecraft:magma_block
setblock 73 197 487 minecraft:basalt
setblock 73 197 488 minecraft:magma_block
setblock 74 197 477 minecraft:magma_block
setblock 74 197 485 minecraft:magma_block
setblock 74 197 486 minecraft:basalt
fill 75 197 478 75 197 480 minecraft:magma_block
fill 75 197 482 75 197 484 minecraft:magma_block
setblock 76 197 475 minecraft:magma_block
setblock 76 197 478 minecraft:magma_block
setblock 76 197 479 minecraft:basalt
fill 76 197 480 76 197 482 minecraft:magma_block
setblock 76 197 483 minecraft:basalt
setblock 76 197 484 minecraft:magma_block
setblock 76 197 485 minecraft:basalt
setblock 76 197 487 minecraft:magma_block
setblock 77 197 488 minecraft:basalt
setblock 78 197 486 minecraft:basalt
setblock 79 197 476 minecraft:basalt
setblock 79 197 477 minecraft:magma_block
setblock 79 197 479 minecraft:basalt
setblock 79 197 480 minecraft:magma_block
fill 79 197 481 79 197 482 minecraft:basalt
setblock 79 197 483 minecraft:magma_block
setblock 79 197 484 minecraft:basalt
setblock 79 197 486 minecraft:magma_block
setblock 88 197 503 minecraft:quartz_block
fill 48 198 482 51 198 485 minecraft:quartz_block
fill 48 198 488 49 198 489 minecraft:quartz_block
fill 49 198 486 51 198 486 minecraft:quartz_block
fill 50 198 488 52 198 488 minecraft:quartz_block
fill 52 198 483 52 198 485 minecraft:quartz_block
fill 53 198 489 53 198 495 minecraft:black_concrete
fill 48 199 477 49 200 477 minecraft:quartz_block
fill 48 199 480 52 199 484 minecraft:quartz_block
fill 49 199 478 52 200 479 minecraft:quartz_block
setblock 50 199 466 minecraft:light[level=14]
setblock 50 199 474 minecraft:light[level=14]
setblock 50 199 490 minecraft:light[level=14]
setblock 50 199 498 minecraft:light[level=14]
fill 53 199 485 53 199 490 minecraft:black_concrete
setblock 58 199 466 minecraft:light[level=14]
setblock 58 199 474 minecraft:light[level=14]
setblock 58 199 482 minecraft:light[level=14]
setblock 58 199 490 minecraft:light[level=14]
setblock 58 199 498 minecraft:light[level=14]
setblock 66 199 466 minecraft:light[level=14]
setblock 66 199 474 minecraft:light[level=14]
setblock 66 199 482 minecraft:light[level=14]
setblock 66 199 490 minecraft:light[level=14]
setblock 66 199 498 minecraft:light[level=14]
setblock 74 199 466 minecraft:light[level=14]
setblock 74 199 474 minecraft:light[level=14]
setblock 74 199 482 minecraft:light[level=14]
setblock 74 199 490 minecraft:light[level=14]
setblock 74 199 498 minecraft:light[level=14]
setblock 82 199 466 minecraft:light[level=14]
setblock 82 199 474 minecraft:light[level=14]
setblock 82 199 482 minecraft:light[level=14]
setblock 82 199 490 minecraft:light[level=14]
setblock 82 199 498 minecraft:light[level=14]
fill 47 200 468 47 205 468 minecraft:sea_lantern
fill 47 200 476 47 205 476 minecraft:sea_lantern
fill 47 200 484 47 205 484 minecraft:sea_lantern
fill 47 200 492 47 205 492 minecraft:sea_lantern
fill 47 200 500 47 205 500 minecraft:sea_lantern
fill 48 200 472 50 200 476 minecraft:quartz_block
fill 49 200 471 49 201 471 minecraft:quartz_block
fill 50 200 477 52 200 477 minecraft:quartz_block
fill 50 200 480 52 200 480 minecraft:quartz_block
fill 50 200 505 50 205 505 minecraft:sea_lantern
fill 51 200 473 52 200 476 minecraft:quartz_block
fill 53 200 481 53 200 486 minecraft:black_concrete
fill 54 200 463 54 205 463 minecraft:sea_lantern
fill 58 200 505 58 205 505 minecraft:sea_lantern
fill 62 200 463 62 205 463 minecraft:sea_lantern
fill 66 200 505 66 205 505 minecraft:sea_lantern
fill 70 200 463 70 205 463 minecraft:sea_lantern
fill 74 200 505 74 205 505 minecraft:sea_lantern
fill 78 200 463 78 205 463 minecraft:sea_lantern
fill 82 200 505 82 205 505 minecraft:sea_lantern
fill 86 200 463 86 205 463 minecraft:sea_lantern
fill 89 200 468 89 205 468 minecraft:sea_lantern
fill 89 200 476 89 205 476 minecraft:sea_lantern
fill 89 200 484 89 205 484 minecraft:sea_lantern
fill 89 200 492 89 205 492 minecraft:sea_lantern
fill 89 200 500 89 205 500 minecraft:sea_lantern
fill 48 201 464 48 201 469 minecraft:quartz_block
fill 48 201 472 52 201 474 minecraft:quartz_block
fill 49 201 465 50 201 470 minecraft:quartz_block
fill 50 201 471 52 201 471 minecraft:quartz_block
fill 50 201 475 52 201 475 minecraft:quartz_block
fill 51 201 465 51 202 466 minecraft:quartz_block
fill 51 201 470 52 201 470 minecraft:quartz_block
fill 52 201 466 52 202 466 minecraft:quartz_block
setblock 52 201 476 minecraft:quartz_block
setblock 53 201 466 minecraft:gray_concrete
setblock 53 201 470 minecraft:gray_concrete
fill 53 201 477 53 201 482 minecraft:black_concrete
fill 54 201 467 54 201 469 minecraft:gray_concrete
fill 48 202 464 48 202 467 minecraft:quartz_block
fill 49 202 465 50 202 467 minecraft:quartz_block
setblock 50 202 468 minecraft:quartz_block
fill 51 202 464 56 202 464 minecraft:quartz_block
fill 52 202 465 58 202 465 minecraft:quartz_block
setblock 52 202 470 minecraft:quartz_block
fill 53 202 466 58 202 466 minecraft:quartz_block
fill 53 202 472 53 202 479 minecraft:black_concrete
fill 54 202 467 59 202 468 minecraft:quartz_block
fill 53 203 469 53 203 474 minecraft:black_concrete
fill 54 203 464 56 203 464 minecraft:quartz_block
fill 54 203 469 57 204 469 minecraft:black_concrete
fill 55 203 465 63 203 466 minecraft:quartz_block
fill 56 203 467 63 203 467 minecraft:quartz_block
fill 57 203 468 64 203 468 minecraft:quartz_block
fill 59 203 464 63 203 464 minecraft:quartz_block
fill 53 204 469 53 228 469 minecraft:quartz_block
fill 58 204 465 58 205 466 minecraft:iron_block
fill 58 204 469 61 204 469 minecraft:black_concrete
fill 60 204 464 64 204 464 minecraft:quartz_block
fill 61 204 465 68 204 466 minecraft:quartz_block
fill 62 204 467 68 204 468 minecraft:quartz_block
fill 67 204 464 68 205 464 minecraft:quartz_block
fill 60 205 469 65 205 469 minecraft:black_concrete
fill 66 205 465 71 205 468 minecraft:quartz_block
fill 69 205 464 72 205 464 minecraft:quartz_block
fill 72 205 465 72 206 467 minecraft:quartz_block
fill 47 206 468 47 213 468 minecraft:light_gray_concrete
fill 47 206 476 47 213 476 minecraft:light_gray_concrete
fill 47 206 484 47 213 484 minecraft:light_gray_concrete
fill 47 206 492 47 213 492 minecraft:light_gray_concrete
fill 47 206 500 47 213 500 minecraft:light_gray_concrete
fill 50 206 505 50 213 505 minecraft:light_gray_concrete
fill 54 206 463 54 213 463 minecraft:light_gray_concrete
fill 58 206 505 58 213 505 minecraft:light_gray_concrete
fill 62 206 463 62 213 463 minecraft:light_gray_concrete
fill 64 206 469 69 206 469 minecraft:black_concrete
fill 66 206 505 66 213 505 minecraft:light_gray_concrete
fill 70 206 463 70 213 463 minecraft:light_gray_concrete
fill 70 206 464 71 206 468 minecraft:quartz_block
setblock 72 206 464 minecraft:quartz_block
fill 72 206 468 76 206 468 minecraft:quartz_block
fill 73 206 465 76 206 467 minecraft:quartz_block
fill 74 206 505 74 213 505 minecraft:light_gray_concrete
fill 75 206 464 78 206 464 minecraft:quartz_block
fill 77 206 465 77 207 466 minecraft:quartz_block
fill 78 206 463 78 213 463 minecraft:light_gray_concrete
fill 82 206 505 82 213 505 minecraft:light_gray_concrete
fill 86 206 463 86 213 463 minecraft:light_gray_concrete
fill 89 206 468 89 213 468 minecraft:light_gray_concrete
fill 89 206 476 89 213 476 minecraft:light_gray_concrete
fill 89 206 484 89 213 484 minecraft:light_gray_concrete
fill 89 206 492 89 213 492 minecraft:light_gray_concrete
fill 89 206 500 89 213 500 minecraft:light_gray_concrete
setblock 50 207 466 minecraft:light[level=14]
setblock 50 207 474 minecraft:light[level=14]
setblock 50 207 482 minecraft:light[level=14]
setblock 50 207 490 minecraft:light[level=14]
setblock 50 207 498 minecraft:light[level=14]
setblock 58 207 466 minecraft:light[level=14]
setblock 58 207 474 minecraft:light[level=14]
setblock 58 207 482 minecraft:light[level=14]
setblock 58 207 490 minecraft:light[level=14]
setblock 58 207 498 minecraft:light[level=14]
setblock 66 207 466 minecraft:light[level=14]
setblock 66 207 474 minecraft:light[level=14]
setblock 66 207 482 minecraft:light[level=14]
setblock 66 207 490 minecraft:light[level=14]
setblock 66 207 498 minecraft:light[level=14]
fill 68 207 469 73 207 469 minecraft:black_concrete
setblock 74 207 466 minecraft:light[level=14]
fill 74 207 467 82 207 468 minecraft:quartz_block
setblock 74 207 474 minecraft:light[level=14]
setblock 74 207 482 minecraft:light[level=14]
setblock 74 207 490 minecraft:light[level=14]
setblock 74 207 498 minecraft:light[level=14]
fill 75 207 465 76 207 466 minecraft:quartz_block
fill 76 207 464 80 207 464 minecraft:quartz_block
fill 78 207 465 83 207 466 minecraft:quartz_block
setblock 82 207 474 minecraft:light[level=14]
setblock 82 207 482 minecraft:light[level=14]
setblock 82 207 490 minecraft:light[level=14]
setblock 82 207 498 minecraft:light[level=14]
fill 83 207 464 85 208 464 minecraft:quartz_block
fill 83 207 467 83 208 467 minecraft:quartz_block
fill 84 207 465 84 208 465 minecraft:quartz_block
fill 71 208 469 77 208 469 minecraft:black_concrete
fill 79 208 468 88 208 468 minecraft:quartz_block
fill 80 208 466 82 208 467 minecraft:quartz_block
fill 81 208 465 83 208 465 minecraft:quartz_block
fill 83 208 466 87 208 466 minecraft:quartz_block
fill 84 208 467 88 208 467 minecraft:quartz_block
fill 84 208 469 85 208 472 minecraft:quartz_block
fill 85 208 465 87 208 465 minecraft:quartz_block
fill 86 208 464 88 208 464 minecraft:quartz_block
fill 86 208 469 86 209 471 minecraft:quartz_block
fill 87 208 469 88 210 470 minecraft:quartz_block
fill 50 209 467 50 209 469 minecraft:gray_concrete
fill 51 209 466 53 209 466 minecraft:gray_concrete
fill 51 209 470 53 209 470 minecraft:gray_concrete
fill 54 209 467 54 209 469 minecraft:gray_concrete
fill 75 209 469 83 209 469 minecraft:black_concrete
fill 83 209 470 83 210 470 minecraft:black_concrete
fill 84 209 470 85 209 477 minecraft:quartz_block
setblock 85 209 469 minecraft:quartz_block
fill 86 209 468 88 209 468 minecraft:quartz_block
fill 86 209 472 86 209 477 minecraft:quartz_block
fill 87 209 467 88 210 467 minecraft:quartz_block
fill 87 209 471 87 210 476 minecraft:quartz_block
fill 88 209 471 88 211 472 minecraft:quartz_block
fill 88 209 475 88 211 476 minecraft:quartz_block
fill 48 210 464 48 211 469 minecraft:quartz_block
fill 48 210 472 49 210 477 minecraft:quartz_block
fill 48 210 480 49 210 485 minecraft:quartz_block
fill 48 210 488 49 210 493 minecraft:quartz_block
fill 48 210 496 49 210 501 minecraft:quartz_block
fill 48 210 504 53 211 504 minecraft:quartz_block
fill 49 210 465 49 210 471 minecraft:quartz_block
fill 49 210 478 49 210 479 minecraft:quartz_block
fill 49 210 486 49 210 487 minecraft:quartz_block
fill 49 210 494 49 210 495 minecraft:quartz_block
fill 49 210 502 49 210 503 minecraft:quartz_block
fill 50 210 465 87 210 465 minecraft:quartz_block
fill 50 210 503 88 210 503 minecraft:quartz_block
fill 51 210 464 56 211 464 minecraft:quartz_block
fill 56 210 504 61 211 504 minecraft:quartz_block
fill 59 210 464 64 211 464 minecraft:quartz_block
fill 64 210 504 69 211 504 minecraft:quartz_block
fill 67 210 464 72 211 464 minecraft:quartz_block
fill 72 210 504 77 211 504 minecraft:quartz_block
fill 75 210 464 80 211 464 minecraft:quartz_block
fill 80 210 504 85 211 504 minecraft:quartz_block
fill 81 210 469 83 210 469 minecraft:black_concrete
fill 83 210 464 88 211 464 minecraft:quartz_block
fill 83 210 471 83 210 475 minecraft:black_concrete
fill 84 210 476 84 210 482 minecraft:quartz_block
fill 85 210 475 86 210 481 minecraft:quartz_block
setblock 86 210 474 minecraft:quartz_block
setblock 87 210 466 minecraft:quartz_block
fill 87 210 468 88 210 468 minecraft:quartz_block
fill 87 210 477 87 210 502 minecraft:quartz_block
fill 88 210 477 88 211 480 minecraft:quartz_block
fill 88 210 483 88 211 488 minecraft:quartz_block
fill 88 210 491 88 211 496 minecraft:quartz_block
fill 88 210 499 88 211 502 minecraft:quartz_block
fill 88 210 504 88 211 504 minecraft:quartz_block
fill 48 211 472 48 211 477 minecraft:quartz_block
fill 48 211 480 48 211 485 minecraft:quartz_block
fill 48 211 488 48 211 493 minecraft:quartz_block
fill 48 211 496 48 211 501 minecraft:quartz_block
fill 83 211 473 83 211 479 minecraft:black_concrete
fill 84 211 480 87 211 485 minecraft:quartz_block
fill 85 211 486 87 212 486 minecraft:quartz_block
setblock 87 211 479 minecraft:quartz_block
fill 88 211 467 88 211 470 minecraft:quartz_block
setblock 88 211 503 minecraft:quartz_block
fill 83 212 478 83 212 483 minecraft:black_concrete
fill 84 212 484 84 212 490 minecraft:quartz_block
fill 85 212 484 88 212 485 minecraft:quartz_block
fill 85 212 487 87 212 490 minecraft:quartz_block
fill 87 212 491 88 213 491 minecraft:quartz_block
fill 88 212 486 88 212 488 minecraft:quartz_block
fill 83 213 482 83 213 487 minecraft:black_concrete
fill 84 213 488 86 213 495 minecraft:quartz_block
fill 86 213 496 88 214 496 minecraft:quartz_block
fill 87 213 489 87 213 490 minecraft:quartz_block
fill 87 213 492 88 213 495 minecraft:quartz_block
fill 87 213 497 87 214 497 minecraft:quartz_block
fill 47 214 468 47 219 468 minecraft:sea_lantern
fill 47 214 476 47 219 476 minecraft:sea_lantern
fill 47 214 484 47 219 484 minecraft:sea_lantern
fill 47 214 492 47 219 492 minecraft:sea_lantern
fill 47 214 500 47 219 500 minecraft:sea_lantern
fill 50 214 505 50 219 505 minecraft:sea_lantern
fill 54 214 463 54 219 463 minecraft:sea_lantern
fill 58 214 505 58 219 505 minecraft:sea_lantern
fill 62 214 463 62 219 463 minecraft:sea_lantern
fill 66 214 505 66 219 505 minecraft:sea_lantern
fill 70 214 463 70 219 463 minecraft:sea_lantern
fill 74 214 505 74 219 505 minecraft:sea_lantern
fill 78 214 463 78 219 463 minecraft:sea_lantern
fill 82 214 505 82 219 505 minecraft:sea_lantern
fill 83 214 486 83 214 491 minecraft:black_concrete
fill 83 214 500 88 214 500 minecraft:quartz_block
fill 84 214 492 84 214 499 minecraft:quartz_block
fill 84 214 501 88 215 502 minecraft:quartz_block
fill 85 214 493 85 214 499 minecraft:quartz_block
fill 85 214 503 88 215 503 minecraft:quartz_block
fill 86 214 463 86 219 463 minecraft:sea_lantern
fill 86 214 493 86 214 495 minecraft:quartz_block
fill 86 214 497 86 214 499 minecraft:quartz_block
fill 87 214 494 88 214 495 minecraft:quartz_block
fill 87 214 498 87 214 499 minecraft:quartz_block
setblock 88 214 499 minecraft:quartz_block
fill 88 214 504 88 215 504 minecraft:quartz_block
fill 89 214 468 89 219 468 minecraft:sea_lantern
fill 89 214 476 89 219 476 minecraft:sea_lantern
fill 89 214 484 89 219 484 minecraft:sea_lantern
fill 89 214 492 89 219 492 minecraft:sea_lantern
fill 89 214 500 89 219 500 minecraft:sea_lantern
setblock 50 215 466 minecraft:light[level=14]
setblock 50 215 474 minecraft:light[level=14]
setblock 50 215 482 minecraft:light[level=14]
setblock 50 215 490 minecraft:light[level=14]
setblock 50 215 498 minecraft:light[level=14]
setblock 58 215 466 minecraft:light[level=14]
setblock 58 215 474 minecraft:light[level=14]
setblock 58 215 482 minecraft:light[level=14]
setblock 58 215 490 minecraft:light[level=14]
setblock 58 215 498 minecraft:light[level=14]
setblock 66 215 466 minecraft:light[level=14]
setblock 66 215 474 minecraft:light[level=14]
setblock 66 215 482 minecraft:light[level=14]
setblock 66 215 490 minecraft:light[level=14]
setblock 66 215 498 minecraft:light[level=14]
setblock 74 215 466 minecraft:light[level=14]
setblock 74 215 474 minecraft:light[level=14]
setblock 74 215 482 minecraft:light[level=14]
setblock 74 215 490 minecraft:light[level=14]
setblock 74 215 498 minecraft:light[level=14]
fill 77 215 500 83 215 501 minecraft:quartz_block
fill 78 215 502 83 215 503 minecraft:quartz_block
fill 80 215 504 85 215 504 minecraft:quartz_block
setblock 82 215 466 minecraft:light[level=14]
setblock 82 215 474 minecraft:light[level=14]
setblock 82 215 482 minecraft:light[level=14]
setblock 82 215 490 minecraft:light[level=14]
setblock 82 215 498 minecraft:light[level=14]
fill 83 215 489 83 215 496 minecraft:black_concrete
fill 84 215 498 84 215 500 minecraft:quartz_block
setblock 84 215 503 minecraft:quartz_block
fill 85 215 499 85 215 500 minecraft:quartz_block
setblock 86 215 500 minecraft:quartz_block
fill 72 216 500 79 216 500 minecraft:quartz_block
fill 73 216 501 77 216 504 minecraft:quartz_block
fill 78 216 501 80 216 503 minecraft:quartz_block
fill 79 216 499 83 216 499 minecraft:black_concrete
fill 80 216 504 82 216 504 minecraft:quartz_block
fill 81 216 502 81 216 503 minecraft:quartz_block
fill 83 216 494 83 216 498 minecraft:black_concrete
fill 48 217 480 48 218 482 minecraft:quartz_block
fill 50 217 467 50 217 469 minecraft:gray_concrete
fill 51 217 466 53 217 466 minecraft:gray_concrete
fill 51 217 470 53 217 470 minecraft:gray_concrete
fill 54 217 467 54 217 469 minecraft:gray_concrete
fill 68 217 500 69 218 504 minecraft:quartz_block
fill 70 217 500 74 217 503 minecraft:quartz_block
fill 72 217 504 76 217 504 minecraft:quartz_block
fill 75 217 499 82 217 499 minecraft:black_concrete
fill 75 217 502 75 217 503 minecraft:quartz_block
fill 87 217 480 87 218 482 minecraft:quartz_block
fill 88 217 480 88 218 480 minecraft:quartz_block
fill 49 218 480 49 219 482 minecraft:quartz_block
fill 50 218 481 50 220 481 minecraft:quartz_block
fill 64 218 501 67 218 504 minecraft:quartz_block
fill 65 218 500 67 218 500 minecraft:quartz_block
fill 70 218 500 70 218 503 minecraft:quartz_block
fill 71 218 499 76 218 499 minecraft:black_concrete
fill 85 218 481 86 220 481 minecraft:quartz_block
fill 86 218 480 86 219 480 minecraft:quartz_block
fill 86 218 482 86 219 482 minecraft:quartz_block
setblock 48 219 481 minecraft:quartz_block
fill 50 219 480 50 220 480 minecraft:quartz_block
fill 50 219 482 50 220 482 minecraft:quartz_block
fill 51 219 481 51 221 481 minecraft:quartz_block
fill 58 219 504 61 219 504 minecraft:quartz_block
fill 59 219 502 66 219 503 minecraft:quartz_block
fill 60 219 500 66 219 501 minecraft:quartz_block
fill 64 219 504 66 219 504 minecraft:quartz_block
fill 67 219 499 72 219 499 minecraft:black_concrete
fill 84 219 481 84 221 481 minecraft:quartz_block
fill 85 219 480 85 220 480 minecraft:quartz_block
fill 85 219 482 85 220 482 minecraft:quartz_block
setblock 87 219 481 minecraft:quartz_block
fill 47 220 468 47 227 468 minecraft:light_gray_concrete
fill 47 220 476 47 227 476 minecraft:light_gray_concrete
fill 47 220 484 47 227 484 minecraft:light_gray_concrete
fill 47 220 492 47 227 492 minecraft:light_gray_concrete
fill 47 220 500 47 227 500 minecraft:light_gray_concrete
setblock 48 220 481 minecraft:black_concrete
setblock 49 220 481 minecraft:quartz_block
fill 50 220 505 50 227 505 minecraft:light_gray_concrete
fill 51 220 480 52 221 480 minecraft:quartz_block
fill 51 220 482 52 221 482 minecraft:quartz_block
fill 51 220 504 53 221 504 minecraft:quartz_block
fill 52 220 481 52 222 481 minecraft:quartz_block
fill 52 220 503 61 220 503 minecraft:quartz_block
fill 53 220 501 61 220 502 minecraft:quartz_block
fill 54 220 463 54 227 463 minecraft:light_gray_concrete
fill 54 220 500 62 220 500 minecraft:quartz_block
fill 56 220 504 60 220 504 minecraft:quartz_block
fill 58 220 505 58 227 505 minecraft:light_gray_concrete
fill 62 220 463 62 227 463 minecraft:light_gray_concrete
setblock 62 220 501 minecraft:quartz_block
fill 63 220 499 68 220 499 minecraft:black_concrete
fill 66 220 505 66 227 505 minecraft:light_gray_concrete
fill 70 220 463 70 227 463 minecraft:light_gray_concrete
fill 74 220 505 74 227 505 minecraft:light_gray_concrete
fill 78 220 463 78 227 463 minecraft:light_gray_concrete
fill 82 220 505 82 227 505 minecraft:light_gray_concrete
fill 83 220 480 83 221 482 minecraft:quartz_block
fill 84 220 480 84 221 480 minecraft:quartz_block
fill 84 220 482 84 221 482 minecraft:quartz_block
fill 86 220 463 86 227 463 minecraft:light_gray_concrete
setblock 87 220 481 minecraft:black_concrete
fill 89 220 468 89 227 468 minecraft:light_gray_concrete
fill 89 220 476 89 227 476 minecraft:light_gray_concrete
fill 89 220 484 89 227 484 minecraft:light_gray_concrete
fill 89 220 492 89 227 492 minecraft:light_gray_concrete
fill 89 220 500 89 227 500 minecraft:light_gray_concrete
fill 48 221 498 52 221 501 minecraft:quartz_block
fill 48 221 504 50 221 504 minecraft:quartz_block
fill 49 221 502 55 221 503 minecraft:quartz_block
setblock 50 221 481 minecraft:black_concrete
fill 50 221 497 52 222 497 minecraft:quartz_block
fill 51 221 496 52 222 496 minecraft:quartz_block
fill 53 221 480 53 222 482 minecraft:quartz_block
fill 53 221 500 56 221 501 minecraft:quartz_block
fill 54 221 481 54 223 481 minecraft:quartz_block
setblock 56 221 502 minecraft:quartz_block
setblock 57 221 500 minecraft:quartz_block
fill 59 221 499 65 221 499 minecraft:black_concrete
fill 81 221 481 82 223 481 minecraft:quartz_block
fill 82 221 480 82 222 480 minecraft:quartz_block
fill 82 221 482 82 222 482 minecraft:quartz_block
setblock 85 221 481 minecraft:black_concrete
fill 48 222 492 52 222 493 minecraft:quartz_block
fill 48 222 496 49 222 501 minecraft:quartz_block
fill 49 222 494 52 222 495 minecraft:quartz_block
fill 50 222 491 52 223 491 minecraft:quartz_block
setblock 50 222 496 minecraft:quartz_block
fill 50 222 498 50 222 500 minecraft:quartz_block
setblock 51 222 481 minecraft:black_concrete
fill 51 222 498 51 222 499 minecraft:quartz_block
setblock 52 222 498 minecraft:quartz_block
fill 53 222 498 53 223 499 minecraft:black_concrete
fill 54 222 480 54 223 480 minecraft:quartz_block
fill 54 222 482 54 223 482 minecraft:quartz_block
fill 54 222 499 61 222 499 minecraft:black_concrete
fill 55 222 481 55 224 481 minecraft:quartz_block
fill 80 222 481 80 224 481 minecraft:quartz_block
fill 81 222 480 81 223 480 minecraft:quartz_block
fill 81 222 482 81 223 482 minecraft:quartz_block
setblock 83 222 481 minecraft:quartz_block
setblock 84 222 481 minecraft:black_concrete
fill 48 223 488 49 224 493 minecraft:quartz_block
fill 49 223 487 52 224 487 minecraft:quartz_block
fill 49 223 494 50 223 494 minecraft:quartz_block
setblock 50 223 466 minecraft:light[level=14]
setblock 50 223 474 minecraft:light[level=14]
setblock 50 223 482 minecraft:light[level=14]
fill 50 223 488 52 223 490 minecraft:quartz_block
fill 50 223 492 51 223 493 minecraft:quartz_block
setblock 50 223 498 minecraft:light[level=14]
setblock 52 223 481 minecraft:black_concrete
fill 52 223 486 52 224 486 minecraft:quartz_block
setblock 52 223 492 minecraft:quartz_block
setblock 53 223 481 minecraft:quartz_block
fill 53 223 493 53 223 497 minecraft:black_concrete
fill 54 223 499 55 223 499 minecraft:black_concrete
fill 55 223 480 56 223 480 minecraft:quartz_block
fill 55 223 482 56 223 482 minecraft:quartz_block
fill 56 223 481 57 224 481 minecraft:quartz_block
setblock 58 223 466 minecraft:light[level=14]
setblock 58 223 474 minecraft:light[level=14]
setblock 58 223 482 minecraft:light[level=14]
setblock 58 223 490 minecraft:light[level=14]
setblock 58 223 498 minecraft:light[level=14]
setblock 66 223 466 minecraft:light[level=14]
setblock 66 223 474 minecraft:light[level=14]
setblock 66 223 482 minecraft:light[level=14]
setblock 66 223 490 minecraft:light[level=14]
setblock 66 223 498 minecraft:light[level=14]
setblock 74 223 466 minecraft:light[level=14]
setblock 74 223 474 minecraft:light[level=14]
setblock 74 223 482 minecraft:light[level=14]
setblock 74 223 490 minecraft:light[level=14]
setblock 74 223 498 minecraft:light[level=14]
fill 78 223 481 79 224 481 minecraft:quartz_block
fill 79 223 480 80 223 480 minecraft:quartz_block
fill 79 223 482 80 223 482 minecraft:quartz_block
setblock 82 223 466 minecraft:light[level=14]
setblock 82 223 474 minecraft:light[level=14]
setblock 82 223 482 minecraft:light[level=14]
setblock 82 223 490 minecraft:light[level=14]
setblock 82 223 498 minecraft:light[level=14]
setblock 83 223 481 minecraft:black_concrete
fill 48 224 464 48 225 469 minecraft:quartz_block
fill 48 224 472 49 224 477 minecraft:quartz_block
fill 48 224 480 49 224 485 minecraft:quartz_block
fill 48 224 496 49 224 501 minecraft:quartz_block
fill 48 224 504 53 225 504 minecraft:quartz_block
fill 49 224 465 49 224 471 minecraft:quartz_block
fill 49 224 478 49 226 479 minecraft:quartz_block
fill 49 224 486 51 224 486 minecraft:quartz_block
fill 49 224 494 49 224 495 minecraft:quartz_block
fill 49 224 502 49 224 503 minecraft:quartz_block
fill 50 224 465 87 224 465 minecraft:quartz_block
fill 50 224 482 51 224 485 minecraft:quartz_block
fill 50 224 488 52 224 488 minecraft:quartz_block
fill 50 224 503 88 224 503 minecraft:quartz_block
fill 51 224 464 56 225 464 minecraft:quartz_block
fill 52 224 483 52 224 485 minecraft:quartz_block
fill 53 224 489 53 224 495 minecraft:black_concrete
setblock 54 224 481 minecraft:black_concrete
fill 56 224 480 58 224 480 minecraft:quartz_block
fill 56 224 482 58 224 482 minecraft:quartz_block
fill 56 224 504 61 225 504 minecraft:quartz_block
fill 58 224 481 59 226 481 minecraft:quartz_block
fill 59 224 464 64 225 464 minecraft:quartz_block
fill 64 224 504 69 225 504 minecraft:quartz_block
fill 67 224 464 72 225 464 minecraft:quartz_block
fill 72 224 504 77 225 504 minecraft:quartz_block
fill 75 224 464 80 225 464 minecraft:quartz_block
fill 76 224 481 77 226 481 minecraft:quartz_block
fill 77 224 480 79 224 480 minecraft:quartz_block
fill 77 224 482 79 224 482 minecraft:quartz_block
fill 80 224 504 85 225 504 minecraft:quartz_block
setblock 81 224 481 minecraft:black_concrete
fill 83 224 464 88 225 464 minecraft:quartz_block
fill 87 224 466 87 224 502 minecraft:quartz_block
fill 88 224 467 88 225 472 minecraft:quartz_block
fill 88 224 475 88 225 480 minecraft:quartz_block
fill 88 224 483 88 225 488 minecraft:quartz_block
fill 88 224 491 88 225 496 minecraft:quartz_block
fill 88 224 499 88 225 502 minecraft:quartz_block
fill 88 224 504 88 225 504 minecraft:quartz_block
fill 48 225 472 48 226 477 minecraft:quartz_block
fill 48 225 480 48 225 485 minecraft:quartz_block
fill 48 225 488 48 225 493 minecraft:quartz_block
fill 48 225 496 48 225 501 minecraft:quartz_block
fill 49 225 477 49 226 477 minecraft:quartz_block
fill 49 225 480 52 225 484 minecraft:quartz_block
fill 50 225 467 50 225 469 minecraft:gray_concrete
fill 50 225 478 52 226 479 minecraft:quartz_block
fill 51 225 466 53 225 466 minecraft:gray_concrete
fill 51 225 470 53 225 470 minecraft:gray_concrete
fill 53 225 485 53 225 490 minecraft:black_concrete
fill 54 225 467 54 225 469 minecraft:gray_concrete
fill 55 225 481 56 225 481 minecraft:black_concrete
setblock 57 225 481 minecraft:quartz_block
fill 58 225 480 60 225 480 minecraft:quartz_block
fill 58 225 482 60 225 482 minecraft:quartz_block
fill 60 225 481 61 227 481 minecraft:quartz_block
fill 74 225 481 75 227 481 minecraft:quartz_block
fill 75 225 480 77 225 480 minecraft:quartz_block
fill 75 225 482 77 225 482 minecraft:quartz_block
setblock 78 225 481 minecraft:quartz_block
fill 79 225 481 80 225 481 minecraft:black_concrete
setblock 88 225 503 minecraft:quartz_block
fill 49 226 471 49 226 476 minecraft:quartz_block
fill 50 226 472 50 226 477 minecraft:quartz_block
fill 50 226 480 52 226 480 minecraft:quartz_block
fill 51 226 473 52 226 477 minecraft:quartz_block
fill 53 226 481 53 226 486 minecraft:black_concrete
setblock 57 226 481 minecraft:black_concrete
fill 59 226 480 63 226 480 minecraft:quartz_block
fill 59 226 482 63 226 482 minecraft:quartz_block
fill 62 226 481 65 227 481 minecraft:quartz_block
fill 71 226 481 73 227 481 minecraft:quartz_block
fill 72 226 480 76 226 480 minecraft:quartz_block
fill 72 226 482 76 226 482 minecraft:quartz_block
setblock 78 226 481 minecraft:black_concrete
fill 48 227 464 48 227 469 minecraft:quartz_block
fill 48 227 472 52 227 474 minecraft:quartz_block
fill 49 227 465 50 227 471 minecraft:quartz_block
fill 50 227 475 52 227 475 minecraft:quartz_block
fill 51 227 465 51 228 466 minecraft:quartz_block
fill 51 227 470 52 227 471 minecraft:quartz_block
fill 52 227 466 52 228 466 minecraft:quartz_block
setblock 52 227 476 minecraft:quartz_block
fill 53 227 477 53 227 482 minecraft:black_concrete
setblock 59 227 481 minecraft:black_concrete
fill 62 227 480 65 227 480 minecraft:quartz_block
fill 62 227 482 66 227 482 minecraft:quartz_block
fill 70 227 482 73 227 482 minecraft:quartz_block
fill 71 227 480 73 227 480 minecraft:quartz_block
setblock 76 227 481 minecraft:black_concrete
fill 47 228 468 47 230 468 minecraft:sea_lantern
fill 47 228 476 47 230 476 minecraft:sea_lantern
fill 47 228 484 47 230 484 minecraft:sea_lantern
fill 47 228 492 47 230 492 minecraft:sea_lantern
fill 47 228 500 47 230 500 minecraft:sea_lantern
fill 48 228 464 48 228 467 minecraft:quartz_block
fill 49 228 465 50 228 467 minecraft:quartz_block
setblock 50 228 468 minecraft:quartz_block
fill 50 228 505 50 230 505 minecraft:sea_lantern
fill 51 228 464 56 228 464 minecraft:quartz_block
fill 52 228 465 58 228 465 minecraft:quartz_block
setblock 52 228 470 minecraft:quartz_block
fill 53 228 466 58 228 466 minecraft:quartz_block
fill 53 228 472 53 228 479 minecraft:black_concrete
fill 54 228 463 54 230 463 minecraft:sea_lantern
fill 54 228 467 59 228 468 minecraft:quartz_block
fill 58 228 505 58 230 505 minecraft:sea_lantern
fill 61 228 481 63 228 481 minecraft:black_concrete
fill 62 228 463 62 230 463 minecraft:sea_lantern
fill 64 228 481 65 228 481 minecraft:quartz_block
fill 66 228 505 66 230 505 minecraft:sea_lantern
fill 70 228 463 70 230 463 minecraft:sea_lantern
setblock 71 228 481 minecraft:quartz_block
fill 72 228 481 74 228 481 minecraft:black_concrete
fill 74 228 505 74 230 505 minecraft:sea_lantern
fill 78 228 463 78 230 463 minecraft:sea_lantern
fill 82 228 505 82 230 505 minecraft:sea_lantern
fill 86 228 463 86 230 463 minecraft:sea_lantern
fill 89 228 468 89 230 468 minecraft:sea_lantern
fill 89 228 476 89 230 476 minecraft:sea_lantern
fill 89 228 484 89 230 484 minecraft:sea_lantern
fill 89 228 492 89 230 492 minecraft:sea_lantern
fill 89 228 500 89 230 500 minecraft:sea_lantern
fill 50 229 467 50 230 468 minecraft:black_concrete
fill 51 229 466 53 230 466 minecraft:black_concrete
fill 51 229 470 53 230 470 minecraft:black_concrete
fill 53 229 469 57 229 469 minecraft:black_concrete
fill 53 229 471 53 229 474 minecraft:black_concrete
fill 54 229 464 56 229 464 minecraft:quartz_block
fill 54 229 467 54 230 468 minecraft:black_concrete
fill 55 229 465 63 229 466 minecraft:quartz_block
fill 56 229 467 63 229 467 minecraft:quartz_block
fill 57 229 468 64 229 468 minecraft:quartz_block
fill 59 229 464 63 229 464 minecraft:quartz_block
fill 64 229 481 65 229 481 minecraft:black_concrete
setblock 71 229 481 minecraft:black_concrete
setblock 53 230 469 minecraft:quartz_block
fill 54 230 469 61 230 469 minecraft:black_concrete
fill 60 230 464 64 230 464 minecraft:quartz_block
fill 61 230 465 68 230 466 minecraft:quartz_block
fill 62 230 467 68 230 468 minecraft:quartz_block
fill 67 230 464 68 230 464 minecraft:quartz_block
fill 47 231 468 47 238 468 minecraft:light_gray_concrete
fill 47 231 476 47 238 476 minecraft:light_gray_concrete
fill 47 231 484 47 238 484 minecraft:light_gray_concrete
fill 47 231 492 47 235 492 minecraft:light_gray_concrete
fill 47 231 500 47 238 500 minecraft:light_gray_concrete
setblock 50 231 466 minecraft:light[level=14]
setblock 50 231 474 minecraft:light[level=14]
setblock 50 231 482 minecraft:light[level=14]
setblock 50 231 490 minecraft:light[level=14]
setblock 50 231 498 minecraft:light[level=14]
fill 50 231 505 50 238 505 minecraft:light_gray_concrete
fill 54 231 463 54 238 463 minecraft:light_gray_concrete
setblock 58 231 466 minecraft:light[level=14]
setblock 58 231 474 minecraft:light[level=14]
setblock 58 231 482 minecraft:light[level=14]
setblock 58 231 490 minecraft:light[level=14]
setblock 58 231 498 minecraft:light[level=14]
fill 58 231 505 58 238 505 minecraft:light_gray_concrete
fill 62 231 463 62 234 463 minecraft:light_gray_concrete
setblock 66 231 466 minecraft:light[level=14]
setblock 66 231 474 minecraft:light[level=14]
setblock 66 231 482 minecraft:light[level=14]
setblock 66 231 490 minecraft:light[level=14]
setblock 66 231 498 minecraft:light[level=14]
fill 66 231 505 66 238 505 minecraft:light_gray_concrete
fill 70 231 463 70 238 463 minecraft:light_gray_concrete
setblock 74 231 466 minecraft:light[level=14]
setblock 74 231 474 minecraft:light[level=14]
setblock 74 231 482 minecraft:light[level=14]
setblock 74 231 490 minecraft:light[level=14]
setblock 74 231 498 minecraft:light[level=14]
fill 74 231 505 74 234 505 minecraft:light_gray_concrete
fill 78 231 463 78 234 463 minecraft:light_gray_concrete
setblock 82 231 466 minecraft:light[level=14]
setblock 82 231 474 minecraft:light[level=14]
setblock 82 231 482 minecraft:light[level=14]
setblock 82 231 490 minecraft:light[level=14]
setblock 82 231 498 minecraft:light[level=14]
fill 82 231 505 82 235 505 minecraft:light_gray_concrete
fill 86 231 463 86 238 463 minecraft:light_gray_concrete
fill 89 231 468 89 238 468 minecraft:light_gray_concrete
fill 89 231 476 89 238 476 minecraft:light_gray_concrete
fill 89 231 484 89 236 484 minecraft:light_gray_concrete
fill 89 231 492 89 238 492 minecraft:light_gray_concrete
fill 89 231 500 89 238 500 minecraft:light_gray_concrete
fill 47 235 469 47 236 469 minecraft:light_gray_concrete
setblock 47 235 470 minecraft:white_concrete
fill 47 235 472 47 235 473 minecraft:white_concrete
fill 47 235 474 47 238 475 minecraft:light_gray_concrete
fill 47 235 485 47 238 487 minecraft:light_gray_concrete
setblock 47 235 488 minecraft:white_concrete
fill 47 235 489 47 238 491 minecraft:light_gray_concrete
fill 55 235 463 57 235 463 minecraft:white_concrete
fill 58 235 463 61 238 463 minecraft:light_gray_concrete
setblock 62 235 463 minecraft:white_concrete
fill 70 235 505 72 238 505 minecraft:light_gray_concrete
fill 73 235 505 74 235 505 minecraft:white_concrete
setblock 75 235 463 minecraft:white_concrete
fill 78 235 463 78 236 463 minecraft:white_concrete
setblock 78 235 505 minecraft:white_concrete
fill 79 235 505 79 238 505 minecraft:light_gray_concrete
setblock 83 235 505 minecraft:white_concrete
fill 89 235 472 89 238 473 minecraft:light_gray_concrete
setblock 89 235 474 minecraft:white_concrete
setblock 89 235 477 minecraft:light_gray_concrete
setblock 89 235 478 minecraft:white_concrete
fill 89 235 479 89 235 483 minecraft:light_gray_concrete
fill 89 235 485 89 235 486 minecraft:light_gray_concrete
setblock 89 235 487 minecraft:white_concrete
fill 89 235 488 89 238 489 minecraft:light_gray_concrete
fill 47 236 470 47 238 470 minecraft:light_gray_concrete
fill 47 236 472 47 238 473 minecraft:light_gray_concrete
setblock 47 236 477 minecraft:white_concrete
fill 47 236 478 47 236 483 minecraft:light_gray_concrete
fill 47 236 488 47 238 488 minecraft:light_gray_concrete
setblock 47 236 492 minecraft:white_concrete
fill 47 236 493 47 238 494 minecraft:light_gray_concrete
fill 47 236 495 47 236 496 minecraft:white_concrete
fill 47 236 497 47 238 497 minecraft:light_gray_concrete
setblock 47 236 498 minecraft:white_concrete
fill 47 236 499 47 238 499 minecraft:light_gray_concrete
fill 51 236 463 51 239 463 minecraft:light_gray_concrete
fill 51 236 505 52 238 505 minecraft:light_gray_concrete
setblock 52 236 463 minecraft:white_concrete
fill 52 236 479 57 237 479 minecraft:light_gray_concrete
fill 53 236 463 53 238 463 minecraft:light_gray_concrete
fill 53 236 474 57 237 478 minecraft:light_gray_concrete
fill 53 236 480 57 237 484 minecraft:light_gray_concrete
fill 53 236 505 54 236 505 minecraft:white_concrete
fill 54 236 472 60 237 473 minecraft:light_gray_concrete
fill 54 236 485 57 237 486 minecraft:light_gray_concrete
fill 55 236 463 57 238 463 minecraft:light_gray_concrete
fill 55 236 470 64 237 471 minecraft:light_gray_concrete
fill 55 236 487 58 237 488 minecraft:light_gray_concrete
fill 56 236 469 77 237 469 minecraft:light_gray_concrete
fill 56 236 489 60 237 489 minecraft:light_gray_concrete
fill 57 236 468 76 237 468 minecraft:light_gray_concrete
fill 57 236 490 61 237 490 minecraft:light_gray_concrete
fill 58 236 467 75 237 467 minecraft:light_gray_concrete
fill 58 236 474 58 237 476 minecraft:light_gray_concrete
fill 58 236 477 61 237 485 minecraft:quartz_block
fill 58 236 486 58 237 486 minecraft:light_gray_concrete
fill 58 236 491 63 237 491 minecraft:light_gray_concrete
fill 59 236 466 73 237 466 minecraft:light_gray_concrete
fill 59 236 474 59 237 474 minecraft:light_gray_concrete
fill 59 236 475 63 236 476 minecraft:quartz_block
fill 59 236 486 63 237 487 minecraft:quartz_block
fill 59 236 488 59 237 488 minecraft:light_gray_concrete
fill 59 236 492 65 237 492 minecraft:light_gray_concrete
fill 60 236 474 72 236 474 minecraft:quartz_block
fill 60 236 488 67 237 488 minecraft:quartz_block
fill 61 236 465 71 237 465 minecraft:light_gray_concrete
fill 61 236 472 62 237 472 minecraft:light_gray_concrete
fill 61 236 473 71 236 473 minecraft:quartz_block
fill 61 236 489 79 237 489 minecraft:quartz_block
fill 61 236 493 75 237 493 minecraft:light_gray_concrete
fill 62 236 463 67 236 463 minecraft:light_gray_concrete
fill 62 236 477 62 236 478 minecraft:quartz_block
fill 62 236 479 65 236 483 minecraft:light_gray_concrete
fill 62 236 484 62 237 485 minecraft:quartz_block
fill 62 236 490 78 237 490 minecraft:quartz_block
fill 63 236 464 65 237 464 minecraft:quartz_block
fill 63 236 472 70 237 472 minecraft:quartz_block
fill 63 236 477 66 236 478 minecraft:light_gray_concrete
fill 63 236 484 77 236 485 minecraft:light_gray_concrete
fill 63 236 494 73 237 494 minecraft:light_gray_concrete
fill 64 236 475 72 236 475 minecraft:quartz_block
fill 64 236 476 68 236 476 minecraft:light_gray_concrete
fill 64 236 486 76 237 486 minecraft:light_gray_concrete
fill 64 236 487 64 237 487 minecraft:quartz_block
fill 64 236 491 76 237 491 minecraft:quartz_block
fill 65 236 470 77 237 470 minecraft:light_gray_concrete
fill 65 236 471 67 237 471 minecraft:quartz_block
fill 65 236 487 74 237 487 minecraft:light_gray_concrete
fill 66 236 464 67 237 464 minecraft:light_gray_concrete
fill 66 236 480 66 236 483 minecraft:light_gray_concrete
fill 66 236 492 74 237 492 minecraft:quartz_block
setblock 67 236 477 minecraft:light_gray_concrete
fill 67 236 481 67 236 483 minecraft:light_gray_concrete
fill 68 236 463 68 237 464 minecraft:quartz_block
fill 68 236 471 78 237 471 minecraft:light_gray_concrete
fill 68 236 482 78 236 483 minecraft:light_gray_concrete
fill 68 236 488 72 237 488 minecraft:light_gray_concrete
fill 68 236 495 68 237 495 minecraft:light_gray_concrete
fill 69 236 463 69 238 463 minecraft:light_gray_concrete
fill 69 236 464 73 237 464 minecraft:quartz_block
fill 69 236 476 73 236 476 minecraft:quartz_block
setblock 69 236 477 minecraft:light_gray_concrete
fill 69 236 481 71 236 481 minecraft:quartz_block
fill 70 236 477 73 236 478 minecraft:quartz_block
fill 70 236 480 72 236 480 minecraft:quartz_block
fill 71 236 472 79 237 472 minecraft:light_gray_concrete
fill 71 236 479 73 236 479 minecraft:quartz_block
fill 72 236 465 75 237 465 minecraft:quartz_block
fill 72 236 473 79 237 473 minecraft:light_gray_concrete
fill 72 236 481 79 236 481 minecraft:light_gray_concrete
setblock 73 236 463 minecraft:white_concrete
fill 73 236 474 79 236 475 minecraft:light_gray_concrete
fill 73 236 480 79 236 480 minecraft:light_gray_concrete
fill 73 236 488 80 237 488 minecraft:quartz_block
fill 73 236 505 74 238 505 minecraft:light_gray_concrete
fill 74 236 466 77 237 466 minecraft:quartz_block
fill 74 236 476 80 236 479 minecraft:light_gray_concrete
fill 75 236 463 75 238 463 minecraft:light_gray_concrete
fill 75 236 487 81 237 487 minecraft:quartz_block
fill 75 236 492 77 237 492 minecraft:light_gray_concrete
fill 76 236 467 78 237 467 minecraft:quartz_block
fill 77 236 468 79 237 468 minecraft:quartz_block
fill 77 236 486 81 237 486 minecraft:quartz_block
fill 77 236 491 78 237 491 minecraft:light_gray_concrete
fill 78 236 469 80 237 470 minecraft:quartz_block
fill 78 236 484 78 237 484 minecraft:light_gray_concrete
fill 78 236 485 82 237 485 minecraft:quartz_block
fill 78 236 505 78 238 505 minecraft:light_gray_concrete
fill 79 236 463 79 238 463 minecraft:light_gray_concrete
fill 79 236 471 81 237 471 minecraft:quartz_block
fill 79 236 482 79 237 482 minecraft:light_gray_concrete
fill 79 236 483 83 237 484 minecraft:quartz_block
fill 79 236 490 79 237 490 minecraft:light_gray_concrete
setblock 80 236 463 minecraft:white_concrete
fill 80 236 472 82 237 474 minecraft:quartz_block
fill 80 236 475 80 237 475 minecraft:light_gray_concrete
fill 80 236 480 83 237 482 minecraft:quartz_block
fill 80 236 489 80 237 489 minecraft:light_gray_concrete
fill 81 236 463 82 236 463 minecraft:light_gray_concrete
fill 81 236 470 81 237 470 minecraft:quartz_block
fill 81 236 475 83 237 479 minecraft:quartz_block
fill 81 236 488 81 237 488 minecraft:light_gray_concrete
fill 82 236 486 82 237 486 minecraft:light_gray_concrete
setblock 82 236 505 minecraft:white_concrete
fill 83 236 474 83 237 474 minecraft:quartz_block
fill 83 236 505 83 238 505 minecraft:light_gray_concrete
fill 84 236 479 84 237 479 minecraft:quartz_block
fill 87 236 463 88 236 463 minecraft:white_concrete
setblock 89 236 463 minecraft:light_gray_concrete
setblock 89 236 474 minecraft:light_gray_concrete
setblock 89 236 477 minecraft:white_concrete
fill 89 236 478 89 238 480 minecraft:light_gray_concrete
fill 89 236 481 89 236 482 minecraft:white_concrete
fill 89 236 483 89 238 483 minecraft:light_gray_concrete
setblock 89 236 485 minecraft:white_concrete
fill 89 236 486 89 238 487 minecraft:light_gray_concrete
fill 89 236 490 89 237 490 minecraft:white_concrete
setblock 89 236 491 minecraft:light_gray_concrete
fill 89 236 501 89 236 503 minecraft:light_gray_concrete
fill 89 236 504 89 236 505 minecraft:white_concrete
setblock 47 237 463 minecraft:white_concrete
setblock 47 237 469 minecraft:white_concrete
fill 47 237 477 51 237 480 minecraft:light_gray_concrete
setblock 47 237 481 minecraft:white_concrete
fill 47 237 482 52 237 483 minecraft:light_gray_concrete
fill 47 237 492 58 237 492 minecraft:light_gray_concrete
fill 47 237 495 67 237 496 minecraft:light_gray_concrete
fill 47 237 498 88 237 498 minecraft:light_gray_concrete
setblock 47 237 505 minecraft:white_concrete
fill 48 237 464 52 237 476 minecraft:light_gray_concrete
fill 48 237 481 52 237 481 minecraft:light_gray_concrete
fill 48 237 484 52 237 491 minecraft:light_gray_concrete
fill 48 237 493 60 237 494 minecraft:light_gray_concrete
fill 48 237 497 88 237 497 minecraft:light_gray_concrete
fill 48 237 499 49 237 505 minecraft:light_gray_concrete
fill 50 237 499 88 237 504 minecraft:light_gray_concrete
fill 52 237 463 52 238 463 minecraft:light_gray_concrete
fill 52 237 477 52 237 478 minecraft:light_gray_concrete
setblock 52 237 480 minecraft:light_gray_concrete
fill 53 237 464 53 237 473 minecraft:light_gray_concrete
fill 53 237 485 53 237 491 minecraft:light_gray_concrete
fill 53 237 505 54 238 505 minecraft:light_gray_concrete
fill 54 237 464 54 237 471 minecraft:light_gray_concrete
fill 54 237 487 54 237 491 minecraft:light_gray_concrete
fill 55 237 464 55 237 469 minecraft:light_gray_concrete
fill 55 237 489 55 237 491 minecraft:light_gray_concrete
fill 56 237 464 56 237 468 minecraft:light_gray_concrete
fill 56 237 490 56 237 491 minecraft:light_gray_concrete
fill 57 237 464 57 237 467 minecraft:light_gray_concrete
setblock 57 237 491 minecraft:light_gray_concrete
fill 58 237 464 58 237 466 minecraft:light_gray_concrete
fill 59 237 464 60 237 465 minecraft:light_gray_concrete
fill 59 237 475 62 237 476 minecraft:quartz_block
fill 60 237 474 63 237 474 minecraft:quartz_block
fill 61 237 464 62 237 464 minecraft:light_gray_concrete
fill 61 237 473 65 237 473 minecraft:quartz_block
fill 61 237 494 62 237 494 minecraft:light_gray_concrete
setblock 62 237 463 minecraft:white_concrete
fill 62 237 477 65 237 481 minecraft:mossy_stone_bricks
fill 62 237 482 62 237 483 minecraft:light_gray_concrete
fill 62 237 505 62 238 505 minecraft:light_gray_concrete
fill 63 237 463 65 238 463 minecraft:light_gray_concrete
fill 63 237 475 73 237 476 minecraft:mossy_stone_bricks
fill 63 237 482 73 237 483 minecraft:mossy_stone_bricks
fill 63 237 484 63 237 485 minecraft:light_gray_concrete
fill 63 237 505 64 237 505 minecraft:white_concrete
fill 64 237 474 72 237 474 minecraft:mossy_stone_bricks
fill 64 237 484 72 237 484 minecraft:mossy_stone_bricks
fill 64 237 485 65 237 485 minecraft:light_gray_concrete
fill 65 237 505 65 238 505 minecraft:light_gray_concrete
setblock 66 237 463 minecraft:white_concrete
fill 66 237 473 70 237 473 minecraft:mossy_stone_bricks
fill 66 237 477 66 237 478 minecraft:mossy_stone_bricks
fill 66 237 480 66 237 481 minecraft:mossy_stone_bricks
fill 66 237 485 70 237 485 minecraft:mossy_stone_bricks
fill 67 237 463 67 240 463 minecraft:light_gray_concrete
setblock 67 237 477 minecraft:mossy_stone_bricks
setblock 67 237 481 minecraft:mossy_stone_bricks
setblock 67 237 505 minecraft:white_concrete
fill 68 237 496 88 237 496 minecraft:light_gray_concrete
fill 68 237 505 68 238 505 minecraft:light_gray_concrete
fill 69 237 477 74 237 477 minecraft:mossy_stone_bricks
fill 69 237 481 74 237 481 minecraft:mossy_stone_bricks
fill 69 237 495 88 237 495 minecraft:light_gray_concrete
setblock 69 237 505 minecraft:white_concrete
fill 70 237 478 74 237 478 minecraft:mossy_stone_bricks
fill 70 237 480 74 237 480 minecraft:mossy_stone_bricks
setblock 71 237 473 minecraft:quartz_block
fill 71 237 479 74 237 479 minecraft:mossy_stone_bricks
fill 71 237 485 77 237 485 minecraft:light_gray_concrete
setblock 72 237 463 minecraft:white_concrete
fill 73 237 463 73 238 463 minecraft:light_gray_concrete
fill 73 237 474 79 237 474 minecraft:light_gray_concrete
fill 73 237 484 77 237 484 minecraft:light_gray_concrete
fill 74 237 464 88 237 464 minecraft:light_gray_concrete
fill 74 237 475 79 237 476 minecraft:light_gray_concrete
fill 74 237 482 78 237 483 minecraft:light_gray_concrete
fill 74 237 494 88 237 494 minecraft:light_gray_concrete
fill 75 237 477 79 237 481 minecraft:light_gray_concrete
fill 76 237 465 88 237 465 minecraft:light_gray_concrete
fill 76 237 493 88 237 493 minecraft:light_gray_concrete
fill 78 237 463 78 238 463 minecraft:light_gray_concrete
fill 78 237 466 88 237 466 minecraft:light_gray_concrete
fill 78 237 492 88 237 492 minecraft:light_gray_concrete
fill 79 237 467 88 237 467 minecraft:light_gray_concrete
fill 79 237 491 88 237 491 minecraft:light_gray_concrete
fill 80 237 463 80 239 463 minecraft:light_gray_concrete
fill 80 237 468 88 237 468 minecraft:light_gray_concrete
fill 80 237 476 80 237 479 minecraft:light_gray_concrete
fill 80 237 490 88 237 490 minecraft:light_gray_concrete
setblock 81 237 463 minecraft:white_concrete
fill 81 237 469 89 237 469 minecraft:light_gray_concrete
fill 81 237 489 88 237 489 minecraft:light_gray_concrete
fill 82 237 463 82 238 463 minecraft:light_gray_concrete
fill 82 237 470 88 237 471 minecraft:light_gray_concrete
fill 82 237 487 88 237 488 minecraft:light_gray_concrete
fill 82 237 505 82 238 505 minecraft:light_gray_concrete
fill 83 237 472 88 237 473 minecraft:light_gray_concrete
fill 83 237 485 88 237 486 minecraft:light_gray_concrete
fill 84 237 474 88 237 478 minecraft:light_gray_concrete
fill 84 237 480 88 237 484 minecraft:light_gray_concrete
fill 85 237 479 88 237 479 minecraft:light_gray_concrete
fill 87 237 463 88 238 463 minecraft:light_gray_concrete
setblock 89 237 463 minecraft:white_concrete
setblock 89 237 470 minecraft:white_concrete
setblock 89 237 474 minecraft:white_concrete
fill 89 237 477 89 238 477 minecraft:light_gray_concrete
fill 89 237 481 89 238 482 minecraft:light_gray_concrete
setblock 89 237 484 minecraft:white_concrete
fill 89 237 485 89 238 485 minecraft:light_gray_concrete
setblock 89 237 491 minecraft:white_concrete
fill 89 237 501 89 238 501 minecraft:light_gray_concrete
setblock 89 237 502 minecraft:white_concrete
fill 89 237 503 89 238 505 minecraft:light_gray_concrete
fill 47 238 463 47 239 463 minecraft:light_gray_concrete
setblock 47 238 469 minecraft:light_gray_concrete
fill 47 238 477 47 238 483 minecraft:light_gray_concrete
setblock 47 238 492 minecraft:light_gray_concrete
fill 47 238 495 47 238 496 minecraft:light_gray_concrete
setblock 47 238 498 minecraft:light_gray_concrete
fill 47 238 505 49 238 505 minecraft:light_gray_concrete
fill 60 238 477 61 247 481 minecraft:stone_bricks
fill 61 238 472 63 250 475 minecraft:cobblestone
fill 61 238 476 62 247 476 minecraft:stone_bricks
fill 61 238 482 62 248 482 minecraft:stone_bricks
fill 61 238 483 63 250 486 minecraft:cobblestone
setblock 62 238 463 minecraft:light_gray_concrete
fill 63 238 505 64 238 505 minecraft:light_gray_concrete
fill 64 238 472 64 250 474 minecraft:cobblestone
fill 64 238 484 64 250 486 minecraft:cobblestone
fill 65 238 472 65 247 473 minecraft:stone_bricks
fill 65 238 485 65 247 486 minecraft:stone_bricks
setblock 66 238 463 minecraft:light_gray_concrete
fill 66 238 471 70 247 472 minecraft:stone_bricks
fill 66 238 486 70 247 487 minecraft:stone_bricks
setblock 67 238 505 minecraft:light_gray_concrete
fill 68 238 463 68 239 463 minecraft:light_gray_concrete
setblock 69 238 505 minecraft:light_gray_concrete
fill 71 238 472 71 247 473 minecraft:stone_bricks
fill 71 238 485 71 248 486 minecraft:stone_bricks
setblock 72 238 463 minecraft:light_gray_concrete
fill 72 238 472 75 250 474 minecraft:cobblestone
fill 72 238 484 75 250 486 minecraft:cobblestone
fill 73 238 475 75 250 475 minecraft:cobblestone
fill 73 238 483 75 250 483 minecraft:cobblestone
fill 74 238 476 75 248 476 minecraft:stone_bricks
fill 74 238 482 75 247 482 minecraft:stone_bricks
fill 75 238 477 76 247 481 minecraft:stone_bricks
setblock 81 238 463 minecraft:light_gray_concrete
setblock 89 238 463 minecraft:light_gray_concrete
fill 89 238 469 89 238 470 minecraft:light_gray_concrete
setblock 89 238 474 minecraft:light_gray_concrete
setblock 89 238 484 minecraft:light_gray_concrete
fill 89 238 490 89 238 491 minecraft:light_gray_concrete
setblock 89 238 502 minecraft:light_gray_concrete
fill 47 239 464 47 307 466 minecraft:white_concrete
fill 47 239 468 47 239 470 minecraft:white_concrete
fill 47 239 472 47 241 486 minecraft:white_concrete
setblock 47 239 487 minecraft:light_gray_concrete
fill 47 239 488 47 239 505 minecraft:white_concrete
fill 48 239 463 50 239 463 minecraft:white_concrete
fill 48 239 505 62 240 505 minecraft:white_concrete
setblock 50 239 466 minecraft:light[level=14]
setblock 50 239 474 minecraft:light[level=14]
setblock 50 239 482 minecraft:light[level=14]
setblock 50 239 490 minecraft:light[level=14]
setblock 50 239 498 minecraft:light[level=14]
fill 52 239 463 63 239 463 minecraft:white_concrete
setblock 58 239 466 minecraft:light[level=14]
setblock 58 239 474 minecraft:light[level=14]
setblock 58 239 482 minecraft:light[level=14]
setblock 58 239 490 minecraft:light[level=14]
setblock 58 239 498 minecraft:light[level=14]
setblock 63 239 505 minecraft:light_gray_concrete
setblock 64 239 463 minecraft:light_gray_concrete
fill 64 239 505 88 239 505 minecraft:white_concrete
fill 65 239 463 66 307 463 minecraft:white_concrete
setblock 66 239 466 minecraft:light[level=14]
setblock 66 239 474 minecraft:light[level=14]
setblock 66 239 482 minecraft:light[level=14]
setblock 66 239 490 minecraft:light[level=14]
setblock 66 239 498 minecraft:light[level=14]
fill 69 239 463 75 239 463 minecraft:white_concrete
setblock 74 239 466 minecraft:light[level=14]
setblock 74 239 490 minecraft:light[level=14]
setblock 74 239 498 minecraft:light[level=14]
fill 77 239 463 79 241 463 minecraft:white_concrete
fill 81 239 463 89 239 463 minecraft:white_concrete
setblock 82 239 466 minecraft:light[level=14]
setblock 82 239 474 minecraft:light[level=14]
setblock 82 239 482 minecraft:light[level=14]
setblock 82 239 490 minecraft:light[level=14]
setblock 82 239 498 minecraft:light[level=14]
fill 89 239 464 89 307 465 minecraft:white_concrete
fill 89 239 466 89 239 467 minecraft:light_gray_concrete
fill 89 239 468 89 241 469 minecraft:white_concrete
setblock 89 239 470 minecraft:light_gray_concrete
fill 89 239 471 89 240 471 minecraft:white_concrete
setblock 89 239 472 minecraft:light_gray_concrete
fill 89 239 473 89 240 479 minecraft:white_concrete
fill 89 239 480 89 240 480 minecraft:light_gray_concrete
fill 89 239 481 89 239 504 minecraft:white_concrete
setblock 89 239 505 minecraft:light_gray_concrete
fill 47 240 463 49 307 463 minecraft:white_concrete
fill 47 240 467 47 307 467 minecraft:white_concrete
fill 47 240 468 47 241 468 minecraft:light_gray_concrete
fill 47 240 469 47 307 471 minecraft:white_concrete
fill 47 240 487 47 307 487 minecraft:white_concrete
fill 47 240 488 47 240 490 minecraft:light_gray_concrete
fill 47 240 491 47 307 491 minecraft:white_concrete
fill 47 240 492 47 240 493 minecraft:light_gray_concrete
fill 47 240 494 47 307 494 minecraft:white_concrete
setblock 47 240 495 minecraft:light_gray_concrete
fill 47 240 496 47 241 501 minecraft:white_concrete
setblock 47 240 502 minecraft:light_gray_concrete
fill 47 240 503 47 240 505 minecraft:white_concrete
setblock 50 240 463 minecraft:light_gray_concrete
fill 51 240 463 51 307 463 minecraft:white_concrete
setblock 52 240 463 minecraft:light_gray_concrete
fill 53 240 463 54 241 463 minecraft:white_concrete
setblock 55 240 463 minecraft:light_gray_concrete
fill 56 240 463 64 241 463 minecraft:white_concrete
setblock 63 240 505 minecraft:white_concrete
fill 64 240 505 64 241 505 minecraft:light_gray_concrete
fill 65 240 505 71 240 505 minecraft:white_concrete
fill 68 240 463 74 241 463 minecraft:white_concrete
setblock 72 240 505 minecraft:light_gray_concrete
fill 73 240 505 81 240 505 minecraft:white_concrete
setblock 75 240 463 minecraft:light_gray_concrete
fill 76 240 463 76 307 463 minecraft:white_concrete
fill 80 240 463 83 240 463 minecraft:white_concrete
setblock 82 240 505 minecraft:light_gray_concrete
fill 83 240 505 89 307 505 minecraft:white_concrete
fill 84 240 463 85 240 463 minecraft:light_gray_concrete
fill 86 240 463 89 240 463 minecraft:white_concrete
fill 89 240 466 89 307 467 minecraft:white_concrete
fill 89 240 470 89 307 470 minecraft:white_concrete
fill 89 240 472 89 307 472 minecraft:white_concrete
fill 89 240 481 89 240 482 minecraft:light_gray_concrete
fill 89 240 483 89 240 504 minecraft:white_concrete
fill 47 241 488 47 307 490 minecraft:white_concrete
fill 47 241 492 47 241 493 minecraft:white_concrete
fill 47 241 495 47 307 495 minecraft:white_concrete
fill 47 241 502 47 307 504 minecraft:white_concrete
setblock 47 241 505 minecraft:light_gray_concrete
fill 48 241 470 48 273 471 minecraft:quartz_block
fill 48 241 478 48 273 479 minecraft:quartz_block
fill 48 241 486 48 273 487 minecraft:quartz_block
fill 48 241 494 48 273 495 minecraft:quartz_block
fill 48 241 502 48 273 503 minecraft:quartz_block
fill 48 241 505 59 241 505 minecraft:white_concrete
fill 49 241 464 50 273 464 minecraft:quartz_block
fill 50 241 463 50 307 463 minecraft:white_concrete
fill 52 241 463 52 307 463 minecraft:white_concrete
fill 54 241 504 55 273 504 minecraft:quartz_block
fill 55 241 463 55 307 463 minecraft:white_concrete
fill 57 241 464 58 273 464 minecraft:quartz_block
fill 59 241 464 59 241 466 minecraft:iron_block
setblock 60 241 505 minecraft:light_gray_concrete
fill 61 241 505 62 307 505 minecraft:white_concrete
fill 62 241 504 63 273 504 minecraft:quartz_block
setblock 63 241 505 minecraft:light_gray_concrete
fill 65 241 464 66 273 464 minecraft:quartz_block
fill 65 241 505 67 241 505 minecraft:white_concrete
fill 67 241 463 67 307 463 minecraft:white_concrete
setblock 68 241 505 minecraft:light_gray_concrete
fill 69 241 505 76 241 505 minecraft:white_concrete
fill 70 241 504 71 273 504 minecraft:quartz_block
fill 73 241 464 74 273 464 minecraft:quartz_block
fill 75 241 463 75 307 463 minecraft:white_concrete
setblock 77 241 505 minecraft:light_gray_concrete
fill 78 241 504 79 273 504 minecraft:quartz_block
fill 78 241 505 82 241 505 minecraft:white_concrete
fill 80 241 463 81 307 463 minecraft:white_concrete
fill 81 241 464 82 273 464 minecraft:quartz_block
fill 81 241 465 81 242 466 minecraft:iron_block
setblock 82 241 463 minecraft:light_gray_concrete
fill 83 241 463 83 307 463 minecraft:white_concrete
fill 83 241 473 83 241 479 minecraft:black_concrete
setblock 84 241 463 minecraft:light_gray_concrete
fill 84 241 480 88 241 485 minecraft:quartz_block
fill 85 241 463 87 241 463 minecraft:white_concrete
fill 85 241 486 88 242 486 minecraft:quartz_block
fill 86 241 504 87 273 504 minecraft:quartz_block
fill 87 241 479 88 241 479 minecraft:quartz_block
setblock 88 241 463 minecraft:light_gray_concrete
fill 88 241 465 88 273 466 minecraft:quartz_block
fill 88 241 473 88 273 474 minecraft:quartz_block
fill 88 241 489 88 273 490 minecraft:quartz_block
fill 88 241 497 88 273 498 minecraft:quartz_block
fill 89 241 463 89 307 463 minecraft:white_concrete
setblock 89 241 471 minecraft:light_gray_concrete
fill 89 241 473 89 307 474 minecraft:white_concrete
setblock 89 241 475 minecraft:light_gray_concrete
fill 89 241 476 89 241 481 minecraft:white_concrete
setblock 89 241 482 minecraft:light_gray_concrete
fill 89 241 483 89 241 489 minecraft:white_concrete
setblock 89 241 490 minecraft:light_gray_concrete
fill 89 241 491 89 241 492 minecraft:white_concrete
setblock 89 241 493 minecraft:light_gray_concrete
fill 89 241 494 89 241 504 minecraft:white_concrete
fill 47 242 468 47 247 468 minecraft:sea_lantern
fill 47 242 472 47 307 475 minecraft:white_concrete
fill 47 242 476 47 247 476 minecraft:sea_lantern
fill 47 242 477 47 307 483 minecraft:white_concrete
fill 47 242 484 47 247 484 minecraft:sea_lantern
fill 47 242 485 47 307 486 minecraft:white_concrete
fill 47 242 492 47 247 492 minecraft:sea_lantern
fill 47 242 493 47 307 493 minecraft:white_concrete
fill 47 242 496 47 307 499 minecraft:white_concrete
fill 47 242 500 47 247 500 minecraft:sea_lantern
fill 47 242 501 47 307 501 minecraft:white_concrete
fill 47 242 505 49 307 505 minecraft:white_concrete
fill 50 242 505 50 247 505 minecraft:sea_lantern
fill 51 242 505 57 307 505 minecraft:white_concrete
fill 53 242 463 53 307 463 minecraft:white_concrete
fill 54 242 463 54 247 463 minecraft:sea_lantern
fill 56 242 463 61 307 463 minecraft:white_concrete
fill 58 242 505 58 247 505 minecraft:sea_lantern
fill 59 242 505 60 307 505 minecraft:white_concrete
fill 62 242 463 62 247 463 minecraft:sea_lantern
fill 63 242 463 64 307 463 minecraft:white_concrete
fill 63 242 505 65 307 505 minecraft:white_concrete
fill 66 242 505 66 247 505 minecraft:sea_lantern
fill 67 242 505 73 307 505 minecraft:white_concrete
fill 68 242 463 69 307 463 minecraft:white_concrete
fill 70 242 463 70 247 463 minecraft:sea_lantern
fill 71 242 463 74 307 463 minecraft:white_concrete
fill 74 242 505 74 247 505 minecraft:sea_lantern
fill 75 242 505 81 307 505 minecraft:white_concrete
fill 77 242 463 77 307 463 minecraft:white_concrete
fill 78 242 463 78 247 463 minecraft:sea_lantern
fill 79 242 463 79 307 463 minecraft:white_concrete
fill 82 242 463 82 307 463 minecraft:white_concrete
fill 82 242 505 82 247 505 minecraft:sea_lantern
fill 83 242 478 83 242 483 minecraft:black_concrete
fill 84 242 463 85 307 463 minecraft:white_concrete
fill 84 242 484 84 242 490 minecraft:quartz_block
fill 85 242 484 88 242 485 minecraft:quartz_block
fill 85 242 487 87 242 490 minecraft:quartz_block
fill 86 242 463 86 247 463 minecraft:sea_lantern
fill 87 242 463 88 307 463 minecraft:white_concrete
fill 87 242 491 88 243 491 minecraft:quartz_block
fill 88 242 481 88 273 482 minecraft:quartz_block
fill 88 242 487 88 242 488 minecraft:quartz_block
fill 89 242 468 89 247 468 minecraft:sea_lantern
fill 89 242 469 89 307 469 minecraft:white_concrete
fill 89 242 471 89 307 471 minecraft:white_concrete
fill 89 242 475 89 307 475 minecraft:white_concrete
fill 89 242 476 89 247 476 minecraft:sea_lantern
fill 89 242 477 89 307 483 minecraft:white_concrete
fill 89 242 484 89 247 484 minecraft:sea_lantern
fill 89 242 485 89 307 491 minecraft:white_concrete
fill 89 242 492 89 247 492 minecraft:sea_lantern
fill 89 242 493 89 307 499 minecraft:white_concrete
fill 89 242 500 89 247 500 minecraft:sea_lantern
fill 89 242 501 89 307 504 minecraft:white_concrete
fill 83 243 482 83 243 487 minecraft:black_concrete
fill 84 243 488 86 243 495 minecraft:quartz_block
fill 86 243 496 88 244 496 minecraft:quartz_block
fill 87 243 489 87 243 490 minecraft:quartz_block
fill 87 243 492 88 243 495 minecraft:quartz_block
fill 87 243 497 87 244 497 minecraft:quartz_block
fill 83 244 486 83 244 491 minecraft:black_concrete
fill 83 244 500 88 244 500 minecraft:quartz_block
fill 84 244 492 84 244 499 minecraft:quartz_block
fill 84 244 501 88 245 502 minecraft:quartz_block
fill 85 244 493 85 244 499 minecraft:quartz_block
fill 85 244 503 88 245 503 minecraft:quartz_block
fill 86 244 493 86 244 495 minecraft:quartz_block
fill 86 244 497 86 244 499 minecraft:quartz_block
fill 87 244 494 88 244 495 minecraft:quartz_block
fill 87 244 498 87 244 499 minecraft:quartz_block
setblock 88 244 499 minecraft:quartz_block
fill 88 244 504 88 245 504 minecraft:quartz_block
fill 77 245 500 83 245 501 minecraft:quartz_block
fill 78 245 502 83 245 503 minecraft:quartz_block
fill 80 245 504 85 245 504 minecraft:quartz_block
fill 83 245 489 83 245 496 minecraft:black_concrete
fill 84 245 498 84 245 500 minecraft:quartz_block
setblock 84 245 503 minecraft:quartz_block
fill 85 245 499 85 245 500 minecraft:quartz_block
setblock 86 245 500 minecraft:quartz_block
fill 72 246 500 79 246 500 minecraft:quartz_block
fill 73 246 501 77 246 504 minecraft:quartz_block
fill 78 246 501 80 246 503 minecraft:quartz_block
fill 79 246 499 83 246 499 minecraft:black_concrete
fill 80 246 504 82 246 504 minecraft:quartz_block
fill 81 246 502 81 246 503 minecraft:quartz_block
fill 83 246 494 83 246 498 minecraft:black_concrete
setblock 50 247 466 minecraft:light[level=14]
setblock 50 247 474 minecraft:light[level=14]
setblock 50 247 482 minecraft:light[level=14]
setblock 50 247 490 minecraft:light[level=14]
setblock 50 247 498 minecraft:light[level=14]
setblock 58 247 466 minecraft:light[level=14]
setblock 58 247 474 minecraft:light[level=14]
setblock 58 247 482 minecraft:light[level=14]
setblock 58 247 490 minecraft:light[level=14]
setblock 58 247 498 minecraft:light[level=14]
setblock 66 247 466 minecraft:light[level=14]
setblock 66 247 474 minecraft:light[level=14]
setblock 66 247 482 minecraft:light[level=14]
setblock 66 247 490 minecraft:light[level=14]
setblock 66 247 498 minecraft:light[level=14]
fill 68 247 500 69 248 504 minecraft:quartz_block
fill 70 247 500 74 247 503 minecraft:quartz_block
fill 72 247 504 76 247 504 minecraft:quartz_block
setblock 74 247 466 minecraft:light[level=14]
setblock 74 247 490 minecraft:light[level=14]
setblock 74 247 498 minecraft:light[level=14]
fill 75 247 499 82 247 499 minecraft:black_concrete
fill 75 247 502 75 247 503 minecraft:quartz_block
setblock 82 247 466 minecraft:light[level=14]
setblock 82 247 474 minecraft:light[level=14]
setblock 82 247 482 minecraft:light[level=14]
setblock 82 247 490 minecraft:light[level=14]
setblock 82 247 498 minecraft:light[level=14]
fill 47 248 468 47 255 468 minecraft:white_concrete
fill 47 248 476 47 255 476 minecraft:white_concrete
fill 47 248 484 47 255 484 minecraft:white_concrete
fill 47 248 492 47 255 492 minecraft:white_concrete
fill 47 248 500 47 255 500 minecraft:white_concrete
fill 50 248 505 50 255 505 minecraft:white_concrete
fill 54 248 463 54 255 463 minecraft:white_concrete
fill 58 248 505 58 255 505 minecraft:white_concrete
fill 60 248 477 61 248 477 minecraft:stone_bricks
fill 60 248 479 60 248 480 minecraft:stone_bricks
fill 61 248 478 61 248 479 minecraft:stone_bricks
fill 62 248 463 62 255 463 minecraft:white_concrete
fill 64 248 501 67 248 504 minecraft:quartz_block
fill 65 248 472 66 248 472 minecraft:stone_bricks
setblock 65 248 485 minecraft:stone_bricks
fill 65 248 500 67 248 500 minecraft:quartz_block
setblock 66 248 471 minecraft:stone_bricks
fill 66 248 505 66 255 505 minecraft:white_concrete
fill 67 248 486 68 248 487 minecraft:stone_bricks
fill 69 248 471 70 248 472 minecraft:stone_bricks
fill 70 248 463 70 255 463 minecraft:white_concrete
fill 70 248 500 70 248 503 minecraft:quartz_block
fill 71 248 499 76 248 499 minecraft:black_concrete
fill 74 248 505 74 255 505 minecraft:white_concrete
setblock 75 248 477 minecraft:stone_bricks
fill 75 248 479 76 248 480 minecraft:stone_bricks
setblock 76 248 481 minecraft:stone_bricks
fill 78 248 463 78 255 463 minecraft:white_concrete
fill 82 248 505 82 255 505 minecraft:white_concrete
fill 86 248 463 86 255 463 minecraft:white_concrete
fill 89 248 468 89 255 468 minecraft:white_concrete
fill 89 248 476 89 255 476 minecraft:white_concrete
fill 89 248 484 89 255 484 minecraft:white_concrete
fill 89 248 492 89 255 492 minecraft:white_concrete
fill 89 248 500 89 255 500 minecraft:white_concrete
fill 58 249 504 61 249 504 minecraft:quartz_block
fill 59 249 502 66 249 503 minecraft:quartz_block
fill 60 249 500 66 249 501 minecraft:quartz_block
fill 64 249 504 66 249 504 minecraft:quartz_block
fill 67 249 499 72 249 499 minecraft:black_concrete
fill 51 250 504 53 253 504 minecraft:quartz_block
fill 52 250 503 61 250 503 minecraft:quartz_block
fill 53 250 501 61 250 502 minecraft:quartz_block
fill 54 250 500 62 250 500 minecraft:quartz_block
fill 56 250 504 60 250 504 minecraft:quartz_block
setblock 62 250 501 minecraft:quartz_block
fill 63 250 499 68 250 499 minecraft:black_concrete
fill 48 251 498 52 251 501 minecraft:quartz_block
fill 48 251 504 50 253 504 minecraft:quartz_block
fill 49 251 502 55 251 503 minecraft:quartz_block
fill 50 251 497 52 252 497 minecraft:quartz_block
fill 51 251 496 52 252 496 minecraft:quartz_block
fill 53 251 500 56 251 501 minecraft:quartz_block
setblock 56 251 502 minecraft:quartz_block
setblock 57 251 500 minecraft:quartz_block
fill 59 251 499 65 251 499 minecraft:black_concrete
fill 60 251 473 64 251 474 minecraft:dark_oak_planks
fill 60 251 484 64 251 485 minecraft:dark_oak_planks
fill 61 251 472 64 251 472 minecraft:dark_oak_planks
fill 61 251 475 64 251 475 minecraft:dark_oak_planks
fill 61 251 483 64 251 483 minecraft:dark_oak_planks
fill 61 251 486 64 251 486 minecraft:dark_oak_planks
fill 62 251 471 63 251 471 minecraft:dark_oak_planks
fill 62 251 487 63 251 487 minecraft:dark_oak_planks
fill 72 251 472 75 251 475 minecraft:dark_oak_planks
fill 72 251 483 75 251 486 minecraft:dark_oak_planks
fill 73 251 471 74 251 471 minecraft:dark_oak_planks
fill 73 251 487 74 251 487 minecraft:dark_oak_planks
fill 76 251 473 76 251 474 minecraft:dark_oak_planks
fill 76 251 484 76 251 485 minecraft:dark_oak_planks
fill 48 252 464 48 253 469 minecraft:quartz_block
fill 48 252 472 49 252 477 minecraft:quartz_block
fill 48 252 480 49 252 485 minecraft:quartz_block
fill 48 252 488 49 253 493 minecraft:quartz_block
fill 48 252 496 49 252 501 minecraft:quartz_block
fill 49 252 465 49 252 471 minecraft:quartz_block
fill 49 252 478 49 252 479 minecraft:quartz_block
fill 49 252 486 49 252 487 minecraft:quartz_block
fill 49 252 494 52 252 495 minecraft:quartz_block
fill 49 252 502 49 252 503 minecraft:quartz_block
fill 50 252 465 87 252 465 minecraft:quartz_block
fill 50 252 491 52 252 493 minecraft:quartz_block
setblock 50 252 496 minecraft:quartz_block
fill 50 252 498 50 252 500 minecraft:quartz_block
fill 50 252 503 88 252 503 minecraft:quartz_block
fill 51 252 464 56 253 464 minecraft:quartz_block
fill 51 252 498 51 252 499 minecraft:quartz_block
setblock 52 252 498 minecraft:quartz_block
fill 53 252 498 53 253 499 minecraft:black_concrete
fill 54 252 499 61 252 499 minecraft:black_concrete
fill 56 252 504 61 253 504 minecraft:quartz_block
fill 59 252 464 64 253 464 minecraft:quartz_block
fill 61 252 472 63 252 474 minecraft:dark_oak_planks
fill 61 252 484 63 252 486 minecraft:dark_oak_planks
fill 62 252 475 63 252 475 minecraft:dark_oak_planks
fill 62 252 483 63 252 483 minecraft:dark_oak_planks
fill 64 252 473 64 252 474 minecraft:dark_oak_planks
fill 64 252 484 64 252 485 minecraft:dark_oak_planks
fill 64 252 504 69 253 504 minecraft:quartz_block
fill 67 252 464 72 253 464 minecraft:quartz_block
fill 72 252 473 75 252 474 minecraft:dark_oak_planks
fill 72 252 484 75 252 485 minecraft:dark_oak_planks
fill 72 252 504 77 253 504 minecraft:quartz_block
fill 73 252 472 75 252 472 minecraft:dark_oak_planks
fill 73 252 475 74 252 475 minecraft:dark_oak_planks
fill 73 252 483 74 252 483 minecraft:dark_oak_planks
fill 73 252 486 75 252 486 minecraft:dark_oak_planks
fill 75 252 464 80 253 464 minecraft:quartz_block
fill 80 252 504 85 253 504 minecraft:quartz_block
fill 83 252 464 88 253 464 minecraft:quartz_block
fill 87 252 466 87 252 502 minecraft:quartz_block
fill 88 252 467 88 253 472 minecraft:quartz_block
fill 88 252 475 88 253 480 minecraft:quartz_block
fill 88 252 483 88 253 488 minecraft:quartz_block
fill 88 252 491 88 253 496 minecraft:quartz_block
fill 88 252 499 88 253 502 minecraft:quartz_block
fill 88 252 504 88 253 504 minecraft:quartz_block
fill 48 253 472 48 253 477 minecraft:quartz_block
fill 48 253 480 48 253 485 minecraft:quartz_block
fill 48 253 496 48 253 501 minecraft:quartz_block
fill 49 253 487 52 254 487 minecraft:quartz_block
fill 49 253 494 50 253 494 minecraft:quartz_block
fill 50 253 488 51 253 493 minecraft:quartz_block
fill 52 253 486 52 254 486 minecraft:quartz_block
fill 52 253 488 52 253 492 minecraft:quartz_block
fill 53 253 493 53 253 497 minecraft:black_concrete
fill 54 253 499 55 253 499 minecraft:black_concrete
fill 61 253 473 63 253 474 minecraft:dark_oak_planks
fill 61 253 484 63 253 485 minecraft:dark_oak_planks
fill 62 253 472 63 253 472 minecraft:dark_oak_planks
fill 62 253 486 63 253 486 minecraft:dark_oak_planks
fill 73 253 472 74 253 474 minecraft:dark_oak_planks
fill 73 253 484 74 253 486 minecraft:dark_oak_planks
fill 75 253 473 75 253 474 minecraft:dark_oak_planks
fill 75 253 484 75 253 485 minecraft:dark_oak_planks
setblock 88 253 503 minecraft:quartz_block
fill 48 254 482 51 254 485 minecraft:quartz_block
fill 48 254 488 49 254 489 minecraft:quartz_block
fill 49 254 486 51 254 486 minecraft:quartz_block
fill 50 254 488 52 254 488 minecraft:quartz_block
fill 52 254 483 52 254 485 minecraft:quartz_block
fill 53 254 489 53 254 495 minecraft:black_concrete
fill 62 254 473 63 254 474 minecraft:dark_oak_planks
fill 62 254 484 63 254 485 minecraft:dark_oak_planks
fill 73 254 473 74 254 474 minecraft:dark_oak_planks
fill 73 254 484 74 254 485 minecraft:dark_oak_planks
fill 48 255 477 49 256 477 minecraft:quartz_block
fill 48 255 480 52 255 484 minecraft:quartz_block
fill 49 255 478 52 256 479 minecraft:quartz_block
setblock 50 255 466 minecraft:light[level=14]
setblock 50 255 474 minecraft:light[level=14]
setblock 50 255 490 minecraft:light[level=14]
setblock 50 255 498 minecraft:light[level=14]
fill 53 255 485 53 255 490 minecraft:black_concrete
setblock 58 255 466 minecraft:light[level=14]
setblock 58 255 474 minecraft:light[level=14]
setblock 58 255 482 minecraft:light[level=14]
setblock 58 255 490 minecraft:light[level=14]
setblock 58 255 498 minecraft:light[level=14]
setblock 62 255 473 minecraft:dark_oak_planks
setblock 62 255 485 minecraft:dark_oak_planks
setblock 66 255 466 minecraft:light[level=14]
setblock 66 255 474 minecraft:light[level=14]
setblock 66 255 482 minecraft:light[level=14]
setblock 66 255 490 minecraft:light[level=14]
setblock 66 255 498 minecraft:light[level=14]
setblock 74 255 466 minecraft:light[level=14]
setblock 74 255 473 minecraft:dark_oak_planks
setblock 74 255 474 minecraft:light[level=14]
setblock 74 255 482 minecraft:light[level=14]
setblock 74 255 485 minecraft:dark_oak_planks
setblock 74 255 490 minecraft:light[level=14]
setblock 74 255 498 minecraft:light[level=14]
setblock 82 255 466 minecraft:light[level=14]
setblock 82 255 474 minecraft:light[level=14]
setblock 82 255 482 minecraft:light[level=14]
setblock 82 255 490 minecraft:light[level=14]
setblock 82 255 498 minecraft:light[level=14]
fill 47 256 468 47 261 468 minecraft:sea_lantern
fill 47 256 476 47 261 476 minecraft:sea_lantern
fill 47 256 484 47 261 484 minecraft:sea_lantern
fill 47 256 492 47 261 492 minecraft:sea_lantern
fill 47 256 500 47 261 500 minecraft:sea_lantern
fill 48 256 472 50 256 476 minecraft:quartz_block
fill 49 256 471 49 257 471 minecraft:quartz_block
fill 50 256 477 52 256 477 minecraft:quartz_block
fill 50 256 480 52 256 480 minecraft:quartz_block
fill 50 256 505 50 261 505 minecraft:sea_lantern
fill 51 256 473 52 256 476 minecraft:quartz_block
fill 53 256 481 53 256 486 minecraft:black_concrete
fill 54 256 463 54 261 463 minecraft:sea_lantern
fill 58 256 505 58 261 505 minecraft:sea_lantern
fill 62 256 463 62 261 463 minecraft:sea_lantern
fill 66 256 505 66 261 505 minecraft:sea_lantern
fill 70 256 463 70 261 463 minecraft:sea_lantern
fill 74 256 505 74 261 505 minecraft:sea_lantern
fill 78 256 463 78 261 463 minecraft:sea_lantern
fill 82 256 505 82 261 505 minecraft:sea_lantern
fill 86 256 463 86 261 463 minecraft:sea_lantern
fill 89 256 468 89 261 468 minecraft:sea_lantern
fill 89 256 476 89 261 476 minecraft:sea_lantern
fill 89 256 484 89 261 484 minecraft:sea_lantern
fill 89 256 492 89 261 492 minecraft:sea_lantern
fill 89 256 500 89 261 500 minecraft:sea_lantern
fill 48 257 464 48 257 469 minecraft:quartz_block
fill 48 257 472 52 257 474 minecraft:quartz_block
fill 49 257 465 51 257 470 minecraft:quartz_block
fill 50 257 471 52 257 471 minecraft:quartz_block
fill 50 257 475 52 257 475 minecraft:quartz_block
fill 52 257 466 52 258 470 minecraft:quartz_block
setblock 52 257 476 minecraft:quartz_block
fill 53 257 468 53 258 468 minecraft:quartz_block
fill 53 257 477 53 257 482 minecraft:black_concrete
fill 48 258 464 48 258 467 minecraft:quartz_block
fill 49 258 465 51 258 467 minecraft:quartz_block
fill 50 258 468 51 258 468 minecraft:quartz_block
fill 51 258 464 56 258 464 minecraft:quartz_block
setblock 51 258 469 minecraft:quartz_block
fill 52 258 465 58 258 465 minecraft:quartz_block
fill 53 258 466 58 258 467 minecraft:quartz_block
fill 53 258 472 53 258 479 minecraft:black_concrete
fill 54 258 468 59 258 468 minecraft:quartz_block
fill 59 258 467 59 259 467 minecraft:quartz_block
fill 53 259 469 53 259 474 minecraft:black_concrete
fill 54 259 464 56 259 464 minecraft:quartz_block
fill 54 259 469 57 260 469 minecraft:black_concrete
fill 55 259 465 63 259 466 minecraft:quartz_block
fill 56 259 467 58 259 467 minecraft:quartz_block
fill 57 259 468 64 259 468 minecraft:quartz_block
fill 59 259 464 63 259 464 minecraft:quartz_block
fill 60 259 467 63 259 467 minecraft:quartz_block
fill 58 260 469 61 260 469 minecraft:black_concrete
fill 60 260 464 64 260 464 minecraft:quartz_block
fill 61 260 465 68 260 466 minecraft:quartz_block
fill 62 260 467 68 260 468 minecraft:quartz_block
fill 67 260 464 68 261 464 minecraft:quartz_block
fill 60 261 469 65 261 469 minecraft:black_concrete
fill 66 261 465 71 261 468 minecraft:quartz_block
fill 69 261 464 72 261 464 minecraft:quartz_block
fill 72 261 465 72 262 467 minecraft:quartz_block
fill 47 262 468 47 269 468 minecraft:white_concrete
fill 47 262 476 47 269 476 minecraft:white_concrete
fill 47 262 484 47 269 484 minecraft:white_concrete
fill 47 262 492 47 269 492 minecraft:white_concrete
fill 47 262 500 47 269 500 minecraft:white_concrete
fill 50 262 505 50 269 505 minecraft:white_concrete
fill 54 262 463 54 269 463 minecraft:white_concrete
fill 58 262 505 58 269 505 minecraft:white_concrete
fill 62 262 463 62 269 463 minecraft:white_concrete
fill 64 262 469 69 262 469 minecraft:black_concrete
fill 66 262 505 66 269 505 minecraft:white_concrete
fill 70 262 463 70 269 463 minecraft:white_concrete
fill 70 262 464 71 262 468 minecraft:quartz_block
setblock 72 262 464 minecraft:quartz_block
fill 72 262 468 76 262 468 minecraft:quartz_block
fill 73 262 465 76 262 467 minecraft:quartz_block
fill 74 262 505 74 269 505 minecraft:white_concrete
fill 75 262 464 78 262 464 minecraft:quartz_block
fill 77 262 465 77 263 466 minecraft:quartz_block
fill 78 262 463 78 269 463 minecraft:white_concrete
fill 82 262 505 82 269 505 minecraft:white_concrete
fill 86 262 463 86 269 463 minecraft:white_concrete
fill 89 262 468 89 269 468 minecraft:white_concrete
fill 89 262 476 89 269 476 minecraft:white_concrete
fill 89 262 484 89 269 484 minecraft:white_concrete
fill 89 262 492 89 269 492 minecraft:white_concrete
fill 89 262 500 89 269 500 minecraft:white_concrete
setblock 50 263 466 minecraft:light[level=14]
setblock 50 263 474 minecraft:light[level=14]
setblock 50 263 482 minecraft:light[level=14]
setblock 50 263 490 minecraft:light[level=14]
setblock 50 263 498 minecraft:light[level=14]
setblock 58 263 466 minecraft:light[level=14]
setblock 58 263 474 minecraft:light[level=14]
setblock 58 263 482 minecraft:light[level=14]
setblock 58 263 490 minecraft:light[level=14]
setblock 58 263 498 minecraft:light[level=14]
setblock 66 263 466 minecraft:light[level=14]
setblock 66 263 474 minecraft:light[level=14]
setblock 66 263 482 minecraft:light[level=14]
setblock 66 263 490 minecraft:light[level=14]
setblock 66 263 498 minecraft:light[level=14]
fill 68 263 469 73 263 469 minecraft:black_concrete
setblock 74 263 466 minecraft:light[level=14]
fill 74 263 467 82 263 468 minecraft:quartz_block
setblock 74 263 474 minecraft:light[level=14]
setblock 74 263 482 minecraft:light[level=14]
setblock 74 263 490 minecraft:light[level=14]
setblock 74 263 498 minecraft:light[level=14]
fill 75 263 465 76 263 466 minecraft:quartz_block
fill 76 263 464 80 263 464 minecraft:quartz_block
fill 78 263 465 83 263 466 minecraft:quartz_block
setblock 82 263 474 minecraft:light[level=14]
setblock 82 263 482 minecraft:light[level=14]
setblock 82 263 490 minecraft:light[level=14]
setblock 82 263 498 minecraft:light[level=14]
fill 83 263 464 85 264 464 minecraft:quartz_block
fill 83 263 467 83 264 467 minecraft:quartz_block
fill 84 263 465 84 264 465 minecraft:quartz_block
fill 71 264 469 77 264 469 minecraft:black_concrete
fill 79 264 468 88 264 468 minecraft:quartz_block
fill 80 264 466 82 264 467 minecraft:quartz_block
fill 81 264 465 83 264 465 minecraft:quartz_block
fill 83 264 466 87 264 466 minecraft:quartz_block
fill 84 264 467 88 264 467 minecraft:quartz_block
fill 84 264 469 85 264 472 minecraft:quartz_block
fill 85 264 465 87 264 465 minecraft:quartz_block
fill 86 264 464 88 264 464 minecraft:quartz_block
fill 86 264 469 86 265 471 minecraft:quartz_block
fill 87 264 469 88 266 470 minecraft:quartz_block
fill 75 265 469 83 265 469 minecraft:black_concrete
fill 83 265 470 83 266 470 minecraft:black_concrete
fill 84 265 470 85 265 477 minecraft:quartz_block
setblock 85 265 469 minecraft:quartz_block
fill 86 265 468 88 265 468 minecraft:quartz_block
fill 86 265 472 86 265 477 minecraft:quartz_block
fill 87 265 467 88 266 467 minecraft:quartz_block
fill 87 265 471 87 266 476 minecraft:quartz_block
fill 88 265 471 88 267 472 minecraft:quartz_block
fill 88 265 475 88 267 476 minecraft:quartz_block
fill 48 266 464 48 267 469 minecraft:quartz_block
fill 48 266 472 49 266 477 minecraft:quartz_block
fill 48 266 480 49 266 485 minecraft:quartz_block
fill 48 266 488 49 266 493 minecraft:quartz_block
fill 48 266 496 49 266 501 minecraft:quartz_block
fill 48 266 504 53 267 504 minecraft:quartz_block
fill 49 266 465 49 266 471 minecraft:quartz_block
fill 49 266 478 49 266 479 minecraft:quartz_block
fill 49 266 486 49 266 487 minecraft:quartz_block
fill 49 266 494 49 266 495 minecraft:quartz_block
fill 49 266 502 49 266 503 minecraft:quartz_block
fill 50 266 465 87 266 465 minecraft:quartz_block
fill 50 266 503 88 266 503 minecraft:quartz_block
fill 51 266 464 56 267 464 minecraft:quartz_block
fill 56 266 504 61 267 504 minecraft:quartz_block
fill 59 266 464 64 267 464 minecraft:quartz_block
fill 64 266 504 69 267 504 minecraft:quartz_block
fill 67 266 464 72 267 464 minecraft:quartz_block
fill 72 266 504 77 267 504 minecraft:quartz_block
fill 75 266 464 80 267 464 minecraft:quartz_block
fill 80 266 504 85 267 504 minecraft:quartz_block
fill 81 266 469 83 266 469 minecraft:black_concrete
fill 83 266 464 88 267 464 minecraft:quartz_block
fill 83 266 471 83 266 475 minecraft:black_concrete
fill 84 266 476 84 266 482 minecraft:quartz_block
fill 85 266 475 86 266 481 minecraft:quartz_block
setblock 86 266 474 minecraft:quartz_block
setblock 87 266 466 minecraft:quartz_block
fill 87 266 468 88 266 468 minecraft:quartz_block
fill 87 266 477 87 266 502 minecraft:quartz_block
fill 88 266 477 88 267 480 minecraft:quartz_block
fill 88 266 483 88 267 488 minecraft:quartz_block
fill 88 266 491 88 267 496 minecraft:quartz_block
fill 88 266 499 88 267 502 minecraft:quartz_block
fill 88 266 504 88 267 504 minecraft:quartz_block
fill 48 267 472 48 267 477 minecraft:quartz_block
fill 48 267 480 48 267 485 minecraft:quartz_block
fill 48 267 488 48 267 493 minecraft:quartz_block
fill 48 267 496 48 267 501 minecraft:quartz_block
fill 83 267 473 83 267 479 minecraft:black_concrete
fill 84 267 480 87 267 485 minecraft:quartz_block
fill 85 267 486 87 268 486 minecraft:quartz_block
setblock 87 267 479 minecraft:quartz_block
fill 88 267 467 88 267 470 minecraft:quartz_block
setblock 88 267 503 minecraft:quartz_block
fill 83 268 478 83 268 483 minecraft:black_concrete
fill 84 268 484 84 268 490 minecraft:quartz_block
fill 85 268 484 88 268 485 minecraft:quartz_block
fill 85 268 487 87 268 490 minecraft:quartz_block
fill 87 268 491 88 269 491 minecraft:quartz_block
fill 88 268 486 88 268 488 minecraft:quartz_block
fill 83 269 482 83 269 487 minecraft:black_concrete
fill 84 269 488 86 269 495 minecraft:quartz_block
fill 86 269 496 88 270 496 minecraft:quartz_block
fill 87 269 489 87 269 490 minecraft:quartz_block
fill 87 269 492 88 269 495 minecraft:quartz_block
fill 87 269 497 87 270 497 minecraft:quartz_block
fill 47 270 468 47 273 468 minecraft:sea_lantern
fill 47 270 476 47 273 476 minecraft:sea_lantern
fill 47 270 484 47 273 484 minecraft:sea_lantern
fill 47 270 492 47 273 492 minecraft:sea_lantern
fill 47 270 500 47 273 500 minecraft:sea_lantern
fill 50 270 505 50 273 505 minecraft:sea_lantern
fill 54 270 463 54 273 463 minecraft:sea_lantern
fill 58 270 505 58 273 505 minecraft:sea_lantern
fill 62 270 463 62 273 463 minecraft:sea_lantern
fill 66 270 505 66 273 505 minecraft:sea_lantern
fill 70 270 463 70 273 463 minecraft:sea_lantern
fill 74 270 505 74 273 505 minecraft:sea_lantern
fill 78 270 463 78 273 463 minecraft:sea_lantern
fill 82 270 505 82 273 505 minecraft:sea_lantern
fill 83 270 486 83 270 491 minecraft:black_concrete
fill 83 270 500 88 270 500 minecraft:quartz_block
fill 84 270 492 84 270 499 minecraft:quartz_block
fill 84 270 501 88 271 502 minecraft:quartz_block
fill 85 270 493 85 270 499 minecraft:quartz_block
fill 85 270 503 88 271 503 minecraft:quartz_block
fill 86 270 463 86 273 463 minecraft:sea_lantern
fill 86 270 493 86 270 495 minecraft:quartz_block
fill 86 270 497 86 270 499 minecraft:quartz_block
fill 87 270 494 88 270 495 minecraft:quartz_block
fill 87 270 498 87 270 499 minecraft:quartz_block
setblock 88 270 499 minecraft:quartz_block
fill 88 270 504 88 271 504 minecraft:quartz_block
fill 89 270 468 89 273 468 minecraft:sea_lantern
fill 89 270 476 89 273 476 minecraft:sea_lantern
fill 89 270 484 89 273 484 minecraft:sea_lantern
fill 89 270 492 89 273 492 minecraft:sea_lantern
fill 89 270 500 89 273 500 minecraft:sea_lantern
setblock 50 271 466 minecraft:light[level=14]
setblock 50 271 474 minecraft:light[level=14]
setblock 50 271 482 minecraft:light[level=14]
setblock 50 271 490 minecraft:light[level=14]
setblock 50 271 498 minecraft:light[level=14]
setblock 58 271 466 minecraft:light[level=14]
setblock 58 271 474 minecraft:light[level=14]
setblock 58 271 482 minecraft:light[level=14]
setblock 58 271 490 minecraft:light[level=14]
setblock 58 271 498 minecraft:light[level=14]
setblock 66 271 466 minecraft:light[level=14]
setblock 66 271 474 minecraft:light[level=14]
setblock 66 271 490 minecraft:light[level=14]
setblock 66 271 498 minecraft:light[level=14]
setblock 74 271 466 minecraft:light[level=14]
setblock 74 271 474 minecraft:light[level=14]
setblock 74 271 482 minecraft:light[level=14]
setblock 74 271 490 minecraft:light[level=14]
setblock 74 271 498 minecraft:light[level=14]
fill 77 271 500 83 271 501 minecraft:quartz_block
fill 78 271 502 83 271 503 minecraft:quartz_block
fill 80 271 504 85 271 504 minecraft:quartz_block
setblock 82 271 466 minecraft:light[level=14]
setblock 82 271 474 minecraft:light[level=14]
setblock 82 271 482 minecraft:light[level=14]
setblock 82 271 490 minecraft:light[level=14]
setblock 82 271 498 minecraft:light[level=14]
fill 83 271 489 83 271 496 minecraft:black_concrete
fill 84 271 498 84 271 500 minecraft:quartz_block
setblock 84 271 503 minecraft:quartz_block
fill 85 271 499 85 271 500 minecraft:quartz_block
setblock 86 271 500 minecraft:quartz_block
fill 72 272 500 79 272 500 minecraft:quartz_block
fill 73 272 501 77 272 504 minecraft:quartz_block
fill 78 272 501 80 272 503 minecraft:quartz_block
fill 79 272 499 83 272 499 minecraft:black_concrete
fill 80 272 504 82 272 504 minecraft:quartz_block
fill 81 272 502 81 272 503 minecraft:quartz_block
fill 83 272 494 83 272 498 minecraft:black_concrete
fill 68 273 500 69 273 504 minecraft:quartz_block
fill 70 273 500 74 273 503 minecraft:quartz_block
fill 72 273 504 76 273 504 minecraft:quartz_block
fill 75 273 499 82 273 499 minecraft:black_concrete
fill 75 273 502 75 273 503 minecraft:quartz_block
fill 47 274 468 47 283 468 minecraft:white_concrete
fill 47 274 476 47 283 476 minecraft:white_concrete
fill 47 274 484 47 283 484 minecraft:white_concrete
fill 47 274 492 47 283 492 minecraft:white_concrete
fill 47 274 500 47 283 500 minecraft:white_concrete
fill 50 274 505 50 283 505 minecraft:white_concrete
fill 54 274 463 54 283 463 minecraft:white_concrete
fill 58 274 505 58 283 505 minecraft:white_concrete
fill 62 274 463 62 283 463 minecraft:white_concrete
fill 66 274 505 66 283 505 minecraft:white_concrete
fill 70 274 463 70 283 463 minecraft:white_concrete
fill 74 274 505 74 283 505 minecraft:white_concrete
fill 78 274 463 78 283 463 minecraft:white_concrete
fill 82 274 505 82 283 505 minecraft:white_concrete
fill 86 274 463 86 283 463 minecraft:white_concrete
fill 89 274 468 89 283 468 minecraft:white_concrete
fill 89 274 476 89 283 476 minecraft:white_concrete
fill 89 274 484 89 283 484 minecraft:white_concrete
fill 89 274 492 89 283 492 minecraft:white_concrete
fill 89 274 500 89 283 500 minecraft:white_concrete
fill 48 279 464 48 280 466 minecraft:quartz_block
fill 48 279 467 48 280 469 minecraft:white_concrete
fill 48 279 470 48 280 472 minecraft:quartz_block
fill 48 279 473 48 280 475 minecraft:white_concrete
fill 48 279 476 48 280 478 minecraft:quartz_block
fill 48 279 479 48 280 481 minecraft:white_concrete
fill 48 279 482 48 280 484 minecraft:quartz_block
fill 48 279 485 48 280 487 minecraft:white_concrete
fill 48 279 488 48 280 490 minecraft:quartz_block
fill 48 279 491 48 280 493 minecraft:white_concrete
fill 48 279 494 48 280 496 minecraft:quartz_block
fill 48 279 497 48 280 499 minecraft:white_concrete
fill 48 279 500 48 280 502 minecraft:quartz_block
fill 48 279 503 48 280 504 minecraft:white_concrete
fill 49 279 464 51 280 466 minecraft:white_concrete
fill 49 279 467 51 280 469 minecraft:quartz_block
fill 49 279 470 51 280 472 minecraft:white_concrete
fill 49 279 473 51 280 475 minecraft:quartz_block
fill 49 279 476 51 280 478 minecraft:white_concrete
fill 49 279 479 51 280 481 minecraft:quartz_block
fill 49 279 482 51 280 484 minecraft:white_concrete
fill 49 279 485 51 280 487 minecraft:quartz_block
fill 49 279 488 51 280 490 minecraft:white_concrete
fill 49 279 491 51 280 493 minecraft:quartz_block
fill 49 279 494 51 280 496 minecraft:white_concrete
fill 49 279 497 51 280 499 minecraft:quartz_block
fill 49 279 500 51 280 502 minecraft:white_concrete
fill 49 279 503 51 280 504 minecraft:quartz_block
fill 52 279 464 54 280 466 minecraft:quartz_block
fill 52 279 467 54 280 469 minecraft:white_concrete
fill 52 279 470 54 280 472 minecraft:quartz_block
fill 52 279 473 54 280 475 minecraft:white_concrete
fill 52 279 476 54 280 478 minecraft:quartz_block
fill 52 279 479 54 280 481 minecraft:white_concrete
fill 52 279 482 54 280 484 minecraft:quartz_block
fill 52 279 485 54 280 487 minecraft:white_concrete
fill 52 279 488 54 280 490 minecraft:quartz_block
fill 52 279 491 54 280 493 minecraft:white_concrete
fill 52 279 494 54 280 496 minecraft:quartz_block
fill 52 279 497 54 280 499 minecraft:white_concrete
fill 52 279 500 54 280 502 minecraft:quartz_block
fill 52 279 503 54 280 504 minecraft:white_concrete
fill 55 279 464 57 280 466 minecraft:white_concrete
fill 55 279 467 57 280 469 minecraft:quartz_block
fill 55 279 470 57 280 472 minecraft:white_concrete
fill 55 279 473 57 280 475 minecraft:quartz_block
fill 55 279 476 57 280 478 minecraft:white_concrete
fill 55 279 479 57 280 481 minecraft:quartz_block
fill 55 279 482 57 280 484 minecraft:white_concrete
fill 55 279 485 57 280 487 minecraft:quartz_block
fill 55 279 488 57 280 490 minecraft:white_concrete
fill 55 279 491 57 280 493 minecraft:quartz_block
fill 55 279 494 57 280 496 minecraft:white_concrete
fill 55 279 497 57 280 499 minecraft:quartz_block
fill 55 279 500 57 280 502 minecraft:white_concrete
fill 55 279 503 57 280 504 minecraft:quartz_block
fill 58 279 464 60 280 466 minecraft:quartz_block
fill 58 279 467 60 280 469 minecraft:white_concrete
fill 58 279 470 60 280 472 minecraft:quartz_block
fill 58 279 473 60 280 475 minecraft:white_concrete
fill 58 279 476 60 280 478 minecraft:quartz_block
fill 58 279 479 60 280 481 minecraft:white_concrete
fill 58 279 482 60 280 484 minecraft:quartz_block
fill 58 279 485 60 280 487 minecraft:white_concrete
fill 58 279 488 60 280 490 minecraft:quartz_block
fill 58 279 491 60 280 493 minecraft:white_concrete
fill 58 279 494 60 280 496 minecraft:quartz_block
fill 58 279 497 60 280 499 minecraft:white_concrete
fill 58 279 500 60 280 502 minecraft:quartz_block
fill 58 279 503 60 280 504 minecraft:white_concrete
fill 61 279 464 63 280 466 minecraft:white_concrete
fill 61 279 467 63 280 469 minecraft:quartz_block
fill 61 279 470 63 280 472 minecraft:white_concrete
fill 61 279 473 63 280 475 minecraft:quartz_block
fill 61 279 476 63 280 478 minecraft:white_concrete
fill 61 279 479 63 280 481 minecraft:quartz_block
fill 61 279 482 63 280 484 minecraft:white_concrete
fill 61 279 485 63 280 487 minecraft:quartz_block
fill 61 279 488 63 280 490 minecraft:white_concrete
fill 61 279 491 63 280 493 minecraft:quartz_block
fill 61 279 494 63 280 496 minecraft:white_concrete
fill 61 279 497 63 280 499 minecraft:quartz_block
fill 61 279 500 63 280 502 minecraft:white_concrete
fill 61 279 503 63 280 504 minecraft:quartz_block
fill 64 279 464 66 280 466 minecraft:quartz_block
fill 64 279 467 66 280 469 minecraft:white_concrete
fill 64 279 470 66 280 472 minecraft:quartz_block
fill 64 279 473 66 280 475 minecraft:white_concrete
fill 64 279 476 66 280 478 minecraft:quartz_block
fill 64 279 479 64 279 481 minecraft:white_concrete
fill 64 279 482 64 279 484 minecraft:quartz_block
fill 64 279 485 66 279 487 minecraft:white_concrete
fill 64 279 488 66 280 490 minecraft:quartz_block
fill 64 279 491 66 280 493 minecraft:white_concrete
fill 64 279 494 66 280 496 minecraft:quartz_block
fill 64 279 497 66 280 499 minecraft:white_concrete
fill 64 279 500 66 280 502 minecraft:quartz_block
fill 64 279 503 66 280 504 minecraft:white_concrete
fill 65 279 479 65 279 480 minecraft:white_concrete
setblock 65 279 484 minecraft:quartz_block
setblock 66 279 479 minecraft:white_concrete
fill 67 279 464 69 280 466 minecraft:white_concrete
fill 67 279 467 69 280 469 minecraft:quartz_block
fill 67 279 470 69 280 472 minecraft:white_concrete
fill 67 279 473 69 280 475 minecraft:quartz_block
fill 67 279 476 69 280 478 minecraft:white_concrete
fill 67 279 479 69 279 479 minecraft:quartz_block
fill 67 279 485 69 279 487 minecraft:quartz_block
fill 67 279 488 69 280 490 minecraft:white_concrete
fill 67 279 491 69 280 493 minecraft:quartz_block
fill 67 279 494 69 280 496 minecraft:white_concrete
fill 67 279 497 69 280 499 minecraft:quartz_block
fill 67 279 500 69 280 502 minecraft:white_concrete
fill 67 279 503 69 280 504 minecraft:quartz_block
setblock 69 279 480 minecraft:quartz_block
setblock 69 279 484 minecraft:white_concrete
fill 70 279 464 72 280 466 minecraft:quartz_block
fill 70 279 467 72 280 469 minecraft:white_concrete
fill 70 279 470 72 280 472 minecraft:quartz_block
fill 70 279 473 72 280 475 minecraft:white_concrete
fill 70 279 476 72 280 478 minecraft:quartz_block
fill 70 279 479 72 279 481 minecraft:white_concrete
fill 70 279 482 72 279 484 minecraft:quartz_block
fill 70 279 485 72 280 487 minecraft:white_concrete
fill 70 279 488 72 280 490 minecraft:quartz_block
fill 70 279 491 72 280 493 minecraft:white_concrete
fill 70 279 494 72 280 496 minecraft:quartz_block
fill 70 279 497 72 280 499 minecraft:white_concrete
fill 70 279 500 72 280 502 minecraft:quartz_block
fill 70 279 503 72 280 504 minecraft:white_concrete
fill 73 279 464 75 280 466 minecraft:white_concrete
fill 73 279 467 75 280 469 minecraft:quartz_block
fill 73 279 470 75 280 472 minecraft:white_concrete
fill 73 279 473 75 280 475 minecraft:quartz_block
fill 73 279 476 75 280 478 minecraft:white_concrete
fill 73 279 479 75 280 481 minecraft:quartz_block
fill 73 279 482 75 280 484 minecraft:white_concrete
fill 73 279 485 75 280 487 minecraft:quartz_block
fill 73 279 488 75 280 490 minecraft:white_concrete
fill 73 279 491 75 280 493 minecraft:quartz_block
fill 73 279 494 75 280 496 minecraft:white_concrete
fill 73 279 497 75 280 499 minecraft:quartz_block
fill 73 279 500 75 280 502 minecraft:white_concrete
fill 73 279 503 75 280 504 minecraft:quartz_block
fill 76 279 464 78 280 466 minecraft:quartz_block
fill 76 279 467 78 280 469 minecraft:white_concrete
fill 76 279 470 78 280 472 minecraft:quartz_block
fill 76 279 473 78 280 475 minecraft:white_concrete
fill 76 279 476 78 280 478 minecraft:quartz_block
fill 76 279 479 78 280 481 minecraft:white_concrete
fill 76 279 482 78 280 484 minecraft:quartz_block
fill 76 279 485 78 280 487 minecraft:white_concrete
fill 76 279 488 78 280 490 minecraft:quartz_block
fill 76 279 491 78 280 493 minecraft:white_concrete
fill 76 279 494 78 280 496 minecraft:quartz_block
fill 76 279 497 78 280 499 minecraft:white_concrete
fill 76 279 500 78 280 502 minecraft:quartz_block
fill 76 279 503 78 280 504 minecraft:white_concrete
fill 79 279 464 81 280 466 minecraft:white_concrete
fill 79 279 467 81 280 469 minecraft:quartz_block
fill 79 279 470 81 280 472 minecraft:white_concrete
fill 79 279 473 81 280 475 minecraft:quartz_block
fill 79 279 476 81 280 478 minecraft:white_concrete
fill 79 279 479 81 280 481 minecraft:quartz_block
fill 79 279 482 81 280 484 minecraft:white_concrete
fill 79 279 485 81 280 487 minecraft:quartz_block
fill 79 279 488 81 280 490 minecraft:white_concrete
fill 79 279 491 81 280 493 minecraft:quartz_block
fill 79 279 494 81 280 496 minecraft:white_concrete
fill 79 279 497 81 280 499 minecraft:quartz_block
fill 79 279 500 81 280 502 minecraft:white_concrete
fill 79 279 503 81 280 504 minecraft:quartz_block
fill 82 279 464 84 280 466 minecraft:quartz_block
fill 82 279 467 84 280 469 minecraft:white_concrete
fill 82 279 470 84 280 472 minecraft:quartz_block
fill 82 279 473 84 280 475 minecraft:white_concrete
fill 82 279 476 84 280 478 minecraft:quartz_block
fill 82 279 479 84 280 481 minecraft:white_concrete
fill 82 279 482 84 280 484 minecraft:quartz_block
fill 82 279 485 84 280 487 minecraft:white_concrete
fill 82 279 488 84 280 490 minecraft:quartz_block
fill 82 279 491 84 280 493 minecraft:white_concrete
fill 82 279 494 84 280 496 minecraft:quartz_block
fill 82 279 497 84 280 499 minecraft:white_concrete
fill 82 279 500 84 280 502 minecraft:quartz_block
fill 82 279 503 84 280 504 minecraft:white_concrete
fill 85 279 464 87 280 466 minecraft:white_concrete
fill 85 279 467 87 280 469 minecraft:quartz_block
fill 85 279 470 87 280 472 minecraft:white_concrete
fill 85 279 473 87 280 475 minecraft:quartz_block
fill 85 279 476 87 280 478 minecraft:white_concrete
fill 85 279 479 87 280 481 minecraft:quartz_block
fill 85 279 482 87 280 484 minecraft:white_concrete
fill 85 279 485 87 280 487 minecraft:quartz_block
fill 85 279 488 87 280 490 minecraft:white_concrete
fill 85 279 491 87 280 493 minecraft:quartz_block
fill 85 279 494 87 280 496 minecraft:white_concrete
fill 85 279 497 87 280 499 minecraft:quartz_block
fill 85 279 500 87 280 502 minecraft:white_concrete
fill 85 279 503 87 280 504 minecraft:quartz_block
fill 88 279 464 88 280 466 minecraft:quartz_block
fill 88 279 467 88 280 469 minecraft:white_concrete
fill 88 279 470 88 280 472 minecraft:quartz_block
fill 88 279 473 88 280 475 minecraft:white_concrete
fill 88 279 476 88 280 478 minecraft:quartz_block
fill 88 279 479 88 280 481 minecraft:white_concrete
fill 88 279 482 88 280 484 minecraft:quartz_block
fill 88 279 485 88 280 487 minecraft:white_concrete
fill 88 279 488 88 280 490 minecraft:quartz_block
fill 88 279 491 88 280 493 minecraft:white_concrete
fill 88 279 494 88 280 496 minecraft:quartz_block
fill 88 279 497 88 280 499 minecraft:white_concrete
fill 88 279 500 88 280 502 minecraft:quartz_block
schedule function dropper:buildpart/109_3 1t
