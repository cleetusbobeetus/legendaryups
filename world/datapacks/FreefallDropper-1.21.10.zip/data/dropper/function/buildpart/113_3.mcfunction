fill 274 60 475 274 61 475 minecraft:brown_terracotta
setblock 274 60 477 minecraft:brown_terracotta
setblock 274 60 478 minecraft:bone_block
fill 274 60 479 274 61 479 minecraft:brown_terracotta
fill 274 60 481 274 61 481 minecraft:brown_terracotta
setblock 274 60 503 minecraft:bone_block
fill 274 60 504 274 61 504 minecraft:brown_terracotta
fill 275 60 465 275 60 466 minecraft:brown_terracotta
setblock 275 60 467 minecraft:bone_block
fill 275 60 468 275 61 470 minecraft:brown_terracotta
setblock 275 60 472 minecraft:bone_block
fill 275 60 473 275 61 473 minecraft:brown_terracotta
setblock 275 60 477 minecraft:bone_block
fill 275 60 478 275 61 478 minecraft:brown_terracotta
setblock 275 60 482 minecraft:bone_block
fill 275 60 483 275 61 484 minecraft:brown_terracotta
fill 275 60 499 275 60 501 minecraft:brown_terracotta
setblock 275 60 502 minecraft:bone_block
fill 275 60 503 275 61 503 minecraft:brown_terracotta
setblock 276 60 465 minecraft:brown_terracotta
setblock 276 60 466 minecraft:bone_block
fill 276 60 467 276 61 467 minecraft:brown_terracotta
setblock 276 60 471 minecraft:bone_block
fill 276 60 472 276 61 472 minecraft:brown_terracotta
setblock 276 60 476 minecraft:bone_block
fill 276 60 477 276 61 477 minecraft:brown_terracotta
setblock 276 60 481 minecraft:bone_block
fill 276 60 482 276 61 482 minecraft:brown_terracotta
setblock 276 60 485 minecraft:brown_terracotta
setblock 276 60 486 minecraft:bone_block
fill 276 60 487 276 61 487 minecraft:brown_terracotta
setblock 276 60 495 minecraft:brown_terracotta
setblock 276 60 496 minecraft:bone_block
fill 276 60 497 276 60 500 minecraft:brown_terracotta
setblock 276 60 501 minecraft:bone_block
fill 276 60 502 276 61 502 minecraft:brown_terracotta
setblock 236 61 465 minecraft:bone_block
setblock 236 61 466 minecraft:brown_terracotta
setblock 236 61 470 minecraft:bone_block
setblock 236 61 471 minecraft:brown_terracotta
setblock 236 61 475 minecraft:bone_block
setblock 236 61 476 minecraft:brown_terracotta
setblock 236 61 480 minecraft:bone_block
setblock 236 61 481 minecraft:brown_terracotta
setblock 236 61 485 minecraft:bone_block
fill 236 61 486 236 61 488 minecraft:brown_terracotta
setblock 236 61 492 minecraft:brown_terracotta
setblock 236 61 495 minecraft:bone_block
setblock 236 61 496 minecraft:brown_terracotta
setblock 236 61 500 minecraft:bone_block
setblock 236 61 501 minecraft:brown_terracotta
setblock 237 61 464 minecraft:bone_block
setblock 237 61 465 minecraft:brown_terracotta
setblock 237 61 468 minecraft:brown_terracotta
setblock 237 61 469 minecraft:bone_block
setblock 237 61 470 minecraft:brown_terracotta
setblock 237 61 474 minecraft:bone_block
setblock 237 61 475 minecraft:brown_terracotta
setblock 237 61 479 minecraft:bone_block
fill 237 61 480 238 61 480 minecraft:brown_terracotta
setblock 237 61 484 minecraft:bone_block
setblock 237 61 485 minecraft:brown_terracotta
setblock 237 61 495 minecraft:brown_terracotta
setblock 237 61 499 minecraft:bone_block
setblock 237 61 500 minecraft:brown_terracotta
setblock 237 61 504 minecraft:bone_block
setblock 238 61 464 minecraft:brown_terracotta
setblock 238 61 479 minecraft:brown_terracotta
setblock 238 61 498 minecraft:bone_block
setblock 238 61 499 minecraft:brown_terracotta
setblock 238 61 503 minecraft:bone_block
setblock 238 61 504 minecraft:brown_terracotta
setblock 239 61 502 minecraft:bone_block
setblock 239 61 503 minecraft:brown_terracotta
setblock 240 61 501 minecraft:bone_block
setblock 240 61 502 minecraft:brown_terracotta
setblock 241 61 465 minecraft:bone_block
setblock 241 61 501 minecraft:brown_terracotta
setblock 242 61 464 minecraft:bone_block
setblock 242 61 504 minecraft:bone_block
setblock 243 61 464 minecraft:brown_terracotta
setblock 243 61 503 minecraft:bone_block
setblock 243 61 504 minecraft:brown_terracotta
setblock 244 61 502 minecraft:bone_block
setblock 244 61 503 minecraft:brown_terracotta
setblock 245 61 464 minecraft:brown_terracotta
fill 245 61 502 246 61 502 minecraft:brown_terracotta
setblock 247 61 504 minecraft:bone_block
setblock 248 61 503 minecraft:bone_block
setblock 248 61 504 minecraft:brown_terracotta
fill 249 61 503 252 61 503 minecraft:brown_terracotta
fill 251 61 502 253 61 502 minecraft:brown_terracotta
setblock 251 61 504 minecraft:brown_terracotta
setblock 252 61 504 minecraft:bone_block
fill 253 61 464 256 61 464 minecraft:brown_terracotta
setblock 253 61 503 minecraft:bone_block
setblock 253 61 504 minecraft:brown_terracotta
setblock 254 61 502 minecraft:bone_block
setblock 254 61 503 minecraft:brown_terracotta
setblock 255 61 502 minecraft:brown_terracotta
setblock 257 61 464 minecraft:bone_block
fill 257 61 502 258 61 502 minecraft:brown_terracotta
setblock 257 61 504 minecraft:bone_block
setblock 258 61 464 minecraft:brown_terracotta
setblock 258 61 503 minecraft:bone_block
setblock 258 61 504 minecraft:brown_terracotta
setblock 259 61 502 minecraft:bone_block
setblock 259 61 503 minecraft:brown_terracotta
setblock 260 61 502 minecraft:brown_terracotta
setblock 262 61 464 minecraft:bone_block
setblock 262 61 504 minecraft:bone_block
setblock 263 61 504 minecraft:brown_terracotta
fill 270 61 464 271 61 464 minecraft:brown_terracotta
setblock 271 61 504 minecraft:brown_terracotta
setblock 272 61 464 minecraft:bone_block
setblock 272 61 504 minecraft:bone_block
fill 273 61 464 273 61 465 minecraft:brown_terracotta
setblock 273 61 503 minecraft:bone_block
setblock 273 61 504 minecraft:brown_terracotta
fill 274 61 465 275 61 465 minecraft:brown_terracotta
setblock 274 61 474 minecraft:brown_terracotta
setblock 274 61 477 minecraft:bone_block
setblock 274 61 478 minecraft:brown_terracotta
setblock 274 61 482 minecraft:bone_block
setblock 274 61 483 minecraft:brown_terracotta
setblock 274 61 503 minecraft:brown_terracotta
setblock 275 61 466 minecraft:bone_block
setblock 275 61 467 minecraft:brown_terracotta
setblock 275 61 471 minecraft:bone_block
setblock 275 61 472 minecraft:brown_terracotta
setblock 275 61 476 minecraft:bone_block
setblock 275 61 477 minecraft:brown_terracotta
setblock 275 61 481 minecraft:bone_block
setblock 275 61 482 minecraft:brown_terracotta
setblock 275 61 485 minecraft:brown_terracotta
fill 275 61 498 275 61 500 minecraft:brown_terracotta
setblock 275 61 501 minecraft:bone_block
setblock 275 61 502 minecraft:brown_terracotta
setblock 276 61 465 minecraft:bone_block
setblock 276 61 466 minecraft:brown_terracotta
setblock 276 61 470 minecraft:bone_block
setblock 276 61 471 minecraft:brown_terracotta
setblock 276 61 475 minecraft:bone_block
setblock 276 61 476 minecraft:brown_terracotta
setblock 276 61 480 minecraft:bone_block
setblock 276 61 481 minecraft:brown_terracotta
setblock 276 61 485 minecraft:bone_block
setblock 276 61 486 minecraft:brown_terracotta
setblock 276 61 488 minecraft:brown_terracotta
setblock 276 61 495 minecraft:bone_block
fill 276 61 496 276 61 499 minecraft:brown_terracotta
setblock 276 61 500 minecraft:bone_block
setblock 276 61 501 minecraft:brown_terracotta
setblock 238 64 466 minecraft:light[level=12]
setblock 238 64 474 minecraft:light[level=12]
setblock 238 64 482 minecraft:light[level=12]
setblock 238 64 490 minecraft:light[level=12]
setblock 238 64 498 minecraft:light[level=12]
setblock 246 64 466 minecraft:light[level=12]
setblock 246 64 474 minecraft:light[level=12]
setblock 246 64 482 minecraft:light[level=12]
setblock 246 64 490 minecraft:light[level=12]
setblock 246 64 498 minecraft:light[level=12]
setblock 254 64 466 minecraft:light[level=12]
setblock 254 64 474 minecraft:light[level=12]
setblock 254 64 482 minecraft:light[level=12]
setblock 254 64 490 minecraft:light[level=12]
setblock 254 64 498 minecraft:light[level=12]
setblock 262 64 466 minecraft:light[level=12]
setblock 262 64 474 minecraft:light[level=12]
setblock 262 64 482 minecraft:light[level=12]
setblock 262 64 490 minecraft:light[level=12]
setblock 262 64 498 minecraft:light[level=12]
setblock 270 64 466 minecraft:light[level=12]
setblock 270 64 474 minecraft:light[level=12]
setblock 270 64 482 minecraft:light[level=12]
setblock 270 64 490 minecraft:light[level=12]
setblock 270 64 498 minecraft:light[level=12]
fill 250 66 480 252 66 482 minecraft:redstone_block
fill 251 66 490 253 66 492 minecraft:redstone_block
fill 256 66 485 258 66 487 minecraft:redstone_block
fill 235 67 463 235 82 477 minecraft:black_concrete
fill 235 67 478 249 67 494 minecraft:bone_block
fill 235 67 495 235 81 505 minecraft:black_concrete
fill 236 67 476 268 67 477 minecraft:bone_block
fill 236 67 495 268 67 496 minecraft:bone_block
fill 236 67 505 251 81 505 minecraft:black_concrete
fill 237 67 475 267 67 475 minecraft:bone_block
fill 237 67 497 267 67 497 minecraft:bone_block
fill 238 67 474 266 67 474 minecraft:bone_block
fill 238 67 498 266 67 498 minecraft:bone_block
fill 239 67 473 265 67 473 minecraft:bone_block
fill 239 67 499 265 67 499 minecraft:bone_block
fill 240 67 472 264 67 472 minecraft:bone_block
fill 240 67 500 264 67 500 minecraft:bone_block
fill 241 67 471 263 67 471 minecraft:bone_block
fill 241 67 501 263 67 501 minecraft:bone_block
fill 242 67 470 262 67 470 minecraft:bone_block
fill 242 67 502 262 67 502 minecraft:bone_block
fill 244 67 469 260 67 469 minecraft:bone_block
fill 244 67 503 260 67 503 minecraft:bone_block
fill 246 67 468 258 67 468 minecraft:bone_block
fill 246 67 504 258 67 504 minecraft:bone_block
fill 250 67 478 269 67 479 minecraft:bone_block
fill 250 67 483 250 67 494 minecraft:bone_block
fill 251 67 483 270 67 484 minecraft:bone_block
fill 251 67 488 270 67 489 minecraft:bone_block
fill 251 67 493 269 67 494 minecraft:bone_block
fill 252 67 467 252 74 467 minecraft:bone_block
fill 252 67 505 252 74 505 minecraft:bone_block
fill 253 67 480 270 67 482 minecraft:bone_block
fill 253 67 505 277 81 505 minecraft:black_concrete
fill 254 67 485 255 67 487 minecraft:bone_block
fill 254 67 490 270 67 492 minecraft:bone_block
fill 259 67 485 270 67 487 minecraft:bone_block
fill 271 67 486 271 74 486 minecraft:bone_block
fill 235 68 478 237 74 482 minecraft:bone_block
fill 235 68 483 236 74 483 minecraft:soul_soil
fill 235 68 484 235 74 491 minecraft:bone_block
fill 235 68 492 235 74 492 minecraft:soul_soil
fill 235 68 493 240 73 494 minecraft:bone_block
fill 236 68 464 236 68 475 minecraft:black_concrete
fill 236 68 476 236 74 477 minecraft:bone_block
fill 236 68 484 236 74 489 minecraft:bone_block
fill 236 68 490 236 74 490 minecraft:soul_soil
fill 236 68 491 241 73 492 minecraft:bone_block
fill 236 68 495 239 74 496 minecraft:bone_block
fill 236 68 497 236 68 504 minecraft:black_concrete
fill 237 68 464 237 68 474 minecraft:black_concrete
fill 237 68 475 248 72 475 minecraft:bone_block
fill 237 68 476 239 74 476 minecraft:soul_soil
fill 237 68 477 242 73 477 minecraft:bone_block
fill 237 68 483 237 74 488 minecraft:bone_block
fill 237 68 489 237 74 489 minecraft:soul_soil
fill 237 68 490 242 72 490 minecraft:bone_block
fill 237 68 497 244 73 497 minecraft:bone_block
fill 237 68 498 237 68 504 minecraft:black_concrete
fill 238 68 464 238 68 473 minecraft:black_concrete
fill 238 68 474 247 73 474 minecraft:bone_block
fill 238 68 478 245 71 481 minecraft:bone_block
fill 238 68 482 239 73 482 minecraft:soul_soil
fill 238 68 483 239 73 487 minecraft:bone_block
fill 238 68 488 238 73 488 minecraft:soul_soil
fill 238 68 489 243 71 489 minecraft:bone_block
fill 238 68 498 238 74 498 minecraft:bone_block
fill 238 68 499 238 68 504 minecraft:black_concrete
fill 239 68 464 239 68 472 minecraft:black_concrete
fill 239 68 473 246 73 473 minecraft:bone_block
fill 239 68 488 247 70 488 minecraft:bone_block
fill 239 68 498 239 74 499 minecraft:soul_soil
fill 239 68 500 239 68 504 minecraft:black_concrete
fill 240 68 464 240 68 471 minecraft:black_concrete
fill 240 68 472 252 73 472 minecraft:bone_block
fill 240 68 476 249 72 476 minecraft:bone_block
fill 240 68 482 244 71 486 minecraft:bone_block
fill 240 68 487 240 73 487 minecraft:soul_soil
fill 240 68 495 240 74 495 minecraft:soul_soil
fill 240 68 496 244 73 496 minecraft:bone_block
fill 240 68 498 244 74 500 minecraft:bone_block
fill 240 68 501 240 68 504 minecraft:black_concrete
fill 241 68 464 241 68 470 minecraft:black_concrete
fill 241 68 471 242 74 471 minecraft:bone_block
fill 241 68 487 247 70 487 minecraft:bone_block
fill 241 68 493 241 73 493 minecraft:soul_soil
fill 241 68 494 252 71 495 minecraft:bone_block
fill 241 68 501 259 74 501 minecraft:bone_block
fill 241 68 502 241 68 504 minecraft:black_concrete
fill 242 68 464 243 68 469 minecraft:black_concrete
fill 242 68 470 251 74 470 minecraft:bone_block
fill 242 68 491 242 72 491 minecraft:soul_soil
fill 242 68 492 249 70 493 minecraft:bone_block
fill 242 68 502 251 74 502 minecraft:bone_block
fill 242 68 503 243 68 504 minecraft:black_concrete
fill 243 68 471 244 74 471 minecraft:soul_soil
fill 243 68 477 244 73 477 minecraft:soul_soil
fill 243 68 490 243 72 490 minecraft:soul_soil
fill 243 68 491 249 70 491 minecraft:bone_block
fill 244 68 464 245 68 468 minecraft:black_concrete
fill 244 68 469 250 74 469 minecraft:bone_block
fill 244 68 489 244 71 489 minecraft:soul_soil
fill 244 68 490 249 69 490 minecraft:bone_block
fill 244 68 503 245 74 503 minecraft:bone_block
fill 244 68 504 245 68 504 minecraft:black_concrete
fill 245 68 471 263 74 471 minecraft:bone_block
fill 245 68 477 263 71 477 minecraft:bone_block
fill 245 68 482 245 70 484 minecraft:bone_block
fill 245 68 485 245 70 485 minecraft:soul_soil
fill 245 68 486 247 69 486 minecraft:bone_block
fill 245 68 489 248 69 489 minecraft:bone_block
fill 245 68 496 245 73 500 minecraft:soul_soil
fill 246 68 464 251 68 467 minecraft:black_concrete
fill 246 68 468 249 74 468 minecraft:bone_block
fill 246 68 478 246 72 478 minecraft:soul_soil
fill 246 68 479 248 70 481 minecraft:bone_block
fill 246 68 482 246 70 482 minecraft:soul_soil
fill 246 68 483 247 70 485 minecraft:bone_block
fill 246 68 496 249 72 500 minecraft:bone_block
fill 246 68 503 246 74 504 minecraft:soul_soil
fill 247 68 473 247 73 473 minecraft:soul_soil
fill 247 68 478 250 71 478 minecraft:bone_block
fill 247 68 482 248 70 482 minecraft:bone_block
fill 247 68 503 252 74 504 minecraft:bone_block
fill 248 68 473 258 73 473 minecraft:bone_block
fill 248 68 474 248 73 474 minecraft:soul_soil
fill 248 68 483 248 69 483 minecraft:bone_block
fill 248 68 484 250 68 488 minecraft:shroomlight
fill 249 68 474 253 72 474 minecraft:bone_block
fill 249 68 475 249 72 475 minecraft:soul_soil
fill 249 68 479 249 68 483 minecraft:shroomlight
fill 249 68 489 255 69 489 minecraft:shroomlight
fill 250 68 468 250 74 468 minecraft:soul_soil
fill 250 68 475 253 72 475 minecraft:bone_block
fill 250 68 476 250 72 476 minecraft:soul_soil
fill 250 68 479 253 68 479 minecraft:shroomlight
fill 250 68 480 252 68 482 minecraft:black_concrete
fill 250 68 483 255 69 483 minecraft:shroomlight
fill 250 68 490 250 68 493 minecraft:shroomlight
fill 250 68 496 253 72 496 minecraft:bone_block
fill 250 68 497 250 72 498 minecraft:soul_soil
fill 250 68 499 250 73 500 minecraft:bone_block
fill 251 68 468 257 74 468 minecraft:bone_block
fill 251 68 469 251 74 469 minecraft:soul_soil
fill 251 68 476 258 72 476 minecraft:bone_block
fill 251 68 478 251 71 478 minecraft:soul_soil
fill 251 68 484 259 68 484 minecraft:shroomlight
fill 251 68 488 259 68 488 minecraft:shroomlight
fill 251 68 490 253 68 492 minecraft:black_concrete
fill 251 68 493 254 68 493 minecraft:shroomlight
fill 251 68 497 254 72 499 minecraft:bone_block
fill 251 68 500 251 73 500 minecraft:soul_soil
fill 252 68 464 276 68 466 minecraft:black_concrete
fill 252 68 469 257 74 469 minecraft:bone_block
fill 252 68 470 252 74 470 minecraft:soul_soil
fill 252 68 478 269 71 478 minecraft:bone_block
fill 252 68 500 264 73 500 minecraft:bone_block
fill 252 68 502 252 74 502 minecraft:soul_soil
fill 253 68 467 276 68 467 minecraft:black_concrete
fill 253 68 470 262 74 470 minecraft:bone_block
fill 253 68 472 253 73 472 minecraft:soul_soil
fill 253 68 480 253 68 482 minecraft:shroomlight
fill 253 68 494 253 71 494 minecraft:soul_soil
fill 253 68 495 259 71 495 minecraft:bone_block
fill 253 68 502 262 74 502 minecraft:bone_block
fill 253 68 503 253 74 503 minecraft:soul_soil
fill 253 68 504 253 74 504 minecraft:bone_block
fill 254 68 472 258 73 472 minecraft:bone_block
fill 254 68 474 254 72 475 minecraft:soul_soil
fill 254 68 479 261 70 481 minecraft:bone_block
fill 254 68 482 254 69 482 minecraft:shroomlight
fill 254 68 485 255 68 487 minecraft:shroomlight
fill 254 68 490 254 68 492 minecraft:shroomlight
fill 254 68 494 257 71 494 minecraft:bone_block
fill 254 68 496 254 72 496 minecraft:soul_soil
fill 254 68 503 260 74 503 minecraft:bone_block
fill 254 68 504 254 74 504 minecraft:soul_soil
fill 255 68 474 258 72 475 minecraft:bone_block
fill 255 68 482 260 69 482 minecraft:bone_block
fill 255 68 490 257 69 493 minecraft:bone_block
fill 255 68 496 264 72 496 minecraft:bone_block
fill 255 68 497 255 72 497 minecraft:soul_soil
fill 255 68 498 255 73 499 minecraft:bone_block
fill 255 68 504 258 74 504 minecraft:bone_block
fill 256 68 483 259 69 483 minecraft:bone_block
fill 256 68 485 258 68 487 minecraft:black_concrete
fill 256 68 489 267 69 489 minecraft:bone_block
fill 256 68 497 267 72 497 minecraft:bone_block
fill 256 68 498 256 73 498 minecraft:soul_soil
fill 256 68 499 256 73 499 minecraft:bone_block
fill 257 68 498 266 73 498 minecraft:bone_block
fill 257 68 499 257 73 499 minecraft:soul_soil
fill 258 68 468 258 74 469 minecraft:soul_soil
fill 258 68 490 258 70 490 minecraft:soul_soil
fill 258 68 491 269 71 493 minecraft:bone_block
fill 258 68 494 258 72 494 minecraft:soul_soil
fill 258 68 499 265 73 499 minecraft:bone_block
fill 259 68 468 276 68 468 minecraft:black_concrete
fill 259 68 469 260 74 469 minecraft:bone_block
fill 259 68 472 259 73 476 minecraft:soul_soil
fill 259 68 485 259 68 487 minecraft:shroomlight
fill 259 68 490 264 71 490 minecraft:bone_block
fill 259 68 494 269 72 494 minecraft:bone_block
fill 259 68 504 276 68 504 minecraft:black_concrete
fill 260 68 472 264 73 476 minecraft:bone_block
fill 260 68 483 260 71 483 minecraft:soul_soil
fill 260 68 484 263 71 488 minecraft:bone_block
fill 260 68 495 261 73 495 minecraft:soul_soil
fill 260 68 501 261 74 501 minecraft:soul_soil
fill 261 68 469 276 68 469 minecraft:black_concrete
fill 261 68 482 261 72 482 minecraft:soul_soil
fill 261 68 483 266 71 483 minecraft:bone_block
fill 261 68 503 276 68 503 minecraft:black_concrete
fill 262 68 479 262 72 480 minecraft:bone_block
fill 262 68 481 262 72 481 minecraft:soul_soil
fill 262 68 482 267 72 482 minecraft:bone_block
fill 262 68 495 268 73 495 minecraft:bone_block
fill 262 68 501 263 74 501 minecraft:bone_block
fill 263 68 470 276 68 470 minecraft:black_concrete
fill 263 68 479 263 73 479 minecraft:soul_soil
fill 263 68 480 268 73 481 minecraft:bone_block
fill 263 68 502 276 68 502 minecraft:black_concrete
fill 264 68 471 276 68 471 minecraft:black_concrete
fill 264 68 477 264 74 477 minecraft:soul_soil
fill 264 68 479 269 73 479 minecraft:bone_block
fill 264 68 484 265 73 484 minecraft:bone_block
fill 264 68 485 264 73 485 minecraft:soul_soil
fill 264 68 486 269 72 488 minecraft:bone_block
fill 264 68 501 276 68 501 minecraft:black_concrete
fill 265 68 472 276 68 472 minecraft:black_concrete
fill 265 68 473 265 74 474 minecraft:soul_soil
fill 265 68 475 267 74 477 minecraft:bone_block
fill 265 68 485 270 73 485 minecraft:bone_block
fill 265 68 490 266 73 490 minecraft:soul_soil
fill 265 68 496 267 74 496 minecraft:soul_soil
fill 265 68 500 276 68 500 minecraft:black_concrete
fill 266 68 473 276 68 473 minecraft:black_concrete
fill 266 68 474 266 74 474 minecraft:bone_block
fill 266 68 484 266 73 484 minecraft:soul_soil
fill 266 68 499 276 68 499 minecraft:black_concrete
fill 267 68 474 276 68 474 minecraft:black_concrete
fill 267 68 483 267 74 483 minecraft:soul_soil
fill 267 68 484 270 74 484 minecraft:bone_block
fill 267 68 490 270 74 490 minecraft:bone_block
fill 267 68 498 276 68 498 minecraft:black_concrete
fill 268 68 475 276 68 475 minecraft:black_concrete
fill 268 68 476 268 74 477 minecraft:bone_block
fill 268 68 482 268 74 482 minecraft:soul_soil
fill 268 68 483 270 74 483 minecraft:bone_block
fill 268 68 489 269 74 489 minecraft:soul_soil
fill 268 68 496 268 74 496 minecraft:bone_block
fill 268 68 497 276 68 497 minecraft:black_concrete
fill 269 68 476 276 68 477 minecraft:black_concrete
fill 269 68 480 269 74 480 minecraft:soul_soil
fill 269 68 481 270 74 482 minecraft:bone_block
fill 269 68 495 276 68 496 minecraft:black_concrete
fill 270 68 478 276 68 479 minecraft:black_concrete
fill 270 68 480 270 74 480 minecraft:bone_block
fill 270 68 486 270 74 487 minecraft:bone_block
fill 270 68 488 270 74 488 minecraft:soul_soil
fill 270 68 489 270 74 489 minecraft:bone_block
fill 270 68 491 270 74 492 minecraft:bone_block
fill 270 68 493 276 68 494 minecraft:black_concrete
fill 271 68 480 276 68 485 minecraft:black_concrete
fill 271 68 487 276 68 492 minecraft:black_concrete
fill 272 68 486 276 68 486 minecraft:black_concrete
fill 248 69 484 249 69 488 minecraft:shroomlight
fill 249 69 479 249 69 482 minecraft:bone_block
setblock 249 69 483 minecraft:shroomlight
fill 250 69 479 251 70 481 minecraft:bone_block
fill 250 69 482 253 69 482 minecraft:shroomlight
setblock 250 69 484 minecraft:shroomlight
setblock 250 69 488 minecraft:shroomlight
fill 250 69 490 254 69 490 minecraft:shroomlight
fill 250 69 491 251 70 493 minecraft:bone_block
fill 252 69 479 253 70 480 minecraft:bone_block
setblock 252 69 481 minecraft:soul_soil
setblock 252 69 491 minecraft:soul_soil
fill 252 69 492 254 70 493 minecraft:bone_block
fill 253 69 481 253 70 481 minecraft:bone_block
fill 253 69 491 254 70 491 minecraft:bone_block
fill 254 69 484 256 69 484 minecraft:shroomlight
fill 254 69 488 256 69 488 minecraft:shroomlight
fill 255 69 485 256 69 487 minecraft:shroomlight
fill 257 69 484 258 69 488 minecraft:bone_block
fill 259 69 484 259 70 486 minecraft:bone_block
fill 259 69 487 259 70 487 minecraft:soul_soil
fill 259 69 488 259 70 488 minecraft:bone_block
fill 244 70 490 248 70 490 minecraft:bone_block
fill 245 70 486 246 70 486 minecraft:bone_block
fill 245 70 489 247 70 489 minecraft:bone_block
fill 249 70 479 249 70 481 minecraft:bone_block
fill 255 70 491 257 70 493 minecraft:bone_block
fill 256 70 482 260 70 482 minecraft:bone_block
fill 256 70 490 257 70 490 minecraft:bone_block
fill 257 70 483 258 70 485 minecraft:bone_block
fill 257 70 487 258 70 489 minecraft:bone_block
setblock 258 70 486 minecraft:bone_block
fill 259 70 483 259 71 483 minecraft:bone_block
fill 259 70 489 267 71 489 minecraft:bone_block
fill 239 71 488 244 71 488 minecraft:bone_block
fill 241 71 487 244 71 487 minecraft:bone_block
fill 242 71 492 247 71 493 minecraft:bone_block
fill 243 71 491 246 71 491 minecraft:bone_block
fill 244 71 490 245 71 490 minecraft:bone_block
fill 245 71 482 245 71 483 minecraft:bone_block
setblock 245 71 489 minecraft:bone_block
fill 246 71 479 246 71 481 minecraft:bone_block
fill 247 71 479 247 71 480 minecraft:bone_block
fill 248 71 479 249 71 479 minecraft:bone_block
fill 248 71 493 249 71 493 minecraft:bone_block
fill 255 71 479 261 71 479 minecraft:bone_block
fill 255 71 493 257 71 493 minecraft:bone_block
fill 257 71 480 261 71 480 minecraft:bone_block
setblock 257 71 492 minecraft:bone_block
fill 258 71 481 261 71 481 minecraft:bone_block
fill 259 71 482 260 71 482 minecraft:bone_block
setblock 236 72 464 minecraft:bone_block
fill 236 72 465 236 72 468 minecraft:brown_terracotta
setblock 236 72 469 minecraft:bone_block
fill 236 72 470 236 75 470 minecraft:brown_terracotta
fill 236 72 497 236 72 498 minecraft:brown_terracotta
setblock 236 72 499 minecraft:bone_block
fill 236 72 500 236 72 503 minecraft:brown_terracotta
setblock 236 72 504 minecraft:bone_block
fill 237 72 464 238 73 464 minecraft:brown_terracotta
fill 237 72 504 239 72 504 minecraft:brown_terracotta
setblock 238 72 466 minecraft:light[level=12]
fill 238 72 478 243 72 481 minecraft:bone_block
fill 238 72 489 242 72 489 minecraft:bone_block
fill 239 72 488 242 72 488 minecraft:bone_block
fill 240 72 482 242 72 486 minecraft:bone_block
fill 241 72 487 242 72 487 minecraft:bone_block
fill 241 72 494 246 72 495 minecraft:bone_block
fill 242 72 492 244 72 493 minecraft:bone_block
setblock 243 72 482 minecraft:bone_block
setblock 243 72 491 minecraft:bone_block
fill 244 72 478 244 72 480 minecraft:bone_block
fill 245 72 477 245 72 479 minecraft:bone_block
setblock 245 72 493 minecraft:bone_block
setblock 246 72 466 minecraft:light[level=12]
fill 246 72 477 248 72 477 minecraft:bone_block
setblock 246 72 482 minecraft:light[level=12]
setblock 246 72 490 minecraft:light[level=12]
fill 247 72 464 250 72 464 minecraft:brown_terracotta
fill 247 72 495 248 72 495 minecraft:bone_block
setblock 251 72 464 minecraft:bone_block
fill 251 72 465 254 72 465 minecraft:brown_terracotta
fill 252 72 464 255 72 464 minecraft:brown_terracotta
setblock 254 72 466 minecraft:light[level=12]
setblock 254 72 482 minecraft:light[level=12]
setblock 254 72 490 minecraft:light[level=12]
setblock 256 72 464 minecraft:bone_block
fill 256 72 477 263 72 477 minecraft:bone_block
fill 256 72 495 259 72 495 minecraft:bone_block
fill 257 72 464 258 72 464 minecraft:brown_terracotta
fill 258 72 478 269 72 478 minecraft:bone_block
fill 259 72 479 261 72 479 minecraft:bone_block
fill 259 72 493 269 72 493 minecraft:bone_block
fill 260 72 480 261 72 480 minecraft:bone_block
fill 260 72 492 269 72 492 minecraft:bone_block
setblock 261 72 481 minecraft:bone_block
fill 261 72 490 264 72 491 minecraft:bone_block
setblock 262 72 466 minecraft:light[level=12]
fill 262 72 483 263 72 489 minecraft:bone_block
fill 263 72 464 265 72 464 minecraft:brown_terracotta
fill 264 72 483 266 73 483 minecraft:bone_block
fill 264 72 489 267 73 489 minecraft:bone_block
setblock 265 72 465 minecraft:bone_block
fill 265 72 491 269 73 491 minecraft:bone_block
setblock 266 72 464 minecraft:bone_block
fill 266 72 465 269 72 465 minecraft:brown_terracotta
fill 267 72 464 270 72 464 minecraft:brown_terracotta
fill 267 72 466 268 72 466 minecraft:brown_terracotta
fill 268 72 504 270 72 504 minecraft:brown_terracotta
setblock 269 72 466 minecraft:bone_block
setblock 270 72 465 minecraft:bone_block
fill 270 72 466 272 72 467 minecraft:brown_terracotta
setblock 270 72 474 minecraft:light[level=12]
setblock 270 72 498 minecraft:light[level=12]
setblock 271 72 464 minecraft:bone_block
fill 271 72 465 274 72 465 minecraft:brown_terracotta
setblock 271 72 504 minecraft:bone_block
fill 272 72 464 275 72 464 minecraft:brown_terracotta
fill 272 72 504 275 72 504 minecraft:brown_terracotta
setblock 273 72 466 minecraft:brown_terracotta
setblock 273 72 467 minecraft:bone_block
fill 273 72 468 276 72 468 minecraft:brown_terracotta
setblock 273 72 503 minecraft:brown_terracotta
setblock 274 72 466 minecraft:bone_block
fill 274 72 467 276 73 467 minecraft:brown_terracotta
fill 274 72 469 274 72 470 minecraft:brown_terracotta
setblock 275 72 465 minecraft:bone_block
fill 275 72 466 276 74 466 minecraft:brown_terracotta
setblock 275 72 469 minecraft:brown_terracotta
setblock 275 72 470 minecraft:bone_block
fill 275 72 471 276 73 472 minecraft:brown_terracotta
setblock 276 72 464 minecraft:bone_block
fill 276 72 465 276 75 465 minecraft:brown_terracotta
setblock 276 72 469 minecraft:bone_block
fill 276 72 470 276 75 470 minecraft:brown_terracotta
setblock 276 72 473 minecraft:brown_terracotta
fill 276 72 485 276 72 488 minecraft:brown_terracotta
setblock 276 72 489 minecraft:bone_block
fill 276 72 490 276 73 492 minecraft:brown_terracotta
fill 276 72 502 276 72 503 minecraft:brown_terracotta
setblock 276 72 504 minecraft:bone_block
fill 236 73 464 236 73 467 minecraft:brown_terracotta
setblock 236 73 468 minecraft:bone_block
fill 236 73 469 236 76 469 minecraft:brown_terracotta
setblock 236 73 497 minecraft:brown_terracotta
setblock 236 73 498 minecraft:bone_block
fill 236 73 499 236 73 502 minecraft:brown_terracotta
setblock 236 73 503 minecraft:bone_block
fill 236 73 504 238 73 504 minecraft:brown_terracotta
fill 237 73 475 247 73 475 minecraft:bone_block
fill 237 73 490 240 73 490 minecraft:bone_block
fill 238 73 478 241 73 481 minecraft:bone_block
fill 238 73 489 240 73 489 minecraft:bone_block
fill 239 73 488 240 73 488 minecraft:bone_block
fill 240 73 476 245 73 476 minecraft:bone_block
fill 240 73 482 240 73 485 minecraft:bone_block
fill 241 73 494 243 73 495 minecraft:bone_block
fill 242 73 478 242 73 479 minecraft:bone_block
setblock 242 73 493 minecraft:bone_block
setblock 243 73 478 minecraft:bone_block
setblock 244 73 495 minecraft:bone_block
fill 246 73 497 247 73 500 minecraft:bone_block
fill 247 73 464 249 73 464 minecraft:brown_terracotta
fill 248 73 498 249 73 500 minecraft:bone_block
fill 249 73 474 251 73 474 minecraft:bone_block
setblock 250 73 464 minecraft:bone_block
fill 250 73 465 253 73 465 minecraft:brown_terracotta
setblock 250 73 498 minecraft:soul_soil
fill 251 73 464 254 73 464 minecraft:brown_terracotta
fill 251 73 498 251 73 499 minecraft:bone_block
fill 252 73 499 254 73 499 minecraft:bone_block
setblock 253 73 474 minecraft:bone_block
fill 253 73 498 254 73 498 minecraft:bone_block
setblock 254 73 465 minecraft:bone_block
setblock 254 73 474 minecraft:soul_soil
setblock 255 73 464 minecraft:bone_block
fill 255 73 474 258 73 474 minecraft:bone_block
fill 256 73 464 257 75 464 minecraft:brown_terracotta
fill 257 73 475 258 73 475 minecraft:bone_block
fill 257 73 497 267 73 497 minecraft:bone_block
fill 259 73 496 264 73 496 minecraft:bone_block
fill 260 73 477 263 73 477 minecraft:bone_block
fill 261 73 478 269 73 478 minecraft:bone_block
fill 261 73 494 269 73 494 minecraft:bone_block
fill 262 73 464 264 73 464 minecraft:brown_terracotta
setblock 262 73 479 minecraft:bone_block
fill 262 73 493 269 73 493 minecraft:bone_block
fill 263 73 491 264 73 492 minecraft:bone_block
setblock 264 73 465 minecraft:bone_block
fill 264 73 482 267 73 482 minecraft:bone_block
fill 264 73 487 269 73 488 minecraft:bone_block
setblock 264 73 490 minecraft:bone_block
setblock 265 73 464 minecraft:bone_block
fill 265 73 465 268 73 465 minecraft:brown_terracotta
fill 265 73 486 269 73 486 minecraft:bone_block
fill 265 73 492 269 73 492 minecraft:bone_block
fill 266 73 464 269 73 464 minecraft:brown_terracotta
fill 266 73 466 267 73 466 minecraft:brown_terracotta
setblock 268 73 466 minecraft:bone_block
fill 268 73 504 269 73 504 minecraft:brown_terracotta
setblock 269 73 465 minecraft:bone_block
fill 269 73 466 271 73 467 minecraft:brown_terracotta
setblock 270 73 464 minecraft:bone_block
fill 270 73 465 273 73 465 minecraft:brown_terracotta
setblock 270 73 504 minecraft:bone_block
fill 271 73 464 274 73 464 minecraft:brown_terracotta
fill 271 73 504 274 73 504 minecraft:brown_terracotta
setblock 272 73 466 minecraft:brown_terracotta
setblock 272 73 467 minecraft:bone_block
setblock 273 73 466 minecraft:bone_block
fill 273 73 467 273 74 469 minecraft:brown_terracotta
setblock 274 73 465 minecraft:bone_block
fill 274 73 466 274 76 466 minecraft:brown_terracotta
fill 274 73 468 274 73 469 minecraft:brown_terracotta
setblock 274 73 470 minecraft:bone_block
fill 274 73 471 274 76 471 minecraft:brown_terracotta
setblock 275 73 464 minecraft:bone_block
fill 275 73 465 275 76 465 minecraft:brown_terracotta
setblock 275 73 468 minecraft:brown_terracotta
setblock 275 73 469 minecraft:bone_block
fill 275 73 470 275 76 470 minecraft:brown_terracotta
setblock 275 73 504 minecraft:bone_block
fill 276 73 464 276 76 464 minecraft:brown_terracotta
setblock 276 73 468 minecraft:bone_block
fill 276 73 469 276 76 469 minecraft:brown_terracotta
setblock 276 73 473 minecraft:bone_block
fill 276 73 486 276 73 487 minecraft:brown_terracotta
setblock 276 73 488 minecraft:bone_block
fill 276 73 489 276 76 489 minecraft:brown_terracotta
setblock 276 73 493 minecraft:bone_block
fill 276 73 494 276 76 494 minecraft:brown_terracotta
setblock 276 73 502 minecraft:brown_terracotta
setblock 276 73 503 minecraft:bone_block
fill 276 73 504 276 76 504 minecraft:brown_terracotta
fill 235 74 493 239 74 494 minecraft:bone_block
fill 236 74 464 236 74 466 minecraft:brown_terracotta
setblock 236 74 467 minecraft:bone_block
fill 236 74 468 236 77 468 minecraft:brown_terracotta
setblock 236 74 471 minecraft:brown_terracotta
fill 236 74 491 238 74 492 minecraft:bone_block
fill 236 74 497 242 74 497 minecraft:bone_block
fill 236 74 498 236 74 501 minecraft:brown_terracotta
setblock 236 74 502 minecraft:bone_block
fill 236 74 503 236 76 504 minecraft:brown_terracotta
fill 237 74 464 237 75 464 minecraft:brown_terracotta
fill 237 74 475 242 74 475 minecraft:bone_block
fill 237 74 477 240 74 477 minecraft:bone_block
fill 237 74 490 238 74 490 minecraft:bone_block
fill 237 74 504 237 75 504 minecraft:brown_terracotta
fill 238 74 474 244 74 474 minecraft:bone_block
fill 238 74 478 238 74 481 minecraft:bone_block
setblock 238 74 482 minecraft:soul_soil
fill 239 74 473 245 74 473 minecraft:bone_block
fill 239 74 478 239 74 479 minecraft:bone_block
fill 240 74 472 248 74 472 minecraft:bone_block
fill 240 74 476 241 74 476 minecraft:bone_block
setblock 240 74 478 minecraft:bone_block
setblock 240 74 494 minecraft:bone_block
fill 240 74 496 241 74 496 minecraft:bone_block
fill 245 74 499 245 74 500 minecraft:soul_soil
fill 246 74 464 248 74 464 minecraft:brown_terracotta
fill 246 74 500 248 74 500 minecraft:bone_block
setblock 249 74 464 minecraft:bone_block
fill 249 74 465 252 74 465 minecraft:brown_terracotta
fill 250 74 464 253 74 464 minecraft:brown_terracotta
fill 250 74 500 252 79 500 minecraft:bone_block
fill 251 74 499 251 79 499 minecraft:bone_block
setblock 253 74 465 minecraft:bone_block
setblock 254 74 464 minecraft:bone_block
fill 254 74 465 254 75 465 minecraft:brown_terracotta
fill 255 74 464 255 77 464 minecraft:brown_terracotta
fill 256 74 472 258 74 472 minecraft:bone_block
fill 256 74 500 264 74 500 minecraft:bone_block
fill 259 74 472 259 74 473 minecraft:soul_soil
fill 259 74 499 265 74 499 minecraft:bone_block
fill 260 74 472 264 74 474 minecraft:bone_block
fill 260 74 498 266 74 498 minecraft:bone_block
fill 262 74 464 263 74 464 minecraft:brown_terracotta
fill 262 74 475 264 74 475 minecraft:bone_block
fill 262 74 497 267 74 497 minecraft:bone_block
fill 263 74 476 264 74 476 minecraft:bone_block
fill 263 74 496 264 74 496 minecraft:bone_block
setblock 264 74 464 minecraft:bone_block
fill 264 74 465 267 74 465 minecraft:brown_terracotta
fill 264 74 478 269 74 478 minecraft:bone_block
fill 264 74 494 268 74 495 minecraft:bone_block
fill 265 74 464 268 74 464 minecraft:brown_terracotta
fill 265 74 466 266 74 466 minecraft:brown_terracotta
fill 265 74 479 269 74 479 minecraft:bone_block
fill 265 74 493 269 74 493 minecraft:bone_block
fill 266 74 480 267 74 482 minecraft:bone_block
setblock 266 74 490 minecraft:soul_soil
fill 266 74 491 269 74 492 minecraft:bone_block
setblock 267 74 466 minecraft:bone_block
fill 267 74 467 270 74 467 minecraft:brown_terracotta
fill 267 74 485 267 74 489 minecraft:bone_block
fill 267 74 504 268 74 504 minecraft:brown_terracotta
setblock 268 74 465 minecraft:bone_block
fill 268 74 466 271 74 466 minecraft:brown_terracotta
fill 268 74 480 268 74 481 minecraft:bone_block
fill 268 74 485 269 74 488 minecraft:bone_block
setblock 269 74 464 minecraft:bone_block
fill 269 74 465 272 74 465 minecraft:brown_terracotta
setblock 269 74 494 minecraft:bone_block
setblock 269 74 504 minecraft:bone_block
fill 270 74 464 273 74 464 minecraft:brown_terracotta
setblock 270 74 485 minecraft:bone_block
fill 270 74 504 273 74 504 minecraft:brown_terracotta
setblock 271 74 467 minecraft:bone_block
setblock 272 74 466 minecraft:bone_block
fill 272 74 467 272 77 467 minecraft:brown_terracotta
fill 272 74 503 273 75 503 minecraft:brown_terracotta
setblock 273 74 465 minecraft:bone_block
fill 273 74 466 273 77 466 minecraft:brown_terracotta
setblock 274 74 464 minecraft:bone_block
fill 274 74 465 274 77 465 minecraft:brown_terracotta
fill 274 74 467 274 74 468 minecraft:brown_terracotta
setblock 274 74 469 minecraft:bone_block
fill 274 74 470 274 77 470 minecraft:brown_terracotta
setblock 274 74 504 minecraft:bone_block
fill 275 74 464 275 77 464 minecraft:brown_terracotta
setblock 275 74 467 minecraft:brown_terracotta
setblock 275 74 468 minecraft:bone_block
fill 275 74 469 275 77 469 minecraft:brown_terracotta
fill 275 74 471 275 74 472 minecraft:brown_terracotta
fill 275 74 504 275 77 504 minecraft:brown_terracotta
setblock 276 74 467 minecraft:bone_block
fill 276 74 468 276 77 468 minecraft:brown_terracotta
setblock 276 74 471 minecraft:brown_terracotta
setblock 276 74 472 minecraft:bone_block
fill 276 74 473 276 76 474 minecraft:brown_terracotta
setblock 276 74 487 minecraft:bone_block
fill 276 74 488 276 77 488 minecraft:brown_terracotta
fill 276 74 490 276 74 491 minecraft:brown_terracotta
setblock 276 74 492 minecraft:bone_block
fill 276 74 493 276 77 493 minecraft:brown_terracotta
fill 276 74 495 276 74 496 minecraft:brown_terracotta
setblock 276 74 502 minecraft:bone_block
fill 276 74 503 276 77 503 minecraft:brown_terracotta
fill 235 75 478 235 82 494 minecraft:black_concrete
fill 236 75 464 236 75 465 minecraft:brown_terracotta
setblock 236 75 466 minecraft:bone_block
fill 236 75 467 236 78 467 minecraft:brown_terracotta
setblock 236 75 471 minecraft:bone_block
setblock 236 75 485 minecraft:brown_terracotta
setblock 236 75 486 minecraft:bone_block
fill 236 75 487 236 75 490 minecraft:brown_terracotta
setblock 236 75 491 minecraft:bone_block
fill 236 75 492 236 75 495 minecraft:brown_terracotta
setblock 236 75 496 minecraft:bone_block
fill 236 75 497 236 75 500 minecraft:brown_terracotta
setblock 236 75 501 minecraft:bone_block
fill 236 75 502 236 78 502 minecraft:brown_terracotta
fill 237 75 488 237 75 489 minecraft:brown_terracotta
setblock 237 75 490 minecraft:bone_block
fill 237 75 491 237 75 494 minecraft:brown_terracotta
setblock 237 75 495 minecraft:bone_block
fill 237 75 496 237 78 496 minecraft:brown_terracotta
fill 246 75 464 247 75 464 minecraft:brown_terracotta
setblock 247 75 504 minecraft:brown_terracotta
setblock 248 75 464 minecraft:bone_block
fill 248 75 465 251 75 465 minecraft:brown_terracotta
setblock 248 75 504 minecraft:bone_block
fill 249 75 464 252 75 464 minecraft:brown_terracotta
fill 249 75 504 251 76 504 minecraft:brown_terracotta
fill 251 75 501 251 79 501 minecraft:bone_block
setblock 252 75 465 minecraft:bone_block
fill 252 75 505 252 85 505 minecraft:black_concrete
setblock 253 75 464 minecraft:bone_block
fill 253 75 465 253 76 465 minecraft:brown_terracotta
fill 254 75 464 254 78 464 minecraft:brown_terracotta
fill 261 75 464 262 75 464 minecraft:brown_terracotta
setblock 263 75 464 minecraft:bone_block
fill 263 75 465 266 75 465 minecraft:brown_terracotta
fill 264 75 464 267 75 464 minecraft:brown_terracotta
setblock 265 75 466 minecraft:brown_terracotta
setblock 266 75 466 minecraft:bone_block
fill 266 75 467 269 75 467 minecraft:brown_terracotta
setblock 267 75 465 minecraft:bone_block
fill 267 75 466 270 75 466 minecraft:brown_terracotta
setblock 267 75 504 minecraft:brown_terracotta
setblock 268 75 464 minecraft:bone_block
fill 268 75 465 271 75 465 minecraft:brown_terracotta
setblock 268 75 481 minecraft:bone_block
setblock 268 75 504 minecraft:bone_block
fill 269 75 464 272 75 464 minecraft:brown_terracotta
fill 269 75 504 272 75 504 minecraft:brown_terracotta
setblock 270 75 467 minecraft:bone_block
fill 270 75 503 271 77 503 minecraft:brown_terracotta
setblock 271 75 466 minecraft:bone_block
fill 271 75 467 271 78 467 minecraft:brown_terracotta
setblock 272 75 465 minecraft:bone_block
fill 272 75 466 272 78 466 minecraft:brown_terracotta
setblock 273 75 464 minecraft:bone_block
fill 273 75 465 273 78 465 minecraft:brown_terracotta
fill 273 75 467 273 75 468 minecraft:brown_terracotta
setblock 273 75 469 minecraft:bone_block
fill 273 75 470 273 77 470 minecraft:brown_terracotta
setblock 273 75 504 minecraft:bone_block
fill 274 75 464 274 78 464 minecraft:brown_terracotta
setblock 274 75 467 minecraft:brown_terracotta
setblock 274 75 468 minecraft:bone_block
fill 274 75 469 274 78 469 minecraft:brown_terracotta
setblock 274 75 472 minecraft:brown_terracotta
fill 274 75 504 274 78 504 minecraft:brown_terracotta
setblock 275 75 466 minecraft:brown_terracotta
setblock 275 75 467 minecraft:bone_block
fill 275 75 468 275 78 468 minecraft:brown_terracotta
setblock 275 75 471 minecraft:brown_terracotta
setblock 275 75 472 minecraft:bone_block
fill 275 75 473 275 78 473 minecraft:brown_terracotta
fill 275 75 490 275 75 491 minecraft:brown_terracotta
setblock 275 75 492 minecraft:bone_block
fill 275 75 493 275 78 493 minecraft:brown_terracotta
setblock 276 75 466 minecraft:bone_block
fill 276 75 467 276 78 467 minecraft:brown_terracotta
setblock 276 75 471 minecraft:bone_block
fill 276 75 472 276 78 472 minecraft:brown_terracotta
fill 276 75 487 276 76 487 minecraft:brown_terracotta
setblock 276 75 490 minecraft:brown_terracotta
setblock 276 75 491 minecraft:bone_block
fill 276 75 492 276 78 492 minecraft:brown_terracotta
setblock 276 75 495 minecraft:brown_terracotta
setblock 276 75 496 minecraft:bone_block
fill 276 75 497 276 75 500 minecraft:brown_terracotta
setblock 276 75 501 minecraft:bone_block
fill 276 75 502 276 78 502 minecraft:brown_terracotta
setblock 236 76 464 minecraft:brown_terracotta
setblock 236 76 465 minecraft:bone_block
fill 236 76 466 236 77 466 minecraft:brown_terracotta
setblock 236 76 470 minecraft:bone_block
fill 236 76 471 236 78 472 minecraft:brown_terracotta
fill 236 76 486 236 76 489 minecraft:brown_terracotta
setblock 236 76 490 minecraft:bone_block
fill 236 76 491 236 76 494 minecraft:brown_terracotta
setblock 236 76 495 minecraft:bone_block
fill 236 76 496 236 76 499 minecraft:brown_terracotta
setblock 236 76 500 minecraft:bone_block
fill 236 76 501 236 79 501 minecraft:brown_terracotta
setblock 237 76 488 minecraft:brown_terracotta
setblock 237 76 489 minecraft:bone_block
fill 237 76 490 237 76 493 minecraft:brown_terracotta
setblock 237 76 494 minecraft:bone_block
fill 237 76 495 237 79 495 minecraft:brown_terracotta
fill 237 76 497 237 77 497 minecraft:brown_terracotta
fill 245 76 464 246 76 464 minecraft:brown_terracotta
setblock 246 76 504 minecraft:brown_terracotta
setblock 247 76 464 minecraft:bone_block
setblock 247 76 504 minecraft:bone_block
fill 248 76 464 250 76 465 minecraft:brown_terracotta
fill 248 76 504 248 79 504 minecraft:brown_terracotta
fill 250 76 499 250 79 499 minecraft:bone_block
fill 250 76 501 250 79 501 minecraft:bone_block
setblock 251 76 464 minecraft:brown_terracotta
setblock 251 76 465 minecraft:bone_block
setblock 252 76 464 minecraft:bone_block
fill 252 76 465 252 77 465 minecraft:brown_terracotta
fill 252 76 499 252 79 499 minecraft:bone_block
fill 252 76 501 252 79 501 minecraft:bone_block
fill 253 76 464 253 78 464 minecraft:brown_terracotta
setblock 256 76 464 minecraft:brown_terracotta
fill 260 76 464 261 76 464 minecraft:brown_terracotta
setblock 262 76 464 minecraft:bone_block
fill 262 76 465 265 76 465 minecraft:brown_terracotta
fill 263 76 464 266 76 464 minecraft:brown_terracotta
setblock 264 76 466 minecraft:brown_terracotta
setblock 265 76 466 minecraft:bone_block
setblock 266 76 465 minecraft:bone_block
fill 266 76 466 268 76 467 minecraft:brown_terracotta
setblock 266 76 504 minecraft:brown_terracotta
setblock 267 76 464 minecraft:bone_block
fill 267 76 465 270 76 465 minecraft:brown_terracotta
setblock 267 76 504 minecraft:bone_block
fill 268 76 464 271 76 464 minecraft:brown_terracotta
fill 268 76 504 271 76 504 minecraft:brown_terracotta
setblock 269 76 466 minecraft:brown_terracotta
setblock 269 76 467 minecraft:bone_block
fill 269 76 468 270 77 468 minecraft:brown_terracotta
fill 269 76 503 269 79 503 minecraft:brown_terracotta
setblock 270 76 466 minecraft:bone_block
fill 270 76 467 270 79 467 minecraft:brown_terracotta
setblock 271 76 465 minecraft:bone_block
fill 271 76 466 271 79 466 minecraft:brown_terracotta
setblock 272 76 464 minecraft:bone_block
fill 272 76 465 272 79 465 minecraft:brown_terracotta
setblock 272 76 503 minecraft:brown_terracotta
setblock 272 76 504 minecraft:bone_block
fill 273 76 464 273 79 464 minecraft:brown_terracotta
setblock 273 76 467 minecraft:brown_terracotta
setblock 273 76 468 minecraft:bone_block
fill 273 76 469 273 77 469 minecraft:brown_terracotta
setblock 273 76 503 minecraft:bone_block
fill 273 76 504 273 79 504 minecraft:brown_terracotta
setblock 274 76 467 minecraft:bone_block
fill 274 76 468 274 78 468 minecraft:brown_terracotta
setblock 274 76 472 minecraft:bone_block
setblock 275 76 466 minecraft:bone_block
fill 275 76 467 275 79 467 minecraft:brown_terracotta
setblock 275 76 471 minecraft:bone_block
fill 275 76 472 275 79 472 minecraft:brown_terracotta
setblock 275 76 490 minecraft:brown_terracotta
setblock 275 76 491 minecraft:bone_block
fill 275 76 492 275 79 492 minecraft:brown_terracotta
fill 275 76 494 275 76 495 minecraft:brown_terracotta
setblock 275 76 496 minecraft:bone_block
setblock 276 76 465 minecraft:bone_block
fill 276 76 466 276 79 466 minecraft:brown_terracotta
setblock 276 76 470 minecraft:bone_block
fill 276 76 471 276 79 471 minecraft:brown_terracotta
setblock 276 76 490 minecraft:bone_block
fill 276 76 491 276 79 491 minecraft:brown_terracotta
setblock 276 76 495 minecraft:bone_block
fill 276 76 496 276 76 499 minecraft:brown_terracotta
setblock 276 76 500 minecraft:bone_block
fill 276 76 501 276 79 501 minecraft:brown_terracotta
setblock 236 77 465 minecraft:brown_terracotta
setblock 236 77 469 minecraft:bone_block
fill 236 77 470 236 79 470 minecraft:brown_terracotta
setblock 236 77 473 minecraft:brown_terracotta
fill 236 77 486 236 77 488 minecraft:brown_terracotta
setblock 236 77 489 minecraft:bone_block
fill 236 77 490 236 77 493 minecraft:brown_terracotta
setblock 236 77 494 minecraft:bone_block
fill 236 77 495 236 77 498 minecraft:brown_terracotta
setblock 236 77 499 minecraft:bone_block
fill 236 77 500 236 80 500 minecraft:brown_terracotta
setblock 236 77 503 minecraft:brown_terracotta
setblock 236 77 504 minecraft:bone_block
setblock 237 77 488 minecraft:bone_block
fill 237 77 489 237 77 492 minecraft:brown_terracotta
setblock 237 77 493 minecraft:bone_block
fill 237 77 494 237 80 494 minecraft:brown_terracotta
setblock 238 77 492 minecraft:bone_block
fill 238 77 493 238 80 493 minecraft:brown_terracotta
setblock 245 77 464 minecraft:brown_terracotta
setblock 245 77 504 minecraft:brown_terracotta
setblock 246 77 464 minecraft:bone_block
setblock 246 77 504 minecraft:bone_block
fill 247 77 464 249 77 465 minecraft:brown_terracotta
fill 247 77 504 247 80 504 minecraft:brown_terracotta
fill 249 77 504 250 77 504 minecraft:brown_terracotta
setblock 250 77 464 minecraft:brown_terracotta
setblock 250 77 465 minecraft:bone_block
setblock 251 77 464 minecraft:bone_block
fill 251 77 465 251 78 465 minecraft:brown_terracotta
fill 252 77 464 252 79 464 minecraft:brown_terracotta
setblock 260 77 464 minecraft:brown_terracotta
setblock 261 77 464 minecraft:bone_block
fill 262 77 464 264 77 465 minecraft:brown_terracotta
setblock 264 77 466 minecraft:bone_block
setblock 265 77 464 minecraft:brown_terracotta
setblock 265 77 465 minecraft:bone_block
fill 265 77 466 267 77 467 minecraft:brown_terracotta
setblock 265 77 504 minecraft:brown_terracotta
setblock 266 77 464 minecraft:bone_block
fill 266 77 465 269 77 465 minecraft:brown_terracotta
setblock 266 77 504 minecraft:bone_block
fill 267 77 464 270 77 464 minecraft:brown_terracotta
fill 267 77 504 270 77 504 minecraft:brown_terracotta
setblock 268 77 466 minecraft:brown_terracotta
setblock 268 77 467 minecraft:bone_block
fill 268 77 468 268 78 468 minecraft:brown_terracotta
fill 268 77 503 268 80 503 minecraft:brown_terracotta
setblock 269 77 466 minecraft:bone_block
fill 269 77 467 269 79 467 minecraft:brown_terracotta
setblock 270 77 465 minecraft:bone_block
fill 270 77 466 270 80 466 minecraft:brown_terracotta
setblock 271 77 464 minecraft:bone_block
fill 271 77 465 271 80 465 minecraft:brown_terracotta
setblock 271 77 504 minecraft:bone_block
fill 272 77 464 272 80 464 minecraft:brown_terracotta
setblock 272 77 503 minecraft:bone_block
fill 272 77 504 272 80 504 minecraft:brown_terracotta
setblock 273 77 468 minecraft:brown_terracotta
fill 273 77 503 273 78 503 minecraft:brown_terracotta
setblock 274 77 466 minecraft:bone_block
fill 274 77 467 274 78 467 minecraft:brown_terracotta
setblock 274 77 471 minecraft:bone_block
fill 274 77 472 274 78 472 minecraft:brown_terracotta
setblock 275 77 465 minecraft:bone_block
fill 275 77 466 275 78 466 minecraft:brown_terracotta
setblock 275 77 470 minecraft:bone_block
fill 275 77 471 275 79 471 minecraft:brown_terracotta
setblock 275 77 490 minecraft:bone_block
fill 275 77 491 275 78 491 minecraft:brown_terracotta
setblock 275 77 494 minecraft:brown_terracotta
setblock 275 77 495 minecraft:bone_block
fill 275 77 496 276 78 497 minecraft:brown_terracotta
setblock 276 77 464 minecraft:bone_block
fill 276 77 465 276 79 465 minecraft:brown_terracotta
setblock 276 77 469 minecraft:bone_block
fill 276 77 470 276 80 470 minecraft:brown_terracotta
setblock 276 77 473 minecraft:brown_terracotta
setblock 276 77 474 minecraft:bone_block
fill 276 77 475 276 79 475 minecraft:brown_terracotta
setblock 276 77 489 minecraft:bone_block
fill 276 77 490 276 80 490 minecraft:brown_terracotta
setblock 276 77 494 minecraft:bone_block
fill 276 77 495 276 80 495 minecraft:brown_terracotta
setblock 276 77 498 minecraft:brown_terracotta
setblock 276 77 499 minecraft:bone_block
fill 276 77 500 276 80 500 minecraft:brown_terracotta
setblock 276 77 504 minecraft:bone_block
setblock 236 78 468 minecraft:bone_block
setblock 236 78 469 minecraft:brown_terracotta
setblock 236 78 473 minecraft:bone_block
fill 236 78 486 236 78 487 minecraft:brown_terracotta
setblock 236 78 488 minecraft:bone_block
fill 236 78 489 236 78 492 minecraft:brown_terracotta
setblock 236 78 493 minecraft:bone_block
fill 236 78 494 236 78 497 minecraft:brown_terracotta
setblock 236 78 498 minecraft:bone_block
fill 236 78 499 236 81 499 minecraft:brown_terracotta
setblock 236 78 503 minecraft:bone_block
fill 237 78 489 237 78 491 minecraft:brown_terracotta
setblock 237 78 492 minecraft:bone_block
fill 237 78 493 237 81 493 minecraft:brown_terracotta
setblock 237 78 497 minecraft:bone_block
fill 237 78 498 237 81 498 minecraft:brown_terracotta
fill 238 78 492 238 79 492 minecraft:brown_terracotta
fill 238 78 494 238 79 494 minecraft:brown_terracotta
setblock 245 78 464 minecraft:bone_block
setblock 245 78 504 minecraft:bone_block
fill 246 78 464 249 78 464 minecraft:brown_terracotta
fill 246 78 504 246 81 504 minecraft:brown_terracotta
setblock 248 78 465 minecraft:brown_terracotta
setblock 249 78 465 minecraft:bone_block
setblock 249 78 504 minecraft:brown_terracotta
setblock 250 78 464 minecraft:bone_block
setblock 250 78 465 minecraft:brown_terracotta
setblock 250 78 504 minecraft:bone_block
fill 251 78 464 251 79 464 minecraft:brown_terracotta
setblock 260 78 464 minecraft:bone_block
fill 261 78 464 264 78 464 minecraft:brown_terracotta
fill 262 78 465 263 78 465 minecraft:brown_terracotta
setblock 263 78 466 minecraft:bone_block
setblock 264 78 465 minecraft:bone_block
fill 264 78 466 267 78 466 minecraft:brown_terracotta
setblock 265 78 464 minecraft:bone_block
fill 265 78 465 268 78 465 minecraft:brown_terracotta
fill 265 78 467 266 78 467 minecraft:brown_terracotta
setblock 265 78 504 minecraft:bone_block
fill 266 78 464 269 78 464 minecraft:brown_terracotta
fill 266 78 504 269 78 504 minecraft:brown_terracotta
setblock 267 78 467 minecraft:bone_block
fill 267 78 503 267 81 503 minecraft:brown_terracotta
setblock 268 78 466 minecraft:bone_block
fill 268 78 467 268 80 467 minecraft:brown_terracotta
setblock 269 78 465 minecraft:bone_block
fill 269 78 466 269 81 466 minecraft:brown_terracotta
setblock 270 78 464 minecraft:bone_block
fill 270 78 465 270 81 465 minecraft:brown_terracotta
setblock 270 78 503 minecraft:brown_terracotta
setblock 270 78 504 minecraft:bone_block
fill 271 78 464 271 81 464 minecraft:brown_terracotta
setblock 271 78 503 minecraft:bone_block
fill 271 78 504 271 81 504 minecraft:brown_terracotta
setblock 272 78 467 minecraft:bone_block
fill 272 78 503 272 80 503 minecraft:brown_terracotta
setblock 273 78 466 minecraft:bone_block
setblock 274 78 465 minecraft:bone_block
setblock 274 78 470 minecraft:bone_block
setblock 274 78 471 minecraft:brown_terracotta
setblock 275 78 464 minecraft:bone_block
setblock 275 78 465 minecraft:brown_terracotta
setblock 275 78 469 minecraft:bone_block
fill 275 78 470 275 79 470 minecraft:brown_terracotta
setblock 275 78 494 minecraft:bone_block
fill 275 78 495 275 81 495 minecraft:brown_terracotta
setblock 275 78 498 minecraft:brown_terracotta
setblock 275 78 504 minecraft:bone_block
fill 276 78 464 276 79 464 minecraft:brown_terracotta
setblock 276 78 468 minecraft:bone_block
fill 276 78 469 276 80 469 minecraft:brown_terracotta
setblock 276 78 473 minecraft:bone_block
fill 276 78 474 276 80 474 minecraft:brown_terracotta
fill 276 78 489 276 79 489 minecraft:brown_terracotta
setblock 276 78 493 minecraft:bone_block
fill 276 78 494 276 81 494 minecraft:brown_terracotta
setblock 276 78 498 minecraft:bone_block
fill 276 78 499 276 81 499 minecraft:brown_terracotta
setblock 276 78 503 minecraft:bone_block
fill 276 78 504 276 80 504 minecraft:brown_terracotta
setblock 236 79 471 minecraft:brown_terracotta
setblock 236 79 472 minecraft:bone_block
setblock 236 79 473 minecraft:brown_terracotta
setblock 236 79 487 minecraft:bone_block
fill 236 79 488 236 79 491 minecraft:brown_terracotta
setblock 236 79 492 minecraft:bone_block
fill 236 79 493 236 79 496 minecraft:brown_terracotta
setblock 236 79 497 minecraft:bone_block
fill 236 79 498 236 82 498 minecraft:brown_terracotta
setblock 236 79 502 minecraft:bone_block
fill 237 79 489 237 79 490 minecraft:brown_terracotta
setblock 237 79 491 minecraft:bone_block
fill 237 79 492 237 82 492 minecraft:brown_terracotta
setblock 237 79 496 minecraft:bone_block
fill 237 79 497 237 82 497 minecraft:brown_terracotta
setblock 238 79 495 minecraft:bone_block
fill 245 79 464 248 79 464 minecraft:brown_terracotta
fill 245 79 504 245 81 504 minecraft:brown_terracotta
setblock 249 79 464 minecraft:bone_block
setblock 249 79 500 minecraft:bone_block
setblock 249 79 504 minecraft:bone_block
fill 250 79 464 250 80 464 minecraft:brown_terracotta
setblock 251 79 498 minecraft:bone_block
setblock 251 79 502 minecraft:bone_block
setblock 253 79 500 minecraft:bone_block
fill 260 79 464 263 79 464 minecraft:brown_terracotta
setblock 262 79 465 minecraft:brown_terracotta
setblock 263 79 465 minecraft:bone_block
fill 263 79 466 266 79 466 minecraft:brown_terracotta
setblock 264 79 464 minecraft:bone_block
fill 264 79 465 267 79 465 minecraft:brown_terracotta
setblock 264 79 504 minecraft:bone_block
fill 265 79 464 268 79 464 minecraft:brown_terracotta
setblock 265 79 467 minecraft:brown_terracotta
fill 265 79 504 268 79 504 minecraft:brown_terracotta
setblock 266 79 467 minecraft:bone_block
setblock 267 79 466 minecraft:bone_block
fill 267 79 467 267 80 467 minecraft:brown_terracotta
setblock 268 79 465 minecraft:bone_block
fill 268 79 466 268 81 466 minecraft:brown_terracotta
setblock 269 79 464 minecraft:bone_block
fill 269 79 465 269 82 465 minecraft:brown_terracotta
setblock 269 79 504 minecraft:bone_block
fill 270 79 464 270 82 464 minecraft:brown_terracotta
setblock 270 79 503 minecraft:bone_block
fill 270 79 504 270 82 504 minecraft:brown_terracotta
fill 271 79 503 271 81 503 minecraft:brown_terracotta
setblock 272 79 466 minecraft:bone_block
setblock 273 79 465 minecraft:bone_block
setblock 274 79 464 minecraft:bone_block
setblock 274 79 465 minecraft:brown_terracotta
setblock 274 79 504 minecraft:bone_block
fill 275 79 464 275 80 464 minecraft:brown_terracotta
setblock 275 79 468 minecraft:bone_block
setblock 275 79 469 minecraft:brown_terracotta
setblock 275 79 473 minecraft:bone_block
setblock 275 79 493 minecraft:bone_block
fill 275 79 494 275 81 494 minecraft:brown_terracotta
fill 275 79 496 275 79 497 minecraft:brown_terracotta
setblock 275 79 498 minecraft:bone_block
fill 275 79 499 275 81 499 minecraft:brown_terracotta
fill 275 79 504 275 81 504 minecraft:brown_terracotta
setblock 276 79 467 minecraft:bone_block
fill 276 79 468 276 80 468 minecraft:brown_terracotta
setblock 276 79 472 minecraft:bone_block
fill 276 79 473 276 81 473 minecraft:brown_terracotta
setblock 276 79 492 minecraft:bone_block
fill 276 79 493 276 82 493 minecraft:brown_terracotta
setblock 276 79 496 minecraft:brown_terracotta
setblock 276 79 497 minecraft:bone_block
fill 276 79 498 276 82 498 minecraft:brown_terracotta
setblock 276 79 502 minecraft:bone_block
fill 276 79 503 276 81 503 minecraft:brown_terracotta
fill 236 80 488 236 80 490 minecraft:brown_terracotta
setblock 236 80 491 minecraft:bone_block
fill 236 80 492 236 80 495 minecraft:brown_terracotta
setblock 236 80 496 minecraft:bone_block
fill 236 80 497 236 83 497 minecraft:brown_terracotta
setblock 236 80 501 minecraft:bone_block
fill 237 80 484 238 81 485 minecraft:soul_soil
setblock 237 80 490 minecraft:bone_block
fill 237 80 491 237 81 491 minecraft:brown_terracotta
setblock 237 80 495 minecraft:bone_block
fill 237 80 496 237 83 496 minecraft:brown_terracotta
setblock 238 80 466 minecraft:light[level=12]
setblock 238 80 474 minecraft:light[level=12]
setblock 238 80 482 minecraft:light[level=12]
setblock 238 80 490 minecraft:light[level=12]
setblock 238 80 494 minecraft:bone_block
setblock 238 80 495 minecraft:brown_terracotta
setblock 238 80 498 minecraft:light[level=12]
fill 246 80 464 247 80 464 minecraft:brown_terracotta
setblock 246 80 466 minecraft:light[level=12]
setblock 246 80 474 minecraft:light[level=12]
setblock 246 80 482 minecraft:light[level=12]
setblock 246 80 490 minecraft:light[level=12]
setblock 246 80 498 minecraft:light[level=12]
setblock 248 80 464 minecraft:bone_block
setblock 248 80 504 minecraft:bone_block
setblock 249 80 464 minecraft:brown_terracotta
setblock 254 80 466 minecraft:light[level=12]
setblock 254 80 474 minecraft:light[level=12]
setblock 254 80 482 minecraft:light[level=12]
setblock 254 80 490 minecraft:light[level=12]
setblock 254 80 498 minecraft:light[level=12]
fill 261 80 464 262 80 464 minecraft:brown_terracotta
setblock 262 80 465 minecraft:bone_block
setblock 262 80 466 minecraft:light[level=12]
setblock 262 80 474 minecraft:light[level=12]
setblock 262 80 482 minecraft:light[level=12]
setblock 262 80 490 minecraft:light[level=12]
setblock 262 80 498 minecraft:light[level=12]
setblock 263 80 464 minecraft:bone_block
fill 263 80 465 266 80 465 minecraft:brown_terracotta
fill 264 80 464 267 80 464 minecraft:brown_terracotta
fill 264 80 466 265 80 466 minecraft:brown_terracotta
fill 264 80 504 267 80 504 minecraft:brown_terracotta
setblock 266 80 466 minecraft:bone_block
setblock 266 80 467 minecraft:brown_terracotta
fill 266 80 503 266 82 503 minecraft:brown_terracotta
setblock 267 80 465 minecraft:bone_block
fill 267 80 466 267 81 466 minecraft:brown_terracotta
setblock 268 80 464 minecraft:bone_block
fill 268 80 465 268 83 465 minecraft:brown_terracotta
setblock 268 80 504 minecraft:bone_block
fill 269 80 464 269 83 464 minecraft:brown_terracotta
setblock 269 80 503 minecraft:bone_block
fill 269 80 504 269 83 504 minecraft:brown_terracotta
setblock 270 80 474 minecraft:light[level=12]
setblock 270 80 482 minecraft:light[level=12]
setblock 270 80 490 minecraft:light[level=12]
setblock 270 80 498 minecraft:light[level=12]
fill 270 80 503 270 83 503 minecraft:brown_terracotta
setblock 271 80 466 minecraft:bone_block
setblock 272 80 465 minecraft:bone_block
setblock 273 80 464 minecraft:bone_block
setblock 273 80 465 minecraft:brown_terracotta
setblock 273 80 504 minecraft:bone_block
setblock 274 80 464 minecraft:brown_terracotta
fill 274 80 504 274 81 504 minecraft:brown_terracotta
setblock 275 80 493 minecraft:brown_terracotta
setblock 275 80 496 minecraft:brown_terracotta
setblock 275 80 497 minecraft:bone_block
fill 275 80 498 275 83 498 minecraft:brown_terracotta
setblock 276 80 466 minecraft:bone_block
setblock 276 80 467 minecraft:brown_terracotta
setblock 276 80 471 minecraft:bone_block
fill 276 80 472 276 81 472 minecraft:brown_terracotta
setblock 276 80 491 minecraft:bone_block
fill 276 80 492 276 82 492 minecraft:brown_terracotta
setblock 276 80 496 minecraft:bone_block
fill 276 80 497 276 83 497 minecraft:brown_terracotta
setblock 276 80 501 minecraft:bone_block
fill 276 80 502 276 83 502 minecraft:brown_terracotta
setblock 236 81 489 minecraft:brown_terracotta
setblock 236 81 490 minecraft:bone_block
fill 236 81 491 236 81 494 minecraft:brown_terracotta
setblock 236 81 495 minecraft:bone_block
fill 236 81 496 236 84 496 minecraft:brown_terracotta
setblock 236 81 500 minecraft:bone_block
fill 236 81 501 236 84 501 minecraft:brown_terracotta
setblock 237 81 494 minecraft:bone_block
fill 237 81 495 237 84 495 minecraft:brown_terracotta
setblock 261 81 464 minecraft:brown_terracotta
setblock 262 81 464 minecraft:bone_block
fill 263 81 464 265 81 465 minecraft:brown_terracotta
fill 263 81 504 266 81 504 minecraft:brown_terracotta
setblock 264 81 466 minecraft:brown_terracotta
setblock 265 81 466 minecraft:bone_block
setblock 266 81 464 minecraft:brown_terracotta
setblock 266 81 465 minecraft:bone_block
fill 266 81 466 266 82 466 minecraft:brown_terracotta
setblock 267 81 464 minecraft:bone_block
fill 267 81 465 267 84 465 minecraft:brown_terracotta
setblock 267 81 504 minecraft:bone_block
fill 268 81 464 268 84 464 minecraft:brown_terracotta
setblock 268 81 503 minecraft:bone_block
fill 268 81 504 268 84 504 minecraft:brown_terracotta
fill 269 81 503 269 84 503 minecraft:brown_terracotta
setblock 271 81 465 minecraft:bone_block
setblock 272 81 464 minecraft:bone_block
setblock 272 81 504 minecraft:bone_block
setblock 273 81 464 minecraft:brown_terracotta
fill 273 81 504 273 83 504 minecraft:brown_terracotta
setblock 275 81 496 minecraft:bone_block
fill 275 81 497 275 83 497 minecraft:brown_terracotta
setblock 276 81 470 minecraft:bone_block
setblock 276 81 471 minecraft:brown_terracotta
setblock 276 81 491 minecraft:brown_terracotta
setblock 276 81 495 minecraft:bone_block
fill 276 81 496 276 84 496 minecraft:brown_terracotta
setblock 276 81 500 minecraft:bone_block
fill 276 81 501 276 84 501 minecraft:brown_terracotta
fill 235 82 495 235 85 504 minecraft:black_concrete
fill 235 82 505 236 82 505 minecraft:brown_terracotta
fill 236 82 463 252 82 463 minecraft:black_concrete
fill 236 82 490 236 82 493 minecraft:brown_terracotta
setblock 236 82 494 minecraft:bone_block
fill 236 82 495 236 85 495 minecraft:brown_terracotta
setblock 236 82 499 minecraft:bone_block
fill 236 82 500 236 85 500 minecraft:brown_terracotta
setblock 237 82 493 minecraft:bone_block
fill 237 82 494 237 84 494 minecraft:brown_terracotta
setblock 237 82 498 minecraft:bone_block
fill 237 82 505 240 82 505 minecraft:black_concrete
setblock 241 82 505 minecraft:brown_terracotta
fill 242 82 505 251 83 505 minecraft:black_concrete
setblock 253 82 463 minecraft:brown_terracotta
fill 253 82 505 260 83 505 minecraft:black_concrete
fill 254 82 463 262 82 463 minecraft:black_concrete
setblock 261 82 464 minecraft:bone_block
setblock 261 82 505 minecraft:brown_terracotta
fill 262 82 464 265 82 464 minecraft:brown_terracotta
fill 262 82 505 263 83 505 minecraft:black_concrete
setblock 263 82 463 minecraft:brown_terracotta
fill 263 82 465 264 82 465 minecraft:brown_terracotta
fill 263 82 504 265 82 504 minecraft:brown_terracotta
fill 264 82 463 268 82 463 minecraft:black_concrete
setblock 264 82 505 minecraft:brown_terracotta
setblock 265 82 465 minecraft:bone_block
fill 265 82 503 265 83 503 minecraft:brown_terracotta
fill 265 82 505 277 82 505 minecraft:black_concrete
setblock 266 82 464 minecraft:bone_block
fill 266 82 465 266 85 465 minecraft:brown_terracotta
setblock 266 82 504 minecraft:bone_block
fill 267 82 464 267 85 464 minecraft:brown_terracotta
setblock 267 82 503 minecraft:bone_block
fill 267 82 504 267 85 504 minecraft:brown_terracotta
fill 268 82 503 268 85 503 minecraft:brown_terracotta
setblock 269 82 463 minecraft:brown_terracotta
fill 270 82 463 271 85 463 minecraft:black_concrete
setblock 270 82 465 minecraft:bone_block
setblock 271 82 464 minecraft:bone_block
setblock 271 82 504 minecraft:bone_block
fill 272 82 463 272 82 464 minecraft:brown_terracotta
fill 272 82 504 272 85 504 minecraft:brown_terracotta
fill 273 82 463 277 83 463 minecraft:black_concrete
setblock 275 82 495 minecraft:bone_block
fill 275 82 496 275 83 496 minecraft:brown_terracotta
setblock 276 82 494 minecraft:bone_block
fill 276 82 495 276 85 495 minecraft:brown_terracotta
setblock 276 82 499 minecraft:bone_block
fill 276 82 500 276 85 500 minecraft:brown_terracotta
fill 277 82 464 277 83 478 minecraft:black_concrete
setblock 277 82 479 minecraft:brown_terracotta
fill 277 82 480 277 82 504 minecraft:black_concrete
fill 235 83 463 235 85 468 minecraft:black_concrete
fill 235 83 469 235 84 469 minecraft:brown_terracotta
fill 235 83 470 235 85 472 minecraft:black_concrete
setblock 235 83 473 minecraft:brown_terracotta
fill 235 83 474 235 85 475 minecraft:black_concrete
setblock 235 83 476 minecraft:brown_terracotta
fill 235 83 477 235 85 477 minecraft:black_concrete
setblock 235 83 478 minecraft:brown_terracotta
fill 235 83 479 235 85 482 minecraft:black_concrete
setblock 235 83 483 minecraft:brown_terracotta
fill 235 83 484 235 83 494 minecraft:black_concrete
fill 235 83 505 238 85 505 minecraft:black_concrete
fill 236 83 463 250 83 463 minecraft:black_concrete
fill 236 83 491 236 83 492 minecraft:brown_terracotta
setblock 236 83 493 minecraft:bone_block
fill 236 83 494 236 86 494 minecraft:brown_terracotta
setblock 236 83 498 minecraft:bone_block
fill 236 83 499 236 86 499 minecraft:brown_terracotta
setblock 237 83 493 minecraft:brown_terracotta
setblock 237 83 497 minecraft:bone_block
fill 237 83 498 237 86 498 minecraft:brown_terracotta
setblock 239 83 505 minecraft:brown_terracotta
fill 240 83 505 241 83 505 minecraft:black_concrete
setblock 251 83 463 minecraft:brown_terracotta
fill 251 83 495 251 84 497 minecraft:bone_block
fill 252 83 463 254 85 463 minecraft:black_concrete
fill 252 83 495 252 84 496 minecraft:bone_block
setblock 255 83 463 minecraft:brown_terracotta
fill 256 83 463 258 83 463 minecraft:black_concrete
fill 258 83 493 259 84 494 minecraft:bone_block
setblock 259 83 463 minecraft:brown_terracotta
fill 260 83 463 264 83 463 minecraft:black_concrete
fill 261 83 464 264 83 464 minecraft:brown_terracotta
fill 261 83 505 261 85 505 minecraft:black_concrete
setblock 263 83 465 minecraft:brown_terracotta
fill 263 83 504 264 83 504 minecraft:brown_terracotta
setblock 264 83 465 minecraft:bone_block
fill 264 83 505 265 83 505 minecraft:black_concrete
fill 265 83 463 266 83 463 minecraft:brown_terracotta
setblock 265 83 464 minecraft:bone_block
fill 265 83 465 265 86 465 minecraft:brown_terracotta
setblock 265 83 504 minecraft:bone_block
fill 266 83 464 266 86 464 minecraft:brown_terracotta
setblock 266 83 503 minecraft:bone_block
fill 266 83 504 266 83 505 minecraft:brown_terracotta
fill 267 83 463 269 85 463 minecraft:black_concrete
fill 267 83 503 267 86 503 minecraft:brown_terracotta
fill 267 83 505 275 85 505 minecraft:black_concrete
setblock 270 83 464 minecraft:bone_block
setblock 270 83 504 minecraft:bone_block
setblock 271 83 464 minecraft:brown_terracotta
fill 271 83 504 271 86 504 minecraft:brown_terracotta
fill 272 83 463 272 85 463 minecraft:black_concrete
setblock 276 83 493 minecraft:bone_block
fill 276 83 494 276 86 494 minecraft:brown_terracotta
setblock 276 83 498 minecraft:bone_block
fill 276 83 499 277 83 499 minecraft:brown_terracotta
setblock 276 83 505 minecraft:brown_terracotta
fill 277 83 479 277 85 480 minecraft:black_concrete
fill 277 83 481 277 84 481 minecraft:brown_terracotta
fill 277 83 482 277 83 485 minecraft:black_concrete
setblock 277 83 486 minecraft:brown_terracotta
fill 277 83 487 277 83 498 minecraft:black_concrete
fill 277 83 500 277 85 505 minecraft:black_concrete
fill 235 84 473 235 85 473 minecraft:black_concrete
fill 235 84 476 235 85 476 minecraft:black_concrete
fill 235 84 478 235 85 478 minecraft:black_concrete
fill 235 84 483 235 85 489 minecraft:black_concrete
setblock 235 84 490 minecraft:brown_terracotta
fill 235 84 491 235 85 494 minecraft:black_concrete
fill 236 84 463 239 85 463 minecraft:black_concrete
setblock 236 84 491 minecraft:brown_terracotta
setblock 236 84 492 minecraft:bone_block
fill 236 84 493 236 87 493 minecraft:brown_terracotta
setblock 236 84 497 minecraft:bone_block
fill 236 84 498 236 87 498 minecraft:brown_terracotta
setblock 237 84 496 minecraft:bone_block
fill 237 84 497 237 87 497 minecraft:brown_terracotta
fill 239 84 505 239 85 505 minecraft:black_concrete
setblock 240 84 463 minecraft:brown_terracotta
setblock 240 84 505 minecraft:brown_terracotta
fill 241 84 463 249 85 463 minecraft:black_concrete
fill 241 84 505 241 85 505 minecraft:black_concrete
setblock 242 84 505 minecraft:brown_terracotta
fill 243 84 505 251 85 505 minecraft:black_concrete
setblock 250 84 463 minecraft:brown_terracotta
fill 251 84 463 251 85 463 minecraft:black_concrete
fill 253 84 505 253 85 505 minecraft:black_concrete
setblock 254 84 505 minecraft:brown_terracotta
fill 255 84 463 256 85 463 minecraft:black_concrete
fill 255 84 505 256 85 505 minecraft:black_concrete
setblock 257 84 463 minecraft:brown_terracotta
setblock 257 84 505 minecraft:brown_terracotta
fill 258 84 463 259 85 463 minecraft:black_concrete
fill 258 84 505 258 85 505 minecraft:black_concrete
setblock 259 84 505 minecraft:brown_terracotta
setblock 260 84 463 minecraft:brown_terracotta
fill 260 84 505 260 85 505 minecraft:black_concrete
fill 261 84 463 266 85 463 minecraft:black_concrete
fill 261 84 464 263 84 464 minecraft:brown_terracotta
fill 262 84 504 263 84 504 minecraft:brown_terracotta
fill 262 84 505 262 85 505 minecraft:black_concrete
fill 263 84 505 264 84 505 minecraft:brown_terracotta
setblock 264 84 464 minecraft:bone_block
fill 264 84 465 264 87 465 minecraft:brown_terracotta
setblock 264 84 503 minecraft:brown_terracotta
setblock 264 84 504 minecraft:bone_block
fill 265 84 464 265 87 464 minecraft:brown_terracotta
setblock 265 84 503 minecraft:bone_block
fill 265 84 504 266 86 504 minecraft:brown_terracotta
fill 265 84 505 266 85 505 minecraft:black_concrete
fill 266 84 503 266 87 503 minecraft:brown_terracotta
setblock 269 84 464 minecraft:bone_block
setblock 269 84 504 minecraft:bone_block
setblock 270 84 464 minecraft:brown_terracotta
fill 270 84 504 270 87 504 minecraft:brown_terracotta
fill 273 84 463 275 85 463 minecraft:black_concrete
setblock 275 84 498 minecraft:bone_block
fill 276 84 463 277 84 463 minecraft:brown_terracotta
setblock 276 84 493 minecraft:brown_terracotta
setblock 276 84 497 minecraft:bone_block
fill 276 84 498 276 86 499 minecraft:brown_terracotta
setblock 276 84 502 minecraft:bone_block
fill 276 84 505 276 85 505 minecraft:black_concrete
fill 277 84 464 277 85 467 minecraft:black_concrete
setblock 277 84 468 minecraft:brown_terracotta
fill 277 84 469 277 85 478 minecraft:black_concrete
fill 277 84 482 277 85 483 minecraft:black_concrete
setblock 277 84 484 minecraft:brown_terracotta
fill 277 84 485 277 85 493 minecraft:black_concrete
fill 277 84 494 277 84 495 minecraft:brown_terracotta
fill 277 84 496 277 85 499 minecraft:black_concrete
setblock 235 85 469 minecraft:black_concrete
setblock 235 85 490 minecraft:black_concrete
fill 236 85 492 236 88 492 minecraft:brown_terracotta
setblock 236 85 496 minecraft:bone_block
fill 236 85 497 236 88 497 minecraft:brown_terracotta
setblock 236 85 501 minecraft:bone_block
setblock 237 85 495 minecraft:bone_block
fill 237 85 496 237 88 496 minecraft:brown_terracotta
setblock 240 85 463 minecraft:black_concrete
setblock 240 85 505 minecraft:black_concrete
fill 242 85 505 242 86 505 minecraft:black_concrete
setblock 250 85 463 minecraft:black_concrete
setblock 254 85 505 minecraft:black_concrete
fill 257 85 463 257 86 463 minecraft:black_concrete
setblock 257 85 505 minecraft:black_concrete
setblock 259 85 505 minecraft:black_concrete
setblock 260 85 463 minecraft:black_concrete
fill 260 85 464 262 85 464 minecraft:brown_terracotta
fill 261 85 504 262 85 504 minecraft:brown_terracotta
setblock 263 85 464 minecraft:bone_block
setblock 263 85 503 minecraft:brown_terracotta
setblock 263 85 504 minecraft:bone_block
fill 263 85 505 264 85 505 minecraft:black_concrete
fill 264 85 464 264 88 464 minecraft:brown_terracotta
setblock 264 85 503 minecraft:bone_block
fill 264 85 504 264 88 504 minecraft:brown_terracotta
fill 265 85 503 265 88 503 minecraft:brown_terracotta
setblock 268 85 464 minecraft:bone_block
setblock 268 85 504 minecraft:bone_block
fill 269 85 464 269 88 464 minecraft:brown_terracotta
setblock 269 85 503 minecraft:bone_block
fill 269 85 504 269 88 504 minecraft:brown_terracotta
fill 275 85 498 275 88 498 minecraft:brown_terracotta
fill 276 85 463 277 85 463 minecraft:black_concrete
setblock 276 85 496 minecraft:bone_block
fill 276 85 497 276 88 497 minecraft:brown_terracotta
setblock 276 85 501 minecraft:bone_block
fill 276 85 502 276 87 503 minecraft:brown_terracotta
setblock 277 85 468 minecraft:black_concrete
setblock 277 85 481 minecraft:black_concrete
setblock 277 85 484 minecraft:black_concrete
fill 277 85 494 277 85 495 minecraft:black_concrete
fill 235 86 463 246 86 463 minecraft:brown_terracotta
setblock 235 86 464 minecraft:black_concrete
fill 235 86 465 235 86 482 minecraft:brown_terracotta
setblock 235 86 483 minecraft:black_concrete
fill 235 86 484 235 149 484 minecraft:brown_terracotta
setblock 235 86 485 minecraft:black_concrete
setblock 235 86 486 minecraft:brown_terracotta
setblock 235 86 487 minecraft:black_concrete
fill 235 86 488 235 86 493 minecraft:brown_terracotta
setblock 235 86 494 minecraft:black_concrete
fill 235 86 495 235 86 505 minecraft:brown_terracotta
setblock 236 86 495 minecraft:bone_block
fill 236 86 496 236 89 496 minecraft:brown_terracotta
setblock 236 86 500 minecraft:bone_block
fill 236 86 501 236 88 502 minecraft:brown_terracotta
fill 236 86 505 237 86 505 minecraft:brown_terracotta
fill 237 86 495 237 89 495 minecraft:brown_terracotta
setblock 237 86 499 minecraft:bone_block
setblock 238 86 505 minecraft:black_concrete
fill 239 86 505 241 86 505 minecraft:brown_terracotta
setblock 242 86 504 minecraft:bone_block
fill 243 86 504 245 87 504 minecraft:brown_terracotta
setblock 243 86 505 minecraft:black_concrete
fill 244 86 505 250 87 505 minecraft:brown_terracotta
fill 247 86 463 247 87 463 minecraft:black_concrete
fill 248 86 463 256 86 463 minecraft:brown_terracotta
fill 251 86 505 251 87 505 minecraft:black_concrete
fill 252 86 505 255 87 505 minecraft:brown_terracotta
setblock 256 86 505 minecraft:black_concrete
fill 257 86 505 265 86 505 minecraft:brown_terracotta
fill 258 86 463 260 86 463 minecraft:brown_terracotta
fill 260 86 464 261 86 464 minecraft:brown_terracotta
fill 260 86 504 261 86 504 minecraft:brown_terracotta
fill 261 86 463 261 87 463 minecraft:black_concrete
fill 262 86 463 276 87 463 minecraft:brown_terracotta
setblock 262 86 464 minecraft:bone_block
setblock 262 86 503 minecraft:brown_terracotta
setblock 262 86 504 minecraft:bone_block
fill 263 86 464 263 88 465 minecraft:brown_terracotta
setblock 263 86 503 minecraft:bone_block
fill 263 86 504 263 89 504 minecraft:brown_terracotta
fill 264 86 503 264 89 503 minecraft:brown_terracotta
fill 265 86 502 266 88 502 minecraft:brown_terracotta
setblock 266 86 505 minecraft:black_concrete
setblock 267 86 464 minecraft:bone_block
setblock 267 86 504 minecraft:bone_block
fill 267 86 505 268 193 505 minecraft:brown_terracotta
fill 268 86 464 268 89 464 minecraft:brown_terracotta
setblock 268 86 503 minecraft:bone_block
fill 268 86 504 268 89 504 minecraft:brown_terracotta
fill 269 86 503 270 88 503 minecraft:brown_terracotta
setblock 269 86 505 minecraft:black_concrete
fill 270 86 505 277 86 505 minecraft:brown_terracotta
setblock 272 86 504 minecraft:bone_block
fill 273 86 504 273 89 504 minecraft:brown_terracotta
fill 275 86 499 275 86 500 minecraft:brown_terracotta
setblock 276 86 495 minecraft:bone_block
fill 276 86 496 277 89 496 minecraft:brown_terracotta
setblock 276 86 500 minecraft:bone_block
fill 276 86 501 277 89 501 minecraft:brown_terracotta
fill 277 86 463 277 87 463 minecraft:black_concrete
fill 277 86 464 277 86 491 minecraft:brown_terracotta
setblock 277 86 492 minecraft:black_concrete
fill 277 86 493 277 86 495 minecraft:brown_terracotta
setblock 277 86 497 minecraft:black_concrete
fill 277 86 498 277 196 500 minecraft:brown_terracotta
fill 277 86 502 277 86 504 minecraft:brown_terracotta
fill 235 87 463 235 88 463 minecraft:black_concrete
fill 235 87 464 235 194 464 minecraft:brown_terracotta
setblock 235 87 465 minecraft:black_concrete
fill 235 87 466 235 87 471 minecraft:brown_terracotta
setblock 235 87 472 minecraft:black_concrete
fill 235 87 473 235 192 478 minecraft:brown_terracotta
setblock 235 87 479 minecraft:black_concrete
fill 235 87 480 235 87 483 minecraft:brown_terracotta
fill 235 87 485 235 149 485 minecraft:brown_terracotta
setblock 235 87 486 minecraft:black_concrete
fill 235 87 487 235 149 489 minecraft:brown_terracotta
setblock 235 87 490 minecraft:black_concrete
fill 235 87 491 235 193 504 minecraft:brown_terracotta
setblock 235 87 505 minecraft:black_concrete
fill 236 87 463 246 87 463 minecraft:brown_terracotta
fill 236 87 476 236 87 478 minecraft:brown_terracotta
setblock 236 87 479 minecraft:bone_block
fill 236 87 480 236 88 482 minecraft:brown_terracotta
setblock 236 87 494 minecraft:bone_block
fill 236 87 495 236 90 495 minecraft:brown_terracotta
setblock 236 87 499 minecraft:bone_block
fill 236 87 500 237 89 500 minecraft:brown_terracotta
fill 236 87 505 236 194 505 minecraft:brown_terracotta
setblock 237 87 498 minecraft:bone_block
fill 237 87 499 237 90 499 minecraft:brown_terracotta
fill 237 87 505 237 88 505 minecraft:black_concrete
fill 238 87 505 240 87 505 minecraft:brown_terracotta
fill 239 87 504 240 87 504 minecraft:brown_terracotta
setblock 241 87 504 minecraft:bone_block
setblock 241 87 505 minecraft:black_concrete
fill 242 87 504 242 90 505 minecraft:brown_terracotta
fill 243 87 505 243 196 505 minecraft:brown_terracotta
setblock 246 87 504 minecraft:bone_block
fill 248 87 463 249 87 463 minecraft:brown_terracotta
fill 250 87 463 251 87 463 minecraft:black_concrete
fill 252 87 463 257 87 463 minecraft:brown_terracotta
fill 256 87 505 261 87 505 minecraft:brown_terracotta
fill 258 87 463 260 87 463 minecraft:black_concrete
fill 259 87 464 260 87 464 minecraft:brown_terracotta
fill 259 87 504 260 87 504 minecraft:brown_terracotta
fill 260 87 503 261 87 503 minecraft:brown_terracotta
setblock 261 87 464 minecraft:bone_block
fill 261 87 465 262 89 465 minecraft:brown_terracotta
setblock 261 87 504 minecraft:bone_block
fill 262 87 464 262 90 464 minecraft:brown_terracotta
setblock 262 87 503 minecraft:bone_block
fill 262 87 504 262 90 504 minecraft:brown_terracotta
setblock 262 87 505 minecraft:black_concrete
setblock 263 87 502 minecraft:bone_block
fill 263 87 503 263 90 503 minecraft:brown_terracotta
fill 263 87 505 266 192 505 minecraft:brown_terracotta
fill 264 87 502 264 90 502 minecraft:brown_terracotta
setblock 265 87 465 minecraft:bone_block
setblock 265 87 504 minecraft:brown_terracotta
setblock 266 87 464 minecraft:bone_block
setblock 266 87 504 minecraft:bone_block
fill 267 87 464 267 90 464 minecraft:brown_terracotta
setblock 267 87 502 minecraft:brown_terracotta
setblock 267 87 503 minecraft:bone_block
fill 267 87 504 267 90 504 minecraft:brown_terracotta
fill 268 87 503 268 90 503 minecraft:brown_terracotta
fill 269 87 505 276 87 505 minecraft:brown_terracotta
setblock 271 87 503 minecraft:brown_terracotta
setblock 271 87 504 minecraft:bone_block
fill 272 87 504 272 90 504 minecraft:brown_terracotta
fill 274 87 504 275 87 504 minecraft:brown_terracotta
fill 275 87 497 275 89 497 minecraft:brown_terracotta
setblock 275 87 499 minecraft:brown_terracotta
setblock 275 87 500 minecraft:bone_block
fill 275 87 501 275 90 501 minecraft:brown_terracotta
setblock 276 87 494 minecraft:bone_block
fill 276 87 495 277 90 495 minecraft:brown_terracotta
setblock 276 87 498 minecraft:brown_terracotta
setblock 276 87 499 minecraft:bone_block
fill 276 87 500 276 90 500 minecraft:brown_terracotta
setblock 276 87 504 minecraft:bone_block
fill 277 87 464 277 87 466 minecraft:brown_terracotta
setblock 277 87 467 minecraft:black_concrete
fill 277 87 468 277 192 473 minecraft:brown_terracotta
setblock 277 87 474 minecraft:black_concrete
fill 277 87 475 277 87 484 minecraft:brown_terracotta
setblock 277 87 485 minecraft:black_concrete
fill 277 87 486 277 87 493 minecraft:brown_terracotta
fill 277 87 494 277 88 494 minecraft:black_concrete
fill 277 87 497 277 196 497 minecraft:brown_terracotta
fill 277 87 502 277 192 503 minecraft:brown_terracotta
fill 277 87 504 277 87 505 minecraft:black_concrete
fill 235 88 465 235 193 468 minecraft:brown_terracotta
setblock 235 88 469 minecraft:black_concrete
fill 235 88 470 235 193 472 minecraft:brown_terracotta
fill 235 88 479 235 196 480 minecraft:brown_terracotta
setblock 235 88 481 minecraft:black_concrete
fill 235 88 482 235 196 483 minecraft:brown_terracotta
fill 235 88 486 235 149 486 minecraft:brown_terracotta
fill 235 88 490 235 196 490 minecraft:brown_terracotta
fill 235 88 505 235 196 505 minecraft:brown_terracotta
fill 236 88 463 240 192 463 minecraft:brown_terracotta
fill 236 88 476 236 88 477 minecraft:brown_terracotta
setblock 236 88 478 minecraft:bone_block
fill 236 88 479 237 90 479 minecraft:brown_terracotta
setblock 236 88 483 minecraft:bone_block
fill 236 88 484 236 90 485 minecraft:brown_terracotta
setblock 236 88 493 minecraft:bone_block
fill 236 88 494 236 91 494 minecraft:brown_terracotta
setblock 236 88 498 minecraft:bone_block
fill 236 88 499 236 91 499 minecraft:brown_terracotta
setblock 236 88 503 minecraft:bone_block
setblock 237 88 477 minecraft:bone_block
fill 237 88 478 237 91 478 minecraft:brown_terracotta
fill 237 88 480 237 88 481 minecraft:brown_terracotta
setblock 237 88 482 minecraft:bone_block
setblock 237 88 497 minecraft:bone_block
fill 237 88 498 237 91 498 minecraft:brown_terracotta
setblock 237 88 501 minecraft:brown_terracotta
fill 237 88 504 239 88 504 minecraft:brown_terracotta
setblock 238 88 466 minecraft:light[level=12]
setblock 238 88 474 minecraft:light[level=12]
setblock 238 88 482 minecraft:light[level=12]
setblock 238 88 490 minecraft:light[level=12]
setblock 238 88 498 minecraft:light[level=12]
fill 238 88 505 239 196 505 minecraft:brown_terracotta
setblock 240 88 503 minecraft:brown_terracotta
setblock 240 88 504 minecraft:bone_block
setblock 240 88 505 minecraft:black_concrete
setblock 241 88 463 minecraft:black_concrete
setblock 241 88 503 minecraft:bone_block
fill 241 88 504 241 91 505 minecraft:brown_terracotta
fill 242 88 463 247 193 463 minecraft:brown_terracotta
fill 242 88 503 244 89 503 minecraft:brown_terracotta
fill 243 88 504 244 88 504 minecraft:brown_terracotta
fill 244 88 505 244 196 505 minecraft:brown_terracotta
setblock 245 88 504 minecraft:bone_block
setblock 245 88 505 minecraft:black_concrete
setblock 246 88 466 minecraft:light[level=12]
setblock 246 88 474 minecraft:light[level=12]
setblock 246 88 482 minecraft:light[level=12]
setblock 246 88 490 minecraft:light[level=12]
setblock 246 88 498 minecraft:light[level=12]
fill 246 88 504 246 91 505 minecraft:brown_terracotta
fill 247 88 505 249 192 505 minecraft:brown_terracotta
fill 248 88 463 249 88 463 minecraft:black_concrete
fill 250 88 463 254 193 463 minecraft:brown_terracotta
setblock 250 88 505 minecraft:black_concrete
fill 251 88 505 254 196 505 minecraft:brown_terracotta
setblock 254 88 466 minecraft:light[level=12]
setblock 254 88 474 minecraft:light[level=12]
setblock 254 88 482 minecraft:light[level=12]
setblock 254 88 490 minecraft:light[level=12]
setblock 254 88 498 minecraft:light[level=12]
setblock 255 88 463 minecraft:black_concrete
setblock 255 88 505 minecraft:black_concrete
fill 256 88 463 256 196 463 minecraft:brown_terracotta
fill 256 88 505 256 193 505 minecraft:brown_terracotta
setblock 257 88 463 minecraft:black_concrete
fill 257 88 464 259 88 464 minecraft:brown_terracotta
fill 257 88 504 259 88 504 minecraft:brown_terracotta
setblock 257 88 505 minecraft:black_concrete
fill 258 88 463 274 192 463 minecraft:brown_terracotta
fill 258 88 505 259 196 505 minecraft:brown_terracotta
fill 259 88 503 260 88 503 minecraft:brown_terracotta
setblock 260 88 464 minecraft:bone_block
fill 260 88 465 260 91 465 minecraft:brown_terracotta
setblock 260 88 504 minecraft:bone_block
setblock 260 88 505 minecraft:black_concrete
fill 261 88 464 261 91 464 minecraft:brown_terracotta
setblock 261 88 502 minecraft:brown_terracotta
setblock 261 88 503 minecraft:bone_block
fill 261 88 504 261 91 505 minecraft:brown_terracotta
setblock 262 88 466 minecraft:light[level=12]
setblock 262 88 474 minecraft:light[level=12]
setblock 262 88 482 minecraft:light[level=12]
setblock 262 88 490 minecraft:light[level=12]
setblock 262 88 498 minecraft:light[level=12]
setblock 262 88 502 minecraft:bone_block
fill 262 88 503 262 91 503 minecraft:brown_terracotta
fill 262 88 505 262 197 505 minecraft:brown_terracotta
fill 263 88 502 263 91 502 minecraft:brown_terracotta
setblock 264 88 465 minecraft:bone_block
setblock 265 88 464 minecraft:bone_block
fill 265 88 465 266 90 465 minecraft:brown_terracotta
setblock 265 88 504 minecraft:bone_block
fill 266 88 464 266 91 464 minecraft:brown_terracotta
setblock 266 88 503 minecraft:bone_block
fill 266 88 504 266 91 504 minecraft:brown_terracotta
setblock 267 88 502 minecraft:bone_block
fill 267 88 503 267 91 503 minecraft:brown_terracotta
fill 268 88 502 268 91 502 minecraft:brown_terracotta
fill 269 88 505 274 193 505 minecraft:brown_terracotta
setblock 270 88 466 minecraft:light[level=12]
setblock 270 88 474 minecraft:light[level=12]
setblock 270 88 482 minecraft:light[level=12]
setblock 270 88 490 minecraft:light[level=12]
setblock 270 88 498 minecraft:light[level=12]
setblock 270 88 504 minecraft:bone_block
setblock 271 88 503 minecraft:bone_block
fill 271 88 504 271 91 504 minecraft:brown_terracotta
fill 272 88 503 273 90 503 minecraft:brown_terracotta
setblock 274 88 504 minecraft:brown_terracotta
setblock 275 88 463 minecraft:black_concrete
setblock 275 88 499 minecraft:bone_block
fill 275 88 500 275 91 500 minecraft:brown_terracotta
fill 275 88 502 275 88 503 minecraft:brown_terracotta
setblock 275 88 504 minecraft:bone_block
setblock 275 88 505 minecraft:black_concrete
fill 276 88 463 277 192 463 minecraft:brown_terracotta
setblock 276 88 493 minecraft:bone_block
fill 276 88 494 276 91 494 minecraft:brown_terracotta
setblock 276 88 498 minecraft:bone_block
fill 276 88 499 276 91 499 minecraft:brown_terracotta
setblock 276 88 502 minecraft:brown_terracotta
setblock 276 88 503 minecraft:bone_block
fill 276 88 504 276 91 505 minecraft:brown_terracotta
fill 277 88 464 277 196 464 minecraft:brown_terracotta
setblock 277 88 465 minecraft:black_concrete
fill 277 88 466 277 194 467 minecraft:brown_terracotta
fill 277 88 474 277 194 478 minecraft:brown_terracotta
setblock 277 88 479 minecraft:black_concrete
fill 277 88 480 277 194 480 minecraft:brown_terracotta
setblock 277 88 481 minecraft:black_concrete
fill 277 88 482 277 192 485 minecraft:brown_terracotta
setblock 277 88 486 minecraft:black_concrete
fill 277 88 487 277 192 493 minecraft:brown_terracotta
setblock 277 88 504 minecraft:black_concrete
fill 277 88 505 277 194 505 minecraft:brown_terracotta
fill 235 89 463 235 197 463 minecraft:brown_terracotta
fill 235 89 469 235 196 469 minecraft:brown_terracotta
fill 235 89 481 236 89 481 minecraft:brown_terracotta
fill 236 89 475 236 89 476 minecraft:brown_terracotta
setblock 236 89 477 minecraft:bone_block
fill 236 89 478 236 92 478 minecraft:brown_terracotta
fill 236 89 480 237 89 480 minecraft:brown_terracotta
setblock 236 89 482 minecraft:bone_block
fill 236 89 483 238 90 483 minecraft:brown_terracotta
setblock 236 89 486 minecraft:brown_terracotta
setblock 236 89 487 minecraft:bone_block
fill 236 89 488 236 89 491 minecraft:brown_terracotta
setblock 236 89 492 minecraft:bone_block
fill 236 89 493 236 92 493 minecraft:brown_terracotta
setblock 236 89 497 minecraft:bone_block
fill 236 89 498 236 92 498 minecraft:brown_terracotta
setblock 236 89 501 minecraft:brown_terracotta
setblock 236 89 502 minecraft:bone_block
fill 236 89 503 238 89 504 minecraft:brown_terracotta
setblock 237 89 476 minecraft:bone_block
fill 237 89 477 237 92 477 minecraft:brown_terracotta
setblock 237 89 481 minecraft:bone_block
fill 237 89 482 238 91 482 minecraft:brown_terracotta
fill 237 89 484 237 89 485 minecraft:brown_terracotta
fill 237 89 494 237 90 494 minecraft:brown_terracotta
setblock 237 89 496 minecraft:bone_block
fill 237 89 497 237 92 497 minecraft:brown_terracotta
setblock 237 89 501 minecraft:bone_block
fill 237 89 502 237 92 502 minecraft:brown_terracotta
fill 237 89 505 237 194 505 minecraft:brown_terracotta
fill 238 89 478 238 89 479 minecraft:brown_terracotta
setblock 238 89 480 minecraft:bone_block
fill 238 89 481 238 92 481 minecraft:brown_terracotta
setblock 239 89 503 minecraft:brown_terracotta
setblock 239 89 504 minecraft:bone_block
setblock 240 89 503 minecraft:bone_block
fill 240 89 504 240 92 505 minecraft:brown_terracotta
fill 241 89 463 241 91 464 minecraft:brown_terracotta
fill 241 89 503 241 92 503 minecraft:brown_terracotta
fill 242 89 464 243 89 464 minecraft:brown_terracotta
setblock 243 89 504 minecraft:brown_terracotta
setblock 244 89 464 minecraft:bone_block
setblock 244 89 504 minecraft:bone_block
fill 245 89 464 246 91 464 minecraft:brown_terracotta
setblock 245 89 503 minecraft:bone_block
fill 245 89 504 245 92 505 minecraft:brown_terracotta
fill 247 89 504 247 90 504 minecraft:brown_terracotta
fill 248 89 463 249 196 463 minecraft:brown_terracotta
fill 250 89 505 250 193 505 minecraft:brown_terracotta
fill 255 89 463 255 92 464 minecraft:brown_terracotta
fill 255 89 505 255 193 505 minecraft:brown_terracotta
fill 256 89 464 258 89 464 minecraft:brown_terracotta
fill 256 89 504 258 89 504 minecraft:brown_terracotta
fill 257 89 463 257 196 463 minecraft:brown_terracotta
fill 257 89 505 257 196 505 minecraft:brown_terracotta
setblock 258 89 465 minecraft:bone_block
fill 258 89 503 259 89 503 minecraft:brown_terracotta
setblock 259 89 464 minecraft:bone_block
fill 259 89 465 259 92 465 minecraft:brown_terracotta
setblock 259 89 504 minecraft:bone_block
fill 260 89 464 260 92 464 minecraft:brown_terracotta
setblock 260 89 502 minecraft:brown_terracotta
setblock 260 89 503 minecraft:bone_block
fill 260 89 504 260 92 505 minecraft:brown_terracotta
setblock 261 89 502 minecraft:bone_block
fill 261 89 503 261 92 503 minecraft:brown_terracotta
fill 262 89 502 262 92 502 minecraft:brown_terracotta
setblock 263 89 464 minecraft:brown_terracotta
setblock 263 89 465 minecraft:bone_block
fill 263 89 501 265 90 501 minecraft:brown_terracotta
setblock 264 89 464 minecraft:bone_block
fill 264 89 465 264 92 465 minecraft:brown_terracotta
setblock 264 89 504 minecraft:bone_block
fill 265 89 464 265 92 464 minecraft:brown_terracotta
setblock 265 89 502 minecraft:brown_terracotta
setblock 265 89 503 minecraft:bone_block
fill 265 89 504 265 92 504 minecraft:brown_terracotta
setblock 266 89 502 minecraft:bone_block
fill 266 89 503 266 92 503 minecraft:brown_terracotta
fill 267 89 502 267 92 502 minecraft:brown_terracotta
setblock 269 89 464 minecraft:bone_block
fill 269 89 502 269 89 503 minecraft:brown_terracotta
setblock 269 89 504 minecraft:bone_block
setblock 270 89 503 minecraft:bone_block
fill 270 89 504 270 92 504 minecraft:brown_terracotta
fill 271 89 503 271 92 503 minecraft:brown_terracotta
setblock 274 89 503 minecraft:brown_terracotta
setblock 274 89 504 minecraft:bone_block
fill 275 89 463 275 196 463 minecraft:brown_terracotta
fill 275 89 496 275 90 496 minecraft:brown_terracotta
setblock 275 89 498 minecraft:bone_block
fill 275 89 499 275 92 499 minecraft:brown_terracotta
setblock 275 89 502 minecraft:brown_terracotta
setblock 275 89 503 minecraft:bone_block
fill 275 89 504 275 92 505 minecraft:brown_terracotta
fill 276 89 478 276 89 481 minecraft:brown_terracotta
setblock 276 89 482 minecraft:bone_block
fill 276 89 493 276 92 493 minecraft:brown_terracotta
setblock 276 89 497 minecraft:bone_block
fill 276 89 498 276 92 498 minecraft:brown_terracotta
setblock 276 89 502 minecraft:bone_block
fill 276 89 503 276 92 503 minecraft:brown_terracotta
fill 277 89 465 277 196 465 minecraft:brown_terracotta
fill 277 89 479 277 193 479 minecraft:brown_terracotta
fill 277 89 481 277 197 481 minecraft:brown_terracotta
fill 277 89 486 277 196 486 minecraft:brown_terracotta
fill 277 89 494 277 196 494 minecraft:brown_terracotta
fill 277 89 504 277 196 504 minecraft:brown_terracotta
fill 235 90 481 235 196 481 minecraft:brown_terracotta
fill 236 90 474 236 90 475 minecraft:brown_terracotta
setblock 236 90 476 minecraft:bone_block
fill 236 90 477 236 93 477 minecraft:brown_terracotta
setblock 236 90 480 minecraft:brown_terracotta
setblock 236 90 481 minecraft:bone_block
fill 236 90 482 236 93 482 minecraft:brown_terracotta
setblock 236 90 486 minecraft:bone_block
fill 236 90 487 236 90 490 minecraft:brown_terracotta
setblock 236 90 491 minecraft:bone_block
fill 236 90 492 236 93 492 minecraft:brown_terracotta
setblock 236 90 496 minecraft:bone_block
fill 236 90 497 236 93 497 minecraft:brown_terracotta
setblock 236 90 500 minecraft:brown_terracotta
setblock 236 90 501 minecraft:bone_block
fill 236 90 502 236 91 504 minecraft:brown_terracotta
setblock 237 90 475 minecraft:bone_block
fill 237 90 476 237 93 476 minecraft:brown_terracotta
setblock 237 90 480 minecraft:bone_block
fill 237 90 481 237 93 481 minecraft:brown_terracotta
setblock 237 90 484 minecraft:brown_terracotta
setblock 237 90 485 minecraft:bone_block
fill 237 90 486 237 91 488 minecraft:brown_terracotta
fill 237 90 493 237 91 493 minecraft:brown_terracotta
setblock 237 90 495 minecraft:bone_block
fill 237 90 496 237 93 496 minecraft:brown_terracotta
setblock 237 90 500 minecraft:bone_block
fill 237 90 501 238 92 501 minecraft:brown_terracotta
fill 237 90 503 237 90 504 minecraft:brown_terracotta
fill 238 90 477 238 90 478 minecraft:brown_terracotta
setblock 238 90 479 minecraft:bone_block
fill 238 90 480 239 92 480 minecraft:brown_terracotta
setblock 238 90 484 minecraft:bone_block
fill 238 90 485 238 92 486 minecraft:brown_terracotta
setblock 238 90 498 minecraft:brown_terracotta
setblock 238 90 499 minecraft:bone_block
fill 238 90 500 238 93 500 minecraft:brown_terracotta
setblock 238 90 503 minecraft:brown_terracotta
setblock 238 90 504 minecraft:bone_block
fill 239 90 464 240 92 464 minecraft:brown_terracotta
setblock 239 90 478 minecraft:bone_block
fill 239 90 479 239 93 479 minecraft:brown_terracotta
fill 239 90 481 239 90 482 minecraft:brown_terracotta
setblock 239 90 483 minecraft:bone_block
setblock 239 90 502 minecraft:brown_terracotta
setblock 239 90 503 minecraft:bone_block
fill 239 90 504 239 93 504 minecraft:brown_terracotta
setblock 240 90 502 minecraft:bone_block
fill 240 90 503 240 93 503 minecraft:brown_terracotta
fill 241 90 502 242 92 502 minecraft:brown_terracotta
setblock 242 90 464 minecraft:brown_terracotta
fill 242 90 503 243 90 503 minecraft:brown_terracotta
setblock 243 90 464 minecraft:bone_block
setblock 243 90 504 minecraft:bone_block
fill 244 90 464 244 93 464 minecraft:brown_terracotta
setblock 244 90 503 minecraft:bone_block
fill 244 90 504 244 93 504 minecraft:brown_terracotta
fill 245 90 503 245 93 503 minecraft:brown_terracotta
setblock 247 90 464 minecraft:brown_terracotta
setblock 248 90 464 minecraft:bone_block
setblock 248 90 504 minecraft:bone_block
setblock 253 90 464 minecraft:bone_block
fill 254 90 464 254 93 464 minecraft:brown_terracotta
fill 254 90 504 257 90 504 minecraft:brown_terracotta
fill 256 90 464 257 90 464 minecraft:brown_terracotta
fill 256 90 503 258 90 503 minecraft:brown_terracotta
setblock 257 90 465 minecraft:bone_block
setblock 258 90 464 minecraft:bone_block
fill 258 90 465 258 93 465 minecraft:brown_terracotta
fill 258 90 502 259 90 502 minecraft:brown_terracotta
setblock 258 90 504 minecraft:bone_block
fill 259 90 464 259 93 464 minecraft:brown_terracotta
setblock 259 90 503 minecraft:bone_block
fill 259 90 504 259 93 504 minecraft:brown_terracotta
setblock 260 90 466 minecraft:brown_terracotta
setblock 260 90 502 minecraft:bone_block
fill 260 90 503 260 93 503 minecraft:brown_terracotta
setblock 261 90 465 minecraft:brown_terracotta
setblock 261 90 466 minecraft:bone_block
setblock 261 90 501 minecraft:bone_block
fill 261 90 502 261 93 502 minecraft:brown_terracotta
setblock 262 90 465 minecraft:bone_block
fill 262 90 466 263 92 466 minecraft:brown_terracotta
fill 262 90 501 262 93 501 minecraft:brown_terracotta
setblock 263 90 464 minecraft:bone_block
fill 263 90 465 263 93 465 minecraft:brown_terracotta
setblock 263 90 504 minecraft:bone_block
fill 264 90 464 264 93 464 minecraft:brown_terracotta
setblock 264 90 503 minecraft:bone_block
fill 264 90 504 264 93 504 minecraft:brown_terracotta
setblock 265 90 502 minecraft:bone_block
fill 265 90 503 265 93 503 minecraft:brown_terracotta
setblock 266 90 501 minecraft:bone_block
fill 266 90 502 266 93 502 minecraft:brown_terracotta
setblock 267 90 465 minecraft:bone_block
setblock 268 90 464 minecraft:bone_block
setblock 268 90 504 minecraft:bone_block
fill 269 90 464 270 92 464 minecraft:brown_terracotta
setblock 269 90 502 minecraft:brown_terracotta
setblock 269 90 503 minecraft:bone_block
fill 269 90 504 269 93 504 minecraft:brown_terracotta
setblock 270 90 502 minecraft:bone_block
fill 270 90 503 270 93 503 minecraft:brown_terracotta
setblock 273 90 504 minecraft:bone_block
fill 274 90 500 274 91 501 minecraft:brown_terracotta
setblock 274 90 503 minecraft:bone_block
fill 274 90 504 274 93 504 minecraft:brown_terracotta
setblock 275 90 497 minecraft:bone_block
fill 275 90 498 275 93 498 minecraft:brown_terracotta
setblock 275 90 502 minecraft:bone_block
fill 275 90 503 275 93 503 minecraft:brown_terracotta
fill 276 90 477 276 90 480 minecraft:brown_terracotta
setblock 276 90 481 minecraft:bone_block
fill 276 90 482 276 90 485 minecraft:brown_terracotta
setblock 276 90 486 minecraft:bone_block
fill 276 90 487 276 93 487 minecraft:brown_terracotta
setblock 276 90 491 minecraft:bone_block
fill 276 90 492 276 93 492 minecraft:brown_terracotta
setblock 276 90 496 minecraft:bone_block
fill 276 90 497 276 93 497 minecraft:brown_terracotta
setblock 276 90 501 minecraft:bone_block
fill 276 90 502 276 93 502 minecraft:brown_terracotta
fill 277 90 496 277 196 496 minecraft:brown_terracotta
fill 277 90 501 277 192 501 minecraft:brown_terracotta
setblock 236 91 474 minecraft:brown_terracotta
setblock 236 91 475 minecraft:bone_block
fill 236 91 476 236 94 476 minecraft:brown_terracotta
setblock 236 91 479 minecraft:brown_terracotta
setblock 236 91 480 minecraft:bone_block
fill 236 91 481 236 94 481 minecraft:brown_terracotta
fill 236 91 483 236 91 484 minecraft:brown_terracotta
setblock 236 91 485 minecraft:bone_block
fill 236 91 486 236 91 489 minecraft:brown_terracotta
setblock 236 91 490 minecraft:bone_block
fill 236 91 491 237 93 491 minecraft:brown_terracotta
setblock 236 91 495 minecraft:bone_block
fill 236 91 496 236 94 496 minecraft:brown_terracotta
setblock 236 91 500 minecraft:bone_block
fill 236 91 501 236 94 501 minecraft:brown_terracotta
setblock 237 91 464 minecraft:bone_block
fill 237 91 475 237 94 475 minecraft:brown_terracotta
setblock 237 91 479 minecraft:bone_block
fill 237 91 480 237 94 480 minecraft:brown_terracotta
setblock 237 91 483 minecraft:brown_terracotta
setblock 237 91 484 minecraft:bone_block
fill 237 91 485 237 94 485 minecraft:brown_terracotta
setblock 237 91 489 minecraft:bone_block
fill 237 91 490 237 94 490 minecraft:brown_terracotta
fill 237 91 492 237 92 492 minecraft:brown_terracotta
setblock 237 91 494 minecraft:bone_block
fill 237 91 495 237 94 495 minecraft:brown_terracotta
setblock 237 91 499 minecraft:bone_block
fill 237 91 500 237 94 500 minecraft:brown_terracotta
setblock 237 91 503 minecraft:brown_terracotta
setblock 237 91 504 minecraft:bone_block
fill 238 91 464 238 94 464 minecraft:brown_terracotta
fill 238 91 476 238 91 477 minecraft:brown_terracotta
setblock 238 91 478 minecraft:bone_block
fill 238 91 479 238 94 479 minecraft:brown_terracotta
setblock 238 91 483 minecraft:bone_block
fill 238 91 484 239 93 484 minecraft:brown_terracotta
setblock 238 91 487 minecraft:brown_terracotta
setblock 238 91 498 minecraft:bone_block
fill 238 91 499 238 93 499 minecraft:brown_terracotta
setblock 238 91 502 minecraft:brown_terracotta
setblock 238 91 503 minecraft:bone_block
fill 238 91 504 238 94 504 minecraft:brown_terracotta
fill 239 91 478 239 94 478 minecraft:brown_terracotta
setblock 239 91 481 minecraft:brown_terracotta
setblock 239 91 482 minecraft:bone_block
fill 239 91 483 239 94 483 minecraft:brown_terracotta
fill 239 91 485 239 92 485 minecraft:brown_terracotta
setblock 239 91 502 minecraft:bone_block
fill 239 91 503 239 94 503 minecraft:brown_terracotta
setblock 240 91 480 minecraft:brown_terracotta
setblock 240 91 481 minecraft:bone_block
fill 240 91 482 240 94 482 minecraft:brown_terracotta
fill 240 91 502 240 94 502 minecraft:brown_terracotta
setblock 242 91 464 minecraft:bone_block
fill 242 91 465 243 93 465 minecraft:brown_terracotta
setblock 242 91 503 minecraft:brown_terracotta
setblock 242 91 504 minecraft:bone_block
fill 242 91 505 242 196 505 minecraft:brown_terracotta
fill 243 91 464 243 94 464 minecraft:brown_terracotta
setblock 243 91 502 minecraft:brown_terracotta
setblock 243 91 503 minecraft:bone_block
fill 243 91 504 243 94 504 minecraft:brown_terracotta
fill 244 91 503 244 94 503 minecraft:brown_terracotta
fill 246 91 503 246 92 503 minecraft:brown_terracotta
setblock 247 91 464 minecraft:bone_block
setblock 247 91 504 minecraft:bone_block
fill 248 91 464 251 91 464 minecraft:brown_terracotta
fill 248 91 504 251 91 504 minecraft:brown_terracotta
setblock 252 91 464 minecraft:bone_block
setblock 252 91 504 minecraft:bone_block
fill 253 91 464 253 94 464 minecraft:brown_terracotta
fill 253 91 504 256 91 504 minecraft:brown_terracotta
setblock 255 91 465 minecraft:brown_terracotta
fill 255 91 503 257 91 503 minecraft:brown_terracotta
setblock 256 91 464 minecraft:brown_terracotta
setblock 256 91 465 minecraft:bone_block
setblock 257 91 464 minecraft:bone_block
fill 257 91 465 257 94 465 minecraft:brown_terracotta
fill 257 91 502 258 91 502 minecraft:brown_terracotta
setblock 257 91 504 minecraft:bone_block
fill 258 91 464 258 94 464 minecraft:brown_terracotta
fill 258 91 466 259 91 466 minecraft:brown_terracotta
setblock 258 91 503 minecraft:bone_block
fill 258 91 504 258 94 504 minecraft:brown_terracotta
setblock 259 91 502 minecraft:bone_block
fill 259 91 503 259 94 503 minecraft:brown_terracotta
setblock 260 91 466 minecraft:bone_block
setblock 260 91 501 minecraft:bone_block
fill 260 91 502 260 94 502 minecraft:brown_terracotta
setblock 261 91 465 minecraft:bone_block
fill 261 91 466 261 94 466 minecraft:brown_terracotta
fill 261 91 501 261 94 501 minecraft:brown_terracotta
setblock 262 91 464 minecraft:bone_block
fill 262 91 465 262 94 465 minecraft:brown_terracotta
setblock 262 91 504 minecraft:bone_block
fill 263 91 464 263 94 464 minecraft:brown_terracotta
fill 263 91 501 264 91 501 minecraft:brown_terracotta
setblock 263 91 503 minecraft:bone_block
fill 263 91 504 263 94 504 minecraft:brown_terracotta
setblock 264 91 466 minecraft:brown_terracotta
setblock 264 91 502 minecraft:bone_block
fill 264 91 503 264 94 503 minecraft:brown_terracotta
setblock 265 91 465 minecraft:brown_terracotta
setblock 265 91 501 minecraft:bone_block
fill 265 91 502 265 94 502 minecraft:brown_terracotta
setblock 266 91 465 minecraft:bone_block
setblock 266 91 501 minecraft:brown_terracotta
setblock 267 91 464 minecraft:bone_block
fill 267 91 465 267 94 465 minecraft:brown_terracotta
setblock 267 91 504 minecraft:bone_block
fill 268 91 464 268 94 464 minecraft:brown_terracotta
setblock 268 91 503 minecraft:bone_block
fill 268 91 504 268 94 504 minecraft:brown_terracotta
setblock 269 91 502 minecraft:bone_block
fill 269 91 503 269 94 503 minecraft:brown_terracotta
fill 270 91 502 273 91 502 minecraft:brown_terracotta
setblock 271 91 464 minecraft:brown_terracotta
setblock 272 91 503 minecraft:brown_terracotta
setblock 272 91 504 minecraft:bone_block
setblock 273 91 503 minecraft:bone_block
fill 273 91 504 273 94 504 minecraft:brown_terracotta
fill 274 91 499 274 93 499 minecraft:brown_terracotta
setblock 274 91 502 minecraft:bone_block
fill 274 91 503 274 94 503 minecraft:brown_terracotta
fill 275 91 464 276 91 464 minecraft:brown_terracotta
setblock 275 91 495 minecraft:brown_terracotta
setblock 275 91 496 minecraft:bone_block
fill 275 91 497 275 94 497 minecraft:brown_terracotta
setblock 275 91 501 minecraft:bone_block
fill 275 91 502 275 94 502 minecraft:brown_terracotta
fill 276 91 476 276 91 479 minecraft:brown_terracotta
setblock 276 91 480 minecraft:bone_block
fill 276 91 481 276 91 484 minecraft:brown_terracotta
setblock 276 91 485 minecraft:bone_block
fill 276 91 486 276 94 486 minecraft:brown_terracotta
fill 276 91 488 276 91 489 minecraft:brown_terracotta
setblock 276 91 490 minecraft:bone_block
fill 276 91 491 276 94 491 minecraft:brown_terracotta
setblock 276 91 495 minecraft:bone_block
fill 276 91 496 276 94 496 minecraft:brown_terracotta
setblock 276 91 500 minecraft:bone_block
fill 276 91 501 276 94 501 minecraft:brown_terracotta
fill 277 91 495 277 196 495 minecraft:brown_terracotta
setblock 236 92 464 minecraft:bone_block
fill 236 92 465 236 95 465 minecraft:brown_terracotta
setblock 236 92 473 minecraft:brown_terracotta
setblock 236 92 474 minecraft:bone_block
fill 236 92 475 236 95 475 minecraft:brown_terracotta
setblock 236 92 479 minecraft:bone_block
fill 236 92 480 236 95 480 minecraft:brown_terracotta
setblock 236 92 483 minecraft:brown_terracotta
setblock 236 92 484 minecraft:bone_block
fill 236 92 485 236 92 488 minecraft:brown_terracotta
setblock 236 92 489 minecraft:bone_block
fill 236 92 490 236 95 490 minecraft:brown_terracotta
setblock 236 92 494 minecraft:bone_block
fill 236 92 495 236 95 495 minecraft:brown_terracotta
setblock 236 92 499 minecraft:bone_block
fill 236 92 500 236 95 500 minecraft:brown_terracotta
fill 236 92 502 236 92 503 minecraft:brown_terracotta
setblock 236 92 504 minecraft:bone_block
fill 237 92 464 237 95 464 minecraft:brown_terracotta
setblock 237 92 478 minecraft:bone_block
fill 237 92 479 237 95 479 minecraft:brown_terracotta
setblock 237 92 482 minecraft:brown_terracotta
setblock 237 92 483 minecraft:bone_block
fill 237 92 484 237 95 484 minecraft:brown_terracotta
fill 237 92 486 237 92 487 minecraft:brown_terracotta
setblock 237 92 488 minecraft:bone_block
fill 237 92 489 238 94 489 minecraft:brown_terracotta
setblock 237 92 493 minecraft:bone_block
fill 237 92 494 237 95 494 minecraft:brown_terracotta
setblock 237 92 498 minecraft:bone_block
fill 237 92 499 237 95 499 minecraft:brown_terracotta
setblock 237 92 503 minecraft:bone_block
fill 237 92 504 237 95 504 minecraft:brown_terracotta
setblock 238 92 476 minecraft:brown_terracotta
setblock 238 92 477 minecraft:bone_block
fill 238 92 478 238 95 478 minecraft:brown_terracotta
setblock 238 92 482 minecraft:bone_block
fill 238 92 483 238 95 483 minecraft:brown_terracotta
setblock 238 92 487 minecraft:bone_block
fill 238 92 488 238 95 488 minecraft:brown_terracotta
setblock 238 92 498 minecraft:brown_terracotta
setblock 238 92 502 minecraft:bone_block
fill 238 92 503 238 95 503 minecraft:brown_terracotta
setblock 239 92 465 minecraft:brown_terracotta
fill 239 92 477 239 93 477 minecraft:brown_terracotta
setblock 239 92 481 minecraft:bone_block
fill 239 92 482 239 95 482 minecraft:brown_terracotta
setblock 239 92 486 minecraft:bone_block
fill 239 92 502 239 94 502 minecraft:brown_terracotta
setblock 240 92 465 minecraft:bone_block
setblock 240 92 479 minecraft:brown_terracotta
setblock 240 92 480 minecraft:bone_block
fill 240 92 481 240 94 481 minecraft:brown_terracotta
fill 240 92 483 240 92 484 minecraft:brown_terracotta
fill 241 92 463 241 192 463 minecraft:brown_terracotta
setblock 241 92 464 minecraft:bone_block
fill 241 92 465 241 95 465 minecraft:brown_terracotta
setblock 241 92 504 minecraft:bone_block
fill 241 92 505 241 196 505 minecraft:brown_terracotta
fill 242 92 464 242 95 464 minecraft:brown_terracotta
setblock 242 92 503 minecraft:bone_block
fill 242 92 504 242 95 504 minecraft:brown_terracotta
setblock 243 92 502 minecraft:bone_block
fill 243 92 503 243 95 503 minecraft:brown_terracotta
setblock 244 92 465 minecraft:brown_terracotta
setblock 245 92 464 minecraft:brown_terracotta
setblock 245 92 465 minecraft:bone_block
setblock 246 92 464 minecraft:bone_block
setblock 246 92 504 minecraft:bone_block
fill 246 92 505 246 196 505 minecraft:brown_terracotta
fill 247 92 464 250 92 464 minecraft:brown_terracotta
fill 247 92 504 250 92 504 minecraft:brown_terracotta
setblock 251 92 464 minecraft:bone_block
setblock 251 92 504 minecraft:bone_block
fill 252 92 464 252 95 464 minecraft:brown_terracotta
fill 252 92 504 255 92 504 minecraft:brown_terracotta
setblock 254 92 465 minecraft:brown_terracotta
fill 254 92 503 256 92 503 minecraft:brown_terracotta
setblock 255 92 465 minecraft:bone_block
setblock 256 92 464 minecraft:bone_block
fill 256 92 465 256 95 465 minecraft:brown_terracotta
setblock 256 92 504 minecraft:bone_block
fill 257 92 464 257 95 464 minecraft:brown_terracotta
fill 257 92 466 258 92 466 minecraft:brown_terracotta
setblock 257 92 502 minecraft:brown_terracotta
setblock 257 92 503 minecraft:bone_block
fill 257 92 504 257 95 504 minecraft:brown_terracotta
setblock 258 92 502 minecraft:bone_block
fill 258 92 503 258 95 503 minecraft:brown_terracotta
setblock 259 92 466 minecraft:bone_block
fill 259 92 502 259 95 502 minecraft:brown_terracotta
setblock 260 92 465 minecraft:bone_block
fill 260 92 466 260 95 466 minecraft:brown_terracotta
fill 260 92 501 260 94 501 minecraft:brown_terracotta
setblock 261 92 464 minecraft:bone_block
fill 261 92 465 261 95 465 minecraft:brown_terracotta
setblock 261 92 504 minecraft:bone_block
fill 261 92 505 261 192 505 minecraft:brown_terracotta
fill 262 92 464 262 95 464 minecraft:brown_terracotta
setblock 262 92 503 minecraft:bone_block
fill 262 92 504 262 95 504 minecraft:brown_terracotta
setblock 263 92 501 minecraft:brown_terracotta
setblock 263 92 502 minecraft:bone_block
fill 263 92 503 263 95 503 minecraft:brown_terracotta
setblock 264 92 466 minecraft:bone_block
setblock 264 92 501 minecraft:bone_block
fill 264 92 502 264 95 502 minecraft:brown_terracotta
setblock 265 92 465 minecraft:bone_block
setblock 265 92 501 minecraft:brown_terracotta
setblock 266 92 464 minecraft:bone_block
fill 266 92 465 266 95 465 minecraft:brown_terracotta
setblock 266 92 504 minecraft:bone_block
fill 267 92 464 267 95 464 minecraft:brown_terracotta
setblock 267 92 503 minecraft:bone_block
fill 267 92 504 267 95 504 minecraft:brown_terracotta
setblock 268 92 502 minecraft:bone_block
fill 268 92 503 268 95 503 minecraft:brown_terracotta
fill 269 92 502 272 92 502 minecraft:brown_terracotta
setblock 271 92 464 minecraft:bone_block
setblock 271 92 504 minecraft:bone_block
fill 272 92 464 275 92 464 minecraft:brown_terracotta
setblock 272 92 503 minecraft:bone_block
fill 272 92 504 272 95 504 minecraft:brown_terracotta
setblock 273 92 502 minecraft:bone_block
fill 273 92 503 273 95 503 minecraft:brown_terracotta
setblock 274 92 500 minecraft:brown_terracotta
setblock 274 92 501 minecraft:bone_block
fill 274 92 502 274 95 502 minecraft:brown_terracotta
setblock 275 92 480 minecraft:bone_block
fill 275 92 481 275 92 484 minecraft:brown_terracotta
setblock 275 92 485 minecraft:bone_block
fill 275 92 486 275 95 486 minecraft:brown_terracotta
setblock 275 92 495 minecraft:bone_block
fill 275 92 496 275 95 496 minecraft:brown_terracotta
setblock 275 92 500 minecraft:bone_block
fill 275 92 501 275 95 501 minecraft:brown_terracotta
setblock 276 92 464 minecraft:bone_block
fill 276 92 465 276 95 465 minecraft:brown_terracotta
fill 276 92 476 276 92 478 minecraft:brown_terracotta
setblock 276 92 479 minecraft:bone_block
fill 276 92 480 276 92 483 minecraft:brown_terracotta
setblock 276 92 484 minecraft:bone_block
fill 276 92 485 276 95 485 minecraft:brown_terracotta
setblock 276 92 488 minecraft:brown_terracotta
setblock 276 92 489 minecraft:bone_block
fill 276 92 490 276 95 490 minecraft:brown_terracotta
setblock 276 92 494 minecraft:bone_block
fill 276 92 495 276 95 495 minecraft:brown_terracotta
setblock 276 92 499 minecraft:bone_block
fill 276 92 500 276 95 500 minecraft:brown_terracotta
setblock 276 92 504 minecraft:bone_block
fill 276 92 505 276 196 505 minecraft:brown_terracotta
fill 236 93 464 236 96 464 minecraft:brown_terracotta
fill 236 93 466 236 93 467 minecraft:brown_terracotta
setblock 236 93 473 minecraft:bone_block
fill 236 93 474 237 95 474 minecraft:brown_terracotta
setblock 236 93 478 minecraft:bone_block
fill 236 93 479 236 96 479 minecraft:brown_terracotta
setblock 236 93 483 minecraft:bone_block
fill 236 93 484 236 93 487 minecraft:brown_terracotta
setblock 236 93 488 minecraft:bone_block
fill 236 93 489 236 96 489 minecraft:brown_terracotta
setblock 236 93 493 minecraft:bone_block
fill 236 93 494 236 96 494 minecraft:brown_terracotta
setblock 236 93 498 minecraft:bone_block
fill 236 93 499 236 96 499 minecraft:brown_terracotta
setblock 236 93 502 minecraft:brown_terracotta
setblock 236 93 503 minecraft:bone_block
fill 236 93 504 236 96 504 minecraft:brown_terracotta
setblock 237 93 477 minecraft:bone_block
fill 237 93 478 237 96 478 minecraft:brown_terracotta
setblock 237 93 482 minecraft:bone_block
fill 237 93 483 237 96 483 minecraft:brown_terracotta
setblock 237 93 486 minecraft:brown_terracotta
setblock 237 93 487 minecraft:bone_block
fill 237 93 488 237 96 488 minecraft:brown_terracotta
setblock 237 93 492 minecraft:bone_block
fill 237 93 493 237 96 493 minecraft:brown_terracotta
setblock 237 93 497 minecraft:bone_block
fill 237 93 498 237 95 498 minecraft:brown_terracotta
setblock 237 93 501 minecraft:brown_terracotta
setblock 237 93 502 minecraft:bone_block
fill 237 93 503 237 96 503 minecraft:brown_terracotta
setblock 238 93 465 minecraft:brown_terracotta
setblock 238 93 476 minecraft:bone_block
fill 238 93 477 238 96 477 minecraft:brown_terracotta
setblock 238 93 480 minecraft:brown_terracotta
setblock 238 93 481 minecraft:bone_block
fill 238 93 482 238 96 482 minecraft:brown_terracotta
setblock 238 93 485 minecraft:brown_terracotta
setblock 238 93 486 minecraft:bone_block
fill 238 93 487 239 95 487 minecraft:brown_terracotta
setblock 238 93 490 minecraft:brown_terracotta
setblock 238 93 501 minecraft:bone_block
fill 238 93 502 238 94 502 minecraft:brown_terracotta
setblock 239 93 464 minecraft:brown_terracotta
setblock 239 93 465 minecraft:bone_block
setblock 239 93 480 minecraft:bone_block
fill 239 93 481 239 96 481 minecraft:brown_terracotta
setblock 239 93 485 minecraft:bone_block
fill 239 93 486 239 96 486 minecraft:brown_terracotta
setblock 240 93 464 minecraft:bone_block
fill 240 93 465 240 96 465 minecraft:brown_terracotta
fill 240 93 480 240 94 480 minecraft:brown_terracotta
setblock 240 93 483 minecraft:brown_terracotta
setblock 240 93 484 minecraft:bone_block
setblock 240 93 504 minecraft:bone_block
fill 240 93 505 240 196 505 minecraft:brown_terracotta
fill 241 93 464 241 96 464 minecraft:brown_terracotta
setblock 241 93 502 minecraft:brown_terracotta
setblock 241 93 503 minecraft:bone_block
fill 241 93 504 241 96 504 minecraft:brown_terracotta
setblock 242 93 502 minecraft:bone_block
fill 242 93 503 242 95 503 minecraft:brown_terracotta
setblock 244 93 465 minecraft:bone_block
setblock 245 93 464 minecraft:bone_block
fill 245 93 465 246 95 465 minecraft:brown_terracotta
setblock 245 93 504 minecraft:bone_block
fill 245 93 505 245 196 505 minecraft:brown_terracotta
fill 246 93 464 249 93 464 minecraft:brown_terracotta
fill 246 93 504 249 93 504 minecraft:brown_terracotta
setblock 250 93 464 minecraft:bone_block
setblock 250 93 504 minecraft:bone_block
fill 251 93 464 251 96 464 minecraft:brown_terracotta
fill 251 93 504 254 93 504 minecraft:brown_terracotta
fill 252 93 465 253 93 465 minecraft:brown_terracotta
fill 253 93 503 255 93 503 minecraft:brown_terracotta
setblock 254 93 465 minecraft:bone_block
fill 255 93 463 255 196 463 minecraft:brown_terracotta
setblock 255 93 464 minecraft:bone_block
fill 255 93 465 255 96 465 minecraft:brown_terracotta
setblock 255 93 504 minecraft:bone_block
fill 256 93 464 256 96 464 minecraft:brown_terracotta
fill 256 93 466 257 93 466 minecraft:brown_terracotta
setblock 256 93 502 minecraft:brown_terracotta
setblock 256 93 503 minecraft:bone_block
fill 256 93 504 256 96 504 minecraft:brown_terracotta
setblock 257 93 502 minecraft:bone_block
fill 257 93 503 257 96 503 minecraft:brown_terracotta
setblock 258 93 466 minecraft:bone_block
fill 258 93 502 258 96 502 minecraft:brown_terracotta
setblock 259 93 465 minecraft:bone_block
fill 259 93 466 259 96 466 minecraft:brown_terracotta
fill 259 93 501 259 94 501 minecraft:brown_terracotta
setblock 260 93 464 minecraft:bone_block
fill 260 93 465 260 96 465 minecraft:brown_terracotta
setblock 260 93 504 minecraft:bone_block
fill 260 93 505 260 194 505 minecraft:brown_terracotta
fill 261 93 464 261 96 464 minecraft:brown_terracotta
setblock 261 93 503 minecraft:bone_block
fill 261 93 504 261 96 504 minecraft:brown_terracotta
setblock 262 93 466 minecraft:brown_terracotta
setblock 262 93 502 minecraft:bone_block
fill 262 93 503 262 96 503 minecraft:brown_terracotta
setblock 263 93 466 minecraft:bone_block
setblock 263 93 501 minecraft:bone_block
fill 263 93 502 263 96 502 minecraft:brown_terracotta
setblock 264 93 465 minecraft:bone_block
fill 264 93 466 264 94 466 minecraft:brown_terracotta
setblock 264 93 501 minecraft:brown_terracotta
setblock 265 93 464 minecraft:bone_block
fill 265 93 465 265 96 465 minecraft:brown_terracotta
setblock 265 93 504 minecraft:bone_block
fill 266 93 464 266 96 464 minecraft:brown_terracotta
setblock 266 93 503 minecraft:bone_block
fill 266 93 504 266 96 504 minecraft:brown_terracotta
setblock 267 93 502 minecraft:bone_block
fill 267 93 503 267 96 503 minecraft:brown_terracotta
fill 268 93 502 271 93 502 minecraft:brown_terracotta
setblock 269 93 464 minecraft:brown_terracotta
setblock 270 93 464 minecraft:bone_block
setblock 270 93 504 minecraft:bone_block
fill 271 93 464 274 93 464 minecraft:brown_terracotta
setblock 271 93 503 minecraft:bone_block
fill 271 93 504 271 96 504 minecraft:brown_terracotta
setblock 272 93 502 minecraft:bone_block
fill 272 93 503 272 96 503 minecraft:brown_terracotta
fill 273 93 502 273 95 502 minecraft:brown_terracotta
setblock 274 93 500 minecraft:bone_block
fill 274 93 501 274 95 501 minecraft:brown_terracotta
setblock 275 93 464 minecraft:bone_block
setblock 275 93 479 minecraft:bone_block
fill 275 93 480 275 93 483 minecraft:brown_terracotta
setblock 275 93 484 minecraft:bone_block
fill 275 93 485 275 96 485 minecraft:brown_terracotta
fill 275 93 487 275 93 488 minecraft:brown_terracotta
schedule function dropper:buildpart/113_4 1t
