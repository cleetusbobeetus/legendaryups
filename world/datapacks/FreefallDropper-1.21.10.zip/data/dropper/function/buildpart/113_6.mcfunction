setblock 263 155 504 minecraft:bone_block
fill 264 155 464 267 155 464 minecraft:brown_terracotta
setblock 264 155 502 minecraft:brown_terracotta
setblock 264 155 503 minecraft:bone_block
fill 264 155 504 267 155 504 minecraft:brown_terracotta
setblock 265 155 502 minecraft:bone_block
fill 265 155 503 268 155 503 minecraft:brown_terracotta
setblock 266 155 466 minecraft:bone_block
fill 266 155 502 269 155 502 minecraft:brown_terracotta
setblock 267 155 465 minecraft:bone_block
fill 267 155 466 270 155 466 minecraft:brown_terracotta
setblock 268 155 464 minecraft:bone_block
fill 268 155 465 271 155 465 minecraft:brown_terracotta
setblock 268 155 504 minecraft:bone_block
fill 269 155 464 272 155 464 minecraft:brown_terracotta
setblock 269 155 503 minecraft:bone_block
fill 269 155 504 272 155 504 minecraft:brown_terracotta
setblock 270 155 502 minecraft:bone_block
fill 270 155 503 273 155 503 minecraft:brown_terracotta
fill 271 155 502 273 155 502 minecraft:brown_terracotta
setblock 272 155 465 minecraft:bone_block
setblock 273 155 464 minecraft:bone_block
setblock 273 155 465 minecraft:brown_terracotta
setblock 273 155 504 minecraft:bone_block
fill 274 155 464 276 156 464 minecraft:brown_terracotta
setblock 274 155 503 minecraft:bone_block
fill 274 155 504 276 156 504 minecraft:brown_terracotta
setblock 275 155 501 minecraft:brown_terracotta
setblock 275 155 502 minecraft:bone_block
fill 275 155 503 276 156 503 minecraft:brown_terracotta
setblock 276 155 465 minecraft:brown_terracotta
fill 276 155 498 276 155 500 minecraft:brown_terracotta
setblock 276 155 501 minecraft:bone_block
fill 276 155 502 276 158 502 minecraft:brown_terracotta
fill 236 156 481 236 156 484 minecraft:brown_terracotta
setblock 236 156 485 minecraft:bone_block
fill 236 156 486 236 156 489 minecraft:brown_terracotta
setblock 236 156 490 minecraft:bone_block
setblock 237 156 484 minecraft:bone_block
fill 237 156 485 237 158 486 minecraft:brown_terracotta
setblock 237 156 504 minecraft:bone_block
fill 238 156 504 241 156 504 minecraft:brown_terracotta
fill 239 156 484 244 156 488 minecraft:light_gray_concrete
fill 240 156 481 245 156 483 minecraft:light_gray_concrete
fill 240 156 489 245 156 491 minecraft:light_gray_concrete
setblock 241 156 464 minecraft:brown_terracotta
setblock 242 156 464 minecraft:bone_block
setblock 242 156 504 minecraft:bone_block
fill 243 156 464 246 156 464 minecraft:brown_terracotta
fill 243 156 504 246 156 504 minecraft:brown_terracotta
fill 244 156 465 245 156 465 minecraft:brown_terracotta
fill 244 156 503 247 156 503 minecraft:brown_terracotta
fill 245 156 484 245 158 488 minecraft:light_blue_stained_glass
setblock 246 156 465 minecraft:bone_block
fill 246 156 481 247 156 481 minecraft:light_gray_concrete
fill 246 156 482 246 158 483 minecraft:light_blue_stained_glass
fill 246 156 489 246 158 490 minecraft:light_blue_stained_glass
fill 246 156 491 247 156 491 minecraft:light_gray_concrete
setblock 247 156 464 minecraft:bone_block
fill 247 156 465 250 156 465 minecraft:brown_terracotta
fill 247 156 482 247 158 482 minecraft:light_blue_stained_glass
fill 247 156 490 247 158 490 minecraft:light_blue_stained_glass
setblock 247 156 504 minecraft:bone_block
fill 248 156 464 251 156 464 minecraft:brown_terracotta
fill 248 156 481 252 158 481 minecraft:light_blue_stained_glass
fill 248 156 491 252 158 491 minecraft:light_blue_stained_glass
fill 248 156 504 251 156 504 minecraft:brown_terracotta
setblock 251 156 465 minecraft:bone_block
setblock 252 156 464 minecraft:bone_block
setblock 252 156 465 minecraft:brown_terracotta
setblock 252 156 504 minecraft:bone_block
fill 253 156 464 256 156 464 minecraft:brown_terracotta
fill 253 156 481 260 156 481 minecraft:light_gray_concrete
fill 253 156 482 254 158 482 minecraft:light_blue_stained_glass
fill 253 156 490 254 158 490 minecraft:light_blue_stained_glass
fill 253 156 491 260 156 491 minecraft:light_gray_concrete
fill 254 156 483 254 158 483 minecraft:light_blue_stained_glass
fill 254 156 489 254 158 489 minecraft:light_blue_stained_glass
fill 255 156 482 260 156 483 minecraft:light_gray_concrete
fill 255 156 484 255 158 488 minecraft:light_blue_stained_glass
fill 255 156 489 260 156 490 minecraft:light_gray_concrete
fill 256 156 484 261 156 488 minecraft:light_gray_concrete
setblock 257 156 464 minecraft:bone_block
fill 258 156 464 260 156 465 minecraft:brown_terracotta
fill 258 156 504 261 156 504 minecraft:brown_terracotta
setblock 261 156 464 minecraft:brown_terracotta
setblock 261 156 465 minecraft:bone_block
setblock 262 156 464 minecraft:bone_block
fill 262 156 465 264 156 466 minecraft:brown_terracotta
setblock 262 156 503 minecraft:brown_terracotta
setblock 262 156 504 minecraft:bone_block
fill 263 156 464 266 156 464 minecraft:brown_terracotta
setblock 263 156 503 minecraft:bone_block
fill 263 156 504 266 156 504 minecraft:brown_terracotta
fill 264 156 503 267 156 503 minecraft:brown_terracotta
setblock 265 156 465 minecraft:brown_terracotta
setblock 265 156 466 minecraft:bone_block
fill 265 156 502 268 156 502 minecraft:brown_terracotta
setblock 266 156 465 minecraft:bone_block
fill 266 156 466 269 156 466 minecraft:brown_terracotta
setblock 267 156 464 minecraft:bone_block
fill 267 156 465 270 156 465 minecraft:brown_terracotta
setblock 267 156 504 minecraft:bone_block
fill 268 156 464 271 156 464 minecraft:brown_terracotta
setblock 268 156 503 minecraft:bone_block
fill 268 156 504 271 156 504 minecraft:brown_terracotta
setblock 269 156 502 minecraft:bone_block
fill 269 156 503 272 156 503 minecraft:brown_terracotta
fill 270 156 502 271 156 502 minecraft:brown_terracotta
setblock 271 156 465 minecraft:bone_block
setblock 272 156 464 minecraft:bone_block
fill 272 156 465 272 157 465 minecraft:brown_terracotta
setblock 272 156 504 minecraft:bone_block
fill 273 156 464 273 159 464 minecraft:brown_terracotta
setblock 273 156 503 minecraft:bone_block
fill 273 156 504 273 159 504 minecraft:brown_terracotta
setblock 274 156 503 minecraft:brown_terracotta
setblock 276 156 500 minecraft:bone_block
fill 276 156 501 276 157 501 minecraft:brown_terracotta
fill 236 157 482 236 157 483 minecraft:brown_terracotta
setblock 236 157 484 minecraft:bone_block
fill 236 157 485 236 157 488 minecraft:brown_terracotta
setblock 236 157 489 minecraft:bone_block
fill 236 157 490 236 160 490 minecraft:brown_terracotta
fill 237 157 484 237 160 484 minecraft:brown_terracotta
setblock 237 157 487 minecraft:brown_terracotta
setblock 240 157 504 minecraft:brown_terracotta
setblock 241 157 464 minecraft:bone_block
setblock 241 157 504 minecraft:bone_block
fill 242 157 464 245 157 464 minecraft:brown_terracotta
fill 242 157 504 245 157 504 minecraft:brown_terracotta
setblock 244 157 465 minecraft:brown_terracotta
setblock 244 157 486 minecraft:light_blue_stained_glass
setblock 245 157 465 minecraft:bone_block
setblock 245 157 483 minecraft:light_blue_stained_glass
setblock 245 157 489 minecraft:light_blue_stained_glass
setblock 246 157 464 minecraft:bone_block
fill 246 157 465 249 157 465 minecraft:brown_terracotta
setblock 246 157 504 minecraft:bone_block
fill 247 157 464 250 157 464 minecraft:brown_terracotta
setblock 247 157 481 minecraft:light_blue_stained_glass
setblock 247 157 491 minecraft:light_blue_stained_glass
fill 247 157 504 250 157 504 minecraft:brown_terracotta
setblock 250 157 465 minecraft:bone_block
setblock 250 157 480 minecraft:light_blue_stained_glass
setblock 250 157 492 minecraft:light_blue_stained_glass
setblock 251 157 464 minecraft:bone_block
fill 251 157 465 251 160 465 minecraft:brown_terracotta
fill 252 157 464 255 157 464 minecraft:brown_terracotta
setblock 253 157 481 minecraft:light_blue_stained_glass
setblock 253 157 491 minecraft:light_blue_stained_glass
setblock 255 157 483 minecraft:light_blue_stained_glass
setblock 255 157 489 minecraft:light_blue_stained_glass
setblock 256 157 464 minecraft:bone_block
setblock 256 157 486 minecraft:light_blue_stained_glass
fill 257 157 464 260 157 464 minecraft:brown_terracotta
fill 258 157 465 259 157 465 minecraft:brown_terracotta
fill 259 157 504 260 157 504 minecraft:brown_terracotta
setblock 260 157 465 minecraft:bone_block
setblock 261 157 464 minecraft:bone_block
fill 261 157 465 263 157 466 minecraft:brown_terracotta
setblock 261 157 504 minecraft:bone_block
fill 262 157 464 265 157 464 minecraft:brown_terracotta
setblock 262 157 503 minecraft:bone_block
fill 262 157 504 265 157 504 minecraft:brown_terracotta
fill 263 157 503 266 157 503 minecraft:brown_terracotta
setblock 264 157 465 minecraft:brown_terracotta
setblock 264 157 466 minecraft:bone_block
setblock 265 157 465 minecraft:bone_block
fill 265 157 466 268 157 466 minecraft:brown_terracotta
fill 265 157 502 267 157 502 minecraft:brown_terracotta
setblock 266 157 464 minecraft:bone_block
fill 266 157 465 269 157 465 minecraft:brown_terracotta
setblock 266 157 504 minecraft:bone_block
fill 267 157 464 270 157 464 minecraft:brown_terracotta
setblock 267 157 503 minecraft:bone_block
fill 267 157 504 270 157 504 minecraft:brown_terracotta
setblock 268 157 502 minecraft:bone_block
fill 268 157 503 271 157 503 minecraft:brown_terracotta
setblock 269 157 466 minecraft:bone_block
setblock 269 157 502 minecraft:brown_terracotta
setblock 270 157 465 minecraft:bone_block
setblock 271 157 464 minecraft:bone_block
fill 271 157 465 271 159 465 minecraft:brown_terracotta
setblock 271 157 504 minecraft:bone_block
fill 272 157 464 272 160 464 minecraft:brown_terracotta
setblock 272 157 503 minecraft:bone_block
fill 272 157 504 272 160 504 minecraft:brown_terracotta
setblock 273 157 503 minecraft:brown_terracotta
fill 274 157 464 275 157 464 minecraft:brown_terracotta
fill 274 157 504 275 157 504 minecraft:brown_terracotta
setblock 276 157 503 minecraft:brown_terracotta
setblock 276 157 504 minecraft:bone_block
setblock 236 158 482 minecraft:brown_terracotta
setblock 236 158 483 minecraft:bone_block
fill 236 158 484 236 158 487 minecraft:brown_terracotta
setblock 236 158 488 minecraft:bone_block
fill 236 158 489 236 161 489 minecraft:brown_terracotta
fill 236 158 491 236 159 491 minecraft:brown_terracotta
setblock 237 158 487 minecraft:bone_block
fill 237 158 488 237 161 488 minecraft:brown_terracotta
setblock 240 158 464 minecraft:bone_block
setblock 240 158 504 minecraft:bone_block
fill 241 158 464 244 158 464 minecraft:brown_terracotta
fill 241 158 504 244 158 504 minecraft:brown_terracotta
setblock 243 158 465 minecraft:brown_terracotta
setblock 244 158 465 minecraft:bone_block
setblock 245 158 464 minecraft:bone_block
fill 245 158 465 248 158 465 minecraft:brown_terracotta
setblock 245 158 504 minecraft:bone_block
fill 246 158 464 249 158 464 minecraft:brown_terracotta
fill 246 158 504 249 158 504 minecraft:brown_terracotta
setblock 249 158 465 minecraft:bone_block
setblock 250 158 464 minecraft:bone_block
fill 250 158 465 250 161 465 minecraft:brown_terracotta
fill 251 158 464 254 158 464 minecraft:brown_terracotta
setblock 255 158 464 minecraft:bone_block
fill 256 158 464 259 158 464 minecraft:brown_terracotta
fill 257 158 465 258 158 465 minecraft:brown_terracotta
setblock 259 158 465 minecraft:bone_block
setblock 259 158 504 minecraft:brown_terracotta
setblock 260 158 464 minecraft:bone_block
fill 260 158 465 263 158 465 minecraft:brown_terracotta
setblock 260 158 504 minecraft:bone_block
fill 261 158 464 264 158 464 minecraft:brown_terracotta
fill 261 158 466 262 158 466 minecraft:brown_terracotta
fill 261 158 504 264 158 504 minecraft:brown_terracotta
fill 262 158 503 265 158 503 minecraft:brown_terracotta
setblock 263 158 466 minecraft:bone_block
setblock 264 158 465 minecraft:bone_block
fill 264 158 466 267 158 466 minecraft:brown_terracotta
setblock 265 158 464 minecraft:bone_block
fill 265 158 465 268 158 465 minecraft:brown_terracotta
setblock 265 158 504 minecraft:bone_block
fill 266 158 464 269 158 464 minecraft:brown_terracotta
setblock 266 158 503 minecraft:bone_block
fill 266 158 504 269 158 504 minecraft:brown_terracotta
fill 267 158 503 270 158 503 minecraft:brown_terracotta
setblock 268 158 466 minecraft:bone_block
setblock 269 158 465 minecraft:bone_block
setblock 270 158 464 minecraft:bone_block
fill 270 158 465 270 161 465 minecraft:brown_terracotta
setblock 270 158 504 minecraft:bone_block
fill 271 158 464 271 161 464 minecraft:brown_terracotta
setblock 271 158 503 minecraft:bone_block
fill 271 158 504 271 161 504 minecraft:brown_terracotta
setblock 272 158 503 minecraft:brown_terracotta
setblock 274 158 464 minecraft:brown_terracotta
setblock 274 158 504 minecraft:brown_terracotta
setblock 275 158 504 minecraft:bone_block
setblock 276 158 487 minecraft:brown_terracotta
setblock 276 158 503 minecraft:bone_block
fill 276 158 504 276 161 504 minecraft:brown_terracotta
setblock 236 159 482 minecraft:bone_block
fill 236 159 483 236 159 486 minecraft:brown_terracotta
setblock 236 159 487 minecraft:bone_block
fill 236 159 488 236 162 488 minecraft:brown_terracotta
setblock 236 159 492 minecraft:bone_block
setblock 237 159 485 minecraft:brown_terracotta
setblock 237 159 486 minecraft:bone_block
fill 237 159 487 237 162 487 minecraft:brown_terracotta
fill 237 159 489 237 160 489 minecraft:brown_terracotta
fill 240 159 464 243 159 464 minecraft:brown_terracotta
fill 241 159 504 243 159 504 minecraft:brown_terracotta
setblock 242 159 465 minecraft:brown_terracotta
setblock 243 159 465 minecraft:bone_block
setblock 244 159 464 minecraft:bone_block
fill 244 159 465 247 159 465 minecraft:brown_terracotta
setblock 244 159 504 minecraft:bone_block
fill 245 159 464 248 159 464 minecraft:brown_terracotta
fill 245 159 504 248 159 504 minecraft:brown_terracotta
fill 247 159 483 247 159 484 minecraft:light_blue_stained_glass
fill 247 159 488 247 159 489 minecraft:light_blue_stained_glass
setblock 248 159 465 minecraft:bone_block
fill 248 159 482 248 159 483 minecraft:light_blue_stained_glass
fill 248 159 489 248 159 490 minecraft:light_blue_stained_glass
setblock 249 159 464 minecraft:bone_block
fill 249 159 465 249 162 465 minecraft:brown_terracotta
setblock 249 159 482 minecraft:light_blue_stained_glass
setblock 249 159 490 minecraft:light_blue_stained_glass
fill 250 159 464 253 159 464 minecraft:brown_terracotta
fill 252 159 483 253 159 483 minecraft:light_blue_stained_glass
fill 252 159 489 253 159 489 minecraft:light_blue_stained_glass
fill 253 159 484 254 159 484 minecraft:light_blue_stained_glass
fill 253 159 488 254 159 488 minecraft:light_blue_stained_glass
setblock 254 159 464 minecraft:bone_block
setblock 254 159 485 minecraft:light_blue_stained_glass
setblock 254 159 487 minecraft:light_blue_stained_glass
fill 255 159 464 258 159 464 minecraft:brown_terracotta
fill 256 159 465 257 159 465 minecraft:brown_terracotta
setblock 258 159 465 minecraft:bone_block
setblock 258 159 504 minecraft:brown_terracotta
setblock 259 159 464 minecraft:bone_block
fill 259 159 465 262 159 465 minecraft:brown_terracotta
setblock 259 159 504 minecraft:bone_block
fill 260 159 464 263 159 464 minecraft:brown_terracotta
fill 260 159 466 261 159 466 minecraft:brown_terracotta
fill 260 159 504 263 159 504 minecraft:brown_terracotta
setblock 262 159 466 minecraft:bone_block
fill 262 159 503 264 159 503 minecraft:brown_terracotta
setblock 263 159 465 minecraft:bone_block
fill 263 159 466 266 159 466 minecraft:brown_terracotta
setblock 264 159 464 minecraft:bone_block
fill 264 159 465 267 159 465 minecraft:brown_terracotta
setblock 264 159 504 minecraft:bone_block
fill 265 159 464 268 159 464 minecraft:brown_terracotta
setblock 265 159 503 minecraft:bone_block
fill 265 159 504 268 159 504 minecraft:brown_terracotta
fill 266 159 503 269 159 503 minecraft:brown_terracotta
setblock 267 159 466 minecraft:bone_block
setblock 268 159 465 minecraft:bone_block
fill 268 159 466 268 161 466 minecraft:brown_terracotta
setblock 269 159 464 minecraft:bone_block
fill 269 159 465 269 162 465 minecraft:brown_terracotta
setblock 269 159 504 minecraft:bone_block
fill 270 159 464 270 162 464 minecraft:brown_terracotta
setblock 270 159 503 minecraft:bone_block
fill 270 159 504 270 162 504 minecraft:brown_terracotta
setblock 274 159 464 minecraft:bone_block
setblock 274 159 504 minecraft:bone_block
fill 275 159 504 275 162 504 minecraft:brown_terracotta
setblock 276 159 486 minecraft:brown_terracotta
setblock 276 159 487 minecraft:bone_block
fill 276 159 488 276 160 490 minecraft:brown_terracotta
setblock 276 159 503 minecraft:brown_terracotta
fill 236 160 482 236 160 485 minecraft:brown_terracotta
setblock 236 160 486 minecraft:bone_block
fill 236 160 487 236 163 487 minecraft:brown_terracotta
setblock 236 160 491 minecraft:bone_block
fill 236 160 492 236 162 493 minecraft:brown_terracotta
setblock 237 160 485 minecraft:bone_block
fill 237 160 486 238 162 486 minecraft:brown_terracotta
setblock 237 160 490 minecraft:bone_block
setblock 238 160 466 minecraft:light[level=12]
setblock 238 160 474 minecraft:light[level=12]
setblock 238 160 482 minecraft:light[level=12]
fill 238 160 487 238 160 488 minecraft:brown_terracotta
setblock 238 160 490 minecraft:light[level=12]
setblock 238 160 498 minecraft:light[level=12]
fill 239 160 464 242 160 464 minecraft:brown_terracotta
setblock 241 160 465 minecraft:brown_terracotta
fill 241 160 504 242 160 504 minecraft:brown_terracotta
setblock 242 160 465 minecraft:bone_block
setblock 243 160 464 minecraft:bone_block
fill 243 160 465 246 160 465 minecraft:brown_terracotta
setblock 243 160 504 minecraft:bone_block
fill 244 160 464 247 160 464 minecraft:brown_terracotta
fill 244 160 504 247 160 504 minecraft:brown_terracotta
setblock 245 160 466 minecraft:brown_terracotta
setblock 246 160 466 minecraft:light[level=12]
setblock 246 160 474 minecraft:light[level=12]
setblock 246 160 482 minecraft:light[level=12]
setblock 246 160 490 minecraft:light[level=12]
setblock 246 160 498 minecraft:light[level=12]
setblock 247 160 465 minecraft:bone_block
setblock 248 160 464 minecraft:bone_block
fill 248 160 465 248 163 465 minecraft:brown_terracotta
fill 249 160 464 252 160 464 minecraft:brown_terracotta
setblock 253 160 464 minecraft:bone_block
fill 254 160 464 257 160 464 minecraft:brown_terracotta
setblock 254 160 466 minecraft:light[level=12]
setblock 254 160 474 minecraft:light[level=12]
setblock 254 160 482 minecraft:light[level=12]
setblock 254 160 490 minecraft:light[level=12]
setblock 254 160 498 minecraft:light[level=12]
fill 255 160 465 256 160 465 minecraft:brown_terracotta
setblock 257 160 465 minecraft:bone_block
setblock 258 160 464 minecraft:bone_block
fill 258 160 465 261 160 465 minecraft:brown_terracotta
setblock 258 160 504 minecraft:bone_block
fill 259 160 464 262 160 464 minecraft:brown_terracotta
fill 259 160 466 260 160 466 minecraft:brown_terracotta
fill 259 160 504 262 160 504 minecraft:brown_terracotta
setblock 261 160 466 minecraft:bone_block
fill 261 160 503 263 160 503 minecraft:brown_terracotta
setblock 262 160 465 minecraft:bone_block
fill 262 160 466 265 160 466 minecraft:brown_terracotta
setblock 262 160 474 minecraft:light[level=12]
setblock 262 160 482 minecraft:light[level=12]
setblock 262 160 490 minecraft:light[level=12]
setblock 262 160 498 minecraft:light[level=12]
setblock 263 160 464 minecraft:bone_block
fill 263 160 465 266 160 465 minecraft:brown_terracotta
fill 263 160 467 264 160 467 minecraft:brown_terracotta
setblock 263 160 504 minecraft:bone_block
fill 264 160 464 267 160 464 minecraft:brown_terracotta
setblock 264 160 503 minecraft:bone_block
fill 264 160 504 267 160 504 minecraft:brown_terracotta
fill 265 160 503 268 160 503 minecraft:brown_terracotta
setblock 266 160 466 minecraft:bone_block
setblock 267 160 465 minecraft:bone_block
fill 267 160 466 267 163 466 minecraft:brown_terracotta
setblock 268 160 464 minecraft:bone_block
fill 268 160 465 268 163 465 minecraft:brown_terracotta
setblock 268 160 504 minecraft:bone_block
fill 269 160 464 269 163 464 minecraft:brown_terracotta
setblock 269 160 503 minecraft:bone_block
fill 269 160 504 269 163 504 minecraft:brown_terracotta
setblock 270 160 466 minecraft:light[level=12]
setblock 270 160 474 minecraft:light[level=12]
setblock 270 160 482 minecraft:light[level=12]
setblock 270 160 490 minecraft:light[level=12]
setblock 270 160 498 minecraft:light[level=12]
setblock 273 160 464 minecraft:bone_block
setblock 273 160 504 minecraft:bone_block
fill 274 160 504 274 163 504 minecraft:brown_terracotta
setblock 276 160 485 minecraft:brown_terracotta
setblock 276 160 486 minecraft:bone_block
fill 276 160 487 276 163 487 minecraft:brown_terracotta
setblock 276 160 491 minecraft:bone_block
fill 276 160 492 276 163 492 minecraft:brown_terracotta
fill 236 161 482 236 161 484 minecraft:brown_terracotta
setblock 236 161 485 minecraft:bone_block
fill 236 161 486 236 164 486 minecraft:brown_terracotta
setblock 236 161 490 minecraft:bone_block
fill 236 161 491 237 163 491 minecraft:brown_terracotta
setblock 236 161 494 minecraft:brown_terracotta
setblock 237 161 483 minecraft:brown_terracotta
setblock 237 161 484 minecraft:bone_block
fill 237 161 485 238 163 485 minecraft:brown_terracotta
setblock 237 161 489 minecraft:bone_block
fill 237 161 490 238 163 490 minecraft:brown_terracotta
fill 237 161 492 237 162 492 minecraft:brown_terracotta
fill 238 161 464 241 161 464 minecraft:brown_terracotta
setblock 238 161 487 minecraft:brown_terracotta
setblock 238 161 488 minecraft:bone_block
fill 238 161 489 238 164 489 minecraft:brown_terracotta
setblock 240 161 465 minecraft:brown_terracotta
fill 240 161 504 241 161 504 minecraft:brown_terracotta
setblock 241 161 465 minecraft:bone_block
setblock 242 161 464 minecraft:bone_block
fill 242 161 465 245 161 465 minecraft:brown_terracotta
setblock 242 161 504 minecraft:bone_block
fill 243 161 464 246 161 464 minecraft:brown_terracotta
fill 243 161 466 244 161 466 minecraft:brown_terracotta
fill 243 161 504 246 161 504 minecraft:brown_terracotta
setblock 245 161 466 minecraft:bone_block
setblock 246 161 465 minecraft:bone_block
fill 246 161 466 247 163 466 minecraft:brown_terracotta
setblock 247 161 464 minecraft:bone_block
fill 247 161 465 247 164 465 minecraft:brown_terracotta
fill 248 161 464 251 161 464 minecraft:brown_terracotta
setblock 251 161 465 minecraft:bone_block
setblock 252 161 464 minecraft:bone_block
fill 252 161 465 255 161 465 minecraft:brown_terracotta
fill 253 161 464 256 161 464 minecraft:brown_terracotta
setblock 256 161 465 minecraft:bone_block
setblock 257 161 464 minecraft:bone_block
fill 257 161 465 259 161 466 minecraft:brown_terracotta
fill 258 161 464 261 161 464 minecraft:brown_terracotta
fill 258 161 504 261 161 504 minecraft:brown_terracotta
setblock 260 161 465 minecraft:brown_terracotta
setblock 260 161 466 minecraft:bone_block
setblock 261 161 465 minecraft:bone_block
fill 261 161 466 263 161 467 minecraft:brown_terracotta
fill 261 161 503 262 161 503 minecraft:brown_terracotta
setblock 262 161 464 minecraft:bone_block
fill 262 161 465 265 161 465 minecraft:brown_terracotta
setblock 262 161 504 minecraft:bone_block
fill 263 161 464 266 161 464 minecraft:brown_terracotta
setblock 263 161 503 minecraft:bone_block
fill 263 161 504 266 161 504 minecraft:brown_terracotta
setblock 264 161 466 minecraft:brown_terracotta
setblock 264 161 467 minecraft:bone_block
fill 264 161 503 267 161 503 minecraft:brown_terracotta
setblock 265 161 466 minecraft:bone_block
fill 265 161 467 265 164 467 minecraft:brown_terracotta
setblock 266 161 465 minecraft:bone_block
fill 266 161 466 266 164 466 minecraft:brown_terracotta
setblock 267 161 464 minecraft:bone_block
fill 267 161 465 267 164 465 minecraft:brown_terracotta
setblock 267 161 504 minecraft:bone_block
fill 268 161 464 268 164 464 minecraft:brown_terracotta
setblock 268 161 503 minecraft:bone_block
fill 268 161 504 268 164 504 minecraft:brown_terracotta
setblock 269 161 503 minecraft:brown_terracotta
setblock 272 161 464 minecraft:bone_block
setblock 272 161 504 minecraft:bone_block
fill 273 161 464 273 163 464 minecraft:brown_terracotta
fill 273 161 504 273 164 504 minecraft:brown_terracotta
setblock 276 161 485 minecraft:bone_block
fill 276 161 486 276 164 486 minecraft:brown_terracotta
fill 276 161 488 276 161 489 minecraft:brown_terracotta
setblock 276 161 490 minecraft:bone_block
fill 276 161 491 276 164 491 minecraft:brown_terracotta
fill 276 161 493 276 161 494 minecraft:brown_terracotta
fill 236 162 466 236 162 468 minecraft:brown_terracotta
setblock 236 162 469 minecraft:bone_block
fill 236 162 481 236 162 483 minecraft:brown_terracotta
setblock 236 162 484 minecraft:bone_block
fill 236 162 485 236 165 485 minecraft:brown_terracotta
setblock 236 162 489 minecraft:bone_block
fill 236 162 490 236 165 490 minecraft:brown_terracotta
setblock 236 162 494 minecraft:bone_block
fill 236 162 495 236 165 495 minecraft:brown_terracotta
fill 237 162 464 240 162 464 minecraft:brown_terracotta
setblock 237 162 483 minecraft:bone_block
fill 237 162 484 238 164 484 minecraft:brown_terracotta
setblock 237 162 488 minecraft:bone_block
fill 237 162 489 237 165 489 minecraft:brown_terracotta
setblock 237 162 493 minecraft:bone_block
setblock 238 162 487 minecraft:bone_block
fill 238 162 488 239 164 488 minecraft:brown_terracotta
setblock 238 162 491 minecraft:brown_terracotta
setblock 239 162 465 minecraft:brown_terracotta
fill 239 162 487 239 165 487 minecraft:brown_terracotta
setblock 240 162 465 minecraft:bone_block
setblock 240 162 504 minecraft:brown_terracotta
setblock 241 162 464 minecraft:bone_block
fill 241 162 465 244 162 465 minecraft:brown_terracotta
setblock 241 162 504 minecraft:bone_block
fill 242 162 464 245 162 464 minecraft:brown_terracotta
fill 242 162 466 243 162 466 minecraft:brown_terracotta
fill 242 162 504 245 162 504 minecraft:brown_terracotta
setblock 244 162 466 minecraft:bone_block
setblock 245 162 465 minecraft:bone_block
fill 245 162 466 245 165 466 minecraft:brown_terracotta
setblock 246 162 464 minecraft:bone_block
fill 246 162 465 246 165 465 minecraft:brown_terracotta
fill 247 162 464 250 162 464 minecraft:brown_terracotta
setblock 250 162 465 minecraft:bone_block
setblock 251 162 464 minecraft:bone_block
fill 251 162 465 254 162 465 minecraft:brown_terracotta
fill 252 162 464 255 162 464 minecraft:brown_terracotta
setblock 255 162 465 minecraft:bone_block
setblock 256 162 464 minecraft:bone_block
fill 256 162 465 258 162 466 minecraft:brown_terracotta
fill 257 162 464 260 162 464 minecraft:brown_terracotta
fill 257 162 504 260 162 504 minecraft:brown_terracotta
setblock 259 162 465 minecraft:brown_terracotta
setblock 259 162 466 minecraft:bone_block
fill 259 162 467 262 162 467 minecraft:brown_terracotta
setblock 260 162 465 minecraft:bone_block
fill 260 162 466 263 162 466 minecraft:brown_terracotta
fill 260 162 503 261 162 503 minecraft:brown_terracotta
setblock 261 162 464 minecraft:bone_block
fill 261 162 465 264 162 465 minecraft:brown_terracotta
setblock 261 162 504 minecraft:bone_block
fill 262 162 464 265 162 464 minecraft:brown_terracotta
setblock 262 162 503 minecraft:bone_block
fill 262 162 504 265 162 504 minecraft:brown_terracotta
setblock 263 162 467 minecraft:bone_block
fill 263 162 503 266 162 503 minecraft:brown_terracotta
setblock 264 162 466 minecraft:bone_block
fill 264 162 467 264 165 467 minecraft:brown_terracotta
setblock 265 162 465 minecraft:bone_block
fill 265 162 466 265 165 466 minecraft:brown_terracotta
setblock 266 162 464 minecraft:bone_block
fill 266 162 465 266 165 465 minecraft:brown_terracotta
setblock 266 162 504 minecraft:bone_block
fill 267 162 464 267 165 464 minecraft:brown_terracotta
setblock 267 162 503 minecraft:bone_block
fill 267 162 504 267 165 504 minecraft:brown_terracotta
fill 268 162 503 268 163 503 minecraft:brown_terracotta
setblock 270 162 465 minecraft:bone_block
setblock 271 162 464 minecraft:bone_block
setblock 271 162 504 minecraft:bone_block
fill 272 162 464 272 164 464 minecraft:brown_terracotta
fill 272 162 504 272 165 504 minecraft:brown_terracotta
fill 275 162 488 275 162 489 minecraft:brown_terracotta
setblock 275 162 490 minecraft:bone_block
fill 275 162 491 275 164 492 minecraft:brown_terracotta
setblock 276 162 464 minecraft:bone_block
fill 276 162 465 276 163 467 minecraft:brown_terracotta
setblock 276 162 484 minecraft:bone_block
fill 276 162 485 276 165 485 minecraft:brown_terracotta
setblock 276 162 488 minecraft:brown_terracotta
setblock 276 162 489 minecraft:bone_block
fill 276 162 490 276 165 490 minecraft:brown_terracotta
setblock 276 162 493 minecraft:brown_terracotta
setblock 276 162 494 minecraft:bone_block
fill 276 162 495 276 163 497 minecraft:brown_terracotta
setblock 276 162 503 minecraft:brown_terracotta
setblock 276 162 504 minecraft:bone_block
fill 236 163 465 236 163 467 minecraft:brown_terracotta
setblock 236 163 468 minecraft:bone_block
fill 236 163 469 236 163 472 minecraft:brown_terracotta
setblock 236 163 473 minecraft:bone_block
fill 236 163 480 236 163 482 minecraft:brown_terracotta
setblock 236 163 483 minecraft:bone_block
fill 236 163 484 236 166 484 minecraft:brown_terracotta
setblock 236 163 488 minecraft:bone_block
fill 236 163 489 236 166 489 minecraft:brown_terracotta
setblock 236 163 492 minecraft:brown_terracotta
setblock 236 163 493 minecraft:bone_block
fill 236 163 494 237 165 494 minecraft:brown_terracotta
fill 236 163 496 236 164 496 minecraft:brown_terracotta
fill 237 163 464 239 163 464 minecraft:brown_terracotta
fill 237 163 468 237 164 470 minecraft:brown_terracotta
setblock 237 163 482 minecraft:bone_block
fill 237 163 483 237 166 483 minecraft:brown_terracotta
setblock 237 163 486 minecraft:brown_terracotta
setblock 237 163 487 minecraft:bone_block
fill 237 163 488 237 166 488 minecraft:brown_terracotta
setblock 237 163 492 minecraft:bone_block
fill 237 163 493 238 165 493 minecraft:brown_terracotta
setblock 238 163 486 minecraft:bone_block
fill 238 163 487 238 166 487 minecraft:brown_terracotta
setblock 238 163 491 minecraft:bone_block
fill 238 163 492 238 166 492 minecraft:brown_terracotta
setblock 239 163 465 minecraft:bone_block
fill 239 163 486 239 166 486 minecraft:brown_terracotta
setblock 239 163 489 minecraft:brown_terracotta
setblock 239 163 490 minecraft:bone_block
setblock 239 163 504 minecraft:brown_terracotta
setblock 240 163 464 minecraft:bone_block
fill 240 163 465 243 163 465 minecraft:brown_terracotta
setblock 240 163 504 minecraft:bone_block
fill 241 163 464 244 163 464 minecraft:brown_terracotta
fill 241 163 466 242 163 466 minecraft:brown_terracotta
fill 241 163 504 244 163 504 minecraft:brown_terracotta
setblock 243 163 466 minecraft:bone_block
setblock 244 163 465 minecraft:bone_block
fill 244 163 466 244 166 466 minecraft:brown_terracotta
setblock 245 163 464 minecraft:bone_block
fill 245 163 465 245 166 465 minecraft:brown_terracotta
setblock 245 163 504 minecraft:bone_block
fill 246 163 464 249 163 464 minecraft:brown_terracotta
setblock 248 163 466 minecraft:bone_block
setblock 249 163 465 minecraft:bone_block
setblock 250 163 464 minecraft:bone_block
fill 250 163 465 253 163 465 minecraft:brown_terracotta
fill 251 163 464 254 163 464 minecraft:brown_terracotta
setblock 254 163 465 minecraft:bone_block
setblock 255 163 464 minecraft:bone_block
fill 255 163 465 257 163 466 minecraft:brown_terracotta
fill 256 163 464 259 163 464 minecraft:brown_terracotta
fill 256 163 504 259 163 504 minecraft:brown_terracotta
setblock 258 163 465 minecraft:brown_terracotta
setblock 258 163 466 minecraft:bone_block
fill 258 163 467 261 163 467 minecraft:brown_terracotta
setblock 259 163 465 minecraft:bone_block
fill 259 163 466 262 163 466 minecraft:brown_terracotta
fill 259 163 503 260 163 503 minecraft:brown_terracotta
setblock 260 163 464 minecraft:bone_block
fill 260 163 465 263 163 465 minecraft:brown_terracotta
setblock 260 163 504 minecraft:bone_block
fill 261 163 464 264 163 464 minecraft:brown_terracotta
setblock 261 163 503 minecraft:bone_block
fill 261 163 504 264 163 504 minecraft:brown_terracotta
setblock 262 163 467 minecraft:bone_block
fill 262 163 503 265 163 503 minecraft:brown_terracotta
setblock 263 163 466 minecraft:bone_block
fill 263 163 467 263 166 467 minecraft:brown_terracotta
setblock 264 163 465 minecraft:bone_block
fill 264 163 466 264 166 466 minecraft:brown_terracotta
setblock 265 163 464 minecraft:bone_block
fill 265 163 465 265 166 465 minecraft:brown_terracotta
setblock 265 163 504 minecraft:bone_block
fill 266 163 464 266 166 464 minecraft:brown_terracotta
setblock 266 163 503 minecraft:bone_block
fill 266 163 504 266 166 504 minecraft:brown_terracotta
fill 267 163 503 267 165 503 minecraft:brown_terracotta
setblock 269 163 465 minecraft:bone_block
setblock 270 163 464 minecraft:bone_block
setblock 270 163 504 minecraft:bone_block
fill 271 163 464 271 165 464 minecraft:brown_terracotta
fill 271 163 504 271 165 504 minecraft:brown_terracotta
setblock 275 163 464 minecraft:bone_block
fill 275 163 487 275 163 488 minecraft:brown_terracotta
setblock 275 163 489 minecraft:bone_block
fill 275 163 490 275 166 490 minecraft:brown_terracotta
setblock 275 163 493 minecraft:brown_terracotta
setblock 275 163 494 minecraft:bone_block
setblock 275 163 504 minecraft:bone_block
fill 276 163 464 276 166 464 minecraft:brown_terracotta
setblock 276 163 468 minecraft:bone_block
fill 276 163 469 276 166 469 minecraft:brown_terracotta
fill 276 163 484 276 166 484 minecraft:brown_terracotta
setblock 276 163 488 minecraft:bone_block
fill 276 163 489 276 166 489 minecraft:brown_terracotta
setblock 276 163 493 minecraft:bone_block
fill 276 163 494 276 166 494 minecraft:brown_terracotta
setblock 276 163 498 minecraft:bone_block
fill 276 163 499 276 165 500 minecraft:brown_terracotta
setblock 276 163 502 minecraft:brown_terracotta
setblock 276 163 503 minecraft:bone_block
fill 276 163 504 276 166 504 minecraft:brown_terracotta
fill 236 164 464 236 164 466 minecraft:brown_terracotta
setblock 236 164 467 minecraft:bone_block
fill 236 164 468 236 164 471 minecraft:brown_terracotta
setblock 236 164 472 minecraft:bone_block
fill 236 164 473 236 164 476 minecraft:brown_terracotta
setblock 236 164 477 minecraft:bone_block
fill 236 164 478 236 164 481 minecraft:brown_terracotta
setblock 236 164 482 minecraft:bone_block
fill 236 164 483 236 167 483 minecraft:brown_terracotta
setblock 236 164 487 minecraft:bone_block
fill 236 164 488 236 167 488 minecraft:brown_terracotta
setblock 236 164 491 minecraft:brown_terracotta
setblock 236 164 492 minecraft:bone_block
fill 236 164 493 236 167 493 minecraft:brown_terracotta
setblock 236 164 497 minecraft:bone_block
fill 236 164 498 236 167 498 minecraft:brown_terracotta
fill 237 164 464 238 164 464 minecraft:brown_terracotta
setblock 237 164 466 minecraft:bone_block
fill 237 164 467 237 167 467 minecraft:brown_terracotta
setblock 237 164 471 minecraft:bone_block
fill 237 164 472 237 165 474 minecraft:brown_terracotta
setblock 237 164 481 minecraft:bone_block
fill 237 164 482 237 167 482 minecraft:brown_terracotta
setblock 237 164 485 minecraft:brown_terracotta
setblock 237 164 486 minecraft:bone_block
fill 237 164 487 237 167 487 minecraft:brown_terracotta
setblock 237 164 490 minecraft:brown_terracotta
setblock 237 164 491 minecraft:bone_block
fill 237 164 492 237 167 492 minecraft:brown_terracotta
setblock 237 164 495 minecraft:brown_terracotta
setblock 237 164 496 minecraft:bone_block
setblock 238 164 465 minecraft:bone_block
setblock 238 164 469 minecraft:brown_terracotta
setblock 238 164 470 minecraft:bone_block
fill 238 164 471 238 167 471 minecraft:brown_terracotta
fill 238 164 483 238 165 483 minecraft:brown_terracotta
setblock 238 164 485 minecraft:bone_block
fill 238 164 486 238 167 486 minecraft:brown_terracotta
setblock 238 164 490 minecraft:bone_block
fill 238 164 491 239 166 491 minecraft:brown_terracotta
setblock 238 164 494 minecraft:brown_terracotta
setblock 239 164 464 minecraft:bone_block
fill 239 164 465 242 164 465 minecraft:brown_terracotta
setblock 239 164 489 minecraft:bone_block
fill 239 164 490 239 167 490 minecraft:brown_terracotta
fill 239 164 492 239 165 492 minecraft:brown_terracotta
setblock 239 164 504 minecraft:bone_block
fill 240 164 464 243 164 464 minecraft:brown_terracotta
fill 240 164 466 241 164 466 minecraft:brown_terracotta
fill 240 164 504 243 164 504 minecraft:brown_terracotta
setblock 242 164 466 minecraft:bone_block
setblock 243 164 465 minecraft:bone_block
fill 243 164 466 243 165 467 minecraft:brown_terracotta
setblock 244 164 464 minecraft:bone_block
fill 244 164 465 244 167 465 minecraft:brown_terracotta
setblock 244 164 467 minecraft:brown_terracotta
setblock 244 164 504 minecraft:bone_block
fill 245 164 464 248 164 464 minecraft:brown_terracotta
setblock 246 164 466 minecraft:brown_terracotta
setblock 247 164 466 minecraft:bone_block
setblock 248 164 465 minecraft:bone_block
setblock 248 164 466 minecraft:brown_terracotta
setblock 249 164 464 minecraft:bone_block
fill 249 164 465 252 164 465 minecraft:brown_terracotta
fill 250 164 464 253 164 464 minecraft:brown_terracotta
setblock 253 164 465 minecraft:bone_block
setblock 254 164 464 minecraft:bone_block
fill 254 164 465 256 164 466 minecraft:brown_terracotta
fill 255 164 464 258 164 464 minecraft:brown_terracotta
fill 256 164 504 258 164 504 minecraft:brown_terracotta
setblock 257 164 465 minecraft:brown_terracotta
setblock 257 164 466 minecraft:bone_block
fill 257 164 467 260 164 467 minecraft:brown_terracotta
setblock 258 164 465 minecraft:bone_block
fill 258 164 466 261 164 466 minecraft:brown_terracotta
setblock 259 164 464 minecraft:bone_block
fill 259 164 465 262 164 465 minecraft:brown_terracotta
setblock 259 164 503 minecraft:brown_terracotta
setblock 259 164 504 minecraft:bone_block
fill 260 164 464 263 164 464 minecraft:brown_terracotta
setblock 260 164 503 minecraft:bone_block
fill 260 164 504 263 164 504 minecraft:brown_terracotta
setblock 261 164 467 minecraft:bone_block
fill 261 164 503 264 164 503 minecraft:brown_terracotta
setblock 262 164 466 minecraft:bone_block
fill 262 164 467 262 167 467 minecraft:brown_terracotta
setblock 263 164 465 minecraft:bone_block
fill 263 164 466 263 167 466 minecraft:brown_terracotta
setblock 264 164 464 minecraft:bone_block
fill 264 164 465 264 167 465 minecraft:brown_terracotta
setblock 264 164 504 minecraft:bone_block
fill 265 164 464 265 167 464 minecraft:brown_terracotta
setblock 265 164 503 minecraft:bone_block
fill 265 164 504 265 167 504 minecraft:brown_terracotta
fill 266 164 503 266 166 503 minecraft:brown_terracotta
setblock 267 164 466 minecraft:bone_block
setblock 268 164 465 minecraft:bone_block
setblock 269 164 464 minecraft:bone_block
setblock 269 164 465 minecraft:brown_terracotta
setblock 269 164 504 minecraft:bone_block
fill 270 164 464 270 165 464 minecraft:brown_terracotta
fill 270 164 504 270 166 504 minecraft:brown_terracotta
setblock 274 164 504 minecraft:bone_block
fill 275 164 464 275 165 464 minecraft:brown_terracotta
fill 275 164 486 275 164 487 minecraft:brown_terracotta
setblock 275 164 488 minecraft:bone_block
fill 275 164 489 275 167 489 minecraft:brown_terracotta
setblock 275 164 493 minecraft:bone_block
fill 275 164 494 275 165 496 minecraft:brown_terracotta
fill 275 164 504 275 167 504 minecraft:brown_terracotta
fill 276 164 465 276 164 466 minecraft:brown_terracotta
setblock 276 164 467 minecraft:bone_block
fill 276 164 468 276 167 468 minecraft:brown_terracotta
fill 276 164 470 276 164 471 minecraft:brown_terracotta
fill 276 164 483 276 167 483 minecraft:brown_terracotta
setblock 276 164 487 minecraft:bone_block
fill 276 164 488 276 167 488 minecraft:brown_terracotta
setblock 276 164 492 minecraft:bone_block
fill 276 164 493 276 167 493 minecraft:brown_terracotta
fill 276 164 495 276 164 496 minecraft:brown_terracotta
setblock 276 164 497 minecraft:bone_block
fill 276 164 498 276 167 498 minecraft:brown_terracotta
setblock 276 164 501 minecraft:brown_terracotta
setblock 276 164 502 minecraft:bone_block
fill 276 164 503 276 167 503 minecraft:brown_terracotta
fill 236 165 464 236 165 465 minecraft:brown_terracotta
setblock 236 165 466 minecraft:bone_block
fill 236 165 467 236 165 470 minecraft:brown_terracotta
setblock 236 165 471 minecraft:bone_block
fill 236 165 472 236 165 475 minecraft:brown_terracotta
setblock 236 165 476 minecraft:bone_block
fill 236 165 477 236 165 480 minecraft:brown_terracotta
setblock 236 165 481 minecraft:bone_block
fill 236 165 482 236 168 482 minecraft:brown_terracotta
setblock 236 165 486 minecraft:bone_block
fill 236 165 487 236 168 487 minecraft:brown_terracotta
setblock 236 165 491 minecraft:bone_block
fill 236 165 492 236 168 492 minecraft:brown_terracotta
setblock 236 165 496 minecraft:bone_block
fill 236 165 497 237 167 497 minecraft:brown_terracotta
fill 236 165 499 236 166 499 minecraft:brown_terracotta
setblock 237 165 464 minecraft:brown_terracotta
fill 237 165 466 237 168 466 minecraft:brown_terracotta
fill 237 165 468 237 165 469 minecraft:brown_terracotta
setblock 237 165 470 minecraft:bone_block
fill 237 165 471 237 168 471 minecraft:brown_terracotta
setblock 237 165 475 minecraft:bone_block
fill 237 165 476 237 165 479 minecraft:brown_terracotta
setblock 237 165 480 minecraft:bone_block
fill 237 165 481 237 168 481 minecraft:brown_terracotta
setblock 237 165 484 minecraft:brown_terracotta
setblock 237 165 485 minecraft:bone_block
fill 237 165 486 237 168 486 minecraft:brown_terracotta
setblock 237 165 490 minecraft:bone_block
fill 237 165 491 237 168 491 minecraft:brown_terracotta
setblock 237 165 495 minecraft:bone_block
fill 237 165 496 237 168 496 minecraft:brown_terracotta
setblock 238 165 464 minecraft:bone_block
fill 238 165 465 241 165 465 minecraft:brown_terracotta
fill 238 165 467 238 165 468 minecraft:brown_terracotta
setblock 238 165 469 minecraft:bone_block
fill 238 165 470 238 168 470 minecraft:brown_terracotta
fill 238 165 472 238 165 473 minecraft:brown_terracotta
setblock 238 165 474 minecraft:bone_block
setblock 238 165 484 minecraft:bone_block
fill 238 165 485 238 168 485 minecraft:brown_terracotta
setblock 238 165 488 minecraft:brown_terracotta
setblock 238 165 489 minecraft:bone_block
fill 238 165 490 238 168 490 minecraft:brown_terracotta
setblock 238 165 494 minecraft:bone_block
fill 238 165 495 238 168 495 minecraft:brown_terracotta
fill 239 165 464 242 165 464 minecraft:brown_terracotta
fill 239 165 466 240 165 466 minecraft:brown_terracotta
setblock 239 165 488 minecraft:bone_block
fill 239 165 489 239 168 489 minecraft:brown_terracotta
setblock 239 165 493 minecraft:bone_block
fill 239 165 504 242 165 504 minecraft:brown_terracotta
setblock 241 165 466 minecraft:bone_block
setblock 242 165 465 minecraft:bone_block
fill 242 165 466 242 165 467 minecraft:brown_terracotta
setblock 243 165 464 minecraft:bone_block
fill 243 165 465 243 168 465 minecraft:brown_terracotta
setblock 243 165 504 minecraft:bone_block
fill 244 165 464 247 165 464 minecraft:brown_terracotta
setblock 246 165 466 minecraft:bone_block
setblock 247 165 465 minecraft:bone_block
setblock 247 165 466 minecraft:brown_terracotta
setblock 248 165 464 minecraft:bone_block
fill 248 165 465 251 165 465 minecraft:brown_terracotta
fill 249 165 464 252 165 464 minecraft:brown_terracotta
setblock 252 165 465 minecraft:bone_block
setblock 253 165 464 minecraft:bone_block
fill 253 165 465 256 165 465 minecraft:brown_terracotta
fill 254 165 464 257 165 464 minecraft:brown_terracotta
fill 254 165 466 255 165 466 minecraft:brown_terracotta
fill 255 165 504 257 165 504 minecraft:brown_terracotta
setblock 256 165 466 minecraft:bone_block
fill 256 165 467 259 165 467 minecraft:brown_terracotta
setblock 257 165 465 minecraft:bone_block
fill 257 165 466 260 165 466 minecraft:brown_terracotta
setblock 258 165 464 minecraft:bone_block
fill 258 165 465 261 165 465 minecraft:brown_terracotta
setblock 258 165 503 minecraft:brown_terracotta
setblock 258 165 504 minecraft:bone_block
fill 259 165 464 262 165 464 minecraft:brown_terracotta
setblock 259 165 503 minecraft:bone_block
fill 259 165 504 262 165 504 minecraft:brown_terracotta
setblock 260 165 467 minecraft:bone_block
fill 260 165 503 263 165 503 minecraft:brown_terracotta
setblock 261 165 466 minecraft:bone_block
fill 261 165 467 261 167 467 minecraft:brown_terracotta
setblock 262 165 465 minecraft:bone_block
fill 262 165 466 262 168 466 minecraft:brown_terracotta
setblock 263 165 464 minecraft:bone_block
fill 263 165 465 263 168 465 minecraft:brown_terracotta
setblock 263 165 504 minecraft:bone_block
fill 264 165 464 264 168 464 minecraft:brown_terracotta
setblock 264 165 503 minecraft:bone_block
fill 264 165 504 264 168 504 minecraft:brown_terracotta
fill 265 165 503 265 167 503 minecraft:brown_terracotta
setblock 266 165 466 minecraft:bone_block
setblock 267 165 465 minecraft:bone_block
setblock 268 165 464 minecraft:bone_block
setblock 268 165 465 minecraft:brown_terracotta
setblock 268 165 504 minecraft:bone_block
fill 269 165 464 269 166 464 minecraft:brown_terracotta
fill 269 165 504 269 166 504 minecraft:brown_terracotta
fill 274 165 490 274 165 492 minecraft:brown_terracotta
setblock 274 165 493 minecraft:bone_block
setblock 274 165 504 minecraft:brown_terracotta
setblock 275 165 486 minecraft:brown_terracotta
setblock 275 165 487 minecraft:bone_block
fill 275 165 488 275 168 488 minecraft:brown_terracotta
setblock 275 165 491 minecraft:brown_terracotta
setblock 275 165 492 minecraft:bone_block
fill 275 165 493 275 168 493 minecraft:brown_terracotta
setblock 275 165 497 minecraft:bone_block
setblock 276 165 465 minecraft:brown_terracotta
setblock 276 165 466 minecraft:bone_block
fill 276 165 467 276 168 467 minecraft:brown_terracotta
setblock 276 165 470 minecraft:brown_terracotta
setblock 276 165 471 minecraft:bone_block
fill 276 165 472 276 166 474 minecraft:brown_terracotta
fill 276 165 482 276 168 482 minecraft:brown_terracotta
setblock 276 165 486 minecraft:bone_block
fill 276 165 487 276 168 487 minecraft:brown_terracotta
setblock 276 165 491 minecraft:bone_block
fill 276 165 492 276 168 492 minecraft:brown_terracotta
setblock 276 165 495 minecraft:brown_terracotta
setblock 276 165 496 minecraft:bone_block
fill 276 165 497 276 168 497 minecraft:brown_terracotta
setblock 276 165 501 minecraft:bone_block
fill 276 165 502 276 168 502 minecraft:brown_terracotta
setblock 236 166 464 minecraft:brown_terracotta
setblock 236 166 465 minecraft:bone_block
fill 236 166 466 236 166 469 minecraft:brown_terracotta
setblock 236 166 470 minecraft:bone_block
fill 236 166 471 236 166 474 minecraft:brown_terracotta
setblock 236 166 475 minecraft:bone_block
fill 236 166 476 236 166 479 minecraft:brown_terracotta
setblock 236 166 480 minecraft:bone_block
fill 236 166 481 236 169 481 minecraft:brown_terracotta
setblock 236 166 485 minecraft:bone_block
fill 236 166 486 236 169 486 minecraft:brown_terracotta
setblock 236 166 490 minecraft:bone_block
fill 236 166 491 236 169 491 minecraft:brown_terracotta
setblock 236 166 494 minecraft:brown_terracotta
setblock 236 166 495 minecraft:bone_block
fill 236 166 496 236 169 496 minecraft:brown_terracotta
setblock 237 166 464 minecraft:bone_block
fill 237 166 465 240 166 465 minecraft:brown_terracotta
setblock 237 166 468 minecraft:brown_terracotta
setblock 237 166 469 minecraft:bone_block
fill 237 166 470 237 169 470 minecraft:brown_terracotta
fill 237 166 472 237 166 473 minecraft:brown_terracotta
setblock 237 166 474 minecraft:bone_block
fill 237 166 475 237 166 478 minecraft:brown_terracotta
setblock 237 166 479 minecraft:bone_block
fill 237 166 480 237 169 480 minecraft:brown_terracotta
setblock 237 166 484 minecraft:bone_block
fill 237 166 485 237 169 485 minecraft:brown_terracotta
setblock 237 166 489 minecraft:bone_block
fill 237 166 490 237 169 490 minecraft:brown_terracotta
setblock 237 166 493 minecraft:brown_terracotta
setblock 237 166 494 minecraft:bone_block
fill 237 166 495 237 169 495 minecraft:brown_terracotta
fill 238 166 464 241 166 464 minecraft:brown_terracotta
setblock 238 166 467 minecraft:brown_terracotta
setblock 238 166 468 minecraft:bone_block
fill 238 166 469 239 167 469 minecraft:brown_terracotta
setblock 238 166 472 minecraft:brown_terracotta
setblock 238 166 473 minecraft:bone_block
fill 238 166 474 238 166 477 minecraft:brown_terracotta
setblock 238 166 482 minecraft:brown_terracotta
setblock 238 166 483 minecraft:bone_block
fill 238 166 484 238 168 484 minecraft:brown_terracotta
setblock 238 166 488 minecraft:bone_block
fill 238 166 489 238 169 489 minecraft:brown_terracotta
setblock 238 166 493 minecraft:bone_block
fill 238 166 494 238 169 494 minecraft:brown_terracotta
setblock 239 166 466 minecraft:brown_terracotta
fill 239 166 470 239 166 471 minecraft:brown_terracotta
setblock 239 166 472 minecraft:bone_block
fill 239 166 473 239 169 473 minecraft:brown_terracotta
setblock 239 166 487 minecraft:bone_block
fill 239 166 488 239 167 488 minecraft:brown_terracotta
setblock 239 166 492 minecraft:bone_block
fill 239 166 493 239 168 493 minecraft:brown_terracotta
fill 239 166 504 241 166 504 minecraft:brown_terracotta
setblock 240 166 466 minecraft:bone_block
setblock 241 166 465 minecraft:bone_block
fill 241 166 466 243 167 466 minecraft:brown_terracotta
setblock 242 166 464 minecraft:bone_block
fill 242 166 465 242 168 465 minecraft:brown_terracotta
setblock 242 166 504 minecraft:bone_block
fill 243 166 464 246 166 464 minecraft:brown_terracotta
setblock 245 166 466 minecraft:bone_block
setblock 246 166 465 minecraft:bone_block
setblock 246 166 466 minecraft:brown_terracotta
setblock 247 166 464 minecraft:bone_block
fill 247 166 465 250 166 465 minecraft:brown_terracotta
fill 248 166 464 251 166 464 minecraft:brown_terracotta
setblock 251 166 465 minecraft:bone_block
setblock 252 166 464 minecraft:bone_block
fill 252 166 465 255 166 465 minecraft:brown_terracotta
fill 253 166 464 256 166 464 minecraft:brown_terracotta
setblock 254 166 466 minecraft:brown_terracotta
setblock 255 166 466 minecraft:bone_block
fill 255 166 504 256 166 504 minecraft:brown_terracotta
setblock 256 166 465 minecraft:bone_block
fill 256 166 466 258 166 467 minecraft:brown_terracotta
setblock 257 166 464 minecraft:bone_block
fill 257 166 465 260 166 465 minecraft:brown_terracotta
setblock 257 166 504 minecraft:bone_block
fill 258 166 464 261 166 464 minecraft:brown_terracotta
setblock 258 166 503 minecraft:bone_block
fill 258 166 504 261 166 504 minecraft:brown_terracotta
setblock 259 166 466 minecraft:brown_terracotta
setblock 259 166 467 minecraft:bone_block
fill 259 166 503 262 166 503 minecraft:brown_terracotta
setblock 260 166 466 minecraft:bone_block
fill 260 166 467 260 168 467 minecraft:brown_terracotta
setblock 261 166 465 minecraft:bone_block
fill 261 166 466 261 169 466 minecraft:brown_terracotta
setblock 262 166 464 minecraft:bone_block
fill 262 166 465 262 169 465 minecraft:brown_terracotta
setblock 262 166 504 minecraft:bone_block
fill 263 166 464 263 169 464 minecraft:brown_terracotta
setblock 263 166 503 minecraft:bone_block
fill 263 166 504 263 169 504 minecraft:brown_terracotta
fill 264 166 503 264 168 503 minecraft:brown_terracotta
setblock 265 166 466 minecraft:bone_block
setblock 266 166 465 minecraft:bone_block
setblock 267 166 464 minecraft:bone_block
setblock 267 166 465 minecraft:brown_terracotta
setblock 267 166 504 minecraft:bone_block
fill 268 166 464 268 167 464 minecraft:brown_terracotta
fill 268 166 504 268 167 504 minecraft:brown_terracotta
fill 274 166 489 274 166 491 minecraft:brown_terracotta
setblock 274 166 492 minecraft:bone_block
fill 274 166 493 274 167 495 minecraft:brown_terracotta
setblock 275 166 486 minecraft:bone_block
fill 275 166 487 275 169 487 minecraft:brown_terracotta
setblock 275 166 491 minecraft:bone_block
fill 275 166 492 275 169 492 minecraft:brown_terracotta
fill 275 166 494 275 166 495 minecraft:brown_terracotta
setblock 275 166 496 minecraft:bone_block
fill 275 166 497 275 168 498 minecraft:brown_terracotta
setblock 276 166 465 minecraft:bone_block
fill 276 166 466 276 169 466 minecraft:brown_terracotta
setblock 276 166 470 minecraft:bone_block
fill 276 166 471 276 169 471 minecraft:brown_terracotta
setblock 276 166 475 minecraft:bone_block
fill 276 166 476 276 169 476 minecraft:brown_terracotta
fill 276 166 481 276 169 481 minecraft:brown_terracotta
setblock 276 166 485 minecraft:bone_block
fill 276 166 486 276 169 486 minecraft:brown_terracotta
setblock 276 166 490 minecraft:bone_block
fill 276 166 491 276 169 491 minecraft:brown_terracotta
setblock 276 166 495 minecraft:bone_block
fill 276 166 496 276 169 496 minecraft:brown_terracotta
setblock 276 166 499 minecraft:brown_terracotta
setblock 276 166 500 minecraft:bone_block
fill 276 166 501 276 169 501 minecraft:brown_terracotta
setblock 236 167 464 minecraft:bone_block
fill 236 167 465 236 167 468 minecraft:brown_terracotta
setblock 236 167 469 minecraft:bone_block
fill 236 167 470 236 167 473 minecraft:brown_terracotta
setblock 236 167 474 minecraft:bone_block
fill 236 167 475 236 167 478 minecraft:brown_terracotta
setblock 236 167 479 minecraft:bone_block
fill 236 167 480 236 170 480 minecraft:brown_terracotta
setblock 236 167 484 minecraft:bone_block
fill 236 167 485 236 170 485 minecraft:brown_terracotta
setblock 236 167 489 minecraft:bone_block
fill 236 167 490 236 170 490 minecraft:brown_terracotta
setblock 236 167 494 minecraft:bone_block
fill 236 167 495 236 170 495 minecraft:brown_terracotta
setblock 236 167 499 minecraft:bone_block
fill 236 167 500 236 170 500 minecraft:brown_terracotta
fill 237 167 464 240 167 464 minecraft:brown_terracotta
setblock 237 167 468 minecraft:bone_block
fill 237 167 469 237 170 469 minecraft:brown_terracotta
setblock 237 167 472 minecraft:brown_terracotta
setblock 237 167 473 minecraft:bone_block
fill 237 167 474 237 167 477 minecraft:brown_terracotta
setblock 237 167 478 minecraft:bone_block
fill 237 167 479 238 169 479 minecraft:brown_terracotta
setblock 237 167 483 minecraft:bone_block
fill 237 167 484 237 170 484 minecraft:brown_terracotta
setblock 237 167 488 minecraft:bone_block
fill 237 167 489 237 170 489 minecraft:brown_terracotta
setblock 237 167 493 minecraft:bone_block
fill 237 167 494 237 170 494 minecraft:brown_terracotta
setblock 237 167 498 minecraft:bone_block
fill 238 167 465 239 167 465 minecraft:brown_terracotta
setblock 238 167 467 minecraft:bone_block
fill 238 167 468 238 169 468 minecraft:brown_terracotta
setblock 238 167 472 minecraft:bone_block
fill 238 167 473 238 167 476 minecraft:brown_terracotta
setblock 238 167 477 minecraft:bone_block
fill 238 167 478 238 170 478 minecraft:brown_terracotta
setblock 238 167 483 minecraft:brown_terracotta
setblock 238 167 487 minecraft:bone_block
fill 238 167 488 238 169 488 minecraft:brown_terracotta
setblock 238 167 491 minecraft:brown_terracotta
setblock 238 167 492 minecraft:bone_block
fill 238 167 493 238 170 493 minecraft:brown_terracotta
setblock 238 167 496 minecraft:brown_terracotta
setblock 239 167 466 minecraft:bone_block
setblock 239 167 470 minecraft:brown_terracotta
setblock 239 167 471 minecraft:bone_block
fill 239 167 472 239 170 472 minecraft:brown_terracotta
fill 239 167 474 239 167 475 minecraft:brown_terracotta
setblock 239 167 487 minecraft:brown_terracotta
setblock 239 167 491 minecraft:bone_block
fill 239 167 492 239 168 492 minecraft:brown_terracotta
setblock 240 167 465 minecraft:bone_block
setblock 240 167 466 minecraft:brown_terracotta
setblock 240 167 504 minecraft:brown_terracotta
setblock 241 167 464 minecraft:bone_block
fill 241 167 465 241 169 465 minecraft:brown_terracotta
setblock 241 167 504 minecraft:bone_block
fill 242 167 464 245 167 464 minecraft:brown_terracotta
setblock 244 167 466 minecraft:bone_block
setblock 245 167 465 minecraft:bone_block
setblock 246 167 464 minecraft:bone_block
fill 246 167 465 247 167 465 minecraft:brown_terracotta
fill 247 167 464 250 167 464 minecraft:brown_terracotta
setblock 251 167 464 minecraft:bone_block
fill 252 167 464 254 167 465 minecraft:brown_terracotta
setblock 254 167 466 minecraft:bone_block
setblock 255 167 464 minecraft:brown_terracotta
setblock 255 167 465 minecraft:bone_block
fill 255 167 466 258 167 466 minecraft:brown_terracotta
setblock 255 167 504 minecraft:brown_terracotta
setblock 256 167 464 minecraft:bone_block
fill 256 167 465 259 167 465 minecraft:brown_terracotta
setblock 256 167 504 minecraft:bone_block
fill 257 167 464 260 167 464 minecraft:brown_terracotta
setblock 257 167 467 minecraft:brown_terracotta
setblock 257 167 503 minecraft:bone_block
fill 257 167 504 260 167 504 minecraft:brown_terracotta
setblock 258 167 467 minecraft:bone_block
fill 258 167 503 261 167 503 minecraft:brown_terracotta
setblock 259 167 466 minecraft:bone_block
fill 259 167 467 259 168 467 minecraft:brown_terracotta
setblock 260 167 465 minecraft:bone_block
fill 260 167 466 260 169 466 minecraft:brown_terracotta
setblock 261 167 464 minecraft:bone_block
fill 261 167 465 261 170 465 minecraft:brown_terracotta
setblock 261 167 504 minecraft:bone_block
fill 262 167 464 262 170 464 minecraft:brown_terracotta
setblock 262 167 503 minecraft:bone_block
fill 262 167 504 262 170 504 minecraft:brown_terracotta
fill 263 167 503 263 169 503 minecraft:brown_terracotta
setblock 264 167 466 minecraft:bone_block
setblock 265 167 465 minecraft:bone_block
setblock 266 167 464 minecraft:bone_block
setblock 266 167 465 minecraft:brown_terracotta
setblock 266 167 504 minecraft:bone_block
setblock 267 167 464 minecraft:brown_terracotta
fill 267 167 504 267 168 504 minecraft:brown_terracotta
fill 274 167 489 274 167 490 minecraft:brown_terracotta
setblock 274 167 491 minecraft:bone_block
fill 274 167 492 274 170 492 minecraft:brown_terracotta
setblock 274 167 496 minecraft:bone_block
fill 275 167 486 275 169 486 minecraft:brown_terracotta
setblock 275 167 490 minecraft:bone_block
fill 275 167 491 275 170 491 minecraft:brown_terracotta
setblock 275 167 494 minecraft:brown_terracotta
setblock 275 167 495 minecraft:bone_block
fill 275 167 496 275 170 496 minecraft:brown_terracotta
setblock 275 167 499 minecraft:brown_terracotta
setblock 276 167 464 minecraft:bone_block
fill 276 167 465 276 168 465 minecraft:brown_terracotta
setblock 276 167 469 minecraft:bone_block
fill 276 167 470 276 170 470 minecraft:brown_terracotta
fill 276 167 472 276 167 473 minecraft:brown_terracotta
setblock 276 167 474 minecraft:bone_block
fill 276 167 475 276 170 475 minecraft:brown_terracotta
fill 276 167 477 276 167 478 minecraft:brown_terracotta
setblock 276 167 479 minecraft:bone_block
fill 276 167 480 276 170 480 minecraft:brown_terracotta
setblock 276 167 484 minecraft:bone_block
fill 276 167 485 276 170 485 minecraft:brown_terracotta
setblock 276 167 489 minecraft:bone_block
fill 276 167 490 276 170 490 minecraft:brown_terracotta
setblock 276 167 494 minecraft:bone_block
fill 276 167 495 276 170 495 minecraft:brown_terracotta
setblock 276 167 499 minecraft:bone_block
fill 276 167 500 276 170 500 minecraft:brown_terracotta
setblock 276 167 504 minecraft:bone_block
fill 236 168 464 236 168 467 minecraft:brown_terracotta
setblock 236 168 468 minecraft:bone_block
fill 236 168 469 236 168 472 minecraft:brown_terracotta
setblock 236 168 473 minecraft:bone_block
fill 236 168 474 236 168 477 minecraft:brown_terracotta
setblock 236 168 478 minecraft:bone_block
fill 236 168 479 236 171 479 minecraft:brown_terracotta
setblock 236 168 483 minecraft:bone_block
fill 236 168 484 236 171 484 minecraft:brown_terracotta
setblock 236 168 488 minecraft:bone_block
fill 236 168 489 236 171 489 minecraft:brown_terracotta
setblock 236 168 493 minecraft:bone_block
fill 236 168 494 236 171 494 minecraft:brown_terracotta
setblock 236 168 497 minecraft:brown_terracotta
setblock 236 168 498 minecraft:bone_block
fill 236 168 499 236 171 499 minecraft:brown_terracotta
fill 237 168 464 239 168 464 minecraft:brown_terracotta
setblock 237 168 467 minecraft:bone_block
fill 237 168 468 237 171 468 minecraft:brown_terracotta
setblock 237 168 472 minecraft:bone_block
fill 237 168 473 237 168 476 minecraft:brown_terracotta
setblock 237 168 477 minecraft:bone_block
fill 237 168 478 237 171 478 minecraft:brown_terracotta
setblock 237 168 482 minecraft:bone_block
fill 237 168 483 237 171 483 minecraft:brown_terracotta
setblock 237 168 487 minecraft:bone_block
fill 237 168 488 237 171 488 minecraft:brown_terracotta
setblock 237 168 492 minecraft:bone_block
fill 237 168 493 237 171 493 minecraft:brown_terracotta
setblock 237 168 497 minecraft:bone_block
fill 237 168 498 237 171 498 minecraft:brown_terracotta
setblock 238 168 465 minecraft:brown_terracotta
setblock 238 168 466 minecraft:light[level=12]
fill 238 168 469 238 169 469 minecraft:brown_terracotta
setblock 238 168 471 minecraft:bone_block
fill 238 168 472 238 168 475 minecraft:brown_terracotta
setblock 238 168 476 minecraft:bone_block
fill 238 168 477 238 171 477 minecraft:brown_terracotta
setblock 238 168 480 minecraft:brown_terracotta
setblock 238 168 482 minecraft:light[level=12]
setblock 238 168 486 minecraft:bone_block
fill 238 168 487 238 169 487 minecraft:brown_terracotta
setblock 238 168 491 minecraft:bone_block
fill 238 168 492 238 171 492 minecraft:brown_terracotta
setblock 238 168 496 minecraft:bone_block
setblock 238 168 498 minecraft:light[level=12]
setblock 239 168 465 minecraft:bone_block
setblock 239 168 470 minecraft:bone_block
fill 239 168 471 239 170 471 minecraft:brown_terracotta
setblock 239 168 474 minecraft:brown_terracotta
setblock 239 168 475 minecraft:bone_block
fill 239 168 476 239 171 476 minecraft:brown_terracotta
setblock 239 168 490 minecraft:bone_block
setblock 239 168 491 minecraft:brown_terracotta
setblock 240 168 464 minecraft:bone_block
fill 240 168 465 240 169 465 minecraft:brown_terracotta
fill 241 168 464 244 168 464 minecraft:brown_terracotta
setblock 244 168 465 minecraft:bone_block
setblock 245 168 464 minecraft:bone_block
fill 246 168 464 249 168 464 minecraft:brown_terracotta
setblock 246 168 466 minecraft:light[level=12]
setblock 246 168 474 minecraft:light[level=12]
setblock 246 168 482 minecraft:light[level=12]
setblock 246 168 490 minecraft:light[level=12]
setblock 246 168 498 minecraft:light[level=12]
setblock 250 168 464 minecraft:bone_block
fill 251 168 464 254 168 464 minecraft:brown_terracotta
setblock 253 168 465 minecraft:brown_terracotta
setblock 254 168 465 minecraft:bone_block
setblock 254 168 466 minecraft:light[level=12]
setblock 254 168 474 minecraft:light[level=12]
setblock 254 168 482 minecraft:light[level=12]
setblock 254 168 490 minecraft:light[level=12]
setblock 254 168 498 minecraft:light[level=12]
setblock 255 168 464 minecraft:bone_block
fill 255 168 465 257 168 466 minecraft:brown_terracotta
setblock 255 168 504 minecraft:bone_block
fill 256 168 464 259 168 464 minecraft:brown_terracotta
fill 256 168 504 259 168 504 minecraft:brown_terracotta
fill 257 168 503 260 168 503 minecraft:brown_terracotta
setblock 258 168 465 minecraft:brown_terracotta
setblock 258 168 466 minecraft:bone_block
setblock 258 168 467 minecraft:brown_terracotta
setblock 259 168 465 minecraft:bone_block
fill 259 168 466 259 169 466 minecraft:brown_terracotta
setblock 260 168 464 minecraft:bone_block
fill 260 168 465 260 170 465 minecraft:brown_terracotta
setblock 260 168 504 minecraft:bone_block
fill 261 168 464 261 171 464 minecraft:brown_terracotta
setblock 261 168 503 minecraft:bone_block
fill 261 168 504 261 171 504 minecraft:brown_terracotta
setblock 262 168 474 minecraft:light[level=12]
setblock 262 168 482 minecraft:light[level=12]
setblock 262 168 490 minecraft:light[level=12]
setblock 262 168 498 minecraft:light[level=12]
fill 262 168 503 262 170 503 minecraft:brown_terracotta
setblock 263 168 466 minecraft:bone_block
setblock 264 168 465 minecraft:bone_block
setblock 265 168 464 minecraft:bone_block
setblock 265 168 504 minecraft:bone_block
setblock 266 168 464 minecraft:brown_terracotta
fill 266 168 504 266 169 504 minecraft:brown_terracotta
setblock 270 168 466 minecraft:light[level=12]
setblock 270 168 474 minecraft:light[level=12]
setblock 270 168 482 minecraft:light[level=12]
setblock 270 168 490 minecraft:light[level=12]
setblock 270 168 498 minecraft:light[level=12]
setblock 274 168 490 minecraft:bone_block
fill 274 168 491 274 171 491 minecraft:brown_terracotta
fill 274 168 493 274 168 494 minecraft:brown_terracotta
setblock 274 168 495 minecraft:bone_block
fill 274 168 496 274 171 496 minecraft:brown_terracotta
setblock 275 168 489 minecraft:bone_block
fill 275 168 490 275 171 490 minecraft:brown_terracotta
setblock 275 168 494 minecraft:bone_block
fill 275 168 495 275 171 495 minecraft:brown_terracotta
setblock 275 168 499 minecraft:bone_block
setblock 276 168 468 minecraft:bone_block
fill 276 168 469 276 171 469 minecraft:brown_terracotta
setblock 276 168 472 minecraft:brown_terracotta
setblock 276 168 473 minecraft:bone_block
fill 276 168 474 276 171 474 minecraft:brown_terracotta
setblock 276 168 477 minecraft:brown_terracotta
setblock 276 168 478 minecraft:bone_block
fill 276 168 479 276 171 479 minecraft:brown_terracotta
setblock 276 168 483 minecraft:bone_block
fill 276 168 484 276 171 484 minecraft:brown_terracotta
setblock 276 168 488 minecraft:bone_block
fill 276 168 489 276 171 489 minecraft:brown_terracotta
setblock 276 168 493 minecraft:bone_block
fill 276 168 494 276 171 494 minecraft:brown_terracotta
setblock 276 168 498 minecraft:bone_block
fill 276 168 499 276 171 499 minecraft:brown_terracotta
setblock 276 168 503 minecraft:bone_block
setblock 276 168 504 minecraft:brown_terracotta
fill 236 169 465 236 169 466 minecraft:brown_terracotta
setblock 236 169 467 minecraft:bone_block
fill 236 169 468 236 169 471 minecraft:brown_terracotta
setblock 236 169 472 minecraft:bone_block
fill 236 169 473 236 169 476 minecraft:brown_terracotta
setblock 236 169 477 minecraft:bone_block
fill 236 169 478 236 172 478 minecraft:brown_terracotta
setblock 236 169 482 minecraft:bone_block
fill 236 169 483 236 172 483 minecraft:brown_terracotta
setblock 236 169 487 minecraft:bone_block
fill 236 169 488 236 172 488 minecraft:brown_terracotta
setblock 236 169 492 minecraft:bone_block
fill 236 169 493 236 172 493 minecraft:brown_terracotta
setblock 236 169 497 minecraft:bone_block
fill 236 169 498 236 172 498 minecraft:brown_terracotta
fill 237 169 464 238 169 464 minecraft:brown_terracotta
fill 237 169 467 237 170 467 minecraft:brown_terracotta
setblock 237 169 471 minecraft:bone_block
fill 237 169 472 237 169 475 minecraft:brown_terracotta
setblock 237 169 476 minecraft:bone_block
fill 237 169 477 237 172 477 minecraft:brown_terracotta
setblock 237 169 481 minecraft:bone_block
fill 237 169 482 237 172 482 minecraft:brown_terracotta
setblock 237 169 486 minecraft:bone_block
fill 237 169 487 237 171 487 minecraft:brown_terracotta
setblock 237 169 491 minecraft:bone_block
fill 237 169 492 237 172 492 minecraft:brown_terracotta
setblock 237 169 496 minecraft:bone_block
fill 237 169 497 237 172 497 minecraft:brown_terracotta
setblock 238 169 470 minecraft:bone_block
fill 238 169 471 238 169 474 minecraft:brown_terracotta
setblock 238 169 475 minecraft:bone_block
fill 238 169 476 238 172 476 minecraft:brown_terracotta
setblock 238 169 480 minecraft:bone_block
setblock 238 169 490 minecraft:bone_block
fill 238 169 491 238 170 491 minecraft:brown_terracotta
setblock 238 169 495 minecraft:bone_block
setblock 238 169 496 minecraft:brown_terracotta
setblock 239 169 464 minecraft:bone_block
setblock 239 169 465 minecraft:brown_terracotta
setblock 239 169 470 minecraft:brown_terracotta
setblock 239 169 474 minecraft:bone_block
fill 239 169 475 239 172 475 minecraft:brown_terracotta
fill 240 169 464 243 169 464 minecraft:brown_terracotta
setblock 244 169 464 minecraft:bone_block
setblock 245 169 464 minecraft:brown_terracotta
fill 251 169 464 253 169 464 minecraft:brown_terracotta
setblock 254 169 464 minecraft:bone_block
fill 254 169 465 257 169 465 minecraft:brown_terracotta
fill 255 169 464 258 169 464 minecraft:brown_terracotta
fill 255 169 504 258 169 504 minecraft:brown_terracotta
setblock 256 169 466 minecraft:brown_terracotta
setblock 257 169 466 minecraft:bone_block
fill 257 169 503 259 169 503 minecraft:brown_terracotta
setblock 258 169 465 minecraft:bone_block
setblock 258 169 466 minecraft:brown_terracotta
setblock 259 169 464 minecraft:bone_block
fill 259 169 465 259 171 465 minecraft:brown_terracotta
setblock 259 169 504 minecraft:bone_block
fill 260 169 464 260 172 464 minecraft:brown_terracotta
setblock 260 169 503 minecraft:bone_block
fill 260 169 504 260 172 504 minecraft:brown_terracotta
fill 261 169 503 261 172 503 minecraft:brown_terracotta
setblock 263 169 465 minecraft:bone_block
setblock 264 169 464 minecraft:bone_block
setblock 264 169 504 minecraft:bone_block
setblock 265 169 464 minecraft:brown_terracotta
fill 265 169 504 265 170 504 minecraft:brown_terracotta
setblock 274 169 490 minecraft:brown_terracotta
setblock 274 169 493 minecraft:brown_terracotta
setblock 274 169 494 minecraft:bone_block
fill 274 169 495 274 172 495 minecraft:brown_terracotta
fill 274 169 497 275 169 497 minecraft:brown_terracotta
setblock 275 169 472 minecraft:brown_terracotta
setblock 275 169 473 minecraft:bone_block
setblock 275 169 488 minecraft:bone_block
fill 275 169 489 275 172 489 minecraft:brown_terracotta
setblock 275 169 493 minecraft:bone_block
fill 275 169 494 275 172 494 minecraft:brown_terracotta
setblock 275 169 498 minecraft:bone_block
fill 275 169 499 275 171 500 minecraft:brown_terracotta
setblock 276 169 467 minecraft:bone_block
fill 276 169 468 276 171 468 minecraft:brown_terracotta
setblock 276 169 472 minecraft:bone_block
fill 276 169 473 276 172 473 minecraft:brown_terracotta
setblock 276 169 477 minecraft:bone_block
fill 276 169 478 276 172 478 minecraft:brown_terracotta
setblock 276 169 482 minecraft:bone_block
fill 276 169 483 276 172 483 minecraft:brown_terracotta
setblock 276 169 487 minecraft:bone_block
fill 276 169 488 276 172 488 minecraft:brown_terracotta
setblock 276 169 492 minecraft:bone_block
fill 276 169 493 276 172 493 minecraft:brown_terracotta
setblock 276 169 497 minecraft:bone_block
fill 276 169 498 276 172 498 minecraft:brown_terracotta
setblock 276 169 502 minecraft:bone_block
fill 276 169 503 276 172 503 minecraft:brown_terracotta
setblock 236 170 466 minecraft:bone_block
fill 236 170 467 236 170 470 minecraft:brown_terracotta
setblock 236 170 471 minecraft:bone_block
fill 236 170 472 236 170 475 minecraft:brown_terracotta
setblock 236 170 476 minecraft:bone_block
fill 236 170 477 236 173 477 minecraft:brown_terracotta
setblock 236 170 481 minecraft:bone_block
fill 236 170 482 236 173 482 minecraft:brown_terracotta
setblock 236 170 486 minecraft:bone_block
fill 236 170 487 236 173 487 minecraft:brown_terracotta
setblock 236 170 491 minecraft:bone_block
fill 236 170 492 236 173 492 minecraft:brown_terracotta
setblock 236 170 496 minecraft:bone_block
fill 236 170 497 236 173 497 minecraft:brown_terracotta
setblock 237 170 470 minecraft:bone_block
fill 237 170 471 237 170 474 minecraft:brown_terracotta
setblock 237 170 475 minecraft:bone_block
fill 237 170 476 237 173 476 minecraft:brown_terracotta
setblock 237 170 479 minecraft:brown_terracotta
setblock 237 170 480 minecraft:bone_block
fill 237 170 481 237 173 481 minecraft:brown_terracotta
setblock 237 170 485 minecraft:bone_block
fill 237 170 486 237 171 486 minecraft:brown_terracotta
setblock 237 170 490 minecraft:bone_block
fill 237 170 491 237 173 491 minecraft:brown_terracotta
setblock 237 170 495 minecraft:bone_block
fill 237 170 496 237 173 496 minecraft:brown_terracotta
setblock 238 170 464 minecraft:bone_block
setblock 238 170 469 minecraft:bone_block
fill 238 170 470 238 170 473 minecraft:brown_terracotta
setblock 238 170 474 minecraft:bone_block
fill 238 170 475 238 173 475 minecraft:brown_terracotta
setblock 238 170 479 minecraft:bone_block
fill 238 170 480 238 173 480 minecraft:brown_terracotta
setblock 238 170 489 minecraft:bone_block
setblock 238 170 490 minecraft:brown_terracotta
setblock 238 170 494 minecraft:bone_block
setblock 238 170 495 minecraft:brown_terracotta
fill 239 170 464 242 170 464 minecraft:brown_terracotta
setblock 239 170 473 minecraft:bone_block
fill 239 170 474 239 173 474 minecraft:brown_terracotta
setblock 252 170 464 minecraft:brown_terracotta
setblock 253 170 464 minecraft:bone_block
fill 254 170 464 256 170 465 minecraft:brown_terracotta
fill 254 170 504 257 170 504 minecraft:brown_terracotta
setblock 257 170 464 minecraft:brown_terracotta
setblock 257 170 465 minecraft:bone_block
fill 257 170 503 258 170 503 minecraft:brown_terracotta
setblock 258 170 464 minecraft:bone_block
fill 258 170 465 258 172 465 minecraft:brown_terracotta
setblock 258 170 504 minecraft:bone_block
fill 259 170 464 259 173 464 minecraft:brown_terracotta
setblock 259 170 503 minecraft:bone_block
fill 259 170 504 259 173 504 minecraft:brown_terracotta
fill 260 170 503 260 173 503 minecraft:brown_terracotta
setblock 263 170 464 minecraft:bone_block
setblock 263 170 504 minecraft:bone_block
fill 264 170 504 264 171 504 minecraft:brown_terracotta
setblock 274 170 493 minecraft:bone_block
fill 274 170 494 274 173 494 minecraft:brown_terracotta
setblock 274 170 497 minecraft:brown_terracotta
setblock 275 170 472 minecraft:bone_block
fill 275 170 473 275 171 475 minecraft:brown_terracotta
setblock 275 170 487 minecraft:bone_block
fill 275 170 488 275 173 488 minecraft:brown_terracotta
setblock 275 170 492 minecraft:bone_block
fill 275 170 493 275 173 493 minecraft:brown_terracotta
setblock 275 170 497 minecraft:bone_block
fill 275 170 498 275 173 498 minecraft:brown_terracotta
setblock 276 170 467 minecraft:brown_terracotta
setblock 276 170 471 minecraft:bone_block
fill 276 170 472 276 173 472 minecraft:brown_terracotta
setblock 276 170 476 minecraft:bone_block
fill 276 170 477 276 173 477 minecraft:brown_terracotta
setblock 276 170 481 minecraft:bone_block
fill 276 170 482 276 173 482 minecraft:brown_terracotta
setblock 276 170 486 minecraft:bone_block
fill 276 170 487 276 173 487 minecraft:brown_terracotta
setblock 276 170 491 minecraft:bone_block
fill 276 170 492 276 173 492 minecraft:brown_terracotta
setblock 276 170 496 minecraft:bone_block
fill 276 170 497 276 173 497 minecraft:brown_terracotta
setblock 276 170 501 minecraft:bone_block
fill 276 170 502 276 173 502 minecraft:brown_terracotta
fill 236 171 466 236 171 469 minecraft:brown_terracotta
setblock 236 171 470 minecraft:bone_block
fill 236 171 471 236 171 474 minecraft:brown_terracotta
setblock 236 171 475 minecraft:bone_block
fill 236 171 476 236 174 476 minecraft:brown_terracotta
setblock 236 171 480 minecraft:bone_block
fill 236 171 481 236 174 481 minecraft:brown_terracotta
setblock 236 171 485 minecraft:bone_block
fill 236 171 486 236 174 486 minecraft:brown_terracotta
setblock 236 171 490 minecraft:bone_block
fill 236 171 491 236 174 491 minecraft:brown_terracotta
setblock 236 171 495 minecraft:bone_block
fill 236 171 496 236 174 496 minecraft:brown_terracotta
setblock 236 171 500 minecraft:bone_block
fill 236 171 501 236 174 501 minecraft:brown_terracotta
setblock 237 171 469 minecraft:bone_block
fill 237 171 470 237 171 473 minecraft:brown_terracotta
setblock 237 171 474 minecraft:bone_block
fill 237 171 475 237 174 475 minecraft:brown_terracotta
setblock 237 171 479 minecraft:bone_block
fill 237 171 480 237 174 480 minecraft:brown_terracotta
setblock 237 171 484 minecraft:bone_block
setblock 237 171 485 minecraft:brown_terracotta
setblock 237 171 489 minecraft:bone_block
fill 237 171 490 237 173 490 minecraft:brown_terracotta
setblock 237 171 494 minecraft:bone_block
fill 237 171 495 237 174 495 minecraft:brown_terracotta
fill 238 171 470 238 171 472 minecraft:brown_terracotta
setblock 238 171 473 minecraft:bone_block
fill 238 171 474 238 174 474 minecraft:brown_terracotta
setblock 238 171 478 minecraft:bone_block
fill 238 171 479 238 174 479 minecraft:brown_terracotta
setblock 238 171 493 minecraft:bone_block
setblock 238 171 494 minecraft:brown_terracotta
setblock 239 171 472 minecraft:bone_block
fill 239 171 473 239 172 473 minecraft:brown_terracotta
fill 253 171 464 256 171 464 minecraft:brown_terracotta
fill 254 171 504 256 171 504 minecraft:brown_terracotta
setblock 255 171 465 minecraft:brown_terracotta
setblock 256 171 465 minecraft:bone_block
fill 256 171 503 257 171 503 minecraft:brown_terracotta
setblock 257 171 464 minecraft:bone_block
fill 257 171 465 257 172 465 minecraft:brown_terracotta
setblock 257 171 504 minecraft:bone_block
fill 258 171 464 258 174 464 minecraft:brown_terracotta
setblock 258 171 503 minecraft:bone_block
fill 258 171 504 258 174 504 minecraft:brown_terracotta
fill 259 171 503 259 174 503 minecraft:brown_terracotta
setblock 262 171 464 minecraft:bone_block
setblock 262 171 504 minecraft:bone_block
fill 263 171 504 263 174 504 minecraft:brown_terracotta
setblock 274 171 492 minecraft:bone_block
fill 274 171 493 274 174 493 minecraft:brown_terracotta
setblock 274 171 497 minecraft:bone_block
setblock 275 171 476 minecraft:bone_block
fill 275 171 477 275 174 477 minecraft:brown_terracotta
setblock 275 171 487 minecraft:brown_terracotta
setblock 275 171 491 minecraft:bone_block
fill 275 171 492 275 174 492 minecraft:brown_terracotta
setblock 275 171 496 minecraft:bone_block
fill 275 171 497 275 174 497 minecraft:brown_terracotta
setblock 276 171 470 minecraft:bone_block
fill 276 171 471 276 174 471 minecraft:brown_terracotta
setblock 276 171 475 minecraft:bone_block
fill 276 171 476 276 174 476 minecraft:brown_terracotta
setblock 276 171 480 minecraft:bone_block
fill 276 171 481 276 174 481 minecraft:brown_terracotta
setblock 276 171 485 minecraft:bone_block
fill 276 171 486 276 174 486 minecraft:brown_terracotta
setblock 276 171 490 minecraft:bone_block
fill 276 171 491 276 174 491 minecraft:brown_terracotta
setblock 276 171 495 minecraft:bone_block
fill 276 171 496 276 174 496 minecraft:brown_terracotta
setblock 276 171 500 minecraft:bone_block
fill 276 171 501 276 174 501 minecraft:brown_terracotta
fill 236 172 466 236 172 468 minecraft:brown_terracotta
setblock 236 172 469 minecraft:bone_block
fill 236 172 470 236 172 473 minecraft:brown_terracotta
setblock 236 172 474 minecraft:bone_block
fill 236 172 475 236 175 475 minecraft:brown_terracotta
setblock 236 172 479 minecraft:bone_block
fill 236 172 480 236 175 480 minecraft:brown_terracotta
setblock 236 172 484 minecraft:bone_block
fill 236 172 485 236 175 485 minecraft:brown_terracotta
setblock 236 172 489 minecraft:bone_block
fill 236 172 490 236 175 490 minecraft:brown_terracotta
setblock 236 172 494 minecraft:bone_block
fill 236 172 495 236 175 495 minecraft:brown_terracotta
setblock 236 172 499 minecraft:bone_block
fill 236 172 500 236 175 500 minecraft:brown_terracotta
setblock 237 172 468 minecraft:bone_block
fill 237 172 469 237 172 472 minecraft:brown_terracotta
setblock 237 172 473 minecraft:bone_block
fill 237 172 474 237 175 474 minecraft:brown_terracotta
setblock 237 172 478 minecraft:bone_block
fill 237 172 479 237 175 479 minecraft:brown_terracotta
setblock 237 172 483 minecraft:bone_block
fill 237 172 484 237 175 484 minecraft:brown_terracotta
setblock 237 172 488 minecraft:bone_block
setblock 237 172 489 minecraft:brown_terracotta
setblock 237 172 493 minecraft:bone_block
fill 237 172 494 237 175 494 minecraft:brown_terracotta
setblock 237 172 498 minecraft:bone_block
fill 238 172 470 238 172 471 minecraft:brown_terracotta
setblock 238 172 472 minecraft:bone_block
fill 238 172 473 238 175 473 minecraft:brown_terracotta
setblock 238 172 477 minecraft:bone_block
fill 238 172 478 238 175 478 minecraft:brown_terracotta
setblock 239 172 476 minecraft:bone_block
fill 253 172 464 255 172 464 minecraft:brown_terracotta
fill 254 172 504 255 172 504 minecraft:brown_terracotta
setblock 256 172 464 minecraft:bone_block
setblock 256 172 465 minecraft:brown_terracotta
setblock 256 172 503 minecraft:brown_terracotta
setblock 256 172 504 minecraft:bone_block
fill 257 172 464 257 175 464 minecraft:brown_terracotta
setblock 257 172 503 minecraft:bone_block
fill 257 172 504 257 175 504 minecraft:brown_terracotta
fill 258 172 503 258 175 503 minecraft:brown_terracotta
setblock 261 172 464 minecraft:bone_block
setblock 261 172 504 minecraft:bone_block
fill 262 172 504 262 175 504 minecraft:brown_terracotta
fill 274 172 492 274 173 492 minecraft:brown_terracotta
setblock 274 172 496 minecraft:bone_block
fill 274 172 497 274 174 498 minecraft:brown_terracotta
fill 275 172 473 275 172 474 minecraft:brown_terracotta
setblock 275 172 475 minecraft:bone_block
fill 275 172 476 275 175 476 minecraft:brown_terracotta
fill 275 172 478 275 172 479 minecraft:brown_terracotta
setblock 275 172 490 minecraft:bone_block
fill 275 172 491 275 175 491 minecraft:brown_terracotta
setblock 275 172 495 minecraft:bone_block
fill 275 172 496 275 175 496 minecraft:brown_terracotta
setblock 275 172 499 minecraft:brown_terracotta
setblock 275 172 500 minecraft:bone_block
setblock 276 172 469 minecraft:bone_block
fill 276 172 470 276 175 470 minecraft:brown_terracotta
setblock 276 172 474 minecraft:bone_block
fill 276 172 475 276 175 475 minecraft:brown_terracotta
setblock 276 172 479 minecraft:bone_block
fill 276 172 480 276 175 480 minecraft:brown_terracotta
setblock 276 172 484 minecraft:bone_block
fill 276 172 485 276 175 485 minecraft:brown_terracotta
setblock 276 172 489 minecraft:bone_block
fill 276 172 490 276 175 490 minecraft:brown_terracotta
setblock 276 172 494 minecraft:bone_block
fill 276 172 495 276 175 495 minecraft:brown_terracotta
setblock 276 172 499 minecraft:bone_block
fill 276 172 500 276 175 500 minecraft:brown_terracotta
setblock 236 173 467 minecraft:brown_terracotta
setblock 236 173 468 minecraft:bone_block
fill 236 173 469 236 173 472 minecraft:brown_terracotta
setblock 236 173 473 minecraft:bone_block
fill 236 173 474 236 176 474 minecraft:brown_terracotta
setblock 236 173 478 minecraft:bone_block
fill 236 173 479 236 176 479 minecraft:brown_terracotta
setblock 236 173 483 minecraft:bone_block
fill 236 173 484 236 176 484 minecraft:brown_terracotta
setblock 236 173 488 minecraft:bone_block
fill 236 173 489 236 176 489 minecraft:brown_terracotta
setblock 236 173 493 minecraft:bone_block
fill 236 173 494 236 176 494 minecraft:brown_terracotta
setblock 236 173 498 minecraft:bone_block
fill 236 173 499 236 176 499 minecraft:brown_terracotta
fill 237 173 469 237 173 471 minecraft:brown_terracotta
setblock 237 173 472 minecraft:bone_block
fill 237 173 473 237 176 473 minecraft:brown_terracotta
setblock 237 173 477 minecraft:bone_block
fill 237 173 478 237 176 478 minecraft:brown_terracotta
setblock 237 173 482 minecraft:bone_block
fill 237 173 483 237 176 483 minecraft:brown_terracotta
setblock 237 173 492 minecraft:bone_block
fill 237 173 493 237 174 493 minecraft:brown_terracotta
setblock 237 173 497 minecraft:bone_block
fill 237 173 498 237 176 498 minecraft:brown_terracotta
setblock 238 173 471 minecraft:bone_block
fill 238 173 472 238 176 472 minecraft:brown_terracotta
setblock 238 173 476 minecraft:bone_block
fill 238 173 477 238 176 477 minecraft:brown_terracotta
setblock 239 173 475 minecraft:bone_block
fill 239 173 476 239 176 476 minecraft:brown_terracotta
fill 252 173 464 254 173 464 minecraft:brown_terracotta
fill 253 173 504 254 173 504 minecraft:brown_terracotta
setblock 255 173 464 minecraft:bone_block
setblock 255 173 503 minecraft:brown_terracotta
setblock 255 173 504 minecraft:bone_block
fill 256 173 464 256 176 464 minecraft:brown_terracotta
setblock 256 173 503 minecraft:bone_block
fill 256 173 504 256 176 504 minecraft:brown_terracotta
fill 257 173 503 257 176 503 minecraft:brown_terracotta
setblock 260 173 464 minecraft:bone_block
setblock 260 173 504 minecraft:bone_block
setblock 261 173 503 minecraft:bone_block
fill 261 173 504 261 176 504 minecraft:brown_terracotta
setblock 274 173 495 minecraft:bone_block
fill 274 173 496 274 176 496 minecraft:brown_terracotta
setblock 275 173 473 minecraft:brown_terracotta
setblock 275 173 474 minecraft:bone_block
fill 275 173 475 275 176 475 minecraft:brown_terracotta
setblock 275 173 478 minecraft:brown_terracotta
setblock 275 173 479 minecraft:bone_block
fill 275 173 480 275 175 481 minecraft:brown_terracotta
setblock 275 173 489 minecraft:bone_block
fill 275 173 490 275 176 490 minecraft:brown_terracotta
setblock 275 173 494 minecraft:bone_block
fill 275 173 495 275 176 495 minecraft:brown_terracotta
setblock 275 173 499 minecraft:bone_block
fill 275 173 500 275 175 501 minecraft:brown_terracotta
fill 276 173 469 276 176 469 minecraft:brown_terracotta
setblock 276 173 473 minecraft:bone_block
fill 276 173 474 276 176 474 minecraft:brown_terracotta
setblock 276 173 478 minecraft:bone_block
fill 276 173 479 276 176 479 minecraft:brown_terracotta
setblock 276 173 483 minecraft:bone_block
fill 276 173 484 276 176 484 minecraft:brown_terracotta
setblock 276 173 488 minecraft:bone_block
fill 276 173 489 276 176 489 minecraft:brown_terracotta
setblock 276 173 493 minecraft:bone_block
fill 276 173 494 276 176 494 minecraft:brown_terracotta
setblock 276 173 498 minecraft:bone_block
fill 276 173 499 276 176 499 minecraft:brown_terracotta
setblock 276 173 503 minecraft:bone_block
setblock 236 174 466 minecraft:brown_terracotta
setblock 236 174 467 minecraft:bone_block
fill 236 174 468 236 174 471 minecraft:brown_terracotta
setblock 236 174 472 minecraft:bone_block
fill 236 174 473 236 177 473 minecraft:brown_terracotta
setblock 236 174 477 minecraft:bone_block
fill 236 174 478 236 177 478 minecraft:brown_terracotta
setblock 236 174 482 minecraft:bone_block
fill 236 174 483 236 177 483 minecraft:brown_terracotta
setblock 236 174 487 minecraft:bone_block
fill 236 174 488 236 177 488 minecraft:brown_terracotta
setblock 236 174 492 minecraft:bone_block
fill 236 174 493 236 177 493 minecraft:brown_terracotta
setblock 236 174 497 minecraft:bone_block
fill 236 174 498 236 177 498 minecraft:brown_terracotta
setblock 236 174 502 minecraft:bone_block
fill 237 174 469 237 174 470 minecraft:brown_terracotta
setblock 237 174 471 minecraft:bone_block
fill 237 174 472 237 177 472 minecraft:brown_terracotta
setblock 237 174 476 minecraft:bone_block
fill 237 174 477 237 177 477 minecraft:brown_terracotta
setblock 237 174 481 minecraft:bone_block
fill 237 174 482 237 177 482 minecraft:brown_terracotta
setblock 237 174 492 minecraft:brown_terracotta
setblock 237 174 496 minecraft:bone_block
fill 237 174 497 237 177 497 minecraft:brown_terracotta
fill 237 174 499 237 175 499 minecraft:brown_terracotta
setblock 238 174 471 minecraft:brown_terracotta
setblock 238 174 475 minecraft:bone_block
fill 238 174 476 238 177 476 minecraft:brown_terracotta
setblock 238 174 480 minecraft:bone_block
fill 252 174 464 253 174 464 minecraft:brown_terracotta
fill 252 174 504 253 174 504 minecraft:brown_terracotta
fill 253 174 503 254 174 503 minecraft:brown_terracotta
setblock 254 174 464 minecraft:bone_block
setblock 254 174 504 minecraft:bone_block
fill 255 174 464 255 177 464 minecraft:brown_terracotta
setblock 255 174 503 minecraft:bone_block
fill 255 174 504 255 177 504 minecraft:brown_terracotta
setblock 256 174 502 minecraft:bone_block
fill 256 174 503 256 177 503 minecraft:brown_terracotta
fill 257 174 502 259 175 502 minecraft:brown_terracotta
setblock 259 174 464 minecraft:bone_block
setblock 259 174 504 minecraft:bone_block
setblock 260 174 464 minecraft:brown_terracotta
setblock 260 174 503 minecraft:bone_block
fill 260 174 504 260 177 504 minecraft:brown_terracotta
fill 261 174 503 261 177 503 minecraft:brown_terracotta
setblock 274 174 494 minecraft:bone_block
fill 274 174 495 274 177 495 minecraft:brown_terracotta
setblock 274 174 499 minecraft:bone_block
setblock 274 174 504 minecraft:bone_block
setblock 275 174 472 minecraft:brown_terracotta
setblock 275 174 473 minecraft:bone_block
fill 275 174 474 275 177 474 minecraft:brown_terracotta
setblock 275 174 478 minecraft:bone_block
fill 275 174 479 275 177 479 minecraft:brown_terracotta
setblock 275 174 482 minecraft:brown_terracotta
setblock 275 174 483 minecraft:bone_block
fill 275 174 484 275 177 484 minecraft:brown_terracotta
setblock 275 174 487 minecraft:brown_terracotta
setblock 275 174 488 minecraft:bone_block
fill 275 174 489 275 177 489 minecraft:brown_terracotta
setblock 275 174 493 minecraft:bone_block
fill 275 174 494 275 177 494 minecraft:brown_terracotta
setblock 275 174 498 minecraft:bone_block
fill 275 174 499 275 177 499 minecraft:brown_terracotta
fill 275 174 504 276 176 504 minecraft:brown_terracotta
setblock 276 174 472 minecraft:bone_block
fill 276 174 473 276 177 473 minecraft:brown_terracotta
setblock 276 174 477 minecraft:bone_block
fill 276 174 478 276 177 478 minecraft:brown_terracotta
setblock 276 174 482 minecraft:bone_block
fill 276 174 483 276 177 483 minecraft:brown_terracotta
setblock 276 174 487 minecraft:bone_block
fill 276 174 488 276 177 488 minecraft:brown_terracotta
setblock 276 174 492 minecraft:bone_block
fill 276 174 493 276 177 493 minecraft:brown_terracotta
setblock 276 174 497 minecraft:bone_block
fill 276 174 498 276 177 498 minecraft:brown_terracotta
setblock 276 174 502 minecraft:bone_block
fill 276 174 503 276 177 503 minecraft:brown_terracotta
setblock 236 175 465 minecraft:brown_terracotta
setblock 236 175 466 minecraft:bone_block
fill 236 175 467 236 175 470 minecraft:brown_terracotta
setblock 236 175 471 minecraft:bone_block
fill 236 175 472 236 178 472 minecraft:brown_terracotta
setblock 236 175 476 minecraft:bone_block
fill 236 175 477 236 178 477 minecraft:brown_terracotta
setblock 236 175 481 minecraft:bone_block
fill 236 175 482 236 178 482 minecraft:brown_terracotta
setblock 236 175 486 minecraft:bone_block
fill 236 175 487 236 178 487 minecraft:brown_terracotta
setblock 236 175 491 minecraft:bone_block
fill 236 175 492 236 178 492 minecraft:brown_terracotta
setblock 236 175 496 minecraft:bone_block
fill 236 175 497 236 178 497 minecraft:brown_terracotta
setblock 236 175 501 minecraft:bone_block
fill 236 175 502 236 177 503 minecraft:brown_terracotta
setblock 237 175 469 minecraft:brown_terracotta
setblock 237 175 470 minecraft:bone_block
fill 237 175 471 237 178 471 minecraft:brown_terracotta
setblock 237 175 475 minecraft:bone_block
fill 237 175 476 237 178 476 minecraft:brown_terracotta
setblock 237 175 480 minecraft:bone_block
fill 237 175 481 238 177 481 minecraft:brown_terracotta
setblock 237 175 495 minecraft:bone_block
fill 237 175 496 237 178 496 minecraft:brown_terracotta
setblock 237 175 500 minecraft:bone_block
setblock 238 175 474 minecraft:bone_block
fill 238 175 475 238 178 475 minecraft:brown_terracotta
setblock 238 175 479 minecraft:bone_block
fill 238 175 480 238 178 480 minecraft:brown_terracotta
fill 246 175 477 246 176 477 minecraft:soul_soil
fill 250 175 504 252 175 504 minecraft:brown_terracotta
fill 251 175 464 252 175 464 minecraft:brown_terracotta
fill 252 175 503 253 175 503 minecraft:brown_terracotta
setblock 253 175 464 minecraft:bone_block
setblock 253 175 504 minecraft:bone_block
fill 254 175 464 254 178 464 minecraft:brown_terracotta
setblock 254 175 502 minecraft:brown_terracotta
setblock 254 175 503 minecraft:bone_block
fill 254 175 504 254 178 504 minecraft:brown_terracotta
fill 255 175 465 255 176 465 minecraft:brown_terracotta
setblock 255 175 502 minecraft:bone_block
fill 255 175 503 255 178 503 minecraft:brown_terracotta
fill 256 175 502 256 178 502 minecraft:brown_terracotta
setblock 258 175 464 minecraft:bone_block
setblock 258 175 504 minecraft:bone_block
fill 259 175 464 259 178 464 minecraft:brown_terracotta
setblock 259 175 503 minecraft:bone_block
fill 259 175 504 259 178 504 minecraft:brown_terracotta
setblock 260 175 502 minecraft:bone_block
fill 260 175 503 260 178 503 minecraft:brown_terracotta
fill 262 175 503 262 176 503 minecraft:brown_terracotta
setblock 263 175 504 minecraft:bone_block
setblock 272 175 504 minecraft:brown_terracotta
setblock 273 175 504 minecraft:bone_block
fill 274 175 476 274 175 477 minecraft:brown_terracotta
setblock 274 175 478 minecraft:bone_block
fill 274 175 479 274 178 479 minecraft:brown_terracotta
setblock 274 175 493 minecraft:bone_block
fill 274 175 494 274 178 494 minecraft:brown_terracotta
setblock 274 175 497 minecraft:brown_terracotta
setblock 274 175 498 minecraft:bone_block
fill 274 175 499 274 177 500 minecraft:brown_terracotta
fill 274 175 504 274 178 504 minecraft:brown_terracotta
setblock 275 175 472 minecraft:bone_block
fill 275 175 473 275 178 473 minecraft:brown_terracotta
setblock 275 175 477 minecraft:bone_block
fill 275 175 478 275 178 478 minecraft:brown_terracotta
setblock 275 175 482 minecraft:bone_block
fill 275 175 483 275 178 483 minecraft:brown_terracotta
fill 275 175 485 275 175 486 minecraft:brown_terracotta
setblock 275 175 487 minecraft:bone_block
fill 275 175 488 275 178 488 minecraft:brown_terracotta
setblock 275 175 492 minecraft:bone_block
fill 275 175 493 275 178 493 minecraft:brown_terracotta
setblock 275 175 497 minecraft:bone_block
fill 275 175 498 275 178 498 minecraft:brown_terracotta
setblock 275 175 502 minecraft:bone_block
setblock 276 175 471 minecraft:bone_block
fill 276 175 472 276 178 472 minecraft:brown_terracotta
setblock 276 175 476 minecraft:bone_block
fill 276 175 477 276 178 477 minecraft:brown_terracotta
setblock 276 175 481 minecraft:bone_block
fill 276 175 482 276 178 482 minecraft:brown_terracotta
setblock 276 175 486 minecraft:bone_block
fill 276 175 487 276 178 487 minecraft:brown_terracotta
setblock 276 175 491 minecraft:bone_block
fill 276 175 492 276 178 492 minecraft:brown_terracotta
setblock 276 175 496 minecraft:bone_block
fill 276 175 497 276 178 497 minecraft:brown_terracotta
setblock 276 175 501 minecraft:bone_block
fill 276 175 502 276 178 502 minecraft:brown_terracotta
setblock 236 176 464 minecraft:brown_terracotta
setblock 236 176 465 minecraft:bone_block
fill 236 176 466 236 176 469 minecraft:brown_terracotta
setblock 236 176 470 minecraft:bone_block
fill 236 176 471 236 179 471 minecraft:brown_terracotta
setblock 236 176 475 minecraft:bone_block
fill 236 176 476 236 179 476 minecraft:brown_terracotta
setblock 236 176 480 minecraft:bone_block
fill 236 176 481 236 179 481 minecraft:brown_terracotta
setblock 236 176 485 minecraft:bone_block
fill 236 176 486 236 179 486 minecraft:brown_terracotta
setblock 236 176 490 minecraft:bone_block
fill 236 176 491 236 179 491 minecraft:brown_terracotta
setblock 236 176 495 minecraft:bone_block
fill 236 176 496 236 179 496 minecraft:brown_terracotta
setblock 236 176 500 minecraft:bone_block
fill 236 176 501 237 178 501 minecraft:brown_terracotta
setblock 236 176 504 minecraft:brown_terracotta
setblock 237 176 464 minecraft:bone_block
setblock 237 176 469 minecraft:bone_block
fill 237 176 470 237 179 470 minecraft:brown_terracotta
setblock 237 176 474 minecraft:bone_block
fill 237 176 475 237 179 475 minecraft:brown_terracotta
setblock 237 176 479 minecraft:bone_block
fill 237 176 480 237 179 480 minecraft:brown_terracotta
setblock 237 176 484 minecraft:bone_block
fill 237 176 485 237 179 485 minecraft:brown_terracotta
fill 237 176 495 237 177 495 minecraft:brown_terracotta
setblock 237 176 499 minecraft:bone_block
fill 237 176 500 237 179 500 minecraft:brown_terracotta
setblock 237 176 504 minecraft:bone_block
fill 238 176 464 239 178 464 minecraft:brown_terracotta
setblock 238 176 466 minecraft:light[level=12]
setblock 238 176 473 minecraft:bone_block
fill 238 176 474 238 179 474 minecraft:brown_terracotta
setblock 238 176 478 minecraft:bone_block
fill 238 176 479 238 179 479 minecraft:brown_terracotta
setblock 238 176 482 minecraft:light[level=12]
setblock 238 176 490 minecraft:light[level=12]
setblock 238 176 498 minecraft:light[level=12]
fill 238 176 504 238 179 504 minecraft:brown_terracotta
setblock 239 176 477 minecraft:bone_block
setblock 246 176 466 minecraft:light[level=12]
setblock 246 176 474 minecraft:light[level=12]
setblock 246 176 482 minecraft:light[level=12]
setblock 246 176 490 minecraft:light[level=12]
setblock 246 176 498 minecraft:light[level=12]
fill 249 176 464 251 176 464 minecraft:brown_terracotta
fill 249 176 504 251 176 504 minecraft:brown_terracotta
fill 251 176 503 252 176 503 minecraft:brown_terracotta
setblock 252 176 464 minecraft:bone_block
fill 252 176 502 253 176 502 minecraft:brown_terracotta
setblock 252 176 504 minecraft:bone_block
fill 253 176 464 253 178 465 minecraft:brown_terracotta
setblock 253 176 503 minecraft:bone_block
fill 253 176 504 253 179 504 minecraft:brown_terracotta
fill 254 176 465 254 177 465 minecraft:brown_terracotta
setblock 254 176 466 minecraft:light[level=12]
setblock 254 176 474 minecraft:light[level=12]
setblock 254 176 482 minecraft:light[level=12]
setblock 254 176 490 minecraft:light[level=12]
setblock 254 176 498 minecraft:light[level=12]
setblock 254 176 502 minecraft:bone_block
fill 254 176 503 254 179 503 minecraft:brown_terracotta
setblock 255 176 501 minecraft:bone_block
fill 255 176 502 255 179 502 minecraft:brown_terracotta
setblock 256 176 465 minecraft:bone_block
fill 256 176 501 258 177 501 minecraft:brown_terracotta
setblock 257 176 464 minecraft:bone_block
fill 257 176 502 258 176 502 minecraft:brown_terracotta
setblock 257 176 504 minecraft:bone_block
fill 258 176 464 258 179 464 minecraft:brown_terracotta
setblock 258 176 503 minecraft:bone_block
fill 258 176 504 258 179 504 minecraft:brown_terracotta
setblock 259 176 502 minecraft:bone_block
fill 259 176 503 259 179 503 minecraft:brown_terracotta
fill 260 176 502 260 179 502 minecraft:brown_terracotta
setblock 262 176 466 minecraft:light[level=12]
setblock 262 176 474 minecraft:light[level=12]
setblock 262 176 482 minecraft:light[level=12]
setblock 262 176 490 minecraft:light[level=12]
setblock 262 176 498 minecraft:light[level=12]
setblock 262 176 504 minecraft:bone_block
fill 263 176 504 265 177 504 minecraft:brown_terracotta
fill 269 176 504 271 176 504 minecraft:brown_terracotta
setblock 270 176 466 minecraft:light[level=12]
setblock 270 176 474 minecraft:light[level=12]
setblock 270 176 482 minecraft:light[level=12]
setblock 270 176 490 minecraft:light[level=12]
setblock 270 176 498 minecraft:light[level=12]
setblock 272 176 503 minecraft:brown_terracotta
setblock 272 176 504 minecraft:bone_block
setblock 273 176 503 minecraft:bone_block
fill 273 176 504 273 179 504 minecraft:brown_terracotta
fill 274 176 475 274 176 476 minecraft:brown_terracotta
setblock 274 176 477 minecraft:bone_block
fill 274 176 478 274 179 478 minecraft:brown_terracotta
fill 274 176 480 274 176 481 minecraft:brown_terracotta
setblock 274 176 482 minecraft:bone_block
setblock 274 176 492 minecraft:bone_block
fill 274 176 493 274 179 493 minecraft:brown_terracotta
setblock 274 176 497 minecraft:bone_block
fill 274 176 498 274 179 498 minecraft:brown_terracotta
setblock 274 176 501 minecraft:brown_terracotta
fill 274 176 503 275 178 503 minecraft:brown_terracotta
fill 275 176 472 275 179 472 minecraft:brown_terracotta
setblock 275 176 476 minecraft:bone_block
fill 275 176 477 275 179 477 minecraft:brown_terracotta
setblock 275 176 480 minecraft:brown_terracotta
setblock 275 176 481 minecraft:bone_block
fill 275 176 482 275 179 482 minecraft:brown_terracotta
setblock 275 176 485 minecraft:brown_terracotta
setblock 275 176 486 minecraft:bone_block
fill 275 176 487 275 179 487 minecraft:brown_terracotta
setblock 275 176 491 minecraft:bone_block
fill 275 176 492 275 179 492 minecraft:brown_terracotta
setblock 275 176 496 minecraft:bone_block
fill 275 176 497 275 179 497 minecraft:brown_terracotta
setblock 275 176 500 minecraft:brown_terracotta
setblock 275 176 501 minecraft:bone_block
fill 275 176 502 275 179 502 minecraft:brown_terracotta
setblock 276 176 470 minecraft:bone_block
fill 276 176 471 276 179 471 minecraft:brown_terracotta
setblock 276 176 475 minecraft:bone_block
fill 276 176 476 276 179 476 minecraft:brown_terracotta
setblock 276 176 480 minecraft:bone_block
fill 276 176 481 276 179 481 minecraft:brown_terracotta
setblock 276 176 485 minecraft:bone_block
fill 276 176 486 276 179 486 minecraft:brown_terracotta
setblock 276 176 490 minecraft:bone_block
fill 276 176 491 276 179 491 minecraft:brown_terracotta
setblock 276 176 495 minecraft:bone_block
fill 276 176 496 276 179 496 minecraft:brown_terracotta
setblock 276 176 500 minecraft:bone_block
fill 276 176 501 276 179 501 minecraft:brown_terracotta
setblock 236 177 464 minecraft:bone_block
fill 236 177 465 236 177 468 minecraft:brown_terracotta
setblock 236 177 469 minecraft:bone_block
fill 236 177 470 236 180 470 minecraft:brown_terracotta
setblock 236 177 474 minecraft:bone_block
fill 236 177 475 236 180 475 minecraft:brown_terracotta
setblock 236 177 479 minecraft:bone_block
fill 236 177 480 236 180 480 minecraft:brown_terracotta
setblock 236 177 484 minecraft:bone_block
fill 236 177 485 236 180 485 minecraft:brown_terracotta
setblock 236 177 489 minecraft:bone_block
fill 236 177 490 236 180 490 minecraft:brown_terracotta
setblock 236 177 494 minecraft:bone_block
fill 236 177 495 236 180 495 minecraft:brown_terracotta
setblock 236 177 499 minecraft:bone_block
fill 236 177 500 236 180 500 minecraft:brown_terracotta
setblock 236 177 504 minecraft:bone_block
fill 237 177 464 237 180 464 minecraft:brown_terracotta
fill 237 177 469 237 180 469 minecraft:brown_terracotta
setblock 237 177 473 minecraft:bone_block
fill 237 177 474 237 180 474 minecraft:brown_terracotta
setblock 237 177 478 minecraft:bone_block
fill 237 177 479 237 180 479 minecraft:brown_terracotta
setblock 237 177 483 minecraft:bone_block
fill 237 177 484 237 180 484 minecraft:brown_terracotta
setblock 237 177 498 minecraft:bone_block
fill 237 177 499 237 180 499 minecraft:brown_terracotta
setblock 237 177 502 minecraft:brown_terracotta
fill 237 177 504 237 180 504 minecraft:brown_terracotta
setblock 238 177 472 minecraft:bone_block
fill 238 177 473 238 179 473 minecraft:brown_terracotta
setblock 238 177 477 minecraft:bone_block
fill 238 177 478 238 180 478 minecraft:brown_terracotta
setblock 238 177 482 minecraft:bone_block
setblock 239 177 477 minecraft:brown_terracotta
fill 239 177 504 240 177 504 minecraft:brown_terracotta
setblock 240 177 464 minecraft:brown_terracotta
fill 247 177 464 250 177 464 minecraft:brown_terracotta
fill 247 177 504 250 177 504 minecraft:brown_terracotta
fill 249 177 503 251 177 503 minecraft:brown_terracotta
setblock 251 177 464 minecraft:bone_block
fill 251 177 465 252 179 465 minecraft:brown_terracotta
fill 251 177 502 252 177 502 minecraft:brown_terracotta
setblock 251 177 504 minecraft:bone_block
fill 252 177 464 252 180 464 minecraft:brown_terracotta
setblock 252 177 503 minecraft:bone_block
fill 252 177 504 252 180 504 minecraft:brown_terracotta
setblock 253 177 501 minecraft:brown_terracotta
setblock 253 177 502 minecraft:bone_block
fill 253 177 503 253 180 503 minecraft:brown_terracotta
setblock 254 177 501 minecraft:bone_block
fill 254 177 502 254 180 502 minecraft:brown_terracotta
setblock 255 177 465 minecraft:bone_block
fill 255 177 501 255 180 501 minecraft:brown_terracotta
setblock 256 177 464 minecraft:bone_block
fill 256 177 465 257 179 465 minecraft:brown_terracotta
setblock 256 177 504 minecraft:bone_block
fill 257 177 464 257 180 464 minecraft:brown_terracotta
setblock 257 177 502 minecraft:brown_terracotta
setblock 257 177 503 minecraft:bone_block
fill 257 177 504 257 180 504 minecraft:brown_terracotta
setblock 258 177 502 minecraft:bone_block
fill 258 177 503 258 180 503 minecraft:brown_terracotta
setblock 259 177 501 minecraft:bone_block
fill 259 177 502 259 180 502 minecraft:brown_terracotta
setblock 260 177 464 minecraft:brown_terracotta
fill 261 177 502 261 178 502 minecraft:brown_terracotta
setblock 261 177 504 minecraft:bone_block
setblock 262 177 503 minecraft:bone_block
fill 262 177 504 262 180 504 minecraft:brown_terracotta
fill 263 177 503 263 180 503 minecraft:brown_terracotta
setblock 266 177 504 minecraft:bone_block
fill 267 177 504 270 177 504 minecraft:brown_terracotta
fill 269 177 503 271 177 503 minecraft:brown_terracotta
setblock 271 177 504 minecraft:bone_block
setblock 272 177 503 minecraft:bone_block
fill 272 177 504 272 180 504 minecraft:brown_terracotta
setblock 273 177 502 minecraft:bone_block
fill 273 177 503 273 180 503 minecraft:brown_terracotta
fill 274 177 474 274 177 475 minecraft:brown_terracotta
setblock 274 177 476 minecraft:bone_block
fill 274 177 477 274 180 477 minecraft:brown_terracotta
setblock 274 177 480 minecraft:brown_terracotta
setblock 274 177 481 minecraft:bone_block
fill 274 177 482 274 177 485 minecraft:brown_terracotta
fill 274 177 492 274 179 492 minecraft:brown_terracotta
setblock 274 177 496 minecraft:bone_block
fill 274 177 497 274 180 497 minecraft:brown_terracotta
setblock 274 177 501 minecraft:bone_block
fill 274 177 502 274 180 502 minecraft:brown_terracotta
setblock 275 177 475 minecraft:bone_block
fill 275 177 476 275 180 476 minecraft:brown_terracotta
setblock 275 177 480 minecraft:bone_block
fill 275 177 481 275 180 481 minecraft:brown_terracotta
setblock 275 177 485 minecraft:bone_block
fill 275 177 486 275 180 486 minecraft:brown_terracotta
setblock 275 177 490 minecraft:bone_block
fill 275 177 491 275 180 491 minecraft:brown_terracotta
setblock 275 177 495 minecraft:bone_block
fill 275 177 496 275 180 496 minecraft:brown_terracotta
setblock 275 177 500 minecraft:bone_block
fill 275 177 501 275 180 501 minecraft:brown_terracotta
setblock 275 177 504 minecraft:brown_terracotta
setblock 276 177 469 minecraft:bone_block
fill 276 177 470 276 180 470 minecraft:brown_terracotta
setblock 276 177 474 minecraft:bone_block
fill 276 177 475 276 180 475 minecraft:brown_terracotta
setblock 276 177 479 minecraft:bone_block
fill 276 177 480 276 180 480 minecraft:brown_terracotta
setblock 276 177 484 minecraft:bone_block
fill 276 177 485 276 180 485 minecraft:brown_terracotta
setblock 276 177 489 minecraft:bone_block
fill 276 177 490 276 180 490 minecraft:brown_terracotta
setblock 276 177 494 minecraft:bone_block
fill 276 177 495 276 180 495 minecraft:brown_terracotta
setblock 276 177 499 minecraft:bone_block
fill 276 177 500 276 180 500 minecraft:brown_terracotta
setblock 276 177 504 minecraft:bone_block
fill 236 178 464 236 178 467 minecraft:brown_terracotta
setblock 236 178 468 minecraft:bone_block
fill 236 178 469 236 181 469 minecraft:brown_terracotta
setblock 236 178 473 minecraft:bone_block
fill 236 178 474 236 181 474 minecraft:brown_terracotta
setblock 236 178 478 minecraft:bone_block
fill 236 178 479 236 181 479 minecraft:brown_terracotta
setblock 236 178 483 minecraft:bone_block
fill 236 178 484 236 181 484 minecraft:brown_terracotta
setblock 236 178 488 minecraft:bone_block
fill 236 178 489 236 181 489 minecraft:brown_terracotta
setblock 236 178 493 minecraft:bone_block
fill 236 178 494 236 180 494 minecraft:brown_terracotta
setblock 236 178 498 minecraft:bone_block
fill 236 178 499 236 181 499 minecraft:brown_terracotta
setblock 236 178 502 minecraft:brown_terracotta
setblock 236 178 503 minecraft:bone_block
fill 236 178 504 236 181 504 minecraft:brown_terracotta
fill 237 178 468 237 181 468 minecraft:brown_terracotta
setblock 237 178 472 minecraft:bone_block
fill 237 178 473 237 181 473 minecraft:brown_terracotta
setblock 237 178 477 minecraft:bone_block
fill 237 178 478 237 181 478 minecraft:brown_terracotta
setblock 237 178 481 minecraft:brown_terracotta
setblock 237 178 482 minecraft:bone_block
fill 237 178 483 237 181 483 minecraft:brown_terracotta
setblock 237 178 486 minecraft:brown_terracotta
setblock 237 178 497 minecraft:bone_block
fill 237 178 498 237 180 498 minecraft:brown_terracotta
setblock 237 178 502 minecraft:bone_block
fill 237 178 503 238 180 503 minecraft:brown_terracotta
setblock 238 178 472 minecraft:brown_terracotta
setblock 238 178 476 minecraft:bone_block
fill 238 178 477 238 181 477 minecraft:brown_terracotta
setblock 238 178 481 minecraft:bone_block
fill 238 178 482 238 181 482 minecraft:brown_terracotta
setblock 239 178 504 minecraft:brown_terracotta
setblock 240 178 464 minecraft:bone_block
setblock 240 178 504 minecraft:bone_block
fill 241 178 464 244 178 464 minecraft:brown_terracotta
fill 241 178 504 244 178 504 minecraft:brown_terracotta
setblock 245 178 464 minecraft:bone_block
setblock 245 178 504 minecraft:bone_block
fill 246 178 464 249 178 464 minecraft:brown_terracotta
fill 246 178 504 249 178 504 minecraft:brown_terracotta
fill 247 178 503 250 178 503 minecraft:brown_terracotta
setblock 249 178 465 minecraft:bone_block
fill 249 178 502 251 178 502 minecraft:brown_terracotta
setblock 250 178 464 minecraft:bone_block
fill 250 178 465 250 181 465 minecraft:brown_terracotta
setblock 250 178 504 minecraft:bone_block
fill 251 178 464 251 181 464 minecraft:brown_terracotta
setblock 251 178 503 minecraft:bone_block
fill 251 178 504 251 181 504 minecraft:brown_terracotta
setblock 252 178 501 minecraft:brown_terracotta
setblock 252 178 502 minecraft:bone_block
fill 252 178 503 252 181 503 minecraft:brown_terracotta
setblock 253 178 501 minecraft:bone_block
fill 253 178 502 253 181 502 minecraft:brown_terracotta
setblock 254 178 465 minecraft:bone_block
fill 254 178 501 254 181 501 minecraft:brown_terracotta
setblock 255 178 464 minecraft:bone_block
fill 255 178 465 255 181 465 minecraft:brown_terracotta
setblock 255 178 504 minecraft:bone_block
fill 256 178 464 256 181 464 minecraft:brown_terracotta
fill 256 178 501 257 178 501 minecraft:brown_terracotta
setblock 256 178 503 minecraft:bone_block
fill 256 178 504 256 181 504 minecraft:brown_terracotta
setblock 257 178 502 minecraft:bone_block
fill 257 178 503 257 181 503 minecraft:brown_terracotta
setblock 258 178 501 minecraft:bone_block
fill 258 178 502 258 181 502 minecraft:brown_terracotta
fill 259 178 501 259 180 501 minecraft:brown_terracotta
setblock 260 178 464 minecraft:bone_block
setblock 260 178 504 minecraft:bone_block
setblock 261 178 503 minecraft:bone_block
fill 261 178 504 261 181 504 minecraft:brown_terracotta
setblock 262 178 502 minecraft:bone_block
fill 262 178 503 262 181 503 minecraft:brown_terracotta
fill 263 178 504 264 178 504 minecraft:brown_terracotta
fill 264 178 503 265 178 503 minecraft:brown_terracotta
setblock 265 178 504 minecraft:bone_block
setblock 266 178 503 minecraft:bone_block
fill 266 178 504 269 178 504 minecraft:brown_terracotta
fill 267 178 503 270 178 503 minecraft:brown_terracotta
fill 270 178 502 271 178 502 minecraft:brown_terracotta
setblock 270 178 504 minecraft:bone_block
setblock 271 178 503 minecraft:bone_block
fill 271 178 504 271 181 504 minecraft:brown_terracotta
setblock 272 178 502 minecraft:bone_block
fill 272 178 503 272 181 503 minecraft:brown_terracotta
fill 273 178 464 274 178 464 minecraft:brown_terracotta
fill 273 178 477 273 178 480 minecraft:brown_terracotta
setblock 273 178 481 minecraft:bone_block
fill 273 178 482 274 180 482 minecraft:brown_terracotta
fill 273 178 498 273 179 499 minecraft:brown_terracotta
fill 273 178 502 273 181 502 minecraft:brown_terracotta
setblock 274 178 474 minecraft:brown_terracotta
setblock 274 178 475 minecraft:bone_block
fill 274 178 476 274 181 476 minecraft:brown_terracotta
setblock 274 178 480 minecraft:bone_block
fill 274 178 481 274 181 481 minecraft:brown_terracotta
fill 274 178 483 274 178 484 minecraft:brown_terracotta
setblock 274 178 485 minecraft:bone_block
fill 274 178 486 274 179 488 minecraft:brown_terracotta
setblock 274 178 495 minecraft:bone_block
fill 274 178 496 274 181 496 minecraft:brown_terracotta
setblock 274 178 499 minecraft:brown_terracotta
setblock 274 178 500 minecraft:bone_block
fill 274 178 501 274 181 501 minecraft:brown_terracotta
setblock 275 178 464 minecraft:bone_block
fill 275 178 471 275 180 471 minecraft:brown_terracotta
setblock 275 178 474 minecraft:bone_block
fill 275 178 475 275 181 475 minecraft:brown_terracotta
setblock 275 178 479 minecraft:bone_block
fill 275 178 480 275 181 480 minecraft:brown_terracotta
setblock 275 178 484 minecraft:bone_block
fill 275 178 485 275 181 485 minecraft:brown_terracotta
setblock 275 178 489 minecraft:bone_block
fill 275 178 490 275 181 490 minecraft:brown_terracotta
setblock 275 178 494 minecraft:bone_block
fill 275 178 495 275 181 495 minecraft:brown_terracotta
setblock 275 178 499 minecraft:bone_block
fill 275 178 500 275 181 500 minecraft:brown_terracotta
setblock 275 178 504 minecraft:bone_block
fill 276 178 464 276 178 467 minecraft:brown_terracotta
setblock 276 178 468 minecraft:bone_block
fill 276 178 469 276 181 469 minecraft:brown_terracotta
setblock 276 178 473 minecraft:bone_block
fill 276 178 474 276 181 474 minecraft:brown_terracotta
setblock 276 178 478 minecraft:bone_block
fill 276 178 479 276 181 479 minecraft:brown_terracotta
setblock 276 178 483 minecraft:bone_block
fill 276 178 484 276 181 484 minecraft:brown_terracotta
setblock 276 178 488 minecraft:bone_block
fill 276 178 489 276 181 489 minecraft:brown_terracotta
setblock 276 178 493 minecraft:bone_block
fill 276 178 494 276 181 494 minecraft:brown_terracotta
setblock 276 178 498 minecraft:bone_block
fill 276 178 499 276 181 499 minecraft:brown_terracotta
setblock 276 178 503 minecraft:bone_block
fill 276 178 504 276 181 504 minecraft:brown_terracotta
fill 236 179 464 236 179 466 minecraft:brown_terracotta
setblock 236 179 467 minecraft:bone_block
fill 236 179 468 236 182 468 minecraft:brown_terracotta
setblock 236 179 472 minecraft:bone_block
fill 236 179 473 236 182 473 minecraft:brown_terracotta
setblock 236 179 477 minecraft:bone_block
fill 236 179 478 236 182 478 minecraft:brown_terracotta
setblock 236 179 482 minecraft:bone_block
fill 236 179 483 236 182 483 minecraft:brown_terracotta
setblock 236 179 487 minecraft:bone_block
fill 236 179 488 236 182 488 minecraft:brown_terracotta
setblock 236 179 492 minecraft:bone_block
fill 236 179 493 236 180 493 minecraft:brown_terracotta
setblock 236 179 497 minecraft:bone_block
fill 236 179 498 236 182 498 minecraft:brown_terracotta
setblock 236 179 501 minecraft:brown_terracotta
setblock 236 179 502 minecraft:bone_block
fill 236 179 503 236 182 503 minecraft:brown_terracotta
setblock 237 179 465 minecraft:brown_terracotta
setblock 237 179 466 minecraft:bone_block
fill 237 179 467 237 182 467 minecraft:brown_terracotta
setblock 237 179 471 minecraft:bone_block
fill 237 179 472 237 182 472 minecraft:brown_terracotta
setblock 237 179 476 minecraft:bone_block
fill 237 179 477 237 182 477 minecraft:brown_terracotta
setblock 237 179 481 minecraft:bone_block
fill 237 179 482 237 182 482 minecraft:brown_terracotta
setblock 237 179 486 minecraft:bone_block
setblock 237 179 497 minecraft:brown_terracotta
setblock 237 179 501 minecraft:bone_block
fill 237 179 502 237 182 502 minecraft:brown_terracotta
setblock 238 179 464 minecraft:brown_terracotta
setblock 238 179 465 minecraft:bone_block
setblock 238 179 475 minecraft:bone_block
fill 238 179 476 238 181 476 minecraft:brown_terracotta
setblock 238 179 480 minecraft:bone_block
fill 238 179 481 238 182 481 minecraft:brown_terracotta
fill 238 179 483 238 180 483 minecraft:brown_terracotta
setblock 239 179 464 minecraft:bone_block
setblock 239 179 504 minecraft:bone_block
fill 240 179 464 243 179 464 minecraft:brown_terracotta
fill 240 179 504 243 179 504 minecraft:brown_terracotta
setblock 244 179 464 minecraft:bone_block
setblock 244 179 504 minecraft:bone_block
fill 245 179 464 248 179 464 minecraft:brown_terracotta
fill 245 179 504 248 179 504 minecraft:brown_terracotta
fill 246 179 503 249 179 503 minecraft:brown_terracotta
setblock 248 179 465 minecraft:bone_block
fill 248 179 502 250 179 502 minecraft:brown_terracotta
setblock 249 179 464 minecraft:bone_block
fill 249 179 465 249 182 465 minecraft:brown_terracotta
setblock 249 179 504 minecraft:bone_block
fill 250 179 464 250 182 464 minecraft:brown_terracotta
setblock 250 179 503 minecraft:bone_block
fill 250 179 504 250 182 504 minecraft:brown_terracotta
setblock 251 179 501 minecraft:brown_terracotta
setblock 251 179 502 minecraft:bone_block
fill 251 179 503 251 182 503 minecraft:brown_terracotta
setblock 252 179 501 minecraft:bone_block
fill 252 179 502 252 182 502 minecraft:brown_terracotta
setblock 253 179 464 minecraft:brown_terracotta
setblock 253 179 465 minecraft:bone_block
fill 253 179 501 253 182 501 minecraft:brown_terracotta
setblock 254 179 464 minecraft:bone_block
fill 254 179 465 254 182 465 minecraft:brown_terracotta
setblock 254 179 504 minecraft:bone_block
fill 255 179 464 255 182 464 minecraft:brown_terracotta
fill 255 179 500 255 180 500 minecraft:brown_terracotta
setblock 255 179 503 minecraft:bone_block
fill 255 179 504 255 182 504 minecraft:brown_terracotta
setblock 256 179 501 minecraft:brown_terracotta
setblock 256 179 502 minecraft:bone_block
fill 256 179 503 256 182 503 minecraft:brown_terracotta
setblock 257 179 501 minecraft:bone_block
fill 257 179 502 257 182 502 minecraft:brown_terracotta
fill 258 179 501 258 181 501 minecraft:brown_terracotta
setblock 259 179 464 minecraft:bone_block
setblock 259 179 504 minecraft:bone_block
fill 260 179 464 260 182 464 minecraft:brown_terracotta
setblock 260 179 503 minecraft:bone_block
fill 260 179 504 260 182 504 minecraft:brown_terracotta
setblock 261 179 502 minecraft:bone_block
fill 261 179 503 261 182 503 minecraft:brown_terracotta
fill 262 179 502 262 181 502 minecraft:brown_terracotta
setblock 263 179 504 minecraft:brown_terracotta
setblock 264 179 503 minecraft:brown_terracotta
setblock 264 179 504 minecraft:bone_block
setblock 265 179 503 minecraft:bone_block
fill 265 179 504 268 179 504 minecraft:brown_terracotta
fill 266 179 503 269 179 503 minecraft:brown_terracotta
fill 268 179 502 270 179 502 minecraft:brown_terracotta
setblock 269 179 504 minecraft:bone_block
setblock 270 179 503 minecraft:bone_block
fill 270 179 504 270 182 504 minecraft:brown_terracotta
fill 271 179 464 273 179 464 minecraft:brown_terracotta
setblock 271 179 502 minecraft:bone_block
fill 271 179 503 271 182 503 minecraft:brown_terracotta
fill 272 179 502 272 182 502 minecraft:brown_terracotta
fill 273 179 477 273 179 479 minecraft:brown_terracotta
setblock 273 179 480 minecraft:bone_block
fill 273 179 481 273 182 481 minecraft:brown_terracotta
fill 273 179 483 273 179 484 minecraft:brown_terracotta
setblock 273 179 500 minecraft:bone_block
setblock 274 179 464 minecraft:bone_block
setblock 274 179 474 minecraft:bone_block
fill 274 179 475 274 182 475 minecraft:brown_terracotta
setblock 274 179 479 minecraft:bone_block
fill 274 179 480 274 182 480 minecraft:brown_terracotta
setblock 274 179 483 minecraft:brown_terracotta
setblock 274 179 484 minecraft:bone_block
fill 274 179 485 274 182 485 minecraft:brown_terracotta
setblock 274 179 489 minecraft:bone_block
fill 274 179 490 274 179 491 minecraft:brown_terracotta
setblock 274 179 494 minecraft:bone_block
fill 274 179 495 274 180 495 minecraft:brown_terracotta
setblock 274 179 499 minecraft:bone_block
fill 274 179 500 274 182 500 minecraft:brown_terracotta
setblock 274 179 503 minecraft:brown_terracotta
setblock 274 179 504 minecraft:bone_block
fill 275 179 464 276 181 464 minecraft:brown_terracotta
setblock 275 179 473 minecraft:bone_block
fill 275 179 474 275 182 474 minecraft:brown_terracotta
setblock 275 179 478 minecraft:bone_block
fill 275 179 479 275 182 479 minecraft:brown_terracotta
setblock 275 179 483 minecraft:bone_block
fill 275 179 484 275 182 484 minecraft:brown_terracotta
setblock 275 179 488 minecraft:bone_block
fill 275 179 489 275 182 489 minecraft:brown_terracotta
setblock 275 179 493 minecraft:bone_block
fill 275 179 494 275 182 494 minecraft:brown_terracotta
setblock 275 179 498 minecraft:bone_block
fill 275 179 499 275 182 499 minecraft:brown_terracotta
setblock 275 179 503 minecraft:bone_block
fill 275 179 504 275 182 504 minecraft:brown_terracotta
fill 276 179 465 276 179 466 minecraft:brown_terracotta
setblock 276 179 467 minecraft:bone_block
fill 276 179 468 276 182 468 minecraft:brown_terracotta
setblock 276 179 472 minecraft:bone_block
fill 276 179 473 276 182 473 minecraft:brown_terracotta
setblock 276 179 477 minecraft:bone_block
fill 276 179 478 276 182 478 minecraft:brown_terracotta
setblock 276 179 482 minecraft:bone_block
fill 276 179 483 276 182 483 minecraft:brown_terracotta
setblock 276 179 487 minecraft:bone_block
fill 276 179 488 276 182 488 minecraft:brown_terracotta
setblock 276 179 492 minecraft:bone_block
fill 276 179 493 276 182 493 minecraft:brown_terracotta
setblock 276 179 497 minecraft:bone_block
fill 276 179 498 276 182 498 minecraft:brown_terracotta
setblock 276 179 502 minecraft:bone_block
fill 276 179 503 276 182 503 minecraft:brown_terracotta
fill 236 180 464 236 180 465 minecraft:brown_terracotta
setblock 236 180 466 minecraft:bone_block
fill 236 180 467 236 183 467 minecraft:brown_terracotta
setblock 236 180 471 minecraft:bone_block
fill 236 180 472 236 183 472 minecraft:brown_terracotta
setblock 236 180 476 minecraft:bone_block
fill 236 180 477 236 183 477 minecraft:brown_terracotta
setblock 236 180 481 minecraft:bone_block
fill 236 180 482 236 183 482 minecraft:brown_terracotta
setblock 236 180 486 minecraft:bone_block
fill 236 180 487 236 183 487 minecraft:brown_terracotta
setblock 236 180 491 minecraft:bone_block
setblock 236 180 492 minecraft:brown_terracotta
setblock 236 180 496 minecraft:bone_block
fill 236 180 497 236 182 497 minecraft:brown_terracotta
setblock 236 180 501 minecraft:bone_block
fill 236 180 502 236 183 502 minecraft:brown_terracotta
setblock 237 180 465 minecraft:bone_block
fill 237 180 466 237 183 466 minecraft:brown_terracotta
setblock 237 180 470 minecraft:bone_block
fill 237 180 471 237 181 471 minecraft:brown_terracotta
setblock 237 180 475 minecraft:bone_block
fill 237 180 476 237 183 476 minecraft:brown_terracotta
setblock 237 180 480 minecraft:bone_block
fill 237 180 481 237 183 481 minecraft:brown_terracotta
setblock 237 180 485 minecraft:bone_block
fill 237 180 486 237 182 486 minecraft:brown_terracotta
setblock 237 180 500 minecraft:bone_block
fill 237 180 501 237 181 501 minecraft:brown_terracotta
setblock 238 180 464 minecraft:bone_block
fill 238 180 465 239 182 465 minecraft:brown_terracotta
setblock 238 180 474 minecraft:bone_block
setblock 238 180 475 minecraft:brown_terracotta
setblock 238 180 479 minecraft:bone_block
fill 238 180 480 238 182 480 minecraft:brown_terracotta
setblock 238 180 504 minecraft:bone_block
fill 239 180 464 242 180 464 minecraft:brown_terracotta
setblock 239 180 503 minecraft:bone_block
fill 239 180 504 242 180 504 minecraft:brown_terracotta
setblock 243 180 464 minecraft:bone_block
setblock 243 180 504 minecraft:bone_block
fill 244 180 464 247 180 464 minecraft:brown_terracotta
setblock 244 180 503 minecraft:bone_block
fill 244 180 504 247 180 504 minecraft:brown_terracotta
fill 245 180 503 248 180 503 minecraft:brown_terracotta
setblock 246 180 465 minecraft:brown_terracotta
setblock 247 180 465 minecraft:bone_block
fill 247 180 502 249 180 502 minecraft:brown_terracotta
setblock 248 180 464 minecraft:bone_block
fill 248 180 465 248 183 465 minecraft:brown_terracotta
schedule function dropper:buildpart/113_7 1t
