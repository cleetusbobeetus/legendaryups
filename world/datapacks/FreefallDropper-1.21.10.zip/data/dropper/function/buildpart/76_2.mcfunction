fill 217 234 347 217 235 347 minecraft:magenta_stained_glass
fill 217 234 348 217 235 348 minecraft:purple_stained_glass
fill 217 234 350 217 235 350 minecraft:magenta_stained_glass
fill 217 234 351 218 236 352 minecraft:iron_block
fill 218 234 346 218 236 350 minecraft:iron_block
fill 220 234 347 221 236 348 minecraft:lime_stained_glass
setblock 223 234 364 minecraft:ochre_froglight
setblock 230 234 323 minecraft:white_concrete
fill 230 234 346 230 246 346 minecraft:black_concrete
fill 230 234 355 230 236 355 minecraft:black_concrete
setblock 188 235 324 minecraft:sea_lantern
fill 188 235 345 188 256 345 minecraft:black_concrete
fill 188 235 352 188 308 352 minecraft:black_concrete
fill 188 235 361 188 290 361 minecraft:black_concrete
fill 189 235 323 200 235 363 minecraft:black_stained_glass
setblock 191 235 322 minecraft:black_concrete
setblock 196 235 322 minecraft:white_concrete
setblock 199 235 322 minecraft:sea_lantern
fill 201 235 323 201 235 345 minecraft:black_stained_glass
fill 201 235 346 201 235 350 minecraft:iron_block
fill 201 235 351 201 235 363 minecraft:black_stained_glass
fill 202 235 323 202 235 343 minecraft:black_stained_glass
fill 202 235 353 202 235 363 minecraft:black_stained_glass
fill 203 235 323 203 235 341 minecraft:black_stained_glass
setblock 203 235 342 minecraft:iron_block
setblock 203 235 354 minecraft:iron_block
fill 203 235 355 203 235 363 minecraft:black_stained_glass
setblock 204 235 322 minecraft:white_concrete
fill 204 235 323 205 235 340 minecraft:black_stained_glass
setblock 204 235 341 minecraft:iron_block
setblock 204 235 355 minecraft:iron_block
fill 204 235 356 205 235 363 minecraft:black_stained_glass
fill 206 235 323 207 235 339 minecraft:black_stained_glass
setblock 206 235 347 minecraft:purple_stained_glass
setblock 206 235 350 minecraft:purple_stained_glass
fill 206 235 357 207 235 363 minecraft:black_stained_glass
fill 207 235 346 207 235 350 minecraft:verdant_froglight
fill 208 235 323 229 235 338 minecraft:black_stained_glass
fill 208 235 339 212 235 339 minecraft:iron_block
fill 208 235 345 208 235 346 minecraft:verdant_froglight
fill 208 235 350 208 235 351 minecraft:verdant_froglight
setblock 208 235 352 minecraft:purple_stained_glass
fill 208 235 357 212 235 357 minecraft:iron_block
fill 208 235 358 229 235 363 minecraft:black_stained_glass
fill 209 235 345 212 235 345 minecraft:verdant_froglight
fill 209 235 351 212 235 351 minecraft:verdant_froglight
setblock 211 235 352 minecraft:purple_stained_glass
fill 212 235 346 213 235 346 minecraft:verdant_froglight
fill 212 235 350 213 235 350 minecraft:verdant_froglight
fill 213 235 339 229 235 339 minecraft:black_stained_glass
fill 213 235 347 213 235 349 minecraft:verdant_froglight
fill 213 235 357 229 235 357 minecraft:black_stained_glass
setblock 214 235 322 minecraft:pearlescent_froglight
fill 215 235 340 229 235 340 minecraft:black_stained_glass
fill 215 235 356 229 235 356 minecraft:black_stained_glass
setblock 216 235 341 minecraft:iron_block
setblock 216 235 355 minecraft:iron_block
fill 217 235 341 229 235 341 minecraft:black_stained_glass
setblock 217 235 342 minecraft:iron_block
setblock 217 235 354 minecraft:iron_block
fill 217 235 355 229 235 355 minecraft:black_stained_glass
fill 218 235 342 229 235 343 minecraft:black_stained_glass
fill 218 235 353 229 235 354 minecraft:black_stained_glass
fill 219 235 344 229 235 345 minecraft:black_stained_glass
fill 219 235 346 219 235 350 minecraft:iron_block
fill 219 235 351 229 235 352 minecraft:black_stained_glass
fill 220 235 346 229 235 346 minecraft:black_stained_glass
fill 220 235 349 229 235 350 minecraft:black_stained_glass
fill 222 235 347 229 235 348 minecraft:black_stained_glass
fill 223 235 364 223 262 364 minecraft:black_concrete
fill 230 235 323 230 273 323 minecraft:black_concrete
setblock 230 235 344 minecraft:pearlescent_froglight
fill 188 236 324 188 252 324 minecraft:black_concrete
setblock 188 236 344 minecraft:sea_lantern
setblock 191 236 322 minecraft:pearlescent_froglight
fill 196 236 322 196 295 322 minecraft:black_concrete
fill 199 236 322 199 245 322 minecraft:black_concrete
fill 203 236 346 203 236 350 minecraft:iron_block
fill 204 236 322 204 256 322 minecraft:black_concrete
fill 204 236 344 204 236 347 minecraft:iron_block
fill 204 236 349 204 236 352 minecraft:iron_block
fill 205 236 343 205 236 344 minecraft:iron_block
fill 205 236 352 205 236 353 minecraft:iron_block
fill 206 236 342 206 236 343 minecraft:iron_block
fill 206 236 353 206 236 354 minecraft:iron_block
fill 207 236 342 209 236 342 minecraft:iron_block
fill 207 236 346 207 236 350 minecraft:lime_stained_glass
fill 207 236 354 209 236 354 minecraft:iron_block
fill 208 236 341 212 236 341 minecraft:iron_block
fill 208 236 345 212 236 345 minecraft:lime_stained_glass
fill 208 236 351 212 236 351 minecraft:lime_stained_glass
fill 208 236 355 212 236 355 minecraft:iron_block
fill 211 236 342 214 236 342 minecraft:iron_block
fill 211 236 354 214 236 354 minecraft:iron_block
fill 213 236 346 213 236 350 minecraft:lime_stained_glass
fill 214 236 322 214 245 322 minecraft:black_concrete
fill 214 236 343 215 236 343 minecraft:iron_block
fill 214 236 353 215 236 353 minecraft:iron_block
fill 215 236 344 216 236 344 minecraft:iron_block
fill 215 236 352 216 236 352 minecraft:iron_block
fill 216 236 345 216 236 347 minecraft:iron_block
fill 216 236 349 216 236 351 minecraft:iron_block
fill 217 236 346 217 236 350 minecraft:iron_block
setblock 230 236 342 minecraft:sea_lantern
fill 230 236 344 230 303 344 minecraft:black_concrete
fill 188 237 344 188 241 344 minecraft:black_concrete
setblock 188 237 351 minecraft:pearlescent_froglight
fill 191 237 322 191 245 322 minecraft:black_concrete
setblock 191 237 325 minecraft:light[level=15]
setblock 191 237 333 minecraft:light[level=15]
setblock 191 237 341 minecraft:light[level=15]
setblock 191 237 349 minecraft:light[level=15]
setblock 191 237 357 minecraft:light[level=15]
setblock 199 237 325 minecraft:light[level=15]
setblock 199 237 333 minecraft:light[level=15]
setblock 199 237 341 minecraft:light[level=15]
fill 199 237 346 206 238 350 minecraft:light_gray_concrete
setblock 199 237 357 minecraft:light[level=15]
fill 200 237 343 208 238 345 minecraft:light_gray_concrete
fill 200 237 351 208 238 353 minecraft:light_gray_concrete
fill 201 237 342 219 240 342 minecraft:light_gray_concrete
fill 201 237 354 219 240 354 minecraft:light_gray_concrete
fill 202 237 341 218 240 341 minecraft:light_gray_concrete
fill 202 237 355 218 240 355 minecraft:light_gray_concrete
fill 203 237 340 217 240 340 minecraft:light_gray_concrete
fill 203 237 356 217 240 356 minecraft:light_gray_concrete
fill 204 237 339 216 240 339 minecraft:light_gray_concrete
fill 204 237 357 216 240 357 minecraft:light_gray_concrete
fill 205 237 338 215 240 338 minecraft:light_gray_concrete
fill 205 237 358 215 240 358 minecraft:light_gray_concrete
setblock 207 237 325 minecraft:light[level=15]
setblock 207 237 333 minecraft:light[level=15]
fill 207 237 346 207 238 346 minecraft:light_gray_concrete
fill 207 237 350 207 238 350 minecraft:light_gray_concrete
fill 208 237 337 212 240 337 minecraft:light_gray_concrete
fill 208 237 359 212 240 359 minecraft:light_gray_concrete
fill 209 237 343 220 238 344 minecraft:light_gray_concrete
fill 209 237 352 220 238 353 minecraft:light_gray_concrete
fill 212 237 345 220 238 345 minecraft:light_gray_concrete
fill 212 237 351 220 238 351 minecraft:light_gray_concrete
fill 213 237 346 221 238 346 minecraft:light_gray_concrete
fill 213 237 350 221 238 350 minecraft:light_gray_concrete
fill 214 237 347 221 238 349 minecraft:light_gray_concrete
setblock 215 237 325 minecraft:light[level=15]
setblock 215 237 333 minecraft:light[level=15]
setblock 216 237 322 minecraft:sea_lantern
setblock 223 237 325 minecraft:light[level=15]
setblock 223 237 333 minecraft:light[level=15]
setblock 223 237 341 minecraft:light[level=15]
setblock 223 237 349 minecraft:light[level=15]
setblock 223 237 357 minecraft:light[level=15]
setblock 230 237 326 minecraft:pearlescent_froglight
fill 230 237 342 230 241 342 minecraft:black_concrete
setblock 230 237 351 minecraft:pearlescent_froglight
setblock 230 237 355 minecraft:white_concrete
setblock 188 238 326 minecraft:sea_lantern
setblock 188 238 338 minecraft:white_concrete
setblock 188 238 346 minecraft:sea_lantern
setblock 188 238 351 minecraft:white_concrete
fill 197 238 344 197 239 352 minecraft:sea_lantern
fill 198 238 342 198 239 345 minecraft:sea_lantern
fill 198 238 346 198 239 350 minecraft:light_gray_concrete
fill 198 238 351 198 239 354 minecraft:sea_lantern
fill 199 238 340 199 239 342 minecraft:sea_lantern
fill 199 238 343 199 239 345 minecraft:light_gray_concrete
fill 199 238 351 199 239 353 minecraft:light_gray_concrete
fill 199 238 354 199 239 356 minecraft:sea_lantern
fill 200 238 339 200 239 340 minecraft:sea_lantern
fill 200 238 341 200 239 342 minecraft:light_gray_concrete
fill 200 238 354 200 239 355 minecraft:light_gray_concrete
fill 200 238 356 200 239 357 minecraft:sea_lantern
fill 201 238 338 201 239 339 minecraft:sea_lantern
fill 201 238 340 201 239 341 minecraft:light_gray_concrete
fill 201 238 355 201 239 356 minecraft:light_gray_concrete
fill 201 238 357 201 239 358 minecraft:sea_lantern
fill 202 238 337 202 239 338 minecraft:sea_lantern
fill 202 238 339 202 239 340 minecraft:light_gray_concrete
fill 202 238 356 202 239 357 minecraft:light_gray_concrete
fill 202 238 358 202 239 359 minecraft:sea_lantern
fill 203 238 337 204 239 337 minecraft:sea_lantern
fill 203 238 338 203 239 339 minecraft:light_gray_concrete
fill 203 238 357 203 239 358 minecraft:light_gray_concrete
fill 203 238 359 204 239 359 minecraft:sea_lantern
fill 204 238 336 207 239 336 minecraft:sea_lantern
fill 204 238 338 204 239 338 minecraft:light_gray_concrete
fill 204 238 358 204 239 358 minecraft:light_gray_concrete
fill 204 238 360 207 239 360 minecraft:sea_lantern
fill 205 238 337 207 239 337 minecraft:light_gray_concrete
fill 205 238 359 207 239 359 minecraft:light_gray_concrete
fill 206 238 335 214 239 335 minecraft:sea_lantern
fill 206 238 361 214 239 361 minecraft:sea_lantern
fill 208 238 336 212 239 336 minecraft:light_gray_concrete
fill 208 238 360 212 239 360 minecraft:light_gray_concrete
fill 213 238 336 216 239 336 minecraft:sea_lantern
fill 213 238 337 215 239 337 minecraft:light_gray_concrete
fill 213 238 359 215 239 359 minecraft:light_gray_concrete
fill 213 238 360 216 239 360 minecraft:sea_lantern
fill 216 238 322 216 239 322 minecraft:black_concrete
fill 216 238 337 218 239 337 minecraft:sea_lantern
fill 216 238 338 217 239 338 minecraft:light_gray_concrete
fill 216 238 358 217 239 358 minecraft:light_gray_concrete
fill 216 238 359 218 239 359 minecraft:sea_lantern
fill 217 238 339 218 239 339 minecraft:light_gray_concrete
fill 217 238 357 218 239 357 minecraft:light_gray_concrete
fill 218 238 338 219 239 338 minecraft:sea_lantern
fill 218 238 340 219 239 340 minecraft:light_gray_concrete
fill 218 238 356 219 239 356 minecraft:light_gray_concrete
fill 218 238 358 219 239 358 minecraft:sea_lantern
fill 219 238 339 220 239 339 minecraft:sea_lantern
fill 219 238 341 220 239 341 minecraft:light_gray_concrete
fill 219 238 355 220 239 355 minecraft:light_gray_concrete
fill 219 238 357 220 239 357 minecraft:sea_lantern
fill 220 238 340 221 239 340 minecraft:sea_lantern
fill 220 238 342 220 239 342 minecraft:light_gray_concrete
fill 220 238 354 220 239 354 minecraft:light_gray_concrete
fill 220 238 356 221 239 356 minecraft:sea_lantern
fill 221 238 341 221 239 342 minecraft:sea_lantern
fill 221 238 343 221 239 345 minecraft:light_gray_concrete
fill 221 238 351 221 239 353 minecraft:light_gray_concrete
fill 221 238 354 221 239 355 minecraft:sea_lantern
fill 222 238 342 222 239 345 minecraft:sea_lantern
fill 222 238 346 222 239 350 minecraft:light_gray_concrete
fill 222 238 351 222 239 354 minecraft:sea_lantern
fill 223 238 344 223 239 352 minecraft:sea_lantern
fill 230 238 326 230 247 326 minecraft:black_concrete
fill 230 238 351 230 305 351 minecraft:black_concrete
fill 230 238 355 230 245 355 minecraft:black_concrete
fill 188 239 326 188 252 326 minecraft:black_concrete
fill 188 239 338 188 240 338 minecraft:black_concrete
setblock 188 239 341 minecraft:ochre_froglight
fill 188 239 346 188 291 346 minecraft:black_concrete
fill 188 239 351 188 281 351 minecraft:black_concrete
setblock 191 239 325 minecraft:light[level=12]
setblock 191 239 332 minecraft:light[level=12]
setblock 191 239 339 minecraft:light[level=12]
setblock 191 239 346 minecraft:light[level=12]
setblock 191 239 353 minecraft:light[level=12]
setblock 191 239 360 minecraft:light[level=12]
setblock 192 239 364 minecraft:pearlescent_froglight
setblock 195 239 364 minecraft:pearlescent_froglight
setblock 198 239 325 minecraft:light[level=12]
setblock 198 239 332 minecraft:light[level=12]
setblock 198 239 339 minecraft:light[level=12]
setblock 198 239 360 minecraft:light[level=12]
fill 199 239 346 205 239 350 minecraft:light_gray_concrete
fill 200 239 343 206 239 345 minecraft:light_gray_concrete
fill 200 239 351 206 239 353 minecraft:light_gray_concrete
setblock 205 239 325 minecraft:light[level=12]
setblock 205 239 332 minecraft:light[level=12]
fill 206 239 346 206 241 350 minecraft:light_blue_stained_glass
fill 207 239 343 207 239 344 minecraft:light_gray_concrete
fill 207 239 345 207 239 346 minecraft:light_blue_stained_glass
fill 207 239 350 207 239 351 minecraft:light_blue_stained_glass
fill 207 239 352 207 239 353 minecraft:light_gray_concrete
fill 208 239 343 220 239 343 minecraft:light_gray_concrete
fill 208 239 344 208 239 345 minecraft:light_blue_stained_glass
fill 208 239 351 208 239 352 minecraft:light_blue_stained_glass
fill 208 239 353 220 239 353 minecraft:light_gray_concrete
fill 209 239 344 212 241 344 minecraft:light_blue_stained_glass
fill 209 239 352 212 241 352 minecraft:light_blue_stained_glass
setblock 212 239 325 minecraft:light[level=12]
setblock 212 239 332 minecraft:light[level=12]
fill 212 239 345 213 239 345 minecraft:light_blue_stained_glass
fill 212 239 351 213 239 351 minecraft:light_blue_stained_glass
fill 213 239 344 220 239 344 minecraft:light_gray_concrete
fill 213 239 346 214 239 346 minecraft:light_blue_stained_glass
fill 213 239 350 214 239 350 minecraft:light_blue_stained_glass
fill 213 239 352 220 239 352 minecraft:light_gray_concrete
fill 214 239 345 220 239 345 minecraft:light_gray_concrete
fill 214 239 347 214 241 349 minecraft:light_blue_stained_glass
fill 214 239 351 220 239 351 minecraft:light_gray_concrete
fill 215 239 346 221 239 350 minecraft:light_gray_concrete
setblock 219 239 325 minecraft:light[level=12]
setblock 219 239 332 minecraft:light[level=12]
setblock 219 239 360 minecraft:light[level=12]
setblock 226 239 325 minecraft:light[level=12]
setblock 226 239 332 minecraft:light[level=12]
setblock 226 239 339 minecraft:light[level=12]
setblock 226 239 346 minecraft:light[level=12]
setblock 226 239 353 minecraft:light[level=12]
setblock 226 239 360 minecraft:light[level=12]
setblock 230 239 349 minecraft:sea_lantern
setblock 188 240 333 minecraft:sea_lantern
fill 188 240 341 188 271 341 minecraft:black_concrete
setblock 189 240 364 minecraft:pearlescent_froglight
fill 192 240 364 192 308 364 minecraft:black_concrete
fill 195 240 364 195 274 364 minecraft:black_concrete
fill 199 240 346 204 240 350 minecraft:light_gray_concrete
fill 200 240 343 205 240 345 minecraft:light_gray_concrete
fill 200 240 351 205 240 353 minecraft:light_gray_concrete
fill 205 240 346 205 242 350 minecraft:light_blue_stained_glass
fill 206 240 343 207 240 343 minecraft:light_gray_concrete
fill 206 240 344 207 242 345 minecraft:light_blue_stained_glass
fill 206 240 351 207 242 352 minecraft:light_blue_stained_glass
fill 206 240 353 207 240 353 minecraft:light_gray_concrete
fill 208 240 343 208 242 344 minecraft:light_blue_stained_glass
fill 208 240 352 208 242 353 minecraft:light_blue_stained_glass
fill 209 240 343 212 242 343 minecraft:light_blue_stained_glass
fill 209 240 353 212 242 353 minecraft:light_blue_stained_glass
fill 213 240 343 220 240 343 minecraft:light_gray_concrete
fill 213 240 344 214 242 345 minecraft:light_blue_stained_glass
fill 213 240 351 214 242 352 minecraft:light_blue_stained_glass
fill 213 240 353 220 240 353 minecraft:light_gray_concrete
fill 214 240 346 215 242 346 minecraft:light_blue_stained_glass
fill 214 240 350 215 242 350 minecraft:light_blue_stained_glass
fill 215 240 344 220 240 345 minecraft:light_gray_concrete
fill 215 240 347 215 242 349 minecraft:light_blue_stained_glass
fill 215 240 351 220 240 352 minecraft:light_gray_concrete
setblock 216 240 322 minecraft:pearlescent_froglight
fill 216 240 346 221 240 350 minecraft:light_gray_concrete
fill 230 240 349 230 268 349 minecraft:black_concrete
fill 188 241 333 188 247 333 minecraft:black_concrete
setblock 188 241 338 minecraft:ochre_froglight
setblock 188 241 363 minecraft:ochre_froglight
fill 189 241 339 189 242 341 minecraft:light_gray_concrete
fill 189 241 364 189 300 364 minecraft:black_concrete
setblock 200 241 364 minecraft:pearlescent_froglight
setblock 204 241 348 minecraft:light_blue_stained_glass
setblock 205 241 345 minecraft:light_blue_stained_glass
setblock 205 241 351 minecraft:light_blue_stained_glass
setblock 207 241 343 minecraft:light_blue_stained_glass
setblock 207 241 353 minecraft:light_blue_stained_glass
setblock 210 241 342 minecraft:light_blue_stained_glass
setblock 210 241 354 minecraft:light_blue_stained_glass
setblock 213 241 343 minecraft:light_blue_stained_glass
setblock 213 241 353 minecraft:light_blue_stained_glass
setblock 215 241 345 minecraft:light_blue_stained_glass
setblock 215 241 351 minecraft:light_blue_stained_glass
fill 216 241 322 216 255 322 minecraft:black_concrete
setblock 216 241 348 minecraft:light_blue_stained_glass
fill 220 241 347 221 241 348 minecraft:lime_stained_glass
setblock 227 241 364 minecraft:sea_lantern
fill 228 241 339 229 242 341 minecraft:light_gray_concrete
setblock 229 241 322 minecraft:white_concrete
fill 188 242 338 188 308 338 minecraft:black_concrete
setblock 188 242 344 minecraft:ochre_froglight
fill 188 242 363 188 246 363 minecraft:black_concrete
fill 190 242 339 190 243 341 minecraft:light_gray_concrete
fill 191 242 340 191 244 340 minecraft:light_gray_concrete
setblock 197 242 322 minecraft:white_concrete
fill 200 242 364 200 300 364 minecraft:black_concrete
fill 201 242 357 202 243 358 minecraft:end_stone
fill 205 242 361 205 248 361 minecraft:lime_concrete
fill 206 242 346 206 243 346 minecraft:light_blue_stained_glass
fill 206 242 350 206 243 350 minecraft:light_blue_stained_glass
fill 212 242 344 212 243 344 minecraft:light_blue_stained_glass
fill 212 242 352 212 243 352 minecraft:light_blue_stained_glass
fill 219 242 345 221 242 349 minecraft:white_concrete
fill 226 242 340 227 243 340 minecraft:light_gray_concrete
fill 227 242 339 227 243 339 minecraft:light_gray_concrete
fill 227 242 341 227 243 341 minecraft:light_gray_concrete
fill 227 242 364 227 308 364 minecraft:black_concrete
fill 229 242 322 229 245 322 minecraft:black_concrete
setblock 230 242 327 minecraft:pearlescent_froglight
setblock 230 242 342 minecraft:pearlescent_froglight
setblock 230 242 363 minecraft:pearlescent_froglight
setblock 188 243 328 minecraft:pearlescent_froglight
setblock 188 243 330 minecraft:sea_lantern
fill 188 243 344 188 285 344 minecraft:black_concrete
fill 189 243 340 189 244 340 minecraft:lime_concrete
fill 191 243 339 191 244 339 minecraft:light_gray_concrete
fill 191 243 341 191 244 341 minecraft:light_gray_concrete
fill 192 243 340 192 244 340 minecraft:light_gray_concrete
fill 197 243 322 197 289 322 minecraft:black_concrete
setblock 208 243 344 minecraft:light_blue_stained_glass
setblock 208 243 352 minecraft:light_blue_stained_glass
setblock 214 243 346 minecraft:light_blue_stained_glass
setblock 214 243 350 minecraft:light_blue_stained_glass
fill 219 243 345 219 243 349 minecraft:white_concrete
fill 219 243 354 220 244 355 minecraft:end_stone
fill 220 243 345 221 243 345 minecraft:white_concrete
fill 220 243 346 220 243 347 minecraft:black_concrete
fill 220 243 348 221 243 349 minecraft:white_concrete
fill 221 243 346 221 243 347 minecraft:white_concrete
fill 225 243 340 225 244 340 minecraft:light_gray_concrete
fill 226 243 339 226 244 339 minecraft:light_gray_concrete
fill 226 243 341 226 244 341 minecraft:light_gray_concrete
fill 228 243 340 229 243 340 minecraft:lime_concrete
fill 230 243 327 230 263 327 minecraft:black_concrete
fill 230 243 342 230 254 342 minecraft:black_concrete
fill 230 243 363 230 257 363 minecraft:black_concrete
fill 188 244 328 188 252 328 minecraft:black_concrete
fill 188 244 330 188 252 330 minecraft:black_concrete
setblock 188 244 349 minecraft:sea_lantern
setblock 188 244 360 minecraft:pearlescent_froglight
setblock 190 244 340 minecraft:lime_concrete
fill 192 244 339 193 245 339 minecraft:light_gray_concrete
fill 192 244 341 193 245 341 minecraft:light_gray_concrete
fill 193 244 340 193 245 340 minecraft:light_gray_concrete
fill 205 244 360 205 248 360 minecraft:lime_concrete
setblock 220 244 322 minecraft:sea_lantern
fill 224 244 339 224 245 341 minecraft:light_gray_concrete
fill 225 244 339 225 245 339 minecraft:light_gray_concrete
fill 225 244 341 225 245 341 minecraft:light_gray_concrete
setblock 226 244 340 minecraft:light_gray_concrete
fill 227 244 340 228 244 340 minecraft:lime_concrete
fill 188 245 349 188 275 349 minecraft:black_concrete
fill 188 245 360 188 303 360 minecraft:black_concrete
setblock 190 245 364 minecraft:white_concrete
setblock 191 245 325 minecraft:light[level=15]
setblock 191 245 332 minecraft:light[level=12]
setblock 191 245 333 minecraft:light[level=15]
setblock 191 245 339 minecraft:light[level=12]
fill 191 245 340 192 245 340 minecraft:lime_concrete
setblock 191 245 341 minecraft:light[level=15]
setblock 191 245 346 minecraft:light[level=12]
setblock 191 245 349 minecraft:light[level=15]
setblock 191 245 353 minecraft:light[level=12]
setblock 191 245 357 minecraft:light[level=15]
setblock 191 245 360 minecraft:light[level=12]
fill 194 245 339 194 246 341 minecraft:light_gray_concrete
fill 195 245 340 195 247 340 minecraft:light_gray_concrete
setblock 198 245 325 minecraft:light[level=12]
setblock 198 245 332 minecraft:light[level=12]
setblock 198 245 339 minecraft:light[level=12]
setblock 198 245 346 minecraft:light[level=12]
setblock 198 245 353 minecraft:light[level=12]
setblock 198 245 360 minecraft:light[level=12]
setblock 198 245 364 minecraft:sea_lantern
setblock 199 245 325 minecraft:light[level=15]
setblock 199 245 333 minecraft:light[level=15]
setblock 199 245 341 minecraft:light[level=15]
setblock 199 245 349 minecraft:light[level=15]
setblock 199 245 357 minecraft:light[level=15]
setblock 205 245 325 minecraft:light[level=12]
setblock 205 245 332 minecraft:light[level=12]
setblock 205 245 339 minecraft:light[level=12]
setblock 205 245 346 minecraft:light[level=12]
setblock 205 245 353 minecraft:light[level=12]
setblock 207 245 325 minecraft:light[level=15]
setblock 207 245 333 minecraft:light[level=15]
setblock 207 245 341 minecraft:light[level=15]
setblock 207 245 357 minecraft:light[level=15]
setblock 212 245 325 minecraft:light[level=12]
setblock 212 245 332 minecraft:light[level=12]
setblock 212 245 339 minecraft:light[level=12]
setblock 212 245 353 minecraft:light[level=12]
setblock 212 245 360 minecraft:light[level=12]
setblock 215 245 325 minecraft:light[level=15]
setblock 215 245 333 minecraft:light[level=15]
setblock 215 245 341 minecraft:light[level=15]
setblock 215 245 349 minecraft:light[level=15]
setblock 215 245 357 minecraft:light[level=15]
setblock 219 245 325 minecraft:light[level=12]
setblock 219 245 332 minecraft:light[level=12]
setblock 219 245 339 minecraft:light[level=12]
setblock 219 245 346 minecraft:light[level=12]
setblock 219 245 353 minecraft:light[level=12]
setblock 219 245 360 minecraft:light[level=12]
fill 220 245 322 220 258 322 minecraft:black_concrete
fill 222 245 340 223 246 340 minecraft:light_gray_concrete
fill 222 245 347 222 246 347 minecraft:lime_stained_glass
setblock 223 245 325 minecraft:light[level=15]
setblock 223 245 333 minecraft:light[level=15]
fill 223 245 339 223 246 339 minecraft:light_gray_concrete
fill 223 245 341 223 246 341 minecraft:light_gray_concrete
setblock 223 245 349 minecraft:light[level=15]
setblock 223 245 357 minecraft:light[level=15]
fill 225 245 340 226 245 340 minecraft:lime_concrete
setblock 226 245 325 minecraft:light[level=12]
setblock 226 245 332 minecraft:light[level=12]
setblock 226 245 339 minecraft:light[level=12]
setblock 226 245 346 minecraft:light[level=12]
setblock 226 245 353 minecraft:light[level=12]
setblock 226 245 360 minecraft:light[level=12]
setblock 230 245 341 minecraft:ochre_froglight
setblock 188 246 323 minecraft:ochre_froglight
fill 190 246 364 190 304 364 minecraft:black_concrete
setblock 191 246 322 minecraft:pearlescent_froglight
fill 191 246 327 191 252 327 minecraft:lime_concrete
fill 192 246 340 193 246 340 minecraft:lime_concrete
setblock 194 246 322 minecraft:ochre_froglight
fill 195 246 339 195 247 339 minecraft:light_gray_concrete
fill 195 246 341 195 247 341 minecraft:light_gray_concrete
fill 196 246 340 196 247 340 minecraft:light_gray_concrete
fill 198 246 364 198 292 364 minecraft:black_concrete
setblock 199 246 322 minecraft:ochre_froglight
setblock 200 246 322 minecraft:sea_lantern
fill 204 246 360 204 248 361 minecraft:lime_concrete
fill 205 246 362 205 248 362 minecraft:lime_concrete
fill 206 246 360 206 248 361 minecraft:lime_concrete
setblock 206 246 364 minecraft:ochre_froglight
setblock 213 246 322 minecraft:sea_lantern
setblock 214 246 322 minecraft:white_concrete
fill 221 246 340 221 247 340 minecraft:light_gray_concrete
fill 222 246 339 222 247 339 minecraft:light_gray_concrete
fill 222 246 341 222 247 341 minecraft:light_gray_concrete
fill 224 246 340 225 246 340 minecraft:lime_concrete
setblock 228 246 364 minecraft:white_concrete
setblock 229 246 322 minecraft:sea_lantern
fill 230 246 341 230 256 341 minecraft:black_concrete
setblock 230 246 343 minecraft:sea_lantern
setblock 230 246 355 minecraft:sea_lantern
fill 188 247 323 188 254 323 minecraft:black_concrete
setblock 188 247 334 minecraft:pearlescent_froglight
setblock 188 247 363 minecraft:white_concrete
fill 191 247 322 191 264 322 minecraft:black_concrete
fill 191 247 326 191 252 326 minecraft:lime_concrete
fill 193 247 340 194 247 340 minecraft:lime_concrete
fill 194 247 322 194 274 322 minecraft:black_concrete
fill 196 247 339 197 247 339 minecraft:light_gray_concrete
fill 196 247 341 197 247 341 minecraft:light_gray_concrete
fill 197 247 340 198 248 340 minecraft:light_gray_concrete
fill 199 247 322 200 308 322 minecraft:black_concrete
fill 206 247 364 206 253 364 minecraft:black_concrete
setblock 208 247 322 minecraft:white_concrete
fill 213 247 322 214 249 322 minecraft:black_concrete
setblock 215 247 322 minecraft:sea_lantern
setblock 215 247 364 minecraft:ochre_froglight
fill 219 247 340 220 248 340 minecraft:light_gray_concrete
fill 220 247 339 221 247 339 minecraft:light_gray_concrete
fill 220 247 341 221 247 341 minecraft:light_gray_concrete
setblock 221 247 322 minecraft:sea_lantern
setblock 222 247 340 minecraft:light_gray_concrete
fill 222 247 347 222 255 347 minecraft:gray_concrete
fill 223 247 340 224 247 340 minecraft:lime_concrete
fill 228 247 364 228 308 364 minecraft:black_concrete
fill 229 247 322 229 308 322 minecraft:black_concrete
fill 230 247 343 230 290 343 minecraft:black_concrete
setblock 230 247 346 minecraft:ochre_froglight
fill 230 247 355 230 262 355 minecraft:black_concrete
setblock 188 248 331 minecraft:ochre_froglight
setblock 188 248 333 minecraft:pearlescent_froglight
setblock 188 248 334 minecraft:white_concrete
setblock 188 248 363 minecraft:sea_lantern
fill 190 248 326 190 252 328 minecraft:lime_concrete
fill 191 248 328 192 252 328 minecraft:lime_concrete
fill 192 248 326 192 252 327 minecraft:lime_concrete
fill 195 248 340 196 248 340 minecraft:lime_concrete
fill 197 248 339 199 248 339 minecraft:light_gray_concrete
fill 197 248 341 199 248 341 minecraft:light_gray_concrete
fill 199 248 340 200 249 340 minecraft:light_gray_concrete
fill 200 248 359 203 255 363 minecraft:light_gray_concrete
fill 204 248 359 204 253 359 minecraft:light_gray_concrete
setblock 204 248 362 minecraft:lime_concrete
fill 204 248 363 210 258 363 minecraft:light_gray_concrete
setblock 205 248 359 minecraft:lime_concrete
fill 206 248 359 210 252 359 minecraft:light_gray_concrete
setblock 206 248 362 minecraft:lime_concrete
fill 207 248 360 210 254 362 minecraft:light_gray_concrete
fill 208 248 322 208 264 322 minecraft:black_concrete
fill 215 248 322 215 270 322 minecraft:black_concrete
fill 215 248 364 215 300 364 minecraft:black_concrete
fill 217 248 340 218 249 340 minecraft:light_gray_concrete
fill 218 248 339 220 248 339 minecraft:light_gray_concrete
fill 218 248 341 220 248 341 minecraft:light_gray_concrete
fill 221 248 322 221 275 322 minecraft:black_concrete
fill 221 248 340 222 248 340 minecraft:lime_concrete
fill 223 248 347 223 255 347 minecraft:gray_concrete
setblock 230 248 326 minecraft:white_concrete
setblock 230 248 332 minecraft:white_concrete
fill 230 248 346 230 260 346 minecraft:black_concrete
fill 188 249 331 188 289 331 minecraft:black_concrete
fill 188 249 333 188 276 334 minecraft:black_concrete
setblock 188 249 337 minecraft:sea_lantern
setblock 188 249 342 minecraft:pearlescent_froglight
setblock 188 249 354 minecraft:pearlescent_froglight
fill 188 249 363 188 308 363 minecraft:black_concrete
fill 189 249 326 189 252 327 minecraft:lime_concrete
fill 190 249 325 192 252 325 minecraft:lime_concrete
fill 191 249 329 191 252 329 minecraft:lime_concrete
fill 193 249 326 193 252 327 minecraft:lime_concrete
fill 196 249 340 198 249 340 minecraft:lime_concrete
fill 199 249 339 201 249 339 minecraft:light_gray_concrete
fill 199 249 341 201 249 341 minecraft:light_gray_concrete
fill 201 249 340 202 250 340 minecraft:light_gray_concrete
fill 204 249 360 206 252 362 minecraft:light_gray_concrete
fill 205 249 359 205 251 359 minecraft:light_gray_concrete
fill 208 249 358 208 250 358 minecraft:lime_stained_glass
setblock 210 249 364 minecraft:sea_lantern
fill 215 249 340 216 250 340 minecraft:light_gray_concrete
fill 216 249 339 218 249 339 minecraft:light_gray_concrete
fill 216 249 341 218 249 341 minecraft:light_gray_concrete
fill 219 249 340 221 249 340 minecraft:lime_concrete
fill 222 249 346 223 255 346 minecraft:gray_concrete
fill 222 249 348 223 255 348 minecraft:gray_concrete
fill 230 249 326 230 308 326 minecraft:black_concrete
fill 230 249 332 230 282 332 minecraft:black_concrete
fill 188 250 337 188 308 337 minecraft:black_concrete
fill 188 250 342 188 263 342 minecraft:black_concrete
fill 188 250 354 188 308 354 minecraft:black_concrete
fill 189 250 325 189 252 325 minecraft:lime_concrete
fill 189 250 328 189 252 328 minecraft:lime_concrete
fill 190 250 324 192 252 324 minecraft:lime_concrete
fill 190 250 329 190 252 329 minecraft:lime_concrete
fill 192 250 329 192 252 329 minecraft:lime_concrete
fill 193 250 325 193 252 325 minecraft:lime_concrete
fill 193 250 328 193 252 328 minecraft:lime_concrete
fill 198 250 340 199 250 340 minecraft:lime_concrete
fill 200 250 339 200 250 341 minecraft:light_gray_concrete
fill 201 250 339 204 250 339 minecraft:light_gray_concrete
fill 201 250 341 204 250 341 minecraft:light_gray_concrete
fill 203 250 340 207 251 340 minecraft:light_gray_concrete
fill 210 250 340 214 251 340 minecraft:light_gray_concrete
fill 210 250 364 210 258 364 minecraft:black_concrete
setblock 213 250 322 minecraft:ochre_froglight
fill 213 250 339 217 250 339 minecraft:light_gray_concrete
fill 213 250 341 217 250 341 minecraft:light_gray_concrete
fill 214 250 322 214 276 322 minecraft:black_concrete
setblock 217 250 340 minecraft:light_gray_concrete
setblock 217 250 364 minecraft:pearlescent_froglight
fill 218 250 340 219 250 340 minecraft:lime_concrete
fill 221 250 346 221 255 348 minecraft:gray_concrete
fill 224 250 347 224 255 347 minecraft:gray_concrete
setblock 188 251 355 minecraft:pearlescent_froglight
fill 189 251 324 189 252 324 minecraft:lime_concrete
fill 189 251 329 189 252 329 minecraft:lime_concrete
fill 190 251 330 192 252 330 minecraft:lime_concrete
setblock 191 251 332 minecraft:light[level=12]
setblock 191 251 339 minecraft:light[level=12]
setblock 191 251 346 minecraft:light[level=12]
setblock 191 251 353 minecraft:light[level=12]
setblock 191 251 360 minecraft:light[level=12]
fill 193 251 324 193 252 324 minecraft:lime_concrete
fill 193 251 329 193 252 329 minecraft:lime_concrete
fill 194 251 325 194 252 328 minecraft:lime_concrete
setblock 195 251 322 minecraft:ochre_froglight
setblock 198 251 325 minecraft:light[level=12]
setblock 198 251 332 minecraft:light[level=12]
setblock 198 251 339 minecraft:light[level=12]
setblock 198 251 346 minecraft:light[level=12]
setblock 198 251 353 minecraft:light[level=12]
setblock 198 251 360 minecraft:light[level=12]
fill 200 251 340 201 251 340 minecraft:lime_concrete
setblock 202 251 340 minecraft:light_gray_concrete
fill 203 251 339 214 251 339 minecraft:light_gray_concrete
fill 203 251 341 214 251 341 minecraft:light_gray_concrete
setblock 205 251 325 minecraft:light[level=12]
setblock 205 251 332 minecraft:light[level=12]
setblock 205 251 346 minecraft:light[level=12]
setblock 205 251 353 minecraft:light[level=12]
setblock 205 251 364 minecraft:sea_lantern
fill 208 251 340 209 252 340 minecraft:light_gray_concrete
fill 208 251 358 208 257 358 minecraft:gray_concrete
setblock 212 251 325 minecraft:light[level=12]
setblock 212 251 332 minecraft:light[level=12]
setblock 212 251 346 minecraft:light[level=12]
setblock 212 251 353 minecraft:light[level=12]
setblock 212 251 360 minecraft:light[level=12]
fill 213 251 322 213 259 322 minecraft:black_concrete
setblock 215 251 340 minecraft:light_gray_concrete
fill 216 251 326 216 252 326 minecraft:gray_concrete
fill 216 251 340 217 251 340 minecraft:lime_concrete
fill 217 251 364 217 308 364 minecraft:black_concrete
setblock 219 251 325 minecraft:light[level=12]
setblock 219 251 332 minecraft:light[level=12]
setblock 219 251 339 minecraft:light[level=12]
setblock 219 251 346 minecraft:light[level=12]
setblock 219 251 353 minecraft:light[level=12]
setblock 219 251 360 minecraft:light[level=12]
fill 222 251 345 223 255 345 minecraft:gray_concrete
fill 222 251 349 223 255 349 minecraft:gray_concrete
fill 224 251 346 224 255 346 minecraft:gray_concrete
fill 224 251 348 224 255 348 minecraft:gray_concrete
setblock 226 251 325 minecraft:light[level=12]
setblock 226 251 332 minecraft:light[level=12]
setblock 226 251 339 minecraft:light[level=12]
setblock 226 251 346 minecraft:light[level=12]
setblock 226 251 353 minecraft:light[level=12]
setblock 226 251 360 minecraft:light[level=12]
fill 188 252 355 188 266 355 minecraft:black_concrete
setblock 189 252 322 minecraft:ochre_froglight
fill 189 252 323 193 252 323 minecraft:lime_concrete
setblock 189 252 330 minecraft:lime_concrete
fill 189 252 331 190 252 331 minecraft:light_gray_concrete
setblock 191 252 331 minecraft:lime_concrete
fill 192 252 331 197 252 331 minecraft:light_gray_concrete
setblock 193 252 330 minecraft:lime_concrete
fill 194 252 323 197 252 323 minecraft:light_gray_concrete
setblock 194 252 324 minecraft:lime_concrete
setblock 194 252 329 minecraft:lime_concrete
fill 194 252 330 197 252 330 minecraft:light_gray_concrete
fill 195 252 322 195 276 322 minecraft:black_concrete
fill 195 252 324 197 252 325 minecraft:light_gray_concrete
fill 195 252 326 195 252 328 minecraft:lime_concrete
fill 195 252 329 197 252 329 minecraft:light_gray_concrete
fill 196 252 326 197 252 328 minecraft:light_gray_concrete
fill 202 252 340 206 252 340 minecraft:lime_concrete
fill 205 252 359 205 258 359 minecraft:lime_concrete
fill 205 252 364 205 301 364 minecraft:black_concrete
setblock 207 252 340 minecraft:light_gray_concrete
fill 207 252 358 207 256 358 minecraft:gray_concrete
fill 208 252 339 209 252 339 minecraft:light_gray_concrete
fill 208 252 341 209 252 341 minecraft:light_gray_concrete
fill 208 252 357 208 259 357 minecraft:gray_concrete
setblock 208 252 364 minecraft:sea_lantern
setblock 210 252 340 minecraft:light_gray_concrete
fill 211 252 340 215 252 340 minecraft:lime_concrete
fill 220 252 346 220 255 348 minecraft:gray_concrete
fill 221 252 345 221 255 345 minecraft:gray_concrete
fill 221 252 349 221 255 349 minecraft:gray_concrete
fill 224 252 345 224 255 345 minecraft:gray_concrete
fill 224 252 349 224 255 349 minecraft:gray_concrete
setblock 225 252 322 minecraft:ochre_froglight
fill 225 252 347 225 255 347 minecraft:gray_concrete
setblock 188 253 324 minecraft:verdant_froglight
setblock 188 253 326 minecraft:verdant_froglight
setblock 188 253 328 minecraft:verdant_froglight
setblock 188 253 330 minecraft:verdant_froglight
fill 189 253 322 189 299 322 minecraft:black_concrete
setblock 189 253 323 minecraft:verdant_froglight
fill 189 253 324 189 271 324 minecraft:light_gray_concrete
setblock 189 253 325 minecraft:verdant_froglight
fill 189 253 326 189 271 326 minecraft:light_gray_concrete
setblock 189 253 327 minecraft:verdant_froglight
fill 189 253 328 189 271 328 minecraft:light_gray_concrete
setblock 189 253 329 minecraft:verdant_froglight
fill 189 253 330 189 271 330 minecraft:light_gray_concrete
setblock 189 253 331 minecraft:verdant_froglight
fill 190 253 323 190 271 323 minecraft:light_gray_concrete
setblock 190 253 324 minecraft:verdant_froglight
fill 190 253 325 190 271 325 minecraft:light_gray_concrete
setblock 190 253 326 minecraft:verdant_froglight
fill 190 253 327 190 271 327 minecraft:light_gray_concrete
setblock 190 253 328 minecraft:verdant_froglight
fill 190 253 329 190 271 329 minecraft:light_gray_concrete
setblock 190 253 330 minecraft:verdant_froglight
fill 190 253 331 190 271 331 minecraft:light_gray_concrete
setblock 191 253 323 minecraft:verdant_froglight
fill 191 253 324 191 271 324 minecraft:light_gray_concrete
setblock 191 253 325 minecraft:verdant_froglight
fill 191 253 326 191 271 326 minecraft:light_gray_concrete
setblock 191 253 327 minecraft:verdant_froglight
fill 191 253 328 191 271 328 minecraft:light_gray_concrete
setblock 191 253 329 minecraft:verdant_froglight
fill 191 253 330 191 271 330 minecraft:light_gray_concrete
setblock 191 253 331 minecraft:verdant_froglight
setblock 191 253 333 minecraft:light[level=15]
setblock 191 253 341 minecraft:light[level=15]
setblock 191 253 349 minecraft:light[level=15]
setblock 191 253 357 minecraft:light[level=15]
fill 192 253 323 192 271 323 minecraft:light_gray_concrete
setblock 192 253 324 minecraft:verdant_froglight
fill 192 253 325 192 271 325 minecraft:light_gray_concrete
setblock 192 253 326 minecraft:verdant_froglight
fill 192 253 327 192 271 327 minecraft:light_gray_concrete
setblock 192 253 328 minecraft:verdant_froglight
fill 192 253 329 192 271 329 minecraft:light_gray_concrete
setblock 192 253 330 minecraft:verdant_froglight
fill 192 253 331 192 271 331 minecraft:light_gray_concrete
setblock 193 253 323 minecraft:verdant_froglight
fill 193 253 324 193 271 324 minecraft:light_gray_concrete
setblock 193 253 325 minecraft:verdant_froglight
fill 193 253 326 193 271 326 minecraft:light_gray_concrete
setblock 193 253 327 minecraft:verdant_froglight
fill 193 253 328 193 271 328 minecraft:light_gray_concrete
setblock 193 253 329 minecraft:verdant_froglight
fill 193 253 330 193 271 330 minecraft:light_gray_concrete
setblock 193 253 331 minecraft:verdant_froglight
fill 194 253 323 194 271 323 minecraft:light_gray_concrete
setblock 194 253 324 minecraft:verdant_froglight
fill 194 253 325 194 271 325 minecraft:light_gray_concrete
setblock 194 253 326 minecraft:verdant_froglight
fill 194 253 327 194 271 327 minecraft:light_gray_concrete
setblock 194 253 328 minecraft:verdant_froglight
fill 194 253 329 194 271 329 minecraft:light_gray_concrete
setblock 194 253 330 minecraft:verdant_froglight
fill 194 253 331 194 271 331 minecraft:light_gray_concrete
setblock 195 253 323 minecraft:verdant_froglight
fill 195 253 324 195 271 324 minecraft:light_gray_concrete
setblock 195 253 325 minecraft:verdant_froglight
fill 195 253 326 195 271 326 minecraft:light_gray_concrete
setblock 195 253 327 minecraft:verdant_froglight
fill 195 253 328 195 271 328 minecraft:light_gray_concrete
setblock 195 253 329 minecraft:verdant_froglight
fill 195 253 330 195 271 330 minecraft:light_gray_concrete
setblock 195 253 331 minecraft:verdant_froglight
fill 196 253 323 196 271 323 minecraft:light_gray_concrete
setblock 196 253 324 minecraft:verdant_froglight
fill 196 253 325 196 271 325 minecraft:light_gray_concrete
setblock 196 253 326 minecraft:verdant_froglight
fill 196 253 327 196 271 327 minecraft:light_gray_concrete
setblock 196 253 328 minecraft:verdant_froglight
fill 196 253 329 196 271 329 minecraft:light_gray_concrete
setblock 196 253 330 minecraft:verdant_froglight
fill 196 253 331 196 270 331 minecraft:light_gray_concrete
setblock 197 253 323 minecraft:verdant_froglight
fill 197 253 324 197 271 324 minecraft:light_gray_concrete
setblock 197 253 325 minecraft:verdant_froglight
fill 197 253 326 197 271 326 minecraft:light_gray_concrete
setblock 197 253 327 minecraft:verdant_froglight
fill 197 253 328 197 271 328 minecraft:light_gray_concrete
setblock 197 253 329 minecraft:verdant_froglight
fill 197 253 330 197 270 330 minecraft:light_gray_concrete
setblock 197 253 331 minecraft:verdant_froglight
setblock 199 253 325 minecraft:light[level=15]
setblock 199 253 333 minecraft:light[level=15]
setblock 199 253 341 minecraft:light[level=15]
setblock 199 253 349 minecraft:light[level=15]
setblock 199 253 357 minecraft:light[level=15]
setblock 202 253 364 minecraft:ochre_froglight
fill 204 253 360 204 253 362 minecraft:light_gray_concrete
fill 205 253 340 212 253 340 minecraft:lime_concrete
fill 205 253 360 205 258 360 minecraft:lime_concrete
fill 205 253 361 206 254 362 minecraft:light_gray_concrete
fill 206 253 359 206 253 360 minecraft:light_gray_concrete
setblock 207 253 325 minecraft:light[level=15]
setblock 207 253 333 minecraft:light[level=15]
setblock 207 253 341 minecraft:light[level=15]
setblock 207 253 349 minecraft:light[level=15]
fill 207 253 357 207 257 357 minecraft:gray_concrete
setblock 207 253 359 minecraft:light_gray_concrete
fill 208 253 359 208 257 359 minecraft:gray_concrete
fill 208 253 364 208 259 364 minecraft:black_concrete
fill 209 253 357 209 258 358 minecraft:gray_concrete
fill 209 253 359 210 253 359 minecraft:light_gray_concrete
setblock 215 253 325 minecraft:light[level=15]
setblock 215 253 333 minecraft:light[level=15]
setblock 215 253 341 minecraft:light[level=15]
setblock 215 253 349 minecraft:light[level=15]
setblock 215 253 357 minecraft:light[level=15]
fill 220 253 345 220 255 345 minecraft:gray_concrete
fill 220 253 349 220 255 349 minecraft:gray_concrete
fill 222 253 344 223 255 344 minecraft:gray_concrete
fill 222 253 350 223 255 350 minecraft:gray_concrete
setblock 223 253 325 minecraft:light[level=15]
setblock 223 253 333 minecraft:light[level=15]
setblock 223 253 341 minecraft:light[level=15]
setblock 223 253 357 minecraft:light[level=15]
fill 225 253 322 225 262 322 minecraft:black_concrete
fill 225 253 346 225 255 346 minecraft:gray_concrete
fill 225 253 348 225 255 348 minecraft:gray_concrete
setblock 230 253 338 minecraft:white_concrete
setblock 230 253 358 minecraft:sea_lantern
fill 188 254 324 188 255 324 minecraft:black_concrete
fill 188 254 326 188 255 326 minecraft:black_concrete
fill 188 254 328 188 255 328 minecraft:black_concrete
fill 188 254 330 188 255 330 minecraft:black_concrete
setblock 188 254 336 minecraft:pearlescent_froglight
fill 189 254 323 189 255 323 minecraft:light_gray_concrete
fill 189 254 325 189 255 325 minecraft:light_gray_concrete
fill 189 254 327 189 255 327 minecraft:light_gray_concrete
fill 189 254 329 189 255 329 minecraft:light_gray_concrete
fill 189 254 331 189 255 331 minecraft:light_gray_concrete
fill 190 254 324 190 255 324 minecraft:light_gray_concrete
fill 190 254 326 190 255 326 minecraft:light_gray_concrete
fill 190 254 328 190 255 328 minecraft:light_gray_concrete
fill 190 254 330 190 255 330 minecraft:light_gray_concrete
fill 191 254 323 191 255 323 minecraft:light_gray_concrete
fill 191 254 325 191 255 325 minecraft:light_gray_concrete
fill 191 254 327 191 255 327 minecraft:light_gray_concrete
fill 191 254 329 191 255 329 minecraft:light_gray_concrete
fill 191 254 331 191 255 331 minecraft:light_gray_concrete
fill 192 254 324 192 255 324 minecraft:light_gray_concrete
fill 192 254 326 192 255 326 minecraft:light_gray_concrete
fill 192 254 328 192 255 328 minecraft:light_gray_concrete
fill 192 254 330 192 255 330 minecraft:light_gray_concrete
fill 193 254 323 193 255 323 minecraft:light_gray_concrete
fill 193 254 325 193 255 325 minecraft:light_gray_concrete
fill 193 254 327 193 255 327 minecraft:light_gray_concrete
fill 193 254 329 193 255 329 minecraft:light_gray_concrete
fill 193 254 331 193 255 331 minecraft:light_gray_concrete
fill 194 254 324 194 255 324 minecraft:light_gray_concrete
fill 194 254 326 194 255 326 minecraft:light_gray_concrete
fill 194 254 328 194 255 328 minecraft:light_gray_concrete
fill 194 254 330 194 255 330 minecraft:light_gray_concrete
fill 195 254 323 195 255 323 minecraft:light_gray_concrete
fill 195 254 325 195 255 325 minecraft:light_gray_concrete
fill 195 254 327 195 255 327 minecraft:light_gray_concrete
fill 195 254 329 195 255 329 minecraft:light_gray_concrete
fill 195 254 331 195 255 331 minecraft:light_gray_concrete
fill 196 254 324 196 255 324 minecraft:light_gray_concrete
fill 196 254 326 196 255 326 minecraft:light_gray_concrete
fill 196 254 328 196 255 328 minecraft:light_gray_concrete
fill 196 254 330 196 255 330 minecraft:light_gray_concrete
fill 197 254 323 197 255 323 minecraft:light_gray_concrete
fill 197 254 325 197 255 325 minecraft:light_gray_concrete
fill 197 254 327 197 255 327 minecraft:light_gray_concrete
fill 197 254 329 197 255 329 minecraft:light_gray_concrete
fill 197 254 331 197 255 331 minecraft:light_gray_concrete
setblock 202 254 364 minecraft:black_concrete
fill 204 254 359 204 258 360 minecraft:lime_concrete
fill 204 254 361 204 255 362 minecraft:light_gray_concrete
fill 205 254 358 205 258 358 minecraft:lime_concrete
fill 206 254 357 206 254 358 minecraft:gray_concrete
fill 206 254 359 206 258 360 minecraft:lime_concrete
setblock 206 254 364 minecraft:sea_lantern
fill 207 254 356 208 258 356 minecraft:gray_concrete
fill 207 254 359 207 255 359 minecraft:gray_concrete
fill 209 254 359 209 258 359 minecraft:gray_concrete
fill 210 254 359 210 255 359 minecraft:light_gray_concrete
setblock 212 254 322 minecraft:sea_lantern
fill 219 254 346 219 255 348 minecraft:gray_concrete
fill 221 254 344 221 255 344 minecraft:gray_concrete
fill 221 254 350 221 255 350 minecraft:gray_concrete
fill 224 254 344 224 255 344 minecraft:gray_concrete
fill 224 254 350 224 255 350 minecraft:gray_concrete
fill 225 254 345 225 255 345 minecraft:gray_concrete
fill 225 254 349 225 255 349 minecraft:gray_concrete
setblock 230 254 328 minecraft:pearlescent_froglight
setblock 230 254 329 minecraft:ochre_froglight
fill 230 254 338 230 277 338 minecraft:black_concrete
fill 230 254 358 230 308 358 minecraft:black_concrete
setblock 188 255 323 minecraft:ochre_froglight
fill 188 255 336 188 289 336 minecraft:black_concrete
setblock 197 255 364 minecraft:sea_lantern
fill 198 255 345 198 256 345 minecraft:lime_stained_glass
setblock 202 255 364 minecraft:sea_lantern
fill 204 255 358 204 258 358 minecraft:lime_concrete
fill 205 255 361 205 258 361 minecraft:lime_concrete
fill 205 255 362 210 256 362 minecraft:light_gray_concrete
fill 206 255 356 206 256 357 minecraft:gray_concrete
fill 206 255 358 206 258 358 minecraft:lime_concrete
fill 206 255 361 210 255 361 minecraft:light_gray_concrete
fill 206 255 364 206 295 364 minecraft:black_concrete
fill 207 255 360 208 255 360 minecraft:gray_concrete
fill 209 255 356 209 259 356 minecraft:gray_concrete
fill 209 255 360 210 255 360 minecraft:light_gray_concrete
fill 210 255 357 210 258 358 minecraft:gray_concrete
fill 212 255 322 212 269 322 minecraft:black_concrete
setblock 219 255 345 minecraft:gray_concrete
setblock 219 255 349 minecraft:gray_concrete
setblock 220 255 344 minecraft:gray_concrete
setblock 220 255 350 minecraft:gray_concrete
fill 222 255 343 223 255 343 minecraft:gray_concrete
fill 222 255 351 223 255 351 minecraft:gray_concrete
setblock 225 255 344 minecraft:gray_concrete
setblock 225 255 350 minecraft:gray_concrete
fill 226 255 346 226 255 348 minecraft:gray_concrete
fill 230 255 328 230 268 329 minecraft:black_concrete
setblock 230 255 342 minecraft:pearlescent_froglight
fill 188 256 323 188 263 323 minecraft:black_concrete
setblock 188 256 324 minecraft:verdant_froglight
setblock 188 256 326 minecraft:verdant_froglight
setblock 188 256 328 minecraft:verdant_froglight
setblock 188 256 330 minecraft:verdant_froglight
setblock 189 256 323 minecraft:verdant_froglight
setblock 189 256 325 minecraft:verdant_froglight
setblock 189 256 327 minecraft:verdant_froglight
setblock 189 256 329 minecraft:verdant_froglight
setblock 189 256 331 minecraft:verdant_froglight
setblock 190 256 324 minecraft:verdant_froglight
setblock 190 256 326 minecraft:verdant_froglight
setblock 190 256 328 minecraft:verdant_froglight
setblock 190 256 330 minecraft:verdant_froglight
setblock 191 256 323 minecraft:verdant_froglight
setblock 191 256 325 minecraft:verdant_froglight
setblock 191 256 327 minecraft:verdant_froglight
setblock 191 256 329 minecraft:verdant_froglight
setblock 191 256 331 minecraft:verdant_froglight
setblock 192 256 324 minecraft:verdant_froglight
setblock 192 256 326 minecraft:verdant_froglight
setblock 192 256 328 minecraft:verdant_froglight
setblock 192 256 330 minecraft:verdant_froglight
setblock 193 256 323 minecraft:verdant_froglight
setblock 193 256 325 minecraft:verdant_froglight
setblock 193 256 327 minecraft:verdant_froglight
setblock 193 256 329 minecraft:verdant_froglight
setblock 193 256 331 minecraft:verdant_froglight
setblock 194 256 324 minecraft:verdant_froglight
setblock 194 256 326 minecraft:verdant_froglight
setblock 194 256 328 minecraft:verdant_froglight
setblock 194 256 330 minecraft:verdant_froglight
setblock 195 256 323 minecraft:verdant_froglight
setblock 195 256 325 minecraft:verdant_froglight
setblock 195 256 327 minecraft:verdant_froglight
setblock 195 256 329 minecraft:verdant_froglight
setblock 195 256 331 minecraft:verdant_froglight
setblock 196 256 324 minecraft:verdant_froglight
setblock 196 256 326 minecraft:verdant_froglight
setblock 196 256 328 minecraft:verdant_froglight
setblock 196 256 330 minecraft:verdant_froglight
fill 196 256 342 196 257 342 minecraft:gray_concrete
setblock 197 256 323 minecraft:verdant_froglight
setblock 197 256 325 minecraft:verdant_froglight
setblock 197 256 327 minecraft:verdant_froglight
setblock 197 256 329 minecraft:verdant_froglight
setblock 197 256 331 minecraft:verdant_froglight
fill 197 256 364 197 276 364 minecraft:black_concrete
setblock 198 256 322 minecraft:sea_lantern
fill 200 256 359 202 257 363 minecraft:light_gray_concrete
fill 202 256 364 202 277 364 minecraft:black_concrete
fill 203 256 359 203 258 360 minecraft:lime_concrete
fill 203 256 361 203 256 363 minecraft:light_gray_concrete
fill 204 256 361 204 258 361 minecraft:lime_concrete
fill 204 256 362 204 257 362 minecraft:light_gray_concrete
fill 205 256 357 205 258 357 minecraft:lime_concrete
fill 206 256 361 206 258 361 minecraft:lime_concrete
fill 207 256 355 209 259 355 minecraft:gray_concrete
fill 207 256 359 207 258 360 minecraft:lime_concrete
fill 207 256 361 210 256 361 minecraft:light_gray_concrete
fill 208 256 360 209 257 360 minecraft:gray_concrete
fill 210 256 356 210 258 356 minecraft:gray_concrete
fill 210 256 359 210 259 359 minecraft:gray_concrete
setblock 210 256 360 minecraft:light_gray_concrete
setblock 216 256 322 minecraft:pearlescent_froglight
fill 222 256 346 223 256 348 minecraft:lime_stained_glass
fill 230 256 342 230 308 342 minecraft:black_concrete
fill 188 257 324 188 258 324 minecraft:black_concrete
fill 188 257 326 188 258 326 minecraft:black_concrete
fill 188 257 328 188 258 328 minecraft:black_concrete
fill 188 257 330 188 258 330 minecraft:black_concrete
setblock 188 257 343 minecraft:ochre_froglight
setblock 188 257 345 minecraft:ochre_froglight
fill 189 257 323 189 258 323 minecraft:light_gray_concrete
fill 189 257 325 189 258 325 minecraft:light_gray_concrete
fill 189 257 327 189 258 327 minecraft:light_gray_concrete
fill 189 257 329 189 258 329 minecraft:light_gray_concrete
fill 189 257 331 189 258 331 minecraft:light_gray_concrete
fill 190 257 324 190 258 324 minecraft:light_gray_concrete
fill 190 257 326 190 258 326 minecraft:light_gray_concrete
fill 190 257 328 190 258 328 minecraft:light_gray_concrete
fill 190 257 330 190 258 330 minecraft:light_gray_concrete
fill 191 257 323 191 258 323 minecraft:light_gray_concrete
fill 191 257 325 191 258 325 minecraft:light_gray_concrete
fill 191 257 327 191 258 327 minecraft:light_gray_concrete
fill 191 257 329 191 258 329 minecraft:light_gray_concrete
fill 191 257 331 191 258 331 minecraft:light_gray_concrete
setblock 191 257 332 minecraft:light[level=12]
setblock 191 257 339 minecraft:light[level=12]
setblock 191 257 346 minecraft:light[level=12]
setblock 191 257 353 minecraft:light[level=12]
setblock 191 257 360 minecraft:light[level=12]
fill 192 257 324 192 258 324 minecraft:light_gray_concrete
fill 192 257 326 192 258 326 minecraft:light_gray_concrete
fill 192 257 328 192 258 328 minecraft:light_gray_concrete
fill 192 257 330 192 258 330 minecraft:light_gray_concrete
fill 193 257 323 193 258 323 minecraft:light_gray_concrete
fill 193 257 325 193 258 325 minecraft:light_gray_concrete
fill 193 257 327 193 258 327 minecraft:light_gray_concrete
fill 193 257 329 193 258 329 minecraft:light_gray_concrete
fill 193 257 331 193 258 331 minecraft:light_gray_concrete
fill 194 257 324 194 258 324 minecraft:light_gray_concrete
fill 194 257 326 194 258 326 minecraft:light_gray_concrete
fill 194 257 328 194 258 328 minecraft:light_gray_concrete
fill 194 257 330 194 258 330 minecraft:light_gray_concrete
fill 195 257 323 195 258 323 minecraft:light_gray_concrete
fill 195 257 325 195 258 325 minecraft:light_gray_concrete
fill 195 257 327 195 258 327 minecraft:light_gray_concrete
fill 195 257 329 195 258 329 minecraft:light_gray_concrete
fill 195 257 331 195 258 331 minecraft:light_gray_concrete
fill 196 257 324 196 258 324 minecraft:light_gray_concrete
fill 196 257 326 196 258 326 minecraft:light_gray_concrete
fill 196 257 328 196 258 328 minecraft:light_gray_concrete
fill 196 257 330 196 258 330 minecraft:light_gray_concrete
fill 197 257 323 197 258 323 minecraft:light_gray_concrete
fill 197 257 325 197 258 325 minecraft:light_gray_concrete
fill 197 257 327 197 258 327 minecraft:light_gray_concrete
fill 197 257 329 197 258 329 minecraft:light_gray_concrete
fill 197 257 331 197 258 331 minecraft:light_gray_concrete
fill 198 257 322 198 264 322 minecraft:black_concrete
setblock 198 257 325 minecraft:light[level=12]
setblock 198 257 332 minecraft:light[level=12]
setblock 198 257 339 minecraft:light[level=12]
fill 198 257 344 198 266 345 minecraft:gray_concrete
setblock 198 257 346 minecraft:light[level=12]
setblock 198 257 353 minecraft:light[level=12]
setblock 198 257 360 minecraft:light[level=12]
fill 203 257 358 203 258 358 minecraft:lime_concrete
fill 203 257 361 203 258 361 minecraft:lime_concrete
fill 203 257 362 203 258 363 minecraft:light_gray_concrete
setblock 204 257 322 minecraft:sea_lantern
fill 204 257 357 204 258 357 minecraft:lime_concrete
setblock 205 257 325 minecraft:light[level=12]
setblock 205 257 332 minecraft:light[level=12]
setblock 205 257 339 minecraft:light[level=12]
setblock 205 257 346 minecraft:light[level=12]
setblock 205 257 353 minecraft:light[level=12]
fill 205 257 356 206 257 356 minecraft:gray_concrete
fill 205 257 362 205 258 362 minecraft:lime_concrete
fill 206 257 355 206 259 355 minecraft:gray_concrete
fill 206 257 357 206 258 357 minecraft:lime_concrete
fill 206 257 362 210 257 362 minecraft:light_gray_concrete
fill 207 257 358 207 258 358 minecraft:lime_concrete
fill 207 257 361 207 258 361 minecraft:lime_concrete
fill 208 257 361 208 259 361 minecraft:gray_concrete
fill 209 257 361 210 257 361 minecraft:light_gray_concrete
setblock 209 257 364 minecraft:white_concrete
fill 210 257 360 210 258 360 minecraft:gray_concrete
fill 211 257 357 211 259 358 minecraft:gray_concrete
setblock 212 257 325 minecraft:light[level=12]
setblock 212 257 332 minecraft:light[level=12]
setblock 212 257 339 minecraft:light[level=12]
setblock 212 257 346 minecraft:light[level=12]
setblock 212 257 353 minecraft:light[level=12]
setblock 212 257 360 minecraft:light[level=12]
fill 216 257 322 216 271 322 minecraft:black_concrete
setblock 219 257 325 minecraft:light[level=12]
setblock 219 257 332 minecraft:light[level=12]
setblock 219 257 339 minecraft:light[level=12]
setblock 219 257 346 minecraft:light[level=12]
setblock 219 257 353 minecraft:light[level=12]
setblock 219 257 360 minecraft:light[level=12]
fill 222 257 347 223 258 347 minecraft:lime_stained_glass
setblock 226 257 325 minecraft:light[level=12]
setblock 226 257 332 minecraft:light[level=12]
setblock 226 257 339 minecraft:light[level=12]
setblock 226 257 346 minecraft:light[level=12]
setblock 226 257 353 minecraft:light[level=12]
setblock 226 257 360 minecraft:light[level=12]
setblock 230 257 341 minecraft:ochre_froglight
fill 188 258 343 188 281 343 minecraft:black_concrete
fill 188 258 345 188 308 345 minecraft:black_concrete
fill 197 258 344 197 266 345 minecraft:gray_concrete
fill 200 258 356 201 258 363 minecraft:light_gray_concrete
fill 202 258 356 202 258 357 minecraft:light_gray_concrete
fill 202 258 358 202 258 360 minecraft:lime_concrete
fill 202 258 361 202 258 363 minecraft:light_gray_concrete
fill 203 258 356 204 258 356 minecraft:light_gray_concrete
setblock 203 258 357 minecraft:lime_concrete
fill 204 258 322 204 262 322 minecraft:black_concrete
setblock 204 258 362 minecraft:lime_concrete
fill 205 258 355 205 259 355 minecraft:gray_concrete
setblock 205 258 356 minecraft:lime_concrete
setblock 206 258 356 minecraft:gray_concrete
setblock 206 258 362 minecraft:lime_concrete
fill 207 258 354 209 259 354 minecraft:gray_concrete
setblock 207 258 357 minecraft:lime_concrete
fill 207 258 362 210 258 362 minecraft:light_gray_concrete
fill 208 258 358 208 258 360 minecraft:lime_concrete
fill 209 258 360 209 258 361 minecraft:gray_concrete
fill 209 258 364 209 308 364 minecraft:black_concrete
fill 210 258 355 210 259 355 minecraft:gray_concrete
setblock 210 258 361 minecraft:light_gray_concrete
fill 211 258 356 211 259 356 minecraft:gray_concrete
fill 211 258 359 211 259 359 minecraft:gray_concrete
setblock 227 258 322 minecraft:pearlescent_froglight
setblock 230 258 334 minecraft:ochre_froglight
setblock 230 258 335 minecraft:white_concrete
fill 230 258 341 230 278 341 minecraft:black_concrete
setblock 230 258 363 minecraft:white_concrete
setblock 188 259 324 minecraft:verdant_froglight
setblock 188 259 326 minecraft:verdant_froglight
setblock 188 259 328 minecraft:verdant_froglight
setblock 188 259 330 minecraft:verdant_froglight
setblock 189 259 323 minecraft:verdant_froglight
setblock 189 259 325 minecraft:verdant_froglight
setblock 189 259 327 minecraft:verdant_froglight
setblock 189 259 329 minecraft:verdant_froglight
setblock 189 259 331 minecraft:verdant_froglight
setblock 190 259 324 minecraft:verdant_froglight
setblock 190 259 326 minecraft:verdant_froglight
setblock 190 259 328 minecraft:verdant_froglight
setblock 190 259 330 minecraft:verdant_froglight
setblock 191 259 323 minecraft:verdant_froglight
setblock 191 259 325 minecraft:verdant_froglight
setblock 191 259 327 minecraft:verdant_froglight
setblock 191 259 329 minecraft:verdant_froglight
setblock 191 259 331 minecraft:verdant_froglight
setblock 192 259 324 minecraft:verdant_froglight
setblock 192 259 326 minecraft:verdant_froglight
setblock 192 259 328 minecraft:verdant_froglight
setblock 192 259 330 minecraft:verdant_froglight
setblock 193 259 323 minecraft:verdant_froglight
setblock 193 259 325 minecraft:verdant_froglight
setblock 193 259 327 minecraft:verdant_froglight
setblock 193 259 329 minecraft:verdant_froglight
setblock 193 259 331 minecraft:verdant_froglight
setblock 194 259 324 minecraft:verdant_froglight
setblock 194 259 326 minecraft:verdant_froglight
setblock 194 259 328 minecraft:verdant_froglight
setblock 194 259 330 minecraft:verdant_froglight
setblock 195 259 323 minecraft:verdant_froglight
setblock 195 259 325 minecraft:verdant_froglight
setblock 195 259 327 minecraft:verdant_froglight
setblock 195 259 329 minecraft:verdant_froglight
setblock 195 259 331 minecraft:verdant_froglight
setblock 196 259 324 minecraft:verdant_froglight
setblock 196 259 326 minecraft:verdant_froglight
setblock 196 259 328 minecraft:verdant_froglight
setblock 196 259 330 minecraft:verdant_froglight
setblock 197 259 323 minecraft:verdant_froglight
setblock 197 259 325 minecraft:verdant_froglight
setblock 197 259 327 minecraft:verdant_froglight
setblock 197 259 329 minecraft:verdant_froglight
setblock 197 259 331 minecraft:verdant_froglight
fill 198 259 343 198 266 343 minecraft:gray_concrete
fill 198 259 346 198 266 346 minecraft:gray_concrete
fill 199 259 344 199 266 345 minecraft:gray_concrete
setblock 200 259 356 minecraft:verdant_froglight
fill 200 259 357 200 271 357 minecraft:light_gray_concrete
setblock 200 259 358 minecraft:verdant_froglight
fill 200 259 359 200 270 359 minecraft:light_gray_concrete
setblock 200 259 360 minecraft:verdant_froglight
fill 200 259 361 200 271 361 minecraft:light_gray_concrete
setblock 200 259 362 minecraft:verdant_froglight
fill 200 259 363 200 271 363 minecraft:light_gray_concrete
fill 201 259 356 201 271 356 minecraft:light_gray_concrete
setblock 201 259 357 minecraft:verdant_froglight
fill 201 259 358 201 271 358 minecraft:light_gray_concrete
setblock 201 259 359 minecraft:verdant_froglight
fill 201 259 360 201 271 360 minecraft:light_gray_concrete
setblock 201 259 361 minecraft:verdant_froglight
fill 201 259 362 201 271 362 minecraft:light_gray_concrete
setblock 201 259 363 minecraft:verdant_froglight
setblock 202 259 356 minecraft:verdant_froglight
fill 202 259 357 202 271 357 minecraft:light_gray_concrete
setblock 202 259 358 minecraft:verdant_froglight
fill 202 259 359 202 271 359 minecraft:light_gray_concrete
setblock 202 259 360 minecraft:verdant_froglight
fill 202 259 361 202 271 361 minecraft:light_gray_concrete
setblock 202 259 362 minecraft:verdant_froglight
fill 202 259 363 202 271 363 minecraft:light_gray_concrete
fill 203 259 356 203 271 356 minecraft:light_gray_concrete
setblock 203 259 357 minecraft:verdant_froglight
fill 203 259 358 203 271 358 minecraft:light_gray_concrete
setblock 203 259 359 minecraft:verdant_froglight
fill 203 259 360 203 270 360 minecraft:light_gray_concrete
setblock 203 259 361 minecraft:verdant_froglight
fill 203 259 362 203 271 362 minecraft:light_gray_concrete
setblock 203 259 363 minecraft:verdant_froglight
setblock 204 259 356 minecraft:verdant_froglight
setblock 204 259 357 minecraft:gray_concrete
setblock 204 259 358 minecraft:verdant_froglight
setblock 204 259 359 minecraft:gray_concrete
setblock 204 259 360 minecraft:verdant_froglight
fill 204 259 361 204 271 361 minecraft:light_gray_concrete
setblock 204 259 362 minecraft:verdant_froglight
fill 204 259 363 204 271 363 minecraft:light_gray_concrete
setblock 205 259 356 minecraft:gray_concrete
setblock 205 259 357 minecraft:verdant_froglight
setblock 205 259 358 minecraft:gray_concrete
setblock 205 259 359 minecraft:verdant_froglight
setblock 205 259 360 minecraft:gray_concrete
setblock 205 259 361 minecraft:verdant_froglight
fill 205 259 362 205 271 362 minecraft:light_gray_concrete
setblock 205 259 363 minecraft:verdant_froglight
setblock 206 259 354 minecraft:gray_concrete
setblock 206 259 356 minecraft:verdant_froglight
setblock 206 259 357 minecraft:gray_concrete
setblock 206 259 358 minecraft:verdant_froglight
setblock 206 259 359 minecraft:gray_concrete
setblock 206 259 360 minecraft:verdant_froglight
setblock 206 259 361 minecraft:gray_concrete
setblock 206 259 362 minecraft:verdant_froglight
fill 206 259 363 206 271 363 minecraft:light_gray_concrete
setblock 207 259 356 minecraft:gray_concrete
setblock 207 259 357 minecraft:verdant_froglight
setblock 207 259 358 minecraft:gray_concrete
setblock 207 259 359 minecraft:verdant_froglight
setblock 207 259 360 minecraft:gray_concrete
setblock 207 259 361 minecraft:verdant_froglight
setblock 207 259 362 minecraft:gray_concrete
setblock 207 259 363 minecraft:verdant_froglight
setblock 208 259 356 minecraft:verdant_froglight
setblock 208 259 358 minecraft:verdant_froglight
setblock 208 259 359 minecraft:gray_concrete
setblock 208 259 360 minecraft:verdant_froglight
setblock 208 259 362 minecraft:verdant_froglight
fill 208 259 363 208 271 363 minecraft:light_gray_concrete
setblock 209 259 357 minecraft:verdant_froglight
setblock 209 259 358 minecraft:gray_concrete
setblock 209 259 359 minecraft:verdant_froglight
setblock 209 259 360 minecraft:gray_concrete
setblock 209 259 361 minecraft:verdant_froglight
fill 209 259 362 209 271 362 minecraft:light_gray_concrete
setblock 209 259 363 minecraft:verdant_froglight
setblock 210 259 354 minecraft:gray_concrete
setblock 210 259 356 minecraft:verdant_froglight
setblock 210 259 357 minecraft:gray_concrete
setblock 210 259 358 minecraft:verdant_froglight
setblock 210 259 360 minecraft:verdant_froglight
setblock 210 259 361 minecraft:gray_concrete
setblock 210 259 362 minecraft:verdant_froglight
fill 210 259 363 210 271 363 minecraft:light_gray_concrete
setblock 210 259 364 minecraft:white_concrete
setblock 211 259 355 minecraft:gray_concrete
setblock 211 259 360 minecraft:gray_concrete
fill 212 259 357 212 259 358 minecraft:gray_concrete
setblock 220 259 322 minecraft:ochre_froglight
setblock 222 259 347 minecraft:lime_stained_glass
fill 227 259 322 227 263 322 minecraft:black_concrete
setblock 228 259 322 minecraft:sea_lantern
fill 230 259 334 230 263 335 minecraft:black_concrete
fill 230 259 363 230 260 363 minecraft:black_concrete
fill 188 260 324 188 261 324 minecraft:black_concrete
fill 188 260 326 188 261 326 minecraft:black_concrete
fill 188 260 328 188 261 328 minecraft:black_concrete
setblock 188 260 329 minecraft:pearlescent_froglight
fill 188 260 330 188 261 330 minecraft:black_concrete
fill 189 260 323 189 261 323 minecraft:light_gray_concrete
fill 189 260 325 189 261 325 minecraft:light_gray_concrete
fill 189 260 327 189 261 327 minecraft:light_gray_concrete
fill 189 260 329 189 261 329 minecraft:light_gray_concrete
fill 189 260 331 189 261 331 minecraft:light_gray_concrete
fill 190 260 324 190 261 324 minecraft:light_gray_concrete
fill 190 260 326 190 261 326 minecraft:light_gray_concrete
fill 190 260 328 190 261 328 minecraft:light_gray_concrete
fill 190 260 330 190 261 330 minecraft:light_gray_concrete
fill 191 260 323 191 261 323 minecraft:light_gray_concrete
fill 191 260 325 191 261 325 minecraft:light_gray_concrete
fill 191 260 327 191 261 327 minecraft:light_gray_concrete
fill 191 260 329 191 261 329 minecraft:light_gray_concrete
fill 191 260 331 191 261 331 minecraft:light_gray_concrete
fill 192 260 324 192 261 324 minecraft:light_gray_concrete
fill 192 260 326 192 261 326 minecraft:light_gray_concrete
fill 192 260 328 192 261 328 minecraft:light_gray_concrete
fill 192 260 330 192 261 330 minecraft:light_gray_concrete
fill 193 260 323 193 261 323 minecraft:light_gray_concrete
fill 193 260 325 193 261 325 minecraft:light_gray_concrete
fill 193 260 327 193 261 327 minecraft:light_gray_concrete
fill 193 260 329 193 261 329 minecraft:light_gray_concrete
fill 193 260 331 193 261 331 minecraft:light_gray_concrete
fill 194 260 324 194 261 324 minecraft:light_gray_concrete
fill 194 260 326 194 261 326 minecraft:light_gray_concrete
fill 194 260 328 194 261 328 minecraft:light_gray_concrete
fill 194 260 330 194 261 330 minecraft:light_gray_concrete
fill 195 260 323 195 261 323 minecraft:light_gray_concrete
fill 195 260 325 195 261 325 minecraft:light_gray_concrete
fill 195 260 327 195 261 327 minecraft:light_gray_concrete
fill 195 260 329 195 261 329 minecraft:light_gray_concrete
fill 195 260 331 195 261 331 minecraft:light_gray_concrete
fill 196 260 324 196 261 324 minecraft:light_gray_concrete
fill 196 260 326 196 261 326 minecraft:light_gray_concrete
fill 196 260 328 196 261 328 minecraft:light_gray_concrete
fill 196 260 330 196 261 330 minecraft:light_gray_concrete
fill 196 260 344 196 266 345 minecraft:gray_concrete
fill 197 260 323 197 261 323 minecraft:light_gray_concrete
fill 197 260 325 197 261 325 minecraft:light_gray_concrete
fill 197 260 327 197 261 327 minecraft:light_gray_concrete
fill 197 260 329 197 261 329 minecraft:light_gray_concrete
fill 197 260 331 197 261 331 minecraft:light_gray_concrete
fill 197 260 343 197 266 343 minecraft:gray_concrete
fill 197 260 346 197 266 346 minecraft:gray_concrete
fill 199 260 343 199 266 343 minecraft:gray_concrete
fill 199 260 346 199 266 346 minecraft:gray_concrete
fill 200 260 356 200 261 356 minecraft:light_gray_concrete
fill 200 260 358 200 261 358 minecraft:light_gray_concrete
fill 200 260 360 200 261 360 minecraft:light_gray_concrete
fill 200 260 362 200 261 362 minecraft:light_gray_concrete
fill 201 260 357 201 261 357 minecraft:light_gray_concrete
fill 201 260 359 201 261 359 minecraft:light_gray_concrete
fill 201 260 361 201 261 361 minecraft:light_gray_concrete
fill 201 260 363 201 261 363 minecraft:light_gray_concrete
fill 202 260 356 202 261 356 minecraft:light_gray_concrete
fill 202 260 358 202 261 358 minecraft:light_gray_concrete
fill 202 260 360 202 261 360 minecraft:light_gray_concrete
fill 202 260 362 202 261 362 minecraft:light_gray_concrete
fill 203 260 357 206 261 357 minecraft:light_gray_concrete
fill 203 260 359 210 261 359 minecraft:light_gray_concrete
fill 203 260 361 203 261 361 minecraft:light_gray_concrete
fill 203 260 363 203 261 363 minecraft:light_gray_concrete
fill 204 260 356 210 261 356 minecraft:light_gray_concrete
fill 204 260 358 206 261 358 minecraft:light_gray_concrete
fill 204 260 360 210 261 360 minecraft:light_gray_concrete
fill 204 260 362 204 261 362 minecraft:light_gray_concrete
fill 205 260 361 210 261 361 minecraft:light_gray_concrete
fill 205 260 363 205 261 363 minecraft:light_gray_concrete
fill 206 260 362 208 261 362 minecraft:light_gray_concrete
fill 207 260 357 208 260 358 minecraft:lime_stained_glass
fill 207 260 363 207 261 363 minecraft:light_gray_concrete
setblock 208 260 364 minecraft:ochre_froglight
setblock 209 260 322 minecraft:white_concrete
fill 209 260 357 210 261 357 minecraft:light_gray_concrete
setblock 209 260 358 minecraft:lime_stained_glass
fill 209 260 363 209 261 363 minecraft:light_gray_concrete
fill 210 260 358 210 261 358 minecraft:light_gray_concrete
fill 210 260 362 210 261 362 minecraft:light_gray_concrete
fill 210 260 364 210 274 364 minecraft:black_concrete
setblock 213 260 322 minecraft:sea_lantern
fill 220 260 322 220 299 322 minecraft:black_concrete
fill 228 260 322 228 275 322 minecraft:black_concrete
setblock 230 260 339 minecraft:ochre_froglight
fill 230 260 340 230 270 340 minecraft:black_concrete
setblock 230 260 357 minecraft:sea_lantern
fill 188 261 329 188 308 329 minecraft:black_concrete
setblock 191 261 333 minecraft:light[level=15]
setblock 191 261 341 minecraft:light[level=15]
setblock 191 261 349 minecraft:light[level=15]
setblock 191 261 357 minecraft:light[level=15]
fill 196 261 343 196 266 343 minecraft:gray_concrete
fill 196 261 346 196 266 346 minecraft:gray_concrete
fill 198 261 347 198 266 347 minecraft:gray_concrete
setblock 199 261 325 minecraft:light[level=15]
setblock 199 261 333 minecraft:light[level=15]
setblock 199 261 341 minecraft:light[level=15]
setblock 199 261 349 minecraft:light[level=15]
setblock 199 261 357 minecraft:light[level=15]
fill 200 261 344 200 266 345 minecraft:gray_concrete
setblock 207 261 325 minecraft:light[level=15]
setblock 207 261 333 minecraft:light[level=15]
setblock 207 261 341 minecraft:light[level=15]
setblock 207 261 349 minecraft:light[level=15]
setblock 207 261 357 minecraft:light_gray_concrete
fill 207 261 358 208 261 358 minecraft:lime_stained_glass
fill 208 261 357 208 262 357 minecraft:lime_stained_glass
fill 208 261 364 208 308 364 minecraft:black_concrete
fill 209 261 322 209 276 322 minecraft:black_concrete
fill 209 261 358 209 271 358 minecraft:light_gray_concrete
fill 213 261 322 213 264 322 minecraft:black_concrete
setblock 215 261 325 minecraft:light[level=15]
setblock 215 261 333 minecraft:light[level=15]
setblock 215 261 341 minecraft:light[level=15]
setblock 215 261 349 minecraft:light[level=15]
setblock 215 261 357 minecraft:light[level=15]
setblock 223 261 325 minecraft:light[level=15]
setblock 223 261 333 minecraft:light[level=15]
setblock 223 261 341 minecraft:light[level=15]
setblock 223 261 349 minecraft:light[level=15]
setblock 223 261 357 minecraft:light[level=15]
setblock 230 261 339 minecraft:sea_lantern
setblock 230 261 346 minecraft:sea_lantern
fill 230 261 357 230 270 357 minecraft:black_concrete
setblock 230 261 363 minecraft:ochre_froglight
setblock 188 262 324 minecraft:verdant_froglight
setblock 188 262 326 minecraft:verdant_froglight
setblock 188 262 328 minecraft:verdant_froglight
setblock 188 262 330 minecraft:verdant_froglight
setblock 189 262 323 minecraft:verdant_froglight
setblock 189 262 325 minecraft:verdant_froglight
setblock 189 262 327 minecraft:verdant_froglight
setblock 189 262 329 minecraft:verdant_froglight
setblock 189 262 331 minecraft:verdant_froglight
setblock 190 262 324 minecraft:verdant_froglight
setblock 190 262 326 minecraft:verdant_froglight
setblock 190 262 328 minecraft:verdant_froglight
setblock 190 262 330 minecraft:verdant_froglight
setblock 191 262 323 minecraft:verdant_froglight
setblock 191 262 325 minecraft:verdant_froglight
setblock 191 262 327 minecraft:verdant_froglight
setblock 191 262 329 minecraft:verdant_froglight
setblock 191 262 331 minecraft:verdant_froglight
setblock 192 262 324 minecraft:verdant_froglight
setblock 192 262 326 minecraft:verdant_froglight
setblock 192 262 328 minecraft:verdant_froglight
setblock 192 262 330 minecraft:verdant_froglight
setblock 193 262 323 minecraft:verdant_froglight
setblock 193 262 325 minecraft:verdant_froglight
setblock 193 262 327 minecraft:verdant_froglight
setblock 193 262 329 minecraft:verdant_froglight
setblock 193 262 331 minecraft:verdant_froglight
setblock 194 262 324 minecraft:verdant_froglight
setblock 194 262 326 minecraft:verdant_froglight
setblock 194 262 328 minecraft:verdant_froglight
setblock 194 262 330 minecraft:verdant_froglight
setblock 195 262 323 minecraft:verdant_froglight
setblock 195 262 325 minecraft:verdant_froglight
setblock 195 262 327 minecraft:verdant_froglight
setblock 195 262 329 minecraft:verdant_froglight
setblock 195 262 331 minecraft:verdant_froglight
fill 195 262 344 195 266 345 minecraft:gray_concrete
setblock 196 262 324 minecraft:verdant_froglight
setblock 196 262 326 minecraft:verdant_froglight
setblock 196 262 328 minecraft:verdant_froglight
setblock 196 262 330 minecraft:verdant_froglight
setblock 197 262 323 minecraft:verdant_froglight
setblock 197 262 325 minecraft:verdant_froglight
setblock 197 262 327 minecraft:verdant_froglight
setblock 197 262 329 minecraft:verdant_froglight
setblock 197 262 331 minecraft:verdant_froglight
fill 197 262 342 199 266 342 minecraft:gray_concrete
fill 197 262 347 197 266 347 minecraft:gray_concrete
fill 199 262 347 199 266 347 minecraft:gray_concrete
fill 200 262 343 200 266 343 minecraft:gray_concrete
fill 200 262 346 200 266 346 minecraft:gray_concrete
setblock 200 262 356 minecraft:verdant_froglight
setblock 200 262 358 minecraft:verdant_froglight
setblock 200 262 360 minecraft:verdant_froglight
setblock 200 262 362 minecraft:verdant_froglight
setblock 201 262 357 minecraft:verdant_froglight
setblock 201 262 359 minecraft:verdant_froglight
setblock 201 262 361 minecraft:verdant_froglight
setblock 201 262 363 minecraft:verdant_froglight
setblock 202 262 356 minecraft:verdant_froglight
setblock 202 262 358 minecraft:verdant_froglight
setblock 202 262 360 minecraft:verdant_froglight
setblock 202 262 362 minecraft:verdant_froglight
setblock 203 262 357 minecraft:verdant_froglight
setblock 203 262 359 minecraft:verdant_froglight
setblock 203 262 361 minecraft:verdant_froglight
setblock 203 262 363 minecraft:verdant_froglight
setblock 204 262 356 minecraft:verdant_froglight
fill 204 262 357 204 271 357 minecraft:light_gray_concrete
setblock 204 262 358 minecraft:verdant_froglight
fill 204 262 359 204 271 359 minecraft:light_gray_concrete
setblock 204 262 360 minecraft:verdant_froglight
setblock 204 262 362 minecraft:verdant_froglight
fill 205 262 356 205 271 356 minecraft:light_gray_concrete
setblock 205 262 357 minecraft:verdant_froglight
fill 205 262 358 205 271 358 minecraft:light_gray_concrete
setblock 205 262 359 minecraft:verdant_froglight
fill 205 262 360 205 271 360 minecraft:light_gray_concrete
setblock 205 262 361 minecraft:verdant_froglight
setblock 205 262 363 minecraft:verdant_froglight
setblock 206 262 356 minecraft:verdant_froglight
fill 206 262 357 206 271 357 minecraft:light_gray_concrete
setblock 206 262 358 minecraft:verdant_froglight
fill 206 262 359 206 271 359 minecraft:light_gray_concrete
setblock 206 262 360 minecraft:verdant_froglight
fill 206 262 361 206 270 361 minecraft:light_gray_concrete
setblock 206 262 362 minecraft:verdant_froglight
fill 207 262 356 207 271 356 minecraft:light_gray_concrete
setblock 207 262 357 minecraft:verdant_froglight
fill 207 262 358 207 271 358 minecraft:light_gray_concrete
setblock 207 262 359 minecraft:verdant_froglight
fill 207 262 360 207 271 360 minecraft:light_gray_concrete
setblock 207 262 361 minecraft:verdant_froglight
fill 207 262 362 207 271 362 minecraft:light_gray_concrete
setblock 207 262 363 minecraft:verdant_froglight
setblock 208 262 356 minecraft:verdant_froglight
setblock 208 262 358 minecraft:verdant_froglight
fill 208 262 359 208 271 359 minecraft:light_gray_concrete
setblock 208 262 360 minecraft:verdant_froglight
fill 208 262 361 208 269 361 minecraft:light_gray_concrete
setblock 208 262 362 minecraft:verdant_froglight
fill 209 262 356 209 271 356 minecraft:light_gray_concrete
setblock 209 262 357 minecraft:verdant_froglight
setblock 209 262 359 minecraft:verdant_froglight
fill 209 262 360 209 271 360 minecraft:light_gray_concrete
setblock 209 262 361 minecraft:verdant_froglight
setblock 209 262 363 minecraft:verdant_froglight
setblock 210 262 356 minecraft:verdant_froglight
fill 210 262 357 210 271 357 minecraft:light_gray_concrete
setblock 210 262 358 minecraft:verdant_froglight
fill 210 262 359 210 271 359 minecraft:light_gray_concrete
setblock 210 262 360 minecraft:verdant_froglight
fill 210 262 361 210 269 361 minecraft:light_gray_concrete
setblock 210 262 362 minecraft:verdant_froglight
setblock 224 262 322 minecraft:sea_lantern
setblock 225 262 364 minecraft:sea_lantern
setblock 230 262 324 minecraft:pearlescent_froglight
fill 230 262 339 230 289 339 minecraft:black_concrete
fill 230 262 346 230 266 346 minecraft:black_concrete
fill 230 262 363 230 275 363 minecraft:black_concrete
fill 188 263 324 188 264 324 minecraft:black_concrete
fill 188 263 326 188 264 326 minecraft:black_concrete
fill 188 263 328 188 264 328 minecraft:black_concrete
fill 188 263 330 188 264 330 minecraft:black_concrete
fill 189 263 323 189 264 323 minecraft:light_gray_concrete
fill 189 263 325 189 264 325 minecraft:light_gray_concrete
fill 189 263 327 189 264 327 minecraft:light_gray_concrete
fill 189 263 329 189 264 329 minecraft:light_gray_concrete
fill 189 263 331 189 264 331 minecraft:light_gray_concrete
fill 190 263 324 190 264 324 minecraft:light_gray_concrete
fill 190 263 326 190 264 326 minecraft:light_gray_concrete
fill 190 263 328 190 264 328 minecraft:light_gray_concrete
fill 190 263 330 190 264 330 minecraft:light_gray_concrete
fill 191 263 323 191 264 323 minecraft:light_gray_concrete
fill 191 263 325 191 264 325 minecraft:light_gray_concrete
fill 191 263 327 191 264 327 minecraft:light_gray_concrete
fill 191 263 329 191 264 329 minecraft:light_gray_concrete
fill 191 263 331 191 264 331 minecraft:light_gray_concrete
setblock 191 263 332 minecraft:light[level=12]
setblock 191 263 339 minecraft:light[level=12]
setblock 191 263 346 minecraft:light[level=12]
setblock 191 263 353 minecraft:light[level=12]
setblock 191 263 360 minecraft:light[level=12]
fill 192 263 324 192 264 324 minecraft:light_gray_concrete
fill 192 263 326 192 264 326 minecraft:light_gray_concrete
fill 192 263 328 192 264 328 minecraft:light_gray_concrete
fill 192 263 330 192 264 330 minecraft:light_gray_concrete
fill 193 263 323 193 264 323 minecraft:light_gray_concrete
fill 193 263 325 193 264 325 minecraft:light_gray_concrete
fill 193 263 327 193 264 327 minecraft:light_gray_concrete
fill 193 263 329 193 264 329 minecraft:light_gray_concrete
fill 193 263 331 193 264 331 minecraft:light_gray_concrete
fill 194 263 324 194 264 324 minecraft:light_gray_concrete
fill 194 263 326 194 264 326 minecraft:light_gray_concrete
fill 194 263 328 194 264 328 minecraft:light_gray_concrete
fill 194 263 330 194 264 330 minecraft:light_gray_concrete
fill 195 263 323 195 264 323 minecraft:light_gray_concrete
fill 195 263 325 195 264 325 minecraft:light_gray_concrete
fill 195 263 327 195 264 327 minecraft:light_gray_concrete
fill 195 263 329 195 264 329 minecraft:light_gray_concrete
fill 195 263 331 195 264 331 minecraft:light_gray_concrete
fill 195 263 343 195 266 343 minecraft:gray_concrete
fill 195 263 346 195 266 346 minecraft:gray_concrete
fill 196 263 324 196 264 324 minecraft:light_gray_concrete
fill 196 263 326 196 264 326 minecraft:light_gray_concrete
fill 196 263 328 196 264 328 minecraft:light_gray_concrete
fill 196 263 330 196 264 330 minecraft:light_gray_concrete
fill 196 263 342 196 266 342 minecraft:gray_concrete
fill 196 263 347 196 266 347 minecraft:gray_concrete
fill 197 263 323 197 264 323 minecraft:light_gray_concrete
fill 197 263 325 197 264 325 minecraft:light_gray_concrete
fill 197 263 327 197 264 327 minecraft:light_gray_concrete
fill 197 263 329 197 264 329 minecraft:light_gray_concrete
fill 197 263 331 197 264 331 minecraft:light_gray_concrete
setblock 198 263 325 minecraft:light[level=12]
setblock 198 263 332 minecraft:light[level=12]
setblock 198 263 339 minecraft:light[level=12]
setblock 198 263 353 minecraft:light[level=12]
setblock 198 263 360 minecraft:light[level=12]
fill 200 263 342 200 266 342 minecraft:gray_concrete
fill 200 263 347 200 266 347 minecraft:gray_concrete
fill 200 263 356 200 264 356 minecraft:light_gray_concrete
fill 200 263 358 200 264 358 minecraft:light_gray_concrete
fill 200 263 360 200 264 360 minecraft:light_gray_concrete
fill 200 263 362 200 264 362 minecraft:light_gray_concrete
fill 201 263 343 201 266 346 minecraft:gray_concrete
fill 201 263 357 201 264 357 minecraft:light_gray_concrete
fill 201 263 359 201 264 359 minecraft:light_gray_concrete
fill 201 263 361 201 264 361 minecraft:light_gray_concrete
fill 201 263 363 201 264 363 minecraft:light_gray_concrete
fill 202 263 356 202 264 356 minecraft:light_gray_concrete
fill 202 263 358 202 264 358 minecraft:light_gray_concrete
fill 202 263 360 202 264 360 minecraft:light_gray_concrete
fill 202 263 362 202 264 362 minecraft:light_gray_concrete
fill 203 263 357 203 264 357 minecraft:light_gray_concrete
fill 203 263 359 203 264 359 minecraft:light_gray_concrete
fill 203 263 361 203 264 361 minecraft:light_gray_concrete
fill 203 263 363 203 264 363 minecraft:light_gray_concrete
setblock 204 263 322 minecraft:pearlescent_froglight
fill 204 263 356 204 264 356 minecraft:light_gray_concrete
fill 204 263 358 204 264 358 minecraft:light_gray_concrete
fill 204 263 360 204 264 360 minecraft:light_gray_concrete
fill 204 263 362 204 264 362 minecraft:light_gray_concrete
setblock 205 263 325 minecraft:light[level=12]
setblock 205 263 332 minecraft:light[level=12]
setblock 205 263 339 minecraft:light[level=12]
setblock 205 263 346 minecraft:light[level=12]
setblock 205 263 353 minecraft:light[level=12]
fill 205 263 357 205 264 357 minecraft:light_gray_concrete
fill 205 263 359 205 264 359 minecraft:light_gray_concrete
fill 205 263 361 205 264 361 minecraft:light_gray_concrete
fill 205 263 363 205 264 363 minecraft:light_gray_concrete
fill 206 263 356 206 264 356 minecraft:light_gray_concrete
fill 206 263 358 206 264 358 minecraft:light_gray_concrete
fill 206 263 360 206 264 360 minecraft:light_gray_concrete
fill 206 263 362 206 264 362 minecraft:light_gray_concrete
fill 207 263 357 209 264 357 minecraft:light_gray_concrete
fill 207 263 359 207 264 359 minecraft:light_gray_concrete
fill 207 263 361 207 264 361 minecraft:light_gray_concrete
fill 207 263 363 207 264 363 minecraft:light_gray_concrete
fill 208 263 356 208 264 356 minecraft:light_gray_concrete
setblock 208 263 358 minecraft:lime_stained_glass
fill 208 263 360 208 264 360 minecraft:light_gray_concrete
fill 208 263 362 208 264 362 minecraft:light_gray_concrete
fill 209 263 359 209 264 359 minecraft:light_gray_concrete
fill 209 263 361 209 264 361 minecraft:light_gray_concrete
fill 209 263 363 209 264 363 minecraft:light_gray_concrete
fill 210 263 356 210 264 356 minecraft:light_gray_concrete
fill 210 263 358 210 264 358 minecraft:light_gray_concrete
fill 210 263 360 210 264 360 minecraft:light_gray_concrete
fill 210 263 362 210 264 362 minecraft:light_gray_concrete
setblock 212 263 325 minecraft:light[level=12]
setblock 212 263 332 minecraft:light[level=12]
setblock 212 263 339 minecraft:light[level=12]
setblock 212 263 353 minecraft:light[level=12]
setblock 212 263 360 minecraft:light[level=12]
setblock 219 263 325 minecraft:light[level=12]
setblock 219 263 332 minecraft:light[level=12]
setblock 219 263 339 minecraft:light[level=12]
setblock 219 263 346 minecraft:light[level=12]
setblock 219 263 353 minecraft:light[level=12]
setblock 219 263 360 minecraft:light[level=12]
setblock 223 263 364 minecraft:ochre_froglight
fill 224 263 322 224 282 322 minecraft:black_concrete
setblock 225 263 322 minecraft:pearlescent_froglight
setblock 225 263 364 minecraft:black_concrete
setblock 226 263 325 minecraft:light[level=12]
setblock 226 263 332 minecraft:light[level=12]
setblock 226 263 339 minecraft:light[level=12]
setblock 226 263 346 minecraft:light[level=12]
setblock 226 263 353 minecraft:light[level=12]
setblock 226 263 360 minecraft:light[level=12]
fill 230 263 324 230 268 324 minecraft:black_concrete
setblock 230 263 355 minecraft:white_concrete
setblock 188 264 323 minecraft:white_concrete
setblock 188 264 342 minecraft:white_concrete
setblock 188 264 350 minecraft:ochre_froglight
setblock 188 264 359 minecraft:white_concrete
setblock 192 264 322 minecraft:sea_lantern
fill 193 264 341 194 265 341 minecraft:gray_concrete
fill 194 264 344 194 266 345 minecraft:gray_concrete
fill 195 264 342 195 266 342 minecraft:gray_concrete
fill 195 264 347 195 266 347 minecraft:gray_concrete
fill 196 264 348 199 266 348 minecraft:gray_concrete
fill 197 264 341 199 266 341 minecraft:gray_concrete
setblock 203 264 364 minecraft:sea_lantern
fill 204 264 322 204 287 322 minecraft:black_concrete
setblock 208 264 358 minecraft:light_gray_concrete
setblock 223 264 364 minecraft:sea_lantern
setblock 225 264 322 minecraft:sea_lantern
setblock 225 264 364 minecraft:ochre_froglight
fill 226 264 364 226 265 364 minecraft:pearlescent_froglight
setblock 227 264 322 minecraft:ochre_froglight
setblock 230 264 327 minecraft:ochre_froglight
fill 230 264 334 230 267 334 minecraft:black_concrete
setblock 230 264 335 minecraft:white_concrete
fill 230 264 355 230 308 355 minecraft:black_concrete
setblock 230 264 360 minecraft:sea_lantern
fill 188 265 323 188 282 323 minecraft:black_concrete
setblock 188 265 324 minecraft:verdant_froglight
setblock 188 265 326 minecraft:verdant_froglight
setblock 188 265 328 minecraft:verdant_froglight
setblock 188 265 330 minecraft:verdant_froglight
fill 188 265 342 188 308 342 minecraft:black_concrete
fill 188 265 350 188 293 350 minecraft:black_concrete
fill 188 265 359 188 308 359 minecraft:black_concrete
setblock 189 265 323 minecraft:verdant_froglight
setblock 189 265 325 minecraft:verdant_froglight
setblock 189 265 327 minecraft:verdant_froglight
setblock 189 265 329 minecraft:verdant_froglight
setblock 189 265 331 minecraft:verdant_froglight
setblock 190 265 324 minecraft:verdant_froglight
setblock 190 265 326 minecraft:verdant_froglight
setblock 190 265 328 minecraft:verdant_froglight
setblock 190 265 330 minecraft:verdant_froglight
setblock 191 265 322 minecraft:pearlescent_froglight
setblock 191 265 323 minecraft:verdant_froglight
setblock 191 265 325 minecraft:verdant_froglight
setblock 191 265 327 minecraft:verdant_froglight
setblock 191 265 329 minecraft:verdant_froglight
setblock 191 265 331 minecraft:verdant_froglight
fill 192 265 322 192 283 322 minecraft:black_concrete
setblock 192 265 324 minecraft:verdant_froglight
setblock 192 265 326 minecraft:verdant_froglight
setblock 192 265 328 minecraft:verdant_froglight
setblock 192 265 330 minecraft:verdant_froglight
setblock 193 265 323 minecraft:verdant_froglight
setblock 193 265 325 minecraft:verdant_froglight
setblock 193 265 327 minecraft:verdant_froglight
setblock 193 265 329 minecraft:verdant_froglight
setblock 193 265 331 minecraft:verdant_froglight
setblock 194 265 324 minecraft:verdant_froglight
setblock 194 265 326 minecraft:verdant_froglight
setblock 194 265 328 minecraft:verdant_froglight
setblock 194 265 330 minecraft:verdant_froglight
fill 194 265 343 194 266 343 minecraft:gray_concrete
fill 194 265 346 194 266 346 minecraft:gray_concrete
setblock 195 265 323 minecraft:verdant_froglight
setblock 195 265 325 minecraft:verdant_froglight
setblock 195 265 327 minecraft:verdant_froglight
setblock 195 265 329 minecraft:verdant_froglight
setblock 195 265 331 minecraft:verdant_froglight
setblock 196 265 324 minecraft:verdant_froglight
setblock 196 265 326 minecraft:verdant_froglight
setblock 196 265 328 minecraft:verdant_froglight
setblock 196 265 330 minecraft:verdant_froglight
fill 196 265 341 196 266 341 minecraft:gray_concrete
setblock 197 265 323 minecraft:verdant_froglight
setblock 197 265 325 minecraft:verdant_froglight
setblock 197 265 327 minecraft:verdant_froglight
setblock 197 265 329 minecraft:verdant_froglight
setblock 197 265 331 minecraft:verdant_froglight
setblock 198 265 322 minecraft:ochre_froglight
fill 200 265 341 200 266 341 minecraft:gray_concrete
fill 200 265 348 200 266 348 minecraft:gray_concrete
setblock 200 265 356 minecraft:verdant_froglight
setblock 200 265 358 minecraft:verdant_froglight
setblock 200 265 360 minecraft:verdant_froglight
setblock 200 265 362 minecraft:verdant_froglight
fill 201 265 342 201 266 342 minecraft:gray_concrete
fill 201 265 347 201 266 347 minecraft:gray_concrete
setblock 201 265 357 minecraft:verdant_froglight
setblock 201 265 359 minecraft:verdant_froglight
setblock 201 265 361 minecraft:verdant_froglight
setblock 201 265 363 minecraft:verdant_froglight
fill 202 265 343 202 266 346 minecraft:gray_concrete
setblock 202 265 356 minecraft:verdant_froglight
setblock 202 265 358 minecraft:verdant_froglight
setblock 202 265 360 minecraft:verdant_froglight
setblock 202 265 362 minecraft:verdant_froglight
setblock 203 265 357 minecraft:verdant_froglight
setblock 203 265 359 minecraft:verdant_froglight
setblock 203 265 361 minecraft:verdant_froglight
setblock 203 265 363 minecraft:verdant_froglight
fill 203 265 364 203 294 364 minecraft:black_concrete
setblock 204 265 356 minecraft:verdant_froglight
setblock 204 265 358 minecraft:verdant_froglight
setblock 204 265 360 minecraft:verdant_froglight
setblock 204 265 362 minecraft:verdant_froglight
setblock 205 265 357 minecraft:verdant_froglight
setblock 205 265 359 minecraft:verdant_froglight
setblock 205 265 361 minecraft:verdant_froglight
setblock 205 265 363 minecraft:verdant_froglight
setblock 206 265 356 minecraft:verdant_froglight
setblock 206 265 358 minecraft:verdant_froglight
setblock 206 265 360 minecraft:verdant_froglight
setblock 206 265 362 minecraft:verdant_froglight
setblock 207 265 357 minecraft:verdant_froglight
setblock 207 265 359 minecraft:verdant_froglight
setblock 207 265 361 minecraft:verdant_froglight
setblock 207 265 363 minecraft:verdant_froglight
setblock 208 265 322 minecraft:ochre_froglight
setblock 208 265 356 minecraft:verdant_froglight
fill 208 265 357 208 271 357 minecraft:light_gray_concrete
setblock 208 265 358 minecraft:verdant_froglight
setblock 208 265 360 minecraft:verdant_froglight
setblock 208 265 362 minecraft:verdant_froglight
setblock 209 265 357 minecraft:verdant_froglight
setblock 209 265 359 minecraft:verdant_froglight
setblock 209 265 361 minecraft:verdant_froglight
setblock 209 265 363 minecraft:verdant_froglight
setblock 210 265 356 minecraft:verdant_froglight
setblock 210 265 358 minecraft:verdant_froglight
setblock 210 265 360 minecraft:verdant_froglight
setblock 210 265 362 minecraft:verdant_froglight
setblock 213 265 322 minecraft:sea_lantern
fill 223 265 364 223 272 364 minecraft:black_concrete
fill 225 265 322 225 269 322 minecraft:black_concrete
fill 225 265 364 225 269 364 minecraft:black_concrete
fill 227 265 322 227 281 322 minecraft:black_concrete
setblock 229 265 364 minecraft:sea_lantern
fill 230 265 327 230 304 327 minecraft:black_concrete
fill 230 265 335 230 308 335 minecraft:black_concrete
setblock 230 265 360 minecraft:white_concrete
fill 188 266 324 188 267 324 minecraft:black_concrete
setblock 188 266 326 minecraft:black_concrete
fill 188 266 328 188 267 328 minecraft:black_concrete
fill 188 266 330 188 267 330 minecraft:black_concrete
fill 189 266 323 189 267 323 minecraft:light_gray_concrete
fill 189 266 325 189 267 325 minecraft:light_gray_concrete
fill 189 266 327 189 267 327 minecraft:light_gray_concrete
fill 189 266 329 189 267 329 minecraft:light_gray_concrete
fill 189 266 331 189 267 331 minecraft:light_gray_concrete
fill 190 266 324 190 267 324 minecraft:light_gray_concrete
fill 190 266 326 190 267 326 minecraft:light_gray_concrete
fill 190 266 328 190 267 328 minecraft:light_gray_concrete
fill 190 266 330 190 267 330 minecraft:light_gray_concrete
fill 191 266 322 191 305 322 minecraft:black_concrete
fill 191 266 323 191 267 323 minecraft:light_gray_concrete
fill 191 266 325 191 267 325 minecraft:light_gray_concrete
fill 191 266 327 191 267 327 minecraft:light_gray_concrete
fill 191 266 329 191 267 329 minecraft:light_gray_concrete
fill 191 266 331 191 267 331 minecraft:light_gray_concrete
fill 192 266 324 192 267 324 minecraft:light_gray_concrete
fill 192 266 326 192 267 326 minecraft:light_gray_concrete
fill 192 266 328 192 267 328 minecraft:light_gray_concrete
fill 192 266 330 192 267 330 minecraft:light_gray_concrete
fill 193 266 323 193 267 323 minecraft:light_gray_concrete
fill 193 266 325 193 267 325 minecraft:light_gray_concrete
fill 193 266 327 193 267 327 minecraft:light_gray_concrete
fill 193 266 329 193 267 329 minecraft:light_gray_concrete
fill 193 266 331 193 267 331 minecraft:light_gray_concrete
fill 193 266 344 193 266 345 minecraft:gray_concrete
fill 194 266 324 194 267 324 minecraft:light_gray_concrete
fill 194 266 326 194 267 326 minecraft:light_gray_concrete
fill 194 266 328 194 267 328 minecraft:light_gray_concrete
fill 194 266 330 194 267 330 minecraft:light_gray_concrete
setblock 194 266 342 minecraft:gray_concrete
setblock 194 266 347 minecraft:gray_concrete
fill 195 266 323 195 267 323 minecraft:light_gray_concrete
fill 195 266 325 195 267 325 minecraft:light_gray_concrete
fill 195 266 327 195 267 327 minecraft:light_gray_concrete
fill 195 266 329 195 267 329 minecraft:light_gray_concrete
fill 195 266 331 195 267 331 minecraft:light_gray_concrete
setblock 195 266 341 minecraft:gray_concrete
setblock 195 266 348 minecraft:gray_concrete
fill 196 266 324 196 267 324 minecraft:light_gray_concrete
fill 196 266 326 196 267 326 minecraft:light_gray_concrete
fill 196 266 328 196 267 328 minecraft:light_gray_concrete
fill 196 266 330 196 267 330 minecraft:light_gray_concrete
fill 196 266 340 199 266 340 minecraft:gray_concrete
fill 196 266 349 199 266 349 minecraft:gray_concrete
fill 197 266 323 197 267 323 minecraft:light_gray_concrete
fill 197 266 325 197 267 325 minecraft:light_gray_concrete
fill 197 266 327 197 267 327 minecraft:light_gray_concrete
fill 197 266 329 197 267 329 minecraft:light_gray_concrete
fill 197 266 331 197 267 331 minecraft:light_gray_concrete
fill 198 266 322 198 272 322 minecraft:black_concrete
fill 199 266 358 200 267 358 minecraft:end_stone
fill 200 266 356 200 267 356 minecraft:light_gray_concrete
fill 200 266 360 200 267 360 minecraft:light_gray_concrete
fill 200 266 362 200 267 362 minecraft:light_gray_concrete
setblock 201 266 341 minecraft:gray_concrete
setblock 201 266 348 minecraft:gray_concrete
fill 201 266 350 201 267 350 minecraft:end_stone
fill 201 266 357 201 267 357 minecraft:light_gray_concrete
fill 201 266 359 201 267 359 minecraft:light_gray_concrete
fill 201 266 361 201 267 361 minecraft:light_gray_concrete
fill 201 266 363 201 267 363 minecraft:light_gray_concrete
setblock 202 266 342 minecraft:gray_concrete
setblock 202 266 347 minecraft:gray_concrete
fill 202 266 356 202 267 356 minecraft:light_gray_concrete
fill 202 266 358 202 267 358 minecraft:light_gray_concrete
fill 202 266 360 202 267 360 minecraft:light_gray_concrete
fill 202 266 362 202 267 362 minecraft:light_gray_concrete
fill 203 266 357 203 267 357 minecraft:light_gray_concrete
fill 203 266 359 203 267 359 minecraft:light_gray_concrete
fill 203 266 361 203 267 361 minecraft:light_gray_concrete
fill 203 266 363 203 267 363 minecraft:light_gray_concrete
fill 204 266 356 204 267 356 minecraft:light_gray_concrete
fill 204 266 358 204 267 358 minecraft:light_gray_concrete
fill 204 266 360 204 267 360 minecraft:light_gray_concrete
fill 204 266 362 204 267 362 minecraft:light_gray_concrete
fill 205 266 357 205 267 357 minecraft:light_gray_concrete
fill 205 266 359 205 267 359 minecraft:light_gray_concrete
fill 205 266 361 205 267 361 minecraft:light_gray_concrete
fill 205 266 363 205 267 363 minecraft:light_gray_concrete
fill 206 266 356 206 267 356 minecraft:light_gray_concrete
fill 206 266 358 206 267 358 minecraft:light_gray_concrete
fill 206 266 360 206 267 360 minecraft:light_gray_concrete
fill 206 266 362 206 267 362 minecraft:light_gray_concrete
fill 207 266 357 207 267 357 minecraft:light_gray_concrete
fill 207 266 359 207 267 359 minecraft:light_gray_concrete
fill 207 266 361 207 267 361 minecraft:light_gray_concrete
fill 207 266 363 207 267 363 minecraft:light_gray_concrete
fill 208 266 322 208 285 322 minecraft:black_concrete
fill 208 266 356 208 267 356 minecraft:light_gray_concrete
fill 208 266 358 208 267 358 minecraft:light_gray_concrete
fill 208 266 360 208 267 360 minecraft:light_gray_concrete
fill 208 266 362 208 267 362 minecraft:light_gray_concrete
fill 209 266 357 209 267 357 minecraft:light_gray_concrete
fill 209 266 359 209 267 359 minecraft:light_gray_concrete
fill 209 266 361 209 267 361 minecraft:light_gray_concrete
fill 209 266 363 209 267 363 minecraft:light_gray_concrete
fill 210 266 356 210 267 356 minecraft:light_gray_concrete
fill 210 266 358 210 267 358 minecraft:light_gray_concrete
fill 210 266 360 210 267 360 minecraft:light_gray_concrete
fill 210 266 362 210 267 362 minecraft:light_gray_concrete
setblock 212 266 364 minecraft:white_concrete
fill 213 266 322 213 268 322 minecraft:black_concrete
fill 226 266 364 226 267 364 minecraft:black_concrete
setblock 229 266 364 minecraft:black_concrete
fill 230 266 360 230 269 360 minecraft:black_concrete
setblock 188 267 326 minecraft:ochre_froglight
setblock 188 267 355 minecraft:white_concrete
fill 198 267 344 198 269 345 minecraft:iron_block
fill 212 267 364 212 282 364 minecraft:black_concrete
setblock 229 267 364 minecraft:ochre_froglight
setblock 230 267 346 minecraft:pearlescent_froglight
setblock 188 268 324 minecraft:verdant_froglight
setblock 188 268 326 minecraft:verdant_froglight
setblock 188 268 328 minecraft:verdant_froglight
setblock 188 268 330 minecraft:verdant_froglight
fill 188 268 355 188 270 355 minecraft:black_concrete
setblock 189 268 323 minecraft:verdant_froglight
setblock 189 268 325 minecraft:verdant_froglight
setblock 189 268 327 minecraft:verdant_froglight
setblock 189 268 329 minecraft:verdant_froglight
setblock 189 268 331 minecraft:verdant_froglight
setblock 190 268 324 minecraft:verdant_froglight
setblock 190 268 326 minecraft:verdant_froglight
setblock 190 268 328 minecraft:verdant_froglight
setblock 190 268 330 minecraft:verdant_froglight
setblock 191 268 323 minecraft:verdant_froglight
setblock 191 268 325 minecraft:verdant_froglight
setblock 191 268 327 minecraft:verdant_froglight
setblock 191 268 329 minecraft:verdant_froglight
setblock 191 268 331 minecraft:verdant_froglight
fill 191 268 341 192 270 345 minecraft:light_gray_concrete
setblock 192 268 324 minecraft:verdant_froglight
setblock 192 268 326 minecraft:verdant_froglight
setblock 192 268 328 minecraft:verdant_froglight
setblock 192 268 330 minecraft:verdant_froglight
fill 192 268 337 192 270 340 minecraft:light_gray_concrete
fill 192 268 346 192 270 349 minecraft:light_gray_concrete
setblock 193 268 323 minecraft:verdant_froglight
setblock 193 268 325 minecraft:verdant_froglight
setblock 193 268 327 minecraft:verdant_froglight
setblock 193 268 329 minecraft:verdant_froglight
setblock 193 268 331 minecraft:verdant_froglight
fill 193 268 335 193 270 337 minecraft:light_gray_concrete
fill 193 268 349 193 270 351 minecraft:light_gray_concrete
setblock 194 268 324 minecraft:verdant_froglight
setblock 194 268 326 minecraft:verdant_froglight
setblock 194 268 328 minecraft:verdant_froglight
setblock 194 268 330 minecraft:verdant_froglight
fill 194 268 333 194 270 335 minecraft:light_gray_concrete
fill 194 268 351 194 270 353 minecraft:light_gray_concrete
setblock 195 268 323 minecraft:verdant_froglight
setblock 195 268 325 minecraft:verdant_froglight
setblock 195 268 327 minecraft:verdant_froglight
setblock 195 268 329 minecraft:verdant_froglight
setblock 195 268 331 minecraft:verdant_froglight
fill 195 268 332 195 270 333 minecraft:light_gray_concrete
fill 195 268 353 195 270 354 minecraft:light_gray_concrete
setblock 196 268 324 minecraft:verdant_froglight
setblock 196 268 326 minecraft:verdant_froglight
setblock 196 268 328 minecraft:verdant_froglight
setblock 196 268 330 minecraft:verdant_froglight
fill 196 268 332 196 270 332 minecraft:light_gray_concrete
fill 196 268 354 196 270 355 minecraft:light_gray_concrete
setblock 197 268 323 minecraft:verdant_froglight
setblock 197 268 325 minecraft:verdant_froglight
setblock 197 268 327 minecraft:verdant_froglight
setblock 197 268 329 minecraft:verdant_froglight
setblock 197 268 331 minecraft:verdant_froglight
fill 197 268 355 197 270 356 minecraft:light_gray_concrete
fill 198 268 329 198 270 330 minecraft:light_gray_concrete
fill 198 268 356 198 270 357 minecraft:light_gray_concrete
fill 199 268 328 199 270 329 minecraft:light_gray_concrete
fill 199 268 357 199 270 358 minecraft:light_gray_concrete
fill 200 268 328 201 270 328 minecraft:light_gray_concrete
setblock 200 268 356 minecraft:verdant_froglight
setblock 200 268 358 minecraft:verdant_froglight
setblock 200 268 360 minecraft:verdant_froglight
setblock 200 268 362 minecraft:verdant_froglight
fill 201 268 327 203 270 327 minecraft:light_gray_concrete
setblock 201 268 357 minecraft:verdant_froglight
setblock 201 268 359 minecraft:verdant_froglight
setblock 201 268 361 minecraft:verdant_froglight
setblock 201 268 363 minecraft:verdant_froglight
setblock 201 268 364 minecraft:ochre_froglight
setblock 202 268 356 minecraft:verdant_froglight
setblock 202 268 358 minecraft:verdant_froglight
setblock 202 268 360 minecraft:verdant_froglight
setblock 202 268 362 minecraft:verdant_froglight
fill 203 268 326 215 270 326 minecraft:light_gray_concrete
setblock 203 268 357 minecraft:verdant_froglight
setblock 203 268 359 minecraft:verdant_froglight
setblock 203 268 361 minecraft:verdant_froglight
setblock 203 268 363 minecraft:verdant_froglight
setblock 204 268 356 minecraft:verdant_froglight
setblock 204 268 358 minecraft:verdant_froglight
setblock 204 268 360 minecraft:verdant_froglight
setblock 204 268 362 minecraft:verdant_froglight
setblock 205 268 357 minecraft:verdant_froglight
setblock 205 268 359 minecraft:verdant_froglight
setblock 205 268 361 minecraft:verdant_froglight
setblock 205 268 363 minecraft:verdant_froglight
fill 206 268 344 206 268 346 minecraft:lime_stained_glass
setblock 206 268 356 minecraft:verdant_froglight
setblock 206 268 358 minecraft:verdant_froglight
setblock 206 268 360 minecraft:verdant_froglight
setblock 206 268 362 minecraft:verdant_froglight
fill 207 268 325 211 270 325 minecraft:light_gray_concrete
fill 207 268 342 207 269 342 minecraft:lime_stained_glass
fill 207 268 348 207 269 348 minecraft:lime_stained_glass
setblock 207 268 357 minecraft:verdant_froglight
setblock 207 268 359 minecraft:verdant_froglight
setblock 207 268 361 minecraft:verdant_froglight
setblock 207 268 363 minecraft:verdant_froglight
fill 208 268 341 208 269 341 minecraft:lime_stained_glass
fill 208 268 349 208 269 349 minecraft:lime_stained_glass
setblock 208 268 356 minecraft:verdant_froglight
setblock 208 268 358 minecraft:verdant_froglight
setblock 208 268 360 minecraft:verdant_froglight
setblock 208 268 362 minecraft:verdant_froglight
setblock 209 268 357 minecraft:verdant_froglight
setblock 209 268 359 minecraft:verdant_froglight
setblock 209 268 361 minecraft:verdant_froglight
setblock 209 268 363 minecraft:verdant_froglight
fill 210 268 340 212 268 340 minecraft:lime_stained_glass
fill 210 268 350 212 268 350 minecraft:lime_stained_glass
setblock 210 268 356 minecraft:verdant_froglight
setblock 210 268 358 minecraft:verdant_froglight
setblock 210 268 360 minecraft:verdant_froglight
setblock 210 268 362 minecraft:verdant_froglight
fill 211 268 360 211 269 361 minecraft:light_gray_concrete
fill 212 268 360 215 269 360 minecraft:light_gray_concrete
fill 214 268 341 214 269 341 minecraft:lime_stained_glass
fill 214 268 349 214 269 349 minecraft:lime_stained_glass
fill 215 268 327 217 270 327 minecraft:light_gray_concrete
fill 215 268 342 215 269 342 minecraft:lime_stained_glass
fill 215 268 348 215 269 348 minecraft:lime_stained_glass
fill 215 268 359 217 269 359 minecraft:light_gray_concrete
fill 216 268 344 216 268 346 minecraft:lime_stained_glass
fill 217 268 328 219 270 328 minecraft:light_gray_concrete
fill 217 268 358 219 269 358 minecraft:light_gray_concrete
fill 219 268 329 220 270 329 minecraft:light_gray_concrete
fill 219 268 357 220 269 357 minecraft:light_gray_concrete
fill 220 268 330 221 270 330 minecraft:light_gray_concrete
fill 220 268 356 221 269 356 minecraft:light_gray_concrete
fill 221 268 331 222 270 331 minecraft:light_gray_concrete
fill 221 268 355 222 269 355 minecraft:light_gray_concrete
fill 222 268 332 223 269 332 minecraft:light_gray_concrete
fill 222 268 354 223 269 354 minecraft:light_gray_concrete
fill 223 268 333 224 269 333 minecraft:light_gray_concrete
fill 223 268 353 224 269 353 minecraft:light_gray_concrete
fill 224 268 334 224 270 335 minecraft:light_gray_concrete
fill 224 268 351 224 270 352 minecraft:light_gray_concrete
fill 225 268 335 225 269 337 minecraft:light_gray_concrete
fill 225 268 349 225 269 351 minecraft:light_gray_concrete
fill 226 268 337 226 269 349 minecraft:light_gray_concrete
setblock 226 268 364 minecraft:pearlescent_froglight
fill 227 268 341 227 269 345 minecraft:light_gray_concrete
fill 229 268 364 229 289 364 minecraft:black_concrete
setblock 230 268 334 minecraft:pearlescent_froglight
fill 230 268 346 230 308 346 minecraft:black_concrete
setblock 230 268 356 minecraft:ochre_froglight
setblock 188 269 324 minecraft:sea_lantern
fill 188 269 326 188 308 326 minecraft:black_concrete
fill 188 269 328 188 308 328 minecraft:black_concrete
fill 188 269 330 188 291 330 minecraft:black_concrete
fill 189 269 323 189 271 323 minecraft:light_gray_concrete
fill 189 269 325 189 271 325 minecraft:light_gray_concrete
fill 189 269 327 189 271 327 minecraft:light_gray_concrete
fill 189 269 329 189 271 329 minecraft:light_gray_concrete
fill 189 269 331 189 271 331 minecraft:light_gray_concrete
fill 190 269 324 190 271 324 minecraft:light_gray_concrete
fill 190 269 326 190 271 326 minecraft:light_gray_concrete
fill 190 269 328 190 271 328 minecraft:light_gray_concrete
fill 190 269 330 190 271 330 minecraft:light_gray_concrete
fill 191 269 323 191 271 323 minecraft:light_gray_concrete
fill 191 269 325 191 271 325 minecraft:light_gray_concrete
fill 191 269 327 191 271 327 minecraft:light_gray_concrete
fill 191 269 329 191 271 329 minecraft:light_gray_concrete
fill 191 269 331 191 271 331 minecraft:light_gray_concrete
setblock 191 269 332 minecraft:light[level=12]
setblock 191 269 333 minecraft:light[level=15]
fill 191 269 339 191 270 340 minecraft:light_gray_concrete
fill 191 269 346 191 270 347 minecraft:light_gray_concrete
setblock 191 269 349 minecraft:light[level=15]
setblock 191 269 353 minecraft:light[level=12]
setblock 191 269 357 minecraft:light[level=15]
setblock 191 269 360 minecraft:light[level=12]
fill 192 269 324 192 271 324 minecraft:light_gray_concrete
fill 192 269 326 192 271 326 minecraft:light_gray_concrete
fill 192 269 328 192 271 328 minecraft:light_gray_concrete
fill 192 269 330 192 271 330 minecraft:light_gray_concrete
fill 192 269 336 192 270 336 minecraft:light_gray_concrete
fill 192 269 350 192 270 350 minecraft:light_gray_concrete
fill 193 269 323 193 271 323 minecraft:light_gray_concrete
fill 193 269 325 193 271 325 minecraft:light_gray_concrete
fill 193 269 327 193 271 327 minecraft:light_gray_concrete
fill 193 269 329 193 271 329 minecraft:light_gray_concrete
fill 193 269 331 193 271 331 minecraft:light_gray_concrete
fill 193 269 334 193 270 334 minecraft:light_gray_concrete
fill 193 269 338 193 270 338 minecraft:light_gray_concrete
fill 193 269 348 193 270 348 minecraft:light_gray_concrete
fill 193 269 352 193 270 352 minecraft:light_gray_concrete
fill 194 269 324 194 271 324 minecraft:light_gray_concrete
fill 194 269 326 194 271 326 minecraft:light_gray_concrete
fill 194 269 328 194 271 328 minecraft:light_gray_concrete
fill 194 269 330 194 271 330 minecraft:light_gray_concrete
fill 194 269 336 194 270 336 minecraft:light_gray_concrete
fill 194 269 350 194 270 350 minecraft:light_gray_concrete
fill 195 269 323 195 271 323 minecraft:light_gray_concrete
fill 195 269 325 195 271 325 minecraft:light_gray_concrete
fill 195 269 327 195 271 327 minecraft:light_gray_concrete
fill 195 269 329 195 271 329 minecraft:light_gray_concrete
fill 195 269 331 195 270 331 minecraft:light_gray_concrete
fill 195 269 334 195 270 334 minecraft:light_gray_concrete
fill 195 269 352 195 270 352 minecraft:light_gray_concrete
fill 195 269 355 195 270 355 minecraft:light_gray_concrete
fill 196 269 324 196 271 324 minecraft:light_gray_concrete
fill 196 269 326 196 271 326 minecraft:light_gray_concrete
fill 196 269 328 196 271 328 minecraft:light_gray_concrete
fill 196 269 330 196 270 330 minecraft:light_gray_concrete
fill 196 269 356 196 270 356 minecraft:light_gray_concrete
fill 197 269 323 197 271 323 minecraft:light_gray_concrete
fill 197 269 325 197 271 325 minecraft:light_gray_concrete
fill 197 269 327 197 271 327 minecraft:light_gray_concrete
fill 197 269 329 197 270 329 minecraft:light_gray_concrete
fill 197 269 331 197 271 331 minecraft:light_gray_concrete
fill 197 269 357 197 270 357 minecraft:light_gray_concrete
setblock 198 269 325 minecraft:light[level=12]
setblock 198 269 332 minecraft:light[level=12]
setblock 198 269 339 minecraft:light[level=12]
setblock 198 269 346 minecraft:light[level=12]
setblock 198 269 353 minecraft:light[level=12]
setblock 198 269 360 minecraft:light[level=12]
setblock 199 269 325 minecraft:light[level=15]
setblock 199 269 333 minecraft:light[level=15]
setblock 199 269 341 minecraft:light[level=15]
setblock 199 269 349 minecraft:light[level=15]
fill 200 269 327 200 270 327 minecraft:light_gray_concrete
fill 200 269 329 200 270 329 minecraft:light_gray_concrete
fill 200 269 356 200 271 356 minecraft:light_gray_concrete
fill 200 269 358 200 271 358 minecraft:light_gray_concrete
fill 200 269 360 200 271 360 minecraft:light_gray_concrete
fill 200 269 362 200 271 362 minecraft:light_gray_concrete
fill 201 269 357 201 271 357 minecraft:light_gray_concrete
fill 201 269 359 201 270 359 minecraft:light_gray_concrete
fill 201 269 361 201 271 361 minecraft:light_gray_concrete
fill 201 269 363 201 271 363 minecraft:light_gray_concrete
setblock 201 269 364 minecraft:black_concrete
fill 202 269 326 202 270 326 minecraft:light_gray_concrete
fill 202 269 328 202 270 328 minecraft:light_gray_concrete
fill 202 269 356 202 271 356 minecraft:light_gray_concrete
fill 202 269 358 202 271 358 minecraft:light_gray_concrete
fill 202 269 360 202 270 360 minecraft:light_gray_concrete
fill 202 269 362 202 271 362 minecraft:light_gray_concrete
fill 203 269 357 203 271 357 minecraft:light_gray_concrete
fill 203 269 359 203 271 359 minecraft:light_gray_concrete
fill 203 269 361 203 271 361 minecraft:light_gray_concrete
fill 203 269 363 203 271 363 minecraft:light_gray_concrete
fill 204 269 327 204 270 327 minecraft:light_gray_concrete
fill 204 269 356 204 271 356 minecraft:light_gray_concrete
fill 204 269 358 204 271 358 minecraft:light_gray_concrete
fill 204 269 360 204 270 360 minecraft:light_gray_concrete
fill 204 269 362 204 271 362 minecraft:light_gray_concrete
fill 205 269 325 206 270 325 minecraft:light_gray_concrete
setblock 205 269 332 minecraft:light[level=12]
setblock 205 269 339 minecraft:light[level=12]
setblock 205 269 346 minecraft:light[level=12]
setblock 205 269 353 minecraft:light[level=12]
fill 205 269 357 205 271 357 minecraft:light_gray_concrete
fill 205 269 359 205 271 359 minecraft:light_gray_concrete
fill 205 269 361 205 270 361 minecraft:light_gray_concrete
fill 205 269 363 205 271 363 minecraft:light_gray_concrete
setblock 206 269 345 minecraft:lime_stained_glass
fill 206 269 356 206 271 356 minecraft:light_gray_concrete
fill 206 269 358 206 271 358 minecraft:light_gray_concrete
fill 206 269 360 206 271 360 minecraft:light_gray_concrete
fill 206 269 362 206 271 362 minecraft:light_gray_concrete
setblock 207 269 322 minecraft:ochre_froglight
setblock 207 269 333 minecraft:light[level=15]
setblock 207 269 341 minecraft:light[level=15]
fill 207 269 343 207 271 343 minecraft:lime_stained_glass
fill 207 269 347 207 271 347 minecraft:lime_stained_glass
setblock 207 269 349 minecraft:light[level=15]
fill 207 269 357 207 271 357 minecraft:light_gray_concrete
fill 207 269 359 207 271 359 minecraft:light_gray_concrete
setblock 207 269 361 minecraft:light_gray_concrete
fill 207 269 363 207 271 363 minecraft:light_gray_concrete
fill 208 269 356 208 271 356 minecraft:light_gray_concrete
fill 208 269 358 208 271 358 minecraft:light_gray_concrete
fill 208 269 360 208 271 360 minecraft:light_gray_concrete
fill 208 269 362 208 271 362 minecraft:light_gray_concrete
fill 209 269 341 209 271 341 minecraft:lime_stained_glass
fill 209 269 349 209 271 349 minecraft:lime_stained_glass
fill 209 269 357 209 271 357 minecraft:light_gray_concrete
fill 209 269 359 209 271 359 minecraft:light_gray_concrete
setblock 209 269 361 minecraft:light_gray_concrete
fill 209 269 363 209 271 363 minecraft:light_gray_concrete
fill 210 269 356 210 271 356 minecraft:light_gray_concrete
fill 210 269 358 210 271 358 minecraft:light_gray_concrete
fill 210 269 360 210 271 360 minecraft:light_gray_concrete
fill 210 269 362 210 271 362 minecraft:light_gray_concrete
setblock 211 269 340 minecraft:lime_stained_glass
setblock 211 269 350 minecraft:lime_stained_glass
fill 212 269 325 213 270 325 minecraft:light_gray_concrete
setblock 212 269 332 minecraft:light[level=12]
setblock 212 269 339 minecraft:light[level=12]
setblock 212 269 353 minecraft:light[level=12]
fill 212 269 361 213 269 361 minecraft:light_gray_concrete
setblock 213 269 322 minecraft:sea_lantern
fill 213 269 341 213 271 341 minecraft:lime_stained_glass
fill 213 269 349 213 271 349 minecraft:lime_stained_glass
fill 214 269 327 214 270 327 minecraft:light_gray_concrete
fill 214 269 359 214 270 359 minecraft:light_gray_concrete
setblock 215 269 325 minecraft:light[level=15]
setblock 215 269 333 minecraft:light[level=15]
setblock 215 269 341 minecraft:light[level=15]
fill 215 269 343 215 271 343 minecraft:lime_stained_glass
fill 215 269 347 215 271 347 minecraft:lime_stained_glass
setblock 215 269 349 minecraft:light[level=15]
setblock 215 269 357 minecraft:light[level=15]
fill 216 269 326 216 270 326 minecraft:light_gray_concrete
fill 216 269 328 216 270 328 minecraft:light_gray_concrete
setblock 216 269 345 minecraft:lime_stained_glass
fill 216 269 358 216 270 358 minecraft:light_gray_concrete
setblock 216 269 360 minecraft:light_gray_concrete
fill 218 269 327 218 270 327 minecraft:light_gray_concrete
fill 218 269 329 218 270 329 minecraft:light_gray_concrete
fill 218 269 357 218 270 357 minecraft:light_gray_concrete
setblock 218 269 359 minecraft:light_gray_concrete
setblock 219 269 325 minecraft:light[level=12]
setblock 219 269 332 minecraft:light[level=12]
setblock 219 269 339 minecraft:light[level=12]
setblock 219 269 346 minecraft:light[level=12]
setblock 219 269 353 minecraft:light[level=12]
setblock 219 269 360 minecraft:light[level=12]
setblock 220 269 364 minecraft:sea_lantern
fill 221 269 329 221 270 329 minecraft:light_gray_concrete
setblock 221 269 357 minecraft:light_gray_concrete
fill 222 269 330 222 270 330 minecraft:light_gray_concrete
setblock 222 269 356 minecraft:light_gray_concrete
setblock 222 269 364 minecraft:pearlescent_froglight
setblock 223 269 325 minecraft:light[level=15]
setblock 223 269 331 minecraft:light_gray_concrete
fill 223 269 334 223 270 334 minecraft:light_gray_concrete
setblock 223 269 341 minecraft:light[level=15]
setblock 223 269 349 minecraft:light[level=15]
fill 223 269 352 223 270 352 minecraft:light_gray_concrete
setblock 223 269 355 minecraft:light_gray_concrete
setblock 223 269 357 minecraft:light[level=15]
fill 224 269 336 224 270 336 minecraft:light_gray_concrete
fill 224 269 350 224 270 350 minecraft:light_gray_concrete
setblock 225 269 334 minecraft:light_gray_concrete
fill 225 269 338 225 270 338 minecraft:light_gray_concrete
fill 225 269 348 225 270 348 minecraft:light_gray_concrete
setblock 225 269 352 minecraft:light_gray_concrete
setblock 226 269 325 minecraft:light[level=12]
setblock 226 269 332 minecraft:light[level=12]
setblock 226 269 336 minecraft:light_gray_concrete
setblock 226 269 350 minecraft:light_gray_concrete
setblock 226 269 353 minecraft:light[level=12]
setblock 226 269 360 minecraft:light[level=12]
fill 226 269 364 226 281 364 minecraft:black_concrete
fill 227 269 339 227 269 340 minecraft:light_gray_concrete
fill 227 269 346 227 269 347 minecraft:light_gray_concrete
setblock 230 269 324 minecraft:sea_lantern
setblock 230 269 328 minecraft:ochre_froglight
fill 230 269 329 230 308 329 minecraft:black_concrete
fill 230 269 334 230 300 334 minecraft:black_concrete
setblock 230 269 349 minecraft:sea_lantern
fill 230 269 356 230 285 356 minecraft:black_concrete
fill 188 270 324 188 305 324 minecraft:black_concrete
setblock 188 270 325 minecraft:sea_lantern
setblock 188 270 353 minecraft:ochre_froglight
setblock 193 270 322 minecraft:pearlescent_froglight
setblock 201 270 364 minecraft:sea_lantern
fill 202 270 350 203 271 350 minecraft:end_stone
fill 207 270 322 207 308 322 minecraft:black_concrete
fill 207 270 344 207 272 344 minecraft:lime_stained_glass
fill 207 270 346 207 272 346 minecraft:lime_stained_glass
fill 207 270 361 213 271 361 minecraft:verdant_froglight
fill 208 270 342 208 272 342 minecraft:lime_stained_glass
fill 208 270 348 208 272 348 minecraft:lime_stained_glass
fill 210 270 341 210 272 341 minecraft:lime_stained_glass
fill 210 270 349 210 272 349 minecraft:lime_stained_glass
fill 211 270 360 213 270 360 minecraft:light_gray_concrete
setblock 212 270 322 minecraft:ochre_froglight
fill 212 270 341 212 272 341 minecraft:lime_stained_glass
fill 212 270 349 212 272 349 minecraft:lime_stained_glass
fill 213 270 322 213 290 322 minecraft:black_concrete
fill 214 270 342 214 272 342 minecraft:lime_stained_glass
fill 214 270 348 214 272 348 minecraft:lime_stained_glass
fill 214 270 360 216 271 360 minecraft:verdant_froglight
fill 215 270 344 215 272 344 minecraft:lime_stained_glass
fill 215 270 346 215 272 346 minecraft:lime_stained_glass
fill 215 270 359 216 270 359 minecraft:light_gray_concrete
fill 217 270 358 218 270 358 minecraft:light_gray_concrete
fill 217 270 359 218 271 359 minecraft:verdant_froglight
setblock 218 270 364 minecraft:ochre_froglight
setblock 219 270 357 minecraft:light_gray_concrete
fill 219 270 358 219 271 358 minecraft:verdant_froglight
setblock 220 270 356 minecraft:light_gray_concrete
fill 220 270 357 221 271 357 minecraft:verdant_froglight
fill 220 270 364 220 291 364 minecraft:black_concrete
setblock 221 270 355 minecraft:light_gray_concrete
fill 221 270 356 222 271 356 minecraft:verdant_froglight
setblock 222 270 332 minecraft:light_gray_concrete
setblock 222 270 354 minecraft:light_gray_concrete
fill 222 270 355 223 271 355 minecraft:verdant_froglight
fill 222 270 364 222 277 364 minecraft:black_concrete
fill 223 270 331 223 270 332 minecraft:verdant_froglight
setblock 223 270 333 minecraft:light_gray_concrete
setblock 223 270 353 minecraft:light_gray_concrete
fill 223 270 354 223 271 354 minecraft:verdant_froglight
setblock 224 270 333 minecraft:verdant_froglight
fill 224 270 353 224 271 353 minecraft:verdant_froglight
setblock 225 270 322 minecraft:pearlescent_froglight
fill 225 270 334 225 270 335 minecraft:verdant_froglight
fill 225 270 336 225 270 337 minecraft:light_gray_concrete
fill 225 270 349 225 270 350 minecraft:light_gray_concrete
fill 225 270 351 225 270 352 minecraft:verdant_froglight
setblock 225 270 364 minecraft:ochre_froglight
fill 226 270 336 226 270 338 minecraft:verdant_froglight
fill 226 270 339 226 270 347 minecraft:light_gray_concrete
fill 226 270 348 226 270 350 minecraft:verdant_froglight
fill 227 270 339 227 270 347 minecraft:verdant_froglight
fill 230 270 324 230 287 324 minecraft:black_concrete
fill 230 270 328 230 280 328 minecraft:black_concrete
fill 230 270 349 230 279 349 minecraft:black_concrete
setblock 230 270 360 minecraft:white_concrete
fill 188 271 325 188 308 325 minecraft:black_concrete
setblock 188 271 327 minecraft:white_concrete
fill 188 271 353 188 279 353 minecraft:black_concrete
setblock 188 271 355 minecraft:ochre_froglight
fill 191 271 339 191 271 347 minecraft:verdant_froglight
fill 192 271 336 192 271 338 minecraft:verdant_froglight
fill 192 271 348 192 271 350 minecraft:verdant_froglight
fill 193 271 322 193 308 322 minecraft:black_concrete
fill 193 271 334 193 271 335 minecraft:verdant_froglight
fill 193 271 351 193 271 352 minecraft:verdant_froglight
setblock 194 271 333 minecraft:verdant_froglight
setblock 194 271 353 minecraft:verdant_froglight
fill 195 271 331 195 271 332 minecraft:verdant_froglight
fill 195 271 354 195 271 355 minecraft:verdant_froglight
fill 196 271 330 196 271 331 minecraft:verdant_froglight
fill 196 271 355 196 271 356 minecraft:verdant_froglight
fill 197 271 329 197 271 330 minecraft:verdant_froglight
fill 197 271 356 197 271 357 minecraft:verdant_froglight
setblock 198 271 329 minecraft:verdant_froglight
setblock 198 271 345 minecraft:verdant_froglight
setblock 198 271 357 minecraft:verdant_froglight
setblock 199 271 328 minecraft:verdant_froglight
setblock 199 271 358 minecraft:verdant_froglight
fill 200 271 327 201 271 327 minecraft:verdant_froglight
fill 200 271 359 201 271 359 minecraft:verdant_froglight
fill 201 271 364 201 308 364 minecraft:black_concrete
fill 202 271 326 204 271 326 minecraft:verdant_froglight
fill 202 271 360 204 271 360 minecraft:verdant_froglight
setblock 205 271 325 minecraft:verdant_froglight
fill 205 271 361 206 271 361 minecraft:verdant_froglight
fill 207 271 345 207 272 345 minecraft:lime_stained_glass
fill 211 271 341 211 272 341 minecraft:lime_stained_glass
fill 211 271 349 211 272 349 minecraft:lime_stained_glass
fill 212 271 322 212 308 322 minecraft:black_concrete
setblock 215 271 322 minecraft:ochre_froglight
fill 215 271 345 215 272 345 minecraft:lime_stained_glass
fill 218 271 364 218 275 364 minecraft:black_concrete
setblock 222 271 322 minecraft:ochre_froglight
fill 225 271 322 225 281 322 minecraft:black_concrete
fill 225 271 364 225 308 364 minecraft:black_concrete
setblock 230 271 340 minecraft:ochre_froglight
setblock 230 271 357 minecraft:sea_lantern
fill 230 271 360 230 308 360 minecraft:black_concrete
fill 188 272 327 188 308 327 minecraft:black_concrete
setblock 188 272 341 minecraft:pearlescent_froglight
fill 188 272 355 188 293 355 minecraft:black_concrete
setblock 206 272 322 minecraft:sea_lantern
fill 208 272 343 208 274 343 minecraft:lime_stained_glass
fill 208 272 347 208 274 347 minecraft:lime_stained_glass
fill 209 272 342 209 274 342 minecraft:lime_stained_glass
fill 209 272 348 209 274 348 minecraft:lime_stained_glass
fill 213 272 342 213 274 342 minecraft:lime_stained_glass
fill 213 272 348 213 274 348 minecraft:lime_stained_glass
fill 214 272 343 214 274 343 minecraft:lime_stained_glass
fill 214 272 347 214 274 347 minecraft:lime_stained_glass
fill 215 272 322 215 278 322 minecraft:black_concrete
setblock 216 272 322 minecraft:pearlescent_froglight
fill 222 272 322 222 308 322 minecraft:black_concrete
setblock 230 272 325 minecraft:white_concrete
fill 230 272 340 230 289 340 minecraft:black_concrete
fill 230 272 357 230 308 357 minecraft:black_concrete
fill 188 273 341 188 303 341 minecraft:black_concrete
setblock 196 273 364 minecraft:pearlescent_froglight
setblock 198 273 322 minecraft:sea_lantern
fill 206 273 322 206 295 322 minecraft:black_concrete
fill 216 273 322 216 277 322 minecraft:black_concrete
setblock 223 273 364 minecraft:white_concrete
fill 230 273 325 230 280 325 minecraft:black_concrete
fill 196 274 364 196 276 364 minecraft:black_concrete
fill 198 274 322 198 308 322 minecraft:black_concrete
setblock 202 274 322 minecraft:sea_lantern
fill 208 274 344 208 275 346 minecraft:lime_stained_glass
fill 210 274 342 212 275 342 minecraft:lime_stained_glass
fill 210 274 348 212 275 348 minecraft:lime_stained_glass
fill 214 274 344 214 275 346 minecraft:lime_stained_glass
fill 223 274 364 223 308 364 minecraft:black_concrete
setblock 230 274 323 minecraft:pearlescent_froglight
setblock 230 274 354 minecraft:ochre_froglight
setblock 191 275 325 minecraft:light[level=12]
setblock 191 275 332 minecraft:light[level=12]
setblock 191 275 339 minecraft:light[level=12]
setblock 191 275 346 minecraft:light[level=12]
setblock 191 275 353 minecraft:light[level=12]
setblock 191 275 360 minecraft:light[level=12]
setblock 194 275 322 minecraft:sea_lantern
setblock 195 275 364 minecraft:sea_lantern
setblock 198 275 325 minecraft:light[level=12]
setblock 198 275 332 minecraft:light[level=12]
setblock 198 275 339 minecraft:light[level=12]
setblock 198 275 346 minecraft:light[level=12]
setblock 198 275 353 minecraft:light[level=12]
setblock 198 275 360 minecraft:light[level=12]
fill 202 275 322 202 295 322 minecraft:black_concrete
setblock 205 275 325 minecraft:light[level=12]
setblock 205 275 332 minecraft:light[level=12]
setblock 205 275 339 minecraft:light[level=12]
setblock 205 275 346 minecraft:light[level=12]
setblock 205 275 353 minecraft:light[level=12]
setblock 205 275 360 minecraft:light[level=12]
fill 209 275 343 209 276 343 minecraft:lime_stained_glass
fill 209 275 347 209 276 347 minecraft:lime_stained_glass
setblock 210 275 364 minecraft:white_concrete
setblock 212 275 325 minecraft:light[level=12]
setblock 212 275 332 minecraft:light[level=12]
setblock 212 275 339 minecraft:light[level=12]
setblock 212 275 346 minecraft:light[level=12]
setblock 212 275 353 minecraft:light[level=12]
setblock 212 275 360 minecraft:light[level=12]
fill 213 275 343 213 276 343 minecraft:lime_stained_glass
fill 213 275 347 213 276 347 minecraft:lime_stained_glass
setblock 219 275 325 minecraft:light[level=12]
setblock 219 275 332 minecraft:light[level=12]
setblock 219 275 339 minecraft:light[level=12]
setblock 219 275 346 minecraft:light[level=12]
setblock 219 275 353 minecraft:light[level=12]
setblock 219 275 360 minecraft:light[level=12]
setblock 226 275 325 minecraft:light[level=12]
setblock 226 275 332 minecraft:light[level=12]
setblock 226 275 339 minecraft:light[level=12]
setblock 226 275 346 minecraft:light[level=12]
setblock 226 275 353 minecraft:light[level=12]
setblock 226 275 360 minecraft:light[level=12]
fill 230 275 323 230 303 323 minecraft:black_concrete
fill 230 275 354 230 284 354 minecraft:black_concrete
setblock 188 276 349 minecraft:white_concrete
fill 194 276 322 194 308 322 minecraft:black_concrete
fill 195 276 364 195 281 364 minecraft:black_concrete
setblock 208 276 345 minecraft:lime_stained_glass
fill 210 276 364 210 304 364 minecraft:black_concrete
setblock 211 276 342 minecraft:lime_stained_glass
setblock 211 276 348 minecraft:lime_stained_glass
setblock 214 276 345 minecraft:lime_stained_glass
setblock 218 276 364 minecraft:sea_lantern
setblock 221 276 322 minecraft:sea_lantern
setblock 228 276 322 minecraft:white_concrete
setblock 230 276 363 minecraft:ochre_froglight
setblock 188 277 333 minecraft:pearlescent_froglight
fill 188 277 334 188 286 334 minecraft:black_concrete
fill 188 277 349 188 308 349 minecraft:black_concrete
setblock 190 277 322 minecraft:sea_lantern
setblock 191 277 325 minecraft:light[level=15]
setblock 191 277 333 minecraft:light[level=15]
setblock 191 277 341 minecraft:light[level=15]
setblock 191 277 349 minecraft:light[level=15]
setblock 191 277 357 minecraft:light[level=15]
setblock 193 277 364 minecraft:ochre_froglight
setblock 195 277 322 minecraft:pearlescent_froglight
setblock 196 277 364 minecraft:white_concrete
setblock 197 277 364 minecraft:sea_lantern
setblock 199 277 325 minecraft:light[level=15]
setblock 199 277 333 minecraft:light[level=15]
setblock 199 277 341 minecraft:light[level=15]
fill 199 277 344 203 280 344 minecraft:light_gray_concrete
fill 199 277 345 200 277 346 minecraft:verdant_froglight
setblock 199 277 349 minecraft:light[level=15]
setblock 199 277 357 minecraft:light[level=15]
fill 200 277 340 204 280 341 minecraft:light_gray_concrete
fill 200 277 342 200 277 343 minecraft:verdant_froglight
fill 200 277 347 203 280 348 minecraft:light_gray_concrete
fill 200 277 349 200 277 350 minecraft:verdant_froglight
setblock 201 277 339 minecraft:verdant_froglight
fill 201 277 342 203 280 343 minecraft:light_gray_concrete
fill 201 277 345 203 280 346 minecraft:light_gray_concrete
fill 201 277 349 204 280 349 minecraft:light_gray_concrete
setblock 201 277 350 minecraft:verdant_froglight
fill 201 277 351 206 280 351 minecraft:light_gray_concrete
fill 202 277 337 206 280 339 minecraft:light_gray_concrete
fill 202 277 350 205 280 350 minecraft:light_gray_concrete
fill 202 277 352 202 277 353 minecraft:verdant_froglight
fill 203 277 336 204 277 336 minecraft:verdant_froglight
fill 203 277 352 208 280 352 minecraft:light_gray_concrete
setblock 203 277 353 minecraft:verdant_froglight
fill 203 277 354 219 280 354 minecraft:light_gray_concrete
fill 204 277 342 204 281 342 minecraft:light_gray_concrete
fill 204 277 343 204 277 347 minecraft:iron_block
fill 204 277 348 204 281 348 minecraft:light_gray_concrete
fill 204 277 353 218 280 353 minecraft:light_gray_concrete
fill 205 277 335 217 280 336 minecraft:light_gray_concrete
fill 205 277 340 205 280 340 minecraft:light_gray_concrete
schedule function dropper:buildpart/76_3 1t
