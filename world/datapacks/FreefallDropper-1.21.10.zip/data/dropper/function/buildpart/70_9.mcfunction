setblock 489 205 310 minecraft:light[level=13]
setblock 489 205 314 minecraft:deepslate_tiles
setblock 489 205 315 minecraft:cobbled_deepslate
fill 489 205 316 489 208 316 minecraft:deepslate_tiles
setblock 490 205 314 minecraft:cobbled_deepslate
fill 490 205 315 493 205 315 minecraft:deepslate_tiles
fill 491 205 314 491 207 314 minecraft:deepslate_tiles
setblock 492 205 277 minecraft:cobbled_deepslate
setblock 493 205 276 minecraft:cobbled_deepslate
fill 493 205 277 493 208 277 minecraft:deepslate_tiles
fill 493 205 314 493 206 314 minecraft:deepslate_tiles
setblock 493 205 316 minecraft:cobbled_deepslate
fill 494 205 276 494 208 276 minecraft:deepslate_tiles
setblock 494 205 278 minecraft:light[level=12]
setblock 494 205 285 minecraft:light[level=12]
setblock 494 205 292 minecraft:light[level=12]
setblock 494 205 299 minecraft:light[level=12]
setblock 494 205 306 minecraft:light[level=12]
setblock 494 205 313 minecraft:light[level=12]
setblock 494 205 315 minecraft:cobbled_deepslate
fill 494 205 316 494 208 316 minecraft:deepslate_tiles
fill 495 205 315 498 205 315 minecraft:deepslate_tiles
setblock 497 205 278 minecraft:light[level=13]
setblock 497 205 286 minecraft:light[level=13]
setblock 497 205 294 minecraft:light[level=13]
setblock 497 205 302 minecraft:light[level=13]
setblock 497 205 310 minecraft:light[level=13]
fill 497 205 314 499 205 314 minecraft:deepslate_tiles
setblock 498 205 276 minecraft:cobbled_deepslate
setblock 498 205 316 minecraft:cobbled_deepslate
fill 499 205 276 499 208 276 minecraft:deepslate_tiles
setblock 499 205 315 minecraft:cobbled_deepslate
fill 499 205 316 499 208 316 minecraft:deepslate_tiles
setblock 500 205 314 minecraft:cobbled_deepslate
fill 500 205 315 500 208 315 minecraft:deepslate_tiles
fill 501 205 275 501 206 276 minecraft:deepslate_tiles
setblock 501 205 278 minecraft:light[level=12]
setblock 501 205 285 minecraft:light[level=12]
setblock 501 205 292 minecraft:light[level=12]
setblock 501 205 299 minecraft:light[level=12]
setblock 501 205 306 minecraft:light[level=12]
setblock 501 205 313 minecraft:cobbled_deepslate
fill 501 205 314 501 208 314 minecraft:deepslate_tiles
setblock 502 205 276 minecraft:deepslate_tiles
setblock 502 205 277 minecraft:cobbled_deepslate
fill 502 205 313 502 208 313 minecraft:deepslate_tiles
setblock 503 205 276 minecraft:cobbled_deepslate
fill 503 205 277 506 205 277 minecraft:deepslate_tiles
setblock 503 205 316 minecraft:cobbled_deepslate
fill 504 205 276 504 208 276 minecraft:deepslate_tiles
setblock 504 205 315 minecraft:cobbled_deepslate
fill 504 205 316 504 208 316 minecraft:deepslate_tiles
setblock 505 205 278 minecraft:light[level=13]
setblock 505 205 286 minecraft:light[level=13]
setblock 505 205 302 minecraft:light[level=13]
setblock 505 205 310 minecraft:light[level=13]
setblock 505 205 314 minecraft:cobbled_deepslate
fill 505 205 315 505 208 315 minecraft:deepslate_tiles
setblock 506 205 313 minecraft:cobbled_deepslate
fill 506 205 314 506 208 314 minecraft:deepslate_tiles
fill 506 205 317 506 308 317 minecraft:deepslate_tiles
fill 507 205 275 507 221 275 minecraft:deepslate_tiles
setblock 507 205 277 minecraft:cobbled_deepslate
fill 507 205 313 507 207 313 minecraft:deepslate_tiles
setblock 508 205 276 minecraft:cobbled_deepslate
setblock 508 205 278 minecraft:light[level=12]
setblock 508 205 285 minecraft:light[level=12]
setblock 508 205 292 minecraft:light[level=12]
setblock 508 205 299 minecraft:light[level=12]
setblock 508 205 306 minecraft:light[level=12]
setblock 508 205 311 minecraft:cobbled_deepslate
fill 508 205 312 508 206 312 minecraft:deepslate_tiles
setblock 508 205 316 minecraft:cobbled_deepslate
fill 509 205 276 509 208 276 minecraft:deepslate_tiles
fill 509 205 291 509 206 291 minecraft:deepslate_tiles
fill 509 205 293 509 205 294 minecraft:deepslate_tiles
setblock 509 205 295 minecraft:cobbled_deepslate
fill 509 205 296 509 208 296 minecraft:deepslate_tiles
setblock 509 205 299 minecraft:deepslate_tiles
setblock 509 205 310 minecraft:cobbled_deepslate
fill 509 205 311 509 207 311 minecraft:deepslate_tiles
setblock 509 205 315 minecraft:cobbled_deepslate
fill 509 205 316 509 208 316 minecraft:deepslate_tiles
setblock 510 205 289 minecraft:cobbled_deepslate
fill 510 205 290 510 207 290 minecraft:deepslate_tiles
setblock 510 205 294 minecraft:cobbled_deepslate
fill 510 205 295 510 208 295 minecraft:deepslate_tiles
setblock 510 205 299 minecraft:cobbled_deepslate
fill 510 205 300 510 208 300 minecraft:deepslate_tiles
setblock 510 205 304 minecraft:cobbled_deepslate
fill 510 205 305 510 207 305 minecraft:deepslate_tiles
setblock 510 205 309 minecraft:cobbled_deepslate
fill 510 205 310 510 207 310 minecraft:deepslate_tiles
setblock 510 205 314 minecraft:cobbled_deepslate
fill 510 205 315 510 208 315 minecraft:deepslate_tiles
fill 511 205 276 511 206 276 minecraft:deepslate_tiles
setblock 511 205 288 minecraft:cobbled_deepslate
fill 511 205 289 511 208 289 minecraft:deepslate_tiles
setblock 511 205 293 minecraft:cobbled_deepslate
fill 511 205 294 511 208 294 minecraft:deepslate_tiles
setblock 511 205 298 minecraft:cobbled_deepslate
fill 511 205 299 511 208 299 minecraft:deepslate_tiles
setblock 511 205 303 minecraft:cobbled_deepslate
fill 511 205 304 511 208 304 minecraft:deepslate_tiles
setblock 511 205 308 minecraft:cobbled_deepslate
fill 511 205 309 511 208 309 minecraft:deepslate_tiles
setblock 511 205 313 minecraft:cobbled_deepslate
fill 511 205 314 511 208 314 minecraft:deepslate_tiles
fill 511 205 317 511 308 317 minecraft:deepslate_tiles
fill 512 205 281 512 264 281 minecraft:deepslate_tiles
fill 512 205 286 512 308 286 minecraft:deepslate_tiles
fill 512 205 291 512 308 291 minecraft:deepslate_tiles
fill 512 205 303 512 258 303 minecraft:deepslate_tiles
setblock 471 206 277 minecraft:cobbled_deepslate
setblock 471 206 287 minecraft:cobbled_deepslate
fill 471 206 288 471 209 288 minecraft:deepslate_tiles
setblock 471 206 292 minecraft:cobbled_deepslate
fill 471 206 293 471 209 293 minecraft:deepslate_tiles
setblock 471 206 297 minecraft:cobbled_deepslate
fill 471 206 298 471 209 298 minecraft:deepslate_tiles
setblock 471 206 302 minecraft:cobbled_deepslate
fill 471 206 303 471 207 303 minecraft:deepslate_tiles
setblock 471 206 312 minecraft:cobbled_deepslate
fill 471 206 313 471 207 313 minecraft:deepslate_tiles
fill 471 206 316 471 206 317 minecraft:deepslate_tiles
setblock 472 206 276 minecraft:cobbled_deepslate
setblock 472 206 291 minecraft:cobbled_deepslate
fill 472 206 292 472 209 292 minecraft:deepslate_tiles
setblock 472 206 296 minecraft:cobbled_deepslate
fill 472 206 297 472 209 297 minecraft:deepslate_tiles
setblock 472 206 316 minecraft:cobbled_deepslate
fill 472 206 317 472 308 317 minecraft:deepslate_tiles
fill 473 206 276 476 206 276 minecraft:deepslate_tiles
setblock 473 206 291 minecraft:deepslate_tiles
setblock 473 206 295 minecraft:cobbled_deepslate
fill 473 206 297 473 207 297 minecraft:black_concrete
fill 473 206 316 476 206 316 minecraft:deepslate_tiles
setblock 477 206 276 minecraft:cobbled_deepslate
setblock 477 206 316 minecraft:cobbled_deepslate
fill 478 206 276 478 209 276 minecraft:deepslate_tiles
fill 478 206 316 478 209 316 minecraft:deepslate_tiles
fill 479 206 277 480 206 277 minecraft:deepslate_tiles
fill 479 206 315 482 206 315 minecraft:deepslate_tiles
setblock 481 206 277 minecraft:cobbled_deepslate
fill 481 206 278 482 208 278 minecraft:deepslate_tiles
setblock 482 206 276 minecraft:cobbled_deepslate
fill 482 206 277 482 209 277 minecraft:deepslate_tiles
fill 482 206 314 483 206 314 minecraft:deepslate_tiles
setblock 482 206 316 minecraft:cobbled_deepslate
fill 482 206 317 482 308 317 minecraft:deepslate_tiles
fill 483 206 276 483 209 276 minecraft:deepslate_tiles
setblock 483 206 315 minecraft:cobbled_deepslate
fill 483 206 316 483 209 316 minecraft:deepslate_tiles
setblock 484 206 278 minecraft:deepslate_tiles
setblock 484 206 314 minecraft:cobbled_deepslate
fill 484 206 315 484 209 315 minecraft:deepslate_tiles
setblock 485 206 278 minecraft:cobbled_deepslate
setblock 485 206 280 minecraft:black_concrete
fill 485 206 314 485 209 314 minecraft:deepslate_tiles
setblock 486 206 277 minecraft:cobbled_deepslate
fill 486 206 278 486 209 278 minecraft:deepslate_tiles
setblock 487 206 276 minecraft:cobbled_deepslate
fill 487 206 277 487 209 277 minecraft:deepslate_tiles
setblock 487 206 282 minecraft:black_concrete
setblock 487 206 316 minecraft:cobbled_deepslate
fill 488 206 276 488 209 276 minecraft:deepslate_tiles
setblock 488 206 315 minecraft:cobbled_deepslate
fill 488 206 316 488 209 316 minecraft:deepslate_tiles
setblock 489 206 280 minecraft:black_concrete
setblock 489 206 314 minecraft:cobbled_deepslate
fill 489 206 315 492 206 315 minecraft:deepslate_tiles
fill 490 206 314 490 208 314 minecraft:deepslate_tiles
setblock 491 206 277 minecraft:cobbled_deepslate
setblock 492 206 276 minecraft:cobbled_deepslate
fill 492 206 277 492 209 277 minecraft:deepslate_tiles
setblock 492 206 316 minecraft:cobbled_deepslate
fill 493 206 276 493 209 276 minecraft:deepslate_tiles
setblock 493 206 315 minecraft:cobbled_deepslate
fill 493 206 316 493 209 316 minecraft:deepslate_tiles
fill 494 206 315 497 206 315 minecraft:deepslate_tiles
fill 495 206 314 498 206 314 minecraft:deepslate_tiles
setblock 496 206 276 minecraft:deepslate_tiles
setblock 497 206 276 minecraft:cobbled_deepslate
setblock 497 206 316 minecraft:cobbled_deepslate
fill 498 206 276 498 209 276 minecraft:deepslate_tiles
setblock 498 206 315 minecraft:cobbled_deepslate
fill 498 206 316 498 209 316 minecraft:deepslate_tiles
setblock 499 206 314 minecraft:cobbled_deepslate
fill 499 206 315 499 209 315 minecraft:deepslate_tiles
setblock 500 206 277 minecraft:deepslate_tiles
setblock 500 206 313 minecraft:cobbled_deepslate
fill 500 206 314 500 209 314 minecraft:deepslate_tiles
setblock 501 206 277 minecraft:cobbled_deepslate
fill 501 206 313 501 209 313 minecraft:deepslate_tiles
setblock 502 206 276 minecraft:cobbled_deepslate
fill 502 206 277 505 206 277 minecraft:deepslate_tiles
setblock 502 206 316 minecraft:cobbled_deepslate
fill 503 206 276 503 209 276 minecraft:deepslate_tiles
setblock 503 206 315 minecraft:cobbled_deepslate
fill 503 206 316 503 209 316 minecraft:deepslate_tiles
setblock 504 206 314 minecraft:cobbled_deepslate
fill 504 206 315 504 209 315 minecraft:deepslate_tiles
setblock 505 206 313 minecraft:cobbled_deepslate
fill 505 206 314 505 209 314 minecraft:deepslate_tiles
setblock 506 206 277 minecraft:cobbled_deepslate
fill 506 206 295 506 209 295 minecraft:bone_block
fill 506 206 313 506 208 313 minecraft:deepslate_tiles
setblock 507 206 276 minecraft:cobbled_deepslate
fill 507 206 277 508 207 277 minecraft:deepslate_tiles
setblock 507 206 316 minecraft:cobbled_deepslate
fill 508 206 276 508 209 276 minecraft:deepslate_tiles
setblock 508 206 294 minecraft:deepslate_tiles
setblock 508 206 295 minecraft:cobbled_deepslate
fill 508 206 296 508 208 296 minecraft:deepslate_tiles
setblock 508 206 311 minecraft:deepslate_tiles
setblock 508 206 315 minecraft:cobbled_deepslate
fill 508 206 316 508 209 316 minecraft:deepslate_tiles
setblock 509 206 293 minecraft:deepslate_tiles
setblock 509 206 294 minecraft:cobbled_deepslate
fill 509 206 295 509 209 295 minecraft:deepslate_tiles
setblock 509 206 299 minecraft:cobbled_deepslate
fill 509 206 300 509 209 300 minecraft:deepslate_tiles
setblock 509 206 309 minecraft:cobbled_deepslate
fill 509 206 310 509 207 310 minecraft:deepslate_tiles
setblock 509 206 314 minecraft:cobbled_deepslate
fill 509 206 315 509 209 315 minecraft:deepslate_tiles
setblock 510 206 289 minecraft:deepslate_tiles
setblock 510 206 293 minecraft:cobbled_deepslate
fill 510 206 294 510 209 294 minecraft:deepslate_tiles
setblock 510 206 298 minecraft:cobbled_deepslate
fill 510 206 299 510 209 299 minecraft:deepslate_tiles
setblock 510 206 303 minecraft:cobbled_deepslate
fill 510 206 304 510 207 304 minecraft:deepslate_tiles
setblock 510 206 308 minecraft:cobbled_deepslate
fill 510 206 309 510 207 309 minecraft:deepslate_tiles
setblock 510 206 313 minecraft:cobbled_deepslate
fill 510 206 314 510 208 314 minecraft:deepslate_tiles
setblock 511 206 287 minecraft:cobbled_deepslate
fill 511 206 288 511 207 288 minecraft:deepslate_tiles
setblock 511 206 292 minecraft:cobbled_deepslate
fill 511 206 293 511 209 293 minecraft:deepslate_tiles
setblock 511 206 297 minecraft:cobbled_deepslate
fill 511 206 298 512 209 298 minecraft:deepslate_tiles
setblock 511 206 302 minecraft:cobbled_deepslate
fill 511 206 303 511 209 303 minecraft:deepslate_tiles
setblock 511 206 307 minecraft:cobbled_deepslate
fill 511 206 308 511 208 308 minecraft:deepslate_tiles
setblock 511 206 312 minecraft:cobbled_deepslate
fill 511 206 313 511 209 313 minecraft:deepslate_tiles
fill 512 206 287 512 308 287 minecraft:deepslate_tiles
fill 512 206 292 512 293 292 minecraft:deepslate_tiles
fill 512 206 297 512 308 297 minecraft:deepslate_tiles
fill 512 206 299 512 273 299 minecraft:deepslate_tiles
setblock 512 206 300 minecraft:white_wool
fill 512 206 301 512 213 302 minecraft:deepslate_tiles
fill 512 206 307 512 209 307 minecraft:deepslate_tiles
fill 512 206 312 512 308 312 minecraft:deepslate_tiles
fill 470 207 284 470 308 284 minecraft:deepslate_tiles
fill 470 207 301 470 308 301 minecraft:deepslate_tiles
setblock 471 207 276 minecraft:cobbled_deepslate
fill 471 207 277 471 209 278 minecraft:deepslate_tiles
setblock 471 207 286 minecraft:cobbled_deepslate
fill 471 207 287 471 209 287 minecraft:deepslate_tiles
setblock 471 207 291 minecraft:cobbled_deepslate
fill 471 207 292 471 209 292 minecraft:deepslate_tiles
setblock 471 207 296 minecraft:cobbled_deepslate
fill 471 207 297 471 209 297 minecraft:deepslate_tiles
setblock 471 207 301 minecraft:cobbled_deepslate
fill 471 207 302 471 209 302 minecraft:deepslate_tiles
setblock 471 207 311 minecraft:cobbled_deepslate
setblock 471 207 312 minecraft:deepslate_tiles
setblock 471 207 316 minecraft:cobbled_deepslate
fill 471 207 317 471 272 317 minecraft:deepslate_tiles
fill 472 207 276 475 207 276 minecraft:deepslate_tiles
setblock 472 207 290 minecraft:cobbled_deepslate
fill 472 207 291 472 209 291 minecraft:deepslate_tiles
setblock 472 207 294 minecraft:deepslate_tiles
setblock 472 207 295 minecraft:cobbled_deepslate
fill 472 207 296 472 209 296 minecraft:deepslate_tiles
fill 472 207 316 475 207 316 minecraft:deepslate_tiles
setblock 473 207 294 minecraft:cobbled_deepslate
fill 473 207 295 473 208 295 minecraft:deepslate_tiles
setblock 474 207 296 minecraft:black_concrete
setblock 476 207 276 minecraft:cobbled_deepslate
setblock 476 207 316 minecraft:cobbled_deepslate
fill 477 207 276 477 209 276 minecraft:deepslate_tiles
fill 477 207 316 477 209 316 minecraft:deepslate_tiles
fill 478 207 277 479 207 277 minecraft:deepslate_tiles
fill 479 207 315 481 207 315 minecraft:deepslate_tiles
setblock 480 207 277 minecraft:cobbled_deepslate
fill 480 207 278 480 209 278 minecraft:deepslate_tiles
setblock 481 207 276 minecraft:cobbled_deepslate
fill 481 207 277 481 209 277 minecraft:deepslate_tiles
setblock 481 207 316 minecraft:cobbled_deepslate
fill 481 207 317 481 308 317 minecraft:deepslate_tiles
fill 482 207 276 482 209 276 minecraft:deepslate_tiles
setblock 482 207 314 minecraft:deepslate_tiles
setblock 482 207 315 minecraft:cobbled_deepslate
fill 482 207 316 482 209 316 minecraft:deepslate_tiles
setblock 483 207 314 minecraft:cobbled_deepslate
fill 483 207 315 483 209 315 minecraft:deepslate_tiles
setblock 484 207 278 minecraft:cobbled_deepslate
fill 484 207 314 484 209 314 minecraft:deepslate_tiles
setblock 485 207 277 minecraft:cobbled_deepslate
fill 485 207 278 485 209 278 minecraft:deepslate_tiles
setblock 486 207 276 minecraft:cobbled_deepslate
fill 486 207 277 486 209 277 minecraft:deepslate_tiles
setblock 486 207 316 minecraft:cobbled_deepslate
fill 486 207 317 486 265 317 minecraft:deepslate_tiles
fill 487 207 276 487 209 276 minecraft:deepslate_tiles
setblock 487 207 315 minecraft:cobbled_deepslate
fill 487 207 316 487 209 316 minecraft:deepslate_tiles
setblock 488 207 314 minecraft:cobbled_deepslate
fill 488 207 315 491 207 315 minecraft:deepslate_tiles
setblock 489 207 278 minecraft:cobbled_deepslate
fill 489 207 314 489 208 314 minecraft:deepslate_tiles
setblock 490 207 277 minecraft:cobbled_deepslate
setblock 491 207 276 minecraft:cobbled_deepslate
fill 491 207 277 491 209 277 minecraft:deepslate_tiles
setblock 491 207 316 minecraft:cobbled_deepslate
fill 492 207 276 492 209 276 minecraft:deepslate_tiles
setblock 492 207 315 minecraft:cobbled_deepslate
fill 492 207 316 492 209 316 minecraft:deepslate_tiles
fill 493 207 315 496 207 315 minecraft:deepslate_tiles
setblock 494 207 277 minecraft:deepslate_tiles
setblock 496 207 276 minecraft:cobbled_deepslate
fill 496 207 314 497 207 314 minecraft:deepslate_tiles
setblock 496 207 316 minecraft:cobbled_deepslate
fill 497 207 276 497 209 276 minecraft:deepslate_tiles
setblock 497 207 315 minecraft:cobbled_deepslate
fill 497 207 316 497 209 316 minecraft:deepslate_tiles
fill 498 207 277 499 207 277 minecraft:deepslate_tiles
setblock 498 207 314 minecraft:cobbled_deepslate
fill 498 207 315 498 209 315 minecraft:deepslate_tiles
fill 499 207 314 499 209 314 minecraft:deepslate_tiles
setblock 500 207 277 minecraft:cobbled_deepslate
setblock 500 207 313 minecraft:deepslate_tiles
fill 501 207 275 501 308 275 minecraft:deepslate_tiles
setblock 501 207 276 minecraft:cobbled_deepslate
fill 501 207 277 504 207 277 minecraft:deepslate_tiles
setblock 501 207 316 minecraft:cobbled_deepslate
fill 502 207 276 502 209 276 minecraft:deepslate_tiles
setblock 502 207 315 minecraft:cobbled_deepslate
fill 502 207 316 502 209 316 minecraft:deepslate_tiles
setblock 503 207 314 minecraft:cobbled_deepslate
fill 503 207 315 503 209 315 minecraft:deepslate_tiles
fill 504 207 294 505 209 296 minecraft:bone_block
setblock 504 207 313 minecraft:cobbled_deepslate
fill 504 207 314 504 209 314 minecraft:deepslate_tiles
setblock 505 207 277 minecraft:cobbled_deepslate
fill 505 207 293 507 209 293 minecraft:bone_block
fill 505 207 297 507 209 297 minecraft:bone_block
fill 505 207 313 505 208 313 minecraft:deepslate_tiles
setblock 506 207 276 minecraft:cobbled_deepslate
fill 506 207 277 506 209 277 minecraft:deepslate_tiles
fill 506 207 294 507 209 294 minecraft:bone_block
fill 506 207 296 507 209 296 minecraft:bone_block
setblock 506 207 316 minecraft:cobbled_deepslate
fill 507 207 276 507 209 276 minecraft:deepslate_tiles
fill 507 207 295 507 209 295 minecraft:bone_block
setblock 507 207 315 minecraft:cobbled_deepslate
fill 507 207 316 507 209 316 minecraft:deepslate_tiles
setblock 508 207 294 minecraft:cobbled_deepslate
fill 508 207 295 508 208 295 minecraft:deepslate_tiles
fill 508 207 297 509 207 297 minecraft:deepslate_tiles
setblock 508 207 314 minecraft:cobbled_deepslate
fill 508 207 315 508 209 315 minecraft:deepslate_tiles
setblock 509 207 293 minecraft:cobbled_deepslate
fill 509 207 294 509 209 294 minecraft:deepslate_tiles
setblock 509 207 298 minecraft:cobbled_deepslate
fill 509 207 299 509 209 299 minecraft:deepslate_tiles
fill 509 207 301 509 208 301 minecraft:deepslate_tiles
setblock 509 207 313 minecraft:cobbled_deepslate
fill 509 207 314 509 208 314 minecraft:deepslate_tiles
setblock 510 207 291 minecraft:deepslate_tiles
setblock 510 207 292 minecraft:cobbled_deepslate
fill 510 207 293 510 209 293 minecraft:deepslate_tiles
setblock 510 207 297 minecraft:cobbled_deepslate
fill 510 207 298 510 209 298 minecraft:deepslate_tiles
setblock 510 207 302 minecraft:cobbled_deepslate
fill 510 207 303 510 208 303 minecraft:deepslate_tiles
setblock 510 207 307 minecraft:cobbled_deepslate
setblock 510 207 308 minecraft:deepslate_tiles
setblock 510 207 312 minecraft:cobbled_deepslate
fill 510 207 313 510 208 313 minecraft:deepslate_tiles
setblock 511 207 276 minecraft:cobbled_deepslate
setblock 511 207 291 minecraft:cobbled_deepslate
fill 511 207 292 511 209 292 minecraft:deepslate_tiles
setblock 511 207 296 minecraft:cobbled_deepslate
fill 511 207 297 511 209 297 minecraft:deepslate_tiles
setblock 511 207 301 minecraft:cobbled_deepslate
fill 511 207 302 511 209 302 minecraft:deepslate_tiles
setblock 511 207 306 minecraft:cobbled_deepslate
fill 511 207 307 511 208 307 minecraft:deepslate_tiles
setblock 511 207 311 minecraft:cobbled_deepslate
fill 511 207 312 511 209 312 minecraft:deepslate_tiles
setblock 511 207 316 minecraft:cobbled_deepslate
fill 512 207 300 512 265 300 minecraft:deepslate_tiles
fill 512 207 316 512 308 316 minecraft:deepslate_tiles
fill 470 208 290 470 308 290 minecraft:deepslate_tiles
fill 471 208 276 474 208 276 minecraft:deepslate_tiles
setblock 471 208 279 minecraft:deepslate_tiles
setblock 471 208 286 minecraft:deepslate_tiles
setblock 471 208 290 minecraft:cobbled_deepslate
fill 471 208 291 471 209 291 minecraft:deepslate_tiles
setblock 471 208 295 minecraft:cobbled_deepslate
fill 471 208 296 471 209 296 minecraft:deepslate_tiles
setblock 471 208 299 minecraft:deepslate_tiles
setblock 471 208 300 minecraft:cobbled_deepslate
fill 471 208 301 471 209 301 minecraft:deepslate_tiles
setblock 471 208 315 minecraft:cobbled_deepslate
fill 471 208 316 472 208 316 minecraft:deepslate_tiles
setblock 472 208 290 minecraft:deepslate_tiles
setblock 472 208 294 minecraft:cobbled_deepslate
fill 472 208 295 472 209 295 minecraft:deepslate_tiles
setblock 472 208 299 minecraft:cobbled_deepslate
setblock 473 208 294 minecraft:deepslate_tiles
setblock 475 208 276 minecraft:cobbled_deepslate
setblock 475 208 316 minecraft:cobbled_deepslate
fill 476 208 276 476 209 276 minecraft:deepslate_tiles
fill 476 208 316 476 209 317 minecraft:deepslate_tiles
fill 477 208 277 478 208 277 minecraft:deepslate_tiles
setblock 477 208 317 minecraft:redstone_block
setblock 479 208 277 minecraft:cobbled_deepslate
fill 479 208 278 479 209 278 minecraft:deepslate_tiles
fill 479 208 315 480 208 315 minecraft:deepslate_tiles
setblock 480 208 276 minecraft:cobbled_deepslate
fill 480 208 277 480 209 277 minecraft:deepslate_tiles
setblock 480 208 316 minecraft:cobbled_deepslate
fill 481 208 276 481 209 276 minecraft:deepslate_tiles
setblock 481 208 315 minecraft:cobbled_deepslate
fill 481 208 316 481 209 316 minecraft:deepslate_tiles
setblock 482 208 314 minecraft:cobbled_deepslate
fill 482 208 315 482 209 315 minecraft:deepslate_tiles
setblock 483 208 277 minecraft:deepslate_tiles
setblock 483 208 278 minecraft:cobbled_deepslate
fill 483 208 279 485 209 279 minecraft:deepslate_tiles
fill 483 208 314 483 209 314 minecraft:deepslate_tiles
setblock 484 208 277 minecraft:cobbled_deepslate
fill 484 208 278 484 209 278 minecraft:deepslate_tiles
setblock 485 208 276 minecraft:cobbled_deepslate
fill 485 208 277 485 209 277 minecraft:deepslate_tiles
setblock 485 208 316 minecraft:cobbled_deepslate
fill 485 208 317 485 308 317 minecraft:deepslate_tiles
fill 486 208 276 486 209 276 minecraft:deepslate_tiles
setblock 486 208 315 minecraft:cobbled_deepslate
fill 486 208 316 486 209 316 minecraft:deepslate_tiles
setblock 487 208 314 minecraft:cobbled_deepslate
fill 487 208 315 490 208 315 minecraft:deepslate_tiles
setblock 488 208 278 minecraft:cobbled_deepslate
fill 488 208 314 488 209 314 minecraft:deepslate_tiles
setblock 489 208 277 minecraft:cobbled_deepslate
fill 489 208 278 489 209 278 minecraft:deepslate_tiles
setblock 490 208 276 minecraft:cobbled_deepslate
fill 490 208 277 490 209 277 minecraft:deepslate_tiles
setblock 490 208 316 minecraft:cobbled_deepslate
fill 491 208 276 491 209 276 minecraft:deepslate_tiles
setblock 491 208 315 minecraft:cobbled_deepslate
fill 491 208 316 491 209 316 minecraft:deepslate_tiles
fill 492 208 315 495 208 315 minecraft:deepslate_tiles
setblock 494 208 277 minecraft:cobbled_deepslate
setblock 495 208 276 minecraft:cobbled_deepslate
fill 495 208 277 498 208 277 minecraft:deepslate_tiles
setblock 495 208 316 minecraft:cobbled_deepslate
fill 496 208 276 496 209 276 minecraft:deepslate_tiles
setblock 496 208 314 minecraft:deepslate_tiles
setblock 496 208 315 minecraft:cobbled_deepslate
fill 496 208 316 496 209 316 minecraft:deepslate_tiles
setblock 497 208 314 minecraft:cobbled_deepslate
fill 497 208 315 497 209 315 minecraft:deepslate_tiles
fill 498 208 314 498 209 314 minecraft:deepslate_tiles
setblock 499 208 277 minecraft:cobbled_deepslate
fill 500 208 275 500 291 275 minecraft:deepslate_tiles
setblock 500 208 276 minecraft:cobbled_deepslate
fill 500 208 277 503 208 277 minecraft:deepslate_tiles
setblock 500 208 316 minecraft:cobbled_deepslate
fill 501 208 276 501 209 276 minecraft:deepslate_tiles
setblock 501 208 315 minecraft:cobbled_deepslate
fill 501 208 316 501 209 316 minecraft:deepslate_tiles
setblock 502 208 314 minecraft:cobbled_deepslate
fill 502 208 315 502 209 315 minecraft:deepslate_tiles
setblock 503 208 313 minecraft:cobbled_deepslate
fill 503 208 314 503 209 314 minecraft:deepslate_tiles
setblock 504 208 277 minecraft:cobbled_deepslate
fill 504 208 313 504 209 313 minecraft:deepslate_tiles
setblock 505 208 276 minecraft:cobbled_deepslate
fill 505 208 277 505 209 277 minecraft:deepslate_tiles
setblock 505 208 316 minecraft:cobbled_deepslate
fill 506 208 276 506 209 276 minecraft:deepslate_tiles
setblock 506 208 315 minecraft:cobbled_deepslate
fill 506 208 316 506 209 316 minecraft:deepslate_tiles
fill 507 208 277 507 209 277 minecraft:deepslate_tiles
setblock 507 208 314 minecraft:cobbled_deepslate
fill 507 208 315 507 209 315 minecraft:deepslate_tiles
fill 508 208 294 508 209 294 minecraft:bone_block
setblock 508 208 297 minecraft:deepslate_tiles
setblock 508 208 314 minecraft:deepslate_tiles
setblock 509 208 292 minecraft:cobbled_deepslate
setblock 509 208 293 minecraft:deepslate_tiles
setblock 509 208 297 minecraft:cobbled_deepslate
fill 509 208 298 509 209 298 minecraft:deepslate_tiles
setblock 510 208 276 minecraft:cobbled_deepslate
setblock 510 208 291 minecraft:cobbled_deepslate
fill 510 208 292 510 209 292 minecraft:deepslate_tiles
setblock 510 208 296 minecraft:cobbled_deepslate
fill 510 208 297 510 209 297 minecraft:deepslate_tiles
setblock 510 208 301 minecraft:cobbled_deepslate
fill 510 208 302 510 209 302 minecraft:deepslate_tiles
setblock 510 208 311 minecraft:cobbled_deepslate
setblock 510 208 312 minecraft:deepslate_tiles
setblock 510 208 316 minecraft:cobbled_deepslate
setblock 511 208 276 minecraft:deepslate_tiles
setblock 511 208 290 minecraft:cobbled_deepslate
fill 511 208 291 511 209 291 minecraft:deepslate_tiles
setblock 511 208 295 minecraft:cobbled_deepslate
fill 511 208 296 511 209 296 minecraft:deepslate_tiles
setblock 511 208 300 minecraft:cobbled_deepslate
fill 511 208 301 511 209 301 minecraft:deepslate_tiles
setblock 511 208 305 minecraft:cobbled_deepslate
setblock 511 208 306 minecraft:deepslate_tiles
setblock 511 208 310 minecraft:cobbled_deepslate
fill 511 208 311 511 209 311 minecraft:deepslate_tiles
setblock 511 208 315 minecraft:cobbled_deepslate
fill 511 208 316 511 209 316 minecraft:deepslate_tiles
fill 512 208 290 512 308 290 minecraft:deepslate_tiles
fill 512 208 305 512 284 305 minecraft:deepslate_tiles
fill 512 208 315 512 296 315 minecraft:deepslate_tiles
fill 471 209 276 473 209 276 minecraft:deepslate_tiles
setblock 471 209 279 minecraft:cobbled_deepslate
setblock 471 209 289 minecraft:cobbled_deepslate
setblock 471 209 290 minecraft:deepslate_tiles
setblock 471 209 294 minecraft:cobbled_deepslate
setblock 471 209 295 minecraft:deepslate_tiles
setblock 471 209 299 minecraft:cobbled_deepslate
setblock 471 209 300 minecraft:deepslate_tiles
setblock 472 209 293 minecraft:cobbled_deepslate
setblock 472 209 294 minecraft:deepslate_tiles
setblock 472 209 298 minecraft:cobbled_deepslate
setblock 472 209 299 minecraft:deepslate_tiles
setblock 474 209 276 minecraft:cobbled_deepslate
setblock 475 209 276 minecraft:deepslate_tiles
fill 476 209 277 477 209 277 minecraft:deepslate_tiles
fill 477 209 317 477 308 317 minecraft:deepslate_tiles
setblock 478 209 277 minecraft:cobbled_deepslate
setblock 479 209 276 minecraft:cobbled_deepslate
setblock 479 209 277 minecraft:deepslate_tiles
setblock 479 209 315 minecraft:deepslate_tiles
setblock 479 209 316 minecraft:cobbled_deepslate
setblock 480 209 276 minecraft:deepslate_tiles
setblock 480 209 315 minecraft:cobbled_deepslate
setblock 480 209 316 minecraft:deepslate_tiles
setblock 481 209 278 minecraft:deepslate_tiles
setblock 481 209 315 minecraft:deepslate_tiles
setblock 482 209 278 minecraft:cobbled_deepslate
setblock 482 209 279 minecraft:deepslate_tiles
setblock 482 209 314 minecraft:deepslate_tiles
setblock 483 209 277 minecraft:cobbled_deepslate
setblock 483 209 278 minecraft:deepslate_tiles
setblock 484 209 276 minecraft:cobbled_deepslate
setblock 484 209 277 minecraft:deepslate_tiles
setblock 484 209 316 minecraft:cobbled_deepslate
setblock 485 209 276 minecraft:deepslate_tiles
setblock 485 209 315 minecraft:cobbled_deepslate
setblock 485 209 316 minecraft:deepslate_tiles
setblock 486 209 314 minecraft:cobbled_deepslate
fill 486 209 315 489 209 315 minecraft:deepslate_tiles
setblock 487 209 278 minecraft:cobbled_deepslate
setblock 487 209 314 minecraft:deepslate_tiles
setblock 488 209 277 minecraft:cobbled_deepslate
setblock 488 209 278 minecraft:deepslate_tiles
setblock 489 209 276 minecraft:cobbled_deepslate
setblock 489 209 277 minecraft:deepslate_tiles
setblock 489 209 316 minecraft:cobbled_deepslate
setblock 490 209 276 minecraft:deepslate_tiles
setblock 490 209 315 minecraft:cobbled_deepslate
setblock 490 209 316 minecraft:deepslate_tiles
fill 491 209 315 494 209 315 minecraft:deepslate_tiles
setblock 493 209 277 minecraft:cobbled_deepslate
setblock 494 209 276 minecraft:cobbled_deepslate
fill 494 209 277 497 209 277 minecraft:deepslate_tiles
setblock 494 209 316 minecraft:cobbled_deepslate
setblock 495 209 276 minecraft:deepslate_tiles
setblock 495 209 315 minecraft:cobbled_deepslate
setblock 495 209 316 minecraft:deepslate_tiles
setblock 496 209 315 minecraft:deepslate_tiles
setblock 497 209 314 minecraft:deepslate_tiles
setblock 498 209 277 minecraft:cobbled_deepslate
setblock 499 209 276 minecraft:cobbled_deepslate
fill 499 209 277 502 209 277 minecraft:deepslate_tiles
setblock 499 209 316 minecraft:cobbled_deepslate
setblock 500 209 276 minecraft:deepslate_tiles
setblock 500 209 315 minecraft:cobbled_deepslate
setblock 500 209 316 minecraft:deepslate_tiles
setblock 501 209 314 minecraft:cobbled_deepslate
setblock 501 209 315 minecraft:deepslate_tiles
setblock 502 209 313 minecraft:cobbled_deepslate
setblock 502 209 314 minecraft:deepslate_tiles
setblock 503 209 277 minecraft:cobbled_deepslate
setblock 503 209 313 minecraft:deepslate_tiles
setblock 504 209 276 minecraft:cobbled_deepslate
setblock 504 209 277 minecraft:deepslate_tiles
setblock 504 209 316 minecraft:cobbled_deepslate
setblock 505 209 276 minecraft:deepslate_tiles
setblock 505 209 315 minecraft:cobbled_deepslate
setblock 505 209 316 minecraft:deepslate_tiles
setblock 506 209 314 minecraft:cobbled_deepslate
setblock 506 209 315 minecraft:deepslate_tiles
setblock 507 209 314 minecraft:deepslate_tiles
fill 508 209 295 508 209 296 minecraft:bone_block
setblock 509 209 276 minecraft:cobbled_deepslate
setblock 509 209 296 minecraft:cobbled_deepslate
setblock 509 209 297 minecraft:deepslate_tiles
setblock 509 209 316 minecraft:cobbled_deepslate
setblock 510 209 276 minecraft:deepslate_tiles
setblock 510 209 295 minecraft:cobbled_deepslate
setblock 510 209 296 minecraft:deepslate_tiles
setblock 510 209 300 minecraft:cobbled_deepslate
setblock 510 209 301 minecraft:deepslate_tiles
setblock 510 209 315 minecraft:cobbled_deepslate
setblock 510 209 316 minecraft:deepslate_tiles
setblock 511 209 290 minecraft:deepslate_tiles
setblock 511 209 294 minecraft:cobbled_deepslate
setblock 511 209 295 minecraft:deepslate_tiles
setblock 511 209 299 minecraft:cobbled_deepslate
setblock 511 209 300 minecraft:deepslate_tiles
setblock 511 209 304 minecraft:cobbled_deepslate
setblock 511 209 305 minecraft:deepslate_tiles
setblock 511 209 314 minecraft:cobbled_deepslate
setblock 511 209 315 minecraft:deepslate_tiles
fill 476 210 317 476 308 317 minecraft:deepslate_tiles
fill 512 210 293 512 304 293 minecraft:deepslate_tiles
setblock 512 210 294 minecraft:redstone_block
fill 512 210 295 512 308 295 minecraft:deepslate_tiles
fill 512 210 298 512 308 298 minecraft:deepslate_tiles
setblock 512 210 307 minecraft:white_wool
setblock 473 211 278 minecraft:light[level=12]
setblock 473 211 285 minecraft:light[level=12]
setblock 473 211 292 minecraft:light[level=12]
setblock 473 211 299 minecraft:light[level=12]
setblock 473 211 306 minecraft:light[level=12]
setblock 473 211 313 minecraft:light[level=12]
setblock 480 211 278 minecraft:light[level=12]
setblock 480 211 285 minecraft:light[level=12]
setblock 480 211 292 minecraft:light[level=12]
setblock 480 211 299 minecraft:light[level=12]
setblock 480 211 306 minecraft:light[level=12]
setblock 480 211 313 minecraft:light[level=12]
setblock 487 211 278 minecraft:light[level=12]
setblock 487 211 285 minecraft:light[level=12]
setblock 487 211 292 minecraft:light[level=12]
setblock 487 211 299 minecraft:light[level=12]
setblock 487 211 306 minecraft:light[level=12]
setblock 487 211 313 minecraft:light[level=12]
setblock 494 211 278 minecraft:light[level=12]
setblock 494 211 285 minecraft:light[level=12]
setblock 494 211 292 minecraft:light[level=12]
setblock 494 211 299 minecraft:light[level=12]
setblock 494 211 306 minecraft:light[level=12]
setblock 494 211 313 minecraft:light[level=12]
setblock 500 211 317 minecraft:redstone_block
setblock 501 211 278 minecraft:light[level=12]
setblock 501 211 285 minecraft:light[level=12]
setblock 501 211 292 minecraft:light[level=12]
setblock 501 211 299 minecraft:light[level=12]
setblock 501 211 306 minecraft:light[level=12]
setblock 501 211 313 minecraft:light[level=12]
setblock 508 211 278 minecraft:light[level=12]
setblock 508 211 285 minecraft:light[level=12]
setblock 508 211 292 minecraft:light[level=12]
setblock 508 211 299 minecraft:light[level=12]
setblock 508 211 306 minecraft:light[level=12]
setblock 508 211 313 minecraft:light[level=12]
fill 512 211 294 512 265 294 minecraft:deepslate_tiles
fill 512 211 307 512 285 307 minecraft:deepslate_tiles
fill 481 212 275 488 228 275 minecraft:deepslate_tiles
setblock 489 212 275 minecraft:white_wool
fill 490 212 275 491 233 275 minecraft:deepslate_tiles
fill 500 212 317 500 308 317 minecraft:deepslate_tiles
setblock 473 213 278 minecraft:light[level=13]
setblock 473 213 286 minecraft:light[level=13]
setblock 473 213 294 minecraft:light[level=13]
setblock 473 213 302 minecraft:light[level=13]
setblock 473 213 310 minecraft:light[level=13]
setblock 481 213 278 minecraft:light[level=13]
setblock 481 213 286 minecraft:light[level=13]
setblock 481 213 294 minecraft:light[level=13]
setblock 481 213 302 minecraft:light[level=13]
setblock 481 213 310 minecraft:light[level=13]
fill 489 213 275 489 308 275 minecraft:deepslate_tiles
setblock 489 213 278 minecraft:light[level=13]
setblock 489 213 286 minecraft:light[level=13]
setblock 489 213 294 minecraft:light[level=13]
setblock 489 213 295 minecraft:black_concrete
setblock 489 213 302 minecraft:light[level=13]
setblock 489 213 310 minecraft:light[level=13]
setblock 497 213 278 minecraft:light[level=13]
setblock 497 213 286 minecraft:light[level=13]
setblock 497 213 294 minecraft:light[level=13]
setblock 497 213 302 minecraft:light[level=13]
setblock 497 213 310 minecraft:light[level=13]
setblock 505 213 278 minecraft:light[level=13]
setblock 505 213 286 minecraft:light[level=13]
setblock 505 213 294 minecraft:light[level=13]
setblock 505 213 302 minecraft:light[level=13]
setblock 505 213 310 minecraft:light[level=13]
fill 486 214 297 492 227 297 minecraft:black_concrete
fill 487 214 298 491 227 298 minecraft:black_concrete
fill 489 214 291 489 227 292 minecraft:black_concrete
fill 489 214 296 492 227 296 minecraft:black_concrete
fill 489 214 299 489 227 299 minecraft:black_concrete
fill 490 214 292 491 227 295 minecraft:black_concrete
fill 492 214 293 492 227 295 minecraft:black_concrete
fill 493 214 295 493 227 295 minecraft:black_concrete
setblock 512 214 301 minecraft:white_wool
fill 512 214 302 512 308 302 minecraft:deepslate_tiles
setblock 470 215 279 minecraft:redstone_block
fill 471 215 291 471 217 292 minecraft:black_wool
fill 473 215 305 474 215 305 minecraft:black_wool
fill 479 215 279 479 215 280 minecraft:black_wool
fill 484 215 293 484 227 297 minecraft:black_concrete
fill 485 215 292 485 227 292 minecraft:black_concrete
fill 485 215 296 485 227 298 minecraft:black_concrete
fill 485 215 313 486 217 313 minecraft:black_wool
fill 486 215 291 488 227 291 minecraft:black_concrete
fill 486 215 298 486 227 299 minecraft:black_concrete
fill 487 215 290 491 227 290 minecraft:black_concrete
fill 487 215 299 488 227 300 minecraft:black_concrete
fill 489 215 300 491 227 300 minecraft:black_concrete
fill 490 215 291 492 227 291 minecraft:black_concrete
fill 490 215 299 492 227 299 minecraft:black_concrete
fill 492 215 277 493 217 277 minecraft:black_wool
fill 492 215 292 493 227 292 minecraft:black_concrete
fill 492 215 298 493 227 298 minecraft:black_concrete
fill 493 215 293 494 227 294 minecraft:black_concrete
fill 493 215 296 494 227 297 minecraft:black_concrete
fill 494 215 295 494 227 295 minecraft:black_concrete
fill 497 215 275 498 237 275 minecraft:deepslate_tiles
setblock 499 215 275 minecraft:redstone_block
fill 499 215 310 499 215 311 minecraft:black_wool
fill 504 215 285 505 215 285 minecraft:black_wool
fill 507 215 298 507 217 299 minecraft:black_wool
fill 512 215 301 512 246 301 minecraft:deepslate_tiles
fill 470 216 279 470 265 279 minecraft:deepslate_tiles
fill 471 216 275 471 259 275 minecraft:deepslate_tiles
setblock 472 216 275 minecraft:white_wool
fill 473 216 275 473 308 275 minecraft:deepslate_tiles
fill 474 216 305 474 219 305 minecraft:black_wool
fill 479 216 280 479 219 280 minecraft:black_wool
fill 483 216 293 483 227 297 minecraft:black_concrete
fill 484 216 291 484 227 292 minecraft:black_concrete
fill 484 216 298 484 227 299 minecraft:black_concrete
fill 485 216 290 485 227 291 minecraft:black_concrete
fill 485 216 299 485 227 300 minecraft:black_concrete
fill 486 216 290 486 227 290 minecraft:black_concrete
fill 486 216 300 486 227 300 minecraft:black_concrete
fill 487 216 289 491 227 289 minecraft:black_concrete
fill 487 216 301 491 225 301 minecraft:black_concrete
fill 492 216 290 493 227 290 minecraft:black_concrete
fill 492 216 300 493 227 300 minecraft:black_concrete
fill 493 216 291 494 227 291 minecraft:black_concrete
fill 493 216 299 494 227 299 minecraft:black_concrete
fill 494 216 292 494 227 292 minecraft:black_concrete
fill 494 216 298 494 227 298 minecraft:black_concrete
fill 495 216 293 495 227 297 minecraft:black_concrete
fill 499 216 275 499 224 275 minecraft:deepslate_tiles
fill 499 216 310 499 219 310 minecraft:black_wool
fill 504 216 285 504 219 285 minecraft:black_wool
fill 512 216 276 512 308 276 minecraft:deepslate_tiles
setblock 512 216 277 minecraft:redstone_block
setblock 470 217 307 minecraft:white_wool
fill 472 217 275 472 284 275 minecraft:deepslate_tiles
setblock 473 217 278 minecraft:light[level=12]
setblock 473 217 285 minecraft:light[level=12]
setblock 473 217 292 minecraft:light[level=12]
setblock 473 217 299 minecraft:light[level=12]
setblock 473 217 306 minecraft:light[level=12]
setblock 473 217 313 minecraft:light[level=12]
setblock 480 217 278 minecraft:light[level=12]
setblock 480 217 285 minecraft:light[level=12]
setblock 480 217 292 minecraft:light[level=12]
setblock 480 217 299 minecraft:light[level=12]
setblock 480 217 306 minecraft:light[level=12]
setblock 480 217 313 minecraft:light[level=12]
fill 482 217 294 482 226 296 minecraft:black_concrete
fill 483 217 291 483 226 292 minecraft:black_concrete
fill 483 217 298 483 222 299 minecraft:black_concrete
fill 484 217 290 484 226 290 minecraft:black_concrete
fill 484 217 300 484 226 300 minecraft:black_concrete
fill 485 217 289 486 222 289 minecraft:black_concrete
fill 485 217 301 486 226 301 minecraft:black_concrete
setblock 487 217 278 minecraft:light[level=12]
setblock 487 217 285 minecraft:light[level=12]
setblock 487 217 306 minecraft:light[level=12]
setblock 487 217 313 minecraft:light[level=12]
fill 488 217 288 490 226 288 minecraft:black_concrete
fill 488 217 302 490 226 302 minecraft:black_concrete
fill 492 217 289 493 226 289 minecraft:black_concrete
fill 492 217 301 493 222 301 minecraft:black_concrete
setblock 494 217 278 minecraft:light[level=12]
setblock 494 217 285 minecraft:light[level=12]
fill 494 217 290 494 226 290 minecraft:black_concrete
fill 494 217 300 494 226 300 minecraft:black_concrete
setblock 494 217 306 minecraft:light[level=12]
setblock 494 217 313 minecraft:light[level=12]
fill 495 217 291 495 222 292 minecraft:black_concrete
fill 495 217 298 495 226 299 minecraft:black_concrete
fill 496 217 294 496 226 296 minecraft:black_concrete
setblock 501 217 278 minecraft:light[level=12]
setblock 501 217 285 minecraft:light[level=12]
setblock 501 217 292 minecraft:light[level=12]
setblock 501 217 299 minecraft:light[level=12]
setblock 501 217 306 minecraft:light[level=12]
setblock 501 217 313 minecraft:light[level=12]
setblock 508 217 278 minecraft:light[level=12]
setblock 508 217 285 minecraft:light[level=12]
setblock 508 217 292 minecraft:light[level=12]
setblock 508 217 299 minecraft:light[level=12]
setblock 508 217 306 minecraft:light[level=12]
setblock 508 217 313 minecraft:light[level=12]
fill 512 217 277 512 220 277 minecraft:deepslate_tiles
fill 470 218 302 470 308 302 minecraft:deepslate_tiles
setblock 470 218 303 minecraft:redstone_block
fill 470 218 304 470 246 307 minecraft:deepslate_tiles
fill 472 218 291 472 220 292 minecraft:black_wool
fill 482 218 292 482 225 293 minecraft:black_concrete
fill 482 218 297 482 225 298 minecraft:black_concrete
fill 485 218 312 486 220 312 minecraft:black_wool
fill 486 218 288 487 225 288 minecraft:black_concrete
fill 486 218 302 487 225 302 minecraft:black_concrete
fill 491 218 288 492 225 288 minecraft:black_concrete
fill 491 218 302 492 225 302 minecraft:black_concrete
fill 492 218 278 493 220 278 minecraft:black_wool
fill 496 218 292 496 225 293 minecraft:black_concrete
fill 496 218 297 496 225 298 minecraft:black_concrete
fill 506 218 298 506 220 299 minecraft:black_wool
fill 470 219 303 470 266 303 minecraft:deepslate_tiles
fill 475 219 305 475 221 305 minecraft:black_wool
fill 479 219 281 479 221 281 minecraft:black_wool
fill 481 219 294 481 222 296 minecraft:black_concrete
fill 482 219 291 482 224 291 minecraft:black_concrete
fill 482 219 299 482 222 299 minecraft:black_concrete
fill 483 219 290 483 224 290 minecraft:black_concrete
fill 483 219 300 483 222 300 minecraft:black_concrete
fill 484 219 289 484 222 289 minecraft:black_concrete
fill 484 219 301 484 224 301 minecraft:black_concrete
fill 485 219 288 485 222 288 minecraft:black_concrete
fill 485 219 302 485 224 302 minecraft:black_concrete
fill 488 219 287 490 222 287 minecraft:black_concrete
fill 488 219 303 490 222 303 minecraft:black_concrete
fill 493 219 288 493 224 288 minecraft:black_concrete
fill 493 219 302 493 222 302 minecraft:black_concrete
fill 494 219 289 494 224 289 minecraft:black_concrete
fill 494 219 301 494 222 301 minecraft:black_concrete
fill 495 219 290 495 222 290 minecraft:black_concrete
fill 495 219 300 495 224 300 minecraft:black_concrete
fill 496 219 291 496 222 291 minecraft:black_concrete
fill 496 219 299 496 224 299 minecraft:black_concrete
fill 497 219 294 497 222 296 minecraft:black_concrete
fill 499 219 309 499 221 309 minecraft:black_wool
fill 503 219 285 503 221 285 minecraft:black_wool
fill 475 220 304 475 224 304 minecraft:black_wool
fill 480 220 281 480 224 281 minecraft:black_wool
fill 481 220 293 481 222 293 minecraft:black_concrete
fill 481 220 297 481 223 297 minecraft:black_concrete
fill 487 220 287 487 223 287 minecraft:black_concrete
fill 487 220 303 487 222 303 minecraft:black_concrete
fill 491 220 287 491 222 287 minecraft:black_concrete
fill 491 220 303 491 223 303 minecraft:black_concrete
fill 497 220 293 497 223 293 minecraft:black_concrete
fill 497 220 297 497 222 297 minecraft:black_concrete
fill 498 220 309 498 224 309 minecraft:black_wool
fill 503 220 286 503 224 286 minecraft:black_wool
setblock 471 221 276 minecraft:light_gray_wool
fill 471 221 277 471 221 280 minecraft:white_wool
setblock 471 221 281 minecraft:light_gray_wool
fill 471 221 282 471 221 285 minecraft:white_wool
setblock 471 221 286 minecraft:light_gray_wool
fill 471 221 287 471 221 290 minecraft:white_wool
setblock 471 221 291 minecraft:light_gray_wool
fill 471 221 292 471 221 295 minecraft:white_wool
setblock 471 221 296 minecraft:light_gray_wool
fill 471 221 297 471 221 300 minecraft:white_wool
setblock 471 221 301 minecraft:light_gray_wool
fill 471 221 302 471 221 305 minecraft:white_wool
setblock 471 221 306 minecraft:light_gray_wool
fill 471 221 307 471 221 310 minecraft:white_wool
setblock 471 221 311 minecraft:light_gray_wool
fill 471 221 312 471 221 315 minecraft:white_wool
setblock 471 221 316 minecraft:light_gray_wool
fill 472 221 276 475 221 276 minecraft:white_wool
setblock 472 221 277 minecraft:light_gray_wool
fill 472 221 278 472 221 281 minecraft:white_wool
setblock 472 221 282 minecraft:light_gray_wool
fill 472 221 283 472 221 286 minecraft:white_wool
setblock 472 221 287 minecraft:light_gray_wool
fill 472 221 288 472 221 291 minecraft:white_wool
fill 472 221 292 473 221 292 minecraft:black_wool
fill 472 221 293 472 221 296 minecraft:white_wool
setblock 472 221 297 minecraft:light_gray_wool
fill 472 221 298 472 221 301 minecraft:white_wool
setblock 472 221 302 minecraft:light_gray_wool
fill 472 221 303 472 221 306 minecraft:white_wool
setblock 472 221 307 minecraft:light_gray_wool
fill 472 221 308 472 221 311 minecraft:white_wool
setblock 472 221 312 minecraft:light_gray_wool
fill 472 221 313 472 221 316 minecraft:white_wool
fill 473 221 277 476 221 277 minecraft:white_wool
setblock 473 221 278 minecraft:light_gray_wool
fill 473 221 279 473 221 282 minecraft:white_wool
setblock 473 221 283 minecraft:light_gray_wool
fill 473 221 284 473 221 287 minecraft:white_wool
setblock 473 221 288 minecraft:light_gray_wool
fill 473 221 289 473 221 291 minecraft:white_wool
setblock 473 221 293 minecraft:light_gray_wool
fill 473 221 294 473 221 297 minecraft:white_wool
setblock 473 221 298 minecraft:light_gray_wool
fill 473 221 299 473 221 302 minecraft:white_wool
setblock 473 221 303 minecraft:light_gray_wool
fill 473 221 304 473 221 307 minecraft:white_wool
setblock 473 221 308 minecraft:light_gray_wool
fill 473 221 309 473 221 312 minecraft:white_wool
setblock 473 221 313 minecraft:light_gray_wool
fill 473 221 314 473 221 316 minecraft:white_wool
fill 474 221 278 477 221 278 minecraft:white_wool
setblock 474 221 279 minecraft:light_gray_wool
fill 474 221 280 474 221 283 minecraft:white_wool
setblock 474 221 284 minecraft:light_gray_wool
fill 474 221 285 474 221 288 minecraft:white_wool
setblock 474 221 289 minecraft:light_gray_wool
fill 474 221 290 474 221 293 minecraft:white_wool
setblock 474 221 294 minecraft:light_gray_wool
fill 474 221 295 474 221 298 minecraft:white_wool
setblock 474 221 299 minecraft:light_gray_wool
fill 474 221 300 474 221 303 minecraft:white_wool
setblock 474 221 304 minecraft:light_gray_wool
fill 474 221 305 474 221 308 minecraft:white_wool
setblock 474 221 309 minecraft:light_gray_wool
fill 474 221 310 474 221 313 minecraft:white_wool
setblock 474 221 314 minecraft:light_gray_wool
fill 474 221 315 474 221 316 minecraft:white_wool
fill 475 221 279 478 221 279 minecraft:white_wool
setblock 475 221 280 minecraft:light_gray_wool
fill 475 221 281 475 221 284 minecraft:white_wool
setblock 475 221 285 minecraft:light_gray_wool
fill 475 221 286 475 221 289 minecraft:white_wool
setblock 475 221 290 minecraft:light_gray_wool
fill 475 221 291 475 221 294 minecraft:white_wool
setblock 475 221 295 minecraft:light_gray_wool
fill 475 221 296 475 221 299 minecraft:white_wool
setblock 475 221 300 minecraft:light_gray_wool
fill 475 221 301 475 221 303 minecraft:white_wool
fill 475 221 306 475 221 309 minecraft:white_wool
setblock 475 221 310 minecraft:light_gray_wool
fill 475 221 311 475 221 314 minecraft:white_wool
setblock 475 221 315 minecraft:light_gray_wool
setblock 475 221 316 minecraft:white_wool
setblock 476 221 276 minecraft:light_gray_wool
fill 476 221 280 479 221 280 minecraft:white_wool
setblock 476 221 281 minecraft:light_gray_wool
fill 476 221 282 476 221 285 minecraft:white_wool
setblock 476 221 286 minecraft:light_gray_wool
fill 476 221 287 476 221 290 minecraft:white_wool
setblock 476 221 291 minecraft:light_gray_wool
fill 476 221 292 476 221 295 minecraft:white_wool
setblock 476 221 296 minecraft:light_gray_wool
fill 476 221 297 476 221 300 minecraft:white_wool
setblock 476 221 301 minecraft:light_gray_wool
fill 476 221 302 476 221 305 minecraft:white_wool
setblock 476 221 306 minecraft:light_gray_wool
fill 476 221 307 476 221 310 minecraft:white_wool
setblock 476 221 311 minecraft:light_gray_wool
fill 476 221 312 476 221 315 minecraft:white_wool
setblock 476 221 316 minecraft:light_gray_wool
fill 477 221 276 480 221 276 minecraft:white_wool
setblock 477 221 277 minecraft:light_gray_wool
fill 477 221 281 478 221 281 minecraft:white_wool
setblock 477 221 282 minecraft:light_gray_wool
fill 477 221 283 477 221 286 minecraft:white_wool
setblock 477 221 287 minecraft:light_gray_wool
fill 477 221 288 477 221 291 minecraft:white_wool
setblock 477 221 292 minecraft:light_gray_wool
fill 477 221 293 477 221 296 minecraft:white_wool
setblock 477 221 297 minecraft:light_gray_wool
fill 477 221 298 477 221 301 minecraft:white_wool
setblock 477 221 302 minecraft:light_gray_wool
fill 477 221 303 477 221 306 minecraft:white_wool
setblock 477 221 307 minecraft:light_gray_wool
fill 477 221 308 477 221 311 minecraft:white_wool
setblock 477 221 312 minecraft:light_gray_wool
fill 477 221 313 477 221 316 minecraft:white_wool
fill 478 221 277 481 221 277 minecraft:white_wool
setblock 478 221 278 minecraft:light_gray_wool
fill 478 221 282 481 221 282 minecraft:white_wool
setblock 478 221 283 minecraft:light_gray_wool
fill 478 221 284 478 221 287 minecraft:white_wool
setblock 478 221 288 minecraft:light_gray_wool
fill 478 221 289 478 221 292 minecraft:white_wool
setblock 478 221 293 minecraft:light_gray_wool
fill 478 221 294 478 221 297 minecraft:white_wool
setblock 478 221 298 minecraft:light_gray_wool
fill 478 221 299 478 221 302 minecraft:white_wool
setblock 478 221 303 minecraft:light_gray_wool
fill 478 221 304 478 221 307 minecraft:white_wool
setblock 478 221 308 minecraft:light_gray_wool
fill 478 221 309 478 221 312 minecraft:white_wool
setblock 478 221 313 minecraft:light_gray_wool
fill 478 221 314 478 221 316 minecraft:white_wool
fill 479 221 278 482 221 278 minecraft:white_wool
setblock 479 221 279 minecraft:light_gray_wool
fill 479 221 283 482 221 283 minecraft:white_wool
setblock 479 221 284 minecraft:light_gray_wool
fill 479 221 285 479 221 288 minecraft:white_wool
setblock 479 221 289 minecraft:light_gray_wool
fill 479 221 290 479 221 293 minecraft:white_wool
setblock 479 221 294 minecraft:light_gray_wool
fill 479 221 295 479 221 298 minecraft:white_wool
setblock 479 221 299 minecraft:light_gray_wool
fill 479 221 300 479 221 303 minecraft:white_wool
setblock 479 221 304 minecraft:light_gray_wool
fill 479 221 305 479 221 308 minecraft:white_wool
setblock 479 221 309 minecraft:light_gray_wool
fill 479 221 310 479 221 313 minecraft:white_wool
setblock 479 221 314 minecraft:light_gray_wool
fill 479 221 315 479 221 316 minecraft:white_wool
fill 480 221 279 483 221 279 minecraft:white_wool
setblock 480 221 280 minecraft:light_gray_wool
fill 480 221 284 483 221 284 minecraft:white_wool
setblock 480 221 285 minecraft:light_gray_wool
fill 480 221 286 480 221 289 minecraft:white_wool
setblock 480 221 290 minecraft:light_gray_wool
fill 480 221 291 480 221 294 minecraft:white_wool
setblock 480 221 295 minecraft:light_gray_wool
fill 480 221 296 480 221 299 minecraft:white_wool
setblock 480 221 300 minecraft:light_gray_wool
fill 480 221 301 480 221 304 minecraft:white_wool
setblock 480 221 305 minecraft:light_gray_wool
fill 480 221 306 480 221 309 minecraft:white_wool
setblock 480 221 310 minecraft:light_gray_wool
fill 480 221 311 480 221 314 minecraft:white_wool
setblock 480 221 315 minecraft:light_gray_wool
setblock 480 221 316 minecraft:white_wool
setblock 481 221 276 minecraft:light_gray_wool
fill 481 221 280 484 221 280 minecraft:white_wool
setblock 481 221 281 minecraft:light_gray_wool
fill 481 221 285 484 221 285 minecraft:white_wool
setblock 481 221 286 minecraft:light_gray_wool
fill 481 221 287 481 221 290 minecraft:white_wool
setblock 481 221 291 minecraft:light_gray_wool
setblock 481 221 292 minecraft:white_wool
fill 481 221 298 481 221 300 minecraft:white_wool
setblock 481 221 301 minecraft:light_gray_wool
fill 481 221 302 481 221 305 minecraft:white_wool
setblock 481 221 306 minecraft:light_gray_wool
fill 481 221 307 481 221 310 minecraft:white_wool
setblock 481 221 311 minecraft:light_gray_wool
fill 481 221 312 481 221 315 minecraft:white_wool
setblock 481 221 316 minecraft:light_gray_wool
fill 482 221 276 485 221 276 minecraft:white_wool
setblock 482 221 277 minecraft:light_gray_wool
fill 482 221 281 485 221 281 minecraft:white_wool
setblock 482 221 282 minecraft:light_gray_wool
fill 482 221 286 485 221 286 minecraft:white_wool
setblock 482 221 287 minecraft:light_gray_wool
fill 482 221 288 482 221 290 minecraft:white_wool
fill 482 221 300 482 221 301 minecraft:white_wool
setblock 482 221 302 minecraft:light_gray_wool
fill 482 221 303 482 221 306 minecraft:white_wool
setblock 482 221 307 minecraft:light_gray_wool
fill 482 221 308 482 221 311 minecraft:white_wool
setblock 482 221 312 minecraft:light_gray_wool
fill 482 221 313 482 221 316 minecraft:white_wool
fill 483 221 277 486 221 277 minecraft:white_wool
setblock 483 221 278 minecraft:light_gray_wool
fill 483 221 282 486 221 282 minecraft:white_wool
setblock 483 221 283 minecraft:light_gray_wool
fill 483 221 287 486 221 287 minecraft:white_wool
setblock 483 221 288 minecraft:light_gray_wool
fill 483 221 289 483 222 289 minecraft:black_concrete
fill 483 221 301 483 222 301 minecraft:black_concrete
fill 483 221 302 484 221 302 minecraft:white_wool
setblock 483 221 303 minecraft:light_gray_wool
fill 483 221 304 483 221 307 minecraft:white_wool
setblock 483 221 308 minecraft:light_gray_wool
fill 483 221 309 483 221 312 minecraft:white_wool
setblock 483 221 313 minecraft:light_gray_wool
fill 483 221 314 483 221 316 minecraft:white_wool
fill 484 221 278 487 221 278 minecraft:white_wool
setblock 484 221 279 minecraft:light_gray_wool
fill 484 221 283 487 221 283 minecraft:white_wool
setblock 484 221 284 minecraft:light_gray_wool
setblock 484 221 288 minecraft:white_wool
fill 484 221 303 486 221 303 minecraft:white_wool
setblock 484 221 304 minecraft:light_gray_wool
fill 484 221 305 484 221 308 minecraft:white_wool
setblock 484 221 309 minecraft:light_gray_wool
fill 484 221 310 484 221 313 minecraft:white_wool
setblock 484 221 314 minecraft:light_gray_wool
fill 484 221 315 484 221 316 minecraft:white_wool
fill 485 221 279 488 221 279 minecraft:white_wool
setblock 485 221 280 minecraft:light_gray_wool
fill 485 221 284 488 221 284 minecraft:white_wool
setblock 485 221 285 minecraft:light_gray_wool
fill 485 221 304 488 221 304 minecraft:white_wool
setblock 485 221 305 minecraft:light_gray_wool
fill 485 221 306 485 221 309 minecraft:white_wool
setblock 485 221 310 minecraft:light_gray_wool
fill 485 221 311 485 221 314 minecraft:white_wool
setblock 485 221 315 minecraft:light_gray_wool
setblock 485 221 316 minecraft:white_wool
setblock 486 221 276 minecraft:light_gray_wool
fill 486 221 280 489 221 280 minecraft:white_wool
setblock 486 221 281 minecraft:light_gray_wool
fill 486 221 285 489 221 285 minecraft:white_wool
setblock 486 221 286 minecraft:light_gray_wool
fill 486 221 305 489 221 305 minecraft:white_wool
setblock 486 221 306 minecraft:light_gray_wool
fill 486 221 307 486 221 310 minecraft:white_wool
fill 486 221 311 486 221 312 minecraft:black_wool
fill 486 221 313 487 221 315 minecraft:white_wool
setblock 486 221 316 minecraft:light_gray_wool
fill 487 221 276 490 221 276 minecraft:white_wool
setblock 487 221 277 minecraft:light_gray_wool
fill 487 221 281 490 221 281 minecraft:white_wool
setblock 487 221 282 minecraft:light_gray_wool
fill 487 221 286 490 221 286 minecraft:white_wool
fill 487 221 306 490 221 306 minecraft:white_wool
setblock 487 221 307 minecraft:light_gray_wool
fill 487 221 308 487 221 311 minecraft:white_wool
setblock 487 221 312 minecraft:light_gray_wool
fill 487 221 316 490 221 316 minecraft:white_wool
fill 488 221 277 491 221 277 minecraft:white_wool
setblock 488 221 278 minecraft:light_gray_wool
fill 488 221 282 491 221 282 minecraft:white_wool
setblock 488 221 283 minecraft:light_gray_wool
fill 488 221 307 491 221 307 minecraft:white_wool
setblock 488 221 308 minecraft:light_gray_wool
fill 488 221 309 488 221 312 minecraft:white_wool
setblock 488 221 313 minecraft:light_gray_wool
fill 488 221 314 488 221 315 minecraft:white_wool
fill 489 221 278 491 221 278 minecraft:white_wool
setblock 489 221 279 minecraft:light_gray_wool
fill 489 221 283 492 221 283 minecraft:white_wool
setblock 489 221 284 minecraft:light_gray_wool
setblock 489 221 304 minecraft:light_gray_wool
fill 489 221 308 492 221 308 minecraft:white_wool
setblock 489 221 309 minecraft:light_gray_wool
fill 489 221 310 489 221 313 minecraft:white_wool
setblock 489 221 314 minecraft:light_gray_wool
setblock 489 221 315 minecraft:white_wool
fill 490 221 279 491 221 279 minecraft:white_wool
setblock 490 221 280 minecraft:light_gray_wool
fill 490 221 284 493 221 284 minecraft:white_wool
setblock 490 221 285 minecraft:light_gray_wool
fill 490 221 304 493 221 304 minecraft:white_wool
setblock 490 221 305 minecraft:light_gray_wool
fill 490 221 309 493 221 309 minecraft:white_wool
setblock 490 221 310 minecraft:light_gray_wool
fill 490 221 311 490 221 314 minecraft:white_wool
setblock 490 221 315 minecraft:light_gray_wool
setblock 491 221 276 minecraft:light_gray_wool
fill 491 221 280 494 221 280 minecraft:white_wool
setblock 491 221 281 minecraft:light_gray_wool
fill 491 221 285 494 221 285 minecraft:white_wool
setblock 491 221 286 minecraft:light_gray_wool
fill 491 221 305 494 221 305 minecraft:white_wool
setblock 491 221 306 minecraft:light_gray_wool
fill 491 221 310 494 221 310 minecraft:white_wool
setblock 491 221 311 minecraft:light_gray_wool
fill 491 221 312 491 221 315 minecraft:white_wool
setblock 491 221 316 minecraft:light_gray_wool
fill 492 221 276 495 221 276 minecraft:white_wool
setblock 492 221 277 minecraft:light_gray_wool
fill 492 221 278 492 221 279 minecraft:black_wool
fill 492 221 281 495 221 281 minecraft:white_wool
setblock 492 221 282 minecraft:light_gray_wool
fill 492 221 286 495 221 286 minecraft:white_wool
setblock 492 221 287 minecraft:light_gray_wool
setblock 492 221 303 minecraft:white_wool
fill 492 221 306 495 221 306 minecraft:white_wool
setblock 492 221 307 minecraft:light_gray_wool
fill 492 221 311 495 221 311 minecraft:white_wool
setblock 492 221 312 minecraft:light_gray_wool
fill 492 221 313 492 221 316 minecraft:white_wool
fill 493 221 277 496 221 277 minecraft:white_wool
setblock 493 221 278 minecraft:light_gray_wool
setblock 493 221 279 minecraft:white_wool
fill 493 221 282 496 221 282 minecraft:white_wool
setblock 493 221 283 minecraft:light_gray_wool
fill 493 221 287 496 221 287 minecraft:white_wool
setblock 493 221 303 minecraft:light_gray_wool
fill 493 221 307 496 221 307 minecraft:white_wool
setblock 493 221 308 minecraft:light_gray_wool
fill 493 221 312 496 221 312 minecraft:white_wool
setblock 493 221 313 minecraft:light_gray_wool
fill 493 221 314 493 221 316 minecraft:white_wool
fill 494 221 278 497 221 278 minecraft:white_wool
setblock 494 221 279 minecraft:light_gray_wool
fill 494 221 283 497 221 283 minecraft:white_wool
setblock 494 221 284 minecraft:light_gray_wool
fill 494 221 288 497 221 288 minecraft:white_wool
fill 494 221 302 496 221 303 minecraft:white_wool
setblock 494 221 304 minecraft:light_gray_wool
fill 494 221 308 497 221 308 minecraft:white_wool
setblock 494 221 309 minecraft:light_gray_wool
fill 494 221 313 497 221 313 minecraft:white_wool
setblock 494 221 314 minecraft:light_gray_wool
fill 494 221 315 494 221 316 minecraft:white_wool
fill 495 221 279 498 221 279 minecraft:white_wool
setblock 495 221 280 minecraft:light_gray_wool
fill 495 221 284 498 221 284 minecraft:white_wool
setblock 495 221 285 minecraft:light_gray_wool
fill 495 221 289 495 222 289 minecraft:black_concrete
fill 495 221 301 495 222 301 minecraft:black_concrete
fill 495 221 304 498 221 304 minecraft:white_wool
setblock 495 221 305 minecraft:light_gray_wool
fill 495 221 309 497 221 309 minecraft:white_wool
setblock 495 221 310 minecraft:light_gray_wool
fill 495 221 314 498 221 314 minecraft:white_wool
setblock 495 221 315 minecraft:light_gray_wool
setblock 495 221 316 minecraft:white_wool
setblock 496 221 276 minecraft:light_gray_wool
fill 496 221 280 499 221 280 minecraft:white_wool
setblock 496 221 281 minecraft:light_gray_wool
fill 496 221 285 499 221 285 minecraft:white_wool
setblock 496 221 286 minecraft:light_gray_wool
fill 496 221 289 498 221 290 minecraft:white_wool
fill 496 221 300 499 221 300 minecraft:white_wool
setblock 496 221 301 minecraft:light_gray_wool
fill 496 221 305 499 221 305 minecraft:white_wool
setblock 496 221 306 minecraft:light_gray_wool
fill 496 221 310 499 221 310 minecraft:white_wool
setblock 496 221 311 minecraft:light_gray_wool
fill 496 221 315 499 221 315 minecraft:white_wool
setblock 496 221 316 minecraft:light_gray_wool
fill 497 221 276 500 221 276 minecraft:white_wool
setblock 497 221 277 minecraft:light_gray_wool
fill 497 221 281 500 221 281 minecraft:white_wool
setblock 497 221 282 minecraft:light_gray_wool
fill 497 221 286 500 221 286 minecraft:white_wool
setblock 497 221 287 minecraft:light_gray_wool
fill 497 221 291 500 221 291 minecraft:white_wool
setblock 497 221 292 minecraft:light_gray_wool
fill 497 221 298 497 221 299 minecraft:white_wool
fill 497 221 301 500 221 301 minecraft:white_wool
setblock 497 221 302 minecraft:light_gray_wool
setblock 497 221 303 minecraft:white_wool
fill 497 221 306 500 221 306 minecraft:white_wool
setblock 497 221 307 minecraft:light_gray_wool
fill 497 221 311 500 221 311 minecraft:white_wool
setblock 497 221 312 minecraft:light_gray_wool
fill 497 221 316 500 221 316 minecraft:white_wool
fill 498 221 277 501 221 277 minecraft:white_wool
setblock 498 221 278 minecraft:light_gray_wool
fill 498 221 282 501 221 282 minecraft:white_wool
setblock 498 221 283 minecraft:light_gray_wool
fill 498 221 287 501 221 287 minecraft:white_wool
setblock 498 221 288 minecraft:light_gray_wool
fill 498 221 292 501 221 292 minecraft:white_wool
setblock 498 221 293 minecraft:light_gray_wool
fill 498 221 294 498 221 297 minecraft:white_wool
setblock 498 221 298 minecraft:light_gray_wool
setblock 498 221 299 minecraft:white_wool
fill 498 221 302 501 221 302 minecraft:white_wool
setblock 498 221 303 minecraft:light_gray_wool
fill 498 221 307 501 221 307 minecraft:white_wool
setblock 498 221 308 minecraft:light_gray_wool
fill 498 221 312 501 221 312 minecraft:white_wool
setblock 498 221 313 minecraft:light_gray_wool
fill 499 221 278 502 221 278 minecraft:white_wool
setblock 499 221 279 minecraft:light_gray_wool
fill 499 221 283 502 221 283 minecraft:white_wool
setblock 499 221 284 minecraft:light_gray_wool
fill 499 221 288 502 221 288 minecraft:white_wool
setblock 499 221 289 minecraft:light_gray_wool
setblock 499 221 290 minecraft:white_wool
fill 499 221 293 502 221 293 minecraft:white_wool
setblock 499 221 294 minecraft:light_gray_wool
fill 499 221 295 499 221 298 minecraft:white_wool
setblock 499 221 299 minecraft:light_gray_wool
fill 499 221 303 502 221 303 minecraft:white_wool
setblock 499 221 304 minecraft:light_gray_wool
fill 499 221 308 502 221 308 minecraft:white_wool
fill 499 221 313 502 221 313 minecraft:white_wool
setblock 499 221 314 minecraft:light_gray_wool
fill 500 221 279 503 221 279 minecraft:white_wool
setblock 500 221 280 minecraft:light_gray_wool
fill 500 221 284 503 221 284 minecraft:white_wool
setblock 500 221 285 minecraft:light_gray_wool
fill 500 221 289 503 221 289 minecraft:white_wool
setblock 500 221 290 minecraft:light_gray_wool
fill 500 221 294 503 221 294 minecraft:white_wool
setblock 500 221 295 minecraft:light_gray_wool
fill 500 221 296 500 221 299 minecraft:white_wool
setblock 500 221 300 minecraft:light_gray_wool
fill 500 221 304 503 221 304 minecraft:white_wool
setblock 500 221 305 minecraft:light_gray_wool
fill 500 221 309 503 221 309 minecraft:white_wool
setblock 500 221 310 minecraft:light_gray_wool
fill 500 221 314 503 221 314 minecraft:white_wool
setblock 500 221 315 minecraft:light_gray_wool
setblock 501 221 276 minecraft:light_gray_wool
fill 501 221 280 504 221 280 minecraft:white_wool
setblock 501 221 281 minecraft:light_gray_wool
fill 501 221 285 502 221 285 minecraft:white_wool
setblock 501 221 286 minecraft:light_gray_wool
fill 501 221 290 504 221 290 minecraft:white_wool
setblock 501 221 291 minecraft:light_gray_wool
fill 501 221 295 504 221 295 minecraft:white_wool
setblock 501 221 296 minecraft:light_gray_wool
fill 501 221 297 501 221 300 minecraft:white_wool
setblock 501 221 301 minecraft:light_gray_wool
fill 501 221 305 504 221 305 minecraft:white_wool
setblock 501 221 306 minecraft:light_gray_wool
fill 501 221 310 504 221 310 minecraft:white_wool
setblock 501 221 311 minecraft:light_gray_wool
fill 501 221 315 504 221 315 minecraft:white_wool
setblock 501 221 316 minecraft:light_gray_wool
fill 502 221 276 505 221 276 minecraft:white_wool
setblock 502 221 277 minecraft:light_gray_wool
fill 502 221 281 505 221 281 minecraft:white_wool
setblock 502 221 282 minecraft:light_gray_wool
setblock 502 221 286 minecraft:white_wool
setblock 502 221 287 minecraft:light_gray_wool
fill 502 221 291 505 221 291 minecraft:white_wool
setblock 502 221 292 minecraft:light_gray_wool
fill 502 221 296 505 221 296 minecraft:white_wool
setblock 502 221 297 minecraft:light_gray_wool
fill 502 221 298 502 221 301 minecraft:white_wool
setblock 502 221 302 minecraft:light_gray_wool
fill 502 221 306 505 221 306 minecraft:white_wool
setblock 502 221 307 minecraft:light_gray_wool
fill 502 221 311 505 221 311 minecraft:white_wool
setblock 502 221 312 minecraft:light_gray_wool
fill 502 221 316 505 221 316 minecraft:white_wool
fill 503 221 277 506 221 277 minecraft:white_wool
setblock 503 221 278 minecraft:light_gray_wool
fill 503 221 282 506 221 282 minecraft:white_wool
setblock 503 221 283 minecraft:light_gray_wool
fill 503 221 287 506 221 287 minecraft:white_wool
setblock 503 221 288 minecraft:light_gray_wool
fill 503 221 292 506 221 292 minecraft:white_wool
setblock 503 221 293 minecraft:light_gray_wool
fill 503 221 297 506 221 297 minecraft:white_wool
setblock 503 221 298 minecraft:light_gray_wool
fill 503 221 299 503 221 302 minecraft:white_wool
setblock 503 221 303 minecraft:light_gray_wool
fill 503 221 307 506 221 307 minecraft:white_wool
setblock 503 221 308 minecraft:light_gray_wool
fill 503 221 312 506 221 312 minecraft:white_wool
setblock 503 221 313 minecraft:light_gray_wool
fill 504 221 278 507 221 278 minecraft:white_wool
setblock 504 221 279 minecraft:light_gray_wool
fill 504 221 283 507 221 283 minecraft:white_wool
setblock 504 221 284 minecraft:light_gray_wool
fill 504 221 285 504 221 286 minecraft:white_wool
fill 504 221 288 507 221 288 minecraft:white_wool
setblock 504 221 289 minecraft:light_gray_wool
fill 504 221 293 507 221 293 minecraft:white_wool
setblock 504 221 294 minecraft:light_gray_wool
setblock 504 221 298 minecraft:white_wool
setblock 504 221 299 minecraft:light_gray_wool
fill 504 221 300 504 221 303 minecraft:white_wool
setblock 504 221 304 minecraft:light_gray_wool
fill 504 221 308 507 221 308 minecraft:white_wool
setblock 504 221 309 minecraft:light_gray_wool
fill 504 221 313 507 221 313 minecraft:white_wool
setblock 504 221 314 minecraft:light_gray_wool
fill 505 221 279 508 221 279 minecraft:white_wool
setblock 505 221 280 minecraft:light_gray_wool
fill 505 221 284 508 221 284 minecraft:white_wool
setblock 505 221 285 minecraft:light_gray_wool
setblock 505 221 286 minecraft:white_wool
fill 505 221 289 508 221 289 minecraft:white_wool
setblock 505 221 290 minecraft:light_gray_wool
fill 505 221 294 508 221 294 minecraft:white_wool
setblock 505 221 295 minecraft:light_gray_wool
fill 505 221 298 506 221 298 minecraft:black_wool
fill 505 221 299 508 221 299 minecraft:white_wool
setblock 505 221 300 minecraft:light_gray_wool
fill 505 221 301 505 221 304 minecraft:white_wool
setblock 505 221 305 minecraft:light_gray_wool
fill 505 221 309 508 221 309 minecraft:white_wool
setblock 505 221 310 minecraft:light_gray_wool
fill 505 221 314 508 221 314 minecraft:white_wool
setblock 505 221 315 minecraft:light_gray_wool
setblock 506 221 276 minecraft:light_gray_wool
fill 506 221 280 509 221 280 minecraft:white_wool
setblock 506 221 281 minecraft:light_gray_wool
fill 506 221 285 509 221 285 minecraft:white_wool
setblock 506 221 286 minecraft:light_gray_wool
fill 506 221 290 509 221 290 minecraft:white_wool
setblock 506 221 291 minecraft:light_gray_wool
fill 506 221 295 509 221 295 minecraft:white_wool
setblock 506 221 296 minecraft:light_gray_wool
fill 506 221 300 509 221 300 minecraft:white_wool
setblock 506 221 301 minecraft:light_gray_wool
fill 506 221 302 506 221 305 minecraft:white_wool
setblock 506 221 306 minecraft:light_gray_wool
fill 506 221 310 509 221 310 minecraft:white_wool
setblock 506 221 311 minecraft:light_gray_wool
fill 506 221 315 509 221 315 minecraft:white_wool
setblock 506 221 316 minecraft:light_gray_wool
fill 507 221 276 510 221 276 minecraft:white_wool
setblock 507 221 277 minecraft:light_gray_wool
fill 507 221 281 510 221 281 minecraft:white_wool
setblock 507 221 282 minecraft:light_gray_wool
fill 507 221 286 510 221 286 minecraft:white_wool
setblock 507 221 287 minecraft:light_gray_wool
fill 507 221 291 510 221 291 minecraft:white_wool
setblock 507 221 292 minecraft:light_gray_wool
fill 507 221 296 510 221 296 minecraft:white_wool
setblock 507 221 297 minecraft:light_gray_wool
setblock 507 221 298 minecraft:white_wool
fill 507 221 301 510 221 301 minecraft:white_wool
setblock 507 221 302 minecraft:light_gray_wool
fill 507 221 303 507 221 306 minecraft:white_wool
setblock 507 221 307 minecraft:light_gray_wool
fill 507 221 311 510 221 311 minecraft:white_wool
setblock 507 221 312 minecraft:light_gray_wool
fill 507 221 316 510 221 316 minecraft:white_wool
fill 508 221 277 511 221 277 minecraft:white_wool
setblock 508 221 278 minecraft:light_gray_wool
fill 508 221 282 511 221 282 minecraft:white_wool
setblock 508 221 283 minecraft:light_gray_wool
fill 508 221 287 511 221 287 minecraft:white_wool
setblock 508 221 288 minecraft:light_gray_wool
fill 508 221 292 511 221 292 minecraft:white_wool
setblock 508 221 293 minecraft:light_gray_wool
fill 508 221 297 511 221 297 minecraft:white_wool
setblock 508 221 298 minecraft:light_gray_wool
fill 508 221 302 511 221 302 minecraft:white_wool
setblock 508 221 303 minecraft:light_gray_wool
fill 508 221 304 508 221 307 minecraft:white_wool
setblock 508 221 308 minecraft:light_gray_wool
fill 508 221 312 511 221 312 minecraft:white_wool
setblock 508 221 313 minecraft:light_gray_wool
fill 509 221 278 511 221 278 minecraft:white_wool
setblock 509 221 279 minecraft:light_gray_wool
fill 509 221 283 511 221 283 minecraft:white_wool
setblock 509 221 284 minecraft:light_gray_wool
fill 509 221 288 511 221 288 minecraft:white_wool
setblock 509 221 289 minecraft:light_gray_wool
fill 509 221 293 511 221 293 minecraft:white_wool
setblock 509 221 294 minecraft:light_gray_wool
fill 509 221 298 511 221 298 minecraft:white_wool
setblock 509 221 299 minecraft:light_gray_wool
fill 509 221 303 511 221 303 minecraft:white_wool
setblock 509 221 304 minecraft:light_gray_wool
fill 509 221 305 509 221 308 minecraft:white_wool
setblock 509 221 309 minecraft:light_gray_wool
fill 509 221 313 511 221 313 minecraft:white_wool
setblock 509 221 314 minecraft:light_gray_wool
fill 510 221 279 511 221 279 minecraft:white_wool
setblock 510 221 280 minecraft:light_gray_wool
fill 510 221 284 511 221 284 minecraft:white_wool
setblock 510 221 285 minecraft:light_gray_wool
fill 510 221 289 511 221 289 minecraft:white_wool
setblock 510 221 290 minecraft:light_gray_wool
fill 510 221 294 511 221 294 minecraft:white_wool
setblock 510 221 295 minecraft:light_gray_wool
fill 510 221 299 511 221 299 minecraft:white_wool
setblock 510 221 300 minecraft:light_gray_wool
fill 510 221 304 511 221 304 minecraft:white_wool
setblock 510 221 305 minecraft:light_gray_wool
fill 510 221 306 510 221 309 minecraft:white_wool
setblock 510 221 310 minecraft:light_gray_wool
fill 510 221 314 511 221 314 minecraft:white_wool
setblock 510 221 315 minecraft:light_gray_wool
setblock 511 221 276 minecraft:light_gray_wool
setblock 511 221 280 minecraft:white_wool
setblock 511 221 281 minecraft:light_gray_wool
setblock 511 221 285 minecraft:white_wool
setblock 511 221 286 minecraft:light_gray_wool
setblock 511 221 290 minecraft:white_wool
setblock 511 221 291 minecraft:light_gray_wool
setblock 511 221 295 minecraft:white_wool
setblock 511 221 296 minecraft:light_gray_wool
setblock 511 221 300 minecraft:white_wool
setblock 511 221 301 minecraft:light_gray_wool
setblock 511 221 305 minecraft:white_wool
setblock 511 221 306 minecraft:light_gray_wool
fill 511 221 307 511 221 310 minecraft:white_wool
setblock 511 221 311 minecraft:light_gray_wool
setblock 511 221 315 minecraft:white_wool
setblock 511 221 316 minecraft:light_gray_wool
setblock 512 221 277 minecraft:redstone_block
fill 473 222 292 473 225 292 minecraft:black_wool
fill 486 222 311 486 225 311 minecraft:black_wool
fill 492 222 279 492 225 279 minecraft:black_wool
fill 505 222 298 505 225 298 minecraft:black_wool
setblock 507 222 275 minecraft:white_wool
fill 512 222 277 512 308 277 minecraft:deepslate_tiles
setblock 470 223 280 minecraft:white_wool
setblock 473 223 278 minecraft:light[level=12]
setblock 473 223 285 minecraft:light[level=12]
setblock 473 223 299 minecraft:light[level=12]
setblock 473 223 306 minecraft:light[level=12]
setblock 473 223 313 minecraft:light[level=12]
fill 476 223 304 476 228 304 minecraft:black_wool
setblock 480 223 278 minecraft:light[level=12]
fill 480 223 282 480 228 282 minecraft:black_wool
setblock 480 223 285 minecraft:light[level=12]
setblock 480 223 292 minecraft:light[level=12]
fill 480 223 293 481 224 293 minecraft:black_wool
setblock 480 223 299 minecraft:light[level=12]
setblock 480 223 306 minecraft:light[level=12]
setblock 480 223 313 minecraft:light[level=12]
setblock 481 223 294 minecraft:black_wool
fill 481 223 295 481 224 296 minecraft:black_concrete
fill 481 223 300 483 223 300 minecraft:black_wool
fill 482 223 299 483 223 299 minecraft:black_wool
fill 483 223 298 483 226 298 minecraft:black_concrete
fill 484 223 287 484 223 289 minecraft:black_wool
fill 485 223 288 485 223 289 minecraft:black_wool
fill 486 223 289 486 226 289 minecraft:black_concrete
setblock 487 223 278 minecraft:light[level=12]
setblock 487 223 285 minecraft:light[level=12]
fill 487 223 303 487 224 304 minecraft:black_wool
setblock 487 223 306 minecraft:light[level=12]
setblock 487 223 313 minecraft:light[level=12]
fill 488 223 287 489 224 287 minecraft:black_concrete
setblock 488 223 303 minecraft:black_wool
fill 489 223 303 490 224 303 minecraft:black_concrete
fill 490 223 287 491 223 287 minecraft:black_wool
fill 491 223 286 491 224 286 minecraft:black_wool
fill 492 223 301 492 226 301 minecraft:black_concrete
fill 493 223 301 494 223 302 minecraft:black_wool
setblock 494 223 278 minecraft:light[level=12]
setblock 494 223 285 minecraft:light[level=12]
fill 494 223 303 494 225 303 minecraft:black_wool
setblock 494 223 306 minecraft:light[level=12]
setblock 494 223 313 minecraft:light[level=12]
fill 495 223 290 496 223 291 minecraft:black_wool
fill 495 223 292 495 226 292 minecraft:black_concrete
fill 497 223 290 497 225 290 minecraft:black_wool
fill 497 223 294 497 224 295 minecraft:black_concrete
fill 497 223 296 497 223 297 minecraft:black_wool
fill 498 223 297 498 224 297 minecraft:black_wool
fill 498 223 308 498 228 308 minecraft:black_wool
setblock 501 223 278 minecraft:light[level=12]
setblock 501 223 285 minecraft:light[level=12]
setblock 501 223 292 minecraft:light[level=12]
setblock 501 223 299 minecraft:light[level=12]
setblock 501 223 306 minecraft:light[level=12]
setblock 501 223 313 minecraft:light[level=12]
fill 502 223 286 502 228 286 minecraft:black_wool
fill 507 223 275 507 308 275 minecraft:deepslate_tiles
fill 507 223 317 508 263 317 minecraft:deepslate_tiles
setblock 508 223 278 minecraft:light[level=12]
setblock 508 223 285 minecraft:light[level=12]
setblock 508 223 292 minecraft:light[level=12]
setblock 508 223 299 minecraft:light[level=12]
setblock 508 223 306 minecraft:light[level=12]
setblock 508 223 313 minecraft:light[level=12]
setblock 509 223 317 minecraft:redstone_block
fill 510 223 317 510 225 317 minecraft:deepslate_tiles
fill 470 224 280 470 308 280 minecraft:deepslate_tiles
fill 479 224 293 479 225 293 minecraft:black_wool
setblock 480 224 294 minecraft:black_wool
fill 480 224 301 481 225 301 minecraft:black_wool
setblock 481 224 294 minecraft:black_concrete
fill 481 224 300 482 224 300 minecraft:black_wool
fill 482 224 299 483 224 299 minecraft:black_concrete
fill 483 224 286 483 225 287 minecraft:black_wool
setblock 483 224 300 minecraft:black_concrete
fill 484 224 287 484 224 288 minecraft:black_wool
fill 484 224 289 485 224 289 minecraft:black_concrete
setblock 485 224 288 minecraft:black_concrete
fill 487 224 305 487 225 305 minecraft:black_wool
setblock 488 224 303 minecraft:black_concrete
setblock 488 224 304 minecraft:black_wool
setblock 490 224 286 minecraft:black_wool
setblock 490 224 287 minecraft:black_concrete
fill 491 224 285 491 225 285 minecraft:black_wool
setblock 491 224 287 minecraft:black_wool
fill 493 224 301 493 224 302 minecraft:black_concrete
setblock 494 224 301 minecraft:black_concrete
setblock 494 224 302 minecraft:black_wool
fill 495 224 290 495 224 291 minecraft:black_concrete
fill 495 224 303 495 225 304 minecraft:black_wool
setblock 496 224 290 minecraft:black_wool
setblock 496 224 291 minecraft:black_concrete
fill 497 224 289 498 225 289 minecraft:black_wool
setblock 497 224 296 minecraft:black_concrete
setblock 497 224 297 minecraft:black_wool
setblock 498 224 296 minecraft:black_wool
fill 499 224 297 499 225 297 minecraft:black_wool
fill 509 224 317 509 308 317 minecraft:deepslate_tiles
fill 470 225 291 470 308 292 minecraft:deepslate_tiles
setblock 470 225 293 minecraft:redstone_block
fill 470 225 294 470 230 294 minecraft:deepslate_tiles
fill 474 225 292 474 228 292 minecraft:black_wool
fill 477 225 293 478 226 293 minecraft:black_wool
fill 478 225 292 478 226 292 minecraft:black_wool
fill 479 225 301 479 226 302 minecraft:black_wool
fill 480 225 300 481 225 300 minecraft:black_wool
fill 482 225 285 483 226 285 minecraft:black_wool
fill 483 225 299 483 226 299 minecraft:black_concrete
fill 484 225 286 484 225 287 minecraft:black_wool
fill 485 225 289 485 226 289 minecraft:black_concrete
fill 486 225 306 487 226 306 minecraft:black_wool
fill 486 225 310 486 228 310 minecraft:black_wool
fill 487 225 307 487 226 307 minecraft:black_wool
fill 491 225 283 491 226 284 minecraft:black_wool
fill 492 225 280 492 228 280 minecraft:black_wool
fill 492 225 284 492 226 284 minecraft:black_wool
fill 493 225 301 493 226 301 minecraft:black_concrete
setblock 494 225 304 minecraft:black_wool
fill 495 225 291 495 226 291 minecraft:black_concrete
fill 495 225 305 496 226 305 minecraft:black_wool
setblock 498 225 290 minecraft:black_wool
setblock 499 225 275 minecraft:redstone_block
fill 499 225 288 499 226 289 minecraft:black_wool
fill 500 225 297 500 226 298 minecraft:black_wool
fill 501 225 297 501 226 297 minecraft:black_wool
fill 504 225 298 504 228 298 minecraft:black_wool
fill 470 226 293 470 308 293 minecraft:deepslate_tiles
fill 476 226 292 476 227 293 minecraft:black_wool
fill 476 226 303 476 228 303 minecraft:black_wool
setblock 477 226 292 minecraft:black_wool
fill 478 226 302 478 227 302 minecraft:black_wool
setblock 480 226 301 minecraft:black_wool
fill 481 226 282 481 228 282 minecraft:black_wool
fill 482 226 284 482 227 284 minecraft:black_wool
setblock 483 226 286 minecraft:black_wool
fill 486 226 307 486 226 308 minecraft:black_wool
fill 487 226 301 487 227 302 minecraft:redstone_block
fill 487 226 308 487 227 308 minecraft:black_wool
fill 488 226 301 490 227 301 minecraft:black_concrete
fill 491 226 282 492 227 282 minecraft:black_wool
fill 491 226 301 491 227 302 minecraft:redstone_block
setblock 492 226 283 minecraft:black_wool
setblock 495 226 304 minecraft:black_wool
fill 496 226 306 496 227 306 minecraft:black_wool
fill 497 226 308 497 228 308 minecraft:black_wool
setblock 498 226 289 minecraft:black_wool
fill 499 226 275 499 308 275 minecraft:deepslate_tiles
fill 500 226 288 500 227 288 minecraft:black_wool
fill 501 226 298 502 226 298 minecraft:black_wool
fill 502 226 287 502 228 287 minecraft:black_wool
fill 502 226 297 502 227 297 minecraft:black_wool
setblock 510 226 317 minecraft:white_wool
fill 475 227 292 475 227 293 minecraft:black_wool
fill 477 227 302 477 227 303 minecraft:black_wool
setblock 478 227 303 minecraft:black_wool
setblock 479 227 302 minecraft:black_wool
fill 481 227 283 481 227 284 minecraft:black_wool
setblock 482 227 283 minecraft:black_wool
setblock 482 227 285 minecraft:black_wool
fill 486 227 308 486 227 309 minecraft:black_wool
setblock 487 227 309 minecraft:black_wool
fill 491 227 281 492 227 281 minecraft:black_wool
setblock 496 227 305 minecraft:black_wool
fill 496 227 307 497 227 307 minecraft:black_wool
setblock 497 227 306 minecraft:black_wool
setblock 499 227 288 minecraft:black_wool
fill 500 227 287 501 227 287 minecraft:black_wool
setblock 501 227 288 minecraft:black_wool
fill 502 227 298 503 227 298 minecraft:black_wool
setblock 503 227 297 minecraft:black_wool
fill 510 227 317 510 308 317 minecraft:deepslate_tiles
fill 471 228 276 473 228 316 minecraft:black_stained_glass
fill 474 228 276 474 228 291 minecraft:black_stained_glass
setblock 474 228 293 minecraft:black_stained_glass
fill 474 228 294 482 229 294 minecraft:iron_block
fill 474 228 295 474 228 316 minecraft:black_stained_glass
fill 475 228 276 475 228 288 minecraft:black_stained_glass
fill 475 228 289 499 229 289 minecraft:iron_block
fill 475 228 290 475 228 291 minecraft:black_stained_glass
setblock 475 228 292 minecraft:black_wool
fill 475 228 293 475 229 293 minecraft:iron_block
fill 475 228 295 475 229 295 minecraft:iron_block
fill 475 228 296 475 228 298 minecraft:black_stained_glass
fill 475 228 299 499 229 299 minecraft:iron_block
fill 475 228 300 475 228 316 minecraft:black_stained_glass
fill 476 228 276 478 228 287 minecraft:black_stained_glass
fill 476 228 288 498 229 288 minecraft:iron_block
fill 476 228 290 486 229 290 minecraft:iron_block
fill 476 228 291 476 228 293 minecraft:black_stained_glass
fill 476 228 295 476 228 297 minecraft:black_stained_glass
fill 476 228 298 486 229 298 minecraft:iron_block
fill 476 228 300 498 229 300 minecraft:iron_block
fill 476 228 301 478 228 302 minecraft:black_stained_glass
fill 476 228 305 483 228 316 minecraft:black_stained_glass
fill 477 228 291 483 229 293 minecraft:iron_block
fill 477 228 295 483 229 297 minecraft:iron_block
fill 477 228 303 477 228 304 minecraft:black_wool
fill 478 228 303 478 228 304 minecraft:black_stained_glass
fill 479 228 276 479 228 283 minecraft:black_stained_glass
fill 479 228 284 480 229 285 minecraft:iron_block
setblock 479 228 286 minecraft:black_stained_glass
fill 479 228 287 495 229 287 minecraft:iron_block
fill 479 228 301 495 229 301 minecraft:iron_block
setblock 479 228 302 minecraft:black_stained_glass
fill 479 228 303 480 229 304 minecraft:iron_block
fill 480 228 276 491 228 281 minecraft:black_stained_glass
fill 480 228 283 481 228 283 minecraft:black_wool
fill 480 228 286 494 229 286 minecraft:iron_block
fill 480 228 302 494 229 302 minecraft:iron_block
fill 481 228 284 482 228 284 minecraft:black_stained_glass
fill 481 228 285 495 229 285 minecraft:iron_block
fill 481 228 303 495 229 303 minecraft:iron_block
fill 481 228 304 482 228 304 minecraft:black_stained_glass
fill 482 228 282 483 228 283 minecraft:black_stained_glass
fill 483 228 284 491 229 284 minecraft:iron_block
fill 483 228 294 484 228 294 minecraft:waxed_copper_block
fill 483 228 304 491 229 304 minecraft:iron_block
fill 484 228 282 485 229 283 minecraft:iron_block
fill 484 228 291 484 229 291 minecraft:iron_block
fill 484 228 292 484 229 293 minecraft:waxed_copper_block
fill 484 228 295 484 229 296 minecraft:waxed_copper_block
fill 484 228 297 484 229 297 minecraft:iron_block
fill 484 228 305 485 229 306 minecraft:iron_block
fill 484 228 307 485 228 316 minecraft:black_stained_glass
fill 485 228 291 485 228 292 minecraft:waxed_copper_block
fill 485 228 296 485 228 297 minecraft:waxed_copper_block
fill 486 228 282 486 228 283 minecraft:black_stained_glass
fill 486 228 291 489 228 291 minecraft:waxed_copper_block
fill 486 228 297 489 228 297 minecraft:waxed_copper_block
fill 486 228 305 486 228 308 minecraft:black_stained_glass
setblock 486 228 309 minecraft:black_wool
fill 486 228 311 511 228 316 minecraft:black_stained_glass
fill 487 228 282 488 228 282 minecraft:black_stained_glass
fill 487 228 283 487 229 283 minecraft:iron_block
fill 487 228 290 487 230 290 minecraft:waxed_copper_block
fill 487 228 298 487 230 298 minecraft:waxed_copper_block
fill 487 228 305 487 229 305 minecraft:iron_block
fill 487 228 306 488 228 310 minecraft:black_stained_glass
setblock 488 228 283 minecraft:black_stained_glass
fill 488 228 290 498 229 290 minecraft:iron_block
fill 488 228 298 498 229 298 minecraft:iron_block
setblock 488 228 305 minecraft:black_stained_glass
fill 489 228 282 490 229 283 minecraft:iron_block
fill 489 228 292 490 228 292 minecraft:waxed_copper_block
fill 489 228 296 490 228 296 minecraft:waxed_copper_block
fill 489 228 305 490 229 306 minecraft:iron_block
fill 489 228 307 496 228 310 minecraft:black_stained_glass
fill 490 228 291 497 229 291 minecraft:iron_block
fill 490 228 293 490 228 295 minecraft:waxed_copper_block
fill 490 228 297 497 229 297 minecraft:iron_block
fill 491 228 282 511 228 283 minecraft:black_stained_glass
fill 491 228 292 497 229 293 minecraft:iron_block
fill 491 228 294 491 230 294 minecraft:waxed_copper_block
fill 491 228 295 497 229 296 minecraft:iron_block
fill 491 228 305 511 228 306 minecraft:black_stained_glass
fill 492 228 276 511 228 279 minecraft:black_stained_glass
setblock 492 228 281 minecraft:black_wool
fill 492 228 284 493 228 284 minecraft:black_stained_glass
fill 492 228 294 500 229 294 minecraft:iron_block
fill 492 228 304 493 228 304 minecraft:black_stained_glass
fill 493 228 280 511 228 281 minecraft:black_stained_glass
fill 494 228 284 495 229 284 minecraft:iron_block
fill 494 228 304 495 229 304 minecraft:iron_block
fill 495 228 286 500 228 286 minecraft:black_stained_glass
fill 495 228 302 511 228 302 minecraft:black_stained_glass
fill 496 228 284 511 228 285 minecraft:black_stained_glass
fill 496 228 287 500 228 287 minecraft:black_stained_glass
fill 496 228 301 511 228 301 minecraft:black_stained_glass
fill 496 228 303 511 228 304 minecraft:black_stained_glass
fill 496 228 317 498 302 317 minecraft:deepslate_tiles
fill 497 228 307 498 228 307 minecraft:black_wool
fill 497 228 309 511 228 310 minecraft:black_stained_glass
fill 498 228 291 498 228 293 minecraft:black_stained_glass
fill 498 228 295 498 228 297 minecraft:black_stained_glass
fill 499 228 288 511 228 288 minecraft:black_stained_glass
fill 499 228 290 511 228 292 minecraft:black_stained_glass
fill 499 228 293 499 229 293 minecraft:iron_block
fill 499 228 295 499 229 295 minecraft:iron_block
fill 499 228 296 502 228 298 minecraft:black_stained_glass
fill 499 228 300 511 228 300 minecraft:black_stained_glass
fill 499 228 307 511 228 308 minecraft:black_stained_glass
setblock 499 228 317 minecraft:redstone_block
fill 500 228 289 511 228 289 minecraft:black_stained_glass
fill 500 228 293 511 228 293 minecraft:black_stained_glass
fill 500 228 295 511 228 295 minecraft:black_stained_glass
fill 500 228 299 511 228 299 minecraft:black_stained_glass
fill 501 228 286 501 228 287 minecraft:black_wool
fill 501 228 294 511 228 294 minecraft:black_stained_glass
fill 503 228 286 511 228 287 minecraft:black_stained_glass
fill 503 228 296 511 228 297 minecraft:black_stained_glass
setblock 503 228 298 minecraft:black_wool
fill 505 228 298 511 228 298 minecraft:black_stained_glass
setblock 473 229 278 minecraft:light[level=13]
setblock 473 229 285 minecraft:light[level=12]
setblock 473 229 286 minecraft:light[level=13]
setblock 473 229 292 minecraft:light[level=12]
setblock 473 229 294 minecraft:light[level=13]
setblock 473 229 299 minecraft:light[level=12]
setblock 473 229 302 minecraft:light[level=13]
setblock 473 229 306 minecraft:light[level=12]
setblock 473 229 310 minecraft:light[level=13]
setblock 473 229 313 minecraft:light[level=12]
setblock 480 229 278 minecraft:light[level=12]
setblock 480 229 306 minecraft:light[level=12]
setblock 480 229 313 minecraft:light[level=12]
fill 481 229 275 483 274 275 minecraft:deepslate_tiles
setblock 481 229 278 minecraft:light[level=13]
setblock 481 229 310 minecraft:light[level=13]
fill 483 229 294 483 230 294 minecraft:waxed_copper_block
setblock 484 229 275 minecraft:white_wool
fill 485 229 275 488 249 275 minecraft:deepslate_tiles
fill 485 229 291 486 229 291 minecraft:waxed_copper_block
fill 485 229 297 486 229 297 minecraft:waxed_copper_block
setblock 487 229 278 minecraft:light[level=12]
setblock 487 229 306 minecraft:light[level=12]
setblock 487 229 313 minecraft:light[level=12]
fill 488 229 291 489 229 291 minecraft:waxed_copper_block
fill 488 229 297 489 229 297 minecraft:waxed_copper_block
setblock 489 229 278 minecraft:light[level=13]
setblock 489 229 310 minecraft:light[level=13]
fill 490 229 292 490 229 293 minecraft:waxed_copper_block
fill 490 229 295 490 229 296 minecraft:waxed_copper_block
setblock 494 229 278 minecraft:light[level=12]
setblock 494 229 306 minecraft:light[level=12]
setblock 494 229 313 minecraft:light[level=12]
setblock 497 229 278 minecraft:light[level=13]
setblock 497 229 286 minecraft:light[level=13]
setblock 497 229 302 minecraft:light[level=13]
setblock 497 229 310 minecraft:light[level=13]
fill 499 229 317 499 308 317 minecraft:deepslate_tiles
setblock 501 229 278 minecraft:light[level=12]
setblock 501 229 285 minecraft:light[level=12]
setblock 501 229 292 minecraft:light[level=12]
setblock 501 229 299 minecraft:light[level=12]
setblock 501 229 306 minecraft:light[level=12]
setblock 501 229 313 minecraft:light[level=12]
setblock 505 229 278 minecraft:light[level=13]
setblock 505 229 286 minecraft:light[level=13]
setblock 505 229 294 minecraft:light[level=13]
setblock 505 229 302 minecraft:light[level=13]
setblock 505 229 310 minecraft:light[level=13]
setblock 508 229 278 minecraft:light[level=12]
setblock 508 229 285 minecraft:light[level=12]
setblock 508 229 292 minecraft:light[level=12]
setblock 508 229 299 minecraft:light[level=12]
setblock 508 229 306 minecraft:light[level=12]
setblock 508 229 313 minecraft:light[level=12]
fill 480 230 292 480 230 296 minecraft:waxed_oxidized_copper
fill 481 230 290 481 230 291 minecraft:waxed_oxidized_copper
fill 481 230 297 481 230 298 minecraft:waxed_oxidized_copper
setblock 482 230 289 minecraft:waxed_oxidized_copper
setblock 482 230 299 minecraft:waxed_oxidized_copper
fill 483 230 288 484 230 288 minecraft:waxed_oxidized_copper
fill 483 230 300 484 230 300 minecraft:waxed_oxidized_copper
fill 484 230 275 484 243 275 minecraft:deepslate_tiles
setblock 484 230 292 minecraft:waxed_copper_block
setblock 484 230 296 minecraft:waxed_copper_block
fill 485 230 287 489 230 287 minecraft:waxed_oxidized_copper
setblock 485 230 291 minecraft:waxed_copper_block
setblock 485 230 297 minecraft:waxed_copper_block
fill 485 230 301 489 230 301 minecraft:waxed_oxidized_copper
setblock 489 230 291 minecraft:waxed_copper_block
setblock 489 230 297 minecraft:waxed_copper_block
fill 490 230 288 491 230 288 minecraft:waxed_oxidized_copper
setblock 490 230 292 minecraft:waxed_copper_block
setblock 490 230 296 minecraft:waxed_copper_block
fill 490 230 300 491 230 300 minecraft:waxed_oxidized_copper
setblock 492 230 289 minecraft:waxed_oxidized_copper
setblock 492 230 299 minecraft:waxed_oxidized_copper
fill 493 230 290 493 230 291 minecraft:waxed_oxidized_copper
fill 493 230 297 493 230 298 minecraft:waxed_oxidized_copper
fill 494 230 292 494 230 296 minecraft:waxed_oxidized_copper
setblock 470 231 294 minecraft:redstone_block
fill 470 232 294 472 232 294 minecraft:deepslate_tiles
setblock 471 232 276 minecraft:cobbled_deepslate
fill 471 232 277 471 232 280 minecraft:deepslate_tiles
setblock 471 232 281 minecraft:cobbled_deepslate
fill 471 232 282 471 232 285 minecraft:deepslate_tiles
setblock 471 232 286 minecraft:cobbled_deepslate
fill 471 232 287 471 232 290 minecraft:deepslate_tiles
setblock 471 232 291 minecraft:cobbled_deepslate
fill 471 232 292 472 233 293 minecraft:deepslate_tiles
setblock 471 232 295 minecraft:deepslate_tiles
setblock 471 232 296 minecraft:cobbled_deepslate
fill 471 232 297 471 234 298 minecraft:deepslate_tiles
setblock 471 232 305 minecraft:deepslate_tiles
setblock 471 232 306 minecraft:cobbled_deepslate
fill 471 232 307 471 232 310 minecraft:deepslate_tiles
setblock 471 232 311 minecraft:cobbled_deepslate
fill 471 232 312 471 232 315 minecraft:deepslate_tiles
setblock 471 232 316 minecraft:cobbled_deepslate
fill 472 232 276 472 232 279 minecraft:deepslate_tiles
setblock 472 232 280 minecraft:cobbled_deepslate
fill 472 232 281 472 232 284 minecraft:deepslate_tiles
setblock 472 232 285 minecraft:cobbled_deepslate
fill 472 232 286 472 232 289 minecraft:deepslate_tiles
setblock 472 232 290 minecraft:cobbled_deepslate
fill 472 232 291 472 235 291 minecraft:deepslate_tiles
fill 472 232 307 472 232 309 minecraft:deepslate_tiles
setblock 472 232 310 minecraft:cobbled_deepslate
fill 472 232 311 472 232 314 minecraft:deepslate_tiles
setblock 472 232 315 minecraft:cobbled_deepslate
fill 472 232 316 475 232 316 minecraft:deepslate_tiles
fill 473 232 276 474 232 277 minecraft:deepslate_tiles
fill 473 232 310 473 232 313 minecraft:deepslate_tiles
setblock 473 232 314 minecraft:cobbled_deepslate
fill 473 232 315 476 232 315 minecraft:deepslate_tiles
fill 474 232 314 477 232 314 minecraft:deepslate_tiles
setblock 475 232 276 minecraft:deepslate_tiles
fill 475 232 291 475 233 291 minecraft:white_wool
setblock 476 232 276 minecraft:cobbled_deepslate
setblock 476 232 316 minecraft:cobbled_deepslate
fill 477 232 276 478 234 276 minecraft:deepslate_tiles
fill 477 232 290 477 233 290 minecraft:white_wool
setblock 477 232 315 minecraft:cobbled_deepslate
fill 477 232 316 480 232 316 minecraft:deepslate_tiles
fill 478 232 315 481 232 315 minecraft:deepslate_tiles
setblock 481 232 316 minecraft:cobbled_deepslate
setblock 482 232 315 minecraft:cobbled_deepslate
fill 482 232 316 485 232 316 minecraft:deepslate_tiles
fill 483 232 315 486 232 315 minecraft:deepslate_tiles
fill 485 232 314 487 232 314 minecraft:deepslate_tiles
setblock 486 232 316 minecraft:cobbled_deepslate
setblock 487 232 315 minecraft:cobbled_deepslate
fill 487 232 316 490 232 316 minecraft:deepslate_tiles
fill 488 232 276 490 232 276 minecraft:deepslate_tiles
setblock 488 232 313 minecraft:deepslate_tiles
setblock 488 232 314 minecraft:cobbled_deepslate
fill 488 232 315 491 232 315 minecraft:deepslate_tiles
setblock 489 232 313 minecraft:cobbled_deepslate
fill 489 232 314 492 232 314 minecraft:deepslate_tiles
fill 490 232 313 492 233 313 minecraft:deepslate_tiles
setblock 491 232 276 minecraft:cobbled_deepslate
setblock 491 232 316 minecraft:cobbled_deepslate
fill 492 232 276 492 235 276 minecraft:deepslate_tiles
setblock 492 232 315 minecraft:cobbled_deepslate
fill 492 232 316 495 232 316 minecraft:deepslate_tiles
setblock 493 232 314 minecraft:cobbled_deepslate
fill 493 232 315 495 233 315 minecraft:deepslate_tiles
fill 494 232 314 494 234 314 minecraft:deepslate_tiles
setblock 496 232 316 minecraft:cobbled_deepslate
fill 497 232 316 497 235 316 minecraft:deepslate_tiles
fill 500 232 278 500 236 278 minecraft:white_wool
fill 507 232 276 510 232 276 minecraft:deepslate_tiles
fill 507 232 316 510 232 316 minecraft:deepslate_tiles
setblock 508 232 288 minecraft:deepslate_tiles
setblock 508 232 289 minecraft:cobbled_deepslate
fill 508 232 290 509 232 292 minecraft:deepslate_tiles
setblock 509 232 277 minecraft:deepslate_tiles
fill 509 232 284 509 232 287 minecraft:deepslate_tiles
setblock 509 232 288 minecraft:cobbled_deepslate
fill 509 232 289 511 233 289 minecraft:deepslate_tiles
setblock 509 232 293 minecraft:cobbled_deepslate
fill 509 232 294 511 232 295 minecraft:deepslate_tiles
fill 509 232 315 511 232 315 minecraft:deepslate_tiles
setblock 510 232 277 minecraft:cobbled_deepslate
fill 510 232 278 510 232 281 minecraft:deepslate_tiles
setblock 510 232 282 minecraft:cobbled_deepslate
fill 510 232 283 510 232 286 minecraft:deepslate_tiles
setblock 510 232 287 minecraft:cobbled_deepslate
fill 510 232 288 511 234 288 minecraft:deepslate_tiles
fill 510 232 290 510 232 291 minecraft:deepslate_tiles
setblock 510 232 292 minecraft:cobbled_deepslate
fill 510 232 293 511 234 293 minecraft:deepslate_tiles
setblock 510 232 296 minecraft:deepslate_tiles
setblock 510 232 297 minecraft:cobbled_deepslate
fill 510 232 309 510 232 311 minecraft:deepslate_tiles
setblock 510 232 312 minecraft:cobbled_deepslate
fill 510 232 313 511 233 314 minecraft:deepslate_tiles
setblock 511 232 276 minecraft:cobbled_deepslate
fill 511 232 277 511 232 280 minecraft:deepslate_tiles
setblock 511 232 281 minecraft:cobbled_deepslate
fill 511 232 282 511 232 285 minecraft:deepslate_tiles
setblock 511 232 286 minecraft:cobbled_deepslate
fill 511 232 287 511 235 287 minecraft:deepslate_tiles
setblock 511 232 290 minecraft:deepslate_tiles
setblock 511 232 291 minecraft:cobbled_deepslate
fill 511 232 292 511 235 292 minecraft:deepslate_tiles
setblock 511 232 296 minecraft:cobbled_deepslate
fill 511 232 297 511 232 300 minecraft:deepslate_tiles
setblock 511 232 305 minecraft:deepslate_tiles
setblock 511 232 306 minecraft:cobbled_deepslate
fill 511 232 307 511 232 310 minecraft:deepslate_tiles
setblock 511 232 311 minecraft:cobbled_deepslate
fill 511 232 312 511 235 312 minecraft:deepslate_tiles
setblock 511 232 316 minecraft:cobbled_deepslate
fill 470 233 294 471 233 294 minecraft:deepslate_tiles
fill 471 233 276 471 233 279 minecraft:deepslate_tiles
setblock 471 233 280 minecraft:cobbled_deepslate
fill 471 233 281 471 233 284 minecraft:deepslate_tiles
setblock 471 233 285 minecraft:cobbled_deepslate
fill 471 233 286 471 233 289 minecraft:deepslate_tiles
setblock 471 233 290 minecraft:cobbled_deepslate
fill 471 233 291 471 236 291 minecraft:deepslate_tiles
setblock 471 233 295 minecraft:cobbled_deepslate
fill 471 233 296 471 236 296 minecraft:deepslate_tiles
setblock 471 233 299 minecraft:deepslate_tiles
setblock 471 233 305 minecraft:cobbled_deepslate
fill 471 233 306 471 233 309 minecraft:deepslate_tiles
setblock 471 233 310 minecraft:cobbled_deepslate
fill 471 233 311 471 233 314 minecraft:deepslate_tiles
setblock 471 233 315 minecraft:cobbled_deepslate
fill 471 233 316 474 233 316 minecraft:deepslate_tiles
fill 472 233 276 472 233 278 minecraft:deepslate_tiles
setblock 472 233 279 minecraft:cobbled_deepslate
fill 472 233 280 472 233 283 minecraft:deepslate_tiles
setblock 472 233 284 minecraft:cobbled_deepslate
fill 472 233 285 472 233 288 minecraft:deepslate_tiles
setblock 472 233 289 minecraft:cobbled_deepslate
fill 472 233 290 472 236 290 minecraft:deepslate_tiles
setblock 472 233 294 minecraft:cobbled_deepslate
fill 472 233 295 472 236 295 minecraft:deepslate_tiles
fill 472 233 307 472 233 308 minecraft:deepslate_tiles
setblock 472 233 309 minecraft:cobbled_deepslate
fill 472 233 310 472 233 313 minecraft:deepslate_tiles
setblock 472 233 314 minecraft:cobbled_deepslate
fill 472 233 315 475 233 315 minecraft:deepslate_tiles
fill 473 233 276 473 233 277 minecraft:deepslate_tiles
fill 473 233 310 473 233 312 minecraft:deepslate_tiles
setblock 473 233 313 minecraft:cobbled_deepslate
fill 473 233 314 476 233 314 minecraft:deepslate_tiles
setblock 474 233 276 minecraft:deepslate_tiles
setblock 474 233 277 minecraft:cobbled_deepslate
setblock 475 233 276 minecraft:cobbled_deepslate
fill 475 233 277 475 236 277 minecraft:deepslate_tiles
setblock 475 233 316 minecraft:cobbled_deepslate
fill 476 233 276 476 236 276 minecraft:deepslate_tiles
setblock 476 233 315 minecraft:cobbled_deepslate
fill 476 233 316 479 233 316 minecraft:deepslate_tiles
setblock 477 233 314 minecraft:cobbled_deepslate
fill 477 233 315 480 233 315 minecraft:deepslate_tiles
fill 478 233 314 478 236 314 minecraft:deepslate_tiles
setblock 480 233 316 minecraft:cobbled_deepslate
setblock 481 233 315 minecraft:cobbled_deepslate
fill 481 233 316 484 233 316 minecraft:deepslate_tiles
fill 482 233 315 485 233 315 minecraft:deepslate_tiles
fill 483 233 314 486 233 314 minecraft:deepslate_tiles
setblock 485 233 276 minecraft:cobbled_deepslate
setblock 485 233 316 minecraft:cobbled_deepslate
fill 486 233 276 489 233 276 minecraft:deepslate_tiles
fill 486 233 313 487 233 313 minecraft:deepslate_tiles
setblock 486 233 315 minecraft:cobbled_deepslate
fill 486 233 316 489 233 316 minecraft:deepslate_tiles
setblock 487 233 314 minecraft:cobbled_deepslate
fill 487 233 315 490 233 315 minecraft:deepslate_tiles
setblock 488 233 313 minecraft:cobbled_deepslate
fill 488 233 314 491 233 314 minecraft:deepslate_tiles
fill 489 233 313 489 236 313 minecraft:deepslate_tiles
setblock 490 233 276 minecraft:cobbled_deepslate
setblock 490 233 316 minecraft:cobbled_deepslate
fill 491 233 276 491 236 276 minecraft:deepslate_tiles
setblock 491 233 315 minecraft:cobbled_deepslate
fill 491 233 316 494 233 316 minecraft:deepslate_tiles
setblock 492 233 314 minecraft:cobbled_deepslate
fill 492 233 315 492 236 315 minecraft:deepslate_tiles
fill 493 233 276 493 234 276 minecraft:deepslate_tiles
fill 493 233 314 493 236 314 minecraft:deepslate_tiles
setblock 495 233 316 minecraft:cobbled_deepslate
fill 496 233 316 496 236 316 minecraft:deepslate_tiles
setblock 505 233 276 minecraft:cobbled_deepslate
setblock 505 233 316 minecraft:cobbled_deepslate
fill 506 233 276 509 233 276 minecraft:deepslate_tiles
fill 506 233 313 506 240 313 minecraft:cobbled_deepslate
fill 506 233 316 509 233 316 minecraft:deepslate_tiles
fill 507 233 315 510 233 315 minecraft:deepslate_tiles
setblock 508 233 277 minecraft:deepslate_tiles
setblock 508 233 288 minecraft:cobbled_deepslate
fill 508 233 289 508 233 292 minecraft:deepslate_tiles
setblock 508 233 293 minecraft:cobbled_deepslate
setblock 509 233 277 minecraft:cobbled_deepslate
fill 509 233 284 509 233 286 minecraft:deepslate_tiles
setblock 509 233 287 minecraft:cobbled_deepslate
fill 509 233 288 509 236 288 minecraft:deepslate_tiles
fill 509 233 290 509 233 291 minecraft:deepslate_tiles
setblock 509 233 292 minecraft:cobbled_deepslate
fill 509 233 293 509 233 296 minecraft:deepslate_tiles
setblock 510 233 276 minecraft:cobbled_deepslate
fill 510 233 277 510 233 280 minecraft:deepslate_tiles
setblock 510 233 281 minecraft:cobbled_deepslate
fill 510 233 282 510 233 285 minecraft:deepslate_tiles
setblock 510 233 286 minecraft:cobbled_deepslate
fill 510 233 287 510 236 287 minecraft:deepslate_tiles
setblock 510 233 290 minecraft:deepslate_tiles
setblock 510 233 291 minecraft:cobbled_deepslate
fill 510 233 292 510 236 292 minecraft:deepslate_tiles
fill 510 233 294 510 233 295 minecraft:deepslate_tiles
setblock 510 233 296 minecraft:cobbled_deepslate
fill 510 233 297 511 234 298 minecraft:deepslate_tiles
fill 510 233 309 510 233 310 minecraft:deepslate_tiles
setblock 510 233 311 minecraft:cobbled_deepslate
fill 510 233 312 510 236 312 minecraft:deepslate_tiles
setblock 510 233 316 minecraft:cobbled_deepslate
fill 511 233 276 511 233 279 minecraft:deepslate_tiles
setblock 511 233 280 minecraft:cobbled_deepslate
fill 511 233 281 511 233 284 minecraft:deepslate_tiles
setblock 511 233 285 minecraft:cobbled_deepslate
fill 511 233 286 511 236 286 minecraft:deepslate_tiles
setblock 511 233 290 minecraft:cobbled_deepslate
fill 511 233 291 511 236 291 minecraft:deepslate_tiles
setblock 511 233 294 minecraft:deepslate_tiles
setblock 511 233 295 minecraft:cobbled_deepslate
fill 511 233 296 511 236 296 minecraft:deepslate_tiles
setblock 511 233 299 minecraft:deepslate_tiles
setblock 511 233 300 minecraft:cobbled_deepslate
fill 511 233 301 511 236 301 minecraft:deepslate_tiles
setblock 511 233 305 minecraft:cobbled_deepslate
fill 511 233 306 511 233 309 minecraft:deepslate_tiles
setblock 511 233 310 minecraft:cobbled_deepslate
fill 511 233 311 511 236 311 minecraft:deepslate_tiles
setblock 511 233 315 minecraft:cobbled_deepslate
fill 511 233 316 511 236 316 minecraft:deepslate_tiles
fill 470 234 294 470 308 294 minecraft:deepslate_tiles
fill 471 234 276 471 234 278 minecraft:deepslate_tiles
setblock 471 234 279 minecraft:cobbled_deepslate
fill 471 234 280 471 234 283 minecraft:deepslate_tiles
setblock 471 234 284 minecraft:cobbled_deepslate
fill 471 234 285 471 234 288 minecraft:deepslate_tiles
setblock 471 234 289 minecraft:cobbled_deepslate
fill 471 234 290 471 237 290 minecraft:deepslate_tiles
fill 471 234 292 471 234 293 minecraft:deepslate_tiles
setblock 471 234 294 minecraft:cobbled_deepslate
fill 471 234 295 471 237 295 minecraft:deepslate_tiles
setblock 471 234 299 minecraft:cobbled_deepslate
fill 471 234 300 471 236 301 minecraft:deepslate_tiles
setblock 471 234 304 minecraft:cobbled_deepslate
fill 471 234 305 471 234 308 minecraft:deepslate_tiles
setblock 471 234 309 minecraft:cobbled_deepslate
fill 471 234 310 471 234 313 minecraft:deepslate_tiles
setblock 471 234 314 minecraft:cobbled_deepslate
fill 471 234 315 473 234 316 minecraft:deepslate_tiles
fill 472 234 276 472 234 277 minecraft:deepslate_tiles
setblock 472 234 278 minecraft:cobbled_deepslate
fill 472 234 279 472 234 282 minecraft:deepslate_tiles
setblock 472 234 283 minecraft:cobbled_deepslate
fill 472 234 284 472 234 287 minecraft:deepslate_tiles
setblock 472 234 288 minecraft:cobbled_deepslate
fill 472 234 289 472 236 289 minecraft:deepslate_tiles
setblock 472 234 292 minecraft:deepslate_tiles
setblock 472 234 293 minecraft:cobbled_deepslate
fill 472 234 294 474 235 294 minecraft:waxed_copper_block
fill 472 234 296 472 235 296 minecraft:deepslate_tiles
setblock 472 234 308 minecraft:cobbled_deepslate
fill 472 234 309 472 234 312 minecraft:deepslate_tiles
setblock 472 234 313 minecraft:cobbled_deepslate
fill 472 234 314 475 234 314 minecraft:deepslate_tiles
setblock 473 234 276 minecraft:deepslate_tiles
setblock 473 234 277 minecraft:cobbled_deepslate
fill 473 234 291 475 235 293 minecraft:waxed_copper_block
fill 473 234 295 475 235 297 minecraft:waxed_copper_block
fill 473 234 310 473 234 311 minecraft:deepslate_tiles
setblock 473 234 312 minecraft:cobbled_deepslate
fill 473 234 313 473 237 313 minecraft:deepslate_tiles
setblock 474 234 276 minecraft:cobbled_deepslate
fill 474 234 277 474 237 277 minecraft:deepslate_tiles
fill 474 234 290 482 235 290 minecraft:waxed_copper_block
fill 474 234 298 482 235 298 minecraft:waxed_copper_block
setblock 474 234 315 minecraft:deepslate_tiles
setblock 474 234 316 minecraft:cobbled_deepslate
fill 475 234 276 475 237 276 minecraft:deepslate_tiles
fill 475 234 289 481 235 289 minecraft:waxed_copper_block
fill 475 234 299 481 235 299 minecraft:waxed_copper_block
setblock 475 234 315 minecraft:cobbled_deepslate
fill 475 234 316 478 234 316 minecraft:deepslate_tiles
fill 476 234 291 477 235 291 minecraft:waxed_copper_block
fill 476 234 297 477 235 297 minecraft:waxed_copper_block
setblock 476 234 314 minecraft:cobbled_deepslate
fill 476 234 315 479 234 315 minecraft:deepslate_tiles
fill 477 234 314 477 237 314 minecraft:deepslate_tiles
fill 478 234 288 478 235 288 minecraft:waxed_copper_block
fill 478 234 300 478 235 300 minecraft:waxed_copper_block
setblock 479 234 276 minecraft:cobbled_deepslate
fill 479 234 291 483 235 291 minecraft:waxed_copper_block
fill 479 234 297 483 235 297 minecraft:waxed_copper_block
fill 479 234 314 480 234 314 minecraft:deepslate_tiles
setblock 479 234 316 minecraft:cobbled_deepslate
fill 480 234 276 483 234 276 minecraft:deepslate_tiles
setblock 480 234 315 minecraft:cobbled_deepslate
fill 480 234 316 483 234 316 minecraft:deepslate_tiles
fill 481 234 292 482 235 293 minecraft:waxed_copper_block
fill 481 234 295 482 235 296 minecraft:waxed_copper_block
setblock 481 234 314 minecraft:cobbled_deepslate
fill 481 234 315 484 234 315 minecraft:deepslate_tiles
fill 482 234 294 482 235 294 minecraft:waxed_copper_block
fill 482 234 314 485 234 314 minecraft:deepslate_tiles
setblock 484 234 276 minecraft:cobbled_deepslate
setblock 484 234 316 minecraft:cobbled_deepslate
fill 485 234 276 488 234 276 minecraft:deepslate_tiles
fill 485 234 313 486 234 313 minecraft:deepslate_tiles
setblock 485 234 315 minecraft:cobbled_deepslate
fill 485 234 316 488 234 316 minecraft:deepslate_tiles
setblock 486 234 314 minecraft:cobbled_deepslate
fill 486 234 315 489 234 315 minecraft:deepslate_tiles
setblock 487 234 313 minecraft:cobbled_deepslate
fill 487 234 314 490 234 314 minecraft:deepslate_tiles
fill 488 234 313 488 237 313 minecraft:deepslate_tiles
setblock 489 234 276 minecraft:cobbled_deepslate
setblock 489 234 316 minecraft:cobbled_deepslate
setblock 490 234 275 minecraft:redstone_block
fill 490 234 276 490 237 276 minecraft:deepslate_tiles
fill 490 234 313 491 234 313 minecraft:deepslate_tiles
setblock 490 234 315 minecraft:cobbled_deepslate
fill 490 234 316 493 234 316 minecraft:deepslate_tiles
fill 491 234 275 491 308 275 minecraft:deepslate_tiles
setblock 491 234 314 minecraft:cobbled_deepslate
fill 491 234 315 491 237 315 minecraft:deepslate_tiles
setblock 492 234 313 minecraft:cobbled_deepslate
fill 492 234 314 492 237 314 minecraft:deepslate_tiles
fill 493 234 315 494 234 315 minecraft:deepslate_tiles
setblock 494 234 276 minecraft:cobbled_deepslate
setblock 494 234 316 minecraft:cobbled_deepslate
setblock 495 234 315 minecraft:cobbled_deepslate
fill 495 234 316 495 237 316 minecraft:deepslate_tiles
setblock 496 234 315 minecraft:deepslate_tiles
setblock 498 234 316 minecraft:deepslate_tiles
setblock 503 234 316 minecraft:deepslate_tiles
setblock 504 234 276 minecraft:cobbled_deepslate
setblock 504 234 316 minecraft:cobbled_deepslate
fill 505 234 276 508 234 276 minecraft:deepslate_tiles
fill 505 234 316 508 234 316 minecraft:deepslate_tiles
fill 506 234 277 507 234 277 minecraft:deepslate_tiles
fill 506 234 315 509 234 315 minecraft:deepslate_tiles
setblock 508 234 277 minecraft:cobbled_deepslate
setblock 508 234 287 minecraft:cobbled_deepslate
fill 508 234 288 508 234 291 minecraft:deepslate_tiles
setblock 508 234 292 minecraft:cobbled_deepslate
fill 508 234 293 509 235 294 minecraft:deepslate_tiles
setblock 509 234 276 minecraft:cobbled_deepslate
fill 509 234 277 511 234 278 minecraft:deepslate_tiles
fill 509 234 283 509 234 285 minecraft:deepslate_tiles
setblock 509 234 286 minecraft:cobbled_deepslate
fill 509 234 287 509 237 287 minecraft:deepslate_tiles
fill 509 234 289 509 234 290 minecraft:deepslate_tiles
setblock 509 234 291 minecraft:cobbled_deepslate
fill 509 234 292 509 237 292 minecraft:deepslate_tiles
setblock 509 234 295 minecraft:deepslate_tiles
setblock 509 234 296 minecraft:cobbled_deepslate
fill 509 234 297 509 237 297 minecraft:deepslate_tiles
fill 509 234 313 510 234 314 minecraft:deepslate_tiles
setblock 509 234 316 minecraft:cobbled_deepslate
fill 510 234 276 511 236 276 minecraft:deepslate_tiles
setblock 510 234 279 minecraft:deepslate_tiles
setblock 510 234 280 minecraft:cobbled_deepslate
fill 510 234 281 510 234 284 minecraft:deepslate_tiles
setblock 510 234 285 minecraft:cobbled_deepslate
fill 510 234 286 510 237 286 minecraft:deepslate_tiles
setblock 510 234 289 minecraft:deepslate_tiles
setblock 510 234 290 minecraft:cobbled_deepslate
fill 510 234 291 510 237 291 minecraft:deepslate_tiles
setblock 510 234 294 minecraft:deepslate_tiles
setblock 510 234 295 minecraft:cobbled_deepslate
fill 510 234 296 510 237 296 minecraft:deepslate_tiles
setblock 510 234 299 minecraft:deepslate_tiles
setblock 510 234 309 minecraft:deepslate_tiles
setblock 510 234 310 minecraft:cobbled_deepslate
fill 510 234 311 510 237 311 minecraft:deepslate_tiles
setblock 510 234 315 minecraft:cobbled_deepslate
fill 510 234 316 510 237 316 minecraft:deepslate_tiles
setblock 511 234 279 minecraft:cobbled_deepslate
fill 511 234 280 511 234 283 minecraft:deepslate_tiles
setblock 511 234 284 minecraft:cobbled_deepslate
fill 511 234 285 511 237 285 minecraft:deepslate_tiles
setblock 511 234 289 minecraft:cobbled_deepslate
fill 511 234 290 511 237 290 minecraft:deepslate_tiles
setblock 511 234 294 minecraft:cobbled_deepslate
fill 511 234 295 511 237 295 minecraft:deepslate_tiles
setblock 511 234 299 minecraft:cobbled_deepslate
fill 511 234 300 511 237 300 minecraft:deepslate_tiles
fill 511 234 302 511 234 303 minecraft:deepslate_tiles
setblock 511 234 304 minecraft:cobbled_deepslate
fill 511 234 305 511 234 308 minecraft:deepslate_tiles
setblock 511 234 309 minecraft:cobbled_deepslate
fill 511 234 310 511 237 310 minecraft:deepslate_tiles
setblock 511 234 313 minecraft:deepslate_tiles
setblock 511 234 314 minecraft:cobbled_deepslate
fill 511 234 315 511 237 315 minecraft:deepslate_tiles
fill 471 235 276 471 235 277 minecraft:deepslate_tiles
setblock 471 235 278 minecraft:cobbled_deepslate
fill 471 235 279 471 235 282 minecraft:deepslate_tiles
setblock 471 235 283 minecraft:cobbled_deepslate
fill 471 235 284 471 235 287 minecraft:deepslate_tiles
setblock 471 235 288 minecraft:cobbled_deepslate
fill 471 235 289 471 238 289 minecraft:deepslate_tiles
setblock 471 235 292 minecraft:deepslate_tiles
setblock 471 235 293 minecraft:cobbled_deepslate
fill 471 235 294 471 238 294 minecraft:deepslate_tiles
setblock 471 235 297 minecraft:deepslate_tiles
setblock 471 235 298 minecraft:cobbled_deepslate
fill 471 235 299 471 238 299 minecraft:deepslate_tiles
setblock 471 235 302 minecraft:deepslate_tiles
setblock 471 235 303 minecraft:cobbled_deepslate
fill 471 235 304 471 235 307 minecraft:deepslate_tiles
setblock 471 235 308 minecraft:cobbled_deepslate
fill 471 235 309 471 235 312 minecraft:deepslate_tiles
setblock 471 235 313 minecraft:cobbled_deepslate
fill 471 235 314 472 235 316 minecraft:deepslate_tiles
setblock 472 235 276 minecraft:deepslate_tiles
setblock 472 235 277 minecraft:cobbled_deepslate
fill 472 235 278 472 235 281 minecraft:deepslate_tiles
setblock 472 235 282 minecraft:cobbled_deepslate
fill 472 235 283 472 235 286 minecraft:deepslate_tiles
setblock 472 235 287 minecraft:cobbled_deepslate
fill 472 235 288 472 236 288 minecraft:deepslate_tiles
setblock 472 235 292 minecraft:cobbled_deepslate
fill 472 235 293 472 237 293 minecraft:deepslate_tiles
setblock 472 235 297 minecraft:cobbled_deepslate
fill 472 235 308 472 235 311 minecraft:deepslate_tiles
setblock 472 235 312 minecraft:cobbled_deepslate
fill 472 235 313 472 238 313 minecraft:deepslate_tiles
setblock 473 235 276 minecraft:cobbled_deepslate
fill 473 235 277 473 238 277 minecraft:deepslate_tiles
setblock 473 235 278 minecraft:light[level=12]
setblock 473 235 285 minecraft:light[level=12]
setblock 473 235 299 minecraft:light[level=12]
setblock 473 235 306 minecraft:light[level=12]
setblock 473 235 310 minecraft:deepslate_tiles
setblock 473 235 311 minecraft:cobbled_deepslate
fill 473 235 312 473 237 312 minecraft:deepslate_tiles
fill 473 235 314 473 235 315 minecraft:deepslate_tiles
setblock 473 235 316 minecraft:cobbled_deepslate
fill 474 235 276 474 238 276 minecraft:deepslate_tiles
setblock 474 235 314 minecraft:deepslate_tiles
setblock 474 235 315 minecraft:cobbled_deepslate
fill 474 235 316 477 235 316 minecraft:deepslate_tiles
setblock 475 235 314 minecraft:cobbled_deepslate
fill 475 235 315 478 235 315 minecraft:deepslate_tiles
fill 476 235 314 476 237 314 minecraft:deepslate_tiles
setblock 477 235 276 minecraft:deepslate_tiles
setblock 478 235 276 minecraft:cobbled_deepslate
setblock 478 235 316 minecraft:cobbled_deepslate
fill 479 235 276 482 235 276 minecraft:deepslate_tiles
setblock 479 235 314 minecraft:deepslate_tiles
setblock 479 235 315 minecraft:cobbled_deepslate
fill 479 235 316 482 235 316 minecraft:deepslate_tiles
setblock 480 235 278 minecraft:light[level=12]
setblock 480 235 285 minecraft:light[level=12]
setblock 480 235 292 minecraft:light[level=12]
setblock 480 235 306 minecraft:light[level=12]
setblock 480 235 313 minecraft:light[level=12]
setblock 480 235 314 minecraft:cobbled_deepslate
fill 480 235 315 483 235 315 minecraft:deepslate_tiles
fill 481 235 314 484 235 314 minecraft:deepslate_tiles
setblock 483 235 276 minecraft:cobbled_deepslate
setblock 483 235 316 minecraft:cobbled_deepslate
fill 484 235 276 487 235 276 minecraft:deepslate_tiles
setblock 484 235 315 minecraft:cobbled_deepslate
fill 484 235 316 487 235 316 minecraft:deepslate_tiles
setblock 485 235 313 minecraft:deepslate_tiles
setblock 485 235 314 minecraft:cobbled_deepslate
fill 485 235 315 488 235 315 minecraft:deepslate_tiles
setblock 486 235 313 minecraft:cobbled_deepslate
fill 486 235 314 489 235 314 minecraft:deepslate_tiles
setblock 487 235 278 minecraft:light[level=12]
setblock 487 235 285 minecraft:light[level=12]
setblock 487 235 299 minecraft:light[level=12]
setblock 487 235 306 minecraft:light[level=12]
fill 487 235 313 487 237 313 minecraft:deepslate_tiles
setblock 488 235 276 minecraft:cobbled_deepslate
fill 488 235 277 490 236 277 minecraft:deepslate_tiles
setblock 488 235 316 minecraft:cobbled_deepslate
fill 489 235 276 489 238 276 minecraft:deepslate_tiles
setblock 489 235 315 minecraft:cobbled_deepslate
fill 489 235 316 492 235 316 minecraft:deepslate_tiles
fill 490 235 275 490 308 275 minecraft:deepslate_tiles
setblock 490 235 313 minecraft:deepslate_tiles
setblock 490 235 314 minecraft:cobbled_deepslate
fill 490 235 315 490 238 315 minecraft:deepslate_tiles
setblock 491 235 313 minecraft:cobbled_deepslate
fill 491 235 314 491 238 314 minecraft:deepslate_tiles
setblock 493 235 276 minecraft:cobbled_deepslate
setblock 493 235 315 minecraft:deepslate_tiles
setblock 493 235 316 minecraft:cobbled_deepslate
fill 494 235 276 495 237 276 minecraft:deepslate_tiles
setblock 494 235 278 minecraft:light[level=12]
setblock 494 235 285 minecraft:light[level=12]
setblock 494 235 292 minecraft:light[level=12]
setblock 494 235 299 minecraft:light[level=12]
setblock 494 235 306 minecraft:light[level=12]
setblock 494 235 313 minecraft:light[level=12]
setblock 494 235 315 minecraft:cobbled_deepslate
fill 494 235 316 494 238 316 minecraft:deepslate_tiles
fill 495 235 315 495 236 315 minecraft:deepslate_tiles
setblock 498 235 316 minecraft:cobbled_deepslate
setblock 501 235 278 minecraft:light[level=12]
setblock 501 235 285 minecraft:light[level=12]
setblock 501 235 292 minecraft:light[level=12]
setblock 501 235 299 minecraft:light[level=12]
setblock 501 235 306 minecraft:light[level=12]
setblock 501 235 313 minecraft:light[level=12]
fill 501 235 316 502 235 316 minecraft:deepslate_tiles
setblock 502 235 276 minecraft:deepslate_tiles
setblock 503 235 276 minecraft:cobbled_deepslate
setblock 503 235 316 minecraft:cobbled_deepslate
fill 504 235 276 507 235 276 minecraft:deepslate_tiles
fill 504 235 316 507 235 316 minecraft:deepslate_tiles
fill 505 235 277 506 235 277 minecraft:deepslate_tiles
fill 505 235 315 508 235 315 minecraft:deepslate_tiles
setblock 507 235 277 minecraft:cobbled_deepslate
setblock 508 235 276 minecraft:cobbled_deepslate
fill 508 235 277 510 235 278 minecraft:deepslate_tiles
setblock 508 235 285 minecraft:light[level=12]
fill 508 235 287 508 235 290 minecraft:deepslate_tiles
setblock 508 235 291 minecraft:cobbled_deepslate
fill 508 235 292 508 238 292 minecraft:deepslate_tiles
setblock 508 235 295 minecraft:deepslate_tiles
setblock 508 235 299 minecraft:light[level=12]
setblock 508 235 306 minecraft:light[level=12]
setblock 508 235 313 minecraft:light[level=12]
fill 508 235 314 509 235 314 minecraft:deepslate_tiles
setblock 508 235 316 minecraft:cobbled_deepslate
fill 509 235 276 509 238 276 minecraft:deepslate_tiles
setblock 509 235 279 minecraft:deepslate_tiles
setblock 509 235 280 minecraft:cobbled_deepslate
fill 509 235 281 509 235 284 minecraft:deepslate_tiles
setblock 509 235 285 minecraft:cobbled_deepslate
fill 509 235 286 509 237 286 minecraft:deepslate_tiles
setblock 509 235 289 minecraft:deepslate_tiles
setblock 509 235 290 minecraft:cobbled_deepslate
fill 509 235 291 509 238 291 minecraft:deepslate_tiles
setblock 509 235 295 minecraft:cobbled_deepslate
fill 509 235 296 509 238 296 minecraft:deepslate_tiles
fill 509 235 298 510 235 298 minecraft:deepslate_tiles
fill 509 235 312 509 235 313 minecraft:deepslate_tiles
setblock 509 235 315 minecraft:cobbled_deepslate
fill 509 235 316 509 238 316 minecraft:deepslate_tiles
setblock 510 235 279 minecraft:cobbled_deepslate
fill 510 235 280 510 235 283 minecraft:deepslate_tiles
setblock 510 235 284 minecraft:cobbled_deepslate
fill 510 235 285 510 238 285 minecraft:deepslate_tiles
setblock 510 235 288 minecraft:deepslate_tiles
setblock 510 235 289 minecraft:cobbled_deepslate
fill 510 235 290 510 238 290 minecraft:deepslate_tiles
setblock 510 235 293 minecraft:deepslate_tiles
setblock 510 235 294 minecraft:cobbled_deepslate
fill 510 235 295 510 238 295 minecraft:deepslate_tiles
fill 510 235 297 511 235 297 minecraft:deepslate_tiles
setblock 510 235 299 minecraft:cobbled_deepslate
fill 510 235 300 510 238 300 minecraft:deepslate_tiles
setblock 510 235 309 minecraft:cobbled_deepslate
fill 510 235 310 510 236 310 minecraft:deepslate_tiles
setblock 510 235 313 minecraft:deepslate_tiles
setblock 510 235 314 minecraft:cobbled_deepslate
fill 510 235 315 510 238 315 minecraft:deepslate_tiles
setblock 511 235 277 minecraft:deepslate_tiles
setblock 511 235 278 minecraft:cobbled_deepslate
fill 511 235 279 511 235 282 minecraft:deepslate_tiles
setblock 511 235 283 minecraft:cobbled_deepslate
fill 511 235 284 511 238 284 minecraft:deepslate_tiles
setblock 511 235 288 minecraft:cobbled_deepslate
fill 511 235 289 511 238 289 minecraft:deepslate_tiles
setblock 511 235 293 minecraft:cobbled_deepslate
fill 511 235 294 511 238 294 minecraft:deepslate_tiles
setblock 511 235 298 minecraft:cobbled_deepslate
fill 511 235 299 511 238 299 minecraft:deepslate_tiles
setblock 511 235 302 minecraft:deepslate_tiles
setblock 511 235 303 minecraft:cobbled_deepslate
fill 511 235 305 511 235 307 minecraft:deepslate_tiles
setblock 511 235 308 minecraft:cobbled_deepslate
fill 511 235 309 511 238 309 minecraft:deepslate_tiles
setblock 511 235 313 minecraft:cobbled_deepslate
fill 511 235 314 511 238 314 minecraft:deepslate_tiles
setblock 471 236 276 minecraft:deepslate_tiles
setblock 471 236 277 minecraft:cobbled_deepslate
fill 471 236 278 471 236 281 minecraft:deepslate_tiles
setblock 471 236 282 minecraft:cobbled_deepslate
fill 471 236 283 471 236 286 minecraft:deepslate_tiles
setblock 471 236 287 minecraft:cobbled_deepslate
fill 471 236 288 471 238 288 minecraft:deepslate_tiles
setblock 471 236 292 minecraft:cobbled_deepslate
fill 471 236 293 471 239 293 minecraft:deepslate_tiles
setblock 471 236 297 minecraft:cobbled_deepslate
fill 471 236 298 471 239 298 minecraft:deepslate_tiles
setblock 471 236 302 minecraft:cobbled_deepslate
fill 471 236 303 471 236 306 minecraft:deepslate_tiles
setblock 471 236 307 minecraft:cobbled_deepslate
fill 471 236 308 471 236 311 minecraft:deepslate_tiles
setblock 471 236 312 minecraft:cobbled_deepslate
fill 471 236 313 471 236 316 minecraft:deepslate_tiles
setblock 472 236 276 minecraft:cobbled_deepslate
fill 472 236 277 472 236 280 minecraft:deepslate_tiles
setblock 472 236 281 minecraft:cobbled_deepslate
setblock 472 236 291 minecraft:cobbled_deepslate
fill 472 236 292 472 237 292 minecraft:deepslate_tiles
fill 472 236 294 472 237 294 minecraft:deepslate_tiles
setblock 472 236 296 minecraft:cobbled_deepslate
fill 472 236 297 472 237 297 minecraft:deepslate_tiles
fill 472 236 308 472 236 310 minecraft:deepslate_tiles
setblock 472 236 311 minecraft:cobbled_deepslate
fill 472 236 312 472 239 312 minecraft:deepslate_tiles
fill 472 236 314 472 236 315 minecraft:deepslate_tiles
setblock 472 236 316 minecraft:cobbled_deepslate
fill 473 236 276 473 239 276 minecraft:deepslate_tiles
setblock 473 236 311 minecraft:deepslate_tiles
setblock 473 236 314 minecraft:deepslate_tiles
setblock 473 236 315 minecraft:cobbled_deepslate
fill 473 236 316 476 236 316 minecraft:deepslate_tiles
setblock 474 236 314 minecraft:cobbled_deepslate
fill 474 236 315 477 236 315 minecraft:deepslate_tiles
fill 475 236 291 475 246 291 minecraft:white_wool
fill 475 236 314 475 238 314 minecraft:deepslate_tiles
setblock 477 236 276 minecraft:cobbled_deepslate
fill 477 236 290 477 240 290 minecraft:white_wool
setblock 477 236 316 minecraft:cobbled_deepslate
fill 478 236 276 481 236 276 minecraft:deepslate_tiles
setblock 478 236 315 minecraft:cobbled_deepslate
fill 478 236 316 481 236 316 minecraft:deepslate_tiles
setblock 479 236 314 minecraft:cobbled_deepslate
fill 479 236 315 482 236 315 minecraft:deepslate_tiles
fill 480 236 314 483 236 314 minecraft:deepslate_tiles
setblock 482 236 276 minecraft:cobbled_deepslate
setblock 482 236 316 minecraft:cobbled_deepslate
schedule function dropper:buildpart/70_10 1t
