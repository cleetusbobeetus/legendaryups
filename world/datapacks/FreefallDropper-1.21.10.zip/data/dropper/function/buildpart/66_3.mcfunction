fill 308 144 282 308 145 282 minecraft:iron_block
fill 308 144 284 308 145 284 minecraft:iron_block
setblock 309 144 276 minecraft:iron_block
fill 314 144 276 317 144 276 minecraft:iron_block
setblock 315 144 316 minecraft:iron_block
fill 317 144 316 320 144 316 minecraft:iron_block
setblock 319 144 276 minecraft:iron_block
fill 323 144 277 323 144 280 minecraft:iron_block
setblock 323 144 282 minecraft:iron_block
fill 323 144 287 323 144 290 minecraft:iron_block
setblock 323 144 292 minecraft:iron_block
fill 323 144 297 323 144 300 minecraft:iron_block
setblock 323 144 302 minecraft:iron_block
fill 323 144 307 323 144 310 minecraft:iron_block
setblock 323 144 312 minecraft:iron_block
setblock 285 145 278 minecraft:light[level=15]
setblock 285 145 285 minecraft:light[level=12]
setblock 285 145 286 minecraft:light[level=15]
setblock 285 145 292 minecraft:light[level=12]
setblock 285 145 294 minecraft:light[level=15]
setblock 285 145 299 minecraft:light[level=12]
setblock 285 145 302 minecraft:light[level=15]
setblock 285 145 306 minecraft:light[level=12]
setblock 285 145 313 minecraft:light[level=12]
setblock 289 145 314 minecraft:iron_block
fill 291 145 312 292 145 312 minecraft:iron_block
setblock 291 145 314 minecraft:iron_block
setblock 292 145 278 minecraft:light[level=12]
setblock 292 145 285 minecraft:light[level=12]
setblock 292 145 292 minecraft:light[level=12]
setblock 292 145 299 minecraft:light[level=12]
setblock 292 145 306 minecraft:light[level=12]
fill 292 145 311 294 145 311 minecraft:iron_block
fill 292 145 313 294 145 313 minecraft:iron_block
setblock 293 145 278 minecraft:light[level=15]
setblock 293 145 286 minecraft:light[level=15]
setblock 293 145 294 minecraft:light[level=15]
setblock 293 145 302 minecraft:light[level=15]
setblock 293 145 310 minecraft:light[level=15]
setblock 294 145 312 minecraft:iron_block
setblock 299 145 292 minecraft:light[level=12]
setblock 299 145 299 minecraft:light[level=12]
setblock 299 145 306 minecraft:light[level=12]
setblock 299 145 313 minecraft:light[level=12]
setblock 301 145 294 minecraft:light[level=15]
setblock 301 145 302 minecraft:light[level=15]
setblock 301 145 310 minecraft:light[level=15]
setblock 306 145 278 minecraft:light[level=12]
setblock 306 145 292 minecraft:light[level=12]
setblock 306 145 299 minecraft:light[level=12]
setblock 306 145 306 minecraft:light[level=12]
setblock 306 145 313 minecraft:light[level=12]
setblock 309 145 275 minecraft:redstone_block
setblock 309 145 278 minecraft:light[level=15]
setblock 309 145 286 minecraft:light[level=15]
setblock 309 145 294 minecraft:light[level=15]
setblock 309 145 302 minecraft:light[level=15]
setblock 309 145 310 minecraft:light[level=15]
fill 310 145 275 312 145 275 minecraft:gray_concrete
setblock 313 145 278 minecraft:light[level=12]
setblock 313 145 285 minecraft:light[level=12]
setblock 313 145 292 minecraft:light[level=12]
setblock 313 145 299 minecraft:light[level=12]
setblock 313 145 306 minecraft:light[level=12]
setblock 313 145 313 minecraft:light[level=12]
setblock 317 145 278 minecraft:light[level=15]
setblock 317 145 286 minecraft:light[level=15]
setblock 317 145 294 minecraft:light[level=15]
setblock 317 145 302 minecraft:light[level=15]
setblock 317 145 310 minecraft:light[level=15]
setblock 320 145 278 minecraft:light[level=12]
setblock 320 145 285 minecraft:light[level=12]
setblock 320 145 292 minecraft:light[level=12]
setblock 320 145 299 minecraft:light[level=12]
setblock 320 145 306 minecraft:light[level=12]
setblock 320 145 313 minecraft:light[level=12]
setblock 324 145 286 minecraft:gray_concrete
setblock 324 145 287 minecraft:sea_lantern
fill 324 145 288 324 145 289 minecraft:gray_concrete
fill 282 146 275 282 147 276 minecraft:yellow_concrete
fill 282 146 277 282 147 278 minecraft:black_concrete
fill 282 146 279 282 147 280 minecraft:yellow_concrete
fill 282 146 281 282 147 282 minecraft:black_concrete
fill 282 146 283 282 147 284 minecraft:yellow_concrete
fill 282 146 285 282 147 286 minecraft:black_concrete
fill 282 146 287 282 147 288 minecraft:yellow_concrete
fill 282 146 289 282 147 290 minecraft:black_concrete
fill 282 146 291 282 147 292 minecraft:yellow_concrete
fill 282 146 293 282 147 294 minecraft:black_concrete
fill 282 146 295 282 147 296 minecraft:yellow_concrete
fill 282 146 297 282 147 298 minecraft:black_concrete
fill 282 146 299 282 147 300 minecraft:yellow_concrete
fill 282 146 301 282 147 302 minecraft:black_concrete
fill 282 146 303 282 147 304 minecraft:yellow_concrete
fill 282 146 305 282 147 306 minecraft:black_concrete
fill 282 146 307 282 147 308 minecraft:yellow_concrete
fill 282 146 309 282 147 310 minecraft:black_concrete
fill 282 146 311 282 147 312 minecraft:yellow_concrete
fill 282 146 313 282 147 314 minecraft:black_concrete
fill 282 146 315 282 147 316 minecraft:yellow_concrete
fill 282 146 317 282 147 317 minecraft:black_concrete
fill 283 146 275 283 147 275 minecraft:yellow_concrete
fill 283 146 317 283 147 317 minecraft:yellow_concrete
fill 284 146 275 285 147 275 minecraft:black_concrete
fill 284 146 317 285 147 317 minecraft:black_concrete
fill 286 146 275 287 147 275 minecraft:yellow_concrete
fill 286 146 317 287 147 317 minecraft:yellow_concrete
fill 288 146 275 289 147 275 minecraft:black_concrete
fill 288 146 317 289 147 317 minecraft:black_concrete
fill 290 146 275 291 147 275 minecraft:yellow_concrete
fill 290 146 317 291 147 317 minecraft:yellow_concrete
fill 292 146 275 293 147 275 minecraft:black_concrete
fill 292 146 317 293 147 317 minecraft:black_concrete
fill 294 146 275 295 147 275 minecraft:yellow_concrete
fill 294 146 317 295 147 317 minecraft:yellow_concrete
fill 296 146 275 297 147 275 minecraft:black_concrete
fill 296 146 317 297 147 317 minecraft:black_concrete
fill 298 146 275 299 147 275 minecraft:yellow_concrete
fill 298 146 317 299 147 317 minecraft:yellow_concrete
fill 300 146 275 301 147 275 minecraft:black_concrete
fill 300 146 317 301 147 317 minecraft:black_concrete
fill 302 146 275 303 147 275 minecraft:yellow_concrete
fill 302 146 317 303 147 317 minecraft:yellow_concrete
fill 304 146 275 305 147 275 minecraft:black_concrete
fill 304 146 317 305 147 317 minecraft:black_concrete
fill 306 146 275 307 147 275 minecraft:yellow_concrete
fill 306 146 317 307 147 317 minecraft:yellow_concrete
fill 308 146 275 309 147 275 minecraft:black_concrete
fill 308 146 317 309 147 317 minecraft:black_concrete
fill 310 146 275 311 147 275 minecraft:yellow_concrete
fill 310 146 317 311 147 317 minecraft:yellow_concrete
fill 312 146 275 313 147 275 minecraft:black_concrete
fill 312 146 317 313 147 317 minecraft:black_concrete
fill 314 146 275 315 147 275 minecraft:yellow_concrete
fill 314 146 317 315 147 317 minecraft:yellow_concrete
fill 316 146 275 317 147 275 minecraft:black_concrete
fill 316 146 317 317 147 317 minecraft:black_concrete
fill 318 146 275 319 147 275 minecraft:yellow_concrete
fill 318 146 317 319 147 317 minecraft:yellow_concrete
fill 320 146 275 321 147 275 minecraft:black_concrete
fill 320 146 317 321 147 317 minecraft:black_concrete
fill 322 146 275 323 147 275 minecraft:yellow_concrete
fill 322 146 317 323 147 317 minecraft:yellow_concrete
fill 324 146 275 324 147 275 minecraft:black_concrete
fill 324 146 276 324 147 276 minecraft:yellow_concrete
fill 324 146 277 324 147 278 minecraft:black_concrete
fill 324 146 279 324 147 280 minecraft:yellow_concrete
fill 324 146 281 324 147 282 minecraft:black_concrete
fill 324 146 283 324 147 284 minecraft:yellow_concrete
fill 324 146 285 324 147 286 minecraft:black_concrete
fill 324 146 287 324 147 288 minecraft:yellow_concrete
fill 324 146 289 324 147 290 minecraft:black_concrete
fill 324 146 291 324 147 292 minecraft:yellow_concrete
fill 324 146 293 324 147 294 minecraft:black_concrete
fill 324 146 295 324 147 296 minecraft:yellow_concrete
fill 324 146 297 324 147 298 minecraft:black_concrete
fill 324 146 299 324 147 300 minecraft:yellow_concrete
fill 324 146 301 324 147 302 minecraft:black_concrete
fill 324 146 303 324 147 304 minecraft:yellow_concrete
fill 324 146 305 324 147 306 minecraft:black_concrete
fill 324 146 307 324 147 308 minecraft:yellow_concrete
fill 324 146 309 324 147 310 minecraft:black_concrete
fill 324 146 311 324 147 312 minecraft:yellow_concrete
fill 324 146 313 324 147 314 minecraft:black_concrete
fill 324 146 315 324 147 316 minecraft:yellow_concrete
fill 324 146 317 324 147 317 minecraft:black_concrete
fill 284 147 282 284 147 284 minecraft:iron_block
fill 284 147 309 284 147 311 minecraft:iron_block
fill 285 147 281 287 147 281 minecraft:iron_block
fill 285 147 285 287 147 285 minecraft:iron_block
fill 285 147 308 287 147 308 minecraft:iron_block
fill 285 147 312 287 147 312 minecraft:iron_block
fill 288 147 282 288 147 284 minecraft:iron_block
fill 288 147 309 288 147 311 minecraft:iron_block
setblock 288 147 313 minecraft:iron_block
setblock 290 147 311 minecraft:iron_block
setblock 299 147 279 minecraft:iron_block
fill 282 148 275 282 154 280 minecraft:gray_concrete
fill 282 148 281 282 148 284 minecraft:pearlescent_froglight
fill 282 148 285 282 164 290 minecraft:gray_concrete
fill 282 148 291 282 148 294 minecraft:pearlescent_froglight
fill 282 148 295 282 172 300 minecraft:gray_concrete
fill 282 148 301 282 148 304 minecraft:pearlescent_froglight
fill 282 148 305 282 173 310 minecraft:gray_concrete
fill 282 148 311 282 148 314 minecraft:pearlescent_froglight
fill 282 148 315 282 173 317 minecraft:gray_concrete
fill 283 148 275 284 173 275 minecraft:gray_concrete
fill 283 148 317 285 173 317 minecraft:gray_concrete
fill 285 148 275 288 148 275 minecraft:pearlescent_froglight
fill 286 148 317 289 148 317 minecraft:pearlescent_froglight
fill 289 148 275 294 151 275 minecraft:gray_concrete
fill 290 148 317 295 173 317 minecraft:gray_concrete
fill 295 148 275 298 148 275 minecraft:pearlescent_froglight
fill 296 148 317 299 148 317 minecraft:pearlescent_froglight
fill 298 148 282 298 148 284 minecraft:iron_block
fill 299 148 275 304 173 275 minecraft:gray_concrete
setblock 300 148 280 minecraft:iron_block
fill 300 148 317 305 173 317 minecraft:gray_concrete
fill 303 148 313 303 149 315 minecraft:iron_block
fill 305 148 275 308 148 275 minecraft:pearlescent_froglight
fill 306 148 282 306 148 283 minecraft:iron_block
fill 306 148 317 309 148 317 minecraft:pearlescent_froglight
fill 309 148 275 314 173 275 minecraft:gray_concrete
fill 310 148 317 315 152 317 minecraft:gray_concrete
fill 315 148 275 318 148 275 minecraft:pearlescent_froglight
fill 316 148 317 319 148 317 minecraft:pearlescent_froglight
fill 319 148 275 324 161 275 minecraft:gray_concrete
fill 320 148 317 320 164 317 minecraft:gray_concrete
setblock 321 148 317 minecraft:sea_lantern
fill 322 148 317 324 173 317 minecraft:gray_concrete
fill 324 148 276 324 148 279 minecraft:pearlescent_froglight
fill 324 148 280 324 150 285 minecraft:gray_concrete
fill 324 148 286 324 148 289 minecraft:pearlescent_froglight
fill 324 148 290 324 173 295 minecraft:gray_concrete
fill 324 148 296 324 148 299 minecraft:pearlescent_froglight
fill 324 148 300 324 159 305 minecraft:gray_concrete
fill 324 148 306 324 148 309 minecraft:pearlescent_froglight
fill 324 148 310 324 154 315 minecraft:gray_concrete
setblock 324 148 316 minecraft:pearlescent_froglight
fill 282 149 281 282 156 284 minecraft:gray_concrete
fill 282 149 291 282 156 294 minecraft:gray_concrete
fill 282 149 301 282 156 304 minecraft:gray_concrete
fill 282 149 311 282 156 314 minecraft:gray_concrete
fill 285 149 275 288 156 275 minecraft:gray_concrete
fill 286 149 317 289 156 317 minecraft:gray_concrete
fill 295 149 275 295 156 275 minecraft:gray_concrete
setblock 296 149 275 minecraft:sea_lantern
fill 296 149 317 299 154 317 minecraft:gray_concrete
fill 297 149 275 298 156 275 minecraft:gray_concrete
setblock 301 149 281 minecraft:iron_block
fill 305 149 275 308 156 275 minecraft:gray_concrete
fill 306 149 317 309 156 317 minecraft:gray_concrete
fill 315 149 275 318 156 275 minecraft:gray_concrete
fill 316 149 317 319 156 317 minecraft:gray_concrete
fill 321 149 317 321 155 317 minecraft:gray_concrete
fill 324 149 276 324 151 279 minecraft:gray_concrete
fill 324 149 286 324 156 289 minecraft:gray_concrete
fill 324 149 296 324 152 299 minecraft:gray_concrete
fill 324 149 306 324 156 309 minecraft:gray_concrete
fill 324 149 316 324 156 316 minecraft:gray_concrete
setblock 283 150 278 minecraft:iron_block
setblock 283 150 288 minecraft:iron_block
setblock 283 150 298 minecraft:iron_block
setblock 283 150 308 minecraft:iron_block
setblock 285 150 316 minecraft:iron_block
setblock 289 150 276 minecraft:iron_block
setblock 295 150 316 minecraft:iron_block
fill 296 150 275 296 156 275 minecraft:gray_concrete
setblock 299 150 276 minecraft:iron_block
setblock 305 150 316 minecraft:iron_block
setblock 309 150 276 minecraft:iron_block
setblock 315 150 316 minecraft:iron_block
setblock 319 150 276 minecraft:iron_block
setblock 323 150 282 minecraft:iron_block
setblock 323 150 292 minecraft:iron_block
setblock 323 150 302 minecraft:iron_block
setblock 323 150 312 minecraft:iron_block
setblock 285 151 278 minecraft:light[level=12]
setblock 285 151 285 minecraft:light[level=12]
setblock 285 151 292 minecraft:light[level=12]
setblock 285 151 299 minecraft:light[level=12]
setblock 285 151 306 minecraft:light[level=12]
setblock 285 151 313 minecraft:light[level=12]
setblock 286 151 278 minecraft:gray_concrete
fill 286 151 280 286 151 281 minecraft:gray_concrete
fill 287 151 277 288 151 277 minecraft:gray_concrete
setblock 287 151 281 minecraft:gray_concrete
setblock 289 151 278 minecraft:gray_concrete
setblock 289 151 281 minecraft:gray_concrete
fill 290 151 279 290 151 280 minecraft:gray_concrete
setblock 292 151 278 minecraft:light[level=12]
setblock 292 151 285 minecraft:light[level=12]
setblock 292 151 292 minecraft:light[level=12]
setblock 292 151 299 minecraft:light[level=12]
setblock 292 151 306 minecraft:light[level=12]
setblock 292 151 313 minecraft:light[level=12]
setblock 299 151 278 minecraft:light[level=12]
setblock 299 151 285 minecraft:light[level=12]
setblock 299 151 292 minecraft:light[level=12]
setblock 299 151 299 minecraft:light[level=12]
setblock 299 151 306 minecraft:light[level=12]
setblock 299 151 313 minecraft:light[level=12]
setblock 306 151 278 minecraft:light[level=12]
setblock 306 151 285 minecraft:light[level=12]
setblock 306 151 292 minecraft:light[level=12]
setblock 306 151 299 minecraft:light[level=12]
setblock 306 151 306 minecraft:light[level=12]
setblock 306 151 313 minecraft:light[level=12]
setblock 313 151 278 minecraft:light[level=12]
setblock 313 151 285 minecraft:light[level=12]
setblock 313 151 292 minecraft:light[level=12]
setblock 313 151 299 minecraft:light[level=12]
setblock 313 151 306 minecraft:light[level=12]
setblock 313 151 313 minecraft:light[level=12]
setblock 320 151 278 minecraft:light[level=12]
setblock 320 151 285 minecraft:light[level=12]
setblock 320 151 292 minecraft:light[level=12]
setblock 320 151 299 minecraft:light[level=12]
setblock 320 151 306 minecraft:light[level=12]
setblock 320 151 313 minecraft:light[level=12]
setblock 324 151 280 minecraft:redstone_block
fill 324 151 281 324 156 285 minecraft:gray_concrete
fill 284 152 282 284 152 284 minecraft:iron_block
fill 284 152 309 284 152 311 minecraft:iron_block
fill 285 152 281 287 152 281 minecraft:iron_block
fill 285 152 285 287 152 285 minecraft:iron_block
fill 285 152 308 287 152 308 minecraft:iron_block
fill 285 152 312 287 152 312 minecraft:iron_block
fill 288 152 282 288 152 284 minecraft:iron_block
fill 288 152 309 288 152 311 minecraft:iron_block
setblock 288 152 313 minecraft:iron_block
fill 289 152 275 289 173 275 minecraft:gray_concrete
setblock 290 152 275 minecraft:redstone_block
setblock 290 152 311 minecraft:iron_block
fill 291 152 275 294 173 275 minecraft:gray_concrete
fill 310 152 306 310 159 306 minecraft:iron_block
fill 324 152 276 324 156 278 minecraft:gray_concrete
setblock 324 152 279 minecraft:redstone_block
fill 324 152 280 324 173 280 minecraft:gray_concrete
fill 283 153 280 283 153 283 minecraft:iron_block
fill 283 153 290 283 153 293 minecraft:iron_block
fill 283 153 300 283 153 303 minecraft:iron_block
fill 283 153 310 283 153 313 minecraft:iron_block
fill 284 153 276 287 153 276 minecraft:iron_block
setblock 285 153 278 minecraft:light[level=15]
setblock 285 153 286 minecraft:light[level=15]
setblock 285 153 294 minecraft:light[level=15]
setblock 285 153 302 minecraft:light[level=15]
fill 287 153 316 290 153 316 minecraft:iron_block
setblock 289 153 314 minecraft:iron_block
fill 290 153 275 290 173 275 minecraft:gray_concrete
fill 291 153 312 292 153 312 minecraft:iron_block
setblock 291 153 314 minecraft:iron_block
fill 292 153 311 294 153 311 minecraft:iron_block
fill 292 153 313 294 153 313 minecraft:iron_block
setblock 293 153 278 minecraft:light[level=15]
setblock 293 153 286 minecraft:light[level=15]
setblock 293 153 294 minecraft:light[level=15]
setblock 293 153 302 minecraft:light[level=15]
setblock 293 153 310 minecraft:light[level=15]
fill 293 153 314 293 154 315 minecraft:iron_block
fill 294 153 276 297 153 276 minecraft:iron_block
setblock 294 153 312 minecraft:iron_block
fill 297 153 316 300 153 316 minecraft:iron_block
setblock 301 153 278 minecraft:light[level=15]
setblock 301 153 286 minecraft:light[level=15]
setblock 301 153 294 minecraft:light[level=15]
setblock 301 153 302 minecraft:light[level=15]
setblock 301 153 310 minecraft:light[level=15]
fill 304 153 276 307 153 276 minecraft:iron_block
fill 307 153 316 310 153 316 minecraft:iron_block
setblock 309 153 278 minecraft:light[level=15]
setblock 309 153 286 minecraft:light[level=15]
setblock 309 153 294 minecraft:light[level=15]
setblock 309 153 302 minecraft:light[level=15]
setblock 309 153 310 minecraft:light[level=15]
fill 310 153 307 310 158 307 minecraft:iron_block
fill 310 153 317 313 159 317 minecraft:gray_concrete
fill 311 153 306 311 158 306 minecraft:iron_block
fill 314 153 276 317 153 276 minecraft:iron_block
setblock 314 153 317 minecraft:sea_lantern
fill 315 153 317 315 173 317 minecraft:gray_concrete
setblock 317 153 278 minecraft:light[level=15]
setblock 317 153 286 minecraft:light[level=15]
setblock 317 153 294 minecraft:light[level=15]
setblock 317 153 302 minecraft:light[level=15]
setblock 317 153 310 minecraft:light[level=15]
fill 317 153 316 320 153 316 minecraft:iron_block
fill 323 153 277 323 153 280 minecraft:iron_block
fill 323 153 287 323 153 290 minecraft:iron_block
fill 323 153 297 323 153 300 minecraft:iron_block
fill 323 153 307 323 153 310 minecraft:iron_block
fill 324 153 279 324 156 279 minecraft:gray_concrete
fill 324 153 296 324 156 296 minecraft:gray_concrete
setblock 324 153 297 minecraft:redstone_block
fill 324 153 298 324 156 299 minecraft:gray_concrete
setblock 293 154 311 minecraft:pearlescent_froglight
setblock 293 154 313 minecraft:iron_block
fill 300 154 309 300 170 309 minecraft:iron_block
fill 314 154 317 314 173 317 minecraft:gray_concrete
fill 324 154 297 324 156 297 minecraft:gray_concrete
fill 282 155 275 282 173 275 minecraft:gray_concrete
setblock 282 155 276 minecraft:sea_lantern
fill 282 155 277 282 173 280 minecraft:gray_concrete
fill 296 155 317 298 156 317 minecraft:gray_concrete
setblock 299 155 317 minecraft:redstone_block
setblock 324 155 310 minecraft:redstone_block
fill 324 155 311 324 173 315 minecraft:gray_concrete
fill 282 156 276 282 173 276 minecraft:gray_concrete
setblock 283 156 278 minecraft:iron_block
setblock 283 156 288 minecraft:iron_block
setblock 283 156 298 minecraft:iron_block
setblock 283 156 308 minecraft:iron_block
setblock 285 156 316 minecraft:iron_block
setblock 289 156 276 minecraft:iron_block
setblock 295 156 316 minecraft:iron_block
setblock 299 156 276 minecraft:iron_block
setblock 299 156 317 minecraft:gray_concrete
setblock 305 156 316 minecraft:iron_block
setblock 309 156 276 minecraft:iron_block
fill 312 156 280 312 173 280 minecraft:iron_block
setblock 315 156 316 minecraft:iron_block
setblock 319 156 276 minecraft:iron_block
setblock 321 156 317 minecraft:sea_lantern
setblock 323 156 282 minecraft:iron_block
setblock 323 156 292 minecraft:iron_block
setblock 323 156 302 minecraft:iron_block
setblock 323 156 312 minecraft:iron_block
fill 324 156 310 324 173 310 minecraft:gray_concrete
fill 282 157 281 282 157 284 minecraft:pearlescent_froglight
fill 282 157 291 282 157 294 minecraft:pearlescent_froglight
fill 282 157 301 282 157 304 minecraft:pearlescent_froglight
fill 282 157 311 282 157 314 minecraft:pearlescent_froglight
fill 284 157 282 284 157 284 minecraft:iron_block
fill 284 157 309 284 157 311 minecraft:iron_block
fill 285 157 275 288 157 275 minecraft:pearlescent_froglight
setblock 285 157 278 minecraft:light[level=12]
fill 285 157 281 287 157 281 minecraft:iron_block
fill 285 157 285 287 157 285 minecraft:iron_block
setblock 285 157 292 minecraft:light[level=12]
setblock 285 157 299 minecraft:light[level=12]
setblock 285 157 306 minecraft:light[level=12]
fill 285 157 308 287 157 308 minecraft:iron_block
fill 285 157 312 287 157 312 minecraft:iron_block
setblock 285 157 313 minecraft:light[level=12]
fill 286 157 317 289 157 317 minecraft:pearlescent_froglight
fill 288 157 282 288 157 284 minecraft:iron_block
fill 288 157 309 288 157 311 minecraft:iron_block
setblock 288 157 313 minecraft:iron_block
setblock 290 157 311 minecraft:iron_block
setblock 292 157 278 minecraft:light[level=12]
setblock 292 157 285 minecraft:light[level=12]
setblock 292 157 292 minecraft:light[level=12]
setblock 292 157 299 minecraft:light[level=12]
setblock 292 157 306 minecraft:light[level=12]
setblock 292 157 313 minecraft:light[level=12]
fill 295 157 275 298 157 275 minecraft:pearlescent_froglight
fill 296 157 317 299 157 317 minecraft:pearlescent_froglight
setblock 299 157 278 minecraft:light[level=12]
setblock 299 157 285 minecraft:light[level=12]
setblock 299 157 292 minecraft:light[level=12]
setblock 299 157 299 minecraft:light[level=12]
setblock 299 157 306 minecraft:light[level=12]
setblock 299 157 313 minecraft:light[level=12]
fill 305 157 275 308 157 275 minecraft:pearlescent_froglight
setblock 306 157 278 minecraft:light[level=12]
setblock 306 157 285 minecraft:light[level=12]
setblock 306 157 292 minecraft:light[level=12]
setblock 306 157 299 minecraft:light[level=12]
setblock 306 157 306 minecraft:light[level=12]
setblock 306 157 313 minecraft:light[level=12]
fill 306 157 317 309 157 317 minecraft:pearlescent_froglight
setblock 313 157 278 minecraft:light[level=12]
setblock 313 157 285 minecraft:light[level=12]
setblock 313 157 292 minecraft:light[level=12]
setblock 313 157 299 minecraft:light[level=12]
setblock 313 157 306 minecraft:light[level=12]
setblock 313 157 313 minecraft:light[level=12]
fill 315 157 275 318 157 275 minecraft:pearlescent_froglight
fill 316 157 317 319 157 317 minecraft:pearlescent_froglight
setblock 320 157 278 minecraft:light[level=12]
setblock 320 157 285 minecraft:light[level=12]
setblock 320 157 292 minecraft:light[level=12]
setblock 320 157 299 minecraft:light[level=12]
setblock 320 157 306 minecraft:light[level=12]
setblock 320 157 313 minecraft:light[level=12]
fill 321 157 317 321 173 317 minecraft:gray_concrete
fill 324 157 276 324 157 279 minecraft:pearlescent_froglight
fill 324 157 281 324 173 282 minecraft:gray_concrete
setblock 324 157 283 minecraft:redstone_block
fill 324 157 284 324 173 285 minecraft:gray_concrete
fill 324 157 286 324 157 289 minecraft:pearlescent_froglight
fill 324 157 296 324 157 299 minecraft:pearlescent_froglight
fill 324 157 306 324 157 309 minecraft:pearlescent_froglight
setblock 324 157 316 minecraft:pearlescent_froglight
fill 282 158 281 282 165 284 minecraft:gray_concrete
fill 282 158 291 282 165 294 minecraft:gray_concrete
fill 282 158 301 282 165 304 minecraft:gray_concrete
fill 282 158 311 282 165 314 minecraft:gray_concrete
fill 285 158 275 288 158 275 minecraft:gray_concrete
fill 286 158 317 289 165 317 minecraft:gray_concrete
fill 295 158 275 298 165 275 minecraft:gray_concrete
fill 296 158 317 299 165 317 minecraft:gray_concrete
fill 305 158 275 308 165 275 minecraft:gray_concrete
fill 306 158 317 309 160 317 minecraft:gray_concrete
fill 315 158 275 318 165 275 minecraft:gray_concrete
fill 316 158 317 319 165 317 minecraft:gray_concrete
fill 324 158 276 324 162 279 minecraft:gray_concrete
fill 324 158 283 324 173 283 minecraft:gray_concrete
fill 324 158 286 324 165 289 minecraft:gray_concrete
fill 324 158 296 324 165 299 minecraft:gray_concrete
fill 324 158 306 324 165 309 minecraft:gray_concrete
fill 324 158 316 324 165 316 minecraft:gray_concrete
setblock 285 159 275 minecraft:redstone_block
fill 286 159 275 288 165 275 minecraft:gray_concrete
setblock 286 159 278 minecraft:gray_concrete
fill 286 159 280 286 159 281 minecraft:gray_concrete
fill 287 159 277 288 159 277 minecraft:gray_concrete
setblock 287 159 281 minecraft:gray_concrete
setblock 289 159 278 minecraft:gray_concrete
setblock 289 159 281 minecraft:gray_concrete
fill 290 159 279 290 159 280 minecraft:gray_concrete
fill 285 160 275 285 165 275 minecraft:gray_concrete
fill 310 160 317 311 173 317 minecraft:gray_concrete
setblock 312 160 317 minecraft:redstone_block
fill 313 160 317 313 173 317 minecraft:gray_concrete
fill 324 160 300 324 173 303 minecraft:gray_concrete
setblock 324 160 304 minecraft:redstone_block
fill 324 160 305 324 173 305 minecraft:gray_concrete
setblock 285 161 278 minecraft:light[level=15]
setblock 285 161 286 minecraft:light[level=15]
setblock 285 161 294 minecraft:light[level=15]
setblock 285 161 302 minecraft:light[level=15]
setblock 289 161 314 minecraft:iron_block
fill 291 161 312 292 161 312 minecraft:iron_block
setblock 291 161 314 minecraft:iron_block
fill 292 161 311 294 161 311 minecraft:iron_block
fill 292 161 313 294 161 313 minecraft:iron_block
setblock 293 161 278 minecraft:light[level=15]
setblock 293 161 286 minecraft:light[level=15]
setblock 293 161 294 minecraft:light[level=15]
setblock 293 161 302 minecraft:light[level=15]
setblock 293 161 310 minecraft:light[level=15]
setblock 294 161 312 minecraft:iron_block
setblock 301 161 278 minecraft:light[level=15]
setblock 301 161 286 minecraft:light[level=15]
setblock 301 161 294 minecraft:light[level=15]
setblock 301 161 302 minecraft:light[level=15]
setblock 301 161 310 minecraft:light[level=15]
fill 306 161 317 307 165 317 minecraft:gray_concrete
setblock 308 161 317 minecraft:redstone_block
setblock 309 161 278 minecraft:light[level=15]
setblock 309 161 286 minecraft:light[level=15]
setblock 309 161 294 minecraft:light[level=15]
setblock 309 161 302 minecraft:light[level=15]
setblock 309 161 310 minecraft:light[level=15]
fill 309 161 317 309 165 317 minecraft:gray_concrete
fill 312 161 317 312 173 317 minecraft:gray_concrete
setblock 317 161 278 minecraft:light[level=15]
setblock 317 161 286 minecraft:light[level=15]
setblock 317 161 294 minecraft:light[level=15]
setblock 317 161 302 minecraft:light[level=15]
setblock 317 161 310 minecraft:light[level=15]
fill 324 161 304 324 173 304 minecraft:gray_concrete
setblock 283 162 278 minecraft:iron_block
fill 283 162 280 283 162 283 minecraft:iron_block
setblock 283 162 288 minecraft:iron_block
fill 283 162 290 283 162 293 minecraft:iron_block
setblock 283 162 298 minecraft:iron_block
fill 283 162 300 283 162 303 minecraft:iron_block
setblock 283 162 308 minecraft:iron_block
fill 283 162 310 283 162 313 minecraft:iron_block
fill 284 162 276 287 162 276 minecraft:iron_block
fill 284 162 282 284 162 284 minecraft:iron_block
fill 284 162 309 284 162 311 minecraft:iron_block
fill 285 162 281 287 162 281 minecraft:iron_block
fill 285 162 285 287 162 285 minecraft:iron_block
fill 285 162 308 287 162 308 minecraft:iron_block
fill 285 162 312 287 162 312 minecraft:iron_block
setblock 285 162 316 minecraft:iron_block
fill 287 162 316 290 162 316 minecraft:iron_block
fill 288 162 282 288 162 284 minecraft:iron_block
fill 288 162 309 288 162 311 minecraft:iron_block
setblock 288 162 313 minecraft:iron_block
setblock 289 162 276 minecraft:iron_block
setblock 290 162 311 minecraft:iron_block
fill 294 162 276 297 162 276 minecraft:iron_block
setblock 295 162 316 minecraft:iron_block
fill 297 162 316 300 162 316 minecraft:iron_block
setblock 299 162 276 minecraft:iron_block
fill 304 162 276 307 162 276 minecraft:iron_block
setblock 305 162 316 minecraft:iron_block
fill 307 162 316 310 162 316 minecraft:iron_block
fill 308 162 317 308 165 317 minecraft:gray_concrete
setblock 309 162 276 minecraft:iron_block
fill 314 162 276 317 162 276 minecraft:iron_block
setblock 315 162 316 minecraft:iron_block
fill 317 162 316 320 162 316 minecraft:iron_block
setblock 319 162 275 minecraft:sea_lantern
setblock 319 162 276 minecraft:iron_block
fill 320 162 275 324 173 275 minecraft:gray_concrete
fill 323 162 277 323 162 280 minecraft:iron_block
setblock 323 162 282 minecraft:iron_block
fill 323 162 287 323 162 290 minecraft:iron_block
setblock 323 162 292 minecraft:iron_block
fill 323 162 297 323 162 300 minecraft:iron_block
setblock 323 162 302 minecraft:iron_block
fill 323 162 307 323 162 310 minecraft:iron_block
setblock 323 162 312 minecraft:iron_block
setblock 285 163 278 minecraft:light[level=12]
setblock 285 163 285 minecraft:light[level=12]
setblock 285 163 292 minecraft:light[level=12]
setblock 285 163 299 minecraft:light[level=12]
setblock 285 163 306 minecraft:light[level=12]
setblock 285 163 313 minecraft:light[level=12]
setblock 292 163 278 minecraft:light[level=12]
setblock 292 163 285 minecraft:light[level=12]
setblock 292 163 292 minecraft:light[level=12]
setblock 292 163 299 minecraft:light[level=12]
setblock 292 163 306 minecraft:light[level=12]
setblock 292 163 313 minecraft:light[level=12]
setblock 299 163 278 minecraft:light[level=12]
setblock 299 163 285 minecraft:light[level=12]
setblock 299 163 292 minecraft:light[level=12]
setblock 299 163 299 minecraft:light[level=12]
setblock 299 163 306 minecraft:light[level=12]
setblock 299 163 313 minecraft:light[level=12]
setblock 306 163 278 minecraft:light[level=12]
setblock 306 163 285 minecraft:light[level=12]
setblock 306 163 292 minecraft:light[level=12]
setblock 306 163 299 minecraft:light[level=12]
setblock 306 163 306 minecraft:light[level=12]
setblock 306 163 313 minecraft:light[level=12]
setblock 313 163 278 minecraft:light[level=12]
setblock 313 163 285 minecraft:light[level=12]
setblock 313 163 292 minecraft:light[level=12]
setblock 313 163 299 minecraft:light[level=12]
setblock 313 163 306 minecraft:light[level=12]
setblock 313 163 313 minecraft:light[level=12]
fill 319 163 275 319 173 275 minecraft:gray_concrete
setblock 320 163 278 minecraft:light[level=12]
setblock 320 163 285 minecraft:light[level=12]
setblock 320 163 292 minecraft:light[level=12]
setblock 320 163 299 minecraft:light[level=12]
setblock 320 163 306 minecraft:light[level=12]
setblock 320 163 313 minecraft:light[level=12]
fill 324 163 276 324 165 276 minecraft:gray_concrete
setblock 324 163 277 minecraft:redstone_block
fill 324 163 278 324 165 279 minecraft:gray_concrete
fill 312 164 276 312 165 278 minecraft:iron_block
fill 324 164 277 324 165 277 minecraft:gray_concrete
fill 282 165 285 282 173 287 minecraft:gray_concrete
setblock 282 165 288 minecraft:sea_lantern
fill 282 165 289 282 173 290 minecraft:gray_concrete
setblock 320 165 317 minecraft:sea_lantern
fill 282 166 281 282 166 284 minecraft:pearlescent_froglight
fill 282 166 288 282 173 288 minecraft:gray_concrete
fill 282 166 291 282 166 294 minecraft:pearlescent_froglight
fill 282 166 301 282 166 304 minecraft:pearlescent_froglight
fill 282 166 311 282 166 314 minecraft:pearlescent_froglight
fill 285 166 275 288 166 275 minecraft:pearlescent_froglight
fill 286 166 317 289 166 317 minecraft:pearlescent_froglight
fill 295 166 275 298 166 275 minecraft:pearlescent_froglight
fill 296 166 317 299 166 317 minecraft:pearlescent_froglight
fill 305 166 275 308 166 275 minecraft:pearlescent_froglight
fill 306 166 317 309 166 317 minecraft:pearlescent_froglight
fill 315 166 275 318 166 275 minecraft:pearlescent_froglight
fill 316 166 317 319 166 317 minecraft:pearlescent_froglight
fill 319 166 311 319 177 311 minecraft:iron_block
fill 320 166 317 320 173 317 minecraft:gray_concrete
fill 324 166 276 324 166 279 minecraft:pearlescent_froglight
fill 324 166 286 324 166 289 minecraft:pearlescent_froglight
fill 324 166 296 324 166 299 minecraft:pearlescent_froglight
fill 324 166 306 324 166 309 minecraft:pearlescent_froglight
setblock 324 166 316 minecraft:pearlescent_froglight
fill 282 167 281 282 173 284 minecraft:gray_concrete
fill 282 167 291 282 167 294 minecraft:gray_concrete
fill 282 167 301 282 173 304 minecraft:gray_concrete
fill 282 167 311 282 168 314 minecraft:gray_concrete
fill 284 167 282 284 167 284 minecraft:iron_block
fill 284 167 309 284 167 311 minecraft:iron_block
fill 285 167 275 288 171 275 minecraft:gray_concrete
setblock 285 167 281 minecraft:iron_block
fill 285 167 285 287 167 285 minecraft:iron_block
fill 285 167 308 287 167 308 minecraft:iron_block
fill 285 167 312 287 167 312 minecraft:iron_block
setblock 286 167 278 minecraft:gray_concrete
fill 286 167 280 286 167 281 minecraft:gray_concrete
fill 286 167 317 289 173 317 minecraft:gray_concrete
fill 287 167 277 288 167 277 minecraft:gray_concrete
setblock 287 167 281 minecraft:gray_concrete
fill 288 167 282 288 167 284 minecraft:iron_block
fill 288 167 309 288 167 311 minecraft:iron_block
setblock 288 167 313 minecraft:iron_block
setblock 289 167 278 minecraft:gray_concrete
setblock 289 167 281 minecraft:gray_concrete
fill 290 167 279 290 167 280 minecraft:gray_concrete
setblock 290 167 311 minecraft:iron_block
fill 295 167 275 298 173 275 minecraft:gray_concrete
fill 296 167 317 299 173 317 minecraft:gray_concrete
fill 305 167 275 308 169 275 minecraft:gray_concrete
fill 306 167 317 309 173 317 minecraft:gray_concrete
fill 315 167 275 318 173 275 minecraft:gray_concrete
fill 316 167 317 319 167 317 minecraft:gray_concrete
fill 324 167 276 324 173 279 minecraft:gray_concrete
fill 324 167 286 324 173 289 minecraft:gray_concrete
fill 324 167 296 324 173 299 minecraft:gray_concrete
fill 324 167 306 324 173 309 minecraft:gray_concrete
fill 324 167 316 324 173 316 minecraft:gray_concrete
setblock 282 168 291 minecraft:sea_lantern
fill 282 168 292 282 173 294 minecraft:gray_concrete
setblock 283 168 278 minecraft:iron_block
setblock 283 168 288 minecraft:iron_block
setblock 283 168 298 minecraft:iron_block
setblock 283 168 308 minecraft:iron_block
setblock 285 168 316 minecraft:iron_block
setblock 289 168 276 minecraft:iron_block
setblock 295 168 316 minecraft:iron_block
setblock 299 168 276 minecraft:iron_block
setblock 305 168 316 minecraft:iron_block
setblock 309 168 276 minecraft:iron_block
setblock 315 168 316 minecraft:iron_block
fill 316 168 317 316 173 317 minecraft:gray_concrete
setblock 317 168 317 minecraft:redstone_block
fill 318 168 317 319 173 317 minecraft:gray_concrete
setblock 319 168 276 minecraft:iron_block
setblock 323 168 282 minecraft:iron_block
setblock 323 168 292 minecraft:iron_block
setblock 323 168 302 minecraft:iron_block
setblock 323 168 312 minecraft:iron_block
fill 282 169 291 282 173 291 minecraft:gray_concrete
fill 282 169 311 282 173 312 minecraft:gray_concrete
setblock 282 169 313 minecraft:sea_lantern
fill 282 169 314 282 173 314 minecraft:gray_concrete
setblock 285 169 278 minecraft:light[level=15]
setblock 285 169 285 minecraft:light[level=12]
setblock 285 169 286 minecraft:light[level=15]
setblock 285 169 292 minecraft:light[level=12]
setblock 285 169 294 minecraft:light[level=15]
setblock 285 169 299 minecraft:light[level=12]
setblock 285 169 302 minecraft:light[level=15]
setblock 285 169 306 minecraft:light[level=12]
setblock 285 169 313 minecraft:light[level=12]
setblock 289 169 314 minecraft:iron_block
fill 291 169 312 292 169 312 minecraft:iron_block
setblock 291 169 314 minecraft:iron_block
setblock 292 169 278 minecraft:light[level=12]
setblock 292 169 285 minecraft:light[level=12]
setblock 292 169 292 minecraft:light[level=12]
setblock 292 169 299 minecraft:light[level=12]
setblock 292 169 306 minecraft:light[level=12]
fill 292 169 311 294 169 311 minecraft:iron_block
fill 292 169 313 294 169 313 minecraft:iron_block
setblock 293 169 278 minecraft:light[level=15]
setblock 293 169 286 minecraft:light[level=15]
setblock 293 169 294 minecraft:light[level=15]
setblock 293 169 302 minecraft:light[level=15]
setblock 293 169 310 minecraft:light[level=15]
setblock 294 169 312 minecraft:iron_block
setblock 299 169 278 minecraft:light[level=12]
setblock 299 169 285 minecraft:light[level=12]
setblock 299 169 292 minecraft:light[level=12]
setblock 299 169 299 minecraft:light[level=12]
setblock 299 169 306 minecraft:light[level=12]
setblock 299 169 313 minecraft:light[level=12]
setblock 301 169 278 minecraft:light[level=15]
setblock 301 169 286 minecraft:light[level=15]
setblock 301 169 294 minecraft:light[level=15]
setblock 301 169 302 minecraft:light[level=15]
setblock 301 169 310 minecraft:light[level=15]
setblock 306 169 278 minecraft:light[level=12]
setblock 306 169 285 minecraft:light[level=12]
setblock 306 169 292 minecraft:light[level=12]
setblock 306 169 299 minecraft:light[level=12]
setblock 306 169 306 minecraft:light[level=12]
setblock 306 169 313 minecraft:light[level=12]
setblock 309 169 278 minecraft:light[level=15]
setblock 309 169 286 minecraft:light[level=15]
setblock 309 169 294 minecraft:light[level=15]
setblock 309 169 302 minecraft:light[level=15]
setblock 309 169 310 minecraft:light[level=15]
setblock 313 169 278 minecraft:light[level=12]
setblock 313 169 285 minecraft:light[level=12]
setblock 313 169 292 minecraft:light[level=12]
setblock 313 169 299 minecraft:light[level=12]
setblock 313 169 306 minecraft:light[level=12]
setblock 313 169 313 minecraft:light[level=12]
setblock 317 169 278 minecraft:light[level=15]
setblock 317 169 286 minecraft:light[level=15]
setblock 317 169 294 minecraft:light[level=15]
setblock 317 169 302 minecraft:light[level=15]
setblock 317 169 310 minecraft:light[level=15]
fill 317 169 317 317 173 317 minecraft:gray_concrete
setblock 320 169 278 minecraft:light[level=12]
setblock 320 169 285 minecraft:light[level=12]
setblock 320 169 292 minecraft:light[level=12]
setblock 320 169 299 minecraft:light[level=12]
setblock 320 169 306 minecraft:light[level=12]
setblock 320 169 313 minecraft:light[level=12]
fill 282 170 313 282 173 313 minecraft:gray_concrete
fill 305 170 275 305 173 275 minecraft:gray_concrete
setblock 306 170 275 minecraft:sea_lantern
fill 307 170 275 308 173 275 minecraft:gray_concrete
fill 283 171 280 283 171 283 minecraft:iron_block
fill 283 171 290 283 171 293 minecraft:iron_block
fill 283 171 300 283 171 303 minecraft:iron_block
fill 283 171 310 283 171 313 minecraft:iron_block
fill 284 171 276 287 171 276 minecraft:iron_block
fill 287 171 316 290 171 316 minecraft:iron_block
fill 294 171 276 297 171 276 minecraft:iron_block
fill 297 171 316 300 171 316 minecraft:iron_block
fill 304 171 276 307 171 276 minecraft:iron_block
fill 306 171 275 306 173 275 minecraft:gray_concrete
fill 307 171 316 310 171 316 minecraft:iron_block
fill 314 171 276 317 171 276 minecraft:iron_block
fill 317 171 316 320 171 316 minecraft:iron_block
fill 323 171 277 323 171 280 minecraft:iron_block
fill 323 171 287 323 171 290 minecraft:iron_block
fill 323 171 297 323 171 300 minecraft:iron_block
fill 323 171 307 323 171 310 minecraft:iron_block
fill 284 172 282 284 172 284 minecraft:iron_block
fill 284 172 309 284 172 311 minecraft:iron_block
fill 285 172 275 286 172 275 minecraft:gray_concrete
fill 285 172 281 287 172 281 minecraft:iron_block
fill 285 172 285 287 172 285 minecraft:iron_block
fill 285 172 308 287 172 308 minecraft:iron_block
fill 285 172 312 287 172 312 minecraft:iron_block
setblock 287 172 275 minecraft:redstone_block
fill 288 172 275 288 173 275 minecraft:gray_concrete
fill 288 172 282 288 172 284 minecraft:iron_block
fill 288 172 309 288 172 311 minecraft:iron_block
setblock 288 172 313 minecraft:iron_block
setblock 290 172 311 minecraft:iron_block
fill 282 173 295 282 173 297 minecraft:gray_concrete
setblock 282 173 298 minecraft:redstone_block
fill 282 173 299 282 173 300 minecraft:gray_concrete
setblock 285 173 275 minecraft:gray_concrete
setblock 286 173 275 minecraft:redstone_block
setblock 287 173 275 minecraft:gray_concrete
fill 282 174 275 282 175 276 minecraft:yellow_concrete
fill 282 174 277 282 175 278 minecraft:black_concrete
fill 282 174 279 282 175 280 minecraft:yellow_concrete
fill 282 174 281 282 174 282 minecraft:black_concrete
fill 282 174 283 282 174 284 minecraft:yellow_concrete
fill 282 174 285 282 175 286 minecraft:black_concrete
fill 282 174 287 282 175 288 minecraft:yellow_concrete
fill 282 174 289 282 175 290 minecraft:black_concrete
fill 282 174 291 282 174 292 minecraft:yellow_concrete
fill 282 174 293 282 174 294 minecraft:black_concrete
fill 282 174 295 282 175 296 minecraft:yellow_concrete
fill 282 174 297 282 175 298 minecraft:black_concrete
fill 282 174 299 282 175 300 minecraft:yellow_concrete
fill 282 174 301 282 174 302 minecraft:black_concrete
fill 282 174 303 282 174 304 minecraft:yellow_concrete
fill 282 174 305 282 175 306 minecraft:black_concrete
fill 282 174 307 282 175 308 minecraft:yellow_concrete
fill 282 174 309 282 175 310 minecraft:black_concrete
fill 282 174 311 282 174 312 minecraft:yellow_concrete
fill 282 174 313 282 174 314 minecraft:black_concrete
fill 282 174 315 282 175 316 minecraft:yellow_concrete
fill 282 174 317 282 175 317 minecraft:black_concrete
fill 283 174 275 283 175 275 minecraft:yellow_concrete
setblock 283 174 278 minecraft:iron_block
setblock 283 174 288 minecraft:iron_block
setblock 283 174 298 minecraft:iron_block
setblock 283 174 308 minecraft:iron_block
fill 283 174 317 283 175 317 minecraft:yellow_concrete
fill 284 174 275 285 174 275 minecraft:black_concrete
fill 284 174 317 285 175 317 minecraft:black_concrete
setblock 285 174 316 minecraft:iron_block
fill 286 174 275 287 174 275 minecraft:yellow_concrete
fill 286 174 317 287 174 317 minecraft:yellow_concrete
fill 288 174 275 289 174 275 minecraft:black_concrete
fill 288 174 317 289 174 317 minecraft:black_concrete
setblock 289 174 276 minecraft:iron_block
fill 290 174 275 291 175 275 minecraft:yellow_concrete
fill 290 174 317 291 175 317 minecraft:yellow_concrete
fill 292 174 275 293 175 275 minecraft:black_concrete
fill 292 174 317 293 175 317 minecraft:black_concrete
fill 294 174 275 295 174 275 minecraft:yellow_concrete
fill 294 174 317 295 175 317 minecraft:yellow_concrete
setblock 295 174 316 minecraft:iron_block
fill 296 174 275 297 174 275 minecraft:black_concrete
fill 296 174 317 297 174 317 minecraft:black_concrete
fill 298 174 275 299 174 275 minecraft:yellow_concrete
fill 298 174 317 299 174 317 minecraft:yellow_concrete
setblock 299 174 276 minecraft:iron_block
fill 300 174 275 301 175 275 minecraft:black_concrete
fill 300 174 317 301 175 317 minecraft:black_concrete
fill 302 174 275 303 175 275 minecraft:yellow_concrete
fill 302 174 317 303 175 317 minecraft:yellow_concrete
fill 304 174 275 305 174 275 minecraft:black_concrete
fill 304 174 317 305 175 317 minecraft:black_concrete
setblock 305 174 316 minecraft:iron_block
fill 306 174 275 307 174 275 minecraft:yellow_concrete
fill 306 174 317 307 174 317 minecraft:yellow_concrete
fill 308 174 275 309 174 275 minecraft:black_concrete
fill 308 174 317 309 174 317 minecraft:black_concrete
setblock 309 174 276 minecraft:iron_block
fill 310 174 275 311 175 275 minecraft:yellow_concrete
fill 310 174 317 311 175 317 minecraft:yellow_concrete
fill 312 174 275 313 175 275 minecraft:black_concrete
fill 312 174 317 313 175 317 minecraft:black_concrete
fill 314 174 275 315 174 275 minecraft:yellow_concrete
fill 314 174 317 315 175 317 minecraft:yellow_concrete
setblock 315 174 316 minecraft:iron_block
fill 316 174 275 317 174 275 minecraft:black_concrete
fill 316 174 317 317 174 317 minecraft:black_concrete
fill 318 174 275 319 174 275 minecraft:yellow_concrete
fill 318 174 317 319 174 317 minecraft:yellow_concrete
setblock 319 174 276 minecraft:iron_block
fill 320 174 275 321 175 275 minecraft:black_concrete
fill 320 174 317 321 175 317 minecraft:black_concrete
fill 322 174 275 323 175 275 minecraft:yellow_concrete
fill 322 174 317 323 175 317 minecraft:yellow_concrete
setblock 323 174 282 minecraft:iron_block
setblock 323 174 292 minecraft:iron_block
setblock 323 174 302 minecraft:iron_block
setblock 323 174 312 minecraft:iron_block
fill 324 174 275 324 175 275 minecraft:black_concrete
setblock 324 174 276 minecraft:yellow_concrete
fill 324 174 277 324 174 278 minecraft:black_concrete
fill 324 174 279 324 174 280 minecraft:yellow_concrete
fill 324 174 281 324 175 282 minecraft:black_concrete
fill 324 174 283 324 175 284 minecraft:yellow_concrete
fill 324 174 285 324 174 286 minecraft:black_concrete
fill 324 174 287 324 174 288 minecraft:yellow_concrete
fill 324 174 289 324 174 290 minecraft:black_concrete
fill 324 174 291 324 175 292 minecraft:yellow_concrete
fill 324 174 293 324 175 294 minecraft:black_concrete
fill 324 174 295 324 174 296 minecraft:yellow_concrete
fill 324 174 297 324 174 298 minecraft:black_concrete
fill 324 174 299 324 174 300 minecraft:yellow_concrete
fill 324 174 301 324 175 302 minecraft:black_concrete
fill 324 174 303 324 175 304 minecraft:yellow_concrete
fill 324 174 305 324 174 306 minecraft:black_concrete
fill 324 174 307 324 174 308 minecraft:yellow_concrete
fill 324 174 309 324 174 310 minecraft:black_concrete
fill 324 174 311 324 175 312 minecraft:yellow_concrete
fill 324 174 313 324 175 314 minecraft:black_concrete
fill 324 174 315 324 174 316 minecraft:yellow_concrete
fill 324 174 317 324 175 317 minecraft:black_concrete
fill 282 175 281 282 175 284 minecraft:pearlescent_froglight
fill 282 175 291 282 175 294 minecraft:pearlescent_froglight
fill 282 175 301 282 175 304 minecraft:pearlescent_froglight
fill 282 175 311 282 175 314 minecraft:pearlescent_froglight
fill 283 175 281 287 176 281 minecraft:iron_block
fill 283 175 286 322 176 286 minecraft:iron_block
fill 283 175 291 292 176 291 minecraft:iron_block
fill 283 175 296 291 176 296 minecraft:iron_block
fill 283 175 301 323 175 301 minecraft:iron_block
fill 283 175 306 292 176 306 minecraft:iron_block
fill 283 175 311 284 176 311 minecraft:iron_block
setblock 284 175 275 minecraft:black_concrete
fill 285 175 275 288 175 275 minecraft:pearlescent_froglight
setblock 285 175 278 minecraft:light[level=12]
setblock 285 175 285 minecraft:light[level=12]
setblock 285 175 292 minecraft:light[level=12]
setblock 285 175 299 minecraft:light[level=12]
setblock 285 175 313 minecraft:light[level=12]
setblock 286 175 278 minecraft:gray_concrete
setblock 286 175 280 minecraft:gray_concrete
fill 286 175 317 289 175 317 minecraft:pearlescent_froglight
fill 287 175 277 288 175 277 minecraft:gray_concrete
fill 288 175 311 288 178 311 minecraft:iron_block
setblock 289 175 275 minecraft:black_concrete
setblock 289 175 278 minecraft:gray_concrete
fill 289 175 281 297 176 281 minecraft:iron_block
fill 290 175 279 290 175 280 minecraft:gray_concrete
fill 290 175 311 318 175 311 minecraft:iron_block
setblock 292 175 278 minecraft:light[level=12]
setblock 292 175 285 minecraft:light[level=12]
setblock 292 175 292 minecraft:light[level=12]
setblock 292 175 299 minecraft:light[level=12]
setblock 292 175 313 minecraft:light[level=12]
setblock 294 175 275 minecraft:yellow_concrete
fill 295 175 275 298 175 275 minecraft:pearlescent_froglight
fill 296 175 317 299 175 317 minecraft:pearlescent_froglight
setblock 299 175 275 minecraft:yellow_concrete
setblock 299 175 278 minecraft:light[level=12]
setblock 299 175 285 minecraft:light[level=12]
setblock 299 175 292 minecraft:light[level=12]
setblock 299 175 299 minecraft:light[level=12]
setblock 299 175 306 minecraft:light[level=12]
setblock 299 175 313 minecraft:light[level=12]
setblock 304 175 275 minecraft:black_concrete
fill 305 175 275 308 175 275 minecraft:pearlescent_froglight
setblock 306 175 278 minecraft:light[level=12]
setblock 306 175 285 minecraft:light[level=12]
setblock 306 175 292 minecraft:light[level=12]
setblock 306 175 299 minecraft:light[level=12]
setblock 306 175 306 minecraft:light[level=12]
setblock 306 175 313 minecraft:light[level=12]
fill 306 175 317 309 175 317 minecraft:pearlescent_froglight
setblock 309 175 275 minecraft:black_concrete
setblock 313 175 278 minecraft:light[level=12]
setblock 313 175 285 minecraft:light[level=12]
setblock 313 175 292 minecraft:light[level=12]
setblock 313 175 299 minecraft:light[level=12]
setblock 313 175 306 minecraft:light[level=12]
setblock 313 175 313 minecraft:light[level=12]
setblock 314 175 275 minecraft:yellow_concrete
fill 315 175 275 318 175 275 minecraft:pearlescent_froglight
fill 316 175 317 319 175 317 minecraft:pearlescent_froglight
setblock 319 175 275 minecraft:yellow_concrete
setblock 320 175 278 minecraft:light[level=12]
setblock 320 175 285 minecraft:light[level=12]
setblock 320 175 292 minecraft:light[level=12]
setblock 320 175 299 minecraft:light[level=12]
setblock 320 175 306 minecraft:light[level=12]
fill 320 175 311 323 175 311 minecraft:iron_block
setblock 320 175 313 minecraft:light[level=12]
fill 324 175 276 324 175 279 minecraft:pearlescent_froglight
setblock 324 175 280 minecraft:yellow_concrete
setblock 324 175 285 minecraft:black_concrete
fill 324 175 286 324 175 289 minecraft:pearlescent_froglight
setblock 324 175 290 minecraft:black_concrete
setblock 324 175 295 minecraft:yellow_concrete
fill 324 175 296 324 175 299 minecraft:pearlescent_froglight
setblock 324 175 300 minecraft:yellow_concrete
setblock 324 175 305 minecraft:black_concrete
fill 324 175 306 324 175 309 minecraft:pearlescent_froglight
setblock 324 175 310 minecraft:black_concrete
setblock 324 175 315 minecraft:yellow_concrete
setblock 324 175 316 minecraft:pearlescent_froglight
fill 282 176 275 282 177 307 minecraft:gray_concrete
setblock 282 176 308 minecraft:sea_lantern
fill 282 176 309 282 183 317 minecraft:gray_concrete
fill 283 176 275 324 176 275 minecraft:gray_concrete
fill 283 176 301 299 176 301 minecraft:iron_block
fill 283 176 317 324 177 317 minecraft:gray_concrete
fill 292 176 296 299 176 296 minecraft:iron_block
fill 293 176 291 323 176 291 minecraft:iron_block
fill 293 176 306 323 176 306 minecraft:iron_block
fill 298 176 281 323 176 281 minecraft:iron_block
fill 307 176 296 323 176 296 minecraft:iron_block
fill 324 176 276 324 176 316 minecraft:gray_concrete
fill 282 177 308 282 201 308 minecraft:gray_concrete
fill 283 177 275 283 201 275 minecraft:gray_concrete
setblock 284 177 275 minecraft:sea_lantern
fill 284 177 282 284 177 284 minecraft:iron_block
fill 284 177 309 284 177 311 minecraft:iron_block
fill 285 177 275 324 178 275 minecraft:gray_concrete
setblock 285 177 278 minecraft:light[level=15]
fill 285 177 281 287 177 281 minecraft:iron_block
fill 285 177 285 287 177 285 minecraft:iron_block
setblock 285 177 286 minecraft:light[level=15]
setblock 285 177 294 minecraft:light[level=15]
setblock 285 177 302 minecraft:light[level=15]
fill 285 177 308 287 177 308 minecraft:iron_block
fill 285 177 312 287 177 312 minecraft:iron_block
fill 288 177 276 288 178 277 minecraft:iron_block
fill 288 177 282 288 178 284 minecraft:iron_block
fill 288 177 309 288 178 310 minecraft:iron_block
fill 288 177 313 288 178 313 minecraft:iron_block
setblock 289 177 314 minecraft:iron_block
setblock 290 177 311 minecraft:iron_block
fill 291 177 312 292 177 312 minecraft:iron_block
setblock 291 177 314 minecraft:iron_block
fill 292 177 311 294 177 311 minecraft:iron_block
fill 292 177 313 294 177 313 minecraft:iron_block
fill 293 177 276 293 177 310 minecraft:iron_block
fill 293 177 314 293 177 315 minecraft:iron_block
setblock 294 177 312 minecraft:iron_block
fill 298 177 276 298 178 278 minecraft:iron_block
setblock 301 177 278 minecraft:light[level=15]
setblock 301 177 286 minecraft:light[level=15]
setblock 301 177 294 minecraft:light[level=15]
setblock 301 177 302 minecraft:light[level=15]
setblock 301 177 310 minecraft:light[level=15]
fill 303 177 276 303 178 278 minecraft:iron_block
fill 308 177 276 308 178 282 minecraft:iron_block
setblock 309 177 278 minecraft:light[level=15]
setblock 309 177 286 minecraft:light[level=15]
setblock 309 177 294 minecraft:light[level=15]
setblock 309 177 302 minecraft:light[level=15]
setblock 309 177 310 minecraft:light[level=15]
fill 313 177 276 313 178 283 minecraft:iron_block
setblock 317 177 278 minecraft:light[level=15]
setblock 317 177 286 minecraft:light[level=15]
setblock 317 177 294 minecraft:light[level=15]
setblock 317 177 302 minecraft:light[level=15]
setblock 317 177 310 minecraft:light[level=15]
fill 318 177 276 318 178 282 minecraft:iron_block
fill 324 177 276 324 182 311 minecraft:gray_concrete
setblock 324 177 312 minecraft:redstone_block
fill 324 177 313 324 183 316 minecraft:gray_concrete
fill 282 178 275 282 201 279 minecraft:gray_concrete
setblock 282 178 280 minecraft:sea_lantern
fill 282 178 281 282 180 307 minecraft:gray_concrete
fill 283 178 317 309 183 317 minecraft:gray_concrete
fill 284 178 275 284 201 275 minecraft:gray_concrete
fill 288 178 285 288 178 308 minecraft:iron_block
fill 288 178 314 288 178 315 minecraft:iron_block
fill 293 178 276 293 178 279 minecraft:iron_block
fill 298 178 279 298 178 306 minecraft:iron_block
fill 303 178 279 303 178 293 minecraft:iron_block
fill 303 178 301 303 178 306 minecraft:iron_block
fill 308 178 283 308 178 316 minecraft:iron_block
setblock 310 178 317 minecraft:redstone_block
fill 311 178 317 324 183 317 minecraft:gray_concrete
fill 313 178 284 313 178 316 minecraft:iron_block
fill 318 178 283 318 178 316 minecraft:iron_block
fill 324 178 312 324 179 312 minecraft:gray_concrete
fill 282 179 280 282 194 280 minecraft:gray_concrete
fill 285 179 275 315 183 275 minecraft:gray_concrete
fill 298 179 302 298 179 316 minecraft:iron_block
fill 303 179 302 303 179 316 minecraft:iron_block
fill 310 179 317 310 201 317 minecraft:gray_concrete
setblock 316 179 275 minecraft:redstone_block
fill 317 179 275 324 181 275 minecraft:gray_concrete
setblock 283 180 278 minecraft:iron_block
fill 283 180 280 283 180 283 minecraft:iron_block
setblock 283 180 288 minecraft:iron_block
fill 283 180 290 283 180 293 minecraft:iron_block
setblock 283 180 298 minecraft:iron_block
fill 283 180 300 283 180 303 minecraft:iron_block
setblock 283 180 308 minecraft:iron_block
fill 283 180 310 283 180 313 minecraft:iron_block
fill 284 180 276 287 180 276 minecraft:iron_block
setblock 285 180 316 minecraft:iron_block
fill 287 180 316 290 180 316 minecraft:iron_block
setblock 289 180 276 minecraft:iron_block
fill 294 180 276 297 180 276 minecraft:iron_block
setblock 295 180 316 minecraft:iron_block
fill 297 180 316 300 180 316 minecraft:iron_block
setblock 299 180 276 minecraft:iron_block
fill 304 180 276 307 180 276 minecraft:iron_block
setblock 305 180 316 minecraft:iron_block
fill 307 180 316 310 180 316 minecraft:iron_block
setblock 309 180 276 minecraft:iron_block
fill 314 180 276 317 180 276 minecraft:iron_block
fill 314 180 309 318 181 313 minecraft:gray_concrete
setblock 315 180 316 minecraft:iron_block
fill 316 180 275 316 183 275 minecraft:gray_concrete
fill 316 180 314 316 180 315 minecraft:gray_concrete
fill 317 180 316 320 180 316 minecraft:iron_block
setblock 319 180 276 minecraft:iron_block
fill 323 180 277 323 180 280 minecraft:iron_block
setblock 323 180 282 minecraft:iron_block
fill 323 180 287 323 180 290 minecraft:iron_block
setblock 323 180 292 minecraft:iron_block
fill 323 180 297 323 180 300 minecraft:iron_block
setblock 323 180 302 minecraft:iron_block
fill 323 180 307 323 180 310 minecraft:iron_block
setblock 323 180 312 minecraft:iron_block
setblock 324 180 312 minecraft:sea_lantern
fill 282 181 281 282 183 294 minecraft:gray_concrete
setblock 282 181 295 minecraft:redstone_block
fill 282 181 296 282 183 307 minecraft:gray_concrete
setblock 285 181 278 minecraft:light[level=12]
setblock 285 181 285 minecraft:light[level=12]
setblock 285 181 292 minecraft:light[level=12]
setblock 285 181 299 minecraft:light[level=12]
setblock 285 181 306 minecraft:light[level=12]
setblock 285 181 313 minecraft:light[level=12]
setblock 292 181 278 minecraft:light[level=12]
setblock 292 181 285 minecraft:light[level=12]
setblock 292 181 292 minecraft:light[level=12]
setblock 292 181 299 minecraft:light[level=12]
setblock 292 181 306 minecraft:light[level=12]
setblock 292 181 313 minecraft:light[level=12]
setblock 299 181 278 minecraft:light[level=12]
setblock 299 181 285 minecraft:light[level=12]
setblock 299 181 292 minecraft:light[level=12]
setblock 299 181 299 minecraft:light[level=12]
setblock 299 181 306 minecraft:light[level=12]
setblock 299 181 313 minecraft:light[level=12]
setblock 306 181 278 minecraft:light[level=12]
setblock 306 181 285 minecraft:light[level=12]
setblock 306 181 292 minecraft:light[level=12]
setblock 306 181 299 minecraft:light[level=12]
setblock 306 181 306 minecraft:light[level=12]
setblock 306 181 313 minecraft:light[level=12]
setblock 313 181 278 minecraft:light[level=12]
setblock 313 181 285 minecraft:light[level=12]
setblock 313 181 292 minecraft:light[level=12]
setblock 313 181 299 minecraft:light[level=12]
setblock 313 181 306 minecraft:light[level=12]
setblock 313 181 313 minecraft:light[level=12]
setblock 320 181 278 minecraft:light[level=12]
setblock 320 181 285 minecraft:light[level=12]
setblock 320 181 292 minecraft:light[level=12]
setblock 320 181 299 minecraft:light[level=12]
setblock 320 181 306 minecraft:light[level=12]
setblock 320 181 313 minecraft:light[level=12]
fill 324 181 312 324 201 312 minecraft:gray_concrete
fill 282 182 295 282 201 295 minecraft:gray_concrete
fill 284 182 282 284 182 284 minecraft:iron_block
fill 284 182 309 284 182 311 minecraft:iron_block
fill 285 182 281 287 182 281 minecraft:iron_block
fill 285 182 285 287 182 285 minecraft:iron_block
fill 285 182 308 287 182 308 minecraft:iron_block
fill 285 182 312 287 182 312 minecraft:iron_block
fill 288 182 282 288 182 284 minecraft:iron_block
fill 288 182 309 288 182 311 minecraft:iron_block
setblock 288 182 313 minecraft:iron_block
setblock 290 182 311 minecraft:iron_block
fill 317 182 275 319 183 275 minecraft:gray_concrete
setblock 320 182 275 minecraft:redstone_block
fill 321 182 275 324 201 275 minecraft:gray_concrete
setblock 286 183 278 minecraft:gray_concrete
fill 286 183 280 286 183 281 minecraft:gray_concrete
fill 287 183 277 288 183 277 minecraft:gray_concrete
setblock 287 183 281 minecraft:gray_concrete
setblock 289 183 278 minecraft:gray_concrete
setblock 289 183 281 minecraft:gray_concrete
fill 290 183 279 290 183 280 minecraft:gray_concrete
fill 320 183 275 320 201 275 minecraft:gray_concrete
fill 324 183 276 324 183 303 minecraft:gray_concrete
setblock 324 183 304 minecraft:redstone_block
fill 324 183 305 324 183 311 minecraft:gray_concrete
fill 282 184 281 282 184 284 minecraft:pearlescent_froglight
fill 282 184 285 282 201 290 minecraft:gray_concrete
fill 282 184 291 282 184 294 minecraft:pearlescent_froglight
fill 282 184 296 282 201 300 minecraft:gray_concrete
fill 282 184 301 282 184 304 minecraft:pearlescent_froglight
fill 282 184 305 282 198 307 minecraft:gray_concrete
fill 282 184 309 282 201 310 minecraft:gray_concrete
fill 282 184 311 282 184 314 minecraft:pearlescent_froglight
fill 282 184 315 282 201 317 minecraft:gray_concrete
fill 283 184 317 285 201 317 minecraft:gray_concrete
fill 285 184 275 288 184 275 minecraft:pearlescent_froglight
fill 286 184 317 289 184 317 minecraft:pearlescent_froglight
fill 289 184 275 294 201 275 minecraft:gray_concrete
fill 290 184 317 295 201 317 minecraft:gray_concrete
fill 295 184 275 298 184 275 minecraft:pearlescent_froglight
fill 296 184 317 299 184 317 minecraft:pearlescent_froglight
fill 299 184 275 304 201 275 minecraft:gray_concrete
fill 300 184 317 305 201 317 minecraft:gray_concrete
fill 305 184 275 308 184 275 minecraft:pearlescent_froglight
fill 306 184 317 309 184 317 minecraft:pearlescent_froglight
fill 309 184 275 314 186 275 minecraft:gray_concrete
fill 311 184 317 315 201 317 minecraft:gray_concrete
fill 315 184 275 318 184 275 minecraft:pearlescent_froglight
fill 316 184 317 319 184 317 minecraft:pearlescent_froglight
fill 319 184 275 319 201 275 minecraft:gray_concrete
fill 320 184 317 324 201 317 minecraft:gray_concrete
fill 324 184 276 324 184 279 minecraft:pearlescent_froglight
fill 324 184 280 324 185 285 minecraft:gray_concrete
fill 324 184 286 324 184 289 minecraft:pearlescent_froglight
fill 324 184 290 324 201 295 minecraft:gray_concrete
fill 324 184 296 324 184 299 minecraft:pearlescent_froglight
fill 324 184 300 324 201 305 minecraft:gray_concrete
fill 324 184 306 324 184 309 minecraft:pearlescent_froglight
fill 324 184 310 324 201 311 minecraft:gray_concrete
fill 324 184 313 324 201 315 minecraft:gray_concrete
setblock 324 184 316 minecraft:pearlescent_froglight
fill 282 185 281 282 201 284 minecraft:gray_concrete
fill 282 185 291 282 201 294 minecraft:gray_concrete
fill 282 185 301 282 201 304 minecraft:gray_concrete
fill 282 185 311 282 200 314 minecraft:gray_concrete
fill 285 185 275 288 198 275 minecraft:gray_concrete
setblock 285 185 278 minecraft:light[level=15]
setblock 285 185 286 minecraft:light[level=15]
setblock 285 185 294 minecraft:light[level=15]
setblock 285 185 302 minecraft:light[level=15]
fill 286 185 317 289 201 317 minecraft:gray_concrete
setblock 289 185 314 minecraft:iron_block
fill 291 185 312 292 185 312 minecraft:iron_block
setblock 291 185 314 minecraft:iron_block
fill 292 185 311 294 185 311 minecraft:iron_block
fill 292 185 313 294 185 313 minecraft:iron_block
setblock 293 185 278 minecraft:light[level=15]
setblock 293 185 286 minecraft:light[level=15]
setblock 293 185 294 minecraft:light[level=15]
setblock 293 185 302 minecraft:light[level=15]
setblock 293 185 310 minecraft:light[level=15]
setblock 294 185 312 minecraft:iron_block
fill 295 185 275 298 194 275 minecraft:gray_concrete
fill 296 185 317 299 190 317 minecraft:gray_concrete
fill 297 185 278 301 186 282 minecraft:gray_concrete
fill 299 185 276 299 185 277 minecraft:gray_concrete
setblock 301 185 286 minecraft:light[level=15]
setblock 301 185 294 minecraft:light[level=15]
setblock 301 185 302 minecraft:light[level=15]
setblock 301 185 310 minecraft:light[level=15]
fill 305 185 275 308 201 275 minecraft:gray_concrete
fill 306 185 317 309 201 317 minecraft:gray_concrete
setblock 309 185 278 minecraft:light[level=15]
setblock 309 185 286 minecraft:light[level=15]
setblock 309 185 294 minecraft:light[level=15]
setblock 309 185 302 minecraft:light[level=15]
setblock 309 185 310 minecraft:light[level=15]
fill 313 185 309 313 186 313 minecraft:iron_block
fill 314 185 308 314 186 309 minecraft:iron_block
fill 314 185 311 319 186 311 minecraft:iron_block
fill 314 185 313 314 186 314 minecraft:iron_block
fill 315 185 275 318 201 275 minecraft:gray_concrete
fill 315 185 308 318 186 308 minecraft:iron_block
fill 315 185 314 318 186 314 minecraft:iron_block
fill 316 185 309 316 186 310 minecraft:iron_block
fill 316 185 312 316 186 313 minecraft:iron_block
fill 316 185 317 319 201 317 minecraft:gray_concrete
setblock 317 185 278 minecraft:light[level=15]
setblock 317 185 286 minecraft:light[level=15]
setblock 317 185 294 minecraft:light[level=15]
setblock 317 185 302 minecraft:light[level=15]
setblock 317 185 310 minecraft:light[level=15]
fill 318 185 309 319 186 309 minecraft:iron_block
fill 318 185 313 319 186 313 minecraft:iron_block
fill 319 185 310 319 186 310 minecraft:iron_block
fill 319 185 312 319 186 312 minecraft:iron_block
fill 324 185 276 324 201 279 minecraft:gray_concrete
fill 324 185 286 324 194 289 minecraft:gray_concrete
fill 324 185 296 324 201 299 minecraft:gray_concrete
fill 324 185 306 324 201 309 minecraft:gray_concrete
fill 324 185 316 324 201 316 minecraft:gray_concrete
setblock 283 186 278 minecraft:iron_block
setblock 283 186 288 minecraft:iron_block
setblock 283 186 298 minecraft:iron_block
setblock 283 186 308 minecraft:iron_block
setblock 285 186 316 minecraft:iron_block
setblock 289 186 276 minecraft:iron_block
setblock 295 186 316 minecraft:iron_block
setblock 299 186 276 minecraft:iron_block
setblock 305 186 316 minecraft:iron_block
setblock 309 186 276 minecraft:iron_block
setblock 315 186 316 minecraft:iron_block
setblock 319 186 276 minecraft:iron_block
setblock 323 186 282 minecraft:iron_block
setblock 323 186 292 minecraft:iron_block
setblock 323 186 302 minecraft:iron_block
setblock 323 186 312 minecraft:iron_block
fill 324 186 280 324 201 282 minecraft:gray_concrete
setblock 324 186 283 minecraft:redstone_block
fill 324 186 284 324 194 285 minecraft:gray_concrete
fill 284 187 282 284 187 284 minecraft:iron_block
fill 284 187 309 284 187 311 minecraft:iron_block
setblock 285 187 278 minecraft:light[level=12]
fill 285 187 281 287 187 281 minecraft:iron_block
fill 285 187 285 287 187 285 minecraft:iron_block
setblock 285 187 292 minecraft:light[level=12]
setblock 285 187 299 minecraft:light[level=12]
setblock 285 187 306 minecraft:light[level=12]
fill 285 187 308 287 187 308 minecraft:iron_block
fill 285 187 312 287 187 312 minecraft:iron_block
setblock 285 187 313 minecraft:light[level=12]
fill 288 187 282 288 187 284 minecraft:iron_block
fill 288 187 309 288 187 311 minecraft:iron_block
setblock 288 187 313 minecraft:iron_block
setblock 290 187 311 minecraft:iron_block
setblock 292 187 278 minecraft:light[level=12]
setblock 292 187 285 minecraft:light[level=12]
setblock 292 187 292 minecraft:light[level=12]
setblock 292 187 299 minecraft:light[level=12]
setblock 292 187 306 minecraft:light[level=12]
setblock 292 187 313 minecraft:light[level=12]
setblock 299 187 278 minecraft:light[level=12]
setblock 299 187 285 minecraft:light[level=12]
setblock 299 187 292 minecraft:light[level=12]
setblock 299 187 299 minecraft:light[level=12]
setblock 299 187 306 minecraft:light[level=12]
setblock 299 187 313 minecraft:light[level=12]
setblock 306 187 278 minecraft:light[level=12]
setblock 306 187 285 minecraft:light[level=12]
setblock 306 187 292 minecraft:light[level=12]
setblock 306 187 299 minecraft:light[level=12]
setblock 306 187 306 minecraft:light[level=12]
setblock 306 187 313 minecraft:light[level=12]
fill 309 187 275 313 187 275 minecraft:gray_concrete
setblock 313 187 278 minecraft:light[level=12]
setblock 313 187 285 minecraft:light[level=12]
setblock 313 187 292 minecraft:light[level=12]
setblock 313 187 299 minecraft:light[level=12]
setblock 313 187 306 minecraft:light[level=12]
setblock 313 187 313 minecraft:light[level=12]
setblock 314 187 275 minecraft:redstone_block
setblock 320 187 278 minecraft:light[level=12]
setblock 320 187 285 minecraft:light[level=12]
setblock 320 187 292 minecraft:light[level=12]
setblock 320 187 299 minecraft:light[level=12]
setblock 320 187 306 minecraft:light[level=12]
setblock 320 187 313 minecraft:light[level=12]
fill 324 187 283 324 201 283 minecraft:gray_concrete
setblock 309 188 275 minecraft:sea_lantern
fill 310 188 275 314 189 275 minecraft:gray_concrete
fill 310 188 277 310 189 278 minecraft:iron_block
fill 283 189 280 283 189 283 minecraft:iron_block
fill 283 189 290 283 189 293 minecraft:iron_block
fill 283 189 300 283 189 303 minecraft:iron_block
fill 283 189 310 283 189 313 minecraft:iron_block
fill 284 189 276 287 189 276 minecraft:iron_block
fill 287 189 316 290 189 316 minecraft:iron_block
fill 294 189 276 297 189 276 minecraft:iron_block
fill 297 189 316 300 189 316 minecraft:iron_block
fill 304 189 276 307 189 276 minecraft:iron_block
fill 307 189 316 310 189 316 minecraft:iron_block
fill 309 189 275 309 201 275 minecraft:gray_concrete
fill 314 189 276 317 189 276 minecraft:iron_block
fill 317 189 316 320 189 316 minecraft:iron_block
fill 323 189 277 323 189 280 minecraft:iron_block
fill 323 189 287 323 189 290 minecraft:iron_block
fill 323 189 297 323 189 300 minecraft:iron_block
fill 323 189 307 323 189 310 minecraft:iron_block
fill 286 190 278 286 191 278 minecraft:light_gray_concrete
fill 286 190 280 286 191 280 minecraft:light_gray_concrete
fill 287 190 281 287 191 281 minecraft:light_gray_concrete
fill 288 190 277 288 191 277 minecraft:light_gray_concrete
fill 289 190 278 289 191 278 minecraft:light_gray_concrete
fill 289 190 281 289 191 281 minecraft:light_gray_concrete
fill 290 190 279 290 191 280 minecraft:light_gray_concrete
fill 296 190 278 296 191 282 minecraft:iron_block
fill 297 190 277 297 191 278 minecraft:iron_block
fill 297 190 280 302 191 280 minecraft:iron_block
fill 297 190 282 297 191 283 minecraft:iron_block
fill 298 190 277 301 191 277 minecraft:iron_block
fill 298 190 283 301 191 283 minecraft:iron_block
fill 299 190 278 299 191 279 minecraft:iron_block
fill 299 190 281 299 191 282 minecraft:iron_block
fill 301 190 278 302 191 278 minecraft:iron_block
fill 301 190 282 302 191 282 minecraft:iron_block
fill 302 190 279 302 191 279 minecraft:iron_block
fill 302 190 281 302 191 281 minecraft:iron_block
fill 310 190 275 313 201 275 minecraft:gray_concrete
setblock 314 190 275 minecraft:sea_lantern
fill 296 191 317 298 201 317 minecraft:gray_concrete
setblock 299 191 317 minecraft:redstone_block
fill 314 191 275 314 201 275 minecraft:gray_concrete
fill 299 192 317 299 201 317 minecraft:gray_concrete
setblock 285 193 278 minecraft:light[level=15]
setblock 285 193 285 minecraft:light[level=12]
setblock 285 193 286 minecraft:light[level=15]
setblock 285 193 292 minecraft:light[level=12]
setblock 285 193 294 minecraft:light[level=15]
setblock 285 193 299 minecraft:light[level=12]
setblock 285 193 302 minecraft:light[level=15]
setblock 285 193 306 minecraft:light[level=12]
setblock 285 193 310 minecraft:light[level=15]
setblock 285 193 313 minecraft:light[level=12]
setblock 292 193 278 minecraft:light[level=12]
setblock 292 193 285 minecraft:light[level=12]
setblock 292 193 292 minecraft:light[level=12]
setblock 292 193 299 minecraft:light[level=12]
setblock 292 193 306 minecraft:light[level=12]
setblock 292 193 313 minecraft:light[level=12]
setblock 293 193 278 minecraft:light[level=15]
setblock 293 193 286 minecraft:light[level=15]
setblock 293 193 294 minecraft:light[level=15]
setblock 293 193 302 minecraft:light[level=15]
setblock 293 193 310 minecraft:light[level=15]
setblock 299 193 278 minecraft:light[level=12]
setblock 299 193 285 minecraft:light[level=12]
setblock 299 193 292 minecraft:light[level=12]
setblock 299 193 299 minecraft:light[level=12]
setblock 299 193 306 minecraft:light[level=12]
setblock 299 193 313 minecraft:light[level=12]
setblock 301 193 278 minecraft:light[level=15]
setblock 301 193 286 minecraft:light[level=15]
setblock 301 193 294 minecraft:light[level=15]
setblock 301 193 302 minecraft:light[level=15]
setblock 301 193 310 minecraft:light[level=15]
setblock 306 193 278 minecraft:light[level=12]
setblock 306 193 285 minecraft:light[level=12]
setblock 306 193 292 minecraft:light[level=12]
setblock 306 193 299 minecraft:light[level=12]
setblock 306 193 306 minecraft:light[level=12]
setblock 306 193 313 minecraft:light[level=12]
setblock 309 193 278 minecraft:light[level=15]
setblock 309 193 286 minecraft:light[level=15]
setblock 309 193 294 minecraft:light[level=15]
setblock 309 193 302 minecraft:light[level=15]
setblock 309 193 310 minecraft:light[level=15]
setblock 313 193 278 minecraft:light[level=12]
setblock 313 193 285 minecraft:light[level=12]
setblock 313 193 292 minecraft:light[level=12]
setblock 313 193 299 minecraft:light[level=12]
setblock 313 193 306 minecraft:light[level=12]
setblock 313 193 313 minecraft:light[level=12]
setblock 317 193 278 minecraft:light[level=15]
setblock 317 193 286 minecraft:light[level=15]
setblock 317 193 294 minecraft:light[level=15]
setblock 317 193 302 minecraft:light[level=15]
setblock 317 193 310 minecraft:light[level=15]
setblock 320 193 278 minecraft:light[level=12]
setblock 320 193 285 minecraft:light[level=12]
setblock 320 193 292 minecraft:light[level=12]
setblock 320 193 299 minecraft:light[level=12]
setblock 320 193 306 minecraft:light[level=12]
setblock 320 193 313 minecraft:light[level=12]
setblock 282 195 280 minecraft:sea_lantern
fill 295 195 275 295 201 275 minecraft:gray_concrete
setblock 296 195 275 minecraft:sea_lantern
fill 297 195 275 298 201 275 minecraft:gray_concrete
setblock 324 195 284 minecraft:redstone_block
fill 324 195 285 324 201 288 minecraft:gray_concrete
setblock 324 195 289 minecraft:redstone_block
fill 282 196 280 282 201 280 minecraft:gray_concrete
fill 296 196 275 296 201 275 minecraft:gray_concrete
fill 324 196 284 324 201 284 minecraft:gray_concrete
fill 324 196 289 324 201 289 minecraft:gray_concrete
fill 292 197 297 299 197 297 minecraft:light_gray_concrete
fill 293 197 296 300 197 296 minecraft:light_gray_concrete
fill 293 197 299 293 197 301 minecraft:light_gray_concrete
fill 294 197 291 294 197 293 minecraft:light_gray_concrete
fill 294 197 299 300 197 300 minecraft:light_gray_concrete
fill 295 197 292 300 197 295 minecraft:light_gray_concrete
fill 295 197 298 300 197 298 minecraft:light_gray_concrete
fill 295 197 301 312 197 301 minecraft:light_gray_concrete
fill 295 197 303 296 197 304 minecraft:light_gray_concrete
fill 296 197 289 297 197 290 minecraft:light_gray_concrete
fill 296 197 302 312 197 302 minecraft:light_gray_concrete
fill 297 197 291 311 197 291 minecraft:light_gray_concrete
fill 297 197 303 309 197 303 minecraft:light_gray_concrete
fill 297 197 306 299 197 306 minecraft:light_gray_concrete
fill 298 197 290 308 197 290 minecraft:light_gray_concrete
fill 298 197 304 307 197 305 minecraft:light_gray_concrete
fill 299 197 287 301 197 287 minecraft:light_gray_concrete
fill 299 197 289 308 197 289 minecraft:light_gray_concrete
fill 300 197 288 301 197 288 minecraft:light_gray_concrete
fill 301 197 292 302 197 294 minecraft:light_gray_concrete
fill 301 197 300 302 197 300 minecraft:light_gray_concrete
fill 302 197 306 303 197 307 minecraft:light_gray_concrete
fill 303 197 286 303 197 288 minecraft:light_gray_concrete
fill 303 197 292 310 197 293 minecraft:light_gray_concrete
setblock 303 197 308 minecraft:light_gray_concrete
fill 304 197 287 304 197 288 minecraft:light_gray_concrete
fill 304 197 294 313 197 294 minecraft:light_gray_concrete
fill 304 197 300 311 197 300 minecraft:light_gray_concrete
fill 305 197 306 306 197 307 minecraft:light_gray_concrete
fill 306 197 295 311 197 296 minecraft:light_gray_concrete
fill 306 197 298 311 197 299 minecraft:light_gray_concrete
fill 307 197 288 309 197 288 minecraft:light_gray_concrete
fill 307 197 297 314 197 297 minecraft:light_gray_concrete
setblock 307 197 307 minecraft:light_gray_concrete
fill 308 197 304 310 197 304 minecraft:light_gray_concrete
fill 309 197 305 310 197 305 minecraft:light_gray_concrete
fill 310 197 290 311 197 290 minecraft:light_gray_concrete
setblock 311 197 293 minecraft:light_gray_concrete
fill 312 197 295 313 197 295 minecraft:light_gray_concrete
fill 312 197 298 313 197 298 minecraft:light_gray_concrete
setblock 312 197 303 minecraft:light_gray_concrete
setblock 313 197 293 minecraft:light_gray_concrete
fill 283 198 276 323 198 277 minecraft:black_concrete
fill 283 198 278 323 198 278 minecraft:yellow_concrete
fill 283 198 279 323 198 280 minecraft:black_concrete
fill 283 198 281 323 198 281 minecraft:yellow_concrete
fill 283 198 282 323 198 283 minecraft:black_concrete
fill 283 198 284 323 198 284 minecraft:yellow_concrete
fill 283 198 285 299 198 286 minecraft:black_concrete
fill 283 198 287 294 198 287 minecraft:yellow_concrete
fill 283 198 288 294 198 289 minecraft:black_concrete
fill 283 198 290 294 198 290 minecraft:yellow_concrete
fill 283 198 291 290 198 292 minecraft:black_concrete
fill 283 198 293 291 198 293 minecraft:yellow_concrete
fill 283 198 294 292 198 295 minecraft:black_concrete
fill 283 198 296 290 198 296 minecraft:yellow_concrete
fill 283 198 297 289 198 298 minecraft:black_concrete
fill 283 198 299 292 198 299 minecraft:yellow_concrete
fill 283 198 300 291 198 301 minecraft:black_concrete
fill 283 198 302 290 198 302 minecraft:yellow_concrete
fill 283 198 303 291 198 304 minecraft:black_concrete
fill 283 198 305 295 198 305 minecraft:yellow_concrete
fill 283 198 306 294 198 307 minecraft:black_concrete
fill 283 198 308 299 198 308 minecraft:yellow_concrete
fill 283 198 309 299 198 310 minecraft:black_concrete
fill 283 198 311 323 198 311 minecraft:yellow_concrete
fill 283 198 312 323 198 313 minecraft:black_concrete
fill 283 198 314 323 198 314 minecraft:yellow_concrete
fill 283 198 315 323 198 316 minecraft:black_concrete
fill 290 198 297 298 199 297 minecraft:iron_block
setblock 290 198 298 minecraft:black_concrete
setblock 291 198 291 minecraft:black_concrete
fill 291 198 292 315 199 292 minecraft:iron_block
fill 291 198 296 291 199 296 minecraft:iron_block
fill 291 198 298 291 199 298 minecraft:iron_block
fill 291 198 302 315 199 302 minecraft:iron_block
fill 292 198 291 314 199 291 minecraft:iron_block
fill 292 198 293 300 199 293 minecraft:iron_block
setblock 292 198 296 minecraft:yellow_concrete
setblock 292 198 298 minecraft:black_concrete
setblock 292 198 300 minecraft:black_concrete
fill 292 198 301 300 199 301 minecraft:iron_block
fill 292 198 303 314 199 303 minecraft:iron_block
fill 292 198 304 294 198 304 minecraft:black_concrete
fill 293 198 294 298 199 296 minecraft:iron_block
fill 293 198 298 298 199 300 minecraft:iron_block
fill 295 198 287 296 199 288 minecraft:iron_block
setblock 295 198 289 minecraft:black_concrete
fill 295 198 290 311 199 290 minecraft:iron_block
fill 295 198 304 311 199 304 minecraft:iron_block
fill 295 198 306 296 199 307 minecraft:iron_block
fill 296 198 289 310 199 289 minecraft:iron_block
fill 296 198 305 310 199 305 minecraft:iron_block
fill 297 198 287 298 198 287 minecraft:yellow_concrete
fill 297 198 288 311 199 288 minecraft:iron_block
fill 297 198 306 311 199 306 minecraft:iron_block
fill 297 198 307 298 198 307 minecraft:black_concrete
fill 299 198 287 307 199 287 minecraft:iron_block
fill 299 198 294 299 199 294 minecraft:iron_block
fill 299 198 295 299 200 299 minecraft:waxed_copper_block
fill 299 198 300 299 199 300 minecraft:iron_block
fill 299 198 307 307 199 307 minecraft:iron_block
fill 300 198 285 301 199 286 minecraft:iron_block
fill 300 198 294 300 199 295 minecraft:waxed_copper_block
setblock 300 198 296 minecraft:sea_lantern
setblock 300 198 298 minecraft:sea_lantern
fill 300 198 299 300 199 300 minecraft:waxed_copper_block
fill 300 198 308 301 199 309 minecraft:iron_block
fill 300 198 310 323 198 310 minecraft:black_concrete
fill 301 198 293 301 199 294 minecraft:waxed_copper_block
fill 301 198 300 301 199 301 minecraft:waxed_copper_block
fill 302 198 285 302 198 286 minecraft:black_concrete
fill 302 198 293 305 200 293 minecraft:waxed_copper_block
setblock 302 198 294 minecraft:sea_lantern
setblock 302 198 300 minecraft:sea_lantern
fill 302 198 301 305 200 301 minecraft:waxed_copper_block
setblock 302 198 308 minecraft:yellow_concrete
fill 302 198 309 304 198 309 minecraft:black_concrete
fill 303 198 285 304 198 285 minecraft:black_concrete
fill 303 198 286 303 199 286 minecraft:iron_block
fill 303 198 308 303 199 308 minecraft:iron_block
setblock 304 198 286 minecraft:black_concrete
setblock 304 198 294 minecraft:sea_lantern
setblock 304 198 300 minecraft:sea_lantern
setblock 304 198 308 minecraft:yellow_concrete
fill 305 198 285 306 199 286 minecraft:iron_block
fill 305 198 294 306 199 294 minecraft:waxed_copper_block
fill 305 198 300 306 199 300 minecraft:waxed_copper_block
fill 305 198 308 306 199 309 minecraft:iron_block
fill 306 198 293 314 199 293 minecraft:iron_block
fill 306 198 295 307 199 295 minecraft:waxed_copper_block
setblock 306 198 296 minecraft:sea_lantern
setblock 306 198 298 minecraft:sea_lantern
fill 306 198 299 307 199 299 minecraft:waxed_copper_block
fill 306 198 301 314 199 301 minecraft:iron_block
fill 307 198 285 323 198 286 minecraft:black_concrete
fill 307 198 294 313 199 294 minecraft:iron_block
fill 307 198 296 307 200 298 minecraft:waxed_copper_block
fill 307 198 300 313 199 300 minecraft:iron_block
fill 307 198 308 323 198 308 minecraft:yellow_concrete
fill 307 198 309 323 198 309 minecraft:black_concrete
fill 308 198 287 309 198 287 minecraft:yellow_concrete
fill 308 198 295 313 199 299 minecraft:iron_block
fill 308 198 307 309 198 307 minecraft:black_concrete
fill 310 198 287 311 199 287 minecraft:iron_block
fill 310 198 307 311 199 307 minecraft:iron_block
fill 311 198 289 323 198 289 minecraft:black_concrete
fill 311 198 305 323 198 305 minecraft:yellow_concrete
fill 312 198 287 323 198 287 minecraft:yellow_concrete
fill 312 198 288 323 198 288 minecraft:black_concrete
fill 312 198 290 323 198 290 minecraft:yellow_concrete
fill 312 198 304 323 198 304 minecraft:black_concrete
fill 312 198 306 323 198 307 minecraft:black_concrete
fill 314 198 294 323 198 295 minecraft:black_concrete
setblock 314 198 296 minecraft:yellow_concrete
fill 314 198 297 316 199 297 minecraft:iron_block
setblock 314 198 298 minecraft:black_concrete
fill 314 198 299 323 198 299 minecraft:yellow_concrete
fill 314 198 300 323 198 300 minecraft:black_concrete
fill 315 198 291 323 198 291 minecraft:black_concrete
fill 315 198 293 323 198 293 minecraft:yellow_concrete
fill 315 198 296 315 199 296 minecraft:iron_block
fill 315 198 298 315 199 298 minecraft:iron_block
fill 315 198 301 323 198 301 minecraft:black_concrete
fill 315 198 303 323 198 303 minecraft:black_concrete
fill 316 198 292 323 198 292 minecraft:black_concrete
fill 316 198 296 323 198 296 minecraft:yellow_concrete
fill 316 198 298 323 198 298 minecraft:black_concrete
fill 316 198 302 323 198 302 minecraft:yellow_concrete
fill 317 198 297 323 198 297 minecraft:black_concrete
setblock 282 199 305 minecraft:sea_lantern
fill 282 199 306 282 201 307 minecraft:gray_concrete
setblock 285 199 275 minecraft:sea_lantern
setblock 285 199 278 minecraft:light[level=12]
setblock 285 199 285 minecraft:light[level=12]
setblock 285 199 292 minecraft:light[level=12]
setblock 285 199 299 minecraft:light[level=12]
setblock 285 199 306 minecraft:light[level=12]
setblock 285 199 313 minecraft:light[level=12]
fill 286 199 275 288 201 275 minecraft:gray_concrete
setblock 292 199 278 minecraft:light[level=12]
setblock 292 199 285 minecraft:light[level=12]
setblock 292 199 299 minecraft:light[level=12]
setblock 292 199 306 minecraft:light[level=12]
setblock 292 199 313 minecraft:light[level=12]
setblock 299 199 278 minecraft:light[level=12]
setblock 299 199 285 minecraft:light[level=12]
setblock 299 199 313 minecraft:light[level=12]
setblock 306 199 278 minecraft:light[level=12]
setblock 306 199 313 minecraft:light[level=12]
setblock 313 199 278 minecraft:light[level=12]
setblock 313 199 285 minecraft:light[level=12]
setblock 313 199 306 minecraft:light[level=12]
setblock 313 199 313 minecraft:light[level=12]
setblock 320 199 278 minecraft:light[level=12]
setblock 320 199 285 minecraft:light[level=12]
setblock 320 199 292 minecraft:light[level=12]
setblock 320 199 299 minecraft:light[level=12]
setblock 320 199 306 minecraft:light[level=12]
setblock 320 199 313 minecraft:light[level=12]
fill 282 200 305 282 201 305 minecraft:gray_concrete
fill 285 200 275 285 201 275 minecraft:gray_concrete
fill 296 200 295 296 200 299 minecraft:waxed_oxidized_copper
fill 297 200 293 297 200 294 minecraft:waxed_oxidized_copper
fill 297 200 300 297 200 301 minecraft:waxed_oxidized_copper
setblock 298 200 292 minecraft:waxed_oxidized_copper
setblock 298 200 302 minecraft:waxed_oxidized_copper
fill 299 200 291 300 200 291 minecraft:waxed_oxidized_copper
fill 299 200 303 300 200 303 minecraft:waxed_oxidized_copper
setblock 300 200 294 minecraft:waxed_copper_block
setblock 300 200 300 minecraft:waxed_copper_block
fill 301 200 290 305 200 290 minecraft:waxed_oxidized_copper
setblock 301 200 293 minecraft:waxed_copper_block
setblock 301 200 301 minecraft:waxed_copper_block
fill 301 200 304 305 200 304 minecraft:waxed_oxidized_copper
fill 306 200 291 307 200 291 minecraft:waxed_oxidized_copper
setblock 306 200 294 minecraft:waxed_copper_block
setblock 306 200 300 minecraft:waxed_copper_block
fill 306 200 303 307 200 303 minecraft:waxed_oxidized_copper
setblock 307 200 295 minecraft:waxed_copper_block
setblock 307 200 299 minecraft:waxed_copper_block
setblock 308 200 292 minecraft:waxed_oxidized_copper
setblock 308 200 302 minecraft:waxed_oxidized_copper
fill 309 200 293 309 200 294 minecraft:waxed_oxidized_copper
fill 309 200 300 309 200 301 minecraft:waxed_oxidized_copper
fill 310 200 295 310 200 299 minecraft:waxed_oxidized_copper
fill 316 200 292 316 207 292 minecraft:iron_block
fill 282 201 311 282 201 313 minecraft:gray_concrete
setblock 282 201 314 minecraft:redstone_block
setblock 285 201 278 minecraft:light[level=15]
setblock 285 201 286 minecraft:light[level=15]
setblock 285 201 294 minecraft:light[level=15]
setblock 285 201 302 minecraft:light[level=15]
setblock 285 201 310 minecraft:light[level=15]
setblock 293 201 278 minecraft:light[level=15]
setblock 293 201 286 minecraft:light[level=15]
setblock 293 201 294 minecraft:light[level=15]
setblock 293 201 302 minecraft:light[level=15]
setblock 293 201 310 minecraft:light[level=15]
setblock 301 201 278 minecraft:light[level=15]
setblock 301 201 286 minecraft:light[level=15]
setblock 301 201 302 minecraft:light[level=15]
setblock 301 201 310 minecraft:light[level=15]
setblock 309 201 278 minecraft:light[level=15]
setblock 309 201 286 minecraft:light[level=15]
setblock 309 201 294 minecraft:light[level=15]
setblock 309 201 302 minecraft:light[level=15]
setblock 309 201 310 minecraft:light[level=15]
fill 316 201 291 316 206 291 minecraft:iron_block
setblock 317 201 278 minecraft:light[level=15]
setblock 317 201 286 minecraft:light[level=15]
setblock 317 201 294 minecraft:light[level=15]
setblock 317 201 302 minecraft:light[level=15]
setblock 317 201 310 minecraft:light[level=15]
fill 282 202 275 282 203 276 minecraft:yellow_concrete
fill 282 202 277 282 203 278 minecraft:black_concrete
fill 282 202 279 282 203 280 minecraft:yellow_concrete
fill 282 202 281 282 202 284 minecraft:pearlescent_froglight
fill 282 202 285 282 203 286 minecraft:black_concrete
fill 282 202 287 282 203 288 minecraft:yellow_concrete
fill 282 202 289 282 203 290 minecraft:black_concrete
fill 282 202 291 282 202 294 minecraft:pearlescent_froglight
fill 282 202 295 282 203 296 minecraft:yellow_concrete
fill 282 202 297 282 203 298 minecraft:black_concrete
fill 282 202 299 282 203 300 minecraft:yellow_concrete
fill 282 202 301 282 202 304 minecraft:pearlescent_froglight
fill 282 202 305 282 203 306 minecraft:black_concrete
fill 282 202 307 282 203 308 minecraft:yellow_concrete
fill 282 202 309 282 203 310 minecraft:black_concrete
fill 282 202 311 282 202 314 minecraft:pearlescent_froglight
fill 282 202 315 282 203 316 minecraft:yellow_concrete
fill 282 202 317 282 203 317 minecraft:black_concrete
fill 283 202 275 283 203 275 minecraft:yellow_concrete
fill 283 202 277 283 270 277 minecraft:iron_block
fill 283 202 287 283 270 287 minecraft:iron_block
fill 283 202 297 283 270 297 minecraft:iron_block
fill 283 202 307 283 270 307 minecraft:iron_block
fill 283 202 317 283 203 317 minecraft:yellow_concrete
fill 284 202 275 284 203 275 minecraft:black_concrete
fill 284 202 316 284 270 316 minecraft:iron_block
fill 284 202 317 285 203 317 minecraft:black_concrete
fill 285 202 275 288 202 275 minecraft:pearlescent_froglight
fill 285 202 311 285 202 314 minecraft:gray_concrete
setblock 286 202 278 minecraft:gray_concrete
fill 286 202 279 289 270 280 minecraft:iron_block
setblock 286 202 281 minecraft:gray_concrete
fill 286 202 310 288 202 310 minecraft:gray_concrete
fill 286 202 311 288 223 313 minecraft:iron_block
setblock 286 202 314 minecraft:gray_concrete
fill 286 202 317 289 202 317 minecraft:pearlescent_froglight
fill 287 202 278 288 270 278 minecraft:iron_block
fill 287 202 281 288 270 281 minecraft:iron_block
fill 287 202 282 288 202 282 minecraft:gray_concrete
fill 287 202 314 287 270 314 minecraft:iron_block
setblock 288 202 314 minecraft:gray_concrete
fill 289 202 275 289 203 275 minecraft:black_concrete
setblock 289 202 278 minecraft:gray_concrete
setblock 289 202 281 minecraft:gray_concrete
fill 289 202 311 289 202 313 minecraft:gray_concrete
fill 290 202 275 291 203 275 minecraft:yellow_concrete
fill 290 202 276 290 270 276 minecraft:iron_block
fill 290 202 279 290 202 280 minecraft:gray_concrete
fill 290 202 307 302 204 316 minecraft:iron_block
fill 290 202 317 291 203 317 minecraft:yellow_concrete
fill 292 202 275 293 203 275 minecraft:black_concrete
fill 292 202 317 293 203 317 minecraft:black_concrete
fill 294 202 275 294 203 275 minecraft:yellow_concrete
fill 294 202 317 295 203 317 minecraft:yellow_concrete
fill 295 202 275 298 202 275 minecraft:pearlescent_froglight
fill 296 202 317 299 202 317 minecraft:pearlescent_froglight
fill 298 202 276 304 204 279 minecraft:iron_block
fill 299 202 275 299 203 275 minecraft:yellow_concrete
fill 300 202 275 301 203 275 minecraft:black_concrete
fill 300 202 317 301 203 317 minecraft:black_concrete
fill 302 202 275 303 203 275 minecraft:yellow_concrete
fill 302 202 317 303 203 317 minecraft:yellow_concrete
fill 304 202 275 304 203 275 minecraft:black_concrete
fill 304 202 316 304 270 316 minecraft:iron_block
fill 304 202 317 305 203 317 minecraft:black_concrete
fill 305 202 275 308 202 275 minecraft:pearlescent_froglight
fill 306 202 317 309 202 317 minecraft:pearlescent_froglight
fill 309 202 275 309 203 275 minecraft:black_concrete
fill 310 202 275 311 203 275 minecraft:yellow_concrete
fill 310 202 276 310 270 276 minecraft:iron_block
fill 310 202 317 311 203 317 minecraft:yellow_concrete
fill 312 202 275 313 203 275 minecraft:black_concrete
fill 312 202 317 313 203 317 minecraft:black_concrete
fill 314 202 275 314 203 275 minecraft:yellow_concrete
fill 314 202 316 314 270 316 minecraft:iron_block
fill 314 202 317 315 203 317 minecraft:yellow_concrete
fill 315 202 275 318 202 275 minecraft:pearlescent_froglight
fill 316 202 317 319 202 317 minecraft:pearlescent_froglight
fill 319 202 275 319 203 275 minecraft:yellow_concrete
fill 320 202 275 321 203 275 minecraft:black_concrete
fill 320 202 276 320 270 276 minecraft:iron_block
fill 320 202 317 321 203 317 minecraft:black_concrete
fill 322 202 275 323 203 275 minecraft:yellow_concrete
fill 322 202 317 323 203 317 minecraft:yellow_concrete
fill 323 202 283 323 270 283 minecraft:iron_block
fill 323 202 293 323 270 293 minecraft:iron_block
fill 323 202 303 323 270 303 minecraft:iron_block
fill 323 202 313 323 270 313 minecraft:iron_block
fill 324 202 275 324 203 275 minecraft:black_concrete
fill 324 202 276 324 202 279 minecraft:pearlescent_froglight
fill 324 202 280 324 203 280 minecraft:yellow_concrete
fill 324 202 281 324 203 282 minecraft:black_concrete
fill 324 202 283 324 203 284 minecraft:yellow_concrete
fill 324 202 285 324 203 285 minecraft:black_concrete
fill 324 202 286 324 202 289 minecraft:pearlescent_froglight
fill 324 202 290 324 203 290 minecraft:black_concrete
fill 324 202 291 324 203 292 minecraft:yellow_concrete
fill 324 202 293 324 203 294 minecraft:black_concrete
fill 324 202 295 324 203 295 minecraft:yellow_concrete
fill 324 202 296 324 202 299 minecraft:pearlescent_froglight
fill 324 202 300 324 203 300 minecraft:yellow_concrete
fill 324 202 301 324 203 302 minecraft:black_concrete
fill 324 202 303 324 203 304 minecraft:yellow_concrete
fill 324 202 305 324 203 305 minecraft:black_concrete
fill 324 202 306 324 202 309 minecraft:pearlescent_froglight
fill 324 202 310 324 203 310 minecraft:black_concrete
fill 324 202 311 324 203 312 minecraft:yellow_concrete
fill 324 202 313 324 203 314 minecraft:black_concrete
fill 324 202 315 324 203 315 minecraft:yellow_concrete
setblock 324 202 316 minecraft:pearlescent_froglight
fill 324 202 317 324 203 317 minecraft:black_concrete
fill 282 203 281 282 203 282 minecraft:black_concrete
fill 282 203 283 282 203 284 minecraft:yellow_concrete
fill 282 203 291 282 203 292 minecraft:yellow_concrete
fill 282 203 293 282 203 294 minecraft:black_concrete
fill 282 203 301 282 203 302 minecraft:black_concrete
fill 282 203 303 282 203 304 minecraft:yellow_concrete
fill 282 203 311 282 203 312 minecraft:yellow_concrete
fill 282 203 313 282 203 314 minecraft:black_concrete
setblock 285 203 275 minecraft:black_concrete
fill 285 203 312 285 209 312 minecraft:iron_block
fill 286 203 275 287 203 275 minecraft:yellow_concrete
fill 286 203 317 287 203 317 minecraft:yellow_concrete
setblock 288 203 275 minecraft:black_concrete
fill 288 203 317 289 203 317 minecraft:black_concrete
setblock 295 203 275 minecraft:yellow_concrete
fill 296 203 275 297 203 275 minecraft:black_concrete
fill 296 203 317 297 203 317 minecraft:black_concrete
setblock 298 203 275 minecraft:yellow_concrete
fill 298 203 317 299 203 317 minecraft:yellow_concrete
setblock 305 203 275 minecraft:black_concrete
fill 306 203 275 307 203 275 minecraft:yellow_concrete
fill 306 203 317 307 203 317 minecraft:yellow_concrete
setblock 308 203 275 minecraft:black_concrete
fill 308 203 317 309 203 317 minecraft:black_concrete
setblock 315 203 275 minecraft:yellow_concrete
fill 316 203 275 317 203 275 minecraft:black_concrete
fill 316 203 317 317 203 317 minecraft:black_concrete
setblock 318 203 275 minecraft:yellow_concrete
fill 318 203 317 319 203 317 minecraft:yellow_concrete
setblock 324 203 276 minecraft:yellow_concrete
fill 324 203 277 324 203 278 minecraft:black_concrete
setblock 324 203 279 minecraft:yellow_concrete
setblock 324 203 286 minecraft:black_concrete
fill 324 203 287 324 203 288 minecraft:yellow_concrete
setblock 324 203 289 minecraft:black_concrete
setblock 324 203 296 minecraft:yellow_concrete
fill 324 203 297 324 203 298 minecraft:black_concrete
setblock 324 203 299 minecraft:yellow_concrete
setblock 324 203 306 minecraft:black_concrete
fill 324 203 307 324 203 308 minecraft:yellow_concrete
setblock 324 203 309 minecraft:black_concrete
setblock 324 203 316 minecraft:yellow_concrete
fill 282 204 275 283 204 275 minecraft:light_gray_concrete
fill 282 204 276 282 205 317 minecraft:gray_concrete
setblock 283 204 278 minecraft:iron_block
setblock 283 204 288 minecraft:iron_block
setblock 283 204 298 minecraft:iron_block
setblock 283 204 308 minecraft:iron_block
fill 283 204 317 283 205 317 minecraft:gray_concrete
fill 284 204 275 306 205 275 minecraft:gray_concrete
fill 284 204 311 284 204 313 minecraft:iron_block
setblock 284 204 317 minecraft:light_gray_concrete
setblock 285 204 311 minecraft:iron_block
setblock 285 204 313 minecraft:iron_block
setblock 285 204 316 minecraft:iron_block
fill 285 204 317 287 205 317 minecraft:gray_concrete
setblock 288 204 317 minecraft:light_gray_concrete
setblock 289 204 276 minecraft:iron_block
fill 289 204 317 293 205 317 minecraft:gray_concrete
setblock 294 204 317 minecraft:light_gray_concrete
fill 295 204 317 304 205 317 minecraft:gray_concrete
setblock 305 204 316 minecraft:iron_block
setblock 305 204 317 minecraft:light_gray_concrete
fill 306 204 317 306 205 317 minecraft:gray_concrete
setblock 307 204 275 minecraft:light_gray_concrete
fill 307 204 294 311 204 294 minecraft:waxed_copper_block
fill 307 204 300 311 204 300 minecraft:waxed_copper_block
setblock 307 204 317 minecraft:light_gray_concrete
fill 308 204 275 309 205 275 minecraft:gray_concrete
fill 308 204 293 316 205 293 minecraft:waxed_copper_block
fill 308 204 295 308 204 299 minecraft:waxed_copper_block
fill 308 204 301 316 205 301 minecraft:waxed_copper_block
fill 308 204 317 315 205 317 minecraft:gray_concrete
setblock 309 204 276 minecraft:iron_block
fill 309 204 292 315 205 292 minecraft:waxed_copper_block
fill 309 204 295 309 205 296 minecraft:waxed_copper_block
fill 309 204 298 309 205 299 minecraft:waxed_copper_block
fill 309 204 302 315 205 302 minecraft:waxed_copper_block
setblock 310 204 275 minecraft:light_gray_concrete
fill 311 204 275 324 205 275 minecraft:gray_concrete
fill 312 204 291 312 205 291 minecraft:waxed_copper_block
fill 312 204 303 312 205 303 minecraft:waxed_copper_block
fill 313 204 294 317 205 294 minecraft:waxed_copper_block
fill 313 204 300 317 205 300 minecraft:waxed_copper_block
fill 315 204 295 317 205 296 minecraft:waxed_copper_block
fill 315 204 298 317 205 299 minecraft:waxed_copper_block
setblock 315 204 316 minecraft:iron_block
fill 316 204 297 318 205 297 minecraft:waxed_copper_block
fill 316 204 317 318 204 317 minecraft:light_gray_concrete
setblock 319 204 276 minecraft:iron_block
fill 319 204 317 322 205 317 minecraft:gray_concrete
setblock 323 204 282 minecraft:iron_block
setblock 323 204 292 minecraft:iron_block
setblock 323 204 302 minecraft:iron_block
setblock 323 204 312 minecraft:iron_block
setblock 323 204 317 minecraft:light_gray_concrete
fill 324 204 276 324 205 277 minecraft:gray_concrete
setblock 324 204 278 minecraft:light_gray_concrete
fill 324 204 279 324 205 282 minecraft:gray_concrete
setblock 324 204 283 minecraft:light_gray_concrete
fill 324 204 284 324 205 288 minecraft:gray_concrete
setblock 324 204 289 minecraft:light_gray_concrete
fill 324 204 290 324 205 296 minecraft:gray_concrete
setblock 324 204 297 minecraft:light_gray_concrete
fill 324 204 298 324 205 303 minecraft:gray_concrete
setblock 324 204 304 minecraft:light_gray_concrete
fill 324 204 305 324 205 314 minecraft:gray_concrete
setblock 324 204 315 minecraft:light_gray_concrete
fill 324 204 316 324 205 317 minecraft:gray_concrete
fill 282 205 275 283 205 275 minecraft:gray_concrete
setblock 284 205 317 minecraft:gray_concrete
setblock 285 205 278 minecraft:light[level=12]
setblock 285 205 285 minecraft:light[level=12]
setblock 285 205 292 minecraft:light[level=12]
setblock 285 205 299 minecraft:light[level=12]
setblock 285 205 306 minecraft:light[level=12]
setblock 285 205 313 minecraft:light[level=12]
setblock 288 205 317 minecraft:gray_concrete
setblock 290 205 307 minecraft:pearlescent_froglight
fill 290 205 308 290 214 308 minecraft:iron_block
setblock 290 205 309 minecraft:pearlescent_froglight
fill 290 205 310 290 214 310 minecraft:iron_block
setblock 290 205 311 minecraft:pearlescent_froglight
fill 290 205 312 290 214 312 minecraft:iron_block
setblock 290 205 313 minecraft:pearlescent_froglight
fill 290 205 314 290 214 314 minecraft:iron_block
setblock 290 205 315 minecraft:pearlescent_froglight
fill 290 205 316 290 214 316 minecraft:iron_block
fill 291 205 307 291 214 307 minecraft:iron_block
setblock 291 205 308 minecraft:pearlescent_froglight
fill 291 205 309 291 214 309 minecraft:iron_block
setblock 291 205 310 minecraft:pearlescent_froglight
fill 291 205 311 291 214 311 minecraft:iron_block
setblock 291 205 312 minecraft:pearlescent_froglight
fill 291 205 313 291 214 313 minecraft:iron_block
setblock 291 205 314 minecraft:pearlescent_froglight
fill 291 205 315 291 214 315 minecraft:iron_block
setblock 291 205 316 minecraft:pearlescent_froglight
setblock 292 205 278 minecraft:light[level=12]
setblock 292 205 285 minecraft:light[level=12]
setblock 292 205 292 minecraft:light[level=12]
setblock 292 205 299 minecraft:light[level=12]
setblock 292 205 306 minecraft:light[level=12]
setblock 292 205 307 minecraft:pearlescent_froglight
fill 292 205 308 292 214 308 minecraft:iron_block
setblock 292 205 309 minecraft:pearlescent_froglight
fill 292 205 310 292 214 310 minecraft:iron_block
setblock 292 205 311 minecraft:pearlescent_froglight
fill 292 205 312 292 214 312 minecraft:iron_block
setblock 292 205 313 minecraft:pearlescent_froglight
fill 292 205 314 292 214 314 minecraft:iron_block
setblock 292 205 315 minecraft:pearlescent_froglight
fill 292 205 316 292 214 316 minecraft:iron_block
fill 293 205 307 293 214 307 minecraft:iron_block
setblock 293 205 308 minecraft:pearlescent_froglight
fill 293 205 309 293 214 309 minecraft:iron_block
setblock 293 205 310 minecraft:pearlescent_froglight
fill 293 205 311 293 214 311 minecraft:iron_block
setblock 293 205 312 minecraft:pearlescent_froglight
fill 293 205 313 293 214 313 minecraft:iron_block
setblock 293 205 314 minecraft:pearlescent_froglight
fill 293 205 315 293 214 315 minecraft:iron_block
setblock 293 205 316 minecraft:pearlescent_froglight
setblock 294 205 307 minecraft:pearlescent_froglight
fill 294 205 308 294 214 308 minecraft:iron_block
setblock 294 205 309 minecraft:pearlescent_froglight
fill 294 205 310 294 214 310 minecraft:iron_block
setblock 294 205 311 minecraft:pearlescent_froglight
fill 294 205 312 294 214 312 minecraft:iron_block
setblock 294 205 313 minecraft:pearlescent_froglight
fill 294 205 314 294 214 314 minecraft:iron_block
setblock 294 205 315 minecraft:pearlescent_froglight
fill 294 205 316 294 270 316 minecraft:iron_block
fill 294 205 317 294 206 317 minecraft:gray_concrete
fill 295 205 307 295 214 307 minecraft:iron_block
setblock 295 205 308 minecraft:pearlescent_froglight
fill 295 205 309 295 214 309 minecraft:iron_block
setblock 295 205 310 minecraft:pearlescent_froglight
fill 295 205 311 295 214 311 minecraft:iron_block
setblock 295 205 312 minecraft:pearlescent_froglight
fill 295 205 313 295 214 313 minecraft:iron_block
setblock 295 205 314 minecraft:pearlescent_froglight
fill 295 205 315 295 214 315 minecraft:iron_block
setblock 295 205 316 minecraft:pearlescent_froglight
setblock 296 205 307 minecraft:pearlescent_froglight
fill 296 205 308 296 214 308 minecraft:iron_block
setblock 296 205 309 minecraft:pearlescent_froglight
fill 296 205 310 296 214 310 minecraft:iron_block
setblock 296 205 311 minecraft:pearlescent_froglight
fill 296 205 312 296 214 312 minecraft:iron_block
setblock 296 205 313 minecraft:pearlescent_froglight
fill 296 205 314 296 214 314 minecraft:iron_block
setblock 296 205 315 minecraft:pearlescent_froglight
fill 296 205 316 296 214 316 minecraft:iron_block
fill 297 205 307 297 214 307 minecraft:iron_block
setblock 297 205 308 minecraft:pearlescent_froglight
fill 297 205 309 297 214 309 minecraft:iron_block
setblock 297 205 310 minecraft:pearlescent_froglight
fill 297 205 311 297 214 311 minecraft:iron_block
setblock 297 205 312 minecraft:pearlescent_froglight
fill 297 205 313 297 214 313 minecraft:iron_block
setblock 297 205 314 minecraft:pearlescent_froglight
fill 297 205 315 297 214 315 minecraft:iron_block
setblock 297 205 316 minecraft:pearlescent_froglight
fill 298 205 276 298 223 276 minecraft:iron_block
setblock 298 205 277 minecraft:pearlescent_froglight
fill 298 205 278 298 223 278 minecraft:iron_block
setblock 298 205 279 minecraft:pearlescent_froglight
setblock 298 205 307 minecraft:pearlescent_froglight
fill 298 205 308 298 214 308 minecraft:iron_block
setblock 298 205 309 minecraft:pearlescent_froglight
fill 298 205 310 298 214 310 minecraft:iron_block
setblock 298 205 311 minecraft:pearlescent_froglight
fill 298 205 312 298 214 312 minecraft:iron_block
setblock 298 205 313 minecraft:pearlescent_froglight
fill 298 205 314 298 214 314 minecraft:iron_block
setblock 298 205 315 minecraft:pearlescent_froglight
fill 298 205 316 298 214 316 minecraft:iron_block
setblock 299 205 276 minecraft:pearlescent_froglight
fill 299 205 277 299 223 277 minecraft:iron_block
setblock 299 205 278 minecraft:pearlescent_froglight
fill 299 205 279 299 223 279 minecraft:iron_block
setblock 299 205 285 minecraft:light[level=12]
setblock 299 205 292 minecraft:light[level=12]
setblock 299 205 306 minecraft:light[level=12]
fill 299 205 307 299 214 307 minecraft:iron_block
setblock 299 205 308 minecraft:pearlescent_froglight
fill 299 205 309 299 214 309 minecraft:iron_block
setblock 299 205 310 minecraft:pearlescent_froglight
fill 299 205 311 299 214 311 minecraft:iron_block
setblock 299 205 312 minecraft:pearlescent_froglight
fill 299 205 313 299 270 313 minecraft:iron_block
setblock 299 205 314 minecraft:pearlescent_froglight
fill 299 205 315 299 214 315 minecraft:iron_block
setblock 299 205 316 minecraft:pearlescent_froglight
fill 300 205 276 300 270 276 minecraft:iron_block
setblock 300 205 277 minecraft:pearlescent_froglight
fill 300 205 278 300 223 278 minecraft:iron_block
setblock 300 205 279 minecraft:pearlescent_froglight
setblock 300 205 307 minecraft:pearlescent_froglight
fill 300 205 308 300 214 308 minecraft:iron_block
setblock 300 205 309 minecraft:pearlescent_froglight
fill 300 205 310 300 214 310 minecraft:iron_block
setblock 300 205 311 minecraft:pearlescent_froglight
fill 300 205 312 300 270 312 minecraft:iron_block
setblock 300 205 313 minecraft:pearlescent_froglight
fill 300 205 314 300 270 314 minecraft:iron_block
setblock 300 205 315 minecraft:pearlescent_froglight
fill 300 205 316 300 214 316 minecraft:iron_block
setblock 301 205 276 minecraft:pearlescent_froglight
fill 301 205 277 301 223 277 minecraft:iron_block
setblock 301 205 278 minecraft:pearlescent_froglight
fill 301 205 279 301 223 279 minecraft:iron_block
fill 301 205 307 301 214 307 minecraft:iron_block
setblock 301 205 308 minecraft:pearlescent_froglight
fill 301 205 309 301 214 309 minecraft:iron_block
setblock 301 205 310 minecraft:pearlescent_froglight
fill 301 205 311 301 214 311 minecraft:iron_block
setblock 301 205 312 minecraft:pearlescent_froglight
fill 301 205 313 301 270 313 minecraft:iron_block
setblock 301 205 314 minecraft:pearlescent_froglight
fill 301 205 315 301 214 315 minecraft:iron_block
setblock 301 205 316 minecraft:pearlescent_froglight
fill 302 205 276 302 223 276 minecraft:iron_block
setblock 302 205 277 minecraft:pearlescent_froglight
fill 302 205 278 302 223 278 minecraft:iron_block
setblock 302 205 279 minecraft:pearlescent_froglight
setblock 302 205 307 minecraft:pearlescent_froglight
fill 302 205 308 302 214 308 minecraft:iron_block
setblock 302 205 309 minecraft:pearlescent_froglight
fill 302 205 310 302 214 310 minecraft:iron_block
setblock 302 205 311 minecraft:pearlescent_froglight
fill 302 205 312 302 214 312 minecraft:iron_block
setblock 302 205 313 minecraft:pearlescent_froglight
fill 302 205 314 302 214 314 minecraft:iron_block
setblock 302 205 315 minecraft:pearlescent_froglight
fill 302 205 316 302 214 316 minecraft:iron_block
setblock 303 205 276 minecraft:pearlescent_froglight
fill 303 205 277 303 223 277 minecraft:iron_block
setblock 303 205 278 minecraft:pearlescent_froglight
fill 303 205 279 303 223 279 minecraft:iron_block
fill 304 205 276 304 223 276 minecraft:iron_block
setblock 304 205 277 minecraft:pearlescent_froglight
fill 304 205 278 304 223 278 minecraft:iron_block
setblock 304 205 279 minecraft:pearlescent_froglight
fill 305 205 317 305 206 317 minecraft:gray_concrete
setblock 306 205 278 minecraft:light[level=12]
setblock 306 205 285 minecraft:light[level=12]
setblock 306 205 292 minecraft:light[level=12]
setblock 306 205 306 minecraft:light[level=12]
setblock 306 205 313 minecraft:light[level=12]
setblock 307 205 275 minecraft:gray_concrete
setblock 307 205 317 minecraft:gray_concrete
fill 308 205 294 308 205 295 minecraft:waxed_copper_block
fill 308 205 299 308 205 300 minecraft:waxed_copper_block
fill 309 205 294 311 205 294 minecraft:waxed_copper_block
fill 309 205 300 311 205 300 minecraft:waxed_copper_block
setblock 310 205 275 minecraft:gray_concrete
setblock 313 205 278 minecraft:light[level=12]
setblock 313 205 285 minecraft:light[level=12]
setblock 313 205 299 minecraft:light[level=12]
setblock 313 205 306 minecraft:light[level=12]
setblock 313 205 313 minecraft:light[level=12]
fill 316 205 317 318 205 317 minecraft:gray_concrete
setblock 320 205 278 minecraft:light[level=12]
setblock 320 205 285 minecraft:light[level=12]
setblock 320 205 292 minecraft:light[level=12]
setblock 320 205 299 minecraft:light[level=12]
setblock 320 205 306 minecraft:light[level=12]
setblock 320 205 313 minecraft:light[level=12]
setblock 323 205 317 minecraft:gray_concrete
setblock 324 205 278 minecraft:gray_concrete
setblock 324 205 283 minecraft:gray_concrete
setblock 324 205 289 minecraft:gray_concrete
setblock 324 205 297 minecraft:gray_concrete
setblock 324 205 304 minecraft:gray_concrete
setblock 324 205 315 minecraft:gray_concrete
fill 282 206 275 282 207 275 minecraft:gray_concrete
fill 282 206 276 282 206 278 minecraft:light_gray_concrete
setblock 282 206 279 minecraft:gray_concrete
fill 282 206 280 282 210 281 minecraft:light_gray_concrete
fill 282 206 282 282 207 282 minecraft:gray_concrete
fill 282 206 283 282 207 291 minecraft:light_gray_concrete
setblock 282 206 292 minecraft:sea_lantern
fill 282 206 293 282 206 295 minecraft:light_gray_concrete
setblock 282 206 296 minecraft:gray_concrete
fill 282 206 297 282 206 307 minecraft:light_gray_concrete
setblock 282 206 308 minecraft:gray_concrete
fill 282 206 309 282 210 317 minecraft:light_gray_concrete
fill 283 206 275 295 206 275 minecraft:light_gray_concrete
fill 283 206 317 291 206 317 minecraft:light_gray_concrete
fill 290 206 307 290 207 307 minecraft:iron_block
fill 290 206 309 290 207 309 minecraft:iron_block
fill 290 206 311 290 207 311 minecraft:iron_block
fill 290 206 313 290 207 313 minecraft:iron_block
fill 290 206 315 290 207 315 minecraft:iron_block
fill 291 206 308 291 207 308 minecraft:iron_block
fill 291 206 310 291 207 310 minecraft:iron_block
fill 291 206 312 291 207 312 minecraft:iron_block
fill 291 206 314 291 207 314 minecraft:iron_block
fill 291 206 316 291 207 316 minecraft:iron_block
fill 292 206 307 292 207 307 minecraft:iron_block
fill 292 206 309 292 207 309 minecraft:iron_block
fill 292 206 311 292 207 311 minecraft:iron_block
fill 292 206 313 292 207 313 minecraft:iron_block
fill 292 206 315 292 207 315 minecraft:iron_block
setblock 292 206 317 minecraft:gray_concrete
fill 293 206 308 293 207 308 minecraft:iron_block
fill 293 206 310 293 207 310 minecraft:iron_block
fill 293 206 312 293 207 312 minecraft:iron_block
fill 293 206 314 293 207 314 minecraft:iron_block
fill 293 206 316 293 207 316 minecraft:iron_block
setblock 293 206 317 minecraft:light_gray_concrete
fill 294 206 307 294 207 307 minecraft:iron_block
fill 294 206 309 294 207 309 minecraft:iron_block
fill 294 206 311 294 207 311 minecraft:iron_block
fill 294 206 313 294 207 313 minecraft:iron_block
fill 294 206 315 294 207 315 minecraft:iron_block
fill 295 206 308 295 207 308 minecraft:iron_block
fill 295 206 310 295 207 310 minecraft:iron_block
fill 295 206 312 295 207 312 minecraft:iron_block
fill 295 206 314 295 207 314 minecraft:iron_block
fill 295 206 316 295 207 316 minecraft:iron_block
fill 295 206 317 301 207 317 minecraft:light_gray_concrete
setblock 296 206 275 minecraft:redstone_block
fill 296 206 307 296 207 307 minecraft:iron_block
fill 296 206 309 296 207 309 minecraft:iron_block
fill 296 206 311 296 207 311 minecraft:iron_block
fill 296 206 313 296 207 313 minecraft:iron_block
fill 296 206 315 296 207 315 minecraft:iron_block
fill 297 206 275 300 206 275 minecraft:light_gray_concrete
fill 297 206 308 297 207 308 minecraft:iron_block
fill 297 206 310 297 207 310 minecraft:iron_block
fill 297 206 312 297 207 312 minecraft:iron_block
fill 297 206 314 297 207 314 minecraft:iron_block
fill 297 206 316 297 207 316 minecraft:iron_block
fill 298 206 277 298 207 277 minecraft:iron_block
fill 298 206 279 298 207 279 minecraft:iron_block
fill 298 206 307 298 207 307 minecraft:iron_block
fill 298 206 309 298 207 309 minecraft:iron_block
fill 298 206 311 298 207 311 minecraft:iron_block
fill 298 206 313 298 207 313 minecraft:iron_block
fill 298 206 315 298 207 315 minecraft:iron_block
fill 299 206 276 299 207 276 minecraft:iron_block
fill 299 206 278 299 207 278 minecraft:iron_block
fill 299 206 308 299 207 308 minecraft:iron_block
fill 299 206 310 299 207 310 minecraft:iron_block
fill 299 206 312 299 207 312 minecraft:iron_block
fill 299 206 314 299 207 314 minecraft:iron_block
fill 299 206 316 299 207 316 minecraft:iron_block
fill 300 206 277 300 207 277 minecraft:iron_block
fill 300 206 279 300 207 279 minecraft:iron_block
fill 300 206 307 300 207 307 minecraft:iron_block
fill 300 206 309 300 207 309 minecraft:iron_block
fill 300 206 311 300 207 311 minecraft:iron_block
fill 300 206 313 300 207 313 minecraft:iron_block
fill 300 206 315 300 207 315 minecraft:iron_block
fill 301 206 275 301 207 275 minecraft:gray_concrete
fill 301 206 276 301 207 276 minecraft:iron_block
fill 301 206 278 301 207 278 minecraft:iron_block
fill 301 206 308 301 207 308 minecraft:iron_block
fill 301 206 310 301 207 310 minecraft:iron_block
fill 301 206 312 301 207 312 minecraft:iron_block
fill 301 206 314 301 207 314 minecraft:iron_block
fill 301 206 316 301 207 316 minecraft:iron_block
setblock 302 206 275 minecraft:light_gray_concrete
fill 302 206 277 302 207 277 minecraft:iron_block
fill 302 206 279 302 207 279 minecraft:iron_block
fill 302 206 307 302 207 307 minecraft:iron_block
fill 302 206 309 302 207 309 minecraft:iron_block
fill 302 206 311 302 207 311 minecraft:iron_block
fill 302 206 313 302 207 313 minecraft:iron_block
fill 302 206 315 302 207 315 minecraft:iron_block
setblock 302 206 317 minecraft:gray_concrete
setblock 303 206 275 minecraft:gray_concrete
fill 303 206 276 303 207 276 minecraft:iron_block
fill 303 206 278 303 207 278 minecraft:iron_block
fill 303 206 317 304 229 317 minecraft:light_gray_concrete
fill 304 206 275 324 206 275 minecraft:light_gray_concrete
fill 304 206 277 304 207 277 minecraft:iron_block
fill 304 206 279 304 207 279 minecraft:iron_block
fill 306 206 317 315 206 317 minecraft:light_gray_concrete
setblock 316 206 317 minecraft:gray_concrete
fill 317 206 317 321 210 317 minecraft:light_gray_concrete
setblock 322 206 317 minecraft:gray_concrete
fill 323 206 317 323 207 317 minecraft:light_gray_concrete
fill 324 206 276 324 206 286 minecraft:light_gray_concrete
fill 324 206 287 324 206 288 minecraft:gray_concrete
fill 324 206 289 324 206 300 minecraft:light_gray_concrete
setblock 324 206 301 minecraft:gray_concrete
fill 324 206 302 324 206 310 minecraft:light_gray_concrete
setblock 324 206 311 minecraft:gray_concrete
fill 324 206 312 324 206 313 minecraft:light_gray_concrete
fill 324 206 314 324 207 314 minecraft:gray_concrete
fill 324 206 315 324 210 316 minecraft:light_gray_concrete
setblock 324 206 317 minecraft:gray_concrete
setblock 282 207 276 minecraft:gray_concrete
fill 282 207 277 282 229 277 minecraft:light_gray_concrete
setblock 282 207 278 minecraft:gray_concrete
fill 282 207 279 282 229 279 minecraft:light_gray_concrete
fill 282 207 292 282 210 293 minecraft:light_gray_concrete
setblock 282 207 294 minecraft:gray_concrete
fill 282 207 295 282 210 301 minecraft:light_gray_concrete
setblock 282 207 302 minecraft:gray_concrete
fill 282 207 303 282 207 308 minecraft:light_gray_concrete
setblock 283 207 275 minecraft:gray_concrete
fill 283 207 280 283 207 283 minecraft:iron_block
fill 283 207 290 283 207 293 minecraft:iron_block
fill 283 207 300 283 207 303 minecraft:iron_block
fill 283 207 310 283 207 313 minecraft:iron_block
fill 283 207 317 283 229 317 minecraft:light_gray_concrete
fill 284 207 275 296 210 275 minecraft:light_gray_concrete
fill 284 207 276 287 207 276 minecraft:iron_block
setblock 284 207 317 minecraft:gray_concrete
fill 285 207 317 292 210 317 minecraft:light_gray_concrete
fill 287 207 316 289 207 316 minecraft:iron_block
fill 293 207 317 293 208 317 minecraft:gray_concrete
fill 294 207 276 297 207 276 minecraft:iron_block
fill 294 207 317 294 229 317 minecraft:light_gray_concrete
setblock 297 207 275 minecraft:gray_concrete
fill 298 207 275 300 209 275 minecraft:light_gray_concrete
setblock 302 207 275 minecraft:gray_concrete
fill 302 207 317 302 229 317 minecraft:light_gray_concrete
fill 303 207 275 310 207 275 minecraft:light_gray_concrete
fill 305 207 276 307 207 276 minecraft:iron_block
fill 305 207 317 309 207 317 minecraft:light_gray_concrete
fill 307 207 316 310 207 316 minecraft:iron_block
setblock 310 207 317 minecraft:gray_concrete
setblock 311 207 275 minecraft:gray_concrete
setblock 311 207 317 minecraft:light_gray_concrete
fill 312 207 275 317 207 275 minecraft:light_gray_concrete
setblock 312 207 317 minecraft:gray_concrete
fill 313 207 317 314 229 317 minecraft:light_gray_concrete
fill 314 207 276 317 207 276 minecraft:iron_block
setblock 315 207 317 minecraft:gray_concrete
fill 316 207 317 316 210 317 minecraft:light_gray_concrete
fill 317 207 316 320 207 316 minecraft:iron_block
setblock 318 207 275 minecraft:gray_concrete
fill 319 207 275 324 214 275 minecraft:light_gray_concrete
fill 322 207 317 322 229 317 minecraft:light_gray_concrete
fill 323 207 277 323 207 280 minecraft:iron_block
fill 323 207 287 323 207 290 minecraft:iron_block
fill 323 207 297 323 207 300 minecraft:iron_block
fill 323 207 307 323 207 310 minecraft:iron_block
fill 324 207 276 324 207 278 minecraft:light_gray_concrete
setblock 324 207 279 minecraft:gray_concrete
fill 324 207 280 324 207 287 minecraft:light_gray_concrete
setblock 324 207 288 minecraft:gray_concrete
fill 324 207 289 324 210 292 minecraft:light_gray_concrete
setblock 324 207 293 minecraft:gray_concrete
fill 324 207 294 324 210 299 minecraft:light_gray_concrete
setblock 324 207 300 minecraft:sea_lantern
fill 324 207 301 324 207 302 minecraft:light_gray_concrete
fill 324 207 303 324 208 303 minecraft:gray_concrete
fill 324 207 304 324 210 308 minecraft:light_gray_concrete
setblock 324 207 309 minecraft:gray_concrete
fill 324 207 310 324 229 312 minecraft:light_gray_concrete
fill 324 207 313 324 208 313 minecraft:gray_concrete
setblock 324 207 317 minecraft:light_gray_concrete
fill 282 208 275 282 229 276 minecraft:light_gray_concrete
fill 282 208 278 282 229 278 minecraft:light_gray_concrete
fill 282 208 282 282 210 284 minecraft:light_gray_concrete
fill 282 208 285 282 208 286 minecraft:gray_concrete
fill 282 208 287 282 210 291 minecraft:light_gray_concrete
fill 282 208 294 282 210 294 minecraft:light_gray_concrete
fill 282 208 302 282 210 303 minecraft:light_gray_concrete
setblock 282 208 304 minecraft:gray_concrete
fill 282 208 305 282 227 308 minecraft:light_gray_concrete
fill 283 208 275 283 229 275 minecraft:light_gray_concrete
fill 284 208 317 284 226 317 minecraft:light_gray_concrete
setblock 290 208 307 minecraft:pearlescent_froglight
setblock 290 208 309 minecraft:pearlescent_froglight
setblock 290 208 311 minecraft:pearlescent_froglight
setblock 290 208 313 minecraft:pearlescent_froglight
setblock 290 208 315 minecraft:pearlescent_froglight
setblock 291 208 308 minecraft:pearlescent_froglight
setblock 291 208 310 minecraft:pearlescent_froglight
setblock 291 208 312 minecraft:pearlescent_froglight
setblock 291 208 314 minecraft:pearlescent_froglight
setblock 291 208 316 minecraft:pearlescent_froglight
setblock 292 208 307 minecraft:pearlescent_froglight
setblock 292 208 309 minecraft:pearlescent_froglight
setblock 292 208 311 minecraft:pearlescent_froglight
setblock 292 208 313 minecraft:pearlescent_froglight
setblock 292 208 315 minecraft:pearlescent_froglight
setblock 293 208 308 minecraft:pearlescent_froglight
setblock 293 208 310 minecraft:pearlescent_froglight
setblock 293 208 312 minecraft:pearlescent_froglight
setblock 293 208 314 minecraft:pearlescent_froglight
setblock 293 208 316 minecraft:pearlescent_froglight
setblock 294 208 307 minecraft:pearlescent_froglight
setblock 294 208 309 minecraft:pearlescent_froglight
setblock 294 208 311 minecraft:pearlescent_froglight
setblock 294 208 313 minecraft:pearlescent_froglight
setblock 294 208 315 minecraft:pearlescent_froglight
setblock 295 208 308 minecraft:pearlescent_froglight
setblock 295 208 310 minecraft:pearlescent_froglight
setblock 295 208 312 minecraft:pearlescent_froglight
setblock 295 208 314 minecraft:pearlescent_froglight
setblock 295 208 316 minecraft:pearlescent_froglight
setblock 295 208 317 minecraft:gray_concrete
setblock 296 208 307 minecraft:pearlescent_froglight
setblock 296 208 309 minecraft:pearlescent_froglight
setblock 296 208 311 minecraft:pearlescent_froglight
setblock 296 208 313 minecraft:pearlescent_froglight
setblock 296 208 315 minecraft:pearlescent_froglight
fill 296 208 317 297 210 317 minecraft:light_gray_concrete
fill 297 208 275 297 210 275 minecraft:light_gray_concrete
setblock 297 208 308 minecraft:pearlescent_froglight
setblock 297 208 310 minecraft:pearlescent_froglight
setblock 297 208 312 minecraft:pearlescent_froglight
setblock 297 208 314 minecraft:pearlescent_froglight
setblock 297 208 316 minecraft:pearlescent_froglight
setblock 298 208 277 minecraft:pearlescent_froglight
setblock 298 208 279 minecraft:pearlescent_froglight
setblock 298 208 307 minecraft:pearlescent_froglight
setblock 298 208 309 minecraft:pearlescent_froglight
setblock 298 208 311 minecraft:pearlescent_froglight
setblock 298 208 313 minecraft:pearlescent_froglight
setblock 298 208 315 minecraft:pearlescent_froglight
setblock 298 208 317 minecraft:gray_concrete
setblock 299 208 276 minecraft:pearlescent_froglight
setblock 299 208 278 minecraft:pearlescent_froglight
setblock 299 208 308 minecraft:pearlescent_froglight
setblock 299 208 310 minecraft:pearlescent_froglight
setblock 299 208 312 minecraft:pearlescent_froglight
setblock 299 208 314 minecraft:pearlescent_froglight
setblock 299 208 316 minecraft:pearlescent_froglight
fill 299 208 317 301 210 317 minecraft:light_gray_concrete
setblock 300 208 277 minecraft:pearlescent_froglight
setblock 300 208 279 minecraft:pearlescent_froglight
setblock 300 208 307 minecraft:pearlescent_froglight
setblock 300 208 309 minecraft:pearlescent_froglight
setblock 300 208 311 minecraft:pearlescent_froglight
setblock 300 208 313 minecraft:pearlescent_froglight
setblock 300 208 315 minecraft:pearlescent_froglight
fill 301 208 275 308 210 275 minecraft:light_gray_concrete
setblock 301 208 276 minecraft:pearlescent_froglight
setblock 301 208 278 minecraft:pearlescent_froglight
setblock 301 208 308 minecraft:pearlescent_froglight
setblock 301 208 310 minecraft:pearlescent_froglight
setblock 301 208 312 minecraft:pearlescent_froglight
setblock 301 208 314 minecraft:pearlescent_froglight
setblock 301 208 316 minecraft:pearlescent_froglight
setblock 302 208 277 minecraft:pearlescent_froglight
setblock 302 208 279 minecraft:pearlescent_froglight
setblock 302 208 307 minecraft:pearlescent_froglight
setblock 302 208 309 minecraft:pearlescent_froglight
setblock 302 208 311 minecraft:pearlescent_froglight
setblock 302 208 313 minecraft:pearlescent_froglight
setblock 302 208 315 minecraft:pearlescent_froglight
setblock 303 208 276 minecraft:pearlescent_froglight
setblock 303 208 278 minecraft:pearlescent_froglight
setblock 304 208 277 minecraft:pearlescent_froglight
setblock 304 208 279 minecraft:pearlescent_froglight
fill 305 208 317 306 210 317 minecraft:light_gray_concrete
setblock 307 208 317 minecraft:gray_concrete
fill 308 208 317 310 210 317 minecraft:light_gray_concrete
setblock 309 208 275 minecraft:gray_concrete
fill 310 208 275 316 210 275 minecraft:light_gray_concrete
setblock 311 208 317 minecraft:gray_concrete
fill 312 208 317 312 221 317 minecraft:light_gray_concrete
fill 315 208 317 315 229 317 minecraft:light_gray_concrete
setblock 317 208 275 minecraft:gray_concrete
fill 318 208 275 318 210 275 minecraft:light_gray_concrete
fill 323 208 317 324 208 317 minecraft:gray_concrete
fill 324 208 276 324 210 277 minecraft:light_gray_concrete
setblock 324 208 278 minecraft:gray_concrete
fill 324 208 279 324 210 279 minecraft:light_gray_concrete
setblock 324 208 280 minecraft:gray_concrete
fill 324 208 281 324 210 288 minecraft:light_gray_concrete
fill 324 208 293 324 227 293 minecraft:light_gray_concrete
fill 324 208 300 324 229 301 minecraft:light_gray_concrete
setblock 324 208 302 minecraft:gray_concrete
fill 324 208 309 324 210 309 minecraft:light_gray_concrete
fill 324 208 314 324 229 314 minecraft:light_gray_concrete
fill 282 209 285 282 229 286 minecraft:light_gray_concrete
fill 282 209 304 282 210 304 minecraft:light_gray_concrete
setblock 285 209 278 minecraft:light[level=15]
setblock 285 209 286 minecraft:light[level=15]
setblock 285 209 294 minecraft:light[level=15]
setblock 285 209 302 minecraft:light[level=15]
setblock 285 209 310 minecraft:light[level=15]
fill 290 209 307 290 210 307 minecraft:iron_block
fill 290 209 309 290 210 309 minecraft:iron_block
fill 290 209 311 290 210 311 minecraft:iron_block
fill 290 209 313 290 210 313 minecraft:iron_block
fill 290 209 315 290 210 315 minecraft:iron_block
fill 291 209 308 291 210 308 minecraft:iron_block
fill 291 209 310 291 210 310 minecraft:iron_block
fill 291 209 312 291 210 312 minecraft:iron_block
fill 291 209 314 291 210 314 minecraft:iron_block
fill 291 209 316 291 210 316 minecraft:iron_block
fill 292 209 307 292 210 307 minecraft:iron_block
fill 292 209 309 292 210 309 minecraft:iron_block
fill 292 209 311 292 210 311 minecraft:iron_block
fill 292 209 313 292 210 313 minecraft:iron_block
fill 292 209 315 292 210 315 minecraft:iron_block
setblock 293 209 278 minecraft:light[level=15]
setblock 293 209 286 minecraft:light[level=15]
setblock 293 209 294 minecraft:light[level=15]
setblock 293 209 302 minecraft:light[level=15]
fill 293 209 308 293 210 308 minecraft:iron_block
fill 293 209 310 293 210 310 minecraft:iron_block
fill 293 209 312 293 210 312 minecraft:iron_block
fill 293 209 314 293 210 314 minecraft:iron_block
fill 293 209 316 293 210 316 minecraft:iron_block
fill 293 209 317 293 229 317 minecraft:light_gray_concrete
fill 294 209 307 294 210 307 minecraft:iron_block
fill 294 209 309 294 210 309 minecraft:iron_block
fill 294 209 311 294 210 311 minecraft:iron_block
fill 294 209 313 294 210 313 minecraft:iron_block
fill 294 209 315 294 210 315 minecraft:iron_block
fill 295 209 308 295 210 308 minecraft:iron_block
fill 295 209 310 295 210 310 minecraft:iron_block
fill 295 209 312 295 210 312 minecraft:iron_block
fill 295 209 314 295 210 314 minecraft:iron_block
fill 295 209 316 295 210 316 minecraft:iron_block
fill 295 209 317 295 229 317 minecraft:light_gray_concrete
fill 296 209 307 296 210 307 minecraft:iron_block
fill 296 209 309 296 210 309 minecraft:iron_block
fill 296 209 311 296 210 311 minecraft:iron_block
fill 296 209 313 296 210 313 minecraft:iron_block
fill 296 209 315 296 210 315 minecraft:iron_block
schedule function dropper:buildpart/66_4 1t
