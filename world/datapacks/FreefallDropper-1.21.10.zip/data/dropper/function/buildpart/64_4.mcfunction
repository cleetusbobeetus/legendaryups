fill 198 269 303 198 271 304 minecraft:cyan_stained_glass
fill 199 269 291 199 272 291 minecraft:cyan_stained_glass
fill 199 269 305 199 272 305 minecraft:cyan_stained_glass
fill 200 269 290 200 272 290 minecraft:prismarine_bricks
fill 200 269 306 200 272 306 minecraft:prismarine_bricks
fill 200 269 310 200 272 310 minecraft:iron_block
fill 201 269 289 201 272 289 minecraft:cyan_stained_glass
fill 201 269 307 201 272 307 minecraft:cyan_stained_glass
fill 202 269 288 203 271 288 minecraft:cyan_stained_glass
fill 202 269 308 203 271 308 minecraft:cyan_stained_glass
fill 203 269 275 203 308 275 minecraft:prismarine
fill 204 269 287 204 271 287 minecraft:cyan_stained_glass
fill 204 269 309 204 271 309 minecraft:cyan_stained_glass
fill 205 269 287 205 272 287 minecraft:prismarine_bricks
fill 205 269 309 205 272 309 minecraft:prismarine_bricks
fill 206 269 287 210 272 287 minecraft:cyan_stained_glass
fill 206 269 309 210 272 309 minecraft:cyan_stained_glass
fill 210 269 317 210 308 317 minecraft:prismarine
fill 211 269 287 211 272 287 minecraft:prismarine_bricks
fill 211 269 309 211 272 309 minecraft:prismarine_bricks
fill 212 269 287 212 271 287 minecraft:cyan_stained_glass
fill 212 269 309 212 271 309 minecraft:cyan_stained_glass
fill 213 269 288 214 271 288 minecraft:cyan_stained_glass
fill 213 269 308 214 271 308 minecraft:cyan_stained_glass
fill 215 269 289 215 272 289 minecraft:cyan_stained_glass
fill 215 269 307 215 272 307 minecraft:cyan_stained_glass
fill 216 269 290 216 272 290 minecraft:prismarine_bricks
fill 216 269 306 216 272 306 minecraft:prismarine_bricks
fill 217 269 291 217 272 291 minecraft:cyan_stained_glass
fill 217 269 305 217 272 305 minecraft:cyan_stained_glass
fill 218 269 292 218 271 293 minecraft:cyan_stained_glass
fill 218 269 303 218 271 304 minecraft:cyan_stained_glass
fill 219 269 294 219 271 294 minecraft:cyan_stained_glass
fill 219 269 295 219 272 295 minecraft:prismarine_bricks
fill 219 269 296 219 272 300 minecraft:cyan_stained_glass
fill 219 269 301 219 272 301 minecraft:prismarine_bricks
fill 219 269 302 219 271 302 minecraft:cyan_stained_glass
fill 188 270 291 188 308 291 minecraft:prismarine
setblock 191 270 286 minecraft:light[level=15]
setblock 191 270 294 minecraft:light[level=15]
setblock 191 270 302 minecraft:light[level=15]
setblock 191 270 310 minecraft:light[level=15]
setblock 199 270 278 minecraft:light[level=15]
setblock 199 270 286 minecraft:light[level=15]
fill 199 270 292 199 273 292 minecraft:cyan_stained_glass
setblock 199 270 294 minecraft:light[level=15]
setblock 199 270 302 minecraft:light[level=15]
fill 199 270 304 199 273 304 minecraft:cyan_stained_glass
setblock 199 270 310 minecraft:light[level=15]
fill 202 270 289 202 273 289 minecraft:cyan_stained_glass
fill 202 270 307 202 273 307 minecraft:cyan_stained_glass
setblock 207 270 278 minecraft:light[level=15]
setblock 207 270 286 minecraft:light[level=15]
setblock 207 270 294 minecraft:light[level=15]
setblock 207 270 302 minecraft:light[level=15]
setblock 207 270 310 minecraft:light[level=15]
setblock 212 270 275 minecraft:prismarine_bricks
fill 214 270 289 214 273 289 minecraft:cyan_stained_glass
fill 214 270 307 214 273 307 minecraft:cyan_stained_glass
setblock 215 270 278 minecraft:light[level=15]
setblock 215 270 286 minecraft:light[level=15]
setblock 215 270 294 minecraft:light[level=15]
setblock 215 270 302 minecraft:light[level=15]
setblock 215 270 310 minecraft:light[level=15]
fill 217 270 292 217 273 292 minecraft:cyan_stained_glass
fill 217 270 304 217 273 304 minecraft:cyan_stained_glass
setblock 219 270 317 minecraft:sea_lantern
fill 220 270 317 221 284 317 minecraft:prismarine
setblock 223 270 278 minecraft:light[level=15]
setblock 223 270 286 minecraft:light[level=15]
setblock 223 270 294 minecraft:light[level=15]
setblock 223 270 302 minecraft:light[level=15]
setblock 223 270 310 minecraft:light[level=15]
setblock 226 270 275 minecraft:prismarine_bricks
setblock 230 270 297 minecraft:sea_lantern
fill 230 270 298 230 308 298 minecraft:prismarine
fill 192 271 311 194 272 311 minecraft:gold_block
fill 192 271 315 194 272 315 minecraft:gold_block
fill 195 271 312 195 272 314 minecraft:gold_block
fill 198 271 294 198 273 294 minecraft:cyan_stained_glass
fill 198 271 302 198 273 302 minecraft:cyan_stained_glass
fill 200 271 291 200 274 291 minecraft:cyan_stained_glass
fill 200 271 305 200 274 305 minecraft:cyan_stained_glass
fill 201 271 290 201 274 290 minecraft:cyan_stained_glass
fill 201 271 306 201 274 306 minecraft:cyan_stained_glass
fill 204 271 288 204 273 288 minecraft:cyan_stained_glass
fill 204 271 308 204 273 308 minecraft:cyan_stained_glass
fill 212 271 275 212 308 275 minecraft:prismarine
fill 212 271 288 212 273 288 minecraft:cyan_stained_glass
fill 212 271 308 212 273 308 minecraft:cyan_stained_glass
fill 215 271 290 215 274 290 minecraft:cyan_stained_glass
fill 215 271 306 215 274 306 minecraft:cyan_stained_glass
fill 216 271 291 216 274 291 minecraft:cyan_stained_glass
fill 216 271 305 216 274 305 minecraft:cyan_stained_glass
fill 218 271 294 218 273 294 minecraft:cyan_stained_glass
fill 218 271 302 218 273 302 minecraft:cyan_stained_glass
fill 219 271 317 219 308 317 minecraft:prismarine
fill 226 271 275 226 308 275 minecraft:prismarine
fill 230 271 297 230 296 297 minecraft:prismarine
fill 188 272 281 188 285 281 minecraft:prismarine
fill 188 272 282 188 272 283 minecraft:sea_lantern
fill 188 272 284 188 285 284 minecraft:prismarine
fill 188 272 293 188 278 293 minecraft:prismarine
fill 188 272 294 188 272 295 minecraft:sea_lantern
fill 188 272 296 188 285 296 minecraft:prismarine
fill 188 272 305 188 285 305 minecraft:prismarine
fill 188 272 306 188 272 307 minecraft:sea_lantern
fill 188 272 308 188 285 308 minecraft:prismarine
fill 188 272 317 188 285 317 minecraft:prismarine
fill 189 272 317 190 272 317 minecraft:sea_lantern
setblock 191 272 285 minecraft:light[level=12]
setblock 191 272 292 minecraft:light[level=12]
setblock 191 272 299 minecraft:light[level=12]
setblock 191 272 306 minecraft:light[level=12]
setblock 191 272 317 minecraft:prismarine_bricks
fill 195 272 275 195 275 275 minecraft:prismarine
fill 196 272 275 197 272 275 minecraft:sea_lantern
fill 198 272 275 198 285 275 minecraft:prismarine
setblock 198 272 278 minecraft:light[level=12]
setblock 198 272 285 minecraft:light[level=12]
setblock 198 272 292 minecraft:light[level=12]
setblock 198 272 293 minecraft:cyan_stained_glass
fill 198 272 295 198 274 295 minecraft:prismarine_bricks
setblock 198 272 299 minecraft:light[level=12]
fill 198 272 301 198 274 301 minecraft:prismarine_bricks
setblock 198 272 303 minecraft:cyan_stained_glass
setblock 198 272 306 minecraft:light[level=12]
setblock 198 272 313 minecraft:light[level=12]
fill 200 272 317 200 280 317 minecraft:prismarine
fill 201 272 317 202 272 317 minecraft:sea_lantern
setblock 203 272 288 minecraft:cyan_stained_glass
setblock 203 272 308 minecraft:cyan_stained_glass
fill 203 272 317 203 285 317 minecraft:prismarine
setblock 205 272 278 minecraft:light[level=12]
setblock 205 272 285 minecraft:light[level=12]
fill 205 272 288 205 274 288 minecraft:prismarine_bricks
setblock 205 272 292 minecraft:light[level=12]
setblock 205 272 299 minecraft:light[level=12]
setblock 205 272 306 minecraft:light[level=12]
fill 205 272 308 205 274 308 minecraft:prismarine_bricks
setblock 205 272 313 minecraft:light[level=12]
fill 207 272 275 207 283 275 minecraft:prismarine
fill 208 272 275 209 272 275 minecraft:sea_lantern
fill 210 272 275 210 285 275 minecraft:prismarine
fill 211 272 288 211 274 288 minecraft:prismarine_bricks
fill 211 272 308 211 274 308 minecraft:prismarine_bricks
setblock 212 272 278 minecraft:light[level=12]
setblock 212 272 285 minecraft:light[level=12]
setblock 212 272 292 minecraft:light[level=12]
setblock 212 272 299 minecraft:light[level=12]
setblock 212 272 306 minecraft:light[level=12]
setblock 212 272 313 minecraft:light[level=12]
fill 212 272 317 212 285 317 minecraft:prismarine
setblock 213 272 288 minecraft:cyan_stained_glass
setblock 213 272 308 minecraft:cyan_stained_glass
fill 213 272 317 214 272 317 minecraft:sea_lantern
fill 215 272 317 215 285 317 minecraft:prismarine
setblock 218 272 293 minecraft:cyan_stained_glass
fill 218 272 295 218 274 295 minecraft:prismarine_bricks
fill 218 272 301 218 274 301 minecraft:prismarine_bricks
setblock 218 272 303 minecraft:cyan_stained_glass
fill 219 272 275 219 285 275 minecraft:prismarine
setblock 219 272 278 minecraft:light[level=12]
setblock 219 272 285 minecraft:light[level=12]
setblock 219 272 292 minecraft:light[level=12]
setblock 219 272 306 minecraft:light[level=12]
setblock 219 272 313 minecraft:light[level=12]
fill 220 272 275 221 272 275 minecraft:sea_lantern
fill 222 272 275 222 285 275 minecraft:prismarine
fill 224 272 317 224 285 317 minecraft:prismarine
fill 225 272 317 226 272 317 minecraft:sea_lantern
setblock 226 272 285 minecraft:light[level=12]
setblock 226 272 292 minecraft:light[level=12]
setblock 226 272 299 minecraft:light[level=12]
setblock 226 272 306 minecraft:light[level=12]
fill 227 272 317 227 285 317 minecraft:prismarine
fill 230 272 276 230 285 276 minecraft:prismarine
fill 230 272 277 230 272 278 minecraft:sea_lantern
fill 230 272 279 230 285 279 minecraft:prismarine
fill 230 272 282 230 308 283 minecraft:prismarine
setblock 230 272 284 minecraft:prismarine_bricks
setblock 230 272 285 minecraft:prismarine
fill 230 272 288 230 285 288 minecraft:prismarine
fill 230 272 289 230 272 290 minecraft:sea_lantern
fill 230 272 291 230 285 291 minecraft:prismarine
fill 230 272 300 230 285 300 minecraft:prismarine
fill 230 272 301 230 272 302 minecraft:sea_lantern
fill 230 272 303 230 285 303 minecraft:prismarine
fill 230 272 312 230 285 312 minecraft:prismarine
fill 230 272 313 230 272 314 minecraft:sea_lantern
fill 230 272 315 230 285 315 minecraft:prismarine
fill 188 273 282 188 285 283 minecraft:prismarine
fill 188 273 294 188 274 295 minecraft:prismarine
fill 188 273 306 188 285 307 minecraft:prismarine
fill 189 273 317 191 285 317 minecraft:prismarine
fill 196 273 275 197 285 275 minecraft:prismarine
fill 196 273 317 198 308 317 minecraft:prismarine
fill 197 273 297 198 273 299 minecraft:cyan_stained_glass
fill 198 273 296 198 274 296 minecraft:cyan_stained_glass
fill 198 273 300 198 274 300 minecraft:cyan_stained_glass
fill 199 273 293 199 274 293 minecraft:cyan_stained_glass
fill 199 273 303 199 274 303 minecraft:cyan_stained_glass
setblock 199 273 317 minecraft:sea_lantern
fill 200 273 292 200 275 292 minecraft:cyan_stained_glass
fill 200 273 304 200 275 304 minecraft:cyan_stained_glass
fill 201 273 317 202 274 317 minecraft:prismarine
fill 202 273 290 202 275 290 minecraft:cyan_stained_glass
fill 202 273 306 202 275 306 minecraft:cyan_stained_glass
fill 203 273 289 203 274 289 minecraft:cyan_stained_glass
fill 203 273 307 203 274 307 minecraft:cyan_stained_glass
fill 206 273 288 210 274 288 minecraft:cyan_stained_glass
fill 206 273 308 210 274 308 minecraft:cyan_stained_glass
fill 207 273 287 209 273 287 minecraft:cyan_stained_glass
fill 207 273 309 209 273 309 minecraft:cyan_stained_glass
fill 208 273 275 209 285 275 minecraft:prismarine
fill 213 273 289 213 274 289 minecraft:cyan_stained_glass
fill 213 273 307 213 274 307 minecraft:cyan_stained_glass
fill 213 273 317 214 285 317 minecraft:prismarine
fill 214 273 290 214 275 290 minecraft:cyan_stained_glass
fill 214 273 306 214 275 306 minecraft:cyan_stained_glass
fill 216 273 292 216 275 292 minecraft:cyan_stained_glass
fill 216 273 304 216 275 304 minecraft:cyan_stained_glass
fill 217 273 293 217 274 293 minecraft:cyan_stained_glass
fill 217 273 303 217 274 303 minecraft:cyan_stained_glass
fill 218 273 296 218 274 300 minecraft:cyan_stained_glass
fill 219 273 297 219 273 299 minecraft:cyan_stained_glass
fill 220 273 275 221 285 275 minecraft:prismarine
fill 225 273 317 226 285 317 minecraft:prismarine
fill 230 273 277 230 275 278 minecraft:prismarine
fill 230 273 284 230 308 284 minecraft:prismarine
setblock 230 273 285 minecraft:sea_lantern
fill 230 273 289 230 284 290 minecraft:prismarine
fill 230 273 301 230 282 302 minecraft:prismarine
fill 230 273 313 230 285 314 minecraft:prismarine
setblock 188 274 286 minecraft:sea_lantern
fill 198 274 297 198 275 299 minecraft:cyan_stained_glass
fill 199 274 294 199 275 295 minecraft:cyan_stained_glass
fill 199 274 301 199 275 302 minecraft:cyan_stained_glass
fill 199 274 317 199 286 317 minecraft:prismarine
fill 200 274 293 200 275 293 minecraft:cyan_stained_glass
fill 200 274 303 200 275 303 minecraft:cyan_stained_glass
fill 201 274 291 201 275 291 minecraft:prismarine_bricks
fill 201 274 305 201 275 305 minecraft:prismarine_bricks
fill 203 274 290 203 275 290 minecraft:cyan_stained_glass
fill 203 274 306 203 275 306 minecraft:cyan_stained_glass
fill 204 274 289 205 275 289 minecraft:cyan_stained_glass
fill 204 274 307 205 275 307 minecraft:cyan_stained_glass
setblock 209 274 317 minecraft:sea_lantern
fill 211 274 289 212 275 289 minecraft:cyan_stained_glass
fill 211 274 307 212 275 307 minecraft:cyan_stained_glass
setblock 211 274 317 minecraft:sea_lantern
fill 213 274 290 213 275 290 minecraft:cyan_stained_glass
fill 213 274 306 213 275 306 minecraft:cyan_stained_glass
fill 215 274 291 215 275 291 minecraft:prismarine_bricks
fill 215 274 305 215 275 305 minecraft:prismarine_bricks
fill 216 274 293 216 275 293 minecraft:cyan_stained_glass
fill 216 274 303 216 275 303 minecraft:cyan_stained_glass
fill 217 274 294 217 275 295 minecraft:cyan_stained_glass
fill 217 274 301 217 275 302 minecraft:cyan_stained_glass
fill 230 274 285 230 308 285 minecraft:prismarine
fill 188 275 286 188 308 286 minecraft:prismarine
fill 188 275 294 188 285 294 minecraft:prismarine
setblock 188 275 295 minecraft:sea_lantern
setblock 188 275 311 minecraft:prismarine_bricks
fill 199 275 296 199 276 300 minecraft:cyan_stained_glass
fill 200 275 294 200 276 294 minecraft:cyan_stained_glass
fill 200 275 302 200 276 302 minecraft:cyan_stained_glass
fill 201 275 292 201 276 292 minecraft:cyan_stained_glass
fill 201 275 304 201 276 304 minecraft:cyan_stained_glass
setblock 201 275 317 minecraft:prismarine_bricks
fill 202 275 291 202 276 291 minecraft:cyan_stained_glass
fill 202 275 305 202 276 305 minecraft:cyan_stained_glass
fill 202 275 317 202 285 317 minecraft:prismarine
fill 204 275 290 204 276 290 minecraft:cyan_stained_glass
fill 204 275 306 204 276 306 minecraft:cyan_stained_glass
fill 206 275 289 210 276 289 minecraft:cyan_stained_glass
fill 206 275 307 210 276 307 minecraft:cyan_stained_glass
fill 207 275 288 209 275 288 minecraft:cyan_stained_glass
fill 207 275 308 209 275 308 minecraft:cyan_stained_glass
fill 209 275 317 209 286 317 minecraft:prismarine
fill 211 275 317 211 308 317 minecraft:prismarine
fill 212 275 290 212 276 290 minecraft:cyan_stained_glass
fill 212 275 306 212 276 306 minecraft:cyan_stained_glass
fill 214 275 291 214 276 291 minecraft:cyan_stained_glass
fill 214 275 305 214 276 305 minecraft:cyan_stained_glass
fill 215 275 292 215 276 292 minecraft:cyan_stained_glass
fill 215 275 304 215 276 304 minecraft:cyan_stained_glass
fill 216 275 294 216 276 294 minecraft:cyan_stained_glass
fill 216 275 302 216 276 302 minecraft:cyan_stained_glass
fill 217 275 296 217 276 300 minecraft:cyan_stained_glass
fill 218 275 297 218 275 299 minecraft:cyan_stained_glass
fill 230 275 292 230 308 293 minecraft:prismarine
setblock 230 275 294 minecraft:prismarine_bricks
fill 230 275 295 230 308 296 minecraft:prismarine
fill 188 276 295 188 285 295 minecraft:prismarine
setblock 188 276 301 minecraft:sea_lantern
fill 188 276 311 188 288 311 minecraft:prismarine
setblock 195 276 275 minecraft:sea_lantern
setblock 200 276 295 minecraft:cyan_stained_glass
fill 200 276 296 200 277 296 minecraft:prismarine_bricks
fill 200 276 297 200 277 299 minecraft:cyan_stained_glass
fill 200 276 300 200 277 300 minecraft:prismarine_bricks
setblock 200 276 301 minecraft:cyan_stained_glass
fill 201 276 293 201 276 294 minecraft:cyan_stained_glass
fill 201 276 302 201 276 303 minecraft:cyan_stained_glass
fill 201 276 317 201 285 317 minecraft:prismarine
setblock 202 276 292 minecraft:prismarine_bricks
setblock 202 276 304 minecraft:prismarine_bricks
fill 203 276 291 204 276 291 minecraft:cyan_stained_glass
fill 203 276 305 204 276 305 minecraft:cyan_stained_glass
setblock 205 276 290 minecraft:cyan_stained_glass
setblock 205 276 306 minecraft:cyan_stained_glass
fill 206 276 290 206 277 290 minecraft:prismarine_bricks
fill 206 276 306 206 277 306 minecraft:prismarine_bricks
fill 207 276 290 209 277 290 minecraft:cyan_stained_glass
fill 207 276 306 209 277 306 minecraft:cyan_stained_glass
fill 210 276 290 210 277 290 minecraft:prismarine_bricks
fill 210 276 306 210 277 306 minecraft:prismarine_bricks
setblock 211 276 290 minecraft:cyan_stained_glass
setblock 211 276 306 minecraft:cyan_stained_glass
fill 212 276 291 213 276 291 minecraft:cyan_stained_glass
fill 212 276 305 213 276 305 minecraft:cyan_stained_glass
setblock 214 276 292 minecraft:prismarine_bricks
setblock 214 276 304 minecraft:prismarine_bricks
fill 215 276 293 215 276 294 minecraft:cyan_stained_glass
fill 215 276 302 215 276 303 minecraft:cyan_stained_glass
setblock 216 276 295 minecraft:cyan_stained_glass
fill 216 276 296 216 277 296 minecraft:prismarine_bricks
fill 216 276 297 216 277 299 minecraft:cyan_stained_glass
fill 216 276 300 216 277 300 minecraft:prismarine_bricks
setblock 216 276 301 minecraft:cyan_stained_glass
setblock 230 276 277 minecraft:prismarine_bricks
fill 230 276 278 230 285 278 minecraft:prismarine
fill 230 276 294 230 308 294 minecraft:prismarine
fill 188 277 301 188 306 301 minecraft:prismarine
fill 195 277 275 195 285 275 minecraft:prismarine
fill 201 277 294 201 277 295 minecraft:cyan_stained_glass
fill 201 277 296 201 278 296 minecraft:prismarine_bricks
fill 201 277 297 201 279 299 minecraft:cyan_stained_glass
fill 201 277 300 201 278 300 minecraft:prismarine_bricks
fill 201 277 301 201 277 302 minecraft:cyan_stained_glass
fill 202 277 293 202 277 294 minecraft:cyan_stained_glass
fill 202 277 302 202 277 303 minecraft:cyan_stained_glass
fill 203 277 292 204 277 292 minecraft:cyan_stained_glass
fill 203 277 293 203 278 293 minecraft:prismarine_bricks
fill 203 277 303 203 278 303 minecraft:prismarine_bricks
fill 203 277 304 204 277 304 minecraft:cyan_stained_glass
fill 204 277 291 205 277 291 minecraft:cyan_stained_glass
fill 204 277 305 205 277 305 minecraft:cyan_stained_glass
fill 206 277 291 206 278 291 minecraft:prismarine_bricks
fill 206 277 305 206 278 305 minecraft:prismarine_bricks
fill 207 277 291 209 279 291 minecraft:cyan_stained_glass
fill 207 277 305 209 279 305 minecraft:cyan_stained_glass
fill 210 277 291 210 278 291 minecraft:prismarine_bricks
fill 210 277 305 210 278 305 minecraft:prismarine_bricks
fill 211 277 291 212 277 291 minecraft:cyan_stained_glass
fill 211 277 305 212 277 305 minecraft:cyan_stained_glass
fill 212 277 292 213 277 292 minecraft:cyan_stained_glass
fill 212 277 304 213 277 304 minecraft:cyan_stained_glass
fill 213 277 293 213 278 293 minecraft:prismarine_bricks
fill 213 277 303 213 278 303 minecraft:prismarine_bricks
fill 214 277 293 214 277 294 minecraft:cyan_stained_glass
fill 214 277 302 214 277 303 minecraft:cyan_stained_glass
fill 215 277 294 215 277 295 minecraft:cyan_stained_glass
fill 215 277 296 215 278 296 minecraft:prismarine_bricks
fill 215 277 297 215 279 299 minecraft:cyan_stained_glass
fill 215 277 300 215 278 300 minecraft:prismarine_bricks
fill 215 277 301 215 277 302 minecraft:cyan_stained_glass
fill 230 277 277 230 282 277 minecraft:prismarine
setblock 191 278 285 minecraft:light[level=12]
setblock 191 278 286 minecraft:light[level=15]
setblock 191 278 292 minecraft:light[level=12]
setblock 191 278 294 minecraft:light[level=15]
setblock 191 278 299 minecraft:light[level=12]
setblock 191 278 302 minecraft:light[level=15]
setblock 191 278 306 minecraft:light[level=12]
setblock 191 278 310 minecraft:light[level=15]
fill 196 278 291 196 279 292 minecraft:white_stained_glass
setblock 198 278 278 minecraft:light[level=12]
setblock 198 278 285 minecraft:light[level=12]
setblock 198 278 292 minecraft:light[level=12]
setblock 198 278 299 minecraft:light[level=12]
setblock 198 278 306 minecraft:light[level=12]
setblock 198 278 313 minecraft:light[level=12]
setblock 199 278 278 minecraft:light[level=15]
setblock 199 278 286 minecraft:light[level=15]
setblock 199 278 294 minecraft:light[level=15]
setblock 199 278 302 minecraft:light[level=15]
setblock 199 278 310 minecraft:light[level=15]
fill 202 278 294 202 279 302 minecraft:cyan_stained_glass
fill 203 278 294 203 279 296 minecraft:cyan_stained_glass
fill 203 278 300 203 279 302 minecraft:cyan_stained_glass
fill 204 278 292 206 279 293 minecraft:cyan_stained_glass
setblock 204 278 294 minecraft:prismarine_bricks
setblock 204 278 302 minecraft:prismarine_bricks
fill 204 278 303 206 279 304 minecraft:cyan_stained_glass
setblock 205 278 278 minecraft:light[level=12]
setblock 205 278 285 minecraft:light[level=12]
setblock 205 278 299 minecraft:light[level=12]
setblock 205 278 306 minecraft:light[level=12]
setblock 205 278 313 minecraft:light[level=12]
setblock 207 278 278 minecraft:light[level=15]
setblock 207 278 286 minecraft:light[level=15]
fill 207 278 292 212 279 292 minecraft:cyan_stained_glass
setblock 207 278 294 minecraft:light[level=15]
setblock 207 278 302 minecraft:light[level=15]
fill 207 278 304 212 279 304 minecraft:cyan_stained_glass
setblock 207 278 310 minecraft:light[level=15]
fill 210 278 293 212 279 293 minecraft:cyan_stained_glass
fill 210 278 303 212 279 303 minecraft:cyan_stained_glass
setblock 212 278 278 minecraft:light[level=12]
setblock 212 278 285 minecraft:light[level=12]
setblock 212 278 294 minecraft:prismarine_bricks
setblock 212 278 299 minecraft:light[level=12]
setblock 212 278 302 minecraft:prismarine_bricks
setblock 212 278 306 minecraft:light[level=12]
setblock 212 278 313 minecraft:light[level=12]
fill 213 278 294 214 279 296 minecraft:cyan_stained_glass
fill 213 278 300 214 279 302 minecraft:cyan_stained_glass
fill 214 278 297 214 279 299 minecraft:cyan_stained_glass
setblock 215 278 278 minecraft:light[level=15]
setblock 215 278 286 minecraft:light[level=15]
setblock 215 278 294 minecraft:light[level=15]
setblock 215 278 302 minecraft:light[level=15]
setblock 215 278 310 minecraft:light[level=15]
setblock 219 278 278 minecraft:light[level=12]
setblock 219 278 285 minecraft:light[level=12]
setblock 219 278 292 minecraft:light[level=12]
setblock 219 278 299 minecraft:light[level=12]
setblock 219 278 306 minecraft:light[level=12]
setblock 219 278 313 minecraft:light[level=12]
setblock 223 278 278 minecraft:light[level=15]
setblock 223 278 286 minecraft:light[level=15]
setblock 223 278 294 minecraft:light[level=15]
setblock 223 278 302 minecraft:light[level=15]
setblock 223 278 310 minecraft:light[level=15]
setblock 226 278 285 minecraft:light[level=12]
setblock 226 278 292 minecraft:light[level=12]
setblock 226 278 299 minecraft:light[level=12]
setblock 226 278 306 minecraft:light[level=12]
setblock 188 279 293 minecraft:sea_lantern
fill 189 279 276 189 279 316 minecraft:prismarine_bricks
fill 190 279 276 190 279 294 minecraft:prismarine_bricks
fill 190 279 298 190 279 316 minecraft:prismarine_bricks
fill 191 279 276 194 279 277 minecraft:prismarine_bricks
fill 191 279 281 194 279 294 minecraft:prismarine_bricks
fill 191 279 298 194 279 311 minecraft:prismarine_bricks
fill 191 279 315 194 279 316 minecraft:prismarine_bricks
fill 193 279 295 194 279 297 minecraft:prismarine_bricks
fill 194 279 278 194 279 280 minecraft:prismarine_bricks
fill 194 279 312 194 279 314 minecraft:prismarine_bricks
fill 195 279 276 195 279 316 minecraft:sea_lantern
fill 196 279 276 201 279 290 minecraft:prismarine_bricks
fill 196 279 293 198 279 316 minecraft:prismarine_bricks
fill 197 279 291 200 279 292 minecraft:prismarine_bricks
fill 199 279 293 199 279 294 minecraft:prismarine_bricks
fill 199 279 295 200 279 301 minecraft:cyan_stained_glass
fill 199 279 302 199 279 316 minecraft:prismarine_bricks
fill 200 279 293 201 279 294 minecraft:cyan_stained_glass
fill 200 279 302 201 279 303 minecraft:cyan_stained_glass
fill 200 279 304 200 279 316 minecraft:prismarine_bricks
setblock 201 279 291 minecraft:prismarine_bricks
fill 201 279 292 203 279 292 minecraft:cyan_stained_glass
fill 201 279 295 201 279 296 minecraft:cyan_stained_glass
fill 201 279 300 201 279 301 minecraft:cyan_stained_glass
fill 201 279 304 203 279 304 minecraft:cyan_stained_glass
fill 201 279 305 201 279 316 minecraft:prismarine_bricks
fill 202 279 276 202 279 290 minecraft:sea_lantern
fill 202 279 291 206 279 291 minecraft:cyan_stained_glass
fill 202 279 293 203 279 293 minecraft:cyan_stained_glass
fill 202 279 303 203 279 303 minecraft:cyan_stained_glass
fill 202 279 305 206 279 305 minecraft:cyan_stained_glass
fill 202 279 306 202 279 316 minecraft:sea_lantern
fill 203 279 276 204 279 289 minecraft:prismarine_bricks
fill 203 279 290 213 279 290 minecraft:cyan_stained_glass
fill 203 279 297 203 279 299 minecraft:cyan_stained_glass
fill 203 279 306 213 279 306 minecraft:cyan_stained_glass
fill 203 279 307 204 279 316 minecraft:prismarine_bricks
fill 204 279 294 204 279 296 minecraft:cyan_stained_glass
fill 204 279 297 204 279 299 minecraft:sea_lantern
fill 204 279 300 204 279 302 minecraft:cyan_stained_glass
fill 205 279 276 207 279 288 minecraft:prismarine_bricks
fill 205 279 289 211 279 289 minecraft:cyan_stained_glass
fill 205 279 294 206 279 294 minecraft:cyan_stained_glass
fill 205 279 295 205 279 297 minecraft:sea_lantern
fill 205 279 299 205 279 301 minecraft:sea_lantern
fill 205 279 302 206 279 302 minecraft:cyan_stained_glass
fill 205 279 307 211 279 307 minecraft:cyan_stained_glass
fill 205 279 308 207 279 316 minecraft:prismarine_bricks
fill 206 279 295 207 279 295 minecraft:sea_lantern
fill 206 279 301 207 279 301 minecraft:sea_lantern
fill 207 279 293 209 279 293 minecraft:cyan_stained_glass
fill 207 279 294 209 279 294 minecraft:sea_lantern
fill 207 279 302 209 279 302 minecraft:sea_lantern
fill 207 279 303 209 279 303 minecraft:cyan_stained_glass
setblock 208 279 276 minecraft:prismarine_bricks
fill 208 279 280 208 279 288 minecraft:prismarine_bricks
fill 208 279 308 208 279 312 minecraft:prismarine_bricks
setblock 208 279 316 minecraft:prismarine_bricks
setblock 209 279 276 minecraft:sea_lantern
fill 209 279 280 209 279 288 minecraft:sea_lantern
fill 209 279 295 211 279 295 minecraft:sea_lantern
fill 209 279 301 211 279 301 minecraft:sea_lantern
fill 209 279 308 209 279 312 minecraft:sea_lantern
setblock 209 279 316 minecraft:sea_lantern
fill 210 279 276 215 279 276 minecraft:prismarine_bricks
fill 210 279 280 215 279 288 minecraft:prismarine_bricks
fill 210 279 291 214 279 291 minecraft:cyan_stained_glass
fill 210 279 294 212 279 294 minecraft:cyan_stained_glass
fill 210 279 302 212 279 302 minecraft:cyan_stained_glass
fill 210 279 305 214 279 305 minecraft:cyan_stained_glass
fill 210 279 308 215 279 312 minecraft:prismarine_bricks
fill 210 279 316 215 279 316 minecraft:prismarine_bricks
fill 211 279 277 215 279 279 minecraft:prismarine_bricks
fill 211 279 296 211 279 297 minecraft:sea_lantern
fill 211 279 299 211 279 300 minecraft:sea_lantern
fill 211 279 313 215 279 315 minecraft:prismarine_bricks
fill 212 279 289 215 279 289 minecraft:prismarine_bricks
fill 212 279 295 212 279 296 minecraft:cyan_stained_glass
fill 212 279 297 212 279 299 minecraft:sea_lantern
fill 212 279 300 212 279 301 minecraft:cyan_stained_glass
fill 212 279 307 215 279 307 minecraft:prismarine_bricks
fill 213 279 292 215 279 293 minecraft:cyan_stained_glass
fill 213 279 297 213 279 299 minecraft:cyan_stained_glass
fill 213 279 303 215 279 304 minecraft:cyan_stained_glass
fill 214 279 290 215 279 290 minecraft:prismarine_bricks
fill 214 279 306 215 279 306 minecraft:prismarine_bricks
setblock 215 279 291 minecraft:prismarine_bricks
fill 215 279 294 216 279 296 minecraft:cyan_stained_glass
fill 215 279 300 216 279 302 minecraft:cyan_stained_glass
setblock 215 279 305 minecraft:prismarine_bricks
fill 216 279 276 216 279 292 minecraft:sea_lantern
setblock 216 279 293 minecraft:cyan_stained_glass
fill 216 279 297 217 279 299 minecraft:cyan_stained_glass
setblock 216 279 303 minecraft:cyan_stained_glass
fill 216 279 304 216 279 316 minecraft:sea_lantern
fill 217 279 276 222 279 294 minecraft:prismarine_bricks
fill 217 279 295 217 279 296 minecraft:cyan_stained_glass
fill 217 279 300 217 279 301 minecraft:cyan_stained_glass
fill 217 279 302 222 279 316 minecraft:prismarine_bricks
fill 218 279 295 222 279 301 minecraft:prismarine_bricks
fill 223 279 276 223 279 316 minecraft:sea_lantern
fill 224 279 276 224 279 316 minecraft:prismarine_bricks
fill 225 279 276 229 279 277 minecraft:prismarine_bricks
fill 225 279 281 225 279 311 minecraft:prismarine_bricks
fill 225 279 315 229 279 316 minecraft:prismarine_bricks
fill 226 279 281 229 279 294 minecraft:prismarine_bricks
fill 226 279 298 229 279 311 minecraft:prismarine_bricks
fill 228 279 278 229 279 280 minecraft:prismarine_bricks
fill 228 279 312 229 279 314 minecraft:prismarine_bricks
fill 229 279 295 229 279 297 minecraft:prismarine_bricks
fill 188 280 293 188 285 293 minecraft:prismarine
setblock 205 280 297 minecraft:cyan_stained_glass
setblock 205 280 299 minecraft:cyan_stained_glass
setblock 207 280 295 minecraft:cyan_stained_glass
setblock 207 280 301 minecraft:cyan_stained_glass
setblock 209 280 295 minecraft:cyan_stained_glass
setblock 209 280 301 minecraft:cyan_stained_glass
setblock 211 280 297 minecraft:cyan_stained_glass
setblock 211 280 299 minecraft:cyan_stained_glass
setblock 214 280 275 minecraft:sea_lantern
setblock 200 281 317 minecraft:sea_lantern
fill 214 281 275 214 308 275 minecraft:prismarine
fill 200 282 317 200 285 317 minecraft:prismarine
fill 189 283 276 191 300 276 minecraft:prismarine_bricks
fill 189 283 286 189 300 288 minecraft:prismarine_bricks
fill 189 283 298 189 300 300 minecraft:prismarine_bricks
fill 189 283 310 189 300 312 minecraft:prismarine_bricks
fill 190 283 285 190 285 287 minecraft:prismarine_bricks
fill 190 283 298 190 285 299 minecraft:prismarine_bricks
fill 190 283 309 190 285 311 minecraft:prismarine_bricks
fill 195 283 316 197 300 316 minecraft:prismarine_bricks
fill 196 283 315 198 285 315 minecraft:prismarine_bricks
fill 200 283 277 202 285 277 minecraft:prismarine_bricks
fill 200 283 310 200 285 310 minecraft:iron_block
fill 201 283 276 203 300 276 minecraft:prismarine_bricks
setblock 204 283 317 minecraft:sea_lantern
fill 207 283 316 209 300 316 minecraft:prismarine_bricks
fill 212 283 277 214 285 277 minecraft:prismarine_bricks
fill 213 283 276 215 300 276 minecraft:prismarine_bricks
fill 219 283 316 221 300 316 minecraft:prismarine_bricks
fill 220 283 315 222 285 315 minecraft:prismarine_bricks
fill 224 283 277 226 285 277 minecraft:prismarine_bricks
fill 224 283 298 229 284 306 minecraft:prismarine_bricks
fill 224 283 312 224 283 314 minecraft:dark_prismarine
fill 225 283 276 227 300 276 minecraft:prismarine_bricks
fill 225 283 311 227 283 311 minecraft:dark_prismarine
fill 225 283 315 227 283 315 minecraft:dark_prismarine
fill 228 283 285 228 285 287 minecraft:prismarine_bricks
fill 228 283 309 228 285 311 minecraft:prismarine_bricks
fill 228 283 312 228 283 314 minecraft:dark_prismarine
fill 229 283 284 229 300 286 minecraft:prismarine_bricks
fill 229 283 296 229 300 297 minecraft:prismarine_bricks
fill 229 283 308 229 300 310 minecraft:prismarine_bricks
setblock 230 283 277 minecraft:sea_lantern
fill 230 283 301 230 285 301 minecraft:prismarine
setblock 230 283 302 minecraft:prismarine_bricks
setblock 191 284 285 minecraft:light[level=12]
setblock 191 284 292 minecraft:light[level=12]
setblock 191 284 299 minecraft:light[level=12]
setblock 191 284 306 minecraft:light[level=12]
setblock 198 284 278 minecraft:light[level=12]
setblock 198 284 285 minecraft:light[level=12]
setblock 198 284 292 minecraft:light[level=12]
setblock 198 284 299 minecraft:light[level=12]
setblock 198 284 306 minecraft:light[level=12]
setblock 198 284 313 minecraft:light[level=12]
fill 204 284 317 204 308 317 minecraft:prismarine
setblock 205 284 278 minecraft:light[level=12]
setblock 205 284 285 minecraft:light[level=12]
setblock 205 284 292 minecraft:light[level=12]
setblock 205 284 299 minecraft:light[level=12]
setblock 205 284 306 minecraft:light[level=12]
setblock 205 284 313 minecraft:light[level=12]
setblock 207 284 275 minecraft:prismarine_bricks
setblock 212 284 278 minecraft:light[level=12]
setblock 212 284 285 minecraft:light[level=12]
setblock 212 284 292 minecraft:light[level=12]
setblock 212 284 299 minecraft:light[level=12]
setblock 212 284 306 minecraft:light[level=12]
setblock 212 284 313 minecraft:light[level=12]
setblock 219 284 278 minecraft:light[level=12]
setblock 219 284 285 minecraft:light[level=12]
setblock 219 284 292 minecraft:light[level=12]
setblock 219 284 299 minecraft:light[level=12]
setblock 219 284 306 minecraft:light[level=12]
setblock 219 284 313 minecraft:light[level=12]
setblock 226 284 285 minecraft:light[level=12]
setblock 226 284 292 minecraft:light[level=12]
fill 230 284 277 230 285 277 minecraft:prismarine
fill 230 284 302 230 285 302 minecraft:prismarine
fill 189 285 279 189 285 284 minecraft:dark_prismarine
fill 189 285 291 189 285 296 minecraft:dark_prismarine
fill 189 285 303 189 285 308 minecraft:dark_prismarine
fill 189 285 315 189 285 316 minecraft:dark_prismarine
fill 190 285 316 193 285 316 minecraft:dark_prismarine
fill 193 285 276 198 285 276 minecraft:dark_prismarine
fill 200 285 316 205 285 316 minecraft:dark_prismarine
fill 205 285 276 210 285 276 minecraft:dark_prismarine
setblock 207 285 275 minecraft:prismarine
fill 212 285 316 217 285 316 minecraft:dark_prismarine
fill 217 285 276 222 285 276 minecraft:dark_prismarine
setblock 220 285 317 minecraft:prismarine_bricks
fill 221 285 317 221 287 317 minecraft:prismarine
fill 224 285 298 228 285 306 minecraft:prismarine_bricks
fill 224 285 316 229 285 316 minecraft:dark_prismarine
fill 229 285 276 229 285 281 minecraft:dark_prismarine
fill 229 285 288 229 285 293 minecraft:dark_prismarine
fill 229 285 298 229 285 299 minecraft:prismarine_bricks
fill 229 285 300 229 285 305 minecraft:dark_prismarine
setblock 229 285 306 minecraft:prismarine_bricks
fill 229 285 312 229 285 315 minecraft:dark_prismarine
fill 230 285 289 230 292 289 minecraft:sea_lantern
setblock 230 285 290 minecraft:prismarine
fill 188 286 281 188 291 284 minecraft:sea_lantern
fill 188 286 293 188 291 296 minecraft:sea_lantern
fill 188 286 305 188 291 308 minecraft:sea_lantern
fill 188 286 317 191 291 317 minecraft:sea_lantern
setblock 191 286 286 minecraft:light[level=15]
setblock 191 286 294 minecraft:light[level=15]
setblock 191 286 302 minecraft:light[level=15]
setblock 191 286 310 minecraft:light[level=15]
setblock 193 286 275 minecraft:sea_lantern
fill 195 286 275 198 291 275 minecraft:sea_lantern
setblock 199 286 278 minecraft:light[level=15]
setblock 199 286 286 minecraft:light[level=15]
setblock 199 286 294 minecraft:light[level=15]
setblock 199 286 302 minecraft:light[level=15]
setblock 199 286 310 minecraft:light[level=15]
fill 200 286 317 203 291 317 minecraft:sea_lantern
setblock 202 286 275 minecraft:prismarine_bricks
fill 207 286 275 210 291 275 minecraft:sea_lantern
setblock 207 286 278 minecraft:light[level=15]
setblock 207 286 286 minecraft:light[level=15]
setblock 207 286 294 minecraft:light[level=15]
setblock 207 286 302 minecraft:light[level=15]
setblock 207 286 310 minecraft:light[level=15]
fill 212 286 317 215 291 317 minecraft:sea_lantern
setblock 215 286 278 minecraft:light[level=15]
setblock 215 286 286 minecraft:light[level=15]
setblock 215 286 294 minecraft:light[level=15]
setblock 215 286 302 minecraft:light[level=15]
setblock 215 286 310 minecraft:light[level=15]
fill 219 286 275 222 291 275 minecraft:sea_lantern
fill 220 286 317 220 298 317 minecraft:prismarine
setblock 223 286 278 minecraft:light[level=15]
setblock 223 286 286 minecraft:light[level=15]
setblock 223 286 294 minecraft:light[level=15]
setblock 223 286 302 minecraft:light[level=15]
setblock 223 286 310 minecraft:light[level=15]
fill 224 286 298 224 299 298 minecraft:prismarine_bricks
setblock 224 286 299 minecraft:sea_lantern
fill 224 286 300 224 299 300 minecraft:prismarine_bricks
setblock 224 286 301 minecraft:sea_lantern
fill 224 286 302 224 299 302 minecraft:prismarine_bricks
setblock 224 286 303 minecraft:sea_lantern
fill 224 286 304 224 299 304 minecraft:prismarine_bricks
setblock 224 286 305 minecraft:sea_lantern
fill 224 286 306 224 299 306 minecraft:prismarine_bricks
fill 224 286 317 227 291 317 minecraft:sea_lantern
setblock 225 286 298 minecraft:sea_lantern
fill 225 286 299 225 299 299 minecraft:prismarine_bricks
setblock 225 286 300 minecraft:sea_lantern
fill 225 286 301 225 299 301 minecraft:prismarine_bricks
setblock 225 286 302 minecraft:sea_lantern
fill 225 286 303 225 299 303 minecraft:prismarine_bricks
setblock 225 286 304 minecraft:sea_lantern
fill 225 286 305 225 299 305 minecraft:prismarine_bricks
setblock 225 286 306 minecraft:sea_lantern
fill 226 286 298 226 299 298 minecraft:prismarine_bricks
setblock 226 286 299 minecraft:sea_lantern
fill 226 286 300 226 299 300 minecraft:prismarine_bricks
setblock 226 286 301 minecraft:sea_lantern
fill 226 286 302 226 299 302 minecraft:prismarine_bricks
setblock 226 286 303 minecraft:sea_lantern
fill 226 286 304 226 299 304 minecraft:prismarine_bricks
setblock 226 286 305 minecraft:sea_lantern
fill 226 286 306 226 299 306 minecraft:prismarine_bricks
setblock 227 286 298 minecraft:sea_lantern
fill 227 286 299 227 299 299 minecraft:prismarine_bricks
setblock 227 286 300 minecraft:sea_lantern
fill 227 286 301 227 299 301 minecraft:prismarine_bricks
setblock 227 286 302 minecraft:sea_lantern
fill 227 286 303 227 299 303 minecraft:prismarine_bricks
setblock 227 286 304 minecraft:sea_lantern
fill 227 286 305 227 299 305 minecraft:prismarine_bricks
setblock 227 286 306 minecraft:sea_lantern
fill 228 286 298 228 300 298 minecraft:prismarine_bricks
setblock 228 286 299 minecraft:sea_lantern
fill 228 286 300 228 299 300 minecraft:prismarine_bricks
setblock 228 286 301 minecraft:sea_lantern
fill 228 286 302 228 299 302 minecraft:prismarine_bricks
setblock 228 286 303 minecraft:sea_lantern
fill 228 286 304 228 299 304 minecraft:prismarine_bricks
setblock 228 286 305 minecraft:sea_lantern
fill 228 286 306 228 299 306 minecraft:prismarine_bricks
setblock 229 286 298 minecraft:sea_lantern
fill 229 286 299 229 299 299 minecraft:prismarine_bricks
fill 229 286 300 230 286 300 minecraft:sea_lantern
fill 229 286 301 229 299 301 minecraft:prismarine_bricks
fill 229 286 302 230 286 302 minecraft:sea_lantern
fill 229 286 303 229 299 303 minecraft:prismarine_bricks
setblock 229 286 304 minecraft:sea_lantern
fill 229 286 305 229 299 305 minecraft:prismarine_bricks
fill 229 286 306 230 286 306 minecraft:sea_lantern
fill 230 286 276 230 291 279 minecraft:sea_lantern
fill 230 286 288 230 291 288 minecraft:sea_lantern
fill 230 286 290 230 291 291 minecraft:sea_lantern
fill 230 286 301 230 292 301 minecraft:sea_lantern
fill 230 286 303 230 291 303 minecraft:sea_lantern
fill 230 286 312 230 291 315 minecraft:sea_lantern
fill 193 287 275 193 308 275 minecraft:prismarine
setblock 199 287 317 minecraft:prismarine_bricks
fill 202 287 275 202 308 275 minecraft:prismarine
setblock 209 287 317 minecraft:sea_lantern
fill 224 287 299 224 288 299 minecraft:prismarine_bricks
fill 224 287 301 224 288 301 minecraft:prismarine_bricks
fill 224 287 303 224 288 303 minecraft:prismarine_bricks
fill 224 287 305 224 288 305 minecraft:prismarine_bricks
fill 225 287 298 225 288 298 minecraft:prismarine_bricks
fill 225 287 300 225 288 300 minecraft:prismarine_bricks
fill 225 287 302 225 288 302 minecraft:prismarine_bricks
fill 225 287 304 225 288 304 minecraft:prismarine_bricks
fill 225 287 306 225 288 306 minecraft:prismarine_bricks
fill 226 287 299 226 288 299 minecraft:prismarine_bricks
fill 226 287 301 226 288 301 minecraft:prismarine_bricks
fill 226 287 303 226 288 303 minecraft:prismarine_bricks
fill 226 287 305 226 288 305 minecraft:prismarine_bricks
fill 227 287 298 227 288 298 minecraft:prismarine_bricks
fill 227 287 300 227 288 300 minecraft:prismarine_bricks
fill 227 287 302 227 288 302 minecraft:prismarine_bricks
fill 227 287 304 227 288 304 minecraft:prismarine_bricks
fill 227 287 306 227 288 306 minecraft:prismarine_bricks
fill 228 287 299 228 288 299 minecraft:prismarine_bricks
fill 228 287 301 228 288 301 minecraft:prismarine_bricks
fill 228 287 303 228 288 303 minecraft:prismarine_bricks
fill 228 287 305 228 288 305 minecraft:prismarine_bricks
fill 229 287 298 229 288 298 minecraft:prismarine_bricks
fill 229 287 300 229 288 300 minecraft:prismarine_bricks
fill 229 287 302 229 288 302 minecraft:prismarine_bricks
fill 229 287 304 229 288 304 minecraft:prismarine_bricks
fill 229 287 306 229 288 306 minecraft:prismarine_bricks
fill 230 287 300 230 291 300 minecraft:sea_lantern
fill 230 287 302 230 292 302 minecraft:sea_lantern
fill 230 287 306 230 290 306 minecraft:prismarine
fill 199 288 317 199 308 317 minecraft:prismarine
fill 201 288 282 201 289 283 minecraft:white_stained_glass
fill 209 288 317 209 308 317 minecraft:prismarine
setblock 221 288 317 minecraft:prismarine_bricks
setblock 188 289 311 minecraft:sea_lantern
fill 221 289 317 221 308 317 minecraft:prismarine
setblock 224 289 299 minecraft:sea_lantern
setblock 224 289 301 minecraft:sea_lantern
setblock 224 289 303 minecraft:sea_lantern
setblock 224 289 305 minecraft:sea_lantern
setblock 225 289 298 minecraft:sea_lantern
setblock 225 289 300 minecraft:sea_lantern
setblock 225 289 302 minecraft:sea_lantern
setblock 225 289 304 minecraft:sea_lantern
setblock 225 289 306 minecraft:sea_lantern
setblock 226 289 299 minecraft:sea_lantern
setblock 226 289 301 minecraft:sea_lantern
setblock 226 289 303 minecraft:sea_lantern
setblock 226 289 305 minecraft:sea_lantern
setblock 227 289 298 minecraft:sea_lantern
setblock 227 289 300 minecraft:sea_lantern
setblock 227 289 302 minecraft:sea_lantern
setblock 227 289 304 minecraft:sea_lantern
setblock 227 289 306 minecraft:sea_lantern
setblock 228 289 299 minecraft:sea_lantern
setblock 228 289 301 minecraft:sea_lantern
setblock 228 289 303 minecraft:sea_lantern
setblock 228 289 305 minecraft:sea_lantern
setblock 229 289 298 minecraft:sea_lantern
setblock 229 289 300 minecraft:sea_lantern
setblock 229 289 302 minecraft:sea_lantern
setblock 229 289 304 minecraft:sea_lantern
setblock 229 289 306 minecraft:sea_lantern
fill 188 290 311 188 308 311 minecraft:prismarine
setblock 191 290 285 minecraft:light[level=12]
setblock 191 290 292 minecraft:light[level=12]
setblock 191 290 299 minecraft:light[level=12]
setblock 191 290 306 minecraft:light[level=12]
setblock 198 290 278 minecraft:light[level=12]
setblock 198 290 285 minecraft:light[level=12]
setblock 198 290 292 minecraft:light[level=12]
setblock 198 290 299 minecraft:light[level=12]
setblock 198 290 306 minecraft:light[level=12]
setblock 198 290 313 minecraft:light[level=12]
setblock 205 290 278 minecraft:light[level=12]
setblock 205 290 285 minecraft:light[level=12]
setblock 205 290 292 minecraft:light[level=12]
setblock 205 290 299 minecraft:light[level=12]
setblock 205 290 306 minecraft:light[level=12]
setblock 205 290 313 minecraft:light[level=12]
setblock 212 290 278 minecraft:light[level=12]
setblock 212 290 285 minecraft:light[level=12]
setblock 212 290 292 minecraft:light[level=12]
setblock 212 290 299 minecraft:light[level=12]
setblock 212 290 306 minecraft:light[level=12]
setblock 212 290 313 minecraft:light[level=12]
setblock 219 290 278 minecraft:light[level=12]
setblock 219 290 285 minecraft:light[level=12]
setblock 219 290 292 minecraft:light[level=12]
setblock 219 290 299 minecraft:light[level=12]
setblock 219 290 306 minecraft:light[level=12]
setblock 219 290 313 minecraft:light[level=12]
fill 224 290 299 224 291 299 minecraft:prismarine_bricks
fill 224 290 301 224 291 301 minecraft:prismarine_bricks
fill 224 290 303 224 291 303 minecraft:prismarine_bricks
fill 224 290 305 224 291 305 minecraft:prismarine_bricks
fill 225 290 298 225 291 298 minecraft:prismarine_bricks
fill 225 290 300 225 291 300 minecraft:prismarine_bricks
fill 225 290 302 225 291 302 minecraft:prismarine_bricks
fill 225 290 304 225 291 304 minecraft:prismarine_bricks
fill 225 290 306 225 291 306 minecraft:prismarine_bricks
setblock 226 290 285 minecraft:light[level=12]
setblock 226 290 292 minecraft:light[level=12]
fill 226 290 299 226 291 299 minecraft:prismarine_bricks
fill 226 290 301 226 291 301 minecraft:prismarine_bricks
fill 226 290 303 226 291 303 minecraft:prismarine_bricks
fill 226 290 305 226 291 305 minecraft:prismarine_bricks
fill 227 290 298 227 291 298 minecraft:prismarine_bricks
fill 227 290 300 227 291 300 minecraft:prismarine_bricks
fill 227 290 302 227 291 302 minecraft:prismarine_bricks
fill 227 290 304 227 291 304 minecraft:prismarine_bricks
fill 227 290 306 227 291 306 minecraft:prismarine_bricks
fill 228 290 299 228 291 299 minecraft:prismarine_bricks
fill 228 290 301 228 291 301 minecraft:prismarine_bricks
fill 228 290 303 228 291 303 minecraft:prismarine_bricks
fill 228 290 305 228 291 305 minecraft:prismarine_bricks
fill 229 290 298 229 291 298 minecraft:prismarine_bricks
fill 229 290 300 229 291 300 minecraft:prismarine_bricks
fill 229 290 302 229 291 302 minecraft:prismarine_bricks
fill 229 290 304 229 291 304 minecraft:prismarine_bricks
fill 229 290 306 229 291 306 minecraft:prismarine_bricks
setblock 230 290 309 minecraft:prismarine_bricks
fill 188 291 287 188 308 287 minecraft:prismarine
setblock 188 291 288 minecraft:sea_lantern
fill 189 291 296 193 292 296 minecraft:prismarine_bricks
fill 190 291 279 194 292 279 minecraft:prismarine_bricks
fill 190 291 295 192 292 295 minecraft:prismarine_bricks
fill 190 291 297 192 292 297 minecraft:prismarine_bricks
fill 190 291 313 194 292 313 minecraft:prismarine_bricks
fill 191 291 278 193 292 278 minecraft:prismarine_bricks
fill 191 291 280 193 292 280 minecraft:prismarine_bricks
fill 191 291 294 191 292 294 minecraft:prismarine_bricks
fill 191 291 298 191 292 298 minecraft:prismarine_bricks
fill 191 291 312 193 292 312 minecraft:prismarine_bricks
fill 191 291 314 193 292 314 minecraft:prismarine_bricks
fill 192 291 277 192 292 277 minecraft:prismarine_bricks
fill 192 291 281 192 292 281 minecraft:prismarine_bricks
fill 192 291 311 192 292 311 minecraft:prismarine_bricks
fill 192 291 315 192 292 315 minecraft:prismarine_bricks
fill 207 291 278 211 292 278 minecraft:prismarine_bricks
fill 207 291 314 211 292 314 minecraft:prismarine_bricks
fill 208 291 277 210 292 277 minecraft:prismarine_bricks
fill 208 291 279 210 292 279 minecraft:prismarine_bricks
fill 208 291 313 210 292 313 minecraft:prismarine_bricks
fill 208 291 315 210 292 315 minecraft:prismarine_bricks
fill 209 291 276 209 292 276 minecraft:prismarine_bricks
fill 209 291 280 209 292 280 minecraft:prismarine_bricks
fill 209 291 312 209 292 312 minecraft:prismarine_bricks
fill 224 291 279 228 292 279 minecraft:prismarine_bricks
setblock 224 291 312 minecraft:dark_prismarine
fill 224 291 313 228 292 313 minecraft:prismarine_bricks
setblock 224 291 314 minecraft:dark_prismarine
fill 225 291 278 227 292 278 minecraft:prismarine_bricks
fill 225 291 280 227 292 280 minecraft:prismarine_bricks
fill 225 291 296 228 292 296 minecraft:prismarine_bricks
setblock 225 291 311 minecraft:dark_prismarine
fill 225 291 312 227 292 312 minecraft:prismarine_bricks
fill 225 291 314 227 292 314 minecraft:prismarine_bricks
setblock 225 291 315 minecraft:dark_prismarine
fill 226 291 277 226 292 277 minecraft:prismarine_bricks
fill 226 291 281 226 292 281 minecraft:prismarine_bricks
fill 226 291 295 228 292 295 minecraft:prismarine_bricks
fill 226 291 297 228 292 297 minecraft:prismarine_bricks
fill 226 291 311 226 292 311 minecraft:prismarine_bricks
fill 226 291 315 226 292 315 minecraft:prismarine_bricks
fill 227 291 294 227 292 294 minecraft:prismarine_bricks
setblock 227 291 311 minecraft:dark_prismarine
setblock 227 291 315 minecraft:dark_prismarine
setblock 228 291 312 minecraft:dark_prismarine
setblock 228 291 314 minecraft:dark_prismarine
setblock 230 291 306 minecraft:sea_lantern
fill 230 291 309 230 298 309 minecraft:prismarine
fill 188 292 281 188 308 281 minecraft:prismarine
fill 188 292 282 188 292 283 minecraft:sea_lantern
fill 188 292 284 188 308 284 minecraft:prismarine
setblock 188 292 285 minecraft:prismarine_bricks
fill 188 292 288 188 308 288 minecraft:prismarine
fill 188 292 293 188 300 293 minecraft:prismarine
fill 188 292 294 188 292 295 minecraft:sea_lantern
fill 188 292 296 188 308 296 minecraft:prismarine
fill 188 292 305 188 308 305 minecraft:prismarine
fill 188 292 306 188 292 307 minecraft:sea_lantern
fill 188 292 308 188 308 308 minecraft:prismarine
fill 188 292 317 188 308 317 minecraft:prismarine
fill 189 292 317 190 292 317 minecraft:sea_lantern
setblock 190 292 275 minecraft:prismarine_bricks
fill 191 292 317 191 308 317 minecraft:prismarine
fill 195 292 275 195 308 275 minecraft:prismarine
fill 196 292 275 197 292 275 minecraft:sea_lantern
fill 198 292 275 198 308 275 minecraft:prismarine
fill 200 292 317 200 308 317 minecraft:prismarine
fill 201 292 317 202 292 317 minecraft:sea_lantern
fill 203 292 317 203 308 317 minecraft:prismarine
fill 207 292 275 207 308 275 minecraft:prismarine
fill 208 292 275 209 292 275 minecraft:sea_lantern
fill 210 292 275 210 308 275 minecraft:prismarine
fill 212 292 317 212 308 317 minecraft:prismarine
fill 213 292 317 214 292 317 minecraft:sea_lantern
fill 215 292 317 215 303 317 minecraft:prismarine
fill 219 292 275 219 308 275 minecraft:prismarine
fill 220 292 275 221 292 275 minecraft:sea_lantern
fill 222 292 275 222 308 275 minecraft:prismarine
setblock 224 292 299 minecraft:sea_lantern
setblock 224 292 301 minecraft:sea_lantern
setblock 224 292 303 minecraft:sea_lantern
setblock 224 292 305 minecraft:sea_lantern
fill 224 292 317 224 308 317 minecraft:prismarine
setblock 225 292 298 minecraft:sea_lantern
setblock 225 292 300 minecraft:sea_lantern
setblock 225 292 302 minecraft:sea_lantern
setblock 225 292 304 minecraft:sea_lantern
setblock 225 292 306 minecraft:sea_lantern
fill 225 292 317 226 292 317 minecraft:sea_lantern
setblock 226 292 299 minecraft:sea_lantern
setblock 226 292 301 minecraft:sea_lantern
setblock 226 292 303 minecraft:sea_lantern
setblock 226 292 305 minecraft:sea_lantern
setblock 227 292 298 minecraft:sea_lantern
setblock 227 292 300 minecraft:sea_lantern
setblock 227 292 302 minecraft:sea_lantern
setblock 227 292 304 minecraft:sea_lantern
setblock 227 292 306 minecraft:sea_lantern
fill 227 292 317 227 308 317 minecraft:prismarine
setblock 228 292 299 minecraft:sea_lantern
setblock 228 292 301 minecraft:sea_lantern
setblock 228 292 303 minecraft:sea_lantern
setblock 228 292 305 minecraft:sea_lantern
setblock 229 292 298 minecraft:sea_lantern
setblock 229 292 300 minecraft:sea_lantern
setblock 229 292 302 minecraft:sea_lantern
setblock 229 292 304 minecraft:sea_lantern
setblock 229 292 306 minecraft:sea_lantern
fill 230 292 276 230 308 276 minecraft:prismarine
fill 230 292 277 230 292 278 minecraft:sea_lantern
fill 230 292 279 230 308 279 minecraft:prismarine
fill 230 292 288 230 296 288 minecraft:prismarine
setblock 230 292 290 minecraft:sea_lantern
fill 230 292 291 230 308 291 minecraft:prismarine
fill 230 292 300 230 308 300 minecraft:prismarine
fill 230 292 303 230 308 303 minecraft:prismarine
fill 230 292 306 230 308 306 minecraft:prismarine
fill 230 292 312 230 308 312 minecraft:prismarine
fill 230 292 313 230 292 314 minecraft:sea_lantern
fill 230 292 315 230 308 315 minecraft:prismarine
fill 188 293 282 188 308 283 minecraft:prismarine
fill 188 293 285 188 308 285 minecraft:prismarine
fill 188 293 294 188 308 294 minecraft:prismarine
setblock 188 293 295 minecraft:sea_lantern
setblock 188 293 297 minecraft:sea_lantern
fill 188 293 306 188 302 307 minecraft:prismarine
fill 189 293 317 190 308 317 minecraft:prismarine
fill 190 293 275 190 308 275 minecraft:prismarine
fill 190 293 295 192 303 297 minecraft:quartz_pillar
fill 191 293 278 193 303 280 minecraft:quartz_pillar
fill 191 293 312 193 303 314 minecraft:quartz_pillar
fill 196 293 275 197 299 275 minecraft:prismarine
fill 201 293 317 202 297 317 minecraft:prismarine
fill 208 293 275 209 305 275 minecraft:prismarine
fill 208 293 277 210 303 279 minecraft:quartz_pillar
fill 208 293 313 210 303 315 minecraft:quartz_pillar
fill 213 293 317 214 308 317 minecraft:prismarine
fill 220 293 275 221 308 275 minecraft:prismarine
fill 224 293 299 224 294 299 minecraft:prismarine_bricks
fill 224 293 301 224 294 301 minecraft:prismarine_bricks
fill 224 293 303 224 294 303 minecraft:prismarine_bricks
fill 224 293 305 224 294 305 minecraft:prismarine_bricks
fill 225 293 278 227 303 280 minecraft:quartz_pillar
fill 225 293 298 225 294 298 minecraft:prismarine_bricks
fill 225 293 300 225 294 300 minecraft:prismarine_bricks
fill 225 293 302 225 294 302 minecraft:prismarine_bricks
fill 225 293 304 225 294 304 minecraft:prismarine_bricks
fill 225 293 306 225 294 306 minecraft:prismarine_bricks
fill 225 293 312 227 303 314 minecraft:quartz_pillar
fill 225 293 317 226 308 317 minecraft:prismarine
fill 226 293 295 228 303 297 minecraft:quartz_pillar
fill 226 293 299 226 294 299 minecraft:prismarine_bricks
fill 226 293 301 226 294 301 minecraft:prismarine_bricks
fill 226 293 303 226 294 303 minecraft:prismarine_bricks
fill 226 293 305 226 294 305 minecraft:prismarine_bricks
fill 227 293 275 227 308 275 minecraft:prismarine
fill 227 293 298 227 294 298 minecraft:prismarine_bricks
fill 227 293 300 227 294 300 minecraft:prismarine_bricks
fill 227 293 302 227 294 302 minecraft:prismarine_bricks
fill 227 293 304 227 294 304 minecraft:prismarine_bricks
fill 227 293 306 227 294 306 minecraft:prismarine_bricks
setblock 228 293 275 minecraft:prismarine_bricks
fill 228 293 299 228 294 299 minecraft:prismarine_bricks
fill 228 293 301 228 294 301 minecraft:prismarine_bricks
fill 228 293 303 228 294 303 minecraft:prismarine_bricks
fill 228 293 305 228 294 305 minecraft:prismarine_bricks
fill 229 293 298 229 294 298 minecraft:prismarine_bricks
fill 229 293 300 229 294 300 minecraft:prismarine_bricks
fill 229 293 302 229 294 302 minecraft:prismarine_bricks
fill 229 293 304 229 294 304 minecraft:prismarine_bricks
fill 229 293 306 229 294 306 minecraft:prismarine_bricks
fill 230 293 277 230 308 278 minecraft:prismarine
fill 230 293 289 230 308 290 minecraft:prismarine
fill 230 293 301 230 308 302 minecraft:prismarine
fill 230 293 313 230 308 314 minecraft:prismarine
fill 188 294 295 188 308 295 minecraft:prismarine
fill 188 294 297 188 308 297 minecraft:prismarine
setblock 191 294 286 minecraft:light[level=15]
setblock 191 294 294 minecraft:light[level=15]
setblock 191 294 302 minecraft:light[level=15]
setblock 191 294 310 minecraft:light[level=15]
setblock 199 294 278 minecraft:light[level=15]
setblock 199 294 286 minecraft:light[level=15]
setblock 199 294 294 minecraft:light[level=15]
setblock 199 294 302 minecraft:light[level=15]
setblock 199 294 310 minecraft:light[level=15]
setblock 207 294 278 minecraft:light[level=15]
setblock 207 294 286 minecraft:light[level=15]
setblock 207 294 294 minecraft:light[level=15]
setblock 207 294 302 minecraft:light[level=15]
setblock 207 294 310 minecraft:light[level=15]
setblock 215 294 278 minecraft:light[level=15]
setblock 215 294 286 minecraft:light[level=15]
setblock 215 294 294 minecraft:light[level=15]
setblock 215 294 302 minecraft:light[level=15]
setblock 215 294 310 minecraft:light[level=15]
setblock 223 294 278 minecraft:light[level=15]
setblock 223 294 286 minecraft:light[level=15]
setblock 223 294 294 minecraft:light[level=15]
setblock 223 294 302 minecraft:light[level=15]
setblock 223 294 310 minecraft:light[level=15]
fill 228 294 275 228 308 275 minecraft:prismarine
setblock 224 295 299 minecraft:sea_lantern
setblock 224 295 301 minecraft:sea_lantern
setblock 224 295 303 minecraft:sea_lantern
setblock 224 295 305 minecraft:sea_lantern
setblock 225 295 298 minecraft:sea_lantern
setblock 225 295 300 minecraft:sea_lantern
setblock 225 295 302 minecraft:sea_lantern
setblock 225 295 304 minecraft:sea_lantern
setblock 225 295 306 minecraft:sea_lantern
setblock 226 295 299 minecraft:sea_lantern
setblock 226 295 301 minecraft:sea_lantern
setblock 226 295 303 minecraft:sea_lantern
setblock 226 295 305 minecraft:sea_lantern
setblock 227 295 298 minecraft:sea_lantern
setblock 227 295 300 minecraft:sea_lantern
setblock 227 295 302 minecraft:sea_lantern
setblock 227 295 304 minecraft:sea_lantern
setblock 227 295 306 minecraft:sea_lantern
setblock 228 295 299 minecraft:sea_lantern
setblock 228 295 301 minecraft:sea_lantern
setblock 228 295 303 minecraft:sea_lantern
setblock 228 295 305 minecraft:sea_lantern
setblock 229 295 298 minecraft:sea_lantern
setblock 229 295 300 minecraft:sea_lantern
setblock 229 295 302 minecraft:sea_lantern
setblock 229 295 304 minecraft:sea_lantern
setblock 229 295 306 minecraft:sea_lantern
setblock 188 296 277 minecraft:sea_lantern
setblock 191 296 285 minecraft:light[level=12]
setblock 191 296 292 minecraft:light[level=12]
setblock 191 296 299 minecraft:light[level=12]
setblock 191 296 306 minecraft:light[level=12]
setblock 198 296 278 minecraft:light[level=12]
setblock 198 296 285 minecraft:light[level=12]
setblock 198 296 292 minecraft:light[level=12]
setblock 198 296 299 minecraft:light[level=12]
setblock 198 296 306 minecraft:light[level=12]
setblock 198 296 313 minecraft:light[level=12]
setblock 205 296 278 minecraft:light[level=12]
setblock 205 296 285 minecraft:light[level=12]
setblock 205 296 292 minecraft:light[level=12]
setblock 205 296 299 minecraft:light[level=12]
setblock 205 296 306 minecraft:light[level=12]
setblock 205 296 313 minecraft:light[level=12]
setblock 212 296 278 minecraft:light[level=12]
setblock 212 296 285 minecraft:light[level=12]
setblock 212 296 292 minecraft:light[level=12]
setblock 212 296 299 minecraft:light[level=12]
setblock 212 296 306 minecraft:light[level=12]
setblock 212 296 313 minecraft:light[level=12]
setblock 219 296 278 minecraft:light[level=12]
setblock 219 296 285 minecraft:light[level=12]
setblock 219 296 292 minecraft:light[level=12]
setblock 219 296 299 minecraft:light[level=12]
setblock 219 296 306 minecraft:light[level=12]
setblock 219 296 313 minecraft:light[level=12]
fill 224 296 299 224 297 299 minecraft:prismarine_bricks
fill 224 296 301 224 297 301 minecraft:prismarine_bricks
fill 224 296 303 224 297 303 minecraft:prismarine_bricks
fill 224 296 305 224 297 305 minecraft:prismarine_bricks
fill 225 296 298 225 297 298 minecraft:prismarine_bricks
fill 225 296 300 225 297 300 minecraft:prismarine_bricks
fill 225 296 302 225 297 302 minecraft:prismarine_bricks
fill 225 296 304 225 297 304 minecraft:prismarine_bricks
fill 225 296 306 225 297 306 minecraft:prismarine_bricks
setblock 226 296 285 minecraft:light[level=12]
setblock 226 296 292 minecraft:light[level=12]
fill 226 296 299 226 297 299 minecraft:prismarine_bricks
fill 226 296 301 226 297 301 minecraft:prismarine_bricks
fill 226 296 303 226 297 303 minecraft:prismarine_bricks
fill 226 296 305 226 297 305 minecraft:prismarine_bricks
fill 227 296 298 227 297 298 minecraft:prismarine_bricks
fill 227 296 300 227 297 300 minecraft:prismarine_bricks
fill 227 296 302 227 297 302 minecraft:prismarine_bricks
fill 227 296 304 227 297 304 minecraft:prismarine_bricks
fill 227 296 306 227 297 306 minecraft:prismarine_bricks
fill 228 296 299 228 297 299 minecraft:prismarine_bricks
fill 228 296 301 228 297 301 minecraft:prismarine_bricks
fill 228 296 303 228 297 303 minecraft:prismarine_bricks
fill 228 296 305 228 297 305 minecraft:prismarine_bricks
fill 229 296 298 229 297 298 minecraft:prismarine_bricks
fill 229 296 300 229 297 300 minecraft:prismarine_bricks
fill 229 296 302 229 297 302 minecraft:prismarine_bricks
fill 229 296 304 229 297 304 minecraft:prismarine_bricks
fill 229 296 306 229 297 306 minecraft:prismarine_bricks
fill 188 297 277 188 308 277 minecraft:prismarine
setblock 230 297 288 minecraft:prismarine_bricks
setblock 230 297 297 minecraft:prismarine_bricks
fill 191 298 275 191 308 275 minecraft:prismarine
setblock 192 298 275 minecraft:sea_lantern
fill 201 298 317 201 308 317 minecraft:prismarine
setblock 202 298 317 minecraft:prismarine_bricks
setblock 224 298 299 minecraft:sea_lantern
setblock 224 298 301 minecraft:sea_lantern
setblock 224 298 303 minecraft:sea_lantern
setblock 224 298 305 minecraft:sea_lantern
setblock 225 298 298 minecraft:sea_lantern
setblock 225 298 300 minecraft:sea_lantern
setblock 225 298 302 minecraft:sea_lantern
setblock 225 298 304 minecraft:sea_lantern
setblock 225 298 306 minecraft:sea_lantern
setblock 226 298 299 minecraft:sea_lantern
setblock 226 298 301 minecraft:sea_lantern
setblock 226 298 303 minecraft:sea_lantern
setblock 226 298 305 minecraft:sea_lantern
setblock 227 298 298 minecraft:sea_lantern
setblock 227 298 300 minecraft:sea_lantern
setblock 227 298 302 minecraft:sea_lantern
setblock 227 298 304 minecraft:sea_lantern
setblock 227 298 306 minecraft:sea_lantern
setblock 228 298 299 minecraft:sea_lantern
setblock 228 298 301 minecraft:sea_lantern
setblock 228 298 303 minecraft:sea_lantern
setblock 228 298 305 minecraft:sea_lantern
setblock 229 298 298 minecraft:sea_lantern
setblock 229 298 300 minecraft:sea_lantern
setblock 229 298 302 minecraft:sea_lantern
setblock 229 298 304 minecraft:sea_lantern
setblock 229 298 306 minecraft:sea_lantern
fill 230 298 288 230 308 288 minecraft:prismarine
fill 230 298 297 230 308 297 minecraft:prismarine
fill 192 299 275 192 308 275 minecraft:prismarine
fill 202 299 317 202 308 317 minecraft:prismarine
setblock 220 299 317 minecraft:sea_lantern
setblock 224 299 299 minecraft:prismarine_bricks
setblock 224 299 301 minecraft:prismarine_bricks
setblock 224 299 303 minecraft:prismarine_bricks
setblock 224 299 305 minecraft:prismarine_bricks
fill 224 299 312 224 299 314 minecraft:dark_prismarine
setblock 225 299 298 minecraft:prismarine_bricks
setblock 225 299 300 minecraft:prismarine_bricks
setblock 225 299 302 minecraft:prismarine_bricks
setblock 225 299 304 minecraft:prismarine_bricks
setblock 225 299 306 minecraft:prismarine_bricks
fill 225 299 311 227 299 311 minecraft:dark_prismarine
fill 225 299 315 227 299 315 minecraft:dark_prismarine
setblock 226 299 299 minecraft:prismarine_bricks
setblock 226 299 301 minecraft:prismarine_bricks
setblock 226 299 303 minecraft:prismarine_bricks
setblock 226 299 305 minecraft:prismarine_bricks
setblock 227 299 298 minecraft:prismarine_bricks
setblock 227 299 300 minecraft:prismarine_bricks
setblock 227 299 302 minecraft:prismarine_bricks
setblock 227 299 304 minecraft:prismarine_bricks
setblock 227 299 306 minecraft:prismarine_bricks
fill 228 299 299 228 300 299 minecraft:prismarine_bricks
setblock 228 299 301 minecraft:prismarine_bricks
setblock 228 299 303 minecraft:prismarine_bricks
setblock 228 299 305 minecraft:prismarine_bricks
fill 228 299 312 228 299 314 minecraft:dark_prismarine
fill 229 299 298 229 300 298 minecraft:prismarine_bricks
setblock 229 299 300 minecraft:prismarine_bricks
setblock 229 299 302 minecraft:prismarine_bricks
setblock 229 299 304 minecraft:prismarine_bricks
setblock 229 299 306 minecraft:prismarine_bricks
setblock 230 299 309 minecraft:prismarine_bricks
fill 190 300 285 190 300 287 minecraft:prismarine_bricks
fill 190 300 298 190 300 299 minecraft:prismarine_bricks
fill 190 300 309 190 300 311 minecraft:prismarine_bricks
fill 196 300 275 196 308 275 minecraft:prismarine
fill 196 300 315 198 300 315 minecraft:prismarine_bricks
setblock 197 300 275 minecraft:prismarine_bricks
fill 200 300 277 202 300 277 minecraft:prismarine_bricks
fill 212 300 277 214 300 277 minecraft:prismarine_bricks
fill 220 300 315 222 300 315 minecraft:prismarine_bricks
fill 220 300 317 220 308 317 minecraft:prismarine
fill 224 300 277 226 300 277 minecraft:prismarine_bricks
fill 224 300 312 224 300 314 minecraft:gold_block
fill 225 300 299 227 300 305 minecraft:gold_block
fill 225 300 311 227 300 311 minecraft:gold_block
fill 225 300 315 227 300 315 minecraft:gold_block
fill 228 300 285 228 300 287 minecraft:prismarine_bricks
fill 228 300 300 228 300 305 minecraft:gold_block
fill 228 300 309 228 300 311 minecraft:prismarine_bricks
fill 228 300 312 228 300 314 minecraft:gold_block
fill 230 300 309 230 305 309 minecraft:prismarine
setblock 188 301 293 minecraft:sea_lantern
fill 197 301 275 197 308 275 minecraft:prismarine
fill 188 302 293 188 308 293 minecraft:prismarine
setblock 191 302 285 minecraft:light[level=12]
setblock 191 302 286 minecraft:light[level=15]
setblock 191 302 292 minecraft:light[level=12]
setblock 191 302 294 minecraft:light[level=15]
setblock 191 302 299 minecraft:light[level=12]
setblock 191 302 302 minecraft:light[level=15]
setblock 191 302 306 minecraft:light[level=12]
setblock 191 302 310 minecraft:light[level=15]
setblock 198 302 278 minecraft:light[level=12]
setblock 198 302 285 minecraft:light[level=12]
setblock 198 302 292 minecraft:light[level=12]
setblock 198 302 299 minecraft:light[level=12]
setblock 198 302 306 minecraft:light[level=12]
setblock 198 302 313 minecraft:light[level=12]
setblock 199 302 278 minecraft:light[level=15]
setblock 199 302 286 minecraft:light[level=15]
setblock 199 302 294 minecraft:light[level=15]
setblock 199 302 302 minecraft:light[level=15]
setblock 199 302 310 minecraft:light[level=15]
setblock 205 302 278 minecraft:light[level=12]
setblock 205 302 285 minecraft:light[level=12]
setblock 205 302 292 minecraft:light[level=12]
setblock 205 302 299 minecraft:light[level=12]
setblock 205 302 306 minecraft:light[level=12]
setblock 205 302 313 minecraft:light[level=12]
setblock 207 302 278 minecraft:light[level=15]
setblock 207 302 286 minecraft:light[level=15]
setblock 207 302 294 minecraft:light[level=15]
setblock 207 302 302 minecraft:light[level=15]
setblock 207 302 310 minecraft:light[level=15]
setblock 212 302 278 minecraft:light[level=12]
setblock 212 302 285 minecraft:light[level=12]
setblock 212 302 292 minecraft:light[level=12]
setblock 212 302 299 minecraft:light[level=12]
setblock 212 302 306 minecraft:light[level=12]
setblock 212 302 313 minecraft:light[level=12]
setblock 215 302 278 minecraft:light[level=15]
setblock 215 302 286 minecraft:light[level=15]
setblock 215 302 294 minecraft:light[level=15]
setblock 215 302 302 minecraft:light[level=15]
setblock 215 302 310 minecraft:light[level=15]
setblock 219 302 278 minecraft:light[level=12]
setblock 219 302 285 minecraft:light[level=12]
setblock 219 302 292 minecraft:light[level=12]
setblock 219 302 299 minecraft:light[level=12]
setblock 219 302 306 minecraft:light[level=12]
setblock 219 302 313 minecraft:light[level=12]
setblock 223 302 278 minecraft:light[level=15]
setblock 223 302 286 minecraft:light[level=15]
setblock 223 302 294 minecraft:light[level=15]
setblock 223 302 302 minecraft:light[level=15]
setblock 223 302 310 minecraft:light[level=15]
setblock 226 302 285 minecraft:light[level=12]
setblock 226 302 292 minecraft:light[level=12]
setblock 226 302 299 minecraft:light[level=12]
setblock 226 302 306 minecraft:light[level=12]
setblock 230 302 307 minecraft:prismarine_bricks
setblock 188 303 306 minecraft:sea_lantern
fill 188 303 307 188 308 307 minecraft:prismarine
setblock 201 303 275 minecraft:sea_lantern
fill 230 303 307 230 308 307 minecraft:prismarine
fill 188 304 306 188 308 306 minecraft:prismarine
fill 201 304 275 201 308 275 minecraft:prismarine
setblock 215 304 317 minecraft:prismarine_bricks
setblock 188 305 310 minecraft:prismarine_bricks
fill 215 305 317 215 308 317 minecraft:prismarine
setblock 188 306 304 minecraft:sea_lantern
fill 188 306 310 188 308 310 minecraft:prismarine
setblock 208 306 275 minecraft:sea_lantern
fill 209 306 275 209 308 275 minecraft:prismarine
setblock 230 306 309 minecraft:sea_lantern
setblock 188 307 301 minecraft:sea_lantern
fill 188 307 304 188 308 304 minecraft:prismarine
fill 208 307 275 208 308 275 minecraft:prismarine
fill 230 307 309 230 308 309 minecraft:prismarine
setblock 188 308 301 minecraft:prismarine
