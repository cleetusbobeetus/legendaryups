setblock 387 144 316 minecraft:red_terracotta
setblock 388 144 278 minecraft:stripped_oak_log
setblock 389 144 277 minecraft:stripped_oak_log
setblock 389 144 278 minecraft:red_terracotta
setblock 390 144 276 minecraft:stripped_oak_log
fill 390 144 277 391 144 277 minecraft:red_terracotta
fill 391 144 276 394 144 276 minecraft:red_terracotta
fill 398 144 276 399 144 276 minecraft:red_terracotta
setblock 400 144 276 minecraft:stripped_oak_log
setblock 400 144 316 minecraft:stripped_oak_log
fill 401 144 276 404 144 276 minecraft:red_terracotta
fill 401 144 316 404 144 316 minecraft:red_terracotta
setblock 403 144 277 minecraft:red_terracotta
setblock 404 144 277 minecraft:stripped_oak_log
setblock 404 144 280 minecraft:brown_terracotta
fill 404 144 315 405 144 315 minecraft:red_terracotta
setblock 405 144 276 minecraft:stripped_oak_log
setblock 405 144 277 minecraft:red_terracotta
setblock 405 144 316 minecraft:stripped_oak_log
fill 406 144 276 408 144 276 minecraft:red_terracotta
setblock 406 144 278 minecraft:brown_terracotta
setblock 406 144 282 minecraft:brown_terracotta
fill 406 144 316 409 144 316 minecraft:red_terracotta
setblock 408 144 280 minecraft:brown_terracotta
fill 408 144 309 417 145 309 minecraft:stripped_oak_log
fill 411 144 310 417 145 310 minecraft:stripped_oak_log
setblock 417 144 299 minecraft:stripped_oak_log
fill 417 144 300 418 147 300 minecraft:red_terracotta
setblock 417 144 304 minecraft:stripped_oak_log
fill 417 144 305 418 147 305 minecraft:red_terracotta
fill 417 144 307 418 145 307 minecraft:red_terracotta
fill 418 144 276 418 147 299 minecraft:red_terracotta
fill 418 144 301 418 147 304 minecraft:red_terracotta
fill 418 144 306 418 147 306 minecraft:red_terracotta
fill 418 144 308 418 147 316 minecraft:red_terracotta
fill 377 145 279 377 148 279 minecraft:red_terracotta
setblock 377 145 283 minecraft:stripped_oak_log
fill 377 145 284 377 148 284 minecraft:red_terracotta
setblock 377 145 288 minecraft:stripped_oak_log
fill 377 145 289 377 148 289 minecraft:red_terracotta
fill 377 145 301 377 146 301 minecraft:red_terracotta
setblock 377 145 302 minecraft:shroomlight
setblock 377 145 303 minecraft:stripped_oak_log
setblock 377 145 304 minecraft:shroomlight
setblock 377 145 306 minecraft:shroomlight
setblock 377 145 308 minecraft:shroomlight
setblock 377 145 310 minecraft:shroomlight
setblock 377 145 312 minecraft:shroomlight
setblock 377 145 314 minecraft:shroomlight
fill 378 145 280 378 145 281 minecraft:red_terracotta
setblock 378 145 282 minecraft:stripped_oak_log
fill 378 145 283 378 148 283 minecraft:red_terracotta
fill 378 145 285 378 145 286 minecraft:red_terracotta
setblock 378 145 303 minecraft:shroomlight
setblock 378 145 305 minecraft:shroomlight
setblock 378 145 307 minecraft:shroomlight
setblock 378 145 309 minecraft:shroomlight
setblock 378 145 311 minecraft:shroomlight
setblock 378 145 313 minecraft:shroomlight
setblock 379 145 302 minecraft:shroomlight
setblock 379 145 304 minecraft:shroomlight
setblock 379 145 306 minecraft:shroomlight
setblock 379 145 308 minecraft:shroomlight
setblock 379 145 310 minecraft:shroomlight
setblock 379 145 312 minecraft:shroomlight
setblock 379 145 314 minecraft:shroomlight
fill 380 145 276 383 145 276 minecraft:red_terracotta
setblock 380 145 303 minecraft:shroomlight
setblock 380 145 305 minecraft:shroomlight
setblock 380 145 307 minecraft:shroomlight
setblock 380 145 309 minecraft:shroomlight
setblock 380 145 311 minecraft:shroomlight
setblock 380 145 313 minecraft:shroomlight
fill 380 145 315 380 146 315 minecraft:iron_bars
fill 381 145 277 382 145 277 minecraft:red_terracotta
setblock 381 145 302 minecraft:shroomlight
setblock 381 145 304 minecraft:shroomlight
setblock 381 145 306 minecraft:shroomlight
setblock 381 145 308 minecraft:shroomlight
setblock 381 145 310 minecraft:shroomlight
setblock 381 145 312 minecraft:shroomlight
setblock 381 145 314 minecraft:shroomlight
setblock 382 145 278 minecraft:stripped_oak_log
setblock 382 145 303 minecraft:shroomlight
setblock 382 145 305 minecraft:shroomlight
setblock 382 145 307 minecraft:shroomlight
setblock 382 145 309 minecraft:shroomlight
setblock 382 145 311 minecraft:shroomlight
setblock 382 145 313 minecraft:shroomlight
setblock 383 145 277 minecraft:stripped_oak_log
fill 383 145 278 386 145 278 minecraft:red_terracotta
setblock 383 145 302 minecraft:shroomlight
setblock 383 145 304 minecraft:shroomlight
setblock 383 145 306 minecraft:shroomlight
setblock 383 145 308 minecraft:shroomlight
setblock 383 145 310 minecraft:shroomlight
setblock 383 145 312 minecraft:shroomlight
setblock 383 145 314 minecraft:shroomlight
setblock 384 145 276 minecraft:stripped_oak_log
fill 384 145 277 387 145 277 minecraft:red_terracotta
fill 385 145 276 388 145 276 minecraft:red_terracotta
fill 386 145 316 386 147 316 minecraft:red_terracotta
setblock 387 145 278 minecraft:stripped_oak_log
fill 387 145 309 407 145 309 minecraft:stripped_oak_log
setblock 388 145 277 minecraft:stripped_oak_log
fill 388 145 278 388 146 278 minecraft:red_terracotta
setblock 389 145 276 minecraft:stripped_oak_log
fill 389 145 277 390 146 277 minecraft:red_terracotta
fill 390 145 276 393 145 276 minecraft:red_terracotta
fill 397 145 310 410 145 310 minecraft:stripped_oak_log
setblock 398 145 276 minecraft:red_terracotta
setblock 399 145 276 minecraft:stripped_oak_log
fill 400 145 276 403 145 276 minecraft:red_terracotta
fill 400 145 316 403 145 316 minecraft:red_terracotta
setblock 403 145 277 minecraft:stripped_oak_log
fill 403 145 315 404 145 315 minecraft:red_terracotta
setblock 404 145 276 minecraft:stripped_oak_log
setblock 404 145 277 minecraft:red_terracotta
setblock 404 145 316 minecraft:stripped_oak_log
fill 405 145 276 407 146 276 minecraft:red_terracotta
setblock 405 145 315 minecraft:stripped_oak_log
fill 405 145 316 408 145 316 minecraft:red_terracotta
setblock 416 145 304 minecraft:stripped_oak_log
setblock 417 145 298 minecraft:stripped_oak_log
fill 417 145 299 417 148 299 minecraft:red_terracotta
setblock 417 145 303 minecraft:stripped_oak_log
fill 417 145 304 417 148 304 minecraft:red_terracotta
fill 377 146 278 377 149 278 minecraft:red_terracotta
setblock 377 146 282 minecraft:stripped_oak_log
fill 377 146 283 377 149 283 minecraft:red_terracotta
fill 377 146 285 377 146 286 minecraft:red_terracotta
setblock 377 146 287 minecraft:stripped_oak_log
fill 377 146 288 378 148 288 minecraft:red_terracotta
fill 377 146 290 377 146 291 minecraft:red_terracotta
setblock 377 146 302 minecraft:stripped_oak_log
fill 377 146 303 377 146 306 minecraft:red_terracotta
fill 377 146 308 377 147 308 minecraft:stripped_oak_log
fill 377 146 310 377 147 310 minecraft:stripped_oak_log
fill 377 146 312 377 147 312 minecraft:stripped_oak_log
fill 377 146 314 377 147 314 minecraft:stripped_oak_log
setblock 378 146 280 minecraft:red_terracotta
setblock 378 146 281 minecraft:stripped_oak_log
fill 378 146 282 379 148 282 minecraft:red_terracotta
setblock 378 146 285 minecraft:red_terracotta
setblock 378 146 286 minecraft:stripped_oak_log
fill 378 146 287 378 149 287 minecraft:red_terracotta
fill 378 146 303 378 147 303 minecraft:stripped_oak_log
fill 378 146 305 378 147 305 minecraft:stripped_oak_log
fill 378 146 307 378 147 307 minecraft:stripped_oak_log
fill 378 146 309 378 147 309 minecraft:stripped_oak_log
fill 378 146 311 378 147 311 minecraft:stripped_oak_log
fill 378 146 313 378 147 313 minecraft:stripped_oak_log
fill 379 146 276 382 146 276 minecraft:red_terracotta
fill 379 146 281 379 149 281 minecraft:red_terracotta
fill 379 146 283 379 146 284 minecraft:red_terracotta
setblock 379 146 285 minecraft:stripped_oak_log
fill 379 146 286 379 149 286 minecraft:red_terracotta
fill 379 146 302 379 147 302 minecraft:stripped_oak_log
fill 379 146 304 379 147 304 minecraft:stripped_oak_log
fill 379 146 306 379 147 306 minecraft:stripped_oak_log
fill 379 146 308 379 147 308 minecraft:stripped_oak_log
fill 379 146 310 379 147 310 minecraft:stripped_oak_log
fill 379 146 312 379 147 312 minecraft:stripped_oak_log
fill 379 146 314 379 147 314 minecraft:stripped_oak_log
fill 380 146 303 380 147 303 minecraft:stripped_oak_log
fill 380 146 305 380 147 305 minecraft:stripped_oak_log
fill 380 146 307 380 147 307 minecraft:stripped_oak_log
fill 380 146 309 380 147 309 minecraft:stripped_oak_log
fill 380 146 311 380 147 311 minecraft:stripped_oak_log
fill 380 146 313 380 147 313 minecraft:stripped_oak_log
setblock 381 146 277 minecraft:red_terracotta
fill 381 146 302 381 147 302 minecraft:stripped_oak_log
fill 381 146 304 381 147 304 minecraft:stripped_oak_log
fill 381 146 306 381 147 306 minecraft:stripped_oak_log
fill 381 146 308 381 147 308 minecraft:stripped_oak_log
fill 381 146 310 381 147 310 minecraft:stripped_oak_log
fill 381 146 312 381 147 312 minecraft:stripped_oak_log
fill 381 146 314 381 147 314 minecraft:stripped_oak_log
setblock 382 146 277 minecraft:stripped_oak_log
fill 382 146 278 385 146 278 minecraft:red_terracotta
fill 382 146 303 382 147 303 minecraft:stripped_oak_log
fill 382 146 305 382 147 305 minecraft:stripped_oak_log
fill 382 146 307 382 147 307 minecraft:stripped_oak_log
fill 382 146 309 382 147 309 minecraft:stripped_oak_log
fill 382 146 311 382 147 311 minecraft:stripped_oak_log
fill 382 146 313 382 147 313 minecraft:stripped_oak_log
setblock 383 146 276 minecraft:stripped_oak_log
fill 383 146 277 386 146 277 minecraft:red_terracotta
fill 383 146 302 383 147 302 minecraft:stripped_oak_log
fill 383 146 304 383 147 304 minecraft:stripped_oak_log
fill 383 146 306 383 147 306 minecraft:stripped_oak_log
fill 383 146 308 389 146 308 minecraft:stripped_oak_log
fill 383 146 310 383 147 310 minecraft:stripped_oak_log
fill 383 146 312 383 147 312 minecraft:stripped_oak_log
fill 383 146 314 383 147 314 minecraft:stripped_oak_log
fill 384 146 276 387 146 276 minecraft:red_terracotta
fill 384 146 309 405 146 309 minecraft:stripped_oak_log
fill 384 146 316 385 148 316 minecraft:red_terracotta
setblock 386 146 278 minecraft:stripped_oak_log
setblock 387 146 277 minecraft:stripped_oak_log
fill 387 146 278 387 147 278 minecraft:red_terracotta
setblock 387 146 316 minecraft:red_terracotta
setblock 388 146 276 minecraft:stripped_oak_log
fill 388 146 277 388 149 277 minecraft:red_terracotta
fill 389 146 276 392 146 276 minecraft:red_terracotta
setblock 398 146 276 minecraft:stripped_oak_log
fill 399 146 276 402 146 276 minecraft:red_terracotta
fill 399 146 316 402 146 316 minecraft:red_terracotta
fill 402 146 315 403 146 315 minecraft:red_terracotta
setblock 403 146 276 minecraft:stripped_oak_log
setblock 403 146 316 minecraft:stripped_oak_log
fill 404 146 276 404 149 276 minecraft:red_terracotta
setblock 404 146 315 minecraft:stripped_oak_log
fill 404 146 316 407 146 316 minecraft:red_terracotta
fill 405 146 315 405 149 315 minecraft:red_terracotta
fill 406 146 309 416 146 309 minecraft:orange_terracotta
setblock 408 146 316 minecraft:stripped_oak_log
setblock 416 146 303 minecraft:stripped_oak_log
fill 416 146 304 416 148 305 minecraft:red_terracotta
setblock 416 146 310 minecraft:orange_terracotta
setblock 417 146 282 minecraft:stripped_oak_log
fill 417 146 283 417 146 286 minecraft:red_terracotta
setblock 417 146 287 minecraft:stripped_oak_log
fill 417 146 288 417 149 288 minecraft:red_terracotta
setblock 417 146 297 minecraft:stripped_oak_log
fill 417 146 298 417 149 298 minecraft:red_terracotta
setblock 417 146 302 minecraft:stripped_oak_log
fill 417 146 303 417 149 303 minecraft:red_terracotta
setblock 417 146 307 minecraft:stripped_oak_log
fill 417 146 308 417 149 308 minecraft:red_terracotta
fill 418 146 307 418 147 307 minecraft:red_terracotta
setblock 377 147 281 minecraft:stripped_oak_log
fill 377 147 282 377 150 282 minecraft:red_terracotta
setblock 377 147 285 minecraft:red_terracotta
setblock 377 147 286 minecraft:stripped_oak_log
fill 377 147 287 377 150 287 minecraft:red_terracotta
setblock 377 147 290 minecraft:red_terracotta
setblock 377 147 291 minecraft:stripped_oak_log
fill 377 147 292 377 149 293 minecraft:red_terracotta
setblock 377 147 298 minecraft:stripped_oak_log
fill 377 147 299 377 148 299 minecraft:red_terracotta
setblock 377 147 301 minecraft:stripped_oak_log
fill 377 147 302 377 147 305 minecraft:red_terracotta
setblock 377 147 306 minecraft:stripped_oak_log
fill 377 147 307 377 150 307 minecraft:red_terracotta
setblock 378 147 279 minecraft:red_terracotta
setblock 378 147 280 minecraft:stripped_oak_log
fill 378 147 281 378 150 281 minecraft:red_terracotta
setblock 378 147 285 minecraft:stripped_oak_log
fill 378 147 286 378 150 286 minecraft:red_terracotta
setblock 378 147 289 minecraft:red_terracotta
setblock 378 147 290 minecraft:stripped_oak_log
fill 379 147 276 381 147 276 minecraft:red_terracotta
fill 379 147 280 379 150 280 minecraft:red_terracotta
setblock 379 147 283 minecraft:red_terracotta
setblock 379 147 284 minecraft:stripped_oak_log
fill 379 147 285 380 149 285 minecraft:red_terracotta
fill 379 147 287 379 147 288 minecraft:red_terracotta
setblock 380 147 277 minecraft:red_terracotta
setblock 380 147 282 minecraft:red_terracotta
setblock 380 147 283 minecraft:stripped_oak_log
fill 380 147 284 380 150 284 minecraft:red_terracotta
fill 380 147 286 380 148 286 minecraft:red_terracotta
setblock 381 147 277 minecraft:stripped_oak_log
fill 381 147 278 384 147 278 minecraft:red_terracotta
setblock 382 147 276 minecraft:stripped_oak_log
fill 382 147 277 385 147 277 minecraft:red_terracotta
fill 383 147 276 386 147 276 minecraft:red_terracotta
setblock 383 147 308 minecraft:stripped_oak_log
fill 383 147 316 383 150 316 minecraft:red_terracotta
fill 384 147 309 386 147 309 minecraft:stripped_oak_log
setblock 385 147 278 minecraft:stripped_oak_log
setblock 386 147 277 minecraft:stripped_oak_log
fill 386 147 278 386 149 278 minecraft:red_terracotta
setblock 387 147 276 minecraft:stripped_oak_log
fill 387 147 277 387 150 277 minecraft:red_terracotta
fill 387 147 309 404 147 309 minecraft:orange_terracotta
setblock 387 147 316 minecraft:stripped_oak_log
fill 388 147 276 391 147 276 minecraft:red_terracotta
fill 388 147 316 388 150 316 minecraft:red_terracotta
fill 389 147 277 389 148 277 minecraft:red_terracotta
setblock 392 147 276 minecraft:stripped_oak_log
setblock 397 147 316 minecraft:stripped_oak_log
fill 398 147 276 401 147 276 minecraft:red_terracotta
fill 398 147 316 401 147 316 minecraft:red_terracotta
fill 400 147 315 402 147 315 minecraft:red_terracotta
setblock 402 147 276 minecraft:stripped_oak_log
setblock 402 147 316 minecraft:stripped_oak_log
fill 403 147 276 403 150 276 minecraft:red_terracotta
setblock 403 147 315 minecraft:stripped_oak_log
fill 403 147 316 406 147 316 minecraft:red_terracotta
fill 404 147 315 404 150 315 minecraft:red_terracotta
fill 405 147 276 406 147 276 minecraft:red_terracotta
fill 406 147 315 406 148 315 minecraft:red_terracotta
setblock 407 147 316 minecraft:stripped_oak_log
fill 408 147 316 408 148 316 minecraft:red_terracotta
setblock 416 147 301 minecraft:red_terracotta
setblock 416 147 302 minecraft:stripped_oak_log
fill 416 147 303 416 150 303 minecraft:red_terracotta
setblock 416 147 306 minecraft:red_terracotta
setblock 416 147 307 minecraft:stripped_oak_log
setblock 417 147 281 minecraft:stripped_oak_log
fill 417 147 282 417 147 285 minecraft:red_terracotta
setblock 417 147 286 minecraft:stripped_oak_log
fill 417 147 287 417 150 287 minecraft:red_terracotta
fill 417 147 289 417 147 290 minecraft:red_terracotta
setblock 417 147 291 minecraft:stripped_oak_log
fill 417 147 292 417 150 292 minecraft:red_terracotta
setblock 417 147 296 minecraft:stripped_oak_log
fill 417 147 297 417 150 297 minecraft:red_terracotta
setblock 417 147 301 minecraft:stripped_oak_log
fill 417 147 302 417 150 302 minecraft:red_terracotta
setblock 417 147 306 minecraft:stripped_oak_log
fill 417 147 307 417 150 307 minecraft:red_terracotta
fill 417 147 309 417 148 309 minecraft:red_terracotta
fill 376 148 275 376 151 317 minecraft:yellow_terracotta
fill 377 148 275 418 151 275 minecraft:yellow_terracotta
fill 377 148 277 377 150 277 minecraft:red_terracotta
setblock 377 148 280 minecraft:stripped_oak_log
fill 377 148 281 377 151 281 minecraft:red_terracotta
setblock 377 148 285 minecraft:stripped_oak_log
fill 377 148 286 377 151 286 minecraft:red_terracotta
setblock 377 148 290 minecraft:stripped_oak_log
fill 377 148 291 378 150 291 minecraft:red_terracotta
setblock 377 148 294 minecraft:red_terracotta
fill 377 148 298 377 149 298 minecraft:red_terracotta
setblock 377 148 300 minecraft:stripped_oak_log
fill 377 148 301 377 151 301 minecraft:red_terracotta
setblock 377 148 302 minecraft:shroomlight
fill 377 148 303 377 149 303 minecraft:red_terracotta
setblock 377 148 304 minecraft:shroomlight
setblock 377 148 305 minecraft:stripped_oak_log
setblock 377 148 306 minecraft:shroomlight
setblock 377 148 308 minecraft:shroomlight
setblock 377 148 309 minecraft:red_terracotta
setblock 377 148 310 minecraft:shroomlight
setblock 377 148 312 minecraft:shroomlight
setblock 377 148 314 minecraft:shroomlight
fill 377 148 317 418 151 317 minecraft:yellow_terracotta
fill 378 148 276 380 148 276 minecraft:red_terracotta
setblock 378 148 278 minecraft:red_terracotta
setblock 378 148 279 minecraft:stripped_oak_log
fill 378 148 280 378 151 280 minecraft:red_terracotta
setblock 378 148 284 minecraft:stripped_oak_log
fill 378 148 285 378 151 285 minecraft:red_terracotta
setblock 378 148 289 minecraft:stripped_oak_log
fill 378 148 290 379 150 290 minecraft:red_terracotta
fill 378 148 292 378 149 292 minecraft:red_terracotta
setblock 378 148 303 minecraft:shroomlight
setblock 378 148 305 minecraft:shroomlight
fill 378 148 306 378 150 306 minecraft:red_terracotta
setblock 378 148 307 minecraft:shroomlight
setblock 378 148 309 minecraft:shroomlight
setblock 378 148 311 minecraft:shroomlight
setblock 378 148 313 minecraft:shroomlight
setblock 379 148 277 minecraft:red_terracotta
setblock 379 148 283 minecraft:stripped_oak_log
fill 379 148 284 379 151 284 minecraft:red_terracotta
setblock 379 148 287 minecraft:red_terracotta
setblock 379 148 288 minecraft:stripped_oak_log
fill 379 148 289 379 151 289 minecraft:red_terracotta
setblock 379 148 302 minecraft:shroomlight
setblock 379 148 304 minecraft:shroomlight
setblock 379 148 306 minecraft:shroomlight
setblock 379 148 308 minecraft:shroomlight
setblock 379 148 310 minecraft:shroomlight
setblock 379 148 312 minecraft:shroomlight
setblock 379 148 314 minecraft:shroomlight
setblock 380 148 277 minecraft:stripped_oak_log
setblock 380 148 281 minecraft:red_terracotta
setblock 380 148 282 minecraft:stripped_oak_log
fill 380 148 283 380 151 283 minecraft:red_terracotta
setblock 380 148 287 minecraft:stripped_oak_log
fill 380 148 288 380 151 288 minecraft:red_terracotta
setblock 380 148 303 minecraft:shroomlight
setblock 380 148 305 minecraft:shroomlight
setblock 380 148 307 minecraft:shroomlight
setblock 380 148 309 minecraft:shroomlight
setblock 380 148 311 minecraft:shroomlight
setblock 380 148 313 minecraft:shroomlight
setblock 381 148 276 minecraft:stripped_oak_log
fill 381 148 277 383 148 278 minecraft:red_terracotta
setblock 381 148 302 minecraft:shroomlight
setblock 381 148 304 minecraft:shroomlight
setblock 381 148 306 minecraft:shroomlight
setblock 381 148 308 minecraft:shroomlight
setblock 381 148 310 minecraft:shroomlight
setblock 381 148 312 minecraft:shroomlight
setblock 381 148 314 minecraft:shroomlight
setblock 381 148 316 minecraft:stripped_oak_log
fill 382 148 276 385 148 276 minecraft:red_terracotta
setblock 382 148 303 minecraft:shroomlight
setblock 382 148 305 minecraft:shroomlight
setblock 382 148 307 minecraft:shroomlight
setblock 382 148 309 minecraft:shroomlight
setblock 382 148 311 minecraft:shroomlight
setblock 382 148 313 minecraft:shroomlight
fill 382 148 316 382 151 316 minecraft:red_terracotta
setblock 383 148 302 minecraft:shroomlight
setblock 383 148 304 minecraft:shroomlight
setblock 383 148 306 minecraft:shroomlight
setblock 383 148 308 minecraft:shroomlight
setblock 383 148 310 minecraft:shroomlight
setblock 383 148 312 minecraft:shroomlight
setblock 383 148 314 minecraft:shroomlight
setblock 384 148 277 minecraft:red_terracotta
setblock 384 148 278 minecraft:stripped_oak_log
fill 384 148 309 385 148 309 minecraft:orange_terracotta
setblock 385 148 277 minecraft:stripped_oak_log
fill 385 148 278 385 150 278 minecraft:red_terracotta
setblock 386 148 276 minecraft:stripped_oak_log
fill 386 148 277 386 151 277 minecraft:red_terracotta
setblock 386 148 316 minecraft:stripped_oak_log
fill 387 148 276 390 148 276 minecraft:red_terracotta
fill 387 148 316 387 151 316 minecraft:red_terracotta
setblock 391 148 276 minecraft:stripped_oak_log
setblock 396 148 316 minecraft:stripped_oak_log
fill 397 148 276 400 148 276 minecraft:red_terracotta
fill 397 148 316 400 148 316 minecraft:red_terracotta
fill 399 148 315 401 148 315 minecraft:red_terracotta
setblock 401 148 276 minecraft:stripped_oak_log
setblock 401 148 316 minecraft:stripped_oak_log
fill 402 148 276 402 151 276 minecraft:red_terracotta
setblock 402 148 314 minecraft:red_terracotta
setblock 402 148 315 minecraft:stripped_oak_log
fill 402 148 316 405 148 316 minecraft:red_terracotta
setblock 403 148 314 minecraft:stripped_oak_log
fill 403 148 315 403 151 315 minecraft:red_terracotta
fill 404 148 314 404 151 314 minecraft:red_terracotta
setblock 405 148 276 minecraft:red_terracotta
setblock 406 148 276 minecraft:stripped_oak_log
setblock 406 148 316 minecraft:stripped_oak_log
fill 407 148 316 407 151 316 minecraft:red_terracotta
fill 416 148 284 416 148 285 minecraft:red_terracotta
setblock 416 148 286 minecraft:stripped_oak_log
fill 416 148 287 416 150 288 minecraft:red_terracotta
setblock 416 148 301 minecraft:stripped_oak_log
fill 416 148 302 416 151 302 minecraft:red_terracotta
setblock 416 148 306 minecraft:stripped_oak_log
fill 416 148 307 416 150 308 minecraft:red_terracotta
setblock 417 148 280 minecraft:stripped_oak_log
fill 417 148 281 417 148 284 minecraft:red_terracotta
setblock 417 148 285 minecraft:stripped_oak_log
fill 417 148 286 417 151 286 minecraft:red_terracotta
setblock 417 148 289 minecraft:red_terracotta
setblock 417 148 290 minecraft:stripped_oak_log
fill 417 148 291 417 151 291 minecraft:red_terracotta
fill 417 148 293 417 148 294 minecraft:red_terracotta
setblock 417 148 295 minecraft:stripped_oak_log
fill 417 148 296 417 151 296 minecraft:red_terracotta
setblock 417 148 300 minecraft:stripped_oak_log
fill 417 148 301 417 151 301 minecraft:red_terracotta
setblock 417 148 305 minecraft:stripped_oak_log
fill 417 148 306 417 151 306 minecraft:red_terracotta
setblock 417 148 310 minecraft:stripped_oak_log
fill 417 148 311 417 151 311 minecraft:red_terracotta
fill 418 148 276 418 151 316 minecraft:yellow_terracotta
fill 377 149 276 379 149 276 minecraft:red_terracotta
setblock 377 149 279 minecraft:stripped_oak_log
fill 377 149 280 377 152 280 minecraft:red_terracotta
setblock 377 149 284 minecraft:stripped_oak_log
fill 377 149 285 377 152 285 minecraft:red_terracotta
setblock 377 149 288 minecraft:red_terracotta
setblock 377 149 289 minecraft:stripped_oak_log
fill 377 149 290 377 152 290 minecraft:red_terracotta
setblock 377 149 294 minecraft:stripped_oak_log
fill 377 149 295 377 150 297 minecraft:red_terracotta
setblock 377 149 299 minecraft:stripped_oak_log
fill 377 149 300 377 152 300 minecraft:red_terracotta
fill 377 149 302 377 150 302 minecraft:red_terracotta
setblock 377 149 304 minecraft:stripped_oak_log
fill 377 149 305 377 150 306 minecraft:red_terracotta
setblock 377 149 308 minecraft:red_terracotta
setblock 377 149 309 minecraft:stripped_oak_log
fill 377 149 310 377 150 311 minecraft:red_terracotta
setblock 377 149 312 minecraft:stripped_oak_log
fill 377 149 314 377 150 314 minecraft:stripped_oak_log
setblock 378 149 278 minecraft:stripped_oak_log
fill 378 149 279 379 151 279 minecraft:red_terracotta
setblock 378 149 282 minecraft:red_terracotta
setblock 378 149 283 minecraft:stripped_oak_log
fill 378 149 284 378 152 284 minecraft:red_terracotta
setblock 378 149 288 minecraft:stripped_oak_log
fill 378 149 289 378 152 289 minecraft:red_terracotta
setblock 378 149 293 minecraft:stripped_oak_log
setblock 378 149 303 minecraft:stripped_oak_log
fill 378 149 304 378 150 305 minecraft:red_terracotta
setblock 378 149 307 minecraft:red_terracotta
fill 378 149 309 378 150 309 minecraft:red_terracotta
setblock 378 149 311 minecraft:stripped_oak_log
fill 378 149 313 378 150 313 minecraft:stripped_oak_log
setblock 379 149 277 minecraft:stripped_oak_log
setblock 379 149 278 minecraft:light[level=12]
setblock 379 149 282 minecraft:stripped_oak_log
fill 379 149 283 379 152 283 minecraft:red_terracotta
setblock 379 149 287 minecraft:stripped_oak_log
fill 379 149 288 379 152 288 minecraft:red_terracotta
setblock 379 149 291 minecraft:red_terracotta
setblock 379 149 292 minecraft:light[level=12]
fill 379 149 302 379 150 302 minecraft:stripped_oak_log
fill 379 149 304 379 150 304 minecraft:stripped_oak_log
fill 379 149 306 379 150 306 minecraft:stripped_oak_log
fill 379 149 308 379 150 308 minecraft:stripped_oak_log
fill 379 149 310 379 150 310 minecraft:stripped_oak_log
fill 379 149 312 379 150 312 minecraft:stripped_oak_log
fill 379 149 314 379 150 314 minecraft:stripped_oak_log
setblock 380 149 276 minecraft:stripped_oak_log
fill 380 149 277 382 149 278 minecraft:red_terracotta
setblock 380 149 281 minecraft:stripped_oak_log
fill 380 149 282 380 152 282 minecraft:red_terracotta
setblock 380 149 286 minecraft:stripped_oak_log
fill 380 149 287 380 152 287 minecraft:red_terracotta
fill 380 149 289 380 150 289 minecraft:red_terracotta
fill 380 149 303 380 150 303 minecraft:stripped_oak_log
fill 380 149 305 380 150 305 minecraft:stripped_oak_log
fill 380 149 307 380 150 307 minecraft:stripped_oak_log
fill 380 149 309 380 150 309 minecraft:stripped_oak_log
fill 380 149 311 380 150 311 minecraft:stripped_oak_log
fill 380 149 313 380 150 313 minecraft:stripped_oak_log
setblock 380 149 316 minecraft:stripped_oak_log
fill 381 149 276 384 149 276 minecraft:red_terracotta
fill 381 149 283 381 149 284 minecraft:red_terracotta
setblock 381 149 285 minecraft:stripped_oak_log
fill 381 149 286 381 152 286 minecraft:red_terracotta
fill 381 149 302 381 150 302 minecraft:stripped_oak_log
fill 381 149 304 381 150 304 minecraft:stripped_oak_log
fill 381 149 306 381 150 306 minecraft:stripped_oak_log
fill 381 149 308 381 150 308 minecraft:stripped_oak_log
fill 381 149 310 381 150 310 minecraft:stripped_oak_log
fill 381 149 312 381 150 312 minecraft:stripped_oak_log
fill 381 149 314 381 150 314 minecraft:stripped_oak_log
fill 381 149 316 381 152 316 minecraft:red_terracotta
fill 382 149 303 382 150 303 minecraft:stripped_oak_log
fill 382 149 305 382 150 305 minecraft:stripped_oak_log
fill 382 149 307 382 150 307 minecraft:stripped_oak_log
fill 382 149 309 382 150 309 minecraft:stripped_oak_log
fill 382 149 311 382 150 311 minecraft:stripped_oak_log
fill 382 149 313 382 150 313 minecraft:stripped_oak_log
setblock 383 149 277 minecraft:red_terracotta
setblock 383 149 278 minecraft:stripped_oak_log
fill 383 149 302 383 150 302 minecraft:stripped_oak_log
fill 383 149 304 383 150 304 minecraft:stripped_oak_log
fill 383 149 306 383 150 306 minecraft:stripped_oak_log
fill 383 149 308 383 150 308 minecraft:stripped_oak_log
fill 383 149 310 383 150 310 minecraft:stripped_oak_log
fill 383 149 312 383 150 312 minecraft:stripped_oak_log
fill 383 149 314 383 150 314 minecraft:stripped_oak_log
setblock 384 149 277 minecraft:stripped_oak_log
fill 384 149 278 384 151 278 minecraft:red_terracotta
fill 384 149 315 384 149 316 minecraft:red_terracotta
setblock 385 149 276 minecraft:stripped_oak_log
fill 385 149 277 385 152 277 minecraft:red_terracotta
setblock 385 149 316 minecraft:stripped_oak_log
fill 386 149 276 389 149 276 minecraft:red_terracotta
setblock 386 149 285 minecraft:light[level=12]
setblock 386 149 292 minecraft:light[level=12]
setblock 386 149 299 minecraft:light[level=12]
setblock 386 149 306 minecraft:light[level=12]
setblock 386 149 313 minecraft:light[level=12]
fill 386 149 316 386 152 316 minecraft:red_terracotta
setblock 389 149 316 minecraft:red_terracotta
setblock 390 149 276 minecraft:stripped_oak_log
setblock 390 149 316 minecraft:stripped_oak_log
fill 391 149 276 391 150 276 minecraft:red_terracotta
setblock 393 149 278 minecraft:light[level=12]
setblock 393 149 285 minecraft:light[level=12]
setblock 393 149 292 minecraft:light[level=12]
setblock 393 149 299 minecraft:light[level=12]
setblock 393 149 306 minecraft:light[level=12]
setblock 393 149 313 minecraft:light[level=12]
setblock 394 149 316 minecraft:red_terracotta
setblock 395 149 316 minecraft:stripped_oak_log
fill 396 149 276 399 149 276 minecraft:red_terracotta
fill 396 149 316 399 149 316 minecraft:red_terracotta
fill 397 149 315 400 149 315 minecraft:red_terracotta
setblock 400 149 276 minecraft:stripped_oak_log
setblock 400 149 278 minecraft:light[level=12]
setblock 400 149 285 minecraft:light[level=12]
setblock 400 149 292 minecraft:light[level=12]
setblock 400 149 299 minecraft:light[level=12]
setblock 400 149 306 minecraft:light[level=12]
setblock 400 149 313 minecraft:light[level=12]
fill 400 149 314 401 149 314 minecraft:red_terracotta
setblock 400 149 316 minecraft:stripped_oak_log
fill 401 149 276 401 152 276 minecraft:red_terracotta
setblock 401 149 315 minecraft:stripped_oak_log
fill 401 149 316 404 149 316 minecraft:red_terracotta
setblock 402 149 314 minecraft:stripped_oak_log
fill 402 149 315 402 152 315 minecraft:red_terracotta
fill 403 149 314 403 152 314 minecraft:red_terracotta
setblock 405 149 276 minecraft:stripped_oak_log
setblock 405 149 316 minecraft:stripped_oak_log
setblock 406 149 315 minecraft:stripped_oak_log
fill 406 149 316 406 152 316 minecraft:red_terracotta
setblock 407 149 278 minecraft:light[level=12]
setblock 407 149 285 minecraft:light[level=12]
setblock 407 149 292 minecraft:light[level=12]
setblock 407 149 299 minecraft:light[level=12]
setblock 407 149 306 minecraft:light[level=12]
setblock 407 149 313 minecraft:light[level=12]
setblock 414 149 278 minecraft:light[level=12]
setblock 414 149 285 minecraft:light[level=12]
setblock 414 149 292 minecraft:light[level=12]
setblock 414 149 299 minecraft:light[level=12]
setblock 414 149 306 minecraft:light[level=12]
setblock 414 149 313 minecraft:light[level=12]
fill 416 149 283 416 149 284 minecraft:red_terracotta
setblock 416 149 285 minecraft:stripped_oak_log
fill 416 149 286 416 152 286 minecraft:red_terracotta
setblock 416 149 289 minecraft:red_terracotta
setblock 416 149 290 minecraft:stripped_oak_log
fill 416 149 291 416 152 291 minecraft:red_terracotta
fill 416 149 301 416 151 301 minecraft:red_terracotta
setblock 416 149 304 minecraft:red_terracotta
setblock 416 149 305 minecraft:stripped_oak_log
fill 416 149 306 416 152 306 minecraft:red_terracotta
setblock 416 149 309 minecraft:red_terracotta
fill 417 149 280 417 149 283 minecraft:red_terracotta
setblock 417 149 284 minecraft:stripped_oak_log
fill 417 149 285 417 152 285 minecraft:red_terracotta
setblock 417 149 289 minecraft:stripped_oak_log
fill 417 149 290 417 152 290 minecraft:red_terracotta
setblock 417 149 293 minecraft:red_terracotta
setblock 417 149 294 minecraft:stripped_oak_log
fill 417 149 295 417 152 295 minecraft:red_terracotta
setblock 417 149 299 minecraft:stripped_oak_log
fill 417 149 300 417 152 300 minecraft:red_terracotta
setblock 417 149 304 minecraft:stripped_oak_log
fill 417 149 305 417 152 305 minecraft:red_terracotta
setblock 417 149 309 minecraft:stripped_oak_log
fill 417 149 310 417 152 310 minecraft:red_terracotta
fill 417 149 312 417 150 312 minecraft:red_terracotta
fill 377 150 276 378 150 276 minecraft:red_terracotta
setblock 377 150 278 minecraft:stripped_oak_log
fill 377 150 279 377 153 279 minecraft:red_terracotta
setblock 377 150 283 minecraft:stripped_oak_log
fill 377 150 284 377 153 284 minecraft:red_terracotta
setblock 377 150 288 minecraft:stripped_oak_log
fill 377 150 289 377 153 289 minecraft:red_terracotta
setblock 377 150 292 minecraft:red_terracotta
setblock 377 150 293 minecraft:stripped_oak_log
fill 377 150 294 378 152 294 minecraft:red_terracotta
setblock 377 150 298 minecraft:stripped_oak_log
fill 377 150 299 377 153 299 minecraft:red_terracotta
setblock 377 150 303 minecraft:stripped_oak_log
setblock 377 150 304 minecraft:red_terracotta
setblock 377 150 308 minecraft:stripped_oak_log
fill 377 150 309 377 153 309 minecraft:red_terracotta
setblock 377 150 312 minecraft:red_terracotta
setblock 378 150 277 minecraft:stripped_oak_log
fill 378 150 278 378 153 278 minecraft:red_terracotta
setblock 378 150 282 minecraft:stripped_oak_log
fill 378 150 283 378 153 283 minecraft:red_terracotta
setblock 378 150 287 minecraft:stripped_oak_log
fill 378 150 288 378 153 288 minecraft:red_terracotta
setblock 378 150 292 minecraft:stripped_oak_log
fill 378 150 293 378 153 293 minecraft:red_terracotta
setblock 378 150 303 minecraft:red_terracotta
setblock 378 150 307 minecraft:stripped_oak_log
fill 378 150 308 378 153 308 minecraft:red_terracotta
fill 378 150 310 378 150 311 minecraft:red_terracotta
setblock 379 150 276 minecraft:stripped_oak_log
fill 379 150 277 382 150 277 minecraft:red_terracotta
setblock 379 150 281 minecraft:stripped_oak_log
fill 379 150 282 379 153 282 minecraft:red_terracotta
setblock 379 150 285 minecraft:red_terracotta
setblock 379 150 286 minecraft:stripped_oak_log
fill 379 150 287 379 153 287 minecraft:red_terracotta
setblock 379 150 291 minecraft:stripped_oak_log
fill 379 150 292 379 153 292 minecraft:red_terracotta
fill 379 150 294 380 154 294 minecraft:stripped_oak_log
setblock 379 150 316 minecraft:stripped_oak_log
fill 380 150 276 383 150 276 minecraft:red_terracotta
fill 380 150 278 381 150 278 minecraft:red_terracotta
fill 380 150 281 380 151 281 minecraft:red_terracotta
setblock 380 150 285 minecraft:stripped_oak_log
fill 380 150 286 380 153 286 minecraft:red_terracotta
setblock 380 150 290 minecraft:stripped_oak_log
fill 380 150 316 380 153 316 minecraft:red_terracotta
setblock 381 150 283 minecraft:red_terracotta
setblock 381 150 284 minecraft:stripped_oak_log
fill 381 150 285 381 151 285 minecraft:red_terracotta
fill 381 150 287 381 151 287 minecraft:red_terracotta
fill 381 150 315 384 150 315 minecraft:red_terracotta
setblock 382 150 278 minecraft:stripped_oak_log
setblock 383 150 277 minecraft:stripped_oak_log
fill 383 150 278 383 152 278 minecraft:red_terracotta
setblock 384 150 276 minecraft:stripped_oak_log
fill 384 150 277 384 153 277 minecraft:red_terracotta
setblock 384 150 316 minecraft:stripped_oak_log
fill 385 150 276 388 150 276 minecraft:red_terracotta
setblock 385 150 315 minecraft:stripped_oak_log
fill 385 150 316 385 153 316 minecraft:red_terracotta
fill 386 150 315 386 153 315 minecraft:red_terracotta
setblock 389 150 276 minecraft:stripped_oak_log
setblock 389 150 316 minecraft:stripped_oak_log
fill 390 150 276 390 151 276 minecraft:red_terracotta
fill 390 150 316 393 150 316 minecraft:red_terracotta
setblock 394 150 316 minecraft:stripped_oak_log
fill 395 150 276 398 150 276 minecraft:red_terracotta
fill 395 150 316 398 150 316 minecraft:red_terracotta
fill 396 150 315 399 150 315 minecraft:red_terracotta
fill 398 150 314 400 150 314 minecraft:red_terracotta
setblock 399 150 276 minecraft:stripped_oak_log
setblock 399 150 316 minecraft:stripped_oak_log
fill 400 150 276 400 153 276 minecraft:red_terracotta
fill 400 150 313 401 150 313 minecraft:red_terracotta
setblock 400 150 315 minecraft:stripped_oak_log
fill 400 150 316 403 150 316 minecraft:red_terracotta
setblock 401 150 314 minecraft:stripped_oak_log
fill 401 150 315 401 153 315 minecraft:red_terracotta
setblock 402 150 313 minecraft:stripped_oak_log
fill 402 150 314 402 153 314 minecraft:red_terracotta
fill 403 150 313 403 153 313 minecraft:red_terracotta
setblock 404 150 276 minecraft:stripped_oak_log
setblock 404 150 316 minecraft:stripped_oak_log
setblock 405 150 276 minecraft:red_terracotta
setblock 405 150 314 minecraft:red_terracotta
setblock 405 150 315 minecraft:stripped_oak_log
fill 405 150 316 405 153 316 minecraft:red_terracotta
fill 406 150 315 406 152 315 minecraft:red_terracotta
setblock 416 150 283 minecraft:red_terracotta
setblock 416 150 284 minecraft:stripped_oak_log
fill 416 150 285 416 153 285 minecraft:red_terracotta
setblock 416 150 289 minecraft:stripped_oak_log
fill 416 150 290 416 153 290 minecraft:red_terracotta
fill 416 150 292 416 150 293 minecraft:red_terracotta
setblock 416 150 304 minecraft:stripped_oak_log
fill 416 150 305 416 153 305 minecraft:red_terracotta
setblock 416 150 309 minecraft:stripped_oak_log
fill 416 150 310 416 153 310 minecraft:red_terracotta
fill 417 150 279 417 150 282 minecraft:red_terracotta
setblock 417 150 283 minecraft:stripped_oak_log
fill 417 150 284 417 153 284 minecraft:red_terracotta
setblock 417 150 288 minecraft:stripped_oak_log
fill 417 150 289 417 153 289 minecraft:red_terracotta
setblock 417 150 293 minecraft:stripped_oak_log
fill 417 150 294 417 153 294 minecraft:red_terracotta
setblock 417 150 298 minecraft:stripped_oak_log
fill 417 150 299 417 153 299 minecraft:red_terracotta
setblock 417 150 303 minecraft:stripped_oak_log
fill 417 150 304 417 153 304 minecraft:red_terracotta
setblock 417 150 308 minecraft:stripped_oak_log
fill 417 150 309 417 153 309 minecraft:red_terracotta
setblock 417 150 313 minecraft:stripped_oak_log
setblock 377 151 276 minecraft:red_terracotta
setblock 377 151 277 minecraft:stripped_oak_log
fill 377 151 278 377 154 278 minecraft:red_terracotta
setblock 377 151 282 minecraft:stripped_oak_log
fill 377 151 283 377 154 283 minecraft:red_terracotta
setblock 377 151 287 minecraft:stripped_oak_log
fill 377 151 288 377 154 288 minecraft:red_terracotta
setblock 377 151 291 minecraft:red_terracotta
setblock 377 151 292 minecraft:stripped_oak_log
fill 377 151 293 377 154 293 minecraft:red_terracotta
fill 377 151 295 377 151 296 minecraft:red_terracotta
fill 377 151 297 378 151 297 minecraft:stripped_oak_log
fill 377 151 298 377 154 298 minecraft:red_terracotta
setblock 377 151 302 minecraft:shroomlight
fill 377 151 303 377 153 303 minecraft:red_terracotta
setblock 377 151 304 minecraft:shroomlight
fill 377 151 305 377 152 305 minecraft:red_terracotta
setblock 377 151 306 minecraft:shroomlight
setblock 377 151 307 minecraft:stripped_oak_log
setblock 377 151 308 minecraft:shroomlight
setblock 377 151 310 minecraft:shroomlight
setblock 377 151 311 minecraft:red_terracotta
setblock 377 151 312 minecraft:shroomlight
fill 377 151 313 377 154 313 minecraft:red_terracotta
setblock 377 151 314 minecraft:shroomlight
fill 377 151 315 377 152 315 minecraft:red_terracotta
setblock 378 151 276 minecraft:stripped_oak_log
fill 378 151 277 381 151 277 minecraft:red_terracotta
setblock 378 151 281 minecraft:stripped_oak_log
fill 378 151 282 378 154 282 minecraft:red_terracotta
setblock 378 151 286 minecraft:stripped_oak_log
fill 378 151 287 378 154 287 minecraft:red_terracotta
setblock 378 151 290 minecraft:red_terracotta
setblock 378 151 291 minecraft:stripped_oak_log
fill 378 151 292 378 154 292 minecraft:red_terracotta
setblock 378 151 295 minecraft:red_terracotta
fill 378 151 296 378 154 296 minecraft:stripped_oak_log
setblock 378 151 303 minecraft:shroomlight
setblock 378 151 304 minecraft:red_terracotta
setblock 378 151 305 minecraft:shroomlight
setblock 378 151 306 minecraft:stripped_oak_log
setblock 378 151 307 minecraft:shroomlight
setblock 378 151 309 minecraft:shroomlight
setblock 378 151 310 minecraft:red_terracotta
setblock 378 151 311 minecraft:shroomlight
fill 378 151 312 378 154 312 minecraft:red_terracotta
setblock 378 151 313 minecraft:shroomlight
setblock 378 151 316 minecraft:stripped_oak_log
fill 379 151 276 382 151 276 minecraft:red_terracotta
setblock 379 151 278 minecraft:light[level=15]
setblock 379 151 280 minecraft:stripped_oak_log
fill 379 151 281 379 154 281 minecraft:red_terracotta
setblock 379 151 285 minecraft:stripped_oak_log
fill 379 151 286 379 154 286 minecraft:red_terracotta
setblock 379 151 290 minecraft:stripped_oak_log
fill 379 151 291 379 154 291 minecraft:red_terracotta
setblock 379 151 302 minecraft:shroomlight
setblock 379 151 304 minecraft:shroomlight
setblock 379 151 306 minecraft:shroomlight
setblock 379 151 308 minecraft:shroomlight
setblock 379 151 310 minecraft:shroomlight
setblock 379 151 312 minecraft:shroomlight
setblock 379 151 314 minecraft:shroomlight
fill 379 151 316 379 154 316 minecraft:red_terracotta
setblock 380 151 278 minecraft:red_terracotta
setblock 380 151 284 minecraft:stripped_oak_log
fill 380 151 285 380 154 285 minecraft:red_terracotta
setblock 380 151 289 minecraft:stripped_oak_log
fill 380 151 290 380 154 290 minecraft:red_terracotta
setblock 380 151 303 minecraft:shroomlight
setblock 380 151 305 minecraft:shroomlight
setblock 380 151 307 minecraft:shroomlight
setblock 380 151 309 minecraft:shroomlight
setblock 380 151 311 minecraft:shroomlight
setblock 380 151 313 minecraft:shroomlight
fill 380 151 315 383 151 315 minecraft:red_terracotta
setblock 381 151 278 minecraft:stripped_oak_log
setblock 381 151 284 minecraft:red_terracotta
setblock 381 151 302 minecraft:shroomlight
setblock 381 151 304 minecraft:shroomlight
setblock 381 151 306 minecraft:shroomlight
setblock 381 151 308 minecraft:shroomlight
setblock 381 151 310 minecraft:shroomlight
setblock 381 151 312 minecraft:shroomlight
setblock 381 151 314 minecraft:shroomlight
setblock 382 151 277 minecraft:stripped_oak_log
fill 382 151 278 382 152 278 minecraft:red_terracotta
setblock 382 151 303 minecraft:shroomlight
setblock 382 151 305 minecraft:shroomlight
setblock 382 151 307 minecraft:shroomlight
setblock 382 151 309 minecraft:shroomlight
setblock 382 151 311 minecraft:shroomlight
setblock 382 151 313 minecraft:shroomlight
setblock 383 151 276 minecraft:stripped_oak_log
fill 383 151 277 383 154 277 minecraft:red_terracotta
setblock 383 151 302 minecraft:shroomlight
setblock 383 151 304 minecraft:shroomlight
setblock 383 151 306 minecraft:shroomlight
setblock 383 151 308 minecraft:shroomlight
setblock 383 151 310 minecraft:shroomlight
setblock 383 151 312 minecraft:shroomlight
setblock 383 151 314 minecraft:shroomlight
setblock 383 151 316 minecraft:stripped_oak_log
fill 384 151 276 387 151 276 minecraft:red_terracotta
setblock 384 151 315 minecraft:stripped_oak_log
fill 384 151 316 384 154 316 minecraft:red_terracotta
fill 385 151 315 385 154 315 minecraft:red_terracotta
setblock 387 151 277 minecraft:stripped_oak_log
setblock 387 151 278 minecraft:light[level=15]
setblock 387 151 286 minecraft:light[level=15]
setblock 387 151 294 minecraft:light[level=15]
setblock 387 151 302 minecraft:light[level=15]
setblock 387 151 310 minecraft:light[level=15]
setblock 388 151 276 minecraft:stripped_oak_log
setblock 388 151 316 minecraft:stripped_oak_log
fill 389 151 276 389 152 276 minecraft:red_terracotta
fill 389 151 316 392 151 316 minecraft:red_terracotta
setblock 393 151 316 minecraft:stripped_oak_log
fill 394 151 316 397 151 316 minecraft:red_terracotta
fill 395 151 276 397 151 276 minecraft:red_terracotta
setblock 395 151 278 minecraft:light[level=15]
setblock 395 151 286 minecraft:light[level=15]
setblock 395 151 294 minecraft:light[level=15]
setblock 395 151 302 minecraft:light[level=15]
setblock 395 151 310 minecraft:light[level=15]
fill 395 151 315 398 151 315 minecraft:red_terracotta
fill 397 151 314 399 151 314 minecraft:red_terracotta
setblock 398 151 276 minecraft:stripped_oak_log
setblock 398 151 316 minecraft:stripped_oak_log
fill 399 151 276 399 154 276 minecraft:red_terracotta
fill 399 151 313 400 151 313 minecraft:red_terracotta
setblock 399 151 315 minecraft:stripped_oak_log
fill 399 151 316 402 151 316 minecraft:red_terracotta
setblock 400 151 314 minecraft:stripped_oak_log
fill 400 151 315 400 154 315 minecraft:red_terracotta
setblock 401 151 313 minecraft:stripped_oak_log
fill 401 151 314 401 154 314 minecraft:red_terracotta
fill 402 151 313 402 154 313 minecraft:red_terracotta
setblock 403 151 276 minecraft:stripped_oak_log
setblock 403 151 278 minecraft:light[level=15]
setblock 403 151 286 minecraft:light[level=15]
setblock 403 151 294 minecraft:light[level=15]
setblock 403 151 302 minecraft:light[level=15]
setblock 403 151 310 minecraft:light[level=15]
setblock 403 151 316 minecraft:stripped_oak_log
setblock 404 151 276 minecraft:red_terracotta
setblock 404 151 315 minecraft:stripped_oak_log
fill 404 151 316 404 154 316 minecraft:red_terracotta
setblock 405 151 314 minecraft:stripped_oak_log
fill 405 151 315 405 154 315 minecraft:red_terracotta
setblock 411 151 278 minecraft:light[level=15]
setblock 411 151 286 minecraft:light[level=15]
setblock 411 151 294 minecraft:light[level=15]
setblock 411 151 302 minecraft:light[level=15]
setblock 411 151 310 minecraft:light[level=15]
fill 415 151 287 415 151 288 minecraft:red_terracotta
setblock 415 151 289 minecraft:stripped_oak_log
setblock 416 151 282 minecraft:red_terracotta
setblock 416 151 283 minecraft:stripped_oak_log
fill 416 151 284 416 154 284 minecraft:red_terracotta
setblock 416 151 287 minecraft:red_terracotta
setblock 416 151 288 minecraft:stripped_oak_log
fill 416 151 289 416 154 289 minecraft:red_terracotta
setblock 416 151 292 minecraft:red_terracotta
setblock 416 151 293 minecraft:stripped_oak_log
fill 416 151 294 416 153 295 minecraft:red_terracotta
setblock 416 151 303 minecraft:stripped_oak_log
fill 416 151 304 416 153 304 minecraft:red_terracotta
setblock 416 151 307 minecraft:red_terracotta
setblock 416 151 308 minecraft:stripped_oak_log
fill 416 151 309 416 154 309 minecraft:red_terracotta
fill 416 151 311 416 152 311 minecraft:red_terracotta
fill 417 151 279 417 151 281 minecraft:red_terracotta
setblock 417 151 282 minecraft:stripped_oak_log
fill 417 151 283 417 154 283 minecraft:red_terracotta
setblock 417 151 287 minecraft:stripped_oak_log
fill 417 151 288 417 154 288 minecraft:red_terracotta
setblock 417 151 292 minecraft:stripped_oak_log
fill 417 151 293 417 154 293 minecraft:red_terracotta
setblock 417 151 297 minecraft:stripped_oak_log
fill 417 151 298 417 154 298 minecraft:red_terracotta
setblock 417 151 302 minecraft:stripped_oak_log
fill 417 151 303 417 154 303 minecraft:red_terracotta
setblock 417 151 307 minecraft:stripped_oak_log
fill 417 151 308 417 154 308 minecraft:red_terracotta
setblock 417 151 312 minecraft:stripped_oak_log
fill 417 151 313 417 153 314 minecraft:red_terracotta
fill 376 152 275 376 155 317 minecraft:white_terracotta
fill 377 152 275 418 155 275 minecraft:white_terracotta
setblock 377 152 276 minecraft:stripped_oak_log
fill 377 152 277 380 152 277 minecraft:red_terracotta
setblock 377 152 281 minecraft:stripped_oak_log
fill 377 152 282 377 155 282 minecraft:red_terracotta
setblock 377 152 286 minecraft:stripped_oak_log
fill 377 152 287 377 155 287 minecraft:red_terracotta
setblock 377 152 291 minecraft:stripped_oak_log
fill 377 152 292 377 155 292 minecraft:red_terracotta
setblock 377 152 295 minecraft:red_terracotta
setblock 377 152 296 minecraft:stripped_oak_log
fill 377 152 297 377 155 297 minecraft:red_terracotta
fill 377 152 301 377 154 301 minecraft:stripped_oak_log
fill 377 152 302 377 153 302 minecraft:red_terracotta
fill 377 152 304 377 153 304 minecraft:red_terracotta
setblock 377 152 306 minecraft:stripped_oak_log
fill 377 152 307 377 154 308 minecraft:red_terracotta
setblock 377 152 310 minecraft:red_terracotta
setblock 377 152 311 minecraft:stripped_oak_log
fill 377 152 312 377 155 312 minecraft:red_terracotta
fill 377 152 314 378 152 314 minecraft:red_terracotta
setblock 377 152 316 minecraft:stripped_oak_log
fill 377 152 317 418 155 317 minecraft:white_terracotta
fill 378 152 276 381 152 276 minecraft:red_terracotta
setblock 378 152 279 minecraft:red_terracotta
setblock 378 152 280 minecraft:stripped_oak_log
fill 378 152 281 378 155 281 minecraft:red_terracotta
setblock 378 152 285 minecraft:stripped_oak_log
fill 378 152 286 378 155 286 minecraft:red_terracotta
setblock 378 152 290 minecraft:stripped_oak_log
fill 378 152 291 378 155 291 minecraft:red_terracotta
setblock 378 152 295 minecraft:stripped_oak_log
fill 378 152 297 378 154 297 minecraft:stripped_oak_log
fill 378 152 303 378 154 305 minecraft:stripped_oak_log
fill 378 152 306 378 153 307 minecraft:red_terracotta
setblock 378 152 309 minecraft:red_terracotta
setblock 378 152 310 minecraft:stripped_oak_log
fill 378 152 311 378 155 311 minecraft:red_terracotta
fill 378 152 313 378 153 313 minecraft:red_terracotta
fill 378 152 316 378 155 316 minecraft:red_terracotta
setblock 379 152 279 minecraft:stripped_oak_log
fill 379 152 280 379 153 280 minecraft:red_terracotta
setblock 379 152 284 minecraft:stripped_oak_log
fill 379 152 285 379 155 285 minecraft:red_terracotta
setblock 379 152 289 minecraft:stripped_oak_log
fill 379 152 290 379 155 290 minecraft:red_terracotta
setblock 379 152 293 minecraft:red_terracotta
fill 379 152 302 379 154 302 minecraft:stripped_oak_log
fill 379 152 304 379 154 304 minecraft:stripped_oak_log
fill 379 152 306 379 154 306 minecraft:stripped_oak_log
fill 379 152 308 379 153 308 minecraft:stripped_oak_log
fill 379 152 310 379 153 310 minecraft:red_terracotta
fill 379 152 312 379 153 312 minecraft:stripped_oak_log
fill 379 152 314 379 153 314 minecraft:stripped_oak_log
fill 379 152 315 382 152 315 minecraft:red_terracotta
setblock 380 152 278 minecraft:stripped_oak_log
setblock 380 152 283 minecraft:stripped_oak_log
fill 380 152 284 380 154 284 minecraft:red_terracotta
setblock 380 152 288 minecraft:stripped_oak_log
fill 380 152 289 380 155 289 minecraft:red_terracotta
fill 380 152 291 380 153 291 minecraft:red_terracotta
fill 380 152 303 380 154 303 minecraft:stripped_oak_log
fill 380 152 305 380 154 305 minecraft:stripped_oak_log
fill 380 152 307 380 153 307 minecraft:stripped_oak_log
fill 380 152 309 380 153 309 minecraft:stripped_oak_log
fill 380 152 311 380 153 311 minecraft:stripped_oak_log
fill 380 152 313 380 153 313 minecraft:stripped_oak_log
setblock 381 152 277 minecraft:stripped_oak_log
setblock 381 152 278 minecraft:red_terracotta
setblock 381 152 287 minecraft:stripped_oak_log
fill 381 152 302 381 153 302 minecraft:stripped_oak_log
fill 381 152 304 381 153 304 minecraft:stripped_oak_log
fill 381 152 306 381 153 306 minecraft:stripped_oak_log
fill 381 152 308 381 153 308 minecraft:stripped_oak_log
fill 381 152 310 381 153 310 minecraft:stripped_oak_log
fill 381 152 312 381 153 312 minecraft:stripped_oak_log
fill 381 152 314 381 153 314 minecraft:stripped_oak_log
setblock 382 152 276 minecraft:stripped_oak_log
fill 382 152 277 382 155 277 minecraft:red_terracotta
fill 382 152 303 382 153 303 minecraft:stripped_oak_log
fill 382 152 305 382 153 305 minecraft:stripped_oak_log
fill 382 152 307 382 153 307 minecraft:stripped_oak_log
fill 382 152 309 382 153 309 minecraft:stripped_oak_log
fill 382 152 311 382 153 311 minecraft:stripped_oak_log
fill 382 152 313 382 153 313 minecraft:stripped_oak_log
setblock 382 152 316 minecraft:stripped_oak_log
fill 383 152 276 386 152 276 minecraft:red_terracotta
fill 383 152 302 383 153 302 minecraft:stripped_oak_log
fill 383 152 304 383 153 304 minecraft:stripped_oak_log
fill 383 152 306 383 153 306 minecraft:stripped_oak_log
fill 383 152 308 383 153 308 minecraft:stripped_oak_log
fill 383 152 310 383 153 310 minecraft:stripped_oak_log
fill 383 152 312 383 153 312 minecraft:stripped_oak_log
fill 383 152 314 383 152 315 minecraft:stripped_oak_log
fill 383 152 316 383 155 316 minecraft:red_terracotta
fill 384 152 315 384 155 315 minecraft:red_terracotta
setblock 386 152 277 minecraft:stripped_oak_log
setblock 387 152 276 minecraft:stripped_oak_log
setblock 387 152 316 minecraft:stripped_oak_log
fill 388 152 276 388 153 276 minecraft:red_terracotta
fill 388 152 316 391 152 316 minecraft:red_terracotta
setblock 392 152 316 minecraft:stripped_oak_log
setblock 393 152 315 minecraft:stripped_oak_log
fill 393 152 316 396 152 316 minecraft:red_terracotta
fill 394 152 315 397 152 315 minecraft:red_terracotta
fill 395 152 276 396 152 276 minecraft:red_terracotta
fill 396 152 314 398 152 314 minecraft:red_terracotta
setblock 397 152 276 minecraft:stripped_oak_log
setblock 397 152 316 minecraft:stripped_oak_log
fill 398 152 276 398 155 276 minecraft:red_terracotta
fill 398 152 313 399 152 313 minecraft:red_terracotta
setblock 398 152 315 minecraft:stripped_oak_log
fill 398 152 316 401 152 316 minecraft:red_terracotta
setblock 399 152 314 minecraft:stripped_oak_log
fill 399 152 315 399 155 315 minecraft:red_terracotta
setblock 400 152 313 minecraft:stripped_oak_log
fill 400 152 314 400 155 314 minecraft:red_terracotta
fill 401 152 313 401 155 313 minecraft:red_terracotta
setblock 402 152 276 minecraft:stripped_oak_log
setblock 402 152 316 minecraft:stripped_oak_log
setblock 403 152 276 minecraft:red_terracotta
setblock 403 152 315 minecraft:stripped_oak_log
fill 403 152 316 403 155 316 minecraft:red_terracotta
setblock 404 152 314 minecraft:stripped_oak_log
fill 404 152 315 404 155 315 minecraft:red_terracotta
setblock 407 152 316 minecraft:stripped_oak_log
fill 415 152 286 415 152 287 minecraft:red_terracotta
setblock 415 152 288 minecraft:stripped_oak_log
fill 415 152 289 415 153 291 minecraft:red_terracotta
setblock 416 152 282 minecraft:stripped_oak_log
fill 416 152 283 416 155 283 minecraft:red_terracotta
setblock 416 152 287 minecraft:stripped_oak_log
fill 416 152 288 416 155 288 minecraft:red_terracotta
setblock 416 152 292 minecraft:stripped_oak_log
fill 416 152 293 416 155 293 minecraft:red_terracotta
setblock 416 152 296 minecraft:red_terracotta
setblock 416 152 302 minecraft:stripped_oak_log
setblock 416 152 303 minecraft:red_terracotta
setblock 416 152 307 minecraft:stripped_oak_log
fill 416 152 308 416 155 308 minecraft:red_terracotta
fill 417 152 279 417 152 280 minecraft:red_terracotta
setblock 417 152 281 minecraft:stripped_oak_log
fill 417 152 282 417 155 282 minecraft:red_terracotta
setblock 417 152 286 minecraft:stripped_oak_log
fill 417 152 287 417 155 287 minecraft:red_terracotta
setblock 417 152 291 minecraft:stripped_oak_log
fill 417 152 292 417 155 292 minecraft:red_terracotta
setblock 417 152 296 minecraft:stripped_oak_log
fill 417 152 297 417 155 297 minecraft:red_terracotta
setblock 417 152 301 minecraft:stripped_oak_log
fill 417 152 302 417 155 302 minecraft:red_terracotta
setblock 417 152 306 minecraft:stripped_oak_log
fill 417 152 307 417 155 307 minecraft:red_terracotta
setblock 417 152 311 minecraft:stripped_oak_log
fill 417 152 312 417 155 312 minecraft:red_terracotta
setblock 417 152 315 minecraft:red_terracotta
fill 418 152 276 418 155 316 minecraft:white_terracotta
fill 377 153 276 379 153 277 minecraft:red_terracotta
setblock 377 153 280 minecraft:stripped_oak_log
fill 377 153 281 377 156 281 minecraft:red_terracotta
setblock 377 153 285 minecraft:stripped_oak_log
fill 377 153 286 377 156 286 minecraft:red_terracotta
setblock 377 153 290 minecraft:stripped_oak_log
fill 377 153 291 377 156 291 minecraft:red_terracotta
setblock 377 153 294 minecraft:red_terracotta
setblock 377 153 295 minecraft:stripped_oak_log
fill 377 153 296 377 156 296 minecraft:red_terracotta
fill 377 153 300 377 154 300 minecraft:stripped_oak_log
setblock 377 153 305 minecraft:stripped_oak_log
fill 377 153 306 377 155 306 minecraft:red_terracotta
setblock 377 153 310 minecraft:stripped_oak_log
fill 377 153 311 377 156 311 minecraft:red_terracotta
setblock 377 153 314 minecraft:red_terracotta
setblock 377 153 315 minecraft:stripped_oak_log
fill 377 153 316 377 156 316 minecraft:red_terracotta
setblock 378 153 279 minecraft:stripped_oak_log
fill 378 153 280 378 156 280 minecraft:red_terracotta
setblock 378 153 284 minecraft:stripped_oak_log
fill 378 153 285 378 156 285 minecraft:red_terracotta
setblock 378 153 289 minecraft:stripped_oak_log
fill 378 153 290 378 156 290 minecraft:red_terracotta
setblock 378 153 294 minecraft:stripped_oak_log
fill 378 153 295 378 156 295 minecraft:red_terracotta
setblock 378 153 309 minecraft:stripped_oak_log
fill 378 153 310 378 156 310 minecraft:red_terracotta
setblock 378 153 314 minecraft:stripped_oak_log
fill 378 153 315 381 153 315 minecraft:red_terracotta
setblock 379 153 283 minecraft:stripped_oak_log
fill 379 153 284 379 156 284 minecraft:red_terracotta
setblock 379 153 288 minecraft:stripped_oak_log
fill 379 153 289 379 156 289 minecraft:red_terracotta
setblock 379 153 293 minecraft:stripped_oak_log
setblock 379 153 311 minecraft:red_terracotta
setblock 380 153 276 minecraft:red_terracotta
setblock 380 153 277 minecraft:stripped_oak_log
setblock 380 153 283 minecraft:red_terracotta
setblock 380 153 287 minecraft:stripped_oak_log
fill 380 153 288 380 155 288 minecraft:red_terracotta
setblock 381 153 276 minecraft:stripped_oak_log
fill 381 153 277 381 156 277 minecraft:red_terracotta
setblock 381 153 316 minecraft:stripped_oak_log
fill 382 153 276 385 153 276 minecraft:red_terracotta
setblock 382 153 315 minecraft:stripped_oak_log
fill 382 153 316 382 156 316 minecraft:red_terracotta
setblock 383 153 314 minecraft:stripped_oak_log
fill 383 153 315 383 156 315 minecraft:red_terracotta
setblock 386 153 276 minecraft:stripped_oak_log
setblock 386 153 316 minecraft:stripped_oak_log
fill 387 153 276 387 154 276 minecraft:red_terracotta
fill 387 153 316 390 153 316 minecraft:red_terracotta
setblock 391 153 316 minecraft:stripped_oak_log
fill 392 153 316 395 153 316 minecraft:red_terracotta
fill 393 153 315 396 153 315 minecraft:red_terracotta
setblock 395 153 276 minecraft:red_terracotta
fill 395 153 314 397 153 314 minecraft:red_terracotta
setblock 396 153 276 minecraft:stripped_oak_log
setblock 396 153 316 minecraft:stripped_oak_log
fill 397 153 276 397 156 276 minecraft:red_terracotta
fill 397 153 313 398 153 313 minecraft:red_terracotta
setblock 397 153 315 minecraft:stripped_oak_log
fill 397 153 316 400 153 316 minecraft:red_terracotta
setblock 398 153 314 minecraft:stripped_oak_log
fill 398 153 315 398 156 315 minecraft:red_terracotta
setblock 399 153 313 minecraft:stripped_oak_log
fill 399 153 314 399 156 314 minecraft:red_terracotta
fill 400 153 313 400 156 313 minecraft:red_terracotta
setblock 401 153 276 minecraft:stripped_oak_log
setblock 401 153 316 minecraft:stripped_oak_log
setblock 402 153 276 minecraft:red_terracotta
setblock 402 153 315 minecraft:stripped_oak_log
fill 402 153 316 402 156 316 minecraft:red_terracotta
setblock 403 153 314 minecraft:stripped_oak_log
fill 403 153 315 403 156 315 minecraft:red_terracotta
setblock 404 153 314 minecraft:red_terracotta
setblock 406 153 316 minecraft:stripped_oak_log
setblock 415 153 286 minecraft:red_terracotta
setblock 415 153 287 minecraft:stripped_oak_log
fill 415 153 288 415 156 288 minecraft:red_terracotta
setblock 415 153 292 minecraft:stripped_oak_log
setblock 416 153 286 minecraft:stripped_oak_log
fill 416 153 287 416 156 287 minecraft:red_terracotta
setblock 416 153 291 minecraft:stripped_oak_log
fill 416 153 292 416 156 292 minecraft:red_terracotta
setblock 416 153 296 minecraft:stripped_oak_log
fill 416 153 297 416 156 297 minecraft:red_terracotta
setblock 416 153 306 minecraft:stripped_oak_log
fill 416 153 307 416 154 307 minecraft:red_terracotta
setblock 416 153 311 minecraft:stripped_oak_log
fill 416 153 312 416 155 312 minecraft:red_terracotta
setblock 417 153 279 minecraft:red_terracotta
setblock 417 153 280 minecraft:stripped_oak_log
fill 417 153 281 417 156 281 minecraft:red_terracotta
setblock 417 153 285 minecraft:stripped_oak_log
fill 417 153 286 417 156 286 minecraft:red_terracotta
setblock 417 153 290 minecraft:stripped_oak_log
fill 417 153 291 417 156 291 minecraft:red_terracotta
setblock 417 153 295 minecraft:stripped_oak_log
fill 417 153 296 417 156 296 minecraft:red_terracotta
setblock 417 153 300 minecraft:stripped_oak_log
fill 417 153 301 417 156 301 minecraft:red_terracotta
setblock 417 153 305 minecraft:stripped_oak_log
fill 417 153 306 417 156 306 minecraft:red_terracotta
setblock 417 153 310 minecraft:stripped_oak_log
fill 417 153 311 417 156 311 minecraft:red_terracotta
setblock 417 153 315 minecraft:stripped_oak_log
fill 377 154 276 378 154 277 minecraft:red_terracotta
setblock 377 154 279 minecraft:stripped_oak_log
fill 377 154 280 377 157 280 minecraft:red_terracotta
setblock 377 154 284 minecraft:stripped_oak_log
fill 377 154 285 377 157 285 minecraft:red_terracotta
setblock 377 154 289 minecraft:stripped_oak_log
fill 377 154 290 377 157 290 minecraft:red_terracotta
setblock 377 154 294 minecraft:stripped_oak_log
fill 377 154 295 377 157 295 minecraft:red_terracotta
setblock 377 154 299 minecraft:stripped_oak_log
fill 377 154 302 377 154 304 minecraft:stripped_oak_log
fill 377 154 305 377 155 305 minecraft:red_terracotta
setblock 377 154 309 minecraft:stripped_oak_log
fill 377 154 310 377 157 310 minecraft:red_terracotta
setblock 377 154 314 minecraft:stripped_oak_log
fill 377 154 315 380 154 315 minecraft:red_terracotta
setblock 378 154 278 minecraft:stripped_oak_log
fill 378 154 279 378 157 279 minecraft:red_terracotta
setblock 378 154 283 minecraft:stripped_oak_log
fill 378 154 284 378 157 284 minecraft:red_terracotta
setblock 378 154 288 minecraft:stripped_oak_log
fill 378 154 289 378 157 289 minecraft:red_terracotta
setblock 378 154 293 minecraft:stripped_oak_log
fill 378 154 294 378 157 294 minecraft:red_terracotta
setblock 378 154 306 minecraft:stripped_oak_log
setblock 378 154 307 minecraft:red_terracotta
setblock 378 154 308 minecraft:stripped_oak_log
fill 378 154 309 378 156 309 minecraft:red_terracotta
setblock 378 154 313 minecraft:stripped_oak_log
fill 378 154 314 378 157 314 minecraft:red_terracotta
setblock 379 154 276 minecraft:red_terracotta
setblock 379 154 277 minecraft:stripped_oak_log
setblock 379 154 282 minecraft:stripped_oak_log
fill 379 154 283 379 155 283 minecraft:red_terracotta
setblock 379 154 287 minecraft:stripped_oak_log
fill 379 154 288 379 157 288 minecraft:red_terracotta
setblock 379 154 292 minecraft:stripped_oak_log
fill 379 154 293 379 155 293 minecraft:red_terracotta
setblock 380 154 276 minecraft:stripped_oak_log
fill 380 154 277 380 157 277 minecraft:red_terracotta
setblock 380 154 286 minecraft:stripped_oak_log
fill 380 154 287 380 155 287 minecraft:red_terracotta
setblock 380 154 316 minecraft:stripped_oak_log
fill 381 154 276 384 154 276 minecraft:red_terracotta
setblock 381 154 315 minecraft:stripped_oak_log
fill 381 154 316 381 157 316 minecraft:red_terracotta
fill 382 154 315 382 157 315 minecraft:red_terracotta
setblock 385 154 276 minecraft:stripped_oak_log
setblock 385 154 316 minecraft:stripped_oak_log
fill 386 154 276 386 155 276 minecraft:red_terracotta
setblock 386 154 315 minecraft:stripped_oak_log
fill 386 154 316 389 154 316 minecraft:red_terracotta
setblock 390 154 316 minecraft:stripped_oak_log
fill 391 154 316 394 154 316 minecraft:red_terracotta
fill 392 154 315 395 154 315 minecraft:red_terracotta
fill 394 154 314 396 154 314 minecraft:red_terracotta
setblock 395 154 316 minecraft:stripped_oak_log
fill 396 154 276 396 157 276 minecraft:red_terracotta
setblock 396 154 315 minecraft:stripped_oak_log
fill 396 154 316 399 154 316 minecraft:red_terracotta
setblock 397 154 313 minecraft:red_terracotta
setblock 397 154 314 minecraft:stripped_oak_log
fill 397 154 315 397 157 315 minecraft:red_terracotta
setblock 398 154 313 minecraft:stripped_oak_log
fill 398 154 314 398 157 314 minecraft:red_terracotta
fill 399 154 313 399 157 313 minecraft:red_terracotta
setblock 400 154 276 minecraft:stripped_oak_log
setblock 400 154 316 minecraft:stripped_oak_log
setblock 401 154 276 minecraft:red_terracotta
setblock 401 154 315 minecraft:stripped_oak_log
fill 401 154 316 401 157 316 minecraft:red_terracotta
setblock 402 154 314 minecraft:stripped_oak_log
fill 402 154 315 402 157 315 minecraft:red_terracotta
fill 403 154 314 403 155 314 minecraft:red_terracotta
setblock 405 154 316 minecraft:stripped_oak_log
setblock 406 154 316 minecraft:red_terracotta
fill 415 154 287 415 156 287 minecraft:red_terracotta
fill 415 154 289 415 154 290 minecraft:red_terracotta
setblock 415 154 291 minecraft:stripped_oak_log
fill 415 154 292 415 156 293 minecraft:red_terracotta
setblock 416 154 285 minecraft:stripped_oak_log
fill 416 154 286 416 157 286 minecraft:red_terracotta
setblock 416 154 290 minecraft:stripped_oak_log
fill 416 154 291 416 157 291 minecraft:red_terracotta
setblock 416 154 294 minecraft:red_terracotta
setblock 416 154 295 minecraft:stripped_oak_log
fill 416 154 296 416 157 296 minecraft:red_terracotta
setblock 416 154 306 minecraft:red_terracotta
setblock 416 154 310 minecraft:stripped_oak_log
fill 416 154 311 416 156 311 minecraft:red_terracotta
setblock 417 154 279 minecraft:stripped_oak_log
fill 417 154 280 417 157 280 minecraft:red_terracotta
setblock 417 154 284 minecraft:stripped_oak_log
fill 417 154 285 417 157 285 minecraft:red_terracotta
setblock 417 154 289 minecraft:stripped_oak_log
fill 417 154 290 417 157 290 minecraft:red_terracotta
setblock 417 154 294 minecraft:stripped_oak_log
fill 417 154 295 417 157 295 minecraft:red_terracotta
setblock 417 154 299 minecraft:stripped_oak_log
fill 417 154 300 417 157 300 minecraft:red_terracotta
setblock 417 154 304 minecraft:stripped_oak_log
fill 417 154 305 417 157 305 minecraft:red_terracotta
setblock 417 154 309 minecraft:stripped_oak_log
fill 417 154 310 417 157 310 minecraft:red_terracotta
setblock 417 154 313 minecraft:red_terracotta
setblock 417 154 314 minecraft:stripped_oak_log
fill 417 154 315 417 156 316 minecraft:red_terracotta
fill 377 155 276 377 155 277 minecraft:red_terracotta
setblock 377 155 278 minecraft:stripped_oak_log
fill 377 155 279 377 158 279 minecraft:red_terracotta
setblock 377 155 283 minecraft:stripped_oak_log
fill 377 155 284 377 158 284 minecraft:red_terracotta
setblock 377 155 288 minecraft:stripped_oak_log
fill 377 155 289 377 158 289 minecraft:red_terracotta
setblock 377 155 293 minecraft:stripped_oak_log
fill 377 155 294 377 158 294 minecraft:red_terracotta
setblock 377 155 307 minecraft:red_terracotta
setblock 377 155 308 minecraft:stripped_oak_log
fill 377 155 309 377 158 309 minecraft:red_terracotta
setblock 377 155 313 minecraft:stripped_oak_log
fill 377 155 314 377 157 315 minecraft:red_terracotta
setblock 378 155 276 minecraft:red_terracotta
setblock 378 155 277 minecraft:stripped_oak_log
fill 378 155 278 378 158 278 minecraft:red_terracotta
setblock 378 155 282 minecraft:stripped_oak_log
fill 378 155 283 378 158 283 minecraft:red_terracotta
setblock 378 155 287 minecraft:stripped_oak_log
fill 378 155 288 378 158 288 minecraft:red_terracotta
setblock 378 155 292 minecraft:stripped_oak_log
fill 378 155 293 378 158 293 minecraft:red_terracotta
setblock 378 155 308 minecraft:red_terracotta
setblock 378 155 312 minecraft:stripped_oak_log
fill 378 155 313 378 158 313 minecraft:red_terracotta
fill 378 155 315 379 155 315 minecraft:red_terracotta
setblock 379 155 276 minecraft:stripped_oak_log
fill 379 155 277 379 158 277 minecraft:red_terracotta
setblock 379 155 278 minecraft:light[level=12]
setblock 379 155 282 minecraft:red_terracotta
setblock 379 155 286 minecraft:stripped_oak_log
fill 379 155 287 379 157 287 minecraft:red_terracotta
setblock 379 155 291 minecraft:stripped_oak_log
fill 379 155 292 379 157 292 minecraft:red_terracotta
setblock 379 155 299 minecraft:light[level=12]
setblock 379 155 306 minecraft:light[level=12]
setblock 379 155 313 minecraft:light[level=12]
setblock 379 155 316 minecraft:stripped_oak_log
fill 380 155 276 383 155 276 minecraft:red_terracotta
setblock 380 155 315 minecraft:stripped_oak_log
fill 380 155 316 380 158 316 minecraft:red_terracotta
fill 381 155 295 381 165 295 minecraft:brown_terracotta
fill 381 155 315 381 158 315 minecraft:red_terracotta
setblock 384 155 276 minecraft:stripped_oak_log
setblock 384 155 316 minecraft:stripped_oak_log
fill 385 155 276 385 158 276 minecraft:red_terracotta
setblock 385 155 315 minecraft:stripped_oak_log
fill 385 155 316 388 155 316 minecraft:red_terracotta
setblock 386 155 278 minecraft:light[level=12]
setblock 386 155 285 minecraft:light[level=12]
setblock 386 155 292 minecraft:light[level=12]
setblock 386 155 299 minecraft:light[level=12]
setblock 386 155 306 minecraft:light[level=12]
setblock 386 155 313 minecraft:light[level=12]
setblock 389 155 316 minecraft:stripped_oak_log
fill 390 155 316 393 155 316 minecraft:red_terracotta
fill 391 155 315 394 155 315 minecraft:red_terracotta
setblock 393 155 278 minecraft:light[level=12]
setblock 393 155 285 minecraft:light[level=12]
setblock 393 155 292 minecraft:light[level=12]
setblock 393 155 299 minecraft:light[level=12]
setblock 393 155 306 minecraft:light[level=12]
setblock 393 155 313 minecraft:light[level=12]
fill 394 155 314 395 155 314 minecraft:red_terracotta
setblock 394 155 316 minecraft:stripped_oak_log
setblock 395 155 315 minecraft:stripped_oak_log
fill 395 155 316 398 155 316 minecraft:red_terracotta
setblock 396 155 313 minecraft:red_terracotta
setblock 396 155 314 minecraft:stripped_oak_log
fill 396 155 315 396 158 315 minecraft:red_terracotta
fill 397 155 307 401 208 310 minecraft:stripped_oak_log
setblock 397 155 313 minecraft:stripped_oak_log
fill 397 155 314 397 158 314 minecraft:red_terracotta
fill 398 155 306 400 208 306 minecraft:stripped_oak_log
fill 398 155 311 400 208 311 minecraft:stripped_oak_log
fill 398 155 313 398 158 313 minecraft:red_terracotta
setblock 399 155 276 minecraft:stripped_oak_log
setblock 399 155 316 minecraft:stripped_oak_log
setblock 400 155 276 minecraft:red_terracotta
setblock 400 155 278 minecraft:light[level=12]
setblock 400 155 285 minecraft:light[level=12]
setblock 400 155 292 minecraft:light[level=12]
setblock 400 155 299 minecraft:light[level=12]
setblock 400 155 315 minecraft:stripped_oak_log
fill 400 155 316 400 158 316 minecraft:red_terracotta
setblock 401 155 314 minecraft:stripped_oak_log
fill 401 155 315 401 158 315 minecraft:red_terracotta
fill 402 155 308 402 208 309 minecraft:stripped_oak_log
fill 402 155 314 402 156 314 minecraft:red_terracotta
setblock 404 155 316 minecraft:stripped_oak_log
fill 405 155 316 405 156 316 minecraft:red_terracotta
setblock 407 155 278 minecraft:light[level=12]
setblock 407 155 285 minecraft:light[level=12]
setblock 407 155 292 minecraft:light[level=12]
setblock 407 155 299 minecraft:light[level=12]
setblock 407 155 306 minecraft:light[level=12]
setblock 407 155 313 minecraft:light[level=12]
setblock 414 155 278 minecraft:light[level=12]
setblock 414 155 285 minecraft:light[level=12]
setblock 414 155 292 minecraft:light[level=12]
setblock 414 155 299 minecraft:light[level=12]
setblock 414 155 306 minecraft:light[level=12]
setblock 414 155 313 minecraft:light[level=12]
setblock 415 155 289 minecraft:red_terracotta
setblock 415 155 290 minecraft:stripped_oak_log
fill 415 155 291 415 158 291 minecraft:red_terracotta
setblock 416 155 284 minecraft:stripped_oak_log
fill 416 155 285 416 158 285 minecraft:red_terracotta
setblock 416 155 289 minecraft:stripped_oak_log
fill 416 155 290 416 158 290 minecraft:red_terracotta
setblock 416 155 294 minecraft:stripped_oak_log
fill 416 155 295 416 158 295 minecraft:red_terracotta
setblock 416 155 309 minecraft:stripped_oak_log
setblock 416 155 310 minecraft:red_terracotta
fill 417 155 279 417 158 279 minecraft:red_terracotta
setblock 417 155 283 minecraft:stripped_oak_log
fill 417 155 284 417 158 284 minecraft:red_terracotta
setblock 417 155 288 minecraft:stripped_oak_log
fill 417 155 289 417 158 289 minecraft:red_terracotta
setblock 417 155 293 minecraft:stripped_oak_log
fill 417 155 294 417 158 294 minecraft:red_terracotta
setblock 417 155 298 minecraft:stripped_oak_log
fill 417 155 299 417 158 299 minecraft:red_terracotta
setblock 417 155 303 minecraft:stripped_oak_log
fill 417 155 304 417 156 304 minecraft:red_terracotta
setblock 417 155 308 minecraft:stripped_oak_log
fill 417 155 309 417 158 309 minecraft:red_terracotta
setblock 417 155 313 minecraft:stripped_oak_log
fill 417 155 314 417 158 314 minecraft:red_terracotta
fill 376 156 275 376 159 317 minecraft:terracotta
fill 377 156 275 418 159 275 minecraft:terracotta
setblock 377 156 276 minecraft:red_terracotta
setblock 377 156 277 minecraft:stripped_oak_log
fill 377 156 278 377 159 278 minecraft:red_terracotta
setblock 377 156 282 minecraft:stripped_oak_log
fill 377 156 283 377 159 283 minecraft:red_terracotta
setblock 377 156 287 minecraft:stripped_oak_log
fill 377 156 288 377 159 288 minecraft:red_terracotta
setblock 377 156 292 minecraft:stripped_oak_log
fill 377 156 293 377 159 293 minecraft:red_terracotta
setblock 377 156 297 minecraft:stripped_oak_log
setblock 377 156 307 minecraft:stripped_oak_log
fill 377 156 308 377 159 308 minecraft:red_terracotta
setblock 377 156 312 minecraft:stripped_oak_log
fill 377 156 313 377 159 313 minecraft:red_terracotta
fill 377 156 317 418 159 317 minecraft:terracotta
setblock 378 156 276 minecraft:stripped_oak_log
fill 378 156 277 378 159 277 minecraft:red_terracotta
setblock 378 156 281 minecraft:stripped_oak_log
fill 378 156 282 378 159 282 minecraft:red_terracotta
setblock 378 156 286 minecraft:stripped_oak_log
fill 378 156 287 378 159 287 minecraft:red_terracotta
setblock 378 156 291 minecraft:stripped_oak_log
fill 378 156 292 378 159 292 minecraft:red_terracotta
setblock 378 156 311 minecraft:stripped_oak_log
fill 378 156 312 378 159 312 minecraft:red_terracotta
setblock 378 156 315 minecraft:red_terracotta
setblock 378 156 316 minecraft:stripped_oak_log
fill 379 156 276 382 156 276 minecraft:red_terracotta
setblock 379 156 285 minecraft:stripped_oak_log
fill 379 156 286 379 157 286 minecraft:red_terracotta
setblock 379 156 290 minecraft:stripped_oak_log
fill 379 156 291 379 158 291 minecraft:red_terracotta
setblock 379 156 315 minecraft:stripped_oak_log
fill 379 156 316 379 159 316 minecraft:red_terracotta
fill 380 156 315 380 159 315 minecraft:red_terracotta
setblock 382 156 277 minecraft:stripped_oak_log
setblock 383 156 276 minecraft:stripped_oak_log
setblock 383 156 316 minecraft:stripped_oak_log
fill 384 156 276 384 159 276 minecraft:red_terracotta
setblock 384 156 315 minecraft:stripped_oak_log
fill 384 156 316 387 156 316 minecraft:red_terracotta
fill 385 156 315 385 159 315 minecraft:red_terracotta
fill 387 156 283 391 208 286 minecraft:stripped_oak_log
fill 388 156 287 390 208 287 minecraft:stripped_oak_log
setblock 388 156 316 minecraft:stripped_oak_log
fill 389 156 282 389 208 282 minecraft:stripped_oak_log
fill 389 156 316 392 156 316 minecraft:red_terracotta
fill 391 156 315 393 156 315 minecraft:red_terracotta
setblock 393 156 316 minecraft:stripped_oak_log
setblock 394 156 314 minecraft:red_terracotta
setblock 394 156 315 minecraft:stripped_oak_log
fill 394 156 316 397 156 316 minecraft:red_terracotta
fill 395 156 276 395 158 276 minecraft:red_terracotta
fill 395 156 308 396 157 309 minecraft:brown_terracotta
setblock 395 156 314 minecraft:stripped_oak_log
fill 395 156 315 395 159 315 minecraft:red_terracotta
fill 396 156 306 396 157 307 minecraft:brown_terracotta
fill 396 156 310 396 157 311 minecraft:brown_terracotta
setblock 396 156 313 minecraft:stripped_oak_log
fill 396 156 314 396 159 314 minecraft:red_terracotta
fill 397 156 305 397 157 306 minecraft:brown_terracotta
fill 397 156 311 397 157 311 minecraft:brown_terracotta
fill 397 156 313 397 159 313 minecraft:red_terracotta
setblock 398 156 276 minecraft:stripped_oak_log
fill 398 156 305 401 157 305 minecraft:brown_terracotta
fill 398 156 312 401 157 312 minecraft:brown_terracotta
setblock 398 156 316 minecraft:stripped_oak_log
fill 399 156 276 399 159 276 minecraft:red_terracotta
setblock 399 156 315 minecraft:stripped_oak_log
fill 399 156 316 399 159 316 minecraft:red_terracotta
setblock 400 156 314 minecraft:stripped_oak_log
fill 400 156 315 400 159 315 minecraft:red_terracotta
fill 401 156 306 402 157 306 minecraft:brown_terracotta
fill 401 156 311 402 157 311 minecraft:brown_terracotta
fill 401 156 314 401 158 314 minecraft:red_terracotta
fill 402 156 307 403 157 307 minecraft:brown_terracotta
fill 402 156 310 403 157 310 minecraft:brown_terracotta
fill 403 156 308 403 157 309 minecraft:brown_terracotta
setblock 403 156 316 minecraft:stripped_oak_log
fill 404 156 316 404 159 316 minecraft:red_terracotta
setblock 415 156 289 minecraft:stripped_oak_log
fill 415 156 290 415 159 290 minecraft:red_terracotta
setblock 415 156 294 minecraft:stripped_oak_log
fill 416 156 284 416 159 284 minecraft:red_terracotta
setblock 416 156 288 minecraft:stripped_oak_log
fill 416 156 289 416 159 289 minecraft:red_terracotta
setblock 416 156 293 minecraft:stripped_oak_log
fill 416 156 294 416 159 294 minecraft:red_terracotta
fill 416 156 316 416 157 316 minecraft:red_terracotta
setblock 417 156 276 minecraft:red_terracotta
setblock 417 156 277 minecraft:stripped_oak_log
fill 417 156 278 417 159 278 minecraft:red_terracotta
setblock 417 156 282 minecraft:stripped_oak_log
fill 417 156 283 417 159 283 minecraft:red_terracotta
setblock 417 156 287 minecraft:stripped_oak_log
fill 417 156 288 417 159 288 minecraft:red_terracotta
setblock 417 156 292 minecraft:stripped_oak_log
fill 417 156 293 417 159 293 minecraft:red_terracotta
setblock 417 156 297 minecraft:stripped_oak_log
fill 417 156 298 417 159 298 minecraft:red_terracotta
setblock 417 156 302 minecraft:stripped_oak_log
setblock 417 156 303 minecraft:red_terracotta
setblock 417 156 307 minecraft:stripped_oak_log
fill 417 156 308 417 159 308 minecraft:red_terracotta
setblock 417 156 312 minecraft:stripped_oak_log
fill 417 156 313 417 159 313 minecraft:red_terracotta
fill 418 156 276 418 159 316 minecraft:terracotta
setblock 377 157 276 minecraft:stripped_oak_log
fill 377 157 277 377 160 277 minecraft:red_terracotta
setblock 377 157 281 minecraft:stripped_oak_log
fill 377 157 282 377 160 282 minecraft:red_terracotta
setblock 377 157 286 minecraft:stripped_oak_log
fill 377 157 287 377 160 287 minecraft:red_terracotta
setblock 377 157 291 minecraft:stripped_oak_log
fill 377 157 292 377 160 292 minecraft:red_terracotta
setblock 377 157 296 minecraft:stripped_oak_log
fill 377 157 297 377 160 297 minecraft:red_terracotta
setblock 377 157 307 minecraft:red_terracotta
setblock 377 157 311 minecraft:stripped_oak_log
fill 377 157 312 377 160 312 minecraft:red_terracotta
setblock 377 157 316 minecraft:stripped_oak_log
fill 378 157 276 381 157 276 minecraft:red_terracotta
setblock 378 157 280 minecraft:stripped_oak_log
fill 378 157 281 378 160 281 minecraft:red_terracotta
setblock 378 157 285 minecraft:stripped_oak_log
fill 378 157 286 378 160 286 minecraft:red_terracotta
setblock 378 157 290 minecraft:stripped_oak_log
fill 378 157 291 378 160 291 minecraft:red_terracotta
setblock 378 157 295 minecraft:stripped_oak_log
setblock 378 157 310 minecraft:stripped_oak_log
fill 378 157 311 378 160 311 minecraft:red_terracotta
setblock 378 157 315 minecraft:stripped_oak_log
fill 378 157 316 378 160 316 minecraft:red_terracotta
setblock 379 157 289 minecraft:stripped_oak_log
fill 379 157 290 379 158 290 minecraft:red_terracotta
fill 379 157 315 379 160 315 minecraft:red_terracotta
setblock 381 157 277 minecraft:stripped_oak_log
setblock 382 157 276 minecraft:stripped_oak_log
setblock 382 157 316 minecraft:stripped_oak_log
fill 383 157 276 383 160 276 minecraft:red_terracotta
setblock 383 157 315 minecraft:stripped_oak_log
fill 383 157 316 386 157 316 minecraft:red_terracotta
fill 384 157 315 384 160 315 minecraft:red_terracotta
fill 386 157 283 386 158 287 minecraft:brown_terracotta
fill 387 157 282 388 158 282 minecraft:brown_terracotta
fill 387 157 287 387 158 288 minecraft:brown_terracotta
setblock 387 157 316 minecraft:stripped_oak_log
fill 388 157 281 390 158 281 minecraft:brown_terracotta
fill 388 157 288 391 158 288 minecraft:brown_terracotta
fill 388 157 316 391 157 316 minecraft:red_terracotta
fill 390 157 282 391 158 282 minecraft:brown_terracotta
fill 390 157 315 392 157 315 minecraft:red_terracotta
fill 391 157 287 392 158 287 minecraft:brown_terracotta
fill 392 157 283 392 158 286 minecraft:brown_terracotta
setblock 392 157 316 minecraft:stripped_oak_log
setblock 393 157 314 minecraft:red_terracotta
setblock 393 157 315 minecraft:stripped_oak_log
fill 393 157 316 396 157 316 minecraft:red_terracotta
fill 394 157 307 394 157 310 minecraft:brown_terracotta
setblock 394 157 314 minecraft:stripped_oak_log
fill 394 157 315 394 160 315 minecraft:red_terracotta
fill 395 157 305 395 157 307 minecraft:brown_terracotta
fill 395 157 310 395 157 311 minecraft:brown_terracotta
fill 395 157 314 395 160 314 minecraft:red_terracotta
fill 396 157 304 396 157 305 minecraft:brown_terracotta
fill 396 157 312 397 157 312 minecraft:brown_terracotta
fill 396 157 313 396 160 313 minecraft:red_terracotta
setblock 397 157 276 minecraft:stripped_oak_log
fill 397 157 304 402 157 304 minecraft:brown_terracotta
setblock 397 157 316 minecraft:stripped_oak_log
fill 398 157 276 398 160 276 minecraft:red_terracotta
setblock 398 157 315 minecraft:stripped_oak_log
fill 398 157 316 398 160 316 minecraft:red_terracotta
setblock 399 157 303 minecraft:brown_terracotta
setblock 399 157 314 minecraft:stripped_oak_log
fill 399 157 315 399 160 315 minecraft:red_terracotta
fill 400 157 313 401 157 313 minecraft:brown_terracotta
fill 400 157 314 400 160 314 minecraft:red_terracotta
fill 402 157 305 403 157 305 minecraft:brown_terracotta
fill 402 157 312 403 157 312 minecraft:brown_terracotta
setblock 402 157 316 minecraft:stripped_oak_log
fill 403 157 306 404 157 306 minecraft:brown_terracotta
setblock 403 157 311 minecraft:brown_terracotta
setblock 403 157 315 minecraft:stripped_oak_log
fill 403 157 316 403 160 316 minecraft:red_terracotta
fill 404 157 307 404 157 310 minecraft:brown_terracotta
fill 405 157 311 405 160 311 minecraft:iron_bars
setblock 415 157 288 minecraft:stripped_oak_log
fill 415 157 289 415 160 289 minecraft:red_terracotta
setblock 415 157 292 minecraft:red_terracotta
setblock 415 157 293 minecraft:stripped_oak_log
fill 415 157 294 415 160 294 minecraft:red_terracotta
fill 415 157 316 415 158 316 minecraft:red_terracotta
setblock 416 157 276 minecraft:red_terracotta
setblock 416 157 287 minecraft:stripped_oak_log
fill 416 157 288 416 160 288 minecraft:red_terracotta
setblock 416 157 292 minecraft:stripped_oak_log
fill 416 157 293 416 160 293 minecraft:red_terracotta
setblock 416 157 297 minecraft:stripped_oak_log
setblock 417 157 276 minecraft:stripped_oak_log
fill 417 157 277 417 160 277 minecraft:red_terracotta
setblock 417 157 281 minecraft:stripped_oak_log
fill 417 157 282 417 160 282 minecraft:red_terracotta
setblock 417 157 286 minecraft:stripped_oak_log
fill 417 157 287 417 160 287 minecraft:red_terracotta
setblock 417 157 291 minecraft:stripped_oak_log
fill 417 157 292 417 160 292 minecraft:red_terracotta
setblock 417 157 296 minecraft:stripped_oak_log
fill 417 157 297 417 160 297 minecraft:red_terracotta
setblock 417 157 301 minecraft:stripped_oak_log
setblock 417 157 306 minecraft:stripped_oak_log
fill 417 157 307 417 158 307 minecraft:red_terracotta
setblock 417 157 311 minecraft:stripped_oak_log
fill 417 157 312 417 160 312 minecraft:red_terracotta
setblock 417 157 315 minecraft:red_terracotta
setblock 417 157 316 minecraft:stripped_oak_log
fill 377 158 276 380 158 276 minecraft:red_terracotta
setblock 377 158 280 minecraft:stripped_oak_log
fill 377 158 281 377 161 281 minecraft:red_terracotta
setblock 377 158 285 minecraft:stripped_oak_log
fill 377 158 286 377 161 286 minecraft:red_terracotta
setblock 377 158 290 minecraft:stripped_oak_log
fill 377 158 291 377 161 291 minecraft:red_terracotta
setblock 377 158 295 minecraft:stripped_oak_log
fill 377 158 296 377 161 296 minecraft:red_terracotta
fill 377 158 298 377 159 298 minecraft:red_terracotta
setblock 377 158 310 minecraft:stripped_oak_log
fill 377 158 311 377 161 311 minecraft:red_terracotta
setblock 377 158 314 minecraft:red_terracotta
setblock 377 158 315 minecraft:stripped_oak_log
fill 377 158 316 377 161 316 minecraft:red_terracotta
setblock 378 158 279 minecraft:stripped_oak_log
fill 378 158 280 378 161 280 minecraft:red_terracotta
setblock 378 158 284 minecraft:stripped_oak_log
fill 378 158 285 378 161 285 minecraft:red_terracotta
setblock 378 158 289 minecraft:stripped_oak_log
fill 378 158 290 378 161 290 minecraft:red_terracotta
setblock 378 158 294 minecraft:stripped_oak_log
fill 378 158 295 378 161 295 minecraft:red_terracotta
fill 378 158 308 382 176 309 minecraft:stripped_oak_log
setblock 378 158 310 minecraft:red_terracotta
setblock 378 158 314 minecraft:stripped_oak_log
fill 378 158 315 378 161 315 minecraft:red_terracotta
setblock 379 158 289 minecraft:red_terracotta
fill 379 158 307 381 179 307 minecraft:stripped_oak_log
fill 379 158 310 381 178 311 minecraft:stripped_oak_log
setblock 380 158 277 minecraft:stripped_oak_log
setblock 381 158 276 minecraft:stripped_oak_log
fill 381 158 277 381 161 277 minecraft:red_terracotta
setblock 381 158 316 minecraft:stripped_oak_log
fill 382 158 276 382 161 276 minecraft:red_terracotta
fill 382 158 310 382 208 310 minecraft:stripped_oak_log
setblock 382 158 315 minecraft:stripped_oak_log
fill 382 158 316 385 158 316 minecraft:red_terracotta
fill 383 158 315 383 161 315 minecraft:red_terracotta
fill 384 158 284 385 158 285 minecraft:brown_terracotta
fill 385 158 282 385 158 283 minecraft:brown_terracotta
fill 385 158 286 385 158 287 minecraft:brown_terracotta
fill 385 158 299 385 159 299 minecraft:shroomlight
fill 386 158 281 386 158 282 minecraft:brown_terracotta
setblock 386 158 288 minecraft:brown_terracotta
setblock 386 158 316 minecraft:stripped_oak_log
setblock 387 158 281 minecraft:brown_terracotta
fill 387 158 289 391 158 289 minecraft:brown_terracotta
fill 387 158 316 390 158 316 minecraft:red_terracotta
fill 388 158 280 390 158 280 minecraft:brown_terracotta
fill 389 158 315 391 158 315 minecraft:red_terracotta
fill 391 158 281 392 158 281 minecraft:brown_terracotta
setblock 391 158 316 minecraft:stripped_oak_log
fill 392 158 282 393 158 282 minecraft:brown_terracotta
setblock 392 158 288 minecraft:brown_terracotta
setblock 392 158 315 minecraft:stripped_oak_log
fill 392 158 316 395 158 316 minecraft:red_terracotta
fill 393 158 276 394 159 276 minecraft:red_terracotta
fill 393 158 283 393 158 287 minecraft:brown_terracotta
setblock 393 158 314 minecraft:stripped_oak_log
fill 393 158 315 393 161 315 minecraft:red_terracotta
fill 394 158 284 394 158 285 minecraft:brown_terracotta
fill 394 158 314 394 161 314 minecraft:red_terracotta
setblock 396 158 276 minecraft:stripped_oak_log
setblock 396 158 316 minecraft:stripped_oak_log
fill 397 158 276 397 161 276 minecraft:red_terracotta
setblock 397 158 315 minecraft:stripped_oak_log
fill 397 158 316 397 161 316 minecraft:red_terracotta
setblock 398 158 314 minecraft:stripped_oak_log
fill 398 158 315 398 161 315 minecraft:red_terracotta
fill 399 158 314 399 161 314 minecraft:red_terracotta
setblock 401 158 316 minecraft:stripped_oak_log
setblock 402 158 315 minecraft:stripped_oak_log
fill 402 158 316 402 161 316 minecraft:red_terracotta
fill 414 158 316 414 159 316 minecraft:red_terracotta
setblock 415 158 276 minecraft:red_terracotta
fill 415 158 288 415 161 288 minecraft:red_terracotta
setblock 415 158 292 minecraft:stripped_oak_log
fill 415 158 293 415 161 293 minecraft:red_terracotta
fill 415 158 295 415 159 295 minecraft:red_terracotta
setblock 416 158 276 minecraft:stripped_oak_log
setblock 416 158 286 minecraft:stripped_oak_log
fill 416 158 287 416 161 287 minecraft:red_terracotta
setblock 416 158 291 minecraft:stripped_oak_log
fill 416 158 292 416 161 292 minecraft:red_terracotta
setblock 416 158 296 minecraft:stripped_oak_log
fill 416 158 297 416 160 298 minecraft:red_terracotta
setblock 416 158 316 minecraft:stripped_oak_log
fill 417 158 276 417 161 276 minecraft:red_terracotta
setblock 417 158 280 minecraft:stripped_oak_log
fill 417 158 281 417 161 281 minecraft:red_terracotta
setblock 417 158 285 minecraft:stripped_oak_log
fill 417 158 286 417 161 286 minecraft:red_terracotta
setblock 417 158 290 minecraft:stripped_oak_log
fill 417 158 291 417 161 291 minecraft:red_terracotta
setblock 417 158 295 minecraft:stripped_oak_log
fill 417 158 296 417 161 296 minecraft:red_terracotta
setblock 417 158 300 minecraft:stripped_oak_log
fill 417 158 301 417 161 301 minecraft:red_terracotta
setblock 417 158 310 minecraft:stripped_oak_log
fill 417 158 311 417 161 311 minecraft:red_terracotta
setblock 417 158 315 minecraft:stripped_oak_log
fill 417 158 316 417 161 316 minecraft:red_terracotta
fill 377 159 276 379 159 276 minecraft:red_terracotta
setblock 377 159 279 minecraft:stripped_oak_log
fill 377 159 280 377 162 280 minecraft:red_terracotta
setblock 377 159 284 minecraft:stripped_oak_log
fill 377 159 285 377 162 285 minecraft:red_terracotta
setblock 377 159 289 minecraft:stripped_oak_log
fill 377 159 290 377 162 290 minecraft:red_terracotta
setblock 377 159 294 minecraft:stripped_oak_log
fill 377 159 295 377 162 295 minecraft:red_terracotta
fill 377 159 307 378 160 307 minecraft:brown_terracotta
setblock 377 159 309 minecraft:stripped_oak_log
fill 377 159 310 377 162 310 minecraft:red_terracotta
setblock 377 159 314 minecraft:stripped_oak_log
fill 377 159 315 377 162 315 minecraft:red_terracotta
setblock 378 159 278 minecraft:stripped_oak_log
fill 378 159 279 378 162 279 minecraft:red_terracotta
setblock 378 159 283 minecraft:stripped_oak_log
fill 378 159 284 378 161 284 minecraft:red_terracotta
setblock 378 159 288 minecraft:stripped_oak_log
fill 378 159 289 378 162 289 minecraft:red_terracotta
setblock 378 159 293 minecraft:stripped_oak_log
fill 378 159 294 378 162 294 minecraft:red_terracotta
fill 378 159 296 378 160 296 minecraft:red_terracotta
fill 378 159 306 382 160 306 minecraft:brown_terracotta
fill 378 159 310 378 177 310 minecraft:stripped_oak_log
setblock 378 159 313 minecraft:stripped_oak_log
fill 378 159 314 379 161 314 minecraft:red_terracotta
setblock 379 159 277 minecraft:stripped_oak_log
setblock 379 159 278 minecraft:light[level=15]
setblock 379 159 286 minecraft:light[level=15]
setblock 379 159 294 minecraft:light[level=15]
setblock 379 159 302 minecraft:light[level=15]
fill 379 159 312 381 160 312 minecraft:brown_terracotta
setblock 380 159 276 minecraft:stripped_oak_log
fill 380 159 277 380 162 277 minecraft:red_terracotta
setblock 380 159 316 minecraft:stripped_oak_log
fill 381 159 276 381 162 276 minecraft:red_terracotta
setblock 381 159 315 minecraft:stripped_oak_log
fill 381 159 316 384 159 316 minecraft:red_terracotta
fill 382 159 307 383 160 307 minecraft:brown_terracotta
fill 382 159 311 382 160 311 minecraft:brown_terracotta
fill 382 159 315 382 162 315 minecraft:red_terracotta
fill 383 159 308 383 160 310 minecraft:brown_terracotta
setblock 385 159 276 minecraft:stripped_oak_log
setblock 385 159 316 minecraft:stripped_oak_log
setblock 386 159 315 minecraft:stripped_oak_log
fill 386 159 316 389 159 316 minecraft:red_terracotta
setblock 387 159 278 minecraft:light[level=15]
setblock 387 159 294 minecraft:light[level=15]
setblock 387 159 302 minecraft:light[level=15]
setblock 387 159 310 minecraft:light[level=15]
fill 387 159 315 390 159 315 minecraft:red_terracotta
setblock 390 159 316 minecraft:stripped_oak_log
fill 391 159 276 392 161 276 minecraft:red_terracotta
setblock 391 159 315 minecraft:stripped_oak_log
fill 391 159 316 394 159 316 minecraft:red_terracotta
setblock 392 159 314 minecraft:stripped_oak_log
fill 392 159 315 392 162 315 minecraft:red_terracotta
fill 393 159 279 393 162 279 minecraft:iron_bars
fill 393 159 314 393 162 314 minecraft:red_terracotta
setblock 395 159 276 minecraft:stripped_oak_log
setblock 395 159 278 minecraft:light[level=15]
setblock 395 159 286 minecraft:light[level=15]
setblock 395 159 294 minecraft:light[level=15]
setblock 395 159 302 minecraft:light[level=15]
setblock 395 159 310 minecraft:light[level=15]
fill 395 159 313 395 161 313 minecraft:red_terracotta
setblock 395 159 316 minecraft:stripped_oak_log
fill 396 159 276 396 162 276 minecraft:red_terracotta
setblock 396 159 315 minecraft:stripped_oak_log
fill 396 159 316 396 162 316 minecraft:red_terracotta
setblock 397 159 314 minecraft:stripped_oak_log
fill 397 159 315 397 161 315 minecraft:red_terracotta
setblock 398 159 313 minecraft:stripped_oak_log
fill 398 159 314 398 161 314 minecraft:red_terracotta
setblock 400 159 316 minecraft:stripped_oak_log
setblock 401 159 315 minecraft:stripped_oak_log
fill 401 159 316 401 162 316 minecraft:red_terracotta
fill 402 159 315 402 162 315 minecraft:red_terracotta
setblock 403 159 278 minecraft:light[level=15]
setblock 403 159 286 minecraft:light[level=15]
setblock 403 159 294 minecraft:light[level=15]
setblock 403 159 302 minecraft:light[level=15]
setblock 403 159 310 minecraft:light[level=15]
setblock 411 159 278 minecraft:light[level=15]
setblock 411 159 286 minecraft:light[level=15]
setblock 411 159 294 minecraft:light[level=15]
setblock 411 159 302 minecraft:light[level=15]
setblock 411 159 310 minecraft:light[level=15]
fill 413 159 316 413 160 316 minecraft:red_terracotta
setblock 414 159 276 minecraft:red_terracotta
setblock 415 159 276 minecraft:stripped_oak_log
setblock 415 159 291 minecraft:stripped_oak_log
fill 415 159 292 415 162 292 minecraft:red_terracotta
setblock 415 159 296 minecraft:stripped_oak_log
setblock 415 159 316 minecraft:stripped_oak_log
fill 416 159 276 416 162 276 minecraft:red_terracotta
setblock 416 159 285 minecraft:stripped_oak_log
fill 416 159 286 416 162 286 minecraft:red_terracotta
setblock 416 159 290 minecraft:stripped_oak_log
fill 416 159 291 416 162 291 minecraft:red_terracotta
setblock 416 159 295 minecraft:stripped_oak_log
fill 416 159 296 416 162 296 minecraft:red_terracotta
setblock 416 159 299 minecraft:red_terracotta
fill 416 159 313 416 159 314 minecraft:red_terracotta
setblock 416 159 315 minecraft:stripped_oak_log
fill 416 159 316 416 162 316 minecraft:red_terracotta
setblock 417 159 279 minecraft:stripped_oak_log
fill 417 159 280 417 162 280 minecraft:red_terracotta
setblock 417 159 284 minecraft:stripped_oak_log
fill 417 159 285 417 162 285 minecraft:red_terracotta
setblock 417 159 289 minecraft:stripped_oak_log
fill 417 159 290 417 162 290 minecraft:red_terracotta
setblock 417 159 294 minecraft:stripped_oak_log
fill 417 159 295 417 162 295 minecraft:red_terracotta
setblock 417 159 299 minecraft:stripped_oak_log
fill 417 159 300 417 162 300 minecraft:red_terracotta
setblock 417 159 309 minecraft:stripped_oak_log
fill 417 159 310 417 162 310 minecraft:red_terracotta
setblock 417 159 314 minecraft:stripped_oak_log
fill 417 159 315 417 162 315 minecraft:red_terracotta
fill 376 160 275 376 163 317 minecraft:brown_terracotta
fill 377 160 275 418 163 275 minecraft:brown_terracotta
fill 377 160 276 378 160 276 minecraft:red_terracotta
setblock 377 160 278 minecraft:stripped_oak_log
fill 377 160 279 377 163 279 minecraft:red_terracotta
setblock 377 160 283 minecraft:stripped_oak_log
fill 377 160 284 377 163 284 minecraft:red_terracotta
setblock 377 160 288 minecraft:stripped_oak_log
fill 377 160 289 377 163 289 minecraft:red_terracotta
setblock 377 160 293 minecraft:stripped_oak_log
fill 377 160 294 377 163 294 minecraft:red_terracotta
setblock 377 160 298 minecraft:stripped_oak_log
fill 377 160 299 377 163 299 minecraft:red_terracotta
setblock 377 160 306 minecraft:brown_terracotta
setblock 377 160 308 minecraft:stripped_oak_log
fill 377 160 309 377 163 309 minecraft:red_terracotta
setblock 377 160 313 minecraft:stripped_oak_log
fill 377 160 314 377 163 314 minecraft:red_terracotta
fill 377 160 317 418 163 317 minecraft:brown_terracotta
setblock 378 160 277 minecraft:stripped_oak_log
fill 378 160 278 378 163 278 minecraft:red_terracotta
setblock 378 160 282 minecraft:stripped_oak_log
fill 378 160 283 378 163 283 minecraft:red_terracotta
setblock 378 160 287 minecraft:stripped_oak_log
fill 378 160 288 378 163 288 minecraft:red_terracotta
setblock 378 160 292 minecraft:stripped_oak_log
fill 378 160 293 378 163 293 minecraft:red_terracotta
fill 378 160 305 382 160 305 minecraft:brown_terracotta
setblock 378 160 312 minecraft:stripped_oak_log
fill 378 160 313 378 163 313 minecraft:red_terracotta
setblock 379 160 276 minecraft:stripped_oak_log
fill 379 160 277 379 163 277 minecraft:red_terracotta
fill 379 160 313 381 160 313 minecraft:brown_terracotta
setblock 379 160 316 minecraft:stripped_oak_log
fill 380 160 276 380 163 276 minecraft:red_terracotta
setblock 380 160 314 minecraft:red_terracotta
setblock 380 160 315 minecraft:stripped_oak_log
fill 380 160 316 383 160 316 minecraft:red_terracotta
fill 381 160 315 381 163 315 minecraft:red_terracotta
setblock 382 160 277 minecraft:red_terracotta
fill 382 160 312 383 160 312 minecraft:brown_terracotta
setblock 383 160 306 minecraft:brown_terracotta
setblock 383 160 311 minecraft:brown_terracotta
setblock 384 160 276 minecraft:stripped_oak_log
fill 384 160 307 384 160 310 minecraft:brown_terracotta
setblock 384 160 316 minecraft:stripped_oak_log
fill 385 160 276 388 160 276 minecraft:red_terracotta
fill 385 160 299 385 167 299 minecraft:brown_terracotta
setblock 385 160 315 minecraft:stripped_oak_log
fill 385 160 316 388 160 316 minecraft:red_terracotta
fill 386 160 315 389 160 315 minecraft:red_terracotta
setblock 389 160 276 minecraft:stripped_oak_log
setblock 389 160 316 minecraft:stripped_oak_log
fill 390 160 276 390 163 276 minecraft:red_terracotta
setblock 390 160 315 minecraft:stripped_oak_log
fill 390 160 316 393 160 316 minecraft:red_terracotta
setblock 391 160 314 minecraft:stripped_oak_log
fill 391 160 315 391 163 315 minecraft:red_terracotta
fill 392 160 314 392 163 314 minecraft:red_terracotta
setblock 393 160 276 minecraft:red_terracotta
setblock 394 160 276 minecraft:stripped_oak_log
fill 394 160 313 394 162 313 minecraft:red_terracotta
setblock 394 160 316 minecraft:stripped_oak_log
fill 395 160 276 395 163 276 minecraft:red_terracotta
setblock 395 160 315 minecraft:stripped_oak_log
fill 395 160 316 395 163 316 minecraft:red_terracotta
setblock 396 160 314 minecraft:stripped_oak_log
fill 396 160 315 396 163 315 minecraft:red_terracotta
setblock 397 160 313 minecraft:stripped_oak_log
fill 397 160 314 397 161 314 minecraft:red_terracotta
setblock 399 160 276 minecraft:stripped_oak_log
setblock 399 160 316 minecraft:stripped_oak_log
fill 400 160 276 400 163 276 minecraft:red_terracotta
setblock 400 160 315 minecraft:stripped_oak_log
fill 400 160 316 400 163 316 minecraft:red_terracotta
fill 401 160 315 401 163 315 minecraft:red_terracotta
setblock 404 160 316 minecraft:stripped_oak_log
fill 412 160 316 412 161 316 minecraft:red_terracotta
setblock 413 160 276 minecraft:red_terracotta
setblock 414 160 276 minecraft:stripped_oak_log
fill 414 160 292 414 162 293 minecraft:red_terracotta
setblock 414 160 316 minecraft:stripped_oak_log
fill 415 160 276 415 163 276 minecraft:red_terracotta
setblock 415 160 290 minecraft:stripped_oak_log
fill 415 160 291 415 163 291 minecraft:red_terracotta
setblock 415 160 295 minecraft:stripped_oak_log
fill 415 160 296 415 162 297 minecraft:red_terracotta
setblock 415 160 315 minecraft:stripped_oak_log
fill 415 160 316 415 163 316 minecraft:red_terracotta
fill 416 160 277 416 160 278 minecraft:red_terracotta
setblock 416 160 283 minecraft:red_terracotta
setblock 416 160 284 minecraft:stripped_oak_log
fill 416 160 285 416 163 285 minecraft:red_terracotta
setblock 416 160 289 minecraft:stripped_oak_log
fill 416 160 290 416 163 290 minecraft:red_terracotta
setblock 416 160 294 minecraft:stripped_oak_log
fill 416 160 295 416 163 295 minecraft:red_terracotta
setblock 416 160 299 minecraft:stripped_oak_log
setblock 416 160 313 minecraft:red_terracotta
setblock 416 160 314 minecraft:stripped_oak_log
fill 416 160 315 416 163 315 minecraft:red_terracotta
setblock 417 160 278 minecraft:stripped_oak_log
fill 417 160 279 417 163 279 minecraft:red_terracotta
setblock 417 160 283 minecraft:stripped_oak_log
fill 417 160 284 417 163 284 minecraft:red_terracotta
setblock 417 160 288 minecraft:stripped_oak_log
fill 417 160 289 417 163 289 minecraft:red_terracotta
setblock 417 160 293 minecraft:stripped_oak_log
fill 417 160 294 417 163 294 minecraft:red_terracotta
setblock 417 160 298 minecraft:stripped_oak_log
fill 417 160 299 417 163 299 minecraft:red_terracotta
setblock 417 160 302 minecraft:red_terracotta
fill 417 160 309 417 163 309 minecraft:red_terracotta
setblock 417 160 313 minecraft:stripped_oak_log
fill 417 160 314 417 163 314 minecraft:red_terracotta
fill 418 160 276 418 163 316 minecraft:brown_terracotta
setblock 377 161 276 minecraft:red_terracotta
setblock 377 161 277 minecraft:stripped_oak_log
fill 377 161 278 377 164 278 minecraft:red_terracotta
setblock 377 161 282 minecraft:stripped_oak_log
fill 377 161 283 377 164 283 minecraft:red_terracotta
setblock 377 161 287 minecraft:stripped_oak_log
fill 377 161 288 377 164 288 minecraft:red_terracotta
setblock 377 161 292 minecraft:stripped_oak_log
fill 377 161 293 377 164 293 minecraft:red_terracotta
setblock 377 161 297 minecraft:stripped_oak_log
fill 377 161 298 377 164 298 minecraft:red_terracotta
fill 377 161 300 377 162 300 minecraft:red_terracotta
fill 377 161 308 377 164 308 minecraft:red_terracotta
setblock 377 161 312 minecraft:stripped_oak_log
fill 377 161 313 377 164 313 minecraft:red_terracotta
setblock 378 161 276 minecraft:stripped_oak_log
fill 378 161 277 378 164 277 minecraft:red_terracotta
setblock 378 161 281 minecraft:stripped_oak_log
fill 378 161 282 378 164 282 minecraft:red_terracotta
setblock 378 161 286 minecraft:stripped_oak_log
fill 378 161 287 378 162 287 minecraft:red_terracotta
setblock 378 161 291 minecraft:stripped_oak_log
fill 378 161 292 378 164 292 minecraft:red_terracotta
setblock 378 161 296 minecraft:stripped_oak_log
fill 378 161 297 378 164 297 minecraft:red_terracotta
setblock 378 161 311 minecraft:stripped_oak_log
fill 378 161 312 378 164 312 minecraft:red_terracotta
setblock 378 161 316 minecraft:stripped_oak_log
fill 379 161 276 379 164 276 minecraft:red_terracotta
setblock 379 161 278 minecraft:light[level=12]
setblock 379 161 285 minecraft:light[level=12]
setblock 379 161 292 minecraft:light[level=12]
setblock 379 161 299 minecraft:light[level=12]
setblock 379 161 306 minecraft:light[level=12]
setblock 379 161 313 minecraft:light[level=12]
setblock 379 161 315 minecraft:stripped_oak_log
fill 379 161 316 382 161 316 minecraft:red_terracotta
setblock 380 161 314 minecraft:stripped_oak_log
fill 380 161 315 380 164 315 minecraft:red_terracotta
setblock 382 161 277 minecraft:stripped_oak_log
setblock 383 161 276 minecraft:stripped_oak_log
setblock 383 161 316 minecraft:stripped_oak_log
fill 384 161 276 387 161 276 minecraft:red_terracotta
setblock 384 161 315 minecraft:stripped_oak_log
fill 384 161 316 387 161 316 minecraft:red_terracotta
fill 385 161 300 385 167 300 minecraft:brown_terracotta
fill 385 161 315 388 161 315 minecraft:red_terracotta
setblock 386 161 278 minecraft:light[level=12]
setblock 386 161 285 minecraft:light[level=12]
setblock 386 161 292 minecraft:light[level=12]
fill 386 161 299 386 167 299 minecraft:brown_terracotta
setblock 386 161 306 minecraft:light[level=12]
setblock 386 161 313 minecraft:light[level=12]
setblock 388 161 276 minecraft:stripped_oak_log
setblock 388 161 316 minecraft:stripped_oak_log
fill 389 161 276 389 164 276 minecraft:red_terracotta
setblock 389 161 315 minecraft:stripped_oak_log
fill 389 161 316 392 161 316 minecraft:red_terracotta
setblock 390 161 314 minecraft:stripped_oak_log
fill 390 161 315 390 164 315 minecraft:red_terracotta
fill 391 161 314 391 164 314 minecraft:red_terracotta
setblock 393 161 276 minecraft:stripped_oak_log
setblock 393 161 278 minecraft:light[level=12]
setblock 393 161 285 minecraft:light[level=12]
setblock 393 161 292 minecraft:light[level=12]
setblock 393 161 299 minecraft:light[level=12]
setblock 393 161 306 minecraft:light[level=12]
setblock 393 161 313 minecraft:light[level=12]
setblock 393 161 316 minecraft:stripped_oak_log
fill 394 161 276 394 163 277 minecraft:red_terracotta
setblock 394 161 315 minecraft:stripped_oak_log
fill 394 161 316 394 164 316 minecraft:red_terracotta
fill 395 161 277 396 161 277 minecraft:red_terracotta
setblock 395 161 314 minecraft:stripped_oak_log
fill 395 161 315 395 164 315 minecraft:red_terracotta
setblock 396 161 313 minecraft:stripped_oak_log
fill 396 161 314 396 164 314 minecraft:red_terracotta
fill 397 161 313 397 162 313 minecraft:red_terracotta
setblock 398 161 276 minecraft:stripped_oak_log
setblock 398 161 316 minecraft:stripped_oak_log
fill 399 161 276 399 164 276 minecraft:red_terracotta
setblock 399 161 315 minecraft:stripped_oak_log
setblock 399 161 316 minecraft:red_terracotta
setblock 400 161 278 minecraft:light[level=12]
setblock 400 161 285 minecraft:light[level=12]
setblock 400 161 292 minecraft:light[level=12]
setblock 400 161 299 minecraft:light[level=12]
setblock 400 161 313 minecraft:light[level=12]
setblock 400 161 314 minecraft:stripped_oak_log
fill 400 161 315 400 164 315 minecraft:red_terracotta
fill 402 161 311 405 161 314 minecraft:brown_terracotta
fill 403 161 315 405 161 315 minecraft:brown_terracotta
setblock 403 161 316 minecraft:stripped_oak_log
fill 404 161 316 404 162 316 minecraft:red_terracotta
fill 406 161 311 408 161 312 minecraft:brown_terracotta
fill 406 161 313 408 161 315 minecraft:terracotta
setblock 407 161 278 minecraft:light[level=12]
setblock 407 161 285 minecraft:light[level=12]
setblock 407 161 292 minecraft:light[level=12]
setblock 407 161 299 minecraft:light[level=12]
setblock 407 161 306 minecraft:light[level=12]
fill 410 161 316 411 162 316 minecraft:red_terracotta
fill 411 161 276 412 161 276 minecraft:red_terracotta
setblock 413 161 276 minecraft:stripped_oak_log
setblock 413 161 316 minecraft:stripped_oak_log
fill 414 161 276 414 163 277 minecraft:red_terracotta
setblock 414 161 278 minecraft:light[level=12]
setblock 414 161 285 minecraft:light[level=12]
fill 414 161 291 414 164 291 minecraft:red_terracotta
setblock 414 161 294 minecraft:red_terracotta
setblock 414 161 295 minecraft:stripped_oak_log
setblock 414 161 299 minecraft:light[level=12]
setblock 414 161 306 minecraft:light[level=12]
setblock 414 161 313 minecraft:light[level=12]
setblock 414 161 315 minecraft:stripped_oak_log
fill 414 161 316 414 164 316 minecraft:red_terracotta
fill 415 161 277 416 161 277 minecraft:red_terracotta
fill 415 161 287 415 162 287 minecraft:red_terracotta
setblock 415 161 289 minecraft:stripped_oak_log
fill 415 161 290 415 164 290 minecraft:red_terracotta
setblock 415 161 294 minecraft:stripped_oak_log
fill 415 161 295 415 164 295 minecraft:red_terracotta
setblock 415 161 298 minecraft:red_terracotta
fill 415 161 315 415 164 315 minecraft:red_terracotta
setblock 416 161 278 minecraft:stripped_oak_log
fill 416 161 279 416 161 282 minecraft:red_terracotta
setblock 416 161 283 minecraft:stripped_oak_log
fill 416 161 284 416 164 284 minecraft:red_terracotta
setblock 416 161 288 minecraft:stripped_oak_log
fill 416 161 289 416 164 289 minecraft:red_terracotta
setblock 416 161 293 minecraft:stripped_oak_log
fill 416 161 294 416 164 294 minecraft:red_terracotta
setblock 416 161 297 minecraft:red_terracotta
setblock 416 161 298 minecraft:stripped_oak_log
fill 416 161 299 416 163 300 minecraft:red_terracotta
setblock 416 161 312 minecraft:red_terracotta
setblock 416 161 313 minecraft:stripped_oak_log
fill 416 161 314 416 164 314 minecraft:red_terracotta
setblock 417 161 277 minecraft:stripped_oak_log
fill 417 161 278 417 164 278 minecraft:red_terracotta
setblock 417 161 282 minecraft:stripped_oak_log
fill 417 161 283 417 164 283 minecraft:red_terracotta
setblock 417 161 287 minecraft:stripped_oak_log
fill 417 161 288 417 164 288 minecraft:red_terracotta
setblock 417 161 292 minecraft:stripped_oak_log
fill 417 161 293 417 164 293 minecraft:red_terracotta
setblock 417 161 297 minecraft:stripped_oak_log
fill 417 161 298 417 164 298 minecraft:red_terracotta
setblock 417 161 302 minecraft:stripped_oak_log
fill 417 161 303 417 164 303 minecraft:red_terracotta
setblock 417 161 312 minecraft:stripped_oak_log
fill 417 161 313 417 164 313 minecraft:red_terracotta
setblock 377 162 276 minecraft:stripped_oak_log
fill 377 162 277 377 165 277 minecraft:red_terracotta
setblock 377 162 281 minecraft:stripped_oak_log
fill 377 162 282 377 165 282 minecraft:red_terracotta
setblock 377 162 286 minecraft:stripped_oak_log
fill 377 162 287 377 165 287 minecraft:red_terracotta
setblock 377 162 291 minecraft:stripped_oak_log
fill 377 162 292 377 165 292 minecraft:red_terracotta
setblock 377 162 296 minecraft:stripped_oak_log
fill 377 162 297 377 165 297 minecraft:red_terracotta
setblock 377 162 301 minecraft:stripped_oak_log
setblock 377 162 311 minecraft:stripped_oak_log
fill 377 162 312 377 165 312 minecraft:red_terracotta
setblock 377 162 316 minecraft:stripped_oak_log
fill 378 162 276 378 165 276 minecraft:red_terracotta
setblock 378 162 280 minecraft:stripped_oak_log
fill 378 162 281 378 165 281 minecraft:red_terracotta
setblock 378 162 290 minecraft:stripped_oak_log
fill 378 162 291 378 164 291 minecraft:red_terracotta
setblock 378 162 295 minecraft:stripped_oak_log
fill 378 162 296 378 165 296 minecraft:red_terracotta
fill 378 162 311 378 164 311 minecraft:red_terracotta
setblock 378 162 314 minecraft:red_terracotta
setblock 378 162 315 minecraft:stripped_oak_log
fill 378 162 316 381 162 316 minecraft:red_terracotta
setblock 379 162 278 minecraft:red_terracotta
setblock 379 162 314 minecraft:stripped_oak_log
fill 379 162 315 379 165 315 minecraft:red_terracotta
fill 380 162 295 380 165 295 minecraft:brown_terracotta
fill 380 162 314 380 163 314 minecraft:red_terracotta
setblock 381 162 277 minecraft:stripped_oak_log
fill 381 162 294 381 165 294 minecraft:brown_terracotta
fill 381 162 296 381 165 296 minecraft:brown_terracotta
setblock 382 162 276 minecraft:stripped_oak_log
fill 382 162 277 383 164 277 minecraft:red_terracotta
fill 382 162 295 382 165 295 minecraft:brown_terracotta
setblock 382 162 316 minecraft:stripped_oak_log
fill 383 162 276 386 162 276 minecraft:red_terracotta
setblock 383 162 315 minecraft:stripped_oak_log
fill 383 162 316 386 162 316 minecraft:red_terracotta
fill 384 162 299 384 167 299 minecraft:brown_terracotta
fill 384 162 315 387 162 315 minecraft:red_terracotta
fill 385 162 298 386 167 298 minecraft:brown_terracotta
fill 386 162 300 386 167 300 minecraft:brown_terracotta
setblock 387 162 276 minecraft:stripped_oak_log
setblock 387 162 316 minecraft:stripped_oak_log
fill 388 162 276 388 165 276 minecraft:red_terracotta
setblock 388 162 315 minecraft:stripped_oak_log
fill 388 162 316 391 162 316 minecraft:red_terracotta
setblock 389 162 314 minecraft:stripped_oak_log
fill 389 162 315 389 165 315 minecraft:red_terracotta
fill 390 162 314 390 165 314 minecraft:red_terracotta
setblock 391 162 276 minecraft:red_terracotta
setblock 391 162 277 minecraft:stripped_oak_log
setblock 392 162 276 minecraft:stripped_oak_log
fill 392 162 277 393 164 277 minecraft:red_terracotta
setblock 392 162 316 minecraft:stripped_oak_log
fill 393 162 276 393 165 276 minecraft:red_terracotta
fill 393 162 313 393 163 313 minecraft:red_terracotta
setblock 393 162 315 minecraft:stripped_oak_log
fill 393 162 316 393 165 316 minecraft:red_terracotta
setblock 394 162 314 minecraft:stripped_oak_log
fill 394 162 315 394 165 315 minecraft:red_terracotta
setblock 395 162 277 minecraft:red_terracotta
setblock 395 162 313 minecraft:stripped_oak_log
fill 395 162 314 395 165 314 minecraft:red_terracotta
setblock 396 162 277 minecraft:stripped_oak_log
fill 396 162 313 396 163 313 minecraft:red_terracotta
setblock 397 162 276 minecraft:stripped_oak_log
fill 397 162 277 397 165 277 minecraft:red_terracotta
fill 397 162 314 399 162 316 minecraft:terracotta
fill 398 162 276 398 165 276 minecraft:red_terracotta
setblock 401 162 276 minecraft:red_terracotta
fill 402 162 276 404 162 278 minecraft:terracotta
fill 402 162 311 406 162 314 minecraft:stripped_oak_log
setblock 402 162 316 minecraft:stripped_oak_log
fill 403 162 315 408 162 315 minecraft:stripped_oak_log
fill 403 162 316 403 165 316 minecraft:red_terracotta
fill 407 162 311 408 162 313 minecraft:stripped_oak_log
fill 407 162 314 407 168 314 minecraft:green_concrete
setblock 408 162 314 minecraft:stripped_oak_log
fill 409 162 316 409 164 316 minecraft:red_terracotta
fill 410 162 276 411 162 276 minecraft:red_terracotta
setblock 412 162 276 minecraft:stripped_oak_log
fill 412 162 277 413 164 277 minecraft:red_terracotta
setblock 412 162 315 minecraft:red_terracotta
setblock 412 162 316 minecraft:stripped_oak_log
fill 413 162 276 413 165 276 minecraft:red_terracotta
setblock 413 162 315 minecraft:stripped_oak_log
fill 413 162 316 413 165 316 minecraft:red_terracotta
fill 414 162 290 414 164 290 minecraft:red_terracotta
setblock 414 162 294 minecraft:stripped_oak_log
fill 414 162 295 414 163 297 minecraft:red_terracotta
fill 414 162 315 414 165 315 minecraft:red_terracotta
setblock 415 162 277 minecraft:red_terracotta
setblock 415 162 278 minecraft:stripped_oak_log
setblock 415 162 288 minecraft:stripped_oak_log
fill 415 162 289 415 165 289 minecraft:red_terracotta
setblock 415 162 293 minecraft:stripped_oak_log
fill 415 162 294 415 165 294 minecraft:red_terracotta
setblock 415 162 298 minecraft:stripped_oak_log
fill 415 162 299 415 165 299 minecraft:red_terracotta
setblock 416 162 277 minecraft:stripped_oak_log
fill 416 162 278 416 162 281 minecraft:red_terracotta
setblock 416 162 282 minecraft:stripped_oak_log
fill 416 162 283 416 165 283 minecraft:red_terracotta
setblock 416 162 287 minecraft:stripped_oak_log
fill 416 162 288 416 165 288 minecraft:red_terracotta
setblock 416 162 292 minecraft:stripped_oak_log
fill 416 162 293 416 165 293 minecraft:red_terracotta
setblock 416 162 297 minecraft:stripped_oak_log
fill 416 162 298 416 165 298 minecraft:red_terracotta
setblock 416 162 301 minecraft:red_terracotta
setblock 416 162 312 minecraft:stripped_oak_log
fill 416 162 313 416 165 313 minecraft:red_terracotta
setblock 417 162 276 minecraft:stripped_oak_log
fill 417 162 277 417 165 277 minecraft:red_terracotta
setblock 417 162 281 minecraft:stripped_oak_log
fill 417 162 282 417 165 282 minecraft:red_terracotta
setblock 417 162 286 minecraft:stripped_oak_log
fill 417 162 287 417 165 287 minecraft:red_terracotta
setblock 417 162 291 minecraft:stripped_oak_log
fill 417 162 292 417 165 292 minecraft:red_terracotta
setblock 417 162 296 minecraft:stripped_oak_log
fill 417 162 297 417 165 297 minecraft:red_terracotta
setblock 417 162 301 minecraft:stripped_oak_log
fill 417 162 302 417 165 302 minecraft:red_terracotta
setblock 417 162 311 minecraft:stripped_oak_log
fill 417 162 312 417 165 312 minecraft:red_terracotta
setblock 417 162 316 minecraft:stripped_oak_log
fill 377 163 276 377 166 276 minecraft:red_terracotta
setblock 377 163 280 minecraft:stripped_oak_log
fill 377 163 281 377 166 281 minecraft:red_terracotta
setblock 377 163 285 minecraft:stripped_oak_log
fill 377 163 286 377 166 286 minecraft:red_terracotta
setblock 377 163 290 minecraft:stripped_oak_log
fill 377 163 291 377 166 291 minecraft:red_terracotta
setblock 377 163 295 minecraft:stripped_oak_log
fill 377 163 296 377 166 296 minecraft:red_terracotta
setblock 377 163 300 minecraft:stripped_oak_log
fill 377 163 301 377 165 302 minecraft:red_terracotta
setblock 377 163 310 minecraft:stripped_oak_log
fill 377 163 311 377 166 311 minecraft:red_terracotta
setblock 377 163 315 minecraft:stripped_oak_log
fill 377 163 316 380 163 316 minecraft:red_terracotta
setblock 378 163 279 minecraft:stripped_oak_log
fill 378 163 280 378 166 280 minecraft:red_terracotta
setblock 378 163 289 minecraft:stripped_oak_log
fill 378 163 290 378 164 290 minecraft:red_terracotta
setblock 378 163 294 minecraft:stripped_oak_log
fill 378 163 295 378 166 295 minecraft:red_terracotta
setblock 378 163 298 minecraft:red_terracotta
setblock 378 163 314 minecraft:stripped_oak_log
fill 378 163 315 378 166 315 minecraft:red_terracotta
setblock 379 163 278 minecraft:stripped_oak_log
fill 379 163 279 379 166 279 minecraft:red_terracotta
fill 379 163 314 379 164 314 minecraft:red_terracotta
setblock 380 163 277 minecraft:stripped_oak_log
fill 380 163 278 380 166 278 minecraft:red_terracotta
setblock 381 163 276 minecraft:stripped_oak_log
fill 381 163 277 381 166 277 minecraft:red_terracotta
setblock 381 163 316 minecraft:stripped_oak_log
fill 382 163 276 385 163 276 minecraft:red_terracotta
setblock 382 163 315 minecraft:stripped_oak_log
fill 382 163 316 385 163 316 minecraft:red_terracotta
fill 383 163 315 386 163 315 minecraft:red_terracotta
setblock 384 163 277 minecraft:red_terracotta
fill 384 163 298 384 167 298 minecraft:brown_terracotta
fill 384 163 300 384 167 300 minecraft:brown_terracotta
fill 385 163 301 385 167 301 minecraft:brown_terracotta
setblock 386 163 276 minecraft:stripped_oak_log
setblock 386 163 316 minecraft:stripped_oak_log
fill 387 163 276 387 166 276 minecraft:red_terracotta
fill 387 163 299 387 167 300 minecraft:brown_terracotta
setblock 387 163 315 minecraft:stripped_oak_log
fill 387 163 316 390 163 316 minecraft:red_terracotta
fill 388 163 277 389 163 277 minecraft:red_terracotta
fill 388 163 278 398 163 279 minecraft:brown_terracotta
setblock 388 163 314 minecraft:stripped_oak_log
fill 388 163 315 388 166 315 minecraft:red_terracotta
fill 389 163 314 389 166 314 minecraft:red_terracotta
setblock 390 163 277 minecraft:stripped_oak_log
setblock 391 163 276 minecraft:stripped_oak_log
fill 391 163 277 391 166 277 minecraft:red_terracotta
setblock 391 163 316 minecraft:stripped_oak_log
fill 392 163 276 392 166 276 minecraft:red_terracotta
fill 392 163 313 392 164 313 minecraft:red_terracotta
setblock 392 163 315 minecraft:stripped_oak_log
fill 392 163 316 392 166 316 minecraft:red_terracotta
setblock 393 163 314 minecraft:stripped_oak_log
fill 393 163 315 393 166 315 minecraft:red_terracotta
setblock 394 163 313 minecraft:stripped_oak_log
fill 394 163 314 394 166 314 minecraft:red_terracotta
setblock 395 163 277 minecraft:stripped_oak_log
fill 395 163 313 395 164 313 minecraft:red_terracotta
setblock 396 163 276 minecraft:stripped_oak_log
fill 396 163 277 396 166 277 minecraft:red_terracotta
setblock 396 163 316 minecraft:stripped_oak_log
fill 397 163 276 397 166 276 minecraft:red_terracotta
setblock 397 163 314 minecraft:red_terracotta
setblock 397 163 315 minecraft:stripped_oak_log
fill 397 163 316 399 164 316 minecraft:red_terracotta
fill 398 163 277 398 164 277 minecraft:red_terracotta
setblock 398 163 314 minecraft:stripped_oak_log
fill 398 163 315 398 169 315 minecraft:green_concrete
fill 399 163 314 399 163 315 minecraft:red_terracotta
setblock 401 163 276 minecraft:stripped_oak_log
setblock 401 163 316 minecraft:stripped_oak_log
fill 402 163 276 402 166 276 minecraft:red_terracotta
fill 402 163 311 408 163 311 minecraft:orange_terracotta
fill 402 163 316 402 166 316 minecraft:red_terracotta
fill 403 163 277 403 169 277 minecraft:green_concrete
fill 404 163 316 406 166 316 minecraft:shroomlight
fill 407 163 316 408 165 316 minecraft:red_terracotta
fill 408 163 276 410 163 276 minecraft:red_terracotta
setblock 410 163 316 minecraft:red_terracotta
setblock 411 163 276 minecraft:stripped_oak_log
fill 411 163 277 411 166 277 minecraft:red_terracotta
setblock 411 163 315 minecraft:red_terracotta
setblock 411 163 316 minecraft:stripped_oak_log
fill 412 163 276 412 166 276 minecraft:red_terracotta
setblock 412 163 315 minecraft:stripped_oak_log
fill 412 163 316 412 166 316 minecraft:red_terracotta
setblock 413 163 278 minecraft:red_terracotta
fill 413 163 315 413 166 315 minecraft:red_terracotta
setblock 414 163 278 minecraft:stripped_oak_log
setblock 414 163 292 minecraft:red_terracotta
setblock 414 163 293 minecraft:stripped_oak_log
fill 414 163 294 414 166 294 minecraft:red_terracotta
setblock 414 163 298 minecraft:stripped_oak_log
setblock 415 163 277 minecraft:stripped_oak_log
fill 415 163 278 415 163 281 minecraft:red_terracotta
setblock 415 163 286 minecraft:red_terracotta
setblock 415 163 287 minecraft:stripped_oak_log
fill 415 163 288 415 166 288 minecraft:red_terracotta
setblock 415 163 292 minecraft:stripped_oak_log
fill 415 163 293 415 166 293 minecraft:red_terracotta
setblock 415 163 296 minecraft:red_terracotta
setblock 415 163 297 minecraft:stripped_oak_log
fill 415 163 298 415 166 298 minecraft:red_terracotta
fill 415 163 300 415 164 300 minecraft:red_terracotta
setblock 416 163 276 minecraft:stripped_oak_log
fill 416 163 277 416 163 280 minecraft:red_terracotta
setblock 416 163 281 minecraft:stripped_oak_log
fill 416 163 282 416 166 282 minecraft:red_terracotta
setblock 416 163 286 minecraft:stripped_oak_log
fill 416 163 287 416 166 287 minecraft:red_terracotta
setblock 416 163 291 minecraft:stripped_oak_log
fill 416 163 292 416 166 292 minecraft:red_terracotta
setblock 416 163 296 minecraft:stripped_oak_log
fill 416 163 297 416 166 297 minecraft:red_terracotta
setblock 416 163 301 minecraft:stripped_oak_log
fill 416 163 302 416 166 302 minecraft:red_terracotta
setblock 416 163 312 minecraft:red_terracotta
setblock 416 163 316 minecraft:stripped_oak_log
fill 417 163 276 417 166 276 minecraft:red_terracotta
setblock 417 163 280 minecraft:stripped_oak_log
fill 417 163 281 417 166 281 minecraft:red_terracotta
setblock 417 163 285 minecraft:stripped_oak_log
fill 417 163 286 417 166 286 minecraft:red_terracotta
setblock 417 163 290 minecraft:stripped_oak_log
fill 417 163 291 417 166 291 minecraft:red_terracotta
setblock 417 163 295 minecraft:stripped_oak_log
fill 417 163 296 417 166 296 minecraft:red_terracotta
setblock 417 163 300 minecraft:stripped_oak_log
fill 417 163 301 417 166 301 minecraft:red_terracotta
setblock 417 163 304 minecraft:red_terracotta
setblock 417 163 310 minecraft:stripped_oak_log
fill 417 163 311 417 165 311 minecraft:red_terracotta
setblock 417 163 315 minecraft:stripped_oak_log
fill 417 163 316 417 166 316 minecraft:red_terracotta
fill 376 164 275 376 167 317 minecraft:light_gray_terracotta
fill 377 164 275 418 164 275 minecraft:light_gray_terracotta
setblock 377 164 279 minecraft:stripped_oak_log
fill 377 164 280 377 167 280 minecraft:red_terracotta
setblock 377 164 284 minecraft:stripped_oak_log
fill 377 164 285 377 167 285 minecraft:red_terracotta
setblock 377 164 289 minecraft:stripped_oak_log
fill 377 164 290 377 166 290 minecraft:red_terracotta
setblock 377 164 294 minecraft:stripped_oak_log
fill 377 164 295 377 167 295 minecraft:red_terracotta
setblock 377 164 299 minecraft:stripped_oak_log
fill 377 164 300 377 167 300 minecraft:red_terracotta
setblock 377 164 303 minecraft:red_terracotta
setblock 377 164 304 minecraft:stripped_oak_log
setblock 377 164 309 minecraft:stripped_oak_log
fill 377 164 310 377 167 310 minecraft:red_terracotta
setblock 377 164 314 minecraft:stripped_oak_log
fill 377 164 315 377 166 316 minecraft:red_terracotta
fill 377 164 317 418 167 317 minecraft:light_gray_terracotta
setblock 378 164 278 minecraft:stripped_oak_log
fill 378 164 279 378 167 279 minecraft:red_terracotta
setblock 378 164 283 minecraft:stripped_oak_log
setblock 378 164 293 minecraft:stripped_oak_log
fill 378 164 294 378 165 294 minecraft:red_terracotta
setblock 378 164 298 minecraft:stripped_oak_log
fill 378 164 299 378 166 299 minecraft:red_terracotta
setblock 378 164 313 minecraft:stripped_oak_log
fill 378 164 314 378 167 314 minecraft:red_terracotta
fill 378 164 316 379 164 316 minecraft:red_terracotta
setblock 379 164 277 minecraft:stripped_oak_log
fill 379 164 278 379 167 278 minecraft:red_terracotta
setblock 380 164 276 minecraft:stripped_oak_log
fill 380 164 277 380 167 277 minecraft:red_terracotta
setblock 380 164 316 minecraft:stripped_oak_log
fill 381 164 276 384 164 276 minecraft:red_terracotta
setblock 381 164 315 minecraft:stripped_oak_log
fill 381 164 316 384 164 316 minecraft:red_terracotta
fill 382 164 315 385 164 315 minecraft:red_terracotta
fill 383 164 299 383 167 299 minecraft:brown_terracotta
setblock 384 164 277 minecraft:stripped_oak_log
fill 384 164 301 384 167 301 minecraft:brown_terracotta
setblock 385 164 276 minecraft:stripped_oak_log
fill 385 164 277 388 164 277 minecraft:red_terracotta
fill 385 164 297 386 167 297 minecraft:brown_terracotta
setblock 385 164 316 minecraft:stripped_oak_log
fill 386 164 276 386 167 276 minecraft:red_terracotta
fill 386 164 301 386 167 301 minecraft:brown_terracotta
setblock 386 164 315 minecraft:stripped_oak_log
fill 386 164 316 389 164 316 minecraft:red_terracotta
fill 387 164 298 387 167 298 minecraft:brown_terracotta
fill 387 164 315 387 167 315 minecraft:red_terracotta
fill 388 164 278 398 164 279 minecraft:stripped_oak_log
fill 388 164 314 388 167 314 minecraft:red_terracotta
setblock 389 164 277 minecraft:stripped_oak_log
setblock 390 164 276 minecraft:stripped_oak_log
fill 390 164 277 390 167 277 minecraft:red_terracotta
setblock 390 164 316 minecraft:stripped_oak_log
fill 391 164 276 391 167 276 minecraft:red_terracotta
setblock 391 164 315 minecraft:stripped_oak_log
fill 391 164 316 391 167 316 minecraft:red_terracotta
setblock 392 164 314 minecraft:stripped_oak_log
fill 392 164 315 392 167 315 minecraft:red_terracotta
setblock 393 164 313 minecraft:stripped_oak_log
fill 393 164 314 393 167 314 minecraft:red_terracotta
setblock 394 164 276 minecraft:red_terracotta
setblock 394 164 277 minecraft:stripped_oak_log
fill 394 164 313 394 165 313 minecraft:red_terracotta
setblock 395 164 276 minecraft:stripped_oak_log
fill 395 164 277 395 167 277 minecraft:red_terracotta
setblock 395 164 316 minecraft:stripped_oak_log
fill 396 164 276 396 167 276 minecraft:red_terracotta
setblock 396 164 315 minecraft:stripped_oak_log
fill 396 164 316 396 167 316 minecraft:red_terracotta
setblock 397 164 314 minecraft:stripped_oak_log
fill 397 164 315 397 167 315 minecraft:red_terracotta
fill 398 164 314 398 165 314 minecraft:red_terracotta
fill 399 164 315 399 165 315 minecraft:red_terracotta
setblock 400 164 276 minecraft:stripped_oak_log
setblock 400 164 316 minecraft:stripped_oak_log
fill 401 164 276 401 167 276 minecraft:red_terracotta
setblock 401 164 315 minecraft:stripped_oak_log
fill 401 164 316 401 166 316 minecraft:red_terracotta
setblock 402 164 311 minecraft:stripped_oak_log
setblock 405 164 311 minecraft:stripped_oak_log
schedule function dropper:buildpart/68_5 1t
