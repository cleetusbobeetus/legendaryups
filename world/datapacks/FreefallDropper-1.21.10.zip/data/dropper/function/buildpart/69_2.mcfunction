setblock 440 181 313 minecraft:light[level=12]
setblock 442 181 278 minecraft:light[level=15]
setblock 442 181 286 minecraft:light[level=15]
setblock 442 181 294 minecraft:light[level=15]
setblock 442 181 302 minecraft:light[level=15]
setblock 442 181 310 minecraft:light[level=15]
setblock 447 181 278 minecraft:light[level=12]
setblock 447 181 285 minecraft:light[level=12]
setblock 447 181 292 minecraft:light[level=12]
setblock 447 181 299 minecraft:light[level=12]
setblock 447 181 306 minecraft:light[level=12]
setblock 447 181 313 minecraft:light[level=12]
setblock 450 181 278 minecraft:light[level=15]
setblock 450 181 286 minecraft:light[level=15]
setblock 450 181 294 minecraft:light[level=15]
setblock 450 181 302 minecraft:light[level=15]
setblock 450 181 310 minecraft:light[level=15]
setblock 454 181 278 minecraft:light[level=12]
setblock 454 181 285 minecraft:light[level=12]
setblock 454 181 292 minecraft:light[level=12]
setblock 454 181 299 minecraft:light[level=12]
setblock 454 181 306 minecraft:light[level=12]
setblock 454 181 313 minecraft:light[level=12]
setblock 458 181 278 minecraft:light[level=15]
setblock 458 181 286 minecraft:light[level=15]
setblock 458 181 294 minecraft:light[level=15]
setblock 458 181 302 minecraft:light[level=15]
setblock 458 181 310 minecraft:light[level=15]
setblock 461 181 278 minecraft:light[level=12]
setblock 461 181 285 minecraft:light[level=12]
setblock 461 181 292 minecraft:light[level=12]
setblock 461 181 299 minecraft:light[level=12]
setblock 461 181 306 minecraft:light[level=12]
setblock 461 181 313 minecraft:light[level=12]
fill 424 183 300 426 183 302 minecraft:black_concrete
fill 424 184 300 424 184 302 minecraft:black_concrete
fill 424 184 305 425 184 305 minecraft:red_stained_glass
fill 425 184 300 426 184 300 minecraft:black_concrete
fill 425 184 301 425 186 301 minecraft:gray_concrete
fill 425 184 302 426 184 302 minecraft:black_concrete
setblock 426 184 301 minecraft:black_concrete
fill 424 185 300 424 187 300 minecraft:black_concrete
setblock 424 185 301 minecraft:gray_concrete
fill 424 185 302 424 187 302 minecraft:black_concrete
setblock 425 185 300 minecraft:gray_concrete
setblock 425 185 302 minecraft:gray_concrete
fill 426 185 300 426 187 300 minecraft:black_concrete
setblock 426 185 301 minecraft:gray_concrete
fill 426 185 302 426 187 302 minecraft:black_concrete
fill 428 185 296 435 185 296 minecraft:black_concrete
fill 429 185 292 436 185 295 minecraft:black_concrete
fill 429 185 297 436 185 300 minecraft:black_concrete
fill 430 185 290 448 185 291 minecraft:black_concrete
fill 430 185 301 448 185 302 minecraft:black_concrete
fill 431 185 289 447 185 289 minecraft:black_concrete
fill 431 185 303 447 185 303 minecraft:black_concrete
fill 432 185 288 446 185 288 minecraft:black_concrete
fill 432 185 304 446 185 304 minecraft:black_concrete
fill 433 185 287 445 185 287 minecraft:black_concrete
fill 433 185 305 445 185 305 minecraft:black_concrete
fill 435 185 286 443 186 286 minecraft:black_concrete
fill 435 185 306 443 186 306 minecraft:black_concrete
fill 437 185 292 438 185 293 minecraft:black_concrete
fill 437 185 299 438 185 300 minecraft:black_concrete
fill 439 185 285 439 186 285 minecraft:black_concrete
fill 439 185 292 449 185 292 minecraft:black_concrete
fill 439 185 300 449 185 300 minecraft:black_concrete
fill 439 185 307 439 186 307 minecraft:black_concrete
fill 440 185 293 449 185 293 minecraft:black_concrete
fill 440 185 299 449 185 299 minecraft:black_concrete
fill 442 185 294 449 185 295 minecraft:black_concrete
fill 442 185 297 449 185 298 minecraft:black_concrete
fill 443 185 296 450 185 296 minecraft:black_concrete
fill 424 186 276 424 186 277 minecraft:gray_concrete
setblock 424 186 278 minecraft:black_concrete
fill 424 186 279 424 186 281 minecraft:gray_concrete
setblock 424 186 282 minecraft:black_concrete
fill 424 186 283 424 186 285 minecraft:gray_concrete
setblock 424 186 286 minecraft:black_concrete
fill 424 186 287 424 186 289 minecraft:gray_concrete
setblock 424 186 290 minecraft:black_concrete
fill 424 186 291 424 186 293 minecraft:gray_concrete
setblock 424 186 294 minecraft:black_concrete
fill 424 186 295 424 186 297 minecraft:gray_concrete
setblock 424 186 298 minecraft:black_concrete
fill 424 186 299 426 186 299 minecraft:gray_concrete
fill 424 186 301 424 187 301 minecraft:black_concrete
fill 424 186 303 424 186 305 minecraft:gray_concrete
setblock 424 186 306 minecraft:black_concrete
fill 424 186 307 424 186 309 minecraft:gray_concrete
setblock 424 186 310 minecraft:black_concrete
fill 424 186 311 424 186 313 minecraft:gray_concrete
setblock 424 186 314 minecraft:black_concrete
fill 424 186 315 425 186 316 minecraft:gray_concrete
setblock 425 186 276 minecraft:gray_concrete
setblock 425 186 277 minecraft:black_concrete
fill 425 186 278 425 186 280 minecraft:gray_concrete
setblock 425 186 281 minecraft:black_concrete
fill 425 186 282 425 186 284 minecraft:gray_concrete
setblock 425 186 285 minecraft:black_concrete
fill 425 186 286 425 186 288 minecraft:gray_concrete
setblock 425 186 289 minecraft:black_concrete
fill 425 186 290 425 186 292 minecraft:gray_concrete
setblock 425 186 293 minecraft:black_concrete
fill 425 186 294 425 186 296 minecraft:gray_concrete
setblock 425 186 297 minecraft:black_concrete
fill 425 186 298 427 186 298 minecraft:gray_concrete
fill 425 186 300 425 187 300 minecraft:black_concrete
fill 425 186 302 425 187 302 minecraft:black_concrete
fill 425 186 303 425 186 304 minecraft:gray_concrete
setblock 425 186 305 minecraft:black_concrete
fill 425 186 306 425 186 308 minecraft:gray_concrete
setblock 425 186 309 minecraft:black_concrete
fill 425 186 310 425 186 312 minecraft:gray_concrete
setblock 425 186 313 minecraft:black_concrete
fill 425 186 314 427 186 314 minecraft:gray_concrete
setblock 426 186 276 minecraft:black_concrete
fill 426 186 277 426 186 279 minecraft:gray_concrete
setblock 426 186 280 minecraft:black_concrete
fill 426 186 281 426 186 283 minecraft:gray_concrete
setblock 426 186 284 minecraft:black_concrete
fill 426 186 285 426 186 287 minecraft:gray_concrete
setblock 426 186 288 minecraft:black_concrete
fill 426 186 289 426 186 291 minecraft:gray_concrete
setblock 426 186 292 minecraft:black_concrete
fill 426 186 293 426 186 295 minecraft:gray_concrete
setblock 426 186 296 minecraft:black_concrete
fill 426 186 297 428 186 297 minecraft:gray_concrete
fill 426 186 301 426 187 301 minecraft:black_concrete
setblock 426 186 303 minecraft:gray_concrete
setblock 426 186 304 minecraft:black_concrete
fill 426 186 305 426 186 307 minecraft:gray_concrete
setblock 426 186 308 minecraft:black_concrete
fill 426 186 309 426 186 311 minecraft:gray_concrete
setblock 426 186 312 minecraft:black_concrete
fill 426 186 313 428 186 313 minecraft:gray_concrete
setblock 426 186 315 minecraft:gray_concrete
setblock 426 186 316 minecraft:black_concrete
fill 427 186 276 427 186 278 minecraft:gray_concrete
setblock 427 186 279 minecraft:black_concrete
fill 427 186 280 427 186 282 minecraft:gray_concrete
setblock 427 186 283 minecraft:black_concrete
fill 427 186 284 427 186 286 minecraft:gray_concrete
setblock 427 186 287 minecraft:black_concrete
fill 427 186 288 427 186 290 minecraft:gray_concrete
setblock 427 186 291 minecraft:black_concrete
fill 427 186 292 427 186 294 minecraft:gray_concrete
setblock 427 186 295 minecraft:black_concrete
setblock 427 186 296 minecraft:gray_concrete
setblock 427 186 299 minecraft:black_concrete
fill 427 186 300 427 186 302 minecraft:gray_concrete
setblock 427 186 303 minecraft:black_concrete
fill 427 186 304 427 186 306 minecraft:gray_concrete
setblock 427 186 307 minecraft:black_concrete
fill 427 186 308 427 186 310 minecraft:gray_concrete
setblock 427 186 311 minecraft:black_concrete
fill 427 186 312 429 186 312 minecraft:gray_concrete
setblock 427 186 315 minecraft:black_concrete
fill 427 186 316 429 186 316 minecraft:gray_concrete
fill 428 186 276 428 186 277 minecraft:gray_concrete
setblock 428 186 278 minecraft:black_concrete
fill 428 186 279 428 186 281 minecraft:gray_concrete
setblock 428 186 282 minecraft:black_concrete
fill 428 186 283 428 186 285 minecraft:gray_concrete
setblock 428 186 286 minecraft:black_concrete
fill 428 186 287 428 186 289 minecraft:gray_concrete
setblock 428 186 290 minecraft:black_concrete
fill 428 186 291 428 186 293 minecraft:gray_concrete
fill 428 186 294 432 186 294 minecraft:black_concrete
setblock 428 186 295 minecraft:gray_concrete
fill 428 186 296 430 186 296 minecraft:black_concrete
fill 428 186 298 432 186 298 minecraft:black_concrete
fill 428 186 299 428 186 301 minecraft:gray_concrete
setblock 428 186 302 minecraft:black_concrete
fill 428 186 303 428 186 305 minecraft:gray_concrete
setblock 428 186 306 minecraft:black_concrete
fill 428 186 307 428 186 309 minecraft:gray_concrete
setblock 428 186 310 minecraft:black_concrete
fill 428 186 311 430 186 311 minecraft:gray_concrete
setblock 428 186 314 minecraft:black_concrete
fill 428 186 315 430 186 315 minecraft:gray_concrete
setblock 429 186 276 minecraft:gray_concrete
setblock 429 186 277 minecraft:black_concrete
fill 429 186 278 429 186 280 minecraft:gray_concrete
setblock 429 186 281 minecraft:black_concrete
fill 429 186 282 429 186 284 minecraft:gray_concrete
setblock 429 186 285 minecraft:black_concrete
fill 429 186 286 429 186 288 minecraft:gray_concrete
setblock 429 186 289 minecraft:black_concrete
fill 429 186 290 429 186 291 minecraft:gray_concrete
fill 429 186 292 429 186 293 minecraft:black_concrete
fill 429 186 295 430 186 295 minecraft:black_concrete
fill 429 186 297 430 186 297 minecraft:black_concrete
fill 429 186 299 429 186 301 minecraft:black_concrete
fill 429 186 302 429 186 304 minecraft:gray_concrete
setblock 429 186 305 minecraft:black_concrete
fill 429 186 306 429 186 308 minecraft:gray_concrete
setblock 429 186 309 minecraft:black_concrete
fill 429 186 310 431 186 310 minecraft:gray_concrete
setblock 429 186 313 minecraft:black_concrete
fill 429 186 314 431 186 314 minecraft:gray_concrete
setblock 430 186 276 minecraft:black_concrete
fill 430 186 277 430 186 279 minecraft:gray_concrete
setblock 430 186 280 minecraft:black_concrete
fill 430 186 281 430 186 283 minecraft:gray_concrete
setblock 430 186 284 minecraft:black_concrete
fill 430 186 285 430 186 287 minecraft:gray_concrete
setblock 430 186 288 minecraft:black_concrete
setblock 430 186 289 minecraft:gray_concrete
fill 430 186 290 430 186 292 minecraft:black_concrete
setblock 430 186 293 minecraft:gray_concrete
setblock 430 186 299 minecraft:gray_concrete
fill 430 186 300 430 186 302 minecraft:black_concrete
setblock 430 186 303 minecraft:gray_concrete
setblock 430 186 304 minecraft:black_concrete
fill 430 186 305 430 186 307 minecraft:gray_concrete
setblock 430 186 308 minecraft:black_concrete
fill 430 186 309 432 186 309 minecraft:gray_concrete
setblock 430 186 312 minecraft:black_concrete
fill 430 186 313 432 186 313 minecraft:gray_concrete
setblock 430 186 316 minecraft:black_concrete
fill 431 186 276 431 186 278 minecraft:gray_concrete
setblock 431 186 279 minecraft:black_concrete
fill 431 186 280 431 186 282 minecraft:gray_concrete
setblock 431 186 283 minecraft:black_concrete
fill 431 186 284 431 186 286 minecraft:gray_concrete
setblock 431 186 287 minecraft:black_concrete
setblock 431 186 288 minecraft:gray_concrete
fill 431 186 289 433 186 290 minecraft:black_concrete
setblock 431 186 291 minecraft:gray_concrete
fill 431 186 292 431 186 293 minecraft:black_concrete
fill 431 186 295 431 186 297 minecraft:gray_concrete
fill 431 186 299 431 186 300 minecraft:black_concrete
setblock 431 186 301 minecraft:gray_concrete
fill 431 186 302 433 186 303 minecraft:black_concrete
fill 431 186 304 431 186 306 minecraft:gray_concrete
setblock 431 186 307 minecraft:black_concrete
fill 431 186 308 433 186 308 minecraft:gray_concrete
setblock 431 186 311 minecraft:black_concrete
fill 431 186 312 433 186 312 minecraft:gray_concrete
setblock 431 186 315 minecraft:black_concrete
fill 431 186 316 433 186 316 minecraft:gray_concrete
fill 432 186 276 432 186 277 minecraft:gray_concrete
setblock 432 186 278 minecraft:black_concrete
fill 432 186 279 432 186 281 minecraft:gray_concrete
setblock 432 186 282 minecraft:black_concrete
fill 432 186 283 432 186 285 minecraft:gray_concrete
setblock 432 186 286 minecraft:black_concrete
setblock 432 186 287 minecraft:gray_concrete
fill 432 186 288 433 186 288 minecraft:black_concrete
setblock 432 186 291 minecraft:black_concrete
setblock 432 186 292 minecraft:gray_concrete
fill 432 186 293 435 186 293 minecraft:black_concrete
fill 432 186 295 434 186 297 minecraft:black_concrete
fill 432 186 299 435 186 299 minecraft:black_concrete
setblock 432 186 300 minecraft:gray_concrete
setblock 432 186 301 minecraft:black_concrete
fill 432 186 304 433 186 304 minecraft:black_concrete
setblock 432 186 305 minecraft:gray_concrete
setblock 432 186 306 minecraft:black_concrete
fill 432 186 307 434 186 307 minecraft:gray_concrete
setblock 432 186 310 minecraft:black_concrete
fill 432 186 311 434 186 311 minecraft:gray_concrete
setblock 432 186 314 minecraft:black_concrete
fill 432 186 315 434 186 315 minecraft:gray_concrete
setblock 433 186 276 minecraft:gray_concrete
setblock 433 186 277 minecraft:black_concrete
fill 433 186 278 433 186 280 minecraft:gray_concrete
setblock 433 186 281 minecraft:black_concrete
fill 433 186 282 433 186 284 minecraft:gray_concrete
setblock 433 186 285 minecraft:black_concrete
fill 433 186 286 434 186 286 minecraft:gray_concrete
fill 433 186 287 435 186 287 minecraft:black_concrete
setblock 433 186 291 minecraft:gray_concrete
setblock 433 186 292 minecraft:black_concrete
setblock 433 186 294 minecraft:gray_concrete
setblock 433 186 298 minecraft:gray_concrete
setblock 433 186 300 minecraft:black_concrete
setblock 433 186 301 minecraft:gray_concrete
fill 433 186 305 435 186 305 minecraft:black_concrete
fill 433 186 306 434 186 306 minecraft:gray_concrete
setblock 433 186 309 minecraft:black_concrete
fill 433 186 310 435 186 310 minecraft:gray_concrete
setblock 433 186 313 minecraft:black_concrete
fill 433 186 314 435 186 314 minecraft:gray_concrete
setblock 434 186 276 minecraft:black_concrete
fill 434 186 277 434 186 279 minecraft:gray_concrete
setblock 434 186 280 minecraft:black_concrete
fill 434 186 281 434 186 283 minecraft:gray_concrete
setblock 434 186 284 minecraft:black_concrete
fill 434 186 285 436 186 285 minecraft:gray_concrete
setblock 434 186 288 minecraft:gray_concrete
setblock 434 186 289 minecraft:black_concrete
setblock 434 186 290 minecraft:gray_concrete
setblock 434 186 291 minecraft:black_concrete
setblock 434 186 292 minecraft:gray_concrete
setblock 434 186 294 minecraft:black_concrete
setblock 434 186 298 minecraft:black_concrete
setblock 434 186 300 minecraft:gray_concrete
setblock 434 186 301 minecraft:black_concrete
setblock 434 186 302 minecraft:gray_concrete
setblock 434 186 303 minecraft:black_concrete
setblock 434 186 304 minecraft:gray_concrete
setblock 434 186 308 minecraft:black_concrete
fill 434 186 309 436 186 309 minecraft:gray_concrete
setblock 434 186 312 minecraft:black_concrete
fill 434 186 313 436 186 313 minecraft:gray_concrete
setblock 434 186 316 minecraft:black_concrete
fill 435 186 276 435 186 278 minecraft:gray_concrete
setblock 435 186 279 minecraft:black_concrete
fill 435 186 280 435 186 282 minecraft:gray_concrete
setblock 435 186 283 minecraft:black_concrete
fill 435 186 284 437 186 284 minecraft:gray_concrete
fill 435 186 288 437 186 288 minecraft:black_concrete
setblock 435 186 289 minecraft:gray_concrete
fill 435 186 290 436 186 290 minecraft:black_concrete
setblock 435 186 291 minecraft:gray_concrete
fill 435 186 292 436 186 292 minecraft:black_concrete
setblock 435 186 294 minecraft:red_concrete
fill 435 186 295 435 186 297 minecraft:white_concrete
setblock 435 186 298 minecraft:red_concrete
fill 435 186 300 436 186 300 minecraft:black_concrete
setblock 435 186 301 minecraft:gray_concrete
fill 435 186 302 436 186 302 minecraft:black_concrete
setblock 435 186 303 minecraft:gray_concrete
fill 435 186 304 437 186 304 minecraft:black_concrete
setblock 435 186 307 minecraft:black_concrete
fill 435 186 308 437 186 308 minecraft:gray_concrete
setblock 435 186 311 minecraft:black_concrete
fill 435 186 312 437 186 312 minecraft:gray_concrete
setblock 435 186 315 minecraft:black_concrete
fill 435 186 316 437 186 316 minecraft:gray_concrete
fill 436 186 276 436 186 277 minecraft:gray_concrete
setblock 436 186 278 minecraft:black_concrete
fill 436 186 279 436 186 281 minecraft:gray_concrete
setblock 436 186 282 minecraft:black_concrete
fill 436 186 283 438 186 283 minecraft:gray_concrete
setblock 436 186 287 minecraft:gray_concrete
fill 436 186 289 442 186 289 minecraft:black_concrete
fill 436 186 291 442 186 291 minecraft:black_concrete
fill 436 186 293 436 186 295 minecraft:white_concrete
fill 436 186 297 436 186 299 minecraft:white_concrete
fill 436 186 301 442 186 301 minecraft:black_concrete
fill 436 186 303 442 186 303 minecraft:black_concrete
setblock 436 186 305 minecraft:gray_concrete
fill 436 186 307 438 186 307 minecraft:gray_concrete
setblock 436 186 310 minecraft:black_concrete
fill 436 186 311 438 186 311 minecraft:gray_concrete
setblock 436 186 314 minecraft:black_concrete
fill 436 186 315 438 186 315 minecraft:gray_concrete
setblock 437 186 276 minecraft:gray_concrete
setblock 437 186 277 minecraft:black_concrete
fill 437 186 278 437 186 280 minecraft:gray_concrete
setblock 437 186 281 minecraft:black_concrete
fill 437 186 282 439 186 282 minecraft:gray_concrete
setblock 437 186 285 minecraft:black_concrete
fill 437 186 287 441 186 287 minecraft:black_concrete
setblock 437 186 290 minecraft:gray_concrete
setblock 437 186 292 minecraft:red_concrete
fill 437 186 293 438 186 293 minecraft:white_concrete
fill 437 186 299 438 186 299 minecraft:white_concrete
setblock 437 186 300 minecraft:red_concrete
setblock 437 186 302 minecraft:gray_concrete
fill 437 186 305 441 186 305 minecraft:black_concrete
setblock 437 186 309 minecraft:black_concrete
fill 437 186 310 439 186 310 minecraft:gray_concrete
setblock 437 186 313 minecraft:black_concrete
fill 437 186 314 439 186 314 minecraft:gray_concrete
setblock 438 186 276 minecraft:black_concrete
fill 438 186 277 438 186 279 minecraft:gray_concrete
setblock 438 186 280 minecraft:black_concrete
fill 438 186 281 440 186 281 minecraft:gray_concrete
setblock 438 186 284 minecraft:black_concrete
setblock 438 186 285 minecraft:gray_concrete
fill 438 186 288 440 186 288 minecraft:gray_concrete
fill 438 186 290 440 186 290 minecraft:black_concrete
fill 438 186 292 440 186 292 minecraft:white_concrete
fill 438 186 300 440 186 300 minecraft:white_concrete
fill 438 186 302 440 186 302 minecraft:black_concrete
fill 438 186 304 440 186 304 minecraft:gray_concrete
setblock 438 186 308 minecraft:black_concrete
fill 438 186 309 440 186 309 minecraft:gray_concrete
setblock 438 186 312 minecraft:black_concrete
fill 438 186 313 440 186 313 minecraft:gray_concrete
setblock 438 186 316 minecraft:black_concrete
fill 439 186 276 439 186 278 minecraft:gray_concrete
setblock 439 186 279 minecraft:black_concrete
fill 439 186 280 441 186 280 minecraft:gray_concrete
setblock 439 186 283 minecraft:black_concrete
fill 439 186 284 441 186 284 minecraft:gray_concrete
fill 439 186 308 441 186 308 minecraft:gray_concrete
setblock 439 186 311 minecraft:black_concrete
fill 439 186 312 441 186 312 minecraft:gray_concrete
setblock 439 186 315 minecraft:black_concrete
fill 439 186 316 441 186 316 minecraft:gray_concrete
fill 440 186 276 440 186 277 minecraft:gray_concrete
setblock 440 186 278 minecraft:black_concrete
fill 440 186 279 442 186 279 minecraft:gray_concrete
setblock 440 186 282 minecraft:black_concrete
fill 440 186 283 442 186 283 minecraft:gray_concrete
setblock 440 186 285 minecraft:gray_concrete
fill 440 186 293 442 186 293 minecraft:white_concrete
fill 440 186 299 442 186 299 minecraft:white_concrete
fill 440 186 307 442 186 307 minecraft:gray_concrete
setblock 440 186 310 minecraft:black_concrete
fill 440 186 311 442 186 311 minecraft:gray_concrete
setblock 440 186 314 minecraft:black_concrete
fill 440 186 315 442 186 315 minecraft:gray_concrete
setblock 441 186 276 minecraft:gray_concrete
setblock 441 186 277 minecraft:black_concrete
fill 441 186 278 443 186 278 minecraft:gray_concrete
setblock 441 186 281 minecraft:black_concrete
fill 441 186 282 443 186 282 minecraft:gray_concrete
setblock 441 186 285 minecraft:black_concrete
fill 441 186 288 443 186 288 minecraft:black_concrete
setblock 441 186 290 minecraft:gray_concrete
setblock 441 186 292 minecraft:red_concrete
setblock 441 186 300 minecraft:red_concrete
setblock 441 186 302 minecraft:gray_concrete
fill 441 186 304 443 186 304 minecraft:black_concrete
setblock 441 186 309 minecraft:black_concrete
fill 441 186 310 443 186 310 minecraft:gray_concrete
setblock 441 186 313 minecraft:black_concrete
fill 441 186 314 443 186 314 minecraft:gray_concrete
setblock 442 186 276 minecraft:black_concrete
fill 442 186 277 444 186 277 minecraft:gray_concrete
setblock 442 186 280 minecraft:black_concrete
fill 442 186 281 444 186 281 minecraft:gray_concrete
setblock 442 186 284 minecraft:black_concrete
fill 442 186 285 444 186 285 minecraft:gray_concrete
setblock 442 186 287 minecraft:gray_concrete
fill 442 186 290 443 186 290 minecraft:black_concrete
fill 442 186 292 443 186 292 minecraft:black_concrete
fill 442 186 294 442 186 295 minecraft:white_concrete
fill 442 186 297 442 186 298 minecraft:white_concrete
fill 442 186 300 443 186 300 minecraft:black_concrete
fill 442 186 302 443 186 302 minecraft:black_concrete
setblock 442 186 305 minecraft:gray_concrete
setblock 442 186 308 minecraft:black_concrete
fill 442 186 309 444 186 309 minecraft:gray_concrete
setblock 442 186 312 minecraft:black_concrete
fill 442 186 313 444 186 313 minecraft:gray_concrete
setblock 442 186 316 minecraft:black_concrete
fill 443 186 276 445 186 276 minecraft:gray_concrete
setblock 443 186 279 minecraft:black_concrete
fill 443 186 280 445 186 280 minecraft:gray_concrete
setblock 443 186 283 minecraft:black_concrete
fill 443 186 284 445 186 284 minecraft:gray_concrete
fill 443 186 287 445 186 287 minecraft:black_concrete
setblock 443 186 289 minecraft:gray_concrete
setblock 443 186 291 minecraft:gray_concrete
fill 443 186 293 447 186 293 minecraft:black_concrete
setblock 443 186 294 minecraft:red_concrete
fill 443 186 295 443 186 297 minecraft:white_concrete
setblock 443 186 298 minecraft:red_concrete
fill 443 186 299 447 186 299 minecraft:black_concrete
setblock 443 186 301 minecraft:gray_concrete
setblock 443 186 303 minecraft:gray_concrete
fill 443 186 305 445 186 305 minecraft:black_concrete
setblock 443 186 307 minecraft:black_concrete
fill 443 186 308 445 186 308 minecraft:gray_concrete
setblock 443 186 311 minecraft:black_concrete
fill 443 186 312 445 186 312 minecraft:gray_concrete
setblock 443 186 315 minecraft:black_concrete
fill 443 186 316 445 186 316 minecraft:gray_concrete
setblock 444 186 278 minecraft:black_concrete
fill 444 186 279 446 186 279 minecraft:gray_concrete
setblock 444 186 282 minecraft:black_concrete
fill 444 186 283 446 186 283 minecraft:gray_concrete
setblock 444 186 286 minecraft:black_concrete
setblock 444 186 288 minecraft:gray_concrete
fill 444 186 289 447 186 289 minecraft:black_concrete
setblock 444 186 290 minecraft:gray_concrete
setblock 444 186 291 minecraft:black_concrete
setblock 444 186 292 minecraft:gray_concrete
fill 444 186 294 444 186 298 minecraft:black_concrete
setblock 444 186 300 minecraft:gray_concrete
setblock 444 186 301 minecraft:black_concrete
setblock 444 186 302 minecraft:gray_concrete
fill 444 186 303 447 186 303 minecraft:black_concrete
setblock 444 186 304 minecraft:gray_concrete
setblock 444 186 306 minecraft:black_concrete
fill 444 186 307 446 186 307 minecraft:gray_concrete
setblock 444 186 310 minecraft:black_concrete
fill 444 186 311 446 186 311 minecraft:gray_concrete
setblock 444 186 314 minecraft:black_concrete
fill 444 186 315 446 186 315 minecraft:gray_concrete
setblock 445 186 277 minecraft:black_concrete
fill 445 186 278 447 186 278 minecraft:gray_concrete
setblock 445 186 281 minecraft:black_concrete
fill 445 186 282 447 186 282 minecraft:gray_concrete
setblock 445 186 285 minecraft:black_concrete
fill 445 186 286 447 186 286 minecraft:gray_concrete
fill 445 186 288 446 186 288 minecraft:black_concrete
fill 445 186 290 448 186 290 minecraft:black_concrete
setblock 445 186 291 minecraft:gray_concrete
setblock 445 186 292 minecraft:black_concrete
setblock 445 186 294 minecraft:gray_concrete
fill 445 186 295 446 186 297 minecraft:black_concrete
setblock 445 186 298 minecraft:gray_concrete
setblock 445 186 300 minecraft:black_concrete
setblock 445 186 301 minecraft:gray_concrete
fill 445 186 302 448 186 302 minecraft:black_concrete
fill 445 186 304 446 186 304 minecraft:black_concrete
fill 445 186 306 447 186 306 minecraft:gray_concrete
setblock 445 186 309 minecraft:black_concrete
fill 445 186 310 447 186 310 minecraft:gray_concrete
setblock 445 186 313 minecraft:black_concrete
fill 445 186 314 447 186 314 minecraft:gray_concrete
setblock 446 186 276 minecraft:black_concrete
fill 446 186 277 448 186 277 minecraft:gray_concrete
setblock 446 186 280 minecraft:black_concrete
fill 446 186 281 448 186 281 minecraft:gray_concrete
setblock 446 186 284 minecraft:black_concrete
fill 446 186 285 448 186 285 minecraft:gray_concrete
setblock 446 186 287 minecraft:gray_concrete
setblock 446 186 291 minecraft:black_concrete
setblock 446 186 292 minecraft:gray_concrete
fill 446 186 294 449 186 294 minecraft:black_concrete
fill 446 186 298 449 186 298 minecraft:black_concrete
setblock 446 186 300 minecraft:gray_concrete
setblock 446 186 301 minecraft:black_concrete
fill 446 186 305 448 186 305 minecraft:gray_concrete
setblock 446 186 308 minecraft:black_concrete
fill 446 186 309 448 186 309 minecraft:gray_concrete
setblock 446 186 312 minecraft:black_concrete
fill 446 186 313 448 186 313 minecraft:gray_concrete
setblock 446 186 316 minecraft:black_concrete
fill 447 186 276 449 186 276 minecraft:gray_concrete
setblock 447 186 279 minecraft:black_concrete
fill 447 186 280 449 186 280 minecraft:gray_concrete
setblock 447 186 283 minecraft:black_concrete
fill 447 186 284 449 186 284 minecraft:gray_concrete
setblock 447 186 287 minecraft:black_concrete
fill 447 186 288 449 186 288 minecraft:gray_concrete
setblock 447 186 291 minecraft:gray_concrete
fill 447 186 292 450 186 292 minecraft:black_concrete
fill 447 186 295 447 186 297 minecraft:gray_concrete
fill 447 186 300 450 186 300 minecraft:black_concrete
setblock 447 186 301 minecraft:gray_concrete
fill 447 186 304 449 186 304 minecraft:gray_concrete
setblock 447 186 307 minecraft:black_concrete
fill 447 186 308 449 186 308 minecraft:gray_concrete
setblock 447 186 311 minecraft:black_concrete
fill 447 186 312 449 186 312 minecraft:gray_concrete
setblock 447 186 315 minecraft:black_concrete
fill 447 186 316 449 186 316 minecraft:gray_concrete
setblock 448 186 278 minecraft:black_concrete
fill 448 186 279 450 186 279 minecraft:gray_concrete
setblock 448 186 282 minecraft:black_concrete
fill 448 186 283 450 186 283 minecraft:gray_concrete
setblock 448 186 286 minecraft:black_concrete
fill 448 186 287 450 186 287 minecraft:gray_concrete
setblock 448 186 289 minecraft:gray_concrete
setblock 448 186 291 minecraft:black_concrete
setblock 448 186 293 minecraft:gray_concrete
fill 448 186 295 449 186 297 minecraft:black_concrete
setblock 448 186 299 minecraft:gray_concrete
fill 448 186 301 449 186 301 minecraft:black_concrete
fill 448 186 303 450 186 303 minecraft:gray_concrete
setblock 448 186 306 minecraft:black_concrete
fill 448 186 307 450 186 307 minecraft:gray_concrete
setblock 448 186 310 minecraft:black_concrete
fill 448 186 311 450 186 311 minecraft:gray_concrete
setblock 448 186 314 minecraft:black_concrete
fill 448 186 315 450 186 315 minecraft:gray_concrete
setblock 449 186 277 minecraft:black_concrete
fill 449 186 278 451 186 278 minecraft:gray_concrete
setblock 449 186 281 minecraft:black_concrete
fill 449 186 282 451 186 282 minecraft:gray_concrete
setblock 449 186 285 minecraft:black_concrete
fill 449 186 286 451 186 286 minecraft:gray_concrete
setblock 449 186 289 minecraft:black_concrete
fill 449 186 290 450 186 291 minecraft:gray_concrete
setblock 449 186 293 minecraft:black_concrete
setblock 449 186 299 minecraft:black_concrete
fill 449 186 302 451 186 302 minecraft:gray_concrete
setblock 449 186 305 minecraft:black_concrete
fill 449 186 306 451 186 306 minecraft:gray_concrete
setblock 449 186 309 minecraft:black_concrete
fill 449 186 310 451 186 310 minecraft:gray_concrete
setblock 449 186 313 minecraft:black_concrete
fill 449 186 314 451 186 314 minecraft:gray_concrete
setblock 450 186 276 minecraft:black_concrete
fill 450 186 277 452 186 277 minecraft:gray_concrete
setblock 450 186 280 minecraft:black_concrete
fill 450 186 281 452 186 281 minecraft:gray_concrete
setblock 450 186 284 minecraft:black_concrete
fill 450 186 285 452 186 285 minecraft:gray_concrete
setblock 450 186 288 minecraft:black_concrete
fill 450 186 289 452 186 289 minecraft:gray_concrete
fill 450 186 293 450 186 295 minecraft:gray_concrete
setblock 450 186 296 minecraft:black_concrete
fill 450 186 297 450 186 299 minecraft:gray_concrete
fill 450 186 301 452 186 301 minecraft:gray_concrete
setblock 450 186 304 minecraft:black_concrete
fill 450 186 305 452 186 305 minecraft:gray_concrete
setblock 450 186 308 minecraft:black_concrete
fill 450 186 309 452 186 309 minecraft:gray_concrete
setblock 450 186 312 minecraft:black_concrete
fill 450 186 313 452 186 313 minecraft:gray_concrete
setblock 450 186 316 minecraft:black_concrete
fill 451 186 276 453 186 276 minecraft:gray_concrete
setblock 451 186 279 minecraft:black_concrete
fill 451 186 280 453 186 280 minecraft:gray_concrete
setblock 451 186 283 minecraft:black_concrete
fill 451 186 284 453 186 284 minecraft:gray_concrete
setblock 451 186 287 minecraft:black_concrete
fill 451 186 288 453 186 288 minecraft:gray_concrete
setblock 451 186 290 minecraft:gray_concrete
setblock 451 186 291 minecraft:black_concrete
fill 451 186 292 451 186 294 minecraft:gray_concrete
setblock 451 186 295 minecraft:black_concrete
fill 451 186 296 451 186 298 minecraft:gray_concrete
setblock 451 186 299 minecraft:black_concrete
fill 451 186 300 453 186 300 minecraft:gray_concrete
setblock 451 186 303 minecraft:black_concrete
fill 451 186 304 453 186 304 minecraft:gray_concrete
setblock 451 186 307 minecraft:black_concrete
fill 451 186 308 453 186 308 minecraft:gray_concrete
setblock 451 186 311 minecraft:black_concrete
fill 451 186 312 453 186 312 minecraft:gray_concrete
setblock 451 186 315 minecraft:black_concrete
fill 451 186 316 453 186 316 minecraft:gray_concrete
setblock 452 186 278 minecraft:black_concrete
fill 452 186 279 454 186 279 minecraft:gray_concrete
setblock 452 186 282 minecraft:black_concrete
fill 452 186 283 454 186 283 minecraft:gray_concrete
setblock 452 186 286 minecraft:black_concrete
fill 452 186 287 454 186 287 minecraft:gray_concrete
setblock 452 186 290 minecraft:black_concrete
fill 452 186 291 452 186 293 minecraft:gray_concrete
setblock 452 186 294 minecraft:black_concrete
fill 452 186 295 452 186 297 minecraft:gray_concrete
setblock 452 186 298 minecraft:black_concrete
fill 452 186 299 454 186 299 minecraft:gray_concrete
setblock 452 186 302 minecraft:black_concrete
fill 452 186 303 454 186 303 minecraft:gray_concrete
setblock 452 186 306 minecraft:black_concrete
fill 452 186 307 454 186 307 minecraft:gray_concrete
setblock 452 186 310 minecraft:black_concrete
fill 452 186 311 454 186 311 minecraft:gray_concrete
setblock 452 186 314 minecraft:black_concrete
fill 452 186 315 454 186 315 minecraft:gray_concrete
setblock 453 186 277 minecraft:black_concrete
fill 453 186 278 455 186 278 minecraft:gray_concrete
setblock 453 186 281 minecraft:black_concrete
fill 453 186 282 455 186 282 minecraft:gray_concrete
setblock 453 186 285 minecraft:black_concrete
fill 453 186 286 455 186 286 minecraft:gray_concrete
setblock 453 186 289 minecraft:black_concrete
fill 453 186 290 453 186 292 minecraft:gray_concrete
setblock 453 186 293 minecraft:black_concrete
fill 453 186 294 453 186 296 minecraft:gray_concrete
setblock 453 186 297 minecraft:black_concrete
fill 453 186 298 455 186 298 minecraft:gray_concrete
setblock 453 186 301 minecraft:black_concrete
fill 453 186 302 455 186 302 minecraft:gray_concrete
setblock 453 186 305 minecraft:black_concrete
fill 453 186 306 455 186 306 minecraft:gray_concrete
setblock 453 186 309 minecraft:black_concrete
fill 453 186 310 455 186 310 minecraft:gray_concrete
setblock 453 186 313 minecraft:black_concrete
fill 453 186 314 455 186 314 minecraft:gray_concrete
setblock 454 186 276 minecraft:black_concrete
fill 454 186 277 456 186 277 minecraft:gray_concrete
setblock 454 186 280 minecraft:black_concrete
fill 454 186 281 456 186 281 minecraft:gray_concrete
setblock 454 186 284 minecraft:black_concrete
fill 454 186 285 456 186 285 minecraft:gray_concrete
setblock 454 186 288 minecraft:black_concrete
fill 454 186 289 454 186 291 minecraft:gray_concrete
setblock 454 186 292 minecraft:black_concrete
fill 454 186 293 454 186 295 minecraft:gray_concrete
setblock 454 186 296 minecraft:black_concrete
fill 454 186 297 456 186 297 minecraft:gray_concrete
setblock 454 186 300 minecraft:black_concrete
fill 454 186 301 456 186 301 minecraft:gray_concrete
setblock 454 186 304 minecraft:black_concrete
fill 454 186 305 456 186 305 minecraft:gray_concrete
setblock 454 186 308 minecraft:black_concrete
fill 454 186 309 456 186 309 minecraft:gray_concrete
setblock 454 186 312 minecraft:black_concrete
fill 454 186 313 456 186 313 minecraft:gray_concrete
setblock 454 186 316 minecraft:black_concrete
fill 455 186 276 457 186 276 minecraft:gray_concrete
setblock 455 186 279 minecraft:black_concrete
fill 455 186 280 457 186 280 minecraft:gray_concrete
setblock 455 186 283 minecraft:black_concrete
fill 455 186 284 457 186 284 minecraft:gray_concrete
setblock 455 186 287 minecraft:black_concrete
fill 455 186 288 455 186 290 minecraft:gray_concrete
setblock 455 186 291 minecraft:black_concrete
fill 455 186 292 455 186 294 minecraft:gray_concrete
setblock 455 186 295 minecraft:black_concrete
fill 455 186 296 457 186 296 minecraft:gray_concrete
setblock 455 186 299 minecraft:black_concrete
fill 455 186 300 457 186 300 minecraft:gray_concrete
setblock 455 186 303 minecraft:black_concrete
fill 455 186 304 457 186 304 minecraft:gray_concrete
setblock 455 186 307 minecraft:black_concrete
fill 455 186 308 457 186 308 minecraft:gray_concrete
setblock 455 186 311 minecraft:black_concrete
fill 455 186 312 457 186 312 minecraft:gray_concrete
setblock 455 186 315 minecraft:black_concrete
fill 455 186 316 457 186 316 minecraft:gray_concrete
setblock 456 186 278 minecraft:black_concrete
fill 456 186 279 458 186 279 minecraft:gray_concrete
setblock 456 186 282 minecraft:black_concrete
fill 456 186 283 458 186 283 minecraft:gray_concrete
setblock 456 186 286 minecraft:black_concrete
fill 456 186 287 456 186 289 minecraft:gray_concrete
setblock 456 186 290 minecraft:black_concrete
fill 456 186 291 456 186 293 minecraft:gray_concrete
setblock 456 186 294 minecraft:black_concrete
fill 456 186 295 458 186 295 minecraft:gray_concrete
setblock 456 186 298 minecraft:black_concrete
fill 456 186 299 458 186 299 minecraft:gray_concrete
setblock 456 186 302 minecraft:black_concrete
fill 456 186 303 458 186 303 minecraft:gray_concrete
setblock 456 186 306 minecraft:black_concrete
fill 456 186 307 458 186 307 minecraft:gray_concrete
setblock 456 186 310 minecraft:black_concrete
fill 456 186 311 458 186 311 minecraft:gray_concrete
setblock 456 186 314 minecraft:black_concrete
fill 456 186 315 458 186 315 minecraft:gray_concrete
setblock 457 186 277 minecraft:black_concrete
fill 457 186 278 459 186 278 minecraft:gray_concrete
setblock 457 186 281 minecraft:black_concrete
fill 457 186 282 459 186 282 minecraft:gray_concrete
setblock 457 186 285 minecraft:black_concrete
fill 457 186 286 457 186 288 minecraft:gray_concrete
setblock 457 186 289 minecraft:black_concrete
fill 457 186 290 457 186 292 minecraft:gray_concrete
setblock 457 186 293 minecraft:black_concrete
fill 457 186 294 459 186 294 minecraft:gray_concrete
setblock 457 186 297 minecraft:black_concrete
fill 457 186 298 459 186 298 minecraft:gray_concrete
setblock 457 186 301 minecraft:black_concrete
fill 457 186 302 459 186 302 minecraft:gray_concrete
setblock 457 186 305 minecraft:black_concrete
fill 457 186 306 459 186 306 minecraft:gray_concrete
setblock 457 186 309 minecraft:black_concrete
fill 457 186 310 459 186 310 minecraft:gray_concrete
setblock 457 186 313 minecraft:black_concrete
fill 457 186 314 459 186 314 minecraft:gray_concrete
setblock 458 186 276 minecraft:black_concrete
fill 458 186 277 460 186 277 minecraft:gray_concrete
setblock 458 186 280 minecraft:black_concrete
fill 458 186 281 460 186 281 minecraft:gray_concrete
setblock 458 186 284 minecraft:black_concrete
fill 458 186 285 458 186 287 minecraft:gray_concrete
setblock 458 186 288 minecraft:black_concrete
fill 458 186 289 458 186 291 minecraft:gray_concrete
setblock 458 186 292 minecraft:black_concrete
fill 458 186 293 460 186 293 minecraft:gray_concrete
setblock 458 186 296 minecraft:black_concrete
fill 458 186 297 460 186 297 minecraft:gray_concrete
setblock 458 186 300 minecraft:black_concrete
fill 458 186 301 460 186 301 minecraft:gray_concrete
setblock 458 186 304 minecraft:black_concrete
fill 458 186 305 460 186 305 minecraft:gray_concrete
setblock 458 186 308 minecraft:black_concrete
fill 458 186 309 460 186 309 minecraft:gray_concrete
setblock 458 186 312 minecraft:black_concrete
fill 458 186 313 460 186 313 minecraft:gray_concrete
setblock 458 186 316 minecraft:black_concrete
fill 459 186 276 461 186 276 minecraft:gray_concrete
setblock 459 186 279 minecraft:black_concrete
fill 459 186 280 461 186 280 minecraft:gray_concrete
setblock 459 186 283 minecraft:black_concrete
fill 459 186 284 459 186 286 minecraft:gray_concrete
setblock 459 186 287 minecraft:black_concrete
fill 459 186 288 459 186 290 minecraft:gray_concrete
setblock 459 186 291 minecraft:black_concrete
fill 459 186 292 461 186 292 minecraft:gray_concrete
setblock 459 186 295 minecraft:black_concrete
fill 459 186 296 461 186 296 minecraft:gray_concrete
setblock 459 186 299 minecraft:black_concrete
fill 459 186 300 461 186 300 minecraft:gray_concrete
setblock 459 186 303 minecraft:black_concrete
fill 459 186 304 461 186 304 minecraft:gray_concrete
setblock 459 186 307 minecraft:black_concrete
fill 459 186 308 461 186 308 minecraft:gray_concrete
setblock 459 186 311 minecraft:black_concrete
fill 459 186 312 461 186 312 minecraft:gray_concrete
setblock 459 186 315 minecraft:black_concrete
fill 459 186 316 461 186 316 minecraft:gray_concrete
setblock 460 186 278 minecraft:black_concrete
fill 460 186 279 462 186 279 minecraft:gray_concrete
setblock 460 186 282 minecraft:black_concrete
fill 460 186 283 460 186 285 minecraft:gray_concrete
setblock 460 186 286 minecraft:black_concrete
fill 460 186 287 460 186 289 minecraft:gray_concrete
setblock 460 186 290 minecraft:black_concrete
fill 460 186 291 462 186 291 minecraft:gray_concrete
setblock 460 186 294 minecraft:black_concrete
fill 460 186 295 462 186 295 minecraft:gray_concrete
setblock 460 186 298 minecraft:black_concrete
fill 460 186 299 462 186 299 minecraft:gray_concrete
setblock 460 186 302 minecraft:black_concrete
fill 460 186 303 462 186 303 minecraft:gray_concrete
setblock 460 186 306 minecraft:black_concrete
fill 460 186 307 462 186 307 minecraft:gray_concrete
setblock 460 186 310 minecraft:black_concrete
fill 460 186 311 462 186 311 minecraft:gray_concrete
setblock 460 186 314 minecraft:black_concrete
fill 460 186 315 462 186 315 minecraft:gray_concrete
setblock 461 186 277 minecraft:black_concrete
fill 461 186 278 463 186 278 minecraft:gray_concrete
setblock 461 186 281 minecraft:black_concrete
fill 461 186 282 461 186 284 minecraft:gray_concrete
setblock 461 186 285 minecraft:black_concrete
fill 461 186 286 461 186 288 minecraft:gray_concrete
setblock 461 186 289 minecraft:black_concrete
fill 461 186 290 463 186 290 minecraft:gray_concrete
setblock 461 186 293 minecraft:black_concrete
fill 461 186 294 463 186 294 minecraft:gray_concrete
setblock 461 186 297 minecraft:black_concrete
fill 461 186 298 463 186 298 minecraft:gray_concrete
setblock 461 186 301 minecraft:black_concrete
fill 461 186 302 463 186 302 minecraft:gray_concrete
setblock 461 186 305 minecraft:black_concrete
fill 461 186 306 463 186 306 minecraft:gray_concrete
setblock 461 186 309 minecraft:black_concrete
fill 461 186 310 463 186 310 minecraft:gray_concrete
setblock 461 186 313 minecraft:black_concrete
fill 461 186 314 463 186 314 minecraft:gray_concrete
setblock 462 186 276 minecraft:black_concrete
fill 462 186 277 464 186 277 minecraft:gray_concrete
setblock 462 186 280 minecraft:black_concrete
fill 462 186 281 462 186 283 minecraft:gray_concrete
setblock 462 186 284 minecraft:black_concrete
fill 462 186 285 462 186 287 minecraft:gray_concrete
setblock 462 186 288 minecraft:black_concrete
fill 462 186 289 464 186 289 minecraft:gray_concrete
setblock 462 186 292 minecraft:black_concrete
fill 462 186 293 464 186 293 minecraft:gray_concrete
setblock 462 186 296 minecraft:black_concrete
fill 462 186 297 464 186 297 minecraft:gray_concrete
setblock 462 186 300 minecraft:black_concrete
fill 462 186 301 464 186 301 minecraft:gray_concrete
setblock 462 186 304 minecraft:black_concrete
fill 462 186 305 464 186 305 minecraft:gray_concrete
setblock 462 186 308 minecraft:black_concrete
fill 462 186 309 464 186 309 minecraft:gray_concrete
setblock 462 186 312 minecraft:black_concrete
fill 462 186 313 464 186 313 minecraft:gray_concrete
setblock 462 186 316 minecraft:black_concrete
fill 463 186 276 464 186 276 minecraft:gray_concrete
setblock 463 186 279 minecraft:black_concrete
fill 463 186 280 463 186 282 minecraft:gray_concrete
setblock 463 186 283 minecraft:black_concrete
fill 463 186 284 463 186 286 minecraft:gray_concrete
setblock 463 186 287 minecraft:black_concrete
fill 463 186 288 464 186 288 minecraft:gray_concrete
setblock 463 186 291 minecraft:black_concrete
fill 463 186 292 464 186 292 minecraft:gray_concrete
setblock 463 186 295 minecraft:black_concrete
fill 463 186 296 464 186 296 minecraft:gray_concrete
setblock 463 186 299 minecraft:black_concrete
fill 463 186 300 464 186 300 minecraft:gray_concrete
setblock 463 186 303 minecraft:black_concrete
fill 463 186 304 464 186 304 minecraft:gray_concrete
setblock 463 186 307 minecraft:black_concrete
fill 463 186 308 464 186 308 minecraft:gray_concrete
setblock 463 186 311 minecraft:black_concrete
fill 463 186 312 464 186 312 minecraft:gray_concrete
setblock 463 186 315 minecraft:black_concrete
fill 463 186 316 464 186 316 minecraft:gray_concrete
setblock 464 186 278 minecraft:black_concrete
fill 464 186 279 464 186 281 minecraft:gray_concrete
setblock 464 186 282 minecraft:black_concrete
fill 464 186 283 464 186 285 minecraft:gray_concrete
setblock 464 186 286 minecraft:black_concrete
setblock 464 186 287 minecraft:gray_concrete
setblock 464 186 290 minecraft:black_concrete
setblock 464 186 291 minecraft:gray_concrete
setblock 464 186 294 minecraft:black_concrete
setblock 464 186 295 minecraft:gray_concrete
setblock 464 186 298 minecraft:black_concrete
setblock 464 186 299 minecraft:gray_concrete
setblock 464 186 302 minecraft:black_concrete
setblock 464 186 303 minecraft:gray_concrete
setblock 464 186 306 minecraft:black_concrete
setblock 464 186 307 minecraft:gray_concrete
setblock 464 186 310 minecraft:black_concrete
setblock 464 186 311 minecraft:gray_concrete
setblock 464 186 314 minecraft:black_concrete
setblock 464 186 315 minecraft:gray_concrete
fill 425 187 296 427 201 296 minecraft:pink_concrete
setblock 425 187 301 minecraft:black_concrete
setblock 426 187 278 minecraft:light[level=12]
setblock 426 187 285 minecraft:light[level=12]
setblock 426 187 292 minecraft:light[level=12]
fill 426 187 295 426 201 295 minecraft:pink_concrete
fill 426 187 297 426 201 297 minecraft:pink_concrete
setblock 426 187 299 minecraft:light[level=12]
setblock 426 187 306 minecraft:light[level=12]
setblock 426 187 313 minecraft:light[level=12]
fill 429 187 286 430 201 287 minecraft:light_blue_concrete
fill 429 187 305 430 201 306 minecraft:light_blue_concrete
setblock 433 187 278 minecraft:light[level=12]
setblock 433 187 285 minecraft:light[level=12]
setblock 433 187 292 minecraft:light[level=12]
setblock 433 187 299 minecraft:light[level=12]
setblock 433 187 306 minecraft:light[level=12]
setblock 433 187 313 minecraft:light[level=12]
fill 438 187 283 440 201 283 minecraft:pink_concrete
fill 438 187 309 440 201 309 minecraft:pink_concrete
fill 439 187 282 439 201 282 minecraft:pink_concrete
fill 439 187 284 439 201 284 minecraft:pink_concrete
fill 439 187 308 439 201 308 minecraft:pink_concrete
fill 439 187 310 439 201 310 minecraft:pink_concrete
setblock 440 187 278 minecraft:light[level=12]
setblock 440 187 285 minecraft:light[level=12]
setblock 440 187 292 minecraft:light[level=12]
setblock 440 187 299 minecraft:light[level=12]
setblock 440 187 306 minecraft:light[level=12]
setblock 440 187 313 minecraft:light[level=12]
fill 445 187 304 446 188 304 minecraft:iron_block
setblock 447 187 278 minecraft:light[level=12]
setblock 447 187 285 minecraft:light[level=12]
setblock 447 187 292 minecraft:light[level=12]
setblock 447 187 299 minecraft:light[level=12]
setblock 447 187 306 minecraft:light[level=12]
setblock 447 187 313 minecraft:light[level=12]
fill 448 187 286 449 201 287 minecraft:light_blue_concrete
fill 448 187 303 449 188 303 minecraft:iron_block
fill 448 187 305 449 201 306 minecraft:light_blue_concrete
fill 451 187 296 453 201 296 minecraft:pink_concrete
fill 451 187 302 452 188 302 minecraft:iron_block
fill 452 187 295 452 201 295 minecraft:pink_concrete
fill 452 187 297 452 201 297 minecraft:pink_concrete
setblock 454 187 278 minecraft:light[level=12]
setblock 454 187 285 minecraft:light[level=12]
setblock 454 187 292 minecraft:light[level=12]
setblock 454 187 299 minecraft:light[level=12]
setblock 454 187 306 minecraft:light[level=12]
setblock 454 187 313 minecraft:light[level=12]
setblock 461 187 278 minecraft:light[level=12]
setblock 461 187 285 minecraft:light[level=12]
setblock 461 187 292 minecraft:light[level=12]
setblock 461 187 299 minecraft:light[level=12]
setblock 461 187 306 minecraft:light[level=12]
setblock 461 187 313 minecraft:light[level=12]
fill 432 188 293 432 189 299 minecraft:magenta_concrete
fill 433 188 292 433 189 293 minecraft:magenta_concrete
fill 433 188 299 433 189 300 minecraft:magenta_concrete
fill 434 188 291 434 189 292 minecraft:magenta_concrete
fill 434 188 300 434 189 301 minecraft:magenta_concrete
fill 435 188 290 435 189 291 minecraft:magenta_concrete
fill 435 188 301 435 189 302 minecraft:magenta_concrete
fill 436 188 289 436 189 290 minecraft:magenta_concrete
fill 436 188 302 436 189 303 minecraft:magenta_concrete
fill 437 188 289 442 189 289 minecraft:magenta_concrete
fill 437 188 303 442 189 303 minecraft:magenta_concrete
fill 442 188 290 443 189 290 minecraft:magenta_concrete
fill 442 188 302 443 189 302 minecraft:magenta_concrete
fill 443 188 291 444 189 291 minecraft:magenta_concrete
fill 443 188 301 444 189 301 minecraft:magenta_concrete
fill 444 188 292 445 189 292 minecraft:magenta_concrete
fill 444 188 300 445 189 300 minecraft:magenta_concrete
fill 445 188 293 446 189 293 minecraft:magenta_concrete
fill 445 188 299 446 189 299 minecraft:magenta_concrete
fill 446 188 294 446 189 298 minecraft:magenta_concrete
setblock 426 189 278 minecraft:light[level=15]
setblock 426 189 286 minecraft:light[level=15]
setblock 426 189 294 minecraft:light[level=15]
setblock 426 189 302 minecraft:light[level=15]
setblock 426 189 310 minecraft:light[level=15]
setblock 434 189 278 minecraft:light[level=15]
setblock 434 189 286 minecraft:light[level=15]
setblock 434 189 294 minecraft:light[level=15]
setblock 434 189 302 minecraft:light[level=15]
setblock 434 189 310 minecraft:light[level=15]
setblock 442 189 278 minecraft:light[level=15]
setblock 442 189 286 minecraft:light[level=15]
setblock 442 189 294 minecraft:light[level=15]
setblock 442 189 310 minecraft:light[level=15]
setblock 450 189 278 minecraft:light[level=15]
setblock 450 189 286 minecraft:light[level=15]
setblock 450 189 294 minecraft:light[level=15]
setblock 450 189 302 minecraft:light[level=15]
setblock 450 189 310 minecraft:light[level=15]
setblock 458 189 278 minecraft:light[level=15]
setblock 458 189 286 minecraft:light[level=15]
setblock 458 189 294 minecraft:light[level=15]
setblock 458 189 302 minecraft:light[level=15]
setblock 458 189 310 minecraft:light[level=15]
fill 424 190 277 424 264 277 minecraft:iron_block
fill 424 190 287 424 264 287 minecraft:iron_block
fill 424 190 297 424 264 297 minecraft:iron_block
fill 424 190 307 424 264 307 minecraft:iron_block
fill 425 190 311 425 190 312 minecraft:black_concrete
fill 425 190 316 425 264 316 minecraft:iron_block
fill 426 190 309 426 190 310 minecraft:black_concrete
fill 426 190 311 428 224 312 minecraft:gray_concrete
fill 426 190 313 429 190 313 minecraft:black_concrete
fill 427 190 309 428 190 309 minecraft:black_concrete
fill 427 190 310 428 264 310 minecraft:gray_concrete
setblock 429 190 310 minecraft:black_concrete
fill 429 190 311 429 264 311 minecraft:gray_concrete
setblock 429 190 312 minecraft:black_concrete
setblock 430 190 311 minecraft:black_concrete
fill 431 190 276 431 264 276 minecraft:iron_block
fill 435 190 316 435 264 316 minecraft:iron_block
fill 441 190 276 441 264 276 minecraft:iron_block
fill 445 190 316 445 264 316 minecraft:iron_block
fill 451 190 276 451 264 276 minecraft:iron_block
fill 455 190 316 455 264 316 minecraft:iron_block
fill 457 190 309 458 190 309 minecraft:light_blue_concrete
fill 461 190 276 461 264 276 minecraft:iron_block
fill 464 190 283 464 264 283 minecraft:iron_block
fill 464 190 293 464 264 293 minecraft:iron_block
fill 464 190 303 464 264 303 minecraft:iron_block
fill 464 190 313 464 264 313 minecraft:iron_block
fill 424 191 286 425 191 286 minecraft:red_stained_glass
setblock 424 192 278 minecraft:gray_concrete
setblock 424 192 288 minecraft:gray_concrete
setblock 424 192 298 minecraft:gray_concrete
setblock 424 192 308 minecraft:gray_concrete
setblock 426 192 316 minecraft:gray_concrete
setblock 430 192 276 minecraft:gray_concrete
fill 430 192 293 430 193 299 minecraft:cyan_concrete
fill 431 192 291 431 193 293 minecraft:cyan_concrete
fill 431 192 299 431 193 301 minecraft:cyan_concrete
fill 432 192 290 432 193 291 minecraft:cyan_concrete
fill 432 192 301 432 193 302 minecraft:cyan_concrete
fill 433 192 289 433 193 290 minecraft:cyan_concrete
fill 433 192 302 433 193 303 minecraft:cyan_concrete
fill 434 192 288 434 193 289 minecraft:cyan_concrete
fill 434 192 303 434 193 304 minecraft:cyan_concrete
fill 435 192 288 436 193 288 minecraft:cyan_concrete
fill 435 192 304 436 193 304 minecraft:cyan_concrete
fill 436 192 287 442 193 287 minecraft:cyan_concrete
fill 436 192 305 442 193 305 minecraft:cyan_concrete
setblock 436 192 316 minecraft:gray_concrete
setblock 440 192 276 minecraft:gray_concrete
fill 442 192 288 444 193 288 minecraft:cyan_concrete
fill 442 192 304 444 193 304 minecraft:cyan_concrete
fill 444 192 289 445 193 289 minecraft:cyan_concrete
fill 444 192 303 445 193 303 minecraft:cyan_concrete
fill 445 192 290 446 193 290 minecraft:cyan_concrete
fill 445 192 302 446 193 302 minecraft:cyan_concrete
fill 446 192 291 447 193 291 minecraft:cyan_concrete
fill 446 192 301 447 193 301 minecraft:cyan_concrete
setblock 446 192 316 minecraft:gray_concrete
fill 447 192 292 447 193 293 minecraft:cyan_concrete
fill 447 192 299 447 193 300 minecraft:cyan_concrete
fill 448 192 293 448 193 299 minecraft:cyan_concrete
setblock 450 192 276 minecraft:gray_concrete
setblock 456 192 316 minecraft:gray_concrete
setblock 460 192 276 minecraft:gray_concrete
setblock 464 192 282 minecraft:gray_concrete
setblock 464 192 292 minecraft:gray_concrete
setblock 464 192 302 minecraft:gray_concrete
setblock 464 192 312 minecraft:gray_concrete
fill 423 193 281 423 193 284 minecraft:sea_lantern
fill 423 193 291 423 193 294 minecraft:sea_lantern
fill 423 193 301 423 193 304 minecraft:sea_lantern
fill 423 193 311 423 193 314 minecraft:sea_lantern
fill 424 193 305 425 193 305 minecraft:lime_stained_glass
fill 426 193 275 429 193 275 minecraft:sea_lantern
setblock 426 193 278 minecraft:light[level=12]
setblock 426 193 285 minecraft:light[level=12]
setblock 426 193 292 minecraft:light[level=12]
setblock 426 193 299 minecraft:light[level=12]
setblock 426 193 306 minecraft:light[level=12]
setblock 426 193 313 minecraft:light[level=12]
fill 427 193 317 430 193 317 minecraft:sea_lantern
setblock 433 193 278 minecraft:light[level=12]
setblock 433 193 285 minecraft:light[level=12]
setblock 433 193 292 minecraft:light[level=12]
setblock 433 193 299 minecraft:light[level=12]
setblock 433 193 306 minecraft:light[level=12]
setblock 433 193 313 minecraft:light[level=12]
fill 436 193 275 439 193 275 minecraft:sea_lantern
fill 437 193 317 440 193 317 minecraft:sea_lantern
setblock 440 193 278 minecraft:light[level=12]
setblock 440 193 285 minecraft:light[level=12]
setblock 440 193 292 minecraft:light[level=12]
setblock 440 193 299 minecraft:light[level=12]
setblock 440 193 306 minecraft:light[level=12]
setblock 440 193 313 minecraft:light[level=12]
fill 446 193 275 449 193 275 minecraft:sea_lantern
setblock 447 193 278 minecraft:light[level=12]
setblock 447 193 285 minecraft:light[level=12]
setblock 447 193 306 minecraft:light[level=12]
setblock 447 193 313 minecraft:light[level=12]
fill 447 193 317 450 193 317 minecraft:sea_lantern
setblock 454 193 278 minecraft:light[level=12]
setblock 454 193 285 minecraft:light[level=12]
setblock 454 193 292 minecraft:light[level=12]
setblock 454 193 299 minecraft:light[level=12]
setblock 454 193 306 minecraft:light[level=12]
setblock 454 193 313 minecraft:light[level=12]
fill 456 193 275 459 193 275 minecraft:sea_lantern
fill 457 193 317 460 193 317 minecraft:sea_lantern
setblock 461 193 278 minecraft:light[level=12]
setblock 461 193 285 minecraft:light[level=12]
setblock 461 193 292 minecraft:light[level=12]
setblock 461 193 299 minecraft:light[level=12]
setblock 461 193 306 minecraft:light[level=12]
setblock 461 193 313 minecraft:light[level=12]
fill 465 193 276 465 193 279 minecraft:sea_lantern
fill 465 193 286 465 193 289 minecraft:sea_lantern
fill 465 193 296 465 193 299 minecraft:sea_lantern
fill 465 193 306 465 193 309 minecraft:sea_lantern
setblock 465 193 316 minecraft:sea_lantern
fill 423 194 281 423 201 284 minecraft:black_concrete
fill 423 194 291 423 201 294 minecraft:black_concrete
fill 423 194 301 423 201 304 minecraft:black_concrete
fill 423 194 311 423 201 314 minecraft:black_concrete
fill 426 194 275 429 201 275 minecraft:black_concrete
fill 427 194 317 430 201 317 minecraft:black_concrete
fill 435 194 287 435 195 287 minecraft:light_blue_concrete
fill 436 194 275 439 201 275 minecraft:black_concrete
fill 437 194 317 440 201 317 minecraft:black_concrete
fill 446 194 275 449 201 275 minecraft:black_concrete
fill 447 194 317 450 201 317 minecraft:black_concrete
fill 456 194 275 459 201 275 minecraft:black_concrete
fill 457 194 317 460 201 317 minecraft:black_concrete
fill 465 194 276 465 201 279 minecraft:black_concrete
fill 465 194 286 465 201 289 minecraft:black_concrete
fill 465 194 296 465 201 299 minecraft:black_concrete
fill 465 194 306 465 201 309 minecraft:black_concrete
fill 465 194 316 465 201 316 minecraft:black_concrete
fill 437 195 301 439 196 301 minecraft:light_blue_concrete
fill 438 195 302 438 196 302 minecraft:light_blue_concrete
fill 454 195 302 454 196 302 minecraft:lime_concrete
fill 428 196 293 428 197 299 minecraft:lime_concrete
fill 429 196 291 429 197 293 minecraft:lime_concrete
fill 429 196 299 429 197 301 minecraft:lime_concrete
fill 430 196 289 430 197 290 minecraft:lime_concrete
fill 430 196 302 430 197 303 minecraft:lime_concrete
fill 431 196 288 431 197 289 minecraft:lime_concrete
fill 431 196 303 431 197 304 minecraft:lime_concrete
fill 432 196 287 432 197 288 minecraft:lime_concrete
fill 432 196 304 432 197 305 minecraft:lime_concrete
fill 433 196 287 433 197 287 minecraft:lime_concrete
fill 433 196 305 433 197 305 minecraft:lime_concrete
fill 434 196 286 436 197 286 minecraft:lime_concrete
fill 434 196 306 436 197 306 minecraft:lime_concrete
fill 436 196 285 442 197 285 minecraft:lime_concrete
fill 436 196 307 442 197 307 minecraft:lime_concrete
fill 442 196 286 444 197 286 minecraft:lime_concrete
fill 442 196 306 444 197 306 minecraft:lime_concrete
fill 445 196 287 446 197 287 minecraft:lime_concrete
fill 445 196 305 446 197 305 minecraft:lime_concrete
fill 446 196 288 447 197 288 minecraft:lime_concrete
fill 446 196 304 447 197 304 minecraft:lime_concrete
fill 447 196 289 448 197 289 minecraft:lime_concrete
fill 447 196 303 448 197 303 minecraft:lime_concrete
fill 448 196 290 448 197 290 minecraft:lime_concrete
fill 448 196 302 448 197 302 minecraft:lime_concrete
fill 449 196 291 449 197 293 minecraft:lime_concrete
fill 449 196 299 449 197 301 minecraft:lime_concrete
fill 450 196 293 450 197 299 minecraft:lime_concrete
setblock 426 197 278 minecraft:light[level=15]
setblock 426 197 286 minecraft:light[level=15]
setblock 426 197 294 minecraft:light[level=15]
setblock 426 197 302 minecraft:light[level=15]
setblock 426 197 310 minecraft:light[level=15]
setblock 434 197 278 minecraft:light[level=15]
setblock 434 197 294 minecraft:light[level=15]
setblock 434 197 302 minecraft:light[level=15]
setblock 434 197 310 minecraft:light[level=15]
setblock 442 197 278 minecraft:light[level=15]
setblock 442 197 294 minecraft:light[level=15]
setblock 442 197 302 minecraft:light[level=15]
setblock 442 197 310 minecraft:light[level=15]
setblock 450 197 278 minecraft:light[level=15]
setblock 450 197 286 minecraft:light[level=15]
setblock 450 197 302 minecraft:light[level=15]
setblock 450 197 310 minecraft:light[level=15]
setblock 458 197 278 minecraft:light[level=15]
setblock 458 197 286 minecraft:light[level=15]
setblock 458 197 294 minecraft:light[level=15]
setblock 458 197 302 minecraft:light[level=15]
setblock 458 197 310 minecraft:light[level=15]
setblock 424 198 278 minecraft:gray_concrete
fill 424 198 280 424 198 283 minecraft:gray_concrete
setblock 424 198 288 minecraft:gray_concrete
fill 424 198 290 424 198 293 minecraft:gray_concrete
setblock 424 198 298 minecraft:gray_concrete
fill 424 198 300 424 198 303 minecraft:gray_concrete
setblock 424 198 308 minecraft:gray_concrete
fill 424 198 310 424 198 313 minecraft:gray_concrete
fill 425 198 276 428 198 276 minecraft:gray_concrete
fill 425 198 311 425 198 312 minecraft:black_concrete
fill 426 198 309 426 198 310 minecraft:black_concrete
fill 426 198 313 429 198 313 minecraft:black_concrete
setblock 426 198 316 minecraft:gray_concrete
fill 427 198 309 428 198 309 minecraft:black_concrete
fill 428 198 316 431 198 316 minecraft:gray_concrete
setblock 429 198 310 minecraft:black_concrete
setblock 429 198 312 minecraft:black_concrete
setblock 430 198 276 minecraft:gray_concrete
setblock 430 198 311 minecraft:black_concrete
fill 435 198 276 438 198 276 minecraft:gray_concrete
setblock 436 198 316 minecraft:gray_concrete
fill 438 198 316 441 198 316 minecraft:gray_concrete
setblock 440 198 276 minecraft:gray_concrete
fill 445 198 276 448 198 276 minecraft:gray_concrete
setblock 446 198 316 minecraft:gray_concrete
fill 448 198 316 451 198 316 minecraft:gray_concrete
setblock 450 198 276 minecraft:gray_concrete
fill 455 198 276 458 198 276 minecraft:gray_concrete
setblock 456 198 316 minecraft:gray_concrete
fill 458 198 316 461 198 316 minecraft:gray_concrete
setblock 460 198 276 minecraft:gray_concrete
fill 464 198 277 464 198 280 minecraft:gray_concrete
setblock 464 198 282 minecraft:gray_concrete
fill 464 198 287 464 198 290 minecraft:gray_concrete
setblock 464 198 292 minecraft:gray_concrete
fill 464 198 297 464 198 300 minecraft:gray_concrete
setblock 464 198 302 minecraft:gray_concrete
fill 464 198 307 464 198 310 minecraft:gray_concrete
setblock 464 198 312 minecraft:gray_concrete
setblock 426 199 278 minecraft:light[level=12]
setblock 426 199 285 minecraft:light[level=12]
setblock 426 199 292 minecraft:light[level=12]
setblock 426 199 299 minecraft:light[level=12]
setblock 426 199 306 minecraft:light[level=12]
setblock 426 199 313 minecraft:light[level=12]
setblock 433 199 278 minecraft:light[level=12]
setblock 433 199 285 minecraft:light[level=12]
setblock 433 199 292 minecraft:light[level=12]
setblock 433 199 299 minecraft:light[level=12]
setblock 433 199 306 minecraft:light[level=12]
setblock 433 199 313 minecraft:light[level=12]
setblock 440 199 278 minecraft:light[level=12]
setblock 440 199 285 minecraft:light[level=12]
setblock 440 199 292 minecraft:light[level=12]
setblock 440 199 299 minecraft:light[level=12]
setblock 440 199 306 minecraft:light[level=12]
setblock 440 199 313 minecraft:light[level=12]
setblock 447 199 278 minecraft:light[level=12]
setblock 447 199 285 minecraft:light[level=12]
setblock 447 199 292 minecraft:light[level=12]
setblock 447 199 299 minecraft:light[level=12]
setblock 447 199 306 minecraft:light[level=12]
setblock 447 199 313 minecraft:light[level=12]
fill 454 199 277 454 211 277 minecraft:purple_wool
setblock 454 199 278 minecraft:light[level=12]
setblock 454 199 285 minecraft:light[level=12]
setblock 454 199 292 minecraft:light[level=12]
setblock 454 199 299 minecraft:light[level=12]
setblock 454 199 306 minecraft:light[level=12]
setblock 454 199 313 minecraft:light[level=12]
setblock 461 199 278 minecraft:light[level=12]
setblock 461 199 285 minecraft:light[level=12]
setblock 461 199 292 minecraft:light[level=12]
setblock 461 199 299 minecraft:light[level=12]
setblock 461 199 306 minecraft:light[level=12]
setblock 461 199 313 minecraft:light[level=12]
fill 424 200 286 425 200 286 minecraft:lime_stained_glass
fill 432 200 295 433 201 295 minecraft:yellow_concrete
fill 433 200 294 433 201 294 minecraft:yellow_concrete
fill 452 200 277 453 211 277 minecraft:purple_wool
fill 455 200 277 456 211 277 minecraft:purple_wool
fill 423 202 281 423 202 284 minecraft:sea_lantern
fill 423 202 291 423 202 294 minecraft:sea_lantern
fill 423 202 301 423 202 304 minecraft:sea_lantern
fill 423 202 311 423 202 314 minecraft:sea_lantern
fill 425 202 296 427 202 296 minecraft:glowstone
fill 426 202 275 429 202 275 minecraft:sea_lantern
setblock 426 202 295 minecraft:glowstone
setblock 426 202 297 minecraft:glowstone
fill 427 202 317 430 202 317 minecraft:sea_lantern
fill 429 202 286 430 202 287 minecraft:glowstone
fill 429 202 305 430 202 306 minecraft:glowstone
setblock 430 202 288 minecraft:glowstone
setblock 430 202 304 minecraft:glowstone
setblock 431 202 287 minecraft:glowstone
setblock 431 202 305 minecraft:glowstone
fill 436 202 275 439 202 275 minecraft:sea_lantern
fill 437 202 317 440 202 317 minecraft:sea_lantern
fill 438 202 283 440 202 283 minecraft:glowstone
fill 438 202 309 440 202 309 minecraft:glowstone
setblock 439 202 282 minecraft:glowstone
setblock 439 202 284 minecraft:glowstone
setblock 439 202 308 minecraft:glowstone
setblock 439 202 310 minecraft:glowstone
fill 446 202 275 449 202 275 minecraft:sea_lantern
fill 447 202 287 449 202 287 minecraft:glowstone
fill 447 202 305 449 202 305 minecraft:glowstone
fill 447 202 317 450 202 317 minecraft:sea_lantern
fill 448 202 286 449 202 286 minecraft:glowstone
setblock 448 202 288 minecraft:glowstone
setblock 448 202 304 minecraft:glowstone
fill 448 202 306 449 202 306 minecraft:glowstone
fill 451 202 296 453 202 296 minecraft:glowstone
setblock 452 202 295 minecraft:glowstone
setblock 452 202 297 minecraft:glowstone
fill 456 202 275 459 202 275 minecraft:sea_lantern
fill 457 202 317 460 202 317 minecraft:sea_lantern
fill 465 202 276 465 202 279 minecraft:sea_lantern
fill 465 202 286 465 202 289 minecraft:sea_lantern
fill 465 202 296 465 202 299 minecraft:sea_lantern
fill 465 202 306 465 202 309 minecraft:sea_lantern
setblock 465 202 316 minecraft:sea_lantern
fill 423 203 281 423 210 284 minecraft:black_concrete
fill 423 203 291 423 210 294 minecraft:black_concrete
fill 423 203 301 423 210 304 minecraft:black_concrete
fill 423 203 311 423 210 314 minecraft:black_concrete
fill 426 203 275 429 210 275 minecraft:black_concrete
fill 427 203 317 430 210 317 minecraft:black_concrete
fill 436 203 275 439 210 275 minecraft:black_concrete
fill 437 203 317 440 210 317 minecraft:black_concrete
fill 446 203 275 449 210 275 minecraft:black_concrete
fill 447 203 317 450 210 317 minecraft:black_concrete
fill 456 203 275 459 210 275 minecraft:black_concrete
fill 457 203 317 460 210 317 minecraft:black_concrete
fill 465 203 276 465 210 279 minecraft:black_concrete
fill 465 203 286 465 210 289 minecraft:black_concrete
fill 465 203 296 465 210 299 minecraft:black_concrete
fill 465 203 306 465 210 309 minecraft:black_concrete
fill 465 203 316 465 210 316 minecraft:black_concrete
setblock 424 204 278 minecraft:gray_concrete
setblock 424 204 288 minecraft:gray_concrete
setblock 424 204 298 minecraft:gray_concrete
setblock 424 204 308 minecraft:gray_concrete
fill 426 204 296 426 205 296 minecraft:magenta_concrete
setblock 426 204 316 minecraft:gray_concrete
setblock 430 204 276 minecraft:gray_concrete
setblock 436 204 316 minecraft:gray_concrete
setblock 440 204 276 minecraft:gray_concrete
setblock 446 204 316 minecraft:gray_concrete
setblock 450 204 276 minecraft:gray_concrete
setblock 456 204 316 minecraft:gray_concrete
setblock 460 204 276 minecraft:gray_concrete
setblock 464 204 282 minecraft:gray_concrete
setblock 464 204 292 minecraft:gray_concrete
setblock 464 204 302 minecraft:gray_concrete
setblock 464 204 312 minecraft:gray_concrete
setblock 426 205 278 minecraft:light[level=15]
setblock 426 205 285 minecraft:light[level=12]
setblock 426 205 286 minecraft:light[level=15]
setblock 426 205 292 minecraft:light[level=12]
setblock 426 205 294 minecraft:light[level=15]
setblock 426 205 299 minecraft:light[level=12]
setblock 426 205 302 minecraft:light[level=15]
setblock 426 205 306 minecraft:light[level=12]
setblock 426 205 310 minecraft:light[level=15]
setblock 426 205 313 minecraft:light[level=12]
setblock 433 205 278 minecraft:light[level=12]
setblock 433 205 285 minecraft:light[level=12]
setblock 433 205 292 minecraft:light[level=12]
setblock 433 205 299 minecraft:light[level=12]
setblock 433 205 306 minecraft:light[level=12]
setblock 433 205 313 minecraft:light[level=12]
setblock 434 205 278 minecraft:light[level=15]
setblock 434 205 286 minecraft:light[level=15]
setblock 434 205 294 minecraft:light[level=15]
setblock 434 205 302 minecraft:light[level=15]
setblock 434 205 310 minecraft:light[level=15]
setblock 440 205 278 minecraft:light[level=12]
setblock 440 205 285 minecraft:light[level=12]
setblock 440 205 292 minecraft:light[level=12]
setblock 440 205 299 minecraft:light[level=12]
setblock 440 205 306 minecraft:light[level=12]
setblock 440 205 313 minecraft:light[level=12]
setblock 442 205 278 minecraft:light[level=15]
setblock 442 205 286 minecraft:light[level=15]
setblock 442 205 294 minecraft:light[level=15]
setblock 442 205 302 minecraft:light[level=15]
setblock 442 205 310 minecraft:light[level=15]
setblock 447 205 278 minecraft:light[level=12]
setblock 447 205 285 minecraft:light[level=12]
setblock 447 205 292 minecraft:light[level=12]
setblock 447 205 299 minecraft:light[level=12]
setblock 447 205 306 minecraft:light[level=12]
setblock 447 205 313 minecraft:light[level=12]
setblock 450 205 278 minecraft:light[level=15]
setblock 450 205 286 minecraft:light[level=15]
setblock 450 205 294 minecraft:light[level=15]
setblock 450 205 302 minecraft:light[level=15]
setblock 450 205 310 minecraft:light[level=15]
setblock 454 205 278 minecraft:light[level=12]
setblock 454 205 285 minecraft:light[level=12]
setblock 454 205 292 minecraft:light[level=12]
setblock 454 205 299 minecraft:light[level=12]
setblock 454 205 306 minecraft:light[level=12]
setblock 454 205 313 minecraft:light[level=12]
setblock 458 205 278 minecraft:light[level=15]
setblock 458 205 286 minecraft:light[level=15]
setblock 458 205 294 minecraft:light[level=15]
setblock 458 205 302 minecraft:light[level=15]
setblock 458 205 310 minecraft:light[level=15]
setblock 461 205 278 minecraft:light[level=12]
setblock 461 205 285 minecraft:light[level=12]
setblock 461 205 292 minecraft:light[level=12]
setblock 461 205 299 minecraft:light[level=12]
setblock 461 205 306 minecraft:light[level=12]
setblock 461 205 313 minecraft:light[level=12]
fill 425 206 311 425 206 312 minecraft:black_concrete
fill 426 206 309 426 206 310 minecraft:black_concrete
fill 426 206 313 429 206 313 minecraft:black_concrete
fill 427 206 309 428 206 309 minecraft:black_concrete
setblock 429 206 310 minecraft:black_concrete
setblock 429 206 312 minecraft:black_concrete
setblock 430 206 311 minecraft:black_concrete
fill 434 206 303 434 207 303 minecraft:light_blue_concrete
fill 424 207 280 424 207 283 minecraft:gray_concrete
fill 424 207 290 424 207 293 minecraft:gray_concrete
fill 424 207 300 424 207 303 minecraft:gray_concrete
fill 424 207 310 424 207 313 minecraft:gray_concrete
fill 425 207 276 428 207 276 minecraft:gray_concrete
fill 428 207 316 431 207 316 minecraft:gray_concrete
fill 435 207 276 438 207 276 minecraft:gray_concrete
fill 438 207 316 441 207 316 minecraft:gray_concrete
fill 445 207 276 448 207 276 minecraft:gray_concrete
fill 448 207 316 451 207 316 minecraft:gray_concrete
fill 455 207 276 458 207 276 minecraft:gray_concrete
fill 458 207 316 461 207 316 minecraft:gray_concrete
fill 464 207 277 464 207 280 minecraft:gray_concrete
fill 464 207 287 464 207 290 minecraft:gray_concrete
fill 464 207 297 464 207 300 minecraft:gray_concrete
fill 464 207 307 464 207 310 minecraft:gray_concrete
fill 453 208 293 453 209 294 minecraft:lime_concrete
setblock 424 210 278 minecraft:gray_concrete
setblock 424 210 288 minecraft:gray_concrete
setblock 424 210 298 minecraft:gray_concrete
setblock 424 210 308 minecraft:gray_concrete
setblock 426 210 316 minecraft:gray_concrete
setblock 430 210 276 minecraft:gray_concrete
setblock 436 210 316 minecraft:gray_concrete
setblock 440 210 276 minecraft:gray_concrete
setblock 446 210 316 minecraft:gray_concrete
setblock 450 210 276 minecraft:gray_concrete
setblock 456 210 316 minecraft:gray_concrete
setblock 460 210 276 minecraft:gray_concrete
setblock 464 210 282 minecraft:gray_concrete
setblock 464 210 292 minecraft:gray_concrete
setblock 464 210 302 minecraft:gray_concrete
setblock 464 210 312 minecraft:gray_concrete
fill 423 211 281 423 211 284 minecraft:sea_lantern
fill 423 211 291 423 211 294 minecraft:sea_lantern
fill 423 211 301 423 211 304 minecraft:sea_lantern
fill 423 211 311 423 211 314 minecraft:sea_lantern
fill 426 211 275 429 211 275 minecraft:sea_lantern
setblock 426 211 278 minecraft:light[level=12]
setblock 426 211 285 minecraft:light[level=12]
setblock 426 211 292 minecraft:light[level=12]
setblock 426 211 299 minecraft:light[level=12]
setblock 426 211 306 minecraft:light[level=12]
setblock 426 211 313 minecraft:light[level=12]
fill 427 211 317 430 211 317 minecraft:sea_lantern
setblock 433 211 278 minecraft:light[level=12]
setblock 433 211 285 minecraft:light[level=12]
setblock 433 211 292 minecraft:light[level=12]
setblock 433 211 299 minecraft:light[level=12]
setblock 433 211 306 minecraft:light[level=12]
setblock 433 211 313 minecraft:light[level=12]
fill 436 211 275 439 211 275 minecraft:sea_lantern
fill 437 211 317 440 211 317 minecraft:sea_lantern
setblock 440 211 278 minecraft:light[level=12]
setblock 440 211 285 minecraft:light[level=12]
setblock 440 211 292 minecraft:light[level=12]
setblock 440 211 299 minecraft:light[level=12]
setblock 440 211 306 minecraft:light[level=12]
setblock 440 211 313 minecraft:light[level=12]
fill 446 211 275 449 211 275 minecraft:sea_lantern
setblock 447 211 278 minecraft:light[level=12]
setblock 447 211 285 minecraft:light[level=12]
setblock 447 211 292 minecraft:light[level=12]
setblock 447 211 299 minecraft:light[level=12]
setblock 447 211 306 minecraft:light[level=12]
setblock 447 211 313 minecraft:light[level=12]
fill 447 211 317 450 211 317 minecraft:sea_lantern
setblock 454 211 278 minecraft:light[level=12]
setblock 454 211 285 minecraft:light[level=12]
setblock 454 211 292 minecraft:light[level=12]
setblock 454 211 299 minecraft:light[level=12]
setblock 454 211 306 minecraft:light[level=12]
setblock 454 211 313 minecraft:light[level=12]
fill 456 211 275 459 211 275 minecraft:sea_lantern
fill 457 211 317 460 211 317 minecraft:sea_lantern
setblock 461 211 278 minecraft:light[level=12]
setblock 461 211 285 minecraft:light[level=12]
setblock 461 211 292 minecraft:light[level=12]
setblock 461 211 299 minecraft:light[level=12]
setblock 461 211 306 minecraft:light[level=12]
setblock 461 211 313 minecraft:light[level=12]
fill 465 211 276 465 211 279 minecraft:sea_lantern
fill 465 211 286 465 211 289 minecraft:sea_lantern
fill 465 211 296 465 211 299 minecraft:sea_lantern
fill 465 211 306 465 211 309 minecraft:sea_lantern
setblock 465 211 316 minecraft:sea_lantern
fill 423 212 281 423 219 284 minecraft:black_concrete
fill 423 212 291 423 219 294 minecraft:black_concrete
fill 423 212 301 423 219 304 minecraft:black_concrete
fill 423 212 311 423 219 314 minecraft:black_concrete
fill 426 212 275 429 219 275 minecraft:black_concrete
fill 427 212 317 430 219 317 minecraft:black_concrete
fill 436 212 275 439 219 275 minecraft:black_concrete
fill 437 212 317 440 219 317 minecraft:black_concrete
fill 446 212 275 449 219 275 minecraft:black_concrete
fill 447 212 317 450 219 317 minecraft:black_concrete
fill 451 212 277 457 213 277 minecraft:iron_block
fill 456 212 275 459 219 275 minecraft:black_concrete
fill 457 212 317 460 219 317 minecraft:black_concrete
fill 465 212 276 465 219 279 minecraft:black_concrete
fill 465 212 286 465 219 289 minecraft:black_concrete
fill 465 212 296 465 219 299 minecraft:black_concrete
fill 465 212 306 465 219 309 minecraft:black_concrete
fill 465 212 316 465 219 316 minecraft:black_concrete
setblock 426 213 278 minecraft:light[level=15]
setblock 426 213 286 minecraft:light[level=15]
setblock 426 213 294 minecraft:light[level=15]
setblock 426 213 302 minecraft:light[level=15]
setblock 426 213 310 minecraft:light[level=15]
setblock 434 213 278 minecraft:light[level=15]
setblock 434 213 286 minecraft:light[level=15]
setblock 434 213 294 minecraft:light[level=15]
setblock 434 213 302 minecraft:light[level=15]
setblock 434 213 310 minecraft:light[level=15]
setblock 442 213 278 minecraft:light[level=15]
setblock 442 213 286 minecraft:light[level=15]
setblock 442 213 294 minecraft:light[level=15]
setblock 442 213 302 minecraft:light[level=15]
setblock 442 213 310 minecraft:light[level=15]
setblock 450 213 278 minecraft:light[level=15]
setblock 450 213 286 minecraft:light[level=15]
setblock 450 213 294 minecraft:light[level=15]
setblock 450 213 302 minecraft:light[level=15]
setblock 450 213 310 minecraft:light[level=15]
setblock 458 213 278 minecraft:light[level=15]
setblock 458 213 286 minecraft:light[level=15]
setblock 458 213 294 minecraft:light[level=15]
setblock 458 213 302 minecraft:light[level=15]
setblock 458 213 310 minecraft:light[level=15]
fill 461 213 299 461 214 299 minecraft:lime_concrete
fill 425 214 311 425 214 312 minecraft:black_concrete
fill 426 214 309 426 214 310 minecraft:black_concrete
fill 426 214 313 429 214 313 minecraft:black_concrete
fill 427 214 309 428 214 309 minecraft:black_concrete
setblock 429 214 310 minecraft:black_concrete
setblock 429 214 312 minecraft:black_concrete
setblock 430 214 311 minecraft:black_concrete
setblock 424 216 278 minecraft:gray_concrete
fill 424 216 280 424 216 283 minecraft:gray_concrete
setblock 424 216 288 minecraft:gray_concrete
fill 424 216 290 424 216 293 minecraft:gray_concrete
setblock 424 216 298 minecraft:gray_concrete
fill 424 216 300 424 216 303 minecraft:gray_concrete
setblock 424 216 308 minecraft:gray_concrete
fill 424 216 310 424 216 313 minecraft:gray_concrete
fill 425 216 276 428 216 276 minecraft:gray_concrete
setblock 426 216 316 minecraft:gray_concrete
fill 428 216 316 431 216 316 minecraft:gray_concrete
setblock 430 216 276 minecraft:gray_concrete
fill 435 216 276 438 216 276 minecraft:gray_concrete
setblock 436 216 316 minecraft:gray_concrete
fill 438 216 316 441 216 316 minecraft:gray_concrete
setblock 440 216 276 minecraft:gray_concrete
fill 445 216 276 448 216 276 minecraft:gray_concrete
setblock 446 216 316 minecraft:gray_concrete
fill 448 216 316 451 216 316 minecraft:gray_concrete
setblock 450 216 276 minecraft:gray_concrete
fill 450 216 277 452 216 279 minecraft:black_concrete
fill 455 216 276 458 216 276 minecraft:gray_concrete
setblock 456 216 316 minecraft:gray_concrete
fill 458 216 316 461 216 316 minecraft:gray_concrete
setblock 460 216 276 minecraft:gray_concrete
fill 464 216 277 464 216 280 minecraft:gray_concrete
setblock 464 216 282 minecraft:gray_concrete
fill 464 216 287 464 216 290 minecraft:gray_concrete
setblock 464 216 292 minecraft:gray_concrete
fill 464 216 297 464 216 300 minecraft:gray_concrete
setblock 464 216 302 minecraft:gray_concrete
fill 464 216 307 464 216 310 minecraft:gray_concrete
setblock 464 216 312 minecraft:gray_concrete
setblock 426 217 278 minecraft:light[level=12]
setblock 426 217 285 minecraft:light[level=12]
setblock 426 217 292 minecraft:light[level=12]
setblock 426 217 299 minecraft:light[level=12]
setblock 426 217 306 minecraft:light[level=12]
setblock 426 217 313 minecraft:light[level=12]
setblock 433 217 278 minecraft:light[level=12]
setblock 433 217 285 minecraft:light[level=12]
setblock 433 217 292 minecraft:light[level=12]
setblock 433 217 299 minecraft:light[level=12]
setblock 433 217 306 minecraft:light[level=12]
setblock 433 217 313 minecraft:light[level=12]
setblock 440 217 278 minecraft:light[level=12]
setblock 440 217 285 minecraft:light[level=12]
setblock 440 217 292 minecraft:light[level=12]
setblock 440 217 299 minecraft:light[level=12]
setblock 440 217 306 minecraft:light[level=12]
setblock 440 217 313 minecraft:light[level=12]
setblock 447 217 278 minecraft:light[level=12]
setblock 447 217 285 minecraft:light[level=12]
setblock 447 217 292 minecraft:light[level=12]
setblock 447 217 299 minecraft:light[level=12]
setblock 447 217 306 minecraft:light[level=12]
setblock 447 217 313 minecraft:light[level=12]
fill 450 217 277 450 217 279 minecraft:black_concrete
fill 451 217 277 452 217 277 minecraft:black_concrete
fill 451 217 278 451 219 278 minecraft:gray_concrete
fill 451 217 279 452 217 279 minecraft:black_concrete
fill 451 217 299 452 218 300 minecraft:light_blue_concrete
setblock 452 217 278 minecraft:black_concrete
fill 452 217 298 452 218 298 minecraft:light_blue_concrete
setblock 454 217 278 minecraft:light[level=12]
setblock 454 217 285 minecraft:light[level=12]
setblock 454 217 292 minecraft:light[level=12]
setblock 454 217 299 minecraft:light[level=12]
setblock 454 217 306 minecraft:light[level=12]
setblock 454 217 313 minecraft:light[level=12]
setblock 461 217 278 minecraft:light[level=12]
setblock 461 217 285 minecraft:light[level=12]
setblock 461 217 292 minecraft:light[level=12]
setblock 461 217 299 minecraft:light[level=12]
setblock 461 217 306 minecraft:light[level=12]
setblock 461 217 313 minecraft:light[level=12]
fill 426 218 292 427 219 300 minecraft:gray_concrete
fill 427 218 289 428 219 291 minecraft:gray_concrete
fill 427 218 301 428 219 303 minecraft:gray_concrete
fill 428 218 287 429 219 288 minecraft:gray_concrete
fill 428 218 304 429 219 305 minecraft:gray_concrete
fill 429 218 286 430 219 286 minecraft:gray_concrete
fill 429 218 289 429 219 289 minecraft:gray_concrete
fill 429 218 303 429 219 303 minecraft:gray_concrete
fill 429 218 306 430 219 306 minecraft:gray_concrete
fill 430 218 284 431 219 285 minecraft:gray_concrete
fill 430 218 287 430 219 287 minecraft:gray_concrete
fill 430 218 305 430 219 305 minecraft:gray_concrete
fill 430 218 307 431 219 308 minecraft:gray_concrete
fill 431 218 283 433 219 283 minecraft:gray_concrete
fill 431 218 309 433 219 309 minecraft:gray_concrete
fill 432 218 282 435 219 282 minecraft:gray_concrete
fill 432 218 284 432 219 284 minecraft:gray_concrete
fill 432 218 308 432 219 308 minecraft:gray_concrete
fill 432 218 310 435 219 310 minecraft:gray_concrete
fill 434 218 281 437 219 281 minecraft:gray_concrete
fill 434 218 311 437 219 311 minecraft:gray_concrete
fill 435 218 280 439 219 280 minecraft:gray_concrete
fill 435 218 312 439 219 312 minecraft:gray_concrete
fill 437 218 279 449 219 279 minecraft:gray_concrete
fill 437 218 313 451 219 313 minecraft:gray_concrete
fill 440 218 278 448 219 278 minecraft:gray_concrete
fill 440 218 314 448 219 314 minecraft:gray_concrete
fill 449 218 280 453 219 280 minecraft:gray_concrete
fill 449 218 312 453 219 312 minecraft:gray_concrete
fill 450 218 277 450 220 277 minecraft:black_concrete
setblock 450 218 278 minecraft:gray_concrete
fill 450 218 279 450 220 279 minecraft:black_concrete
setblock 451 218 277 minecraft:gray_concrete
setblock 451 218 279 minecraft:gray_concrete
fill 451 218 281 454 219 281 minecraft:gray_concrete
fill 451 218 311 454 219 311 minecraft:gray_concrete
fill 452 218 277 452 220 277 minecraft:black_concrete
setblock 452 218 278 minecraft:gray_concrete
fill 452 218 279 452 220 279 minecraft:black_concrete
fill 453 218 282 456 219 282 minecraft:gray_concrete
fill 453 218 310 456 219 310 minecraft:gray_concrete
fill 455 218 283 457 219 283 minecraft:gray_concrete
fill 455 218 309 457 219 309 minecraft:gray_concrete
fill 456 218 284 458 220 284 minecraft:gray_concrete
fill 456 218 308 458 219 308 minecraft:gray_concrete
fill 457 218 285 458 220 285 minecraft:gray_concrete
fill 457 218 307 458 219 307 minecraft:gray_concrete
fill 458 218 286 459 219 287 minecraft:gray_concrete
fill 458 218 305 459 219 306 minecraft:gray_concrete
fill 459 218 288 460 219 289 minecraft:gray_concrete
fill 459 218 303 460 219 304 minecraft:gray_concrete
fill 460 218 287 460 219 287 minecraft:gray_concrete
fill 460 218 290 461 219 291 minecraft:gray_concrete
fill 460 218 301 461 219 302 minecraft:gray_concrete
fill 460 218 305 460 219 305 minecraft:gray_concrete
fill 461 218 289 461 219 289 minecraft:gray_concrete
fill 461 218 292 462 219 300 minecraft:gray_concrete
fill 461 218 303 461 219 303 minecraft:gray_concrete
fill 424 219 305 425 219 305 minecraft:cyan_stained_glass
fill 450 219 278 450 220 278 minecraft:black_concrete
fill 451 219 277 451 220 277 minecraft:black_concrete
fill 451 219 279 451 220 279 minecraft:black_concrete
fill 452 219 278 452 220 278 minecraft:black_concrete
fill 459 219 285 464 220 285 minecraft:gray_concrete
fill 423 220 281 423 220 284 minecraft:sea_lantern
fill 423 220 291 423 220 294 minecraft:sea_lantern
fill 423 220 301 423 220 304 minecraft:sea_lantern
fill 423 220 311 423 220 314 minecraft:sea_lantern
fill 426 220 275 429 220 275 minecraft:sea_lantern
fill 427 220 289 427 220 291 minecraft:sea_lantern
fill 427 220 317 430 220 317 minecraft:sea_lantern
fill 428 220 287 428 220 288 minecraft:sea_lantern
setblock 429 220 286 minecraft:sea_lantern
fill 430 220 284 430 220 285 minecraft:sea_lantern
fill 431 220 283 431 220 284 minecraft:sea_lantern
fill 432 220 282 432 220 283 minecraft:sea_lantern
setblock 433 220 282 minecraft:sea_lantern
setblock 434 220 281 minecraft:sea_lantern
fill 435 220 280 436 220 280 minecraft:sea_lantern
fill 436 220 275 439 220 275 minecraft:sea_lantern
fill 437 220 279 438 220 279 minecraft:sea_lantern
fill 437 220 317 440 220 317 minecraft:sea_lantern
fill 445 220 284 455 220 284 minecraft:gray_concrete
fill 446 220 275 449 220 275 minecraft:sea_lantern
fill 446 220 285 456 221 285 minecraft:gray_concrete
fill 447 220 317 450 220 317 minecraft:sea_lantern
setblock 451 220 278 minecraft:black_concrete
fill 456 220 275 459 220 275 minecraft:sea_lantern
fill 457 220 317 460 220 317 minecraft:sea_lantern
fill 459 220 284 460 220 284 minecraft:gray_concrete
fill 465 220 276 465 220 279 minecraft:sea_lantern
fill 465 220 286 465 220 289 minecraft:sea_lantern
fill 465 220 296 465 220 299 minecraft:sea_lantern
fill 465 220 306 465 220 309 minecraft:sea_lantern
setblock 465 220 316 minecraft:sea_lantern
fill 423 221 281 423 228 284 minecraft:black_concrete
fill 423 221 291 423 228 294 minecraft:black_concrete
fill 423 221 301 423 228 304 minecraft:black_concrete
fill 423 221 311 423 228 314 minecraft:black_concrete
fill 426 221 275 429 228 275 minecraft:black_concrete
setblock 426 221 278 minecraft:light[level=15]
setblock 426 221 286 minecraft:light[level=15]
setblock 426 221 294 minecraft:light[level=15]
setblock 426 221 302 minecraft:light[level=15]
setblock 426 221 310 minecraft:light[level=15]
fill 427 221 317 430 228 317 minecraft:black_concrete
fill 431 221 284 453 221 284 minecraft:gray_concrete
setblock 434 221 278 minecraft:light[level=15]
setblock 434 221 286 minecraft:light[level=15]
setblock 434 221 294 minecraft:light[level=15]
setblock 434 221 302 minecraft:light[level=15]
setblock 434 221 310 minecraft:light[level=15]
fill 436 221 275 439 228 275 minecraft:black_concrete
fill 437 221 317 440 228 317 minecraft:black_concrete
fill 438 221 285 445 221 285 minecraft:gray_concrete
setblock 442 221 278 minecraft:light[level=15]
setblock 442 221 286 minecraft:light[level=15]
setblock 442 221 294 minecraft:light[level=15]
setblock 442 221 302 minecraft:light[level=15]
setblock 442 221 310 minecraft:light[level=15]
fill 446 221 275 449 228 275 minecraft:black_concrete
fill 447 221 317 450 228 317 minecraft:black_concrete
setblock 450 221 278 minecraft:light[level=15]
setblock 450 221 286 minecraft:light[level=15]
setblock 450 221 294 minecraft:light[level=15]
setblock 450 221 302 minecraft:light[level=15]
setblock 450 221 310 minecraft:light[level=15]
fill 456 221 275 459 228 275 minecraft:black_concrete
fill 457 221 285 464 221 285 minecraft:magenta_concrete
fill 457 221 317 460 228 317 minecraft:black_concrete
setblock 458 221 278 minecraft:light[level=15]
setblock 458 221 286 minecraft:light[level=15]
setblock 458 221 294 minecraft:light[level=15]
setblock 458 221 302 minecraft:light[level=15]
setblock 458 221 310 minecraft:light[level=15]
fill 465 221 276 465 228 279 minecraft:black_concrete
fill 465 221 286 465 228 289 minecraft:black_concrete
fill 465 221 296 465 228 299 minecraft:black_concrete
fill 465 221 306 465 228 309 minecraft:black_concrete
fill 465 221 316 465 228 316 minecraft:black_concrete
fill 424 222 278 424 224 278 minecraft:gray_concrete
fill 424 222 283 433 222 284 minecraft:gray_concrete
setblock 424 222 288 minecraft:gray_concrete
setblock 424 222 298 minecraft:gray_concrete
fill 424 222 308 424 224 308 minecraft:gray_concrete
fill 425 222 311 425 222 312 minecraft:black_concrete
fill 426 222 309 426 222 310 minecraft:black_concrete
fill 426 222 313 429 222 313 minecraft:black_concrete
setblock 426 222 316 minecraft:gray_concrete
fill 427 222 309 428 222 309 minecraft:black_concrete
setblock 429 222 310 minecraft:black_concrete
setblock 429 222 312 minecraft:black_concrete
setblock 430 222 276 minecraft:gray_concrete
fill 430 222 305 430 223 306 minecraft:lime_concrete
setblock 430 222 311 minecraft:black_concrete
fill 434 222 284 442 222 284 minecraft:gray_concrete
setblock 436 222 316 minecraft:gray_concrete
setblock 440 222 276 minecraft:gray_concrete
fill 443 222 284 449 222 284 minecraft:magenta_concrete
setblock 446 222 316 minecraft:gray_concrete
fill 448 222 285 455 222 285 minecraft:magenta_concrete
setblock 450 222 276 minecraft:gray_concrete
setblock 456 222 316 minecraft:gray_concrete
setblock 460 222 276 minecraft:gray_concrete
setblock 464 222 282 minecraft:gray_concrete
setblock 464 222 292 minecraft:gray_concrete
setblock 464 222 302 minecraft:gray_concrete
setblock 464 222 312 minecraft:gray_concrete
fill 424 223 283 426 223 284 minecraft:gray_concrete
fill 424 223 290 427 224 290 minecraft:gray_concrete
fill 424 223 296 430 224 296 minecraft:gray_concrete
fill 424 223 302 432 224 302 minecraft:gray_concrete
fill 424 223 314 445 223 314 minecraft:gray_concrete
fill 425 223 278 464 223 278 minecraft:gray_concrete
fill 425 223 308 463 223 308 minecraft:gray_concrete
setblock 426 223 285 minecraft:light[level=12]
setblock 426 223 292 minecraft:light[level=12]
setblock 426 223 299 minecraft:light[level=12]
setblock 426 223 306 minecraft:light[level=12]
setblock 426 223 313 minecraft:light[level=12]
fill 427 223 284 430 224 284 minecraft:gray_concrete
fill 431 223 284 441 223 284 minecraft:magenta_concrete
setblock 433 223 285 minecraft:light[level=12]
setblock 433 223 292 minecraft:light[level=12]
setblock 433 223 299 minecraft:light[level=12]
setblock 433 223 306 minecraft:light[level=12]
setblock 433 223 313 minecraft:light[level=12]
setblock 440 223 285 minecraft:light[level=12]
setblock 440 223 292 minecraft:light[level=12]
setblock 440 223 299 minecraft:light[level=12]
setblock 440 223 306 minecraft:light[level=12]
setblock 440 223 313 minecraft:light[level=12]
setblock 447 223 285 minecraft:light[level=12]
setblock 447 223 292 minecraft:light[level=12]
setblock 447 223 299 minecraft:light[level=12]
setblock 447 223 306 minecraft:light[level=12]
setblock 447 223 313 minecraft:light[level=12]
setblock 454 223 285 minecraft:light[level=12]
setblock 454 223 292 minecraft:light[level=12]
setblock 454 223 299 minecraft:light[level=12]
setblock 454 223 306 minecraft:light[level=12]
setblock 454 223 313 minecraft:light[level=12]
setblock 461 223 285 minecraft:light[level=12]
setblock 461 223 292 minecraft:light[level=12]
setblock 461 223 299 minecraft:light[level=12]
setblock 461 223 306 minecraft:light[level=12]
setblock 461 223 313 minecraft:light[level=12]
fill 424 224 284 426 224 284 minecraft:gray_concrete
fill 424 224 314 437 224 314 minecraft:gray_concrete
fill 425 224 278 428 224 278 minecraft:gray_concrete
fill 425 224 308 437 224 308 minecraft:gray_concrete
fill 428 224 290 462 224 290 minecraft:gray_concrete
fill 431 224 284 464 224 284 minecraft:gray_concrete
fill 431 224 296 436 224 296 minecraft:gray_concrete
fill 433 224 302 437 224 302 minecraft:gray_concrete
fill 438 224 301 438 224 316 minecraft:iron_block
fill 439 224 302 464 224 302 minecraft:gray_concrete
fill 439 224 308 455 224 308 minecraft:gray_concrete
fill 439 224 314 455 224 314 minecraft:gray_concrete
fill 444 224 296 464 224 296 minecraft:gray_concrete
fill 450 224 315 450 225 315 minecraft:iron_block
fill 456 224 304 456 224 316 minecraft:iron_block
fill 457 224 308 463 224 308 minecraft:gray_concrete
fill 457 224 314 464 224 314 minecraft:gray_concrete
fill 424 225 280 424 225 283 minecraft:gray_concrete
fill 424 225 290 424 225 293 minecraft:gray_concrete
fill 424 225 300 424 225 303 minecraft:gray_concrete
fill 424 225 310 424 225 313 minecraft:gray_concrete
fill 425 225 276 428 225 276 minecraft:gray_concrete
fill 426 225 277 426 225 316 minecraft:iron_block
fill 427 225 311 428 264 312 minecraft:gray_concrete
fill 428 225 316 431 225 316 minecraft:gray_concrete
fill 432 225 276 432 225 316 minecraft:iron_block
fill 435 225 276 438 225 276 minecraft:gray_concrete
fill 438 225 277 438 225 293 minecraft:iron_block
fill 438 225 300 438 225 305 minecraft:iron_block
fill 438 225 316 441 225 316 minecraft:gray_concrete
fill 444 225 276 444 225 316 minecraft:iron_block
fill 445 225 276 448 225 276 minecraft:gray_concrete
fill 448 225 316 451 225 316 minecraft:gray_concrete
fill 450 225 276 450 225 314 minecraft:iron_block
fill 455 225 276 458 225 276 minecraft:gray_concrete
fill 456 225 277 456 225 289 minecraft:iron_block
fill 456 225 290 464 225 290 minecraft:gray_concrete
fill 456 225 291 456 225 309 minecraft:iron_block
fill 458 225 316 461 225 316 minecraft:gray_concrete
fill 462 225 276 462 225 289 minecraft:iron_block
fill 462 225 291 462 225 316 minecraft:iron_block
fill 464 225 277 464 225 280 minecraft:gray_concrete
fill 464 225 287 464 225 289 minecraft:gray_concrete
fill 464 225 297 464 225 300 minecraft:gray_concrete
fill 464 225 307 464 225 310 minecraft:gray_concrete
fill 424 226 286 425 226 286 minecraft:cyan_stained_glass
fill 426 226 276 426 226 285 minecraft:iron_block
fill 426 226 311 426 260 312 minecraft:gray_concrete
fill 432 226 276 432 226 297 minecraft:iron_block
fill 438 226 276 438 226 278 minecraft:iron_block
fill 444 226 276 444 226 282 minecraft:iron_block
fill 450 226 276 450 226 279 minecraft:iron_block
fill 456 226 276 456 226 278 minecraft:iron_block
fill 462 226 276 462 226 283 minecraft:iron_block
setblock 424 228 278 minecraft:gray_concrete
setblock 424 228 288 minecraft:gray_concrete
setblock 424 228 298 minecraft:gray_concrete
setblock 424 228 308 minecraft:gray_concrete
setblock 426 228 316 minecraft:gray_concrete
setblock 430 228 276 minecraft:gray_concrete
setblock 436 228 316 minecraft:gray_concrete
setblock 440 228 276 minecraft:gray_concrete
setblock 446 228 316 minecraft:gray_concrete
setblock 450 228 276 minecraft:gray_concrete
setblock 456 228 316 minecraft:gray_concrete
setblock 460 228 276 minecraft:gray_concrete
setblock 464 228 282 minecraft:gray_concrete
setblock 464 228 292 minecraft:gray_concrete
setblock 464 228 302 minecraft:gray_concrete
setblock 464 228 312 minecraft:gray_concrete
fill 423 229 281 423 229 284 minecraft:sea_lantern
fill 423 229 291 423 229 294 minecraft:sea_lantern
fill 423 229 301 423 229 304 minecraft:sea_lantern
fill 423 229 311 423 229 314 minecraft:sea_lantern
fill 426 229 275 429 229 275 minecraft:sea_lantern
setblock 426 229 278 minecraft:light[level=15]
setblock 426 229 285 minecraft:light[level=12]
setblock 426 229 286 minecraft:light[level=15]
setblock 426 229 292 minecraft:light[level=12]
setblock 426 229 294 minecraft:light[level=15]
setblock 426 229 299 minecraft:light[level=12]
setblock 426 229 302 minecraft:light[level=15]
setblock 426 229 306 minecraft:light[level=12]
setblock 426 229 310 minecraft:light[level=15]
setblock 426 229 313 minecraft:light[level=12]
fill 427 229 317 430 229 317 minecraft:sea_lantern
fill 431 229 300 432 230 300 minecraft:magenta_concrete
setblock 433 229 278 minecraft:light[level=12]
setblock 433 229 285 minecraft:light[level=12]
setblock 433 229 292 minecraft:light[level=12]
setblock 433 229 299 minecraft:light[level=12]
setblock 433 229 306 minecraft:light[level=12]
setblock 433 229 313 minecraft:light[level=12]
setblock 434 229 278 minecraft:light[level=15]
setblock 434 229 286 minecraft:light[level=15]
setblock 434 229 294 minecraft:light[level=15]
setblock 434 229 302 minecraft:light[level=15]
setblock 434 229 310 minecraft:light[level=15]
fill 436 229 275 439 229 275 minecraft:sea_lantern
fill 437 229 317 440 229 317 minecraft:sea_lantern
setblock 440 229 278 minecraft:light[level=12]
setblock 440 229 285 minecraft:light[level=12]
setblock 440 229 292 minecraft:light[level=12]
setblock 440 229 299 minecraft:light[level=12]
setblock 440 229 306 minecraft:light[level=12]
setblock 440 229 313 minecraft:light[level=12]
setblock 442 229 278 minecraft:light[level=15]
setblock 442 229 286 minecraft:light[level=15]
setblock 442 229 294 minecraft:light[level=15]
setblock 442 229 302 minecraft:light[level=15]
setblock 442 229 310 minecraft:light[level=15]
fill 444 229 284 445 230 285 minecraft:light_blue_concrete
fill 446 229 275 449 229 275 minecraft:sea_lantern
setblock 447 229 278 minecraft:light[level=12]
setblock 447 229 285 minecraft:light[level=12]
setblock 447 229 292 minecraft:light[level=12]
setblock 447 229 299 minecraft:light[level=12]
setblock 447 229 306 minecraft:light[level=12]
setblock 447 229 313 minecraft:light[level=12]
fill 447 229 317 450 229 317 minecraft:sea_lantern
setblock 450 229 278 minecraft:light[level=15]
setblock 450 229 286 minecraft:light[level=15]
setblock 450 229 294 minecraft:light[level=15]
setblock 450 229 302 minecraft:light[level=15]
setblock 450 229 310 minecraft:light[level=15]
setblock 454 229 278 minecraft:light[level=12]
setblock 454 229 285 minecraft:light[level=12]
setblock 454 229 292 minecraft:light[level=12]
setblock 454 229 299 minecraft:light[level=12]
setblock 454 229 306 minecraft:light[level=12]
setblock 454 229 313 minecraft:light[level=12]
fill 456 229 275 459 229 275 minecraft:sea_lantern
fill 457 229 317 460 229 317 minecraft:sea_lantern
setblock 458 229 278 minecraft:light[level=15]
setblock 458 229 286 minecraft:light[level=15]
setblock 458 229 294 minecraft:light[level=15]
setblock 458 229 302 minecraft:light[level=15]
setblock 458 229 310 minecraft:light[level=15]
setblock 461 229 278 minecraft:light[level=12]
setblock 461 229 285 minecraft:light[level=12]
setblock 461 229 292 minecraft:light[level=12]
setblock 461 229 299 minecraft:light[level=12]
setblock 461 229 306 minecraft:light[level=12]
setblock 461 229 313 minecraft:light[level=12]
fill 465 229 276 465 229 279 minecraft:sea_lantern
fill 465 229 286 465 229 289 minecraft:sea_lantern
fill 465 229 296 465 229 299 minecraft:sea_lantern
fill 465 229 306 465 229 309 minecraft:sea_lantern
setblock 465 229 316 minecraft:sea_lantern
fill 423 230 281 423 237 284 minecraft:black_concrete
fill 423 230 291 423 237 294 minecraft:black_concrete
fill 423 230 301 423 237 304 minecraft:black_concrete
fill 423 230 311 423 237 314 minecraft:black_concrete
fill 425 230 311 425 230 312 minecraft:black_concrete
fill 426 230 275 429 237 275 minecraft:black_concrete
fill 426 230 309 426 230 310 minecraft:black_concrete
fill 426 230 313 429 230 313 minecraft:black_concrete
fill 427 230 309 428 230 309 minecraft:black_concrete
fill 427 230 317 430 237 317 minecraft:black_concrete
setblock 429 230 310 minecraft:black_concrete
setblock 429 230 312 minecraft:black_concrete
setblock 430 230 311 minecraft:black_concrete
fill 436 230 275 439 237 275 minecraft:black_concrete
fill 437 230 317 440 237 317 minecraft:black_concrete
fill 446 230 275 449 237 275 minecraft:black_concrete
fill 447 230 317 450 237 317 minecraft:black_concrete
fill 456 230 275 459 237 275 minecraft:black_concrete
fill 457 230 317 460 237 317 minecraft:black_concrete
fill 465 230 276 465 237 279 minecraft:black_concrete
fill 465 230 286 465 237 289 minecraft:black_concrete
fill 465 230 296 465 237 299 minecraft:black_concrete
fill 465 230 306 465 237 309 minecraft:black_concrete
fill 465 230 316 465 237 316 minecraft:black_concrete
fill 457 231 276 457 232 278 minecraft:iron_block
fill 433 232 313 433 233 315 minecraft:iron_block
setblock 424 234 278 minecraft:gray_concrete
fill 424 234 280 424 234 283 minecraft:gray_concrete
setblock 424 234 288 minecraft:gray_concrete
fill 424 234 290 424 234 293 minecraft:gray_concrete
setblock 424 234 298 minecraft:gray_concrete
fill 424 234 300 424 234 303 minecraft:gray_concrete
setblock 424 234 308 minecraft:gray_concrete
fill 424 234 310 424 234 313 minecraft:gray_concrete
fill 425 234 276 428 234 276 minecraft:gray_concrete
setblock 426 234 316 minecraft:gray_concrete
fill 428 234 316 431 234 316 minecraft:gray_concrete
setblock 430 234 276 minecraft:gray_concrete
fill 435 234 276 438 234 276 minecraft:gray_concrete
setblock 436 234 316 minecraft:gray_concrete
fill 438 234 316 441 234 316 minecraft:gray_concrete
setblock 440 234 276 minecraft:gray_concrete
fill 445 234 276 448 234 276 minecraft:gray_concrete
setblock 446 234 316 minecraft:gray_concrete
fill 448 234 316 451 234 316 minecraft:gray_concrete
setblock 450 234 276 minecraft:gray_concrete
fill 455 234 276 458 234 276 minecraft:gray_concrete
setblock 456 234 316 minecraft:gray_concrete
fill 458 234 316 461 234 316 minecraft:gray_concrete
setblock 460 234 276 minecraft:gray_concrete
fill 464 234 277 464 234 280 minecraft:gray_concrete
setblock 464 234 282 minecraft:gray_concrete
fill 464 234 287 464 234 290 minecraft:gray_concrete
setblock 464 234 292 minecraft:gray_concrete
fill 464 234 297 464 234 300 minecraft:gray_concrete
setblock 464 234 302 minecraft:gray_concrete
fill 464 234 307 464 234 310 minecraft:gray_concrete
setblock 464 234 312 minecraft:gray_concrete
setblock 426 235 278 minecraft:light[level=12]
setblock 426 235 285 minecraft:light[level=12]
setblock 426 235 292 minecraft:light[level=12]
setblock 426 235 299 minecraft:light[level=12]
setblock 426 235 306 minecraft:light[level=12]
setblock 426 235 313 minecraft:light[level=12]
setblock 433 235 278 minecraft:light[level=12]
setblock 433 235 285 minecraft:light[level=12]
setblock 433 235 292 minecraft:light[level=12]
setblock 433 235 299 minecraft:light[level=12]
setblock 433 235 306 minecraft:light[level=12]
setblock 433 235 313 minecraft:light[level=12]
setblock 440 235 278 minecraft:light[level=12]
setblock 440 235 285 minecraft:light[level=12]
setblock 440 235 292 minecraft:light[level=12]
setblock 440 235 299 minecraft:light[level=12]
setblock 440 235 306 minecraft:light[level=12]
setblock 440 235 313 minecraft:light[level=12]
setblock 447 235 278 minecraft:light[level=12]
setblock 447 235 285 minecraft:light[level=12]
setblock 447 235 292 minecraft:light[level=12]
setblock 447 235 299 minecraft:light[level=12]
setblock 447 235 306 minecraft:light[level=12]
setblock 447 235 313 minecraft:light[level=12]
fill 453 235 313 455 235 315 minecraft:black_concrete
setblock 454 235 278 minecraft:light[level=12]
setblock 454 235 285 minecraft:light[level=12]
setblock 454 235 292 minecraft:light[level=12]
setblock 454 235 299 minecraft:light[level=12]
setblock 454 235 306 minecraft:light[level=12]
setblock 461 235 278 minecraft:light[level=12]
setblock 461 235 285 minecraft:light[level=12]
setblock 461 235 292 minecraft:light[level=12]
setblock 461 235 299 minecraft:light[level=12]
setblock 461 235 306 minecraft:light[level=12]
setblock 461 235 313 minecraft:light[level=12]
fill 436 236 285 436 237 285 minecraft:lime_concrete
fill 453 236 313 453 236 315 minecraft:black_concrete
fill 454 236 313 455 236 313 minecraft:black_concrete
fill 454 236 314 454 238 314 minecraft:gray_concrete
fill 454 236 315 455 236 315 minecraft:black_concrete
setblock 455 236 314 minecraft:black_concrete
setblock 426 237 278 minecraft:light[level=15]
setblock 426 237 286 minecraft:light[level=15]
setblock 426 237 294 minecraft:light[level=15]
setblock 426 237 302 minecraft:light[level=15]
setblock 426 237 310 minecraft:light[level=15]
setblock 434 237 278 minecraft:light[level=15]
setblock 434 237 286 minecraft:light[level=15]
setblock 434 237 294 minecraft:light[level=15]
setblock 434 237 302 minecraft:light[level=15]
setblock 434 237 310 minecraft:light[level=15]
setblock 442 237 278 minecraft:light[level=15]
setblock 442 237 286 minecraft:light[level=15]
setblock 442 237 294 minecraft:light[level=15]
setblock 442 237 302 minecraft:light[level=15]
setblock 442 237 310 minecraft:light[level=15]
setblock 450 237 278 minecraft:light[level=15]
setblock 450 237 286 minecraft:light[level=15]
setblock 450 237 294 minecraft:light[level=15]
setblock 450 237 302 minecraft:light[level=15]
setblock 450 237 310 minecraft:light[level=15]
fill 453 237 313 453 239 313 minecraft:black_concrete
setblock 453 237 314 minecraft:gray_concrete
fill 453 237 315 453 239 315 minecraft:black_concrete
setblock 454 237 313 minecraft:gray_concrete
setblock 454 237 315 minecraft:gray_concrete
fill 455 237 313 455 239 313 minecraft:black_concrete
setblock 455 237 314 minecraft:gray_concrete
fill 455 237 315 455 239 315 minecraft:black_concrete
setblock 458 237 278 minecraft:light[level=15]
setblock 458 237 286 minecraft:light[level=15]
setblock 458 237 294 minecraft:light[level=15]
setblock 458 237 302 minecraft:light[level=15]
setblock 458 237 310 minecraft:light[level=15]
fill 461 237 290 463 238 290 minecraft:iron_block
fill 423 238 281 423 238 284 minecraft:sea_lantern
fill 423 238 291 423 238 294 minecraft:sea_lantern
fill 423 238 301 423 238 304 minecraft:sea_lantern
fill 423 238 311 423 238 314 minecraft:sea_lantern
fill 425 238 311 425 238 312 minecraft:black_concrete
fill 426 238 275 429 238 275 minecraft:sea_lantern
fill 426 238 309 426 238 310 minecraft:black_concrete
fill 426 238 313 429 238 313 minecraft:black_concrete
fill 427 238 309 428 238 309 minecraft:black_concrete
fill 427 238 317 430 238 317 minecraft:sea_lantern
setblock 429 238 310 minecraft:black_concrete
setblock 429 238 312 minecraft:black_concrete
setblock 430 238 311 minecraft:black_concrete
fill 436 238 275 439 238 275 minecraft:sea_lantern
fill 437 238 317 440 238 317 minecraft:sea_lantern
fill 446 238 275 449 238 275 minecraft:sea_lantern
fill 447 238 317 450 238 317 minecraft:sea_lantern
fill 453 238 314 453 239 314 minecraft:black_concrete
fill 454 238 313 454 239 313 minecraft:black_concrete
fill 454 238 315 454 239 315 minecraft:black_concrete
fill 455 238 314 455 239 314 minecraft:black_concrete
fill 456 238 275 459 238 275 minecraft:sea_lantern
fill 457 238 317 460 238 317 minecraft:sea_lantern
fill 465 238 276 465 238 279 minecraft:sea_lantern
fill 465 238 286 465 238 289 minecraft:sea_lantern
fill 465 238 296 465 238 299 minecraft:sea_lantern
fill 465 238 306 465 238 309 minecraft:sea_lantern
setblock 465 238 316 minecraft:sea_lantern
fill 423 239 281 423 246 284 minecraft:black_concrete
fill 423 239 291 423 246 294 minecraft:black_concrete
fill 423 239 301 423 246 304 minecraft:black_concrete
fill 423 239 311 423 246 314 minecraft:black_concrete
fill 426 239 275 429 246 275 minecraft:black_concrete
fill 427 239 317 430 246 317 minecraft:black_concrete
fill 436 239 275 439 246 275 minecraft:black_concrete
fill 437 239 317 440 246 317 minecraft:black_concrete
fill 446 239 275 449 246 275 minecraft:black_concrete
fill 447 239 317 450 246 317 minecraft:black_concrete
setblock 454 239 314 minecraft:black_concrete
fill 456 239 275 459 246 275 minecraft:black_concrete
fill 457 239 317 460 246 317 minecraft:black_concrete
fill 465 239 276 465 246 279 minecraft:black_concrete
fill 465 239 286 465 246 289 minecraft:black_concrete
fill 465 239 296 465 246 299 minecraft:black_concrete
fill 465 239 306 465 246 309 minecraft:black_concrete
fill 465 239 316 465 246 316 minecraft:black_concrete
setblock 424 240 278 minecraft:gray_concrete
setblock 424 240 288 minecraft:gray_concrete
setblock 424 240 298 minecraft:gray_concrete
setblock 424 240 308 minecraft:gray_concrete
setblock 426 240 316 minecraft:gray_concrete
setblock 430 240 276 minecraft:gray_concrete
setblock 436 240 316 minecraft:gray_concrete
setblock 440 240 276 minecraft:gray_concrete
setblock 446 240 316 minecraft:gray_concrete
setblock 450 240 276 minecraft:gray_concrete
setblock 456 240 316 minecraft:gray_concrete
setblock 460 240 276 minecraft:gray_concrete
setblock 464 240 282 minecraft:gray_concrete
setblock 464 240 292 minecraft:gray_concrete
setblock 464 240 302 minecraft:gray_concrete
setblock 464 240 312 minecraft:gray_concrete
setblock 426 241 278 minecraft:light[level=12]
setblock 426 241 285 minecraft:light[level=12]
setblock 426 241 292 minecraft:light[level=12]
setblock 426 241 299 minecraft:light[level=12]
setblock 426 241 306 minecraft:light[level=12]
setblock 426 241 313 minecraft:light[level=12]
setblock 433 241 278 minecraft:light[level=12]
setblock 433 241 285 minecraft:light[level=12]
setblock 433 241 292 minecraft:light[level=12]
setblock 433 241 299 minecraft:light[level=12]
setblock 433 241 306 minecraft:light[level=12]
setblock 433 241 313 minecraft:light[level=12]
setblock 440 241 278 minecraft:light[level=12]
setblock 440 241 285 minecraft:light[level=12]
setblock 440 241 292 minecraft:light[level=12]
setblock 440 241 299 minecraft:light[level=12]
setblock 440 241 306 minecraft:light[level=12]
setblock 440 241 313 minecraft:light[level=12]
setblock 447 241 278 minecraft:light[level=12]
setblock 447 241 285 minecraft:light[level=12]
setblock 447 241 292 minecraft:light[level=12]
setblock 447 241 299 minecraft:light[level=12]
setblock 447 241 306 minecraft:light[level=12]
setblock 447 241 313 minecraft:light[level=12]
setblock 454 241 278 minecraft:light[level=12]
setblock 454 241 285 minecraft:light[level=12]
setblock 454 241 292 minecraft:light[level=12]
setblock 454 241 299 minecraft:light[level=12]
setblock 454 241 306 minecraft:light[level=12]
setblock 454 241 313 minecraft:light[level=12]
fill 457 241 302 458 242 303 minecraft:yellow_concrete
setblock 461 241 278 minecraft:light[level=12]
setblock 461 241 285 minecraft:light[level=12]
setblock 461 241 292 minecraft:light[level=12]
setblock 461 241 299 minecraft:light[level=12]
setblock 461 241 306 minecraft:light[level=12]
setblock 461 241 313 minecraft:light[level=12]
fill 462 242 295 462 253 295 minecraft:purple_wool
fill 424 243 280 424 243 283 minecraft:gray_concrete
fill 424 243 290 424 243 293 minecraft:gray_concrete
fill 424 243 300 424 243 303 minecraft:gray_concrete
fill 424 243 310 424 243 313 minecraft:gray_concrete
fill 425 243 276 428 243 276 minecraft:gray_concrete
fill 428 243 316 431 243 316 minecraft:gray_concrete
fill 435 243 276 438 243 276 minecraft:gray_concrete
fill 438 243 316 441 243 316 minecraft:gray_concrete
fill 445 243 276 448 243 276 minecraft:gray_concrete
fill 448 243 316 451 243 316 minecraft:gray_concrete
fill 455 243 276 458 243 276 minecraft:gray_concrete
fill 458 243 316 461 243 316 minecraft:gray_concrete
fill 462 243 293 462 253 294 minecraft:purple_wool
fill 462 243 296 462 253 297 minecraft:purple_wool
fill 464 243 277 464 243 280 minecraft:gray_concrete
fill 464 243 287 464 243 290 minecraft:gray_concrete
fill 464 243 297 464 243 300 minecraft:gray_concrete
fill 464 243 307 464 243 310 minecraft:gray_concrete
setblock 426 245 278 minecraft:light[level=15]
setblock 426 245 286 minecraft:light[level=15]
setblock 426 245 294 minecraft:light[level=15]
setblock 426 245 302 minecraft:light[level=15]
setblock 426 245 310 minecraft:light[level=15]
setblock 434 245 278 minecraft:light[level=15]
setblock 434 245 286 minecraft:light[level=15]
setblock 434 245 294 minecraft:light[level=15]
setblock 434 245 302 minecraft:light[level=15]
setblock 434 245 310 minecraft:light[level=15]
setblock 442 245 278 minecraft:light[level=15]
setblock 442 245 286 minecraft:light[level=15]
setblock 442 245 294 minecraft:light[level=15]
setblock 442 245 302 minecraft:light[level=15]
setblock 442 245 310 minecraft:light[level=15]
setblock 450 245 278 minecraft:light[level=15]
setblock 450 245 286 minecraft:light[level=15]
setblock 450 245 294 minecraft:light[level=15]
setblock 450 245 302 minecraft:light[level=15]
setblock 450 245 310 minecraft:light[level=15]
setblock 458 245 278 minecraft:light[level=15]
setblock 458 245 286 minecraft:light[level=15]
setblock 458 245 294 minecraft:light[level=15]
setblock 458 245 302 minecraft:light[level=15]
setblock 458 245 310 minecraft:light[level=15]
setblock 424 246 278 minecraft:gray_concrete
setblock 424 246 288 minecraft:gray_concrete
setblock 424 246 298 minecraft:gray_concrete
setblock 424 246 308 minecraft:gray_concrete
fill 425 246 311 425 246 312 minecraft:black_concrete
fill 426 246 309 426 246 310 minecraft:black_concrete
fill 426 246 313 429 246 313 minecraft:black_concrete
setblock 426 246 316 minecraft:gray_concrete
fill 427 246 309 428 246 309 minecraft:black_concrete
setblock 429 246 310 minecraft:black_concrete
setblock 429 246 312 minecraft:black_concrete
setblock 430 246 276 minecraft:gray_concrete
setblock 430 246 311 minecraft:black_concrete
fill 434 246 277 434 258 277 minecraft:purple_wool
setblock 436 246 316 minecraft:gray_concrete
setblock 440 246 276 minecraft:gray_concrete
setblock 446 246 316 minecraft:gray_concrete
setblock 450 246 276 minecraft:gray_concrete
setblock 456 246 316 minecraft:gray_concrete
setblock 460 246 276 minecraft:gray_concrete
setblock 464 246 282 minecraft:gray_concrete
setblock 464 246 292 minecraft:gray_concrete
setblock 464 246 302 minecraft:gray_concrete
setblock 464 246 312 minecraft:gray_concrete
fill 423 247 281 423 247 284 minecraft:sea_lantern
fill 423 247 291 423 247 294 minecraft:sea_lantern
fill 423 247 301 423 247 304 minecraft:sea_lantern
fill 423 247 311 423 247 314 minecraft:sea_lantern
fill 426 247 275 429 247 275 minecraft:sea_lantern
setblock 426 247 278 minecraft:light[level=12]
setblock 426 247 285 minecraft:light[level=12]
setblock 426 247 292 minecraft:light[level=12]
setblock 426 247 299 minecraft:light[level=12]
setblock 426 247 306 minecraft:light[level=12]
setblock 426 247 313 minecraft:light[level=12]
fill 427 247 317 430 247 317 minecraft:sea_lantern
fill 432 247 277 433 258 277 minecraft:purple_wool
setblock 433 247 278 minecraft:light[level=12]
setblock 433 247 285 minecraft:light[level=12]
setblock 433 247 292 minecraft:light[level=12]
setblock 433 247 299 minecraft:light[level=12]
setblock 433 247 306 minecraft:light[level=12]
setblock 433 247 313 minecraft:light[level=12]
fill 435 247 277 436 258 277 minecraft:purple_wool
fill 436 247 275 439 247 275 minecraft:sea_lantern
fill 437 247 317 440 247 317 minecraft:sea_lantern
setblock 440 247 278 minecraft:light[level=12]
setblock 440 247 285 minecraft:light[level=12]
setblock 440 247 292 minecraft:light[level=12]
setblock 440 247 299 minecraft:light[level=12]
setblock 440 247 306 minecraft:light[level=12]
setblock 440 247 313 minecraft:light[level=12]
fill 446 247 275 449 247 275 minecraft:sea_lantern
setblock 447 247 278 minecraft:light[level=12]
setblock 447 247 285 minecraft:light[level=12]
setblock 447 247 292 minecraft:light[level=12]
setblock 447 247 299 minecraft:light[level=12]
setblock 447 247 306 minecraft:light[level=12]
setblock 447 247 313 minecraft:light[level=12]
fill 447 247 317 450 247 317 minecraft:sea_lantern
setblock 454 247 278 minecraft:light[level=12]
setblock 454 247 285 minecraft:light[level=12]
setblock 454 247 292 minecraft:light[level=12]
setblock 454 247 299 minecraft:light[level=12]
setblock 454 247 306 minecraft:light[level=12]
setblock 454 247 313 minecraft:light[level=12]
fill 456 247 275 459 247 275 minecraft:sea_lantern
fill 457 247 317 460 247 317 minecraft:sea_lantern
setblock 461 247 278 minecraft:light[level=12]
setblock 461 247 285 minecraft:light[level=12]
setblock 461 247 292 minecraft:light[level=12]
setblock 461 247 299 minecraft:light[level=12]
setblock 461 247 306 minecraft:light[level=12]
setblock 461 247 313 minecraft:light[level=12]
fill 465 247 276 465 247 279 minecraft:sea_lantern
fill 465 247 286 465 247 289 minecraft:sea_lantern
fill 465 247 296 465 247 299 minecraft:sea_lantern
fill 465 247 306 465 247 309 minecraft:sea_lantern
setblock 465 247 316 minecraft:sea_lantern
fill 423 248 281 423 255 284 minecraft:black_concrete
fill 423 248 291 423 255 294 minecraft:black_concrete
fill 423 248 301 423 255 304 minecraft:black_concrete
fill 423 248 311 423 255 314 minecraft:black_concrete
fill 426 248 275 429 255 275 minecraft:black_concrete
fill 427 248 317 430 255 317 minecraft:black_concrete
fill 436 248 275 439 255 275 minecraft:black_concrete
fill 437 248 317 440 255 317 minecraft:black_concrete
fill 446 248 275 449 255 275 minecraft:black_concrete
fill 447 248 317 450 255 317 minecraft:black_concrete
fill 456 248 275 459 255 275 minecraft:black_concrete
fill 457 248 317 460 255 317 minecraft:black_concrete
fill 465 248 276 465 255 279 minecraft:black_concrete
fill 465 248 286 465 255 289 minecraft:black_concrete
fill 465 248 296 465 255 299 minecraft:black_concrete
fill 465 248 306 465 255 309 minecraft:black_concrete
fill 465 248 316 465 255 316 minecraft:black_concrete
fill 459 250 300 459 251 301 minecraft:yellow_concrete
fill 460 250 301 460 251 301 minecraft:yellow_concrete
setblock 424 252 278 minecraft:gray_concrete
fill 424 252 280 424 252 283 minecraft:gray_concrete
setblock 424 252 288 minecraft:gray_concrete
fill 424 252 290 424 252 293 minecraft:gray_concrete
setblock 424 252 298 minecraft:gray_concrete
fill 424 252 300 424 252 303 minecraft:gray_concrete
setblock 424 252 308 minecraft:gray_concrete
fill 424 252 310 424 252 313 minecraft:gray_concrete
fill 425 252 276 428 252 276 minecraft:gray_concrete
setblock 426 252 316 minecraft:gray_concrete
fill 428 252 316 431 252 316 minecraft:gray_concrete
setblock 430 252 276 minecraft:gray_concrete
fill 435 252 276 438 252 276 minecraft:gray_concrete
setblock 436 252 316 minecraft:gray_concrete
fill 438 252 316 441 252 316 minecraft:gray_concrete
setblock 440 252 276 minecraft:gray_concrete
fill 445 252 276 448 252 276 minecraft:gray_concrete
setblock 446 252 316 minecraft:gray_concrete
fill 448 252 316 451 252 316 minecraft:gray_concrete
setblock 450 252 276 minecraft:gray_concrete
fill 452 252 313 452 253 315 minecraft:iron_block
fill 455 252 276 458 252 276 minecraft:gray_concrete
setblock 456 252 316 minecraft:gray_concrete
fill 458 252 316 461 252 316 minecraft:gray_concrete
setblock 460 252 276 minecraft:gray_concrete
fill 464 252 277 464 252 280 minecraft:gray_concrete
setblock 464 252 282 minecraft:gray_concrete
fill 464 252 287 464 252 290 minecraft:gray_concrete
setblock 464 252 292 minecraft:gray_concrete
fill 464 252 297 464 252 300 minecraft:gray_concrete
setblock 464 252 302 minecraft:gray_concrete
fill 464 252 307 464 252 310 minecraft:gray_concrete
setblock 464 252 312 minecraft:gray_concrete
setblock 426 253 278 minecraft:light[level=15]
setblock 426 253 285 minecraft:light[level=12]
setblock 426 253 286 minecraft:light[level=15]
setblock 426 253 292 minecraft:light[level=12]
setblock 426 253 294 minecraft:light[level=15]
setblock 426 253 299 minecraft:light[level=12]
setblock 426 253 302 minecraft:light[level=15]
setblock 426 253 306 minecraft:light[level=12]
setblock 426 253 310 minecraft:light[level=15]
setblock 426 253 313 minecraft:light[level=12]
setblock 433 253 278 minecraft:light[level=12]
setblock 433 253 285 minecraft:light[level=12]
setblock 433 253 292 minecraft:light[level=12]
setblock 433 253 299 minecraft:light[level=12]
setblock 433 253 306 minecraft:light[level=12]
setblock 433 253 313 minecraft:light[level=12]
setblock 434 253 278 minecraft:light[level=15]
setblock 434 253 286 minecraft:light[level=15]
setblock 434 253 294 minecraft:light[level=15]
setblock 434 253 302 minecraft:light[level=15]
setblock 434 253 310 minecraft:light[level=15]
setblock 440 253 278 minecraft:light[level=12]
setblock 440 253 285 minecraft:light[level=12]
setblock 440 253 292 minecraft:light[level=12]
setblock 440 253 299 minecraft:light[level=12]
setblock 440 253 306 minecraft:light[level=12]
setblock 440 253 313 minecraft:light[level=12]
setblock 442 253 278 minecraft:light[level=15]
setblock 442 253 286 minecraft:light[level=15]
setblock 442 253 294 minecraft:light[level=15]
setblock 442 253 302 minecraft:light[level=15]
setblock 442 253 310 minecraft:light[level=15]
setblock 447 253 278 minecraft:light[level=12]
setblock 447 253 285 minecraft:light[level=12]
setblock 447 253 292 minecraft:light[level=12]
setblock 447 253 299 minecraft:light[level=12]
setblock 447 253 306 minecraft:light[level=12]
setblock 447 253 313 minecraft:light[level=12]
setblock 450 253 278 minecraft:light[level=15]
setblock 450 253 286 minecraft:light[level=15]
setblock 450 253 294 minecraft:light[level=15]
setblock 450 253 302 minecraft:light[level=15]
setblock 450 253 310 minecraft:light[level=15]
fill 454 253 277 454 263 277 minecraft:purple_wool
setblock 454 253 278 minecraft:light[level=12]
setblock 454 253 285 minecraft:light[level=12]
setblock 454 253 292 minecraft:light[level=12]
setblock 454 253 299 minecraft:light[level=12]
setblock 454 253 306 minecraft:light[level=12]
setblock 454 253 313 minecraft:light[level=12]
setblock 458 253 278 minecraft:light[level=15]
setblock 458 253 286 minecraft:light[level=15]
setblock 458 253 294 minecraft:light[level=15]
setblock 458 253 302 minecraft:light[level=15]
setblock 458 253 310 minecraft:light[level=15]
setblock 461 253 278 minecraft:light[level=12]
setblock 461 253 285 minecraft:light[level=12]
setblock 461 253 292 minecraft:light[level=12]
setblock 461 253 299 minecraft:light[level=12]
setblock 461 253 306 minecraft:light[level=12]
setblock 461 253 313 minecraft:light[level=12]
fill 425 254 311 425 254 312 minecraft:black_concrete
fill 426 254 309 426 254 310 minecraft:black_concrete
fill 426 254 313 429 254 313 minecraft:black_concrete
fill 427 254 309 428 254 309 minecraft:black_concrete
setblock 429 254 310 minecraft:black_concrete
setblock 429 254 312 minecraft:black_concrete
setblock 430 254 311 minecraft:black_concrete
fill 452 254 277 453 263 277 minecraft:purple_wool
fill 455 254 277 456 259 277 minecraft:purple_wool
fill 462 254 292 462 255 298 minecraft:iron_block
fill 423 256 281 423 256 284 minecraft:sea_lantern
fill 423 256 291 423 256 294 minecraft:sea_lantern
fill 423 256 301 423 256 304 minecraft:sea_lantern
fill 423 256 311 423 256 314 minecraft:sea_lantern
fill 426 256 275 429 256 275 minecraft:sea_lantern
fill 427 256 317 430 256 317 minecraft:sea_lantern
fill 436 256 275 439 256 275 minecraft:sea_lantern
fill 437 256 317 440 256 317 minecraft:sea_lantern
fill 446 256 275 449 256 275 minecraft:sea_lantern
fill 447 256 317 450 256 317 minecraft:sea_lantern
fill 456 256 275 459 256 275 minecraft:sea_lantern
fill 457 256 317 460 256 317 minecraft:sea_lantern
fill 465 256 276 465 256 279 minecraft:sea_lantern
fill 465 256 286 465 256 289 minecraft:sea_lantern
fill 465 256 296 465 256 299 minecraft:sea_lantern
fill 465 256 306 465 256 309 minecraft:sea_lantern
setblock 465 256 316 minecraft:sea_lantern
fill 423 257 281 423 282 284 minecraft:black_concrete
fill 423 257 291 423 282 294 minecraft:black_concrete
fill 423 257 301 423 282 304 minecraft:black_concrete
fill 423 257 311 423 282 314 minecraft:black_concrete
fill 426 257 275 429 282 275 minecraft:black_concrete
fill 427 257 317 430 282 317 minecraft:black_concrete
fill 436 257 275 439 282 275 minecraft:black_concrete
fill 437 257 317 440 282 317 minecraft:black_concrete
fill 446 257 275 449 282 275 minecraft:black_concrete
fill 447 257 317 450 282 317 minecraft:black_concrete
fill 456 257 275 459 282 275 minecraft:black_concrete
fill 457 257 317 460 282 317 minecraft:black_concrete
fill 465 257 276 465 282 279 minecraft:black_concrete
fill 465 257 286 465 282 289 minecraft:black_concrete
fill 465 257 296 465 282 299 minecraft:black_concrete
fill 465 257 306 465 282 309 minecraft:black_concrete
fill 465 257 316 465 282 316 minecraft:black_concrete
fill 424 258 278 427 259 278 minecraft:gray_concrete
fill 424 258 284 463 259 284 minecraft:gray_concrete
setblock 424 258 288 minecraft:gray_concrete
fill 424 258 290 464 258 290 minecraft:gray_concrete
fill 424 258 296 438 258 296 minecraft:gray_concrete
setblock 424 258 298 minecraft:gray_concrete
fill 424 258 302 427 259 302 minecraft:gray_concrete
fill 424 258 308 464 258 308 minecraft:gray_concrete
fill 424 258 314 464 258 314 minecraft:gray_concrete
setblock 426 258 316 minecraft:gray_concrete
setblock 430 258 276 minecraft:gray_concrete
setblock 436 258 316 minecraft:gray_concrete
setblock 440 258 276 minecraft:gray_concrete
schedule function dropper:buildpart/69_3 1t
