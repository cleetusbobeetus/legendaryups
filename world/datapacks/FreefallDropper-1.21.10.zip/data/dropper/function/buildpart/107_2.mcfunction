setblock 545 213 458 minecraft:black_concrete
setblock 546 213 418 minecraft:black_concrete
setblock 546 213 458 minecraft:deepslate_tiles
setblock 547 213 458 minecraft:black_concrete
fill 549 213 416 550 215 416 minecraft:black_concrete
setblock 551 213 416 minecraft:deepslate_tiles
fill 552 213 416 552 215 416 minecraft:black_concrete
fill 553 213 416 553 214 416 minecraft:deepslate_tiles
fill 554 213 416 554 215 416 minecraft:black_concrete
fill 558 213 447 558 228 447 minecraft:black_concrete
fill 559 213 419 559 216 419 minecraft:black_concrete
fill 559 213 427 559 215 428 minecraft:black_concrete
setblock 559 213 429 minecraft:deepslate_tiles
fill 559 213 430 559 215 430 minecraft:black_concrete
fill 559 213 441 559 213 442 minecraft:deepslate_tiles
setblock 559 213 445 minecraft:deepslate_tiles
setblock 559 213 447 minecraft:deepslate_tiles
fill 559 213 451 559 215 451 minecraft:black_concrete
setblock 559 213 452 minecraft:deepslate_tiles
setblock 559 213 453 minecraft:black_concrete
fill 517 214 416 517 215 418 minecraft:black_concrete
setblock 517 214 419 minecraft:deepslate_tiles
fill 517 214 420 517 215 421 minecraft:black_concrete
setblock 517 214 422 minecraft:deepslate_tiles
fill 517 214 423 517 215 426 minecraft:black_concrete
setblock 517 214 433 minecraft:deepslate_tiles
fill 517 214 434 517 215 435 minecraft:black_concrete
setblock 517 214 436 minecraft:deepslate_tiles
fill 517 214 437 517 215 438 minecraft:black_concrete
fill 517 214 443 517 215 444 minecraft:black_concrete
setblock 517 214 445 minecraft:deepslate_tiles
fill 517 214 446 517 215 446 minecraft:black_concrete
fill 517 214 450 517 216 450 minecraft:black_concrete
fill 518 214 448 518 230 449 minecraft:black_concrete
fill 518 214 458 518 215 458 minecraft:black_concrete
fill 519 214 445 519 226 445 minecraft:black_concrete
fill 521 214 458 522 215 458 minecraft:black_concrete
fill 523 214 420 524 214 420 minecraft:black_concrete
setblock 523 214 458 minecraft:deepslate_tiles
fill 528 214 416 531 215 416 minecraft:black_concrete
setblock 529 214 458 minecraft:deepslate_tiles
fill 530 214 458 531 215 458 minecraft:black_concrete
setblock 532 214 416 minecraft:deepslate_tiles
fill 533 214 458 533 215 458 minecraft:black_concrete
fill 534 214 416 535 214 416 minecraft:deepslate_tiles
setblock 535 214 458 minecraft:deepslate_tiles
fill 536 214 416 538 215 416 minecraft:black_concrete
fill 539 214 457 541 214 457 minecraft:black_concrete
fill 540 214 417 541 214 417 minecraft:black_concrete
fill 540 214 458 540 215 458 minecraft:black_concrete
fill 544 214 457 544 214 458 minecraft:black_concrete
setblock 545 214 458 minecraft:deepslate_tiles
fill 546 214 458 546 215 458 minecraft:black_concrete
setblock 547 214 458 minecraft:deepslate_tiles
fill 551 214 416 551 215 416 minecraft:black_concrete
setblock 555 214 458 minecraft:deepslate_tiles
fill 556 214 458 559 215 458 minecraft:black_concrete
fill 557 214 417 557 215 417 minecraft:black_concrete
fill 557 214 428 557 230 428 minecraft:black_concrete
fill 559 214 417 559 216 417 minecraft:black_concrete
setblock 559 214 418 minecraft:deepslate_tiles
fill 559 214 422 559 215 422 minecraft:black_concrete
fill 559 214 429 559 215 429 minecraft:black_concrete
setblock 559 214 431 minecraft:deepslate_tiles
fill 559 214 432 559 215 432 minecraft:black_concrete
fill 559 214 441 559 215 442 minecraft:black_concrete
setblock 559 214 444 minecraft:deepslate_tiles
fill 559 214 445 559 215 445 minecraft:black_concrete
fill 559 214 447 559 215 447 minecraft:black_concrete
fill 559 214 449 559 216 449 minecraft:black_concrete
fill 559 214 452 559 215 452 minecraft:black_concrete
setblock 559 214 453 minecraft:deepslate_tiles
setblock 517 215 419 minecraft:black_concrete
setblock 517 215 422 minecraft:black_concrete
setblock 517 215 431 minecraft:black_concrete
setblock 517 215 433 minecraft:black_concrete
setblock 517 215 436 minecraft:black_concrete
setblock 517 215 445 minecraft:black_concrete
fill 518 215 442 518 216 442 minecraft:black_concrete
fill 518 215 450 518 230 450 minecraft:black_concrete
fill 519 215 446 519 227 446 minecraft:black_concrete
setblock 521 215 421 minecraft:black_concrete
setblock 523 215 458 minecraft:black_concrete
setblock 526 215 458 minecraft:black_concrete
fill 528 215 458 529 215 458 minecraft:black_concrete
setblock 532 215 416 minecraft:black_concrete
fill 534 215 416 535 215 416 minecraft:black_concrete
fill 535 215 458 535 216 458 minecraft:black_concrete
setblock 541 215 417 minecraft:black_concrete
setblock 541 215 457 minecraft:black_concrete
fill 544 215 458 545 215 458 minecraft:black_concrete
setblock 545 215 416 minecraft:black_concrete
setblock 547 215 458 minecraft:black_concrete
setblock 553 215 416 minecraft:black_concrete
fill 553 215 425 553 230 425 minecraft:white_wool
setblock 555 215 458 minecraft:black_concrete
fill 557 215 420 557 229 422 minecraft:black_concrete
setblock 559 215 418 minecraft:black_concrete
setblock 559 215 431 minecraft:black_concrete
setblock 559 215 444 minecraft:black_concrete
fill 559 215 453 559 216 453 minecraft:black_concrete
fill 517 216 416 517 217 419 minecraft:deepslate_tiles
setblock 517 216 420 minecraft:black_concrete
fill 517 216 421 517 307 422 minecraft:deepslate_tiles
setblock 517 216 423 minecraft:black_concrete
fill 517 216 424 517 216 449 minecraft:deepslate_tiles
fill 517 216 451 517 217 458 minecraft:deepslate_tiles
fill 518 216 416 529 216 416 minecraft:deepslate_tiles
fill 518 216 451 518 230 452 minecraft:black_concrete
fill 518 216 458 518 307 458 minecraft:deepslate_tiles
fill 519 216 447 519 227 448 minecraft:black_concrete
setblock 520 216 427 minecraft:light[level=12]
setblock 520 216 435 minecraft:light[level=12]
setblock 520 216 443 minecraft:light[level=12]
setblock 520 216 451 minecraft:light[level=12]
fill 521 216 458 523 307 458 minecraft:deepslate_tiles
setblock 523 216 419 minecraft:black_concrete
setblock 524 216 458 minecraft:black_concrete
fill 525 216 458 534 217 458 minecraft:deepslate_tiles
setblock 528 216 419 minecraft:light[level=12]
setblock 528 216 427 minecraft:light[level=12]
setblock 528 216 435 minecraft:light[level=12]
setblock 528 216 443 minecraft:light[level=12]
setblock 528 216 451 minecraft:light[level=12]
fill 530 216 416 530 217 416 minecraft:black_concrete
fill 531 216 416 556 216 416 minecraft:deepslate_tiles
setblock 536 216 419 minecraft:light[level=12]
setblock 536 216 427 minecraft:light[level=12]
setblock 536 216 443 minecraft:light[level=12]
setblock 536 216 451 minecraft:light[level=12]
setblock 536 216 458 minecraft:black_concrete
fill 537 216 458 550 216 458 minecraft:deepslate_tiles
setblock 544 216 419 minecraft:light[level=12]
setblock 544 216 427 minecraft:light[level=12]
setblock 544 216 435 minecraft:light[level=12]
setblock 544 216 443 minecraft:light[level=12]
setblock 544 216 451 minecraft:light[level=12]
setblock 551 216 458 minecraft:black_concrete
setblock 552 216 419 minecraft:light[level=12]
setblock 552 216 427 minecraft:light[level=12]
setblock 552 216 435 minecraft:light[level=12]
setblock 552 216 443 minecraft:light[level=12]
setblock 552 216 451 minecraft:light[level=12]
fill 552 216 458 556 217 458 minecraft:deepslate_tiles
fill 557 216 416 558 216 416 minecraft:black_concrete
fill 557 216 429 557 230 429 minecraft:black_concrete
fill 557 216 458 557 217 458 minecraft:black_concrete
fill 558 216 448 558 229 448 minecraft:black_concrete
fill 558 216 458 559 217 458 minecraft:deepslate_tiles
fill 559 216 416 559 307 416 minecraft:deepslate_tiles
fill 559 216 418 559 307 418 minecraft:deepslate_tiles
fill 559 216 420 559 307 434 minecraft:deepslate_tiles
setblock 559 216 435 minecraft:black_concrete
fill 559 216 436 559 216 448 minecraft:deepslate_tiles
fill 559 216 450 559 307 452 minecraft:deepslate_tiles
fill 559 216 454 559 307 457 minecraft:deepslate_tiles
fill 517 217 420 517 307 420 minecraft:deepslate_tiles
fill 517 217 423 517 307 427 minecraft:deepslate_tiles
setblock 517 217 428 minecraft:black_concrete
fill 517 217 429 517 307 431 minecraft:deepslate_tiles
setblock 517 217 432 minecraft:black_concrete
fill 517 217 433 517 217 439 minecraft:deepslate_tiles
setblock 517 217 440 minecraft:black_concrete
fill 517 217 441 517 307 450 minecraft:deepslate_tiles
fill 518 217 416 518 307 416 minecraft:deepslate_tiles
fill 518 217 453 518 230 457 minecraft:black_concrete
setblock 519 217 416 minecraft:black_concrete
fill 519 217 429 519 227 429 minecraft:black_concrete
fill 519 217 449 519 229 451 minecraft:black_concrete
fill 519 217 458 520 307 458 minecraft:deepslate_tiles
fill 520 217 416 520 307 416 minecraft:deepslate_tiles
setblock 520 217 420 minecraft:black_concrete
setblock 521 217 416 minecraft:black_concrete
fill 522 217 416 525 217 416 minecraft:deepslate_tiles
fill 524 217 458 524 307 458 minecraft:deepslate_tiles
fill 526 217 416 527 217 416 minecraft:black_concrete
fill 526 217 457 526 218 457 minecraft:black_concrete
fill 528 217 416 529 307 416 minecraft:deepslate_tiles
fill 531 217 416 535 307 416 minecraft:deepslate_tiles
fill 535 217 458 538 307 458 minecraft:deepslate_tiles
setblock 536 217 416 minecraft:black_concrete
fill 537 217 416 545 217 416 minecraft:deepslate_tiles
fill 539 217 458 539 218 458 minecraft:black_concrete
fill 540 217 458 551 217 458 minecraft:deepslate_tiles
setblock 546 217 416 minecraft:black_concrete
fill 547 217 416 558 217 416 minecraft:deepslate_tiles
fill 557 217 430 557 230 430 minecraft:black_concrete
fill 558 217 449 558 230 449 minecraft:black_concrete
fill 559 217 417 559 307 417 minecraft:deepslate_tiles
fill 559 217 419 559 307 419 minecraft:deepslate_tiles
fill 559 217 435 559 307 439 minecraft:deepslate_tiles
setblock 559 217 440 minecraft:black_concrete
fill 559 217 441 559 217 445 minecraft:deepslate_tiles
setblock 559 217 446 minecraft:black_concrete
fill 559 217 447 559 307 449 minecraft:deepslate_tiles
fill 559 217 453 559 307 453 minecraft:deepslate_tiles
fill 517 218 416 517 218 417 minecraft:black_concrete
fill 517 218 418 517 307 418 minecraft:deepslate_tiles
setblock 517 218 419 minecraft:black_concrete
fill 517 218 428 517 307 428 minecraft:deepslate_tiles
fill 517 218 432 517 307 432 minecraft:deepslate_tiles
setblock 517 218 433 minecraft:black_concrete
fill 517 218 434 517 307 440 minecraft:deepslate_tiles
fill 517 218 451 517 307 452 minecraft:deepslate_tiles
setblock 517 218 453 minecraft:black_concrete
fill 517 218 454 517 307 458 minecraft:deepslate_tiles
fill 518 218 431 518 230 431 minecraft:black_concrete
fill 519 218 416 519 307 416 minecraft:deepslate_tiles
fill 519 218 452 519 230 453 minecraft:black_concrete
fill 521 218 416 522 307 416 minecraft:deepslate_tiles
fill 521 218 456 522 230 456 minecraft:black_concrete
setblock 523 218 416 minecraft:black_concrete
fill 524 218 416 527 307 416 minecraft:deepslate_tiles
fill 525 218 458 525 307 458 minecraft:deepslate_tiles
setblock 526 218 458 minecraft:black_concrete
fill 527 218 458 534 307 458 minecraft:deepslate_tiles
fill 530 218 416 530 307 416 minecraft:deepslate_tiles
fill 536 218 416 539 307 416 minecraft:deepslate_tiles
setblock 540 218 416 minecraft:black_concrete
fill 540 218 458 540 307 458 minecraft:deepslate_tiles
fill 541 218 416 543 307 416 minecraft:deepslate_tiles
setblock 541 218 458 minecraft:black_concrete
fill 542 218 458 551 307 458 minecraft:deepslate_tiles
setblock 544 218 416 minecraft:black_concrete
fill 545 218 416 549 307 416 minecraft:deepslate_tiles
setblock 550 218 416 minecraft:black_concrete
fill 551 218 416 552 307 416 minecraft:deepslate_tiles
setblock 552 218 458 minecraft:black_concrete
setblock 553 218 416 minecraft:black_concrete
fill 553 218 458 557 307 458 minecraft:deepslate_tiles
fill 554 218 416 558 307 416 minecraft:deepslate_tiles
fill 556 218 424 556 227 427 minecraft:black_concrete
fill 557 218 417 557 230 417 minecraft:black_concrete
fill 557 218 431 557 230 431 minecraft:black_concrete
fill 558 218 434 558 230 434 minecraft:black_concrete
fill 558 218 450 558 230 451 minecraft:black_concrete
setblock 558 218 458 minecraft:black_concrete
fill 559 218 440 559 307 442 minecraft:deepslate_tiles
setblock 559 218 443 minecraft:black_concrete
fill 559 218 444 559 307 446 minecraft:deepslate_tiles
fill 559 218 458 559 307 458 minecraft:deepslate_tiles
fill 517 219 416 517 307 417 minecraft:deepslate_tiles
fill 517 219 419 517 307 419 minecraft:deepslate_tiles
fill 517 219 433 517 307 433 minecraft:deepslate_tiles
fill 517 219 453 517 307 453 minecraft:deepslate_tiles
fill 518 219 432 518 230 432 minecraft:black_concrete
fill 519 219 430 519 227 430 minecraft:black_concrete
fill 519 219 454 519 230 456 minecraft:black_concrete
fill 520 219 422 520 220 422 minecraft:black_concrete
fill 520 219 427 520 223 427 minecraft:black_concrete
fill 520 219 447 520 225 451 minecraft:black_concrete
fill 520 219 456 520 230 456 minecraft:black_concrete
fill 523 219 416 523 307 416 minecraft:deepslate_tiles
fill 523 219 456 523 230 456 minecraft:black_concrete
fill 524 219 417 524 220 417 minecraft:black_concrete
fill 526 219 458 526 307 458 minecraft:deepslate_tiles
fill 539 219 458 539 307 458 minecraft:deepslate_tiles
fill 540 219 416 540 307 416 minecraft:deepslate_tiles
fill 541 219 458 541 307 458 minecraft:deepslate_tiles
fill 544 219 416 544 307 416 minecraft:deepslate_tiles
fill 550 219 416 550 307 416 minecraft:deepslate_tiles
fill 552 219 458 552 307 458 minecraft:deepslate_tiles
fill 553 219 416 553 307 416 minecraft:deepslate_tiles
fill 556 219 423 556 227 423 minecraft:black_concrete
fill 556 219 428 556 228 428 minecraft:black_concrete
fill 557 219 432 557 230 432 minecraft:black_concrete
fill 558 219 435 558 230 435 minecraft:black_concrete
fill 558 219 452 558 230 453 minecraft:black_concrete
fill 558 219 458 558 307 458 minecraft:deepslate_tiles
fill 559 219 443 559 307 443 minecraft:deepslate_tiles
fill 518 220 433 518 230 433 minecraft:black_concrete
fill 518 220 442 518 227 442 minecraft:black_concrete
fill 519 220 431 519 228 431 minecraft:black_concrete
fill 519 220 444 519 224 444 minecraft:black_concrete
fill 520 220 452 520 229 454 minecraft:black_concrete
fill 521 220 418 521 223 418 minecraft:black_concrete
fill 522 220 418 522 229 418 minecraft:white_wool
fill 524 220 456 524 230 456 minecraft:black_concrete
fill 526 220 457 526 230 457 minecraft:black_concrete
fill 538 220 457 539 230 457 minecraft:black_concrete
fill 556 220 417 556 230 417 minecraft:black_concrete
fill 556 220 429 556 229 430 minecraft:black_concrete
fill 557 220 419 557 230 419 minecraft:black_concrete
fill 557 220 433 557 230 433 minecraft:black_concrete
fill 558 220 436 558 230 436 minecraft:black_concrete
fill 558 220 454 558 230 457 minecraft:black_concrete
fill 518 221 434 518 230 434 minecraft:black_concrete
fill 519 221 432 519 228 432 minecraft:black_concrete
fill 520 221 428 520 224 428 minecraft:black_concrete
fill 520 221 446 520 223 446 minecraft:black_concrete
fill 520 221 455 522 228 455 minecraft:black_concrete
fill 535 221 457 537 230 457 minecraft:black_concrete
fill 540 221 457 541 228 457 minecraft:black_concrete
fill 555 221 417 555 230 417 minecraft:black_concrete
fill 556 221 422 556 227 422 minecraft:black_concrete
fill 556 221 431 556 229 431 minecraft:black_concrete
fill 557 221 418 557 230 418 minecraft:black_concrete
fill 557 221 434 557 230 434 minecraft:black_concrete
fill 557 221 447 557 226 453 minecraft:black_concrete
fill 557 221 457 557 230 457 minecraft:black_concrete
fill 558 221 437 558 230 437 minecraft:black_concrete
fill 518 222 435 518 230 436 minecraft:black_concrete
fill 518 222 441 518 227 441 minecraft:black_concrete
fill 519 222 433 519 228 433 minecraft:black_concrete
fill 520 222 429 520 224 429 minecraft:black_concrete
fill 521 222 449 521 224 453 minecraft:black_concrete
fill 523 222 455 523 227 455 minecraft:black_concrete
fill 525 222 456 525 229 456 minecraft:black_concrete
fill 527 222 457 528 230 457 minecraft:black_concrete
fill 532 222 457 534 230 457 minecraft:black_concrete
fill 535 222 456 539 228 456 minecraft:black_concrete
fill 554 222 417 554 230 417 minecraft:black_concrete
fill 555 222 426 555 226 429 minecraft:black_concrete
fill 555 222 457 556 230 457 minecraft:black_concrete
fill 556 222 418 556 230 418 minecraft:black_concrete
fill 556 222 432 556 229 432 minecraft:black_concrete
fill 557 222 435 557 230 435 minecraft:black_concrete
fill 557 222 446 557 224 446 minecraft:black_concrete
fill 557 222 454 557 230 456 minecraft:black_concrete
fill 558 222 438 558 228 439 minecraft:black_concrete
fill 558 222 441 558 225 441 minecraft:black_concrete
fill 518 223 437 518 230 438 minecraft:black_concrete
fill 518 223 440 518 229 440 minecraft:black_concrete
fill 519 223 434 519 228 434 minecraft:black_concrete
fill 520 223 430 520 224 430 minecraft:black_concrete
fill 521 223 454 521 227 454 minecraft:black_concrete
fill 524 223 455 524 227 455 minecraft:black_concrete
fill 526 223 456 526 229 456 minecraft:black_concrete
fill 529 223 457 531 230 457 minecraft:black_concrete
fill 533 223 456 534 230 456 minecraft:black_concrete
fill 535 223 455 538 227 455 minecraft:black_concrete
fill 540 223 456 540 227 456 minecraft:black_concrete
fill 542 223 457 542 227 457 minecraft:black_concrete
fill 553 223 417 553 230 417 minecraft:black_concrete
fill 554 223 457 554 230 457 minecraft:black_concrete
fill 555 223 418 555 230 418 minecraft:black_concrete
fill 555 223 425 555 225 425 minecraft:black_concrete
fill 555 223 430 555 227 431 minecraft:black_concrete
fill 556 223 421 556 226 421 minecraft:black_concrete
fill 556 223 433 556 229 433 minecraft:black_concrete
fill 556 223 456 556 230 456 minecraft:black_concrete
fill 557 223 436 557 230 436 minecraft:black_concrete
fill 558 223 440 558 227 440 minecraft:black_concrete
fill 518 224 439 518 230 439 minecraft:black_concrete
fill 519 224 435 519 227 435 minecraft:black_concrete
setblock 520 224 419 minecraft:light[level=12]
setblock 520 224 427 minecraft:light[level=12]
fill 520 224 433 520 229 433 minecraft:black_concrete
setblock 520 224 435 minecraft:light[level=12]
setblock 520 224 443 minecraft:light[level=12]
fill 522 224 447 523 226 448 minecraft:black_concrete
fill 522 224 454 522 225 454 minecraft:black_concrete
fill 527 224 421 528 226 422 minecraft:black_concrete
fill 527 224 456 532 230 456 minecraft:black_concrete
setblock 528 224 419 minecraft:light[level=12]
setblock 528 224 427 minecraft:light[level=12]
setblock 528 224 435 minecraft:light[level=12]
setblock 528 224 443 minecraft:light[level=12]
setblock 528 224 451 minecraft:light[level=12]
fill 533 224 455 534 229 455 minecraft:black_concrete
fill 536 224 417 539 228 417 minecraft:black_concrete
setblock 536 224 419 minecraft:light[level=12]
setblock 536 224 427 minecraft:light[level=12]
setblock 536 224 443 minecraft:light[level=12]
setblock 536 224 451 minecraft:light[level=12]
fill 539 224 455 539 226 455 minecraft:black_concrete
fill 541 224 418 542 226 418 minecraft:black_concrete
fill 541 224 456 541 225 456 minecraft:black_concrete
fill 542 224 419 542 229 419 minecraft:black_concrete
setblock 544 224 419 minecraft:light[level=12]
setblock 544 224 427 minecraft:light[level=12]
setblock 544 224 435 minecraft:light[level=12]
setblock 544 224 443 minecraft:light[level=12]
setblock 544 224 451 minecraft:light[level=12]
fill 548 224 452 549 226 453 minecraft:black_concrete
fill 552 224 417 552 230 417 minecraft:black_concrete
setblock 552 224 419 minecraft:light[level=12]
setblock 552 224 427 minecraft:light[level=12]
setblock 552 224 435 minecraft:light[level=12]
setblock 552 224 443 minecraft:light[level=12]
setblock 552 224 451 minecraft:light[level=12]
fill 552 224 457 553 230 457 minecraft:black_concrete
fill 553 224 426 554 226 427 minecraft:black_concrete
fill 554 224 418 554 230 418 minecraft:black_concrete
fill 554 224 456 555 230 456 minecraft:black_concrete
fill 555 224 432 555 227 432 minecraft:black_concrete
fill 556 224 420 556 227 420 minecraft:black_concrete
fill 556 224 434 556 229 434 minecraft:black_concrete
fill 556 224 441 557 226 441 minecraft:black_concrete
fill 556 224 450 556 226 455 minecraft:black_concrete
fill 557 224 437 557 229 437 minecraft:black_concrete
fill 557 224 440 557 226 440 minecraft:black_concrete
fill 520 225 434 520 229 434 minecraft:black_concrete
fill 521 225 450 521 225 453 minecraft:black_concrete
fill 532 225 455 532 229 455 minecraft:black_concrete
fill 535 225 417 535 230 417 minecraft:black_concrete
setblock 536 225 454 minecraft:black_concrete
fill 540 225 417 540 226 417 minecraft:black_concrete
fill 541 225 419 541 229 419 minecraft:black_concrete
fill 551 225 417 551 230 417 minecraft:black_concrete
fill 551 225 457 551 230 457 minecraft:black_concrete
fill 553 225 418 553 230 418 minecraft:black_concrete
fill 553 225 456 553 230 456 minecraft:black_concrete
fill 555 225 455 555 230 455 minecraft:black_concrete
fill 556 225 419 556 229 419 minecraft:black_concrete
fill 556 225 435 556 228 435 minecraft:black_concrete
fill 556 225 440 556 229 440 minecraft:black_concrete
fill 519 226 418 519 226 419 minecraft:black_concrete
fill 520 226 448 520 226 451 minecraft:black_concrete
fill 521 226 451 521 226 453 minecraft:black_concrete
fill 531 226 455 531 229 455 minecraft:black_concrete
fill 534 226 417 534 230 417 minecraft:black_concrete
fill 535 226 454 535 230 454 minecraft:black_concrete
fill 550 226 417 550 230 417 minecraft:black_concrete
fill 550 226 457 550 230 457 minecraft:black_concrete
fill 552 226 456 552 230 456 minecraft:black_concrete
fill 554 226 455 554 230 455 minecraft:black_concrete
fill 555 226 419 555 230 419 minecraft:black_concrete
setblock 555 226 433 minecraft:black_concrete
setblock 519 227 418 minecraft:black_concrete
fill 520 227 449 520 227 451 minecraft:black_concrete
fill 521 227 433 521 230 434 minecraft:black_concrete
setblock 521 227 453 minecraft:black_concrete
fill 522 227 447 523 228 447 minecraft:black_concrete
fill 523 227 446 523 230 446 minecraft:black_concrete
setblock 523 227 448 minecraft:black_concrete
fill 527 227 422 529 227 422 minecraft:black_concrete
fill 528 227 421 528 228 421 minecraft:black_concrete
fill 533 227 417 533 230 417 minecraft:black_concrete
fill 534 227 454 534 230 454 minecraft:black_concrete
fill 541 227 420 542 230 420 minecraft:black_concrete
fill 547 227 452 549 227 452 minecraft:black_concrete
fill 548 227 453 548 228 453 minecraft:black_concrete
fill 549 227 417 549 230 417 minecraft:black_concrete
fill 552 227 418 552 230 418 minecraft:black_concrete
fill 553 227 426 553 227 428 minecraft:black_concrete
fill 554 227 427 554 228 427 minecraft:black_concrete
fill 555 227 428 555 227 429 minecraft:black_concrete
fill 555 227 440 555 230 441 minecraft:black_concrete
fill 556 227 441 556 229 441 minecraft:black_concrete
fill 556 227 451 556 227 455 minecraft:black_concrete
fill 557 227 448 557 227 453 minecraft:black_concrete
setblock 519 228 448 minecraft:black_concrete
fill 520 228 450 520 228 451 minecraft:black_concrete
fill 524 228 447 524 230 447 minecraft:black_concrete
fill 528 228 422 528 230 423 minecraft:black_concrete
fill 529 228 422 529 230 422 minecraft:black_concrete
fill 535 228 455 537 228 455 minecraft:black_concrete
fill 547 228 452 548 230 452 minecraft:black_concrete
fill 548 228 451 548 230 451 minecraft:black_concrete
fill 549 228 457 549 230 457 minecraft:black_concrete
fill 551 228 418 551 230 418 minecraft:black_concrete
fill 551 228 456 551 230 456 minecraft:black_concrete
fill 552 228 427 553 230 427 minecraft:black_concrete
fill 553 228 428 553 230 428 minecraft:black_concrete
fill 553 228 455 553 230 455 minecraft:black_concrete
fill 556 228 426 556 228 427 minecraft:black_concrete
fill 556 228 452 556 228 455 minecraft:black_concrete
fill 557 228 449 557 228 453 minecraft:black_concrete
fill 520 229 455 521 229 455 minecraft:black_concrete
fill 523 229 447 523 230 447 minecraft:black_concrete
fill 524 229 446 524 230 446 minecraft:black_concrete
fill 529 229 423 529 230 423 minecraft:black_concrete
fill 532 229 417 532 230 417 minecraft:black_concrete
fill 535 229 455 536 229 456 minecraft:black_concrete
fill 536 229 417 538 230 417 minecraft:black_concrete
fill 537 229 456 538 229 456 minecraft:black_concrete
setblock 540 229 457 minecraft:black_concrete
fill 547 229 451 547 230 451 minecraft:black_concrete
fill 548 229 417 548 230 417 minecraft:black_concrete
fill 552 229 428 552 230 428 minecraft:black_concrete
fill 556 229 453 556 229 455 minecraft:black_concrete
fill 557 229 450 557 229 453 minecraft:black_concrete
fill 558 229 438 558 230 438 minecraft:black_concrete
setblock 518 230 419 minecraft:black_concrete
fill 519 230 450 519 230 451 minecraft:black_concrete
fill 520 230 454 520 230 455 minecraft:black_concrete
fill 522 230 433 522 230 434 minecraft:black_concrete
setblock 533 230 455 minecraft:black_concrete
fill 534 230 453 535 230 453 minecraft:black_concrete
fill 535 230 456 537 230 456 minecraft:black_concrete
fill 541 230 421 542 230 421 minecraft:black_concrete
setblock 547 230 417 minecraft:black_concrete
setblock 548 230 457 minecraft:black_concrete
setblock 550 230 418 minecraft:black_concrete
setblock 554 230 419 minecraft:black_concrete
fill 554 230 440 554 230 441 minecraft:black_concrete
fill 556 230 454 556 230 455 minecraft:black_concrete
fill 557 230 420 557 230 421 minecraft:black_concrete
fill 557 230 451 557 230 453 minecraft:black_concrete
setblock 520 232 419 minecraft:light[level=12]
setblock 520 232 427 minecraft:light[level=12]
setblock 520 232 435 minecraft:light[level=12]
setblock 520 232 443 minecraft:light[level=12]
setblock 520 232 451 minecraft:light[level=12]
setblock 528 232 419 minecraft:light[level=12]
setblock 528 232 427 minecraft:light[level=12]
setblock 528 232 435 minecraft:light[level=12]
setblock 528 232 443 minecraft:light[level=12]
setblock 528 232 451 minecraft:light[level=12]
setblock 536 232 419 minecraft:light[level=12]
setblock 536 232 427 minecraft:light[level=12]
setblock 536 232 443 minecraft:light[level=12]
setblock 536 232 451 minecraft:light[level=12]
setblock 544 232 419 minecraft:light[level=12]
setblock 544 232 427 minecraft:light[level=12]
setblock 544 232 435 minecraft:light[level=12]
setblock 544 232 443 minecraft:light[level=12]
setblock 544 232 451 minecraft:light[level=12]
setblock 552 232 419 minecraft:light[level=12]
setblock 552 232 427 minecraft:light[level=12]
setblock 552 232 435 minecraft:light[level=12]
setblock 552 232 443 minecraft:light[level=12]
setblock 552 232 451 minecraft:light[level=12]
fill 526 236 436 533 236 436 minecraft:black_concrete
fill 527 236 432 534 236 435 minecraft:black_concrete
fill 527 236 437 534 236 440 minecraft:black_concrete
fill 528 236 430 544 236 431 minecraft:black_concrete
fill 528 236 441 544 236 442 minecraft:black_concrete
fill 529 236 429 543 236 429 minecraft:black_concrete
fill 529 236 443 543 236 443 minecraft:black_concrete
fill 530 236 428 542 236 428 minecraft:black_concrete
fill 530 236 444 542 236 444 minecraft:black_concrete
fill 532 236 427 540 237 427 minecraft:black_concrete
fill 532 236 445 540 237 445 minecraft:black_concrete
fill 535 236 432 535 236 434 minecraft:black_concrete
fill 535 236 438 535 236 440 minecraft:black_concrete
fill 536 236 426 536 237 426 minecraft:black_concrete
fill 536 236 432 545 236 433 minecraft:black_concrete
fill 536 236 439 545 236 440 minecraft:black_concrete
fill 536 236 446 536 237 446 minecraft:black_concrete
fill 537 236 434 545 236 434 minecraft:black_concrete
fill 537 236 438 545 236 438 minecraft:black_concrete
fill 538 236 435 545 236 435 minecraft:black_concrete
fill 538 236 437 545 236 437 minecraft:black_concrete
fill 539 236 436 546 236 436 minecraft:black_concrete
fill 518 237 417 527 237 457 minecraft:black_concrete
fill 528 237 417 528 237 433 minecraft:black_concrete
fill 528 237 434 528 237 438 minecraft:red_concrete
fill 528 237 439 528 237 457 minecraft:black_concrete
fill 529 237 417 529 237 431 minecraft:black_concrete
fill 529 237 432 529 237 433 minecraft:red_concrete
fill 529 237 434 531 237 438 minecraft:black_concrete
fill 529 237 439 529 237 440 minecraft:red_concrete
fill 529 237 441 529 237 457 minecraft:black_concrete
fill 530 237 417 530 237 430 minecraft:black_concrete
setblock 530 237 431 minecraft:red_concrete
fill 530 237 432 532 237 433 minecraft:black_concrete
fill 530 237 439 532 237 440 minecraft:black_concrete
setblock 530 237 441 minecraft:red_concrete
fill 530 237 442 530 237 457 minecraft:black_concrete
fill 531 237 417 531 237 429 minecraft:black_concrete
setblock 531 237 430 minecraft:red_concrete
fill 531 237 431 541 237 431 minecraft:black_concrete
fill 531 237 441 541 237 441 minecraft:black_concrete
setblock 531 237 442 minecraft:red_concrete
fill 531 237 443 531 237 457 minecraft:black_concrete
fill 532 237 417 535 237 426 minecraft:black_concrete
fill 532 237 428 533 237 428 minecraft:black_concrete
fill 532 237 429 533 237 429 minecraft:red_concrete
fill 532 237 430 540 237 430 minecraft:black_concrete
fill 532 237 434 532 237 438 minecraft:red_concrete
fill 532 237 442 540 237 442 minecraft:black_concrete
fill 532 237 443 533 237 443 minecraft:red_concrete
fill 532 237 444 533 237 444 minecraft:black_concrete
fill 532 237 446 535 237 457 minecraft:black_concrete
setblock 533 237 432 minecraft:black_concrete
fill 533 237 433 533 237 434 minecraft:red_concrete
fill 533 237 435 533 237 437 minecraft:crying_obsidian
fill 533 237 438 533 237 439 minecraft:red_concrete
setblock 533 237 440 minecraft:black_concrete
fill 534 237 428 538 237 428 minecraft:red_concrete
fill 534 237 429 538 237 429 minecraft:black_concrete
fill 534 237 432 534 237 433 minecraft:red_concrete
fill 534 237 434 534 237 435 minecraft:crying_obsidian
fill 534 237 437 534 237 438 minecraft:crying_obsidian
fill 534 237 439 534 237 440 minecraft:red_concrete
fill 534 237 443 538 237 443 minecraft:black_concrete
fill 534 237 444 538 237 444 minecraft:red_concrete
fill 535 237 432 538 237 432 minecraft:red_concrete
fill 535 237 433 535 237 434 minecraft:crying_obsidian
fill 535 237 438 535 237 439 minecraft:crying_obsidian
fill 535 237 440 538 237 440 minecraft:red_concrete
fill 536 237 417 558 237 425 minecraft:black_concrete
fill 536 237 433 537 237 433 minecraft:crying_obsidian
fill 536 237 439 537 237 439 minecraft:crying_obsidian
fill 536 237 447 558 237 457 minecraft:black_concrete
fill 537 237 426 558 237 426 minecraft:black_concrete
fill 537 237 434 538 237 434 minecraft:crying_obsidian
fill 537 237 438 538 237 438 minecraft:crying_obsidian
fill 537 237 446 558 237 446 minecraft:black_concrete
fill 538 237 433 539 237 433 minecraft:red_concrete
fill 538 237 435 539 237 435 minecraft:crying_obsidian
fill 538 237 437 539 237 437 minecraft:crying_obsidian
fill 538 237 439 539 237 439 minecraft:red_concrete
fill 539 237 428 558 237 428 minecraft:black_concrete
fill 539 237 429 540 237 429 minecraft:red_concrete
fill 539 237 432 542 237 432 minecraft:black_concrete
fill 539 237 434 540 237 434 minecraft:red_concrete
setblock 539 237 436 minecraft:crying_obsidian
fill 539 237 438 540 237 438 minecraft:red_concrete
fill 539 237 440 542 237 440 minecraft:black_concrete
fill 539 237 443 540 237 443 minecraft:red_concrete
fill 539 237 444 558 237 444 minecraft:black_concrete
fill 540 237 433 542 237 433 minecraft:black_concrete
fill 540 237 435 540 237 437 minecraft:red_concrete
fill 540 237 439 542 237 439 minecraft:black_concrete
fill 541 237 427 558 237 427 minecraft:black_concrete
fill 541 237 429 558 237 429 minecraft:black_concrete
setblock 541 237 430 minecraft:red_concrete
fill 541 237 434 543 237 438 minecraft:black_concrete
setblock 541 237 442 minecraft:red_concrete
fill 541 237 443 558 237 443 minecraft:black_concrete
fill 541 237 445 558 237 445 minecraft:black_concrete
fill 542 237 430 558 237 430 minecraft:black_concrete
setblock 542 237 431 minecraft:red_concrete
setblock 542 237 441 minecraft:red_concrete
fill 542 237 442 558 237 442 minecraft:black_concrete
fill 543 237 431 558 237 431 minecraft:black_concrete
fill 543 237 432 543 237 433 minecraft:red_concrete
fill 543 237 439 543 237 440 minecraft:red_concrete
fill 543 237 441 558 237 441 minecraft:black_concrete
fill 544 237 432 558 237 433 minecraft:black_concrete
fill 544 237 434 544 237 438 minecraft:red_concrete
fill 544 237 439 558 237 440 minecraft:black_concrete
fill 545 237 434 558 237 438 minecraft:black_concrete
setblock 520 240 419 minecraft:light[level=12]
setblock 520 240 427 minecraft:light[level=12]
setblock 520 240 435 minecraft:light[level=12]
setblock 520 240 443 minecraft:light[level=12]
setblock 520 240 451 minecraft:light[level=12]
setblock 528 240 419 minecraft:light[level=12]
setblock 528 240 427 minecraft:light[level=12]
setblock 528 240 435 minecraft:light[level=12]
setblock 528 240 443 minecraft:light[level=12]
setblock 528 240 451 minecraft:light[level=12]
setblock 536 240 419 minecraft:light[level=12]
setblock 536 240 427 minecraft:light[level=12]
setblock 536 240 443 minecraft:light[level=12]
setblock 536 240 451 minecraft:light[level=12]
setblock 544 240 419 minecraft:light[level=12]
setblock 544 240 427 minecraft:light[level=12]
setblock 544 240 435 minecraft:light[level=12]
setblock 544 240 443 minecraft:light[level=12]
setblock 544 240 451 minecraft:light[level=12]
setblock 552 240 419 minecraft:light[level=12]
setblock 552 240 427 minecraft:light[level=12]
setblock 552 240 435 minecraft:light[level=12]
setblock 552 240 443 minecraft:light[level=12]
setblock 552 240 451 minecraft:light[level=12]
fill 518 241 418 518 241 420 minecraft:black_concrete
fill 518 241 437 518 241 450 minecraft:black_concrete
setblock 518 241 457 minecraft:black_concrete
fill 519 241 439 519 241 447 minecraft:black_concrete
fill 520 241 441 520 241 444 minecraft:black_concrete
fill 522 241 417 558 241 417 minecraft:black_concrete
fill 522 241 457 532 241 457 minecraft:black_concrete
fill 524 241 418 558 241 418 minecraft:black_concrete
fill 524 241 434 525 241 435 minecraft:black_concrete
fill 526 241 444 527 241 445 minecraft:black_concrete
fill 527 241 419 532 241 419 minecraft:black_concrete
fill 529 241 435 531 241 436 minecraft:black_concrete
fill 530 241 425 531 241 426 minecraft:black_concrete
setblock 530 241 434 minecraft:black_concrete
fill 530 241 441 532 242 442 minecraft:black_concrete
fill 531 241 443 531 243 443 minecraft:black_concrete
fill 532 241 430 534 242 430 minecraft:black_concrete
setblock 532 241 440 minecraft:black_concrete
fill 533 241 429 534 243 429 minecraft:black_concrete
fill 533 241 431 535 241 431 minecraft:black_concrete
fill 535 241 445 537 241 445 minecraft:black_concrete
fill 535 241 450 536 241 451 minecraft:black_concrete
fill 536 241 444 537 241 444 minecraft:black_concrete
fill 536 241 446 537 243 446 minecraft:black_concrete
fill 539 241 428 540 241 430 minecraft:black_concrete
fill 540 241 423 541 241 424 minecraft:black_concrete
fill 541 241 419 555 241 419 minecraft:black_concrete
setblock 541 241 429 minecraft:black_concrete
fill 541 241 443 543 241 443 minecraft:black_concrete
fill 542 241 444 543 242 445 minecraft:black_concrete
fill 543 241 457 558 242 457 minecraft:black_concrete
fill 544 241 420 553 241 420 minecraft:black_concrete
fill 544 241 432 544 241 434 minecraft:black_concrete
fill 544 241 444 544 243 444 minecraft:black_concrete
fill 545 241 431 545 242 433 minecraft:black_concrete
fill 545 241 438 547 241 439 minecraft:black_concrete
fill 545 241 448 546 241 449 minecraft:black_concrete
fill 546 241 432 546 243 433 minecraft:black_concrete
setblock 546 241 440 minecraft:black_concrete
fill 546 241 456 554 241 456 minecraft:black_concrete
fill 547 241 421 549 241 421 minecraft:black_concrete
fill 548 241 453 548 252 453 minecraft:white_wool
fill 549 241 429 550 241 430 minecraft:black_concrete
fill 551 241 439 552 241 440 minecraft:black_concrete
fill 557 241 419 558 241 421 minecraft:black_concrete
fill 558 241 422 558 242 423 minecraft:black_concrete
fill 558 241 440 558 242 449 minecraft:black_concrete
fill 558 241 455 558 241 456 minecraft:black_concrete
fill 518 242 438 518 243 450 minecraft:black_concrete
fill 519 242 440 519 243 447 minecraft:black_concrete
fill 520 242 442 520 242 444 minecraft:black_concrete
fill 523 242 417 558 242 417 minecraft:black_concrete
fill 523 242 457 530 242 457 minecraft:black_concrete
fill 525 242 418 533 242 418 minecraft:black_concrete
fill 525 242 434 526 244 435 minecraft:black_concrete
fill 526 242 444 528 242 444 minecraft:black_concrete
fill 527 242 445 527 243 445 minecraft:black_concrete
fill 528 242 419 530 242 419 minecraft:black_concrete
fill 528 242 435 530 242 436 minecraft:black_concrete
fill 529 242 434 529 243 434 minecraft:black_concrete
fill 529 242 442 529 245 443 minecraft:black_concrete
fill 530 242 426 531 243 426 minecraft:black_concrete
fill 530 242 443 530 245 443 minecraft:black_concrete
setblock 531 242 425 minecraft:black_concrete
fill 531 242 427 531 246 427 minecraft:black_concrete
fill 532 242 428 532 245 429 minecraft:black_concrete
fill 533 242 428 533 245 428 minecraft:black_concrete
fill 533 242 431 534 242 431 minecraft:black_concrete
fill 535 242 446 535 243 446 minecraft:black_concrete
fill 535 242 449 536 244 450 minecraft:black_concrete
fill 536 242 445 537 242 445 minecraft:black_concrete
fill 536 242 447 537 244 447 minecraft:black_concrete
fill 539 242 418 556 242 418 minecraft:black_concrete
fill 539 242 427 540 242 429 minecraft:black_concrete
fill 540 242 424 541 244 425 minecraft:black_concrete
fill 541 242 428 541 243 428 minecraft:black_concrete
fill 542 242 419 554 242 419 minecraft:black_concrete
fill 542 242 443 543 242 443 minecraft:black_concrete
fill 543 242 446 544 245 446 minecraft:black_concrete
fill 544 242 420 552 242 420 minecraft:black_concrete
fill 544 242 432 544 242 433 minecraft:black_concrete
fill 544 242 445 544 245 445 minecraft:black_concrete
fill 545 242 447 545 242 449 minecraft:black_concrete
fill 546 242 431 547 245 431 minecraft:black_concrete
fill 546 242 438 548 242 439 minecraft:black_concrete
fill 546 242 448 546 243 448 minecraft:black_concrete
fill 547 242 421 548 242 421 minecraft:black_concrete
fill 547 242 432 547 245 432 minecraft:black_concrete
fill 547 242 440 547 243 440 minecraft:black_concrete
fill 547 242 456 552 242 456 minecraft:black_concrete
fill 548 242 430 550 242 430 minecraft:black_concrete
fill 549 242 429 549 243 429 minecraft:black_concrete
fill 550 242 439 551 244 440 minecraft:black_concrete
fill 558 242 418 558 243 421 minecraft:black_concrete
setblock 558 242 456 minecraft:black_concrete
fill 520 243 443 520 243 444 minecraft:black_concrete
fill 523 243 417 534 243 417 minecraft:black_concrete
fill 525 243 457 527 243 457 minecraft:black_concrete
fill 526 243 418 531 243 418 minecraft:black_concrete
fill 527 243 434 528 245 435 minecraft:black_concrete
fill 527 243 444 528 246 444 minecraft:black_concrete
fill 528 243 436 529 243 436 minecraft:black_concrete
fill 529 243 435 530 243 435 minecraft:black_concrete
fill 530 243 441 530 243 442 minecraft:black_concrete
setblock 531 243 442 minecraft:black_concrete
fill 532 243 430 533 243 430 minecraft:black_concrete
fill 535 243 447 535 245 448 minecraft:black_concrete
setblock 536 243 445 minecraft:black_concrete
fill 536 243 448 536 246 448 minecraft:black_concrete
fill 538 243 417 558 243 417 minecraft:black_concrete
fill 539 243 427 540 243 428 minecraft:black_concrete
fill 540 243 418 554 243 418 minecraft:black_concrete
fill 540 243 426 541 246 426 minecraft:black_concrete
setblock 540 243 429 minecraft:black_concrete
fill 541 243 427 541 245 427 minecraft:black_concrete
fill 542 243 419 552 243 419 minecraft:black_concrete
fill 542 243 445 543 243 445 minecraft:black_concrete
setblock 543 243 444 minecraft:black_concrete
fill 544 243 420 550 243 420 minecraft:black_concrete
fill 544 243 457 555 243 457 minecraft:black_concrete
fill 545 243 431 545 243 432 minecraft:black_concrete
fill 545 243 447 545 246 448 minecraft:black_concrete
fill 546 243 439 549 243 439 minecraft:black_concrete
fill 547 243 438 548 243 438 minecraft:black_concrete
fill 547 243 456 550 243 456 minecraft:black_concrete
fill 548 243 430 549 246 430 minecraft:black_concrete
fill 548 243 440 549 245 440 minecraft:black_concrete
setblock 558 243 422 minecraft:black_concrete
fill 558 243 441 558 243 450 minecraft:black_concrete
fill 518 244 439 518 244 450 minecraft:black_concrete
fill 519 244 441 519 245 448 minecraft:black_concrete
setblock 520 244 444 minecraft:black_concrete
fill 524 244 417 531 244 417 minecraft:black_concrete
fill 527 244 436 528 244 436 minecraft:black_concrete
fill 527 244 443 528 246 443 minecraft:black_concrete
setblock 528 244 442 minecraft:black_concrete
setblock 529 244 435 minecraft:black_concrete
fill 529 244 444 529 246 444 minecraft:black_concrete
setblock 530 244 442 minecraft:black_concrete
fill 531 244 426 532 246 426 minecraft:black_concrete
fill 531 244 428 531 246 428 minecraft:black_concrete
fill 532 244 427 533 244 427 minecraft:black_concrete
setblock 533 244 429 minecraft:black_concrete
setblock 536 244 446 minecraft:black_concrete
fill 537 244 448 537 245 448 minecraft:black_concrete
fill 539 244 417 555 244 417 minecraft:black_concrete
fill 539 244 426 539 244 427 minecraft:black_concrete
fill 540 244 427 540 244 428 minecraft:black_concrete
fill 541 244 418 553 244 418 minecraft:black_concrete
fill 542 244 419 551 244 419 minecraft:black_concrete
setblock 543 244 445 minecraft:black_concrete
fill 543 244 447 544 244 447 minecraft:black_concrete
fill 544 244 448 544 246 448 minecraft:black_concrete
fill 544 244 457 553 244 457 minecraft:black_concrete
fill 545 244 420 548 244 420 minecraft:black_concrete
fill 545 244 446 545 246 446 minecraft:black_concrete
setblock 546 244 432 minecraft:black_concrete
fill 547 244 430 547 246 430 minecraft:black_concrete
fill 547 244 439 549 244 439 minecraft:black_concrete
fill 548 244 431 548 244 432 minecraft:black_concrete
fill 548 244 438 549 244 438 minecraft:black_concrete
fill 549 244 431 549 246 431 minecraft:black_concrete
fill 558 244 442 558 244 450 minecraft:black_concrete
fill 518 245 440 518 261 450 minecraft:black_concrete
fill 525 245 435 526 246 435 minecraft:black_concrete
fill 526 245 417 528 245 417 minecraft:black_concrete
fill 526 245 434 526 246 434 minecraft:black_concrete
setblock 527 245 436 minecraft:black_concrete
fill 532 245 427 532 246 427 minecraft:black_concrete
fill 535 245 449 536 246 449 minecraft:black_concrete
setblock 536 245 447 minecraft:black_concrete
fill 536 245 450 536 246 450 minecraft:black_concrete
setblock 539 245 426 minecraft:black_concrete
fill 540 245 417 553 245 417 minecraft:black_concrete
fill 540 245 424 540 246 425 minecraft:black_concrete
setblock 540 245 427 minecraft:black_concrete
fill 541 245 418 551 245 418 minecraft:black_concrete
fill 541 245 425 541 246 425 minecraft:black_concrete
fill 543 245 419 549 245 419 minecraft:black_concrete
fill 544 245 447 544 246 447 minecraft:black_concrete
fill 544 245 457 552 245 457 minecraft:black_concrete
fill 548 245 431 548 246 431 minecraft:black_concrete
fill 548 245 439 551 245 439 minecraft:black_concrete
setblock 549 245 438 minecraft:black_concrete
fill 550 245 440 550 246 440 minecraft:black_concrete
fill 558 245 443 558 269 450 minecraft:black_concrete
fill 518 246 451 518 262 451 minecraft:black_concrete
fill 519 246 442 519 257 449 minecraft:black_concrete
fill 520 246 445 520 255 445 minecraft:black_concrete
fill 527 246 434 527 246 435 minecraft:black_concrete
setblock 529 246 443 minecraft:black_concrete
setblock 532 246 428 minecraft:black_concrete
setblock 535 246 448 minecraft:black_concrete
fill 540 246 417 552 246 417 minecraft:black_concrete
fill 542 246 418 550 246 418 minecraft:black_concrete
fill 543 246 419 548 246 419 minecraft:black_concrete
setblock 544 246 446 minecraft:black_concrete
fill 544 246 457 550 271 457 minecraft:black_concrete
setblock 547 246 431 minecraft:black_concrete
fill 549 246 439 549 246 440 minecraft:black_concrete
fill 550 246 439 551 246 439 minecraft:black_concrete
fill 558 246 451 558 269 451 minecraft:black_concrete
fill 520 247 446 520 255 447 minecraft:black_concrete
fill 540 247 417 550 248 417 minecraft:black_concrete
fill 542 247 418 549 247 418 minecraft:black_concrete
fill 543 247 457 543 271 457 minecraft:black_concrete
fill 544 247 419 546 247 419 minecraft:black_concrete
fill 558 247 452 558 268 452 minecraft:black_concrete
fill 518 248 426 518 273 427 minecraft:black_concrete
fill 518 248 452 518 263 452 minecraft:black_concrete
fill 519 248 450 519 259 450 minecraft:black_concrete
setblock 520 248 419 minecraft:light[level=12]
setblock 520 248 427 minecraft:light[level=12]
setblock 520 248 435 minecraft:light[level=12]
setblock 520 248 443 minecraft:light[level=12]
fill 520 248 444 520 255 444 minecraft:black_concrete
fill 520 248 448 520 256 448 minecraft:black_concrete
setblock 520 248 451 minecraft:light[level=12]
setblock 528 248 419 minecraft:light[level=12]
setblock 528 248 427 minecraft:light[level=12]
setblock 528 248 435 minecraft:light[level=12]
setblock 528 248 443 minecraft:light[level=12]
setblock 528 248 451 minecraft:light[level=12]
setblock 536 248 419 minecraft:light[level=12]
setblock 536 248 427 minecraft:light[level=12]
setblock 536 248 435 minecraft:light[level=12]
setblock 536 248 443 minecraft:light[level=12]
setblock 536 248 451 minecraft:light[level=12]
fill 541 248 418 548 248 418 minecraft:black_concrete
setblock 544 248 419 minecraft:light[level=12]
setblock 544 248 427 minecraft:light[level=12]
setblock 544 248 435 minecraft:light[level=12]
setblock 544 248 443 minecraft:light[level=12]
setblock 544 248 451 minecraft:light[level=12]
setblock 552 248 419 minecraft:light[level=12]
setblock 552 248 427 minecraft:light[level=12]
setblock 552 248 435 minecraft:light[level=12]
setblock 552 248 443 minecraft:light[level=12]
setblock 552 248 451 minecraft:light[level=12]
fill 557 248 446 557 266 450 minecraft:black_concrete
fill 558 248 453 558 268 454 minecraft:black_concrete
fill 518 249 424 518 273 425 minecraft:black_concrete
fill 518 249 428 518 271 432 minecraft:black_concrete
fill 518 249 439 518 272 439 minecraft:black_concrete
fill 518 249 453 518 265 453 minecraft:black_concrete
fill 519 249 427 519 261 428 minecraft:black_concrete
fill 519 249 441 519 270 441 minecraft:black_concrete
fill 519 249 451 519 259 451 minecraft:black_concrete
fill 520 249 449 520 256 449 minecraft:black_concrete
fill 539 249 417 549 252 417 minecraft:black_concrete
fill 541 249 418 547 250 418 minecraft:black_concrete
fill 541 249 457 542 271 457 minecraft:black_concrete
fill 544 249 456 546 267 456 minecraft:black_concrete
fill 557 249 451 557 265 452 minecraft:black_concrete
fill 558 249 442 558 273 442 minecraft:black_concrete
fill 558 249 455 558 269 455 minecraft:black_concrete
fill 518 250 423 518 273 423 minecraft:black_concrete
fill 518 250 433 518 271 438 minecraft:black_concrete
fill 518 250 454 518 266 454 minecraft:black_concrete
fill 519 250 425 519 258 426 minecraft:black_concrete
fill 519 250 429 519 267 433 minecraft:black_concrete
fill 519 250 452 519 259 453 minecraft:black_concrete
fill 520 250 427 520 258 430 minecraft:black_concrete
fill 520 250 443 520 254 443 minecraft:black_concrete
fill 520 250 450 520 257 451 minecraft:black_concrete
fill 538 250 417 538 273 417 minecraft:black_concrete
fill 540 250 418 540 271 418 minecraft:black_concrete
fill 540 250 457 540 272 457 minecraft:black_concrete
fill 542 250 456 543 268 456 minecraft:black_concrete
fill 547 250 456 548 261 456 minecraft:black_concrete
fill 551 250 457 551 273 457 minecraft:black_concrete
fill 557 250 445 557 273 445 minecraft:black_concrete
fill 557 250 453 557 266 453 minecraft:black_concrete
fill 558 250 425 558 257 429 minecraft:black_concrete
fill 558 250 441 558 273 441 minecraft:black_concrete
fill 558 250 456 558 269 457 minecraft:black_concrete
fill 518 251 455 518 267 456 minecraft:black_concrete
fill 519 251 424 519 257 424 minecraft:black_concrete
fill 519 251 434 519 269 440 minecraft:black_concrete
fill 519 251 454 519 260 454 minecraft:black_concrete
fill 520 251 426 520 257 426 minecraft:black_concrete
fill 520 251 431 520 262 433 minecraft:black_concrete
fill 520 251 452 520 257 452 minecraft:black_concrete
fill 520 251 457 524 259 457 minecraft:black_concrete
fill 521 251 428 521 256 430 minecraft:black_concrete
fill 521 251 447 521 252 448 minecraft:black_concrete
fill 537 251 417 537 273 417 minecraft:black_concrete
fill 539 251 418 539 271 418 minecraft:black_concrete
fill 539 251 457 539 272 457 minecraft:black_concrete
fill 540 251 456 541 269 456 minecraft:black_concrete
fill 541 251 418 546 253 418 minecraft:black_concrete
fill 543 251 419 543 253 419 minecraft:black_concrete
fill 543 251 455 546 258 455 minecraft:black_concrete
fill 549 251 456 549 270 456 minecraft:black_concrete
fill 552 251 457 552 273 457 minecraft:black_concrete
fill 555 251 457 557 270 457 minecraft:black_concrete
fill 556 251 448 556 257 451 minecraft:black_concrete
fill 557 251 444 557 273 444 minecraft:black_concrete
fill 557 251 454 557 267 455 minecraft:black_concrete
fill 558 251 424 558 256 424 minecraft:black_concrete
fill 558 251 430 558 272 433 minecraft:black_concrete
fill 558 251 440 558 273 440 minecraft:black_concrete
fill 518 252 422 518 273 422 minecraft:black_concrete
fill 518 252 457 519 269 457 minecraft:black_concrete
fill 519 252 455 519 260 455 minecraft:black_concrete
fill 520 252 425 520 256 425 minecraft:black_concrete
fill 520 252 434 520 265 436 minecraft:black_concrete
fill 520 252 442 520 254 442 minecraft:black_concrete
fill 520 252 453 520 257 453 minecraft:black_concrete
fill 521 252 427 521 255 427 minecraft:black_concrete
fill 521 252 431 521 259 433 minecraft:black_concrete
fill 521 252 449 521 253 450 minecraft:black_concrete
fill 522 252 417 525 257 417 minecraft:black_concrete
fill 525 252 457 525 257 457 minecraft:black_concrete
fill 536 252 417 536 273 417 minecraft:black_concrete
fill 537 252 457 538 273 457 minecraft:black_concrete
fill 538 252 418 538 272 418 minecraft:black_concrete
fill 539 252 456 539 270 456 minecraft:black_concrete
fill 541 252 419 542 254 419 minecraft:black_concrete
fill 541 252 455 542 262 455 minecraft:black_concrete
fill 547 252 455 547 257 455 minecraft:black_concrete
fill 550 252 456 550 270 456 minecraft:black_concrete
fill 553 252 457 554 272 457 minecraft:black_concrete
fill 556 252 447 556 256 447 minecraft:black_concrete
fill 556 252 452 556 260 453 minecraft:black_concrete
fill 556 252 456 557 268 456 minecraft:black_concrete
fill 558 252 423 558 254 423 minecraft:black_concrete
fill 558 252 434 558 272 439 minecraft:black_concrete
fill 519 253 423 519 255 423 minecraft:black_concrete
fill 519 253 456 523 257 456 minecraft:black_concrete
fill 520 253 437 520 259 439 minecraft:black_concrete
fill 520 253 441 520 254 441 minecraft:black_concrete
fill 520 253 454 520 257 454 minecraft:black_concrete
fill 521 253 417 521 273 417 minecraft:black_concrete
fill 521 253 426 521 254 426 minecraft:black_concrete
fill 521 253 434 521 259 435 minecraft:black_concrete
setblock 521 253 448 minecraft:black_concrete
fill 522 253 430 522 255 430 minecraft:black_concrete
fill 535 253 417 535 273 417 minecraft:black_concrete
fill 536 253 457 536 273 457 minecraft:black_concrete
fill 537 253 418 537 272 418 minecraft:black_concrete
fill 538 253 456 538 271 456 minecraft:black_concrete
fill 539 253 417 548 255 417 minecraft:black_concrete
fill 539 253 455 540 266 455 minecraft:black_concrete
fill 540 253 419 540 256 419 minecraft:black_concrete
fill 542 253 454 545 256 454 minecraft:black_concrete
fill 548 253 455 548 256 455 minecraft:black_concrete
fill 551 253 456 555 269 456 minecraft:black_concrete
fill 556 253 454 556 262 454 minecraft:black_concrete
fill 557 253 428 557 257 432 minecraft:black_concrete
fill 557 253 443 557 273 443 minecraft:black_concrete
fill 518 254 421 518 273 421 minecraft:black_concrete
fill 519 254 417 520 273 417 minecraft:black_concrete
fill 520 254 440 520 256 440 minecraft:black_concrete
fill 521 254 436 521 258 436 minecraft:black_concrete
setblock 521 254 450 minecraft:black_concrete
setblock 522 254 429 minecraft:black_concrete
fill 522 254 431 522 256 432 minecraft:black_concrete
fill 524 254 456 524 255 456 minecraft:black_concrete
fill 526 254 417 526 255 417 minecraft:black_concrete
fill 526 254 457 526 256 457 minecraft:black_concrete
fill 534 254 417 534 273 417 minecraft:black_concrete
fill 535 254 457 535 273 457 minecraft:black_concrete
fill 536 254 456 537 271 456 minecraft:black_concrete
fill 538 254 455 538 268 455 minecraft:black_concrete
fill 540 254 454 541 258 454 minecraft:black_concrete
fill 541 254 418 545 255 418 minecraft:black_concrete
fill 549 254 455 549 255 455 minecraft:black_concrete
fill 555 254 455 556 263 455 minecraft:black_concrete
setblock 557 254 427 minecraft:black_concrete
fill 557 254 433 557 271 435 minecraft:black_concrete
fill 520 255 455 521 255 455 minecraft:black_concrete
fill 533 255 417 533 273 417 minecraft:black_concrete
fill 533 255 457 534 273 457 minecraft:black_concrete
fill 535 255 456 535 272 456 minecraft:black_concrete
fill 536 255 418 536 273 418 minecraft:black_concrete
fill 537 255 455 537 269 455 minecraft:black_concrete
setblock 541 255 419 minecraft:black_concrete
fill 554 255 455 554 260 455 minecraft:black_concrete
fill 557 255 436 557 272 438 minecraft:black_concrete
fill 557 255 442 557 273 442 minecraft:black_concrete
fill 558 255 417 558 271 417 minecraft:black_concrete
fill 518 256 417 518 273 418 minecraft:black_concrete
setblock 520 256 419 minecraft:light[level=12]
setblock 520 256 443 minecraft:light[level=12]
setblock 520 256 447 minecraft:black_concrete
setblock 520 256 455 minecraft:black_concrete
setblock 528 256 419 minecraft:light[level=12]
setblock 528 256 427 minecraft:light[level=12]
setblock 528 256 435 minecraft:light[level=12]
setblock 528 256 443 minecraft:light[level=12]
setblock 528 256 451 minecraft:light[level=12]
fill 532 256 417 532 273 417 minecraft:black_concrete
fill 535 256 418 535 273 418 minecraft:black_concrete
setblock 536 256 419 minecraft:light[level=12]
setblock 536 256 427 minecraft:light[level=12]
setblock 536 256 435 minecraft:light[level=12]
setblock 536 256 443 minecraft:light[level=12]
setblock 536 256 451 minecraft:light[level=12]
fill 539 256 417 547 257 417 minecraft:black_concrete
fill 539 256 454 539 258 454 minecraft:black_concrete
fill 541 256 418 544 257 418 minecraft:black_concrete
setblock 544 256 419 minecraft:light[level=12]
setblock 544 256 427 minecraft:light[level=12]
setblock 544 256 435 minecraft:light[level=12]
setblock 544 256 443 minecraft:light[level=12]
setblock 544 256 451 minecraft:light[level=12]
setblock 552 256 419 minecraft:light[level=12]
setblock 552 256 427 minecraft:light[level=12]
setblock 552 256 435 minecraft:light[level=12]
setblock 552 256 443 minecraft:light[level=12]
setblock 552 256 451 minecraft:light[level=12]
fill 553 256 455 553 257 455 minecraft:black_concrete
fill 557 256 417 557 272 417 minecraft:black_concrete
fill 557 256 439 557 273 441 minecraft:black_concrete
fill 518 257 419 518 273 420 minecraft:black_concrete
fill 521 257 429 521 257 430 minecraft:black_concrete
fill 532 257 457 532 273 457 minecraft:black_concrete
fill 534 257 456 534 273 456 minecraft:black_concrete
fill 536 257 455 536 269 455 minecraft:black_concrete
fill 542 257 454 543 257 454 minecraft:black_concrete
fill 519 258 442 519 258 444 minecraft:black_concrete
fill 519 258 446 519 258 449 minecraft:black_concrete
fill 519 258 456 522 258 456 minecraft:black_concrete
setblock 521 258 430 minecraft:black_concrete
fill 522 258 417 524 273 417 minecraft:black_concrete
fill 531 258 417 531 273 417 minecraft:black_concrete
fill 539 258 417 546 259 417 minecraft:black_concrete
fill 541 258 418 543 258 418 minecraft:black_concrete
setblock 542 258 454 minecraft:black_concrete
fill 556 258 449 556 258 451 minecraft:black_concrete
fill 557 258 429 557 258 432 minecraft:black_concrete
fill 558 258 426 558 259 429 minecraft:black_concrete
setblock 519 259 426 minecraft:black_concrete
setblock 519 259 442 minecraft:black_concrete
fill 519 259 456 521 259 456 minecraft:black_concrete
fill 520 259 428 520 259 430 minecraft:black_concrete
fill 530 259 417 530 273 417 minecraft:black_concrete
fill 531 259 457 531 273 457 minecraft:black_concrete
fill 534 259 418 534 273 418 minecraft:black_concrete
fill 541 259 418 542 269 418 minecraft:black_concrete
fill 543 259 455 545 259 455 minecraft:black_concrete
fill 556 259 417 556 272 417 minecraft:black_concrete
fill 556 259 434 556 270 436 minecraft:black_concrete
fill 556 259 450 556 259 451 minecraft:black_concrete
fill 557 259 430 557 269 432 minecraft:black_concrete
setblock 519 260 453 minecraft:black_concrete
fill 519 260 456 520 260 456 minecraft:black_concrete
fill 520 260 429 520 260 430 minecraft:black_concrete
fill 520 260 437 520 267 438 minecraft:black_concrete
fill 520 260 457 523 260 457 minecraft:black_concrete
fill 533 260 418 533 273 418 minecraft:black_concrete
fill 533 260 456 533 273 456 minecraft:black_concrete
fill 539 260 417 545 271 417 minecraft:black_concrete
fill 543 260 455 544 260 455 minecraft:black_concrete
fill 555 260 417 555 273 417 minecraft:black_concrete
fill 556 260 437 556 271 438 minecraft:black_concrete
fill 558 260 418 558 272 418 minecraft:black_concrete
fill 558 260 427 558 260 429 minecraft:black_concrete
setblock 519 261 456 minecraft:black_concrete
setblock 520 261 430 minecraft:black_concrete
fill 520 261 457 522 266 457 minecraft:black_concrete
fill 528 261 417 529 273 417 minecraft:black_concrete
fill 530 261 457 530 273 457 minecraft:black_concrete
fill 532 261 418 532 273 418 minecraft:black_concrete
fill 535 261 455 535 270 455 minecraft:black_concrete
setblock 543 261 455 minecraft:black_concrete
fill 554 261 417 554 273 417 minecraft:black_concrete
fill 556 261 439 556 272 439 minecraft:black_concrete
setblock 556 261 453 minecraft:black_concrete
fill 558 261 428 558 273 429 minecraft:black_concrete
fill 518 262 440 518 272 445 minecraft:black_concrete
fill 519 262 428 519 268 428 minecraft:black_concrete
fill 525 262 417 527 273 417 minecraft:black_concrete
fill 529 262 457 529 273 457 minecraft:black_concrete
fill 531 262 418 531 273 418 minecraft:black_concrete
fill 532 262 456 532 273 456 minecraft:black_concrete
fill 535 262 419 538 270 419 minecraft:black_concrete
fill 547 262 456 547 268 456 minecraft:black_concrete
fill 553 262 417 553 273 417 minecraft:black_concrete
fill 556 262 433 556 269 433 minecraft:black_concrete
fill 556 262 440 556 273 441 minecraft:black_concrete
fill 558 262 419 558 273 419 minecraft:black_concrete
fill 519 263 418 519 272 419 minecraft:black_concrete
fill 519 263 442 519 271 442 minecraft:black_concrete
fill 520 263 418 520 272 418 minecraft:black_concrete
fill 520 263 432 520 263 433 minecraft:black_concrete
fill 530 263 418 530 273 418 minecraft:black_concrete
fill 533 263 419 534 273 419 minecraft:black_concrete
fill 541 263 455 541 264 455 minecraft:black_concrete
fill 548 263 456 548 269 456 minecraft:black_concrete
fill 551 263 417 552 273 417 minecraft:black_concrete
fill 556 263 442 556 273 442 minecraft:black_concrete
fill 558 263 420 558 273 420 minecraft:black_concrete
fill 518 264 446 518 271 446 minecraft:black_concrete
fill 519 264 420 519 273 421 minecraft:black_concrete
setblock 520 264 419 minecraft:light[level=12]
setblock 520 264 427 minecraft:light[level=12]
setblock 520 264 433 minecraft:black_concrete
fill 520 264 439 520 267 439 minecraft:black_concrete
setblock 520 264 443 minecraft:light[level=12]
setblock 520 264 451 minecraft:light[level=12]
fill 521 264 418 522 272 418 minecraft:black_concrete
fill 528 264 418 529 273 418 minecraft:black_concrete
setblock 528 264 419 minecraft:light[level=12]
setblock 528 264 427 minecraft:light[level=12]
setblock 528 264 435 minecraft:light[level=12]
setblock 528 264 443 minecraft:light[level=12]
setblock 528 264 451 minecraft:light[level=12]
fill 528 264 457 528 273 457 minecraft:black_concrete
fill 531 264 419 532 273 419 minecraft:black_concrete
fill 531 264 456 531 273 456 minecraft:black_concrete
fill 534 264 455 534 270 455 minecraft:black_concrete
setblock 536 264 427 minecraft:light[level=12]
setblock 536 264 435 minecraft:light[level=12]
setblock 536 264 443 minecraft:light[level=12]
setblock 536 264 451 minecraft:light[level=12]
fill 539 264 419 539 269 419 minecraft:black_concrete
setblock 544 264 419 minecraft:light[level=12]
setblock 544 264 427 minecraft:light[level=12]
setblock 544 264 435 minecraft:light[level=12]
setblock 544 264 443 minecraft:light[level=12]
setblock 544 264 451 minecraft:light[level=12]
fill 546 264 417 550 272 417 minecraft:black_concrete
setblock 552 264 419 minecraft:light[level=12]
setblock 552 264 427 minecraft:light[level=12]
setblock 552 264 435 minecraft:light[level=12]
setblock 552 264 443 minecraft:light[level=12]
setblock 552 264 451 minecraft:light[level=12]
fill 554 264 455 555 265 455 minecraft:black_concrete
fill 555 264 418 557 272 418 minecraft:black_concrete
fill 555 264 436 555 269 440 minecraft:black_concrete
fill 556 264 443 556 273 444 minecraft:black_concrete
fill 558 264 421 558 273 422 minecraft:black_concrete
fill 558 264 427 558 273 427 minecraft:black_concrete
fill 519 265 422 519 273 423 minecraft:black_concrete
fill 519 265 443 519 270 443 minecraft:black_concrete
fill 523 265 418 527 273 418 minecraft:black_concrete
fill 526 265 457 527 273 457 minecraft:black_concrete
fill 530 265 419 530 273 419 minecraft:black_concrete
fill 530 265 456 530 273 456 minecraft:black_concrete
fill 533 265 455 533 270 455 minecraft:black_concrete
fill 553 265 418 554 272 418 minecraft:black_concrete
fill 555 265 435 555 268 435 minecraft:black_concrete
fill 555 265 441 555 272 442 minecraft:black_concrete
fill 556 265 445 556 273 445 minecraft:black_concrete
fill 557 265 419 557 271 420 minecraft:black_concrete
fill 558 265 423 558 273 426 minecraft:black_concrete
fill 519 266 424 519 270 427 minecraft:black_concrete
fill 520 266 435 520 266 436 minecraft:black_concrete
fill 525 266 457 525 270 457 minecraft:black_concrete
fill 528 266 419 529 273 419 minecraft:black_concrete
fill 532 266 420 536 270 420 minecraft:black_concrete
fill 551 266 418 552 272 418 minecraft:black_concrete
fill 553 266 455 554 266 455 minecraft:black_concrete
fill 555 266 443 555 272 443 minecraft:black_concrete
fill 556 266 432 556 267 432 minecraft:black_concrete
fill 556 266 446 556 272 446 minecraft:black_concrete
fill 557 266 421 557 272 422 minecraft:black_concrete
setblock 557 266 452 minecraft:black_concrete
fill 518 267 447 518 269 447 minecraft:black_concrete
fill 520 267 419 520 270 420 minecraft:black_concrete
setblock 520 267 436 minecraft:black_concrete
fill 520 267 457 521 267 457 minecraft:black_concrete
fill 526 267 419 527 273 419 minecraft:black_concrete
fill 529 267 456 529 272 456 minecraft:black_concrete
fill 530 267 420 531 273 420 minecraft:black_concrete
fill 532 267 455 532 270 455 minecraft:black_concrete
fill 537 267 420 537 268 420 minecraft:black_concrete
setblock 539 267 455 minecraft:black_concrete
setblock 543 267 418 minecraft:black_concrete
fill 549 267 418 550 272 418 minecraft:black_concrete
fill 554 267 438 554 269 441 minecraft:black_concrete
fill 555 267 419 555 270 419 minecraft:black_concrete
fill 555 267 444 555 272 444 minecraft:black_concrete
fill 556 267 447 557 270 447 minecraft:black_concrete
fill 557 267 423 557 273 424 minecraft:black_concrete
fill 557 267 446 557 273 446 minecraft:black_concrete
fill 557 267 448 557 268 449 minecraft:black_concrete
setblock 518 268 456 minecraft:black_concrete
fill 519 268 430 519 268 433 minecraft:black_concrete
fill 520 268 421 520 270 421 minecraft:black_concrete
setblock 520 268 457 minecraft:black_concrete
fill 521 268 419 521 269 419 minecraft:black_concrete
fill 524 268 419 525 271 419 minecraft:black_concrete
fill 529 268 420 529 273 420 minecraft:black_concrete
fill 548 268 418 548 272 418 minecraft:black_concrete
fill 553 268 419 554 270 419 minecraft:black_concrete
fill 554 268 442 554 271 442 minecraft:black_concrete
fill 555 268 445 555 271 445 minecraft:black_concrete
fill 556 268 419 556 269 420 minecraft:black_concrete
fill 557 268 425 557 273 425 minecraft:black_concrete
fill 557 268 429 557 269 429 minecraft:black_concrete
setblock 519 269 433 minecraft:black_concrete
fill 520 269 422 520 271 422 minecraft:black_concrete
fill 522 269 419 523 269 419 minecraft:black_concrete
fill 528 269 420 528 272 420 minecraft:black_concrete
fill 550 269 450 557 269 450 minecraft:black_concrete
fill 552 269 419 552 270 419 minecraft:black_concrete
fill 554 269 443 554 270 443 minecraft:black_concrete
fill 556 269 421 556 270 421 minecraft:black_concrete
setblock 556 269 456 minecraft:black_concrete
fill 557 269 426 557 270 427 minecraft:black_concrete
fill 557 269 448 557 270 448 minecraft:black_concrete
fill 518 270 450 552 270 450 minecraft:black_concrete
fill 518 270 454 557 270 454 minecraft:black_concrete
fill 519 270 434 530 271 434 minecraft:black_concrete
fill 519 270 436 519 270 440 minecraft:black_concrete
fill 519 270 446 519 271 446 minecraft:black_concrete
fill 520 270 426 556 270 426 minecraft:black_concrete
fill 520 270 438 520 271 438 minecraft:black_concrete
fill 520 270 442 553 270 442 minecraft:black_concrete
fill 521 270 422 556 270 422 minecraft:black_concrete
fill 527 270 420 527 271 420 minecraft:black_concrete
fill 551 270 456 554 270 456 minecraft:black_concrete
fill 554 270 439 554 270 441 minecraft:black_concrete
fill 555 270 437 555 270 440 minecraft:black_concrete
fill 557 270 431 557 270 432 minecraft:black_concrete
fill 558 270 443 558 271 449 minecraft:black_concrete
fill 518 271 450 519 271 450 minecraft:black_concrete
fill 518 271 454 533 271 454 minecraft:black_concrete
fill 519 271 424 519 272 426 minecraft:black_concrete
fill 519 271 430 546 271 430 minecraft:black_concrete
setblock 519 271 438 minecraft:black_concrete
fill 520 271 426 521 271 426 minecraft:black_concrete
fill 520 271 442 546 271 442 minecraft:black_concrete
fill 520 271 446 534 271 446 minecraft:black_concrete
setblock 521 271 422 minecraft:black_concrete
fill 521 271 438 555 271 438 minecraft:black_concrete
fill 531 271 434 535 271 434 minecraft:black_concrete
fill 532 271 420 535 271 420 minecraft:black_concrete
fill 535 271 419 537 271 419 minecraft:black_concrete
fill 535 271 446 535 271 455 minecraft:white_wool
fill 536 271 446 551 271 446 minecraft:black_concrete
fill 541 271 418 547 271 418 minecraft:black_concrete
fill 542 271 434 556 271 434 minecraft:black_concrete
fill 551 271 456 552 271 456 minecraft:black_concrete
fill 555 271 439 555 271 440 minecraft:black_concrete
fill 555 271 457 556 271 457 minecraft:black_concrete
setblock 556 271 436 minecraft:black_concrete
fill 557 271 426 557 272 426 minecraft:black_concrete
fill 557 271 447 557 272 447 minecraft:black_concrete
fill 518 272 428 518 272 431 minecraft:black_concrete
fill 518 272 436 518 272 438 minecraft:black_concrete
fill 519 272 427 519 272 456 minecraft:white_wool
setblock 520 272 419 minecraft:light[level=12]
setblock 520 272 427 minecraft:light[level=12]
setblock 520 272 435 minecraft:light[level=12]
setblock 520 272 443 minecraft:light[level=12]
setblock 520 272 451 minecraft:light[level=12]
setblock 525 272 419 minecraft:black_concrete
fill 527 272 420 527 273 423 minecraft:white_wool
setblock 528 272 427 minecraft:light[level=12]
setblock 528 272 435 minecraft:light[level=12]
setblock 528 272 443 minecraft:light[level=12]
setblock 528 272 451 minecraft:light[level=12]
fill 531 272 421 531 272 455 minecraft:white_wool
fill 532 272 420 533 272 420 minecraft:black_concrete
fill 535 272 419 536 272 419 minecraft:black_concrete
fill 535 272 420 535 272 448 minecraft:white_wool
setblock 536 272 427 minecraft:light[level=12]
setblock 536 272 435 minecraft:light[level=12]
setblock 536 272 443 minecraft:light[level=12]
setblock 536 272 451 minecraft:light[level=12]
setblock 536 272 456 minecraft:black_concrete
fill 539 272 417 540 272 417 minecraft:black_concrete
fill 539 272 418 539 273 418 minecraft:white_wool
fill 543 272 417 543 272 457 minecraft:white_wool
setblock 544 272 419 minecraft:light[level=12]
setblock 544 272 427 minecraft:light[level=12]
fill 544 272 430 557 272 430 minecraft:black_concrete
setblock 544 272 435 minecraft:light[level=12]
setblock 544 272 443 minecraft:light[level=12]
setblock 544 272 451 minecraft:light[level=12]
fill 546 272 418 547 272 418 minecraft:black_concrete
fill 546 272 457 550 272 457 minecraft:black_concrete
fill 547 272 419 547 273 419 minecraft:white_wool
fill 549 272 446 555 272 446 minecraft:black_concrete
setblock 552 272 419 minecraft:light[level=12]
setblock 552 272 427 minecraft:light[level=12]
setblock 552 272 435 minecraft:light[level=12]
setblock 552 272 443 minecraft:light[level=12]
setblock 552 272 451 minecraft:light[level=12]
fill 555 272 419 555 272 429 minecraft:white_wool
fill 555 272 431 555 272 439 minecraft:white_wool
setblock 555 272 440 minecraft:black_concrete
setblock 555 272 445 minecraft:white_wool
fill 555 272 447 555 272 457 minecraft:white_wool
setblock 556 272 438 minecraft:black_concrete
setblock 557 272 420 minecraft:black_concrete
setblock 557 272 435 minecraft:black_concrete
fill 558 272 443 558 272 448 minecraft:black_concrete
fill 518 273 428 518 273 429 minecraft:black_concrete
fill 518 273 440 518 273 444 minecraft:black_concrete
setblock 519 273 418 minecraft:white_wool
setblock 519 273 419 minecraft:black_concrete
fill 519 273 424 519 273 425 minecraft:black_concrete
fill 523 273 419 523 273 456 minecraft:white_wool
fill 527 273 424 527 273 456 minecraft:white_wool
fill 531 273 421 531 273 422 minecraft:white_wool
setblock 532 273 420 minecraft:black_concrete
setblock 539 273 417 minecraft:white_wool
fill 539 273 419 539 273 431 minecraft:white_wool
fill 539 273 438 539 273 448 minecraft:white_wool
fill 543 273 417 543 273 423 minecraft:white_wool
fill 547 273 417 547 273 418 minecraft:white_wool
fill 547 273 420 547 273 456 minecraft:white_wool
fill 548 273 417 550 273 417 minecraft:black_concrete
fill 548 273 457 550 273 457 minecraft:black_concrete
fill 551 273 418 551 273 446 minecraft:white_wool
fill 555 273 418 555 273 420 minecraft:white_wool
setblock 557 273 422 minecraft:black_concrete
fill 557 273 438 558 273 438 minecraft:black_concrete
setblock 558 273 430 minecraft:black_concrete
fill 558 273 435 558 273 437 minecraft:black_concrete
setblock 558 273 439 minecraft:black_concrete
fill 558 273 443 558 273 447 minecraft:black_concrete
fill 523 279 435 526 280 435 minecraft:white_wool
fill 524 279 430 524 280 433 minecraft:black_concrete
fill 524 279 434 528 280 434 minecraft:white_wool
fill 524 279 436 524 280 438 minecraft:white_wool
fill 524 279 439 528 280 440 minecraft:black_concrete
fill 525 279 428 526 280 432 minecraft:black_concrete
fill 525 279 433 530 280 433 minecraft:white_wool
fill 525 279 436 525 280 437 minecraft:white_wool
fill 525 279 438 529 280 438 minecraft:black_concrete
fill 525 279 441 527 280 442 minecraft:black_concrete
fill 526 279 426 536 280 426 minecraft:white_wool
fill 526 279 427 533 280 427 minecraft:black_concrete
fill 526 279 436 530 280 437 minecraft:black_concrete
fill 526 279 443 527 280 444 minecraft:black_concrete
fill 527 279 425 534 280 425 minecraft:white_wool
fill 527 279 428 528 280 431 minecraft:black_concrete
fill 527 279 432 536 280 432 minecraft:white_wool
fill 527 279 435 533 280 435 minecraft:black_concrete
fill 527 279 445 527 280 445 minecraft:black_concrete
fill 528 279 424 532 280 424 minecraft:white_wool
fill 528 279 441 528 280 441 minecraft:black_concrete
fill 528 279 442 530 280 446 minecraft:white_wool
fill 529 279 423 539 280 423 minecraft:black_concrete
fill 529 279 428 535 280 430 minecraft:black_concrete
fill 529 279 431 534 280 431 minecraft:white_wool
fill 529 279 434 536 279 434 minecraft:black_concrete
fill 529 279 439 529 280 439 minecraft:black_concrete
fill 529 279 440 530 280 441 minecraft:white_wool
fill 529 279 447 530 280 447 minecraft:white_wool
fill 530 279 422 538 280 422 minecraft:black_concrete
fill 530 279 438 531 280 439 minecraft:white_wool
fill 530 279 448 530 280 448 minecraft:white_wool
fill 531 279 433 535 280 433 minecraft:black_concrete
fill 531 279 436 531 280 436 minecraft:black_concrete
fill 531 279 437 533 280 437 minecraft:white_wool
fill 531 279 440 531 280 440 minecraft:white_wool
fill 531 279 441 534 280 448 minecraft:black_concrete
fill 532 279 421 536 280 421 minecraft:black_concrete
fill 532 279 436 534 280 436 minecraft:white_wool
fill 532 279 438 532 280 438 minecraft:white_wool
fill 532 279 439 534 280 440 minecraft:black_concrete
fill 532 279 449 536 280 449 minecraft:black_concrete
fill 533 279 424 539 280 424 minecraft:black_concrete
fill 533 279 438 535 280 438 minecraft:black_concrete
fill 534 279 420 535 280 420 minecraft:black_concrete
fill 534 279 427 537 280 427 minecraft:white_wool
fill 534 279 435 536 279 435 minecraft:white_wool
fill 534 279 437 536 279 437 minecraft:black_concrete
fill 534 279 450 537 280 450 minecraft:black_concrete
fill 535 279 425 540 280 425 minecraft:black_concrete
fill 535 279 431 538 280 431 minecraft:black_concrete
fill 535 279 436 536 279 436 minecraft:black_concrete
fill 535 279 439 535 280 439 minecraft:black_concrete
fill 535 279 440 536 280 445 minecraft:white_wool
fill 535 279 446 535 280 448 minecraft:black_concrete
fill 536 279 420 540 280 420 minecraft:white_wool
fill 536 279 428 538 280 428 minecraft:white_wool
fill 536 279 429 536 280 430 minecraft:black_concrete
fill 536 279 433 537 279 433 minecraft:white_wool
fill 536 279 438 536 280 439 minecraft:white_wool
fill 536 279 446 538 280 447 minecraft:white_wool
fill 536 279 448 536 280 448 minecraft:black_concrete
fill 537 279 421 541 280 421 minecraft:white_wool
fill 537 279 426 540 280 426 minecraft:black_concrete
fill 537 279 429 538 280 429 minecraft:white_wool
fill 537 279 430 537 280 430 minecraft:black_concrete
fill 537 279 432 538 279 432 minecraft:black_concrete
fill 537 279 437 537 279 438 minecraft:white_wool
fill 537 279 439 538 280 443 minecraft:black_concrete
fill 537 279 444 537 280 445 minecraft:white_wool
fill 537 279 448 539 280 449 minecraft:white_wool
fill 538 279 427 541 280 427 minecraft:black_concrete
fill 538 279 430 539 280 430 minecraft:white_wool
setblock 538 279 438 minecraft:black_concrete
fill 538 279 444 541 280 445 minecraft:black_concrete
fill 538 279 450 542 280 450 minecraft:white_wool
fill 539 279 419 539 280 419 minecraft:white_wool
fill 539 279 422 541 280 422 minecraft:white_wool
fill 539 279 428 541 280 429 minecraft:black_concrete
fill 539 279 431 539 279 432 minecraft:white_wool
fill 539 279 438 539 279 440 minecraft:white_wool
fill 539 279 441 539 280 443 minecraft:black_concrete
fill 539 279 446 545 280 447 minecraft:black_concrete
fill 539 279 451 539 280 451 minecraft:white_wool
fill 540 279 423 542 280 424 minecraft:white_wool
fill 540 279 430 540 279 432 minecraft:black_concrete
fill 540 279 438 541 279 439 minecraft:black_concrete
fill 540 279 440 540 280 442 minecraft:white_wool
fill 540 279 443 540 280 443 minecraft:black_concrete
fill 540 279 448 548 280 448 minecraft:black_concrete
fill 540 279 449 541 280 449 minecraft:white_wool
fill 541 279 420 544 280 420 minecraft:black_concrete
fill 541 279 425 543 280 426 minecraft:white_wool
fill 541 279 430 541 280 431 minecraft:black_concrete
fill 541 279 432 541 279 433 minecraft:white_wool
fill 541 279 437 542 279 437 minecraft:white_wool
fill 541 279 440 554 280 440 minecraft:black_concrete
fill 541 279 441 541 280 443 minecraft:white_wool
fill 542 279 421 546 280 422 minecraft:black_concrete
fill 542 279 427 542 280 432 minecraft:white_wool
fill 542 279 433 543 279 434 minecraft:black_concrete
fill 542 279 435 544 279 435 minecraft:white_wool
fill 542 279 436 549 279 436 minecraft:black_concrete
fill 542 279 438 551 280 438 minecraft:white_wool
fill 542 279 439 543 280 439 minecraft:black_concrete
fill 542 279 441 553 280 441 minecraft:black_concrete
fill 542 279 442 542 280 444 minecraft:white_wool
fill 542 279 445 543 280 445 minecraft:black_concrete
fill 542 279 449 546 280 449 minecraft:black_concrete
fill 543 279 423 547 280 424 minecraft:black_concrete
fill 543 279 427 543 280 430 minecraft:white_wool
fill 543 279 431 545 280 432 minecraft:black_concrete
fill 543 279 437 547 280 437 minecraft:black_concrete
fill 543 279 442 553 280 442 minecraft:black_concrete
fill 543 279 443 544 280 444 minecraft:white_wool
fill 543 279 450 544 280 450 minecraft:black_concrete
fill 544 279 425 546 280 430 minecraft:black_concrete
fill 544 279 433 544 280 433 minecraft:black_concrete
fill 544 279 434 546 280 434 minecraft:white_wool
fill 544 279 439 549 280 439 minecraft:white_wool
fill 544 279 445 551 280 445 minecraft:white_wool
fill 545 279 433 547 280 433 minecraft:white_wool
fill 545 279 435 551 280 435 minecraft:black_concrete
fill 545 279 443 552 280 443 minecraft:black_concrete
fill 545 279 444 552 280 444 minecraft:white_wool
fill 546 279 431 546 280 431 minecraft:black_concrete
fill 546 279 432 548 280 432 minecraft:white_wool
fill 546 279 446 550 280 446 minecraft:white_wool
fill 546 279 447 549 280 447 minecraft:black_concrete
fill 547 279 422 547 280 422 minecraft:black_concrete
fill 547 279 425 547 280 429 minecraft:black_concrete
fill 547 279 430 548 280 431 minecraft:white_wool
fill 547 279 434 552 280 434 minecraft:black_concrete
fill 548 279 422 548 280 429 minecraft:white_wool
fill 548 279 433 552 280 433 minecraft:black_concrete
fill 548 279 437 553 280 437 minecraft:white_wool
fill 549 279 423 549 280 430 minecraft:white_wool
fill 549 279 431 553 280 432 minecraft:black_concrete
fill 550 279 424 550 280 428 minecraft:white_wool
fill 550 279 429 553 280 430 minecraft:black_concrete
fill 550 279 436 554 280 436 minecraft:white_wool
fill 550 279 439 554 280 439 minecraft:black_concrete
fill 551 279 425 551 280 428 minecraft:black_concrete
fill 552 279 426 552 280 428 minecraft:black_concrete
fill 552 279 435 555 280 435 minecraft:white_wool
fill 552 279 438 554 280 438 minecraft:black_concrete
fill 553 279 428 553 280 428 minecraft:black_concrete
fill 553 279 433 554 280 434 minecraft:white_wool
fill 554 279 430 554 280 431 minecraft:black_concrete
fill 554 279 432 554 280 432 minecraft:white_wool
fill 554 279 437 554 280 437 minecraft:black_concrete
fill 518 280 417 522 280 457 minecraft:black_concrete
fill 523 280 417 523 280 434 minecraft:black_concrete
fill 523 280 436 523 280 457 minecraft:black_concrete
fill 524 280 417 524 280 429 minecraft:black_concrete
fill 524 280 441 524 280 457 minecraft:black_concrete
fill 525 280 417 525 280 427 minecraft:black_concrete
fill 525 280 443 525 280 457 minecraft:black_concrete
fill 526 280 417 526 280 425 minecraft:black_concrete
fill 526 280 445 526 280 457 minecraft:black_concrete
fill 527 280 417 527 280 424 minecraft:black_concrete
fill 527 280 446 527 280 457 minecraft:black_concrete
fill 528 280 417 528 280 423 minecraft:black_concrete
fill 528 280 447 528 280 457 minecraft:black_concrete
fill 529 280 417 529 280 422 minecraft:black_concrete
fill 529 280 434 535 280 434 minecraft:black_concrete
fill 529 280 448 529 280 457 minecraft:black_concrete
fill 530 280 417 531 280 421 minecraft:black_concrete
fill 530 280 449 531 280 457 minecraft:black_concrete
fill 532 280 417 533 280 420 minecraft:black_concrete
fill 532 280 450 533 280 457 minecraft:black_concrete
fill 534 280 417 538 280 419 minecraft:black_concrete
fill 534 280 435 535 280 435 minecraft:white_wool
fill 534 280 437 535 280 437 minecraft:black_concrete
fill 534 280 451 538 280 457 minecraft:black_concrete
setblock 535 280 436 minecraft:black_concrete
fill 536 280 433 536 280 437 minecraft:crying_obsidian
fill 537 280 432 537 280 433 minecraft:crying_obsidian
fill 537 280 437 537 280 438 minecraft:crying_obsidian
fill 538 280 432 541 280 432 minecraft:crying_obsidian
fill 538 280 438 541 280 438 minecraft:crying_obsidian
fill 539 280 417 558 280 418 minecraft:black_concrete
setblock 539 280 431 minecraft:white_wool
fill 539 280 439 539 280 440 minecraft:white_wool
fill 539 280 452 558 280 457 minecraft:black_concrete
fill 540 280 419 558 280 419 minecraft:black_concrete
fill 540 280 430 540 280 431 minecraft:black_concrete
fill 540 280 439 541 280 439 minecraft:black_concrete
fill 540 280 451 558 280 451 minecraft:black_concrete
fill 541 280 433 542 280 433 minecraft:crying_obsidian
fill 541 280 437 542 280 437 minecraft:crying_obsidian
fill 542 280 434 542 280 436 minecraft:crying_obsidian
fill 543 280 433 543 280 434 minecraft:black_concrete
fill 543 280 435 544 280 435 minecraft:white_wool
fill 543 280 436 549 280 436 minecraft:black_concrete
fill 545 280 420 558 280 420 minecraft:black_concrete
fill 545 280 450 558 280 450 minecraft:black_concrete
fill 547 280 421 558 280 421 minecraft:black_concrete
fill 547 280 449 558 280 449 minecraft:black_concrete
fill 549 280 422 558 280 422 minecraft:black_concrete
fill 549 280 448 558 280 448 minecraft:black_concrete
fill 550 280 423 558 280 423 minecraft:black_concrete
fill 550 280 447 558 280 447 minecraft:black_concrete
fill 551 280 424 558 280 424 minecraft:black_concrete
fill 551 280 446 558 280 446 minecraft:black_concrete
fill 552 280 425 558 280 425 minecraft:black_concrete
fill 552 280 445 558 280 445 minecraft:black_concrete
fill 553 280 426 558 280 427 minecraft:black_concrete
fill 553 280 443 558 280 444 minecraft:black_concrete
fill 554 280 428 558 280 429 minecraft:black_concrete
fill 554 280 441 558 280 442 minecraft:black_concrete
fill 555 280 430 558 280 434 minecraft:black_concrete
fill 555 280 436 558 280 440 minecraft:black_concrete
fill 556 280 435 558 280 435 minecraft:black_concrete
fill 518 284 417 518 288 434 minecraft:black_concrete
fill 518 284 448 518 285 457 minecraft:black_concrete
fill 519 284 417 530 285 417 minecraft:black_concrete
fill 519 284 422 519 284 432 minecraft:black_concrete
fill 519 284 449 519 284 457 minecraft:black_concrete
fill 520 284 418 528 284 418 minecraft:black_concrete
fill 520 284 422 520 287 424 minecraft:black_concrete
fill 520 284 427 520 284 430 minecraft:black_concrete
fill 520 284 432 520 297 432 minecraft:white_wool
fill 520 284 452 520 289 457 minecraft:black_concrete
fill 521 284 423 521 287 423 minecraft:black_concrete
fill 521 284 455 532 285 457 minecraft:black_concrete
fill 522 284 454 530 284 454 minecraft:black_concrete
fill 533 284 456 535 286 457 minecraft:black_concrete
fill 536 284 457 550 285 457 minecraft:black_concrete
fill 537 284 450 537 300 450 minecraft:white_wool
fill 538 284 456 548 285 456 minecraft:black_concrete
fill 541 284 455 546 285 455 minecraft:black_concrete
fill 544 284 417 547 286 417 minecraft:black_concrete
fill 556 284 428 558 284 431 minecraft:black_concrete
fill 557 284 424 558 284 427 minecraft:black_concrete
fill 557 284 432 558 298 434 minecraft:black_concrete
fill 558 284 420 558 300 423 minecraft:black_concrete
fill 558 284 435 558 300 437 minecraft:black_concrete
fill 558 284 449 558 284 454 minecraft:black_concrete
fill 518 285 435 518 300 435 minecraft:black_concrete
fill 519 285 423 519 286 433 minecraft:black_concrete
fill 519 285 450 519 287 457 minecraft:black_concrete
fill 520 285 418 527 285 418 minecraft:black_concrete
setblock 520 285 429 minecraft:black_concrete
fill 520 285 451 520 286 451 minecraft:black_concrete
fill 522 285 454 529 285 454 minecraft:black_concrete
fill 536 285 456 537 287 456 minecraft:black_concrete
fill 540 285 455 540 287 455 minecraft:black_concrete
fill 543 285 417 543 300 417 minecraft:black_concrete
fill 556 285 429 558 285 431 minecraft:black_concrete
fill 557 285 425 558 285 428 minecraft:black_concrete
fill 558 285 424 558 300 424 minecraft:black_concrete
fill 558 285 450 558 285 456 minecraft:black_concrete
fill 518 286 449 518 288 457 minecraft:black_concrete
fill 519 286 417 526 286 418 minecraft:black_concrete
fill 519 286 422 519 287 422 minecraft:black_concrete
fill 521 286 422 521 287 422 minecraft:black_concrete
fill 521 286 424 521 287 424 minecraft:black_concrete
fill 521 286 454 528 286 457 minecraft:black_concrete
fill 527 286 417 529 287 417 minecraft:black_concrete
fill 529 286 455 531 286 457 minecraft:black_concrete
fill 532 286 456 532 288 457 minecraft:black_concrete
fill 536 286 457 549 286 457 minecraft:black_concrete
fill 538 286 456 547 287 456 minecraft:black_concrete
fill 541 286 455 545 286 455 minecraft:black_concrete
fill 557 286 426 558 286 431 minecraft:black_concrete
fill 557 286 435 557 299 435 minecraft:black_concrete
fill 558 286 417 558 300 419 minecraft:black_concrete
fill 558 286 425 558 300 425 minecraft:black_concrete
fill 558 286 451 558 287 457 minecraft:black_concrete
fill 519 287 417 525 288 418 minecraft:black_concrete
fill 519 287 423 519 287 424 minecraft:black_concrete
fill 519 287 427 519 287 433 minecraft:black_concrete
fill 521 287 454 527 287 457 minecraft:black_concrete
fill 526 287 417 526 299 417 minecraft:black_concrete
fill 528 287 455 530 287 457 minecraft:black_concrete
fill 531 287 456 531 289 457 minecraft:black_concrete
fill 533 287 456 533 287 457 minecraft:black_concrete
fill 534 287 457 548 288 457 minecraft:black_concrete
fill 541 287 455 544 287 455 minecraft:black_concrete
fill 542 287 417 542 300 417 minecraft:black_concrete
fill 544 287 417 546 287 417 minecraft:black_concrete
fill 557 287 417 557 300 417 minecraft:black_concrete
fill 557 287 427 558 287 431 minecraft:black_concrete
fill 558 287 426 558 300 426 minecraft:black_concrete
fill 518 288 436 518 300 436 minecraft:black_concrete
fill 519 288 430 519 288 433 minecraft:black_concrete
fill 519 288 451 519 300 457 minecraft:black_concrete
setblock 520 288 419 minecraft:light[level=12]
setblock 520 288 427 minecraft:light[level=12]
setblock 520 288 435 minecraft:light[level=12]
setblock 520 288 443 minecraft:light[level=12]
setblock 520 288 451 minecraft:light[level=12]
fill 521 288 454 526 288 457 minecraft:black_concrete
fill 527 288 417 528 288 417 minecraft:black_concrete
fill 527 288 455 529 288 457 minecraft:black_concrete
setblock 528 288 419 minecraft:light[level=12]
setblock 528 288 427 minecraft:light[level=12]
setblock 528 288 435 minecraft:light[level=12]
setblock 528 288 443 minecraft:light[level=12]
setblock 528 288 451 minecraft:light[level=12]
fill 530 288 456 530 290 457 minecraft:black_concrete
fill 533 288 457 533 300 457 minecraft:black_concrete
setblock 536 288 419 minecraft:light[level=12]
setblock 536 288 427 minecraft:light[level=12]
setblock 536 288 435 minecraft:light[level=12]
setblock 536 288 443 minecraft:light[level=12]
setblock 536 288 451 minecraft:light[level=12]
fill 537 288 456 546 288 456 minecraft:black_concrete
fill 541 288 455 542 288 455 minecraft:black_concrete
fill 544 288 417 545 300 417 minecraft:black_concrete
setblock 544 288 419 minecraft:light[level=12]
setblock 544 288 427 minecraft:light[level=12]
setblock 544 288 435 minecraft:light[level=12]
setblock 544 288 443 minecraft:light[level=12]
setblock 544 288 451 minecraft:light[level=12]
setblock 552 288 419 minecraft:light[level=12]
setblock 552 288 427 minecraft:light[level=12]
setblock 552 288 435 minecraft:light[level=12]
setblock 552 288 443 minecraft:light[level=12]
setblock 552 288 451 minecraft:light[level=12]
fill 557 288 428 558 288 431 minecraft:black_concrete
fill 557 288 457 558 300 457 minecraft:black_concrete
fill 558 288 427 558 300 427 minecraft:black_concrete
fill 558 288 452 558 289 456 minecraft:black_concrete
fill 518 289 417 518 300 422 minecraft:black_concrete
fill 518 289 427 518 289 434 minecraft:black_concrete
fill 518 289 450 518 300 457 minecraft:black_concrete
fill 519 289 417 519 300 419 minecraft:black_concrete
fill 520 289 417 524 298 418 minecraft:black_concrete
fill 521 289 455 528 289 457 minecraft:black_concrete
fill 522 289 454 525 289 454 minecraft:black_concrete
fill 525 289 417 525 300 417 minecraft:black_concrete
fill 527 289 417 527 299 417 minecraft:black_concrete
fill 529 289 456 529 292 457 minecraft:black_concrete
fill 532 289 457 532 300 457 minecraft:black_concrete
fill 534 289 457 547 290 457 minecraft:black_concrete
fill 537 289 456 545 289 456 minecraft:black_concrete
fill 541 289 417 541 300 417 minecraft:black_concrete
fill 556 289 417 556 300 417 minecraft:black_concrete
fill 557 289 429 558 289 431 minecraft:black_concrete
fill 558 289 428 558 300 428 minecraft:black_concrete
fill 558 289 438 558 300 438 minecraft:black_concrete
fill 518 290 428 518 290 434 minecraft:black_concrete
fill 518 290 437 518 300 437 minecraft:black_concrete
fill 520 290 453 520 298 457 minecraft:black_concrete
fill 521 290 455 527 290 457 minecraft:black_concrete
fill 522 290 454 523 290 454 minecraft:black_concrete
fill 528 290 456 528 295 457 minecraft:black_concrete
fill 531 290 457 531 300 457 minecraft:black_concrete
fill 537 290 456 544 290 456 minecraft:black_concrete
fill 540 290 417 540 300 417 minecraft:black_concrete
fill 555 290 417 555 300 417 minecraft:black_concrete
fill 556 290 457 556 300 457 minecraft:black_concrete
fill 557 290 430 558 291 431 minecraft:black_concrete
fill 558 290 429 558 300 429 minecraft:black_concrete
fill 558 290 453 558 300 456 minecraft:black_concrete
fill 518 291 429 518 298 434 minecraft:black_concrete
fill 518 291 438 518 300 438 minecraft:black_concrete
fill 519 291 420 519 300 420 minecraft:black_concrete
fill 521 291 455 526 292 457 minecraft:black_concrete
fill 527 291 456 527 296 457 minecraft:black_concrete
fill 530 291 457 530 300 457 minecraft:black_concrete
fill 534 291 457 546 295 457 minecraft:black_concrete
fill 536 291 456 543 293 456 minecraft:black_concrete
fill 539 291 417 539 300 417 minecraft:black_concrete
fill 546 291 417 546 300 417 minecraft:black_concrete
fill 554 291 417 554 300 417 minecraft:black_concrete
fill 555 291 457 555 300 457 minecraft:black_concrete
fill 557 291 418 557 300 418 minecraft:black_concrete
fill 557 291 436 557 300 436 minecraft:black_concrete
fill 558 291 439 558 300 439 minecraft:black_concrete
fill 558 291 452 558 300 452 minecraft:black_concrete
fill 518 292 423 518 300 423 minecraft:black_concrete
fill 518 292 439 518 300 440 minecraft:black_concrete
fill 518 292 449 518 300 449 minecraft:black_concrete
fill 519 292 421 519 300 421 minecraft:black_concrete
fill 519 292 434 519 297 437 minecraft:black_concrete
fill 537 292 417 538 300 417 minecraft:black_concrete
fill 547 292 417 547 300 417 minecraft:black_concrete
fill 552 292 417 553 300 417 minecraft:black_concrete
fill 556 292 418 556 300 418 minecraft:black_concrete
fill 557 292 419 557 300 421 minecraft:black_concrete
fill 557 292 431 558 298 431 minecraft:black_concrete
fill 557 292 437 557 300 437 minecraft:black_concrete
fill 557 292 456 557 300 456 minecraft:black_concrete
fill 558 292 430 558 300 430 minecraft:black_concrete
fill 558 292 440 558 300 440 minecraft:black_concrete
fill 518 293 424 518 300 425 minecraft:black_concrete
fill 518 293 441 518 300 443 minecraft:black_concrete
fill 518 293 448 518 300 448 minecraft:black_concrete
fill 519 293 438 519 300 439 minecraft:black_concrete
fill 520 293 419 521 299 419 minecraft:black_concrete
fill 520 293 452 520 297 452 minecraft:black_concrete
fill 521 293 455 525 294 457 minecraft:black_concrete
fill 526 293 456 526 297 457 minecraft:black_concrete
fill 529 293 457 529 299 457 minecraft:black_concrete
fill 535 293 417 536 300 417 minecraft:black_concrete
fill 535 293 456 535 299 456 minecraft:black_concrete
fill 540 293 418 542 300 418 minecraft:black_concrete
fill 548 293 417 551 300 417 minecraft:black_concrete
fill 554 293 418 555 300 418 minecraft:black_concrete
fill 554 293 457 554 300 457 minecraft:black_concrete
fill 556 293 456 556 300 456 minecraft:black_concrete
fill 557 293 422 557 300 423 minecraft:black_concrete
fill 557 293 430 557 298 430 minecraft:black_concrete
fill 557 293 438 557 300 438 minecraft:black_concrete
fill 557 293 455 557 300 455 minecraft:black_concrete
fill 558 293 441 558 300 441 minecraft:black_concrete
fill 518 294 426 518 300 426 minecraft:black_concrete
fill 518 294 444 518 300 447 minecraft:black_concrete
fill 519 294 422 519 300 422 minecraft:black_concrete
fill 519 294 433 519 295 433 minecraft:black_concrete
fill 519 294 440 519 300 442 minecraft:black_concrete
fill 519 294 450 519 300 450 minecraft:black_concrete
fill 520 294 420 520 300 420 minecraft:black_concrete
fill 525 294 418 525 297 418 minecraft:black_concrete
fill 528 294 417 528 299 417 minecraft:black_concrete
fill 534 294 417 534 300 417 minecraft:black_concrete
fill 534 294 456 534 298 456 minecraft:black_concrete
fill 536 294 456 542 295 456 minecraft:black_concrete
fill 538 294 418 539 300 418 minecraft:black_concrete
fill 543 294 418 544 300 418 minecraft:black_concrete
fill 552 294 418 553 300 418 minecraft:black_concrete
fill 553 294 457 553 300 457 minecraft:black_concrete
fill 555 294 419 556 300 419 minecraft:black_concrete
fill 556 294 420 556 300 420 minecraft:black_concrete
fill 557 294 424 557 300 425 minecraft:black_concrete
fill 557 294 439 557 300 440 minecraft:black_concrete
fill 557 294 454 557 300 454 minecraft:black_concrete
fill 558 294 442 558 300 443 minecraft:black_concrete
fill 558 294 451 558 300 451 minecraft:black_concrete
fill 518 295 427 518 300 428 minecraft:black_concrete
fill 519 295 423 519 300 423 minecraft:black_concrete
fill 519 295 443 519 300 449 minecraft:black_concrete
fill 520 295 438 520 298 440 minecraft:black_concrete
fill 521 295 455 524 295 457 minecraft:black_concrete
fill 522 295 419 522 298 419 minecraft:black_concrete
fill 525 295 456 525 298 457 minecraft:black_concrete
fill 529 295 417 533 299 417 minecraft:black_concrete
fill 533 295 456 533 297 456 minecraft:black_concrete
fill 536 295 418 537 300 418 minecraft:black_concrete
fill 545 295 418 546 300 418 minecraft:black_concrete
fill 550 295 418 551 300 418 minecraft:black_concrete
fill 552 295 457 552 300 457 minecraft:black_concrete
fill 554 295 419 554 300 419 minecraft:black_concrete
fill 555 295 456 555 300 456 minecraft:black_concrete
fill 556 295 421 556 300 422 minecraft:black_concrete
fill 557 295 426 557 299 429 minecraft:black_concrete
fill 557 295 441 557 300 441 minecraft:black_concrete
fill 558 295 444 558 300 445 minecraft:black_concrete
fill 558 295 450 558 300 450 minecraft:black_concrete
fill 519 296 424 519 300 424 minecraft:black_concrete
fill 520 296 421 520 299 421 minecraft:black_concrete
setblock 520 296 427 minecraft:light[level=12]
setblock 520 296 435 minecraft:light[level=12]
fill 520 296 437 520 297 437 minecraft:black_concrete
fill 520 296 441 520 300 443 minecraft:black_concrete
setblock 520 296 451 minecraft:light[level=12]
fill 521 296 455 523 297 457 minecraft:black_concrete
fill 524 296 456 524 298 457 minecraft:black_concrete
setblock 528 296 419 minecraft:light[level=12]
setblock 528 296 427 minecraft:light[level=12]
setblock 528 296 435 minecraft:light[level=12]
setblock 528 296 443 minecraft:light[level=12]
setblock 528 296 451 minecraft:light[level=12]
fill 528 296 457 528 299 457 minecraft:black_concrete
fill 534 296 418 535 300 418 minecraft:black_concrete
fill 534 296 457 545 296 457 minecraft:black_concrete
setblock 536 296 419 minecraft:light[level=12]
setblock 536 296 427 minecraft:light[level=12]
setblock 536 296 435 minecraft:light[level=12]
setblock 536 296 443 minecraft:light[level=12]
setblock 536 296 451 minecraft:light[level=12]
fill 536 296 456 541 296 456 minecraft:black_concrete
fill 538 296 419 541 299 419 minecraft:black_concrete
setblock 544 296 419 minecraft:light[level=12]
setblock 544 296 427 minecraft:light[level=12]
setblock 544 296 435 minecraft:light[level=12]
setblock 544 296 443 minecraft:light[level=12]
setblock 544 296 451 minecraft:light[level=12]
fill 547 296 418 549 300 418 minecraft:black_concrete
fill 551 296 457 551 300 457 minecraft:black_concrete
fill 552 296 419 553 300 419 minecraft:black_concrete
setblock 552 296 427 minecraft:light[level=12]
setblock 552 296 435 minecraft:light[level=12]
setblock 552 296 443 minecraft:light[level=12]
setblock 552 296 451 minecraft:light[level=12]
fill 554 296 456 554 300 456 minecraft:black_concrete
fill 555 296 420 555 300 420 minecraft:black_concrete
fill 556 296 423 556 300 424 minecraft:black_concrete
fill 556 296 436 556 297 438 minecraft:black_concrete
fill 557 296 442 557 300 443 minecraft:black_concrete
fill 558 296 446 558 300 449 minecraft:black_concrete
fill 520 297 444 520 300 445 minecraft:black_concrete
fill 527 297 457 527 299 457 minecraft:black_concrete
fill 533 297 418 533 300 418 minecraft:black_concrete
fill 534 297 457 544 297 457 minecraft:black_concrete
fill 536 297 456 540 297 456 minecraft:black_concrete
fill 537 297 419 537 300 419 minecraft:black_concrete
fill 542 297 419 542 299 419 minecraft:black_concrete
fill 551 297 419 551 300 419 minecraft:black_concrete
fill 554 297 420 554 300 420 minecraft:black_concrete
fill 555 297 421 555 300 422 minecraft:black_concrete
fill 556 297 425 556 300 425 minecraft:black_concrete
fill 556 297 439 556 299 440 minecraft:black_concrete
fill 557 297 444 557 300 444 minecraft:black_concrete
fill 557 297 453 557 299 453 minecraft:black_concrete
fill 519 298 435 519 298 437 minecraft:black_concrete
fill 520 298 446 520 300 446 minecraft:black_concrete
fill 521 298 455 522 298 457 minecraft:black_concrete
fill 523 298 456 523 299 457 minecraft:black_concrete
fill 526 298 457 526 300 457 minecraft:black_concrete
fill 534 298 457 543 298 457 minecraft:black_concrete
fill 536 298 419 536 300 419 minecraft:black_concrete
fill 536 298 456 539 298 456 minecraft:black_concrete
fill 550 298 419 550 300 419 minecraft:black_concrete
fill 553 298 420 553 300 420 minecraft:black_concrete
fill 555 298 423 555 300 423 minecraft:black_concrete
fill 556 298 426 556 300 426 minecraft:black_concrete
fill 556 298 437 556 298 438 minecraft:black_concrete
fill 556 298 441 556 299 441 minecraft:black_concrete
fill 557 298 445 557 300 446 minecraft:black_concrete
setblock 518 299 429 minecraft:black_concrete
fill 518 299 432 518 299 434 minecraft:black_concrete
fill 519 299 436 519 299 437 minecraft:black_concrete
fill 520 299 417 523 299 418 minecraft:black_concrete
fill 520 299 439 520 299 440 minecraft:black_concrete
setblock 520 299 447 minecraft:black_concrete
fill 520 299 455 520 299 457 minecraft:black_concrete
fill 521 299 456 522 300 457 minecraft:black_concrete
fill 524 299 417 524 300 417 minecraft:black_concrete
fill 524 299 457 525 300 457 minecraft:black_concrete
setblock 532 299 418 minecraft:black_concrete
fill 534 299 457 542 299 457 minecraft:black_concrete
fill 535 299 419 535 300 419 minecraft:black_concrete
fill 536 299 456 537 299 456 minecraft:black_concrete
fill 552 299 420 552 300 420 minecraft:black_concrete
fill 557 299 433 558 299 434 minecraft:black_concrete
fill 557 299 447 557 300 447 minecraft:black_concrete
fill 558 299 431 558 300 432 minecraft:black_concrete
setblock 518 300 434 minecraft:black_concrete
setblock 519 300 437 minecraft:black_concrete
fill 520 300 417 520 300 419 minecraft:black_concrete
setblock 520 300 440 minecraft:black_concrete
fill 520 300 456 520 300 457 minecraft:black_concrete
fill 521 300 417 522 300 418 minecraft:black_concrete
setblock 523 300 417 minecraft:black_concrete
setblock 523 300 457 minecraft:black_concrete
fill 530 300 417 533 300 417 minecraft:black_concrete
fill 534 300 457 540 300 457 minecraft:black_concrete
fill 538 300 419 540 300 419 minecraft:black_concrete
setblock 555 300 424 minecraft:black_concrete
fill 557 300 426 557 300 428 minecraft:black_concrete
fill 558 300 433 558 300 434 minecraft:black_concrete
