fill 117 81 511 118 83 511 minecraft:blackstone
setblock 117 81 550 minecraft:smooth_basalt
fill 117 81 551 120 81 551 minecraft:blackstone
fill 118 81 510 119 83 510 minecraft:gilded_blackstone
fill 118 81 550 118 84 550 minecraft:blackstone
setblock 118 81 552 minecraft:blackstone
setblock 119 81 513 minecraft:smooth_basalt
fill 119 81 552 132 81 552 minecraft:gilded_blackstone
setblock 120 81 510 minecraft:blackstone
setblock 120 81 512 minecraft:smooth_basalt
fill 121 81 510 123 83 510 minecraft:gilded_blackstone
setblock 121 81 511 minecraft:smooth_basalt
fill 121 81 512 121 82 512 minecraft:blackstone
setblock 121 81 551 minecraft:smooth_basalt
fill 122 81 511 122 83 511 minecraft:blackstone
fill 122 81 551 122 83 551 minecraft:blackstone
setblock 124 81 510 minecraft:blackstone
fill 125 81 510 127 83 510 minecraft:gilded_blackstone
setblock 128 81 510 minecraft:blackstone
fill 129 81 510 131 83 510 minecraft:gilded_blackstone
fill 132 81 511 132 84 511 minecraft:blackstone
fill 133 81 512 134 81 512 minecraft:blackstone
fill 133 81 532 133 81 533 minecraft:blackstone
setblock 133 81 534 minecraft:smooth_basalt
fill 133 81 535 133 84 535 minecraft:blackstone
setblock 133 81 538 minecraft:blackstone
setblock 133 81 552 minecraft:blackstone
setblock 134 81 513 minecraft:smooth_basalt
fill 134 81 514 134 84 514 minecraft:blackstone
setblock 134 81 517 minecraft:blackstone
setblock 134 81 518 minecraft:smooth_basalt
fill 134 81 519 135 83 519 minecraft:blackstone
setblock 134 81 522 minecraft:blackstone
setblock 134 81 523 minecraft:smooth_basalt
fill 134 81 524 134 81 527 minecraft:blackstone
setblock 134 81 528 minecraft:smooth_basalt
fill 134 81 529 134 84 529 minecraft:blackstone
setblock 134 81 533 minecraft:smooth_basalt
fill 134 81 534 134 84 534 minecraft:blackstone
setblock 134 81 537 minecraft:blackstone
setblock 134 81 538 minecraft:smooth_basalt
fill 134 81 539 135 83 539 minecraft:blackstone
fill 134 81 541 134 82 541 minecraft:blackstone
fill 134 81 552 136 81 552 minecraft:gilded_blackstone
setblock 135 81 512 minecraft:smooth_basalt
fill 135 81 513 135 84 513 minecraft:blackstone
setblock 135 81 517 minecraft:smooth_basalt
fill 135 81 518 135 84 518 minecraft:blackstone
setblock 135 81 522 minecraft:smooth_basalt
fill 135 81 523 135 84 523 minecraft:blackstone
setblock 135 81 527 minecraft:smooth_basalt
fill 135 81 528 135 84 528 minecraft:blackstone
setblock 135 81 532 minecraft:smooth_basalt
fill 135 81 533 135 84 533 minecraft:blackstone
setblock 135 81 537 minecraft:smooth_basalt
fill 135 81 538 135 84 538 minecraft:blackstone
setblock 135 81 542 minecraft:smooth_basalt
fill 135 81 543 135 83 544 minecraft:blackstone
fill 136 81 510 136 83 511 minecraft:gilded_blackstone
setblock 136 81 512 minecraft:blackstone
fill 136 81 513 136 83 515 minecraft:gilded_blackstone
fill 136 81 519 136 83 519 minecraft:gilded_blackstone
fill 136 81 526 136 83 526 minecraft:gilded_blackstone
setblock 136 81 527 minecraft:blackstone
fill 136 81 528 136 83 528 minecraft:gilded_blackstone
fill 136 81 529 136 82 529 minecraft:blackstone
fill 136 81 530 136 83 530 minecraft:gilded_blackstone
setblock 136 81 531 minecraft:blackstone
fill 136 81 532 136 83 533 minecraft:gilded_blackstone
fill 136 81 534 136 82 534 minecraft:blackstone
fill 136 81 535 136 81 539 minecraft:gilded_blackstone
fill 136 81 544 136 83 545 minecraft:gilded_blackstone
setblock 136 81 546 minecraft:blackstone
fill 136 81 547 136 83 550 minecraft:gilded_blackstone
setblock 136 81 551 minecraft:blackstone
fill 94 82 513 94 83 519 minecraft:gilded_blackstone
fill 94 82 520 95 82 520 minecraft:blackstone
fill 94 82 521 94 83 523 minecraft:gilded_blackstone
fill 94 82 529 94 83 530 minecraft:gilded_blackstone
setblock 94 82 531 minecraft:blackstone
fill 94 82 545 94 83 545 minecraft:gilded_blackstone
fill 94 82 550 94 83 550 minecraft:gilded_blackstone
setblock 95 82 511 minecraft:smooth_basalt
fill 95 82 512 95 82 515 minecraft:blackstone
setblock 95 82 516 minecraft:smooth_basalt
fill 95 82 517 95 83 519 minecraft:blackstone
setblock 95 82 521 minecraft:smooth_basalt
fill 95 82 522 95 84 523 minecraft:blackstone
setblock 95 82 526 minecraft:smooth_basalt
fill 95 82 527 95 85 527 minecraft:blackstone
setblock 95 82 531 minecraft:smooth_basalt
fill 95 82 532 95 85 532 minecraft:blackstone
setblock 95 82 536 minecraft:smooth_basalt
fill 95 82 537 95 85 537 minecraft:blackstone
setblock 95 82 541 minecraft:smooth_basalt
fill 95 82 542 96 84 542 minecraft:blackstone
fill 95 82 544 95 82 545 minecraft:blackstone
setblock 95 82 546 minecraft:smooth_basalt
fill 95 82 547 95 82 550 minecraft:blackstone
setblock 95 82 551 minecraft:smooth_basalt
setblock 95 82 552 minecraft:blackstone
fill 96 82 511 96 82 514 minecraft:blackstone
setblock 96 82 515 minecraft:smooth_basalt
fill 96 82 516 96 85 516 minecraft:blackstone
setblock 96 82 519 minecraft:blackstone
setblock 96 82 520 minecraft:smooth_basalt
fill 96 82 521 96 85 521 minecraft:blackstone
setblock 96 82 525 minecraft:smooth_basalt
fill 96 82 526 96 85 526 minecraft:blackstone
setblock 96 82 530 minecraft:smooth_basalt
fill 96 82 531 96 84 531 minecraft:blackstone
setblock 96 82 535 minecraft:smooth_basalt
fill 96 82 536 96 85 536 minecraft:blackstone
setblock 96 82 540 minecraft:smooth_basalt
fill 96 82 541 96 85 541 minecraft:blackstone
fill 96 82 551 99 82 551 minecraft:blackstone
fill 96 82 552 97 83 552 minecraft:gilded_blackstone
fill 97 82 511 97 82 513 minecraft:blackstone
setblock 97 82 514 minecraft:smooth_basalt
fill 97 82 515 97 85 515 minecraft:blackstone
setblock 97 82 519 minecraft:smooth_basalt
fill 97 82 520 98 84 520 minecraft:blackstone
setblock 97 82 523 minecraft:blackstone
setblock 97 82 534 minecraft:smooth_basalt
setblock 97 82 535 minecraft:blackstone
setblock 97 82 538 minecraft:blackstone
setblock 97 82 539 minecraft:smooth_basalt
fill 98 82 511 98 82 512 minecraft:blackstone
setblock 98 82 513 minecraft:smooth_basalt
fill 98 82 514 98 85 514 minecraft:blackstone
setblock 98 82 518 minecraft:smooth_basalt
fill 98 82 519 98 85 519 minecraft:blackstone
setblock 98 82 552 minecraft:blackstone
setblock 99 82 511 minecraft:blackstone
setblock 99 82 512 minecraft:smooth_basalt
fill 99 82 513 99 85 513 minecraft:blackstone
fill 99 82 552 108 83 552 minecraft:gilded_blackstone
setblock 100 82 511 minecraft:smooth_basalt
fill 100 82 512 100 85 512 minecraft:blackstone
setblock 100 82 551 minecraft:smooth_basalt
fill 101 82 510 101 83 510 minecraft:gilded_blackstone
fill 101 82 511 104 82 511 minecraft:blackstone
fill 101 82 551 104 82 551 minecraft:blackstone
setblock 102 82 514 minecraft:smooth_basalt
setblock 103 82 513 minecraft:smooth_basalt
fill 104 82 510 105 83 510 minecraft:gilded_blackstone
setblock 104 82 512 minecraft:smooth_basalt
setblock 104 82 513 minecraft:blackstone
setblock 105 82 511 minecraft:smooth_basalt
fill 105 82 512 105 83 512 minecraft:blackstone
setblock 105 82 551 minecraft:smooth_basalt
fill 106 82 510 106 82 511 minecraft:blackstone
fill 106 82 525 107 83 526 minecraft:gilded_blackstone
fill 106 82 551 109 82 551 minecraft:blackstone
fill 107 82 510 111 83 510 minecraft:gilded_blackstone
fill 107 82 511 109 82 511 minecraft:blackstone
setblock 109 82 512 minecraft:smooth_basalt
setblock 109 82 552 minecraft:blackstone
setblock 110 82 511 minecraft:smooth_basalt
fill 110 82 512 110 84 512 minecraft:blackstone
setblock 110 82 551 minecraft:smooth_basalt
fill 110 82 552 116 83 552 minecraft:gilded_blackstone
fill 111 82 511 114 82 511 minecraft:blackstone
fill 111 82 551 114 82 551 minecraft:blackstone
fill 112 82 550 115 82 550 minecraft:blackstone
fill 113 82 510 116 83 510 minecraft:gilded_blackstone
setblock 114 82 512 minecraft:smooth_basalt
fill 114 82 513 114 83 513 minecraft:blackstone
setblock 115 82 511 minecraft:smooth_basalt
fill 115 82 512 115 85 512 minecraft:blackstone
setblock 115 82 551 minecraft:smooth_basalt
fill 116 82 511 116 85 511 minecraft:blackstone
setblock 116 82 550 minecraft:smooth_basalt
fill 116 82 551 119 82 551 minecraft:blackstone
setblock 117 82 510 minecraft:blackstone
fill 117 82 550 117 85 550 minecraft:blackstone
setblock 117 82 552 minecraft:blackstone
setblock 118 82 512 minecraft:blackstone
setblock 118 82 513 minecraft:smooth_basalt
fill 118 82 552 118 83 552 minecraft:gilded_blackstone
setblock 119 82 512 minecraft:smooth_basalt
setblock 119 82 552 minecraft:blackstone
fill 120 82 510 120 83 510 minecraft:gilded_blackstone
setblock 120 82 511 minecraft:smooth_basalt
fill 120 82 512 120 83 512 minecraft:blackstone
setblock 120 82 551 minecraft:smooth_basalt
fill 120 82 552 135 83 552 minecraft:gilded_blackstone
fill 121 82 511 121 84 511 minecraft:blackstone
fill 121 82 551 121 84 551 minecraft:blackstone
fill 124 82 510 124 84 510 minecraft:gilded_blackstone
fill 128 82 510 128 83 510 minecraft:gilded_blackstone
fill 131 82 511 131 85 511 minecraft:blackstone
setblock 133 82 512 minecraft:blackstone
fill 133 82 515 133 82 517 minecraft:blackstone
setblock 133 82 518 minecraft:smooth_basalt
fill 133 82 519 133 84 520 minecraft:blackstone
setblock 133 82 532 minecraft:blackstone
setblock 133 82 533 minecraft:smooth_basalt
fill 133 82 534 133 85 534 minecraft:blackstone
setblock 133 82 538 minecraft:smooth_basalt
fill 133 82 539 133 85 539 minecraft:blackstone
setblock 134 82 512 minecraft:smooth_basalt
fill 134 82 513 134 85 513 minecraft:blackstone
setblock 134 82 517 minecraft:smooth_basalt
fill 134 82 518 134 85 518 minecraft:blackstone
fill 134 82 520 134 82 521 minecraft:blackstone
setblock 134 82 522 minecraft:smooth_basalt
fill 134 82 523 134 82 526 minecraft:blackstone
setblock 134 82 527 minecraft:smooth_basalt
fill 134 82 528 134 85 528 minecraft:blackstone
setblock 134 82 532 minecraft:smooth_basalt
fill 134 82 533 134 85 533 minecraft:blackstone
setblock 134 82 537 minecraft:smooth_basalt
fill 134 82 538 134 85 538 minecraft:blackstone
setblock 134 82 542 minecraft:smooth_basalt
setblock 135 82 511 minecraft:smooth_basalt
fill 135 82 512 135 85 512 minecraft:blackstone
setblock 135 82 516 minecraft:smooth_basalt
fill 135 82 517 135 85 517 minecraft:blackstone
setblock 135 82 520 minecraft:blackstone
setblock 135 82 521 minecraft:smooth_basalt
fill 135 82 522 135 85 522 minecraft:blackstone
setblock 135 82 526 minecraft:smooth_basalt
fill 135 82 527 135 85 527 minecraft:blackstone
setblock 135 82 531 minecraft:smooth_basalt
fill 135 82 532 135 85 532 minecraft:blackstone
setblock 135 82 536 minecraft:smooth_basalt
fill 135 82 537 135 85 537 minecraft:blackstone
setblock 135 82 540 minecraft:blackstone
setblock 135 82 541 minecraft:smooth_basalt
fill 135 82 542 135 85 542 minecraft:blackstone
setblock 135 82 545 minecraft:blackstone
setblock 135 82 551 minecraft:smooth_basalt
fill 136 82 512 136 83 512 minecraft:gilded_blackstone
fill 136 82 520 136 83 524 minecraft:gilded_blackstone
setblock 136 82 525 minecraft:blackstone
fill 136 82 527 136 83 527 minecraft:gilded_blackstone
fill 136 82 531 136 83 531 minecraft:gilded_blackstone
fill 136 82 535 136 83 538 minecraft:gilded_blackstone
setblock 136 82 539 minecraft:blackstone
fill 136 82 546 136 83 546 minecraft:gilded_blackstone
fill 136 82 551 136 83 551 minecraft:gilded_blackstone
setblock 136 82 552 minecraft:blackstone
setblock 94 83 512 minecraft:gilded_blackstone
setblock 94 83 520 minecraft:gilded_blackstone
setblock 94 83 531 minecraft:gilded_blackstone
setblock 94 83 546 minecraft:gilded_blackstone
fill 95 83 511 95 83 514 minecraft:blackstone
setblock 95 83 515 minecraft:smooth_basalt
fill 95 83 516 95 86 516 minecraft:blackstone
setblock 95 83 520 minecraft:smooth_basalt
fill 95 83 521 95 86 521 minecraft:blackstone
setblock 95 83 524 minecraft:blackstone
setblock 95 83 525 minecraft:smooth_basalt
fill 95 83 526 95 86 526 minecraft:blackstone
setblock 95 83 530 minecraft:smooth_basalt
fill 95 83 531 95 86 531 minecraft:blackstone
setblock 95 83 535 minecraft:smooth_basalt
fill 95 83 536 95 86 536 minecraft:blackstone
setblock 95 83 539 minecraft:blackstone
setblock 95 83 540 minecraft:smooth_basalt
fill 95 83 541 95 86 541 minecraft:blackstone
setblock 95 83 544 minecraft:blackstone
setblock 95 83 545 minecraft:smooth_basalt
fill 95 83 546 95 83 549 minecraft:blackstone
setblock 95 83 550 minecraft:smooth_basalt
fill 95 83 551 98 83 551 minecraft:blackstone
setblock 95 83 552 minecraft:gilded_blackstone
fill 96 83 511 96 83 513 minecraft:blackstone
setblock 96 83 514 minecraft:smooth_basalt
fill 96 83 515 96 86 515 minecraft:blackstone
setblock 96 83 519 minecraft:smooth_basalt
fill 96 83 520 96 86 520 minecraft:blackstone
setblock 96 83 524 minecraft:smooth_basalt
fill 96 83 525 96 86 525 minecraft:blackstone
setblock 96 83 529 minecraft:smooth_basalt
setblock 96 83 530 minecraft:blackstone
setblock 96 83 534 minecraft:smooth_basalt
fill 96 83 535 96 85 535 minecraft:blackstone
setblock 96 83 539 minecraft:smooth_basalt
fill 96 83 540 97 85 540 minecraft:blackstone
setblock 96 83 543 minecraft:blackstone
setblock 96 83 544 minecraft:smooth_basalt
fill 97 83 511 97 83 512 minecraft:blackstone
setblock 97 83 513 minecraft:smooth_basalt
fill 97 83 514 97 86 514 minecraft:blackstone
setblock 97 83 518 minecraft:smooth_basalt
fill 97 83 519 97 86 519 minecraft:blackstone
setblock 97 83 523 minecraft:smooth_basalt
setblock 97 83 538 minecraft:smooth_basalt
fill 97 83 539 97 84 539 minecraft:blackstone
fill 97 83 550 97 84 550 minecraft:blackstone
setblock 98 83 511 minecraft:blackstone
setblock 98 83 512 minecraft:smooth_basalt
fill 98 83 513 98 86 513 minecraft:blackstone
setblock 98 83 517 minecraft:smooth_basalt
fill 98 83 518 98 86 518 minecraft:blackstone
setblock 98 83 521 minecraft:blackstone
fill 98 83 552 98 85 552 minecraft:gilded_blackstone
setblock 99 83 511 minecraft:smooth_basalt
fill 99 83 512 99 86 512 minecraft:blackstone
setblock 99 83 516 minecraft:smooth_basalt
setblock 99 83 551 minecraft:smooth_basalt
fill 100 83 511 103 83 511 minecraft:blackstone
fill 100 83 551 103 83 551 minecraft:blackstone
setblock 101 83 514 minecraft:smooth_basalt
setblock 102 83 513 minecraft:smooth_basalt
setblock 103 83 512 minecraft:smooth_basalt
setblock 103 83 513 minecraft:blackstone
setblock 104 83 511 minecraft:smooth_basalt
fill 104 83 512 104 84 512 minecraft:blackstone
setblock 104 83 551 minecraft:smooth_basalt
fill 105 83 511 108 83 511 minecraft:blackstone
fill 105 83 551 108 83 551 minecraft:blackstone
setblock 106 83 510 minecraft:gilded_blackstone
setblock 108 83 512 minecraft:smooth_basalt
setblock 109 83 511 minecraft:smooth_basalt
setblock 109 83 512 minecraft:blackstone
setblock 109 83 551 minecraft:smooth_basalt
setblock 109 83 552 minecraft:gilded_blackstone
fill 110 83 511 113 83 511 minecraft:blackstone
fill 110 83 551 113 83 551 minecraft:blackstone
fill 112 83 550 114 83 550 minecraft:blackstone
setblock 113 83 512 minecraft:smooth_basalt
setblock 114 83 511 minecraft:smooth_basalt
fill 114 83 512 114 85 512 minecraft:blackstone
setblock 114 83 551 minecraft:smooth_basalt
fill 115 83 511 115 86 511 minecraft:blackstone
setblock 115 83 550 minecraft:smooth_basalt
fill 115 83 551 118 83 551 minecraft:blackstone
setblock 116 83 513 minecraft:blackstone
setblock 116 83 549 minecraft:smooth_basalt
fill 116 83 550 116 86 550 minecraft:blackstone
fill 117 83 510 117 85 510 minecraft:gilded_blackstone
setblock 117 83 513 minecraft:smooth_basalt
setblock 117 83 552 minecraft:gilded_blackstone
setblock 118 83 512 minecraft:smooth_basalt
setblock 119 83 511 minecraft:smooth_basalt
fill 119 83 512 119 84 512 minecraft:blackstone
setblock 119 83 551 minecraft:smooth_basalt
setblock 119 83 552 minecraft:gilded_blackstone
fill 120 83 511 120 84 511 minecraft:blackstone
setblock 120 83 550 minecraft:smooth_basalt
fill 120 83 551 120 85 551 minecraft:blackstone
setblock 133 83 512 minecraft:smooth_basalt
fill 133 83 514 133 83 516 minecraft:blackstone
setblock 133 83 517 minecraft:smooth_basalt
fill 133 83 518 133 86 518 minecraft:blackstone
setblock 133 83 521 minecraft:blackstone
setblock 133 83 522 minecraft:smooth_basalt
fill 133 83 523 134 85 523 minecraft:blackstone
setblock 133 83 532 minecraft:smooth_basalt
fill 133 83 533 133 85 533 minecraft:blackstone
setblock 133 83 536 minecraft:blackstone
setblock 133 83 537 minecraft:smooth_basalt
fill 133 83 538 133 86 538 minecraft:blackstone
fill 133 83 540 133 84 540 minecraft:blackstone
setblock 134 83 511 minecraft:smooth_basalt
fill 134 83 512 134 86 512 minecraft:blackstone
setblock 134 83 516 minecraft:smooth_basalt
fill 134 83 517 134 86 517 minecraft:blackstone
setblock 134 83 520 minecraft:blackstone
setblock 134 83 521 minecraft:smooth_basalt
fill 134 83 522 134 86 522 minecraft:blackstone
fill 134 83 524 134 83 525 minecraft:blackstone
setblock 134 83 526 minecraft:smooth_basalt
fill 134 83 527 134 86 527 minecraft:blackstone
setblock 134 83 531 minecraft:smooth_basalt
fill 134 83 532 134 86 532 minecraft:blackstone
setblock 134 83 536 minecraft:smooth_basalt
fill 134 83 537 134 86 537 minecraft:blackstone
setblock 134 83 541 minecraft:smooth_basalt
fill 134 83 542 134 85 543 minecraft:blackstone
fill 135 83 511 135 86 511 minecraft:blackstone
setblock 135 83 515 minecraft:smooth_basalt
fill 135 83 516 135 86 516 minecraft:blackstone
setblock 135 83 520 minecraft:smooth_basalt
fill 135 83 521 135 86 521 minecraft:blackstone
setblock 135 83 525 minecraft:smooth_basalt
fill 135 83 526 135 86 526 minecraft:blackstone
setblock 135 83 530 minecraft:smooth_basalt
fill 135 83 531 135 86 531 minecraft:blackstone
setblock 135 83 535 minecraft:smooth_basalt
fill 135 83 536 135 86 536 minecraft:blackstone
setblock 135 83 540 minecraft:smooth_basalt
fill 135 83 541 135 86 541 minecraft:blackstone
setblock 135 83 545 minecraft:smooth_basalt
fill 135 83 546 135 85 547 minecraft:blackstone
fill 135 83 551 135 84 551 minecraft:blackstone
setblock 136 83 525 minecraft:gilded_blackstone
setblock 136 83 529 minecraft:gilded_blackstone
setblock 136 83 534 minecraft:gilded_blackstone
setblock 136 83 539 minecraft:gilded_blackstone
setblock 136 83 543 minecraft:gilded_blackstone
setblock 136 83 552 minecraft:gilded_blackstone
fill 94 84 510 94 84 546 minecraft:blackstone
fill 94 84 547 94 85 547 minecraft:gilded_blackstone
fill 94 84 548 94 84 552 minecraft:blackstone
setblock 95 84 510 minecraft:gilded_blackstone
fill 95 84 511 95 84 513 minecraft:blackstone
setblock 95 84 514 minecraft:smooth_basalt
fill 95 84 515 95 87 515 minecraft:blackstone
fill 95 84 517 95 84 518 minecraft:blackstone
setblock 95 84 519 minecraft:smooth_basalt
fill 95 84 520 95 87 520 minecraft:blackstone
setblock 95 84 524 minecraft:smooth_basalt
fill 95 84 525 95 87 525 minecraft:blackstone
setblock 95 84 529 minecraft:smooth_basalt
fill 95 84 530 95 87 530 minecraft:blackstone
setblock 95 84 534 minecraft:smooth_basalt
fill 95 84 535 95 87 535 minecraft:blackstone
setblock 95 84 539 minecraft:smooth_basalt
fill 95 84 540 95 87 540 minecraft:blackstone
setblock 95 84 544 minecraft:smooth_basalt
fill 95 84 545 95 84 548 minecraft:blackstone
setblock 95 84 549 minecraft:smooth_basalt
fill 95 84 550 95 86 552 minecraft:blackstone
fill 96 84 510 96 84 512 minecraft:blackstone
setblock 96 84 513 minecraft:smooth_basalt
fill 96 84 514 96 87 514 minecraft:blackstone
setblock 96 84 518 minecraft:smooth_basalt
fill 96 84 519 96 87 519 minecraft:blackstone
setblock 96 84 522 minecraft:blackstone
setblock 96 84 523 minecraft:smooth_basalt
fill 96 84 524 96 87 524 minecraft:blackstone
setblock 96 84 528 minecraft:smooth_basalt
setblock 96 84 533 minecraft:smooth_basalt
fill 96 84 534 96 85 534 minecraft:blackstone
setblock 96 84 537 minecraft:blackstone
setblock 96 84 538 minecraft:smooth_basalt
fill 96 84 539 96 87 539 minecraft:blackstone
setblock 96 84 543 minecraft:smooth_basalt
fill 96 84 544 96 86 545 minecraft:blackstone
fill 96 84 551 97 84 552 minecraft:blackstone
fill 97 84 510 97 84 511 minecraft:blackstone
setblock 97 84 512 minecraft:smooth_basalt
fill 97 84 513 97 87 513 minecraft:blackstone
setblock 97 84 517 minecraft:smooth_basalt
fill 97 84 518 97 87 518 minecraft:blackstone
setblock 97 84 522 minecraft:smooth_basalt
fill 97 84 523 97 86 523 minecraft:blackstone
setblock 97 84 537 minecraft:smooth_basalt
setblock 97 84 538 minecraft:blackstone
fill 98 84 510 116 84 510 minecraft:blackstone
setblock 98 84 511 minecraft:smooth_basalt
fill 98 84 512 98 87 512 minecraft:blackstone
setblock 98 84 515 minecraft:blackstone
setblock 98 84 516 minecraft:smooth_basalt
fill 98 84 517 98 86 517 minecraft:blackstone
setblock 98 84 521 minecraft:smooth_basalt
setblock 98 84 550 minecraft:blackstone
setblock 98 84 551 minecraft:smooth_basalt
fill 99 84 511 102 84 511 minecraft:blackstone
fill 99 84 551 102 84 552 minecraft:blackstone
setblock 100 84 514 minecraft:smooth_basalt
setblock 101 84 513 minecraft:smooth_basalt
setblock 102 84 512 minecraft:smooth_basalt
setblock 102 84 513 minecraft:blackstone
setblock 103 84 511 minecraft:smooth_basalt
fill 103 84 512 103 85 512 minecraft:blackstone
setblock 103 84 551 minecraft:smooth_basalt
fill 103 84 552 111 84 552 minecraft:blackstone
fill 104 84 511 107 84 511 minecraft:blackstone
fill 104 84 551 107 84 551 minecraft:blackstone
setblock 108 84 511 minecraft:smooth_basalt
setblock 108 84 551 minecraft:smooth_basalt
fill 109 84 511 112 84 511 minecraft:blackstone
fill 109 84 551 112 84 551 minecraft:blackstone
fill 111 84 550 113 84 550 minecraft:blackstone
setblock 112 84 512 minecraft:smooth_basalt
fill 112 84 552 112 85 552 minecraft:gilded_blackstone
setblock 113 84 511 minecraft:smooth_basalt
fill 113 84 512 113 85 512 minecraft:blackstone
setblock 113 84 551 minecraft:smooth_basalt
fill 113 84 552 124 84 552 minecraft:blackstone
fill 114 84 511 114 87 511 minecraft:blackstone
setblock 114 84 550 minecraft:smooth_basalt
fill 114 84 551 117 84 551 minecraft:blackstone
fill 115 84 550 115 87 550 minecraft:blackstone
setblock 117 84 511 minecraft:blackstone
setblock 117 84 512 minecraft:smooth_basalt
fill 118 84 510 121 85 510 minecraft:blackstone
setblock 118 84 511 minecraft:smooth_basalt
setblock 118 84 512 minecraft:blackstone
setblock 118 84 551 minecraft:smooth_basalt
fill 119 84 511 119 85 511 minecraft:blackstone
setblock 119 84 550 minecraft:smooth_basalt
fill 119 84 551 119 86 551 minecraft:blackstone
fill 122 84 510 123 84 510 minecraft:gilded_blackstone
setblock 125 84 510 minecraft:gilded_blackstone
fill 125 84 552 126 84 552 minecraft:gilded_blackstone
fill 126 84 510 136 84 510 minecraft:blackstone
fill 127 84 552 129 193 552 minecraft:blackstone
setblock 130 84 552 minecraft:gilded_blackstone
fill 131 84 552 131 195 552 minecraft:blackstone
setblock 132 84 552 minecraft:gilded_blackstone
setblock 133 84 511 minecraft:smooth_basalt
fill 133 84 512 133 86 512 minecraft:blackstone
fill 133 84 514 133 84 515 minecraft:blackstone
setblock 133 84 516 minecraft:smooth_basalt
fill 133 84 517 133 87 517 minecraft:blackstone
setblock 133 84 521 minecraft:smooth_basalt
fill 133 84 522 133 87 522 minecraft:blackstone
fill 133 84 524 134 84 524 minecraft:blackstone
setblock 133 84 532 minecraft:blackstone
setblock 133 84 536 minecraft:smooth_basalt
fill 133 84 537 133 86 537 minecraft:blackstone
setblock 133 84 541 minecraft:smooth_basalt
fill 133 84 552 136 84 552 minecraft:blackstone
fill 134 84 511 134 87 511 minecraft:blackstone
setblock 134 84 515 minecraft:smooth_basalt
fill 134 84 516 134 87 516 minecraft:blackstone
setblock 134 84 519 minecraft:blackstone
setblock 134 84 520 minecraft:smooth_basalt
fill 134 84 521 134 87 521 minecraft:blackstone
setblock 134 84 525 minecraft:smooth_basalt
fill 134 84 526 134 87 526 minecraft:blackstone
setblock 134 84 530 minecraft:smooth_basalt
fill 134 84 531 134 87 531 minecraft:blackstone
setblock 134 84 535 minecraft:smooth_basalt
fill 134 84 536 134 87 536 minecraft:blackstone
setblock 134 84 539 minecraft:blackstone
setblock 134 84 540 minecraft:smooth_basalt
fill 134 84 541 134 87 541 minecraft:blackstone
setblock 134 84 544 minecraft:blackstone
setblock 135 84 514 minecraft:smooth_basalt
fill 135 84 515 136 85 515 minecraft:blackstone
setblock 135 84 519 minecraft:smooth_basalt
fill 135 84 520 136 87 520 minecraft:blackstone
setblock 135 84 524 minecraft:smooth_basalt
fill 135 84 525 136 87 525 minecraft:blackstone
setblock 135 84 529 minecraft:smooth_basalt
fill 135 84 530 136 85 530 minecraft:blackstone
setblock 135 84 534 minecraft:smooth_basalt
fill 135 84 535 136 87 535 minecraft:blackstone
setblock 135 84 539 minecraft:smooth_basalt
fill 135 84 540 136 87 540 minecraft:blackstone
fill 135 84 543 136 84 543 minecraft:blackstone
setblock 135 84 544 minecraft:smooth_basalt
fill 135 84 545 136 87 545 minecraft:blackstone
fill 135 84 548 136 84 548 minecraft:blackstone
fill 136 84 511 136 195 514 minecraft:blackstone
fill 136 84 516 136 195 516 minecraft:blackstone
setblock 136 84 517 minecraft:gilded_blackstone
fill 136 84 518 136 195 519 minecraft:blackstone
fill 136 84 521 136 84 524 minecraft:blackstone
fill 136 84 526 136 85 529 minecraft:blackstone
fill 136 84 531 136 191 534 minecraft:blackstone
fill 136 84 536 136 85 539 minecraft:blackstone
fill 136 84 541 136 85 542 minecraft:blackstone
fill 136 84 544 136 195 544 minecraft:blackstone
fill 136 84 546 136 193 547 minecraft:blackstone
fill 136 84 549 136 195 549 minecraft:blackstone
setblock 136 84 550 minecraft:gilded_blackstone
fill 136 84 551 136 193 551 minecraft:blackstone
fill 94 85 510 94 85 515 minecraft:blackstone
fill 94 85 516 94 85 517 minecraft:gilded_blackstone
fill 94 85 518 94 85 532 minecraft:blackstone
setblock 94 85 533 minecraft:gilded_blackstone
fill 94 85 534 94 85 546 minecraft:blackstone
fill 94 85 548 94 193 548 minecraft:blackstone
setblock 94 85 549 minecraft:gilded_blackstone
fill 94 85 550 94 85 552 minecraft:blackstone
fill 95 85 510 95 85 512 minecraft:blackstone
setblock 95 85 513 minecraft:smooth_basalt
fill 95 85 514 95 88 514 minecraft:blackstone
setblock 95 85 517 minecraft:blackstone
setblock 95 85 518 minecraft:smooth_basalt
fill 95 85 519 95 88 519 minecraft:blackstone
setblock 95 85 522 minecraft:blackstone
setblock 95 85 523 minecraft:smooth_basalt
fill 95 85 524 95 88 524 minecraft:blackstone
setblock 95 85 528 minecraft:smooth_basalt
fill 95 85 529 95 87 529 minecraft:blackstone
setblock 95 85 533 minecraft:smooth_basalt
fill 95 85 534 95 87 534 minecraft:blackstone
setblock 95 85 538 minecraft:smooth_basalt
fill 95 85 539 95 88 539 minecraft:blackstone
setblock 95 85 542 minecraft:blackstone
setblock 95 85 543 minecraft:smooth_basalt
fill 95 85 544 95 85 547 minecraft:blackstone
setblock 95 85 548 minecraft:smooth_basalt
fill 95 85 549 95 88 549 minecraft:blackstone
fill 96 85 510 96 85 511 minecraft:blackstone
setblock 96 85 512 minecraft:smooth_basalt
fill 96 85 513 96 88 513 minecraft:blackstone
setblock 96 85 517 minecraft:smooth_basalt
fill 96 85 518 96 88 518 minecraft:blackstone
setblock 96 85 522 minecraft:smooth_basalt
fill 96 85 523 96 88 523 minecraft:blackstone
setblock 96 85 527 minecraft:smooth_basalt
setblock 96 85 537 minecraft:smooth_basalt
fill 96 85 538 96 87 538 minecraft:blackstone
setblock 96 85 542 minecraft:smooth_basalt
fill 96 85 543 96 88 543 minecraft:blackstone
setblock 96 85 546 minecraft:blackstone
fill 96 85 551 96 85 552 minecraft:blackstone
fill 97 85 510 103 192 510 minecraft:blackstone
setblock 97 85 511 minecraft:smooth_basalt
fill 97 85 512 97 88 512 minecraft:blackstone
setblock 97 85 516 minecraft:smooth_basalt
fill 97 85 517 97 88 517 minecraft:blackstone
setblock 97 85 520 minecraft:blackstone
setblock 97 85 521 minecraft:smooth_basalt
fill 97 85 522 97 88 522 minecraft:blackstone
setblock 97 85 529 minecraft:light[level=12]
setblock 97 85 537 minecraft:light[level=12]
setblock 97 85 545 minecraft:light[level=12]
setblock 97 85 551 minecraft:smooth_basalt
setblock 97 85 552 minecraft:blackstone
fill 98 85 511 101 85 511 minecraft:blackstone
setblock 98 85 515 minecraft:smooth_basalt
fill 98 85 516 98 86 516 minecraft:blackstone
setblock 98 85 520 minecraft:smooth_basalt
fill 98 85 551 101 85 551 minecraft:blackstone
setblock 99 85 514 minecraft:smooth_basalt
fill 99 85 552 100 85 552 minecraft:blackstone
setblock 100 85 513 minecraft:smooth_basalt
setblock 101 85 512 minecraft:smooth_basalt
setblock 101 85 513 minecraft:blackstone
setblock 101 85 552 minecraft:gilded_blackstone
setblock 102 85 511 minecraft:smooth_basalt
setblock 102 85 512 minecraft:blackstone
setblock 102 85 551 minecraft:smooth_basalt
fill 102 85 552 104 195 552 minecraft:blackstone
fill 103 85 511 106 85 511 minecraft:blackstone
setblock 103 85 551 minecraft:blackstone
setblock 104 85 510 minecraft:gilded_blackstone
fill 105 85 510 110 192 510 minecraft:blackstone
setblock 105 85 513 minecraft:light[level=12]
setblock 105 85 521 minecraft:light[level=12]
setblock 105 85 529 minecraft:light[level=12]
setblock 105 85 537 minecraft:light[level=12]
setblock 105 85 545 minecraft:light[level=12]
setblock 105 85 552 minecraft:gilded_blackstone
fill 106 85 552 111 191 552 minecraft:blackstone
setblock 107 85 511 minecraft:smooth_basalt
setblock 107 85 551 minecraft:smooth_basalt
fill 108 85 511 111 85 511 minecraft:blackstone
fill 108 85 551 111 85 551 minecraft:blackstone
fill 111 85 510 111 86 510 minecraft:gilded_blackstone
fill 111 85 550 112 85 550 minecraft:blackstone
fill 112 85 510 116 192 510 minecraft:blackstone
setblock 112 85 511 minecraft:smooth_basalt
setblock 112 85 512 minecraft:blackstone
setblock 112 85 551 minecraft:smooth_basalt
fill 113 85 511 113 87 511 minecraft:blackstone
setblock 113 85 513 minecraft:light[level=12]
setblock 113 85 521 minecraft:light[level=12]
setblock 113 85 529 minecraft:light[level=12]
setblock 113 85 537 minecraft:light[level=12]
setblock 113 85 545 minecraft:light[level=12]
setblock 113 85 550 minecraft:smooth_basalt
fill 113 85 551 116 85 551 minecraft:blackstone
setblock 113 85 552 minecraft:gilded_blackstone
fill 114 85 550 114 88 550 minecraft:blackstone
fill 114 85 552 121 85 552 minecraft:blackstone
setblock 116 85 512 minecraft:smooth_basalt
setblock 117 85 511 minecraft:smooth_basalt
setblock 117 85 512 minecraft:blackstone
setblock 117 85 551 minecraft:smooth_basalt
setblock 118 85 511 minecraft:blackstone
setblock 118 85 550 minecraft:smooth_basalt
fill 118 85 551 118 87 551 minecraft:blackstone
setblock 121 85 513 minecraft:light[level=12]
setblock 121 85 521 minecraft:light[level=12]
setblock 121 85 529 minecraft:light[level=12]
setblock 121 85 537 minecraft:light[level=12]
setblock 121 85 545 minecraft:light[level=12]
fill 122 85 510 134 85 510 minecraft:blackstone
setblock 122 85 552 minecraft:gilded_blackstone
setblock 123 85 552 minecraft:blackstone
fill 124 85 552 125 85 552 minecraft:gilded_blackstone
fill 126 85 552 126 195 552 minecraft:blackstone
setblock 129 85 513 minecraft:light[level=12]
setblock 129 85 521 minecraft:light[level=12]
setblock 129 85 529 minecraft:light[level=12]
setblock 129 85 537 minecraft:light[level=12]
setblock 129 85 545 minecraft:light[level=12]
fill 130 85 552 130 195 552 minecraft:blackstone
setblock 132 85 511 minecraft:smooth_basalt
fill 132 85 519 133 85 519 minecraft:blackstone
fill 132 85 552 134 192 552 minecraft:blackstone
fill 133 85 511 133 88 511 minecraft:blackstone
setblock 133 85 514 minecraft:blackstone
setblock 133 85 515 minecraft:smooth_basalt
fill 133 85 516 133 88 516 minecraft:blackstone
setblock 133 85 520 minecraft:smooth_basalt
fill 133 85 521 133 88 521 minecraft:blackstone
setblock 133 85 524 minecraft:blackstone
setblock 133 85 525 minecraft:smooth_basalt
setblock 133 85 535 minecraft:smooth_basalt
fill 133 85 536 133 86 536 minecraft:blackstone
setblock 133 85 540 minecraft:smooth_basalt
fill 133 85 541 133 86 541 minecraft:blackstone
setblock 134 85 514 minecraft:smooth_basalt
fill 134 85 515 134 88 515 minecraft:blackstone
setblock 134 85 519 minecraft:smooth_basalt
fill 134 85 520 134 88 520 minecraft:blackstone
setblock 134 85 524 minecraft:smooth_basalt
fill 134 85 525 134 88 525 minecraft:blackstone
setblock 134 85 529 minecraft:smooth_basalt
fill 134 85 530 134 88 530 minecraft:blackstone
setblock 134 85 534 minecraft:smooth_basalt
fill 134 85 535 134 88 535 minecraft:blackstone
setblock 134 85 539 minecraft:smooth_basalt
fill 134 85 540 134 88 540 minecraft:blackstone
setblock 134 85 544 minecraft:smooth_basalt
setblock 135 85 510 minecraft:gilded_blackstone
setblock 135 85 513 minecraft:smooth_basalt
fill 135 85 514 135 88 514 minecraft:blackstone
setblock 135 85 518 minecraft:smooth_basalt
fill 135 85 519 135 88 519 minecraft:blackstone
setblock 135 85 523 minecraft:smooth_basalt
fill 135 85 524 136 88 524 minecraft:blackstone
setblock 135 85 528 minecraft:smooth_basalt
fill 135 85 529 135 88 529 minecraft:blackstone
setblock 135 85 533 minecraft:smooth_basalt
fill 135 85 534 135 88 534 minecraft:blackstone
setblock 135 85 538 minecraft:smooth_basalt
fill 135 85 539 135 88 539 minecraft:blackstone
setblock 135 85 543 minecraft:smooth_basalt
fill 135 85 544 135 88 544 minecraft:blackstone
setblock 135 85 548 minecraft:smooth_basalt
setblock 135 85 552 minecraft:gilded_blackstone
fill 136 85 510 136 193 510 minecraft:blackstone
fill 136 85 517 136 195 517 minecraft:blackstone
setblock 136 85 521 minecraft:gilded_blackstone
fill 136 85 522 136 191 523 minecraft:blackstone
fill 136 85 543 136 191 543 minecraft:blackstone
fill 136 85 548 136 195 548 minecraft:blackstone
fill 136 85 550 136 193 550 minecraft:blackstone
fill 136 85 552 136 195 552 minecraft:blackstone
fill 94 86 510 94 191 512 minecraft:blackstone
setblock 94 86 513 minecraft:gilded_blackstone
fill 94 86 514 94 195 514 minecraft:blackstone
setblock 94 86 515 minecraft:gilded_blackstone
fill 94 86 516 94 193 519 minecraft:blackstone
setblock 94 86 520 minecraft:gilded_blackstone
fill 94 86 521 94 195 526 minecraft:blackstone
setblock 94 86 527 minecraft:gilded_blackstone
fill 94 86 528 94 192 535 minecraft:blackstone
setblock 94 86 536 minecraft:gilded_blackstone
fill 94 86 537 94 191 542 minecraft:blackstone
setblock 94 86 543 minecraft:gilded_blackstone
fill 94 86 544 94 191 547 minecraft:blackstone
fill 94 86 549 94 195 549 minecraft:blackstone
setblock 94 86 550 minecraft:gilded_blackstone
fill 94 86 551 94 191 552 minecraft:blackstone
fill 95 86 510 95 86 511 minecraft:blackstone
setblock 95 86 512 minecraft:smooth_basalt
fill 95 86 513 95 89 513 minecraft:blackstone
setblock 95 86 517 minecraft:smooth_basalt
fill 95 86 518 95 89 518 minecraft:blackstone
setblock 95 86 522 minecraft:smooth_basalt
fill 95 86 523 95 89 523 minecraft:blackstone
setblock 95 86 527 minecraft:smooth_basalt
fill 95 86 528 95 89 528 minecraft:blackstone
setblock 95 86 532 minecraft:smooth_basalt
fill 95 86 533 95 87 533 minecraft:blackstone
setblock 95 86 537 minecraft:smooth_basalt
fill 95 86 538 95 89 538 minecraft:blackstone
setblock 95 86 542 minecraft:smooth_basalt
fill 95 86 543 95 86 546 minecraft:blackstone
setblock 95 86 547 minecraft:smooth_basalt
fill 95 86 548 95 89 548 minecraft:blackstone
fill 96 86 510 96 195 510 minecraft:blackstone
setblock 96 86 511 minecraft:smooth_basalt
fill 96 86 512 96 89 512 minecraft:blackstone
setblock 96 86 516 minecraft:smooth_basalt
fill 96 86 517 96 89 517 minecraft:blackstone
setblock 96 86 521 minecraft:smooth_basalt
fill 96 86 522 96 89 522 minecraft:blackstone
setblock 96 86 526 minecraft:smooth_basalt
setblock 96 86 536 minecraft:smooth_basalt
setblock 96 86 537 minecraft:blackstone
setblock 96 86 540 minecraft:blackstone
setblock 96 86 541 minecraft:smooth_basalt
fill 96 86 542 96 89 542 minecraft:blackstone
setblock 96 86 546 minecraft:smooth_basalt
setblock 96 86 551 minecraft:smooth_basalt
fill 96 86 552 97 86 552 minecraft:gilded_blackstone
fill 97 86 511 100 86 511 minecraft:blackstone
setblock 97 86 515 minecraft:smooth_basalt
fill 97 86 516 97 88 516 minecraft:blackstone
setblock 97 86 520 minecraft:smooth_basalt
fill 97 86 521 97 88 521 minecraft:blackstone
fill 97 86 551 100 86 551 minecraft:blackstone
setblock 98 86 515 minecraft:blackstone
setblock 98 86 519 minecraft:smooth_basalt
fill 98 86 552 98 195 552 minecraft:blackstone
setblock 99 86 513 minecraft:smooth_basalt
setblock 99 86 552 minecraft:gilded_blackstone
setblock 100 86 512 minecraft:smooth_basalt
fill 100 86 552 101 191 552 minecraft:blackstone
setblock 101 86 511 minecraft:smooth_basalt
setblock 101 86 512 minecraft:blackstone
setblock 101 86 551 minecraft:smooth_basalt
fill 102 86 511 103 86 511 minecraft:blackstone
fill 104 86 510 104 196 510 minecraft:blackstone
fill 105 86 552 105 193 552 minecraft:blackstone
fill 108 86 551 110 86 551 minecraft:blackstone
fill 109 86 511 110 86 511 minecraft:blackstone
setblock 111 86 511 minecraft:smooth_basalt
setblock 111 86 550 minecraft:blackstone
setblock 111 86 551 minecraft:smooth_basalt
fill 112 86 511 112 87 511 minecraft:blackstone
setblock 112 86 550 minecraft:smooth_basalt
fill 112 86 551 115 86 552 minecraft:blackstone
fill 113 86 550 113 89 550 minecraft:blackstone
setblock 116 86 511 minecraft:smooth_basalt
setblock 116 86 551 minecraft:smooth_basalt
setblock 116 86 552 minecraft:gilded_blackstone
fill 117 86 510 117 86 511 minecraft:blackstone
setblock 117 86 550 minecraft:smooth_basalt
fill 117 86 551 117 88 552 minecraft:blackstone
setblock 118 86 510 minecraft:gilded_blackstone
fill 118 86 552 122 192 552 minecraft:blackstone
fill 119 86 510 128 191 510 minecraft:blackstone
setblock 123 86 552 minecraft:gilded_blackstone
fill 124 86 552 124 191 552 minecraft:blackstone
setblock 125 86 552 minecraft:gilded_blackstone
setblock 129 86 510 minecraft:gilded_blackstone
fill 130 86 510 135 191 510 minecraft:blackstone
fill 132 86 511 132 88 511 minecraft:blackstone
fill 132 86 518 132 86 519 minecraft:blackstone
setblock 132 86 520 minecraft:smooth_basalt
fill 132 86 521 132 89 521 minecraft:blackstone
setblock 133 86 514 minecraft:smooth_basalt
fill 133 86 515 133 88 515 minecraft:blackstone
setblock 133 86 519 minecraft:smooth_basalt
fill 133 86 520 133 89 520 minecraft:blackstone
setblock 133 86 523 minecraft:blackstone
setblock 133 86 524 minecraft:smooth_basalt
fill 133 86 525 133 88 526 minecraft:blackstone
setblock 133 86 535 minecraft:blackstone
setblock 133 86 539 minecraft:smooth_basalt
fill 133 86 540 133 87 540 minecraft:blackstone
setblock 134 86 513 minecraft:smooth_basalt
fill 134 86 514 134 89 514 minecraft:blackstone
setblock 134 86 518 minecraft:smooth_basalt
fill 134 86 519 134 89 519 minecraft:blackstone
setblock 134 86 523 minecraft:smooth_basalt
fill 134 86 524 134 89 524 minecraft:blackstone
setblock 134 86 528 minecraft:smooth_basalt
fill 134 86 529 134 89 529 minecraft:blackstone
setblock 134 86 533 minecraft:smooth_basalt
fill 134 86 534 134 87 534 minecraft:blackstone
setblock 134 86 538 minecraft:smooth_basalt
fill 134 86 539 134 89 539 minecraft:blackstone
setblock 134 86 542 minecraft:blackstone
setblock 134 86 543 minecraft:smooth_basalt
fill 134 86 544 134 89 544 minecraft:blackstone
setblock 135 86 512 minecraft:smooth_basalt
fill 135 86 513 135 89 513 minecraft:blackstone
fill 135 86 515 135 87 515 minecraft:blackstone
setblock 135 86 517 minecraft:smooth_basalt
fill 135 86 518 135 89 518 minecraft:blackstone
setblock 135 86 522 minecraft:smooth_basalt
fill 135 86 523 135 89 523 minecraft:blackstone
setblock 135 86 527 minecraft:smooth_basalt
fill 135 86 528 136 89 528 minecraft:blackstone
fill 135 86 530 135 87 530 minecraft:blackstone
setblock 135 86 532 minecraft:smooth_basalt
fill 135 86 533 135 89 533 minecraft:blackstone
setblock 135 86 537 minecraft:smooth_basalt
fill 135 86 538 136 89 538 minecraft:blackstone
setblock 135 86 542 minecraft:smooth_basalt
fill 135 86 543 135 89 543 minecraft:blackstone
setblock 135 86 546 minecraft:blackstone
setblock 135 86 547 minecraft:smooth_basalt
fill 135 86 548 135 89 548 minecraft:blackstone
fill 135 86 552 135 195 552 minecraft:blackstone
setblock 136 86 515 minecraft:gilded_blackstone
fill 136 86 521 136 195 521 minecraft:blackstone
fill 136 86 526 136 191 526 minecraft:blackstone
setblock 136 86 527 minecraft:gilded_blackstone
fill 136 86 529 136 195 529 minecraft:blackstone
setblock 136 86 530 minecraft:gilded_blackstone
fill 136 86 536 136 191 537 minecraft:blackstone
setblock 136 86 539 minecraft:gilded_blackstone
setblock 136 86 541 minecraft:gilded_blackstone
fill 136 86 542 136 193 542 minecraft:blackstone
fill 94 87 513 94 195 513 minecraft:blackstone
fill 94 87 515 94 195 515 minecraft:blackstone
fill 94 87 520 94 191 520 minecraft:blackstone
fill 94 87 527 95 90 527 minecraft:blackstone
fill 94 87 536 94 195 536 minecraft:blackstone
fill 94 87 543 95 89 543 minecraft:blackstone
fill 94 87 550 95 87 550 minecraft:blackstone
fill 95 87 510 95 192 510 minecraft:blackstone
setblock 95 87 511 minecraft:smooth_basalt
fill 95 87 512 95 90 512 minecraft:blackstone
setblock 95 87 516 minecraft:smooth_basalt
fill 95 87 517 95 90 517 minecraft:blackstone
setblock 95 87 521 minecraft:smooth_basalt
fill 95 87 522 95 90 522 minecraft:blackstone
setblock 95 87 526 minecraft:smooth_basalt
setblock 95 87 536 minecraft:smooth_basalt
fill 95 87 537 95 89 537 minecraft:blackstone
setblock 95 87 541 minecraft:smooth_basalt
fill 95 87 542 95 90 542 minecraft:blackstone
fill 95 87 544 95 87 545 minecraft:blackstone
setblock 95 87 546 minecraft:smooth_basalt
fill 95 87 547 95 90 547 minecraft:blackstone
setblock 95 87 551 minecraft:smooth_basalt
fill 95 87 552 97 192 552 minecraft:blackstone
fill 96 87 511 99 87 511 minecraft:blackstone
setblock 96 87 515 minecraft:smooth_basalt
fill 96 87 516 96 90 516 minecraft:blackstone
setblock 96 87 520 minecraft:smooth_basalt
fill 96 87 521 96 90 521 minecraft:blackstone
setblock 96 87 525 minecraft:smooth_basalt
setblock 96 87 540 minecraft:smooth_basalt
fill 96 87 541 96 89 541 minecraft:blackstone
setblock 96 87 544 minecraft:blackstone
setblock 96 87 545 minecraft:smooth_basalt
fill 96 87 546 96 90 546 minecraft:blackstone
fill 96 87 551 99 87 551 minecraft:blackstone
setblock 97 87 514 minecraft:smooth_basalt
fill 97 87 515 97 88 515 minecraft:blackstone
setblock 97 87 519 minecraft:smooth_basalt
fill 97 87 520 97 89 520 minecraft:blackstone
setblock 99 87 512 minecraft:smooth_basalt
fill 99 87 552 99 191 552 minecraft:blackstone
setblock 100 87 511 minecraft:smooth_basalt
setblock 100 87 551 minecraft:smooth_basalt
setblock 101 87 511 minecraft:blackstone
fill 108 87 551 109 87 551 minecraft:blackstone
setblock 110 87 551 minecraft:smooth_basalt
fill 111 87 510 111 87 511 minecraft:blackstone
setblock 111 87 550 minecraft:smooth_basalt
fill 111 87 551 114 87 551 minecraft:blackstone
fill 112 87 550 112 90 550 minecraft:blackstone
fill 112 87 552 116 191 552 minecraft:blackstone
setblock 115 87 511 minecraft:smooth_basalt
setblock 115 87 551 minecraft:smooth_basalt
setblock 116 87 511 minecraft:blackstone
setblock 116 87 550 minecraft:smooth_basalt
fill 116 87 551 116 90 551 minecraft:blackstone
fill 117 87 510 118 191 510 minecraft:blackstone
fill 123 87 552 123 195 552 minecraft:blackstone
fill 125 87 552 125 195 552 minecraft:blackstone
fill 129 87 510 129 195 510 minecraft:blackstone
setblock 132 87 519 minecraft:smooth_basalt
fill 132 87 520 132 90 520 minecraft:blackstone
fill 132 87 522 132 88 522 minecraft:blackstone
setblock 133 87 518 minecraft:smooth_basalt
fill 133 87 519 133 90 519 minecraft:blackstone
setblock 133 87 523 minecraft:smooth_basalt
fill 133 87 524 133 90 524 minecraft:blackstone
setblock 133 87 538 minecraft:smooth_basalt
setblock 133 87 539 minecraft:blackstone
setblock 134 87 512 minecraft:smooth_basalt
fill 134 87 513 134 89 513 minecraft:blackstone
setblock 134 87 517 minecraft:smooth_basalt
fill 134 87 518 134 90 518 minecraft:blackstone
setblock 134 87 522 minecraft:smooth_basalt
fill 134 87 523 134 90 523 minecraft:blackstone
setblock 134 87 527 minecraft:smooth_basalt
fill 134 87 528 134 90 528 minecraft:blackstone
setblock 134 87 532 minecraft:smooth_basalt
setblock 134 87 533 minecraft:blackstone
setblock 134 87 537 minecraft:smooth_basalt
fill 134 87 538 134 89 538 minecraft:blackstone
setblock 134 87 542 minecraft:smooth_basalt
fill 134 87 543 134 90 543 minecraft:blackstone
setblock 134 87 545 minecraft:blackstone
setblock 135 87 511 minecraft:smooth_basalt
fill 135 87 512 135 90 512 minecraft:blackstone
setblock 135 87 516 minecraft:smooth_basalt
fill 135 87 517 135 90 517 minecraft:blackstone
setblock 135 87 521 minecraft:smooth_basalt
fill 135 87 522 135 90 522 minecraft:blackstone
setblock 135 87 526 minecraft:smooth_basalt
fill 135 87 527 136 90 527 minecraft:blackstone
setblock 135 87 531 minecraft:smooth_basalt
fill 135 87 532 135 89 532 minecraft:blackstone
setblock 135 87 536 minecraft:smooth_basalt
fill 135 87 537 135 90 537 minecraft:blackstone
setblock 135 87 541 minecraft:smooth_basalt
fill 135 87 542 135 90 542 minecraft:blackstone
setblock 135 87 546 minecraft:smooth_basalt
fill 135 87 547 135 90 547 minecraft:blackstone
fill 136 87 515 136 193 515 minecraft:blackstone
fill 136 87 530 136 195 530 minecraft:blackstone
fill 136 87 539 136 193 539 minecraft:blackstone
fill 136 87 541 136 195 541 minecraft:blackstone
fill 94 88 550 94 191 550 minecraft:blackstone
fill 95 88 511 98 88 511 minecraft:blackstone
setblock 95 88 515 minecraft:smooth_basalt
fill 95 88 516 95 91 516 minecraft:blackstone
setblock 95 88 520 minecraft:smooth_basalt
fill 95 88 521 95 91 521 minecraft:blackstone
setblock 95 88 525 minecraft:smooth_basalt
fill 95 88 526 95 91 526 minecraft:blackstone
setblock 95 88 536 minecraft:blackstone
setblock 95 88 540 minecraft:smooth_basalt
fill 95 88 541 95 91 541 minecraft:blackstone
setblock 95 88 544 minecraft:blackstone
setblock 95 88 545 minecraft:smooth_basalt
fill 95 88 546 95 91 546 minecraft:blackstone
setblock 95 88 550 minecraft:smooth_basalt
fill 95 88 551 98 88 551 minecraft:blackstone
setblock 96 88 514 minecraft:smooth_basalt
fill 96 88 515 96 90 515 minecraft:blackstone
setblock 96 88 519 minecraft:smooth_basalt
fill 96 88 520 96 91 520 minecraft:blackstone
setblock 96 88 524 minecraft:smooth_basalt
fill 96 88 525 96 89 525 minecraft:blackstone
setblock 96 88 540 minecraft:blackstone
setblock 96 88 544 minecraft:smooth_basalt
fill 96 88 545 96 91 545 minecraft:blackstone
setblock 97 88 518 minecraft:smooth_basalt
fill 97 88 519 97 89 519 minecraft:blackstone
setblock 99 88 511 minecraft:smooth_basalt
setblock 100 88 511 minecraft:blackstone
setblock 108 88 551 minecraft:blackstone
fill 109 88 537 110 89 537 minecraft:gilded_blackstone
setblock 109 88 551 minecraft:smooth_basalt
fill 110 88 551 113 88 551 minecraft:blackstone
fill 111 88 510 111 195 510 minecraft:blackstone
fill 111 88 550 111 91 550 minecraft:blackstone
setblock 114 88 551 minecraft:smooth_basalt
setblock 115 88 550 minecraft:smooth_basalt
fill 115 88 551 115 91 551 minecraft:blackstone
setblock 132 88 519 minecraft:blackstone
setblock 133 88 517 minecraft:smooth_basalt
fill 133 88 518 133 91 518 minecraft:blackstone
setblock 133 88 522 minecraft:smooth_basalt
fill 133 88 523 133 91 523 minecraft:blackstone
setblock 134 88 511 minecraft:smooth_basalt
setblock 134 88 516 minecraft:smooth_basalt
fill 134 88 517 134 91 517 minecraft:blackstone
setblock 134 88 521 minecraft:smooth_basalt
fill 134 88 522 134 91 522 minecraft:blackstone
setblock 134 88 526 minecraft:smooth_basalt
fill 134 88 527 134 91 527 minecraft:blackstone
setblock 134 88 536 minecraft:smooth_basalt
setblock 134 88 537 minecraft:blackstone
setblock 134 88 541 minecraft:smooth_basalt
fill 134 88 542 134 90 542 minecraft:blackstone
fill 135 88 511 135 91 511 minecraft:blackstone
setblock 135 88 515 minecraft:smooth_basalt
fill 135 88 516 135 91 516 minecraft:blackstone
setblock 135 88 520 minecraft:smooth_basalt
fill 135 88 521 135 91 521 minecraft:blackstone
setblock 135 88 525 minecraft:smooth_basalt
fill 135 88 526 135 91 526 minecraft:blackstone
setblock 135 88 530 minecraft:smooth_basalt
fill 135 88 531 135 91 531 minecraft:blackstone
setblock 135 88 535 minecraft:smooth_basalt
fill 135 88 536 135 89 536 minecraft:blackstone
setblock 135 88 540 minecraft:smooth_basalt
fill 135 88 541 135 91 541 minecraft:blackstone
setblock 135 88 545 minecraft:smooth_basalt
fill 135 88 546 135 91 546 minecraft:blackstone
fill 136 88 520 136 195 520 minecraft:blackstone
fill 136 88 525 136 193 525 minecraft:blackstone
fill 136 88 535 136 195 535 minecraft:blackstone
fill 136 88 540 136 195 540 minecraft:blackstone
fill 136 88 545 136 195 545 minecraft:blackstone
fill 95 89 511 97 89 511 minecraft:blackstone
setblock 95 89 514 minecraft:smooth_basalt
fill 95 89 515 95 92 515 minecraft:blackstone
setblock 95 89 519 minecraft:smooth_basalt
fill 95 89 520 95 92 520 minecraft:blackstone
setblock 95 89 524 minecraft:smooth_basalt
fill 95 89 525 95 92 525 minecraft:blackstone
setblock 95 89 539 minecraft:smooth_basalt
fill 95 89 540 95 92 540 minecraft:blackstone
setblock 95 89 544 minecraft:smooth_basalt
fill 95 89 545 95 92 545 minecraft:blackstone
setblock 95 89 549 minecraft:smooth_basalt
fill 95 89 550 95 91 551 minecraft:blackstone
setblock 96 89 513 minecraft:smooth_basalt
fill 96 89 514 96 90 514 minecraft:blackstone
setblock 96 89 518 minecraft:smooth_basalt
fill 96 89 519 96 92 519 minecraft:blackstone
setblock 96 89 523 minecraft:smooth_basalt
fill 96 89 524 96 92 524 minecraft:blackstone
setblock 96 89 543 minecraft:smooth_basalt
fill 96 89 544 96 92 544 minecraft:blackstone
fill 96 89 551 97 89 551 minecraft:blackstone
setblock 97 89 518 minecraft:blackstone
setblock 98 89 511 minecraft:smooth_basalt
setblock 98 89 551 minecraft:smooth_basalt
setblock 108 89 551 minecraft:smooth_basalt
fill 109 89 551 112 89 551 minecraft:blackstone
setblock 113 89 551 minecraft:smooth_basalt
setblock 114 89 550 minecraft:smooth_basalt
fill 114 89 551 114 92 551 minecraft:blackstone
fill 117 89 552 117 195 552 minecraft:blackstone
fill 122 89 542 127 143 543 minecraft:smooth_basalt
fill 123 89 541 126 143 541 minecraft:smooth_basalt
fill 123 89 544 126 143 544 minecraft:smooth_basalt
fill 124 89 540 125 143 540 minecraft:smooth_basalt
fill 125 89 545 125 143 545 minecraft:smooth_basalt
setblock 132 89 522 minecraft:smooth_basalt
fill 132 89 523 132 92 523 minecraft:blackstone
setblock 133 89 511 minecraft:smooth_basalt
setblock 133 89 516 minecraft:smooth_basalt
fill 133 89 517 133 92 517 minecraft:blackstone
setblock 133 89 521 minecraft:smooth_basalt
fill 133 89 522 133 92 522 minecraft:blackstone
setblock 133 89 525 minecraft:blackstone
setblock 133 89 526 minecraft:smooth_basalt
fill 134 89 511 134 92 511 minecraft:blackstone
setblock 134 89 515 minecraft:smooth_basalt
fill 134 89 516 134 92 516 minecraft:blackstone
setblock 134 89 520 minecraft:smooth_basalt
fill 134 89 521 134 92 521 minecraft:blackstone
setblock 134 89 525 minecraft:smooth_basalt
fill 134 89 526 134 92 526 minecraft:blackstone
setblock 134 89 540 minecraft:smooth_basalt
fill 134 89 541 134 90 541 minecraft:blackstone
setblock 135 89 514 minecraft:smooth_basalt
fill 135 89 515 135 92 515 minecraft:blackstone
setblock 135 89 519 minecraft:smooth_basalt
fill 135 89 520 135 92 520 minecraft:blackstone
setblock 135 89 524 minecraft:smooth_basalt
fill 135 89 525 135 92 525 minecraft:blackstone
setblock 135 89 529 minecraft:smooth_basalt
fill 135 89 530 135 92 530 minecraft:blackstone
setblock 135 89 534 minecraft:smooth_basalt
setblock 135 89 535 minecraft:blackstone
setblock 135 89 539 minecraft:smooth_basalt
fill 135 89 540 135 92 540 minecraft:blackstone
setblock 135 89 544 minecraft:smooth_basalt
fill 135 89 545 135 92 545 minecraft:blackstone
fill 136 89 524 136 195 524 minecraft:blackstone
fill 94 90 543 94 196 543 minecraft:blackstone
fill 95 90 511 96 90 511 minecraft:blackstone
setblock 95 90 513 minecraft:smooth_basalt
fill 95 90 514 95 93 514 minecraft:blackstone
setblock 95 90 518 minecraft:smooth_basalt
fill 95 90 519 95 93 519 minecraft:blackstone
setblock 95 90 523 minecraft:smooth_basalt
fill 95 90 524 95 93 524 minecraft:blackstone
setblock 95 90 539 minecraft:blackstone
setblock 95 90 543 minecraft:smooth_basalt
fill 95 90 544 95 93 544 minecraft:blackstone
setblock 95 90 548 minecraft:smooth_basalt
fill 95 90 549 95 93 549 minecraft:blackstone
setblock 96 90 517 minecraft:smooth_basalt
fill 96 90 518 96 92 518 minecraft:blackstone
setblock 96 90 522 minecraft:smooth_basalt
fill 96 90 523 96 93 523 minecraft:blackstone
fill 96 90 543 96 91 543 minecraft:blackstone
setblock 96 90 547 minecraft:smooth_basalt
setblock 96 90 551 minecraft:blackstone
setblock 97 90 511 minecraft:smooth_basalt
setblock 97 90 551 minecraft:smooth_basalt
setblock 107 90 551 minecraft:smooth_basalt
fill 108 90 551 111 90 551 minecraft:blackstone
fill 110 90 550 110 92 550 minecraft:blackstone
setblock 112 90 551 minecraft:smooth_basalt
setblock 113 90 550 minecraft:smooth_basalt
fill 113 90 551 113 93 551 minecraft:blackstone
fill 114 90 550 114 93 550 minecraft:blackstone
fill 121 90 542 121 91 543 minecraft:blackstone
fill 122 90 540 122 91 541 minecraft:blackstone
fill 122 90 544 122 91 545 minecraft:blackstone
fill 123 90 540 123 91 540 minecraft:blackstone
fill 123 90 545 124 91 545 minecraft:blackstone
fill 124 90 539 125 91 539 minecraft:blackstone
fill 124 90 546 125 91 546 minecraft:blackstone
fill 126 90 540 127 91 540 minecraft:blackstone
fill 126 90 545 127 91 545 minecraft:blackstone
fill 127 90 541 127 91 541 minecraft:blackstone
fill 127 90 544 127 91 544 minecraft:blackstone
fill 128 90 542 128 91 543 minecraft:blackstone
setblock 132 90 521 minecraft:smooth_basalt
fill 132 90 522 132 93 522 minecraft:blackstone
fill 133 90 511 133 93 511 minecraft:blackstone
setblock 133 90 520 minecraft:smooth_basalt
fill 133 90 521 133 93 521 minecraft:blackstone
setblock 133 90 525 minecraft:smooth_basalt
fill 133 90 526 133 93 526 minecraft:blackstone
setblock 134 90 514 minecraft:smooth_basalt
fill 134 90 515 134 93 515 minecraft:blackstone
setblock 134 90 519 minecraft:smooth_basalt
fill 134 90 520 134 93 520 minecraft:blackstone
setblock 134 90 524 minecraft:smooth_basalt
fill 134 90 525 134 93 525 minecraft:blackstone
setblock 134 90 529 minecraft:smooth_basalt
setblock 134 90 544 minecraft:smooth_basalt
setblock 135 90 513 minecraft:smooth_basalt
fill 135 90 514 135 93 514 minecraft:blackstone
setblock 135 90 518 minecraft:smooth_basalt
fill 135 90 519 135 93 519 minecraft:blackstone
setblock 135 90 523 minecraft:smooth_basalt
fill 135 90 524 135 93 524 minecraft:blackstone
setblock 135 90 528 minecraft:smooth_basalt
fill 135 90 529 135 93 529 minecraft:blackstone
setblock 135 90 538 minecraft:smooth_basalt
fill 135 90 539 135 91 539 minecraft:blackstone
setblock 135 90 543 minecraft:smooth_basalt
fill 135 90 544 135 93 544 minecraft:blackstone
setblock 135 90 548 minecraft:smooth_basalt
fill 136 90 528 136 193 528 minecraft:blackstone
fill 136 90 538 136 195 538 minecraft:blackstone
fill 94 91 527 94 191 527 minecraft:blackstone
setblock 95 91 511 minecraft:blackstone
setblock 95 91 512 minecraft:smooth_basalt
fill 95 91 513 95 94 513 minecraft:blackstone
setblock 95 91 517 minecraft:smooth_basalt
fill 95 91 518 95 94 518 minecraft:blackstone
setblock 95 91 522 minecraft:smooth_basalt
fill 95 91 523 95 94 523 minecraft:blackstone
setblock 95 91 527 minecraft:smooth_basalt
setblock 95 91 542 minecraft:smooth_basalt
fill 95 91 543 95 94 543 minecraft:blackstone
setblock 95 91 547 minecraft:smooth_basalt
fill 95 91 548 96 93 548 minecraft:blackstone
setblock 96 91 511 minecraft:smooth_basalt
setblock 96 91 516 minecraft:smooth_basalt
setblock 96 91 517 minecraft:blackstone
setblock 96 91 521 minecraft:smooth_basalt
fill 96 91 522 96 93 522 minecraft:blackstone
setblock 96 91 546 minecraft:smooth_basalt
fill 96 91 547 96 94 547 minecraft:blackstone
setblock 96 91 551 minecraft:smooth_basalt
fill 97 91 511 97 94 511 minecraft:blackstone
fill 97 91 551 98 93 551 minecraft:blackstone
fill 104 91 539 107 143 541 minecraft:smooth_basalt
fill 105 91 542 106 143 542 minecraft:smooth_basalt
setblock 106 91 551 minecraft:smooth_basalt
fill 107 91 551 110 91 551 minecraft:blackstone
fill 108 91 550 109 93 550 minecraft:blackstone
setblock 111 91 551 minecraft:smooth_basalt
setblock 112 91 550 minecraft:smooth_basalt
fill 112 91 551 112 94 551 minecraft:blackstone
fill 113 91 550 113 94 550 minecraft:blackstone
fill 120 91 542 120 91 543 minecraft:blackstone
fill 121 91 540 121 91 541 minecraft:blackstone
fill 121 91 544 121 91 545 minecraft:blackstone
fill 122 91 539 123 91 539 minecraft:blackstone
fill 122 91 546 123 91 546 minecraft:blackstone
fill 123 91 538 126 91 538 minecraft:blackstone
fill 124 91 547 125 91 547 minecraft:blackstone
fill 126 91 539 127 91 539 minecraft:blackstone
fill 126 91 546 127 91 546 minecraft:blackstone
fill 128 91 540 128 91 541 minecraft:blackstone
fill 128 91 544 128 91 545 minecraft:blackstone
fill 129 91 541 129 91 544 minecraft:blackstone
fill 132 91 511 132 94 511 minecraft:blackstone
setblock 132 91 520 minecraft:smooth_basalt
fill 132 91 521 132 94 521 minecraft:blackstone
setblock 132 91 524 minecraft:blackstone
setblock 133 91 519 minecraft:smooth_basalt
fill 133 91 520 133 94 520 minecraft:blackstone
setblock 133 91 524 minecraft:smooth_basalt
fill 133 91 525 133 94 525 minecraft:blackstone
fill 133 91 527 133 92 527 minecraft:blackstone
setblock 134 91 514 minecraft:blackstone
setblock 134 91 518 minecraft:smooth_basalt
fill 134 91 519 134 94 519 minecraft:blackstone
setblock 134 91 523 minecraft:smooth_basalt
fill 134 91 524 134 94 524 minecraft:blackstone
setblock 134 91 528 minecraft:smooth_basalt
fill 134 91 529 134 94 529 minecraft:blackstone
setblock 134 91 543 minecraft:smooth_basalt
fill 134 91 544 134 94 544 minecraft:blackstone
setblock 135 91 512 minecraft:smooth_basalt
fill 135 91 513 135 94 513 minecraft:blackstone
setblock 135 91 517 minecraft:smooth_basalt
fill 135 91 518 135 94 518 minecraft:blackstone
setblock 135 91 522 minecraft:smooth_basalt
fill 135 91 523 135 94 523 minecraft:blackstone
setblock 135 91 527 minecraft:smooth_basalt
fill 135 91 528 135 94 528 minecraft:blackstone
setblock 135 91 542 minecraft:smooth_basalt
fill 135 91 543 135 94 543 minecraft:blackstone
setblock 135 91 547 minecraft:smooth_basalt
fill 135 91 548 135 93 549 minecraft:blackstone
fill 136 91 527 136 195 527 minecraft:blackstone
setblock 95 92 511 minecraft:smooth_basalt
fill 95 92 512 95 95 512 minecraft:blackstone
setblock 95 92 516 minecraft:smooth_basalt
fill 95 92 517 95 95 517 minecraft:blackstone
setblock 95 92 521 minecraft:smooth_basalt
fill 95 92 522 95 95 522 minecraft:blackstone
setblock 95 92 526 minecraft:smooth_basalt
fill 95 92 527 95 94 528 minecraft:blackstone
setblock 95 92 541 minecraft:smooth_basalt
fill 95 92 542 95 95 542 minecraft:blackstone
setblock 95 92 546 minecraft:smooth_basalt
fill 95 92 547 95 95 547 minecraft:blackstone
setblock 95 92 550 minecraft:blackstone
setblock 95 92 551 minecraft:smooth_basalt
fill 96 92 511 96 95 511 minecraft:blackstone
setblock 96 92 520 minecraft:smooth_basalt
fill 96 92 521 96 93 521 minecraft:blackstone
setblock 96 92 545 minecraft:smooth_basalt
fill 96 92 546 96 95 546 minecraft:blackstone
setblock 96 92 549 minecraft:blackstone
fill 96 92 551 96 95 551 minecraft:blackstone
fill 98 92 512 101 105 514 minecraft:smooth_basalt
fill 99 92 515 100 143 515 minecraft:smooth_basalt
setblock 99 92 551 minecraft:blackstone
fill 103 92 539 103 93 542 minecraft:blackstone
fill 104 92 538 107 93 538 minecraft:blackstone
fill 104 92 542 104 93 543 minecraft:blackstone
setblock 104 92 551 minecraft:blackstone
fill 105 92 543 107 93 543 minecraft:blackstone
setblock 105 92 551 minecraft:smooth_basalt
fill 106 92 551 109 92 551 minecraft:blackstone
fill 107 92 542 108 93 542 minecraft:blackstone
fill 107 92 550 107 95 550 minecraft:blackstone
fill 108 92 539 108 93 541 minecraft:blackstone
fill 109 92 549 111 92 549 minecraft:blackstone
setblock 110 92 551 minecraft:smooth_basalt
setblock 111 92 550 minecraft:smooth_basalt
fill 111 92 551 111 95 551 minecraft:blackstone
setblock 112 92 549 minecraft:smooth_basalt
fill 112 92 550 112 95 550 minecraft:blackstone
fill 113 92 549 113 95 549 minecraft:blackstone
setblock 115 92 551 minecraft:smooth_basalt
fill 116 92 513 116 93 513 minecraft:gold_block
fill 131 92 511 131 95 511 minecraft:blackstone
fill 132 92 520 132 94 520 minecraft:blackstone
setblock 132 92 524 minecraft:smooth_basalt
fill 132 92 525 132 95 525 minecraft:blackstone
fill 132 92 551 134 92 551 minecraft:blackstone
setblock 133 92 518 minecraft:smooth_basalt
fill 133 92 519 133 95 519 minecraft:blackstone
setblock 133 92 523 minecraft:smooth_basalt
fill 133 92 524 133 95 524 minecraft:blackstone
setblock 134 92 517 minecraft:smooth_basalt
fill 134 92 518 134 95 518 minecraft:blackstone
setblock 134 92 522 minecraft:smooth_basalt
fill 134 92 523 134 95 523 minecraft:blackstone
setblock 134 92 527 minecraft:smooth_basalt
fill 134 92 528 134 95 528 minecraft:blackstone
fill 134 92 545 134 93 545 minecraft:blackstone
setblock 135 92 511 minecraft:smooth_basalt
fill 135 92 512 135 95 512 minecraft:blackstone
setblock 135 92 516 minecraft:smooth_basalt
fill 135 92 517 135 95 517 minecraft:blackstone
setblock 135 92 521 minecraft:smooth_basalt
fill 135 92 522 135 95 522 minecraft:blackstone
setblock 135 92 526 minecraft:smooth_basalt
fill 135 92 527 135 95 527 minecraft:blackstone
setblock 135 92 531 minecraft:smooth_basalt
setblock 135 92 541 minecraft:smooth_basalt
fill 135 92 542 135 95 542 minecraft:blackstone
setblock 135 92 546 minecraft:smooth_basalt
fill 135 92 547 135 95 547 minecraft:blackstone
setblock 135 92 550 minecraft:blackstone
fill 95 93 511 95 96 511 minecraft:blackstone
setblock 95 93 515 minecraft:smooth_basalt
fill 95 93 516 95 96 516 minecraft:blackstone
setblock 95 93 520 minecraft:smooth_basalt
fill 95 93 521 95 96 521 minecraft:blackstone
setblock 95 93 525 minecraft:smooth_basalt
fill 95 93 526 95 96 526 minecraft:blackstone
fill 95 93 541 95 96 541 minecraft:blackstone
setblock 95 93 545 minecraft:smooth_basalt
fill 95 93 546 95 96 546 minecraft:blackstone
setblock 95 93 550 minecraft:smooth_basalt
fill 95 93 551 95 96 551 minecraft:blackstone
setblock 96 93 520 minecraft:blackstone
setblock 96 93 524 minecraft:smooth_basalt
setblock 96 93 544 minecraft:smooth_basalt
fill 96 93 545 96 96 545 minecraft:blackstone
setblock 96 93 549 minecraft:smooth_basalt
fill 96 93 550 96 96 550 minecraft:blackstone
fill 97 93 512 97 94 514 minecraft:blackstone
setblock 97 93 521 minecraft:light[level=12]
setblock 97 93 529 minecraft:light[level=12]
setblock 97 93 537 minecraft:light[level=12]
setblock 97 93 545 minecraft:light[level=12]
fill 98 93 511 101 94 511 minecraft:blackstone
fill 98 93 515 98 94 515 minecraft:blackstone
setblock 99 93 551 minecraft:smooth_basalt
fill 100 93 551 103 93 551 minecraft:blackstone
fill 101 93 515 101 94 515 minecraft:blackstone
fill 102 93 512 102 94 514 minecraft:blackstone
fill 102 93 539 102 93 542 minecraft:blackstone
setblock 103 93 538 minecraft:blackstone
setblock 103 93 543 minecraft:blackstone
fill 104 93 537 107 93 537 minecraft:blackstone
fill 104 93 544 106 93 544 minecraft:blackstone
setblock 104 93 551 minecraft:smooth_basalt
setblock 105 93 513 minecraft:light[level=12]
setblock 105 93 521 minecraft:light[level=12]
setblock 105 93 529 minecraft:light[level=12]
setblock 105 93 545 minecraft:light[level=12]
setblock 105 93 550 minecraft:smooth_basalt
fill 105 93 551 108 93 551 minecraft:blackstone
fill 106 93 550 106 96 550 minecraft:blackstone
fill 107 93 549 110 93 549 minecraft:blackstone
setblock 108 93 538 minecraft:blackstone
setblock 108 93 543 minecraft:blackstone
fill 109 93 539 109 93 542 minecraft:blackstone
setblock 109 93 551 minecraft:smooth_basalt
setblock 110 93 550 minecraft:smooth_basalt
fill 110 93 551 110 96 551 minecraft:blackstone
setblock 111 93 549 minecraft:smooth_basalt
fill 111 93 550 111 96 550 minecraft:blackstone
fill 112 93 549 112 96 549 minecraft:blackstone
setblock 113 93 513 minecraft:light[level=12]
setblock 113 93 521 minecraft:light[level=12]
setblock 113 93 529 minecraft:light[level=12]
setblock 113 93 537 minecraft:light[level=12]
setblock 113 93 545 minecraft:light[level=12]
setblock 114 93 551 minecraft:smooth_basalt
fill 115 93 551 116 95 551 minecraft:blackstone
setblock 121 93 513 minecraft:light[level=12]
setblock 121 93 521 minecraft:light[level=12]
setblock 121 93 529 minecraft:light[level=12]
setblock 121 93 537 minecraft:light[level=12]
setblock 121 93 545 minecraft:light[level=12]
fill 124 93 527 127 143 529 minecraft:smooth_basalt
fill 125 93 526 126 143 526 minecraft:smooth_basalt
setblock 129 93 513 minecraft:light[level=12]
setblock 129 93 521 minecraft:light[level=12]
setblock 129 93 529 minecraft:light[level=12]
setblock 129 93 537 minecraft:light[level=12]
setblock 129 93 545 minecraft:light[level=12]
fill 130 93 511 130 96 511 minecraft:blackstone
fill 130 93 551 133 93 551 minecraft:blackstone
setblock 132 93 523 minecraft:smooth_basalt
fill 132 93 524 132 96 524 minecraft:blackstone
fill 132 93 526 132 94 526 minecraft:blackstone
fill 133 93 518 133 96 518 minecraft:blackstone
setblock 133 93 522 minecraft:smooth_basalt
fill 133 93 523 133 96 523 minecraft:blackstone
setblock 133 93 527 minecraft:smooth_basalt
fill 133 93 528 133 96 528 minecraft:blackstone
setblock 134 93 511 minecraft:smooth_basalt
setblock 134 93 516 minecraft:smooth_basalt
fill 134 93 517 134 96 517 minecraft:blackstone
setblock 134 93 521 minecraft:smooth_basalt
fill 134 93 522 134 96 522 minecraft:blackstone
setblock 134 93 526 minecraft:smooth_basalt
fill 134 93 527 134 96 527 minecraft:blackstone
setblock 134 93 546 minecraft:smooth_basalt
fill 134 93 547 134 96 547 minecraft:blackstone
setblock 134 93 551 minecraft:smooth_basalt
fill 135 93 511 135 96 511 minecraft:blackstone
setblock 135 93 515 minecraft:smooth_basalt
fill 135 93 516 135 96 516 minecraft:blackstone
setblock 135 93 520 minecraft:smooth_basalt
fill 135 93 521 135 96 521 minecraft:blackstone
setblock 135 93 525 minecraft:smooth_basalt
fill 135 93 526 135 96 526 minecraft:blackstone
setblock 135 93 530 minecraft:smooth_basalt
fill 135 93 531 135 96 531 minecraft:blackstone
setblock 135 93 541 minecraft:blackstone
setblock 135 93 545 minecraft:smooth_basalt
fill 135 93 546 135 96 546 minecraft:blackstone
setblock 135 93 550 minecraft:smooth_basalt
fill 135 93 551 135 96 551 minecraft:blackstone
setblock 95 94 514 minecraft:smooth_basalt
fill 95 94 515 95 97 515 minecraft:blackstone
setblock 95 94 519 minecraft:smooth_basalt
fill 95 94 520 95 97 520 minecraft:blackstone
setblock 95 94 524 minecraft:smooth_basalt
fill 95 94 525 95 97 525 minecraft:blackstone
setblock 95 94 529 minecraft:smooth_basalt
setblock 95 94 544 minecraft:smooth_basalt
fill 95 94 545 95 97 545 minecraft:blackstone
setblock 95 94 548 minecraft:blackstone
setblock 95 94 549 minecraft:smooth_basalt
fill 95 94 550 95 97 550 minecraft:blackstone
setblock 96 94 513 minecraft:blackstone
setblock 96 94 523 minecraft:smooth_basalt
fill 96 94 544 96 97 544 minecraft:blackstone
setblock 96 94 548 minecraft:smooth_basalt
fill 96 94 549 96 97 549 minecraft:blackstone
setblock 97 94 515 minecraft:blackstone
fill 97 94 550 97 94 551 minecraft:blackstone
fill 98 94 516 101 94 516 minecraft:blackstone
setblock 98 94 550 minecraft:blackstone
setblock 98 94 551 minecraft:smooth_basalt
fill 99 94 551 102 94 551 minecraft:blackstone
setblock 102 94 511 minecraft:blackstone
setblock 102 94 515 minecraft:blackstone
fill 102 94 550 103 94 550 minecraft:blackstone
setblock 103 94 513 minecraft:blackstone
setblock 103 94 551 minecraft:smooth_basalt
setblock 104 94 550 minecraft:smooth_basalt
fill 104 94 551 107 94 551 minecraft:blackstone
setblock 105 94 549 minecraft:smooth_basalt
fill 105 94 550 105 97 550 minecraft:blackstone
fill 106 94 549 109 94 549 minecraft:blackstone
setblock 108 94 511 minecraft:smooth_basalt
fill 108 94 548 110 94 548 minecraft:blackstone
setblock 108 94 550 minecraft:blackstone
setblock 108 94 551 minecraft:smooth_basalt
fill 109 94 511 111 95 511 minecraft:blackstone
setblock 109 94 550 minecraft:smooth_basalt
fill 109 94 551 109 97 551 minecraft:blackstone
setblock 110 94 549 minecraft:smooth_basalt
fill 110 94 550 110 97 550 minecraft:blackstone
setblock 111 94 548 minecraft:smooth_basalt
fill 111 94 549 111 97 549 minecraft:blackstone
fill 112 94 548 112 97 548 minecraft:blackstone
setblock 113 94 551 minecraft:smooth_basalt
setblock 114 94 549 minecraft:blackstone
setblock 114 94 550 minecraft:smooth_basalt
fill 114 94 551 114 97 551 minecraft:blackstone
fill 115 94 550 115 97 550 minecraft:blackstone
fill 123 94 527 123 95 529 minecraft:blackstone
fill 124 94 526 124 95 526 minecraft:blackstone
fill 124 94 530 127 95 530 minecraft:blackstone
fill 125 94 525 126 95 525 minecraft:blackstone
fill 127 94 526 128 95 526 minecraft:blackstone
setblock 128 94 511 minecraft:smooth_basalt
fill 128 94 527 128 95 529 minecraft:blackstone
setblock 128 94 551 minecraft:smooth_basalt
fill 129 94 511 129 97 511 minecraft:blackstone
fill 129 94 551 132 94 551 minecraft:blackstone
fill 130 94 534 130 95 535 minecraft:gilded_blackstone
fill 130 94 550 133 94 550 minecraft:blackstone
setblock 131 94 512 minecraft:blackstone
setblock 132 94 512 minecraft:smooth_basalt
setblock 132 94 522 minecraft:smooth_basalt
fill 132 94 523 132 97 523 minecraft:blackstone
setblock 132 94 527 minecraft:smooth_basalt
setblock 133 94 511 minecraft:smooth_basalt
fill 133 94 512 133 97 512 minecraft:blackstone
setblock 133 94 521 minecraft:smooth_basalt
fill 133 94 522 133 97 522 minecraft:blackstone
setblock 133 94 526 minecraft:smooth_basalt
fill 133 94 527 133 97 527 minecraft:blackstone
fill 133 94 529 133 95 529 minecraft:blackstone
setblock 133 94 551 minecraft:smooth_basalt
fill 134 94 511 134 97 511 minecraft:blackstone
setblock 134 94 514 minecraft:blackstone
setblock 134 94 515 minecraft:smooth_basalt
fill 134 94 516 134 97 516 minecraft:blackstone
setblock 134 94 520 minecraft:smooth_basalt
fill 134 94 521 134 97 521 minecraft:blackstone
setblock 134 94 525 minecraft:smooth_basalt
fill 134 94 526 134 97 526 minecraft:blackstone
setblock 134 94 530 minecraft:smooth_basalt
setblock 134 94 545 minecraft:smooth_basalt
fill 134 94 546 134 97 546 minecraft:blackstone
fill 134 94 548 134 94 549 minecraft:blackstone
fill 134 94 551 134 97 551 minecraft:blackstone
setblock 135 94 514 minecraft:smooth_basalt
fill 135 94 515 135 97 515 minecraft:blackstone
setblock 135 94 519 minecraft:smooth_basalt
fill 135 94 520 135 97 520 minecraft:blackstone
setblock 135 94 524 minecraft:smooth_basalt
fill 135 94 525 135 97 525 minecraft:blackstone
setblock 135 94 529 minecraft:smooth_basalt
fill 135 94 530 135 97 530 minecraft:blackstone
setblock 135 94 544 minecraft:smooth_basalt
fill 135 94 545 135 97 545 minecraft:blackstone
setblock 135 94 548 minecraft:blackstone
setblock 135 94 549 minecraft:smooth_basalt
fill 135 94 550 135 97 550 minecraft:blackstone
setblock 95 95 513 minecraft:smooth_basalt
fill 95 95 514 95 98 514 minecraft:blackstone
setblock 95 95 518 minecraft:smooth_basalt
fill 95 95 519 95 97 519 minecraft:blackstone
setblock 95 95 523 minecraft:smooth_basalt
fill 95 95 524 95 98 524 minecraft:blackstone
setblock 95 95 527 minecraft:blackstone
setblock 95 95 528 minecraft:smooth_basalt
fill 95 95 529 95 98 529 minecraft:blackstone
setblock 95 95 543 minecraft:smooth_basalt
fill 95 95 544 95 98 544 minecraft:blackstone
setblock 95 95 548 minecraft:smooth_basalt
fill 95 95 549 95 98 549 minecraft:blackstone
setblock 96 95 547 minecraft:smooth_basalt
fill 96 95 548 96 98 548 minecraft:blackstone
setblock 97 95 511 minecraft:smooth_basalt
setblock 97 95 550 minecraft:blackstone
setblock 97 95 551 minecraft:smooth_basalt
fill 98 95 511 98 98 511 minecraft:blackstone
setblock 98 95 550 minecraft:smooth_basalt
fill 98 95 551 101 95 551 minecraft:blackstone
fill 99 95 550 102 95 550 minecraft:blackstone
setblock 102 95 551 minecraft:smooth_basalt
setblock 103 95 549 minecraft:blackstone
setblock 103 95 550 minecraft:smooth_basalt
fill 103 95 551 106 95 551 minecraft:blackstone
setblock 104 95 549 minecraft:smooth_basalt
fill 104 95 550 104 98 550 minecraft:blackstone
fill 105 95 511 106 95 511 minecraft:blackstone
fill 105 95 549 108 95 549 minecraft:blackstone
fill 106 95 548 109 95 548 minecraft:blackstone
setblock 107 95 511 minecraft:smooth_basalt
setblock 107 95 551 minecraft:smooth_basalt
fill 108 95 511 108 98 511 minecraft:blackstone
setblock 108 95 550 minecraft:smooth_basalt
fill 108 95 551 108 98 551 minecraft:blackstone
setblock 109 95 549 minecraft:smooth_basalt
fill 109 95 550 109 98 550 minecraft:blackstone
setblock 110 95 548 minecraft:smooth_basalt
fill 110 95 549 110 98 549 minecraft:blackstone
fill 111 95 548 111 98 548 minecraft:blackstone
setblock 112 95 511 minecraft:smooth_basalt
setblock 112 95 551 minecraft:smooth_basalt
setblock 113 95 550 minecraft:smooth_basalt
fill 113 95 551 113 98 551 minecraft:blackstone
setblock 114 95 549 minecraft:smooth_basalt
fill 114 95 550 114 98 550 minecraft:blackstone
fill 122 95 527 122 95 528 minecraft:blackstone
setblock 123 95 526 minecraft:blackstone
setblock 123 95 530 minecraft:blackstone
setblock 124 95 525 minecraft:blackstone
fill 124 95 531 127 95 531 minecraft:blackstone
setblock 126 95 551 minecraft:blackstone
setblock 127 95 511 minecraft:smooth_basalt
fill 127 95 525 128 95 525 minecraft:blackstone
setblock 127 95 551 minecraft:smooth_basalt
fill 128 95 511 128 98 511 minecraft:blackstone
setblock 128 95 530 minecraft:blackstone
setblock 128 95 550 minecraft:smooth_basalt
fill 128 95 551 131 95 551 minecraft:blackstone
fill 129 95 512 130 95 512 minecraft:blackstone
fill 129 95 526 129 95 529 minecraft:blackstone
fill 129 95 550 132 95 550 minecraft:blackstone
setblock 131 95 512 minecraft:smooth_basalt
setblock 132 95 511 minecraft:smooth_basalt
fill 132 95 512 132 98 512 minecraft:blackstone
setblock 132 95 521 minecraft:smooth_basalt
fill 132 95 522 132 97 522 minecraft:blackstone
setblock 132 95 526 minecraft:smooth_basalt
fill 132 95 527 132 98 527 minecraft:blackstone
setblock 132 95 551 minecraft:smooth_basalt
fill 133 95 511 133 98 511 minecraft:blackstone
setblock 133 95 520 minecraft:smooth_basalt
fill 133 95 521 133 98 521 minecraft:blackstone
setblock 133 95 525 minecraft:smooth_basalt
fill 133 95 526 133 98 526 minecraft:blackstone
setblock 133 95 550 minecraft:smooth_basalt
fill 133 95 551 133 98 551 minecraft:blackstone
fill 134 95 512 134 95 513 minecraft:blackstone
setblock 134 95 514 minecraft:smooth_basalt
fill 134 95 515 134 98 515 minecraft:blackstone
setblock 134 95 519 minecraft:smooth_basalt
fill 134 95 520 134 98 520 minecraft:blackstone
setblock 134 95 524 minecraft:smooth_basalt
fill 134 95 525 134 98 525 minecraft:blackstone
setblock 134 95 529 minecraft:smooth_basalt
fill 134 95 530 134 98 530 minecraft:blackstone
fill 134 95 545 134 97 545 minecraft:blackstone
setblock 134 95 548 minecraft:blackstone
setblock 134 95 549 minecraft:smooth_basalt
fill 134 95 550 134 98 550 minecraft:blackstone
setblock 135 95 513 minecraft:smooth_basalt
fill 135 95 514 135 98 514 minecraft:blackstone
setblock 135 95 518 minecraft:smooth_basalt
fill 135 95 519 135 98 519 minecraft:blackstone
setblock 135 95 523 minecraft:smooth_basalt
fill 135 95 524 135 98 524 minecraft:blackstone
setblock 135 95 528 minecraft:smooth_basalt
fill 135 95 529 135 98 529 minecraft:blackstone
setblock 135 95 532 minecraft:blackstone
setblock 135 95 543 minecraft:smooth_basalt
fill 135 95 544 135 98 544 minecraft:blackstone
setblock 135 95 548 minecraft:smooth_basalt
fill 135 95 549 135 98 549 minecraft:blackstone
setblock 95 96 512 minecraft:smooth_basalt
fill 95 96 513 95 99 513 minecraft:blackstone
setblock 95 96 517 minecraft:smooth_basalt
fill 95 96 518 95 97 518 minecraft:blackstone
setblock 95 96 522 minecraft:smooth_basalt
fill 95 96 523 95 98 523 minecraft:blackstone
setblock 95 96 527 minecraft:smooth_basalt
fill 95 96 528 95 99 528 minecraft:blackstone
fill 95 96 530 95 97 530 minecraft:blackstone
setblock 95 96 542 minecraft:smooth_basalt
fill 95 96 543 95 99 543 minecraft:blackstone
setblock 95 96 547 minecraft:smooth_basalt
fill 95 96 548 95 99 548 minecraft:blackstone
setblock 96 96 511 minecraft:smooth_basalt
setblock 96 96 546 minecraft:smooth_basalt
fill 96 96 547 96 99 547 minecraft:blackstone
setblock 96 96 551 minecraft:smooth_basalt
fill 97 96 511 97 99 511 minecraft:blackstone
fill 97 96 548 97 96 549 minecraft:blackstone
setblock 97 96 550 minecraft:smooth_basalt
fill 97 96 551 100 96 551 minecraft:blackstone
fill 98 96 550 101 96 550 minecraft:blackstone
fill 99 96 511 99 97 511 minecraft:blackstone
fill 101 96 549 102 96 549 minecraft:blackstone
setblock 101 96 551 minecraft:smooth_basalt
setblock 102 96 550 minecraft:smooth_basalt
fill 102 96 551 105 96 551 minecraft:blackstone
fill 103 96 511 105 96 511 minecraft:blackstone
setblock 103 96 549 minecraft:smooth_basalt
fill 103 96 550 103 99 550 minecraft:blackstone
fill 104 96 549 107 96 549 minecraft:blackstone
fill 105 96 548 108 96 548 minecraft:blackstone
setblock 106 96 511 minecraft:smooth_basalt
setblock 106 96 551 minecraft:smooth_basalt
fill 107 96 511 107 99 511 minecraft:blackstone
setblock 107 96 550 minecraft:smooth_basalt
fill 107 96 551 107 99 551 minecraft:blackstone
fill 108 96 547 109 96 547 minecraft:blackstone
setblock 108 96 549 minecraft:smooth_basalt
fill 108 96 550 108 99 550 minecraft:blackstone
fill 109 96 511 110 96 511 minecraft:blackstone
setblock 109 96 548 minecraft:smooth_basalt
fill 109 96 549 109 99 549 minecraft:blackstone
fill 110 96 548 110 99 548 minecraft:blackstone
setblock 111 96 511 minecraft:smooth_basalt
setblock 111 96 551 minecraft:smooth_basalt
fill 112 96 511 113 98 511 minecraft:blackstone
setblock 112 96 550 minecraft:smooth_basalt
fill 112 96 551 112 99 551 minecraft:blackstone
setblock 113 96 549 minecraft:smooth_basalt
fill 113 96 550 113 99 550 minecraft:blackstone
fill 114 96 549 114 97 549 minecraft:blackstone
setblock 115 96 551 minecraft:blackstone
setblock 116 96 551 minecraft:smooth_basalt
fill 117 96 551 117 99 551 minecraft:blackstone
fill 124 96 551 125 96 551 minecraft:blackstone
setblock 125 96 511 minecraft:blackstone
setblock 126 96 511 minecraft:smooth_basalt
setblock 126 96 550 minecraft:blackstone
setblock 126 96 551 minecraft:smooth_basalt
fill 127 96 511 127 99 511 minecraft:blackstone
setblock 127 96 550 minecraft:smooth_basalt
fill 127 96 551 130 96 551 minecraft:blackstone
fill 128 96 512 129 96 512 minecraft:blackstone
fill 128 96 550 131 96 550 minecraft:blackstone
setblock 130 96 512 minecraft:smooth_basalt
fill 130 96 549 132 96 549 minecraft:blackstone
setblock 131 96 511 minecraft:smooth_basalt
fill 131 96 512 131 99 512 minecraft:blackstone
setblock 131 96 551 minecraft:smooth_basalt
fill 132 96 511 132 99 511 minecraft:blackstone
setblock 132 96 521 minecraft:blackstone
setblock 132 96 525 minecraft:smooth_basalt
fill 132 96 526 132 98 526 minecraft:blackstone
fill 132 96 528 132 97 528 minecraft:blackstone
setblock 132 96 550 minecraft:smooth_basalt
fill 132 96 551 132 99 551 minecraft:blackstone
setblock 133 96 519 minecraft:smooth_basalt
fill 133 96 520 133 97 520 minecraft:blackstone
setblock 133 96 524 minecraft:smooth_basalt
fill 133 96 525 133 99 525 minecraft:blackstone
setblock 133 96 529 minecraft:smooth_basalt
fill 133 96 550 133 99 550 minecraft:blackstone
setblock 134 96 512 minecraft:blackstone
setblock 134 96 513 minecraft:smooth_basalt
fill 134 96 514 134 99 514 minecraft:blackstone
setblock 134 96 518 minecraft:smooth_basalt
fill 134 96 519 134 98 519 minecraft:blackstone
setblock 134 96 523 minecraft:smooth_basalt
fill 134 96 524 134 99 524 minecraft:blackstone
setblock 134 96 528 minecraft:smooth_basalt
fill 134 96 529 134 99 529 minecraft:blackstone
fill 134 96 531 134 97 531 minecraft:blackstone
setblock 134 96 548 minecraft:smooth_basalt
fill 134 96 549 134 99 549 minecraft:blackstone
setblock 135 96 512 minecraft:smooth_basalt
fill 135 96 513 135 99 513 minecraft:blackstone
setblock 135 96 517 minecraft:smooth_basalt
fill 135 96 518 135 99 518 minecraft:blackstone
setblock 135 96 522 minecraft:smooth_basalt
fill 135 96 523 135 99 523 minecraft:blackstone
setblock 135 96 527 minecraft:smooth_basalt
fill 135 96 528 135 99 528 minecraft:blackstone
setblock 135 96 532 minecraft:smooth_basalt
fill 135 96 543 135 97 543 minecraft:blackstone
setblock 135 96 547 minecraft:smooth_basalt
fill 135 96 548 135 99 548 minecraft:blackstone
setblock 95 97 511 minecraft:smooth_basalt
fill 95 97 512 95 100 512 minecraft:blackstone
setblock 95 97 516 minecraft:smooth_basalt
setblock 95 97 517 minecraft:blackstone
setblock 95 97 521 minecraft:smooth_basalt
fill 95 97 522 95 98 522 minecraft:blackstone
setblock 95 97 526 minecraft:smooth_basalt
fill 95 97 527 95 100 527 minecraft:blackstone
fill 95 97 542 95 98 542 minecraft:blackstone
setblock 95 97 546 minecraft:smooth_basalt
fill 95 97 547 95 100 547 minecraft:blackstone
setblock 95 97 551 minecraft:smooth_basalt
fill 96 97 511 96 100 511 minecraft:blackstone
setblock 96 97 545 minecraft:smooth_basalt
fill 96 97 546 96 100 546 minecraft:blackstone
setblock 96 97 550 minecraft:smooth_basalt
fill 96 97 551 99 97 551 minecraft:blackstone
setblock 97 97 548 minecraft:blackstone
setblock 97 97 549 minecraft:smooth_basalt
fill 97 97 550 100 97 550 minecraft:blackstone
fill 98 97 549 101 97 549 minecraft:blackstone
setblock 100 97 511 minecraft:smooth_basalt
setblock 100 97 551 minecraft:smooth_basalt
fill 101 97 511 104 97 511 minecraft:blackstone
setblock 101 97 550 minecraft:smooth_basalt
fill 101 97 551 104 97 551 minecraft:blackstone
setblock 102 97 549 minecraft:smooth_basalt
fill 102 97 550 102 100 550 minecraft:blackstone
fill 103 97 549 106 97 549 minecraft:blackstone
fill 104 97 548 107 97 548 minecraft:blackstone
setblock 105 97 511 minecraft:smooth_basalt
setblock 105 97 551 minecraft:smooth_basalt
fill 106 97 511 106 100 511 minecraft:blackstone
setblock 106 97 550 minecraft:smooth_basalt
fill 106 97 551 106 100 551 minecraft:blackstone
fill 107 97 547 108 97 547 minecraft:blackstone
setblock 107 97 549 minecraft:smooth_basalt
fill 107 97 550 107 100 550 minecraft:blackstone
setblock 108 97 548 minecraft:smooth_basalt
fill 108 97 549 108 100 549 minecraft:blackstone
setblock 109 97 511 minecraft:blackstone
setblock 109 97 547 minecraft:smooth_basalt
fill 109 97 548 109 100 548 minecraft:blackstone
setblock 110 97 511 minecraft:smooth_basalt
setblock 110 97 551 minecraft:smooth_basalt
fill 111 97 511 111 100 511 minecraft:blackstone
setblock 111 97 550 minecraft:smooth_basalt
fill 111 97 551 111 100 551 minecraft:blackstone
setblock 112 97 549 minecraft:smooth_basalt
fill 112 97 550 112 100 550 minecraft:blackstone
fill 113 97 549 113 99 549 minecraft:blackstone
setblock 115 97 551 minecraft:smooth_basalt
fill 116 97 551 116 100 551 minecraft:blackstone
fill 122 97 551 124 97 551 minecraft:blackstone
setblock 124 97 511 minecraft:blackstone
setblock 125 97 511 minecraft:smooth_basalt
setblock 125 97 550 minecraft:blackstone
setblock 125 97 551 minecraft:smooth_basalt
fill 126 97 511 126 99 512 minecraft:blackstone
setblock 126 97 550 minecraft:smooth_basalt
fill 126 97 551 129 97 551 minecraft:blackstone
fill 127 97 512 128 97 512 minecraft:blackstone
fill 127 97 550 130 97 550 minecraft:blackstone
fill 128 97 549 131 97 549 minecraft:blackstone
setblock 129 97 512 minecraft:smooth_basalt
setblock 130 97 511 minecraft:smooth_basalt
fill 130 97 512 130 99 513 minecraft:blackstone
setblock 130 97 551 minecraft:smooth_basalt
fill 131 97 511 131 100 511 minecraft:blackstone
fill 131 97 513 131 98 513 minecraft:blackstone
setblock 131 97 550 minecraft:smooth_basalt
fill 131 97 551 131 100 551 minecraft:blackstone
setblock 132 97 524 minecraft:smooth_basalt
fill 132 97 525 132 98 525 minecraft:blackstone
setblock 132 97 549 minecraft:smooth_basalt
fill 132 97 550 132 100 550 minecraft:blackstone
setblock 133 97 519 minecraft:blackstone
setblock 133 97 523 minecraft:smooth_basalt
fill 133 97 524 133 99 524 minecraft:blackstone
setblock 133 97 528 minecraft:smooth_basalt
fill 133 97 529 133 98 530 minecraft:blackstone
setblock 133 97 549 minecraft:blackstone
setblock 134 97 512 minecraft:smooth_basalt
fill 134 97 513 134 100 513 minecraft:blackstone
setblock 134 97 517 minecraft:smooth_basalt
fill 134 97 518 134 98 518 minecraft:blackstone
setblock 134 97 522 minecraft:smooth_basalt
fill 134 97 523 134 99 523 minecraft:blackstone
setblock 134 97 527 minecraft:smooth_basalt
fill 134 97 528 134 100 528 minecraft:blackstone
setblock 134 97 547 minecraft:smooth_basalt
fill 134 97 548 134 100 548 minecraft:blackstone
setblock 135 97 511 minecraft:smooth_basalt
fill 135 97 512 135 100 512 minecraft:blackstone
setblock 135 97 516 minecraft:smooth_basalt
fill 135 97 517 135 100 517 minecraft:blackstone
setblock 135 97 521 minecraft:smooth_basalt
fill 135 97 522 135 100 522 minecraft:blackstone
setblock 135 97 526 minecraft:smooth_basalt
fill 135 97 527 135 100 527 minecraft:blackstone
setblock 135 97 531 minecraft:smooth_basalt
fill 135 97 532 135 100 532 minecraft:blackstone
setblock 135 97 546 minecraft:smooth_basalt
fill 135 97 547 135 100 547 minecraft:blackstone
setblock 135 97 551 minecraft:smooth_basalt
fill 95 98 511 95 101 511 minecraft:blackstone
setblock 95 98 515 minecraft:smooth_basalt
setblock 95 98 521 minecraft:blackstone
setblock 95 98 525 minecraft:smooth_basalt
fill 95 98 526 95 99 526 minecraft:blackstone
setblock 95 98 530 minecraft:smooth_basalt
setblock 95 98 545 minecraft:smooth_basalt
fill 95 98 546 95 101 546 minecraft:blackstone
setblock 95 98 550 minecraft:smooth_basalt
fill 95 98 551 98 98 551 minecraft:blackstone
setblock 96 98 545 minecraft:blackstone
setblock 96 98 549 minecraft:smooth_basalt
fill 96 98 550 99 98 550 minecraft:blackstone
setblock 97 98 548 minecraft:smooth_basalt
fill 97 98 549 100 98 549 minecraft:blackstone
setblock 99 98 511 minecraft:smooth_basalt
setblock 99 98 551 minecraft:smooth_basalt
fill 100 98 511 103 98 511 minecraft:blackstone
setblock 100 98 550 minecraft:smooth_basalt
fill 100 98 551 103 98 551 minecraft:blackstone
setblock 101 98 549 minecraft:smooth_basalt
fill 101 98 550 101 101 550 minecraft:blackstone
fill 102 98 549 105 98 549 minecraft:blackstone
fill 103 98 548 106 98 548 minecraft:blackstone
setblock 104 98 511 minecraft:smooth_basalt
setblock 104 98 551 minecraft:smooth_basalt
fill 105 98 511 105 101 511 minecraft:blackstone
setblock 105 98 550 minecraft:smooth_basalt
fill 105 98 551 105 101 551 minecraft:blackstone
setblock 106 98 549 minecraft:smooth_basalt
fill 106 98 550 106 101 550 minecraft:blackstone
setblock 107 98 512 minecraft:blackstone
setblock 107 98 547 minecraft:blackstone
setblock 107 98 548 minecraft:smooth_basalt
fill 107 98 549 107 101 549 minecraft:blackstone
setblock 108 98 512 minecraft:smooth_basalt
setblock 108 98 547 minecraft:smooth_basalt
fill 108 98 548 108 100 548 minecraft:blackstone
setblock 109 98 511 minecraft:smooth_basalt
setblock 109 98 551 minecraft:smooth_basalt
fill 110 98 511 110 101 511 minecraft:blackstone
setblock 110 98 550 minecraft:smooth_basalt
fill 110 98 551 110 101 551 minecraft:blackstone
setblock 111 98 549 minecraft:smooth_basalt
fill 111 98 550 111 101 550 minecraft:blackstone
fill 112 98 549 112 100 549 minecraft:blackstone
setblock 114 98 551 minecraft:smooth_basalt
setblock 115 98 550 minecraft:smooth_basalt
fill 115 98 551 115 101 551 minecraft:blackstone
setblock 118 98 551 minecraft:blackstone
fill 120 98 551 123 98 551 minecraft:blackstone
setblock 123 98 511 minecraft:blackstone
setblock 124 98 511 minecraft:smooth_basalt
setblock 124 98 550 minecraft:blackstone
setblock 124 98 551 minecraft:smooth_basalt
fill 125 98 511 125 100 512 minecraft:blackstone
setblock 125 98 550 minecraft:smooth_basalt
fill 125 98 551 128 98 551 minecraft:blackstone
fill 126 98 550 129 98 550 minecraft:blackstone
setblock 127 98 512 minecraft:blackstone
fill 127 98 549 130 98 549 minecraft:blackstone
setblock 128 98 512 minecraft:smooth_basalt
fill 128 98 513 129 100 513 minecraft:blackstone
setblock 129 98 511 minecraft:smooth_basalt
fill 129 98 512 129 101 512 minecraft:blackstone
setblock 129 98 551 minecraft:smooth_basalt
fill 130 98 511 130 101 511 minecraft:blackstone
setblock 130 98 550 minecraft:smooth_basalt
fill 130 98 551 130 101 551 minecraft:blackstone
setblock 131 98 549 minecraft:smooth_basalt
fill 131 98 550 131 101 550 minecraft:blackstone
setblock 132 98 513 minecraft:smooth_basalt
setblock 132 98 524 minecraft:blackstone
setblock 132 98 528 minecraft:smooth_basalt
fill 132 98 549 132 99 549 minecraft:blackstone
setblock 133 98 512 minecraft:smooth_basalt
setblock 133 98 522 minecraft:smooth_basalt
fill 133 98 523 133 99 523 minecraft:blackstone
setblock 133 98 527 minecraft:smooth_basalt
fill 133 98 528 133 99 528 minecraft:blackstone
setblock 134 98 511 minecraft:smooth_basalt
fill 134 98 512 134 101 512 minecraft:blackstone
setblock 134 98 516 minecraft:smooth_basalt
setblock 134 98 517 minecraft:blackstone
setblock 134 98 521 minecraft:smooth_basalt
fill 134 98 522 134 99 522 minecraft:blackstone
setblock 134 98 526 minecraft:smooth_basalt
fill 134 98 527 134 100 527 minecraft:blackstone
setblock 134 98 531 minecraft:smooth_basalt
setblock 134 98 546 minecraft:smooth_basalt
fill 134 98 547 134 99 547 minecraft:blackstone
setblock 134 98 551 minecraft:smooth_basalt
fill 135 98 511 135 101 511 minecraft:blackstone
setblock 135 98 515 minecraft:smooth_basalt
fill 135 98 516 135 101 516 minecraft:blackstone
setblock 135 98 520 minecraft:smooth_basalt
fill 135 98 521 135 100 521 minecraft:blackstone
setblock 135 98 525 minecraft:smooth_basalt
fill 135 98 526 135 101 526 minecraft:blackstone
setblock 135 98 530 minecraft:smooth_basalt
fill 135 98 531 135 101 531 minecraft:blackstone
setblock 135 98 545 minecraft:smooth_basalt
fill 135 98 546 135 100 546 minecraft:blackstone
setblock 135 98 550 minecraft:smooth_basalt
fill 135 98 551 135 101 551 minecraft:blackstone
setblock 95 99 514 minecraft:smooth_basalt
setblock 95 99 524 minecraft:smooth_basalt
setblock 95 99 525 minecraft:blackstone
setblock 95 99 529 minecraft:smooth_basalt
fill 95 99 530 95 100 530 minecraft:blackstone
setblock 95 99 544 minecraft:smooth_basalt
fill 95 99 545 95 101 545 minecraft:blackstone
setblock 95 99 549 minecraft:smooth_basalt
fill 95 99 550 97 99 551 minecraft:blackstone
setblock 96 99 548 minecraft:smooth_basalt
fill 96 99 549 99 99 549 minecraft:blackstone
setblock 98 99 511 minecraft:smooth_basalt
setblock 98 99 550 minecraft:blackstone
setblock 98 99 551 minecraft:smooth_basalt
fill 99 99 511 102 99 511 minecraft:blackstone
setblock 99 99 550 minecraft:smooth_basalt
fill 99 99 551 102 99 551 minecraft:blackstone
setblock 100 99 549 minecraft:smooth_basalt
fill 100 99 550 100 102 550 minecraft:blackstone
fill 101 99 549 104 99 549 minecraft:blackstone
setblock 103 99 511 minecraft:smooth_basalt
fill 103 99 548 105 99 548 minecraft:blackstone
setblock 103 99 551 minecraft:smooth_basalt
fill 104 99 511 104 102 511 minecraft:blackstone
setblock 104 99 550 minecraft:smooth_basalt
fill 104 99 551 104 102 551 minecraft:blackstone
fill 105 99 512 106 99 512 minecraft:blackstone
setblock 105 99 549 minecraft:smooth_basalt
fill 105 99 550 105 102 550 minecraft:blackstone
setblock 106 99 548 minecraft:smooth_basalt
fill 106 99 549 106 102 549 minecraft:blackstone
setblock 107 99 512 minecraft:smooth_basalt
fill 107 99 548 107 101 548 minecraft:blackstone
setblock 108 99 511 minecraft:smooth_basalt
fill 108 99 512 109 100 512 minecraft:blackstone
setblock 108 99 551 minecraft:smooth_basalt
fill 109 99 511 109 102 511 minecraft:blackstone
setblock 109 99 550 minecraft:smooth_basalt
fill 109 99 551 109 102 551 minecraft:blackstone
setblock 110 99 549 minecraft:smooth_basalt
fill 110 99 550 110 102 550 minecraft:blackstone
setblock 111 99 548 minecraft:smooth_basalt
fill 111 99 549 111 100 549 minecraft:blackstone
setblock 112 99 511 minecraft:blackstone
setblock 113 99 511 minecraft:smooth_basalt
setblock 113 99 551 minecraft:smooth_basalt
setblock 114 99 550 minecraft:smooth_basalt
fill 114 99 551 114 101 551 minecraft:blackstone
setblock 115 99 550 minecraft:blackstone
setblock 118 99 551 minecraft:smooth_basalt
fill 119 99 551 122 99 551 minecraft:blackstone
setblock 122 99 511 minecraft:blackstone
setblock 123 99 511 minecraft:smooth_basalt
setblock 123 99 550 minecraft:blackstone
setblock 123 99 551 minecraft:smooth_basalt
fill 124 99 511 124 101 512 minecraft:blackstone
setblock 124 99 550 minecraft:smooth_basalt
fill 124 99 551 127 99 551 minecraft:blackstone
fill 125 99 550 128 99 550 minecraft:blackstone
setblock 127 99 512 minecraft:smooth_basalt
fill 127 99 513 127 102 513 minecraft:blackstone
fill 127 99 549 129 99 549 minecraft:blackstone
setblock 128 99 511 minecraft:smooth_basalt
fill 128 99 512 128 102 512 minecraft:blackstone
setblock 128 99 551 minecraft:smooth_basalt
fill 129 99 511 129 102 511 minecraft:blackstone
setblock 129 99 550 minecraft:smooth_basalt
fill 129 99 551 129 102 551 minecraft:blackstone
setblock 130 99 549 minecraft:smooth_basalt
fill 130 99 550 130 102 550 minecraft:blackstone
setblock 131 99 513 minecraft:smooth_basalt
setblock 131 99 549 minecraft:blackstone
setblock 132 99 512 minecraft:smooth_basalt
setblock 132 99 513 minecraft:blackstone
setblock 133 99 511 minecraft:smooth_basalt
fill 133 99 512 133 102 512 minecraft:blackstone
setblock 133 99 526 minecraft:smooth_basalt
setblock 133 99 527 minecraft:blackstone
setblock 133 99 529 minecraft:blackstone
setblock 133 99 551 minecraft:smooth_basalt
fill 134 99 511 134 102 511 minecraft:blackstone
setblock 134 99 515 minecraft:smooth_basalt
setblock 134 99 520 minecraft:smooth_basalt
setblock 134 99 521 minecraft:blackstone
setblock 134 99 525 minecraft:smooth_basalt
fill 134 99 526 134 100 526 minecraft:blackstone
setblock 134 99 530 minecraft:smooth_basalt
setblock 134 99 550 minecraft:smooth_basalt
fill 134 99 551 134 102 551 minecraft:blackstone
setblock 135 99 514 minecraft:smooth_basalt
fill 135 99 515 135 102 515 minecraft:blackstone
setblock 135 99 519 minecraft:smooth_basalt
fill 135 99 520 135 100 520 minecraft:blackstone
setblock 135 99 524 minecraft:smooth_basalt
fill 135 99 525 135 101 525 minecraft:blackstone
setblock 135 99 529 minecraft:smooth_basalt
fill 135 99 530 135 101 530 minecraft:blackstone
setblock 135 99 545 minecraft:blackstone
setblock 135 99 549 minecraft:smooth_basalt
fill 135 99 550 135 102 550 minecraft:blackstone
setblock 95 100 513 minecraft:smooth_basalt
setblock 95 100 514 minecraft:blackstone
setblock 95 100 528 minecraft:smooth_basalt
setblock 95 100 529 minecraft:blackstone
setblock 95 100 544 minecraft:blackstone
setblock 95 100 548 minecraft:smooth_basalt
fill 95 100 549 96 100 551 minecraft:blackstone
setblock 96 100 547 minecraft:smooth_basalt
fill 96 100 548 96 101 548 minecraft:blackstone
setblock 97 100 511 minecraft:smooth_basalt
setblock 97 100 550 minecraft:blackstone
setblock 97 100 551 minecraft:smooth_basalt
fill 98 100 511 101 100 511 minecraft:blackstone
setblock 98 100 550 minecraft:smooth_basalt
fill 98 100 551 101 100 551 minecraft:blackstone
setblock 99 100 549 minecraft:smooth_basalt
fill 99 100 550 99 103 550 minecraft:blackstone
fill 100 100 549 103 100 549 minecraft:blackstone
setblock 102 100 511 minecraft:smooth_basalt
setblock 102 100 551 minecraft:smooth_basalt
fill 103 100 511 103 103 511 minecraft:blackstone
fill 103 100 548 104 100 548 minecraft:blackstone
setblock 103 100 550 minecraft:smooth_basalt
fill 103 100 551 103 103 551 minecraft:blackstone
fill 104 100 512 105 100 512 minecraft:blackstone
setblock 104 100 549 minecraft:smooth_basalt
fill 104 100 550 104 103 550 minecraft:blackstone
setblock 105 100 548 minecraft:smooth_basalt
fill 105 100 549 105 103 549 minecraft:blackstone
setblock 106 100 512 minecraft:smooth_basalt
fill 106 100 548 106 101 548 minecraft:blackstone
setblock 107 100 511 minecraft:smooth_basalt
fill 107 100 512 107 103 512 minecraft:blackstone
setblock 107 100 551 minecraft:smooth_basalt
fill 108 100 511 108 103 511 minecraft:blackstone
setblock 108 100 550 minecraft:smooth_basalt
fill 108 100 551 108 103 551 minecraft:blackstone
setblock 109 100 549 minecraft:smooth_basalt
fill 109 100 550 109 103 550 minecraft:blackstone
fill 110 100 549 110 101 549 minecraft:blackstone
setblock 112 100 511 minecraft:smooth_basalt
setblock 112 100 551 minecraft:smooth_basalt
setblock 113 100 511 minecraft:blackstone
setblock 113 100 550 minecraft:smooth_basalt
fill 113 100 551 113 102 551 minecraft:blackstone
setblock 114 100 550 minecraft:blackstone
setblock 117 100 551 minecraft:smooth_basalt
fill 120 100 551 121 100 551 minecraft:blackstone
setblock 121 100 511 minecraft:blackstone
setblock 122 100 511 minecraft:smooth_basalt
setblock 122 100 551 minecraft:smooth_basalt
fill 123 100 511 123 102 512 minecraft:blackstone
setblock 123 100 550 minecraft:smooth_basalt
fill 123 100 551 126 100 551 minecraft:blackstone
fill 124 100 550 127 100 550 minecraft:blackstone
setblock 126 100 511 minecraft:blackstone
setblock 126 100 512 minecraft:smooth_basalt
fill 126 100 513 126 103 513 minecraft:blackstone
setblock 127 100 511 minecraft:smooth_basalt
fill 127 100 512 127 103 512 minecraft:blackstone
fill 127 100 549 128 100 549 minecraft:blackstone
setblock 127 100 551 minecraft:smooth_basalt
fill 128 100 511 128 103 511 minecraft:blackstone
setblock 128 100 550 minecraft:smooth_basalt
fill 128 100 551 128 103 551 minecraft:blackstone
setblock 129 100 549 minecraft:smooth_basalt
fill 129 100 550 129 103 550 minecraft:blackstone
setblock 130 100 512 minecraft:blackstone
setblock 130 100 513 minecraft:smooth_basalt
setblock 130 100 549 minecraft:blackstone
setblock 131 100 512 minecraft:smooth_basalt
fill 131 100 513 131 101 513 minecraft:blackstone
setblock 132 100 511 minecraft:smooth_basalt
fill 132 100 512 132 103 512 minecraft:blackstone
setblock 132 100 551 minecraft:smooth_basalt
fill 133 100 511 133 103 511 minecraft:blackstone
setblock 133 100 550 minecraft:smooth_basalt
fill 133 100 551 133 103 551 minecraft:blackstone
setblock 134 100 514 minecraft:smooth_basalt
setblock 134 100 524 minecraft:smooth_basalt
setblock 134 100 525 minecraft:blackstone
setblock 134 100 529 minecraft:smooth_basalt
setblock 134 100 530 minecraft:blackstone
setblock 134 100 549 minecraft:smooth_basalt
fill 134 100 550 134 101 550 minecraft:blackstone
setblock 135 100 513 minecraft:smooth_basalt
fill 135 100 514 135 103 514 minecraft:blackstone
setblock 135 100 518 minecraft:smooth_basalt
setblock 135 100 519 minecraft:blackstone
setblock 135 100 523 minecraft:smooth_basalt
fill 135 100 524 135 101 524 minecraft:blackstone
setblock 135 100 528 minecraft:smooth_basalt
fill 135 100 529 135 101 529 minecraft:blackstone
setblock 135 100 548 minecraft:smooth_basalt
fill 135 100 549 135 103 549 minecraft:blackstone
setblock 95 101 512 minecraft:smooth_basalt
fill 95 101 513 95 102 513 minecraft:blackstone
setblock 95 101 547 minecraft:smooth_basalt
fill 95 101 548 95 101 551 minecraft:blackstone
setblock 96 101 511 minecraft:smooth_basalt
fill 96 101 549 96 101 550 minecraft:blackstone
setblock 96 101 551 minecraft:smooth_basalt
fill 97 101 511 100 101 511 minecraft:blackstone
setblock 97 101 513 minecraft:light[level=12]
setblock 97 101 521 minecraft:light[level=12]
setblock 97 101 529 minecraft:light[level=12]
setblock 97 101 537 minecraft:light[level=12]
setblock 97 101 545 minecraft:light[level=12]
setblock 97 101 550 minecraft:smooth_basalt
fill 97 101 551 100 101 551 minecraft:blackstone
fill 98 101 550 98 104 550 minecraft:blackstone
fill 100 101 549 102 101 549 minecraft:blackstone
setblock 101 101 511 minecraft:smooth_basalt
setblock 101 101 551 minecraft:smooth_basalt
fill 102 101 511 102 104 511 minecraft:blackstone
setblock 102 101 550 minecraft:smooth_basalt
fill 102 101 551 102 104 551 minecraft:blackstone
setblock 103 101 549 minecraft:smooth_basalt
fill 103 101 550 103 104 550 minecraft:blackstone
setblock 104 101 512 minecraft:blackstone
setblock 104 101 548 minecraft:smooth_basalt
fill 104 101 549 104 104 549 minecraft:blackstone
setblock 105 101 512 minecraft:smooth_basalt
setblock 105 101 513 minecraft:light[level=12]
setblock 105 101 521 minecraft:light[level=12]
setblock 105 101 529 minecraft:light[level=12]
setblock 105 101 537 minecraft:light[level=12]
setblock 105 101 545 minecraft:light[level=12]
setblock 105 101 548 minecraft:blackstone
setblock 106 101 511 minecraft:smooth_basalt
fill 106 101 512 106 104 512 minecraft:blackstone
setblock 106 101 551 minecraft:smooth_basalt
fill 107 101 511 107 104 511 minecraft:blackstone
setblock 107 101 550 minecraft:smooth_basalt
fill 107 101 551 107 104 551 minecraft:blackstone
setblock 108 101 512 minecraft:blackstone
setblock 108 101 549 minecraft:smooth_basalt
fill 108 101 550 108 104 550 minecraft:blackstone
fill 109 101 549 109 102 549 minecraft:blackstone
setblock 111 101 511 minecraft:smooth_basalt
setblock 111 101 551 minecraft:smooth_basalt
setblock 112 101 511 minecraft:blackstone
setblock 112 101 550 minecraft:smooth_basalt
fill 112 101 551 112 103 551 minecraft:blackstone
setblock 113 101 513 minecraft:light[level=12]
setblock 113 101 521 minecraft:light[level=12]
setblock 113 101 529 minecraft:light[level=12]
setblock 113 101 537 minecraft:light[level=12]
setblock 113 101 545 minecraft:light[level=12]
setblock 120 101 511 minecraft:blackstone
setblock 120 101 551 minecraft:blackstone
setblock 121 101 511 minecraft:smooth_basalt
setblock 121 101 513 minecraft:light[level=12]
setblock 121 101 521 minecraft:light[level=12]
setblock 121 101 529 minecraft:light[level=12]
setblock 121 101 537 minecraft:light[level=12]
setblock 121 101 545 minecraft:light[level=12]
setblock 121 101 551 minecraft:smooth_basalt
fill 122 101 511 122 104 511 minecraft:blackstone
fill 122 101 551 125 101 551 minecraft:blackstone
fill 123 101 550 126 101 550 minecraft:blackstone
setblock 125 101 511 minecraft:blackstone
setblock 125 101 512 minecraft:smooth_basalt
setblock 126 101 511 minecraft:smooth_basalt
fill 126 101 512 126 104 512 minecraft:blackstone
setblock 126 101 551 minecraft:smooth_basalt
fill 127 101 511 127 104 511 minecraft:blackstone
setblock 127 101 550 minecraft:smooth_basalt
fill 127 101 551 127 104 551 minecraft:blackstone
setblock 128 101 513 minecraft:blackstone
fill 128 101 550 128 104 550 minecraft:blackstone
setblock 129 101 513 minecraft:smooth_basalt
setblock 129 101 521 minecraft:light[level=12]
setblock 129 101 529 minecraft:light[level=12]
setblock 129 101 537 minecraft:light[level=12]
setblock 129 101 545 minecraft:light[level=12]
setblock 130 101 512 minecraft:smooth_basalt
fill 130 101 513 130 104 513 minecraft:blackstone
setblock 131 101 511 minecraft:smooth_basalt
fill 131 101 512 131 104 512 minecraft:blackstone
setblock 131 101 551 minecraft:smooth_basalt
fill 132 101 511 132 104 511 minecraft:blackstone
setblock 132 101 550 minecraft:smooth_basalt
fill 132 101 551 132 104 551 minecraft:blackstone
setblock 133 101 550 minecraft:blackstone
setblock 134 101 513 minecraft:smooth_basalt
setblock 135 101 512 minecraft:smooth_basalt
fill 135 101 513 135 104 513 minecraft:blackstone
setblock 135 101 527 minecraft:smooth_basalt
setblock 135 101 528 minecraft:blackstone
setblock 135 101 547 minecraft:smooth_basalt
fill 135 101 548 135 102 548 minecraft:blackstone
setblock 95 102 511 minecraft:smooth_basalt
fill 95 102 512 95 105 512 minecraft:blackstone
setblock 95 102 546 minecraft:smooth_basalt
fill 95 102 547 95 102 550 minecraft:blackstone
setblock 95 102 551 minecraft:smooth_basalt
fill 96 102 511 99 102 511 minecraft:blackstone
setblock 96 102 549 minecraft:blackstone
setblock 96 102 550 minecraft:smooth_basalt
fill 96 102 551 99 102 551 minecraft:blackstone
fill 97 102 550 97 103 550 minecraft:blackstone
setblock 100 102 511 minecraft:smooth_basalt
setblock 100 102 551 minecraft:smooth_basalt
fill 101 102 511 101 105 511 minecraft:blackstone
setblock 101 102 549 minecraft:blackstone
setblock 101 102 550 minecraft:smooth_basalt
fill 101 102 551 101 105 551 minecraft:blackstone
setblock 102 102 549 minecraft:smooth_basalt
fill 102 102 550 102 105 550 minecraft:blackstone
setblock 103 102 512 minecraft:blackstone
fill 103 102 549 103 104 549 minecraft:blackstone
setblock 104 102 512 minecraft:smooth_basalt
setblock 105 102 511 minecraft:smooth_basalt
fill 105 102 512 105 105 512 minecraft:blackstone
setblock 105 102 551 minecraft:smooth_basalt
fill 106 102 511 106 105 511 minecraft:blackstone
setblock 106 102 550 minecraft:smooth_basalt
fill 106 102 551 106 105 551 minecraft:blackstone
setblock 107 102 549 minecraft:smooth_basalt
fill 107 102 550 107 105 550 minecraft:blackstone
setblock 108 102 549 minecraft:blackstone
setblock 110 102 511 minecraft:smooth_basalt
setblock 110 102 551 minecraft:smooth_basalt
fill 111 102 511 111 103 511 minecraft:blackstone
setblock 111 102 550 minecraft:smooth_basalt
fill 111 102 551 111 104 551 minecraft:blackstone
setblock 120 102 511 minecraft:smooth_basalt
fill 121 102 511 121 105 511 minecraft:blackstone
fill 121 102 551 124 102 551 minecraft:blackstone
fill 122 102 512 122 103 512 minecraft:blackstone
setblock 124 102 511 minecraft:blackstone
setblock 124 102 512 minecraft:smooth_basalt
fill 124 102 550 125 102 550 minecraft:blackstone
setblock 125 102 511 minecraft:smooth_basalt
fill 125 102 512 125 104 513 minecraft:blackstone
setblock 125 102 551 minecraft:smooth_basalt
fill 126 102 511 126 105 511 minecraft:blackstone
setblock 126 102 550 minecraft:smooth_basalt
fill 126 102 551 126 105 551 minecraft:blackstone
fill 127 102 550 127 104 550 minecraft:blackstone
setblock 128 102 513 minecraft:smooth_basalt
setblock 129 102 512 minecraft:smooth_basalt
fill 129 102 513 129 105 513 minecraft:blackstone
setblock 130 102 511 minecraft:smooth_basalt
fill 130 102 512 130 105 512 minecraft:blackstone
setblock 130 102 551 minecraft:smooth_basalt
fill 131 102 511 131 105 511 minecraft:blackstone
setblock 131 102 550 minecraft:smooth_basalt
fill 131 102 551 131 105 551 minecraft:blackstone
setblock 132 102 550 minecraft:blackstone
setblock 134 102 512 minecraft:smooth_basalt
setblock 134 102 513 minecraft:blackstone
setblock 135 102 511 minecraft:smooth_basalt
fill 135 102 512 135 105 512 minecraft:blackstone
setblock 135 102 551 minecraft:smooth_basalt
fill 95 103 511 98 103 511 minecraft:blackstone
fill 95 103 547 95 103 549 minecraft:blackstone
setblock 95 103 550 minecraft:smooth_basalt
fill 95 103 551 98 103 551 minecraft:blackstone
setblock 96 103 550 minecraft:blackstone
setblock 99 103 511 minecraft:smooth_basalt
setblock 99 103 551 minecraft:smooth_basalt
fill 100 103 511 100 106 511 minecraft:blackstone
setblock 100 103 550 minecraft:smooth_basalt
fill 100 103 551 100 106 551 minecraft:blackstone
fill 101 103 550 101 106 550 minecraft:blackstone
setblock 102 103 549 minecraft:blackstone
setblock 103 103 512 minecraft:smooth_basalt
setblock 104 103 511 minecraft:smooth_basalt
fill 104 103 512 104 106 512 minecraft:blackstone
setblock 104 103 551 minecraft:smooth_basalt
fill 105 103 511 105 106 511 minecraft:blackstone
setblock 105 103 550 minecraft:smooth_basalt
fill 105 103 551 105 106 551 minecraft:blackstone
setblock 106 103 549 minecraft:smooth_basalt
fill 106 103 550 106 106 550 minecraft:blackstone
setblock 107 103 549 minecraft:blackstone
setblock 109 103 511 minecraft:smooth_basalt
setblock 109 103 551 minecraft:smooth_basalt
fill 110 103 511 110 104 511 minecraft:blackstone
setblock 110 103 550 minecraft:smooth_basalt
fill 110 103 551 110 105 551 minecraft:blackstone
setblock 119 103 511 minecraft:smooth_basalt
fill 120 103 511 120 106 511 minecraft:blackstone
fill 121 103 551 123 103 551 minecraft:blackstone
setblock 123 103 511 minecraft:blackstone
setblock 123 103 512 minecraft:smooth_basalt
setblock 124 103 511 minecraft:smooth_basalt
fill 124 103 512 124 105 513 minecraft:blackstone
setblock 124 103 550 minecraft:blackstone
setblock 124 103 551 minecraft:smooth_basalt
fill 125 103 511 125 106 511 minecraft:blackstone
setblock 125 103 550 minecraft:smooth_basalt
fill 125 103 551 125 106 551 minecraft:blackstone
fill 126 103 550 126 104 550 minecraft:blackstone
setblock 127 103 513 minecraft:smooth_basalt
setblock 128 103 512 minecraft:smooth_basalt
fill 128 103 513 128 106 513 minecraft:blackstone
setblock 129 103 511 minecraft:smooth_basalt
fill 129 103 512 129 106 512 minecraft:blackstone
setblock 129 103 551 minecraft:smooth_basalt
fill 130 103 511 130 106 511 minecraft:blackstone
setblock 130 103 550 minecraft:smooth_basalt
fill 130 103 551 130 106 551 minecraft:blackstone
setblock 133 103 512 minecraft:smooth_basalt
setblock 134 103 511 minecraft:smooth_basalt
fill 134 103 512 134 106 512 minecraft:blackstone
setblock 134 103 551 minecraft:smooth_basalt
fill 135 103 511 135 106 511 minecraft:blackstone
setblock 135 103 515 minecraft:smooth_basalt
setblock 135 103 550 minecraft:smooth_basalt
fill 135 103 551 135 106 551 minecraft:blackstone
fill 95 104 511 97 104 511 minecraft:blackstone
setblock 95 104 548 minecraft:blackstone
setblock 95 104 549 minecraft:smooth_basalt
fill 95 104 550 95 106 551 minecraft:blackstone
fill 96 104 551 97 104 551 minecraft:blackstone
setblock 98 104 511 minecraft:smooth_basalt
setblock 98 104 551 minecraft:smooth_basalt
fill 99 104 511 99 107 511 minecraft:blackstone
setblock 99 104 550 minecraft:smooth_basalt
fill 99 104 551 99 107 551 minecraft:blackstone
fill 100 104 550 100 107 550 minecraft:blackstone
setblock 103 104 511 minecraft:smooth_basalt
fill 103 104 512 103 107 512 minecraft:blackstone
setblock 103 104 551 minecraft:smooth_basalt
fill 104 104 511 104 107 511 minecraft:blackstone
setblock 104 104 550 minecraft:smooth_basalt
fill 104 104 551 104 107 551 minecraft:blackstone
setblock 105 104 549 minecraft:smooth_basalt
fill 105 104 550 105 107 550 minecraft:blackstone
setblock 108 104 511 minecraft:smooth_basalt
setblock 108 104 551 minecraft:smooth_basalt
fill 109 104 511 109 107 511 minecraft:blackstone
setblock 109 104 550 minecraft:smooth_basalt
fill 109 104 551 109 106 551 minecraft:blackstone
fill 119 104 511 119 107 511 minecraft:blackstone
setblock 121 104 512 minecraft:blackstone
fill 121 104 551 122 104 551 minecraft:blackstone
setblock 122 104 512 minecraft:smooth_basalt
setblock 123 104 511 minecraft:smooth_basalt
fill 123 104 512 123 107 512 minecraft:blackstone
setblock 123 104 551 minecraft:smooth_basalt
fill 124 104 511 124 107 511 minecraft:blackstone
fill 124 104 551 124 107 551 minecraft:blackstone
setblock 125 104 550 minecraft:blackstone
setblock 126 104 513 minecraft:smooth_basalt
setblock 127 104 512 minecraft:smooth_basalt
fill 127 104 513 127 107 513 minecraft:blackstone
setblock 128 104 511 minecraft:smooth_basalt
fill 128 104 512 128 107 512 minecraft:blackstone
setblock 128 104 551 minecraft:smooth_basalt
fill 129 104 511 129 107 511 minecraft:blackstone
fill 129 104 551 129 107 551 minecraft:blackstone
setblock 132 104 512 minecraft:smooth_basalt
setblock 133 104 511 minecraft:smooth_basalt
fill 133 104 512 133 107 512 minecraft:blackstone
setblock 133 104 551 minecraft:smooth_basalt
fill 134 104 511 134 107 511 minecraft:blackstone
fill 134 104 551 134 107 551 minecraft:blackstone
setblock 135 104 514 minecraft:smooth_basalt
fill 135 104 515 135 107 515 minecraft:blackstone
setblock 135 104 550 minecraft:blackstone
fill 95 105 511 96 105 511 minecraft:blackstone
fill 95 105 549 95 108 549 minecraft:blackstone
setblock 96 105 551 minecraft:blackstone
setblock 97 105 511 minecraft:smooth_basalt
setblock 97 105 551 minecraft:smooth_basalt
fill 98 105 511 98 108 511 minecraft:blackstone
setblock 98 105 550 minecraft:smooth_basalt
fill 98 105 551 98 108 551 minecraft:blackstone
fill 99 105 550 99 108 550 minecraft:blackstone
setblock 102 105 511 minecraft:smooth_basalt
fill 102 105 512 102 108 512 minecraft:blackstone
setblock 102 105 551 minecraft:smooth_basalt
fill 103 105 511 103 108 511 minecraft:blackstone
setblock 103 105 550 minecraft:smooth_basalt
fill 103 105 551 103 108 551 minecraft:blackstone
fill 104 105 550 104 108 550 minecraft:blackstone
setblock 106 105 512 minecraft:smooth_basalt
setblock 107 105 511 minecraft:smooth_basalt
setblock 107 105 551 minecraft:smooth_basalt
fill 108 105 511 108 108 511 minecraft:blackstone
fill 108 105 551 108 107 551 minecraft:blackstone
fill 118 105 511 118 108 511 minecraft:blackstone
setblock 121 105 512 minecraft:smooth_basalt
setblock 121 105 551 minecraft:blackstone
setblock 122 105 511 minecraft:smooth_basalt
fill 122 105 512 122 108 512 minecraft:blackstone
setblock 122 105 551 minecraft:smooth_basalt
fill 123 105 511 123 108 511 minecraft:blackstone
fill 123 105 513 123 106 513 minecraft:blackstone
fill 123 105 551 123 108 551 minecraft:blackstone
setblock 125 105 512 minecraft:blackstone
setblock 125 105 513 minecraft:smooth_basalt
setblock 126 105 512 minecraft:smooth_basalt
fill 126 105 513 126 108 513 minecraft:blackstone
setblock 127 105 511 minecraft:smooth_basalt
fill 127 105 512 127 108 512 minecraft:blackstone
setblock 127 105 551 minecraft:smooth_basalt
fill 128 105 511 128 108 511 minecraft:blackstone
fill 128 105 551 128 108 551 minecraft:blackstone
setblock 131 105 512 minecraft:smooth_basalt
setblock 132 105 511 minecraft:smooth_basalt
fill 132 105 512 132 108 512 minecraft:blackstone
setblock 132 105 551 minecraft:smooth_basalt
fill 133 105 511 133 108 511 minecraft:blackstone
fill 133 105 551 133 108 551 minecraft:blackstone
setblock 135 105 513 minecraft:smooth_basalt
fill 135 105 514 135 108 514 minecraft:blackstone
setblock 95 106 511 minecraft:blackstone
setblock 95 106 512 minecraft:smooth_basalt
setblock 96 106 511 minecraft:smooth_basalt
setblock 96 106 551 minecraft:smooth_basalt
fill 97 106 511 97 109 511 minecraft:blackstone
fill 97 106 551 97 109 551 minecraft:blackstone
fill 98 106 512 100 106 514 minecraft:smooth_basalt
setblock 101 106 511 minecraft:smooth_basalt
fill 101 106 512 101 109 512 minecraft:blackstone
fill 101 106 513 101 110 514 minecraft:smooth_basalt
setblock 101 106 551 minecraft:smooth_basalt
fill 102 106 511 102 109 511 minecraft:blackstone
schedule function dropper:buildpart/122_5 1t
