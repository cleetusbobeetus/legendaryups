fill 283 276 235 287 276 236 minecraft:blackstone
fill 283 276 238 288 277 238 minecraft:blackstone
setblock 283 276 239 minecraft:tuff
fill 283 276 240 283 276 241 minecraft:blackstone
fill 283 276 243 284 279 243 minecraft:blackstone
fill 283 276 244 289 276 244 minecraft:basalt
fill 283 276 246 286 276 248 minecraft:blackstone
fill 283 276 249 287 276 249 minecraft:basalt
fill 283 276 250 288 276 251 minecraft:blackstone
setblock 283 276 252 minecraft:tuff
fill 283 276 253 289 277 253 minecraft:blackstone
setblock 283 276 254 minecraft:basalt
fill 283 276 255 284 276 256 minecraft:blackstone
fill 283 276 258 285 277 258 minecraft:blackstone
fill 283 276 259 292 276 259 minecraft:basalt
fill 283 276 262 287 276 263 minecraft:blackstone
fill 283 276 264 288 276 264 minecraft:basalt
setblock 283 276 265 minecraft:tuff
fill 283 276 266 283 276 268 minecraft:blackstone
fill 283 276 269 284 276 269 minecraft:basalt
fill 284 276 228 284 283 228 minecraft:blackstone
fill 284 276 239 292 276 239 minecraft:basalt
fill 284 276 240 289 276 240 minecraft:blackstone
setblock 284 276 241 minecraft:tuff
fill 284 276 245 285 276 245 minecraft:blackstone
setblock 284 276 254 minecraft:tuff
fill 284 276 261 293 276 261 minecraft:blackstone
fill 284 276 265 289 276 266 minecraft:blackstone
setblock 284 276 267 minecraft:tuff
fill 284 276 268 290 277 268 minecraft:blackstone
setblock 285 276 230 minecraft:tuff
fill 285 276 231 285 276 233 minecraft:blackstone
fill 285 276 241 291 276 241 minecraft:blackstone
setblock 285 276 243 minecraft:tuff
fill 285 276 254 291 276 254 minecraft:basalt
fill 285 276 255 290 276 255 minecraft:blackstone
setblock 285 276 256 minecraft:tuff
fill 285 276 260 286 276 260 minecraft:blackstone
setblock 285 276 269 minecraft:tuff
fill 286 276 228 286 283 228 minecraft:blackstone
fill 286 276 230 291 276 231 minecraft:blackstone
setblock 286 276 232 minecraft:tuff
fill 286 276 233 292 277 233 minecraft:blackstone
fill 286 276 242 290 276 243 minecraft:blackstone
setblock 286 276 245 minecraft:tuff
fill 286 276 256 293 276 256 minecraft:blackstone
setblock 286 276 258 minecraft:tuff
fill 286 276 269 297 276 269 minecraft:basalt
setblock 287 276 234 minecraft:tuff
fill 287 276 245 289 276 246 minecraft:blackstone
setblock 287 276 247 minecraft:tuff
fill 287 276 248 289 276 248 minecraft:blackstone
fill 287 276 257 291 276 258 minecraft:blackstone
setblock 287 276 260 minecraft:tuff
fill 288 276 234 299 276 234 minecraft:basalt
fill 288 276 235 293 276 235 minecraft:blackstone
setblock 288 276 236 minecraft:tuff
fill 288 276 247 289 276 247 minecraft:blackstone
setblock 288 276 249 minecraft:tuff
fill 288 276 260 299 276 260 minecraft:blackstone
setblock 288 276 262 minecraft:tuff
fill 288 276 263 294 277 263 minecraft:blackstone
fill 289 276 236 296 276 236 minecraft:blackstone
setblock 289 276 238 minecraft:tuff
setblock 289 276 249 minecraft:basalt
setblock 289 276 250 minecraft:blackstone
setblock 289 276 251 minecraft:tuff
setblock 289 276 264 minecraft:tuff
fill 290 276 237 293 276 238 minecraft:blackstone
setblock 290 276 240 minecraft:tuff
fill 290 276 244 290 277 244 minecraft:shroomlight
fill 290 276 245 290 276 249 minecraft:magma_block
fill 290 276 250 290 277 250 minecraft:shroomlight
setblock 290 276 251 minecraft:blackstone
setblock 290 276 253 minecraft:tuff
fill 290 276 264 301 276 264 minecraft:basalt
fill 290 276 265 295 276 265 minecraft:blackstone
setblock 290 276 266 minecraft:tuff
setblock 291 276 229 minecraft:tuff
setblock 291 276 240 minecraft:blackstone
fill 291 276 242 291 276 243 minecraft:magma_block
fill 291 276 251 291 276 252 minecraft:magma_block
setblock 291 276 253 minecraft:blackstone
setblock 291 276 255 minecraft:tuff
fill 291 276 266 302 276 266 minecraft:blackstone
setblock 291 276 268 minecraft:tuff
fill 292 276 229 303 276 229 minecraft:basalt
fill 292 276 230 297 276 230 minecraft:blackstone
setblock 292 276 231 minecraft:tuff
fill 292 276 240 292 276 241 minecraft:magma_block
fill 292 276 253 292 276 254 minecraft:magma_block
setblock 292 276 255 minecraft:blackstone
setblock 292 276 257 minecraft:tuff
fill 292 276 258 296 276 258 minecraft:blackstone
fill 292 276 267 296 276 268 minecraft:blackstone
fill 293 276 231 304 276 231 minecraft:blackstone
setblock 293 276 233 minecraft:tuff
setblock 293 276 239 minecraft:magma_block
setblock 293 276 255 minecraft:magma_block
fill 293 276 257 294 276 257 minecraft:blackstone
setblock 293 276 259 minecraft:tuff
fill 294 276 232 298 276 233 minecraft:blackstone
setblock 294 276 235 minecraft:tuff
setblock 294 276 237 minecraft:blackstone
setblock 294 276 238 minecraft:magma_block
setblock 294 276 256 minecraft:magma_block
fill 294 276 259 298 276 259 minecraft:basalt
setblock 294 276 261 minecraft:tuff
fill 295 276 235 298 276 235 minecraft:blackstone
fill 295 276 237 296 276 237 minecraft:magma_block
fill 295 276 257 296 276 257 minecraft:magma_block
fill 295 276 261 306 276 261 minecraft:blackstone
setblock 295 276 263 minecraft:tuff
fill 296 276 262 300 276 263 minecraft:blackstone
setblock 296 276 265 minecraft:tuff
setblock 297 276 236 minecraft:shroomlight
setblock 297 276 258 minecraft:shroomlight
fill 297 276 265 308 276 265 minecraft:blackstone
setblock 297 276 267 minecraft:tuff
fill 297 276 268 303 277 268 minecraft:blackstone
setblock 298 276 230 minecraft:tuff
setblock 298 276 236 minecraft:magma_block
setblock 298 276 258 minecraft:magma_block
setblock 298 276 269 minecraft:tuff
fill 299 276 230 310 276 230 minecraft:blackstone
setblock 299 276 232 minecraft:tuff
fill 299 276 233 305 277 233 minecraft:blackstone
fill 299 276 235 301 276 235 minecraft:magma_block
fill 299 276 259 301 276 259 minecraft:magma_block
fill 299 276 269 310 276 269 minecraft:basalt
setblock 300 276 234 minecraft:tuff
setblock 300 276 260 minecraft:tuff
fill 301 276 234 312 276 234 minecraft:basalt
fill 301 276 260 312 276 260 minecraft:blackstone
setblock 301 276 262 minecraft:tuff
fill 301 276 263 307 277 263 minecraft:blackstone
setblock 302 276 235 minecraft:shroomlight
setblock 302 276 259 minecraft:shroomlight
setblock 302 276 264 minecraft:tuff
fill 303 276 235 305 276 235 minecraft:magma_block
fill 303 276 259 305 276 259 minecraft:magma_block
fill 303 276 264 314 276 264 minecraft:basalt
setblock 303 276 266 minecraft:tuff
fill 304 276 228 304 283 228 minecraft:blackstone
setblock 304 276 229 minecraft:tuff
fill 304 276 266 315 276 266 minecraft:blackstone
setblock 304 276 268 minecraft:tuff
fill 305 276 229 316 276 229 minecraft:basalt
setblock 305 276 231 minecraft:tuff
fill 305 276 267 309 276 268 minecraft:blackstone
fill 306 276 231 317 276 231 minecraft:blackstone
setblock 306 276 233 minecraft:tuff
setblock 306 276 235 minecraft:blackstone
setblock 306 276 236 minecraft:magma_block
setblock 306 276 258 minecraft:magma_block
setblock 306 276 259 minecraft:tuff
fill 307 276 232 311 276 233 minecraft:blackstone
setblock 307 276 235 minecraft:tuff
setblock 307 276 236 minecraft:shroomlight
setblock 307 276 258 minecraft:shroomlight
fill 307 276 259 318 276 259 minecraft:basalt
setblock 307 276 261 minecraft:tuff
fill 308 276 235 313 276 236 minecraft:blackstone
fill 308 276 237 309 276 237 minecraft:magma_block
fill 308 276 257 309 276 257 minecraft:magma_block
fill 308 276 258 311 276 258 minecraft:blackstone
fill 308 276 261 319 276 261 minecraft:blackstone
setblock 308 276 263 minecraft:tuff
fill 309 276 262 313 276 263 minecraft:blackstone
setblock 309 276 265 minecraft:tuff
fill 310 276 237 316 276 237 minecraft:blackstone
setblock 310 276 238 minecraft:magma_block
setblock 310 276 256 minecraft:magma_block
fill 310 276 257 317 276 257 minecraft:blackstone
fill 310 276 265 317 276 265 minecraft:blackstone
setblock 310 276 267 minecraft:tuff
fill 310 276 268 316 277 268 minecraft:blackstone
setblock 311 276 230 minecraft:tuff
fill 311 276 238 314 276 238 minecraft:blackstone
setblock 311 276 239 minecraft:magma_block
setblock 311 276 255 minecraft:magma_block
setblock 311 276 256 minecraft:tuff
setblock 311 276 269 minecraft:tuff
fill 312 276 230 319 276 230 minecraft:blackstone
setblock 312 276 232 minecraft:tuff
fill 312 276 233 318 277 233 minecraft:blackstone
fill 312 276 239 321 276 239 minecraft:basalt
fill 312 276 240 312 276 241 minecraft:magma_block
fill 312 276 253 312 276 254 minecraft:magma_block
fill 312 276 255 316 276 256 minecraft:blackstone
setblock 312 276 258 minecraft:tuff
fill 312 276 269 323 276 269 minecraft:basalt
setblock 313 276 234 minecraft:tuff
fill 313 276 240 315 276 241 minecraft:blackstone
fill 313 276 242 313 276 243 minecraft:magma_block
fill 313 276 251 313 276 252 minecraft:magma_block
fill 313 276 253 315 276 253 minecraft:blackstone
fill 313 276 254 322 276 254 minecraft:basalt
fill 313 276 258 323 276 258 minecraft:blackstone
setblock 313 276 260 minecraft:tuff
fill 314 276 234 323 276 234 minecraft:basalt
fill 314 276 235 315 276 235 minecraft:blackstone
setblock 314 276 236 minecraft:tuff
fill 314 276 242 316 276 243 minecraft:blackstone
fill 314 276 244 314 277 244 minecraft:shroomlight
fill 314 276 245 314 276 249 minecraft:magma_block
fill 314 276 250 314 277 250 minecraft:shroomlight
fill 314 276 251 314 276 252 minecraft:blackstone
fill 314 276 260 321 276 260 minecraft:blackstone
setblock 314 276 262 minecraft:tuff
fill 314 276 263 320 277 263 minecraft:blackstone
fill 315 276 236 316 277 236 minecraft:blackstone
setblock 315 276 238 minecraft:tuff
fill 315 276 244 317 276 244 minecraft:basalt
fill 315 276 246 318 276 248 minecraft:blackstone
fill 315 276 249 323 276 249 minecraft:basalt
fill 315 276 250 316 276 250 minecraft:blackstone
setblock 315 276 251 minecraft:tuff
fill 315 276 252 321 277 252 minecraft:blackstone
setblock 315 276 264 minecraft:tuff
fill 316 276 238 323 276 238 minecraft:blackstone
setblock 316 276 240 minecraft:tuff
fill 316 276 241 322 277 241 minecraft:blackstone
setblock 316 276 253 minecraft:tuff
fill 316 276 264 323 276 264 minecraft:basalt
setblock 316 276 266 minecraft:tuff
setblock 317 276 229 minecraft:tuff
fill 317 276 240 319 276 240 minecraft:blackstone
setblock 317 276 242 minecraft:tuff
fill 317 276 243 323 277 243 minecraft:blackstone
fill 317 276 253 323 276 253 minecraft:blackstone
setblock 317 276 255 minecraft:tuff
fill 317 276 256 319 277 256 minecraft:blackstone
fill 317 276 266 318 277 266 minecraft:blackstone
setblock 317 276 268 minecraft:tuff
fill 318 276 229 323 276 229 minecraft:basalt
setblock 318 276 231 minecraft:tuff
fill 318 276 237 320 277 237 minecraft:blackstone
setblock 318 276 244 minecraft:tuff
fill 318 276 250 320 276 250 minecraft:blackstone
fill 318 276 255 320 276 255 minecraft:blackstone
setblock 318 276 257 minecraft:tuff
fill 318 276 267 318 278 268 minecraft:blackstone
fill 319 276 231 321 277 231 minecraft:blackstone
setblock 319 276 233 minecraft:tuff
setblock 319 276 235 minecraft:blackstone
fill 319 276 244 323 276 244 minecraft:basalt
setblock 319 276 246 minecraft:tuff
fill 319 276 247 319 278 248 minecraft:blackstone
fill 319 276 251 319 277 251 minecraft:blackstone
fill 319 276 257 323 276 257 minecraft:blackstone
setblock 319 276 259 minecraft:tuff
fill 319 276 268 323 276 268 minecraft:blackstone
fill 320 276 232 320 278 233 minecraft:blackstone
setblock 320 276 235 minecraft:tuff
fill 320 276 245 321 276 247 minecraft:blackstone
setblock 320 276 248 minecraft:tuff
fill 320 276 259 323 276 259 minecraft:basalt
setblock 320 276 261 minecraft:tuff
fill 320 276 267 322 277 267 minecraft:blackstone
fill 321 276 233 323 278 233 minecraft:blackstone
fill 321 276 235 322 276 235 minecraft:blackstone
setblock 321 276 237 minecraft:tuff
fill 321 276 248 323 278 248 minecraft:blackstone
setblock 321 276 250 minecraft:tuff
fill 321 276 261 322 277 261 minecraft:blackstone
setblock 321 276 263 minecraft:tuff
setblock 321 276 265 minecraft:blackstone
fill 322 276 236 322 277 237 minecraft:blackstone
setblock 322 276 239 minecraft:tuff
fill 322 276 245 323 276 245 minecraft:blackstone
fill 322 276 250 323 276 250 minecraft:blackstone
setblock 322 276 252 minecraft:tuff
fill 322 276 262 322 278 263 minecraft:blackstone
setblock 322 276 265 minecraft:tuff
fill 323 276 237 323 278 237 minecraft:blackstone
setblock 323 276 239 minecraft:basalt
setblock 323 276 241 minecraft:tuff
fill 323 276 246 323 277 246 minecraft:blackstone
fill 323 276 251 323 277 252 minecraft:blackstone
setblock 323 276 254 minecraft:tuff
fill 323 276 263 323 278 263 minecraft:blackstone
setblock 323 276 265 minecraft:blackstone
setblock 323 276 267 minecraft:tuff
setblock 282 277 249 minecraft:magma_block
setblock 283 277 229 minecraft:tuff
fill 283 277 230 289 277 230 minecraft:basalt
fill 283 277 231 283 277 234 minecraft:blackstone
fill 283 277 235 285 277 235 minecraft:basalt
fill 283 277 236 286 277 237 minecraft:blackstone
fill 283 277 239 287 278 239 minecraft:blackstone
fill 283 277 240 290 277 240 minecraft:basalt
fill 283 277 241 288 277 241 minecraft:blackstone
setblock 283 277 242 minecraft:tuff
fill 283 277 244 283 280 244 minecraft:blackstone
fill 283 277 245 288 277 245 minecraft:basalt
fill 283 277 246 284 277 249 minecraft:blackstone
fill 283 277 250 286 277 250 minecraft:basalt
fill 283 277 251 287 277 252 minecraft:blackstone
fill 283 277 254 288 278 254 minecraft:blackstone
setblock 283 277 255 minecraft:tuff
fill 283 277 256 283 277 257 minecraft:blackstone
fill 283 277 259 284 280 259 minecraft:blackstone
fill 283 277 260 291 277 260 minecraft:basalt
fill 283 277 262 286 277 264 minecraft:blackstone
fill 283 277 265 287 277 265 minecraft:basalt
fill 283 277 266 288 277 267 minecraft:blackstone
setblock 283 277 268 minecraft:tuff
fill 283 277 269 289 278 269 minecraft:blackstone
fill 284 277 229 295 277 229 minecraft:blackstone
setblock 284 277 231 minecraft:tuff
fill 284 277 232 284 277 234 minecraft:blackstone
fill 284 277 242 289 277 242 minecraft:blackstone
setblock 284 277 244 minecraft:tuff
fill 284 277 255 291 277 255 minecraft:basalt
fill 284 277 256 289 277 256 minecraft:blackstone
setblock 284 277 257 minecraft:tuff
fill 284 277 261 285 277 261 minecraft:blackstone
fill 285 277 231 290 277 232 minecraft:blackstone
setblock 285 277 233 minecraft:tuff
fill 285 277 234 291 278 234 minecraft:blackstone
fill 285 277 243 289 277 244 minecraft:blackstone
setblock 285 277 246 minecraft:tuff
fill 285 277 247 285 277 249 minecraft:blackstone
fill 285 277 257 293 277 257 minecraft:blackstone
setblock 285 277 259 minecraft:tuff
setblock 286 277 235 minecraft:tuff
fill 286 277 246 288 277 247 minecraft:blackstone
setblock 286 277 248 minecraft:tuff
fill 286 277 249 288 278 249 minecraft:blackstone
fill 286 277 258 290 277 259 minecraft:blackstone
setblock 286 277 261 minecraft:tuff
fill 287 277 235 296 277 235 minecraft:basalt
fill 287 277 236 292 277 236 minecraft:blackstone
setblock 287 277 237 minecraft:tuff
fill 287 277 248 288 278 248 minecraft:blackstone
setblock 287 277 250 minecraft:tuff
fill 287 277 261 292 277 262 minecraft:blackstone
setblock 287 277 263 minecraft:tuff
fill 287 277 264 293 278 264 minecraft:blackstone
fill 288 277 237 293 277 237 minecraft:blackstone
setblock 288 277 239 minecraft:tuff
fill 288 277 250 289 277 250 minecraft:basalt
fill 288 277 251 289 277 251 minecraft:blackstone
setblock 288 277 252 minecraft:tuff
setblock 288 277 265 minecraft:tuff
fill 289 277 238 291 277 239 minecraft:blackstone
setblock 289 277 241 minecraft:tuff
fill 289 277 245 289 278 249 minecraft:netherrack
fill 289 277 252 289 278 252 minecraft:blackstone
setblock 289 277 254 minecraft:tuff
fill 289 277 265 300 277 265 minecraft:basalt
fill 289 277 266 294 277 266 minecraft:blackstone
setblock 289 277 267 minecraft:tuff
setblock 290 277 230 minecraft:tuff
setblock 290 277 241 minecraft:blackstone
fill 290 277 242 290 277 243 minecraft:netherrack
fill 290 277 251 290 277 252 minecraft:netherrack
fill 290 277 253 290 277 254 minecraft:blackstone
setblock 290 277 256 minecraft:tuff
fill 290 277 267 301 277 267 minecraft:blackstone
setblock 290 277 269 minecraft:tuff
fill 291 277 230 302 277 230 minecraft:basalt
fill 291 277 231 296 277 231 minecraft:blackstone
setblock 291 277 232 minecraft:tuff
fill 291 277 240 291 277 241 minecraft:netherrack
fill 291 277 253 291 277 254 minecraft:netherrack
fill 291 277 256 292 277 256 minecraft:blackstone
setblock 291 277 258 minecraft:tuff
fill 291 277 259 296 277 259 minecraft:blackstone
fill 291 277 268 295 277 269 minecraft:blackstone
fill 292 277 232 303 277 232 minecraft:blackstone
setblock 292 277 234 minecraft:tuff
setblock 292 277 238 minecraft:blackstone
setblock 292 277 239 minecraft:shroomlight
setblock 292 277 255 minecraft:shroomlight
fill 292 277 258 294 277 258 minecraft:blackstone
setblock 292 277 260 minecraft:tuff
fill 293 277 233 297 277 234 minecraft:blackstone
setblock 293 277 236 minecraft:tuff
setblock 293 277 238 minecraft:netherrack
setblock 293 277 239 minecraft:light[level=12]
setblock 293 277 247 minecraft:light[level=12]
setblock 293 277 255 minecraft:light[level=12]
setblock 293 277 256 minecraft:netherrack
fill 293 277 260 299 277 260 minecraft:basalt
fill 293 277 261 298 277 261 minecraft:blackstone
setblock 293 277 262 minecraft:tuff
setblock 294 277 236 minecraft:blackstone
setblock 294 277 237 minecraft:netherrack
setblock 294 277 257 minecraft:netherrack
fill 294 277 262 305 277 262 minecraft:blackstone
setblock 294 277 264 minecraft:tuff
fill 295 277 236 296 277 236 minecraft:netherrack
fill 295 277 258 296 277 258 minecraft:netherrack
fill 295 277 263 299 277 264 minecraft:blackstone
setblock 295 277 266 minecraft:tuff
setblock 296 277 229 minecraft:tuff
fill 296 277 266 307 277 266 minecraft:blackstone
setblock 296 277 268 minecraft:tuff
fill 296 277 269 302 278 269 minecraft:blackstone
fill 297 277 229 308 277 229 minecraft:blackstone
setblock 297 277 231 minecraft:tuff
fill 297 277 235 299 277 235 minecraft:netherrack
fill 297 277 259 299 277 259 minecraft:netherrack
fill 298 277 231 309 277 231 minecraft:blackstone
setblock 298 277 233 minecraft:tuff
fill 298 277 234 299 277 234 minecraft:blackstone
setblock 299 277 261 minecraft:tuff
fill 300 277 234 301 278 234 minecraft:netherrack
fill 300 277 260 301 278 260 minecraft:netherrack
fill 300 277 261 311 277 261 minecraft:blackstone
setblock 300 277 263 minecraft:tuff
fill 300 277 264 306 278 264 minecraft:blackstone
setblock 301 277 239 minecraft:light[level=12]
setblock 301 277 255 minecraft:light[level=12]
setblock 301 277 265 minecraft:tuff
fill 302 277 234 302 278 234 minecraft:shroomlight
fill 302 277 260 302 278 260 minecraft:shroomlight
fill 302 277 265 313 277 265 minecraft:basalt
setblock 302 277 267 minecraft:tuff
setblock 303 277 230 minecraft:tuff
fill 303 277 234 304 278 234 minecraft:netherrack
fill 303 277 260 304 278 260 minecraft:netherrack
fill 303 277 267 314 277 267 minecraft:blackstone
setblock 303 277 269 minecraft:tuff
fill 304 277 230 315 277 230 minecraft:basalt
setblock 304 277 232 minecraft:tuff
fill 304 277 268 308 277 269 minecraft:blackstone
fill 305 277 232 316 277 232 minecraft:blackstone
setblock 305 277 234 minecraft:tuff
fill 305 277 235 307 277 235 minecraft:netherrack
fill 305 277 236 307 300 236 minecraft:basalt
fill 305 277 259 307 277 259 minecraft:netherrack
setblock 305 277 260 minecraft:tuff
fill 306 277 233 310 277 234 minecraft:blackstone
fill 306 277 237 309 300 237 minecraft:basalt
fill 306 277 260 317 277 260 minecraft:basalt
setblock 306 277 262 minecraft:tuff
fill 307 277 238 308 300 238 minecraft:basalt
fill 307 277 262 318 277 262 minecraft:blackstone
setblock 307 277 264 minecraft:tuff
fill 308 277 235 311 277 235 minecraft:basalt
fill 308 277 236 309 277 236 minecraft:netherrack
fill 308 277 258 309 277 258 minecraft:netherrack
fill 308 277 259 310 277 259 minecraft:blackstone
fill 308 277 263 312 277 264 minecraft:blackstone
setblock 308 277 266 minecraft:tuff
setblock 309 277 229 minecraft:tuff
setblock 309 277 239 minecraft:light[level=12]
setblock 309 277 247 minecraft:light[level=12]
setblock 309 277 255 minecraft:light[level=12]
fill 309 277 266 316 277 266 minecraft:blackstone
setblock 309 277 268 minecraft:tuff
fill 309 277 269 315 278 269 minecraft:blackstone
fill 310 277 229 321 277 229 minecraft:blackstone
setblock 310 277 231 minecraft:tuff
fill 310 277 236 314 277 236 minecraft:blackstone
setblock 310 277 237 minecraft:netherrack
setblock 310 277 257 minecraft:netherrack
fill 310 277 258 316 277 258 minecraft:blackstone
fill 311 277 231 318 277 231 minecraft:blackstone
setblock 311 277 233 minecraft:tuff
fill 311 277 234 317 278 234 minecraft:blackstone
fill 311 277 237 312 277 237 minecraft:blackstone
setblock 311 277 238 minecraft:netherrack
setblock 311 277 256 minecraft:netherrack
fill 311 277 257 322 277 257 minecraft:blackstone
setblock 311 277 259 minecraft:tuff
setblock 312 277 235 minecraft:tuff
fill 312 277 238 319 277 238 minecraft:blackstone
setblock 312 277 239 minecraft:shroomlight
setblock 312 277 255 minecraft:shroomlight
fill 312 277 256 315 277 256 minecraft:blackstone
fill 312 277 259 323 277 259 minecraft:blackstone
setblock 312 277 261 minecraft:tuff
fill 313 277 235 323 277 235 minecraft:basalt
setblock 313 277 237 minecraft:tuff
setblock 313 277 239 minecraft:blackstone
fill 313 277 240 313 277 241 minecraft:netherrack
fill 313 277 253 313 277 254 minecraft:netherrack
fill 313 277 255 321 277 255 minecraft:basalt
fill 313 277 261 320 277 261 minecraft:blackstone
setblock 313 277 263 minecraft:tuff
fill 313 277 264 319 278 264 minecraft:blackstone
fill 314 277 237 316 278 237 minecraft:blackstone
setblock 314 277 239 minecraft:tuff
fill 314 277 240 320 277 240 minecraft:basalt
setblock 314 277 241 minecraft:blackstone
fill 314 277 242 314 277 243 minecraft:netherrack
fill 314 277 251 314 277 252 minecraft:netherrack
fill 314 277 253 314 277 254 minecraft:blackstone
setblock 314 277 265 minecraft:tuff
fill 315 277 239 323 277 239 minecraft:blackstone
setblock 315 277 241 minecraft:tuff
fill 315 277 242 315 277 244 minecraft:blackstone
fill 315 277 245 315 278 249 minecraft:netherrack
fill 315 277 250 323 277 250 minecraft:basalt
setblock 315 277 251 minecraft:blackstone
fill 315 277 253 320 278 253 minecraft:blackstone
setblock 315 277 254 minecraft:tuff
fill 315 277 265 323 277 265 minecraft:basalt
setblock 315 277 267 minecraft:tuff
setblock 316 277 230 minecraft:tuff
fill 316 277 242 321 278 242 minecraft:blackstone
setblock 316 277 243 minecraft:tuff
fill 316 277 244 322 278 244 minecraft:blackstone
setblock 316 277 245 minecraft:basalt
fill 316 277 246 317 277 249 minecraft:blackstone
fill 316 277 254 323 277 254 minecraft:blackstone
setblock 316 277 256 minecraft:tuff
fill 316 277 267 317 278 267 minecraft:blackstone
setblock 316 277 269 minecraft:tuff
fill 317 277 230 323 277 230 minecraft:basalt
setblock 317 277 232 minecraft:tuff
setblock 317 277 245 minecraft:tuff
setblock 317 277 258 minecraft:tuff
fill 317 277 268 317 279 269 minecraft:blackstone
fill 318 277 232 319 278 232 minecraft:blackstone
setblock 318 277 234 minecraft:tuff
setblock 318 277 236 minecraft:blackstone
fill 318 277 245 323 277 245 minecraft:basalt
fill 318 277 246 321 277 246 minecraft:blackstone
setblock 318 277 247 minecraft:tuff
fill 318 277 248 318 279 249 minecraft:blackstone
fill 318 277 258 323 277 258 minecraft:blackstone
setblock 318 277 260 minecraft:tuff
fill 318 277 269 323 277 269 minecraft:blackstone
fill 319 277 233 319 279 234 minecraft:blackstone
setblock 319 277 236 minecraft:tuff
setblock 319 277 249 minecraft:tuff
fill 319 277 260 323 277 260 minecraft:basalt
setblock 319 277 262 minecraft:tuff
fill 319 277 268 321 278 268 minecraft:blackstone
fill 320 277 234 323 277 234 minecraft:blackstone
fill 320 277 236 321 277 236 minecraft:blackstone
setblock 320 277 238 minecraft:tuff
fill 320 277 247 320 278 249 minecraft:blackstone
setblock 320 277 251 minecraft:tuff
fill 320 277 262 321 278 262 minecraft:blackstone
setblock 320 277 264 minecraft:tuff
setblock 320 277 266 minecraft:blackstone
fill 321 277 237 321 278 238 minecraft:blackstone
setblock 321 277 240 minecraft:tuff
fill 321 277 247 321 278 247 minecraft:blackstone
fill 321 277 249 323 279 249 minecraft:blackstone
fill 321 277 251 322 277 251 minecraft:blackstone
setblock 321 277 253 minecraft:tuff
fill 321 277 263 321 279 264 minecraft:blackstone
setblock 321 277 266 minecraft:tuff
setblock 322 277 229 minecraft:tuff
setblock 322 277 231 minecraft:blackstone
fill 322 277 238 323 279 238 minecraft:blackstone
fill 322 277 240 323 277 240 minecraft:basalt
setblock 322 277 242 minecraft:tuff
fill 322 277 252 322 278 253 minecraft:blackstone
setblock 322 277 255 minecraft:tuff
fill 322 277 264 323 279 264 minecraft:blackstone
fill 322 277 266 323 277 266 minecraft:blackstone
setblock 322 277 268 minecraft:tuff
fill 323 277 229 323 278 229 minecraft:blackstone
setblock 323 277 231 minecraft:tuff
setblock 323 277 236 minecraft:blackstone
fill 323 277 241 323 277 242 minecraft:blackstone
setblock 323 277 244 minecraft:tuff
fill 323 277 253 323 279 253 minecraft:blackstone
setblock 323 277 255 minecraft:basalt
setblock 323 277 257 minecraft:tuff
fill 323 277 267 323 278 268 minecraft:blackstone
fill 324 277 240 324 283 240 minecraft:blackstone
setblock 324 277 264 minecraft:magma_block
fill 282 278 249 284 280 249 minecraft:blackstone
fill 283 278 229 287 278 230 minecraft:blackstone
fill 283 278 231 288 278 231 minecraft:basalt
setblock 283 278 232 minecraft:tuff
fill 283 278 233 283 278 235 minecraft:blackstone
fill 283 278 236 284 278 236 minecraft:basalt
fill 283 278 237 285 278 238 minecraft:blackstone
fill 283 278 240 286 279 240 minecraft:blackstone
fill 283 278 241 289 278 241 minecraft:basalt
fill 283 278 242 287 278 242 minecraft:blackstone
setblock 283 278 245 minecraft:tuff
fill 283 278 246 288 278 246 minecraft:basalt
fill 283 278 247 283 278 248 minecraft:blackstone
fill 283 278 250 288 278 250 minecraft:blackstone
fill 283 278 251 285 278 251 minecraft:basalt
fill 283 278 252 286 278 253 minecraft:blackstone
fill 283 278 255 287 279 255 minecraft:blackstone
fill 283 278 256 291 278 256 minecraft:basalt
fill 283 278 257 288 278 257 minecraft:blackstone
setblock 283 278 258 minecraft:tuff
fill 283 278 260 283 281 260 minecraft:blackstone
fill 283 278 261 290 278 261 minecraft:basalt
fill 283 278 262 284 278 265 minecraft:blackstone
fill 283 278 266 286 278 266 minecraft:basalt
fill 283 278 267 287 278 268 minecraft:blackstone
fill 284 278 232 289 278 233 minecraft:blackstone
setblock 284 278 234 minecraft:tuff
fill 284 278 235 290 279 235 minecraft:blackstone
fill 284 278 244 288 278 245 minecraft:blackstone
setblock 284 278 247 minecraft:tuff
fill 284 278 248 286 279 248 minecraft:blackstone
fill 284 278 258 293 278 258 minecraft:blackstone
setblock 284 278 260 minecraft:tuff
setblock 285 278 236 minecraft:tuff
fill 285 278 243 288 278 243 minecraft:blackstone
fill 285 278 247 288 278 247 minecraft:blackstone
setblock 285 278 249 minecraft:tuff
fill 285 278 259 289 278 260 minecraft:blackstone
setblock 285 278 262 minecraft:tuff
fill 285 278 263 285 278 265 minecraft:blackstone
fill 286 278 236 293 278 236 minecraft:basalt
fill 286 278 237 291 278 237 minecraft:blackstone
setblock 286 278 238 minecraft:tuff
setblock 286 278 251 minecraft:tuff
fill 286 278 262 291 278 263 minecraft:blackstone
setblock 286 278 264 minecraft:tuff
fill 286 278 265 292 279 265 minecraft:blackstone
fill 287 278 238 291 278 238 minecraft:blackstone
setblock 287 278 240 minecraft:tuff
fill 287 278 251 288 278 251 minecraft:basalt
fill 287 278 252 288 278 252 minecraft:blackstone
setblock 287 278 253 minecraft:tuff
setblock 287 278 266 minecraft:tuff
setblock 288 278 229 minecraft:tuff
fill 288 278 230 294 279 230 minecraft:blackstone
fill 288 278 239 290 278 240 minecraft:blackstone
setblock 288 278 242 minecraft:tuff
fill 288 278 253 289 278 253 minecraft:blackstone
setblock 288 278 255 minecraft:tuff
fill 288 278 266 299 278 266 minecraft:basalt
fill 288 278 267 293 278 267 minecraft:blackstone
setblock 288 278 268 minecraft:tuff
fill 289 278 229 300 278 229 minecraft:blackstone
setblock 289 278 231 minecraft:tuff
setblock 289 278 242 minecraft:blackstone
fill 289 278 243 289 279 243 minecraft:netherrack
setblock 289 278 244 minecraft:shroomlight
setblock 289 278 250 minecraft:shroomlight
fill 289 278 251 289 279 251 minecraft:netherrack
fill 289 278 254 290 278 255 minecraft:blackstone
setblock 289 278 257 minecraft:tuff
fill 289 278 268 300 278 268 minecraft:blackstone
fill 290 278 231 301 278 231 minecraft:basalt
fill 290 278 232 295 278 232 minecraft:blackstone
setblock 290 278 233 minecraft:tuff
fill 290 278 241 290 278 242 minecraft:netherrack
fill 290 278 252 290 278 253 minecraft:netherrack
fill 290 278 257 292 278 257 minecraft:blackstone
setblock 290 278 259 minecraft:tuff
fill 290 278 260 296 278 260 minecraft:blackstone
fill 290 278 269 294 279 269 minecraft:blackstone
fill 291 278 233 302 278 233 minecraft:blackstone
setblock 291 278 235 minecraft:tuff
fill 291 278 239 291 278 240 minecraft:netherrack
fill 291 278 254 291 278 255 minecraft:netherrack
fill 291 278 259 295 278 259 minecraft:blackstone
setblock 291 278 261 minecraft:tuff
fill 292 278 234 295 278 235 minecraft:blackstone
setblock 292 278 237 minecraft:tuff
setblock 292 278 238 minecraft:netherrack
setblock 292 278 256 minecraft:netherrack
fill 292 278 261 303 278 261 minecraft:basalt
fill 292 278 262 297 278 262 minecraft:blackstone
setblock 292 278 263 minecraft:tuff
setblock 293 278 237 minecraft:netherrack
setblock 293 278 257 minecraft:netherrack
fill 293 278 263 304 278 263 minecraft:blackstone
setblock 293 278 265 minecraft:tuff
fill 294 278 236 295 278 236 minecraft:netherrack
fill 294 278 258 295 278 258 minecraft:netherrack
fill 294 278 264 298 278 265 minecraft:blackstone
setblock 294 278 267 minecraft:tuff
setblock 295 278 230 minecraft:tuff
fill 295 278 267 306 278 267 minecraft:blackstone
setblock 295 278 269 minecraft:tuff
fill 296 278 230 307 278 230 minecraft:blackstone
setblock 296 278 232 minecraft:tuff
fill 296 278 234 296 280 234 minecraft:blackstone
setblock 296 278 235 minecraft:shroomlight
setblock 296 278 259 minecraft:shroomlight
fill 297 278 232 308 278 232 minecraft:blackstone
setblock 297 278 234 minecraft:tuff
setblock 297 278 235 minecraft:netherrack
setblock 297 278 259 minecraft:netherrack
setblock 297 278 260 minecraft:tuff
fill 298 278 234 299 278 234 minecraft:netherrack
fill 298 278 260 299 278 260 minecraft:netherrack
setblock 298 278 262 minecraft:tuff
fill 299 278 262 310 278 262 minecraft:blackstone
setblock 299 278 264 minecraft:tuff
fill 299 278 265 305 279 265 minecraft:blackstone
setblock 300 278 266 minecraft:tuff
setblock 301 278 229 minecraft:tuff
fill 301 278 266 312 278 266 minecraft:basalt
setblock 301 278 268 minecraft:tuff
fill 302 278 229 313 278 229 minecraft:blackstone
setblock 302 278 231 minecraft:tuff
fill 302 278 268 313 278 268 minecraft:blackstone
fill 303 278 231 314 278 231 minecraft:basalt
setblock 303 278 233 minecraft:tuff
fill 303 278 269 307 279 269 minecraft:blackstone
fill 304 278 233 315 278 233 minecraft:blackstone
fill 304 278 235 304 279 236 minecraft:blackstone
setblock 304 278 261 minecraft:tuff
fill 305 278 234 306 278 234 minecraft:netherrack
fill 305 278 235 306 300 235 minecraft:basalt
fill 305 278 237 305 279 238 minecraft:blackstone
fill 305 278 260 306 278 260 minecraft:netherrack
fill 305 278 261 316 278 261 minecraft:basalt
setblock 305 278 263 minecraft:tuff
fill 306 278 238 306 279 239 minecraft:blackstone
fill 306 278 263 317 278 263 minecraft:blackstone
setblock 306 278 265 minecraft:tuff
fill 307 278 234 309 278 234 minecraft:blackstone
setblock 307 278 235 minecraft:netherrack
fill 307 278 239 308 279 239 minecraft:blackstone
setblock 307 278 259 minecraft:netherrack
fill 307 278 260 309 278 260 minecraft:blackstone
fill 307 278 264 311 278 265 minecraft:blackstone
setblock 307 278 267 minecraft:tuff
setblock 308 278 230 minecraft:tuff
setblock 308 278 235 minecraft:shroomlight
fill 308 278 236 308 300 236 minecraft:basalt
setblock 308 278 259 minecraft:shroomlight
fill 308 278 267 315 278 267 minecraft:blackstone
setblock 308 278 269 minecraft:tuff
fill 309 278 230 320 278 230 minecraft:blackstone
setblock 309 278 232 minecraft:tuff
fill 309 278 235 316 278 235 minecraft:blackstone
fill 309 278 236 310 278 236 minecraft:netherrack
fill 309 278 238 310 279 238 minecraft:blackstone
fill 309 278 258 310 278 258 minecraft:netherrack
fill 309 278 259 315 278 259 minecraft:blackstone
fill 310 278 232 317 278 232 minecraft:blackstone
setblock 310 278 234 minecraft:tuff
fill 310 278 237 310 279 237 minecraft:blackstone
setblock 310 278 260 minecraft:tuff
setblock 311 278 236 minecraft:tuff
setblock 311 278 237 minecraft:netherrack
setblock 311 278 257 minecraft:netherrack
fill 311 278 258 321 278 258 minecraft:blackstone
fill 311 278 260 322 278 260 minecraft:blackstone
setblock 311 278 262 minecraft:tuff
fill 312 278 236 323 278 236 minecraft:basalt
fill 312 278 237 313 278 237 minecraft:blackstone
setblock 312 278 238 minecraft:netherrack
setblock 312 278 256 minecraft:netherrack
fill 312 278 257 314 278 257 minecraft:blackstone
fill 312 278 262 319 278 262 minecraft:blackstone
setblock 312 278 264 minecraft:tuff
fill 312 278 265 318 279 265 minecraft:blackstone
fill 313 278 238 320 278 238 minecraft:blackstone
fill 313 278 239 313 278 240 minecraft:netherrack
fill 313 278 254 313 278 255 minecraft:netherrack
fill 313 278 256 320 278 256 minecraft:basalt
setblock 313 278 266 minecraft:tuff
setblock 314 278 229 minecraft:tuff
fill 314 278 239 318 278 240 minecraft:blackstone
fill 314 278 241 314 278 242 minecraft:netherrack
fill 314 278 252 314 278 253 minecraft:netherrack
fill 314 278 254 319 278 254 minecraft:blackstone
setblock 314 278 255 minecraft:tuff
fill 314 278 266 323 278 266 minecraft:basalt
setblock 314 278 268 minecraft:tuff
fill 315 278 229 322 278 229 minecraft:blackstone
setblock 315 278 231 minecraft:tuff
fill 315 278 241 319 278 241 minecraft:basalt
setblock 315 278 242 minecraft:blackstone
fill 315 278 243 315 279 243 minecraft:netherrack
setblock 315 278 244 minecraft:shroomlight
setblock 315 278 250 minecraft:shroomlight
fill 315 278 251 315 279 251 minecraft:netherrack
fill 315 278 252 318 278 252 minecraft:blackstone
fill 315 278 255 323 278 255 minecraft:blackstone
setblock 315 278 257 minecraft:tuff
fill 315 278 268 316 279 268 minecraft:blackstone
fill 316 278 231 323 278 231 minecraft:basalt
setblock 316 278 233 minecraft:tuff
fill 316 278 243 320 279 243 minecraft:blackstone
fill 316 278 245 321 278 245 minecraft:blackstone
setblock 316 278 246 minecraft:tuff
fill 316 278 247 316 278 250 minecraft:blackstone
fill 316 278 251 323 278 251 minecraft:basalt
fill 316 278 257 323 278 257 minecraft:blackstone
setblock 316 278 259 minecraft:tuff
fill 316 278 269 316 280 269 minecraft:blackstone
fill 317 278 233 318 279 233 minecraft:blackstone
setblock 317 278 235 minecraft:tuff
setblock 317 278 237 minecraft:blackstone
fill 317 278 246 323 278 246 minecraft:basalt
fill 317 278 247 318 278 247 minecraft:blackstone
setblock 317 278 248 minecraft:tuff
fill 317 278 249 317 279 250 minecraft:blackstone
fill 317 278 259 323 278 259 minecraft:blackstone
setblock 317 278 261 minecraft:tuff
fill 318 278 234 318 280 235 minecraft:blackstone
setblock 318 278 237 minecraft:tuff
setblock 318 278 250 minecraft:tuff
fill 318 278 261 323 278 261 minecraft:basalt
setblock 318 278 263 minecraft:tuff
fill 318 278 269 320 279 269 minecraft:blackstone
fill 319 278 235 323 278 235 minecraft:blackstone
fill 319 278 237 320 278 237 minecraft:blackstone
setblock 319 278 239 minecraft:tuff
fill 319 278 240 323 279 240 minecraft:blackstone
fill 319 278 249 319 280 250 minecraft:blackstone
setblock 319 278 252 minecraft:tuff
fill 319 278 263 320 279 263 minecraft:blackstone
setblock 319 278 265 minecraft:tuff
setblock 319 278 267 minecraft:blackstone
fill 320 278 234 322 279 234 minecraft:blackstone
fill 320 278 239 323 280 239 minecraft:blackstone
setblock 320 278 241 minecraft:tuff
fill 320 278 250 323 278 250 minecraft:blackstone
fill 320 278 252 321 278 252 minecraft:blackstone
setblock 320 278 254 minecraft:tuff
fill 320 278 264 320 280 265 minecraft:blackstone
setblock 320 278 267 minecraft:tuff
setblock 321 278 230 minecraft:tuff
setblock 321 278 232 minecraft:blackstone
fill 321 278 241 323 278 241 minecraft:basalt
setblock 321 278 243 minecraft:tuff
fill 321 278 253 321 279 254 minecraft:blackstone
setblock 321 278 256 minecraft:tuff
fill 321 278 265 323 279 265 minecraft:blackstone
fill 321 278 267 322 278 267 minecraft:blackstone
setblock 321 278 269 minecraft:tuff
fill 322 278 230 323 278 230 minecraft:blackstone
setblock 322 278 232 minecraft:tuff
setblock 322 278 237 minecraft:blackstone
fill 322 278 242 323 278 243 minecraft:blackstone
setblock 322 278 245 minecraft:tuff
setblock 322 278 247 minecraft:blackstone
fill 322 278 254 323 280 254 minecraft:blackstone
fill 322 278 256 323 278 256 minecraft:basalt
setblock 322 278 258 minecraft:tuff
fill 322 278 268 322 278 269 minecraft:blackstone
setblock 323 278 232 minecraft:blackstone
setblock 323 278 234 minecraft:tuff
fill 323 278 244 323 280 245 minecraft:blackstone
setblock 323 278 247 minecraft:tuff
setblock 323 278 252 minecraft:blackstone
fill 323 278 258 323 279 258 minecraft:blackstone
setblock 323 278 260 minecraft:tuff
setblock 323 278 262 minecraft:blackstone
setblock 323 278 269 minecraft:blackstone
fill 324 278 264 324 283 264 minecraft:blackstone
setblock 282 279 250 minecraft:shroomlight
fill 283 279 230 286 279 231 minecraft:blackstone
fill 283 279 232 287 279 232 minecraft:basalt
fill 283 279 233 288 279 234 minecraft:blackstone
setblock 283 279 235 minecraft:tuff
fill 283 279 236 289 280 236 minecraft:blackstone
setblock 283 279 237 minecraft:basalt
fill 283 279 238 284 279 239 minecraft:blackstone
fill 283 279 241 285 280 241 minecraft:blackstone
fill 283 279 242 288 279 242 minecraft:basalt
fill 283 279 245 287 279 246 minecraft:blackstone
fill 283 279 247 287 279 247 minecraft:basalt
setblock 283 279 248 minecraft:tuff
fill 283 279 250 283 279 251 minecraft:blackstone
fill 283 279 252 284 279 252 minecraft:basalt
fill 283 279 253 285 279 254 minecraft:blackstone
fill 283 279 256 286 280 256 minecraft:blackstone
fill 283 279 257 291 279 257 minecraft:basalt
fill 283 279 258 287 279 258 minecraft:blackstone
setblock 283 279 261 minecraft:tuff
fill 283 279 262 289 279 262 minecraft:basalt
fill 283 279 263 283 279 266 minecraft:blackstone
fill 283 279 267 285 279 267 minecraft:basalt
fill 284 279 229 292 279 229 minecraft:blackstone
setblock 284 279 237 minecraft:tuff
fill 284 279 244 287 279 244 minecraft:blackstone
setblock 284 279 250 minecraft:tuff
fill 284 279 251 288 279 251 minecraft:blackstone
fill 284 279 260 288 279 261 minecraft:blackstone
setblock 284 279 263 minecraft:tuff
fill 284 279 264 284 279 266 minecraft:blackstone
fill 284 279 268 292 279 268 minecraft:blackstone
fill 285 279 237 291 279 237 minecraft:basalt
fill 285 279 238 290 279 238 minecraft:blackstone
setblock 285 279 239 minecraft:tuff
fill 285 279 243 286 279 243 minecraft:blackstone
fill 285 279 249 287 279 250 minecraft:blackstone
setblock 285 279 252 minecraft:tuff
fill 285 279 259 294 279 259 minecraft:blackstone
fill 285 279 263 290 279 264 minecraft:blackstone
setblock 285 279 265 minecraft:tuff
fill 285 279 266 291 280 266 minecraft:blackstone
fill 285 279 269 286 279 269 minecraft:blackstone
fill 286 279 239 290 279 239 minecraft:blackstone
setblock 286 279 241 minecraft:tuff
fill 286 279 252 288 279 252 minecraft:basalt
fill 286 279 253 288 279 253 minecraft:blackstone
setblock 286 279 254 minecraft:tuff
setblock 286 279 267 minecraft:tuff
setblock 287 279 230 minecraft:tuff
fill 287 279 231 293 280 231 minecraft:blackstone
fill 287 279 240 288 281 241 minecraft:blackstone
setblock 287 279 243 minecraft:tuff
setblock 287 279 248 minecraft:blackstone
fill 287 279 254 289 279 254 minecraft:blackstone
setblock 287 279 256 minecraft:tuff
fill 287 279 267 298 279 267 minecraft:basalt
setblock 287 279 269 minecraft:tuff
setblock 288 279 232 minecraft:tuff
setblock 288 279 243 minecraft:blackstone
fill 288 279 244 288 280 244 minecraft:shroomlight
fill 288 279 245 288 279 249 minecraft:netherrack
fill 288 279 250 288 280 250 minecraft:shroomlight
fill 288 279 255 290 279 256 minecraft:blackstone
setblock 288 279 258 minecraft:tuff
fill 288 279 269 289 280 269 minecraft:blackstone
fill 289 279 232 300 279 232 minecraft:basalt
fill 289 279 233 294 279 233 minecraft:blackstone
setblock 289 279 234 minecraft:tuff
fill 289 279 240 289 280 240 minecraft:blackstone
fill 289 279 241 289 279 242 minecraft:netherrack
fill 289 279 252 289 279 253 minecraft:netherrack
fill 289 279 258 292 279 258 minecraft:blackstone
setblock 289 279 260 minecraft:tuff
fill 289 279 261 295 280 261 minecraft:blackstone
fill 290 279 234 295 279 234 minecraft:blackstone
setblock 290 279 236 minecraft:tuff
setblock 290 279 240 minecraft:netherrack
setblock 290 279 254 minecraft:netherrack
fill 290 279 260 295 279 260 minecraft:blackstone
setblock 290 279 262 minecraft:tuff
fill 291 279 235 292 281 236 minecraft:blackstone
fill 291 279 238 291 280 238 minecraft:shroomlight
setblock 291 279 239 minecraft:netherrack
setblock 291 279 255 minecraft:netherrack
fill 291 279 256 291 280 256 minecraft:shroomlight
fill 291 279 262 302 279 262 minecraft:basalt
fill 291 279 263 296 279 263 minecraft:blackstone
setblock 291 279 264 minecraft:tuff
setblock 292 279 237 minecraft:netherrack
setblock 292 279 238 minecraft:light[level=12]
setblock 292 279 245 minecraft:light[level=12]
setblock 292 279 252 minecraft:light[level=12]
setblock 292 279 257 minecraft:netherrack
fill 292 279 264 303 279 264 minecraft:blackstone
setblock 292 279 266 minecraft:tuff
setblock 293 279 229 minecraft:tuff
fill 293 279 235 294 280 235 minecraft:blackstone
fill 293 279 236 294 279 236 minecraft:netherrack
fill 293 279 258 294 279 258 minecraft:netherrack
fill 293 279 265 297 279 266 minecraft:blackstone
setblock 293 279 268 minecraft:tuff
fill 294 279 229 305 279 229 minecraft:blackstone
setblock 294 279 231 minecraft:tuff
fill 294 279 268 305 279 268 minecraft:blackstone
fill 295 279 230 299 279 231 minecraft:blackstone
setblock 295 279 233 minecraft:tuff
setblock 295 279 235 minecraft:netherrack
fill 295 279 258 297 279 258 minecraft:blackstone
setblock 295 279 259 minecraft:netherrack
fill 295 279 269 299 280 269 minecraft:blackstone
fill 296 279 233 298 279 233 minecraft:blackstone
fill 296 279 259 296 300 259 minecraft:basalt
fill 296 279 260 296 280 260 minecraft:shroomlight
setblock 296 279 261 minecraft:tuff
fill 297 279 234 298 279 234 minecraft:netherrack
setblock 297 279 259 minecraft:blackstone
fill 297 279 260 298 279 260 minecraft:netherrack
fill 297 279 261 298 279 261 minecraft:blackstone
setblock 297 279 263 minecraft:tuff
fill 298 279 263 309 279 263 minecraft:blackstone
setblock 298 279 265 minecraft:tuff
fill 298 279 266 304 280 266 minecraft:blackstone
setblock 299 279 228 minecraft:magma_block
fill 299 279 233 301 279 233 minecraft:netherrack
fill 299 279 234 299 300 234 minecraft:basalt
setblock 299 279 238 minecraft:light[level=12]
setblock 299 279 245 minecraft:light[level=12]
setblock 299 279 252 minecraft:light[level=12]
setblock 299 279 259 minecraft:light[level=12]
fill 299 279 261 301 279 261 minecraft:netherrack
setblock 299 279 267 minecraft:tuff
setblock 300 279 230 minecraft:tuff
fill 300 279 231 306 280 231 minecraft:blackstone
fill 300 279 267 311 279 267 minecraft:basalt
setblock 300 279 269 minecraft:tuff
fill 301 279 230 312 279 230 minecraft:blackstone
setblock 301 279 232 minecraft:tuff
fill 301 279 269 302 280 269 minecraft:blackstone
fill 302 279 232 313 279 232 minecraft:basalt
setblock 302 279 233 minecraft:shroomlight
setblock 302 279 261 minecraft:shroomlight
fill 303 279 233 305 279 233 minecraft:netherrack
fill 303 279 235 303 279 237 minecraft:blackstone
fill 303 279 261 305 279 261 minecraft:netherrack
setblock 303 279 262 minecraft:tuff
fill 304 279 234 305 279 234 minecraft:blackstone
fill 304 279 237 304 279 238 minecraft:blackstone
fill 304 279 262 315 279 262 minecraft:basalt
setblock 304 279 264 minecraft:tuff
setblock 305 279 239 minecraft:blackstone
fill 305 279 264 316 279 264 minecraft:blackstone
setblock 305 279 266 minecraft:tuff
setblock 306 279 229 minecraft:tuff
fill 306 279 233 307 279 233 minecraft:blackstone
fill 306 279 234 307 279 234 minecraft:netherrack
fill 306 279 240 309 279 240 minecraft:blackstone
setblock 306 279 245 minecraft:light[level=12]
setblock 306 279 252 minecraft:light[level=12]
setblock 306 279 259 minecraft:light[level=12]
fill 306 279 260 307 279 260 minecraft:netherrack
fill 306 279 261 308 279 261 minecraft:blackstone
fill 306 279 265 310 279 266 minecraft:blackstone
setblock 306 279 268 minecraft:tuff
fill 307 279 229 318 279 229 minecraft:blackstone
setblock 307 279 231 minecraft:tuff
fill 307 279 235 308 300 235 minecraft:basalt
fill 307 279 268 314 279 268 minecraft:blackstone
fill 308 279 231 319 279 231 minecraft:blackstone
setblock 308 279 233 minecraft:tuff
fill 308 279 234 308 280 234 minecraft:shroomlight
fill 308 279 260 308 280 260 minecraft:shroomlight
fill 308 279 269 312 280 269 minecraft:blackstone
fill 309 279 233 314 279 234 minecraft:blackstone
setblock 309 279 235 minecraft:netherrack
fill 309 279 236 309 300 236 minecraft:basalt
fill 309 279 239 310 279 239 minecraft:blackstone
setblock 309 279 259 minecraft:netherrack
fill 309 279 260 314 279 260 minecraft:blackstone
setblock 309 279 261 minecraft:tuff
fill 310 279 235 317 279 235 minecraft:blackstone
fill 310 279 236 311 279 236 minecraft:netherrack
fill 310 279 258 311 279 258 minecraft:netherrack
fill 310 279 259 320 279 259 minecraft:blackstone
fill 310 279 261 321 279 261 minecraft:blackstone
setblock 310 279 263 minecraft:tuff
fill 311 279 237 311 279 238 minecraft:blackstone
fill 311 279 263 318 279 263 minecraft:blackstone
setblock 311 279 265 minecraft:tuff
fill 311 279 266 317 280 266 minecraft:blackstone
fill 312 279 236 315 279 236 minecraft:blackstone
setblock 312 279 237 minecraft:netherrack
setblock 312 279 257 minecraft:netherrack
fill 312 279 258 313 279 258 minecraft:blackstone
setblock 312 279 267 minecraft:tuff
setblock 313 279 230 minecraft:tuff
fill 313 279 237 322 279 237 minecraft:basalt
fill 313 279 238 313 280 238 minecraft:shroomlight
setblock 313 279 239 minecraft:netherrack
setblock 313 279 245 minecraft:light[level=12]
setblock 313 279 252 minecraft:light[level=12]
setblock 313 279 255 minecraft:netherrack
fill 313 279 256 313 280 256 minecraft:shroomlight
fill 313 279 257 319 279 257 minecraft:basalt
fill 313 279 267 323 279 267 minecraft:basalt
setblock 313 279 269 minecraft:tuff
fill 314 279 230 322 279 230 minecraft:blackstone
setblock 314 279 232 minecraft:tuff
fill 314 279 238 316 279 239 minecraft:blackstone
setblock 314 279 240 minecraft:netherrack
setblock 314 279 254 minecraft:netherrack
fill 314 279 255 318 279 256 minecraft:blackstone
setblock 314 279 258 minecraft:tuff
fill 314 279 269 315 280 269 minecraft:blackstone
fill 315 279 232 323 279 232 minecraft:basalt
fill 315 279 233 316 279 233 minecraft:blackstone
setblock 315 279 234 minecraft:tuff
fill 315 279 240 317 279 240 minecraft:blackstone
fill 315 279 241 315 279 242 minecraft:netherrack
fill 315 279 252 315 279 253 minecraft:netherrack
fill 315 279 254 320 279 254 minecraft:blackstone
fill 315 279 258 322 279 258 minecraft:blackstone
setblock 315 279 260 minecraft:tuff
fill 316 279 234 317 280 234 minecraft:blackstone
setblock 316 279 236 minecraft:tuff
fill 316 279 241 323 279 241 minecraft:blackstone
fill 316 279 242 318 279 242 minecraft:basalt
fill 316 279 244 316 280 244 minecraft:shroomlight
fill 316 279 245 316 279 249 minecraft:netherrack
fill 316 279 250 316 280 250 minecraft:shroomlight
setblock 316 279 251 minecraft:blackstone
fill 316 279 252 323 279 252 minecraft:basalt
fill 316 279 253 317 279 253 minecraft:blackstone
fill 316 279 260 323 279 260 minecraft:blackstone
setblock 316 279 262 minecraft:tuff
fill 317 279 236 323 279 236 minecraft:blackstone
setblock 317 279 238 minecraft:tuff
fill 317 279 239 319 280 239 minecraft:blackstone
fill 317 279 244 319 279 246 minecraft:blackstone
fill 317 279 247 323 279 247 minecraft:basalt
setblock 317 279 248 minecraft:blackstone
setblock 317 279 251 minecraft:tuff
fill 317 279 262 323 279 262 minecraft:basalt
setblock 317 279 264 minecraft:tuff
fill 318 279 238 321 279 238 minecraft:blackstone
setblock 318 279 240 minecraft:tuff
fill 318 279 250 318 281 251 minecraft:blackstone
setblock 318 279 253 minecraft:tuff
fill 318 279 264 319 280 264 minecraft:blackstone
setblock 318 279 266 minecraft:tuff
setblock 318 279 268 minecraft:blackstone
setblock 319 279 229 minecraft:tuff
fill 319 279 235 321 280 235 minecraft:blackstone
setblock 319 279 242 minecraft:tuff
fill 319 279 248 321 279 248 minecraft:blackstone
fill 319 279 251 323 279 251 minecraft:blackstone
fill 319 279 253 320 279 253 minecraft:blackstone
setblock 319 279 255 minecraft:tuff
fill 319 279 256 323 280 256 minecraft:blackstone
fill 319 279 265 319 281 266 minecraft:blackstone
setblock 319 279 268 minecraft:tuff
fill 320 279 229 321 279 229 minecraft:blackstone
setblock 320 279 231 minecraft:tuff
setblock 320 279 233 minecraft:blackstone
fill 320 279 242 323 279 242 minecraft:basalt
setblock 320 279 244 minecraft:tuff
fill 320 279 245 320 281 246 minecraft:blackstone
fill 320 279 249 320 280 250 minecraft:blackstone
fill 320 279 255 323 281 255 minecraft:blackstone
setblock 320 279 257 minecraft:tuff
fill 320 279 266 323 279 266 minecraft:blackstone
fill 320 279 268 322 279 268 minecraft:blackstone
fill 321 279 231 323 279 231 minecraft:blackstone
setblock 321 279 233 minecraft:tuff
fill 321 279 243 322 279 245 minecraft:blackstone
setblock 321 279 246 minecraft:tuff
fill 321 279 250 322 281 250 minecraft:blackstone
fill 321 279 257 323 279 257 minecraft:basalt
setblock 321 279 259 minecraft:tuff
setblock 321 279 269 minecraft:blackstone
fill 322 279 233 323 279 233 minecraft:blackstone
setblock 322 279 235 minecraft:tuff
fill 322 279 246 323 281 246 minecraft:blackstone
setblock 322 279 248 minecraft:tuff
setblock 322 279 253 minecraft:blackstone
fill 322 279 259 323 280 259 minecraft:blackstone
setblock 322 279 261 minecraft:tuff
setblock 322 279 263 minecraft:blackstone
fill 323 279 234 323 280 235 minecraft:blackstone
setblock 323 279 237 minecraft:tuff
setblock 323 279 243 minecraft:blackstone
setblock 323 279 248 minecraft:blackstone
setblock 323 279 250 minecraft:tuff
fill 323 279 261 323 281 261 minecraft:blackstone
setblock 323 279 263 minecraft:tuff
fill 282 280 250 287 280 250 minecraft:blackstone
fill 283 280 234 287 280 235 minecraft:blackstone
fill 283 280 237 288 281 237 minecraft:blackstone
setblock 283 280 238 minecraft:tuff
fill 283 280 239 283 280 240 minecraft:blackstone
fill 283 280 242 284 282 242 minecraft:blackstone
fill 283 280 243 287 280 243 minecraft:basalt
fill 283 280 245 286 280 247 minecraft:blackstone
fill 283 280 248 286 280 248 minecraft:basalt
setblock 283 280 251 minecraft:tuff
fill 283 280 252 287 281 252 minecraft:blackstone
setblock 283 280 253 minecraft:basalt
fill 283 280 254 284 280 255 minecraft:blackstone
fill 283 280 257 285 281 257 minecraft:blackstone
fill 283 280 258 291 280 258 minecraft:basalt
fill 283 280 261 287 280 262 minecraft:blackstone
fill 283 280 263 288 280 263 minecraft:basalt
setblock 283 280 264 minecraft:tuff
fill 284 280 233 286 280 233 minecraft:basalt
fill 284 280 238 290 280 238 minecraft:basalt
fill 284 280 239 289 280 239 minecraft:blackstone
setblock 284 280 240 minecraft:tuff
fill 284 280 244 285 280 244 minecraft:blackstone
fill 284 280 251 287 280 251 minecraft:blackstone
setblock 284 280 253 minecraft:tuff
fill 284 280 260 293 280 260 minecraft:blackstone
fill 284 280 264 289 280 265 minecraft:blackstone
fill 285 280 232 292 280 232 minecraft:blackstone
fill 285 280 240 286 281 240 minecraft:blackstone
setblock 285 280 242 minecraft:tuff
fill 285 280 249 286 280 249 minecraft:blackstone
fill 285 280 253 288 280 253 minecraft:basalt
fill 285 280 254 288 280 254 minecraft:blackstone
setblock 285 280 255 minecraft:tuff
fill 285 280 259 286 280 259 minecraft:blackstone
setblock 286 280 231 minecraft:tuff
fill 286 280 241 286 282 242 minecraft:blackstone
setblock 286 280 244 minecraft:tuff
fill 286 280 255 289 280 255 minecraft:blackstone
setblock 286 280 257 minecraft:tuff
fill 286 280 267 290 280 267 minecraft:blackstone
fill 287 280 230 291 280 230 minecraft:blackstone
setblock 287 280 233 minecraft:tuff
fill 287 280 242 288 281 242 minecraft:blackstone
setblock 287 280 244 minecraft:blackstone
fill 287 280 245 287 280 249 minecraft:magma_block
fill 287 280 256 290 280 257 minecraft:blackstone
setblock 287 280 259 minecraft:tuff
fill 287 280 268 297 280 268 minecraft:basalt
fill 288 280 229 297 280 229 minecraft:blackstone
fill 288 280 233 298 280 233 minecraft:basalt
fill 288 280 234 293 280 234 minecraft:blackstone
setblock 288 280 235 minecraft:tuff
setblock 288 280 243 minecraft:magma_block
fill 288 280 251 288 280 252 minecraft:magma_block
fill 288 280 259 293 280 259 minecraft:blackstone
setblock 288 280 261 minecraft:tuff
fill 288 280 262 294 281 262 minecraft:blackstone
fill 289 280 235 290 281 235 minecraft:blackstone
setblock 289 280 237 minecraft:tuff
setblock 289 280 241 minecraft:magma_block
fill 289 280 253 289 280 254 minecraft:magma_block
setblock 289 280 263 minecraft:tuff
fill 290 280 236 290 282 237 minecraft:blackstone
setblock 290 280 239 minecraft:magma_block
setblock 290 280 255 minecraft:magma_block
fill 290 280 263 301 280 263 minecraft:basalt
fill 290 280 264 295 280 264 minecraft:blackstone
setblock 290 280 265 minecraft:tuff
fill 290 280 269 291 280 269 minecraft:blackstone
fill 291 280 237 291 281 237 minecraft:blackstone
setblock 291 280 257 minecraft:magma_block
fill 291 280 265 302 280 265 minecraft:blackstone
setblock 291 280 267 minecraft:tuff
setblock 292 280 230 minecraft:tuff
fill 292 280 258 293 280 258 minecraft:magma_block
fill 292 280 266 296 280 267 minecraft:blackstone
setblock 292 280 269 minecraft:tuff
fill 293 280 230 304 280 230 minecraft:blackstone
setblock 293 280 232 minecraft:tuff
setblock 293 280 236 minecraft:magma_block
fill 293 280 269 294 280 269 minecraft:blackstone
fill 294 280 231 298 280 232 minecraft:blackstone
setblock 294 280 234 minecraft:tuff
setblock 294 280 259 minecraft:magma_block
setblock 294 280 260 minecraft:tuff
setblock 295 280 234 minecraft:blackstone
fill 295 280 259 295 300 259 minecraft:basalt
setblock 295 280 260 minecraft:magma_block
setblock 295 280 262 minecraft:tuff
fill 296 280 261 296 280 262 minecraft:blackstone
setblock 296 280 264 minecraft:tuff
fill 297 280 234 298 300 234 minecraft:basalt
fill 297 280 261 299 280 261 minecraft:magma_block
fill 297 280 262 299 280 262 minecraft:blackstone
fill 297 280 264 308 280 264 minecraft:blackstone
setblock 297 280 266 minecraft:tuff
fill 297 280 267 303 281 267 minecraft:blackstone
setblock 298 280 229 minecraft:tuff
setblock 298 280 268 minecraft:tuff
fill 299 280 228 299 280 229 minecraft:blackstone
setblock 299 280 231 minecraft:tuff
fill 299 280 232 305 281 232 minecraft:blackstone
setblock 299 280 233 minecraft:magma_block
fill 299 280 268 310 280 268 minecraft:basalt
fill 300 280 229 310 280 229 minecraft:blackstone
fill 300 280 262 301 280 262 minecraft:magma_block
setblock 300 280 269 minecraft:blackstone
fill 302 280 262 302 281 262 minecraft:shroomlight
setblock 302 280 263 minecraft:tuff
fill 303 280 262 304 280 262 minecraft:magma_block
fill 303 280 263 314 280 263 minecraft:basalt
setblock 303 280 265 minecraft:tuff
fill 303 280 269 304 280 269 minecraft:blackstone
fill 304 280 265 315 280 265 minecraft:blackstone
setblock 304 280 267 minecraft:tuff
setblock 305 280 230 minecraft:tuff
fill 305 280 233 307 280 233 minecraft:magma_block
fill 305 280 261 307 280 261 minecraft:magma_block
fill 305 280 262 307 280 262 minecraft:blackstone
fill 305 280 266 309 280 267 minecraft:blackstone
setblock 305 280 269 minecraft:tuff
fill 306 280 230 317 280 230 minecraft:blackstone
setblock 306 280 232 minecraft:tuff
fill 306 280 234 307 300 234 minecraft:basalt
fill 306 280 269 307 280 269 minecraft:blackstone
fill 307 280 231 311 280 232 minecraft:blackstone
fill 308 280 233 312 280 233 minecraft:basalt
fill 308 280 261 313 280 261 minecraft:blackstone
setblock 308 280 262 minecraft:tuff
setblock 309 280 234 minecraft:magma_block
fill 309 280 235 309 300 235 minecraft:basalt
setblock 309 280 260 minecraft:magma_block
fill 309 280 262 320 280 262 minecraft:blackstone
setblock 309 280 264 minecraft:tuff
fill 310 280 234 315 280 234 minecraft:blackstone
setblock 310 280 235 minecraft:magma_block
setblock 310 280 259 minecraft:magma_block
fill 310 280 260 319 280 260 minecraft:blackstone
fill 310 280 264 317 280 264 minecraft:blackstone
setblock 310 280 266 minecraft:tuff
fill 310 280 267 316 281 267 minecraft:blackstone
setblock 311 280 229 minecraft:tuff
fill 311 280 235 313 280 235 minecraft:blackstone
fill 311 280 236 312 280 236 minecraft:magma_block
fill 311 280 258 312 280 258 minecraft:magma_block
fill 311 280 259 312 280 259 minecraft:blackstone
setblock 311 280 268 minecraft:tuff
fill 312 280 229 318 280 229 minecraft:blackstone
setblock 312 280 231 minecraft:tuff
fill 312 280 232 318 281 232 minecraft:blackstone
fill 312 280 268 319 280 268 minecraft:basalt
fill 313 280 231 321 280 231 minecraft:blackstone
setblock 313 280 233 minecraft:tuff
fill 313 280 236 320 280 236 minecraft:blackstone
setblock 313 280 237 minecraft:magma_block
setblock 313 280 257 minecraft:magma_block
fill 313 280 258 318 280 258 minecraft:basalt
setblock 313 280 259 minecraft:tuff
setblock 313 280 269 minecraft:blackstone
fill 314 280 233 322 280 233 minecraft:basalt
setblock 314 280 235 minecraft:tuff
fill 314 280 237 314 281 237 minecraft:blackstone
fill 314 280 238 321 280 238 minecraft:basalt
setblock 314 280 239 minecraft:magma_block
setblock 314 280 255 minecraft:magma_block
fill 314 280 256 317 280 257 minecraft:blackstone
fill 314 280 259 321 280 259 minecraft:blackstone
setblock 314 280 261 minecraft:tuff
fill 315 280 235 317 281 235 minecraft:blackstone
setblock 315 280 237 minecraft:tuff
setblock 315 280 239 minecraft:blackstone
fill 315 280 240 315 280 241 minecraft:magma_block
fill 315 280 253 315 280 254 minecraft:magma_block
fill 315 280 255 319 280 255 minecraft:blackstone
fill 315 280 261 322 280 261 minecraft:blackstone
setblock 315 280 263 minecraft:tuff
fill 316 280 237 323 280 237 minecraft:blackstone
setblock 316 280 239 minecraft:tuff
fill 316 280 240 316 280 241 minecraft:blackstone
fill 316 280 242 316 280 243 minecraft:magma_block
fill 316 280 251 316 280 252 minecraft:magma_block
fill 316 280 253 322 280 253 minecraft:basalt
setblock 316 280 254 minecraft:blackstone
fill 316 280 263 323 280 263 minecraft:basalt
setblock 316 280 265 minecraft:tuff
fill 317 280 240 322 281 240 minecraft:blackstone
setblock 317 280 241 minecraft:tuff
fill 317 280 242 323 281 242 minecraft:blackstone
setblock 317 280 243 minecraft:basalt
fill 317 280 244 322 280 244 minecraft:blackstone
fill 317 280 245 317 280 249 minecraft:magma_block
fill 317 280 250 317 280 252 minecraft:blackstone
setblock 317 280 254 minecraft:tuff
fill 317 280 265 318 281 265 minecraft:blackstone
setblock 317 280 267 minecraft:tuff
setblock 317 280 269 minecraft:blackstone
setblock 318 280 230 minecraft:tuff
fill 318 280 241 323 280 241 minecraft:blackstone
setblock 318 280 243 minecraft:tuff
fill 318 280 245 318 280 247 minecraft:blackstone
fill 318 280 248 323 280 248 minecraft:basalt
setblock 318 280 249 minecraft:blackstone
fill 318 280 252 323 280 252 minecraft:blackstone
fill 318 280 254 321 280 254 minecraft:blackstone
setblock 318 280 256 minecraft:tuff
fill 318 280 257 323 281 257 minecraft:blackstone
fill 318 280 266 318 280 267 minecraft:blackstone
setblock 318 280 269 minecraft:tuff
setblock 319 280 230 minecraft:blackstone
setblock 319 280 232 minecraft:tuff
setblock 319 280 234 minecraft:blackstone
fill 319 280 243 323 280 243 minecraft:basalt
setblock 319 280 245 minecraft:tuff
fill 319 280 246 319 282 247 minecraft:blackstone
fill 319 280 251 321 281 251 minecraft:blackstone
setblock 319 280 258 minecraft:tuff
fill 319 280 267 320 280 267 minecraft:blackstone
fill 320 280 232 321 280 232 minecraft:blackstone
setblock 320 280 234 minecraft:tuff
setblock 320 280 247 minecraft:tuff
fill 320 280 258 323 280 258 minecraft:basalt
setblock 320 280 260 minecraft:tuff
fill 320 280 266 321 280 266 minecraft:blackstone
fill 321 280 234 322 280 234 minecraft:blackstone
setblock 321 280 236 minecraft:tuff
fill 321 280 245 321 281 247 minecraft:blackstone
setblock 321 280 249 minecraft:tuff
fill 321 280 260 323 281 260 minecraft:blackstone
setblock 321 280 262 minecraft:tuff
fill 321 280 264 321 280 265 minecraft:blackstone
fill 322 280 235 322 280 236 minecraft:blackstone
setblock 322 280 238 minecraft:tuff
fill 322 280 245 322 281 245 minecraft:blackstone
fill 322 280 247 323 282 247 minecraft:blackstone
fill 322 280 249 323 280 249 minecraft:blackstone
setblock 322 280 251 minecraft:tuff
fill 322 280 262 323 280 262 minecraft:blackstone
setblock 322 280 264 minecraft:tuff
setblock 322 280 265 minecraft:blackstone
setblock 323 280 236 minecraft:blackstone
setblock 323 280 238 minecraft:basalt
setblock 323 280 240 minecraft:tuff
fill 323 280 250 323 281 251 minecraft:blackstone
setblock 323 280 253 minecraft:tuff
setblock 323 280 264 minecraft:blackstone
fill 282 281 249 282 283 250 minecraft:blackstone
fill 283 281 238 287 281 238 minecraft:blackstone
fill 283 281 239 289 281 239 minecraft:basalt
fill 283 281 240 284 281 240 minecraft:blackstone
setblock 283 281 241 minecraft:tuff
fill 283 281 243 283 282 243 minecraft:blackstone
fill 283 281 244 287 281 244 minecraft:basalt
fill 283 281 245 284 281 248 minecraft:blackstone
fill 283 281 249 286 281 249 minecraft:basalt
fill 283 281 250 286 281 251 minecraft:blackstone
fill 283 281 253 287 281 253 minecraft:blackstone
setblock 283 281 254 minecraft:tuff
fill 283 281 255 283 281 256 minecraft:blackstone
fill 283 281 258 284 281 258 minecraft:blackstone
fill 283 281 259 291 281 259 minecraft:basalt
fill 283 281 261 292 281 261 minecraft:blackstone
fill 284 281 236 286 281 236 minecraft:blackstone
fill 284 281 241 285 282 241 minecraft:blackstone
setblock 284 281 243 minecraft:tuff
fill 284 281 254 287 281 254 minecraft:basalt
fill 284 281 255 288 281 255 minecraft:blackstone
setblock 284 281 256 minecraft:tuff
fill 284 281 260 285 281 260 minecraft:blackstone
fill 284 281 262 286 281 262 minecraft:blackstone
fill 285 281 235 288 281 235 minecraft:blackstone
fill 285 281 242 285 283 243 minecraft:blackstone
setblock 285 281 245 minecraft:tuff
fill 285 281 246 285 281 248 minecraft:blackstone
fill 285 281 256 289 281 256 minecraft:blackstone
setblock 285 281 258 minecraft:tuff
fill 285 281 263 293 281 263 minecraft:blackstone
fill 286 281 233 291 281 233 minecraft:blackstone
setblock 286 281 234 minecraft:tuff
fill 286 281 243 287 282 243 minecraft:blackstone
fill 286 281 245 286 281 246 minecraft:blackstone
setblock 286 281 247 minecraft:tuff
fill 286 281 248 286 282 248 minecraft:blackstone
fill 286 281 257 290 281 258 minecraft:blackstone
setblock 286 281 260 minecraft:tuff
fill 286 281 264 287 281 264 minecraft:basalt
fill 286 281 265 294 281 265 minecraft:blackstone
fill 287 281 232 297 281 232 minecraft:blackstone
fill 287 281 234 294 281 234 minecraft:basalt
setblock 287 281 236 minecraft:tuff
fill 287 281 245 287 281 249 minecraft:netherrack
setblock 287 281 250 minecraft:shroomlight
fill 287 281 251 287 282 251 minecraft:netherrack
fill 287 281 260 293 281 260 minecraft:blackstone
setblock 287 281 262 minecraft:tuff
fill 287 281 266 288 281 266 minecraft:blackstone
fill 288 281 236 289 282 236 minecraft:blackstone
setblock 288 281 238 minecraft:tuff
fill 288 281 252 288 281 254 minecraft:netherrack
setblock 288 281 264 minecraft:tuff
fill 289 281 231 290 281 231 minecraft:blackstone
fill 289 281 237 289 282 238 minecraft:blackstone
setblock 289 281 255 minecraft:netherrack
fill 289 281 264 300 281 264 minecraft:basalt
setblock 289 281 266 minecraft:tuff
fill 289 281 267 295 281 267 minecraft:blackstone
fill 290 281 230 296 281 230 minecraft:blackstone
setblock 290 281 238 minecraft:blackstone
setblock 290 281 256 minecraft:shroomlight
fill 290 281 266 301 281 266 minecraft:blackstone
setblock 290 281 268 minecraft:tuff
fill 291 281 229 302 281 229 minecraft:basalt
setblock 291 281 231 minecraft:tuff
setblock 291 281 257 minecraft:netherrack
setblock 291 281 258 minecraft:blackstone
fill 291 281 268 302 281 268 minecraft:blackstone
fill 291 281 269 296 281 269 minecraft:basalt
fill 292 281 231 303 281 231 minecraft:blackstone
setblock 292 281 233 minecraft:tuff
setblock 292 281 258 minecraft:netherrack
setblock 292 281 259 minecraft:tuff
fill 293 281 233 297 281 233 minecraft:blackstone
setblock 293 281 235 minecraft:tuff
setblock 293 281 259 minecraft:netherrack
setblock 293 281 261 minecraft:tuff
setblock 293 281 270 minecraft:crying_obsidian
setblock 294 281 260 minecraft:netherrack
setblock 294 281 261 minecraft:blackstone
setblock 294 281 263 minecraft:tuff
fill 295 281 260 296 300 260 minecraft:basalt
fill 295 281 261 295 282 261 minecraft:shroomlight
fill 295 281 262 297 281 263 minecraft:blackstone
setblock 295 281 265 minecraft:tuff
fill 296 281 261 297 281 261 minecraft:netherrack
fill 296 281 265 307 281 265 minecraft:blackstone
setblock 296 281 267 minecraft:tuff
setblock 297 281 230 minecraft:tuff
setblock 297 281 269 minecraft:tuff
fill 298 281 230 309 281 230 minecraft:blackstone
setblock 298 281 232 minecraft:tuff
fill 298 281 233 299 300 233 minecraft:basalt
fill 298 281 262 301 281 262 minecraft:netherrack
fill 298 281 263 306 281 263 minecraft:blackstone
fill 298 281 269 309 281 269 minecraft:basalt
fill 299 281 228 299 283 228 minecraft:blackstone
setblock 301 281 264 minecraft:tuff
fill 302 281 264 313 281 264 minecraft:basalt
setblock 302 281 266 minecraft:tuff
setblock 303 281 229 minecraft:tuff
fill 303 281 262 306 281 262 minecraft:netherrack
fill 303 281 266 314 281 266 minecraft:blackstone
setblock 303 281 268 minecraft:tuff
fill 304 281 229 315 281 229 minecraft:basalt
setblock 304 281 231 minecraft:tuff
fill 304 281 267 308 281 268 minecraft:blackstone
fill 305 281 231 316 281 231 minecraft:blackstone
fill 306 281 232 310 282 232 minecraft:blackstone
setblock 307 281 233 minecraft:netherrack
fill 307 281 261 308 281 261 minecraft:netherrack
fill 307 281 262 312 281 262 minecraft:blackstone
setblock 307 281 263 minecraft:tuff
fill 308 281 233 317 281 233 minecraft:blackstone
fill 308 281 234 311 281 234 minecraft:basalt
fill 308 281 263 319 281 263 minecraft:blackstone
setblock 308 281 265 minecraft:tuff
fill 309 281 261 309 282 261 minecraft:shroomlight
fill 309 281 265 316 281 265 minecraft:blackstone
setblock 309 281 267 minecraft:tuff
fill 309 281 268 315 281 268 minecraft:blackstone
setblock 310 281 230 minecraft:tuff
setblock 310 281 260 minecraft:netherrack
fill 310 281 261 318 281 261 minecraft:blackstone
setblock 310 281 269 minecraft:tuff
fill 311 281 230 316 281 230 minecraft:blackstone
setblock 311 281 232 minecraft:tuff
setblock 311 281 235 minecraft:netherrack
setblock 311 281 259 minecraft:netherrack
setblock 311 281 260 minecraft:blackstone
fill 311 281 269 315 281 269 minecraft:basalt
setblock 312 281 234 minecraft:tuff
fill 312 281 235 314 281 235 minecraft:blackstone
setblock 312 281 236 minecraft:netherrack
setblock 312 281 258 minecraft:netherrack
fill 312 281 259 317 281 259 minecraft:basalt
setblock 312 281 260 minecraft:tuff
fill 313 281 234 320 281 234 minecraft:basalt
setblock 313 281 236 minecraft:tuff
setblock 313 281 237 minecraft:netherrack
setblock 313 281 257 minecraft:netherrack
fill 313 281 258 323 281 258 minecraft:blackstone
fill 313 281 260 320 281 260 minecraft:blackstone
setblock 313 281 262 minecraft:tuff
fill 314 281 236 322 281 236 minecraft:blackstone
setblock 314 281 238 minecraft:shroomlight
setblock 314 281 256 minecraft:shroomlight
fill 314 281 257 316 281 257 minecraft:blackstone
fill 314 281 262 322 281 262 minecraft:blackstone
setblock 314 281 264 minecraft:tuff
fill 315 281 237 319 281 238 minecraft:blackstone
setblock 315 281 239 minecraft:netherrack
setblock 315 281 255 minecraft:netherrack
fill 315 281 256 322 281 256 minecraft:blackstone
fill 315 281 264 320 281 264 minecraft:basalt
setblock 315 281 266 minecraft:tuff
fill 316 281 239 320 281 239 minecraft:basalt
fill 316 281 240 316 281 242 minecraft:netherrack
fill 316 281 252 316 281 254 minecraft:netherrack
setblock 316 281 255 minecraft:tuff
fill 316 281 266 318 281 266 minecraft:blackstone
setblock 316 281 268 minecraft:tuff
setblock 317 281 231 minecraft:tuff
fill 317 281 241 321 281 241 minecraft:blackstone
fill 317 281 243 317 282 243 minecraft:netherrack
setblock 317 281 244 minecraft:shroomlight
fill 317 281 245 317 281 249 minecraft:netherrack
setblock 317 281 250 minecraft:shroomlight
fill 317 281 251 317 282 251 minecraft:netherrack
fill 317 281 252 320 281 253 minecraft:blackstone
fill 317 281 254 321 281 254 minecraft:basalt
fill 317 281 255 319 281 255 minecraft:blackstone
setblock 317 281 257 minecraft:tuff
setblock 317 281 267 minecraft:blackstone
setblock 318 281 233 minecraft:tuff
setblock 318 281 235 minecraft:blackstone
fill 318 281 243 322 282 243 minecraft:blackstone
fill 318 281 244 323 281 244 minecraft:basalt
fill 318 281 245 319 281 245 minecraft:blackstone
setblock 318 281 246 minecraft:tuff
fill 318 281 247 318 281 248 minecraft:blackstone
fill 318 281 249 323 281 249 minecraft:basalt
setblock 318 281 259 minecraft:tuff
fill 319 281 232 319 281 233 minecraft:blackstone
setblock 319 281 235 minecraft:tuff
setblock 319 281 248 minecraft:tuff
setblock 319 281 250 minecraft:blackstone
fill 319 281 259 323 281 259 minecraft:basalt
setblock 319 281 261 minecraft:tuff
setblock 320 281 233 minecraft:blackstone
fill 320 281 235 321 281 235 minecraft:blackstone
setblock 320 281 237 minecraft:tuff
fill 320 281 238 323 281 238 minecraft:blackstone
fill 320 281 247 320 282 248 minecraft:blackstone
setblock 320 281 250 minecraft:tuff
fill 320 281 261 322 281 261 minecraft:blackstone
setblock 320 281 263 minecraft:tuff
setblock 320 281 265 minecraft:blackstone
fill 321 281 237 323 281 237 minecraft:blackstone
setblock 321 281 239 minecraft:tuff
fill 321 281 248 323 282 248 minecraft:blackstone
setblock 321 281 252 minecraft:tuff
fill 321 281 253 323 282 253 minecraft:blackstone
setblock 321 281 263 minecraft:blackstone
fill 322 281 239 323 281 239 minecraft:basalt
setblock 322 281 241 minecraft:tuff
fill 322 281 251 322 282 252 minecraft:blackstone
setblock 322 281 254 minecraft:tuff
fill 323 281 240 323 281 241 minecraft:blackstone
setblock 323 281 243 minecraft:tuff
setblock 323 281 245 minecraft:blackstone
fill 323 281 252 323 282 252 minecraft:blackstone
setblock 323 281 254 minecraft:basalt
setblock 323 281 256 minecraft:tuff
setblock 283 282 241 minecraft:blackstone
setblock 283 282 244 minecraft:tuff
fill 283 282 245 286 282 245 minecraft:basalt
fill 283 282 246 283 282 249 minecraft:blackstone
fill 283 282 250 285 282 250 minecraft:basalt
fill 283 282 251 286 282 254 minecraft:blackstone
fill 283 282 255 287 282 255 minecraft:basalt
fill 283 282 256 288 282 256 minecraft:blackstone
setblock 283 282 257 minecraft:tuff
fill 284 282 239 286 282 239 minecraft:blackstone
fill 284 282 240 288 282 240 minecraft:basalt
fill 284 282 243 284 282 244 minecraft:blackstone
setblock 284 282 246 minecraft:tuff
fill 284 282 247 284 282 249 minecraft:blackstone
fill 284 282 257 289 282 258 minecraft:blackstone
setblock 284 282 259 minecraft:tuff
fill 285 282 238 288 282 238 minecraft:blackstone
fill 285 282 244 286 282 244 minecraft:blackstone
fill 285 282 246 286 282 247 minecraft:blackstone
setblock 285 282 248 minecraft:tuff
fill 285 282 249 286 282 249 minecraft:blackstone
fill 285 282 259 291 282 259 minecraft:blackstone
fill 285 282 260 290 282 260 minecraft:basalt
fill 286 282 236 287 282 236 minecraft:blackstone
setblock 286 282 237 minecraft:tuff
setblock 286 282 250 minecraft:tuff
fill 286 282 261 291 282 262 minecraft:blackstone
fill 287 282 235 292 282 235 minecraft:basalt
fill 287 282 237 288 282 237 minecraft:blackstone
setblock 287 282 239 minecraft:tuff
fill 287 282 241 287 282 242 minecraft:blackstone
fill 287 282 252 287 282 253 minecraft:netherrack
setblock 287 282 254 minecraft:blackstone
fill 287 282 263 298 282 263 minecraft:blackstone
fill 288 282 234 290 282 234 minecraft:blackstone
setblock 288 282 239 minecraft:blackstone
fill 288 282 254 288 282 255 minecraft:netherrack
fill 288 282 264 292 282 264 minecraft:blackstone
fill 289 282 233 295 282 233 minecraft:blackstone
setblock 289 282 256 minecraft:netherrack
fill 289 282 265 299 282 265 minecraft:basalt
setblock 290 282 232 minecraft:tuff
setblock 290 282 257 minecraft:shroomlight
setblock 290 282 258 minecraft:tuff
fill 290 282 266 293 282 266 minecraft:blackstone
fill 291 282 232 298 282 232 minecraft:blackstone
setblock 291 282 234 minecraft:tuff
setblock 291 282 236 minecraft:blackstone
setblock 291 282 258 minecraft:netherrack
setblock 291 282 260 minecraft:tuff
fill 292 282 231 295 282 231 minecraft:blackstone
fill 292 282 234 293 282 234 minecraft:blackstone
setblock 292 282 259 minecraft:netherrack
setblock 292 282 260 minecraft:basalt
fill 292 282 261 293 282 261 minecraft:blackstone
setblock 292 282 262 minecraft:tuff
fill 292 282 267 300 282 267 minecraft:blackstone
fill 293 282 230 301 282 230 minecraft:basalt
setblock 293 282 260 minecraft:netherrack
fill 293 282 262 295 282 262 minecraft:blackstone
setblock 293 282 264 minecraft:tuff
fill 293 282 268 294 282 268 minecraft:blackstone
fill 293 282 270 293 283 270 minecraft:blackstone
fill 294 282 260 294 300 260 minecraft:basalt
fill 294 282 261 294 283 261 minecraft:netherrack
fill 294 282 264 305 282 264 minecraft:blackstone
setblock 294 282 266 minecraft:tuff
setblock 295 282 229 minecraft:tuff
fill 295 282 266 306 282 266 minecraft:blackstone
setblock 295 282 268 minecraft:tuff
fill 295 282 269 301 282 269 minecraft:blackstone
fill 296 282 229 307 282 229 minecraft:blackstone
setblock 296 282 231 minecraft:tuff
fill 296 282 233 297 300 233 minecraft:basalt
fill 296 282 261 296 300 261 minecraft:basalt
fill 296 282 262 298 282 262 minecraft:netherrack
fill 296 282 268 307 282 268 minecraft:blackstone
fill 297 282 231 308 282 231 minecraft:blackstone
fill 299 282 232 300 300 232 minecraft:basalt
fill 299 282 263 301 282 263 minecraft:netherrack
setblock 300 282 265 minecraft:tuff
fill 301 282 265 312 282 265 minecraft:basalt
setblock 301 282 267 minecraft:tuff
setblock 302 282 230 minecraft:tuff
setblock 302 282 263 minecraft:shroomlight
fill 302 282 267 313 282 267 minecraft:blackstone
setblock 302 282 269 minecraft:tuff
fill 303 282 230 313 282 230 minecraft:basalt
fill 303 282 263 305 282 263 minecraft:netherrack
fill 303 282 269 311 282 269 minecraft:blackstone
fill 306 282 262 308 282 262 minecraft:netherrack
fill 306 282 263 311 282 263 minecraft:blackstone
setblock 306 282 264 minecraft:tuff
fill 307 282 264 318 282 264 minecraft:blackstone
setblock 307 282 266 minecraft:tuff
setblock 308 282 229 minecraft:tuff
fill 308 282 234 309 300 234 minecraft:basalt
fill 308 282 266 316 282 266 minecraft:blackstone
setblock 308 282 268 minecraft:tuff
fill 309 282 229 311 282 229 minecraft:blackstone
setblock 309 282 231 minecraft:tuff
setblock 309 282 233 minecraft:blackstone
fill 309 282 262 317 282 262 minecraft:blackstone
fill 309 282 268 313 282 268 minecraft:blackstone
fill 310 282 231 314 282 231 minecraft:blackstone
setblock 310 282 233 minecraft:tuff
fill 310 282 261 310 283 261 minecraft:netherrack
fill 311 282 232 315 282 234 minecraft:blackstone
fill 311 282 259 311 300 259 minecraft:basalt
setblock 311 282 260 minecraft:netherrack
setblock 311 282 261 minecraft:tuff
fill 312 282 235 319 282 235 minecraft:basalt
setblock 312 282 259 minecraft:netherrack
fill 312 282 260 316 282 260 minecraft:basalt
fill 312 282 261 320 282 261 minecraft:blackstone
setblock 312 282 263 minecraft:tuff
setblock 313 282 236 minecraft:netherrack
setblock 313 282 258 minecraft:netherrack
fill 313 282 259 322 282 259 minecraft:blackstone
fill 313 282 263 319 282 263 minecraft:blackstone
setblock 313 282 265 minecraft:tuff
fill 314 282 236 317 282 236 minecraft:blackstone
setblock 314 282 237 minecraft:shroomlight
setblock 314 282 257 minecraft:shroomlight
fill 314 282 258 315 282 258 minecraft:blackstone
fill 314 282 265 317 282 265 minecraft:basalt
setblock 314 282 267 minecraft:tuff
fill 315 282 237 320 282 237 minecraft:blackstone
setblock 315 282 238 minecraft:netherrack
setblock 315 282 256 minecraft:netherrack
fill 315 282 257 321 282 257 minecraft:blackstone
setblock 316 282 232 minecraft:tuff
fill 316 282 233 316 282 234 minecraft:blackstone
fill 316 282 238 318 282 238 minecraft:blackstone
fill 316 282 239 316 282 240 minecraft:netherrack
fill 316 282 254 316 282 255 minecraft:netherrack
fill 316 282 256 323 282 256 minecraft:blackstone
setblock 316 282 258 minecraft:tuff
setblock 317 282 233 minecraft:blackstone
setblock 317 282 234 minecraft:tuff
fill 317 282 239 322 282 239 minecraft:blackstone
fill 317 282 240 319 282 240 minecraft:basalt
fill 317 282 241 317 282 242 minecraft:netherrack
fill 317 282 252 317 282 253 minecraft:netherrack
fill 317 282 254 323 282 254 minecraft:blackstone
fill 317 282 255 320 282 255 minecraft:basalt
fill 317 282 258 322 282 258 minecraft:blackstone
setblock 317 282 260 minecraft:tuff
setblock 318 282 234 minecraft:blackstone
setblock 318 282 236 minecraft:tuff
fill 318 282 241 320 282 242 minecraft:blackstone
fill 318 282 244 318 282 250 minecraft:netherrack
fill 318 282 251 318 282 253 minecraft:blackstone
fill 318 282 260 321 282 260 minecraft:basalt
setblock 318 282 262 minecraft:tuff
fill 319 282 236 320 282 236 minecraft:blackstone
setblock 319 282 238 minecraft:tuff
fill 319 282 244 321 282 244 minecraft:blackstone
fill 319 282 245 323 282 245 minecraft:basalt
fill 319 282 248 319 282 249 minecraft:blackstone
fill 319 282 250 323 282 250 minecraft:basalt
setblock 319 282 251 minecraft:tuff
fill 319 282 252 319 283 253 minecraft:blackstone
fill 319 282 262 320 282 262 minecraft:blackstone
fill 320 282 238 321 282 238 minecraft:blackstone
setblock 320 282 240 minecraft:tuff
fill 320 282 246 322 282 246 minecraft:blackstone
fill 320 282 249 323 282 249 minecraft:blackstone
fill 320 282 251 321 282 252 minecraft:blackstone
setblock 320 282 253 minecraft:tuff
fill 321 282 240 322 282 240 minecraft:basalt
fill 321 282 241 323 282 241 minecraft:blackstone
setblock 321 282 242 minecraft:tuff
setblock 321 282 247 minecraft:blackstone
setblock 321 282 255 minecraft:tuff
fill 322 282 242 323 282 242 minecraft:blackstone
setblock 322 282 244 minecraft:tuff
fill 322 282 255 323 282 255 minecraft:basalt
setblock 322 282 257 minecraft:tuff
fill 323 282 243 323 282 244 minecraft:blackstone
setblock 323 282 246 minecraft:tuff
setblock 323 282 251 minecraft:blackstone
setblock 323 282 257 minecraft:blackstone
fill 284 283 244 284 283 245 minecraft:blackstone
setblock 284 283 246 minecraft:basalt
fill 284 283 247 284 283 248 minecraft:blackstone
setblock 284 283 249 minecraft:tuff
setblock 284 283 250 minecraft:blackstone
setblock 284 283 251 minecraft:basalt
fill 284 283 252 284 283 254 minecraft:blackstone
fill 285 283 241 286 283 241 minecraft:basalt
setblock 285 283 244 minecraft:blackstone
fill 285 283 245 285 283 253 minecraft:magma_block
fill 285 283 254 285 283 255 minecraft:blackstone
setblock 285 283 256 minecraft:basalt
fill 285 283 257 286 283 257 minecraft:blackstone
fill 286 283 239 287 283 239 minecraft:blackstone
setblock 286 283 240 minecraft:tuff
fill 286 283 242 286 283 245 minecraft:magma_block
fill 286 283 249 286 283 256 minecraft:magma_block
fill 286 283 258 286 283 259 minecraft:blackstone
fill 287 283 238 288 283 238 minecraft:blackstone
fill 287 283 240 287 283 241 minecraft:magma_block
setblock 287 283 253 minecraft:netherrack
fill 287 283 254 287 283 258 minecraft:magma_block
fill 287 283 259 287 283 260 minecraft:blackstone
setblock 288 283 237 minecraft:blackstone
setblock 288 283 239 minecraft:magma_block
setblock 288 283 255 minecraft:netherrack
fill 288 283 256 288 283 259 minecraft:magma_block
setblock 288 283 260 minecraft:blackstone
setblock 288 283 261 minecraft:basalt
setblock 289 283 236 minecraft:basalt
setblock 289 283 237 minecraft:magma_block
setblock 289 283 257 minecraft:shroomlight
fill 289 283 258 289 283 261 minecraft:magma_block
setblock 289 283 262 minecraft:blackstone
setblock 290 283 235 minecraft:tuff
setblock 290 283 236 minecraft:magma_block
setblock 290 283 258 minecraft:netherrack
setblock 290 283 259 minecraft:blackstone
fill 290 283 260 290 283 262 minecraft:magma_block
setblock 290 283 263 minecraft:blackstone
fill 291 283 234 292 283 234 minecraft:blackstone
setblock 291 283 235 minecraft:magma_block
setblock 291 283 259 minecraft:netherrack
setblock 291 283 260 minecraft:blackstone
fill 291 283 261 291 283 263 minecraft:magma_block
fill 291 283 264 292 283 264 minecraft:blackstone
fill 292 283 233 293 283 233 minecraft:blackstone
setblock 292 283 260 minecraft:netherrack
setblock 292 283 261 minecraft:basalt
fill 292 283 262 292 284 263 minecraft:magma_block
setblock 292 283 265 minecraft:tuff
fill 293 283 232 294 283 232 minecraft:blackstone
setblock 293 283 261 minecraft:netherrack
fill 293 283 262 294 283 262 minecraft:blackstone
fill 293 283 263 294 283 264 minecraft:magma_block
setblock 293 283 265 minecraft:blackstone
fill 293 283 266 295 283 266 minecraft:basalt
setblock 294 283 233 minecraft:magma_block
fill 294 283 265 298 283 265 minecraft:magma_block
fill 295 283 231 298 283 231 minecraft:basalt
setblock 295 283 232 minecraft:tuff
fill 295 283 261 295 300 261 minecraft:basalt
setblock 295 283 262 minecraft:shroomlight
fill 295 283 263 296 283 263 minecraft:blackstone
fill 295 283 264 296 284 264 minecraft:magma_block
fill 295 283 267 298 283 267 minecraft:blackstone
setblock 296 283 232 minecraft:magma_block
setblock 296 283 262 minecraft:netherrack
fill 296 283 266 310 283 266 minecraft:magma_block
fill 297 283 230 297 300 230 minecraft:basalt
fill 297 283 232 298 300 232 minecraft:basalt
fill 297 283 263 300 283 263 minecraft:netherrack
setblock 297 283 264 minecraft:blackstone
fill 298 283 230 306 283 230 minecraft:blackstone
setblock 298 283 264 minecraft:tuff
fill 298 283 268 299 283 268 minecraft:blackstone
fill 299 283 231 300 283 231 minecraft:magma_block
fill 299 283 264 300 283 265 minecraft:blackstone
fill 299 283 267 307 283 267 minecraft:magma_block
setblock 300 283 268 minecraft:tuff
setblock 301 283 264 minecraft:netherrack
fill 301 283 265 304 283 265 minecraft:blackstone
fill 301 283 268 308 283 268 minecraft:blackstone
fill 302 283 264 302 284 264 minecraft:shroomlight
setblock 303 283 264 minecraft:netherrack
fill 304 283 231 307 283 231 minecraft:magma_block
fill 304 283 263 307 283 263 minecraft:netherrack
fill 304 283 264 309 283 264 minecraft:blackstone
setblock 305 283 265 minecraft:tuff
fill 306 283 265 307 283 265 minecraft:blackstone
setblock 307 283 230 minecraft:tuff
setblock 308 283 230 minecraft:blackstone
fill 308 283 231 311 283 231 minecraft:basalt
fill 308 283 232 310 283 232 minecraft:magma_block
setblock 308 283 262 minecraft:netherrack
fill 308 283 263 311 283 263 minecraft:blackstone
fill 308 283 265 312 283 265 minecraft:magma_block
fill 308 283 267 311 283 267 minecraft:blackstone
setblock 309 283 262 minecraft:shroomlight
fill 310 283 233 312 283 233 minecraft:magma_block
setblock 310 283 262 minecraft:tuff
fill 310 283 264 313 283 264 minecraft:magma_block
fill 311 283 232 313 283 232 minecraft:blackstone
fill 311 283 260 311 300 260 minecraft:basalt
setblock 311 283 261 minecraft:netherrack
fill 311 283 262 313 283 262 minecraft:blackstone
setblock 311 283 266 minecraft:basalt
fill 312 283 234 313 283 234 minecraft:magma_block
fill 312 283 259 312 300 259 minecraft:basalt
setblock 312 283 260 minecraft:netherrack
fill 312 283 261 314 283 261 minecraft:basalt
fill 312 283 263 315 283 263 minecraft:magma_block
setblock 312 283 266 minecraft:tuff
fill 313 283 233 314 283 233 minecraft:blackstone
fill 313 283 235 315 283 235 minecraft:magma_block
setblock 313 283 259 minecraft:netherrack
fill 313 283 260 315 283 260 minecraft:blackstone
fill 313 283 265 314 283 265 minecraft:blackstone
setblock 313 283 266 minecraft:basalt
fill 314 283 234 315 283 234 minecraft:blackstone
fill 314 283 236 316 283 236 minecraft:magma_block
setblock 314 283 258 minecraft:netherrack
setblock 314 283 259 minecraft:blackstone
fill 314 283 262 316 283 262 minecraft:magma_block
fill 314 283 264 315 283 264 minecraft:blackstone
fill 315 283 237 317 283 237 minecraft:magma_block
setblock 315 283 257 minecraft:shroomlight
fill 315 283 258 316 283 258 minecraft:blackstone
setblock 315 283 259 minecraft:tuff
fill 315 283 261 317 283 261 minecraft:magma_block
setblock 316 283 235 minecraft:tuff
fill 316 283 238 317 283 238 minecraft:magma_block
setblock 316 283 239 minecraft:netherrack
fill 316 283 255 316 283 256 minecraft:netherrack
fill 316 283 257 317 283 257 minecraft:blackstone
setblock 316 283 259 minecraft:blackstone
fill 316 283 260 317 284 260 minecraft:magma_block
setblock 316 283 263 minecraft:blackstone
setblock 317 283 236 minecraft:basalt
fill 317 283 239 318 283 240 minecraft:magma_block
setblock 317 283 241 minecraft:netherrack
fill 317 283 253 317 283 254 minecraft:netherrack
fill 317 283 255 318 283 255 minecraft:blackstone
setblock 317 283 256 minecraft:basalt
fill 317 283 258 318 283 259 minecraft:magma_block
setblock 317 283 262 minecraft:blackstone
fill 318 283 237 318 283 238 minecraft:blackstone
fill 318 283 241 319 284 242 minecraft:magma_block
setblock 318 283 243 minecraft:shroomlight
fill 318 283 244 318 283 245 minecraft:netherrack
fill 318 283 249 318 283 250 minecraft:netherrack
setblock 318 283 251 minecraft:shroomlight
setblock 318 283 252 minecraft:netherrack
fill 318 283 253 318 283 254 minecraft:blackstone
fill 318 283 256 319 284 257 minecraft:magma_block
fill 318 283 260 319 283 260 minecraft:blackstone
setblock 318 283 261 minecraft:basalt
fill 319 283 238 319 283 239 minecraft:blackstone
setblock 319 283 240 minecraft:magma_block
fill 319 283 243 320 283 244 minecraft:magma_block
setblock 319 283 245 minecraft:blackstone
fill 319 283 246 319 283 248 minecraft:netherrack
fill 319 283 249 319 283 250 minecraft:blackstone
setblock 319 283 251 minecraft:basalt
fill 319 283 254 320 283 255 minecraft:magma_block
setblock 319 283 258 minecraft:magma_block
fill 319 283 259 320 283 259 minecraft:blackstone
setblock 319 283 270 minecraft:shroomlight
fill 320 283 239 320 283 240 minecraft:blackstone
fill 320 283 241 321 283 241 minecraft:basalt
setblock 320 283 242 minecraft:magma_block
fill 320 283 245 321 283 253 minecraft:magma_block
setblock 320 283 256 minecraft:magma_block
fill 320 283 257 320 283 258 minecraft:blackstone
fill 321 283 242 321 283 244 minecraft:blackstone
fill 321 283 254 321 283 255 minecraft:blackstone
setblock 321 283 256 minecraft:basalt
setblock 321 283 257 minecraft:blackstone
fill 322 283 244 322 283 245 minecraft:blackstone
setblock 322 283 246 minecraft:basalt
setblock 322 283 247 minecraft:tuff
fill 322 283 248 322 283 250 minecraft:blackstone
setblock 322 283 251 minecraft:basalt
fill 322 283 252 322 283 254 minecraft:blackstone
fill 282 284 228 282 287 233 minecraft:brown_terracotta
setblock 282 284 234 minecraft:gray_terracotta
setblock 282 284 235 minecraft:light_gray_terracotta
fill 282 284 236 282 284 270 minecraft:brown_terracotta
fill 283 284 228 296 285 228 minecraft:brown_terracotta
fill 283 284 270 286 287 270 minecraft:brown_terracotta
fill 285 284 231 285 285 231 minecraft:light[level=12]
setblock 285 284 239 minecraft:light[level=12]
setblock 285 284 247 minecraft:light[level=12]
setblock 285 284 255 minecraft:light[level=12]
setblock 285 284 263 minecraft:light[level=12]
fill 286 284 252 286 284 254 minecraft:magma_block
fill 287 284 255 287 284 257 minecraft:magma_block
setblock 287 284 270 minecraft:light_gray_terracotta
fill 288 284 257 288 284 258 minecraft:magma_block
fill 288 284 270 294 285 270 minecraft:brown_terracotta
fill 289 284 258 289 284 260 minecraft:magma_block
fill 290 284 259 290 284 261 minecraft:magma_block
fill 291 284 260 291 284 262 minecraft:magma_block
setblock 292 284 261 minecraft:magma_block
setblock 293 284 231 minecraft:light[level=12]
setblock 293 284 239 minecraft:light[level=12]
setblock 293 284 247 minecraft:light[level=12]
setblock 293 284 255 minecraft:light[level=12]
fill 293 284 262 294 284 263 minecraft:magma_block
fill 294 284 261 294 300 261 minecraft:basalt
setblock 294 284 264 minecraft:magma_block
fill 295 284 263 297 284 263 minecraft:magma_block
fill 295 284 265 301 284 265 minecraft:magma_block
setblock 295 284 270 minecraft:light_gray_terracotta
fill 296 284 231 296 287 232 minecraft:basalt
fill 296 284 270 324 284 270 minecraft:brown_terracotta
setblock 297 284 228 minecraft:gray_terracotta
fill 297 284 231 299 300 231 minecraft:basalt
fill 297 284 264 301 284 264 minecraft:magma_block
fill 298 284 228 324 284 228 minecraft:brown_terracotta
fill 298 284 230 298 300 230 minecraft:basalt
fill 298 284 266 308 284 266 minecraft:magma_block
setblock 301 284 231 minecraft:light[level=12]
setblock 301 284 239 minecraft:light[level=12]
setblock 301 284 255 minecraft:light[level=12]
setblock 301 284 263 minecraft:light[level=12]
setblock 302 284 265 minecraft:shroomlight
fill 303 284 264 311 284 265 minecraft:magma_block
fill 307 284 263 309 284 263 minecraft:magma_block
setblock 309 284 231 minecraft:light[level=12]
setblock 309 284 239 minecraft:light[level=12]
setblock 309 284 247 minecraft:light[level=12]
setblock 309 284 255 minecraft:light[level=12]
fill 310 284 262 315 284 262 minecraft:magma_block
setblock 310 284 263 minecraft:shroomlight
fill 311 284 263 314 284 263 minecraft:magma_block
fill 312 284 260 312 300 260 minecraft:basalt
fill 312 284 261 316 284 261 minecraft:magma_block
setblock 312 284 264 minecraft:magma_block
fill 313 284 260 315 284 260 minecraft:magma_block
setblock 314 284 235 minecraft:magma_block
fill 314 284 259 317 284 259 minecraft:magma_block
setblock 315 284 236 minecraft:magma_block
fill 315 284 258 316 284 258 minecraft:shroomlight
setblock 316 284 237 minecraft:magma_block
fill 316 284 257 317 284 257 minecraft:magma_block
setblock 317 284 231 minecraft:light[level=12]
fill 317 284 238 317 284 239 minecraft:magma_block
setblock 317 284 247 minecraft:light[level=12]
fill 317 284 255 317 284 256 minecraft:magma_block
fill 317 284 258 318 284 258 minecraft:magma_block
setblock 317 284 263 minecraft:light[level=12]
setblock 318 284 240 minecraft:magma_block
fill 318 284 252 319 284 255 minecraft:magma_block
fill 319 284 243 319 284 250 minecraft:magma_block
setblock 319 284 251 minecraft:shroomlight
fill 320 284 244 320 284 254 minecraft:magma_block
fill 321 284 251 321 291 251 minecraft:white_wool
fill 324 284 229 324 284 269 minecraft:brown_terracotta
fill 282 285 234 282 285 241 minecraft:brown_terracotta
setblock 282 285 242 minecraft:orange_terracotta
fill 282 285 243 282 285 270 minecraft:brown_terracotta
fill 284 285 260 285 289 260 minecraft:white_wool
setblock 285 285 238 minecraft:light[level=12]
setblock 285 285 245 minecraft:light[level=12]
setblock 285 285 252 minecraft:light[level=12]
setblock 285 285 259 minecraft:light[level=12]
fill 285 285 261 286 289 261 minecraft:white_wool
setblock 285 285 266 minecraft:light[level=12]
fill 287 285 270 287 289 270 minecraft:brown_terracotta
setblock 292 285 231 minecraft:light[level=12]
setblock 292 285 238 minecraft:light[level=12]
setblock 292 285 245 minecraft:light[level=12]
setblock 292 285 252 minecraft:light[level=12]
setblock 292 285 259 minecraft:light[level=12]
setblock 292 285 266 minecraft:light[level=12]
fill 295 285 270 310 285 270 minecraft:brown_terracotta
fill 297 285 228 298 289 228 minecraft:brown_terracotta
setblock 299 285 228 minecraft:gray_terracotta
setblock 299 285 238 minecraft:light[level=12]
setblock 299 285 245 minecraft:light[level=12]
setblock 299 285 252 minecraft:light[level=12]
setblock 299 285 259 minecraft:light[level=12]
setblock 299 285 266 minecraft:light[level=12]
fill 300 285 228 324 285 228 minecraft:brown_terracotta
setblock 306 285 231 minecraft:light[level=12]
setblock 306 285 238 minecraft:light[level=12]
setblock 306 285 245 minecraft:light[level=12]
setblock 306 285 252 minecraft:light[level=12]
setblock 306 285 259 minecraft:light[level=12]
setblock 306 285 266 minecraft:light[level=12]
setblock 311 285 270 minecraft:gray_terracotta
fill 312 285 261 312 300 261 minecraft:basalt
fill 312 285 270 324 285 270 minecraft:brown_terracotta
setblock 313 285 231 minecraft:light[level=12]
setblock 313 285 238 minecraft:light[level=12]
setblock 313 285 245 minecraft:light[level=12]
fill 313 285 246 313 286 247 minecraft:blackstone
setblock 313 285 252 minecraft:light[level=12]
setblock 313 285 259 minecraft:light[level=12]
fill 313 285 260 313 300 260 minecraft:basalt
setblock 313 285 266 minecraft:light[level=12]
fill 319 285 251 320 290 251 minecraft:white_wool
setblock 320 285 231 minecraft:light[level=12]
setblock 320 285 238 minecraft:light[level=12]
setblock 320 285 245 minecraft:light[level=12]
fill 320 285 249 321 289 250 minecraft:white_wool
fill 320 285 252 323 289 252 minecraft:white_wool
setblock 320 285 259 minecraft:light[level=12]
setblock 320 285 266 minecraft:light[level=12]
fill 321 285 253 322 289 253 minecraft:white_wool
fill 322 285 250 322 290 251 minecraft:white_wool
fill 324 285 229 324 285 249 minecraft:brown_terracotta
setblock 324 285 250 minecraft:light_gray_terracotta
fill 324 285 251 324 286 252 minecraft:brown_terracotta
setblock 324 285 253 minecraft:gray_terracotta
fill 324 285 254 324 287 267 minecraft:brown_terracotta
setblock 324 285 268 minecraft:gray_terracotta
fill 324 285 269 324 292 269 minecraft:brown_terracotta
fill 282 286 234 282 288 240 minecraft:brown_terracotta
setblock 282 286 241 minecraft:light_gray_terracotta
fill 282 286 242 282 287 246 minecraft:brown_terracotta
setblock 282 286 247 minecraft:light_gray_terracotta
fill 282 286 248 282 287 270 minecraft:brown_terracotta
fill 283 286 228 284 287 228 minecraft:brown_terracotta
fill 284 286 258 285 288 259 minecraft:white_wool
fill 284 286 261 284 288 262 minecraft:white_wool
setblock 285 286 228 minecraft:orange_terracotta
fill 285 286 262 286 288 262 minecraft:white_wool
fill 286 286 228 296 286 228 minecraft:brown_terracotta
fill 286 286 259 286 290 260 minecraft:white_wool
fill 287 286 260 287 288 261 minecraft:white_wool
fill 288 286 270 291 289 270 minecraft:brown_terracotta
setblock 292 286 270 minecraft:gray_terracotta
fill 293 286 270 301 288 270 minecraft:brown_terracotta
fill 299 286 228 310 288 228 minecraft:brown_terracotta
setblock 302 286 270 minecraft:light_gray_terracotta
fill 303 286 270 312 286 270 minecraft:brown_terracotta
fill 310 286 238 310 288 238 minecraft:magma_block
setblock 311 286 228 minecraft:gray_terracotta
setblock 312 286 228 minecraft:brown_terracotta
fill 312 286 251 313 287 252 minecraft:magma_block
setblock 313 286 228 minecraft:light_gray_terracotta
setblock 313 286 270 minecraft:orange_terracotta
fill 314 286 228 324 288 228 minecraft:brown_terracotta
fill 314 286 270 315 292 270 minecraft:brown_terracotta
setblock 316 286 270 minecraft:gray_terracotta
fill 317 286 270 322 287 270 minecraft:brown_terracotta
fill 318 286 251 318 289 251 minecraft:white_wool
fill 319 286 249 319 288 250 minecraft:white_wool
fill 319 286 252 319 290 252 minecraft:white_wool
fill 320 286 244 321 291 244 minecraft:gray_wool
fill 320 286 253 320 289 253 minecraft:white_wool
fill 321 286 248 322 288 248 minecraft:white_wool
fill 321 286 254 322 288 254 minecraft:white_wool
fill 322 286 249 322 289 249 minecraft:white_wool
fill 323 286 250 323 290 251 minecraft:white_wool
fill 323 286 253 323 289 253 minecraft:white_wool
setblock 323 286 270 minecraft:light_gray_terracotta
fill 324 286 229 324 286 244 minecraft:brown_terracotta
setblock 324 286 245 minecraft:light_gray_terracotta
fill 324 286 246 324 288 250 minecraft:brown_terracotta
fill 324 286 253 324 289 253 minecraft:brown_terracotta
fill 324 286 268 324 292 268 minecraft:brown_terracotta
fill 324 286 270 324 294 270 minecraft:brown_terracotta
fill 282 287 241 282 292 241 minecraft:brown_terracotta
fill 282 287 247 282 292 247 minecraft:brown_terracotta
fill 283 287 259 283 287 262 minecraft:white_wool
fill 285 287 228 285 292 228 minecraft:brown_terracotta
setblock 286 287 228 minecraft:gray_terracotta
fill 286 287 258 286 289 258 minecraft:white_wool
fill 287 287 228 296 289 228 minecraft:brown_terracotta
fill 287 287 259 287 289 259 minecraft:white_wool
fill 292 287 270 292 290 270 minecraft:brown_terracotta
fill 293 287 230 294 290 232 minecraft:gray_wool
fill 295 287 231 295 289 232 minecraft:gray_wool
fill 302 287 270 302 292 270 minecraft:brown_terracotta
setblock 303 287 270 minecraft:light_gray_terracotta
setblock 304 287 270 minecraft:gray_terracotta
fill 305 287 270 313 288 270 minecraft:brown_terracotta
fill 311 287 228 311 293 228 minecraft:brown_terracotta
setblock 312 287 228 minecraft:light_gray_terracotta
fill 313 287 228 313 292 228 minecraft:brown_terracotta
fill 316 287 270 316 289 270 minecraft:brown_terracotta
fill 320 287 242 321 289 243 minecraft:gray_wool
fill 320 287 245 321 289 246 minecraft:gray_wool
fill 320 287 248 320 288 248 minecraft:white_wool
fill 322 287 243 322 290 245 minecraft:gray_wool
fill 323 287 244 323 290 244 minecraft:gray_wool
fill 323 287 249 323 289 249 minecraft:white_wool
fill 323 287 254 323 288 254 minecraft:white_wool
fill 323 287 270 323 289 270 minecraft:brown_terracotta
fill 324 287 229 324 290 231 minecraft:brown_terracotta
setblock 324 287 232 minecraft:orange_terracotta
fill 324 287 233 324 288 245 minecraft:brown_terracotta
fill 324 287 251 324 292 251 minecraft:brown_terracotta
setblock 324 287 252 minecraft:light_gray_terracotta
fill 282 288 228 282 289 231 minecraft:brown_terracotta
fill 282 288 232 282 289 232 minecraft:orange_terracotta
fill 282 288 233 282 292 233 minecraft:brown_terracotta
fill 282 288 242 282 289 245 minecraft:brown_terracotta
setblock 282 288 246 minecraft:light_gray_terracotta
fill 282 288 248 282 288 261 minecraft:brown_terracotta
setblock 282 288 262 minecraft:orange_terracotta
fill 282 288 263 282 290 270 minecraft:brown_terracotta
fill 283 288 228 283 292 228 minecraft:brown_terracotta
fill 283 288 259 283 289 261 minecraft:white_wool
fill 283 288 270 285 288 270 minecraft:brown_terracotta
setblock 284 288 228 minecraft:gray_terracotta
setblock 286 288 228 minecraft:brown_terracotta
setblock 286 288 270 minecraft:gray_terracotta
fill 287 288 258 287 289 258 minecraft:white_wool
fill 292 288 231 292 289 231 minecraft:gray_wool
setblock 294 288 233 minecraft:gray_wool
fill 295 288 230 295 289 230 minecraft:gray_wool
fill 296 288 231 296 289 231 minecraft:gray_wool
fill 296 288 232 296 300 232 minecraft:basalt
fill 303 288 270 304 289 270 minecraft:brown_terracotta
setblock 312 288 228 minecraft:brown_terracotta
setblock 317 288 270 minecraft:gray_terracotta
fill 318 288 270 322 288 270 minecraft:brown_terracotta
fill 319 288 243 319 289 245 minecraft:gray_wool
fill 322 288 242 322 289 242 minecraft:gray_wool
fill 322 288 246 322 289 246 minecraft:gray_wool
fill 323 288 243 323 289 243 minecraft:gray_wool
fill 323 288 245 323 290 245 minecraft:gray_wool
fill 324 288 232 324 289 232 minecraft:brown_terracotta
fill 324 288 252 324 290 252 minecraft:brown_terracotta
fill 324 288 254 324 289 257 minecraft:brown_terracotta
setblock 324 288 258 minecraft:orange_terracotta
fill 324 288 259 324 288 267 minecraft:brown_terracotta
setblock 282 289 234 minecraft:light_gray_terracotta
fill 282 289 235 282 289 240 minecraft:brown_terracotta
fill 282 289 246 282 292 246 minecraft:brown_terracotta
fill 282 289 248 282 290 258 minecraft:brown_terracotta
setblock 282 289 259 minecraft:orange_terracotta
setblock 282 289 260 minecraft:light_gray_terracotta
fill 282 289 261 282 292 262 minecraft:brown_terracotta
fill 283 289 270 283 290 270 minecraft:gray_concrete
fill 284 289 228 284 293 228 minecraft:brown_terracotta
fill 284 289 259 285 289 259 minecraft:white_wool
setblock 284 289 261 minecraft:white_wool
fill 284 289 270 286 292 270 minecraft:brown_terracotta
setblock 285 289 258 minecraft:white_wool
setblock 285 289 262 minecraft:white_wool
setblock 286 289 228 minecraft:gray_terracotta
setblock 287 289 260 minecraft:white_wool
fill 288 289 266 290 293 269 minecraft:gray_wool
fill 289 289 265 290 293 265 minecraft:gray_wool
fill 291 289 266 291 294 266 minecraft:gray_wool
setblock 293 289 270 minecraft:gray_terracotta
fill 294 289 270 297 290 270 minecraft:brown_terracotta
setblock 298 289 270 minecraft:gray_concrete
fill 299 289 228 300 289 228 minecraft:gray_concrete
fill 299 289 270 301 290 270 minecraft:brown_terracotta
fill 301 289 228 303 292 228 minecraft:brown_terracotta
fill 304 289 228 305 289 228 minecraft:gray_concrete
fill 305 289 270 308 289 270 minecraft:brown_terracotta
fill 306 289 228 310 292 228 minecraft:brown_terracotta
fill 309 289 238 310 296 239 minecraft:blackstone
setblock 309 289 270 minecraft:gray_concrete
fill 310 289 270 313 289 270 minecraft:brown_terracotta
setblock 312 289 228 minecraft:gray_terracotta
fill 314 289 228 320 290 228 minecraft:brown_terracotta
fill 317 289 270 321 289 270 minecraft:brown_terracotta
setblock 319 289 250 minecraft:white_wool
fill 321 289 228 321 290 228 minecraft:gray_terracotta
setblock 321 289 248 minecraft:white_wool
fill 322 289 228 324 292 228 minecraft:brown_terracotta
setblock 322 289 270 minecraft:light_gray_terracotta
fill 324 289 233 324 292 236 minecraft:brown_terracotta
setblock 324 289 237 minecraft:gray_concrete
fill 324 289 238 324 292 238 minecraft:brown_terracotta
setblock 324 289 239 minecraft:gray_concrete
fill 324 289 240 324 292 244 minecraft:brown_terracotta
setblock 324 289 245 minecraft:light_gray_terracotta
fill 324 289 246 324 289 248 minecraft:brown_terracotta
fill 324 289 249 324 289 250 minecraft:gray_concrete
fill 324 289 258 324 292 258 minecraft:brown_terracotta
setblock 324 289 259 minecraft:gray_terracotta
fill 324 289 260 324 290 267 minecraft:brown_terracotta
fill 282 290 228 282 290 229 minecraft:gray_concrete
setblock 282 290 230 minecraft:light_gray_terracotta
fill 282 290 231 282 292 231 minecraft:brown_terracotta
setblock 282 290 232 minecraft:gray_concrete
setblock 282 290 234 minecraft:gray_concrete
fill 282 290 235 282 290 239 minecraft:brown_terracotta
setblock 282 290 240 minecraft:gray_concrete
setblock 282 290 242 minecraft:brown_terracotta
fill 282 290 243 282 290 244 minecraft:gray_concrete
setblock 282 290 245 minecraft:brown_terracotta
fill 282 290 259 282 290 260 minecraft:brown_terracotta
fill 285 290 260 285 290 261 minecraft:white_wool
fill 286 290 228 290 291 228 minecraft:brown_terracotta
fill 286 290 267 287 293 267 minecraft:gray_wool
fill 287 290 266 287 293 266 minecraft:gray_wool
fill 287 290 268 287 293 269 minecraft:gray_wool
setblock 287 290 270 minecraft:orange_terracotta
fill 288 290 265 288 293 265 minecraft:gray_wool
setblock 288 290 270 minecraft:gray_concrete
fill 289 290 270 291 290 270 minecraft:brown_terracotta
fill 291 290 228 292 290 228 minecraft:gray_concrete
fill 291 290 265 291 292 265 minecraft:gray_wool
fill 291 290 267 291 293 269 minecraft:gray_wool
fill 293 290 228 297 292 228 minecraft:brown_terracotta
fill 293 290 270 293 292 270 minecraft:brown_terracotta
setblock 295 290 231 minecraft:gray_wool
fill 296 290 231 296 300 231 minecraft:basalt
setblock 298 290 228 minecraft:gray_concrete
fill 298 290 270 298 294 270 minecraft:brown_terracotta
fill 299 290 228 300 292 228 minecraft:brown_terracotta
fill 303 290 270 303 293 270 minecraft:brown_terracotta
setblock 304 290 228 minecraft:gray_concrete
setblock 304 290 270 minecraft:gray_concrete
fill 305 290 228 305 292 228 minecraft:brown_terracotta
fill 305 290 270 306 290 270 minecraft:brown_terracotta
setblock 307 290 270 minecraft:gray_concrete
fill 308 290 270 309 292 270 minecraft:brown_terracotta
setblock 310 290 270 minecraft:gray_concrete
fill 311 290 270 313 291 270 minecraft:brown_terracotta
fill 312 290 228 312 292 228 minecraft:brown_terracotta
setblock 316 290 270 minecraft:gray_concrete
fill 317 290 270 318 292 270 minecraft:brown_terracotta
fill 319 290 244 319 290 245 minecraft:gray_wool
setblock 319 290 270 minecraft:gray_terracotta
fill 320 290 243 321 290 243 minecraft:gray_wool
fill 320 290 245 321 290 245 minecraft:gray_wool
fill 320 290 250 321 290 250 minecraft:white_wool
fill 320 290 252 322 290 252 minecraft:white_wool
fill 320 290 270 321 290 270 minecraft:brown_terracotta
setblock 321 290 242 minecraft:gray_wool
setblock 322 290 270 minecraft:gray_terracotta
setblock 323 290 270 minecraft:gray_concrete
fill 324 290 232 324 291 232 minecraft:gray_concrete
fill 324 290 237 324 293 237 minecraft:brown_terracotta
fill 324 290 239 324 292 239 minecraft:brown_terracotta
setblock 324 290 245 minecraft:brown_terracotta
setblock 324 290 246 minecraft:gray_concrete
fill 324 290 247 324 292 249 minecraft:brown_terracotta
setblock 324 290 250 minecraft:light_gray_terracotta
setblock 324 290 253 minecraft:gray_concrete
fill 324 290 254 324 290 256 minecraft:brown_terracotta
setblock 324 290 257 minecraft:gray_concrete
fill 324 290 259 324 292 259 minecraft:brown_terracotta
fill 282 291 228 282 292 230 minecraft:brown_terracotta
setblock 282 291 232 minecraft:light_gray_terracotta
fill 282 291 234 282 292 235 minecraft:brown_terracotta
setblock 282 291 236 minecraft:orange_terracotta
fill 282 291 237 282 292 240 minecraft:brown_terracotta
setblock 282 291 242 minecraft:light_gray_terracotta
fill 282 291 243 282 292 244 minecraft:brown_terracotta
setblock 282 291 245 minecraft:gray_concrete
setblock 282 291 248 minecraft:gray_terracotta
fill 282 291 249 282 292 258 minecraft:brown_terracotta
setblock 282 291 259 minecraft:gray_concrete
fill 282 291 260 282 293 260 minecraft:brown_terracotta
fill 282 291 263 282 292 265 minecraft:brown_terracotta
setblock 282 291 266 minecraft:gray_concrete
fill 282 291 267 282 292 267 minecraft:brown_terracotta
setblock 282 291 268 minecraft:gray_concrete
fill 282 291 269 282 292 269 minecraft:brown_terracotta
setblock 282 291 270 minecraft:gray_concrete
fill 283 291 270 283 292 270 minecraft:brown_terracotta
setblock 285 291 231 minecraft:light[level=12]
fill 285 291 238 285 291 239 minecraft:light[level=12]
setblock 285 291 245 minecraft:light[level=12]
setblock 285 291 247 minecraft:light[level=12]
setblock 285 291 252 minecraft:light[level=12]
setblock 285 291 255 minecraft:light[level=12]
setblock 285 291 259 minecraft:light[level=12]
setblock 285 291 263 minecraft:light[level=12]
setblock 285 291 266 minecraft:light[level=12]
fill 286 291 266 286 292 266 minecraft:gray_wool
fill 286 291 268 286 292 268 minecraft:gray_wool
fill 287 291 265 287 293 265 minecraft:gray_wool
fill 287 291 270 288 292 270 minecraft:brown_terracotta
fill 288 291 264 289 292 264 minecraft:gray_wool
fill 289 291 230 291 295 232 minecraft:white_wool
fill 289 291 270 290 291 270 minecraft:gray_wool
fill 290 291 229 290 295 229 minecraft:white_wool
fill 291 291 228 292 292 228 minecraft:brown_terracotta
fill 291 291 270 291 292 270 minecraft:brown_terracotta
fill 292 291 231 292 295 232 minecraft:white_wool
setblock 292 291 238 minecraft:light[level=12]
setblock 292 291 245 minecraft:light[level=12]
setblock 292 291 252 minecraft:light[level=12]
setblock 292 291 259 minecraft:light[level=12]
fill 292 291 266 292 292 269 minecraft:gray_wool
setblock 292 291 270 minecraft:gray_concrete
setblock 293 291 231 minecraft:light[level=12]
setblock 293 291 239 minecraft:light[level=12]
setblock 293 291 247 minecraft:light[level=12]
setblock 293 291 255 minecraft:light[level=12]
setblock 293 291 263 minecraft:light[level=12]
fill 294 291 270 296 292 270 minecraft:brown_terracotta
setblock 297 291 270 minecraft:gray_concrete
fill 298 291 228 298 292 228 minecraft:brown_terracotta
setblock 299 291 238 minecraft:light[level=12]
setblock 299 291 245 minecraft:light[level=12]
setblock 299 291 252 minecraft:light[level=12]
setblock 299 291 259 minecraft:light[level=12]
setblock 299 291 266 minecraft:light[level=12]
setblock 299 291 270 minecraft:orange_terracotta
fill 300 291 270 301 292 270 minecraft:brown_terracotta
setblock 301 291 231 minecraft:light[level=12]
setblock 301 291 239 minecraft:light[level=12]
setblock 301 291 247 minecraft:light[level=12]
setblock 301 291 255 minecraft:light[level=12]
setblock 301 291 263 minecraft:light[level=12]
fill 304 291 228 304 292 228 minecraft:brown_terracotta
fill 304 291 270 304 292 270 minecraft:brown_terracotta
setblock 305 291 270 minecraft:orange_terracotta
setblock 306 291 231 minecraft:light[level=12]
setblock 306 291 238 minecraft:light[level=12]
setblock 306 291 245 minecraft:light[level=12]
setblock 306 291 252 minecraft:light[level=12]
setblock 306 291 259 minecraft:light[level=12]
setblock 306 291 266 minecraft:light[level=12]
fill 306 291 270 307 292 270 minecraft:brown_terracotta
fill 308 291 239 308 296 239 minecraft:blackstone
setblock 309 291 231 minecraft:light[level=12]
fill 309 291 240 310 296 240 minecraft:blackstone
setblock 309 291 247 minecraft:light[level=12]
setblock 309 291 255 minecraft:light[level=12]
setblock 309 291 263 minecraft:light[level=12]
fill 310 291 237 310 296 237 minecraft:blackstone
fill 310 291 270 310 292 270 minecraft:brown_terracotta
fill 311 291 238 311 296 239 minecraft:blackstone
setblock 313 291 231 minecraft:light[level=12]
setblock 313 291 238 minecraft:light[level=12]
setblock 313 291 245 minecraft:light[level=12]
setblock 313 291 252 minecraft:light[level=12]
setblock 313 291 259 minecraft:light[level=12]
setblock 313 291 266 minecraft:light[level=12]
fill 314 291 228 317 292 228 minecraft:brown_terracotta
fill 316 291 270 316 292 270 minecraft:brown_terracotta
setblock 317 291 231 minecraft:light[level=12]
setblock 317 291 239 minecraft:light[level=12]
setblock 317 291 247 minecraft:light[level=12]
setblock 317 291 255 minecraft:light[level=12]
setblock 317 291 263 minecraft:light[level=12]
setblock 318 291 228 minecraft:orange_terracotta
fill 319 291 228 319 292 228 minecraft:brown_terracotta
fill 319 291 270 320 291 270 minecraft:gray_concrete
setblock 320 291 228 minecraft:gray_concrete
setblock 320 291 231 minecraft:light[level=12]
setblock 320 291 238 minecraft:light[level=12]
setblock 320 291 245 minecraft:light[level=12]
setblock 320 291 252 minecraft:light[level=12]
fill 320 291 254 320 297 254 minecraft:white_wool
setblock 320 291 259 minecraft:light[level=12]
setblock 320 291 266 minecraft:light[level=12]
setblock 321 291 228 minecraft:light_gray_terracotta
fill 321 291 253 321 297 253 minecraft:white_wool
fill 321 291 270 323 291 270 minecraft:brown_terracotta
setblock 322 291 251 minecraft:white_wool
fill 322 291 255 322 297 255 minecraft:white_wool
fill 324 291 229 324 292 230 minecraft:brown_terracotta
setblock 324 291 231 minecraft:orange_terracotta
setblock 324 291 245 minecraft:gray_concrete
fill 324 291 246 324 292 246 minecraft:brown_terracotta
fill 324 291 250 324 292 250 minecraft:brown_terracotta
setblock 324 291 252 minecraft:light_gray_terracotta
fill 324 291 253 324 293 254 minecraft:brown_terracotta
setblock 324 291 255 minecraft:light_gray_terracotta
fill 324 291 256 324 292 257 minecraft:brown_terracotta
fill 324 291 260 324 292 263 minecraft:brown_terracotta
setblock 324 291 264 minecraft:gray_concrete
fill 324 291 265 324 291 267 minecraft:brown_terracotta
setblock 282 292 232 minecraft:brown_terracotta
fill 282 292 236 282 293 236 minecraft:brown_terracotta
setblock 282 292 242 minecraft:gray_terracotta
setblock 282 292 245 minecraft:brown_terracotta
setblock 282 292 248 minecraft:brown_terracotta
setblock 282 292 259 minecraft:brown_terracotta
setblock 282 292 266 minecraft:brown_terracotta
fill 282 292 268 282 293 268 minecraft:brown_terracotta
setblock 282 292 270 minecraft:brown_terracotta
fill 286 292 228 288 292 228 minecraft:brown_terracotta
fill 288 292 229 288 294 233 minecraft:white_wool
fill 289 292 228 289 294 229 minecraft:white_wool
fill 289 292 233 291 295 233 minecraft:white_wool
setblock 289 292 270 minecraft:brown_terracotta
fill 290 292 228 290 294 228 minecraft:white_wool
setblock 290 292 270 minecraft:gray_wool
fill 291 292 229 291 295 229 minecraft:white_wool
fill 292 292 230 292 296 230 minecraft:white_wool
setblock 292 292 270 minecraft:brown_terracotta
fill 293 292 231 293 294 231 minecraft:white_wool
setblock 297 292 270 minecraft:brown_terracotta
setblock 299 292 270 minecraft:brown_terracotta
setblock 305 292 270 minecraft:brown_terracotta
fill 308 292 240 308 296 240 minecraft:blackstone
fill 311 292 237 311 296 237 minecraft:blackstone
fill 311 292 240 311 298 240 minecraft:blackstone
fill 311 292 270 312 292 270 minecraft:brown_terracotta
setblock 313 292 270 minecraft:orange_terracotta
setblock 318 292 228 minecraft:brown_terracotta
fill 319 292 254 319 296 255 minecraft:white_wool
fill 319 292 270 321 292 270 minecraft:brown_terracotta
fill 320 292 228 321 292 228 minecraft:brown_terracotta
fill 320 292 253 320 297 253 minecraft:white_wool
fill 320 292 255 321 297 255 minecraft:white_wool
fill 321 292 252 322 296 252 minecraft:white_wool
fill 321 292 254 322 297 254 minecraft:white_wool
fill 322 292 253 322 297 253 minecraft:white_wool
fill 322 292 256 322 296 256 minecraft:white_wool
setblock 322 292 270 minecraft:gray_terracotta
fill 323 292 255 323 296 255 minecraft:white_wool
setblock 323 292 270 minecraft:brown_terracotta
fill 324 292 231 324 292 232 minecraft:brown_terracotta
setblock 324 292 245 minecraft:brown_terracotta
schedule function dropper:buildpart/54_6 1t
