setblock 163 90 278 minecraft:packed_ice
fill 163 90 284 163 90 286 minecraft:packed_ice
setblock 164 90 276 minecraft:snow_block
fill 164 90 277 164 91 277 minecraft:packed_ice
setblock 164 90 316 minecraft:snow_block
fill 165 90 275 165 91 275 minecraft:blue_ice
fill 165 90 276 165 92 276 minecraft:packed_ice
setblock 165 90 278 minecraft:light[level=12]
setblock 165 90 285 minecraft:light[level=12]
setblock 165 90 292 minecraft:light[level=12]
setblock 165 90 299 minecraft:light[level=12]
setblock 165 90 306 minecraft:light[level=12]
setblock 165 90 313 minecraft:light[level=12]
setblock 165 90 315 minecraft:snow_block
fill 165 90 316 165 92 316 minecraft:packed_ice
setblock 166 90 315 minecraft:packed_ice
setblock 166 90 317 minecraft:blue_ice
fill 170 90 317 170 93 317 minecraft:packed_ice
setblock 171 90 317 minecraft:blue_ice
setblock 172 90 278 minecraft:light[level=12]
setblock 172 90 285 minecraft:light[level=12]
setblock 172 90 292 minecraft:light[level=12]
setblock 172 90 299 minecraft:light[level=12]
setblock 172 90 306 minecraft:light[level=12]
setblock 172 90 313 minecraft:light[level=12]
fill 172 90 317 172 93 317 minecraft:packed_ice
setblock 173 90 317 minecraft:blue_ice
fill 174 90 275 174 93 275 minecraft:packed_ice
setblock 175 90 275 minecraft:blue_ice
setblock 177 90 275 minecraft:blue_ice
fill 177 90 314 177 91 316 minecraft:blue_ice
fill 178 90 275 181 90 275 minecraft:packed_ice
setblock 178 90 277 minecraft:snow_block
fill 178 90 314 179 91 314 minecraft:blue_ice
fill 178 90 316 179 91 316 minecraft:blue_ice
setblock 179 90 276 minecraft:snow_block
fill 179 90 277 180 92 277 minecraft:packed_ice
setblock 179 90 278 minecraft:light[level=12]
setblock 179 90 285 minecraft:light[level=12]
setblock 179 90 301 minecraft:snow_block
fill 179 90 302 179 91 302 minecraft:packed_ice
setblock 179 90 306 minecraft:light[level=12]
setblock 179 90 313 minecraft:light[level=12]
fill 179 90 315 179 91 315 minecraft:blue_ice
fill 180 90 276 180 93 276 minecraft:packed_ice
fill 180 90 278 180 90 279 minecraft:packed_ice
setblock 180 90 280 minecraft:snow_block
fill 180 90 281 180 93 281 minecraft:packed_ice
setblock 180 90 284 minecraft:packed_ice
setblock 180 90 285 minecraft:snow_block
fill 180 90 286 180 92 287 minecraft:packed_ice
setblock 180 90 295 minecraft:snow_block
fill 180 90 296 180 91 296 minecraft:packed_ice
setblock 180 90 300 minecraft:snow_block
fill 180 90 301 180 93 301 minecraft:packed_ice
setblock 180 90 305 minecraft:snow_block
fill 180 90 306 180 91 306 minecraft:packed_ice
setblock 180 90 316 minecraft:packed_ice
setblock 181 90 279 minecraft:snow_block
fill 181 90 280 181 93 280 minecraft:packed_ice
setblock 181 90 284 minecraft:snow_block
fill 181 90 285 181 93 285 minecraft:packed_ice
setblock 181 90 289 minecraft:snow_block
fill 181 90 290 181 93 290 minecraft:packed_ice
setblock 181 90 294 minecraft:snow_block
fill 181 90 295 181 93 295 minecraft:packed_ice
setblock 181 90 299 minecraft:snow_block
fill 181 90 300 181 93 300 minecraft:packed_ice
setblock 181 90 304 minecraft:snow_block
fill 181 90 305 181 93 305 minecraft:packed_ice
setblock 181 90 308 minecraft:packed_ice
setblock 182 90 278 minecraft:snow_block
fill 182 90 279 182 93 279 minecraft:packed_ice
setblock 182 90 283 minecraft:snow_block
fill 182 90 284 182 93 284 minecraft:packed_ice
setblock 182 90 288 minecraft:snow_block
fill 182 90 289 182 93 289 minecraft:packed_ice
setblock 182 90 293 minecraft:snow_block
fill 182 90 294 182 93 294 minecraft:packed_ice
setblock 182 90 298 minecraft:snow_block
fill 182 90 299 182 93 299 minecraft:packed_ice
setblock 182 90 303 minecraft:snow_block
fill 182 90 304 182 93 304 minecraft:packed_ice
setblock 182 90 308 minecraft:snow_block
fill 182 90 309 182 93 309 minecraft:packed_ice
setblock 183 90 277 minecraft:blue_ice
setblock 183 90 281 minecraft:blue_ice
setblock 183 90 285 minecraft:blue_ice
fill 183 90 296 183 91 298 minecraft:packed_ice
fill 183 90 299 183 91 299 minecraft:blue_ice
fill 183 90 302 183 93 303 minecraft:packed_ice
setblock 183 90 304 minecraft:blue_ice
setblock 183 90 308 minecraft:light_blue_concrete
fill 141 91 275 141 92 275 minecraft:blue_ice
fill 141 91 291 141 93 291 minecraft:packed_ice
setblock 141 91 292 minecraft:blue_ice
fill 141 91 293 141 93 295 minecraft:packed_ice
setblock 141 91 307 minecraft:blue_ice
fill 141 91 308 142 93 308 minecraft:packed_ice
setblock 142 91 277 minecraft:snow_block
fill 142 91 278 142 94 278 minecraft:packed_ice
setblock 142 91 282 minecraft:snow_block
fill 142 91 283 142 94 283 minecraft:packed_ice
setblock 142 91 287 minecraft:snow_block
fill 142 91 288 142 94 288 minecraft:packed_ice
setblock 142 91 292 minecraft:snow_block
fill 142 91 293 142 93 293 minecraft:packed_ice
setblock 142 91 297 minecraft:snow_block
fill 142 91 298 142 93 298 minecraft:packed_ice
setblock 142 91 302 minecraft:snow_block
fill 142 91 303 142 94 303 minecraft:packed_ice
setblock 142 91 306 minecraft:packed_ice
setblock 142 91 307 minecraft:snow_block
setblock 142 91 312 minecraft:snow_block
setblock 142 91 313 minecraft:packed_ice
setblock 143 91 275 minecraft:packed_ice
setblock 143 91 276 minecraft:snow_block
fill 143 91 277 143 94 277 minecraft:packed_ice
setblock 143 91 281 minecraft:snow_block
fill 143 91 282 143 94 282 minecraft:packed_ice
setblock 143 91 286 minecraft:snow_block
fill 143 91 287 143 94 287 minecraft:packed_ice
setblock 143 91 297 minecraft:packed_ice
setblock 143 91 301 minecraft:snow_block
fill 143 91 302 143 92 302 minecraft:packed_ice
setblock 143 91 306 minecraft:snow_block
setblock 143 91 316 minecraft:snow_block
fill 143 91 317 143 93 317 minecraft:packed_ice
fill 144 91 276 147 91 276 minecraft:packed_ice
setblock 144 91 280 minecraft:snow_block
fill 144 91 281 144 94 281 minecraft:packed_ice
setblock 144 91 285 minecraft:snow_block
fill 144 91 286 144 92 286 minecraft:packed_ice
fill 144 91 316 144 92 316 minecraft:packed_ice
fill 145 91 275 145 93 275 minecraft:packed_ice
setblock 145 91 279 minecraft:snow_block
setblock 145 91 280 minecraft:packed_ice
setblock 146 91 278 minecraft:snow_block
setblock 146 91 317 minecraft:blue_ice
setblock 147 91 277 minecraft:snow_block
setblock 147 91 278 minecraft:packed_ice
setblock 147 91 307 minecraft:blue_ice
setblock 148 91 276 minecraft:snow_block
fill 148 91 277 151 91 277 minecraft:packed_ice
setblock 148 91 316 minecraft:snow_block
fill 149 91 276 149 93 276 minecraft:packed_ice
setblock 151 91 275 minecraft:blue_ice
setblock 152 91 277 minecraft:snow_block
setblock 153 91 276 minecraft:snow_block
setblock 153 91 277 minecraft:packed_ice
setblock 153 91 316 minecraft:snow_block
fill 154 91 276 154 93 276 minecraft:packed_ice
fill 154 91 316 154 92 316 minecraft:packed_ice
fill 155 91 317 155 93 317 minecraft:packed_ice
setblock 156 91 277 minecraft:packed_ice
setblock 157 91 277 minecraft:snow_block
fill 158 91 275 158 93 275 minecraft:packed_ice
setblock 158 91 276 minecraft:snow_block
fill 158 91 277 158 93 277 minecraft:packed_ice
fill 158 91 285 159 92 286 minecraft:blue_ice
setblock 158 91 316 minecraft:snow_block
fill 158 91 317 158 93 317 minecraft:packed_ice
fill 159 91 276 159 94 276 minecraft:packed_ice
setblock 159 91 315 minecraft:snow_block
fill 159 91 316 159 94 316 minecraft:packed_ice
fill 160 91 315 160 94 315 minecraft:packed_ice
setblock 161 91 278 minecraft:snow_block
setblock 161 91 317 minecraft:blue_ice
setblock 162 91 277 minecraft:snow_block
setblock 162 91 278 minecraft:packed_ice
fill 162 91 317 162 93 317 minecraft:packed_ice
setblock 163 91 276 minecraft:snow_block
fill 163 91 277 163 92 277 minecraft:packed_ice
setblock 163 91 316 minecraft:snow_block
setblock 163 91 317 minecraft:blue_ice
fill 164 91 276 164 92 276 minecraft:packed_ice
setblock 164 91 315 minecraft:snow_block
fill 164 91 316 164 93 317 minecraft:packed_ice
fill 165 91 317 166 93 317 minecraft:packed_ice
setblock 168 91 275 minecraft:blue_ice
fill 171 91 317 171 93 317 minecraft:packed_ice
fill 173 91 317 173 93 317 minecraft:packed_ice
fill 175 91 275 175 93 275 minecraft:packed_ice
fill 177 91 275 180 93 275 minecraft:packed_ice
setblock 178 91 276 minecraft:snow_block
setblock 178 91 277 minecraft:packed_ice
fill 178 91 313 178 92 313 minecraft:blue_ice
fill 179 91 276 179 94 276 minecraft:packed_ice
setblock 179 91 301 minecraft:packed_ice
setblock 180 91 278 minecraft:packed_ice
setblock 180 91 279 minecraft:snow_block
fill 180 91 280 180 94 280 minecraft:packed_ice
setblock 180 91 284 minecraft:snow_block
fill 180 91 285 180 94 285 minecraft:packed_ice
setblock 180 91 288 minecraft:packed_ice
setblock 180 91 295 minecraft:packed_ice
setblock 180 91 299 minecraft:snow_block
fill 180 91 300 180 93 300 minecraft:packed_ice
setblock 180 91 304 minecraft:snow_block
fill 180 91 305 180 93 305 minecraft:packed_ice
setblock 181 91 275 minecraft:blue_ice
setblock 181 91 278 minecraft:snow_block
fill 181 91 279 181 94 279 minecraft:packed_ice
setblock 181 91 283 minecraft:snow_block
fill 181 91 284 181 94 284 minecraft:packed_ice
setblock 181 91 288 minecraft:snow_block
fill 181 91 289 181 94 289 minecraft:packed_ice
setblock 181 91 293 minecraft:snow_block
fill 181 91 294 181 93 294 minecraft:packed_ice
setblock 181 91 298 minecraft:snow_block
fill 181 91 299 181 94 299 minecraft:packed_ice
setblock 181 91 303 minecraft:snow_block
fill 181 91 304 181 94 304 minecraft:packed_ice
setblock 181 91 308 minecraft:snow_block
fill 181 91 317 181 93 317 minecraft:packed_ice
setblock 182 91 277 minecraft:snow_block
fill 182 91 278 182 94 278 minecraft:packed_ice
setblock 182 91 282 minecraft:snow_block
fill 182 91 283 182 94 283 minecraft:packed_ice
setblock 182 91 287 minecraft:snow_block
fill 182 91 288 182 94 288 minecraft:packed_ice
setblock 182 91 292 minecraft:snow_block
fill 182 91 293 182 94 293 minecraft:packed_ice
setblock 182 91 297 minecraft:snow_block
fill 182 91 298 182 94 298 minecraft:packed_ice
setblock 182 91 302 minecraft:snow_block
fill 182 91 303 182 94 303 minecraft:packed_ice
setblock 182 91 307 minecraft:snow_block
fill 182 91 308 183 93 308 minecraft:packed_ice
fill 183 91 277 183 93 277 minecraft:packed_ice
setblock 183 91 280 minecraft:blue_ice
fill 183 91 281 183 93 281 minecraft:packed_ice
fill 183 91 285 183 93 285 minecraft:packed_ice
setblock 183 91 289 minecraft:blue_ice
setblock 183 91 290 minecraft:white_concrete
fill 183 91 291 183 93 292 minecraft:packed_ice
setblock 183 91 301 minecraft:blue_ice
fill 183 91 304 183 93 304 minecraft:packed_ice
fill 183 91 311 183 92 311 minecraft:blue_ice
setblock 183 91 313 minecraft:blue_ice
setblock 141 92 277 minecraft:blue_ice
setblock 141 92 279 minecraft:blue_ice
setblock 141 92 281 minecraft:blue_ice
fill 141 92 290 141 93 290 minecraft:packed_ice
fill 141 92 292 142 93 292 minecraft:packed_ice
setblock 141 92 297 minecraft:blue_ice
setblock 141 92 299 minecraft:blue_ice
fill 141 92 307 142 92 307 minecraft:packed_ice
fill 141 92 317 141 94 317 minecraft:packed_ice
setblock 142 92 276 minecraft:snow_block
fill 142 92 277 142 95 277 minecraft:packed_ice
setblock 142 92 281 minecraft:snow_block
fill 142 92 282 142 95 282 minecraft:packed_ice
setblock 142 92 286 minecraft:snow_block
fill 142 92 287 142 95 287 minecraft:packed_ice
setblock 142 92 291 minecraft:snow_block
setblock 142 92 296 minecraft:snow_block
fill 142 92 297 142 93 297 minecraft:packed_ice
setblock 142 92 301 minecraft:snow_block
fill 142 92 302 142 95 302 minecraft:packed_ice
setblock 142 92 306 minecraft:snow_block
setblock 142 92 311 minecraft:snow_block
setblock 142 92 315 minecraft:packed_ice
setblock 142 92 316 minecraft:snow_block
setblock 142 92 317 minecraft:blue_ice
setblock 143 92 275 minecraft:blue_ice
fill 143 92 276 146 92 276 minecraft:packed_ice
setblock 143 92 280 minecraft:snow_block
fill 143 92 281 143 95 281 minecraft:packed_ice
setblock 143 92 285 minecraft:snow_block
fill 143 92 286 143 95 286 minecraft:packed_ice
setblock 143 92 300 minecraft:snow_block
setblock 143 92 301 minecraft:packed_ice
setblock 143 92 305 minecraft:snow_block
setblock 143 92 306 minecraft:packed_ice
fill 143 92 316 143 93 316 minecraft:packed_ice
setblock 144 92 279 minecraft:snow_block
fill 144 92 280 144 94 280 minecraft:packed_ice
setblock 144 92 284 minecraft:snow_block
fill 144 92 285 144 93 285 minecraft:packed_ice
setblock 145 92 278 minecraft:snow_block
setblock 146 92 277 minecraft:snow_block
setblock 146 92 278 minecraft:packed_ice
fill 146 92 317 146 93 317 minecraft:packed_ice
setblock 147 92 275 minecraft:blue_ice
setblock 147 92 276 minecraft:snow_block
fill 147 92 277 148 92 277 minecraft:packed_ice
fill 148 92 276 148 93 276 minecraft:packed_ice
setblock 149 92 275 minecraft:blue_ice
fill 150 92 275 151 93 275 minecraft:packed_ice
setblock 152 92 276 minecraft:snow_block
fill 153 92 276 153 93 276 minecraft:packed_ice
fill 154 92 275 154 93 275 minecraft:packed_ice
setblock 154 92 317 minecraft:blue_ice
setblock 156 92 277 minecraft:snow_block
setblock 157 92 275 minecraft:blue_ice
setblock 157 92 276 minecraft:snow_block
setblock 157 92 277 minecraft:packed_ice
setblock 157 92 316 minecraft:snow_block
fill 158 92 276 158 95 276 minecraft:packed_ice
setblock 158 92 315 minecraft:snow_block
fill 158 92 316 158 95 316 minecraft:packed_ice
fill 159 92 315 159 95 315 minecraft:packed_ice
setblock 160 92 317 minecraft:blue_ice
setblock 161 92 277 minecraft:snow_block
fill 161 92 317 161 93 317 minecraft:packed_ice
setblock 162 92 276 minecraft:snow_block
setblock 162 92 277 minecraft:packed_ice
setblock 162 92 316 minecraft:snow_block
fill 163 92 276 163 93 276 minecraft:packed_ice
setblock 163 92 315 minecraft:snow_block
fill 163 92 316 163 93 317 minecraft:packed_ice
fill 165 92 275 165 94 275 minecraft:packed_ice
fill 168 92 275 168 93 275 minecraft:packed_ice
setblock 172 92 275 minecraft:blue_ice
setblock 177 92 317 minecraft:blue_ice
fill 178 92 276 178 93 276 minecraft:packed_ice
setblock 178 92 312 minecraft:blue_ice
setblock 178 92 314 minecraft:blue_ice
fill 180 92 279 180 93 279 minecraft:packed_ice
setblock 180 92 283 minecraft:snow_block
fill 180 92 284 180 95 284 minecraft:packed_ice
setblock 180 92 288 minecraft:snow_block
setblock 180 92 298 minecraft:snow_block
fill 180 92 299 180 93 299 minecraft:packed_ice
setblock 180 92 303 minecraft:snow_block
fill 180 92 304 180 94 304 minecraft:packed_ice
fill 181 92 275 181 93 275 minecraft:packed_ice
setblock 181 92 277 minecraft:snow_block
fill 181 92 278 181 95 278 minecraft:packed_ice
setblock 181 92 282 minecraft:snow_block
fill 181 92 283 181 95 283 minecraft:packed_ice
setblock 181 92 287 minecraft:snow_block
fill 181 92 288 181 95 288 minecraft:packed_ice
setblock 181 92 292 minecraft:snow_block
fill 181 92 293 181 94 293 minecraft:packed_ice
setblock 181 92 297 minecraft:snow_block
fill 181 92 298 181 94 298 minecraft:packed_ice
setblock 181 92 302 minecraft:snow_block
fill 181 92 303 181 95 303 minecraft:packed_ice
setblock 181 92 307 minecraft:snow_block
fill 181 92 308 181 93 308 minecraft:packed_ice
setblock 182 92 276 minecraft:snow_block
fill 182 92 277 182 95 277 minecraft:packed_ice
setblock 182 92 281 minecraft:snow_block
fill 182 92 282 182 95 282 minecraft:packed_ice
setblock 182 92 286 minecraft:snow_block
fill 182 92 287 182 95 287 minecraft:packed_ice
setblock 182 92 291 minecraft:snow_block
fill 182 92 292 182 95 292 minecraft:packed_ice
setblock 182 92 296 minecraft:snow_block
fill 182 92 297 183 93 297 minecraft:packed_ice
setblock 182 92 301 minecraft:snow_block
fill 182 92 302 182 95 302 minecraft:packed_ice
setblock 182 92 306 minecraft:snow_block
fill 182 92 307 182 95 307 minecraft:packed_ice
fill 183 92 280 183 93 280 minecraft:packed_ice
fill 183 92 289 183 93 290 minecraft:packed_ice
setblock 183 92 295 minecraft:blue_ice
fill 183 92 296 183 93 296 minecraft:packed_ice
setblock 183 92 298 minecraft:blue_ice
fill 183 92 299 183 93 299 minecraft:packed_ice
setblock 183 92 300 minecraft:white_concrete
fill 183 92 301 183 93 301 minecraft:packed_ice
setblock 183 92 306 minecraft:blue_ice
setblock 183 92 309 minecraft:light_blue_concrete
fill 183 92 313 183 93 313 minecraft:packed_ice
setblock 183 92 314 minecraft:blue_ice
setblock 183 92 316 minecraft:blue_ice
setblock 141 93 275 minecraft:packed_ice
setblock 141 93 277 minecraft:packed_ice
setblock 141 93 279 minecraft:packed_ice
fill 141 93 281 142 93 281 minecraft:packed_ice
setblock 141 93 297 minecraft:packed_ice
setblock 141 93 299 minecraft:packed_ice
setblock 141 93 307 minecraft:white_concrete
fill 142 93 276 145 93 276 minecraft:packed_ice
setblock 142 93 280 minecraft:snow_block
setblock 142 93 285 minecraft:snow_block
fill 142 93 286 142 96 286 minecraft:packed_ice
setblock 142 93 290 minecraft:snow_block
fill 142 93 291 142 96 291 minecraft:packed_ice
setblock 142 93 296 minecraft:packed_ice
setblock 142 93 300 minecraft:snow_block
fill 142 93 301 142 95 301 minecraft:packed_ice
setblock 142 93 305 minecraft:snow_block
fill 142 93 306 142 95 307 minecraft:packed_ice
setblock 142 93 310 minecraft:snow_block
fill 142 93 311 142 96 311 minecraft:packed_ice
fill 142 93 316 142 93 317 minecraft:packed_ice
setblock 143 93 275 minecraft:packed_ice
setblock 143 93 279 minecraft:snow_block
fill 143 93 280 143 96 280 minecraft:packed_ice
setblock 143 93 284 minecraft:snow_block
fill 143 93 285 143 96 285 minecraft:packed_ice
setblock 143 93 304 minecraft:snow_block
setblock 144 93 278 minecraft:snow_block
setblock 144 93 279 minecraft:packed_ice
setblock 144 93 283 minecraft:snow_block
fill 144 93 284 144 94 284 minecraft:packed_ice
setblock 145 93 277 minecraft:snow_block
setblock 146 93 276 minecraft:snow_block
setblock 146 93 277 minecraft:packed_ice
fill 147 93 275 147 94 276 minecraft:packed_ice
fill 149 93 275 149 94 275 minecraft:packed_ice
setblock 154 93 317 minecraft:packed_ice
setblock 156 93 276 minecraft:snow_block
setblock 156 93 316 minecraft:snow_block
fill 157 93 275 157 93 276 minecraft:packed_ice
fill 157 93 316 157 96 316 minecraft:packed_ice
fill 158 93 286 159 93 286 minecraft:blue_ice
setblock 158 93 315 minecraft:packed_ice
setblock 160 93 277 minecraft:snow_block
setblock 160 93 317 minecraft:packed_ice
setblock 161 93 276 minecraft:snow_block
setblock 161 93 316 minecraft:snow_block
setblock 162 93 276 minecraft:packed_ice
fill 162 93 316 162 95 316 minecraft:packed_ice
fill 172 93 275 172 94 275 minecraft:packed_ice
setblock 177 93 317 minecraft:packed_ice
setblock 180 93 277 minecraft:snow_block
setblock 180 93 282 minecraft:snow_block
fill 180 93 283 180 96 283 minecraft:packed_ice
setblock 180 93 286 minecraft:packed_ice
setblock 180 93 287 minecraft:snow_block
fill 180 93 288 180 95 289 minecraft:packed_ice
setblock 180 93 302 minecraft:snow_block
fill 180 93 303 180 94 303 minecraft:packed_ice
setblock 181 93 276 minecraft:snow_block
fill 181 93 277 181 94 277 minecraft:packed_ice
setblock 181 93 281 minecraft:snow_block
fill 181 93 282 181 96 282 minecraft:packed_ice
setblock 181 93 286 minecraft:snow_block
fill 181 93 287 181 96 287 minecraft:packed_ice
setblock 181 93 291 minecraft:snow_block
fill 181 93 292 181 96 292 minecraft:packed_ice
setblock 181 93 296 minecraft:snow_block
fill 181 93 297 181 94 297 minecraft:packed_ice
setblock 181 93 301 minecraft:snow_block
fill 181 93 302 181 96 302 minecraft:packed_ice
setblock 181 93 306 minecraft:snow_block
fill 181 93 307 181 96 307 minecraft:packed_ice
fill 182 93 276 182 96 276 minecraft:packed_ice
setblock 182 93 280 minecraft:snow_block
fill 182 93 281 182 96 281 minecraft:packed_ice
setblock 182 93 285 minecraft:snow_block
fill 182 93 286 182 96 286 minecraft:packed_ice
setblock 182 93 290 minecraft:snow_block
fill 182 93 291 182 96 291 minecraft:packed_ice
setblock 182 93 295 minecraft:snow_block
fill 182 93 296 182 96 296 minecraft:packed_ice
setblock 182 93 300 minecraft:snow_block
fill 182 93 301 182 96 301 minecraft:packed_ice
setblock 182 93 305 minecraft:snow_block
fill 182 93 306 183 93 306 minecraft:packed_ice
setblock 182 93 310 minecraft:snow_block
setblock 183 93 295 minecraft:packed_ice
setblock 183 93 298 minecraft:packed_ice
setblock 183 93 300 minecraft:packed_ice
setblock 183 93 309 minecraft:packed_ice
setblock 183 93 311 minecraft:packed_ice
setblock 183 93 314 minecraft:packed_ice
setblock 183 93 316 minecraft:packed_ice
fill 141 94 275 141 94 303 minecraft:blue_ice
fill 141 94 305 141 94 316 minecraft:blue_ice
fill 142 94 275 146 94 275 minecraft:blue_ice
fill 142 94 276 144 94 276 minecraft:packed_ice
setblock 142 94 279 minecraft:snow_block
fill 142 94 280 142 96 281 minecraft:packed_ice
setblock 142 94 284 minecraft:snow_block
fill 142 94 285 142 97 285 minecraft:packed_ice
setblock 142 94 289 minecraft:snow_block
fill 142 94 290 142 97 290 minecraft:packed_ice
setblock 142 94 299 minecraft:snow_block
setblock 142 94 300 minecraft:packed_ice
setblock 142 94 304 minecraft:snow_block
fill 142 94 305 142 97 305 minecraft:packed_ice
setblock 142 94 308 minecraft:packed_ice
setblock 142 94 309 minecraft:snow_block
fill 142 94 310 142 97 310 minecraft:packed_ice
fill 142 94 317 143 165 317 minecraft:blue_ice
setblock 143 94 278 minecraft:snow_block
fill 143 94 279 143 97 279 minecraft:packed_ice
setblock 143 94 283 minecraft:snow_block
fill 143 94 284 143 97 284 minecraft:packed_ice
setblock 143 94 288 minecraft:snow_block
setblock 144 94 277 minecraft:snow_block
setblock 144 94 282 minecraft:snow_block
setblock 144 94 283 minecraft:packed_ice
setblock 145 94 276 minecraft:snow_block
fill 145 94 317 155 94 317 minecraft:blue_ice
setblock 146 94 276 minecraft:packed_ice
fill 148 94 275 148 165 275 minecraft:blue_ice
fill 150 94 275 162 94 275 minecraft:blue_ice
setblock 155 94 276 minecraft:snow_block
setblock 155 94 316 minecraft:snow_block
fill 156 94 276 157 95 276 minecraft:packed_ice
fill 156 94 316 156 94 317 minecraft:packed_ice
fill 157 94 303 158 95 303 minecraft:white_concrete
fill 157 94 317 158 117 317 minecraft:blue_ice
setblock 159 94 286 minecraft:blue_ice
setblock 160 94 276 minecraft:snow_block
setblock 160 94 316 minecraft:snow_block
fill 160 94 317 177 94 317 minecraft:blue_ice
setblock 161 94 276 minecraft:packed_ice
fill 161 94 316 161 97 316 minecraft:packed_ice
setblock 163 94 275 minecraft:light_blue_concrete
setblock 163 94 316 minecraft:packed_ice
setblock 164 94 275 minecraft:white_concrete
fill 167 94 313 167 95 313 minecraft:packed_ice
fill 168 94 275 170 148 275 minecraft:blue_ice
fill 168 94 312 168 95 312 minecraft:packed_ice
fill 168 94 314 168 95 314 minecraft:packed_ice
fill 169 94 313 169 95 313 minecraft:packed_ice
fill 173 94 275 183 94 275 minecraft:blue_ice
fill 178 94 317 178 95 317 minecraft:packed_ice
fill 179 94 317 179 95 317 minecraft:blue_ice
setblock 180 94 276 minecraft:snow_block
setblock 180 94 281 minecraft:snow_block
fill 180 94 282 180 97 282 minecraft:packed_ice
setblock 180 94 286 minecraft:snow_block
fill 180 94 287 180 97 287 minecraft:packed_ice
setblock 180 94 302 minecraft:packed_ice
fill 180 94 317 180 95 317 minecraft:packed_ice
fill 181 94 276 181 97 276 minecraft:packed_ice
setblock 181 94 280 minecraft:snow_block
fill 181 94 281 181 97 281 minecraft:packed_ice
setblock 181 94 285 minecraft:snow_block
fill 181 94 286 181 97 286 minecraft:packed_ice
setblock 181 94 290 minecraft:snow_block
fill 181 94 291 181 97 291 minecraft:packed_ice
setblock 181 94 296 minecraft:packed_ice
setblock 181 94 300 minecraft:snow_block
fill 181 94 301 181 95 301 minecraft:packed_ice
setblock 181 94 305 minecraft:snow_block
fill 181 94 306 182 96 306 minecraft:packed_ice
setblock 181 94 317 minecraft:blue_ice
setblock 182 94 279 minecraft:snow_block
fill 182 94 280 182 97 280 minecraft:packed_ice
setblock 182 94 284 minecraft:snow_block
fill 182 94 285 182 97 285 minecraft:packed_ice
setblock 182 94 289 minecraft:snow_block
fill 182 94 290 182 97 290 minecraft:packed_ice
setblock 182 94 294 minecraft:snow_block
fill 182 94 295 182 97 295 minecraft:packed_ice
fill 182 94 297 182 95 297 minecraft:packed_ice
setblock 182 94 299 minecraft:snow_block
fill 182 94 300 182 96 300 minecraft:packed_ice
setblock 182 94 304 minecraft:snow_block
fill 182 94 305 182 97 305 minecraft:packed_ice
setblock 182 94 308 minecraft:packed_ice
setblock 182 94 309 minecraft:snow_block
fill 182 94 310 182 97 310 minecraft:packed_ice
fill 183 94 276 183 99 290 minecraft:blue_ice
setblock 183 94 291 minecraft:packed_ice
fill 183 94 292 183 94 307 minecraft:blue_ice
setblock 183 94 308 minecraft:white_concrete
fill 183 94 309 183 95 314 minecraft:blue_ice
fill 183 94 316 183 106 317 minecraft:blue_ice
fill 141 95 275 142 161 275 minecraft:blue_ice
fill 141 95 276 143 95 276 minecraft:packed_ice
setblock 141 95 277 minecraft:light_blue_concrete
fill 141 95 278 141 159 286 minecraft:blue_ice
fill 141 95 287 141 96 287 minecraft:packed_ice
fill 141 95 288 141 95 294 minecraft:blue_ice
setblock 141 95 295 minecraft:white_concrete
fill 141 95 296 141 95 305 minecraft:blue_ice
setblock 141 95 306 minecraft:packed_ice
fill 141 95 307 141 142 313 minecraft:blue_ice
setblock 141 95 314 minecraft:packed_ice
fill 141 95 315 141 95 317 minecraft:blue_ice
setblock 142 95 278 minecraft:snow_block
fill 142 95 279 142 98 279 minecraft:packed_ice
setblock 142 95 283 minecraft:snow_block
fill 142 95 284 142 98 284 minecraft:packed_ice
setblock 142 95 288 minecraft:snow_block
fill 142 95 289 142 98 289 minecraft:packed_ice
setblock 142 95 303 minecraft:snow_block
fill 142 95 304 142 98 304 minecraft:packed_ice
setblock 142 95 308 minecraft:snow_block
fill 142 95 309 142 98 309 minecraft:packed_ice
fill 143 95 275 144 95 275 minecraft:packed_ice
setblock 143 95 277 minecraft:snow_block
fill 143 95 278 143 96 278 minecraft:packed_ice
setblock 143 95 282 minecraft:snow_block
fill 143 95 283 143 98 283 minecraft:packed_ice
setblock 143 95 287 minecraft:snow_block
fill 143 95 288 143 98 288 minecraft:packed_ice
setblock 144 95 276 minecraft:snow_block
fill 144 95 317 152 95 317 minecraft:blue_ice
fill 145 95 275 147 100 275 minecraft:blue_ice
setblock 145 95 276 minecraft:packed_ice
fill 149 95 275 156 95 275 minecraft:blue_ice
setblock 153 95 317 minecraft:light_blue_concrete
setblock 154 95 317 minecraft:packed_ice
fill 155 95 316 156 97 316 minecraft:packed_ice
fill 155 95 317 156 165 317 minecraft:blue_ice
setblock 157 95 275 minecraft:packed_ice
fill 158 95 275 158 161 275 minecraft:blue_ice
fill 158 95 315 158 96 315 minecraft:packed_ice
setblock 159 95 275 minecraft:white_concrete
setblock 159 95 276 minecraft:snow_block
setblock 159 95 316 minecraft:snow_block
fill 159 95 317 167 95 317 minecraft:blue_ice
fill 160 95 275 167 95 275 minecraft:blue_ice
setblock 160 95 276 minecraft:packed_ice
fill 160 95 316 160 98 316 minecraft:packed_ice
setblock 168 95 317 minecraft:white_concrete
fill 169 95 317 176 95 317 minecraft:blue_ice
fill 171 95 275 180 95 275 minecraft:blue_ice
setblock 177 95 317 minecraft:packed_ice
setblock 179 95 276 minecraft:snow_block
fill 179 95 282 179 97 282 minecraft:blue_ice
setblock 179 95 285 minecraft:packed_ice
fill 180 95 276 180 98 276 minecraft:packed_ice
setblock 180 95 280 minecraft:snow_block
fill 180 95 281 180 98 281 minecraft:packed_ice
setblock 180 95 285 minecraft:snow_block
fill 180 95 286 180 98 286 minecraft:packed_ice
setblock 181 95 275 minecraft:packed_ice
setblock 181 95 279 minecraft:snow_block
fill 181 95 280 181 98 280 minecraft:packed_ice
setblock 181 95 284 minecraft:snow_block
fill 181 95 285 181 98 285 minecraft:packed_ice
setblock 181 95 289 minecraft:snow_block
fill 181 95 290 181 98 290 minecraft:packed_ice
setblock 181 95 300 minecraft:packed_ice
setblock 181 95 304 minecraft:snow_block
fill 181 95 305 181 97 305 minecraft:packed_ice
setblock 181 95 317 minecraft:packed_ice
fill 182 95 275 182 161 275 minecraft:blue_ice
setblock 182 95 278 minecraft:snow_block
fill 182 95 279 182 98 279 minecraft:packed_ice
setblock 182 95 283 minecraft:snow_block
fill 182 95 284 182 98 284 minecraft:packed_ice
setblock 182 95 288 minecraft:snow_block
fill 182 95 289 182 98 289 minecraft:packed_ice
setblock 182 95 293 minecraft:snow_block
fill 182 95 294 182 98 294 minecraft:packed_ice
setblock 182 95 298 minecraft:snow_block
fill 182 95 299 182 96 299 minecraft:packed_ice
setblock 182 95 303 minecraft:snow_block
fill 182 95 304 182 98 304 minecraft:packed_ice
setblock 182 95 308 minecraft:snow_block
fill 182 95 309 182 98 309 minecraft:packed_ice
setblock 182 95 317 minecraft:blue_ice
setblock 183 95 275 minecraft:packed_ice
fill 183 95 291 183 97 295 minecraft:blue_ice
setblock 183 95 296 minecraft:light_blue_concrete
fill 183 95 297 183 165 297 minecraft:blue_ice
setblock 183 95 298 minecraft:packed_ice
fill 183 95 299 183 95 308 minecraft:blue_ice
fill 183 95 315 183 161 315 minecraft:blue_ice
fill 141 96 276 141 142 277 minecraft:blue_ice
fill 141 96 288 141 134 288 minecraft:blue_ice
fill 141 96 289 141 96 290 minecraft:packed_ice
fill 141 96 291 141 103 300 minecraft:blue_ice
setblock 141 96 301 minecraft:packed_ice
fill 141 96 302 141 97 306 minecraft:blue_ice
fill 141 96 314 141 107 315 minecraft:blue_ice
fill 141 96 316 141 96 317 minecraft:packed_ice
setblock 142 96 276 minecraft:packed_ice
setblock 142 96 277 minecraft:snow_block
fill 142 96 278 142 99 278 minecraft:packed_ice
setblock 142 96 282 minecraft:snow_block
fill 142 96 283 142 99 283 minecraft:packed_ice
setblock 142 96 287 minecraft:snow_block
fill 142 96 288 142 99 288 minecraft:packed_ice
setblock 142 96 303 minecraft:packed_ice
setblock 142 96 306 minecraft:packed_ice
setblock 142 96 307 minecraft:snow_block
fill 142 96 308 142 99 308 minecraft:packed_ice
setblock 142 96 312 minecraft:snow_block
fill 143 96 275 144 105 275 minecraft:blue_ice
setblock 143 96 276 minecraft:snow_block
setblock 143 96 281 minecraft:snow_block
fill 143 96 282 143 99 282 minecraft:packed_ice
setblock 143 96 286 minecraft:snow_block
fill 143 96 287 143 99 287 minecraft:packed_ice
setblock 144 96 276 minecraft:packed_ice
setblock 144 96 278 minecraft:light[level=15]
setblock 144 96 285 minecraft:light[level=12]
setblock 144 96 286 minecraft:light[level=15]
setblock 144 96 292 minecraft:light[level=12]
setblock 144 96 294 minecraft:light[level=15]
setblock 144 96 299 minecraft:light[level=12]
setblock 144 96 302 minecraft:light[level=15]
setblock 144 96 306 minecraft:light[level=12]
setblock 144 96 310 minecraft:light[level=15]
setblock 144 96 313 minecraft:light[level=12]
fill 144 96 317 144 165 317 minecraft:blue_ice
setblock 145 96 317 minecraft:light_blue_concrete
fill 146 96 317 147 165 317 minecraft:blue_ice
setblock 148 96 317 minecraft:packed_ice
setblock 149 96 275 minecraft:packed_ice
fill 149 96 317 151 105 317 minecraft:blue_ice
fill 150 96 275 157 108 275 minecraft:blue_ice
setblock 151 96 278 minecraft:light[level=12]
setblock 151 96 285 minecraft:light[level=12]
setblock 151 96 292 minecraft:light[level=12]
setblock 151 96 299 minecraft:light[level=12]
setblock 151 96 306 minecraft:light[level=12]
setblock 151 96 313 minecraft:light[level=12]
setblock 152 96 278 minecraft:light[level=15]
setblock 152 96 286 minecraft:light[level=15]
setblock 152 96 294 minecraft:light[level=15]
setblock 152 96 302 minecraft:light[level=15]
setblock 152 96 310 minecraft:light[level=15]
setblock 152 96 317 minecraft:packed_ice
fill 153 96 317 154 123 317 minecraft:blue_ice
fill 154 96 316 154 99 316 minecraft:packed_ice
setblock 157 96 276 minecraft:packed_ice
fill 157 96 315 157 97 315 minecraft:packed_ice
setblock 158 96 276 minecraft:snow_block
setblock 158 96 278 minecraft:light[level=12]
setblock 158 96 285 minecraft:light[level=12]
setblock 158 96 292 minecraft:light[level=12]
setblock 158 96 299 minecraft:light[level=12]
setblock 158 96 306 minecraft:light[level=12]
setblock 158 96 313 minecraft:light[level=12]
setblock 158 96 316 minecraft:snow_block
setblock 159 96 275 minecraft:packed_ice
setblock 159 96 315 minecraft:snow_block
fill 159 96 316 159 96 317 minecraft:packed_ice
fill 160 96 275 162 109 275 minecraft:blue_ice
setblock 160 96 278 minecraft:light[level=15]
setblock 160 96 286 minecraft:light[level=15]
setblock 160 96 294 minecraft:light[level=15]
setblock 160 96 302 minecraft:light[level=15]
setblock 160 96 310 minecraft:light[level=15]
fill 160 96 317 163 123 317 minecraft:blue_ice
setblock 163 96 275 minecraft:packed_ice
fill 164 96 275 166 105 275 minecraft:blue_ice
setblock 164 96 317 minecraft:packed_ice
setblock 165 96 278 minecraft:light[level=12]
setblock 165 96 285 minecraft:light[level=12]
setblock 165 96 292 minecraft:light[level=12]
setblock 165 96 299 minecraft:light[level=12]
setblock 165 96 306 minecraft:light[level=12]
setblock 165 96 313 minecraft:light[level=12]
fill 165 96 317 168 101 317 minecraft:blue_ice
setblock 167 96 275 minecraft:packed_ice
setblock 168 96 278 minecraft:light[level=15]
setblock 168 96 286 minecraft:light[level=15]
setblock 168 96 294 minecraft:light[level=15]
setblock 168 96 302 minecraft:light[level=15]
setblock 168 96 310 minecraft:light[level=15]
setblock 169 96 317 minecraft:packed_ice
fill 170 96 317 178 161 317 minecraft:blue_ice
fill 171 96 275 177 112 275 minecraft:blue_ice
setblock 172 96 278 minecraft:light[level=12]
setblock 172 96 285 minecraft:light[level=12]
setblock 172 96 292 minecraft:light[level=12]
setblock 172 96 299 minecraft:light[level=12]
setblock 172 96 306 minecraft:light[level=12]
setblock 172 96 313 minecraft:light[level=12]
setblock 176 96 278 minecraft:light[level=15]
setblock 176 96 286 minecraft:light[level=15]
setblock 176 96 294 minecraft:light[level=15]
setblock 176 96 302 minecraft:light[level=15]
setblock 176 96 310 minecraft:light[level=15]
fill 177 96 282 178 97 282 minecraft:blue_ice
setblock 178 96 275 minecraft:packed_ice
fill 179 96 275 181 161 275 minecraft:blue_ice
fill 179 96 276 179 99 276 minecraft:packed_ice
setblock 179 96 278 minecraft:light[level=12]
setblock 179 96 281 minecraft:blue_ice
setblock 179 96 283 minecraft:blue_ice
setblock 179 96 284 minecraft:packed_ice
setblock 179 96 285 minecraft:snow_block
fill 179 96 286 179 98 287 minecraft:packed_ice
setblock 179 96 292 minecraft:light[level=12]
setblock 179 96 299 minecraft:light[level=12]
setblock 179 96 306 minecraft:light[level=12]
setblock 179 96 313 minecraft:light[level=12]
setblock 179 96 317 minecraft:packed_ice
setblock 180 96 284 minecraft:snow_block
fill 180 96 285 180 99 285 minecraft:packed_ice
setblock 180 96 288 minecraft:packed_ice
setblock 180 96 289 minecraft:snow_block
fill 180 96 290 180 99 290 minecraft:packed_ice
fill 180 96 317 181 145 317 minecraft:blue_ice
setblock 181 96 278 minecraft:snow_block
fill 181 96 279 181 99 279 minecraft:packed_ice
setblock 181 96 283 minecraft:snow_block
fill 181 96 284 181 99 284 minecraft:packed_ice
setblock 181 96 288 minecraft:snow_block
fill 181 96 289 181 99 289 minecraft:packed_ice
setblock 181 96 303 minecraft:snow_block
fill 181 96 304 181 97 304 minecraft:packed_ice
setblock 182 96 277 minecraft:snow_block
fill 182 96 278 182 99 278 minecraft:packed_ice
setblock 182 96 282 minecraft:snow_block
fill 182 96 283 182 99 283 minecraft:packed_ice
setblock 182 96 287 minecraft:snow_block
fill 182 96 288 182 99 288 minecraft:packed_ice
setblock 182 96 292 minecraft:snow_block
fill 182 96 293 182 99 293 minecraft:packed_ice
setblock 182 96 297 minecraft:snow_block
setblock 182 96 298 minecraft:packed_ice
setblock 182 96 302 minecraft:snow_block
fill 182 96 303 182 98 303 minecraft:packed_ice
setblock 182 96 307 minecraft:snow_block
fill 182 96 308 182 99 308 minecraft:packed_ice
setblock 182 96 317 minecraft:packed_ice
fill 183 96 275 183 165 275 minecraft:blue_ice
fill 183 96 296 183 161 296 minecraft:blue_ice
fill 183 96 298 183 116 301 minecraft:blue_ice
setblock 183 96 302 minecraft:packed_ice
fill 183 96 303 183 120 311 minecraft:blue_ice
setblock 183 96 312 minecraft:packed_ice
fill 183 96 313 183 124 314 minecraft:blue_ice
fill 141 97 287 141 104 287 minecraft:blue_ice
fill 141 97 289 141 98 290 minecraft:blue_ice
fill 141 97 301 141 166 301 minecraft:blue_ice
fill 141 97 316 141 150 317 minecraft:blue_ice
setblock 142 97 276 minecraft:snow_block
fill 142 97 277 142 100 277 minecraft:packed_ice
setblock 142 97 280 minecraft:packed_ice
setblock 142 97 281 minecraft:snow_block
fill 142 97 282 142 100 282 minecraft:packed_ice
setblock 142 97 286 minecraft:snow_block
fill 142 97 287 142 100 287 minecraft:packed_ice
setblock 142 97 291 minecraft:snow_block
setblock 142 97 306 minecraft:snow_block
fill 142 97 307 142 100 307 minecraft:packed_ice
setblock 142 97 311 minecraft:snow_block
fill 142 97 312 142 98 314 minecraft:packed_ice
fill 143 97 276 143 100 276 minecraft:packed_ice
setblock 143 97 280 minecraft:snow_block
fill 143 97 281 143 98 281 minecraft:packed_ice
setblock 143 97 285 minecraft:snow_block
fill 143 97 286 143 100 286 minecraft:packed_ice
fill 145 97 317 145 103 317 minecraft:blue_ice
fill 148 97 317 148 115 317 minecraft:blue_ice
fill 149 97 275 149 165 275 minecraft:blue_ice
fill 152 97 317 152 165 317 minecraft:blue_ice
fill 153 97 316 153 100 316 minecraft:packed_ice
fill 155 97 315 156 98 315 minecraft:packed_ice
setblock 157 97 276 minecraft:snow_block
setblock 157 97 316 minecraft:snow_block
setblock 158 97 315 minecraft:snow_block
fill 158 97 316 159 99 316 minecraft:packed_ice
fill 159 97 275 159 165 275 minecraft:blue_ice
fill 159 97 315 159 100 315 minecraft:packed_ice
fill 159 97 317 159 165 317 minecraft:blue_ice
fill 163 97 275 163 126 275 minecraft:blue_ice
setblock 164 97 317 minecraft:white_concrete
setblock 167 97 275 minecraft:blue_ice
fill 169 97 317 169 162 317 minecraft:blue_ice
setblock 176 97 282 minecraft:blue_ice
fill 178 97 275 178 163 275 minecraft:blue_ice
fill 178 97 276 178 100 276 minecraft:packed_ice
setblock 179 97 284 minecraft:snow_block
fill 179 97 285 179 100 285 minecraft:packed_ice
setblock 179 97 288 minecraft:packed_ice
fill 179 97 317 179 165 317 minecraft:blue_ice
setblock 180 97 283 minecraft:snow_block
fill 180 97 284 180 100 284 minecraft:packed_ice
setblock 180 97 288 minecraft:snow_block
fill 180 97 289 180 100 289 minecraft:packed_ice
fill 180 97 291 180 98 291 minecraft:packed_ice
setblock 181 97 282 minecraft:snow_block
fill 181 97 283 181 100 283 minecraft:packed_ice
setblock 181 97 287 minecraft:snow_block
fill 181 97 288 181 100 288 minecraft:packed_ice
setblock 181 97 292 minecraft:snow_block
fill 181 97 293 181 100 293 minecraft:packed_ice
setblock 181 97 306 minecraft:packed_ice
setblock 181 97 307 minecraft:snow_block
setblock 182 97 276 minecraft:snow_block
fill 182 97 277 182 100 277 minecraft:packed_ice
setblock 182 97 281 minecraft:snow_block
fill 182 97 282 182 100 282 minecraft:packed_ice
setblock 182 97 286 minecraft:snow_block
fill 182 97 287 182 100 287 minecraft:packed_ice
setblock 182 97 291 minecraft:snow_block
fill 182 97 292 182 100 292 minecraft:packed_ice
setblock 182 97 301 minecraft:snow_block
fill 182 97 302 182 98 302 minecraft:packed_ice
setblock 182 97 306 minecraft:snow_block
fill 182 97 307 182 100 307 minecraft:packed_ice
fill 182 97 317 182 142 317 minecraft:blue_ice
fill 183 97 302 183 137 302 minecraft:blue_ice
fill 183 97 312 183 165 312 minecraft:blue_ice
setblock 141 98 302 minecraft:white_concrete
fill 141 98 303 141 150 303 minecraft:blue_ice
setblock 141 98 304 minecraft:white_concrete
fill 141 98 305 141 106 306 minecraft:blue_ice
fill 142 98 276 142 101 276 minecraft:packed_ice
setblock 142 98 280 minecraft:snow_block
fill 142 98 281 142 101 281 minecraft:packed_ice
setblock 142 98 285 minecraft:snow_block
fill 142 98 286 142 101 286 minecraft:packed_ice
setblock 142 98 290 minecraft:snow_block
fill 142 98 291 142 101 291 minecraft:packed_ice
setblock 142 98 305 minecraft:snow_block
fill 142 98 306 142 101 306 minecraft:packed_ice
setblock 142 98 310 minecraft:snow_block
fill 142 98 311 142 101 311 minecraft:packed_ice
setblock 142 98 315 minecraft:snow_block
fill 142 98 316 142 101 316 minecraft:packed_ice
setblock 143 98 284 minecraft:snow_block
fill 143 98 285 143 101 285 minecraft:packed_ice
fill 144 98 315 144 101 315 minecraft:blue_ice
setblock 151 98 316 minecraft:snow_block
fill 152 98 316 152 101 316 minecraft:packed_ice
fill 154 98 315 154 100 315 minecraft:packed_ice
setblock 155 98 276 minecraft:packed_ice
setblock 155 98 316 minecraft:packed_ice
setblock 156 98 276 minecraft:snow_block
fill 156 98 314 157 98 314 minecraft:packed_ice
setblock 156 98 316 minecraft:snow_block
fill 157 98 276 157 101 276 minecraft:packed_ice
setblock 157 98 315 minecraft:snow_block
fill 157 98 316 157 101 316 minecraft:packed_ice
setblock 158 98 314 minecraft:snow_block
fill 158 98 315 158 101 315 minecraft:packed_ice
fill 160 98 315 160 99 315 minecraft:packed_ice
setblock 161 98 316 minecraft:snow_block
fill 164 98 317 164 166 317 minecraft:blue_ice
setblock 167 98 275 minecraft:white_concrete
fill 177 98 276 177 101 276 minecraft:packed_ice
fill 179 98 284 179 101 284 minecraft:packed_ice
setblock 179 98 288 minecraft:snow_block
fill 179 98 289 179 101 289 minecraft:packed_ice
setblock 180 98 282 minecraft:snow_block
fill 180 98 283 180 101 283 minecraft:packed_ice
setblock 180 98 287 minecraft:snow_block
fill 180 98 288 180 101 288 minecraft:packed_ice
setblock 181 98 276 minecraft:snow_block
setblock 181 98 281 minecraft:snow_block
fill 181 98 282 181 101 282 minecraft:packed_ice
setblock 181 98 286 minecraft:snow_block
fill 181 98 287 181 101 287 minecraft:packed_ice
setblock 181 98 291 minecraft:snow_block
fill 181 98 292 181 101 292 minecraft:packed_ice
setblock 181 98 306 minecraft:snow_block
fill 181 98 307 181 99 308 minecraft:packed_ice
fill 182 98 276 182 101 276 minecraft:packed_ice
setblock 182 98 280 minecraft:snow_block
fill 182 98 281 182 101 281 minecraft:packed_ice
setblock 182 98 285 minecraft:snow_block
fill 182 98 286 182 101 286 minecraft:packed_ice
setblock 182 98 290 minecraft:snow_block
fill 182 98 291 182 101 291 minecraft:packed_ice
setblock 182 98 295 minecraft:snow_block
setblock 182 98 305 minecraft:snow_block
fill 182 98 306 182 101 306 minecraft:packed_ice
setblock 182 98 310 minecraft:snow_block
fill 182 98 311 182 101 311 minecraft:packed_ice
fill 183 98 291 183 119 293 minecraft:blue_ice
setblock 183 98 294 minecraft:white_concrete
fill 183 98 295 183 165 295 minecraft:blue_ice
fill 141 99 289 141 119 289 minecraft:blue_ice
setblock 141 99 290 minecraft:white_concrete
fill 141 99 302 141 130 302 minecraft:blue_ice
fill 141 99 304 141 156 304 minecraft:blue_ice
setblock 142 99 279 minecraft:snow_block
fill 142 99 280 142 102 280 minecraft:packed_ice
setblock 142 99 284 minecraft:snow_block
fill 142 99 285 142 102 285 minecraft:packed_ice
setblock 142 99 289 minecraft:snow_block
fill 142 99 290 142 102 290 minecraft:packed_ice
fill 142 99 292 142 100 292 minecraft:packed_ice
fill 142 99 305 142 101 305 minecraft:packed_ice
setblock 142 99 309 minecraft:snow_block
fill 142 99 310 142 102 310 minecraft:packed_ice
fill 142 99 312 142 99 313 minecraft:packed_ice
setblock 142 99 314 minecraft:snow_block
fill 142 99 315 142 102 315 minecraft:packed_ice
setblock 143 99 283 minecraft:snow_block
fill 143 99 284 143 101 284 minecraft:packed_ice
setblock 143 99 288 minecraft:snow_block
fill 143 99 314 143 100 315 minecraft:blue_ice
fill 143 99 316 143 100 316 minecraft:packed_ice
fill 144 99 312 144 100 314 minecraft:blue_ice
fill 144 99 316 145 99 316 minecraft:blue_ice
fill 145 99 314 145 100 315 minecraft:blue_ice
setblock 149 99 316 minecraft:packed_ice
setblock 150 99 316 minecraft:snow_block
fill 151 99 316 151 102 316 minecraft:packed_ice
fill 152 99 315 153 101 315 minecraft:packed_ice
setblock 154 99 276 minecraft:packed_ice
fill 154 99 314 156 99 314 minecraft:packed_ice
setblock 155 99 276 minecraft:snow_block
setblock 155 99 315 minecraft:packed_ice
setblock 155 99 316 minecraft:snow_block
fill 156 99 276 156 102 276 minecraft:packed_ice
setblock 156 99 315 minecraft:snow_block
fill 156 99 316 156 102 316 minecraft:packed_ice
setblock 157 99 314 minecraft:snow_block
fill 157 99 315 157 102 315 minecraft:packed_ice
fill 158 99 276 158 100 276 minecraft:packed_ice
fill 158 99 314 159 101 314 minecraft:packed_ice
setblock 160 99 316 minecraft:snow_block
fill 161 99 316 162 101 316 minecraft:packed_ice
fill 167 99 275 167 165 275 minecraft:blue_ice
fill 176 99 276 176 102 276 minecraft:packed_ice
setblock 179 99 283 minecraft:packed_ice
setblock 179 99 286 minecraft:packed_ice
setblock 179 99 287 minecraft:snow_block
fill 179 99 288 179 102 288 minecraft:packed_ice
fill 179 99 290 179 100 290 minecraft:packed_ice
setblock 180 99 276 minecraft:snow_block
setblock 180 99 281 minecraft:snow_block
fill 180 99 282 180 102 282 minecraft:packed_ice
setblock 180 99 286 minecraft:snow_block
fill 180 99 287 180 102 287 minecraft:packed_ice
setblock 180 99 291 minecraft:snow_block
fill 180 99 292 180 102 292 minecraft:packed_ice
fill 181 99 276 181 102 276 minecraft:packed_ice
setblock 181 99 280 minecraft:snow_block
fill 181 99 281 181 102 281 minecraft:packed_ice
setblock 181 99 285 minecraft:snow_block
fill 181 99 286 181 102 286 minecraft:packed_ice
setblock 181 99 290 minecraft:snow_block
fill 181 99 291 181 102 291 minecraft:packed_ice
setblock 181 99 309 minecraft:packed_ice
setblock 182 99 279 minecraft:snow_block
fill 182 99 280 182 102 280 minecraft:packed_ice
setblock 182 99 284 minecraft:snow_block
fill 182 99 285 182 102 285 minecraft:packed_ice
setblock 182 99 289 minecraft:snow_block
fill 182 99 290 182 102 290 minecraft:packed_ice
setblock 182 99 294 minecraft:snow_block
fill 182 99 295 182 102 295 minecraft:packed_ice
setblock 182 99 304 minecraft:snow_block
fill 182 99 305 182 100 305 minecraft:packed_ice
setblock 182 99 309 minecraft:snow_block
fill 182 99 310 182 102 310 minecraft:packed_ice
fill 182 99 312 182 99 313 minecraft:packed_ice
fill 183 99 294 183 165 294 minecraft:blue_ice
fill 141 100 290 141 163 290 minecraft:blue_ice
setblock 142 100 278 minecraft:snow_block
fill 142 100 279 142 103 279 minecraft:packed_ice
setblock 142 100 283 minecraft:snow_block
fill 142 100 284 142 103 284 minecraft:packed_ice
setblock 142 100 288 minecraft:snow_block
fill 142 100 289 142 103 289 minecraft:packed_ice
setblock 142 100 308 minecraft:snow_block
fill 142 100 309 143 102 309 minecraft:packed_ice
setblock 142 100 312 minecraft:packed_ice
setblock 142 100 313 minecraft:snow_block
fill 142 100 314 142 103 314 minecraft:packed_ice
setblock 143 100 283 minecraft:packed_ice
setblock 143 100 287 minecraft:snow_block
fill 143 100 288 143 101 288 minecraft:packed_ice
fill 143 100 310 143 100 311 minecraft:packed_ice
setblock 143 100 312 minecraft:snow_block
fill 143 100 313 143 103 313 minecraft:packed_ice
fill 144 100 309 144 100 311 minecraft:blue_ice
setblock 144 100 316 minecraft:snow_block
setblock 145 100 313 minecraft:blue_ice
fill 145 100 316 148 100 316 minecraft:packed_ice
setblock 149 100 316 minecraft:snow_block
setblock 150 100 315 minecraft:snow_block
fill 150 100 316 150 103 316 minecraft:packed_ice
fill 151 100 315 151 103 315 minecraft:packed_ice
fill 152 100 276 153 100 276 minecraft:packed_ice
fill 152 100 314 155 100 314 minecraft:packed_ice
setblock 154 100 276 minecraft:snow_block
fill 154 100 313 156 100 313 minecraft:packed_ice
setblock 154 100 316 minecraft:snow_block
fill 155 100 276 155 103 276 minecraft:packed_ice
setblock 155 100 315 minecraft:snow_block
fill 155 100 316 155 103 316 minecraft:packed_ice
setblock 156 100 314 minecraft:snow_block
fill 156 100 315 156 103 315 minecraft:packed_ice
setblock 157 100 313 minecraft:snow_block
fill 157 100 314 157 103 314 minecraft:packed_ice
fill 158 100 313 158 103 313 minecraft:packed_ice
setblock 158 100 316 minecraft:packed_ice
setblock 159 100 316 minecraft:snow_block
setblock 160 100 314 minecraft:packed_ice
setblock 160 100 315 minecraft:snow_block
fill 160 100 316 160 103 316 minecraft:packed_ice
fill 161 100 315 161 103 315 minecraft:packed_ice
fill 175 100 276 175 103 276 minecraft:packed_ice
fill 175 100 316 178 100 316 minecraft:packed_ice
setblock 178 100 287 minecraft:snow_block
fill 178 100 288 178 102 288 minecraft:packed_ice
setblock 179 100 276 minecraft:snow_block
setblock 179 100 286 minecraft:snow_block
fill 179 100 287 179 103 287 minecraft:packed_ice
setblock 179 100 291 minecraft:snow_block
setblock 179 100 316 minecraft:snow_block
fill 180 100 276 180 103 276 minecraft:packed_ice
setblock 180 100 281 minecraft:packed_ice
setblock 180 100 285 minecraft:snow_block
fill 180 100 286 180 103 286 minecraft:packed_ice
setblock 180 100 290 minecraft:snow_block
fill 180 100 291 180 103 291 minecraft:packed_ice
fill 180 100 293 180 101 293 minecraft:packed_ice
fill 180 100 316 180 103 316 minecraft:packed_ice
setblock 181 100 279 minecraft:snow_block
fill 181 100 280 181 102 280 minecraft:packed_ice
setblock 181 100 284 minecraft:snow_block
fill 181 100 285 181 103 285 minecraft:packed_ice
setblock 181 100 289 minecraft:snow_block
fill 181 100 290 181 103 290 minecraft:packed_ice
setblock 181 100 294 minecraft:snow_block
setblock 181 100 308 minecraft:packed_ice
setblock 181 100 309 minecraft:snow_block
fill 181 100 310 181 102 310 minecraft:packed_ice
setblock 182 100 278 minecraft:snow_block
fill 182 100 279 182 103 279 minecraft:packed_ice
setblock 182 100 283 minecraft:snow_block
fill 182 100 284 182 103 284 minecraft:packed_ice
setblock 182 100 288 minecraft:snow_block
fill 182 100 289 182 103 289 minecraft:packed_ice
setblock 182 100 293 minecraft:snow_block
fill 182 100 294 182 103 294 minecraft:packed_ice
setblock 182 100 308 minecraft:snow_block
fill 182 100 309 182 103 309 minecraft:packed_ice
setblock 182 100 312 minecraft:packed_ice
setblock 182 100 313 minecraft:snow_block
fill 182 100 314 182 103 314 minecraft:packed_ice
fill 183 100 276 183 126 280 minecraft:blue_ice
setblock 183 100 281 minecraft:light_blue_concrete
fill 183 100 282 183 121 290 minecraft:blue_ice
setblock 142 101 277 minecraft:snow_block
fill 142 101 278 142 104 278 minecraft:packed_ice
setblock 142 101 282 minecraft:snow_block
fill 142 101 283 142 103 283 minecraft:packed_ice
setblock 142 101 287 minecraft:snow_block
fill 142 101 288 142 104 288 minecraft:packed_ice
setblock 142 101 292 minecraft:snow_block
fill 142 101 293 142 104 293 minecraft:packed_ice
setblock 142 101 307 minecraft:snow_block
fill 142 101 308 143 101 308 minecraft:packed_ice
setblock 142 101 312 minecraft:snow_block
fill 142 101 313 142 104 313 minecraft:packed_ice
setblock 143 101 276 minecraft:snow_block
setblock 143 101 286 minecraft:snow_block
fill 143 101 287 143 102 287 minecraft:packed_ice
setblock 143 101 310 minecraft:packed_ice
setblock 143 101 311 minecraft:snow_block
fill 143 101 312 143 104 312 minecraft:packed_ice
fill 143 101 314 143 101 315 minecraft:packed_ice
setblock 143 101 316 minecraft:snow_block
fill 144 101 276 144 104 276 minecraft:packed_ice
fill 144 101 316 147 101 316 minecraft:packed_ice
fill 145 101 275 145 165 275 minecraft:blue_ice
setblock 146 101 275 minecraft:white_concrete
fill 147 101 275 147 159 275 minecraft:blue_ice
fill 147 101 315 148 101 315 minecraft:packed_ice
setblock 148 101 316 minecraft:snow_block
setblock 149 101 315 minecraft:snow_block
fill 149 101 316 149 104 316 minecraft:packed_ice
fill 150 101 276 152 101 276 minecraft:packed_ice
setblock 150 101 314 minecraft:snow_block
fill 150 101 315 150 104 315 minecraft:packed_ice
fill 151 101 314 154 101 314 minecraft:packed_ice
fill 152 101 313 155 101 313 minecraft:packed_ice
setblock 153 101 276 minecraft:snow_block
setblock 153 101 316 minecraft:snow_block
fill 154 101 276 154 104 276 minecraft:packed_ice
setblock 154 101 315 minecraft:snow_block
fill 154 101 316 154 104 316 minecraft:packed_ice
setblock 155 101 314 minecraft:snow_block
fill 155 101 315 155 104 315 minecraft:packed_ice
setblock 156 101 312 minecraft:packed_ice
setblock 156 101 313 minecraft:snow_block
fill 156 101 314 156 104 314 minecraft:packed_ice
fill 157 101 313 157 104 313 minecraft:packed_ice
setblock 158 101 276 minecraft:snow_block
setblock 158 101 316 minecraft:snow_block
fill 159 101 313 159 102 313 minecraft:packed_ice
setblock 159 101 315 minecraft:snow_block
fill 159 101 316 159 104 316 minecraft:packed_ice
setblock 160 101 314 minecraft:snow_block
fill 160 101 315 160 104 315 minecraft:packed_ice
setblock 173 101 316 minecraft:snow_block
fill 174 101 276 174 104 276 minecraft:packed_ice
fill 174 101 316 177 101 316 minecraft:packed_ice
setblock 176 101 277 minecraft:blue_ice
fill 176 101 315 178 101 315 minecraft:packed_ice
setblock 177 101 277 minecraft:snow_block
fill 177 101 278 177 103 279 minecraft:blue_ice
setblock 178 101 276 minecraft:snow_block
fill 178 101 277 179 103 277 minecraft:packed_ice
fill 178 101 287 178 102 287 minecraft:packed_ice
fill 178 101 289 178 102 289 minecraft:packed_ice
setblock 178 101 316 minecraft:snow_block
fill 179 101 276 179 104 276 minecraft:packed_ice
setblock 179 101 285 minecraft:snow_block
fill 179 101 286 179 103 286 minecraft:packed_ice
setblock 179 101 290 minecraft:snow_block
fill 179 101 291 179 103 292 minecraft:packed_ice
fill 179 101 316 179 104 316 minecraft:packed_ice
setblock 180 101 284 minecraft:snow_block
fill 180 101 285 180 104 285 minecraft:packed_ice
setblock 180 101 289 minecraft:snow_block
fill 180 101 290 180 104 290 minecraft:packed_ice
setblock 181 101 279 minecraft:packed_ice
setblock 181 101 283 minecraft:snow_block
fill 181 101 284 181 104 284 minecraft:packed_ice
setblock 181 101 288 minecraft:snow_block
fill 181 101 289 181 104 289 minecraft:packed_ice
setblock 181 101 293 minecraft:snow_block
fill 181 101 294 181 104 294 minecraft:packed_ice
setblock 181 101 308 minecraft:snow_block
setblock 181 101 309 minecraft:packed_ice
fill 181 101 311 181 101 312 minecraft:packed_ice
fill 181 101 316 182 101 316 minecraft:packed_ice
setblock 182 101 277 minecraft:snow_block
fill 182 101 278 182 104 278 minecraft:packed_ice
setblock 182 101 282 minecraft:snow_block
fill 182 101 283 182 104 283 minecraft:packed_ice
setblock 182 101 287 minecraft:snow_block
fill 182 101 288 182 104 288 minecraft:packed_ice
setblock 182 101 292 minecraft:snow_block
fill 182 101 293 182 104 293 minecraft:packed_ice
setblock 182 101 307 minecraft:snow_block
fill 182 101 308 182 103 308 minecraft:packed_ice
setblock 182 101 312 minecraft:snow_block
fill 182 101 313 182 104 313 minecraft:packed_ice
fill 182 101 315 182 102 315 minecraft:packed_ice
fill 183 101 281 183 165 281 minecraft:blue_ice
setblock 142 102 276 minecraft:snow_block
fill 142 102 277 142 105 277 minecraft:packed_ice
setblock 142 102 281 minecraft:snow_block
fill 142 102 282 142 103 282 minecraft:packed_ice
setblock 142 102 286 minecraft:snow_block
fill 142 102 287 142 105 287 minecraft:packed_ice
setblock 142 102 291 minecraft:snow_block
fill 142 102 292 142 105 292 minecraft:packed_ice
setblock 142 102 306 minecraft:snow_block
fill 142 102 307 142 104 308 minecraft:packed_ice
setblock 142 102 311 minecraft:snow_block
fill 142 102 312 142 105 312 minecraft:packed_ice
setblock 142 102 316 minecraft:snow_block
fill 143 102 276 143 105 276 minecraft:packed_ice
setblock 143 102 310 minecraft:snow_block
fill 143 102 311 143 105 311 minecraft:packed_ice
setblock 143 102 314 minecraft:packed_ice
setblock 143 102 315 minecraft:snow_block
fill 143 102 316 146 102 316 minecraft:packed_ice
setblock 144 102 278 minecraft:light[level=12]
setblock 144 102 285 minecraft:light[level=12]
setblock 144 102 292 minecraft:light[level=12]
setblock 144 102 299 minecraft:light[level=12]
setblock 144 102 306 minecraft:light[level=12]
fill 144 102 311 144 102 313 minecraft:blue_ice
fill 144 102 315 147 102 315 minecraft:packed_ice
fill 145 102 310 145 102 311 minecraft:blue_ice
fill 145 102 313 145 104 313 minecraft:blue_ice
fill 146 102 275 146 161 275 minecraft:blue_ice
fill 146 102 310 147 103 310 minecraft:blue_ice
fill 146 102 314 147 102 314 minecraft:blue_ice
fill 147 102 313 148 102 313 minecraft:blue_ice
setblock 147 102 316 minecraft:snow_block
fill 148 102 276 151 102 276 minecraft:packed_ice
fill 148 102 311 148 103 312 minecraft:blue_ice
setblock 148 102 315 minecraft:snow_block
fill 148 102 316 148 105 316 minecraft:packed_ice
setblock 149 102 314 minecraft:snow_block
fill 149 102 315 149 105 315 minecraft:packed_ice
fill 150 102 314 153 102 314 minecraft:packed_ice
setblock 151 102 278 minecraft:light[level=12]
setblock 151 102 285 minecraft:light[level=12]
setblock 151 102 292 minecraft:light[level=12]
setblock 151 102 299 minecraft:light[level=12]
setblock 151 102 306 minecraft:light[level=12]
fill 151 102 308 152 102 308 minecraft:blue_ice
fill 151 102 313 154 102 313 minecraft:packed_ice
setblock 152 102 276 minecraft:snow_block
fill 152 102 306 152 102 307 minecraft:blue_ice
fill 152 102 309 152 102 310 minecraft:blue_ice
setblock 152 102 315 minecraft:packed_ice
setblock 152 102 316 minecraft:snow_block
fill 153 102 276 153 105 276 minecraft:packed_ice
fill 153 102 306 155 102 306 minecraft:blue_ice
fill 153 102 310 155 102 310 minecraft:blue_ice
setblock 153 102 315 minecraft:snow_block
fill 153 102 316 153 105 316 minecraft:packed_ice
fill 154 102 312 155 102 312 minecraft:packed_ice
setblock 154 102 314 minecraft:snow_block
fill 154 102 315 154 105 315 minecraft:packed_ice
fill 155 102 301 156 102 301 minecraft:blue_ice
fill 155 102 307 156 102 309 minecraft:blue_ice
setblock 155 102 313 minecraft:snow_block
fill 155 102 314 155 105 314 minecraft:packed_ice
fill 156 102 299 156 102 300 minecraft:blue_ice
fill 156 102 302 156 102 303 minecraft:blue_ice
setblock 156 102 312 minecraft:snow_block
fill 156 102 313 156 105 313 minecraft:packed_ice
setblock 157 102 276 minecraft:snow_block
fill 157 102 303 159 102 304 minecraft:blue_ice
setblock 157 102 312 minecraft:packed_ice
setblock 157 102 316 minecraft:snow_block
fill 158 102 276 158 104 276 minecraft:packed_ice
setblock 158 102 278 minecraft:light[level=12]
setblock 158 102 285 minecraft:light[level=12]
fill 158 102 286 159 102 290 minecraft:blue_ice
setblock 158 102 292 minecraft:light[level=12]
setblock 158 102 299 minecraft:light[level=12]
setblock 158 102 306 minecraft:light[level=12]
setblock 158 102 314 minecraft:packed_ice
setblock 158 102 315 minecraft:snow_block
fill 158 102 316 158 105 316 minecraft:packed_ice
fill 159 102 285 164 102 285 minecraft:blue_ice
fill 159 102 291 164 102 291 minecraft:blue_ice
fill 159 102 299 160 102 299 minecraft:blue_ice
setblock 159 102 314 minecraft:snow_block
fill 159 102 315 159 105 315 minecraft:packed_ice
fill 160 102 286 160 104 286 minecraft:blue_ice
fill 160 102 290 160 104 290 minecraft:blue_ice
fill 160 102 300 160 102 303 minecraft:blue_ice
fill 160 102 314 160 103 314 minecraft:packed_ice
fill 161 102 284 162 102 284 minecraft:blue_ice
fill 161 102 292 162 102 292 minecraft:blue_ice
fill 161 102 301 161 102 302 minecraft:blue_ice
setblock 161 102 316 minecraft:packed_ice
setblock 162 102 316 minecraft:snow_block
fill 163 102 286 165 102 286 minecraft:blue_ice
fill 163 102 290 165 102 290 minecraft:blue_ice
fill 164 102 287 165 102 289 minecraft:blue_ice
setblock 165 102 278 minecraft:light[level=12]
setblock 165 102 285 minecraft:light[level=12]
setblock 165 102 292 minecraft:light[level=12]
setblock 165 102 299 minecraft:light[level=12]
setblock 165 102 306 minecraft:light[level=12]
setblock 165 102 313 minecraft:light[level=12]
setblock 165 102 317 minecraft:light_blue_concrete
fill 166 102 317 168 162 317 minecraft:blue_ice
setblock 171 102 316 minecraft:packed_ice
setblock 172 102 276 minecraft:snow_block
setblock 172 102 278 minecraft:light[level=12]
setblock 172 102 285 minecraft:light[level=12]
setblock 172 102 292 minecraft:light[level=12]
setblock 172 102 299 minecraft:light[level=12]
setblock 172 102 306 minecraft:light[level=12]
setblock 172 102 313 minecraft:light[level=12]
setblock 172 102 316 minecraft:snow_block
fill 173 102 276 173 105 276 minecraft:packed_ice
setblock 173 102 315 minecraft:snow_block
fill 173 102 316 176 102 316 minecraft:packed_ice
fill 174 102 315 177 102 315 minecraft:packed_ice
setblock 175 102 277 minecraft:packed_ice
setblock 176 102 277 minecraft:snow_block
fill 176 102 278 176 102 279 minecraft:blue_ice
setblock 177 102 276 minecraft:snow_block
fill 177 102 277 177 105 277 minecraft:packed_ice
setblock 177 102 280 minecraft:blue_ice
setblock 177 102 316 minecraft:snow_block
fill 178 102 276 178 105 276 minecraft:packed_ice
fill 178 102 278 178 102 279 minecraft:blue_ice
setblock 178 102 315 minecraft:snow_block
fill 178 102 316 178 105 316 minecraft:packed_ice
setblock 179 102 278 minecraft:light[level=12]
setblock 179 102 284 minecraft:snow_block
setblock 179 102 285 minecraft:packed_ice
setblock 179 102 289 minecraft:snow_block
fill 179 102 290 179 104 290 minecraft:packed_ice
setblock 179 102 299 minecraft:light[level=12]
setblock 179 102 306 minecraft:light[level=12]
setblock 179 102 313 minecraft:light[level=12]
fill 179 102 315 179 105 315 minecraft:packed_ice
setblock 180 102 283 minecraft:snow_block
fill 180 102 284 180 103 284 minecraft:packed_ice
setblock 180 102 288 minecraft:snow_block
fill 180 102 289 180 105 289 minecraft:packed_ice
setblock 180 102 293 minecraft:snow_block
setblock 181 102 282 minecraft:snow_block
fill 181 102 283 181 104 283 minecraft:packed_ice
setblock 181 102 287 minecraft:snow_block
fill 181 102 288 181 105 288 minecraft:packed_ice
setblock 181 102 292 minecraft:snow_block
fill 181 102 293 181 105 293 minecraft:packed_ice
setblock 181 102 311 minecraft:packed_ice
setblock 181 102 312 minecraft:snow_block
fill 181 102 313 181 103 313 minecraft:packed_ice
setblock 181 102 316 minecraft:packed_ice
setblock 182 102 276 minecraft:snow_block
fill 182 102 277 182 105 277 minecraft:packed_ice
setblock 182 102 281 minecraft:snow_block
fill 182 102 282 182 105 282 minecraft:packed_ice
setblock 182 102 286 minecraft:snow_block
fill 182 102 287 182 105 287 minecraft:packed_ice
setblock 182 102 291 minecraft:snow_block
fill 182 102 292 182 105 292 minecraft:packed_ice
setblock 182 102 307 minecraft:packed_ice
setblock 182 102 311 minecraft:snow_block
fill 182 102 312 182 105 312 minecraft:packed_ice
setblock 182 102 316 minecraft:snow_block
fill 142 103 276 142 105 276 minecraft:packed_ice
setblock 142 103 280 minecraft:snow_block
setblock 142 103 281 minecraft:packed_ice
setblock 142 103 285 minecraft:snow_block
fill 142 103 286 142 104 286 minecraft:packed_ice
setblock 142 103 290 minecraft:snow_block
fill 142 103 291 142 105 291 minecraft:packed_ice
setblock 142 103 306 minecraft:packed_ice
setblock 142 103 309 minecraft:packed_ice
setblock 142 103 310 minecraft:snow_block
fill 142 103 311 142 105 311 minecraft:packed_ice
setblock 142 103 315 minecraft:snow_block
fill 142 103 316 145 103 316 minecraft:packed_ice
setblock 143 103 309 minecraft:snow_block
fill 143 103 310 143 105 310 minecraft:packed_ice
setblock 143 103 314 minecraft:snow_block
fill 143 103 315 146 103 315 minecraft:packed_ice
setblock 145 103 276 minecraft:packed_ice
fill 145 103 311 145 104 311 minecraft:blue_ice
setblock 146 103 276 minecraft:snow_block
setblock 146 103 316 minecraft:snow_block
fill 147 103 276 150 103 276 minecraft:packed_ice
fill 147 103 313 147 104 313 minecraft:blue_ice
setblock 147 103 314 minecraft:packed_ice
setblock 147 103 315 minecraft:snow_block
fill 147 103 316 147 105 316 minecraft:packed_ice
setblock 148 103 314 minecraft:snow_block
fill 148 103 315 148 105 315 minecraft:packed_ice
fill 149 103 314 152 103 314 minecraft:packed_ice
fill 150 103 313 153 103 313 minecraft:packed_ice
setblock 151 103 276 minecraft:snow_block
setblock 151 103 316 minecraft:snow_block
fill 152 103 276 152 105 276 minecraft:packed_ice
fill 152 103 307 152 103 309 minecraft:blue_ice
setblock 152 103 315 minecraft:snow_block
fill 152 103 316 152 105 316 minecraft:packed_ice
fill 153 103 306 154 103 306 minecraft:blue_ice
fill 153 103 310 154 103 310 minecraft:blue_ice
fill 153 103 312 154 103 312 minecraft:packed_ice
setblock 153 103 314 minecraft:snow_block
fill 153 103 315 153 105 315 minecraft:packed_ice
setblock 154 103 313 minecraft:snow_block
fill 154 103 314 154 105 314 minecraft:packed_ice
fill 155 103 307 155 104 309 minecraft:blue_ice
setblock 155 103 312 minecraft:snow_block
fill 155 103 313 155 105 313 minecraft:packed_ice
setblock 156 103 276 minecraft:snow_block
fill 156 103 300 156 103 302 minecraft:blue_ice
fill 156 103 312 156 104 312 minecraft:packed_ice
setblock 156 103 316 minecraft:snow_block
fill 157 103 276 157 105 276 minecraft:packed_ice
setblock 157 103 299 minecraft:blue_ice
fill 157 103 303 159 104 303 minecraft:blue_ice
setblock 157 103 315 minecraft:snow_block
fill 157 103 316 157 105 316 minecraft:packed_ice
fill 158 103 288 159 103 288 minecraft:blue_ice
setblock 158 103 314 minecraft:snow_block
fill 158 103 315 158 105 315 minecraft:packed_ice
fill 159 103 286 159 103 287 minecraft:blue_ice
fill 159 103 289 159 103 290 minecraft:blue_ice
setblock 159 103 299 minecraft:blue_ice
fill 159 103 314 159 105 314 minecraft:packed_ice
fill 160 103 285 163 103 285 minecraft:blue_ice
fill 160 103 291 163 103 291 minecraft:blue_ice
fill 160 103 300 160 103 302 minecraft:blue_ice
setblock 161 103 316 minecraft:snow_block
fill 162 103 316 163 103 316 minecraft:packed_ice
fill 163 103 286 164 103 286 minecraft:blue_ice
fill 163 103 290 164 103 290 minecraft:blue_ice
fill 164 103 287 164 104 289 minecraft:blue_ice
fill 165 103 317 165 165 317 minecraft:blue_ice
setblock 170 103 316 minecraft:packed_ice
setblock 171 103 276 minecraft:snow_block
setblock 171 103 316 minecraft:snow_block
fill 172 103 276 172 105 276 minecraft:packed_ice
setblock 172 103 315 minecraft:snow_block
fill 172 103 316 175 103 316 minecraft:packed_ice
fill 173 103 315 176 103 315 minecraft:packed_ice
setblock 174 103 277 minecraft:packed_ice
setblock 175 103 277 minecraft:snow_block
setblock 176 103 276 minecraft:snow_block
fill 176 103 277 176 105 277 minecraft:packed_ice
setblock 176 103 278 minecraft:blue_ice
setblock 176 103 316 minecraft:snow_block
fill 177 103 276 177 105 276 minecraft:packed_ice
setblock 177 103 315 minecraft:snow_block
fill 177 103 316 177 105 316 minecraft:packed_ice
setblock 178 103 278 minecraft:blue_ice
fill 178 103 315 178 105 315 minecraft:packed_ice
setblock 179 103 288 minecraft:snow_block
fill 179 103 289 179 104 289 minecraft:packed_ice
setblock 180 103 283 minecraft:packed_ice
setblock 180 103 287 minecraft:snow_block
fill 180 103 288 180 105 288 minecraft:packed_ice
setblock 180 103 292 minecraft:snow_block
fill 180 103 293 180 104 293 minecraft:packed_ice
fill 180 103 315 180 104 315 minecraft:packed_ice
setblock 181 103 276 minecraft:snow_block
setblock 181 103 281 minecraft:snow_block
setblock 181 103 282 minecraft:packed_ice
setblock 181 103 286 minecraft:snow_block
fill 181 103 287 181 105 287 minecraft:packed_ice
setblock 181 103 291 minecraft:snow_block
fill 181 103 292 181 105 292 minecraft:packed_ice
setblock 181 103 311 minecraft:snow_block
setblock 181 103 312 minecraft:packed_ice
setblock 181 103 316 minecraft:snow_block
fill 182 103 276 182 105 276 minecraft:packed_ice
setblock 182 103 280 minecraft:snow_block
fill 182 103 281 182 105 281 minecraft:packed_ice
setblock 182 103 285 minecraft:snow_block
fill 182 103 286 182 105 286 minecraft:packed_ice
setblock 182 103 290 minecraft:snow_block
fill 182 103 291 182 105 291 minecraft:packed_ice
setblock 182 103 295 minecraft:snow_block
setblock 182 103 310 minecraft:snow_block
fill 182 103 311 182 105 311 minecraft:packed_ice
setblock 182 103 315 minecraft:snow_block
fill 182 103 316 182 105 316 minecraft:packed_ice
fill 141 104 291 141 161 293 minecraft:blue_ice
setblock 141 104 294 minecraft:light_blue_concrete
fill 141 104 295 141 114 300 minecraft:blue_ice
setblock 142 104 284 minecraft:snow_block
setblock 142 104 285 minecraft:packed_ice
setblock 142 104 289 minecraft:snow_block
fill 142 104 290 142 105 290 minecraft:packed_ice
setblock 142 104 309 minecraft:snow_block
fill 142 104 310 142 105 310 minecraft:packed_ice
setblock 142 104 314 minecraft:snow_block
fill 142 104 315 144 104 316 minecraft:packed_ice
setblock 143 104 313 minecraft:snow_block
fill 143 104 314 143 105 314 minecraft:packed_ice
setblock 144 104 278 minecraft:light[level=15]
setblock 144 104 286 minecraft:light[level=15]
setblock 144 104 294 minecraft:light[level=15]
setblock 144 104 302 minecraft:light[level=15]
setblock 144 104 310 minecraft:light[level=15]
setblock 145 104 276 minecraft:snow_block
setblock 145 104 315 minecraft:packed_ice
setblock 145 104 316 minecraft:snow_block
setblock 145 104 317 minecraft:white_concrete
fill 146 104 276 149 104 276 minecraft:packed_ice
setblock 146 104 314 minecraft:packed_ice
setblock 146 104 315 minecraft:snow_block
fill 146 104 316 146 105 316 minecraft:packed_ice
setblock 147 104 314 minecraft:snow_block
fill 147 104 315 147 105 315 minecraft:packed_ice
fill 148 104 314 151 104 314 minecraft:packed_ice
fill 149 104 313 152 104 313 minecraft:packed_ice
setblock 150 104 276 minecraft:snow_block
setblock 150 104 316 minecraft:snow_block
fill 151 104 276 151 105 276 minecraft:packed_ice
setblock 151 104 315 minecraft:snow_block
fill 151 104 316 151 105 316 minecraft:packed_ice
setblock 152 104 278 minecraft:light[level=15]
setblock 152 104 286 minecraft:light[level=15]
setblock 152 104 294 minecraft:light[level=15]
setblock 152 104 302 minecraft:light[level=15]
fill 152 104 308 152 104 309 minecraft:blue_ice
setblock 152 104 310 minecraft:light[level=15]
fill 152 104 312 153 104 312 minecraft:packed_ice
setblock 152 104 314 minecraft:snow_block
fill 152 104 315 152 105 315 minecraft:packed_ice
setblock 153 104 313 minecraft:snow_block
fill 153 104 314 153 105 314 minecraft:packed_ice
setblock 154 104 312 minecraft:snow_block
fill 154 104 313 154 105 313 minecraft:packed_ice
setblock 155 104 276 minecraft:snow_block
setblock 155 104 312 minecraft:packed_ice
setblock 155 104 316 minecraft:snow_block
fill 156 104 276 156 105 276 minecraft:packed_ice
setblock 156 104 301 minecraft:blue_ice
setblock 156 104 315 minecraft:snow_block
fill 156 104 316 156 105 316 minecraft:packed_ice
setblock 157 104 314 minecraft:snow_block
fill 157 104 315 157 105 315 minecraft:packed_ice
setblock 158 104 299 minecraft:blue_ice
setblock 158 104 313 minecraft:snow_block
fill 158 104 314 158 105 314 minecraft:packed_ice
fill 159 104 287 159 104 289 minecraft:blue_ice
setblock 160 104 278 minecraft:light[level=15]
setblock 160 104 294 minecraft:light[level=15]
fill 160 104 301 160 104 302 minecraft:blue_ice
setblock 160 104 310 minecraft:light[level=15]
setblock 160 104 316 minecraft:snow_block
setblock 161 104 315 minecraft:snow_block
fill 161 104 316 162 105 316 minecraft:packed_ice
setblock 163 104 286 minecraft:blue_ice
setblock 163 104 290 minecraft:blue_ice
setblock 168 104 278 minecraft:light[level=15]
setblock 168 104 286 minecraft:light[level=15]
setblock 168 104 294 minecraft:light[level=15]
setblock 168 104 302 minecraft:light[level=15]
setblock 168 104 310 minecraft:light[level=15]
setblock 169 104 316 minecraft:packed_ice
setblock 170 104 316 minecraft:snow_block
fill 171 104 276 171 105 276 minecraft:packed_ice
setblock 171 104 315 minecraft:snow_block
fill 171 104 316 174 104 316 minecraft:packed_ice
fill 172 104 315 175 104 315 minecraft:packed_ice
setblock 173 104 277 minecraft:packed_ice
setblock 174 104 277 minecraft:snow_block
setblock 175 104 276 minecraft:snow_block
fill 175 104 277 175 105 277 minecraft:packed_ice
setblock 175 104 316 minecraft:snow_block
fill 176 104 276 176 105 276 minecraft:packed_ice
setblock 176 104 278 minecraft:light[level=15]
setblock 176 104 286 minecraft:light[level=15]
setblock 176 104 294 minecraft:light[level=15]
setblock 176 104 302 minecraft:light[level=15]
setblock 176 104 310 minecraft:light[level=15]
setblock 176 104 315 minecraft:snow_block
fill 176 104 316 176 105 316 minecraft:packed_ice
fill 177 104 315 177 105 315 minecraft:packed_ice
setblock 178 104 277 minecraft:packed_ice
setblock 179 104 277 minecraft:snow_block
setblock 179 104 287 minecraft:snow_block
setblock 179 104 288 minecraft:packed_ice
setblock 179 104 291 minecraft:packed_ice
setblock 180 104 276 minecraft:snow_block
setblock 180 104 286 minecraft:snow_block
fill 180 104 287 180 105 287 minecraft:packed_ice
setblock 180 104 291 minecraft:snow_block
fill 180 104 292 180 105 292 minecraft:packed_ice
setblock 180 104 316 minecraft:snow_block
fill 181 104 276 181 105 276 minecraft:packed_ice
setblock 181 104 285 minecraft:snow_block
fill 181 104 286 181 105 286 minecraft:packed_ice
setblock 181 104 290 minecraft:snow_block
fill 181 104 291 181 105 291 minecraft:packed_ice
fill 181 104 316 181 105 316 minecraft:packed_ice
setblock 182 104 279 minecraft:snow_block
fill 182 104 280 182 105 280 minecraft:packed_ice
setblock 182 104 284 minecraft:snow_block
fill 182 104 285 182 105 285 minecraft:packed_ice
setblock 182 104 289 minecraft:snow_block
fill 182 104 290 182 105 290 minecraft:packed_ice
setblock 182 104 294 minecraft:snow_block
fill 182 104 295 182 105 295 minecraft:packed_ice
setblock 182 104 309 minecraft:snow_block
fill 182 104 310 182 105 310 minecraft:packed_ice
setblock 182 104 314 minecraft:snow_block
fill 182 104 315 182 105 315 minecraft:packed_ice
setblock 141 105 287 minecraft:white_concrete
fill 141 105 294 141 165 294 minecraft:blue_ice
setblock 142 105 288 minecraft:snow_block
setblock 142 105 289 minecraft:packed_ice
setblock 142 105 308 minecraft:snow_block
setblock 142 105 309 minecraft:packed_ice
setblock 142 105 313 minecraft:snow_block
fill 142 105 314 142 105 316 minecraft:packed_ice
setblock 143 105 312 minecraft:snow_block
setblock 143 105 313 minecraft:packed_ice
fill 143 105 315 143 105 316 minecraft:packed_ice
setblock 144 105 276 minecraft:snow_block
setblock 144 105 315 minecraft:packed_ice
setblock 144 105 316 minecraft:snow_block
fill 145 105 276 148 105 276 minecraft:packed_ice
setblock 145 105 315 minecraft:snow_block
setblock 145 105 316 minecraft:packed_ice
fill 145 105 317 145 164 317 minecraft:blue_ice
setblock 146 105 314 minecraft:snow_block
setblock 146 105 315 minecraft:packed_ice
fill 147 105 314 150 105 314 minecraft:packed_ice
setblock 149 105 276 minecraft:snow_block
fill 149 105 313 151 105 313 minecraft:packed_ice
setblock 149 105 316 minecraft:snow_block
setblock 150 105 276 minecraft:packed_ice
setblock 150 105 315 minecraft:snow_block
setblock 150 105 316 minecraft:packed_ice
setblock 151 105 314 minecraft:snow_block
setblock 151 105 315 minecraft:packed_ice
setblock 152 105 313 minecraft:snow_block
setblock 152 105 314 minecraft:packed_ice
setblock 153 105 312 minecraft:snow_block
setblock 153 105 313 minecraft:packed_ice
setblock 154 105 276 minecraft:snow_block
setblock 154 105 312 minecraft:packed_ice
setblock 154 105 316 minecraft:snow_block
setblock 155 105 276 minecraft:packed_ice
setblock 155 105 315 minecraft:snow_block
setblock 155 105 316 minecraft:packed_ice
setblock 156 105 314 minecraft:snow_block
setblock 156 105 315 minecraft:packed_ice
setblock 157 105 313 minecraft:snow_block
setblock 157 105 314 minecraft:packed_ice
setblock 159 105 316 minecraft:snow_block
setblock 160 105 315 minecraft:snow_block
setblock 160 105 316 minecraft:packed_ice
setblock 168 105 316 minecraft:packed_ice
setblock 169 105 316 minecraft:snow_block
setblock 170 105 276 minecraft:packed_ice
fill 170 105 316 173 105 316 minecraft:packed_ice
fill 171 105 315 174 105 315 minecraft:packed_ice
setblock 173 105 277 minecraft:snow_block
setblock 174 105 276 minecraft:snow_block
setblock 174 105 277 minecraft:packed_ice
setblock 174 105 316 minecraft:snow_block
setblock 175 105 276 minecraft:packed_ice
setblock 175 105 315 minecraft:snow_block
setblock 175 105 316 minecraft:packed_ice
setblock 176 105 315 minecraft:packed_ice
setblock 178 105 277 minecraft:snow_block
setblock 179 105 276 minecraft:snow_block
setblock 179 105 277 minecraft:packed_ice
setblock 179 105 316 minecraft:snow_block
setblock 180 105 276 minecraft:packed_ice
setblock 180 105 290 minecraft:snow_block
setblock 180 105 291 minecraft:packed_ice
setblock 180 105 316 minecraft:packed_ice
setblock 181 105 285 minecraft:packed_ice
setblock 181 105 289 minecraft:snow_block
setblock 181 105 290 minecraft:packed_ice
setblock 182 105 278 minecraft:snow_block
setblock 182 105 279 minecraft:packed_ice
setblock 182 105 283 minecraft:snow_block
setblock 182 105 284 minecraft:packed_ice
setblock 182 105 288 minecraft:snow_block
setblock 182 105 289 minecraft:packed_ice
setblock 182 105 293 minecraft:snow_block
setblock 182 105 294 minecraft:packed_ice
setblock 182 105 313 minecraft:snow_block
setblock 182 105 314 minecraft:packed_ice
fill 141 106 287 141 118 287 minecraft:blue_ice
setblock 143 106 275 minecraft:light_blue_concrete
fill 144 106 275 144 138 275 minecraft:blue_ice
setblock 149 106 317 minecraft:light_blue_concrete
fill 150 106 317 151 112 317 minecraft:blue_ice
fill 164 106 275 165 116 275 minecraft:blue_ice
setblock 166 106 275 minecraft:white_concrete
setblock 141 107 305 minecraft:light_blue_concrete
fill 141 107 306 141 136 306 minecraft:blue_ice
fill 143 107 275 143 161 275 minecraft:blue_ice
fill 149 107 317 149 166 317 minecraft:blue_ice
fill 166 107 275 166 165 275 minecraft:blue_ice
setblock 183 107 316 minecraft:light_blue_concrete
fill 183 107 317 183 165 317 minecraft:blue_ice
fill 141 108 305 141 138 305 minecraft:blue_ice
setblock 141 108 314 minecraft:light_blue_concrete
fill 141 108 315 141 151 315 minecraft:blue_ice
setblock 144 108 278 minecraft:light[level=12]
setblock 144 108 285 minecraft:light[level=12]
setblock 144 108 292 minecraft:light[level=12]
setblock 144 108 299 minecraft:light[level=12]
setblock 144 108 306 minecraft:light[level=12]
setblock 144 108 313 minecraft:light[level=12]
setblock 151 108 278 minecraft:light[level=12]
setblock 151 108 285 minecraft:light[level=12]
setblock 151 108 292 minecraft:light[level=12]
setblock 151 108 299 minecraft:light[level=12]
setblock 151 108 306 minecraft:light[level=12]
setblock 151 108 313 minecraft:light[level=12]
setblock 158 108 278 minecraft:light[level=12]
setblock 158 108 285 minecraft:light[level=12]
setblock 158 108 292 minecraft:light[level=12]
setblock 158 108 299 minecraft:light[level=12]
setblock 158 108 306 minecraft:light[level=12]
setblock 158 108 313 minecraft:light[level=12]
setblock 165 108 278 minecraft:light[level=12]
setblock 165 108 285 minecraft:light[level=12]
setblock 165 108 292 minecraft:light[level=12]
setblock 165 108 299 minecraft:light[level=12]
setblock 165 108 306 minecraft:light[level=12]
setblock 165 108 313 minecraft:light[level=12]
setblock 172 108 278 minecraft:light[level=12]
setblock 172 108 285 minecraft:light[level=12]
setblock 172 108 292 minecraft:light[level=12]
setblock 172 108 299 minecraft:light[level=12]
setblock 172 108 306 minecraft:light[level=12]
setblock 172 108 313 minecraft:light[level=12]
setblock 179 108 278 minecraft:light[level=12]
setblock 179 108 285 minecraft:light[level=12]
setblock 179 108 292 minecraft:light[level=12]
setblock 179 108 299 minecraft:light[level=12]
setblock 179 108 306 minecraft:light[level=12]
setblock 179 108 313 minecraft:light[level=12]
fill 183 108 316 183 120 316 minecraft:blue_ice
fill 141 109 314 141 135 314 minecraft:blue_ice
fill 150 109 275 151 165 275 minecraft:blue_ice
setblock 152 109 275 minecraft:white_concrete
fill 153 109 275 157 125 275 minecraft:blue_ice
fill 152 110 275 152 126 275 minecraft:blue_ice
fill 160 110 275 160 165 275 minecraft:blue_ice
setblock 161 110 275 minecraft:light_blue_concrete
fill 162 110 275 162 163 275 minecraft:blue_ice
fill 142 111 276 142 112 279 minecraft:light_blue_stained_glass
fill 142 111 280 142 112 280 minecraft:white_stained_glass
fill 142 111 281 142 112 302 minecraft:light_blue_stained_glass
fill 142 111 303 142 112 303 minecraft:white_stained_glass
fill 142 111 304 143 112 310 minecraft:light_blue_stained_glass
fill 142 111 311 142 112 311 minecraft:white_stained_glass
fill 142 111 312 144 112 316 minecraft:light_blue_stained_glass
fill 143 111 276 143 112 277 minecraft:light_blue_stained_glass
fill 143 111 278 143 112 278 minecraft:white_stained_glass
fill 143 111 279 143 112 285 minecraft:light_blue_stained_glass
fill 143 111 286 143 112 286 minecraft:white_stained_glass
fill 143 111 287 143 112 293 minecraft:light_blue_stained_glass
fill 143 111 294 143 112 294 minecraft:white_stained_glass
fill 143 111 295 143 112 303 minecraft:light_blue_stained_glass
fill 143 111 311 150 112 311 minecraft:light_blue_stained_glass
fill 144 111 276 144 112 276 minecraft:white_stained_glass
fill 144 111 277 144 112 283 minecraft:light_blue_stained_glass
fill 144 111 284 144 112 284 minecraft:white_stained_glass
fill 144 111 285 144 112 291 minecraft:light_blue_stained_glass
fill 144 111 292 144 112 292 minecraft:white_stained_glass
fill 144 111 293 144 112 299 minecraft:light_blue_stained_glass
fill 144 111 300 144 112 300 minecraft:white_stained_glass
fill 144 111 301 144 112 307 minecraft:light_blue_stained_glass
fill 144 111 308 144 112 308 minecraft:white_stained_glass
fill 144 111 309 146 112 310 minecraft:light_blue_stained_glass
fill 145 111 276 146 112 281 minecraft:light_blue_stained_glass
fill 145 111 282 145 112 282 minecraft:white_stained_glass
fill 145 111 283 146 112 289 minecraft:light_blue_stained_glass
fill 145 111 290 145 112 290 minecraft:white_stained_glass
fill 145 111 291 145 112 297 minecraft:light_blue_stained_glass
fill 145 111 298 145 112 298 minecraft:white_stained_glass
fill 145 111 299 145 112 305 minecraft:light_blue_stained_glass
fill 145 111 306 145 112 306 minecraft:white_stained_glass
fill 145 111 307 148 112 308 minecraft:light_blue_stained_glass
fill 145 111 312 145 112 313 minecraft:light_blue_stained_glass
fill 145 111 314 145 112 314 minecraft:white_stained_glass
fill 145 111 315 147 112 316 minecraft:light_blue_stained_glass
fill 146 111 282 153 112 282 minecraft:light_blue_stained_glass
fill 146 111 290 147 112 295 minecraft:light_blue_stained_glass
fill 146 111 296 146 112 296 minecraft:white_stained_glass
fill 146 111 297 147 112 303 minecraft:light_blue_stained_glass
fill 146 111 304 146 112 304 minecraft:white_stained_glass
fill 146 111 305 149 112 306 minecraft:light_blue_stained_glass
fill 146 111 312 146 112 312 minecraft:white_stained_glass
fill 146 111 313 149 112 314 minecraft:light_blue_stained_glass
fill 147 111 276 147 112 278 minecraft:light_blue_stained_glass
fill 147 111 279 147 112 279 minecraft:white_stained_glass
fill 147 111 280 150 112 281 minecraft:light_blue_stained_glass
fill 147 111 283 147 112 286 minecraft:light_blue_stained_glass
fill 147 111 287 147 112 287 minecraft:white_stained_glass
fill 147 111 288 149 112 289 minecraft:light_blue_stained_glass
fill 147 111 296 154 111 296 minecraft:light_blue_stained_glass
fill 147 111 304 154 112 304 minecraft:light_blue_stained_glass
fill 147 111 309 151 112 309 minecraft:light_blue_stained_glass
fill 147 111 310 147 112 310 minecraft:white_stained_glass
fill 147 111 312 154 112 312 minecraft:light_blue_stained_glass
fill 148 111 276 152 112 276 minecraft:light_blue_stained_glass
fill 148 111 277 148 112 277 minecraft:white_stained_glass
fill 148 111 278 151 112 279 minecraft:light_blue_stained_glass
fill 148 111 283 148 112 284 minecraft:light_blue_stained_glass
fill 148 111 285 148 112 285 minecraft:white_stained_glass
fill 148 111 286 151 112 287 minecraft:light_blue_stained_glass
fill 148 111 290 148 112 292 minecraft:light_blue_stained_glass
fill 148 111 293 148 112 293 minecraft:white_stained_glass
fill 148 111 294 151 112 295 minecraft:light_blue_stained_glass
fill 148 111 297 148 112 300 minecraft:light_blue_stained_glass
fill 148 111 301 148 112 301 minecraft:white_stained_glass
fill 148 111 302 150 112 303 minecraft:light_blue_stained_glass
fill 148 111 310 155 112 310 minecraft:light_blue_stained_glass
fill 148 111 315 170 112 315 minecraft:light_blue_stained_glass
fill 148 111 316 148 112 316 minecraft:white_stained_glass
fill 149 111 277 156 112 277 minecraft:light_blue_stained_glass
fill 149 111 283 149 112 283 minecraft:white_stained_glass
fill 149 111 284 152 112 285 minecraft:light_blue_stained_glass
fill 149 111 290 153 112 290 minecraft:light_blue_stained_glass
fill 149 111 291 149 112 291 minecraft:white_stained_glass
fill 149 111 292 152 112 293 minecraft:light_blue_stained_glass
fill 149 111 297 149 112 298 minecraft:light_blue_stained_glass
fill 149 111 299 149 112 299 minecraft:white_stained_glass
fill 149 111 300 152 112 301 minecraft:light_blue_stained_glass
fill 149 111 307 149 112 307 minecraft:white_stained_glass
fill 149 111 308 174 112 308 minecraft:light_blue_stained_glass
fill 149 111 316 156 112 316 minecraft:light_blue_stained_glass
fill 150 111 283 157 112 283 minecraft:light_blue_stained_glass
fill 150 111 288 163 112 288 minecraft:light_blue_stained_glass
fill 150 111 289 150 112 289 minecraft:white_stained_glass
fill 150 111 291 157 112 291 minecraft:light_blue_stained_glass
fill 150 111 297 150 112 297 minecraft:white_stained_glass
fill 150 111 298 153 112 299 minecraft:light_blue_stained_glass
fill 150 111 305 150 112 305 minecraft:white_stained_glass
fill 150 111 306 153 112 307 minecraft:light_blue_stained_glass
fill 150 111 313 150 112 313 minecraft:white_stained_glass
fill 150 111 314 153 112 314 minecraft:light_blue_stained_glass
fill 151 111 280 151 112 280 minecraft:white_stained_glass
fill 151 111 281 167 112 281 minecraft:light_blue_stained_glass
fill 151 111 289 158 112 289 minecraft:light_blue_stained_glass
fill 151 111 297 155 111 297 minecraft:light_blue_stained_glass
fill 151 111 302 155 112 302 minecraft:light_blue_stained_glass
fill 151 111 303 151 112 303 minecraft:white_stained_glass
fill 151 111 305 158 112 305 minecraft:light_blue_stained_glass
fill 151 111 311 151 112 311 minecraft:white_stained_glass
fill 151 111 313 158 112 313 minecraft:light_blue_stained_glass
fill 152 111 278 152 112 278 minecraft:white_stained_glass
fill 152 111 279 155 112 280 minecraft:light_blue_stained_glass
fill 152 111 286 152 112 286 minecraft:white_stained_glass
fill 152 111 287 155 112 287 minecraft:light_blue_stained_glass
fill 152 111 294 152 112 294 minecraft:white_stained_glass
fill 152 111 295 155 111 295 minecraft:light_blue_stained_glass
fill 152 111 303 159 112 303 minecraft:light_blue_stained_glass
fill 152 111 309 152 112 309 minecraft:white_stained_glass
fill 152 111 311 159 112 311 minecraft:light_blue_stained_glass
fill 153 111 276 153 112 276 minecraft:white_stained_glass
fill 153 111 278 160 112 278 minecraft:light_blue_stained_glass
fill 153 111 284 153 112 284 minecraft:white_stained_glass
fill 153 111 285 156 112 286 minecraft:light_blue_stained_glass
fill 153 111 292 153 112 292 minecraft:white_stained_glass
fill 153 111 293 155 111 294 minecraft:light_blue_stained_glass
fill 153 111 300 153 112 300 minecraft:white_stained_glass
fill 153 111 301 178 112 301 minecraft:light_blue_stained_glass
fill 153 111 309 160 112 309 minecraft:light_blue_stained_glass
fill 154 111 276 161 112 276 minecraft:light_blue_stained_glass
fill 154 111 282 154 112 282 minecraft:white_stained_glass
fill 154 111 284 161 112 284 minecraft:light_blue_stained_glass
fill 154 111 290 154 112 290 minecraft:white_stained_glass
fill 154 111 292 161 111 292 minecraft:light_blue_stained_glass
fill 154 111 298 154 112 298 minecraft:white_stained_glass
fill 154 111 299 157 111 300 minecraft:light_blue_stained_glass
fill 154 111 306 154 112 306 minecraft:white_stained_glass
fill 154 111 307 157 112 307 minecraft:light_blue_stained_glass
fill 154 111 314 154 112 314 minecraft:white_stained_glass
fill 155 111 282 162 112 282 minecraft:light_blue_stained_glass
fill 155 111 290 162 112 290 minecraft:light_blue_stained_glass
setblock 155 111 298 minecraft:light_blue_stained_glass
fill 155 111 304 155 112 304 minecraft:white_stained_glass
fill 155 111 306 162 112 306 minecraft:light_blue_stained_glass
fill 155 111 312 155 112 312 minecraft:white_stained_glass
fill 155 111 314 162 112 314 minecraft:light_blue_stained_glass
fill 156 111 279 156 112 279 minecraft:white_stained_glass
fill 156 111 280 159 112 280 minecraft:light_blue_stained_glass
fill 156 111 287 156 112 287 minecraft:white_stained_glass
setblock 156 111 293 minecraft:light_blue_stained_glass
fill 156 111 302 156 112 302 minecraft:white_stained_glass
fill 156 111 304 163 112 304 minecraft:light_blue_stained_glass
fill 156 111 310 156 112 310 minecraft:white_stained_glass
fill 156 111 312 163 112 312 minecraft:light_blue_stained_glass
fill 157 111 277 157 112 277 minecraft:white_stained_glass
fill 157 111 279 164 112 279 minecraft:light_blue_stained_glass
fill 157 111 285 157 112 285 minecraft:white_stained_glass
fill 157 111 286 160 112 287 minecraft:light_blue_stained_glass
setblock 157 111 293 minecraft:white_stained_glass
fill 157 111 302 164 112 302 minecraft:light_blue_stained_glass
fill 157 111 310 164 112 310 minecraft:light_blue_stained_glass
fill 157 111 316 157 112 316 minecraft:white_stained_glass
fill 158 111 277 165 112 277 minecraft:light_blue_stained_glass
fill 158 111 283 158 112 283 minecraft:white_stained_glass
fill 158 111 285 165 112 285 minecraft:light_blue_stained_glass
fill 158 111 291 158 112 291 minecraft:white_stained_glass
fill 158 111 300 161 111 300 minecraft:light_blue_stained_glass
fill 158 111 307 158 112 307 minecraft:white_stained_glass
fill 158 111 316 165 112 316 minecraft:light_blue_stained_glass
fill 159 111 283 166 112 283 minecraft:light_blue_stained_glass
fill 159 111 289 159 112 289 minecraft:white_stained_glass
fill 159 111 291 166 112 291 minecraft:light_blue_stained_glass
fill 159 111 293 165 111 293 minecraft:light_blue_stained_glass
fill 159 111 299 166 111 299 minecraft:light_blue_stained_glass
fill 159 111 305 159 112 305 minecraft:white_stained_glass
fill 159 111 307 166 112 307 minecraft:light_blue_stained_glass
fill 159 111 313 159 112 313 minecraft:white_stained_glass
fill 160 111 280 160 112 280 minecraft:white_stained_glass
fill 160 111 289 167 112 289 minecraft:light_blue_stained_glass
fill 160 111 303 160 112 303 minecraft:white_stained_glass
fill 160 111 305 167 112 305 minecraft:light_blue_stained_glass
fill 160 111 311 160 112 311 minecraft:white_stained_glass
fill 160 111 313 167 112 313 minecraft:light_blue_stained_glass
fill 161 111 275 161 165 275 minecraft:blue_ice
fill 161 111 278 161 112 278 minecraft:white_stained_glass
fill 161 111 280 182 112 280 minecraft:light_blue_stained_glass
fill 161 111 286 161 112 286 minecraft:white_stained_glass
fill 161 111 287 182 112 287 minecraft:light_blue_stained_glass
fill 161 111 294 168 111 295 minecraft:light_blue_stained_glass
fill 161 111 297 162 111 298 minecraft:light_blue_stained_glass
fill 161 111 303 168 112 303 minecraft:light_blue_stained_glass
fill 161 111 309 161 112 309 minecraft:white_stained_glass
fill 161 111 311 168 112 311 minecraft:light_blue_stained_glass
fill 162 111 276 162 112 276 minecraft:white_stained_glass
fill 162 111 278 169 112 278 minecraft:light_blue_stained_glass
fill 162 111 284 162 112 284 minecraft:white_stained_glass
fill 162 111 286 169 112 286 minecraft:light_blue_stained_glass
fill 162 111 292 162 112 292 minecraft:white_stained_glass
fill 162 111 296 163 111 296 minecraft:light_blue_stained_glass
fill 162 111 300 162 112 300 minecraft:white_stained_glass
fill 162 111 309 169 112 309 minecraft:light_blue_stained_glass
fill 163 111 276 170 112 276 minecraft:light_blue_stained_glass
fill 163 111 282 163 112 282 minecraft:white_stained_glass
fill 163 111 284 170 112 284 minecraft:light_blue_stained_glass
fill 163 111 290 163 112 290 minecraft:white_stained_glass
fill 163 111 292 170 112 292 minecraft:light_blue_stained_glass
fill 163 111 297 167 112 297 minecraft:light_blue_stained_glass
fill 163 111 298 163 112 298 minecraft:white_stained_glass
fill 163 111 300 170 112 300 minecraft:light_blue_stained_glass
fill 163 111 306 163 112 306 minecraft:white_stained_glass
fill 163 111 314 163 112 314 minecraft:white_stained_glass
fill 164 111 282 171 112 282 minecraft:light_blue_stained_glass
fill 164 111 288 164 112 288 minecraft:white_stained_glass
fill 164 111 290 171 112 290 minecraft:light_blue_stained_glass
fill 164 111 296 164 112 296 minecraft:white_stained_glass
fill 164 111 298 171 112 298 minecraft:light_blue_stained_glass
fill 164 111 304 164 112 304 minecraft:white_stained_glass
fill 164 111 306 171 112 306 minecraft:light_blue_stained_glass
fill 164 111 312 164 112 312 minecraft:white_stained_glass
fill 164 111 314 182 112 314 minecraft:light_blue_stained_glass
fill 165 111 279 165 112 279 minecraft:white_stained_glass
fill 165 111 288 172 112 288 minecraft:light_blue_stained_glass
fill 165 111 296 172 112 296 minecraft:light_blue_stained_glass
fill 165 111 302 165 112 302 minecraft:white_stained_glass
fill 165 111 304 172 112 304 minecraft:light_blue_stained_glass
fill 165 111 310 165 112 310 minecraft:white_stained_glass
fill 165 111 312 172 112 312 minecraft:light_blue_stained_glass
fill 166 111 277 166 112 277 minecraft:white_stained_glass
fill 166 111 279 173 112 279 minecraft:light_blue_stained_glass
fill 166 111 285 166 112 285 minecraft:white_stained_glass
fill 166 111 293 166 112 293 minecraft:white_stained_glass
fill 166 111 302 173 112 302 minecraft:light_blue_stained_glass
fill 166 111 310 173 112 310 minecraft:light_blue_stained_glass
fill 166 111 316 166 112 316 minecraft:white_stained_glass
fill 167 111 277 174 112 277 minecraft:light_blue_stained_glass
fill 167 111 283 167 112 283 minecraft:white_stained_glass
fill 167 111 285 174 112 285 minecraft:light_blue_stained_glass
fill 167 111 291 167 112 291 minecraft:white_stained_glass
fill 167 111 293 174 112 293 minecraft:light_blue_stained_glass
fill 167 111 299 167 112 299 minecraft:white_stained_glass
fill 167 111 307 167 112 307 minecraft:white_stained_glass
fill 167 111 316 174 112 316 minecraft:light_blue_stained_glass
fill 168 111 281 168 112 281 minecraft:white_stained_glass
fill 168 111 283 175 112 283 minecraft:light_blue_stained_glass
fill 168 111 289 168 112 289 minecraft:white_stained_glass
fill 168 111 291 175 112 291 minecraft:light_blue_stained_glass
fill 168 111 297 168 112 297 minecraft:white_stained_glass
fill 168 111 299 175 112 299 minecraft:light_blue_stained_glass
fill 168 111 305 168 112 305 minecraft:white_stained_glass
fill 168 111 307 182 112 307 minecraft:light_blue_stained_glass
fill 168 111 313 168 112 313 minecraft:white_stained_glass
fill 169 111 281 176 112 281 minecraft:light_blue_stained_glass
fill 169 111 289 176 112 289 minecraft:light_blue_stained_glass
fill 169 111 294 182 112 294 minecraft:light_blue_stained_glass
fill 169 111 295 169 112 295 minecraft:white_stained_glass
fill 169 111 297 176 112 297 minecraft:light_blue_stained_glass
fill 169 111 303 169 112 303 minecraft:white_stained_glass
fill 169 111 305 176 112 305 minecraft:light_blue_stained_glass
fill 169 111 311 169 112 311 minecraft:white_stained_glass
fill 169 111 313 176 112 313 minecraft:light_blue_stained_glass
fill 170 111 278 170 112 278 minecraft:white_stained_glass
fill 170 111 286 170 112 286 minecraft:white_stained_glass
fill 170 111 295 177 112 295 minecraft:light_blue_stained_glass
fill 170 111 303 177 112 303 minecraft:light_blue_stained_glass
fill 170 111 309 170 112 309 minecraft:white_stained_glass
fill 170 111 311 177 112 311 minecraft:light_blue_stained_glass
fill 171 111 276 171 112 276 minecraft:white_stained_glass
fill 171 111 278 178 112 278 minecraft:light_blue_stained_glass
fill 171 111 284 171 112 284 minecraft:white_stained_glass
fill 171 111 286 178 112 286 minecraft:light_blue_stained_glass
fill 171 111 292 171 112 292 minecraft:white_stained_glass
fill 171 111 300 171 112 300 minecraft:white_stained_glass
fill 171 111 309 178 112 309 minecraft:light_blue_stained_glass
fill 171 111 315 171 112 315 minecraft:white_stained_glass
fill 172 111 276 179 112 276 minecraft:light_blue_stained_glass
fill 172 111 282 172 112 282 minecraft:white_stained_glass
fill 172 111 284 179 112 284 minecraft:light_blue_stained_glass
fill 172 111 290 172 112 290 minecraft:white_stained_glass
fill 172 111 292 179 112 292 minecraft:light_blue_stained_glass
fill 172 111 298 172 112 298 minecraft:white_stained_glass
fill 172 111 300 182 112 300 minecraft:light_blue_stained_glass
fill 172 111 306 172 112 306 minecraft:white_stained_glass
fill 172 111 315 179 112 315 minecraft:light_blue_stained_glass
fill 173 111 282 180 112 282 minecraft:light_blue_stained_glass
fill 173 111 288 173 112 288 minecraft:white_stained_glass
fill 173 111 290 180 112 290 minecraft:light_blue_stained_glass
fill 173 111 296 173 112 296 minecraft:white_stained_glass
fill 173 111 298 180 112 298 minecraft:light_blue_stained_glass
fill 173 111 304 173 112 304 minecraft:white_stained_glass
fill 173 111 306 180 112 306 minecraft:light_blue_stained_glass
fill 173 111 312 173 112 312 minecraft:white_stained_glass
fill 174 111 279 174 112 279 minecraft:white_stained_glass
fill 174 111 288 181 112 288 minecraft:light_blue_stained_glass
fill 174 111 296 181 112 296 minecraft:light_blue_stained_glass
fill 174 111 302 174 112 302 minecraft:white_stained_glass
fill 174 111 304 181 112 304 minecraft:light_blue_stained_glass
fill 174 111 310 174 112 310 minecraft:white_stained_glass
fill 174 111 312 181 112 312 minecraft:light_blue_stained_glass
fill 175 111 277 175 112 277 minecraft:white_stained_glass
fill 175 111 279 182 112 279 minecraft:light_blue_stained_glass
fill 175 111 285 175 112 285 minecraft:white_stained_glass
fill 175 111 293 175 112 293 minecraft:white_stained_glass
fill 175 111 302 182 112 302 minecraft:light_blue_stained_glass
fill 175 111 308 175 112 308 minecraft:white_stained_glass
fill 175 111 310 182 112 310 minecraft:light_blue_stained_glass
fill 175 111 316 175 112 316 minecraft:white_stained_glass
fill 176 111 277 182 112 277 minecraft:light_blue_stained_glass
fill 176 111 283 176 112 283 minecraft:white_stained_glass
fill 176 111 285 182 112 285 minecraft:light_blue_stained_glass
fill 176 111 291 176 112 291 minecraft:white_stained_glass
fill 176 111 293 182 112 293 minecraft:light_blue_stained_glass
fill 176 111 299 176 112 299 minecraft:white_stained_glass
fill 176 111 308 182 112 308 minecraft:light_blue_stained_glass
fill 176 111 316 182 112 316 minecraft:light_blue_stained_glass
fill 177 111 281 177 112 281 minecraft:white_stained_glass
fill 177 111 283 182 112 283 minecraft:light_blue_stained_glass
fill 177 111 289 177 112 289 minecraft:white_stained_glass
fill 177 111 291 182 112 291 minecraft:light_blue_stained_glass
fill 177 111 297 177 112 297 minecraft:white_stained_glass
fill 177 111 299 182 112 299 minecraft:light_blue_stained_glass
fill 177 111 305 177 112 305 minecraft:white_stained_glass
fill 177 111 313 177 112 313 minecraft:white_stained_glass
fill 178 111 281 182 112 281 minecraft:light_blue_stained_glass
fill 178 111 289 182 112 289 minecraft:light_blue_stained_glass
fill 178 111 295 178 112 295 minecraft:white_stained_glass
fill 178 111 297 182 112 297 minecraft:light_blue_stained_glass
fill 178 111 303 178 112 303 minecraft:white_stained_glass
fill 178 111 305 182 112 305 minecraft:light_blue_stained_glass
fill 178 111 311 178 112 311 minecraft:white_stained_glass
fill 178 111 313 182 112 313 minecraft:light_blue_stained_glass
fill 179 111 278 179 112 278 minecraft:white_stained_glass
fill 179 111 286 179 112 286 minecraft:white_stained_glass
fill 179 111 295 182 112 295 minecraft:light_blue_stained_glass
fill 179 111 301 179 112 301 minecraft:white_stained_glass
fill 179 111 303 182 112 303 minecraft:light_blue_stained_glass
fill 179 111 309 179 112 309 minecraft:white_stained_glass
fill 179 111 311 182 112 311 minecraft:light_blue_stained_glass
fill 180 111 276 180 112 276 minecraft:white_stained_glass
fill 180 111 278 182 112 278 minecraft:light_blue_stained_glass
fill 180 111 284 180 112 284 minecraft:white_stained_glass
fill 180 111 286 182 112 286 minecraft:light_blue_stained_glass
fill 180 111 292 180 112 292 minecraft:white_stained_glass
fill 180 111 301 182 112 301 minecraft:light_blue_stained_glass
fill 180 111 309 182 112 309 minecraft:light_blue_stained_glass
fill 180 111 315 180 112 315 minecraft:white_stained_glass
fill 181 111 276 182 112 276 minecraft:light_blue_stained_glass
fill 181 111 282 181 112 282 minecraft:white_stained_glass
fill 181 111 284 182 112 284 minecraft:light_blue_stained_glass
fill 181 111 290 181 112 290 minecraft:white_stained_glass
fill 181 111 292 182 112 292 minecraft:light_blue_stained_glass
fill 181 111 298 181 112 298 minecraft:white_stained_glass
fill 181 111 306 181 112 306 minecraft:white_stained_glass
fill 181 111 315 182 112 315 minecraft:light_blue_stained_glass
fill 182 111 282 182 112 282 minecraft:light_blue_stained_glass
fill 182 111 288 182 112 288 minecraft:white_stained_glass
fill 182 111 290 182 112 290 minecraft:light_blue_stained_glass
fill 182 111 296 182 112 296 minecraft:white_stained_glass
fill 182 111 298 182 112 298 minecraft:light_blue_stained_glass
fill 182 111 304 182 112 304 minecraft:white_stained_glass
fill 182 111 306 182 112 306 minecraft:light_blue_stained_glass
fill 182 111 312 182 112 312 minecraft:white_stained_glass
fill 147 112 296 153 112 296 minecraft:light_blue_stained_glass
fill 151 112 297 153 112 297 minecraft:light_blue_stained_glass
fill 152 112 295 153 112 295 minecraft:light_blue_stained_glass
fill 153 112 293 154 112 294 minecraft:light_blue_stained_glass
fill 154 112 292 156 112 292 minecraft:light_blue_stained_glass
fill 154 112 295 154 112 297 minecraft:white_concrete
fill 154 112 299 154 112 300 minecraft:light_blue_stained_glass
fill 155 112 293 155 112 295 minecraft:white_concrete
fill 155 112 297 155 112 299 minecraft:white_concrete
fill 155 112 300 156 112 300 minecraft:light_blue_stained_glass
fill 156 112 293 157 112 293 minecraft:white_concrete
fill 156 112 299 157 112 299 minecraft:white_concrete
fill 157 112 292 159 112 292 minecraft:white_concrete
fill 157 112 300 159 112 300 minecraft:white_concrete
fill 159 112 293 161 112 293 minecraft:white_concrete
fill 159 112 299 161 112 299 minecraft:white_concrete
fill 160 112 292 161 112 292 minecraft:light_blue_stained_glass
fill 160 112 300 161 112 300 minecraft:light_blue_stained_glass
fill 161 112 294 161 112 295 minecraft:white_concrete
fill 161 112 297 161 112 298 minecraft:white_concrete
fill 162 112 293 165 112 294 minecraft:light_blue_stained_glass
fill 162 112 295 162 112 297 minecraft:white_concrete
fill 162 112 298 162 112 299 minecraft:light_blue_stained_glass
fill 163 112 295 163 112 296 minecraft:light_blue_stained_glass
fill 163 112 299 166 112 299 minecraft:light_blue_stained_glass
fill 164 112 295 168 112 295 minecraft:light_blue_stained_glass
fill 166 112 294 168 112 294 minecraft:light_blue_stained_glass
setblock 150 113 317 minecraft:white_concrete
fill 151 113 317 151 117 317 minecraft:blue_ice
fill 171 113 275 175 136 275 minecraft:blue_ice
setblock 176 113 275 minecraft:white_concrete
fill 177 113 275 177 165 275 minecraft:blue_ice
setblock 144 114 278 minecraft:light[level=12]
setblock 144 114 285 minecraft:light[level=12]
setblock 144 114 292 minecraft:light[level=12]
setblock 144 114 299 minecraft:light[level=12]
setblock 144 114 306 minecraft:light[level=12]
setblock 144 114 313 minecraft:light[level=12]
fill 150 114 317 150 142 317 minecraft:blue_ice
setblock 151 114 278 minecraft:light[level=12]
setblock 151 114 285 minecraft:light[level=12]
setblock 151 114 292 minecraft:light[level=12]
setblock 151 114 299 minecraft:light[level=12]
setblock 151 114 306 minecraft:light[level=12]
setblock 151 114 313 minecraft:light[level=12]
setblock 158 114 278 minecraft:light[level=12]
setblock 158 114 285 minecraft:light[level=12]
setblock 158 114 292 minecraft:light[level=12]
setblock 158 114 306 minecraft:light[level=12]
setblock 158 114 313 minecraft:light[level=12]
setblock 165 114 278 minecraft:light[level=12]
setblock 165 114 285 minecraft:light[level=12]
setblock 165 114 292 minecraft:light[level=12]
setblock 165 114 299 minecraft:light[level=12]
setblock 165 114 306 minecraft:light[level=12]
setblock 165 114 313 minecraft:light[level=12]
setblock 172 114 278 minecraft:light[level=12]
setblock 172 114 285 minecraft:light[level=12]
setblock 172 114 292 minecraft:light[level=12]
setblock 172 114 299 minecraft:light[level=12]
setblock 172 114 306 minecraft:light[level=12]
setblock 172 114 313 minecraft:light[level=12]
fill 176 114 275 176 118 275 minecraft:blue_ice
setblock 179 114 278 minecraft:light[level=12]
setblock 179 114 285 minecraft:light[level=12]
setblock 179 114 292 minecraft:light[level=12]
setblock 179 114 299 minecraft:light[level=12]
setblock 179 114 306 minecraft:light[level=12]
setblock 179 114 313 minecraft:light[level=12]
fill 141 115 295 141 166 295 minecraft:blue_ice
setblock 141 115 296 minecraft:white_concrete
fill 141 115 297 141 115 300 minecraft:blue_ice
fill 141 116 296 141 137 298 minecraft:blue_ice
setblock 141 116 299 minecraft:white_concrete
fill 141 116 300 141 165 300 minecraft:blue_ice
setblock 142 116 276 minecraft:packed_ice
setblock 142 116 277 minecraft:snow_block
fill 142 116 278 142 116 281 minecraft:packed_ice
setblock 142 116 282 minecraft:snow_block
fill 142 116 294 142 116 296 minecraft:packed_ice
setblock 142 116 297 minecraft:snow_block
fill 142 116 298 142 116 301 minecraft:packed_ice
setblock 142 116 302 minecraft:snow_block
fill 142 116 303 142 116 306 minecraft:packed_ice
setblock 142 116 307 minecraft:snow_block
fill 142 116 308 142 116 311 minecraft:packed_ice
setblock 142 116 312 minecraft:snow_block
fill 142 116 313 142 116 316 minecraft:packed_ice
setblock 143 116 276 minecraft:snow_block
fill 143 116 277 143 116 280 minecraft:packed_ice
setblock 143 116 296 minecraft:snow_block
fill 143 116 297 143 116 300 minecraft:packed_ice
setblock 143 116 301 minecraft:snow_block
fill 143 116 302 143 116 305 minecraft:packed_ice
setblock 143 116 306 minecraft:snow_block
fill 143 116 307 143 116 310 minecraft:packed_ice
setblock 143 116 311 minecraft:snow_block
fill 143 116 312 143 116 315 minecraft:packed_ice
setblock 143 116 316 minecraft:snow_block
fill 144 116 276 145 116 278 minecraft:packed_ice
fill 144 116 280 146 117 280 minecraft:snow_block
fill 144 116 297 144 116 299 minecraft:packed_ice
setblock 144 116 300 minecraft:snow_block
fill 144 116 301 144 116 304 minecraft:packed_ice
setblock 144 116 305 minecraft:snow_block
setblock 144 116 314 minecraft:packed_ice
setblock 144 116 315 minecraft:snow_block
fill 144 116 316 147 116 316 minecraft:packed_ice
fill 145 116 279 145 119 279 minecraft:snow_block
fill 145 116 281 145 119 281 minecraft:snow_block
setblock 145 116 299 minecraft:snow_block
fill 145 116 300 145 117 302 minecraft:packed_ice
setblock 145 116 314 minecraft:snow_block
fill 145 116 315 148 116 315 minecraft:packed_ice
fill 146 116 276 146 116 277 minecraft:packed_ice
setblock 146 116 278 minecraft:snow_block
fill 146 116 314 149 116 314 minecraft:packed_ice
setblock 147 116 276 minecraft:packed_ice
setblock 147 116 277 minecraft:snow_block
fill 147 116 278 149 117 278 minecraft:packed_ice
fill 147 116 299 148 200 300 minecraft:snow_block
setblock 148 116 276 minecraft:snow_block
fill 148 116 277 151 116 277 minecraft:packed_ice
fill 148 116 298 148 200 298 minecraft:snow_block
setblock 148 116 316 minecraft:snow_block
setblock 148 116 317 minecraft:white_concrete
fill 149 116 276 152 116 276 minecraft:packed_ice
fill 149 116 299 149 200 299 minecraft:snow_block
setblock 149 116 315 minecraft:snow_block
fill 149 116 316 152 116 316 minecraft:packed_ice
fill 150 116 315 152 116 315 minecraft:packed_ice
setblock 152 116 277 minecraft:snow_block
setblock 153 116 276 minecraft:snow_block
setblock 153 116 277 minecraft:packed_ice
setblock 153 116 316 minecraft:snow_block
fill 154 116 276 156 117 276 minecraft:packed_ice
fill 154 116 316 155 116 316 minecraft:packed_ice
fill 159 116 276 162 116 276 minecraft:packed_ice
fill 160 116 278 160 123 278 minecraft:packed_ice
setblock 162 116 277 minecraft:snow_block
setblock 163 116 276 minecraft:snow_block
fill 163 116 277 166 116 277 minecraft:packed_ice
setblock 163 116 316 minecraft:snow_block
fill 164 116 276 167 116 276 minecraft:packed_ice
fill 164 116 278 165 116 278 minecraft:packed_ice
fill 164 116 316 167 116 316 minecraft:packed_ice
setblock 166 116 278 minecraft:snow_block
fill 166 116 279 169 116 279 minecraft:packed_ice
setblock 167 116 277 minecraft:snow_block
fill 167 116 278 170 116 278 minecraft:packed_ice
fill 167 116 315 168 116 315 minecraft:packed_ice
setblock 168 116 276 minecraft:snow_block
fill 168 116 277 171 116 277 minecraft:packed_ice
setblock 168 116 316 minecraft:snow_block
fill 169 116 276 172 116 276 minecraft:packed_ice
setblock 169 116 315 minecraft:snow_block
fill 169 116 316 172 116 316 minecraft:packed_ice
setblock 170 116 279 minecraft:snow_block
fill 170 116 315 171 116 315 minecraft:packed_ice
setblock 171 116 278 minecraft:snow_block
fill 171 116 279 173 117 279 minecraft:packed_ice
setblock 172 116 277 minecraft:snow_block
fill 172 116 278 175 116 278 minecraft:packed_ice
setblock 173 116 276 minecraft:snow_block
fill 173 116 277 176 116 277 minecraft:packed_ice
setblock 173 116 316 minecraft:snow_block
fill 174 116 276 177 116 276 minecraft:packed_ice
fill 174 116 316 177 116 316 minecraft:packed_ice
setblock 176 116 278 minecraft:snow_block
setblock 177 116 277 minecraft:snow_block
fill 177 116 278 180 116 278 minecraft:packed_ice
setblock 178 116 276 minecraft:snow_block
fill 178 116 277 181 116 277 minecraft:packed_ice
setblock 178 116 316 minecraft:snow_block
fill 179 116 276 182 116 276 minecraft:packed_ice
fill 179 116 316 182 116 316 minecraft:packed_ice
setblock 180 116 279 minecraft:snow_block
setblock 181 116 278 minecraft:snow_block
fill 181 116 279 181 116 282 minecraft:packed_ice
setblock 182 116 277 minecraft:snow_block
fill 182 116 278 182 116 281 minecraft:packed_ice
setblock 182 116 282 minecraft:snow_block
fill 182 116 283 182 118 284 minecraft:packed_ice
fill 182 116 295 182 116 296 minecraft:packed_ice
setblock 182 116 297 minecraft:snow_block
fill 182 116 298 182 116 301 minecraft:packed_ice
setblock 182 116 302 minecraft:snow_block
fill 182 116 303 182 118 304 minecraft:packed_ice
setblock 182 116 312 minecraft:snow_block
fill 182 116 313 182 117 315 minecraft:packed_ice
fill 141 117 299 141 153 299 minecraft:blue_ice
setblock 142 117 276 minecraft:snow_block
fill 142 117 277 142 117 280 minecraft:packed_ice
setblock 142 117 281 minecraft:snow_block
fill 142 117 282 142 119 283 minecraft:packed_ice
fill 142 117 294 142 117 295 minecraft:packed_ice
setblock 142 117 296 minecraft:snow_block
fill 142 117 297 142 117 300 minecraft:packed_ice
setblock 142 117 301 minecraft:snow_block
fill 142 117 302 142 117 305 minecraft:packed_ice
setblock 142 117 306 minecraft:snow_block
fill 142 117 307 142 117 310 minecraft:packed_ice
setblock 142 117 311 minecraft:snow_block
fill 142 117 312 142 117 315 minecraft:packed_ice
setblock 142 117 316 minecraft:snow_block
fill 143 117 276 143 117 279 minecraft:packed_ice
setblock 143 117 280 minecraft:snow_block
fill 143 117 281 143 120 281 minecraft:packed_ice
setblock 143 117 295 minecraft:snow_block
fill 143 117 296 143 117 299 minecraft:packed_ice
setblock 143 117 300 minecraft:snow_block
fill 143 117 301 143 117 304 minecraft:packed_ice
setblock 143 117 305 minecraft:snow_block
fill 143 117 306 143 117 309 minecraft:packed_ice
setblock 143 117 310 minecraft:snow_block
fill 143 117 311 143 117 314 minecraft:packed_ice
setblock 143 117 315 minecraft:snow_block
fill 143 117 316 146 117 316 minecraft:packed_ice
fill 144 117 276 144 117 278 minecraft:packed_ice
setblock 144 117 279 minecraft:snow_block
fill 144 117 281 144 119 281 minecraft:snow_block
fill 144 117 297 144 117 298 minecraft:packed_ice
setblock 144 117 299 minecraft:snow_block
fill 144 117 300 144 117 303 minecraft:packed_ice
setblock 144 117 304 minecraft:snow_block
fill 144 117 305 144 118 307 minecraft:packed_ice
setblock 144 117 314 minecraft:snow_block
fill 144 117 315 147 117 315 minecraft:packed_ice
fill 145 117 276 145 117 277 minecraft:packed_ice
setblock 145 117 278 minecraft:snow_block
setblock 145 117 298 minecraft:snow_block
fill 145 117 299 146 118 299 minecraft:packed_ice
setblock 145 117 303 minecraft:snow_block
fill 145 117 304 145 120 304 minecraft:packed_ice
fill 145 117 314 148 117 314 minecraft:packed_ice
setblock 146 117 276 minecraft:packed_ice
setblock 146 117 277 minecraft:snow_block
fill 146 117 278 146 119 278 minecraft:packed_ice
fill 146 117 279 146 119 279 minecraft:snow_block
fill 146 117 281 146 119 281 minecraft:snow_block
fill 146 117 300 146 118 300 minecraft:packed_ice
setblock 147 117 276 minecraft:snow_block
fill 147 117 277 150 117 277 minecraft:packed_ice
fill 147 117 298 147 118 298 minecraft:packed_ice
fill 147 117 301 148 118 301 minecraft:packed_ice
setblock 147 117 316 minecraft:snow_block
fill 148 117 276 151 117 276 minecraft:packed_ice
setblock 148 117 315 minecraft:snow_block
fill 148 117 316 151 117 316 minecraft:packed_ice
setblock 148 117 317 minecraft:blue_ice
fill 149 117 298 149 118 298 minecraft:packed_ice
fill 149 117 300 149 118 300 minecraft:packed_ice
fill 149 117 315 151 117 315 minecraft:packed_ice
setblock 151 117 277 minecraft:snow_block
setblock 152 117 276 minecraft:snow_block
setblock 152 117 277 minecraft:packed_ice
setblock 152 117 316 minecraft:snow_block
fill 153 117 276 153 118 276 minecraft:packed_ice
fill 153 117 316 154 117 316 minecraft:packed_ice
fill 158 117 276 161 117 276 minecraft:packed_ice
setblock 161 117 277 minecraft:snow_block
setblock 162 117 276 minecraft:snow_block
fill 162 117 277 165 117 277 minecraft:packed_ice
fill 163 117 276 166 117 276 minecraft:packed_ice
fill 163 117 278 164 117 278 minecraft:packed_ice
fill 163 117 316 166 117 316 minecraft:packed_ice
setblock 164 117 275 minecraft:light_blue_concrete
fill 165 117 275 165 165 275 minecraft:blue_ice
setblock 165 117 278 minecraft:snow_block
fill 165 117 279 168 117 279 minecraft:packed_ice
setblock 166 117 277 minecraft:snow_block
fill 166 117 278 169 117 278 minecraft:packed_ice
setblock 167 117 276 minecraft:snow_block
fill 167 117 277 170 117 277 minecraft:packed_ice
setblock 167 117 316 minecraft:snow_block
fill 168 117 276 171 117 276 minecraft:packed_ice
setblock 168 117 315 minecraft:snow_block
fill 168 117 316 171 117 316 minecraft:packed_ice
setblock 169 117 279 minecraft:snow_block
setblock 169 117 315 minecraft:packed_ice
setblock 170 117 278 minecraft:snow_block
fill 170 117 279 170 120 279 minecraft:packed_ice
setblock 171 117 277 minecraft:snow_block
fill 171 117 278 174 117 278 minecraft:packed_ice
setblock 172 117 276 minecraft:snow_block
fill 172 117 277 175 117 277 minecraft:packed_ice
setblock 172 117 316 minecraft:snow_block
fill 173 117 276 176 117 276 minecraft:packed_ice
fill 173 117 316 176 117 316 minecraft:packed_ice
setblock 175 117 278 minecraft:snow_block
fill 175 117 295 175 118 295 minecraft:snow_block
setblock 176 117 277 minecraft:snow_block
fill 176 117 278 179 117 278 minecraft:packed_ice
setblock 177 117 276 minecraft:snow_block
fill 177 117 277 180 117 277 minecraft:packed_ice
setblock 177 117 316 minecraft:snow_block
fill 178 117 276 181 117 276 minecraft:packed_ice
fill 178 117 316 181 117 316 minecraft:packed_ice
setblock 180 117 278 minecraft:snow_block
fill 180 117 279 182 117 280 minecraft:packed_ice
setblock 181 117 277 minecraft:snow_block
fill 181 117 278 182 119 278 minecraft:packed_ice
setblock 181 117 281 minecraft:packed_ice
setblock 181 117 282 minecraft:snow_block
fill 181 117 283 181 120 283 minecraft:packed_ice
fill 181 117 315 181 118 315 minecraft:packed_ice
setblock 182 117 276 minecraft:snow_block
fill 182 117 277 182 120 277 minecraft:packed_ice
setblock 182 117 281 minecraft:snow_block
fill 182 117 282 182 120 282 minecraft:packed_ice
setblock 182 117 285 minecraft:packed_ice
setblock 182 117 295 minecraft:packed_ice
setblock 182 117 296 minecraft:snow_block
fill 182 117 297 182 117 300 minecraft:packed_ice
setblock 182 117 301 minecraft:snow_block
fill 182 117 302 182 120 302 minecraft:packed_ice
setblock 182 117 305 minecraft:packed_ice
setblock 182 117 306 minecraft:snow_block
fill 182 117 307 182 119 308 minecraft:packed_ice
setblock 182 117 310 minecraft:packed_ice
setblock 182 117 311 minecraft:snow_block
fill 182 117 312 182 120 312 minecraft:packed_ice
setblock 182 117 316 minecraft:snow_block
fill 183 117 298 183 142 298 minecraft:blue_ice
setblock 183 117 299 minecraft:light_blue_concrete
fill 183 117 300 183 160 301 minecraft:blue_ice
fill 142 118 276 142 118 279 minecraft:packed_ice
setblock 142 118 280 minecraft:snow_block
fill 142 118 281 142 121 281 minecraft:packed_ice
setblock 142 118 284 minecraft:packed_ice
setblock 142 118 294 minecraft:packed_ice
setblock 142 118 295 minecraft:snow_block
fill 142 118 296 142 118 299 minecraft:packed_ice
setblock 142 118 300 minecraft:snow_block
fill 142 118 301 142 118 304 minecraft:packed_ice
setblock 142 118 305 minecraft:snow_block
fill 142 118 306 142 118 309 minecraft:packed_ice
setblock 142 118 310 minecraft:snow_block
fill 142 118 311 142 118 314 minecraft:packed_ice
setblock 142 118 315 minecraft:snow_block
fill 142 118 316 145 118 316 minecraft:packed_ice
fill 143 118 276 143 118 278 minecraft:packed_ice
setblock 143 118 279 minecraft:snow_block
fill 143 118 280 144 119 280 minecraft:packed_ice
fill 143 118 282 143 119 282 minecraft:packed_ice
fill 143 118 295 143 118 298 minecraft:packed_ice
setblock 143 118 299 minecraft:snow_block
fill 143 118 300 143 118 303 minecraft:packed_ice
setblock 143 118 304 minecraft:snow_block
fill 143 118 305 143 118 308 minecraft:packed_ice
setblock 143 118 309 minecraft:snow_block
fill 143 118 310 143 118 313 minecraft:packed_ice
setblock 143 118 314 minecraft:snow_block
fill 143 118 315 146 118 315 minecraft:packed_ice
fill 144 118 276 144 118 277 minecraft:packed_ice
setblock 144 118 278 minecraft:snow_block
fill 144 118 279 144 119 279 minecraft:packed_ice
setblock 144 118 297 minecraft:packed_ice
setblock 144 118 298 minecraft:snow_block
fill 144 118 299 144 118 302 minecraft:packed_ice
setblock 144 118 303 minecraft:snow_block
fill 144 118 304 144 121 304 minecraft:packed_ice
setblock 144 118 308 minecraft:snow_block
fill 144 118 309 144 121 309 minecraft:packed_ice
fill 144 118 314 147 118 314 minecraft:packed_ice
setblock 145 118 276 minecraft:packed_ice
setblock 145 118 277 minecraft:snow_block
fill 145 118 278 145 119 278 minecraft:packed_ice
fill 145 118 280 146 119 280 minecraft:snow_block
fill 145 118 298 146 118 298 minecraft:packed_ice
fill 145 118 300 145 118 301 minecraft:packed_ice
setblock 145 118 302 minecraft:snow_block
fill 145 118 303 145 121 303 minecraft:packed_ice
fill 145 118 305 145 118 306 minecraft:packed_ice
setblock 146 118 276 minecraft:snow_block
fill 146 118 277 149 118 277 minecraft:packed_ice
schedule function dropper:buildpart/63_4 1t
