fill 50 150 589 50 151 589 minecraft:cobbled_deepslate
setblock 50 150 592 minecraft:cobbled_deepslate
setblock 50 150 593 minecraft:calcite
setblock 50 150 598 minecraft:calcite
fill 51 150 558 51 151 558 minecraft:cobbled_deepslate
setblock 51 150 597 minecraft:calcite
fill 51 150 598 51 151 598 minecraft:cobbled_deepslate
setblock 54 150 598 minecraft:cobbled_deepslate
setblock 59 150 598 minecraft:cobbled_deepslate
setblock 60 150 598 minecraft:calcite
fill 61 150 598 61 151 598 minecraft:cobbled_deepslate
fill 62 150 567 62 150 569 minecraft:diamond_block
fill 63 150 570 66 150 570 minecraft:diamond_block
fill 63 150 597 65 150 597 minecraft:cobbled_deepslate
setblock 64 150 558 minecraft:cobbled_deepslate
fill 64 150 565 66 150 565 minecraft:diamond_block
setblock 65 150 558 minecraft:calcite
setblock 65 150 598 minecraft:calcite
fill 66 150 558 66 151 558 minecraft:cobbled_deepslate
fill 66 150 598 66 151 598 minecraft:cobbled_deepslate
fill 81 150 558 81 151 558 minecraft:cobbled_deepslate
fill 82 150 559 82 151 559 minecraft:cobbled_deepslate
setblock 84 150 559 minecraft:calcite
fill 84 150 560 84 151 560 minecraft:cobbled_deepslate
fill 84 150 566 85 150 567 minecraft:cobbled_deepslate
setblock 84 150 598 minecraft:cobbled_deepslate
setblock 85 150 558 minecraft:calcite
fill 85 150 559 85 151 559 minecraft:cobbled_deepslate
setblock 85 150 562 minecraft:cobbled_deepslate
setblock 85 150 563 minecraft:calcite
fill 85 150 564 85 151 564 minecraft:cobbled_deepslate
setblock 85 150 568 minecraft:calcite
fill 85 150 569 85 151 569 minecraft:cobbled_deepslate
fill 85 150 571 85 151 571 minecraft:cobbled_deepslate
setblock 85 150 598 minecraft:calcite
fill 86 150 558 86 151 558 minecraft:cobbled_deepslate
setblock 86 150 562 minecraft:calcite
fill 86 150 563 86 151 563 minecraft:cobbled_deepslate
setblock 86 150 567 minecraft:calcite
fill 86 150 568 86 151 568 minecraft:cobbled_deepslate
setblock 86 150 572 minecraft:calcite
fill 86 150 573 86 151 573 minecraft:cobbled_deepslate
fill 86 150 588 86 151 590 minecraft:cobbled_deepslate
fill 86 150 598 86 151 598 minecraft:cobbled_deepslate
setblock 87 150 561 minecraft:calcite
fill 87 150 562 87 151 562 minecraft:cobbled_deepslate
setblock 87 150 566 minecraft:calcite
fill 87 150 567 87 151 567 minecraft:cobbled_deepslate
setblock 87 150 571 minecraft:calcite
fill 87 150 572 87 151 572 minecraft:cobbled_deepslate
setblock 87 150 575 minecraft:cobbled_deepslate
setblock 87 150 586 minecraft:calcite
fill 87 150 587 87 151 587 minecraft:cobbled_deepslate
fill 87 150 589 87 150 590 minecraft:cobbled_deepslate
setblock 87 150 591 minecraft:calcite
fill 87 150 592 87 151 592 minecraft:cobbled_deepslate
fill 87 150 594 87 150 595 minecraft:cobbled_deepslate
setblock 88 150 560 minecraft:calcite
fill 88 150 561 88 151 561 minecraft:cobbled_deepslate
setblock 88 150 565 minecraft:calcite
fill 88 150 566 88 151 566 minecraft:cobbled_deepslate
setblock 88 150 570 minecraft:calcite
fill 88 150 571 88 151 571 minecraft:cobbled_deepslate
setblock 88 150 575 minecraft:calcite
fill 88 150 576 88 151 576 minecraft:cobbled_deepslate
setblock 88 150 580 minecraft:calcite
fill 88 150 581 88 151 581 minecraft:cobbled_deepslate
setblock 88 150 585 minecraft:calcite
fill 88 150 586 88 151 586 minecraft:cobbled_deepslate
setblock 88 150 590 minecraft:calcite
fill 88 150 591 88 151 591 minecraft:cobbled_deepslate
setblock 88 150 594 minecraft:cobbled_deepslate
setblock 88 150 595 minecraft:calcite
fill 88 150 596 88 151 596 minecraft:cobbled_deepslate
setblock 48 151 559 minecraft:calcite
setblock 48 151 560 minecraft:cobbled_deepslate
setblock 48 151 564 minecraft:calcite
setblock 48 151 565 minecraft:cobbled_deepslate
setblock 48 151 569 minecraft:calcite
setblock 48 151 570 minecraft:cobbled_deepslate
setblock 48 151 574 minecraft:calcite
setblock 48 151 575 minecraft:cobbled_deepslate
setblock 48 151 584 minecraft:calcite
setblock 48 151 585 minecraft:cobbled_deepslate
setblock 48 151 589 minecraft:calcite
setblock 48 151 590 minecraft:cobbled_deepslate
setblock 48 151 594 minecraft:calcite
setblock 48 151 595 minecraft:cobbled_deepslate
setblock 49 151 558 minecraft:calcite
setblock 49 151 559 minecraft:cobbled_deepslate
setblock 49 151 563 minecraft:calcite
setblock 49 151 564 minecraft:cobbled_deepslate
setblock 49 151 568 minecraft:calcite
setblock 49 151 569 minecraft:cobbled_deepslate
setblock 49 151 571 minecraft:cobbled_deepslate
setblock 49 151 584 minecraft:cobbled_deepslate
setblock 49 151 588 minecraft:calcite
setblock 49 151 589 minecraft:cobbled_deepslate
setblock 49 151 593 minecraft:calcite
fill 49 151 594 50 151 594 minecraft:cobbled_deepslate
setblock 49 151 598 minecraft:calcite
setblock 50 151 558 minecraft:cobbled_deepslate
setblock 50 151 587 minecraft:calcite
setblock 50 151 588 minecraft:cobbled_deepslate
setblock 50 151 592 minecraft:calcite
setblock 50 151 593 minecraft:cobbled_deepslate
setblock 50 151 597 minecraft:calcite
setblock 50 151 598 minecraft:cobbled_deepslate
setblock 51 151 597 minecraft:cobbled_deepslate
setblock 54 151 598 minecraft:calcite
setblock 55 151 598 minecraft:cobbled_deepslate
fill 57 151 598 58 151 598 minecraft:cobbled_deepslate
setblock 59 151 598 minecraft:calcite
setblock 60 151 598 minecraft:cobbled_deepslate
fill 61 151 597 64 151 597 minecraft:cobbled_deepslate
setblock 64 151 558 minecraft:calcite
setblock 64 151 598 minecraft:calcite
setblock 65 151 558 minecraft:cobbled_deepslate
setblock 65 151 597 minecraft:calcite
setblock 65 151 598 minecraft:cobbled_deepslate
setblock 66 151 597 minecraft:cobbled_deepslate
setblock 80 151 558 minecraft:cobbled_deepslate
fill 82 151 598 83 151 598 minecraft:cobbled_deepslate
setblock 83 151 558 minecraft:cobbled_deepslate
setblock 83 151 559 minecraft:calcite
setblock 83 151 560 minecraft:cobbled_deepslate
setblock 84 151 558 minecraft:calcite
setblock 84 151 559 minecraft:cobbled_deepslate
fill 84 151 565 84 151 567 minecraft:cobbled_deepslate
setblock 84 151 568 minecraft:calcite
setblock 84 151 569 minecraft:cobbled_deepslate
setblock 84 151 598 minecraft:calcite
setblock 85 151 558 minecraft:cobbled_deepslate
setblock 85 151 562 minecraft:calcite
setblock 85 151 563 minecraft:cobbled_deepslate
setblock 85 151 566 minecraft:cobbled_deepslate
setblock 85 151 567 minecraft:calcite
setblock 85 151 568 minecraft:cobbled_deepslate
setblock 85 151 597 minecraft:calcite
setblock 85 151 598 minecraft:cobbled_deepslate
setblock 86 151 561 minecraft:calcite
setblock 86 151 562 minecraft:cobbled_deepslate
setblock 86 151 566 minecraft:calcite
setblock 86 151 567 minecraft:cobbled_deepslate
setblock 86 151 570 minecraft:cobbled_deepslate
setblock 86 151 571 minecraft:calcite
setblock 86 151 572 minecraft:cobbled_deepslate
setblock 86 151 591 minecraft:calcite
setblock 86 151 592 minecraft:cobbled_deepslate
fill 86 151 597 87 151 597 minecraft:cobbled_deepslate
setblock 87 151 560 minecraft:calcite
setblock 87 151 561 minecraft:cobbled_deepslate
setblock 87 151 565 minecraft:calcite
setblock 87 151 566 minecraft:cobbled_deepslate
setblock 87 151 570 minecraft:calcite
setblock 87 151 571 minecraft:cobbled_deepslate
setblock 87 151 575 minecraft:calcite
setblock 87 151 585 minecraft:calcite
setblock 87 151 586 minecraft:cobbled_deepslate
setblock 87 151 589 minecraft:cobbled_deepslate
setblock 87 151 590 minecraft:calcite
setblock 87 151 591 minecraft:cobbled_deepslate
setblock 87 151 594 minecraft:cobbled_deepslate
setblock 87 151 595 minecraft:calcite
setblock 87 151 596 minecraft:cobbled_deepslate
setblock 88 151 559 minecraft:calcite
setblock 88 151 560 minecraft:cobbled_deepslate
setblock 88 151 564 minecraft:calcite
setblock 88 151 565 minecraft:cobbled_deepslate
setblock 88 151 569 minecraft:calcite
setblock 88 151 570 minecraft:cobbled_deepslate
setblock 88 151 574 minecraft:calcite
setblock 88 151 575 minecraft:cobbled_deepslate
setblock 88 151 579 minecraft:calcite
setblock 88 151 580 minecraft:cobbled_deepslate
setblock 88 151 584 minecraft:calcite
setblock 88 151 585 minecraft:cobbled_deepslate
setblock 88 151 589 minecraft:calcite
setblock 88 151 590 minecraft:cobbled_deepslate
setblock 88 151 594 minecraft:calcite
setblock 88 151 595 minecraft:cobbled_deepslate
setblock 50 152 560 minecraft:light[level=14]
setblock 50 152 568 minecraft:light[level=14]
setblock 50 152 576 minecraft:light[level=14]
setblock 50 152 584 minecraft:light[level=14]
setblock 50 152 592 minecraft:light[level=14]
setblock 58 152 560 minecraft:light[level=14]
setblock 58 152 568 minecraft:light[level=14]
setblock 58 152 576 minecraft:light[level=14]
setblock 58 152 584 minecraft:light[level=14]
setblock 58 152 592 minecraft:light[level=14]
setblock 66 152 560 minecraft:light[level=14]
setblock 66 152 568 minecraft:light[level=14]
setblock 66 152 576 minecraft:light[level=14]
setblock 66 152 584 minecraft:light[level=14]
setblock 66 152 592 minecraft:light[level=14]
setblock 74 152 560 minecraft:light[level=14]
setblock 74 152 568 minecraft:light[level=14]
setblock 74 152 576 minecraft:light[level=14]
setblock 74 152 584 minecraft:light[level=14]
setblock 74 152 592 minecraft:light[level=14]
setblock 82 152 560 minecraft:light[level=14]
setblock 82 152 568 minecraft:light[level=14]
setblock 82 152 576 minecraft:light[level=14]
setblock 82 152 584 minecraft:light[level=14]
setblock 82 152 592 minecraft:light[level=14]
fill 63 156 574 65 156 576 minecraft:redstone_block
fill 64 156 581 66 156 583 minecraft:redstone_block
fill 71 156 574 73 156 576 minecraft:redstone_block
fill 71 156 580 73 156 582 minecraft:redstone_block
fill 48 157 558 62 157 598 minecraft:calcite
fill 63 157 558 88 157 573 minecraft:calcite
fill 63 157 577 63 157 598 minecraft:calcite
fill 64 157 577 66 157 580 minecraft:calcite
fill 64 157 584 88 157 598 minecraft:calcite
fill 66 157 574 70 157 576 minecraft:calcite
fill 67 157 580 70 157 583 minecraft:calcite
fill 70 157 577 88 157 579 minecraft:calcite
fill 71 157 583 88 157 583 minecraft:calcite
fill 74 157 574 88 157 576 minecraft:calcite
fill 74 157 580 88 157 582 minecraft:calcite
fill 48 158 558 48 158 563 minecraft:calcite
fill 48 158 564 88 158 564 minecraft:diamond_block
fill 48 158 565 48 158 570 minecraft:calcite
fill 48 158 571 59 158 571 minecraft:diamond_block
fill 48 158 572 48 158 577 minecraft:calcite
fill 48 158 578 54 158 578 minecraft:diamond_block
fill 48 158 579 48 158 584 minecraft:calcite
fill 48 158 585 59 158 585 minecraft:diamond_block
fill 48 158 586 48 158 591 minecraft:calcite
fill 48 158 592 88 158 592 minecraft:diamond_block
fill 48 158 593 48 158 598 minecraft:calcite
fill 49 158 558 53 158 560 minecraft:calcite
fill 49 158 561 49 158 563 minecraft:diamond_block
fill 49 158 565 53 158 567 minecraft:calcite
fill 49 158 568 49 158 570 minecraft:diamond_block
fill 49 158 572 53 158 574 minecraft:calcite
fill 49 158 575 49 158 577 minecraft:diamond_block
fill 49 158 579 53 158 581 minecraft:calcite
fill 49 158 582 49 158 584 minecraft:diamond_block
fill 49 158 586 53 158 588 minecraft:calcite
fill 49 158 589 49 158 591 minecraft:diamond_block
fill 49 158 593 53 158 595 minecraft:calcite
fill 49 158 596 49 158 598 minecraft:diamond_block
fill 50 158 561 51 158 563 minecraft:calcite
fill 50 158 568 51 158 570 minecraft:calcite
fill 50 158 575 51 158 577 minecraft:calcite
fill 50 158 582 51 158 584 minecraft:calcite
fill 50 158 589 51 158 591 minecraft:calcite
fill 50 158 596 51 158 598 minecraft:calcite
fill 52 158 561 52 158 563 minecraft:diamond_block
fill 52 158 568 52 158 570 minecraft:diamond_block
fill 52 158 575 52 158 577 minecraft:diamond_block
fill 52 158 582 52 158 584 minecraft:diamond_block
fill 52 158 589 52 158 591 minecraft:diamond_block
fill 52 158 596 52 158 598 minecraft:diamond_block
fill 53 158 561 55 158 563 minecraft:calcite
fill 53 158 568 55 158 570 minecraft:calcite
fill 53 158 575 55 158 577 minecraft:calcite
fill 53 158 582 55 158 584 minecraft:calcite
fill 53 158 589 55 158 591 minecraft:calcite
fill 53 158 596 55 158 598 minecraft:calcite
fill 54 158 558 54 158 560 minecraft:diamond_block
fill 54 158 565 54 158 567 minecraft:diamond_block
fill 54 158 572 54 158 574 minecraft:diamond_block
fill 54 158 579 54 158 581 minecraft:diamond_block
fill 54 158 586 54 158 588 minecraft:diamond_block
fill 54 158 593 54 158 595 minecraft:diamond_block
fill 55 158 558 60 158 560 minecraft:calcite
fill 55 158 565 60 158 567 minecraft:calcite
fill 55 158 572 55 158 574 minecraft:calcite
fill 55 158 578 64 159 578 minecraft:iron_block
fill 55 158 579 55 158 581 minecraft:calcite
fill 55 158 586 59 158 588 minecraft:calcite
fill 55 158 593 60 158 595 minecraft:calcite
fill 56 158 561 56 158 563 minecraft:diamond_block
fill 56 158 568 56 158 570 minecraft:diamond_block
setblock 56 158 572 minecraft:calcite
fill 56 158 573 80 159 573 minecraft:iron_block
setblock 56 158 574 minecraft:calcite
fill 56 158 575 56 158 576 minecraft:diamond_block
fill 56 158 577 56 159 577 minecraft:iron_block
fill 56 158 579 56 159 579 minecraft:iron_block
fill 56 158 580 57 158 581 minecraft:calcite
setblock 56 158 582 minecraft:diamond_block
fill 56 158 583 80 159 583 minecraft:iron_block
setblock 56 158 584 minecraft:diamond_block
fill 56 158 589 56 158 591 minecraft:diamond_block
fill 56 158 596 56 158 598 minecraft:diamond_block
fill 57 158 561 58 158 563 minecraft:calcite
fill 57 158 568 58 158 570 minecraft:calcite
fill 57 158 572 79 159 572 minecraft:iron_block
fill 57 158 574 79 159 574 minecraft:iron_block
fill 57 158 575 57 158 577 minecraft:calcite
setblock 57 158 579 minecraft:calcite
fill 57 158 582 79 159 582 minecraft:iron_block
fill 57 158 584 79 159 584 minecraft:iron_block
fill 57 158 589 58 158 591 minecraft:calcite
fill 57 158 596 58 158 598 minecraft:calcite
fill 58 158 575 65 159 577 minecraft:iron_block
fill 58 158 579 65 159 581 minecraft:iron_block
fill 59 158 561 59 158 563 minecraft:diamond_block
fill 59 158 568 59 158 570 minecraft:diamond_block
fill 59 158 589 59 158 591 minecraft:diamond_block
fill 59 158 596 59 158 598 minecraft:diamond_block
fill 60 158 561 62 158 563 minecraft:calcite
fill 60 158 568 61 159 569 minecraft:iron_block
setblock 60 158 570 minecraft:calcite
fill 60 158 571 76 159 571 minecraft:iron_block
fill 60 158 585 76 159 585 minecraft:iron_block
setblock 60 158 586 minecraft:calcite
fill 60 158 587 61 159 588 minecraft:iron_block
fill 60 158 589 62 158 591 minecraft:calcite
fill 60 158 596 62 158 598 minecraft:calcite
fill 61 158 558 61 158 560 minecraft:diamond_block
fill 61 158 565 61 158 567 minecraft:diamond_block
fill 61 158 570 75 159 570 minecraft:iron_block
fill 61 158 586 75 159 586 minecraft:iron_block
fill 61 158 593 61 158 595 minecraft:diamond_block
fill 62 158 558 67 158 560 minecraft:calcite
fill 62 158 565 62 158 568 minecraft:calcite
fill 62 158 569 76 159 569 minecraft:iron_block
fill 62 158 587 76 159 587 minecraft:iron_block
fill 62 158 588 63 158 588 minecraft:calcite
fill 62 158 593 67 158 595 minecraft:calcite
fill 63 158 561 63 158 563 minecraft:diamond_block
fill 63 158 565 64 158 567 minecraft:calcite
setblock 63 158 568 minecraft:diamond_block
fill 63 158 589 63 158 591 minecraft:diamond_block
fill 63 158 596 63 158 598 minecraft:diamond_block
fill 64 158 561 65 158 563 minecraft:calcite
fill 64 158 568 72 159 568 minecraft:iron_block
fill 64 158 588 72 159 588 minecraft:iron_block
fill 64 158 589 64 158 591 minecraft:calcite
fill 64 158 596 65 158 598 minecraft:calcite
fill 65 158 565 67 158 565 minecraft:calcite
fill 65 158 566 66 159 567 minecraft:iron_block
fill 65 158 578 66 158 578 minecraft:waxed_copper_block
fill 65 158 589 66 159 590 minecraft:iron_block
setblock 65 158 591 minecraft:calcite
fill 66 158 561 66 158 563 minecraft:diamond_block
fill 66 158 575 67 159 575 minecraft:iron_block
fill 66 158 576 66 159 577 minecraft:waxed_copper_block
fill 66 158 579 66 159 580 minecraft:waxed_copper_block
fill 66 158 581 67 159 581 minecraft:iron_block
setblock 66 158 591 minecraft:diamond_block
fill 66 158 596 66 158 598 minecraft:diamond_block
fill 67 158 561 69 158 563 minecraft:calcite
fill 67 158 566 67 158 567 minecraft:calcite
fill 67 158 576 70 158 576 minecraft:waxed_copper_block
fill 67 158 580 70 158 580 minecraft:waxed_copper_block
fill 67 158 589 67 158 591 minecraft:calcite
fill 67 158 596 69 158 598 minecraft:calcite
fill 68 158 558 68 158 560 minecraft:diamond_block
fill 68 158 565 68 158 566 minecraft:diamond_block
fill 68 158 567 68 159 567 minecraft:iron_block
fill 68 158 575 68 160 575 minecraft:waxed_copper_block
fill 68 158 581 68 160 581 minecraft:waxed_copper_block
fill 68 158 589 68 159 589 minecraft:iron_block
fill 68 158 590 69 158 591 minecraft:calcite
fill 68 158 593 68 158 595 minecraft:diamond_block
fill 69 158 558 74 158 560 minecraft:calcite
fill 69 158 565 69 158 567 minecraft:calcite
fill 69 158 575 78 159 575 minecraft:iron_block
fill 69 158 581 78 159 581 minecraft:iron_block
setblock 69 158 589 minecraft:calcite
fill 69 158 593 74 158 595 minecraft:calcite
fill 70 158 561 70 158 563 minecraft:diamond_block
fill 70 158 565 74 158 565 minecraft:calcite
fill 70 158 566 71 159 567 minecraft:iron_block
fill 70 158 577 70 158 579 minecraft:waxed_copper_block
fill 70 158 589 71 159 590 minecraft:iron_block
setblock 70 158 591 minecraft:diamond_block
fill 70 158 596 70 158 598 minecraft:diamond_block
fill 71 158 561 72 158 563 minecraft:calcite
fill 71 158 576 78 159 577 minecraft:iron_block
fill 71 158 578 71 160 578 minecraft:waxed_copper_block
fill 71 158 579 78 159 580 minecraft:iron_block
fill 71 158 591 72 158 591 minecraft:calcite
fill 71 158 596 72 158 598 minecraft:calcite
fill 72 158 566 74 158 567 minecraft:calcite
fill 72 158 578 81 159 578 minecraft:iron_block
fill 72 158 589 72 158 590 minecraft:calcite
fill 73 158 561 73 158 563 minecraft:diamond_block
setblock 73 158 568 minecraft:diamond_block
fill 73 158 588 74 158 588 minecraft:calcite
fill 73 158 589 73 158 591 minecraft:diamond_block
fill 73 158 596 73 158 598 minecraft:diamond_block
fill 74 158 561 76 158 563 minecraft:calcite
setblock 74 158 568 minecraft:calcite
fill 74 158 589 76 158 591 minecraft:calcite
fill 74 158 596 76 158 598 minecraft:calcite
fill 75 158 558 75 158 560 minecraft:diamond_block
fill 75 158 565 75 158 567 minecraft:diamond_block
fill 75 158 568 76 159 568 minecraft:iron_block
fill 75 158 588 76 159 588 minecraft:iron_block
fill 75 158 593 75 158 595 minecraft:diamond_block
fill 76 158 558 81 158 560 minecraft:calcite
fill 76 158 565 81 158 567 minecraft:calcite
setblock 76 158 570 minecraft:calcite
fill 76 158 586 81 158 586 minecraft:calcite
fill 76 158 593 81 158 595 minecraft:calcite
fill 77 158 561 77 158 563 minecraft:diamond_block
fill 77 158 568 77 158 571 minecraft:diamond_block
fill 77 158 585 88 158 585 minecraft:diamond_block
fill 77 158 587 81 158 588 minecraft:calcite
fill 77 158 589 77 158 591 minecraft:diamond_block
fill 77 158 596 77 158 598 minecraft:diamond_block
fill 78 158 561 79 158 563 minecraft:calcite
fill 78 158 568 79 158 570 minecraft:calcite
fill 78 158 571 88 158 571 minecraft:diamond_block
fill 78 158 589 79 158 591 minecraft:calcite
fill 78 158 596 79 158 598 minecraft:calcite
fill 79 158 575 79 158 577 minecraft:calcite
fill 79 158 579 79 158 581 minecraft:calcite
fill 80 158 561 80 158 563 minecraft:diamond_block
fill 80 158 568 80 158 570 minecraft:diamond_block
fill 80 158 572 81 158 572 minecraft:calcite
fill 80 158 574 81 158 574 minecraft:calcite
fill 80 158 575 80 158 576 minecraft:diamond_block
fill 80 158 577 80 159 577 minecraft:iron_block
fill 80 158 579 80 159 579 minecraft:iron_block
fill 80 158 580 81 158 581 minecraft:calcite
setblock 80 158 582 minecraft:diamond_block
setblock 80 158 584 minecraft:diamond_block
fill 80 158 589 80 158 591 minecraft:diamond_block
fill 80 158 596 80 158 598 minecraft:diamond_block
fill 81 158 561 83 158 563 minecraft:calcite
fill 81 158 568 83 158 570 minecraft:calcite
setblock 81 158 573 minecraft:calcite
fill 81 158 575 83 158 577 minecraft:calcite
setblock 81 158 579 minecraft:calcite
fill 81 158 582 83 158 584 minecraft:calcite
fill 81 158 589 83 158 591 minecraft:calcite
fill 81 158 596 83 158 598 minecraft:calcite
fill 82 158 558 82 158 560 minecraft:diamond_block
fill 82 158 565 82 158 567 minecraft:diamond_block
fill 82 158 572 82 158 574 minecraft:diamond_block
fill 82 158 578 82 158 581 minecraft:diamond_block
fill 82 158 586 82 158 588 minecraft:diamond_block
fill 82 158 593 82 158 595 minecraft:diamond_block
fill 83 158 558 88 158 560 minecraft:calcite
fill 83 158 565 88 158 567 minecraft:calcite
fill 83 158 572 88 158 574 minecraft:calcite
fill 83 158 578 88 158 578 minecraft:diamond_block
fill 83 158 579 88 158 581 minecraft:calcite
fill 83 158 586 88 158 588 minecraft:calcite
fill 83 158 593 88 158 595 minecraft:calcite
fill 84 158 561 84 158 563 minecraft:diamond_block
fill 84 158 568 84 158 570 minecraft:diamond_block
fill 84 158 575 84 158 577 minecraft:diamond_block
fill 84 158 582 84 158 584 minecraft:diamond_block
fill 84 158 589 84 158 591 minecraft:diamond_block
fill 84 158 596 84 158 598 minecraft:diamond_block
fill 85 158 561 86 158 563 minecraft:calcite
fill 85 158 568 86 158 570 minecraft:calcite
fill 85 158 575 86 158 577 minecraft:calcite
fill 85 158 582 86 158 584 minecraft:calcite
fill 85 158 589 86 158 591 minecraft:calcite
fill 85 158 596 86 158 598 minecraft:calcite
fill 87 158 561 87 158 563 minecraft:diamond_block
fill 87 158 568 87 158 570 minecraft:diamond_block
fill 87 158 575 87 158 577 minecraft:diamond_block
fill 87 158 582 87 158 584 minecraft:diamond_block
fill 87 158 589 87 158 591 minecraft:diamond_block
fill 87 158 596 87 158 598 minecraft:diamond_block
fill 88 158 561 88 158 563 minecraft:calcite
fill 88 158 568 88 158 570 minecraft:calcite
fill 88 158 575 88 158 577 minecraft:calcite
fill 88 158 582 88 158 584 minecraft:calcite
fill 88 158 589 88 158 591 minecraft:calcite
fill 88 158 596 88 158 598 minecraft:calcite
fill 65 159 578 65 160 578 minecraft:waxed_copper_block
setblock 67 159 576 minecraft:waxed_copper_block
setblock 67 159 580 minecraft:waxed_copper_block
fill 69 159 576 70 159 576 minecraft:waxed_copper_block
fill 69 159 580 70 159 580 minecraft:waxed_copper_block
setblock 70 159 577 minecraft:waxed_copper_block
setblock 70 159 579 minecraft:waxed_copper_block
setblock 50 160 560 minecraft:light[level=14]
setblock 50 160 568 minecraft:light[level=14]
setblock 50 160 576 minecraft:light[level=14]
setblock 50 160 584 minecraft:light[level=14]
setblock 50 160 592 minecraft:light[level=14]
setblock 58 160 560 minecraft:light[level=14]
setblock 58 160 568 minecraft:light[level=14]
setblock 58 160 576 minecraft:light[level=14]
setblock 58 160 584 minecraft:light[level=14]
setblock 58 160 592 minecraft:light[level=14]
fill 61 160 576 61 160 580 minecraft:waxed_oxidized_copper
fill 62 160 574 62 160 575 minecraft:waxed_oxidized_copper
fill 62 160 581 62 160 582 minecraft:waxed_oxidized_copper
setblock 63 160 573 minecraft:waxed_oxidized_copper
setblock 63 160 583 minecraft:waxed_oxidized_copper
fill 64 160 572 65 160 572 minecraft:waxed_oxidized_copper
fill 64 160 584 65 160 584 minecraft:waxed_oxidized_copper
setblock 66 160 560 minecraft:light[level=14]
setblock 66 160 568 minecraft:light[level=14]
fill 66 160 571 70 160 571 minecraft:waxed_oxidized_copper
setblock 66 160 576 minecraft:waxed_copper_block
setblock 66 160 580 minecraft:waxed_copper_block
setblock 66 160 584 minecraft:light[level=14]
fill 66 160 585 70 160 585 minecraft:waxed_oxidized_copper
setblock 66 160 592 minecraft:light[level=14]
setblock 70 160 576 minecraft:waxed_copper_block
setblock 70 160 580 minecraft:waxed_copper_block
fill 71 160 572 72 160 572 minecraft:waxed_oxidized_copper
fill 71 160 584 72 160 584 minecraft:waxed_oxidized_copper
setblock 73 160 573 minecraft:waxed_oxidized_copper
setblock 73 160 583 minecraft:waxed_oxidized_copper
setblock 74 160 560 minecraft:light[level=14]
setblock 74 160 568 minecraft:light[level=14]
fill 74 160 574 74 160 575 minecraft:waxed_oxidized_copper
setblock 74 160 576 minecraft:light[level=14]
fill 74 160 581 74 160 582 minecraft:waxed_oxidized_copper
setblock 74 160 584 minecraft:light[level=14]
setblock 74 160 592 minecraft:light[level=14]
fill 75 160 576 75 160 580 minecraft:waxed_oxidized_copper
setblock 82 160 560 minecraft:light[level=14]
setblock 82 160 568 minecraft:light[level=14]
setblock 82 160 576 minecraft:light[level=14]
setblock 82 160 584 minecraft:light[level=14]
setblock 82 160 592 minecraft:light[level=14]
fill 48 162 591 48 162 592 minecraft:cobbled_deepslate
setblock 48 162 593 minecraft:calcite
fill 48 162 594 48 162 597 minecraft:cobbled_deepslate
setblock 48 162 598 minecraft:calcite
fill 49 162 587 51 166 587 minecraft:deepslate
fill 49 162 594 49 162 596 minecraft:cobbled_deepslate
setblock 49 162 597 minecraft:calcite
fill 49 162 598 52 162 598 minecraft:cobbled_deepslate
fill 50 162 586 50 166 586 minecraft:deepslate
fill 50 162 588 50 166 588 minecraft:deepslate
fill 50 162 597 53 162 597 minecraft:cobbled_deepslate
setblock 53 162 598 minecraft:calcite
setblock 54 162 597 minecraft:calcite
fill 54 162 598 57 162 598 minecraft:cobbled_deepslate
fill 55 162 558 57 162 558 minecraft:cobbled_deepslate
setblock 55 162 596 minecraft:calcite
fill 55 162 597 58 162 597 minecraft:cobbled_deepslate
fill 56 162 596 59 162 596 minecraft:cobbled_deepslate
setblock 58 162 558 minecraft:calcite
setblock 58 162 598 minecraft:calcite
fill 59 162 558 62 162 558 minecraft:cobbled_deepslate
setblock 59 162 597 minecraft:calcite
fill 59 162 598 62 162 598 minecraft:cobbled_deepslate
setblock 60 162 596 minecraft:calcite
fill 60 162 597 63 162 597 minecraft:cobbled_deepslate
setblock 63 162 558 minecraft:calcite
setblock 63 162 598 minecraft:calcite
fill 64 162 598 65 164 598 minecraft:cobbled_deepslate
setblock 72 162 558 minecraft:cobbled_deepslate
setblock 73 162 558 minecraft:calcite
setblock 73 162 598 minecraft:calcite
fill 74 162 558 77 162 558 minecraft:cobbled_deepslate
fill 74 162 598 77 162 598 minecraft:cobbled_deepslate
fill 75 162 559 76 162 559 minecraft:cobbled_deepslate
fill 75 162 597 78 162 597 minecraft:cobbled_deepslate
setblock 77 162 559 minecraft:calcite
setblock 78 162 558 minecraft:calcite
fill 78 162 559 80 162 560 minecraft:cobbled_deepslate
setblock 78 162 598 minecraft:calcite
fill 79 162 558 82 162 558 minecraft:cobbled_deepslate
setblock 79 162 596 minecraft:cobbled_deepslate
setblock 79 162 597 minecraft:calcite
fill 79 162 598 82 162 598 minecraft:cobbled_deepslate
setblock 80 162 596 minecraft:calcite
fill 80 162 597 83 162 597 minecraft:cobbled_deepslate
setblock 81 162 559 minecraft:cobbled_deepslate
setblock 81 162 560 minecraft:calcite
fill 81 162 596 83 163 596 minecraft:cobbled_deepslate
setblock 82 162 559 minecraft:calcite
fill 82 162 560 84 162 562 minecraft:deepslate
setblock 83 162 558 minecraft:calcite
fill 83 162 559 85 163 559 minecraft:cobbled_deepslate
setblock 83 162 598 minecraft:calcite
fill 84 162 558 87 162 558 minecraft:cobbled_deepslate
setblock 84 162 597 minecraft:calcite
fill 84 162 598 87 162 598 minecraft:cobbled_deepslate
fill 85 162 597 88 162 597 minecraft:cobbled_deepslate
fill 87 162 595 88 163 596 minecraft:cobbled_deepslate
setblock 88 162 558 minecraft:calcite
fill 88 162 559 88 165 559 minecraft:cobbled_deepslate
setblock 88 162 593 minecraft:calcite
fill 88 162 594 88 165 594 minecraft:cobbled_deepslate
setblock 88 162 598 minecraft:calcite
setblock 48 163 576 minecraft:cobbled_deepslate
setblock 48 163 577 minecraft:calcite
fill 48 163 578 48 165 579 minecraft:cobbled_deepslate
setblock 48 163 591 minecraft:cobbled_deepslate
setblock 48 163 592 minecraft:calcite
fill 48 163 593 48 163 596 minecraft:cobbled_deepslate
setblock 48 163 597 minecraft:calcite
fill 48 163 598 51 163 598 minecraft:cobbled_deepslate
fill 49 163 594 49 163 595 minecraft:cobbled_deepslate
setblock 49 163 596 minecraft:calcite
fill 49 163 597 52 163 597 minecraft:cobbled_deepslate
setblock 52 163 598 minecraft:calcite
fill 53 163 558 56 163 558 minecraft:cobbled_deepslate
setblock 53 163 597 minecraft:calcite
fill 53 163 598 56 163 598 minecraft:cobbled_deepslate
setblock 54 163 596 minecraft:calcite
fill 54 163 597 57 163 597 minecraft:cobbled_deepslate
fill 55 163 596 58 163 596 minecraft:cobbled_deepslate
setblock 57 163 558 minecraft:calcite
setblock 57 163 598 minecraft:calcite
fill 58 163 558 61 163 558 minecraft:cobbled_deepslate
setblock 58 163 597 minecraft:calcite
fill 58 163 598 61 163 598 minecraft:cobbled_deepslate
setblock 59 163 596 minecraft:calcite
fill 59 163 597 62 163 597 minecraft:cobbled_deepslate
setblock 60 163 596 minecraft:cobbled_deepslate
setblock 62 163 558 minecraft:calcite
setblock 62 163 598 minecraft:calcite
fill 63 163 558 65 164 558 minecraft:cobbled_deepslate
setblock 63 163 597 minecraft:calcite
fill 63 163 598 63 166 598 minecraft:cobbled_deepslate
fill 70 163 558 71 163 558 minecraft:cobbled_deepslate
setblock 72 163 558 minecraft:calcite
setblock 72 163 598 minecraft:calcite
fill 73 163 558 75 163 559 minecraft:cobbled_deepslate
fill 73 163 598 76 163 598 minecraft:cobbled_deepslate
fill 74 163 597 77 163 597 minecraft:cobbled_deepslate
setblock 76 163 558 minecraft:cobbled_deepslate
setblock 76 163 559 minecraft:calcite
fill 76 163 560 79 163 560 minecraft:cobbled_deepslate
setblock 77 163 558 minecraft:calcite
fill 77 163 559 80 163 559 minecraft:cobbled_deepslate
setblock 77 163 598 minecraft:calcite
fill 78 163 558 81 163 558 minecraft:cobbled_deepslate
setblock 78 163 596 minecraft:cobbled_deepslate
setblock 78 163 597 minecraft:calcite
fill 78 163 598 81 163 598 minecraft:cobbled_deepslate
setblock 79 163 596 minecraft:calcite
fill 79 163 597 82 163 597 minecraft:cobbled_deepslate
setblock 80 163 560 minecraft:calcite
fill 80 163 596 80 166 596 minecraft:cobbled_deepslate
setblock 81 163 559 minecraft:calcite
fill 81 163 560 82 165 560 minecraft:cobbled_deepslate
setblock 82 163 558 minecraft:calcite
fill 82 163 559 82 166 559 minecraft:cobbled_deepslate
fill 82 163 561 84 165 562 minecraft:deepslate
setblock 82 163 598 minecraft:calcite
fill 83 163 558 86 163 558 minecraft:cobbled_deepslate
fill 83 163 560 84 163 560 minecraft:deepslate
setblock 83 163 597 minecraft:calcite
fill 83 163 598 86 163 598 minecraft:cobbled_deepslate
fill 84 163 597 87 163 597 minecraft:cobbled_deepslate
setblock 86 163 559 minecraft:calcite
setblock 87 163 558 minecraft:calcite
setblock 87 163 598 minecraft:calcite
fill 88 163 558 88 166 558 minecraft:cobbled_deepslate
fill 88 163 560 88 164 560 minecraft:cobbled_deepslate
fill 88 163 593 88 166 593 minecraft:cobbled_deepslate
setblock 88 163 597 minecraft:calcite
fill 88 163 598 88 166 598 minecraft:cobbled_deepslate
fill 48 164 558 50 164 558 minecraft:cobbled_deepslate
setblock 48 164 575 minecraft:cobbled_deepslate
setblock 48 164 576 minecraft:calcite
fill 48 164 577 48 167 577 minecraft:cobbled_deepslate
setblock 48 164 580 minecraft:cobbled_deepslate
setblock 48 164 581 minecraft:calcite
fill 48 164 582 48 167 582 minecraft:cobbled_deepslate
setblock 48 164 591 minecraft:calcite
fill 48 164 592 48 164 595 minecraft:cobbled_deepslate
setblock 48 164 596 minecraft:calcite
fill 48 164 597 50 164 598 minecraft:cobbled_deepslate
fill 49 164 586 49 166 586 minecraft:deepslate
fill 49 164 588 49 166 588 minecraft:deepslate
setblock 49 164 594 minecraft:cobbled_deepslate
setblock 49 164 595 minecraft:calcite
fill 49 164 596 49 167 596 minecraft:cobbled_deepslate
setblock 51 164 558 minecraft:calcite
fill 51 164 586 51 166 586 minecraft:deepslate
fill 51 164 588 51 166 588 minecraft:deepslate
setblock 51 164 597 minecraft:cobbled_deepslate
setblock 51 164 598 minecraft:calcite
fill 52 164 558 55 164 558 minecraft:cobbled_deepslate
setblock 52 164 597 minecraft:calcite
fill 52 164 598 55 164 598 minecraft:cobbled_deepslate
setblock 53 164 596 minecraft:calcite
fill 53 164 597 56 164 597 minecraft:cobbled_deepslate
fill 54 164 596 57 164 596 minecraft:cobbled_deepslate
setblock 56 164 558 minecraft:calcite
fill 56 164 559 59 164 559 minecraft:cobbled_deepslate
setblock 56 164 598 minecraft:calcite
fill 57 164 558 60 164 558 minecraft:cobbled_deepslate
setblock 57 164 597 minecraft:calcite
fill 57 164 598 60 164 598 minecraft:cobbled_deepslate
setblock 58 164 596 minecraft:calcite
fill 58 164 597 61 164 597 minecraft:cobbled_deepslate
fill 59 164 596 59 165 596 minecraft:cobbled_deepslate
setblock 60 164 559 minecraft:calcite
setblock 61 164 558 minecraft:calcite
fill 61 164 559 61 167 559 minecraft:cobbled_deepslate
setblock 61 164 598 minecraft:calcite
fill 62 164 558 62 167 558 minecraft:cobbled_deepslate
setblock 62 164 597 minecraft:calcite
fill 62 164 598 62 167 598 minecraft:cobbled_deepslate
setblock 66 164 558 minecraft:calcite
fill 67 164 558 70 164 558 minecraft:cobbled_deepslate
setblock 70 164 598 minecraft:cobbled_deepslate
setblock 71 164 558 minecraft:calcite
setblock 71 164 598 minecraft:calcite
fill 72 164 558 74 164 559 minecraft:cobbled_deepslate
fill 72 164 575 73 165 581 minecraft:waxed_copper_block
fill 72 164 598 75 164 598 minecraft:cobbled_deepslate
fill 73 164 574 81 165 574 minecraft:waxed_copper_block
fill 73 164 582 81 165 582 minecraft:waxed_copper_block
setblock 74 164 560 minecraft:calcite
fill 74 164 573 80 165 573 minecraft:waxed_copper_block
fill 74 164 575 74 165 577 minecraft:waxed_copper_block
fill 74 164 579 74 165 581 minecraft:waxed_copper_block
fill 74 164 583 80 165 583 minecraft:waxed_copper_block
fill 74 164 597 76 164 597 minecraft:cobbled_deepslate
setblock 75 164 558 minecraft:cobbled_deepslate
setblock 75 164 559 minecraft:calcite
fill 75 164 560 78 164 560 minecraft:cobbled_deepslate
fill 75 164 575 76 165 575 minecraft:waxed_copper_block
fill 75 164 581 76 165 581 minecraft:waxed_copper_block
setblock 76 164 558 minecraft:calcite
fill 76 164 559 79 164 559 minecraft:cobbled_deepslate
setblock 76 164 598 minecraft:calcite
fill 77 164 558 80 164 558 minecraft:cobbled_deepslate
fill 77 164 572 77 165 572 minecraft:waxed_copper_block
fill 77 164 584 77 165 584 minecraft:waxed_copper_block
setblock 77 164 596 minecraft:cobbled_deepslate
setblock 77 164 597 minecraft:calcite
fill 77 164 598 80 164 598 minecraft:cobbled_deepslate
fill 78 164 575 82 165 575 minecraft:waxed_copper_block
fill 78 164 581 82 165 581 minecraft:waxed_copper_block
setblock 78 164 596 minecraft:calcite
fill 78 164 597 81 164 597 minecraft:cobbled_deepslate
setblock 79 164 560 minecraft:calcite
fill 79 164 596 79 167 596 minecraft:cobbled_deepslate
setblock 80 164 559 minecraft:calcite
fill 80 164 560 80 167 560 minecraft:cobbled_deepslate
fill 80 164 576 82 165 577 minecraft:waxed_copper_block
fill 80 164 579 82 165 580 minecraft:waxed_copper_block
setblock 81 164 558 minecraft:calcite
fill 81 164 559 81 167 559 minecraft:cobbled_deepslate
fill 81 164 578 83 165 578 minecraft:waxed_copper_block
fill 81 164 596 82 164 596 minecraft:cobbled_deepslate
setblock 81 164 598 minecraft:calcite
fill 82 164 558 85 164 558 minecraft:cobbled_deepslate
setblock 82 164 597 minecraft:calcite
fill 82 164 598 85 164 598 minecraft:cobbled_deepslate
fill 83 164 559 83 164 560 minecraft:cobbled_deepslate
setblock 83 164 596 minecraft:calcite
fill 83 164 597 86 164 597 minecraft:cobbled_deepslate
setblock 84 164 559 minecraft:cobbled_deepslate
fill 84 164 560 84 165 560 minecraft:deepslate
setblock 85 164 559 minecraft:calcite
setblock 86 164 558 minecraft:calcite
fill 86 164 559 87 166 559 minecraft:cobbled_deepslate
setblock 86 164 598 minecraft:calcite
fill 87 164 558 87 167 558 minecraft:cobbled_deepslate
fill 87 164 595 87 164 596 minecraft:cobbled_deepslate
setblock 87 164 597 minecraft:calcite
fill 87 164 598 87 167 598 minecraft:cobbled_deepslate
setblock 88 164 561 minecraft:calcite
setblock 88 164 595 minecraft:cobbled_deepslate
setblock 88 164 596 minecraft:calcite
fill 88 164 597 88 167 597 minecraft:cobbled_deepslate
fill 48 165 558 48 165 559 minecraft:cobbled_deepslate
setblock 48 165 575 minecraft:calcite
fill 48 165 576 48 168 576 minecraft:cobbled_deepslate
setblock 48 165 580 minecraft:calcite
fill 48 165 581 49 167 581 minecraft:cobbled_deepslate
fill 48 165 583 48 165 584 minecraft:cobbled_deepslate
setblock 48 165 585 minecraft:calcite
setblock 48 165 590 minecraft:calcite
fill 48 165 591 48 165 594 minecraft:cobbled_deepslate
setblock 48 165 595 minecraft:calcite
fill 48 165 596 48 166 598 minecraft:cobbled_deepslate
setblock 49 165 558 minecraft:cobbled_deepslate
fill 49 165 577 49 165 578 minecraft:cobbled_deepslate
setblock 49 165 579 minecraft:calcite
fill 49 165 580 49 168 580 minecraft:cobbled_deepslate
setblock 49 165 594 minecraft:calcite
fill 49 165 595 49 167 595 minecraft:cobbled_deepslate
fill 49 165 597 49 165 598 minecraft:cobbled_deepslate
setblock 50 165 558 minecraft:calcite
setblock 50 165 597 minecraft:cobbled_deepslate
setblock 50 165 598 minecraft:calcite
fill 51 165 558 54 165 558 minecraft:cobbled_deepslate
setblock 51 165 597 minecraft:calcite
fill 51 165 598 54 165 598 minecraft:cobbled_deepslate
fill 52 165 597 55 165 597 minecraft:cobbled_deepslate
fill 53 165 596 56 165 596 minecraft:cobbled_deepslate
setblock 54 165 559 minecraft:calcite
setblock 55 165 558 minecraft:calcite
fill 55 165 559 58 165 559 minecraft:cobbled_deepslate
setblock 55 165 598 minecraft:calcite
fill 56 165 558 59 165 558 minecraft:cobbled_deepslate
setblock 56 165 597 minecraft:calcite
fill 56 165 598 59 165 598 minecraft:cobbled_deepslate
setblock 57 165 596 minecraft:calcite
fill 57 165 597 60 165 597 minecraft:cobbled_deepslate
fill 58 165 596 58 166 596 minecraft:cobbled_deepslate
setblock 59 165 559 minecraft:calcite
setblock 60 165 558 minecraft:calcite
fill 60 165 559 60 168 559 minecraft:cobbled_deepslate
setblock 60 165 598 minecraft:calcite
fill 61 165 558 61 168 558 minecraft:cobbled_deepslate
setblock 61 165 597 minecraft:calcite
fill 61 165 598 61 168 598 minecraft:cobbled_deepslate
fill 62 165 559 62 166 559 minecraft:cobbled_deepslate
setblock 62 165 597 minecraft:cobbled_deepslate
fill 63 165 558 64 165 558 minecraft:cobbled_deepslate
setblock 64 165 598 minecraft:cobbled_deepslate
setblock 65 165 558 minecraft:calcite
setblock 65 165 598 minecraft:calcite
fill 66 165 558 69 165 558 minecraft:cobbled_deepslate
setblock 69 165 598 minecraft:cobbled_deepslate
setblock 70 165 558 minecraft:calcite
fill 70 165 559 73 165 559 minecraft:cobbled_deepslate
setblock 70 165 598 minecraft:calcite
fill 71 165 558 74 165 558 minecraft:cobbled_deepslate
fill 71 165 598 74 165 598 minecraft:cobbled_deepslate
setblock 73 165 560 minecraft:calcite
fill 73 165 597 75 165 597 minecraft:cobbled_deepslate
setblock 74 165 559 minecraft:calcite
fill 74 165 560 77 165 560 minecraft:cobbled_deepslate
setblock 75 165 558 minecraft:calcite
fill 75 165 559 78 165 559 minecraft:cobbled_deepslate
setblock 75 165 598 minecraft:calcite
fill 76 165 558 79 165 558 minecraft:cobbled_deepslate
setblock 76 165 561 minecraft:cobbled_deepslate
setblock 76 165 596 minecraft:cobbled_deepslate
setblock 76 165 597 minecraft:calcite
fill 76 165 598 79 165 598 minecraft:cobbled_deepslate
setblock 77 165 561 minecraft:calcite
setblock 77 165 596 minecraft:calcite
fill 77 165 597 80 165 597 minecraft:cobbled_deepslate
setblock 78 165 560 minecraft:calcite
fill 78 165 561 80 166 561 minecraft:cobbled_deepslate
fill 78 165 596 78 168 596 minecraft:cobbled_deepslate
setblock 79 165 559 minecraft:calcite
fill 79 165 560 79 168 560 minecraft:cobbled_deepslate
setblock 80 165 558 minecraft:calcite
fill 80 165 559 80 168 559 minecraft:cobbled_deepslate
setblock 80 165 598 minecraft:calcite
fill 81 165 558 84 165 558 minecraft:cobbled_deepslate
setblock 81 165 561 minecraft:deepslate
setblock 81 165 596 minecraft:cobbled_deepslate
setblock 81 165 597 minecraft:calcite
fill 81 165 598 84 165 598 minecraft:cobbled_deepslate
setblock 82 165 596 minecraft:calcite
fill 82 165 597 85 165 597 minecraft:cobbled_deepslate
setblock 83 165 559 minecraft:cobbled_deepslate
setblock 83 165 560 minecraft:calcite
setblock 83 165 563 minecraft:deepslate
setblock 83 165 596 minecraft:cobbled_deepslate
setblock 84 165 559 minecraft:calcite
setblock 85 165 558 minecraft:calcite
fill 85 165 559 85 168 559 minecraft:cobbled_deepslate
setblock 85 165 561 minecraft:deepslate
setblock 85 165 598 minecraft:calcite
fill 86 165 558 86 168 558 minecraft:cobbled_deepslate
setblock 86 165 597 minecraft:calcite
fill 86 165 598 86 168 598 minecraft:cobbled_deepslate
setblock 87 165 595 minecraft:cobbled_deepslate
setblock 87 165 596 minecraft:calcite
fill 87 165 597 87 168 597 minecraft:cobbled_deepslate
setblock 88 165 560 minecraft:calcite
fill 88 165 561 88 168 561 minecraft:cobbled_deepslate
setblock 88 165 595 minecraft:calcite
fill 88 165 596 88 168 596 minecraft:cobbled_deepslate
setblock 48 166 558 minecraft:cobbled_deepslate
setblock 48 166 559 minecraft:calcite
fill 48 166 575 48 168 575 minecraft:cobbled_deepslate
setblock 48 166 578 minecraft:cobbled_deepslate
setblock 48 166 579 minecraft:calcite
fill 48 166 580 48 169 580 minecraft:cobbled_deepslate
setblock 48 166 583 minecraft:cobbled_deepslate
setblock 48 166 584 minecraft:calcite
fill 48 166 585 48 166 588 minecraft:cobbled_deepslate
setblock 48 166 589 minecraft:calcite
fill 48 166 590 48 166 593 minecraft:cobbled_deepslate
setblock 48 166 594 minecraft:calcite
fill 48 166 595 48 169 595 minecraft:cobbled_deepslate
setblock 49 166 558 minecraft:calcite
setblock 49 166 577 minecraft:cobbled_deepslate
setblock 49 166 578 minecraft:calcite
fill 49 166 579 49 169 579 minecraft:cobbled_deepslate
setblock 49 166 582 minecraft:cobbled_deepslate
setblock 49 166 583 minecraft:calcite
fill 49 166 584 49 169 584 minecraft:cobbled_deepslate
setblock 49 166 594 minecraft:cobbled_deepslate
setblock 49 166 597 minecraft:cobbled_deepslate
setblock 49 166 598 minecraft:calcite
fill 50 166 558 53 166 558 minecraft:cobbled_deepslate
fill 50 166 580 50 167 580 minecraft:cobbled_deepslate
setblock 50 166 597 minecraft:calcite
fill 50 166 598 53 166 598 minecraft:cobbled_deepslate
fill 51 166 597 54 166 597 minecraft:cobbled_deepslate
setblock 52 166 559 minecraft:cobbled_deepslate
setblock 53 166 559 minecraft:calcite
fill 53 166 596 55 166 596 minecraft:cobbled_deepslate
setblock 54 166 558 minecraft:calcite
fill 54 166 559 57 166 559 minecraft:cobbled_deepslate
setblock 54 166 598 minecraft:calcite
fill 55 166 558 58 166 558 minecraft:cobbled_deepslate
setblock 55 166 597 minecraft:calcite
fill 55 166 598 58 166 598 minecraft:cobbled_deepslate
setblock 56 166 596 minecraft:calcite
fill 56 166 597 59 166 597 minecraft:cobbled_deepslate
setblock 57 166 596 minecraft:cobbled_deepslate
setblock 58 166 559 minecraft:calcite
setblock 59 166 558 minecraft:calcite
fill 59 166 559 59 169 559 minecraft:cobbled_deepslate
setblock 59 166 598 minecraft:calcite
fill 60 166 558 60 169 558 minecraft:cobbled_deepslate
setblock 60 166 597 minecraft:calcite
fill 60 166 598 60 169 598 minecraft:cobbled_deepslate
setblock 61 166 597 minecraft:cobbled_deepslate
setblock 63 166 558 minecraft:cobbled_deepslate
setblock 63 166 559 minecraft:calcite
setblock 64 166 558 minecraft:calcite
setblock 64 166 598 minecraft:calcite
fill 65 166 558 68 166 558 minecraft:cobbled_deepslate
setblock 65 166 598 minecraft:cobbled_deepslate
setblock 68 166 559 minecraft:calcite
setblock 68 166 598 minecraft:cobbled_deepslate
setblock 69 166 558 minecraft:calcite
fill 69 166 559 72 166 559 minecraft:cobbled_deepslate
setblock 69 166 598 minecraft:calcite
fill 70 166 558 73 166 558 minecraft:cobbled_deepslate
fill 70 166 598 73 166 598 minecraft:cobbled_deepslate
setblock 71 166 560 minecraft:cobbled_deepslate
setblock 72 166 560 minecraft:calcite
fill 72 166 597 74 166 597 minecraft:cobbled_deepslate
setblock 73 166 559 minecraft:calcite
fill 73 166 560 76 166 560 minecraft:cobbled_deepslate
setblock 74 166 558 minecraft:calcite
fill 74 166 559 77 166 559 minecraft:cobbled_deepslate
fill 74 166 561 75 166 561 minecraft:cobbled_deepslate
setblock 74 166 598 minecraft:calcite
fill 75 166 558 78 166 558 minecraft:cobbled_deepslate
setblock 75 166 597 minecraft:calcite
fill 75 166 598 78 166 598 minecraft:cobbled_deepslate
setblock 76 166 561 minecraft:calcite
setblock 76 166 596 minecraft:calcite
fill 76 166 597 79 166 597 minecraft:cobbled_deepslate
setblock 77 166 560 minecraft:calcite
fill 77 166 561 77 169 561 minecraft:cobbled_deepslate
fill 77 166 596 77 168 596 minecraft:cobbled_deepslate
setblock 78 166 559 minecraft:calcite
fill 78 166 560 78 169 560 minecraft:cobbled_deepslate
setblock 79 166 558 minecraft:calcite
fill 79 166 559 79 169 559 minecraft:cobbled_deepslate
setblock 79 166 598 minecraft:calcite
fill 80 166 558 83 166 558 minecraft:cobbled_deepslate
setblock 80 166 597 minecraft:calcite
fill 80 166 598 83 166 598 minecraft:cobbled_deepslate
setblock 81 166 560 minecraft:cobbled_deepslate
setblock 81 166 596 minecraft:calcite
fill 81 166 597 84 166 597 minecraft:cobbled_deepslate
setblock 82 166 560 minecraft:calcite
setblock 82 166 596 minecraft:cobbled_deepslate
setblock 83 166 559 minecraft:calcite
fill 83 166 560 84 166 560 minecraft:cobbled_deepslate
setblock 84 166 558 minecraft:calcite
fill 84 166 559 84 169 559 minecraft:cobbled_deepslate
setblock 84 166 598 minecraft:calcite
fill 85 166 558 85 169 558 minecraft:cobbled_deepslate
setblock 85 166 597 minecraft:calcite
fill 85 166 598 85 169 598 minecraft:cobbled_deepslate
fill 86 166 597 86 168 597 minecraft:cobbled_deepslate
setblock 87 166 560 minecraft:calcite
setblock 87 166 595 minecraft:calcite
fill 87 166 596 87 168 596 minecraft:cobbled_deepslate
setblock 88 166 559 minecraft:calcite
fill 88 166 560 88 169 560 minecraft:cobbled_deepslate
fill 88 166 562 88 167 562 minecraft:cobbled_deepslate
fill 88 166 577 88 166 578 minecraft:cobbled_deepslate
setblock 88 166 579 minecraft:calcite
fill 88 166 580 88 168 581 minecraft:cobbled_deepslate
setblock 88 166 592 minecraft:cobbled_deepslate
setblock 88 166 594 minecraft:calcite
fill 88 166 595 88 169 595 minecraft:cobbled_deepslate
setblock 48 167 558 minecraft:calcite
fill 48 167 559 48 169 560 minecraft:cobbled_deepslate
setblock 48 167 578 minecraft:calcite
fill 48 167 579 48 170 579 minecraft:cobbled_deepslate
setblock 48 167 583 minecraft:calcite
fill 48 167 584 48 167 587 minecraft:cobbled_deepslate
setblock 48 167 588 minecraft:calcite
fill 48 167 589 48 167 592 minecraft:cobbled_deepslate
setblock 48 167 593 minecraft:calcite
fill 48 167 594 48 169 594 minecraft:cobbled_deepslate
fill 48 167 596 48 167 597 minecraft:cobbled_deepslate
setblock 48 167 598 minecraft:calcite
fill 49 167 558 52 167 558 minecraft:cobbled_deepslate
setblock 49 167 576 minecraft:cobbled_deepslate
setblock 49 167 577 minecraft:calcite
fill 49 167 578 50 169 578 minecraft:cobbled_deepslate
setblock 49 167 582 minecraft:calcite
fill 49 167 583 50 169 583 minecraft:cobbled_deepslate
fill 49 167 585 49 168 585 minecraft:cobbled_deepslate
setblock 49 167 597 minecraft:calcite
fill 49 167 598 52 167 598 minecraft:cobbled_deepslate
fill 50 167 579 50 168 579 minecraft:cobbled_deepslate
setblock 50 167 581 minecraft:calcite
fill 50 167 582 50 170 582 minecraft:cobbled_deepslate
fill 50 167 597 53 167 597 minecraft:cobbled_deepslate
setblock 51 167 559 minecraft:cobbled_deepslate
setblock 52 167 559 minecraft:calcite
setblock 53 167 558 minecraft:calcite
fill 53 167 559 56 167 559 minecraft:cobbled_deepslate
fill 53 167 596 54 167 596 minecraft:cobbled_deepslate
setblock 53 167 598 minecraft:calcite
fill 54 167 558 57 167 558 minecraft:cobbled_deepslate
setblock 54 167 597 minecraft:calcite
fill 54 167 598 57 167 598 minecraft:cobbled_deepslate
setblock 55 167 596 minecraft:calcite
fill 55 167 597 58 167 597 minecraft:cobbled_deepslate
setblock 56 167 596 minecraft:cobbled_deepslate
setblock 57 167 559 minecraft:calcite
fill 57 167 560 57 168 560 minecraft:cobbled_deepslate
setblock 58 167 558 minecraft:calcite
fill 58 167 559 58 170 559 minecraft:cobbled_deepslate
setblock 58 167 598 minecraft:calcite
fill 59 167 558 59 170 558 minecraft:cobbled_deepslate
setblock 59 167 597 minecraft:calcite
fill 59 167 598 59 170 598 minecraft:cobbled_deepslate
setblock 60 167 597 minecraft:cobbled_deepslate
setblock 62 167 559 minecraft:calcite
setblock 63 167 558 minecraft:calcite
fill 63 167 559 63 168 559 minecraft:cobbled_deepslate
setblock 63 167 598 minecraft:calcite
fill 64 167 558 67 167 558 minecraft:cobbled_deepslate
setblock 64 167 598 minecraft:cobbled_deepslate
setblock 67 167 559 minecraft:calcite
setblock 68 167 558 minecraft:calcite
fill 68 167 559 71 167 559 minecraft:cobbled_deepslate
fill 69 167 558 72 167 558 minecraft:cobbled_deepslate
fill 69 167 598 72 167 598 minecraft:cobbled_deepslate
setblock 70 167 560 minecraft:cobbled_deepslate
setblock 71 167 560 minecraft:calcite
setblock 72 167 559 minecraft:calcite
fill 72 167 560 75 167 560 minecraft:cobbled_deepslate
fill 72 167 597 73 167 597 minecraft:cobbled_deepslate
setblock 73 167 558 minecraft:calcite
fill 73 167 559 76 167 559 minecraft:cobbled_deepslate
fill 73 167 561 74 167 561 minecraft:cobbled_deepslate
setblock 73 167 598 minecraft:calcite
fill 74 167 558 77 167 558 minecraft:cobbled_deepslate
setblock 74 167 597 minecraft:calcite
fill 74 167 598 77 167 598 minecraft:cobbled_deepslate
setblock 75 167 561 minecraft:calcite
fill 75 167 597 78 167 597 minecraft:cobbled_deepslate
setblock 76 167 560 minecraft:calcite
fill 76 167 561 76 170 561 minecraft:cobbled_deepslate
setblock 76 167 596 minecraft:cobbled_deepslate
setblock 77 167 559 minecraft:calcite
fill 77 167 560 77 170 560 minecraft:cobbled_deepslate
setblock 78 167 558 minecraft:calcite
fill 78 167 559 78 170 559 minecraft:cobbled_deepslate
fill 78 167 561 79 167 561 minecraft:cobbled_deepslate
setblock 78 167 598 minecraft:calcite
fill 79 167 558 82 167 558 minecraft:cobbled_deepslate
setblock 79 167 597 minecraft:calcite
fill 79 167 598 82 167 598 minecraft:cobbled_deepslate
setblock 80 167 561 minecraft:calcite
setblock 80 167 596 minecraft:calcite
fill 80 167 597 83 167 597 minecraft:cobbled_deepslate
setblock 81 167 560 minecraft:calcite
setblock 81 167 596 minecraft:cobbled_deepslate
setblock 82 167 559 minecraft:calcite
fill 82 167 560 83 168 560 minecraft:cobbled_deepslate
setblock 83 167 558 minecraft:calcite
fill 83 167 559 83 170 559 minecraft:cobbled_deepslate
setblock 83 167 598 minecraft:calcite
fill 84 167 558 84 170 558 minecraft:cobbled_deepslate
setblock 84 167 597 minecraft:calcite
fill 84 167 598 84 170 598 minecraft:cobbled_deepslate
fill 85 167 597 85 168 597 minecraft:cobbled_deepslate
setblock 86 167 559 minecraft:cobbled_deepslate
setblock 87 167 559 minecraft:calcite
fill 87 167 560 87 169 560 minecraft:cobbled_deepslate
setblock 88 167 558 minecraft:calcite
fill 88 167 559 88 170 559 minecraft:cobbled_deepslate
setblock 88 167 577 minecraft:cobbled_deepslate
setblock 88 167 578 minecraft:calcite
fill 88 167 579 88 170 579 minecraft:cobbled_deepslate
setblock 88 167 582 minecraft:cobbled_deepslate
setblock 88 167 583 minecraft:calcite
setblock 88 167 593 minecraft:calcite
fill 88 167 594 88 170 594 minecraft:cobbled_deepslate
setblock 88 167 598 minecraft:calcite
fill 48 168 558 51 168 558 minecraft:cobbled_deepslate
setblock 48 168 577 minecraft:calcite
fill 48 168 578 48 171 578 minecraft:cobbled_deepslate
setblock 48 168 581 minecraft:cobbled_deepslate
setblock 48 168 582 minecraft:calcite
fill 48 168 583 48 168 586 minecraft:cobbled_deepslate
setblock 48 168 587 minecraft:calcite
fill 48 168 588 48 168 591 minecraft:cobbled_deepslate
setblock 48 168 592 minecraft:calcite
fill 48 168 593 48 169 593 minecraft:cobbled_deepslate
setblock 48 168 596 minecraft:cobbled_deepslate
setblock 48 168 597 minecraft:calcite
fill 48 168 598 51 168 598 minecraft:cobbled_deepslate
fill 49 168 577 49 170 577 minecraft:cobbled_deepslate
setblock 49 168 581 minecraft:calcite
fill 49 168 582 49 171 582 minecraft:cobbled_deepslate
setblock 49 168 586 minecraft:calcite
fill 49 168 587 49 171 587 minecraft:cobbled_deepslate
setblock 49 168 596 minecraft:calcite
fill 49 168 597 52 168 597 minecraft:cobbled_deepslate
setblock 50 168 560 minecraft:light[level=14]
setblock 50 168 568 minecraft:light[level=14]
setblock 50 168 576 minecraft:light[level=14]
setblock 50 168 580 minecraft:calcite
fill 50 168 581 51 170 581 minecraft:cobbled_deepslate
setblock 50 168 584 minecraft:cobbled_deepslate
setblock 50 168 592 minecraft:light[level=14]
setblock 51 168 559 minecraft:calcite
fill 51 168 580 51 170 580 minecraft:cobbled_deepslate
setblock 52 168 558 minecraft:calcite
fill 52 168 559 55 168 559 minecraft:cobbled_deepslate
setblock 52 168 598 minecraft:calcite
fill 53 168 558 56 168 558 minecraft:cobbled_deepslate
setblock 53 168 597 minecraft:calcite
fill 53 168 598 56 168 598 minecraft:cobbled_deepslate
fill 54 168 597 57 168 597 minecraft:cobbled_deepslate
setblock 56 168 559 minecraft:calcite
fill 56 168 560 56 169 560 minecraft:cobbled_deepslate
setblock 57 168 558 minecraft:calcite
fill 57 168 559 57 171 559 minecraft:cobbled_deepslate
setblock 57 168 598 minecraft:calcite
fill 58 168 558 58 171 558 minecraft:cobbled_deepslate
setblock 58 168 560 minecraft:light[level=14]
setblock 58 168 568 minecraft:light[level=14]
setblock 58 168 576 minecraft:light[level=14]
setblock 58 168 584 minecraft:light[level=14]
setblock 58 168 592 minecraft:light[level=14]
setblock 58 168 597 minecraft:calcite
fill 58 168 598 58 170 598 minecraft:cobbled_deepslate
setblock 59 168 597 minecraft:cobbled_deepslate
setblock 61 168 559 minecraft:calcite
setblock 62 168 558 minecraft:calcite
setblock 62 168 559 minecraft:cobbled_deepslate
setblock 62 168 598 minecraft:calcite
fill 63 168 558 66 168 558 minecraft:cobbled_deepslate
setblock 66 168 559 minecraft:calcite
setblock 66 168 560 minecraft:light[level=14]
setblock 66 168 568 minecraft:light[level=14]
setblock 66 168 576 minecraft:light[level=14]
setblock 66 168 584 minecraft:light[level=14]
setblock 66 168 592 minecraft:light[level=14]
setblock 67 168 558 minecraft:calcite
fill 67 168 559 70 168 559 minecraft:cobbled_deepslate
fill 68 168 558 71 168 558 minecraft:cobbled_deepslate
fill 69 168 598 71 168 598 minecraft:cobbled_deepslate
setblock 70 168 560 minecraft:calcite
setblock 71 168 559 minecraft:calcite
fill 71 168 560 74 168 560 minecraft:cobbled_deepslate
setblock 72 168 558 minecraft:calcite
fill 72 168 559 75 168 559 minecraft:cobbled_deepslate
fill 72 168 561 73 168 561 minecraft:cobbled_deepslate
setblock 72 168 597 minecraft:cobbled_deepslate
setblock 72 168 598 minecraft:calcite
fill 73 168 558 76 168 558 minecraft:cobbled_deepslate
setblock 73 168 597 minecraft:calcite
fill 73 168 598 76 168 598 minecraft:cobbled_deepslate
setblock 74 168 561 minecraft:calcite
setblock 74 168 568 minecraft:light[level=14]
setblock 74 168 576 minecraft:light[level=14]
setblock 74 168 584 minecraft:light[level=14]
setblock 74 168 592 minecraft:light[level=14]
fill 74 168 597 77 168 597 minecraft:cobbled_deepslate
setblock 75 168 560 minecraft:calcite
fill 75 168 561 75 171 561 minecraft:cobbled_deepslate
setblock 76 168 559 minecraft:calcite
fill 76 168 560 76 171 560 minecraft:cobbled_deepslate
setblock 77 168 558 minecraft:calcite
fill 77 168 559 77 171 559 minecraft:cobbled_deepslate
setblock 77 168 598 minecraft:calcite
fill 78 168 558 81 168 558 minecraft:cobbled_deepslate
setblock 78 168 561 minecraft:cobbled_deepslate
setblock 78 168 597 minecraft:calcite
fill 78 168 598 81 168 598 minecraft:cobbled_deepslate
setblock 79 168 561 minecraft:calcite
fill 79 168 597 82 168 597 minecraft:cobbled_deepslate
setblock 80 168 560 minecraft:calcite
setblock 80 168 561 minecraft:cobbled_deepslate
setblock 81 168 559 minecraft:calcite
fill 81 168 560 81 170 560 minecraft:cobbled_deepslate
setblock 82 168 558 minecraft:calcite
fill 82 168 559 82 171 559 minecraft:cobbled_deepslate
setblock 82 168 568 minecraft:light[level=14]
setblock 82 168 576 minecraft:light[level=14]
setblock 82 168 584 minecraft:light[level=14]
setblock 82 168 592 minecraft:light[level=14]
setblock 82 168 598 minecraft:calcite
fill 83 168 558 83 171 558 minecraft:cobbled_deepslate
setblock 83 168 597 minecraft:calcite
fill 83 168 598 83 171 598 minecraft:cobbled_deepslate
setblock 84 168 597 minecraft:cobbled_deepslate
setblock 86 168 559 minecraft:calcite
setblock 87 168 558 minecraft:calcite
fill 87 168 559 87 170 559 minecraft:cobbled_deepslate
setblock 87 168 598 minecraft:calcite
fill 88 168 558 88 171 558 minecraft:cobbled_deepslate
setblock 88 168 562 minecraft:calcite
fill 88 168 563 88 171 563 minecraft:cobbled_deepslate
fill 88 168 578 88 169 578 minecraft:cobbled_deepslate
setblock 88 168 582 minecraft:calcite
fill 88 168 583 88 169 585 minecraft:cobbled_deepslate
fill 88 168 593 88 169 593 minecraft:cobbled_deepslate
setblock 88 168 597 minecraft:calcite
fill 88 168 598 88 171 598 minecraft:cobbled_deepslate
fill 48 169 558 50 169 558 minecraft:cobbled_deepslate
setblock 48 169 561 minecraft:calcite
setblock 48 169 576 minecraft:calcite
fill 48 169 577 48 172 577 minecraft:cobbled_deepslate
setblock 48 169 581 minecraft:calcite
fill 48 169 582 48 169 585 minecraft:cobbled_deepslate
setblock 48 169 586 minecraft:calcite
fill 48 169 587 48 169 590 minecraft:cobbled_deepslate
setblock 48 169 591 minecraft:calcite
setblock 48 169 592 minecraft:cobbled_deepslate
setblock 48 169 596 minecraft:calcite
fill 48 169 597 48 170 598 minecraft:cobbled_deepslate
setblock 49 169 580 minecraft:calcite
fill 49 169 581 49 172 581 minecraft:cobbled_deepslate
setblock 49 169 585 minecraft:calcite
fill 49 169 586 49 172 586 minecraft:cobbled_deepslate
fill 49 169 598 50 169 598 minecraft:cobbled_deepslate
setblock 50 169 579 minecraft:calcite
fill 50 169 580 50 172 580 minecraft:cobbled_deepslate
setblock 50 169 584 minecraft:calcite
fill 50 169 585 50 172 585 minecraft:cobbled_deepslate
fill 50 169 597 51 169 597 minecraft:cobbled_deepslate
setblock 51 169 558 minecraft:calcite
fill 51 169 559 54 169 559 minecraft:cobbled_deepslate
setblock 51 169 582 minecraft:cobbled_deepslate
setblock 51 169 583 minecraft:calcite
setblock 51 169 598 minecraft:calcite
fill 52 169 558 55 169 558 minecraft:cobbled_deepslate
setblock 52 169 597 minecraft:calcite
fill 52 169 598 55 169 598 minecraft:cobbled_deepslate
fill 53 169 597 56 169 597 minecraft:cobbled_deepslate
setblock 55 169 559 minecraft:calcite
setblock 56 169 558 minecraft:calcite
fill 56 169 559 56 172 559 minecraft:cobbled_deepslate
setblock 56 169 598 minecraft:calcite
fill 57 169 558 57 172 558 minecraft:cobbled_deepslate
setblock 57 169 597 minecraft:calcite
fill 57 169 598 57 171 598 minecraft:cobbled_deepslate
setblock 60 169 559 minecraft:calcite
setblock 61 169 558 minecraft:calcite
setblock 61 169 559 minecraft:cobbled_deepslate
fill 62 169 558 65 169 558 minecraft:cobbled_deepslate
setblock 66 169 558 minecraft:calcite
fill 66 169 559 69 169 559 minecraft:cobbled_deepslate
fill 67 169 558 70 169 558 minecraft:cobbled_deepslate
setblock 69 169 560 minecraft:calcite
fill 69 169 598 70 169 598 minecraft:cobbled_deepslate
setblock 70 169 559 minecraft:calcite
fill 70 169 560 73 169 560 minecraft:cobbled_deepslate
setblock 71 169 558 minecraft:calcite
fill 71 169 559 74 169 559 minecraft:cobbled_deepslate
setblock 71 169 598 minecraft:calcite
fill 72 169 558 75 169 558 minecraft:cobbled_deepslate
setblock 72 169 561 minecraft:cobbled_deepslate
fill 72 169 598 75 169 598 minecraft:cobbled_deepslate
setblock 73 169 561 minecraft:calcite
fill 73 169 597 76 169 597 minecraft:cobbled_deepslate
setblock 74 169 560 minecraft:calcite
fill 74 169 561 74 172 561 minecraft:cobbled_deepslate
setblock 75 169 559 minecraft:calcite
fill 75 169 560 75 172 560 minecraft:cobbled_deepslate
setblock 76 169 558 minecraft:calcite
fill 76 169 559 76 172 559 minecraft:cobbled_deepslate
setblock 76 169 598 minecraft:calcite
fill 77 169 558 80 169 558 minecraft:cobbled_deepslate
setblock 77 169 597 minecraft:calcite
fill 77 169 598 80 169 598 minecraft:cobbled_deepslate
setblock 78 169 561 minecraft:calcite
fill 78 169 597 81 169 597 minecraft:cobbled_deepslate
setblock 79 169 560 minecraft:calcite
setblock 79 169 561 minecraft:cobbled_deepslate
setblock 80 169 559 minecraft:calcite
fill 80 169 560 80 171 560 minecraft:cobbled_deepslate
setblock 81 169 558 minecraft:calcite
fill 81 169 559 81 172 559 minecraft:cobbled_deepslate
setblock 81 169 598 minecraft:calcite
fill 82 169 558 82 172 558 minecraft:cobbled_deepslate
setblock 82 169 560 minecraft:cobbled_deepslate
setblock 82 169 597 minecraft:calcite
fill 82 169 598 82 172 598 minecraft:cobbled_deepslate
setblock 83 169 597 minecraft:cobbled_deepslate
setblock 85 169 559 minecraft:calcite
setblock 86 169 558 minecraft:calcite
fill 86 169 559 86 170 559 minecraft:cobbled_deepslate
setblock 86 169 598 minecraft:calcite
fill 87 169 558 87 172 558 minecraft:cobbled_deepslate
setblock 87 169 597 minecraft:calcite
fill 87 169 598 87 172 598 minecraft:cobbled_deepslate
setblock 88 169 561 minecraft:calcite
fill 88 169 562 88 172 562 minecraft:cobbled_deepslate
setblock 88 169 580 minecraft:cobbled_deepslate
setblock 88 169 581 minecraft:calcite
fill 88 169 582 88 172 582 minecraft:cobbled_deepslate
setblock 88 169 586 minecraft:calcite
fill 88 169 587 88 172 587 minecraft:cobbled_deepslate
setblock 88 169 596 minecraft:calcite
fill 88 169 597 88 172 597 minecraft:cobbled_deepslate
fill 48 170 558 48 170 559 minecraft:cobbled_deepslate
setblock 48 170 560 minecraft:calcite
fill 48 170 561 48 173 561 minecraft:cobbled_deepslate
fill 48 170 576 48 171 576 minecraft:cobbled_deepslate
setblock 48 170 580 minecraft:calcite
fill 48 170 581 48 170 584 minecraft:cobbled_deepslate
setblock 48 170 585 minecraft:calcite
fill 48 170 586 48 170 589 minecraft:cobbled_deepslate
setblock 48 170 590 minecraft:calcite
fill 48 170 591 48 173 591 minecraft:cobbled_deepslate
setblock 48 170 595 minecraft:calcite
setblock 48 170 596 minecraft:cobbled_deepslate
setblock 49 170 558 minecraft:cobbled_deepslate
setblock 49 170 578 minecraft:cobbled_deepslate
setblock 49 170 579 minecraft:calcite
fill 49 170 580 49 173 580 minecraft:cobbled_deepslate
setblock 49 170 583 minecraft:cobbled_deepslate
setblock 49 170 584 minecraft:calcite
fill 49 170 585 49 173 585 minecraft:cobbled_deepslate
setblock 49 170 588 minecraft:cobbled_deepslate
setblock 49 170 598 minecraft:cobbled_deepslate
setblock 50 170 558 minecraft:calcite
setblock 50 170 578 minecraft:calcite
fill 50 170 579 50 172 579 minecraft:cobbled_deepslate
setblock 50 170 583 minecraft:calcite
fill 50 170 584 50 173 584 minecraft:cobbled_deepslate
fill 50 170 586 50 171 586 minecraft:cobbled_deepslate
setblock 50 170 598 minecraft:calcite
fill 51 170 558 53 170 559 minecraft:cobbled_deepslate
setblock 51 170 582 minecraft:calcite
fill 51 170 583 51 173 583 minecraft:cobbled_deepslate
fill 51 170 598 54 170 598 minecraft:cobbled_deepslate
fill 52 170 597 55 170 597 minecraft:cobbled_deepslate
setblock 54 170 558 minecraft:cobbled_deepslate
setblock 54 170 559 minecraft:calcite
setblock 55 170 558 minecraft:calcite
fill 55 170 559 55 172 559 minecraft:cobbled_deepslate
setblock 55 170 598 minecraft:calcite
fill 56 170 558 56 173 558 minecraft:cobbled_deepslate
fill 56 170 598 56 171 598 minecraft:cobbled_deepslate
setblock 59 170 559 minecraft:calcite
setblock 60 170 558 minecraft:calcite
setblock 60 170 559 minecraft:cobbled_deepslate
fill 61 170 558 64 170 558 minecraft:cobbled_deepslate
setblock 65 170 558 minecraft:calcite
fill 66 170 558 69 170 558 minecraft:cobbled_deepslate
fill 67 170 559 68 170 559 minecraft:cobbled_deepslate
setblock 69 170 559 minecraft:calcite
fill 69 170 560 72 170 560 minecraft:cobbled_deepslate
setblock 70 170 558 minecraft:calcite
fill 70 170 559 73 170 559 minecraft:cobbled_deepslate
setblock 70 170 598 minecraft:calcite
fill 71 170 558 74 170 558 minecraft:cobbled_deepslate
fill 71 170 598 74 170 598 minecraft:cobbled_deepslate
setblock 72 170 561 minecraft:calcite
setblock 73 170 560 minecraft:calcite
fill 73 170 561 73 173 561 minecraft:cobbled_deepslate
fill 73 170 597 75 170 597 minecraft:cobbled_deepslate
setblock 74 170 559 minecraft:calcite
fill 74 170 560 74 173 560 minecraft:cobbled_deepslate
setblock 75 170 558 minecraft:calcite
fill 75 170 559 75 173 559 minecraft:cobbled_deepslate
setblock 75 170 598 minecraft:calcite
fill 76 170 558 79 170 558 minecraft:cobbled_deepslate
setblock 76 170 597 minecraft:calcite
fill 76 170 598 79 170 598 minecraft:cobbled_deepslate
setblock 77 170 561 minecraft:calcite
fill 77 170 597 80 170 597 minecraft:cobbled_deepslate
setblock 78 170 560 minecraft:calcite
setblock 78 170 561 minecraft:cobbled_deepslate
setblock 79 170 559 minecraft:calcite
fill 79 170 560 79 172 560 minecraft:cobbled_deepslate
setblock 80 170 558 minecraft:calcite
fill 80 170 559 80 173 559 minecraft:cobbled_deepslate
setblock 80 170 598 minecraft:calcite
fill 81 170 558 81 173 558 minecraft:cobbled_deepslate
fill 81 170 598 81 172 598 minecraft:cobbled_deepslate
setblock 84 170 559 minecraft:calcite
setblock 85 170 558 minecraft:calcite
setblock 85 170 559 minecraft:cobbled_deepslate
setblock 85 170 598 minecraft:calcite
fill 86 170 558 86 173 558 minecraft:cobbled_deepslate
fill 86 170 598 86 172 598 minecraft:cobbled_deepslate
setblock 88 170 560 minecraft:calcite
fill 88 170 561 88 173 561 minecraft:cobbled_deepslate
setblock 88 170 580 minecraft:calcite
fill 88 170 581 88 173 581 minecraft:cobbled_deepslate
fill 88 170 583 88 170 584 minecraft:cobbled_deepslate
setblock 88 170 585 minecraft:calcite
fill 88 170 586 88 173 586 minecraft:cobbled_deepslate
fill 88 170 588 88 171 588 minecraft:cobbled_deepslate
setblock 88 170 595 minecraft:calcite
fill 88 170 596 88 172 596 minecraft:cobbled_deepslate
setblock 48 171 558 minecraft:cobbled_deepslate
setblock 48 171 559 minecraft:calcite
fill 48 171 560 48 172 560 minecraft:cobbled_deepslate
setblock 48 171 579 minecraft:calcite
fill 48 171 580 48 171 583 minecraft:cobbled_deepslate
setblock 48 171 584 minecraft:calcite
fill 48 171 585 48 171 588 minecraft:cobbled_deepslate
setblock 48 171 589 minecraft:calcite
fill 48 171 590 48 174 590 minecraft:cobbled_deepslate
setblock 48 171 598 minecraft:cobbled_deepslate
setblock 49 171 558 minecraft:calcite
setblock 49 171 578 minecraft:calcite
fill 49 171 579 49 174 579 minecraft:cobbled_deepslate
setblock 49 171 583 minecraft:calcite
fill 49 171 584 49 174 584 minecraft:cobbled_deepslate
setblock 49 171 588 minecraft:calcite
setblock 49 171 598 minecraft:calcite
fill 50 171 558 53 171 558 minecraft:cobbled_deepslate
setblock 50 171 581 minecraft:cobbled_deepslate
setblock 50 171 582 minecraft:calcite
fill 50 171 583 50 174 583 minecraft:cobbled_deepslate
fill 50 171 598 53 171 598 minecraft:cobbled_deepslate
setblock 51 171 581 minecraft:calcite
fill 51 171 582 51 174 582 minecraft:cobbled_deepslate
fill 51 171 584 51 172 584 minecraft:cobbled_deepslate
setblock 52 171 559 minecraft:cobbled_deepslate
setblock 53 171 559 minecraft:calcite
setblock 54 171 558 minecraft:calcite
fill 54 171 559 54 172 559 minecraft:cobbled_deepslate
setblock 54 171 598 minecraft:calcite
fill 55 171 558 55 174 558 minecraft:cobbled_deepslate
fill 55 171 598 55 172 598 minecraft:cobbled_deepslate
setblock 58 171 559 minecraft:calcite
setblock 59 171 558 minecraft:calcite
fill 60 171 558 63 171 558 minecraft:cobbled_deepslate
setblock 64 171 558 minecraft:calcite
fill 65 171 558 68 171 558 minecraft:cobbled_deepslate
setblock 67 171 559 minecraft:cobbled_deepslate
setblock 68 171 559 minecraft:calcite
setblock 69 171 558 minecraft:calcite
fill 69 171 559 71 171 560 minecraft:cobbled_deepslate
fill 70 171 558 73 171 558 minecraft:cobbled_deepslate
fill 70 171 598 73 171 598 minecraft:cobbled_deepslate
setblock 71 171 561 minecraft:calcite
setblock 72 171 559 minecraft:cobbled_deepslate
setblock 72 171 560 minecraft:calcite
fill 72 171 561 72 174 561 minecraft:cobbled_deepslate
setblock 73 171 559 minecraft:calcite
fill 73 171 560 73 174 560 minecraft:cobbled_deepslate
setblock 74 171 558 minecraft:calcite
fill 74 171 559 74 174 559 minecraft:cobbled_deepslate
setblock 74 171 597 minecraft:cobbled_deepslate
setblock 74 171 598 minecraft:calcite
fill 75 171 558 78 171 558 minecraft:cobbled_deepslate
setblock 75 171 597 minecraft:calcite
fill 75 171 598 78 171 598 minecraft:cobbled_deepslate
setblock 76 171 561 minecraft:calcite
fill 76 171 597 78 171 597 minecraft:cobbled_deepslate
setblock 77 171 560 minecraft:calcite
setblock 77 171 561 minecraft:cobbled_deepslate
setblock 78 171 559 minecraft:calcite
fill 78 171 560 78 173 560 minecraft:cobbled_deepslate
setblock 79 171 558 minecraft:calcite
fill 79 171 559 79 174 559 minecraft:cobbled_deepslate
setblock 79 171 598 minecraft:calcite
fill 80 171 558 80 174 558 minecraft:cobbled_deepslate
fill 80 171 598 80 173 598 minecraft:cobbled_deepslate
setblock 83 171 559 minecraft:calcite
setblock 84 171 558 minecraft:calcite
setblock 84 171 598 minecraft:calcite
fill 85 171 558 85 172 558 minecraft:cobbled_deepslate
setblock 85 171 598 minecraft:cobbled_deepslate
setblock 88 171 559 minecraft:calcite
fill 88 171 560 88 174 560 minecraft:cobbled_deepslate
setblock 88 171 579 minecraft:calcite
fill 88 171 580 88 174 580 minecraft:cobbled_deepslate
setblock 88 171 583 minecraft:cobbled_deepslate
setblock 88 171 584 minecraft:calcite
fill 88 171 585 88 174 585 minecraft:cobbled_deepslate
setblock 88 171 589 minecraft:calcite
setblock 88 171 595 minecraft:cobbled_deepslate
fill 48 172 565 51 173 567 minecraft:light_blue_stained_glass
setblock 48 172 578 minecraft:calcite
fill 48 172 579 48 172 582 minecraft:cobbled_deepslate
setblock 48 172 583 minecraft:calcite
fill 48 172 584 48 172 587 minecraft:cobbled_deepslate
setblock 48 172 588 minecraft:calcite
fill 48 172 589 49 174 589 minecraft:cobbled_deepslate
fill 49 172 558 52 172 558 minecraft:cobbled_deepslate
fill 49 172 578 49 175 578 minecraft:cobbled_deepslate
setblock 49 172 582 minecraft:calcite
fill 49 172 583 49 175 583 minecraft:cobbled_deepslate
setblock 49 172 587 minecraft:calcite
fill 49 172 588 49 175 588 minecraft:cobbled_deepslate
setblock 50 172 581 minecraft:calcite
fill 50 172 582 50 175 582 minecraft:cobbled_deepslate
setblock 50 172 586 minecraft:calcite
fill 50 172 587 50 175 587 minecraft:cobbled_deepslate
fill 50 172 598 52 172 598 minecraft:cobbled_deepslate
setblock 52 172 559 minecraft:calcite
fill 52 172 566 52 174 566 minecraft:light_blue_stained_glass
setblock 53 172 558 minecraft:calcite
setblock 53 172 559 minecraft:cobbled_deepslate
setblock 53 172 598 minecraft:calcite
fill 54 172 558 54 175 558 minecraft:cobbled_deepslate
setblock 54 172 598 minecraft:cobbled_deepslate
setblock 58 172 558 minecraft:calcite
setblock 59 172 558 minecraft:cobbled_deepslate
fill 65 172 558 67 172 558 minecraft:cobbled_deepslate
setblock 67 172 559 minecraft:calcite
setblock 68 172 558 minecraft:calcite
fill 68 172 559 71 172 559 minecraft:cobbled_deepslate
fill 69 172 558 72 172 558 minecraft:cobbled_deepslate
fill 69 172 560 70 172 560 minecraft:cobbled_deepslate
setblock 71 172 560 minecraft:calcite
fill 71 172 561 71 175 561 minecraft:cobbled_deepslate
fill 71 172 598 72 172 598 minecraft:cobbled_deepslate
setblock 72 172 559 minecraft:calcite
fill 72 172 560 72 175 560 minecraft:cobbled_deepslate
setblock 73 172 558 minecraft:calcite
fill 73 172 559 73 175 559 minecraft:cobbled_deepslate
setblock 73 172 598 minecraft:calcite
fill 74 172 558 77 172 558 minecraft:cobbled_deepslate
fill 74 172 598 77 172 598 minecraft:cobbled_deepslate
setblock 75 172 561 minecraft:calcite
setblock 76 172 560 minecraft:calcite
setblock 76 172 561 minecraft:cobbled_deepslate
setblock 77 172 559 minecraft:calcite
fill 77 172 560 77 174 560 minecraft:cobbled_deepslate
setblock 78 172 558 minecraft:calcite
fill 78 172 559 78 175 559 minecraft:cobbled_deepslate
setblock 78 172 598 minecraft:calcite
fill 79 172 558 79 175 558 minecraft:cobbled_deepslate
fill 79 172 598 79 173 598 minecraft:cobbled_deepslate
setblock 83 172 558 minecraft:calcite
fill 84 172 558 84 173 558 minecraft:cobbled_deepslate
setblock 88 172 558 minecraft:calcite
fill 88 172 559 88 175 559 minecraft:cobbled_deepslate
setblock 88 172 563 minecraft:calcite
setblock 88 172 583 minecraft:calcite
fill 88 172 584 88 175 584 minecraft:cobbled_deepslate
setblock 88 172 588 minecraft:calcite
fill 88 172 589 88 173 591 minecraft:cobbled_deepslate
setblock 88 172 598 minecraft:calcite
setblock 48 173 562 minecraft:calcite
fill 48 173 563 48 176 563 minecraft:cobbled_deepslate
fill 48 173 564 49 173 564 minecraft:light_blue_stained_glass
fill 48 173 568 49 174 568 minecraft:light_blue_stained_glass
setblock 48 173 577 minecraft:calcite
fill 48 173 578 48 173 581 minecraft:cobbled_deepslate
setblock 48 173 582 minecraft:calcite
fill 48 173 583 48 173 586 minecraft:cobbled_deepslate
setblock 48 173 587 minecraft:calcite
fill 48 173 588 48 176 588 minecraft:cobbled_deepslate
setblock 49 173 581 minecraft:calcite
fill 49 173 582 49 176 582 minecraft:cobbled_deepslate
setblock 49 173 586 minecraft:calcite
fill 49 173 587 49 176 587 minecraft:cobbled_deepslate
fill 50 173 558 51 173 558 minecraft:cobbled_deepslate
setblock 50 173 580 minecraft:calcite
fill 50 173 581 50 176 581 minecraft:cobbled_deepslate
setblock 50 173 585 minecraft:calcite
fill 50 173 586 50 176 586 minecraft:cobbled_deepslate
setblock 51 173 584 minecraft:calcite
setblock 52 173 558 minecraft:calcite
fill 52 173 565 53 173 565 minecraft:light_blue_stained_glass
fill 52 173 567 53 173 567 minecraft:light_blue_stained_glass
setblock 52 173 598 minecraft:calcite
fill 53 173 558 53 176 558 minecraft:cobbled_deepslate
fill 53 173 566 55 173 566 minecraft:light_blue_stained_glass
setblock 57 173 558 minecraft:calcite
setblock 66 173 558 minecraft:cobbled_deepslate
setblock 67 173 558 minecraft:calcite
fill 67 173 559 70 173 559 minecraft:cobbled_deepslate
fill 68 173 558 71 173 558 minecraft:cobbled_deepslate
setblock 69 173 560 minecraft:cobbled_deepslate
setblock 70 173 560 minecraft:calcite
setblock 71 173 559 minecraft:calcite
fill 71 173 560 71 176 560 minecraft:cobbled_deepslate
setblock 71 173 598 minecraft:cobbled_deepslate
setblock 72 173 558 minecraft:calcite
fill 72 173 559 72 176 559 minecraft:cobbled_deepslate
setblock 72 173 598 minecraft:calcite
fill 73 173 558 76 173 558 minecraft:cobbled_deepslate
fill 73 173 598 76 173 598 minecraft:cobbled_deepslate
setblock 74 173 561 minecraft:calcite
setblock 75 173 560 minecraft:calcite
setblock 75 173 561 minecraft:cobbled_deepslate
setblock 76 173 559 minecraft:calcite
fill 76 173 560 76 175 560 minecraft:cobbled_deepslate
setblock 77 173 558 minecraft:calcite
fill 77 173 559 77 176 559 minecraft:cobbled_deepslate
setblock 77 173 598 minecraft:calcite
fill 78 173 558 78 176 558 minecraft:cobbled_deepslate
fill 78 173 598 78 174 598 minecraft:cobbled_deepslate
setblock 82 173 558 minecraft:calcite
setblock 83 173 558 minecraft:cobbled_deepslate
setblock 87 173 558 minecraft:calcite
setblock 87 173 598 minecraft:calcite
fill 88 173 558 88 176 558 minecraft:cobbled_deepslate
setblock 88 173 562 minecraft:calcite
fill 88 173 563 88 176 563 minecraft:cobbled_deepslate
setblock 88 173 582 minecraft:calcite
fill 88 173 583 88 176 583 minecraft:cobbled_deepslate
setblock 88 173 587 minecraft:calcite
fill 88 173 588 88 176 588 minecraft:cobbled_deepslate
setblock 88 173 592 minecraft:calcite
setblock 88 173 597 minecraft:calcite
fill 88 173 598 88 176 598 minecraft:cobbled_deepslate
setblock 48 174 561 minecraft:calcite
fill 48 174 562 48 177 562 minecraft:cobbled_deepslate
fill 48 174 564 48 174 565 minecraft:cobbled_deepslate
fill 48 174 566 51 174 567 minecraft:light_blue_stained_glass
fill 48 174 577 48 174 580 minecraft:cobbled_deepslate
setblock 48 174 581 minecraft:calcite
fill 48 174 582 48 174 585 minecraft:cobbled_deepslate
setblock 48 174 586 minecraft:calcite
fill 48 174 587 48 177 587 minecraft:cobbled_deepslate
setblock 48 174 591 minecraft:calcite
fill 48 174 592 48 177 592 minecraft:cobbled_deepslate
fill 49 174 564 49 174 565 minecraft:light_blue_stained_glass
setblock 49 174 580 minecraft:calcite
fill 49 174 581 49 177 581 minecraft:cobbled_deepslate
setblock 49 174 585 minecraft:calcite
fill 49 174 586 49 177 586 minecraft:cobbled_deepslate
setblock 49 174 590 minecraft:calcite
setblock 50 174 558 minecraft:cobbled_deepslate
fill 50 174 565 52 174 565 minecraft:light_blue_stained_glass
fill 50 174 580 50 177 580 minecraft:cobbled_deepslate
setblock 50 174 584 minecraft:calcite
fill 50 174 585 51 176 585 minecraft:cobbled_deepslate
setblock 50 174 588 minecraft:cobbled_deepslate
setblock 51 174 558 minecraft:calcite
setblock 51 174 583 minecraft:calcite
fill 51 174 584 51 177 584 minecraft:cobbled_deepslate
fill 52 174 558 52 177 558 minecraft:cobbled_deepslate
setblock 52 174 567 minecraft:light_blue_stained_glass
setblock 53 174 566 minecraft:light_blue_stained_glass
setblock 56 174 558 minecraft:calcite
setblock 66 174 558 minecraft:calcite
fill 67 174 558 69 174 559 minecraft:cobbled_deepslate
setblock 69 174 560 minecraft:calcite
setblock 70 174 558 minecraft:cobbled_deepslate
setblock 70 174 559 minecraft:calcite
fill 70 174 560 70 177 560 minecraft:cobbled_deepslate
setblock 71 174 558 minecraft:calcite
fill 71 174 559 71 177 559 minecraft:cobbled_deepslate
setblock 71 174 598 minecraft:calcite
fill 72 174 558 75 174 558 minecraft:cobbled_deepslate
fill 72 174 598 75 174 598 minecraft:cobbled_deepslate
setblock 73 174 561 minecraft:calcite
setblock 74 174 560 minecraft:calcite
setblock 74 174 561 minecraft:cobbled_deepslate
setblock 75 174 559 minecraft:calcite
fill 75 174 560 75 177 560 minecraft:cobbled_deepslate
setblock 76 174 558 minecraft:calcite
fill 76 174 559 76 177 559 minecraft:cobbled_deepslate
setblock 76 174 598 minecraft:calcite
fill 77 174 558 77 177 558 minecraft:cobbled_deepslate
fill 77 174 598 77 177 598 minecraft:cobbled_deepslate
setblock 81 174 558 minecraft:calcite
setblock 87 174 558 minecraft:cobbled_deepslate
fill 87 174 584 87 174 586 minecraft:cobbled_deepslate
setblock 87 174 587 minecraft:calcite
setblock 88 174 561 minecraft:calcite
fill 88 174 562 88 177 562 minecraft:cobbled_deepslate
fill 88 174 564 88 175 564 minecraft:cobbled_deepslate
setblock 88 174 581 minecraft:calcite
fill 88 174 582 88 177 582 minecraft:cobbled_deepslate
setblock 88 174 586 minecraft:calcite
fill 88 174 587 88 177 587 minecraft:cobbled_deepslate
fill 88 174 589 88 174 590 minecraft:cobbled_deepslate
setblock 88 174 591 minecraft:calcite
fill 88 174 592 88 174 595 minecraft:cobbled_deepslate
setblock 88 174 596 minecraft:calcite
fill 88 174 597 88 177 597 minecraft:cobbled_deepslate
setblock 48 175 560 minecraft:calcite
fill 48 175 561 48 178 561 minecraft:cobbled_deepslate
setblock 48 175 564 minecraft:cobbled_deepslate
setblock 48 175 565 minecraft:calcite
fill 48 175 566 48 176 568 minecraft:cobbled_deepslate
fill 48 175 576 48 175 579 minecraft:cobbled_deepslate
setblock 48 175 580 minecraft:calcite
fill 48 175 581 48 175 584 minecraft:cobbled_deepslate
setblock 48 175 585 minecraft:calcite
fill 48 175 586 48 178 586 minecraft:cobbled_deepslate
setblock 48 175 589 minecraft:cobbled_deepslate
setblock 48 175 590 minecraft:calcite
fill 48 175 591 49 177 591 minecraft:cobbled_deepslate
fill 48 175 593 48 176 593 minecraft:cobbled_deepslate
fill 49 175 565 50 175 567 minecraft:light_blue_stained_glass
setblock 49 175 579 minecraft:calcite
fill 49 175 580 49 178 580 minecraft:cobbled_deepslate
setblock 49 175 584 minecraft:calcite
fill 49 175 585 49 178 585 minecraft:cobbled_deepslate
setblock 49 175 589 minecraft:calcite
fill 49 175 590 49 178 590 minecraft:cobbled_deepslate
setblock 50 175 583 minecraft:calcite
fill 50 175 584 50 178 584 minecraft:cobbled_deepslate
setblock 50 175 588 minecraft:calcite
fill 50 175 589 50 178 589 minecraft:cobbled_deepslate
fill 51 175 558 51 178 558 minecraft:cobbled_deepslate
setblock 51 175 582 minecraft:calcite
fill 51 175 583 51 178 583 minecraft:cobbled_deepslate
setblock 51 175 586 minecraft:cobbled_deepslate
fill 66 175 558 69 175 558 minecraft:cobbled_deepslate
fill 67 175 559 68 175 559 minecraft:cobbled_deepslate
setblock 69 175 559 minecraft:calcite
fill 69 175 560 69 178 560 minecraft:cobbled_deepslate
setblock 70 175 558 minecraft:calcite
fill 70 175 559 70 178 559 minecraft:cobbled_deepslate
setblock 70 175 598 minecraft:calcite
fill 71 175 558 74 175 558 minecraft:cobbled_deepslate
fill 71 175 598 74 175 598 minecraft:cobbled_deepslate
setblock 72 175 561 minecraft:calcite
setblock 73 175 560 minecraft:calcite
fill 73 175 561 73 176 561 minecraft:cobbled_deepslate
setblock 74 175 559 minecraft:calcite
fill 74 175 560 74 178 560 minecraft:cobbled_deepslate
setblock 75 175 558 minecraft:calcite
fill 75 175 559 75 178 559 minecraft:cobbled_deepslate
setblock 75 175 598 minecraft:calcite
fill 76 175 558 76 178 558 minecraft:cobbled_deepslate
fill 76 175 598 76 178 598 minecraft:cobbled_deepslate
setblock 80 175 558 minecraft:calcite
fill 87 175 583 87 175 585 minecraft:cobbled_deepslate
setblock 87 175 586 minecraft:calcite
fill 87 175 587 87 175 590 minecraft:cobbled_deepslate
fill 87 175 598 87 177 598 minecraft:cobbled_deepslate
setblock 88 175 560 minecraft:calcite
fill 88 175 561 88 178 561 minecraft:cobbled_deepslate
setblock 88 175 565 minecraft:calcite
setblock 88 175 580 minecraft:calcite
fill 88 175 581 88 178 581 minecraft:cobbled_deepslate
setblock 88 175 585 minecraft:calcite
fill 88 175 586 88 178 586 minecraft:cobbled_deepslate
setblock 88 175 589 minecraft:cobbled_deepslate
setblock 88 175 590 minecraft:calcite
fill 88 175 591 88 175 594 minecraft:cobbled_deepslate
setblock 88 175 595 minecraft:calcite
fill 88 175 596 88 178 596 minecraft:cobbled_deepslate
fill 48 176 560 48 179 560 minecraft:cobbled_deepslate
setblock 48 176 564 minecraft:calcite
fill 48 176 565 49 178 565 minecraft:cobbled_deepslate
setblock 48 176 569 minecraft:calcite
fill 48 176 570 48 176 573 minecraft:cobbled_deepslate
setblock 48 176 574 minecraft:calcite
fill 48 176 575 48 176 578 minecraft:cobbled_deepslate
setblock 48 176 579 minecraft:calcite
fill 48 176 580 48 176 583 minecraft:cobbled_deepslate
setblock 48 176 584 minecraft:calcite
fill 48 176 585 48 179 585 minecraft:cobbled_deepslate
setblock 48 176 589 minecraft:calcite
fill 48 176 590 48 179 590 minecraft:cobbled_deepslate
setblock 48 176 594 minecraft:calcite
setblock 49 176 562 minecraft:cobbled_deepslate
setblock 49 176 563 minecraft:calcite
fill 49 176 564 49 179 564 minecraft:cobbled_deepslate
fill 49 176 566 49 176 567 minecraft:cobbled_deepslate
setblock 49 176 568 minecraft:calcite
setblock 49 176 577 minecraft:cobbled_deepslate
setblock 49 176 578 minecraft:calcite
fill 49 176 579 49 179 579 minecraft:cobbled_deepslate
setblock 49 176 583 minecraft:calcite
fill 49 176 584 49 179 584 minecraft:cobbled_deepslate
setblock 49 176 588 minecraft:calcite
fill 49 176 589 49 179 589 minecraft:cobbled_deepslate
setblock 49 176 592 minecraft:cobbled_deepslate
fill 50 176 558 50 179 558 minecraft:cobbled_deepslate
setblock 50 176 560 minecraft:light[level=14]
setblock 50 176 568 minecraft:light[level=14]
setblock 50 176 576 minecraft:light[level=14]
setblock 50 176 582 minecraft:calcite
fill 50 176 583 50 179 583 minecraft:cobbled_deepslate
setblock 50 176 587 minecraft:calcite
fill 50 176 588 50 179 588 minecraft:cobbled_deepslate
fill 50 176 590 50 177 590 minecraft:cobbled_deepslate
setblock 50 176 592 minecraft:light[level=14]
setblock 51 176 586 minecraft:calcite
fill 51 176 587 51 179 587 minecraft:cobbled_deepslate
setblock 58 176 560 minecraft:light[level=14]
setblock 58 176 568 minecraft:light[level=14]
setblock 58 176 576 minecraft:light[level=14]
setblock 58 176 584 minecraft:light[level=14]
setblock 58 176 592 minecraft:light[level=14]
fill 65 176 558 68 176 558 minecraft:cobbled_deepslate
setblock 66 176 560 minecraft:light[level=14]
setblock 66 176 568 minecraft:light[level=14]
setblock 66 176 576 minecraft:light[level=14]
setblock 66 176 584 minecraft:light[level=14]
setblock 66 176 592 minecraft:light[level=14]
setblock 67 176 559 minecraft:cobbled_deepslate
setblock 68 176 559 minecraft:calcite
fill 68 176 560 68 179 560 minecraft:cobbled_deepslate
setblock 69 176 558 minecraft:calcite
fill 69 176 559 69 179 559 minecraft:cobbled_deepslate
fill 70 176 558 73 176 558 minecraft:cobbled_deepslate
setblock 70 176 561 minecraft:cobbled_deepslate
fill 70 176 598 73 176 598 minecraft:cobbled_deepslate
setblock 71 176 561 minecraft:calcite
setblock 72 176 560 minecraft:calcite
fill 72 176 561 72 178 561 minecraft:cobbled_deepslate
setblock 73 176 559 minecraft:calcite
fill 73 176 560 73 179 560 minecraft:cobbled_deepslate
setblock 74 176 558 minecraft:calcite
fill 74 176 559 74 179 559 minecraft:cobbled_deepslate
setblock 74 176 568 minecraft:light[level=14]
setblock 74 176 576 minecraft:light[level=14]
setblock 74 176 584 minecraft:light[level=14]
setblock 74 176 592 minecraft:light[level=14]
setblock 74 176 598 minecraft:calcite
fill 75 176 558 75 179 558 minecraft:cobbled_deepslate
fill 75 176 598 75 179 598 minecraft:cobbled_deepslate
setblock 79 176 558 minecraft:calcite
setblock 82 176 560 minecraft:light[level=14]
setblock 82 176 568 minecraft:light[level=14]
setblock 82 176 576 minecraft:light[level=14]
setblock 82 176 584 minecraft:light[level=14]
setblock 82 176 592 minecraft:light[level=14]
fill 87 176 582 87 176 584 minecraft:cobbled_deepslate
setblock 87 176 585 minecraft:calcite
fill 87 176 586 87 176 589 minecraft:cobbled_deepslate
setblock 87 176 590 minecraft:calcite
fill 87 176 591 88 177 592 minecraft:cobbled_deepslate
setblock 88 176 559 minecraft:calcite
fill 88 176 560 88 179 560 minecraft:cobbled_deepslate
setblock 88 176 564 minecraft:calcite
fill 88 176 565 88 177 567 minecraft:cobbled_deepslate
setblock 88 176 579 minecraft:calcite
fill 88 176 580 88 179 580 minecraft:cobbled_deepslate
setblock 88 176 584 minecraft:calcite
fill 88 176 585 88 179 585 minecraft:cobbled_deepslate
setblock 88 176 589 minecraft:calcite
fill 88 176 590 88 179 590 minecraft:cobbled_deepslate
setblock 88 176 593 minecraft:cobbled_deepslate
setblock 88 176 594 minecraft:calcite
fill 88 176 595 88 179 595 minecraft:cobbled_deepslate
setblock 48 177 563 minecraft:calcite
fill 48 177 564 48 180 564 minecraft:cobbled_deepslate
fill 48 177 566 48 177 567 minecraft:cobbled_deepslate
setblock 48 177 568 minecraft:calcite
fill 48 177 569 48 177 572 minecraft:cobbled_deepslate
setblock 48 177 573 minecraft:calcite
fill 48 177 574 48 177 577 minecraft:cobbled_deepslate
setblock 48 177 578 minecraft:calcite
fill 48 177 579 48 177 582 minecraft:cobbled_deepslate
setblock 48 177 583 minecraft:calcite
fill 48 177 584 48 180 584 minecraft:cobbled_deepslate
setblock 48 177 588 minecraft:calcite
fill 48 177 589 48 180 589 minecraft:cobbled_deepslate
setblock 48 177 593 minecraft:calcite
fill 48 177 594 48 179 595 minecraft:cobbled_deepslate
setblock 49 177 562 minecraft:calcite
fill 49 177 563 49 180 563 minecraft:cobbled_deepslate
setblock 49 177 566 minecraft:cobbled_deepslate
setblock 49 177 567 minecraft:calcite
fill 49 177 568 49 177 571 minecraft:cobbled_deepslate
setblock 49 177 572 minecraft:calcite
fill 49 177 573 49 180 573 minecraft:cobbled_deepslate
setblock 49 177 576 minecraft:cobbled_deepslate
setblock 49 177 577 minecraft:calcite
fill 49 177 578 49 180 578 minecraft:cobbled_deepslate
setblock 49 177 582 minecraft:calcite
fill 49 177 583 49 180 583 minecraft:cobbled_deepslate
setblock 49 177 587 minecraft:calcite
fill 49 177 588 49 180 588 minecraft:cobbled_deepslate
setblock 49 177 592 minecraft:calcite
fill 49 177 593 49 180 593 minecraft:cobbled_deepslate
setblock 50 177 565 minecraft:cobbled_deepslate
setblock 50 177 566 minecraft:calcite
fill 50 177 567 50 179 568 minecraft:cobbled_deepslate
fill 50 177 579 50 178 579 minecraft:cobbled_deepslate
setblock 50 177 581 minecraft:calcite
fill 50 177 582 50 180 582 minecraft:cobbled_deepslate
setblock 50 177 585 minecraft:cobbled_deepslate
setblock 50 177 586 minecraft:calcite
fill 50 177 587 50 180 587 minecraft:cobbled_deepslate
setblock 50 177 591 minecraft:calcite
setblock 51 177 585 minecraft:calcite
fill 51 177 586 51 180 586 minecraft:cobbled_deepslate
fill 51 177 588 51 178 588 minecraft:cobbled_deepslate
setblock 53 177 558 minecraft:calcite
fill 65 177 558 67 177 558 minecraft:cobbled_deepslate
setblock 66 177 559 minecraft:cobbled_deepslate
setblock 67 177 559 minecraft:calcite
setblock 68 177 558 minecraft:calcite
fill 68 177 559 68 180 559 minecraft:cobbled_deepslate
fill 69 177 558 72 177 558 minecraft:cobbled_deepslate
fill 69 177 598 72 177 598 minecraft:cobbled_deepslate
setblock 70 177 561 minecraft:calcite
setblock 71 177 560 minecraft:calcite
fill 71 177 561 71 179 561 minecraft:cobbled_deepslate
setblock 72 177 559 minecraft:calcite
fill 72 177 560 72 180 560 minecraft:cobbled_deepslate
setblock 73 177 558 minecraft:calcite
fill 73 177 559 73 180 559 minecraft:cobbled_deepslate
setblock 73 177 598 minecraft:calcite
fill 74 177 558 74 180 558 minecraft:cobbled_deepslate
fill 74 177 598 74 180 598 minecraft:cobbled_deepslate
setblock 77 177 559 minecraft:calcite
setblock 78 177 558 minecraft:calcite
setblock 79 177 558 minecraft:cobbled_deepslate
fill 86 177 586 86 177 589 minecraft:cobbled_deepslate
fill 86 177 598 86 178 598 minecraft:cobbled_deepslate
setblock 87 177 558 minecraft:cobbled_deepslate
fill 87 177 582 87 177 583 minecraft:cobbled_deepslate
setblock 87 177 584 minecraft:calcite
fill 87 177 585 87 177 588 minecraft:cobbled_deepslate
setblock 87 177 589 minecraft:calcite
fill 87 177 590 87 180 590 minecraft:cobbled_deepslate
setblock 87 177 593 minecraft:cobbled_deepslate
setblock 87 177 594 minecraft:calcite
setblock 88 177 558 minecraft:calcite
fill 88 177 559 88 180 559 minecraft:cobbled_deepslate
setblock 88 177 563 minecraft:calcite
fill 88 177 564 88 180 564 minecraft:cobbled_deepslate
setblock 88 177 568 minecraft:calcite
fill 88 177 569 88 179 570 minecraft:cobbled_deepslate
setblock 88 177 578 minecraft:calcite
fill 88 177 579 88 180 579 minecraft:cobbled_deepslate
setblock 88 177 583 minecraft:calcite
fill 88 177 584 88 180 584 minecraft:cobbled_deepslate
setblock 88 177 588 minecraft:calcite
fill 88 177 589 88 180 589 minecraft:cobbled_deepslate
setblock 88 177 593 minecraft:calcite
fill 88 177 594 88 180 594 minecraft:cobbled_deepslate
setblock 88 177 598 minecraft:calcite
fill 48 178 559 48 180 559 minecraft:cobbled_deepslate
setblock 48 178 562 minecraft:calcite
fill 48 178 563 48 181 563 minecraft:cobbled_deepslate
setblock 48 178 566 minecraft:cobbled_deepslate
setblock 48 178 567 minecraft:calcite
fill 48 178 568 48 178 571 minecraft:cobbled_deepslate
setblock 48 178 572 minecraft:calcite
fill 48 178 573 48 178 576 minecraft:cobbled_deepslate
setblock 48 178 577 minecraft:calcite
fill 48 178 578 48 178 581 minecraft:cobbled_deepslate
setblock 48 178 582 minecraft:calcite
fill 48 178 583 48 181 583 minecraft:cobbled_deepslate
setblock 48 178 587 minecraft:calcite
fill 48 178 588 48 181 588 minecraft:cobbled_deepslate
setblock 48 178 591 minecraft:cobbled_deepslate
setblock 48 178 592 minecraft:calcite
fill 48 178 593 48 181 593 minecraft:cobbled_deepslate
setblock 48 178 596 minecraft:cobbled_deepslate
setblock 48 178 597 minecraft:calcite
fill 49 178 558 49 180 558 minecraft:cobbled_deepslate
setblock 49 178 561 minecraft:calcite
fill 49 178 562 49 181 562 minecraft:cobbled_deepslate
setblock 49 178 566 minecraft:calcite
fill 49 178 567 49 178 570 minecraft:cobbled_deepslate
setblock 49 178 571 minecraft:calcite
fill 49 178 572 49 181 572 minecraft:cobbled_deepslate
fill 49 178 574 49 178 575 minecraft:cobbled_deepslate
setblock 49 178 576 minecraft:calcite
fill 49 178 577 49 181 577 minecraft:cobbled_deepslate
setblock 49 178 581 minecraft:calcite
fill 49 178 582 49 181 582 minecraft:cobbled_deepslate
setblock 49 178 586 minecraft:calcite
fill 49 178 587 49 181 587 minecraft:cobbled_deepslate
setblock 49 178 591 minecraft:calcite
fill 49 178 592 49 181 592 minecraft:cobbled_deepslate
fill 49 178 594 49 179 594 minecraft:cobbled_deepslate
setblock 50 178 564 minecraft:cobbled_deepslate
setblock 50 178 565 minecraft:calcite
fill 50 178 566 50 181 566 minecraft:cobbled_deepslate
setblock 50 178 569 minecraft:cobbled_deepslate
setblock 50 178 570 minecraft:calcite
fill 50 178 571 50 181 571 minecraft:cobbled_deepslate
setblock 50 178 580 minecraft:calcite
fill 50 178 581 50 181 581 minecraft:cobbled_deepslate
setblock 50 178 585 minecraft:calcite
fill 50 178 586 50 181 586 minecraft:cobbled_deepslate
setblock 50 178 590 minecraft:calcite
fill 50 178 591 50 181 591 minecraft:cobbled_deepslate
setblock 51 178 584 minecraft:calcite
fill 51 178 585 51 180 585 minecraft:cobbled_deepslate
setblock 51 178 589 minecraft:calcite
setblock 52 178 558 minecraft:calcite
setblock 53 178 558 minecraft:cobbled_deepslate
fill 64 178 558 66 178 558 minecraft:cobbled_deepslate
setblock 65 178 559 minecraft:cobbled_deepslate
setblock 66 178 559 minecraft:calcite
setblock 67 178 558 minecraft:calcite
fill 67 178 559 67 180 560 minecraft:cobbled_deepslate
fill 68 178 558 71 178 558 minecraft:cobbled_deepslate
fill 68 178 598 71 178 598 minecraft:cobbled_deepslate
setblock 69 178 561 minecraft:calcite
setblock 70 178 560 minecraft:calcite
fill 70 178 561 70 180 561 minecraft:cobbled_deepslate
setblock 71 178 559 minecraft:calcite
fill 71 178 560 71 181 560 minecraft:cobbled_deepslate
setblock 72 178 558 minecraft:calcite
fill 72 178 559 72 181 559 minecraft:cobbled_deepslate
setblock 72 178 597 minecraft:cobbled_deepslate
setblock 72 178 598 minecraft:calcite
fill 73 178 558 73 181 558 minecraft:cobbled_deepslate
fill 73 178 598 73 181 598 minecraft:cobbled_deepslate
setblock 76 178 559 minecraft:calcite
setblock 77 178 558 minecraft:calcite
setblock 77 178 598 minecraft:calcite
fill 78 178 558 78 179 558 minecraft:cobbled_deepslate
fill 84 178 598 85 179 598 minecraft:cobbled_deepslate
fill 86 178 585 86 178 588 minecraft:cobbled_deepslate
setblock 86 178 589 minecraft:calcite
fill 86 178 590 86 179 592 minecraft:cobbled_deepslate
setblock 87 178 558 minecraft:calcite
setblock 87 178 563 minecraft:calcite
fill 87 178 564 87 179 566 minecraft:cobbled_deepslate
fill 87 178 581 87 178 582 minecraft:cobbled_deepslate
setblock 87 178 583 minecraft:calcite
fill 87 178 584 87 178 587 minecraft:cobbled_deepslate
setblock 87 178 588 minecraft:calcite
fill 87 178 589 87 181 589 minecraft:cobbled_deepslate
fill 87 178 591 87 178 592 minecraft:cobbled_deepslate
setblock 87 178 593 minecraft:calcite
fill 87 178 594 87 179 596 minecraft:cobbled_deepslate
setblock 87 178 598 minecraft:calcite
fill 88 178 558 88 181 558 minecraft:cobbled_deepslate
setblock 88 178 562 minecraft:calcite
fill 88 178 563 88 181 563 minecraft:cobbled_deepslate
fill 88 178 565 88 178 566 minecraft:cobbled_deepslate
setblock 88 178 567 minecraft:calcite
fill 88 178 568 88 181 568 minecraft:cobbled_deepslate
setblock 88 178 571 minecraft:cobbled_deepslate
setblock 88 178 572 minecraft:calcite
fill 88 178 573 88 181 573 minecraft:cobbled_deepslate
setblock 88 178 577 minecraft:calcite
fill 88 178 578 88 181 578 minecraft:cobbled_deepslate
setblock 88 178 582 minecraft:calcite
fill 88 178 583 88 181 583 minecraft:cobbled_deepslate
setblock 88 178 587 minecraft:calcite
fill 88 178 588 88 181 588 minecraft:cobbled_deepslate
setblock 88 178 591 minecraft:cobbled_deepslate
setblock 88 178 592 minecraft:calcite
fill 88 178 593 88 181 593 minecraft:cobbled_deepslate
setblock 88 178 597 minecraft:calcite
fill 88 178 598 88 181 598 minecraft:cobbled_deepslate
setblock 48 179 561 minecraft:calcite
fill 48 179 562 48 182 562 minecraft:cobbled_deepslate
setblock 48 179 565 minecraft:cobbled_deepslate
setblock 48 179 566 minecraft:calcite
fill 48 179 567 48 179 570 minecraft:cobbled_deepslate
setblock 48 179 571 minecraft:calcite
fill 48 179 572 48 179 575 minecraft:cobbled_deepslate
setblock 48 179 576 minecraft:calcite
fill 48 179 577 48 179 580 minecraft:cobbled_deepslate
setblock 48 179 581 minecraft:calcite
fill 48 179 582 48 182 582 minecraft:cobbled_deepslate
setblock 48 179 586 minecraft:calcite
fill 48 179 587 48 182 587 minecraft:cobbled_deepslate
setblock 48 179 591 minecraft:calcite
fill 48 179 592 48 182 592 minecraft:cobbled_deepslate
setblock 48 179 596 minecraft:calcite
fill 48 179 597 48 181 598 minecraft:cobbled_deepslate
fill 49 179 561 49 181 561 minecraft:cobbled_deepslate
setblock 49 179 565 minecraft:calcite
fill 49 179 566 49 179 569 minecraft:cobbled_deepslate
setblock 49 179 570 minecraft:calcite
fill 49 179 571 49 182 571 minecraft:cobbled_deepslate
setblock 49 179 574 minecraft:cobbled_deepslate
setblock 49 179 575 minecraft:calcite
fill 49 179 576 49 182 576 minecraft:cobbled_deepslate
setblock 49 179 580 minecraft:calcite
fill 49 179 581 49 182 581 minecraft:cobbled_deepslate
setblock 49 179 585 minecraft:calcite
fill 49 179 586 49 182 586 minecraft:cobbled_deepslate
setblock 49 179 590 minecraft:calcite
fill 49 179 591 49 182 591 minecraft:cobbled_deepslate
setblock 49 179 595 minecraft:calcite
fill 49 179 598 50 179 598 minecraft:cobbled_deepslate
setblock 50 179 563 minecraft:cobbled_deepslate
setblock 50 179 564 minecraft:calcite
fill 50 179 565 50 182 565 minecraft:cobbled_deepslate
setblock 50 179 569 minecraft:calcite
fill 50 179 570 50 182 570 minecraft:cobbled_deepslate
fill 50 179 572 50 179 573 minecraft:cobbled_deepslate
setblock 50 179 574 minecraft:calcite
fill 50 179 575 50 182 575 minecraft:cobbled_deepslate
setblock 50 179 578 minecraft:cobbled_deepslate
setblock 50 179 579 minecraft:calcite
fill 50 179 580 50 182 580 minecraft:cobbled_deepslate
setblock 50 179 584 minecraft:calcite
fill 50 179 585 50 182 585 minecraft:cobbled_deepslate
setblock 50 179 589 minecraft:calcite
fill 50 179 590 50 182 590 minecraft:cobbled_deepslate
fill 50 179 592 50 180 592 minecraft:cobbled_deepslate
setblock 51 179 558 minecraft:calcite
fill 51 179 566 51 179 567 minecraft:cobbled_deepslate
setblock 51 179 568 minecraft:calcite
fill 51 179 569 51 182 569 minecraft:cobbled_deepslate
setblock 51 179 583 minecraft:calcite
fill 51 179 584 51 180 584 minecraft:cobbled_deepslate
setblock 51 179 588 minecraft:calcite
fill 51 179 589 51 181 589 minecraft:cobbled_deepslate
fill 52 179 558 52 180 558 minecraft:cobbled_deepslate
fill 63 179 558 65 179 558 minecraft:cobbled_deepslate
setblock 65 179 559 minecraft:calcite
setblock 66 179 558 minecraft:calcite
fill 66 179 559 66 181 560 minecraft:cobbled_deepslate
fill 67 179 558 70 179 558 minecraft:cobbled_deepslate
fill 67 179 598 70 179 598 minecraft:cobbled_deepslate
setblock 68 179 561 minecraft:calcite
setblock 69 179 560 minecraft:calcite
fill 69 179 561 69 180 561 minecraft:cobbled_deepslate
fill 69 179 597 71 179 597 minecraft:cobbled_deepslate
setblock 70 179 559 minecraft:calcite
fill 70 179 560 70 182 560 minecraft:cobbled_deepslate
setblock 71 179 558 minecraft:calcite
fill 71 179 559 71 182 559 minecraft:cobbled_deepslate
setblock 71 179 598 minecraft:calcite
fill 72 179 558 72 182 558 minecraft:cobbled_deepslate
setblock 72 179 597 minecraft:calcite
fill 72 179 598 72 182 598 minecraft:cobbled_deepslate
fill 73 179 597 74 181 597 minecraft:cobbled_deepslate
setblock 74 179 560 minecraft:calcite
setblock 75 179 559 minecraft:calcite
setblock 76 179 558 minecraft:calcite
setblock 76 179 598 minecraft:calcite
fill 77 179 558 77 180 558 minecraft:cobbled_deepslate
fill 77 179 598 78 181 598 minecraft:cobbled_deepslate
fill 83 179 598 83 181 598 minecraft:cobbled_deepslate
setblock 86 179 558 minecraft:calcite
fill 86 179 584 86 179 587 minecraft:cobbled_deepslate
setblock 86 179 588 minecraft:calcite
fill 86 179 589 86 182 589 minecraft:cobbled_deepslate
setblock 86 179 593 minecraft:calcite
setblock 86 179 597 minecraft:cobbled_deepslate
setblock 86 179 598 minecraft:calcite
fill 87 179 558 87 182 558 minecraft:cobbled_deepslate
fill 87 179 563 87 182 563 minecraft:cobbled_deepslate
setblock 87 179 567 minecraft:calcite
fill 87 179 568 87 181 569 minecraft:cobbled_deepslate
setblock 87 179 581 minecraft:cobbled_deepslate
setblock 87 179 582 minecraft:calcite
fill 87 179 583 87 179 586 minecraft:cobbled_deepslate
setblock 87 179 587 minecraft:calcite
fill 87 179 588 87 182 588 minecraft:cobbled_deepslate
setblock 87 179 591 minecraft:cobbled_deepslate
setblock 87 179 592 minecraft:calcite
fill 87 179 593 87 182 593 minecraft:cobbled_deepslate
setblock 87 179 597 minecraft:calcite
fill 87 179 598 87 182 598 minecraft:cobbled_deepslate
setblock 88 179 561 minecraft:calcite
fill 88 179 562 88 182 562 minecraft:cobbled_deepslate
setblock 88 179 565 minecraft:cobbled_deepslate
setblock 88 179 566 minecraft:calcite
fill 88 179 567 88 182 567 minecraft:cobbled_deepslate
setblock 88 179 571 minecraft:calcite
fill 88 179 572 88 182 572 minecraft:cobbled_deepslate
fill 88 179 574 88 179 575 minecraft:cobbled_deepslate
setblock 88 179 576 minecraft:calcite
fill 88 179 577 88 182 577 minecraft:cobbled_deepslate
setblock 88 179 581 minecraft:calcite
fill 88 179 582 88 182 582 minecraft:cobbled_deepslate
setblock 88 179 586 minecraft:calcite
fill 88 179 587 88 182 587 minecraft:cobbled_deepslate
setblock 88 179 591 minecraft:calcite
fill 88 179 592 88 182 592 minecraft:cobbled_deepslate
setblock 88 179 596 minecraft:calcite
fill 88 179 597 88 182 597 minecraft:cobbled_deepslate
fill 48 180 558 48 181 558 minecraft:cobbled_deepslate
setblock 48 180 560 minecraft:calcite
fill 48 180 561 48 183 561 minecraft:cobbled_deepslate
setblock 48 180 565 minecraft:calcite
fill 48 180 566 48 180 569 minecraft:cobbled_deepslate
setblock 48 180 570 minecraft:calcite
fill 48 180 571 48 180 574 minecraft:cobbled_deepslate
setblock 48 180 575 minecraft:calcite
fill 48 180 576 48 180 579 minecraft:cobbled_deepslate
setblock 48 180 580 minecraft:calcite
fill 48 180 581 48 183 581 minecraft:cobbled_deepslate
setblock 48 180 585 minecraft:calcite
fill 48 180 586 48 183 586 minecraft:cobbled_deepslate
setblock 48 180 590 minecraft:calcite
fill 48 180 591 48 183 591 minecraft:cobbled_deepslate
setblock 48 180 594 minecraft:cobbled_deepslate
setblock 48 180 595 minecraft:calcite
fill 48 180 596 48 183 596 minecraft:cobbled_deepslate
setblock 49 180 564 minecraft:calcite
fill 49 180 565 49 180 568 minecraft:cobbled_deepslate
setblock 49 180 569 minecraft:calcite
fill 49 180 570 49 183 570 minecraft:cobbled_deepslate
setblock 49 180 574 minecraft:calcite
fill 49 180 575 49 183 575 minecraft:cobbled_deepslate
setblock 49 180 579 minecraft:calcite
fill 49 180 580 49 183 580 minecraft:cobbled_deepslate
setblock 49 180 584 minecraft:calcite
fill 49 180 585 49 183 585 minecraft:cobbled_deepslate
setblock 49 180 589 minecraft:calcite
fill 49 180 590 49 183 590 minecraft:cobbled_deepslate
setblock 49 180 594 minecraft:calcite
fill 49 180 595 49 183 595 minecraft:cobbled_deepslate
setblock 49 180 598 minecraft:cobbled_deepslate
setblock 50 180 558 minecraft:calcite
setblock 50 180 563 minecraft:calcite
fill 50 180 564 50 182 564 minecraft:cobbled_deepslate
setblock 50 180 567 minecraft:cobbled_deepslate
setblock 50 180 568 minecraft:calcite
fill 50 180 569 50 183 569 minecraft:cobbled_deepslate
setblock 50 180 572 minecraft:cobbled_deepslate
setblock 50 180 573 minecraft:calcite
fill 50 180 574 50 183 574 minecraft:cobbled_deepslate
fill 50 180 576 50 180 577 minecraft:cobbled_deepslate
setblock 50 180 578 minecraft:calcite
fill 50 180 579 50 182 579 minecraft:cobbled_deepslate
setblock 50 180 583 minecraft:calcite
fill 50 180 584 50 183 584 minecraft:cobbled_deepslate
setblock 50 180 588 minecraft:calcite
fill 50 180 589 50 183 589 minecraft:cobbled_deepslate
setblock 50 180 593 minecraft:calcite
setblock 50 180 598 minecraft:calcite
fill 51 180 558 51 181 558 minecraft:cobbled_deepslate
setblock 51 180 566 minecraft:cobbled_deepslate
setblock 51 180 567 minecraft:calcite
fill 51 180 568 51 183 568 minecraft:cobbled_deepslate
fill 51 180 570 51 180 571 minecraft:cobbled_deepslate
setblock 51 180 587 minecraft:calcite
fill 51 180 588 51 181 588 minecraft:cobbled_deepslate
fill 51 180 598 51 182 598 minecraft:cobbled_deepslate
fill 63 180 558 64 180 558 minecraft:cobbled_deepslate
setblock 64 180 559 minecraft:calcite
setblock 65 180 558 minecraft:calcite
fill 65 180 559 65 183 559 minecraft:cobbled_deepslate
fill 66 180 558 69 180 558 minecraft:cobbled_deepslate
fill 66 180 598 69 180 598 minecraft:cobbled_deepslate
setblock 68 180 560 minecraft:calcite
setblock 68 180 561 minecraft:cobbled_deepslate
fill 68 180 597 70 180 597 minecraft:cobbled_deepslate
setblock 69 180 559 minecraft:calcite
fill 69 180 560 69 183 560 minecraft:cobbled_deepslate
setblock 70 180 558 minecraft:calcite
fill 70 180 559 70 183 559 minecraft:cobbled_deepslate
setblock 70 180 598 minecraft:calcite
fill 71 180 558 71 183 558 minecraft:cobbled_deepslate
setblock 71 180 597 minecraft:calcite
fill 71 180 598 71 183 598 minecraft:cobbled_deepslate
fill 72 180 597 72 183 597 minecraft:cobbled_deepslate
setblock 73 180 560 minecraft:calcite
setblock 74 180 559 minecraft:calcite
setblock 75 180 558 minecraft:calcite
setblock 75 180 559 minecraft:cobbled_deepslate
setblock 75 180 598 minecraft:calcite
fill 76 180 558 76 181 558 minecraft:cobbled_deepslate
fill 76 180 598 76 183 598 minecraft:cobbled_deepslate
setblock 79 180 598 minecraft:cobbled_deepslate
setblock 80 180 598 minecraft:calcite
fill 81 180 598 82 182 598 minecraft:cobbled_deepslate
setblock 84 180 598 minecraft:cobbled_deepslate
setblock 85 180 587 minecraft:cobbled_deepslate
setblock 85 180 588 minecraft:calcite
fill 85 180 589 85 181 591 minecraft:cobbled_deepslate
setblock 85 180 597 minecraft:cobbled_deepslate
setblock 85 180 598 minecraft:calcite
fill 86 180 558 86 183 558 minecraft:cobbled_deepslate
fill 86 180 583 86 180 586 minecraft:cobbled_deepslate
setblock 86 180 587 minecraft:calcite
fill 86 180 588 86 183 588 minecraft:cobbled_deepslate
fill 86 180 590 86 180 591 minecraft:cobbled_deepslate
setblock 86 180 592 minecraft:calcite
fill 86 180 593 86 181 595 minecraft:cobbled_deepslate
setblock 86 180 597 minecraft:calcite
fill 86 180 598 86 183 598 minecraft:cobbled_deepslate
setblock 87 180 562 minecraft:cobbled_deepslate
fill 87 180 564 87 180 565 minecraft:cobbled_deepslate
setblock 87 180 566 minecraft:calcite
fill 87 180 567 87 183 567 minecraft:cobbled_deepslate
setblock 87 180 570 minecraft:cobbled_deepslate
setblock 87 180 571 minecraft:calcite
fill 87 180 572 87 183 572 minecraft:cobbled_deepslate
setblock 87 180 580 minecraft:cobbled_deepslate
setblock 87 180 581 minecraft:calcite
fill 87 180 582 87 180 585 minecraft:cobbled_deepslate
setblock 87 180 586 minecraft:calcite
fill 87 180 587 87 183 587 minecraft:cobbled_deepslate
setblock 87 180 591 minecraft:calcite
fill 87 180 592 87 183 592 minecraft:cobbled_deepslate
fill 87 180 594 87 180 595 minecraft:cobbled_deepslate
setblock 87 180 596 minecraft:calcite
fill 87 180 597 87 183 597 minecraft:cobbled_deepslate
setblock 88 180 560 minecraft:calcite
fill 88 180 561 88 183 561 minecraft:cobbled_deepslate
setblock 88 180 565 minecraft:calcite
fill 88 180 566 88 183 566 minecraft:cobbled_deepslate
setblock 88 180 569 minecraft:cobbled_deepslate
setblock 88 180 570 minecraft:calcite
fill 88 180 571 88 183 571 minecraft:cobbled_deepslate
setblock 88 180 574 minecraft:cobbled_deepslate
setblock 88 180 575 minecraft:calcite
fill 88 180 576 88 183 576 minecraft:cobbled_deepslate
setblock 88 180 580 minecraft:calcite
fill 88 180 581 88 183 581 minecraft:cobbled_deepslate
setblock 88 180 585 minecraft:calcite
fill 88 180 586 88 183 586 minecraft:cobbled_deepslate
setblock 88 180 590 minecraft:calcite
fill 88 180 591 88 183 591 minecraft:cobbled_deepslate
setblock 88 180 595 minecraft:calcite
fill 88 180 596 88 183 596 minecraft:cobbled_deepslate
setblock 48 181 559 minecraft:calcite
fill 48 181 560 48 184 560 minecraft:cobbled_deepslate
setblock 48 181 564 minecraft:calcite
fill 48 181 565 48 181 568 minecraft:cobbled_deepslate
setblock 48 181 569 minecraft:calcite
fill 48 181 570 48 181 573 minecraft:cobbled_deepslate
setblock 48 181 574 minecraft:calcite
fill 48 181 575 48 181 578 minecraft:cobbled_deepslate
setblock 48 181 579 minecraft:calcite
fill 48 181 580 48 184 580 minecraft:cobbled_deepslate
setblock 48 181 584 minecraft:calcite
fill 48 181 585 48 184 585 minecraft:cobbled_deepslate
setblock 48 181 589 minecraft:calcite
fill 48 181 590 48 184 590 minecraft:cobbled_deepslate
setblock 48 181 594 minecraft:calcite
fill 48 181 595 48 184 595 minecraft:cobbled_deepslate
setblock 49 181 558 minecraft:calcite
setblock 49 181 563 minecraft:calcite
fill 49 181 564 49 181 567 minecraft:cobbled_deepslate
setblock 49 181 568 minecraft:calcite
fill 49 181 569 49 184 569 minecraft:cobbled_deepslate
setblock 49 181 573 minecraft:calcite
fill 49 181 574 49 184 574 minecraft:cobbled_deepslate
setblock 49 181 578 minecraft:calcite
fill 49 181 579 49 184 579 minecraft:cobbled_deepslate
setblock 49 181 583 minecraft:calcite
fill 49 181 584 49 184 584 minecraft:cobbled_deepslate
setblock 49 181 588 minecraft:calcite
fill 49 181 589 49 184 589 minecraft:cobbled_deepslate
setblock 49 181 593 minecraft:calcite
fill 49 181 594 49 184 594 minecraft:cobbled_deepslate
fill 49 181 596 49 182 596 minecraft:cobbled_deepslate
setblock 49 181 598 minecraft:calcite
fill 50 181 558 50 182 558 minecraft:cobbled_deepslate
setblock 50 181 563 minecraft:cobbled_deepslate
setblock 50 181 567 minecraft:calcite
fill 50 181 568 50 184 568 minecraft:cobbled_deepslate
setblock 50 181 572 minecraft:calcite
fill 50 181 573 50 184 573 minecraft:cobbled_deepslate
setblock 50 181 576 minecraft:cobbled_deepslate
setblock 50 181 577 minecraft:calcite
fill 50 181 578 50 182 578 minecraft:cobbled_deepslate
setblock 50 181 582 minecraft:calcite
fill 50 181 583 50 182 583 minecraft:cobbled_deepslate
setblock 50 181 587 minecraft:calcite
fill 50 181 588 50 184 588 minecraft:cobbled_deepslate
setblock 50 181 592 minecraft:calcite
fill 50 181 593 50 183 593 minecraft:cobbled_deepslate
fill 50 181 598 50 184 598 minecraft:cobbled_deepslate
setblock 51 181 566 minecraft:calcite
fill 51 181 567 51 182 567 minecraft:cobbled_deepslate
setblock 51 181 570 minecraft:cobbled_deepslate
setblock 51 181 571 minecraft:calcite
fill 51 181 572 51 184 572 minecraft:cobbled_deepslate
setblock 51 181 586 minecraft:calcite
setblock 51 181 587 minecraft:cobbled_deepslate
fill 62 181 558 63 181 558 minecraft:cobbled_deepslate
setblock 64 181 558 minecraft:calcite
fill 64 181 559 64 184 559 minecraft:cobbled_deepslate
fill 65 181 558 68 181 558 minecraft:cobbled_deepslate
fill 65 181 598 68 181 598 minecraft:cobbled_deepslate
setblock 67 181 559 minecraft:cobbled_deepslate
setblock 67 181 560 minecraft:calcite
fill 67 181 597 69 181 597 minecraft:cobbled_deepslate
setblock 68 181 559 minecraft:calcite
fill 68 181 560 68 183 560 minecraft:cobbled_deepslate
setblock 69 181 558 minecraft:calcite
fill 69 181 559 69 184 559 minecraft:cobbled_deepslate
setblock 69 181 598 minecraft:calcite
fill 70 181 558 70 184 558 minecraft:cobbled_deepslate
setblock 70 181 596 minecraft:cobbled_deepslate
setblock 70 181 597 minecraft:calcite
fill 70 181 598 70 184 598 minecraft:cobbled_deepslate
fill 71 181 597 71 184 597 minecraft:cobbled_deepslate
setblock 72 181 560 minecraft:calcite
setblock 73 181 559 minecraft:calcite
setblock 74 181 558 minecraft:calcite
setblock 74 181 559 minecraft:cobbled_deepslate
setblock 74 181 598 minecraft:calcite
fill 75 181 558 75 182 558 minecraft:cobbled_deepslate
setblock 75 181 597 minecraft:calcite
fill 75 181 598 75 184 598 minecraft:cobbled_deepslate
setblock 79 181 598 minecraft:calcite
fill 80 181 598 80 184 598 minecraft:cobbled_deepslate
fill 83 181 597 84 181 597 minecraft:cobbled_deepslate
setblock 84 181 598 minecraft:calcite
setblock 85 181 587 minecraft:calcite
fill 85 181 588 85 184 588 minecraft:cobbled_deepslate
setblock 85 181 592 minecraft:calcite
setblock 85 181 597 minecraft:calcite
fill 85 181 598 85 184 598 minecraft:cobbled_deepslate
fill 86 181 583 86 181 585 minecraft:cobbled_deepslate
setblock 86 181 586 minecraft:calcite
fill 86 181 587 86 184 587 minecraft:cobbled_deepslate
setblock 86 181 590 minecraft:cobbled_deepslate
setblock 86 181 591 minecraft:calcite
fill 86 181 592 86 184 592 minecraft:cobbled_deepslate
setblock 86 181 596 minecraft:calcite
fill 86 181 597 86 184 597 minecraft:cobbled_deepslate
setblock 87 181 564 minecraft:cobbled_deepslate
setblock 87 181 565 minecraft:calcite
fill 87 181 566 87 184 566 minecraft:cobbled_deepslate
setblock 87 181 570 minecraft:calcite
fill 87 181 571 87 184 571 minecraft:cobbled_deepslate
fill 87 181 573 87 181 574 minecraft:cobbled_deepslate
setblock 87 181 575 minecraft:calcite
fill 87 181 578 87 181 579 minecraft:cobbled_deepslate
setblock 87 181 580 minecraft:calcite
fill 87 181 581 87 181 584 minecraft:cobbled_deepslate
setblock 87 181 585 minecraft:calcite
fill 87 181 586 87 184 586 minecraft:cobbled_deepslate
setblock 87 181 590 minecraft:calcite
fill 87 181 591 87 184 591 minecraft:cobbled_deepslate
setblock 87 181 594 minecraft:cobbled_deepslate
setblock 87 181 595 minecraft:calcite
fill 87 181 596 87 184 596 minecraft:cobbled_deepslate
setblock 88 181 559 minecraft:calcite
fill 88 181 560 88 183 560 minecraft:cobbled_deepslate
setblock 88 181 564 minecraft:calcite
fill 88 181 565 88 184 565 minecraft:cobbled_deepslate
setblock 88 181 569 minecraft:calcite
fill 88 181 570 88 184 570 minecraft:cobbled_deepslate
setblock 88 181 574 minecraft:calcite
fill 88 181 575 88 184 575 minecraft:cobbled_deepslate
setblock 88 181 579 minecraft:calcite
fill 88 181 580 88 184 580 minecraft:cobbled_deepslate
setblock 88 181 584 minecraft:calcite
fill 88 181 585 88 184 585 minecraft:cobbled_deepslate
setblock 88 181 589 minecraft:calcite
fill 88 181 590 88 184 590 minecraft:cobbled_deepslate
setblock 88 181 594 minecraft:calcite
fill 88 181 595 88 184 595 minecraft:cobbled_deepslate
setblock 48 182 558 minecraft:calcite
fill 48 182 559 48 183 559 minecraft:cobbled_deepslate
setblock 48 182 563 minecraft:calcite
fill 48 182 564 48 182 567 minecraft:cobbled_deepslate
setblock 48 182 568 minecraft:calcite
fill 48 182 569 48 182 572 minecraft:cobbled_deepslate
setblock 48 182 573 minecraft:calcite
fill 48 182 574 48 182 577 minecraft:cobbled_deepslate
setblock 48 182 578 minecraft:calcite
fill 48 182 579 48 185 579 minecraft:cobbled_deepslate
setblock 48 182 583 minecraft:calcite
fill 48 182 584 48 185 584 minecraft:cobbled_deepslate
setblock 48 182 588 minecraft:calcite
fill 48 182 589 48 185 589 minecraft:cobbled_deepslate
setblock 48 182 593 minecraft:calcite
fill 48 182 594 48 185 594 minecraft:cobbled_deepslate
setblock 48 182 597 minecraft:cobbled_deepslate
setblock 48 182 598 minecraft:calcite
setblock 49 182 558 minecraft:cobbled_deepslate
setblock 49 182 562 minecraft:calcite
fill 49 182 563 49 182 566 minecraft:cobbled_deepslate
setblock 49 182 567 minecraft:calcite
fill 49 182 568 49 185 568 minecraft:cobbled_deepslate
setblock 49 182 572 minecraft:calcite
fill 49 182 573 49 185 573 minecraft:cobbled_deepslate
setblock 49 182 577 minecraft:calcite
fill 49 182 578 49 185 578 minecraft:cobbled_deepslate
setblock 49 182 582 minecraft:calcite
fill 49 182 583 49 185 583 minecraft:cobbled_deepslate
setblock 49 182 587 minecraft:calcite
fill 49 182 588 49 185 588 minecraft:cobbled_deepslate
setblock 49 182 592 minecraft:calcite
fill 49 182 593 49 185 593 minecraft:cobbled_deepslate
fill 49 182 598 49 185 598 minecraft:cobbled_deepslate
setblock 50 182 566 minecraft:calcite
fill 50 182 567 50 185 567 minecraft:cobbled_deepslate
setblock 50 182 571 minecraft:calcite
fill 50 182 572 50 185 572 minecraft:cobbled_deepslate
setblock 50 182 576 minecraft:calcite
fill 50 182 577 50 183 577 minecraft:cobbled_deepslate
setblock 50 182 581 minecraft:calcite
setblock 50 182 582 minecraft:cobbled_deepslate
setblock 50 182 586 minecraft:calcite
fill 50 182 587 50 183 587 minecraft:cobbled_deepslate
setblock 50 182 591 minecraft:calcite
fill 50 182 592 50 184 592 minecraft:cobbled_deepslate
setblock 51 182 570 minecraft:calcite
fill 51 182 571 51 184 571 minecraft:cobbled_deepslate
fill 51 182 573 51 183 573 minecraft:cobbled_deepslate
setblock 62 182 558 minecraft:cobbled_deepslate
setblock 63 182 558 minecraft:calcite
fill 64 182 558 67 182 558 minecraft:cobbled_deepslate
fill 64 182 598 67 182 598 minecraft:cobbled_deepslate
setblock 66 182 559 minecraft:cobbled_deepslate
setblock 66 182 560 minecraft:calcite
fill 66 182 597 68 182 597 minecraft:cobbled_deepslate
setblock 67 182 559 minecraft:calcite
fill 67 182 560 67 183 560 minecraft:cobbled_deepslate
setblock 68 182 558 minecraft:calcite
fill 68 182 559 68 185 559 minecraft:cobbled_deepslate
fill 68 182 596 69 182 596 minecraft:cobbled_deepslate
setblock 68 182 598 minecraft:calcite
fill 69 182 558 69 185 558 minecraft:cobbled_deepslate
setblock 69 182 597 minecraft:calcite
fill 69 182 598 69 185 598 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_7 1t
