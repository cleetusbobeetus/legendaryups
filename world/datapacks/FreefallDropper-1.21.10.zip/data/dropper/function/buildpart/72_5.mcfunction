setblock 38 147 325 minecraft:light[level=12]
setblock 38 147 332 minecraft:light[level=12]
setblock 38 147 339 minecraft:light[level=12]
setblock 38 147 346 minecraft:light[level=12]
setblock 38 147 353 minecraft:light[level=12]
setblock 38 147 360 minecraft:light[level=12]
setblock 40 147 329 minecraft:yellow_terracotta
fill 40 147 330 40 149 331 minecraft:honeycomb_block
setblock 41 147 323 minecraft:yellow_terracotta
fill 41 147 324 41 150 324 minecraft:honeycomb_block
setblock 41 147 328 minecraft:yellow_terracotta
fill 41 147 329 41 150 329 minecraft:honeycomb_block
setblock 41 147 333 minecraft:yellow_terracotta
fill 41 147 334 41 149 335 minecraft:honeycomb_block
fill 41 147 351 41 147 352 minecraft:honeycomb_block
setblock 41 147 353 minecraft:yellow_terracotta
fill 41 147 354 41 147 357 minecraft:honeycomb_block
setblock 41 147 358 minecraft:yellow_terracotta
fill 41 147 359 41 147 362 minecraft:honeycomb_block
setblock 1 148 328 minecraft:honeycomb_block
setblock 1 148 332 minecraft:yellow_terracotta
fill 1 148 333 1 148 336 minecraft:honeycomb_block
setblock 1 148 347 minecraft:yellow_terracotta
fill 1 148 348 1 151 348 minecraft:honeycomb_block
setblock 1 148 351 minecraft:honeycomb_block
setblock 1 148 352 minecraft:yellow_terracotta
fill 1 148 353 1 151 353 minecraft:honeycomb_block
setblock 1 148 356 minecraft:honeycomb_block
setblock 1 148 357 minecraft:yellow_terracotta
fill 1 148 358 1 151 358 minecraft:honeycomb_block
setblock 1 148 362 minecraft:yellow_terracotta
fill 1 148 363 4 148 363 minecraft:honeycomb_block
setblock 2 148 323 minecraft:honey_block
setblock 2 148 351 minecraft:yellow_terracotta
fill 2 148 352 2 151 352 minecraft:honeycomb_block
setblock 2 148 356 minecraft:yellow_terracotta
fill 2 148 357 2 151 357 minecraft:honeycomb_block
setblock 2 148 361 minecraft:yellow_terracotta
fill 2 148 362 5 148 362 minecraft:honeycomb_block
setblock 3 148 350 minecraft:yellow_terracotta
fill 3 148 351 4 150 351 minecraft:honeycomb_block
setblock 3 148 355 minecraft:yellow_terracotta
fill 3 148 356 3 151 356 minecraft:honeycomb_block
setblock 3 148 359 minecraft:honeycomb_block
setblock 3 148 360 minecraft:yellow_terracotta
setblock 4 148 353 minecraft:honeycomb_block
setblock 4 148 354 minecraft:yellow_terracotta
fill 4 148 355 4 151 355 minecraft:honeycomb_block
fill 4 148 357 4 148 358 minecraft:honeycomb_block
setblock 5 148 323 minecraft:yellow_terracotta
fill 5 148 361 6 148 361 minecraft:honeycomb_block
setblock 5 148 363 minecraft:yellow_terracotta
fill 6 148 323 6 151 323 minecraft:honeycomb_block
setblock 6 148 362 minecraft:yellow_terracotta
fill 6 148 363 6 151 363 minecraft:honeycomb_block
setblock 7 148 361 minecraft:yellow_terracotta
fill 7 148 362 7 151 362 minecraft:honeycomb_block
fill 8 148 361 8 151 361 minecraft:honeycomb_block
setblock 10 148 322 minecraft:yellow_terracotta
setblock 10 148 363 minecraft:yellow_terracotta
fill 11 148 363 11 151 363 minecraft:honeycomb_block
setblock 15 148 363 minecraft:honey_block
setblock 23 148 364 minecraft:yellow_concrete
setblock 24 148 323 minecraft:honeycomb_block
setblock 25 148 323 minecraft:yellow_terracotta
fill 25 148 324 25 151 324 minecraft:honeycomb_block
fill 26 148 323 26 151 323 minecraft:honeycomb_block
fill 26 148 363 29 148 363 minecraft:honeycomb_block
setblock 27 148 325 minecraft:honeycomb_block
setblock 28 148 325 minecraft:yellow_terracotta
setblock 29 148 324 minecraft:yellow_terracotta
fill 29 148 325 29 150 325 minecraft:honeycomb_block
setblock 30 148 323 minecraft:yellow_terracotta
fill 30 148 324 30 151 324 minecraft:honeycomb_block
setblock 30 148 363 minecraft:yellow_terracotta
fill 31 148 323 31 151 323 minecraft:honeycomb_block
fill 31 148 363 31 151 363 minecraft:honeycomb_block
setblock 34 148 363 minecraft:honeycomb_block
setblock 34 148 364 minecraft:yellow_terracotta
setblock 35 148 323 minecraft:yellow_terracotta
fill 36 148 323 36 150 323 minecraft:honeycomb_block
setblock 37 148 322 minecraft:yellow_concrete
setblock 40 148 323 minecraft:yellow_terracotta
setblock 40 148 329 minecraft:honeycomb_block
setblock 40 148 332 minecraft:honeycomb_block
setblock 40 148 333 minecraft:yellow_terracotta
fill 40 148 348 40 149 350 minecraft:yellow_terracotta
fill 40 148 355 40 148 357 minecraft:honeycomb_block
setblock 40 148 363 minecraft:yellow_terracotta
fill 41 148 323 41 151 323 minecraft:honeycomb_block
setblock 41 148 327 minecraft:yellow_terracotta
fill 41 148 328 41 151 328 minecraft:honeycomb_block
setblock 41 148 332 minecraft:yellow_terracotta
fill 41 148 333 41 151 333 minecraft:honeycomb_block
setblock 41 148 336 minecraft:honeycomb_block
fill 41 148 348 41 149 349 minecraft:yellow_terracotta
fill 41 148 350 41 148 351 minecraft:honeycomb_block
setblock 41 148 352 minecraft:yellow_terracotta
fill 41 148 353 41 148 356 minecraft:honeycomb_block
setblock 41 148 357 minecraft:yellow_terracotta
fill 41 148 358 41 148 361 minecraft:honeycomb_block
setblock 41 148 362 minecraft:yellow_terracotta
fill 41 148 363 41 151 363 minecraft:honeycomb_block
setblock 42 148 336 minecraft:yellow_terracotta
setblock 0 149 352 minecraft:yellow_concrete
fill 0 149 353 0 179 353 minecraft:honeycomb_block
setblock 1 149 330 minecraft:honeycomb_block
setblock 1 149 331 minecraft:yellow_terracotta
fill 1 149 332 1 149 335 minecraft:honeycomb_block
setblock 1 149 336 minecraft:yellow_terracotta
fill 1 149 337 1 151 338 minecraft:honeycomb_block
setblock 1 149 339 minecraft:honey_block
fill 1 149 347 1 152 347 minecraft:honeycomb_block
setblock 1 149 350 minecraft:honeycomb_block
setblock 1 149 351 minecraft:yellow_terracotta
fill 1 149 352 1 152 352 minecraft:honeycomb_block
setblock 1 149 356 minecraft:yellow_terracotta
fill 1 149 357 1 152 357 minecraft:honeycomb_block
setblock 1 149 360 minecraft:honeycomb_block
setblock 1 149 361 minecraft:yellow_terracotta
fill 1 149 362 3 149 363 minecraft:honeycomb_block
fill 2 149 332 2 149 334 minecraft:honeycomb_block
setblock 2 149 335 minecraft:yellow_terracotta
fill 2 149 348 2 150 348 minecraft:honeycomb_block
setblock 2 149 350 minecraft:yellow_terracotta
fill 2 149 351 2 152 351 minecraft:honeycomb_block
setblock 2 149 354 minecraft:honeycomb_block
setblock 2 149 355 minecraft:yellow_terracotta
fill 2 149 356 2 152 356 minecraft:honeycomb_block
setblock 2 149 360 minecraft:yellow_terracotta
fill 2 149 361 5 149 361 minecraft:honeycomb_block
fill 3 149 349 3 152 349 minecraft:yellow_terracotta
fill 3 149 350 3 152 350 minecraft:honeycomb_block
setblock 3 149 354 minecraft:yellow_terracotta
fill 3 149 355 3 152 355 minecraft:honeycomb_block
setblock 3 149 359 minecraft:yellow_terracotta
fill 3 149 360 3 152 360 minecraft:honeycomb_block
setblock 4 149 323 minecraft:yellow_terracotta
setblock 4 149 353 minecraft:yellow_terracotta
fill 4 149 354 5 150 354 minecraft:honeycomb_block
setblock 4 149 357 minecraft:honeycomb_block
setblock 4 149 358 minecraft:yellow_terracotta
fill 4 149 359 4 152 359 minecraft:honeycomb_block
setblock 4 149 362 minecraft:honeycomb_block
setblock 4 149 363 minecraft:yellow_terracotta
fill 5 149 323 5 152 323 minecraft:honeycomb_block
setblock 5 149 353 minecraft:honeycomb_block
fill 5 149 355 5 149 356 minecraft:honeycomb_block
setblock 5 149 362 minecraft:yellow_terracotta
fill 5 149 363 5 152 363 minecraft:honeycomb_block
setblock 6 149 361 minecraft:yellow_terracotta
fill 6 149 362 6 152 362 minecraft:honeycomb_block
fill 7 149 361 7 152 361 minecraft:honeycomb_block
fill 9 149 361 9 150 361 minecraft:honeycomb_block
setblock 9 149 363 minecraft:yellow_terracotta
fill 10 149 322 10 155 322 minecraft:honeycomb_block
setblock 10 149 362 minecraft:yellow_terracotta
fill 10 149 363 10 152 363 minecraft:honeycomb_block
setblock 21 149 323 minecraft:honey_block
setblock 21 149 363 minecraft:honey_block
setblock 23 149 323 minecraft:honeycomb_block
fill 23 149 364 23 308 364 minecraft:honeycomb_block
setblock 24 149 323 minecraft:yellow_terracotta
fill 25 149 323 25 152 323 minecraft:honeycomb_block
fill 25 149 363 28 149 363 minecraft:honeycomb_block
setblock 27 149 325 minecraft:yellow_terracotta
setblock 28 149 324 minecraft:yellow_terracotta
fill 28 149 325 28 150 325 minecraft:honeycomb_block
fill 28 149 362 29 149 362 minecraft:honeycomb_block
setblock 29 149 323 minecraft:yellow_terracotta
fill 29 149 324 29 152 324 minecraft:honeycomb_block
setblock 29 149 363 minecraft:yellow_terracotta
fill 30 149 323 30 152 323 minecraft:honeycomb_block
setblock 30 149 362 minecraft:yellow_terracotta
fill 30 149 363 30 152 363 minecraft:honeycomb_block
setblock 33 149 324 minecraft:yellow_terracotta
setblock 34 149 323 minecraft:yellow_terracotta
setblock 34 149 363 minecraft:yellow_terracotta
fill 34 149 364 34 168 364 minecraft:honeycomb_block
fill 35 149 323 35 151 323 minecraft:honeycomb_block
fill 35 149 363 35 152 363 minecraft:honeycomb_block
setblock 36 149 364 minecraft:yellow_concrete
fill 37 149 322 37 226 322 minecraft:honeycomb_block
fill 37 149 364 37 158 364 minecraft:honeycomb_block
setblock 38 149 323 minecraft:honeycomb_block
fill 38 149 349 39 151 349 minecraft:yellow_terracotta
setblock 38 149 363 minecraft:honeycomb_block
setblock 39 149 323 minecraft:yellow_terracotta
fill 39 149 348 39 150 348 minecraft:yellow_terracotta
fill 39 149 350 39 150 350 minecraft:yellow_terracotta
setblock 39 149 363 minecraft:yellow_terracotta
fill 40 149 323 40 152 323 minecraft:honeycomb_block
setblock 40 149 332 minecraft:yellow_terracotta
fill 40 149 333 40 150 333 minecraft:honeycomb_block
fill 40 149 354 40 149 356 minecraft:honeycomb_block
setblock 40 149 357 minecraft:yellow_terracotta
fill 40 149 358 41 149 360 minecraft:honeycomb_block
fill 40 149 363 40 152 363 minecraft:honeycomb_block
setblock 41 149 326 minecraft:yellow_terracotta
fill 41 149 327 41 152 327 minecraft:honeycomb_block
setblock 41 149 331 minecraft:yellow_terracotta
fill 41 149 332 41 152 332 minecraft:honeycomb_block
setblock 41 149 336 minecraft:yellow_terracotta
fill 41 149 337 41 152 337 minecraft:honeycomb_block
setblock 41 149 347 minecraft:honey_block
setblock 41 149 350 minecraft:honeycomb_block
setblock 41 149 351 minecraft:yellow_terracotta
fill 41 149 352 41 149 355 minecraft:honeycomb_block
setblock 41 149 356 minecraft:yellow_terracotta
fill 41 149 357 41 152 357 minecraft:honeycomb_block
setblock 41 149 361 minecraft:yellow_terracotta
fill 41 149 362 41 152 362 minecraft:honeycomb_block
fill 42 149 336 42 187 336 minecraft:honeycomb_block
fill 0 150 352 0 189 352 minecraft:honeycomb_block
setblock 1 150 326 minecraft:honey_block
setblock 1 150 330 minecraft:yellow_terracotta
fill 1 150 331 1 150 334 minecraft:honeycomb_block
setblock 1 150 335 minecraft:yellow_terracotta
fill 1 150 336 2 152 336 minecraft:honeycomb_block
setblock 1 150 339 minecraft:honeycomb_block
setblock 1 150 340 minecraft:yellow_terracotta
setblock 1 150 345 minecraft:honey_block
fill 1 150 346 1 153 346 minecraft:honeycomb_block
setblock 1 150 349 minecraft:honeycomb_block
setblock 1 150 350 minecraft:yellow_terracotta
fill 1 150 351 1 153 351 minecraft:honeycomb_block
setblock 1 150 355 minecraft:yellow_terracotta
fill 1 150 356 1 153 356 minecraft:honeycomb_block
setblock 1 150 359 minecraft:honeycomb_block
setblock 1 150 360 minecraft:yellow_terracotta
fill 1 150 361 2 150 363 minecraft:honeycomb_block
fill 2 150 332 2 150 333 minecraft:honeycomb_block
setblock 2 150 334 minecraft:yellow_terracotta
fill 2 150 335 2 153 335 minecraft:honeycomb_block
fill 2 150 337 2 151 337 minecraft:honeycomb_block
setblock 2 150 349 minecraft:yellow_terracotta
fill 2 150 350 2 153 350 minecraft:honeycomb_block
setblock 2 150 354 minecraft:yellow_terracotta
fill 2 150 355 2 153 355 minecraft:honeycomb_block
setblock 2 150 358 minecraft:honeycomb_block
setblock 2 150 359 minecraft:yellow_terracotta
fill 2 150 360 2 153 360 minecraft:honeycomb_block
fill 3 150 348 3 151 348 minecraft:yellow_terracotta
setblock 3 150 352 minecraft:honeycomb_block
setblock 3 150 353 minecraft:yellow_terracotta
fill 3 150 354 3 153 354 minecraft:honeycomb_block
setblock 3 150 358 minecraft:yellow_terracotta
fill 3 150 359 3 153 359 minecraft:honeycomb_block
fill 3 150 361 3 150 362 minecraft:honeycomb_block
setblock 3 150 363 minecraft:yellow_terracotta
setblock 4 150 322 minecraft:yellow_concrete
fill 4 150 323 4 152 323 minecraft:honeycomb_block
fill 4 150 349 4 152 349 minecraft:yellow_terracotta
setblock 4 150 352 minecraft:yellow_terracotta
fill 4 150 353 4 152 353 minecraft:honeycomb_block
setblock 4 150 357 minecraft:yellow_terracotta
fill 4 150 358 4 153 358 minecraft:honeycomb_block
fill 4 150 360 4 150 361 minecraft:honeycomb_block
setblock 4 150 362 minecraft:yellow_terracotta
fill 4 150 363 4 153 363 minecraft:honeycomb_block
setblock 5 150 355 minecraft:honeycomb_block
setblock 5 150 356 minecraft:yellow_terracotta
fill 5 150 357 5 151 357 minecraft:honeycomb_block
setblock 5 150 360 minecraft:honeycomb_block
setblock 5 150 361 minecraft:yellow_terracotta
fill 5 150 362 5 153 362 minecraft:honeycomb_block
setblock 6 150 360 minecraft:yellow_terracotta
fill 6 150 361 6 153 361 minecraft:honeycomb_block
fill 7 150 360 7 151 360 minecraft:honeycomb_block
setblock 8 150 323 minecraft:yellow_terracotta
setblock 8 150 363 minecraft:yellow_terracotta
setblock 9 150 362 minecraft:yellow_terracotta
fill 9 150 363 9 153 363 minecraft:honeycomb_block
fill 10 150 362 10 151 362 minecraft:honeycomb_block
setblock 15 150 323 minecraft:honey_block
setblock 16 150 364 minecraft:yellow_terracotta
setblock 23 150 323 minecraft:yellow_terracotta
fill 24 150 323 24 152 324 minecraft:honeycomb_block
fill 24 150 363 27 150 363 minecraft:honeycomb_block
fill 26 150 362 28 150 362 minecraft:honeycomb_block
setblock 26 150 364 minecraft:yellow_concrete
setblock 27 150 324 minecraft:yellow_terracotta
setblock 27 150 325 minecraft:honeycomb_block
setblock 28 150 323 minecraft:yellow_terracotta
fill 28 150 324 28 153 324 minecraft:honeycomb_block
setblock 28 150 363 minecraft:yellow_terracotta
fill 29 150 323 29 153 323 minecraft:honeycomb_block
setblock 29 150 362 minecraft:yellow_terracotta
fill 29 150 363 29 153 363 minecraft:honeycomb_block
fill 30 150 362 30 153 362 minecraft:honeycomb_block
setblock 32 150 324 minecraft:yellow_terracotta
setblock 32 150 363 minecraft:honeycomb_block
setblock 33 150 323 minecraft:yellow_terracotta
setblock 33 150 363 minecraft:yellow_terracotta
fill 34 150 323 34 152 323 minecraft:honeycomb_block
fill 34 150 363 34 153 363 minecraft:honeycomb_block
fill 36 150 363 36 151 364 minecraft:honeycomb_block
fill 37 150 349 37 152 349 minecraft:yellow_terracotta
setblock 37 150 363 minecraft:honeycomb_block
setblock 38 150 323 minecraft:yellow_terracotta
fill 38 150 348 38 151 348 minecraft:yellow_terracotta
fill 38 150 350 38 151 350 minecraft:yellow_terracotta
setblock 38 150 363 minecraft:yellow_terracotta
fill 39 150 323 39 153 323 minecraft:honeycomb_block
fill 39 150 363 39 153 363 minecraft:honeycomb_block
setblock 40 150 331 minecraft:yellow_terracotta
setblock 40 150 332 minecraft:honeycomb_block
fill 40 150 334 41 150 334 minecraft:honeycomb_block
setblock 40 150 349 minecraft:yellow_terracotta
fill 40 150 353 40 150 355 minecraft:honeycomb_block
setblock 40 150 356 minecraft:yellow_terracotta
fill 40 150 357 40 150 360 minecraft:honeycomb_block
setblock 40 150 361 minecraft:yellow_terracotta
fill 40 150 362 40 153 362 minecraft:honeycomb_block
setblock 41 150 325 minecraft:yellow_terracotta
fill 41 150 326 41 152 326 minecraft:honeycomb_block
setblock 41 150 330 minecraft:yellow_terracotta
fill 41 150 331 41 153 331 minecraft:honeycomb_block
setblock 41 150 335 minecraft:yellow_terracotta
fill 41 150 336 41 153 336 minecraft:honeycomb_block
fill 41 150 338 41 151 338 minecraft:honeycomb_block
setblock 41 150 341 minecraft:honey_block
setblock 41 150 349 minecraft:honey_block
setblock 41 150 350 minecraft:yellow_terracotta
fill 41 150 351 41 150 354 minecraft:honeycomb_block
setblock 41 150 355 minecraft:yellow_terracotta
fill 41 150 356 41 153 356 minecraft:honeycomb_block
fill 41 150 358 41 150 359 minecraft:honeycomb_block
setblock 41 150 360 minecraft:yellow_terracotta
fill 41 150 361 41 153 361 minecraft:honeycomb_block
setblock 42 150 354 minecraft:orange_terracotta
setblock 0 151 333 minecraft:yellow_terracotta
fill 1 151 330 1 151 333 minecraft:honeycomb_block
setblock 1 151 334 minecraft:yellow_terracotta
fill 1 151 335 1 154 335 minecraft:honeycomb_block
setblock 1 151 339 minecraft:yellow_terracotta
fill 1 151 340 1 151 343 minecraft:honeycomb_block
fill 1 151 345 1 154 345 minecraft:honeycomb_block
setblock 1 151 349 minecraft:yellow_terracotta
fill 1 151 350 1 154 350 minecraft:honeycomb_block
setblock 1 151 354 minecraft:yellow_terracotta
fill 1 151 355 1 154 355 minecraft:honeycomb_block
setblock 1 151 359 minecraft:yellow_terracotta
fill 1 151 360 1 151 363 minecraft:honeycomb_block
setblock 2 151 332 minecraft:honeycomb_block
setblock 2 151 333 minecraft:yellow_terracotta
fill 2 151 334 2 154 334 minecraft:honeycomb_block
setblock 2 151 338 minecraft:yellow_terracotta
fill 2 151 339 2 154 339 minecraft:honeycomb_block
setblock 2 151 348 minecraft:yellow_terracotta
fill 2 151 349 2 154 349 minecraft:honeycomb_block
setblock 2 151 353 minecraft:yellow_terracotta
fill 2 151 354 2 154 354 minecraft:honeycomb_block
setblock 2 151 358 minecraft:yellow_terracotta
fill 2 151 359 2 154 359 minecraft:honeycomb_block
fill 2 151 361 2 151 362 minecraft:honeycomb_block
setblock 2 151 363 minecraft:yellow_terracotta
setblock 3 151 325 minecraft:light[level=15]
setblock 3 151 333 minecraft:light[level=15]
setblock 3 151 341 minecraft:light[level=15]
setblock 3 151 351 minecraft:honeycomb_block
setblock 3 151 352 minecraft:yellow_terracotta
fill 3 151 353 3 154 353 minecraft:honeycomb_block
setblock 3 151 357 minecraft:yellow_terracotta
fill 3 151 358 3 154 358 minecraft:honeycomb_block
setblock 3 151 361 minecraft:honeycomb_block
setblock 3 151 362 minecraft:yellow_terracotta
fill 3 151 363 3 154 363 minecraft:honeycomb_block
fill 4 151 322 4 272 322 minecraft:honeycomb_block
fill 4 151 348 5 152 348 minecraft:yellow_terracotta
fill 4 151 350 5 152 350 minecraft:yellow_terracotta
fill 4 151 352 4 152 352 minecraft:honeycomb_block
fill 4 151 354 4 152 354 minecraft:honeycomb_block
setblock 4 151 356 minecraft:yellow_terracotta
fill 4 151 357 4 154 357 minecraft:honeycomb_block
setblock 4 151 360 minecraft:honeycomb_block
setblock 4 151 361 minecraft:yellow_terracotta
fill 4 151 362 4 154 362 minecraft:honeycomb_block
fill 5 151 349 5 153 349 minecraft:yellow_terracotta
setblock 5 151 355 minecraft:yellow_terracotta
setblock 5 151 356 minecraft:honeycomb_block
setblock 5 151 360 minecraft:yellow_terracotta
fill 5 151 361 5 154 361 minecraft:honeycomb_block
fill 6 151 360 6 152 360 minecraft:honeycomb_block
setblock 7 151 323 minecraft:yellow_terracotta
setblock 7 151 363 minecraft:yellow_terracotta
setblock 8 151 362 minecraft:yellow_terracotta
fill 8 151 363 8 154 363 minecraft:honeycomb_block
setblock 9 151 323 minecraft:honey_block
fill 9 151 362 9 152 362 minecraft:honeycomb_block
setblock 11 151 325 minecraft:light[level=15]
setblock 11 151 333 minecraft:light[level=15]
setblock 11 151 341 minecraft:light[level=15]
setblock 11 151 349 minecraft:light[level=15]
setblock 11 151 357 minecraft:light[level=15]
setblock 14 151 363 minecraft:honey_block
fill 16 151 364 16 237 364 minecraft:honeycomb_block
setblock 19 151 325 minecraft:light[level=15]
setblock 19 151 333 minecraft:light[level=15]
setblock 19 151 341 minecraft:light[level=15]
setblock 19 151 349 minecraft:light[level=15]
setblock 19 151 357 minecraft:light[level=15]
setblock 22 151 323 minecraft:yellow_terracotta
fill 23 151 323 23 154 323 minecraft:honeycomb_block
fill 23 151 363 26 151 363 minecraft:honeycomb_block
fill 25 151 362 27 151 362 minecraft:honeycomb_block
setblock 26 151 324 minecraft:yellow_terracotta
fill 26 151 364 26 165 364 minecraft:honeycomb_block
setblock 27 151 323 minecraft:yellow_terracotta
fill 27 151 324 27 154 324 minecraft:honeycomb_block
setblock 27 151 325 minecraft:light[level=15]
setblock 27 151 333 minecraft:light[level=15]
setblock 27 151 341 minecraft:light[level=15]
setblock 27 151 349 minecraft:light[level=15]
setblock 27 151 357 minecraft:light[level=15]
setblock 27 151 363 minecraft:yellow_terracotta
fill 28 151 323 28 154 323 minecraft:honeycomb_block
setblock 28 151 362 minecraft:yellow_terracotta
fill 28 151 363 28 154 363 minecraft:honeycomb_block
fill 29 151 337 30 152 338 minecraft:yellow_concrete
fill 29 151 362 29 154 362 minecraft:honeycomb_block
setblock 31 151 324 minecraft:yellow_terracotta
fill 31 151 362 31 152 362 minecraft:honeycomb_block
setblock 32 151 323 minecraft:yellow_terracotta
setblock 32 151 363 minecraft:yellow_terracotta
fill 33 151 323 33 153 323 minecraft:honeycomb_block
fill 33 151 363 33 154 363 minecraft:honeycomb_block
setblock 35 151 325 minecraft:light[level=15]
setblock 35 151 333 minecraft:light[level=15]
setblock 35 151 341 minecraft:light[level=15]
setblock 35 151 349 minecraft:light[level=15]
setblock 35 151 357 minecraft:light[level=15]
fill 36 151 348 36 152 350 minecraft:yellow_terracotta
fill 37 151 348 37 152 348 minecraft:yellow_terracotta
fill 37 151 350 37 152 350 minecraft:yellow_terracotta
setblock 37 151 363 minecraft:yellow_terracotta
fill 38 151 363 38 154 363 minecraft:honeycomb_block
fill 39 151 362 39 154 362 minecraft:honeycomb_block
setblock 40 151 349 minecraft:honey_block
fill 40 151 353 40 151 354 minecraft:honeycomb_block
setblock 40 151 355 minecraft:yellow_terracotta
fill 40 151 356 40 151 359 minecraft:honeycomb_block
setblock 40 151 360 minecraft:yellow_terracotta
fill 40 151 361 40 154 361 minecraft:honeycomb_block
setblock 41 151 324 minecraft:yellow_terracotta
fill 41 151 325 41 153 325 minecraft:honeycomb_block
setblock 41 151 329 minecraft:yellow_terracotta
fill 41 151 330 41 153 330 minecraft:honeycomb_block
setblock 41 151 334 minecraft:yellow_terracotta
fill 41 151 335 41 154 335 minecraft:honeycomb_block
setblock 41 151 339 minecraft:yellow_terracotta
fill 41 151 350 41 151 353 minecraft:honeycomb_block
setblock 41 151 354 minecraft:yellow_terracotta
fill 41 151 355 41 154 355 minecraft:honeycomb_block
setblock 41 151 358 minecraft:honeycomb_block
setblock 41 151 359 minecraft:yellow_terracotta
fill 41 151 360 41 154 360 minecraft:honeycomb_block
setblock 42 151 354 minecraft:honeycomb_block
setblock 42 151 358 minecraft:orange_terracotta
fill 42 151 359 42 277 359 minecraft:honeycomb_block
fill 0 152 333 0 159 333 minecraft:honeycomb_block
fill 1 152 331 1 152 332 minecraft:honeycomb_block
setblock 1 152 333 minecraft:yellow_terracotta
fill 1 152 334 1 155 334 minecraft:honeycomb_block
setblock 1 152 337 minecraft:honeycomb_block
setblock 1 152 338 minecraft:yellow_terracotta
fill 1 152 339 1 152 342 minecraft:honeycomb_block
setblock 1 152 343 minecraft:yellow_terracotta
fill 1 152 344 1 155 344 minecraft:honeycomb_block
setblock 1 152 348 minecraft:yellow_terracotta
fill 1 152 349 1 155 349 minecraft:honeycomb_block
setblock 1 152 353 minecraft:yellow_terracotta
fill 1 152 354 1 155 354 minecraft:honeycomb_block
setblock 1 152 358 minecraft:yellow_terracotta
fill 1 152 359 1 152 362 minecraft:honeycomb_block
setblock 1 152 363 minecraft:yellow_terracotta
setblock 2 152 333 minecraft:honeycomb_block
setblock 2 152 337 minecraft:yellow_terracotta
fill 2 152 338 2 155 338 minecraft:honeycomb_block
fill 2 152 340 2 152 341 minecraft:honeycomb_block
fill 2 152 348 2 153 348 minecraft:honeycomb_block
setblock 2 152 352 minecraft:yellow_terracotta
fill 2 152 353 2 155 353 minecraft:honeycomb_block
setblock 2 152 357 minecraft:yellow_terracotta
fill 2 152 358 2 155 358 minecraft:honeycomb_block
setblock 2 152 361 minecraft:honeycomb_block
setblock 2 152 362 minecraft:yellow_terracotta
fill 2 152 363 2 155 363 minecraft:honeycomb_block
setblock 3 152 323 minecraft:honey_block
fill 3 152 337 3 154 337 minecraft:honeycomb_block
setblock 3 152 351 minecraft:yellow_terracotta
fill 3 152 352 3 154 352 minecraft:honeycomb_block
setblock 3 152 356 minecraft:yellow_terracotta
fill 3 152 357 3 155 357 minecraft:honeycomb_block
setblock 3 152 361 minecraft:yellow_terracotta
fill 3 152 362 3 155 362 minecraft:honeycomb_block
setblock 4 152 355 minecraft:yellow_terracotta
fill 4 152 356 4 154 356 minecraft:honeycomb_block
setblock 4 152 360 minecraft:yellow_terracotta
fill 4 152 361 4 155 361 minecraft:honeycomb_block
fill 5 152 360 5 153 360 minecraft:honeycomb_block
fill 6 152 348 6 153 350 minecraft:yellow_terracotta
setblock 6 152 363 minecraft:yellow_terracotta
fill 7 152 349 7 154 349 minecraft:yellow_terracotta
setblock 7 152 362 minecraft:yellow_terracotta
fill 7 152 363 7 155 363 minecraft:honeycomb_block
setblock 8 152 361 minecraft:yellow_terracotta
fill 8 152 362 8 154 362 minecraft:honeycomb_block
setblock 19 152 364 minecraft:orange_terracotta
setblock 20 152 363 minecraft:honey_block
fill 22 152 323 22 155 323 minecraft:honeycomb_block
fill 22 152 363 25 152 363 minecraft:honeycomb_block
fill 24 152 362 26 152 362 minecraft:honeycomb_block
setblock 25 152 324 minecraft:yellow_terracotta
setblock 26 152 323 minecraft:yellow_terracotta
fill 26 152 324 26 155 324 minecraft:honeycomb_block
setblock 26 152 363 minecraft:yellow_terracotta
fill 27 152 323 27 155 323 minecraft:honeycomb_block
setblock 27 152 362 minecraft:yellow_terracotta
fill 27 152 363 27 155 363 minecraft:honeycomb_block
fill 28 152 362 28 155 362 minecraft:honeycomb_block
setblock 30 152 324 minecraft:yellow_terracotta
setblock 31 152 323 minecraft:yellow_terracotta
setblock 31 152 363 minecraft:yellow_terracotta
fill 32 152 323 32 154 323 minecraft:honeycomb_block
fill 32 152 363 32 155 363 minecraft:honeycomb_block
fill 34 152 349 35 154 349 minecraft:yellow_terracotta
fill 35 152 348 35 153 348 minecraft:yellow_terracotta
fill 35 152 350 35 153 350 minecraft:yellow_terracotta
setblock 36 152 363 minecraft:yellow_terracotta
fill 36 152 364 36 209 364 minecraft:honeycomb_block
fill 37 152 363 37 155 363 minecraft:honeycomb_block
setblock 38 152 349 minecraft:yellow_terracotta
fill 38 152 362 38 155 362 minecraft:honeycomb_block
setblock 39 152 349 minecraft:honey_block
setblock 40 152 354 minecraft:yellow_terracotta
fill 40 152 355 40 152 358 minecraft:honeycomb_block
setblock 40 152 359 minecraft:yellow_terracotta
fill 40 152 360 40 155 360 minecraft:honeycomb_block
setblock 41 152 323 minecraft:yellow_terracotta
fill 41 152 324 41 155 324 minecraft:honeycomb_block
setblock 41 152 328 minecraft:yellow_terracotta
setblock 41 152 329 minecraft:honeycomb_block
setblock 41 152 333 minecraft:yellow_terracotta
fill 41 152 334 41 155 334 minecraft:honeycomb_block
setblock 41 152 338 minecraft:yellow_terracotta
fill 41 152 339 41 154 340 minecraft:honeycomb_block
setblock 41 152 348 minecraft:honey_block
fill 41 152 350 41 152 352 minecraft:honeycomb_block
setblock 41 152 353 minecraft:yellow_terracotta
fill 41 152 354 41 155 354 minecraft:honeycomb_block
setblock 41 152 358 minecraft:yellow_terracotta
fill 41 152 359 41 155 359 minecraft:honeycomb_block
setblock 41 152 363 minecraft:yellow_terracotta
setblock 42 152 354 minecraft:yellow_terracotta
fill 42 152 358 42 225 358 minecraft:honeycomb_block
setblock 1 153 332 minecraft:yellow_terracotta
fill 1 153 333 1 155 333 minecraft:honeycomb_block
setblock 1 153 336 minecraft:honeycomb_block
setblock 1 153 337 minecraft:yellow_terracotta
fill 1 153 338 1 153 341 minecraft:honeycomb_block
setblock 1 153 342 minecraft:yellow_terracotta
fill 1 153 343 2 155 343 minecraft:honeycomb_block
setblock 1 153 347 minecraft:yellow_terracotta
fill 1 153 348 1 156 348 minecraft:honeycomb_block
setblock 1 153 352 minecraft:yellow_terracotta
fill 1 153 353 1 156 353 minecraft:honeycomb_block
setblock 1 153 357 minecraft:yellow_terracotta
fill 1 153 358 1 153 361 minecraft:honeycomb_block
setblock 1 153 362 minecraft:yellow_terracotta
fill 1 153 363 1 156 363 minecraft:honeycomb_block
setblock 2 153 336 minecraft:yellow_terracotta
fill 2 153 337 2 156 337 minecraft:honeycomb_block
setblock 2 153 340 minecraft:honeycomb_block
setblock 2 153 341 minecraft:yellow_terracotta
fill 2 153 342 2 156 342 minecraft:honeycomb_block
setblock 2 153 351 minecraft:yellow_terracotta
fill 2 153 352 2 156 352 minecraft:honeycomb_block
setblock 2 153 356 minecraft:yellow_terracotta
fill 2 153 357 2 156 357 minecraft:honeycomb_block
setblock 2 153 361 minecraft:yellow_terracotta
fill 2 153 362 2 156 362 minecraft:honeycomb_block
setblock 3 153 325 minecraft:light[level=12]
setblock 3 153 332 minecraft:light[level=12]
fill 3 153 338 3 153 339 minecraft:honeycomb_block
setblock 3 153 346 minecraft:light[level=12]
setblock 3 153 351 minecraft:honeycomb_block
setblock 3 153 355 minecraft:yellow_terracotta
fill 3 153 356 3 156 356 minecraft:honeycomb_block
setblock 3 153 360 minecraft:yellow_terracotta
fill 3 153 361 3 156 361 minecraft:honeycomb_block
setblock 4 153 349 minecraft:honey_block
setblock 4 153 354 minecraft:yellow_terracotta
fill 4 153 355 4 154 355 minecraft:honeycomb_block
setblock 4 153 359 minecraft:yellow_terracotta
setblock 4 153 360 minecraft:honeycomb_block
setblock 5 153 363 minecraft:yellow_terracotta
setblock 6 153 362 minecraft:yellow_terracotta
fill 6 153 363 6 156 363 minecraft:honeycomb_block
fill 7 153 348 7 154 348 minecraft:yellow_terracotta
fill 7 153 350 7 154 350 minecraft:yellow_terracotta
setblock 7 153 361 minecraft:yellow_terracotta
fill 7 153 362 7 156 362 minecraft:honeycomb_block
fill 8 153 349 8 155 349 minecraft:yellow_terracotta
setblock 10 153 325 minecraft:light[level=12]
setblock 10 153 332 minecraft:light[level=12]
setblock 10 153 339 minecraft:light[level=12]
setblock 10 153 346 minecraft:light[level=12]
setblock 10 153 353 minecraft:light[level=12]
setblock 10 153 360 minecraft:light[level=12]
setblock 10 153 363 minecraft:yellow_terracotta
setblock 16 153 323 minecraft:honey_block
setblock 17 153 325 minecraft:light[level=12]
setblock 17 153 332 minecraft:light[level=12]
setblock 17 153 339 minecraft:light[level=12]
setblock 17 153 346 minecraft:light[level=12]
setblock 17 153 353 minecraft:light[level=12]
setblock 17 153 360 minecraft:light[level=12]
fill 19 153 364 19 195 364 minecraft:honeycomb_block
fill 21 153 323 21 156 323 minecraft:honeycomb_block
fill 21 153 363 24 153 363 minecraft:honeycomb_block
setblock 24 153 323 minecraft:honeycomb_block
setblock 24 153 324 minecraft:yellow_terracotta
setblock 24 153 325 minecraft:light[level=12]
setblock 24 153 332 minecraft:light[level=12]
setblock 24 153 339 minecraft:light[level=12]
setblock 24 153 346 minecraft:light[level=12]
setblock 24 153 353 minecraft:light[level=12]
setblock 24 153 360 minecraft:light[level=12]
fill 24 153 362 25 153 362 minecraft:honeycomb_block
setblock 25 153 323 minecraft:yellow_terracotta
fill 25 153 324 25 156 324 minecraft:honeycomb_block
setblock 25 153 363 minecraft:yellow_terracotta
fill 26 153 323 26 156 323 minecraft:honeycomb_block
setblock 26 153 362 minecraft:yellow_terracotta
fill 26 153 363 26 156 363 minecraft:honeycomb_block
fill 27 153 362 27 156 362 minecraft:honeycomb_block
setblock 29 153 324 minecraft:yellow_terracotta
setblock 30 153 323 minecraft:yellow_terracotta
setblock 30 153 363 minecraft:yellow_terracotta
fill 31 153 323 31 156 323 minecraft:honeycomb_block
setblock 31 153 325 minecraft:light[level=12]
setblock 31 153 332 minecraft:light[level=12]
setblock 31 153 339 minecraft:light[level=12]
setblock 31 153 346 minecraft:light[level=12]
setblock 31 153 353 minecraft:light[level=12]
setblock 31 153 360 minecraft:light[level=12]
fill 31 153 363 31 156 363 minecraft:honeycomb_block
fill 33 153 349 33 155 349 minecraft:yellow_terracotta
fill 34 153 348 34 154 348 minecraft:yellow_terracotta
fill 34 153 350 34 154 350 minecraft:yellow_terracotta
setblock 35 153 363 minecraft:yellow_terracotta
setblock 36 153 349 minecraft:yellow_terracotta
fill 36 153 363 36 156 363 minecraft:honeycomb_block
setblock 37 153 349 minecraft:honey_block
setblock 38 153 325 minecraft:light[level=12]
setblock 38 153 332 minecraft:light[level=12]
setblock 38 153 339 minecraft:light[level=12]
setblock 38 153 346 minecraft:light[level=12]
fill 38 153 349 38 162 349 minecraft:iron_block
setblock 38 153 353 minecraft:light[level=12]
setblock 38 153 360 minecraft:light[level=12]
setblock 40 153 323 minecraft:yellow_terracotta
fill 40 153 354 40 153 357 minecraft:honeycomb_block
setblock 40 153 358 minecraft:yellow_terracotta
fill 40 153 359 40 156 359 minecraft:honeycomb_block
setblock 40 153 363 minecraft:yellow_terracotta
fill 41 153 323 41 156 323 minecraft:honeycomb_block
setblock 41 153 332 minecraft:yellow_terracotta
fill 41 153 333 41 155 333 minecraft:honeycomb_block
setblock 41 153 337 minecraft:yellow_terracotta
fill 41 153 338 41 156 338 minecraft:honeycomb_block
setblock 41 153 342 minecraft:honey_block
setblock 41 153 351 minecraft:honeycomb_block
setblock 41 153 352 minecraft:yellow_terracotta
fill 41 153 353 41 156 353 minecraft:honeycomb_block
setblock 41 153 357 minecraft:yellow_terracotta
fill 41 153 358 41 156 358 minecraft:honeycomb_block
setblock 41 153 362 minecraft:yellow_terracotta
fill 41 153 363 41 156 363 minecraft:honeycomb_block
fill 42 153 354 42 177 354 minecraft:honeycomb_block
setblock 1 154 325 minecraft:honey_block
setblock 1 154 332 minecraft:honeycomb_block
setblock 1 154 336 minecraft:yellow_terracotta
fill 1 154 337 1 154 340 minecraft:honeycomb_block
setblock 1 154 341 minecraft:yellow_terracotta
fill 1 154 342 1 157 342 minecraft:honeycomb_block
setblock 1 154 346 minecraft:yellow_terracotta
fill 1 154 347 1 157 347 minecraft:honeycomb_block
setblock 1 154 351 minecraft:yellow_terracotta
fill 1 154 352 1 157 352 minecraft:honeycomb_block
setblock 1 154 356 minecraft:yellow_terracotta
fill 1 154 357 1 154 360 minecraft:honeycomb_block
setblock 1 154 361 minecraft:yellow_terracotta
fill 1 154 362 1 157 362 minecraft:honeycomb_block
setblock 2 154 335 minecraft:yellow_terracotta
fill 2 154 336 2 157 336 minecraft:honeycomb_block
setblock 2 154 340 minecraft:yellow_terracotta
fill 2 154 341 2 157 341 minecraft:honeycomb_block
setblock 2 154 344 minecraft:honeycomb_block
setblock 2 154 350 minecraft:yellow_terracotta
fill 2 154 351 2 157 351 minecraft:honeycomb_block
setblock 2 154 355 minecraft:yellow_terracotta
fill 2 154 356 2 157 356 minecraft:honeycomb_block
setblock 2 154 360 minecraft:yellow_terracotta
fill 2 154 361 2 157 361 minecraft:honeycomb_block
setblock 3 154 338 minecraft:honeycomb_block
setblock 3 154 339 minecraft:yellow_terracotta
fill 3 154 340 3 157 340 minecraft:honeycomb_block
setblock 3 154 354 minecraft:yellow_terracotta
fill 3 154 355 3 156 355 minecraft:honeycomb_block
setblock 3 154 359 minecraft:yellow_terracotta
fill 3 154 360 3 157 360 minecraft:honeycomb_block
setblock 4 154 358 minecraft:yellow_terracotta
setblock 4 154 359 minecraft:honeycomb_block
setblock 4 154 363 minecraft:yellow_terracotta
setblock 5 154 349 minecraft:honey_block
setblock 5 154 362 minecraft:yellow_terracotta
fill 5 154 363 5 157 363 minecraft:honeycomb_block
setblock 6 154 349 minecraft:yellow_terracotta
setblock 6 154 361 minecraft:yellow_terracotta
fill 6 154 362 6 157 362 minecraft:honeycomb_block
fill 8 154 348 9 154 348 minecraft:yellow_terracotta
fill 8 154 350 9 154 350 minecraft:yellow_terracotta
fill 9 154 349 10 156 349 minecraft:yellow_terracotta
setblock 9 154 363 minecraft:yellow_terracotta
setblock 10 154 323 minecraft:honey_block
fill 12 154 348 13 154 349 minecraft:honey_block
fill 21 154 363 23 154 363 minecraft:honeycomb_block
fill 23 154 362 24 154 362 minecraft:honeycomb_block
setblock 24 154 323 minecraft:yellow_terracotta
fill 24 154 324 24 157 324 minecraft:honeycomb_block
setblock 24 154 363 minecraft:yellow_terracotta
fill 25 154 323 25 157 323 minecraft:honeycomb_block
setblock 25 154 362 minecraft:yellow_terracotta
fill 25 154 363 25 157 363 minecraft:honeycomb_block
fill 26 154 336 27 155 336 minecraft:yellow_concrete
fill 26 154 362 26 157 362 minecraft:honeycomb_block
setblock 28 154 324 minecraft:yellow_terracotta
setblock 29 154 323 minecraft:yellow_terracotta
setblock 29 154 363 minecraft:yellow_terracotta
fill 30 154 323 30 157 323 minecraft:honeycomb_block
fill 30 154 363 30 157 363 minecraft:honeycomb_block
fill 31 154 349 32 156 349 minecraft:yellow_terracotta
fill 32 154 348 33 154 348 minecraft:yellow_terracotta
fill 32 154 350 33 154 350 minecraft:yellow_terracotta
setblock 34 154 363 minecraft:yellow_terracotta
setblock 35 154 323 minecraft:honey_block
fill 35 154 363 35 157 363 minecraft:honeycomb_block
setblock 36 154 349 minecraft:honey_block
fill 37 154 360 37 163 360 minecraft:iron_block
fill 37 154 362 37 156 362 minecraft:honeycomb_block
setblock 39 154 323 minecraft:yellow_terracotta
fill 39 154 360 39 156 360 minecraft:honeycomb_block
setblock 39 154 363 minecraft:yellow_terracotta
fill 40 154 323 40 157 323 minecraft:honeycomb_block
fill 40 154 354 40 154 356 minecraft:honeycomb_block
setblock 40 154 357 minecraft:yellow_terracotta
fill 40 154 358 40 157 358 minecraft:honeycomb_block
setblock 40 154 362 minecraft:yellow_terracotta
fill 40 154 363 40 157 363 minecraft:honeycomb_block
setblock 41 154 332 minecraft:honeycomb_block
setblock 41 154 336 minecraft:yellow_terracotta
fill 41 154 337 41 157 337 minecraft:honeycomb_block
setblock 41 154 341 minecraft:yellow_terracotta
setblock 41 154 351 minecraft:yellow_terracotta
fill 41 154 352 41 157 352 minecraft:honeycomb_block
setblock 41 154 356 minecraft:yellow_terracotta
fill 41 154 357 41 157 357 minecraft:honeycomb_block
setblock 41 154 361 minecraft:yellow_terracotta
fill 41 154 362 41 157 362 minecraft:honeycomb_block
setblock 42 154 324 minecraft:yellow_terracotta
setblock 42 154 353 minecraft:orange_terracotta
setblock 0 155 348 minecraft:yellow_terracotta
setblock 1 155 331 minecraft:honey_block
setblock 1 155 335 minecraft:yellow_terracotta
fill 1 155 336 1 155 339 minecraft:honeycomb_block
setblock 1 155 340 minecraft:yellow_terracotta
fill 1 155 341 1 158 341 minecraft:honeycomb_block
setblock 1 155 345 minecraft:yellow_terracotta
fill 1 155 346 2 157 346 minecraft:honeycomb_block
setblock 1 155 350 minecraft:yellow_terracotta
fill 1 155 351 1 158 351 minecraft:honeycomb_block
setblock 1 155 355 minecraft:yellow_terracotta
fill 1 155 356 1 155 359 minecraft:honeycomb_block
setblock 1 155 360 minecraft:yellow_terracotta
fill 1 155 361 1 158 361 minecraft:honeycomb_block
fill 2 155 335 2 156 335 minecraft:honeycomb_block
setblock 2 155 339 minecraft:yellow_terracotta
fill 2 155 340 2 158 340 minecraft:honeycomb_block
setblock 2 155 344 minecraft:yellow_terracotta
fill 2 155 345 2 158 345 minecraft:honeycomb_block
setblock 2 155 349 minecraft:yellow_terracotta
fill 2 155 350 2 158 350 minecraft:honeycomb_block
setblock 2 155 354 minecraft:yellow_terracotta
fill 2 155 355 2 158 355 minecraft:honeycomb_block
setblock 2 155 359 minecraft:yellow_terracotta
fill 2 155 360 2 158 360 minecraft:honeycomb_block
setblock 3 155 338 minecraft:yellow_terracotta
fill 3 155 339 3 158 339 minecraft:honeycomb_block
fill 3 155 341 3 156 341 minecraft:honeycomb_block
setblock 3 155 353 minecraft:yellow_terracotta
setblock 3 155 354 minecraft:honeycomb_block
setblock 3 155 358 minecraft:yellow_terracotta
fill 3 155 359 3 158 359 minecraft:honeycomb_block
setblock 3 155 363 minecraft:yellow_terracotta
setblock 4 155 323 minecraft:honey_block
setblock 4 155 362 minecraft:yellow_terracotta
fill 4 155 363 4 158 363 minecraft:honeycomb_block
setblock 5 155 361 minecraft:yellow_terracotta
fill 5 155 362 5 158 362 minecraft:honeycomb_block
setblock 6 155 361 minecraft:honeycomb_block
setblock 7 155 349 minecraft:honey_block
setblock 8 155 363 minecraft:yellow_terracotta
fill 9 155 348 11 155 348 minecraft:yellow_terracotta
fill 9 155 350 11 155 350 minecraft:yellow_terracotta
setblock 9 155 363 minecraft:honeycomb_block
fill 11 155 349 12 157 349 minecraft:yellow_terracotta
fill 12 155 348 13 155 348 minecraft:honey_block
setblock 13 155 349 minecraft:honey_block
setblock 13 155 363 minecraft:honey_block
fill 20 155 323 20 157 323 minecraft:honeycomb_block
fill 20 155 363 22 155 363 minecraft:honeycomb_block
setblock 23 155 323 minecraft:yellow_terracotta
fill 23 155 324 23 158 324 minecraft:honeycomb_block
setblock 23 155 362 minecraft:honeycomb_block
setblock 23 155 363 minecraft:yellow_terracotta
fill 24 155 323 24 158 323 minecraft:honeycomb_block
setblock 24 155 362 minecraft:yellow_terracotta
fill 24 155 363 24 158 363 minecraft:honeycomb_block
fill 25 155 362 25 158 362 minecraft:honeycomb_block
setblock 25 155 364 minecraft:yellow_concrete
setblock 27 155 324 minecraft:yellow_terracotta
setblock 28 155 323 minecraft:yellow_terracotta
setblock 28 155 363 minecraft:yellow_terracotta
fill 29 155 323 29 158 323 minecraft:honeycomb_block
fill 29 155 349 30 157 349 minecraft:yellow_terracotta
setblock 29 155 362 minecraft:yellow_terracotta
fill 29 155 363 29 158 363 minecraft:honeycomb_block
fill 30 155 348 32 155 348 minecraft:yellow_terracotta
fill 30 155 350 32 155 350 minecraft:yellow_terracotta
setblock 33 155 363 minecraft:yellow_terracotta
setblock 34 155 349 minecraft:honey_block
fill 34 155 363 34 158 363 minecraft:honeycomb_block
setblock 38 155 323 minecraft:yellow_terracotta
setblock 38 155 363 minecraft:yellow_terracotta
fill 39 155 323 39 158 323 minecraft:honeycomb_block
fill 39 155 359 39 157 359 minecraft:honeycomb_block
setblock 39 155 361 minecraft:honeycomb_block
setblock 39 155 362 minecraft:yellow_terracotta
fill 39 155 363 39 158 363 minecraft:honeycomb_block
setblock 40 155 355 minecraft:honeycomb_block
setblock 40 155 356 minecraft:yellow_terracotta
fill 40 155 357 40 158 357 minecraft:honeycomb_block
setblock 40 155 361 minecraft:yellow_terracotta
fill 40 155 362 40 158 362 minecraft:honeycomb_block
setblock 41 155 330 minecraft:honey_block
setblock 41 155 335 minecraft:yellow_terracotta
fill 41 155 336 41 158 336 minecraft:honeycomb_block
setblock 41 155 339 minecraft:honeycomb_block
setblock 41 155 340 minecraft:yellow_terracotta
fill 41 155 341 41 157 342 minecraft:honeycomb_block
fill 41 155 349 41 156 349 minecraft:honey_block
fill 41 155 351 41 158 351 minecraft:honeycomb_block
setblock 41 155 355 minecraft:yellow_terracotta
fill 41 155 356 41 158 356 minecraft:honeycomb_block
setblock 41 155 360 minecraft:yellow_terracotta
fill 41 155 361 41 158 361 minecraft:honeycomb_block
fill 42 155 324 42 269 324 minecraft:honeycomb_block
fill 42 155 353 42 182 353 minecraft:honeycomb_block
fill 0 156 348 0 279 348 minecraft:honeycomb_block
setblock 1 156 334 minecraft:yellow_terracotta
fill 1 156 335 1 156 338 minecraft:honeycomb_block
setblock 1 156 339 minecraft:yellow_terracotta
fill 1 156 340 1 159 340 minecraft:honeycomb_block
setblock 1 156 343 minecraft:honeycomb_block
setblock 1 156 344 minecraft:yellow_terracotta
fill 1 156 345 1 159 345 minecraft:honeycomb_block
setblock 1 156 349 minecraft:yellow_terracotta
fill 1 156 350 1 159 350 minecraft:honeycomb_block
setblock 1 156 354 minecraft:yellow_terracotta
fill 1 156 355 1 156 358 minecraft:honeycomb_block
setblock 1 156 359 minecraft:yellow_terracotta
fill 1 156 360 1 159 360 minecraft:honeycomb_block
setblock 2 156 338 minecraft:yellow_terracotta
fill 2 156 339 2 159 339 minecraft:honeycomb_block
setblock 2 156 343 minecraft:yellow_terracotta
fill 2 156 344 2 159 344 minecraft:honeycomb_block
setblock 2 156 347 minecraft:honeycomb_block
setblock 2 156 348 minecraft:yellow_terracotta
fill 2 156 349 2 159 349 minecraft:honeycomb_block
setblock 2 156 353 minecraft:yellow_terracotta
fill 2 156 354 2 159 354 minecraft:honeycomb_block
setblock 2 156 358 minecraft:yellow_terracotta
fill 2 156 359 2 159 359 minecraft:honeycomb_block
setblock 2 156 363 minecraft:yellow_terracotta
fill 3 156 338 3 159 338 minecraft:honeycomb_block
setblock 3 156 342 minecraft:yellow_terracotta
setblock 3 156 357 minecraft:yellow_terracotta
fill 3 156 358 3 159 358 minecraft:honeycomb_block
setblock 3 156 362 minecraft:yellow_terracotta
fill 3 156 363 3 159 363 minecraft:honeycomb_block
setblock 4 156 361 minecraft:yellow_terracotta
fill 4 156 362 4 159 362 minecraft:honeycomb_block
setblock 5 156 361 minecraft:honeycomb_block
setblock 7 156 363 minecraft:yellow_terracotta
setblock 8 156 349 minecraft:honey_block
fill 8 156 363 8 159 363 minecraft:honeycomb_block
setblock 10 156 322 minecraft:yellow_terracotta
fill 10 156 348 13 156 348 minecraft:yellow_terracotta
fill 10 156 350 13 156 350 minecraft:yellow_terracotta
fill 13 156 349 14 158 349 minecraft:yellow_terracotta
setblock 17 156 323 minecraft:honey_block
setblock 19 156 363 minecraft:honey_block
fill 20 156 363 21 156 363 minecraft:honeycomb_block
setblock 22 156 323 minecraft:yellow_terracotta
fill 22 156 324 22 159 324 minecraft:honeycomb_block
setblock 22 156 362 minecraft:honeycomb_block
setblock 22 156 363 minecraft:yellow_terracotta
fill 23 156 323 23 159 323 minecraft:honeycomb_block
setblock 23 156 362 minecraft:yellow_terracotta
fill 23 156 363 23 159 363 minecraft:honeycomb_block
fill 24 156 362 24 159 362 minecraft:honeycomb_block
fill 25 156 364 25 275 364 minecraft:honeycomb_block
setblock 26 156 324 minecraft:yellow_terracotta
setblock 27 156 323 minecraft:yellow_terracotta
fill 27 156 324 27 159 324 minecraft:honeycomb_block
fill 27 156 349 28 158 349 minecraft:yellow_terracotta
setblock 27 156 363 minecraft:yellow_terracotta
fill 28 156 323 28 159 323 minecraft:honeycomb_block
fill 28 156 348 31 156 348 minecraft:yellow_terracotta
fill 28 156 350 31 156 350 minecraft:yellow_terracotta
setblock 28 156 362 minecraft:yellow_terracotta
fill 28 156 363 28 159 363 minecraft:honeycomb_block
fill 29 156 362 29 159 362 minecraft:honeycomb_block
setblock 32 156 363 minecraft:yellow_terracotta
setblock 33 156 349 minecraft:honey_block
fill 33 156 363 33 159 363 minecraft:honeycomb_block
fill 36 156 362 36 157 362 minecraft:honeycomb_block
setblock 37 156 323 minecraft:yellow_terracotta
setblock 37 156 363 minecraft:yellow_terracotta
fill 38 156 323 38 159 323 minecraft:honeycomb_block
setblock 38 156 362 minecraft:yellow_terracotta
fill 38 156 363 38 159 363 minecraft:honeycomb_block
setblock 39 156 361 minecraft:yellow_terracotta
fill 39 156 362 39 159 362 minecraft:honeycomb_block
setblock 40 156 355 minecraft:yellow_terracotta
fill 40 156 356 40 159 356 minecraft:honeycomb_block
setblock 40 156 360 minecraft:yellow_terracotta
fill 40 156 361 40 159 361 minecraft:honeycomb_block
setblock 41 156 324 minecraft:yellow_terracotta
setblock 41 156 334 minecraft:yellow_terracotta
fill 41 156 335 41 159 335 minecraft:honeycomb_block
setblock 41 156 339 minecraft:yellow_terracotta
fill 41 156 340 41 159 340 minecraft:honeycomb_block
setblock 41 156 343 minecraft:honeycomb_block
setblock 41 156 344 minecraft:yellow_terracotta
setblock 41 156 354 minecraft:yellow_terracotta
fill 41 156 355 41 159 355 minecraft:honeycomb_block
setblock 41 156 359 minecraft:yellow_terracotta
fill 41 156 360 41 159 360 minecraft:honeycomb_block
setblock 1 157 323 minecraft:yellow_terracotta
setblock 1 157 324 minecraft:honey_block
fill 1 157 334 1 157 337 minecraft:honeycomb_block
setblock 1 157 338 minecraft:yellow_terracotta
fill 1 157 339 1 160 339 minecraft:honeycomb_block
setblock 1 157 343 minecraft:yellow_terracotta
fill 1 157 344 1 160 344 minecraft:honeycomb_block
setblock 1 157 348 minecraft:yellow_terracotta
fill 1 157 349 1 160 349 minecraft:honeycomb_block
setblock 1 157 353 minecraft:yellow_terracotta
fill 1 157 354 1 157 357 minecraft:honeycomb_block
setblock 1 157 358 minecraft:yellow_terracotta
fill 1 157 359 1 160 359 minecraft:honeycomb_block
setblock 1 157 363 minecraft:yellow_terracotta
fill 2 157 323 3 159 323 minecraft:honeycomb_block
setblock 2 157 337 minecraft:yellow_terracotta
fill 2 157 338 2 160 338 minecraft:honeycomb_block
setblock 2 157 342 minecraft:yellow_terracotta
fill 2 157 343 3 159 343 minecraft:honeycomb_block
setblock 2 157 347 minecraft:yellow_terracotta
fill 2 157 348 2 160 348 minecraft:honeycomb_block
setblock 2 157 352 minecraft:yellow_terracotta
fill 2 157 353 2 160 353 minecraft:honeycomb_block
setblock 2 157 357 minecraft:yellow_terracotta
fill 2 157 358 2 160 358 minecraft:honeycomb_block
setblock 2 157 362 minecraft:yellow_terracotta
fill 2 157 363 2 160 363 minecraft:honeycomb_block
setblock 3 157 341 minecraft:yellow_terracotta
fill 3 157 342 3 160 342 minecraft:honeycomb_block
fill 3 157 344 3 158 344 minecraft:honeycomb_block
setblock 3 157 356 minecraft:yellow_terracotta
fill 3 157 357 3 158 357 minecraft:honeycomb_block
setblock 3 157 361 minecraft:yellow_terracotta
fill 3 157 362 3 160 362 minecraft:honeycomb_block
fill 4 157 361 4 158 361 minecraft:honeycomb_block
setblock 6 157 363 minecraft:yellow_terracotta
fill 7 157 350 8 158 350 minecraft:yellow_concrete
fill 7 157 363 7 160 363 minecraft:honeycomb_block
fill 10 157 322 10 234 322 minecraft:honeycomb_block
setblock 10 157 349 minecraft:honey_block
setblock 11 157 323 minecraft:honey_block
fill 12 157 348 15 157 348 minecraft:yellow_terracotta
fill 12 157 350 15 157 350 minecraft:yellow_terracotta
fill 15 157 349 18 158 349 minecraft:yellow_terracotta
fill 19 157 323 19 158 323 minecraft:honeycomb_block
fill 19 157 363 20 157 363 minecraft:honeycomb_block
fill 20 157 333 21 158 333 minecraft:honey_block
setblock 21 157 323 minecraft:yellow_terracotta
fill 21 157 324 21 160 324 minecraft:honeycomb_block
setblock 21 157 362 minecraft:honeycomb_block
setblock 21 157 363 minecraft:yellow_terracotta
fill 22 157 323 22 160 323 minecraft:honeycomb_block
setblock 22 157 362 minecraft:yellow_terracotta
fill 22 157 363 22 160 363 minecraft:honeycomb_block
fill 23 157 349 26 158 349 minecraft:yellow_terracotta
fill 23 157 362 23 160 362 minecraft:honeycomb_block
setblock 25 157 324 minecraft:yellow_terracotta
setblock 26 157 323 minecraft:yellow_terracotta
fill 26 157 324 26 160 324 minecraft:honeycomb_block
fill 26 157 348 29 157 348 minecraft:yellow_terracotta
fill 26 157 350 29 157 350 minecraft:yellow_terracotta
setblock 26 157 363 minecraft:yellow_terracotta
fill 27 157 323 27 160 323 minecraft:honeycomb_block
setblock 27 157 362 minecraft:yellow_terracotta
fill 27 157 363 27 160 363 minecraft:honeycomb_block
fill 28 157 362 28 160 362 minecraft:honeycomb_block
setblock 31 157 322 minecraft:yellow_concrete
setblock 31 157 323 minecraft:yellow_terracotta
setblock 31 157 349 minecraft:honey_block
setblock 31 157 363 minecraft:yellow_terracotta
fill 32 157 322 32 160 323 minecraft:honeycomb_block
fill 32 157 363 32 160 363 minecraft:honeycomb_block
setblock 33 157 364 minecraft:yellow_concrete
fill 35 157 362 35 158 362 minecraft:honeycomb_block
setblock 36 157 323 minecraft:yellow_terracotta
setblock 36 157 363 minecraft:yellow_terracotta
fill 37 157 323 37 160 323 minecraft:honeycomb_block
setblock 37 157 362 minecraft:yellow_terracotta
fill 37 157 363 37 160 363 minecraft:honeycomb_block
setblock 38 157 361 minecraft:yellow_terracotta
fill 38 157 362 38 160 362 minecraft:honeycomb_block
setblock 39 157 360 minecraft:yellow_terracotta
fill 39 157 361 39 160 361 minecraft:honeycomb_block
fill 40 157 355 40 160 355 minecraft:honeycomb_block
setblock 40 157 359 minecraft:yellow_terracotta
fill 40 157 360 40 160 360 minecraft:honeycomb_block
setblock 41 157 323 minecraft:yellow_terracotta
fill 41 157 324 41 159 325 minecraft:honeycomb_block
setblock 41 157 338 minecraft:yellow_terracotta
fill 41 157 339 41 160 339 minecraft:honeycomb_block
setblock 41 157 343 minecraft:yellow_terracotta
fill 41 157 344 41 158 346 minecraft:honeycomb_block
setblock 41 157 353 minecraft:yellow_terracotta
fill 41 157 354 41 160 354 minecraft:honeycomb_block
setblock 41 157 358 minecraft:yellow_terracotta
fill 41 157 359 41 160 359 minecraft:honeycomb_block
setblock 41 157 363 minecraft:yellow_terracotta
setblock 0 158 361 minecraft:orange_terracotta
fill 0 158 362 0 204 362 minecraft:honeycomb_block
fill 1 158 323 1 160 324 minecraft:honeycomb_block
setblock 1 158 330 minecraft:honey_block
fill 1 158 334 1 158 336 minecraft:honeycomb_block
setblock 1 158 337 minecraft:yellow_terracotta
fill 1 158 338 1 161 338 minecraft:honeycomb_block
setblock 1 158 342 minecraft:yellow_terracotta
fill 1 158 343 1 161 343 minecraft:honeycomb_block
setblock 1 158 346 minecraft:honeycomb_block
setblock 1 158 347 minecraft:yellow_terracotta
fill 1 158 348 1 161 348 minecraft:honeycomb_block
setblock 1 158 352 minecraft:yellow_terracotta
fill 1 158 353 1 158 356 minecraft:honeycomb_block
setblock 1 158 357 minecraft:yellow_terracotta
fill 1 158 358 1 161 358 minecraft:honeycomb_block
setblock 1 158 362 minecraft:yellow_terracotta
fill 1 158 363 1 161 363 minecraft:honeycomb_block
setblock 2 158 336 minecraft:yellow_terracotta
fill 2 158 337 2 161 337 minecraft:honeycomb_block
setblock 2 158 341 minecraft:yellow_terracotta
fill 2 158 342 2 161 342 minecraft:honeycomb_block
setblock 2 158 346 minecraft:yellow_terracotta
fill 2 158 347 2 161 347 minecraft:honeycomb_block
setblock 2 158 351 minecraft:yellow_terracotta
fill 2 158 352 2 161 352 minecraft:honeycomb_block
setblock 2 158 356 minecraft:yellow_terracotta
fill 2 158 357 2 161 357 minecraft:honeycomb_block
setblock 2 158 361 minecraft:yellow_terracotta
fill 2 158 362 2 161 362 minecraft:honeycomb_block
setblock 3 158 340 minecraft:yellow_terracotta
fill 3 158 341 3 161 341 minecraft:honeycomb_block
setblock 3 158 345 minecraft:yellow_terracotta
setblock 3 158 360 minecraft:yellow_terracotta
fill 3 158 361 3 161 361 minecraft:honeycomb_block
setblock 4 158 323 minecraft:honeycomb_block
setblock 5 158 323 minecraft:honey_block
setblock 5 158 363 minecraft:yellow_terracotta
setblock 6 158 362 minecraft:yellow_terracotta
fill 6 158 363 6 161 363 minecraft:honeycomb_block
fill 11 158 349 12 158 349 minecraft:honey_block
setblock 12 158 363 minecraft:honey_block
setblock 13 158 364 minecraft:yellow_concrete
fill 15 158 348 26 158 348 minecraft:yellow_terracotta
fill 15 158 350 26 158 350 minecraft:yellow_terracotta
fill 17 158 323 18 159 323 minecraft:honeycomb_block
fill 18 158 363 19 158 363 minecraft:honeycomb_block
fill 19 158 349 22 159 349 minecraft:yellow_terracotta
setblock 20 158 323 minecraft:yellow_terracotta
fill 20 158 324 20 161 324 minecraft:honeycomb_block
setblock 20 158 362 minecraft:honeycomb_block
setblock 20 158 363 minecraft:yellow_terracotta
fill 21 158 323 21 161 323 minecraft:honeycomb_block
setblock 21 158 362 minecraft:yellow_terracotta
fill 21 158 363 21 161 363 minecraft:honeycomb_block
fill 22 158 362 22 161 362 minecraft:honeycomb_block
setblock 24 158 324 minecraft:yellow_terracotta
setblock 25 158 323 minecraft:yellow_terracotta
fill 25 158 324 25 161 324 minecraft:honeycomb_block
setblock 25 158 363 minecraft:yellow_terracotta
fill 26 158 323 26 161 323 minecraft:honeycomb_block
setblock 26 158 362 minecraft:yellow_terracotta
fill 26 158 363 26 161 363 minecraft:honeycomb_block
fill 27 158 362 27 161 362 minecraft:honeycomb_block
fill 29 158 349 30 158 349 minecraft:honey_block
setblock 30 158 323 minecraft:yellow_terracotta
setblock 30 158 363 minecraft:yellow_terracotta
fill 31 158 322 31 161 323 minecraft:honeycomb_block
fill 31 158 363 31 161 363 minecraft:honeycomb_block
fill 33 158 323 34 158 323 minecraft:honeycomb_block
fill 33 158 364 33 183 364 minecraft:honeycomb_block
fill 34 158 362 34 159 362 minecraft:honeycomb_block
setblock 35 158 323 minecraft:yellow_terracotta
setblock 35 158 363 minecraft:yellow_terracotta
fill 36 158 323 36 161 323 minecraft:honeycomb_block
setblock 36 158 362 minecraft:yellow_terracotta
fill 36 158 363 36 161 363 minecraft:honeycomb_block
fill 37 158 362 37 161 362 minecraft:honeycomb_block
fill 38 158 361 38 161 361 minecraft:honeycomb_block
setblock 39 158 358 minecraft:honeycomb_block
setblock 39 158 359 minecraft:yellow_terracotta
fill 39 158 360 39 161 360 minecraft:honeycomb_block
setblock 40 158 323 minecraft:yellow_terracotta
setblock 40 158 358 minecraft:yellow_terracotta
fill 40 158 359 40 161 359 minecraft:honeycomb_block
setblock 40 158 363 minecraft:yellow_terracotta
fill 41 158 323 41 161 323 minecraft:honeycomb_block
setblock 41 158 326 minecraft:honeycomb_block
setblock 41 158 331 minecraft:honey_block
setblock 41 158 337 minecraft:yellow_terracotta
fill 41 158 338 41 161 338 minecraft:honeycomb_block
setblock 41 158 341 minecraft:honeycomb_block
setblock 41 158 342 minecraft:yellow_terracotta
fill 41 158 343 41 161 343 minecraft:honeycomb_block
setblock 41 158 347 minecraft:yellow_terracotta
fill 41 158 348 41 159 350 minecraft:honeycomb_block
setblock 41 158 352 minecraft:yellow_terracotta
fill 41 158 353 41 161 353 minecraft:honeycomb_block
setblock 41 158 357 minecraft:yellow_terracotta
fill 41 158 358 41 161 358 minecraft:honeycomb_block
setblock 41 158 362 minecraft:yellow_terracotta
fill 41 158 363 41 161 363 minecraft:honeycomb_block
setblock 42 158 348 minecraft:yellow_concrete
setblock 0 159 346 minecraft:orange_terracotta
fill 0 159 347 1 162 347 minecraft:honeycomb_block
fill 0 159 361 0 160 361 minecraft:honeycomb_block
setblock 1 159 325 minecraft:honeycomb_block
fill 1 159 334 1 159 335 minecraft:honeycomb_block
setblock 1 159 336 minecraft:yellow_terracotta
fill 1 159 337 1 162 337 minecraft:honeycomb_block
setblock 1 159 341 minecraft:yellow_terracotta
fill 1 159 342 1 162 342 minecraft:honeycomb_block
setblock 1 159 346 minecraft:yellow_terracotta
setblock 1 159 351 minecraft:yellow_terracotta
fill 1 159 352 1 159 355 minecraft:honeycomb_block
setblock 1 159 356 minecraft:yellow_terracotta
fill 1 159 357 1 162 357 minecraft:honeycomb_block
setblock 1 159 361 minecraft:yellow_terracotta
fill 1 159 362 1 162 362 minecraft:honeycomb_block
fill 2 159 336 2 162 336 minecraft:honeycomb_block
setblock 2 159 340 minecraft:yellow_terracotta
fill 2 159 341 2 162 341 minecraft:honeycomb_block
setblock 2 159 345 minecraft:yellow_terracotta
fill 2 159 346 3 161 346 minecraft:honeycomb_block
setblock 2 159 350 minecraft:yellow_terracotta
fill 2 159 351 2 162 351 minecraft:honeycomb_block
setblock 2 159 355 minecraft:yellow_terracotta
fill 2 159 356 2 162 356 minecraft:honeycomb_block
setblock 2 159 360 minecraft:yellow_terracotta
fill 2 159 361 2 162 361 minecraft:honeycomb_block
setblock 3 159 325 minecraft:light[level=15]
setblock 3 159 332 minecraft:light[level=12]
setblock 3 159 333 minecraft:light[level=15]
setblock 3 159 339 minecraft:yellow_terracotta
fill 3 159 340 3 162 340 minecraft:honeycomb_block
setblock 3 159 344 minecraft:yellow_terracotta
fill 3 159 345 3 162 345 minecraft:honeycomb_block
fill 3 159 347 3 160 347 minecraft:honeycomb_block
setblock 3 159 349 minecraft:light[level=15]
setblock 3 159 353 minecraft:light[level=12]
setblock 3 159 357 minecraft:light[level=15]
setblock 3 159 359 minecraft:yellow_terracotta
fill 3 159 360 3 161 360 minecraft:honeycomb_block
setblock 4 159 323 minecraft:yellow_terracotta
setblock 4 159 363 minecraft:yellow_terracotta
fill 5 159 323 5 162 323 minecraft:honeycomb_block
setblock 5 159 362 minecraft:yellow_terracotta
fill 5 159 363 5 162 363 minecraft:honeycomb_block
setblock 6 159 362 minecraft:honeycomb_block
setblock 10 159 325 minecraft:light[level=12]
setblock 10 159 332 minecraft:light[level=12]
setblock 10 159 339 minecraft:light[level=12]
setblock 10 159 346 minecraft:light[level=12]
setblock 10 159 353 minecraft:light[level=12]
setblock 10 159 360 minecraft:light[level=12]
setblock 11 159 325 minecraft:light[level=15]
setblock 11 159 333 minecraft:light[level=15]
setblock 11 159 341 minecraft:light[level=15]
setblock 11 159 349 minecraft:light[level=15]
fill 11 159 356 11 160 357 minecraft:yellow_concrete
fill 13 159 364 13 308 364 minecraft:honeycomb_block
fill 14 159 349 15 159 349 minecraft:honey_block
fill 16 159 323 16 161 323 minecraft:honeycomb_block
fill 16 159 349 18 159 349 minecraft:yellow_terracotta
fill 16 159 363 18 159 363 minecraft:honeycomb_block
setblock 17 159 325 minecraft:light[level=12]
setblock 17 159 332 minecraft:light[level=12]
setblock 17 159 339 minecraft:light[level=12]
setblock 17 159 346 minecraft:light[level=12]
setblock 17 159 353 minecraft:light[level=12]
setblock 17 159 360 minecraft:light[level=12]
setblock 18 159 324 minecraft:yellow_terracotta
fill 18 159 348 23 159 348 minecraft:yellow_terracotta
fill 18 159 350 23 159 350 minecraft:yellow_terracotta
setblock 19 159 323 minecraft:yellow_terracotta
fill 19 159 324 19 162 324 minecraft:honeycomb_block
setblock 19 159 325 minecraft:light[level=15]
setblock 19 159 333 minecraft:light[level=15]
setblock 19 159 341 minecraft:light[level=15]
setblock 19 159 357 minecraft:light[level=15]
setblock 19 159 362 minecraft:honeycomb_block
setblock 19 159 363 minecraft:yellow_terracotta
fill 20 159 323 20 162 323 minecraft:honeycomb_block
setblock 20 159 362 minecraft:yellow_terracotta
fill 20 159 363 20 162 363 minecraft:honeycomb_block
fill 21 159 362 21 162 362 minecraft:honeycomb_block
setblock 22 159 325 minecraft:yellow_terracotta
setblock 23 159 324 minecraft:yellow_terracotta
fill 23 159 325 23 162 325 minecraft:honeycomb_block
fill 23 159 349 25 159 349 minecraft:yellow_terracotta
setblock 24 159 323 minecraft:yellow_terracotta
fill 24 159 324 24 162 324 minecraft:honeycomb_block
setblock 24 159 325 minecraft:light[level=12]
setblock 24 159 332 minecraft:light[level=12]
setblock 24 159 339 minecraft:light[level=12]
setblock 24 159 346 minecraft:light[level=12]
setblock 24 159 353 minecraft:light[level=12]
setblock 24 159 360 minecraft:light[level=12]
setblock 24 159 363 minecraft:yellow_terracotta
fill 25 159 323 25 162 323 minecraft:honeycomb_block
setblock 25 159 362 minecraft:yellow_terracotta
fill 25 159 363 25 162 363 minecraft:honeycomb_block
fill 26 159 349 27 159 349 minecraft:honey_block
fill 26 159 362 26 162 362 minecraft:honeycomb_block
setblock 27 159 325 minecraft:light[level=15]
setblock 27 159 333 minecraft:light[level=15]
setblock 27 159 341 minecraft:light[level=15]
setblock 27 159 357 minecraft:light[level=15]
setblock 28 159 324 minecraft:yellow_terracotta
setblock 29 159 323 minecraft:yellow_terracotta
setblock 29 159 363 minecraft:yellow_terracotta
fill 30 159 323 30 162 323 minecraft:honeycomb_block
setblock 30 159 362 minecraft:yellow_terracotta
fill 30 159 363 30 162 363 minecraft:honeycomb_block
setblock 31 159 325 minecraft:light[level=12]
setblock 31 159 332 minecraft:light[level=12]
setblock 31 159 339 minecraft:light[level=12]
setblock 31 159 346 minecraft:light[level=12]
setblock 31 159 353 minecraft:light[level=12]
setblock 31 159 360 minecraft:light[level=12]
fill 32 159 362 33 160 362 minecraft:honeycomb_block
setblock 33 159 323 minecraft:honeycomb_block
setblock 34 159 323 minecraft:yellow_terracotta
setblock 34 159 363 minecraft:yellow_terracotta
fill 35 159 323 35 162 323 minecraft:honeycomb_block
setblock 35 159 325 minecraft:light[level=15]
setblock 35 159 333 minecraft:light[level=15]
setblock 35 159 341 minecraft:light[level=15]
setblock 35 159 349 minecraft:light[level=15]
setblock 35 159 357 minecraft:light[level=15]
setblock 35 159 362 minecraft:yellow_terracotta
fill 35 159 363 35 162 363 minecraft:honeycomb_block
fill 36 159 362 36 162 362 minecraft:honeycomb_block
fill 37 159 361 37 162 361 minecraft:honeycomb_block
setblock 37 159 364 minecraft:yellow_terracotta
setblock 38 159 325 minecraft:light[level=12]
setblock 38 159 332 minecraft:light[level=12]
setblock 38 159 339 minecraft:light[level=12]
setblock 38 159 346 minecraft:light[level=12]
setblock 38 159 353 minecraft:light[level=12]
setblock 38 159 360 minecraft:light[level=12]
setblock 39 159 323 minecraft:yellow_terracotta
fill 39 159 324 40 161 324 minecraft:honeycomb_block
setblock 39 159 358 minecraft:yellow_terracotta
fill 39 159 359 39 162 359 minecraft:honeycomb_block
setblock 39 159 363 minecraft:yellow_terracotta
fill 40 159 323 40 162 323 minecraft:honeycomb_block
fill 40 159 339 40 159 341 minecraft:honeycomb_block
setblock 40 159 342 minecraft:yellow_terracotta
fill 40 159 343 40 160 345 minecraft:honeycomb_block
fill 40 159 354 40 161 354 minecraft:honeycomb_block
setblock 40 159 357 minecraft:yellow_terracotta
fill 40 159 358 40 162 358 minecraft:honeycomb_block
setblock 40 159 362 minecraft:yellow_terracotta
fill 40 159 363 40 162 363 minecraft:honeycomb_block
setblock 41 159 326 minecraft:yellow_terracotta
setblock 41 159 336 minecraft:yellow_terracotta
fill 41 159 337 41 162 337 minecraft:honeycomb_block
setblock 41 159 341 minecraft:yellow_terracotta
fill 41 159 342 41 162 342 minecraft:honeycomb_block
fill 41 159 344 41 159 345 minecraft:honeycomb_block
setblock 41 159 346 minecraft:yellow_terracotta
fill 41 159 347 41 162 347 minecraft:honeycomb_block
setblock 41 159 351 minecraft:yellow_terracotta
fill 41 159 352 41 162 352 minecraft:honeycomb_block
setblock 41 159 356 minecraft:yellow_terracotta
fill 41 159 357 41 162 357 minecraft:honeycomb_block
setblock 41 159 361 minecraft:yellow_terracotta
fill 41 159 362 41 162 362 minecraft:honeycomb_block
fill 42 159 348 42 269 348 minecraft:honeycomb_block
setblock 0 160 333 minecraft:yellow_concrete
fill 0 160 346 1 163 346 minecraft:honeycomb_block
setblock 1 160 325 minecraft:yellow_terracotta
fill 1 160 326 1 163 326 minecraft:honeycomb_block
fill 1 160 333 1 160 334 minecraft:honeycomb_block
setblock 1 160 335 minecraft:yellow_terracotta
fill 1 160 336 1 163 336 minecraft:honeycomb_block
setblock 1 160 340 minecraft:yellow_terracotta
fill 1 160 341 1 163 341 minecraft:honeycomb_block
setblock 1 160 345 minecraft:yellow_terracotta
setblock 1 160 350 minecraft:yellow_terracotta
fill 1 160 351 1 160 354 minecraft:honeycomb_block
setblock 1 160 355 minecraft:yellow_terracotta
fill 1 160 356 1 163 356 minecraft:honeycomb_block
setblock 1 160 360 minecraft:yellow_terracotta
fill 1 160 361 1 163 361 minecraft:honeycomb_block
setblock 2 160 323 minecraft:honeycomb_block
setblock 2 160 339 minecraft:yellow_terracotta
fill 2 160 340 2 163 340 minecraft:honeycomb_block
setblock 2 160 343 minecraft:honeycomb_block
setblock 2 160 344 minecraft:yellow_terracotta
fill 2 160 345 2 163 345 minecraft:honeycomb_block
setblock 2 160 349 minecraft:yellow_terracotta
fill 2 160 350 2 163 350 minecraft:honeycomb_block
setblock 2 160 354 minecraft:yellow_terracotta
fill 2 160 355 2 163 355 minecraft:honeycomb_block
setblock 2 160 359 minecraft:yellow_terracotta
fill 2 160 360 2 163 360 minecraft:honeycomb_block
setblock 3 160 323 minecraft:yellow_terracotta
setblock 3 160 338 minecraft:yellow_terracotta
fill 3 160 339 3 163 339 minecraft:honeycomb_block
setblock 3 160 343 minecraft:yellow_terracotta
fill 3 160 344 3 163 344 minecraft:honeycomb_block
setblock 3 160 348 minecraft:yellow_terracotta
setblock 3 160 359 minecraft:honeycomb_block
setblock 3 160 363 minecraft:yellow_terracotta
fill 4 160 323 4 163 323 minecraft:honeycomb_block
setblock 4 160 341 minecraft:honeycomb_block
setblock 4 160 342 minecraft:yellow_terracotta
fill 4 160 343 4 163 343 minecraft:honeycomb_block
setblock 4 160 362 minecraft:yellow_terracotta
fill 4 160 363 4 163 363 minecraft:honeycomb_block
fill 5 160 362 5 162 362 minecraft:honeycomb_block
fill 6 160 323 6 161 323 minecraft:honeycomb_block
setblock 8 160 363 minecraft:yellow_terracotta
fill 14 160 323 15 162 323 minecraft:honeycomb_block
fill 15 160 363 17 160 363 minecraft:honeycomb_block
fill 16 160 349 25 160 349 minecraft:honey_block
setblock 17 160 323 minecraft:honeycomb_block
setblock 17 160 324 minecraft:yellow_terracotta
setblock 18 160 323 minecraft:yellow_terracotta
fill 18 160 324 18 163 324 minecraft:honeycomb_block
setblock 18 160 362 minecraft:honeycomb_block
setblock 18 160 363 minecraft:yellow_terracotta
fill 19 160 323 19 163 323 minecraft:honeycomb_block
setblock 19 160 362 minecraft:yellow_terracotta
fill 19 160 363 19 163 363 minecraft:honeycomb_block
setblock 20 160 325 minecraft:honeycomb_block
fill 20 160 362 20 163 362 minecraft:honeycomb_block
setblock 21 160 325 minecraft:yellow_terracotta
setblock 22 160 324 minecraft:yellow_terracotta
fill 22 160 325 22 163 325 minecraft:honeycomb_block
setblock 23 160 323 minecraft:yellow_terracotta
fill 23 160 324 23 163 324 minecraft:honeycomb_block
setblock 23 160 363 minecraft:yellow_terracotta
fill 24 160 323 24 163 323 minecraft:honeycomb_block
fill 24 160 325 25 160 325 minecraft:honeycomb_block
setblock 24 160 362 minecraft:yellow_terracotta
fill 24 160 363 24 163 363 minecraft:honeycomb_block
fill 25 160 362 25 163 362 minecraft:honeycomb_block
setblock 27 160 324 minecraft:yellow_terracotta
setblock 28 160 323 minecraft:yellow_terracotta
fill 28 160 324 29 162 324 minecraft:honeycomb_block
setblock 28 160 363 minecraft:yellow_terracotta
fill 29 160 323 29 163 323 minecraft:honeycomb_block
setblock 29 160 362 minecraft:yellow_terracotta
fill 29 160 363 29 163 363 minecraft:honeycomb_block
fill 30 160 362 31 162 362 minecraft:honeycomb_block
setblock 33 160 323 minecraft:yellow_terracotta
setblock 33 160 363 minecraft:yellow_terracotta
fill 34 160 323 34 163 323 minecraft:honeycomb_block
setblock 34 160 362 minecraft:yellow_terracotta
fill 34 160 363 34 163 363 minecraft:honeycomb_block
fill 35 160 362 35 163 362 minecraft:honeycomb_block
setblock 36 160 324 minecraft:honeycomb_block
fill 36 160 361 36 163 361 minecraft:honeycomb_block
setblock 37 160 324 minecraft:yellow_terracotta
fill 37 160 364 37 199 364 minecraft:honeycomb_block
setblock 38 160 323 minecraft:yellow_terracotta
fill 38 160 324 38 163 324 minecraft:honeycomb_block
setblock 38 160 363 minecraft:yellow_terracotta
fill 39 160 323 39 163 323 minecraft:honeycomb_block
setblock 39 160 357 minecraft:yellow_terracotta
fill 39 160 358 39 163 358 minecraft:honeycomb_block
setblock 39 160 362 minecraft:yellow_terracotta
fill 39 160 363 39 163 363 minecraft:honeycomb_block
setblock 40 160 325 minecraft:honeycomb_block
fill 40 160 338 40 160 340 minecraft:honeycomb_block
setblock 40 160 341 minecraft:yellow_terracotta
fill 40 160 342 40 163 342 minecraft:honeycomb_block
setblock 40 160 346 minecraft:yellow_terracotta
fill 40 160 347 40 162 348 minecraft:honeycomb_block
fill 40 160 353 40 162 353 minecraft:honeycomb_block
setblock 40 160 356 minecraft:yellow_terracotta
fill 40 160 357 40 163 357 minecraft:honeycomb_block
setblock 40 160 361 minecraft:yellow_terracotta
fill 40 160 362 40 163 362 minecraft:honeycomb_block
setblock 41 160 324 minecraft:honeycomb_block
setblock 41 160 325 minecraft:yellow_terracotta
fill 41 160 326 41 162 327 minecraft:honeycomb_block
setblock 41 160 335 minecraft:yellow_terracotta
fill 41 160 336 41 163 336 minecraft:honeycomb_block
setblock 41 160 340 minecraft:yellow_terracotta
fill 41 160 341 41 163 341 minecraft:honeycomb_block
setblock 41 160 344 minecraft:honeycomb_block
setblock 41 160 345 minecraft:yellow_terracotta
fill 41 160 346 41 163 346 minecraft:honeycomb_block
fill 41 160 348 41 160 349 minecraft:honeycomb_block
setblock 41 160 350 minecraft:yellow_terracotta
fill 41 160 351 41 163 351 minecraft:honeycomb_block
setblock 41 160 355 minecraft:yellow_terracotta
fill 41 160 356 41 163 356 minecraft:honeycomb_block
setblock 41 160 360 minecraft:yellow_terracotta
fill 41 160 361 41 163 361 minecraft:honeycomb_block
fill 0 161 333 1 161 333 minecraft:honeycomb_block
setblock 0 161 345 minecraft:yellow_concrete
setblock 0 161 361 minecraft:yellow_terracotta
setblock 1 161 323 minecraft:honeycomb_block
setblock 1 161 324 minecraft:yellow_terracotta
fill 1 161 325 1 164 325 minecraft:honeycomb_block
fill 1 161 327 1 161 328 minecraft:honeycomb_block
setblock 1 161 329 minecraft:honey_block
fill 1 161 332 1 162 332 minecraft:honeycomb_block
setblock 1 161 334 minecraft:yellow_terracotta
fill 1 161 335 2 163 335 minecraft:honeycomb_block
setblock 1 161 339 minecraft:yellow_terracotta
fill 1 161 340 1 164 340 minecraft:honeycomb_block
setblock 1 161 344 minecraft:yellow_terracotta
fill 1 161 345 1 164 345 minecraft:honeycomb_block
setblock 1 161 349 minecraft:yellow_terracotta
fill 1 161 350 1 161 353 minecraft:honeycomb_block
setblock 1 161 354 minecraft:yellow_terracotta
fill 1 161 355 1 164 355 minecraft:honeycomb_block
setblock 1 161 359 minecraft:yellow_terracotta
fill 1 161 360 1 164 360 minecraft:honeycomb_block
setblock 2 161 323 minecraft:yellow_terracotta
fill 2 161 324 2 164 324 minecraft:honeycomb_block
setblock 2 161 338 minecraft:yellow_terracotta
fill 2 161 339 2 164 339 minecraft:honeycomb_block
setblock 2 161 343 minecraft:yellow_terracotta
fill 2 161 344 2 164 344 minecraft:honeycomb_block
setblock 2 161 348 minecraft:yellow_terracotta
fill 2 161 349 3 163 349 minecraft:honeycomb_block
setblock 2 161 353 minecraft:yellow_terracotta
fill 2 161 354 2 164 354 minecraft:honeycomb_block
setblock 2 161 358 minecraft:yellow_terracotta
fill 2 161 359 2 164 359 minecraft:honeycomb_block
setblock 2 161 363 minecraft:yellow_terracotta
fill 3 161 323 3 164 323 minecraft:honeycomb_block
fill 3 161 338 3 163 338 minecraft:honeycomb_block
setblock 3 161 342 minecraft:yellow_terracotta
fill 3 161 343 3 164 343 minecraft:honeycomb_block
setblock 3 161 347 minecraft:yellow_terracotta
fill 3 161 348 3 164 348 minecraft:honeycomb_block
setblock 3 161 362 minecraft:yellow_terracotta
fill 3 161 363 3 164 363 minecraft:honeycomb_block
setblock 4 161 341 minecraft:yellow_terracotta
fill 4 161 342 4 164 342 minecraft:honeycomb_block
fill 4 161 344 4 161 345 minecraft:honeycomb_block
fill 4 161 362 4 163 362 minecraft:honeycomb_block
setblock 7 161 323 minecraft:yellow_terracotta
fill 7 161 363 7 161 364 minecraft:yellow_terracotta
fill 8 161 363 8 162 363 minecraft:honeycomb_block
setblock 11 161 363 minecraft:honey_block
setblock 12 161 323 minecraft:yellow_terracotta
fill 13 161 323 13 164 323 minecraft:honeycomb_block
fill 14 161 363 16 161 363 minecraft:honeycomb_block
setblock 15 161 324 minecraft:honeycomb_block
setblock 16 161 324 minecraft:yellow_terracotta
setblock 17 161 323 minecraft:yellow_terracotta
fill 17 161 324 17 164 324 minecraft:honeycomb_block
setblock 17 161 362 minecraft:honeycomb_block
setblock 17 161 363 minecraft:yellow_terracotta
fill 18 161 323 18 164 323 minecraft:honeycomb_block
fill 18 161 325 19 161 325 minecraft:honeycomb_block
setblock 18 161 362 minecraft:yellow_terracotta
fill 18 161 363 18 164 363 minecraft:honeycomb_block
fill 19 161 362 19 164 362 minecraft:honeycomb_block
setblock 20 161 325 minecraft:yellow_terracotta
setblock 21 161 324 minecraft:yellow_terracotta
fill 21 161 325 21 164 325 minecraft:honeycomb_block
setblock 22 161 323 minecraft:yellow_terracotta
fill 22 161 324 22 164 324 minecraft:honeycomb_block
fill 22 161 361 23 161 361 minecraft:honeycomb_block
setblock 22 161 363 minecraft:yellow_terracotta
fill 23 161 323 23 164 323 minecraft:honeycomb_block
setblock 23 161 362 minecraft:yellow_terracotta
fill 23 161 363 23 164 363 minecraft:honeycomb_block
setblock 24 161 325 minecraft:honeycomb_block
fill 24 161 362 24 164 362 minecraft:honeycomb_block
setblock 25 161 325 minecraft:yellow_terracotta
setblock 26 161 324 minecraft:yellow_terracotta
fill 26 161 325 26 164 325 minecraft:honeycomb_block
setblock 27 161 323 minecraft:yellow_terracotta
fill 27 161 324 27 164 324 minecraft:honeycomb_block
fill 27 161 334 27 162 334 minecraft:ochre_froglight
setblock 27 161 363 minecraft:yellow_terracotta
fill 28 161 323 28 164 323 minecraft:honeycomb_block
setblock 28 161 362 minecraft:yellow_terracotta
fill 28 161 363 28 164 363 minecraft:honeycomb_block
fill 29 161 362 29 164 362 minecraft:honeycomb_block
setblock 30 161 324 minecraft:honeycomb_block
setblock 30 161 364 minecraft:yellow_terracotta
setblock 31 161 324 minecraft:yellow_terracotta
fill 32 161 322 32 204 322 minecraft:honeycomb_block
setblock 32 161 323 minecraft:yellow_terracotta
fill 32 161 324 35 161 324 minecraft:honeycomb_block
setblock 32 161 362 minecraft:honeycomb_block
setblock 32 161 363 minecraft:yellow_terracotta
fill 33 161 323 33 164 323 minecraft:honeycomb_block
setblock 33 161 362 minecraft:yellow_terracotta
fill 33 161 363 33 164 363 minecraft:honeycomb_block
fill 34 161 362 34 164 362 minecraft:honeycomb_block
fill 35 161 361 35 164 361 minecraft:honeycomb_block
setblock 36 161 324 minecraft:yellow_terracotta
setblock 37 161 323 minecraft:yellow_terracotta
fill 37 161 324 37 164 324 minecraft:honeycomb_block
setblock 37 161 363 minecraft:yellow_terracotta
fill 38 161 323 38 164 323 minecraft:honeycomb_block
setblock 38 161 362 minecraft:yellow_terracotta
fill 38 161 363 38 164 363 minecraft:honeycomb_block
fill 39 161 343 40 161 344 minecraft:honeycomb_block
fill 39 161 357 39 164 357 minecraft:honeycomb_block
setblock 39 161 361 minecraft:yellow_terracotta
fill 39 161 362 39 164 362 minecraft:honeycomb_block
setblock 40 161 325 minecraft:yellow_terracotta
fill 40 161 326 40 164 326 minecraft:honeycomb_block
fill 40 161 338 40 161 339 minecraft:honeycomb_block
setblock 40 161 340 minecraft:yellow_terracotta
fill 40 161 341 40 164 341 minecraft:honeycomb_block
setblock 40 161 345 minecraft:yellow_terracotta
fill 40 161 346 40 164 346 minecraft:honeycomb_block
setblock 40 161 349 minecraft:honeycomb_block
setblock 40 161 350 minecraft:yellow_terracotta
fill 40 161 351 40 163 352 minecraft:honeycomb_block
setblock 40 161 355 minecraft:yellow_terracotta
fill 40 161 356 40 164 356 minecraft:honeycomb_block
setblock 40 161 360 minecraft:yellow_terracotta
fill 40 161 361 40 164 361 minecraft:honeycomb_block
setblock 41 161 324 minecraft:yellow_terracotta
fill 41 161 325 41 164 325 minecraft:honeycomb_block
setblock 41 161 328 minecraft:honeycomb_block
setblock 41 161 329 minecraft:yellow_terracotta
fill 41 161 335 41 164 335 minecraft:honeycomb_block
setblock 41 161 339 minecraft:yellow_terracotta
fill 41 161 340 41 164 340 minecraft:honeycomb_block
setblock 41 161 344 minecraft:yellow_terracotta
fill 41 161 345 41 164 345 minecraft:honeycomb_block
setblock 41 161 348 minecraft:honeycomb_block
setblock 41 161 349 minecraft:yellow_terracotta
fill 41 161 350 41 164 350 minecraft:honeycomb_block
setblock 41 161 354 minecraft:yellow_terracotta
fill 41 161 355 41 164 355 minecraft:honeycomb_block
setblock 41 161 359 minecraft:yellow_terracotta
fill 41 161 360 41 164 360 minecraft:honeycomb_block
fill 0 162 333 0 170 333 minecraft:honeycomb_block
fill 0 162 345 0 248 345 minecraft:honeycomb_block
fill 0 162 361 0 225 361 minecraft:honeycomb_block
setblock 1 162 323 minecraft:yellow_terracotta
fill 1 162 324 1 165 324 minecraft:honeycomb_block
setblock 1 162 327 minecraft:honeycomb_block
setblock 1 162 328 minecraft:yellow_terracotta
fill 1 162 329 1 163 331 minecraft:honeycomb_block
setblock 1 162 333 minecraft:yellow_terracotta
fill 1 162 334 1 165 334 minecraft:honeycomb_block
setblock 1 162 338 minecraft:yellow_terracotta
fill 1 162 339 1 165 339 minecraft:honeycomb_block
setblock 1 162 343 minecraft:yellow_terracotta
fill 1 162 344 1 165 344 minecraft:honeycomb_block
setblock 1 162 348 minecraft:yellow_terracotta
fill 1 162 349 1 162 352 minecraft:honeycomb_block
setblock 1 162 353 minecraft:yellow_terracotta
fill 1 162 354 1 165 354 minecraft:honeycomb_block
setblock 1 162 358 minecraft:yellow_terracotta
fill 1 162 359 1 165 359 minecraft:honeycomb_block
setblock 1 162 363 minecraft:yellow_terracotta
fill 2 162 323 2 165 323 minecraft:honeycomb_block
fill 2 162 325 2 163 325 minecraft:honeycomb_block
setblock 2 162 337 minecraft:yellow_terracotta
fill 2 162 338 2 165 338 minecraft:honeycomb_block
setblock 2 162 342 minecraft:yellow_terracotta
fill 2 162 343 2 165 343 minecraft:honeycomb_block
setblock 2 162 346 minecraft:honeycomb_block
setblock 2 162 347 minecraft:yellow_terracotta
fill 2 162 348 2 165 348 minecraft:honeycomb_block
setblock 2 162 352 minecraft:yellow_terracotta
fill 2 162 353 2 165 353 minecraft:honeycomb_block
setblock 2 162 357 minecraft:yellow_terracotta
fill 2 162 358 2 164 358 minecraft:honeycomb_block
setblock 2 162 362 minecraft:yellow_terracotta
fill 2 162 363 2 165 363 minecraft:honeycomb_block
fill 3 162 324 4 162 324 minecraft:honeycomb_block
setblock 3 162 341 minecraft:yellow_terracotta
fill 3 162 342 3 165 342 minecraft:honeycomb_block
setblock 3 162 346 minecraft:yellow_terracotta
fill 3 162 347 3 165 347 minecraft:honeycomb_block
setblock 3 162 350 minecraft:honeycomb_block
fill 3 162 362 3 164 362 minecraft:honeycomb_block
fill 4 162 341 4 163 341 minecraft:honeycomb_block
setblock 4 162 344 minecraft:honeycomb_block
setblock 4 162 345 minecraft:yellow_terracotta
fill 4 162 346 4 165 346 minecraft:honeycomb_block
setblock 6 162 323 minecraft:yellow_terracotta
setblock 6 162 363 minecraft:yellow_terracotta
fill 7 162 323 10 162 323 minecraft:honeycomb_block
fill 7 162 363 7 163 364 minecraft:honeycomb_block
setblock 11 162 323 minecraft:yellow_terracotta
fill 12 162 323 12 165 323 minecraft:honeycomb_block
fill 13 162 363 15 162 363 minecraft:honeycomb_block
setblock 14 162 324 minecraft:honeycomb_block
setblock 15 162 324 minecraft:yellow_terracotta
setblock 16 162 323 minecraft:yellow_terracotta
fill 16 162 324 16 164 325 minecraft:honeycomb_block
setblock 16 162 362 minecraft:honeycomb_block
setblock 16 162 363 minecraft:yellow_terracotta
fill 17 162 323 17 165 323 minecraft:honeycomb_block
fill 17 162 325 18 162 325 minecraft:honeycomb_block
setblock 17 162 362 minecraft:yellow_terracotta
fill 17 162 363 17 165 363 minecraft:honeycomb_block
fill 18 162 362 18 165 362 minecraft:honeycomb_block
setblock 19 162 325 minecraft:yellow_terracotta
fill 19 162 326 22 162 326 minecraft:honeycomb_block
setblock 20 162 324 minecraft:yellow_terracotta
fill 20 162 325 20 165 325 minecraft:honeycomb_block
setblock 21 162 323 minecraft:yellow_terracotta
fill 21 162 324 21 165 324 minecraft:honeycomb_block
fill 21 162 361 22 162 361 minecraft:honeycomb_block
setblock 21 162 363 minecraft:yellow_terracotta
fill 22 162 323 22 165 323 minecraft:honeycomb_block
setblock 22 162 362 minecraft:yellow_terracotta
fill 22 162 363 22 165 363 minecraft:honeycomb_block
setblock 23 162 361 minecraft:yellow_terracotta
fill 23 162 362 23 165 362 minecraft:honeycomb_block
setblock 24 162 325 minecraft:yellow_terracotta
setblock 25 162 324 minecraft:yellow_terracotta
fill 25 162 325 25 165 325 minecraft:honeycomb_block
setblock 26 162 323 minecraft:yellow_terracotta
fill 26 162 324 26 165 324 minecraft:honeycomb_block
setblock 26 162 363 minecraft:yellow_terracotta
fill 27 162 323 27 165 323 minecraft:honeycomb_block
setblock 27 162 362 minecraft:yellow_terracotta
fill 27 162 363 27 165 363 minecraft:honeycomb_block
fill 28 162 362 28 165 362 minecraft:honeycomb_block
setblock 30 162 324 minecraft:yellow_terracotta
fill 30 162 364 30 171 364 minecraft:honeycomb_block
fill 31 162 322 31 171 322 minecraft:honeycomb_block
setblock 31 162 323 minecraft:yellow_terracotta
fill 31 162 324 34 162 324 minecraft:honeycomb_block
setblock 31 162 363 minecraft:yellow_terracotta
fill 32 162 323 32 165 323 minecraft:honeycomb_block
setblock 32 162 362 minecraft:yellow_terracotta
fill 32 162 363 32 165 363 minecraft:honeycomb_block
fill 33 162 362 33 165 362 minecraft:honeycomb_block
fill 34 162 361 34 165 361 minecraft:honeycomb_block
setblock 35 162 324 minecraft:yellow_terracotta
setblock 36 162 323 minecraft:yellow_terracotta
fill 36 162 324 36 165 324 minecraft:honeycomb_block
setblock 36 162 363 minecraft:yellow_terracotta
fill 37 162 323 37 165 323 minecraft:honeycomb_block
setblock 37 162 362 minecraft:yellow_terracotta
fill 37 162 363 37 165 363 minecraft:honeycomb_block
setblock 38 162 325 minecraft:honeycomb_block
setblock 38 162 360 minecraft:honeycomb_block
setblock 38 162 361 minecraft:yellow_terracotta
fill 38 162 362 38 165 362 minecraft:honeycomb_block
setblock 39 162 324 minecraft:honeycomb_block
setblock 39 162 325 minecraft:yellow_terracotta
fill 39 162 341 39 162 344 minecraft:honeycomb_block
setblock 39 162 345 minecraft:yellow_terracotta
fill 39 162 346 39 163 348 minecraft:honeycomb_block
fill 39 162 356 39 165 356 minecraft:honeycomb_block
setblock 39 162 360 minecraft:yellow_terracotta
fill 39 162 361 39 165 361 minecraft:honeycomb_block
setblock 40 162 324 minecraft:yellow_terracotta
fill 40 162 325 40 165 325 minecraft:honeycomb_block
fill 40 162 327 40 163 327 minecraft:honeycomb_block
setblock 40 162 338 minecraft:honeycomb_block
setblock 40 162 339 minecraft:yellow_terracotta
fill 40 162 340 40 165 340 minecraft:honeycomb_block
setblock 40 162 343 minecraft:honeycomb_block
setblock 40 162 344 minecraft:yellow_terracotta
fill 40 162 345 40 165 345 minecraft:honeycomb_block
setblock 40 162 349 minecraft:yellow_terracotta
fill 40 162 350 40 165 350 minecraft:honeycomb_block
setblock 40 162 354 minecraft:yellow_terracotta
fill 40 162 355 40 165 355 minecraft:honeycomb_block
setblock 40 162 359 minecraft:yellow_terracotta
fill 40 162 360 40 165 360 minecraft:honeycomb_block
setblock 41 162 323 minecraft:yellow_terracotta
fill 41 162 324 41 165 324 minecraft:honeycomb_block
setblock 41 162 328 minecraft:yellow_terracotta
fill 41 162 329 41 164 330 minecraft:honeycomb_block
setblock 41 162 332 minecraft:honey_block
fill 41 162 334 41 164 334 minecraft:honeycomb_block
setblock 41 162 338 minecraft:yellow_terracotta
fill 41 162 339 41 165 339 minecraft:honeycomb_block
setblock 41 162 343 minecraft:yellow_terracotta
fill 41 162 344 41 165 344 minecraft:honeycomb_block
setblock 41 162 348 minecraft:yellow_terracotta
fill 41 162 349 41 165 349 minecraft:honeycomb_block
setblock 41 162 353 minecraft:yellow_terracotta
fill 41 162 354 41 165 354 minecraft:honeycomb_block
setblock 41 162 358 minecraft:yellow_terracotta
fill 41 162 359 41 165 359 minecraft:honeycomb_block
setblock 41 162 363 minecraft:yellow_terracotta
fill 0 163 347 0 166 347 minecraft:honeycomb_block
fill 1 163 323 1 166 323 minecraft:honeycomb_block
setblock 1 163 327 minecraft:yellow_terracotta
fill 1 163 328 1 166 328 minecraft:honeycomb_block
setblock 1 163 332 minecraft:yellow_terracotta
fill 1 163 333 1 166 333 minecraft:honeycomb_block
setblock 1 163 337 minecraft:yellow_terracotta
fill 1 163 338 1 166 338 minecraft:honeycomb_block
setblock 1 163 342 minecraft:yellow_terracotta
fill 1 163 343 1 166 343 minecraft:honeycomb_block
setblock 1 163 347 minecraft:yellow_terracotta
fill 1 163 348 1 163 351 minecraft:honeycomb_block
setblock 1 163 352 minecraft:yellow_terracotta
fill 1 163 353 1 166 353 minecraft:honeycomb_block
setblock 1 163 357 minecraft:yellow_terracotta
fill 1 163 358 1 166 358 minecraft:honeycomb_block
setblock 1 163 362 minecraft:yellow_terracotta
fill 1 163 363 1 166 363 minecraft:honeycomb_block
setblock 2 163 326 minecraft:yellow_terracotta
fill 2 163 327 2 166 327 minecraft:honeycomb_block
setblock 2 163 336 minecraft:yellow_terracotta
fill 2 163 337 2 165 337 minecraft:honeycomb_block
setblock 2 163 341 minecraft:yellow_terracotta
fill 2 163 342 2 166 342 minecraft:honeycomb_block
setblock 2 163 346 minecraft:yellow_terracotta
fill 2 163 347 2 166 347 minecraft:honeycomb_block
setblock 2 163 351 minecraft:yellow_terracotta
fill 2 163 352 2 166 352 minecraft:honeycomb_block
setblock 2 163 356 minecraft:yellow_terracotta
fill 2 163 357 2 164 357 minecraft:honeycomb_block
setblock 2 163 361 minecraft:yellow_terracotta
fill 2 163 362 2 165 362 minecraft:honeycomb_block
setblock 3 163 324 minecraft:honeycomb_block
setblock 3 163 340 minecraft:yellow_terracotta
fill 3 163 341 3 166 341 minecraft:honeycomb_block
setblock 3 163 345 minecraft:yellow_terracotta
fill 3 163 346 3 166 346 minecraft:honeycomb_block
setblock 3 163 350 minecraft:yellow_terracotta
setblock 4 163 324 minecraft:yellow_terracotta
setblock 4 163 344 minecraft:yellow_terracotta
fill 4 163 345 4 165 345 minecraft:honeycomb_block
setblock 5 163 323 minecraft:yellow_terracotta
setblock 5 163 363 minecraft:yellow_terracotta
fill 6 163 323 9 163 323 minecraft:honeycomb_block
fill 6 163 363 6 164 363 minecraft:honeycomb_block
setblock 10 163 323 minecraft:yellow_terracotta
fill 11 163 323 11 166 323 minecraft:honeycomb_block
fill 12 163 324 13 163 324 minecraft:honeycomb_block
fill 12 163 363 14 163 363 minecraft:honeycomb_block
setblock 14 163 323 minecraft:honeycomb_block
setblock 14 163 324 minecraft:yellow_terracotta
setblock 15 163 323 minecraft:yellow_terracotta
fill 15 163 324 15 165 325 minecraft:honeycomb_block
setblock 15 163 363 minecraft:yellow_terracotta
fill 16 163 323 16 166 323 minecraft:honeycomb_block
setblock 16 163 362 minecraft:yellow_terracotta
fill 16 163 363 16 166 363 minecraft:honeycomb_block
setblock 17 163 325 minecraft:honeycomb_block
fill 17 163 362 17 166 362 minecraft:honeycomb_block
setblock 18 163 325 minecraft:yellow_terracotta
fill 18 163 326 21 163 326 minecraft:honeycomb_block
setblock 19 163 324 minecraft:yellow_terracotta
fill 19 163 325 19 166 325 minecraft:honeycomb_block
setblock 20 163 323 minecraft:yellow_terracotta
fill 20 163 324 20 166 324 minecraft:honeycomb_block
setblock 20 163 363 minecraft:yellow_terracotta
fill 21 163 323 21 166 323 minecraft:honeycomb_block
setblock 21 163 361 minecraft:honeycomb_block
setblock 21 163 362 minecraft:yellow_terracotta
fill 21 163 363 21 166 363 minecraft:honeycomb_block
setblock 22 163 326 minecraft:yellow_terracotta
setblock 22 163 361 minecraft:yellow_terracotta
fill 22 163 362 22 166 362 minecraft:honeycomb_block
setblock 23 163 325 minecraft:yellow_terracotta
fill 23 163 326 23 166 326 minecraft:honeycomb_block
setblock 24 163 324 minecraft:yellow_terracotta
fill 24 163 325 24 166 325 minecraft:honeycomb_block
setblock 25 163 323 minecraft:yellow_terracotta
fill 25 163 324 25 166 324 minecraft:honeycomb_block
setblock 25 163 363 minecraft:yellow_terracotta
setblock 26 163 322 minecraft:yellow_terracotta
fill 26 163 323 26 166 323 minecraft:honeycomb_block
setblock 26 163 362 minecraft:yellow_terracotta
fill 26 163 363 26 166 363 minecraft:honeycomb_block
setblock 27 163 325 minecraft:honeycomb_block
fill 27 163 333 27 169 334 minecraft:brown_terracotta
fill 27 163 362 27 165 362 minecraft:honeycomb_block
setblock 28 163 324 minecraft:honeycomb_block
setblock 29 163 324 minecraft:yellow_terracotta
setblock 30 163 323 minecraft:yellow_terracotta
fill 30 163 324 33 163 324 minecraft:honeycomb_block
setblock 30 163 362 minecraft:honeycomb_block
setblock 30 163 363 minecraft:yellow_terracotta
fill 31 163 323 31 166 323 minecraft:honeycomb_block
setblock 31 163 362 minecraft:yellow_terracotta
fill 31 163 363 31 166 363 minecraft:honeycomb_block
fill 32 163 362 32 166 362 minecraft:honeycomb_block
setblock 34 163 324 minecraft:yellow_terracotta
setblock 35 163 323 minecraft:yellow_terracotta
fill 35 163 324 35 166 324 minecraft:honeycomb_block
setblock 35 163 363 minecraft:yellow_terracotta
fill 36 163 323 36 166 323 minecraft:honeycomb_block
fill 36 163 325 37 163 325 minecraft:honeycomb_block
setblock 36 163 362 minecraft:yellow_terracotta
fill 36 163 363 36 166 363 minecraft:honeycomb_block
setblock 37 163 361 minecraft:yellow_terracotta
fill 37 163 362 37 166 362 minecraft:honeycomb_block
setblock 38 163 325 minecraft:yellow_terracotta
setblock 38 163 360 minecraft:yellow_terracotta
fill 38 163 361 38 166 361 minecraft:honeycomb_block
setblock 39 163 324 minecraft:yellow_terracotta
fill 39 163 325 39 166 325 minecraft:honeycomb_block
fill 39 163 341 39 163 343 minecraft:honeycomb_block
setblock 39 163 344 minecraft:yellow_terracotta
fill 39 163 345 39 166 345 minecraft:honeycomb_block
setblock 39 163 349 minecraft:yellow_terracotta
fill 39 163 350 39 164 352 minecraft:honeycomb_block
fill 39 163 355 39 166 355 minecraft:honeycomb_block
setblock 39 163 359 minecraft:yellow_terracotta
fill 39 163 360 39 166 360 minecraft:honeycomb_block
setblock 40 163 323 minecraft:yellow_terracotta
fill 40 163 324 40 166 324 minecraft:honeycomb_block
setblock 40 163 328 minecraft:yellow_terracotta
setblock 40 163 338 minecraft:yellow_terracotta
fill 40 163 339 40 165 339 minecraft:honeycomb_block
setblock 40 163 343 minecraft:yellow_terracotta
fill 40 163 344 40 166 344 minecraft:honeycomb_block
setblock 40 163 347 minecraft:honeycomb_block
setblock 40 163 348 minecraft:yellow_terracotta
fill 40 163 349 40 166 349 minecraft:honeycomb_block
setblock 40 163 353 minecraft:yellow_terracotta
fill 40 163 354 40 166 354 minecraft:honeycomb_block
setblock 40 163 358 minecraft:yellow_terracotta
fill 40 163 359 40 166 359 minecraft:honeycomb_block
setblock 40 163 363 minecraft:yellow_terracotta
fill 41 163 323 41 166 323 minecraft:honeycomb_block
setblock 41 163 326 minecraft:honeycomb_block
setblock 41 163 327 minecraft:yellow_terracotta
fill 41 163 328 41 166 328 minecraft:honeycomb_block
setblock 41 163 331 minecraft:honeycomb_block
setblock 41 163 337 minecraft:yellow_terracotta
fill 41 163 338 41 166 338 minecraft:honeycomb_block
setblock 41 163 342 minecraft:yellow_terracotta
fill 41 163 343 41 166 343 minecraft:honeycomb_block
setblock 41 163 347 minecraft:yellow_terracotta
fill 41 163 348 41 166 348 minecraft:honeycomb_block
setblock 41 163 352 minecraft:yellow_terracotta
fill 41 163 353 41 166 353 minecraft:honeycomb_block
setblock 41 163 357 minecraft:yellow_terracotta
fill 41 163 358 41 166 358 minecraft:honeycomb_block
setblock 41 163 362 minecraft:yellow_terracotta
fill 41 163 363 41 166 363 minecraft:honeycomb_block
setblock 0 164 338 minecraft:yellow_concrete
fill 0 164 346 0 205 346 minecraft:honeycomb_block
setblock 0 164 354 minecraft:yellow_terracotta
setblock 1 164 326 minecraft:yellow_terracotta
fill 1 164 327 1 167 327 minecraft:honeycomb_block
fill 1 164 329 1 164 330 minecraft:honeycomb_block
setblock 1 164 331 minecraft:yellow_terracotta
fill 1 164 332 1 167 332 minecraft:honeycomb_block
setblock 1 164 335 minecraft:honeycomb_block
setblock 1 164 336 minecraft:yellow_terracotta
fill 1 164 337 1 167 337 minecraft:honeycomb_block
setblock 1 164 341 minecraft:yellow_terracotta
fill 1 164 342 1 167 342 minecraft:honeycomb_block
setblock 1 164 346 minecraft:yellow_terracotta
fill 1 164 347 1 164 350 minecraft:honeycomb_block
setblock 1 164 351 minecraft:yellow_terracotta
fill 1 164 352 1 167 352 minecraft:honeycomb_block
setblock 1 164 356 minecraft:yellow_terracotta
fill 1 164 357 1 167 357 minecraft:honeycomb_block
setblock 1 164 361 minecraft:yellow_terracotta
fill 1 164 362 1 167 362 minecraft:honeycomb_block
setblock 2 164 325 minecraft:yellow_terracotta
fill 2 164 326 2 167 326 minecraft:honeycomb_block
setblock 2 164 336 minecraft:honeycomb_block
setblock 2 164 340 minecraft:yellow_terracotta
fill 2 164 341 2 167 341 minecraft:honeycomb_block
setblock 2 164 345 minecraft:yellow_terracotta
fill 2 164 346 2 167 346 minecraft:honeycomb_block
setblock 2 164 349 minecraft:honeycomb_block
setblock 2 164 350 minecraft:yellow_terracotta
fill 2 164 351 2 167 351 minecraft:honeycomb_block
setblock 2 164 355 minecraft:yellow_terracotta
setblock 2 164 356 minecraft:honeycomb_block
setblock 2 164 360 minecraft:yellow_terracotta
fill 2 164 361 2 165 361 minecraft:honeycomb_block
setblock 3 164 324 minecraft:yellow_terracotta
setblock 3 164 339 minecraft:yellow_terracotta
fill 3 164 340 3 165 340 minecraft:honeycomb_block
setblock 3 164 344 minecraft:yellow_terracotta
fill 3 164 345 3 167 345 minecraft:honeycomb_block
setblock 3 164 349 minecraft:yellow_terracotta
fill 3 164 350 3 166 350 minecraft:honeycomb_block
setblock 4 164 323 minecraft:yellow_terracotta
fill 4 164 324 4 165 324 minecraft:honeycomb_block
setblock 4 164 343 minecraft:yellow_terracotta
fill 4 164 344 4 165 344 minecraft:honeycomb_block
setblock 4 164 363 minecraft:yellow_terracotta
fill 5 164 323 8 164 323 minecraft:honeycomb_block
fill 5 164 363 5 165 363 minecraft:honeycomb_block
fill 7 164 364 7 173 364 minecraft:honeycomb_block
setblock 9 164 323 minecraft:yellow_terracotta
fill 10 164 323 10 167 323 minecraft:honeycomb_block
fill 11 164 324 12 164 324 minecraft:honeycomb_block
fill 12 164 363 13 164 363 minecraft:honeycomb_block
setblock 13 164 324 minecraft:yellow_terracotta
setblock 14 164 323 minecraft:yellow_terracotta
fill 14 164 324 14 166 325 minecraft:honeycomb_block
setblock 14 164 363 minecraft:yellow_terracotta
fill 15 164 323 15 167 323 minecraft:honeycomb_block
fill 15 164 363 15 167 363 minecraft:honeycomb_block
setblock 16 164 326 minecraft:yellow_terracotta
fill 16 164 362 16 166 362 minecraft:honeycomb_block
setblock 17 164 325 minecraft:yellow_terracotta
fill 17 164 326 20 164 326 minecraft:honeycomb_block
setblock 18 164 324 minecraft:yellow_terracotta
fill 18 164 325 18 167 325 minecraft:honeycomb_block
setblock 19 164 323 minecraft:yellow_terracotta
fill 19 164 324 19 167 324 minecraft:honeycomb_block
setblock 19 164 363 minecraft:yellow_terracotta
fill 20 164 323 20 167 323 minecraft:honeycomb_block
setblock 20 164 362 minecraft:yellow_terracotta
fill 20 164 363 20 167 363 minecraft:honeycomb_block
setblock 21 164 326 minecraft:yellow_terracotta
fill 21 164 362 21 167 362 minecraft:honeycomb_block
setblock 22 164 325 minecraft:yellow_terracotta
fill 22 164 326 22 167 326 minecraft:honeycomb_block
setblock 23 164 324 minecraft:yellow_terracotta
fill 23 164 325 23 167 325 minecraft:honeycomb_block
setblock 24 164 323 minecraft:yellow_terracotta
fill 24 164 324 24 167 324 minecraft:honeycomb_block
setblock 24 164 363 minecraft:yellow_terracotta
fill 25 164 323 25 167 323 minecraft:honeycomb_block
setblock 25 164 362 minecraft:yellow_terracotta
fill 25 164 363 25 167 363 minecraft:honeycomb_block
fill 26 164 322 26 209 322 minecraft:honeycomb_block
fill 26 164 362 26 165 362 minecraft:honeycomb_block
setblock 27 164 325 minecraft:yellow_terracotta
setblock 28 164 324 minecraft:yellow_terracotta
setblock 29 164 323 minecraft:yellow_terracotta
fill 29 164 324 32 164 324 minecraft:honeycomb_block
setblock 29 164 363 minecraft:yellow_terracotta
fill 30 164 323 30 167 323 minecraft:honeycomb_block
setblock 30 164 362 minecraft:yellow_terracotta
fill 30 164 363 30 167 363 minecraft:honeycomb_block
fill 31 164 362 31 167 362 minecraft:honeycomb_block
setblock 33 164 324 minecraft:yellow_terracotta
setblock 34 164 323 minecraft:yellow_terracotta
fill 34 164 324 34 166 325 minecraft:honeycomb_block
setblock 34 164 363 minecraft:yellow_terracotta
fill 35 164 323 35 167 323 minecraft:honeycomb_block
fill 35 164 325 36 164 325 minecraft:honeycomb_block
setblock 35 164 362 minecraft:yellow_terracotta
fill 35 164 363 35 167 363 minecraft:honeycomb_block
setblock 36 164 361 minecraft:yellow_terracotta
fill 36 164 362 36 167 362 minecraft:honeycomb_block
setblock 37 164 325 minecraft:yellow_terracotta
fill 37 164 361 37 167 361 minecraft:honeycomb_block
setblock 38 164 324 minecraft:yellow_terracotta
fill 38 164 325 38 167 325 minecraft:honeycomb_block
setblock 38 164 360 minecraft:honeycomb_block
setblock 39 164 323 minecraft:yellow_terracotta
fill 39 164 324 39 167 324 minecraft:honeycomb_block
fill 39 164 326 39 165 326 minecraft:honeycomb_block
fill 39 164 341 39 164 342 minecraft:honeycomb_block
setblock 39 164 343 minecraft:yellow_terracotta
fill 39 164 344 39 167 344 minecraft:honeycomb_block
fill 39 164 346 39 164 347 minecraft:honeycomb_block
setblock 39 164 348 minecraft:yellow_terracotta
fill 39 164 349 39 167 349 minecraft:honeycomb_block
setblock 39 164 353 minecraft:yellow_terracotta
fill 39 164 354 39 167 354 minecraft:honeycomb_block
setblock 39 164 358 minecraft:yellow_terracotta
fill 39 164 359 39 166 359 minecraft:honeycomb_block
setblock 39 164 363 minecraft:yellow_terracotta
fill 40 164 323 40 167 323 minecraft:honeycomb_block
setblock 40 164 327 minecraft:yellow_terracotta
fill 40 164 328 40 167 328 minecraft:honeycomb_block
setblock 40 164 338 minecraft:honeycomb_block
setblock 40 164 342 minecraft:yellow_terracotta
fill 40 164 343 40 167 343 minecraft:honeycomb_block
setblock 40 164 347 minecraft:yellow_terracotta
fill 40 164 348 40 167 348 minecraft:honeycomb_block
setblock 40 164 351 minecraft:honeycomb_block
setblock 40 164 352 minecraft:yellow_terracotta
fill 40 164 353 40 167 353 minecraft:honeycomb_block
setblock 40 164 357 minecraft:yellow_terracotta
fill 40 164 358 40 167 358 minecraft:honeycomb_block
setblock 40 164 362 minecraft:yellow_terracotta
fill 40 164 363 40 167 363 minecraft:honeycomb_block
setblock 41 164 326 minecraft:yellow_terracotta
fill 41 164 327 41 167 327 minecraft:honeycomb_block
setblock 41 164 331 minecraft:yellow_terracotta
setblock 41 164 332 minecraft:honeycomb_block
setblock 41 164 336 minecraft:yellow_terracotta
fill 41 164 337 41 166 337 minecraft:honeycomb_block
setblock 41 164 341 minecraft:yellow_terracotta
fill 41 164 342 41 167 342 minecraft:honeycomb_block
setblock 41 164 346 minecraft:yellow_terracotta
fill 41 164 347 41 167 347 minecraft:honeycomb_block
setblock 41 164 351 minecraft:yellow_terracotta
fill 41 164 352 41 167 352 minecraft:honeycomb_block
setblock 41 164 356 minecraft:yellow_terracotta
fill 41 164 357 41 167 357 minecraft:honeycomb_block
setblock 41 164 361 minecraft:yellow_terracotta
fill 41 164 362 41 167 362 minecraft:honeycomb_block
fill 0 165 338 0 200 338 minecraft:honeycomb_block
fill 0 165 354 0 169 354 minecraft:honeycomb_block
setblock 1 165 325 minecraft:yellow_terracotta
fill 1 165 326 1 168 326 minecraft:honeycomb_block
setblock 1 165 329 minecraft:honeycomb_block
setblock 1 165 330 minecraft:yellow_terracotta
fill 1 165 331 1 168 331 minecraft:honeycomb_block
setblock 1 165 335 minecraft:yellow_terracotta
fill 1 165 336 1 168 336 minecraft:honeycomb_block
setblock 1 165 340 minecraft:yellow_terracotta
fill 1 165 341 1 168 341 minecraft:honeycomb_block
setblock 1 165 345 minecraft:yellow_terracotta
fill 1 165 346 1 165 349 minecraft:honeycomb_block
setblock 1 165 350 minecraft:yellow_terracotta
fill 1 165 351 1 168 351 minecraft:honeycomb_block
setblock 1 165 355 minecraft:yellow_terracotta
fill 1 165 356 1 167 356 minecraft:honeycomb_block
setblock 1 165 360 minecraft:yellow_terracotta
fill 1 165 361 1 167 361 minecraft:honeycomb_block
setblock 2 165 324 minecraft:yellow_terracotta
fill 2 165 325 2 167 325 minecraft:honeycomb_block
setblock 2 165 328 minecraft:honeycomb_block
setblock 2 165 339 minecraft:yellow_terracotta
fill 2 165 340 2 167 340 minecraft:honeycomb_block
setblock 2 165 344 minecraft:yellow_terracotta
fill 2 165 345 2 168 345 minecraft:honeycomb_block
setblock 2 165 349 minecraft:yellow_terracotta
fill 2 165 350 2 168 350 minecraft:honeycomb_block
setblock 2 165 354 minecraft:yellow_terracotta
setblock 3 165 323 minecraft:yellow_terracotta
fill 3 165 324 3 166 324 minecraft:honeycomb_block
setblock 3 165 325 minecraft:light[level=12]
setblock 3 165 332 minecraft:light[level=12]
setblock 3 165 339 minecraft:light[level=12]
setblock 3 165 343 minecraft:yellow_terracotta
fill 3 165 344 3 167 344 minecraft:honeycomb_block
setblock 3 165 348 minecraft:yellow_terracotta
fill 3 165 349 3 167 349 minecraft:honeycomb_block
setblock 3 165 353 minecraft:light[level=12]
setblock 3 165 360 minecraft:light[level=12]
setblock 3 165 363 minecraft:yellow_terracotta
fill 4 165 323 7 165 323 minecraft:honeycomb_block
fill 4 165 363 4 166 363 minecraft:honeycomb_block
fill 5 165 322 5 171 322 minecraft:honeycomb_block
setblock 6 165 322 minecraft:yellow_concrete
fill 7 165 322 7 239 322 minecraft:honeycomb_block
setblock 8 165 323 minecraft:yellow_terracotta
fill 9 165 323 9 168 323 minecraft:honeycomb_block
setblock 10 165 325 minecraft:light[level=12]
setblock 10 165 332 minecraft:light[level=12]
setblock 10 165 339 minecraft:light[level=12]
setblock 10 165 346 minecraft:light[level=12]
setblock 10 165 353 minecraft:light[level=12]
setblock 10 165 360 minecraft:light[level=12]
setblock 10 165 363 minecraft:honey_block
setblock 11 165 324 minecraft:honeycomb_block
setblock 12 165 324 minecraft:yellow_terracotta
setblock 12 165 363 minecraft:honeycomb_block
setblock 13 165 323 minecraft:yellow_terracotta
fill 13 165 324 13 167 325 minecraft:honeycomb_block
setblock 13 165 363 minecraft:yellow_terracotta
fill 14 165 323 14 168 323 minecraft:honeycomb_block
fill 14 165 363 14 168 363 minecraft:honeycomb_block
setblock 15 165 326 minecraft:yellow_terracotta
setblock 16 165 324 minecraft:honeycomb_block
setblock 16 165 325 minecraft:yellow_terracotta
fill 16 165 326 19 165 326 minecraft:honeycomb_block
setblock 17 165 324 minecraft:yellow_terracotta
fill 17 165 325 17 168 325 minecraft:honeycomb_block
setblock 17 165 332 minecraft:light[level=12]
setblock 17 165 339 minecraft:light[level=12]
setblock 17 165 346 minecraft:light[level=12]
setblock 17 165 353 minecraft:light[level=12]
setblock 17 165 360 minecraft:light[level=12]
setblock 18 165 323 minecraft:yellow_terracotta
fill 18 165 324 18 168 324 minecraft:honeycomb_block
setblock 18 165 363 minecraft:yellow_terracotta
fill 19 165 323 19 168 323 minecraft:honeycomb_block
setblock 19 165 362 minecraft:yellow_terracotta
fill 19 165 363 19 168 363 minecraft:honeycomb_block
setblock 20 165 326 minecraft:yellow_terracotta
fill 20 165 362 20 167 362 minecraft:honeycomb_block
setblock 21 165 325 minecraft:yellow_terracotta
fill 21 165 326 21 168 326 minecraft:honeycomb_block
setblock 22 165 324 minecraft:yellow_terracotta
fill 22 165 325 22 168 325 minecraft:honeycomb_block
setblock 23 165 323 minecraft:yellow_terracotta
fill 23 165 324 23 168 324 minecraft:honeycomb_block
setblock 23 165 363 minecraft:yellow_terracotta
fill 24 165 323 24 168 323 minecraft:honeycomb_block
setblock 24 165 332 minecraft:light[level=12]
setblock 24 165 339 minecraft:light[level=12]
setblock 24 165 346 minecraft:light[level=12]
setblock 24 165 353 minecraft:light[level=12]
setblock 24 165 360 minecraft:light[level=12]
setblock 24 165 362 minecraft:yellow_terracotta
fill 24 165 363 24 168 363 minecraft:honeycomb_block
setblock 25 165 362 minecraft:honeycomb_block
setblock 26 165 325 minecraft:yellow_terracotta
fill 26 165 333 26 169 334 minecraft:brown_terracotta
setblock 27 165 324 minecraft:yellow_terracotta
setblock 27 165 325 minecraft:honeycomb_block
setblock 28 165 323 minecraft:yellow_terracotta
fill 28 165 324 31 165 324 minecraft:honeycomb_block
fill 28 165 333 28 169 334 minecraft:brown_terracotta
setblock 28 165 363 minecraft:yellow_terracotta
fill 29 165 323 29 168 323 minecraft:honeycomb_block
setblock 29 165 362 minecraft:yellow_terracotta
fill 29 165 363 29 168 363 minecraft:honeycomb_block
fill 30 165 362 30 166 362 minecraft:honeycomb_block
setblock 31 165 325 minecraft:light[level=12]
setblock 31 165 332 minecraft:light[level=12]
setblock 31 165 339 minecraft:light[level=12]
setblock 31 165 346 minecraft:light[level=12]
setblock 31 165 353 minecraft:light[level=12]
setblock 31 165 360 minecraft:light[level=12]
setblock 32 165 324 minecraft:yellow_terracotta
fill 32 165 349 33 166 349 minecraft:honey_block
setblock 33 165 323 minecraft:yellow_terracotta
fill 33 165 324 33 166 325 minecraft:honeycomb_block
setblock 33 165 363 minecraft:yellow_terracotta
fill 34 165 323 34 168 323 minecraft:honeycomb_block
setblock 34 165 362 minecraft:yellow_terracotta
fill 34 165 363 34 168 363 minecraft:honeycomb_block
setblock 35 165 325 minecraft:honeycomb_block
setblock 35 165 361 minecraft:yellow_terracotta
fill 35 165 362 35 168 362 minecraft:honeycomb_block
setblock 36 165 325 minecraft:yellow_terracotta
fill 36 165 361 36 167 361 minecraft:honeycomb_block
setblock 37 165 324 minecraft:yellow_terracotta
fill 37 165 325 37 168 325 minecraft:honeycomb_block
setblock 38 165 323 minecraft:yellow_terracotta
fill 38 165 324 38 168 324 minecraft:honeycomb_block
setblock 38 165 332 minecraft:light[level=12]
setblock 38 165 339 minecraft:light[level=12]
fill 38 165 345 38 165 347 minecraft:honeycomb_block
setblock 38 165 348 minecraft:yellow_terracotta
setblock 38 165 353 minecraft:light[level=12]
setblock 38 165 360 minecraft:light[level=12]
setblock 38 165 363 minecraft:yellow_terracotta
fill 39 165 323 39 168 323 minecraft:honeycomb_block
setblock 39 165 341 minecraft:honeycomb_block
setblock 39 165 342 minecraft:yellow_terracotta
fill 39 165 343 39 167 343 minecraft:honeycomb_block
setblock 39 165 346 minecraft:honeycomb_block
setblock 39 165 347 minecraft:yellow_terracotta
fill 39 165 348 39 168 348 minecraft:honeycomb_block
fill 39 165 350 39 165 351 minecraft:honeycomb_block
setblock 39 165 352 minecraft:yellow_terracotta
fill 39 165 353 39 168 353 minecraft:honeycomb_block
setblock 39 165 357 minecraft:yellow_terracotta
fill 39 165 358 39 166 358 minecraft:honeycomb_block
setblock 39 165 362 minecraft:yellow_terracotta
fill 39 165 363 39 168 363 minecraft:honeycomb_block
setblock 40 165 326 minecraft:yellow_terracotta
fill 40 165 327 40 168 327 minecraft:honeycomb_block
fill 40 165 329 41 165 329 minecraft:honeycomb_block
setblock 40 165 341 minecraft:yellow_terracotta
fill 40 165 342 40 168 342 minecraft:honeycomb_block
setblock 40 165 346 minecraft:yellow_terracotta
fill 40 165 347 40 168 347 minecraft:honeycomb_block
setblock 40 165 351 minecraft:yellow_terracotta
fill 40 165 352 40 168 352 minecraft:honeycomb_block
setblock 40 165 356 minecraft:yellow_terracotta
fill 40 165 357 40 168 357 minecraft:honeycomb_block
setblock 40 165 361 minecraft:yellow_terracotta
fill 40 165 362 40 168 362 minecraft:honeycomb_block
setblock 41 165 325 minecraft:yellow_terracotta
fill 41 165 326 41 168 326 minecraft:honeycomb_block
setblock 41 165 330 minecraft:yellow_terracotta
fill 41 165 331 41 167 331 minecraft:honeycomb_block
setblock 41 165 333 minecraft:honey_block
setblock 41 165 336 minecraft:honeycomb_block
setblock 41 165 340 minecraft:yellow_terracotta
fill 41 165 341 41 168 341 minecraft:honeycomb_block
setblock 41 165 345 minecraft:yellow_terracotta
fill 41 165 346 41 168 346 minecraft:honeycomb_block
setblock 41 165 350 minecraft:yellow_terracotta
fill 41 165 351 41 168 351 minecraft:honeycomb_block
setblock 41 165 355 minecraft:yellow_terracotta
fill 41 165 356 41 168 356 minecraft:honeycomb_block
setblock 41 165 360 minecraft:yellow_terracotta
fill 41 165 361 41 168 361 minecraft:honeycomb_block
setblock 0 166 335 minecraft:yellow_concrete
setblock 1 166 324 minecraft:yellow_terracotta
fill 1 166 325 1 169 325 minecraft:honeycomb_block
setblock 1 166 329 minecraft:yellow_terracotta
fill 1 166 330 1 169 330 minecraft:honeycomb_block
setblock 1 166 334 minecraft:yellow_terracotta
fill 1 166 335 1 168 335 minecraft:honeycomb_block
setblock 1 166 339 minecraft:yellow_terracotta
fill 1 166 340 1 169 340 minecraft:honeycomb_block
setblock 1 166 344 minecraft:yellow_terracotta
fill 1 166 345 1 166 348 minecraft:honeycomb_block
setblock 1 166 349 minecraft:yellow_terracotta
fill 1 166 350 1 169 350 minecraft:honeycomb_block
setblock 1 166 354 minecraft:yellow_terracotta
fill 1 166 355 1 169 355 minecraft:honeycomb_block
setblock 1 166 359 minecraft:yellow_terracotta
fill 1 166 360 1 167 360 minecraft:honeycomb_block
setblock 2 166 323 minecraft:yellow_terracotta
fill 2 166 324 2 167 324 minecraft:honeycomb_block
setblock 2 166 328 minecraft:yellow_terracotta
setblock 2 166 338 minecraft:yellow_terracotta
fill 2 166 339 2 167 339 minecraft:honeycomb_block
setblock 2 166 343 minecraft:yellow_terracotta
fill 2 166 344 2 169 344 minecraft:honeycomb_block
setblock 2 166 348 minecraft:yellow_terracotta
fill 2 166 349 2 169 349 minecraft:honeycomb_block
setblock 2 166 353 minecraft:yellow_terracotta
setblock 2 166 363 minecraft:yellow_terracotta
fill 3 166 323 6 166 323 minecraft:honeycomb_block
setblock 3 166 342 minecraft:yellow_terracotta
fill 3 166 343 3 167 343 minecraft:honeycomb_block
setblock 3 166 347 minecraft:yellow_terracotta
fill 3 166 348 3 168 348 minecraft:honeycomb_block
setblock 3 166 363 minecraft:honeycomb_block
fill 6 166 322 6 260 322 minecraft:honeycomb_block
setblock 7 166 323 minecraft:yellow_terracotta
fill 8 166 323 8 167 323 minecraft:honeycomb_block
setblock 10 166 324 minecraft:honeycomb_block
setblock 11 166 324 minecraft:yellow_terracotta
setblock 12 166 323 minecraft:yellow_terracotta
fill 12 166 324 12 169 324 minecraft:honeycomb_block
fill 13 166 323 13 169 323 minecraft:honeycomb_block
fill 13 166 363 13 168 363 minecraft:honeycomb_block
setblock 15 166 324 minecraft:honeycomb_block
setblock 15 166 325 minecraft:yellow_terracotta
fill 15 166 326 18 166 326 minecraft:honeycomb_block
setblock 16 166 324 minecraft:yellow_terracotta
fill 16 166 325 16 169 325 minecraft:honeycomb_block
setblock 17 166 323 minecraft:yellow_terracotta
fill 17 166 324 17 169 324 minecraft:honeycomb_block
setblock 17 166 363 minecraft:yellow_terracotta
fill 18 166 323 18 169 323 minecraft:honeycomb_block
setblock 18 166 362 minecraft:yellow_terracotta
fill 18 166 363 18 169 363 minecraft:honeycomb_block
setblock 19 166 326 minecraft:yellow_terracotta
fill 19 166 362 19 167 362 minecraft:honeycomb_block
setblock 20 166 325 minecraft:yellow_terracotta
fill 20 166 326 20 169 326 minecraft:honeycomb_block
setblock 21 166 324 minecraft:yellow_terracotta
fill 21 166 325 21 169 325 minecraft:honeycomb_block
setblock 22 166 323 minecraft:yellow_terracotta
fill 22 166 324 22 169 324 minecraft:honeycomb_block
setblock 22 166 363 minecraft:yellow_terracotta
fill 23 166 323 23 169 323 minecraft:honeycomb_block
setblock 23 166 362 minecraft:yellow_terracotta
fill 23 166 363 23 169 363 minecraft:honeycomb_block
setblock 24 166 362 minecraft:honeycomb_block
setblock 25 166 325 minecraft:yellow_terracotta
setblock 26 166 324 minecraft:yellow_terracotta
setblock 26 166 325 minecraft:honeycomb_block
setblock 26 166 364 minecraft:yellow_concrete
setblock 27 166 323 minecraft:yellow_terracotta
fill 27 166 324 30 166 324 minecraft:honeycomb_block
fill 27 166 332 27 169 332 minecraft:brown_terracotta
fill 27 166 335 27 169 335 minecraft:brown_terracotta
setblock 27 166 363 minecraft:yellow_terracotta
fill 28 166 323 28 169 323 minecraft:honeycomb_block
fill 28 166 363 28 169 363 minecraft:honeycomb_block
setblock 31 166 324 minecraft:yellow_terracotta
setblock 32 166 323 minecraft:yellow_terracotta
fill 32 166 324 32 169 324 minecraft:honeycomb_block
setblock 32 166 363 minecraft:yellow_terracotta
fill 33 166 323 33 169 323 minecraft:honeycomb_block
setblock 33 166 362 minecraft:yellow_terracotta
fill 33 166 363 33 169 363 minecraft:honeycomb_block
setblock 34 166 361 minecraft:yellow_terracotta
fill 34 166 362 34 169 362 minecraft:honeycomb_block
setblock 35 166 325 minecraft:yellow_terracotta
fill 35 166 361 35 167 361 minecraft:honeycomb_block
setblock 36 166 324 minecraft:yellow_terracotta
fill 36 166 325 36 168 325 minecraft:honeycomb_block
setblock 37 166 323 minecraft:yellow_terracotta
fill 37 166 324 37 169 324 minecraft:honeycomb_block
setblock 37 166 363 minecraft:yellow_terracotta
fill 38 166 323 38 169 323 minecraft:honeycomb_block
fill 38 166 345 38 166 346 minecraft:honeycomb_block
setblock 38 166 347 minecraft:yellow_terracotta
fill 38 166 348 38 167 350 minecraft:honeycomb_block
setblock 38 166 362 minecraft:yellow_terracotta
fill 38 166 363 38 169 363 minecraft:honeycomb_block
setblock 39 166 326 minecraft:yellow_terracotta
setblock 39 166 342 minecraft:honeycomb_block
setblock 39 166 346 minecraft:yellow_terracotta
fill 39 166 347 39 169 347 minecraft:honeycomb_block
setblock 39 166 350 minecraft:honeycomb_block
setblock 39 166 351 minecraft:yellow_terracotta
fill 39 166 352 39 169 352 minecraft:honeycomb_block
setblock 39 166 356 minecraft:yellow_terracotta
setblock 39 166 357 minecraft:honeycomb_block
setblock 39 166 361 minecraft:yellow_terracotta
fill 39 166 362 39 169 362 minecraft:honeycomb_block
setblock 40 166 325 minecraft:yellow_terracotta
fill 40 166 326 40 168 326 minecraft:honeycomb_block
setblock 40 166 329 minecraft:honeycomb_block
setblock 40 166 340 minecraft:yellow_terracotta
fill 40 166 341 40 167 341 minecraft:honeycomb_block
setblock 40 166 345 minecraft:yellow_terracotta
fill 40 166 346 40 169 346 minecraft:honeycomb_block
setblock 40 166 350 minecraft:yellow_terracotta
fill 40 166 351 40 169 351 minecraft:honeycomb_block
setblock 40 166 355 minecraft:yellow_terracotta
fill 40 166 356 40 169 356 minecraft:honeycomb_block
setblock 40 166 360 minecraft:yellow_terracotta
fill 40 166 361 40 168 361 minecraft:honeycomb_block
setblock 41 166 324 minecraft:yellow_terracotta
fill 41 166 325 41 169 325 minecraft:honeycomb_block
setblock 41 166 329 minecraft:yellow_terracotta
fill 41 166 330 41 169 330 minecraft:honeycomb_block
setblock 41 166 339 minecraft:yellow_terracotta
fill 41 166 340 41 168 340 minecraft:honeycomb_block
setblock 41 166 344 minecraft:yellow_terracotta
fill 41 166 345 41 169 345 minecraft:honeycomb_block
setblock 41 166 349 minecraft:yellow_terracotta
fill 41 166 350 41 169 350 minecraft:honeycomb_block
setblock 41 166 354 minecraft:yellow_terracotta
fill 41 166 355 41 169 355 minecraft:honeycomb_block
setblock 41 166 359 minecraft:yellow_terracotta
fill 41 166 360 41 169 360 minecraft:honeycomb_block
setblock 0 167 325 minecraft:yellow_concrete
fill 0 167 326 0 308 326 minecraft:honeycomb_block
setblock 0 167 330 minecraft:orange_terracotta
setblock 0 167 334 minecraft:orange_terracotta
fill 0 167 335 0 204 335 minecraft:honeycomb_block
setblock 0 167 347 minecraft:orange_terracotta
setblock 1 167 323 minecraft:yellow_terracotta
fill 1 167 324 1 169 324 minecraft:honeycomb_block
setblock 1 167 328 minecraft:yellow_terracotta
fill 1 167 329 1 170 329 minecraft:honeycomb_block
setblock 1 167 333 minecraft:yellow_terracotta
fill 1 167 334 1 169 334 minecraft:honeycomb_block
setblock 1 167 338 minecraft:yellow_terracotta
fill 1 167 339 1 169 339 minecraft:honeycomb_block
setblock 1 167 343 minecraft:yellow_terracotta
fill 1 167 344 1 167 347 minecraft:honeycomb_block
setblock 1 167 348 minecraft:yellow_terracotta
fill 1 167 349 1 170 349 minecraft:honeycomb_block
setblock 1 167 353 minecraft:yellow_terracotta
fill 1 167 354 1 170 354 minecraft:honeycomb_block
setblock 1 167 358 minecraft:yellow_terracotta
setblock 1 167 359 minecraft:honeycomb_block
setblock 1 167 363 minecraft:yellow_terracotta
fill 2 167 323 5 167 323 minecraft:honeycomb_block
setblock 2 167 327 minecraft:yellow_terracotta
setblock 2 167 342 minecraft:yellow_terracotta
fill 2 167 343 2 169 343 minecraft:honeycomb_block
setblock 2 167 347 minecraft:yellow_terracotta
fill 2 167 348 2 170 348 minecraft:honeycomb_block
setblock 2 167 352 minecraft:yellow_terracotta
setblock 2 167 363 minecraft:honeycomb_block
setblock 3 167 325 minecraft:light[level=15]
setblock 3 167 333 minecraft:light[level=15]
setblock 3 167 341 minecraft:light[level=15]
setblock 3 167 346 minecraft:yellow_terracotta
fill 3 167 347 3 168 347 minecraft:honeycomb_block
setblock 3 167 357 minecraft:light[level=15]
setblock 3 167 363 minecraft:honey_block
setblock 6 167 323 minecraft:yellow_terracotta
setblock 7 167 323 minecraft:honeycomb_block
fill 8 167 347 8 168 348 minecraft:black_concrete
setblock 10 167 324 minecraft:yellow_terracotta
setblock 11 167 323 minecraft:yellow_terracotta
fill 11 167 324 11 170 324 minecraft:honeycomb_block
setblock 11 167 325 minecraft:light[level=15]
setblock 11 167 333 minecraft:light[level=15]
setblock 11 167 341 minecraft:light[level=15]
setblock 11 167 349 minecraft:light[level=15]
setblock 11 167 357 minecraft:light[level=15]
fill 12 167 323 12 170 323 minecraft:honeycomb_block
fill 12 167 325 12 168 325 minecraft:honeycomb_block
setblock 14 167 324 minecraft:honeycomb_block
setblock 14 167 325 minecraft:yellow_terracotta
fill 14 167 326 17 167 326 minecraft:honeycomb_block
setblock 15 167 324 minecraft:yellow_terracotta
fill 15 167 325 15 170 325 minecraft:honeycomb_block
setblock 16 167 323 minecraft:yellow_terracotta
fill 16 167 324 16 170 324 minecraft:honeycomb_block
setblock 16 167 363 minecraft:yellow_terracotta
fill 17 167 323 17 170 323 minecraft:honeycomb_block
setblock 17 167 362 minecraft:yellow_terracotta
fill 17 167 363 17 170 363 minecraft:honeycomb_block
setblock 18 167 326 minecraft:yellow_terracotta
setblock 18 167 362 minecraft:honeycomb_block
setblock 19 167 325 minecraft:yellow_terracotta
fill 19 167 326 19 169 326 minecraft:honeycomb_block
setblock 19 167 333 minecraft:light[level=15]
setblock 19 167 341 minecraft:light[level=15]
setblock 19 167 349 minecraft:light[level=15]
setblock 19 167 357 minecraft:light[level=15]
setblock 20 167 324 minecraft:yellow_terracotta
fill 20 167 325 20 170 325 minecraft:honeycomb_block
setblock 21 167 323 minecraft:yellow_terracotta
fill 21 167 324 21 170 324 minecraft:honeycomb_block
setblock 21 167 363 minecraft:yellow_terracotta
fill 22 167 323 22 170 323 minecraft:honeycomb_block
fill 22 167 363 22 169 363 minecraft:honeycomb_block
setblock 24 167 325 minecraft:yellow_terracotta
setblock 25 167 324 minecraft:yellow_terracotta
setblock 25 167 325 minecraft:honeycomb_block
fill 25 167 333 25 169 334 minecraft:brown_terracotta
setblock 26 167 323 minecraft:yellow_terracotta
fill 26 167 324 29 167 324 minecraft:honeycomb_block
fill 26 167 332 26 169 332 minecraft:brown_terracotta
fill 26 167 335 26 169 335 minecraft:brown_terracotta
setblock 26 167 363 minecraft:yellow_terracotta
fill 26 167 364 26 208 364 minecraft:honeycomb_block
fill 27 167 323 27 170 323 minecraft:honeycomb_block
setblock 27 167 325 minecraft:light[level=15]
setblock 27 167 341 minecraft:light[level=15]
setblock 27 167 349 minecraft:light[level=15]
setblock 27 167 357 minecraft:light[level=15]
fill 27 167 363 27 168 363 minecraft:honeycomb_block
fill 28 167 332 28 169 332 minecraft:brown_terracotta
fill 28 167 335 28 169 335 minecraft:brown_terracotta
fill 29 167 333 29 169 334 minecraft:brown_terracotta
setblock 30 167 324 minecraft:yellow_terracotta
setblock 31 167 323 minecraft:yellow_terracotta
fill 31 167 324 31 170 324 minecraft:honeycomb_block
setblock 31 167 363 minecraft:yellow_terracotta
fill 32 167 323 32 170 323 minecraft:honeycomb_block
setblock 32 167 362 minecraft:yellow_terracotta
fill 32 167 363 32 170 363 minecraft:honeycomb_block
fill 33 167 324 34 167 324 minecraft:honeycomb_block
fill 33 167 362 33 169 362 minecraft:honeycomb_block
setblock 34 167 325 minecraft:yellow_terracotta
setblock 35 167 324 minecraft:yellow_terracotta
fill 35 167 325 35 168 325 minecraft:honeycomb_block
setblock 35 167 333 minecraft:light[level=15]
setblock 35 167 341 minecraft:light[level=15]
setblock 35 167 349 minecraft:light[level=15]
setblock 35 167 357 minecraft:light[level=15]
setblock 36 167 323 minecraft:yellow_terracotta
fill 36 167 324 36 170 324 minecraft:honeycomb_block
setblock 36 167 363 minecraft:yellow_terracotta
fill 37 167 323 37 170 323 minecraft:honeycomb_block
setblock 37 167 362 minecraft:yellow_terracotta
fill 37 167 363 37 170 363 minecraft:honeycomb_block
setblock 38 167 346 minecraft:yellow_terracotta
fill 38 167 347 38 168 347 minecraft:honeycomb_block
setblock 38 167 361 minecraft:yellow_terracotta
fill 38 167 362 38 169 362 minecraft:honeycomb_block
setblock 39 167 325 minecraft:yellow_terracotta
setblock 39 167 345 minecraft:yellow_terracotta
fill 39 167 346 39 170 346 minecraft:honeycomb_block
setblock 39 167 350 minecraft:yellow_terracotta
fill 39 167 351 39 170 351 minecraft:honeycomb_block
setblock 39 167 355 minecraft:yellow_terracotta
setblock 39 167 361 minecraft:honeycomb_block
schedule function dropper:buildpart/72_6 1t
