setblock 88 290 279 minecraft:spruce_planks
fill 88 290 281 88 290 284 minecraft:spruce_planks
setblock 88 290 286 minecraft:spruce_planks
fill 88 290 288 88 290 291 minecraft:spruce_planks
setblock 88 290 293 minecraft:spruce_planks
fill 88 290 295 88 290 298 minecraft:spruce_planks
setblock 88 290 300 minecraft:spruce_planks
fill 88 290 302 88 290 305 minecraft:spruce_planks
setblock 88 290 307 minecraft:spruce_planks
fill 88 290 309 88 290 312 minecraft:spruce_planks
setblock 88 290 314 minecraft:spruce_planks
fill 47 291 291 47 308 291 minecraft:light_blue_concrete
setblock 48 291 278 minecraft:spruce_planks
setblock 48 291 285 minecraft:spruce_planks
setblock 48 291 292 minecraft:spruce_planks
setblock 48 291 299 minecraft:spruce_planks
setblock 48 291 306 minecraft:spruce_planks
setblock 48 291 313 minecraft:spruce_planks
fill 50 291 317 50 298 317 minecraft:light_blue_concrete
setblock 52 291 316 minecraft:spruce_planks
setblock 53 291 276 minecraft:spruce_planks
setblock 59 291 316 minecraft:spruce_planks
setblock 61 291 317 minecraft:white_wool
setblock 66 291 316 minecraft:spruce_planks
fill 67 291 275 67 308 275 minecraft:light_blue_concrete
setblock 73 291 316 minecraft:spruce_planks
setblock 74 291 276 minecraft:spruce_planks
setblock 80 291 316 minecraft:spruce_planks
setblock 81 291 275 minecraft:light_blue_wool
setblock 81 291 276 minecraft:spruce_planks
fill 82 291 284 82 291 286 minecraft:spruce_planks
fill 82 291 305 82 291 307 minecraft:spruce_planks
setblock 83 291 282 minecraft:dark_oak_planks
fill 83 291 286 83 293 287 minecraft:spruce_planks
fill 83 291 304 83 293 305 minecraft:spruce_planks
setblock 83 291 309 minecraft:dark_oak_planks
fill 84 291 284 84 291 286 minecraft:spruce_planks
fill 84 291 305 84 291 307 minecraft:spruce_planks
setblock 87 291 316 minecraft:spruce_planks
setblock 88 291 276 minecraft:spruce_planks
setblock 88 291 283 minecraft:spruce_planks
setblock 88 291 290 minecraft:spruce_planks
setblock 88 291 297 minecraft:spruce_planks
setblock 88 291 304 minecraft:spruce_planks
setblock 88 291 311 minecraft:spruce_planks
setblock 89 291 292 minecraft:light_blue_wool
setblock 48 292 279 minecraft:spruce_planks
setblock 48 292 286 minecraft:spruce_planks
setblock 48 292 293 minecraft:spruce_planks
setblock 48 292 300 minecraft:spruce_planks
setblock 48 292 307 minecraft:spruce_planks
setblock 48 292 314 minecraft:spruce_planks
setblock 52 292 276 minecraft:spruce_planks
setblock 53 292 316 minecraft:spruce_planks
setblock 55 292 277 minecraft:shroomlight
setblock 55 292 279 minecraft:shroomlight
setblock 56 292 276 minecraft:shroomlight
setblock 56 292 278 minecraft:shroomlight
fill 56 292 303 56 300 303 minecraft:dark_oak_planks
setblock 57 292 277 minecraft:shroomlight
setblock 57 292 279 minecraft:shroomlight
setblock 58 292 276 minecraft:shroomlight
setblock 58 292 278 minecraft:shroomlight
setblock 59 292 277 minecraft:shroomlight
setblock 59 292 279 minecraft:shroomlight
setblock 60 292 276 minecraft:shroomlight
setblock 60 292 278 minecraft:shroomlight
setblock 60 292 316 minecraft:spruce_planks
setblock 61 292 277 minecraft:shroomlight
setblock 61 292 279 minecraft:shroomlight
fill 61 292 317 61 308 317 minecraft:light_blue_concrete
setblock 62 292 276 minecraft:shroomlight
setblock 62 292 278 minecraft:shroomlight
setblock 63 292 277 minecraft:shroomlight
setblock 63 292 279 minecraft:shroomlight
setblock 64 292 276 minecraft:shroomlight
setblock 64 292 278 minecraft:shroomlight
setblock 65 292 277 minecraft:shroomlight
setblock 65 292 279 minecraft:shroomlight
setblock 66 292 276 minecraft:shroomlight
setblock 66 292 278 minecraft:shroomlight
setblock 67 292 277 minecraft:shroomlight
setblock 67 292 279 minecraft:shroomlight
setblock 67 292 316 minecraft:spruce_planks
setblock 73 292 276 minecraft:spruce_planks
setblock 74 292 316 minecraft:spruce_planks
setblock 80 292 276 minecraft:spruce_planks
fill 81 292 275 81 308 275 minecraft:light_blue_concrete
setblock 81 292 316 minecraft:spruce_planks
fill 82 292 285 82 292 288 minecraft:spruce_planks
fill 82 292 303 82 292 306 minecraft:spruce_planks
setblock 83 292 283 minecraft:dark_oak_planks
fill 83 292 288 83 294 289 minecraft:spruce_planks
fill 83 292 302 83 294 303 minecraft:spruce_planks
setblock 83 292 308 minecraft:dark_oak_planks
fill 84 292 285 84 292 288 minecraft:spruce_planks
fill 84 292 303 84 292 306 minecraft:spruce_planks
setblock 87 292 276 minecraft:spruce_planks
setblock 88 292 282 minecraft:spruce_planks
setblock 88 292 289 minecraft:spruce_planks
setblock 88 292 296 minecraft:spruce_planks
setblock 88 292 303 minecraft:spruce_planks
setblock 88 292 310 minecraft:spruce_planks
setblock 88 292 316 minecraft:spruce_planks
fill 89 292 292 89 308 292 minecraft:light_blue_concrete
setblock 48 293 280 minecraft:spruce_planks
setblock 48 293 287 minecraft:spruce_planks
fill 48 293 292 54 294 292 minecraft:spruce_planks
setblock 48 293 294 minecraft:spruce_planks
setblock 48 293 301 minecraft:spruce_planks
setblock 48 293 308 minecraft:spruce_planks
setblock 48 293 315 minecraft:spruce_planks
fill 50 293 293 62 294 293 minecraft:spruce_planks
setblock 51 293 276 minecraft:spruce_planks
setblock 54 293 316 minecraft:spruce_planks
fill 55 293 277 55 294 277 minecraft:spruce_planks
fill 55 293 279 55 294 279 minecraft:spruce_planks
fill 56 293 276 56 294 276 minecraft:spruce_planks
fill 56 293 278 56 294 278 minecraft:spruce_planks
fill 56 293 304 56 300 304 minecraft:dark_oak_planks
fill 57 293 277 57 294 277 minecraft:spruce_planks
fill 57 293 279 57 294 279 minecraft:spruce_planks
fill 57 293 303 57 300 303 minecraft:dark_oak_planks
fill 58 293 276 58 294 276 minecraft:spruce_planks
fill 58 293 278 58 294 278 minecraft:spruce_planks
fill 59 293 277 59 294 277 minecraft:spruce_planks
fill 59 293 279 59 294 279 minecraft:spruce_planks
fill 60 293 276 60 294 276 minecraft:spruce_planks
fill 60 293 278 60 294 278 minecraft:spruce_planks
fill 61 293 277 61 294 277 minecraft:spruce_planks
fill 61 293 279 61 294 279 minecraft:spruce_planks
setblock 61 293 316 minecraft:spruce_planks
fill 62 293 276 62 294 276 minecraft:spruce_planks
fill 62 293 278 62 294 278 minecraft:spruce_planks
fill 63 293 277 63 294 277 minecraft:spruce_planks
fill 63 293 279 63 294 279 minecraft:spruce_planks
fill 63 293 294 67 294 294 minecraft:spruce_planks
fill 64 293 276 64 294 276 minecraft:spruce_planks
fill 64 293 278 64 294 278 minecraft:spruce_planks
fill 65 293 277 65 294 277 minecraft:spruce_planks
fill 65 293 279 65 294 279 minecraft:spruce_planks
fill 66 293 276 66 294 276 minecraft:spruce_planks
fill 66 293 278 66 294 278 minecraft:spruce_planks
setblock 66 293 317 minecraft:light_blue_wool
fill 67 293 277 67 294 277 minecraft:spruce_planks
fill 67 293 279 67 294 279 minecraft:spruce_planks
fill 67 293 317 68 308 317 minecraft:light_blue_concrete
setblock 68 293 316 minecraft:spruce_planks
setblock 72 293 276 minecraft:spruce_planks
setblock 75 293 316 minecraft:spruce_planks
setblock 79 293 276 minecraft:spruce_planks
fill 82 293 287 82 293 290 minecraft:spruce_planks
fill 82 293 301 82 293 304 minecraft:spruce_planks
setblock 82 293 316 minecraft:spruce_planks
setblock 83 293 285 minecraft:dark_oak_planks
fill 83 293 290 83 294 293 minecraft:spruce_planks
fill 83 293 298 83 294 301 minecraft:spruce_planks
setblock 83 293 306 minecraft:dark_oak_planks
fill 84 293 287 84 293 290 minecraft:spruce_planks
fill 84 293 301 84 293 304 minecraft:spruce_planks
setblock 86 293 276 minecraft:spruce_planks
setblock 88 293 281 minecraft:spruce_planks
setblock 88 293 288 minecraft:spruce_planks
setblock 88 293 295 minecraft:spruce_planks
setblock 88 293 302 minecraft:spruce_planks
setblock 88 293 309 minecraft:spruce_planks
setblock 47 294 282 minecraft:white_wool
fill 47 294 283 47 308 283 minecraft:light_blue_concrete
fill 55 294 292 57 294 292 minecraft:spruce_planks
fill 55 294 303 55 300 304 minecraft:dark_oak_planks
fill 56 294 302 57 300 302 minecraft:dark_oak_planks
fill 57 294 304 57 300 304 minecraft:dark_oak_planks
fill 58 294 294 62 294 294 minecraft:spruce_planks
fill 63 294 293 66 294 293 minecraft:spruce_planks
fill 66 294 317 66 302 317 minecraft:light_blue_concrete
fill 68 294 294 75 294 294 minecraft:spruce_planks
fill 70 294 295 84 294 295 minecraft:spruce_planks
setblock 75 294 317 minecraft:white_wool
fill 77 294 296 88 294 296 minecraft:spruce_planks
fill 82 294 290 82 294 294 minecraft:spruce_planks
fill 82 294 297 82 294 301 minecraft:spruce_planks
fill 83 294 286 83 294 287 minecraft:dark_oak_planks
fill 83 294 294 84 295 294 minecraft:spruce_planks
fill 83 294 297 84 295 297 minecraft:spruce_planks
fill 83 294 304 83 294 305 minecraft:dark_oak_planks
fill 84 294 290 84 294 293 minecraft:spruce_planks
fill 84 294 298 84 294 301 minecraft:spruce_planks
fill 87 294 297 87 295 297 minecraft:spruce_planks
fill 47 295 282 47 308 282 minecraft:light_blue_concrete
setblock 48 295 282 minecraft:spruce_planks
setblock 48 295 289 minecraft:spruce_planks
fill 48 295 292 53 295 292 minecraft:dark_oak_planks
setblock 48 295 296 minecraft:spruce_planks
setblock 48 295 303 minecraft:spruce_planks
setblock 48 295 310 minecraft:spruce_planks
setblock 49 295 276 minecraft:spruce_planks
setblock 49 295 316 minecraft:spruce_planks
fill 53 295 293 62 295 293 minecraft:dark_oak_planks
setblock 55 295 277 minecraft:shroomlight
setblock 55 295 279 minecraft:shroomlight
fill 55 295 302 55 300 302 minecraft:dark_oak_planks
setblock 56 295 276 minecraft:shroomlight
setblock 56 295 278 minecraft:shroomlight
setblock 56 295 316 minecraft:spruce_planks
setblock 57 295 277 minecraft:shroomlight
setblock 57 295 279 minecraft:shroomlight
setblock 58 295 276 minecraft:shroomlight
setblock 58 295 278 minecraft:shroomlight
fill 58 295 303 58 300 303 minecraft:dark_oak_planks
setblock 59 295 277 minecraft:shroomlight
setblock 59 295 279 minecraft:shroomlight
setblock 60 295 276 minecraft:shroomlight
setblock 60 295 278 minecraft:shroomlight
setblock 61 295 277 minecraft:shroomlight
setblock 61 295 279 minecraft:shroomlight
fill 61 295 313 62 295 313 minecraft:white_concrete
setblock 62 295 276 minecraft:shroomlight
setblock 62 295 278 minecraft:shroomlight
setblock 63 295 277 minecraft:shroomlight
setblock 63 295 279 minecraft:shroomlight
fill 63 295 294 67 295 294 minecraft:dark_oak_planks
setblock 63 295 316 minecraft:spruce_planks
setblock 64 295 276 minecraft:shroomlight
setblock 64 295 278 minecraft:shroomlight
setblock 65 295 277 minecraft:shroomlight
setblock 65 295 279 minecraft:shroomlight
setblock 66 295 276 minecraft:shroomlight
setblock 66 295 278 minecraft:shroomlight
setblock 67 295 277 minecraft:shroomlight
setblock 67 295 279 minecraft:shroomlight
fill 68 295 294 70 295 294 minecraft:spruce_planks
setblock 70 295 276 minecraft:spruce_planks
setblock 70 295 316 minecraft:spruce_planks
setblock 71 295 317 minecraft:white_wool
fill 72 295 295 84 295 295 minecraft:spruce_planks
setblock 73 295 317 minecraft:white_wool
fill 75 295 317 75 308 317 minecraft:light_blue_concrete
setblock 77 295 276 minecraft:spruce_planks
setblock 77 295 316 minecraft:spruce_planks
fill 79 295 296 88 295 296 minecraft:spruce_planks
fill 82 295 293 82 295 294 minecraft:spruce_planks
fill 82 295 297 82 295 298 minecraft:spruce_planks
fill 83 295 289 83 295 290 minecraft:dark_oak_planks
fill 83 295 291 83 295 293 minecraft:spruce_planks
fill 83 295 298 83 295 300 minecraft:spruce_planks
fill 83 295 301 83 295 302 minecraft:dark_oak_planks
setblock 84 295 276 minecraft:spruce_planks
setblock 84 295 293 minecraft:spruce_planks
setblock 84 295 298 minecraft:spruce_planks
setblock 84 295 316 minecraft:spruce_planks
setblock 88 295 279 minecraft:spruce_planks
setblock 88 295 286 minecraft:spruce_planks
setblock 88 295 293 minecraft:spruce_planks
setblock 88 295 300 minecraft:spruce_planks
setblock 88 295 307 minecraft:spruce_planks
setblock 88 295 314 minecraft:spruce_planks
setblock 48 296 276 minecraft:spruce_planks
setblock 48 296 283 minecraft:spruce_planks
setblock 48 296 290 minecraft:spruce_planks
setblock 48 296 297 minecraft:spruce_planks
setblock 48 296 304 minecraft:spruce_planks
setblock 48 296 311 minecraft:spruce_planks
setblock 50 296 278 minecraft:light[level=12]
setblock 50 296 285 minecraft:light[level=12]
setblock 50 296 292 minecraft:light[level=12]
setblock 50 296 299 minecraft:light[level=12]
setblock 50 296 306 minecraft:light[level=12]
setblock 50 296 313 minecraft:light[level=12]
setblock 50 296 316 minecraft:spruce_planks
fill 54 296 302 54 300 304 minecraft:dark_oak_planks
fill 55 296 277 55 297 277 minecraft:spruce_planks
fill 55 296 279 55 297 279 minecraft:spruce_planks
fill 55 296 301 57 300 301 minecraft:dark_oak_planks
fill 55 296 305 57 300 305 minecraft:dark_oak_planks
fill 56 296 276 56 297 276 minecraft:spruce_planks
fill 56 296 278 56 297 278 minecraft:spruce_planks
fill 57 296 277 57 297 277 minecraft:spruce_planks
fill 57 296 279 57 297 279 minecraft:spruce_planks
setblock 57 296 285 minecraft:light[level=12]
setblock 57 296 292 minecraft:light[level=12]
setblock 57 296 299 minecraft:light[level=12]
setblock 57 296 306 minecraft:light[level=12]
setblock 57 296 313 minecraft:light[level=12]
setblock 57 296 316 minecraft:spruce_planks
fill 58 296 276 58 297 276 minecraft:spruce_planks
fill 58 296 278 58 297 278 minecraft:spruce_planks
fill 58 296 302 58 300 302 minecraft:dark_oak_planks
fill 58 296 304 58 300 304 minecraft:dark_oak_planks
fill 59 296 277 59 297 277 minecraft:spruce_planks
fill 59 296 279 59 297 279 minecraft:spruce_planks
fill 60 296 276 60 297 276 minecraft:spruce_planks
fill 60 296 278 60 297 278 minecraft:spruce_planks
fill 61 296 277 61 297 277 minecraft:spruce_planks
fill 61 296 279 61 297 279 minecraft:spruce_planks
fill 62 296 276 62 297 276 minecraft:spruce_planks
fill 62 296 278 62 297 278 minecraft:spruce_planks
fill 63 296 277 63 297 277 minecraft:spruce_planks
fill 63 296 279 63 297 279 minecraft:spruce_planks
fill 64 296 276 64 297 276 minecraft:spruce_planks
fill 64 296 278 64 297 278 minecraft:spruce_planks
setblock 64 296 285 minecraft:light[level=12]
setblock 64 296 292 minecraft:light[level=12]
setblock 64 296 299 minecraft:light[level=12]
setblock 64 296 306 minecraft:light[level=12]
setblock 64 296 313 minecraft:light[level=12]
setblock 64 296 316 minecraft:spruce_planks
fill 65 296 277 65 297 277 minecraft:spruce_planks
fill 65 296 279 65 297 279 minecraft:spruce_planks
fill 66 296 276 66 297 276 minecraft:spruce_planks
fill 66 296 278 66 297 278 minecraft:spruce_planks
fill 67 296 277 67 297 277 minecraft:spruce_planks
fill 67 296 279 67 297 279 minecraft:spruce_planks
setblock 69 296 276 minecraft:spruce_planks
setblock 71 296 278 minecraft:light[level=12]
setblock 71 296 285 minecraft:light[level=12]
setblock 71 296 292 minecraft:light[level=12]
setblock 71 296 299 minecraft:light[level=12]
setblock 71 296 306 minecraft:light[level=12]
setblock 71 296 313 minecraft:light[level=12]
setblock 71 296 316 minecraft:spruce_planks
fill 71 296 317 71 308 317 minecraft:light_blue_concrete
fill 73 296 317 73 308 317 minecraft:light_blue_concrete
setblock 74 296 275 minecraft:white_wool
fill 74 296 295 80 296 295 minecraft:dark_oak_planks
setblock 76 296 276 minecraft:spruce_planks
setblock 78 296 278 minecraft:light[level=12]
setblock 78 296 285 minecraft:light[level=12]
setblock 78 296 292 minecraft:light[level=12]
setblock 78 296 299 minecraft:light[level=12]
setblock 78 296 306 minecraft:light[level=12]
setblock 78 296 313 minecraft:light[level=12]
setblock 78 296 316 minecraft:spruce_planks
setblock 79 296 275 minecraft:light_blue_wool
fill 81 296 296 87 296 296 minecraft:dark_oak_planks
setblock 83 296 276 minecraft:spruce_planks
fill 83 296 291 83 296 295 minecraft:dark_oak_planks
fill 83 296 297 83 296 300 minecraft:dark_oak_planks
setblock 85 296 278 minecraft:light[level=12]
setblock 85 296 285 minecraft:light[level=12]
setblock 85 296 292 minecraft:light[level=12]
setblock 85 296 299 minecraft:light[level=12]
setblock 85 296 306 minecraft:light[level=12]
setblock 85 296 313 minecraft:light[level=12]
setblock 85 296 316 minecraft:spruce_planks
setblock 88 296 278 minecraft:spruce_planks
setblock 88 296 285 minecraft:spruce_planks
setblock 88 296 292 minecraft:spruce_planks
setblock 88 296 299 minecraft:spruce_planks
setblock 88 296 306 minecraft:spruce_planks
setblock 88 296 313 minecraft:spruce_planks
setblock 48 297 277 minecraft:spruce_planks
setblock 48 297 284 minecraft:spruce_planks
setblock 48 297 291 minecraft:spruce_planks
setblock 48 297 298 minecraft:spruce_planks
setblock 48 297 305 minecraft:spruce_planks
setblock 48 297 312 minecraft:spruce_planks
setblock 51 297 316 minecraft:spruce_planks
setblock 54 297 276 minecraft:spruce_planks
fill 54 297 305 54 300 305 minecraft:dark_oak_planks
fill 58 297 301 58 300 301 minecraft:dark_oak_planks
fill 58 297 305 58 300 305 minecraft:dark_oak_planks
setblock 58 297 316 minecraft:spruce_planks
setblock 65 297 316 minecraft:spruce_planks
setblock 68 297 276 minecraft:spruce_planks
setblock 72 297 316 minecraft:spruce_planks
fill 74 297 275 74 308 275 minecraft:light_blue_concrete
setblock 75 297 276 minecraft:spruce_planks
fill 79 297 275 79 308 275 minecraft:light_blue_concrete
setblock 79 297 316 minecraft:spruce_planks
setblock 82 297 276 minecraft:spruce_planks
setblock 86 297 316 minecraft:spruce_planks
setblock 88 297 277 minecraft:spruce_planks
setblock 88 297 284 minecraft:spruce_planks
setblock 88 297 291 minecraft:spruce_planks
setblock 88 297 298 minecraft:spruce_planks
setblock 88 297 305 minecraft:spruce_planks
setblock 88 297 312 minecraft:spruce_planks
fill 89 297 286 89 308 286 minecraft:light_blue_concrete
setblock 89 297 287 minecraft:white_wool
setblock 48 298 278 minecraft:spruce_planks
setblock 48 298 285 minecraft:spruce_planks
setblock 48 298 292 minecraft:spruce_planks
setblock 48 298 299 minecraft:spruce_planks
setblock 48 298 306 minecraft:spruce_planks
setblock 48 298 313 minecraft:spruce_planks
setblock 50 298 278 minecraft:light[level=15]
setblock 50 298 286 minecraft:light[level=15]
setblock 50 298 294 minecraft:light[level=15]
setblock 50 298 302 minecraft:light[level=15]
setblock 50 298 310 minecraft:light[level=15]
setblock 52 298 316 minecraft:spruce_planks
setblock 53 298 276 minecraft:spruce_planks
fill 53 298 302 53 300 304 minecraft:dark_oak_planks
fill 54 298 301 54 300 301 minecraft:dark_oak_planks
setblock 55 298 277 minecraft:shroomlight
setblock 55 298 279 minecraft:shroomlight
fill 55 298 300 57 300 300 minecraft:dark_oak_planks
fill 55 298 306 57 300 306 minecraft:dark_oak_planks
setblock 56 298 276 minecraft:shroomlight
setblock 56 298 278 minecraft:shroomlight
setblock 57 298 277 minecraft:shroomlight
setblock 57 298 279 minecraft:shroomlight
setblock 58 298 276 minecraft:shroomlight
setblock 58 298 278 minecraft:shroomlight
setblock 58 298 286 minecraft:light[level=15]
setblock 58 298 294 minecraft:light[level=15]
setblock 58 298 310 minecraft:light[level=15]
setblock 59 298 277 minecraft:shroomlight
setblock 59 298 279 minecraft:shroomlight
fill 59 298 302 59 300 304 minecraft:dark_oak_planks
setblock 59 298 316 minecraft:spruce_planks
setblock 60 298 276 minecraft:shroomlight
setblock 60 298 278 minecraft:shroomlight
setblock 61 298 277 minecraft:shroomlight
setblock 61 298 279 minecraft:shroomlight
setblock 62 298 276 minecraft:shroomlight
setblock 62 298 278 minecraft:shroomlight
setblock 63 298 277 minecraft:shroomlight
setblock 63 298 279 minecraft:shroomlight
setblock 64 298 276 minecraft:shroomlight
setblock 64 298 278 minecraft:shroomlight
setblock 65 298 277 minecraft:shroomlight
setblock 65 298 279 minecraft:shroomlight
setblock 66 298 276 minecraft:shroomlight
setblock 66 298 278 minecraft:shroomlight
setblock 66 298 286 minecraft:light[level=15]
setblock 66 298 294 minecraft:light[level=15]
setblock 66 298 302 minecraft:light[level=15]
setblock 66 298 310 minecraft:light[level=15]
setblock 66 298 316 minecraft:spruce_planks
setblock 67 298 277 minecraft:shroomlight
setblock 67 298 279 minecraft:shroomlight
setblock 73 298 316 minecraft:spruce_planks
setblock 74 298 276 minecraft:spruce_planks
setblock 74 298 278 minecraft:light[level=15]
setblock 74 298 286 minecraft:light[level=15]
setblock 74 298 294 minecraft:light[level=15]
setblock 74 298 302 minecraft:light[level=15]
setblock 74 298 310 minecraft:light[level=15]
setblock 80 298 316 minecraft:spruce_planks
setblock 81 298 276 minecraft:spruce_planks
setblock 82 298 278 minecraft:light[level=15]
setblock 82 298 286 minecraft:light[level=15]
setblock 82 298 294 minecraft:light[level=15]
setblock 82 298 302 minecraft:light[level=15]
setblock 82 298 310 minecraft:light[level=15]
setblock 87 298 316 minecraft:spruce_planks
setblock 88 298 276 minecraft:spruce_planks
setblock 88 298 283 minecraft:spruce_planks
setblock 88 298 290 minecraft:spruce_planks
setblock 88 298 297 minecraft:spruce_planks
setblock 88 298 304 minecraft:spruce_planks
setblock 88 298 311 minecraft:spruce_planks
fill 89 298 287 89 308 287 minecraft:light_blue_concrete
fill 48 299 279 48 300 279 minecraft:spruce_planks
fill 48 299 286 48 300 286 minecraft:spruce_planks
fill 48 299 293 48 300 293 minecraft:spruce_planks
fill 48 299 300 48 300 300 minecraft:spruce_planks
fill 48 299 307 48 300 307 minecraft:spruce_planks
fill 48 299 314 48 300 314 minecraft:spruce_planks
setblock 50 299 317 minecraft:white_wool
fill 52 299 276 52 300 276 minecraft:spruce_planks
fill 53 299 301 53 300 301 minecraft:dark_oak_planks
fill 53 299 305 53 300 305 minecraft:dark_oak_planks
fill 53 299 316 53 300 316 minecraft:spruce_planks
fill 54 299 300 54 300 300 minecraft:dark_oak_planks
fill 54 299 306 54 300 306 minecraft:dark_oak_planks
fill 54 299 317 55 308 317 minecraft:light_blue_concrete
fill 55 299 277 55 300 277 minecraft:spruce_planks
fill 55 299 279 55 300 279 minecraft:spruce_planks
fill 56 299 276 56 300 276 minecraft:spruce_planks
fill 56 299 278 56 300 278 minecraft:spruce_planks
setblock 56 299 317 minecraft:light_blue_wool
fill 57 299 277 57 300 277 minecraft:spruce_planks
fill 57 299 279 57 300 279 minecraft:spruce_planks
fill 58 299 276 58 300 276 minecraft:spruce_planks
fill 58 299 278 58 300 278 minecraft:spruce_planks
fill 58 299 300 58 300 300 minecraft:dark_oak_planks
fill 58 299 306 58 300 306 minecraft:dark_oak_planks
fill 59 299 277 59 300 277 minecraft:spruce_planks
fill 59 299 279 59 300 279 minecraft:spruce_planks
fill 59 299 301 59 300 301 minecraft:dark_oak_planks
fill 59 299 305 59 300 305 minecraft:dark_oak_planks
fill 60 299 276 60 300 276 minecraft:spruce_planks
fill 60 299 278 60 300 278 minecraft:spruce_planks
fill 60 299 316 60 300 316 minecraft:spruce_planks
fill 61 299 277 61 300 277 minecraft:spruce_planks
fill 61 299 279 61 300 279 minecraft:spruce_planks
fill 62 299 276 62 300 276 minecraft:spruce_planks
fill 62 299 278 62 300 278 minecraft:spruce_planks
fill 63 299 277 63 300 277 minecraft:spruce_planks
fill 63 299 279 63 300 279 minecraft:spruce_planks
fill 64 299 276 64 300 276 minecraft:spruce_planks
fill 64 299 278 64 300 278 minecraft:spruce_planks
fill 65 299 277 65 300 277 minecraft:spruce_planks
fill 65 299 279 65 300 279 minecraft:spruce_planks
fill 66 299 276 66 300 276 minecraft:spruce_planks
fill 66 299 278 66 300 278 minecraft:spruce_planks
fill 67 299 277 67 300 277 minecraft:spruce_planks
fill 67 299 279 67 300 279 minecraft:spruce_planks
fill 67 299 316 67 300 316 minecraft:spruce_planks
fill 73 299 276 73 300 276 minecraft:spruce_planks
fill 74 299 316 74 300 316 minecraft:spruce_planks
fill 80 299 276 80 300 276 minecraft:spruce_planks
fill 81 299 316 81 300 316 minecraft:spruce_planks
fill 87 299 276 87 300 276 minecraft:spruce_planks
fill 88 299 282 88 300 282 minecraft:spruce_planks
fill 88 299 289 88 300 289 minecraft:spruce_planks
fill 88 299 296 88 300 296 minecraft:spruce_planks
fill 88 299 303 88 300 303 minecraft:spruce_planks
fill 88 299 310 88 300 310 minecraft:spruce_planks
fill 88 299 316 88 300 316 minecraft:spruce_planks
fill 48 300 276 48 300 278 minecraft:spruce_planks
setblock 48 300 280 minecraft:spruce_planks
fill 48 300 282 48 300 285 minecraft:spruce_planks
setblock 48 300 287 minecraft:spruce_planks
fill 48 300 289 48 300 292 minecraft:spruce_planks
setblock 48 300 294 minecraft:spruce_planks
fill 48 300 296 48 300 299 minecraft:spruce_planks
setblock 48 300 301 minecraft:spruce_planks
fill 48 300 303 48 300 306 minecraft:spruce_planks
setblock 48 300 308 minecraft:spruce_planks
fill 48 300 310 48 300 313 minecraft:spruce_planks
setblock 48 300 315 minecraft:spruce_planks
setblock 49 300 276 minecraft:spruce_planks
fill 49 300 316 52 300 316 minecraft:spruce_planks
fill 50 300 317 50 308 317 minecraft:light_blue_concrete
setblock 51 300 276 minecraft:spruce_planks
fill 52 300 302 52 300 304 minecraft:dark_oak_planks
fill 53 300 276 54 300 276 minecraft:spruce_planks
setblock 53 300 306 minecraft:dark_oak_planks
setblock 54 300 316 minecraft:spruce_planks
fill 55 300 299 57 300 299 minecraft:dark_oak_planks
fill 55 300 307 57 300 307 minecraft:dark_oak_planks
fill 56 300 316 59 300 316 minecraft:spruce_planks
fill 56 300 317 56 308 317 minecraft:light_blue_concrete
setblock 59 300 300 minecraft:dark_oak_planks
setblock 59 300 306 minecraft:dark_oak_planks
fill 60 300 302 60 300 304 minecraft:dark_oak_planks
setblock 61 300 316 minecraft:spruce_planks
fill 63 300 316 66 300 316 minecraft:spruce_planks
fill 68 300 276 70 300 276 minecraft:spruce_planks
setblock 68 300 316 minecraft:spruce_planks
fill 70 300 316 73 300 316 minecraft:spruce_planks
setblock 72 300 276 minecraft:spruce_planks
fill 74 300 276 77 300 276 minecraft:spruce_planks
setblock 75 300 316 minecraft:spruce_planks
fill 77 300 316 80 300 316 minecraft:spruce_planks
setblock 79 300 276 minecraft:spruce_planks
fill 81 300 276 84 300 276 minecraft:spruce_planks
setblock 82 300 316 minecraft:spruce_planks
fill 84 300 316 87 300 316 minecraft:spruce_planks
setblock 86 300 276 minecraft:spruce_planks
fill 88 300 276 88 300 279 minecraft:spruce_planks
setblock 88 300 281 minecraft:spruce_planks
fill 88 300 283 88 300 286 minecraft:spruce_planks
setblock 88 300 288 minecraft:spruce_planks
fill 88 300 290 88 300 293 minecraft:spruce_planks
setblock 88 300 295 minecraft:spruce_planks
fill 88 300 297 88 300 300 minecraft:spruce_planks
setblock 88 300 302 minecraft:spruce_planks
fill 88 300 304 88 300 307 minecraft:spruce_planks
setblock 88 300 309 minecraft:spruce_planks
fill 88 300 311 88 300 314 minecraft:spruce_planks
fill 76 301 317 78 308 317 minecraft:light_blue_concrete
setblock 79 301 317 minecraft:white_wool
fill 80 301 317 80 308 317 minecraft:light_blue_concrete
setblock 50 302 278 minecraft:light[level=12]
setblock 50 302 285 minecraft:light[level=12]
setblock 50 302 292 minecraft:light[level=12]
setblock 50 302 299 minecraft:light[level=12]
setblock 50 302 306 minecraft:light[level=12]
setblock 50 302 313 minecraft:light[level=12]
setblock 56 302 275 minecraft:white_wool
setblock 57 302 278 minecraft:light[level=12]
setblock 57 302 285 minecraft:light[level=12]
setblock 57 302 292 minecraft:light[level=12]
setblock 57 302 299 minecraft:light[level=12]
setblock 57 302 306 minecraft:light[level=12]
setblock 57 302 313 minecraft:light[level=12]
fill 58 302 275 58 308 275 minecraft:light_blue_concrete
setblock 59 302 275 minecraft:light_blue_wool
fill 60 302 275 63 302 275 minecraft:light_blue_concrete
setblock 64 302 278 minecraft:light[level=12]
setblock 64 302 285 minecraft:light[level=12]
setblock 64 302 292 minecraft:light[level=12]
setblock 64 302 299 minecraft:light[level=12]
setblock 64 302 306 minecraft:light[level=12]
setblock 64 302 313 minecraft:light[level=12]
setblock 71 302 278 minecraft:light[level=12]
setblock 71 302 285 minecraft:light[level=12]
setblock 71 302 292 minecraft:light[level=12]
setblock 71 302 299 minecraft:light[level=12]
setblock 71 302 306 minecraft:light[level=12]
setblock 71 302 313 minecraft:light[level=12]
setblock 78 302 278 minecraft:light[level=12]
setblock 78 302 285 minecraft:light[level=12]
setblock 78 302 292 minecraft:light[level=12]
setblock 78 302 299 minecraft:light[level=12]
setblock 78 302 306 minecraft:light[level=12]
setblock 78 302 313 minecraft:light[level=12]
fill 79 302 317 79 308 317 minecraft:light_blue_concrete
setblock 85 302 278 minecraft:light[level=12]
setblock 85 302 285 minecraft:light[level=12]
setblock 85 302 292 minecraft:light[level=12]
setblock 85 302 299 minecraft:light[level=12]
setblock 85 302 306 minecraft:light[level=12]
setblock 85 302 313 minecraft:light[level=12]
fill 89 302 308 89 308 308 minecraft:light_blue_concrete
setblock 89 302 309 minecraft:light_blue_wool
fill 89 302 310 89 308 311 minecraft:light_blue_concrete
setblock 47 303 290 minecraft:white_wool
fill 56 303 275 56 308 275 minecraft:light_blue_concrete
fill 59 303 275 59 308 275 minecraft:light_blue_concrete
setblock 60 303 275 minecraft:light_blue_wool
fill 61 303 275 63 308 275 minecraft:light_blue_concrete
setblock 66 303 317 minecraft:light_blue_wool
setblock 83 303 317 minecraft:white_wool
fill 89 303 309 89 308 309 minecraft:light_blue_concrete
fill 47 304 290 47 308 290 minecraft:light_blue_concrete
fill 60 304 275 60 308 275 minecraft:light_blue_concrete
fill 66 304 317 66 308 317 minecraft:light_blue_concrete
fill 83 304 317 83 308 317 minecraft:light_blue_concrete
setblock 70 305 317 minecraft:white_wool
setblock 89 305 288 minecraft:white_wool
setblock 89 305 307 minecraft:light_blue_wool
setblock 47 306 316 minecraft:white_wool
fill 70 306 317 70 308 317 minecraft:light_blue_concrete
fill 89 306 288 89 308 288 minecraft:light_blue_concrete
fill 89 306 307 89 308 307 minecraft:light_blue_concrete
setblock 47 307 280 minecraft:white_wool
fill 47 307 316 47 308 316 minecraft:light_blue_concrete
setblock 47 308 280 minecraft:light_blue_concrete
setblock 47 308 311 minecraft:white_wool
setblock 47 308 312 minecraft:light_blue_concrete
setblock 48 308 317 minecraft:light_blue_wool
setblock 49 308 317 minecraft:light_blue_concrete
