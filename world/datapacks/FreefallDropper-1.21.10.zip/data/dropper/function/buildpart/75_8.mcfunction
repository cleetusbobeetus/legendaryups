setblock 158 141 363 minecraft:dark_prismarine
fill 158 141 364 158 166 364 minecraft:blue_terracotta
fill 159 141 323 159 144 323 minecraft:blue_terracotta
setblock 159 141 327 minecraft:dark_prismarine
setblock 159 141 362 minecraft:dark_prismarine
fill 159 141 363 159 144 363 minecraft:blue_terracotta
setblock 159 141 364 minecraft:cyan_concrete
setblock 160 141 326 minecraft:dark_prismarine
fill 160 141 327 160 142 327 minecraft:blue_terracotta
setblock 160 141 333 minecraft:light[level=13]
setblock 160 141 341 minecraft:light[level=13]
setblock 160 141 349 minecraft:light[level=13]
setblock 160 141 357 minecraft:light[level=13]
fill 160 141 362 163 141 362 minecraft:blue_terracotta
fill 160 141 364 161 220 364 minecraft:blue_terracotta
setblock 161 141 325 minecraft:dark_prismarine
fill 161 141 326 161 144 326 minecraft:blue_terracotta
setblock 162 141 324 minecraft:dark_prismarine
fill 162 141 325 162 144 325 minecraft:blue_terracotta
setblock 163 141 323 minecraft:dark_prismarine
fill 163 141 324 163 144 324 minecraft:blue_terracotta
setblock 163 141 363 minecraft:dark_prismarine
fill 164 141 323 164 144 323 minecraft:blue_terracotta
setblock 164 141 362 minecraft:dark_prismarine
fill 164 141 363 164 144 363 minecraft:blue_terracotta
setblock 165 141 326 minecraft:dark_prismarine
fill 165 141 362 165 142 362 minecraft:blue_terracotta
setblock 166 141 325 minecraft:dark_prismarine
setblock 166 141 326 minecraft:blue_terracotta
setblock 167 141 324 minecraft:dark_prismarine
setblock 167 141 325 minecraft:blue_terracotta
setblock 168 141 323 minecraft:dark_prismarine
fill 168 141 324 168 142 324 minecraft:blue_terracotta
fill 168 141 330 168 169 330 minecraft:magenta_terracotta
setblock 168 141 333 minecraft:light[level=13]
setblock 168 141 341 minecraft:light[level=13]
setblock 168 141 349 minecraft:light[level=13]
setblock 168 141 357 minecraft:light[level=13]
setblock 168 141 363 minecraft:dark_prismarine
fill 169 141 323 169 143 323 minecraft:blue_terracotta
fill 169 141 363 169 143 363 minecraft:blue_terracotta
setblock 173 141 323 minecraft:dark_prismarine
setblock 173 141 363 minecraft:dark_prismarine
fill 174 141 323 174 143 323 minecraft:blue_terracotta
fill 174 141 351 174 145 352 minecraft:magenta_terracotta
fill 174 141 363 174 144 363 minecraft:blue_terracotta
setblock 175 141 324 minecraft:dark_prismarine
setblock 176 141 324 minecraft:blue_terracotta
setblock 176 141 349 minecraft:light[level=13]
setblock 176 141 357 minecraft:light[level=13]
setblock 177 141 324 minecraft:dark_prismarine
setblock 178 141 323 minecraft:dark_prismarine
fill 178 141 324 178 143 324 minecraft:blue_terracotta
fill 178 141 328 179 162 330 minecraft:dark_prismarine
fill 178 141 339 178 145 339 minecraft:magenta_terracotta
setblock 178 141 363 minecraft:dark_prismarine
fill 179 141 323 179 144 323 minecraft:blue_terracotta
setblock 179 141 346 minecraft:blue_terracotta
setblock 179 141 347 minecraft:dark_prismarine
fill 179 141 348 179 144 348 minecraft:blue_terracotta
setblock 179 141 351 minecraft:blue_terracotta
setblock 179 141 352 minecraft:dark_prismarine
fill 179 141 353 179 143 354 minecraft:blue_terracotta
setblock 179 141 362 minecraft:dark_prismarine
fill 179 141 363 179 144 363 minecraft:blue_terracotta
setblock 180 141 326 minecraft:dark_prismarine
fill 180 141 327 180 142 328 minecraft:blue_terracotta
fill 180 141 329 180 162 330 minecraft:dark_prismarine
fill 180 141 343 180 141 345 minecraft:blue_terracotta
setblock 180 141 346 minecraft:dark_prismarine
fill 180 141 347 180 144 347 minecraft:blue_terracotta
setblock 180 141 351 minecraft:dark_prismarine
fill 180 141 352 180 144 352 minecraft:blue_terracotta
setblock 180 141 356 minecraft:dark_prismarine
fill 180 141 357 180 144 357 minecraft:blue_terracotta
fill 180 141 362 180 143 362 minecraft:blue_terracotta
setblock 181 141 325 minecraft:dark_prismarine
fill 181 141 326 181 144 326 minecraft:blue_terracotta
setblock 181 141 330 minecraft:dark_prismarine
fill 181 141 331 181 144 331 minecraft:blue_terracotta
fill 181 141 333 182 141 333 minecraft:blue_terracotta
setblock 181 141 340 minecraft:dark_prismarine
fill 181 141 341 181 143 341 minecraft:blue_terracotta
setblock 181 141 345 minecraft:dark_prismarine
fill 181 141 346 181 144 346 minecraft:blue_terracotta
setblock 181 141 350 minecraft:dark_prismarine
fill 181 141 351 181 144 351 minecraft:blue_terracotta
setblock 181 141 355 minecraft:dark_prismarine
fill 181 141 356 181 144 356 minecraft:blue_terracotta
setblock 181 141 360 minecraft:dark_prismarine
fill 181 141 361 181 143 361 minecraft:blue_terracotta
setblock 182 141 324 minecraft:dark_prismarine
fill 182 141 325 182 144 325 minecraft:blue_terracotta
setblock 182 141 329 minecraft:dark_prismarine
fill 182 141 330 182 144 330 minecraft:blue_terracotta
setblock 182 141 334 minecraft:dark_prismarine
fill 182 141 335 182 144 335 minecraft:blue_terracotta
setblock 182 141 339 minecraft:dark_prismarine
fill 182 141 340 182 144 340 minecraft:blue_terracotta
setblock 182 141 344 minecraft:dark_prismarine
fill 182 141 345 182 144 345 minecraft:blue_terracotta
setblock 182 141 349 minecraft:dark_prismarine
fill 182 141 350 182 144 350 minecraft:blue_terracotta
setblock 182 141 354 minecraft:dark_prismarine
fill 182 141 355 182 144 355 minecraft:blue_terracotta
setblock 182 141 359 minecraft:dark_prismarine
fill 182 141 360 182 144 360 minecraft:blue_terracotta
setblock 183 141 339 minecraft:cyan_concrete
fill 141 142 349 141 220 351 minecraft:blue_terracotta
setblock 141 142 352 minecraft:light_blue_wool
fill 141 142 353 141 150 356 minecraft:blue_terracotta
setblock 142 142 323 minecraft:dark_prismarine
fill 142 142 324 142 142 327 minecraft:blue_terracotta
setblock 142 142 328 minecraft:dark_prismarine
fill 142 142 329 142 145 329 minecraft:blue_terracotta
setblock 142 142 333 minecraft:dark_prismarine
fill 142 142 334 142 145 334 minecraft:blue_terracotta
setblock 142 142 338 minecraft:dark_prismarine
fill 142 142 339 142 145 339 minecraft:blue_terracotta
setblock 142 142 343 minecraft:dark_prismarine
fill 142 142 344 142 145 344 minecraft:blue_terracotta
setblock 142 142 348 minecraft:dark_prismarine
fill 142 142 349 142 145 349 minecraft:blue_terracotta
setblock 142 142 353 minecraft:sea_lantern
fill 142 142 354 142 145 354 minecraft:blue_terracotta
setblock 142 142 355 minecraft:sea_lantern
fill 142 142 356 142 143 356 minecraft:blue_terracotta
setblock 142 142 357 minecraft:sea_lantern
setblock 142 142 358 minecraft:dark_prismarine
setblock 142 142 359 minecraft:sea_lantern
setblock 142 142 361 minecraft:sea_lantern
setblock 142 142 363 minecraft:dark_prismarine
fill 143 142 323 143 142 326 minecraft:blue_terracotta
setblock 143 142 327 minecraft:dark_prismarine
fill 143 142 328 143 145 328 minecraft:blue_terracotta
setblock 143 142 331 minecraft:blue_terracotta
setblock 143 142 332 minecraft:dark_prismarine
fill 143 142 333 143 145 333 minecraft:blue_terracotta
setblock 143 142 337 minecraft:dark_prismarine
fill 143 142 338 143 145 338 minecraft:blue_terracotta
setblock 143 142 342 minecraft:dark_prismarine
fill 143 142 343 143 144 343 minecraft:blue_terracotta
setblock 143 142 347 minecraft:dark_prismarine
fill 143 142 348 143 145 348 minecraft:blue_terracotta
setblock 143 142 352 minecraft:dark_prismarine
fill 143 142 353 143 145 353 minecraft:blue_terracotta
setblock 143 142 354 minecraft:sea_lantern
fill 143 142 355 143 143 355 minecraft:blue_terracotta
setblock 143 142 356 minecraft:sea_lantern
setblock 143 142 358 minecraft:sea_lantern
setblock 143 142 360 minecraft:sea_lantern
fill 144 142 323 144 143 324 minecraft:blue_terracotta
setblock 144 142 326 minecraft:dark_prismarine
fill 144 142 327 144 143 327 minecraft:blue_terracotta
setblock 144 142 331 minecraft:dark_prismarine
fill 144 142 332 144 145 332 minecraft:blue_terracotta
setblock 144 142 342 minecraft:blue_terracotta
setblock 144 142 346 minecraft:dark_prismarine
fill 144 142 347 144 143 347 minecraft:blue_terracotta
setblock 144 142 351 minecraft:dark_prismarine
fill 144 142 352 144 143 352 minecraft:blue_terracotta
setblock 144 142 353 minecraft:sea_lantern
setblock 144 142 355 minecraft:sea_lantern
setblock 144 142 357 minecraft:sea_lantern
setblock 144 142 359 minecraft:sea_lantern
setblock 144 142 361 minecraft:sea_lantern
setblock 145 142 354 minecraft:sea_lantern
setblock 145 142 356 minecraft:sea_lantern
setblock 145 142 358 minecraft:sea_lantern
setblock 145 142 360 minecraft:sea_lantern
setblock 146 142 324 minecraft:dark_prismarine
setblock 146 142 353 minecraft:sea_lantern
setblock 146 142 355 minecraft:sea_lantern
setblock 146 142 357 minecraft:sea_lantern
setblock 146 142 359 minecraft:sea_lantern
setblock 146 142 361 minecraft:sea_lantern
setblock 147 142 323 minecraft:dark_prismarine
setblock 148 142 323 minecraft:blue_terracotta
fill 152 142 322 152 216 322 minecraft:blue_terracotta
setblock 152 142 323 minecraft:dark_prismarine
setblock 152 142 324 minecraft:blue_terracotta
fill 153 142 323 153 145 323 minecraft:blue_terracotta
setblock 155 142 324 minecraft:blue_terracotta
setblock 155 142 325 minecraft:dark_prismarine
setblock 156 142 324 minecraft:dark_prismarine
fill 156 142 325 156 145 325 minecraft:blue_terracotta
setblock 157 142 323 minecraft:dark_prismarine
fill 157 142 324 157 145 324 minecraft:blue_terracotta
setblock 157 142 363 minecraft:dark_prismarine
fill 158 142 323 158 145 323 minecraft:blue_terracotta
fill 158 142 363 158 145 363 minecraft:blue_terracotta
setblock 159 142 326 minecraft:dark_prismarine
setblock 159 142 327 minecraft:blue_terracotta
fill 159 142 362 162 142 362 minecraft:blue_terracotta
fill 159 142 364 159 220 364 minecraft:blue_terracotta
setblock 160 142 325 minecraft:dark_prismarine
fill 160 142 326 160 144 326 minecraft:blue_terracotta
setblock 161 142 324 minecraft:dark_prismarine
fill 161 142 325 161 145 325 minecraft:blue_terracotta
setblock 162 142 323 minecraft:dark_prismarine
fill 162 142 324 162 145 324 minecraft:blue_terracotta
setblock 162 142 327 minecraft:blue_terracotta
setblock 162 142 363 minecraft:dark_prismarine
fill 163 142 323 163 145 323 minecraft:blue_terracotta
setblock 163 142 362 minecraft:dark_prismarine
fill 163 142 363 163 145 363 minecraft:blue_terracotta
setblock 164 142 326 minecraft:dark_prismarine
fill 164 142 362 164 143 362 minecraft:blue_terracotta
fill 164 142 364 166 216 364 minecraft:blue_terracotta
setblock 165 142 325 minecraft:dark_prismarine
setblock 166 142 324 minecraft:dark_prismarine
setblock 166 142 325 minecraft:blue_terracotta
fill 167 142 322 168 216 322 minecraft:blue_terracotta
setblock 167 142 323 minecraft:dark_prismarine
fill 167 142 324 167 143 324 minecraft:blue_terracotta
setblock 167 142 363 minecraft:dark_prismarine
setblock 167 142 364 minecraft:light_blue_wool
fill 168 142 323 168 143 323 minecraft:blue_terracotta
fill 168 142 363 168 143 363 minecraft:blue_terracotta
setblock 169 142 322 minecraft:cyan_concrete
setblock 172 142 323 minecraft:dark_prismarine
setblock 172 142 363 minecraft:dark_prismarine
setblock 173 142 323 minecraft:blue_terracotta
fill 173 142 363 173 143 363 minecraft:blue_terracotta
fill 175 142 324 175 142 327 minecraft:purple_concrete
fill 176 142 327 176 142 339 minecraft:purple_concrete
setblock 177 142 323 minecraft:dark_prismarine
setblock 177 142 324 minecraft:blue_terracotta
fill 177 142 339 177 142 350 minecraft:purple_concrete
setblock 177 142 363 minecraft:dark_prismarine
fill 178 142 323 178 144 323 minecraft:blue_terracotta
fill 178 142 350 178 142 361 minecraft:purple_concrete
setblock 178 142 362 minecraft:dark_prismarine
fill 178 142 363 178 145 363 minecraft:blue_terracotta
setblock 179 142 346 minecraft:dark_prismarine
fill 179 142 347 179 143 347 minecraft:blue_terracotta
setblock 179 142 351 minecraft:dark_prismarine
fill 179 142 352 179 145 352 minecraft:blue_terracotta
setblock 179 142 361 minecraft:purple_concrete
fill 179 142 362 179 143 362 minecraft:blue_terracotta
setblock 180 142 324 minecraft:blue_terracotta
fill 180 142 343 180 142 344 minecraft:blue_terracotta
setblock 180 142 345 minecraft:dark_prismarine
fill 180 142 346 180 145 346 minecraft:blue_terracotta
setblock 180 142 350 minecraft:dark_prismarine
fill 180 142 351 180 145 351 minecraft:blue_terracotta
setblock 180 142 354 minecraft:blue_terracotta
setblock 180 142 355 minecraft:dark_prismarine
fill 180 142 356 180 145 356 minecraft:blue_terracotta
setblock 180 142 358 minecraft:blue_terracotta
setblock 181 142 324 minecraft:dark_prismarine
fill 181 142 325 181 143 325 minecraft:blue_terracotta
setblock 181 142 329 minecraft:dark_prismarine
fill 181 142 330 181 145 330 minecraft:blue_terracotta
setblock 181 142 333 minecraft:blue_terracotta
setblock 181 142 334 minecraft:dark_prismarine
fill 181 142 340 181 143 340 minecraft:blue_terracotta
setblock 181 142 344 minecraft:dark_prismarine
fill 181 142 345 181 145 345 minecraft:blue_terracotta
setblock 181 142 349 minecraft:dark_prismarine
fill 181 142 350 181 145 350 minecraft:blue_terracotta
setblock 181 142 354 minecraft:dark_prismarine
fill 181 142 355 181 145 355 minecraft:blue_terracotta
setblock 181 142 359 minecraft:dark_prismarine
fill 181 142 360 181 144 360 minecraft:blue_terracotta
setblock 182 142 323 minecraft:dark_prismarine
fill 182 142 324 182 144 324 minecraft:blue_terracotta
setblock 182 142 328 minecraft:dark_prismarine
fill 182 142 329 182 145 329 minecraft:blue_terracotta
setblock 182 142 333 minecraft:dark_prismarine
fill 182 142 334 182 145 334 minecraft:blue_terracotta
setblock 182 142 338 minecraft:dark_prismarine
fill 182 142 339 183 145 339 minecraft:blue_terracotta
setblock 182 142 343 minecraft:dark_prismarine
fill 182 142 344 182 145 344 minecraft:blue_terracotta
setblock 182 142 348 minecraft:dark_prismarine
fill 182 142 349 182 145 349 minecraft:blue_terracotta
setblock 182 142 353 minecraft:dark_prismarine
fill 182 142 354 182 145 354 minecraft:blue_terracotta
setblock 182 142 358 minecraft:dark_prismarine
fill 182 142 359 182 145 359 minecraft:blue_terracotta
setblock 182 142 363 minecraft:dark_prismarine
fill 141 143 352 141 220 352 minecraft:blue_terracotta
fill 142 143 323 142 143 326 minecraft:blue_terracotta
setblock 142 143 327 minecraft:dark_prismarine
fill 142 143 328 142 146 328 minecraft:blue_terracotta
setblock 142 143 332 minecraft:dark_prismarine
fill 142 143 333 142 146 333 minecraft:blue_terracotta
setblock 142 143 337 minecraft:dark_prismarine
fill 142 143 338 142 146 338 minecraft:blue_terracotta
setblock 142 143 342 minecraft:dark_prismarine
fill 142 143 343 142 146 343 minecraft:blue_terracotta
setblock 142 143 347 minecraft:dark_prismarine
fill 142 143 348 142 146 348 minecraft:blue_terracotta
setblock 142 143 352 minecraft:dark_prismarine
fill 142 143 353 142 144 353 minecraft:blue_terracotta
fill 142 143 355 142 144 355 minecraft:blue_terracotta
setblock 142 143 357 minecraft:dark_prismarine
fill 142 143 358 142 143 359 minecraft:blue_terracotta
fill 142 143 360 142 144 361 minecraft:dark_prismarine
fill 143 143 323 143 143 325 minecraft:blue_terracotta
setblock 143 143 326 minecraft:dark_prismarine
fill 143 143 327 143 145 327 minecraft:blue_terracotta
setblock 143 143 331 minecraft:dark_prismarine
fill 143 143 332 143 146 332 minecraft:blue_terracotta
setblock 143 143 336 minecraft:dark_prismarine
fill 143 143 337 143 146 337 minecraft:blue_terracotta
setblock 143 143 341 minecraft:dark_prismarine
fill 143 143 342 143 144 342 minecraft:blue_terracotta
setblock 143 143 346 minecraft:dark_prismarine
fill 143 143 347 143 145 347 minecraft:blue_terracotta
setblock 143 143 351 minecraft:dark_prismarine
fill 143 143 352 143 146 352 minecraft:blue_terracotta
fill 143 143 354 143 144 354 minecraft:blue_terracotta
fill 143 143 356 143 144 356 minecraft:dark_prismarine
fill 143 143 358 143 144 358 minecraft:dark_prismarine
fill 143 143 360 143 144 360 minecraft:dark_prismarine
setblock 144 143 325 minecraft:light[level=12]
setblock 144 143 330 minecraft:dark_prismarine
fill 144 143 331 144 145 331 minecraft:blue_terracotta
setblock 144 143 339 minecraft:light[level=12]
setblock 144 143 345 minecraft:dark_prismarine
setblock 144 143 346 minecraft:blue_terracotta
setblock 144 143 350 minecraft:dark_prismarine
setblock 144 143 351 minecraft:blue_terracotta
fill 144 143 353 144 144 353 minecraft:dark_prismarine
fill 144 143 355 144 144 355 minecraft:dark_prismarine
fill 144 143 357 144 144 357 minecraft:dark_prismarine
fill 144 143 359 144 144 359 minecraft:dark_prismarine
fill 144 143 361 144 144 361 minecraft:dark_prismarine
fill 145 143 354 145 144 354 minecraft:dark_prismarine
fill 145 143 356 145 144 356 minecraft:dark_prismarine
fill 145 143 358 145 144 358 minecraft:dark_prismarine
fill 145 143 360 145 144 360 minecraft:dark_prismarine
setblock 145 143 363 minecraft:purple_concrete
setblock 146 143 323 minecraft:dark_prismarine
fill 146 143 353 146 144 353 minecraft:dark_prismarine
fill 146 143 355 146 144 355 minecraft:dark_prismarine
fill 146 143 357 146 144 357 minecraft:dark_prismarine
fill 146 143 359 146 144 359 minecraft:dark_prismarine
fill 146 143 361 146 144 361 minecraft:dark_prismarine
fill 151 143 322 151 220 322 minecraft:blue_terracotta
setblock 151 143 323 minecraft:dark_prismarine
setblock 151 143 325 minecraft:light[level=12]
setblock 151 143 332 minecraft:light[level=12]
setblock 151 143 346 minecraft:light[level=12]
setblock 151 143 353 minecraft:light[level=12]
setblock 151 143 360 minecraft:light[level=12]
fill 152 143 323 152 144 323 minecraft:blue_terracotta
setblock 154 143 324 minecraft:blue_terracotta
setblock 155 143 324 minecraft:dark_prismarine
fill 155 143 325 155 144 325 minecraft:blue_terracotta
setblock 156 143 323 minecraft:dark_prismarine
fill 156 143 324 156 146 324 minecraft:blue_terracotta
fill 156 143 356 156 154 356 minecraft:magenta_terracotta
setblock 156 143 363 minecraft:dark_prismarine
fill 157 143 323 157 146 323 minecraft:blue_terracotta
fill 157 143 363 157 146 363 minecraft:blue_terracotta
setblock 158 143 326 minecraft:dark_prismarine
setblock 158 143 332 minecraft:light[level=12]
setblock 158 143 339 minecraft:light[level=12]
setblock 158 143 346 minecraft:light[level=12]
setblock 158 143 353 minecraft:light[level=12]
setblock 158 143 360 minecraft:light[level=12]
setblock 159 143 325 minecraft:dark_prismarine
fill 159 143 326 159 144 326 minecraft:blue_terracotta
setblock 160 143 324 minecraft:dark_prismarine
fill 160 143 325 160 146 325 minecraft:blue_terracotta
fill 160 143 362 161 143 362 minecraft:blue_terracotta
setblock 161 143 323 minecraft:dark_prismarine
fill 161 143 324 161 146 324 minecraft:blue_terracotta
setblock 161 143 363 minecraft:dark_prismarine
fill 162 143 323 162 146 323 minecraft:blue_terracotta
setblock 162 143 362 minecraft:dark_prismarine
fill 162 143 363 162 146 363 minecraft:blue_terracotta
setblock 163 143 326 minecraft:dark_prismarine
setblock 163 143 362 minecraft:blue_terracotta
setblock 164 143 325 minecraft:dark_prismarine
setblock 165 143 324 minecraft:dark_prismarine
setblock 165 143 325 minecraft:blue_terracotta
setblock 165 143 332 minecraft:light[level=12]
setblock 165 143 339 minecraft:light[level=12]
setblock 165 143 346 minecraft:light[level=12]
setblock 165 143 353 minecraft:light[level=12]
setblock 165 143 360 minecraft:light[level=12]
setblock 166 143 323 minecraft:dark_prismarine
setblock 166 143 324 minecraft:blue_terracotta
setblock 166 143 363 minecraft:dark_prismarine
fill 167 143 323 167 144 323 minecraft:blue_terracotta
fill 167 143 363 167 143 364 minecraft:blue_terracotta
fill 169 143 322 169 216 322 minecraft:blue_terracotta
setblock 170 143 363 minecraft:purple_concrete
setblock 172 143 325 minecraft:light[level=12]
setblock 172 143 332 minecraft:light[level=12]
setblock 172 143 339 minecraft:light[level=12]
setblock 172 143 346 minecraft:light[level=12]
setblock 172 143 353 minecraft:light[level=12]
setblock 172 143 360 minecraft:light[level=12]
setblock 176 143 323 minecraft:dark_prismarine
setblock 176 143 363 minecraft:dark_prismarine
fill 177 143 323 177 144 323 minecraft:blue_terracotta
fill 177 143 363 177 146 363 minecraft:blue_terracotta
setblock 178 143 362 minecraft:blue_terracotta
setblock 179 143 325 minecraft:light[level=12]
setblock 179 143 332 minecraft:light[level=12]
setblock 179 143 339 minecraft:light[level=12]
setblock 179 143 346 minecraft:light[level=12]
setblock 179 143 350 minecraft:dark_prismarine
fill 179 143 351 179 146 351 minecraft:blue_terracotta
setblock 179 143 355 minecraft:dark_prismarine
setblock 179 143 360 minecraft:light[level=12]
setblock 180 143 324 minecraft:dark_prismarine
fill 180 143 328 181 143 328 minecraft:dark_prismarine
setblock 180 143 344 minecraft:dark_prismarine
fill 180 143 345 180 144 345 minecraft:blue_terracotta
setblock 180 143 349 minecraft:dark_prismarine
fill 180 143 350 180 146 350 minecraft:blue_terracotta
setblock 180 143 354 minecraft:dark_prismarine
fill 180 143 355 180 146 355 minecraft:blue_terracotta
setblock 181 143 323 minecraft:dark_prismarine
setblock 181 143 324 minecraft:blue_terracotta
fill 181 143 329 181 146 329 minecraft:blue_terracotta
setblock 181 143 332 minecraft:blue_terracotta
setblock 181 143 333 minecraft:dark_prismarine
fill 181 143 334 181 145 335 minecraft:blue_terracotta
setblock 181 143 343 minecraft:dark_prismarine
fill 181 143 344 181 146 344 minecraft:blue_terracotta
setblock 181 143 348 minecraft:dark_prismarine
fill 181 143 349 181 146 349 minecraft:blue_terracotta
setblock 181 143 353 minecraft:dark_prismarine
fill 181 143 354 181 146 354 minecraft:blue_terracotta
setblock 181 143 358 minecraft:dark_prismarine
fill 181 143 359 181 145 359 minecraft:blue_terracotta
setblock 181 143 363 minecraft:dark_prismarine
fill 182 143 323 182 144 323 minecraft:blue_terracotta
setblock 182 143 327 minecraft:dark_prismarine
fill 182 143 328 182 146 328 minecraft:blue_terracotta
setblock 182 143 332 minecraft:dark_prismarine
fill 182 143 333 182 146 333 minecraft:blue_terracotta
setblock 182 143 337 minecraft:dark_prismarine
fill 182 143 338 182 146 338 minecraft:blue_terracotta
setblock 182 143 342 minecraft:dark_prismarine
fill 182 143 343 182 146 343 minecraft:blue_terracotta
setblock 182 143 347 minecraft:dark_prismarine
fill 182 143 348 182 146 348 minecraft:blue_terracotta
setblock 182 143 352 minecraft:dark_prismarine
fill 182 143 353 182 146 353 minecraft:blue_terracotta
setblock 182 143 357 minecraft:dark_prismarine
fill 182 143 358 182 146 358 minecraft:blue_terracotta
setblock 182 143 362 minecraft:dark_prismarine
fill 182 143 363 182 144 363 minecraft:blue_terracotta
setblock 183 143 355 minecraft:cyan_concrete
fill 183 143 356 183 221 356 minecraft:blue_terracotta
fill 142 144 322 142 144 325 minecraft:blue_terracotta
setblock 142 144 326 minecraft:dark_prismarine
fill 142 144 327 142 147 327 minecraft:blue_terracotta
setblock 142 144 331 minecraft:dark_prismarine
fill 142 144 332 142 147 332 minecraft:blue_terracotta
setblock 142 144 336 minecraft:dark_prismarine
fill 142 144 337 142 147 337 minecraft:blue_terracotta
setblock 142 144 341 minecraft:dark_prismarine
fill 142 144 342 142 147 342 minecraft:blue_terracotta
setblock 142 144 346 minecraft:dark_prismarine
fill 142 144 347 142 147 347 minecraft:blue_terracotta
setblock 142 144 351 minecraft:dark_prismarine
fill 142 144 352 142 147 352 minecraft:blue_terracotta
setblock 142 144 356 minecraft:dark_prismarine
fill 142 144 357 142 144 358 minecraft:blue_terracotta
setblock 142 144 359 minecraft:dark_prismarine
fill 143 144 322 144 144 323 minecraft:blue_terracotta
setblock 143 144 325 minecraft:dark_prismarine
fill 143 144 326 143 145 326 minecraft:blue_terracotta
setblock 143 144 330 minecraft:dark_prismarine
fill 143 144 331 143 147 331 minecraft:blue_terracotta
setblock 143 144 334 minecraft:blue_terracotta
setblock 143 144 335 minecraft:dark_prismarine
fill 143 144 336 143 147 336 minecraft:blue_terracotta
setblock 143 144 340 minecraft:dark_prismarine
setblock 143 144 341 minecraft:blue_terracotta
setblock 143 144 345 minecraft:dark_prismarine
fill 143 144 346 143 145 346 minecraft:blue_terracotta
setblock 143 144 350 minecraft:dark_prismarine
fill 143 144 351 143 146 351 minecraft:blue_terracotta
fill 143 144 355 143 162 355 minecraft:dark_prismarine
setblock 144 144 329 minecraft:dark_prismarine
fill 144 144 330 144 145 330 minecraft:blue_terracotta
setblock 145 144 322 minecraft:cyan_concrete
fill 146 144 322 147 218 322 minecraft:blue_terracotta
setblock 148 144 323 minecraft:purple_concrete
fill 150 144 334 150 150 335 minecraft:magenta_terracotta
fill 151 144 342 152 145 343 minecraft:dark_prismarine
setblock 151 144 363 minecraft:purple_concrete
setblock 154 144 324 minecraft:dark_prismarine
setblock 155 144 323 minecraft:dark_prismarine
fill 155 144 324 155 147 324 minecraft:blue_terracotta
fill 156 144 323 156 147 323 minecraft:blue_terracotta
setblock 157 144 326 minecraft:dark_prismarine
setblock 158 144 325 minecraft:dark_prismarine
setblock 158 144 326 minecraft:blue_terracotta
setblock 159 144 324 minecraft:dark_prismarine
fill 159 144 325 159 146 325 minecraft:blue_terracotta
setblock 160 144 323 minecraft:dark_prismarine
fill 160 144 324 160 147 324 minecraft:blue_terracotta
setblock 160 144 362 minecraft:blue_terracotta
setblock 160 144 363 minecraft:dark_prismarine
fill 161 144 323 161 147 323 minecraft:blue_terracotta
setblock 161 144 362 minecraft:dark_prismarine
fill 161 144 363 161 147 363 minecraft:blue_terracotta
setblock 162 144 362 minecraft:blue_terracotta
setblock 163 144 325 minecraft:dark_prismarine
setblock 164 144 324 minecraft:dark_prismarine
setblock 164 144 325 minecraft:blue_terracotta
setblock 165 144 323 minecraft:dark_prismarine
setblock 165 144 324 minecraft:blue_terracotta
setblock 165 144 363 minecraft:dark_prismarine
fill 166 144 323 166 145 323 minecraft:blue_terracotta
setblock 166 144 363 minecraft:blue_terracotta
fill 167 144 364 167 220 364 minecraft:blue_terracotta
fill 171 144 351 171 171 351 minecraft:magenta_terracotta
setblock 173 144 323 minecraft:purple_concrete
setblock 175 144 363 minecraft:dark_prismarine
setblock 176 144 323 minecraft:blue_terracotta
fill 176 144 363 176 147 363 minecraft:blue_terracotta
setblock 179 144 349 minecraft:dark_prismarine
fill 179 144 350 179 146 350 minecraft:blue_terracotta
setblock 179 144 353 minecraft:blue_terracotta
setblock 179 144 354 minecraft:dark_prismarine
fill 179 144 355 179 146 355 minecraft:blue_terracotta
setblock 180 144 323 minecraft:dark_prismarine
fill 180 144 328 180 162 328 minecraft:dark_prismarine
setblock 180 144 348 minecraft:dark_prismarine
fill 180 144 349 180 147 349 minecraft:blue_terracotta
setblock 180 144 353 minecraft:dark_prismarine
fill 180 144 354 180 147 354 minecraft:blue_terracotta
setblock 180 144 363 minecraft:dark_prismarine
setblock 181 144 323 minecraft:blue_terracotta
setblock 181 144 327 minecraft:dark_prismarine
fill 181 144 328 181 145 328 minecraft:blue_terracotta
setblock 181 144 332 minecraft:dark_prismarine
fill 181 144 333 181 147 333 minecraft:blue_terracotta
setblock 181 144 342 minecraft:dark_prismarine
fill 181 144 343 181 145 343 minecraft:blue_terracotta
setblock 181 144 347 minecraft:dark_prismarine
fill 181 144 348 181 147 348 minecraft:blue_terracotta
setblock 181 144 352 minecraft:dark_prismarine
fill 181 144 353 181 147 353 minecraft:blue_terracotta
setblock 181 144 357 minecraft:dark_prismarine
fill 181 144 358 181 147 358 minecraft:blue_terracotta
fill 181 144 363 181 145 363 minecraft:blue_terracotta
setblock 182 144 326 minecraft:dark_prismarine
fill 182 144 327 182 146 327 minecraft:blue_terracotta
setblock 182 144 331 minecraft:dark_prismarine
fill 182 144 332 182 147 332 minecraft:blue_terracotta
setblock 182 144 336 minecraft:dark_prismarine
fill 182 144 337 182 147 337 minecraft:blue_terracotta
setblock 182 144 341 minecraft:dark_prismarine
fill 182 144 342 182 147 342 minecraft:blue_terracotta
setblock 182 144 346 minecraft:dark_prismarine
fill 182 144 347 182 147 347 minecraft:blue_terracotta
setblock 182 144 351 minecraft:dark_prismarine
fill 182 144 352 182 147 352 minecraft:blue_terracotta
setblock 182 144 356 minecraft:dark_prismarine
fill 182 144 357 182 147 357 minecraft:blue_terracotta
setblock 182 144 361 minecraft:dark_prismarine
setblock 182 144 362 minecraft:blue_terracotta
fill 183 144 355 183 220 355 minecraft:blue_terracotta
fill 141 145 346 142 148 346 minecraft:blue_terracotta
setblock 141 145 347 minecraft:cyan_concrete
fill 142 145 322 145 166 322 minecraft:blue_terracotta
setblock 142 145 324 minecraft:blue_terracotta
setblock 142 145 325 minecraft:dark_prismarine
fill 142 145 326 142 147 326 minecraft:blue_terracotta
setblock 142 145 330 minecraft:dark_prismarine
fill 142 145 331 142 148 331 minecraft:blue_terracotta
setblock 142 145 335 minecraft:dark_prismarine
fill 142 145 336 142 148 336 minecraft:blue_terracotta
setblock 142 145 340 minecraft:dark_prismarine
fill 142 145 341 142 148 341 minecraft:blue_terracotta
setblock 142 145 345 minecraft:dark_prismarine
setblock 142 145 350 minecraft:dark_prismarine
fill 142 145 351 142 148 351 minecraft:blue_terracotta
setblock 142 145 353 minecraft:sea_lantern
setblock 142 145 355 minecraft:sea_lantern
fill 142 145 356 142 148 356 minecraft:blue_terracotta
setblock 142 145 357 minecraft:sea_lantern
fill 142 145 358 142 147 358 minecraft:dark_prismarine
setblock 142 145 359 minecraft:sea_lantern
fill 142 145 360 142 153 360 minecraft:dark_prismarine
setblock 142 145 361 minecraft:sea_lantern
setblock 143 145 329 minecraft:dark_prismarine
fill 143 145 330 143 148 330 minecraft:blue_terracotta
setblock 143 145 334 minecraft:dark_prismarine
fill 143 145 335 143 148 335 minecraft:blue_terracotta
setblock 143 145 345 minecraft:blue_terracotta
setblock 143 145 349 minecraft:dark_prismarine
fill 143 145 350 143 146 350 minecraft:blue_terracotta
setblock 143 145 354 minecraft:sea_lantern
setblock 143 145 356 minecraft:sea_lantern
setblock 143 145 358 minecraft:sea_lantern
setblock 143 145 360 minecraft:sea_lantern
setblock 144 145 353 minecraft:sea_lantern
setblock 144 145 355 minecraft:sea_lantern
setblock 144 145 357 minecraft:sea_lantern
setblock 144 145 359 minecraft:sea_lantern
setblock 144 145 361 minecraft:sea_lantern
setblock 145 145 354 minecraft:sea_lantern
setblock 145 145 356 minecraft:sea_lantern
setblock 145 145 358 minecraft:sea_lantern
setblock 145 145 360 minecraft:sea_lantern
setblock 146 145 353 minecraft:sea_lantern
setblock 146 145 355 minecraft:sea_lantern
setblock 146 145 357 minecraft:sea_lantern
setblock 146 145 359 minecraft:sea_lantern
setblock 146 145 361 minecraft:sea_lantern
setblock 154 145 323 minecraft:dark_prismarine
setblock 154 145 324 minecraft:blue_terracotta
fill 155 145 323 155 148 323 minecraft:blue_terracotta
setblock 157 145 325 minecraft:dark_prismarine
setblock 158 145 324 minecraft:dark_prismarine
fill 158 145 325 158 146 325 minecraft:blue_terracotta
setblock 159 145 323 minecraft:dark_prismarine
fill 159 145 324 159 148 324 minecraft:blue_terracotta
setblock 159 145 363 minecraft:dark_prismarine
fill 160 145 323 160 148 323 minecraft:blue_terracotta
fill 160 145 363 160 148 363 minecraft:blue_terracotta
setblock 162 145 325 minecraft:dark_prismarine
setblock 163 145 324 minecraft:dark_prismarine
setblock 164 145 323 minecraft:dark_prismarine
setblock 164 145 324 minecraft:blue_terracotta
setblock 164 145 363 minecraft:dark_prismarine
setblock 165 145 323 minecraft:blue_terracotta
setblock 165 145 363 minecraft:blue_terracotta
setblock 167 145 323 minecraft:purple_concrete
fill 168 145 328 168 186 328 minecraft:magenta_terracotta
setblock 175 145 363 minecraft:blue_terracotta
setblock 179 145 323 minecraft:dark_prismarine
setblock 179 145 349 minecraft:blue_terracotta
setblock 179 145 353 minecraft:dark_prismarine
fill 179 145 354 179 148 354 minecraft:blue_terracotta
setblock 179 145 363 minecraft:dark_prismarine
setblock 180 145 347 minecraft:dark_prismarine
fill 180 145 348 180 147 348 minecraft:blue_terracotta
setblock 180 145 352 minecraft:dark_prismarine
fill 180 145 353 180 148 353 minecraft:blue_terracotta
setblock 180 145 357 minecraft:dark_prismarine
setblock 180 145 363 minecraft:blue_terracotta
setblock 181 145 331 minecraft:dark_prismarine
fill 181 145 332 181 148 332 minecraft:blue_terracotta
setblock 181 145 346 minecraft:dark_prismarine
fill 181 145 347 181 148 347 minecraft:blue_terracotta
setblock 181 145 351 minecraft:dark_prismarine
fill 181 145 352 181 148 352 minecraft:blue_terracotta
setblock 181 145 356 minecraft:dark_prismarine
fill 181 145 357 181 148 357 minecraft:blue_terracotta
setblock 182 145 325 minecraft:dark_prismarine
fill 182 145 326 182 146 326 minecraft:blue_terracotta
setblock 182 145 330 minecraft:dark_prismarine
fill 182 145 331 182 148 331 minecraft:blue_terracotta
setblock 182 145 335 minecraft:dark_prismarine
fill 182 145 336 182 148 336 minecraft:blue_terracotta
setblock 182 145 340 minecraft:dark_prismarine
fill 182 145 341 182 148 341 minecraft:blue_terracotta
setblock 182 145 345 minecraft:dark_prismarine
fill 182 145 346 182 148 346 minecraft:blue_terracotta
setblock 182 145 350 minecraft:dark_prismarine
fill 182 145 351 182 148 351 minecraft:blue_terracotta
setblock 182 145 355 minecraft:dark_prismarine
fill 182 145 356 182 148 356 minecraft:blue_terracotta
setblock 182 145 360 minecraft:dark_prismarine
setblock 182 145 361 minecraft:blue_terracotta
setblock 182 145 363 minecraft:purple_concrete
fill 141 146 347 141 220 347 minecraft:blue_terracotta
setblock 142 146 325 minecraft:blue_terracotta
setblock 142 146 329 minecraft:dark_prismarine
fill 142 146 330 142 149 330 minecraft:blue_terracotta
setblock 142 146 334 minecraft:dark_prismarine
fill 142 146 335 142 149 335 minecraft:blue_terracotta
setblock 142 146 339 minecraft:dark_prismarine
fill 142 146 340 142 149 340 minecraft:blue_terracotta
setblock 142 146 344 minecraft:dark_prismarine
fill 142 146 345 142 147 345 minecraft:blue_terracotta
setblock 142 146 349 minecraft:dark_prismarine
fill 142 146 350 142 149 350 minecraft:blue_terracotta
setblock 142 146 353 minecraft:blue_terracotta
fill 142 146 354 143 146 354 minecraft:dark_prismarine
fill 142 146 355 142 147 355 minecraft:blue_terracotta
fill 142 146 357 142 147 357 minecraft:blue_terracotta
fill 142 146 359 142 147 359 minecraft:dark_prismarine
fill 142 146 361 142 147 361 minecraft:dark_prismarine
setblock 143 146 328 minecraft:dark_prismarine
fill 143 146 329 143 148 329 minecraft:blue_terracotta
setblock 143 146 333 minecraft:dark_prismarine
fill 143 146 334 143 149 334 minecraft:blue_terracotta
setblock 143 146 348 minecraft:dark_prismarine
setblock 143 146 349 minecraft:blue_terracotta
fill 143 146 353 144 147 353 minecraft:dark_prismarine
fill 143 146 356 143 147 356 minecraft:dark_prismarine
fill 143 146 358 143 147 358 minecraft:dark_prismarine
fill 143 146 360 143 147 360 minecraft:dark_prismarine
fill 144 146 355 144 147 355 minecraft:dark_prismarine
fill 144 146 357 144 147 357 minecraft:dark_prismarine
fill 144 146 359 144 147 359 minecraft:dark_prismarine
fill 144 146 361 144 147 361 minecraft:dark_prismarine
setblock 144 146 363 minecraft:purple_concrete
fill 145 146 323 147 147 323 minecraft:dark_prismarine
fill 145 146 349 145 154 349 minecraft:magenta_terracotta
fill 145 146 354 145 147 354 minecraft:dark_prismarine
fill 145 146 356 145 147 356 minecraft:dark_prismarine
fill 145 146 358 145 147 358 minecraft:dark_prismarine
fill 145 146 360 145 147 360 minecraft:dark_prismarine
fill 145 146 362 147 147 363 minecraft:dark_prismarine
fill 146 146 353 146 147 353 minecraft:dark_prismarine
fill 146 146 355 146 147 355 minecraft:dark_prismarine
fill 146 146 357 146 147 357 minecraft:dark_prismarine
fill 146 146 359 146 147 359 minecraft:dark_prismarine
fill 146 146 361 146 147 361 minecraft:dark_prismarine
setblock 153 146 323 minecraft:dark_prismarine
fill 154 146 323 154 149 323 minecraft:blue_terracotta
fill 156 146 363 156 147 363 minecraft:blue_terracotta
setblock 157 146 324 minecraft:dark_prismarine
setblock 157 146 325 minecraft:blue_terracotta
setblock 158 146 323 minecraft:dark_prismarine
fill 158 146 324 158 149 324 minecraft:blue_terracotta
setblock 158 146 363 minecraft:dark_prismarine
fill 159 146 323 159 149 323 minecraft:blue_terracotta
fill 159 146 363 159 149 363 minecraft:blue_terracotta
setblock 162 146 324 minecraft:dark_prismarine
setblock 163 146 323 minecraft:dark_prismarine
setblock 163 146 363 minecraft:dark_prismarine
setblock 164 146 323 minecraft:blue_terracotta
setblock 164 146 363 minecraft:blue_terracotta
fill 169 146 363 169 147 363 minecraft:purple_concrete
fill 174 146 351 174 147 351 minecraft:magenta_terracotta
setblock 178 146 363 minecraft:dark_prismarine
setblock 179 146 352 minecraft:dark_prismarine
fill 179 146 353 179 149 353 minecraft:blue_terracotta
setblock 179 146 363 minecraft:blue_terracotta
setblock 180 146 323 minecraft:purple_concrete
setblock 180 146 347 minecraft:blue_terracotta
setblock 180 146 351 minecraft:dark_prismarine
fill 180 146 352 180 149 352 minecraft:blue_terracotta
setblock 180 146 356 minecraft:dark_prismarine
fill 180 146 357 180 149 357 minecraft:blue_terracotta
setblock 181 146 330 minecraft:dark_prismarine
fill 181 146 331 181 149 331 minecraft:blue_terracotta
setblock 181 146 334 minecraft:blue_terracotta
setblock 181 146 335 minecraft:dark_prismarine
fill 181 146 336 181 149 336 minecraft:blue_terracotta
setblock 181 146 345 minecraft:dark_prismarine
fill 181 146 346 181 148 346 minecraft:blue_terracotta
setblock 181 146 350 minecraft:dark_prismarine
fill 181 146 351 181 149 351 minecraft:blue_terracotta
setblock 181 146 355 minecraft:dark_prismarine
fill 181 146 356 181 149 356 minecraft:blue_terracotta
setblock 182 146 329 minecraft:dark_prismarine
fill 182 146 330 182 149 330 minecraft:blue_terracotta
setblock 182 146 334 minecraft:dark_prismarine
fill 182 146 335 182 149 335 minecraft:blue_terracotta
setblock 182 146 339 minecraft:dark_prismarine
fill 182 146 340 182 149 340 minecraft:blue_terracotta
setblock 182 146 344 minecraft:dark_prismarine
fill 182 146 345 182 149 345 minecraft:blue_terracotta
setblock 182 146 349 minecraft:dark_prismarine
fill 182 146 350 182 149 350 minecraft:blue_terracotta
setblock 182 146 354 minecraft:dark_prismarine
fill 182 146 355 182 149 355 minecraft:blue_terracotta
setblock 182 146 359 minecraft:dark_prismarine
setblock 182 146 360 minecraft:blue_terracotta
fill 183 146 339 183 220 339 minecraft:blue_terracotta
setblock 142 147 328 minecraft:dark_prismarine
fill 142 147 329 142 150 329 minecraft:blue_terracotta
setblock 142 147 333 minecraft:dark_prismarine
fill 142 147 334 142 150 334 minecraft:blue_terracotta
setblock 142 147 338 minecraft:dark_prismarine
fill 142 147 339 142 150 339 minecraft:blue_terracotta
setblock 142 147 343 minecraft:dark_prismarine
setblock 142 147 344 minecraft:blue_terracotta
setblock 142 147 348 minecraft:dark_prismarine
fill 142 147 349 142 149 349 minecraft:blue_terracotta
setblock 142 147 353 minecraft:dark_prismarine
fill 142 147 354 142 150 354 minecraft:blue_terracotta
setblock 143 147 332 minecraft:dark_prismarine
fill 143 147 333 143 150 333 minecraft:blue_terracotta
setblock 143 147 337 minecraft:dark_prismarine
setblock 143 147 354 minecraft:dark_prismarine
fill 145 147 324 147 148 324 minecraft:dark_prismarine
fill 146 147 325 146 150 325 minecraft:dark_prismarine
fill 147 147 361 147 148 361 minecraft:dark_prismarine
setblock 149 147 323 minecraft:purple_concrete
setblock 150 147 363 minecraft:purple_concrete
fill 153 147 323 153 150 323 minecraft:blue_terracotta
setblock 156 147 324 minecraft:dark_prismarine
setblock 157 147 323 minecraft:dark_prismarine
fill 157 147 324 157 150 324 minecraft:blue_terracotta
setblock 157 147 363 minecraft:dark_prismarine
fill 158 147 323 158 150 323 minecraft:blue_terracotta
fill 158 147 363 158 150 363 minecraft:blue_terracotta
setblock 161 147 324 minecraft:dark_prismarine
setblock 162 147 323 minecraft:dark_prismarine
setblock 162 147 363 minecraft:dark_prismarine
setblock 163 147 323 minecraft:blue_terracotta
fill 163 147 363 163 150 363 minecraft:blue_terracotta
fill 171 147 352 171 160 352 minecraft:magenta_terracotta
setblock 174 147 323 minecraft:purple_concrete
setblock 175 147 363 minecraft:purple_concrete
setblock 177 147 363 minecraft:dark_prismarine
fill 178 147 363 178 150 363 minecraft:blue_terracotta
setblock 179 147 351 minecraft:dark_prismarine
fill 179 147 352 179 148 352 minecraft:blue_terracotta
setblock 180 147 350 minecraft:dark_prismarine
fill 180 147 351 180 150 351 minecraft:blue_terracotta
setblock 180 147 355 minecraft:dark_prismarine
fill 180 147 356 180 150 356 minecraft:blue_terracotta
setblock 181 147 330 minecraft:blue_terracotta
setblock 181 147 334 minecraft:dark_prismarine
fill 181 147 335 181 150 335 minecraft:blue_terracotta
setblock 181 147 345 minecraft:blue_terracotta
setblock 181 147 349 minecraft:dark_prismarine
fill 181 147 350 181 150 350 minecraft:blue_terracotta
setblock 181 147 354 minecraft:dark_prismarine
fill 181 147 355 181 150 355 minecraft:blue_terracotta
setblock 182 147 328 minecraft:dark_prismarine
fill 182 147 329 182 149 329 minecraft:blue_terracotta
setblock 182 147 333 minecraft:dark_prismarine
fill 182 147 334 182 150 334 minecraft:blue_terracotta
setblock 182 147 338 minecraft:dark_prismarine
fill 182 147 339 182 150 339 minecraft:blue_terracotta
setblock 182 147 343 minecraft:dark_prismarine
fill 182 147 344 182 150 344 minecraft:blue_terracotta
setblock 182 147 348 minecraft:dark_prismarine
fill 182 147 349 182 150 349 minecraft:blue_terracotta
setblock 182 147 353 minecraft:dark_prismarine
fill 182 147 354 182 150 354 minecraft:blue_terracotta
setblock 182 147 358 minecraft:dark_prismarine
fill 182 147 359 182 150 359 minecraft:blue_terracotta
setblock 142 148 327 minecraft:dark_prismarine
fill 142 148 328 142 151 328 minecraft:blue_terracotta
setblock 142 148 332 minecraft:dark_prismarine
fill 142 148 333 142 151 333 minecraft:blue_terracotta
setblock 142 148 337 minecraft:dark_prismarine
fill 142 148 338 142 151 338 minecraft:blue_terracotta
setblock 142 148 342 minecraft:dark_prismarine
setblock 142 148 347 minecraft:dark_prismarine
setblock 142 148 348 minecraft:blue_terracotta
setblock 142 148 352 minecraft:dark_prismarine
setblock 142 148 353 minecraft:sea_lantern
setblock 142 148 355 minecraft:sea_lantern
setblock 142 148 357 minecraft:sea_lantern
setblock 142 148 358 minecraft:purple_concrete
setblock 142 148 359 minecraft:sea_lantern
setblock 142 148 361 minecraft:sea_lantern
setblock 143 148 323 minecraft:purple_concrete
setblock 143 148 331 minecraft:dark_prismarine
fill 143 148 332 143 151 332 minecraft:blue_terracotta
setblock 143 148 336 minecraft:dark_prismarine
fill 143 148 337 143 151 337 minecraft:blue_terracotta
fill 143 148 353 143 162 353 minecraft:dark_prismarine
setblock 143 148 354 minecraft:sea_lantern
setblock 143 148 356 minecraft:sea_lantern
setblock 143 148 358 minecraft:sea_lantern
setblock 143 148 360 minecraft:sea_lantern
setblock 144 148 353 minecraft:sea_lantern
setblock 144 148 355 minecraft:sea_lantern
setblock 144 148 357 minecraft:sea_lantern
setblock 144 148 359 minecraft:sea_lantern
setblock 144 148 361 minecraft:sea_lantern
fill 145 148 325 145 149 325 minecraft:dark_prismarine
setblock 145 148 354 minecraft:sea_lantern
setblock 145 148 356 minecraft:sea_lantern
setblock 145 148 358 minecraft:sea_lantern
setblock 145 148 360 minecraft:sea_lantern
setblock 146 148 323 minecraft:dark_prismarine
fill 146 148 326 146 150 326 minecraft:dark_prismarine
setblock 146 148 353 minecraft:sea_lantern
setblock 146 148 355 minecraft:sea_lantern
setblock 146 148 357 minecraft:sea_lantern
setblock 146 148 359 minecraft:sea_lantern
setblock 146 148 361 minecraft:sea_lantern
setblock 146 148 362 minecraft:dark_prismarine
setblock 146 148 363 minecraft:purple_concrete
fill 147 148 325 147 149 325 minecraft:dark_prismarine
fill 147 148 360 147 149 360 minecraft:dark_prismarine
setblock 155 148 324 minecraft:dark_prismarine
setblock 155 148 363 minecraft:blue_terracotta
setblock 156 148 323 minecraft:dark_prismarine
fill 156 148 324 156 151 324 minecraft:blue_terracotta
setblock 156 148 363 minecraft:dark_prismarine
fill 157 148 323 157 151 323 minecraft:blue_terracotta
fill 157 148 363 157 151 363 minecraft:blue_terracotta
setblock 160 148 324 minecraft:dark_prismarine
setblock 161 148 323 minecraft:dark_prismarine
setblock 161 148 363 minecraft:dark_prismarine
setblock 162 148 323 minecraft:blue_terracotta
fill 162 148 363 162 151 363 minecraft:blue_terracotta
setblock 168 148 323 minecraft:purple_concrete
setblock 175 148 363 minecraft:blue_terracotta
setblock 176 148 363 minecraft:dark_prismarine
fill 177 148 363 177 151 363 minecraft:blue_terracotta
fill 178 148 339 178 204 339 minecraft:magenta_terracotta
setblock 180 148 349 minecraft:dark_prismarine
fill 180 148 350 180 149 350 minecraft:blue_terracotta
setblock 180 148 354 minecraft:dark_prismarine
fill 180 148 355 180 151 355 minecraft:blue_terracotta
setblock 181 148 333 minecraft:dark_prismarine
fill 181 148 334 181 151 334 minecraft:blue_terracotta
setblock 181 148 337 minecraft:blue_terracotta
setblock 181 148 348 minecraft:dark_prismarine
fill 181 148 349 181 151 349 minecraft:blue_terracotta
setblock 181 148 353 minecraft:dark_prismarine
fill 181 148 354 181 151 354 minecraft:blue_terracotta
setblock 181 148 358 minecraft:dark_prismarine
setblock 181 148 363 minecraft:purple_concrete
setblock 182 148 328 minecraft:purple_concrete
setblock 182 148 332 minecraft:dark_prismarine
fill 182 148 333 182 151 333 minecraft:blue_terracotta
setblock 182 148 337 minecraft:dark_prismarine
fill 182 148 338 182 151 338 minecraft:blue_terracotta
setblock 182 148 342 minecraft:dark_prismarine
fill 182 148 343 182 151 343 minecraft:blue_terracotta
setblock 182 148 347 minecraft:dark_prismarine
fill 182 148 348 182 151 348 minecraft:blue_terracotta
setblock 182 148 352 minecraft:dark_prismarine
fill 182 148 353 182 151 353 minecraft:blue_terracotta
setblock 182 148 357 minecraft:dark_prismarine
fill 182 148 358 182 151 358 minecraft:blue_terracotta
setblock 183 148 353 minecraft:light_blue_wool
fill 141 149 346 141 220 346 minecraft:blue_terracotta
fill 142 149 327 142 150 327 minecraft:blue_terracotta
setblock 142 149 331 minecraft:dark_prismarine
fill 142 149 332 142 152 332 minecraft:blue_terracotta
setblock 142 149 336 minecraft:dark_prismarine
fill 142 149 337 142 152 337 minecraft:blue_terracotta
setblock 142 149 341 minecraft:dark_prismarine
fill 142 149 342 142 152 342 minecraft:blue_terracotta
setblock 142 149 351 minecraft:dark_prismarine
fill 142 149 352 142 150 353 minecraft:blue_terracotta
setblock 142 149 355 minecraft:blue_terracotta
fill 142 149 356 143 149 356 minecraft:dark_prismarine
fill 142 149 357 142 150 357 minecraft:blue_terracotta
fill 142 149 358 142 150 359 minecraft:dark_prismarine
fill 142 149 361 142 150 361 minecraft:dark_prismarine
setblock 143 149 330 minecraft:dark_prismarine
fill 143 149 331 143 152 331 minecraft:blue_terracotta
setblock 143 149 335 minecraft:dark_prismarine
fill 143 149 336 143 152 336 minecraft:blue_terracotta
fill 143 149 354 143 150 354 minecraft:dark_prismarine
fill 143 149 358 143 150 358 minecraft:dark_prismarine
fill 143 149 360 143 150 360 minecraft:dark_prismarine
setblock 143 149 363 minecraft:purple_concrete
setblock 144 149 325 minecraft:light[level=13]
setblock 144 149 332 minecraft:light[level=12]
setblock 144 149 333 minecraft:light[level=13]
setblock 144 149 339 minecraft:light[level=12]
setblock 144 149 341 minecraft:light[level=13]
setblock 144 149 346 minecraft:light[level=12]
setblock 144 149 349 minecraft:light[level=13]
fill 144 149 353 144 150 353 minecraft:dark_prismarine
fill 144 149 355 144 150 355 minecraft:dark_prismarine
fill 144 149 357 144 150 357 minecraft:dark_prismarine
fill 144 149 359 144 150 359 minecraft:dark_prismarine
fill 144 149 361 144 150 361 minecraft:dark_prismarine
fill 145 149 326 145 150 327 minecraft:dark_prismarine
fill 145 149 354 145 150 354 minecraft:dark_prismarine
fill 145 149 356 145 150 356 minecraft:dark_prismarine
fill 145 149 358 145 150 358 minecraft:dark_prismarine
fill 145 149 360 145 150 360 minecraft:dark_prismarine
setblock 146 149 323 minecraft:purple_concrete
setblock 146 149 324 minecraft:dark_prismarine
fill 146 149 327 147 150 327 minecraft:dark_prismarine
fill 146 149 353 146 150 353 minecraft:dark_prismarine
fill 146 149 355 146 150 355 minecraft:dark_prismarine
fill 146 149 357 146 150 357 minecraft:dark_prismarine
fill 146 149 359 147 150 359 minecraft:dark_prismarine
fill 146 149 361 146 150 361 minecraft:dark_prismarine
setblock 146 149 362 minecraft:purple_concrete
fill 147 149 326 147 150 326 minecraft:dark_prismarine
fill 147 149 358 147 150 358 minecraft:dark_prismarine
setblock 151 149 325 minecraft:light[level=12]
setblock 151 149 332 minecraft:light[level=12]
setblock 151 149 346 minecraft:light[level=12]
setblock 151 149 353 minecraft:light[level=12]
setblock 151 149 360 minecraft:light[level=12]
fill 152 149 323 152 151 323 minecraft:blue_terracotta
setblock 152 149 325 minecraft:light[level=13]
setblock 152 149 333 minecraft:light[level=13]
setblock 152 149 349 minecraft:light[level=13]
setblock 152 149 357 minecraft:light[level=13]
setblock 154 149 363 minecraft:blue_terracotta
setblock 155 149 323 minecraft:dark_prismarine
fill 155 149 324 155 152 324 minecraft:blue_terracotta
setblock 155 149 363 minecraft:dark_prismarine
fill 156 149 323 156 152 323 minecraft:blue_terracotta
fill 156 149 363 156 152 363 minecraft:blue_terracotta
fill 157 149 362 160 149 362 minecraft:blue_terracotta
setblock 158 149 325 minecraft:light[level=12]
setblock 158 149 332 minecraft:light[level=12]
setblock 158 149 339 minecraft:light[level=12]
setblock 158 149 346 minecraft:light[level=12]
setblock 158 149 353 minecraft:light[level=12]
setblock 158 149 360 minecraft:light[level=12]
setblock 159 149 324 minecraft:dark_prismarine
setblock 160 149 323 minecraft:dark_prismarine
setblock 160 149 325 minecraft:light[level=13]
setblock 160 149 333 minecraft:light[level=13]
setblock 160 149 341 minecraft:light[level=13]
setblock 160 149 349 minecraft:light[level=13]
setblock 160 149 357 minecraft:light[level=13]
setblock 160 149 363 minecraft:dark_prismarine
fill 161 149 323 161 152 323 minecraft:blue_terracotta
fill 161 149 363 161 152 363 minecraft:blue_terracotta
setblock 162 149 323 minecraft:purple_concrete
setblock 165 149 325 minecraft:light[level=12]
setblock 165 149 332 minecraft:light[level=12]
setblock 165 149 339 minecraft:light[level=12]
setblock 165 149 346 minecraft:light[level=12]
setblock 165 149 353 minecraft:light[level=12]
setblock 165 149 360 minecraft:light[level=12]
setblock 168 149 325 minecraft:light[level=13]
setblock 168 149 333 minecraft:light[level=13]
setblock 168 149 341 minecraft:light[level=13]
setblock 168 149 349 minecraft:light[level=13]
setblock 168 149 357 minecraft:light[level=13]
setblock 172 149 325 minecraft:light[level=12]
setblock 172 149 332 minecraft:light[level=12]
setblock 172 149 339 minecraft:light[level=12]
setblock 172 149 346 minecraft:light[level=12]
fill 172 149 353 172 183 353 minecraft:magenta_terracotta
setblock 172 149 360 minecraft:light[level=12]
fill 173 149 363 174 149 363 minecraft:blue_terracotta
setblock 175 149 363 minecraft:dark_prismarine
setblock 176 149 325 minecraft:light[level=13]
setblock 176 149 333 minecraft:light[level=13]
setblock 176 149 341 minecraft:light[level=13]
setblock 176 149 349 minecraft:light[level=13]
setblock 176 149 357 minecraft:light[level=13]
fill 176 149 363 176 152 363 minecraft:blue_terracotta
setblock 179 149 325 minecraft:light[level=12]
setblock 179 149 332 minecraft:light[level=12]
setblock 179 149 339 minecraft:light[level=12]
setblock 179 149 346 minecraft:light[level=12]
setblock 179 149 354 minecraft:dark_prismarine
setblock 179 149 360 minecraft:light[level=12]
setblock 180 149 353 minecraft:dark_prismarine
fill 180 149 354 180 152 354 minecraft:blue_terracotta
setblock 181 149 323 minecraft:purple_concrete
setblock 181 149 332 minecraft:dark_prismarine
fill 181 149 333 181 152 333 minecraft:blue_terracotta
setblock 181 149 337 minecraft:dark_prismarine
fill 181 149 338 181 152 338 minecraft:blue_terracotta
setblock 181 149 347 minecraft:dark_prismarine
fill 181 149 348 181 150 348 minecraft:blue_terracotta
setblock 181 149 352 minecraft:dark_prismarine
fill 181 149 353 181 152 353 minecraft:blue_terracotta
setblock 181 149 357 minecraft:dark_prismarine
fill 181 149 358 181 152 358 minecraft:blue_terracotta
setblock 182 149 331 minecraft:dark_prismarine
fill 182 149 332 182 152 332 minecraft:blue_terracotta
setblock 182 149 336 minecraft:dark_prismarine
fill 182 149 337 182 152 337 minecraft:blue_terracotta
setblock 182 149 341 minecraft:dark_prismarine
fill 182 149 342 182 152 342 minecraft:blue_terracotta
setblock 182 149 346 minecraft:dark_prismarine
fill 182 149 347 182 152 347 minecraft:blue_terracotta
setblock 182 149 351 minecraft:dark_prismarine
fill 182 149 352 182 152 352 minecraft:blue_terracotta
setblock 182 149 356 minecraft:dark_prismarine
fill 182 149 357 182 152 357 minecraft:blue_terracotta
fill 183 149 330 183 217 330 minecraft:blue_terracotta
setblock 183 149 331 minecraft:light_blue_wool
fill 183 149 353 183 221 353 minecraft:blue_terracotta
setblock 142 150 326 minecraft:purple_concrete
setblock 142 150 330 minecraft:dark_prismarine
fill 142 150 331 142 153 331 minecraft:blue_terracotta
setblock 142 150 335 minecraft:dark_prismarine
fill 142 150 336 142 153 336 minecraft:blue_terracotta
setblock 142 150 340 minecraft:dark_prismarine
fill 142 150 341 142 153 341 minecraft:blue_terracotta
setblock 142 150 345 minecraft:purple_concrete
setblock 142 150 351 minecraft:blue_terracotta
setblock 142 150 355 minecraft:dark_prismarine
fill 142 150 356 142 153 356 minecraft:blue_terracotta
fill 143 150 330 143 151 330 minecraft:blue_terracotta
setblock 143 150 334 minecraft:dark_prismarine
fill 143 150 335 143 153 335 minecraft:blue_terracotta
setblock 143 150 338 minecraft:blue_terracotta
setblock 143 150 356 minecraft:dark_prismarine
fill 145 150 328 147 151 328 minecraft:dark_prismarine
setblock 146 150 324 minecraft:purple_concrete
fill 146 150 329 146 152 329 minecraft:dark_prismarine
fill 147 150 346 147 155 346 minecraft:iron_bars
fill 147 150 357 147 151 357 minecraft:dark_prismarine
setblock 149 150 363 minecraft:purple_concrete
fill 153 150 335 153 173 335 minecraft:magenta_terracotta
setblock 153 150 363 minecraft:blue_terracotta
setblock 154 150 323 minecraft:dark_prismarine
fill 154 150 324 154 153 324 minecraft:blue_terracotta
setblock 154 150 363 minecraft:dark_prismarine
fill 155 150 323 155 153 323 minecraft:blue_terracotta
setblock 155 150 362 minecraft:dark_prismarine
fill 155 150 363 155 153 363 minecraft:blue_terracotta
fill 156 150 362 159 150 362 minecraft:blue_terracotta
setblock 158 150 324 minecraft:dark_prismarine
setblock 159 150 323 minecraft:dark_prismarine
setblock 159 150 363 minecraft:dark_prismarine
fill 160 150 323 160 153 323 minecraft:blue_terracotta
setblock 160 150 362 minecraft:dark_prismarine
fill 160 150 363 160 153 363 minecraft:blue_terracotta
fill 161 150 362 161 153 362 minecraft:blue_terracotta
setblock 168 150 363 minecraft:purple_concrete
fill 171 150 363 173 150 363 minecraft:blue_terracotta
setblock 174 150 362 minecraft:blue_terracotta
setblock 174 150 363 minecraft:dark_prismarine
setblock 175 150 323 minecraft:purple_concrete
setblock 175 150 362 minecraft:dark_prismarine
fill 175 150 363 175 153 363 minecraft:blue_terracotta
fill 176 150 362 177 152 362 minecraft:blue_terracotta
setblock 179 150 363 minecraft:dark_prismarine
setblock 180 150 352 minecraft:dark_prismarine
fill 180 150 353 180 152 353 minecraft:blue_terracotta
setblock 180 150 357 minecraft:dark_prismarine
fill 181 150 332 181 153 332 minecraft:blue_terracotta
setblock 181 150 336 minecraft:dark_prismarine
fill 181 150 337 181 153 337 minecraft:blue_terracotta
fill 181 150 339 181 150 340 minecraft:blue_terracotta
setblock 181 150 351 minecraft:dark_prismarine
fill 181 150 352 181 153 352 minecraft:blue_terracotta
setblock 181 150 356 minecraft:dark_prismarine
fill 181 150 357 181 153 357 minecraft:blue_terracotta
setblock 182 150 330 minecraft:dark_prismarine
fill 182 150 331 183 153 331 minecraft:blue_terracotta
setblock 182 150 335 minecraft:dark_prismarine
fill 182 150 336 182 153 336 minecraft:blue_terracotta
setblock 182 150 340 minecraft:dark_prismarine
fill 182 150 341 182 153 341 minecraft:blue_terracotta
setblock 182 150 345 minecraft:dark_prismarine
fill 182 150 346 182 153 346 minecraft:blue_terracotta
setblock 182 150 350 minecraft:dark_prismarine
fill 182 150 351 182 153 351 minecraft:blue_terracotta
setblock 182 150 355 minecraft:dark_prismarine
fill 182 150 356 182 153 356 minecraft:blue_terracotta
setblock 182 150 360 minecraft:dark_prismarine
fill 141 151 353 141 218 355 minecraft:blue_terracotta
setblock 141 151 356 minecraft:light_blue_wool
setblock 142 151 329 minecraft:dark_prismarine
fill 142 151 330 142 154 330 minecraft:blue_terracotta
setblock 142 151 334 minecraft:dark_prismarine
fill 142 151 335 142 154 335 minecraft:blue_terracotta
setblock 142 151 339 minecraft:dark_prismarine
fill 142 151 340 142 154 340 minecraft:blue_terracotta
setblock 142 151 351 minecraft:purple_concrete
setblock 142 151 352 minecraft:blue_terracotta
setblock 142 151 353 minecraft:sea_lantern
setblock 142 151 354 minecraft:dark_prismarine
setblock 142 151 355 minecraft:sea_lantern
setblock 142 151 357 minecraft:sea_lantern
fill 142 151 358 142 152 358 minecraft:dark_prismarine
setblock 142 151 359 minecraft:sea_lantern
setblock 142 151 361 minecraft:sea_lantern
setblock 143 151 333 minecraft:dark_prismarine
fill 143 151 334 143 154 334 minecraft:blue_terracotta
setblock 143 151 338 minecraft:dark_prismarine
fill 143 151 339 143 154 339 minecraft:blue_terracotta
setblock 143 151 354 minecraft:sea_lantern
setblock 143 151 356 minecraft:sea_lantern
setblock 143 151 358 minecraft:sea_lantern
setblock 143 151 360 minecraft:sea_lantern
setblock 144 151 353 minecraft:sea_lantern
setblock 144 151 355 minecraft:sea_lantern
setblock 144 151 357 minecraft:sea_lantern
setblock 144 151 359 minecraft:sea_lantern
setblock 144 151 361 minecraft:sea_lantern
fill 145 151 329 145 152 329 minecraft:dark_prismarine
setblock 145 151 354 minecraft:sea_lantern
setblock 145 151 356 minecraft:sea_lantern
setblock 145 151 358 minecraft:sea_lantern
setblock 145 151 360 minecraft:sea_lantern
setblock 146 151 326 minecraft:purple_concrete
setblock 146 151 327 minecraft:dark_prismarine
fill 146 151 330 146 153 330 minecraft:dark_prismarine
setblock 146 151 353 minecraft:sea_lantern
setblock 146 151 355 minecraft:sea_lantern
setblock 146 151 357 minecraft:sea_lantern
setblock 146 151 359 minecraft:sea_lantern
setblock 146 151 361 minecraft:sea_lantern
fill 147 151 329 147 152 329 minecraft:dark_prismarine
fill 147 151 356 147 152 356 minecraft:dark_prismarine
fill 150 151 323 151 152 323 minecraft:blue_terracotta
fill 151 151 363 152 151 363 minecraft:blue_terracotta
fill 152 151 333 152 187 333 minecraft:magenta_terracotta
setblock 153 151 323 minecraft:dark_prismarine
fill 153 151 324 153 154 324 minecraft:blue_terracotta
fill 153 151 334 153 189 334 minecraft:magenta_terracotta
setblock 153 151 362 minecraft:blue_terracotta
setblock 153 151 363 minecraft:dark_prismarine
fill 154 151 323 154 154 323 minecraft:blue_terracotta
setblock 154 151 362 minecraft:dark_prismarine
fill 154 151 363 154 154 363 minecraft:blue_terracotta
fill 155 151 362 158 151 362 minecraft:blue_terracotta
fill 156 151 361 159 151 361 minecraft:blue_terracotta
setblock 157 151 324 minecraft:dark_prismarine
setblock 158 151 323 minecraft:dark_prismarine
fill 158 151 324 158 154 324 minecraft:blue_terracotta
setblock 158 151 363 minecraft:dark_prismarine
fill 159 151 323 159 154 323 minecraft:blue_terracotta
setblock 159 151 362 minecraft:dark_prismarine
fill 159 151 363 159 154 363 minecraft:blue_terracotta
fill 160 151 362 160 154 362 minecraft:blue_terracotta
fill 162 151 362 162 152 362 minecraft:blue_terracotta
setblock 163 151 363 minecraft:dark_prismarine
fill 164 151 363 165 153 363 minecraft:blue_terracotta
fill 166 151 332 166 152 333 minecraft:dark_prismarine
setblock 168 151 363 minecraft:dark_prismarine
setblock 169 151 323 minecraft:purple_concrete
fill 169 151 363 172 151 363 minecraft:blue_terracotta
fill 171 151 362 173 151 362 minecraft:blue_terracotta
fill 172 151 335 172 152 336 minecraft:black_concrete
fill 173 151 336 173 152 336 minecraft:black_concrete
setblock 173 151 363 minecraft:dark_prismarine
setblock 174 151 362 minecraft:dark_prismarine
fill 174 151 363 174 154 363 minecraft:blue_terracotta
setblock 175 151 361 minecraft:dark_prismarine
fill 175 151 362 175 154 362 minecraft:blue_terracotta
setblock 178 151 362 minecraft:blue_terracotta
setblock 178 151 363 minecraft:dark_prismarine
fill 179 151 363 179 154 363 minecraft:blue_terracotta
fill 180 151 334 180 151 335 minecraft:blue_terracotta
setblock 180 151 336 minecraft:dark_prismarine
fill 180 151 337 180 153 338 minecraft:blue_terracotta
setblock 180 151 352 minecraft:blue_terracotta
setblock 180 151 356 minecraft:dark_prismarine
fill 180 151 357 180 153 357 minecraft:blue_terracotta
setblock 181 151 335 minecraft:dark_prismarine
fill 181 151 336 181 154 336 minecraft:blue_terracotta
setblock 181 151 339 minecraft:blue_terracotta
setblock 181 151 340 minecraft:dark_prismarine
fill 181 151 341 181 154 341 minecraft:blue_terracotta
setblock 181 151 350 minecraft:dark_prismarine
fill 181 151 351 181 153 351 minecraft:blue_terracotta
setblock 181 151 355 minecraft:dark_prismarine
fill 181 151 356 181 154 356 minecraft:blue_terracotta
setblock 181 151 359 minecraft:blue_terracotta
fill 182 151 330 182 154 330 minecraft:blue_terracotta
setblock 182 151 334 minecraft:dark_prismarine
fill 182 151 335 182 154 335 minecraft:blue_terracotta
setblock 182 151 339 minecraft:dark_prismarine
fill 182 151 340 182 154 340 minecraft:blue_terracotta
setblock 182 151 344 minecraft:dark_prismarine
fill 182 151 345 182 154 345 minecraft:blue_terracotta
setblock 182 151 349 minecraft:dark_prismarine
fill 182 151 350 182 154 350 minecraft:blue_terracotta
setblock 182 151 354 minecraft:dark_prismarine
fill 182 151 355 182 154 355 minecraft:blue_terracotta
setblock 182 151 359 minecraft:dark_prismarine
fill 182 151 360 182 154 360 minecraft:blue_terracotta
fill 141 152 356 141 218 356 minecraft:blue_terracotta
setblock 142 152 328 minecraft:dark_prismarine
fill 142 152 329 142 155 329 minecraft:blue_terracotta
setblock 142 152 333 minecraft:dark_prismarine
fill 142 152 334 142 155 334 minecraft:blue_terracotta
setblock 142 152 338 minecraft:dark_prismarine
fill 142 152 339 142 155 339 minecraft:blue_terracotta
setblock 142 152 343 minecraft:dark_prismarine
fill 142 152 353 142 153 353 minecraft:dark_prismarine
fill 142 152 354 142 152 355 minecraft:blue_terracotta
setblock 142 152 357 minecraft:blue_terracotta
setblock 142 152 359 minecraft:dark_prismarine
fill 142 152 361 142 153 361 minecraft:dark_prismarine
setblock 143 152 332 minecraft:dark_prismarine
fill 143 152 333 143 155 333 minecraft:blue_terracotta
setblock 143 152 337 minecraft:dark_prismarine
fill 143 152 338 143 155 338 minecraft:blue_terracotta
fill 143 152 354 143 153 354 minecraft:dark_prismarine
fill 143 152 356 143 153 356 minecraft:dark_prismarine
fill 143 152 358 143 153 358 minecraft:dark_prismarine
fill 143 152 360 143 153 360 minecraft:dark_prismarine
setblock 144 152 323 minecraft:purple_concrete
fill 144 152 353 144 153 353 minecraft:dark_prismarine
fill 144 152 355 144 153 355 minecraft:dark_prismarine
fill 144 152 357 144 153 357 minecraft:dark_prismarine
fill 144 152 359 144 153 359 minecraft:dark_prismarine
fill 144 152 361 144 153 361 minecraft:dark_prismarine
fill 145 152 330 145 152 331 minecraft:dark_prismarine
fill 145 152 354 145 153 354 minecraft:dark_prismarine
fill 145 152 356 145 153 356 minecraft:dark_prismarine
fill 145 152 358 145 153 358 minecraft:dark_prismarine
fill 145 152 360 145 153 360 minecraft:dark_prismarine
setblock 146 152 327 minecraft:purple_concrete
setblock 146 152 328 minecraft:dark_prismarine
fill 146 152 331 146 154 332 minecraft:dark_prismarine
fill 146 152 353 146 153 353 minecraft:dark_prismarine
fill 146 152 355 147 152 355 minecraft:dark_prismarine
fill 146 152 357 146 153 357 minecraft:dark_prismarine
fill 146 152 359 146 153 359 minecraft:dark_prismarine
fill 146 152 361 146 153 361 minecraft:dark_prismarine
fill 147 152 330 147 152 331 minecraft:dark_prismarine
fill 147 152 354 147 153 354 minecraft:dark_prismarine
fill 149 152 323 149 154 323 minecraft:blue_terracotta
fill 150 152 363 151 152 363 minecraft:blue_terracotta
setblock 152 152 323 minecraft:dark_prismarine
fill 152 152 324 152 155 324 minecraft:blue_terracotta
fill 152 152 336 152 154 336 minecraft:magenta_terracotta
setblock 152 152 362 minecraft:blue_terracotta
setblock 152 152 363 minecraft:dark_prismarine
fill 153 152 323 153 155 323 minecraft:blue_terracotta
setblock 153 152 361 minecraft:blue_terracotta
setblock 153 152 362 minecraft:dark_prismarine
fill 153 152 363 153 155 363 minecraft:blue_terracotta
setblock 154 152 361 minecraft:dark_prismarine
fill 154 152 362 157 152 362 minecraft:blue_terracotta
fill 155 152 361 158 152 361 minecraft:blue_terracotta
setblock 156 152 324 minecraft:dark_prismarine
setblock 157 152 323 minecraft:dark_prismarine
fill 157 152 324 157 155 324 minecraft:blue_terracotta
setblock 157 152 363 minecraft:dark_prismarine
fill 158 152 323 158 155 323 minecraft:blue_terracotta
setblock 158 152 362 minecraft:dark_prismarine
fill 158 152 363 158 155 363 minecraft:blue_terracotta
setblock 159 152 361 minecraft:dark_prismarine
fill 159 152 362 159 155 362 minecraft:blue_terracotta
fill 160 152 361 160 155 361 minecraft:blue_terracotta
setblock 162 152 363 minecraft:dark_prismarine
setblock 163 152 323 minecraft:purple_concrete
setblock 163 152 362 minecraft:dark_prismarine
fill 163 152 363 163 155 363 minecraft:blue_terracotta
setblock 166 152 363 minecraft:blue_terracotta
setblock 167 152 363 minecraft:dark_prismarine
fill 168 152 363 171 152 363 minecraft:blue_terracotta
fill 169 152 362 172 152 362 minecraft:blue_terracotta
fill 172 152 361 173 152 361 minecraft:blue_terracotta
setblock 172 152 363 minecraft:dark_prismarine
setblock 173 152 362 minecraft:dark_prismarine
fill 173 152 363 173 155 363 minecraft:blue_terracotta
setblock 174 152 361 minecraft:dark_prismarine
fill 174 152 362 174 155 362 minecraft:blue_terracotta
fill 175 152 361 177 153 361 minecraft:blue_terracotta
setblock 177 152 363 minecraft:dark_prismarine
setblock 178 152 362 minecraft:dark_prismarine
fill 178 152 363 178 155 363 minecraft:blue_terracotta
setblock 180 152 334 minecraft:blue_terracotta
setblock 180 152 335 minecraft:dark_prismarine
fill 180 152 336 180 155 336 minecraft:blue_terracotta
setblock 180 152 339 minecraft:blue_terracotta
setblock 180 152 340 minecraft:dark_prismarine
setblock 180 152 355 minecraft:dark_prismarine
fill 180 152 356 180 153 356 minecraft:blue_terracotta
setblock 180 152 358 minecraft:blue_terracotta
fill 180 152 363 180 153 363 minecraft:blue_terracotta
setblock 181 152 334 minecraft:dark_prismarine
fill 181 152 335 181 155 335 minecraft:blue_terracotta
setblock 181 152 339 minecraft:dark_prismarine
fill 181 152 340 181 155 340 minecraft:blue_terracotta
fill 181 152 342 181 152 343 minecraft:blue_terracotta
setblock 181 152 350 minecraft:blue_terracotta
setblock 181 152 354 minecraft:dark_prismarine
fill 181 152 355 181 154 355 minecraft:blue_terracotta
setblock 181 152 359 minecraft:dark_prismarine
setblock 182 152 329 minecraft:purple_concrete
setblock 182 152 333 minecraft:dark_prismarine
fill 182 152 334 182 155 334 minecraft:blue_terracotta
setblock 182 152 338 minecraft:dark_prismarine
fill 182 152 339 182 155 339 minecraft:blue_terracotta
setblock 182 152 343 minecraft:dark_prismarine
fill 182 152 344 182 155 344 minecraft:blue_terracotta
setblock 182 152 348 minecraft:dark_prismarine
fill 182 152 349 182 154 349 minecraft:blue_terracotta
setblock 182 152 353 minecraft:dark_prismarine
fill 182 152 354 182 155 354 minecraft:blue_terracotta
setblock 182 152 358 minecraft:dark_prismarine
fill 182 152 359 182 155 359 minecraft:blue_terracotta
fill 182 152 361 182 153 361 minecraft:blue_terracotta
fill 142 153 328 142 155 328 minecraft:blue_terracotta
setblock 142 153 332 minecraft:dark_prismarine
fill 142 153 333 142 156 333 minecraft:blue_terracotta
setblock 142 153 337 minecraft:dark_prismarine
fill 142 153 338 142 156 338 minecraft:blue_terracotta
setblock 142 153 342 minecraft:dark_prismarine
fill 142 153 343 142 156 343 minecraft:blue_terracotta
setblock 142 153 344 minecraft:purple_concrete
fill 142 153 354 142 161 354 minecraft:dark_prismarine
setblock 142 153 355 minecraft:blue_terracotta
setblock 142 153 357 minecraft:dark_prismarine
fill 142 153 358 142 153 359 minecraft:blue_terracotta
setblock 142 153 363 minecraft:purple_concrete
setblock 143 153 331 minecraft:dark_prismarine
fill 143 153 332 143 155 332 minecraft:blue_terracotta
setblock 143 153 336 minecraft:dark_prismarine
fill 143 153 337 143 156 337 minecraft:blue_terracotta
setblock 143 153 340 minecraft:blue_terracotta
setblock 144 153 335 minecraft:dark_prismarine
fill 145 153 331 145 153 333 minecraft:dark_prismarine
fill 145 153 352 147 154 352 minecraft:dark_prismarine
setblock 146 153 329 minecraft:purple_concrete
fill 146 153 333 146 155 334 minecraft:dark_prismarine
fill 146 153 351 146 155 351 minecraft:dark_prismarine
setblock 146 153 355 minecraft:dark_prismarine
fill 147 153 331 147 153 333 minecraft:dark_prismarine
fill 147 153 353 147 154 353 minecraft:dark_prismarine
fill 148 153 323 148 155 323 minecraft:blue_terracotta
fill 148 153 363 150 153 363 minecraft:blue_terracotta
setblock 150 153 323 minecraft:blue_terracotta
setblock 150 153 324 minecraft:dark_prismarine
fill 150 153 362 151 153 362 minecraft:blue_terracotta
setblock 151 153 323 minecraft:dark_prismarine
fill 151 153 324 151 156 324 minecraft:blue_terracotta
fill 151 153 333 151 154 333 minecraft:magenta_terracotta
setblock 151 153 363 minecraft:dark_prismarine
fill 152 153 323 152 156 323 minecraft:blue_terracotta
setblock 152 153 361 minecraft:blue_terracotta
setblock 152 153 362 minecraft:dark_prismarine
fill 152 153 363 152 156 363 minecraft:blue_terracotta
setblock 153 153 322 minecraft:light_blue_wool
setblock 153 153 361 minecraft:dark_prismarine
fill 153 153 362 156 153 362 minecraft:blue_terracotta
setblock 154 153 360 minecraft:dark_prismarine
fill 154 153 361 157 153 361 minecraft:blue_terracotta
setblock 155 153 324 minecraft:dark_prismarine
fill 155 153 360 158 153 360 minecraft:blue_terracotta
setblock 156 153 323 minecraft:dark_prismarine
fill 156 153 324 156 156 324 minecraft:blue_terracotta
setblock 156 153 363 minecraft:dark_prismarine
fill 157 153 323 157 156 323 minecraft:blue_terracotta
setblock 157 153 362 minecraft:dark_prismarine
fill 157 153 363 157 156 363 minecraft:blue_terracotta
setblock 158 153 361 minecraft:dark_prismarine
fill 158 153 362 158 156 362 minecraft:blue_terracotta
fill 159 153 361 159 156 361 minecraft:blue_terracotta
setblock 161 153 323 minecraft:dark_prismarine
fill 161 153 361 161 154 361 minecraft:blue_terracotta
setblock 161 153 363 minecraft:dark_prismarine
setblock 162 153 362 minecraft:dark_prismarine
fill 162 153 363 162 156 363 minecraft:blue_terracotta
fill 163 153 362 166 153 362 minecraft:blue_terracotta
setblock 166 153 363 minecraft:dark_prismarine
setblock 167 153 362 minecraft:dark_prismarine
fill 167 153 363 170 153 363 minecraft:blue_terracotta
fill 168 153 362 171 153 362 minecraft:blue_terracotta
fill 169 153 361 172 153 361 minecraft:blue_terracotta
setblock 171 153 363 minecraft:dark_prismarine
fill 172 153 360 173 153 360 minecraft:blue_terracotta
setblock 172 153 362 minecraft:dark_prismarine
fill 172 153 363 172 156 363 minecraft:blue_terracotta
fill 173 153 323 175 153 323 minecraft:blue_terracotta
setblock 173 153 361 minecraft:dark_prismarine
fill 173 153 362 173 156 362 minecraft:blue_terracotta
setblock 174 153 360 minecraft:dark_prismarine
fill 174 153 361 174 156 361 minecraft:blue_terracotta
fill 175 153 360 175 156 360 minecraft:blue_terracotta
setblock 176 153 323 minecraft:dark_prismarine
setblock 176 153 362 minecraft:blue_terracotta
setblock 176 153 363 minecraft:dark_prismarine
setblock 177 153 362 minecraft:dark_prismarine
fill 177 153 363 177 156 363 minecraft:blue_terracotta
fill 178 153 362 179 155 362 minecraft:blue_terracotta
setblock 180 153 334 minecraft:dark_prismarine
fill 180 153 335 180 155 335 minecraft:blue_terracotta
setblock 180 153 339 minecraft:dark_prismarine
fill 180 153 340 180 155 341 minecraft:blue_terracotta
setblock 180 153 354 minecraft:dark_prismarine
setblock 180 153 355 minecraft:blue_terracotta
setblock 181 153 333 minecraft:dark_prismarine
fill 181 153 334 181 156 334 minecraft:blue_terracotta
setblock 181 153 338 minecraft:dark_prismarine
fill 181 153 339 181 156 339 minecraft:blue_terracotta
setblock 181 153 342 minecraft:blue_terracotta
setblock 181 153 343 minecraft:dark_prismarine
fill 181 153 344 181 156 344 minecraft:blue_terracotta
setblock 181 153 353 minecraft:dark_prismarine
fill 181 153 354 181 154 354 minecraft:blue_terracotta
setblock 181 153 358 minecraft:dark_prismarine
fill 181 153 359 181 155 359 minecraft:blue_terracotta
setblock 182 153 323 minecraft:purple_concrete
setblock 182 153 332 minecraft:dark_prismarine
fill 182 153 333 182 156 333 minecraft:blue_terracotta
setblock 182 153 337 minecraft:dark_prismarine
fill 182 153 338 182 156 338 minecraft:blue_terracotta
setblock 182 153 342 minecraft:dark_prismarine
fill 182 153 343 182 156 343 minecraft:blue_terracotta
setblock 182 153 347 minecraft:dark_prismarine
fill 182 153 348 182 154 348 minecraft:blue_terracotta
setblock 182 153 352 minecraft:dark_prismarine
fill 182 153 353 182 155 353 minecraft:blue_terracotta
setblock 182 153 357 minecraft:dark_prismarine
fill 182 153 358 182 156 358 minecraft:blue_terracotta
fill 183 153 325 183 217 326 minecraft:blue_terracotta
setblock 183 153 327 minecraft:light_blue_wool
fill 183 153 328 183 220 329 minecraft:blue_terracotta
setblock 142 154 325 minecraft:purple_concrete
setblock 142 154 331 minecraft:dark_prismarine
fill 142 154 332 142 157 332 minecraft:blue_terracotta
setblock 142 154 336 minecraft:dark_prismarine
fill 142 154 337 142 157 337 minecraft:blue_terracotta
setblock 142 154 341 minecraft:dark_prismarine
fill 142 154 342 142 157 342 minecraft:blue_terracotta
setblock 142 154 350 minecraft:purple_concrete
setblock 142 154 353 minecraft:sea_lantern
setblock 142 154 355 minecraft:sea_lantern
setblock 142 154 356 minecraft:dark_prismarine
setblock 142 154 357 minecraft:sea_lantern
fill 142 154 358 142 155 358 minecraft:blue_terracotta
setblock 142 154 359 minecraft:sea_lantern
setblock 142 154 360 minecraft:blue_terracotta
setblock 142 154 361 minecraft:sea_lantern
setblock 143 154 331 minecraft:blue_terracotta
setblock 143 154 335 minecraft:dark_prismarine
fill 143 154 336 144 154 336 minecraft:blue_terracotta
setblock 143 154 340 minecraft:dark_prismarine
setblock 143 154 354 minecraft:sea_lantern
setblock 143 154 356 minecraft:sea_lantern
setblock 143 154 358 minecraft:sea_lantern
setblock 143 154 360 minecraft:sea_lantern
setblock 144 154 335 minecraft:blue_terracotta
setblock 144 154 353 minecraft:sea_lantern
setblock 144 154 355 minecraft:sea_lantern
setblock 144 154 357 minecraft:sea_lantern
setblock 144 154 359 minecraft:sea_lantern
setblock 144 154 361 minecraft:sea_lantern
fill 145 154 332 145 154 335 minecraft:dark_prismarine
fill 145 154 350 145 155 351 minecraft:dark_prismarine
setblock 145 154 354 minecraft:sea_lantern
setblock 145 154 356 minecraft:sea_lantern
setblock 145 154 358 minecraft:sea_lantern
setblock 145 154 360 minecraft:sea_lantern
fill 146 154 323 147 156 323 minecraft:blue_terracotta
setblock 146 154 330 minecraft:purple_concrete
fill 146 154 335 146 156 336 minecraft:dark_prismarine
setblock 146 154 353 minecraft:sea_lantern
setblock 146 154 355 minecraft:sea_lantern
setblock 146 154 357 minecraft:sea_lantern
setblock 146 154 359 minecraft:sea_lantern
setblock 146 154 361 minecraft:sea_lantern
fill 147 154 332 147 154 335 minecraft:dark_prismarine
fill 147 154 351 147 155 351 minecraft:dark_prismarine
fill 147 154 363 149 154 363 minecraft:blue_terracotta
setblock 149 154 324 minecraft:dark_prismarine
fill 149 154 362 150 154 362 minecraft:blue_terracotta
setblock 150 154 323 minecraft:dark_prismarine
fill 150 154 324 150 157 324 minecraft:blue_terracotta
setblock 150 154 363 minecraft:dark_prismarine
fill 151 154 323 151 157 323 minecraft:blue_terracotta
setblock 151 154 361 minecraft:blue_terracotta
setblock 151 154 362 minecraft:dark_prismarine
fill 151 154 363 151 157 363 minecraft:blue_terracotta
setblock 152 154 361 minecraft:dark_prismarine
fill 152 154 362 155 154 362 minecraft:blue_terracotta
fill 153 154 322 153 220 322 minecraft:blue_terracotta
setblock 153 154 325 minecraft:dark_prismarine
setblock 153 154 360 minecraft:dark_prismarine
fill 153 154 361 156 154 361 minecraft:blue_terracotta
setblock 154 154 324 minecraft:dark_prismarine
fill 154 154 325 155 155 325 minecraft:blue_terracotta
fill 154 154 360 157 154 360 minecraft:blue_terracotta
setblock 155 154 323 minecraft:dark_prismarine
fill 155 154 324 155 157 324 minecraft:blue_terracotta
setblock 155 154 363 minecraft:dark_prismarine
fill 156 154 323 156 157 323 minecraft:blue_terracotta
setblock 156 154 362 minecraft:dark_prismarine
fill 156 154 363 156 157 363 minecraft:blue_terracotta
setblock 157 154 361 minecraft:dark_prismarine
fill 157 154 362 157 157 362 minecraft:blue_terracotta
setblock 158 154 360 minecraft:dark_prismarine
fill 158 154 361 158 157 361 minecraft:blue_terracotta
fill 159 154 360 159 155 360 minecraft:blue_terracotta
setblock 160 154 323 minecraft:dark_prismarine
setblock 160 154 363 minecraft:dark_prismarine
fill 161 154 323 161 157 323 minecraft:blue_terracotta
setblock 161 154 362 minecraft:dark_prismarine
fill 161 154 363 161 157 363 minecraft:blue_terracotta
setblock 162 154 361 minecraft:dark_prismarine
fill 162 154 362 165 154 362 minecraft:blue_terracotta
setblock 164 154 363 minecraft:blue_terracotta
setblock 165 154 363 minecraft:dark_prismarine
setblock 166 154 362 minecraft:dark_prismarine
fill 166 154 363 169 154 363 minecraft:blue_terracotta
setblock 167 154 361 minecraft:dark_prismarine
fill 167 154 362 170 154 362 minecraft:blue_terracotta
fill 168 154 361 171 154 361 minecraft:blue_terracotta
setblock 170 154 323 minecraft:purple_concrete
fill 170 154 360 172 154 360 minecraft:blue_terracotta
setblock 170 154 363 minecraft:dark_prismarine
fill 171 154 323 174 154 323 minecraft:blue_terracotta
setblock 171 154 362 minecraft:dark_prismarine
fill 171 154 363 171 157 363 minecraft:blue_terracotta
setblock 172 154 361 minecraft:dark_prismarine
fill 172 154 362 172 157 362 minecraft:blue_terracotta
setblock 173 154 360 minecraft:dark_prismarine
fill 173 154 361 173 157 361 minecraft:blue_terracotta
fill 174 154 360 174 157 360 minecraft:blue_terracotta
setblock 175 154 323 minecraft:dark_prismarine
fill 175 154 361 176 154 361 minecraft:blue_terracotta
setblock 175 154 363 minecraft:dark_prismarine
fill 176 154 323 177 156 323 minecraft:blue_terracotta
fill 176 154 360 176 155 360 minecraft:blue_terracotta
setblock 176 154 362 minecraft:dark_prismarine
fill 176 154 363 176 157 363 minecraft:blue_terracotta
setblock 177 154 361 minecraft:dark_prismarine
fill 177 154 362 177 157 362 minecraft:blue_terracotta
setblock 178 154 361 minecraft:blue_terracotta
setblock 180 154 334 minecraft:blue_terracotta
setblock 180 154 337 minecraft:blue_terracotta
setblock 180 154 338 minecraft:dark_prismarine
fill 180 154 339 180 157 339 minecraft:blue_terracotta
setblock 180 154 342 minecraft:blue_terracotta
setblock 180 154 363 minecraft:dark_prismarine
setblock 181 154 332 minecraft:dark_prismarine
fill 181 154 333 181 155 333 minecraft:blue_terracotta
setblock 181 154 337 minecraft:dark_prismarine
fill 181 154 338 181 157 338 minecraft:blue_terracotta
setblock 181 154 342 minecraft:dark_prismarine
fill 181 154 343 181 157 343 minecraft:blue_terracotta
setblock 181 154 353 minecraft:blue_terracotta
setblock 181 154 357 minecraft:dark_prismarine
fill 181 154 358 181 155 358 minecraft:blue_terracotta
setblock 182 154 331 minecraft:dark_prismarine
fill 182 154 332 182 157 332 minecraft:blue_terracotta
setblock 182 154 336 minecraft:dark_prismarine
fill 182 154 337 182 157 337 minecraft:blue_terracotta
setblock 182 154 341 minecraft:dark_prismarine
fill 182 154 342 183 157 342 minecraft:blue_terracotta
setblock 182 154 346 minecraft:dark_prismarine
fill 182 154 347 182 155 347 minecraft:blue_terracotta
setblock 182 154 351 minecraft:dark_prismarine
fill 182 154 352 182 155 352 minecraft:blue_terracotta
setblock 182 154 356 minecraft:dark_prismarine
fill 182 154 357 182 156 357 minecraft:blue_terracotta
setblock 182 154 361 minecraft:dark_prismarine
fill 183 154 327 183 213 327 minecraft:blue_terracotta
fill 183 154 331 183 206 331 minecraft:blue_terracotta
fill 183 154 340 183 169 341 minecraft:blue_terracotta
setblock 183 154 343 minecraft:light_blue_wool
setblock 142 155 330 minecraft:dark_prismarine
fill 142 155 331 142 157 331 minecraft:blue_terracotta
setblock 142 155 335 minecraft:dark_prismarine
fill 142 155 336 143 157 336 minecraft:blue_terracotta
setblock 142 155 340 minecraft:dark_prismarine
fill 142 155 341 143 156 341 minecraft:blue_terracotta
fill 142 155 353 142 156 353 minecraft:dark_prismarine
fill 142 155 355 142 156 355 minecraft:dark_prismarine
setblock 142 155 356 minecraft:purple_concrete
setblock 142 155 357 minecraft:blue_terracotta
setblock 142 155 359 minecraft:blue_terracotta
fill 142 155 360 143 155 360 minecraft:dark_prismarine
fill 142 155 361 142 156 361 minecraft:blue_terracotta
setblock 143 155 334 minecraft:dark_prismarine
fill 143 155 335 143 157 335 minecraft:blue_terracotta
setblock 143 155 339 minecraft:dark_prismarine
fill 143 155 340 143 158 340 minecraft:blue_terracotta
fill 143 155 354 143 156 354 minecraft:dark_prismarine
fill 143 155 356 143 156 356 minecraft:dark_prismarine
fill 143 155 358 143 156 358 minecraft:dark_prismarine
setblock 144 155 325 minecraft:light[level=12]
setblock 144 155 332 minecraft:light[level=12]
setblock 144 155 339 minecraft:light[level=12]
setblock 144 155 346 minecraft:light[level=12]
fill 144 155 353 144 156 353 minecraft:dark_prismarine
fill 144 155 355 144 156 355 minecraft:dark_prismarine
fill 144 155 357 144 156 357 minecraft:dark_prismarine
fill 144 155 359 144 156 359 minecraft:dark_prismarine
fill 144 155 361 144 156 361 minecraft:dark_prismarine
fill 145 155 323 145 158 323 minecraft:blue_terracotta
fill 145 155 334 145 155 337 minecraft:dark_prismarine
fill 145 155 348 145 155 349 minecraft:dark_prismarine
fill 145 155 354 145 156 354 minecraft:dark_prismarine
fill 145 155 356 145 156 356 minecraft:dark_prismarine
fill 145 155 358 145 156 358 minecraft:dark_prismarine
fill 145 155 360 145 156 360 minecraft:dark_prismarine
fill 145 155 363 148 155 363 minecraft:blue_terracotta
setblock 146 155 332 minecraft:purple_concrete
fill 146 155 337 146 156 340 minecraft:dark_prismarine
fill 146 155 345 146 157 347 minecraft:dark_prismarine
fill 146 155 352 146 155 353 minecraft:dark_prismarine
fill 146 155 355 146 156 355 minecraft:dark_prismarine
fill 146 155 357 146 156 357 minecraft:dark_prismarine
fill 146 155 359 146 156 359 minecraft:dark_prismarine
fill 146 155 361 146 156 361 minecraft:dark_prismarine
fill 147 155 334 147 155 337 minecraft:dark_prismarine
setblock 148 155 324 minecraft:dark_prismarine
fill 148 155 362 149 155 362 minecraft:blue_terracotta
setblock 149 155 323 minecraft:dark_prismarine
fill 149 155 324 149 158 324 minecraft:blue_terracotta
setblock 149 155 363 minecraft:dark_prismarine
fill 150 155 323 150 158 323 minecraft:blue_terracotta
setblock 150 155 361 minecraft:blue_terracotta
setblock 150 155 362 minecraft:dark_prismarine
fill 150 155 363 150 158 363 minecraft:blue_terracotta
setblock 151 155 325 minecraft:light[level=12]
setblock 151 155 332 minecraft:light[level=12]
setblock 151 155 346 minecraft:light[level=12]
setblock 151 155 353 minecraft:light[level=12]
setblock 151 155 360 minecraft:light[level=12]
setblock 151 155 361 minecraft:dark_prismarine
fill 151 155 362 154 155 362 minecraft:blue_terracotta
setblock 152 155 325 minecraft:dark_prismarine
setblock 152 155 360 minecraft:dark_prismarine
fill 152 155 361 155 155 361 minecraft:blue_terracotta
setblock 153 155 324 minecraft:dark_prismarine
fill 153 155 325 153 158 325 minecraft:blue_terracotta
fill 153 155 360 156 155 360 minecraft:blue_terracotta
setblock 154 155 323 minecraft:dark_prismarine
fill 154 155 324 154 158 324 minecraft:blue_terracotta
setblock 154 155 363 minecraft:dark_prismarine
fill 155 155 323 155 158 323 minecraft:blue_terracotta
setblock 155 155 362 minecraft:dark_prismarine
fill 155 155 363 155 158 363 minecraft:blue_terracotta
setblock 156 155 361 minecraft:dark_prismarine
fill 156 155 362 156 158 362 minecraft:blue_terracotta
setblock 157 155 360 minecraft:dark_prismarine
fill 157 155 361 157 158 361 minecraft:blue_terracotta
setblock 158 155 324 minecraft:dark_prismarine
setblock 158 155 325 minecraft:light[level=12]
setblock 158 155 332 minecraft:light[level=12]
setblock 158 155 339 minecraft:light[level=12]
setblock 158 155 346 minecraft:light[level=12]
setblock 158 155 353 minecraft:light[level=12]
fill 158 155 360 158 156 360 minecraft:blue_terracotta
setblock 159 155 323 minecraft:dark_prismarine
setblock 159 155 363 minecraft:dark_prismarine
fill 160 155 323 160 158 323 minecraft:blue_terracotta
setblock 160 155 362 minecraft:dark_prismarine
fill 160 155 363 160 158 363 minecraft:blue_terracotta
setblock 161 155 361 minecraft:dark_prismarine
fill 161 155 362 164 155 362 minecraft:blue_terracotta
fill 162 155 361 165 155 361 minecraft:blue_terracotta
setblock 164 155 323 minecraft:purple_concrete
setblock 164 155 363 minecraft:dark_prismarine
setblock 165 155 325 minecraft:light[level=12]
setblock 165 155 332 minecraft:light[level=12]
setblock 165 155 339 minecraft:light[level=12]
setblock 165 155 346 minecraft:light[level=12]
setblock 165 155 353 minecraft:light[level=12]
setblock 165 155 360 minecraft:light[level=12]
setblock 165 155 362 minecraft:dark_prismarine
fill 165 155 363 168 155 363 minecraft:blue_terracotta
setblock 166 155 361 minecraft:dark_prismarine
fill 166 155 362 169 155 362 minecraft:blue_terracotta
fill 167 155 361 170 155 361 minecraft:blue_terracotta
fill 169 155 360 171 155 360 minecraft:blue_terracotta
setblock 169 155 363 minecraft:dark_prismarine
fill 170 155 323 173 155 323 minecraft:blue_terracotta
setblock 170 155 362 minecraft:dark_prismarine
fill 170 155 363 170 158 363 minecraft:blue_terracotta
setblock 171 155 361 minecraft:dark_prismarine
fill 171 155 362 171 158 362 minecraft:blue_terracotta
setblock 172 155 325 minecraft:light[level=12]
setblock 172 155 332 minecraft:light[level=12]
setblock 172 155 339 minecraft:light[level=12]
setblock 172 155 346 minecraft:light[level=12]
setblock 172 155 360 minecraft:dark_prismarine
fill 172 155 361 172 158 361 minecraft:blue_terracotta
fill 173 155 360 173 157 360 minecraft:blue_terracotta
setblock 174 155 323 minecraft:dark_prismarine
setblock 174 155 363 minecraft:dark_prismarine
fill 175 155 323 175 158 323 minecraft:blue_terracotta
setblock 175 155 361 minecraft:blue_terracotta
setblock 175 155 362 minecraft:dark_prismarine
fill 175 155 363 175 158 363 minecraft:blue_terracotta
setblock 176 155 361 minecraft:dark_prismarine
fill 176 155 362 176 158 362 minecraft:blue_terracotta
fill 177 155 361 177 156 361 minecraft:blue_terracotta
setblock 179 155 325 minecraft:light[level=12]
setblock 179 155 332 minecraft:light[level=12]
setblock 179 155 339 minecraft:light[level=12]
setblock 179 155 346 minecraft:light[level=12]
setblock 179 155 353 minecraft:light[level=12]
setblock 179 155 360 minecraft:light[level=12]
setblock 179 155 363 minecraft:dark_prismarine
setblock 180 155 337 minecraft:dark_prismarine
fill 180 155 338 180 157 338 minecraft:blue_terracotta
setblock 180 155 342 minecraft:dark_prismarine
fill 180 155 363 180 157 363 minecraft:blue_terracotta
setblock 181 155 336 minecraft:dark_prismarine
fill 181 155 337 181 158 337 minecraft:blue_terracotta
setblock 181 155 341 minecraft:dark_prismarine
fill 181 155 342 181 158 342 minecraft:blue_terracotta
setblock 181 155 356 minecraft:dark_prismarine
setblock 181 155 357 minecraft:blue_terracotta
setblock 182 155 330 minecraft:purple_concrete
setblock 182 155 331 minecraft:blue_terracotta
setblock 182 155 335 minecraft:dark_prismarine
fill 182 155 336 182 158 336 minecraft:blue_terracotta
setblock 182 155 340 minecraft:dark_prismarine
fill 182 155 341 182 158 341 minecraft:blue_terracotta
setblock 182 155 345 minecraft:dark_prismarine
fill 182 155 346 182 158 346 minecraft:blue_terracotta
fill 182 155 349 182 156 349 minecraft:purple_concrete
setblock 182 155 355 minecraft:dark_prismarine
fill 182 155 356 182 156 356 minecraft:blue_terracotta
setblock 182 155 360 minecraft:dark_prismarine
fill 182 155 361 182 155 362 minecraft:blue_terracotta
fill 183 155 343 183 217 343 minecraft:blue_terracotta
setblock 142 156 323 minecraft:blue_terracotta
setblock 142 156 329 minecraft:dark_prismarine
fill 142 156 330 142 157 330 minecraft:blue_terracotta
setblock 142 156 334 minecraft:dark_prismarine
fill 142 156 335 142 159 335 minecraft:blue_terracotta
setblock 142 156 339 minecraft:dark_prismarine
fill 142 156 340 142 159 340 minecraft:blue_terracotta
fill 142 156 356 142 156 359 minecraft:dark_prismarine
fill 142 156 360 142 157 360 minecraft:blue_terracotta
fill 142 156 362 142 157 362 minecraft:blue_terracotta
setblock 143 156 323 minecraft:dark_prismarine
setblock 143 156 333 minecraft:dark_prismarine
fill 143 156 334 143 157 334 minecraft:blue_terracotta
setblock 143 156 338 minecraft:dark_prismarine
fill 143 156 339 143 158 339 minecraft:blue_terracotta
setblock 143 156 360 minecraft:dark_prismarine
fill 144 156 323 144 159 323 minecraft:blue_terracotta
fill 144 156 363 147 156 363 minecraft:blue_terracotta
fill 145 156 337 145 156 348 minecraft:dark_prismarine
fill 146 156 333 146 156 334 minecraft:purple_concrete
fill 146 156 341 147 157 344 minecraft:dark_prismarine
fill 146 156 351 146 156 352 minecraft:purple_concrete
setblock 146 156 353 minecraft:dark_prismarine
setblock 147 156 324 minecraft:dark_prismarine
fill 147 156 337 147 156 340 minecraft:dark_prismarine
fill 147 156 345 147 156 347 minecraft:dark_prismarine
fill 147 156 362 148 156 362 minecraft:blue_terracotta
setblock 148 156 323 minecraft:dark_prismarine
fill 148 156 324 148 159 324 minecraft:blue_terracotta
fill 148 156 348 148 213 348 minecraft:magenta_terracotta
setblock 148 156 363 minecraft:dark_prismarine
fill 149 156 323 149 159 323 minecraft:blue_terracotta
setblock 149 156 361 minecraft:blue_terracotta
setblock 149 156 362 minecraft:dark_prismarine
fill 149 156 363 149 159 363 minecraft:blue_terracotta
setblock 150 156 361 minecraft:dark_prismarine
fill 150 156 362 153 156 362 minecraft:blue_terracotta
setblock 151 156 325 minecraft:dark_prismarine
setblock 151 156 360 minecraft:dark_prismarine
fill 151 156 361 154 156 361 minecraft:blue_terracotta
setblock 152 156 324 minecraft:dark_prismarine
fill 152 156 325 152 159 325 minecraft:blue_terracotta
fill 152 156 360 155 156 360 minecraft:blue_terracotta
setblock 153 156 323 minecraft:dark_prismarine
fill 153 156 324 153 159 324 minecraft:blue_terracotta
setblock 153 156 363 minecraft:dark_prismarine
fill 154 156 323 154 159 323 minecraft:blue_terracotta
fill 154 156 325 154 157 325 minecraft:blue_terracotta
setblock 154 156 362 minecraft:dark_prismarine
fill 154 156 363 154 159 363 minecraft:blue_terracotta
setblock 155 156 361 minecraft:dark_prismarine
fill 155 156 362 155 159 362 minecraft:blue_terracotta
setblock 156 156 360 minecraft:dark_prismarine
fill 156 156 361 156 159 361 minecraft:blue_terracotta
setblock 157 156 324 minecraft:dark_prismarine
fill 157 156 360 157 157 360 minecraft:blue_terracotta
setblock 158 156 323 minecraft:dark_prismarine
setblock 158 156 324 minecraft:blue_terracotta
setblock 158 156 363 minecraft:dark_prismarine
fill 159 156 323 159 159 323 minecraft:blue_terracotta
setblock 159 156 362 minecraft:dark_prismarine
fill 159 156 363 159 159 363 minecraft:blue_terracotta
setblock 160 156 361 minecraft:dark_prismarine
fill 160 156 362 163 156 362 minecraft:blue_terracotta
fill 161 156 361 164 156 361 minecraft:blue_terracotta
setblock 163 156 363 minecraft:dark_prismarine
setblock 164 156 362 minecraft:dark_prismarine
fill 164 156 363 167 156 363 minecraft:blue_terracotta
setblock 165 156 361 minecraft:dark_prismarine
fill 165 156 362 168 156 362 minecraft:blue_terracotta
fill 166 156 361 169 156 361 minecraft:blue_terracotta
setblock 168 156 363 minecraft:dark_prismarine
fill 169 156 323 172 156 323 minecraft:blue_terracotta
fill 169 156 360 170 156 360 minecraft:blue_terracotta
setblock 169 156 362 minecraft:dark_prismarine
fill 169 156 363 169 159 363 minecraft:blue_terracotta
setblock 170 156 361 minecraft:dark_prismarine
fill 170 156 362 170 159 362 minecraft:blue_terracotta
fill 171 156 353 171 197 353 minecraft:magenta_terracotta
setblock 171 156 360 minecraft:dark_prismarine
fill 171 156 361 171 159 361 minecraft:blue_terracotta
fill 172 156 360 172 158 360 minecraft:blue_terracotta
setblock 173 156 323 minecraft:dark_prismarine
setblock 173 156 363 minecraft:dark_prismarine
fill 174 156 323 174 159 323 minecraft:blue_terracotta
setblock 174 156 362 minecraft:dark_prismarine
fill 174 156 363 174 159 363 minecraft:blue_terracotta
setblock 175 156 361 minecraft:dark_prismarine
fill 175 156 362 175 159 362 minecraft:blue_terracotta
fill 176 156 361 176 157 361 minecraft:blue_terracotta
setblock 178 156 362 minecraft:blue_terracotta
setblock 178 156 363 minecraft:dark_prismarine
setblock 179 156 362 minecraft:dark_prismarine
fill 179 156 363 179 158 363 minecraft:blue_terracotta
setblock 180 156 336 minecraft:dark_prismarine
fill 180 156 337 180 157 337 minecraft:blue_terracotta
setblock 180 156 340 minecraft:blue_terracotta
setblock 180 156 341 minecraft:dark_prismarine
fill 180 156 342 180 157 342 minecraft:blue_terracotta
setblock 181 156 335 minecraft:dark_prismarine
fill 181 156 336 181 158 336 minecraft:blue_terracotta
setblock 181 156 340 minecraft:dark_prismarine
fill 181 156 341 181 159 341 minecraft:blue_terracotta
setblock 182 156 324 minecraft:purple_concrete
setblock 182 156 334 minecraft:dark_prismarine
fill 182 156 335 182 159 335 minecraft:blue_terracotta
setblock 182 156 339 minecraft:dark_prismarine
fill 182 156 340 182 159 340 minecraft:blue_terracotta
setblock 182 156 344 minecraft:dark_prismarine
fill 182 156 345 182 159 345 minecraft:blue_terracotta
setblock 182 156 355 minecraft:blue_terracotta
setblock 182 156 359 minecraft:dark_prismarine
fill 182 156 360 182 156 361 minecraft:blue_terracotta
setblock 142 157 323 minecraft:dark_prismarine
setblock 142 157 324 minecraft:purple_concrete
setblock 142 157 333 minecraft:dark_prismarine
fill 142 157 334 142 159 334 minecraft:blue_terracotta
setblock 142 157 338 minecraft:dark_prismarine
fill 142 157 339 142 160 339 minecraft:blue_terracotta
fill 142 157 341 142 158 341 minecraft:blue_terracotta
setblock 142 157 343 minecraft:dark_prismarine
fill 142 157 349 142 158 349 minecraft:purple_concrete
setblock 142 157 353 minecraft:sea_lantern
setblock 142 157 355 minecraft:sea_lantern
fill 142 157 356 142 162 356 minecraft:dark_prismarine
setblock 142 157 357 minecraft:sea_lantern
fill 142 157 358 142 162 358 minecraft:dark_prismarine
setblock 142 157 359 minecraft:sea_lantern
setblock 142 157 361 minecraft:sea_lantern
fill 143 157 323 143 160 323 minecraft:blue_terracotta
setblock 143 157 337 minecraft:dark_prismarine
fill 143 157 338 143 158 338 minecraft:blue_terracotta
setblock 143 157 354 minecraft:sea_lantern
setblock 143 157 356 minecraft:sea_lantern
setblock 143 157 358 minecraft:sea_lantern
setblock 143 157 360 minecraft:sea_lantern
fill 143 157 363 146 157 363 minecraft:blue_terracotta
setblock 144 157 325 minecraft:light[level=13]
setblock 144 157 333 minecraft:light[level=13]
setblock 144 157 341 minecraft:light[level=13]
setblock 144 157 349 minecraft:light[level=13]
setblock 144 157 353 minecraft:sea_lantern
setblock 144 157 355 minecraft:sea_lantern
setblock 144 157 357 minecraft:sea_lantern
setblock 144 157 359 minecraft:sea_lantern
setblock 144 157 361 minecraft:sea_lantern
fill 145 157 340 145 157 345 minecraft:dark_prismarine
setblock 145 157 354 minecraft:sea_lantern
setblock 145 157 356 minecraft:sea_lantern
setblock 145 157 358 minecraft:sea_lantern
setblock 145 157 360 minecraft:sea_lantern
setblock 146 157 323 minecraft:blue_terracotta
fill 146 157 336 146 157 337 minecraft:purple_concrete
fill 146 157 338 146 157 340 minecraft:dark_prismarine
setblock 146 157 353 minecraft:sea_lantern
setblock 146 157 355 minecraft:sea_lantern
setblock 146 157 357 minecraft:sea_lantern
setblock 146 157 359 minecraft:sea_lantern
setblock 146 157 361 minecraft:sea_lantern
fill 146 157 362 147 157 362 minecraft:blue_terracotta
setblock 147 157 323 minecraft:dark_prismarine
fill 147 157 324 147 160 324 minecraft:blue_terracotta
setblock 147 157 340 minecraft:dark_prismarine
setblock 147 157 345 minecraft:dark_prismarine
fill 147 157 346 147 160 346 minecraft:iron_bars
setblock 147 157 363 minecraft:dark_prismarine
fill 148 157 323 148 160 323 minecraft:blue_terracotta
setblock 148 157 361 minecraft:blue_terracotta
setblock 148 157 362 minecraft:dark_prismarine
fill 148 157 363 148 160 363 minecraft:blue_terracotta
setblock 149 157 361 minecraft:dark_prismarine
fill 149 157 362 152 157 362 minecraft:blue_terracotta
setblock 150 157 325 minecraft:dark_prismarine
fill 150 157 361 153 157 361 minecraft:blue_terracotta
setblock 151 157 324 minecraft:dark_prismarine
fill 151 157 325 151 160 325 minecraft:blue_terracotta
fill 151 157 360 154 157 360 minecraft:blue_terracotta
setblock 152 157 323 minecraft:dark_prismarine
fill 152 157 324 152 160 324 minecraft:blue_terracotta
setblock 152 157 349 minecraft:light[level=13]
setblock 152 157 357 minecraft:light[level=13]
setblock 152 157 363 minecraft:dark_prismarine
fill 153 157 323 153 160 323 minecraft:blue_terracotta
setblock 153 157 362 minecraft:dark_prismarine
fill 153 157 363 153 160 363 minecraft:blue_terracotta
setblock 154 157 361 minecraft:dark_prismarine
fill 154 157 362 154 160 362 minecraft:blue_terracotta
setblock 155 157 360 minecraft:dark_prismarine
fill 155 157 361 155 160 361 minecraft:blue_terracotta
setblock 156 157 324 minecraft:dark_prismarine
fill 156 157 360 156 158 360 minecraft:blue_terracotta
setblock 157 157 323 minecraft:dark_prismarine
fill 157 157 324 157 158 324 minecraft:blue_terracotta
setblock 157 157 363 minecraft:dark_prismarine
fill 158 157 323 158 160 323 minecraft:blue_terracotta
setblock 158 157 362 minecraft:dark_prismarine
fill 158 157 363 158 160 363 minecraft:blue_terracotta
setblock 159 157 361 minecraft:dark_prismarine
fill 159 157 362 162 157 362 minecraft:blue_terracotta
setblock 160 157 325 minecraft:light[level=13]
setblock 160 157 333 minecraft:light[level=13]
setblock 160 157 341 minecraft:light[level=13]
setblock 160 157 349 minecraft:light[level=13]
setblock 160 157 357 minecraft:light[level=13]
fill 160 157 361 163 157 361 minecraft:blue_terracotta
setblock 162 157 363 minecraft:dark_prismarine
setblock 163 157 362 minecraft:dark_prismarine
fill 163 157 363 166 157 363 minecraft:blue_terracotta
setblock 164 157 361 minecraft:dark_prismarine
fill 164 157 362 167 157 362 minecraft:blue_terracotta
fill 165 157 361 168 157 361 minecraft:blue_terracotta
setblock 167 157 363 minecraft:dark_prismarine
fill 168 157 323 171 157 323 minecraft:blue_terracotta
setblock 168 157 325 minecraft:light[level=13]
setblock 168 157 333 minecraft:light[level=13]
setblock 168 157 341 minecraft:light[level=13]
setblock 168 157 349 minecraft:light[level=13]
setblock 168 157 357 minecraft:light[level=13]
setblock 168 157 362 minecraft:dark_prismarine
fill 168 157 363 168 160 363 minecraft:blue_terracotta
setblock 169 157 360 minecraft:blue_terracotta
setblock 169 157 361 minecraft:dark_prismarine
fill 169 157 362 169 160 362 minecraft:blue_terracotta
setblock 170 157 360 minecraft:dark_prismarine
fill 170 157 361 170 160 361 minecraft:blue_terracotta
fill 171 157 360 171 158 360 minecraft:blue_terracotta
setblock 172 157 323 minecraft:dark_prismarine
setblock 172 157 363 minecraft:dark_prismarine
fill 173 157 323 173 160 323 minecraft:blue_terracotta
setblock 173 157 362 minecraft:dark_prismarine
fill 173 157 363 173 160 363 minecraft:blue_terracotta
setblock 174 157 361 minecraft:dark_prismarine
fill 174 157 362 174 160 362 minecraft:blue_terracotta
fill 175 157 361 175 158 361 minecraft:blue_terracotta
setblock 176 157 323 minecraft:blue_terracotta
setblock 176 157 325 minecraft:light[level=13]
setblock 176 157 333 minecraft:light[level=13]
setblock 176 157 341 minecraft:light[level=13]
setblock 176 157 349 minecraft:light[level=13]
setblock 176 157 357 minecraft:light[level=13]
setblock 177 157 323 minecraft:dark_prismarine
setblock 177 157 363 minecraft:dark_prismarine
setblock 178 157 362 minecraft:dark_prismarine
fill 178 157 363 178 159 363 minecraft:blue_terracotta
setblock 180 157 340 minecraft:dark_prismarine
fill 180 157 341 180 158 341 minecraft:blue_terracotta
setblock 181 157 335 minecraft:blue_terracotta
setblock 181 157 339 minecraft:dark_prismarine
fill 181 157 340 181 160 340 minecraft:blue_terracotta
setblock 181 157 344 minecraft:dark_prismarine
setblock 182 157 333 minecraft:dark_prismarine
fill 182 157 334 182 159 334 minecraft:blue_terracotta
setblock 182 157 338 minecraft:dark_prismarine
fill 182 157 339 182 160 339 minecraft:blue_terracotta
setblock 182 157 343 minecraft:dark_prismarine
fill 182 157 344 182 160 344 minecraft:blue_terracotta
setblock 182 157 358 minecraft:dark_prismarine
fill 182 157 359 182 157 360 minecraft:blue_terracotta
setblock 182 157 362 minecraft:purple_concrete
fill 142 158 323 142 160 324 minecraft:blue_terracotta
setblock 142 158 330 minecraft:purple_concrete
setblock 142 158 332 minecraft:dark_prismarine
setblock 142 158 333 minecraft:blue_terracotta
setblock 142 158 336 minecraft:blue_terracotta
setblock 142 158 337 minecraft:dark_prismarine
fill 142 158 338 142 161 338 minecraft:blue_terracotta
setblock 142 158 342 minecraft:dark_prismarine
fill 142 158 343 142 159 343 minecraft:blue_terracotta
fill 142 158 353 142 159 353 minecraft:dark_prismarine
setblock 142 158 355 minecraft:purple_concrete
fill 142 158 357 142 159 357 minecraft:dark_prismarine
fill 142 158 359 142 158 361 minecraft:dark_prismarine
setblock 143 158 336 minecraft:dark_prismarine
setblock 143 158 337 minecraft:blue_terracotta
fill 143 158 354 143 159 354 minecraft:dark_prismarine
fill 143 158 356 143 159 356 minecraft:dark_prismarine
fill 143 158 358 143 159 358 minecraft:dark_prismarine
fill 143 158 360 143 159 360 minecraft:dark_prismarine
fill 143 158 363 145 158 363 minecraft:blue_terracotta
fill 144 158 353 144 159 353 minecraft:dark_prismarine
fill 144 158 355 144 159 355 minecraft:dark_prismarine
fill 144 158 357 144 159 357 minecraft:dark_prismarine
fill 144 158 359 144 159 359 minecraft:dark_prismarine
fill 144 158 361 144 159 361 minecraft:dark_prismarine
fill 145 158 354 145 159 354 minecraft:dark_prismarine
fill 145 158 356 145 159 356 minecraft:dark_prismarine
fill 145 158 358 145 159 358 minecraft:dark_prismarine
fill 145 158 360 145 159 360 minecraft:dark_prismarine
setblock 146 158 323 minecraft:dark_prismarine
fill 146 158 324 146 161 324 minecraft:blue_terracotta
fill 146 158 338 146 158 347 minecraft:purple_concrete
fill 146 158 353 146 159 353 minecraft:dark_prismarine
fill 146 158 355 146 159 355 minecraft:dark_prismarine
fill 146 158 357 146 159 357 minecraft:dark_prismarine
fill 146 158 359 146 159 359 minecraft:dark_prismarine
fill 146 158 361 146 159 361 minecraft:dark_prismarine
setblock 146 158 362 minecraft:blue_terracotta
setblock 146 158 363 minecraft:dark_prismarine
fill 147 158 323 147 161 323 minecraft:blue_terracotta
setblock 147 158 362 minecraft:dark_prismarine
fill 147 158 363 147 161 363 minecraft:blue_terracotta
setblock 148 158 361 minecraft:dark_prismarine
fill 148 158 362 151 158 362 minecraft:blue_terracotta
fill 149 158 361 152 158 361 minecraft:blue_terracotta
setblock 150 158 324 minecraft:dark_prismarine
fill 150 158 325 150 161 325 minecraft:blue_terracotta
setblock 151 158 323 minecraft:dark_prismarine
fill 151 158 324 151 161 324 minecraft:blue_terracotta
fill 151 158 360 153 158 360 minecraft:blue_terracotta
setblock 151 158 363 minecraft:dark_prismarine
fill 152 158 323 152 161 323 minecraft:blue_terracotta
setblock 152 158 362 minecraft:dark_prismarine
fill 152 158 363 152 161 363 minecraft:blue_terracotta
setblock 153 158 361 minecraft:dark_prismarine
fill 153 158 362 153 161 362 minecraft:blue_terracotta
setblock 154 158 360 minecraft:dark_prismarine
fill 154 158 361 154 161 361 minecraft:blue_terracotta
setblock 155 158 324 minecraft:dark_prismarine
setblock 155 158 360 minecraft:blue_terracotta
setblock 156 158 323 minecraft:dark_prismarine
fill 156 158 324 156 160 324 minecraft:blue_terracotta
setblock 156 158 363 minecraft:dark_prismarine
fill 157 158 323 157 161 323 minecraft:blue_terracotta
setblock 157 158 362 minecraft:dark_prismarine
fill 157 158 363 157 161 363 minecraft:blue_terracotta
setblock 158 158 361 minecraft:dark_prismarine
fill 158 158 362 161 158 362 minecraft:blue_terracotta
fill 159 158 361 160 158 361 minecraft:blue_terracotta
setblock 161 158 363 minecraft:dark_prismarine
setblock 162 158 362 minecraft:dark_prismarine
fill 162 158 363 165 158 363 minecraft:blue_terracotta
fill 163 158 362 166 158 362 minecraft:blue_terracotta
fill 165 158 361 167 158 361 minecraft:blue_terracotta
setblock 166 158 363 minecraft:dark_prismarine
fill 167 158 323 170 158 323 minecraft:blue_terracotta
setblock 167 158 362 minecraft:dark_prismarine
fill 167 158 363 167 161 363 minecraft:blue_terracotta
setblock 168 158 361 minecraft:dark_prismarine
fill 168 158 362 168 161 362 minecraft:blue_terracotta
fill 169 158 361 169 161 361 minecraft:blue_terracotta
setblock 170 158 360 minecraft:blue_terracotta
setblock 171 158 323 minecraft:dark_prismarine
setblock 171 158 363 minecraft:dark_prismarine
fill 172 158 323 172 161 323 minecraft:blue_terracotta
setblock 172 158 362 minecraft:dark_prismarine
fill 172 158 363 172 161 363 minecraft:blue_terracotta
setblock 173 158 361 minecraft:dark_prismarine
fill 173 158 362 173 161 362 minecraft:blue_terracotta
fill 174 158 361 174 159 361 minecraft:blue_terracotta
setblock 176 158 323 minecraft:dark_prismarine
setblock 176 158 363 minecraft:dark_prismarine
setblock 177 158 362 minecraft:dark_prismarine
fill 177 158 363 177 160 363 minecraft:blue_terracotta
setblock 180 158 339 minecraft:dark_prismarine
setblock 180 158 340 minecraft:blue_terracotta
setblock 181 158 338 minecraft:dark_prismarine
fill 181 158 339 181 160 339 minecraft:blue_terracotta
setblock 181 158 343 minecraft:dark_prismarine
setblock 181 158 344 minecraft:blue_terracotta
setblock 182 158 331 minecraft:purple_concrete
setblock 182 158 333 minecraft:blue_terracotta
setblock 182 158 337 minecraft:dark_prismarine
fill 182 158 338 182 161 338 minecraft:blue_terracotta
setblock 182 158 342 minecraft:dark_prismarine
fill 182 158 343 182 161 343 minecraft:blue_terracotta
setblock 182 158 356 minecraft:purple_concrete
setblock 183 158 342 minecraft:light_blue_wool
fill 141 159 336 141 218 336 minecraft:blue_terracotta
setblock 141 159 337 minecraft:light_blue_wool
fill 141 159 338 141 171 338 minecraft:blue_terracotta
setblock 142 159 336 minecraft:dark_prismarine
fill 142 159 337 142 160 337 minecraft:blue_terracotta
setblock 142 159 341 minecraft:dark_prismarine
fill 142 159 342 142 162 342 minecraft:blue_terracotta
setblock 142 159 355 minecraft:dark_prismarine
fill 142 159 359 142 159 360 minecraft:dark_prismarine
setblock 142 159 361 minecraft:purple_concrete
fill 143 159 363 144 159 363 minecraft:blue_terracotta
setblock 145 159 323 minecraft:dark_prismarine
setblock 145 159 363 minecraft:dark_prismarine
fill 146 159 323 146 162 323 minecraft:blue_terracotta
setblock 146 159 362 minecraft:dark_prismarine
fill 146 159 363 146 162 363 minecraft:blue_terracotta
fill 147 159 362 150 159 362 minecraft:blue_terracotta
setblock 148 159 322 minecraft:cyan_concrete
fill 148 159 361 151 159 361 minecraft:blue_terracotta
setblock 149 159 324 minecraft:dark_prismarine
fill 149 159 325 149 162 325 minecraft:blue_terracotta
setblock 150 159 323 minecraft:dark_prismarine
fill 150 159 324 150 162 324 minecraft:blue_terracotta
fill 150 159 338 150 159 342 minecraft:purple_concrete
setblock 150 159 363 minecraft:dark_prismarine
fill 151 159 323 151 162 323 minecraft:blue_terracotta
fill 151 159 338 153 159 338 minecraft:purple_concrete
fill 151 159 342 153 159 342 minecraft:purple_concrete
setblock 151 159 362 minecraft:dark_prismarine
fill 151 159 363 151 162 363 minecraft:blue_terracotta
setblock 152 159 360 minecraft:blue_terracotta
setblock 152 159 361 minecraft:dark_prismarine
fill 152 159 362 152 162 362 minecraft:blue_terracotta
fill 153 159 339 154 159 339 minecraft:purple_concrete
fill 153 159 341 154 159 341 minecraft:purple_concrete
setblock 153 159 360 minecraft:dark_prismarine
fill 153 159 361 153 162 361 minecraft:blue_terracotta
setblock 154 159 324 minecraft:dark_prismarine
fill 154 159 340 154 160 340 minecraft:purple_concrete
setblock 155 159 323 minecraft:dark_prismarine
fill 155 159 324 155 162 324 minecraft:blue_terracotta
setblock 155 159 363 minecraft:dark_prismarine
fill 156 159 323 156 162 323 minecraft:blue_terracotta
setblock 156 159 362 minecraft:dark_prismarine
fill 156 159 363 156 162 363 minecraft:blue_terracotta
fill 157 159 359 157 179 359 minecraft:magenta_terracotta
setblock 157 159 361 minecraft:dark_prismarine
fill 157 159 362 160 159 362 minecraft:blue_terracotta
setblock 158 159 361 minecraft:blue_terracotta
setblock 160 159 323 minecraft:dark_prismarine
setblock 160 159 363 minecraft:dark_prismarine
setblock 161 159 362 minecraft:dark_prismarine
fill 161 159 363 164 159 363 minecraft:blue_terracotta
fill 162 159 362 165 159 362 minecraft:blue_terracotta
setblock 165 159 323 minecraft:purple_concrete
setblock 165 159 363 minecraft:dark_prismarine
setblock 166 159 361 minecraft:blue_terracotta
setblock 166 159 362 minecraft:dark_prismarine
fill 166 159 363 166 162 363 minecraft:blue_terracotta
fill 167 159 323 169 159 323 minecraft:blue_terracotta
setblock 167 159 361 minecraft:dark_prismarine
fill 167 159 362 167 162 362 minecraft:blue_terracotta
fill 168 159 361 168 161 361 minecraft:blue_terracotta
setblock 170 159 323 minecraft:dark_prismarine
setblock 170 159 363 minecraft:dark_prismarine
fill 171 159 323 171 162 323 minecraft:blue_terracotta
setblock 171 159 362 minecraft:dark_prismarine
fill 171 159 363 171 162 363 minecraft:blue_terracotta
fill 172 159 346 172 159 349 minecraft:purple_concrete
setblock 172 159 361 minecraft:dark_prismarine
fill 172 159 362 172 162 362 minecraft:blue_terracotta
fill 173 159 345 173 159 346 minecraft:purple_concrete
fill 173 159 349 175 160 349 minecraft:purple_concrete
setblock 173 159 361 minecraft:blue_terracotta
fill 174 159 345 175 159 345 minecraft:purple_concrete
setblock 175 159 323 minecraft:dark_prismarine
fill 175 159 346 176 159 346 minecraft:purple_concrete
fill 175 159 348 176 159 348 minecraft:purple_concrete
setblock 175 159 363 minecraft:dark_prismarine
setblock 176 159 323 minecraft:blue_terracotta
fill 176 159 328 177 159 330 minecraft:purple_concrete
fill 176 159 347 176 160 347 minecraft:purple_concrete
setblock 176 159 362 minecraft:dark_prismarine
fill 176 159 363 176 161 363 minecraft:blue_terracotta
fill 177 159 327 181 160 327 minecraft:purple_concrete
fill 177 159 331 181 159 331 minecraft:purple_concrete
fill 177 159 339 177 211 339 minecraft:magenta_terracotta
fill 178 159 326 180 159 326 minecraft:purple_concrete
fill 178 159 332 180 159 332 minecraft:purple_concrete
fill 181 159 328 182 159 330 minecraft:purple_concrete
setblock 181 159 337 minecraft:dark_prismarine
fill 181 159 338 181 160 338 minecraft:blue_terracotta
setblock 181 159 342 minecraft:dark_prismarine
fill 181 159 343 181 160 343 minecraft:blue_terracotta
setblock 182 159 325 minecraft:purple_concrete
setblock 182 159 336 minecraft:dark_prismarine
fill 182 159 337 182 162 337 minecraft:blue_terracotta
setblock 182 159 341 minecraft:dark_prismarine
fill 182 159 342 183 162 342 minecraft:blue_terracotta
setblock 182 159 350 minecraft:purple_concrete
fill 141 160 337 141 216 337 minecraft:blue_terracotta
setblock 142 160 325 minecraft:dark_prismarine
setblock 142 160 336 minecraft:blue_terracotta
setblock 142 160 340 minecraft:dark_prismarine
fill 142 160 341 142 162 341 minecraft:blue_terracotta
setblock 142 160 353 minecraft:sea_lantern
setblock 142 160 355 minecraft:sea_lantern
setblock 142 160 357 minecraft:sea_lantern
setblock 142 160 359 minecraft:sea_lantern
fill 142 160 360 142 162 360 minecraft:dark_prismarine
setblock 142 160 361 minecraft:sea_lantern
setblock 143 160 354 minecraft:sea_lantern
setblock 143 160 356 minecraft:sea_lantern
setblock 143 160 358 minecraft:sea_lantern
setblock 143 160 360 minecraft:sea_lantern
setblock 143 160 363 minecraft:blue_terracotta
setblock 144 160 323 minecraft:dark_prismarine
setblock 144 160 353 minecraft:sea_lantern
setblock 144 160 355 minecraft:sea_lantern
setblock 144 160 357 minecraft:sea_lantern
setblock 144 160 359 minecraft:sea_lantern
setblock 144 160 361 minecraft:sea_lantern
setblock 144 160 363 minecraft:dark_prismarine
fill 145 160 323 145 162 324 minecraft:blue_terracotta
setblock 145 160 354 minecraft:sea_lantern
setblock 145 160 356 minecraft:sea_lantern
setblock 145 160 358 minecraft:sea_lantern
setblock 145 160 360 minecraft:sea_lantern
fill 145 160 363 145 162 363 minecraft:blue_terracotta
setblock 146 160 353 minecraft:sea_lantern
setblock 146 160 355 minecraft:sea_lantern
setblock 146 160 357 minecraft:sea_lantern
setblock 146 160 359 minecraft:sea_lantern
setblock 146 160 361 minecraft:sea_lantern
fill 146 160 362 149 160 362 minecraft:blue_terracotta
fill 148 160 322 148 221 322 minecraft:blue_terracotta
setblock 148 160 324 minecraft:dark_prismarine
fill 148 160 361 150 160 361 minecraft:blue_terracotta
setblock 149 160 323 minecraft:dark_prismarine
fill 149 160 324 149 162 324 minecraft:blue_terracotta
setblock 149 160 363 minecraft:dark_prismarine
fill 150 160 323 150 162 323 minecraft:blue_terracotta
fill 150 160 339 150 160 341 minecraft:purple_concrete
setblock 150 160 362 minecraft:dark_prismarine
fill 150 160 363 150 162 363 minecraft:blue_terracotta
fill 151 160 338 152 160 338 minecraft:purple_concrete
fill 151 160 342 152 160 342 minecraft:purple_concrete
setblock 151 160 361 minecraft:dark_prismarine
fill 151 160 362 151 162 362 minecraft:blue_terracotta
setblock 152 160 325 minecraft:dark_prismarine
fill 152 160 361 152 162 361 minecraft:blue_terracotta
setblock 153 160 324 minecraft:dark_prismarine
fill 153 160 333 153 200 333 minecraft:magenta_terracotta
fill 153 160 339 153 161 339 minecraft:purple_concrete
fill 153 160 341 153 161 341 minecraft:purple_concrete
setblock 154 160 323 minecraft:dark_prismarine
fill 154 160 324 154 162 324 minecraft:blue_terracotta
setblock 154 160 363 minecraft:dark_prismarine
fill 155 160 323 155 162 323 minecraft:blue_terracotta
setblock 155 160 362 minecraft:dark_prismarine
fill 155 160 363 155 162 363 minecraft:blue_terracotta
fill 156 160 359 156 234 359 minecraft:magenta_terracotta
setblock 156 160 361 minecraft:dark_prismarine
fill 156 160 362 159 160 362 minecraft:blue_terracotta
fill 157 160 357 157 179 357 minecraft:magenta_terracotta
setblock 157 160 361 minecraft:blue_terracotta
setblock 159 160 323 minecraft:dark_prismarine
setblock 159 160 363 minecraft:dark_prismarine
setblock 160 160 362 minecraft:dark_prismarine
fill 160 160 363 163 160 363 minecraft:blue_terracotta
fill 161 160 362 164 160 362 minecraft:blue_terracotta
setblock 164 160 363 minecraft:dark_prismarine
setblock 165 160 362 minecraft:dark_prismarine
fill 165 160 363 165 162 363 minecraft:blue_terracotta
fill 166 160 323 168 160 323 minecraft:blue_terracotta
fill 166 160 362 166 162 362 minecraft:blue_terracotta
setblock 167 160 361 minecraft:blue_terracotta
setblock 169 160 323 minecraft:dark_prismarine
fill 169 160 329 169 204 329 minecraft:magenta_terracotta
setblock 169 160 363 minecraft:dark_prismarine
fill 170 160 323 170 162 323 minecraft:blue_terracotta
setblock 170 160 362 minecraft:dark_prismarine
fill 170 160 363 170 162 363 minecraft:blue_terracotta
setblock 171 160 361 minecraft:dark_prismarine
fill 171 160 362 171 162 362 minecraft:blue_terracotta
fill 172 160 346 172 160 348 minecraft:purple_concrete
setblock 172 160 361 minecraft:blue_terracotta
fill 173 160 346 173 161 346 minecraft:purple_concrete
setblock 174 160 323 minecraft:dark_prismarine
setblock 174 160 345 minecraft:purple_concrete
setblock 174 160 363 minecraft:dark_prismarine
fill 175 160 323 175 162 323 minecraft:blue_terracotta
fill 175 160 346 175 161 346 minecraft:purple_concrete
fill 175 160 348 175 161 348 minecraft:purple_concrete
setblock 175 160 362 minecraft:dark_prismarine
fill 175 160 363 175 162 363 minecraft:blue_terracotta
fill 177 160 328 177 161 330 minecraft:purple_concrete
setblock 178 160 323 minecraft:purple_concrete
fill 178 160 331 180 161 331 minecraft:purple_concrete
fill 181 160 328 181 161 330 minecraft:purple_concrete
setblock 181 160 341 minecraft:dark_prismarine
fill 181 160 342 181 161 342 minecraft:blue_terracotta
setblock 182 160 335 minecraft:dark_prismarine
fill 182 160 336 182 161 336 minecraft:blue_terracotta
setblock 182 160 340 minecraft:dark_prismarine
fill 182 160 341 182 162 341 minecraft:blue_terracotta
setblock 182 160 345 minecraft:dark_prismarine
setblock 142 161 323 minecraft:blue_terracotta
setblock 142 161 324 minecraft:dark_prismarine
fill 142 161 325 142 162 325 minecraft:blue_terracotta
setblock 142 161 329 minecraft:purple_concrete
setblock 142 161 339 minecraft:dark_prismarine
fill 142 161 340 142 162 340 minecraft:blue_terracotta
setblock 142 161 348 minecraft:purple_concrete
fill 142 161 353 142 162 353 minecraft:dark_prismarine
fill 142 161 355 142 162 355 minecraft:dark_prismarine
fill 142 161 357 142 162 357 minecraft:dark_prismarine
fill 142 161 359 142 162 359 minecraft:dark_prismarine
fill 142 161 361 142 162 361 minecraft:dark_prismarine
setblock 143 161 323 minecraft:dark_prismarine
fill 143 161 354 143 162 354 minecraft:dark_prismarine
fill 143 161 356 143 162 356 minecraft:dark_prismarine
fill 143 161 358 143 162 358 minecraft:dark_prismarine
fill 143 161 360 143 162 360 minecraft:dark_prismarine
setblock 143 161 363 minecraft:dark_prismarine
fill 144 161 323 144 162 324 minecraft:blue_terracotta
setblock 144 161 325 minecraft:light[level=12]
setblock 144 161 332 minecraft:light[level=12]
setblock 144 161 339 minecraft:light[level=12]
setblock 144 161 346 minecraft:light[level=12]
fill 144 161 353 144 162 353 minecraft:dark_prismarine
fill 144 161 355 144 162 355 minecraft:dark_prismarine
fill 144 161 357 144 162 357 minecraft:dark_prismarine
fill 144 161 359 144 162 359 minecraft:dark_prismarine
fill 144 161 361 144 162 361 minecraft:dark_prismarine
fill 144 161 363 144 162 363 minecraft:blue_terracotta
fill 145 161 354 145 162 354 minecraft:dark_prismarine
fill 145 161 356 145 162 356 minecraft:dark_prismarine
fill 145 161 358 145 162 358 minecraft:dark_prismarine
fill 145 161 360 145 162 360 minecraft:dark_prismarine
fill 146 161 353 146 162 353 minecraft:dark_prismarine
fill 146 161 355 146 162 355 minecraft:dark_prismarine
fill 146 161 357 146 162 357 minecraft:dark_prismarine
fill 146 161 359 146 162 359 minecraft:dark_prismarine
fill 146 161 361 146 162 361 minecraft:dark_prismarine
fill 146 161 362 148 161 362 minecraft:blue_terracotta
setblock 147 161 324 minecraft:dark_prismarine
fill 147 161 348 147 161 349 minecraft:pink_terracotta
setblock 148 161 323 minecraft:dark_prismarine
fill 148 161 324 148 162 325 minecraft:blue_terracotta
fill 148 161 361 149 161 361 minecraft:blue_terracotta
setblock 148 161 363 minecraft:dark_prismarine
fill 149 161 323 149 162 323 minecraft:blue_terracotta
setblock 149 161 362 minecraft:dark_prismarine
fill 149 161 363 149 162 363 minecraft:blue_terracotta
setblock 150 161 340 minecraft:purple_concrete
setblock 150 161 361 minecraft:dark_prismarine
fill 150 161 362 150 162 362 minecraft:blue_terracotta
setblock 151 161 325 minecraft:dark_prismarine
setblock 151 161 332 minecraft:light[level=12]
setblock 151 161 346 minecraft:light[level=12]
setblock 151 161 353 minecraft:light[level=12]
setblock 151 161 360 minecraft:light[level=12]
fill 151 161 361 151 162 361 minecraft:blue_terracotta
setblock 152 161 324 minecraft:dark_prismarine
setblock 152 161 325 minecraft:blue_terracotta
setblock 152 161 334 minecraft:pink_terracotta
setblock 153 161 323 minecraft:dark_prismarine
fill 153 161 324 153 162 324 minecraft:blue_terracotta
setblock 153 161 363 minecraft:dark_prismarine
fill 154 161 323 154 162 323 minecraft:blue_terracotta
setblock 154 161 362 minecraft:dark_prismarine
fill 154 161 363 154 162 363 minecraft:blue_terracotta
fill 155 161 358 155 234 358 minecraft:magenta_terracotta
setblock 155 161 361 minecraft:dark_prismarine
fill 155 161 362 158 161 362 minecraft:blue_terracotta
setblock 156 161 358 minecraft:pink_terracotta
setblock 158 161 323 minecraft:dark_prismarine
setblock 158 161 325 minecraft:light[level=12]
setblock 158 161 332 minecraft:light[level=12]
setblock 158 161 339 minecraft:light[level=12]
setblock 158 161 346 minecraft:light[level=12]
setblock 158 161 353 minecraft:light[level=12]
setblock 158 161 360 minecraft:light[level=12]
setblock 158 161 363 minecraft:dark_prismarine
setblock 159 161 323 minecraft:blue_terracotta
setblock 159 161 362 minecraft:dark_prismarine
fill 159 161 363 162 161 363 minecraft:blue_terracotta
fill 160 161 362 163 161 362 minecraft:blue_terracotta
setblock 163 161 363 minecraft:dark_prismarine
setblock 164 161 362 minecraft:dark_prismarine
fill 164 161 363 164 162 363 minecraft:blue_terracotta
setblock 165 161 325 minecraft:light[level=12]
setblock 165 161 332 minecraft:light[level=12]
setblock 165 161 339 minecraft:light[level=12]
setblock 165 161 346 minecraft:light[level=12]
setblock 165 161 353 minecraft:light[level=12]
setblock 165 161 360 minecraft:light[level=12]
fill 165 161 362 165 162 362 minecraft:blue_terracotta
fill 166 161 323 167 161 323 minecraft:blue_terracotta
fill 167 161 329 168 161 329 minecraft:pink_terracotta
fill 167 161 330 167 164 330 minecraft:magenta_terracotta
setblock 168 161 323 minecraft:dark_prismarine
setblock 168 161 363 minecraft:dark_prismarine
fill 169 161 323 169 162 323 minecraft:blue_terracotta
setblock 169 161 362 minecraft:dark_prismarine
fill 169 161 363 169 162 363 minecraft:blue_terracotta
setblock 170 161 361 minecraft:dark_prismarine
fill 170 161 362 170 162 362 minecraft:blue_terracotta
fill 171 161 352 172 161 352 minecraft:pink_terracotta
setblock 171 161 361 minecraft:blue_terracotta
setblock 172 161 325 minecraft:light[level=12]
setblock 172 161 332 minecraft:light[level=12]
setblock 172 161 339 minecraft:light[level=12]
setblock 172 161 346 minecraft:light[level=12]
setblock 172 161 360 minecraft:light[level=12]
setblock 173 161 323 minecraft:dark_prismarine
setblock 173 161 363 minecraft:dark_prismarine
fill 174 161 323 174 162 323 minecraft:blue_terracotta
setblock 174 161 362 minecraft:dark_prismarine
fill 174 161 363 174 162 363 minecraft:blue_terracotta
fill 177 161 337 177 194 337 minecraft:magenta_terracotta
fill 177 161 338 178 161 338 minecraft:pink_terracotta
fill 178 161 327 180 161 327 minecraft:purple_concrete
setblock 179 161 325 minecraft:light[level=12]
setblock 179 161 332 minecraft:light[level=12]
fill 179 161 338 179 162 338 minecraft:magenta_terracotta
setblock 179 161 339 minecraft:light[level=12]
setblock 179 161 346 minecraft:light[level=12]
setblock 179 161 353 minecraft:light[level=12]
setblock 179 161 360 minecraft:light[level=12]
setblock 181 161 340 minecraft:dark_prismarine
setblock 181 161 341 minecraft:blue_terracotta
setblock 182 161 339 minecraft:dark_prismarine
fill 182 161 340 182 162 340 minecraft:blue_terracotta
setblock 182 161 344 minecraft:dark_prismarine
fill 182 161 345 182 162 345 minecraft:blue_terracotta
setblock 182 161 357 minecraft:purple_concrete
setblock 141 162 345 minecraft:light_blue_wool
setblock 142 162 323 minecraft:dark_prismarine
fill 142 162 324 143 162 324 minecraft:blue_terracotta
setblock 142 162 326 minecraft:blue_terracotta
setblock 142 162 335 minecraft:purple_concrete
setblock 142 162 339 minecraft:blue_terracotta
schedule function dropper:buildpart/75_9 1t
