fill 126 -3 511 126 -2 511 minecraft:blackstone
setblock 126 -3 550 minecraft:smooth_basalt
fill 126 -3 551 126 0 551 minecraft:blackstone
fill 127 -3 550 127 -2 550 minecraft:blackstone
setblock 129 -3 513 minecraft:light[level=12]
setblock 129 -3 521 minecraft:light[level=12]
setblock 129 -3 529 minecraft:light[level=12]
setblock 129 -3 537 minecraft:light[level=12]
setblock 133 -3 539 minecraft:blackstone
setblock 134 -3 537 minecraft:smooth_basalt
fill 134 -3 538 134 -1 538 minecraft:blackstone
setblock 134 -3 542 minecraft:smooth_basalt
fill 134 -3 543 134 0 543 minecraft:blackstone
setblock 135 -3 517 minecraft:blackstone
fill 135 -3 519 135 -3 520 minecraft:blackstone
setblock 135 -3 521 minecraft:smooth_basalt
fill 135 -3 522 135 0 522 minecraft:blackstone
fill 135 -3 524 135 -3 525 minecraft:blackstone
setblock 135 -3 532 minecraft:blackstone
setblock 135 -3 536 minecraft:smooth_basalt
fill 135 -3 537 135 0 537 minecraft:blackstone
setblock 135 -3 541 minecraft:smooth_basalt
fill 135 -3 542 135 0 542 minecraft:blackstone
setblock 135 -3 546 minecraft:smooth_basalt
setblock 95 -2 515 minecraft:smooth_basalt
fill 95 -2 516 95 1 516 minecraft:blackstone
setblock 95 -2 520 minecraft:smooth_basalt
fill 95 -2 521 95 1 521 minecraft:blackstone
setblock 95 -2 525 minecraft:smooth_basalt
fill 95 -2 526 95 1 526 minecraft:blackstone
setblock 95 -2 530 minecraft:smooth_basalt
setblock 95 -2 531 minecraft:blackstone
setblock 95 -2 535 minecraft:smooth_basalt
fill 95 -2 536 95 -1 536 minecraft:blackstone
setblock 95 -2 540 minecraft:smooth_basalt
fill 95 -2 541 95 0 542 minecraft:blackstone
setblock 96 -2 519 minecraft:smooth_basalt
fill 96 -2 520 96 1 520 minecraft:blackstone
setblock 96 -2 524 minecraft:smooth_basalt
fill 96 -2 525 96 1 525 minecraft:blackstone
setblock 96 -2 539 minecraft:smooth_basalt
setblock 96 -2 540 minecraft:blackstone
setblock 97 -2 517 minecraft:blackstone
setblock 97 -2 518 minecraft:smooth_basalt
fill 97 -2 519 97 1 519 minecraft:blackstone
setblock 97 -2 523 minecraft:smooth_basalt
fill 97 -2 524 97 1 524 minecraft:blackstone
fill 98 -2 520 98 -2 521 minecraft:blackstone
setblock 99 -2 511 minecraft:smooth_basalt
fill 100 -2 511 103 -2 511 minecraft:blackstone
fill 101 -2 551 101 0 551 minecraft:blackstone
setblock 102 -2 513 minecraft:smooth_basalt
setblock 103 -2 512 minecraft:smooth_basalt
setblock 103 -2 513 minecraft:blackstone
setblock 104 -2 511 minecraft:smooth_basalt
fill 104 -2 512 107 -2 512 minecraft:blackstone
setblock 104 -2 551 minecraft:smooth_basalt
fill 105 -2 511 108 -2 511 minecraft:blackstone
fill 105 -2 551 105 -1 551 minecraft:blackstone
setblock 108 -2 512 minecraft:smooth_basalt
setblock 109 -2 511 minecraft:smooth_basalt
fill 110 -2 511 111 -2 511 minecraft:blackstone
setblock 114 -2 511 minecraft:smooth_basalt
setblock 115 -2 511 minecraft:blackstone
fill 118 -2 550 118 -1 550 minecraft:blackstone
setblock 119 -2 511 minecraft:smooth_basalt
setblock 119 -2 512 minecraft:blackstone
setblock 119 -2 551 minecraft:smooth_basalt
fill 120 -2 511 120 1 511 minecraft:blackstone
setblock 120 -2 549 minecraft:blackstone
setblock 120 -2 550 minecraft:smooth_basalt
fill 120 -2 551 120 1 551 minecraft:blackstone
setblock 121 -2 549 minecraft:smooth_basalt
fill 121 -2 550 121 1 550 minecraft:blackstone
fill 122 -2 549 122 1 549 minecraft:blackstone
setblock 123 -2 512 minecraft:smooth_basalt
setblock 124 -2 511 minecraft:smooth_basalt
setblock 124 -2 551 minecraft:smooth_basalt
fill 125 -2 511 125 -1 511 minecraft:blackstone
setblock 125 -2 550 minecraft:smooth_basalt
fill 125 -2 551 125 1 551 minecraft:blackstone
fill 126 -2 550 126 -1 550 minecraft:blackstone
setblock 134 -2 537 minecraft:blackstone
setblock 134 -2 541 minecraft:smooth_basalt
fill 134 -2 542 134 1 542 minecraft:blackstone
setblock 135 -2 519 minecraft:blackstone
setblock 135 -2 520 minecraft:smooth_basalt
fill 135 -2 521 135 1 521 minecraft:blackstone
setblock 135 -2 524 minecraft:blackstone
setblock 135 -2 525 minecraft:smooth_basalt
fill 135 -2 526 135 1 526 minecraft:blackstone
setblock 135 -2 535 minecraft:smooth_basalt
fill 135 -2 536 135 1 536 minecraft:blackstone
setblock 135 -2 540 minecraft:smooth_basalt
fill 135 -2 541 135 1 541 minecraft:blackstone
setblock 135 -2 545 minecraft:smooth_basalt
fill 135 -2 546 135 0 547 minecraft:blackstone
setblock 95 -1 515 minecraft:blackstone
setblock 95 -1 519 minecraft:smooth_basalt
fill 95 -1 520 95 2 520 minecraft:blackstone
setblock 95 -1 524 minecraft:smooth_basalt
fill 95 -1 525 95 2 525 minecraft:blackstone
setblock 95 -1 529 minecraft:smooth_basalt
fill 95 -1 530 95 2 530 minecraft:blackstone
setblock 95 -1 535 minecraft:blackstone
setblock 95 -1 539 minecraft:smooth_basalt
fill 95 -1 540 95 1 540 minecraft:blackstone
setblock 95 -1 543 minecraft:blackstone
setblock 95 -1 544 minecraft:smooth_basalt
setblock 96 -1 518 minecraft:smooth_basalt
fill 96 -1 519 96 2 519 minecraft:blackstone
setblock 96 -1 522 minecraft:blackstone
setblock 96 -1 523 minecraft:smooth_basalt
fill 96 -1 524 96 2 524 minecraft:blackstone
setblock 96 -1 527 minecraft:blackstone
fill 97 -1 518 97 0 518 minecraft:blackstone
setblock 97 -1 522 minecraft:smooth_basalt
fill 97 -1 523 97 2 523 minecraft:blackstone
fill 97 -1 525 97 0 525 minecraft:blackstone
setblock 98 -1 520 minecraft:blackstone
setblock 98 -1 521 minecraft:smooth_basalt
fill 98 -1 522 98 2 522 minecraft:blackstone
fill 99 -1 511 102 -1 511 minecraft:blackstone
setblock 102 -1 512 minecraft:smooth_basalt
setblock 103 -1 511 minecraft:smooth_basalt
fill 103 -1 512 106 -1 512 minecraft:blackstone
setblock 103 -1 551 minecraft:smooth_basalt
fill 104 -1 511 107 -1 511 minecraft:blackstone
fill 104 -1 551 104 2 551 minecraft:blackstone
setblock 108 -1 511 minecraft:smooth_basalt
setblock 109 -1 511 minecraft:blackstone
fill 115 -1 551 115 1 551 minecraft:blackstone
setblock 118 -1 511 minecraft:smooth_basalt
setblock 118 -1 551 minecraft:smooth_basalt
fill 119 -1 511 119 2 511 minecraft:blackstone
setblock 119 -1 550 minecraft:smooth_basalt
fill 119 -1 551 119 2 551 minecraft:blackstone
setblock 120 -1 549 minecraft:smooth_basalt
fill 120 -1 550 120 2 550 minecraft:blackstone
fill 121 -1 549 121 2 549 minecraft:blackstone
setblock 123 -1 511 minecraft:smooth_basalt
setblock 123 -1 551 minecraft:smooth_basalt
setblock 124 -1 511 minecraft:blackstone
setblock 124 -1 550 minecraft:smooth_basalt
fill 124 -1 551 124 2 551 minecraft:blackstone
fill 125 -1 550 125 1 550 minecraft:blackstone
setblock 134 -1 540 minecraft:smooth_basalt
fill 134 -1 541 134 1 541 minecraft:blackstone
setblock 135 -1 519 minecraft:smooth_basalt
fill 135 -1 520 135 2 520 minecraft:blackstone
setblock 135 -1 524 minecraft:smooth_basalt
fill 135 -1 525 135 2 525 minecraft:blackstone
fill 135 -1 527 135 0 527 minecraft:blackstone
setblock 135 -1 534 minecraft:smooth_basalt
fill 135 -1 535 135 0 535 minecraft:blackstone
setblock 135 -1 539 minecraft:smooth_basalt
fill 135 -1 540 135 2 540 minecraft:blackstone
setblock 135 -1 544 minecraft:smooth_basalt
fill 135 -1 545 135 2 545 minecraft:blackstone
setblock 95 0 518 minecraft:smooth_basalt
fill 95 0 519 95 3 519 minecraft:blackstone
setblock 95 0 523 minecraft:smooth_basalt
fill 95 0 524 95 3 524 minecraft:blackstone
setblock 95 0 528 minecraft:smooth_basalt
fill 95 0 529 95 3 529 minecraft:blackstone
setblock 95 0 538 minecraft:smooth_basalt
setblock 95 0 539 minecraft:blackstone
setblock 95 0 543 minecraft:smooth_basalt
fill 95 0 544 95 3 544 minecraft:blackstone
setblock 96 0 517 minecraft:smooth_basalt
fill 96 0 518 96 3 518 minecraft:blackstone
setblock 96 0 522 minecraft:smooth_basalt
fill 96 0 523 96 3 523 minecraft:blackstone
setblock 96 0 527 minecraft:smooth_basalt
setblock 97 0 521 minecraft:smooth_basalt
fill 97 0 522 97 3 522 minecraft:blackstone
setblock 98 0 520 minecraft:smooth_basalt
fill 98 0 521 98 1 521 minecraft:blackstone
fill 98 0 523 98 1 523 minecraft:blackstone
fill 99 0 511 101 0 511 minecraft:blackstone
setblock 101 0 512 minecraft:smooth_basalt
setblock 102 0 511 minecraft:smooth_basalt
fill 102 0 512 104 0 512 minecraft:blackstone
setblock 102 0 551 minecraft:smooth_basalt
fill 103 0 511 106 0 511 minecraft:blackstone
fill 103 0 551 103 3 551 minecraft:blackstone
setblock 107 0 511 minecraft:smooth_basalt
fill 109 0 514 109 1 514 minecraft:gilded_blackstone
setblock 117 0 511 minecraft:smooth_basalt
setblock 117 0 550 minecraft:blackstone
setblock 117 0 551 minecraft:smooth_basalt
fill 118 0 511 118 3 511 minecraft:blackstone
setblock 118 0 550 minecraft:smooth_basalt
fill 118 0 551 118 3 551 minecraft:blackstone
setblock 119 0 549 minecraft:smooth_basalt
fill 119 0 550 119 3 550 minecraft:blackstone
fill 120 0 549 120 3 549 minecraft:blackstone
setblock 122 0 511 minecraft:smooth_basalt
setblock 122 0 551 minecraft:smooth_basalt
setblock 123 0 511 minecraft:blackstone
setblock 123 0 550 minecraft:smooth_basalt
fill 123 0 551 123 3 551 minecraft:blackstone
setblock 124 0 549 minecraft:smooth_basalt
fill 124 0 550 124 3 550 minecraft:blackstone
setblock 127 0 551 minecraft:smooth_basalt
setblock 134 0 539 minecraft:smooth_basalt
setblock 134 0 540 minecraft:blackstone
setblock 134 0 544 minecraft:smooth_basalt
fill 135 0 519 135 3 519 minecraft:blackstone
setblock 135 0 523 minecraft:smooth_basalt
fill 135 0 524 135 3 524 minecraft:blackstone
setblock 135 0 528 minecraft:smooth_basalt
setblock 135 0 538 minecraft:smooth_basalt
fill 135 0 539 135 3 539 minecraft:blackstone
setblock 135 0 543 minecraft:smooth_basalt
fill 135 0 544 135 3 544 minecraft:blackstone
setblock 95 1 517 minecraft:smooth_basalt
fill 95 1 518 95 4 518 minecraft:blackstone
setblock 95 1 522 minecraft:smooth_basalt
fill 95 1 523 95 4 523 minecraft:blackstone
setblock 95 1 527 minecraft:smooth_basalt
fill 95 1 528 96 3 528 minecraft:blackstone
setblock 95 1 541 minecraft:blackstone
setblock 95 1 542 minecraft:smooth_basalt
fill 95 1 543 95 4 543 minecraft:blackstone
fill 95 1 545 95 2 545 minecraft:blackstone
setblock 96 1 517 minecraft:blackstone
setblock 96 1 521 minecraft:smooth_basalt
fill 96 1 522 96 4 522 minecraft:blackstone
setblock 96 1 526 minecraft:smooth_basalt
fill 96 1 527 96 4 527 minecraft:blackstone
setblock 97 1 520 minecraft:smooth_basalt
fill 97 1 521 97 4 521 minecraft:blackstone
setblock 97 1 525 minecraft:smooth_basalt
fill 97 1 526 97 4 526 minecraft:blackstone
fill 99 1 511 100 1 511 minecraft:blackstone
setblock 101 1 511 minecraft:smooth_basalt
setblock 101 1 551 minecraft:smooth_basalt
fill 102 1 511 105 1 511 minecraft:blackstone
fill 102 1 551 102 4 551 minecraft:blackstone
setblock 106 1 511 minecraft:smooth_basalt
setblock 116 1 551 minecraft:smooth_basalt
setblock 117 1 511 minecraft:blackstone
setblock 117 1 550 minecraft:smooth_basalt
fill 117 1 551 117 4 551 minecraft:blackstone
fill 118 1 550 118 4 550 minecraft:blackstone
fill 119 1 549 119 4 549 minecraft:blackstone
setblock 121 1 511 minecraft:smooth_basalt
setblock 121 1 551 minecraft:smooth_basalt
setblock 122 1 511 minecraft:blackstone
setblock 122 1 550 minecraft:smooth_basalt
fill 122 1 551 122 4 551 minecraft:blackstone
setblock 123 1 549 minecraft:smooth_basalt
fill 123 1 550 123 4 550 minecraft:blackstone
setblock 126 1 551 minecraft:smooth_basalt
setblock 134 1 543 minecraft:smooth_basalt
setblock 135 1 522 minecraft:smooth_basalt
fill 135 1 523 135 4 523 minecraft:blackstone
setblock 135 1 527 minecraft:smooth_basalt
fill 135 1 528 135 3 529 minecraft:blackstone
setblock 135 1 537 minecraft:smooth_basalt
fill 135 1 538 135 4 538 minecraft:blackstone
setblock 135 1 542 minecraft:smooth_basalt
fill 135 1 543 135 4 543 minecraft:blackstone
setblock 135 1 546 minecraft:blackstone
setblock 135 1 547 minecraft:smooth_basalt
setblock 95 2 516 minecraft:smooth_basalt
fill 95 2 517 95 5 517 minecraft:blackstone
setblock 95 2 521 minecraft:smooth_basalt
fill 95 2 522 95 5 522 minecraft:blackstone
setblock 95 2 526 minecraft:smooth_basalt
fill 95 2 527 95 5 527 minecraft:blackstone
setblock 95 2 541 minecraft:smooth_basalt
fill 95 2 542 95 5 542 minecraft:blackstone
setblock 96 2 520 minecraft:smooth_basalt
fill 96 2 521 96 5 521 minecraft:blackstone
setblock 96 2 525 minecraft:smooth_basalt
fill 96 2 526 96 5 526 minecraft:blackstone
setblock 97 2 519 minecraft:smooth_basalt
fill 97 2 520 97 5 520 minecraft:blackstone
setblock 97 2 524 minecraft:smooth_basalt
fill 97 2 525 97 5 525 minecraft:blackstone
fill 98 2 511 99 2 511 minecraft:blackstone
setblock 98 2 523 minecraft:smooth_basalt
setblock 100 2 511 minecraft:smooth_basalt
setblock 100 2 551 minecraft:smooth_basalt
fill 101 2 511 104 2 511 minecraft:blackstone
fill 101 2 551 101 5 551 minecraft:blackstone
setblock 105 2 511 minecraft:smooth_basalt
setblock 114 2 551 minecraft:blackstone
setblock 115 2 551 minecraft:smooth_basalt
setblock 116 2 550 minecraft:smooth_basalt
fill 116 2 551 116 5 551 minecraft:blackstone
fill 117 2 550 117 5 550 minecraft:blackstone
fill 118 2 549 118 5 549 minecraft:blackstone
setblock 120 2 511 minecraft:smooth_basalt
setblock 120 2 551 minecraft:smooth_basalt
setblock 121 2 511 minecraft:blackstone
setblock 121 2 550 minecraft:smooth_basalt
fill 121 2 551 121 5 551 minecraft:blackstone
setblock 122 2 549 minecraft:smooth_basalt
fill 122 2 550 122 5 550 minecraft:blackstone
fill 123 2 549 123 5 549 minecraft:blackstone
setblock 125 2 551 minecraft:smooth_basalt
setblock 135 2 521 minecraft:smooth_basalt
fill 135 2 522 135 5 522 minecraft:blackstone
setblock 135 2 526 minecraft:smooth_basalt
fill 135 2 527 135 5 527 minecraft:blackstone
setblock 135 2 530 minecraft:blackstone
setblock 135 2 531 minecraft:smooth_basalt
setblock 135 2 536 minecraft:smooth_basalt
fill 135 2 537 135 5 537 minecraft:blackstone
setblock 135 2 541 minecraft:smooth_basalt
fill 135 2 542 135 5 542 minecraft:blackstone
setblock 135 2 546 minecraft:smooth_basalt
fill 135 2 547 135 5 547 minecraft:blackstone
fill 95 3 516 95 6 516 minecraft:blackstone
setblock 95 3 520 minecraft:smooth_basalt
fill 95 3 521 95 6 521 minecraft:blackstone
setblock 95 3 525 minecraft:smooth_basalt
fill 95 3 526 95 6 526 minecraft:blackstone
setblock 95 3 530 minecraft:smooth_basalt
fill 95 3 531 95 6 531 minecraft:blackstone
setblock 95 3 545 minecraft:smooth_basalt
fill 95 3 546 95 6 546 minecraft:blackstone
setblock 96 3 519 minecraft:smooth_basalt
fill 96 3 520 96 6 520 minecraft:blackstone
setblock 96 3 524 minecraft:smooth_basalt
fill 96 3 525 96 6 525 minecraft:blackstone
setblock 96 3 529 minecraft:smooth_basalt
fill 97 3 519 97 6 519 minecraft:blackstone
setblock 97 3 523 minecraft:smooth_basalt
fill 97 3 524 98 5 524 minecraft:blackstone
setblock 97 3 527 minecraft:blackstone
setblock 98 3 511 minecraft:blackstone
setblock 98 3 522 minecraft:smooth_basalt
fill 98 3 523 98 6 523 minecraft:blackstone
setblock 98 3 551 minecraft:blackstone
setblock 99 3 511 minecraft:smooth_basalt
setblock 99 3 551 minecraft:smooth_basalt
fill 100 3 511 103 3 511 minecraft:blackstone
fill 100 3 551 100 6 551 minecraft:blackstone
setblock 104 3 511 minecraft:smooth_basalt
setblock 104 3 551 minecraft:smooth_basalt
fill 105 3 511 105 6 511 minecraft:blackstone
setblock 113 3 551 minecraft:blackstone
setblock 114 3 551 minecraft:smooth_basalt
setblock 115 3 550 minecraft:smooth_basalt
fill 115 3 551 115 6 551 minecraft:blackstone
fill 116 3 550 116 6 550 minecraft:blackstone
fill 117 3 511 117 4 511 minecraft:blackstone
fill 117 3 549 117 6 549 minecraft:blackstone
setblock 119 3 511 minecraft:smooth_basalt
setblock 119 3 551 minecraft:smooth_basalt
fill 120 3 511 120 6 511 minecraft:blackstone
setblock 120 3 550 minecraft:smooth_basalt
fill 120 3 551 120 6 551 minecraft:blackstone
setblock 121 3 549 minecraft:smooth_basalt
fill 121 3 550 121 6 550 minecraft:blackstone
fill 122 3 549 122 6 549 minecraft:blackstone
setblock 124 3 551 minecraft:smooth_basalt
fill 125 3 551 125 6 551 minecraft:blackstone
fill 134 3 524 134 3 525 minecraft:blackstone
setblock 134 3 526 minecraft:smooth_basalt
setblock 135 3 520 minecraft:smooth_basalt
fill 135 3 521 135 6 521 minecraft:blackstone
setblock 135 3 525 minecraft:smooth_basalt
fill 135 3 526 135 6 526 minecraft:blackstone
setblock 135 3 530 minecraft:smooth_basalt
fill 135 3 531 135 4 533 minecraft:blackstone
setblock 135 3 540 minecraft:smooth_basalt
fill 135 3 541 135 6 541 minecraft:blackstone
setblock 135 3 545 minecraft:smooth_basalt
fill 135 3 546 135 6 546 minecraft:blackstone
fill 135 3 548 135 4 548 minecraft:blackstone
setblock 95 4 519 minecraft:smooth_basalt
fill 95 4 520 95 7 520 minecraft:blackstone
setblock 95 4 524 minecraft:smooth_basalt
fill 95 4 525 95 7 525 minecraft:blackstone
setblock 95 4 528 minecraft:blackstone
setblock 95 4 529 minecraft:smooth_basalt
fill 95 4 530 96 6 530 minecraft:blackstone
fill 95 4 532 95 5 532 minecraft:blackstone
setblock 95 4 544 minecraft:smooth_basalt
fill 95 4 545 95 7 545 minecraft:blackstone
fill 95 4 547 95 4 548 minecraft:blackstone
setblock 96 4 517 minecraft:blackstone
setblock 96 4 518 minecraft:smooth_basalt
fill 96 4 519 96 7 519 minecraft:blackstone
setblock 96 4 523 minecraft:smooth_basalt
fill 96 4 524 96 7 524 minecraft:blackstone
setblock 96 4 528 minecraft:smooth_basalt
fill 96 4 529 96 7 529 minecraft:blackstone
setblock 97 4 511 minecraft:blackstone
setblock 97 4 522 minecraft:smooth_basalt
fill 97 4 523 97 7 523 minecraft:blackstone
setblock 97 4 527 minecraft:smooth_basalt
fill 97 4 528 97 7 528 minecraft:blackstone
setblock 97 4 551 minecraft:blackstone
setblock 98 4 511 minecraft:smooth_basalt
fill 98 4 522 98 7 522 minecraft:blackstone
setblock 98 4 525 minecraft:blackstone
setblock 98 4 551 minecraft:smooth_basalt
fill 99 4 511 102 4 511 minecraft:blackstone
fill 99 4 551 99 7 551 minecraft:blackstone
setblock 103 4 511 minecraft:smooth_basalt
setblock 103 4 551 minecraft:smooth_basalt
fill 104 4 511 104 7 511 minecraft:blackstone
fill 104 4 551 105 6 551 minecraft:blackstone
fill 111 4 551 112 4 551 minecraft:blackstone
setblock 113 4 551 minecraft:smooth_basalt
setblock 114 4 550 minecraft:smooth_basalt
fill 114 4 551 114 7 551 minecraft:blackstone
fill 115 4 511 116 5 511 minecraft:blackstone
fill 115 4 550 115 7 550 minecraft:blackstone
fill 116 4 549 116 7 549 minecraft:blackstone
setblock 118 4 511 minecraft:smooth_basalt
fill 118 4 548 120 4 548 minecraft:blackstone
setblock 118 4 551 minecraft:smooth_basalt
fill 119 4 511 119 7 511 minecraft:blackstone
setblock 119 4 550 minecraft:smooth_basalt
fill 119 4 551 119 7 551 minecraft:blackstone
setblock 120 4 549 minecraft:smooth_basalt
fill 120 4 550 120 7 550 minecraft:blackstone
setblock 121 4 548 minecraft:smooth_basalt
fill 121 4 549 121 7 549 minecraft:blackstone
setblock 123 4 551 minecraft:smooth_basalt
setblock 124 4 550 minecraft:smooth_basalt
fill 124 4 551 124 7 551 minecraft:blackstone
fill 134 4 523 134 4 524 minecraft:blackstone
setblock 134 4 525 minecraft:smooth_basalt
fill 134 4 526 134 4 529 minecraft:blackstone
setblock 135 4 519 minecraft:smooth_basalt
fill 135 4 520 135 7 520 minecraft:blackstone
setblock 135 4 524 minecraft:smooth_basalt
fill 135 4 525 135 7 525 minecraft:blackstone
setblock 135 4 528 minecraft:blackstone
setblock 135 4 529 minecraft:smooth_basalt
fill 135 4 530 135 7 530 minecraft:blackstone
setblock 135 4 534 minecraft:smooth_basalt
fill 135 4 535 135 6 536 minecraft:blackstone
setblock 135 4 539 minecraft:smooth_basalt
fill 135 4 540 135 7 540 minecraft:blackstone
setblock 135 4 544 minecraft:smooth_basalt
fill 135 4 545 135 7 545 minecraft:blackstone
setblock 135 4 549 minecraft:smooth_basalt
fill 95 5 511 95 5 512 minecraft:blackstone
setblock 95 5 513 minecraft:smooth_basalt
fill 95 5 514 95 7 515 minecraft:blackstone
setblock 95 5 518 minecraft:smooth_basalt
fill 95 5 519 95 8 519 minecraft:blackstone
setblock 95 5 523 minecraft:smooth_basalt
fill 95 5 524 95 8 524 minecraft:blackstone
setblock 95 5 528 minecraft:smooth_basalt
fill 95 5 529 95 8 529 minecraft:blackstone
setblock 95 5 533 minecraft:smooth_basalt
setblock 95 5 543 minecraft:smooth_basalt
fill 95 5 544 95 8 544 minecraft:blackstone
setblock 95 5 547 minecraft:blackstone
setblock 95 5 548 minecraft:smooth_basalt
fill 95 5 549 95 6 551 minecraft:blackstone
setblock 96 5 511 minecraft:blackstone
setblock 96 5 517 minecraft:smooth_basalt
fill 96 5 518 96 8 518 minecraft:blackstone
setblock 96 5 522 minecraft:smooth_basalt
fill 96 5 523 96 8 523 minecraft:blackstone
setblock 96 5 527 minecraft:smooth_basalt
fill 96 5 528 96 8 528 minecraft:blackstone
setblock 96 5 531 minecraft:blackstone
setblock 96 5 547 minecraft:smooth_basalt
setblock 96 5 551 minecraft:blackstone
setblock 97 5 511 minecraft:smooth_basalt
setblock 97 5 513 minecraft:light[level=12]
setblock 97 5 521 minecraft:smooth_basalt
fill 97 5 522 97 8 522 minecraft:blackstone
setblock 97 5 526 minecraft:smooth_basalt
fill 97 5 527 97 8 527 minecraft:blackstone
fill 97 5 529 97 6 529 minecraft:blackstone
setblock 97 5 537 minecraft:light[level=12]
setblock 97 5 545 minecraft:light[level=12]
setblock 97 5 551 minecraft:smooth_basalt
fill 98 5 511 100 5 512 minecraft:blackstone
setblock 98 5 525 minecraft:smooth_basalt
fill 98 5 526 98 8 526 minecraft:blackstone
setblock 98 5 550 minecraft:smooth_basalt
fill 98 5 551 98 8 551 minecraft:blackstone
fill 99 5 550 102 5 550 minecraft:blackstone
setblock 101 5 511 minecraft:blackstone
setblock 101 5 512 minecraft:smooth_basalt
setblock 102 5 511 minecraft:smooth_basalt
setblock 102 5 551 minecraft:smooth_basalt
fill 103 5 511 103 8 511 minecraft:blackstone
fill 103 5 551 103 8 551 minecraft:blackstone
setblock 105 5 513 minecraft:light[level=12]
setblock 105 5 521 minecraft:light[level=12]
setblock 105 5 529 minecraft:light[level=12]
setblock 105 5 537 minecraft:light[level=12]
setblock 105 5 545 minecraft:light[level=12]
setblock 106 5 551 minecraft:blackstone
setblock 107 5 551 minecraft:smooth_basalt
fill 108 5 551 111 5 551 minecraft:blackstone
setblock 112 5 550 minecraft:blackstone
setblock 112 5 551 minecraft:smooth_basalt
setblock 113 5 513 minecraft:light[level=12]
setblock 113 5 521 minecraft:light[level=12]
setblock 113 5 529 minecraft:light[level=12]
setblock 113 5 537 minecraft:light[level=12]
setblock 113 5 545 minecraft:light[level=12]
setblock 113 5 550 minecraft:smooth_basalt
fill 113 5 551 113 8 551 minecraft:blackstone
fill 114 5 511 114 7 511 minecraft:blackstone
setblock 114 5 549 minecraft:smooth_basalt
fill 114 5 550 114 8 550 minecraft:blackstone
fill 115 5 549 115 8 549 minecraft:blackstone
setblock 117 5 511 minecraft:smooth_basalt
fill 117 5 548 119 5 548 minecraft:blackstone
setblock 117 5 551 minecraft:smooth_basalt
fill 118 5 511 118 8 511 minecraft:blackstone
setblock 118 5 550 minecraft:smooth_basalt
fill 118 5 551 118 8 551 minecraft:blackstone
setblock 119 5 549 minecraft:smooth_basalt
fill 119 5 550 119 8 550 minecraft:blackstone
setblock 120 5 548 minecraft:smooth_basalt
fill 120 5 549 120 8 549 minecraft:blackstone
setblock 121 5 511 minecraft:blackstone
setblock 121 5 513 minecraft:light[level=12]
setblock 121 5 521 minecraft:light[level=12]
setblock 121 5 529 minecraft:light[level=12]
setblock 121 5 537 minecraft:light[level=12]
setblock 121 5 545 minecraft:light[level=12]
fill 121 5 548 121 8 548 minecraft:blackstone
setblock 122 5 551 minecraft:smooth_basalt
setblock 123 5 550 minecraft:smooth_basalt
fill 123 5 551 123 8 551 minecraft:blackstone
fill 124 5 550 124 8 550 minecraft:blackstone
setblock 126 5 551 minecraft:blackstone
setblock 129 5 513 minecraft:light[level=12]
setblock 129 5 521 minecraft:light[level=12]
setblock 129 5 529 minecraft:light[level=12]
setblock 129 5 537 minecraft:light[level=12]
fill 134 5 522 134 5 523 minecraft:blackstone
setblock 134 5 524 minecraft:smooth_basalt
fill 134 5 525 134 5 528 minecraft:blackstone
setblock 134 5 529 minecraft:smooth_basalt
fill 134 5 530 134 7 531 minecraft:blackstone
setblock 134 5 544 minecraft:smooth_basalt
fill 134 5 545 134 8 545 minecraft:blackstone
setblock 135 5 518 minecraft:smooth_basalt
fill 135 5 519 135 8 519 minecraft:blackstone
setblock 135 5 523 minecraft:smooth_basalt
fill 135 5 524 135 8 524 minecraft:blackstone
setblock 135 5 528 minecraft:smooth_basalt
fill 135 5 529 135 8 529 minecraft:blackstone
fill 135 5 531 135 5 532 minecraft:blackstone
setblock 135 5 533 minecraft:smooth_basalt
fill 135 5 534 135 8 534 minecraft:blackstone
setblock 135 5 538 minecraft:smooth_basalt
fill 135 5 539 135 8 539 minecraft:blackstone
setblock 135 5 543 minecraft:smooth_basalt
fill 135 5 544 135 8 544 minecraft:blackstone
setblock 135 5 548 minecraft:smooth_basalt
fill 135 5 549 135 7 550 minecraft:blackstone
setblock 95 6 511 minecraft:blackstone
setblock 95 6 512 minecraft:smooth_basalt
fill 95 6 513 95 9 513 minecraft:blackstone
setblock 95 6 517 minecraft:smooth_basalt
fill 95 6 518 95 9 518 minecraft:blackstone
setblock 95 6 522 minecraft:smooth_basalt
fill 95 6 523 95 9 523 minecraft:blackstone
setblock 95 6 527 minecraft:smooth_basalt
fill 95 6 528 95 9 528 minecraft:blackstone
setblock 95 6 532 minecraft:smooth_basalt
fill 95 6 533 95 8 534 minecraft:blackstone
setblock 95 6 542 minecraft:smooth_basalt
fill 95 6 543 95 9 543 minecraft:blackstone
setblock 95 6 547 minecraft:smooth_basalt
fill 95 6 548 96 8 548 minecraft:blackstone
setblock 96 6 511 minecraft:smooth_basalt
fill 96 6 512 99 6 512 minecraft:blackstone
setblock 96 6 515 minecraft:blackstone
setblock 96 6 516 minecraft:smooth_basalt
fill 96 6 517 96 9 517 minecraft:blackstone
setblock 96 6 521 minecraft:smooth_basalt
fill 96 6 522 96 9 522 minecraft:blackstone
setblock 96 6 526 minecraft:smooth_basalt
fill 96 6 527 96 9 527 minecraft:blackstone
setblock 96 6 531 minecraft:smooth_basalt
fill 96 6 532 96 9 532 minecraft:blackstone
setblock 96 6 545 minecraft:blackstone
setblock 96 6 546 minecraft:smooth_basalt
fill 96 6 547 96 9 547 minecraft:blackstone
fill 96 6 549 96 6 550 minecraft:blackstone
setblock 96 6 551 minecraft:smooth_basalt
fill 97 6 511 100 6 511 minecraft:blackstone
setblock 97 6 520 minecraft:smooth_basalt
fill 97 6 521 97 9 521 minecraft:blackstone
setblock 97 6 524 minecraft:blackstone
setblock 97 6 525 minecraft:smooth_basalt
fill 97 6 526 97 9 526 minecraft:blackstone
setblock 97 6 530 minecraft:smooth_basalt
setblock 97 6 550 minecraft:smooth_basalt
fill 97 6 551 97 9 551 minecraft:blackstone
setblock 98 6 524 minecraft:smooth_basalt
fill 98 6 525 98 9 525 minecraft:blackstone
fill 98 6 527 98 7 527 minecraft:blackstone
fill 98 6 550 101 6 550 minecraft:blackstone
setblock 100 6 512 minecraft:smooth_basalt
setblock 101 6 511 minecraft:smooth_basalt
fill 101 6 512 102 8 512 minecraft:blackstone
fill 101 6 528 101 28 528 minecraft:smooth_basalt
setblock 101 6 551 minecraft:smooth_basalt
fill 102 6 511 102 9 511 minecraft:blackstone
setblock 102 6 550 minecraft:smooth_basalt
fill 102 6 551 102 9 551 minecraft:blackstone
fill 103 6 550 104 8 550 minecraft:blackstone
setblock 106 6 511 minecraft:smooth_basalt
setblock 106 6 551 minecraft:smooth_basalt
fill 107 6 511 107 9 511 minecraft:blackstone
fill 107 6 551 110 6 551 minecraft:blackstone
fill 110 6 550 111 6 550 minecraft:blackstone
setblock 111 6 511 minecraft:smooth_basalt
setblock 111 6 551 minecraft:smooth_basalt
fill 112 6 511 113 8 511 minecraft:blackstone
setblock 112 6 550 minecraft:smooth_basalt
fill 112 6 551 112 9 551 minecraft:blackstone
fill 113 6 515 113 7 516 minecraft:gilded_blackstone
setblock 113 6 549 minecraft:smooth_basalt
fill 113 6 550 113 9 550 minecraft:blackstone
fill 114 6 549 114 9 549 minecraft:blackstone
setblock 115 6 511 minecraft:blackstone
fill 115 6 548 118 6 548 minecraft:blackstone
setblock 116 6 511 minecraft:smooth_basalt
setblock 116 6 551 minecraft:smooth_basalt
fill 117 6 511 117 9 511 minecraft:blackstone
setblock 117 6 550 minecraft:smooth_basalt
fill 117 6 551 117 9 551 minecraft:blackstone
setblock 118 6 549 minecraft:smooth_basalt
fill 118 6 550 118 9 550 minecraft:blackstone
setblock 119 6 548 minecraft:smooth_basalt
fill 119 6 549 119 9 549 minecraft:blackstone
fill 120 6 548 120 9 548 minecraft:blackstone
setblock 121 6 511 minecraft:smooth_basalt
setblock 121 6 551 minecraft:smooth_basalt
setblock 122 6 550 minecraft:smooth_basalt
fill 122 6 551 122 9 551 minecraft:blackstone
setblock 123 6 549 minecraft:smooth_basalt
fill 123 6 550 123 9 550 minecraft:blackstone
fill 125 6 550 125 7 550 minecraft:blackstone
setblock 126 6 551 minecraft:smooth_basalt
fill 133 6 525 133 6 528 minecraft:blackstone
fill 134 6 521 134 6 522 minecraft:blackstone
setblock 134 6 523 minecraft:smooth_basalt
fill 134 6 524 134 6 527 minecraft:blackstone
setblock 134 6 528 minecraft:smooth_basalt
fill 134 6 529 134 9 529 minecraft:blackstone
setblock 134 6 532 minecraft:blackstone
setblock 134 6 533 minecraft:smooth_basalt
setblock 134 6 543 minecraft:smooth_basalt
fill 134 6 544 134 9 544 minecraft:blackstone
fill 134 6 546 134 6 547 minecraft:blackstone
setblock 134 6 548 minecraft:smooth_basalt
fill 134 6 551 135 6 551 minecraft:blackstone
fill 135 6 518 135 9 518 minecraft:blackstone
setblock 135 6 522 minecraft:smooth_basalt
fill 135 6 523 135 9 523 minecraft:blackstone
setblock 135 6 527 minecraft:smooth_basalt
fill 135 6 528 135 9 528 minecraft:blackstone
setblock 135 6 531 minecraft:blackstone
setblock 135 6 532 minecraft:smooth_basalt
fill 135 6 533 135 9 533 minecraft:blackstone
setblock 135 6 537 minecraft:smooth_basalt
fill 135 6 538 135 9 538 minecraft:blackstone
setblock 135 6 542 minecraft:smooth_basalt
fill 135 6 543 135 9 543 minecraft:blackstone
setblock 135 6 547 minecraft:smooth_basalt
fill 135 6 548 135 9 548 minecraft:blackstone
setblock 95 7 511 minecraft:smooth_basalt
fill 95 7 512 98 7 512 minecraft:blackstone
setblock 95 7 516 minecraft:smooth_basalt
fill 95 7 517 95 10 517 minecraft:blackstone
setblock 95 7 521 minecraft:smooth_basalt
fill 95 7 522 95 10 522 minecraft:blackstone
setblock 95 7 526 minecraft:smooth_basalt
fill 95 7 527 95 10 527 minecraft:blackstone
setblock 95 7 530 minecraft:blackstone
setblock 95 7 531 minecraft:smooth_basalt
fill 95 7 532 95 10 532 minecraft:blackstone
setblock 95 7 535 minecraft:blackstone
setblock 95 7 536 minecraft:smooth_basalt
setblock 95 7 541 minecraft:smooth_basalt
fill 95 7 542 95 10 542 minecraft:blackstone
setblock 95 7 546 minecraft:smooth_basalt
fill 95 7 547 95 10 547 minecraft:blackstone
fill 95 7 549 95 7 550 minecraft:blackstone
setblock 95 7 551 minecraft:smooth_basalt
fill 96 7 511 99 7 511 minecraft:blackstone
fill 96 7 513 96 7 514 minecraft:blackstone
setblock 96 7 515 minecraft:smooth_basalt
fill 96 7 516 96 10 516 minecraft:blackstone
setblock 96 7 520 minecraft:smooth_basalt
fill 96 7 521 96 10 521 minecraft:blackstone
setblock 96 7 525 minecraft:smooth_basalt
fill 96 7 526 96 10 526 minecraft:blackstone
setblock 96 7 530 minecraft:smooth_basalt
fill 96 7 531 97 9 531 minecraft:blackstone
fill 96 7 533 96 8 533 minecraft:blackstone
setblock 96 7 544 minecraft:blackstone
setblock 96 7 545 minecraft:smooth_basalt
fill 96 7 546 96 10 546 minecraft:blackstone
setblock 96 7 549 minecraft:blackstone
setblock 96 7 550 minecraft:smooth_basalt
fill 96 7 551 96 10 551 minecraft:blackstone
setblock 97 7 518 minecraft:blackstone
setblock 97 7 519 minecraft:smooth_basalt
fill 97 7 520 97 10 520 minecraft:blackstone
setblock 97 7 524 minecraft:smooth_basalt
fill 97 7 525 97 10 525 minecraft:blackstone
fill 97 7 529 105 7 529 minecraft:smooth_basalt
fill 97 7 530 97 10 530 minecraft:blackstone
setblock 97 7 549 minecraft:smooth_basalt
fill 97 7 550 100 7 550 minecraft:blackstone
setblock 98 7 523 minecraft:smooth_basalt
fill 98 7 524 98 9 524 minecraft:blackstone
fill 98 7 528 100 7 528 minecraft:smooth_basalt
fill 98 7 530 104 27 530 minecraft:smooth_basalt
fill 98 7 549 100 8 549 minecraft:blackstone
setblock 99 7 512 minecraft:smooth_basalt
fill 99 7 525 103 27 527 minecraft:smooth_basalt
fill 99 7 531 103 27 531 minecraft:smooth_basalt
setblock 100 7 511 minecraft:smooth_basalt
fill 100 7 512 100 10 512 minecraft:blackstone
fill 100 7 524 102 27 524 minecraft:smooth_basalt
fill 100 7 532 102 27 532 minecraft:smooth_basalt
setblock 100 7 551 minecraft:smooth_basalt
fill 101 7 511 101 10 511 minecraft:blackstone
setblock 101 7 550 minecraft:smooth_basalt
fill 101 7 551 101 10 551 minecraft:blackstone
fill 102 7 528 105 27 528 minecraft:smooth_basalt
fill 102 7 550 102 10 550 minecraft:blackstone
setblock 103 7 512 minecraft:blackstone
fill 104 7 526 104 27 527 minecraft:smooth_basalt
setblock 104 7 551 minecraft:blackstone
setblock 105 7 511 minecraft:smooth_basalt
fill 105 7 527 105 27 527 minecraft:smooth_basalt
setblock 105 7 550 minecraft:blackstone
setblock 105 7 551 minecraft:smooth_basalt
fill 106 7 511 106 10 511 minecraft:blackstone
setblock 106 7 550 minecraft:smooth_basalt
fill 106 7 551 109 7 551 minecraft:blackstone
fill 107 7 550 110 7 550 minecraft:blackstone
fill 108 7 511 109 7 511 minecraft:blackstone
setblock 110 7 511 minecraft:smooth_basalt
setblock 110 7 551 minecraft:smooth_basalt
fill 111 7 511 111 10 511 minecraft:blackstone
setblock 111 7 549 minecraft:blackstone
setblock 111 7 550 minecraft:smooth_basalt
fill 111 7 551 111 10 551 minecraft:blackstone
setblock 112 7 549 minecraft:smooth_basalt
fill 112 7 550 112 10 550 minecraft:blackstone
fill 113 7 549 113 10 549 minecraft:blackstone
fill 114 7 548 117 7 548 minecraft:blackstone
setblock 115 7 511 minecraft:smooth_basalt
setblock 115 7 551 minecraft:smooth_basalt
fill 116 7 511 116 9 512 minecraft:blackstone
setblock 116 7 550 minecraft:smooth_basalt
fill 116 7 551 116 10 551 minecraft:blackstone
fill 117 7 512 117 8 512 minecraft:blackstone
setblock 117 7 549 minecraft:smooth_basalt
fill 117 7 550 117 10 550 minecraft:blackstone
setblock 118 7 548 minecraft:smooth_basalt
fill 118 7 549 118 10 549 minecraft:blackstone
fill 119 7 548 119 10 548 minecraft:blackstone
setblock 120 7 511 minecraft:smooth_basalt
setblock 120 7 551 minecraft:smooth_basalt
fill 121 7 511 122 9 511 minecraft:blackstone
setblock 121 7 550 minecraft:smooth_basalt
fill 121 7 551 121 10 551 minecraft:blackstone
setblock 122 7 549 minecraft:smooth_basalt
fill 122 7 550 122 10 550 minecraft:blackstone
fill 123 7 549 123 9 549 minecraft:blackstone
setblock 125 7 551 minecraft:smooth_basalt
fill 126 7 551 127 9 551 minecraft:blackstone
fill 131 7 551 134 7 551 minecraft:blackstone
fill 133 7 524 133 7 527 minecraft:blackstone
setblock 133 7 528 minecraft:smooth_basalt
fill 133 7 529 133 9 530 minecraft:blackstone
setblock 134 7 521 minecraft:blackstone
setblock 134 7 522 minecraft:smooth_basalt
fill 134 7 523 134 7 526 minecraft:blackstone
setblock 134 7 527 minecraft:smooth_basalt
fill 134 7 528 134 10 528 minecraft:blackstone
setblock 134 7 532 minecraft:smooth_basalt
fill 134 7 533 134 8 535 minecraft:blackstone
fill 134 7 543 134 10 543 minecraft:blackstone
setblock 134 7 546 minecraft:blackstone
setblock 134 7 547 minecraft:smooth_basalt
fill 134 7 548 134 8 550 minecraft:blackstone
setblock 135 7 511 minecraft:smooth_basalt
fill 135 7 512 135 10 512 minecraft:blackstone
setblock 135 7 516 minecraft:smooth_basalt
fill 135 7 517 135 10 517 minecraft:blackstone
setblock 135 7 521 minecraft:smooth_basalt
fill 135 7 522 135 10 522 minecraft:blackstone
setblock 135 7 526 minecraft:smooth_basalt
fill 135 7 527 135 10 527 minecraft:blackstone
setblock 135 7 531 minecraft:smooth_basalt
fill 135 7 532 135 10 532 minecraft:blackstone
setblock 135 7 535 minecraft:blackstone
setblock 135 7 536 minecraft:smooth_basalt
fill 135 7 537 135 10 537 minecraft:blackstone
setblock 135 7 541 minecraft:smooth_basalt
fill 135 7 542 135 10 542 minecraft:blackstone
setblock 135 7 546 minecraft:smooth_basalt
fill 135 7 547 135 10 547 minecraft:blackstone
setblock 135 7 551 minecraft:smooth_basalt
fill 95 8 511 97 8 512 minecraft:blackstone
setblock 95 8 514 minecraft:blackstone
setblock 95 8 515 minecraft:smooth_basalt
fill 95 8 516 95 11 516 minecraft:blackstone
setblock 95 8 520 minecraft:smooth_basalt
fill 95 8 521 95 11 521 minecraft:blackstone
setblock 95 8 525 minecraft:smooth_basalt
fill 95 8 526 95 11 526 minecraft:blackstone
setblock 95 8 530 minecraft:smooth_basalt
fill 95 8 531 95 11 531 minecraft:blackstone
setblock 95 8 535 minecraft:smooth_basalt
fill 95 8 536 95 10 537 minecraft:blackstone
setblock 95 8 540 minecraft:smooth_basalt
fill 95 8 541 95 11 541 minecraft:blackstone
setblock 95 8 545 minecraft:smooth_basalt
fill 95 8 546 95 11 546 minecraft:blackstone
setblock 95 8 549 minecraft:blackstone
setblock 95 8 550 minecraft:smooth_basalt
fill 95 8 551 95 11 551 minecraft:blackstone
setblock 96 8 513 minecraft:blackstone
setblock 96 8 514 minecraft:smooth_basalt
fill 96 8 515 96 11 515 minecraft:blackstone
setblock 96 8 519 minecraft:smooth_basalt
fill 96 8 520 96 11 520 minecraft:blackstone
setblock 96 8 524 minecraft:smooth_basalt
fill 96 8 525 96 11 525 minecraft:blackstone
setblock 96 8 529 minecraft:smooth_basalt
fill 96 8 530 96 11 530 minecraft:blackstone
setblock 96 8 534 minecraft:smooth_basalt
setblock 96 8 544 minecraft:smooth_basalt
fill 96 8 545 96 11 545 minecraft:blackstone
setblock 96 8 549 minecraft:smooth_basalt
fill 96 8 550 99 8 550 minecraft:blackstone
setblock 97 8 513 minecraft:smooth_basalt
fill 97 8 514 97 11 514 minecraft:blackstone
setblock 97 8 517 minecraft:blackstone
setblock 97 8 518 minecraft:smooth_basalt
fill 97 8 519 97 11 519 minecraft:blackstone
setblock 97 8 523 minecraft:smooth_basalt
fill 97 8 524 97 11 524 minecraft:blackstone
setblock 97 8 528 minecraft:smooth_basalt
fill 97 8 529 97 11 529 minecraft:blackstone
fill 97 8 532 99 9 532 minecraft:smooth_basalt
setblock 97 8 547 minecraft:blackstone
setblock 97 8 548 minecraft:smooth_basalt
fill 97 8 549 97 11 549 minecraft:blackstone
setblock 98 8 511 minecraft:blackstone
setblock 98 8 512 minecraft:smooth_basalt
fill 98 8 513 99 10 513 minecraft:blackstone
fill 98 8 522 98 25 522 minecraft:smooth_basalt
fill 98 8 523 98 9 523 minecraft:blackstone
setblock 98 8 527 minecraft:smooth_basalt
fill 98 8 528 98 10 528 minecraft:blackstone
fill 98 8 529 106 8 529 minecraft:smooth_basalt
fill 98 8 531 98 26 531 minecraft:smooth_basalt
setblock 99 8 511 minecraft:smooth_basalt
fill 99 8 512 99 11 512 minecraft:blackstone
fill 99 8 523 99 26 524 minecraft:smooth_basalt
fill 99 8 528 100 27 528 minecraft:smooth_basalt
fill 99 8 533 101 26 533 minecraft:smooth_basalt
setblock 99 8 551 minecraft:smooth_basalt
fill 100 8 511 100 11 511 minecraft:blackstone
fill 100 8 523 103 26 523 minecraft:smooth_basalt
setblock 100 8 550 minecraft:smooth_basalt
fill 100 8 551 100 11 551 minecraft:blackstone
setblock 101 8 549 minecraft:smooth_basalt
fill 101 8 550 101 11 550 minecraft:blackstone
setblock 103 8 512 minecraft:smooth_basalt
fill 103 8 524 105 26 524 minecraft:smooth_basalt
setblock 104 8 511 minecraft:smooth_basalt
fill 104 8 512 104 11 512 minecraft:blackstone
fill 104 8 525 105 26 525 minecraft:smooth_basalt
fill 104 8 531 105 26 531 minecraft:smooth_basalt
setblock 104 8 551 minecraft:smooth_basalt
fill 105 8 511 105 11 511 minecraft:blackstone
fill 105 8 526 106 26 526 minecraft:smooth_basalt
fill 105 8 530 106 26 530 minecraft:smooth_basalt
setblock 105 8 550 minecraft:smooth_basalt
fill 105 8 551 108 8 551 minecraft:blackstone
fill 106 8 527 106 26 528 minecraft:smooth_basalt
fill 106 8 550 109 8 550 minecraft:blackstone
setblock 108 8 511 minecraft:blackstone
setblock 109 8 511 minecraft:smooth_basalt
setblock 109 8 551 minecraft:smooth_basalt
fill 110 8 511 110 11 511 minecraft:blackstone
setblock 110 8 549 minecraft:blackstone
setblock 110 8 550 minecraft:smooth_basalt
fill 110 8 551 110 11 551 minecraft:blackstone
setblock 111 8 549 minecraft:smooth_basalt
fill 111 8 550 111 11 550 minecraft:blackstone
fill 112 8 549 112 11 549 minecraft:blackstone
setblock 113 8 512 minecraft:smooth_basalt
fill 113 8 548 116 8 548 minecraft:blackstone
setblock 114 8 511 minecraft:smooth_basalt
fill 114 8 512 115 10 512 minecraft:blackstone
setblock 114 8 551 minecraft:smooth_basalt
fill 115 8 511 115 11 511 minecraft:blackstone
setblock 115 8 550 minecraft:smooth_basalt
fill 115 8 551 115 11 551 minecraft:blackstone
setblock 116 8 549 minecraft:smooth_basalt
fill 116 8 550 116 11 550 minecraft:blackstone
setblock 117 8 547 minecraft:blackstone
setblock 117 8 548 minecraft:smooth_basalt
fill 117 8 549 117 11 549 minecraft:blackstone
setblock 118 8 512 minecraft:smooth_basalt
setblock 118 8 547 minecraft:smooth_basalt
fill 118 8 548 118 11 548 minecraft:blackstone
setblock 119 8 511 minecraft:smooth_basalt
setblock 119 8 551 minecraft:smooth_basalt
fill 120 8 511 120 11 511 minecraft:blackstone
setblock 120 8 550 minecraft:smooth_basalt
fill 120 8 551 120 11 551 minecraft:blackstone
setblock 121 8 549 minecraft:smooth_basalt
fill 121 8 550 121 11 550 minecraft:blackstone
fill 122 8 549 122 11 549 minecraft:blackstone
setblock 124 8 551 minecraft:smooth_basalt
setblock 125 8 550 minecraft:smooth_basalt
fill 125 8 551 125 11 551 minecraft:blackstone
setblock 128 8 551 minecraft:blackstone
setblock 129 8 551 minecraft:smooth_basalt
fill 130 8 551 133 8 551 minecraft:blackstone
setblock 133 8 511 minecraft:blackstone
fill 133 8 523 133 8 526 minecraft:blackstone
setblock 133 8 527 minecraft:smooth_basalt
fill 133 8 528 133 11 528 minecraft:blackstone
setblock 133 8 531 minecraft:blackstone
setblock 133 8 532 minecraft:smooth_basalt
fill 133 8 550 133 9 550 minecraft:blackstone
setblock 134 8 511 minecraft:smooth_basalt
setblock 134 8 520 minecraft:blackstone
setblock 134 8 521 minecraft:smooth_basalt
fill 134 8 522 134 8 525 minecraft:blackstone
setblock 134 8 526 minecraft:smooth_basalt
fill 134 8 527 134 11 527 minecraft:blackstone
setblock 134 8 530 minecraft:blackstone
setblock 134 8 531 minecraft:smooth_basalt
fill 134 8 532 134 11 532 minecraft:blackstone
setblock 134 8 536 minecraft:smooth_basalt
setblock 134 8 546 minecraft:smooth_basalt
fill 134 8 547 134 11 547 minecraft:blackstone
setblock 134 8 551 minecraft:smooth_basalt
fill 135 8 511 135 11 511 minecraft:blackstone
fill 135 8 513 135 8 514 minecraft:blackstone
setblock 135 8 515 minecraft:smooth_basalt
fill 135 8 516 135 11 516 minecraft:blackstone
setblock 135 8 520 minecraft:smooth_basalt
fill 135 8 521 135 11 521 minecraft:blackstone
setblock 135 8 525 minecraft:smooth_basalt
fill 135 8 526 135 11 526 minecraft:blackstone
setblock 135 8 530 minecraft:smooth_basalt
fill 135 8 531 135 11 531 minecraft:blackstone
setblock 135 8 535 minecraft:smooth_basalt
fill 135 8 536 135 11 536 minecraft:blackstone
setblock 135 8 540 minecraft:smooth_basalt
fill 135 8 541 135 11 541 minecraft:blackstone
setblock 135 8 545 minecraft:smooth_basalt
fill 135 8 546 135 11 546 minecraft:blackstone
setblock 135 8 549 minecraft:blackstone
setblock 135 8 550 minecraft:smooth_basalt
fill 135 8 551 135 11 551 minecraft:blackstone
fill 95 9 511 96 9 512 minecraft:blackstone
setblock 95 9 514 minecraft:smooth_basalt
fill 95 9 515 95 12 515 minecraft:blackstone
setblock 95 9 519 minecraft:smooth_basalt
fill 95 9 520 95 12 520 minecraft:blackstone
setblock 95 9 524 minecraft:smooth_basalt
fill 95 9 525 95 12 525 minecraft:blackstone
setblock 95 9 529 minecraft:smooth_basalt
fill 95 9 530 95 12 530 minecraft:blackstone
setblock 95 9 533 minecraft:blackstone
setblock 95 9 534 minecraft:smooth_basalt
fill 95 9 535 96 11 535 minecraft:blackstone
setblock 95 9 538 minecraft:blackstone
setblock 95 9 539 minecraft:smooth_basalt
fill 95 9 540 95 11 540 minecraft:blackstone
setblock 95 9 544 minecraft:smooth_basalt
fill 95 9 545 95 12 545 minecraft:blackstone
setblock 95 9 548 minecraft:blackstone
setblock 95 9 549 minecraft:smooth_basalt
fill 95 9 550 98 9 550 minecraft:blackstone
setblock 96 9 513 minecraft:smooth_basalt
fill 96 9 514 96 12 514 minecraft:blackstone
setblock 96 9 518 minecraft:smooth_basalt
fill 96 9 519 96 12 519 minecraft:blackstone
setblock 96 9 523 minecraft:smooth_basalt
fill 96 9 524 96 12 524 minecraft:blackstone
setblock 96 9 528 minecraft:smooth_basalt
fill 96 9 529 96 12 529 minecraft:blackstone
fill 96 9 533 98 9 533 minecraft:smooth_basalt
fill 96 9 534 96 12 534 minecraft:blackstone
setblock 96 9 544 minecraft:blackstone
setblock 96 9 548 minecraft:smooth_basalt
fill 96 9 549 96 12 549 minecraft:blackstone
setblock 97 9 511 minecraft:blackstone
setblock 97 9 512 minecraft:smooth_basalt
fill 97 9 513 97 12 513 minecraft:blackstone
fill 97 9 515 97 9 516 minecraft:blackstone
setblock 97 9 517 minecraft:smooth_basalt
fill 97 9 518 97 11 518 minecraft:blackstone
setblock 97 9 522 minecraft:smooth_basalt
fill 97 9 523 97 12 523 minecraft:blackstone
setblock 97 9 527 minecraft:smooth_basalt
fill 97 9 528 97 12 528 minecraft:blackstone
setblock 97 9 547 minecraft:smooth_basalt
fill 97 9 548 97 11 548 minecraft:blackstone
setblock 98 9 511 minecraft:smooth_basalt
fill 98 9 512 98 12 512 minecraft:blackstone
setblock 98 9 526 minecraft:smooth_basalt
fill 98 9 527 98 10 527 minecraft:blackstone
setblock 98 9 529 minecraft:blackstone
fill 98 9 534 101 25 534 minecraft:smooth_basalt
fill 98 9 549 99 9 549 minecraft:blackstone
setblock 98 9 551 minecraft:smooth_basalt
fill 99 9 511 99 12 511 minecraft:blackstone
fill 99 9 522 104 25 522 minecraft:smooth_basalt
fill 99 9 529 107 25 529 minecraft:smooth_basalt
setblock 99 9 550 minecraft:smooth_basalt
fill 99 9 551 99 12 551 minecraft:blackstone
setblock 100 9 513 minecraft:blackstone
setblock 100 9 549 minecraft:smooth_basalt
fill 100 9 550 100 12 550 minecraft:blackstone
setblock 101 9 512 minecraft:blackstone
fill 101 9 549 102 9 549 minecraft:blackstone
setblock 102 9 512 minecraft:smooth_basalt
setblock 103 9 511 minecraft:smooth_basalt
fill 103 9 512 103 12 512 minecraft:blackstone
setblock 103 9 550 minecraft:blackstone
setblock 103 9 551 minecraft:smooth_basalt
fill 104 9 511 104 12 511 minecraft:blackstone
fill 104 9 523 105 25 523 minecraft:smooth_basalt
setblock 104 9 550 minecraft:smooth_basalt
fill 104 9 551 107 9 551 minecraft:blackstone
fill 105 9 550 108 9 550 minecraft:blackstone
fill 106 9 524 106 25 525 minecraft:smooth_basalt
fill 106 9 531 107 25 531 minecraft:smooth_basalt
fill 107 9 525 107 25 528 minecraft:smooth_basalt
fill 107 9 530 107 25 530 minecraft:smooth_basalt
setblock 108 9 511 minecraft:smooth_basalt
setblock 108 9 551 minecraft:smooth_basalt
fill 109 9 511 109 12 511 minecraft:blackstone
setblock 109 9 549 minecraft:blackstone
setblock 109 9 550 minecraft:smooth_basalt
fill 109 9 551 109 12 551 minecraft:blackstone
setblock 110 9 549 minecraft:smooth_basalt
fill 110 9 550 110 12 550 minecraft:blackstone
setblock 111 9 512 minecraft:blackstone
fill 111 9 549 111 12 549 minecraft:blackstone
setblock 112 9 511 minecraft:blackstone
setblock 112 9 512 minecraft:smooth_basalt
fill 112 9 548 115 9 548 minecraft:blackstone
setblock 113 9 511 minecraft:smooth_basalt
fill 113 9 512 113 12 512 minecraft:blackstone
setblock 113 9 551 minecraft:smooth_basalt
fill 114 9 511 114 12 511 minecraft:blackstone
setblock 114 9 550 minecraft:smooth_basalt
fill 114 9 551 114 12 551 minecraft:blackstone
setblock 115 9 549 minecraft:smooth_basalt
fill 115 9 550 115 12 550 minecraft:blackstone
setblock 116 9 547 minecraft:blackstone
setblock 116 9 548 minecraft:smooth_basalt
fill 116 9 549 116 12 549 minecraft:blackstone
setblock 117 9 512 minecraft:smooth_basalt
setblock 117 9 547 minecraft:smooth_basalt
fill 117 9 548 117 12 548 minecraft:blackstone
setblock 118 9 511 minecraft:smooth_basalt
fill 118 9 512 119 11 512 minecraft:blackstone
setblock 118 9 547 minecraft:blackstone
setblock 118 9 551 minecraft:smooth_basalt
fill 119 9 511 119 12 511 minecraft:blackstone
setblock 119 9 550 minecraft:smooth_basalt
fill 119 9 551 119 12 551 minecraft:blackstone
setblock 120 9 549 minecraft:smooth_basalt
fill 120 9 550 120 12 550 minecraft:blackstone
setblock 121 9 548 minecraft:smooth_basalt
fill 121 9 549 121 11 549 minecraft:blackstone
setblock 123 9 551 minecraft:smooth_basalt
setblock 124 9 550 minecraft:smooth_basalt
fill 124 9 551 124 12 551 minecraft:blackstone
fill 125 9 550 125 10 550 minecraft:blackstone
setblock 128 9 551 minecraft:smooth_basalt
fill 129 9 551 132 9 551 minecraft:blackstone
fill 131 9 550 132 10 550 minecraft:blackstone
setblock 132 9 511 minecraft:blackstone
setblock 132 9 527 minecraft:smooth_basalt
fill 132 9 528 132 10 530 minecraft:blackstone
setblock 133 9 511 minecraft:smooth_basalt
fill 133 9 523 133 9 525 minecraft:blackstone
setblock 133 9 526 minecraft:smooth_basalt
fill 133 9 527 133 12 527 minecraft:blackstone
setblock 133 9 531 minecraft:smooth_basalt
fill 133 9 532 133 10 534 minecraft:blackstone
setblock 133 9 551 minecraft:smooth_basalt
fill 134 9 511 134 12 511 minecraft:blackstone
setblock 134 9 519 minecraft:blackstone
setblock 134 9 520 minecraft:smooth_basalt
fill 134 9 521 134 9 524 minecraft:blackstone
setblock 134 9 525 minecraft:smooth_basalt
fill 134 9 526 134 12 526 minecraft:blackstone
setblock 134 9 530 minecraft:smooth_basalt
fill 134 9 531 134 12 531 minecraft:blackstone
fill 134 9 533 134 9 534 minecraft:blackstone
setblock 134 9 535 minecraft:smooth_basalt
fill 134 9 536 134 10 538 minecraft:blackstone
setblock 134 9 542 minecraft:blackstone
setblock 134 9 545 minecraft:smooth_basalt
fill 134 9 546 134 12 546 minecraft:blackstone
fill 134 9 548 134 9 549 minecraft:blackstone
setblock 134 9 550 minecraft:smooth_basalt
fill 134 9 551 134 12 551 minecraft:blackstone
setblock 135 9 513 minecraft:blackstone
setblock 135 9 514 minecraft:smooth_basalt
fill 135 9 515 135 12 515 minecraft:blackstone
setblock 135 9 519 minecraft:smooth_basalt
fill 135 9 520 135 12 520 minecraft:blackstone
setblock 135 9 524 minecraft:smooth_basalt
fill 135 9 525 135 12 525 minecraft:blackstone
setblock 135 9 529 minecraft:smooth_basalt
fill 135 9 530 135 12 530 minecraft:blackstone
setblock 135 9 534 minecraft:smooth_basalt
fill 135 9 535 135 12 535 minecraft:blackstone
setblock 135 9 539 minecraft:smooth_basalt
fill 135 9 540 135 12 540 minecraft:blackstone
setblock 135 9 544 minecraft:smooth_basalt
fill 135 9 545 135 12 545 minecraft:blackstone
setblock 135 9 549 minecraft:smooth_basalt
fill 135 9 550 135 12 550 minecraft:blackstone
fill 95 10 511 95 10 512 minecraft:blackstone
setblock 95 10 513 minecraft:smooth_basalt
fill 95 10 514 95 13 514 minecraft:blackstone
setblock 95 10 518 minecraft:smooth_basalt
fill 95 10 519 95 13 519 minecraft:blackstone
setblock 95 10 523 minecraft:smooth_basalt
fill 95 10 524 95 13 524 minecraft:blackstone
setblock 95 10 528 minecraft:smooth_basalt
fill 95 10 529 95 13 529 minecraft:blackstone
setblock 95 10 533 minecraft:smooth_basalt
fill 95 10 534 95 13 534 minecraft:blackstone
setblock 95 10 538 minecraft:smooth_basalt
fill 95 10 539 95 12 539 minecraft:blackstone
setblock 95 10 543 minecraft:smooth_basalt
fill 95 10 544 95 13 544 minecraft:blackstone
setblock 95 10 548 minecraft:smooth_basalt
fill 95 10 549 95 12 550 minecraft:blackstone
setblock 96 10 511 minecraft:blackstone
setblock 96 10 512 minecraft:smooth_basalt
fill 96 10 513 96 13 513 minecraft:blackstone
setblock 96 10 517 minecraft:smooth_basalt
fill 96 10 518 96 13 518 minecraft:blackstone
setblock 96 10 522 minecraft:smooth_basalt
fill 96 10 523 96 13 523 minecraft:blackstone
setblock 96 10 527 minecraft:smooth_basalt
fill 96 10 528 96 13 528 minecraft:blackstone
setblock 96 10 531 minecraft:blackstone
setblock 96 10 532 minecraft:smooth_basalt
fill 96 10 533 96 13 533 minecraft:blackstone
setblock 96 10 547 minecraft:smooth_basalt
fill 96 10 548 96 13 548 minecraft:blackstone
fill 96 10 550 97 10 550 minecraft:blackstone
setblock 97 10 511 minecraft:smooth_basalt
fill 97 10 512 97 13 512 minecraft:blackstone
setblock 97 10 515 minecraft:blackstone
setblock 97 10 516 minecraft:smooth_basalt
fill 97 10 517 97 12 517 minecraft:blackstone
fill 97 10 521 104 10 521 minecraft:smooth_basalt
fill 97 10 522 97 11 522 minecraft:blackstone
setblock 97 10 526 minecraft:smooth_basalt
fill 97 10 527 97 13 527 minecraft:blackstone
setblock 97 10 531 minecraft:smooth_basalt
fill 97 10 532 97 12 532 minecraft:blackstone
fill 97 10 533 97 24 534 minecraft:smooth_basalt
setblock 97 10 547 minecraft:blackstone
setblock 97 10 551 minecraft:smooth_basalt
fill 98 10 511 98 13 511 minecraft:blackstone
fill 98 10 523 98 25 525 minecraft:smooth_basalt
setblock 98 10 526 minecraft:blackstone
fill 98 10 529 98 27 529 minecraft:smooth_basalt
fill 98 10 532 98 25 533 minecraft:smooth_basalt
fill 98 10 535 101 24 535 minecraft:smooth_basalt
setblock 98 10 549 minecraft:blackstone
setblock 98 10 550 minecraft:smooth_basalt
fill 98 10 551 98 13 551 minecraft:blackstone
fill 99 10 532 99 26 532 minecraft:smooth_basalt
setblock 99 10 549 minecraft:smooth_basalt
fill 99 10 550 99 13 550 minecraft:blackstone
setblock 100 10 513 minecraft:smooth_basalt
fill 100 10 549 101 10 549 minecraft:blackstone
setblock 101 10 512 minecraft:smooth_basalt
setblock 102 10 511 minecraft:smooth_basalt
fill 102 10 512 102 13 512 minecraft:blackstone
setblock 102 10 551 minecraft:smooth_basalt
fill 103 10 511 103 13 511 minecraft:blackstone
setblock 103 10 550 minecraft:smooth_basalt
fill 103 10 551 106 10 551 minecraft:blackstone
fill 104 10 550 107 10 550 minecraft:blackstone
setblock 105 10 512 minecraft:blackstone
fill 105 10 522 105 24 522 minecraft:smooth_basalt
setblock 106 10 512 minecraft:smooth_basalt
fill 106 10 523 106 24 523 minecraft:smooth_basalt
setblock 107 10 511 minecraft:smooth_basalt
fill 107 10 512 110 10 512 minecraft:blackstone
fill 107 10 524 107 24 524 minecraft:smooth_basalt
fill 107 10 532 107 24 532 minecraft:smooth_basalt
setblock 107 10 551 minecraft:smooth_basalt
fill 108 10 511 108 13 511 minecraft:blackstone
fill 108 10 525 108 24 531 minecraft:smooth_basalt
setblock 108 10 549 minecraft:blackstone
setblock 108 10 550 minecraft:smooth_basalt
fill 108 10 551 108 13 551 minecraft:blackstone
setblock 109 10 549 minecraft:smooth_basalt
fill 109 10 550 109 13 550 minecraft:blackstone
fill 110 10 549 110 13 549 minecraft:blackstone
setblock 111 10 512 minecraft:smooth_basalt
setblock 112 10 511 minecraft:smooth_basalt
fill 112 10 512 112 13 512 minecraft:blackstone
fill 112 10 548 114 10 548 minecraft:blackstone
setblock 112 10 551 minecraft:smooth_basalt
fill 113 10 511 113 13 511 minecraft:blackstone
setblock 113 10 550 minecraft:smooth_basalt
fill 113 10 551 113 13 551 minecraft:blackstone
setblock 114 10 549 minecraft:smooth_basalt
fill 114 10 550 114 13 550 minecraft:blackstone
setblock 115 10 548 minecraft:smooth_basalt
fill 115 10 549 115 13 549 minecraft:blackstone
setblock 116 10 511 minecraft:blackstone
setblock 116 10 512 minecraft:smooth_basalt
setblock 116 10 547 minecraft:smooth_basalt
fill 116 10 548 116 13 548 minecraft:blackstone
setblock 117 10 511 minecraft:smooth_basalt
fill 117 10 512 117 13 512 minecraft:blackstone
setblock 117 10 551 minecraft:smooth_basalt
fill 118 10 511 118 13 511 minecraft:blackstone
setblock 118 10 550 minecraft:smooth_basalt
fill 118 10 551 118 13 551 minecraft:blackstone
setblock 119 10 549 minecraft:smooth_basalt
fill 119 10 550 119 13 550 minecraft:blackstone
setblock 120 10 548 minecraft:smooth_basalt
fill 120 10 549 120 12 549 minecraft:blackstone
setblock 121 10 511 minecraft:blackstone
setblock 122 10 511 minecraft:smooth_basalt
setblock 122 10 551 minecraft:smooth_basalt
fill 123 10 511 123 11 511 minecraft:blackstone
setblock 123 10 550 minecraft:smooth_basalt
fill 123 10 551 123 13 551 minecraft:blackstone
fill 124 10 550 124 11 550 minecraft:blackstone
setblock 126 10 551 minecraft:blackstone
setblock 127 10 551 minecraft:smooth_basalt
fill 128 10 551 131 10 551 minecraft:blackstone
fill 130 10 511 131 10 511 minecraft:blackstone
fill 130 10 550 130 12 550 minecraft:blackstone
setblock 132 10 511 minecraft:smooth_basalt
setblock 132 10 526 minecraft:smooth_basalt
fill 132 10 527 132 13 527 minecraft:blackstone
setblock 132 10 531 minecraft:smooth_basalt
setblock 132 10 551 minecraft:smooth_basalt
fill 133 10 511 133 12 512 minecraft:blackstone
fill 133 10 523 133 10 524 minecraft:blackstone
setblock 133 10 525 minecraft:smooth_basalt
fill 133 10 526 133 13 526 minecraft:blackstone
setblock 133 10 529 minecraft:blackstone
setblock 133 10 530 minecraft:smooth_basalt
fill 133 10 531 133 13 531 minecraft:blackstone
setblock 133 10 535 minecraft:smooth_basalt
setblock 133 10 550 minecraft:smooth_basalt
fill 133 10 551 133 13 551 minecraft:blackstone
fill 134 10 512 134 10 513 minecraft:blackstone
setblock 134 10 514 minecraft:smooth_basalt
setblock 134 10 518 minecraft:blackstone
setblock 134 10 519 minecraft:smooth_basalt
fill 134 10 520 134 10 523 minecraft:blackstone
setblock 134 10 524 minecraft:smooth_basalt
fill 134 10 525 134 13 525 minecraft:blackstone
setblock 134 10 529 minecraft:smooth_basalt
fill 134 10 530 134 13 530 minecraft:blackstone
setblock 134 10 533 minecraft:blackstone
setblock 134 10 534 minecraft:smooth_basalt
fill 134 10 535 134 13 535 minecraft:blackstone
setblock 134 10 539 minecraft:smooth_basalt
setblock 134 10 544 minecraft:smooth_basalt
fill 134 10 545 134 11 545 minecraft:blackstone
setblock 134 10 548 minecraft:blackstone
setblock 134 10 549 minecraft:smooth_basalt
fill 134 10 550 134 13 550 minecraft:blackstone
setblock 135 10 513 minecraft:smooth_basalt
fill 135 10 514 135 13 514 minecraft:blackstone
setblock 135 10 518 minecraft:smooth_basalt
fill 135 10 519 135 13 519 minecraft:blackstone
setblock 135 10 523 minecraft:smooth_basalt
fill 135 10 524 135 13 524 minecraft:blackstone
setblock 135 10 528 minecraft:smooth_basalt
fill 135 10 529 135 13 529 minecraft:blackstone
setblock 135 10 533 minecraft:smooth_basalt
fill 135 10 534 135 13 534 minecraft:blackstone
setblock 135 10 538 minecraft:smooth_basalt
fill 135 10 539 135 13 539 minecraft:blackstone
setblock 135 10 543 minecraft:smooth_basalt
fill 135 10 544 135 13 544 minecraft:blackstone
setblock 135 10 548 minecraft:smooth_basalt
fill 135 10 549 135 13 549 minecraft:blackstone
setblock 95 11 511 minecraft:blackstone
setblock 95 11 512 minecraft:smooth_basalt
fill 95 11 513 95 14 513 minecraft:blackstone
setblock 95 11 517 minecraft:smooth_basalt
fill 95 11 518 95 14 518 minecraft:blackstone
setblock 95 11 522 minecraft:smooth_basalt
fill 95 11 523 95 14 523 minecraft:blackstone
setblock 95 11 527 minecraft:smooth_basalt
fill 95 11 528 95 14 528 minecraft:blackstone
setblock 95 11 532 minecraft:smooth_basalt
fill 95 11 533 95 14 533 minecraft:blackstone
setblock 95 11 536 minecraft:blackstone
setblock 95 11 537 minecraft:smooth_basalt
fill 95 11 538 95 14 538 minecraft:blackstone
setblock 95 11 542 minecraft:smooth_basalt
fill 95 11 543 95 12 543 minecraft:blackstone
setblock 95 11 547 minecraft:smooth_basalt
fill 95 11 548 95 14 548 minecraft:blackstone
setblock 96 11 511 minecraft:smooth_basalt
fill 96 11 512 96 14 512 minecraft:blackstone
setblock 96 11 516 minecraft:smooth_basalt
fill 96 11 517 96 14 517 minecraft:blackstone
setblock 96 11 521 minecraft:smooth_basalt
fill 96 11 522 96 14 522 minecraft:blackstone
setblock 96 11 526 minecraft:smooth_basalt
fill 96 11 527 96 14 527 minecraft:blackstone
setblock 96 11 531 minecraft:smooth_basalt
fill 96 11 532 96 14 532 minecraft:blackstone
setblock 96 11 546 minecraft:smooth_basalt
fill 96 11 547 96 13 547 minecraft:blackstone
setblock 96 11 550 minecraft:blackstone
setblock 96 11 551 minecraft:smooth_basalt
fill 97 11 511 97 14 511 minecraft:blackstone
setblock 97 11 515 minecraft:smooth_basalt
fill 97 11 516 97 13 516 minecraft:blackstone
setblock 97 11 520 minecraft:smooth_basalt
setblock 97 11 521 minecraft:blackstone
setblock 97 11 525 minecraft:smooth_basalt
fill 97 11 526 97 12 526 minecraft:blackstone
setblock 97 11 530 minecraft:smooth_basalt
fill 97 11 531 97 13 531 minecraft:blackstone
fill 97 11 535 97 23 535 minecraft:smooth_basalt
setblock 97 11 550 minecraft:smooth_basalt
fill 97 11 551 97 14 551 minecraft:blackstone
setblock 98 11 513 minecraft:blackstone
fill 98 11 521 105 23 521 minecraft:smooth_basalt
fill 98 11 526 98 27 528 minecraft:smooth_basalt
setblock 98 11 549 minecraft:smooth_basalt
fill 98 11 550 98 14 550 minecraft:blackstone
setblock 99 11 513 minecraft:smooth_basalt
fill 99 11 520 103 23 520 minecraft:smooth_basalt
fill 99 11 536 102 23 536 minecraft:smooth_basalt
fill 99 11 549 100 11 549 minecraft:blackstone
setblock 100 11 512 minecraft:smooth_basalt
fill 100 11 513 101 11 513 minecraft:blackstone
setblock 101 11 511 minecraft:smooth_basalt
fill 101 11 512 101 14 512 minecraft:blackstone
setblock 101 11 551 minecraft:smooth_basalt
fill 102 11 511 102 14 511 minecraft:blackstone
setblock 102 11 550 minecraft:smooth_basalt
fill 102 11 551 105 11 551 minecraft:blackstone
fill 103 11 550 106 11 550 minecraft:blackstone
setblock 105 11 512 minecraft:smooth_basalt
setblock 106 11 511 minecraft:smooth_basalt
fill 106 11 512 109 11 512 minecraft:blackstone
fill 106 11 522 106 23 522 minecraft:smooth_basalt
setblock 106 11 551 minecraft:smooth_basalt
fill 107 11 511 107 14 511 minecraft:blackstone
fill 107 11 523 107 23 523 minecraft:smooth_basalt
fill 107 11 533 107 23 533 minecraft:smooth_basalt
setblock 107 11 550 minecraft:smooth_basalt
fill 107 11 551 107 14 551 minecraft:blackstone
fill 108 11 524 108 23 524 minecraft:smooth_basalt
fill 108 11 532 108 23 532 minecraft:smooth_basalt
setblock 108 11 549 minecraft:smooth_basalt
fill 108 11 550 108 14 550 minecraft:blackstone
fill 109 11 513 111 12 513 minecraft:gilded_blackstone
fill 109 11 526 109 23 530 minecraft:smooth_basalt
fill 109 11 549 109 14 549 minecraft:blackstone
setblock 110 11 512 minecraft:smooth_basalt
fill 110 11 514 111 12 514 minecraft:gilded_blackstone
setblock 111 11 511 minecraft:smooth_basalt
fill 111 11 512 111 14 512 minecraft:blackstone
fill 111 11 548 113 11 548 minecraft:blackstone
setblock 111 11 551 minecraft:smooth_basalt
fill 112 11 511 112 14 511 minecraft:blackstone
setblock 112 11 550 minecraft:smooth_basalt
fill 112 11 551 112 14 551 minecraft:blackstone
setblock 113 11 549 minecraft:smooth_basalt
fill 113 11 550 113 14 550 minecraft:blackstone
setblock 114 11 512 minecraft:blackstone
setblock 114 11 548 minecraft:smooth_basalt
fill 114 11 549 114 14 549 minecraft:blackstone
setblock 115 11 512 minecraft:smooth_basalt
fill 115 11 548 115 13 548 minecraft:blackstone
setblock 116 11 511 minecraft:smooth_basalt
fill 116 11 512 116 14 512 minecraft:blackstone
setblock 116 11 551 minecraft:smooth_basalt
fill 117 11 511 117 14 511 minecraft:blackstone
setblock 117 11 550 minecraft:smooth_basalt
fill 117 11 551 117 14 551 minecraft:blackstone
setblock 118 11 549 minecraft:smooth_basalt
fill 118 11 550 118 14 550 minecraft:blackstone
setblock 119 11 548 minecraft:smooth_basalt
fill 119 11 549 119 13 549 minecraft:blackstone
setblock 121 11 511 minecraft:smooth_basalt
setblock 121 11 551 minecraft:smooth_basalt
fill 122 11 511 122 12 511 minecraft:blackstone
setblock 122 11 550 minecraft:smooth_basalt
fill 122 11 551 122 14 551 minecraft:blackstone
fill 123 11 550 123 12 550 minecraft:blackstone
setblock 126 11 551 minecraft:smooth_basalt
fill 127 11 551 130 11 551 minecraft:blackstone
fill 129 11 511 130 11 511 minecraft:blackstone
setblock 131 11 511 minecraft:smooth_basalt
setblock 131 11 550 minecraft:blackstone
setblock 131 11 551 minecraft:smooth_basalt
fill 132 11 511 132 13 512 minecraft:blackstone
fill 132 11 526 132 12 526 minecraft:blackstone
fill 132 11 528 132 11 529 minecraft:blackstone
setblock 132 11 530 minecraft:smooth_basalt
fill 132 11 531 132 13 532 minecraft:blackstone
setblock 132 11 550 minecraft:smooth_basalt
fill 132 11 551 132 14 551 minecraft:blackstone
setblock 133 11 523 minecraft:blackstone
setblock 133 11 524 minecraft:smooth_basalt
fill 133 11 525 133 14 525 minecraft:blackstone
setblock 133 11 529 minecraft:smooth_basalt
fill 133 11 530 133 14 530 minecraft:blackstone
fill 133 11 532 133 11 533 minecraft:blackstone
setblock 133 11 534 minecraft:smooth_basalt
fill 133 11 535 133 14 535 minecraft:blackstone
fill 133 11 550 133 14 550 minecraft:blackstone
setblock 134 11 512 minecraft:blackstone
setblock 134 11 513 minecraft:smooth_basalt
fill 134 11 514 134 11 517 minecraft:blackstone
setblock 134 11 518 minecraft:smooth_basalt
fill 134 11 519 134 11 522 minecraft:blackstone
setblock 134 11 523 minecraft:smooth_basalt
fill 134 11 524 134 14 524 minecraft:blackstone
setblock 134 11 528 minecraft:smooth_basalt
fill 134 11 529 134 14 529 minecraft:blackstone
setblock 134 11 533 minecraft:smooth_basalt
fill 134 11 534 134 14 534 minecraft:blackstone
fill 134 11 536 134 11 537 minecraft:blackstone
setblock 134 11 538 minecraft:smooth_basalt
fill 134 11 539 134 12 539 minecraft:blackstone
setblock 134 11 544 minecraft:blackstone
setblock 134 11 548 minecraft:smooth_basalt
fill 134 11 549 134 14 549 minecraft:blackstone
setblock 135 11 512 minecraft:smooth_basalt
fill 135 11 513 135 14 513 minecraft:blackstone
setblock 135 11 517 minecraft:smooth_basalt
fill 135 11 518 135 14 518 minecraft:blackstone
setblock 135 11 522 minecraft:smooth_basalt
fill 135 11 523 135 14 523 minecraft:blackstone
setblock 135 11 527 minecraft:smooth_basalt
fill 135 11 528 135 14 528 minecraft:blackstone
setblock 135 11 532 minecraft:smooth_basalt
fill 135 11 533 135 14 533 minecraft:blackstone
setblock 135 11 537 minecraft:smooth_basalt
fill 135 11 538 135 14 538 minecraft:blackstone
setblock 135 11 542 minecraft:smooth_basalt
fill 135 11 543 135 13 543 minecraft:blackstone
setblock 135 11 547 minecraft:smooth_basalt
fill 135 11 548 135 14 548 minecraft:blackstone
setblock 95 12 511 minecraft:smooth_basalt
fill 95 12 512 95 15 512 minecraft:blackstone
setblock 95 12 516 minecraft:smooth_basalt
fill 95 12 517 95 15 517 minecraft:blackstone
setblock 95 12 521 minecraft:smooth_basalt
fill 95 12 522 95 15 522 minecraft:blackstone
setblock 95 12 526 minecraft:smooth_basalt
fill 95 12 527 95 15 527 minecraft:blackstone
setblock 95 12 531 minecraft:smooth_basalt
fill 95 12 532 95 15 532 minecraft:blackstone
setblock 95 12 535 minecraft:blackstone
setblock 95 12 536 minecraft:smooth_basalt
fill 95 12 537 95 15 537 minecraft:blackstone
setblock 95 12 546 minecraft:smooth_basalt
fill 95 12 547 95 15 547 minecraft:blackstone
setblock 95 12 551 minecraft:smooth_basalt
fill 96 12 511 96 15 511 minecraft:blackstone
setblock 96 12 515 minecraft:smooth_basalt
fill 96 12 516 96 15 516 minecraft:blackstone
setblock 96 12 520 minecraft:smooth_basalt
fill 96 12 521 96 14 521 minecraft:blackstone
setblock 96 12 525 minecraft:smooth_basalt
fill 96 12 526 96 14 526 minecraft:blackstone
setblock 96 12 530 minecraft:smooth_basalt
fill 96 12 531 96 15 531 minecraft:blackstone
setblock 96 12 535 minecraft:smooth_basalt
setblock 96 12 546 minecraft:blackstone
setblock 96 12 550 minecraft:smooth_basalt
fill 96 12 551 96 15 551 minecraft:blackstone
setblock 97 12 514 minecraft:smooth_basalt
fill 97 12 515 97 15 515 minecraft:blackstone
fill 97 12 521 97 23 522 minecraft:smooth_basalt
fill 97 12 524 97 26 524 minecraft:smooth_basalt
setblock 97 12 525 minecraft:blackstone
setblock 97 12 529 minecraft:smooth_basalt
fill 97 12 530 97 13 530 minecraft:blackstone
setblock 97 12 549 minecraft:smooth_basalt
fill 97 12 550 97 15 550 minecraft:blackstone
setblock 98 12 513 minecraft:smooth_basalt
fill 98 12 520 98 22 520 minecraft:smooth_basalt
fill 98 12 536 98 22 536 minecraft:smooth_basalt
setblock 98 12 549 minecraft:blackstone
setblock 99 12 512 minecraft:smooth_basalt
fill 99 12 513 100 13 513 minecraft:blackstone
setblock 100 12 511 minecraft:smooth_basalt
fill 100 12 512 100 15 512 minecraft:blackstone
setblock 100 12 551 minecraft:smooth_basalt
fill 101 12 511 101 15 511 minecraft:blackstone
setblock 101 12 550 minecraft:smooth_basalt
fill 101 12 551 104 12 551 minecraft:blackstone
fill 102 12 550 105 12 550 minecraft:blackstone
setblock 104 12 512 minecraft:smooth_basalt
fill 104 12 520 104 22 520 minecraft:smooth_basalt
setblock 105 12 511 minecraft:smooth_basalt
fill 105 12 512 108 12 512 minecraft:blackstone
setblock 105 12 551 minecraft:smooth_basalt
fill 106 12 511 106 15 511 minecraft:blackstone
fill 106 12 521 106 22 521 minecraft:smooth_basalt
setblock 106 12 550 minecraft:smooth_basalt
fill 106 12 551 106 15 551 minecraft:blackstone
fill 107 12 522 107 22 522 minecraft:smooth_basalt
fill 107 12 534 107 22 534 minecraft:smooth_basalt
fill 107 12 550 107 15 550 minecraft:blackstone
fill 108 12 523 108 22 523 minecraft:smooth_basalt
fill 108 12 533 108 22 533 minecraft:smooth_basalt
setblock 108 12 549 minecraft:blackstone
setblock 109 12 512 minecraft:smooth_basalt
fill 109 12 525 109 22 525 minecraft:smooth_basalt
fill 109 12 531 109 22 531 minecraft:smooth_basalt
setblock 110 12 511 minecraft:smooth_basalt
fill 110 12 512 110 15 512 minecraft:blackstone
fill 110 12 525 110 12 531 minecraft:blackstone
setblock 110 12 551 minecraft:smooth_basalt
fill 111 12 511 111 15 511 minecraft:blackstone
setblock 111 12 550 minecraft:smooth_basalt
fill 111 12 551 111 15 551 minecraft:blackstone
setblock 112 12 548 minecraft:blackstone
setblock 112 12 549 minecraft:smooth_basalt
fill 112 12 550 112 15 550 minecraft:blackstone
setblock 113 12 548 minecraft:smooth_basalt
fill 113 12 549 113 15 549 minecraft:blackstone
setblock 114 12 512 minecraft:smooth_basalt
fill 114 12 548 114 13 548 minecraft:blackstone
setblock 115 12 511 minecraft:smooth_basalt
fill 115 12 512 115 15 512 minecraft:blackstone
setblock 115 12 551 minecraft:smooth_basalt
fill 116 12 511 116 15 511 minecraft:blackstone
setblock 116 12 550 minecraft:smooth_basalt
fill 116 12 551 116 15 551 minecraft:blackstone
setblock 117 12 549 minecraft:smooth_basalt
fill 117 12 550 117 15 550 minecraft:blackstone
setblock 118 12 512 minecraft:blackstone
setblock 118 12 548 minecraft:smooth_basalt
fill 118 12 549 118 13 549 minecraft:blackstone
setblock 119 12 512 minecraft:smooth_basalt
setblock 120 12 511 minecraft:smooth_basalt
setblock 120 12 551 minecraft:smooth_basalt
fill 121 12 511 121 13 511 minecraft:blackstone
setblock 121 12 550 minecraft:smooth_basalt
fill 121 12 551 121 15 551 minecraft:blackstone
setblock 122 12 550 minecraft:blackstone
setblock 125 12 551 minecraft:smooth_basalt
fill 126 12 551 129 12 551 minecraft:blackstone
setblock 129 12 511 minecraft:blackstone
setblock 130 12 511 minecraft:smooth_basalt
setblock 130 12 551 minecraft:smooth_basalt
fill 131 12 511 131 15 511 minecraft:blackstone
setblock 131 12 550 minecraft:smooth_basalt
fill 131 12 551 131 15 551 minecraft:blackstone
setblock 132 12 528 minecraft:blackstone
setblock 132 12 529 minecraft:smooth_basalt
fill 132 12 530 132 15 530 minecraft:blackstone
setblock 132 12 533 minecraft:blackstone
fill 132 12 550 132 14 550 minecraft:blackstone
setblock 133 12 523 minecraft:smooth_basalt
fill 133 12 524 133 14 524 minecraft:blackstone
setblock 133 12 528 minecraft:smooth_basalt
fill 133 12 529 133 15 529 minecraft:blackstone
setblock 133 12 532 minecraft:blackstone
setblock 133 12 533 minecraft:smooth_basalt
fill 133 12 534 133 15 534 minecraft:blackstone
fill 133 12 536 134 12 536 minecraft:blackstone
setblock 134 12 512 minecraft:smooth_basalt
fill 134 12 513 134 12 516 minecraft:blackstone
setblock 134 12 517 minecraft:smooth_basalt
fill 134 12 518 134 12 521 minecraft:blackstone
setblock 134 12 522 minecraft:smooth_basalt
fill 134 12 523 134 15 523 minecraft:blackstone
setblock 134 12 527 minecraft:smooth_basalt
fill 134 12 528 134 15 528 minecraft:blackstone
setblock 134 12 532 minecraft:smooth_basalt
fill 134 12 533 134 15 533 minecraft:blackstone
setblock 134 12 537 minecraft:smooth_basalt
fill 134 12 538 134 15 538 minecraft:blackstone
setblock 134 12 547 minecraft:smooth_basalt
fill 134 12 548 134 13 548 minecraft:blackstone
setblock 135 12 511 minecraft:smooth_basalt
fill 135 12 512 135 15 512 minecraft:blackstone
setblock 135 12 516 minecraft:smooth_basalt
fill 135 12 517 135 15 517 minecraft:blackstone
setblock 135 12 521 minecraft:smooth_basalt
fill 135 12 522 135 15 522 minecraft:blackstone
setblock 135 12 526 minecraft:smooth_basalt
fill 135 12 527 135 15 527 minecraft:blackstone
setblock 135 12 531 minecraft:smooth_basalt
fill 135 12 532 135 15 532 minecraft:blackstone
setblock 135 12 536 minecraft:smooth_basalt
fill 135 12 537 135 15 537 minecraft:blackstone
setblock 135 12 541 minecraft:smooth_basalt
fill 135 12 542 135 13 542 minecraft:blackstone
setblock 135 12 546 minecraft:smooth_basalt
fill 135 12 547 135 14 547 minecraft:blackstone
setblock 135 12 551 minecraft:smooth_basalt
fill 95 13 511 95 16 511 minecraft:blackstone
setblock 95 13 515 minecraft:smooth_basalt
fill 95 13 516 95 16 516 minecraft:blackstone
setblock 95 13 520 minecraft:smooth_basalt
fill 95 13 521 95 16 521 minecraft:blackstone
setblock 95 13 525 minecraft:smooth_basalt
fill 95 13 526 95 16 526 minecraft:blackstone
setblock 95 13 530 minecraft:smooth_basalt
fill 95 13 531 95 16 531 minecraft:blackstone
setblock 95 13 535 minecraft:smooth_basalt
fill 95 13 536 95 16 536 minecraft:blackstone
setblock 95 13 545 minecraft:smooth_basalt
fill 95 13 546 95 14 546 minecraft:blackstone
setblock 95 13 549 minecraft:blackstone
setblock 95 13 550 minecraft:smooth_basalt
fill 95 13 551 95 16 551 minecraft:blackstone
setblock 96 13 514 minecraft:smooth_basalt
fill 96 13 515 96 16 515 minecraft:blackstone
setblock 96 13 519 minecraft:smooth_basalt
fill 96 13 520 96 14 520 minecraft:blackstone
setblock 96 13 524 minecraft:smooth_basalt
fill 96 13 525 96 14 525 minecraft:blackstone
setblock 96 13 529 minecraft:smooth_basalt
fill 96 13 530 96 15 530 minecraft:blackstone
setblock 96 13 534 minecraft:smooth_basalt
fill 96 13 535 96 14 535 minecraft:blackstone
setblock 96 13 549 minecraft:smooth_basalt
fill 96 13 550 96 16 550 minecraft:blackstone
setblock 97 13 513 minecraft:smooth_basalt
fill 97 13 514 97 16 514 minecraft:blackstone
fill 97 13 520 97 21 520 minecraft:smooth_basalt
fill 97 13 523 97 25 523 minecraft:smooth_basalt
fill 97 13 525 97 26 526 minecraft:smooth_basalt
fill 97 13 528 97 27 528 minecraft:smooth_basalt
setblock 97 13 529 minecraft:blackstone
fill 97 13 532 97 26 532 minecraft:smooth_basalt
fill 97 13 536 97 21 536 minecraft:smooth_basalt
setblock 97 13 537 minecraft:light[level=12]
setblock 97 13 545 minecraft:light[level=12]
setblock 98 13 512 minecraft:smooth_basalt
fill 98 13 513 98 16 513 minecraft:blackstone
setblock 99 13 511 minecraft:smooth_basalt
fill 99 13 512 99 16 512 minecraft:blackstone
fill 99 13 519 103 21 519 minecraft:smooth_basalt
fill 99 13 537 103 21 537 minecraft:smooth_basalt
setblock 99 13 551 minecraft:smooth_basalt
fill 100 13 511 100 16 511 minecraft:blackstone
setblock 100 13 550 minecraft:smooth_basalt
fill 100 13 551 103 13 551 minecraft:blackstone
fill 101 13 550 104 13 550 minecraft:blackstone
setblock 103 13 512 minecraft:smooth_basalt
setblock 104 13 511 minecraft:smooth_basalt
fill 104 13 512 107 13 512 minecraft:blackstone
setblock 104 13 551 minecraft:smooth_basalt
fill 105 13 511 105 16 511 minecraft:blackstone
setblock 105 13 513 minecraft:light[level=12]
fill 105 13 520 105 21 520 minecraft:smooth_basalt
setblock 105 13 537 minecraft:light[level=12]
setblock 105 13 545 minecraft:light[level=12]
setblock 105 13 550 minecraft:smooth_basalt
fill 105 13 551 105 16 551 minecraft:blackstone
fill 106 13 550 106 15 550 minecraft:blackstone
fill 107 13 521 107 21 521 minecraft:smooth_basalt
fill 107 13 535 107 21 535 minecraft:smooth_basalt
setblock 108 13 512 minecraft:smooth_basalt
fill 108 13 522 108 21 522 minecraft:smooth_basalt
fill 108 13 534 108 21 534 minecraft:smooth_basalt
setblock 109 13 511 minecraft:smooth_basalt
fill 109 13 512 109 16 512 minecraft:blackstone
fill 109 13 524 109 21 524 minecraft:smooth_basalt
fill 109 13 532 109 21 532 minecraft:smooth_basalt
setblock 109 13 551 minecraft:smooth_basalt
fill 110 13 511 110 16 511 minecraft:blackstone
setblock 110 13 525 minecraft:blackstone
fill 110 13 526 110 21 530 minecraft:smooth_basalt
setblock 110 13 531 minecraft:blackstone
setblock 110 13 550 minecraft:smooth_basalt
fill 110 13 551 110 16 551 minecraft:blackstone
setblock 111 13 549 minecraft:smooth_basalt
fill 111 13 550 111 16 550 minecraft:blackstone
setblock 112 13 548 minecraft:smooth_basalt
fill 112 13 549 112 16 549 minecraft:blackstone
setblock 113 13 512 minecraft:smooth_basalt
setblock 113 13 513 minecraft:light[level=12]
setblock 113 13 521 minecraft:light[level=12]
setblock 113 13 529 minecraft:light[level=12]
setblock 113 13 537 minecraft:light[level=12]
setblock 113 13 545 minecraft:light[level=12]
setblock 113 13 548 minecraft:blackstone
setblock 114 13 511 minecraft:smooth_basalt
fill 114 13 512 114 16 512 minecraft:blackstone
setblock 114 13 551 minecraft:smooth_basalt
fill 115 13 511 115 16 511 minecraft:blackstone
setblock 115 13 550 minecraft:smooth_basalt
fill 115 13 551 115 16 551 minecraft:blackstone
setblock 116 13 549 minecraft:smooth_basalt
fill 116 13 550 116 16 550 minecraft:blackstone
fill 117 13 549 117 14 549 minecraft:blackstone
setblock 118 13 512 minecraft:smooth_basalt
setblock 119 13 511 minecraft:smooth_basalt
setblock 119 13 551 minecraft:smooth_basalt
fill 120 13 511 120 14 511 minecraft:blackstone
setblock 120 13 550 minecraft:smooth_basalt
fill 120 13 551 120 16 551 minecraft:blackstone
setblock 121 13 513 minecraft:light[level=12]
setblock 121 13 521 minecraft:light[level=12]
setblock 121 13 529 minecraft:light[level=12]
setblock 121 13 537 minecraft:light[level=12]
setblock 121 13 545 minecraft:light[level=12]
setblock 121 13 550 minecraft:blackstone
setblock 124 13 551 minecraft:smooth_basalt
fill 125 13 551 128 13 551 minecraft:blackstone
setblock 128 13 511 minecraft:blackstone
setblock 129 13 511 minecraft:smooth_basalt
setblock 129 13 513 minecraft:light[level=12]
setblock 129 13 521 minecraft:light[level=12]
setblock 129 13 529 minecraft:light[level=12]
setblock 129 13 537 minecraft:light[level=12]
setblock 129 13 551 minecraft:smooth_basalt
fill 130 13 511 130 16 511 minecraft:blackstone
fill 130 13 551 130 16 551 minecraft:blackstone
fill 131 13 512 131 14 512 minecraft:blackstone
setblock 131 13 550 minecraft:blackstone
setblock 132 13 528 minecraft:smooth_basalt
fill 132 13 529 132 15 529 minecraft:blackstone
setblock 132 13 533 minecraft:smooth_basalt
setblock 133 13 511 minecraft:blackstone
setblock 133 13 512 minecraft:smooth_basalt
setblock 133 13 523 minecraft:blackstone
setblock 133 13 527 minecraft:smooth_basalt
fill 133 13 528 133 16 528 minecraft:blackstone
setblock 133 13 532 minecraft:smooth_basalt
fill 133 13 533 133 16 533 minecraft:blackstone
setblock 133 13 536 minecraft:blackstone
setblock 134 13 511 minecraft:smooth_basalt
fill 134 13 512 134 13 515 minecraft:blackstone
setblock 134 13 516 minecraft:smooth_basalt
fill 134 13 517 134 13 520 minecraft:blackstone
setblock 134 13 521 minecraft:smooth_basalt
fill 134 13 522 134 16 522 minecraft:blackstone
setblock 134 13 526 minecraft:smooth_basalt
fill 134 13 527 134 16 527 minecraft:blackstone
setblock 134 13 531 minecraft:smooth_basalt
fill 134 13 532 134 16 532 minecraft:blackstone
setblock 134 13 536 minecraft:smooth_basalt
fill 134 13 537 134 16 537 minecraft:blackstone
setblock 134 13 551 minecraft:smooth_basalt
fill 135 13 511 135 16 511 minecraft:blackstone
setblock 135 13 515 minecraft:smooth_basalt
fill 135 13 516 135 16 516 minecraft:blackstone
setblock 135 13 520 minecraft:smooth_basalt
fill 135 13 521 135 16 521 minecraft:blackstone
setblock 135 13 525 minecraft:smooth_basalt
fill 135 13 526 135 16 526 minecraft:blackstone
setblock 135 13 530 minecraft:smooth_basalt
fill 135 13 531 135 16 531 minecraft:blackstone
setblock 135 13 535 minecraft:smooth_basalt
fill 135 13 536 135 16 536 minecraft:blackstone
setblock 135 13 540 minecraft:smooth_basalt
fill 135 13 541 135 14 541 minecraft:blackstone
setblock 135 13 545 minecraft:smooth_basalt
fill 135 13 546 135 14 546 minecraft:blackstone
setblock 135 13 550 minecraft:smooth_basalt
fill 135 13 551 135 16 551 minecraft:blackstone
setblock 95 14 514 minecraft:smooth_basalt
fill 95 14 515 95 17 515 minecraft:blackstone
setblock 95 14 519 minecraft:smooth_basalt
fill 95 14 520 95 17 520 minecraft:blackstone
setblock 95 14 524 minecraft:smooth_basalt
fill 95 14 525 95 17 525 minecraft:blackstone
setblock 95 14 529 minecraft:smooth_basalt
fill 95 14 530 95 17 530 minecraft:blackstone
setblock 95 14 534 minecraft:smooth_basalt
fill 95 14 535 95 17 535 minecraft:blackstone
setblock 95 14 549 minecraft:smooth_basalt
fill 95 14 550 95 17 550 minecraft:blackstone
setblock 96 14 513 minecraft:smooth_basalt
fill 96 14 514 96 17 514 minecraft:blackstone
setblock 96 14 518 minecraft:smooth_basalt
fill 96 14 519 96 15 519 minecraft:blackstone
fill 96 14 523 96 24 523 minecraft:smooth_basalt
setblock 96 14 524 minecraft:blackstone
setblock 96 14 528 minecraft:smooth_basalt
fill 96 14 529 96 15 529 minecraft:blackstone
setblock 96 14 533 minecraft:smooth_basalt
fill 96 14 534 96 15 534 minecraft:blackstone
fill 96 14 536 96 20 536 minecraft:smooth_basalt
setblock 96 14 548 minecraft:smooth_basalt
fill 96 14 549 96 15 549 minecraft:blackstone
setblock 97 14 512 minecraft:smooth_basalt
fill 97 14 513 97 17 513 minecraft:blackstone
fill 97 14 527 97 27 527 minecraft:smooth_basalt
fill 97 14 529 97 26 531 minecraft:smooth_basalt
setblock 98 14 511 minecraft:smooth_basalt
fill 98 14 512 98 17 512 minecraft:blackstone
fill 98 14 519 98 20 519 minecraft:smooth_basalt
fill 98 14 537 98 20 537 minecraft:smooth_basalt
setblock 98 14 551 minecraft:smooth_basalt
fill 99 14 511 99 17 511 minecraft:blackstone
setblock 99 14 513 minecraft:blackstone
setblock 99 14 550 minecraft:smooth_basalt
fill 99 14 551 102 14 551 minecraft:blackstone
fill 100 14 550 101 14 550 minecraft:blackstone
setblock 102 14 512 minecraft:smooth_basalt
setblock 103 14 511 minecraft:smooth_basalt
fill 103 14 512 106 14 512 minecraft:blackstone
setblock 103 14 551 minecraft:smooth_basalt
fill 104 14 511 104 17 511 minecraft:blackstone
fill 104 14 519 104 20 519 minecraft:smooth_basalt
fill 104 14 537 104 20 537 minecraft:smooth_basalt
setblock 104 14 550 minecraft:smooth_basalt
fill 104 14 551 104 17 551 minecraft:blackstone
setblock 105 14 550 minecraft:blackstone
fill 106 14 520 106 20 520 minecraft:smooth_basalt
fill 106 14 536 106 20 536 minecraft:smooth_basalt
setblock 107 14 512 minecraft:smooth_basalt
setblock 108 14 511 minecraft:smooth_basalt
fill 108 14 512 108 17 512 minecraft:blackstone
setblock 108 14 551 minecraft:smooth_basalt
fill 109 14 511 109 17 511 minecraft:blackstone
fill 109 14 523 109 20 523 minecraft:smooth_basalt
fill 109 14 533 109 20 533 minecraft:smooth_basalt
setblock 109 14 550 minecraft:smooth_basalt
fill 109 14 551 109 17 551 minecraft:blackstone
fill 110 14 525 110 20 525 minecraft:smooth_basalt
fill 110 14 531 110 20 531 minecraft:smooth_basalt
setblock 110 14 549 minecraft:smooth_basalt
fill 110 14 550 110 17 550 minecraft:blackstone
fill 111 14 549 111 16 549 minecraft:blackstone
setblock 112 14 512 minecraft:smooth_basalt
setblock 113 14 511 minecraft:smooth_basalt
fill 113 14 512 113 17 512 minecraft:blackstone
setblock 113 14 551 minecraft:smooth_basalt
fill 114 14 511 114 17 511 minecraft:blackstone
setblock 114 14 550 minecraft:smooth_basalt
fill 114 14 551 114 17 551 minecraft:blackstone
setblock 115 14 549 minecraft:smooth_basalt
fill 115 14 550 115 17 550 minecraft:blackstone
fill 116 14 549 116 15 549 minecraft:blackstone
setblock 117 14 512 minecraft:smooth_basalt
setblock 118 14 511 minecraft:smooth_basalt
setblock 118 14 551 minecraft:smooth_basalt
fill 119 14 511 119 15 511 minecraft:blackstone
setblock 119 14 550 minecraft:smooth_basalt
fill 119 14 551 119 16 551 minecraft:blackstone
setblock 120 14 550 minecraft:blackstone
setblock 123 14 551 minecraft:smooth_basalt
setblock 128 14 511 minecraft:smooth_basalt
setblock 128 14 551 minecraft:smooth_basalt
fill 129 14 511 129 17 511 minecraft:blackstone
fill 129 14 551 129 15 551 minecraft:blackstone
setblock 132 14 511 minecraft:blackstone
setblock 132 14 512 minecraft:smooth_basalt
setblock 132 14 528 minecraft:blackstone
setblock 132 14 531 minecraft:blackstone
setblock 132 14 532 minecraft:smooth_basalt
fill 132 14 533 132 15 533 minecraft:blackstone
setblock 133 14 511 minecraft:smooth_basalt
fill 133 14 512 134 16 512 minecraft:blackstone
setblock 133 14 526 minecraft:smooth_basalt
fill 133 14 527 133 16 527 minecraft:blackstone
setblock 133 14 531 minecraft:smooth_basalt
fill 133 14 532 133 17 532 minecraft:blackstone
setblock 133 14 536 minecraft:smooth_basalt
setblock 133 14 551 minecraft:smooth_basalt
fill 134 14 511 134 17 511 minecraft:blackstone
fill 134 14 513 134 14 514 minecraft:blackstone
setblock 134 14 515 minecraft:smooth_basalt
fill 134 14 516 134 14 519 minecraft:blackstone
setblock 134 14 520 minecraft:smooth_basalt
fill 134 14 521 134 17 521 minecraft:blackstone
setblock 134 14 525 minecraft:smooth_basalt
fill 134 14 526 134 17 526 minecraft:blackstone
setblock 134 14 530 minecraft:smooth_basalt
fill 134 14 531 134 17 531 minecraft:blackstone
setblock 134 14 535 minecraft:smooth_basalt
fill 134 14 536 134 17 536 minecraft:blackstone
setblock 134 14 550 minecraft:smooth_basalt
fill 134 14 551 134 17 551 minecraft:blackstone
setblock 135 14 514 minecraft:smooth_basalt
fill 135 14 515 135 17 515 minecraft:blackstone
setblock 135 14 519 minecraft:smooth_basalt
fill 135 14 520 135 17 520 minecraft:blackstone
setblock 135 14 524 minecraft:smooth_basalt
fill 135 14 525 135 17 525 minecraft:blackstone
setblock 135 14 529 minecraft:smooth_basalt
fill 135 14 530 135 17 530 minecraft:blackstone
setblock 135 14 534 minecraft:smooth_basalt
fill 135 14 535 135 17 535 minecraft:blackstone
setblock 135 14 539 minecraft:smooth_basalt
fill 135 14 540 135 15 540 minecraft:blackstone
setblock 135 14 549 minecraft:smooth_basalt
fill 135 14 550 135 16 550 minecraft:blackstone
setblock 95 15 513 minecraft:smooth_basalt
fill 95 15 514 95 18 514 minecraft:blackstone
setblock 95 15 518 minecraft:smooth_basalt
fill 95 15 519 95 18 519 minecraft:blackstone
setblock 95 15 523 minecraft:smooth_basalt
fill 95 15 524 95 17 524 minecraft:blackstone
setblock 95 15 528 minecraft:smooth_basalt
fill 95 15 529 95 18 529 minecraft:blackstone
setblock 95 15 533 minecraft:smooth_basalt
fill 95 15 534 95 18 534 minecraft:blackstone
setblock 95 15 538 minecraft:smooth_basalt
setblock 95 15 548 minecraft:smooth_basalt
fill 95 15 549 95 18 549 minecraft:blackstone
setblock 96 15 512 minecraft:smooth_basalt
fill 96 15 513 96 18 513 minecraft:blackstone
setblock 96 15 517 minecraft:smooth_basalt
fill 96 15 518 96 18 518 minecraft:blackstone
fill 96 15 520 96 20 522 minecraft:smooth_basalt
fill 96 15 524 96 25 527 minecraft:smooth_basalt
setblock 96 15 528 minecraft:blackstone
setblock 96 15 532 minecraft:smooth_basalt
setblock 96 15 533 minecraft:blackstone
fill 96 15 535 96 22 535 minecraft:smooth_basalt
setblock 97 15 511 minecraft:smooth_basalt
fill 97 15 512 97 18 512 minecraft:blackstone
setblock 97 15 551 minecraft:smooth_basalt
fill 98 15 511 98 18 511 minecraft:blackstone
setblock 98 15 550 minecraft:smooth_basalt
fill 98 15 551 101 15 551 minecraft:blackstone
setblock 101 15 512 minecraft:smooth_basalt
setblock 102 15 511 minecraft:smooth_basalt
fill 102 15 512 105 15 512 minecraft:blackstone
setblock 102 15 551 minecraft:smooth_basalt
fill 103 15 511 103 18 511 minecraft:blackstone
fill 103 15 551 103 18 551 minecraft:blackstone
setblock 106 15 512 minecraft:smooth_basalt
setblock 107 15 511 minecraft:smooth_basalt
fill 107 15 512 107 18 512 minecraft:blackstone
setblock 107 15 551 minecraft:smooth_basalt
fill 108 15 511 108 18 511 minecraft:blackstone
setblock 108 15 550 minecraft:smooth_basalt
fill 108 15 551 108 18 551 minecraft:blackstone
fill 109 15 550 109 18 550 minecraft:blackstone
setblock 110 15 549 minecraft:blackstone
setblock 111 15 512 minecraft:smooth_basalt
setblock 112 15 511 minecraft:smooth_basalt
fill 112 15 512 112 18 512 minecraft:blackstone
setblock 112 15 551 minecraft:smooth_basalt
fill 113 15 511 113 18 511 minecraft:blackstone
setblock 113 15 550 minecraft:smooth_basalt
fill 113 15 551 113 18 551 minecraft:blackstone
setblock 114 15 549 minecraft:smooth_basalt
fill 114 15 550 114 18 550 minecraft:blackstone
setblock 115 15 549 minecraft:blackstone
setblock 116 15 512 minecraft:smooth_basalt
setblock 117 15 511 minecraft:smooth_basalt
setblock 117 15 512 minecraft:blackstone
setblock 117 15 551 minecraft:smooth_basalt
fill 118 15 511 118 17 511 minecraft:blackstone
setblock 118 15 550 minecraft:smooth_basalt
fill 118 15 551 118 17 551 minecraft:blackstone
fill 128 15 511 128 18 511 minecraft:blackstone
setblock 130 15 512 minecraft:blackstone
setblock 131 15 512 minecraft:smooth_basalt
setblock 132 15 511 minecraft:smooth_basalt
fill 132 15 512 132 18 512 minecraft:blackstone
setblock 132 15 531 minecraft:smooth_basalt
fill 132 15 532 132 16 532 minecraft:blackstone
setblock 132 15 551 minecraft:smooth_basalt
fill 133 15 511 133 18 511 minecraft:blackstone
fill 133 15 513 134 15 513 minecraft:blackstone
setblock 133 15 525 minecraft:smooth_basalt
setblock 133 15 526 minecraft:blackstone
setblock 133 15 530 minecraft:smooth_basalt
fill 133 15 531 133 18 531 minecraft:blackstone
setblock 133 15 535 minecraft:smooth_basalt
fill 133 15 536 133 18 536 minecraft:blackstone
fill 133 15 551 133 18 551 minecraft:blackstone
setblock 134 15 514 minecraft:smooth_basalt
fill 134 15 515 134 15 518 minecraft:blackstone
setblock 134 15 519 minecraft:smooth_basalt
fill 134 15 520 134 18 520 minecraft:blackstone
setblock 134 15 524 minecraft:smooth_basalt
fill 134 15 525 134 18 525 minecraft:blackstone
setblock 134 15 529 minecraft:smooth_basalt
fill 134 15 530 134 18 530 minecraft:blackstone
setblock 134 15 534 minecraft:smooth_basalt
fill 134 15 535 134 18 535 minecraft:blackstone
setblock 135 15 513 minecraft:smooth_basalt
fill 135 15 514 135 18 514 minecraft:blackstone
setblock 135 15 518 minecraft:smooth_basalt
fill 135 15 519 135 18 519 minecraft:blackstone
setblock 135 15 523 minecraft:smooth_basalt
fill 135 15 524 135 18 524 minecraft:blackstone
setblock 135 15 528 minecraft:smooth_basalt
fill 135 15 529 135 18 529 minecraft:blackstone
setblock 135 15 533 minecraft:smooth_basalt
fill 135 15 534 135 18 534 minecraft:blackstone
setblock 135 15 538 minecraft:smooth_basalt
fill 135 15 539 135 18 539 minecraft:blackstone
setblock 135 15 548 minecraft:smooth_basalt
fill 135 15 549 135 16 549 minecraft:blackstone
setblock 95 16 512 minecraft:smooth_basalt
fill 95 16 513 95 19 513 minecraft:blackstone
setblock 95 16 517 minecraft:smooth_basalt
fill 95 16 518 95 19 518 minecraft:blackstone
setblock 95 16 522 minecraft:smooth_basalt
fill 95 16 523 95 17 523 minecraft:blackstone
setblock 95 16 527 minecraft:smooth_basalt
fill 95 16 528 95 17 528 minecraft:blackstone
setblock 95 16 532 minecraft:smooth_basalt
fill 95 16 533 95 19 533 minecraft:blackstone
setblock 95 16 537 minecraft:smooth_basalt
setblock 95 16 548 minecraft:blackstone
setblock 96 16 511 minecraft:smooth_basalt
fill 96 16 512 96 19 512 minecraft:blackstone
setblock 96 16 516 minecraft:smooth_basalt
fill 96 16 517 96 19 517 minecraft:blackstone
fill 96 16 528 96 25 531 minecraft:smooth_basalt
setblock 96 16 532 minecraft:blackstone
fill 96 16 533 96 23 534 minecraft:smooth_basalt
setblock 96 16 551 minecraft:smooth_basalt
fill 97 16 511 97 19 511 minecraft:blackstone
fill 97 16 519 97 18 519 minecraft:smooth_basalt
fill 97 16 537 97 18 537 minecraft:smooth_basalt
fill 97 16 551 100 16 551 minecraft:blackstone
setblock 100 16 512 minecraft:smooth_basalt
setblock 101 16 511 minecraft:smooth_basalt
fill 101 16 512 102 16 512 minecraft:blackstone
setblock 101 16 551 minecraft:smooth_basalt
fill 102 16 511 102 19 511 minecraft:blackstone
fill 102 16 551 102 19 551 minecraft:blackstone
setblock 105 16 512 minecraft:smooth_basalt
fill 105 16 519 105 18 519 minecraft:smooth_basalt
fill 105 16 537 105 18 537 minecraft:smooth_basalt
setblock 106 16 511 minecraft:smooth_basalt
fill 106 16 512 106 19 512 minecraft:blackstone
setblock 106 16 551 minecraft:smooth_basalt
fill 107 16 511 107 19 511 minecraft:blackstone
setblock 107 16 550 minecraft:smooth_basalt
fill 107 16 551 107 19 551 minecraft:blackstone
fill 108 16 521 108 18 521 minecraft:smooth_basalt
fill 108 16 535 108 18 535 minecraft:smooth_basalt
fill 108 16 550 108 19 550 minecraft:blackstone
setblock 110 16 512 minecraft:smooth_basalt
fill 110 16 524 110 18 524 minecraft:smooth_basalt
fill 110 16 532 110 18 532 minecraft:smooth_basalt
setblock 111 16 511 minecraft:smooth_basalt
fill 111 16 512 111 19 512 minecraft:blackstone
setblock 111 16 551 minecraft:smooth_basalt
fill 112 16 511 112 19 511 minecraft:blackstone
setblock 112 16 550 minecraft:smooth_basalt
fill 112 16 551 112 19 551 minecraft:blackstone
setblock 113 16 549 minecraft:smooth_basalt
fill 113 16 550 113 19 550 minecraft:blackstone
setblock 114 16 549 minecraft:blackstone
setblock 115 16 512 minecraft:smooth_basalt
setblock 116 16 511 minecraft:smooth_basalt
setblock 116 16 512 minecraft:blackstone
setblock 116 16 551 minecraft:smooth_basalt
fill 117 16 511 117 18 511 minecraft:blackstone
setblock 117 16 550 minecraft:smooth_basalt
fill 117 16 551 117 18 551 minecraft:blackstone
setblock 130 16 512 minecraft:smooth_basalt
setblock 131 16 511 minecraft:smooth_basalt
fill 131 16 512 131 19 512 minecraft:blackstone
setblock 131 16 551 minecraft:smooth_basalt
fill 132 16 511 132 19 511 minecraft:blackstone
setblock 132 16 531 minecraft:blackstone
fill 132 16 551 132 19 551 minecraft:blackstone
setblock 133 16 513 minecraft:blackstone
setblock 133 16 514 minecraft:smooth_basalt
fill 133 16 515 134 18 515 minecraft:blackstone
setblock 133 16 529 minecraft:smooth_basalt
fill 133 16 530 133 18 530 minecraft:blackstone
setblock 133 16 534 minecraft:smooth_basalt
fill 133 16 535 133 19 535 minecraft:blackstone
setblock 134 16 513 minecraft:smooth_basalt
fill 134 16 514 134 19 514 minecraft:blackstone
fill 134 16 516 134 16 517 minecraft:blackstone
setblock 134 16 518 minecraft:smooth_basalt
fill 134 16 519 134 19 519 minecraft:blackstone
setblock 134 16 523 minecraft:smooth_basalt
fill 134 16 524 134 17 524 minecraft:blackstone
setblock 134 16 528 minecraft:smooth_basalt
fill 134 16 529 134 19 529 minecraft:blackstone
setblock 134 16 533 minecraft:smooth_basalt
fill 134 16 534 134 19 534 minecraft:blackstone
setblock 134 16 538 minecraft:smooth_basalt
setblock 135 16 512 minecraft:smooth_basalt
fill 135 16 513 135 19 513 minecraft:blackstone
setblock 135 16 517 minecraft:smooth_basalt
fill 135 16 518 135 19 518 minecraft:blackstone
setblock 135 16 522 minecraft:smooth_basalt
fill 135 16 523 135 19 523 minecraft:blackstone
setblock 135 16 527 minecraft:smooth_basalt
fill 135 16 528 135 19 528 minecraft:blackstone
setblock 135 16 532 minecraft:smooth_basalt
fill 135 16 533 135 19 533 minecraft:blackstone
setblock 135 16 537 minecraft:smooth_basalt
fill 135 16 538 135 19 538 minecraft:blackstone
setblock 95 17 511 minecraft:smooth_basalt
fill 95 17 512 95 20 512 minecraft:blackstone
setblock 95 17 516 minecraft:smooth_basalt
fill 95 17 517 95 20 517 minecraft:blackstone
setblock 95 17 521 minecraft:smooth_basalt
fill 95 17 522 95 20 522 minecraft:blackstone
fill 95 17 526 95 25 526 minecraft:smooth_basalt
setblock 95 17 527 minecraft:blackstone
setblock 95 17 531 minecraft:smooth_basalt
fill 95 17 532 95 20 532 minecraft:blackstone
setblock 95 17 536 minecraft:smooth_basalt
fill 95 17 537 95 20 537 minecraft:blackstone
setblock 95 17 551 minecraft:smooth_basalt
fill 96 17 511 96 20 511 minecraft:blackstone
setblock 96 17 515 minecraft:smooth_basalt
fill 96 17 516 96 20 516 minecraft:blackstone
fill 96 17 532 96 25 532 minecraft:smooth_basalt
fill 96 17 551 99 17 551 minecraft:blackstone
setblock 97 17 514 minecraft:smooth_basalt
setblock 99 17 512 minecraft:smooth_basalt
setblock 100 17 511 minecraft:smooth_basalt
fill 100 17 512 101 17 512 minecraft:blackstone
setblock 100 17 551 minecraft:smooth_basalt
fill 101 17 511 101 20 511 minecraft:blackstone
setblock 101 17 518 minecraft:smooth_basalt
setblock 101 17 538 minecraft:smooth_basalt
fill 101 17 551 101 18 551 minecraft:blackstone
setblock 105 17 511 minecraft:smooth_basalt
fill 105 17 512 105 20 512 minecraft:blackstone
setblock 105 17 551 minecraft:smooth_basalt
fill 106 17 511 106 20 511 minecraft:blackstone
fill 106 17 551 106 20 551 minecraft:blackstone
setblock 107 17 520 minecraft:smooth_basalt
setblock 107 17 536 minecraft:smooth_basalt
fill 107 17 550 107 20 550 minecraft:blackstone
setblock 109 17 512 minecraft:smooth_basalt
setblock 109 17 522 minecraft:smooth_basalt
setblock 109 17 534 minecraft:smooth_basalt
setblock 110 17 511 minecraft:smooth_basalt
fill 110 17 512 110 20 512 minecraft:blackstone
setblock 110 17 551 minecraft:smooth_basalt
fill 111 17 511 111 20 511 minecraft:blackstone
setblock 111 17 528 minecraft:smooth_basalt
setblock 111 17 550 minecraft:smooth_basalt
fill 111 17 551 111 20 551 minecraft:blackstone
fill 112 17 550 112 20 550 minecraft:blackstone
setblock 114 17 512 minecraft:smooth_basalt
setblock 115 17 511 minecraft:smooth_basalt
setblock 115 17 512 minecraft:blackstone
setblock 115 17 551 minecraft:smooth_basalt
fill 116 17 511 116 20 511 minecraft:blackstone
setblock 116 17 550 minecraft:smooth_basalt
fill 116 17 551 116 20 551 minecraft:blackstone
fill 127 17 511 127 19 511 minecraft:blackstone
setblock 129 17 512 minecraft:smooth_basalt
setblock 130 17 511 minecraft:smooth_basalt
fill 130 17 512 130 20 512 minecraft:blackstone
setblock 130 17 551 minecraft:smooth_basalt
fill 131 17 511 131 20 511 minecraft:blackstone
fill 131 17 551 131 20 551 minecraft:blackstone
setblock 132 17 513 minecraft:blackstone
setblock 133 17 512 minecraft:blackstone
setblock 133 17 513 minecraft:smooth_basalt
fill 133 17 514 133 20 514 minecraft:blackstone
fill 133 17 516 134 17 516 minecraft:blackstone
setblock 133 17 528 minecraft:smooth_basalt
fill 133 17 529 133 18 529 minecraft:blackstone
setblock 133 17 533 minecraft:smooth_basalt
fill 133 17 534 133 20 534 minecraft:blackstone
setblock 134 17 512 minecraft:smooth_basalt
fill 134 17 513 134 20 513 minecraft:blackstone
setblock 134 17 517 minecraft:smooth_basalt
fill 134 17 518 134 20 518 minecraft:blackstone
setblock 134 17 522 minecraft:smooth_basalt
setblock 134 17 523 minecraft:blackstone
setblock 134 17 527 minecraft:smooth_basalt
fill 134 17 528 134 20 528 minecraft:blackstone
setblock 134 17 532 minecraft:smooth_basalt
fill 134 17 533 134 20 533 minecraft:blackstone
setblock 134 17 537 minecraft:smooth_basalt
fill 134 17 538 134 20 538 minecraft:blackstone
setblock 135 17 511 minecraft:smooth_basalt
fill 135 17 512 135 20 512 minecraft:blackstone
setblock 135 17 516 minecraft:smooth_basalt
fill 135 17 517 135 20 517 minecraft:blackstone
setblock 135 17 521 minecraft:smooth_basalt
fill 135 17 522 135 20 522 minecraft:blackstone
setblock 135 17 526 minecraft:smooth_basalt
fill 135 17 527 135 20 527 minecraft:blackstone
setblock 135 17 531 minecraft:smooth_basalt
fill 135 17 532 135 20 532 minecraft:blackstone
setblock 135 17 536 minecraft:smooth_basalt
fill 135 17 537 135 20 537 minecraft:blackstone
setblock 135 17 551 minecraft:smooth_basalt
fill 95 18 511 95 21 511 minecraft:blackstone
setblock 95 18 515 minecraft:smooth_basalt
fill 95 18 516 95 21 516 minecraft:blackstone
setblock 95 18 520 minecraft:smooth_basalt
fill 95 18 521 95 21 521 minecraft:blackstone
fill 95 18 523 95 22 525 minecraft:smooth_basalt
fill 95 18 527 95 25 528 minecraft:smooth_basalt
fill 95 18 530 95 25 530 minecraft:smooth_basalt
fill 95 18 531 95 19 531 minecraft:blackstone
setblock 95 18 535 minecraft:smooth_basalt
fill 95 18 536 95 21 536 minecraft:blackstone
fill 95 18 538 95 19 538 minecraft:blackstone
setblock 95 18 550 minecraft:smooth_basalt
fill 95 18 551 98 18 551 minecraft:blackstone
setblock 96 18 514 minecraft:smooth_basalt
fill 96 18 515 96 21 515 minecraft:blackstone
setblock 97 18 513 minecraft:smooth_basalt
setblock 98 18 512 minecraft:smooth_basalt
setblock 99 18 511 minecraft:smooth_basalt
fill 99 18 512 100 20 512 minecraft:blackstone
setblock 99 18 551 minecraft:smooth_basalt
fill 100 18 511 100 21 511 minecraft:blackstone
setblock 100 18 551 minecraft:blackstone
setblock 104 18 511 minecraft:smooth_basalt
setblock 104 18 551 minecraft:smooth_basalt
fill 105 18 511 105 21 511 minecraft:blackstone
fill 105 18 551 105 21 551 minecraft:blackstone
setblock 108 18 512 minecraft:smooth_basalt
setblock 109 18 511 minecraft:smooth_basalt
fill 109 18 512 109 21 512 minecraft:blackstone
setblock 109 18 551 minecraft:smooth_basalt
fill 110 18 511 110 21 511 minecraft:blackstone
fill 110 18 523 110 20 523 minecraft:shroomlight
fill 110 18 533 110 20 533 minecraft:shroomlight
setblock 110 18 550 minecraft:smooth_basalt
fill 110 18 551 110 21 551 minecraft:blackstone
fill 111 18 550 111 21 550 minecraft:blackstone
setblock 113 18 512 minecraft:smooth_basalt
setblock 114 18 511 minecraft:smooth_basalt
fill 114 18 512 114 19 512 minecraft:blackstone
setblock 114 18 551 minecraft:smooth_basalt
fill 115 18 511 115 21 511 minecraft:blackstone
setblock 115 18 550 minecraft:smooth_basalt
fill 115 18 551 115 21 551 minecraft:blackstone
setblock 129 18 511 minecraft:smooth_basalt
fill 129 18 512 129 21 512 minecraft:blackstone
fill 130 18 511 130 21 511 minecraft:blackstone
setblock 130 18 551 minecraft:blackstone
setblock 131 18 513 minecraft:blackstone
setblock 132 18 513 minecraft:smooth_basalt
setblock 133 18 512 minecraft:smooth_basalt
fill 133 18 513 133 21 513 minecraft:blackstone
setblock 133 18 516 minecraft:blackstone
setblock 133 18 517 minecraft:smooth_basalt
setblock 133 18 532 minecraft:smooth_basalt
fill 133 18 533 133 21 533 minecraft:blackstone
setblock 134 18 511 minecraft:smooth_basalt
fill 134 18 512 134 21 512 minecraft:blackstone
setblock 134 18 516 minecraft:smooth_basalt
fill 134 18 517 134 21 517 minecraft:blackstone
setblock 134 18 521 minecraft:smooth_basalt
fill 134 18 522 134 21 522 minecraft:blackstone
setblock 134 18 526 minecraft:smooth_basalt
fill 134 18 527 134 19 527 minecraft:blackstone
setblock 134 18 531 minecraft:smooth_basalt
fill 134 18 532 134 21 532 minecraft:blackstone
setblock 134 18 536 minecraft:smooth_basalt
fill 134 18 537 134 21 537 minecraft:blackstone
setblock 134 18 551 minecraft:smooth_basalt
fill 135 18 511 135 21 511 minecraft:blackstone
setblock 135 18 515 minecraft:smooth_basalt
fill 135 18 516 135 21 516 minecraft:blackstone
setblock 135 18 520 minecraft:smooth_basalt
fill 135 18 521 135 21 521 minecraft:blackstone
setblock 135 18 525 minecraft:smooth_basalt
fill 135 18 526 135 21 526 minecraft:blackstone
setblock 135 18 530 minecraft:smooth_basalt
fill 135 18 531 135 21 531 minecraft:blackstone
setblock 135 18 535 minecraft:smooth_basalt
fill 135 18 536 135 21 536 minecraft:blackstone
setblock 135 18 551 minecraft:blackstone
setblock 95 19 514 minecraft:smooth_basalt
fill 95 19 515 95 22 515 minecraft:blackstone
setblock 95 19 519 minecraft:smooth_basalt
fill 95 19 520 95 22 520 minecraft:blackstone
fill 95 19 529 95 25 529 minecraft:smooth_basalt
setblock 95 19 534 minecraft:smooth_basalt
fill 95 19 535 95 22 535 minecraft:blackstone
fill 95 19 550 95 21 551 minecraft:blackstone
setblock 96 19 513 minecraft:smooth_basalt
fill 96 19 514 96 22 514 minecraft:blackstone
setblock 96 19 518 minecraft:smooth_basalt
fill 96 19 551 97 19 551 minecraft:blackstone
setblock 97 19 512 minecraft:smooth_basalt
setblock 97 19 513 minecraft:blackstone
setblock 98 19 511 minecraft:smooth_basalt
fill 98 19 512 98 22 512 minecraft:blackstone
setblock 98 19 551 minecraft:smooth_basalt
fill 99 19 511 99 22 511 minecraft:blackstone
setblock 99 19 551 minecraft:blackstone
setblock 103 19 511 minecraft:smooth_basalt
setblock 103 19 551 minecraft:smooth_basalt
fill 104 19 511 104 21 512 minecraft:blackstone
fill 104 19 551 104 22 551 minecraft:blackstone
setblock 107 19 512 minecraft:smooth_basalt
setblock 108 19 511 minecraft:smooth_basalt
fill 108 19 512 108 22 512 minecraft:blackstone
setblock 108 19 551 minecraft:smooth_basalt
fill 109 19 511 109 22 511 minecraft:blackstone
setblock 109 19 522 minecraft:shroomlight
setblock 109 19 534 minecraft:shroomlight
setblock 109 19 550 minecraft:smooth_basalt
fill 109 19 551 109 22 551 minecraft:blackstone
fill 110 19 524 111 19 524 minecraft:shroomlight
fill 110 19 532 111 19 532 minecraft:shroomlight
fill 110 19 550 110 22 550 minecraft:blackstone
setblock 111 19 525 minecraft:shroomlight
setblock 111 19 531 minecraft:shroomlight
setblock 112 19 512 minecraft:smooth_basalt
setblock 113 19 511 minecraft:smooth_basalt
fill 113 19 512 113 22 512 minecraft:blackstone
setblock 113 19 551 minecraft:smooth_basalt
fill 114 19 511 114 22 511 minecraft:blackstone
setblock 114 19 550 minecraft:smooth_basalt
fill 114 19 551 114 22 551 minecraft:blackstone
setblock 128 19 511 minecraft:smooth_basalt
fill 128 19 512 128 22 512 minecraft:blackstone
fill 129 19 511 129 22 511 minecraft:blackstone
setblock 130 19 513 minecraft:blackstone
setblock 131 19 513 minecraft:smooth_basalt
setblock 132 19 512 minecraft:smooth_basalt
fill 132 19 513 132 22 513 minecraft:blackstone
setblock 133 19 511 minecraft:smooth_basalt
fill 133 19 512 133 22 512 minecraft:blackstone
setblock 133 19 515 minecraft:blackstone
setblock 133 19 516 minecraft:smooth_basalt
fill 133 19 517 133 20 519 minecraft:blackstone
setblock 133 19 531 minecraft:smooth_basalt
fill 133 19 532 133 20 532 minecraft:blackstone
setblock 133 19 536 minecraft:smooth_basalt
setblock 133 19 551 minecraft:smooth_basalt
fill 134 19 511 134 22 511 minecraft:blackstone
setblock 134 19 515 minecraft:smooth_basalt
fill 134 19 516 134 22 516 minecraft:blackstone
setblock 134 19 520 minecraft:smooth_basalt
fill 134 19 521 134 22 521 minecraft:blackstone
fill 134 19 523 134 20 523 minecraft:blackstone
setblock 134 19 530 minecraft:smooth_basalt
fill 134 19 531 134 22 531 minecraft:blackstone
setblock 134 19 535 minecraft:smooth_basalt
fill 134 19 536 134 22 536 minecraft:blackstone
setblock 135 19 514 minecraft:smooth_basalt
fill 135 19 515 135 22 515 minecraft:blackstone
setblock 135 19 519 minecraft:smooth_basalt
fill 135 19 520 135 22 520 minecraft:blackstone
setblock 135 19 524 minecraft:smooth_basalt
fill 135 19 525 135 22 525 minecraft:blackstone
setblock 135 19 529 minecraft:smooth_basalt
fill 135 19 530 135 22 530 minecraft:blackstone
setblock 135 19 534 minecraft:smooth_basalt
fill 135 19 535 135 22 535 minecraft:blackstone
setblock 135 19 539 minecraft:smooth_basalt
setblock 95 20 513 minecraft:smooth_basalt
fill 95 20 514 95 23 514 minecraft:blackstone
setblock 95 20 518 minecraft:smooth_basalt
fill 95 20 519 95 23 519 minecraft:blackstone
fill 95 20 531 95 25 531 minecraft:smooth_basalt
setblock 95 20 533 minecraft:smooth_basalt
fill 95 20 534 95 23 534 minecraft:blackstone
setblock 95 20 538 minecraft:smooth_basalt
fill 95 20 539 95 23 539 minecraft:blackstone
setblock 96 20 512 minecraft:smooth_basalt
fill 96 20 513 96 23 513 minecraft:blackstone
setblock 96 20 517 minecraft:smooth_basalt
fill 96 20 518 96 23 518 minecraft:blackstone
setblock 96 20 551 minecraft:blackstone
setblock 97 20 511 minecraft:smooth_basalt
fill 97 20 512 97 23 512 minecraft:blackstone
setblock 97 20 551 minecraft:smooth_basalt
fill 98 20 511 98 23 511 minecraft:blackstone
setblock 98 20 551 minecraft:blackstone
setblock 102 20 511 minecraft:smooth_basalt
setblock 102 20 551 minecraft:smooth_basalt
fill 103 20 511 103 22 512 minecraft:blackstone
fill 103 20 551 103 23 551 minecraft:blackstone
setblock 106 20 512 minecraft:smooth_basalt
setblock 107 20 511 minecraft:smooth_basalt
fill 107 20 512 107 23 512 minecraft:blackstone
setblock 107 20 551 minecraft:smooth_basalt
fill 108 20 511 108 23 511 minecraft:blackstone
setblock 108 20 550 minecraft:smooth_basalt
fill 108 20 551 108 23 551 minecraft:blackstone
fill 109 20 550 109 23 550 minecraft:blackstone
setblock 110 20 524 minecraft:shroomlight
setblock 110 20 532 minecraft:shroomlight
setblock 111 20 512 minecraft:smooth_basalt
setblock 112 20 511 minecraft:smooth_basalt
fill 112 20 512 112 23 512 minecraft:blackstone
setblock 112 20 551 minecraft:smooth_basalt
fill 113 20 511 113 23 511 minecraft:blackstone
setblock 113 20 550 minecraft:smooth_basalt
fill 113 20 551 113 23 551 minecraft:blackstone
setblock 126 20 511 minecraft:blackstone
setblock 127 20 511 minecraft:smooth_basalt
fill 127 20 512 127 23 512 minecraft:blackstone
fill 128 20 511 128 23 511 minecraft:blackstone
setblock 129 20 513 minecraft:blackstone
setblock 130 20 513 minecraft:smooth_basalt
fill 130 20 551 130 21 551 minecraft:blackstone
setblock 131 20 512 minecraft:smooth_basalt
fill 131 20 513 131 23 513 minecraft:blackstone
setblock 132 20 511 minecraft:smooth_basalt
fill 132 20 512 132 23 512 minecraft:blackstone
setblock 132 20 551 minecraft:smooth_basalt
fill 133 20 511 133 23 511 minecraft:blackstone
setblock 133 20 515 minecraft:smooth_basalt
fill 133 20 516 133 23 516 minecraft:blackstone
setblock 133 20 520 minecraft:smooth_basalt
setblock 133 20 535 minecraft:smooth_basalt
fill 133 20 536 133 22 536 minecraft:blackstone
setblock 133 20 551 minecraft:blackstone
setblock 134 20 514 minecraft:smooth_basalt
fill 134 20 515 134 23 515 minecraft:blackstone
setblock 134 20 519 minecraft:smooth_basalt
fill 134 20 520 134 23 520 minecraft:blackstone
setblock 134 20 529 minecraft:smooth_basalt
fill 134 20 530 134 21 530 minecraft:blackstone
setblock 134 20 534 minecraft:smooth_basalt
fill 134 20 535 134 23 535 minecraft:blackstone
setblock 135 20 513 minecraft:smooth_basalt
fill 135 20 514 135 23 514 minecraft:blackstone
setblock 135 20 518 minecraft:smooth_basalt
fill 135 20 519 135 23 519 minecraft:blackstone
setblock 135 20 523 minecraft:smooth_basalt
fill 135 20 524 135 23 524 minecraft:blackstone
setblock 135 20 528 minecraft:smooth_basalt
fill 135 20 529 135 23 529 minecraft:blackstone
setblock 135 20 533 minecraft:smooth_basalt
fill 135 20 534 135 23 534 minecraft:blackstone
setblock 135 20 538 minecraft:smooth_basalt
fill 135 20 539 135 22 540 minecraft:blackstone
setblock 95 21 512 minecraft:smooth_basalt
fill 95 21 513 95 24 513 minecraft:blackstone
setblock 95 21 517 minecraft:smooth_basalt
fill 95 21 518 95 24 518 minecraft:blackstone
fill 95 21 522 96 21 522 minecraft:smooth_basalt
fill 95 21 532 95 24 532 minecraft:smooth_basalt
setblock 95 21 533 minecraft:blackstone
setblock 95 21 537 minecraft:smooth_basalt
fill 95 21 538 95 24 538 minecraft:blackstone
fill 95 21 540 95 22 540 minecraft:blackstone
setblock 96 21 511 minecraft:smooth_basalt
fill 96 21 512 96 24 512 minecraft:blackstone
setblock 96 21 516 minecraft:smooth_basalt
fill 96 21 517 96 24 517 minecraft:blackstone
fill 96 21 519 96 22 519 minecraft:blackstone
fill 96 21 521 96 22 521 minecraft:smooth_basalt
setblock 96 21 551 minecraft:smooth_basalt
fill 97 21 511 97 24 511 minecraft:blackstone
setblock 97 21 513 minecraft:light[level=12]
setblock 97 21 537 minecraft:light[level=12]
setblock 97 21 545 minecraft:light[level=12]
fill 97 21 551 97 24 551 minecraft:blackstone
setblock 99 21 512 minecraft:blackstone
setblock 100 21 512 minecraft:smooth_basalt
setblock 101 21 511 minecraft:smooth_basalt
setblock 101 21 551 minecraft:smooth_basalt
fill 102 21 511 102 23 512 minecraft:blackstone
fill 102 21 551 102 24 551 minecraft:blackstone
setblock 105 21 512 minecraft:smooth_basalt
setblock 105 21 513 minecraft:light[level=12]
setblock 105 21 537 minecraft:light[level=12]
setblock 105 21 545 minecraft:light[level=12]
setblock 106 21 511 minecraft:smooth_basalt
fill 106 21 512 106 24 512 minecraft:blackstone
setblock 106 21 550 minecraft:blackstone
setblock 106 21 551 minecraft:smooth_basalt
fill 107 21 511 107 24 511 minecraft:blackstone
setblock 107 21 550 minecraft:smooth_basalt
fill 107 21 551 107 24 551 minecraft:blackstone
schedule function dropper:buildpart/122_2 1t
