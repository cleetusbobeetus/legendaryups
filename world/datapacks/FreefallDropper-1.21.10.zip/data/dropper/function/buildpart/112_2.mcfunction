fill 207 241 488 208 242 489 minecraft:white_concrete
fill 207 241 490 208 242 491 minecraft:light_gray_concrete
fill 207 241 492 208 242 493 minecraft:white_concrete
fill 207 241 494 208 242 495 minecraft:light_gray_concrete
fill 207 241 496 208 242 497 minecraft:white_concrete
fill 207 241 498 208 242 499 minecraft:light_gray_concrete
fill 207 241 500 208 242 501 minecraft:white_concrete
fill 207 241 502 208 242 503 minecraft:light_gray_concrete
fill 207 241 504 208 242 504 minecraft:white_concrete
setblock 208 241 482 minecraft:light_gray_concrete
fill 209 241 464 210 242 465 minecraft:light_gray_concrete
fill 209 241 466 210 242 467 minecraft:white_concrete
fill 209 241 468 210 242 469 minecraft:light_gray_concrete
fill 209 241 470 210 242 471 minecraft:white_concrete
fill 209 241 472 210 242 473 minecraft:light_gray_concrete
fill 209 241 474 210 242 475 minecraft:white_concrete
fill 209 241 476 210 242 477 minecraft:light_gray_concrete
fill 209 241 478 210 242 479 minecraft:white_concrete
fill 209 241 480 210 241 481 minecraft:light_gray_concrete
fill 209 241 487 210 241 487 minecraft:white_concrete
fill 209 241 488 210 242 489 minecraft:light_gray_concrete
fill 209 241 490 210 242 491 minecraft:white_concrete
fill 209 241 492 210 242 493 minecraft:light_gray_concrete
fill 209 241 494 210 242 495 minecraft:white_concrete
fill 209 241 496 210 242 497 minecraft:light_gray_concrete
fill 209 241 498 210 242 499 minecraft:white_concrete
fill 209 241 500 210 242 501 minecraft:light_gray_concrete
fill 209 241 502 210 242 503 minecraft:white_concrete
fill 209 241 504 210 242 504 minecraft:light_gray_concrete
setblock 210 241 482 minecraft:white_concrete
setblock 210 241 486 minecraft:white_concrete
fill 211 241 464 212 242 465 minecraft:white_concrete
fill 211 241 466 212 242 467 minecraft:light_gray_concrete
fill 211 241 468 212 242 469 minecraft:white_concrete
fill 211 241 470 212 242 471 minecraft:light_gray_concrete
fill 211 241 472 212 242 473 minecraft:white_concrete
fill 211 241 474 212 242 475 minecraft:light_gray_concrete
fill 211 241 476 212 242 477 minecraft:white_concrete
fill 211 241 478 212 242 479 minecraft:light_gray_concrete
fill 211 241 480 212 242 481 minecraft:white_concrete
fill 211 241 482 212 241 483 minecraft:light_gray_concrete
fill 211 241 485 212 241 485 minecraft:white_concrete
fill 211 241 486 212 241 487 minecraft:light_gray_concrete
fill 211 241 488 212 242 489 minecraft:white_concrete
fill 211 241 490 212 242 491 minecraft:light_gray_concrete
fill 211 241 492 212 242 493 minecraft:white_concrete
fill 211 241 494 212 242 495 minecraft:light_gray_concrete
fill 211 241 496 212 242 497 minecraft:white_concrete
fill 211 241 498 212 242 499 minecraft:light_gray_concrete
fill 211 241 500 212 242 501 minecraft:white_concrete
fill 211 241 502 212 242 503 minecraft:light_gray_concrete
fill 211 241 504 212 242 504 minecraft:white_concrete
setblock 212 241 484 minecraft:white_concrete
fill 213 241 464 214 242 465 minecraft:light_gray_concrete
fill 213 241 466 214 242 467 minecraft:white_concrete
fill 213 241 468 214 242 469 minecraft:light_gray_concrete
fill 213 241 470 214 242 471 minecraft:white_concrete
fill 213 241 472 214 242 473 minecraft:light_gray_concrete
fill 213 241 474 214 242 475 minecraft:white_concrete
fill 213 241 476 214 242 477 minecraft:light_gray_concrete
fill 213 241 478 214 242 479 minecraft:white_concrete
fill 213 241 480 214 242 481 minecraft:light_gray_concrete
fill 213 241 482 214 242 483 minecraft:white_concrete
fill 213 241 484 214 242 485 minecraft:light_gray_concrete
fill 213 241 486 214 242 487 minecraft:white_concrete
fill 213 241 488 214 242 489 minecraft:light_gray_concrete
fill 213 241 490 214 242 491 minecraft:white_concrete
fill 213 241 492 214 242 493 minecraft:light_gray_concrete
fill 213 241 494 214 242 495 minecraft:white_concrete
fill 213 241 496 214 242 497 minecraft:light_gray_concrete
fill 213 241 498 214 242 499 minecraft:white_concrete
fill 213 241 500 214 242 501 minecraft:light_gray_concrete
fill 213 241 502 214 242 503 minecraft:white_concrete
fill 213 241 504 214 242 504 minecraft:light_gray_concrete
fill 215 241 464 216 242 465 minecraft:white_concrete
fill 215 241 466 216 242 467 minecraft:light_gray_concrete
fill 215 241 468 216 242 469 minecraft:white_concrete
fill 215 241 470 216 242 471 minecraft:light_gray_concrete
fill 215 241 472 216 242 473 minecraft:white_concrete
fill 215 241 474 216 242 475 minecraft:light_gray_concrete
fill 215 241 476 216 242 477 minecraft:white_concrete
fill 215 241 478 216 242 479 minecraft:light_gray_concrete
fill 215 241 480 216 242 481 minecraft:white_concrete
fill 215 241 482 216 242 483 minecraft:light_gray_concrete
fill 215 241 484 216 242 485 minecraft:white_concrete
fill 215 241 486 216 242 487 minecraft:light_gray_concrete
fill 215 241 488 216 242 489 minecraft:white_concrete
fill 215 241 490 216 242 491 minecraft:light_gray_concrete
fill 215 241 492 216 242 493 minecraft:white_concrete
fill 215 241 494 216 242 495 minecraft:light_gray_concrete
fill 215 241 496 216 242 497 minecraft:white_concrete
fill 215 241 498 216 242 499 minecraft:light_gray_concrete
fill 215 241 500 216 242 501 minecraft:white_concrete
fill 215 241 502 216 242 503 minecraft:light_gray_concrete
fill 215 241 504 216 242 504 minecraft:white_concrete
fill 217 241 464 218 242 465 minecraft:light_gray_concrete
fill 217 241 466 218 242 467 minecraft:white_concrete
fill 217 241 468 218 242 469 minecraft:light_gray_concrete
fill 217 241 470 218 242 471 minecraft:white_concrete
fill 217 241 472 218 242 473 minecraft:light_gray_concrete
fill 217 241 474 218 242 475 minecraft:white_concrete
fill 217 241 476 218 242 477 minecraft:light_gray_concrete
fill 217 241 478 218 242 479 minecraft:white_concrete
fill 217 241 480 218 242 481 minecraft:light_gray_concrete
fill 217 241 482 218 242 483 minecraft:white_concrete
fill 217 241 484 218 242 485 minecraft:light_gray_concrete
fill 217 241 486 218 242 487 minecraft:white_concrete
fill 217 241 488 218 242 489 minecraft:light_gray_concrete
fill 217 241 490 218 242 491 minecraft:white_concrete
fill 217 241 492 218 242 493 minecraft:light_gray_concrete
fill 217 241 494 218 242 495 minecraft:white_concrete
fill 217 241 496 218 242 497 minecraft:light_gray_concrete
fill 217 241 498 218 242 499 minecraft:white_concrete
fill 217 241 500 218 242 501 minecraft:light_gray_concrete
fill 217 241 502 218 242 503 minecraft:white_concrete
fill 217 241 504 218 242 504 minecraft:light_gray_concrete
fill 219 241 464 220 242 465 minecraft:white_concrete
fill 219 241 466 220 242 467 minecraft:light_gray_concrete
fill 219 241 468 220 242 469 minecraft:white_concrete
fill 219 241 470 220 242 471 minecraft:light_gray_concrete
fill 219 241 472 220 242 473 minecraft:white_concrete
fill 219 241 474 220 242 475 minecraft:light_gray_concrete
fill 219 241 476 220 242 477 minecraft:white_concrete
fill 219 241 478 220 242 479 minecraft:light_gray_concrete
fill 219 241 480 220 242 481 minecraft:white_concrete
fill 219 241 482 220 242 483 minecraft:light_gray_concrete
fill 219 241 484 220 242 485 minecraft:white_concrete
fill 219 241 486 220 242 487 minecraft:light_gray_concrete
fill 219 241 488 220 242 489 minecraft:white_concrete
fill 219 241 490 220 242 491 minecraft:light_gray_concrete
fill 219 241 492 220 242 493 minecraft:white_concrete
fill 219 241 494 220 242 495 minecraft:light_gray_concrete
fill 219 241 496 220 242 497 minecraft:white_concrete
fill 219 241 498 220 242 499 minecraft:light_gray_concrete
fill 219 241 500 220 242 501 minecraft:white_concrete
fill 219 241 502 220 242 503 minecraft:light_gray_concrete
fill 219 241 504 220 242 504 minecraft:white_concrete
fill 221 241 464 222 242 465 minecraft:light_gray_concrete
fill 221 241 466 222 242 467 minecraft:white_concrete
fill 221 241 468 222 242 469 minecraft:light_gray_concrete
fill 221 241 470 222 242 471 minecraft:white_concrete
fill 221 241 472 222 242 473 minecraft:light_gray_concrete
fill 221 241 474 222 242 475 minecraft:white_concrete
fill 221 241 476 222 242 477 minecraft:light_gray_concrete
fill 221 241 478 222 242 479 minecraft:white_concrete
fill 221 241 480 222 242 481 minecraft:light_gray_concrete
fill 221 241 482 222 242 483 minecraft:white_concrete
fill 221 241 484 222 242 485 minecraft:light_gray_concrete
fill 221 241 486 222 242 487 minecraft:white_concrete
fill 221 241 488 222 242 489 minecraft:light_gray_concrete
fill 221 241 490 222 242 491 minecraft:white_concrete
fill 221 241 492 222 242 493 minecraft:light_gray_concrete
fill 221 241 494 222 242 495 minecraft:white_concrete
fill 221 241 496 222 242 497 minecraft:light_gray_concrete
fill 221 241 498 222 242 499 minecraft:white_concrete
fill 221 241 500 222 242 501 minecraft:light_gray_concrete
fill 221 241 502 222 242 503 minecraft:white_concrete
fill 221 241 504 222 242 504 minecraft:light_gray_concrete
fill 223 241 464 224 242 465 minecraft:white_concrete
fill 223 241 466 224 242 467 minecraft:light_gray_concrete
fill 223 241 468 224 242 469 minecraft:white_concrete
fill 223 241 470 224 242 471 minecraft:light_gray_concrete
fill 223 241 472 224 242 473 minecraft:white_concrete
fill 223 241 474 224 242 475 minecraft:light_gray_concrete
fill 223 241 476 224 242 477 minecraft:white_concrete
fill 223 241 478 224 242 479 minecraft:light_gray_concrete
fill 223 241 480 224 242 481 minecraft:white_concrete
fill 223 241 482 224 242 483 minecraft:light_gray_concrete
fill 223 241 484 224 242 485 minecraft:white_concrete
fill 223 241 486 224 242 487 minecraft:light_gray_concrete
fill 223 241 488 224 242 489 minecraft:white_concrete
fill 223 241 490 224 242 491 minecraft:light_gray_concrete
fill 223 241 492 224 242 493 minecraft:white_concrete
fill 223 241 494 224 242 495 minecraft:light_gray_concrete
fill 223 241 496 224 242 497 minecraft:white_concrete
fill 223 241 498 224 242 499 minecraft:light_gray_concrete
fill 223 241 500 224 242 501 minecraft:white_concrete
fill 223 241 502 224 242 503 minecraft:light_gray_concrete
fill 223 241 504 224 242 504 minecraft:white_concrete
fill 225 241 464 226 242 465 minecraft:light_gray_concrete
fill 225 241 466 226 242 467 minecraft:white_concrete
fill 225 241 468 226 242 469 minecraft:light_gray_concrete
fill 225 241 470 226 242 471 minecraft:white_concrete
fill 225 241 472 226 242 473 minecraft:light_gray_concrete
fill 225 241 474 226 242 475 minecraft:white_concrete
fill 225 241 476 226 242 477 minecraft:light_gray_concrete
fill 225 241 478 226 242 479 minecraft:white_concrete
fill 225 241 480 226 242 481 minecraft:light_gray_concrete
fill 225 241 482 226 242 483 minecraft:white_concrete
fill 225 241 484 226 242 485 minecraft:light_gray_concrete
fill 225 241 486 226 242 487 minecraft:white_concrete
fill 225 241 488 226 242 489 minecraft:light_gray_concrete
fill 225 241 490 226 242 491 minecraft:white_concrete
fill 225 241 492 226 242 493 minecraft:light_gray_concrete
fill 225 241 494 226 242 495 minecraft:white_concrete
fill 225 241 496 226 242 497 minecraft:light_gray_concrete
fill 225 241 498 226 242 499 minecraft:white_concrete
fill 225 241 500 226 242 501 minecraft:light_gray_concrete
fill 225 241 502 226 242 503 minecraft:white_concrete
fill 225 241 504 226 242 504 minecraft:light_gray_concrete
fill 227 241 464 228 242 465 minecraft:white_concrete
fill 227 241 466 228 242 467 minecraft:light_gray_concrete
fill 227 241 468 228 242 469 minecraft:white_concrete
fill 227 241 470 228 242 471 minecraft:light_gray_concrete
fill 227 241 472 228 242 473 minecraft:white_concrete
fill 227 241 474 228 242 475 minecraft:light_gray_concrete
fill 227 241 476 228 242 477 minecraft:white_concrete
fill 227 241 478 228 242 479 minecraft:light_gray_concrete
fill 227 241 480 228 242 481 minecraft:white_concrete
fill 227 241 482 228 242 483 minecraft:light_gray_concrete
fill 227 241 484 228 242 485 minecraft:white_concrete
fill 227 241 486 228 242 487 minecraft:light_gray_concrete
fill 227 241 488 228 242 489 minecraft:white_concrete
fill 227 241 490 228 242 491 minecraft:light_gray_concrete
fill 227 241 492 228 242 493 minecraft:white_concrete
fill 227 241 494 228 242 495 minecraft:light_gray_concrete
fill 227 241 496 228 242 497 minecraft:white_concrete
fill 227 241 498 228 242 499 minecraft:light_gray_concrete
fill 227 241 500 228 242 501 minecraft:white_concrete
fill 227 241 502 228 242 503 minecraft:light_gray_concrete
fill 227 241 504 228 242 504 minecraft:white_concrete
fill 229 241 464 229 242 465 minecraft:light_gray_concrete
fill 229 241 466 229 242 467 minecraft:white_concrete
fill 229 241 468 229 242 469 minecraft:light_gray_concrete
fill 229 241 470 229 242 471 minecraft:white_concrete
fill 229 241 472 229 242 473 minecraft:light_gray_concrete
fill 229 241 474 229 242 475 minecraft:white_concrete
fill 229 241 476 229 242 477 minecraft:light_gray_concrete
fill 229 241 478 229 242 479 minecraft:white_concrete
fill 229 241 480 229 242 481 minecraft:light_gray_concrete
fill 229 241 482 229 242 483 minecraft:white_concrete
fill 229 241 484 229 242 485 minecraft:light_gray_concrete
fill 229 241 486 229 242 487 minecraft:white_concrete
fill 229 241 488 229 242 489 minecraft:light_gray_concrete
fill 229 241 490 229 242 491 minecraft:white_concrete
fill 229 241 492 229 242 493 minecraft:light_gray_concrete
fill 229 241 494 229 242 495 minecraft:white_concrete
fill 229 241 496 229 242 497 minecraft:light_gray_concrete
fill 229 241 498 229 242 499 minecraft:white_concrete
fill 229 241 500 229 242 501 minecraft:light_gray_concrete
fill 229 241 502 229 242 503 minecraft:white_concrete
fill 229 241 504 229 242 504 minecraft:light_gray_concrete
fill 205 242 482 205 242 483 minecraft:white_concrete
fill 205 242 484 205 242 485 minecraft:light_gray_concrete
setblock 206 242 482 minecraft:white_concrete
fill 206 242 483 206 242 485 minecraft:pearlescent_froglight
fill 207 242 480 207 242 481 minecraft:white_concrete
fill 207 242 482 207 242 483 minecraft:pearlescent_froglight
fill 207 242 485 207 242 486 minecraft:pearlescent_froglight
setblock 207 242 487 minecraft:light_gray_concrete
setblock 208 242 480 minecraft:white_concrete
fill 208 242 481 208 242 482 minecraft:pearlescent_froglight
fill 208 242 486 208 242 487 minecraft:pearlescent_froglight
fill 209 242 480 210 242 480 minecraft:light_gray_concrete
fill 209 242 481 210 242 481 minecraft:pearlescent_froglight
fill 209 242 487 210 242 487 minecraft:pearlescent_froglight
fill 210 242 482 211 242 482 minecraft:pearlescent_froglight
fill 210 242 486 211 242 486 minecraft:pearlescent_froglight
fill 211 242 483 212 242 483 minecraft:pearlescent_froglight
fill 211 242 485 212 242 485 minecraft:pearlescent_froglight
fill 211 242 487 212 242 487 minecraft:light_gray_concrete
setblock 212 242 482 minecraft:light_gray_concrete
setblock 212 242 484 minecraft:pearlescent_froglight
setblock 212 242 486 minecraft:light_gray_concrete
setblock 191 244 466 minecraft:light[level=11]
setblock 191 244 474 minecraft:light[level=11]
setblock 191 244 482 minecraft:light[level=11]
setblock 191 244 490 minecraft:light[level=11]
setblock 191 244 498 minecraft:light[level=11]
setblock 199 244 466 minecraft:light[level=11]
setblock 199 244 474 minecraft:light[level=11]
setblock 199 244 482 minecraft:light[level=11]
setblock 199 244 490 minecraft:light[level=11]
setblock 199 244 498 minecraft:light[level=11]
setblock 207 244 466 minecraft:light[level=11]
setblock 207 244 474 minecraft:light[level=11]
setblock 207 244 482 minecraft:light[level=11]
setblock 207 244 490 minecraft:light[level=11]
setblock 207 244 498 minecraft:light[level=11]
setblock 215 244 466 minecraft:light[level=11]
setblock 215 244 474 minecraft:light[level=11]
setblock 215 244 482 minecraft:light[level=11]
setblock 215 244 490 minecraft:light[level=11]
setblock 215 244 498 minecraft:light[level=11]
setblock 223 244 466 minecraft:light[level=11]
setblock 223 244 474 minecraft:light[level=11]
setblock 223 244 482 minecraft:light[level=11]
setblock 223 244 490 minecraft:light[level=11]
setblock 223 244 498 minecraft:light[level=11]
fill 188 246 468 188 247 468 minecraft:pearlescent_froglight
fill 188 246 476 188 247 476 minecraft:pearlescent_froglight
fill 188 246 484 188 247 484 minecraft:pearlescent_froglight
fill 188 246 492 188 247 492 minecraft:pearlescent_froglight
fill 188 246 500 188 247 500 minecraft:pearlescent_froglight
fill 189 246 470 189 273 471 minecraft:light_gray_concrete
fill 189 246 478 189 273 479 minecraft:light_gray_concrete
fill 189 246 486 189 273 487 minecraft:light_gray_concrete
fill 189 246 494 189 273 495 minecraft:light_gray_concrete
fill 189 246 502 189 273 503 minecraft:light_gray_concrete
fill 190 246 464 191 273 464 minecraft:light_gray_concrete
fill 191 246 505 191 247 505 minecraft:pearlescent_froglight
fill 192 246 487 193 247 488 minecraft:white_wool
fill 195 246 463 195 247 463 minecraft:pearlescent_froglight
fill 195 246 504 196 273 504 minecraft:light_gray_concrete
fill 198 246 464 199 273 464 minecraft:light_gray_concrete
fill 199 246 505 199 247 505 minecraft:pearlescent_froglight
fill 203 246 463 203 247 463 minecraft:pearlescent_froglight
fill 203 246 497 213 246 504 minecraft:light_gray_concrete
fill 206 246 464 207 273 464 minecraft:light_gray_concrete
fill 207 246 505 207 247 505 minecraft:pearlescent_froglight
fill 211 246 463 211 247 463 minecraft:pearlescent_froglight
fill 214 246 464 215 273 464 minecraft:light_gray_concrete
fill 215 246 505 215 247 505 minecraft:pearlescent_froglight
fill 219 246 463 219 247 463 minecraft:pearlescent_froglight
fill 219 246 479 229 246 487 minecraft:light_gray_concrete
fill 219 246 504 220 273 504 minecraft:light_gray_concrete
fill 222 246 464 223 273 464 minecraft:light_gray_concrete
fill 223 246 505 223 247 505 minecraft:pearlescent_froglight
fill 227 246 463 227 247 463 minecraft:pearlescent_froglight
fill 227 246 504 228 273 504 minecraft:light_gray_concrete
fill 229 246 465 229 273 466 minecraft:light_gray_concrete
fill 229 246 473 229 273 474 minecraft:light_gray_concrete
fill 229 246 489 229 273 490 minecraft:light_gray_concrete
fill 229 246 497 229 273 498 minecraft:light_gray_concrete
fill 230 246 468 230 247 468 minecraft:pearlescent_froglight
fill 230 246 476 230 247 476 minecraft:pearlescent_froglight
fill 230 246 484 230 247 484 minecraft:pearlescent_froglight
fill 230 246 492 230 247 492 minecraft:pearlescent_froglight
fill 230 246 500 230 247 500 minecraft:pearlescent_froglight
fill 202 247 502 202 248 502 minecraft:iron_block
fill 203 247 497 203 262 497 minecraft:light_gray_concrete
setblock 203 247 498 minecraft:pearlescent_froglight
fill 203 247 499 203 262 499 minecraft:light_gray_concrete
setblock 203 247 500 minecraft:pearlescent_froglight
fill 203 247 501 203 262 501 minecraft:light_gray_concrete
setblock 203 247 502 minecraft:pearlescent_froglight
fill 203 247 503 203 262 503 minecraft:light_gray_concrete
setblock 203 247 504 minecraft:pearlescent_froglight
setblock 204 247 497 minecraft:pearlescent_froglight
fill 204 247 498 204 262 498 minecraft:light_gray_concrete
setblock 204 247 499 minecraft:pearlescent_froglight
fill 204 247 500 204 262 500 minecraft:light_gray_concrete
setblock 204 247 501 minecraft:pearlescent_froglight
fill 204 247 502 204 262 502 minecraft:light_gray_concrete
setblock 204 247 503 minecraft:pearlescent_froglight
fill 204 247 504 204 273 504 minecraft:light_gray_concrete
fill 205 247 497 205 262 497 minecraft:light_gray_concrete
setblock 205 247 498 minecraft:pearlescent_froglight
fill 205 247 499 205 262 499 minecraft:light_gray_concrete
setblock 205 247 500 minecraft:pearlescent_froglight
fill 205 247 501 205 262 501 minecraft:light_gray_concrete
setblock 205 247 502 minecraft:pearlescent_froglight
fill 205 247 503 205 262 503 minecraft:light_gray_concrete
setblock 205 247 504 minecraft:pearlescent_froglight
setblock 206 247 497 minecraft:pearlescent_froglight
fill 206 247 498 206 262 498 minecraft:light_gray_concrete
setblock 206 247 499 minecraft:pearlescent_froglight
fill 206 247 500 206 262 500 minecraft:light_gray_concrete
setblock 206 247 501 minecraft:pearlescent_froglight
fill 206 247 502 206 262 502 minecraft:light_gray_concrete
setblock 206 247 503 minecraft:pearlescent_froglight
fill 206 247 504 206 262 504 minecraft:light_gray_concrete
fill 207 247 497 207 262 497 minecraft:light_gray_concrete
setblock 207 247 498 minecraft:pearlescent_froglight
fill 207 247 499 207 262 499 minecraft:light_gray_concrete
setblock 207 247 500 minecraft:pearlescent_froglight
fill 207 247 501 207 262 501 minecraft:light_gray_concrete
setblock 207 247 502 minecraft:pearlescent_froglight
fill 207 247 503 207 262 503 minecraft:light_gray_concrete
setblock 207 247 504 minecraft:pearlescent_froglight
setblock 208 247 497 minecraft:pearlescent_froglight
fill 208 247 498 208 262 498 minecraft:light_gray_concrete
setblock 208 247 499 minecraft:pearlescent_froglight
fill 208 247 500 208 262 500 minecraft:light_gray_concrete
setblock 208 247 501 minecraft:pearlescent_froglight
fill 208 247 502 208 262 502 minecraft:light_gray_concrete
setblock 208 247 503 minecraft:pearlescent_froglight
fill 208 247 504 208 262 504 minecraft:light_gray_concrete
fill 209 247 497 209 262 497 minecraft:light_gray_concrete
setblock 209 247 498 minecraft:pearlescent_froglight
fill 209 247 499 209 262 499 minecraft:light_gray_concrete
setblock 209 247 500 minecraft:pearlescent_froglight
fill 209 247 501 209 262 501 minecraft:light_gray_concrete
setblock 209 247 502 minecraft:pearlescent_froglight
fill 209 247 503 209 262 503 minecraft:light_gray_concrete
setblock 209 247 504 minecraft:pearlescent_froglight
setblock 210 247 497 minecraft:pearlescent_froglight
fill 210 247 498 210 262 498 minecraft:light_gray_concrete
setblock 210 247 499 minecraft:pearlescent_froglight
fill 210 247 500 210 262 500 minecraft:light_gray_concrete
setblock 210 247 501 minecraft:pearlescent_froglight
fill 210 247 502 210 262 502 minecraft:light_gray_concrete
setblock 210 247 503 minecraft:pearlescent_froglight
fill 210 247 504 210 262 504 minecraft:light_gray_concrete
fill 211 247 497 211 262 497 minecraft:light_gray_concrete
setblock 211 247 498 minecraft:pearlescent_froglight
fill 211 247 499 211 262 499 minecraft:light_gray_concrete
setblock 211 247 500 minecraft:pearlescent_froglight
fill 211 247 501 211 262 501 minecraft:light_gray_concrete
setblock 211 247 502 minecraft:pearlescent_froglight
fill 211 247 503 211 262 503 minecraft:light_gray_concrete
setblock 211 247 504 minecraft:pearlescent_froglight
setblock 212 247 497 minecraft:pearlescent_froglight
fill 212 247 498 212 262 498 minecraft:light_gray_concrete
setblock 212 247 499 minecraft:pearlescent_froglight
fill 212 247 500 212 262 500 minecraft:light_gray_concrete
setblock 212 247 501 minecraft:pearlescent_froglight
fill 212 247 502 212 262 502 minecraft:light_gray_concrete
setblock 212 247 503 minecraft:pearlescent_froglight
fill 212 247 504 212 273 504 minecraft:light_gray_concrete
fill 213 247 497 213 262 497 minecraft:light_gray_concrete
setblock 213 247 498 minecraft:pearlescent_froglight
fill 213 247 499 213 262 499 minecraft:light_gray_concrete
setblock 213 247 500 minecraft:pearlescent_froglight
fill 213 247 501 213 262 501 minecraft:light_gray_concrete
setblock 213 247 502 minecraft:pearlescent_froglight
fill 213 247 503 213 262 503 minecraft:light_gray_concrete
setblock 213 247 504 minecraft:pearlescent_froglight
fill 219 247 479 219 264 479 minecraft:light_gray_concrete
setblock 219 247 480 minecraft:pearlescent_froglight
fill 219 247 481 219 264 481 minecraft:light_gray_concrete
setblock 219 247 482 minecraft:pearlescent_froglight
fill 219 247 483 219 264 483 minecraft:light_gray_concrete
setblock 219 247 484 minecraft:pearlescent_froglight
fill 219 247 485 219 264 485 minecraft:light_gray_concrete
setblock 219 247 486 minecraft:pearlescent_froglight
fill 219 247 487 219 264 487 minecraft:light_gray_concrete
setblock 220 247 479 minecraft:pearlescent_froglight
fill 220 247 480 220 264 480 minecraft:light_gray_concrete
setblock 220 247 481 minecraft:pearlescent_froglight
fill 220 247 482 220 264 482 minecraft:light_gray_concrete
setblock 220 247 483 minecraft:pearlescent_froglight
fill 220 247 484 220 264 484 minecraft:light_gray_concrete
setblock 220 247 485 minecraft:pearlescent_froglight
fill 220 247 486 220 264 486 minecraft:light_gray_concrete
setblock 220 247 487 minecraft:pearlescent_froglight
fill 221 247 479 221 264 479 minecraft:light_gray_concrete
setblock 221 247 480 minecraft:pearlescent_froglight
fill 221 247 481 221 264 481 minecraft:light_gray_concrete
setblock 221 247 482 minecraft:pearlescent_froglight
fill 221 247 483 221 264 483 minecraft:light_gray_concrete
setblock 221 247 484 minecraft:pearlescent_froglight
fill 221 247 485 221 264 485 minecraft:light_gray_concrete
setblock 221 247 486 minecraft:pearlescent_froglight
fill 221 247 487 221 264 487 minecraft:light_gray_concrete
setblock 222 247 479 minecraft:pearlescent_froglight
fill 222 247 480 222 264 480 minecraft:light_gray_concrete
setblock 222 247 481 minecraft:pearlescent_froglight
fill 222 247 482 222 264 482 minecraft:light_gray_concrete
setblock 222 247 483 minecraft:pearlescent_froglight
fill 222 247 484 222 264 484 minecraft:light_gray_concrete
setblock 222 247 485 minecraft:pearlescent_froglight
fill 222 247 486 222 264 486 minecraft:light_gray_concrete
setblock 222 247 487 minecraft:pearlescent_froglight
fill 223 247 479 223 264 479 minecraft:light_gray_concrete
setblock 223 247 480 minecraft:pearlescent_froglight
fill 223 247 481 223 264 481 minecraft:light_gray_concrete
setblock 223 247 482 minecraft:pearlescent_froglight
fill 223 247 483 223 264 483 minecraft:light_gray_concrete
setblock 223 247 484 minecraft:pearlescent_froglight
fill 223 247 485 223 264 485 minecraft:light_gray_concrete
setblock 223 247 486 minecraft:pearlescent_froglight
fill 223 247 487 223 264 487 minecraft:light_gray_concrete
setblock 224 247 479 minecraft:pearlescent_froglight
fill 224 247 480 224 264 480 minecraft:light_gray_concrete
setblock 224 247 481 minecraft:pearlescent_froglight
fill 224 247 482 224 264 482 minecraft:light_gray_concrete
setblock 224 247 483 minecraft:pearlescent_froglight
fill 224 247 484 224 264 484 minecraft:light_gray_concrete
setblock 224 247 485 minecraft:pearlescent_froglight
fill 224 247 486 224 264 486 minecraft:light_gray_concrete
setblock 224 247 487 minecraft:pearlescent_froglight
fill 225 247 479 225 264 479 minecraft:light_gray_concrete
setblock 225 247 480 minecraft:pearlescent_froglight
fill 225 247 481 225 264 481 minecraft:light_gray_concrete
setblock 225 247 482 minecraft:pearlescent_froglight
fill 225 247 483 225 264 483 minecraft:light_gray_concrete
setblock 225 247 484 minecraft:pearlescent_froglight
fill 225 247 485 225 264 485 minecraft:light_gray_concrete
setblock 225 247 486 minecraft:pearlescent_froglight
fill 225 247 487 225 264 487 minecraft:light_gray_concrete
setblock 226 247 479 minecraft:pearlescent_froglight
fill 226 247 480 226 264 480 minecraft:light_gray_concrete
setblock 226 247 481 minecraft:pearlescent_froglight
fill 226 247 482 226 264 482 minecraft:light_gray_concrete
setblock 226 247 483 minecraft:pearlescent_froglight
fill 226 247 484 226 264 484 minecraft:light_gray_concrete
setblock 226 247 485 minecraft:pearlescent_froglight
fill 226 247 486 226 264 486 minecraft:light_gray_concrete
setblock 226 247 487 minecraft:pearlescent_froglight
fill 227 247 479 227 264 479 minecraft:light_gray_concrete
setblock 227 247 480 minecraft:pearlescent_froglight
fill 227 247 481 227 264 481 minecraft:light_gray_concrete
setblock 227 247 482 minecraft:pearlescent_froglight
fill 227 247 483 227 264 483 minecraft:light_gray_concrete
setblock 227 247 484 minecraft:pearlescent_froglight
fill 227 247 485 227 264 485 minecraft:light_gray_concrete
setblock 227 247 486 minecraft:pearlescent_froglight
fill 227 247 487 227 264 487 minecraft:light_gray_concrete
setblock 228 247 479 minecraft:pearlescent_froglight
fill 228 247 480 228 264 480 minecraft:light_gray_concrete
setblock 228 247 481 minecraft:pearlescent_froglight
fill 228 247 482 228 264 482 minecraft:light_gray_concrete
setblock 228 247 483 minecraft:pearlescent_froglight
fill 228 247 484 228 264 484 minecraft:light_gray_concrete
setblock 228 247 485 minecraft:pearlescent_froglight
fill 228 247 486 228 264 486 minecraft:light_gray_concrete
setblock 228 247 487 minecraft:pearlescent_froglight
fill 229 247 479 229 264 479 minecraft:light_gray_concrete
setblock 229 247 480 minecraft:pearlescent_froglight
fill 229 247 481 229 273 481 minecraft:light_gray_concrete
setblock 229 247 482 minecraft:pearlescent_froglight
fill 229 247 483 229 264 483 minecraft:light_gray_concrete
setblock 229 247 484 minecraft:pearlescent_froglight
fill 229 247 485 229 264 485 minecraft:light_gray_concrete
setblock 229 247 486 minecraft:pearlescent_froglight
fill 229 247 487 229 264 487 minecraft:light_gray_concrete
fill 188 248 468 188 255 468 minecraft:white_terracotta
fill 188 248 476 188 255 476 minecraft:white_terracotta
fill 188 248 484 188 255 484 minecraft:white_terracotta
fill 188 248 492 188 255 492 minecraft:white_terracotta
fill 188 248 500 188 255 500 minecraft:white_terracotta
fill 191 248 505 191 255 505 minecraft:white_terracotta
fill 195 248 463 195 255 463 minecraft:white_terracotta
fill 199 248 505 199 255 505 minecraft:white_terracotta
fill 203 248 463 203 255 463 minecraft:white_terracotta
fill 203 248 498 203 249 498 minecraft:light_gray_concrete
fill 203 248 500 203 249 500 minecraft:light_gray_concrete
fill 203 248 502 203 249 502 minecraft:light_gray_concrete
fill 203 248 504 203 249 504 minecraft:light_gray_concrete
fill 204 248 497 204 249 497 minecraft:light_gray_concrete
fill 204 248 499 204 249 499 minecraft:light_gray_concrete
fill 204 248 501 204 249 501 minecraft:light_gray_concrete
fill 204 248 503 204 249 503 minecraft:light_gray_concrete
fill 205 248 498 205 249 498 minecraft:light_gray_concrete
fill 205 248 500 205 249 500 minecraft:light_gray_concrete
fill 205 248 502 205 249 502 minecraft:light_gray_concrete
fill 205 248 504 205 249 504 minecraft:light_gray_concrete
fill 206 248 497 206 249 497 minecraft:light_gray_concrete
fill 206 248 499 206 249 499 minecraft:light_gray_concrete
fill 206 248 501 206 249 501 minecraft:light_gray_concrete
fill 206 248 503 206 249 503 minecraft:light_gray_concrete
fill 207 248 498 207 249 498 minecraft:light_gray_concrete
fill 207 248 500 207 249 500 minecraft:light_gray_concrete
fill 207 248 502 207 249 502 minecraft:light_gray_concrete
fill 207 248 504 207 249 504 minecraft:light_gray_concrete
fill 207 248 505 207 255 505 minecraft:white_terracotta
fill 208 248 497 208 249 497 minecraft:light_gray_concrete
fill 208 248 499 208 249 499 minecraft:light_gray_concrete
fill 208 248 501 208 249 501 minecraft:light_gray_concrete
fill 208 248 503 208 249 503 minecraft:light_gray_concrete
fill 209 248 498 209 249 498 minecraft:light_gray_concrete
fill 209 248 500 209 249 500 minecraft:light_gray_concrete
fill 209 248 502 209 249 502 minecraft:light_gray_concrete
fill 209 248 504 209 249 504 minecraft:light_gray_concrete
fill 210 248 497 210 249 497 minecraft:light_gray_concrete
fill 210 248 499 210 249 499 minecraft:light_gray_concrete
fill 210 248 501 210 249 501 minecraft:light_gray_concrete
fill 210 248 503 210 249 503 minecraft:light_gray_concrete
fill 211 248 463 211 255 463 minecraft:white_terracotta
fill 211 248 498 211 249 498 minecraft:light_gray_concrete
fill 211 248 500 211 249 500 minecraft:light_gray_concrete
fill 211 248 502 211 249 502 minecraft:light_gray_concrete
fill 211 248 504 211 249 504 minecraft:light_gray_concrete
fill 212 248 497 212 249 497 minecraft:light_gray_concrete
fill 212 248 499 212 249 499 minecraft:light_gray_concrete
fill 212 248 501 212 249 501 minecraft:light_gray_concrete
fill 212 248 503 212 249 503 minecraft:light_gray_concrete
fill 213 248 498 213 249 498 minecraft:light_gray_concrete
fill 213 248 500 213 249 500 minecraft:light_gray_concrete
fill 213 248 502 213 249 502 minecraft:light_gray_concrete
fill 213 248 504 213 249 504 minecraft:light_gray_concrete
fill 215 248 505 215 255 505 minecraft:white_terracotta
fill 219 248 463 219 255 463 minecraft:white_terracotta
fill 219 248 480 219 249 480 minecraft:light_gray_concrete
fill 219 248 482 219 249 482 minecraft:light_gray_concrete
fill 219 248 484 219 249 484 minecraft:light_gray_concrete
fill 219 248 486 219 249 486 minecraft:light_gray_concrete
fill 220 248 479 220 249 479 minecraft:light_gray_concrete
fill 220 248 481 220 249 481 minecraft:light_gray_concrete
fill 220 248 483 220 249 483 minecraft:light_gray_concrete
fill 220 248 485 220 249 485 minecraft:light_gray_concrete
fill 220 248 487 220 249 487 minecraft:light_gray_concrete
fill 221 248 480 221 249 480 minecraft:light_gray_concrete
fill 221 248 482 221 249 482 minecraft:light_gray_concrete
fill 221 248 484 221 249 484 minecraft:light_gray_concrete
fill 221 248 486 221 249 486 minecraft:light_gray_concrete
fill 222 248 479 222 249 479 minecraft:light_gray_concrete
fill 222 248 481 222 249 481 minecraft:light_gray_concrete
fill 222 248 483 222 249 483 minecraft:light_gray_concrete
fill 222 248 485 222 249 485 minecraft:light_gray_concrete
fill 222 248 487 222 249 487 minecraft:light_gray_concrete
fill 223 248 480 223 249 480 minecraft:light_gray_concrete
fill 223 248 482 223 249 482 minecraft:light_gray_concrete
fill 223 248 484 223 249 484 minecraft:light_gray_concrete
fill 223 248 486 223 249 486 minecraft:light_gray_concrete
fill 223 248 505 223 255 505 minecraft:white_terracotta
fill 224 248 479 224 249 479 minecraft:light_gray_concrete
fill 224 248 481 224 249 481 minecraft:light_gray_concrete
fill 224 248 483 224 249 483 minecraft:light_gray_concrete
fill 224 248 485 224 249 485 minecraft:light_gray_concrete
fill 224 248 487 224 249 487 minecraft:light_gray_concrete
fill 225 248 480 225 249 480 minecraft:light_gray_concrete
fill 225 248 482 225 249 482 minecraft:light_gray_concrete
fill 225 248 484 225 249 484 minecraft:light_gray_concrete
fill 225 248 486 225 249 486 minecraft:light_gray_concrete
fill 226 248 479 226 249 479 minecraft:light_gray_concrete
fill 226 248 481 226 249 481 minecraft:light_gray_concrete
fill 226 248 483 226 249 483 minecraft:light_gray_concrete
fill 226 248 485 226 249 485 minecraft:light_gray_concrete
fill 226 248 487 226 249 487 minecraft:light_gray_concrete
fill 227 248 463 227 255 463 minecraft:white_terracotta
fill 227 248 480 227 249 480 minecraft:light_gray_concrete
fill 227 248 482 227 249 482 minecraft:light_gray_concrete
fill 227 248 484 227 249 484 minecraft:light_gray_concrete
fill 227 248 486 227 249 486 minecraft:light_gray_concrete
fill 228 248 479 228 249 479 minecraft:light_gray_concrete
fill 228 248 481 228 249 481 minecraft:light_gray_concrete
fill 228 248 483 228 249 483 minecraft:light_gray_concrete
fill 228 248 485 228 249 485 minecraft:light_gray_concrete
fill 228 248 487 228 249 487 minecraft:light_gray_concrete
fill 229 248 480 229 249 480 minecraft:light_gray_concrete
fill 229 248 482 229 249 482 minecraft:light_gray_concrete
fill 229 248 484 229 249 484 minecraft:light_gray_concrete
fill 229 248 486 229 249 486 minecraft:light_gray_concrete
fill 230 248 468 230 255 468 minecraft:white_terracotta
fill 230 248 476 230 255 476 minecraft:white_terracotta
fill 230 248 484 230 255 484 minecraft:white_terracotta
fill 230 248 492 230 255 492 minecraft:white_terracotta
fill 230 248 500 230 255 500 minecraft:white_terracotta
setblock 203 250 498 minecraft:pearlescent_froglight
setblock 203 250 500 minecraft:pearlescent_froglight
setblock 203 250 502 minecraft:pearlescent_froglight
setblock 203 250 504 minecraft:pearlescent_froglight
setblock 204 250 497 minecraft:pearlescent_froglight
setblock 204 250 499 minecraft:pearlescent_froglight
setblock 204 250 501 minecraft:pearlescent_froglight
setblock 204 250 503 minecraft:pearlescent_froglight
setblock 205 250 498 minecraft:pearlescent_froglight
setblock 205 250 500 minecraft:pearlescent_froglight
setblock 205 250 502 minecraft:pearlescent_froglight
setblock 205 250 504 minecraft:pearlescent_froglight
setblock 206 250 497 minecraft:pearlescent_froglight
setblock 206 250 499 minecraft:pearlescent_froglight
setblock 206 250 501 minecraft:pearlescent_froglight
setblock 206 250 503 minecraft:pearlescent_froglight
setblock 207 250 498 minecraft:pearlescent_froglight
setblock 207 250 500 minecraft:pearlescent_froglight
setblock 207 250 502 minecraft:pearlescent_froglight
setblock 207 250 504 minecraft:pearlescent_froglight
setblock 208 250 497 minecraft:pearlescent_froglight
setblock 208 250 499 minecraft:pearlescent_froglight
setblock 208 250 501 minecraft:pearlescent_froglight
setblock 208 250 503 minecraft:pearlescent_froglight
setblock 209 250 498 minecraft:pearlescent_froglight
setblock 209 250 500 minecraft:pearlescent_froglight
setblock 209 250 502 minecraft:pearlescent_froglight
setblock 209 250 504 minecraft:pearlescent_froglight
setblock 210 250 497 minecraft:pearlescent_froglight
setblock 210 250 499 minecraft:pearlescent_froglight
setblock 210 250 501 minecraft:pearlescent_froglight
setblock 210 250 503 minecraft:pearlescent_froglight
setblock 211 250 498 minecraft:pearlescent_froglight
setblock 211 250 500 minecraft:pearlescent_froglight
setblock 211 250 502 minecraft:pearlescent_froglight
setblock 211 250 504 minecraft:pearlescent_froglight
setblock 212 250 497 minecraft:pearlescent_froglight
setblock 212 250 499 minecraft:pearlescent_froglight
setblock 212 250 501 minecraft:pearlescent_froglight
setblock 212 250 503 minecraft:pearlescent_froglight
setblock 213 250 498 minecraft:pearlescent_froglight
setblock 213 250 500 minecraft:pearlescent_froglight
setblock 213 250 502 minecraft:pearlescent_froglight
setblock 213 250 504 minecraft:pearlescent_froglight
setblock 219 250 480 minecraft:pearlescent_froglight
setblock 219 250 482 minecraft:pearlescent_froglight
setblock 219 250 484 minecraft:pearlescent_froglight
setblock 219 250 486 minecraft:pearlescent_froglight
setblock 220 250 479 minecraft:pearlescent_froglight
setblock 220 250 481 minecraft:pearlescent_froglight
setblock 220 250 483 minecraft:pearlescent_froglight
setblock 220 250 485 minecraft:pearlescent_froglight
setblock 220 250 487 minecraft:pearlescent_froglight
setblock 221 250 480 minecraft:pearlescent_froglight
setblock 221 250 482 minecraft:pearlescent_froglight
setblock 221 250 484 minecraft:pearlescent_froglight
setblock 221 250 486 minecraft:pearlescent_froglight
setblock 222 250 479 minecraft:pearlescent_froglight
setblock 222 250 481 minecraft:pearlescent_froglight
setblock 222 250 483 minecraft:pearlescent_froglight
setblock 222 250 485 minecraft:pearlescent_froglight
setblock 222 250 487 minecraft:pearlescent_froglight
setblock 223 250 480 minecraft:pearlescent_froglight
setblock 223 250 482 minecraft:pearlescent_froglight
setblock 223 250 484 minecraft:pearlescent_froglight
setblock 223 250 486 minecraft:pearlescent_froglight
setblock 224 250 479 minecraft:pearlescent_froglight
setblock 224 250 481 minecraft:pearlescent_froglight
setblock 224 250 483 minecraft:pearlescent_froglight
setblock 224 250 485 minecraft:pearlescent_froglight
setblock 224 250 487 minecraft:pearlescent_froglight
setblock 225 250 480 minecraft:pearlescent_froglight
setblock 225 250 482 minecraft:pearlescent_froglight
setblock 225 250 484 minecraft:pearlescent_froglight
setblock 225 250 486 minecraft:pearlescent_froglight
setblock 226 250 479 minecraft:pearlescent_froglight
setblock 226 250 481 minecraft:pearlescent_froglight
setblock 226 250 483 minecraft:pearlescent_froglight
setblock 226 250 485 minecraft:pearlescent_froglight
setblock 226 250 487 minecraft:pearlescent_froglight
setblock 227 250 480 minecraft:pearlescent_froglight
setblock 227 250 482 minecraft:pearlescent_froglight
setblock 227 250 484 minecraft:pearlescent_froglight
setblock 227 250 486 minecraft:pearlescent_froglight
setblock 228 250 479 minecraft:pearlescent_froglight
setblock 228 250 481 minecraft:pearlescent_froglight
setblock 228 250 483 minecraft:pearlescent_froglight
setblock 228 250 485 minecraft:pearlescent_froglight
setblock 228 250 487 minecraft:pearlescent_froglight
setblock 229 250 480 minecraft:pearlescent_froglight
setblock 229 250 482 minecraft:pearlescent_froglight
setblock 229 250 484 minecraft:pearlescent_froglight
setblock 229 250 486 minecraft:pearlescent_froglight
fill 203 251 498 203 252 498 minecraft:light_gray_concrete
fill 203 251 500 203 252 500 minecraft:light_gray_concrete
fill 203 251 502 203 252 502 minecraft:light_gray_concrete
fill 203 251 504 203 252 504 minecraft:light_gray_concrete
fill 204 251 497 204 252 497 minecraft:light_gray_concrete
fill 204 251 499 204 252 499 minecraft:light_gray_concrete
fill 204 251 501 204 252 501 minecraft:light_gray_concrete
fill 204 251 503 204 252 503 minecraft:light_gray_concrete
fill 205 251 498 205 252 498 minecraft:light_gray_concrete
fill 205 251 500 205 252 500 minecraft:light_gray_concrete
fill 205 251 502 205 252 502 minecraft:light_gray_concrete
fill 205 251 504 205 252 504 minecraft:light_gray_concrete
fill 206 251 497 206 252 497 minecraft:light_gray_concrete
fill 206 251 499 206 252 499 minecraft:light_gray_concrete
fill 206 251 501 206 252 501 minecraft:light_gray_concrete
fill 206 251 503 206 252 503 minecraft:light_gray_concrete
fill 207 251 498 207 252 498 minecraft:light_gray_concrete
fill 207 251 500 207 252 500 minecraft:light_gray_concrete
fill 207 251 502 207 252 502 minecraft:light_gray_concrete
fill 207 251 504 207 252 504 minecraft:light_gray_concrete
fill 208 251 497 208 252 497 minecraft:light_gray_concrete
fill 208 251 499 208 252 499 minecraft:light_gray_concrete
fill 208 251 501 208 252 501 minecraft:light_gray_concrete
fill 208 251 503 208 252 503 minecraft:light_gray_concrete
fill 209 251 498 209 252 498 minecraft:light_gray_concrete
fill 209 251 500 209 252 500 minecraft:light_gray_concrete
fill 209 251 502 209 252 502 minecraft:light_gray_concrete
fill 209 251 504 209 252 504 minecraft:light_gray_concrete
fill 210 251 497 210 252 497 minecraft:light_gray_concrete
fill 210 251 499 210 252 499 minecraft:light_gray_concrete
fill 210 251 501 210 252 501 minecraft:light_gray_concrete
fill 210 251 503 210 252 503 minecraft:light_gray_concrete
fill 211 251 498 211 252 498 minecraft:light_gray_concrete
fill 211 251 500 211 252 500 minecraft:light_gray_concrete
fill 211 251 502 211 252 502 minecraft:light_gray_concrete
fill 211 251 504 211 252 504 minecraft:light_gray_concrete
fill 212 251 497 212 252 497 minecraft:light_gray_concrete
fill 212 251 499 212 252 499 minecraft:light_gray_concrete
fill 212 251 501 212 252 501 minecraft:light_gray_concrete
fill 212 251 503 212 252 503 minecraft:light_gray_concrete
fill 213 251 498 213 252 498 minecraft:light_gray_concrete
fill 213 251 500 213 252 500 minecraft:light_gray_concrete
fill 213 251 502 213 252 502 minecraft:light_gray_concrete
fill 213 251 504 213 252 504 minecraft:light_gray_concrete
fill 219 251 480 219 252 480 minecraft:light_gray_concrete
fill 219 251 482 219 252 482 minecraft:light_gray_concrete
fill 219 251 484 219 252 484 minecraft:light_gray_concrete
fill 219 251 486 219 252 486 minecraft:light_gray_concrete
fill 220 251 479 220 252 479 minecraft:light_gray_concrete
fill 220 251 481 220 252 481 minecraft:light_gray_concrete
fill 220 251 483 220 252 483 minecraft:light_gray_concrete
fill 220 251 485 220 252 485 minecraft:light_gray_concrete
fill 220 251 487 220 252 487 minecraft:light_gray_concrete
fill 221 251 480 221 252 480 minecraft:light_gray_concrete
fill 221 251 482 221 252 482 minecraft:light_gray_concrete
fill 221 251 484 221 252 484 minecraft:light_gray_concrete
fill 221 251 486 221 252 486 minecraft:light_gray_concrete
fill 222 251 479 222 252 479 minecraft:light_gray_concrete
fill 222 251 481 222 252 481 minecraft:light_gray_concrete
fill 222 251 483 222 252 483 minecraft:light_gray_concrete
fill 222 251 485 222 252 485 minecraft:light_gray_concrete
fill 222 251 487 222 252 487 minecraft:light_gray_concrete
fill 223 251 480 223 252 480 minecraft:light_gray_concrete
fill 223 251 482 223 252 482 minecraft:light_gray_concrete
fill 223 251 484 223 252 484 minecraft:light_gray_concrete
fill 223 251 486 223 252 486 minecraft:light_gray_concrete
fill 224 251 479 224 252 479 minecraft:light_gray_concrete
fill 224 251 481 224 252 481 minecraft:light_gray_concrete
fill 224 251 483 224 252 483 minecraft:light_gray_concrete
fill 224 251 485 224 252 485 minecraft:light_gray_concrete
fill 224 251 487 224 252 487 minecraft:light_gray_concrete
fill 225 251 480 225 252 480 minecraft:light_gray_concrete
fill 225 251 482 225 252 482 minecraft:light_gray_concrete
fill 225 251 484 225 252 484 minecraft:light_gray_concrete
fill 225 251 486 225 252 486 minecraft:light_gray_concrete
fill 226 251 479 226 252 479 minecraft:light_gray_concrete
fill 226 251 481 226 252 481 minecraft:light_gray_concrete
fill 226 251 483 226 252 483 minecraft:light_gray_concrete
fill 226 251 485 226 252 485 minecraft:light_gray_concrete
fill 226 251 487 226 252 487 minecraft:light_gray_concrete
fill 227 251 480 227 252 480 minecraft:light_gray_concrete
fill 227 251 482 227 252 482 minecraft:light_gray_concrete
fill 227 251 484 227 252 484 minecraft:light_gray_concrete
fill 227 251 486 227 252 486 minecraft:light_gray_concrete
fill 228 251 479 228 252 479 minecraft:light_gray_concrete
fill 228 251 481 228 252 481 minecraft:light_gray_concrete
fill 228 251 483 228 252 483 minecraft:light_gray_concrete
fill 228 251 485 228 252 485 minecraft:light_gray_concrete
fill 228 251 487 228 252 487 minecraft:light_gray_concrete
fill 229 251 480 229 252 480 minecraft:light_gray_concrete
fill 229 251 482 229 252 482 minecraft:light_gray_concrete
fill 229 251 484 229 252 484 minecraft:light_gray_concrete
fill 229 251 486 229 252 486 minecraft:light_gray_concrete
fill 189 252 464 189 253 469 minecraft:light_gray_concrete
fill 189 252 472 190 252 477 minecraft:light_gray_concrete
fill 189 252 480 190 252 485 minecraft:light_gray_concrete
fill 189 252 488 190 252 493 minecraft:light_gray_concrete
fill 189 252 496 190 252 501 minecraft:light_gray_concrete
fill 189 252 504 194 253 504 minecraft:light_gray_concrete
fill 190 252 465 190 252 471 minecraft:light_gray_concrete
fill 190 252 478 190 252 479 minecraft:light_gray_concrete
fill 190 252 486 190 252 487 minecraft:light_gray_concrete
fill 190 252 494 190 252 495 minecraft:light_gray_concrete
fill 190 252 502 190 252 503 minecraft:light_gray_concrete
fill 191 252 465 228 252 465 minecraft:light_gray_concrete
setblock 191 252 466 minecraft:light[level=11]
setblock 191 252 474 minecraft:light[level=11]
setblock 191 252 482 minecraft:light[level=11]
setblock 191 252 490 minecraft:light[level=11]
setblock 191 252 498 minecraft:light[level=11]
fill 191 252 503 202 252 503 minecraft:light_gray_concrete
fill 192 252 464 197 253 464 minecraft:light_gray_concrete
fill 197 252 504 202 253 504 minecraft:light_gray_concrete
setblock 199 252 466 minecraft:light[level=11]
setblock 199 252 474 minecraft:light[level=11]
setblock 199 252 482 minecraft:light[level=11]
fill 199 252 485 200 253 485 minecraft:white_wool
setblock 199 252 490 minecraft:light[level=11]
setblock 199 252 498 minecraft:light[level=11]
fill 200 252 464 205 253 464 minecraft:light_gray_concrete
setblock 207 252 466 minecraft:light[level=11]
setblock 207 252 474 minecraft:light[level=11]
setblock 207 252 482 minecraft:light[level=11]
setblock 207 252 490 minecraft:light[level=11]
fill 208 252 464 213 253 464 minecraft:light_gray_concrete
fill 214 252 503 218 252 504 minecraft:light_gray_concrete
setblock 215 252 466 minecraft:light[level=11]
setblock 215 252 474 minecraft:light[level=11]
setblock 215 252 482 minecraft:light[level=11]
setblock 215 252 490 minecraft:light[level=11]
setblock 215 252 498 minecraft:light[level=11]
fill 216 252 464 221 253 464 minecraft:light_gray_concrete
fill 219 252 503 229 252 503 minecraft:light_gray_concrete
fill 221 252 504 226 253 504 minecraft:light_gray_concrete
setblock 223 252 466 minecraft:light[level=11]
setblock 223 252 474 minecraft:light[level=11]
setblock 223 252 490 minecraft:light[level=11]
setblock 223 252 498 minecraft:light[level=11]
fill 224 252 464 229 253 464 minecraft:light_gray_concrete
fill 228 252 466 228 252 478 minecraft:light_gray_concrete
fill 228 252 488 228 252 502 minecraft:light_gray_concrete
fill 229 252 467 229 253 472 minecraft:light_gray_concrete
fill 229 252 475 229 253 478 minecraft:light_gray_concrete
fill 229 252 488 229 253 488 minecraft:light_gray_concrete
fill 229 252 491 229 253 496 minecraft:light_gray_concrete
fill 229 252 499 229 253 502 minecraft:light_gray_concrete
fill 229 252 504 229 253 504 minecraft:light_gray_concrete
fill 189 253 472 189 253 477 minecraft:light_gray_concrete
fill 189 253 480 189 253 485 minecraft:light_gray_concrete
fill 189 253 488 189 253 493 minecraft:light_gray_concrete
fill 189 253 496 189 253 501 minecraft:light_gray_concrete
setblock 203 253 498 minecraft:pearlescent_froglight
setblock 203 253 500 minecraft:pearlescent_froglight
setblock 203 253 502 minecraft:pearlescent_froglight
setblock 203 253 504 minecraft:pearlescent_froglight
setblock 204 253 497 minecraft:pearlescent_froglight
setblock 204 253 499 minecraft:pearlescent_froglight
setblock 204 253 501 minecraft:pearlescent_froglight
setblock 204 253 503 minecraft:pearlescent_froglight
setblock 205 253 498 minecraft:pearlescent_froglight
setblock 205 253 500 minecraft:pearlescent_froglight
setblock 205 253 502 minecraft:pearlescent_froglight
setblock 205 253 504 minecraft:pearlescent_froglight
setblock 206 253 497 minecraft:pearlescent_froglight
setblock 206 253 499 minecraft:pearlescent_froglight
setblock 206 253 501 minecraft:pearlescent_froglight
setblock 206 253 503 minecraft:pearlescent_froglight
setblock 207 253 498 minecraft:pearlescent_froglight
setblock 207 253 500 minecraft:pearlescent_froglight
setblock 207 253 502 minecraft:pearlescent_froglight
setblock 207 253 504 minecraft:pearlescent_froglight
setblock 208 253 497 minecraft:pearlescent_froglight
setblock 208 253 499 minecraft:pearlescent_froglight
setblock 208 253 501 minecraft:pearlescent_froglight
setblock 208 253 503 minecraft:pearlescent_froglight
setblock 209 253 498 minecraft:pearlescent_froglight
setblock 209 253 500 minecraft:pearlescent_froglight
setblock 209 253 502 minecraft:pearlescent_froglight
setblock 209 253 504 minecraft:pearlescent_froglight
setblock 210 253 497 minecraft:pearlescent_froglight
setblock 210 253 499 minecraft:pearlescent_froglight
setblock 210 253 501 minecraft:pearlescent_froglight
setblock 210 253 503 minecraft:pearlescent_froglight
setblock 211 253 498 minecraft:pearlescent_froglight
setblock 211 253 500 minecraft:pearlescent_froglight
setblock 211 253 502 minecraft:pearlescent_froglight
setblock 211 253 504 minecraft:pearlescent_froglight
setblock 212 253 497 minecraft:pearlescent_froglight
setblock 212 253 499 minecraft:pearlescent_froglight
setblock 212 253 501 minecraft:pearlescent_froglight
setblock 212 253 503 minecraft:pearlescent_froglight
setblock 213 253 498 minecraft:pearlescent_froglight
setblock 213 253 500 minecraft:pearlescent_froglight
setblock 213 253 502 minecraft:pearlescent_froglight
setblock 213 253 504 minecraft:pearlescent_froglight
fill 214 253 504 218 253 504 minecraft:light_gray_concrete
setblock 219 253 480 minecraft:pearlescent_froglight
setblock 219 253 482 minecraft:pearlescent_froglight
setblock 219 253 484 minecraft:pearlescent_froglight
setblock 219 253 486 minecraft:pearlescent_froglight
setblock 220 253 479 minecraft:pearlescent_froglight
setblock 220 253 481 minecraft:pearlescent_froglight
setblock 220 253 483 minecraft:pearlescent_froglight
setblock 220 253 485 minecraft:pearlescent_froglight
setblock 220 253 487 minecraft:pearlescent_froglight
setblock 221 253 480 minecraft:pearlescent_froglight
setblock 221 253 482 minecraft:pearlescent_froglight
setblock 221 253 484 minecraft:pearlescent_froglight
setblock 221 253 486 minecraft:pearlescent_froglight
setblock 222 253 479 minecraft:pearlescent_froglight
setblock 222 253 481 minecraft:pearlescent_froglight
setblock 222 253 483 minecraft:pearlescent_froglight
setblock 222 253 485 minecraft:pearlescent_froglight
setblock 222 253 487 minecraft:pearlescent_froglight
setblock 223 253 480 minecraft:pearlescent_froglight
setblock 223 253 482 minecraft:pearlescent_froglight
setblock 223 253 484 minecraft:pearlescent_froglight
setblock 223 253 486 minecraft:pearlescent_froglight
setblock 224 253 479 minecraft:pearlescent_froglight
setblock 224 253 481 minecraft:pearlescent_froglight
setblock 224 253 483 minecraft:pearlescent_froglight
setblock 224 253 485 minecraft:pearlescent_froglight
setblock 224 253 487 minecraft:pearlescent_froglight
setblock 225 253 480 minecraft:pearlescent_froglight
setblock 225 253 482 minecraft:pearlescent_froglight
setblock 225 253 484 minecraft:pearlescent_froglight
setblock 225 253 486 minecraft:pearlescent_froglight
setblock 226 253 479 minecraft:pearlescent_froglight
setblock 226 253 481 minecraft:pearlescent_froglight
setblock 226 253 483 minecraft:pearlescent_froglight
setblock 226 253 485 minecraft:pearlescent_froglight
setblock 226 253 487 minecraft:pearlescent_froglight
setblock 227 253 480 minecraft:pearlescent_froglight
setblock 227 253 482 minecraft:pearlescent_froglight
setblock 227 253 484 minecraft:pearlescent_froglight
setblock 227 253 486 minecraft:pearlescent_froglight
setblock 228 253 479 minecraft:pearlescent_froglight
setblock 228 253 481 minecraft:pearlescent_froglight
setblock 228 253 483 minecraft:pearlescent_froglight
setblock 228 253 485 minecraft:pearlescent_froglight
setblock 228 253 487 minecraft:pearlescent_froglight
setblock 229 253 480 minecraft:pearlescent_froglight
setblock 229 253 482 minecraft:pearlescent_froglight
setblock 229 253 484 minecraft:pearlescent_froglight
setblock 229 253 486 minecraft:pearlescent_froglight
setblock 229 253 503 minecraft:light_gray_concrete
fill 203 254 498 203 255 498 minecraft:light_gray_concrete
fill 203 254 500 203 255 500 minecraft:light_gray_concrete
fill 203 254 502 203 255 502 minecraft:light_gray_concrete
fill 203 254 504 203 255 504 minecraft:light_gray_concrete
fill 204 254 497 204 255 497 minecraft:light_gray_concrete
fill 204 254 499 204 255 499 minecraft:light_gray_concrete
fill 204 254 501 204 255 501 minecraft:light_gray_concrete
fill 204 254 503 204 255 503 minecraft:light_gray_concrete
fill 205 254 498 205 255 498 minecraft:light_gray_concrete
fill 205 254 500 205 255 500 minecraft:light_gray_concrete
fill 205 254 502 205 255 502 minecraft:light_gray_concrete
fill 205 254 504 205 255 504 minecraft:light_gray_concrete
fill 206 254 497 206 255 497 minecraft:light_gray_concrete
fill 206 254 499 206 255 499 minecraft:light_gray_concrete
fill 206 254 501 206 255 501 minecraft:light_gray_concrete
fill 206 254 503 206 255 503 minecraft:light_gray_concrete
fill 207 254 498 207 255 498 minecraft:light_gray_concrete
fill 207 254 500 207 255 500 minecraft:light_gray_concrete
fill 207 254 502 207 255 502 minecraft:light_gray_concrete
fill 207 254 504 207 255 504 minecraft:light_gray_concrete
fill 208 254 497 208 255 497 minecraft:light_gray_concrete
fill 208 254 499 208 255 499 minecraft:light_gray_concrete
fill 208 254 501 208 255 501 minecraft:light_gray_concrete
fill 208 254 503 208 255 503 minecraft:light_gray_concrete
fill 209 254 498 209 255 498 minecraft:light_gray_concrete
fill 209 254 500 209 255 500 minecraft:light_gray_concrete
fill 209 254 502 209 255 502 minecraft:light_gray_concrete
fill 209 254 504 209 255 504 minecraft:light_gray_concrete
fill 210 254 497 210 255 497 minecraft:light_gray_concrete
fill 210 254 499 210 255 499 minecraft:light_gray_concrete
fill 210 254 501 210 255 501 minecraft:light_gray_concrete
fill 210 254 503 210 255 503 minecraft:light_gray_concrete
fill 211 254 498 211 255 498 minecraft:light_gray_concrete
fill 211 254 500 211 255 500 minecraft:light_gray_concrete
fill 211 254 502 211 255 502 minecraft:light_gray_concrete
fill 211 254 504 211 255 504 minecraft:light_gray_concrete
fill 212 254 497 212 255 497 minecraft:light_gray_concrete
fill 212 254 499 212 255 499 minecraft:light_gray_concrete
fill 212 254 501 212 255 501 minecraft:light_gray_concrete
fill 212 254 503 212 255 503 minecraft:light_gray_concrete
fill 213 254 498 213 255 498 minecraft:light_gray_concrete
fill 213 254 500 213 255 500 minecraft:light_gray_concrete
fill 213 254 502 213 255 502 minecraft:light_gray_concrete
fill 213 254 504 213 255 504 minecraft:light_gray_concrete
fill 219 254 480 219 255 480 minecraft:light_gray_concrete
fill 219 254 482 219 255 482 minecraft:light_gray_concrete
fill 219 254 484 219 255 484 minecraft:light_gray_concrete
fill 219 254 486 219 255 486 minecraft:light_gray_concrete
fill 220 254 479 220 255 479 minecraft:light_gray_concrete
fill 220 254 481 220 255 481 minecraft:light_gray_concrete
fill 220 254 483 220 255 483 minecraft:light_gray_concrete
fill 220 254 485 220 255 485 minecraft:light_gray_concrete
fill 220 254 487 220 255 487 minecraft:light_gray_concrete
fill 221 254 480 221 255 480 minecraft:light_gray_concrete
fill 221 254 482 221 255 482 minecraft:light_gray_concrete
fill 221 254 484 221 255 484 minecraft:light_gray_concrete
fill 221 254 486 221 255 486 minecraft:light_gray_concrete
fill 222 254 479 222 255 479 minecraft:light_gray_concrete
fill 222 254 481 222 255 481 minecraft:light_gray_concrete
fill 222 254 483 222 255 483 minecraft:light_gray_concrete
fill 222 254 485 222 255 485 minecraft:light_gray_concrete
fill 222 254 487 222 255 487 minecraft:light_gray_concrete
fill 223 254 480 223 255 480 minecraft:light_gray_concrete
fill 223 254 482 223 255 482 minecraft:light_gray_concrete
fill 223 254 484 223 255 484 minecraft:light_gray_concrete
fill 223 254 486 223 255 486 minecraft:light_gray_concrete
fill 224 254 479 224 255 479 minecraft:light_gray_concrete
fill 224 254 481 224 255 481 minecraft:light_gray_concrete
fill 224 254 483 224 255 483 minecraft:light_gray_concrete
fill 224 254 485 224 255 485 minecraft:light_gray_concrete
fill 224 254 487 224 255 487 minecraft:light_gray_concrete
fill 225 254 480 225 255 480 minecraft:light_gray_concrete
fill 225 254 482 225 255 482 minecraft:light_gray_concrete
fill 225 254 484 225 255 484 minecraft:light_gray_concrete
fill 225 254 486 225 255 486 minecraft:light_gray_concrete
fill 226 254 479 226 255 479 minecraft:light_gray_concrete
fill 226 254 481 226 255 481 minecraft:light_gray_concrete
fill 226 254 483 226 255 483 minecraft:light_gray_concrete
fill 226 254 485 226 255 485 minecraft:light_gray_concrete
fill 226 254 487 226 255 487 minecraft:light_gray_concrete
fill 227 254 480 227 255 480 minecraft:light_gray_concrete
fill 227 254 482 227 255 482 minecraft:light_gray_concrete
fill 227 254 484 227 255 484 minecraft:light_gray_concrete
fill 227 254 486 227 255 486 minecraft:light_gray_concrete
fill 228 254 479 228 255 479 minecraft:light_gray_concrete
fill 228 254 481 228 255 481 minecraft:light_gray_concrete
fill 228 254 483 228 255 483 minecraft:light_gray_concrete
fill 228 254 485 228 255 485 minecraft:light_gray_concrete
fill 228 254 487 228 255 487 minecraft:light_gray_concrete
fill 229 254 480 229 255 480 minecraft:light_gray_concrete
fill 229 254 482 229 255 482 minecraft:light_gray_concrete
fill 229 254 484 229 255 484 minecraft:light_gray_concrete
fill 229 254 486 229 255 486 minecraft:light_gray_concrete
fill 188 256 468 188 261 468 minecraft:pearlescent_froglight
fill 188 256 476 188 261 476 minecraft:pearlescent_froglight
fill 188 256 484 188 261 484 minecraft:pearlescent_froglight
fill 188 256 492 188 261 492 minecraft:pearlescent_froglight
fill 188 256 500 188 261 500 minecraft:pearlescent_froglight
fill 191 256 505 191 261 505 minecraft:pearlescent_froglight
fill 195 256 463 195 261 463 minecraft:pearlescent_froglight
fill 199 256 505 199 261 505 minecraft:pearlescent_froglight
fill 203 256 463 203 261 463 minecraft:pearlescent_froglight
setblock 203 256 498 minecraft:pearlescent_froglight
setblock 203 256 500 minecraft:pearlescent_froglight
setblock 203 256 502 minecraft:pearlescent_froglight
setblock 203 256 504 minecraft:pearlescent_froglight
setblock 204 256 497 minecraft:pearlescent_froglight
setblock 204 256 499 minecraft:pearlescent_froglight
setblock 204 256 501 minecraft:pearlescent_froglight
setblock 204 256 503 minecraft:pearlescent_froglight
setblock 205 256 498 minecraft:pearlescent_froglight
setblock 205 256 500 minecraft:pearlescent_froglight
setblock 205 256 502 minecraft:pearlescent_froglight
setblock 205 256 504 minecraft:pearlescent_froglight
setblock 206 256 497 minecraft:pearlescent_froglight
setblock 206 256 499 minecraft:pearlescent_froglight
setblock 206 256 501 minecraft:pearlescent_froglight
setblock 206 256 503 minecraft:pearlescent_froglight
setblock 207 256 498 minecraft:pearlescent_froglight
setblock 207 256 500 minecraft:pearlescent_froglight
setblock 207 256 502 minecraft:pearlescent_froglight
fill 207 256 504 207 256 505 minecraft:pearlescent_froglight
setblock 208 256 497 minecraft:pearlescent_froglight
setblock 208 256 499 minecraft:pearlescent_froglight
setblock 208 256 501 minecraft:pearlescent_froglight
setblock 208 256 503 minecraft:pearlescent_froglight
setblock 209 256 498 minecraft:pearlescent_froglight
setblock 209 256 500 minecraft:pearlescent_froglight
setblock 209 256 502 minecraft:pearlescent_froglight
setblock 209 256 504 minecraft:pearlescent_froglight
setblock 210 256 497 minecraft:pearlescent_froglight
setblock 210 256 499 minecraft:pearlescent_froglight
setblock 210 256 501 minecraft:pearlescent_froglight
setblock 210 256 503 minecraft:pearlescent_froglight
fill 211 256 463 211 261 463 minecraft:pearlescent_froglight
setblock 211 256 498 minecraft:pearlescent_froglight
setblock 211 256 500 minecraft:pearlescent_froglight
setblock 211 256 502 minecraft:pearlescent_froglight
setblock 211 256 504 minecraft:pearlescent_froglight
setblock 212 256 497 minecraft:pearlescent_froglight
setblock 212 256 499 minecraft:pearlescent_froglight
setblock 212 256 501 minecraft:pearlescent_froglight
setblock 212 256 503 minecraft:pearlescent_froglight
setblock 213 256 498 minecraft:pearlescent_froglight
setblock 213 256 500 minecraft:pearlescent_froglight
setblock 213 256 502 minecraft:pearlescent_froglight
setblock 213 256 504 minecraft:pearlescent_froglight
fill 215 256 505 215 261 505 minecraft:pearlescent_froglight
fill 219 256 463 219 261 463 minecraft:pearlescent_froglight
setblock 219 256 480 minecraft:pearlescent_froglight
setblock 219 256 482 minecraft:pearlescent_froglight
setblock 219 256 484 minecraft:pearlescent_froglight
setblock 219 256 486 minecraft:pearlescent_froglight
setblock 220 256 479 minecraft:pearlescent_froglight
setblock 220 256 481 minecraft:pearlescent_froglight
setblock 220 256 483 minecraft:pearlescent_froglight
setblock 220 256 485 minecraft:pearlescent_froglight
setblock 220 256 487 minecraft:pearlescent_froglight
setblock 221 256 480 minecraft:pearlescent_froglight
setblock 221 256 482 minecraft:pearlescent_froglight
setblock 221 256 484 minecraft:pearlescent_froglight
setblock 221 256 486 minecraft:pearlescent_froglight
setblock 222 256 479 minecraft:pearlescent_froglight
setblock 222 256 481 minecraft:pearlescent_froglight
setblock 222 256 483 minecraft:pearlescent_froglight
setblock 222 256 485 minecraft:pearlescent_froglight
setblock 222 256 487 minecraft:pearlescent_froglight
setblock 223 256 480 minecraft:pearlescent_froglight
setblock 223 256 482 minecraft:pearlescent_froglight
setblock 223 256 484 minecraft:pearlescent_froglight
setblock 223 256 486 minecraft:pearlescent_froglight
fill 223 256 505 223 261 505 minecraft:pearlescent_froglight
setblock 224 256 479 minecraft:pearlescent_froglight
setblock 224 256 481 minecraft:pearlescent_froglight
setblock 224 256 483 minecraft:pearlescent_froglight
setblock 224 256 485 minecraft:pearlescent_froglight
setblock 224 256 487 minecraft:pearlescent_froglight
setblock 225 256 480 minecraft:pearlescent_froglight
setblock 225 256 482 minecraft:pearlescent_froglight
setblock 225 256 484 minecraft:pearlescent_froglight
setblock 225 256 486 minecraft:pearlescent_froglight
setblock 226 256 479 minecraft:pearlescent_froglight
setblock 226 256 481 minecraft:pearlescent_froglight
setblock 226 256 483 minecraft:pearlescent_froglight
setblock 226 256 485 minecraft:pearlescent_froglight
setblock 226 256 487 minecraft:pearlescent_froglight
fill 227 256 463 227 261 463 minecraft:pearlescent_froglight
setblock 227 256 480 minecraft:pearlescent_froglight
setblock 227 256 482 minecraft:pearlescent_froglight
setblock 227 256 484 minecraft:pearlescent_froglight
setblock 227 256 486 minecraft:pearlescent_froglight
setblock 228 256 479 minecraft:pearlescent_froglight
setblock 228 256 481 minecraft:pearlescent_froglight
setblock 228 256 483 minecraft:pearlescent_froglight
setblock 228 256 485 minecraft:pearlescent_froglight
setblock 228 256 487 minecraft:pearlescent_froglight
setblock 229 256 480 minecraft:pearlescent_froglight
setblock 229 256 482 minecraft:pearlescent_froglight
fill 229 256 484 230 256 484 minecraft:pearlescent_froglight
setblock 229 256 486 minecraft:pearlescent_froglight
fill 230 256 468 230 261 468 minecraft:pearlescent_froglight
fill 230 256 476 230 261 476 minecraft:pearlescent_froglight
fill 230 256 492 230 261 492 minecraft:pearlescent_froglight
fill 230 256 500 230 261 500 minecraft:pearlescent_froglight
fill 203 257 498 203 258 498 minecraft:light_gray_concrete
fill 203 257 500 203 258 500 minecraft:light_gray_concrete
fill 203 257 502 203 258 502 minecraft:light_gray_concrete
fill 203 257 504 203 258 504 minecraft:light_gray_concrete
fill 204 257 497 204 258 497 minecraft:light_gray_concrete
fill 204 257 499 204 258 499 minecraft:light_gray_concrete
fill 204 257 501 204 258 501 minecraft:light_gray_concrete
fill 204 257 503 204 258 503 minecraft:light_gray_concrete
fill 205 257 498 205 258 498 minecraft:light_gray_concrete
fill 205 257 500 205 258 500 minecraft:light_gray_concrete
fill 205 257 502 205 258 502 minecraft:light_gray_concrete
fill 205 257 504 205 258 504 minecraft:light_gray_concrete
fill 206 257 497 206 258 497 minecraft:light_gray_concrete
fill 206 257 499 206 258 499 minecraft:light_gray_concrete
fill 206 257 501 206 258 501 minecraft:light_gray_concrete
fill 206 257 503 206 258 503 minecraft:light_gray_concrete
fill 207 257 498 207 258 498 minecraft:light_gray_concrete
fill 207 257 500 207 258 500 minecraft:light_gray_concrete
fill 207 257 502 207 258 502 minecraft:light_gray_concrete
fill 207 257 504 207 258 504 minecraft:light_gray_concrete
fill 207 257 505 207 261 505 minecraft:pearlescent_froglight
fill 208 257 497 208 258 497 minecraft:light_gray_concrete
fill 208 257 499 208 258 499 minecraft:light_gray_concrete
fill 208 257 501 208 258 501 minecraft:light_gray_concrete
fill 208 257 503 208 258 503 minecraft:light_gray_concrete
fill 209 257 498 209 258 498 minecraft:light_gray_concrete
fill 209 257 500 209 258 500 minecraft:light_gray_concrete
fill 209 257 502 209 258 502 minecraft:light_gray_concrete
fill 209 257 504 209 258 504 minecraft:light_gray_concrete
fill 210 257 497 210 258 497 minecraft:light_gray_concrete
fill 210 257 499 210 258 499 minecraft:light_gray_concrete
fill 210 257 501 210 258 501 minecraft:light_gray_concrete
fill 210 257 503 210 258 503 minecraft:light_gray_concrete
fill 211 257 498 211 258 498 minecraft:light_gray_concrete
fill 211 257 500 211 258 500 minecraft:light_gray_concrete
fill 211 257 502 211 258 502 minecraft:light_gray_concrete
fill 211 257 504 211 258 504 minecraft:light_gray_concrete
fill 212 257 497 212 258 497 minecraft:light_gray_concrete
fill 212 257 499 212 258 499 minecraft:light_gray_concrete
fill 212 257 501 212 258 501 minecraft:light_gray_concrete
fill 212 257 503 212 258 503 minecraft:light_gray_concrete
fill 213 257 498 213 258 498 minecraft:light_gray_concrete
fill 213 257 500 213 258 500 minecraft:light_gray_concrete
fill 213 257 502 213 258 502 minecraft:light_gray_concrete
fill 213 257 504 213 258 504 minecraft:light_gray_concrete
fill 219 257 480 219 258 480 minecraft:light_gray_concrete
fill 219 257 482 219 258 482 minecraft:light_gray_concrete
fill 219 257 484 219 258 484 minecraft:light_gray_concrete
fill 219 257 486 219 258 486 minecraft:light_gray_concrete
fill 220 257 479 220 258 479 minecraft:light_gray_concrete
fill 220 257 481 220 258 481 minecraft:light_gray_concrete
fill 220 257 483 220 258 483 minecraft:light_gray_concrete
fill 220 257 485 220 258 485 minecraft:light_gray_concrete
fill 220 257 487 220 258 487 minecraft:light_gray_concrete
fill 221 257 480 221 258 480 minecraft:light_gray_concrete
fill 221 257 482 221 258 482 minecraft:light_gray_concrete
fill 221 257 484 221 258 484 minecraft:light_gray_concrete
fill 221 257 486 221 258 486 minecraft:light_gray_concrete
fill 222 257 479 222 258 479 minecraft:light_gray_concrete
fill 222 257 481 222 258 481 minecraft:light_gray_concrete
fill 222 257 483 222 258 483 minecraft:light_gray_concrete
fill 222 257 485 222 258 485 minecraft:light_gray_concrete
fill 222 257 487 222 258 487 minecraft:light_gray_concrete
fill 223 257 480 223 258 480 minecraft:light_gray_concrete
fill 223 257 482 223 258 482 minecraft:light_gray_concrete
fill 223 257 484 223 258 484 minecraft:light_gray_concrete
fill 223 257 486 223 258 486 minecraft:light_gray_concrete
fill 224 257 479 224 258 479 minecraft:light_gray_concrete
fill 224 257 481 224 258 481 minecraft:light_gray_concrete
fill 224 257 483 224 258 483 minecraft:light_gray_concrete
fill 224 257 485 224 258 485 minecraft:light_gray_concrete
fill 224 257 487 224 258 487 minecraft:light_gray_concrete
fill 225 257 480 225 258 480 minecraft:light_gray_concrete
fill 225 257 482 225 258 482 minecraft:light_gray_concrete
fill 225 257 484 225 258 484 minecraft:light_gray_concrete
fill 225 257 486 225 258 486 minecraft:light_gray_concrete
fill 226 257 479 226 258 479 minecraft:light_gray_concrete
fill 226 257 481 226 258 481 minecraft:light_gray_concrete
fill 226 257 483 226 258 483 minecraft:light_gray_concrete
fill 226 257 485 226 258 485 minecraft:light_gray_concrete
fill 226 257 487 226 258 487 minecraft:light_gray_concrete
fill 227 257 480 227 258 480 minecraft:light_gray_concrete
fill 227 257 482 227 258 482 minecraft:light_gray_concrete
fill 227 257 484 227 258 484 minecraft:light_gray_concrete
fill 227 257 486 227 258 486 minecraft:light_gray_concrete
fill 228 257 479 228 258 479 minecraft:light_gray_concrete
fill 228 257 481 228 258 481 minecraft:light_gray_concrete
fill 228 257 483 228 258 483 minecraft:light_gray_concrete
fill 228 257 485 228 258 485 minecraft:light_gray_concrete
fill 228 257 487 228 258 487 minecraft:light_gray_concrete
fill 229 257 480 229 258 480 minecraft:light_gray_concrete
fill 229 257 482 229 258 482 minecraft:light_gray_concrete
fill 229 257 484 229 258 484 minecraft:light_gray_concrete
fill 229 257 486 229 258 486 minecraft:light_gray_concrete
fill 230 257 484 230 261 484 minecraft:pearlescent_froglight
setblock 203 259 498 minecraft:pearlescent_froglight
setblock 203 259 500 minecraft:pearlescent_froglight
setblock 203 259 502 minecraft:pearlescent_froglight
setblock 203 259 504 minecraft:pearlescent_froglight
setblock 204 259 497 minecraft:pearlescent_froglight
setblock 204 259 499 minecraft:pearlescent_froglight
setblock 204 259 501 minecraft:pearlescent_froglight
setblock 204 259 503 minecraft:pearlescent_froglight
setblock 205 259 498 minecraft:pearlescent_froglight
setblock 205 259 500 minecraft:pearlescent_froglight
setblock 205 259 502 minecraft:pearlescent_froglight
setblock 205 259 504 minecraft:pearlescent_froglight
setblock 206 259 497 minecraft:pearlescent_froglight
setblock 206 259 499 minecraft:pearlescent_froglight
setblock 206 259 501 minecraft:pearlescent_froglight
setblock 206 259 503 minecraft:pearlescent_froglight
setblock 207 259 498 minecraft:pearlescent_froglight
setblock 207 259 500 minecraft:pearlescent_froglight
setblock 207 259 502 minecraft:pearlescent_froglight
setblock 207 259 504 minecraft:pearlescent_froglight
setblock 208 259 497 minecraft:pearlescent_froglight
setblock 208 259 499 minecraft:pearlescent_froglight
setblock 208 259 501 minecraft:pearlescent_froglight
setblock 208 259 503 minecraft:pearlescent_froglight
setblock 209 259 498 minecraft:pearlescent_froglight
setblock 209 259 500 minecraft:pearlescent_froglight
setblock 209 259 502 minecraft:pearlescent_froglight
setblock 209 259 504 minecraft:pearlescent_froglight
setblock 210 259 497 minecraft:pearlescent_froglight
setblock 210 259 499 minecraft:pearlescent_froglight
setblock 210 259 501 minecraft:pearlescent_froglight
setblock 210 259 503 minecraft:pearlescent_froglight
setblock 211 259 498 minecraft:pearlescent_froglight
setblock 211 259 500 minecraft:pearlescent_froglight
setblock 211 259 502 minecraft:pearlescent_froglight
setblock 211 259 504 minecraft:pearlescent_froglight
setblock 212 259 497 minecraft:pearlescent_froglight
setblock 212 259 499 minecraft:pearlescent_froglight
setblock 212 259 501 minecraft:pearlescent_froglight
setblock 212 259 503 minecraft:pearlescent_froglight
setblock 213 259 498 minecraft:pearlescent_froglight
setblock 213 259 500 minecraft:pearlescent_froglight
setblock 213 259 502 minecraft:pearlescent_froglight
setblock 213 259 504 minecraft:pearlescent_froglight
setblock 219 259 480 minecraft:pearlescent_froglight
setblock 219 259 482 minecraft:pearlescent_froglight
setblock 219 259 484 minecraft:pearlescent_froglight
setblock 219 259 486 minecraft:pearlescent_froglight
setblock 220 259 479 minecraft:pearlescent_froglight
setblock 220 259 481 minecraft:pearlescent_froglight
setblock 220 259 483 minecraft:pearlescent_froglight
setblock 220 259 485 minecraft:pearlescent_froglight
setblock 220 259 487 minecraft:pearlescent_froglight
setblock 221 259 480 minecraft:pearlescent_froglight
setblock 221 259 482 minecraft:pearlescent_froglight
setblock 221 259 484 minecraft:pearlescent_froglight
setblock 221 259 486 minecraft:pearlescent_froglight
setblock 222 259 479 minecraft:pearlescent_froglight
setblock 222 259 481 minecraft:pearlescent_froglight
setblock 222 259 483 minecraft:pearlescent_froglight
setblock 222 259 485 minecraft:pearlescent_froglight
setblock 222 259 487 minecraft:pearlescent_froglight
setblock 223 259 480 minecraft:pearlescent_froglight
setblock 223 259 482 minecraft:pearlescent_froglight
setblock 223 259 484 minecraft:pearlescent_froglight
setblock 223 259 486 minecraft:pearlescent_froglight
setblock 224 259 479 minecraft:pearlescent_froglight
setblock 224 259 481 minecraft:pearlescent_froglight
setblock 224 259 483 minecraft:pearlescent_froglight
setblock 224 259 485 minecraft:pearlescent_froglight
setblock 224 259 487 minecraft:pearlescent_froglight
setblock 225 259 480 minecraft:pearlescent_froglight
setblock 225 259 482 minecraft:pearlescent_froglight
setblock 225 259 484 minecraft:pearlescent_froglight
setblock 225 259 486 minecraft:pearlescent_froglight
setblock 226 259 479 minecraft:pearlescent_froglight
setblock 226 259 481 minecraft:pearlescent_froglight
setblock 226 259 483 minecraft:pearlescent_froglight
setblock 226 259 485 minecraft:pearlescent_froglight
setblock 226 259 487 minecraft:pearlescent_froglight
setblock 227 259 480 minecraft:pearlescent_froglight
setblock 227 259 482 minecraft:pearlescent_froglight
setblock 227 259 484 minecraft:pearlescent_froglight
setblock 227 259 486 minecraft:pearlescent_froglight
setblock 228 259 479 minecraft:pearlescent_froglight
setblock 228 259 481 minecraft:pearlescent_froglight
setblock 228 259 483 minecraft:pearlescent_froglight
setblock 228 259 485 minecraft:pearlescent_froglight
setblock 228 259 487 minecraft:pearlescent_froglight
setblock 229 259 480 minecraft:pearlescent_froglight
setblock 229 259 482 minecraft:pearlescent_froglight
setblock 229 259 484 minecraft:pearlescent_froglight
setblock 229 259 486 minecraft:pearlescent_froglight
setblock 191 260 466 minecraft:light[level=11]
setblock 191 260 474 minecraft:light[level=11]
setblock 191 260 482 minecraft:light[level=11]
setblock 191 260 490 minecraft:light[level=11]
setblock 191 260 498 minecraft:light[level=11]
setblock 199 260 466 minecraft:light[level=11]
setblock 199 260 474 minecraft:light[level=11]
setblock 199 260 482 minecraft:light[level=11]
setblock 199 260 490 minecraft:light[level=11]
setblock 199 260 498 minecraft:light[level=11]
fill 203 260 498 203 262 498 minecraft:light_gray_concrete
fill 203 260 500 203 262 500 minecraft:light_gray_concrete
fill 203 260 502 203 262 502 minecraft:light_gray_concrete
fill 203 260 504 203 273 504 minecraft:light_gray_concrete
fill 204 260 497 204 262 497 minecraft:light_gray_concrete
fill 204 260 499 204 262 499 minecraft:light_gray_concrete
fill 204 260 501 204 262 501 minecraft:light_gray_concrete
fill 204 260 503 204 262 503 minecraft:light_gray_concrete
fill 205 260 498 205 262 498 minecraft:light_gray_concrete
fill 205 260 500 205 262 500 minecraft:light_gray_concrete
fill 205 260 502 205 262 502 minecraft:light_gray_concrete
fill 205 260 504 205 262 504 minecraft:light_gray_concrete
fill 206 260 497 206 262 497 minecraft:light_gray_concrete
fill 206 260 499 206 262 499 minecraft:light_gray_concrete
fill 206 260 501 206 262 501 minecraft:light_gray_concrete
fill 206 260 503 206 262 503 minecraft:light_gray_concrete
setblock 207 260 466 minecraft:light[level=11]
setblock 207 260 474 minecraft:light[level=11]
setblock 207 260 482 minecraft:light[level=11]
setblock 207 260 490 minecraft:light[level=11]
fill 207 260 498 207 262 498 minecraft:light_gray_concrete
fill 207 260 500 207 262 500 minecraft:light_gray_concrete
fill 207 260 502 207 262 502 minecraft:light_gray_concrete
fill 207 260 504 207 262 504 minecraft:light_gray_concrete
fill 208 260 497 208 262 497 minecraft:light_gray_concrete
fill 208 260 499 208 262 499 minecraft:light_gray_concrete
fill 208 260 501 208 262 501 minecraft:light_gray_concrete
fill 208 260 503 208 262 503 minecraft:light_gray_concrete
fill 209 260 498 209 262 498 minecraft:light_gray_concrete
fill 209 260 500 209 262 500 minecraft:light_gray_concrete
fill 209 260 502 209 262 502 minecraft:light_gray_concrete
fill 209 260 504 209 262 504 minecraft:light_gray_concrete
fill 210 260 497 210 262 497 minecraft:light_gray_concrete
fill 210 260 499 210 262 499 minecraft:light_gray_concrete
fill 210 260 501 210 262 501 minecraft:light_gray_concrete
fill 210 260 503 210 262 503 minecraft:light_gray_concrete
fill 211 260 498 211 262 498 minecraft:light_gray_concrete
fill 211 260 500 211 262 500 minecraft:light_gray_concrete
fill 211 260 502 211 262 502 minecraft:light_gray_concrete
fill 211 260 504 211 273 504 minecraft:light_gray_concrete
fill 212 260 497 212 262 497 minecraft:light_gray_concrete
fill 212 260 499 212 262 499 minecraft:light_gray_concrete
fill 212 260 501 212 262 501 minecraft:light_gray_concrete
fill 212 260 503 212 262 503 minecraft:light_gray_concrete
fill 213 260 498 213 262 498 minecraft:light_gray_concrete
fill 213 260 500 213 262 500 minecraft:light_gray_concrete
fill 213 260 502 213 262 502 minecraft:light_gray_concrete
fill 213 260 504 213 262 504 minecraft:light_gray_concrete
setblock 215 260 466 minecraft:light[level=11]
setblock 215 260 474 minecraft:light[level=11]
setblock 215 260 482 minecraft:light[level=11]
setblock 215 260 490 minecraft:light[level=11]
setblock 215 260 498 minecraft:light[level=11]
fill 219 260 480 219 261 480 minecraft:light_gray_concrete
fill 219 260 482 219 261 482 minecraft:light_gray_concrete
fill 219 260 484 219 261 484 minecraft:light_gray_concrete
fill 219 260 486 219 261 486 minecraft:light_gray_concrete
fill 220 260 479 220 261 479 minecraft:light_gray_concrete
fill 220 260 481 220 261 481 minecraft:light_gray_concrete
fill 220 260 483 220 261 483 minecraft:light_gray_concrete
fill 220 260 485 220 261 485 minecraft:light_gray_concrete
fill 220 260 487 220 261 487 minecraft:light_gray_concrete
fill 221 260 480 221 261 480 minecraft:light_gray_concrete
fill 221 260 482 221 261 482 minecraft:light_gray_concrete
fill 221 260 484 221 261 484 minecraft:light_gray_concrete
fill 221 260 486 221 261 486 minecraft:light_gray_concrete
fill 222 260 479 222 261 479 minecraft:light_gray_concrete
fill 222 260 481 222 261 481 minecraft:light_gray_concrete
fill 222 260 483 222 261 483 minecraft:light_gray_concrete
fill 222 260 485 222 261 485 minecraft:light_gray_concrete
fill 222 260 487 222 261 487 minecraft:light_gray_concrete
setblock 223 260 466 minecraft:light[level=11]
setblock 223 260 474 minecraft:light[level=11]
fill 223 260 480 223 261 480 minecraft:light_gray_concrete
fill 223 260 482 223 261 482 minecraft:light_gray_concrete
fill 223 260 484 223 261 484 minecraft:light_gray_concrete
fill 223 260 486 223 261 486 minecraft:light_gray_concrete
setblock 223 260 490 minecraft:light[level=11]
setblock 223 260 498 minecraft:light[level=11]
fill 224 260 479 224 261 479 minecraft:light_gray_concrete
fill 224 260 481 224 261 481 minecraft:light_gray_concrete
fill 224 260 483 224 261 483 minecraft:light_gray_concrete
fill 224 260 485 224 261 485 minecraft:light_gray_concrete
fill 224 260 487 224 261 487 minecraft:light_gray_concrete
fill 225 260 480 225 261 480 minecraft:light_gray_concrete
fill 225 260 482 225 261 482 minecraft:light_gray_concrete
fill 225 260 484 225 261 484 minecraft:light_gray_concrete
fill 225 260 486 225 261 486 minecraft:light_gray_concrete
fill 226 260 479 226 261 479 minecraft:light_gray_concrete
fill 226 260 481 226 261 481 minecraft:light_gray_concrete
fill 226 260 483 226 261 483 minecraft:light_gray_concrete
fill 226 260 485 226 261 485 minecraft:light_gray_concrete
fill 226 260 487 226 261 487 minecraft:light_gray_concrete
fill 227 260 480 227 261 480 minecraft:light_gray_concrete
fill 227 260 482 227 261 482 minecraft:light_gray_concrete
fill 227 260 484 227 261 484 minecraft:light_gray_concrete
fill 227 260 486 227 261 486 minecraft:light_gray_concrete
fill 228 260 479 228 261 479 minecraft:light_gray_concrete
fill 228 260 481 228 261 481 minecraft:light_gray_concrete
fill 228 260 483 228 261 483 minecraft:light_gray_concrete
fill 228 260 485 228 261 485 minecraft:light_gray_concrete
fill 228 260 487 228 261 487 minecraft:light_gray_concrete
fill 229 260 480 229 261 480 minecraft:light_gray_concrete
fill 229 260 482 229 261 482 minecraft:light_gray_concrete
fill 229 260 484 229 261 484 minecraft:light_gray_concrete
fill 229 260 486 229 261 486 minecraft:light_gray_concrete
fill 188 262 468 188 269 468 minecraft:white_terracotta
fill 188 262 476 188 269 476 minecraft:white_terracotta
fill 188 262 484 188 269 484 minecraft:white_terracotta
fill 188 262 492 188 269 492 minecraft:white_terracotta
fill 188 262 500 188 269 500 minecraft:white_terracotta
fill 191 262 505 191 269 505 minecraft:white_terracotta
fill 195 262 463 195 269 463 minecraft:white_terracotta
fill 199 262 505 199 269 505 minecraft:white_terracotta
fill 203 262 463 203 269 463 minecraft:white_terracotta
fill 207 262 505 207 269 505 minecraft:white_terracotta
fill 211 262 463 211 269 463 minecraft:white_terracotta
fill 215 262 505 215 269 505 minecraft:white_terracotta
fill 219 262 463 219 269 463 minecraft:white_terracotta
setblock 219 262 480 minecraft:pearlescent_froglight
setblock 219 262 482 minecraft:pearlescent_froglight
setblock 219 262 484 minecraft:pearlescent_froglight
setblock 219 262 486 minecraft:pearlescent_froglight
setblock 220 262 479 minecraft:pearlescent_froglight
setblock 220 262 481 minecraft:pearlescent_froglight
setblock 220 262 483 minecraft:pearlescent_froglight
setblock 220 262 485 minecraft:pearlescent_froglight
setblock 220 262 487 minecraft:pearlescent_froglight
setblock 221 262 480 minecraft:pearlescent_froglight
setblock 221 262 482 minecraft:pearlescent_froglight
setblock 221 262 484 minecraft:pearlescent_froglight
setblock 221 262 486 minecraft:pearlescent_froglight
setblock 222 262 479 minecraft:pearlescent_froglight
setblock 222 262 481 minecraft:pearlescent_froglight
setblock 222 262 483 minecraft:pearlescent_froglight
setblock 222 262 485 minecraft:pearlescent_froglight
setblock 222 262 487 minecraft:pearlescent_froglight
setblock 223 262 480 minecraft:pearlescent_froglight
setblock 223 262 482 minecraft:pearlescent_froglight
setblock 223 262 484 minecraft:pearlescent_froglight
setblock 223 262 486 minecraft:pearlescent_froglight
fill 223 262 505 223 269 505 minecraft:white_terracotta
setblock 224 262 479 minecraft:pearlescent_froglight
setblock 224 262 481 minecraft:pearlescent_froglight
setblock 224 262 483 minecraft:pearlescent_froglight
setblock 224 262 485 minecraft:pearlescent_froglight
setblock 224 262 487 minecraft:pearlescent_froglight
setblock 225 262 480 minecraft:pearlescent_froglight
setblock 225 262 482 minecraft:pearlescent_froglight
setblock 225 262 484 minecraft:pearlescent_froglight
setblock 225 262 486 minecraft:pearlescent_froglight
setblock 226 262 479 minecraft:pearlescent_froglight
setblock 226 262 481 minecraft:pearlescent_froglight
setblock 226 262 483 minecraft:pearlescent_froglight
setblock 226 262 485 minecraft:pearlescent_froglight
setblock 226 262 487 minecraft:pearlescent_froglight
fill 227 262 463 227 269 463 minecraft:white_terracotta
setblock 227 262 480 minecraft:pearlescent_froglight
setblock 227 262 482 minecraft:pearlescent_froglight
setblock 227 262 484 minecraft:pearlescent_froglight
setblock 227 262 486 minecraft:pearlescent_froglight
setblock 228 262 479 minecraft:pearlescent_froglight
setblock 228 262 481 minecraft:pearlescent_froglight
setblock 228 262 483 minecraft:pearlescent_froglight
setblock 228 262 485 minecraft:pearlescent_froglight
setblock 228 262 487 minecraft:pearlescent_froglight
setblock 229 262 480 minecraft:pearlescent_froglight
setblock 229 262 482 minecraft:pearlescent_froglight
setblock 229 262 484 minecraft:pearlescent_froglight
setblock 229 262 486 minecraft:pearlescent_froglight
fill 230 262 468 230 269 468 minecraft:white_terracotta
fill 230 262 476 230 269 476 minecraft:white_terracotta
fill 230 262 484 230 269 484 minecraft:white_terracotta
fill 230 262 492 230 269 492 minecraft:white_terracotta
fill 230 262 500 230 269 500 minecraft:white_terracotta
fill 219 263 480 219 264 480 minecraft:light_gray_concrete
fill 219 263 482 219 264 482 minecraft:light_gray_concrete
fill 219 263 484 219 264 484 minecraft:light_gray_concrete
fill 219 263 486 219 264 486 minecraft:light_gray_concrete
fill 220 263 479 220 264 479 minecraft:light_gray_concrete
fill 220 263 481 220 264 481 minecraft:light_gray_concrete
fill 220 263 483 220 264 483 minecraft:light_gray_concrete
fill 220 263 485 220 264 485 minecraft:light_gray_concrete
fill 220 263 487 220 264 487 minecraft:light_gray_concrete
fill 221 263 480 221 264 480 minecraft:light_gray_concrete
fill 221 263 482 221 264 482 minecraft:light_gray_concrete
fill 221 263 484 221 264 484 minecraft:light_gray_concrete
fill 221 263 486 221 264 486 minecraft:light_gray_concrete
fill 222 263 479 222 264 479 minecraft:light_gray_concrete
fill 222 263 481 222 264 481 minecraft:light_gray_concrete
fill 222 263 483 222 264 483 minecraft:light_gray_concrete
fill 222 263 485 222 264 485 minecraft:light_gray_concrete
fill 222 263 487 222 264 487 minecraft:light_gray_concrete
fill 223 263 480 223 264 480 minecraft:light_gray_concrete
fill 223 263 482 223 264 482 minecraft:light_gray_concrete
fill 223 263 484 223 264 484 minecraft:light_gray_concrete
fill 223 263 486 223 264 486 minecraft:light_gray_concrete
fill 224 263 479 224 264 479 minecraft:light_gray_concrete
fill 224 263 481 224 264 481 minecraft:light_gray_concrete
fill 224 263 483 224 264 483 minecraft:light_gray_concrete
fill 224 263 485 224 264 485 minecraft:light_gray_concrete
fill 224 263 487 224 264 487 minecraft:light_gray_concrete
fill 225 263 480 225 264 480 minecraft:light_gray_concrete
fill 225 263 482 225 264 482 minecraft:light_gray_concrete
fill 225 263 484 225 264 484 minecraft:light_gray_concrete
fill 225 263 486 225 264 486 minecraft:light_gray_concrete
fill 226 263 479 226 264 479 minecraft:light_gray_concrete
fill 226 263 481 226 264 481 minecraft:light_gray_concrete
fill 226 263 483 226 264 483 minecraft:light_gray_concrete
fill 226 263 485 226 264 485 minecraft:light_gray_concrete
fill 226 263 487 226 264 487 minecraft:light_gray_concrete
fill 227 263 480 227 264 480 minecraft:light_gray_concrete
fill 227 263 482 227 264 482 minecraft:light_gray_concrete
fill 227 263 484 227 264 484 minecraft:light_gray_concrete
fill 227 263 486 227 264 486 minecraft:light_gray_concrete
fill 228 263 479 228 264 479 minecraft:light_gray_concrete
fill 228 263 481 228 264 481 minecraft:light_gray_concrete
fill 228 263 483 228 264 483 minecraft:light_gray_concrete
fill 228 263 485 228 264 485 minecraft:light_gray_concrete
fill 228 263 487 228 264 487 minecraft:light_gray_concrete
fill 229 263 480 229 264 480 minecraft:light_gray_concrete
fill 229 263 482 229 273 482 minecraft:light_gray_concrete
fill 229 263 484 229 264 484 minecraft:light_gray_concrete
fill 229 263 486 229 264 486 minecraft:light_gray_concrete
fill 208 264 475 209 265 475 minecraft:red_concrete
fill 189 266 464 189 267 469 minecraft:light_gray_concrete
fill 189 266 472 190 266 477 minecraft:light_gray_concrete
fill 189 266 480 190 266 485 minecraft:light_gray_concrete
fill 189 266 488 190 266 493 minecraft:light_gray_concrete
fill 189 266 496 190 266 501 minecraft:light_gray_concrete
fill 189 266 504 194 267 504 minecraft:light_gray_concrete
fill 190 266 465 190 266 471 minecraft:light_gray_concrete
fill 190 266 478 190 266 479 minecraft:light_gray_concrete
fill 190 266 486 190 266 487 minecraft:light_gray_concrete
fill 190 266 494 190 266 495 minecraft:light_gray_concrete
fill 190 266 502 190 266 503 minecraft:light_gray_concrete
fill 191 266 465 228 266 465 minecraft:light_gray_concrete
fill 191 266 503 229 266 503 minecraft:light_gray_concrete
fill 192 266 464 197 267 464 minecraft:light_gray_concrete
fill 197 266 504 202 267 504 minecraft:light_gray_concrete
fill 200 266 464 205 267 464 minecraft:light_gray_concrete
fill 205 266 504 210 267 504 minecraft:light_gray_concrete
fill 208 266 464 213 267 464 minecraft:light_gray_concrete
fill 213 266 504 218 267 504 minecraft:light_gray_concrete
fill 216 266 464 221 267 464 minecraft:light_gray_concrete
fill 221 266 504 226 267 504 minecraft:light_gray_concrete
fill 224 266 464 229 267 464 minecraft:light_gray_concrete
fill 228 266 466 228 266 502 minecraft:light_gray_concrete
fill 229 266 467 229 267 472 minecraft:light_gray_concrete
fill 229 266 475 229 267 480 minecraft:light_gray_concrete
fill 229 266 483 229 267 488 minecraft:light_gray_concrete
fill 229 266 491 229 267 496 minecraft:light_gray_concrete
fill 229 266 499 229 267 502 minecraft:light_gray_concrete
fill 229 266 504 229 267 504 minecraft:light_gray_concrete
fill 189 267 472 189 267 477 minecraft:light_gray_concrete
fill 189 267 480 189 267 485 minecraft:light_gray_concrete
fill 189 267 488 189 267 493 minecraft:light_gray_concrete
fill 189 267 496 189 267 501 minecraft:light_gray_concrete
setblock 229 267 503 minecraft:light_gray_concrete
setblock 191 268 466 minecraft:light[level=11]
setblock 191 268 474 minecraft:light[level=11]
setblock 191 268 482 minecraft:light[level=11]
setblock 191 268 490 minecraft:light[level=11]
setblock 191 268 498 minecraft:light[level=11]
fill 198 268 479 199 269 479 minecraft:red_concrete
setblock 199 268 466 minecraft:light[level=11]
setblock 199 268 474 minecraft:light[level=11]
setblock 199 268 482 minecraft:light[level=11]
setblock 199 268 490 minecraft:light[level=11]
setblock 199 268 498 minecraft:light[level=11]
setblock 207 268 466 minecraft:light[level=11]
setblock 207 268 474 minecraft:light[level=11]
setblock 207 268 482 minecraft:light[level=11]
setblock 207 268 490 minecraft:light[level=11]
setblock 207 268 498 minecraft:light[level=11]
setblock 215 268 466 minecraft:light[level=11]
setblock 215 268 474 minecraft:light[level=11]
setblock 215 268 482 minecraft:light[level=11]
setblock 215 268 490 minecraft:light[level=11]
setblock 215 268 498 minecraft:light[level=11]
setblock 223 268 466 minecraft:light[level=11]
setblock 223 268 474 minecraft:light[level=11]
setblock 223 268 482 minecraft:light[level=11]
setblock 223 268 490 minecraft:light[level=11]
setblock 223 268 498 minecraft:light[level=11]
fill 201 269 479 202 270 479 minecraft:white_wool
fill 188 270 468 188 273 468 minecraft:pearlescent_froglight
fill 188 270 476 188 273 476 minecraft:pearlescent_froglight
fill 188 270 484 188 273 484 minecraft:pearlescent_froglight
fill 188 270 492 188 273 492 minecraft:pearlescent_froglight
fill 188 270 500 188 273 500 minecraft:pearlescent_froglight
fill 191 270 505 191 273 505 minecraft:pearlescent_froglight
fill 195 270 463 195 273 463 minecraft:pearlescent_froglight
fill 199 270 505 199 273 505 minecraft:pearlescent_froglight
fill 203 270 463 203 273 463 minecraft:pearlescent_froglight
fill 207 270 505 207 273 505 minecraft:pearlescent_froglight
fill 211 270 463 211 273 463 minecraft:pearlescent_froglight
fill 215 270 505 215 273 505 minecraft:pearlescent_froglight
fill 219 270 463 219 273 463 minecraft:pearlescent_froglight
fill 223 270 505 223 273 505 minecraft:pearlescent_froglight
fill 227 270 463 227 273 463 minecraft:pearlescent_froglight
fill 230 270 468 230 273 468 minecraft:pearlescent_froglight
fill 230 270 476 230 273 476 minecraft:pearlescent_froglight
fill 230 270 484 230 273 484 minecraft:pearlescent_froglight
fill 230 270 492 230 273 492 minecraft:pearlescent_froglight
fill 230 270 500 230 273 500 minecraft:pearlescent_froglight
fill 188 274 468 188 283 468 minecraft:white_terracotta
fill 188 274 476 188 283 476 minecraft:white_terracotta
fill 188 274 484 188 283 484 minecraft:white_terracotta
fill 188 274 492 188 283 492 minecraft:white_terracotta
fill 188 274 500 188 283 500 minecraft:white_terracotta
fill 191 274 505 191 283 505 minecraft:white_terracotta
fill 195 274 463 195 283 463 minecraft:white_terracotta
fill 199 274 505 199 283 505 minecraft:white_terracotta
fill 203 274 463 203 283 463 minecraft:white_terracotta
fill 207 274 505 207 283 505 minecraft:white_terracotta
fill 211 274 463 211 283 463 minecraft:white_terracotta
fill 215 274 505 215 283 505 minecraft:white_terracotta
fill 219 274 463 219 283 463 minecraft:white_terracotta
fill 223 274 505 223 283 505 minecraft:white_terracotta
fill 227 274 463 227 283 463 minecraft:white_terracotta
fill 230 274 468 230 283 468 minecraft:white_terracotta
fill 230 274 476 230 283 476 minecraft:white_terracotta
fill 230 274 484 230 283 484 minecraft:white_terracotta
fill 230 274 492 230 283 492 minecraft:white_terracotta
fill 230 274 500 230 283 500 minecraft:white_terracotta
setblock 191 276 466 minecraft:light[level=11]
setblock 191 276 474 minecraft:light[level=11]
setblock 191 276 482 minecraft:light[level=11]
setblock 191 276 490 minecraft:light[level=11]
setblock 191 276 498 minecraft:light[level=11]
setblock 199 276 466 minecraft:light[level=11]
setblock 199 276 474 minecraft:light[level=11]
setblock 199 276 482 minecraft:light[level=11]
setblock 199 276 490 minecraft:light[level=11]
setblock 199 276 498 minecraft:light[level=11]
setblock 207 276 466 minecraft:light[level=11]
setblock 207 276 474 minecraft:light[level=11]
setblock 207 276 482 minecraft:light[level=11]
setblock 207 276 490 minecraft:light[level=11]
setblock 207 276 498 minecraft:light[level=11]
setblock 215 276 466 minecraft:light[level=11]
setblock 215 276 474 minecraft:light[level=11]
setblock 215 276 482 minecraft:light[level=11]
setblock 215 276 490 minecraft:light[level=11]
setblock 215 276 498 minecraft:light[level=11]
setblock 223 276 466 minecraft:light[level=11]
setblock 223 276 474 minecraft:light[level=11]
setblock 223 276 482 minecraft:light[level=11]
setblock 223 276 490 minecraft:light[level=11]
setblock 223 276 498 minecraft:light[level=11]
fill 201 279 482 208 279 482 minecraft:pearlescent_froglight
fill 202 279 478 209 279 481 minecraft:pearlescent_froglight
fill 202 279 483 209 279 486 minecraft:pearlescent_froglight
fill 203 279 476 219 279 477 minecraft:pearlescent_froglight
fill 203 279 487 219 279 488 minecraft:pearlescent_froglight
fill 204 279 475 218 279 475 minecraft:pearlescent_froglight
fill 204 279 489 218 279 489 minecraft:pearlescent_froglight
fill 205 279 474 217 279 474 minecraft:pearlescent_froglight
fill 205 279 490 217 279 490 minecraft:pearlescent_froglight
fill 207 279 473 215 279 473 minecraft:pearlescent_froglight
fill 207 279 491 215 279 491 minecraft:pearlescent_froglight
fill 210 279 478 210 280 480 minecraft:pearlescent_froglight
fill 210 279 484 210 280 486 minecraft:pearlescent_froglight
setblock 211 279 472 minecraft:pearlescent_froglight
fill 211 279 478 220 279 479 minecraft:pearlescent_froglight
fill 211 279 485 220 279 486 minecraft:pearlescent_froglight
setblock 211 279 492 minecraft:pearlescent_froglight
fill 212 279 480 220 279 480 minecraft:pearlescent_froglight
fill 212 279 484 220 279 484 minecraft:pearlescent_froglight
fill 213 279 481 220 279 481 minecraft:pearlescent_froglight
fill 213 279 483 220 279 483 minecraft:pearlescent_froglight
fill 214 279 482 221 279 482 minecraft:pearlescent_froglight
fill 189 280 464 200 280 504 minecraft:white_terracotta
fill 201 280 464 201 280 481 minecraft:white_terracotta
fill 201 280 482 202 280 482 minecraft:iron_block
fill 201 280 483 201 280 504 minecraft:white_terracotta
fill 202 280 464 202 280 477 minecraft:white_terracotta
fill 202 280 478 202 280 481 minecraft:iron_block
fill 202 280 483 202 280 486 minecraft:iron_block
fill 202 280 487 202 280 504 minecraft:white_terracotta
fill 203 280 464 203 280 475 minecraft:white_terracotta
fill 203 280 476 203 280 478 minecraft:iron_block
fill 203 280 479 204 280 485 minecraft:pearlescent_froglight
fill 203 280 486 203 280 488 minecraft:iron_block
fill 203 280 489 203 280 504 minecraft:white_terracotta
fill 204 280 464 204 280 474 minecraft:white_terracotta
fill 204 280 475 204 280 476 minecraft:iron_block
fill 204 280 477 206 280 478 minecraft:pearlescent_froglight
fill 204 280 486 206 280 487 minecraft:pearlescent_froglight
fill 204 280 488 204 280 489 minecraft:iron_block
fill 204 280 490 204 280 504 minecraft:white_terracotta
fill 205 280 464 206 280 473 minecraft:white_terracotta
fill 205 280 474 205 280 475 minecraft:iron_block
fill 205 280 476 208 280 476 minecraft:pearlescent_froglight
setblock 205 280 479 minecraft:pearlescent_froglight
fill 205 280 480 205 280 484 minecraft:light_gray_concrete
setblock 205 280 485 minecraft:pearlescent_froglight
fill 205 280 488 208 280 488 minecraft:pearlescent_froglight
fill 205 280 489 205 280 490 minecraft:iron_block
fill 205 280 491 206 280 504 minecraft:white_terracotta
fill 206 280 474 207 280 474 minecraft:iron_block
fill 206 280 475 216 280 475 minecraft:pearlescent_froglight
setblock 206 280 479 minecraft:light_gray_concrete
fill 206 280 480 208 280 484 minecraft:pearlescent_froglight
setblock 206 280 485 minecraft:light_gray_concrete
fill 206 280 489 216 280 489 minecraft:pearlescent_froglight
fill 206 280 490 207 280 490 minecraft:iron_block
fill 207 280 464 210 280 472 minecraft:white_terracotta
fill 207 280 473 215 280 473 minecraft:iron_block
setblock 207 280 477 minecraft:pearlescent_froglight
setblock 207 280 478 minecraft:light_gray_concrete
fill 207 280 479 209 280 479 minecraft:pearlescent_froglight
fill 207 280 485 209 280 485 minecraft:pearlescent_froglight
setblock 207 280 486 minecraft:light_gray_concrete
setblock 207 280 487 minecraft:pearlescent_froglight
fill 207 280 491 215 280 491 minecraft:iron_block
fill 207 280 492 210 280 504 minecraft:white_terracotta
fill 208 280 474 214 280 474 minecraft:pearlescent_froglight
setblock 208 280 477 minecraft:light_gray_concrete
fill 208 280 478 209 280 478 minecraft:pearlescent_froglight
fill 208 280 486 209 280 486 minecraft:pearlescent_froglight
setblock 208 280 487 minecraft:light_gray_concrete
fill 208 280 490 214 280 490 minecraft:pearlescent_froglight
fill 209 280 476 213 280 476 minecraft:light_gray_concrete
fill 209 280 477 213 280 477 minecraft:pearlescent_froglight
fill 209 280 480 209 280 481 minecraft:pearlescent_froglight
fill 209 280 483 209 280 484 minecraft:pearlescent_froglight
fill 209 280 487 213 280 487 minecraft:pearlescent_froglight
fill 209 280 488 213 280 488 minecraft:light_gray_concrete
fill 211 280 464 229 280 471 minecraft:white_terracotta
setblock 211 280 472 minecraft:iron_block
fill 211 280 478 214 280 479 minecraft:pearlescent_froglight
fill 211 280 485 214 280 486 minecraft:pearlescent_froglight
setblock 211 280 492 minecraft:iron_block
fill 211 280 493 229 280 504 minecraft:white_terracotta
fill 212 280 472 229 280 472 minecraft:white_terracotta
fill 212 280 480 216 280 480 minecraft:pearlescent_froglight
fill 212 280 484 216 280 484 minecraft:pearlescent_froglight
fill 212 280 492 229 280 492 minecraft:white_terracotta
fill 213 280 481 216 280 481 minecraft:pearlescent_froglight
fill 213 280 483 216 280 483 minecraft:pearlescent_froglight
fill 214 280 476 217 280 476 minecraft:pearlescent_froglight
setblock 214 280 477 minecraft:light_gray_concrete
fill 214 280 482 216 280 482 minecraft:pearlescent_froglight
setblock 214 280 487 minecraft:light_gray_concrete
fill 214 280 488 217 280 488 minecraft:pearlescent_froglight
fill 215 280 474 217 280 474 minecraft:iron_block
fill 215 280 477 218 280 477 minecraft:pearlescent_froglight
setblock 215 280 478 minecraft:light_gray_concrete
setblock 215 280 479 minecraft:pearlescent_froglight
setblock 215 280 485 minecraft:pearlescent_froglight
setblock 215 280 486 minecraft:light_gray_concrete
fill 215 280 487 218 280 487 minecraft:pearlescent_froglight
fill 215 280 490 217 280 490 minecraft:iron_block
fill 216 280 473 229 280 473 minecraft:white_terracotta
fill 216 280 478 218 280 478 minecraft:pearlescent_froglight
setblock 216 280 479 minecraft:light_gray_concrete
setblock 216 280 485 minecraft:light_gray_concrete
fill 216 280 486 218 280 486 minecraft:pearlescent_froglight
fill 216 280 491 229 280 491 minecraft:white_terracotta
fill 217 280 475 218 280 475 minecraft:iron_block
fill 217 280 479 219 280 479 minecraft:pearlescent_froglight
fill 217 280 480 217 280 484 minecraft:light_gray_concrete
fill 217 280 485 219 280 485 minecraft:pearlescent_froglight
fill 217 280 489 218 280 489 minecraft:iron_block
fill 218 280 474 229 280 474 minecraft:white_terracotta
fill 218 280 476 219 280 476 minecraft:iron_block
fill 218 280 480 219 280 484 minecraft:pearlescent_froglight
fill 218 280 488 219 280 488 minecraft:iron_block
fill 218 280 490 229 280 490 minecraft:white_terracotta
fill 219 280 475 229 280 475 minecraft:white_terracotta
fill 219 280 477 219 280 478 minecraft:iron_block
fill 219 280 486 219 280 487 minecraft:iron_block
fill 219 280 489 229 280 489 minecraft:white_terracotta
fill 220 280 476 229 280 477 minecraft:white_terracotta
fill 220 280 478 220 280 486 minecraft:iron_block
fill 220 280 487 229 280 488 minecraft:white_terracotta
fill 221 280 478 229 280 481 minecraft:white_terracotta
setblock 221 280 482 minecraft:iron_block
fill 221 280 483 229 280 486 minecraft:white_terracotta
fill 222 280 482 229 280 482 minecraft:white_terracotta
fill 188 284 468 188 289 468 minecraft:pearlescent_froglight
fill 188 284 476 188 289 476 minecraft:pearlescent_froglight
fill 188 284 484 188 289 484 minecraft:pearlescent_froglight
fill 188 284 492 188 289 492 minecraft:pearlescent_froglight
fill 188 284 500 188 289 500 minecraft:pearlescent_froglight
fill 189 284 470 189 300 471 minecraft:light_gray_concrete
fill 189 284 478 189 300 479 minecraft:light_gray_concrete
fill 189 284 486 189 300 487 minecraft:light_gray_concrete
fill 189 284 494 189 300 495 minecraft:light_gray_concrete
fill 189 284 502 189 300 503 minecraft:light_gray_concrete
fill 190 284 464 191 300 464 minecraft:light_gray_concrete
setblock 191 284 466 minecraft:light[level=11]
setblock 191 284 474 minecraft:light[level=11]
setblock 191 284 482 minecraft:light[level=11]
setblock 191 284 490 minecraft:light[level=11]
setblock 191 284 498 minecraft:light[level=11]
fill 191 284 505 191 289 505 minecraft:pearlescent_froglight
fill 195 284 463 195 289 463 minecraft:pearlescent_froglight
fill 195 284 504 196 300 504 minecraft:light_gray_concrete
fill 198 284 464 199 300 464 minecraft:light_gray_concrete
fill 199 284 465 199 293 465 minecraft:iron_block
setblock 199 284 466 minecraft:light[level=11]
setblock 199 284 474 minecraft:light[level=11]
setblock 199 284 482 minecraft:light[level=11]
setblock 199 284 490 minecraft:light[level=11]
setblock 199 284 498 minecraft:light[level=11]
fill 199 284 505 199 289 505 minecraft:pearlescent_froglight
fill 203 284 463 203 289 463 minecraft:pearlescent_froglight
fill 203 284 504 204 300 504 minecraft:light_gray_concrete
fill 206 284 464 207 300 464 minecraft:light_gray_concrete
setblock 207 284 466 minecraft:light[level=11]
setblock 207 284 474 minecraft:light[level=11]
setblock 207 284 482 minecraft:light[level=11]
setblock 207 284 490 minecraft:light[level=11]
setblock 207 284 498 minecraft:light[level=11]
fill 207 284 505 207 289 505 minecraft:pearlescent_froglight
fill 211 284 463 211 289 463 minecraft:pearlescent_froglight
fill 211 284 504 212 300 504 minecraft:light_gray_concrete
fill 214 284 464 215 300 464 minecraft:light_gray_concrete
setblock 215 284 466 minecraft:light[level=11]
setblock 215 284 474 minecraft:light[level=11]
setblock 215 284 482 minecraft:light[level=11]
setblock 215 284 490 minecraft:light[level=11]
fill 215 284 497 227 285 504 minecraft:light_gray_concrete
fill 215 284 505 215 289 505 minecraft:pearlescent_froglight
fill 219 284 463 219 289 463 minecraft:pearlescent_froglight
fill 222 284 464 223 300 464 minecraft:light_gray_concrete
setblock 223 284 466 minecraft:light[level=11]
setblock 223 284 474 minecraft:light[level=11]
setblock 223 284 482 minecraft:light[level=11]
setblock 223 284 490 minecraft:light[level=11]
fill 223 284 505 223 289 505 minecraft:pearlescent_froglight
fill 227 284 463 227 289 463 minecraft:pearlescent_froglight
fill 228 284 504 228 300 504 minecraft:light_gray_concrete
fill 229 284 465 229 300 466 minecraft:light_gray_concrete
fill 229 284 473 229 300 474 minecraft:light_gray_concrete
fill 229 284 481 229 300 482 minecraft:light_gray_concrete
fill 229 284 489 229 300 490 minecraft:light_gray_concrete
fill 229 284 497 229 300 498 minecraft:light_gray_concrete
fill 230 284 468 230 289 468 minecraft:pearlescent_froglight
fill 230 284 476 230 289 476 minecraft:pearlescent_froglight
fill 230 284 484 230 289 484 minecraft:pearlescent_froglight
fill 230 284 492 230 289 492 minecraft:pearlescent_froglight
fill 230 284 500 230 289 500 minecraft:pearlescent_froglight
fill 215 286 497 215 297 497 minecraft:light_gray_concrete
setblock 215 286 498 minecraft:pearlescent_froglight
fill 215 286 499 215 297 499 minecraft:light_gray_concrete
setblock 215 286 500 minecraft:pearlescent_froglight
fill 215 286 501 215 297 501 minecraft:light_gray_concrete
setblock 215 286 502 minecraft:pearlescent_froglight
fill 215 286 503 215 297 503 minecraft:light_gray_concrete
setblock 215 286 504 minecraft:pearlescent_froglight
setblock 216 286 497 minecraft:pearlescent_froglight
fill 216 286 498 216 297 498 minecraft:light_gray_concrete
setblock 216 286 499 minecraft:pearlescent_froglight
fill 216 286 500 216 297 500 minecraft:light_gray_concrete
setblock 216 286 501 minecraft:pearlescent_froglight
fill 216 286 502 216 297 502 minecraft:light_gray_concrete
setblock 216 286 503 minecraft:pearlescent_froglight
fill 216 286 504 216 297 504 minecraft:light_gray_concrete
fill 217 286 497 217 297 497 minecraft:light_gray_concrete
setblock 217 286 498 minecraft:pearlescent_froglight
fill 217 286 499 217 297 499 minecraft:light_gray_concrete
setblock 217 286 500 minecraft:pearlescent_froglight
fill 217 286 501 217 297 501 minecraft:light_gray_concrete
setblock 217 286 502 minecraft:pearlescent_froglight
fill 217 286 503 217 297 503 minecraft:light_gray_concrete
setblock 217 286 504 minecraft:pearlescent_froglight
setblock 218 286 497 minecraft:pearlescent_froglight
fill 218 286 498 218 297 498 minecraft:light_gray_concrete
setblock 218 286 499 minecraft:pearlescent_froglight
fill 218 286 500 218 297 500 minecraft:light_gray_concrete
setblock 218 286 501 minecraft:pearlescent_froglight
fill 218 286 502 218 297 502 minecraft:light_gray_concrete
setblock 218 286 503 minecraft:pearlescent_froglight
fill 218 286 504 218 297 504 minecraft:light_gray_concrete
fill 219 286 497 219 297 497 minecraft:light_gray_concrete
setblock 219 286 498 minecraft:pearlescent_froglight
fill 219 286 499 219 297 499 minecraft:light_gray_concrete
setblock 219 286 500 minecraft:pearlescent_froglight
fill 219 286 501 219 297 501 minecraft:light_gray_concrete
setblock 219 286 502 minecraft:pearlescent_froglight
fill 219 286 503 219 297 503 minecraft:light_gray_concrete
setblock 219 286 504 minecraft:pearlescent_froglight
setblock 220 286 497 minecraft:pearlescent_froglight
fill 220 286 498 220 297 498 minecraft:light_gray_concrete
setblock 220 286 499 minecraft:pearlescent_froglight
fill 220 286 500 220 297 500 minecraft:light_gray_concrete
setblock 220 286 501 minecraft:pearlescent_froglight
fill 220 286 502 220 297 502 minecraft:light_gray_concrete
setblock 220 286 503 minecraft:pearlescent_froglight
fill 220 286 504 220 300 504 minecraft:light_gray_concrete
fill 221 286 497 221 297 497 minecraft:light_gray_concrete
setblock 221 286 498 minecraft:pearlescent_froglight
fill 221 286 499 221 297 499 minecraft:light_gray_concrete
setblock 221 286 500 minecraft:pearlescent_froglight
fill 221 286 501 221 297 501 minecraft:light_gray_concrete
setblock 221 286 502 minecraft:pearlescent_froglight
fill 221 286 503 221 297 503 minecraft:light_gray_concrete
setblock 221 286 504 minecraft:pearlescent_froglight
setblock 222 286 497 minecraft:pearlescent_froglight
fill 222 286 498 222 297 498 minecraft:light_gray_concrete
setblock 222 286 499 minecraft:pearlescent_froglight
fill 222 286 500 222 297 500 minecraft:light_gray_concrete
setblock 222 286 501 minecraft:pearlescent_froglight
fill 222 286 502 222 297 502 minecraft:light_gray_concrete
setblock 222 286 503 minecraft:pearlescent_froglight
fill 222 286 504 222 297 504 minecraft:light_gray_concrete
fill 223 286 497 223 297 497 minecraft:light_gray_concrete
setblock 223 286 498 minecraft:pearlescent_froglight
fill 223 286 499 223 297 499 minecraft:light_gray_concrete
setblock 223 286 500 minecraft:pearlescent_froglight
fill 223 286 501 223 297 501 minecraft:light_gray_concrete
setblock 223 286 502 minecraft:pearlescent_froglight
fill 223 286 503 223 297 503 minecraft:light_gray_concrete
setblock 223 286 504 minecraft:pearlescent_froglight
setblock 224 286 497 minecraft:pearlescent_froglight
fill 224 286 498 224 297 498 minecraft:light_gray_concrete
setblock 224 286 499 minecraft:pearlescent_froglight
fill 224 286 500 224 297 500 minecraft:light_gray_concrete
setblock 224 286 501 minecraft:pearlescent_froglight
fill 224 286 502 224 297 502 minecraft:light_gray_concrete
setblock 224 286 503 minecraft:pearlescent_froglight
fill 224 286 504 224 297 504 minecraft:light_gray_concrete
fill 225 286 497 225 297 497 minecraft:light_gray_concrete
setblock 225 286 498 minecraft:pearlescent_froglight
fill 225 286 499 225 297 499 minecraft:light_gray_concrete
setblock 225 286 500 minecraft:pearlescent_froglight
fill 225 286 501 225 297 501 minecraft:light_gray_concrete
setblock 225 286 502 minecraft:pearlescent_froglight
fill 225 286 503 225 297 503 minecraft:light_gray_concrete
setblock 225 286 504 minecraft:pearlescent_froglight
setblock 226 286 497 minecraft:pearlescent_froglight
fill 226 286 498 226 297 498 minecraft:light_gray_concrete
setblock 226 286 499 minecraft:pearlescent_froglight
fill 226 286 500 226 297 500 minecraft:light_gray_concrete
setblock 226 286 501 minecraft:pearlescent_froglight
fill 226 286 502 226 297 502 minecraft:light_gray_concrete
setblock 226 286 503 minecraft:pearlescent_froglight
fill 226 286 504 226 297 504 minecraft:light_gray_concrete
fill 227 286 497 227 297 497 minecraft:light_gray_concrete
setblock 227 286 498 minecraft:pearlescent_froglight
fill 227 286 499 227 297 499 minecraft:light_gray_concrete
setblock 227 286 500 minecraft:pearlescent_froglight
fill 227 286 501 227 297 501 minecraft:light_gray_concrete
setblock 227 286 502 minecraft:pearlescent_froglight
fill 227 286 503 227 297 503 minecraft:light_gray_concrete
setblock 227 286 504 minecraft:pearlescent_froglight
fill 215 287 498 215 288 498 minecraft:light_gray_concrete
fill 215 287 500 215 288 500 minecraft:light_gray_concrete
fill 215 287 502 215 288 502 minecraft:light_gray_concrete
fill 215 287 504 215 288 504 minecraft:light_gray_concrete
fill 216 287 497 216 288 497 minecraft:light_gray_concrete
fill 216 287 499 216 288 499 minecraft:light_gray_concrete
fill 216 287 501 216 288 501 minecraft:light_gray_concrete
fill 216 287 503 216 288 503 minecraft:light_gray_concrete
fill 217 287 498 217 288 498 minecraft:light_gray_concrete
fill 217 287 500 217 288 500 minecraft:light_gray_concrete
fill 217 287 502 217 288 502 minecraft:light_gray_concrete
fill 217 287 504 217 288 504 minecraft:light_gray_concrete
fill 218 287 497 218 288 497 minecraft:light_gray_concrete
fill 218 287 499 218 288 499 minecraft:light_gray_concrete
fill 218 287 501 218 288 501 minecraft:light_gray_concrete
fill 218 287 503 218 288 503 minecraft:light_gray_concrete
fill 219 287 498 219 288 498 minecraft:light_gray_concrete
fill 219 287 500 219 288 500 minecraft:light_gray_concrete
fill 219 287 502 219 288 502 minecraft:light_gray_concrete
fill 219 287 504 219 288 504 minecraft:light_gray_concrete
fill 220 287 497 220 288 497 minecraft:light_gray_concrete
fill 220 287 499 220 288 499 minecraft:light_gray_concrete
fill 220 287 501 220 288 501 minecraft:light_gray_concrete
fill 220 287 503 220 288 503 minecraft:light_gray_concrete
fill 221 287 498 221 288 498 minecraft:light_gray_concrete
fill 221 287 500 221 288 500 minecraft:light_gray_concrete
fill 221 287 502 221 288 502 minecraft:light_gray_concrete
fill 221 287 504 221 288 504 minecraft:light_gray_concrete
fill 222 287 497 222 288 497 minecraft:light_gray_concrete
fill 222 287 499 222 288 499 minecraft:light_gray_concrete
fill 222 287 501 222 288 501 minecraft:light_gray_concrete
fill 222 287 503 222 288 503 minecraft:light_gray_concrete
fill 223 287 498 223 288 498 minecraft:light_gray_concrete
fill 223 287 500 223 288 500 minecraft:light_gray_concrete
fill 223 287 502 223 288 502 minecraft:light_gray_concrete
fill 223 287 504 223 288 504 minecraft:light_gray_concrete
fill 224 287 497 224 288 497 minecraft:light_gray_concrete
fill 224 287 499 224 288 499 minecraft:light_gray_concrete
fill 224 287 501 224 288 501 minecraft:light_gray_concrete
fill 224 287 503 224 288 503 minecraft:light_gray_concrete
fill 225 287 498 225 288 498 minecraft:light_gray_concrete
fill 225 287 500 225 288 500 minecraft:light_gray_concrete
fill 225 287 502 225 288 502 minecraft:light_gray_concrete
fill 225 287 504 225 288 504 minecraft:light_gray_concrete
fill 226 287 497 226 288 497 minecraft:light_gray_concrete
fill 226 287 499 226 288 499 minecraft:light_gray_concrete
fill 226 287 501 226 288 501 minecraft:light_gray_concrete
fill 226 287 503 226 288 503 minecraft:light_gray_concrete
fill 227 287 498 227 288 498 minecraft:light_gray_concrete
fill 227 287 500 227 288 500 minecraft:light_gray_concrete
fill 227 287 502 227 288 502 minecraft:light_gray_concrete
fill 227 287 504 227 288 504 minecraft:light_gray_concrete
fill 213 289 466 214 290 467 minecraft:white_wool
setblock 215 289 498 minecraft:pearlescent_froglight
setblock 215 289 500 minecraft:pearlescent_froglight
setblock 215 289 502 minecraft:pearlescent_froglight
setblock 215 289 504 minecraft:pearlescent_froglight
setblock 216 289 497 minecraft:pearlescent_froglight
setblock 216 289 499 minecraft:pearlescent_froglight
setblock 216 289 501 minecraft:pearlescent_froglight
setblock 216 289 503 minecraft:pearlescent_froglight
setblock 217 289 498 minecraft:pearlescent_froglight
setblock 217 289 500 minecraft:pearlescent_froglight
setblock 217 289 502 minecraft:pearlescent_froglight
setblock 217 289 504 minecraft:pearlescent_froglight
setblock 218 289 497 minecraft:pearlescent_froglight
setblock 218 289 499 minecraft:pearlescent_froglight
setblock 218 289 501 minecraft:pearlescent_froglight
setblock 218 289 503 minecraft:pearlescent_froglight
setblock 219 289 498 minecraft:pearlescent_froglight
setblock 219 289 500 minecraft:pearlescent_froglight
setblock 219 289 502 minecraft:pearlescent_froglight
setblock 219 289 504 minecraft:pearlescent_froglight
setblock 220 289 497 minecraft:pearlescent_froglight
setblock 220 289 499 minecraft:pearlescent_froglight
setblock 220 289 501 minecraft:pearlescent_froglight
setblock 220 289 503 minecraft:pearlescent_froglight
setblock 221 289 498 minecraft:pearlescent_froglight
setblock 221 289 500 minecraft:pearlescent_froglight
setblock 221 289 502 minecraft:pearlescent_froglight
setblock 221 289 504 minecraft:pearlescent_froglight
setblock 222 289 497 minecraft:pearlescent_froglight
setblock 222 289 499 minecraft:pearlescent_froglight
setblock 222 289 501 minecraft:pearlescent_froglight
setblock 222 289 503 minecraft:pearlescent_froglight
setblock 223 289 498 minecraft:pearlescent_froglight
setblock 223 289 500 minecraft:pearlescent_froglight
setblock 223 289 502 minecraft:pearlescent_froglight
setblock 223 289 504 minecraft:pearlescent_froglight
setblock 224 289 497 minecraft:pearlescent_froglight
setblock 224 289 499 minecraft:pearlescent_froglight
setblock 224 289 501 minecraft:pearlescent_froglight
setblock 224 289 503 minecraft:pearlescent_froglight
setblock 225 289 498 minecraft:pearlescent_froglight
setblock 225 289 500 minecraft:pearlescent_froglight
setblock 225 289 502 minecraft:pearlescent_froglight
setblock 225 289 504 minecraft:pearlescent_froglight
setblock 226 289 497 minecraft:pearlescent_froglight
setblock 226 289 499 minecraft:pearlescent_froglight
setblock 226 289 501 minecraft:pearlescent_froglight
setblock 226 289 503 minecraft:pearlescent_froglight
setblock 227 289 498 minecraft:pearlescent_froglight
setblock 227 289 500 minecraft:pearlescent_froglight
setblock 227 289 502 minecraft:pearlescent_froglight
setblock 227 289 504 minecraft:pearlescent_froglight
fill 188 290 468 188 297 468 minecraft:white_terracotta
fill 188 290 476 188 297 476 minecraft:white_terracotta
fill 188 290 484 188 297 484 minecraft:white_terracotta
fill 188 290 492 188 297 492 minecraft:white_terracotta
fill 188 290 500 188 297 500 minecraft:white_terracotta
fill 191 290 505 191 297 505 minecraft:white_terracotta
fill 195 290 463 195 297 463 minecraft:white_terracotta
fill 199 290 505 199 297 505 minecraft:white_terracotta
fill 203 290 463 203 297 463 minecraft:white_terracotta
fill 207 290 505 207 297 505 minecraft:white_terracotta
fill 211 290 463 211 297 463 minecraft:white_terracotta
fill 215 290 498 215 291 498 minecraft:light_gray_concrete
fill 215 290 500 215 291 500 minecraft:light_gray_concrete
fill 215 290 502 215 291 502 minecraft:light_gray_concrete
fill 215 290 504 215 291 504 minecraft:light_gray_concrete
fill 215 290 505 215 297 505 minecraft:white_terracotta
fill 216 290 497 216 291 497 minecraft:light_gray_concrete
fill 216 290 499 216 291 499 minecraft:light_gray_concrete
fill 216 290 501 216 291 501 minecraft:light_gray_concrete
fill 216 290 503 216 291 503 minecraft:light_gray_concrete
fill 217 290 498 217 291 498 minecraft:light_gray_concrete
fill 217 290 500 217 291 500 minecraft:light_gray_concrete
fill 217 290 502 217 291 502 minecraft:light_gray_concrete
fill 217 290 504 217 291 504 minecraft:light_gray_concrete
fill 218 290 497 218 291 497 minecraft:light_gray_concrete
fill 218 290 499 218 291 499 minecraft:light_gray_concrete
fill 218 290 501 218 291 501 minecraft:light_gray_concrete
fill 218 290 503 218 291 503 minecraft:light_gray_concrete
fill 219 290 463 219 297 463 minecraft:white_terracotta
fill 219 290 498 219 291 498 minecraft:light_gray_concrete
fill 219 290 500 219 291 500 minecraft:light_gray_concrete
fill 219 290 502 219 291 502 minecraft:light_gray_concrete
fill 219 290 504 219 291 504 minecraft:light_gray_concrete
fill 220 290 497 220 291 497 minecraft:light_gray_concrete
fill 220 290 499 220 291 499 minecraft:light_gray_concrete
fill 220 290 501 220 291 501 minecraft:light_gray_concrete
fill 220 290 503 220 291 503 minecraft:light_gray_concrete
fill 221 290 498 221 291 498 minecraft:light_gray_concrete
fill 221 290 500 221 291 500 minecraft:light_gray_concrete
fill 221 290 502 221 291 502 minecraft:light_gray_concrete
fill 221 290 504 221 291 504 minecraft:light_gray_concrete
fill 222 290 497 222 291 497 minecraft:light_gray_concrete
fill 222 290 499 222 291 499 minecraft:light_gray_concrete
fill 222 290 501 222 291 501 minecraft:light_gray_concrete
fill 222 290 503 222 291 503 minecraft:light_gray_concrete
fill 223 290 498 223 291 498 minecraft:light_gray_concrete
fill 223 290 500 223 291 500 minecraft:light_gray_concrete
fill 223 290 502 223 291 502 minecraft:light_gray_concrete
fill 223 290 504 223 291 504 minecraft:light_gray_concrete
fill 223 290 505 223 297 505 minecraft:white_terracotta
fill 224 290 497 224 291 497 minecraft:light_gray_concrete
fill 224 290 499 224 291 499 minecraft:light_gray_concrete
fill 224 290 501 224 291 501 minecraft:light_gray_concrete
fill 224 290 503 224 291 503 minecraft:light_gray_concrete
fill 225 290 498 225 291 498 minecraft:light_gray_concrete
fill 225 290 500 225 291 500 minecraft:light_gray_concrete
fill 225 290 502 225 291 502 minecraft:light_gray_concrete
fill 225 290 504 225 291 504 minecraft:light_gray_concrete
fill 226 290 497 226 291 497 minecraft:light_gray_concrete
fill 226 290 499 226 291 499 minecraft:light_gray_concrete
fill 226 290 501 226 291 501 minecraft:light_gray_concrete
fill 226 290 503 226 291 503 minecraft:light_gray_concrete
fill 227 290 463 227 297 463 minecraft:white_terracotta
fill 227 290 498 227 291 498 minecraft:light_gray_concrete
fill 227 290 500 227 291 500 minecraft:light_gray_concrete
fill 227 290 502 227 291 502 minecraft:light_gray_concrete
fill 227 290 504 227 291 504 minecraft:light_gray_concrete
fill 230 290 468 230 297 468 minecraft:white_terracotta
fill 230 290 476 230 297 476 minecraft:white_terracotta
fill 230 290 484 230 297 484 minecraft:white_terracotta
fill 230 290 492 230 297 492 minecraft:white_terracotta
fill 230 290 500 230 297 500 minecraft:white_terracotta
setblock 191 292 466 minecraft:light[level=11]
setblock 191 292 474 minecraft:light[level=11]
setblock 191 292 482 minecraft:light[level=11]
setblock 191 292 490 minecraft:light[level=11]
setblock 191 292 498 minecraft:light[level=11]
setblock 199 292 466 minecraft:light[level=11]
setblock 199 292 474 minecraft:light[level=11]
setblock 199 292 482 minecraft:light[level=11]
setblock 199 292 490 minecraft:light[level=11]
setblock 199 292 498 minecraft:light[level=11]
setblock 207 292 466 minecraft:light[level=11]
setblock 207 292 474 minecraft:light[level=11]
setblock 207 292 482 minecraft:light[level=11]
setblock 207 292 490 minecraft:light[level=11]
setblock 207 292 498 minecraft:light[level=11]
setblock 215 292 466 minecraft:light[level=11]
setblock 215 292 474 minecraft:light[level=11]
setblock 215 292 482 minecraft:light[level=11]
setblock 215 292 490 minecraft:light[level=11]
setblock 215 292 498 minecraft:pearlescent_froglight
setblock 215 292 500 minecraft:pearlescent_froglight
setblock 215 292 502 minecraft:pearlescent_froglight
setblock 215 292 504 minecraft:pearlescent_froglight
fill 216 292 495 217 293 496 minecraft:red_concrete
setblock 216 292 497 minecraft:pearlescent_froglight
setblock 216 292 499 minecraft:pearlescent_froglight
setblock 216 292 501 minecraft:pearlescent_froglight
setblock 216 292 503 minecraft:pearlescent_froglight
setblock 217 292 498 minecraft:pearlescent_froglight
setblock 217 292 500 minecraft:pearlescent_froglight
setblock 217 292 502 minecraft:pearlescent_froglight
setblock 217 292 504 minecraft:pearlescent_froglight
setblock 218 292 497 minecraft:pearlescent_froglight
setblock 218 292 499 minecraft:pearlescent_froglight
setblock 218 292 501 minecraft:pearlescent_froglight
setblock 218 292 503 minecraft:pearlescent_froglight
setblock 219 292 498 minecraft:pearlescent_froglight
setblock 219 292 500 minecraft:pearlescent_froglight
setblock 219 292 502 minecraft:pearlescent_froglight
setblock 219 292 504 minecraft:pearlescent_froglight
setblock 220 292 497 minecraft:pearlescent_froglight
setblock 220 292 499 minecraft:pearlescent_froglight
setblock 220 292 501 minecraft:pearlescent_froglight
setblock 220 292 503 minecraft:pearlescent_froglight
setblock 221 292 498 minecraft:pearlescent_froglight
setblock 221 292 500 minecraft:pearlescent_froglight
setblock 221 292 502 minecraft:pearlescent_froglight
setblock 221 292 504 minecraft:pearlescent_froglight
setblock 222 292 497 minecraft:pearlescent_froglight
setblock 222 292 499 minecraft:pearlescent_froglight
setblock 222 292 501 minecraft:pearlescent_froglight
setblock 222 292 503 minecraft:pearlescent_froglight
setblock 223 292 466 minecraft:light[level=11]
setblock 223 292 474 minecraft:light[level=11]
setblock 223 292 482 minecraft:light[level=11]
setblock 223 292 490 minecraft:light[level=11]
setblock 223 292 498 minecraft:pearlescent_froglight
setblock 223 292 500 minecraft:pearlescent_froglight
setblock 223 292 502 minecraft:pearlescent_froglight
setblock 223 292 504 minecraft:pearlescent_froglight
setblock 224 292 497 minecraft:pearlescent_froglight
setblock 224 292 499 minecraft:pearlescent_froglight
setblock 224 292 501 minecraft:pearlescent_froglight
setblock 224 292 503 minecraft:pearlescent_froglight
setblock 225 292 498 minecraft:pearlescent_froglight
setblock 225 292 500 minecraft:pearlescent_froglight
setblock 225 292 502 minecraft:pearlescent_froglight
setblock 225 292 504 minecraft:pearlescent_froglight
setblock 226 292 497 minecraft:pearlescent_froglight
setblock 226 292 499 minecraft:pearlescent_froglight
setblock 226 292 501 minecraft:pearlescent_froglight
setblock 226 292 503 minecraft:pearlescent_froglight
setblock 227 292 498 minecraft:pearlescent_froglight
setblock 227 292 500 minecraft:pearlescent_froglight
setblock 227 292 502 minecraft:pearlescent_froglight
setblock 227 292 504 minecraft:pearlescent_froglight
fill 215 293 498 215 294 498 minecraft:light_gray_concrete
fill 215 293 500 215 294 500 minecraft:light_gray_concrete
fill 215 293 502 215 294 502 minecraft:light_gray_concrete
fill 215 293 504 215 294 504 minecraft:light_gray_concrete
fill 216 293 497 216 294 497 minecraft:light_gray_concrete
fill 216 293 499 216 294 499 minecraft:light_gray_concrete
fill 216 293 501 216 294 501 minecraft:light_gray_concrete
fill 216 293 503 216 294 503 minecraft:light_gray_concrete
fill 217 293 498 217 294 498 minecraft:light_gray_concrete
fill 217 293 500 217 294 500 minecraft:light_gray_concrete
fill 217 293 502 217 294 502 minecraft:light_gray_concrete
fill 217 293 504 217 294 504 minecraft:light_gray_concrete
fill 218 293 497 218 294 497 minecraft:light_gray_concrete
fill 218 293 499 218 294 499 minecraft:light_gray_concrete
fill 218 293 501 218 294 501 minecraft:light_gray_concrete
fill 218 293 503 218 294 503 minecraft:light_gray_concrete
fill 219 293 498 219 294 498 minecraft:light_gray_concrete
fill 219 293 500 219 294 500 minecraft:light_gray_concrete
fill 219 293 502 219 294 502 minecraft:light_gray_concrete
fill 219 293 504 219 294 504 minecraft:light_gray_concrete
fill 220 293 497 220 294 497 minecraft:light_gray_concrete
fill 220 293 499 220 294 499 minecraft:light_gray_concrete
fill 220 293 501 220 294 501 minecraft:light_gray_concrete
fill 220 293 503 220 294 503 minecraft:light_gray_concrete
fill 221 293 498 221 294 498 minecraft:light_gray_concrete
fill 221 293 500 221 294 500 minecraft:light_gray_concrete
fill 221 293 502 221 294 502 minecraft:light_gray_concrete
fill 221 293 504 221 294 504 minecraft:light_gray_concrete
fill 222 293 497 222 294 497 minecraft:light_gray_concrete
fill 222 293 499 222 294 499 minecraft:light_gray_concrete
fill 222 293 501 222 294 501 minecraft:light_gray_concrete
fill 222 293 503 222 294 503 minecraft:light_gray_concrete
fill 223 293 498 223 294 498 minecraft:light_gray_concrete
fill 223 293 500 223 294 500 minecraft:light_gray_concrete
fill 223 293 502 223 294 502 minecraft:light_gray_concrete
fill 223 293 504 223 294 504 minecraft:light_gray_concrete
fill 224 293 497 224 294 497 minecraft:light_gray_concrete
fill 224 293 499 224 294 499 minecraft:light_gray_concrete
fill 224 293 501 224 294 501 minecraft:light_gray_concrete
fill 224 293 503 224 294 503 minecraft:light_gray_concrete
fill 225 293 498 225 294 498 minecraft:light_gray_concrete
fill 225 293 500 225 294 500 minecraft:light_gray_concrete
fill 225 293 502 225 294 502 minecraft:light_gray_concrete
fill 225 293 504 225 294 504 minecraft:light_gray_concrete
fill 226 293 497 226 294 497 minecraft:light_gray_concrete
fill 226 293 499 226 294 499 minecraft:light_gray_concrete
fill 226 293 501 226 294 501 minecraft:light_gray_concrete
fill 226 293 503 226 294 503 minecraft:light_gray_concrete
fill 227 293 498 227 294 498 minecraft:light_gray_concrete
fill 227 293 500 227 294 500 minecraft:light_gray_concrete
fill 227 293 502 227 294 502 minecraft:light_gray_concrete
fill 227 293 504 227 294 504 minecraft:light_gray_concrete
fill 189 294 464 189 295 469 minecraft:light_gray_concrete
fill 189 294 472 190 294 477 minecraft:light_gray_concrete
fill 189 294 480 190 294 485 minecraft:light_gray_concrete
fill 189 294 488 190 294 493 minecraft:light_gray_concrete
fill 189 294 496 190 294 501 minecraft:light_gray_concrete
fill 189 294 504 194 295 504 minecraft:light_gray_concrete
fill 190 294 465 190 294 471 minecraft:light_gray_concrete
fill 190 294 478 190 294 479 minecraft:light_gray_concrete
fill 190 294 486 190 294 487 minecraft:light_gray_concrete
fill 190 294 494 190 294 495 minecraft:light_gray_concrete
fill 190 294 502 190 294 503 minecraft:light_gray_concrete
fill 191 294 465 228 294 465 minecraft:light_gray_concrete
fill 191 294 503 214 294 503 minecraft:light_gray_concrete
fill 192 294 464 197 295 464 minecraft:light_gray_concrete
fill 197 294 504 202 295 504 minecraft:light_gray_concrete
fill 200 294 464 205 295 464 minecraft:light_gray_concrete
fill 205 294 504 210 295 504 minecraft:light_gray_concrete
fill 208 294 464 213 295 464 minecraft:light_gray_concrete
fill 213 294 504 214 295 504 minecraft:light_gray_concrete
fill 216 294 464 221 295 464 minecraft:light_gray_concrete
fill 224 294 464 229 295 464 minecraft:light_gray_concrete
fill 228 294 466 228 294 503 minecraft:light_gray_concrete
fill 229 294 467 229 295 472 minecraft:light_gray_concrete
fill 229 294 475 229 295 480 minecraft:light_gray_concrete
fill 229 294 483 229 295 488 minecraft:light_gray_concrete
fill 229 294 491 229 295 496 minecraft:light_gray_concrete
fill 229 294 499 229 295 504 minecraft:light_gray_concrete
fill 189 295 472 189 295 477 minecraft:light_gray_concrete
fill 189 295 480 189 295 485 minecraft:light_gray_concrete
fill 189 295 488 189 295 493 minecraft:light_gray_concrete
fill 189 295 496 189 295 501 minecraft:light_gray_concrete
fill 199 295 465 199 296 465 minecraft:iron_block
setblock 215 295 498 minecraft:pearlescent_froglight
setblock 215 295 500 minecraft:pearlescent_froglight
setblock 215 295 502 minecraft:pearlescent_froglight
setblock 215 295 504 minecraft:pearlescent_froglight
setblock 216 295 497 minecraft:pearlescent_froglight
setblock 216 295 499 minecraft:pearlescent_froglight
setblock 216 295 501 minecraft:pearlescent_froglight
setblock 216 295 503 minecraft:pearlescent_froglight
setblock 217 295 498 minecraft:pearlescent_froglight
setblock 217 295 500 minecraft:pearlescent_froglight
setblock 217 295 502 minecraft:pearlescent_froglight
setblock 217 295 504 minecraft:pearlescent_froglight
setblock 218 295 497 minecraft:pearlescent_froglight
setblock 218 295 499 minecraft:pearlescent_froglight
setblock 218 295 501 minecraft:pearlescent_froglight
setblock 218 295 503 minecraft:pearlescent_froglight
setblock 219 295 498 minecraft:pearlescent_froglight
setblock 219 295 500 minecraft:pearlescent_froglight
setblock 219 295 502 minecraft:pearlescent_froglight
setblock 219 295 504 minecraft:pearlescent_froglight
setblock 220 295 497 minecraft:pearlescent_froglight
setblock 220 295 499 minecraft:pearlescent_froglight
setblock 220 295 501 minecraft:pearlescent_froglight
setblock 220 295 503 minecraft:pearlescent_froglight
setblock 221 295 498 minecraft:pearlescent_froglight
setblock 221 295 500 minecraft:pearlescent_froglight
setblock 221 295 502 minecraft:pearlescent_froglight
setblock 221 295 504 minecraft:pearlescent_froglight
setblock 222 295 497 minecraft:pearlescent_froglight
setblock 222 295 499 minecraft:pearlescent_froglight
setblock 222 295 501 minecraft:pearlescent_froglight
setblock 222 295 503 minecraft:pearlescent_froglight
setblock 223 295 498 minecraft:pearlescent_froglight
setblock 223 295 500 minecraft:pearlescent_froglight
setblock 223 295 502 minecraft:pearlescent_froglight
setblock 223 295 504 minecraft:pearlescent_froglight
setblock 224 295 497 minecraft:pearlescent_froglight
setblock 224 295 499 minecraft:pearlescent_froglight
setblock 224 295 501 minecraft:pearlescent_froglight
setblock 224 295 503 minecraft:pearlescent_froglight
setblock 225 295 498 minecraft:pearlescent_froglight
setblock 225 295 500 minecraft:pearlescent_froglight
setblock 225 295 502 minecraft:pearlescent_froglight
setblock 225 295 504 minecraft:pearlescent_froglight
setblock 226 295 497 minecraft:pearlescent_froglight
setblock 226 295 499 minecraft:pearlescent_froglight
setblock 226 295 501 minecraft:pearlescent_froglight
setblock 226 295 503 minecraft:pearlescent_froglight
setblock 227 295 498 minecraft:pearlescent_froglight
setblock 227 295 500 minecraft:pearlescent_froglight
setblock 227 295 502 minecraft:pearlescent_froglight
setblock 227 295 504 minecraft:pearlescent_froglight
fill 215 296 498 215 297 498 minecraft:light_gray_concrete
fill 215 296 500 215 297 500 minecraft:light_gray_concrete
fill 215 296 502 215 297 502 minecraft:light_gray_concrete
fill 215 296 504 215 297 504 minecraft:light_gray_concrete
fill 216 296 497 216 297 497 minecraft:light_gray_concrete
fill 216 296 499 216 297 499 minecraft:light_gray_concrete
fill 216 296 501 216 297 501 minecraft:light_gray_concrete
fill 216 296 503 216 297 503 minecraft:light_gray_concrete
fill 217 296 498 217 297 498 minecraft:light_gray_concrete
fill 217 296 500 217 297 500 minecraft:light_gray_concrete
fill 217 296 502 217 297 502 minecraft:light_gray_concrete
fill 217 296 504 217 297 504 minecraft:light_gray_concrete
fill 218 296 497 218 297 497 minecraft:light_gray_concrete
fill 218 296 499 218 297 499 minecraft:light_gray_concrete
fill 218 296 501 218 297 501 minecraft:light_gray_concrete
fill 218 296 503 218 297 503 minecraft:light_gray_concrete
fill 219 296 498 219 297 498 minecraft:light_gray_concrete
fill 219 296 500 219 297 500 minecraft:light_gray_concrete
fill 219 296 502 219 297 502 minecraft:light_gray_concrete
fill 219 296 504 219 300 504 minecraft:light_gray_concrete
fill 220 296 497 220 297 497 minecraft:light_gray_concrete
fill 220 296 499 220 297 499 minecraft:light_gray_concrete
fill 220 296 501 220 297 501 minecraft:light_gray_concrete
fill 220 296 503 220 297 503 minecraft:light_gray_concrete
fill 221 296 498 221 297 498 minecraft:light_gray_concrete
fill 221 296 500 221 297 500 minecraft:light_gray_concrete
fill 221 296 502 221 297 502 minecraft:light_gray_concrete
fill 221 296 504 221 297 504 minecraft:light_gray_concrete
fill 222 296 497 222 297 497 minecraft:light_gray_concrete
fill 222 296 499 222 297 499 minecraft:light_gray_concrete
fill 222 296 501 222 297 501 minecraft:light_gray_concrete
fill 222 296 503 222 297 503 minecraft:light_gray_concrete
fill 223 296 498 223 297 498 minecraft:light_gray_concrete
fill 223 296 500 223 297 500 minecraft:light_gray_concrete
fill 223 296 502 223 297 502 minecraft:light_gray_concrete
fill 223 296 504 223 297 504 minecraft:light_gray_concrete
fill 224 296 497 224 297 497 minecraft:light_gray_concrete
fill 224 296 499 224 297 499 minecraft:light_gray_concrete
fill 224 296 501 224 297 501 minecraft:light_gray_concrete
fill 224 296 503 224 297 503 minecraft:light_gray_concrete
fill 225 296 498 225 297 498 minecraft:light_gray_concrete
fill 225 296 500 225 297 500 minecraft:light_gray_concrete
fill 225 296 502 225 297 502 minecraft:light_gray_concrete
fill 225 296 504 225 297 504 minecraft:light_gray_concrete
fill 226 296 497 226 297 497 minecraft:light_gray_concrete
fill 226 296 499 226 297 499 minecraft:light_gray_concrete
fill 226 296 501 226 297 501 minecraft:light_gray_concrete
fill 226 296 503 226 297 503 minecraft:light_gray_concrete
fill 227 296 498 227 297 498 minecraft:light_gray_concrete
fill 227 296 500 227 297 500 minecraft:light_gray_concrete
fill 227 296 502 227 297 502 minecraft:light_gray_concrete
fill 227 296 504 227 300 504 minecraft:light_gray_concrete
fill 188 298 468 188 300 468 minecraft:pearlescent_froglight
fill 188 298 476 188 300 476 minecraft:pearlescent_froglight
fill 188 298 484 188 300 484 minecraft:pearlescent_froglight
fill 188 298 492 188 300 492 minecraft:pearlescent_froglight
fill 188 298 500 188 300 500 minecraft:pearlescent_froglight
fill 191 298 505 191 300 505 minecraft:pearlescent_froglight
fill 195 298 463 195 300 463 minecraft:pearlescent_froglight
fill 199 298 505 199 300 505 minecraft:pearlescent_froglight
fill 203 298 463 203 300 463 minecraft:pearlescent_froglight
fill 207 298 505 207 300 505 minecraft:pearlescent_froglight
fill 211 298 463 211 300 463 minecraft:pearlescent_froglight
fill 215 298 505 215 300 505 minecraft:pearlescent_froglight
fill 219 298 463 219 300 463 minecraft:pearlescent_froglight
fill 223 298 505 223 300 505 minecraft:pearlescent_froglight
fill 227 298 463 227 300 463 minecraft:pearlescent_froglight
fill 230 298 468 230 300 468 minecraft:pearlescent_froglight
fill 230 298 476 230 300 476 minecraft:pearlescent_froglight
fill 230 298 484 230 300 484 minecraft:pearlescent_froglight
fill 230 298 492 230 300 492 minecraft:pearlescent_froglight
fill 230 298 500 230 300 500 minecraft:pearlescent_froglight
setblock 191 300 466 minecraft:light[level=11]
setblock 191 300 474 minecraft:light[level=11]
setblock 191 300 482 minecraft:light[level=11]
setblock 191 300 490 minecraft:light[level=11]
setblock 191 300 498 minecraft:light[level=11]
setblock 199 300 466 minecraft:light[level=11]
setblock 199 300 474 minecraft:light[level=11]
setblock 199 300 482 minecraft:light[level=11]
setblock 199 300 490 minecraft:light[level=11]
setblock 199 300 498 minecraft:light[level=11]
setblock 207 300 466 minecraft:light[level=11]
setblock 207 300 474 minecraft:light[level=11]
setblock 207 300 482 minecraft:light[level=11]
setblock 207 300 490 minecraft:light[level=11]
setblock 207 300 498 minecraft:light[level=11]
setblock 215 300 466 minecraft:light[level=11]
setblock 215 300 474 minecraft:light[level=11]
setblock 215 300 482 minecraft:light[level=11]
schedule function dropper:buildpart/112_3 1t
