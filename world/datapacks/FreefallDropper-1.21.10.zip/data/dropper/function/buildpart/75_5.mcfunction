setblock 165 71 353 minecraft:light[level=12]
setblock 165 71 360 minecraft:light[level=12]
fill 165 71 362 168 71 362 minecraft:blue_terracotta
setblock 168 71 323 minecraft:dark_prismarine
setblock 168 71 363 minecraft:dark_prismarine
fill 169 71 323 172 71 323 minecraft:blue_terracotta
setblock 169 71 362 minecraft:dark_prismarine
fill 169 71 363 169 74 363 minecraft:blue_terracotta
fill 170 71 362 170 73 362 minecraft:blue_terracotta
setblock 172 71 325 minecraft:light[level=12]
setblock 172 71 332 minecraft:light[level=12]
setblock 172 71 339 minecraft:light[level=12]
setblock 172 71 346 minecraft:light[level=12]
setblock 172 71 353 minecraft:light[level=12]
setblock 172 71 360 minecraft:light[level=12]
setblock 173 71 323 minecraft:dark_prismarine
setblock 173 71 363 minecraft:dark_prismarine
fill 174 71 323 174 74 323 minecraft:blue_terracotta
setblock 174 71 362 minecraft:dark_prismarine
fill 174 71 363 174 74 363 minecraft:blue_terracotta
setblock 175 71 361 minecraft:dark_prismarine
fill 175 71 362 175 74 362 minecraft:blue_terracotta
setblock 176 71 324 minecraft:blue_terracotta
fill 176 71 361 176 74 361 minecraft:blue_terracotta
setblock 177 71 324 minecraft:dark_prismarine
fill 177 71 339 177 102 339 minecraft:magenta_terracotta
setblock 177 71 360 minecraft:blue_terracotta
setblock 178 71 323 minecraft:dark_prismarine
fill 178 71 324 178 74 324 minecraft:blue_terracotta
setblock 178 71 363 minecraft:dark_prismarine
fill 179 71 323 179 74 323 minecraft:blue_terracotta
setblock 179 71 325 minecraft:light[level=12]
setblock 179 71 332 minecraft:light[level=12]
setblock 179 71 339 minecraft:light[level=12]
setblock 179 71 346 minecraft:light[level=12]
setblock 179 71 353 minecraft:light[level=12]
setblock 179 71 362 minecraft:dark_prismarine
fill 179 71 363 179 74 363 minecraft:blue_terracotta
fill 179 71 364 179 131 364 minecraft:black_concrete
fill 180 71 339 180 71 340 minecraft:blue_terracotta
setblock 180 71 341 minecraft:dark_prismarine
fill 180 71 342 180 74 342 minecraft:blue_terracotta
setblock 180 71 345 minecraft:blue_terracotta
setblock 180 71 346 minecraft:dark_prismarine
fill 180 71 347 180 74 347 minecraft:blue_terracotta
setblock 180 71 356 minecraft:dark_prismarine
setblock 180 71 357 minecraft:blue_terracotta
setblock 180 71 361 minecraft:dark_prismarine
fill 180 71 362 180 74 362 minecraft:blue_terracotta
fill 181 71 337 181 71 339 minecraft:blue_terracotta
setblock 181 71 340 minecraft:dark_prismarine
fill 181 71 341 181 74 341 minecraft:blue_terracotta
setblock 181 71 345 minecraft:dark_prismarine
fill 181 71 346 181 74 346 minecraft:blue_terracotta
setblock 181 71 350 minecraft:dark_prismarine
fill 181 71 351 181 74 351 minecraft:blue_terracotta
setblock 181 71 355 minecraft:dark_prismarine
fill 181 71 356 181 72 356 minecraft:blue_terracotta
setblock 181 71 360 minecraft:dark_prismarine
fill 181 71 361 181 74 361 minecraft:blue_terracotta
setblock 182 71 324 minecraft:dark_prismarine
fill 182 71 325 182 74 325 minecraft:blue_terracotta
setblock 182 71 330 minecraft:purple_concrete
setblock 182 71 334 minecraft:dark_prismarine
fill 182 71 335 182 71 338 minecraft:blue_terracotta
setblock 182 71 339 minecraft:dark_prismarine
fill 182 71 340 182 74 340 minecraft:blue_terracotta
setblock 182 71 344 minecraft:dark_prismarine
fill 182 71 345 182 74 345 minecraft:blue_terracotta
setblock 182 71 349 minecraft:dark_prismarine
fill 182 71 350 182 74 350 minecraft:blue_terracotta
setblock 182 71 354 minecraft:dark_prismarine
fill 182 71 355 182 74 355 minecraft:blue_terracotta
setblock 182 71 359 minecraft:dark_prismarine
fill 182 71 360 182 74 360 minecraft:blue_terracotta
fill 141 72 330 141 131 330 minecraft:black_concrete
setblock 141 72 332 minecraft:light_blue_wool
setblock 142 72 323 minecraft:dark_prismarine
fill 142 72 324 142 75 324 minecraft:blue_terracotta
setblock 142 72 333 minecraft:dark_prismarine
fill 142 72 334 142 73 334 minecraft:blue_terracotta
setblock 142 72 338 minecraft:dark_prismarine
fill 142 72 339 142 75 339 minecraft:blue_terracotta
setblock 142 72 343 minecraft:dark_prismarine
fill 142 72 344 142 75 344 minecraft:blue_terracotta
setblock 142 72 348 minecraft:dark_prismarine
fill 142 72 349 142 75 349 minecraft:blue_terracotta
setblock 142 72 358 minecraft:dark_prismarine
setblock 142 72 359 minecraft:blue_terracotta
setblock 142 72 363 minecraft:dark_prismarine
fill 143 72 323 143 75 323 minecraft:blue_terracotta
setblock 143 72 337 minecraft:dark_prismarine
fill 143 72 338 143 73 338 minecraft:blue_terracotta
setblock 143 72 342 minecraft:dark_prismarine
fill 143 72 343 143 75 343 minecraft:blue_terracotta
setblock 143 72 347 minecraft:dark_prismarine
setblock 143 72 348 minecraft:blue_terracotta
fill 143 72 363 143 73 363 minecraft:blue_terracotta
fill 144 72 329 144 73 329 minecraft:black_concrete
setblock 144 72 341 minecraft:dark_prismarine
setblock 144 72 342 minecraft:blue_terracotta
fill 144 72 356 144 73 356 minecraft:black_concrete
setblock 147 72 322 minecraft:cyan_concrete
fill 149 72 323 151 72 323 minecraft:blue_terracotta
fill 149 72 349 149 77 349 minecraft:magenta_terracotta
setblock 152 72 323 minecraft:dark_prismarine
setblock 152 72 363 minecraft:dark_prismarine
fill 153 72 322 159 91 322 minecraft:black_concrete
fill 153 72 323 153 75 323 minecraft:blue_terracotta
fill 153 72 360 153 73 360 minecraft:black_concrete
fill 153 72 363 153 75 363 minecraft:blue_terracotta
setblock 155 72 325 minecraft:dark_prismarine
fill 155 72 362 157 72 362 minecraft:blue_terracotta
setblock 156 72 324 minecraft:dark_prismarine
fill 156 72 325 156 75 325 minecraft:blue_terracotta
setblock 157 72 323 minecraft:dark_prismarine
fill 157 72 324 157 75 324 minecraft:blue_terracotta
setblock 157 72 363 minecraft:dark_prismarine
fill 158 72 323 158 75 323 minecraft:blue_terracotta
setblock 158 72 362 minecraft:dark_prismarine
fill 158 72 363 158 75 363 minecraft:blue_terracotta
setblock 159 72 361 minecraft:dark_prismarine
fill 159 72 362 159 75 362 minecraft:blue_terracotta
setblock 160 72 322 minecraft:light_blue_wool
setblock 160 72 325 minecraft:dark_prismarine
setblock 160 72 361 minecraft:blue_terracotta
setblock 161 72 324 minecraft:dark_prismarine
fill 161 72 325 161 75 325 minecraft:blue_terracotta
setblock 162 72 323 minecraft:dark_prismarine
fill 162 72 324 162 75 324 minecraft:blue_terracotta
setblock 162 72 363 minecraft:dark_prismarine
fill 163 72 323 163 75 323 minecraft:blue_terracotta
fill 163 72 325 163 73 325 minecraft:black_concrete
setblock 163 72 362 minecraft:dark_prismarine
fill 163 72 363 166 72 363 minecraft:blue_terracotta
fill 164 72 329 164 102 329 minecraft:magenta_terracotta
fill 164 72 362 167 72 362 minecraft:blue_terracotta
setblock 166 72 324 minecraft:dark_prismarine
setblock 167 72 323 minecraft:dark_prismarine
setblock 167 72 363 minecraft:dark_prismarine
fill 168 72 323 171 72 323 minecraft:blue_terracotta
setblock 168 72 362 minecraft:dark_prismarine
fill 168 72 363 168 75 363 minecraft:blue_terracotta
setblock 169 72 362 minecraft:blue_terracotta
setblock 172 72 323 minecraft:dark_prismarine
setblock 172 72 363 minecraft:dark_prismarine
fill 173 72 323 173 75 323 minecraft:blue_terracotta
setblock 173 72 362 minecraft:dark_prismarine
fill 173 72 363 173 75 363 minecraft:blue_terracotta
setblock 174 72 361 minecraft:dark_prismarine
fill 174 72 362 174 75 362 minecraft:blue_terracotta
fill 175 72 361 175 73 361 minecraft:blue_terracotta
setblock 176 72 324 minecraft:dark_prismarine
setblock 177 72 323 minecraft:dark_prismarine
fill 177 72 324 177 75 324 minecraft:blue_terracotta
setblock 177 72 363 minecraft:dark_prismarine
fill 178 72 323 178 75 323 minecraft:blue_terracotta
setblock 178 72 362 minecraft:dark_prismarine
fill 178 72 363 178 75 363 minecraft:blue_terracotta
fill 179 72 327 179 73 327 minecraft:black_concrete
fill 179 72 346 179 73 346 minecraft:black_concrete
fill 179 72 354 179 73 355 minecraft:black_concrete
setblock 179 72 361 minecraft:dark_prismarine
fill 179 72 362 179 75 362 minecraft:blue_terracotta
setblock 180 72 340 minecraft:dark_prismarine
fill 180 72 341 180 74 341 minecraft:blue_terracotta
setblock 180 72 345 minecraft:dark_prismarine
fill 180 72 346 180 75 346 minecraft:blue_terracotta
setblock 180 72 360 minecraft:dark_prismarine
fill 180 72 361 180 73 361 minecraft:blue_terracotta
setblock 181 72 338 minecraft:blue_terracotta
setblock 181 72 339 minecraft:dark_prismarine
fill 181 72 340 181 75 340 minecraft:blue_terracotta
setblock 181 72 344 minecraft:dark_prismarine
fill 181 72 345 181 75 345 minecraft:blue_terracotta
setblock 181 72 349 minecraft:dark_prismarine
fill 181 72 350 181 75 350 minecraft:blue_terracotta
setblock 181 72 354 minecraft:dark_prismarine
setblock 181 72 355 minecraft:blue_terracotta
setblock 181 72 359 minecraft:dark_prismarine
fill 181 72 360 181 74 360 minecraft:blue_terracotta
setblock 182 72 323 minecraft:dark_prismarine
fill 182 72 324 182 75 324 minecraft:blue_terracotta
fill 182 72 336 182 72 337 minecraft:blue_terracotta
setblock 182 72 338 minecraft:dark_prismarine
fill 182 72 339 182 75 339 minecraft:blue_terracotta
setblock 182 72 343 minecraft:dark_prismarine
fill 182 72 344 182 75 344 minecraft:blue_terracotta
setblock 182 72 348 minecraft:dark_prismarine
fill 182 72 349 182 75 349 minecraft:blue_terracotta
setblock 182 72 353 minecraft:dark_prismarine
fill 182 72 354 182 75 354 minecraft:blue_terracotta
setblock 182 72 358 minecraft:dark_prismarine
fill 182 72 359 182 74 359 minecraft:blue_terracotta
setblock 182 72 363 minecraft:dark_prismarine
fill 141 73 322 141 127 323 minecraft:black_concrete
setblock 141 73 324 minecraft:cyan_concrete
fill 141 73 332 141 128 332 minecraft:black_concrete
fill 142 73 323 142 76 323 minecraft:blue_terracotta
setblock 142 73 327 minecraft:dark_prismarine
setblock 142 73 337 minecraft:dark_prismarine
fill 142 73 338 142 76 338 minecraft:blue_terracotta
setblock 142 73 342 minecraft:dark_prismarine
fill 142 73 343 142 76 343 minecraft:blue_terracotta
setblock 142 73 347 minecraft:dark_prismarine
fill 142 73 348 142 76 348 minecraft:blue_terracotta
setblock 142 73 362 minecraft:dark_prismarine
fill 142 73 363 142 74 363 minecraft:blue_terracotta
fill 143 73 329 143 74 329 minecraft:black_concrete
setblock 143 73 337 minecraft:blue_terracotta
setblock 143 73 341 minecraft:dark_prismarine
fill 143 73 342 143 76 342 minecraft:blue_terracotta
setblock 143 73 346 minecraft:dark_prismarine
fill 143 73 347 143 76 347 minecraft:blue_terracotta
fill 143 73 356 143 74 356 minecraft:black_concrete
fill 147 73 322 147 129 322 minecraft:black_concrete
setblock 147 73 363 minecraft:purple_concrete
fill 149 73 323 150 73 323 minecraft:blue_terracotta
setblock 151 73 323 minecraft:dark_prismarine
fill 152 73 323 152 75 324 minecraft:blue_terracotta
fill 152 73 363 152 76 363 minecraft:blue_terracotta
fill 153 73 361 153 74 361 minecraft:black_concrete
setblock 155 73 324 minecraft:dark_prismarine
fill 155 73 325 155 76 325 minecraft:blue_terracotta
fill 155 73 362 156 73 362 minecraft:blue_terracotta
setblock 156 73 323 minecraft:dark_prismarine
fill 156 73 324 156 76 324 minecraft:blue_terracotta
setblock 156 73 363 minecraft:dark_prismarine
fill 157 73 323 157 76 323 minecraft:blue_terracotta
setblock 157 73 362 minecraft:dark_prismarine
fill 157 73 363 157 76 363 minecraft:blue_terracotta
fill 158 73 362 158 76 362 minecraft:blue_terracotta
setblock 159 73 325 minecraft:dark_prismarine
setblock 159 73 364 minecraft:cyan_concrete
fill 160 73 322 160 131 322 minecraft:black_concrete
setblock 160 73 324 minecraft:dark_prismarine
fill 160 73 325 160 76 325 minecraft:blue_terracotta
setblock 161 73 323 minecraft:dark_prismarine
fill 161 73 324 161 76 324 minecraft:blue_terracotta
setblock 161 73 363 minecraft:dark_prismarine
fill 162 73 323 162 76 323 minecraft:blue_terracotta
setblock 162 73 362 minecraft:dark_prismarine
fill 162 73 363 165 73 363 minecraft:blue_terracotta
fill 163 73 362 166 73 362 minecraft:blue_terracotta
setblock 165 73 324 minecraft:dark_prismarine
setblock 166 73 323 minecraft:dark_prismarine
setblock 166 73 363 minecraft:dark_prismarine
fill 167 73 323 170 73 323 minecraft:blue_terracotta
fill 167 73 363 167 76 363 minecraft:blue_terracotta
setblock 169 73 322 minecraft:cyan_concrete
setblock 171 73 323 minecraft:dark_prismarine
setblock 171 73 363 minecraft:dark_prismarine
fill 172 73 323 172 76 323 minecraft:blue_terracotta
setblock 172 73 362 minecraft:dark_prismarine
fill 172 73 363 172 76 363 minecraft:blue_terracotta
fill 173 73 362 173 76 362 minecraft:blue_terracotta
setblock 176 73 323 minecraft:dark_prismarine
fill 176 73 324 176 76 324 minecraft:blue_terracotta
fill 176 73 336 176 98 336 minecraft:magenta_terracotta
setblock 176 73 363 minecraft:dark_prismarine
fill 177 73 323 177 76 323 minecraft:blue_terracotta
setblock 177 73 362 minecraft:dark_prismarine
fill 177 73 363 177 76 363 minecraft:blue_terracotta
setblock 178 73 361 minecraft:dark_prismarine
fill 178 73 362 178 76 362 minecraft:blue_terracotta
setblock 179 73 361 minecraft:blue_terracotta
fill 180 73 327 180 74 327 minecraft:black_concrete
setblock 180 73 344 minecraft:dark_prismarine
fill 180 73 345 180 76 345 minecraft:blue_terracotta
fill 180 73 354 180 74 355 minecraft:black_concrete
setblock 181 73 323 minecraft:dark_prismarine
fill 181 73 339 181 74 339 minecraft:blue_terracotta
setblock 181 73 343 minecraft:dark_prismarine
fill 181 73 344 181 76 344 minecraft:blue_terracotta
setblock 181 73 348 minecraft:dark_prismarine
fill 181 73 349 181 76 349 minecraft:blue_terracotta
setblock 181 73 358 minecraft:dark_prismarine
setblock 181 73 359 minecraft:blue_terracotta
setblock 181 73 363 minecraft:dark_prismarine
fill 182 73 323 182 76 323 minecraft:blue_terracotta
setblock 182 73 337 minecraft:dark_prismarine
fill 182 73 338 182 75 338 minecraft:blue_terracotta
setblock 182 73 342 minecraft:dark_prismarine
fill 182 73 343 182 76 343 minecraft:blue_terracotta
setblock 182 73 347 minecraft:dark_prismarine
fill 182 73 348 182 76 348 minecraft:blue_terracotta
setblock 182 73 352 minecraft:dark_prismarine
fill 182 73 353 182 76 353 minecraft:blue_terracotta
setblock 182 73 357 minecraft:dark_prismarine
fill 182 73 358 182 74 358 minecraft:blue_terracotta
setblock 182 73 362 minecraft:dark_prismarine
fill 182 73 363 182 76 363 minecraft:blue_terracotta
fill 141 74 324 141 131 324 minecraft:black_concrete
fill 141 74 341 141 131 341 minecraft:black_concrete
setblock 141 74 342 minecraft:cyan_concrete
fill 141 74 343 141 132 343 minecraft:black_concrete
setblock 142 74 326 minecraft:dark_prismarine
fill 142 74 327 142 77 327 minecraft:blue_terracotta
fill 142 74 329 142 75 329 minecraft:black_concrete
setblock 142 74 330 minecraft:purple_concrete
setblock 142 74 336 minecraft:dark_prismarine
fill 142 74 337 142 77 337 minecraft:blue_terracotta
setblock 142 74 341 minecraft:dark_prismarine
fill 142 74 342 142 77 342 minecraft:blue_terracotta
setblock 142 74 346 minecraft:dark_prismarine
fill 142 74 347 142 77 347 minecraft:blue_terracotta
fill 142 74 356 142 75 356 minecraft:black_concrete
setblock 143 74 340 minecraft:dark_prismarine
fill 143 74 341 143 76 341 minecraft:blue_terracotta
setblock 143 74 345 minecraft:dark_prismarine
fill 143 74 346 143 77 346 minecraft:blue_terracotta
fill 146 74 323 146 75 323 minecraft:purple_concrete
fill 148 74 323 149 74 323 minecraft:blue_terracotta
setblock 150 74 323 minecraft:dark_prismarine
fill 151 74 323 151 76 324 minecraft:blue_terracotta
fill 153 74 362 153 75 362 minecraft:black_concrete
setblock 154 74 324 minecraft:dark_prismarine
fill 154 74 325 154 77 325 minecraft:blue_terracotta
setblock 155 74 323 minecraft:dark_prismarine
fill 155 74 324 155 77 324 minecraft:blue_terracotta
setblock 155 74 362 minecraft:blue_terracotta
setblock 155 74 363 minecraft:dark_prismarine
fill 156 74 323 156 77 323 minecraft:blue_terracotta
setblock 156 74 362 minecraft:dark_prismarine
fill 156 74 363 156 77 363 minecraft:blue_terracotta
fill 157 74 362 157 77 362 minecraft:blue_terracotta
setblock 158 74 325 minecraft:dark_prismarine
setblock 159 74 324 minecraft:dark_prismarine
fill 159 74 325 159 77 325 minecraft:blue_terracotta
fill 159 74 364 159 131 364 minecraft:black_concrete
setblock 160 74 323 minecraft:dark_prismarine
fill 160 74 324 160 77 324 minecraft:blue_terracotta
setblock 160 74 363 minecraft:dark_prismarine
fill 161 74 323 161 77 323 minecraft:blue_terracotta
setblock 161 74 362 minecraft:dark_prismarine
fill 161 74 363 164 74 363 minecraft:blue_terracotta
fill 162 74 362 164 74 362 minecraft:blue_terracotta
setblock 164 74 324 minecraft:dark_prismarine
setblock 165 74 323 minecraft:dark_prismarine
setblock 165 74 324 minecraft:blue_terracotta
setblock 165 74 363 minecraft:dark_prismarine
fill 166 74 323 169 74 323 minecraft:blue_terracotta
fill 166 74 363 166 77 363 minecraft:blue_terracotta
fill 169 74 322 169 131 322 minecraft:black_concrete
setblock 170 74 323 minecraft:dark_prismarine
setblock 170 74 363 minecraft:dark_prismarine
fill 171 74 323 171 77 323 minecraft:blue_terracotta
setblock 171 74 362 minecraft:dark_prismarine
fill 171 74 363 171 77 363 minecraft:blue_terracotta
fill 172 74 362 172 77 362 minecraft:blue_terracotta
setblock 175 74 323 minecraft:dark_prismarine
fill 175 74 324 175 77 324 minecraft:blue_terracotta
setblock 175 74 363 minecraft:dark_prismarine
fill 176 74 323 176 77 323 minecraft:blue_terracotta
setblock 176 74 362 minecraft:dark_prismarine
fill 176 74 363 176 77 363 minecraft:blue_terracotta
setblock 177 74 361 minecraft:dark_prismarine
fill 177 74 362 177 77 362 minecraft:blue_terracotta
setblock 178 74 361 minecraft:blue_terracotta
setblock 179 74 324 minecraft:dark_prismarine
setblock 180 74 323 minecraft:dark_prismarine
setblock 180 74 343 minecraft:dark_prismarine
fill 180 74 344 180 77 344 minecraft:blue_terracotta
setblock 180 74 348 minecraft:dark_prismarine
fill 180 74 349 180 77 349 minecraft:blue_terracotta
setblock 180 74 363 minecraft:dark_prismarine
fill 181 74 323 181 77 323 minecraft:blue_terracotta
fill 181 74 327 181 75 327 minecraft:black_concrete
setblock 181 74 342 minecraft:dark_prismarine
fill 181 74 343 181 77 343 minecraft:blue_terracotta
setblock 181 74 347 minecraft:dark_prismarine
fill 181 74 348 181 77 348 minecraft:blue_terracotta
fill 181 74 354 181 75 355 minecraft:black_concrete
setblock 181 74 362 minecraft:dark_prismarine
fill 181 74 363 181 77 363 minecraft:blue_terracotta
setblock 182 74 337 minecraft:blue_terracotta
setblock 182 74 341 minecraft:dark_prismarine
fill 182 74 342 182 77 342 minecraft:blue_terracotta
setblock 182 74 346 minecraft:dark_prismarine
fill 182 74 347 182 77 347 minecraft:blue_terracotta
setblock 182 74 351 minecraft:dark_prismarine
fill 182 74 352 182 77 352 minecraft:blue_terracotta
setblock 182 74 356 minecraft:dark_prismarine
setblock 182 74 357 minecraft:blue_terracotta
setblock 182 74 361 minecraft:dark_prismarine
fill 182 74 362 182 76 362 minecraft:blue_terracotta
fill 141 75 342 141 129 342 minecraft:black_concrete
setblock 142 75 325 minecraft:dark_prismarine
fill 142 75 326 142 78 326 minecraft:blue_terracotta
fill 142 75 328 142 76 328 minecraft:blue_terracotta
setblock 142 75 336 minecraft:blue_terracotta
setblock 142 75 340 minecraft:dark_prismarine
fill 142 75 341 142 78 341 minecraft:blue_terracotta
setblock 142 75 345 minecraft:dark_prismarine
fill 142 75 346 142 78 346 minecraft:blue_terracotta
setblock 142 75 350 minecraft:dark_prismarine
setblock 142 75 355 minecraft:purple_concrete
setblock 143 75 340 minecraft:blue_terracotta
setblock 143 75 344 minecraft:dark_prismarine
fill 143 75 345 143 78 345 minecraft:blue_terracotta
setblock 144 75 323 minecraft:dark_prismarine
setblock 144 75 325 minecraft:sea_lantern
setblock 144 75 331 minecraft:sea_lantern
setblock 144 75 337 minecraft:sea_lantern
setblock 144 75 343 minecraft:sea_lantern
setblock 144 75 349 minecraft:sea_lantern
setblock 144 75 355 minecraft:sea_lantern
setblock 144 75 361 minecraft:sea_lantern
fill 147 75 323 148 75 323 minecraft:blue_terracotta
setblock 149 75 323 minecraft:dark_prismarine
fill 149 75 337 149 102 337 minecraft:magenta_terracotta
fill 150 75 323 150 78 323 minecraft:blue_terracotta
setblock 150 75 325 minecraft:sea_lantern
setblock 150 75 361 minecraft:sea_lantern
setblock 153 75 324 minecraft:dark_prismarine
fill 153 75 325 153 78 325 minecraft:blue_terracotta
setblock 154 75 323 minecraft:dark_prismarine
fill 154 75 324 154 78 324 minecraft:blue_terracotta
setblock 154 75 363 minecraft:dark_prismarine
fill 155 75 323 155 78 323 minecraft:blue_terracotta
setblock 155 75 362 minecraft:dark_prismarine
fill 155 75 363 155 78 363 minecraft:blue_terracotta
setblock 156 75 361 minecraft:sea_lantern
fill 156 75 362 156 78 362 minecraft:blue_terracotta
setblock 157 75 325 minecraft:dark_prismarine
setblock 158 75 324 minecraft:dark_prismarine
fill 158 75 325 158 78 325 minecraft:blue_terracotta
setblock 159 75 323 minecraft:dark_prismarine
fill 159 75 324 159 78 324 minecraft:blue_terracotta
setblock 159 75 363 minecraft:dark_prismarine
fill 160 75 323 160 78 323 minecraft:blue_terracotta
fill 160 75 355 160 102 355 minecraft:magenta_terracotta
setblock 160 75 362 minecraft:dark_prismarine
fill 160 75 363 163 75 363 minecraft:blue_terracotta
fill 161 75 362 163 75 362 minecraft:blue_terracotta
setblock 162 75 325 minecraft:sea_lantern
setblock 162 75 361 minecraft:sea_lantern
setblock 163 75 324 minecraft:dark_prismarine
setblock 164 75 323 minecraft:dark_prismarine
fill 164 75 324 164 78 324 minecraft:blue_terracotta
setblock 164 75 363 minecraft:dark_prismarine
fill 165 75 323 168 75 323 minecraft:blue_terracotta
fill 165 75 363 165 78 363 minecraft:blue_terracotta
fill 166 75 355 166 76 356 minecraft:spruce_planks
setblock 168 75 325 minecraft:sea_lantern
setblock 168 75 361 minecraft:sea_lantern
setblock 169 75 323 minecraft:dark_prismarine
setblock 169 75 363 minecraft:dark_prismarine
fill 170 75 323 170 78 323 minecraft:blue_terracotta
fill 170 75 363 170 78 363 minecraft:blue_terracotta
fill 171 75 362 171 78 362 minecraft:blue_terracotta
setblock 174 75 323 minecraft:dark_prismarine
fill 174 75 324 174 78 324 minecraft:blue_terracotta
setblock 174 75 325 minecraft:sea_lantern
setblock 174 75 361 minecraft:sea_lantern
setblock 174 75 363 minecraft:dark_prismarine
fill 175 75 323 175 78 323 minecraft:blue_terracotta
setblock 175 75 362 minecraft:dark_prismarine
fill 175 75 363 175 78 363 minecraft:blue_terracotta
fill 176 75 338 176 102 338 minecraft:magenta_terracotta
fill 176 75 362 176 78 362 minecraft:blue_terracotta
setblock 178 75 324 minecraft:dark_prismarine
setblock 179 75 323 minecraft:dark_prismarine
fill 179 75 324 179 78 324 minecraft:blue_terracotta
setblock 179 75 363 minecraft:dark_prismarine
fill 180 75 323 180 78 323 minecraft:blue_terracotta
setblock 180 75 325 minecraft:sea_lantern
setblock 180 75 331 minecraft:sea_lantern
setblock 180 75 337 minecraft:sea_lantern
setblock 180 75 342 minecraft:dark_prismarine
fill 180 75 343 180 78 343 minecraft:blue_terracotta
setblock 180 75 347 minecraft:dark_prismarine
fill 180 75 348 180 78 348 minecraft:blue_terracotta
setblock 180 75 355 minecraft:sea_lantern
setblock 180 75 361 minecraft:sea_lantern
fill 180 75 362 180 76 362 minecraft:dark_prismarine
fill 180 75 363 180 78 363 minecraft:blue_terracotta
setblock 181 75 341 minecraft:dark_prismarine
fill 181 75 342 181 78 342 minecraft:blue_terracotta
setblock 181 75 346 minecraft:dark_prismarine
fill 181 75 347 181 78 347 minecraft:blue_terracotta
setblock 181 75 351 minecraft:dark_prismarine
setblock 182 75 325 minecraft:purple_concrete
setblock 182 75 331 minecraft:purple_concrete
setblock 182 75 340 minecraft:dark_prismarine
fill 182 75 341 182 78 341 minecraft:blue_terracotta
setblock 182 75 345 minecraft:dark_prismarine
fill 182 75 346 182 78 346 minecraft:blue_terracotta
setblock 182 75 350 minecraft:dark_prismarine
fill 182 75 351 182 78 351 minecraft:blue_terracotta
fill 182 75 360 182 76 360 minecraft:dark_prismarine
setblock 182 75 361 minecraft:blue_terracotta
fill 142 76 324 149 76 324 minecraft:dark_prismarine
fill 142 76 325 142 79 325 minecraft:blue_terracotta
fill 142 76 329 144 76 336 minecraft:dark_prismarine
fill 142 76 339 144 76 339 minecraft:dark_prismarine
fill 142 76 340 142 79 340 minecraft:blue_terracotta
setblock 142 76 344 minecraft:dark_prismarine
fill 142 76 345 142 79 345 minecraft:blue_terracotta
fill 142 76 349 144 76 349 minecraft:dark_prismarine
fill 142 76 350 142 79 350 minecraft:blue_terracotta
fill 142 76 351 144 76 360 minecraft:dark_prismarine
setblock 142 76 361 minecraft:purple_concrete
fill 142 76 362 151 76 363 minecraft:dark_prismarine
setblock 143 76 323 minecraft:dark_prismarine
fill 143 76 325 144 76 328 minecraft:dark_prismarine
fill 143 76 337 144 76 338 minecraft:dark_prismarine
fill 143 76 340 144 76 340 minecraft:dark_prismarine
fill 143 76 343 144 76 343 minecraft:dark_prismarine
fill 143 76 344 143 79 344 minecraft:blue_terracotta
fill 143 76 348 144 76 348 minecraft:dark_prismarine
fill 143 76 350 144 76 350 minecraft:dark_prismarine
fill 143 76 361 182 76 361 minecraft:dark_prismarine
fill 144 76 323 147 76 323 minecraft:blue_terracotta
fill 144 76 341 144 76 342 minecraft:dark_prismarine
fill 144 76 344 144 76 347 minecraft:dark_prismarine
fill 145 76 325 151 76 325 minecraft:dark_prismarine
fill 147 76 337 148 94 337 minecraft:magenta_terracotta
setblock 148 76 323 minecraft:dark_prismarine
fill 149 76 323 149 79 323 minecraft:blue_terracotta
fill 150 76 324 150 77 324 minecraft:blue_terracotta
setblock 152 76 323 minecraft:blue_terracotta
setblock 152 76 324 minecraft:dark_prismarine
fill 152 76 325 152 79 325 minecraft:blue_terracotta
fill 152 76 362 154 76 362 minecraft:dark_prismarine
setblock 153 76 323 minecraft:dark_prismarine
fill 153 76 324 153 79 324 minecraft:blue_terracotta
setblock 153 76 363 minecraft:dark_prismarine
fill 154 76 323 154 79 323 minecraft:blue_terracotta
fill 154 76 363 154 79 363 minecraft:blue_terracotta
setblock 155 76 326 minecraft:dark_prismarine
fill 155 76 362 155 79 362 minecraft:blue_terracotta
setblock 156 76 325 minecraft:dark_prismarine
fill 156 76 326 157 78 326 minecraft:blue_terracotta
setblock 157 76 324 minecraft:dark_prismarine
fill 157 76 325 157 79 325 minecraft:blue_terracotta
setblock 158 76 323 minecraft:dark_prismarine
fill 158 76 324 158 79 324 minecraft:blue_terracotta
setblock 158 76 363 minecraft:dark_prismarine
fill 159 76 323 159 79 323 minecraft:blue_terracotta
setblock 159 76 362 minecraft:dark_prismarine
fill 159 76 363 162 76 363 minecraft:blue_terracotta
fill 160 76 362 162 76 362 minecraft:blue_terracotta
fill 161 76 325 181 76 325 minecraft:dark_prismarine
setblock 162 76 324 minecraft:dark_prismarine
setblock 163 76 323 minecraft:dark_prismarine
fill 163 76 324 163 79 324 minecraft:blue_terracotta
fill 163 76 362 163 76 363 minecraft:dark_prismarine
fill 164 76 323 167 76 323 minecraft:blue_terracotta
fill 164 76 362 170 76 362 minecraft:dark_prismarine
fill 164 76 363 164 79 363 minecraft:blue_terracotta
fill 165 76 324 172 76 324 minecraft:dark_prismarine
setblock 168 76 323 minecraft:dark_prismarine
setblock 168 76 363 minecraft:dark_prismarine
fill 169 76 323 169 79 323 minecraft:blue_terracotta
fill 169 76 363 169 79 363 minecraft:blue_terracotta
setblock 173 76 323 minecraft:dark_prismarine
fill 173 76 324 173 79 324 minecraft:blue_terracotta
setblock 173 76 363 minecraft:dark_prismarine
fill 174 76 323 174 79 323 minecraft:blue_terracotta
fill 174 76 326 174 79 326 minecraft:dark_prismarine
setblock 174 76 362 minecraft:dark_prismarine
fill 174 76 363 174 79 363 minecraft:blue_terracotta
fill 175 76 327 175 79 327 minecraft:dark_prismarine
fill 175 76 362 175 79 362 minecraft:blue_terracotta
fill 176 76 326 176 79 326 minecraft:dark_prismarine
setblock 177 76 324 minecraft:dark_prismarine
setblock 178 76 323 minecraft:dark_prismarine
fill 178 76 324 178 79 324 minecraft:blue_terracotta
setblock 178 76 363 minecraft:dark_prismarine
fill 179 76 323 179 79 323 minecraft:blue_terracotta
setblock 179 76 362 minecraft:dark_prismarine
fill 179 76 363 179 79 363 minecraft:blue_terracotta
fill 180 76 324 182 76 324 minecraft:dark_prismarine
fill 180 76 326 180 76 341 minecraft:dark_prismarine
setblock 180 76 342 minecraft:blue_terracotta
setblock 180 76 346 minecraft:dark_prismarine
fill 180 76 347 180 79 347 minecraft:blue_terracotta
setblock 180 76 350 minecraft:blue_terracotta
fill 180 76 351 180 76 360 minecraft:dark_prismarine
fill 181 76 326 181 76 340 minecraft:dark_prismarine
fill 181 76 341 181 79 341 minecraft:blue_terracotta
setblock 181 76 345 minecraft:dark_prismarine
fill 181 76 346 181 79 346 minecraft:blue_terracotta
setblock 181 76 350 minecraft:dark_prismarine
fill 181 76 351 181 79 351 minecraft:blue_terracotta
fill 181 76 352 181 76 360 minecraft:dark_prismarine
setblock 181 76 362 minecraft:dark_prismarine
fill 182 76 325 182 79 325 minecraft:blue_terracotta
fill 182 76 326 182 76 339 minecraft:dark_prismarine
fill 182 76 340 182 79 340 minecraft:blue_terracotta
setblock 182 76 344 minecraft:dark_prismarine
fill 182 76 345 182 79 345 minecraft:blue_terracotta
setblock 182 76 349 minecraft:dark_prismarine
fill 182 76 350 182 79 350 minecraft:blue_terracotta
fill 182 76 354 182 76 359 minecraft:dark_prismarine
setblock 142 77 323 minecraft:dark_prismarine
fill 142 77 324 142 80 324 minecraft:blue_terracotta
setblock 142 77 328 minecraft:dark_prismarine
fill 142 77 329 142 78 331 minecraft:blue_terracotta
setblock 142 77 338 minecraft:dark_prismarine
fill 142 77 339 142 80 339 minecraft:blue_terracotta
setblock 142 77 343 minecraft:dark_prismarine
fill 142 77 344 142 80 344 minecraft:blue_terracotta
setblock 142 77 348 minecraft:dark_prismarine
fill 142 77 349 142 80 349 minecraft:blue_terracotta
fill 143 77 323 146 77 323 minecraft:blue_terracotta
setblock 143 77 342 minecraft:dark_prismarine
fill 143 77 343 143 78 343 minecraft:blue_terracotta
setblock 143 77 347 minecraft:dark_prismarine
fill 144 77 325 144 77 361 minecraft:purple_concrete
fill 145 77 325 150 77 325 minecraft:purple_concrete
fill 145 77 349 145 102 349 minecraft:magenta_terracotta
fill 145 77 361 180 77 361 minecraft:purple_concrete
setblock 146 77 363 minecraft:purple_concrete
setblock 147 77 323 minecraft:dark_prismarine
fill 148 77 323 148 80 323 minecraft:blue_terracotta
fill 149 77 324 149 78 324 minecraft:blue_terracotta
setblock 151 77 323 minecraft:blue_terracotta
setblock 151 77 324 minecraft:dark_prismarine
fill 151 77 325 151 80 325 minecraft:blue_terracotta
setblock 151 77 332 minecraft:light[level=12]
setblock 151 77 339 minecraft:light[level=12]
setblock 151 77 346 minecraft:light[level=12]
setblock 151 77 353 minecraft:light[level=12]
setblock 151 77 360 minecraft:light[level=12]
setblock 151 77 363 minecraft:blue_terracotta
setblock 152 77 323 minecraft:dark_prismarine
fill 152 77 324 152 80 324 minecraft:blue_terracotta
setblock 152 77 333 minecraft:light[level=13]
setblock 152 77 341 minecraft:light[level=13]
setblock 152 77 349 minecraft:light[level=13]
setblock 152 77 357 minecraft:light[level=13]
setblock 152 77 363 minecraft:dark_prismarine
fill 153 77 323 153 80 323 minecraft:blue_terracotta
fill 153 77 363 153 80 363 minecraft:blue_terracotta
setblock 154 77 326 minecraft:dark_prismarine
fill 154 77 362 154 80 362 minecraft:blue_terracotta
setblock 155 77 325 minecraft:dark_prismarine
fill 155 77 326 155 80 326 minecraft:blue_terracotta
setblock 156 77 324 minecraft:dark_prismarine
fill 156 77 325 156 80 325 minecraft:blue_terracotta
setblock 157 77 323 minecraft:dark_prismarine
fill 157 77 324 157 80 324 minecraft:blue_terracotta
setblock 157 77 363 minecraft:dark_prismarine
fill 158 77 323 158 80 323 minecraft:blue_terracotta
setblock 158 77 326 minecraft:blue_terracotta
setblock 158 77 332 minecraft:light[level=12]
setblock 158 77 339 minecraft:light[level=12]
setblock 158 77 346 minecraft:light[level=12]
setblock 158 77 353 minecraft:light[level=12]
setblock 158 77 360 minecraft:light[level=12]
setblock 158 77 362 minecraft:dark_prismarine
fill 158 77 363 161 77 363 minecraft:blue_terracotta
fill 159 77 362 161 77 362 minecraft:blue_terracotta
setblock 160 77 325 minecraft:dark_prismarine
setblock 160 77 333 minecraft:light[level=13]
setblock 160 77 341 minecraft:light[level=13]
setblock 160 77 349 minecraft:light[level=13]
setblock 161 77 324 minecraft:dark_prismarine
fill 161 77 325 161 80 325 minecraft:blue_terracotta
setblock 162 77 323 minecraft:dark_prismarine
fill 162 77 324 162 80 324 minecraft:blue_terracotta
fill 162 77 325 180 77 325 minecraft:purple_concrete
setblock 162 77 363 minecraft:dark_prismarine
fill 163 77 323 166 77 323 minecraft:blue_terracotta
fill 163 77 363 163 80 363 minecraft:blue_terracotta
setblock 165 77 332 minecraft:light[level=12]
setblock 165 77 339 minecraft:light[level=12]
setblock 165 77 346 minecraft:light[level=12]
setblock 165 77 353 minecraft:light[level=12]
setblock 165 77 360 minecraft:light[level=12]
setblock 167 77 323 minecraft:dark_prismarine
setblock 167 77 363 minecraft:dark_prismarine
fill 168 77 323 168 80 323 minecraft:blue_terracotta
setblock 168 77 333 minecraft:light[level=13]
setblock 168 77 341 minecraft:light[level=13]
setblock 168 77 349 minecraft:light[level=13]
setblock 168 77 357 minecraft:light[level=13]
fill 168 77 363 168 80 363 minecraft:blue_terracotta
setblock 171 77 324 minecraft:dark_prismarine
setblock 172 77 323 minecraft:dark_prismarine
fill 172 77 324 172 80 324 minecraft:blue_terracotta
setblock 172 77 332 minecraft:light[level=12]
setblock 172 77 339 minecraft:light[level=12]
setblock 172 77 346 minecraft:light[level=12]
setblock 172 77 353 minecraft:light[level=12]
setblock 172 77 360 minecraft:light[level=12]
setblock 172 77 363 minecraft:dark_prismarine
fill 173 77 323 173 80 323 minecraft:blue_terracotta
setblock 173 77 362 minecraft:dark_prismarine
fill 173 77 363 173 80 363 minecraft:blue_terracotta
fill 174 77 362 174 80 362 minecraft:blue_terracotta
setblock 176 77 324 minecraft:dark_prismarine
setblock 176 77 333 minecraft:light[level=13]
setblock 176 77 341 minecraft:light[level=13]
setblock 176 77 357 minecraft:light[level=13]
setblock 177 77 323 minecraft:dark_prismarine
fill 177 77 324 177 80 324 minecraft:blue_terracotta
fill 177 77 349 177 93 349 minecraft:magenta_terracotta
setblock 177 77 363 minecraft:dark_prismarine
fill 178 77 323 178 80 323 minecraft:blue_terracotta
setblock 178 77 362 minecraft:dark_prismarine
fill 178 77 363 178 80 363 minecraft:blue_terracotta
setblock 179 77 332 minecraft:light[level=12]
setblock 179 77 339 minecraft:light[level=12]
setblock 179 77 346 minecraft:dark_prismarine
fill 179 77 347 179 80 347 minecraft:blue_terracotta
setblock 179 77 353 minecraft:light[level=12]
setblock 179 77 360 minecraft:light[level=12]
setblock 179 77 362 minecraft:blue_terracotta
fill 180 77 326 180 77 342 minecraft:purple_concrete
setblock 180 77 345 minecraft:dark_prismarine
fill 180 77 346 180 80 346 minecraft:blue_terracotta
setblock 180 77 350 minecraft:dark_prismarine
fill 180 77 351 180 77 360 minecraft:purple_concrete
setblock 181 77 344 minecraft:dark_prismarine
fill 181 77 345 181 80 345 minecraft:blue_terracotta
setblock 181 77 349 minecraft:dark_prismarine
fill 181 77 350 181 80 350 minecraft:blue_terracotta
fill 181 77 352 181 78 352 minecraft:blue_terracotta
setblock 182 77 323 minecraft:dark_prismarine
fill 182 77 324 182 80 324 minecraft:blue_terracotta
fill 182 77 326 182 78 326 minecraft:blue_terracotta
setblock 182 77 338 minecraft:purple_concrete
fill 182 77 339 182 80 339 minecraft:blue_terracotta
setblock 182 77 343 minecraft:dark_prismarine
fill 182 77 344 182 80 344 minecraft:blue_terracotta
setblock 182 77 348 minecraft:dark_prismarine
fill 182 77 349 182 80 349 minecraft:blue_terracotta
setblock 182 77 353 minecraft:dark_prismarine
fill 182 77 354 182 80 354 minecraft:blue_terracotta
setblock 182 77 357 minecraft:purple_concrete
fill 142 78 323 145 78 323 minecraft:blue_terracotta
setblock 142 78 327 minecraft:dark_prismarine
fill 142 78 328 142 81 328 minecraft:blue_terracotta
setblock 142 78 332 minecraft:dark_prismarine
fill 142 78 333 142 81 333 minecraft:blue_terracotta
setblock 142 78 335 minecraft:purple_concrete
setblock 142 78 337 minecraft:dark_prismarine
fill 142 78 338 142 81 338 minecraft:blue_terracotta
setblock 142 78 342 minecraft:dark_prismarine
fill 142 78 343 142 81 343 minecraft:blue_terracotta
setblock 142 78 347 minecraft:dark_prismarine
fill 142 78 348 142 81 348 minecraft:blue_terracotta
setblock 142 78 351 minecraft:blue_terracotta
setblock 142 78 354 minecraft:purple_concrete
setblock 143 78 346 minecraft:dark_prismarine
fill 143 78 347 143 81 347 minecraft:blue_terracotta
setblock 146 78 323 minecraft:dark_prismarine
fill 147 78 323 147 80 324 minecraft:blue_terracotta
fill 148 78 324 148 79 324 minecraft:blue_terracotta
setblock 150 78 324 minecraft:dark_prismarine
fill 150 78 325 150 81 325 minecraft:blue_terracotta
setblock 150 78 363 minecraft:blue_terracotta
setblock 151 78 323 minecraft:dark_prismarine
fill 151 78 324 151 81 324 minecraft:blue_terracotta
setblock 151 78 363 minecraft:dark_prismarine
setblock 152 78 322 minecraft:cyan_concrete
fill 152 78 323 152 81 323 minecraft:blue_terracotta
setblock 152 78 326 minecraft:blue_terracotta
fill 152 78 363 152 81 363 minecraft:blue_terracotta
setblock 153 78 326 minecraft:dark_prismarine
setblock 154 78 325 minecraft:dark_prismarine
fill 154 78 326 154 81 326 minecraft:blue_terracotta
setblock 155 78 324 minecraft:dark_prismarine
fill 155 78 325 155 81 325 minecraft:blue_terracotta
setblock 156 78 323 minecraft:dark_prismarine
fill 156 78 324 156 81 324 minecraft:blue_terracotta
setblock 156 78 363 minecraft:dark_prismarine
fill 157 78 323 157 81 323 minecraft:blue_terracotta
setblock 157 78 362 minecraft:dark_prismarine
fill 157 78 363 160 78 363 minecraft:blue_terracotta
setblock 158 78 326 minecraft:dark_prismarine
fill 158 78 362 160 79 362 minecraft:blue_terracotta
setblock 159 78 325 minecraft:dark_prismarine
setblock 160 78 324 minecraft:dark_prismarine
fill 160 78 325 160 81 325 minecraft:blue_terracotta
setblock 161 78 323 minecraft:dark_prismarine
fill 161 78 324 161 81 324 minecraft:blue_terracotta
setblock 161 78 363 minecraft:dark_prismarine
fill 162 78 323 165 78 323 minecraft:blue_terracotta
fill 162 78 363 162 81 363 minecraft:blue_terracotta
setblock 166 78 323 minecraft:dark_prismarine
setblock 166 78 363 minecraft:dark_prismarine
fill 167 78 323 167 81 323 minecraft:blue_terracotta
fill 167 78 363 167 81 363 minecraft:blue_terracotta
setblock 170 78 324 minecraft:dark_prismarine
fill 170 78 362 170 79 362 minecraft:blue_terracotta
setblock 171 78 323 minecraft:dark_prismarine
fill 171 78 324 171 81 324 minecraft:blue_terracotta
setblock 171 78 363 minecraft:dark_prismarine
fill 172 78 323 172 81 323 minecraft:blue_terracotta
setblock 172 78 362 minecraft:dark_prismarine
fill 172 78 363 172 81 363 minecraft:blue_terracotta
fill 173 78 362 173 81 362 minecraft:blue_terracotta
fill 175 78 324 175 78 325 minecraft:dark_prismarine
setblock 176 78 323 minecraft:dark_prismarine
fill 176 78 324 176 81 324 minecraft:blue_terracotta
setblock 176 78 363 minecraft:dark_prismarine
fill 177 78 323 177 81 323 minecraft:blue_terracotta
setblock 177 78 362 minecraft:dark_prismarine
fill 177 78 363 177 81 363 minecraft:blue_terracotta
fill 178 78 362 178 79 362 minecraft:blue_terracotta
setblock 179 78 345 minecraft:dark_prismarine
fill 179 78 346 179 81 346 minecraft:blue_terracotta
fill 179 78 348 179 78 349 minecraft:blue_terracotta
setblock 180 78 344 minecraft:dark_prismarine
fill 180 78 345 180 81 345 minecraft:blue_terracotta
setblock 180 78 349 minecraft:dark_prismarine
fill 180 78 350 180 80 351 minecraft:blue_terracotta
setblock 181 78 323 minecraft:dark_prismarine
setblock 181 78 343 minecraft:dark_prismarine
fill 181 78 344 181 81 344 minecraft:blue_terracotta
setblock 181 78 348 minecraft:dark_prismarine
fill 181 78 349 181 81 349 minecraft:blue_terracotta
setblock 181 78 363 minecraft:dark_prismarine
setblock 182 78 323 minecraft:blue_terracotta
setblock 182 78 327 minecraft:dark_prismarine
fill 182 78 328 182 81 328 minecraft:blue_terracotta
setblock 182 78 332 minecraft:purple_concrete
setblock 182 78 342 minecraft:dark_prismarine
fill 182 78 343 182 81 343 minecraft:blue_terracotta
setblock 182 78 347 minecraft:dark_prismarine
fill 182 78 348 182 81 348 minecraft:blue_terracotta
setblock 182 78 352 minecraft:dark_prismarine
fill 182 78 353 182 81 353 minecraft:blue_terracotta
fill 142 79 323 144 79 323 minecraft:blue_terracotta
setblock 142 79 326 minecraft:dark_prismarine
fill 142 79 327 143 81 327 minecraft:blue_terracotta
fill 142 79 329 142 79 330 minecraft:blue_terracotta
setblock 142 79 331 minecraft:dark_prismarine
fill 142 79 332 142 82 332 minecraft:blue_terracotta
fill 142 79 334 142 79 335 minecraft:blue_terracotta
setblock 142 79 336 minecraft:dark_prismarine
fill 142 79 337 142 82 337 minecraft:blue_terracotta
setblock 142 79 341 minecraft:dark_prismarine
fill 142 79 342 142 82 342 minecraft:blue_terracotta
setblock 142 79 346 minecraft:dark_prismarine
fill 142 79 347 142 82 347 minecraft:blue_terracotta
setblock 142 79 351 minecraft:dark_prismarine
setblock 142 79 360 minecraft:purple_concrete
setblock 143 79 325 minecraft:dark_prismarine
fill 143 79 326 143 82 326 minecraft:blue_terracotta
fill 143 79 328 143 79 329 minecraft:blue_terracotta
setblock 143 79 345 minecraft:dark_prismarine
fill 143 79 346 143 80 346 minecraft:blue_terracotta
setblock 145 79 323 minecraft:dark_prismarine
fill 146 79 323 146 81 324 minecraft:blue_terracotta
setblock 149 79 324 minecraft:dark_prismarine
fill 149 79 325 149 82 325 minecraft:blue_terracotta
setblock 150 79 323 minecraft:dark_prismarine
fill 150 79 324 150 82 324 minecraft:blue_terracotta
setblock 150 79 363 minecraft:dark_prismarine
fill 151 79 323 151 82 323 minecraft:blue_terracotta
setblock 151 79 326 minecraft:blue_terracotta
fill 151 79 363 151 82 363 minecraft:blue_terracotta
fill 152 79 322 152 131 322 minecraft:black_concrete
setblock 152 79 326 minecraft:dark_prismarine
setblock 153 79 325 minecraft:dark_prismarine
fill 153 79 326 153 82 326 minecraft:blue_terracotta
fill 153 79 362 153 81 362 minecraft:blue_terracotta
setblock 154 79 324 minecraft:dark_prismarine
fill 154 79 325 154 82 325 minecraft:blue_terracotta
setblock 155 79 323 minecraft:dark_prismarine
fill 155 79 324 155 82 324 minecraft:blue_terracotta
setblock 155 79 363 minecraft:dark_prismarine
fill 156 79 323 156 82 323 minecraft:blue_terracotta
setblock 156 79 326 minecraft:blue_terracotta
setblock 156 79 362 minecraft:dark_prismarine
fill 156 79 363 159 79 363 minecraft:blue_terracotta
setblock 157 79 326 minecraft:dark_prismarine
fill 157 79 362 157 82 362 minecraft:blue_terracotta
setblock 158 79 325 minecraft:dark_prismarine
fill 158 79 326 159 79 326 minecraft:blue_terracotta
setblock 159 79 324 minecraft:dark_prismarine
fill 159 79 325 159 82 325 minecraft:blue_terracotta
setblock 160 79 323 minecraft:dark_prismarine
fill 160 79 324 160 82 324 minecraft:blue_terracotta
setblock 160 79 363 minecraft:dark_prismarine
fill 161 79 323 164 79 323 minecraft:blue_terracotta
fill 161 79 363 161 82 363 minecraft:blue_terracotta
setblock 164 79 324 minecraft:dark_prismarine
fill 164 79 331 164 102 331 minecraft:magenta_terracotta
setblock 165 79 323 minecraft:dark_prismarine
fill 165 79 324 165 80 324 minecraft:blue_terracotta
setblock 165 79 363 minecraft:dark_prismarine
fill 166 79 323 166 82 323 minecraft:blue_terracotta
fill 166 79 363 166 82 363 minecraft:blue_terracotta
setblock 168 79 324 minecraft:blue_terracotta
setblock 169 79 324 minecraft:dark_prismarine
setblock 170 79 323 minecraft:dark_prismarine
fill 170 79 324 170 82 324 minecraft:blue_terracotta
setblock 170 79 363 minecraft:dark_prismarine
fill 171 79 323 171 82 323 minecraft:blue_terracotta
setblock 171 79 362 minecraft:dark_prismarine
fill 171 79 363 171 82 363 minecraft:blue_terracotta
fill 172 79 362 172 82 362 minecraft:blue_terracotta
fill 174 79 324 174 79 325 minecraft:dark_prismarine
setblock 174 79 327 minecraft:dark_prismarine
setblock 175 79 323 minecraft:dark_prismarine
fill 175 79 324 175 82 324 minecraft:blue_terracotta
fill 175 79 325 176 79 325 minecraft:dark_prismarine
setblock 175 79 363 minecraft:dark_prismarine
fill 176 79 323 176 82 323 minecraft:blue_terracotta
setblock 176 79 327 minecraft:dark_prismarine
setblock 176 79 362 minecraft:dark_prismarine
fill 176 79 363 176 82 363 minecraft:blue_terracotta
fill 177 79 362 177 80 362 minecraft:blue_terracotta
fill 178 79 350 178 82 350 minecraft:magenta_terracotta
setblock 179 79 324 minecraft:dark_prismarine
setblock 179 79 345 minecraft:blue_terracotta
setblock 179 79 348 minecraft:blue_terracotta
setblock 179 79 349 minecraft:dark_prismarine
fill 179 79 350 179 82 350 minecraft:blue_terracotta
setblock 180 79 323 minecraft:dark_prismarine
setblock 180 79 343 minecraft:dark_prismarine
fill 180 79 344 180 81 344 minecraft:blue_terracotta
setblock 180 79 348 minecraft:dark_prismarine
fill 180 79 349 180 82 349 minecraft:blue_terracotta
setblock 180 79 352 minecraft:blue_terracotta
setblock 180 79 363 minecraft:dark_prismarine
fill 181 79 323 181 80 323 minecraft:blue_terracotta
setblock 181 79 342 minecraft:dark_prismarine
fill 181 79 343 181 82 343 minecraft:blue_terracotta
setblock 181 79 347 minecraft:dark_prismarine
fill 181 79 348 181 82 348 minecraft:blue_terracotta
setblock 181 79 352 minecraft:dark_prismarine
fill 181 79 353 181 82 353 minecraft:blue_terracotta
setblock 182 79 326 minecraft:dark_prismarine
fill 182 79 327 182 82 327 minecraft:blue_terracotta
fill 182 79 329 182 79 330 minecraft:blue_terracotta
setblock 182 79 341 minecraft:dark_prismarine
fill 182 79 342 182 82 342 minecraft:blue_terracotta
setblock 182 79 346 minecraft:dark_prismarine
fill 182 79 347 182 82 347 minecraft:blue_terracotta
setblock 182 79 351 minecraft:dark_prismarine
fill 182 79 352 182 82 352 minecraft:blue_terracotta
fill 142 80 323 143 80 323 minecraft:blue_terracotta
setblock 142 80 325 minecraft:dark_prismarine
fill 142 80 326 142 83 326 minecraft:blue_terracotta
setblock 142 80 329 minecraft:blue_terracotta
setblock 142 80 330 minecraft:dark_prismarine
fill 142 80 331 143 82 331 minecraft:blue_terracotta
setblock 142 80 334 minecraft:blue_terracotta
setblock 142 80 335 minecraft:dark_prismarine
fill 142 80 336 142 83 336 minecraft:blue_terracotta
setblock 142 80 340 minecraft:dark_prismarine
fill 142 80 341 142 82 341 minecraft:blue_terracotta
setblock 142 80 345 minecraft:dark_prismarine
fill 142 80 346 142 83 346 minecraft:blue_terracotta
setblock 142 80 350 minecraft:dark_prismarine
fill 142 80 351 142 82 352 minecraft:blue_terracotta
fill 143 80 325 143 83 325 minecraft:blue_terracotta
setblock 143 80 328 minecraft:blue_terracotta
setblock 143 80 329 minecraft:dark_prismarine
fill 143 80 330 143 83 330 minecraft:blue_terracotta
setblock 143 80 345 minecraft:blue_terracotta
setblock 143 80 348 minecraft:blue_terracotta
setblock 144 80 323 minecraft:dark_prismarine
fill 145 80 323 145 82 324 minecraft:blue_terracotta
setblock 145 80 363 minecraft:purple_concrete
setblock 148 80 324 minecraft:dark_prismarine
fill 148 80 325 148 83 325 minecraft:blue_terracotta
setblock 149 80 323 minecraft:dark_prismarine
fill 149 80 324 149 83 324 minecraft:blue_terracotta
setblock 149 80 363 minecraft:dark_prismarine
fill 150 80 323 150 83 323 minecraft:blue_terracotta
setblock 150 80 326 minecraft:blue_terracotta
fill 150 80 363 150 83 363 minecraft:blue_terracotta
setblock 151 80 326 minecraft:dark_prismarine
setblock 152 80 325 minecraft:dark_prismarine
fill 152 80 326 152 83 326 minecraft:blue_terracotta
setblock 153 80 324 minecraft:dark_prismarine
fill 153 80 325 153 83 325 minecraft:blue_terracotta
fill 153 80 327 154 80 327 minecraft:blue_terracotta
setblock 154 80 323 minecraft:dark_prismarine
fill 154 80 324 154 83 324 minecraft:blue_terracotta
setblock 154 80 363 minecraft:dark_prismarine
fill 155 80 323 155 83 323 minecraft:blue_terracotta
setblock 155 80 327 minecraft:dark_prismarine
setblock 155 80 362 minecraft:dark_prismarine
fill 155 80 363 158 80 363 minecraft:blue_terracotta
setblock 156 80 326 minecraft:dark_prismarine
fill 156 80 362 156 83 362 minecraft:blue_terracotta
setblock 157 80 325 minecraft:dark_prismarine
fill 157 80 326 158 81 326 minecraft:blue_terracotta
setblock 158 80 324 minecraft:dark_prismarine
fill 158 80 325 158 83 325 minecraft:blue_terracotta
fill 158 80 362 159 80 362 minecraft:blue_terracotta
setblock 159 80 323 minecraft:dark_prismarine
fill 159 80 324 159 83 324 minecraft:blue_terracotta
setblock 159 80 363 minecraft:dark_prismarine
fill 160 80 323 163 80 323 minecraft:blue_terracotta
fill 160 80 358 160 102 358 minecraft:magenta_terracotta
setblock 160 80 362 minecraft:dark_prismarine
fill 160 80 363 160 83 363 minecraft:blue_terracotta
fill 162 80 356 162 92 357 minecraft:magenta_terracotta
setblock 163 80 324 minecraft:dark_prismarine
setblock 163 80 356 minecraft:magenta_terracotta
setblock 164 80 323 minecraft:dark_prismarine
fill 164 80 324 164 81 324 minecraft:blue_terracotta
setblock 164 80 363 minecraft:dark_prismarine
fill 165 80 323 165 83 323 minecraft:blue_terracotta
fill 165 80 363 165 83 363 minecraft:blue_terracotta
setblock 167 80 324 minecraft:blue_terracotta
setblock 168 80 324 minecraft:dark_prismarine
setblock 169 80 323 minecraft:dark_prismarine
fill 169 80 324 169 83 324 minecraft:blue_terracotta
setblock 169 80 362 minecraft:blue_terracotta
setblock 169 80 363 minecraft:dark_prismarine
fill 170 80 323 170 83 323 minecraft:blue_terracotta
setblock 170 80 362 minecraft:dark_prismarine
fill 170 80 363 170 83 363 minecraft:blue_terracotta
fill 171 80 362 171 83 362 minecraft:blue_terracotta
setblock 173 80 324 minecraft:dark_prismarine
fill 173 80 325 175 81 325 minecraft:blue_terracotta
setblock 174 80 323 minecraft:dark_prismarine
fill 174 80 324 174 83 324 minecraft:blue_terracotta
setblock 174 80 363 minecraft:dark_prismarine
fill 175 80 323 175 83 323 minecraft:blue_terracotta
setblock 175 80 362 minecraft:dark_prismarine
fill 175 80 363 175 83 363 minecraft:blue_terracotta
fill 176 80 362 176 81 362 minecraft:blue_terracotta
setblock 178 80 324 minecraft:dark_prismarine
setblock 179 80 323 minecraft:dark_prismarine
setblock 179 80 348 minecraft:dark_prismarine
fill 179 80 349 179 82 349 minecraft:blue_terracotta
setblock 179 80 363 minecraft:dark_prismarine
fill 180 80 323 180 81 323 minecraft:blue_terracotta
setblock 180 80 347 minecraft:dark_prismarine
fill 180 80 348 180 83 348 minecraft:blue_terracotta
setblock 180 80 352 minecraft:dark_prismarine
fill 181 80 342 181 81 342 minecraft:blue_terracotta
setblock 181 80 346 minecraft:dark_prismarine
fill 181 80 347 181 83 347 minecraft:blue_terracotta
setblock 181 80 351 minecraft:dark_prismarine
fill 181 80 352 181 83 352 minecraft:blue_terracotta
setblock 182 80 325 minecraft:dark_prismarine
fill 182 80 326 182 83 326 minecraft:blue_terracotta
setblock 182 80 329 minecraft:blue_terracotta
setblock 182 80 330 minecraft:dark_prismarine
fill 182 80 331 182 82 332 minecraft:blue_terracotta
setblock 182 80 340 minecraft:dark_prismarine
fill 182 80 341 182 83 341 minecraft:blue_terracotta
setblock 182 80 345 minecraft:dark_prismarine
fill 182 80 346 182 83 346 minecraft:blue_terracotta
setblock 182 80 350 minecraft:dark_prismarine
fill 182 80 351 182 83 351 minecraft:blue_terracotta
setblock 182 80 355 minecraft:dark_prismarine
setblock 142 81 323 minecraft:blue_terracotta
setblock 142 81 324 minecraft:dark_prismarine
fill 142 81 325 142 84 325 minecraft:blue_terracotta
setblock 142 81 329 minecraft:dark_prismarine
fill 142 81 330 142 84 330 minecraft:blue_terracotta
setblock 142 81 334 minecraft:dark_prismarine
fill 142 81 335 142 84 335 minecraft:blue_terracotta
setblock 142 81 339 minecraft:dark_prismarine
fill 142 81 340 142 82 340 minecraft:blue_terracotta
setblock 142 81 344 minecraft:dark_prismarine
fill 142 81 345 142 83 345 minecraft:blue_terracotta
setblock 142 81 349 minecraft:dark_prismarine
fill 142 81 350 142 84 350 minecraft:blue_terracotta
setblock 142 81 353 minecraft:purple_concrete
setblock 143 81 323 minecraft:dark_prismarine
setblock 143 81 328 minecraft:dark_prismarine
fill 143 81 329 143 84 329 minecraft:blue_terracotta
setblock 143 81 332 minecraft:blue_terracotta
fill 144 81 323 144 81 324 minecraft:blue_terracotta
setblock 147 81 323 minecraft:blue_terracotta
setblock 147 81 324 minecraft:dark_prismarine
fill 147 81 325 147 84 325 minecraft:blue_terracotta
setblock 148 81 323 minecraft:dark_prismarine
fill 148 81 324 148 84 324 minecraft:blue_terracotta
fill 149 81 323 149 84 323 minecraft:blue_terracotta
setblock 149 81 326 minecraft:blue_terracotta
fill 149 81 363 149 84 363 minecraft:blue_terracotta
setblock 150 81 326 minecraft:dark_prismarine
setblock 151 81 325 minecraft:dark_prismarine
fill 151 81 326 151 83 327 minecraft:blue_terracotta
setblock 152 81 324 minecraft:dark_prismarine
fill 152 81 325 152 84 325 minecraft:blue_terracotta
fill 152 81 327 153 81 327 minecraft:blue_terracotta
fill 152 81 362 152 82 362 minecraft:blue_terracotta
setblock 153 81 323 minecraft:dark_prismarine
fill 153 81 324 153 84 324 minecraft:blue_terracotta
setblock 153 81 363 minecraft:dark_prismarine
fill 154 81 323 154 84 323 minecraft:blue_terracotta
setblock 154 81 327 minecraft:dark_prismarine
setblock 154 81 362 minecraft:dark_prismarine
fill 154 81 363 157 81 363 minecraft:blue_terracotta
setblock 155 81 326 minecraft:dark_prismarine
fill 155 81 327 155 82 327 minecraft:blue_terracotta
fill 155 81 362 155 84 362 minecraft:blue_terracotta
setblock 156 81 325 minecraft:dark_prismarine
fill 156 81 326 156 83 326 minecraft:blue_terracotta
setblock 157 81 324 minecraft:dark_prismarine
fill 157 81 325 157 84 325 minecraft:blue_terracotta
setblock 158 81 323 minecraft:dark_prismarine
fill 158 81 324 158 84 324 minecraft:blue_terracotta
setblock 158 81 362 minecraft:blue_terracotta
setblock 158 81 363 minecraft:dark_prismarine
fill 159 81 323 162 81 323 minecraft:blue_terracotta
setblock 159 81 362 minecraft:dark_prismarine
fill 159 81 363 159 84 363 minecraft:blue_terracotta
setblock 162 81 324 minecraft:dark_prismarine
setblock 163 81 323 minecraft:dark_prismarine
setblock 163 81 324 minecraft:blue_terracotta
setblock 163 81 363 minecraft:dark_prismarine
fill 164 81 323 164 83 323 minecraft:blue_terracotta
fill 164 81 363 164 83 363 minecraft:blue_terracotta
setblock 167 81 324 minecraft:dark_prismarine
setblock 168 81 323 minecraft:dark_prismarine
fill 168 81 324 168 82 324 minecraft:blue_terracotta
setblock 168 81 363 minecraft:dark_prismarine
fill 169 81 323 169 84 323 minecraft:blue_terracotta
setblock 169 81 362 minecraft:dark_prismarine
fill 169 81 363 169 84 363 minecraft:blue_terracotta
fill 170 81 362 170 84 362 minecraft:blue_terracotta
setblock 172 81 324 minecraft:dark_prismarine
setblock 172 81 325 minecraft:blue_terracotta
setblock 173 81 323 minecraft:dark_prismarine
fill 173 81 324 173 84 324 minecraft:blue_terracotta
setblock 173 81 363 minecraft:dark_prismarine
fill 174 81 323 174 84 323 minecraft:blue_terracotta
setblock 174 81 362 minecraft:dark_prismarine
fill 174 81 363 174 84 363 minecraft:blue_terracotta
fill 175 81 362 175 82 362 minecraft:blue_terracotta
fill 176 81 332 176 82 333 minecraft:dark_prismarine
setblock 177 81 324 minecraft:dark_prismarine
setblock 178 81 323 minecraft:dark_prismarine
setblock 178 81 324 minecraft:blue_terracotta
setblock 178 81 363 minecraft:dark_prismarine
fill 179 81 323 179 82 323 minecraft:blue_terracotta
setblock 179 81 347 minecraft:dark_prismarine
fill 179 81 348 179 82 348 minecraft:blue_terracotta
setblock 179 81 351 minecraft:blue_terracotta
setblock 179 81 363 minecraft:blue_terracotta
setblock 180 81 346 minecraft:dark_prismarine
fill 180 81 347 180 83 347 minecraft:blue_terracotta
setblock 180 81 350 minecraft:blue_terracotta
setblock 180 81 351 minecraft:dark_prismarine
fill 180 81 352 180 83 352 minecraft:blue_terracotta
setblock 181 81 345 minecraft:dark_prismarine
fill 181 81 346 181 84 346 minecraft:blue_terracotta
setblock 181 81 350 minecraft:dark_prismarine
fill 181 81 351 181 84 351 minecraft:blue_terracotta
setblock 181 81 354 minecraft:blue_terracotta
fill 182 81 325 182 82 325 minecraft:blue_terracotta
setblock 182 81 329 minecraft:dark_prismarine
fill 182 81 330 182 84 330 minecraft:blue_terracotta
setblock 182 81 333 minecraft:blue_terracotta
setblock 182 81 334 minecraft:dark_prismarine
setblock 182 81 339 minecraft:dark_prismarine
fill 182 81 340 182 82 340 minecraft:blue_terracotta
setblock 182 81 344 minecraft:dark_prismarine
fill 182 81 345 182 84 345 minecraft:blue_terracotta
setblock 182 81 349 minecraft:dark_prismarine
fill 182 81 350 182 84 350 minecraft:blue_terracotta
setblock 182 81 354 minecraft:dark_prismarine
fill 182 81 355 182 84 355 minecraft:blue_terracotta
setblock 182 81 358 minecraft:purple_concrete
setblock 142 82 323 minecraft:dark_prismarine
fill 142 82 324 142 84 324 minecraft:blue_terracotta
setblock 142 82 327 minecraft:blue_terracotta
setblock 142 82 328 minecraft:dark_prismarine
fill 142 82 329 142 85 329 minecraft:blue_terracotta
setblock 142 82 333 minecraft:dark_prismarine
fill 142 82 334 142 85 334 minecraft:blue_terracotta
setblock 142 82 338 minecraft:dark_prismarine
setblock 142 82 339 minecraft:blue_terracotta
setblock 142 82 343 minecraft:dark_prismarine
fill 142 82 344 142 83 344 minecraft:blue_terracotta
setblock 142 82 348 minecraft:dark_prismarine
fill 142 82 349 142 84 349 minecraft:blue_terracotta
setblock 142 82 359 minecraft:purple_concrete
fill 143 82 323 144 83 323 minecraft:blue_terracotta
setblock 143 82 327 minecraft:dark_prismarine
fill 143 82 328 144 84 328 minecraft:blue_terracotta
setblock 143 82 332 minecraft:dark_prismarine
fill 143 82 333 143 85 333 minecraft:blue_terracotta
fill 144 82 329 144 83 329 minecraft:blue_terracotta
setblock 146 82 323 minecraft:blue_terracotta
setblock 146 82 324 minecraft:dark_prismarine
setblock 147 82 323 minecraft:dark_prismarine
fill 147 82 324 147 85 324 minecraft:blue_terracotta
fill 148 82 323 148 85 323 minecraft:blue_terracotta
setblock 148 82 326 minecraft:blue_terracotta
setblock 149 82 326 minecraft:dark_prismarine
setblock 150 82 325 minecraft:dark_prismarine
fill 150 82 326 150 85 326 minecraft:blue_terracotta
setblock 151 82 324 minecraft:dark_prismarine
fill 151 82 325 151 85 325 minecraft:blue_terracotta
setblock 152 82 323 minecraft:dark_prismarine
fill 152 82 324 152 85 324 minecraft:blue_terracotta
setblock 152 82 327 minecraft:blue_terracotta
setblock 152 82 363 minecraft:dark_prismarine
fill 153 82 323 153 85 323 minecraft:blue_terracotta
setblock 153 82 327 minecraft:dark_prismarine
setblock 153 82 362 minecraft:dark_prismarine
fill 153 82 363 156 82 363 minecraft:blue_terracotta
setblock 154 82 326 minecraft:dark_prismarine
fill 154 82 327 154 83 327 minecraft:blue_terracotta
fill 154 82 362 154 85 362 minecraft:blue_terracotta
setblock 155 82 325 minecraft:dark_prismarine
fill 155 82 326 155 84 326 minecraft:blue_terracotta
setblock 156 82 324 minecraft:dark_prismarine
fill 156 82 325 156 84 325 minecraft:blue_terracotta
setblock 157 82 323 minecraft:dark_prismarine
fill 157 82 324 157 85 324 minecraft:blue_terracotta
setblock 157 82 326 minecraft:blue_terracotta
setblock 157 82 363 minecraft:dark_prismarine
fill 158 82 323 161 82 323 minecraft:blue_terracotta
setblock 158 82 362 minecraft:dark_prismarine
fill 158 82 363 158 85 363 minecraft:blue_terracotta
fill 159 82 356 159 102 356 minecraft:magenta_terracotta
setblock 161 82 324 minecraft:dark_prismarine
setblock 162 82 323 minecraft:dark_prismarine
setblock 162 82 324 minecraft:blue_terracotta
setblock 162 82 363 minecraft:dark_prismarine
fill 163 82 323 163 83 323 minecraft:blue_terracotta
fill 163 82 363 163 83 363 minecraft:blue_terracotta
setblock 167 82 323 minecraft:dark_prismarine
setblock 167 82 363 minecraft:dark_prismarine
fill 168 82 323 168 85 323 minecraft:blue_terracotta
fill 168 82 363 168 85 363 minecraft:blue_terracotta
fill 169 82 362 169 84 362 minecraft:blue_terracotta
setblock 171 82 324 minecraft:dark_prismarine
setblock 172 82 323 minecraft:dark_prismarine
fill 172 82 324 172 84 324 minecraft:blue_terracotta
setblock 172 82 363 minecraft:dark_prismarine
fill 173 82 323 173 85 323 minecraft:blue_terracotta
setblock 173 82 325 minecraft:blue_terracotta
setblock 173 82 362 minecraft:dark_prismarine
fill 173 82 363 173 85 363 minecraft:blue_terracotta
fill 174 82 362 174 83 362 minecraft:blue_terracotta
setblock 176 82 324 minecraft:dark_prismarine
setblock 177 82 323 minecraft:dark_prismarine
setblock 177 82 324 minecraft:blue_terracotta
setblock 177 82 363 minecraft:dark_prismarine
setblock 178 82 323 minecraft:blue_terracotta
setblock 178 82 363 minecraft:blue_terracotta
setblock 180 82 345 minecraft:dark_prismarine
setblock 180 82 346 minecraft:blue_terracotta
setblock 180 82 350 minecraft:dark_prismarine
fill 180 82 351 180 83 351 minecraft:blue_terracotta
setblock 181 82 344 minecraft:dark_prismarine
fill 181 82 345 181 83 345 minecraft:blue_terracotta
setblock 181 82 349 minecraft:dark_prismarine
fill 181 82 350 181 85 350 minecraft:blue_terracotta
setblock 181 82 354 minecraft:dark_prismarine
setblock 182 82 328 minecraft:dark_prismarine
fill 182 82 329 182 85 329 minecraft:blue_terracotta
setblock 182 82 333 minecraft:dark_prismarine
fill 182 82 334 182 84 335 minecraft:blue_terracotta
setblock 182 82 339 minecraft:blue_terracotta
setblock 182 82 343 minecraft:dark_prismarine
fill 182 82 344 182 85 344 minecraft:blue_terracotta
setblock 182 82 348 minecraft:dark_prismarine
fill 182 82 349 182 85 349 minecraft:blue_terracotta
setblock 182 82 353 minecraft:dark_prismarine
fill 182 82 354 182 85 354 minecraft:blue_terracotta
setblock 182 82 363 minecraft:purple_concrete
setblock 142 83 323 minecraft:blue_terracotta
setblock 142 83 327 minecraft:dark_prismarine
fill 142 83 328 142 86 328 minecraft:blue_terracotta
setblock 142 83 331 minecraft:blue_terracotta
setblock 142 83 332 minecraft:dark_prismarine
fill 142 83 333 142 86 333 minecraft:blue_terracotta
setblock 142 83 337 minecraft:dark_prismarine
setblock 142 83 340 minecraft:purple_concrete
setblock 142 83 343 minecraft:blue_terracotta
setblock 142 83 347 minecraft:dark_prismarine
fill 142 83 348 142 84 348 minecraft:blue_terracotta
setblock 142 83 351 minecraft:blue_terracotta
setblock 142 83 352 minecraft:dark_prismarine
setblock 143 83 326 minecraft:dark_prismarine
fill 143 83 327 143 86 327 minecraft:blue_terracotta
setblock 143 83 331 minecraft:dark_prismarine
fill 143 83 332 143 86 332 minecraft:blue_terracotta
fill 143 83 334 143 84 334 minecraft:blue_terracotta
fill 143 83 364 143 131 364 minecraft:black_concrete
setblock 144 83 325 minecraft:light[level=12]
setblock 144 83 330 minecraft:dark_prismarine
setblock 144 83 332 minecraft:light[level=12]
setblock 144 83 339 minecraft:light[level=12]
setblock 144 83 346 minecraft:light[level=12]
setblock 144 83 353 minecraft:light[level=12]
setblock 144 83 360 minecraft:light[level=12]
setblock 144 83 363 minecraft:purple_concrete
setblock 144 83 364 minecraft:cyan_concrete
setblock 145 83 323 minecraft:blue_terracotta
setblock 145 83 324 minecraft:dark_prismarine
setblock 146 83 323 minecraft:dark_prismarine
fill 146 83 324 146 86 324 minecraft:blue_terracotta
fill 147 83 323 147 86 323 minecraft:blue_terracotta
setblock 148 83 326 minecraft:dark_prismarine
fill 148 83 363 148 85 363 minecraft:blue_terracotta
setblock 149 83 325 minecraft:dark_prismarine
fill 149 83 326 149 85 326 minecraft:blue_terracotta
setblock 150 83 324 minecraft:dark_prismarine
fill 150 83 325 150 86 325 minecraft:blue_terracotta
setblock 151 83 323 minecraft:dark_prismarine
fill 151 83 324 151 86 324 minecraft:blue_terracotta
setblock 151 83 332 minecraft:light[level=12]
setblock 151 83 339 minecraft:light[level=12]
setblock 151 83 346 minecraft:light[level=12]
setblock 151 83 353 minecraft:light[level=12]
setblock 151 83 360 minecraft:light[level=12]
setblock 151 83 363 minecraft:dark_prismarine
fill 152 83 323 152 86 323 minecraft:blue_terracotta
setblock 152 83 327 minecraft:dark_prismarine
setblock 152 83 362 minecraft:dark_prismarine
fill 152 83 363 155 83 363 minecraft:blue_terracotta
setblock 153 83 326 minecraft:dark_prismarine
setblock 153 83 327 minecraft:blue_terracotta
fill 153 83 362 153 85 362 minecraft:blue_terracotta
setblock 154 83 325 minecraft:dark_prismarine
fill 154 83 326 154 84 326 minecraft:blue_terracotta
setblock 155 83 324 minecraft:dark_prismarine
fill 155 83 325 155 85 325 minecraft:blue_terracotta
setblock 156 83 323 minecraft:dark_prismarine
fill 156 83 324 156 86 324 minecraft:blue_terracotta
setblock 156 83 363 minecraft:dark_prismarine
fill 157 83 323 160 83 323 minecraft:blue_terracotta
fill 157 83 328 158 84 329 minecraft:spruce_planks
setblock 157 83 362 minecraft:dark_prismarine
fill 157 83 363 157 86 363 minecraft:blue_terracotta
setblock 158 83 332 minecraft:light[level=12]
setblock 158 83 339 minecraft:light[level=12]
setblock 158 83 346 minecraft:light[level=12]
setblock 158 83 353 minecraft:light[level=12]
setblock 158 83 360 minecraft:light[level=12]
fill 159 83 357 159 102 357 minecraft:magenta_terracotta
setblock 160 83 324 minecraft:dark_prismarine
setblock 161 83 323 minecraft:dark_prismarine
setblock 161 83 363 minecraft:dark_prismarine
fill 162 83 323 162 84 323 minecraft:blue_terracotta
setblock 162 83 363 minecraft:blue_terracotta
setblock 165 83 325 minecraft:light[level=12]
setblock 165 83 332 minecraft:light[level=12]
setblock 165 83 339 minecraft:light[level=12]
setblock 165 83 346 minecraft:light[level=12]
setblock 165 83 353 minecraft:light[level=12]
setblock 165 83 360 minecraft:light[level=12]
setblock 166 83 323 minecraft:dark_prismarine
setblock 166 83 363 minecraft:dark_prismarine
fill 167 83 323 167 84 323 minecraft:blue_terracotta
fill 167 83 363 167 86 363 minecraft:blue_terracotta
setblock 170 83 324 minecraft:dark_prismarine
setblock 171 83 323 minecraft:dark_prismarine
fill 171 83 324 171 84 324 minecraft:blue_terracotta
setblock 171 83 363 minecraft:dark_prismarine
fill 172 83 323 172 85 323 minecraft:blue_terracotta
setblock 172 83 325 minecraft:light[level=12]
setblock 172 83 332 minecraft:light[level=12]
setblock 172 83 339 minecraft:light[level=12]
setblock 172 83 346 minecraft:light[level=12]
setblock 172 83 353 minecraft:light[level=12]
setblock 172 83 360 minecraft:light[level=12]
setblock 172 83 362 minecraft:dark_prismarine
fill 172 83 363 172 86 363 minecraft:blue_terracotta
fill 173 83 362 173 84 362 minecraft:blue_terracotta
setblock 175 83 324 minecraft:dark_prismarine
setblock 176 83 323 minecraft:dark_prismarine
setblock 176 83 363 minecraft:dark_prismarine
setblock 177 83 323 minecraft:blue_terracotta
setblock 177 83 363 minecraft:blue_terracotta
setblock 179 83 325 minecraft:light[level=12]
setblock 179 83 332 minecraft:light[level=12]
fill 179 83 337 179 102 337 minecraft:magenta_terracotta
setblock 179 83 339 minecraft:light[level=12]
setblock 179 83 346 minecraft:light[level=12]
setblock 179 83 353 minecraft:light[level=12]
setblock 179 83 360 minecraft:light[level=12]
setblock 180 83 323 minecraft:purple_concrete
setblock 180 83 349 minecraft:dark_prismarine
fill 180 83 350 180 84 350 minecraft:blue_terracotta
setblock 181 83 344 minecraft:blue_terracotta
setblock 181 83 348 minecraft:dark_prismarine
fill 181 83 349 181 85 349 minecraft:blue_terracotta
setblock 181 83 353 minecraft:dark_prismarine
setblock 182 83 327 minecraft:dark_prismarine
fill 182 83 328 182 86 328 minecraft:blue_terracotta
setblock 182 83 331 minecraft:blue_terracotta
setblock 182 83 332 minecraft:dark_prismarine
fill 182 83 333 182 86 333 minecraft:blue_terracotta
setblock 182 83 336 minecraft:blue_terracotta
setblock 182 83 342 minecraft:dark_prismarine
fill 182 83 343 182 84 343 minecraft:blue_terracotta
setblock 182 83 347 minecraft:dark_prismarine
fill 182 83 348 182 86 348 minecraft:blue_terracotta
setblock 182 83 352 minecraft:dark_prismarine
fill 182 83 353 182 86 353 minecraft:blue_terracotta
setblock 183 83 323 minecraft:cyan_concrete
setblock 183 83 327 minecraft:cyan_concrete
setblock 142 84 326 minecraft:dark_prismarine
fill 142 84 327 142 87 327 minecraft:blue_terracotta
setblock 142 84 331 minecraft:dark_prismarine
fill 142 84 332 142 87 332 minecraft:blue_terracotta
setblock 142 84 336 minecraft:dark_prismarine
fill 142 84 337 142 87 337 minecraft:blue_terracotta
setblock 142 84 346 minecraft:dark_prismarine
setblock 142 84 347 minecraft:blue_terracotta
setblock 142 84 351 minecraft:dark_prismarine
setblock 142 84 352 minecraft:blue_terracotta
setblock 143 84 326 minecraft:blue_terracotta
setblock 143 84 330 minecraft:dark_prismarine
fill 143 84 331 144 86 331 minecraft:blue_terracotta
setblock 144 84 323 minecraft:blue_terracotta
setblock 144 84 329 minecraft:dark_prismarine
fill 144 84 330 144 86 330 minecraft:blue_terracotta
fill 144 84 364 144 127 364 minecraft:black_concrete
setblock 145 84 323 minecraft:dark_prismarine
setblock 145 84 324 minecraft:blue_terracotta
fill 146 84 323 146 87 323 minecraft:blue_terracotta
fill 147 84 349 147 85 349 minecraft:pink_terracotta
setblock 148 84 325 minecraft:dark_prismarine
setblock 148 84 335 minecraft:magenta_terracotta
fill 148 84 336 148 85 336 minecraft:pink_terracotta
fill 148 84 349 148 102 349 minecraft:magenta_terracotta
setblock 149 84 324 minecraft:dark_prismarine
fill 149 84 325 149 87 325 minecraft:blue_terracotta
setblock 150 84 323 minecraft:dark_prismarine
fill 150 84 324 150 87 324 minecraft:blue_terracotta
setblock 150 84 363 minecraft:dark_prismarine
fill 151 84 323 151 87 323 minecraft:blue_terracotta
setblock 151 84 326 minecraft:blue_terracotta
fill 151 84 363 154 84 363 minecraft:blue_terracotta
setblock 152 84 326 minecraft:dark_prismarine
fill 152 84 362 152 85 362 minecraft:blue_terracotta
setblock 153 84 325 minecraft:dark_prismarine
fill 153 84 326 153 85 326 minecraft:blue_terracotta
setblock 154 84 324 minecraft:dark_prismarine
fill 154 84 325 154 86 325 minecraft:blue_terracotta
setblock 155 84 323 minecraft:dark_prismarine
fill 155 84 324 155 86 324 minecraft:blue_terracotta
setblock 155 84 363 minecraft:dark_prismarine
fill 156 84 323 159 84 323 minecraft:blue_terracotta
setblock 156 84 362 minecraft:dark_prismarine
fill 156 84 363 156 87 363 minecraft:blue_terracotta
setblock 159 84 324 minecraft:dark_prismarine
setblock 160 84 323 minecraft:dark_prismarine
setblock 160 84 363 minecraft:dark_prismarine
setblock 161 84 323 minecraft:blue_terracotta
fill 161 84 356 161 85 356 minecraft:pink_terracotta
setblock 161 84 363 minecraft:blue_terracotta
fill 163 84 330 163 85 330 minecraft:pink_terracotta
setblock 165 84 363 minecraft:dark_prismarine
setblock 166 84 323 minecraft:blue_terracotta
fill 166 84 363 166 87 363 minecraft:blue_terracotta
setblock 170 84 323 minecraft:dark_prismarine
setblock 170 84 324 minecraft:blue_terracotta
setblock 170 84 363 minecraft:dark_prismarine
fill 171 84 323 171 86 323 minecraft:blue_terracotta
setblock 171 84 362 minecraft:dark_prismarine
fill 171 84 363 171 87 363 minecraft:blue_terracotta
setblock 172 84 362 minecraft:blue_terracotta
fill 174 84 350 174 102 350 minecraft:magenta_terracotta
setblock 175 84 323 minecraft:dark_prismarine
setblock 175 84 363 minecraft:dark_prismarine
setblock 176 84 323 minecraft:blue_terracotta
fill 176 84 349 176 102 349 minecraft:magenta_terracotta
fill 176 84 350 176 85 350 minecraft:pink_terracotta
fill 176 84 351 176 102 351 minecraft:magenta_terracotta
setblock 176 84 363 minecraft:blue_terracotta
fill 177 84 337 177 85 337 minecraft:pink_terracotta
setblock 180 84 349 minecraft:blue_terracotta
setblock 181 84 347 minecraft:dark_prismarine
fill 181 84 348 181 85 348 minecraft:blue_terracotta
setblock 181 84 352 minecraft:dark_prismarine
setblock 181 84 353 minecraft:blue_terracotta
setblock 182 84 327 minecraft:blue_terracotta
setblock 182 84 331 minecraft:dark_prismarine
fill 182 84 332 182 87 332 minecraft:blue_terracotta
setblock 182 84 336 minecraft:dark_prismarine
setblock 182 84 340 minecraft:purple_concrete
setblock 182 84 342 minecraft:blue_terracotta
setblock 182 84 346 minecraft:dark_prismarine
fill 182 84 347 182 86 347 minecraft:blue_terracotta
setblock 182 84 351 minecraft:dark_prismarine
fill 182 84 352 182 87 352 minecraft:blue_terracotta
setblock 182 84 359 minecraft:purple_concrete
fill 183 84 323 183 131 323 minecraft:black_concrete
fill 183 84 327 183 131 327 minecraft:black_concrete
setblock 142 85 325 minecraft:dark_prismarine
fill 142 85 326 142 87 326 minecraft:blue_terracotta
setblock 142 85 330 minecraft:dark_prismarine
fill 142 85 331 142 88 331 minecraft:blue_terracotta
setblock 142 85 335 minecraft:dark_prismarine
fill 142 85 336 142 88 336 minecraft:blue_terracotta
setblock 142 85 350 minecraft:dark_prismarine
setblock 142 85 352 minecraft:purple_concrete
setblock 143 85 323 minecraft:purple_concrete
setblock 143 85 328 minecraft:blue_terracotta
setblock 143 85 329 minecraft:dark_prismarine
fill 143 85 330 143 88 330 minecraft:blue_terracotta
setblock 143 85 334 minecraft:dark_prismarine
setblock 144 85 325 minecraft:light[level=13]
setblock 144 85 329 minecraft:blue_terracotta
setblock 144 85 333 minecraft:light[level=13]
setblock 144 85 341 minecraft:light[level=13]
setblock 144 85 349 minecraft:light[level=13]
setblock 144 85 357 minecraft:light[level=13]
fill 145 85 323 145 88 323 minecraft:blue_terracotta
setblock 146 85 349 minecraft:pink_terracotta
fill 146 85 351 146 86 351 minecraft:black_concrete
setblock 147 85 325 minecraft:dark_prismarine
setblock 148 85 324 minecraft:dark_prismarine
fill 148 85 325 148 86 325 minecraft:blue_terracotta
setblock 148 85 335 minecraft:pink_terracotta
setblock 149 85 323 minecraft:dark_prismarine
fill 149 85 324 149 88 324 minecraft:blue_terracotta
setblock 149 85 363 minecraft:dark_prismarine
fill 150 85 323 150 88 323 minecraft:blue_terracotta
fill 150 85 363 153 85 363 minecraft:blue_terracotta
setblock 151 85 326 minecraft:dark_prismarine
setblock 152 85 325 minecraft:dark_prismarine
setblock 152 85 326 minecraft:blue_terracotta
setblock 152 85 333 minecraft:light[level=13]
setblock 152 85 341 minecraft:light[level=13]
setblock 152 85 349 minecraft:light[level=13]
setblock 152 85 357 minecraft:light[level=13]
setblock 153 85 324 minecraft:dark_prismarine
fill 153 85 325 153 86 325 minecraft:blue_terracotta
setblock 154 85 323 minecraft:dark_prismarine
fill 154 85 324 154 87 324 minecraft:blue_terracotta
setblock 154 85 363 minecraft:dark_prismarine
fill 155 85 323 158 85 323 minecraft:blue_terracotta
fill 155 85 363 155 88 363 minecraft:blue_terracotta
setblock 159 85 323 minecraft:dark_prismarine
setblock 160 85 325 minecraft:light[level=13]
setblock 160 85 333 minecraft:light[level=13]
setblock 160 85 341 minecraft:light[level=13]
setblock 160 85 349 minecraft:light[level=13]
setblock 160 85 356 minecraft:pink_terracotta
fill 160 85 357 160 102 357 minecraft:magenta_terracotta
setblock 161 85 357 minecraft:pink_terracotta
setblock 163 85 329 minecraft:pink_terracotta
fill 164 85 328 164 102 328 minecraft:magenta_terracotta
setblock 168 85 325 minecraft:light[level=13]
setblock 168 85 333 minecraft:light[level=13]
setblock 168 85 341 minecraft:light[level=13]
setblock 168 85 349 minecraft:light[level=13]
setblock 168 85 357 minecraft:light[level=13]
setblock 169 85 323 minecraft:dark_prismarine
setblock 169 85 363 minecraft:dark_prismarine
fill 170 85 323 170 86 323 minecraft:blue_terracotta
setblock 170 85 362 minecraft:dark_prismarine
fill 170 85 363 170 88 363 minecraft:blue_terracotta
setblock 171 85 362 minecraft:blue_terracotta
setblock 174 85 323 minecraft:dark_prismarine
setblock 174 85 363 minecraft:dark_prismarine
setblock 175 85 363 minecraft:purple_concrete
setblock 176 85 325 minecraft:light[level=13]
setblock 176 85 333 minecraft:light[level=13]
setblock 176 85 341 minecraft:light[level=13]
setblock 176 85 357 minecraft:light[level=13]
setblock 181 85 351 minecraft:dark_prismarine
setblock 181 85 352 minecraft:blue_terracotta
setblock 182 85 330 minecraft:dark_prismarine
fill 182 85 331 182 88 331 minecraft:blue_terracotta
setblock 182 85 334 minecraft:blue_terracotta
setblock 182 85 335 minecraft:dark_prismarine
fill 182 85 336 182 87 337 minecraft:blue_terracotta
setblock 182 85 345 minecraft:dark_prismarine
setblock 182 85 346 minecraft:blue_terracotta
setblock 182 85 350 minecraft:dark_prismarine
fill 182 85 351 182 88 351 minecraft:blue_terracotta
setblock 182 85 355 minecraft:dark_prismarine
setblock 142 86 329 minecraft:dark_prismarine
fill 142 86 330 142 89 330 minecraft:blue_terracotta
setblock 142 86 334 minecraft:dark_prismarine
fill 142 86 335 142 89 335 minecraft:blue_terracotta
setblock 142 86 339 minecraft:purple_concrete
setblock 142 86 358 minecraft:purple_concrete
setblock 143 86 328 minecraft:dark_prismarine
fill 143 86 329 143 89 329 minecraft:blue_terracotta
setblock 143 86 333 minecraft:dark_prismarine
fill 143 86 334 143 89 334 minecraft:blue_terracotta
fill 146 86 349 147 102 349 minecraft:magenta_terracotta
setblock 147 86 324 minecraft:dark_prismarine
fill 147 86 336 148 102 336 minecraft:magenta_terracotta
setblock 148 86 323 minecraft:dark_prismarine
fill 148 86 324 148 89 324 minecraft:blue_terracotta
fill 148 86 335 148 102 335 minecraft:magenta_terracotta
setblock 148 86 363 minecraft:dark_prismarine
fill 149 86 323 149 89 323 minecraft:blue_terracotta
fill 149 86 363 152 86 363 minecraft:blue_terracotta
setblock 151 86 325 minecraft:dark_prismarine
setblock 152 86 324 minecraft:dark_prismarine
setblock 152 86 325 minecraft:blue_terracotta
setblock 153 86 323 minecraft:dark_prismarine
fill 153 86 324 153 87 324 minecraft:blue_terracotta
setblock 153 86 363 minecraft:dark_prismarine
fill 154 86 323 157 86 323 minecraft:blue_terracotta
fill 154 86 363 154 89 363 minecraft:blue_terracotta
fill 160 86 356 161 102 356 minecraft:magenta_terracotta
fill 161 86 357 161 102 357 minecraft:magenta_terracotta
setblock 162 86 323 minecraft:purple_concrete
setblock 162 86 363 minecraft:purple_concrete
fill 163 86 329 163 102 330 minecraft:magenta_terracotta
fill 165 86 330 165 102 330 minecraft:magenta_terracotta
setblock 167 86 322 minecraft:cyan_concrete
setblock 168 86 363 minecraft:dark_prismarine
fill 169 86 363 169 89 363 minecraft:blue_terracotta
setblock 173 86 363 minecraft:dark_prismarine
fill 176 86 350 176 102 350 minecraft:magenta_terracotta
fill 177 86 337 177 102 337 minecraft:magenta_terracotta
setblock 181 86 323 minecraft:purple_concrete
setblock 181 86 363 minecraft:purple_concrete
setblock 182 86 329 minecraft:dark_prismarine
fill 182 86 330 182 89 330 minecraft:blue_terracotta
setblock 182 86 334 minecraft:dark_prismarine
fill 182 86 335 182 89 335 minecraft:blue_terracotta
setblock 182 86 349 minecraft:dark_prismarine
fill 182 86 350 182 87 350 minecraft:blue_terracotta
setblock 182 86 354 minecraft:dark_prismarine
setblock 142 87 328 minecraft:dark_prismarine
fill 142 87 329 142 90 329 minecraft:blue_terracotta
setblock 142 87 333 minecraft:dark_prismarine
fill 142 87 334 142 90 334 minecraft:blue_terracotta
setblock 142 87 345 minecraft:purple_concrete
setblock 143 87 328 minecraft:blue_terracotta
setblock 143 87 331 minecraft:blue_terracotta
setblock 143 87 332 minecraft:dark_prismarine
fill 143 87 333 143 90 333 minecraft:blue_terracotta
fill 143 87 335 143 88 335 minecraft:blue_terracotta
setblock 143 87 363 minecraft:purple_concrete
setblock 147 87 323 minecraft:dark_prismarine
fill 147 87 324 147 90 324 minecraft:blue_terracotta
fill 147 87 350 147 102 350 minecraft:magenta_terracotta
fill 148 87 323 148 90 323 minecraft:blue_terracotta
fill 148 87 334 148 102 334 minecraft:magenta_terracotta
fill 148 87 363 151 87 363 minecraft:blue_terracotta
setblock 150 87 325 minecraft:dark_prismarine
setblock 151 87 324 minecraft:dark_prismarine
setblock 151 87 325 minecraft:blue_terracotta
setblock 152 87 323 minecraft:dark_prismarine
fill 152 87 324 152 88 324 minecraft:blue_terracotta
setblock 152 87 363 minecraft:dark_prismarine
fill 153 87 323 156 87 323 minecraft:blue_terracotta
fill 153 87 363 153 90 363 minecraft:blue_terracotta
setblock 157 87 364 minecraft:cyan_concrete
fill 167 87 322 167 131 322 minecraft:black_concrete
setblock 167 87 363 minecraft:dark_prismarine
fill 168 87 363 168 90 363 minecraft:blue_terracotta
setblock 172 87 363 minecraft:dark_prismarine
setblock 175 87 323 minecraft:purple_concrete
fill 182 87 329 182 88 329 minecraft:blue_terracotta
setblock 182 87 333 minecraft:dark_prismarine
fill 182 87 334 182 90 334 minecraft:blue_terracotta
setblock 182 87 341 minecraft:purple_concrete
setblock 182 87 349 minecraft:blue_terracotta
setblock 182 87 353 minecraft:dark_prismarine
setblock 182 87 354 minecraft:blue_terracotta
setblock 182 87 360 minecraft:purple_concrete
setblock 142 88 326 minecraft:purple_concrete
setblock 142 88 327 minecraft:dark_prismarine
fill 142 88 328 142 91 328 minecraft:blue_terracotta
setblock 142 88 332 minecraft:dark_prismarine
fill 142 88 333 142 91 333 minecraft:blue_terracotta
setblock 142 88 337 minecraft:dark_prismarine
setblock 142 88 351 minecraft:purple_concrete
setblock 143 88 331 minecraft:dark_prismarine
fill 143 88 332 143 91 332 minecraft:blue_terracotta
setblock 146 88 323 minecraft:dark_prismarine
fill 147 88 323 147 91 323 minecraft:blue_terracotta
fill 148 88 363 150 88 363 minecraft:blue_terracotta
fill 149 88 334 149 102 334 minecraft:magenta_terracotta
setblock 150 88 324 minecraft:dark_prismarine
fill 150 88 332 150 89 332 minecraft:spruce_planks
setblock 151 88 323 minecraft:dark_prismarine
fill 151 88 324 151 89 324 minecraft:blue_terracotta
setblock 151 88 363 minecraft:dark_prismarine
fill 152 88 323 155 88 323 minecraft:blue_terracotta
fill 152 88 363 152 91 363 minecraft:blue_terracotta
fill 157 88 364 157 93 364 minecraft:black_concrete
fill 165 88 329 165 102 329 minecraft:magenta_terracotta
setblock 166 88 363 minecraft:dark_prismarine
fill 167 88 363 167 91 363 minecraft:blue_terracotta
setblock 169 88 323 minecraft:purple_concrete
setblock 171 88 363 minecraft:dark_prismarine
setblock 174 88 363 minecraft:purple_concrete
setblock 182 88 332 minecraft:dark_prismarine
fill 182 88 333 182 91 333 minecraft:blue_terracotta
setblock 182 88 336 minecraft:blue_terracotta
setblock 182 88 337 minecraft:dark_prismarine
fill 182 88 338 182 91 338 minecraft:blue_terracotta
setblock 182 88 352 minecraft:dark_prismarine
setblock 182 88 353 minecraft:blue_terracotta
setblock 182 88 354 minecraft:purple_concrete
fill 142 89 327 142 92 327 minecraft:blue_terracotta
setblock 142 89 331 minecraft:dark_prismarine
fill 142 89 332 142 92 332 minecraft:blue_terracotta
setblock 142 89 336 minecraft:dark_prismarine
fill 142 89 337 142 91 338 minecraft:blue_terracotta
setblock 142 89 357 minecraft:purple_concrete
setblock 143 89 330 minecraft:dark_prismarine
fill 143 89 331 143 92 331 minecraft:blue_terracotta
setblock 143 89 335 minecraft:dark_prismarine
setblock 144 89 323 minecraft:purple_concrete
setblock 144 89 325 minecraft:light[level=12]
setblock 144 89 332 minecraft:light[level=12]
setblock 144 89 339 minecraft:light[level=12]
setblock 144 89 346 minecraft:light[level=12]
setblock 144 89 353 minecraft:light[level=12]
setblock 144 89 360 minecraft:light[level=12]
setblock 145 89 323 minecraft:dark_prismarine
fill 146 89 323 146 92 323 minecraft:blue_terracotta
fill 147 89 363 149 89 363 minecraft:blue_terracotta
setblock 149 89 324 minecraft:dark_prismarine
setblock 150 89 323 minecraft:dark_prismarine
fill 150 89 324 150 92 324 minecraft:blue_terracotta
fill 150 89 336 150 102 336 minecraft:magenta_terracotta
setblock 150 89 363 minecraft:dark_prismarine
fill 151 89 323 154 89 323 minecraft:blue_terracotta
setblock 151 89 325 minecraft:light[level=12]
setblock 151 89 332 minecraft:light[level=12]
setblock 151 89 339 minecraft:light[level=12]
setblock 151 89 346 minecraft:light[level=12]
setblock 151 89 353 minecraft:light[level=12]
setblock 151 89 360 minecraft:light[level=12]
fill 151 89 363 151 92 363 minecraft:blue_terracotta
setblock 155 89 363 minecraft:dark_prismarine
setblock 158 89 325 minecraft:light[level=12]
setblock 158 89 332 minecraft:light[level=12]
setblock 158 89 339 minecraft:light[level=12]
setblock 158 89 346 minecraft:light[level=12]
setblock 158 89 353 minecraft:light[level=12]
setblock 158 89 360 minecraft:light[level=12]
setblock 161 89 363 minecraft:purple_concrete
setblock 163 89 323 minecraft:purple_concrete
setblock 165 89 325 minecraft:light[level=12]
setblock 165 89 332 minecraft:light[level=12]
setblock 165 89 339 minecraft:light[level=12]
setblock 165 89 346 minecraft:light[level=12]
setblock 165 89 353 minecraft:light[level=12]
setblock 165 89 360 minecraft:light[level=12]
fill 166 89 363 166 92 363 minecraft:blue_terracotta
fill 167 89 334 168 90 335 minecraft:black_concrete
setblock 170 89 363 minecraft:dark_prismarine
fill 171 89 363 171 92 363 minecraft:blue_terracotta
setblock 172 89 325 minecraft:light[level=12]
setblock 172 89 332 minecraft:light[level=12]
setblock 172 89 339 minecraft:light[level=12]
setblock 172 89 346 minecraft:light[level=12]
setblock 172 89 353 minecraft:light[level=12]
setblock 172 89 360 minecraft:light[level=12]
fill 174 89 351 174 102 351 minecraft:magenta_terracotta
setblock 179 89 325 minecraft:light[level=12]
setblock 179 89 332 minecraft:light[level=12]
setblock 179 89 339 minecraft:light[level=12]
setblock 179 89 346 minecraft:light[level=12]
setblock 179 89 353 minecraft:light[level=12]
setblock 179 89 360 minecraft:light[level=12]
setblock 180 89 363 minecraft:purple_concrete
setblock 182 89 329 minecraft:purple_concrete
setblock 182 89 331 minecraft:dark_prismarine
fill 182 89 332 182 92 332 minecraft:blue_terracotta
setblock 182 89 336 minecraft:dark_prismarine
fill 182 89 337 182 92 337 minecraft:blue_terracotta
fill 182 89 339 182 90 339 minecraft:blue_terracotta
setblock 182 89 348 minecraft:purple_concrete
fill 141 90 345 141 131 345 minecraft:black_concrete
setblock 141 90 346 minecraft:cyan_concrete
fill 141 90 347 141 109 349 minecraft:black_concrete
setblock 141 90 350 minecraft:cyan_concrete
setblock 142 90 330 minecraft:dark_prismarine
fill 142 90 331 142 93 331 minecraft:blue_terracotta
setblock 142 90 335 minecraft:dark_prismarine
fill 142 90 336 143 92 336 minecraft:blue_terracotta
setblock 142 90 344 minecraft:purple_concrete
setblock 142 90 363 minecraft:purple_concrete
setblock 143 90 329 minecraft:dark_prismarine
fill 143 90 330 143 93 330 minecraft:blue_terracotta
setblock 143 90 334 minecraft:dark_prismarine
fill 143 90 335 143 93 335 minecraft:blue_terracotta
fill 143 90 337 145 90 338 minecraft:dark_prismarine
setblock 144 90 332 minecraft:blue_terracotta
setblock 144 90 333 minecraft:dark_prismarine
fill 145 90 323 145 93 323 minecraft:blue_terracotta
fill 146 90 337 146 91 337 minecraft:dark_prismarine
fill 146 90 363 148 90 363 minecraft:blue_terracotta
setblock 148 90 324 minecraft:dark_prismarine
setblock 149 90 323 minecraft:dark_prismarine
fill 149 90 324 149 93 324 minecraft:blue_terracotta
setblock 149 90 362 minecraft:blue_terracotta
setblock 149 90 363 minecraft:dark_prismarine
fill 150 90 323 153 90 323 minecraft:blue_terracotta
fill 150 90 337 150 91 337 minecraft:dark_prismarine
setblock 150 90 362 minecraft:dark_prismarine
fill 150 90 363 150 93 363 minecraft:blue_terracotta
fill 151 90 362 152 92 362 minecraft:blue_terracotta
setblock 154 90 363 minecraft:dark_prismarine
fill 155 90 363 155 93 363 minecraft:blue_terracotta
setblock 157 90 323 minecraft:purple_concrete
fill 159 90 355 159 102 355 minecraft:magenta_terracotta
setblock 164 90 363 minecraft:dark_prismarine
fill 165 90 363 165 93 363 minecraft:blue_terracotta
fill 168 90 362 168 91 362 minecraft:blue_terracotta
setblock 169 90 363 minecraft:dark_prismarine
fill 170 90 363 170 93 363 minecraft:blue_terracotta
fill 181 90 334 181 90 335 minecraft:blue_terracotta
setblock 182 90 323 minecraft:purple_concrete
setblock 182 90 329 minecraft:blue_terracotta
setblock 182 90 330 minecraft:dark_prismarine
fill 182 90 331 182 93 331 minecraft:blue_terracotta
setblock 182 90 335 minecraft:dark_prismarine
fill 182 90 336 182 93 336 minecraft:blue_terracotta
setblock 182 90 340 minecraft:dark_prismarine
setblock 182 90 342 minecraft:purple_concrete
fill 141 91 346 141 128 346 minecraft:black_concrete
fill 141 91 350 141 92 350 minecraft:black_concrete
setblock 142 91 325 minecraft:purple_concrete
setblock 142 91 329 minecraft:dark_prismarine
fill 142 91 330 142 94 330 minecraft:blue_terracotta
setblock 142 91 334 minecraft:dark_prismarine
fill 142 91 335 142 94 335 minecraft:blue_terracotta
setblock 142 91 339 minecraft:dark_prismarine
setblock 142 91 350 minecraft:purple_concrete
fill 143 91 329 143 94 329 minecraft:blue_terracotta
setblock 143 91 333 minecraft:dark_prismarine
fill 143 91 334 144 93 334 minecraft:blue_terracotta
setblock 143 91 337 minecraft:blue_terracotta
fill 143 91 338 148 91 338 minecraft:dark_prismarine
fill 144 91 323 144 94 323 minecraft:blue_terracotta
setblock 144 91 331 minecraft:blue_terracotta
setblock 144 91 332 minecraft:dark_prismarine
fill 144 91 333 144 94 333 minecraft:blue_terracotta
fill 144 91 335 144 92 335 minecraft:blue_terracotta
fill 144 91 337 145 91 337 minecraft:dark_prismarine
fill 145 91 350 145 102 350 minecraft:magenta_terracotta
fill 145 91 363 147 91 363 minecraft:blue_terracotta
setblock 146 91 324 minecraft:blue_terracotta
setblock 147 91 324 minecraft:dark_prismarine
fill 147 91 362 148 91 362 minecraft:blue_terracotta
setblock 148 91 323 minecraft:dark_prismarine
fill 148 91 324 148 94 324 minecraft:blue_terracotta
setblock 148 91 363 minecraft:dark_prismarine
fill 149 91 323 152 91 323 minecraft:blue_terracotta
setblock 149 91 362 minecraft:dark_prismarine
fill 149 91 363 149 94 363 minecraft:blue_terracotta
fill 150 91 335 150 102 335 minecraft:magenta_terracotta
fill 150 91 362 150 94 362 minecraft:blue_terracotta
fill 151 91 336 158 91 337 minecraft:dark_prismarine
setblock 153 91 323 minecraft:dark_prismarine
setblock 153 91 362 minecraft:blue_terracotta
setblock 153 91 363 minecraft:dark_prismarine
fill 154 91 363 154 94 363 minecraft:blue_terracotta
fill 156 91 363 156 92 363 minecraft:blue_terracotta
fill 159 91 336 166 92 336 minecraft:dark_prismarine
fill 160 91 335 171 91 335 minecraft:dark_prismarine
setblock 162 91 363 minecraft:blue_terracotta
setblock 163 91 363 minecraft:dark_prismarine
fill 164 91 363 164 94 363 minecraft:blue_terracotta
fill 165 91 362 167 92 362 minecraft:blue_terracotta
setblock 168 91 363 minecraft:dark_prismarine
setblock 169 91 362 minecraft:dark_prismarine
fill 169 91 363 169 94 363 minecraft:blue_terracotta
setblock 173 91 363 minecraft:purple_concrete
setblock 176 91 323 minecraft:purple_concrete
fill 179 91 338 179 102 338 minecraft:magenta_terracotta
fill 181 91 333 181 91 334 minecraft:blue_terracotta
setblock 181 91 335 minecraft:dark_prismarine
fill 181 91 336 181 93 337 minecraft:blue_terracotta
setblock 182 91 329 minecraft:dark_prismarine
fill 182 91 330 182 94 330 minecraft:blue_terracotta
setblock 182 91 334 minecraft:dark_prismarine
fill 182 91 335 182 94 335 minecraft:blue_terracotta
setblock 182 91 339 minecraft:dark_prismarine
fill 182 91 340 182 93 341 minecraft:blue_terracotta
setblock 182 91 361 minecraft:purple_concrete
fill 141 92 326 141 117 326 minecraft:black_concrete
setblock 141 92 327 minecraft:light_blue_wool
fill 142 92 325 142 93 326 minecraft:blue_terracotta
setblock 142 92 328 minecraft:dark_prismarine
fill 142 92 329 142 95 329 minecraft:blue_terracotta
setblock 142 92 333 minecraft:dark_prismarine
fill 142 92 334 142 95 334 minecraft:blue_terracotta
setblock 142 92 337 minecraft:blue_terracotta
setblock 142 92 338 minecraft:dark_prismarine
fill 142 92 339 142 94 340 minecraft:blue_terracotta
fill 142 92 355 142 92 357 minecraft:blue_terracotta
setblock 142 92 358 minecraft:dark_prismarine
fill 142 92 359 142 94 360 minecraft:blue_terracotta
fill 143 92 323 143 95 323 minecraft:blue_terracotta
fill 143 92 328 143 95 328 minecraft:blue_terracotta
setblock 143 92 332 minecraft:dark_prismarine
fill 143 92 333 143 95 333 minecraft:blue_terracotta
setblock 143 92 337 minecraft:dark_prismarine
fill 143 92 338 143 94 339 minecraft:blue_terracotta
fill 143 92 363 146 92 363 minecraft:blue_terracotta
setblock 144 92 331 minecraft:dark_prismarine
fill 144 92 332 144 95 332 minecraft:blue_terracotta
setblock 144 92 336 minecraft:dark_prismarine
fill 144 92 337 146 92 337 minecraft:purple_concrete
setblock 145 92 324 minecraft:blue_terracotta
fill 145 92 362 147 92 362 minecraft:blue_terracotta
setblock 146 92 324 minecraft:dark_prismarine
setblock 147 92 323 minecraft:dark_prismarine
fill 147 92 324 147 95 324 minecraft:blue_terracotta
setblock 147 92 363 minecraft:dark_prismarine
fill 148 92 323 151 92 323 minecraft:blue_terracotta
setblock 148 92 361 minecraft:blue_terracotta
setblock 148 92 362 minecraft:dark_prismarine
fill 148 92 363 148 95 363 minecraft:blue_terracotta
setblock 149 92 361 minecraft:dark_prismarine
fill 149 92 362 149 95 362 minecraft:blue_terracotta
fill 150 92 337 152 92 337 minecraft:purple_concrete
fill 150 92 361 151 94 361 minecraft:blue_terracotta
setblock 152 92 323 minecraft:dark_prismarine
setblock 152 92 363 minecraft:dark_prismarine
setblock 153 92 322 minecraft:cyan_concrete
fill 153 92 323 153 95 323 minecraft:blue_terracotta
setblock 153 92 362 minecraft:dark_prismarine
fill 153 92 363 153 95 363 minecraft:blue_terracotta
fill 154 92 322 159 127 322 minecraft:black_concrete
fill 154 92 336 158 92 336 minecraft:dark_prismarine
fill 154 92 362 154 95 362 minecraft:blue_terracotta
setblock 157 92 363 minecraft:dark_prismarine
fill 158 92 363 161 92 363 minecraft:blue_terracotta
fill 161 92 335 179 92 335 minecraft:dark_prismarine
setblock 162 92 363 minecraft:dark_prismarine
setblock 163 92 362 minecraft:dark_prismarine
fill 163 92 363 163 95 363 minecraft:blue_terracotta
fill 164 92 362 164 95 362 minecraft:blue_terracotta
fill 165 92 361 168 92 361 minecraft:blue_terracotta
fill 167 92 336 169 92 336 minecraft:dark_prismarine
setblock 167 92 363 minecraft:dark_prismarine
setblock 168 92 362 minecraft:dark_prismarine
fill 168 92 363 168 95 363 minecraft:blue_terracotta
fill 169 92 362 170 94 362 minecraft:blue_terracotta
setblock 170 92 323 minecraft:purple_concrete
fill 170 92 334 181 92 334 minecraft:dark_prismarine
fill 175 92 352 175 102 352 minecraft:magenta_terracotta
setblock 179 92 363 minecraft:purple_concrete
fill 181 92 332 181 92 333 minecraft:blue_terracotta
fill 181 92 335 181 95 335 minecraft:blue_terracotta
setblock 181 92 338 minecraft:blue_terracotta
setblock 181 92 339 minecraft:dark_prismarine
fill 182 92 329 182 95 329 minecraft:blue_terracotta
setblock 182 92 333 minecraft:dark_prismarine
fill 182 92 334 182 95 334 minecraft:blue_terracotta
setblock 182 92 338 minecraft:dark_prismarine
fill 182 92 339 182 95 339 minecraft:blue_terracotta
setblock 182 92 342 minecraft:blue_terracotta
fill 182 92 354 182 92 357 minecraft:blue_terracotta
fill 141 93 327 141 131 327 minecraft:black_concrete
setblock 141 93 350 minecraft:light_blue_wool
fill 142 93 323 142 95 324 minecraft:blue_terracotta
setblock 142 93 327 minecraft:dark_prismarine
fill 142 93 328 142 96 328 minecraft:blue_terracotta
setblock 142 93 332 minecraft:dark_prismarine
fill 142 93 333 142 96 333 minecraft:blue_terracotta
setblock 142 93 336 minecraft:blue_terracotta
setblock 142 93 337 minecraft:dark_prismarine
fill 142 93 338 142 96 338 minecraft:blue_terracotta
setblock 142 93 341 minecraft:blue_terracotta
fill 142 93 354 142 93 356 minecraft:blue_terracotta
setblock 142 93 357 minecraft:dark_prismarine
fill 142 93 358 143 95 358 minecraft:blue_terracotta
setblock 142 93 361 minecraft:blue_terracotta
setblock 142 93 362 minecraft:dark_prismarine
fill 142 93 363 145 93 363 minecraft:blue_terracotta
fill 143 93 327 143 96 327 minecraft:blue_terracotta
setblock 143 93 331 minecraft:dark_prismarine
fill 143 93 332 143 96 332 minecraft:blue_terracotta
setblock 143 93 336 minecraft:dark_prismarine
fill 143 93 337 144 95 337 minecraft:blue_terracotta
setblock 143 93 340 minecraft:blue_terracotta
setblock 143 93 356 minecraft:dark_prismarine
fill 143 93 357 143 96 357 minecraft:blue_terracotta
fill 143 93 359 143 93 360 minecraft:blue_terracotta
setblock 143 93 361 minecraft:dark_prismarine
fill 143 93 362 146 93 362 minecraft:blue_terracotta
setblock 144 93 324 minecraft:blue_terracotta
setblock 144 93 325 minecraft:light[level=13]
setblock 144 93 330 minecraft:dark_prismarine
fill 144 93 331 144 96 331 minecraft:blue_terracotta
setblock 144 93 335 minecraft:dark_prismarine
fill 144 93 336 144 96 336 minecraft:blue_terracotta
fill 144 93 338 144 94 338 minecraft:blue_terracotta
setblock 144 93 341 minecraft:light[level=13]
setblock 144 93 349 minecraft:light[level=13]
setblock 144 93 357 minecraft:light[level=13]
setblock 145 93 324 minecraft:dark_prismarine
fill 145 93 348 145 102 348 minecraft:magenta_terracotta
fill 145 93 361 147 93 361 minecraft:blue_terracotta
setblock 146 93 323 minecraft:dark_prismarine
fill 146 93 324 146 96 324 minecraft:blue_terracotta
setblock 146 93 363 minecraft:dark_prismarine
fill 147 93 323 150 93 323 minecraft:blue_terracotta
setblock 147 93 362 minecraft:dark_prismarine
fill 147 93 363 147 96 363 minecraft:blue_terracotta
setblock 148 93 361 minecraft:dark_prismarine
fill 148 93 362 148 96 362 minecraft:blue_terracotta
fill 149 93 361 149 96 361 minecraft:blue_terracotta
setblock 150 93 324 minecraft:dark_prismarine
setblock 151 93 323 minecraft:dark_prismarine
setblock 151 93 362 minecraft:blue_terracotta
setblock 151 93 363 minecraft:dark_prismarine
fill 152 93 323 152 96 323 minecraft:blue_terracotta
setblock 152 93 325 minecraft:light[level=13]
setblock 152 93 333 minecraft:light[level=13]
setblock 152 93 341 minecraft:light[level=13]
setblock 152 93 349 minecraft:light[level=13]
setblock 152 93 357 minecraft:light[level=13]
setblock 152 93 361 minecraft:blue_terracotta
setblock 152 93 362 minecraft:dark_prismarine
fill 152 93 363 152 96 363 minecraft:blue_terracotta
fill 153 93 322 153 111 322 minecraft:black_concrete
fill 153 93 362 153 96 362 minecraft:blue_terracotta
fill 155 93 362 155 94 362 minecraft:blue_terracotta
fill 156 93 336 164 93 336 minecraft:purple_concrete
setblock 156 93 363 minecraft:dark_prismarine
fill 157 93 363 160 93 363 minecraft:blue_terracotta
setblock 160 93 325 minecraft:light[level=13]
setblock 160 93 333 minecraft:light[level=13]
setblock 160 93 341 minecraft:light[level=13]
setblock 160 93 349 minecraft:light[level=13]
fill 160 93 362 161 93 362 minecraft:blue_terracotta
setblock 161 93 363 minecraft:dark_prismarine
fill 162 93 356 162 94 356 minecraft:magenta_terracotta
setblock 162 93 362 minecraft:dark_prismarine
fill 162 93 363 162 96 363 minecraft:blue_terracotta
setblock 163 93 361 minecraft:dark_prismarine
fill 163 93 362 163 96 362 minecraft:blue_terracotta
setblock 164 93 323 minecraft:purple_concrete
fill 164 93 335 172 93 335 minecraft:purple_concrete
fill 164 93 361 167 93 361 minecraft:blue_terracotta
fill 165 93 331 165 102 331 minecraft:magenta_terracotta
fill 165 93 362 166 93 362 minecraft:blue_terracotta
setblock 166 93 363 minecraft:dark_prismarine
setblock 167 93 362 minecraft:dark_prismarine
fill 167 93 363 167 96 363 minecraft:blue_terracotta
setblock 168 93 325 minecraft:light[level=13]
setblock 168 93 333 minecraft:light[level=13]
setblock 168 93 341 minecraft:light[level=13]
setblock 168 93 349 minecraft:light[level=13]
setblock 168 93 357 minecraft:light[level=13]
setblock 168 93 361 minecraft:dark_prismarine
fill 168 93 362 168 96 362 minecraft:blue_terracotta
fill 169 93 361 169 96 361 minecraft:blue_terracotta
setblock 171 93 362 minecraft:blue_terracotta
setblock 171 93 363 minecraft:dark_prismarine
fill 172 93 363 172 96 363 minecraft:blue_terracotta
fill 173 93 335 176 93 335 minecraft:dark_prismarine
fill 174 93 349 174 102 349 minecraft:magenta_terracotta
fill 175 93 334 180 93 334 minecraft:dark_prismarine
setblock 176 93 325 minecraft:light[level=13]
setblock 176 93 333 minecraft:light[level=13]
setblock 176 93 341 minecraft:light[level=13]
setblock 176 93 357 minecraft:light[level=13]
fill 181 93 331 181 93 332 minecraft:blue_terracotta
setblock 181 93 333 minecraft:dark_prismarine
fill 181 93 334 181 96 334 minecraft:blue_terracotta
setblock 181 93 338 minecraft:dark_prismarine
fill 181 93 339 181 94 341 minecraft:blue_terracotta
setblock 182 93 324 minecraft:purple_concrete
fill 182 93 328 182 96 328 minecraft:blue_terracotta
setblock 182 93 332 minecraft:dark_prismarine
fill 182 93 333 182 96 333 minecraft:blue_terracotta
setblock 182 93 337 minecraft:dark_prismarine
fill 182 93 338 182 96 338 minecraft:blue_terracotta
setblock 182 93 342 minecraft:dark_prismarine
fill 182 93 343 182 95 344 minecraft:blue_terracotta
setblock 182 93 349 minecraft:purple_concrete
fill 182 93 353 182 93 356 minecraft:blue_terracotta
setblock 182 93 357 minecraft:dark_prismarine
fill 182 93 358 182 94 360 minecraft:blue_terracotta
setblock 183 93 352 minecraft:cyan_concrete
fill 141 94 350 141 127 350 minecraft:black_concrete
setblock 142 94 325 minecraft:blue_terracotta
setblock 142 94 326 minecraft:dark_prismarine
fill 142 94 327 142 97 327 minecraft:blue_terracotta
setblock 142 94 331 minecraft:dark_prismarine
fill 142 94 332 142 97 332 minecraft:blue_terracotta
setblock 142 94 336 minecraft:dark_prismarine
fill 142 94 337 142 97 337 minecraft:blue_terracotta
setblock 142 94 341 minecraft:dark_prismarine
fill 142 94 342 142 96 343 minecraft:blue_terracotta
fill 142 94 353 142 94 355 minecraft:blue_terracotta
setblock 142 94 356 minecraft:dark_prismarine
fill 142 94 357 142 97 357 minecraft:blue_terracotta
setblock 142 94 361 minecraft:dark_prismarine
fill 142 94 362 144 94 363 minecraft:blue_terracotta
setblock 143 94 324 minecraft:blue_terracotta
setblock 143 94 325 minecraft:dark_prismarine
fill 143 94 326 143 97 326 minecraft:blue_terracotta
setblock 143 94 330 minecraft:dark_prismarine
fill 143 94 331 143 97 331 minecraft:blue_terracotta
setblock 143 94 334 minecraft:blue_terracotta
setblock 143 94 335 minecraft:dark_prismarine
fill 143 94 336 143 97 336 minecraft:blue_terracotta
setblock 143 94 340 minecraft:dark_prismarine
fill 143 94 341 143 97 341 minecraft:blue_terracotta
setblock 143 94 355 minecraft:dark_prismarine
fill 143 94 356 143 97 356 minecraft:blue_terracotta
setblock 143 94 359 minecraft:blue_terracotta
setblock 143 94 360 minecraft:dark_prismarine
fill 143 94 361 146 94 361 minecraft:blue_terracotta
setblock 144 94 324 minecraft:dark_prismarine
fill 144 94 330 144 96 330 minecraft:blue_terracotta
setblock 144 94 334 minecraft:dark_prismarine
fill 144 94 335 144 97 335 minecraft:blue_terracotta
setblock 144 94 339 minecraft:dark_prismarine
fill 144 94 357 144 94 358 minecraft:blue_terracotta
setblock 144 94 359 minecraft:dark_prismarine
fill 144 94 360 144 97 360 minecraft:blue_terracotta
setblock 145 94 323 minecraft:dark_prismarine
fill 145 94 324 145 97 324 minecraft:blue_terracotta
setblock 145 94 362 minecraft:blue_terracotta
setblock 145 94 363 minecraft:dark_prismarine
fill 146 94 323 149 94 323 minecraft:blue_terracotta
setblock 146 94 362 minecraft:dark_prismarine
fill 146 94 363 146 97 363 minecraft:blue_terracotta
setblock 147 94 360 minecraft:blue_terracotta
setblock 147 94 361 minecraft:dark_prismarine
fill 147 94 362 147 97 362 minecraft:blue_terracotta
setblock 148 94 360 minecraft:dark_prismarine
fill 148 94 361 148 97 361 minecraft:blue_terracotta
setblock 149 94 324 minecraft:dark_prismarine
fill 149 94 360 150 96 360 minecraft:blue_terracotta
setblock 150 94 323 minecraft:dark_prismarine
fill 150 94 324 150 97 324 minecraft:blue_terracotta
setblock 150 94 363 minecraft:dark_prismarine
fill 151 94 323 151 97 323 minecraft:blue_terracotta
setblock 151 94 362 minecraft:dark_prismarine
fill 151 94 363 151 97 363 minecraft:blue_terracotta
setblock 152 94 361 minecraft:dark_prismarine
fill 152 94 362 152 97 362 minecraft:blue_terracotta
fill 153 94 361 153 97 361 minecraft:blue_terracotta
setblock 155 94 363 minecraft:dark_prismarine
setblock 156 94 362 minecraft:dark_prismarine
fill 156 94 363 159 94 363 minecraft:blue_terracotta
fill 157 94 362 160 94 362 minecraft:blue_terracotta
setblock 157 94 364 minecraft:cyan_concrete
setblock 158 94 323 minecraft:purple_concrete
setblock 160 94 363 minecraft:dark_prismarine
setblock 161 94 361 minecraft:blue_terracotta
setblock 161 94 362 minecraft:dark_prismarine
fill 161 94 363 161 97 363 minecraft:blue_terracotta
setblock 162 94 361 minecraft:dark_prismarine
fill 162 94 362 162 97 362 minecraft:blue_terracotta
fill 163 94 361 166 94 361 minecraft:blue_terracotta
fill 164 94 360 167 94 360 minecraft:blue_terracotta
setblock 165 94 323 minecraft:dark_prismarine
setblock 165 94 362 minecraft:blue_terracotta
setblock 165 94 363 minecraft:dark_prismarine
fill 166 94 323 168 95 323 minecraft:blue_terracotta
setblock 166 94 362 minecraft:dark_prismarine
fill 166 94 363 166 97 363 minecraft:blue_terracotta
setblock 167 94 361 minecraft:dark_prismarine
fill 167 94 362 167 97 362 minecraft:blue_terracotta
setblock 168 94 360 minecraft:dark_prismarine
fill 168 94 361 168 97 361 minecraft:blue_terracotta
fill 170 94 361 170 95 361 minecraft:blue_terracotta
setblock 170 94 363 minecraft:dark_prismarine
setblock 171 94 362 minecraft:dark_prismarine
fill 171 94 363 171 97 363 minecraft:blue_terracotta
setblock 175 94 322 minecraft:cyan_concrete
fill 176 94 334 179 94 334 minecraft:purple_concrete
setblock 177 94 323 minecraft:purple_concrete
setblock 178 94 339 minecraft:magenta_terracotta
fill 180 94 334 180 94 337 minecraft:blue_terracotta
setblock 180 94 338 minecraft:dark_prismarine
fill 180 94 339 180 97 339 minecraft:blue_terracotta
setblock 181 94 331 minecraft:blue_terracotta
setblock 181 94 332 minecraft:dark_prismarine
fill 181 94 333 181 97 333 minecraft:blue_terracotta
setblock 181 94 336 minecraft:blue_terracotta
setblock 181 94 337 minecraft:dark_prismarine
fill 181 94 338 181 97 338 minecraft:blue_terracotta
setblock 181 94 342 minecraft:dark_prismarine
setblock 182 94 326 minecraft:dark_prismarine
fill 182 94 327 182 97 327 minecraft:blue_terracotta
setblock 182 94 331 minecraft:dark_prismarine
fill 182 94 332 182 97 332 minecraft:blue_terracotta
setblock 182 94 336 minecraft:dark_prismarine
fill 182 94 337 182 97 337 minecraft:blue_terracotta
setblock 182 94 340 minecraft:blue_terracotta
setblock 182 94 341 minecraft:dark_prismarine
fill 182 94 342 182 97 342 minecraft:blue_terracotta
setblock 182 94 345 minecraft:blue_terracotta
fill 182 94 353 182 94 355 minecraft:blue_terracotta
setblock 182 94 356 minecraft:dark_prismarine
fill 182 94 357 182 97 357 minecraft:blue_terracotta
setblock 182 94 361 minecraft:dark_prismarine
fill 182 94 362 182 97 362 minecraft:blue_terracotta
fill 183 94 352 183 131 352 minecraft:black_concrete
setblock 142 95 325 minecraft:dark_prismarine
fill 142 95 326 142 97 326 minecraft:blue_terracotta
setblock 142 95 330 minecraft:dark_prismarine
fill 142 95 331 142 97 331 minecraft:blue_terracotta
setblock 142 95 335 minecraft:dark_prismarine
fill 142 95 336 142 97 336 minecraft:blue_terracotta
setblock 142 95 339 minecraft:blue_terracotta
setblock 142 95 340 minecraft:dark_prismarine
fill 142 95 341 142 97 341 minecraft:blue_terracotta
setblock 142 95 344 minecraft:blue_terracotta
setblock 142 95 349 minecraft:purple_concrete
fill 142 95 353 142 95 354 minecraft:blue_terracotta
setblock 142 95 355 minecraft:dark_prismarine
fill 142 95 356 142 97 356 minecraft:blue_terracotta
setblock 142 95 359 minecraft:blue_terracotta
setblock 142 95 360 minecraft:dark_prismarine
fill 142 95 361 143 95 363 minecraft:blue_terracotta
setblock 143 95 324 minecraft:dark_prismarine
fill 143 95 325 143 97 325 minecraft:blue_terracotta
setblock 143 95 329 minecraft:dark_prismarine
fill 143 95 330 143 97 330 minecraft:blue_terracotta
setblock 143 95 334 minecraft:dark_prismarine
fill 143 95 335 143 97 335 minecraft:blue_terracotta
setblock 143 95 338 minecraft:blue_terracotta
setblock 143 95 339 minecraft:dark_prismarine
fill 143 95 340 144 97 340 minecraft:blue_terracotta
fill 143 95 342 143 96 342 minecraft:blue_terracotta
fill 143 95 355 143 97 355 minecraft:blue_terracotta
setblock 143 95 359 minecraft:dark_prismarine
fill 143 95 360 143 97 360 minecraft:blue_terracotta
setblock 144 95 323 minecraft:dark_prismarine
fill 144 95 324 144 97 324 minecraft:blue_terracotta
setblock 144 95 325 minecraft:light[level=12]
fill 144 95 329 144 96 329 minecraft:blue_terracotta
setblock 144 95 333 minecraft:dark_prismarine
fill 144 95 334 144 97 334 minecraft:blue_terracotta
setblock 144 95 338 minecraft:dark_prismarine
fill 144 95 339 144 97 339 minecraft:blue_terracotta
setblock 144 95 346 minecraft:light[level=12]
setblock 144 95 353 minecraft:light[level=12]
fill 144 95 356 144 95 357 minecraft:blue_terracotta
setblock 144 95 358 minecraft:dark_prismarine
fill 144 95 359 145 97 359 minecraft:blue_terracotta
fill 144 95 361 144 95 362 minecraft:blue_terracotta
setblock 144 95 363 minecraft:dark_prismarine
fill 145 95 323 148 95 323 minecraft:blue_terracotta
fill 145 95 325 146 95 325 minecraft:blue_terracotta
fill 145 95 335 145 95 336 minecraft:blue_terracotta
fill 145 95 360 145 95 361 minecraft:blue_terracotta
setblock 145 95 362 minecraft:dark_prismarine
fill 145 95 363 145 97 363 minecraft:blue_terracotta
setblock 146 95 360 minecraft:blue_terracotta
setblock 146 95 361 minecraft:dark_prismarine
fill 146 95 362 146 97 362 minecraft:blue_terracotta
setblock 147 95 325 minecraft:dark_prismarine
setblock 147 95 360 minecraft:dark_prismarine
fill 147 95 361 147 97 361 minecraft:blue_terracotta
setblock 148 95 324 minecraft:dark_prismarine
fill 148 95 337 148 102 337 minecraft:magenta_terracotta
fill 148 95 360 148 97 360 minecraft:blue_terracotta
setblock 149 95 323 minecraft:dark_prismarine
fill 149 95 324 149 97 324 minecraft:blue_terracotta
setblock 149 95 363 minecraft:dark_prismarine
fill 150 95 323 150 97 323 minecraft:blue_terracotta
setblock 150 95 361 minecraft:blue_terracotta
setblock 150 95 362 minecraft:dark_prismarine
fill 150 95 363 150 97 363 minecraft:blue_terracotta
setblock 151 95 325 minecraft:light[level=12]
setblock 151 95 332 minecraft:light[level=12]
setblock 151 95 339 minecraft:light[level=12]
setblock 151 95 346 minecraft:light[level=12]
setblock 151 95 353 minecraft:light[level=12]
setblock 151 95 360 minecraft:light[level=12]
setblock 151 95 361 minecraft:dark_prismarine
fill 151 95 362 151 97 362 minecraft:blue_terracotta
fill 152 95 361 152 97 361 minecraft:blue_terracotta
setblock 154 95 323 minecraft:dark_prismarine
fill 154 95 361 155 95 361 minecraft:blue_terracotta
setblock 154 95 363 minecraft:dark_prismarine
setblock 155 95 362 minecraft:dark_prismarine
fill 155 95 363 158 95 363 minecraft:blue_terracotta
fill 156 95 362 159 95 362 minecraft:blue_terracotta
fill 157 95 364 157 128 364 minecraft:black_concrete
setblock 158 95 325 minecraft:light[level=12]
setblock 158 95 332 minecraft:light[level=12]
setblock 158 95 339 minecraft:light[level=12]
setblock 158 95 346 minecraft:light[level=12]
setblock 158 95 353 minecraft:light[level=12]
setblock 158 95 360 minecraft:light[level=12]
fill 158 95 361 160 95 361 minecraft:blue_terracotta
setblock 159 95 363 minecraft:dark_prismarine
setblock 160 95 362 minecraft:dark_prismarine
fill 160 95 363 160 97 363 minecraft:blue_terracotta
setblock 161 95 361 minecraft:dark_prismarine
fill 161 95 362 161 97 362 minecraft:blue_terracotta
fill 162 95 323 163 95 323 minecraft:blue_terracotta
setblock 162 95 360 minecraft:dark_prismarine
fill 162 95 361 165 95 361 minecraft:blue_terracotta
fill 163 95 360 166 95 360 minecraft:blue_terracotta
setblock 164 95 323 minecraft:dark_prismarine
setblock 164 95 363 minecraft:dark_prismarine
fill 165 95 323 165 97 323 minecraft:blue_terracotta
setblock 165 95 325 minecraft:light[level=12]
setblock 165 95 332 minecraft:light[level=12]
setblock 165 95 339 minecraft:light[level=12]
setblock 165 95 346 minecraft:light[level=12]
setblock 165 95 353 minecraft:light[level=12]
setblock 165 95 362 minecraft:dark_prismarine
fill 165 95 363 165 97 363 minecraft:blue_terracotta
setblock 166 95 361 minecraft:dark_prismarine
fill 166 95 362 166 97 362 minecraft:blue_terracotta
setblock 167 95 360 minecraft:dark_prismarine
fill 167 95 361 167 97 361 minecraft:blue_terracotta
fill 168 95 360 168 96 360 minecraft:blue_terracotta
setblock 169 95 323 minecraft:dark_prismarine
setblock 169 95 362 minecraft:blue_terracotta
setblock 169 95 363 minecraft:dark_prismarine
setblock 170 95 362 minecraft:dark_prismarine
fill 170 95 363 170 97 363 minecraft:blue_terracotta
setblock 171 95 323 minecraft:purple_concrete
fill 171 95 362 171 97 362 minecraft:blue_terracotta
setblock 172 95 325 minecraft:light[level=12]
setblock 172 95 332 minecraft:light[level=12]
setblock 172 95 339 minecraft:light[level=12]
setblock 172 95 346 minecraft:light[level=12]
setblock 172 95 353 minecraft:light[level=12]
setblock 172 95 360 minecraft:light[level=12]
setblock 173 95 363 minecraft:blue_terracotta
fill 174 95 336 175 96 336 minecraft:spruce_planks
fill 175 95 322 175 131 322 minecraft:black_concrete
setblock 179 95 325 minecraft:light[level=12]
setblock 179 95 332 minecraft:light[level=12]
setblock 179 95 339 minecraft:light[level=12]
setblock 179 95 346 minecraft:light[level=12]
setblock 179 95 353 minecraft:light[level=12]
setblock 179 95 360 minecraft:light[level=12]
fill 180 95 334 180 95 336 minecraft:blue_terracotta
setblock 180 95 337 minecraft:dark_prismarine
fill 180 95 338 180 97 338 minecraft:blue_terracotta
fill 180 95 340 181 95 340 minecraft:blue_terracotta
fill 181 95 323 182 96 323 minecraft:blue_terracotta
setblock 181 95 330 minecraft:blue_terracotta
setblock 181 95 331 minecraft:dark_prismarine
fill 181 95 332 181 97 332 minecraft:blue_terracotta
setblock 181 95 336 minecraft:dark_prismarine
fill 181 95 337 181 97 337 minecraft:blue_terracotta
fill 181 95 339 181 96 339 minecraft:blue_terracotta
setblock 181 95 341 minecraft:dark_prismarine
fill 181 95 342 181 97 343 minecraft:blue_terracotta
fill 181 95 363 182 96 363 minecraft:blue_terracotta
setblock 182 95 324 minecraft:blue_terracotta
setblock 182 95 325 minecraft:dark_prismarine
fill 182 95 326 182 97 326 minecraft:blue_terracotta
setblock 182 95 330 minecraft:dark_prismarine
fill 182 95 331 182 97 331 minecraft:blue_terracotta
setblock 182 95 335 minecraft:dark_prismarine
fill 182 95 336 182 97 336 minecraft:blue_terracotta
setblock 182 95 340 minecraft:dark_prismarine
fill 182 95 341 182 97 341 minecraft:blue_terracotta
setblock 182 95 345 minecraft:dark_prismarine
fill 182 95 346 182 97 347 minecraft:blue_terracotta
fill 182 95 352 182 95 354 minecraft:blue_terracotta
setblock 182 95 355 minecraft:dark_prismarine
fill 182 95 356 182 97 356 minecraft:blue_terracotta
fill 182 95 358 182 95 359 minecraft:blue_terracotta
setblock 182 95 360 minecraft:dark_prismarine
fill 182 95 361 182 97 361 minecraft:blue_terracotta
setblock 142 96 323 minecraft:blue_terracotta
setblock 142 96 324 minecraft:dark_prismarine
fill 142 96 325 142 97 325 minecraft:blue_terracotta
setblock 142 96 329 minecraft:dark_prismarine
fill 142 96 330 142 97 330 minecraft:blue_terracotta
setblock 142 96 334 minecraft:dark_prismarine
fill 142 96 335 142 97 335 minecraft:blue_terracotta
setblock 142 96 339 minecraft:dark_prismarine
fill 142 96 340 142 97 340 minecraft:blue_terracotta
setblock 142 96 344 minecraft:dark_prismarine
fill 142 96 345 142 97 345 minecraft:blue_terracotta
setblock 142 96 353 minecraft:blue_terracotta
setblock 142 96 354 minecraft:dark_prismarine
fill 142 96 355 142 97 355 minecraft:blue_terracotta
setblock 142 96 358 minecraft:blue_terracotta
setblock 142 96 359 minecraft:dark_prismarine
fill 142 96 360 142 96 363 minecraft:blue_terracotta
setblock 143 96 323 minecraft:dark_prismarine
fill 143 96 324 143 97 324 minecraft:blue_terracotta
setblock 143 96 328 minecraft:dark_prismarine
fill 143 96 329 143 97 329 minecraft:blue_terracotta
setblock 143 96 333 minecraft:dark_prismarine
fill 143 96 334 143 97 334 minecraft:blue_terracotta
setblock 143 96 337 minecraft:blue_terracotta
setblock 143 96 338 minecraft:dark_prismarine
fill 143 96 339 143 97 339 minecraft:blue_terracotta
setblock 143 96 343 minecraft:dark_prismarine
setblock 143 96 358 minecraft:dark_prismarine
fill 143 96 359 143 97 359 minecraft:blue_terracotta
fill 143 96 361 143 96 362 minecraft:blue_terracotta
setblock 143 96 363 minecraft:dark_prismarine
fill 144 96 323 147 96 323 minecraft:blue_terracotta
fill 144 96 325 144 96 326 minecraft:blue_terracotta
setblock 144 96 327 minecraft:dark_prismarine
setblock 144 96 332 minecraft:dark_prismarine
fill 144 96 333 144 97 333 minecraft:blue_terracotta
setblock 144 96 337 minecraft:dark_prismarine
fill 144 96 338 144 97 338 minecraft:blue_terracotta
setblock 144 96 341 minecraft:blue_terracotta
setblock 144 96 356 minecraft:blue_terracotta
setblock 144 96 357 minecraft:dark_prismarine
fill 144 96 358 145 97 358 minecraft:blue_terracotta
setblock 144 96 361 minecraft:blue_terracotta
setblock 144 96 362 minecraft:dark_prismarine
fill 144 96 363 144 97 363 minecraft:blue_terracotta
setblock 145 96 325 minecraft:blue_terracotta
setblock 145 96 360 minecraft:blue_terracotta
setblock 145 96 361 minecraft:dark_prismarine
fill 145 96 362 145 97 362 minecraft:blue_terracotta
setblock 146 96 325 minecraft:dark_prismarine
setblock 146 96 360 minecraft:dark_prismarine
fill 146 96 361 146 97 361 minecraft:blue_terracotta
setblock 147 96 324 minecraft:dark_prismarine
fill 147 96 325 147 97 325 minecraft:blue_terracotta
fill 147 96 360 147 97 360 minecraft:blue_terracotta
setblock 148 96 323 minecraft:dark_prismarine
fill 148 96 324 148 97 324 minecraft:blue_terracotta
setblock 148 96 363 minecraft:dark_prismarine
fill 149 96 323 149 97 323 minecraft:blue_terracotta
setblock 149 96 362 minecraft:dark_prismarine
fill 149 96 363 149 97 363 minecraft:blue_terracotta
setblock 150 96 361 minecraft:dark_prismarine
fill 150 96 362 150 97 362 minecraft:blue_terracotta
fill 151 96 361 151 97 361 minecraft:blue_terracotta
setblock 153 96 323 minecraft:dark_prismarine
setblock 153 96 363 minecraft:dark_prismarine
fill 154 96 323 154 97 323 minecraft:blue_terracotta
setblock 154 96 361 minecraft:blue_terracotta
setblock 154 96 362 minecraft:dark_prismarine
fill 154 96 363 157 96 363 minecraft:blue_terracotta
setblock 155 96 361 minecraft:dark_prismarine
fill 155 96 362 158 96 362 minecraft:blue_terracotta
fill 156 96 361 159 96 361 minecraft:blue_terracotta
setblock 158 96 363 minecraft:dark_prismarine
setblock 159 96 362 minecraft:dark_prismarine
fill 159 96 363 159 97 363 minecraft:blue_terracotta
setblock 160 96 361 minecraft:dark_prismarine
fill 160 96 362 160 97 362 minecraft:blue_terracotta
fill 161 96 323 162 96 323 minecraft:blue_terracotta
setblock 161 96 360 minecraft:dark_prismarine
fill 161 96 361 164 96 361 minecraft:blue_terracotta
fill 162 96 360 165 96 360 minecraft:blue_terracotta
setblock 163 96 323 minecraft:dark_prismarine
setblock 163 96 363 minecraft:dark_prismarine
fill 164 96 323 164 97 323 minecraft:blue_terracotta
setblock 164 96 362 minecraft:dark_prismarine
fill 164 96 363 164 97 363 minecraft:blue_terracotta
setblock 165 96 361 minecraft:dark_prismarine
fill 165 96 362 165 97 362 minecraft:blue_terracotta
fill 166 96 323 167 96 323 minecraft:blue_terracotta
setblock 166 96 360 minecraft:dark_prismarine
fill 166 96 361 166 97 361 minecraft:blue_terracotta
fill 167 96 360 167 97 360 minecraft:blue_terracotta
setblock 168 96 323 minecraft:dark_prismarine
setblock 168 96 363 minecraft:dark_prismarine
fill 169 96 323 169 97 323 minecraft:blue_terracotta
setblock 169 96 362 minecraft:dark_prismarine
fill 169 96 363 169 97 363 minecraft:blue_terracotta
setblock 170 96 361 minecraft:dark_prismarine
fill 170 96 362 170 97 362 minecraft:blue_terracotta
setblock 173 96 363 minecraft:dark_prismarine
setblock 178 96 363 minecraft:purple_concrete
fill 180 96 323 180 97 323 minecraft:blue_terracotta
fill 180 96 334 180 96 335 minecraft:blue_terracotta
setblock 180 96 336 minecraft:dark_prismarine
fill 180 96 337 180 97 337 minecraft:blue_terracotta
setblock 180 96 340 minecraft:blue_terracotta
setblock 180 96 341 minecraft:dark_prismarine
fill 180 96 363 180 97 363 minecraft:blue_terracotta
setblock 181 96 330 minecraft:dark_prismarine
fill 181 96 331 181 97 331 minecraft:blue_terracotta
setblock 181 96 335 minecraft:dark_prismarine
fill 181 96 336 181 97 336 minecraft:blue_terracotta
setblock 181 96 340 minecraft:dark_prismarine
fill 181 96 341 181 97 341 minecraft:blue_terracotta
setblock 181 96 344 minecraft:blue_terracotta
fill 181 96 358 181 96 359 minecraft:blue_terracotta
setblock 181 96 360 minecraft:dark_prismarine
fill 181 96 361 181 97 361 minecraft:blue_terracotta
setblock 182 96 324 minecraft:dark_prismarine
fill 182 96 325 182 97 325 minecraft:blue_terracotta
setblock 182 96 329 minecraft:dark_prismarine
fill 182 96 330 182 97 330 minecraft:blue_terracotta
setblock 182 96 334 minecraft:dark_prismarine
fill 182 96 335 182 97 335 minecraft:blue_terracotta
setblock 182 96 339 minecraft:dark_prismarine
fill 182 96 340 182 97 340 minecraft:blue_terracotta
setblock 182 96 343 minecraft:blue_terracotta
setblock 182 96 344 minecraft:dark_prismarine
fill 182 96 345 182 97 345 minecraft:blue_terracotta
setblock 182 96 348 minecraft:blue_terracotta
setblock 182 96 350 minecraft:purple_concrete
fill 182 96 352 182 96 353 minecraft:blue_terracotta
setblock 182 96 354 minecraft:dark_prismarine
fill 182 96 355 182 97 355 minecraft:blue_terracotta
setblock 182 96 358 minecraft:blue_terracotta
setblock 182 96 359 minecraft:dark_prismarine
fill 182 96 360 182 97 360 minecraft:blue_terracotta
setblock 142 97 323 minecraft:dark_prismarine
setblock 142 97 324 minecraft:blue_terracotta
setblock 142 97 328 minecraft:dark_prismarine
setblock 142 97 329 minecraft:blue_terracotta
schedule function dropper:buildpart/75_6 1t
