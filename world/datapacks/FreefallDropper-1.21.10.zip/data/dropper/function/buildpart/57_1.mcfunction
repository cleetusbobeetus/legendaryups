fill 465 39 249 465 46 249 minecraft:black_concrete
fill 423 40 269 423 45 269 minecraft:black_concrete
setblock 426 40 231 minecraft:light[level=12]
setblock 426 40 238 minecraft:light[level=12]
setblock 426 40 245 minecraft:light[level=12]
setblock 426 40 252 minecraft:light[level=12]
setblock 426 40 259 minecraft:light[level=12]
setblock 426 40 266 minecraft:light[level=12]
setblock 433 40 231 minecraft:light[level=12]
setblock 433 40 238 minecraft:light[level=12]
setblock 433 40 245 minecraft:light[level=12]
setblock 433 40 252 minecraft:light[level=12]
setblock 433 40 259 minecraft:light[level=12]
setblock 433 40 266 minecraft:light[level=12]
fill 434 40 241 434 41 241 minecraft:gray_concrete
fill 437 40 270 437 145 270 minecraft:black_concrete
fill 438 40 241 438 41 241 minecraft:gray_concrete
setblock 440 40 231 minecraft:light[level=12]
setblock 440 40 238 minecraft:light[level=12]
setblock 440 40 245 minecraft:light[level=12]
setblock 440 40 252 minecraft:light[level=12]
setblock 440 40 259 minecraft:light[level=12]
setblock 440 40 266 minecraft:light[level=12]
setblock 447 40 231 minecraft:light[level=12]
setblock 447 40 238 minecraft:light[level=12]
setblock 447 40 245 minecraft:light[level=12]
setblock 447 40 252 minecraft:light[level=12]
setblock 447 40 259 minecraft:light[level=12]
setblock 447 40 266 minecraft:light[level=12]
fill 447 40 270 447 80 270 minecraft:black_concrete
setblock 454 40 231 minecraft:light[level=12]
setblock 454 40 238 minecraft:light[level=12]
setblock 454 40 245 minecraft:light[level=12]
setblock 454 40 252 minecraft:light[level=12]
setblock 454 40 259 minecraft:light[level=12]
setblock 454 40 266 minecraft:light[level=12]
setblock 456 40 270 minecraft:white_concrete
fill 459 40 228 459 73 228 minecraft:black_concrete
setblock 461 40 231 minecraft:light[level=12]
setblock 461 40 238 minecraft:light[level=12]
setblock 461 40 245 minecraft:light[level=12]
setblock 461 40 252 minecraft:light[level=12]
setblock 461 40 259 minecraft:light[level=12]
setblock 461 40 266 minecraft:light[level=12]
fill 423 41 263 423 77 263 minecraft:black_concrete
setblock 423 41 264 minecraft:white_concrete
setblock 425 41 228 minecraft:pearlescent_froglight
fill 433 41 238 433 41 240 minecraft:gray_concrete
setblock 434 41 237 minecraft:gray_concrete
fill 435 41 236 437 41 236 minecraft:gray_concrete
fill 435 41 242 437 41 242 minecraft:gray_concrete
setblock 438 41 237 minecraft:gray_concrete
fill 439 41 238 439 41 240 minecraft:gray_concrete
fill 439 41 270 440 41 270 minecraft:white_concrete
setblock 444 41 228 minecraft:blue_concrete
setblock 449 41 270 minecraft:white_concrete
setblock 456 41 270 minecraft:ochre_froglight
setblock 463 41 228 minecraft:sea_lantern
setblock 465 41 231 minecraft:ochre_froglight
setblock 423 42 234 minecraft:sea_lantern
setblock 423 42 235 minecraft:ochre_froglight
setblock 423 42 250 minecraft:white_concrete
fill 423 42 264 423 81 264 minecraft:black_concrete
fill 425 42 228 425 61 228 minecraft:black_concrete
setblock 431 42 228 minecraft:purple_concrete
fill 435 42 239 437 43 239 minecraft:pearlescent_froglight
setblock 436 42 238 minecraft:pearlescent_froglight
fill 436 42 240 436 43 240 minecraft:pearlescent_froglight
fill 439 42 270 440 49 270 minecraft:black_concrete
fill 444 42 228 444 81 228 minecraft:black_concrete
fill 449 42 270 449 44 270 minecraft:black_concrete
fill 456 42 270 456 58 270 minecraft:black_concrete
fill 463 42 228 463 94 228 minecraft:black_concrete
fill 465 42 231 465 71 231 minecraft:black_concrete
setblock 465 42 258 minecraft:white_concrete
fill 423 43 234 423 46 235 minecraft:black_concrete
setblock 423 43 236 minecraft:blue_concrete
setblock 423 43 243 minecraft:white_concrete
fill 423 43 244 423 89 244 minecraft:black_concrete
fill 423 43 250 423 54 250 minecraft:black_concrete
setblock 423 43 252 minecraft:ochre_froglight
fill 431 43 228 431 68 228 minecraft:black_concrete
setblock 459 43 270 minecraft:white_concrete
fill 465 43 258 465 121 258 minecraft:black_concrete
fill 423 44 236 423 61 236 minecraft:black_concrete
fill 423 44 243 423 53 243 minecraft:black_concrete
fill 423 44 252 423 90 252 minecraft:black_concrete
fill 436 44 239 436 46 239 minecraft:pearlescent_froglight
setblock 440 44 228 minecraft:sea_lantern
fill 451 44 241 451 65 241 minecraft:gray_concrete
fill 453 44 258 453 65 258 minecraft:gray_concrete
fill 459 44 270 459 52 270 minecraft:black_concrete
setblock 465 44 266 minecraft:purple_terracotta
setblock 423 45 242 minecraft:magenta_terracotta
setblock 426 45 231 minecraft:light[level=15]
setblock 426 45 239 minecraft:light[level=15]
setblock 426 45 247 minecraft:light[level=15]
setblock 426 45 255 minecraft:light[level=15]
setblock 426 45 263 minecraft:light[level=15]
setblock 434 45 231 minecraft:light[level=15]
setblock 434 45 239 minecraft:light[level=15]
setblock 434 45 247 minecraft:light[level=15]
setblock 434 45 255 minecraft:light[level=15]
setblock 434 45 263 minecraft:light[level=15]
fill 440 45 228 440 128 228 minecraft:black_concrete
setblock 442 45 231 minecraft:light[level=15]
setblock 442 45 239 minecraft:light[level=15]
setblock 442 45 247 minecraft:light[level=15]
setblock 442 45 255 minecraft:light[level=15]
setblock 442 45 263 minecraft:light[level=15]
setblock 449 45 270 minecraft:pearlescent_froglight
setblock 450 45 231 minecraft:light[level=15]
setblock 450 45 239 minecraft:light[level=15]
setblock 450 45 247 minecraft:light[level=15]
setblock 450 45 255 minecraft:light[level=15]
setblock 450 45 263 minecraft:light[level=15]
setblock 458 45 231 minecraft:light[level=15]
setblock 458 45 239 minecraft:light[level=15]
setblock 458 45 247 minecraft:light[level=15]
setblock 458 45 255 minecraft:light[level=15]
setblock 458 45 263 minecraft:light[level=15]
setblock 465 45 236 minecraft:sea_lantern
fill 465 45 266 465 51 266 minecraft:black_concrete
fill 423 46 242 423 117 242 minecraft:black_concrete
setblock 423 46 251 minecraft:ochre_froglight
setblock 423 46 262 minecraft:sea_lantern
setblock 423 46 269 minecraft:sea_lantern
setblock 426 46 231 minecraft:light[level=12]
setblock 426 46 238 minecraft:light[level=12]
setblock 426 46 245 minecraft:light[level=12]
setblock 426 46 252 minecraft:light[level=12]
setblock 426 46 259 minecraft:light[level=12]
setblock 426 46 266 minecraft:light[level=12]
setblock 433 46 231 minecraft:light[level=12]
setblock 433 46 238 minecraft:light[level=12]
setblock 433 46 245 minecraft:light[level=12]
setblock 433 46 252 minecraft:light[level=12]
setblock 433 46 259 minecraft:light[level=12]
setblock 433 46 266 minecraft:light[level=12]
setblock 440 46 231 minecraft:light[level=12]
setblock 440 46 238 minecraft:light[level=12]
setblock 440 46 245 minecraft:light[level=12]
setblock 440 46 252 minecraft:light[level=12]
setblock 440 46 259 minecraft:light[level=12]
setblock 440 46 266 minecraft:light[level=12]
setblock 445 46 228 minecraft:pearlescent_froglight
setblock 447 46 228 minecraft:sea_lantern
setblock 447 46 231 minecraft:light[level=12]
setblock 447 46 238 minecraft:light[level=12]
setblock 447 46 245 minecraft:light[level=12]
setblock 447 46 252 minecraft:light[level=12]
setblock 447 46 259 minecraft:light[level=12]
setblock 447 46 266 minecraft:light[level=12]
fill 449 46 270 449 105 270 minecraft:black_concrete
setblock 454 46 231 minecraft:light[level=12]
setblock 454 46 238 minecraft:light[level=12]
setblock 454 46 245 minecraft:light[level=12]
setblock 454 46 252 minecraft:light[level=12]
setblock 454 46 259 minecraft:light[level=12]
setblock 454 46 266 minecraft:light[level=12]
setblock 461 46 231 minecraft:light[level=12]
setblock 461 46 238 minecraft:light[level=12]
setblock 461 46 245 minecraft:light[level=12]
setblock 461 46 252 minecraft:light[level=12]
setblock 461 46 259 minecraft:light[level=12]
setblock 461 46 266 minecraft:light[level=12]
fill 465 46 236 465 129 236 minecraft:black_concrete
setblock 465 46 254 minecraft:white_concrete
setblock 423 47 230 minecraft:white_concrete
fill 423 47 234 423 107 234 minecraft:black_concrete
setblock 423 47 235 minecraft:purple_terracotta
setblock 423 47 251 minecraft:black_concrete
fill 423 47 262 423 48 262 minecraft:black_concrete
setblock 423 47 266 minecraft:ochre_froglight
fill 423 47 269 423 99 269 minecraft:black_concrete
fill 445 47 228 445 83 228 minecraft:black_concrete
fill 447 47 228 447 54 228 minecraft:black_concrete
setblock 465 47 249 minecraft:pearlescent_froglight
fill 465 47 254 465 129 254 minecraft:black_concrete
fill 423 48 230 423 67 230 minecraft:black_concrete
fill 423 48 235 423 52 235 minecraft:black_concrete
setblock 423 48 251 minecraft:sea_lantern
fill 423 48 266 423 63 266 minecraft:black_concrete
setblock 423 48 268 minecraft:pearlescent_froglight
setblock 429 48 270 minecraft:pearlescent_froglight
setblock 431 48 270 minecraft:white_concrete
setblock 441 48 228 minecraft:blue_concrete
fill 452 48 258 452 65 258 minecraft:gray_concrete
fill 465 48 249 465 74 249 minecraft:black_concrete
setblock 465 48 263 minecraft:ochre_froglight
fill 423 49 251 423 126 251 minecraft:black_concrete
setblock 423 49 262 minecraft:purple_terracotta
fill 423 49 268 423 50 268 minecraft:black_concrete
fill 429 49 270 429 108 270 minecraft:black_concrete
fill 431 49 270 431 123 270 minecraft:black_concrete
setblock 439 49 228 minecraft:white_concrete
fill 441 49 228 441 96 228 minecraft:black_concrete
fill 465 49 263 465 55 263 minecraft:black_concrete
fill 423 50 262 423 84 262 minecraft:black_concrete
fill 439 50 228 439 68 228 minecraft:black_concrete
setblock 439 50 270 minecraft:ochre_froglight
fill 440 50 270 440 79 270 minecraft:black_concrete
setblock 460 50 228 minecraft:magenta_terracotta
setblock 465 50 232 minecraft:sea_lantern
setblock 423 51 265 minecraft:sea_lantern
setblock 423 51 268 minecraft:sea_lantern
setblock 426 51 270 minecraft:blue_concrete
setblock 430 51 270 minecraft:ochre_froglight
fill 439 51 270 439 63 270 minecraft:black_concrete
fill 454 51 251 454 52 252 minecraft:gray_concrete
fill 460 51 228 460 72 228 minecraft:black_concrete
fill 461 51 245 463 52 245 minecraft:gray_concrete
fill 462 51 246 463 52 246 minecraft:gray_concrete
fill 465 51 232 465 55 232 minecraft:black_concrete
setblock 465 51 238 minecraft:pearlescent_froglight
setblock 423 52 258 minecraft:white_concrete
fill 423 52 265 423 57 265 minecraft:black_concrete
fill 423 52 268 423 78 268 minecraft:black_concrete
setblock 426 52 231 minecraft:light[level=15]
setblock 426 52 238 minecraft:light[level=12]
setblock 426 52 239 minecraft:light[level=15]
setblock 426 52 245 minecraft:light[level=12]
setblock 426 52 247 minecraft:light[level=15]
setblock 426 52 252 minecraft:light[level=12]
setblock 426 52 255 minecraft:light[level=15]
setblock 426 52 259 minecraft:light[level=12]
setblock 426 52 263 minecraft:light[level=15]
setblock 426 52 266 minecraft:light[level=12]
fill 426 52 270 426 56 270 minecraft:black_concrete
setblock 430 52 270 minecraft:black_concrete
setblock 433 52 231 minecraft:light[level=12]
setblock 433 52 238 minecraft:light[level=12]
setblock 433 52 245 minecraft:light[level=12]
setblock 433 52 252 minecraft:light[level=12]
setblock 433 52 259 minecraft:light[level=12]
setblock 433 52 266 minecraft:light[level=12]
setblock 434 52 231 minecraft:light[level=15]
setblock 434 52 239 minecraft:light[level=15]
setblock 434 52 247 minecraft:light[level=15]
setblock 434 52 255 minecraft:light[level=15]
setblock 434 52 263 minecraft:light[level=15]
fill 438 52 265 438 53 265 minecraft:gray_concrete
setblock 440 52 231 minecraft:light[level=12]
setblock 440 52 238 minecraft:light[level=12]
setblock 440 52 245 minecraft:light[level=12]
setblock 440 52 252 minecraft:light[level=12]
setblock 440 52 259 minecraft:light[level=12]
setblock 440 52 266 minecraft:light[level=12]
setblock 442 52 231 minecraft:light[level=15]
setblock 442 52 239 minecraft:light[level=15]
setblock 442 52 247 minecraft:light[level=15]
setblock 442 52 255 minecraft:light[level=15]
setblock 442 52 263 minecraft:light[level=15]
setblock 447 52 231 minecraft:light[level=12]
setblock 447 52 238 minecraft:light[level=12]
setblock 447 52 245 minecraft:light[level=12]
setblock 447 52 252 minecraft:light[level=12]
setblock 447 52 259 minecraft:light[level=12]
setblock 447 52 266 minecraft:light[level=12]
setblock 450 52 231 minecraft:light[level=15]
setblock 450 52 239 minecraft:light[level=15]
setblock 450 52 247 minecraft:light[level=15]
setblock 450 52 255 minecraft:light[level=15]
setblock 450 52 263 minecraft:light[level=15]
setblock 454 52 231 minecraft:light[level=12]
setblock 454 52 238 minecraft:light[level=12]
setblock 454 52 245 minecraft:light[level=12]
setblock 454 52 259 minecraft:light[level=12]
setblock 454 52 266 minecraft:light[level=12]
setblock 458 52 231 minecraft:light[level=15]
setblock 458 52 239 minecraft:light[level=15]
setblock 458 52 247 minecraft:light[level=15]
setblock 458 52 255 minecraft:light[level=15]
setblock 458 52 263 minecraft:light[level=15]
setblock 461 52 231 minecraft:light[level=12]
setblock 461 52 238 minecraft:light[level=12]
setblock 461 52 252 minecraft:light[level=12]
setblock 461 52 259 minecraft:light[level=12]
setblock 461 52 266 minecraft:light[level=12]
fill 465 52 238 465 107 238 minecraft:black_concrete
setblock 465 52 266 minecraft:white_concrete
setblock 423 53 235 minecraft:pearlescent_froglight
fill 423 53 258 423 123 258 minecraft:black_concrete
fill 429 53 243 430 54 244 minecraft:gray_concrete
setblock 430 53 270 minecraft:blue_concrete
fill 432 53 228 432 61 228 minecraft:black_concrete
fill 432 53 248 432 54 248 minecraft:gray_concrete
setblock 433 53 228 minecraft:pearlescent_froglight
fill 434 53 228 434 77 228 minecraft:black_concrete
setblock 452 53 270 minecraft:blue_concrete
setblock 459 53 270 minecraft:sea_lantern
setblock 461 53 228 minecraft:pearlescent_froglight
setblock 465 53 234 minecraft:white_concrete
setblock 465 53 240 minecraft:sea_lantern
setblock 465 53 261 minecraft:pearlescent_froglight
setblock 465 53 266 minecraft:purple_concrete
fill 423 54 235 423 86 235 minecraft:black_concrete
setblock 423 54 243 minecraft:pearlescent_froglight
setblock 423 54 259 minecraft:sea_lantern
fill 430 54 270 430 66 270 minecraft:black_concrete
fill 433 54 228 433 153 228 minecraft:black_concrete
setblock 436 54 270 minecraft:purple_terracotta
fill 452 54 270 452 80 270 minecraft:black_concrete
fill 459 54 270 459 169 270 minecraft:black_concrete
fill 461 54 228 461 65 228 minecraft:black_concrete
fill 465 54 234 465 58 234 minecraft:black_concrete
fill 465 54 240 465 72 240 minecraft:black_concrete
fill 465 54 261 465 61 261 minecraft:black_concrete
fill 465 54 266 465 92 266 minecraft:black_concrete
setblock 423 55 238 minecraft:blue_concrete
fill 423 55 243 423 104 243 minecraft:black_concrete
setblock 423 55 250 minecraft:purple_terracotta
fill 423 55 259 423 107 259 minecraft:black_concrete
fill 436 55 270 436 172 270 minecraft:black_concrete
setblock 437 55 228 minecraft:ochre_froglight
setblock 447 55 228 minecraft:sea_lantern
setblock 457 55 228 minecraft:pearlescent_froglight
fill 423 56 238 423 107 238 minecraft:black_concrete
fill 423 56 250 423 95 250 minecraft:black_concrete
fill 437 56 228 437 171 228 minecraft:black_concrete
fill 447 56 228 447 78 228 minecraft:black_concrete
setblock 452 56 228 minecraft:ochre_froglight
fill 457 56 228 457 57 228 minecraft:black_concrete
setblock 462 56 270 minecraft:white_concrete
setblock 465 56 232 minecraft:white_concrete
setblock 465 56 263 minecraft:white_concrete
setblock 426 57 270 minecraft:white_concrete
setblock 451 57 270 minecraft:white_concrete
fill 452 57 228 452 71 228 minecraft:black_concrete
fill 462 57 270 462 92 270 minecraft:black_concrete
fill 465 57 232 465 92 232 minecraft:black_concrete
fill 465 57 263 465 77 263 minecraft:black_concrete
setblock 423 58 265 minecraft:white_concrete
setblock 426 58 231 minecraft:light[level=12]
setblock 426 58 238 minecraft:light[level=12]
setblock 426 58 245 minecraft:light[level=12]
setblock 426 58 252 minecraft:light[level=12]
setblock 426 58 259 minecraft:light[level=12]
setblock 426 58 266 minecraft:light[level=12]
setblock 426 58 270 minecraft:blue_concrete
setblock 428 58 228 minecraft:purple_concrete
setblock 433 58 231 minecraft:light[level=12]
setblock 433 58 238 minecraft:light[level=12]
setblock 433 58 245 minecraft:light[level=12]
setblock 433 58 252 minecraft:light[level=12]
setblock 433 58 259 minecraft:light[level=12]
setblock 433 58 266 minecraft:light[level=12]
setblock 440 58 231 minecraft:light[level=12]
setblock 440 58 238 minecraft:light[level=12]
setblock 440 58 245 minecraft:light[level=12]
setblock 440 58 252 minecraft:light[level=12]
setblock 440 58 259 minecraft:light[level=12]
setblock 440 58 266 minecraft:light[level=12]
setblock 447 58 231 minecraft:light[level=12]
setblock 447 58 238 minecraft:light[level=12]
setblock 447 58 245 minecraft:light[level=12]
setblock 447 58 252 minecraft:light[level=12]
setblock 447 58 259 minecraft:light[level=12]
setblock 447 58 266 minecraft:light[level=12]
setblock 448 58 270 minecraft:pearlescent_froglight
fill 451 58 242 452 65 242 minecraft:gray_concrete
fill 451 58 270 451 62 270 minecraft:black_concrete
setblock 454 58 231 minecraft:light[level=12]
setblock 454 58 238 minecraft:light[level=12]
setblock 454 58 245 minecraft:light[level=12]
setblock 454 58 252 minecraft:light[level=12]
setblock 454 58 259 minecraft:light[level=12]
setblock 454 58 266 minecraft:light[level=12]
setblock 457 58 228 minecraft:white_concrete
setblock 461 58 231 minecraft:light[level=12]
setblock 461 58 238 minecraft:light[level=12]
setblock 461 58 245 minecraft:light[level=12]
setblock 461 58 252 minecraft:light[level=12]
setblock 461 58 259 minecraft:light[level=12]
setblock 461 58 266 minecraft:light[level=12]
setblock 465 58 245 minecraft:white_concrete
fill 423 59 265 423 71 265 minecraft:black_concrete
setblock 426 59 231 minecraft:light[level=15]
setblock 426 59 239 minecraft:light[level=15]
setblock 426 59 247 minecraft:light[level=15]
setblock 426 59 255 minecraft:light[level=15]
setblock 426 59 263 minecraft:light[level=15]
fill 426 59 270 426 87 270 minecraft:black_concrete
fill 428 59 228 428 143 228 minecraft:black_concrete
setblock 433 59 270 minecraft:sea_lantern
setblock 434 59 231 minecraft:light[level=15]
setblock 434 59 239 minecraft:light[level=15]
setblock 434 59 247 minecraft:light[level=15]
setblock 434 59 255 minecraft:light[level=15]
setblock 434 59 263 minecraft:light[level=15]
fill 438 59 250 438 65 250 minecraft:gray_concrete
setblock 442 59 231 minecraft:light[level=15]
setblock 442 59 239 minecraft:light[level=15]
setblock 442 59 247 minecraft:light[level=15]
setblock 442 59 255 minecraft:light[level=15]
setblock 442 59 263 minecraft:light[level=15]
fill 448 59 270 448 77 270 minecraft:black_concrete
setblock 450 59 231 minecraft:light[level=15]
setblock 450 59 239 minecraft:light[level=15]
setblock 450 59 247 minecraft:light[level=15]
setblock 450 59 255 minecraft:light[level=15]
setblock 450 59 263 minecraft:light[level=15]
setblock 456 59 270 minecraft:pearlescent_froglight
fill 457 59 228 457 163 228 minecraft:black_concrete
setblock 458 59 231 minecraft:light[level=15]
setblock 458 59 239 minecraft:light[level=15]
setblock 458 59 247 minecraft:light[level=15]
setblock 458 59 255 minecraft:light[level=15]
setblock 458 59 263 minecraft:light[level=15]
setblock 465 59 234 minecraft:white_concrete
fill 465 59 245 465 78 245 minecraft:black_concrete
setblock 423 60 256 minecraft:pearlescent_froglight
fill 433 60 270 433 66 270 minecraft:black_concrete
fill 444 60 249 444 61 249 minecraft:light_gray_concrete
fill 444 60 251 444 61 251 minecraft:light_gray_concrete
fill 446 60 247 446 61 247 minecraft:light_gray_concrete
fill 446 60 253 446 61 253 minecraft:light_gray_concrete
fill 448 60 247 448 61 247 minecraft:light_gray_concrete
fill 448 60 253 448 61 253 minecraft:light_gray_concrete
fill 450 60 249 450 61 249 minecraft:light_gray_concrete
fill 450 60 251 450 61 251 minecraft:light_gray_concrete
setblock 455 60 228 minecraft:white_concrete
fill 456 60 270 456 67 270 minecraft:black_concrete
setblock 465 60 234 minecraft:black_concrete
fill 423 61 256 423 127 256 minecraft:black_concrete
fill 438 61 251 438 65 251 minecraft:gray_concrete
setblock 443 61 250 minecraft:white_concrete
setblock 444 61 248 minecraft:light_gray_concrete
setblock 444 61 252 minecraft:light_gray_concrete
setblock 445 61 247 minecraft:light_gray_concrete
setblock 445 61 253 minecraft:light_gray_concrete
setblock 447 61 246 minecraft:white_concrete
setblock 447 61 254 minecraft:white_concrete
setblock 449 61 247 minecraft:light_gray_concrete
setblock 449 61 253 minecraft:light_gray_concrete
setblock 450 61 248 minecraft:light_gray_concrete
setblock 450 61 252 minecraft:light_gray_concrete
setblock 451 61 250 minecraft:white_concrete
fill 455 61 228 455 98 228 minecraft:black_concrete
setblock 465 61 234 minecraft:ochre_froglight
setblock 423 62 236 minecraft:sea_lantern
fill 424 62 229 424 62 234 minecraft:light_gray_stained_glass
setblock 424 62 235 minecraft:sea_lantern
fill 424 62 236 424 62 247 minecraft:light_gray_stained_glass
setblock 424 62 248 minecraft:sea_lantern
fill 424 62 249 424 62 260 minecraft:light_gray_stained_glass
setblock 424 62 261 minecraft:sea_lantern
fill 424 62 262 424 62 269 minecraft:light_gray_stained_glass
setblock 425 62 228 minecraft:pearlescent_froglight
setblock 425 62 229 minecraft:sea_lantern
fill 425 62 230 425 62 241 minecraft:light_gray_stained_glass
setblock 425 62 242 minecraft:sea_lantern
fill 425 62 243 425 62 254 minecraft:light_gray_stained_glass
setblock 425 62 255 minecraft:sea_lantern
fill 425 62 256 425 62 267 minecraft:light_gray_stained_glass
setblock 425 62 268 minecraft:sea_lantern
fill 425 62 269 426 62 269 minecraft:light_gray_stained_glass
fill 426 62 229 426 62 235 minecraft:light_gray_stained_glass
setblock 426 62 236 minecraft:sea_lantern
fill 426 62 237 426 62 248 minecraft:light_gray_stained_glass
setblock 426 62 249 minecraft:sea_lantern
fill 426 62 250 426 62 261 minecraft:light_gray_stained_glass
setblock 426 62 262 minecraft:sea_lantern
fill 426 62 263 427 62 268 minecraft:light_gray_stained_glass
fill 427 62 229 437 62 229 minecraft:light_gray_stained_glass
setblock 427 62 230 minecraft:sea_lantern
fill 427 62 231 427 62 242 minecraft:light_gray_stained_glass
setblock 427 62 243 minecraft:sea_lantern
fill 427 62 244 427 62 255 minecraft:light_gray_stained_glass
setblock 427 62 256 minecraft:sea_lantern
fill 427 62 257 428 62 262 minecraft:light_gray_stained_glass
setblock 427 62 269 minecraft:sea_lantern
fill 428 62 230 428 62 236 minecraft:light_gray_stained_glass
setblock 428 62 237 minecraft:sea_lantern
fill 428 62 238 428 62 249 minecraft:light_gray_stained_glass
setblock 428 62 250 minecraft:sea_lantern
fill 428 62 251 429 62 256 minecraft:light_gray_stained_glass
setblock 428 62 263 minecraft:sea_lantern
fill 428 62 264 429 62 269 minecraft:light_gray_stained_glass
fill 429 62 230 439 62 230 minecraft:light_gray_stained_glass
setblock 429 62 231 minecraft:sea_lantern
fill 429 62 232 429 62 243 minecraft:light_gray_stained_glass
setblock 429 62 244 minecraft:sea_lantern
fill 429 62 245 430 62 250 minecraft:light_gray_stained_glass
setblock 429 62 257 minecraft:sea_lantern
fill 429 62 258 430 62 263 minecraft:light_gray_stained_glass
fill 430 62 231 430 62 237 minecraft:light_gray_stained_glass
setblock 430 62 238 minecraft:sea_lantern
fill 430 62 239 431 62 244 minecraft:light_gray_stained_glass
setblock 430 62 251 minecraft:sea_lantern
fill 430 62 252 431 62 257 minecraft:light_gray_stained_glass
setblock 430 62 264 minecraft:sea_lantern
fill 430 62 265 431 62 269 minecraft:light_gray_stained_glass
fill 431 62 231 441 62 231 minecraft:light_gray_stained_glass
setblock 431 62 232 minecraft:sea_lantern
fill 431 62 233 432 62 238 minecraft:light_gray_stained_glass
setblock 431 62 245 minecraft:sea_lantern
fill 431 62 246 432 62 251 minecraft:light_gray_stained_glass
setblock 431 62 258 minecraft:sea_lantern
fill 431 62 259 432 62 264 minecraft:light_gray_stained_glass
setblock 432 62 228 minecraft:sea_lantern
fill 432 62 232 443 62 232 minecraft:light_gray_stained_glass
setblock 432 62 239 minecraft:sea_lantern
fill 432 62 240 433 62 245 minecraft:light_gray_stained_glass
setblock 432 62 252 minecraft:sea_lantern
fill 432 62 253 433 62 258 minecraft:light_gray_stained_glass
setblock 432 62 265 minecraft:sea_lantern
fill 432 62 266 433 62 269 minecraft:light_gray_stained_glass
setblock 433 62 233 minecraft:sea_lantern
fill 433 62 234 434 62 239 minecraft:light_gray_stained_glass
setblock 433 62 246 minecraft:sea_lantern
fill 433 62 247 434 62 252 minecraft:light_gray_stained_glass
setblock 433 62 259 minecraft:sea_lantern
fill 433 62 260 434 62 265 minecraft:light_gray_stained_glass
fill 434 62 233 445 62 233 minecraft:light_gray_stained_glass
setblock 434 62 240 minecraft:sea_lantern
fill 434 62 241 435 62 246 minecraft:light_gray_stained_glass
setblock 434 62 253 minecraft:sea_lantern
fill 434 62 254 435 62 259 minecraft:light_gray_stained_glass
setblock 434 62 266 minecraft:sea_lantern
fill 434 62 267 435 62 269 minecraft:light_gray_stained_glass
setblock 435 62 234 minecraft:sea_lantern
fill 435 62 235 436 62 240 minecraft:light_gray_stained_glass
setblock 435 62 247 minecraft:sea_lantern
fill 435 62 248 436 62 253 minecraft:light_gray_stained_glass
setblock 435 62 260 minecraft:sea_lantern
fill 435 62 261 436 62 266 minecraft:light_gray_stained_glass
fill 436 62 234 447 62 234 minecraft:light_gray_stained_glass
setblock 436 62 241 minecraft:sea_lantern
fill 436 62 242 437 62 247 minecraft:light_gray_stained_glass
setblock 436 62 254 minecraft:sea_lantern
fill 436 62 255 437 62 260 minecraft:light_gray_stained_glass
setblock 436 62 267 minecraft:sea_lantern
fill 436 62 268 437 62 269 minecraft:light_gray_stained_glass
setblock 437 62 235 minecraft:sea_lantern
fill 437 62 236 438 62 241 minecraft:light_gray_stained_glass
setblock 437 62 248 minecraft:sea_lantern
fill 437 62 249 438 62 249 minecraft:light_gray_stained_glass
fill 437 62 252 441 62 254 minecraft:light_gray_stained_glass
setblock 437 62 261 minecraft:sea_lantern
fill 437 62 262 438 62 267 minecraft:light_gray_stained_glass
setblock 438 62 229 minecraft:sea_lantern
fill 438 62 235 449 62 235 minecraft:light_gray_stained_glass
setblock 438 62 242 minecraft:sea_lantern
fill 438 62 243 439 62 248 minecraft:light_gray_stained_glass
setblock 438 62 255 minecraft:sea_lantern
fill 438 62 256 439 62 261 minecraft:light_gray_stained_glass
setblock 438 62 268 minecraft:sea_lantern
fill 438 62 269 439 62 269 minecraft:light_gray_stained_glass
fill 439 62 229 450 62 229 minecraft:light_gray_stained_glass
setblock 439 62 236 minecraft:sea_lantern
fill 439 62 237 440 62 242 minecraft:light_gray_stained_glass
setblock 439 62 249 minecraft:sea_lantern
fill 439 62 250 440 62 251 minecraft:light_gray_stained_glass
fill 439 62 255 443 62 255 minecraft:light_gray_stained_glass
setblock 439 62 262 minecraft:sea_lantern
fill 439 62 263 440 62 268 minecraft:light_gray_stained_glass
setblock 440 62 230 minecraft:sea_lantern
fill 440 62 236 451 62 236 minecraft:light_gray_stained_glass
setblock 440 62 243 minecraft:sea_lantern
fill 440 62 244 440 62 249 minecraft:light_gray_stained_glass
setblock 440 62 256 minecraft:sea_lantern
fill 440 62 257 441 62 262 minecraft:light_gray_stained_glass
setblock 440 62 269 minecraft:sea_lantern
fill 441 62 230 452 62 230 minecraft:light_gray_stained_glass
setblock 441 62 237 minecraft:sea_lantern
fill 441 62 238 441 62 248 minecraft:light_gray_stained_glass
fill 441 62 249 441 63 251 minecraft:light_gray_concrete
fill 441 62 256 445 62 256 minecraft:light_gray_stained_glass
setblock 441 62 263 minecraft:sea_lantern
fill 441 62 264 442 62 269 minecraft:light_gray_stained_glass
setblock 442 62 231 minecraft:sea_lantern
fill 442 62 237 442 62 243 minecraft:light_gray_stained_glass
setblock 442 62 244 minecraft:sea_lantern
fill 442 62 245 442 62 246 minecraft:light_gray_stained_glass
fill 442 62 247 442 63 247 minecraft:white_concrete
fill 442 62 248 442 62 252 minecraft:sea_lantern
fill 442 62 253 442 63 253 minecraft:white_concrete
setblock 442 62 254 minecraft:light_gray_stained_glass
setblock 442 62 257 minecraft:sea_lantern
fill 442 62 258 443 62 263 minecraft:light_gray_stained_glass
fill 443 62 231 454 62 231 minecraft:light_gray_stained_glass
fill 443 62 237 453 62 237 minecraft:light_gray_stained_glass
setblock 443 62 238 minecraft:sea_lantern
fill 443 62 239 443 62 245 minecraft:light_gray_stained_glass
fill 443 62 246 443 62 248 minecraft:sea_lantern
fill 443 62 249 443 62 251 minecraft:redstone_block
fill 443 62 252 443 62 254 minecraft:sea_lantern
fill 443 62 257 454 62 257 minecraft:light_gray_stained_glass
setblock 443 62 264 minecraft:sea_lantern
fill 443 62 265 444 62 269 minecraft:light_gray_stained_glass
setblock 444 62 232 minecraft:sea_lantern
fill 444 62 238 444 62 244 minecraft:light_gray_stained_glass
fill 444 62 245 444 63 245 minecraft:white_concrete
fill 444 62 246 445 62 246 minecraft:sea_lantern
fill 444 62 247 444 62 249 minecraft:redstone_block
fill 444 62 251 444 62 253 minecraft:redstone_block
fill 444 62 254 445 62 254 minecraft:sea_lantern
fill 444 62 255 444 63 255 minecraft:white_concrete
setblock 444 62 258 minecraft:sea_lantern
fill 444 62 259 445 62 264 minecraft:light_gray_stained_glass
fill 445 62 232 456 62 232 minecraft:light_gray_stained_glass
fill 445 62 238 455 62 238 minecraft:light_gray_stained_glass
setblock 445 62 239 minecraft:sea_lantern
fill 445 62 240 445 62 244 minecraft:light_gray_stained_glass
fill 445 62 245 449 62 245 minecraft:sea_lantern
fill 445 62 247 446 62 247 minecraft:redstone_block
fill 445 62 253 446 62 253 minecraft:redstone_block
fill 445 62 255 449 62 255 minecraft:sea_lantern
fill 445 62 258 451 62 258 minecraft:light_gray_stained_glass
setblock 445 62 265 minecraft:sea_lantern
fill 445 62 266 446 62 269 minecraft:light_gray_stained_glass
setblock 446 62 233 minecraft:sea_lantern
fill 446 62 239 446 62 243 minecraft:light_gray_stained_glass
fill 446 62 244 448 63 244 minecraft:light_gray_concrete
fill 446 62 246 448 62 246 minecraft:redstone_block
fill 446 62 254 448 62 254 minecraft:redstone_block
fill 446 62 256 448 63 256 minecraft:light_gray_concrete
setblock 446 62 259 minecraft:sea_lantern
fill 446 62 260 447 62 265 minecraft:light_gray_stained_glass
fill 447 62 233 458 62 233 minecraft:light_gray_stained_glass
fill 447 62 239 457 62 239 minecraft:light_gray_stained_glass
setblock 447 62 240 minecraft:sea_lantern
fill 447 62 241 448 62 243 minecraft:light_gray_stained_glass
fill 447 62 259 458 62 259 minecraft:light_gray_stained_glass
setblock 447 62 266 minecraft:sea_lantern
fill 447 62 267 448 62 269 minecraft:light_gray_stained_glass
setblock 448 62 234 minecraft:sea_lantern
fill 448 62 240 459 62 240 minecraft:light_gray_stained_glass
fill 448 62 247 450 62 247 minecraft:redstone_block
fill 448 62 253 450 62 253 minecraft:redstone_block
setblock 448 62 260 minecraft:sea_lantern
fill 448 62 261 449 62 266 minecraft:light_gray_stained_glass
fill 449 62 234 460 62 234 minecraft:light_gray_stained_glass
setblock 449 62 241 minecraft:sea_lantern
fill 449 62 242 450 62 244 minecraft:light_gray_stained_glass
fill 449 62 246 451 62 246 minecraft:sea_lantern
fill 449 62 254 451 62 254 minecraft:sea_lantern
fill 449 62 256 452 62 256 minecraft:light_gray_stained_glass
fill 449 62 260 460 62 260 minecraft:light_gray_stained_glass
setblock 449 62 267 minecraft:sea_lantern
fill 449 62 268 450 62 269 minecraft:light_gray_stained_glass
setblock 450 62 235 minecraft:sea_lantern
setblock 450 62 241 minecraft:light_gray_stained_glass
fill 450 62 245 450 63 245 minecraft:white_concrete
fill 450 62 248 450 62 249 minecraft:redstone_block
fill 450 62 251 450 62 252 minecraft:redstone_block
fill 450 62 255 450 63 255 minecraft:white_concrete
setblock 450 62 261 minecraft:sea_lantern
fill 450 62 262 451 62 267 minecraft:light_gray_stained_glass
setblock 451 62 229 minecraft:sea_lantern
fill 451 62 235 462 62 235 minecraft:light_gray_stained_glass
fill 451 62 243 452 62 245 minecraft:light_gray_stained_glass
fill 451 62 247 451 62 248 minecraft:sea_lantern
fill 451 62 249 451 62 251 minecraft:redstone_block
fill 451 62 252 451 62 253 minecraft:sea_lantern
setblock 451 62 255 minecraft:sea_lantern
fill 451 62 261 462 62 261 minecraft:light_gray_stained_glass
setblock 451 62 268 minecraft:sea_lantern
fill 451 62 269 452 62 269 minecraft:light_gray_stained_glass
fill 452 62 229 463 62 229 minecraft:light_gray_stained_glass
setblock 452 62 236 minecraft:sea_lantern
fill 452 62 246 458 62 246 minecraft:light_gray_stained_glass
fill 452 62 247 452 63 247 minecraft:white_concrete
fill 452 62 248 452 62 252 minecraft:sea_lantern
fill 452 62 253 452 63 253 minecraft:white_concrete
fill 452 62 254 461 62 255 minecraft:light_gray_stained_glass
setblock 452 62 262 minecraft:sea_lantern
fill 452 62 263 453 62 268 minecraft:light_gray_stained_glass
setblock 453 62 230 minecraft:sea_lantern
fill 453 62 236 464 62 236 minecraft:light_gray_stained_glass
fill 453 62 241 461 62 242 minecraft:light_gray_stained_glass
setblock 453 62 243 minecraft:sea_lantern
fill 453 62 244 454 62 245 minecraft:light_gray_stained_glass
fill 453 62 247 460 62 248 minecraft:light_gray_stained_glass
fill 453 62 249 453 63 251 minecraft:light_gray_concrete
fill 453 62 252 457 62 253 minecraft:light_gray_stained_glass
setblock 453 62 256 minecraft:sea_lantern
fill 453 62 262 464 62 262 minecraft:light_gray_stained_glass
setblock 453 62 269 minecraft:sea_lantern
fill 454 62 230 464 62 230 minecraft:light_gray_stained_glass
setblock 454 62 237 minecraft:sea_lantern
fill 454 62 243 464 62 243 minecraft:light_gray_stained_glass
fill 454 62 249 464 62 249 minecraft:light_gray_stained_glass
setblock 454 62 250 minecraft:sea_lantern
fill 454 62 251 455 62 251 minecraft:light_gray_stained_glass
fill 454 62 256 464 62 256 minecraft:light_gray_stained_glass
fill 454 62 258 456 62 258 minecraft:light_gray_stained_glass
setblock 454 62 263 minecraft:sea_lantern
fill 454 62 264 455 62 269 minecraft:light_gray_stained_glass
setblock 455 62 231 minecraft:sea_lantern
fill 455 62 237 464 62 237 minecraft:light_gray_stained_glass
setblock 455 62 244 minecraft:sea_lantern
fill 455 62 245 456 62 245 minecraft:light_gray_stained_glass
fill 455 62 250 464 62 250 minecraft:light_gray_stained_glass
setblock 455 62 257 minecraft:sea_lantern
fill 455 62 263 464 62 263 minecraft:light_gray_stained_glass
fill 456 62 231 464 62 231 minecraft:light_gray_stained_glass
setblock 456 62 238 minecraft:sea_lantern
fill 456 62 244 464 62 244 minecraft:light_gray_stained_glass
setblock 456 62 251 minecraft:sea_lantern
fill 456 62 257 464 62 257 minecraft:light_gray_stained_glass
setblock 456 62 264 minecraft:sea_lantern
fill 456 62 265 457 62 269 minecraft:light_gray_stained_glass
setblock 457 62 232 minecraft:sea_lantern
fill 457 62 238 464 62 238 minecraft:light_gray_stained_glass
setblock 457 62 245 minecraft:sea_lantern
fill 457 62 251 464 62 251 minecraft:light_gray_stained_glass
setblock 457 62 258 minecraft:sea_lantern
fill 457 62 264 464 62 264 minecraft:light_gray_stained_glass
fill 458 62 232 464 62 232 minecraft:light_gray_stained_glass
setblock 458 62 239 minecraft:sea_lantern
fill 458 62 245 464 62 245 minecraft:light_gray_stained_glass
setblock 458 62 252 minecraft:sea_lantern
fill 458 62 253 459 62 253 minecraft:light_gray_stained_glass
fill 458 62 258 464 62 258 minecraft:light_gray_stained_glass
setblock 458 62 265 minecraft:sea_lantern
fill 458 62 266 459 62 269 minecraft:light_gray_stained_glass
setblock 459 62 233 minecraft:sea_lantern
fill 459 62 239 464 62 239 minecraft:light_gray_stained_glass
setblock 459 62 246 minecraft:sea_lantern
fill 459 62 252 464 62 252 minecraft:light_gray_stained_glass
setblock 459 62 259 minecraft:sea_lantern
fill 459 62 265 464 62 265 minecraft:light_gray_stained_glass
fill 460 62 233 464 62 233 minecraft:light_gray_stained_glass
setblock 460 62 240 minecraft:sea_lantern
fill 460 62 246 464 62 246 minecraft:light_gray_stained_glass
setblock 460 62 253 minecraft:sea_lantern
fill 460 62 259 464 62 259 minecraft:light_gray_stained_glass
setblock 460 62 266 minecraft:sea_lantern
fill 460 62 267 461 62 269 minecraft:light_gray_stained_glass
setblock 461 62 234 minecraft:sea_lantern
fill 461 62 240 464 62 240 minecraft:light_gray_stained_glass
setblock 461 62 247 minecraft:sea_lantern
fill 461 62 248 462 62 248 minecraft:light_gray_stained_glass
fill 461 62 253 464 62 253 minecraft:light_gray_stained_glass
setblock 461 62 260 minecraft:sea_lantern
fill 461 62 266 464 62 266 minecraft:light_gray_stained_glass
fill 462 62 234 464 62 234 minecraft:light_gray_stained_glass
setblock 462 62 241 minecraft:sea_lantern
fill 462 62 242 463 62 242 minecraft:light_gray_stained_glass
fill 462 62 247 464 62 247 minecraft:light_gray_stained_glass
setblock 462 62 254 minecraft:sea_lantern
fill 462 62 255 463 62 255 minecraft:light_gray_stained_glass
fill 462 62 260 464 62 260 minecraft:light_gray_stained_glass
setblock 462 62 267 minecraft:sea_lantern
fill 462 62 268 463 62 269 minecraft:light_gray_stained_glass
setblock 463 62 235 minecraft:sea_lantern
fill 463 62 241 464 62 241 minecraft:light_gray_stained_glass
setblock 463 62 248 minecraft:sea_lantern
fill 463 62 254 464 62 254 minecraft:light_gray_stained_glass
setblock 463 62 261 minecraft:sea_lantern
fill 463 62 267 464 62 267 minecraft:light_gray_stained_glass
setblock 464 62 229 minecraft:sea_lantern
setblock 464 62 235 minecraft:light_gray_stained_glass
setblock 464 62 242 minecraft:sea_lantern
setblock 464 62 248 minecraft:light_gray_stained_glass
setblock 464 62 255 minecraft:sea_lantern
setblock 464 62 261 minecraft:light_gray_stained_glass
setblock 464 62 268 minecraft:sea_lantern
setblock 464 62 269 minecraft:light_gray_stained_glass
fill 465 62 234 465 69 234 minecraft:black_concrete
setblock 465 62 261 minecraft:pearlescent_froglight
setblock 465 62 267 minecraft:white_concrete
fill 423 63 236 423 96 236 minecraft:black_concrete
fill 425 63 228 425 182 228 minecraft:black_concrete
fill 432 63 228 432 65 228 minecraft:black_concrete
fill 440 63 248 440 64 252 minecraft:white_concrete
fill 441 63 246 441 64 246 minecraft:white_concrete
fill 441 63 247 441 63 248 minecraft:light_gray_concrete
fill 441 63 252 441 63 253 minecraft:light_gray_concrete
fill 441 63 254 441 64 254 minecraft:white_concrete
fill 442 63 245 442 64 245 minecraft:white_concrete
setblock 442 63 246 minecraft:light_gray_concrete
setblock 442 63 248 minecraft:white_concrete
setblock 442 63 252 minecraft:white_concrete
setblock 442 63 254 minecraft:light_gray_concrete
fill 442 63 255 442 64 255 minecraft:white_concrete
fill 443 63 244 443 64 244 minecraft:white_concrete
setblock 443 63 245 minecraft:light_gray_concrete
setblock 443 63 246 minecraft:white_concrete
setblock 443 63 254 minecraft:white_concrete
setblock 443 63 255 minecraft:light_gray_concrete
fill 443 63 256 443 64 256 minecraft:white_concrete
fill 444 63 244 445 63 244 minecraft:light_gray_concrete
fill 444 63 256 445 63 256 minecraft:light_gray_concrete
fill 445 63 243 449 64 243 minecraft:white_concrete
setblock 445 63 245 minecraft:white_concrete
setblock 445 63 255 minecraft:white_concrete
fill 445 63 257 449 64 257 minecraft:white_concrete
fill 449 63 244 450 63 244 minecraft:light_gray_concrete
setblock 449 63 245 minecraft:white_concrete
setblock 449 63 255 minecraft:white_concrete
fill 449 63 256 450 63 256 minecraft:light_gray_concrete
fill 451 63 244 451 64 244 minecraft:white_concrete
setblock 451 63 245 minecraft:light_gray_concrete
setblock 451 63 246 minecraft:white_concrete
setblock 451 63 254 minecraft:white_concrete
setblock 451 63 255 minecraft:light_gray_concrete
fill 451 63 256 451 64 256 minecraft:white_concrete
fill 451 63 270 451 64 270 minecraft:ochre_froglight
fill 452 63 245 452 64 245 minecraft:white_concrete
setblock 452 63 246 minecraft:light_gray_concrete
setblock 452 63 248 minecraft:white_concrete
setblock 452 63 252 minecraft:white_concrete
setblock 452 63 254 minecraft:light_gray_concrete
fill 452 63 255 452 64 255 minecraft:white_concrete
fill 453 63 246 453 64 246 minecraft:white_concrete
fill 453 63 247 453 63 248 minecraft:light_gray_concrete
fill 453 63 252 453 63 253 minecraft:light_gray_concrete
fill 453 63 254 453 64 254 minecraft:white_concrete
setblock 453 63 270 minecraft:white_concrete
fill 454 63 248 454 64 252 minecraft:white_concrete
setblock 463 63 270 minecraft:pearlescent_froglight
fill 465 63 261 465 67 261 minecraft:black_concrete
fill 465 63 267 465 64 267 minecraft:black_concrete
setblock 423 64 233 minecraft:pearlescent_froglight
setblock 423 64 266 minecraft:sea_lantern
setblock 426 64 231 minecraft:light[level=12]
setblock 426 64 238 minecraft:light[level=12]
setblock 426 64 245 minecraft:light[level=12]
setblock 426 64 252 minecraft:light[level=12]
setblock 426 64 259 minecraft:light[level=12]
setblock 426 64 266 minecraft:light[level=12]
setblock 433 64 231 minecraft:light[level=12]
setblock 433 64 238 minecraft:light[level=12]
setblock 433 64 245 minecraft:light[level=12]
setblock 433 64 252 minecraft:light[level=12]
setblock 433 64 259 minecraft:light[level=12]
setblock 433 64 266 minecraft:light[level=12]
fill 439 64 247 439 64 253 minecraft:white_concrete
setblock 439 64 270 minecraft:ochre_froglight
setblock 440 64 231 minecraft:light[level=12]
setblock 440 64 238 minecraft:light[level=12]
fill 440 64 245 440 64 247 minecraft:white_concrete
fill 440 64 253 440 64 255 minecraft:white_concrete
setblock 440 64 259 minecraft:light[level=12]
setblock 440 64 266 minecraft:light[level=12]
fill 441 64 244 441 64 245 minecraft:white_concrete
fill 441 64 255 441 64 256 minecraft:white_concrete
fill 442 64 243 442 64 244 minecraft:white_concrete
fill 442 64 256 442 64 257 minecraft:white_concrete
fill 443 64 243 444 64 243 minecraft:white_concrete
fill 443 64 257 444 64 257 minecraft:white_concrete
fill 444 64 242 450 64 242 minecraft:white_concrete
fill 444 64 258 450 64 258 minecraft:white_concrete
setblock 444 64 270 minecraft:sea_lantern
setblock 447 64 231 minecraft:light[level=12]
setblock 447 64 238 minecraft:light[level=12]
setblock 447 64 245 minecraft:light[level=12]
setblock 447 64 259 minecraft:light[level=12]
setblock 447 64 266 minecraft:light[level=12]
fill 450 64 243 452 64 243 minecraft:white_concrete
fill 450 64 257 452 64 257 minecraft:white_concrete
fill 452 64 244 453 64 244 minecraft:white_concrete
fill 452 64 256 453 64 256 minecraft:white_concrete
fill 453 64 245 454 64 245 minecraft:white_concrete
fill 453 64 255 454 64 255 minecraft:white_concrete
fill 453 64 270 453 70 270 minecraft:black_concrete
setblock 454 64 231 minecraft:light[level=12]
setblock 454 64 238 minecraft:light[level=12]
fill 454 64 246 454 64 247 minecraft:white_concrete
fill 454 64 253 454 64 254 minecraft:white_concrete
setblock 454 64 259 minecraft:light[level=12]
setblock 454 64 266 minecraft:light[level=12]
fill 455 64 247 455 64 253 minecraft:white_concrete
setblock 455 64 270 minecraft:pearlescent_froglight
setblock 461 64 231 minecraft:light[level=12]
setblock 461 64 238 minecraft:light[level=12]
setblock 461 64 245 minecraft:light[level=12]
setblock 461 64 252 minecraft:light[level=12]
setblock 461 64 259 minecraft:light[level=12]
setblock 461 64 266 minecraft:light[level=12]
fill 463 64 270 463 80 270 minecraft:black_concrete
fill 423 65 233 423 84 233 minecraft:black_concrete
fill 423 65 266 423 114 266 minecraft:black_concrete
fill 438 65 246 438 65 249 minecraft:light_gray_concrete
fill 438 65 252 438 65 254 minecraft:light_gray_concrete
fill 439 65 245 439 66 245 minecraft:light_gray_concrete
fill 439 65 246 439 65 248 minecraft:white_concrete
fill 439 65 252 439 65 254 minecraft:white_concrete
fill 439 65 255 439 66 255 minecraft:light_gray_concrete
fill 439 65 270 439 187 270 minecraft:black_concrete
fill 440 65 243 440 65 244 minecraft:light_gray_concrete
setblock 440 65 245 minecraft:white_concrete
setblock 440 65 255 minecraft:white_concrete
fill 440 65 256 440 65 257 minecraft:light_gray_concrete
setblock 441 65 243 minecraft:light_gray_concrete
setblock 441 65 244 minecraft:white_concrete
setblock 441 65 256 minecraft:white_concrete
setblock 441 65 257 minecraft:light_gray_concrete
fill 442 65 242 442 66 242 minecraft:light_gray_concrete
setblock 442 65 243 minecraft:white_concrete
setblock 442 65 257 minecraft:white_concrete
fill 442 65 258 442 66 258 minecraft:light_gray_concrete
fill 443 65 241 450 65 241 minecraft:light_gray_concrete
fill 443 65 242 445 65 242 minecraft:white_concrete
fill 443 65 258 445 65 258 minecraft:white_concrete
fill 443 65 259 451 65 259 minecraft:light_gray_concrete
fill 444 65 270 444 209 270 minecraft:black_concrete
setblock 445 65 270 minecraft:white_concrete
fill 449 65 242 450 65 242 minecraft:white_concrete
fill 449 65 258 451 65 258 minecraft:white_concrete
setblock 451 65 270 minecraft:black_concrete
setblock 452 65 243 minecraft:white_concrete
setblock 452 65 257 minecraft:white_concrete
fill 453 65 243 454 65 243 minecraft:light_gray_concrete
setblock 453 65 244 minecraft:white_concrete
setblock 453 65 256 minecraft:white_concrete
fill 453 65 257 454 65 257 minecraft:light_gray_concrete
setblock 454 65 244 minecraft:light_gray_concrete
setblock 454 65 245 minecraft:white_concrete
setblock 454 65 255 minecraft:white_concrete
setblock 454 65 256 minecraft:light_gray_concrete
fill 455 65 245 455 66 245 minecraft:light_gray_concrete
fill 455 65 246 455 65 248 minecraft:white_concrete
fill 455 65 252 455 65 254 minecraft:white_concrete
fill 455 65 255 455 66 255 minecraft:light_gray_concrete
fill 455 65 270 455 76 270 minecraft:black_concrete
fill 456 65 246 456 65 254 minecraft:light_gray_concrete
setblock 461 65 270 minecraft:purple_concrete
setblock 465 65 229 minecraft:ochre_froglight
setblock 465 65 264 minecraft:pearlescent_froglight
setblock 465 65 267 minecraft:purple_concrete
setblock 426 66 231 minecraft:light[level=15]
setblock 426 66 239 minecraft:light[level=15]
setblock 426 66 247 minecraft:light[level=15]
setblock 426 66 255 minecraft:light[level=15]
setblock 426 66 263 minecraft:light[level=15]
setblock 432 66 228 minecraft:ochre_froglight
setblock 434 66 231 minecraft:light[level=15]
setblock 434 66 239 minecraft:light[level=15]
setblock 434 66 247 minecraft:light[level=15]
setblock 434 66 255 minecraft:light[level=15]
setblock 434 66 263 minecraft:light[level=15]
fill 437 66 246 437 66 254 minecraft:white_concrete
fill 438 66 244 438 66 245 minecraft:white_concrete
fill 438 66 246 438 66 247 minecraft:light_gray_concrete
fill 438 66 253 438 66 254 minecraft:light_gray_concrete
fill 438 66 255 438 66 256 minecraft:white_concrete
fill 439 66 243 439 66 244 minecraft:white_concrete
fill 439 66 256 439 66 257 minecraft:white_concrete
fill 440 66 242 441 66 242 minecraft:white_concrete
setblock 440 66 243 minecraft:light_gray_concrete
setblock 440 66 257 minecraft:light_gray_concrete
fill 440 66 258 441 66 258 minecraft:white_concrete
fill 441 66 241 442 66 241 minecraft:white_concrete
fill 441 66 259 442 66 259 minecraft:white_concrete
setblock 442 66 231 minecraft:light[level=15]
setblock 442 66 239 minecraft:light[level=15]
setblock 442 66 247 minecraft:light[level=15]
setblock 442 66 255 minecraft:light[level=15]
setblock 442 66 263 minecraft:light[level=15]
fill 443 66 240 451 66 240 minecraft:white_concrete
fill 443 66 241 444 66 241 minecraft:light_gray_concrete
fill 443 66 259 444 66 259 minecraft:light_gray_concrete
fill 443 66 260 451 66 260 minecraft:white_concrete
fill 445 66 270 445 67 270 minecraft:black_concrete
setblock 450 66 231 minecraft:light[level=15]
setblock 450 66 239 minecraft:light[level=15]
fill 450 66 241 451 66 241 minecraft:light_gray_concrete
setblock 450 66 247 minecraft:light[level=15]
setblock 450 66 255 minecraft:light[level=15]
fill 450 66 259 451 66 259 minecraft:light_gray_concrete
setblock 450 66 263 minecraft:light[level=15]
setblock 451 66 270 minecraft:white_concrete
fill 452 66 241 453 66 241 minecraft:white_concrete
setblock 452 66 242 minecraft:light_gray_concrete
setblock 452 66 258 minecraft:light_gray_concrete
fill 452 66 259 453 66 259 minecraft:white_concrete
fill 453 66 242 454 66 242 minecraft:white_concrete
fill 453 66 258 454 66 258 minecraft:white_concrete
setblock 454 66 243 minecraft:light_gray_concrete
setblock 454 66 257 minecraft:light_gray_concrete
setblock 454 66 270 minecraft:purple_concrete
fill 455 66 243 455 66 244 minecraft:white_concrete
fill 455 66 256 455 66 257 minecraft:white_concrete
fill 456 66 244 456 66 245 minecraft:white_concrete
fill 456 66 246 456 66 247 minecraft:light_gray_concrete
fill 456 66 253 456 66 254 minecraft:light_gray_concrete
fill 456 66 255 456 66 256 minecraft:white_concrete
fill 457 66 246 457 66 254 minecraft:white_concrete
setblock 458 66 231 minecraft:light[level=15]
setblock 458 66 239 minecraft:light[level=15]
setblock 458 66 247 minecraft:light[level=15]
setblock 458 66 255 minecraft:light[level=15]
setblock 458 66 263 minecraft:light[level=15]
setblock 461 66 228 minecraft:white_concrete
fill 461 66 270 461 75 270 minecraft:black_concrete
fill 465 66 229 465 111 229 minecraft:black_concrete
setblock 465 66 247 minecraft:sea_lantern
fill 465 66 264 465 86 264 minecraft:black_concrete
fill 465 66 267 465 136 267 minecraft:black_concrete
setblock 423 67 254 minecraft:pearlescent_froglight
setblock 423 67 260 minecraft:sea_lantern
fill 427 67 270 427 145 270 minecraft:black_concrete
setblock 428 67 270 minecraft:purple_concrete
setblock 430 67 270 minecraft:blue_concrete
fill 432 67 228 432 150 228 minecraft:black_concrete
setblock 433 67 270 minecraft:sea_lantern
fill 436 67 246 436 67 254 minecraft:white_concrete
fill 437 67 244 437 67 246 minecraft:white_concrete
fill 437 67 254 437 67 256 minecraft:white_concrete
setblock 438 67 228 minecraft:white_concrete
fill 438 67 243 438 67 244 minecraft:white_concrete
fill 438 67 256 438 67 257 minecraft:white_concrete
fill 439 67 242 439 67 243 minecraft:white_concrete
fill 439 67 257 439 67 258 minecraft:white_concrete
fill 440 67 241 440 67 242 minecraft:white_concrete
fill 440 67 258 440 67 259 minecraft:white_concrete
fill 441 67 240 441 67 241 minecraft:white_concrete
fill 441 67 259 441 67 260 minecraft:white_concrete
fill 442 67 240 443 67 240 minecraft:white_concrete
fill 442 67 260 443 67 260 minecraft:white_concrete
fill 443 67 239 451 67 239 minecraft:white_concrete
fill 443 67 261 451 67 261 minecraft:white_concrete
fill 451 67 240 453 67 240 minecraft:white_concrete
fill 451 67 260 453 67 260 minecraft:white_concrete
fill 451 67 270 451 106 270 minecraft:black_concrete
fill 453 67 241 454 67 241 minecraft:white_concrete
fill 453 67 259 454 67 259 minecraft:white_concrete
fill 454 67 242 455 67 242 minecraft:white_concrete
fill 454 67 258 455 67 258 minecraft:white_concrete
fill 454 67 270 454 84 270 minecraft:black_concrete
fill 455 67 243 456 67 243 minecraft:white_concrete
fill 455 67 257 456 67 257 minecraft:white_concrete
fill 456 67 244 457 67 244 minecraft:white_concrete
fill 456 67 256 457 67 256 minecraft:white_concrete
fill 457 67 245 457 67 246 minecraft:white_concrete
fill 457 67 254 457 67 255 minecraft:white_concrete
fill 458 67 246 458 67 254 minecraft:white_concrete
fill 461 67 228 461 68 228 minecraft:black_concrete
fill 465 67 247 465 115 247 minecraft:black_concrete
setblock 423 68 230 minecraft:purple_terracotta
fill 423 68 254 423 296 254 minecraft:black_concrete
fill 423 68 260 423 133 260 minecraft:black_concrete
fill 428 68 270 428 108 270 minecraft:black_concrete
setblock 429 68 228 minecraft:white_concrete
fill 430 68 270 430 114 270 minecraft:black_concrete
fill 433 68 270 433 123 270 minecraft:black_concrete
fill 435 68 247 435 68 253 minecraft:light_gray_concrete
setblock 436 68 245 minecraft:light_gray_concrete
fill 436 68 246 436 68 247 minecraft:white_concrete
fill 436 68 253 436 68 254 minecraft:white_concrete
setblock 436 68 255 minecraft:light_gray_concrete
setblock 437 68 243 minecraft:light_gray_concrete
setblock 437 68 244 minecraft:white_concrete
setblock 437 68 256 minecraft:iron_block
setblock 437 68 257 minecraft:light_gray_concrete
fill 438 68 228 438 83 228 minecraft:black_concrete
setblock 438 68 242 minecraft:light_gray_concrete
setblock 438 68 243 minecraft:white_concrete
setblock 438 68 257 minecraft:white_concrete
setblock 438 68 258 minecraft:light_gray_concrete
setblock 439 68 241 minecraft:light_gray_concrete
setblock 439 68 259 minecraft:light_gray_concrete
setblock 440 68 240 minecraft:light_gray_concrete
setblock 440 68 241 minecraft:white_concrete
setblock 440 68 259 minecraft:white_concrete
setblock 440 68 260 minecraft:light_gray_concrete
setblock 441 68 240 minecraft:white_concrete
setblock 441 68 260 minecraft:white_concrete
setblock 442 68 239 minecraft:light_gray_concrete
setblock 442 68 261 minecraft:light_gray_concrete
fill 443 68 239 444 68 239 minecraft:white_concrete
fill 443 68 261 444 68 261 minecraft:white_concrete
fill 444 68 238 450 68 238 minecraft:light_gray_concrete
fill 444 68 262 450 68 262 minecraft:light_gray_concrete
setblock 445 68 270 minecraft:white_concrete
fill 447 68 239 447 69 239 minecraft:iron_block
fill 450 68 239 451 68 239 minecraft:white_concrete
fill 450 68 261 451 68 261 minecraft:white_concrete
setblock 452 68 239 minecraft:light_gray_concrete
setblock 452 68 261 minecraft:light_gray_concrete
setblock 453 68 240 minecraft:white_concrete
setblock 453 68 260 minecraft:white_concrete
setblock 454 68 240 minecraft:light_gray_concrete
setblock 454 68 241 minecraft:white_concrete
setblock 454 68 259 minecraft:white_concrete
setblock 454 68 260 minecraft:light_gray_concrete
setblock 455 68 241 minecraft:light_gray_concrete
setblock 455 68 259 minecraft:light_gray_concrete
setblock 456 68 242 minecraft:light_gray_concrete
setblock 456 68 243 minecraft:white_concrete
setblock 456 68 257 minecraft:white_concrete
setblock 456 68 258 minecraft:light_gray_concrete
setblock 456 68 270 minecraft:sea_lantern
setblock 457 68 243 minecraft:light_gray_concrete
setblock 457 68 244 minecraft:white_concrete
fill 457 68 255 457 68 256 minecraft:iron_block
setblock 457 68 257 minecraft:light_gray_concrete
setblock 458 68 245 minecraft:light_gray_concrete
fill 458 68 246 458 68 247 minecraft:white_concrete
fill 458 68 253 458 68 254 minecraft:white_concrete
setblock 458 68 255 minecraft:light_gray_concrete
fill 459 68 247 459 68 253 minecraft:light_gray_concrete
fill 465 68 241 465 73 241 minecraft:black_concrete
setblock 465 68 242 minecraft:purple_terracotta
setblock 465 68 261 minecraft:purple_concrete
fill 423 69 230 423 107 230 minecraft:black_concrete
fill 429 69 228 429 158 228 minecraft:black_concrete
setblock 431 69 228 minecraft:sea_lantern
setblock 435 69 247 minecraft:light_gray_concrete
setblock 435 69 253 minecraft:light_gray_concrete
fill 438 69 255 438 69 256 minecraft:iron_block
setblock 439 69 228 minecraft:sea_lantern
setblock 444 69 238 minecraft:light_gray_concrete
setblock 444 69 262 minecraft:light_gray_concrete
fill 445 69 270 445 182 270 minecraft:black_concrete
fill 447 69 240 447 70 240 minecraft:iron_block
setblock 450 69 238 minecraft:light_gray_concrete
setblock 450 69 262 minecraft:light_gray_concrete
setblock 451 69 228 minecraft:sea_lantern
setblock 456 69 255 minecraft:iron_block
fill 456 69 270 456 108 270 minecraft:black_concrete
setblock 459 69 247 minecraft:light_gray_concrete
setblock 459 69 253 minecraft:light_gray_concrete
setblock 461 69 228 minecraft:pearlescent_froglight
fill 465 69 242 465 100 242 minecraft:black_concrete
fill 465 69 261 465 98 261 minecraft:black_concrete
setblock 465 69 265 minecraft:sea_lantern
setblock 465 69 269 minecraft:purple_concrete
setblock 426 70 231 minecraft:light[level=12]
setblock 426 70 238 minecraft:light[level=12]
setblock 426 70 245 minecraft:light[level=12]
setblock 426 70 252 minecraft:light[level=12]
setblock 426 70 259 minecraft:light[level=12]
setblock 426 70 266 minecraft:light[level=12]
fill 431 70 228 431 86 228 minecraft:black_concrete
setblock 433 70 231 minecraft:light[level=12]
setblock 433 70 238 minecraft:light[level=12]
fill 433 70 240 434 71 241 minecraft:end_stone
setblock 433 70 245 minecraft:light[level=12]
setblock 433 70 252 minecraft:light[level=12]
setblock 433 70 259 minecraft:light[level=12]
setblock 433 70 266 minecraft:light[level=12]
fill 439 70 228 439 267 228 minecraft:black_concrete
setblock 439 70 255 minecraft:iron_block
setblock 440 70 231 minecraft:light[level=12]
setblock 440 70 238 minecraft:light[level=12]
setblock 440 70 245 minecraft:light[level=12]
setblock 440 70 252 minecraft:light[level=12]
setblock 440 70 259 minecraft:light[level=12]
setblock 440 70 266 minecraft:light[level=12]
setblock 446 70 228 minecraft:blue_concrete
setblock 447 70 231 minecraft:light[level=12]
setblock 447 70 238 minecraft:light[level=12]
setblock 447 70 241 minecraft:iron_block
setblock 447 70 245 minecraft:light[level=12]
setblock 447 70 252 minecraft:light[level=12]
setblock 447 70 259 minecraft:light[level=12]
setblock 447 70 266 minecraft:light[level=12]
fill 451 70 228 451 141 228 minecraft:black_concrete
setblock 454 70 231 minecraft:light[level=12]
setblock 454 70 238 minecraft:light[level=12]
setblock 454 70 245 minecraft:light[level=12]
setblock 454 70 252 minecraft:light[level=12]
setblock 454 70 259 minecraft:light[level=12]
setblock 454 70 266 minecraft:light[level=12]
setblock 455 70 254 minecraft:iron_block
setblock 461 70 228 minecraft:black_concrete
setblock 461 70 231 minecraft:light[level=12]
setblock 461 70 238 minecraft:light[level=12]
setblock 461 70 245 minecraft:light[level=12]
setblock 461 70 252 minecraft:light[level=12]
setblock 461 70 259 minecraft:light[level=12]
setblock 461 70 266 minecraft:light[level=12]
setblock 465 70 234 minecraft:pearlescent_froglight
setblock 465 70 235 minecraft:white_concrete
setblock 465 70 265 minecraft:white_concrete
fill 465 70 269 465 107 269 minecraft:black_concrete
setblock 423 71 237 minecraft:sea_lantern
setblock 425 71 270 minecraft:pearlescent_froglight
fill 438 71 255 440 73 255 minecraft:tuff
fill 439 71 256 439 74 256 minecraft:tuff
setblock 440 71 254 minecraft:iron_block
fill 446 71 228 446 82 228 minecraft:black_concrete
setblock 447 71 242 minecraft:iron_block
setblock 453 71 270 minecraft:pearlescent_froglight
setblock 454 71 254 minecraft:iron_block
setblock 461 71 228 minecraft:sea_lantern
fill 465 71 234 465 91 235 minecraft:black_concrete
fill 465 71 265 465 79 265 minecraft:black_concrete
fill 423 72 237 423 184 237 minecraft:black_concrete
setblock 423 72 265 minecraft:ochre_froglight
setblock 424 72 270 minecraft:sea_lantern
fill 425 72 270 425 126 270 minecraft:black_concrete
fill 438 72 256 438 73 256 minecraft:tuff
fill 439 72 254 440 73 254 minecraft:tuff
fill 440 72 256 440 72 257 minecraft:tuff
setblock 441 72 254 minecraft:iron_block
fill 441 72 255 441 73 256 minecraft:tuff
setblock 443 72 270 minecraft:purple_concrete
setblock 447 72 243 minecraft:iron_block
setblock 452 72 228 minecraft:ochre_froglight
setblock 453 72 253 minecraft:iron_block
fill 453 72 270 453 103 270 minecraft:black_concrete
fill 461 72 228 461 109 228 minecraft:black_concrete
setblock 465 72 231 minecraft:white_concrete
setblock 423 73 257 minecraft:white_concrete
fill 423 73 265 423 154 265 minecraft:black_concrete
fill 424 73 270 424 143 270 minecraft:black_concrete
setblock 426 73 231 minecraft:light[level=15]
setblock 426 73 239 minecraft:light[level=15]
setblock 426 73 247 minecraft:light[level=15]
setblock 426 73 255 minecraft:light[level=15]
setblock 426 73 263 minecraft:light[level=15]
setblock 434 73 231 minecraft:light[level=15]
setblock 434 73 239 minecraft:light[level=15]
setblock 434 73 247 minecraft:light[level=15]
setblock 434 73 255 minecraft:light[level=15]
setblock 434 73 263 minecraft:light[level=15]
setblock 440 73 256 minecraft:tuff
setblock 442 73 231 minecraft:light[level=15]
setblock 442 73 239 minecraft:light[level=15]
setblock 442 73 247 minecraft:light[level=15]
setblock 442 73 255 minecraft:light[level=15]
setblock 442 73 263 minecraft:light[level=15]
fill 443 73 270 443 215 270 minecraft:black_concrete
setblock 450 73 231 minecraft:light[level=15]
setblock 450 73 239 minecraft:light[level=15]
setblock 450 73 247 minecraft:light[level=15]
setblock 450 73 255 minecraft:light[level=15]
setblock 450 73 263 minecraft:light[level=15]
fill 452 73 228 452 79 228 minecraft:black_concrete
setblock 458 73 231 minecraft:light[level=15]
setblock 458 73 239 minecraft:light[level=15]
setblock 458 73 247 minecraft:light[level=15]
setblock 458 73 255 minecraft:light[level=15]
setblock 458 73 263 minecraft:light[level=15]
setblock 460 73 228 minecraft:white_concrete
fill 465 73 231 465 95 231 minecraft:black_concrete
setblock 465 73 240 minecraft:white_concrete
fill 423 74 257 423 82 257 minecraft:black_concrete
fill 439 74 255 440 74 255 minecraft:tuff
setblock 459 74 228 minecraft:ochre_froglight
fill 460 74 228 460 114 228 minecraft:black_concrete
fill 465 74 240 465 103 240 minecraft:black_concrete
setblock 465 74 241 minecraft:purple_terracotta
setblock 438 75 270 minecraft:white_concrete
setblock 441 75 270 minecraft:pearlescent_froglight
fill 459 75 228 459 107 228 minecraft:black_concrete
fill 465 75 241 465 119 241 minecraft:black_concrete
setblock 465 75 249 minecraft:sea_lantern
setblock 426 76 231 minecraft:light[level=12]
setblock 426 76 238 minecraft:light[level=12]
setblock 426 76 245 minecraft:light[level=12]
setblock 426 76 252 minecraft:light[level=12]
setblock 426 76 259 minecraft:light[level=12]
setblock 426 76 266 minecraft:light[level=12]
setblock 433 76 231 minecraft:light[level=12]
setblock 433 76 238 minecraft:light[level=12]
setblock 433 76 245 minecraft:light[level=12]
setblock 433 76 252 minecraft:light[level=12]
setblock 433 76 259 minecraft:light[level=12]
setblock 433 76 266 minecraft:light[level=12]
fill 438 76 270 438 102 270 minecraft:black_concrete
setblock 440 76 231 minecraft:light[level=12]
setblock 440 76 238 minecraft:light[level=12]
setblock 440 76 245 minecraft:light[level=12]
setblock 440 76 252 minecraft:light[level=12]
setblock 440 76 259 minecraft:light[level=12]
setblock 440 76 266 minecraft:light[level=12]
fill 441 76 270 441 204 270 minecraft:black_concrete
setblock 442 76 228 minecraft:purple_concrete
setblock 447 76 231 minecraft:light[level=12]
setblock 447 76 238 minecraft:light[level=12]
setblock 447 76 245 minecraft:light[level=12]
setblock 447 76 252 minecraft:light[level=12]
setblock 447 76 259 minecraft:light[level=12]
setblock 447 76 266 minecraft:light[level=12]
setblock 454 76 231 minecraft:light[level=12]
setblock 454 76 238 minecraft:light[level=12]
setblock 454 76 245 minecraft:light[level=12]
setblock 454 76 252 minecraft:light[level=12]
setblock 454 76 259 minecraft:light[level=12]
setblock 454 76 266 minecraft:light[level=12]
setblock 458 76 270 minecraft:ochre_froglight
setblock 461 76 231 minecraft:light[level=12]
setblock 461 76 238 minecraft:light[level=12]
setblock 461 76 245 minecraft:light[level=12]
setblock 461 76 252 minecraft:light[level=12]
setblock 461 76 259 minecraft:light[level=12]
setblock 461 76 266 minecraft:light[level=12]
setblock 461 76 270 minecraft:ochre_froglight
fill 465 76 249 465 171 249 minecraft:black_concrete
setblock 465 76 260 minecraft:pearlescent_froglight
fill 442 77 228 442 110 228 minecraft:black_concrete
setblock 450 77 228 minecraft:magenta_terracotta
setblock 455 77 270 minecraft:pearlescent_froglight
fill 458 77 270 458 174 270 minecraft:black_concrete
fill 461 77 270 461 89 270 minecraft:black_concrete
setblock 465 77 246 minecraft:sea_lantern
fill 465 77 260 465 149 260 minecraft:black_concrete
setblock 423 78 263 minecraft:pearlescent_froglight
setblock 434 78 228 minecraft:ochre_froglight
setblock 448 78 270 minecraft:purple_terracotta
fill 450 78 228 450 124 228 minecraft:black_concrete
fill 455 78 270 455 152 270 minecraft:black_concrete
setblock 465 78 233 minecraft:white_concrete
fill 465 78 246 465 86 246 minecraft:black_concrete
setblock 465 78 263 minecraft:white_concrete
fill 423 79 263 423 95 263 minecraft:black_concrete
setblock 423 79 268 minecraft:sea_lantern
setblock 426 79 228 minecraft:sea_lantern
fill 434 79 228 434 114 228 minecraft:black_concrete
setblock 447 79 228 minecraft:pearlescent_froglight
fill 448 79 270 448 86 270 minecraft:black_concrete
setblock 460 79 270 minecraft:pearlescent_froglight
fill 465 79 233 465 83 233 minecraft:black_concrete
setblock 465 79 245 minecraft:blue_concrete
fill 465 79 263 465 83 263 minecraft:black_concrete
setblock 423 80 229 minecraft:magenta_terracotta
fill 423 80 268 423 151 268 minecraft:black_concrete
fill 426 80 228 426 108 228 minecraft:black_concrete
setblock 426 80 231 minecraft:light[level=15]
setblock 426 80 239 minecraft:light[level=15]
setblock 426 80 247 minecraft:light[level=15]
setblock 426 80 255 minecraft:light[level=15]
setblock 426 80 263 minecraft:light[level=15]
setblock 434 80 231 minecraft:light[level=15]
setblock 434 80 239 minecraft:light[level=15]
setblock 434 80 247 minecraft:light[level=15]
setblock 434 80 255 minecraft:light[level=15]
setblock 434 80 263 minecraft:light[level=15]
setblock 436 80 228 minecraft:pearlescent_froglight
setblock 440 80 270 minecraft:ochre_froglight
setblock 442 80 231 minecraft:light[level=15]
setblock 442 80 239 minecraft:light[level=15]
setblock 442 80 247 minecraft:light[level=15]
setblock 442 80 255 minecraft:light[level=15]
setblock 442 80 263 minecraft:light[level=15]
setblock 446 80 270 minecraft:white_concrete
fill 447 80 228 447 127 228 minecraft:black_concrete
setblock 450 80 231 minecraft:light[level=15]
setblock 450 80 239 minecraft:light[level=15]
setblock 450 80 247 minecraft:light[level=15]
setblock 450 80 255 minecraft:light[level=15]
setblock 450 80 263 minecraft:light[level=15]
setblock 452 80 228 minecraft:pearlescent_froglight
setblock 458 80 231 minecraft:light[level=15]
setblock 458 80 239 minecraft:light[level=15]
setblock 458 80 247 minecraft:light[level=15]
setblock 458 80 255 minecraft:light[level=15]
setblock 458 80 263 minecraft:light[level=15]
fill 460 80 270 460 114 270 minecraft:black_concrete
fill 461 80 248 462 81 249 minecraft:end_stone
fill 462 80 250 462 81 250 minecraft:end_stone
fill 465 80 245 465 157 245 minecraft:black_concrete
setblock 465 80 265 minecraft:white_concrete
fill 423 81 229 423 308 229 minecraft:black_concrete
fill 436 81 228 436 127 228 minecraft:black_concrete
setblock 440 81 270 minecraft:black_concrete
fill 446 81 270 446 91 270 minecraft:black_concrete
setblock 447 81 270 minecraft:sea_lantern
fill 452 81 228 452 163 228 minecraft:black_concrete
setblock 452 81 270 minecraft:blue_concrete
setblock 463 81 270 minecraft:white_concrete
fill 465 81 265 465 104 265 minecraft:black_concrete
fill 423 82 231 423 177 231 minecraft:black_concrete
setblock 423 82 232 minecraft:ochre_froglight
setblock 423 82 239 minecraft:white_concrete
setblock 423 82 264 minecraft:ochre_froglight
setblock 426 82 231 minecraft:light[level=12]
setblock 426 82 238 minecraft:light[level=12]
setblock 426 82 245 minecraft:light[level=12]
setblock 426 82 252 minecraft:light[level=12]
setblock 426 82 259 minecraft:light[level=12]
setblock 426 82 266 minecraft:light[level=12]
setblock 433 82 231 minecraft:light[level=12]
setblock 433 82 238 minecraft:light[level=12]
setblock 433 82 245 minecraft:light[level=12]
setblock 433 82 252 minecraft:light[level=12]
setblock 433 82 259 minecraft:light[level=12]
setblock 433 82 266 minecraft:light[level=12]
setblock 440 82 231 minecraft:light[level=12]
setblock 440 82 238 minecraft:light[level=12]
setblock 440 82 245 minecraft:light[level=12]
setblock 440 82 252 minecraft:light[level=12]
setblock 440 82 259 minecraft:light[level=12]
setblock 440 82 266 minecraft:light[level=12]
setblock 440 82 270 minecraft:sea_lantern
setblock 444 82 228 minecraft:sea_lantern
setblock 447 82 231 minecraft:light[level=12]
setblock 447 82 238 minecraft:light[level=12]
setblock 447 82 245 minecraft:light[level=12]
setblock 447 82 252 minecraft:light[level=12]
setblock 447 82 259 minecraft:light[level=12]
setblock 447 82 266 minecraft:light[level=12]
fill 447 82 270 447 135 270 minecraft:black_concrete
fill 452 82 270 452 131 270 minecraft:black_concrete
setblock 454 82 231 minecraft:light[level=12]
setblock 454 82 238 minecraft:light[level=12]
setblock 454 82 245 minecraft:light[level=12]
setblock 454 82 252 minecraft:light[level=12]
setblock 454 82 259 minecraft:light[level=12]
setblock 454 82 266 minecraft:light[level=12]
setblock 461 82 231 minecraft:light[level=12]
setblock 461 82 238 minecraft:light[level=12]
setblock 461 82 245 minecraft:light[level=12]
setblock 461 82 252 minecraft:light[level=12]
setblock 461 82 259 minecraft:light[level=12]
setblock 461 82 266 minecraft:light[level=12]
fill 463 82 270 463 90 270 minecraft:black_concrete
setblock 465 82 251 minecraft:white_concrete
fill 423 83 232 423 133 232 minecraft:black_concrete
fill 423 83 239 423 104 239 minecraft:black_concrete
setblock 423 83 257 minecraft:pearlescent_froglight
fill 423 83 264 423 90 264 minecraft:black_concrete
fill 440 83 270 440 152 270 minecraft:black_concrete
fill 444 83 228 444 91 228 minecraft:black_concrete
setblock 446 83 228 minecraft:white_concrete
fill 459 83 245 459 84 246 minecraft:gray_concrete
fill 460 83 242 461 84 243 minecraft:gray_concrete
fill 461 83 244 461 84 244 minecraft:gray_concrete
fill 465 83 251 465 98 251 minecraft:black_concrete
fill 423 84 257 423 99 257 minecraft:black_concrete
setblock 438 84 228 minecraft:ochre_froglight
setblock 445 84 228 minecraft:sea_lantern
fill 446 84 228 446 100 228 minecraft:black_concrete
setblock 465 84 233 minecraft:white_concrete
setblock 465 84 263 minecraft:pearlescent_froglight
setblock 423 85 233 minecraft:magenta_terracotta
setblock 423 85 262 minecraft:magenta_terracotta
fill 438 85 228 438 95 228 minecraft:black_concrete
fill 445 85 228 445 93 228 minecraft:black_concrete
setblock 454 85 270 minecraft:ochre_froglight
fill 465 85 233 465 90 233 minecraft:black_concrete
fill 465 85 263 465 131 263 minecraft:black_concrete
fill 423 86 233 423 105 233 minecraft:black_concrete
fill 423 86 262 423 121 262 minecraft:black_concrete
fill 454 86 270 454 99 270 minecraft:black_concrete
fill 455 86 246 455 87 246 minecraft:pearlescent_froglight
setblock 464 86 228 minecraft:sea_lantern
fill 465 86 228 465 308 228 minecraft:black_concrete
setblock 465 86 239 minecraft:sea_lantern
setblock 465 86 252 minecraft:sea_lantern
setblock 423 87 235 minecraft:pearlescent_froglight
setblock 426 87 231 minecraft:light[level=15]
setblock 426 87 239 minecraft:light[level=15]
setblock 426 87 247 minecraft:light[level=15]
setblock 426 87 255 minecraft:light[level=15]
setblock 426 87 263 minecraft:light[level=15]
setblock 431 87 228 minecraft:pearlescent_froglight
setblock 434 87 231 minecraft:light[level=15]
setblock 434 87 239 minecraft:light[level=15]
setblock 434 87 247 minecraft:light[level=15]
setblock 434 87 255 minecraft:light[level=15]
setblock 434 87 263 minecraft:light[level=15]
setblock 442 87 231 minecraft:light[level=15]
setblock 442 87 239 minecraft:light[level=15]
setblock 442 87 247 minecraft:light[level=15]
setblock 442 87 255 minecraft:light[level=15]
setblock 442 87 263 minecraft:light[level=15]
setblock 448 87 270 minecraft:sea_lantern
setblock 450 87 231 minecraft:light[level=15]
setblock 450 87 239 minecraft:light[level=15]
setblock 450 87 247 minecraft:light[level=15]
setblock 450 87 255 minecraft:light[level=15]
setblock 450 87 263 minecraft:light[level=15]
setblock 458 87 231 minecraft:light[level=15]
setblock 458 87 239 minecraft:light[level=15]
setblock 458 87 247 minecraft:light[level=15]
setblock 458 87 255 minecraft:light[level=15]
setblock 458 87 263 minecraft:light[level=15]
fill 464 87 228 464 142 228 minecraft:black_concrete
fill 465 87 239 465 162 239 minecraft:black_concrete
setblock 465 87 244 minecraft:white_concrete
setblock 465 87 246 minecraft:ochre_froglight
setblock 465 87 250 minecraft:sea_lantern
setblock 465 87 252 minecraft:purple_terracotta
setblock 465 87 257 minecraft:sea_lantern
setblock 465 87 264 minecraft:sea_lantern
fill 423 88 235 423 154 235 minecraft:black_concrete
setblock 426 88 231 minecraft:light[level=12]
setblock 426 88 238 minecraft:light[level=12]
setblock 426 88 245 minecraft:light[level=12]
setblock 426 88 252 minecraft:light[level=12]
setblock 426 88 259 minecraft:light[level=12]
setblock 426 88 266 minecraft:light[level=12]
setblock 426 88 270 minecraft:sea_lantern
fill 431 88 228 431 100 228 minecraft:black_concrete
setblock 433 88 231 minecraft:light[level=12]
setblock 433 88 238 minecraft:light[level=12]
setblock 433 88 245 minecraft:light[level=12]
setblock 433 88 252 minecraft:light[level=12]
setblock 433 88 259 minecraft:light[level=12]
setblock 433 88 266 minecraft:light[level=12]
setblock 440 88 231 minecraft:light[level=12]
setblock 440 88 238 minecraft:light[level=12]
setblock 440 88 245 minecraft:light[level=12]
setblock 440 88 252 minecraft:light[level=12]
setblock 440 88 259 minecraft:light[level=12]
setblock 440 88 266 minecraft:light[level=12]
setblock 447 88 231 minecraft:light[level=12]
setblock 447 88 238 minecraft:light[level=12]
setblock 447 88 245 minecraft:light[level=12]
setblock 447 88 252 minecraft:light[level=12]
setblock 447 88 259 minecraft:light[level=12]
setblock 447 88 266 minecraft:light[level=12]
fill 448 88 270 448 99 270 minecraft:black_concrete
setblock 454 88 231 minecraft:light[level=12]
setblock 454 88 238 minecraft:light[level=12]
setblock 454 88 245 minecraft:light[level=12]
setblock 454 88 252 minecraft:light[level=12]
setblock 454 88 259 minecraft:light[level=12]
setblock 454 88 266 minecraft:light[level=12]
fill 455 88 246 455 96 246 minecraft:gray_concrete
fill 457 88 260 461 89 264 minecraft:gray_concrete
setblock 461 88 231 minecraft:light[level=12]
setblock 461 88 238 minecraft:light[level=12]
setblock 461 88 245 minecraft:light[level=12]
setblock 461 88 252 minecraft:light[level=12]
setblock 461 88 259 minecraft:light[level=12]
setblock 461 88 266 minecraft:light[level=12]
fill 462 88 262 463 88 262 minecraft:gray_concrete
setblock 464 88 270 minecraft:sea_lantern
fill 465 88 244 465 134 244 minecraft:black_concrete
fill 465 88 246 465 113 246 minecraft:black_concrete
fill 465 88 250 465 145 250 minecraft:black_concrete
fill 465 88 252 465 154 252 minecraft:black_concrete
setblock 465 88 257 minecraft:black_concrete
fill 465 88 264 465 123 264 minecraft:black_concrete
fill 426 89 270 426 103 270 minecraft:black_concrete
fill 454 89 246 454 96 246 minecraft:gray_concrete
fill 456 89 262 456 90 262 minecraft:orange_concrete
fill 459 89 259 459 90 259 minecraft:orange_concrete
fill 459 89 265 459 90 265 minecraft:orange_concrete
fill 462 89 262 462 90 262 minecraft:orange_concrete
fill 464 89 270 464 133 270 minecraft:black_concrete
setblock 465 89 257 minecraft:sea_lantern
setblock 423 90 244 minecraft:blue_concrete
fill 454 90 247 455 96 247 minecraft:gray_concrete
fill 458 90 261 460 100 263 minecraft:light_gray_concrete
setblock 461 90 270 minecraft:pearlescent_froglight
fill 465 90 257 465 133 257 minecraft:black_concrete
fill 423 91 244 423 101 244 minecraft:black_concrete
setblock 423 91 252 minecraft:ochre_froglight
setblock 423 91 264 minecraft:sea_lantern
fill 453 91 246 453 96 246 minecraft:gray_concrete
fill 454 91 245 455 96 245 minecraft:gray_concrete
fill 456 91 246 456 96 247 minecraft:gray_concrete
fill 457 91 262 457 92 262 minecraft:orange_concrete
fill 459 91 260 459 92 260 minecraft:orange_concrete
fill 459 91 264 459 92 264 minecraft:orange_concrete
fill 461 91 262 461 92 262 minecraft:orange_concrete
fill 461 91 270 461 109 270 minecraft:black_concrete
setblock 463 91 270 minecraft:sea_lantern
setblock 465 91 233 minecraft:ochre_froglight
fill 423 92 252 423 105 252 minecraft:black_concrete
setblock 423 92 264 minecraft:blue_concrete
setblock 435 92 228 minecraft:sea_lantern
setblock 444 92 228 minecraft:ochre_froglight
setblock 446 92 270 minecraft:blue_concrete
fill 453 92 245 453 96 245 minecraft:gray_concrete
fill 453 92 247 453 96 247 minecraft:gray_concrete
fill 454 92 248 455 96 248 minecraft:gray_concrete
fill 456 92 245 456 96 245 minecraft:gray_concrete
fill 463 92 270 463 141 270 minecraft:black_concrete
fill 465 92 233 465 107 234 minecraft:black_concrete
setblock 465 92 235 minecraft:ochre_froglight
setblock 465 92 253 minecraft:blue_concrete
setblock 423 93 264 minecraft:ochre_froglight
fill 435 93 228 435 113 228 minecraft:black_concrete
fill 444 93 228 444 173 228 minecraft:black_concrete
fill 446 93 270 446 135 270 minecraft:black_concrete
fill 452 93 246 452 96 246 minecraft:gray_concrete
fill 453 93 248 453 96 248 minecraft:gray_concrete
fill 454 93 244 455 96 244 minecraft:gray_concrete
fill 456 93 248 456 96 248 minecraft:gray_concrete
fill 457 93 246 457 96 247 minecraft:gray_concrete
setblock 462 93 270 minecraft:magenta_terracotta
setblock 465 93 232 minecraft:ochre_froglight
fill 465 93 235 465 180 235 minecraft:black_concrete
fill 465 93 253 465 125 253 minecraft:black_concrete
setblock 465 93 266 minecraft:sea_lantern
fill 423 94 264 423 101 264 minecraft:black_concrete
setblock 426 94 231 minecraft:light[level=15]
setblock 426 94 238 minecraft:light[level=12]
setblock 426 94 239 minecraft:light[level=15]
setblock 426 94 245 minecraft:light[level=12]
setblock 426 94 247 minecraft:light[level=15]
setblock 426 94 252 minecraft:light[level=12]
setblock 426 94 255 minecraft:light[level=15]
setblock 426 94 259 minecraft:light[level=12]
setblock 426 94 263 minecraft:light[level=15]
setblock 426 94 266 minecraft:light[level=12]
setblock 433 94 231 minecraft:light[level=12]
setblock 433 94 238 minecraft:light[level=12]
setblock 433 94 245 minecraft:light[level=12]
setblock 433 94 252 minecraft:light[level=12]
setblock 433 94 259 minecraft:light[level=12]
setblock 433 94 266 minecraft:light[level=12]
setblock 434 94 231 minecraft:light[level=15]
setblock 434 94 239 minecraft:light[level=15]
setblock 434 94 247 minecraft:light[level=15]
setblock 434 94 255 minecraft:light[level=15]
setblock 434 94 263 minecraft:light[level=15]
setblock 440 94 231 minecraft:light[level=12]
setblock 440 94 238 minecraft:light[level=12]
setblock 440 94 245 minecraft:light[level=12]
setblock 440 94 252 minecraft:light[level=12]
setblock 440 94 259 minecraft:light[level=12]
setblock 440 94 266 minecraft:light[level=12]
setblock 442 94 231 minecraft:light[level=15]
setblock 442 94 239 minecraft:light[level=15]
setblock 442 94 247 minecraft:light[level=15]
setblock 442 94 255 minecraft:light[level=15]
setblock 442 94 263 minecraft:light[level=15]
setblock 445 94 228 minecraft:pearlescent_froglight
setblock 447 94 231 minecraft:light[level=12]
setblock 447 94 238 minecraft:light[level=12]
setblock 447 94 245 minecraft:light[level=12]
setblock 447 94 259 minecraft:light[level=12]
setblock 447 94 266 minecraft:light[level=12]
setblock 450 94 231 minecraft:light[level=15]
setblock 450 94 239 minecraft:light[level=15]
setblock 450 94 247 minecraft:light[level=15]
setblock 450 94 255 minecraft:light[level=15]
setblock 450 94 263 minecraft:light[level=15]
fill 452 94 245 452 96 245 minecraft:gray_concrete
fill 452 94 247 452 96 247 minecraft:gray_concrete
fill 453 94 244 453 96 244 minecraft:gray_concrete
setblock 454 94 231 minecraft:light[level=12]
setblock 454 94 238 minecraft:light[level=12]
fill 454 94 249 456 96 249 minecraft:gray_concrete
setblock 454 94 252 minecraft:light[level=12]
setblock 454 94 259 minecraft:light[level=12]
setblock 454 94 266 minecraft:light[level=12]
fill 456 94 244 456 96 244 minecraft:gray_concrete
fill 457 94 245 457 96 245 minecraft:gray_concrete
fill 457 94 248 457 96 248 minecraft:gray_concrete
setblock 458 94 231 minecraft:light[level=15]
setblock 458 94 239 minecraft:light[level=15]
setblock 458 94 247 minecraft:light[level=15]
setblock 458 94 255 minecraft:light[level=15]
setblock 461 94 231 minecraft:light[level=12]
setblock 461 94 238 minecraft:light[level=12]
setblock 461 94 245 minecraft:light[level=12]
setblock 461 94 252 minecraft:light[level=12]
setblock 461 94 259 minecraft:light[level=12]
setblock 461 94 266 minecraft:light[level=12]
setblock 462 94 228 minecraft:pearlescent_froglight
fill 462 94 270 462 129 270 minecraft:black_concrete
fill 465 94 232 465 136 232 minecraft:black_concrete
fill 465 94 266 465 107 266 minecraft:black_concrete
setblock 435 95 270 minecraft:purple_terracotta
fill 445 95 228 445 237 228 minecraft:black_concrete
fill 452 95 244 452 96 244 minecraft:gray_concrete
fill 452 95 248 452 96 248 minecraft:gray_concrete
fill 453 95 249 453 96 249 minecraft:gray_concrete
fill 454 95 243 455 96 243 minecraft:gray_concrete
fill 457 95 244 457 96 244 minecraft:gray_concrete
fill 458 95 246 458 96 247 minecraft:gray_concrete
fill 462 95 228 462 133 228 minecraft:black_concrete
setblock 463 95 228 minecraft:pearlescent_froglight
setblock 465 95 248 minecraft:ochre_froglight
setblock 423 96 250 minecraft:purple_terracotta
setblock 423 96 255 minecraft:blue_concrete
setblock 423 96 263 minecraft:sea_lantern
fill 435 96 270 435 99 270 minecraft:black_concrete
setblock 438 96 228 minecraft:ochre_froglight
setblock 450 96 270 minecraft:sea_lantern
fill 451 96 245 451 96 248 minecraft:gray_concrete
setblock 452 96 249 minecraft:gray_concrete
setblock 453 96 243 minecraft:gray_concrete
fill 454 96 250 456 96 250 minecraft:gray_concrete
setblock 456 96 243 minecraft:gray_concrete
setblock 457 96 249 minecraft:gray_concrete
setblock 458 96 245 minecraft:gray_concrete
setblock 458 96 248 minecraft:gray_concrete
fill 463 96 228 463 137 228 minecraft:black_concrete
setblock 465 96 231 minecraft:purple_terracotta
fill 465 96 248 465 148 248 minecraft:black_concrete
setblock 423 97 236 minecraft:purple_concrete
fill 423 97 250 423 182 250 minecraft:black_concrete
fill 423 97 255 423 170 255 minecraft:black_concrete
fill 423 97 263 423 220 263 minecraft:black_concrete
setblock 423 97 267 minecraft:sea_lantern
fill 438 97 228 438 144 228 minecraft:black_concrete
setblock 441 97 228 minecraft:white_concrete
fill 450 97 270 450 132 270 minecraft:black_concrete
fill 454 97 246 455 98 247 minecraft:pearlescent_froglight
fill 465 97 231 465 171 231 minecraft:black_concrete
fill 423 98 236 423 114 236 minecraft:black_concrete
setblock 423 98 267 minecraft:pearlescent_froglight
fill 441 98 228 441 115 228 minecraft:black_concrete
fill 448 98 228 448 161 228 minecraft:black_concrete
setblock 449 98 228 minecraft:pearlescent_froglight
setblock 423 99 246 minecraft:ochre_froglight
setblock 423 99 248 minecraft:white_concrete
fill 423 99 267 423 103 267 minecraft:black_concrete
fill 449 99 228 449 191 228 minecraft:black_concrete
fill 454 99 246 455 99 246 minecraft:pearlescent_froglight
setblock 455 99 228 minecraft:ochre_froglight
setblock 465 99 251 minecraft:purple_terracotta
setblock 465 99 261 minecraft:pearlescent_froglight
fill 423 100 246 423 190 246 minecraft:black_concrete
fill 423 100 248 423 158 248 minecraft:black_concrete
setblock 423 100 257 minecraft:white_concrete
setblock 423 100 269 minecraft:pearlescent_froglight
setblock 426 100 231 minecraft:light[level=12]
setblock 426 100 238 minecraft:light[level=12]
setblock 426 100 245 minecraft:light[level=12]
setblock 426 100 252 minecraft:light[level=12]
setblock 426 100 259 minecraft:light[level=12]
setblock 426 100 266 minecraft:light[level=12]
setblock 433 100 231 minecraft:light[level=12]
setblock 433 100 238 minecraft:light[level=12]
setblock 433 100 245 minecraft:light[level=12]
setblock 433 100 252 minecraft:light[level=12]
setblock 433 100 259 minecraft:light[level=12]
setblock 433 100 266 minecraft:light[level=12]
setblock 435 100 270 minecraft:purple_concrete
fill 438 100 261 439 101 262 minecraft:gray_concrete
setblock 440 100 231 minecraft:light[level=12]
setblock 440 100 238 minecraft:light[level=12]
setblock 440 100 245 minecraft:light[level=12]
setblock 440 100 252 minecraft:light[level=12]
setblock 440 100 259 minecraft:light[level=12]
setblock 440 100 266 minecraft:light[level=12]
setblock 447 100 231 minecraft:light[level=12]
setblock 447 100 238 minecraft:light[level=12]
setblock 447 100 245 minecraft:light[level=12]
setblock 447 100 259 minecraft:light[level=12]
setblock 447 100 266 minecraft:light[level=12]
setblock 448 100 270 minecraft:sea_lantern
setblock 454 100 231 minecraft:light[level=12]
setblock 454 100 238 minecraft:light[level=12]
setblock 454 100 245 minecraft:light[level=12]
setblock 454 100 252 minecraft:light[level=12]
setblock 454 100 259 minecraft:light[level=12]
setblock 454 100 266 minecraft:light[level=12]
setblock 454 100 270 minecraft:white_concrete
fill 455 100 228 455 118 228 minecraft:black_concrete
setblock 455 100 246 minecraft:pearlescent_froglight
setblock 461 100 231 minecraft:light[level=12]
setblock 461 100 238 minecraft:light[level=12]
setblock 461 100 245 minecraft:light[level=12]
setblock 461 100 252 minecraft:light[level=12]
setblock 461 100 259 minecraft:light[level=12]
setblock 461 100 266 minecraft:light[level=12]
fill 465 100 251 465 135 251 minecraft:black_concrete
fill 465 100 261 465 162 261 minecraft:black_concrete
fill 423 101 257 423 105 257 minecraft:black_concrete
fill 423 101 269 423 114 269 minecraft:black_concrete
setblock 426 101 231 minecraft:light[level=15]
setblock 426 101 239 minecraft:light[level=15]
setblock 426 101 247 minecraft:light[level=15]
setblock 426 101 255 minecraft:light[level=15]
setblock 426 101 263 minecraft:light[level=15]
setblock 431 101 228 minecraft:sea_lantern
setblock 434 101 231 minecraft:light[level=15]
setblock 434 101 239 minecraft:light[level=15]
setblock 434 101 247 minecraft:light[level=15]
setblock 434 101 255 minecraft:light[level=15]
setblock 434 101 263 minecraft:light[level=15]
fill 435 101 270 435 248 270 minecraft:black_concrete
setblock 442 101 231 minecraft:light[level=15]
setblock 442 101 239 minecraft:light[level=15]
setblock 442 101 247 minecraft:light[level=15]
setblock 442 101 255 minecraft:light[level=15]
setblock 442 101 263 minecraft:light[level=15]
setblock 446 101 228 minecraft:white_concrete
fill 448 101 270 448 116 270 minecraft:black_concrete
setblock 450 101 231 minecraft:light[level=15]
setblock 450 101 239 minecraft:light[level=15]
setblock 450 101 247 minecraft:light[level=15]
setblock 450 101 255 minecraft:light[level=15]
setblock 450 101 263 minecraft:light[level=15]
fill 454 101 270 454 123 270 minecraft:black_concrete
setblock 456 101 228 minecraft:white_concrete
setblock 458 101 231 minecraft:light[level=15]
setblock 458 101 239 minecraft:light[level=15]
setblock 458 101 247 minecraft:light[level=15]
setblock 458 101 255 minecraft:light[level=15]
fill 458 101 261 460 101 263 minecraft:orange_concrete
setblock 465 101 242 minecraft:ochre_froglight
setblock 423 102 244 minecraft:pearlescent_froglight
setblock 423 102 264 minecraft:white_concrete
fill 431 102 228 431 157 228 minecraft:black_concrete
fill 446 102 228 446 106 228 minecraft:black_concrete
fill 456 102 228 456 140 228 minecraft:black_concrete
fill 458 102 262 460 102 262 minecraft:orange_concrete
setblock 459 102 261 minecraft:orange_concrete
setblock 459 102 263 minecraft:orange_concrete
fill 465 102 242 465 291 242 minecraft:black_concrete
fill 423 103 244 423 152 244 minecraft:black_concrete
fill 423 103 264 423 122 264 minecraft:black_concrete
setblock 438 103 270 minecraft:white_concrete
fill 459 103 262 459 104 262 minecraft:orange_concrete
setblock 423 104 267 minecraft:white_concrete
setblock 426 104 270 minecraft:purple_terracotta
setblock 438 104 270 minecraft:black_concrete
setblock 453 104 270 minecraft:sea_lantern
setblock 465 104 240 minecraft:white_concrete
setblock 423 105 239 minecraft:magenta_terracotta
setblock 423 105 243 minecraft:white_concrete
fill 423 105 267 423 139 267 minecraft:black_concrete
fill 426 105 270 426 142 270 minecraft:black_concrete
setblock 438 105 270 minecraft:ochre_froglight
setblock 453 105 270 minecraft:white_concrete
fill 465 105 240 465 254 240 minecraft:black_concrete
setblock 465 105 243 minecraft:pearlescent_froglight
setblock 465 105 265 minecraft:white_concrete
setblock 465 105 268 minecraft:sea_lantern
setblock 423 106 233 minecraft:ochre_froglight
fill 423 106 239 423 140 239 minecraft:black_concrete
setblock 423 106 243 minecraft:black_concrete
setblock 423 106 252 minecraft:ochre_froglight
setblock 423 106 257 minecraft:ochre_froglight
fill 424 106 253 430 106 253 minecraft:gray_concrete
setblock 426 106 231 minecraft:light[level=12]
setblock 426 106 238 minecraft:light[level=12]
setblock 426 106 245 minecraft:light[level=12]
fill 426 106 251 430 107 252 minecraft:gray_concrete
fill 426 106 254 430 107 255 minecraft:gray_concrete
setblock 426 106 259 minecraft:light[level=12]
setblock 426 106 266 minecraft:light[level=12]
setblock 427 106 228 minecraft:white_concrete
setblock 433 106 231 minecraft:light[level=12]
setblock 433 106 238 minecraft:light[level=12]
setblock 433 106 245 minecraft:light[level=12]
setblock 433 106 252 minecraft:light[level=12]
setblock 433 106 259 minecraft:light[level=12]
setblock 433 106 266 minecraft:light[level=12]
fill 438 106 270 438 129 270 minecraft:black_concrete
setblock 440 106 231 minecraft:light[level=12]
setblock 440 106 238 minecraft:light[level=12]
setblock 440 106 245 minecraft:light[level=12]
setblock 440 106 252 minecraft:light[level=12]
setblock 440 106 259 minecraft:light[level=12]
setblock 440 106 266 minecraft:light[level=12]
setblock 447 106 231 minecraft:light[level=12]
setblock 447 106 238 minecraft:light[level=12]
setblock 447 106 245 minecraft:light[level=12]
setblock 447 106 259 minecraft:light[level=12]
setblock 447 106 266 minecraft:light[level=12]
setblock 449 106 270 minecraft:white_concrete
fill 453 106 270 453 118 270 minecraft:black_concrete
setblock 454 106 231 minecraft:light[level=12]
setblock 454 106 238 minecraft:light[level=12]
setblock 454 106 245 minecraft:light[level=12]
setblock 454 106 252 minecraft:light[level=12]
setblock 454 106 259 minecraft:light[level=12]
setblock 454 106 266 minecraft:light[level=12]
setblock 461 106 231 minecraft:light[level=12]
setblock 461 106 238 minecraft:light[level=12]
setblock 461 106 245 minecraft:light[level=12]
setblock 461 106 252 minecraft:light[level=12]
setblock 461 106 259 minecraft:light[level=12]
setblock 461 106 266 minecraft:light[level=12]
fill 465 106 243 465 110 243 minecraft:black_concrete
fill 465 106 265 465 127 265 minecraft:black_concrete
fill 465 106 268 465 137 268 minecraft:black_concrete
fill 423 107 233 423 205 233 minecraft:black_concrete
setblock 423 107 243 minecraft:purple_terracotta
fill 423 107 252 423 143 252 minecraft:black_concrete
fill 423 107 257 423 116 257 minecraft:black_concrete
fill 426 107 253 430 107 253 minecraft:gray_concrete
fill 427 107 228 427 140 228 minecraft:black_concrete
setblock 446 107 228 minecraft:white_concrete
fill 449 107 270 449 143 270 minecraft:black_concrete
setblock 451 107 270 minecraft:ochre_froglight
fill 452 107 254 452 108 254 minecraft:end_stone
setblock 423 108 230 minecraft:sea_lantern
setblock 423 108 234 minecraft:purple_concrete
setblock 423 108 238 minecraft:ochre_froglight
fill 423 108 243 423 150 243 minecraft:black_concrete
setblock 423 108 259 minecraft:ochre_froglight
setblock 426 108 231 minecraft:light[level=15]
setblock 426 108 239 minecraft:light[level=15]
setblock 426 108 247 minecraft:light[level=15]
setblock 426 108 255 minecraft:light[level=15]
setblock 426 108 263 minecraft:light[level=15]
setblock 434 108 231 minecraft:light[level=15]
setblock 434 108 239 minecraft:light[level=15]
setblock 434 108 247 minecraft:light[level=15]
setblock 434 108 255 minecraft:light[level=15]
setblock 434 108 263 minecraft:light[level=15]
setblock 442 108 231 minecraft:light[level=15]
setblock 442 108 239 minecraft:light[level=15]
setblock 442 108 247 minecraft:light[level=15]
setblock 442 108 255 minecraft:light[level=15]
setblock 442 108 263 minecraft:light[level=15]
fill 446 108 228 446 155 228 minecraft:black_concrete
setblock 450 108 231 minecraft:light[level=15]
setblock 450 108 239 minecraft:light[level=15]
setblock 450 108 247 minecraft:light[level=15]
setblock 450 108 255 minecraft:light[level=15]
setblock 450 108 263 minecraft:light[level=15]
fill 451 108 270 451 118 270 minecraft:black_concrete
setblock 458 108 231 minecraft:light[level=15]
setblock 458 108 239 minecraft:light[level=15]
setblock 458 108 247 minecraft:light[level=15]
setblock 458 108 255 minecraft:light[level=15]
setblock 458 108 263 minecraft:light[level=15]
setblock 459 108 228 minecraft:blue_concrete
setblock 465 108 230 minecraft:purple_concrete
setblock 465 108 233 minecraft:pearlescent_froglight
fill 465 108 234 465 133 234 minecraft:black_concrete
setblock 465 108 238 minecraft:magenta_terracotta
setblock 465 108 266 minecraft:ochre_froglight
setblock 465 108 269 minecraft:pearlescent_froglight
fill 423 109 230 423 153 230 minecraft:black_concrete
fill 423 109 234 423 128 234 minecraft:black_concrete
fill 423 109 238 423 110 238 minecraft:black_concrete
fill 423 109 259 423 113 259 minecraft:black_concrete
setblock 426 109 228 minecraft:pearlescent_froglight
fill 428 109 253 428 116 253 minecraft:orange_concrete
setblock 428 109 270 minecraft:purple_concrete
setblock 429 109 270 minecraft:sea_lantern
setblock 453 109 228 minecraft:sea_lantern
setblock 456 109 270 minecraft:ochre_froglight
fill 459 109 228 459 158 228 minecraft:black_concrete
fill 465 109 230 465 116 230 minecraft:black_concrete
fill 465 109 233 465 112 233 minecraft:black_concrete
setblock 465 109 238 minecraft:black_concrete
fill 465 109 266 465 142 266 minecraft:black_concrete
setblock 465 109 269 minecraft:ochre_froglight
fill 426 110 228 426 111 228 minecraft:black_concrete
fill 426 110 252 427 115 254 minecraft:orange_concrete
fill 427 110 251 429 115 251 minecraft:orange_concrete
fill 427 110 255 429 115 255 minecraft:orange_concrete
fill 428 110 252 430 115 252 minecraft:orange_concrete
fill 428 110 254 430 115 254 minecraft:orange_concrete
fill 428 110 270 429 176 270 minecraft:black_concrete
fill 429 110 253 430 115 253 minecraft:orange_concrete
fill 453 110 228 453 161 228 minecraft:black_concrete
fill 456 110 270 456 136 270 minecraft:black_concrete
setblock 461 110 228 minecraft:purple_concrete
setblock 461 110 270 minecraft:sea_lantern
setblock 465 110 238 minecraft:blue_concrete
fill 465 110 269 465 122 269 minecraft:black_concrete
setblock 423 111 238 minecraft:ochre_froglight
fill 425 111 252 425 114 254 minecraft:orange_concrete
fill 426 111 251 426 114 251 minecraft:orange_concrete
fill 426 111 255 426 114 255 minecraft:orange_concrete
fill 427 111 250 429 114 250 minecraft:orange_concrete
fill 427 111 256 429 114 256 minecraft:orange_concrete
fill 430 111 251 430 114 251 minecraft:orange_concrete
fill 430 111 255 430 114 255 minecraft:orange_concrete
fill 431 111 252 431 114 254 minecraft:orange_concrete
fill 439 111 259 441 112 259 minecraft:gray_concrete
fill 440 111 260 441 112 260 minecraft:gray_concrete
setblock 442 111 228 minecraft:pearlescent_froglight
setblock 458 111 228 minecraft:magenta_terracotta
setblock 461 111 228 minecraft:black_concrete
fill 461 111 270 461 112 270 minecraft:black_concrete
fill 465 111 238 465 117 238 minecraft:black_concrete
setblock 465 111 243 minecraft:sea_lantern
fill 423 112 238 423 123 238 minecraft:black_concrete
setblock 423 112 240 minecraft:purple_concrete
setblock 426 112 228 minecraft:ochre_froglight
setblock 426 112 231 minecraft:light[level=12]
setblock 426 112 238 minecraft:light[level=12]
setblock 426 112 245 minecraft:light[level=12]
setblock 426 112 259 minecraft:light[level=12]
setblock 426 112 266 minecraft:light[level=12]
setblock 433 112 231 minecraft:light[level=12]
setblock 433 112 238 minecraft:light[level=12]
setblock 433 112 245 minecraft:light[level=12]
setblock 433 112 252 minecraft:light[level=12]
setblock 433 112 259 minecraft:light[level=12]
setblock 433 112 266 minecraft:light[level=12]
setblock 440 112 231 minecraft:light[level=12]
setblock 440 112 238 minecraft:light[level=12]
setblock 440 112 245 minecraft:light[level=12]
setblock 440 112 252 minecraft:light[level=12]
setblock 440 112 266 minecraft:light[level=12]
fill 442 112 228 442 158 228 minecraft:black_concrete
setblock 447 112 231 minecraft:light[level=12]
setblock 447 112 238 minecraft:light[level=12]
setblock 447 112 245 minecraft:light[level=12]
setblock 447 112 259 minecraft:light[level=12]
setblock 447 112 266 minecraft:light[level=12]
setblock 454 112 231 minecraft:light[level=12]
setblock 454 112 238 minecraft:light[level=12]
setblock 454 112 245 minecraft:light[level=12]
setblock 454 112 252 minecraft:light[level=12]
setblock 454 112 259 minecraft:light[level=12]
setblock 454 112 266 minecraft:light[level=12]
fill 458 112 228 458 129 228 minecraft:black_concrete
fill 460 112 267 460 113 268 minecraft:light_blue_concrete
setblock 461 112 228 minecraft:sea_lantern
setblock 461 112 231 minecraft:light[level=12]
setblock 461 112 238 minecraft:light[level=12]
setblock 461 112 245 minecraft:light[level=12]
setblock 461 112 252 minecraft:light[level=12]
setblock 461 112 259 minecraft:light[level=12]
fill 461 112 266 464 112 267 minecraft:light_blue_concrete
setblock 461 112 268 minecraft:white_concrete
fill 461 112 269 464 112 269 minecraft:light_blue_concrete
setblock 462 112 265 minecraft:white_concrete
fill 462 112 268 462 114 268 minecraft:light_blue_concrete
fill 463 112 265 463 114 265 minecraft:light_blue_concrete
setblock 463 112 268 minecraft:white_concrete
fill 464 112 268 464 114 268 minecraft:light_blue_concrete
setblock 465 112 229 minecraft:white_concrete
fill 465 112 243 465 115 243 minecraft:black_concrete
setblock 465 112 262 minecraft:pearlescent_froglight
fill 423 113 240 423 228 240 minecraft:black_concrete
setblock 423 113 261 minecraft:white_concrete
fill 426 113 228 426 115 228 minecraft:black_concrete
fill 459 113 265 459 114 268 minecraft:light_blue_concrete
setblock 459 113 269 minecraft:white_concrete
fill 460 113 264 462 113 265 minecraft:light_blue_concrete
setblock 460 113 266 minecraft:white_concrete
fill 460 113 269 460 115 269 minecraft:light_blue_concrete
fill 461 113 228 461 114 228 minecraft:black_concrete
fill 461 113 266 461 115 268 minecraft:light_blue_concrete
setblock 461 113 269 minecraft:white_concrete
setblock 461 113 270 minecraft:ochre_froglight
setblock 462 113 266 minecraft:white_concrete
fill 462 113 267 464 113 267 minecraft:light_blue_concrete
fill 462 113 269 462 115 269 minecraft:light_blue_concrete
fill 463 113 264 464 113 264 minecraft:light_blue_concrete
fill 463 113 266 463 115 266 minecraft:light_blue_concrete
fill 463 113 268 463 117 268 minecraft:light_blue_concrete
setblock 463 113 269 minecraft:white_concrete
fill 464 113 265 464 117 265 minecraft:light_blue_concrete
setblock 464 113 266 minecraft:white_concrete
fill 464 113 269 464 115 269 minecraft:light_blue_concrete
fill 465 113 229 465 191 229 minecraft:black_concrete
setblock 465 113 233 minecraft:pearlescent_froglight
fill 465 113 262 465 130 262 minecraft:black_concrete
setblock 423 114 259 minecraft:white_concrete
fill 423 114 261 423 117 261 minecraft:black_concrete
setblock 435 114 228 minecraft:magenta_terracotta
fill 450 114 259 451 116 260 minecraft:cobbled_deepslate
fill 458 114 265 458 117 266 minecraft:light_blue_concrete
setblock 458 114 267 minecraft:white_concrete
fill 458 114 268 458 114 269 minecraft:light_blue_concrete
setblock 459 114 264 minecraft:white_concrete
fill 459 114 269 459 118 269 minecraft:light_blue_concrete
fill 460 114 263 460 115 266 minecraft:light_blue_concrete
setblock 460 114 267 minecraft:white_concrete
setblock 460 114 268 minecraft:light_blue_concrete
fill 461 114 263 464 115 263 minecraft:light_blue_concrete
setblock 461 114 264 minecraft:white_concrete
fill 461 114 265 462 114 265 minecraft:light_blue_concrete
fill 461 114 269 461 118 269 minecraft:light_blue_concrete
fill 461 114 270 461 150 270 minecraft:black_concrete
fill 462 114 264 462 116 264 minecraft:light_blue_concrete
fill 462 114 266 462 118 266 minecraft:light_blue_concrete
setblock 462 114 267 minecraft:white_concrete
setblock 463 114 264 minecraft:white_concrete
fill 463 114 267 463 116 267 minecraft:light_blue_concrete
fill 463 114 269 463 118 269 minecraft:light_blue_concrete
fill 464 114 264 464 116 264 minecraft:light_blue_concrete
fill 464 114 266 464 118 266 minecraft:light_blue_concrete
setblock 464 114 267 minecraft:white_concrete
fill 465 114 233 465 150 233 minecraft:black_concrete
setblock 465 114 246 minecraft:sea_lantern
setblock 423 115 236 minecraft:white_concrete
fill 423 115 259 423 150 259 minecraft:black_concrete
setblock 423 115 266 minecraft:sea_lantern
setblock 423 115 269 minecraft:purple_concrete
setblock 426 115 231 minecraft:light[level=15]
setblock 426 115 239 minecraft:light[level=15]
setblock 426 115 247 minecraft:light[level=15]
setblock 426 115 255 minecraft:light[level=15]
setblock 426 115 263 minecraft:light[level=15]
setblock 430 115 270 minecraft:ochre_froglight
setblock 434 115 228 minecraft:sea_lantern
setblock 434 115 231 minecraft:light[level=15]
setblock 434 115 239 minecraft:light[level=15]
setblock 434 115 247 minecraft:light[level=15]
setblock 434 115 255 minecraft:light[level=15]
setblock 434 115 263 minecraft:light[level=15]
fill 435 115 228 435 193 228 minecraft:black_concrete
setblock 442 115 231 minecraft:light[level=15]
setblock 442 115 239 minecraft:light[level=15]
setblock 442 115 247 minecraft:light[level=15]
setblock 442 115 255 minecraft:light[level=15]
setblock 442 115 263 minecraft:light[level=15]
fill 449 115 259 449 115 260 minecraft:cobbled_deepslate
setblock 450 115 231 minecraft:light[level=15]
setblock 450 115 239 minecraft:light[level=15]
setblock 450 115 247 minecraft:light[level=15]
setblock 450 115 255 minecraft:light[level=15]
setblock 450 115 263 minecraft:light[level=15]
fill 451 115 258 451 116 258 minecraft:cobbled_deepslate
fill 451 115 261 452 115 261 minecraft:cobbled_deepslate
fill 452 115 259 452 116 260 minecraft:cobbled_deepslate
setblock 457 115 265 minecraft:white_concrete
fill 457 115 266 457 115 269 minecraft:light_blue_concrete
setblock 458 115 231 minecraft:light[level=15]
setblock 458 115 239 minecraft:light[level=15]
setblock 458 115 247 minecraft:light[level=15]
setblock 458 115 255 minecraft:light[level=15]
setblock 458 115 263 minecraft:light[level=15]
fill 458 115 264 459 116 264 minecraft:light_blue_concrete
fill 458 115 267 460 116 267 minecraft:light_blue_concrete
setblock 458 115 268 minecraft:white_concrete
setblock 458 115 269 minecraft:light_blue_concrete
fill 459 115 263 459 118 263 minecraft:light_blue_concrete
setblock 459 115 265 minecraft:white_concrete
setblock 459 115 266 minecraft:light_blue_concrete
fill 459 115 268 459 117 268 minecraft:light_blue_concrete
setblock 460 115 228 minecraft:purple_concrete
setblock 460 115 262 minecraft:white_concrete
setblock 460 115 268 minecraft:white_concrete
setblock 460 115 270 minecraft:pearlescent_froglight
setblock 461 115 228 minecraft:sea_lantern
fill 461 115 262 461 117 262 minecraft:light_blue_concrete
fill 461 115 264 461 119 264 minecraft:light_blue_concrete
setblock 461 115 265 minecraft:white_concrete
setblock 462 115 262 minecraft:white_concrete
fill 462 115 265 462 117 265 minecraft:light_blue_concrete
fill 462 115 267 462 119 267 minecraft:light_blue_concrete
setblock 462 115 268 minecraft:white_concrete
fill 463 115 262 463 117 262 minecraft:light_blue_concrete
fill 463 115 264 463 119 264 minecraft:light_blue_concrete
setblock 463 115 265 minecraft:white_concrete
setblock 464 115 262 minecraft:white_concrete
fill 464 115 267 464 119 267 minecraft:light_blue_concrete
setblock 464 115 268 minecraft:white_concrete
fill 465 115 246 465 121 246 minecraft:black_concrete
fill 423 116 236 423 186 236 minecraft:black_concrete
fill 423 116 266 423 175 266 minecraft:black_concrete
fill 423 116 269 423 293 269 minecraft:black_concrete
setblock 426 116 228 minecraft:pearlescent_froglight
fill 430 116 270 430 125 270 minecraft:black_concrete
fill 434 116 228 434 129 228 minecraft:black_concrete
setblock 441 116 228 minecraft:white_concrete
setblock 449 116 260 minecraft:cobbled_deepslate
fill 450 116 261 451 116 261 minecraft:cobbled_deepslate
fill 456 116 267 457 116 268 minecraft:light_blue_concrete
fill 457 116 264 457 119 265 minecraft:light_blue_concrete
setblock 457 116 266 minecraft:white_concrete
fill 457 116 269 457 118 269 minecraft:light_blue_concrete
setblock 457 116 270 minecraft:ochre_froglight
setblock 458 116 263 minecraft:white_concrete
fill 458 116 268 458 120 268 minecraft:light_blue_concrete
setblock 458 116 269 minecraft:white_concrete
fill 459 116 262 460 117 262 minecraft:light_blue_concrete
fill 459 116 265 461 117 265 minecraft:light_blue_concrete
setblock 459 116 266 minecraft:white_concrete
fill 460 116 228 461 130 228 minecraft:black_concrete
setblock 460 116 263 minecraft:white_concrete
setblock 460 116 264 minecraft:light_blue_concrete
fill 460 116 266 460 118 266 minecraft:light_blue_concrete
fill 460 116 268 462 117 268 minecraft:light_blue_concrete
setblock 460 116 269 minecraft:white_concrete
fill 460 116 270 460 125 270 minecraft:black_concrete
fill 461 116 263 461 118 263 minecraft:light_blue_concrete
setblock 461 116 266 minecraft:white_concrete
setblock 461 116 267 minecraft:light_blue_concrete
fill 462 116 261 462 119 262 minecraft:light_blue_concrete
setblock 462 116 263 minecraft:white_concrete
setblock 462 116 269 minecraft:white_concrete
setblock 463 116 261 minecraft:light_blue_concrete
fill 463 116 263 463 118 263 minecraft:light_blue_concrete
fill 463 116 265 463 120 265 minecraft:light_blue_concrete
setblock 463 116 266 minecraft:white_concrete
fill 464 116 262 464 120 262 minecraft:light_blue_concrete
setblock 464 116 263 minecraft:white_concrete
fill 464 116 268 464 120 268 minecraft:light_blue_concrete
setblock 464 116 269 minecraft:white_concrete
setblock 465 116 243 minecraft:sea_lantern
setblock 465 116 247 minecraft:magenta_terracotta
setblock 465 116 255 minecraft:ochre_froglight
setblock 423 117 257 minecraft:ochre_froglight
fill 426 117 228 426 154 228 minecraft:black_concrete
fill 441 117 228 441 124 228 minecraft:black_concrete
setblock 448 117 270 minecraft:pearlescent_froglight
fill 450 117 259 450 117 260 minecraft:cobbled_deepslate
fill 456 117 266 456 118 269 minecraft:light_blue_concrete
fill 457 117 266 457 121 266 minecraft:light_blue_concrete
setblock 457 117 267 minecraft:white_concrete
setblock 457 117 268 minecraft:light_blue_concrete
fill 457 117 270 457 164 270 minecraft:black_concrete
fill 458 117 263 458 121 263 minecraft:light_blue_concrete
setblock 458 117 264 minecraft:white_concrete
fill 458 117 267 458 119 267 minecraft:light_blue_concrete
fill 458 117 269 458 121 269 minecraft:light_blue_concrete
fill 459 117 264 459 119 264 minecraft:light_blue_concrete
fill 459 117 266 459 121 266 minecraft:light_blue_concrete
setblock 459 117 267 minecraft:white_concrete
fill 460 117 263 460 121 263 minecraft:light_blue_concrete
setblock 460 117 264 minecraft:white_concrete
fill 460 117 267 460 119 267 minecraft:light_blue_concrete
fill 460 117 269 460 121 269 minecraft:light_blue_concrete
setblock 461 117 261 minecraft:white_concrete
fill 461 117 266 461 121 266 minecraft:light_blue_concrete
setblock 461 117 267 minecraft:white_concrete
fill 462 117 263 462 121 263 minecraft:light_blue_concrete
setblock 462 117 264 minecraft:white_concrete
fill 462 117 269 462 121 269 minecraft:light_blue_concrete
setblock 463 117 261 minecraft:white_concrete
fill 463 117 266 463 121 266 minecraft:light_blue_concrete
setblock 463 117 267 minecraft:white_concrete
fill 464 117 261 464 119 261 minecraft:light_blue_concrete
fill 464 117 263 464 121 263 minecraft:light_blue_concrete
setblock 464 117 264 minecraft:white_concrete
fill 464 117 269 464 121 269 minecraft:light_blue_concrete
setblock 465 117 230 minecraft:pearlescent_froglight
fill 465 117 243 465 142 243 minecraft:black_concrete
fill 465 117 247 465 182 247 minecraft:black_concrete
fill 465 117 255 465 174 255 minecraft:black_concrete
setblock 423 118 242 minecraft:ochre_froglight
setblock 423 118 247 minecraft:white_concrete
fill 423 118 257 423 177 257 minecraft:black_concrete
setblock 423 118 261 minecraft:ochre_froglight
setblock 426 118 231 minecraft:light[level=12]
setblock 426 118 238 minecraft:light[level=12]
setblock 426 118 245 minecraft:light[level=12]
setblock 426 118 252 minecraft:light[level=12]
setblock 426 118 259 minecraft:light[level=12]
setblock 426 118 266 minecraft:light[level=12]
setblock 433 118 231 minecraft:light[level=12]
setblock 433 118 238 minecraft:light[level=12]
setblock 433 118 245 minecraft:light[level=12]
setblock 433 118 252 minecraft:light[level=12]
setblock 433 118 259 minecraft:light[level=12]
setblock 433 118 266 minecraft:light[level=12]
setblock 440 118 231 minecraft:light[level=12]
setblock 440 118 238 minecraft:light[level=12]
setblock 440 118 245 minecraft:light[level=12]
setblock 440 118 252 minecraft:light[level=12]
setblock 440 118 259 minecraft:light[level=12]
setblock 440 118 266 minecraft:light[level=12]
setblock 447 118 231 minecraft:light[level=12]
setblock 447 118 238 minecraft:light[level=12]
setblock 447 118 245 minecraft:light[level=12]
setblock 447 118 259 minecraft:light[level=12]
setblock 447 118 266 minecraft:light[level=12]
fill 448 118 270 448 181 270 minecraft:black_concrete
setblock 454 118 231 minecraft:light[level=12]
setblock 454 118 238 minecraft:light[level=12]
setblock 454 118 245 minecraft:light[level=12]
setblock 454 118 252 minecraft:light[level=12]
setblock 454 118 259 minecraft:light[level=12]
setblock 454 118 266 minecraft:light[level=12]
setblock 456 118 265 minecraft:white_concrete
fill 457 118 267 457 122 267 minecraft:light_blue_concrete
setblock 457 118 268 minecraft:white_concrete
fill 458 118 264 458 122 264 minecraft:light_blue_concrete
setblock 458 118 265 minecraft:white_concrete
setblock 458 118 266 minecraft:light_blue_concrete
setblock 459 118 262 minecraft:white_concrete
fill 459 118 265 459 120 265 minecraft:light_blue_concrete
fill 459 118 267 459 122 267 minecraft:light_blue_concrete
setblock 459 118 268 minecraft:white_concrete
fill 460 118 261 460 119 262 minecraft:light_blue_concrete
fill 460 118 264 460 122 264 minecraft:light_blue_concrete
setblock 460 118 265 minecraft:white_concrete
fill 460 118 268 460 120 268 minecraft:light_blue_concrete
setblock 461 118 231 minecraft:light[level=12]
setblock 461 118 238 minecraft:light[level=12]
setblock 461 118 245 minecraft:light[level=12]
setblock 461 118 252 minecraft:light[level=12]
setblock 461 118 259 minecraft:light[level=12]
fill 461 118 261 461 120 261 minecraft:light_blue_concrete
setblock 461 118 262 minecraft:white_concrete
fill 461 118 265 461 120 265 minecraft:light_blue_concrete
fill 461 118 267 461 122 267 minecraft:light_blue_concrete
setblock 461 118 268 minecraft:white_concrete
fill 462 118 264 462 122 264 minecraft:light_blue_concrete
setblock 462 118 265 minecraft:white_concrete
fill 462 118 268 462 120 268 minecraft:light_blue_concrete
fill 463 118 261 463 121 261 minecraft:light_blue_concrete
setblock 463 118 262 minecraft:white_concrete
fill 463 118 267 463 122 267 minecraft:light_blue_concrete
setblock 463 118 268 minecraft:white_concrete
fill 464 118 264 464 122 264 minecraft:light_blue_concrete
setblock 464 118 265 minecraft:white_concrete
fill 465 118 230 465 138 230 minecraft:black_concrete
setblock 465 118 238 minecraft:magenta_terracotta
fill 423 119 242 423 273 242 minecraft:black_concrete
fill 423 119 247 423 181 247 minecraft:black_concrete
fill 423 119 261 423 144 261 minecraft:black_concrete
fill 435 119 239 435 120 239 minecraft:gray_concrete
setblock 451 119 270 minecraft:ochre_froglight
setblock 453 119 270 minecraft:pearlescent_froglight
setblock 455 119 228 minecraft:ochre_froglight
setblock 456 119 265 minecraft:light_blue_concrete
setblock 456 119 266 minecraft:white_concrete
fill 456 119 267 456 119 269 minecraft:light_blue_concrete
fill 457 119 268 457 122 268 minecraft:light_blue_concrete
setblock 457 119 269 minecraft:white_concrete
fill 458 119 265 458 123 265 minecraft:light_blue_concrete
setblock 458 119 266 minecraft:white_concrete
fill 459 119 262 459 121 262 minecraft:light_blue_concrete
setblock 459 119 263 minecraft:white_concrete
fill 459 119 268 459 123 268 minecraft:light_blue_concrete
setblock 459 119 269 minecraft:white_concrete
fill 460 119 265 460 123 265 minecraft:light_blue_concrete
setblock 460 119 266 minecraft:white_concrete
fill 461 119 262 461 122 262 minecraft:light_blue_concrete
setblock 461 119 263 minecraft:white_concrete
fill 461 119 268 461 123 268 minecraft:light_blue_concrete
setblock 461 119 269 minecraft:white_concrete
fill 462 119 265 462 123 265 minecraft:light_blue_concrete
setblock 462 119 266 minecraft:white_concrete
fill 463 119 262 463 122 262 minecraft:light_blue_concrete
setblock 463 119 263 minecraft:white_concrete
fill 463 119 268 463 123 268 minecraft:light_blue_concrete
setblock 463 119 269 minecraft:white_concrete
fill 464 119 265 464 123 265 minecraft:light_blue_concrete
setblock 464 119 266 minecraft:white_concrete
fill 465 119 238 465 147 238 minecraft:black_concrete
setblock 451 120 270 minecraft:black_concrete
fill 453 120 270 453 130 270 minecraft:black_concrete
setblock 454 120 228 minecraft:ochre_froglight
fill 455 120 228 455 181 228 minecraft:black_concrete
setblock 456 120 266 minecraft:light_blue_concrete
setblock 456 120 267 minecraft:white_concrete
fill 456 120 268 456 120 269 minecraft:light_blue_concrete
setblock 457 120 264 minecraft:white_concrete
setblock 457 120 265 minecraft:light_blue_concrete
fill 457 120 269 457 122 269 minecraft:light_blue_concrete
fill 458 120 266 458 123 266 minecraft:light_blue_concrete
setblock 458 120 267 minecraft:white_concrete
fill 459 120 263 459 122 263 minecraft:light_blue_concrete
setblock 459 120 264 minecraft:white_concrete
fill 459 120 269 459 124 269 minecraft:light_blue_concrete
setblock 460 120 262 minecraft:light_blue_concrete
fill 460 120 266 460 124 266 minecraft:light_blue_concrete
setblock 460 120 267 minecraft:white_concrete
fill 461 120 263 461 123 263 minecraft:light_blue_concrete
setblock 461 120 264 minecraft:white_concrete
fill 461 120 269 461 124 269 minecraft:light_blue_concrete
setblock 462 120 261 minecraft:white_concrete
setblock 462 120 262 minecraft:light_blue_concrete
fill 462 120 266 462 124 266 minecraft:light_blue_concrete
setblock 462 120 267 minecraft:white_concrete
fill 463 120 263 463 123 263 minecraft:light_blue_concrete
setblock 463 120 264 minecraft:white_concrete
fill 463 120 269 463 124 269 minecraft:light_blue_concrete
setblock 464 120 261 minecraft:white_concrete
fill 464 120 266 464 124 266 minecraft:light_blue_concrete
setblock 464 120 267 minecraft:white_concrete
setblock 465 120 241 minecraft:ochre_froglight
setblock 451 121 270 minecraft:white_concrete
fill 454 121 228 454 192 228 minecraft:black_concrete
setblock 456 121 267 minecraft:light_blue_concrete
setblock 456 121 268 minecraft:white_concrete
setblock 457 121 264 minecraft:light_blue_concrete
setblock 457 121 265 minecraft:white_concrete
fill 458 121 267 458 123 267 minecraft:light_blue_concrete
setblock 458 121 268 minecraft:white_concrete
fill 459 121 264 459 123 264 minecraft:light_blue_concrete
setblock 459 121 265 minecraft:white_concrete
setblock 460 121 262 minecraft:white_concrete
fill 460 121 267 460 125 267 minecraft:light_blue_concrete
setblock 460 121 268 minecraft:white_concrete
fill 461 121 264 461 124 264 minecraft:light_blue_concrete
setblock 461 121 265 minecraft:white_concrete
setblock 462 121 261 minecraft:light_blue_concrete
setblock 462 121 262 minecraft:white_concrete
fill 462 121 267 462 125 267 minecraft:light_blue_concrete
setblock 462 121 268 minecraft:white_concrete
fill 463 121 264 463 124 264 minecraft:light_blue_concrete
setblock 463 121 265 minecraft:white_concrete
setblock 464 121 262 minecraft:white_concrete
fill 464 121 267 464 125 267 minecraft:light_blue_concrete
setblock 464 121 268 minecraft:white_concrete
fill 465 121 241 465 136 241 minecraft:black_concrete
setblock 423 122 262 minecraft:white_concrete
setblock 426 122 231 minecraft:light[level=15]
setblock 426 122 239 minecraft:light[level=15]
setblock 426 122 247 minecraft:light[level=15]
setblock 426 122 255 minecraft:light[level=15]
setblock 426 122 263 minecraft:light[level=15]
setblock 434 122 231 minecraft:light[level=15]
setblock 434 122 239 minecraft:light[level=15]
setblock 434 122 247 minecraft:light[level=15]
setblock 434 122 255 minecraft:light[level=15]
setblock 434 122 263 minecraft:light[level=15]
fill 437 122 254 437 123 255 minecraft:gray_concrete
setblock 442 122 231 minecraft:light[level=15]
setblock 442 122 239 minecraft:light[level=15]
setblock 442 122 247 minecraft:light[level=15]
setblock 442 122 255 minecraft:light[level=15]
setblock 442 122 263 minecraft:light[level=15]
setblock 450 122 231 minecraft:light[level=15]
setblock 450 122 239 minecraft:light[level=15]
setblock 450 122 247 minecraft:light[level=15]
setblock 450 122 255 minecraft:light[level=15]
setblock 450 122 263 minecraft:light[level=15]
fill 451 122 270 451 173 270 minecraft:black_concrete
setblock 457 122 265 minecraft:light_blue_concrete
setblock 457 122 266 minecraft:white_concrete
setblock 458 122 231 minecraft:light[level=15]
setblock 458 122 239 minecraft:light[level=15]
setblock 458 122 247 minecraft:light[level=15]
setblock 458 122 255 minecraft:light[level=15]
setblock 458 122 263 minecraft:light[level=15]
fill 458 122 268 458 123 268 minecraft:light_blue_concrete
setblock 458 122 269 minecraft:white_concrete
fill 459 122 265 459 124 265 minecraft:light_blue_concrete
setblock 459 122 266 minecraft:white_concrete
setblock 460 122 262 minecraft:light_blue_concrete
setblock 460 122 263 minecraft:white_concrete
fill 460 122 268 460 125 268 minecraft:light_blue_concrete
setblock 460 122 269 minecraft:white_concrete
fill 461 122 265 461 124 265 minecraft:light_blue_concrete
setblock 461 122 266 minecraft:white_concrete
setblock 462 122 262 minecraft:light_blue_concrete
setblock 462 122 263 minecraft:white_concrete
fill 462 122 268 462 125 268 minecraft:light_blue_concrete
setblock 462 122 269 minecraft:white_concrete
fill 463 122 265 463 125 265 minecraft:light_blue_concrete
setblock 463 122 266 minecraft:white_concrete
setblock 464 122 262 minecraft:light_blue_concrete
setblock 464 122 263 minecraft:white_concrete
fill 464 122 268 464 125 268 minecraft:light_blue_concrete
setblock 464 122 269 minecraft:white_concrete
setblock 465 122 246 minecraft:sea_lantern
setblock 465 122 258 minecraft:white_concrete
fill 423 123 262 423 201 262 minecraft:black_concrete
setblock 423 123 264 minecraft:white_concrete
fill 434 123 245 435 124 246 minecraft:gray_concrete
fill 436 123 245 436 124 245 minecraft:gray_concrete
fill 444 123 265 446 125 267 minecraft:gold_block
setblock 458 123 269 minecraft:light_blue_concrete
fill 459 123 266 459 124 266 minecraft:light_blue_concrete
setblock 459 123 267 minecraft:white_concrete
setblock 460 123 263 minecraft:light_blue_concrete
setblock 460 123 264 minecraft:white_concrete
fill 460 123 269 460 124 269 minecraft:light_blue_concrete
fill 461 123 266 461 125 266 minecraft:light_blue_concrete
setblock 461 123 267 minecraft:white_concrete
setblock 462 123 263 minecraft:light_blue_concrete
setblock 462 123 264 minecraft:white_concrete
fill 462 123 269 462 125 269 minecraft:light_blue_concrete
fill 463 123 266 463 125 266 minecraft:light_blue_concrete
setblock 463 123 267 minecraft:white_concrete
setblock 464 123 263 minecraft:light_blue_concrete
setblock 464 123 264 minecraft:white_concrete
fill 464 123 269 464 125 269 minecraft:light_blue_concrete
fill 465 123 246 465 149 246 minecraft:black_concrete
fill 465 123 258 465 131 258 minecraft:black_concrete
setblock 465 123 269 minecraft:ochre_froglight
setblock 423 124 238 minecraft:white_concrete
setblock 423 124 258 minecraft:purple_concrete
fill 423 124 264 423 139 264 minecraft:black_concrete
setblock 426 124 231 minecraft:light[level=12]
setblock 426 124 238 minecraft:light[level=12]
setblock 426 124 245 minecraft:light[level=12]
setblock 426 124 252 minecraft:light[level=12]
setblock 426 124 259 minecraft:light[level=12]
setblock 426 124 266 minecraft:light[level=12]
setblock 431 124 270 minecraft:ochre_froglight
setblock 433 124 231 minecraft:light[level=12]
setblock 433 124 238 minecraft:light[level=12]
setblock 433 124 245 minecraft:light[level=12]
setblock 433 124 252 minecraft:light[level=12]
setblock 433 124 259 minecraft:light[level=12]
setblock 433 124 266 minecraft:light[level=12]
setblock 433 124 270 minecraft:sea_lantern
fill 435 124 231 437 126 233 minecraft:gold_block
fill 439 124 265 443 124 267 minecraft:blue_stained_glass
setblock 440 124 231 minecraft:light[level=12]
setblock 440 124 238 minecraft:light[level=12]
setblock 440 124 245 minecraft:light[level=12]
setblock 440 124 252 minecraft:light[level=12]
setblock 440 124 259 minecraft:light[level=12]
setblock 447 124 231 minecraft:light[level=12]
setblock 447 124 238 minecraft:light[level=12]
setblock 447 124 245 minecraft:light[level=12]
setblock 447 124 259 minecraft:light[level=12]
fill 447 124 265 451 124 267 minecraft:blue_stained_glass
setblock 454 124 231 minecraft:light[level=12]
setblock 454 124 238 minecraft:light[level=12]
setblock 454 124 245 minecraft:light[level=12]
setblock 454 124 252 minecraft:light[level=12]
setblock 454 124 259 minecraft:light[level=12]
setblock 454 124 266 minecraft:light[level=12]
setblock 454 124 270 minecraft:white_concrete
setblock 459 124 267 minecraft:light_blue_concrete
setblock 459 124 268 minecraft:white_concrete
setblock 460 124 264 minecraft:light_blue_concrete
setblock 460 124 265 minecraft:white_concrete
setblock 461 124 231 minecraft:light[level=12]
setblock 461 124 238 minecraft:light[level=12]
setblock 461 124 245 minecraft:light[level=12]
setblock 461 124 252 minecraft:light[level=12]
setblock 461 124 259 minecraft:light[level=12]
fill 461 124 267 461 125 267 minecraft:light_blue_concrete
setblock 461 124 268 minecraft:white_concrete
setblock 462 124 264 minecraft:light_blue_concrete
setblock 462 124 265 minecraft:white_concrete
fill 463 124 267 463 125 267 minecraft:light_blue_concrete
setblock 463 124 268 minecraft:white_concrete
setblock 464 124 264 minecraft:light_blue_concrete
setblock 464 124 265 minecraft:white_concrete
setblock 465 124 264 minecraft:pearlescent_froglight
fill 465 124 269 465 159 269 minecraft:black_concrete
fill 423 125 238 423 142 238 minecraft:black_concrete
fill 423 125 258 423 180 258 minecraft:black_concrete
fill 430 125 231 434 125 233 minecraft:blue_stained_glass
fill 431 125 270 431 164 270 minecraft:black_concrete
fill 433 125 270 433 141 270 minecraft:black_concrete
fill 438 125 231 442 125 233 minecraft:blue_stained_glass
setblock 441 125 228 minecraft:pearlescent_froglight
setblock 450 125 228 minecraft:pearlescent_froglight
fill 454 125 270 454 146 270 minecraft:black_concrete
schedule function dropper:buildpart/57_2 1t
