fill 50 248 597 52 248 597 minecraft:cobbled_deepslate
fill 51 248 595 51 251 595 minecraft:deepslate
setblock 52 248 598 minecraft:calcite
setblock 53 248 597 minecraft:calcite
fill 53 248 598 53 251 598 minecraft:cobbled_deepslate
setblock 56 248 598 minecraft:cobbled_deepslate
setblock 58 248 560 minecraft:light[level=14]
setblock 58 248 568 minecraft:light[level=14]
setblock 58 248 576 minecraft:light[level=14]
setblock 58 248 584 minecraft:light[level=14]
setblock 58 248 592 minecraft:light[level=14]
setblock 66 248 560 minecraft:light[level=14]
setblock 66 248 568 minecraft:light[level=14]
setblock 66 248 576 minecraft:light[level=14]
setblock 66 248 584 minecraft:light[level=14]
setblock 66 248 592 minecraft:light[level=14]
setblock 67 248 558 minecraft:calcite
setblock 67 248 598 minecraft:calcite
fill 68 248 558 71 248 558 minecraft:cobbled_deepslate
fill 68 248 598 71 248 598 minecraft:cobbled_deepslate
fill 69 248 597 69 251 597 minecraft:cobbled_deepslate
setblock 70 248 559 minecraft:cobbled_deepslate
setblock 71 248 559 minecraft:calcite
fill 71 248 596 71 250 596 minecraft:cobbled_deepslate
setblock 72 248 558 minecraft:calcite
fill 72 248 559 72 251 559 minecraft:cobbled_deepslate
setblock 72 248 598 minecraft:calcite
fill 73 248 558 73 251 558 minecraft:cobbled_deepslate
setblock 73 248 597 minecraft:calcite
fill 73 248 598 73 251 598 minecraft:cobbled_deepslate
setblock 74 248 560 minecraft:light[level=14]
setblock 74 248 568 minecraft:light[level=14]
setblock 74 248 576 minecraft:light[level=14]
setblock 74 248 584 minecraft:light[level=14]
setblock 74 248 592 minecraft:light[level=14]
setblock 74 248 596 minecraft:calcite
fill 74 248 597 74 251 597 minecraft:cobbled_deepslate
fill 75 248 596 75 251 596 minecraft:cobbled_deepslate
setblock 77 248 558 minecraft:calcite
setblock 77 248 598 minecraft:calcite
fill 78 248 558 78 251 558 minecraft:cobbled_deepslate
setblock 78 248 597 minecraft:calcite
fill 78 248 598 78 251 598 minecraft:cobbled_deepslate
fill 79 248 597 79 251 597 minecraft:cobbled_deepslate
fill 81 248 597 81 249 597 minecraft:cobbled_deepslate
setblock 82 248 560 minecraft:light[level=14]
setblock 82 248 568 minecraft:light[level=14]
setblock 82 248 576 minecraft:light[level=14]
setblock 82 248 592 minecraft:light[level=14]
setblock 82 248 598 minecraft:calcite
fill 83 248 598 83 251 598 minecraft:cobbled_deepslate
fill 86 248 597 86 249 597 minecraft:cobbled_deepslate
setblock 87 248 593 minecraft:calcite
fill 87 248 594 87 251 594 minecraft:cobbled_deepslate
setblock 87 248 598 minecraft:calcite
setblock 88 248 571 minecraft:cobbled_deepslate
setblock 88 248 572 minecraft:calcite
fill 88 248 573 88 251 573 minecraft:cobbled_deepslate
setblock 88 248 576 minecraft:cobbled_deepslate
setblock 88 248 577 minecraft:calcite
fill 88 248 578 88 251 578 minecraft:cobbled_deepslate
setblock 88 248 587 minecraft:calcite
fill 88 248 588 88 251 588 minecraft:cobbled_deepslate
setblock 88 248 592 minecraft:calcite
fill 88 248 593 88 251 593 minecraft:cobbled_deepslate
setblock 88 248 597 minecraft:calcite
fill 88 248 598 88 251 598 minecraft:cobbled_deepslate
setblock 48 249 571 minecraft:calcite
fill 48 249 572 48 252 572 minecraft:cobbled_deepslate
setblock 48 249 576 minecraft:calcite
fill 48 249 577 48 252 577 minecraft:cobbled_deepslate
setblock 48 249 581 minecraft:calcite
fill 48 249 582 49 251 582 minecraft:cobbled_deepslate
setblock 48 249 586 minecraft:calcite
fill 48 249 587 48 252 587 minecraft:cobbled_deepslate
setblock 48 249 591 minecraft:calcite
fill 48 249 592 48 252 592 minecraft:cobbled_deepslate
setblock 48 249 595 minecraft:cobbled_deepslate
setblock 48 249 596 minecraft:calcite
fill 48 249 597 51 249 597 minecraft:cobbled_deepslate
setblock 49 249 570 minecraft:calcite
fill 49 249 571 49 252 571 minecraft:cobbled_deepslate
setblock 49 249 575 minecraft:calcite
fill 49 249 576 49 252 576 minecraft:cobbled_deepslate
setblock 49 249 579 minecraft:cobbled_deepslate
setblock 49 249 580 minecraft:calcite
fill 49 249 581 49 252 581 minecraft:cobbled_deepslate
setblock 49 249 590 minecraft:calcite
fill 49 249 591 49 252 591 minecraft:cobbled_deepslate
setblock 49 249 595 minecraft:calcite
fill 49 249 596 49 252 596 minecraft:cobbled_deepslate
fill 50 249 570 50 252 570 minecraft:cobbled_deepslate
setblock 50 249 574 minecraft:calcite
fill 50 249 575 51 251 575 minecraft:cobbled_deepslate
setblock 50 249 578 minecraft:cobbled_deepslate
setblock 50 249 579 minecraft:calcite
setblock 51 249 558 minecraft:calcite
setblock 51 249 572 minecraft:cobbled_deepslate
setblock 51 249 573 minecraft:calcite
fill 51 249 574 51 252 574 minecraft:cobbled_deepslate
fill 51 249 576 51 250 576 minecraft:cobbled_deepslate
setblock 51 249 598 minecraft:calcite
fill 52 249 558 55 249 558 minecraft:cobbled_deepslate
setblock 52 249 597 minecraft:calcite
fill 52 249 598 52 252 598 minecraft:cobbled_deepslate
fill 53 249 597 54 251 597 minecraft:cobbled_deepslate
setblock 56 249 598 minecraft:calcite
setblock 65 249 558 minecraft:cobbled_deepslate
setblock 66 249 558 minecraft:calcite
setblock 66 249 598 minecraft:calcite
fill 67 249 558 70 249 558 minecraft:cobbled_deepslate
fill 67 249 598 70 249 598 minecraft:cobbled_deepslate
fill 68 249 559 69 249 559 minecraft:cobbled_deepslate
fill 68 249 597 68 252 597 minecraft:cobbled_deepslate
setblock 70 249 559 minecraft:calcite
fill 70 249 596 70 251 596 minecraft:cobbled_deepslate
setblock 71 249 558 minecraft:calcite
fill 71 249 559 71 252 559 minecraft:cobbled_deepslate
setblock 71 249 598 minecraft:calcite
fill 72 249 558 72 252 558 minecraft:cobbled_deepslate
setblock 72 249 597 minecraft:calcite
fill 72 249 598 72 252 598 minecraft:cobbled_deepslate
setblock 73 249 596 minecraft:calcite
fill 73 249 597 73 252 597 minecraft:cobbled_deepslate
fill 74 249 596 74 252 596 minecraft:cobbled_deepslate
setblock 75 249 559 minecraft:calcite
setblock 76 249 558 minecraft:calcite
setblock 76 249 598 minecraft:calcite
fill 77 249 558 77 252 558 minecraft:cobbled_deepslate
setblock 77 249 597 minecraft:calcite
fill 77 249 598 77 252 598 minecraft:cobbled_deepslate
setblock 78 249 596 minecraft:calcite
fill 78 249 597 78 252 597 minecraft:cobbled_deepslate
fill 79 249 558 79 250 558 minecraft:cobbled_deepslate
setblock 81 249 598 minecraft:calcite
setblock 82 249 597 minecraft:calcite
fill 82 249 598 82 252 598 minecraft:cobbled_deepslate
fill 83 249 597 85 250 597 minecraft:cobbled_deepslate
setblock 86 249 598 minecraft:calcite
setblock 87 249 592 minecraft:calcite
fill 87 249 593 87 252 593 minecraft:cobbled_deepslate
setblock 87 249 597 minecraft:calcite
fill 87 249 598 87 252 598 minecraft:cobbled_deepslate
setblock 88 249 570 minecraft:cobbled_deepslate
setblock 88 249 571 minecraft:calcite
fill 88 249 572 88 252 572 minecraft:cobbled_deepslate
setblock 88 249 576 minecraft:calcite
fill 88 249 577 88 252 577 minecraft:cobbled_deepslate
fill 88 249 579 88 249 580 minecraft:cobbled_deepslate
setblock 88 249 581 minecraft:calcite
fill 88 249 582 88 249 585 minecraft:cobbled_deepslate
setblock 88 249 586 minecraft:calcite
fill 88 249 587 88 252 587 minecraft:cobbled_deepslate
setblock 88 249 591 minecraft:calcite
fill 88 249 592 88 252 592 minecraft:cobbled_deepslate
setblock 88 249 596 minecraft:calcite
fill 88 249 597 88 252 597 minecraft:cobbled_deepslate
fill 48 250 567 48 252 567 minecraft:cobbled_deepslate
setblock 48 250 569 minecraft:cobbled_deepslate
setblock 48 250 570 minecraft:calcite
fill 48 250 571 48 253 571 minecraft:cobbled_deepslate
setblock 48 250 575 minecraft:calcite
fill 48 250 576 48 253 576 minecraft:cobbled_deepslate
setblock 48 250 580 minecraft:calcite
fill 48 250 581 48 253 581 minecraft:cobbled_deepslate
setblock 48 250 585 minecraft:calcite
fill 48 250 586 48 253 586 minecraft:cobbled_deepslate
setblock 48 250 590 minecraft:calcite
fill 48 250 591 48 253 591 minecraft:cobbled_deepslate
setblock 48 250 595 minecraft:calcite
fill 48 250 596 48 252 597 minecraft:cobbled_deepslate
setblock 49 250 558 minecraft:cobbled_deepslate
setblock 49 250 568 minecraft:cobbled_deepslate
setblock 49 250 569 minecraft:calcite
fill 49 250 570 49 253 570 minecraft:cobbled_deepslate
setblock 49 250 574 minecraft:calcite
fill 49 250 575 49 253 575 minecraft:cobbled_deepslate
setblock 49 250 579 minecraft:calcite
fill 49 250 580 50 252 580 minecraft:cobbled_deepslate
setblock 49 250 583 minecraft:cobbled_deepslate
setblock 49 250 584 minecraft:calcite
fill 49 250 585 49 253 585 minecraft:cobbled_deepslate
setblock 49 250 588 minecraft:cobbled_deepslate
setblock 49 250 589 minecraft:calcite
fill 49 250 590 49 253 590 minecraft:cobbled_deepslate
setblock 49 250 594 minecraft:calcite
fill 49 250 595 49 253 595 minecraft:cobbled_deepslate
fill 49 250 597 50 250 597 minecraft:cobbled_deepslate
setblock 50 250 558 minecraft:calcite
setblock 50 250 573 minecraft:calcite
fill 50 250 574 50 253 574 minecraft:cobbled_deepslate
setblock 50 250 578 minecraft:calcite
fill 50 250 579 50 253 579 minecraft:cobbled_deepslate
fill 50 250 581 50 251 581 minecraft:cobbled_deepslate
setblock 50 250 598 minecraft:calcite
fill 51 250 558 54 250 558 minecraft:cobbled_deepslate
setblock 51 250 572 minecraft:calcite
fill 51 250 573 51 253 573 minecraft:cobbled_deepslate
setblock 51 250 577 minecraft:calcite
fill 51 250 578 51 253 578 minecraft:cobbled_deepslate
setblock 51 250 597 minecraft:calcite
fill 51 250 598 51 253 598 minecraft:cobbled_deepslate
fill 52 250 597 52 253 597 minecraft:cobbled_deepslate
setblock 55 250 558 minecraft:calcite
setblock 55 250 598 minecraft:calcite
fill 56 250 558 57 252 558 minecraft:cobbled_deepslate
fill 56 250 598 57 252 598 minecraft:cobbled_deepslate
fill 63 250 558 64 250 558 minecraft:cobbled_deepslate
setblock 64 250 598 minecraft:cobbled_deepslate
setblock 65 250 558 minecraft:calcite
setblock 65 250 598 minecraft:calcite
fill 66 250 558 69 250 558 minecraft:cobbled_deepslate
setblock 66 250 597 minecraft:calcite
fill 66 250 598 69 250 598 minecraft:cobbled_deepslate
fill 67 250 559 68 250 559 minecraft:cobbled_deepslate
fill 67 250 597 67 253 597 minecraft:cobbled_deepslate
setblock 69 250 559 minecraft:calcite
fill 69 250 596 69 252 596 minecraft:cobbled_deepslate
setblock 70 250 558 minecraft:calcite
fill 70 250 559 70 253 559 minecraft:cobbled_deepslate
setblock 70 250 598 minecraft:calcite
fill 71 250 558 71 253 558 minecraft:cobbled_deepslate
setblock 71 250 597 minecraft:calcite
fill 71 250 598 71 253 598 minecraft:cobbled_deepslate
setblock 72 250 596 minecraft:calcite
fill 72 250 597 72 253 597 minecraft:cobbled_deepslate
fill 73 250 596 73 253 596 minecraft:cobbled_deepslate
setblock 74 250 559 minecraft:calcite
setblock 75 250 558 minecraft:calcite
fill 75 250 559 76 252 559 minecraft:cobbled_deepslate
setblock 75 250 598 minecraft:calcite
fill 76 250 558 76 253 558 minecraft:cobbled_deepslate
setblock 76 250 597 minecraft:calcite
fill 76 250 598 76 253 598 minecraft:cobbled_deepslate
setblock 77 250 596 minecraft:calcite
fill 77 250 597 77 253 597 minecraft:cobbled_deepslate
fill 78 250 596 78 253 596 minecraft:cobbled_deepslate
setblock 80 250 598 minecraft:calcite
setblock 81 250 597 minecraft:calcite
fill 81 250 598 81 253 598 minecraft:cobbled_deepslate
fill 82 250 597 82 253 597 minecraft:cobbled_deepslate
setblock 85 250 598 minecraft:calcite
fill 86 250 594 86 250 596 minecraft:cobbled_deepslate
setblock 86 250 597 minecraft:calcite
fill 86 250 598 86 253 598 minecraft:cobbled_deepslate
fill 87 250 574 87 250 575 minecraft:cobbled_deepslate
setblock 87 250 576 minecraft:calcite
fill 87 250 577 87 252 578 minecraft:cobbled_deepslate
fill 87 250 589 87 251 589 minecraft:cobbled_deepslate
setblock 87 250 591 minecraft:calcite
fill 87 250 592 87 253 592 minecraft:cobbled_deepslate
setblock 87 250 596 minecraft:calcite
fill 87 250 597 87 253 597 minecraft:cobbled_deepslate
fill 88 250 558 88 251 558 minecraft:cobbled_deepslate
setblock 88 250 570 minecraft:calcite
fill 88 250 571 88 253 571 minecraft:cobbled_deepslate
setblock 88 250 574 minecraft:cobbled_deepslate
setblock 88 250 575 minecraft:calcite
fill 88 250 576 88 253 576 minecraft:cobbled_deepslate
setblock 88 250 579 minecraft:cobbled_deepslate
setblock 88 250 580 minecraft:calcite
fill 88 250 581 88 250 584 minecraft:cobbled_deepslate
setblock 88 250 585 minecraft:calcite
fill 88 250 586 88 253 586 minecraft:cobbled_deepslate
setblock 88 250 590 minecraft:calcite
fill 88 250 591 88 253 591 minecraft:cobbled_deepslate
setblock 88 250 595 minecraft:calcite
fill 88 250 596 88 253 596 minecraft:cobbled_deepslate
setblock 48 251 558 minecraft:cobbled_deepslate
setblock 48 251 559 minecraft:calcite
fill 48 251 560 48 254 560 minecraft:cobbled_deepslate
fill 48 251 566 48 253 566 minecraft:cobbled_deepslate
setblock 48 251 569 minecraft:calcite
fill 48 251 570 48 254 570 minecraft:cobbled_deepslate
setblock 48 251 574 minecraft:calcite
fill 48 251 575 48 254 575 minecraft:cobbled_deepslate
setblock 48 251 579 minecraft:calcite
fill 48 251 580 48 254 580 minecraft:cobbled_deepslate
setblock 48 251 584 minecraft:calcite
fill 48 251 585 48 254 585 minecraft:cobbled_deepslate
setblock 48 251 589 minecraft:calcite
fill 48 251 590 48 254 590 minecraft:cobbled_deepslate
setblock 48 251 594 minecraft:calcite
fill 48 251 595 48 254 595 minecraft:cobbled_deepslate
setblock 49 251 558 minecraft:calcite
setblock 49 251 568 minecraft:calcite
fill 49 251 569 50 253 569 minecraft:cobbled_deepslate
setblock 49 251 573 minecraft:calcite
fill 49 251 574 49 254 574 minecraft:cobbled_deepslate
setblock 49 251 577 minecraft:cobbled_deepslate
setblock 49 251 578 minecraft:calcite
fill 49 251 579 49 254 579 minecraft:cobbled_deepslate
setblock 49 251 583 minecraft:calcite
fill 49 251 584 49 254 584 minecraft:cobbled_deepslate
fill 49 251 586 49 251 587 minecraft:cobbled_deepslate
setblock 49 251 588 minecraft:calcite
fill 49 251 589 49 254 589 minecraft:cobbled_deepslate
setblock 49 251 593 minecraft:calcite
fill 49 251 594 50 252 594 minecraft:cobbled_deepslate
setblock 49 251 597 minecraft:cobbled_deepslate
setblock 49 251 598 minecraft:calcite
fill 50 251 558 53 251 558 minecraft:cobbled_deepslate
setblock 50 251 572 minecraft:calcite
fill 50 251 573 50 254 573 minecraft:cobbled_deepslate
setblock 50 251 577 minecraft:calcite
fill 50 251 578 50 254 578 minecraft:cobbled_deepslate
setblock 50 251 582 minecraft:calcite
fill 50 251 595 50 251 596 minecraft:cobbled_deepslate
setblock 50 251 597 minecraft:calcite
fill 50 251 598 50 254 598 minecraft:cobbled_deepslate
setblock 51 251 571 minecraft:calcite
fill 51 251 572 51 254 572 minecraft:cobbled_deepslate
setblock 51 251 576 minecraft:calcite
fill 51 251 577 51 254 577 minecraft:cobbled_deepslate
fill 51 251 579 51 252 579 minecraft:cobbled_deepslate
setblock 51 251 596 minecraft:calcite
fill 51 251 597 51 254 597 minecraft:cobbled_deepslate
setblock 52 251 596 minecraft:deepslate
setblock 54 251 558 minecraft:calcite
setblock 54 251 598 minecraft:calcite
fill 55 251 558 55 254 558 minecraft:cobbled_deepslate
fill 55 251 598 55 254 598 minecraft:cobbled_deepslate
setblock 58 251 558 minecraft:cobbled_deepslate
setblock 58 251 598 minecraft:cobbled_deepslate
setblock 59 251 558 minecraft:calcite
fill 60 251 558 63 251 558 minecraft:cobbled_deepslate
fill 62 251 598 63 251 598 minecraft:cobbled_deepslate
setblock 64 251 558 minecraft:calcite
setblock 64 251 598 minecraft:calcite
fill 65 251 558 67 251 559 minecraft:cobbled_deepslate
setblock 65 251 597 minecraft:calcite
fill 65 251 598 68 251 598 minecraft:cobbled_deepslate
fill 66 251 597 66 254 597 minecraft:cobbled_deepslate
setblock 68 251 558 minecraft:cobbled_deepslate
setblock 68 251 559 minecraft:calcite
fill 68 251 596 68 253 596 minecraft:cobbled_deepslate
setblock 69 251 558 minecraft:calcite
fill 69 251 559 69 253 560 minecraft:cobbled_deepslate
setblock 69 251 598 minecraft:calcite
fill 70 251 558 70 254 558 minecraft:cobbled_deepslate
fill 70 251 560 71 251 560 minecraft:cobbled_deepslate
setblock 70 251 597 minecraft:calcite
fill 70 251 598 70 254 598 minecraft:cobbled_deepslate
setblock 71 251 595 minecraft:cobbled_deepslate
setblock 71 251 596 minecraft:calcite
fill 71 251 597 71 254 597 minecraft:cobbled_deepslate
setblock 72 251 560 minecraft:calcite
setblock 72 251 595 minecraft:calcite
fill 72 251 596 72 254 596 minecraft:cobbled_deepslate
setblock 73 251 559 minecraft:calcite
fill 73 251 560 73 254 560 minecraft:cobbled_deepslate
fill 73 251 595 74 252 595 minecraft:cobbled_deepslate
setblock 74 251 558 minecraft:calcite
fill 74 251 559 74 254 559 minecraft:cobbled_deepslate
setblock 74 251 598 minecraft:calcite
fill 75 251 558 75 254 558 minecraft:cobbled_deepslate
setblock 75 251 597 minecraft:calcite
fill 75 251 598 75 254 598 minecraft:cobbled_deepslate
setblock 76 251 596 minecraft:calcite
fill 76 251 597 76 254 597 minecraft:cobbled_deepslate
fill 77 251 596 77 254 596 minecraft:cobbled_deepslate
setblock 79 251 558 minecraft:calcite
fill 79 251 596 79 252 596 minecraft:cobbled_deepslate
setblock 79 251 598 minecraft:calcite
fill 80 251 558 80 254 558 minecraft:cobbled_deepslate
setblock 80 251 597 minecraft:calcite
fill 80 251 598 80 254 598 minecraft:cobbled_deepslate
fill 81 251 597 81 254 597 minecraft:cobbled_deepslate
fill 83 251 597 84 251 597 minecraft:cobbled_deepslate
fill 84 251 596 85 251 596 minecraft:cobbled_deepslate
setblock 84 251 598 minecraft:calcite
fill 85 251 558 87 252 558 minecraft:cobbled_deepslate
setblock 85 251 597 minecraft:calcite
fill 85 251 598 85 254 598 minecraft:cobbled_deepslate
fill 86 251 593 86 251 595 minecraft:cobbled_deepslate
setblock 86 251 596 minecraft:calcite
fill 86 251 597 86 254 597 minecraft:cobbled_deepslate
fill 87 251 573 87 251 574 minecraft:cobbled_deepslate
setblock 87 251 575 minecraft:calcite
fill 87 251 576 87 254 576 minecraft:cobbled_deepslate
setblock 87 251 579 minecraft:cobbled_deepslate
setblock 87 251 580 minecraft:calcite
fill 87 251 581 88 252 582 minecraft:cobbled_deepslate
fill 87 251 588 87 252 588 minecraft:cobbled_deepslate
setblock 87 251 590 minecraft:calcite
fill 87 251 591 87 254 591 minecraft:cobbled_deepslate
setblock 87 251 595 minecraft:calcite
fill 87 251 596 87 254 596 minecraft:cobbled_deepslate
setblock 88 251 559 minecraft:calcite
setblock 88 251 569 minecraft:calcite
fill 88 251 570 88 254 570 minecraft:cobbled_deepslate
setblock 88 251 574 minecraft:calcite
fill 88 251 575 88 254 575 minecraft:cobbled_deepslate
setblock 88 251 579 minecraft:calcite
fill 88 251 580 88 254 580 minecraft:cobbled_deepslate
setblock 88 251 583 minecraft:cobbled_deepslate
setblock 88 251 584 minecraft:calcite
fill 88 251 585 88 254 585 minecraft:cobbled_deepslate
setblock 88 251 589 minecraft:calcite
fill 88 251 590 88 254 590 minecraft:cobbled_deepslate
setblock 88 251 594 minecraft:calcite
fill 88 251 595 88 254 595 minecraft:cobbled_deepslate
setblock 48 252 558 minecraft:calcite
fill 48 252 559 51 252 559 minecraft:cobbled_deepslate
fill 48 252 561 48 252 562 minecraft:cobbled_deepslate
setblock 48 252 563 minecraft:calcite
fill 48 252 564 48 254 565 minecraft:cobbled_deepslate
setblock 48 252 568 minecraft:calcite
fill 48 252 569 48 255 569 minecraft:cobbled_deepslate
setblock 48 252 573 minecraft:calcite
fill 48 252 574 48 255 574 minecraft:cobbled_deepslate
setblock 48 252 578 minecraft:calcite
fill 48 252 579 48 255 579 minecraft:cobbled_deepslate
setblock 48 252 582 minecraft:cobbled_deepslate
setblock 48 252 583 minecraft:calcite
fill 48 252 584 48 255 584 minecraft:cobbled_deepslate
setblock 48 252 588 minecraft:calcite
fill 48 252 589 48 255 589 minecraft:cobbled_deepslate
setblock 48 252 593 minecraft:calcite
fill 48 252 594 48 255 594 minecraft:cobbled_deepslate
setblock 48 252 598 minecraft:calcite
fill 49 252 558 52 252 558 minecraft:cobbled_deepslate
setblock 49 252 567 minecraft:calcite
fill 49 252 568 49 255 568 minecraft:cobbled_deepslate
setblock 49 252 572 minecraft:calcite
fill 49 252 573 49 255 573 minecraft:cobbled_deepslate
setblock 49 252 577 minecraft:calcite
fill 49 252 578 49 255 578 minecraft:cobbled_deepslate
setblock 49 252 582 minecraft:calcite
fill 49 252 583 50 254 583 minecraft:cobbled_deepslate
setblock 49 252 586 minecraft:cobbled_deepslate
setblock 49 252 587 minecraft:calcite
fill 49 252 588 49 255 588 minecraft:cobbled_deepslate
setblock 49 252 592 minecraft:calcite
fill 49 252 593 49 255 593 minecraft:cobbled_deepslate
setblock 49 252 597 minecraft:calcite
fill 49 252 598 49 255 598 minecraft:cobbled_deepslate
setblock 50 252 571 minecraft:calcite
fill 50 252 572 50 255 572 minecraft:cobbled_deepslate
setblock 50 252 575 minecraft:cobbled_deepslate
setblock 50 252 576 minecraft:calcite
fill 50 252 577 50 255 577 minecraft:cobbled_deepslate
setblock 50 252 581 minecraft:calcite
fill 50 252 582 50 255 582 minecraft:cobbled_deepslate
setblock 50 252 595 minecraft:cobbled_deepslate
setblock 50 252 596 minecraft:calcite
fill 50 252 597 50 255 597 minecraft:cobbled_deepslate
fill 51 252 571 51 253 571 minecraft:cobbled_deepslate
setblock 51 252 575 minecraft:calcite
fill 51 252 576 52 253 576 minecraft:cobbled_deepslate
setblock 51 252 580 minecraft:calcite
fill 51 252 596 51 253 596 minecraft:cobbled_deepslate
setblock 52 252 559 minecraft:calcite
fill 52 252 575 52 253 575 minecraft:cobbled_deepslate
setblock 53 252 558 minecraft:calcite
fill 53 252 559 55 253 559 minecraft:cobbled_deepslate
setblock 53 252 597 minecraft:cobbled_deepslate
setblock 53 252 598 minecraft:calcite
fill 54 252 558 54 255 558 minecraft:cobbled_deepslate
setblock 54 252 597 minecraft:calcite
fill 54 252 598 54 255 598 minecraft:cobbled_deepslate
setblock 55 252 597 minecraft:cobbled_deepslate
setblock 58 252 558 minecraft:calcite
setblock 58 252 598 minecraft:calcite
fill 59 252 558 62 252 558 minecraft:cobbled_deepslate
fill 59 252 598 62 252 598 minecraft:cobbled_deepslate
setblock 63 252 558 minecraft:calcite
fill 63 252 559 66 252 559 minecraft:cobbled_deepslate
setblock 63 252 598 minecraft:calcite
fill 64 252 558 67 252 558 minecraft:cobbled_deepslate
setblock 64 252 597 minecraft:calcite
fill 64 252 598 67 252 598 minecraft:cobbled_deepslate
fill 65 252 597 65 255 597 minecraft:cobbled_deepslate
setblock 67 252 559 minecraft:calcite
fill 67 252 560 68 254 560 minecraft:cobbled_deepslate
fill 67 252 596 67 254 596 minecraft:cobbled_deepslate
setblock 68 252 558 minecraft:calcite
fill 68 252 559 68 255 559 minecraft:cobbled_deepslate
setblock 68 252 598 minecraft:calcite
fill 69 252 558 69 255 558 minecraft:cobbled_deepslate
setblock 69 252 597 minecraft:calcite
fill 69 252 598 69 255 598 minecraft:cobbled_deepslate
setblock 70 252 560 minecraft:cobbled_deepslate
setblock 70 252 595 minecraft:cobbled_deepslate
setblock 70 252 596 minecraft:calcite
fill 70 252 597 70 255 597 minecraft:cobbled_deepslate
setblock 71 252 560 minecraft:calcite
setblock 71 252 595 minecraft:calcite
fill 71 252 596 71 255 596 minecraft:cobbled_deepslate
setblock 72 252 559 minecraft:calcite
fill 72 252 560 72 255 560 minecraft:cobbled_deepslate
fill 72 252 595 72 254 595 minecraft:cobbled_deepslate
setblock 73 252 558 minecraft:calcite
fill 73 252 559 73 255 559 minecraft:cobbled_deepslate
setblock 73 252 598 minecraft:calcite
fill 74 252 558 74 255 558 minecraft:cobbled_deepslate
setblock 74 252 597 minecraft:calcite
fill 74 252 598 74 255 598 minecraft:cobbled_deepslate
setblock 75 252 596 minecraft:calcite
fill 75 252 597 75 255 597 minecraft:cobbled_deepslate
fill 76 252 596 76 255 596 minecraft:cobbled_deepslate
setblock 77 252 559 minecraft:calcite
setblock 78 252 558 minecraft:calcite
setblock 78 252 598 minecraft:calcite
fill 79 252 558 79 255 558 minecraft:cobbled_deepslate
setblock 79 252 597 minecraft:calcite
fill 79 252 598 79 255 598 minecraft:cobbled_deepslate
fill 80 252 597 80 255 597 minecraft:cobbled_deepslate
fill 81 252 558 82 252 558 minecraft:cobbled_deepslate
setblock 83 252 558 minecraft:calcite
fill 83 252 596 83 252 597 minecraft:cobbled_deepslate
setblock 83 252 598 minecraft:calcite
fill 84 252 558 84 255 558 minecraft:cobbled_deepslate
setblock 84 252 596 minecraft:cobbled_deepslate
setblock 84 252 597 minecraft:calcite
fill 84 252 598 84 255 598 minecraft:cobbled_deepslate
setblock 85 252 596 minecraft:calcite
fill 85 252 597 85 255 597 minecraft:cobbled_deepslate
fill 86 252 592 86 252 594 minecraft:cobbled_deepslate
setblock 86 252 595 minecraft:calcite
fill 86 252 596 86 255 596 minecraft:cobbled_deepslate
fill 87 252 572 87 252 573 minecraft:cobbled_deepslate
setblock 87 252 574 minecraft:calcite
fill 87 252 575 87 255 575 minecraft:cobbled_deepslate
setblock 87 252 579 minecraft:calcite
fill 87 252 580 87 255 580 minecraft:cobbled_deepslate
setblock 87 252 583 minecraft:cobbled_deepslate
setblock 87 252 584 minecraft:calcite
fill 87 252 585 87 253 587 minecraft:cobbled_deepslate
setblock 87 252 589 minecraft:calcite
fill 87 252 590 87 255 590 minecraft:cobbled_deepslate
setblock 87 252 594 minecraft:calcite
fill 87 252 595 87 255 595 minecraft:cobbled_deepslate
setblock 88 252 558 minecraft:calcite
fill 88 252 559 88 253 561 minecraft:cobbled_deepslate
setblock 88 252 568 minecraft:calcite
fill 88 252 569 88 255 569 minecraft:cobbled_deepslate
setblock 88 252 573 minecraft:calcite
fill 88 252 574 88 255 574 minecraft:cobbled_deepslate
setblock 88 252 578 minecraft:calcite
fill 88 252 579 88 255 579 minecraft:cobbled_deepslate
setblock 88 252 583 minecraft:calcite
fill 88 252 584 88 255 584 minecraft:cobbled_deepslate
setblock 88 252 588 minecraft:calcite
fill 88 252 589 88 255 589 minecraft:cobbled_deepslate
setblock 88 252 593 minecraft:calcite
fill 88 252 594 88 255 594 minecraft:cobbled_deepslate
setblock 88 252 598 minecraft:calcite
fill 48 253 558 50 253 559 minecraft:cobbled_deepslate
setblock 48 253 561 minecraft:cobbled_deepslate
setblock 48 253 562 minecraft:calcite
fill 48 253 563 48 256 563 minecraft:cobbled_deepslate
setblock 48 253 567 minecraft:calcite
fill 48 253 568 48 256 568 minecraft:cobbled_deepslate
setblock 48 253 572 minecraft:calcite
fill 48 253 573 48 256 573 minecraft:cobbled_deepslate
setblock 48 253 577 minecraft:calcite
fill 48 253 578 48 256 578 minecraft:cobbled_deepslate
setblock 48 253 582 minecraft:calcite
fill 48 253 583 48 256 583 minecraft:cobbled_deepslate
setblock 48 253 587 minecraft:calcite
fill 48 253 588 48 256 588 minecraft:cobbled_deepslate
setblock 48 253 592 minecraft:calcite
fill 48 253 593 48 256 593 minecraft:cobbled_deepslate
setblock 48 253 596 minecraft:cobbled_deepslate
setblock 48 253 597 minecraft:calcite
fill 48 253 598 48 256 598 minecraft:cobbled_deepslate
setblock 49 253 560 minecraft:cobbled_deepslate
setblock 49 253 561 minecraft:calcite
fill 49 253 562 49 256 562 minecraft:cobbled_deepslate
setblock 49 253 566 minecraft:calcite
fill 49 253 567 49 256 567 minecraft:cobbled_deepslate
setblock 49 253 571 minecraft:calcite
fill 49 253 572 49 256 572 minecraft:cobbled_deepslate
setblock 49 253 576 minecraft:calcite
fill 49 253 577 49 256 577 minecraft:cobbled_deepslate
setblock 49 253 580 minecraft:cobbled_deepslate
setblock 49 253 581 minecraft:calcite
fill 49 253 582 49 256 582 minecraft:cobbled_deepslate
setblock 49 253 586 minecraft:calcite
fill 49 253 587 49 256 587 minecraft:cobbled_deepslate
setblock 49 253 591 minecraft:calcite
fill 49 253 592 49 255 592 minecraft:cobbled_deepslate
fill 49 253 594 49 254 594 minecraft:cobbled_deepslate
setblock 49 253 596 minecraft:calcite
fill 49 253 597 49 256 597 minecraft:cobbled_deepslate
setblock 50 253 570 minecraft:calcite
fill 50 253 571 50 256 571 minecraft:cobbled_deepslate
setblock 50 253 575 minecraft:calcite
fill 50 253 576 50 256 576 minecraft:cobbled_deepslate
setblock 50 253 580 minecraft:calcite
fill 50 253 581 51 255 581 minecraft:cobbled_deepslate
setblock 50 253 584 minecraft:cobbled_deepslate
setblock 50 253 595 minecraft:calcite
fill 50 253 596 50 254 596 minecraft:cobbled_deepslate
setblock 51 253 558 minecraft:cobbled_deepslate
setblock 51 253 559 minecraft:calcite
setblock 51 253 574 minecraft:calcite
fill 51 253 575 51 256 575 minecraft:cobbled_deepslate
setblock 51 253 579 minecraft:calcite
fill 51 253 580 51 256 580 minecraft:cobbled_deepslate
setblock 52 253 558 minecraft:calcite
fill 52 253 559 52 256 559 minecraft:cobbled_deepslate
setblock 52 253 577 minecraft:cobbled_deepslate
setblock 52 253 598 minecraft:calcite
fill 53 253 558 53 256 558 minecraft:cobbled_deepslate
setblock 53 253 597 minecraft:calcite
fill 53 253 598 53 256 598 minecraft:cobbled_deepslate
fill 54 253 597 54 254 597 minecraft:cobbled_deepslate
setblock 56 253 558 minecraft:cobbled_deepslate
setblock 56 253 559 minecraft:calcite
setblock 56 253 598 minecraft:cobbled_deepslate
setblock 57 253 558 minecraft:calcite
setblock 57 253 598 minecraft:calcite
fill 58 253 558 61 253 558 minecraft:cobbled_deepslate
fill 58 253 598 61 253 598 minecraft:cobbled_deepslate
setblock 61 253 559 minecraft:calcite
setblock 62 253 558 minecraft:calcite
fill 62 253 559 65 253 559 minecraft:cobbled_deepslate
setblock 62 253 598 minecraft:calcite
fill 63 253 558 66 253 558 minecraft:cobbled_deepslate
setblock 63 253 597 minecraft:calcite
fill 63 253 598 66 253 598 minecraft:cobbled_deepslate
fill 64 253 597 64 256 597 minecraft:cobbled_deepslate
setblock 65 253 560 minecraft:calcite
setblock 66 253 559 minecraft:calcite
fill 66 253 560 66 256 560 minecraft:cobbled_deepslate
fill 66 253 596 66 255 596 minecraft:cobbled_deepslate
setblock 67 253 558 minecraft:calcite
fill 67 253 559 67 256 559 minecraft:cobbled_deepslate
setblock 67 253 598 minecraft:calcite
fill 68 253 558 68 256 558 minecraft:cobbled_deepslate
setblock 68 253 597 minecraft:calcite
fill 68 253 598 68 256 598 minecraft:cobbled_deepslate
setblock 69 253 595 minecraft:cobbled_deepslate
setblock 69 253 596 minecraft:calcite
fill 69 253 597 69 256 597 minecraft:cobbled_deepslate
setblock 70 253 560 minecraft:calcite
setblock 70 253 595 minecraft:calcite
fill 70 253 596 70 256 596 minecraft:cobbled_deepslate
setblock 71 253 559 minecraft:calcite
fill 71 253 560 71 256 560 minecraft:cobbled_deepslate
fill 71 253 595 71 254 595 minecraft:cobbled_deepslate
setblock 72 253 558 minecraft:calcite
fill 72 253 559 72 256 559 minecraft:cobbled_deepslate
setblock 72 253 598 minecraft:calcite
fill 73 253 558 73 256 558 minecraft:cobbled_deepslate
setblock 73 253 595 minecraft:cobbled_deepslate
setblock 73 253 597 minecraft:calcite
fill 73 253 598 73 256 598 minecraft:cobbled_deepslate
setblock 74 253 560 minecraft:cobbled_deepslate
setblock 74 253 596 minecraft:calcite
fill 74 253 597 74 256 597 minecraft:cobbled_deepslate
setblock 75 253 559 minecraft:cobbled_deepslate
fill 75 253 596 75 255 596 minecraft:cobbled_deepslate
setblock 76 253 559 minecraft:calcite
setblock 77 253 558 minecraft:calcite
fill 77 253 559 77 255 559 minecraft:cobbled_deepslate
setblock 77 253 598 minecraft:calcite
fill 78 253 558 78 256 558 minecraft:cobbled_deepslate
setblock 78 253 597 minecraft:calcite
fill 78 253 598 78 256 598 minecraft:cobbled_deepslate
setblock 79 253 596 minecraft:calcite
fill 79 253 597 79 256 597 minecraft:cobbled_deepslate
setblock 81 253 558 minecraft:cobbled_deepslate
setblock 82 253 558 minecraft:calcite
fill 82 253 596 83 253 596 minecraft:cobbled_deepslate
setblock 82 253 598 minecraft:calcite
fill 83 253 558 83 256 558 minecraft:cobbled_deepslate
setblock 83 253 597 minecraft:calcite
fill 83 253 598 83 256 598 minecraft:cobbled_deepslate
setblock 84 253 596 minecraft:calcite
fill 84 253 597 84 256 597 minecraft:cobbled_deepslate
fill 85 253 558 86 253 558 minecraft:cobbled_deepslate
fill 85 253 596 85 256 596 minecraft:cobbled_deepslate
fill 86 253 575 86 253 578 minecraft:cobbled_deepslate
setblock 86 253 579 minecraft:calcite
fill 86 253 580 86 255 581 minecraft:cobbled_deepslate
fill 86 253 592 86 253 593 minecraft:cobbled_deepslate
setblock 86 253 594 minecraft:calcite
fill 86 253 595 86 256 595 minecraft:cobbled_deepslate
setblock 87 253 558 minecraft:calcite
fill 87 253 559 87 256 559 minecraft:cobbled_deepslate
fill 87 253 571 87 253 572 minecraft:cobbled_deepslate
setblock 87 253 573 minecraft:calcite
fill 87 253 574 87 256 574 minecraft:cobbled_deepslate
setblock 87 253 577 minecraft:cobbled_deepslate
setblock 87 253 578 minecraft:calcite
fill 87 253 579 87 256 579 minecraft:cobbled_deepslate
fill 87 253 581 87 253 582 minecraft:cobbled_deepslate
setblock 87 253 583 minecraft:calcite
fill 87 253 584 87 256 584 minecraft:cobbled_deepslate
setblock 87 253 588 minecraft:calcite
fill 87 253 589 87 256 589 minecraft:cobbled_deepslate
setblock 87 253 593 minecraft:calcite
fill 87 253 594 87 256 594 minecraft:cobbled_deepslate
setblock 87 253 598 minecraft:calcite
fill 88 253 558 88 256 558 minecraft:cobbled_deepslate
setblock 88 253 562 minecraft:calcite
fill 88 253 568 88 256 568 minecraft:cobbled_deepslate
setblock 88 253 572 minecraft:calcite
fill 88 253 573 88 256 573 minecraft:cobbled_deepslate
setblock 88 253 577 minecraft:calcite
fill 88 253 578 88 256 578 minecraft:cobbled_deepslate
setblock 88 253 581 minecraft:cobbled_deepslate
setblock 88 253 582 minecraft:calcite
fill 88 253 583 88 256 583 minecraft:cobbled_deepslate
setblock 88 253 587 minecraft:calcite
fill 88 253 588 88 256 588 minecraft:cobbled_deepslate
setblock 88 253 592 minecraft:calcite
fill 88 253 593 88 256 593 minecraft:cobbled_deepslate
setblock 88 253 597 minecraft:calcite
fill 88 253 598 88 256 598 minecraft:cobbled_deepslate
fill 48 254 558 49 254 559 minecraft:cobbled_deepslate
setblock 48 254 561 minecraft:calcite
fill 48 254 562 48 257 562 minecraft:cobbled_deepslate
setblock 48 254 566 minecraft:calcite
fill 48 254 567 48 257 567 minecraft:cobbled_deepslate
setblock 48 254 571 minecraft:calcite
fill 48 254 572 48 257 572 minecraft:cobbled_deepslate
setblock 48 254 576 minecraft:calcite
fill 48 254 577 48 257 577 minecraft:cobbled_deepslate
setblock 48 254 581 minecraft:calcite
fill 48 254 582 48 257 582 minecraft:cobbled_deepslate
setblock 48 254 586 minecraft:calcite
fill 48 254 587 48 257 587 minecraft:cobbled_deepslate
setblock 48 254 591 minecraft:calcite
fill 48 254 592 48 257 592 minecraft:cobbled_deepslate
setblock 48 254 596 minecraft:calcite
fill 48 254 597 48 257 597 minecraft:cobbled_deepslate
setblock 49 254 560 minecraft:calcite
fill 49 254 561 49 257 561 minecraft:cobbled_deepslate
fill 49 254 563 49 254 564 minecraft:cobbled_deepslate
setblock 49 254 565 minecraft:calcite
fill 49 254 566 49 257 566 minecraft:cobbled_deepslate
setblock 49 254 569 minecraft:cobbled_deepslate
setblock 49 254 570 minecraft:calcite
fill 49 254 571 49 257 571 minecraft:cobbled_deepslate
setblock 49 254 575 minecraft:calcite
fill 49 254 576 49 257 576 minecraft:cobbled_deepslate
setblock 49 254 580 minecraft:calcite
fill 49 254 581 49 257 581 minecraft:cobbled_deepslate
setblock 49 254 585 minecraft:calcite
fill 49 254 586 49 257 586 minecraft:cobbled_deepslate
setblock 49 254 590 minecraft:calcite
setblock 49 254 591 minecraft:cobbled_deepslate
setblock 49 254 595 minecraft:calcite
fill 49 254 596 49 256 596 minecraft:cobbled_deepslate
setblock 50 254 558 minecraft:cobbled_deepslate
setblock 50 254 559 minecraft:calcite
setblock 50 254 569 minecraft:calcite
fill 50 254 570 50 255 570 minecraft:cobbled_deepslate
setblock 50 254 574 minecraft:calcite
fill 50 254 575 50 257 575 minecraft:cobbled_deepslate
setblock 50 254 579 minecraft:calcite
fill 50 254 580 50 257 580 minecraft:cobbled_deepslate
setblock 50 254 584 minecraft:calcite
setblock 51 254 558 minecraft:calcite
fill 51 254 559 51 257 559 minecraft:cobbled_deepslate
setblock 51 254 573 minecraft:calcite
fill 51 254 574 51 256 574 minecraft:cobbled_deepslate
fill 51 254 576 51 255 576 minecraft:cobbled_deepslate
setblock 51 254 578 minecraft:calcite
fill 51 254 579 51 257 579 minecraft:cobbled_deepslate
setblock 51 254 598 minecraft:calcite
fill 52 254 558 52 257 558 minecraft:cobbled_deepslate
setblock 52 254 597 minecraft:calcite
fill 52 254 598 52 257 598 minecraft:cobbled_deepslate
fill 53 254 559 54 254 559 minecraft:cobbled_deepslate
fill 53 254 597 53 255 597 minecraft:cobbled_deepslate
setblock 55 254 559 minecraft:calcite
setblock 56 254 558 minecraft:calcite
fill 56 254 559 59 254 559 minecraft:cobbled_deepslate
setblock 56 254 598 minecraft:calcite
fill 57 254 558 60 254 558 minecraft:cobbled_deepslate
fill 57 254 598 60 254 598 minecraft:cobbled_deepslate
setblock 60 254 559 minecraft:calcite
setblock 61 254 558 minecraft:calcite
fill 61 254 559 64 254 559 minecraft:cobbled_deepslate
setblock 61 254 598 minecraft:calcite
fill 62 254 558 65 254 558 minecraft:cobbled_deepslate
fill 62 254 598 65 254 598 minecraft:cobbled_deepslate
fill 63 254 597 63 257 597 minecraft:cobbled_deepslate
setblock 64 254 560 minecraft:calcite
setblock 65 254 559 minecraft:calcite
fill 65 254 560 65 257 560 minecraft:cobbled_deepslate
setblock 66 254 558 minecraft:calcite
fill 66 254 559 66 257 559 minecraft:cobbled_deepslate
setblock 66 254 598 minecraft:calcite
fill 67 254 558 67 257 558 minecraft:cobbled_deepslate
setblock 67 254 597 minecraft:calcite
fill 67 254 598 67 257 598 minecraft:cobbled_deepslate
setblock 68 254 561 minecraft:calcite
setblock 68 254 596 minecraft:calcite
fill 68 254 597 68 257 597 minecraft:cobbled_deepslate
setblock 69 254 559 minecraft:cobbled_deepslate
setblock 69 254 560 minecraft:calcite
fill 69 254 561 70 256 561 minecraft:cobbled_deepslate
setblock 69 254 595 minecraft:calcite
fill 69 254 596 69 257 596 minecraft:cobbled_deepslate
setblock 70 254 559 minecraft:calcite
fill 70 254 560 70 257 560 minecraft:cobbled_deepslate
fill 70 254 594 72 256 594 minecraft:light_blue_stained_glass
setblock 70 254 595 minecraft:cobbled_deepslate
setblock 71 254 558 minecraft:calcite
fill 71 254 559 71 257 559 minecraft:cobbled_deepslate
fill 71 254 593 71 257 593 minecraft:light_blue_stained_glass
setblock 71 254 598 minecraft:calcite
fill 72 254 558 72 257 558 minecraft:cobbled_deepslate
setblock 72 254 597 minecraft:calcite
fill 72 254 598 72 257 598 minecraft:cobbled_deepslate
setblock 73 254 596 minecraft:calcite
fill 73 254 597 73 257 597 minecraft:cobbled_deepslate
setblock 74 254 560 minecraft:calcite
fill 74 254 596 74 256 596 minecraft:cobbled_deepslate
setblock 75 254 559 minecraft:calcite
setblock 76 254 558 minecraft:calcite
fill 76 254 559 76 257 559 minecraft:cobbled_deepslate
setblock 76 254 598 minecraft:calcite
fill 77 254 558 77 257 558 minecraft:cobbled_deepslate
setblock 77 254 597 minecraft:calcite
fill 77 254 598 77 257 598 minecraft:cobbled_deepslate
setblock 78 254 596 minecraft:calcite
fill 78 254 597 78 257 597 minecraft:cobbled_deepslate
setblock 81 254 558 minecraft:calcite
setblock 81 254 598 minecraft:calcite
fill 82 254 558 82 257 558 minecraft:cobbled_deepslate
setblock 82 254 596 minecraft:cobbled_deepslate
setblock 82 254 597 minecraft:calcite
fill 82 254 598 82 257 598 minecraft:cobbled_deepslate
setblock 83 254 596 minecraft:calcite
fill 83 254 597 83 257 597 minecraft:cobbled_deepslate
fill 84 254 596 84 256 596 minecraft:cobbled_deepslate
setblock 85 254 558 minecraft:cobbled_deepslate
setblock 85 254 559 minecraft:calcite
setblock 86 254 558 minecraft:calcite
fill 86 254 559 86 257 559 minecraft:cobbled_deepslate
fill 86 254 575 86 254 577 minecraft:cobbled_deepslate
setblock 86 254 578 minecraft:calcite
fill 86 254 579 86 257 579 minecraft:cobbled_deepslate
setblock 86 254 582 minecraft:cobbled_deepslate
setblock 86 254 583 minecraft:calcite
fill 86 254 584 86 257 584 minecraft:cobbled_deepslate
setblock 86 254 592 minecraft:cobbled_deepslate
setblock 86 254 593 minecraft:calcite
fill 86 254 594 86 256 594 minecraft:cobbled_deepslate
setblock 86 254 598 minecraft:calcite
fill 87 254 558 87 257 558 minecraft:cobbled_deepslate
fill 87 254 560 88 254 560 minecraft:cobbled_deepslate
setblock 87 254 571 minecraft:cobbled_deepslate
setblock 87 254 572 minecraft:calcite
fill 87 254 573 87 257 573 minecraft:cobbled_deepslate
setblock 87 254 577 minecraft:calcite
fill 87 254 578 87 257 578 minecraft:cobbled_deepslate
setblock 87 254 581 minecraft:cobbled_deepslate
setblock 87 254 582 minecraft:calcite
fill 87 254 583 87 257 583 minecraft:cobbled_deepslate
fill 87 254 585 87 254 586 minecraft:cobbled_deepslate
setblock 87 254 587 minecraft:calcite
fill 87 254 588 87 257 588 minecraft:cobbled_deepslate
setblock 87 254 592 minecraft:calcite
fill 87 254 593 87 257 593 minecraft:cobbled_deepslate
setblock 87 254 597 minecraft:calcite
fill 87 254 598 87 257 598 minecraft:cobbled_deepslate
fill 88 254 559 88 255 559 minecraft:cobbled_deepslate
setblock 88 254 561 minecraft:calcite
fill 88 254 562 88 254 565 minecraft:cobbled_deepslate
setblock 88 254 566 minecraft:calcite
fill 88 254 567 88 257 567 minecraft:cobbled_deepslate
setblock 88 254 571 minecraft:calcite
fill 88 254 572 88 257 572 minecraft:cobbled_deepslate
setblock 88 254 576 minecraft:calcite
fill 88 254 577 88 257 577 minecraft:cobbled_deepslate
setblock 88 254 581 minecraft:calcite
fill 88 254 582 88 257 582 minecraft:cobbled_deepslate
setblock 88 254 586 minecraft:calcite
fill 88 254 587 88 257 587 minecraft:cobbled_deepslate
setblock 88 254 591 minecraft:calcite
fill 88 254 592 88 257 592 minecraft:cobbled_deepslate
setblock 88 254 596 minecraft:calcite
fill 88 254 597 88 257 597 minecraft:cobbled_deepslate
fill 48 255 558 48 255 559 minecraft:cobbled_deepslate
setblock 48 255 560 minecraft:calcite
fill 48 255 561 48 258 561 minecraft:cobbled_deepslate
setblock 48 255 564 minecraft:cobbled_deepslate
setblock 48 255 565 minecraft:calcite
fill 48 255 566 48 258 566 minecraft:cobbled_deepslate
setblock 48 255 570 minecraft:calcite
fill 48 255 571 48 258 571 minecraft:cobbled_deepslate
setblock 48 255 575 minecraft:calcite
fill 48 255 576 48 258 576 minecraft:cobbled_deepslate
setblock 48 255 580 minecraft:calcite
fill 48 255 581 48 258 581 minecraft:cobbled_deepslate
setblock 48 255 585 minecraft:calcite
fill 48 255 586 48 258 586 minecraft:cobbled_deepslate
setblock 48 255 590 minecraft:calcite
fill 48 255 591 48 257 591 minecraft:cobbled_deepslate
setblock 48 255 595 minecraft:calcite
fill 48 255 596 48 258 596 minecraft:cobbled_deepslate
setblock 49 255 558 minecraft:cobbled_deepslate
setblock 49 255 559 minecraft:calcite
fill 49 255 560 52 255 560 minecraft:cobbled_deepslate
setblock 49 255 563 minecraft:cobbled_deepslate
setblock 49 255 564 minecraft:calcite
fill 49 255 565 49 258 565 minecraft:cobbled_deepslate
setblock 49 255 569 minecraft:calcite
fill 49 255 570 49 258 570 minecraft:cobbled_deepslate
setblock 49 255 574 minecraft:calcite
fill 49 255 575 49 258 575 minecraft:cobbled_deepslate
setblock 49 255 579 minecraft:calcite
fill 49 255 580 49 258 580 minecraft:cobbled_deepslate
setblock 49 255 583 minecraft:cobbled_deepslate
setblock 49 255 584 minecraft:calcite
fill 49 255 585 49 258 585 minecraft:cobbled_deepslate
setblock 49 255 589 minecraft:calcite
setblock 49 255 594 minecraft:calcite
fill 49 255 595 49 256 595 minecraft:cobbled_deepslate
setblock 50 255 558 minecraft:calcite
fill 50 255 559 50 258 559 minecraft:cobbled_deepslate
fill 50 255 561 50 256 561 minecraft:cobbled_deepslate
setblock 50 255 573 minecraft:calcite
fill 50 255 574 50 258 574 minecraft:cobbled_deepslate
setblock 50 255 578 minecraft:calcite
fill 50 255 579 50 258 579 minecraft:cobbled_deepslate
setblock 50 255 583 minecraft:calcite
fill 50 255 584 50 257 584 minecraft:cobbled_deepslate
setblock 50 255 598 minecraft:calcite
fill 51 255 558 51 258 558 minecraft:cobbled_deepslate
setblock 51 255 573 minecraft:cobbled_deepslate
setblock 51 255 577 minecraft:calcite
fill 51 255 578 51 257 578 minecraft:cobbled_deepslate
setblock 51 255 597 minecraft:calcite
fill 51 255 598 51 258 598 minecraft:cobbled_deepslate
setblock 52 255 597 minecraft:cobbled_deepslate
setblock 53 255 559 minecraft:cobbled_deepslate
setblock 54 255 559 minecraft:calcite
setblock 55 255 558 minecraft:calcite
fill 55 255 559 58 255 559 minecraft:cobbled_deepslate
setblock 55 255 598 minecraft:calcite
fill 56 255 558 59 255 558 minecraft:cobbled_deepslate
fill 56 255 598 59 255 598 minecraft:cobbled_deepslate
setblock 59 255 559 minecraft:calcite
setblock 60 255 558 minecraft:calcite
fill 60 255 559 63 255 559 minecraft:cobbled_deepslate
setblock 60 255 598 minecraft:calcite
fill 61 255 558 64 255 558 minecraft:cobbled_deepslate
fill 61 255 598 64 255 598 minecraft:cobbled_deepslate
setblock 62 255 560 minecraft:cobbled_deepslate
setblock 62 255 597 minecraft:cobbled_deepslate
setblock 63 255 560 minecraft:calcite
setblock 64 255 559 minecraft:calcite
fill 64 255 560 64 258 560 minecraft:cobbled_deepslate
setblock 65 255 558 minecraft:calcite
fill 65 255 559 65 258 559 minecraft:cobbled_deepslate
setblock 65 255 596 minecraft:cobbled_deepslate
setblock 65 255 598 minecraft:calcite
fill 66 255 558 66 258 558 minecraft:cobbled_deepslate
setblock 66 255 561 minecraft:cobbled_deepslate
setblock 66 255 597 minecraft:calcite
fill 66 255 598 66 258 598 minecraft:cobbled_deepslate
setblock 67 255 560 minecraft:cobbled_deepslate
setblock 67 255 561 minecraft:calcite
setblock 67 255 596 minecraft:calcite
fill 67 255 597 67 258 597 minecraft:cobbled_deepslate
setblock 68 255 560 minecraft:calcite
fill 68 255 561 68 258 561 minecraft:cobbled_deepslate
fill 68 255 596 68 258 596 minecraft:cobbled_deepslate
setblock 69 255 559 minecraft:calcite
fill 69 255 560 69 258 560 minecraft:cobbled_deepslate
fill 69 255 595 73 255 595 minecraft:light_blue_stained_glass
setblock 70 255 558 minecraft:calcite
fill 70 255 559 70 258 559 minecraft:cobbled_deepslate
fill 70 255 593 70 256 593 minecraft:light_blue_stained_glass
setblock 70 255 598 minecraft:calcite
fill 71 255 558 71 258 558 minecraft:cobbled_deepslate
fill 71 255 592 71 257 592 minecraft:light_blue_stained_glass
setblock 71 255 597 minecraft:calcite
fill 71 255 598 71 258 598 minecraft:cobbled_deepslate
fill 72 255 593 72 256 593 minecraft:light_blue_stained_glass
setblock 72 255 596 minecraft:calcite
fill 72 255 597 72 258 597 minecraft:cobbled_deepslate
setblock 73 255 560 minecraft:calcite
fill 73 255 596 73 256 596 minecraft:cobbled_deepslate
setblock 74 255 559 minecraft:calcite
setblock 74 255 560 minecraft:cobbled_deepslate
setblock 75 255 558 minecraft:calcite
fill 75 255 559 75 258 559 minecraft:cobbled_deepslate
setblock 75 255 598 minecraft:calcite
fill 76 255 558 76 258 558 minecraft:cobbled_deepslate
setblock 76 255 597 minecraft:calcite
fill 76 255 598 76 258 598 minecraft:cobbled_deepslate
fill 77 255 597 77 257 597 minecraft:cobbled_deepslate
setblock 80 255 558 minecraft:calcite
setblock 80 255 598 minecraft:calcite
fill 81 255 558 81 258 558 minecraft:cobbled_deepslate
setblock 81 255 597 minecraft:calcite
fill 81 255 598 81 258 598 minecraft:cobbled_deepslate
fill 82 255 597 82 258 597 minecraft:cobbled_deepslate
setblock 83 255 596 minecraft:cobbled_deepslate
setblock 84 255 559 minecraft:calcite
setblock 85 255 558 minecraft:calcite
fill 85 255 559 85 258 559 minecraft:cobbled_deepslate
setblock 85 255 598 minecraft:calcite
fill 86 255 558 86 258 558 minecraft:cobbled_deepslate
fill 86 255 574 86 255 576 minecraft:cobbled_deepslate
setblock 86 255 577 minecraft:calcite
fill 86 255 578 86 258 578 minecraft:cobbled_deepslate
setblock 86 255 582 minecraft:calcite
fill 86 255 583 86 258 583 minecraft:cobbled_deepslate
fill 86 255 585 86 255 586 minecraft:cobbled_deepslate
setblock 86 255 592 minecraft:calcite
setblock 86 255 593 minecraft:cobbled_deepslate
setblock 86 255 597 minecraft:calcite
fill 86 255 598 86 258 598 minecraft:cobbled_deepslate
setblock 87 255 560 minecraft:cobbled_deepslate
setblock 87 255 561 minecraft:calcite
setblock 87 255 571 minecraft:calcite
fill 87 255 572 87 257 572 minecraft:cobbled_deepslate
setblock 87 255 576 minecraft:calcite
fill 87 255 577 87 258 577 minecraft:cobbled_deepslate
setblock 87 255 581 minecraft:calcite
fill 87 255 582 87 258 582 minecraft:cobbled_deepslate
setblock 87 255 585 minecraft:cobbled_deepslate
setblock 87 255 586 minecraft:calcite
fill 87 255 587 87 258 587 minecraft:cobbled_deepslate
setblock 87 255 591 minecraft:calcite
fill 87 255 592 87 258 592 minecraft:cobbled_deepslate
setblock 87 255 596 minecraft:calcite
fill 87 255 597 87 258 597 minecraft:cobbled_deepslate
setblock 88 255 560 minecraft:calcite
fill 88 255 561 88 255 564 minecraft:cobbled_deepslate
setblock 88 255 565 minecraft:calcite
fill 88 255 566 88 258 566 minecraft:cobbled_deepslate
setblock 88 255 570 minecraft:calcite
fill 88 255 571 88 258 571 minecraft:cobbled_deepslate
setblock 88 255 575 minecraft:calcite
fill 88 255 576 88 258 576 minecraft:cobbled_deepslate
setblock 88 255 580 minecraft:calcite
fill 88 255 581 88 258 581 minecraft:cobbled_deepslate
setblock 88 255 585 minecraft:calcite
fill 88 255 586 88 258 586 minecraft:cobbled_deepslate
setblock 88 255 590 minecraft:calcite
fill 88 255 591 88 258 591 minecraft:cobbled_deepslate
setblock 88 255 595 minecraft:calcite
fill 88 255 596 88 258 596 minecraft:cobbled_deepslate
setblock 48 256 558 minecraft:cobbled_deepslate
setblock 48 256 559 minecraft:calcite
fill 48 256 560 51 256 560 minecraft:cobbled_deepslate
setblock 48 256 564 minecraft:calcite
fill 48 256 565 48 259 565 minecraft:cobbled_deepslate
setblock 48 256 569 minecraft:calcite
fill 48 256 570 48 259 570 minecraft:cobbled_deepslate
setblock 48 256 574 minecraft:calcite
fill 48 256 575 48 259 575 minecraft:cobbled_deepslate
setblock 48 256 579 minecraft:calcite
fill 48 256 580 48 259 580 minecraft:cobbled_deepslate
setblock 48 256 584 minecraft:calcite
fill 48 256 585 48 259 585 minecraft:cobbled_deepslate
setblock 48 256 589 minecraft:calcite
fill 48 256 590 48 258 590 minecraft:cobbled_deepslate
setblock 48 256 594 minecraft:calcite
fill 48 256 595 48 258 595 minecraft:cobbled_deepslate
setblock 49 256 558 minecraft:calcite
fill 49 256 559 49 259 559 minecraft:cobbled_deepslate
setblock 49 256 563 minecraft:calcite
fill 49 256 564 49 259 564 minecraft:cobbled_deepslate
setblock 49 256 568 minecraft:calcite
fill 49 256 569 49 258 569 minecraft:cobbled_deepslate
setblock 49 256 573 minecraft:calcite
fill 49 256 574 49 259 574 minecraft:cobbled_deepslate
setblock 49 256 578 minecraft:calcite
fill 49 256 579 49 259 579 minecraft:cobbled_deepslate
setblock 49 256 583 minecraft:calcite
fill 49 256 584 49 259 584 minecraft:cobbled_deepslate
setblock 49 256 598 minecraft:calcite
fill 50 256 558 50 259 558 minecraft:cobbled_deepslate
setblock 50 256 568 minecraft:light[level=14]
setblock 50 256 572 minecraft:calcite
fill 50 256 573 50 257 573 minecraft:cobbled_deepslate
setblock 50 256 577 minecraft:calcite
fill 50 256 578 50 259 578 minecraft:cobbled_deepslate
setblock 50 256 581 minecraft:cobbled_deepslate
setblock 50 256 582 minecraft:calcite
fill 50 256 583 50 258 583 minecraft:cobbled_deepslate
setblock 50 256 592 minecraft:light[level=14]
setblock 50 256 597 minecraft:calcite
fill 50 256 598 50 259 598 minecraft:cobbled_deepslate
setblock 51 256 576 minecraft:calcite
fill 51 256 577 51 257 577 minecraft:cobbled_deepslate
setblock 51 256 581 minecraft:calcite
setblock 51 256 597 minecraft:cobbled_deepslate
setblock 52 256 560 minecraft:calcite
setblock 53 256 559 minecraft:calcite
setblock 54 256 558 minecraft:calcite
fill 54 256 559 57 256 559 minecraft:cobbled_deepslate
setblock 54 256 598 minecraft:calcite
fill 55 256 558 58 256 558 minecraft:cobbled_deepslate
fill 55 256 598 58 256 598 minecraft:cobbled_deepslate
setblock 58 256 559 minecraft:calcite
setblock 58 256 560 minecraft:light[level=14]
setblock 58 256 568 minecraft:light[level=14]
setblock 58 256 576 minecraft:light[level=14]
setblock 58 256 584 minecraft:light[level=14]
setblock 58 256 592 minecraft:light[level=14]
setblock 59 256 558 minecraft:calcite
fill 59 256 559 62 256 559 minecraft:cobbled_deepslate
setblock 59 256 598 minecraft:calcite
fill 60 256 558 63 256 558 minecraft:cobbled_deepslate
fill 60 256 598 63 256 598 minecraft:cobbled_deepslate
setblock 62 256 560 minecraft:calcite
setblock 63 256 559 minecraft:calcite
fill 63 256 560 63 259 560 minecraft:cobbled_deepslate
setblock 64 256 558 minecraft:calcite
fill 64 256 559 64 259 559 minecraft:cobbled_deepslate
setblock 64 256 598 minecraft:calcite
fill 65 256 558 65 259 558 minecraft:cobbled_deepslate
setblock 65 256 561 minecraft:cobbled_deepslate
setblock 65 256 597 minecraft:calcite
fill 65 256 598 65 259 598 minecraft:cobbled_deepslate
setblock 66 256 561 minecraft:calcite
setblock 66 256 568 minecraft:light[level=14]
setblock 66 256 576 minecraft:light[level=14]
setblock 66 256 584 minecraft:light[level=14]
setblock 66 256 592 minecraft:light[level=14]
setblock 66 256 596 minecraft:calcite
fill 66 256 597 66 259 597 minecraft:cobbled_deepslate
setblock 67 256 560 minecraft:calcite
fill 67 256 561 67 259 561 minecraft:cobbled_deepslate
fill 67 256 596 67 258 596 minecraft:cobbled_deepslate
setblock 68 256 559 minecraft:calcite
fill 68 256 560 68 259 560 minecraft:cobbled_deepslate
setblock 69 256 558 minecraft:calcite
fill 69 256 559 69 259 559 minecraft:cobbled_deepslate
setblock 69 256 598 minecraft:calcite
fill 70 256 558 70 259 558 minecraft:cobbled_deepslate
setblock 70 256 592 minecraft:light_blue_stained_glass
fill 70 256 595 72 256 595 minecraft:light_blue_stained_glass
setblock 70 256 597 minecraft:calcite
fill 70 256 598 70 259 598 minecraft:cobbled_deepslate
fill 71 256 590 71 257 591 minecraft:light_blue_stained_glass
setblock 71 256 596 minecraft:calcite
fill 71 256 597 71 259 597 minecraft:cobbled_deepslate
setblock 72 256 560 minecraft:calcite
setblock 72 256 592 minecraft:light_blue_stained_glass
fill 72 256 596 72 257 596 minecraft:cobbled_deepslate
setblock 73 256 559 minecraft:calcite
fill 73 256 560 73 257 560 minecraft:cobbled_deepslate
setblock 74 256 558 minecraft:calcite
fill 74 256 559 74 258 559 minecraft:cobbled_deepslate
setblock 74 256 560 minecraft:light[level=14]
setblock 74 256 568 minecraft:light[level=14]
setblock 74 256 576 minecraft:light[level=14]
setblock 74 256 584 minecraft:light[level=14]
setblock 74 256 592 minecraft:light[level=14]
setblock 74 256 598 minecraft:calcite
fill 75 256 558 75 259 558 minecraft:cobbled_deepslate
setblock 75 256 597 minecraft:calcite
fill 75 256 598 75 259 598 minecraft:cobbled_deepslate
fill 76 256 597 76 257 597 minecraft:cobbled_deepslate
setblock 79 256 558 minecraft:calcite
setblock 79 256 598 minecraft:calcite
fill 80 256 558 80 259 558 minecraft:cobbled_deepslate
setblock 80 256 597 minecraft:calcite
fill 80 256 598 80 259 598 minecraft:cobbled_deepslate
fill 81 256 597 81 258 597 minecraft:cobbled_deepslate
setblock 82 256 560 minecraft:light[level=14]
setblock 82 256 568 minecraft:light[level=14]
setblock 82 256 576 minecraft:light[level=14]
setblock 82 256 584 minecraft:light[level=14]
setblock 82 256 592 minecraft:light[level=14]
setblock 84 256 558 minecraft:calcite
fill 84 256 559 84 259 559 minecraft:cobbled_deepslate
setblock 84 256 598 minecraft:calcite
fill 85 256 558 85 259 558 minecraft:cobbled_deepslate
fill 85 256 579 85 257 580 minecraft:cobbled_deepslate
setblock 85 256 597 minecraft:calcite
fill 85 256 598 85 259 598 minecraft:cobbled_deepslate
setblock 86 256 575 minecraft:cobbled_deepslate
setblock 86 256 576 minecraft:calcite
fill 86 256 577 86 259 577 minecraft:cobbled_deepslate
setblock 86 256 580 minecraft:cobbled_deepslate
setblock 86 256 581 minecraft:calcite
fill 86 256 582 86 259 582 minecraft:cobbled_deepslate
setblock 86 256 585 minecraft:cobbled_deepslate
setblock 86 256 586 minecraft:calcite
setblock 86 256 596 minecraft:calcite
fill 86 256 597 86 259 597 minecraft:cobbled_deepslate
setblock 87 256 560 minecraft:calcite
fill 87 256 561 88 258 561 minecraft:cobbled_deepslate
setblock 87 256 575 minecraft:calcite
fill 87 256 576 87 259 576 minecraft:cobbled_deepslate
setblock 87 256 580 minecraft:calcite
fill 87 256 581 87 259 581 minecraft:cobbled_deepslate
setblock 87 256 585 minecraft:calcite
fill 87 256 586 87 259 586 minecraft:cobbled_deepslate
setblock 87 256 590 minecraft:calcite
fill 87 256 591 87 258 591 minecraft:cobbled_deepslate
setblock 87 256 595 minecraft:calcite
fill 87 256 596 87 259 596 minecraft:cobbled_deepslate
setblock 88 256 559 minecraft:calcite
fill 88 256 560 88 259 560 minecraft:cobbled_deepslate
fill 88 256 562 88 256 563 minecraft:cobbled_deepslate
setblock 88 256 564 minecraft:calcite
fill 88 256 565 88 259 565 minecraft:cobbled_deepslate
setblock 88 256 569 minecraft:calcite
fill 88 256 570 88 259 570 minecraft:cobbled_deepslate
setblock 88 256 574 minecraft:calcite
fill 88 256 575 88 259 575 minecraft:cobbled_deepslate
setblock 88 256 579 minecraft:calcite
fill 88 256 580 88 259 580 minecraft:cobbled_deepslate
setblock 88 256 584 minecraft:calcite
fill 88 256 585 88 259 585 minecraft:cobbled_deepslate
setblock 88 256 589 minecraft:calcite
fill 88 256 590 88 259 590 minecraft:cobbled_deepslate
setblock 88 256 594 minecraft:calcite
fill 88 256 595 88 259 595 minecraft:cobbled_deepslate
setblock 48 257 558 minecraft:calcite
fill 48 257 559 48 259 560 minecraft:cobbled_deepslate
setblock 48 257 563 minecraft:calcite
fill 48 257 564 48 260 564 minecraft:cobbled_deepslate
setblock 48 257 568 minecraft:calcite
fill 48 257 569 48 260 569 minecraft:cobbled_deepslate
setblock 48 257 573 minecraft:calcite
fill 48 257 574 48 260 574 minecraft:cobbled_deepslate
setblock 48 257 578 minecraft:calcite
fill 48 257 579 48 260 579 minecraft:cobbled_deepslate
setblock 48 257 583 minecraft:calcite
fill 48 257 584 48 260 584 minecraft:cobbled_deepslate
setblock 48 257 588 minecraft:calcite
fill 48 257 589 48 259 589 minecraft:cobbled_deepslate
setblock 48 257 593 minecraft:calcite
fill 48 257 594 48 258 594 minecraft:cobbled_deepslate
setblock 48 257 598 minecraft:calcite
fill 49 257 558 49 260 558 minecraft:cobbled_deepslate
fill 49 257 560 50 257 560 minecraft:cobbled_deepslate
setblock 49 257 562 minecraft:calcite
fill 49 257 563 49 260 563 minecraft:cobbled_deepslate
setblock 49 257 567 minecraft:calcite
fill 49 257 568 49 259 568 minecraft:cobbled_deepslate
setblock 49 257 572 minecraft:calcite
fill 49 257 573 49 260 573 minecraft:cobbled_deepslate
setblock 49 257 577 minecraft:calcite
fill 49 257 578 49 260 578 minecraft:cobbled_deepslate
setblock 49 257 582 minecraft:calcite
fill 49 257 583 49 260 583 minecraft:cobbled_deepslate
setblock 49 257 587 minecraft:calcite
setblock 49 257 597 minecraft:calcite
fill 49 257 598 49 259 598 minecraft:cobbled_deepslate
setblock 50 257 561 minecraft:calcite
setblock 50 257 572 minecraft:cobbled_deepslate
setblock 50 257 576 minecraft:calcite
fill 50 257 577 50 259 577 minecraft:cobbled_deepslate
setblock 50 257 581 minecraft:calcite
fill 50 257 582 50 259 582 minecraft:cobbled_deepslate
setblock 51 257 560 minecraft:calcite
setblock 51 257 580 minecraft:calcite
setblock 52 257 559 minecraft:calcite
setblock 53 257 558 minecraft:calcite
fill 53 257 559 56 257 559 minecraft:cobbled_deepslate
setblock 53 257 598 minecraft:calcite
fill 54 257 558 57 257 558 minecraft:cobbled_deepslate
fill 54 257 560 56 260 560 minecraft:light_blue_stained_glass
setblock 54 257 598 minecraft:cobbled_deepslate
setblock 57 257 559 minecraft:calcite
setblock 58 257 558 minecraft:calcite
fill 58 257 559 61 257 559 minecraft:cobbled_deepslate
fill 59 257 558 62 257 558 minecraft:cobbled_deepslate
fill 59 257 598 62 257 598 minecraft:cobbled_deepslate
setblock 61 257 560 minecraft:calcite
setblock 62 257 559 minecraft:calcite
fill 62 257 560 62 260 560 minecraft:cobbled_deepslate
setblock 63 257 558 minecraft:calcite
fill 63 257 559 63 260 559 minecraft:cobbled_deepslate
setblock 63 257 598 minecraft:calcite
fill 64 257 558 64 260 558 minecraft:cobbled_deepslate
setblock 64 257 597 minecraft:calcite
fill 64 257 598 64 260 598 minecraft:cobbled_deepslate
setblock 65 257 561 minecraft:calcite
fill 65 257 597 65 260 597 minecraft:cobbled_deepslate
setblock 66 257 560 minecraft:calcite
fill 66 257 561 66 260 561 minecraft:cobbled_deepslate
setblock 66 257 596 minecraft:cobbled_deepslate
setblock 67 257 559 minecraft:calcite
fill 67 257 560 67 260 560 minecraft:cobbled_deepslate
setblock 68 257 558 minecraft:calcite
fill 68 257 559 68 260 559 minecraft:cobbled_deepslate
setblock 68 257 598 minecraft:calcite
fill 69 257 558 69 260 558 minecraft:cobbled_deepslate
setblock 69 257 561 minecraft:cobbled_deepslate
setblock 69 257 597 minecraft:calcite
fill 69 257 598 69 260 598 minecraft:cobbled_deepslate
setblock 70 257 596 minecraft:calcite
fill 70 257 597 70 260 597 minecraft:cobbled_deepslate
setblock 71 257 560 minecraft:calcite
fill 71 257 594 71 257 595 minecraft:light_blue_stained_glass
setblock 71 257 596 minecraft:cobbled_deepslate
setblock 72 257 559 minecraft:calcite
fill 72 257 560 72 258 560 minecraft:cobbled_deepslate
setblock 73 257 558 minecraft:calcite
fill 73 257 559 73 259 559 minecraft:cobbled_deepslate
setblock 73 257 598 minecraft:calcite
fill 74 257 558 74 260 558 minecraft:cobbled_deepslate
setblock 74 257 597 minecraft:calcite
fill 74 257 598 74 260 598 minecraft:cobbled_deepslate
fill 75 257 597 75 258 597 minecraft:cobbled_deepslate
setblock 78 257 558 minecraft:calcite
setblock 78 257 598 minecraft:calcite
fill 79 257 558 79 259 558 minecraft:cobbled_deepslate
setblock 79 257 597 minecraft:calcite
fill 79 257 598 79 260 598 minecraft:cobbled_deepslate
setblock 80 257 597 minecraft:cobbled_deepslate
setblock 83 257 558 minecraft:calcite
setblock 83 257 559 minecraft:cobbled_deepslate
setblock 83 257 598 minecraft:calcite
fill 84 257 558 84 260 558 minecraft:cobbled_deepslate
setblock 84 257 597 minecraft:calcite
fill 84 257 598 84 260 598 minecraft:cobbled_deepslate
setblock 85 257 581 minecraft:calcite
fill 85 257 582 85 260 582 minecraft:cobbled_deepslate
setblock 85 257 596 minecraft:calcite
fill 85 257 597 85 259 597 minecraft:cobbled_deepslate
setblock 86 257 575 minecraft:calcite
fill 86 257 576 86 259 576 minecraft:cobbled_deepslate
setblock 86 257 580 minecraft:calcite
fill 86 257 581 86 260 581 minecraft:cobbled_deepslate
setblock 86 257 585 minecraft:calcite
fill 86 257 586 86 259 587 minecraft:cobbled_deepslate
setblock 86 257 596 minecraft:cobbled_deepslate
setblock 87 257 559 minecraft:calcite
fill 87 257 560 87 260 560 minecraft:cobbled_deepslate
fill 87 257 562 88 257 562 minecraft:cobbled_deepslate
setblock 87 257 574 minecraft:calcite
fill 87 257 575 87 260 575 minecraft:cobbled_deepslate
setblock 87 257 579 minecraft:calcite
fill 87 257 580 87 260 580 minecraft:cobbled_deepslate
setblock 87 257 584 minecraft:calcite
fill 87 257 585 87 260 585 minecraft:cobbled_deepslate
setblock 87 257 589 minecraft:calcite
fill 87 257 590 87 260 590 minecraft:cobbled_deepslate
setblock 87 257 594 minecraft:calcite
fill 87 257 595 87 258 595 minecraft:cobbled_deepslate
setblock 88 257 558 minecraft:calcite
fill 88 257 559 88 260 559 minecraft:cobbled_deepslate
setblock 88 257 563 minecraft:calcite
fill 88 257 564 88 260 564 minecraft:cobbled_deepslate
setblock 88 257 568 minecraft:calcite
fill 88 257 569 88 260 569 minecraft:cobbled_deepslate
setblock 88 257 573 minecraft:calcite
fill 88 257 574 88 260 574 minecraft:cobbled_deepslate
setblock 88 257 578 minecraft:calcite
fill 88 257 579 88 260 579 minecraft:cobbled_deepslate
setblock 88 257 583 minecraft:calcite
fill 88 257 584 88 260 584 minecraft:cobbled_deepslate
setblock 88 257 588 minecraft:calcite
fill 88 257 589 88 260 589 minecraft:cobbled_deepslate
setblock 88 257 593 minecraft:calcite
fill 88 257 594 88 260 594 minecraft:cobbled_deepslate
setblock 88 257 598 minecraft:calcite
fill 48 258 558 48 261 558 minecraft:cobbled_deepslate
setblock 48 258 562 minecraft:calcite
fill 48 258 563 48 261 563 minecraft:cobbled_deepslate
setblock 48 258 567 minecraft:calcite
fill 48 258 568 48 261 568 minecraft:cobbled_deepslate
setblock 48 258 572 minecraft:calcite
fill 48 258 573 48 261 573 minecraft:cobbled_deepslate
setblock 48 258 577 minecraft:calcite
fill 48 258 578 48 261 578 minecraft:cobbled_deepslate
setblock 48 258 582 minecraft:calcite
fill 48 258 583 48 261 583 minecraft:cobbled_deepslate
setblock 48 258 587 minecraft:calcite
fill 48 258 588 48 261 588 minecraft:cobbled_deepslate
setblock 48 258 597 minecraft:calcite
fill 48 258 598 48 260 598 minecraft:cobbled_deepslate
setblock 49 258 560 minecraft:cobbled_deepslate
setblock 49 258 561 minecraft:calcite
fill 49 258 562 49 261 562 minecraft:cobbled_deepslate
setblock 49 258 566 minecraft:calcite
fill 49 258 567 49 261 567 minecraft:cobbled_deepslate
setblock 49 258 571 minecraft:calcite
fill 49 258 572 49 259 572 minecraft:cobbled_deepslate
setblock 49 258 576 minecraft:calcite
fill 49 258 577 49 261 577 minecraft:cobbled_deepslate
setblock 49 258 581 minecraft:calcite
fill 49 258 582 49 261 582 minecraft:cobbled_deepslate
setblock 49 258 586 minecraft:calcite
setblock 50 258 560 minecraft:calcite
setblock 50 258 561 minecraft:cobbled_deepslate
setblock 50 258 575 minecraft:calcite
fill 50 258 576 50 259 576 minecraft:cobbled_deepslate
setblock 50 258 580 minecraft:calcite
fill 50 258 581 50 259 581 minecraft:cobbled_deepslate
setblock 51 258 559 minecraft:calcite
setblock 52 258 558 minecraft:calcite
fill 52 258 559 55 258 559 minecraft:cobbled_deepslate
setblock 52 258 598 minecraft:calcite
fill 53 258 558 56 258 558 minecraft:cobbled_deepslate
fill 54 258 561 56 260 561 minecraft:light_blue_stained_glass
fill 55 258 562 55 260 562 minecraft:light_blue_stained_glass
setblock 56 258 559 minecraft:calcite
setblock 57 258 558 minecraft:calcite
fill 57 258 559 60 258 559 minecraft:cobbled_deepslate
fill 58 258 558 61 258 558 minecraft:cobbled_deepslate
fill 60 258 598 61 258 598 minecraft:cobbled_deepslate
setblock 61 258 559 minecraft:calcite
fill 61 258 560 61 261 560 minecraft:cobbled_deepslate
setblock 62 258 558 minecraft:calcite
fill 62 258 559 62 261 559 minecraft:cobbled_deepslate
setblock 62 258 598 minecraft:calcite
fill 63 258 558 63 261 558 minecraft:cobbled_deepslate
setblock 63 258 597 minecraft:calcite
fill 63 258 598 63 261 598 minecraft:cobbled_deepslate
fill 64 258 597 64 261 597 minecraft:cobbled_deepslate
setblock 65 258 560 minecraft:calcite
fill 65 258 561 65 261 561 minecraft:cobbled_deepslate
setblock 66 258 559 minecraft:calcite
fill 66 258 560 66 261 560 minecraft:cobbled_deepslate
setblock 67 258 558 minecraft:calcite
fill 67 258 559 67 261 559 minecraft:cobbled_deepslate
setblock 67 258 598 minecraft:calcite
fill 68 258 558 68 261 558 minecraft:cobbled_deepslate
setblock 68 258 597 minecraft:calcite
fill 68 258 598 68 261 598 minecraft:cobbled_deepslate
setblock 69 258 596 minecraft:calcite
fill 69 258 597 69 261 597 minecraft:cobbled_deepslate
setblock 70 258 560 minecraft:calcite
setblock 70 258 596 minecraft:cobbled_deepslate
setblock 71 258 559 minecraft:calcite
fill 71 258 560 71 259 560 minecraft:cobbled_deepslate
setblock 72 258 558 minecraft:calcite
fill 72 258 559 72 260 559 minecraft:cobbled_deepslate
setblock 72 258 598 minecraft:calcite
fill 73 258 558 73 261 558 minecraft:cobbled_deepslate
setblock 73 258 597 minecraft:calcite
fill 73 258 598 73 261 598 minecraft:cobbled_deepslate
setblock 74 258 597 minecraft:cobbled_deepslate
setblock 77 258 558 minecraft:calcite
setblock 77 258 598 minecraft:calcite
fill 78 258 558 78 259 558 minecraft:cobbled_deepslate
fill 78 258 598 78 260 598 minecraft:cobbled_deepslate
setblock 82 258 558 minecraft:calcite
setblock 82 258 598 minecraft:calcite
fill 83 258 558 83 261 558 minecraft:cobbled_deepslate
setblock 83 258 597 minecraft:calcite
fill 83 258 598 83 261 598 minecraft:cobbled_deepslate
fill 84 258 597 84 259 597 minecraft:cobbled_deepslate
setblock 85 258 579 minecraft:cobbled_deepslate
setblock 85 258 580 minecraft:calcite
fill 85 258 581 85 261 581 minecraft:cobbled_deepslate
fill 85 258 583 85 259 583 minecraft:cobbled_deepslate
setblock 86 258 559 minecraft:calcite
setblock 86 258 579 minecraft:calcite
fill 86 258 580 86 261 580 minecraft:cobbled_deepslate
setblock 86 258 584 minecraft:calcite
fill 86 258 585 86 261 585 minecraft:cobbled_deepslate
setblock 87 258 558 minecraft:calcite
fill 87 258 559 87 261 559 minecraft:cobbled_deepslate
setblock 87 258 562 minecraft:cobbled_deepslate
setblock 87 258 573 minecraft:calcite
fill 87 258 574 87 260 574 minecraft:cobbled_deepslate
setblock 87 258 578 minecraft:calcite
fill 87 258 579 87 261 579 minecraft:cobbled_deepslate
setblock 87 258 583 minecraft:calcite
fill 87 258 584 87 261 584 minecraft:cobbled_deepslate
setblock 87 258 588 minecraft:calcite
fill 87 258 589 87 261 589 minecraft:cobbled_deepslate
setblock 87 258 593 minecraft:calcite
setblock 87 258 594 minecraft:cobbled_deepslate
setblock 87 258 598 minecraft:calcite
fill 88 258 558 88 261 558 minecraft:cobbled_deepslate
setblock 88 258 562 minecraft:calcite
fill 88 258 563 88 261 563 minecraft:cobbled_deepslate
setblock 88 258 567 minecraft:calcite
fill 88 258 568 88 261 568 minecraft:cobbled_deepslate
setblock 88 258 572 minecraft:calcite
fill 88 258 573 88 261 573 minecraft:cobbled_deepslate
setblock 88 258 577 minecraft:calcite
fill 88 258 578 88 261 578 minecraft:cobbled_deepslate
setblock 88 258 582 minecraft:calcite
fill 88 258 583 88 261 583 minecraft:cobbled_deepslate
setblock 88 258 587 minecraft:calcite
fill 88 258 588 88 261 588 minecraft:cobbled_deepslate
setblock 88 258 592 minecraft:calcite
fill 88 258 593 88 260 593 minecraft:cobbled_deepslate
setblock 88 258 597 minecraft:calcite
fill 88 258 598 88 261 598 minecraft:cobbled_deepslate
setblock 48 259 561 minecraft:calcite
fill 48 259 562 48 262 562 minecraft:cobbled_deepslate
setblock 48 259 566 minecraft:calcite
fill 48 259 567 48 262 567 minecraft:cobbled_deepslate
setblock 48 259 571 minecraft:calcite
fill 48 259 572 48 262 572 minecraft:cobbled_deepslate
setblock 48 259 576 minecraft:calcite
fill 48 259 577 48 262 577 minecraft:cobbled_deepslate
setblock 48 259 581 minecraft:calcite
fill 48 259 582 48 262 582 minecraft:cobbled_deepslate
setblock 48 259 586 minecraft:calcite
fill 48 259 587 48 262 587 minecraft:cobbled_deepslate
setblock 48 259 597 minecraft:cobbled_deepslate
setblock 49 259 560 minecraft:calcite
fill 49 259 561 49 262 561 minecraft:cobbled_deepslate
setblock 49 259 565 minecraft:calcite
fill 49 259 566 49 262 566 minecraft:cobbled_deepslate
setblock 49 259 570 minecraft:calcite
setblock 49 259 571 minecraft:cobbled_deepslate
setblock 49 259 575 minecraft:calcite
fill 49 259 576 49 261 576 minecraft:cobbled_deepslate
setblock 49 259 580 minecraft:calcite
fill 49 259 581 49 262 581 minecraft:cobbled_deepslate
setblock 49 259 585 minecraft:calcite
setblock 49 259 586 minecraft:cobbled_deepslate
setblock 50 259 559 minecraft:calcite
setblock 50 259 579 minecraft:calcite
fill 50 259 580 50 260 580 minecraft:cobbled_deepslate
setblock 51 259 558 minecraft:calcite
fill 51 259 559 54 259 559 minecraft:cobbled_deepslate
fill 52 259 558 55 259 558 minecraft:cobbled_deepslate
fill 54 259 562 54 259 563 minecraft:light_blue_stained_glass
fill 55 259 559 55 260 559 minecraft:light_blue_stained_glass
fill 55 259 563 55 259 565 minecraft:light_blue_stained_glass
setblock 56 259 558 minecraft:calcite
fill 56 259 559 59 259 559 minecraft:cobbled_deepslate
fill 56 259 562 56 259 563 minecraft:light_blue_stained_glass
fill 57 259 558 60 259 558 minecraft:cobbled_deepslate
setblock 60 259 559 minecraft:calcite
setblock 60 259 598 minecraft:cobbled_deepslate
setblock 61 259 558 minecraft:calcite
fill 61 259 559 61 262 559 minecraft:cobbled_deepslate
setblock 61 259 598 minecraft:calcite
fill 62 259 558 62 262 558 minecraft:cobbled_deepslate
fill 62 259 598 62 262 598 minecraft:cobbled_deepslate
setblock 63 259 597 minecraft:cobbled_deepslate
setblock 64 259 560 minecraft:calcite
fill 64 259 561 64 262 561 minecraft:cobbled_deepslate
setblock 65 259 559 minecraft:calcite
fill 65 259 560 65 262 560 minecraft:cobbled_deepslate
setblock 66 259 558 minecraft:calcite
fill 66 259 559 66 262 559 minecraft:cobbled_deepslate
setblock 66 259 598 minecraft:calcite
fill 67 259 558 67 262 558 minecraft:cobbled_deepslate
setblock 67 259 597 minecraft:calcite
fill 67 259 598 67 262 598 minecraft:cobbled_deepslate
fill 68 259 597 68 262 597 minecraft:cobbled_deepslate
setblock 69 259 560 minecraft:calcite
setblock 70 259 559 minecraft:calcite
fill 70 259 560 70 260 560 minecraft:cobbled_deepslate
setblock 71 259 558 minecraft:calcite
fill 71 259 559 71 261 559 minecraft:cobbled_deepslate
setblock 71 259 598 minecraft:calcite
fill 72 259 558 72 262 558 minecraft:cobbled_deepslate
setblock 72 259 597 minecraft:calcite
fill 72 259 598 72 262 598 minecraft:cobbled_deepslate
setblock 73 259 597 minecraft:cobbled_deepslate
setblock 76 259 558 minecraft:calcite
setblock 76 259 598 minecraft:calcite
setblock 77 259 558 minecraft:cobbled_deepslate
fill 77 259 598 77 260 598 minecraft:cobbled_deepslate
setblock 81 259 558 minecraft:calcite
setblock 81 259 598 minecraft:calcite
fill 82 259 558 82 262 558 minecraft:cobbled_deepslate
fill 82 259 598 82 262 598 minecraft:cobbled_deepslate
setblock 83 259 597 minecraft:cobbled_deepslate
setblock 85 259 559 minecraft:calcite
fill 85 259 580 85 260 580 minecraft:cobbled_deepslate
setblock 86 259 558 minecraft:calcite
fill 86 259 559 86 261 559 minecraft:cobbled_deepslate
setblock 86 259 578 minecraft:calcite
fill 86 259 579 86 262 579 minecraft:cobbled_deepslate
setblock 86 259 583 minecraft:calcite
fill 86 259 584 86 262 584 minecraft:cobbled_deepslate
setblock 86 259 598 minecraft:calcite
fill 87 259 558 87 262 558 minecraft:cobbled_deepslate
setblock 87 259 561 minecraft:cobbled_deepslate
setblock 87 259 562 minecraft:calcite
setblock 87 259 577 minecraft:calcite
fill 87 259 578 87 262 578 minecraft:cobbled_deepslate
setblock 87 259 582 minecraft:calcite
fill 87 259 583 87 262 583 minecraft:cobbled_deepslate
setblock 87 259 587 minecraft:calcite
fill 87 259 588 87 262 588 minecraft:cobbled_deepslate
setblock 87 259 597 minecraft:calcite
fill 87 259 598 87 262 598 minecraft:cobbled_deepslate
setblock 88 259 561 minecraft:calcite
fill 88 259 562 88 262 562 minecraft:cobbled_deepslate
setblock 88 259 566 minecraft:calcite
fill 88 259 567 88 262 567 minecraft:cobbled_deepslate
setblock 88 259 571 minecraft:calcite
fill 88 259 572 88 262 572 minecraft:cobbled_deepslate
setblock 88 259 576 minecraft:calcite
fill 88 259 577 88 262 577 minecraft:cobbled_deepslate
setblock 88 259 581 minecraft:calcite
fill 88 259 582 88 262 582 minecraft:cobbled_deepslate
setblock 88 259 586 minecraft:calcite
fill 88 259 587 88 262 587 minecraft:cobbled_deepslate
setblock 88 259 591 minecraft:calcite
fill 88 259 592 88 261 592 minecraft:cobbled_deepslate
setblock 88 259 596 minecraft:calcite
fill 88 259 597 88 261 597 minecraft:cobbled_deepslate
setblock 48 260 559 minecraft:cobbled_deepslate
setblock 48 260 560 minecraft:calcite
fill 48 260 561 48 263 561 minecraft:cobbled_deepslate
setblock 48 260 565 minecraft:calcite
fill 48 260 566 48 263 566 minecraft:cobbled_deepslate
setblock 48 260 570 minecraft:calcite
fill 48 260 571 48 263 571 minecraft:cobbled_deepslate
setblock 48 260 575 minecraft:calcite
fill 48 260 576 48 263 576 minecraft:cobbled_deepslate
setblock 48 260 580 minecraft:calcite
fill 48 260 581 48 263 581 minecraft:cobbled_deepslate
setblock 48 260 585 minecraft:calcite
fill 48 260 586 48 263 586 minecraft:cobbled_deepslate
setblock 49 260 559 minecraft:calcite
fill 49 260 560 49 263 560 minecraft:cobbled_deepslate
setblock 49 260 564 minecraft:calcite
fill 49 260 565 49 263 565 minecraft:cobbled_deepslate
setblock 49 260 574 minecraft:calcite
fill 49 260 575 49 261 575 minecraft:cobbled_deepslate
setblock 49 260 579 minecraft:calcite
fill 49 260 580 49 263 580 minecraft:cobbled_deepslate
setblock 49 260 584 minecraft:calcite
fill 49 260 585 49 262 585 minecraft:cobbled_deepslate
setblock 50 260 558 minecraft:calcite
fill 50 260 559 52 260 559 minecraft:cobbled_deepslate
fill 51 260 558 54 260 558 minecraft:cobbled_deepslate
setblock 54 260 559 minecraft:light_blue_stained_glass
setblock 54 260 562 minecraft:light_blue_stained_glass
setblock 55 260 558 minecraft:calcite
fill 55 260 563 55 260 564 minecraft:light_blue_stained_glass
fill 56 260 558 59 260 558 minecraft:cobbled_deepslate
setblock 56 260 559 minecraft:light_blue_stained_glass
setblock 56 260 562 minecraft:light_blue_stained_glass
fill 57 260 559 58 260 559 minecraft:cobbled_deepslate
setblock 59 260 559 minecraft:calcite
setblock 60 260 558 minecraft:calcite
fill 60 260 559 60 263 559 minecraft:cobbled_deepslate
fill 61 260 558 61 263 558 minecraft:cobbled_deepslate
fill 61 260 598 61 263 598 minecraft:cobbled_deepslate
setblock 63 260 560 minecraft:calcite
setblock 64 260 559 minecraft:calcite
fill 64 260 560 64 263 560 minecraft:cobbled_deepslate
setblock 65 260 558 minecraft:calcite
fill 65 260 559 65 263 559 minecraft:cobbled_deepslate
setblock 65 260 598 minecraft:calcite
fill 66 260 558 66 263 558 minecraft:cobbled_deepslate
setblock 66 260 597 minecraft:calcite
fill 66 260 598 66 263 598 minecraft:cobbled_deepslate
setblock 67 260 561 minecraft:calcite
fill 67 260 597 67 263 597 minecraft:cobbled_deepslate
setblock 68 260 560 minecraft:calcite
setblock 69 260 559 minecraft:calcite
fill 69 260 560 69 261 560 minecraft:cobbled_deepslate
setblock 70 260 558 minecraft:calcite
fill 70 260 559 70 263 559 minecraft:cobbled_deepslate
setblock 70 260 598 minecraft:calcite
fill 71 260 558 71 263 558 minecraft:cobbled_deepslate
setblock 71 260 597 minecraft:calcite
fill 71 260 598 71 263 598 minecraft:cobbled_deepslate
setblock 75 260 558 minecraft:calcite
setblock 75 260 598 minecraft:calcite
setblock 76 260 598 minecraft:cobbled_deepslate
setblock 80 260 558 minecraft:calcite
setblock 80 260 598 minecraft:calcite
fill 81 260 558 81 263 558 minecraft:cobbled_deepslate
fill 81 260 598 81 263 598 minecraft:cobbled_deepslate
setblock 84 260 559 minecraft:calcite
setblock 85 260 558 minecraft:calcite
fill 85 260 559 85 261 559 minecraft:cobbled_deepslate
setblock 85 260 583 minecraft:calcite
fill 85 260 584 85 263 584 minecraft:cobbled_deepslate
setblock 85 260 598 minecraft:calcite
fill 86 260 558 86 263 558 minecraft:cobbled_deepslate
setblock 86 260 577 minecraft:calcite
fill 86 260 578 86 263 578 minecraft:cobbled_deepslate
setblock 86 260 582 minecraft:calcite
fill 86 260 583 86 263 583 minecraft:cobbled_deepslate
setblock 86 260 586 minecraft:cobbled_deepslate
setblock 86 260 587 minecraft:calcite
fill 86 260 598 86 263 598 minecraft:cobbled_deepslate
setblock 87 260 561 minecraft:calcite
fill 87 260 562 87 263 562 minecraft:cobbled_deepslate
setblock 87 260 576 minecraft:calcite
fill 87 260 577 87 263 577 minecraft:cobbled_deepslate
setblock 87 260 581 minecraft:calcite
fill 87 260 582 87 263 582 minecraft:cobbled_deepslate
setblock 87 260 586 minecraft:calcite
fill 87 260 587 87 263 587 minecraft:cobbled_deepslate
setblock 88 260 560 minecraft:calcite
fill 88 260 561 88 263 561 minecraft:cobbled_deepslate
setblock 88 260 565 minecraft:calcite
fill 88 260 566 88 263 566 minecraft:cobbled_deepslate
setblock 88 260 570 minecraft:calcite
fill 88 260 571 88 263 571 minecraft:cobbled_deepslate
setblock 88 260 575 minecraft:calcite
fill 88 260 576 88 263 576 minecraft:cobbled_deepslate
setblock 88 260 580 minecraft:calcite
fill 88 260 581 88 263 581 minecraft:cobbled_deepslate
setblock 88 260 585 minecraft:calcite
fill 88 260 586 88 263 586 minecraft:cobbled_deepslate
setblock 88 260 590 minecraft:calcite
fill 88 260 591 88 263 591 minecraft:cobbled_deepslate
setblock 88 260 595 minecraft:calcite
setblock 88 260 596 minecraft:cobbled_deepslate
setblock 48 261 559 minecraft:calcite
fill 48 261 560 48 264 560 minecraft:cobbled_deepslate
setblock 48 261 564 minecraft:calcite
fill 48 261 565 48 264 565 minecraft:cobbled_deepslate
setblock 48 261 569 minecraft:calcite
fill 48 261 570 48 264 570 minecraft:cobbled_deepslate
setblock 48 261 574 minecraft:calcite
fill 48 261 575 48 264 575 minecraft:cobbled_deepslate
setblock 48 261 579 minecraft:calcite
fill 48 261 580 48 264 580 minecraft:cobbled_deepslate
setblock 48 261 584 minecraft:calcite
fill 48 261 585 48 264 585 minecraft:cobbled_deepslate
setblock 49 261 558 minecraft:calcite
fill 49 261 559 51 261 559 minecraft:cobbled_deepslate
setblock 49 261 563 minecraft:calcite
fill 49 261 564 49 264 564 minecraft:cobbled_deepslate
setblock 49 261 578 minecraft:calcite
fill 49 261 579 49 263 579 minecraft:cobbled_deepslate
setblock 49 261 583 minecraft:calcite
fill 49 261 584 49 264 584 minecraft:cobbled_deepslate
fill 50 261 558 53 261 558 minecraft:cobbled_deepslate
setblock 54 261 558 minecraft:calcite
fill 55 261 558 58 261 558 minecraft:cobbled_deepslate
setblock 58 261 559 minecraft:calcite
setblock 59 261 558 minecraft:calcite
fill 59 261 559 59 264 559 minecraft:cobbled_deepslate
fill 60 261 558 60 264 558 minecraft:cobbled_deepslate
fill 60 261 560 60 262 560 minecraft:cobbled_deepslate
setblock 62 261 560 minecraft:calcite
setblock 63 261 559 minecraft:calcite
fill 63 261 560 63 264 560 minecraft:cobbled_deepslate
setblock 64 261 558 minecraft:calcite
fill 64 261 559 64 264 559 minecraft:cobbled_deepslate
setblock 64 261 598 minecraft:calcite
fill 65 261 558 65 264 558 minecraft:cobbled_deepslate
setblock 65 261 597 minecraft:calcite
fill 65 261 598 65 264 598 minecraft:cobbled_deepslate
setblock 66 261 561 minecraft:calcite
fill 66 261 597 66 264 597 minecraft:cobbled_deepslate
setblock 67 261 560 minecraft:calcite
setblock 68 261 559 minecraft:calcite
fill 68 261 560 68 263 560 minecraft:cobbled_deepslate
setblock 69 261 558 minecraft:calcite
fill 69 261 559 69 264 559 minecraft:cobbled_deepslate
setblock 69 261 598 minecraft:calcite
fill 70 261 558 70 264 558 minecraft:cobbled_deepslate
fill 70 261 598 70 264 598 minecraft:cobbled_deepslate
setblock 74 261 558 minecraft:calcite
setblock 74 261 598 minecraft:calcite
setblock 80 261 598 minecraft:cobbled_deepslate
setblock 84 261 558 minecraft:calcite
setblock 84 261 598 minecraft:calcite
fill 85 261 558 85 264 558 minecraft:cobbled_deepslate
setblock 85 261 582 minecraft:calcite
fill 85 261 583 85 264 583 minecraft:cobbled_deepslate
fill 85 261 598 85 264 598 minecraft:cobbled_deepslate
setblock 86 261 577 minecraft:cobbled_deepslate
setblock 86 261 581 minecraft:calcite
fill 86 261 582 86 264 582 minecraft:cobbled_deepslate
setblock 86 261 586 minecraft:calcite
fill 86 261 587 86 264 587 minecraft:cobbled_deepslate
setblock 87 261 560 minecraft:calcite
fill 87 261 561 87 264 561 minecraft:cobbled_deepslate
fill 87 261 563 87 262 563 minecraft:cobbled_deepslate
setblock 87 261 575 minecraft:calcite
fill 87 261 576 87 264 576 minecraft:cobbled_deepslate
setblock 87 261 580 minecraft:calcite
fill 87 261 581 87 264 581 minecraft:cobbled_deepslate
setblock 87 261 585 minecraft:calcite
fill 87 261 586 87 264 586 minecraft:cobbled_deepslate
setblock 88 261 559 minecraft:calcite
fill 88 261 560 88 264 560 minecraft:cobbled_deepslate
setblock 88 261 564 minecraft:calcite
fill 88 261 565 88 264 565 minecraft:cobbled_deepslate
setblock 88 261 569 minecraft:calcite
fill 88 261 570 88 264 570 minecraft:cobbled_deepslate
setblock 88 261 574 minecraft:calcite
fill 88 261 575 88 264 575 minecraft:cobbled_deepslate
setblock 88 261 579 minecraft:calcite
fill 88 261 580 88 264 580 minecraft:cobbled_deepslate
setblock 88 261 584 minecraft:calcite
fill 88 261 585 88 264 585 minecraft:cobbled_deepslate
setblock 88 261 589 minecraft:calcite
fill 88 261 590 88 264 590 minecraft:cobbled_deepslate
setblock 48 262 558 minecraft:calcite
fill 48 262 559 50 262 559 minecraft:cobbled_deepslate
setblock 48 262 563 minecraft:calcite
fill 48 262 564 48 265 564 minecraft:cobbled_deepslate
setblock 48 262 568 minecraft:calcite
fill 48 262 569 48 265 569 minecraft:cobbled_deepslate
setblock 48 262 573 minecraft:calcite
fill 48 262 574 48 265 574 minecraft:cobbled_deepslate
setblock 48 262 578 minecraft:calcite
fill 48 262 579 48 265 579 minecraft:cobbled_deepslate
setblock 48 262 583 minecraft:calcite
fill 48 262 584 48 265 584 minecraft:cobbled_deepslate
setblock 48 262 588 minecraft:calcite
fill 49 262 558 52 262 558 minecraft:cobbled_deepslate
setblock 49 262 562 minecraft:calcite
fill 49 262 563 49 265 563 minecraft:cobbled_deepslate
setblock 49 262 567 minecraft:calcite
setblock 49 262 577 minecraft:calcite
setblock 49 262 578 minecraft:cobbled_deepslate
setblock 49 262 582 minecraft:calcite
fill 49 262 583 49 264 583 minecraft:cobbled_deepslate
setblock 53 262 558 minecraft:calcite
fill 54 262 558 57 262 558 minecraft:cobbled_deepslate
setblock 58 262 558 minecraft:calcite
fill 58 262 559 58 265 559 minecraft:cobbled_deepslate
fill 59 262 558 59 265 558 minecraft:cobbled_deepslate
setblock 61 262 560 minecraft:calcite
setblock 62 262 559 minecraft:calcite
fill 62 262 560 62 265 560 minecraft:cobbled_deepslate
setblock 63 262 558 minecraft:calcite
fill 63 262 559 63 265 559 minecraft:cobbled_deepslate
fill 63 262 561 63 263 561 minecraft:cobbled_deepslate
setblock 63 262 598 minecraft:calcite
fill 64 262 558 64 265 558 minecraft:cobbled_deepslate
setblock 64 262 597 minecraft:calcite
fill 64 262 598 64 265 598 minecraft:cobbled_deepslate
setblock 65 262 561 minecraft:calcite
fill 65 262 597 65 265 597 minecraft:cobbled_deepslate
setblock 66 262 560 minecraft:calcite
setblock 67 262 559 minecraft:calcite
fill 67 262 560 67 265 560 minecraft:cobbled_deepslate
setblock 68 262 558 minecraft:calcite
fill 68 262 559 68 265 559 minecraft:cobbled_deepslate
setblock 68 262 598 minecraft:calcite
fill 69 262 558 69 265 558 minecraft:cobbled_deepslate
fill 69 262 598 69 265 598 minecraft:cobbled_deepslate
setblock 73 262 558 minecraft:calcite
setblock 83 262 558 minecraft:calcite
setblock 83 262 598 minecraft:calcite
fill 84 262 558 84 265 558 minecraft:cobbled_deepslate
fill 84 262 598 84 265 598 minecraft:cobbled_deepslate
setblock 85 262 581 minecraft:calcite
fill 85 262 582 85 265 582 minecraft:cobbled_deepslate
setblock 85 262 585 minecraft:cobbled_deepslate
setblock 86 262 580 minecraft:calcite
fill 86 262 581 86 265 581 minecraft:cobbled_deepslate
setblock 86 262 585 minecraft:calcite
fill 86 262 586 86 265 586 minecraft:cobbled_deepslate
fill 86 262 588 86 263 588 minecraft:cobbled_deepslate
setblock 87 262 560 minecraft:cobbled_deepslate
setblock 87 262 564 minecraft:calcite
setblock 87 262 575 minecraft:cobbled_deepslate
setblock 87 262 579 minecraft:calcite
fill 87 262 580 87 265 580 minecraft:cobbled_deepslate
setblock 87 262 584 minecraft:calcite
fill 87 262 585 87 265 585 minecraft:cobbled_deepslate
setblock 87 262 589 minecraft:calcite
setblock 88 262 558 minecraft:calcite
fill 88 262 559 88 265 559 minecraft:cobbled_deepslate
setblock 88 262 563 minecraft:calcite
fill 88 262 564 88 265 564 minecraft:cobbled_deepslate
setblock 88 262 568 minecraft:calcite
fill 88 262 569 88 265 569 minecraft:cobbled_deepslate
setblock 88 262 573 minecraft:calcite
fill 88 262 574 88 265 574 minecraft:cobbled_deepslate
setblock 88 262 578 minecraft:calcite
fill 88 262 579 88 265 579 minecraft:cobbled_deepslate
setblock 88 262 583 minecraft:calcite
fill 88 262 584 88 265 584 minecraft:cobbled_deepslate
setblock 88 262 588 minecraft:calcite
fill 88 262 589 88 265 589 minecraft:cobbled_deepslate
fill 48 263 558 49 263 559 minecraft:cobbled_deepslate
setblock 48 263 562 minecraft:calcite
fill 48 263 563 48 266 563 minecraft:cobbled_deepslate
setblock 48 263 567 minecraft:calcite
fill 48 263 568 49 265 568 minecraft:cobbled_deepslate
setblock 48 263 572 minecraft:calcite
fill 48 263 573 48 266 573 minecraft:cobbled_deepslate
setblock 48 263 577 minecraft:calcite
fill 48 263 578 48 266 578 minecraft:cobbled_deepslate
setblock 48 263 582 minecraft:calcite
fill 48 263 583 48 266 583 minecraft:cobbled_deepslate
setblock 48 263 587 minecraft:calcite
fill 48 263 588 48 266 588 minecraft:cobbled_deepslate
setblock 49 263 561 minecraft:calcite
fill 49 263 562 49 266 562 minecraft:cobbled_deepslate
setblock 49 263 566 minecraft:calcite
fill 49 263 567 49 266 567 minecraft:cobbled_deepslate
setblock 49 263 581 minecraft:calcite
fill 49 263 582 49 264 582 minecraft:cobbled_deepslate
fill 50 263 558 51 263 558 minecraft:cobbled_deepslate
setblock 52 263 558 minecraft:calcite
fill 53 263 558 56 263 558 minecraft:cobbled_deepslate
setblock 57 263 558 minecraft:calcite
fill 57 263 559 57 266 559 minecraft:cobbled_deepslate
fill 58 263 558 58 266 558 minecraft:cobbled_deepslate
setblock 59 263 560 minecraft:cobbled_deepslate
setblock 60 263 560 minecraft:calcite
fill 60 263 598 60 264 598 minecraft:cobbled_deepslate
setblock 61 263 559 minecraft:calcite
fill 61 263 560 61 266 560 minecraft:cobbled_deepslate
setblock 62 263 558 minecraft:calcite
fill 62 263 559 62 266 559 minecraft:cobbled_deepslate
setblock 62 263 598 minecraft:calcite
fill 63 263 558 63 266 558 minecraft:cobbled_deepslate
fill 63 263 598 63 266 598 minecraft:cobbled_deepslate
setblock 64 263 561 minecraft:calcite
fill 64 263 597 64 266 597 minecraft:cobbled_deepslate
setblock 65 263 560 minecraft:calcite
fill 65 263 561 65 264 561 minecraft:cobbled_deepslate
setblock 66 263 559 minecraft:calcite
fill 66 263 560 66 266 560 minecraft:cobbled_deepslate
setblock 67 263 558 minecraft:calcite
fill 67 263 559 67 266 559 minecraft:cobbled_deepslate
setblock 67 263 598 minecraft:calcite
fill 68 263 558 68 266 558 minecraft:cobbled_deepslate
fill 68 263 598 68 266 598 minecraft:cobbled_deepslate
setblock 72 263 558 minecraft:calcite
setblock 82 263 558 minecraft:calcite
setblock 82 263 598 minecraft:calcite
fill 83 263 558 83 266 558 minecraft:cobbled_deepslate
fill 83 263 598 83 266 598 minecraft:cobbled_deepslate
fill 84 263 568 84 268 568 minecraft:calcite
fill 85 263 581 85 266 581 minecraft:cobbled_deepslate
setblock 85 263 585 minecraft:calcite
fill 85 263 586 85 266 586 minecraft:cobbled_deepslate
setblock 86 263 579 minecraft:calcite
fill 86 263 580 86 266 580 minecraft:cobbled_deepslate
setblock 86 263 584 minecraft:calcite
fill 86 263 585 86 266 585 minecraft:cobbled_deepslate
setblock 87 263 558 minecraft:calcite
setblock 87 263 563 minecraft:calcite
fill 87 263 564 87 264 566 minecraft:cobbled_deepslate
setblock 87 263 578 minecraft:calcite
fill 87 263 579 87 266 579 minecraft:cobbled_deepslate
setblock 87 263 583 minecraft:calcite
fill 87 263 584 87 266 584 minecraft:cobbled_deepslate
setblock 87 263 588 minecraft:calcite
fill 87 263 589 87 265 590 minecraft:cobbled_deepslate
fill 88 263 558 88 264 558 minecraft:cobbled_deepslate
setblock 88 263 562 minecraft:calcite
fill 88 263 563 88 266 563 minecraft:cobbled_deepslate
setblock 88 263 567 minecraft:calcite
fill 88 263 568 88 266 568 minecraft:cobbled_deepslate
setblock 88 263 572 minecraft:calcite
fill 88 263 573 88 266 573 minecraft:cobbled_deepslate
setblock 88 263 577 minecraft:calcite
fill 88 263 578 88 266 578 minecraft:cobbled_deepslate
setblock 88 263 582 minecraft:calcite
fill 88 263 583 88 266 583 minecraft:cobbled_deepslate
setblock 88 263 587 minecraft:calcite
fill 88 263 588 88 266 588 minecraft:cobbled_deepslate
fill 48 264 558 48 265 559 minecraft:cobbled_deepslate
setblock 48 264 561 minecraft:calcite
fill 48 264 562 48 267 562 minecraft:cobbled_deepslate
setblock 48 264 566 minecraft:calcite
fill 48 264 567 48 267 567 minecraft:cobbled_deepslate
setblock 48 264 571 minecraft:calcite
fill 48 264 572 48 267 572 minecraft:cobbled_deepslate
setblock 48 264 576 minecraft:calcite
fill 48 264 577 48 267 577 minecraft:cobbled_deepslate
setblock 48 264 581 minecraft:calcite
fill 48 264 582 48 267 582 minecraft:cobbled_deepslate
setblock 48 264 586 minecraft:calcite
fill 48 264 587 48 267 587 minecraft:cobbled_deepslate
fill 48 264 589 48 265 589 minecraft:cobbled_deepslate
fill 49 264 558 50 264 558 minecraft:cobbled_deepslate
setblock 49 264 560 minecraft:calcite
fill 49 264 561 49 267 561 minecraft:cobbled_deepslate
setblock 49 264 565 minecraft:calcite
fill 49 264 566 49 267 566 minecraft:cobbled_deepslate
setblock 49 264 569 minecraft:cobbled_deepslate
setblock 49 264 581 minecraft:cobbled_deepslate
setblock 50 264 560 minecraft:light[level=14]
setblock 50 264 568 minecraft:light[level=14]
setblock 50 264 576 minecraft:light[level=14]
setblock 50 264 584 minecraft:light[level=14]
setblock 50 264 592 minecraft:light[level=14]
setblock 51 264 558 minecraft:calcite
fill 52 264 558 55 264 558 minecraft:cobbled_deepslate
setblock 56 264 558 minecraft:calcite
fill 57 264 558 57 267 558 minecraft:cobbled_deepslate
setblock 58 264 560 minecraft:light[level=14]
setblock 58 264 568 minecraft:light[level=14]
setblock 58 264 576 minecraft:light[level=14]
setblock 58 264 584 minecraft:light[level=14]
setblock 58 264 592 minecraft:light[level=14]
setblock 59 264 560 minecraft:calcite
setblock 60 264 559 minecraft:calcite
fill 60 264 560 60 267 560 minecraft:cobbled_deepslate
setblock 61 264 558 minecraft:calcite
fill 61 264 559 61 267 559 minecraft:cobbled_deepslate
setblock 61 264 598 minecraft:calcite
fill 62 264 558 62 267 558 minecraft:cobbled_deepslate
setblock 62 264 561 minecraft:cobbled_deepslate
fill 62 264 598 62 267 598 minecraft:cobbled_deepslate
setblock 63 264 561 minecraft:calcite
fill 63 264 597 63 267 597 minecraft:cobbled_deepslate
setblock 64 264 560 minecraft:calcite
fill 64 264 561 64 266 561 minecraft:cobbled_deepslate
setblock 65 264 559 minecraft:calcite
fill 65 264 560 65 267 560 minecraft:cobbled_deepslate
setblock 66 264 558 minecraft:calcite
fill 66 264 559 66 267 559 minecraft:cobbled_deepslate
setblock 66 264 568 minecraft:light[level=14]
setblock 66 264 576 minecraft:light[level=14]
setblock 66 264 584 minecraft:light[level=14]
setblock 66 264 592 minecraft:light[level=14]
setblock 66 264 598 minecraft:calcite
fill 67 264 558 67 267 558 minecraft:cobbled_deepslate
setblock 67 264 597 minecraft:calcite
fill 67 264 598 67 267 598 minecraft:cobbled_deepslate
setblock 71 264 558 minecraft:calcite
setblock 71 264 598 minecraft:calcite
setblock 74 264 560 minecraft:light[level=14]
setblock 74 264 568 minecraft:light[level=14]
setblock 74 264 576 minecraft:light[level=14]
setblock 74 264 584 minecraft:light[level=14]
setblock 74 264 592 minecraft:light[level=14]
setblock 80 264 598 minecraft:cobbled_deepslate
setblock 81 264 558 minecraft:calcite
setblock 81 264 598 minecraft:calcite
fill 82 264 558 82 267 558 minecraft:cobbled_deepslate
setblock 82 264 560 minecraft:light[level=14]
setblock 82 264 568 minecraft:light[level=14]
setblock 82 264 576 minecraft:light[level=14]
setblock 82 264 584 minecraft:light[level=14]
setblock 82 264 592 minecraft:light[level=14]
fill 82 264 598 82 267 598 minecraft:cobbled_deepslate
setblock 85 264 584 minecraft:calcite
fill 85 264 585 85 267 585 minecraft:cobbled_deepslate
fill 85 264 587 85 265 587 minecraft:cobbled_deepslate
setblock 86 264 558 minecraft:calcite
setblock 86 264 578 minecraft:calcite
fill 86 264 579 86 267 579 minecraft:cobbled_deepslate
setblock 86 264 583 minecraft:calcite
fill 86 264 584 86 267 584 minecraft:cobbled_deepslate
setblock 86 264 588 minecraft:calcite
fill 86 264 589 86 267 589 minecraft:cobbled_deepslate
fill 87 264 558 87 265 558 minecraft:cobbled_deepslate
setblock 87 264 562 minecraft:calcite
fill 87 264 563 87 267 563 minecraft:cobbled_deepslate
setblock 87 264 567 minecraft:calcite
fill 87 264 568 87 267 568 minecraft:cobbled_deepslate
setblock 87 264 577 minecraft:calcite
fill 87 264 578 87 267 578 minecraft:cobbled_deepslate
setblock 87 264 582 minecraft:calcite
fill 87 264 583 87 267 583 minecraft:cobbled_deepslate
setblock 87 264 587 minecraft:calcite
fill 87 264 588 87 267 588 minecraft:cobbled_deepslate
setblock 88 264 561 minecraft:calcite
fill 88 264 562 88 267 562 minecraft:cobbled_deepslate
setblock 88 264 566 minecraft:calcite
fill 88 264 567 88 267 567 minecraft:cobbled_deepslate
setblock 88 264 571 minecraft:calcite
fill 88 264 572 88 267 572 minecraft:cobbled_deepslate
setblock 88 264 576 minecraft:calcite
fill 88 264 577 88 267 577 minecraft:cobbled_deepslate
setblock 88 264 581 minecraft:calcite
fill 88 264 582 88 267 582 minecraft:cobbled_deepslate
setblock 88 264 586 minecraft:calcite
fill 88 264 587 88 267 587 minecraft:cobbled_deepslate
setblock 88 264 591 minecraft:calcite
setblock 48 265 560 minecraft:calcite
fill 48 265 561 48 268 561 minecraft:cobbled_deepslate
setblock 48 265 565 minecraft:calcite
fill 48 265 566 48 268 566 minecraft:cobbled_deepslate
setblock 48 265 570 minecraft:calcite
fill 48 265 571 48 268 571 minecraft:cobbled_deepslate
setblock 48 265 575 minecraft:calcite
fill 48 265 576 48 268 576 minecraft:cobbled_deepslate
setblock 48 265 580 minecraft:calcite
fill 48 265 581 48 268 581 minecraft:cobbled_deepslate
setblock 48 265 585 minecraft:calcite
fill 48 265 586 48 268 586 minecraft:cobbled_deepslate
setblock 49 265 558 minecraft:cobbled_deepslate
fill 49 265 560 49 268 560 minecraft:cobbled_deepslate
setblock 49 265 564 minecraft:calcite
fill 49 265 565 49 268 565 minecraft:cobbled_deepslate
setblock 49 265 569 minecraft:calcite
fill 49 265 570 49 268 570 minecraft:cobbled_deepslate
setblock 50 265 558 minecraft:calcite
fill 50 265 564 50 268 564 minecraft:cobbled_deepslate
fill 51 265 558 54 265 558 minecraft:cobbled_deepslate
setblock 55 265 558 minecraft:calcite
fill 56 265 558 56 267 559 minecraft:cobbled_deepslate
setblock 58 265 560 minecraft:calcite
setblock 59 265 559 minecraft:calcite
fill 59 265 560 59 268 560 minecraft:cobbled_deepslate
setblock 59 265 598 minecraft:cobbled_deepslate
setblock 60 265 558 minecraft:calcite
fill 60 265 559 60 268 559 minecraft:cobbled_deepslate
setblock 60 265 598 minecraft:calcite
fill 61 265 558 61 268 558 minecraft:cobbled_deepslate
setblock 61 265 561 minecraft:cobbled_deepslate
fill 61 265 598 61 268 598 minecraft:cobbled_deepslate
setblock 62 265 561 minecraft:calcite
fill 62 265 597 62 268 597 minecraft:cobbled_deepslate
setblock 63 265 560 minecraft:calcite
fill 63 265 561 63 267 561 minecraft:cobbled_deepslate
setblock 64 265 559 minecraft:calcite
fill 64 265 560 64 268 560 minecraft:cobbled_deepslate
setblock 65 265 558 minecraft:calcite
fill 65 265 559 65 268 559 minecraft:cobbled_deepslate
setblock 65 265 598 minecraft:calcite
fill 66 265 558 66 268 558 minecraft:cobbled_deepslate
setblock 66 265 597 minecraft:calcite
fill 66 265 598 66 268 598 minecraft:cobbled_deepslate
fill 67 265 597 67 268 597 minecraft:cobbled_deepslate
setblock 69 265 559 minecraft:calcite
setblock 70 265 558 minecraft:calcite
setblock 70 265 598 minecraft:calcite
setblock 79 265 598 minecraft:cobbled_deepslate
setblock 80 265 558 minecraft:calcite
setblock 80 265 598 minecraft:calcite
fill 81 265 558 81 268 558 minecraft:cobbled_deepslate
fill 81 265 598 81 268 598 minecraft:cobbled_deepslate
setblock 85 265 558 minecraft:calcite
setblock 85 265 583 minecraft:calcite
fill 85 265 584 85 268 584 minecraft:cobbled_deepslate
setblock 85 265 588 minecraft:calcite
setblock 85 265 598 minecraft:calcite
fill 86 265 558 86 267 558 minecraft:cobbled_deepslate
setblock 86 265 582 minecraft:calcite
fill 86 265 583 86 268 583 minecraft:cobbled_deepslate
setblock 86 265 587 minecraft:calcite
fill 86 265 588 86 268 588 minecraft:cobbled_deepslate
setblock 87 265 561 minecraft:calcite
fill 87 265 562 87 268 562 minecraft:cobbled_deepslate
fill 87 265 564 87 265 565 minecraft:cobbled_deepslate
setblock 87 265 566 minecraft:calcite
fill 87 265 567 87 268 567 minecraft:cobbled_deepslate
fill 87 265 569 87 265 570 minecraft:cobbled_deepslate
setblock 87 265 576 minecraft:calcite
fill 87 265 577 87 268 577 minecraft:cobbled_deepslate
setblock 87 265 581 minecraft:calcite
fill 87 265 582 87 268 582 minecraft:cobbled_deepslate
setblock 87 265 586 minecraft:calcite
fill 87 265 587 87 268 587 minecraft:cobbled_deepslate
setblock 87 265 591 minecraft:calcite
setblock 88 265 560 minecraft:calcite
fill 88 265 561 88 268 561 minecraft:cobbled_deepslate
setblock 88 265 565 minecraft:calcite
fill 88 265 566 88 268 566 minecraft:cobbled_deepslate
setblock 88 265 570 minecraft:calcite
fill 88 265 571 88 268 571 minecraft:cobbled_deepslate
setblock 88 265 575 minecraft:calcite
fill 88 265 576 88 268 576 minecraft:cobbled_deepslate
setblock 88 265 580 minecraft:calcite
fill 88 265 581 88 268 581 minecraft:cobbled_deepslate
setblock 88 265 585 minecraft:calcite
fill 88 265 586 88 268 586 minecraft:cobbled_deepslate
setblock 88 265 590 minecraft:calcite
fill 88 265 591 88 267 592 minecraft:cobbled_deepslate
setblock 48 266 558 minecraft:cobbled_deepslate
setblock 48 266 559 minecraft:calcite
fill 48 266 560 48 269 560 minecraft:cobbled_deepslate
setblock 48 266 564 minecraft:calcite
fill 48 266 565 48 269 565 minecraft:cobbled_deepslate
setblock 48 266 568 minecraft:cobbled_deepslate
setblock 48 266 569 minecraft:calcite
fill 48 266 570 48 269 570 minecraft:cobbled_deepslate
setblock 48 266 574 minecraft:calcite
fill 48 266 575 48 269 575 minecraft:cobbled_deepslate
setblock 48 266 579 minecraft:calcite
fill 48 266 580 48 268 580 minecraft:cobbled_deepslate
setblock 48 266 584 minecraft:calcite
fill 48 266 585 48 269 585 minecraft:cobbled_deepslate
setblock 48 266 589 minecraft:calcite
fill 48 266 590 48 269 590 minecraft:cobbled_deepslate
setblock 49 266 558 minecraft:calcite
setblock 49 266 563 minecraft:calcite
fill 49 266 564 49 269 564 minecraft:cobbled_deepslate
setblock 49 266 568 minecraft:calcite
fill 49 266 569 49 269 569 minecraft:cobbled_deepslate
fill 50 266 558 53 266 558 minecraft:cobbled_deepslate
fill 50 266 563 50 267 563 minecraft:cobbled_deepslate
fill 50 266 565 50 266 566 minecraft:cobbled_deepslate
setblock 54 266 558 minecraft:calcite
fill 55 266 558 55 268 559 minecraft:cobbled_deepslate
setblock 57 266 560 minecraft:calcite
setblock 58 266 559 minecraft:calcite
fill 58 266 560 58 269 560 minecraft:cobbled_deepslate
setblock 58 266 598 minecraft:cobbled_deepslate
setblock 59 266 558 minecraft:calcite
fill 59 266 559 59 269 559 minecraft:cobbled_deepslate
setblock 59 266 598 minecraft:calcite
fill 60 266 558 60 269 558 minecraft:cobbled_deepslate
setblock 60 266 561 minecraft:cobbled_deepslate
fill 60 266 598 60 269 598 minecraft:cobbled_deepslate
setblock 61 266 561 minecraft:calcite
fill 61 266 597 61 269 597 minecraft:cobbled_deepslate
setblock 62 266 560 minecraft:calcite
fill 62 266 561 62 268 561 minecraft:cobbled_deepslate
setblock 63 266 559 minecraft:calcite
fill 63 266 560 63 269 560 minecraft:cobbled_deepslate
setblock 64 266 558 minecraft:calcite
fill 64 266 559 64 269 559 minecraft:cobbled_deepslate
setblock 64 266 598 minecraft:calcite
fill 65 266 558 65 269 558 minecraft:cobbled_deepslate
setblock 65 266 597 minecraft:calcite
fill 65 266 598 65 269 598 minecraft:cobbled_deepslate
fill 66 266 597 66 269 597 minecraft:cobbled_deepslate
setblock 68 266 559 minecraft:calcite
setblock 69 266 558 minecraft:calcite
setblock 69 266 598 minecraft:calcite
setblock 70 266 558 minecraft:cobbled_deepslate
fill 70 266 598 70 269 598 minecraft:cobbled_deepslate
setblock 78 266 598 minecraft:cobbled_deepslate
setblock 79 266 598 minecraft:calcite
fill 80 266 558 80 269 558 minecraft:cobbled_deepslate
fill 80 266 598 80 269 598 minecraft:cobbled_deepslate
fill 83 266 568 83 268 568 minecraft:calcite
setblock 84 266 558 minecraft:calcite
fill 84 266 567 84 268 567 minecraft:calcite
fill 84 266 569 84 268 569 minecraft:calcite
setblock 84 266 598 minecraft:calcite
fill 85 266 558 85 268 558 minecraft:cobbled_deepslate
fill 85 266 568 85 268 568 minecraft:calcite
setblock 85 266 582 minecraft:calcite
fill 85 266 583 85 268 583 minecraft:cobbled_deepslate
setblock 85 266 587 minecraft:calcite
fill 85 266 588 85 269 588 minecraft:cobbled_deepslate
setblock 85 266 598 minecraft:cobbled_deepslate
fill 86 266 564 86 266 565 minecraft:cobbled_deepslate
setblock 86 266 566 minecraft:calcite
fill 86 266 567 86 269 567 minecraft:cobbled_deepslate
setblock 86 266 581 minecraft:calcite
fill 86 266 582 86 269 582 minecraft:cobbled_deepslate
setblock 86 266 586 minecraft:calcite
fill 86 266 587 86 269 587 minecraft:cobbled_deepslate
setblock 86 266 590 minecraft:cobbled_deepslate
fill 87 266 561 87 267 561 minecraft:cobbled_deepslate
setblock 87 266 564 minecraft:cobbled_deepslate
setblock 87 266 565 minecraft:calcite
fill 87 266 566 87 269 566 minecraft:cobbled_deepslate
setblock 87 266 569 minecraft:cobbled_deepslate
setblock 87 266 570 minecraft:calcite
fill 87 266 571 87 266 574 minecraft:cobbled_deepslate
setblock 87 266 575 minecraft:calcite
fill 87 266 576 87 269 576 minecraft:cobbled_deepslate
setblock 87 266 580 minecraft:calcite
fill 87 266 581 87 269 581 minecraft:cobbled_deepslate
setblock 87 266 585 minecraft:calcite
fill 87 266 586 87 269 586 minecraft:cobbled_deepslate
setblock 87 266 589 minecraft:cobbled_deepslate
setblock 87 266 590 minecraft:calcite
fill 87 266 591 87 269 591 minecraft:cobbled_deepslate
setblock 88 266 559 minecraft:calcite
fill 88 266 560 88 268 560 minecraft:cobbled_deepslate
setblock 88 266 564 minecraft:calcite
fill 88 266 565 88 269 565 minecraft:cobbled_deepslate
setblock 88 266 569 minecraft:calcite
fill 88 266 570 88 269 570 minecraft:cobbled_deepslate
setblock 88 266 574 minecraft:calcite
fill 88 266 575 88 269 575 minecraft:cobbled_deepslate
setblock 88 266 579 minecraft:calcite
fill 88 266 580 88 269 580 minecraft:cobbled_deepslate
setblock 88 266 584 minecraft:calcite
fill 88 266 585 88 269 585 minecraft:cobbled_deepslate
setblock 88 266 589 minecraft:calcite
fill 88 266 590 88 269 590 minecraft:cobbled_deepslate
setblock 48 267 558 minecraft:calcite
fill 48 267 559 48 270 559 minecraft:cobbled_deepslate
setblock 48 267 563 minecraft:calcite
fill 48 267 564 48 270 564 minecraft:cobbled_deepslate
setblock 48 267 568 minecraft:calcite
fill 48 267 569 48 270 569 minecraft:cobbled_deepslate
setblock 48 267 573 minecraft:calcite
fill 48 267 574 48 270 574 minecraft:cobbled_deepslate
setblock 48 267 578 minecraft:calcite
fill 48 267 579 48 268 579 minecraft:cobbled_deepslate
setblock 48 267 583 minecraft:calcite
fill 48 267 584 48 269 584 minecraft:cobbled_deepslate
setblock 48 267 588 minecraft:calcite
fill 48 267 589 48 270 589 minecraft:cobbled_deepslate
fill 49 267 558 52 267 558 minecraft:cobbled_deepslate
setblock 49 267 562 minecraft:calcite
fill 49 267 563 49 270 563 minecraft:cobbled_deepslate
setblock 49 267 567 minecraft:calcite
fill 49 267 568 49 270 568 minecraft:cobbled_deepslate
setblock 49 267 571 minecraft:cobbled_deepslate
setblock 50 267 565 minecraft:cobbled_deepslate
setblock 50 267 566 minecraft:calcite
fill 50 267 567 50 270 567 minecraft:cobbled_deepslate
setblock 53 267 558 minecraft:calcite
fill 54 267 558 54 270 558 minecraft:cobbled_deepslate
setblock 57 267 559 minecraft:calcite
fill 57 267 560 57 270 560 minecraft:cobbled_deepslate
setblock 57 267 598 minecraft:cobbled_deepslate
setblock 58 267 558 minecraft:calcite
fill 58 267 559 58 270 559 minecraft:cobbled_deepslate
setblock 58 267 598 minecraft:calcite
fill 59 267 558 59 270 558 minecraft:cobbled_deepslate
setblock 59 267 561 minecraft:cobbled_deepslate
fill 59 267 598 59 270 598 minecraft:cobbled_deepslate
setblock 60 267 561 minecraft:calcite
fill 60 267 597 60 270 597 minecraft:cobbled_deepslate
setblock 61 267 560 minecraft:calcite
fill 61 267 561 61 269 561 minecraft:cobbled_deepslate
setblock 62 267 559 minecraft:calcite
fill 62 267 560 62 270 560 minecraft:cobbled_deepslate
setblock 63 267 558 minecraft:calcite
fill 63 267 559 63 270 559 minecraft:cobbled_deepslate
setblock 63 267 598 minecraft:calcite
fill 64 267 558 64 270 558 minecraft:cobbled_deepslate
setblock 64 267 597 minecraft:calcite
fill 64 267 598 64 270 598 minecraft:cobbled_deepslate
fill 65 267 597 65 270 597 minecraft:cobbled_deepslate
setblock 66 267 560 minecraft:calcite
setblock 67 267 559 minecraft:calcite
setblock 68 267 558 minecraft:calcite
setblock 68 267 598 minecraft:calcite
setblock 69 267 558 minecraft:cobbled_deepslate
fill 69 267 598 69 270 598 minecraft:cobbled_deepslate
setblock 77 267 598 minecraft:cobbled_deepslate
setblock 78 267 598 minecraft:calcite
fill 79 267 558 79 269 558 minecraft:cobbled_deepslate
fill 79 267 598 79 270 598 minecraft:cobbled_deepslate
setblock 83 267 558 minecraft:calcite
fill 83 267 567 83 268 567 minecraft:calcite
fill 83 267 569 83 268 569 minecraft:calcite
setblock 83 267 598 minecraft:calcite
fill 84 267 558 84 269 558 minecraft:cobbled_deepslate
fill 84 267 598 84 269 598 minecraft:cobbled_deepslate
fill 85 267 567 85 268 567 minecraft:calcite
fill 85 267 569 85 268 569 minecraft:calcite
setblock 85 267 582 minecraft:cobbled_deepslate
setblock 85 267 586 minecraft:calcite
fill 85 267 587 85 269 587 minecraft:cobbled_deepslate
fill 85 267 589 85 268 589 minecraft:cobbled_deepslate
setblock 86 267 564 minecraft:cobbled_deepslate
setblock 86 267 565 minecraft:calcite
fill 86 267 566 86 270 566 minecraft:cobbled_deepslate
fill 86 267 568 86 267 569 minecraft:cobbled_deepslate
setblock 86 267 570 minecraft:calcite
setblock 86 267 580 minecraft:calcite
fill 86 267 581 86 268 581 minecraft:cobbled_deepslate
setblock 86 267 585 minecraft:calcite
fill 86 267 586 86 270 586 minecraft:cobbled_deepslate
setblock 86 267 590 minecraft:calcite
setblock 87 267 564 minecraft:calcite
fill 87 267 565 87 270 565 minecraft:cobbled_deepslate
setblock 87 267 569 minecraft:calcite
fill 87 267 570 87 267 573 minecraft:cobbled_deepslate
setblock 87 267 574 minecraft:calcite
fill 87 267 575 87 270 575 minecraft:cobbled_deepslate
setblock 87 267 579 minecraft:calcite
fill 87 267 580 87 269 580 minecraft:cobbled_deepslate
setblock 87 267 584 minecraft:calcite
fill 87 267 585 87 270 585 minecraft:cobbled_deepslate
setblock 87 267 589 minecraft:calcite
fill 87 267 590 87 270 590 minecraft:cobbled_deepslate
setblock 88 267 563 minecraft:calcite
fill 88 267 564 88 270 564 minecraft:cobbled_deepslate
setblock 88 267 568 minecraft:calcite
fill 88 267 569 88 270 569 minecraft:cobbled_deepslate
setblock 88 267 573 minecraft:calcite
fill 88 267 574 88 270 574 minecraft:cobbled_deepslate
setblock 88 267 578 minecraft:calcite
fill 88 267 579 88 270 579 minecraft:cobbled_deepslate
setblock 88 267 583 minecraft:calcite
fill 88 267 584 88 270 584 minecraft:cobbled_deepslate
setblock 88 267 588 minecraft:calcite
fill 88 267 589 88 270 589 minecraft:cobbled_deepslate
setblock 88 267 593 minecraft:calcite
fill 48 268 558 51 268 558 minecraft:cobbled_deepslate
setblock 48 268 562 minecraft:calcite
fill 48 268 563 48 271 563 minecraft:cobbled_deepslate
setblock 48 268 567 minecraft:calcite
fill 48 268 568 48 271 568 minecraft:cobbled_deepslate
setblock 48 268 572 minecraft:calcite
fill 48 268 573 48 271 573 minecraft:cobbled_deepslate
setblock 48 268 577 minecraft:calcite
setblock 48 268 582 minecraft:calcite
fill 48 268 583 48 269 583 minecraft:cobbled_deepslate
setblock 48 268 587 minecraft:calcite
fill 48 268 588 48 271 588 minecraft:cobbled_deepslate
setblock 48 268 591 minecraft:cobbled_deepslate
setblock 49 268 561 minecraft:calcite
fill 49 268 562 49 270 562 minecraft:cobbled_deepslate
setblock 49 268 566 minecraft:calcite
fill 49 268 567 49 271 567 minecraft:cobbled_deepslate
setblock 49 268 571 minecraft:calcite
setblock 50 268 565 minecraft:calcite
fill 50 268 566 50 270 566 minecraft:cobbled_deepslate
fill 50 268 568 50 269 568 minecraft:cobbled_deepslate
setblock 52 268 558 minecraft:calcite
fill 53 268 558 53 271 558 minecraft:cobbled_deepslate
setblock 56 268 558 minecraft:cobbled_deepslate
setblock 56 268 559 minecraft:calcite
setblock 57 268 558 minecraft:calcite
fill 57 268 559 57 271 559 minecraft:cobbled_deepslate
setblock 57 268 598 minecraft:calcite
fill 58 268 558 58 271 558 minecraft:cobbled_deepslate
fill 58 268 598 58 271 598 minecraft:cobbled_deepslate
setblock 59 268 561 minecraft:calcite
fill 59 268 597 59 271 597 minecraft:cobbled_deepslate
setblock 60 268 560 minecraft:calcite
fill 60 268 561 60 269 561 minecraft:cobbled_deepslate
setblock 61 268 559 minecraft:calcite
fill 61 268 560 61 270 560 minecraft:cobbled_deepslate
setblock 62 268 558 minecraft:calcite
fill 62 268 559 62 271 559 minecraft:cobbled_deepslate
fill 62 268 596 63 268 596 minecraft:cobbled_deepslate
setblock 62 268 598 minecraft:calcite
fill 63 268 558 63 271 558 minecraft:cobbled_deepslate
setblock 63 268 597 minecraft:calcite
fill 63 268 598 63 271 598 minecraft:cobbled_deepslate
fill 64 268 597 64 271 597 minecraft:cobbled_deepslate
setblock 65 268 560 minecraft:calcite
setblock 66 268 559 minecraft:calcite
setblock 67 268 558 minecraft:calcite
setblock 67 268 559 minecraft:cobbled_deepslate
setblock 67 268 598 minecraft:calcite
fill 68 268 558 68 269 558 minecraft:cobbled_deepslate
fill 68 268 598 68 271 598 minecraft:cobbled_deepslate
setblock 76 268 598 minecraft:cobbled_deepslate
setblock 77 268 598 minecraft:calcite
fill 78 268 598 78 271 598 minecraft:cobbled_deepslate
setblock 82 268 558 minecraft:calcite
setblock 82 268 598 minecraft:calcite
fill 83 268 558 83 269 558 minecraft:cobbled_deepslate
fill 83 268 598 83 270 598 minecraft:cobbled_deepslate
setblock 85 268 585 minecraft:calcite
fill 85 268 586 85 269 586 minecraft:cobbled_deepslate
setblock 86 268 564 minecraft:calcite
fill 86 268 565 86 270 565 minecraft:cobbled_deepslate
setblock 86 268 568 minecraft:cobbled_deepslate
setblock 86 268 569 minecraft:calcite
fill 86 268 570 87 269 571 minecraft:cobbled_deepslate
setblock 86 268 580 minecraft:cobbled_deepslate
setblock 86 268 584 minecraft:calcite
fill 86 268 585 86 270 585 minecraft:cobbled_deepslate
setblock 86 268 589 minecraft:calcite
fill 86 268 590 86 269 590 minecraft:cobbled_deepslate
setblock 87 268 563 minecraft:calcite
fill 87 268 564 87 271 564 minecraft:cobbled_deepslate
setblock 87 268 568 minecraft:calcite
fill 87 268 569 87 271 569 minecraft:cobbled_deepslate
setblock 87 268 572 minecraft:cobbled_deepslate
setblock 87 268 573 minecraft:calcite
fill 87 268 574 87 271 574 minecraft:cobbled_deepslate
setblock 87 268 578 minecraft:calcite
fill 87 268 579 87 269 579 minecraft:cobbled_deepslate
setblock 87 268 583 minecraft:calcite
fill 87 268 584 87 270 584 minecraft:cobbled_deepslate
setblock 87 268 588 minecraft:calcite
fill 87 268 589 87 271 589 minecraft:cobbled_deepslate
setblock 87 268 592 minecraft:cobbled_deepslate
setblock 88 268 562 minecraft:calcite
fill 88 268 563 88 271 563 minecraft:cobbled_deepslate
setblock 88 268 567 minecraft:calcite
fill 88 268 568 88 271 568 minecraft:cobbled_deepslate
setblock 88 268 572 minecraft:calcite
fill 88 268 573 88 271 573 minecraft:cobbled_deepslate
setblock 88 268 577 minecraft:calcite
fill 88 268 578 88 271 578 minecraft:cobbled_deepslate
setblock 88 268 582 minecraft:calcite
fill 88 268 583 88 271 583 minecraft:cobbled_deepslate
setblock 88 268 587 minecraft:calcite
fill 88 268 588 88 271 588 minecraft:cobbled_deepslate
setblock 88 268 591 minecraft:cobbled_deepslate
setblock 88 268 592 minecraft:calcite
fill 88 268 593 88 270 593 minecraft:cobbled_deepslate
setblock 48 269 558 minecraft:cobbled_deepslate
setblock 48 269 561 minecraft:calcite
fill 48 269 562 48 272 562 minecraft:cobbled_deepslate
setblock 48 269 566 minecraft:calcite
fill 48 269 567 48 272 567 minecraft:cobbled_deepslate
setblock 48 269 571 minecraft:calcite
fill 48 269 572 48 272 572 minecraft:cobbled_deepslate
setblock 48 269 582 minecraft:cobbled_deepslate
setblock 48 269 586 minecraft:calcite
fill 48 269 587 48 270 587 minecraft:cobbled_deepslate
setblock 48 269 591 minecraft:calcite
setblock 49 269 561 minecraft:cobbled_deepslate
setblock 49 269 565 minecraft:calcite
fill 49 269 566 49 272 566 minecraft:cobbled_deepslate
setblock 49 269 570 minecraft:calcite
fill 49 269 571 49 272 571 minecraft:cobbled_deepslate
setblock 50 269 564 minecraft:calcite
fill 50 269 565 50 270 565 minecraft:cobbled_deepslate
fill 52 269 558 52 270 558 minecraft:cobbled_deepslate
setblock 55 269 558 minecraft:cobbled_deepslate
setblock 55 269 559 minecraft:calcite
setblock 56 269 558 minecraft:calcite
fill 56 269 559 56 272 559 minecraft:cobbled_deepslate
setblock 56 269 598 minecraft:calcite
fill 57 269 558 57 272 558 minecraft:cobbled_deepslate
fill 57 269 598 57 272 598 minecraft:cobbled_deepslate
fill 58 269 597 58 272 597 minecraft:cobbled_deepslate
setblock 59 269 560 minecraft:calcite
setblock 60 269 559 minecraft:calcite
fill 60 269 560 60 271 560 minecraft:cobbled_deepslate
setblock 61 269 558 minecraft:calcite
fill 61 269 559 61 272 559 minecraft:cobbled_deepslate
fill 61 269 596 62 269 596 minecraft:cobbled_deepslate
setblock 61 269 598 minecraft:calcite
fill 62 269 558 62 272 558 minecraft:cobbled_deepslate
setblock 62 269 597 minecraft:calcite
fill 62 269 598 62 272 598 minecraft:cobbled_deepslate
setblock 63 269 596 minecraft:calcite
fill 63 269 597 63 272 597 minecraft:cobbled_deepslate
setblock 64 269 560 minecraft:calcite
schedule function dropper:buildpart/133_10 1t
