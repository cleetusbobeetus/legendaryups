setblock 141 221 205 minecraft:sea_lantern
fill 142 221 181 142 307 181 minecraft:black_concrete
fill 145 221 181 145 224 181 minecraft:black_concrete
fill 154 221 181 154 242 181 minecraft:black_concrete
setblock 159 221 181 minecraft:sea_lantern
fill 160 221 181 160 235 181 minecraft:black_concrete
fill 141 222 205 141 224 205 minecraft:black_concrete
setblock 157 222 223 minecraft:sea_lantern
fill 159 222 181 159 307 181 minecraft:black_concrete
setblock 183 222 207 minecraft:sea_lantern
setblock 183 222 212 minecraft:sea_lantern
fill 183 222 216 183 222 217 minecraft:sea_lantern
fill 183 222 218 183 307 218 minecraft:black_concrete
fill 157 223 223 157 307 223 minecraft:black_concrete
fill 183 223 207 183 224 207 minecraft:black_concrete
fill 183 223 212 183 246 212 minecraft:black_concrete
fill 183 223 216 183 244 217 minecraft:black_concrete
setblock 146 224 181 minecraft:sea_lantern
fill 183 224 197 183 307 197 minecraft:black_concrete
setblock 183 224 198 minecraft:white_concrete
fill 183 224 199 183 253 200 minecraft:black_concrete
fill 141 225 189 141 227 189 minecraft:cyan_concrete
fill 141 225 205 141 227 205 minecraft:cyan_concrete
fill 141 225 221 141 227 221 minecraft:cyan_concrete
setblock 144 225 181 minecraft:sea_lantern
setblock 144 225 184 minecraft:light[level=10]
setblock 144 225 192 minecraft:light[level=10]
setblock 144 225 200 minecraft:light[level=10]
setblock 144 225 208 minecraft:light[level=10]
setblock 144 225 216 minecraft:light[level=10]
fill 145 225 181 145 227 181 minecraft:cyan_concrete
fill 146 225 181 146 261 181 minecraft:black_concrete
setblock 152 225 184 minecraft:light[level=10]
setblock 152 225 192 minecraft:light[level=10]
setblock 152 225 200 minecraft:light[level=10]
setblock 152 225 208 minecraft:light[level=10]
setblock 152 225 216 minecraft:light[level=10]
fill 155 225 223 155 227 223 minecraft:cyan_concrete
setblock 160 225 184 minecraft:light[level=10]
setblock 160 225 192 minecraft:light[level=10]
setblock 160 225 200 minecraft:light[level=10]
setblock 160 225 208 minecraft:light[level=10]
setblock 160 225 216 minecraft:light[level=10]
fill 161 225 181 161 227 181 minecraft:cyan_concrete
setblock 168 225 184 minecraft:light[level=10]
setblock 168 225 192 minecraft:light[level=10]
setblock 168 225 200 minecraft:light[level=10]
setblock 168 225 208 minecraft:light[level=10]
setblock 168 225 216 minecraft:light[level=10]
fill 171 225 223 171 227 223 minecraft:cyan_concrete
setblock 176 225 184 minecraft:light[level=10]
setblock 176 225 192 minecraft:light[level=10]
setblock 176 225 200 minecraft:light[level=10]
setblock 176 225 208 minecraft:light[level=10]
setblock 176 225 216 minecraft:light[level=10]
fill 177 225 181 177 227 181 minecraft:cyan_concrete
fill 183 225 191 183 227 191 minecraft:cyan_concrete
setblock 183 225 195 minecraft:white_concrete
fill 183 225 198 183 254 198 minecraft:black_concrete
fill 183 225 207 183 227 207 minecraft:cyan_concrete
setblock 183 225 211 minecraft:sea_lantern
fill 144 226 181 144 243 181 minecraft:black_concrete
fill 183 226 195 183 248 195 minecraft:black_concrete
fill 183 226 211 183 307 211 minecraft:black_concrete
fill 141 228 189 141 234 189 minecraft:black_concrete
fill 141 228 205 141 242 205 minecraft:black_concrete
fill 141 228 221 141 242 221 minecraft:black_concrete
fill 145 228 181 145 242 181 minecraft:black_concrete
fill 155 228 223 155 242 223 minecraft:black_concrete
fill 161 228 181 161 242 181 minecraft:black_concrete
fill 171 228 223 171 242 223 minecraft:black_concrete
fill 177 228 181 177 242 181 minecraft:black_concrete
fill 183 228 191 183 242 191 minecraft:black_concrete
fill 183 228 207 183 242 207 minecraft:black_concrete
setblock 183 228 210 minecraft:sea_lantern
fill 142 229 223 142 245 223 minecraft:black_concrete
setblock 143 229 223 minecraft:sea_lantern
fill 183 229 210 183 304 210 minecraft:black_concrete
fill 141 230 211 141 267 213 minecraft:black_concrete
setblock 141 230 214 minecraft:sea_lantern
fill 141 230 215 141 307 215 minecraft:black_concrete
fill 143 230 223 143 253 223 minecraft:black_concrete
fill 141 231 214 141 250 214 minecraft:black_concrete
fill 141 231 219 141 236 219 minecraft:black_concrete
setblock 141 231 220 minecraft:white_concrete
setblock 164 231 181 minecraft:sea_lantern
fill 141 232 220 141 244 220 minecraft:black_concrete
fill 164 232 181 164 273 181 minecraft:black_concrete
setblock 141 233 199 minecraft:sea_lantern
setblock 144 233 184 minecraft:light[level=10]
setblock 144 233 192 minecraft:light[level=10]
setblock 144 233 200 minecraft:light[level=10]
setblock 144 233 208 minecraft:light[level=10]
setblock 144 233 216 minecraft:light[level=10]
setblock 152 233 184 minecraft:light[level=10]
setblock 152 233 192 minecraft:light[level=10]
setblock 152 233 200 minecraft:light[level=10]
setblock 152 233 208 minecraft:light[level=10]
setblock 152 233 216 minecraft:light[level=10]
setblock 160 233 184 minecraft:light[level=10]
setblock 160 233 192 minecraft:light[level=10]
setblock 160 233 200 minecraft:light[level=10]
setblock 160 233 208 minecraft:light[level=10]
setblock 160 233 216 minecraft:light[level=10]
setblock 168 233 184 minecraft:light[level=10]
setblock 168 233 192 minecraft:light[level=10]
setblock 168 233 200 minecraft:light[level=10]
setblock 168 233 208 minecraft:light[level=10]
setblock 168 233 216 minecraft:light[level=10]
setblock 176 233 184 minecraft:light[level=10]
setblock 176 233 192 minecraft:light[level=10]
setblock 176 233 200 minecraft:light[level=10]
setblock 176 233 208 minecraft:light[level=10]
setblock 176 233 216 minecraft:light[level=10]
fill 141 234 183 141 259 185 minecraft:black_concrete
setblock 141 234 186 minecraft:sea_lantern
fill 141 234 187 141 307 187 minecraft:black_concrete
fill 141 234 199 141 263 199 minecraft:black_concrete
setblock 141 235 186 minecraft:white_concrete
setblock 141 235 189 minecraft:white_concrete
fill 148 235 198 149 236 198 minecraft:black_concrete
fill 149 235 195 150 236 197 minecraft:black_concrete
fill 149 235 199 150 236 201 minecraft:black_concrete
fill 150 235 193 151 236 194 minecraft:black_concrete
fill 150 235 198 157 236 198 minecraft:sea_lantern
fill 150 235 202 151 236 203 minecraft:black_concrete
fill 151 235 192 154 236 192 minecraft:black_concrete
fill 151 235 195 157 236 197 minecraft:sea_lantern
fill 151 235 199 157 236 201 minecraft:sea_lantern
fill 151 235 204 154 236 204 minecraft:black_concrete
fill 152 235 193 152 236 193 minecraft:black_concrete
fill 152 235 194 159 236 194 minecraft:sea_lantern
fill 152 235 202 159 236 202 minecraft:sea_lantern
fill 152 235 203 152 236 203 minecraft:black_concrete
fill 153 235 191 156 236 191 minecraft:black_concrete
fill 153 235 193 160 236 193 minecraft:sea_lantern
fill 153 235 203 160 236 203 minecraft:sea_lantern
fill 153 235 205 156 236 205 minecraft:black_concrete
fill 154 235 190 161 236 190 minecraft:black_concrete
fill 154 235 206 161 236 206 minecraft:black_concrete
fill 155 235 192 171 236 192 minecraft:sea_lantern
fill 155 235 204 171 236 204 minecraft:sea_lantern
fill 156 235 181 157 244 181 minecraft:black_concrete
fill 157 235 189 169 236 189 minecraft:black_concrete
fill 157 235 191 169 236 191 minecraft:sea_lantern
fill 157 235 205 169 236 205 minecraft:sea_lantern
fill 157 235 207 169 236 207 minecraft:black_concrete
setblock 158 235 181 minecraft:sea_lantern
fill 158 235 195 158 236 195 minecraft:sea_lantern
fill 158 235 196 158 236 196 minecraft:cyan_concrete
fill 158 235 197 158 236 197 minecraft:sculk
fill 158 235 198 159 235 198 minecraft:cyan_concrete
fill 158 235 199 158 236 199 minecraft:sculk
fill 158 235 200 158 236 200 minecraft:cyan_concrete
fill 158 235 201 158 236 201 minecraft:sea_lantern
fill 159 235 195 161 235 195 minecraft:cyan_concrete
fill 159 235 196 159 236 196 minecraft:sculk
fill 159 235 197 160 235 197 minecraft:cyan_concrete
fill 159 235 199 160 235 199 minecraft:cyan_concrete
fill 159 235 200 159 236 200 minecraft:sculk
fill 159 235 201 161 235 201 minecraft:cyan_concrete
fill 160 235 194 160 236 194 minecraft:sculk
setblock 160 235 196 minecraft:cyan_concrete
setblock 160 235 200 minecraft:cyan_concrete
fill 160 235 202 160 236 202 minecraft:sculk
fill 161 235 193 161 236 193 minecraft:sculk
fill 161 235 194 162 235 194 minecraft:cyan_concrete
fill 161 235 202 162 235 202 minecraft:cyan_concrete
fill 161 235 203 161 236 203 minecraft:sculk
fill 162 235 188 164 236 188 minecraft:black_concrete
fill 162 235 190 164 236 190 minecraft:sea_lantern
fill 162 235 193 162 236 193 minecraft:cyan_concrete
setblock 162 235 195 minecraft:sculk
setblock 162 235 201 minecraft:sculk
fill 162 235 203 162 236 203 minecraft:cyan_concrete
fill 162 235 206 164 236 206 minecraft:sea_lantern
fill 162 235 208 164 236 208 minecraft:black_concrete
fill 163 235 193 163 235 194 minecraft:sculk
fill 163 235 202 163 235 203 minecraft:sculk
fill 164 235 193 164 235 194 minecraft:cyan_concrete
setblock 164 235 195 minecraft:sculk
setblock 164 235 201 minecraft:sculk
fill 164 235 202 164 235 203 minecraft:cyan_concrete
fill 165 235 190 172 236 190 minecraft:black_concrete
fill 165 235 193 165 236 193 minecraft:sculk
fill 165 235 194 165 235 195 minecraft:cyan_concrete
fill 165 235 201 165 235 202 minecraft:cyan_concrete
fill 165 235 203 165 236 203 minecraft:sculk
fill 165 235 206 172 236 206 minecraft:black_concrete
fill 166 235 193 173 236 193 minecraft:sea_lantern
fill 166 235 194 166 236 194 minecraft:sculk
fill 166 235 195 166 235 197 minecraft:cyan_concrete
fill 166 235 199 166 235 201 minecraft:cyan_concrete
fill 166 235 202 166 236 202 minecraft:sculk
fill 166 235 203 173 236 203 minecraft:sea_lantern
fill 167 235 194 174 236 194 minecraft:sea_lantern
fill 167 235 195 167 236 195 minecraft:cyan_concrete
fill 167 235 196 167 236 196 minecraft:sculk
fill 167 235 197 167 235 199 minecraft:cyan_concrete
fill 167 235 200 167 236 200 minecraft:sculk
fill 167 235 201 167 236 201 minecraft:cyan_concrete
fill 167 235 202 174 236 202 minecraft:sea_lantern
fill 168 235 195 175 236 195 minecraft:sea_lantern
fill 168 235 196 168 236 196 minecraft:cyan_concrete
fill 168 235 197 168 236 197 minecraft:sculk
fill 168 235 198 168 236 198 minecraft:cyan_concrete
fill 168 235 199 168 236 199 minecraft:sculk
fill 168 235 200 168 236 200 minecraft:cyan_concrete
fill 168 235 201 175 236 201 minecraft:sea_lantern
fill 169 235 196 175 236 200 minecraft:sea_lantern
fill 170 235 191 173 236 191 minecraft:black_concrete
fill 170 235 205 173 236 205 minecraft:black_concrete
fill 172 235 192 175 236 192 minecraft:black_concrete
fill 172 235 204 175 236 204 minecraft:black_concrete
fill 174 235 193 176 236 193 minecraft:black_concrete
fill 174 235 203 176 236 203 minecraft:black_concrete
fill 175 235 194 176 236 194 minecraft:black_concrete
fill 175 235 202 176 236 202 minecraft:black_concrete
fill 176 235 195 177 236 197 minecraft:black_concrete
fill 176 235 198 176 236 198 minecraft:sea_lantern
fill 176 235 199 177 236 201 minecraft:black_concrete
fill 177 235 198 178 236 198 minecraft:black_concrete
fill 141 236 186 182 236 186 minecraft:black_concrete
fill 141 236 189 156 236 189 minecraft:black_concrete
setblock 141 236 208 minecraft:sea_lantern
fill 142 236 182 182 236 185 minecraft:black_concrete
fill 142 236 187 161 236 188 minecraft:black_concrete
fill 142 236 190 147 236 222 minecraft:black_concrete
fill 148 236 190 148 236 197 minecraft:black_concrete
fill 148 236 199 148 236 222 minecraft:black_concrete
fill 149 236 190 149 236 194 minecraft:black_concrete
fill 149 236 202 149 236 222 minecraft:black_concrete
fill 150 236 190 150 236 192 minecraft:black_concrete
fill 150 236 204 150 236 222 minecraft:black_concrete
fill 151 236 190 152 236 191 minecraft:black_concrete
fill 151 236 205 152 236 222 minecraft:black_concrete
setblock 153 236 190 minecraft:black_concrete
fill 153 236 206 153 236 222 minecraft:black_concrete
fill 154 236 207 156 236 222 minecraft:black_concrete
fill 157 236 208 161 236 222 minecraft:black_concrete
fill 158 236 181 158 307 181 minecraft:black_concrete
setblock 158 236 198 minecraft:cyan_concrete
setblock 159 236 195 minecraft:cyan_concrete
fill 159 236 197 159 236 199 minecraft:sea_lantern
setblock 159 236 201 minecraft:cyan_concrete
setblock 160 236 181 minecraft:sea_lantern
fill 160 236 195 160 236 197 minecraft:sea_lantern
fill 160 236 199 160 236 201 minecraft:sea_lantern
setblock 161 236 194 minecraft:cyan_concrete
fill 161 236 195 162 236 195 minecraft:sea_lantern
fill 161 236 201 162 236 201 minecraft:sea_lantern
setblock 161 236 202 minecraft:cyan_concrete
fill 162 236 187 182 236 187 minecraft:black_concrete
fill 162 236 194 164 236 194 minecraft:sea_lantern
fill 162 236 202 164 236 202 minecraft:sea_lantern
fill 162 236 209 182 236 222 minecraft:black_concrete
setblock 163 236 193 minecraft:sculk
setblock 163 236 203 minecraft:sculk
setblock 164 236 193 minecraft:cyan_concrete
fill 164 236 195 166 236 195 minecraft:sea_lantern
fill 164 236 201 166 236 201 minecraft:sea_lantern
setblock 164 236 203 minecraft:cyan_concrete
fill 165 236 188 182 236 188 minecraft:black_concrete
setblock 165 236 194 minecraft:cyan_concrete
setblock 165 236 202 minecraft:cyan_concrete
fill 165 236 208 182 236 208 minecraft:black_concrete
fill 166 236 196 166 236 197 minecraft:sea_lantern
fill 166 236 199 166 236 200 minecraft:sea_lantern
fill 167 236 197 167 236 199 minecraft:sea_lantern
fill 170 236 189 182 236 189 minecraft:black_concrete
fill 170 236 207 182 236 207 minecraft:black_concrete
fill 173 236 190 182 236 190 minecraft:black_concrete
fill 173 236 206 182 236 206 minecraft:black_concrete
fill 174 236 191 182 236 191 minecraft:black_concrete
fill 174 236 205 182 236 205 minecraft:black_concrete
fill 176 236 192 182 236 192 minecraft:black_concrete
fill 176 236 204 182 236 204 minecraft:black_concrete
fill 177 236 193 182 236 194 minecraft:black_concrete
fill 177 236 202 182 236 203 minecraft:black_concrete
fill 178 236 195 182 236 197 minecraft:black_concrete
fill 178 236 199 182 236 201 minecraft:black_concrete
fill 179 236 198 182 236 198 minecraft:black_concrete
setblock 141 237 186 minecraft:sea_lantern
fill 141 237 189 141 242 189 minecraft:black_concrete
fill 141 237 208 141 307 208 minecraft:black_concrete
setblock 141 237 219 minecraft:sea_lantern
setblock 141 237 222 minecraft:sea_lantern
fill 141 237 223 141 307 223 minecraft:black_concrete
fill 160 237 181 160 255 181 minecraft:black_concrete
fill 141 238 186 141 276 186 minecraft:black_concrete
fill 141 238 219 141 302 219 minecraft:black_concrete
fill 141 238 222 141 287 222 minecraft:black_concrete
setblock 163 238 223 minecraft:white_concrete
fill 179 238 181 179 239 181 minecraft:black_concrete
setblock 180 238 181 minecraft:sea_lantern
fill 148 239 181 149 244 181 minecraft:black_concrete
setblock 150 239 181 minecraft:sea_lantern
fill 163 239 223 163 249 223 minecraft:black_concrete
setblock 170 239 223 minecraft:sea_lantern
fill 180 239 181 180 307 181 minecraft:black_concrete
fill 150 240 181 150 307 181 minecraft:black_concrete
fill 151 240 220 153 240 220 minecraft:black_concrete
setblock 152 240 219 minecraft:black_concrete
setblock 152 240 221 minecraft:black_concrete
fill 160 240 219 162 242 219 minecraft:black_concrete
fill 161 240 218 161 242 218 minecraft:black_concrete
fill 161 240 220 161 242 220 minecraft:black_concrete
fill 170 240 223 170 256 223 minecraft:black_concrete
setblock 179 240 181 minecraft:sea_lantern
setblock 144 241 184 minecraft:light[level=10]
setblock 144 241 192 minecraft:light[level=10]
setblock 144 241 200 minecraft:light[level=10]
setblock 144 241 208 minecraft:light[level=10]
setblock 144 241 216 minecraft:light[level=10]
setblock 152 241 184 minecraft:light[level=10]
setblock 152 241 192 minecraft:light[level=10]
setblock 152 241 200 minecraft:light[level=10]
setblock 152 241 208 minecraft:light[level=10]
setblock 152 241 216 minecraft:light[level=10]
setblock 160 241 184 minecraft:light[level=10]
setblock 160 241 192 minecraft:light[level=10]
setblock 160 241 200 minecraft:light[level=10]
setblock 160 241 208 minecraft:light[level=10]
setblock 160 241 216 minecraft:light[level=10]
setblock 168 241 184 minecraft:light[level=10]
setblock 168 241 192 minecraft:light[level=10]
setblock 168 241 200 minecraft:light[level=10]
setblock 168 241 208 minecraft:light[level=10]
setblock 168 241 216 minecraft:light[level=10]
setblock 176 241 184 minecraft:light[level=10]
setblock 176 241 192 minecraft:light[level=10]
setblock 176 241 200 minecraft:light[level=10]
setblock 176 241 208 minecraft:light[level=10]
setblock 176 241 216 minecraft:light[level=10]
fill 179 241 181 179 261 181 minecraft:black_concrete
setblock 183 241 219 minecraft:sea_lantern
fill 177 242 223 177 258 223 minecraft:black_concrete
setblock 178 242 223 minecraft:white_concrete
fill 183 242 219 183 307 219 minecraft:black_concrete
fill 141 243 189 141 245 189 minecraft:cyan_concrete
fill 141 243 205 141 245 205 minecraft:cyan_concrete
fill 141 243 221 141 245 221 minecraft:cyan_concrete
fill 145 243 181 145 245 181 minecraft:cyan_concrete
setblock 154 243 181 minecraft:sea_lantern
fill 155 243 223 155 245 223 minecraft:cyan_concrete
fill 161 243 181 161 245 181 minecraft:cyan_concrete
setblock 163 243 181 minecraft:sea_lantern
fill 171 243 223 171 245 223 minecraft:cyan_concrete
fill 177 243 181 177 245 181 minecraft:cyan_concrete
fill 178 243 223 178 307 223 minecraft:black_concrete
setblock 181 243 223 minecraft:sea_lantern
fill 183 243 191 183 245 191 minecraft:cyan_concrete
setblock 183 243 206 minecraft:white_concrete
fill 183 243 207 183 245 207 minecraft:cyan_concrete
setblock 183 243 221 minecraft:sea_lantern
setblock 144 244 181 minecraft:white_concrete
fill 154 244 181 154 256 181 minecraft:black_concrete
fill 163 244 181 163 307 181 minecraft:black_concrete
setblock 181 244 223 minecraft:black_concrete
setblock 183 244 183 minecraft:white_concrete
setblock 183 244 204 minecraft:sea_lantern
fill 183 244 206 183 307 206 minecraft:black_concrete
fill 183 244 221 183 307 221 minecraft:black_concrete
setblock 141 245 202 minecraft:white_concrete
setblock 141 245 220 minecraft:sea_lantern
fill 144 245 181 144 307 181 minecraft:black_concrete
fill 148 245 181 148 262 181 minecraft:black_concrete
setblock 148 245 223 minecraft:sea_lantern
setblock 149 245 181 minecraft:sea_lantern
fill 156 245 181 156 258 181 minecraft:black_concrete
setblock 157 245 181 minecraft:sea_lantern
setblock 181 245 223 minecraft:sea_lantern
fill 183 245 183 183 268 183 minecraft:black_concrete
setblock 183 245 185 minecraft:sea_lantern
setblock 183 245 203 minecraft:white_concrete
fill 183 245 204 183 271 204 minecraft:black_concrete
fill 183 245 216 183 307 216 minecraft:black_concrete
setblock 183 245 217 minecraft:sea_lantern
fill 141 246 189 141 247 189 minecraft:black_concrete
fill 141 246 202 141 301 202 minecraft:black_concrete
fill 141 246 205 141 251 205 minecraft:black_concrete
fill 141 246 220 141 251 221 minecraft:black_concrete
setblock 142 246 223 minecraft:white_concrete
fill 145 246 181 145 251 181 minecraft:black_concrete
fill 148 246 223 148 291 223 minecraft:black_concrete
fill 149 246 181 149 251 181 minecraft:black_concrete
fill 155 246 223 155 251 223 minecraft:black_concrete
fill 157 246 181 157 307 181 minecraft:black_concrete
fill 161 246 181 161 251 181 minecraft:black_concrete
fill 171 246 223 171 251 223 minecraft:black_concrete
fill 177 246 181 177 251 181 minecraft:black_concrete
fill 181 246 223 181 249 223 minecraft:black_concrete
setblock 183 246 182 minecraft:white_concrete
fill 183 246 185 183 303 185 minecraft:black_concrete
fill 183 246 191 183 251 191 minecraft:black_concrete
fill 183 246 203 183 271 203 minecraft:black_concrete
fill 183 246 207 183 251 207 minecraft:black_concrete
fill 183 246 217 183 289 217 minecraft:black_concrete
fill 142 247 223 142 296 223 minecraft:black_concrete
fill 183 247 182 183 307 182 minecraft:black_concrete
setblock 183 247 187 minecraft:sea_lantern
fill 183 247 188 183 307 188 minecraft:black_concrete
setblock 183 247 212 minecraft:sea_lantern
setblock 141 248 189 minecraft:white_concrete
setblock 141 248 190 minecraft:sea_lantern
setblock 141 248 197 minecraft:sea_lantern
fill 141 248 198 141 275 198 minecraft:black_concrete
setblock 172 248 223 minecraft:sea_lantern
fill 183 248 187 183 307 187 minecraft:black_concrete
fill 183 248 212 183 305 212 minecraft:black_concrete
fill 141 249 189 141 251 190 minecraft:black_concrete
setblock 141 249 197 minecraft:black_concrete
setblock 144 249 184 minecraft:light[level=10]
setblock 144 249 192 minecraft:light[level=10]
setblock 144 249 200 minecraft:light[level=10]
setblock 144 249 208 minecraft:light[level=10]
setblock 144 249 216 minecraft:light[level=10]
setblock 152 249 184 minecraft:light[level=10]
setblock 152 249 192 minecraft:light[level=10]
setblock 152 249 200 minecraft:light[level=10]
setblock 152 249 208 minecraft:light[level=10]
setblock 152 249 216 minecraft:light[level=10]
setblock 160 249 184 minecraft:light[level=10]
setblock 160 249 192 minecraft:light[level=10]
setblock 160 249 200 minecraft:light[level=10]
setblock 160 249 208 minecraft:light[level=10]
setblock 160 249 216 minecraft:light[level=10]
setblock 168 249 184 minecraft:light[level=10]
setblock 168 249 192 minecraft:light[level=10]
setblock 168 249 200 minecraft:light[level=10]
setblock 168 249 208 minecraft:light[level=10]
setblock 168 249 216 minecraft:light[level=10]
fill 172 249 223 172 263 223 minecraft:black_concrete
setblock 176 249 184 minecraft:light[level=10]
setblock 176 249 192 minecraft:light[level=10]
setblock 176 249 200 minecraft:light[level=10]
setblock 176 249 208 minecraft:light[level=10]
setblock 176 249 216 minecraft:light[level=10]
setblock 183 249 195 minecraft:sea_lantern
setblock 141 250 197 minecraft:white_concrete
setblock 163 250 223 minecraft:white_concrete
setblock 175 250 181 minecraft:sea_lantern
fill 176 250 181 176 253 181 minecraft:black_concrete
setblock 181 250 223 minecraft:sea_lantern
fill 183 250 195 183 307 195 minecraft:black_concrete
fill 141 251 197 141 307 197 minecraft:black_concrete
setblock 141 251 214 minecraft:white_concrete
fill 152 251 181 152 252 181 minecraft:sea_lantern
fill 163 251 223 163 269 223 minecraft:black_concrete
fill 175 251 181 175 307 181 minecraft:black_concrete
fill 181 251 223 181 307 223 minecraft:black_concrete
setblock 182 251 223 minecraft:sea_lantern
fill 183 251 223 183 307 223 minecraft:black_concrete
setblock 141 252 188 minecraft:sea_lantern
fill 141 252 189 141 254 189 minecraft:cyan_concrete
fill 141 252 190 141 307 190 minecraft:black_concrete
fill 141 252 205 141 254 205 minecraft:cyan_concrete
fill 141 252 214 141 264 214 minecraft:black_concrete
fill 141 252 220 141 273 220 minecraft:black_concrete
fill 141 252 221 141 254 221 minecraft:cyan_concrete
fill 145 252 181 145 254 181 minecraft:cyan_concrete
setblock 149 252 181 minecraft:white_concrete
fill 155 252 223 155 254 223 minecraft:cyan_concrete
fill 161 252 181 161 254 181 minecraft:cyan_concrete
setblock 166 252 181 minecraft:sea_lantern
fill 167 252 181 167 291 181 minecraft:black_concrete
fill 171 252 223 171 254 223 minecraft:cyan_concrete
fill 174 252 223 174 307 223 minecraft:black_concrete
setblock 175 252 223 minecraft:white_concrete
fill 176 252 223 176 307 223 minecraft:black_concrete
fill 177 252 181 177 254 181 minecraft:cyan_concrete
setblock 180 252 223 minecraft:white_concrete
fill 182 252 223 182 305 223 minecraft:black_concrete
fill 183 252 191 183 254 191 minecraft:cyan_concrete
fill 183 252 207 183 254 207 minecraft:cyan_concrete
fill 141 253 188 141 262 188 minecraft:black_concrete
fill 149 253 181 149 307 181 minecraft:black_concrete
fill 152 253 181 152 283 181 minecraft:black_concrete
setblock 155 253 181 minecraft:white_concrete
fill 166 253 181 166 259 181 minecraft:black_concrete
setblock 167 253 223 minecraft:sea_lantern
fill 168 253 223 168 307 223 minecraft:black_concrete
fill 175 253 223 175 307 223 minecraft:black_concrete
fill 180 253 223 180 307 223 minecraft:black_concrete
setblock 143 254 223 minecraft:white_concrete
fill 155 254 181 155 307 181 minecraft:black_concrete
setblock 160 254 223 minecraft:sea_lantern
fill 161 254 223 161 299 223 minecraft:black_concrete
fill 167 254 223 167 307 223 minecraft:black_concrete
setblock 176 254 181 minecraft:sea_lantern
setblock 183 254 190 minecraft:white_concrete
setblock 183 254 199 minecraft:sea_lantern
fill 183 254 200 183 255 200 minecraft:black_concrete
setblock 183 254 208 minecraft:sea_lantern
fill 183 254 209 183 260 209 minecraft:black_concrete
fill 141 255 189 141 259 189 minecraft:black_concrete
fill 141 255 205 141 260 205 minecraft:black_concrete
setblock 141 255 207 minecraft:white_concrete
fill 141 255 221 141 260 221 minecraft:black_concrete
fill 143 255 223 143 307 223 minecraft:black_concrete
fill 145 255 181 145 260 181 minecraft:black_concrete
fill 155 255 223 155 260 223 minecraft:black_concrete
fill 160 255 223 160 290 223 minecraft:black_concrete
fill 161 255 181 161 258 181 minecraft:black_concrete
fill 171 255 223 171 260 223 minecraft:black_concrete
fill 176 255 181 177 260 181 minecraft:black_concrete
fill 183 255 190 183 257 191 minecraft:black_concrete
setblock 183 255 198 minecraft:white_concrete
fill 183 255 199 183 264 199 minecraft:black_concrete
fill 183 255 207 183 260 208 minecraft:black_concrete
fill 141 256 207 141 307 207 minecraft:black_concrete
fill 145 256 223 145 307 223 minecraft:black_concrete
setblock 146 256 223 minecraft:sea_lantern
setblock 151 256 181 minecraft:sea_lantern
setblock 160 256 181 minecraft:sea_lantern
setblock 170 256 181 minecraft:sea_lantern
fill 171 256 181 171 307 181 minecraft:black_concrete
setblock 178 256 181 minecraft:sea_lantern
fill 183 256 198 183 307 198 minecraft:black_concrete
setblock 183 256 200 minecraft:sea_lantern
setblock 144 257 184 minecraft:light[level=10]
setblock 144 257 192 minecraft:light[level=10]
setblock 144 257 200 minecraft:light[level=10]
setblock 144 257 208 minecraft:light[level=10]
setblock 144 257 216 minecraft:light[level=10]
fill 146 257 223 146 296 223 minecraft:black_concrete
fill 151 257 181 151 262 181 minecraft:black_concrete
setblock 152 257 184 minecraft:light[level=10]
setblock 152 257 192 minecraft:light[level=10]
setblock 152 257 200 minecraft:light[level=10]
setblock 152 257 208 minecraft:light[level=10]
setblock 152 257 216 minecraft:light[level=10]
setblock 154 257 181 minecraft:sea_lantern
fill 160 257 181 160 307 181 minecraft:black_concrete
setblock 160 257 184 minecraft:light[level=10]
setblock 160 257 192 minecraft:light[level=10]
setblock 160 257 200 minecraft:light[level=10]
setblock 160 257 208 minecraft:light[level=10]
setblock 160 257 216 minecraft:light[level=10]
setblock 168 257 184 minecraft:light[level=10]
setblock 168 257 192 minecraft:light[level=10]
setblock 168 257 200 minecraft:light[level=10]
setblock 168 257 208 minecraft:light[level=10]
setblock 168 257 216 minecraft:light[level=10]
fill 170 257 181 170 307 181 minecraft:black_concrete
setblock 170 257 223 minecraft:sea_lantern
setblock 176 257 184 minecraft:light[level=10]
setblock 176 257 192 minecraft:light[level=10]
setblock 176 257 200 minecraft:light[level=10]
setblock 176 257 208 minecraft:light[level=10]
setblock 176 257 216 minecraft:light[level=10]
fill 178 257 181 178 307 181 minecraft:black_concrete
fill 183 257 200 183 306 200 minecraft:black_concrete
fill 154 258 181 154 307 181 minecraft:black_concrete
fill 170 258 223 170 307 223 minecraft:black_concrete
setblock 181 258 181 minecraft:sea_lantern
setblock 183 258 190 minecraft:white_concrete
fill 183 258 191 183 260 191 minecraft:black_concrete
setblock 183 258 214 minecraft:sea_lantern
fill 183 258 215 183 271 215 minecraft:black_concrete
setblock 183 258 220 minecraft:sea_lantern
setblock 156 259 181 minecraft:sea_lantern
setblock 161 259 181 minecraft:white_concrete
setblock 177 259 223 minecraft:white_concrete
fill 181 259 181 181 291 181 minecraft:black_concrete
fill 183 259 190 183 270 190 minecraft:black_concrete
fill 183 259 214 183 292 214 minecraft:black_concrete
fill 183 259 220 183 307 220 minecraft:black_concrete
fill 141 260 183 141 270 183 minecraft:black_concrete
setblock 141 260 184 minecraft:sea_lantern
fill 141 260 185 141 307 185 minecraft:black_concrete
setblock 141 260 189 minecraft:sea_lantern
setblock 141 260 216 minecraft:sea_lantern
fill 156 260 181 156 307 181 minecraft:black_concrete
setblock 161 260 181 minecraft:black_concrete
setblock 166 260 181 minecraft:sea_lantern
fill 177 260 223 177 307 223 minecraft:black_concrete
fill 179 260 193 179 268 193 minecraft:polished_blackstone
fill 141 261 184 141 307 184 minecraft:black_concrete
fill 141 261 189 141 263 189 minecraft:cyan_concrete
fill 141 261 205 141 263 205 minecraft:cyan_concrete
fill 141 261 216 141 265 216 minecraft:black_concrete
fill 141 261 221 141 263 221 minecraft:cyan_concrete
setblock 144 261 223 minecraft:sea_lantern
fill 145 261 181 145 263 181 minecraft:cyan_concrete
fill 155 261 223 155 263 223 minecraft:cyan_concrete
fill 161 261 181 161 263 181 minecraft:cyan_concrete
fill 166 261 181 166 307 181 minecraft:black_concrete
setblock 169 261 181 minecraft:sea_lantern
fill 171 261 223 171 263 223 minecraft:cyan_concrete
fill 176 261 181 176 272 181 minecraft:black_concrete
fill 177 261 181 177 263 181 minecraft:cyan_concrete
setblock 182 261 181 minecraft:sea_lantern
fill 183 261 191 183 263 191 minecraft:cyan_concrete
fill 183 261 207 183 263 207 minecraft:cyan_concrete
fill 183 261 208 183 307 208 minecraft:black_concrete
setblock 183 261 209 minecraft:sea_lantern
fill 144 262 223 144 307 223 minecraft:black_concrete
setblock 146 262 181 minecraft:sea_lantern
fill 169 262 181 169 307 181 minecraft:black_concrete
setblock 179 262 181 minecraft:sea_lantern
fill 182 262 181 182 303 181 minecraft:black_concrete
fill 183 262 209 183 307 209 minecraft:black_concrete
setblock 141 263 182 minecraft:sea_lantern
setblock 141 263 188 minecraft:white_concrete
setblock 141 263 203 minecraft:white_concrete
fill 146 263 181 146 290 181 minecraft:black_concrete
fill 146 263 214 146 271 214 minecraft:sculk
setblock 148 263 181 minecraft:sea_lantern
setblock 151 263 181 minecraft:sea_lantern
fill 179 263 181 179 307 181 minecraft:black_concrete
setblock 183 263 202 minecraft:sea_lantern
fill 141 264 182 141 298 182 minecraft:black_concrete
fill 141 264 188 141 269 189 minecraft:black_concrete
setblock 141 264 199 minecraft:white_concrete
fill 141 264 203 141 291 203 minecraft:black_concrete
fill 141 264 205 141 268 205 minecraft:black_concrete
fill 141 264 221 141 269 221 minecraft:black_concrete
fill 145 264 181 145 269 181 minecraft:black_concrete
fill 148 264 181 148 267 181 minecraft:black_concrete
fill 151 264 181 151 285 181 minecraft:black_concrete
fill 155 264 223 155 266 223 minecraft:black_concrete
fill 161 264 181 161 269 181 minecraft:black_concrete
fill 171 264 223 171 269 223 minecraft:black_concrete
setblock 172 264 223 minecraft:sea_lantern
fill 177 264 181 177 269 181 minecraft:black_concrete
fill 183 264 191 183 269 191 minecraft:black_concrete
fill 183 264 202 183 307 202 minecraft:black_concrete
fill 183 264 207 183 269 207 minecraft:black_concrete
fill 141 265 199 141 281 199 minecraft:black_concrete
setblock 141 265 214 minecraft:sea_lantern
setblock 144 265 184 minecraft:light[level=10]
setblock 144 265 192 minecraft:light[level=10]
setblock 144 265 200 minecraft:light[level=10]
setblock 144 265 208 minecraft:light[level=10]
setblock 144 265 216 minecraft:light[level=10]
setblock 152 265 184 minecraft:light[level=10]
setblock 152 265 192 minecraft:light[level=10]
setblock 152 265 200 minecraft:light[level=10]
setblock 152 265 208 minecraft:light[level=10]
setblock 152 265 216 minecraft:light[level=10]
setblock 160 265 184 minecraft:light[level=10]
setblock 160 265 192 minecraft:light[level=10]
setblock 160 265 200 minecraft:light[level=10]
setblock 160 265 208 minecraft:light[level=10]
setblock 160 265 216 minecraft:light[level=10]
setblock 168 265 184 minecraft:light[level=10]
setblock 168 265 192 minecraft:light[level=10]
setblock 168 265 200 minecraft:light[level=10]
setblock 168 265 208 minecraft:light[level=10]
setblock 168 265 216 minecraft:light[level=10]
fill 172 265 223 172 307 223 minecraft:black_concrete
setblock 176 265 184 minecraft:light[level=10]
setblock 176 265 192 minecraft:light[level=10]
setblock 176 265 200 minecraft:light[level=10]
setblock 176 265 208 minecraft:light[level=10]
setblock 176 265 216 minecraft:light[level=10]
fill 178 265 193 178 268 193 minecraft:polished_blackstone
fill 179 265 192 179 268 192 minecraft:polished_blackstone
fill 179 265 194 179 268 194 minecraft:polished_blackstone
fill 180 265 193 180 268 193 minecraft:polished_blackstone
setblock 183 265 192 minecraft:sea_lantern
setblock 183 265 199 minecraft:sea_lantern
fill 141 266 214 141 305 214 minecraft:black_concrete
setblock 141 266 216 minecraft:sea_lantern
fill 183 266 192 183 286 192 minecraft:black_concrete
fill 183 266 199 183 301 199 minecraft:black_concrete
fill 141 267 216 141 296 216 minecraft:black_concrete
setblock 155 267 223 minecraft:sea_lantern
fill 164 267 223 164 289 223 minecraft:black_concrete
setblock 165 267 223 minecraft:sea_lantern
fill 178 267 192 178 268 192 minecraft:polished_blackstone
fill 178 267 194 178 268 194 minecraft:polished_blackstone
fill 180 267 192 180 268 192 minecraft:polished_blackstone
fill 180 267 194 180 268 194 minecraft:polished_blackstone
setblock 183 267 189 minecraft:sea_lantern
setblock 141 268 211 minecraft:sea_lantern
fill 141 268 212 141 279 213 minecraft:black_concrete
setblock 148 268 181 minecraft:white_concrete
fill 155 268 223 155 269 223 minecraft:black_concrete
fill 165 268 223 165 307 223 minecraft:black_concrete
fill 183 268 189 183 307 189 minecraft:black_concrete
setblock 141 269 205 minecraft:sea_lantern
fill 141 269 211 141 293 211 minecraft:black_concrete
fill 148 269 181 148 281 181 minecraft:black_concrete
setblock 169 269 223 minecraft:sea_lantern
setblock 183 269 183 minecraft:white_concrete
fill 141 270 188 141 302 188 minecraft:black_concrete
fill 141 270 189 141 272 189 minecraft:cyan_concrete
fill 141 270 205 141 272 205 minecraft:cyan_concrete
fill 141 270 221 141 272 221 minecraft:cyan_concrete
fill 145 270 181 145 272 181 minecraft:cyan_concrete
setblock 147 270 181 minecraft:sea_lantern
fill 155 270 223 155 272 223 minecraft:cyan_concrete
fill 161 270 181 161 272 181 minecraft:cyan_concrete
setblock 163 270 223 minecraft:sea_lantern
fill 169 270 223 169 292 223 minecraft:black_concrete
fill 171 270 223 171 272 223 minecraft:cyan_concrete
fill 177 270 181 177 272 181 minecraft:cyan_concrete
fill 183 270 183 183 307 183 minecraft:black_concrete
setblock 183 270 186 minecraft:sea_lantern
fill 183 270 191 183 272 191 minecraft:cyan_concrete
fill 183 270 207 183 272 207 minecraft:cyan_concrete
setblock 141 271 183 minecraft:sea_lantern
fill 147 271 181 147 292 181 minecraft:black_concrete
setblock 153 271 223 minecraft:sea_lantern
fill 163 271 223 163 307 223 minecraft:black_concrete
fill 183 271 186 183 286 186 minecraft:black_concrete
setblock 183 271 190 minecraft:sea_lantern
fill 141 272 183 141 307 183 minecraft:black_concrete
setblock 149 272 223 minecraft:white_concrete
fill 153 272 223 153 299 223 minecraft:black_concrete
fill 183 272 190 183 307 190 minecraft:black_concrete
setblock 183 272 203 minecraft:white_concrete
setblock 183 272 204 minecraft:sea_lantern
setblock 183 272 215 minecraft:sea_lantern
fill 141 273 189 141 287 189 minecraft:black_concrete
fill 141 273 205 141 287 205 minecraft:black_concrete
fill 141 273 221 141 287 221 minecraft:black_concrete
setblock 144 273 184 minecraft:light[level=10]
setblock 144 273 192 minecraft:light[level=10]
setblock 144 273 200 minecraft:light[level=10]
setblock 144 273 208 minecraft:light[level=10]
setblock 144 273 216 minecraft:light[level=10]
fill 145 273 181 145 286 181 minecraft:black_concrete
fill 149 273 223 149 307 223 minecraft:black_concrete
setblock 152 273 184 minecraft:light[level=10]
setblock 152 273 192 minecraft:light[level=10]
setblock 152 273 200 minecraft:light[level=10]
setblock 152 273 208 minecraft:light[level=10]
setblock 152 273 216 minecraft:light[level=10]
fill 155 273 223 155 287 223 minecraft:black_concrete
setblock 160 273 184 minecraft:light[level=10]
setblock 160 273 192 minecraft:light[level=10]
setblock 160 273 200 minecraft:light[level=10]
setblock 160 273 208 minecraft:light[level=10]
setblock 160 273 216 minecraft:light[level=10]
fill 161 273 181 161 287 181 minecraft:black_concrete
setblock 168 273 184 minecraft:light[level=10]
setblock 168 273 192 minecraft:light[level=10]
setblock 168 273 200 minecraft:light[level=10]
setblock 168 273 208 minecraft:light[level=10]
setblock 168 273 216 minecraft:light[level=10]
fill 171 273 223 171 287 223 minecraft:black_concrete
setblock 176 273 181 minecraft:sea_lantern
setblock 176 273 184 minecraft:light[level=10]
setblock 176 273 192 minecraft:light[level=10]
setblock 176 273 200 minecraft:light[level=10]
setblock 176 273 208 minecraft:light[level=10]
setblock 176 273 216 minecraft:light[level=10]
fill 177 273 181 177 287 181 minecraft:black_concrete
fill 183 273 191 183 287 191 minecraft:black_concrete
fill 183 273 203 183 307 204 minecraft:black_concrete
fill 183 273 207 183 287 207 minecraft:black_concrete
fill 183 273 215 183 307 215 minecraft:black_concrete
setblock 141 274 220 minecraft:sea_lantern
setblock 164 274 181 minecraft:sea_lantern
fill 176 274 181 176 307 181 minecraft:black_concrete
fill 141 275 220 141 282 220 minecraft:black_concrete
fill 164 275 181 164 287 181 minecraft:black_concrete
setblock 141 276 198 minecraft:sea_lantern
setblock 141 277 186 minecraft:white_concrete
fill 141 277 198 141 294 198 minecraft:black_concrete
fill 141 278 186 141 300 186 minecraft:black_concrete
setblock 141 278 192 minecraft:sea_lantern
fill 152 278 201 154 279 201 minecraft:sculk
fill 153 278 196 154 279 200 minecraft:sculk
fill 153 278 202 153 279 206 minecraft:sculk
fill 154 278 195 167 279 195 minecraft:sculk
fill 154 278 202 157 279 207 minecraft:black_concrete
fill 155 278 193 166 279 194 minecraft:sculk
fill 155 278 196 155 279 199 minecraft:sculk
fill 155 278 200 158 279 201 minecraft:black_concrete
fill 155 278 208 157 279 209 minecraft:black_concrete
fill 156 278 192 165 279 192 minecraft:sculk
fill 156 278 196 156 279 198 minecraft:sculk
fill 156 278 199 162 278 199 minecraft:black_concrete
fill 156 278 210 158 279 210 minecraft:black_concrete
fill 157 278 191 163 279 191 minecraft:sculk
fill 157 278 196 158 279 197 minecraft:sculk
fill 157 278 198 163 278 198 minecraft:black_concrete
fill 157 278 211 158 279 211 minecraft:black_concrete
fill 158 278 202 161 278 209 minecraft:sculk
fill 159 278 190 169 279 190 minecraft:black_concrete
fill 159 278 196 168 279 196 minecraft:sculk
fill 159 278 197 163 279 197 minecraft:black_concrete
fill 159 278 200 159 279 200 minecraft:black_concrete
fill 159 278 201 161 278 201 minecraft:sculk
fill 159 278 210 167 279 211 minecraft:sculk
fill 159 278 212 159 279 212 minecraft:black_concrete
fill 160 278 189 167 279 189 minecraft:black_concrete
fill 160 278 200 161 278 200 minecraft:sculk
fill 160 278 212 171 279 212 minecraft:sculk
fill 160 278 213 160 279 213 minecraft:black_concrete
fill 161 278 213 170 279 213 minecraft:sculk
fill 162 278 200 162 279 200 minecraft:sea_lantern
fill 162 278 202 162 279 202 minecraft:sea_lantern
fill 162 278 203 162 278 209 minecraft:sculk
fill 163 278 204 163 278 206 minecraft:black_concrete
fill 163 278 207 163 279 209 minecraft:sculk
fill 164 278 191 169 279 191 minecraft:black_concrete
fill 164 278 197 168 278 197 minecraft:sculk
fill 164 278 198 164 279 198 minecraft:sea_lantern
fill 164 278 204 164 279 204 minecraft:sea_lantern
fill 164 278 205 165 278 208 minecraft:black_concrete
fill 164 278 209 165 279 209 minecraft:sculk
fill 165 278 188 165 279 188 minecraft:black_concrete
fill 165 278 214 165 279 214 minecraft:sculk
fill 166 278 192 170 279 192 minecraft:black_concrete
fill 166 278 198 166 279 198 minecraft:sea_lantern
fill 166 278 204 166 279 204 minecraft:sea_lantern
fill 166 278 205 173 278 205 minecraft:sculk
fill 166 278 206 166 279 209 minecraft:black_concrete
fill 167 278 193 171 279 193 minecraft:black_concrete
fill 167 278 194 167 279 194 minecraft:sculk
fill 167 278 198 168 278 198 minecraft:sculk
fill 167 278 204 175 278 204 minecraft:sculk
fill 167 278 206 172 279 206 minecraft:sculk
fill 167 278 207 174 279 209 minecraft:black_concrete
fill 168 278 189 170 279 189 minecraft:sculk
fill 168 278 194 171 279 195 minecraft:black_concrete
setblock 168 278 199 minecraft:sculk
fill 168 278 200 168 279 200 minecraft:sea_lantern
fill 168 278 202 168 279 202 minecraft:sea_lantern
fill 168 278 203 175 278 203 minecraft:sculk
fill 168 278 210 172 279 210 minecraft:black_concrete
fill 168 278 211 173 279 211 minecraft:sculk
fill 169 278 196 170 278 201 minecraft:black_concrete
fill 169 278 202 176 278 202 minecraft:sculk
fill 170 278 190 171 279 191 minecraft:sculk
fill 171 278 192 174 279 192 minecraft:sculk
fill 171 278 196 171 279 199 minecraft:black_concrete
fill 171 278 200 177 279 201 minecraft:sculk
fill 172 278 191 173 279 191 minecraft:sculk
fill 172 278 193 175 279 199 minecraft:sculk
fill 173 278 206 177 279 206 minecraft:black_concrete
fill 173 278 210 174 279 210 minecraft:sculk
fill 174 278 205 177 279 205 minecraft:black_concrete
fill 175 278 207 175 279 208 minecraft:black_concrete
fill 175 278 209 175 279 209 minecraft:sculk
fill 176 278 195 176 279 199 minecraft:sculk
fill 176 278 203 177 279 204 minecraft:black_concrete
fill 176 278 207 176 279 207 minecraft:black_concrete
fill 177 278 196 177 279 199 minecraft:sculk
fill 177 278 202 177 279 202 minecraft:black_concrete
fill 178 278 201 178 279 201 minecraft:black_concrete
fill 141 279 192 155 279 192 minecraft:black_concrete
fill 142 279 182 156 279 191 minecraft:black_concrete
fill 142 279 193 151 279 222 minecraft:black_concrete
fill 152 279 193 152 279 200 minecraft:black_concrete
fill 152 279 202 152 279 222 minecraft:black_concrete
fill 153 279 193 153 279 195 minecraft:black_concrete
fill 153 279 207 153 279 222 minecraft:black_concrete
fill 154 279 193 154 279 194 minecraft:black_concrete
fill 154 279 208 154 279 222 minecraft:black_concrete
fill 155 279 210 155 279 222 minecraft:black_concrete
fill 156 279 199 161 279 199 minecraft:black_concrete
fill 156 279 211 156 279 222 minecraft:black_concrete
fill 157 279 182 158 279 190 minecraft:black_concrete
fill 157 279 198 161 279 198 minecraft:black_concrete
fill 157 279 212 158 279 222 minecraft:black_concrete
fill 158 279 202 160 279 209 minecraft:sculk
fill 159 279 182 159 279 189 minecraft:black_concrete
fill 159 279 201 160 279 201 minecraft:sculk
fill 159 279 213 159 279 222 minecraft:black_concrete
fill 160 279 182 164 279 188 minecraft:black_concrete
setblock 160 279 200 minecraft:sculk
fill 160 279 214 164 279 222 minecraft:black_concrete
fill 161 279 200 161 279 202 minecraft:sea_lantern
fill 161 279 203 161 279 209 minecraft:sculk
fill 162 279 198 162 279 199 minecraft:sea_lantern
fill 162 279 203 162 279 204 minecraft:sea_lantern
fill 162 279 205 162 279 209 minecraft:sculk
setblock 163 279 198 minecraft:sea_lantern
setblock 163 279 204 minecraft:sea_lantern
fill 163 279 205 163 279 206 minecraft:black_concrete
fill 164 279 197 166 279 197 minecraft:sea_lantern
fill 164 279 205 166 279 205 minecraft:sea_lantern
fill 164 279 206 165 279 208 minecraft:black_concrete
fill 165 279 182 182 279 187 minecraft:black_concrete
fill 165 279 215 182 279 222 minecraft:black_concrete
fill 166 279 188 182 279 188 minecraft:black_concrete
fill 166 279 214 182 279 214 minecraft:black_concrete
fill 167 279 197 168 279 197 minecraft:sculk
fill 167 279 198 168 279 198 minecraft:sea_lantern
fill 167 279 204 168 279 204 minecraft:sea_lantern
fill 167 279 205 173 279 205 minecraft:sculk
setblock 168 279 199 minecraft:sea_lantern
setblock 168 279 203 minecraft:sea_lantern
fill 169 279 196 170 279 199 minecraft:black_concrete
fill 169 279 200 169 279 202 minecraft:sea_lantern
fill 169 279 203 175 279 204 minecraft:sculk
fill 170 279 200 170 279 201 minecraft:black_concrete
fill 170 279 202 176 279 202 minecraft:sculk
fill 171 279 189 182 279 189 minecraft:black_concrete
fill 171 279 213 182 279 213 minecraft:black_concrete
fill 172 279 190 182 279 190 minecraft:black_concrete
fill 172 279 212 182 279 212 minecraft:black_concrete
fill 174 279 191 182 279 191 minecraft:black_concrete
fill 174 279 211 182 279 211 minecraft:black_concrete
fill 175 279 192 182 279 192 minecraft:black_concrete
fill 175 279 210 182 279 210 minecraft:black_concrete
fill 176 279 193 182 279 194 minecraft:black_concrete
fill 176 279 208 182 279 209 minecraft:black_concrete
fill 177 279 195 182 279 195 minecraft:black_concrete
fill 177 279 207 182 279 207 minecraft:black_concrete
fill 178 279 196 182 279 200 minecraft:black_concrete
fill 178 279 202 182 279 206 minecraft:black_concrete
fill 179 279 201 182 279 201 minecraft:black_concrete
fill 141 280 192 141 281 192 minecraft:black_concrete
setblock 141 280 212 minecraft:sea_lantern
fill 141 280 213 141 293 213 minecraft:black_concrete
fill 141 281 212 141 299 212 minecraft:black_concrete
setblock 144 281 184 minecraft:light[level=10]
setblock 144 281 192 minecraft:light[level=10]
setblock 144 281 200 minecraft:light[level=10]
setblock 144 281 208 minecraft:light[level=10]
setblock 144 281 216 minecraft:light[level=10]
setblock 152 281 184 minecraft:light[level=10]
setblock 152 281 192 minecraft:light[level=10]
setblock 152 281 200 minecraft:light[level=10]
setblock 152 281 208 minecraft:light[level=10]
setblock 152 281 216 minecraft:light[level=10]
setblock 160 281 184 minecraft:light[level=10]
setblock 160 281 192 minecraft:light[level=10]
setblock 160 281 200 minecraft:light[level=10]
setblock 160 281 208 minecraft:light[level=10]
setblock 160 281 216 minecraft:light[level=10]
setblock 168 281 184 minecraft:light[level=10]
setblock 168 281 192 minecraft:light[level=10]
setblock 168 281 200 minecraft:light[level=10]
setblock 168 281 208 minecraft:light[level=10]
setblock 168 281 216 minecraft:light[level=10]
setblock 176 281 184 minecraft:light[level=10]
setblock 176 281 192 minecraft:light[level=10]
setblock 176 281 200 minecraft:light[level=10]
setblock 176 281 208 minecraft:light[level=10]
setblock 176 281 216 minecraft:light[level=10]
setblock 141 282 192 minecraft:sea_lantern
setblock 141 282 199 minecraft:white_concrete
setblock 148 282 181 minecraft:sea_lantern
fill 141 283 192 141 307 192 minecraft:black_concrete
fill 141 283 199 141 295 199 minecraft:black_concrete
setblock 141 283 220 minecraft:sea_lantern
fill 148 283 181 148 307 181 minecraft:black_concrete
setblock 162 283 223 minecraft:sea_lantern
fill 141 284 220 141 307 220 minecraft:black_concrete
setblock 152 284 181 minecraft:sea_lantern
fill 162 284 223 162 285 223 minecraft:black_concrete
setblock 183 284 193 minecraft:sea_lantern
fill 152 285 181 152 307 181 minecraft:black_concrete
fill 183 285 193 183 307 193 minecraft:black_concrete
setblock 141 286 204 minecraft:sea_lantern
setblock 151 286 181 minecraft:sea_lantern
setblock 162 286 223 minecraft:white_concrete
setblock 183 286 201 minecraft:sea_lantern
fill 141 287 204 141 307 204 minecraft:black_concrete
setblock 145 287 181 minecraft:sea_lantern
setblock 150 287 223 minecraft:sea_lantern
fill 151 287 181 151 307 181 minecraft:black_concrete
setblock 162 287 181 minecraft:sea_lantern
fill 162 287 223 162 307 223 minecraft:black_concrete
setblock 183 287 186 minecraft:sea_lantern
setblock 183 287 192 minecraft:white_concrete
fill 183 287 201 183 307 201 minecraft:black_concrete
fill 141 288 189 141 290 189 minecraft:cyan_concrete
fill 141 288 205 141 290 205 minecraft:cyan_concrete
fill 141 288 221 141 290 221 minecraft:cyan_concrete
setblock 141 288 222 minecraft:sea_lantern
fill 145 288 181 145 290 181 minecraft:cyan_concrete
fill 150 288 223 150 307 223 minecraft:black_concrete
fill 155 288 223 155 290 223 minecraft:cyan_concrete
fill 161 288 181 161 290 181 minecraft:cyan_concrete
fill 162 288 181 162 307 181 minecraft:black_concrete
setblock 164 288 181 minecraft:sea_lantern
fill 171 288 223 171 290 223 minecraft:cyan_concrete
fill 177 288 181 177 290 181 minecraft:cyan_concrete
fill 183 288 186 183 307 186 minecraft:black_concrete
fill 183 288 191 183 290 191 minecraft:cyan_concrete
fill 183 288 192 183 307 192 minecraft:black_concrete
fill 183 288 207 183 290 207 minecraft:cyan_concrete
fill 141 289 222 141 307 222 minecraft:black_concrete
setblock 144 289 184 minecraft:light[level=10]
setblock 144 289 192 minecraft:light[level=10]
setblock 144 289 200 minecraft:light[level=10]
setblock 144 289 208 minecraft:light[level=10]
setblock 144 289 216 minecraft:light[level=10]
setblock 152 289 184 minecraft:light[level=10]
setblock 152 289 192 minecraft:light[level=10]
setblock 152 289 200 minecraft:light[level=10]
setblock 152 289 208 minecraft:light[level=10]
setblock 152 289 216 minecraft:light[level=10]
setblock 160 289 184 minecraft:light[level=10]
setblock 160 289 192 minecraft:light[level=10]
setblock 160 289 200 minecraft:light[level=10]
setblock 160 289 208 minecraft:light[level=10]
setblock 160 289 216 minecraft:light[level=10]
setblock 164 289 181 minecraft:black_concrete
setblock 168 289 184 minecraft:light[level=10]
setblock 168 289 192 minecraft:light[level=10]
setblock 168 289 200 minecraft:light[level=10]
setblock 168 289 208 minecraft:light[level=10]
setblock 168 289 216 minecraft:light[level=10]
setblock 176 289 184 minecraft:light[level=10]
setblock 176 289 192 minecraft:light[level=10]
setblock 176 289 200 minecraft:light[level=10]
setblock 176 289 208 minecraft:light[level=10]
setblock 176 289 216 minecraft:light[level=10]
setblock 164 290 181 minecraft:sea_lantern
setblock 164 290 223 minecraft:sea_lantern
setblock 183 290 196 minecraft:white_concrete
setblock 183 290 217 minecraft:sea_lantern
fill 141 291 189 141 296 189 minecraft:black_concrete
fill 141 291 205 141 296 205 minecraft:black_concrete
fill 141 291 221 141 296 221 minecraft:black_concrete
fill 145 291 181 145 296 181 minecraft:black_concrete
setblock 146 291 181 minecraft:white_concrete
fill 155 291 223 155 296 223 minecraft:black_concrete
setblock 160 291 223 minecraft:white_concrete
fill 161 291 181 161 296 181 minecraft:black_concrete
fill 164 291 181 164 307 181 minecraft:black_concrete
fill 164 291 223 164 307 223 minecraft:black_concrete
fill 171 291 223 171 296 223 minecraft:black_concrete
fill 177 291 181 177 296 181 minecraft:black_concrete
fill 183 291 191 183 296 191 minecraft:black_concrete
fill 183 291 196 183 296 196 minecraft:black_concrete
fill 183 291 207 183 294 207 minecraft:black_concrete
fill 183 291 217 183 307 217 minecraft:black_concrete
setblock 141 292 203 minecraft:white_concrete
fill 146 292 181 146 307 181 minecraft:black_concrete
setblock 148 292 223 minecraft:white_concrete
fill 160 292 223 160 295 223 minecraft:black_concrete
setblock 167 292 181 minecraft:sea_lantern
setblock 181 292 181 minecraft:white_concrete
fill 141 293 203 141 307 203 minecraft:black_concrete
setblock 147 293 181 minecraft:sea_lantern
fill 148 293 223 148 307 223 minecraft:black_concrete
fill 167 293 181 167 307 181 minecraft:black_concrete
setblock 169 293 223 minecraft:sea_lantern
fill 181 293 181 181 307 181 minecraft:black_concrete
setblock 183 293 214 minecraft:sea_lantern
setblock 141 294 211 minecraft:sea_lantern
setblock 141 294 213 minecraft:sea_lantern
fill 147 294 181 147 307 181 minecraft:black_concrete
fill 169 294 223 169 307 223 minecraft:black_concrete
fill 183 294 214 183 307 214 minecraft:black_concrete
setblock 141 295 198 minecraft:sea_lantern
fill 141 295 211 141 307 211 minecraft:black_concrete
fill 141 295 213 141 307 213 minecraft:black_concrete
setblock 183 295 207 minecraft:white_concrete
fill 141 296 198 141 307 198 minecraft:black_concrete
setblock 141 296 199 minecraft:white_concrete
setblock 160 296 223 minecraft:sea_lantern
setblock 183 296 207 minecraft:black_concrete
fill 141 297 189 141 299 189 minecraft:cyan_concrete
fill 141 297 199 141 305 199 minecraft:black_concrete
fill 141 297 205 141 299 205 minecraft:cyan_concrete
setblock 141 297 216 minecraft:white_concrete
fill 141 297 221 141 299 221 minecraft:cyan_concrete
setblock 142 297 223 minecraft:white_concrete
setblock 144 297 184 minecraft:light[level=10]
setblock 144 297 192 minecraft:light[level=10]
setblock 144 297 200 minecraft:light[level=10]
setblock 144 297 208 minecraft:light[level=10]
setblock 144 297 216 minecraft:light[level=10]
fill 145 297 181 145 299 181 minecraft:cyan_concrete
setblock 146 297 223 minecraft:white_concrete
setblock 152 297 184 minecraft:light[level=10]
setblock 152 297 192 minecraft:light[level=10]
setblock 152 297 200 minecraft:light[level=10]
setblock 152 297 208 minecraft:light[level=10]
setblock 152 297 216 minecraft:light[level=10]
fill 155 297 223 155 299 223 minecraft:cyan_concrete
setblock 160 297 184 minecraft:light[level=10]
setblock 160 297 192 minecraft:light[level=10]
setblock 160 297 200 minecraft:light[level=10]
setblock 160 297 208 minecraft:light[level=10]
setblock 160 297 216 minecraft:light[level=10]
fill 160 297 223 160 307 223 minecraft:black_concrete
fill 161 297 181 161 299 181 minecraft:cyan_concrete
setblock 168 297 184 minecraft:light[level=10]
setblock 168 297 192 minecraft:light[level=10]
setblock 168 297 200 minecraft:light[level=10]
setblock 168 297 208 minecraft:light[level=10]
setblock 168 297 216 minecraft:light[level=10]
fill 171 297 223 171 299 223 minecraft:cyan_concrete
setblock 173 297 223 minecraft:sea_lantern
setblock 176 297 184 minecraft:light[level=10]
setblock 176 297 192 minecraft:light[level=10]
setblock 176 297 200 minecraft:light[level=10]
setblock 176 297 208 minecraft:light[level=10]
setblock 176 297 216 minecraft:light[level=10]
fill 177 297 181 177 299 181 minecraft:cyan_concrete
fill 183 297 191 183 299 191 minecraft:cyan_concrete
setblock 183 297 196 minecraft:sea_lantern
fill 183 297 207 183 299 207 minecraft:cyan_concrete
fill 141 298 216 141 307 216 minecraft:black_concrete
fill 142 298 223 142 307 223 minecraft:black_concrete
fill 146 298 223 146 307 223 minecraft:black_concrete
setblock 154 298 223 minecraft:white_concrete
fill 173 298 223 173 307 223 minecraft:black_concrete
fill 183 298 196 183 307 196 minecraft:black_concrete
setblock 141 299 182 minecraft:sea_lantern
fill 154 299 223 154 307 223 minecraft:black_concrete
fill 141 300 182 141 307 182 minecraft:black_concrete
fill 141 300 189 141 307 189 minecraft:black_concrete
fill 141 300 205 141 307 205 minecraft:black_concrete
setblock 141 300 212 minecraft:sea_lantern
fill 141 300 221 141 307 221 minecraft:black_concrete
fill 145 300 181 145 307 181 minecraft:black_concrete
setblock 153 300 223 minecraft:sea_lantern
fill 155 300 223 155 307 223 minecraft:black_concrete
fill 161 300 181 161 301 181 minecraft:black_concrete
setblock 161 300 223 minecraft:sea_lantern
fill 171 300 223 171 307 223 minecraft:black_concrete
fill 177 300 181 177 306 181 minecraft:black_concrete
fill 183 300 191 183 307 191 minecraft:black_concrete
fill 183 300 207 183 302 207 minecraft:black_concrete
setblock 141 301 186 minecraft:sea_lantern
fill 141 301 212 141 307 212 minecraft:black_concrete
fill 153 301 223 153 307 223 minecraft:black_concrete
fill 161 301 223 161 307 223 minecraft:black_concrete
fill 141 302 186 141 307 186 minecraft:black_concrete
setblock 141 302 202 minecraft:white_concrete
setblock 161 302 181 minecraft:white_concrete
setblock 183 302 199 minecraft:white_concrete
setblock 141 303 188 minecraft:sea_lantern
fill 141 303 202 141 307 202 minecraft:black_concrete
setblock 141 303 219 minecraft:sea_lantern
setblock 147 303 223 minecraft:white_concrete
fill 161 303 181 161 307 181 minecraft:black_concrete
fill 183 303 199 183 307 199 minecraft:black_concrete
setblock 183 303 207 minecraft:sea_lantern
fill 141 304 188 141 307 188 minecraft:black_concrete
fill 141 304 219 141 307 219 minecraft:black_concrete
fill 147 304 223 147 307 223 minecraft:black_concrete
setblock 182 304 181 minecraft:white_concrete
setblock 183 304 185 minecraft:sea_lantern
fill 183 304 207 183 307 207 minecraft:black_concrete
fill 182 305 181 182 307 181 minecraft:black_concrete
fill 183 305 185 183 307 185 minecraft:black_concrete
setblock 183 305 210 minecraft:sea_lantern
setblock 141 306 199 minecraft:sea_lantern
setblock 141 306 214 minecraft:sea_lantern
setblock 182 306 223 minecraft:sea_lantern
fill 183 306 210 183 307 210 minecraft:black_concrete
setblock 183 306 212 minecraft:sea_lantern
setblock 141 307 199 minecraft:black_concrete
setblock 141 307 214 minecraft:black_concrete
setblock 177 307 181 minecraft:sea_lantern
setblock 182 307 223 minecraft:black_concrete
setblock 183 307 200 minecraft:sea_lantern
setblock 183 307 212 minecraft:black_concrete
setblock 183 307 213 minecraft:sea_lantern
