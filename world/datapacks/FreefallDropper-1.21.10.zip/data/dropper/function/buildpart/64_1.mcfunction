fill 217 53 314 217 54 314 minecraft:prismarine_bricks
fill 217 53 316 217 54 316 minecraft:prismarine_bricks
fill 218 53 307 218 54 307 minecraft:prismarine_bricks
fill 218 53 309 218 54 309 minecraft:prismarine_bricks
fill 218 53 311 218 54 311 minecraft:prismarine_bricks
fill 218 53 313 218 54 313 minecraft:prismarine_bricks
fill 218 53 315 218 54 315 minecraft:prismarine_bricks
fill 219 53 306 219 54 306 minecraft:prismarine_bricks
fill 219 53 308 219 54 308 minecraft:prismarine_bricks
fill 219 53 310 219 54 310 minecraft:prismarine_bricks
fill 219 53 312 219 54 312 minecraft:prismarine_bricks
fill 219 53 314 219 54 314 minecraft:prismarine_bricks
fill 219 53 316 219 54 316 minecraft:prismarine_bricks
fill 220 53 275 221 65 275 minecraft:dark_prismarine
fill 220 53 307 220 54 307 minecraft:prismarine_bricks
fill 220 53 309 220 54 309 minecraft:prismarine_bricks
fill 220 53 311 220 54 311 minecraft:prismarine_bricks
fill 220 53 313 220 54 313 minecraft:prismarine_bricks
fill 220 53 315 220 54 315 minecraft:prismarine_bricks
fill 221 53 306 221 54 306 minecraft:prismarine_bricks
fill 221 53 308 221 54 308 minecraft:prismarine_bricks
fill 221 53 310 221 54 310 minecraft:prismarine_bricks
fill 221 53 312 221 54 312 minecraft:prismarine_bricks
fill 221 53 314 221 54 314 minecraft:prismarine_bricks
fill 221 53 316 221 54 316 minecraft:prismarine_bricks
fill 222 53 307 222 54 307 minecraft:prismarine_bricks
fill 222 53 309 222 54 309 minecraft:prismarine_bricks
fill 222 53 311 222 54 311 minecraft:prismarine_bricks
fill 222 53 313 222 54 313 minecraft:prismarine_bricks
fill 222 53 315 222 54 315 minecraft:prismarine_bricks
fill 223 53 288 223 54 288 minecraft:sea_lantern
fill 223 53 306 223 54 306 minecraft:prismarine_bricks
fill 223 53 308 223 54 308 minecraft:prismarine_bricks
fill 223 53 310 223 54 310 minecraft:prismarine_bricks
fill 223 53 312 223 54 312 minecraft:prismarine_bricks
fill 223 53 314 223 54 314 minecraft:prismarine_bricks
fill 223 53 316 223 54 316 minecraft:prismarine_bricks
fill 224 53 307 224 54 307 minecraft:prismarine_bricks
fill 224 53 309 224 54 309 minecraft:prismarine_bricks
fill 224 53 311 224 54 311 minecraft:prismarine_bricks
fill 224 53 313 224 54 313 minecraft:prismarine_bricks
fill 224 53 315 224 54 315 minecraft:prismarine_bricks
fill 225 53 278 227 80 280 minecraft:quartz_pillar
fill 225 53 291 225 53 297 minecraft:gold_block
fill 225 53 306 225 54 306 minecraft:prismarine_bricks
fill 225 53 308 225 54 308 minecraft:prismarine_bricks
fill 225 53 310 225 54 310 minecraft:prismarine_bricks
fill 225 53 312 227 54 314 minecraft:quartz_pillar
fill 225 53 316 225 54 316 minecraft:prismarine_bricks
fill 225 53 317 226 64 317 minecraft:dark_prismarine
fill 226 53 291 228 53 294 minecraft:gold_block
fill 226 53 295 228 80 297 minecraft:quartz_pillar
fill 226 53 307 226 54 307 minecraft:prismarine_bricks
fill 226 53 309 226 54 309 minecraft:prismarine_bricks
fill 226 53 311 226 54 311 minecraft:prismarine_bricks
fill 226 53 315 226 54 315 minecraft:prismarine_bricks
fill 230 53 277 230 60 278 minecraft:dark_prismarine
fill 230 53 289 230 65 290 minecraft:dark_prismarine
fill 230 53 301 230 65 302 minecraft:dark_prismarine
fill 230 53 313 230 65 314 minecraft:dark_prismarine
fill 190 54 301 190 54 306 minecraft:prismarine_bricks
setblock 191 54 286 minecraft:light[level=15]
setblock 191 54 294 minecraft:light[level=15]
fill 191 54 299 196 54 305 minecraft:gold_block
fill 191 54 306 195 54 306 minecraft:prismarine_bricks
fill 193 54 297 193 55 297 minecraft:prismarine_bricks
fill 195 54 296 195 58 296 minecraft:prismarine_bricks
fill 195 54 298 195 56 298 minecraft:prismarine_bricks
fill 198 54 275 198 65 275 minecraft:dark_prismarine
setblock 199 54 278 minecraft:light[level=15]
setblock 199 54 286 minecraft:light[level=15]
setblock 199 54 294 minecraft:light[level=15]
setblock 199 54 302 minecraft:light[level=15]
setblock 207 54 278 minecraft:light[level=15]
setblock 207 54 286 minecraft:light[level=15]
setblock 207 54 294 minecraft:light[level=15]
setblock 207 54 302 minecraft:light[level=15]
setblock 207 54 310 minecraft:light[level=15]
setblock 211 54 275 minecraft:prismarine_bricks
fill 212 54 275 213 96 275 minecraft:dark_prismarine
setblock 215 54 278 minecraft:light[level=15]
setblock 215 54 286 minecraft:light[level=15]
setblock 215 54 294 minecraft:light[level=15]
setblock 215 54 302 minecraft:light[level=15]
setblock 223 54 278 minecraft:light[level=15]
setblock 223 54 286 minecraft:light[level=15]
setblock 223 54 294 minecraft:light[level=15]
setblock 223 54 302 minecraft:light[level=15]
fill 226 54 292 227 54 294 minecraft:gold_block
setblock 189 55 302 minecraft:sea_lantern
setblock 189 55 304 minecraft:sea_lantern
setblock 189 55 306 minecraft:sea_lantern
setblock 189 55 308 minecraft:sea_lantern
setblock 190 55 301 minecraft:sea_lantern
fill 190 55 302 190 67 302 minecraft:prismarine_bricks
setblock 190 55 303 minecraft:sea_lantern
fill 190 55 304 190 67 304 minecraft:prismarine_bricks
setblock 190 55 305 minecraft:sea_lantern
fill 190 55 306 190 67 306 minecraft:prismarine_bricks
setblock 190 55 307 minecraft:sea_lantern
fill 190 55 308 190 58 308 minecraft:gold_block
setblock 190 55 309 minecraft:sea_lantern
fill 190 55 310 191 55 311 minecraft:gold_block
fill 191 55 278 191 80 280 minecraft:quartz_pillar
fill 191 55 301 191 67 301 minecraft:prismarine_bricks
setblock 191 55 302 minecraft:sea_lantern
fill 191 55 303 191 67 303 minecraft:prismarine_bricks
setblock 191 55 304 minecraft:sea_lantern
fill 191 55 305 191 67 305 minecraft:prismarine_bricks
setblock 191 55 306 minecraft:sea_lantern
setblock 191 55 308 minecraft:sea_lantern
fill 191 55 309 191 57 309 minecraft:gold_block
fill 191 55 312 192 80 314 minecraft:quartz_pillar
setblock 192 55 277 minecraft:sea_lantern
fill 192 55 278 192 80 278 minecraft:quartz_pillar
setblock 192 55 279 minecraft:sea_lantern
fill 192 55 280 193 80 280 minecraft:quartz_pillar
fill 192 55 300 195 55 300 minecraft:gold_block
setblock 192 55 301 minecraft:sea_lantern
setblock 192 55 302 minecraft:gold_block
setblock 192 55 303 minecraft:sea_lantern
setblock 192 55 304 minecraft:gold_block
setblock 192 55 305 minecraft:sea_lantern
fill 192 55 306 192 67 306 minecraft:prismarine_bricks
setblock 192 55 307 minecraft:sea_lantern
setblock 192 55 309 minecraft:sea_lantern
setblock 193 55 276 minecraft:sea_lantern
setblock 193 55 278 minecraft:sea_lantern
fill 193 55 279 193 80 279 minecraft:quartz_pillar
fill 193 55 301 193 56 301 minecraft:gold_block
setblock 193 55 302 minecraft:sea_lantern
fill 193 55 303 193 56 303 minecraft:gold_block
setblock 193 55 304 minecraft:sea_lantern
fill 193 55 305 193 67 305 minecraft:prismarine_bricks
setblock 193 55 306 minecraft:sea_lantern
setblock 193 55 308 minecraft:sea_lantern
setblock 193 55 310 minecraft:sea_lantern
setblock 193 55 312 minecraft:sea_lantern
fill 193 55 313 193 80 313 minecraft:quartz_pillar
setblock 193 55 314 minecraft:sea_lantern
setblock 193 55 316 minecraft:sea_lantern
setblock 194 55 277 minecraft:sea_lantern
setblock 194 55 279 minecraft:sea_lantern
setblock 194 55 301 minecraft:sea_lantern
fill 194 55 302 194 56 302 minecraft:gold_block
setblock 194 55 303 minecraft:sea_lantern
setblock 194 55 304 minecraft:gold_block
setblock 194 55 305 minecraft:sea_lantern
fill 194 55 306 194 67 306 minecraft:prismarine_bricks
setblock 194 55 307 minecraft:sea_lantern
setblock 194 55 311 minecraft:sea_lantern
setblock 194 55 313 minecraft:sea_lantern
setblock 194 55 315 minecraft:sea_lantern
setblock 195 55 276 minecraft:sea_lantern
setblock 195 55 278 minecraft:sea_lantern
setblock 195 55 301 minecraft:gold_block
setblock 195 55 302 minecraft:sea_lantern
setblock 195 55 303 minecraft:gold_block
setblock 195 55 304 minecraft:sea_lantern
fill 195 55 305 195 67 305 minecraft:prismarine_bricks
setblock 195 55 306 minecraft:sea_lantern
setblock 195 55 310 minecraft:sea_lantern
setblock 195 55 312 minecraft:sea_lantern
setblock 195 55 314 minecraft:sea_lantern
setblock 195 55 316 minecraft:sea_lantern
setblock 196 55 277 minecraft:sea_lantern
setblock 196 55 279 minecraft:sea_lantern
setblock 196 55 311 minecraft:sea_lantern
setblock 196 55 313 minecraft:sea_lantern
setblock 196 55 315 minecraft:sea_lantern
setblock 197 55 276 minecraft:sea_lantern
setblock 197 55 278 minecraft:sea_lantern
setblock 197 55 310 minecraft:sea_lantern
setblock 197 55 312 minecraft:sea_lantern
setblock 197 55 314 minecraft:sea_lantern
setblock 197 55 316 minecraft:sea_lantern
setblock 198 55 277 minecraft:sea_lantern
setblock 198 55 279 minecraft:sea_lantern
setblock 198 55 311 minecraft:sea_lantern
setblock 198 55 313 minecraft:sea_lantern
setblock 198 55 315 minecraft:sea_lantern
setblock 199 55 310 minecraft:sea_lantern
setblock 199 55 312 minecraft:sea_lantern
setblock 199 55 314 minecraft:sea_lantern
setblock 199 55 316 minecraft:sea_lantern
fill 211 55 275 211 126 275 minecraft:dark_prismarine
setblock 214 55 307 minecraft:sea_lantern
setblock 214 55 309 minecraft:sea_lantern
setblock 214 55 311 minecraft:sea_lantern
setblock 214 55 313 minecraft:sea_lantern
setblock 214 55 315 minecraft:sea_lantern
setblock 215 55 306 minecraft:sea_lantern
setblock 215 55 308 minecraft:sea_lantern
setblock 215 55 310 minecraft:sea_lantern
setblock 215 55 312 minecraft:sea_lantern
setblock 215 55 314 minecraft:sea_lantern
setblock 215 55 316 minecraft:sea_lantern
setblock 216 55 307 minecraft:sea_lantern
setblock 216 55 309 minecraft:sea_lantern
setblock 216 55 311 minecraft:sea_lantern
setblock 216 55 313 minecraft:sea_lantern
setblock 216 55 315 minecraft:sea_lantern
setblock 217 55 306 minecraft:sea_lantern
setblock 217 55 308 minecraft:sea_lantern
setblock 217 55 310 minecraft:sea_lantern
setblock 217 55 312 minecraft:sea_lantern
setblock 217 55 314 minecraft:sea_lantern
setblock 217 55 316 minecraft:sea_lantern
setblock 218 55 307 minecraft:sea_lantern
setblock 218 55 309 minecraft:sea_lantern
setblock 218 55 311 minecraft:sea_lantern
setblock 218 55 313 minecraft:sea_lantern
setblock 218 55 315 minecraft:sea_lantern
setblock 219 55 306 minecraft:sea_lantern
setblock 219 55 308 minecraft:sea_lantern
setblock 219 55 310 minecraft:sea_lantern
setblock 219 55 312 minecraft:sea_lantern
setblock 219 55 314 minecraft:sea_lantern
setblock 219 55 316 minecraft:sea_lantern
setblock 220 55 307 minecraft:sea_lantern
setblock 220 55 309 minecraft:sea_lantern
setblock 220 55 311 minecraft:sea_lantern
setblock 220 55 313 minecraft:sea_lantern
setblock 220 55 315 minecraft:sea_lantern
setblock 221 55 306 minecraft:sea_lantern
setblock 221 55 308 minecraft:sea_lantern
setblock 221 55 310 minecraft:sea_lantern
setblock 221 55 312 minecraft:sea_lantern
setblock 221 55 314 minecraft:sea_lantern
setblock 221 55 316 minecraft:sea_lantern
setblock 222 55 307 minecraft:sea_lantern
setblock 222 55 309 minecraft:sea_lantern
setblock 222 55 311 minecraft:sea_lantern
setblock 222 55 313 minecraft:sea_lantern
setblock 222 55 315 minecraft:sea_lantern
fill 223 55 288 223 62 288 minecraft:dark_prismarine
setblock 223 55 306 minecraft:sea_lantern
setblock 223 55 308 minecraft:sea_lantern
setblock 223 55 310 minecraft:sea_lantern
setblock 223 55 312 minecraft:sea_lantern
setblock 223 55 314 minecraft:sea_lantern
setblock 223 55 316 minecraft:sea_lantern
fill 224 55 275 224 96 275 minecraft:dark_prismarine
setblock 224 55 307 minecraft:sea_lantern
setblock 224 55 309 minecraft:sea_lantern
setblock 224 55 311 minecraft:sea_lantern
setblock 224 55 313 minecraft:sea_lantern
setblock 224 55 315 minecraft:sea_lantern
setblock 225 55 275 minecraft:sea_lantern
setblock 225 55 306 minecraft:sea_lantern
setblock 225 55 308 minecraft:sea_lantern
setblock 225 55 310 minecraft:sea_lantern
setblock 225 55 312 minecraft:sea_lantern
fill 225 55 313 225 80 313 minecraft:quartz_pillar
setblock 225 55 314 minecraft:sea_lantern
setblock 225 55 316 minecraft:sea_lantern
fill 226 55 275 230 65 275 minecraft:dark_prismarine
fill 226 55 293 227 55 294 minecraft:gold_block
setblock 226 55 307 minecraft:sea_lantern
setblock 226 55 309 minecraft:sea_lantern
setblock 226 55 311 minecraft:sea_lantern
fill 226 55 312 227 80 312 minecraft:quartz_pillar
setblock 226 55 313 minecraft:sea_lantern
fill 226 55 314 227 80 314 minecraft:quartz_pillar
setblock 226 55 315 minecraft:sea_lantern
fill 227 55 313 227 80 313 minecraft:quartz_pillar
setblock 230 55 303 minecraft:prismarine_bricks
fill 189 56 302 189 57 302 minecraft:prismarine_bricks
fill 189 56 304 189 57 304 minecraft:prismarine_bricks
fill 189 56 306 189 57 306 minecraft:prismarine_bricks
setblock 189 56 308 minecraft:prismarine_bricks
fill 190 56 301 190 57 301 minecraft:prismarine_bricks
fill 190 56 303 190 57 303 minecraft:prismarine_bricks
fill 190 56 305 190 57 305 minecraft:prismarine_bricks
fill 190 56 307 190 57 307 minecraft:prismarine_bricks
fill 190 56 309 190 56 310 minecraft:gold_block
setblock 191 56 285 minecraft:light[level=12]
setblock 191 56 292 minecraft:light[level=12]
setblock 191 56 299 minecraft:light[level=12]
fill 191 56 302 192 57 302 minecraft:prismarine_bricks
fill 191 56 304 195 57 304 minecraft:prismarine_bricks
fill 191 56 306 191 57 306 minecraft:prismarine_bricks
fill 191 56 308 191 57 308 minecraft:gold_block
setblock 191 56 310 minecraft:gold_block
fill 192 56 277 192 57 277 minecraft:prismarine_bricks
fill 192 56 279 192 57 279 minecraft:quartz_pillar
fill 192 56 301 192 57 301 minecraft:prismarine_bricks
fill 192 56 303 192 57 303 minecraft:prismarine_bricks
fill 192 56 305 192 57 305 minecraft:prismarine_bricks
fill 192 56 307 192 57 307 minecraft:prismarine_bricks
setblock 192 56 309 minecraft:prismarine_bricks
fill 193 56 276 193 57 276 minecraft:prismarine_bricks
fill 193 56 278 193 57 278 minecraft:quartz_pillar
setblock 193 56 302 minecraft:gold_block
fill 193 56 306 193 57 306 minecraft:prismarine_bricks
fill 193 56 308 193 57 308 minecraft:prismarine_bricks
fill 193 56 310 193 58 310 minecraft:prismarine_bricks
fill 193 56 312 193 80 312 minecraft:quartz_pillar
fill 193 56 314 193 80 314 minecraft:quartz_pillar
fill 193 56 316 193 58 316 minecraft:prismarine_bricks
fill 194 56 277 194 57 277 minecraft:prismarine_bricks
fill 194 56 279 194 57 279 minecraft:prismarine_bricks
setblock 194 56 301 minecraft:gold_block
setblock 194 56 303 minecraft:gold_block
fill 194 56 305 194 57 305 minecraft:prismarine_bricks
fill 194 56 307 194 57 307 minecraft:prismarine_bricks
fill 194 56 311 194 58 311 minecraft:prismarine_bricks
fill 194 56 313 194 58 313 minecraft:prismarine_bricks
fill 194 56 315 194 58 315 minecraft:prismarine_bricks
fill 195 56 276 195 57 276 minecraft:prismarine_bricks
fill 195 56 278 195 57 278 minecraft:prismarine_bricks
fill 195 56 301 195 57 303 minecraft:prismarine_bricks
fill 195 56 306 195 57 306 minecraft:prismarine_bricks
fill 195 56 310 195 58 310 minecraft:prismarine_bricks
fill 195 56 312 195 58 312 minecraft:prismarine_bricks
fill 195 56 314 195 58 314 minecraft:prismarine_bricks
fill 195 56 316 195 118 316 minecraft:prismarine_bricks
fill 196 56 277 196 57 277 minecraft:prismarine_bricks
fill 196 56 279 196 57 279 minecraft:prismarine_bricks
fill 196 56 311 196 58 311 minecraft:prismarine_bricks
fill 196 56 313 196 58 313 minecraft:prismarine_bricks
fill 196 56 315 196 58 315 minecraft:prismarine_bricks
fill 197 56 276 197 57 276 minecraft:prismarine_bricks
fill 197 56 278 197 57 278 minecraft:prismarine_bricks
fill 197 56 310 197 58 310 minecraft:prismarine_bricks
fill 197 56 312 197 58 312 minecraft:prismarine_bricks
fill 197 56 314 197 58 314 minecraft:prismarine_bricks
fill 197 56 316 197 118 316 minecraft:prismarine_bricks
fill 198 56 277 198 57 277 minecraft:prismarine_bricks
fill 198 56 279 198 57 279 minecraft:prismarine_bricks
setblock 198 56 285 minecraft:light[level=12]
setblock 198 56 292 minecraft:light[level=12]
setblock 198 56 299 minecraft:light[level=12]
setblock 198 56 306 minecraft:light[level=12]
fill 198 56 311 198 58 311 minecraft:prismarine_bricks
fill 198 56 313 198 58 313 minecraft:prismarine_bricks
fill 198 56 315 198 58 315 minecraft:prismarine_bricks
fill 199 56 310 199 58 310 minecraft:prismarine_bricks
fill 199 56 312 199 58 312 minecraft:prismarine_bricks
fill 199 56 314 199 58 314 minecraft:prismarine_bricks
fill 199 56 316 199 58 316 minecraft:prismarine_bricks
setblock 205 56 278 minecraft:light[level=12]
setblock 205 56 285 minecraft:light[level=12]
setblock 205 56 292 minecraft:light[level=12]
setblock 205 56 299 minecraft:light[level=12]
setblock 205 56 306 minecraft:light[level=12]
setblock 205 56 313 minecraft:light[level=12]
setblock 212 56 278 minecraft:light[level=12]
setblock 212 56 285 minecraft:light[level=12]
setblock 212 56 292 minecraft:light[level=12]
setblock 212 56 299 minecraft:light[level=12]
setblock 212 56 306 minecraft:light[level=12]
setblock 212 56 313 minecraft:light[level=12]
fill 214 56 307 214 57 307 minecraft:prismarine_bricks
fill 214 56 309 214 57 309 minecraft:prismarine_bricks
fill 214 56 311 214 57 311 minecraft:prismarine_bricks
fill 214 56 313 214 57 313 minecraft:prismarine_bricks
fill 214 56 315 214 57 315 minecraft:prismarine_bricks
fill 215 56 306 215 57 306 minecraft:prismarine_bricks
fill 215 56 308 215 57 308 minecraft:prismarine_bricks
fill 215 56 310 215 57 310 minecraft:prismarine_bricks
fill 215 56 312 215 57 312 minecraft:prismarine_bricks
fill 215 56 314 215 57 314 minecraft:prismarine_bricks
fill 215 56 316 215 57 316 minecraft:prismarine_bricks
fill 216 56 307 216 57 307 minecraft:prismarine_bricks
fill 216 56 309 216 57 309 minecraft:prismarine_bricks
fill 216 56 311 216 57 311 minecraft:prismarine_bricks
fill 216 56 313 216 57 313 minecraft:prismarine_bricks
fill 216 56 315 216 57 315 minecraft:prismarine_bricks
fill 217 56 306 217 57 306 minecraft:prismarine_bricks
fill 217 56 308 217 57 308 minecraft:prismarine_bricks
fill 217 56 310 217 57 310 minecraft:prismarine_bricks
fill 217 56 312 217 57 312 minecraft:prismarine_bricks
fill 217 56 314 217 57 314 minecraft:prismarine_bricks
fill 217 56 316 217 57 316 minecraft:prismarine_bricks
fill 218 56 307 218 57 307 minecraft:prismarine_bricks
fill 218 56 309 218 57 309 minecraft:prismarine_bricks
fill 218 56 311 218 57 311 minecraft:prismarine_bricks
fill 218 56 313 218 57 313 minecraft:prismarine_bricks
fill 218 56 315 218 57 315 minecraft:prismarine_bricks
setblock 219 56 278 minecraft:light[level=12]
setblock 219 56 285 minecraft:light[level=12]
setblock 219 56 292 minecraft:light[level=12]
setblock 219 56 299 minecraft:light[level=12]
fill 219 56 306 219 57 306 minecraft:prismarine_bricks
fill 219 56 308 219 57 308 minecraft:prismarine_bricks
fill 219 56 310 219 57 310 minecraft:prismarine_bricks
fill 219 56 312 219 57 312 minecraft:prismarine_bricks
fill 219 56 314 219 57 314 minecraft:prismarine_bricks
fill 219 56 316 219 57 316 minecraft:prismarine_bricks
fill 220 56 307 220 57 307 minecraft:prismarine_bricks
fill 220 56 309 220 57 309 minecraft:prismarine_bricks
fill 220 56 311 220 57 311 minecraft:prismarine_bricks
fill 220 56 313 220 57 313 minecraft:prismarine_bricks
fill 220 56 315 220 57 315 minecraft:prismarine_bricks
fill 221 56 306 221 57 306 minecraft:prismarine_bricks
fill 221 56 308 221 57 308 minecraft:prismarine_bricks
fill 221 56 310 221 57 310 minecraft:prismarine_bricks
fill 221 56 312 221 57 312 minecraft:prismarine_bricks
fill 221 56 314 221 57 314 minecraft:prismarine_bricks
fill 221 56 316 221 57 316 minecraft:prismarine_bricks
fill 222 56 307 222 57 307 minecraft:prismarine_bricks
fill 222 56 309 222 57 309 minecraft:prismarine_bricks
fill 222 56 311 222 57 311 minecraft:prismarine_bricks
fill 222 56 313 222 57 313 minecraft:prismarine_bricks
fill 222 56 315 222 57 315 minecraft:prismarine_bricks
fill 223 56 301 223 63 301 minecraft:iron_block
fill 223 56 306 223 57 306 minecraft:prismarine_bricks
fill 223 56 308 223 57 308 minecraft:prismarine_bricks
fill 223 56 310 223 57 310 minecraft:prismarine_bricks
fill 223 56 312 223 57 312 minecraft:prismarine_bricks
fill 223 56 314 223 57 314 minecraft:prismarine_bricks
fill 223 56 316 223 57 316 minecraft:prismarine_bricks
fill 224 56 307 224 57 307 minecraft:prismarine_bricks
fill 224 56 309 224 57 309 minecraft:prismarine_bricks
fill 224 56 311 224 57 311 minecraft:prismarine_bricks
fill 224 56 313 224 57 313 minecraft:prismarine_bricks
fill 224 56 315 224 57 315 minecraft:prismarine_bricks
fill 225 56 275 225 59 275 minecraft:dark_prismarine
fill 225 56 294 228 56 294 minecraft:gold_block
fill 225 56 306 225 57 306 minecraft:prismarine_bricks
fill 225 56 308 225 57 308 minecraft:prismarine_bricks
fill 225 56 310 225 57 310 minecraft:prismarine_bricks
fill 225 56 312 225 57 312 minecraft:quartz_pillar
fill 225 56 314 225 57 314 minecraft:quartz_pillar
fill 225 56 316 225 57 316 minecraft:prismarine_bricks
setblock 226 56 285 minecraft:light[level=12]
setblock 226 56 292 minecraft:light[level=12]
setblock 226 56 299 minecraft:light[level=12]
fill 226 56 307 226 57 307 minecraft:prismarine_bricks
fill 226 56 309 226 57 309 minecraft:prismarine_bricks
fill 226 56 311 226 57 311 minecraft:prismarine_bricks
fill 226 56 313 226 57 313 minecraft:quartz_pillar
fill 226 56 315 226 57 315 minecraft:prismarine_bricks
fill 230 56 303 230 65 303 minecraft:dark_prismarine
fill 189 57 308 189 57 309 minecraft:gold_block
setblock 190 57 309 minecraft:gold_block
fill 192 57 308 192 57 309 minecraft:gold_block
fill 193 57 301 194 57 303 minecraft:prismarine_bricks
fill 201 57 309 205 58 313 minecraft:dark_prismarine
fill 203 57 314 203 57 315 minecraft:dark_prismarine
fill 204 57 317 207 103 317 minecraft:dark_prismarine
setblock 208 57 317 minecraft:sea_lantern
fill 209 57 317 211 57 317 minecraft:dark_prismarine
fill 222 57 288 222 62 288 minecraft:dark_prismarine
fill 223 57 287 223 62 287 minecraft:dark_prismarine
setblock 189 58 302 minecraft:sea_lantern
setblock 189 58 304 minecraft:sea_lantern
setblock 189 58 306 minecraft:sea_lantern
setblock 189 58 308 minecraft:sea_lantern
fill 189 58 309 189 67 309 minecraft:prismarine_bricks
setblock 189 58 317 minecraft:sea_lantern
setblock 190 58 301 minecraft:sea_lantern
setblock 190 58 303 minecraft:sea_lantern
setblock 190 58 305 minecraft:sea_lantern
setblock 190 58 307 minecraft:sea_lantern
setblock 190 58 309 minecraft:sea_lantern
fill 190 58 317 190 65 317 minecraft:dark_prismarine
setblock 191 58 302 minecraft:sea_lantern
setblock 191 58 304 minecraft:sea_lantern
setblock 191 58 306 minecraft:sea_lantern
setblock 191 58 308 minecraft:sea_lantern
fill 191 58 309 191 67 309 minecraft:prismarine_bricks
setblock 192 58 277 minecraft:sea_lantern
setblock 192 58 279 minecraft:sea_lantern
setblock 192 58 301 minecraft:sea_lantern
fill 192 58 302 192 67 302 minecraft:prismarine_bricks
setblock 192 58 303 minecraft:sea_lantern
fill 192 58 304 192 67 304 minecraft:prismarine_bricks
setblock 192 58 305 minecraft:sea_lantern
setblock 192 58 307 minecraft:sea_lantern
setblock 192 58 308 minecraft:gold_block
setblock 192 58 309 minecraft:sea_lantern
setblock 193 58 276 minecraft:sea_lantern
setblock 193 58 278 minecraft:sea_lantern
fill 193 58 301 193 67 301 minecraft:prismarine_bricks
setblock 193 58 302 minecraft:sea_lantern
fill 193 58 303 193 67 303 minecraft:prismarine_bricks
setblock 193 58 304 minecraft:sea_lantern
setblock 193 58 306 minecraft:sea_lantern
setblock 193 58 308 minecraft:sea_lantern
setblock 194 58 277 minecraft:sea_lantern
setblock 194 58 279 minecraft:sea_lantern
setblock 194 58 301 minecraft:sea_lantern
fill 194 58 302 194 67 302 minecraft:prismarine_bricks
setblock 194 58 303 minecraft:sea_lantern
fill 194 58 304 194 67 304 minecraft:prismarine_bricks
setblock 194 58 305 minecraft:sea_lantern
setblock 194 58 307 minecraft:sea_lantern
setblock 195 58 276 minecraft:sea_lantern
setblock 195 58 278 minecraft:sea_lantern
fill 195 58 301 195 67 301 minecraft:prismarine_bricks
setblock 195 58 302 minecraft:sea_lantern
fill 195 58 303 195 67 303 minecraft:prismarine_bricks
setblock 195 58 304 minecraft:sea_lantern
setblock 195 58 306 minecraft:sea_lantern
setblock 196 58 277 minecraft:sea_lantern
setblock 196 58 279 minecraft:sea_lantern
setblock 197 58 276 minecraft:sea_lantern
setblock 197 58 278 minecraft:sea_lantern
setblock 198 58 277 minecraft:sea_lantern
setblock 198 58 279 minecraft:sea_lantern
fill 208 58 317 208 126 317 minecraft:dark_prismarine
setblock 209 58 317 minecraft:prismarine_bricks
fill 210 58 317 211 70 317 minecraft:dark_prismarine
setblock 214 58 307 minecraft:sea_lantern
setblock 214 58 309 minecraft:sea_lantern
setblock 214 58 311 minecraft:sea_lantern
setblock 214 58 313 minecraft:sea_lantern
setblock 214 58 315 minecraft:sea_lantern
setblock 215 58 306 minecraft:sea_lantern
setblock 215 58 308 minecraft:sea_lantern
setblock 215 58 310 minecraft:sea_lantern
setblock 215 58 312 minecraft:sea_lantern
setblock 215 58 314 minecraft:sea_lantern
setblock 215 58 316 minecraft:sea_lantern
setblock 216 58 307 minecraft:sea_lantern
setblock 216 58 309 minecraft:sea_lantern
setblock 216 58 311 minecraft:sea_lantern
setblock 216 58 313 minecraft:sea_lantern
setblock 216 58 315 minecraft:sea_lantern
setblock 217 58 306 minecraft:sea_lantern
setblock 217 58 308 minecraft:sea_lantern
setblock 217 58 310 minecraft:sea_lantern
setblock 217 58 312 minecraft:sea_lantern
setblock 217 58 314 minecraft:sea_lantern
setblock 217 58 316 minecraft:sea_lantern
setblock 218 58 307 minecraft:sea_lantern
setblock 218 58 309 minecraft:sea_lantern
setblock 218 58 311 minecraft:sea_lantern
setblock 218 58 313 minecraft:sea_lantern
setblock 218 58 315 minecraft:sea_lantern
setblock 219 58 306 minecraft:sea_lantern
setblock 219 58 308 minecraft:sea_lantern
setblock 219 58 310 minecraft:sea_lantern
setblock 219 58 312 minecraft:sea_lantern
setblock 219 58 314 minecraft:sea_lantern
setblock 219 58 316 minecraft:sea_lantern
setblock 220 58 307 minecraft:sea_lantern
setblock 220 58 309 minecraft:sea_lantern
setblock 220 58 311 minecraft:sea_lantern
setblock 220 58 313 minecraft:sea_lantern
setblock 220 58 315 minecraft:sea_lantern
setblock 221 58 306 minecraft:sea_lantern
setblock 221 58 308 minecraft:sea_lantern
setblock 221 58 310 minecraft:sea_lantern
setblock 221 58 312 minecraft:sea_lantern
setblock 221 58 314 minecraft:sea_lantern
setblock 221 58 316 minecraft:sea_lantern
fill 222 58 287 222 62 287 minecraft:dark_prismarine
fill 222 58 289 223 62 289 minecraft:dark_prismarine
setblock 222 58 307 minecraft:sea_lantern
setblock 222 58 309 minecraft:sea_lantern
setblock 222 58 311 minecraft:sea_lantern
setblock 222 58 313 minecraft:sea_lantern
setblock 222 58 315 minecraft:sea_lantern
setblock 223 58 306 minecraft:sea_lantern
setblock 223 58 308 minecraft:sea_lantern
setblock 223 58 310 minecraft:sea_lantern
setblock 223 58 312 minecraft:sea_lantern
setblock 223 58 314 minecraft:sea_lantern
setblock 223 58 316 minecraft:sea_lantern
fill 224 58 287 224 62 288 minecraft:dark_prismarine
setblock 224 58 307 minecraft:sea_lantern
setblock 224 58 309 minecraft:sea_lantern
setblock 224 58 311 minecraft:sea_lantern
setblock 224 58 313 minecraft:sea_lantern
setblock 224 58 315 minecraft:sea_lantern
setblock 225 58 306 minecraft:sea_lantern
setblock 225 58 308 minecraft:sea_lantern
setblock 225 58 310 minecraft:sea_lantern
setblock 225 58 312 minecraft:sea_lantern
setblock 225 58 314 minecraft:sea_lantern
setblock 225 58 316 minecraft:sea_lantern
setblock 226 58 307 minecraft:sea_lantern
setblock 226 58 309 minecraft:sea_lantern
setblock 226 58 311 minecraft:sea_lantern
setblock 226 58 313 minecraft:sea_lantern
setblock 226 58 315 minecraft:sea_lantern
fill 189 59 302 189 60 302 minecraft:prismarine_bricks
fill 189 59 304 189 60 304 minecraft:prismarine_bricks
fill 189 59 306 189 60 306 minecraft:prismarine_bricks
fill 189 59 308 193 60 308 minecraft:prismarine_bricks
fill 189 59 317 189 65 317 minecraft:dark_prismarine
fill 190 59 301 190 60 301 minecraft:prismarine_bricks
fill 190 59 303 190 60 303 minecraft:prismarine_bricks
fill 190 59 305 190 60 305 minecraft:prismarine_bricks
fill 190 59 307 190 60 307 minecraft:prismarine_bricks
fill 190 59 309 190 60 309 minecraft:prismarine_bricks
fill 191 59 302 191 60 302 minecraft:prismarine_bricks
fill 191 59 304 191 60 304 minecraft:prismarine_bricks
fill 191 59 306 191 60 306 minecraft:prismarine_bricks
fill 192 59 277 192 60 277 minecraft:prismarine_bricks
fill 192 59 279 192 60 279 minecraft:quartz_pillar
fill 192 59 301 192 60 301 minecraft:prismarine_bricks
fill 192 59 303 192 60 303 minecraft:prismarine_bricks
fill 192 59 305 192 60 305 minecraft:prismarine_bricks
fill 192 59 307 192 60 307 minecraft:prismarine_bricks
fill 192 59 309 192 60 309 minecraft:prismarine_bricks
fill 193 59 276 193 60 276 minecraft:prismarine_bricks
fill 193 59 278 193 60 278 minecraft:quartz_pillar
fill 193 59 302 193 60 302 minecraft:prismarine_bricks
fill 193 59 304 193 60 304 minecraft:prismarine_bricks
fill 193 59 306 193 60 306 minecraft:prismarine_bricks
fill 194 59 277 194 60 277 minecraft:prismarine_bricks
fill 194 59 279 194 60 279 minecraft:prismarine_bricks
fill 194 59 301 194 60 301 minecraft:prismarine_bricks
fill 194 59 303 194 60 303 minecraft:prismarine_bricks
fill 194 59 305 194 60 305 minecraft:prismarine_bricks
fill 194 59 307 194 60 307 minecraft:prismarine_bricks
fill 194 59 311 198 59 315 minecraft:gold_block
fill 195 59 276 195 60 276 minecraft:prismarine_bricks
fill 195 59 278 195 60 278 minecraft:prismarine_bricks
fill 195 59 302 195 60 302 minecraft:prismarine_bricks
fill 195 59 304 195 60 304 minecraft:prismarine_bricks
fill 195 59 306 195 60 306 minecraft:prismarine_bricks
fill 196 59 277 196 60 277 minecraft:prismarine_bricks
fill 196 59 279 196 60 279 minecraft:prismarine_bricks
fill 197 59 276 197 60 276 minecraft:prismarine_bricks
fill 197 59 278 197 60 278 minecraft:prismarine_bricks
fill 198 59 277 198 60 277 minecraft:prismarine_bricks
fill 198 59 279 198 60 279 minecraft:prismarine_bricks
setblock 201 59 317 minecraft:prismarine_bricks
fill 202 59 310 204 60 312 minecraft:prismarine_bricks
fill 202 59 317 202 65 317 minecraft:dark_prismarine
fill 209 59 317 209 106 317 minecraft:dark_prismarine
fill 214 59 307 214 61 307 minecraft:prismarine_bricks
fill 214 59 309 214 61 309 minecraft:prismarine_bricks
fill 214 59 311 214 61 311 minecraft:prismarine_bricks
fill 214 59 313 214 61 313 minecraft:prismarine_bricks
fill 214 59 315 214 61 315 minecraft:prismarine_bricks
fill 215 59 306 215 61 306 minecraft:prismarine_bricks
fill 215 59 308 215 61 308 minecraft:prismarine_bricks
fill 215 59 310 215 61 310 minecraft:prismarine_bricks
fill 215 59 312 215 61 312 minecraft:prismarine_bricks
fill 215 59 314 215 61 314 minecraft:prismarine_bricks
fill 215 59 316 215 61 316 minecraft:prismarine_bricks
fill 216 59 307 216 61 307 minecraft:prismarine_bricks
fill 216 59 309 216 61 309 minecraft:prismarine_bricks
fill 216 59 311 216 61 311 minecraft:prismarine_bricks
fill 216 59 313 216 61 313 minecraft:prismarine_bricks
fill 216 59 315 216 61 315 minecraft:prismarine_bricks
fill 217 59 306 217 61 306 minecraft:prismarine_bricks
fill 217 59 308 217 61 308 minecraft:prismarine_bricks
fill 217 59 310 217 61 310 minecraft:prismarine_bricks
fill 217 59 312 217 61 312 minecraft:prismarine_bricks
fill 217 59 314 217 61 314 minecraft:prismarine_bricks
fill 217 59 316 217 61 316 minecraft:prismarine_bricks
fill 218 59 307 218 61 307 minecraft:prismarine_bricks
fill 218 59 309 218 61 309 minecraft:prismarine_bricks
fill 218 59 311 218 61 311 minecraft:prismarine_bricks
fill 218 59 313 218 61 313 minecraft:prismarine_bricks
fill 218 59 315 218 61 315 minecraft:prismarine_bricks
fill 219 59 306 219 61 306 minecraft:prismarine_bricks
fill 219 59 308 219 61 308 minecraft:prismarine_bricks
fill 219 59 310 219 61 310 minecraft:prismarine_bricks
fill 219 59 312 219 61 312 minecraft:prismarine_bricks
fill 219 59 314 219 61 314 minecraft:prismarine_bricks
fill 219 59 316 219 118 316 minecraft:prismarine_bricks
fill 220 59 307 220 61 307 minecraft:prismarine_bricks
fill 220 59 309 220 61 309 minecraft:prismarine_bricks
fill 220 59 311 220 61 311 minecraft:prismarine_bricks
fill 220 59 313 220 61 313 minecraft:prismarine_bricks
fill 220 59 315 220 65 315 minecraft:prismarine_bricks
fill 221 59 288 221 62 288 minecraft:dark_prismarine
fill 221 59 306 221 61 306 minecraft:prismarine_bricks
fill 221 59 308 221 61 308 minecraft:prismarine_bricks
fill 221 59 310 221 61 310 minecraft:prismarine_bricks
fill 221 59 312 221 61 312 minecraft:prismarine_bricks
fill 221 59 314 221 61 314 minecraft:prismarine_bricks
fill 221 59 316 221 118 316 minecraft:prismarine_bricks
fill 222 59 307 222 61 307 minecraft:prismarine_bricks
fill 222 59 309 222 61 309 minecraft:prismarine_bricks
fill 222 59 311 222 61 311 minecraft:prismarine_bricks
fill 222 59 313 222 61 313 minecraft:prismarine_bricks
fill 222 59 315 222 65 315 minecraft:prismarine_bricks
fill 223 59 286 223 62 286 minecraft:dark_prismarine
fill 223 59 306 223 61 306 minecraft:prismarine_bricks
fill 223 59 308 223 61 308 minecraft:prismarine_bricks
fill 223 59 310 223 61 310 minecraft:prismarine_bricks
fill 223 59 312 223 61 312 minecraft:prismarine_bricks
fill 223 59 314 223 61 314 minecraft:prismarine_bricks
fill 223 59 316 223 61 316 minecraft:prismarine_bricks
fill 224 59 289 224 62 289 minecraft:dark_prismarine
fill 224 59 307 224 61 307 minecraft:prismarine_bricks
fill 224 59 309 224 61 309 minecraft:prismarine_bricks
fill 224 59 311 224 61 311 minecraft:prismarine_bricks
fill 224 59 313 224 61 313 minecraft:prismarine_bricks
fill 224 59 315 224 61 315 minecraft:prismarine_bricks
fill 225 59 306 225 61 306 minecraft:prismarine_bricks
fill 225 59 308 225 61 308 minecraft:prismarine_bricks
fill 225 59 310 225 61 310 minecraft:prismarine_bricks
fill 225 59 312 225 80 312 minecraft:quartz_pillar
fill 225 59 314 225 80 314 minecraft:quartz_pillar
fill 225 59 316 225 61 316 minecraft:prismarine_bricks
fill 226 59 307 226 61 307 minecraft:prismarine_bricks
fill 226 59 309 226 61 309 minecraft:prismarine_bricks
fill 226 59 311 226 61 311 minecraft:prismarine_bricks
fill 226 59 313 226 80 313 minecraft:quartz_pillar
fill 226 59 315 226 61 315 minecraft:prismarine_bricks
fill 190 60 285 190 65 287 minecraft:prismarine_bricks
fill 190 60 298 190 65 299 minecraft:prismarine_bricks
fill 190 60 310 190 65 311 minecraft:prismarine_bricks
fill 195 60 312 197 60 314 minecraft:gold_block
fill 196 60 315 198 65 315 minecraft:prismarine_bricks
fill 200 60 277 202 65 277 minecraft:prismarine_bricks
fill 201 60 317 201 65 317 minecraft:dark_prismarine
fill 212 60 277 214 65 277 minecraft:prismarine_bricks
fill 221 60 287 221 62 287 minecraft:dark_prismarine
fill 221 60 289 221 62 289 minecraft:dark_prismarine
fill 222 60 286 222 62 286 minecraft:dark_prismarine
fill 222 60 290 223 62 290 minecraft:dark_prismarine
fill 224 60 277 226 65 277 minecraft:prismarine_bricks
fill 224 60 286 224 62 286 minecraft:dark_prismarine
setblock 225 60 275 minecraft:sea_lantern
fill 225 60 287 225 62 288 minecraft:dark_prismarine
fill 228 60 285 228 65 287 minecraft:prismarine_bricks
fill 228 60 298 228 65 299 minecraft:prismarine_bricks
fill 228 60 309 228 65 311 minecraft:prismarine_bricks
setblock 189 61 302 minecraft:sea_lantern
setblock 189 61 304 minecraft:sea_lantern
setblock 189 61 306 minecraft:sea_lantern
setblock 189 61 308 minecraft:sea_lantern
setblock 190 61 301 minecraft:sea_lantern
setblock 190 61 303 minecraft:sea_lantern
setblock 190 61 305 minecraft:sea_lantern
setblock 190 61 307 minecraft:sea_lantern
fill 190 61 308 190 67 308 minecraft:prismarine_bricks
setblock 190 61 309 minecraft:sea_lantern
setblock 191 61 302 minecraft:sea_lantern
setblock 191 61 304 minecraft:sea_lantern
setblock 191 61 306 minecraft:sea_lantern
setblock 191 61 308 minecraft:sea_lantern
setblock 192 61 277 minecraft:sea_lantern
setblock 192 61 279 minecraft:sea_lantern
setblock 192 61 301 minecraft:sea_lantern
setblock 192 61 303 minecraft:sea_lantern
setblock 192 61 305 minecraft:sea_lantern
setblock 192 61 307 minecraft:sea_lantern
fill 192 61 308 192 67 308 minecraft:prismarine_bricks
setblock 192 61 309 minecraft:sea_lantern
setblock 193 61 276 minecraft:sea_lantern
setblock 193 61 278 minecraft:sea_lantern
setblock 193 61 302 minecraft:sea_lantern
setblock 193 61 304 minecraft:sea_lantern
setblock 193 61 306 minecraft:sea_lantern
setblock 193 61 308 minecraft:sea_lantern
setblock 194 61 277 minecraft:sea_lantern
setblock 194 61 279 minecraft:sea_lantern
setblock 194 61 301 minecraft:sea_lantern
setblock 194 61 303 minecraft:sea_lantern
setblock 194 61 305 minecraft:sea_lantern
setblock 194 61 307 minecraft:sea_lantern
setblock 195 61 276 minecraft:sea_lantern
setblock 195 61 278 minecraft:sea_lantern
setblock 195 61 302 minecraft:sea_lantern
setblock 195 61 304 minecraft:sea_lantern
setblock 195 61 306 minecraft:sea_lantern
setblock 196 61 277 minecraft:sea_lantern
setblock 196 61 279 minecraft:sea_lantern
fill 196 61 313 196 62 313 minecraft:gold_block
setblock 197 61 276 minecraft:sea_lantern
setblock 197 61 278 minecraft:sea_lantern
setblock 198 61 277 minecraft:sea_lantern
setblock 198 61 279 minecraft:sea_lantern
fill 202 61 311 204 63 311 minecraft:prismarine_bricks
fill 203 61 310 203 63 310 minecraft:prismarine_bricks
fill 203 61 312 203 63 312 minecraft:prismarine_bricks
fill 220 61 288 220 62 288 minecraft:dark_prismarine
fill 221 61 286 221 62 286 minecraft:dark_prismarine
fill 221 61 290 221 62 290 minecraft:dark_prismarine
fill 223 61 285 223 62 285 minecraft:dark_prismarine
fill 224 61 290 224 62 290 minecraft:dark_prismarine
fill 225 61 275 225 127 275 minecraft:dark_prismarine
fill 225 61 289 225 62 289 minecraft:dark_prismarine
setblock 230 61 277 minecraft:sea_lantern
fill 230 61 278 230 65 278 minecraft:dark_prismarine
fill 188 62 285 188 68 287 minecraft:dark_prismarine
setblock 188 62 288 minecraft:sea_lantern
fill 189 62 275 190 126 275 minecraft:dark_prismarine
fill 189 62 302 189 63 302 minecraft:prismarine_bricks
fill 189 62 304 189 63 304 minecraft:prismarine_bricks
fill 189 62 306 189 63 306 minecraft:prismarine_bricks
fill 189 62 308 189 63 308 minecraft:prismarine_bricks
fill 190 62 301 190 63 301 minecraft:prismarine_bricks
fill 190 62 303 190 63 303 minecraft:prismarine_bricks
fill 190 62 305 190 63 305 minecraft:prismarine_bricks
fill 190 62 307 190 63 307 minecraft:prismarine_bricks
fill 190 62 309 190 63 309 minecraft:prismarine_bricks
setblock 191 62 275 minecraft:prismarine_bricks
setblock 191 62 285 minecraft:light[level=12]
setblock 191 62 286 minecraft:light[level=15]
setblock 191 62 292 minecraft:light[level=12]
setblock 191 62 294 minecraft:light[level=15]
setblock 191 62 299 minecraft:light[level=12]
fill 191 62 302 191 63 302 minecraft:prismarine_bricks
fill 191 62 304 191 63 304 minecraft:prismarine_bricks
fill 191 62 306 191 63 306 minecraft:prismarine_bricks
fill 191 62 308 191 63 308 minecraft:prismarine_bricks
setblock 191 62 310 minecraft:light[level=15]
fill 192 62 277 192 63 277 minecraft:prismarine_bricks
fill 192 62 279 192 63 279 minecraft:quartz_pillar
fill 192 62 301 192 63 301 minecraft:prismarine_bricks
fill 192 62 303 192 63 303 minecraft:prismarine_bricks
fill 192 62 305 192 63 305 minecraft:prismarine_bricks
fill 192 62 307 192 63 307 minecraft:prismarine_bricks
fill 192 62 309 192 63 309 minecraft:prismarine_bricks
fill 193 62 276 193 63 276 minecraft:prismarine_bricks
fill 193 62 278 193 63 278 minecraft:quartz_pillar
fill 193 62 302 193 63 302 minecraft:prismarine_bricks
fill 193 62 304 193 63 304 minecraft:prismarine_bricks
fill 193 62 306 193 63 306 minecraft:prismarine_bricks
fill 193 62 308 193 63 308 minecraft:prismarine_bricks
fill 194 62 277 194 63 277 minecraft:prismarine_bricks
fill 194 62 279 194 63 279 minecraft:prismarine_bricks
fill 194 62 301 194 63 301 minecraft:prismarine_bricks
fill 194 62 303 194 63 303 minecraft:prismarine_bricks
fill 194 62 305 194 63 305 minecraft:prismarine_bricks
fill 194 62 307 194 63 307 minecraft:prismarine_bricks
fill 195 62 276 195 63 276 minecraft:prismarine_bricks
fill 195 62 278 195 63 278 minecraft:prismarine_bricks
fill 195 62 302 195 63 302 minecraft:prismarine_bricks
fill 195 62 304 195 63 304 minecraft:prismarine_bricks
fill 195 62 306 195 63 306 minecraft:prismarine_bricks
fill 195 62 312 195 62 314 minecraft:gold_block
fill 196 62 277 196 63 277 minecraft:prismarine_bricks
fill 196 62 279 196 63 279 minecraft:prismarine_bricks
fill 196 62 312 197 62 312 minecraft:gold_block
fill 196 62 314 197 62 314 minecraft:gold_block
fill 197 62 276 197 63 276 minecraft:prismarine_bricks
fill 197 62 278 197 63 278 minecraft:prismarine_bricks
setblock 197 62 313 minecraft:gold_block
fill 198 62 277 198 63 277 minecraft:prismarine_bricks
fill 198 62 279 198 63 279 minecraft:prismarine_bricks
setblock 198 62 285 minecraft:light[level=12]
setblock 198 62 292 minecraft:light[level=12]
setblock 198 62 299 minecraft:light[level=12]
setblock 198 62 306 minecraft:light[level=12]
setblock 198 62 313 minecraft:light[level=12]
setblock 199 62 278 minecraft:light[level=15]
setblock 199 62 286 minecraft:light[level=15]
setblock 199 62 294 minecraft:light[level=15]
setblock 199 62 302 minecraft:light[level=15]
setblock 199 62 310 minecraft:light[level=15]
setblock 205 62 278 minecraft:light[level=12]
setblock 205 62 285 minecraft:light[level=12]
setblock 205 62 292 minecraft:light[level=12]
setblock 205 62 299 minecraft:light[level=12]
setblock 205 62 306 minecraft:light[level=12]
setblock 205 62 313 minecraft:light[level=12]
setblock 207 62 278 minecraft:light[level=15]
setblock 207 62 286 minecraft:light[level=15]
setblock 207 62 294 minecraft:light[level=15]
setblock 207 62 302 minecraft:light[level=15]
setblock 207 62 310 minecraft:light[level=15]
setblock 212 62 278 minecraft:light[level=12]
setblock 212 62 285 minecraft:light[level=12]
setblock 212 62 292 minecraft:light[level=12]
setblock 212 62 299 minecraft:light[level=12]
setblock 212 62 306 minecraft:light[level=12]
setblock 212 62 313 minecraft:light[level=12]
setblock 215 62 278 minecraft:light[level=15]
setblock 215 62 286 minecraft:light[level=15]
setblock 215 62 294 minecraft:light[level=15]
setblock 215 62 302 minecraft:light[level=15]
fill 215 62 307 219 62 315 minecraft:gold_block
setblock 219 62 278 minecraft:light[level=12]
setblock 219 62 285 minecraft:light[level=12]
setblock 219 62 292 minecraft:light[level=12]
setblock 219 62 299 minecraft:light[level=12]
setblock 219 62 306 minecraft:light[level=12]
setblock 220 62 287 minecraft:dark_prismarine
setblock 220 62 289 minecraft:dark_prismarine
fill 220 62 307 224 62 314 minecraft:gold_block
setblock 222 62 285 minecraft:dark_prismarine
fill 222 62 291 223 62 291 minecraft:dark_prismarine
setblock 223 62 278 minecraft:light[level=15]
setblock 223 62 294 minecraft:light[level=15]
setblock 223 62 302 minecraft:light[level=15]
fill 223 62 315 225 62 315 minecraft:gold_block
setblock 224 62 285 minecraft:dark_prismarine
setblock 225 62 286 minecraft:dark_prismarine
setblock 225 62 290 minecraft:dark_prismarine
fill 225 62 307 225 62 311 minecraft:gold_block
setblock 226 62 285 minecraft:light[level=12]
fill 226 62 287 226 62 288 minecraft:dark_prismarine
setblock 226 62 292 minecraft:light[level=12]
setblock 226 62 299 minecraft:light[level=12]
setblock 226 62 306 minecraft:light[level=12]
fill 230 62 277 230 65 277 minecraft:dark_prismarine
fill 188 63 277 188 64 278 minecraft:dark_prismarine
setblock 188 63 279 minecraft:prismarine_bricks
fill 188 63 280 188 103 280 minecraft:dark_prismarine
fill 188 63 288 188 69 288 minecraft:dark_prismarine
fill 188 63 315 188 66 315 minecraft:dark_prismarine
setblock 188 63 316 minecraft:prismarine_bricks
fill 191 63 275 191 95 275 minecraft:dark_prismarine
fill 198 63 295 198 64 296 minecraft:light_blue_stained_glass
fill 199 63 275 200 120 275 minecraft:dark_prismarine
fill 199 63 296 199 64 296 minecraft:light_blue_stained_glass
setblock 201 63 275 minecraft:prismarine_bricks
fill 216 63 308 224 63 314 minecraft:gold_block
fill 221 63 287 221 64 287 minecraft:prismarine_bricks
fill 223 63 289 223 65 289 minecraft:prismarine_bricks
fill 224 63 287 224 64 287 minecraft:prismarine_bricks
fill 188 64 279 188 91 279 minecraft:dark_prismarine
fill 188 64 316 188 72 316 minecraft:dark_prismarine
setblock 189 64 302 minecraft:sea_lantern
setblock 189 64 304 minecraft:sea_lantern
setblock 189 64 306 minecraft:sea_lantern
setblock 189 64 308 minecraft:sea_lantern
setblock 190 64 301 minecraft:sea_lantern
setblock 190 64 303 minecraft:sea_lantern
setblock 190 64 305 minecraft:sea_lantern
setblock 190 64 307 minecraft:sea_lantern
setblock 190 64 309 minecraft:sea_lantern
setblock 191 64 302 minecraft:sea_lantern
setblock 191 64 304 minecraft:sea_lantern
setblock 191 64 306 minecraft:sea_lantern
setblock 191 64 308 minecraft:sea_lantern
setblock 192 64 277 minecraft:sea_lantern
setblock 192 64 279 minecraft:sea_lantern
setblock 192 64 301 minecraft:sea_lantern
setblock 192 64 303 minecraft:sea_lantern
setblock 192 64 305 minecraft:sea_lantern
setblock 192 64 307 minecraft:sea_lantern
setblock 192 64 309 minecraft:sea_lantern
setblock 193 64 276 minecraft:sea_lantern
setblock 193 64 278 minecraft:sea_lantern
setblock 193 64 302 minecraft:sea_lantern
setblock 193 64 304 minecraft:sea_lantern
setblock 193 64 306 minecraft:sea_lantern
setblock 193 64 308 minecraft:sea_lantern
setblock 194 64 277 minecraft:sea_lantern
setblock 194 64 279 minecraft:sea_lantern
setblock 194 64 301 minecraft:sea_lantern
setblock 194 64 303 minecraft:sea_lantern
setblock 194 64 305 minecraft:sea_lantern
setblock 194 64 307 minecraft:sea_lantern
setblock 195 64 276 minecraft:sea_lantern
setblock 195 64 278 minecraft:sea_lantern
setblock 195 64 302 minecraft:sea_lantern
setblock 195 64 304 minecraft:sea_lantern
setblock 195 64 306 minecraft:sea_lantern
setblock 196 64 277 minecraft:sea_lantern
setblock 196 64 279 minecraft:sea_lantern
setblock 197 64 276 minecraft:sea_lantern
setblock 197 64 278 minecraft:sea_lantern
setblock 198 64 277 minecraft:sea_lantern
setblock 198 64 279 minecraft:sea_lantern
fill 201 64 275 201 71 275 minecraft:dark_prismarine
fill 203 64 311 203 68 311 minecraft:prismarine_bricks
setblock 208 64 275 minecraft:prismarine_bricks
fill 209 64 275 209 65 275 minecraft:dark_prismarine
fill 217 64 309 223 64 313 minecraft:gold_block
setblock 188 65 277 minecraft:prismarine_bricks
fill 188 65 278 188 83 278 minecraft:dark_prismarine
fill 189 65 279 189 65 284 minecraft:dark_prismarine
fill 189 65 291 189 65 296 minecraft:dark_prismarine
fill 189 65 302 189 67 302 minecraft:prismarine_bricks
fill 189 65 303 189 65 308 minecraft:dark_prismarine
fill 189 65 315 189 65 316 minecraft:dark_prismarine
fill 190 65 301 190 67 301 minecraft:prismarine_bricks
fill 190 65 303 190 67 303 minecraft:prismarine_bricks
fill 190 65 305 190 67 305 minecraft:prismarine_bricks
fill 190 65 307 190 67 307 minecraft:prismarine_bricks
fill 190 65 309 190 67 309 minecraft:prismarine_bricks
fill 190 65 316 193 65 316 minecraft:dark_prismarine
fill 191 65 302 191 67 302 minecraft:prismarine_bricks
fill 191 65 304 191 67 304 minecraft:prismarine_bricks
fill 191 65 306 191 67 306 minecraft:prismarine_bricks
fill 191 65 308 191 67 308 minecraft:prismarine_bricks
setblock 192 65 277 minecraft:prismarine_bricks
fill 192 65 279 192 80 279 minecraft:quartz_pillar
fill 192 65 301 192 67 301 minecraft:prismarine_bricks
fill 192 65 303 192 67 303 minecraft:prismarine_bricks
fill 192 65 305 192 67 305 minecraft:prismarine_bricks
fill 192 65 307 192 67 307 minecraft:prismarine_bricks
fill 192 65 309 192 67 309 minecraft:prismarine_bricks
fill 193 65 276 198 65 276 minecraft:dark_prismarine
fill 193 65 278 193 80 278 minecraft:quartz_pillar
fill 193 65 302 193 67 302 minecraft:prismarine_bricks
fill 193 65 304 193 67 304 minecraft:prismarine_bricks
fill 193 65 306 193 67 306 minecraft:prismarine_bricks
fill 193 65 308 193 67 308 minecraft:prismarine_bricks
setblock 194 65 277 minecraft:prismarine_bricks
setblock 194 65 279 minecraft:prismarine_bricks
fill 194 65 301 194 67 301 minecraft:prismarine_bricks
fill 194 65 303 194 67 303 minecraft:prismarine_bricks
fill 194 65 305 194 67 305 minecraft:prismarine_bricks
fill 194 65 307 194 67 307 minecraft:prismarine_bricks
setblock 195 65 278 minecraft:prismarine_bricks
fill 195 65 302 195 67 302 minecraft:prismarine_bricks
fill 195 65 304 195 67 304 minecraft:prismarine_bricks
fill 195 65 306 195 67 306 minecraft:prismarine_bricks
setblock 196 65 277 minecraft:prismarine_bricks
setblock 196 65 279 minecraft:prismarine_bricks
setblock 197 65 278 minecraft:prismarine_bricks
setblock 198 65 277 minecraft:prismarine_bricks
setblock 198 65 279 minecraft:prismarine_bricks
fill 200 65 316 205 65 316 minecraft:dark_prismarine
fill 205 65 276 210 65 276 minecraft:dark_prismarine
setblock 208 65 275 minecraft:dark_prismarine
fill 212 65 316 217 65 316 minecraft:dark_prismarine
fill 217 65 276 222 65 276 minecraft:dark_prismarine
fill 218 65 310 222 65 312 minecraft:gold_block
fill 224 65 316 229 65 316 minecraft:dark_prismarine
setblock 225 65 317 minecraft:prismarine_bricks
setblock 226 65 317 minecraft:dark_prismarine
fill 229 65 276 229 65 281 minecraft:dark_prismarine
fill 229 65 288 229 65 293 minecraft:dark_prismarine
fill 229 65 300 229 65 305 minecraft:dark_prismarine
fill 229 65 312 229 65 315 minecraft:dark_prismarine
fill 188 66 277 188 112 277 minecraft:dark_prismarine
fill 188 66 281 188 71 284 minecraft:sea_lantern
fill 188 66 293 188 71 296 minecraft:sea_lantern
fill 188 66 305 188 71 308 minecraft:sea_lantern
fill 188 66 317 191 71 317 minecraft:sea_lantern
fill 189 66 276 191 118 276 minecraft:prismarine_bricks
fill 189 66 303 189 67 308 minecraft:prismarine_bricks
fill 193 66 277 197 66 277 minecraft:gold_block
fill 194 66 278 197 66 278 minecraft:gold_block
fill 195 66 275 198 71 275 minecraft:sea_lantern
fill 200 66 317 203 71 317 minecraft:sea_lantern
fill 207 66 275 210 71 275 minecraft:sea_lantern
fill 212 66 317 215 71 317 minecraft:sea_lantern
fill 219 66 275 222 71 275 minecraft:sea_lantern
fill 223 66 317 223 71 317 minecraft:dark_prismarine
fill 224 66 317 227 71 317 minecraft:sea_lantern
fill 226 66 275 227 71 275 minecraft:dark_prismarine
setblock 228 66 275 minecraft:sea_lantern
fill 229 66 275 230 81 275 minecraft:dark_prismarine
fill 230 66 276 230 71 279 minecraft:sea_lantern
fill 230 66 288 230 71 291 minecraft:sea_lantern
fill 230 66 300 230 71 303 minecraft:sea_lantern
fill 230 66 312 230 71 315 minecraft:sea_lantern
fill 188 67 309 188 118 310 minecraft:dark_prismarine
setblock 188 67 311 minecraft:sea_lantern
fill 188 67 312 188 124 313 minecraft:dark_prismarine
setblock 188 67 315 minecraft:prismarine_bricks
fill 194 67 277 196 67 278 minecraft:gold_block
fill 228 67 275 228 124 275 minecraft:dark_prismarine
setblock 230 67 280 minecraft:sea_lantern
fill 230 67 281 230 99 282 minecraft:dark_prismarine
setblock 188 68 302 minecraft:prismarine_bricks
fill 188 68 303 188 96 304 minecraft:dark_prismarine
fill 188 68 311 188 126 311 minecraft:dark_prismarine
fill 188 68 315 188 126 315 minecraft:dark_prismarine
fill 190 68 302 192 68 308 minecraft:gold_block
setblock 191 68 285 minecraft:light[level=12]
setblock 191 68 292 minecraft:light[level=12]
setblock 191 68 299 minecraft:light[level=12]
fill 193 68 302 194 68 306 minecraft:gold_block
fill 195 68 276 195 69 279 minecraft:gold_block
setblock 198 68 278 minecraft:light[level=12]
setblock 198 68 285 minecraft:light[level=12]
setblock 198 68 292 minecraft:light[level=12]
setblock 198 68 299 minecraft:light[level=12]
setblock 198 68 306 minecraft:light[level=12]
setblock 198 68 313 minecraft:light[level=12]
setblock 205 68 278 minecraft:light[level=12]
setblock 205 68 285 minecraft:light[level=12]
setblock 205 68 292 minecraft:light[level=12]
setblock 205 68 299 minecraft:light[level=12]
setblock 205 68 306 minecraft:light[level=12]
setblock 205 68 313 minecraft:light[level=12]
setblock 212 68 278 minecraft:light[level=12]
setblock 212 68 285 minecraft:light[level=12]
setblock 212 68 292 minecraft:light[level=12]
setblock 212 68 299 minecraft:light[level=12]
setblock 212 68 306 minecraft:light[level=12]
setblock 212 68 313 minecraft:light[level=12]
setblock 219 68 278 minecraft:light[level=12]
setblock 219 68 285 minecraft:light[level=12]
setblock 219 68 292 minecraft:light[level=12]
setblock 219 68 299 minecraft:light[level=12]
setblock 219 68 306 minecraft:light[level=12]
setblock 219 68 313 minecraft:light[level=12]
setblock 226 68 285 minecraft:light[level=12]
setblock 226 68 292 minecraft:light[level=12]
setblock 226 68 299 minecraft:light[level=12]
setblock 226 68 306 minecraft:light[level=12]
fill 230 68 280 230 126 280 minecraft:dark_prismarine
setblock 188 69 285 minecraft:prismarine_bricks
fill 188 69 286 188 78 287 minecraft:dark_prismarine
fill 188 69 302 188 120 302 minecraft:dark_prismarine
fill 191 69 303 191 69 307 minecraft:gold_block
fill 192 69 303 193 69 305 minecraft:gold_block
setblock 193 69 275 minecraft:sea_lantern
fill 194 69 275 194 126 275 minecraft:dark_prismarine
fill 194 69 276 194 69 280 minecraft:gold_block
fill 195 69 280 196 69 280 minecraft:gold_block
fill 196 69 276 196 69 279 minecraft:gold_block
setblock 203 69 311 minecraft:sea_lantern
fill 188 70 285 188 73 285 minecraft:dark_prismarine
setblock 188 70 288 minecraft:sea_lantern
fill 190 70 304 192 70 306 minecraft:gold_block
setblock 191 70 286 minecraft:light[level=15]
setblock 191 70 294 minecraft:light[level=15]
setblock 191 70 302 minecraft:light[level=15]
setblock 191 70 310 minecraft:light[level=15]
fill 193 70 275 193 123 275 minecraft:dark_prismarine
setblock 199 70 278 minecraft:light[level=15]
setblock 199 70 286 minecraft:light[level=15]
setblock 199 70 294 minecraft:light[level=15]
setblock 199 70 302 minecraft:light[level=15]
setblock 199 70 310 minecraft:light[level=15]
setblock 207 70 278 minecraft:light[level=15]
setblock 207 70 286 minecraft:light[level=15]
setblock 207 70 294 minecraft:light[level=15]
setblock 207 70 302 minecraft:light[level=15]
setblock 207 70 310 minecraft:light[level=15]
setblock 215 70 278 minecraft:light[level=15]
setblock 215 70 286 minecraft:light[level=15]
setblock 215 70 294 minecraft:light[level=15]
setblock 215 70 302 minecraft:light[level=15]
setblock 215 70 310 minecraft:light[level=15]
setblock 223 70 278 minecraft:light[level=15]
setblock 223 70 286 minecraft:light[level=15]
setblock 223 70 294 minecraft:light[level=15]
setblock 223 70 302 minecraft:light[level=15]
setblock 223 70 310 minecraft:light[level=15]
fill 188 71 288 188 91 288 minecraft:dark_prismarine
fill 189 71 305 193 71 305 minecraft:gold_block
fill 191 71 303 193 71 304 minecraft:gold_block
fill 203 71 305 204 72 306 minecraft:white_stained_glass
fill 204 71 307 204 72 307 minecraft:white_stained_glass
setblock 210 71 317 minecraft:prismarine_bricks
fill 211 71 317 211 86 317 minecraft:dark_prismarine
fill 230 71 305 230 73 305 minecraft:dark_prismarine
setblock 230 71 306 minecraft:prismarine_bricks
fill 188 72 281 188 85 281 minecraft:dark_prismarine
fill 188 72 282 188 72 283 minecraft:sea_lantern
fill 188 72 284 188 85 284 minecraft:dark_prismarine
fill 188 72 293 188 85 293 minecraft:dark_prismarine
fill 188 72 294 188 72 295 minecraft:sea_lantern
fill 188 72 296 188 85 296 minecraft:dark_prismarine
fill 188 72 305 188 82 305 minecraft:dark_prismarine
fill 188 72 306 188 72 307 minecraft:sea_lantern
fill 188 72 308 188 85 308 minecraft:dark_prismarine
fill 188 72 317 188 85 317 minecraft:dark_prismarine
fill 189 72 317 190 72 317 minecraft:sea_lantern
fill 191 72 317 191 85 317 minecraft:dark_prismarine
fill 194 72 299 194 73 299 minecraft:white_stained_glass
fill 195 72 275 195 84 275 minecraft:dark_prismarine
fill 196 72 275 197 72 275 minecraft:sea_lantern
fill 198 72 275 198 85 275 minecraft:dark_prismarine
fill 200 72 317 200 85 317 minecraft:dark_prismarine
setblock 201 72 275 minecraft:sea_lantern
fill 201 72 317 202 72 317 minecraft:sea_lantern
setblock 203 72 275 minecraft:prismarine_bricks
fill 203 72 317 203 85 317 minecraft:dark_prismarine
fill 204 72 275 207 80 275 minecraft:dark_prismarine
fill 208 72 275 209 72 275 minecraft:sea_lantern
fill 210 72 275 210 85 275 minecraft:dark_prismarine
fill 210 72 317 210 99 317 minecraft:dark_prismarine
fill 212 72 317 212 85 317 minecraft:dark_prismarine
fill 213 72 317 214 72 317 minecraft:sea_lantern
fill 215 72 317 215 85 317 minecraft:dark_prismarine
fill 219 72 275 219 85 275 minecraft:dark_prismarine
fill 220 72 275 221 72 275 minecraft:sea_lantern
fill 221 72 292 222 73 293 minecraft:white_stained_glass
fill 222 72 275 222 85 275 minecraft:dark_prismarine
setblock 223 72 317 minecraft:sea_lantern
fill 224 72 317 224 85 317 minecraft:dark_prismarine
fill 225 72 317 226 72 317 minecraft:sea_lantern
fill 226 72 275 226 116 275 minecraft:dark_prismarine
setblock 227 72 275 minecraft:sea_lantern
fill 227 72 317 227 85 317 minecraft:dark_prismarine
fill 230 72 276 230 85 276 minecraft:dark_prismarine
fill 230 72 277 230 72 278 minecraft:sea_lantern
fill 230 72 279 230 85 279 minecraft:dark_prismarine
fill 230 72 288 230 85 288 minecraft:dark_prismarine
fill 230 72 289 230 72 290 minecraft:sea_lantern
fill 230 72 291 230 85 291 minecraft:dark_prismarine
fill 230 72 300 230 85 300 minecraft:dark_prismarine
fill 230 72 301 230 72 302 minecraft:sea_lantern
fill 230 72 303 230 85 303 minecraft:dark_prismarine
fill 230 72 306 230 100 306 minecraft:dark_prismarine
fill 230 72 312 230 85 312 minecraft:dark_prismarine
fill 230 72 313 230 72 314 minecraft:sea_lantern
fill 230 72 315 230 85 315 minecraft:dark_prismarine
fill 188 73 282 188 85 283 minecraft:dark_prismarine
fill 188 73 294 188 85 295 minecraft:dark_prismarine
fill 188 73 306 188 81 307 minecraft:dark_prismarine
setblock 188 73 316 minecraft:prismarine_bricks
fill 189 73 317 190 74 317 minecraft:dark_prismarine
fill 196 73 275 197 85 275 minecraft:dark_prismarine
fill 201 73 275 201 123 275 minecraft:dark_prismarine
fill 201 73 317 202 85 317 minecraft:dark_prismarine
fill 203 73 275 203 126 275 minecraft:dark_prismarine
fill 208 73 275 209 85 275 minecraft:dark_prismarine
fill 213 73 317 214 84 317 minecraft:dark_prismarine
fill 216 73 317 219 123 317 minecraft:dark_prismarine
setblock 217 73 275 minecraft:sea_lantern
fill 218 73 275 218 113 275 minecraft:dark_prismarine
fill 220 73 275 221 85 275 minecraft:dark_prismarine
setblock 220 73 317 minecraft:prismarine_bricks
fill 221 73 317 223 101 317 minecraft:dark_prismarine
fill 225 73 317 226 85 317 minecraft:dark_prismarine
fill 227 73 275 227 106 275 minecraft:dark_prismarine
fill 230 73 277 230 73 278 minecraft:dark_prismarine
fill 230 73 289 230 85 290 minecraft:dark_prismarine
fill 230 73 301 230 74 302 minecraft:dark_prismarine
fill 230 73 313 230 85 314 minecraft:dark_prismarine
setblock 188 74 285 minecraft:prismarine_bricks
fill 188 74 316 188 91 316 minecraft:dark_prismarine
setblock 191 74 285 minecraft:light[level=12]
setblock 191 74 292 minecraft:light[level=12]
setblock 191 74 299 minecraft:light[level=12]
setblock 191 74 306 minecraft:light[level=12]
setblock 198 74 278 minecraft:light[level=12]
setblock 198 74 285 minecraft:light[level=12]
setblock 198 74 292 minecraft:light[level=12]
setblock 198 74 299 minecraft:light[level=12]
setblock 198 74 306 minecraft:light[level=12]
setblock 198 74 313 minecraft:light[level=12]
setblock 205 74 278 minecraft:light[level=12]
setblock 205 74 285 minecraft:light[level=12]
setblock 205 74 292 minecraft:light[level=12]
setblock 205 74 299 minecraft:light[level=12]
setblock 205 74 306 minecraft:light[level=12]
setblock 205 74 313 minecraft:light[level=12]
setblock 212 74 278 minecraft:light[level=12]
setblock 212 74 285 minecraft:light[level=12]
setblock 212 74 292 minecraft:light[level=12]
setblock 212 74 299 minecraft:light[level=12]
setblock 212 74 306 minecraft:light[level=12]
setblock 212 74 313 minecraft:light[level=12]
fill 217 74 275 217 124 275 minecraft:dark_prismarine
setblock 219 74 278 minecraft:light[level=12]
setblock 219 74 285 minecraft:light[level=12]
setblock 219 74 292 minecraft:light[level=12]
setblock 219 74 299 minecraft:light[level=12]
setblock 219 74 306 minecraft:light[level=12]
setblock 219 74 313 minecraft:light[level=12]
fill 220 74 317 220 81 317 minecraft:dark_prismarine
setblock 226 74 285 minecraft:light[level=12]
setblock 226 74 292 minecraft:light[level=12]
setblock 226 74 299 minecraft:light[level=12]
setblock 226 74 306 minecraft:light[level=12]
setblock 230 74 277 minecraft:prismarine_bricks
fill 230 74 278 230 85 278 minecraft:dark_prismarine
setblock 230 74 305 minecraft:sea_lantern
fill 188 75 285 188 126 285 minecraft:dark_prismarine
fill 189 75 317 189 85 317 minecraft:dark_prismarine
setblock 190 75 317 minecraft:prismarine_bricks
fill 210 75 282 211 76 282 minecraft:white_stained_glass
fill 230 75 277 230 82 277 minecraft:dark_prismarine
setblock 230 75 301 minecraft:prismarine_bricks
fill 230 75 302 230 85 302 minecraft:dark_prismarine
fill 230 75 305 230 126 305 minecraft:dark_prismarine
setblock 230 75 316 minecraft:prismarine_bricks
fill 190 76 317 190 78 317 minecraft:dark_prismarine
fill 193 76 317 195 76 317 minecraft:dark_prismarine
setblock 196 76 317 minecraft:prismarine_bricks
fill 197 76 317 197 99 317 minecraft:dark_prismarine
fill 230 76 301 230 85 301 minecraft:dark_prismarine
fill 230 76 316 230 126 316 minecraft:dark_prismarine
fill 193 77 317 193 90 317 minecraft:dark_prismarine
setblock 194 77 317 minecraft:prismarine_bricks
fill 195 77 317 196 126 317 minecraft:dark_prismarine
setblock 191 78 286 minecraft:light[level=15]
setblock 191 78 294 minecraft:light[level=15]
setblock 191 78 302 minecraft:light[level=15]
setblock 191 78 310 minecraft:light[level=15]
fill 194 78 317 194 84 317 minecraft:dark_prismarine
setblock 199 78 278 minecraft:light[level=15]
setblock 199 78 286 minecraft:light[level=15]
setblock 199 78 294 minecraft:light[level=15]
setblock 199 78 302 minecraft:light[level=15]
setblock 199 78 310 minecraft:light[level=15]
setblock 207 78 278 minecraft:light[level=15]
setblock 207 78 286 minecraft:light[level=15]
setblock 207 78 294 minecraft:light[level=15]
setblock 207 78 302 minecraft:light[level=15]
setblock 207 78 310 minecraft:light[level=15]
fill 212 78 314 214 79 314 minecraft:light_blue_stained_glass
fill 213 78 313 213 79 313 minecraft:light_blue_stained_glass
fill 213 78 315 213 79 315 minecraft:light_blue_stained_glass
setblock 215 78 278 minecraft:light[level=15]
setblock 215 78 286 minecraft:light[level=15]
setblock 215 78 294 minecraft:light[level=15]
setblock 215 78 302 minecraft:light[level=15]
setblock 215 78 310 minecraft:light[level=15]
setblock 223 78 278 minecraft:light[level=15]
setblock 223 78 286 minecraft:light[level=15]
setblock 223 78 294 minecraft:light[level=15]
setblock 223 78 302 minecraft:light[level=15]
setblock 223 78 310 minecraft:light[level=15]
setblock 188 79 286 minecraft:prismarine_bricks
fill 188 79 287 188 126 287 minecraft:dark_prismarine
setblock 190 79 317 minecraft:prismarine_bricks
setblock 230 79 285 minecraft:sea_lantern
fill 230 79 286 230 100 286 minecraft:dark_prismarine
fill 188 80 286 188 122 286 minecraft:dark_prismarine
fill 188 80 297 188 115 299 minecraft:dark_prismarine
setblock 188 80 300 minecraft:sea_lantern
fill 190 80 285 190 85 287 minecraft:prismarine_bricks
fill 190 80 298 190 85 299 minecraft:prismarine_bricks
fill 190 80 309 190 85 311 minecraft:prismarine_bricks
fill 190 80 317 190 85 317 minecraft:dark_prismarine
setblock 191 80 285 minecraft:light[level=12]
setblock 191 80 292 minecraft:light[level=12]
setblock 191 80 299 minecraft:light[level=12]
setblock 191 80 306 minecraft:light[level=12]
fill 196 80 315 198 85 315 minecraft:prismarine_bricks
setblock 198 80 278 minecraft:light[level=12]
setblock 198 80 285 minecraft:light[level=12]
setblock 198 80 292 minecraft:light[level=12]
setblock 198 80 299 minecraft:light[level=12]
setblock 198 80 306 minecraft:light[level=12]
setblock 198 80 313 minecraft:light[level=12]
fill 200 80 277 202 85 277 minecraft:prismarine_bricks
setblock 205 80 278 minecraft:light[level=12]
setblock 205 80 285 minecraft:light[level=12]
setblock 205 80 292 minecraft:light[level=12]
setblock 205 80 299 minecraft:light[level=12]
setblock 205 80 306 minecraft:light[level=12]
setblock 205 80 313 minecraft:light[level=12]
fill 212 80 277 214 85 277 minecraft:prismarine_bricks
setblock 212 80 278 minecraft:light[level=12]
setblock 212 80 285 minecraft:light[level=12]
setblock 212 80 292 minecraft:light[level=12]
setblock 212 80 299 minecraft:light[level=12]
setblock 212 80 306 minecraft:light[level=12]
setblock 212 80 313 minecraft:light[level=12]
setblock 215 80 275 minecraft:prismarine_bricks
setblock 219 80 278 minecraft:light[level=12]
setblock 219 80 285 minecraft:light[level=12]
setblock 219 80 292 minecraft:light[level=12]
setblock 219 80 299 minecraft:light[level=12]
setblock 219 80 306 minecraft:light[level=12]
setblock 219 80 313 minecraft:light[level=12]
fill 220 80 315 222 85 315 minecraft:prismarine_bricks
fill 224 80 277 226 85 277 minecraft:prismarine_bricks
setblock 226 80 285 minecraft:light[level=12]
setblock 226 80 292 minecraft:light[level=12]
setblock 226 80 299 minecraft:light[level=12]
setblock 226 80 306 minecraft:light[level=12]
fill 228 80 285 228 85 287 minecraft:prismarine_bricks
fill 228 80 298 228 85 299 minecraft:prismarine_bricks
fill 228 80 309 228 85 311 minecraft:prismarine_bricks
fill 230 80 285 230 100 285 minecraft:dark_prismarine
fill 188 81 300 188 94 300 minecraft:dark_prismarine
fill 189 81 296 193 82 296 minecraft:prismarine_bricks
fill 190 81 279 194 82 279 minecraft:prismarine_bricks
fill 190 81 295 192 82 295 minecraft:prismarine_bricks
fill 190 81 297 192 82 297 minecraft:prismarine_bricks
fill 190 81 313 194 82 313 minecraft:prismarine_bricks
fill 191 81 278 193 82 278 minecraft:prismarine_bricks
fill 191 81 280 193 82 280 minecraft:prismarine_bricks
fill 191 81 294 191 82 294 minecraft:prismarine_bricks
fill 191 81 298 191 82 298 minecraft:prismarine_bricks
fill 191 81 312 193 82 312 minecraft:prismarine_bricks
fill 191 81 314 193 82 314 minecraft:prismarine_bricks
fill 192 81 277 192 82 277 minecraft:prismarine_bricks
fill 192 81 281 192 82 281 minecraft:prismarine_bricks
fill 192 81 311 192 82 311 minecraft:prismarine_bricks
fill 192 81 315 192 82 315 minecraft:prismarine_bricks
fill 204 81 275 205 126 275 minecraft:dark_prismarine
setblock 206 81 275 minecraft:sea_lantern
fill 207 81 275 207 85 275 minecraft:dark_prismarine
fill 207 81 278 211 82 278 minecraft:prismarine_bricks
fill 207 81 314 211 82 314 minecraft:prismarine_bricks
fill 208 81 277 210 82 277 minecraft:prismarine_bricks
fill 208 81 279 210 82 279 minecraft:prismarine_bricks
fill 208 81 313 210 82 313 minecraft:prismarine_bricks
fill 208 81 315 210 82 315 minecraft:prismarine_bricks
fill 209 81 276 209 82 276 minecraft:prismarine_bricks
fill 209 81 280 209 82 280 minecraft:prismarine_bricks
fill 209 81 312 209 82 312 minecraft:prismarine_bricks
fill 215 81 275 215 122 275 minecraft:dark_prismarine
fill 220 81 287 221 82 289 minecraft:white_stained_glass
fill 224 81 279 228 82 279 minecraft:prismarine_bricks
fill 224 81 313 228 82 313 minecraft:prismarine_bricks
fill 225 81 278 227 82 278 minecraft:prismarine_bricks
fill 225 81 280 227 82 280 minecraft:prismarine_bricks
fill 225 81 296 228 82 296 minecraft:prismarine_bricks
fill 225 81 312 227 82 312 minecraft:prismarine_bricks
fill 225 81 314 227 82 314 minecraft:prismarine_bricks
fill 226 81 281 226 82 281 minecraft:prismarine_bricks
fill 226 81 295 228 82 295 minecraft:prismarine_bricks
fill 226 81 297 228 82 297 minecraft:prismarine_bricks
fill 226 81 311 226 82 311 minecraft:prismarine_bricks
fill 226 81 315 226 82 315 minecraft:prismarine_bricks
fill 227 81 294 227 82 294 minecraft:prismarine_bricks
fill 227 81 298 227 82 298 minecraft:prismarine_bricks
setblock 188 82 306 minecraft:sea_lantern
fill 188 82 307 188 85 307 minecraft:dark_prismarine
fill 206 82 275 206 124 275 minecraft:dark_prismarine
setblock 220 82 317 minecraft:sea_lantern
setblock 229 82 275 minecraft:prismarine_bricks
fill 230 82 275 230 124 275 minecraft:dark_prismarine
fill 188 83 289 188 126 289 minecraft:dark_prismarine
setblock 188 83 290 minecraft:prismarine_bricks
fill 188 83 291 188 114 292 minecraft:dark_prismarine
setblock 188 83 305 minecraft:sea_lantern
fill 188 83 306 188 85 306 minecraft:dark_prismarine
fill 190 83 295 192 110 297 minecraft:quartz_pillar
fill 191 83 278 193 110 280 minecraft:quartz_pillar
fill 191 83 312 193 110 314 minecraft:quartz_pillar
fill 208 83 277 210 110 279 minecraft:quartz_pillar
fill 208 83 313 210 110 315 minecraft:quartz_pillar
fill 220 83 317 220 126 317 minecraft:dark_prismarine
fill 225 83 278 227 110 280 minecraft:quartz_pillar
fill 225 83 312 227 110 314 minecraft:quartz_pillar
fill 226 83 295 228 110 297 minecraft:quartz_pillar
fill 229 83 275 229 127 275 minecraft:dark_prismarine
setblock 230 83 277 minecraft:sea_lantern
setblock 188 84 278 minecraft:prismarine_bricks
fill 188 84 290 188 126 290 minecraft:dark_prismarine
fill 188 84 305 188 85 305 minecraft:dark_prismarine
setblock 199 84 317 minecraft:prismarine_bricks
fill 230 84 277 230 85 277 minecraft:dark_prismarine
fill 188 85 278 188 126 278 minecraft:dark_prismarine
fill 189 85 279 189 85 284 minecraft:dark_prismarine
fill 189 85 291 189 85 296 minecraft:dark_prismarine
fill 189 85 303 189 85 308 minecraft:dark_prismarine
fill 189 85 315 189 85 316 minecraft:dark_prismarine
fill 190 85 316 193 85 316 minecraft:dark_prismarine
fill 193 85 276 198 85 276 minecraft:dark_prismarine
setblock 194 85 317 minecraft:prismarine_bricks
fill 195 85 275 195 91 275 minecraft:sea_lantern
fill 199 85 317 199 126 317 minecraft:dark_prismarine
fill 200 85 316 205 85 316 minecraft:dark_prismarine
fill 205 85 276 210 85 276 minecraft:dark_prismarine
fill 212 85 316 217 85 316 minecraft:dark_prismarine
setblock 213 85 317 minecraft:dark_prismarine
fill 214 85 317 214 92 317 minecraft:sea_lantern
fill 217 85 276 222 85 276 minecraft:dark_prismarine
fill 224 85 316 229 85 316 minecraft:dark_prismarine
fill 229 85 276 229 85 281 minecraft:dark_prismarine
fill 229 85 288 229 85 293 minecraft:dark_prismarine
fill 229 85 300 229 85 305 minecraft:dark_prismarine
fill 229 85 312 229 85 315 minecraft:dark_prismarine
fill 188 86 281 188 91 284 minecraft:sea_lantern
fill 188 86 293 188 91 296 minecraft:sea_lantern
fill 188 86 305 188 91 308 minecraft:sea_lantern
fill 188 86 317 191 91 317 minecraft:sea_lantern
setblock 191 86 285 minecraft:light[level=12]
setblock 191 86 286 minecraft:light[level=15]
setblock 191 86 292 minecraft:light[level=12]
setblock 191 86 294 minecraft:light[level=15]
setblock 191 86 299 minecraft:light[level=12]
setblock 191 86 302 minecraft:light[level=15]
setblock 191 86 306 minecraft:light[level=12]
setblock 191 86 310 minecraft:light[level=15]
fill 194 86 317 194 126 317 minecraft:dark_prismarine
fill 196 86 275 198 91 275 minecraft:sea_lantern
fill 196 86 308 197 87 308 minecraft:light_blue_stained_glass
fill 197 86 309 197 87 309 minecraft:light_blue_stained_glass
setblock 198 86 278 minecraft:light[level=12]
setblock 198 86 285 minecraft:light[level=12]
setblock 198 86 292 minecraft:light[level=12]
setblock 198 86 299 minecraft:light[level=12]
setblock 198 86 306 minecraft:light[level=12]
setblock 198 86 313 minecraft:light[level=12]
setblock 199 86 278 minecraft:light[level=15]
setblock 199 86 286 minecraft:light[level=15]
setblock 199 86 294 minecraft:light[level=15]
setblock 199 86 302 minecraft:light[level=15]
setblock 199 86 310 minecraft:light[level=15]
fill 200 86 317 203 91 317 minecraft:sea_lantern
setblock 205 86 278 minecraft:light[level=12]
setblock 205 86 285 minecraft:light[level=12]
setblock 205 86 292 minecraft:light[level=12]
setblock 205 86 299 minecraft:light[level=12]
setblock 205 86 306 minecraft:light[level=12]
setblock 205 86 313 minecraft:light[level=12]
fill 207 86 275 210 91 275 minecraft:sea_lantern
setblock 207 86 278 minecraft:light[level=15]
setblock 207 86 286 minecraft:light[level=15]
setblock 207 86 294 minecraft:light[level=15]
setblock 207 86 302 minecraft:light[level=15]
setblock 207 86 310 minecraft:light[level=15]
setblock 212 86 278 minecraft:light[level=12]
setblock 212 86 285 minecraft:light[level=12]
setblock 212 86 292 minecraft:light[level=12]
setblock 212 86 299 minecraft:light[level=12]
setblock 212 86 306 minecraft:light[level=12]
setblock 212 86 313 minecraft:light[level=12]
fill 212 86 317 213 91 317 minecraft:sea_lantern
setblock 215 86 278 minecraft:light[level=15]
setblock 215 86 286 minecraft:light[level=15]
setblock 215 86 294 minecraft:light[level=15]
setblock 215 86 302 minecraft:light[level=15]
setblock 215 86 310 minecraft:light[level=15]
fill 215 86 317 215 91 317 minecraft:sea_lantern
fill 219 86 275 222 91 275 minecraft:sea_lantern
setblock 219 86 278 minecraft:light[level=12]
setblock 219 86 285 minecraft:light[level=12]
setblock 219 86 292 minecraft:light[level=12]
setblock 219 86 299 minecraft:light[level=12]
setblock 219 86 306 minecraft:light[level=12]
setblock 219 86 313 minecraft:light[level=12]
setblock 223 86 278 minecraft:light[level=15]
setblock 223 86 286 minecraft:light[level=15]
setblock 223 86 294 minecraft:light[level=15]
setblock 223 86 302 minecraft:light[level=15]
setblock 223 86 310 minecraft:light[level=15]
fill 224 86 317 227 91 317 minecraft:sea_lantern
setblock 226 86 285 minecraft:light[level=12]
setblock 226 86 292 minecraft:light[level=12]
setblock 226 86 299 minecraft:light[level=12]
setblock 226 86 306 minecraft:light[level=12]
fill 230 86 276 230 91 279 minecraft:sea_lantern
fill 230 86 288 230 91 291 minecraft:sea_lantern
fill 230 86 300 230 91 303 minecraft:sea_lantern
fill 230 86 312 230 91 315 minecraft:sea_lantern
setblock 211 87 317 minecraft:prismarine_bricks
setblock 230 87 295 minecraft:prismarine_bricks
fill 230 87 296 230 124 296 minecraft:dark_prismarine
fill 211 88 317 211 126 317 minecraft:dark_prismarine
fill 230 88 283 230 123 283 minecraft:dark_prismarine
setblock 230 88 284 minecraft:sea_lantern
fill 230 88 295 230 127 295 minecraft:dark_prismarine
fill 230 89 284 230 126 284 minecraft:dark_prismarine
setblock 193 91 317 minecraft:sea_lantern
setblock 188 92 279 minecraft:prismarine_bricks
fill 188 92 281 188 105 281 minecraft:dark_prismarine
fill 188 92 282 188 92 283 minecraft:sea_lantern
fill 188 92 284 188 105 284 minecraft:dark_prismarine
setblock 188 92 288 minecraft:sea_lantern
fill 188 92 293 188 105 293 minecraft:dark_prismarine
fill 188 92 294 188 92 295 minecraft:sea_lantern
fill 188 92 296 188 105 296 minecraft:dark_prismarine
fill 188 92 305 188 105 305 minecraft:dark_prismarine
fill 188 92 306 188 92 307 minecraft:sea_lantern
fill 188 92 308 188 105 308 minecraft:dark_prismarine
setblock 188 92 316 minecraft:prismarine_bricks
fill 188 92 317 188 105 317 minecraft:dark_prismarine
fill 189 92 317 190 92 317 minecraft:sea_lantern
setblock 191 92 285 minecraft:light[level=12]
setblock 191 92 292 minecraft:light[level=12]
setblock 191 92 299 minecraft:light[level=12]
setblock 191 92 306 minecraft:light[level=12]
fill 191 92 317 191 105 317 minecraft:dark_prismarine
fill 193 92 317 193 126 317 minecraft:dark_prismarine
fill 195 92 275 195 105 275 minecraft:dark_prismarine
fill 196 92 275 197 92 275 minecraft:sea_lantern
fill 196 92 296 196 93 296 minecraft:white_stained_glass
setblock 198 92 275 minecraft:prismarine_bricks
setblock 198 92 278 minecraft:light[level=12]
setblock 198 92 285 minecraft:light[level=12]
setblock 198 92 292 minecraft:light[level=12]
setblock 198 92 299 minecraft:light[level=12]
setblock 198 92 306 minecraft:light[level=12]
setblock 198 92 313 minecraft:light[level=12]
fill 200 92 317 200 95 317 minecraft:dark_prismarine
fill 201 92 317 202 92 317 minecraft:sea_lantern
fill 203 92 317 203 105 317 minecraft:dark_prismarine
setblock 205 92 278 minecraft:light[level=12]
setblock 205 92 285 minecraft:light[level=12]
setblock 205 92 292 minecraft:light[level=12]
setblock 205 92 299 minecraft:light[level=12]
setblock 205 92 306 minecraft:light[level=12]
setblock 205 92 313 minecraft:light[level=12]
fill 207 92 275 207 105 275 minecraft:dark_prismarine
fill 208 92 275 209 92 275 minecraft:sea_lantern
fill 210 92 275 210 105 275 minecraft:dark_prismarine
setblock 212 92 278 minecraft:light[level=12]
setblock 212 92 285 minecraft:light[level=12]
setblock 212 92 292 minecraft:light[level=12]
setblock 212 92 299 minecraft:light[level=12]
setblock 212 92 306 minecraft:light[level=12]
setblock 212 92 313 minecraft:light[level=12]
fill 212 92 317 212 103 317 minecraft:dark_prismarine
setblock 213 92 317 minecraft:sea_lantern
fill 215 92 317 215 105 317 minecraft:dark_prismarine
fill 219 92 275 219 105 275 minecraft:dark_prismarine
setblock 219 92 278 minecraft:light[level=12]
setblock 219 92 285 minecraft:light[level=12]
setblock 219 92 292 minecraft:light[level=12]
setblock 219 92 299 minecraft:light[level=12]
setblock 219 92 306 minecraft:light[level=12]
setblock 219 92 313 minecraft:light[level=12]
fill 220 92 275 221 92 275 minecraft:sea_lantern
fill 222 92 275 222 105 275 minecraft:dark_prismarine
fill 224 92 317 224 105 317 minecraft:dark_prismarine
fill 225 92 317 226 92 317 minecraft:sea_lantern
setblock 226 92 285 minecraft:light[level=12]
setblock 226 92 292 minecraft:light[level=12]
setblock 226 92 299 minecraft:light[level=12]
setblock 226 92 306 minecraft:light[level=12]
fill 227 92 317 227 105 317 minecraft:dark_prismarine
fill 230 92 276 230 105 276 minecraft:dark_prismarine
fill 230 92 277 230 92 278 minecraft:sea_lantern
fill 230 92 279 230 105 279 minecraft:dark_prismarine
fill 230 92 288 230 103 288 minecraft:dark_prismarine
fill 230 92 289 230 92 290 minecraft:sea_lantern
fill 230 92 291 230 105 291 minecraft:dark_prismarine
fill 230 92 300 230 105 300 minecraft:dark_prismarine
fill 230 92 301 230 92 302 minecraft:sea_lantern
fill 230 92 303 230 105 303 minecraft:dark_prismarine
setblock 230 92 311 minecraft:sea_lantern
fill 230 92 312 230 105 312 minecraft:dark_prismarine
fill 230 92 313 230 92 314 minecraft:sea_lantern
fill 230 92 315 230 105 315 minecraft:dark_prismarine
fill 188 93 279 188 124 279 minecraft:dark_prismarine
fill 188 93 282 188 105 283 minecraft:dark_prismarine
fill 188 93 288 188 126 288 minecraft:dark_prismarine
fill 188 93 294 188 94 295 minecraft:dark_prismarine
fill 188 93 306 188 105 307 minecraft:dark_prismarine
fill 188 93 316 188 126 316 minecraft:dark_prismarine
fill 189 93 317 190 105 317 minecraft:dark_prismarine
fill 196 93 275 198 105 275 minecraft:dark_prismarine
fill 201 93 317 202 105 317 minecraft:dark_prismarine
fill 208 93 275 209 105 275 minecraft:dark_prismarine
fill 213 93 317 214 105 317 minecraft:dark_prismarine
fill 220 93 275 221 105 275 minecraft:dark_prismarine
fill 225 93 317 226 97 317 minecraft:dark_prismarine
fill 230 93 277 230 105 278 minecraft:dark_prismarine
fill 230 93 289 230 105 290 minecraft:dark_prismarine
fill 230 93 301 230 105 302 minecraft:dark_prismarine
fill 230 93 311 230 126 311 minecraft:dark_prismarine
fill 230 93 313 230 105 314 minecraft:dark_prismarine
setblock 191 94 286 minecraft:light[level=15]
setblock 191 94 294 minecraft:light[level=15]
setblock 191 94 302 minecraft:light[level=15]
setblock 191 94 310 minecraft:light[level=15]
setblock 199 94 278 minecraft:light[level=15]
setblock 199 94 286 minecraft:light[level=15]
setblock 199 94 294 minecraft:light[level=15]
setblock 199 94 302 minecraft:light[level=15]
setblock 199 94 310 minecraft:light[level=15]
fill 204 94 281 204 95 281 minecraft:dark_prismarine
setblock 207 94 278 minecraft:light[level=15]
setblock 207 94 286 minecraft:light[level=15]
setblock 207 94 294 minecraft:light[level=15]
setblock 207 94 302 minecraft:light[level=15]
setblock 207 94 310 minecraft:light[level=15]
setblock 215 94 278 minecraft:light[level=15]
setblock 215 94 286 minecraft:light[level=15]
setblock 215 94 294 minecraft:light[level=15]
setblock 215 94 302 minecraft:light[level=15]
setblock 215 94 310 minecraft:light[level=15]
fill 218 94 297 218 95 298 minecraft:light_blue_stained_glass
setblock 223 94 278 minecraft:light[level=15]
fill 223 94 280 223 95 280 minecraft:dark_prismarine
setblock 223 94 286 minecraft:light[level=15]
fill 223 94 287 223 95 287 minecraft:dark_prismarine
setblock 223 94 294 minecraft:light[level=15]
setblock 223 94 302 minecraft:light[level=15]
fill 223 94 303 223 95 303 minecraft:dark_prismarine
setblock 223 94 310 minecraft:light[level=15]
setblock 230 94 298 minecraft:sea_lantern
setblock 188 95 294 minecraft:sea_lantern
fill 188 95 295 188 105 295 minecraft:dark_prismarine
setblock 188 95 300 minecraft:prismarine_bricks
fill 204 95 280 204 96 280 minecraft:dark_prismarine
fill 222 95 288 226 96 292 minecraft:dark_prismarine
fill 224 95 280 224 96 280 minecraft:dark_prismarine
fill 224 95 287 224 96 287 minecraft:dark_prismarine
fill 224 95 303 224 96 303 minecraft:dark_prismarine
fill 227 95 290 228 95 290 minecraft:dark_prismarine
fill 230 95 298 230 126 298 minecraft:dark_prismarine
fill 188 96 294 188 105 294 minecraft:dark_prismarine
fill 188 96 300 188 117 300 minecraft:dark_prismarine
setblock 191 96 275 minecraft:prismarine_bricks
setblock 200 96 317 minecraft:prismarine_bricks
fill 204 96 279 204 97 279 minecraft:dark_prismarine
fill 225 96 287 225 97 287 minecraft:dark_prismarine
fill 225 96 303 225 97 303 minecraft:dark_prismarine
setblock 188 97 303 minecraft:sea_lantern
fill 188 97 304 188 124 304 minecraft:dark_prismarine
fill 191 97 275 191 126 275 minecraft:dark_prismarine
fill 200 97 317 200 105 317 minecraft:dark_prismarine
fill 204 97 278 204 98 278 minecraft:dark_prismarine
setblock 212 97 275 minecraft:prismarine_bricks
fill 213 97 275 213 127 275 minecraft:dark_prismarine
fill 223 97 289 225 98 291 minecraft:prismarine_bricks
setblock 224 97 275 minecraft:prismarine_bricks
fill 226 97 287 226 98 287 minecraft:dark_prismarine
fill 226 97 303 226 98 303 minecraft:dark_prismarine
fill 188 98 303 188 123 303 minecraft:dark_prismarine
setblock 191 98 285 minecraft:light[level=12]
setblock 191 98 292 minecraft:light[level=12]
setblock 191 98 299 minecraft:light[level=12]
setblock 191 98 306 minecraft:light[level=12]
setblock 198 98 278 minecraft:light[level=12]
setblock 198 98 285 minecraft:light[level=12]
setblock 198 98 292 minecraft:light[level=12]
setblock 198 98 299 minecraft:light[level=12]
setblock 198 98 306 minecraft:light[level=12]
setblock 198 98 313 minecraft:light[level=12]
fill 204 98 277 204 99 277 minecraft:dark_prismarine
setblock 205 98 278 minecraft:light[level=12]
setblock 205 98 285 minecraft:light[level=12]
setblock 205 98 292 minecraft:light[level=12]
setblock 205 98 299 minecraft:light[level=12]
setblock 205 98 306 minecraft:light[level=12]
setblock 205 98 313 minecraft:light[level=12]
fill 212 98 275 212 126 275 minecraft:dark_prismarine
setblock 212 98 278 minecraft:light[level=12]
setblock 212 98 285 minecraft:light[level=12]
setblock 212 98 292 minecraft:light[level=12]
setblock 212 98 299 minecraft:light[level=12]
setblock 212 98 306 minecraft:light[level=12]
setblock 212 98 313 minecraft:light[level=12]
fill 214 98 290 215 99 291 minecraft:light_blue_stained_glass
fill 215 98 289 215 99 289 minecraft:light_blue_stained_glass
setblock 219 98 278 minecraft:light[level=12]
setblock 219 98 285 minecraft:light[level=12]
setblock 219 98 292 minecraft:light[level=12]
setblock 219 98 299 minecraft:light[level=12]
setblock 219 98 306 minecraft:light[level=12]
setblock 219 98 313 minecraft:light[level=12]
setblock 223 98 275 minecraft:prismarine_bricks
fill 224 98 275 224 126 275 minecraft:dark_prismarine
fill 225 98 317 225 105 317 minecraft:dark_prismarine
setblock 226 98 285 minecraft:light[level=12]
setblock 226 98 292 minecraft:light[level=12]
setblock 226 98 299 minecraft:light[level=12]
setblock 226 98 306 minecraft:light[level=12]
setblock 226 98 317 minecraft:sea_lantern
fill 227 98 287 227 99 287 minecraft:dark_prismarine
fill 227 98 303 227 99 303 minecraft:dark_prismarine
fill 204 99 276 204 100 276 minecraft:dark_prismarine
fill 223 99 275 223 126 275 minecraft:dark_prismarine
fill 223 99 290 225 101 290 minecraft:prismarine_bricks
fill 224 99 289 224 101 289 minecraft:prismarine_bricks
fill 224 99 291 224 101 291 minecraft:prismarine_bricks
fill 226 99 317 226 105 317 minecraft:dark_prismarine
fill 228 99 280 228 100 280 minecraft:dark_prismarine
setblock 228 99 287 minecraft:dark_prismarine
fill 228 99 303 228 100 303 minecraft:dark_prismarine
setblock 230 99 304 minecraft:sea_lantern
fill 190 100 285 190 105 287 minecraft:prismarine_bricks
fill 190 100 298 190 105 299 minecraft:prismarine_bricks
fill 190 100 309 190 105 311 minecraft:prismarine_bricks
setblock 194 100 281 minecraft:sea_lantern
setblock 194 100 287 minecraft:sea_lantern
setblock 194 100 293 minecraft:sea_lantern
setblock 194 100 299 minecraft:sea_lantern
setblock 194 100 305 minecraft:sea_lantern
setblock 194 100 311 minecraft:sea_lantern
fill 196 100 315 198 105 315 minecraft:prismarine_bricks
setblock 197 100 317 minecraft:prismarine_bricks
fill 200 100 277 202 105 277 minecraft:prismarine_bricks
setblock 200 100 281 minecraft:sea_lantern
setblock 200 100 311 minecraft:sea_lantern
setblock 206 100 281 minecraft:sea_lantern
setblock 206 100 311 minecraft:sea_lantern
setblock 210 100 317 minecraft:prismarine_bricks
fill 212 100 277 214 105 277 minecraft:prismarine_bricks
setblock 212 100 281 minecraft:sea_lantern
setblock 212 100 311 minecraft:sea_lantern
setblock 218 100 281 minecraft:sea_lantern
setblock 218 100 311 minecraft:sea_lantern
fill 220 100 315 222 105 315 minecraft:prismarine_bricks
fill 222 100 289 223 101 289 minecraft:white_stained_glass
fill 224 100 277 226 105 277 minecraft:prismarine_bricks
setblock 224 100 281 minecraft:sea_lantern
setblock 224 100 287 minecraft:sea_lantern
setblock 224 100 293 minecraft:sea_lantern
setblock 224 100 299 minecraft:sea_lantern
setblock 224 100 305 minecraft:sea_lantern
setblock 224 100 311 minecraft:sea_lantern
fill 228 100 285 228 105 287 minecraft:prismarine_bricks
fill 228 100 298 228 105 299 minecraft:prismarine_bricks
fill 228 100 309 228 105 311 minecraft:prismarine_bricks
setblock 230 100 281 minecraft:prismarine_bricks
fill 230 100 282 230 101 282 minecraft:dark_prismarine
fill 230 100 304 230 126 304 minecraft:dark_prismarine
fill 188 101 301 194 101 301 minecraft:prismarine_bricks
fill 189 101 277 189 101 285 minecraft:prismarine_bricks
fill 189 101 289 189 101 297 minecraft:prismarine_bricks
fill 189 101 302 189 101 309 minecraft:prismarine_bricks
fill 189 101 313 190 101 316 minecraft:prismarine_bricks
fill 190 101 277 190 101 284 minecraft:prismarine_bricks
fill 190 101 288 194 101 294 minecraft:prismarine_bricks
fill 190 101 300 194 101 300 minecraft:prismarine_bricks
fill 190 101 302 194 101 308 minecraft:prismarine_bricks
setblock 190 101 312 minecraft:prismarine_bricks
fill 191 101 277 199 101 277 minecraft:prismarine_bricks
fill 191 101 281 194 101 287 minecraft:prismarine_bricks
fill 191 101 298 194 101 299 minecraft:prismarine_bricks
fill 191 101 309 194 101 311 minecraft:prismarine_bricks
fill 191 101 315 194 101 316 minecraft:prismarine_bricks
fill 192 101 276 200 101 276 minecraft:prismarine_bricks
fill 193 101 295 194 101 297 minecraft:prismarine_bricks
fill 194 101 278 207 101 280 minecraft:prismarine_bricks
fill 194 101 312 207 101 314 minecraft:prismarine_bricks
fill 195 101 281 229 101 281 minecraft:prismarine_bricks
fill 195 101 311 227 101 311 minecraft:prismarine_bricks
setblock 195 101 315 minecraft:prismarine_bricks
fill 197 101 317 197 126 317 minecraft:dark_prismarine
fill 198 101 316 206 101 316 minecraft:prismarine_bricks
fill 199 101 315 207 101 315 minecraft:prismarine_bricks
fill 203 101 277 207 101 277 minecraft:prismarine_bricks
fill 204 101 276 212 101 276 minecraft:prismarine_bricks
fill 208 101 280 224 101 280 minecraft:prismarine_bricks
fill 208 101 312 224 101 312 minecraft:prismarine_bricks
fill 210 101 316 218 101 316 minecraft:prismarine_bricks
fill 210 101 317 210 126 317 minecraft:dark_prismarine
fill 211 101 277 211 101 279 minecraft:prismarine_bricks
fill 211 101 313 219 101 315 minecraft:prismarine_bricks
fill 212 101 278 224 101 279 minecraft:prismarine_bricks
fill 215 101 277 223 101 277 minecraft:prismarine_bricks
fill 216 101 276 224 101 276 minecraft:prismarine_bricks
fill 220 101 283 221 102 284 minecraft:light_blue_stained_glass
fill 220 101 313 224 101 314 minecraft:prismarine_bricks
fill 222 101 316 229 101 316 minecraft:prismarine_bricks
fill 223 101 315 229 101 315 minecraft:prismarine_bricks
fill 224 101 282 227 101 288 minecraft:prismarine_bricks
fill 224 101 292 225 101 310 minecraft:prismarine_bricks
fill 225 101 289 229 101 289 minecraft:prismarine_bricks
fill 225 101 291 229 101 291 minecraft:prismarine_bricks
fill 226 101 290 229 101 290 minecraft:prismarine_bricks
fill 226 101 292 229 101 294 minecraft:prismarine_bricks
fill 226 101 298 227 101 310 minecraft:prismarine_bricks
fill 227 101 277 229 101 277 minecraft:prismarine_bricks
fill 228 101 276 229 101 276 minecraft:prismarine_bricks
fill 228 101 278 229 101 280 minecraft:prismarine_bricks
fill 228 101 282 228 101 284 minecraft:prismarine_bricks
fill 228 101 288 229 101 288 minecraft:prismarine_bricks
fill 228 101 300 228 101 308 minecraft:prismarine_bricks
fill 228 101 312 229 101 314 minecraft:prismarine_bricks
fill 229 101 282 229 101 283 minecraft:prismarine_bricks
setblock 229 101 287 minecraft:prismarine_bricks
setblock 229 101 295 minecraft:prismarine_bricks
fill 229 101 299 229 101 307 minecraft:prismarine_bricks
setblock 229 101 311 minecraft:prismarine_bricks
fill 230 101 281 230 123 281 minecraft:dark_prismarine
setblock 230 101 285 minecraft:sea_lantern
setblock 230 101 286 minecraft:prismarine_bricks
setblock 230 101 306 minecraft:prismarine_bricks
fill 188 102 301 188 124 301 minecraft:dark_prismarine
setblock 191 102 286 minecraft:light[level=15]
setblock 191 102 294 minecraft:light[level=15]
setblock 191 102 302 minecraft:light[level=15]
setblock 191 102 310 minecraft:light[level=15]
fill 194 102 281 194 102 311 minecraft:gold_block
fill 195 102 281 224 102 281 minecraft:gold_block
fill 195 102 311 224 102 311 minecraft:gold_block
setblock 199 102 278 minecraft:light[level=15]
setblock 199 102 286 minecraft:light[level=15]
setblock 199 102 294 minecraft:light[level=15]
setblock 199 102 302 minecraft:light[level=15]
setblock 199 102 310 minecraft:light[level=15]
setblock 207 102 278 minecraft:light[level=15]
setblock 207 102 286 minecraft:light[level=15]
setblock 207 102 294 minecraft:light[level=15]
setblock 207 102 302 minecraft:light[level=15]
setblock 207 102 310 minecraft:light[level=15]
setblock 215 102 278 minecraft:light[level=15]
setblock 215 102 286 minecraft:light[level=15]
setblock 215 102 294 minecraft:light[level=15]
setblock 215 102 302 minecraft:light[level=15]
setblock 215 102 310 minecraft:light[level=15]
fill 221 102 317 221 126 317 minecraft:dark_prismarine
setblock 222 102 317 minecraft:prismarine_bricks
setblock 223 102 278 minecraft:light[level=15]
setblock 223 102 286 minecraft:light[level=15]
setblock 223 102 294 minecraft:light[level=15]
setblock 223 102 302 minecraft:light[level=15]
setblock 223 102 310 minecraft:light[level=15]
fill 223 102 317 223 123 317 minecraft:dark_prismarine
fill 224 102 282 224 102 310 minecraft:gold_block
setblock 230 102 282 minecraft:prismarine_bricks
fill 230 102 285 230 116 286 minecraft:dark_prismarine
fill 230 102 306 230 123 306 minecraft:dark_prismarine
fill 222 103 317 222 126 317 minecraft:dark_prismarine
fill 224 103 290 224 106 290 minecraft:prismarine_bricks
fill 230 103 282 230 115 282 minecraft:dark_prismarine
setblock 188 104 280 minecraft:sea_lantern
setblock 191 104 285 minecraft:light[level=12]
setblock 191 104 292 minecraft:light[level=12]
setblock 191 104 299 minecraft:light[level=12]
setblock 191 104 306 minecraft:light[level=12]
setblock 198 104 278 minecraft:light[level=12]
setblock 198 104 285 minecraft:light[level=12]
setblock 198 104 292 minecraft:light[level=12]
setblock 198 104 299 minecraft:light[level=12]
setblock 198 104 306 minecraft:light[level=12]
setblock 198 104 313 minecraft:light[level=12]
fill 204 104 317 204 126 317 minecraft:dark_prismarine
setblock 205 104 278 minecraft:light[level=12]
setblock 205 104 285 minecraft:light[level=12]
setblock 205 104 292 minecraft:light[level=12]
setblock 205 104 299 minecraft:light[level=12]
setblock 205 104 306 minecraft:light[level=12]
setblock 205 104 313 minecraft:light[level=12]
setblock 205 104 317 minecraft:sea_lantern
fill 206 104 317 207 124 317 minecraft:dark_prismarine
setblock 212 104 278 minecraft:light[level=12]
setblock 212 104 285 minecraft:light[level=12]
setblock 212 104 292 minecraft:light[level=12]
setblock 212 104 299 minecraft:light[level=12]
setblock 212 104 306 minecraft:light[level=12]
setblock 212 104 313 minecraft:light[level=12]
setblock 212 104 317 minecraft:prismarine_bricks
setblock 219 104 278 minecraft:light[level=12]
setblock 219 104 285 minecraft:light[level=12]
setblock 219 104 292 minecraft:light[level=12]
setblock 219 104 299 minecraft:light[level=12]
setblock 219 104 306 minecraft:light[level=12]
setblock 219 104 313 minecraft:light[level=12]
setblock 226 104 285 minecraft:light[level=12]
setblock 226 104 292 minecraft:light[level=12]
setblock 226 104 299 minecraft:light[level=12]
setblock 226 104 306 minecraft:light[level=12]
setblock 230 104 288 minecraft:prismarine_bricks
setblock 230 104 297 minecraft:prismarine_bricks
fill 188 105 280 189 105 280 minecraft:dark_prismarine
setblock 189 105 279 minecraft:dark_prismarine
fill 189 105 281 189 105 284 minecraft:dark_prismarine
fill 189 105 291 189 105 296 minecraft:dark_prismarine
fill 189 105 303 189 105 308 minecraft:dark_prismarine
fill 189 105 315 189 105 316 minecraft:dark_prismarine
fill 190 105 316 193 105 316 minecraft:dark_prismarine
fill 193 105 276 198 105 276 minecraft:dark_prismarine
fill 200 105 316 205 105 316 minecraft:dark_prismarine
fill 205 105 276 210 105 276 minecraft:dark_prismarine
fill 205 105 317 205 108 317 minecraft:dark_prismarine
fill 212 105 316 212 105 317 minecraft:dark_prismarine
fill 213 105 316 217 105 316 minecraft:dark_prismarine
fill 217 105 276 222 105 276 minecraft:dark_prismarine
fill 224 105 316 229 105 316 minecraft:dark_prismarine
fill 229 105 276 229 105 281 minecraft:dark_prismarine
fill 229 105 288 229 105 293 minecraft:dark_prismarine
fill 229 105 300 229 105 305 minecraft:dark_prismarine
fill 229 105 312 229 105 315 minecraft:dark_prismarine
setblock 230 105 288 minecraft:dark_prismarine
fill 230 105 297 230 123 297 minecraft:dark_prismarine
fill 188 106 280 188 126 280 minecraft:dark_prismarine
fill 188 106 281 188 111 284 minecraft:sea_lantern
fill 188 106 293 188 111 296 minecraft:sea_lantern
fill 188 106 305 188 111 308 minecraft:sea_lantern
fill 188 106 317 191 111 317 minecraft:sea_lantern
fill 195 106 275 198 111 275 minecraft:sea_lantern
fill 196 106 295 196 107 296 minecraft:white_stained_glass
fill 200 106 317 203 111 317 minecraft:sea_lantern
fill 207 106 275 210 111 275 minecraft:sea_lantern
fill 212 106 317 215 111 317 minecraft:sea_lantern
fill 219 106 275 222 111 275 minecraft:sea_lantern
fill 224 106 317 227 111 317 minecraft:sea_lantern
fill 230 106 276 230 111 279 minecraft:sea_lantern
fill 230 106 288 230 111 291 minecraft:sea_lantern
fill 230 106 300 230 111 303 minecraft:sea_lantern
fill 230 106 312 230 111 315 minecraft:sea_lantern
fill 205 107 282 205 108 283 minecraft:white_stained_glass
setblock 209 107 317 minecraft:prismarine_bricks
setblock 224 107 290 minecraft:sea_lantern
setblock 227 107 275 minecraft:prismarine_bricks
fill 209 108 317 209 110 317 minecraft:dark_prismarine
fill 227 108 275 227 124 275 minecraft:dark_prismarine
setblock 205 109 317 minecraft:prismarine_bricks
setblock 191 110 285 minecraft:light[level=12]
setblock 191 110 286 minecraft:light[level=15]
setblock 191 110 292 minecraft:light[level=12]
setblock 191 110 294 minecraft:light[level=15]
setblock 191 110 299 minecraft:light[level=12]
setblock 191 110 302 minecraft:light[level=15]
setblock 191 110 306 minecraft:light[level=12]
setblock 191 110 310 minecraft:light[level=15]
setblock 198 110 278 minecraft:light[level=12]
setblock 198 110 285 minecraft:light[level=12]
setblock 198 110 292 minecraft:light[level=12]
setblock 198 110 299 minecraft:light[level=12]
setblock 198 110 306 minecraft:light[level=12]
setblock 198 110 313 minecraft:light[level=12]
setblock 199 110 278 minecraft:light[level=15]
setblock 199 110 286 minecraft:light[level=15]
setblock 199 110 294 minecraft:light[level=15]
setblock 199 110 302 minecraft:light[level=15]
setblock 199 110 310 minecraft:light[level=15]
setblock 205 110 278 minecraft:light[level=12]
setblock 205 110 285 minecraft:light[level=12]
setblock 205 110 292 minecraft:light[level=12]
setblock 205 110 299 minecraft:light[level=12]
setblock 205 110 306 minecraft:light[level=12]
setblock 205 110 313 minecraft:light[level=12]
fill 205 110 317 205 126 317 minecraft:dark_prismarine
setblock 207 110 278 minecraft:light[level=15]
setblock 207 110 286 minecraft:light[level=15]
setblock 207 110 294 minecraft:light[level=15]
setblock 207 110 302 minecraft:light[level=15]
setblock 207 110 310 minecraft:light[level=15]
setblock 212 110 278 minecraft:light[level=12]
setblock 212 110 285 minecraft:light[level=12]
setblock 212 110 292 minecraft:light[level=12]
setblock 212 110 299 minecraft:light[level=12]
setblock 212 110 306 minecraft:light[level=12]
setblock 212 110 313 minecraft:light[level=12]
setblock 215 110 278 minecraft:light[level=15]
setblock 215 110 286 minecraft:light[level=15]
setblock 215 110 294 minecraft:light[level=15]
setblock 215 110 302 minecraft:light[level=15]
setblock 215 110 310 minecraft:light[level=15]
setblock 219 110 278 minecraft:light[level=12]
setblock 219 110 285 minecraft:light[level=12]
setblock 219 110 292 minecraft:light[level=12]
setblock 219 110 299 minecraft:light[level=12]
setblock 219 110 306 minecraft:light[level=12]
setblock 219 110 313 minecraft:light[level=12]
setblock 223 110 278 minecraft:light[level=15]
setblock 223 110 286 minecraft:light[level=15]
setblock 223 110 294 minecraft:light[level=15]
setblock 223 110 302 minecraft:light[level=15]
setblock 223 110 310 minecraft:light[level=15]
setblock 226 110 285 minecraft:light[level=12]
setblock 226 110 292 minecraft:light[level=12]
setblock 226 110 299 minecraft:light[level=12]
setblock 226 110 306 minecraft:light[level=12]
fill 189 111 296 193 112 296 minecraft:prismarine_bricks
fill 190 111 279 194 112 279 minecraft:prismarine_bricks
fill 190 111 295 192 112 295 minecraft:prismarine_bricks
fill 190 111 297 192 112 297 minecraft:prismarine_bricks
fill 190 111 313 194 112 313 minecraft:prismarine_bricks
fill 191 111 278 193 112 278 minecraft:prismarine_bricks
fill 191 111 280 193 112 280 minecraft:prismarine_bricks
fill 191 111 294 191 112 294 minecraft:prismarine_bricks
fill 191 111 298 191 112 298 minecraft:prismarine_bricks
fill 191 111 312 193 112 312 minecraft:prismarine_bricks
fill 191 111 314 193 112 314 minecraft:prismarine_bricks
fill 192 111 277 192 112 277 minecraft:prismarine_bricks
fill 192 111 281 192 112 281 minecraft:prismarine_bricks
fill 192 111 311 192 112 311 minecraft:prismarine_bricks
fill 192 111 315 192 112 315 minecraft:prismarine_bricks
fill 207 111 278 211 112 278 minecraft:prismarine_bricks
fill 207 111 314 211 112 314 minecraft:prismarine_bricks
fill 208 111 277 210 112 277 minecraft:prismarine_bricks
fill 208 111 279 210 112 279 minecraft:prismarine_bricks
fill 208 111 313 210 112 313 minecraft:prismarine_bricks
fill 208 111 315 210 112 315 minecraft:prismarine_bricks
fill 209 111 276 209 112 276 minecraft:prismarine_bricks
fill 209 111 280 209 112 280 minecraft:prismarine_bricks
fill 209 111 312 209 112 312 minecraft:prismarine_bricks
setblock 209 111 317 minecraft:prismarine_bricks
fill 224 111 279 228 112 279 minecraft:prismarine_bricks
fill 224 111 313 228 112 313 minecraft:prismarine_bricks
fill 225 111 278 227 112 278 minecraft:prismarine_bricks
fill 225 111 280 227 112 280 minecraft:prismarine_bricks
fill 225 111 296 228 112 296 minecraft:prismarine_bricks
fill 225 111 312 227 112 312 minecraft:prismarine_bricks
fill 225 111 314 227 112 314 minecraft:prismarine_bricks
fill 226 111 277 226 112 277 minecraft:prismarine_bricks
fill 226 111 281 226 112 281 minecraft:prismarine_bricks
fill 226 111 295 228 112 295 minecraft:prismarine_bricks
fill 226 111 297 228 112 297 minecraft:prismarine_bricks
fill 226 111 311 226 112 311 minecraft:prismarine_bricks
fill 226 111 315 226 112 315 minecraft:prismarine_bricks
fill 227 111 294 227 112 294 minecraft:prismarine_bricks
fill 227 111 298 227 112 298 minecraft:prismarine_bricks
fill 188 112 281 188 123 281 minecraft:dark_prismarine
fill 188 112 282 188 112 283 minecraft:sea_lantern
fill 188 112 284 188 121 284 minecraft:dark_prismarine
fill 188 112 293 188 126 293 minecraft:dark_prismarine
fill 188 112 294 188 112 295 minecraft:sea_lantern
fill 188 112 296 188 126 296 minecraft:dark_prismarine
fill 188 112 305 188 124 305 minecraft:dark_prismarine
fill 188 112 306 188 112 307 minecraft:sea_lantern
fill 188 112 308 188 126 308 minecraft:dark_prismarine
fill 188 112 317 188 127 317 minecraft:dark_prismarine
fill 189 112 317 190 112 317 minecraft:sea_lantern
fill 191 112 317 191 126 317 minecraft:dark_prismarine
fill 195 112 275 195 120 275 minecraft:dark_prismarine
fill 196 112 275 197 112 275 minecraft:sea_lantern
fill 198 112 275 198 123 275 minecraft:dark_prismarine
fill 200 112 317 200 124 317 minecraft:dark_prismarine
fill 201 112 317 202 112 317 minecraft:sea_lantern
fill 203 112 317 203 123 317 minecraft:dark_prismarine
fill 207 112 275 207 126 275 minecraft:dark_prismarine
fill 208 112 275 209 112 275 minecraft:sea_lantern
fill 209 112 317 209 126 317 minecraft:dark_prismarine
fill 210 112 275 210 126 275 minecraft:dark_prismarine
fill 212 112 317 212 124 317 minecraft:dark_prismarine
fill 213 112 317 214 112 317 minecraft:sea_lantern
fill 215 112 317 215 122 317 minecraft:dark_prismarine
fill 219 112 275 219 126 275 minecraft:dark_prismarine
fill 220 112 275 221 112 275 minecraft:sea_lantern
fill 222 112 275 222 124 275 minecraft:dark_prismarine
fill 224 112 317 224 126 317 minecraft:dark_prismarine
fill 225 112 317 226 112 317 minecraft:sea_lantern
fill 227 112 317 227 126 317 minecraft:dark_prismarine
fill 230 112 276 230 126 276 minecraft:dark_prismarine
fill 230 112 277 230 112 278 minecraft:sea_lantern
fill 230 112 279 230 126 279 minecraft:dark_prismarine
fill 230 112 288 230 126 288 minecraft:dark_prismarine
fill 230 112 289 230 112 290 minecraft:sea_lantern
fill 230 112 291 230 122 291 minecraft:dark_prismarine
fill 230 112 300 230 116 300 minecraft:dark_prismarine
fill 230 112 301 230 112 302 minecraft:sea_lantern
fill 230 112 303 230 119 303 minecraft:dark_prismarine
fill 230 112 312 230 126 312 minecraft:dark_prismarine
fill 230 112 313 230 112 314 minecraft:sea_lantern
fill 230 112 315 230 126 315 minecraft:dark_prismarine
setblock 188 113 277 minecraft:prismarine_bricks
fill 188 113 282 188 122 283 minecraft:dark_prismarine
fill 188 113 294 188 113 295 minecraft:dark_prismarine
fill 188 113 306 188 118 307 minecraft:dark_prismarine
fill 189 113 317 190 126 317 minecraft:dark_prismarine
fill 190 113 295 192 123 297 minecraft:quartz_pillar
fill 191 113 278 193 129 280 minecraft:quartz_pillar
fill 191 113 312 193 140 314 minecraft:quartz_pillar
fill 196 113 275 197 122 275 minecraft:dark_prismarine
fill 201 113 317 202 126 317 minecraft:dark_prismarine
fill 208 113 275 209 124 275 minecraft:dark_prismarine
fill 208 113 277 210 140 279 minecraft:quartz_pillar
fill 208 113 313 210 129 315 minecraft:quartz_pillar
fill 213 113 317 214 123 317 minecraft:dark_prismarine
fill 220 113 275 221 122 275 minecraft:dark_prismarine
fill 225 113 278 227 140 280 minecraft:quartz_pillar
fill 225 113 312 227 140 314 minecraft:quartz_pillar
fill 225 113 317 226 124 317 minecraft:dark_prismarine
fill 226 113 295 228 140 297 minecraft:quartz_pillar
fill 230 113 277 230 126 278 minecraft:dark_prismarine
fill 230 113 289 230 126 290 minecraft:dark_prismarine
fill 230 113 301 230 123 302 minecraft:dark_prismarine
fill 230 113 313 230 126 314 minecraft:dark_prismarine
fill 188 114 277 188 124 277 minecraft:dark_prismarine
fill 188 114 294 188 126 294 minecraft:dark_prismarine
setblock 188 114 295 minecraft:prismarine_bricks
setblock 218 114 275 minecraft:sea_lantern
setblock 230 114 287 minecraft:sea_lantern
fill 188 115 291 188 116 291 minecraft:dark_prismarine
setblock 188 115 292 minecraft:prismarine_bricks
fill 188 115 295 188 124 295 minecraft:dark_prismarine
fill 218 115 275 218 127 275 minecraft:dark_prismarine
fill 230 115 287 230 126 287 minecraft:dark_prismarine
fill 188 116 292 188 126 292 minecraft:dark_prismarine
fill 188 116 297 188 124 298 minecraft:dark_prismarine
setblock 188 116 299 minecraft:sea_lantern
fill 190 116 288 195 116 288 minecraft:dark_prismarine
setblock 191 116 285 minecraft:light[level=12]
fill 191 116 286 195 117 287 minecraft:dark_prismarine
fill 191 116 289 195 117 290 minecraft:dark_prismarine
setblock 191 116 292 minecraft:light[level=12]
setblock 191 116 299 minecraft:light[level=12]
setblock 191 116 306 minecraft:light[level=12]
setblock 198 116 278 minecraft:light[level=12]
setblock 198 116 285 minecraft:light[level=12]
setblock 198 116 292 minecraft:light[level=12]
setblock 198 116 299 minecraft:light[level=12]
setblock 198 116 306 minecraft:light[level=12]
setblock 198 116 313 minecraft:light[level=12]
setblock 205 116 278 minecraft:light[level=12]
setblock 205 116 285 minecraft:light[level=12]
setblock 205 116 292 minecraft:light[level=12]
setblock 205 116 299 minecraft:light[level=12]
setblock 205 116 306 minecraft:light[level=12]
setblock 205 116 313 minecraft:light[level=12]
setblock 212 116 278 minecraft:light[level=12]
setblock 212 116 285 minecraft:light[level=12]
setblock 212 116 292 minecraft:light[level=12]
setblock 212 116 299 minecraft:light[level=12]
setblock 212 116 306 minecraft:light[level=12]
setblock 212 116 313 minecraft:light[level=12]
setblock 219 116 278 minecraft:light[level=12]
setblock 219 116 285 minecraft:light[level=12]
setblock 219 116 292 minecraft:light[level=12]
setblock 219 116 299 minecraft:light[level=12]
setblock 219 116 306 minecraft:light[level=12]
setblock 219 116 313 minecraft:light[level=12]
setblock 226 116 285 minecraft:light[level=12]
setblock 226 116 292 minecraft:light[level=12]
setblock 226 116 299 minecraft:light[level=12]
setblock 226 116 306 minecraft:light[level=12]
setblock 230 116 282 minecraft:sea_lantern
setblock 188 117 291 minecraft:prismarine_bricks
fill 188 117 299 188 123 299 minecraft:dark_prismarine
fill 191 117 288 195 117 288 minecraft:dark_prismarine
setblock 216 117 275 minecraft:prismarine_bricks
setblock 226 117 275 minecraft:sea_lantern
fill 230 117 282 230 126 282 minecraft:dark_prismarine
fill 230 117 285 230 124 285 minecraft:dark_prismarine
setblock 230 117 286 minecraft:prismarine_bricks
setblock 230 117 300 minecraft:sea_lantern
fill 188 118 291 188 122 291 minecraft:dark_prismarine
setblock 188 118 300 minecraft:sea_lantern
setblock 191 118 286 minecraft:light[level=15]
setblock 191 118 294 minecraft:light[level=15]
setblock 191 118 302 minecraft:light[level=15]
setblock 191 118 310 minecraft:light[level=15]
fill 192 118 287 194 118 289 minecraft:prismarine_bricks
setblock 199 118 278 minecraft:light[level=15]
setblock 199 118 286 minecraft:light[level=15]
setblock 199 118 294 minecraft:light[level=15]
setblock 199 118 302 minecraft:light[level=15]
setblock 199 118 310 minecraft:light[level=15]
setblock 207 118 278 minecraft:light[level=15]
setblock 207 118 286 minecraft:light[level=15]
setblock 207 118 294 minecraft:light[level=15]
setblock 207 118 302 minecraft:light[level=15]
setblock 207 118 310 minecraft:light[level=15]
setblock 215 118 278 minecraft:light[level=15]
setblock 215 118 286 minecraft:light[level=15]
setblock 215 118 294 minecraft:light[level=15]
setblock 215 118 302 minecraft:light[level=15]
setblock 215 118 310 minecraft:light[level=15]
fill 216 118 275 216 124 275 minecraft:dark_prismarine
setblock 223 118 278 minecraft:light[level=15]
setblock 223 118 286 minecraft:light[level=15]
setblock 223 118 294 minecraft:light[level=15]
setblock 223 118 302 minecraft:light[level=15]
setblock 223 118 310 minecraft:light[level=15]
fill 226 118 275 226 128 275 minecraft:dark_prismarine
fill 230 118 286 230 122 286 minecraft:dark_prismarine
fill 230 118 300 230 126 300 minecraft:dark_prismarine
fill 188 119 300 188 124 300 minecraft:dark_prismarine
setblock 188 119 306 minecraft:sea_lantern
fill 188 119 307 188 126 307 minecraft:dark_prismarine
setblock 188 119 309 minecraft:sea_lantern
fill 188 119 310 188 126 310 minecraft:dark_prismarine
fill 188 120 306 188 124 306 minecraft:dark_prismarine
fill 188 120 309 188 126 309 minecraft:dark_prismarine
setblock 230 120 303 minecraft:sea_lantern
setblock 188 121 302 minecraft:sea_lantern
setblock 195 121 275 minecraft:sea_lantern
setblock 199 121 275 minecraft:sea_lantern
fill 200 121 275 200 126 275 minecraft:dark_prismarine
fill 230 121 303 230 124 303 minecraft:dark_prismarine
setblock 188 122 284 minecraft:prismarine_bricks
fill 188 122 302 188 126 302 minecraft:dark_prismarine
setblock 191 122 285 minecraft:light[level=12]
setblock 191 122 292 minecraft:light[level=12]
setblock 191 122 299 minecraft:light[level=12]
setblock 191 122 306 minecraft:light[level=12]
fill 195 122 275 195 126 275 minecraft:dark_prismarine
setblock 198 122 278 minecraft:light[level=12]
setblock 198 122 285 minecraft:light[level=12]
setblock 198 122 292 minecraft:light[level=12]
setblock 198 122 299 minecraft:light[level=12]
setblock 198 122 306 minecraft:light[level=12]
setblock 198 122 313 minecraft:light[level=12]
setblock 199 122 275 minecraft:dark_prismarine
setblock 205 122 278 minecraft:light[level=12]
setblock 205 122 285 minecraft:light[level=12]
setblock 205 122 292 minecraft:light[level=12]
setblock 205 122 299 minecraft:light[level=12]
setblock 205 122 306 minecraft:light[level=12]
setblock 205 122 313 minecraft:light[level=12]
setblock 212 122 278 minecraft:light[level=12]
setblock 212 122 285 minecraft:light[level=12]
setblock 212 122 292 minecraft:light[level=12]
setblock 212 122 299 minecraft:light[level=12]
setblock 212 122 306 minecraft:light[level=12]
setblock 212 122 313 minecraft:light[level=12]
setblock 219 122 278 minecraft:light[level=12]
setblock 219 122 285 minecraft:light[level=12]
setblock 219 122 292 minecraft:light[level=12]
setblock 219 122 299 minecraft:light[level=12]
setblock 219 122 306 minecraft:light[level=12]
setblock 219 122 313 minecraft:light[level=12]
setblock 226 122 285 minecraft:light[level=12]
setblock 226 122 292 minecraft:light[level=12]
setblock 226 122 299 minecraft:light[level=12]
setblock 226 122 306 minecraft:light[level=12]
fill 188 123 282 188 124 282 minecraft:dark_prismarine
setblock 188 123 283 minecraft:prismarine_bricks
fill 188 123 284 188 126 284 minecraft:dark_prismarine
setblock 188 123 286 minecraft:prismarine_bricks
setblock 188 123 291 minecraft:prismarine_bricks
setblock 192 123 275 minecraft:prismarine_bricks
fill 196 123 275 196 124 275 minecraft:dark_prismarine
fill 197 123 275 197 124 275 minecraft:prismarine_bricks
setblock 199 123 275 minecraft:prismarine_bricks
setblock 215 123 275 minecraft:prismarine_bricks
setblock 215 123 317 minecraft:prismarine_bricks
fill 220 123 275 220 126 275 minecraft:dark_prismarine
setblock 221 123 275 minecraft:prismarine_bricks
fill 228 123 317 229 126 317 minecraft:dark_prismarine
setblock 230 123 286 minecraft:prismarine_bricks
setblock 230 123 291 minecraft:prismarine_bricks
fill 230 123 293 230 126 293 minecraft:dark_prismarine
fill 230 123 294 230 124 294 minecraft:prismarine_bricks
setblock 230 123 307 minecraft:prismarine_bricks
setblock 230 123 308 minecraft:dark_prismarine
setblock 230 123 317 minecraft:prismarine_bricks
setblock 188 124 281 minecraft:prismarine_bricks
setblock 188 124 283 minecraft:dark_prismarine
setblock 188 124 286 minecraft:dark_prismarine
fill 188 124 291 188 126 291 minecraft:dark_prismarine
setblock 188 124 299 minecraft:prismarine_bricks
setblock 188 124 303 minecraft:prismarine_bricks
fill 190 124 294 197 124 294 minecraft:prismarine_bricks
fill 190 124 295 190 140 297 minecraft:quartz_pillar
fill 191 124 290 198 124 293 minecraft:prismarine_bricks
fill 191 124 295 198 124 298 minecraft:prismarine_bricks
fill 192 124 275 192 126 275 minecraft:dark_prismarine
fill 192 124 288 210 124 289 minecraft:prismarine_bricks
fill 192 124 299 210 124 300 minecraft:prismarine_bricks
setblock 193 124 275 minecraft:sea_lantern
fill 193 124 287 209 124 287 minecraft:prismarine_bricks
fill 193 124 301 209 124 301 minecraft:prismarine_bricks
fill 194 124 286 208 124 286 minecraft:prismarine_bricks
fill 194 124 302 208 124 302 minecraft:prismarine_bricks
fill 195 124 285 207 124 285 minecraft:prismarine_bricks
fill 195 124 303 207 124 303 minecraft:prismarine_bricks
fill 197 124 284 205 124 284 minecraft:prismarine_bricks
fill 197 124 304 205 124 304 minecraft:prismarine_bricks
setblock 198 124 275 minecraft:prismarine_bricks
setblock 198 124 317 minecraft:prismarine_bricks
setblock 199 124 275 minecraft:dark_prismarine
fill 199 124 290 200 124 291 minecraft:prismarine_bricks
fill 199 124 297 200 124 298 minecraft:prismarine_bricks
setblock 201 124 275 minecraft:prismarine_bricks
fill 201 124 283 201 125 283 minecraft:prismarine_bricks
fill 201 124 290 211 124 290 minecraft:prismarine_bricks
fill 201 124 298 211 124 298 minecraft:prismarine_bricks
fill 201 124 305 201 125 305 minecraft:prismarine_bricks
fill 202 124 291 211 124 291 minecraft:prismarine_bricks
fill 202 124 297 211 124 297 minecraft:prismarine_bricks
setblock 203 124 317 minecraft:prismarine_bricks
fill 204 124 292 211 124 293 minecraft:prismarine_bricks
fill 204 124 295 211 124 296 minecraft:prismarine_bricks
fill 205 124 294 212 124 294 minecraft:prismarine_bricks
fill 213 124 317 213 126 317 minecraft:dark_prismarine
setblock 214 124 317 minecraft:sea_lantern
fill 215 124 275 215 126 275 minecraft:dark_prismarine
fill 215 124 317 217 126 317 minecraft:dark_prismarine
fill 218 124 317 219 124 317 minecraft:prismarine_bricks
setblock 221 124 275 minecraft:dark_prismarine
setblock 223 124 317 minecraft:prismarine_bricks
setblock 230 124 281 minecraft:prismarine_bricks
setblock 230 124 283 minecraft:prismarine_bricks
fill 230 124 286 230 126 286 minecraft:dark_prismarine
fill 230 124 291 230 126 291 minecraft:dark_prismarine
setblock 230 124 297 minecraft:prismarine_bricks
fill 230 124 301 230 124 302 minecraft:prismarine_bricks
fill 230 124 306 230 125 306 minecraft:prismarine_bricks
fill 230 124 307 230 126 307 minecraft:dark_prismarine
fill 230 124 308 230 125 308 minecraft:prismarine_bricks
fill 230 124 317 230 126 317 minecraft:dark_prismarine
setblock 188 125 275 minecraft:prismarine_bricks
fill 188 125 276 229 125 276 minecraft:dark_prismarine
setblock 188 125 277 minecraft:sea_lantern
setblock 188 125 279 minecraft:prismarine_bricks
fill 188 125 281 230 125 281 minecraft:dark_prismarine
fill 188 125 282 188 125 283 minecraft:prismarine_bricks
setblock 188 125 286 minecraft:prismarine_bricks
setblock 188 125 295 minecraft:prismarine_bricks
fill 188 125 297 189 125 297 minecraft:dark_prismarine
setblock 188 125 298 minecraft:prismarine_bricks
fill 188 125 299 191 125 299 minecraft:dark_prismarine
setblock 188 125 300 minecraft:sea_lantern
setblock 188 125 301 minecraft:prismarine_bricks
fill 188 125 303 194 125 303 minecraft:dark_prismarine
fill 188 125 304 188 125 306 minecraft:prismarine_bricks
setblock 188 125 312 minecraft:prismarine_bricks
fill 188 125 313 190 125 313 minecraft:dark_prismarine
fill 189 125 277 190 125 280 minecraft:dark_prismarine
fill 189 125 282 189 125 296 minecraft:dark_prismarine
fill 189 125 298 190 125 298 minecraft:dark_prismarine
fill 189 125 300 191 125 302 minecraft:dark_prismarine
fill 189 125 304 190 125 312 minecraft:dark_prismarine
fill 189 125 314 190 125 316 minecraft:dark_prismarine
fill 190 125 282 190 125 293 minecraft:dark_prismarine
setblock 190 125 294 minecraft:prismarine_bricks
fill 191 125 277 207 125 277 minecraft:dark_prismarine
fill 191 125 282 191 125 289 minecraft:dark_prismarine
fill 191 125 290 191 125 298 minecraft:sea_lantern
fill 191 125 304 196 125 311 minecraft:dark_prismarine
fill 191 125 315 207 125 316 minecraft:dark_prismarine
fill 192 125 282 192 125 287 minecraft:dark_prismarine
fill 192 125 288 192 125 289 minecraft:sea_lantern
fill 192 125 290 194 125 291 minecraft:prismarine_bricks
fill 192 125 292 193 125 292 minecraft:prismarine
fill 192 125 293 193 125 295 minecraft:prismarine_bricks
fill 192 125 296 193 125 296 minecraft:prismarine
fill 192 125 297 194 125 298 minecraft:prismarine_bricks
fill 192 125 299 192 125 300 minecraft:sea_lantern
fill 192 125 301 192 125 302 minecraft:dark_prismarine
fill 193 125 275 193 126 275 minecraft:dark_prismarine
fill 193 125 282 193 125 286 minecraft:dark_prismarine
fill 193 125 287 193 125 288 minecraft:sea_lantern
fill 193 125 289 195 125 289 minecraft:prismarine_bricks
fill 193 125 299 195 125 299 minecraft:prismarine_bricks
fill 193 125 300 193 125 301 minecraft:sea_lantern
setblock 193 125 302 minecraft:dark_prismarine
fill 194 125 278 207 125 280 minecraft:dark_prismarine
fill 194 125 282 194 125 285 minecraft:dark_prismarine
fill 194 125 286 195 125 286 minecraft:sea_lantern
setblock 194 125 287 minecraft:prismarine
setblock 194 125 288 minecraft:prismarine_bricks
fill 194 125 292 194 125 296 minecraft:gold_block
setblock 194 125 300 minecraft:prismarine_bricks
setblock 194 125 301 minecraft:prismarine
fill 194 125 302 195 125 302 minecraft:sea_lantern
fill 194 125 312 207 125 314 minecraft:dark_prismarine
fill 195 125 282 196 125 284 minecraft:dark_prismarine
fill 195 125 285 196 125 285 minecraft:sea_lantern
fill 195 125 287 198 125 287 minecraft:prismarine_bricks
setblock 195 125 288 minecraft:prismarine
fill 195 125 290 195 125 291 minecraft:gold_block
fill 195 125 292 196 125 296 minecraft:prismarine_bricks
fill 195 125 297 195 125 298 minecraft:gold_block
setblock 195 125 300 minecraft:prismarine
fill 195 125 301 198 125 301 minecraft:prismarine_bricks
fill 195 125 303 196 125 303 minecraft:sea_lantern
setblock 196 125 275 minecraft:prismarine_bricks
fill 196 125 286 198 125 286 minecraft:prismarine_bricks
setblock 196 125 288 minecraft:prismarine_bricks
setblock 196 125 289 minecraft:gold_block
fill 196 125 290 196 125 291 minecraft:prismarine_bricks
fill 196 125 297 196 125 298 minecraft:prismarine_bricks
setblock 196 125 299 minecraft:gold_block
setblock 196 125 300 minecraft:prismarine_bricks
fill 196 125 302 198 125 302 minecraft:prismarine_bricks
fill 197 125 275 198 126 275 minecraft:dark_prismarine
fill 197 125 282 200 125 283 minecraft:dark_prismarine
fill 197 125 284 205 125 284 minecraft:sea_lantern
fill 197 125 285 198 125 285 minecraft:prismarine_bricks
fill 197 125 288 198 125 288 minecraft:gold_block
fill 197 125 289 205 125 289 minecraft:prismarine_bricks
setblock 197 125 290 minecraft:prismarine
fill 197 125 291 197 125 292 minecraft:prismarine_bricks
fill 197 125 293 197 125 295 minecraft:gold_block
fill 197 125 296 197 125 297 minecraft:prismarine_bricks
setblock 197 125 298 minecraft:prismarine
fill 197 125 299 205 125 299 minecraft:prismarine_bricks
fill 197 125 300 198 125 300 minecraft:gold_block
fill 197 125 303 198 125 303 minecraft:prismarine_bricks
fill 197 125 304 205 125 304 minecraft:sea_lantern
fill 197 125 305 200 125 311 minecraft:dark_prismarine
fill 198 125 290 199 125 290 minecraft:prismarine_bricks
fill 198 125 291 198 125 293 minecraft:gold_block
fill 198 125 295 198 125 297 minecraft:gold_block
fill 198 125 298 199 125 298 minecraft:prismarine_bricks
fill 198 125 317 198 126 317 minecraft:dark_prismarine
setblock 199 125 275 minecraft:prismarine_bricks
fill 199 125 285 199 125 286 minecraft:prismarine
fill 199 125 287 203 125 287 minecraft:gold_block
fill 199 125 288 203 125 288 minecraft:prismarine_bricks
fill 199 125 291 200 125 291 minecraft:gold_block
fill 199 125 297 200 125 297 minecraft:gold_block
fill 199 125 300 203 125 300 minecraft:prismarine_bricks
fill 199 125 301 203 125 301 minecraft:gold_block
fill 199 125 302 199 125 303 minecraft:prismarine
fill 200 125 285 202 125 286 minecraft:prismarine_bricks
fill 200 125 290 202 125 290 minecraft:gold_block
fill 200 125 298 202 125 298 minecraft:gold_block
fill 200 125 302 202 125 303 minecraft:prismarine_bricks
setblock 200 125 317 minecraft:prismarine_bricks
fill 201 125 275 201 126 275 minecraft:dark_prismarine
fill 201 125 282 229 125 282 minecraft:dark_prismarine
fill 201 125 306 229 125 311 minecraft:dark_prismarine
fill 202 125 283 230 125 283 minecraft:dark_prismarine
fill 202 125 291 204 125 291 minecraft:gold_block
fill 202 125 297 204 125 297 minecraft:gold_block
fill 202 125 305 229 125 305 minecraft:dark_prismarine
fill 203 125 285 203 125 286 minecraft:prismarine
fill 203 125 290 204 125 290 minecraft:prismarine_bricks
fill 203 125 298 204 125 298 minecraft:prismarine_bricks
fill 203 125 302 203 125 303 minecraft:prismarine
fill 203 125 317 203 126 317 minecraft:dark_prismarine
fill 204 125 285 205 125 287 minecraft:prismarine_bricks
fill 204 125 288 205 125 288 minecraft:gold_block
fill 204 125 292 204 125 293 minecraft:gold_block
fill 204 125 295 204 125 296 minecraft:gold_block
fill 204 125 300 205 125 300 minecraft:gold_block
fill 204 125 301 205 125 303 minecraft:prismarine_bricks
setblock 205 125 290 minecraft:prismarine
fill 205 125 291 206 125 292 minecraft:prismarine_bricks
fill 205 125 293 205 125 295 minecraft:gold_block
fill 205 125 296 206 125 297 minecraft:prismarine_bricks
setblock 205 125 298 minecraft:prismarine
setblock 206 125 275 minecraft:sea_lantern
fill 206 125 284 229 125 284 minecraft:dark_prismarine
fill 206 125 285 207 125 285 minecraft:sea_lantern
fill 206 125 286 206 125 288 minecraft:prismarine_bricks
setblock 206 125 289 minecraft:gold_block
setblock 206 125 290 minecraft:prismarine_bricks
fill 206 125 293 207 125 295 minecraft:prismarine_bricks
setblock 206 125 298 minecraft:prismarine_bricks
setblock 206 125 299 minecraft:gold_block
fill 206 125 300 206 125 302 minecraft:prismarine_bricks
fill 206 125 303 207 125 303 minecraft:sea_lantern
fill 206 125 304 229 125 304 minecraft:dark_prismarine
fill 206 125 317 206 126 317 minecraft:dark_prismarine
fill 207 125 286 208 125 286 minecraft:sea_lantern
setblock 207 125 287 minecraft:prismarine_bricks
setblock 207 125 288 minecraft:prismarine
fill 207 125 289 209 125 289 minecraft:prismarine_bricks
fill 207 125 290 207 125 291 minecraft:gold_block
setblock 207 125 292 minecraft:prismarine_bricks
setblock 207 125 296 minecraft:prismarine_bricks
fill 207 125 297 207 125 298 minecraft:gold_block
fill 207 125 299 209 125 299 minecraft:prismarine_bricks
setblock 207 125 300 minecraft:prismarine
setblock 207 125 301 minecraft:prismarine_bricks
fill 207 125 302 208 125 302 minecraft:sea_lantern
setblock 207 125 317 minecraft:prismarine_bricks
fill 208 125 275 208 126 275 minecraft:dark_prismarine
fill 208 125 280 224 125 280 minecraft:dark_prismarine
fill 208 125 285 229 125 285 minecraft:dark_prismarine
setblock 208 125 287 minecraft:prismarine
setblock 208 125 288 minecraft:prismarine_bricks
fill 208 125 290 210 125 291 minecraft:prismarine_bricks
fill 208 125 292 208 125 296 minecraft:gold_block
fill 208 125 297 210 125 298 minecraft:prismarine_bricks
setblock 208 125 300 minecraft:prismarine_bricks
setblock 208 125 301 minecraft:prismarine
fill 208 125 303 229 125 303 minecraft:dark_prismarine
fill 208 125 312 224 125 312 minecraft:dark_prismarine
fill 208 125 316 229 125 316 minecraft:dark_prismarine
setblock 209 125 275 minecraft:prismarine_bricks
fill 209 125 286 229 125 286 minecraft:dark_prismarine
schedule function dropper:buildpart/64_2 1t
