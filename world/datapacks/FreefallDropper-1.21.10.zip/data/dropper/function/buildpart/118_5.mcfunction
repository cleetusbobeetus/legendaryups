setblock 472 137 493 minecraft:terracotta
fill 472 137 494 472 140 494 minecraft:red_terracotta
setblock 472 137 498 minecraft:terracotta
fill 472 137 499 472 140 499 minecraft:red_terracotta
fill 472 137 501 472 137 502 minecraft:red_terracotta
setblock 472 137 503 minecraft:terracotta
fill 472 137 504 472 140 504 minecraft:red_terracotta
setblock 473 137 477 minecraft:terracotta
setblock 473 137 478 minecraft:red_terracotta
setblock 473 137 492 minecraft:terracotta
fill 473 137 493 473 138 493 minecraft:red_terracotta
setblock 473 137 497 minecraft:terracotta
fill 473 137 498 473 140 498 minecraft:red_terracotta
setblock 473 137 501 minecraft:red_terracotta
setblock 473 137 502 minecraft:terracotta
fill 473 137 503 473 140 503 minecraft:red_terracotta
setblock 474 137 496 minecraft:terracotta
fill 474 137 497 474 139 497 minecraft:red_terracotta
setblock 474 137 501 minecraft:terracotta
fill 474 137 502 474 140 502 minecraft:red_terracotta
fill 475 137 501 475 139 501 minecraft:red_terracotta
setblock 476 137 464 minecraft:terracotta
setblock 476 137 504 minecraft:terracotta
setblock 477 137 464 minecraft:red_terracotta
setblock 477 137 503 minecraft:terracotta
fill 477 137 504 477 140 504 minecraft:red_terracotta
setblock 478 137 502 minecraft:terracotta
fill 478 137 503 478 140 503 minecraft:red_terracotta
setblock 481 137 504 minecraft:terracotta
setblock 482 137 504 minecraft:red_terracotta
fill 487 137 504 490 137 504 minecraft:red_terracotta
fill 490 137 503 491 137 503 minecraft:red_terracotta
setblock 491 137 464 minecraft:terracotta
setblock 491 137 504 minecraft:terracotta
fill 492 137 464 492 140 464 minecraft:red_terracotta
setblock 492 137 503 minecraft:terracotta
fill 492 137 504 492 140 504 minecraft:red_terracotta
fill 493 137 503 493 140 503 minecraft:red_terracotta
setblock 495 137 504 minecraft:red_terracotta
setblock 496 137 464 minecraft:terracotta
setblock 496 137 504 minecraft:terracotta
fill 497 137 464 497 138 464 minecraft:red_terracotta
fill 497 137 504 497 138 504 minecraft:red_terracotta
setblock 506 137 464 minecraft:terracotta
setblock 506 137 504 minecraft:terracotta
fill 507 137 464 507 140 464 minecraft:red_terracotta
fill 507 137 504 507 140 504 minecraft:red_terracotta
fill 508 137 503 508 140 503 minecraft:red_terracotta
setblock 509 137 471 minecraft:terracotta
fill 509 137 472 509 138 472 minecraft:red_terracotta
setblock 509 137 475 minecraft:red_terracotta
setblock 509 137 476 minecraft:terracotta
fill 509 137 477 509 139 477 minecraft:red_terracotta
setblock 510 137 464 minecraft:red_terracotta
setblock 510 137 465 minecraft:terracotta
fill 510 137 466 510 140 466 minecraft:red_terracotta
setblock 510 137 470 minecraft:terracotta
fill 510 137 471 510 140 471 minecraft:red_terracotta
setblock 510 137 475 minecraft:terracotta
fill 510 137 476 510 140 476 minecraft:red_terracotta
setblock 510 137 480 minecraft:terracotta
fill 510 137 481 510 140 481 minecraft:red_terracotta
setblock 510 137 494 minecraft:red_terracotta
setblock 510 137 495 minecraft:terracotta
fill 510 137 496 510 140 496 minecraft:red_terracotta
setblock 510 137 499 minecraft:red_terracotta
setblock 510 137 500 minecraft:terracotta
fill 510 137 501 510 140 501 minecraft:red_terracotta
setblock 511 137 464 minecraft:terracotta
fill 511 137 465 511 140 465 minecraft:red_terracotta
setblock 511 137 469 minecraft:terracotta
fill 511 137 470 511 140 470 minecraft:red_terracotta
setblock 511 137 474 minecraft:terracotta
fill 511 137 475 511 140 475 minecraft:red_terracotta
setblock 511 137 479 minecraft:terracotta
fill 511 137 480 511 140 480 minecraft:red_terracotta
setblock 511 137 484 minecraft:terracotta
fill 511 137 485 511 140 485 minecraft:red_terracotta
setblock 511 137 494 minecraft:terracotta
fill 511 137 495 511 140 495 minecraft:red_terracotta
setblock 511 137 499 minecraft:terracotta
fill 511 137 500 511 140 500 minecraft:red_terracotta
setblock 511 137 504 minecraft:terracotta
fill 471 138 464 471 141 464 minecraft:red_terracotta
setblock 471 138 468 minecraft:terracotta
fill 471 138 469 471 139 469 minecraft:red_terracotta
setblock 471 138 473 minecraft:terracotta
fill 471 138 474 471 141 474 minecraft:red_terracotta
setblock 471 138 478 minecraft:terracotta
fill 471 138 479 471 141 479 minecraft:red_terracotta
setblock 471 138 482 minecraft:red_terracotta
setblock 471 138 483 minecraft:terracotta
fill 471 138 484 471 138 487 minecraft:red_terracotta
setblock 471 138 488 minecraft:terracotta
fill 471 138 489 471 138 492 minecraft:red_terracotta
setblock 471 138 493 minecraft:terracotta
fill 471 138 494 471 138 497 minecraft:red_terracotta
setblock 471 138 498 minecraft:terracotta
fill 471 138 499 471 141 499 minecraft:red_terracotta
setblock 471 138 503 minecraft:terracotta
fill 471 138 504 471 141 504 minecraft:red_terracotta
setblock 472 138 472 minecraft:terracotta
setblock 472 138 473 minecraft:red_terracotta
setblock 472 138 477 minecraft:terracotta
fill 472 138 478 472 141 478 minecraft:red_terracotta
setblock 472 138 482 minecraft:terracotta
setblock 472 138 492 minecraft:terracotta
fill 472 138 493 472 141 493 minecraft:red_terracotta
setblock 472 138 497 minecraft:terracotta
fill 472 138 498 472 141 498 minecraft:red_terracotta
setblock 472 138 501 minecraft:red_terracotta
setblock 472 138 502 minecraft:terracotta
fill 472 138 503 472 141 503 minecraft:red_terracotta
setblock 473 138 496 minecraft:terracotta
fill 473 138 497 473 141 497 minecraft:red_terracotta
setblock 473 138 501 minecraft:terracotta
fill 473 138 502 473 141 502 minecraft:red_terracotta
setblock 474 138 495 minecraft:terracotta
setblock 474 138 496 minecraft:red_terracotta
setblock 474 138 499 minecraft:red_terracotta
setblock 474 138 500 minecraft:terracotta
fill 474 138 501 474 140 501 minecraft:red_terracotta
setblock 475 138 464 minecraft:terracotta
setblock 475 138 504 minecraft:terracotta
setblock 476 138 464 minecraft:red_terracotta
setblock 476 138 503 minecraft:terracotta
fill 476 138 504 476 141 504 minecraft:red_terracotta
setblock 477 138 502 minecraft:terracotta
fill 477 138 503 477 141 503 minecraft:red_terracotta
setblock 478 138 502 minecraft:red_terracotta
setblock 480 138 504 minecraft:terracotta
setblock 481 138 504 minecraft:red_terracotta
fill 486 138 504 489 138 504 minecraft:red_terracotta
fill 489 138 503 490 138 503 minecraft:red_terracotta
setblock 490 138 504 minecraft:terracotta
fill 491 138 464 491 141 464 minecraft:red_terracotta
setblock 491 138 503 minecraft:terracotta
fill 491 138 504 491 141 504 minecraft:red_terracotta
fill 492 138 503 492 141 503 minecraft:red_terracotta
fill 494 138 503 494 139 503 minecraft:red_terracotta
setblock 495 138 464 minecraft:terracotta
setblock 495 138 504 minecraft:terracotta
fill 496 138 464 496 139 464 minecraft:red_terracotta
fill 496 138 504 496 140 504 minecraft:red_terracotta
setblock 505 138 464 minecraft:terracotta
fill 506 138 464 506 141 464 minecraft:red_terracotta
fill 506 138 504 506 141 504 minecraft:red_terracotta
fill 507 138 503 507 141 503 minecraft:red_terracotta
setblock 508 138 465 minecraft:red_terracotta
setblock 509 138 464 minecraft:red_terracotta
setblock 509 138 465 minecraft:terracotta
setblock 509 138 475 minecraft:terracotta
fill 509 138 476 509 139 476 minecraft:red_terracotta
setblock 509 138 479 minecraft:red_terracotta
setblock 509 138 499 minecraft:red_terracotta
setblock 509 138 500 minecraft:terracotta
fill 509 138 501 509 140 502 minecraft:red_terracotta
setblock 510 138 464 minecraft:terracotta
fill 510 138 465 510 141 465 minecraft:red_terracotta
setblock 510 138 469 minecraft:terracotta
fill 510 138 470 510 140 470 minecraft:red_terracotta
setblock 510 138 474 minecraft:terracotta
fill 510 138 475 510 141 475 minecraft:red_terracotta
setblock 510 138 479 minecraft:terracotta
fill 510 138 480 510 141 480 minecraft:red_terracotta
fill 510 138 482 511 138 482 minecraft:red_terracotta
fill 510 138 495 510 139 495 minecraft:red_terracotta
setblock 510 138 499 minecraft:terracotta
fill 510 138 500 510 141 500 minecraft:red_terracotta
setblock 510 138 504 minecraft:terracotta
fill 511 138 464 511 141 464 minecraft:red_terracotta
setblock 511 138 468 minecraft:terracotta
fill 511 138 469 511 141 469 minecraft:red_terracotta
setblock 511 138 473 minecraft:terracotta
fill 511 138 474 511 141 474 minecraft:red_terracotta
setblock 511 138 478 minecraft:terracotta
fill 511 138 479 511 141 479 minecraft:red_terracotta
setblock 511 138 483 minecraft:terracotta
fill 511 138 484 511 141 484 minecraft:red_terracotta
setblock 511 138 493 minecraft:terracotta
fill 511 138 494 511 141 494 minecraft:red_terracotta
setblock 511 138 498 minecraft:terracotta
fill 511 138 499 511 141 499 minecraft:red_terracotta
setblock 511 138 503 minecraft:terracotta
fill 511 138 504 511 141 504 minecraft:red_terracotta
setblock 471 139 467 minecraft:terracotta
fill 471 139 468 471 140 468 minecraft:red_terracotta
setblock 471 139 472 minecraft:terracotta
fill 471 139 473 471 140 473 minecraft:red_terracotta
setblock 471 139 477 minecraft:terracotta
fill 471 139 478 471 142 478 minecraft:red_terracotta
setblock 471 139 481 minecraft:red_terracotta
setblock 471 139 482 minecraft:terracotta
fill 471 139 483 471 139 486 minecraft:red_terracotta
setblock 471 139 487 minecraft:terracotta
fill 471 139 488 471 139 491 minecraft:red_terracotta
setblock 471 139 492 minecraft:terracotta
fill 471 139 493 471 139 496 minecraft:red_terracotta
setblock 471 139 497 minecraft:terracotta
fill 471 139 498 471 142 498 minecraft:red_terracotta
fill 471 139 500 471 139 501 minecraft:red_terracotta
setblock 471 139 502 minecraft:terracotta
fill 471 139 503 471 142 503 minecraft:red_terracotta
setblock 472 139 476 minecraft:terracotta
fill 472 139 477 472 140 477 minecraft:red_terracotta
setblock 472 139 481 minecraft:terracotta
fill 472 139 482 472 141 483 minecraft:red_terracotta
setblock 472 139 491 minecraft:terracotta
fill 472 139 492 472 140 492 minecraft:red_terracotta
setblock 472 139 496 minecraft:terracotta
fill 472 139 497 472 142 497 minecraft:red_terracotta
setblock 472 139 501 minecraft:terracotta
fill 472 139 502 472 142 502 minecraft:red_terracotta
setblock 473 139 495 minecraft:terracotta
fill 473 139 496 473 141 496 minecraft:red_terracotta
setblock 473 139 500 minecraft:terracotta
fill 473 139 501 473 142 501 minecraft:red_terracotta
setblock 474 139 464 minecraft:terracotta
setblock 474 139 499 minecraft:terracotta
fill 474 139 500 474 140 500 minecraft:red_terracotta
setblock 474 139 504 minecraft:terracotta
setblock 475 139 464 minecraft:red_terracotta
setblock 475 139 503 minecraft:terracotta
fill 475 139 504 475 142 504 minecraft:red_terracotta
setblock 476 139 502 minecraft:terracotta
fill 476 139 503 476 142 503 minecraft:red_terracotta
setblock 477 139 502 minecraft:red_terracotta
setblock 479 139 504 minecraft:terracotta
fill 480 139 504 480 140 504 minecraft:red_terracotta
fill 486 139 504 488 139 504 minecraft:red_terracotta
setblock 489 139 503 minecraft:red_terracotta
setblock 489 139 504 minecraft:terracotta
setblock 490 139 503 minecraft:terracotta
fill 490 139 504 490 142 504 minecraft:red_terracotta
fill 491 139 503 491 142 503 minecraft:red_terracotta
setblock 494 139 464 minecraft:terracotta
setblock 494 139 504 minecraft:terracotta
fill 495 139 464 495 142 464 minecraft:red_terracotta
fill 495 139 504 495 142 504 minecraft:red_terracotta
fill 505 139 464 505 142 464 minecraft:red_terracotta
fill 505 139 504 505 142 504 minecraft:red_terracotta
setblock 508 139 465 minecraft:terracotta
setblock 509 139 464 minecraft:terracotta
fill 509 139 465 509 142 465 minecraft:red_terracotta
setblock 509 139 474 minecraft:terracotta
setblock 509 139 475 minecraft:red_terracotta
setblock 509 139 499 minecraft:terracotta
fill 509 139 500 509 142 500 minecraft:red_terracotta
setblock 509 139 504 minecraft:terracotta
fill 510 139 464 510 142 464 minecraft:red_terracotta
setblock 510 139 468 minecraft:terracotta
fill 510 139 469 510 140 469 minecraft:red_terracotta
setblock 510 139 473 minecraft:terracotta
fill 510 139 474 510 141 474 minecraft:red_terracotta
setblock 510 139 478 minecraft:terracotta
fill 510 139 479 510 142 479 minecraft:red_terracotta
setblock 510 139 482 minecraft:red_terracotta
setblock 510 139 498 minecraft:terracotta
fill 510 139 499 510 142 499 minecraft:red_terracotta
setblock 510 139 503 minecraft:terracotta
fill 510 139 504 510 142 504 minecraft:red_terracotta
setblock 511 139 467 minecraft:terracotta
fill 511 139 468 511 142 468 minecraft:red_terracotta
setblock 511 139 472 minecraft:terracotta
fill 511 139 473 511 142 473 minecraft:red_terracotta
setblock 511 139 477 minecraft:terracotta
fill 511 139 478 511 142 478 minecraft:red_terracotta
setblock 511 139 482 minecraft:terracotta
fill 511 139 483 511 142 483 minecraft:red_terracotta
setblock 511 139 492 minecraft:terracotta
fill 511 139 493 511 140 493 minecraft:red_terracotta
setblock 511 139 497 minecraft:terracotta
fill 511 139 498 511 142 498 minecraft:red_terracotta
setblock 511 139 502 minecraft:terracotta
fill 511 139 503 511 142 503 minecraft:red_terracotta
setblock 471 140 466 minecraft:terracotta
fill 471 140 467 471 141 467 minecraft:red_terracotta
setblock 471 140 471 minecraft:terracotta
setblock 471 140 472 minecraft:red_terracotta
setblock 471 140 476 minecraft:terracotta
fill 471 140 477 471 143 477 minecraft:red_terracotta
setblock 471 140 481 minecraft:terracotta
fill 471 140 482 471 140 485 minecraft:red_terracotta
setblock 471 140 486 minecraft:terracotta
fill 471 140 487 471 140 490 minecraft:red_terracotta
setblock 471 140 491 minecraft:terracotta
fill 471 140 492 471 140 495 minecraft:red_terracotta
setblock 471 140 496 minecraft:terracotta
fill 471 140 497 471 143 497 minecraft:red_terracotta
setblock 471 140 500 minecraft:red_terracotta
setblock 471 140 501 minecraft:terracotta
fill 471 140 502 471 143 502 minecraft:red_terracotta
setblock 472 140 476 minecraft:red_terracotta
setblock 472 140 480 minecraft:terracotta
fill 472 140 481 472 143 481 minecraft:red_terracotta
setblock 472 140 495 minecraft:terracotta
fill 472 140 496 472 143 496 minecraft:red_terracotta
setblock 472 140 500 minecraft:terracotta
fill 472 140 501 472 143 501 minecraft:red_terracotta
setblock 473 140 464 minecraft:terracotta
setblock 473 140 495 minecraft:red_terracotta
setblock 473 140 499 minecraft:terracotta
fill 473 140 500 473 143 500 minecraft:red_terracotta
setblock 473 140 504 minecraft:terracotta
fill 474 140 464 474 142 464 minecraft:red_terracotta
setblock 474 140 498 minecraft:terracotta
setblock 474 140 499 minecraft:red_terracotta
setblock 474 140 503 minecraft:terracotta
fill 474 140 504 474 143 504 minecraft:red_terracotta
setblock 475 140 502 minecraft:terracotta
fill 475 140 503 475 143 503 minecraft:red_terracotta
setblock 476 140 502 minecraft:red_terracotta
setblock 478 140 504 minecraft:terracotta
fill 479 140 504 479 142 504 minecraft:red_terracotta
fill 486 140 504 487 140 504 minecraft:red_terracotta
setblock 488 140 504 minecraft:terracotta
setblock 489 140 503 minecraft:terracotta
fill 489 140 504 489 143 504 minecraft:red_terracotta
fill 490 140 464 490 142 464 minecraft:red_terracotta
fill 490 140 503 490 143 503 minecraft:red_terracotta
setblock 493 140 464 minecraft:terracotta
setblock 493 140 504 minecraft:terracotta
fill 494 140 464 494 143 464 minecraft:red_terracotta
fill 494 140 504 494 143 504 minecraft:red_terracotta
fill 504 140 464 504 143 464 minecraft:red_terracotta
fill 504 140 504 504 143 504 minecraft:red_terracotta
fill 506 140 503 506 142 503 minecraft:red_terracotta
setblock 508 140 464 minecraft:terracotta
fill 508 140 465 508 143 465 minecraft:red_terracotta
setblock 508 140 504 minecraft:terracotta
fill 509 140 464 509 143 464 minecraft:red_terracotta
setblock 509 140 499 minecraft:red_terracotta
setblock 509 140 503 minecraft:terracotta
fill 509 140 504 509 143 504 minecraft:red_terracotta
setblock 510 140 467 minecraft:terracotta
setblock 510 140 468 minecraft:red_terracotta
setblock 510 140 472 minecraft:terracotta
fill 510 140 473 510 141 473 minecraft:red_terracotta
setblock 510 140 477 minecraft:terracotta
fill 510 140 478 510 143 478 minecraft:red_terracotta
setblock 510 140 482 minecraft:terracotta
setblock 510 140 497 minecraft:terracotta
fill 510 140 498 510 143 498 minecraft:red_terracotta
setblock 510 140 502 minecraft:terracotta
fill 510 140 503 510 143 503 minecraft:red_terracotta
setblock 511 140 466 minecraft:terracotta
fill 511 140 467 511 143 467 minecraft:red_terracotta
setblock 511 140 471 minecraft:terracotta
fill 511 140 472 511 143 472 minecraft:red_terracotta
setblock 511 140 476 minecraft:terracotta
fill 511 140 477 511 143 477 minecraft:red_terracotta
setblock 511 140 481 minecraft:terracotta
fill 511 140 482 511 143 482 minecraft:red_terracotta
setblock 511 140 496 minecraft:terracotta
fill 511 140 497 511 143 497 minecraft:red_terracotta
setblock 511 140 501 minecraft:terracotta
fill 511 140 502 511 143 502 minecraft:red_terracotta
setblock 471 141 465 minecraft:terracotta
fill 471 141 466 471 144 466 minecraft:red_terracotta
setblock 471 141 475 minecraft:terracotta
fill 471 141 476 471 143 476 minecraft:red_terracotta
setblock 471 141 480 minecraft:terracotta
fill 471 141 481 471 141 484 minecraft:red_terracotta
setblock 471 141 485 minecraft:terracotta
fill 471 141 486 471 141 489 minecraft:red_terracotta
setblock 471 141 490 minecraft:terracotta
fill 471 141 491 471 141 494 minecraft:red_terracotta
setblock 471 141 495 minecraft:terracotta
fill 471 141 496 471 144 496 minecraft:red_terracotta
setblock 471 141 500 minecraft:terracotta
fill 471 141 501 471 144 501 minecraft:red_terracotta
setblock 472 141 464 minecraft:terracotta
setblock 472 141 479 minecraft:terracotta
fill 472 141 480 472 143 480 minecraft:red_terracotta
setblock 472 141 494 minecraft:terracotta
fill 472 141 495 472 143 495 minecraft:red_terracotta
setblock 472 141 499 minecraft:terracotta
fill 472 141 500 472 144 500 minecraft:red_terracotta
setblock 472 141 504 minecraft:terracotta
fill 473 141 464 473 144 464 minecraft:red_terracotta
setblock 473 141 498 minecraft:terracotta
fill 473 141 499 473 143 499 minecraft:red_terracotta
setblock 473 141 503 minecraft:terracotta
fill 473 141 504 473 144 504 minecraft:red_terracotta
setblock 474 141 502 minecraft:terracotta
fill 474 141 503 474 144 503 minecraft:red_terracotta
fill 475 141 502 475 142 502 minecraft:red_terracotta
setblock 477 141 504 minecraft:terracotta
fill 478 141 504 478 144 504 minecraft:red_terracotta
fill 485 141 504 486 141 504 minecraft:red_terracotta
setblock 487 141 504 minecraft:terracotta
fill 488 141 504 488 144 504 minecraft:red_terracotta
fill 489 141 464 489 143 464 minecraft:red_terracotta
fill 489 141 503 489 144 503 minecraft:red_terracotta
setblock 492 141 464 minecraft:terracotta
setblock 492 141 504 minecraft:terracotta
fill 493 141 464 493 144 464 minecraft:red_terracotta
fill 493 141 504 493 144 504 minecraft:red_terracotta
setblock 507 141 464 minecraft:terracotta
fill 507 141 465 507 144 465 minecraft:red_terracotta
setblock 507 141 504 minecraft:terracotta
fill 508 141 464 508 144 464 minecraft:red_terracotta
setblock 508 141 502 minecraft:red_terracotta
setblock 508 141 503 minecraft:terracotta
fill 508 141 504 508 144 504 minecraft:red_terracotta
setblock 509 141 501 minecraft:red_terracotta
setblock 509 141 502 minecraft:terracotta
fill 509 141 503 509 144 503 minecraft:red_terracotta
setblock 510 141 466 minecraft:terracotta
fill 510 141 467 510 144 467 minecraft:red_terracotta
setblock 510 141 476 minecraft:terracotta
fill 510 141 477 510 143 477 minecraft:red_terracotta
setblock 510 141 481 minecraft:terracotta
fill 510 141 482 510 144 482 minecraft:red_terracotta
fill 510 141 497 510 144 497 minecraft:red_terracotta
setblock 510 141 501 minecraft:terracotta
fill 510 141 502 510 144 502 minecraft:red_terracotta
setblock 511 141 465 minecraft:terracotta
fill 511 141 466 511 144 466 minecraft:red_terracotta
setblock 511 141 470 minecraft:terracotta
fill 511 141 471 511 144 471 minecraft:red_terracotta
setblock 511 141 475 minecraft:terracotta
fill 511 141 476 511 144 476 minecraft:red_terracotta
setblock 511 141 480 minecraft:terracotta
fill 511 141 481 511 144 481 minecraft:red_terracotta
setblock 511 141 485 minecraft:terracotta
setblock 511 141 495 minecraft:terracotta
fill 511 141 496 511 144 496 minecraft:red_terracotta
setblock 511 141 500 minecraft:terracotta
fill 511 141 501 511 144 501 minecraft:red_terracotta
setblock 471 142 464 minecraft:terracotta
fill 471 142 465 471 145 465 minecraft:red_terracotta
setblock 471 142 475 minecraft:red_terracotta
setblock 471 142 479 minecraft:terracotta
fill 471 142 480 471 142 483 minecraft:red_terracotta
setblock 471 142 484 minecraft:terracotta
fill 471 142 485 471 142 488 minecraft:red_terracotta
setblock 471 142 489 minecraft:terracotta
fill 471 142 490 471 142 493 minecraft:red_terracotta
setblock 471 142 494 minecraft:terracotta
fill 471 142 495 471 145 495 minecraft:red_terracotta
setblock 471 142 499 minecraft:terracotta
fill 471 142 500 471 145 500 minecraft:red_terracotta
setblock 471 142 504 minecraft:terracotta
fill 472 142 464 472 145 464 minecraft:red_terracotta
setblock 472 142 479 minecraft:red_terracotta
setblock 472 142 482 minecraft:red_terracotta
setblock 472 142 483 minecraft:terracotta
fill 472 142 484 472 145 484 minecraft:red_terracotta
setblock 472 142 494 minecraft:red_terracotta
setblock 472 142 498 minecraft:terracotta
fill 472 142 499 472 145 499 minecraft:red_terracotta
setblock 472 142 503 minecraft:terracotta
fill 472 142 504 472 145 504 minecraft:red_terracotta
setblock 473 142 466 minecraft:light[level=14]
setblock 473 142 474 minecraft:light[level=14]
setblock 473 142 482 minecraft:light[level=14]
setblock 473 142 490 minecraft:light[level=14]
setblock 473 142 498 minecraft:red_terracotta
setblock 473 142 502 minecraft:terracotta
fill 473 142 503 473 145 503 minecraft:red_terracotta
fill 474 142 502 474 143 502 minecraft:red_terracotta
setblock 476 142 504 minecraft:terracotta
fill 477 142 504 477 145 504 minecraft:red_terracotta
setblock 481 142 466 minecraft:light[level=14]
setblock 481 142 474 minecraft:light[level=14]
setblock 481 142 482 minecraft:light[level=14]
setblock 481 142 490 minecraft:light[level=14]
setblock 481 142 498 minecraft:light[level=14]
setblock 485 142 504 minecraft:red_terracotta
setblock 486 142 504 minecraft:terracotta
fill 487 142 504 487 145 504 minecraft:red_terracotta
fill 488 142 464 488 144 464 minecraft:red_terracotta
fill 488 142 503 488 145 503 minecraft:red_terracotta
setblock 489 142 466 minecraft:light[level=14]
setblock 489 142 474 minecraft:light[level=14]
setblock 489 142 482 minecraft:light[level=14]
setblock 489 142 490 minecraft:light[level=14]
setblock 489 142 498 minecraft:light[level=14]
setblock 491 142 464 minecraft:terracotta
setblock 491 142 504 minecraft:terracotta
fill 492 142 464 492 145 464 minecraft:red_terracotta
fill 492 142 504 492 145 504 minecraft:red_terracotta
setblock 497 142 466 minecraft:light[level=14]
setblock 497 142 474 minecraft:light[level=14]
setblock 497 142 482 minecraft:light[level=14]
setblock 497 142 490 minecraft:light[level=14]
setblock 497 142 498 minecraft:light[level=14]
fill 503 142 464 503 144 464 minecraft:red_terracotta
fill 503 142 504 503 144 504 minecraft:red_terracotta
setblock 505 142 466 minecraft:light[level=14]
setblock 505 142 474 minecraft:light[level=14]
setblock 505 142 482 minecraft:light[level=14]
setblock 505 142 490 minecraft:light[level=14]
fill 505 142 503 505 143 503 minecraft:red_terracotta
setblock 506 142 464 minecraft:terracotta
fill 506 142 465 506 145 465 minecraft:red_terracotta
setblock 506 142 504 minecraft:terracotta
fill 507 142 464 507 145 464 minecraft:red_terracotta
setblock 507 142 503 minecraft:terracotta
fill 507 142 504 507 145 504 minecraft:red_terracotta
setblock 508 142 502 minecraft:terracotta
fill 508 142 503 508 145 503 minecraft:red_terracotta
setblock 509 142 501 minecraft:terracotta
fill 509 142 502 509 145 502 minecraft:red_terracotta
setblock 510 142 465 minecraft:terracotta
fill 510 142 466 510 145 466 minecraft:red_terracotta
setblock 510 142 475 minecraft:terracotta
setblock 510 142 476 minecraft:red_terracotta
setblock 510 142 480 minecraft:terracotta
fill 510 142 481 510 145 481 minecraft:red_terracotta
setblock 510 142 500 minecraft:terracotta
fill 510 142 501 510 145 501 minecraft:red_terracotta
setblock 511 142 464 minecraft:terracotta
fill 511 142 465 511 145 465 minecraft:red_terracotta
setblock 511 142 469 minecraft:terracotta
fill 511 142 470 511 145 470 minecraft:red_terracotta
setblock 511 142 474 minecraft:terracotta
fill 511 142 475 511 144 475 minecraft:red_terracotta
setblock 511 142 479 minecraft:terracotta
fill 511 142 480 511 145 480 minecraft:red_terracotta
setblock 511 142 484 minecraft:terracotta
fill 511 142 485 511 145 485 minecraft:red_terracotta
setblock 511 142 494 minecraft:terracotta
fill 511 142 495 511 145 495 minecraft:red_terracotta
setblock 511 142 499 minecraft:terracotta
fill 511 142 500 511 145 500 minecraft:red_terracotta
setblock 511 142 504 minecraft:terracotta
fill 471 143 464 471 146 464 minecraft:red_terracotta
setblock 471 143 478 minecraft:terracotta
fill 471 143 479 471 143 482 minecraft:red_terracotta
setblock 471 143 483 minecraft:terracotta
fill 471 143 484 471 143 487 minecraft:red_terracotta
setblock 471 143 488 minecraft:terracotta
fill 471 143 489 471 143 492 minecraft:red_terracotta
setblock 471 143 493 minecraft:terracotta
fill 471 143 494 471 146 494 minecraft:red_terracotta
setblock 471 143 498 minecraft:terracotta
fill 471 143 499 471 146 499 minecraft:red_terracotta
setblock 471 143 503 minecraft:terracotta
fill 471 143 504 471 146 504 minecraft:red_terracotta
setblock 472 143 482 minecraft:terracotta
fill 472 143 483 472 146 483 minecraft:red_terracotta
fill 472 143 485 472 144 485 minecraft:red_terracotta
setblock 472 143 497 minecraft:terracotta
fill 472 143 498 472 146 498 minecraft:red_terracotta
setblock 472 143 502 minecraft:terracotta
fill 472 143 503 472 146 503 minecraft:red_terracotta
setblock 473 143 501 minecraft:terracotta
fill 473 143 502 473 145 502 minecraft:red_terracotta
setblock 475 143 504 minecraft:terracotta
setblock 476 143 503 minecraft:terracotta
fill 476 143 504 476 146 504 minecraft:red_terracotta
setblock 484 143 504 minecraft:red_terracotta
setblock 485 143 504 minecraft:terracotta
fill 486 143 504 486 146 504 minecraft:red_terracotta
fill 487 143 464 487 145 464 minecraft:red_terracotta
setblock 490 143 464 minecraft:terracotta
setblock 490 143 504 minecraft:terracotta
fill 491 143 464 491 146 464 minecraft:red_terracotta
setblock 491 143 503 minecraft:terracotta
fill 491 143 504 491 146 504 minecraft:red_terracotta
setblock 495 143 464 minecraft:terracotta
setblock 495 143 504 minecraft:terracotta
fill 496 143 464 496 146 464 minecraft:red_terracotta
fill 501 143 464 502 145 464 minecraft:red_terracotta
fill 502 143 504 502 145 504 minecraft:red_terracotta
setblock 505 143 464 minecraft:terracotta
fill 505 143 465 505 146 465 minecraft:red_terracotta
setblock 505 143 504 minecraft:terracotta
fill 506 143 464 506 146 464 minecraft:red_terracotta
setblock 506 143 503 minecraft:terracotta
fill 506 143 504 506 146 504 minecraft:red_terracotta
setblock 507 143 502 minecraft:terracotta
fill 507 143 503 507 146 503 minecraft:red_terracotta
fill 508 143 502 508 146 502 minecraft:red_terracotta
setblock 509 143 465 minecraft:terracotta
setblock 509 143 500 minecraft:terracotta
fill 509 143 501 509 146 501 minecraft:red_terracotta
setblock 510 143 464 minecraft:terracotta
fill 510 143 465 510 146 465 minecraft:red_terracotta
setblock 510 143 479 minecraft:terracotta
fill 510 143 480 510 146 480 minecraft:red_terracotta
setblock 510 143 499 minecraft:terracotta
fill 510 143 500 510 146 500 minecraft:red_terracotta
setblock 510 143 504 minecraft:terracotta
fill 511 143 464 511 146 464 minecraft:red_terracotta
setblock 511 143 468 minecraft:terracotta
fill 511 143 469 511 146 469 minecraft:red_terracotta
setblock 511 143 473 minecraft:terracotta
fill 511 143 474 511 144 474 minecraft:red_terracotta
setblock 511 143 478 minecraft:terracotta
fill 511 143 479 511 146 479 minecraft:red_terracotta
setblock 511 143 483 minecraft:terracotta
fill 511 143 484 511 146 484 minecraft:red_terracotta
fill 511 143 486 511 144 486 minecraft:red_terracotta
setblock 511 143 498 minecraft:terracotta
fill 511 143 499 511 146 499 minecraft:red_terracotta
setblock 511 143 503 minecraft:terracotta
fill 511 143 504 511 146 504 minecraft:red_terracotta
setblock 471 144 477 minecraft:terracotta
fill 471 144 478 471 144 481 minecraft:red_terracotta
setblock 471 144 482 minecraft:terracotta
fill 471 144 483 471 144 486 minecraft:red_terracotta
setblock 471 144 487 minecraft:terracotta
fill 471 144 488 471 144 491 minecraft:red_terracotta
setblock 471 144 492 minecraft:terracotta
fill 471 144 493 471 147 493 minecraft:red_terracotta
setblock 471 144 497 minecraft:terracotta
fill 471 144 498 471 147 498 minecraft:red_terracotta
setblock 471 144 502 minecraft:terracotta
fill 471 144 503 471 147 503 minecraft:red_terracotta
setblock 472 144 481 minecraft:terracotta
fill 472 144 482 472 147 482 minecraft:red_terracotta
setblock 472 144 496 minecraft:terracotta
fill 472 144 497 472 147 497 minecraft:red_terracotta
setblock 472 144 501 minecraft:terracotta
fill 472 144 502 472 147 502 minecraft:red_terracotta
setblock 473 144 500 minecraft:terracotta
fill 473 144 501 473 145 501 minecraft:red_terracotta
setblock 474 144 504 minecraft:terracotta
setblock 475 144 503 minecraft:terracotta
fill 475 144 504 475 147 504 minecraft:red_terracotta
setblock 476 144 503 minecraft:red_terracotta
setblock 483 144 504 minecraft:red_terracotta
setblock 484 144 504 minecraft:terracotta
fill 485 144 504 485 147 504 minecraft:red_terracotta
fill 486 144 464 486 146 464 minecraft:red_terracotta
fill 487 144 503 487 146 503 minecraft:red_terracotta
setblock 489 144 464 minecraft:terracotta
setblock 489 144 504 minecraft:terracotta
fill 490 144 464 490 147 464 minecraft:red_terracotta
setblock 490 144 503 minecraft:terracotta
fill 490 144 504 490 147 504 minecraft:red_terracotta
fill 491 144 503 491 147 503 minecraft:red_terracotta
setblock 494 144 464 minecraft:terracotta
setblock 494 144 504 minecraft:terracotta
fill 495 144 464 495 147 464 minecraft:red_terracotta
fill 495 144 504 495 147 504 minecraft:red_terracotta
fill 497 144 464 498 144 464 minecraft:red_terracotta
setblock 499 144 464 minecraft:terracotta
fill 500 144 464 500 147 464 minecraft:red_terracotta
fill 501 144 504 501 146 504 minecraft:red_terracotta
setblock 504 144 464 minecraft:terracotta
fill 504 144 465 504 147 465 minecraft:red_terracotta
setblock 504 144 503 minecraft:red_terracotta
setblock 504 144 504 minecraft:terracotta
fill 505 144 464 505 147 464 minecraft:red_terracotta
setblock 505 144 503 minecraft:terracotta
fill 505 144 504 505 147 504 minecraft:red_terracotta
fill 506 144 503 506 147 503 minecraft:red_terracotta
fill 507 144 502 507 147 502 minecraft:red_terracotta
setblock 508 144 465 minecraft:terracotta
setblock 509 144 464 minecraft:terracotta
fill 509 144 465 509 147 465 minecraft:red_terracotta
fill 509 144 500 509 147 500 minecraft:red_terracotta
setblock 509 144 504 minecraft:terracotta
fill 510 144 464 510 147 464 minecraft:red_terracotta
setblock 510 144 468 minecraft:terracotta
fill 510 144 479 510 145 479 minecraft:red_terracotta
setblock 510 144 483 minecraft:terracotta
setblock 510 144 498 minecraft:terracotta
fill 510 144 499 510 147 499 minecraft:red_terracotta
setblock 510 144 503 minecraft:terracotta
fill 510 144 504 510 147 504 minecraft:red_terracotta
setblock 511 144 467 minecraft:terracotta
fill 511 144 468 511 147 468 minecraft:red_terracotta
setblock 511 144 477 minecraft:terracotta
fill 511 144 478 511 147 478 minecraft:red_terracotta
setblock 511 144 482 minecraft:terracotta
fill 511 144 483 511 147 483 minecraft:red_terracotta
setblock 511 144 487 minecraft:terracotta
setblock 511 144 497 minecraft:terracotta
fill 511 144 498 511 147 498 minecraft:red_terracotta
setblock 511 144 502 minecraft:terracotta
fill 511 144 503 511 147 503 minecraft:red_terracotta
setblock 471 145 466 minecraft:terracotta
fill 471 145 467 471 148 467 minecraft:red_terracotta
fill 471 145 477 471 145 480 minecraft:red_terracotta
setblock 471 145 481 minecraft:terracotta
fill 471 145 482 471 145 485 minecraft:red_terracotta
setblock 471 145 486 minecraft:terracotta
fill 471 145 487 471 145 490 minecraft:red_terracotta
setblock 471 145 491 minecraft:terracotta
fill 471 145 492 471 148 492 minecraft:red_terracotta
setblock 471 145 496 minecraft:terracotta
fill 471 145 497 471 148 497 minecraft:red_terracotta
setblock 471 145 501 minecraft:terracotta
fill 471 145 502 471 148 502 minecraft:red_terracotta
fill 472 145 481 472 148 481 minecraft:red_terracotta
setblock 472 145 485 minecraft:terracotta
fill 472 145 486 472 146 488 minecraft:red_terracotta
setblock 472 145 496 minecraft:red_terracotta
setblock 472 145 500 minecraft:terracotta
fill 472 145 501 472 148 501 minecraft:red_terracotta
setblock 473 145 464 minecraft:terracotta
fill 473 145 486 475 147 488 minecraft:terracotta
setblock 473 145 504 minecraft:terracotta
fill 474 145 464 474 148 464 minecraft:red_terracotta
setblock 474 145 503 minecraft:terracotta
fill 474 145 504 474 148 504 minecraft:red_terracotta
fill 475 145 503 475 147 503 minecraft:red_terracotta
setblock 478 145 504 minecraft:terracotta
fill 479 145 504 482 145 504 minecraft:red_terracotta
setblock 483 145 504 minecraft:terracotta
fill 484 145 464 485 147 464 minecraft:red_terracotta
fill 484 145 504 484 148 504 minecraft:red_terracotta
fill 486 145 503 486 147 503 minecraft:red_terracotta
setblock 488 145 464 minecraft:terracotta
fill 488 145 465 491 145 465 minecraft:red_terracotta
setblock 488 145 504 minecraft:terracotta
fill 489 145 464 489 148 464 minecraft:red_terracotta
setblock 489 145 503 minecraft:terracotta
fill 489 145 504 489 148 504 minecraft:red_terracotta
fill 490 145 503 490 148 503 minecraft:red_terracotta
setblock 492 145 465 minecraft:terracotta
setblock 493 145 464 minecraft:terracotta
setblock 493 145 504 minecraft:terracotta
fill 494 145 464 494 148 464 minecraft:red_terracotta
fill 494 145 504 494 148 504 minecraft:red_terracotta
setblock 497 145 464 minecraft:red_terracotta
setblock 498 145 464 minecraft:terracotta
fill 499 145 464 499 148 464 minecraft:red_terracotta
fill 500 145 504 500 147 504 minecraft:red_terracotta
setblock 502 145 465 minecraft:terracotta
setblock 503 145 464 minecraft:terracotta
fill 503 145 465 503 148 465 minecraft:red_terracotta
setblock 503 145 503 minecraft:red_terracotta
setblock 503 145 504 minecraft:terracotta
fill 504 145 464 504 148 464 minecraft:red_terracotta
setblock 504 145 503 minecraft:terracotta
fill 504 145 504 504 148 504 minecraft:red_terracotta
fill 505 145 503 505 148 503 minecraft:red_terracotta
setblock 506 145 466 minecraft:terracotta
fill 506 145 502 506 148 502 minecraft:red_terracotta
setblock 507 145 465 minecraft:terracotta
fill 507 145 466 509 146 466 minecraft:red_terracotta
setblock 508 145 464 minecraft:terracotta
fill 508 145 465 508 148 465 minecraft:red_terracotta
setblock 508 145 504 minecraft:terracotta
fill 509 145 464 509 148 464 minecraft:red_terracotta
setblock 509 145 503 minecraft:terracotta
fill 509 145 504 509 148 504 minecraft:red_terracotta
setblock 510 145 467 minecraft:terracotta
fill 510 145 468 510 148 468 minecraft:red_terracotta
setblock 510 145 482 minecraft:terracotta
fill 510 145 483 510 146 485 minecraft:red_terracotta
setblock 510 145 497 minecraft:terracotta
fill 510 145 498 510 148 498 minecraft:red_terracotta
setblock 510 145 502 minecraft:terracotta
fill 510 145 503 510 148 503 minecraft:red_terracotta
setblock 511 145 466 minecraft:terracotta
fill 511 145 467 511 148 467 minecraft:red_terracotta
setblock 511 145 476 minecraft:terracotta
fill 511 145 477 511 146 477 minecraft:red_terracotta
setblock 511 145 481 minecraft:terracotta
fill 511 145 482 511 148 482 minecraft:red_terracotta
setblock 511 145 486 minecraft:terracotta
fill 511 145 487 511 146 489 minecraft:red_terracotta
fill 511 145 494 511 146 494 minecraft:red_terracotta
setblock 511 145 496 minecraft:terracotta
fill 511 145 497 511 148 497 minecraft:red_terracotta
setblock 511 145 501 minecraft:terracotta
fill 511 145 502 511 148 502 minecraft:red_terracotta
setblock 471 146 465 minecraft:terracotta
fill 471 146 466 471 149 466 minecraft:red_terracotta
fill 471 146 478 471 146 479 minecraft:red_terracotta
setblock 471 146 480 minecraft:terracotta
fill 471 146 481 471 146 484 minecraft:red_terracotta
setblock 471 146 485 minecraft:terracotta
fill 471 146 486 471 146 489 minecraft:red_terracotta
setblock 471 146 490 minecraft:terracotta
fill 471 146 491 471 149 491 minecraft:red_terracotta
setblock 471 146 495 minecraft:terracotta
fill 471 146 496 471 149 496 minecraft:red_terracotta
setblock 471 146 500 minecraft:terracotta
fill 471 146 501 471 149 501 minecraft:red_terracotta
setblock 472 146 464 minecraft:terracotta
setblock 472 146 484 minecraft:terracotta
fill 472 146 485 472 149 485 minecraft:red_terracotta
setblock 472 146 489 minecraft:terracotta
fill 472 146 490 472 149 490 minecraft:red_terracotta
setblock 472 146 499 minecraft:terracotta
fill 472 146 500 472 149 500 minecraft:red_terracotta
setblock 472 146 504 minecraft:terracotta
fill 473 146 464 473 149 464 minecraft:red_terracotta
setblock 473 146 503 minecraft:terracotta
fill 473 146 504 473 149 504 minecraft:red_terracotta
fill 474 146 503 474 148 503 minecraft:red_terracotta
setblock 477 146 504 minecraft:terracotta
fill 478 146 504 481 146 504 minecraft:red_terracotta
setblock 482 146 504 minecraft:terracotta
fill 483 146 464 483 149 464 minecraft:red_terracotta
fill 483 146 504 483 149 504 minecraft:red_terracotta
fill 485 146 503 485 148 503 minecraft:red_terracotta
setblock 486 146 465 minecraft:terracotta
setblock 487 146 464 minecraft:terracotta
fill 487 146 465 490 146 465 minecraft:red_terracotta
setblock 487 146 504 minecraft:terracotta
fill 488 146 464 488 149 464 minecraft:red_terracotta
setblock 488 146 503 minecraft:terracotta
fill 488 146 504 488 149 504 minecraft:red_terracotta
fill 489 146 503 489 149 503 minecraft:red_terracotta
setblock 491 146 465 minecraft:terracotta
setblock 492 146 464 minecraft:terracotta
fill 492 146 465 494 147 465 minecraft:red_terracotta
setblock 492 146 504 minecraft:terracotta
fill 493 146 464 493 149 464 minecraft:red_terracotta
fill 493 146 504 493 149 504 minecraft:red_terracotta
setblock 496 146 504 minecraft:red_terracotta
setblock 497 146 464 minecraft:terracotta
setblock 497 146 504 minecraft:terracotta
fill 498 146 464 498 149 464 minecraft:red_terracotta
fill 498 146 504 499 148 504 minecraft:red_terracotta
setblock 500 146 465 minecraft:red_terracotta
setblock 501 146 464 minecraft:red_terracotta
setblock 501 146 465 minecraft:terracotta
setblock 502 146 464 minecraft:terracotta
fill 502 146 465 502 149 465 minecraft:red_terracotta
setblock 502 146 503 minecraft:red_terracotta
setblock 502 146 504 minecraft:terracotta
fill 503 146 464 503 149 464 minecraft:red_terracotta
setblock 503 146 503 minecraft:terracotta
fill 503 146 504 503 149 504 minecraft:red_terracotta
setblock 504 146 466 minecraft:red_terracotta
fill 504 146 503 504 149 503 minecraft:red_terracotta
setblock 505 146 466 minecraft:terracotta
fill 505 146 502 505 149 502 minecraft:red_terracotta
setblock 506 146 465 minecraft:terracotta
fill 506 146 466 506 149 466 minecraft:red_terracotta
setblock 507 146 464 minecraft:terracotta
fill 507 146 465 507 149 465 minecraft:red_terracotta
setblock 507 146 504 minecraft:terracotta
fill 508 146 464 508 149 464 minecraft:red_terracotta
setblock 508 146 503 minecraft:terracotta
fill 508 146 504 508 149 504 minecraft:red_terracotta
setblock 509 146 467 minecraft:terracotta
setblock 509 146 502 minecraft:terracotta
fill 509 146 503 509 149 503 minecraft:red_terracotta
setblock 510 146 466 minecraft:terracotta
fill 510 146 467 510 149 467 minecraft:red_terracotta
fill 510 146 469 510 147 469 minecraft:red_terracotta
setblock 510 146 481 minecraft:terracotta
fill 510 146 482 510 149 482 minecraft:red_terracotta
setblock 510 146 486 minecraft:terracotta
fill 510 146 497 510 149 497 minecraft:red_terracotta
setblock 510 146 501 minecraft:terracotta
fill 510 146 502 510 149 502 minecraft:red_terracotta
setblock 511 146 465 minecraft:terracotta
fill 511 146 466 511 149 466 minecraft:red_terracotta
setblock 511 146 470 minecraft:terracotta
fill 511 146 471 511 149 471 minecraft:red_terracotta
setblock 511 146 480 minecraft:terracotta
fill 511 146 481 511 149 481 minecraft:red_terracotta
setblock 511 146 485 minecraft:terracotta
fill 511 146 486 511 149 486 minecraft:red_terracotta
setblock 511 146 490 minecraft:terracotta
fill 511 146 491 511 147 493 minecraft:red_terracotta
setblock 511 146 495 minecraft:terracotta
fill 511 146 496 511 149 496 minecraft:red_terracotta
setblock 511 146 500 minecraft:terracotta
fill 511 146 501 511 149 501 minecraft:red_terracotta
setblock 471 147 464 minecraft:terracotta
fill 471 147 465 471 150 465 minecraft:red_terracotta
setblock 471 147 468 minecraft:red_terracotta
setblock 471 147 478 minecraft:red_terracotta
setblock 471 147 479 minecraft:terracotta
fill 471 147 480 471 147 483 minecraft:red_terracotta
setblock 471 147 484 minecraft:terracotta
fill 471 147 485 471 147 488 minecraft:red_terracotta
setblock 471 147 489 minecraft:terracotta
fill 471 147 490 471 150 490 minecraft:red_terracotta
setblock 471 147 494 minecraft:terracotta
fill 471 147 495 471 150 495 minecraft:red_terracotta
setblock 471 147 499 minecraft:terracotta
fill 471 147 500 471 150 500 minecraft:red_terracotta
setblock 471 147 504 minecraft:terracotta
fill 472 147 464 472 150 464 minecraft:red_terracotta
setblock 472 147 483 minecraft:terracotta
fill 472 147 484 472 150 484 minecraft:red_terracotta
fill 472 147 486 472 147 487 minecraft:red_terracotta
setblock 472 147 488 minecraft:terracotta
fill 472 147 489 472 150 489 minecraft:red_terracotta
fill 472 147 491 472 147 492 minecraft:red_terracotta
setblock 472 147 498 minecraft:terracotta
fill 472 147 499 472 149 499 minecraft:red_terracotta
setblock 472 147 503 minecraft:terracotta
fill 472 147 504 472 150 504 minecraft:red_terracotta
fill 473 147 503 473 149 503 minecraft:red_terracotta
setblock 476 147 504 minecraft:terracotta
fill 477 147 504 480 147 504 minecraft:red_terracotta
setblock 481 147 464 minecraft:terracotta
setblock 481 147 504 minecraft:terracotta
fill 482 147 464 482 150 464 minecraft:red_terracotta
fill 482 147 504 482 150 504 minecraft:red_terracotta
setblock 484 147 465 minecraft:red_terracotta
fill 484 147 503 484 149 503 minecraft:red_terracotta
setblock 485 147 465 minecraft:terracotta
setblock 486 147 464 minecraft:terracotta
fill 486 147 465 489 147 465 minecraft:red_terracotta
setblock 486 147 504 minecraft:terracotta
fill 487 147 464 487 150 464 minecraft:red_terracotta
setblock 487 147 503 minecraft:terracotta
fill 487 147 504 487 150 504 minecraft:red_terracotta
setblock 488 147 466 minecraft:red_terracotta
fill 488 147 503 488 150 503 minecraft:red_terracotta
setblock 489 147 466 minecraft:terracotta
setblock 490 147 465 minecraft:terracotta
fill 490 147 466 490 150 466 minecraft:red_terracotta
setblock 491 147 464 minecraft:terracotta
fill 491 147 465 491 150 465 minecraft:red_terracotta
setblock 491 147 504 minecraft:terracotta
fill 492 147 464 492 150 464 minecraft:red_terracotta
fill 492 147 504 492 150 504 minecraft:red_terracotta
setblock 495 147 465 minecraft:terracotta
setblock 496 147 464 minecraft:terracotta
fill 496 147 465 499 147 465 minecraft:red_terracotta
setblock 496 147 504 minecraft:terracotta
fill 497 147 464 497 150 464 minecraft:red_terracotta
fill 497 147 504 497 150 504 minecraft:red_terracotta
setblock 500 147 465 minecraft:terracotta
setblock 501 147 464 minecraft:terracotta
fill 501 147 465 501 150 465 minecraft:red_terracotta
setblock 501 147 504 minecraft:terracotta
fill 502 147 464 502 150 464 minecraft:red_terracotta
fill 502 147 466 503 147 466 minecraft:red_terracotta
setblock 502 147 503 minecraft:terracotta
fill 502 147 504 502 150 504 minecraft:red_terracotta
fill 503 147 503 503 150 503 minecraft:red_terracotta
setblock 504 147 466 minecraft:terracotta
setblock 505 147 465 minecraft:terracotta
fill 505 147 466 505 150 466 minecraft:red_terracotta
setblock 506 147 464 minecraft:terracotta
fill 506 147 465 506 150 465 minecraft:red_terracotta
setblock 506 147 504 minecraft:terracotta
fill 507 147 464 507 150 464 minecraft:red_terracotta
fill 507 147 466 508 147 466 minecraft:red_terracotta
setblock 507 147 503 minecraft:terracotta
fill 507 147 504 507 150 504 minecraft:red_terracotta
setblock 508 147 502 minecraft:terracotta
fill 508 147 503 508 150 503 minecraft:red_terracotta
setblock 509 147 466 minecraft:terracotta
fill 509 147 467 509 149 468 minecraft:red_terracotta
setblock 509 147 501 minecraft:terracotta
fill 509 147 502 509 150 502 minecraft:red_terracotta
setblock 510 147 465 minecraft:terracotta
fill 510 147 466 510 150 466 minecraft:red_terracotta
setblock 510 147 480 minecraft:terracotta
fill 510 147 481 510 148 481 minecraft:red_terracotta
fill 510 147 483 510 147 484 minecraft:red_terracotta
setblock 510 147 485 minecraft:terracotta
fill 510 147 486 510 148 488 minecraft:red_terracotta
setblock 510 147 500 minecraft:terracotta
fill 510 147 501 510 150 501 minecraft:red_terracotta
setblock 511 147 464 minecraft:terracotta
fill 511 147 465 511 150 465 minecraft:red_terracotta
setblock 511 147 469 minecraft:terracotta
fill 511 147 470 511 150 470 minecraft:red_terracotta
setblock 511 147 479 minecraft:terracotta
fill 511 147 480 511 149 480 minecraft:red_terracotta
setblock 511 147 484 minecraft:terracotta
fill 511 147 485 511 150 485 minecraft:red_terracotta
fill 511 147 487 511 147 488 minecraft:red_terracotta
setblock 511 147 489 minecraft:terracotta
fill 511 147 490 511 150 490 minecraft:red_terracotta
setblock 511 147 494 minecraft:terracotta
fill 511 147 495 511 150 495 minecraft:red_terracotta
setblock 511 147 499 minecraft:terracotta
fill 511 147 500 511 150 500 minecraft:red_terracotta
setblock 511 147 504 minecraft:terracotta
fill 470 148 489 471 148 489 minecraft:red_terracotta
fill 470 148 490 470 148 499 minecraft:brown_terracotta
fill 470 148 501 470 151 501 minecraft:brown_terracotta
setblock 470 148 502 minecraft:red_terracotta
fill 470 148 503 470 151 504 minecraft:brown_terracotta
fill 471 148 464 471 151 464 minecraft:red_terracotta
setblock 471 148 468 minecraft:terracotta
setblock 471 148 478 minecraft:terracotta
fill 471 148 479 471 148 482 minecraft:red_terracotta
setblock 471 148 483 minecraft:terracotta
fill 471 148 484 471 148 487 minecraft:red_terracotta
setblock 471 148 488 minecraft:terracotta
setblock 471 148 493 minecraft:terracotta
fill 471 148 494 471 151 494 minecraft:red_terracotta
setblock 471 148 498 minecraft:terracotta
fill 471 148 499 471 151 499 minecraft:red_terracotta
setblock 471 148 503 minecraft:terracotta
fill 471 148 504 471 151 504 minecraft:red_terracotta
fill 472 148 465 472 149 465 minecraft:red_terracotta
setblock 472 148 482 minecraft:terracotta
fill 472 148 483 472 151 483 minecraft:red_terracotta
setblock 472 148 486 minecraft:red_terracotta
setblock 472 148 487 minecraft:terracotta
fill 472 148 488 472 151 488 minecraft:red_terracotta
setblock 472 148 491 minecraft:red_terracotta
setblock 472 148 492 minecraft:terracotta
fill 472 148 493 472 151 493 minecraft:red_terracotta
setblock 472 148 498 minecraft:red_terracotta
setblock 472 148 502 minecraft:terracotta
fill 472 148 503 472 150 503 minecraft:red_terracotta
setblock 473 148 485 minecraft:red_terracotta
fill 473 148 486 475 148 486 minecraft:terracotta
fill 473 148 487 473 151 487 minecraft:red_terracotta
fill 473 148 488 475 148 488 minecraft:terracotta
fill 474 148 487 475 157 487 minecraft:terracotta
fill 474 148 505 476 149 505 minecraft:brown_terracotta
setblock 475 148 464 minecraft:terracotta
setblock 475 148 504 minecraft:terracotta
fill 476 148 504 479 148 504 minecraft:red_terracotta
setblock 477 148 505 minecraft:red_terracotta
setblock 478 148 463 minecraft:red_terracotta
fill 478 148 505 479 151 505 minecraft:brown_terracotta
setblock 479 148 464 minecraft:red_terracotta
setblock 480 148 464 minecraft:terracotta
setblock 480 148 504 minecraft:terracotta
fill 481 148 463 482 151 463 minecraft:brown_terracotta
fill 481 148 464 481 151 464 minecraft:red_terracotta
fill 481 148 504 481 151 504 minecraft:red_terracotta
setblock 482 148 505 minecraft:red_terracotta
setblock 483 148 463 minecraft:red_terracotta
setblock 483 148 465 minecraft:red_terracotta
fill 483 148 503 483 150 503 minecraft:red_terracotta
fill 483 148 505 484 151 505 minecraft:brown_terracotta
fill 484 148 463 484 151 463 minecraft:brown_terracotta
setblock 484 148 464 minecraft:red_terracotta
setblock 484 148 465 minecraft:terracotta
setblock 485 148 464 minecraft:terracotta
fill 485 148 465 488 148 465 minecraft:red_terracotta
setblock 485 148 504 minecraft:terracotta
fill 486 148 463 486 151 463 minecraft:brown_terracotta
fill 486 148 464 486 151 464 minecraft:red_terracotta
fill 486 148 466 487 148 466 minecraft:red_terracotta
setblock 486 148 503 minecraft:terracotta
fill 486 148 504 486 151 504 minecraft:red_terracotta
fill 486 148 505 489 148 505 minecraft:brown_terracotta
setblock 487 148 463 minecraft:red_terracotta
fill 487 148 503 487 150 503 minecraft:red_terracotta
setblock 488 148 463 minecraft:brown_terracotta
setblock 488 148 466 minecraft:terracotta
setblock 489 148 463 minecraft:red_terracotta
setblock 489 148 465 minecraft:terracotta
fill 489 148 466 489 151 466 minecraft:red_terracotta
fill 490 148 463 497 149 463 minecraft:brown_terracotta
setblock 490 148 464 minecraft:terracotta
fill 490 148 465 490 151 465 minecraft:red_terracotta
setblock 490 148 504 minecraft:terracotta
setblock 490 148 505 minecraft:red_terracotta
fill 491 148 464 491 151 464 minecraft:red_terracotta
fill 491 148 466 492 148 466 minecraft:red_terracotta
fill 491 148 504 491 151 504 minecraft:red_terracotta
fill 491 148 505 491 151 505 minecraft:brown_terracotta
fill 492 148 465 493 148 465 minecraft:red_terracotta
setblock 494 148 465 minecraft:terracotta
setblock 494 148 505 minecraft:red_terracotta
setblock 495 148 464 minecraft:terracotta
fill 495 148 465 498 148 465 minecraft:red_terracotta
setblock 495 148 504 minecraft:terracotta
fill 496 148 464 496 151 464 minecraft:red_terracotta
fill 496 148 504 496 151 504 minecraft:red_terracotta
fill 498 148 463 500 148 463 minecraft:red_terracotta
setblock 499 148 465 minecraft:terracotta
setblock 500 148 464 minecraft:terracotta
fill 500 148 465 500 150 466 minecraft:red_terracotta
setblock 500 148 504 minecraft:terracotta
fill 501 148 463 502 151 463 minecraft:brown_terracotta
fill 501 148 464 501 151 464 minecraft:red_terracotta
fill 501 148 466 502 148 466 minecraft:red_terracotta
fill 501 148 498 501 148 503 minecraft:terracotta
fill 501 148 504 501 151 504 minecraft:red_terracotta
fill 502 148 498 503 149 502 minecraft:terracotta
fill 502 148 503 502 151 503 minecraft:red_terracotta
setblock 503 148 463 minecraft:red_terracotta
setblock 503 148 466 minecraft:terracotta
fill 504 148 463 506 149 463 minecraft:brown_terracotta
setblock 504 148 465 minecraft:terracotta
fill 504 148 466 504 151 466 minecraft:red_terracotta
fill 504 148 498 504 157 501 minecraft:terracotta
fill 504 148 502 504 150 502 minecraft:red_terracotta
setblock 505 148 464 minecraft:terracotta
fill 505 148 465 505 151 465 minecraft:red_terracotta
fill 505 148 467 506 148 467 minecraft:red_terracotta
setblock 505 148 504 minecraft:terracotta
fill 506 148 464 506 151 464 minecraft:red_terracotta
setblock 506 148 503 minecraft:terracotta
fill 506 148 504 506 151 504 minecraft:red_terracotta
setblock 507 148 466 minecraft:red_terracotta
setblock 507 148 467 minecraft:terracotta
setblock 507 148 502 minecraft:terracotta
fill 507 148 503 507 151 503 minecraft:red_terracotta
setblock 508 148 466 minecraft:terracotta
fill 508 148 467 508 151 467 minecraft:red_terracotta
fill 508 148 502 508 151 502 minecraft:red_terracotta
setblock 509 148 465 minecraft:terracotta
fill 509 148 466 509 151 466 minecraft:red_terracotta
setblock 509 148 500 minecraft:terracotta
fill 509 148 501 509 151 501 minecraft:red_terracotta
setblock 510 148 464 minecraft:terracotta
fill 510 148 465 510 151 465 minecraft:red_terracotta
setblock 510 148 469 minecraft:terracotta
fill 510 148 470 510 151 470 minecraft:red_terracotta
setblock 510 148 483 minecraft:red_terracotta
setblock 510 148 484 minecraft:terracotta
fill 510 148 485 510 151 485 minecraft:red_terracotta
setblock 510 148 489 minecraft:terracotta
fill 510 148 490 510 150 491 minecraft:red_terracotta
setblock 510 148 499 minecraft:terracotta
fill 510 148 500 510 151 500 minecraft:red_terracotta
setblock 510 148 504 minecraft:terracotta
fill 511 148 464 512 148 464 minecraft:red_terracotta
setblock 511 148 468 minecraft:terracotta
fill 511 148 469 511 151 469 minecraft:red_terracotta
setblock 511 148 479 minecraft:red_terracotta
setblock 511 148 483 minecraft:terracotta
fill 511 148 484 512 148 484 minecraft:red_terracotta
setblock 511 148 487 minecraft:red_terracotta
setblock 511 148 488 minecraft:terracotta
fill 511 148 489 511 151 489 minecraft:red_terracotta
fill 511 148 491 511 148 492 minecraft:red_terracotta
setblock 511 148 493 minecraft:terracotta
fill 511 148 494 511 151 494 minecraft:red_terracotta
setblock 511 148 498 minecraft:terracotta
fill 511 148 499 511 151 499 minecraft:red_terracotta
setblock 511 148 503 minecraft:terracotta
fill 511 148 504 511 151 504 minecraft:red_terracotta
setblock 512 148 468 minecraft:red_terracotta
fill 512 148 469 512 151 469 minecraft:brown_terracotta
setblock 512 148 470 minecraft:red_terracotta
fill 512 148 485 512 151 485 minecraft:brown_terracotta
fill 470 149 469 471 149 469 minecraft:red_terracotta
fill 470 149 470 470 151 477 minecraft:brown_terracotta
fill 470 149 479 470 151 482 minecraft:brown_terracotta
fill 470 149 483 471 149 483 minecraft:red_terracotta
fill 470 149 484 470 149 486 minecraft:brown_terracotta
fill 470 149 489 470 151 489 minecraft:brown_terracotta
setblock 470 149 490 minecraft:red_terracotta
fill 470 149 491 470 149 499 minecraft:brown_terracotta
setblock 470 149 500 minecraft:red_terracotta
fill 470 149 502 470 152 502 minecraft:brown_terracotta
setblock 471 149 467 minecraft:terracotta
fill 471 149 468 471 152 468 minecraft:red_terracotta
fill 471 149 479 471 149 481 minecraft:red_terracotta
setblock 471 149 482 minecraft:terracotta
fill 471 149 484 471 149 486 minecraft:red_terracotta
setblock 471 149 487 minecraft:terracotta
fill 471 149 488 471 151 489 minecraft:red_terracotta
setblock 471 149 492 minecraft:terracotta
fill 471 149 493 471 152 493 minecraft:red_terracotta
setblock 471 149 497 minecraft:terracotta
fill 471 149 498 471 152 498 minecraft:red_terracotta
setblock 471 149 502 minecraft:terracotta
fill 471 149 503 471 152 503 minecraft:red_terracotta
fill 472 149 482 472 150 482 minecraft:red_terracotta
setblock 472 149 486 minecraft:terracotta
fill 472 149 487 472 152 487 minecraft:red_terracotta
setblock 472 149 491 minecraft:terracotta
fill 472 149 492 472 152 492 minecraft:red_terracotta
fill 472 149 494 472 150 494 minecraft:red_terracotta
setblock 472 149 501 minecraft:terracotta
fill 472 149 502 472 150 502 minecraft:red_terracotta
setblock 473 149 463 minecraft:red_terracotta
setblock 473 149 485 minecraft:terracotta
fill 473 149 486 473 151 486 minecraft:red_terracotta
fill 473 149 488 473 150 488 minecraft:red_terracotta
setblock 474 149 464 minecraft:terracotta
fill 474 149 486 475 157 486 minecraft:terracotta
fill 474 149 488 475 157 488 minecraft:terracotta
setblock 474 149 504 minecraft:terracotta
fill 475 149 464 478 149 464 minecraft:red_terracotta
fill 475 149 504 478 149 504 minecraft:red_terracotta
fill 477 149 505 477 151 505 minecraft:brown_terracotta
setblock 478 149 463 minecraft:brown_terracotta
setblock 479 149 464 minecraft:terracotta
setblock 479 149 504 minecraft:terracotta
fill 480 149 464 480 152 464 minecraft:red_terracotta
fill 480 149 504 480 152 504 minecraft:red_terracotta
setblock 482 149 465 minecraft:red_terracotta
fill 482 149 505 482 151 505 minecraft:brown_terracotta
fill 483 149 463 483 151 463 minecraft:brown_terracotta
setblock 483 149 465 minecraft:terracotta
setblock 484 149 464 minecraft:terracotta
fill 484 149 465 486 149 466 minecraft:red_terracotta
setblock 484 149 504 minecraft:terracotta
fill 485 149 464 485 152 464 minecraft:red_terracotta
setblock 485 149 503 minecraft:terracotta
fill 485 149 504 485 152 504 minecraft:red_terracotta
fill 486 149 503 486 151 503 minecraft:red_terracotta
fill 486 149 505 487 151 505 minecraft:brown_terracotta
fill 487 149 463 487 151 463 minecraft:brown_terracotta
setblock 487 149 465 minecraft:red_terracotta
setblock 487 149 466 minecraft:terracotta
setblock 488 149 463 minecraft:red_terracotta
setblock 488 149 465 minecraft:terracotta
fill 488 149 466 488 152 466 minecraft:red_terracotta
setblock 488 149 505 minecraft:red_terracotta
fill 489 149 463 489 151 463 minecraft:brown_terracotta
setblock 489 149 464 minecraft:terracotta
fill 489 149 465 489 152 465 minecraft:red_terracotta
setblock 489 149 504 minecraft:terracotta
fill 489 149 505 490 151 505 minecraft:brown_terracotta
fill 490 149 464 490 152 464 minecraft:red_terracotta
fill 490 149 504 490 152 504 minecraft:red_terracotta
setblock 491 149 466 minecraft:red_terracotta
setblock 492 149 465 minecraft:red_terracotta
setblock 492 149 466 minecraft:terracotta
setblock 493 149 465 minecraft:terracotta
fill 493 149 466 493 151 466 minecraft:red_terracotta
setblock 494 149 464 minecraft:terracotta
fill 494 149 465 497 149 465 minecraft:red_terracotta
setblock 494 149 504 minecraft:terracotta
fill 494 149 505 494 151 505 minecraft:brown_terracotta
fill 495 149 464 495 152 464 minecraft:red_terracotta
fill 495 149 504 495 150 504 minecraft:red_terracotta
fill 498 149 463 499 151 463 minecraft:brown_terracotta
setblock 498 149 465 minecraft:terracotta
setblock 498 149 504 minecraft:red_terracotta
setblock 499 149 464 minecraft:terracotta
fill 499 149 465 499 151 466 minecraft:red_terracotta
setblock 499 149 504 minecraft:terracotta
fill 500 149 463 500 149 464 minecraft:red_terracotta
setblock 500 149 503 minecraft:terracotta
fill 500 149 504 500 152 504 minecraft:red_terracotta
setblock 501 149 466 minecraft:red_terracotta
fill 501 149 498 501 157 502 minecraft:terracotta
fill 501 149 503 501 152 503 minecraft:red_terracotta
setblock 501 149 505 minecraft:red_terracotta
setblock 502 149 466 minecraft:terracotta
fill 502 149 505 502 151 505 minecraft:brown_terracotta
fill 503 149 463 503 151 463 minecraft:brown_terracotta
setblock 503 149 465 minecraft:terracotta
fill 503 149 466 503 151 467 minecraft:red_terracotta
setblock 504 149 464 minecraft:terracotta
fill 504 149 465 504 152 465 minecraft:red_terracotta
fill 504 149 467 505 149 467 minecraft:red_terracotta
setblock 504 149 504 minecraft:terracotta
fill 505 149 464 505 152 464 minecraft:red_terracotta
setblock 505 149 503 minecraft:terracotta
fill 505 149 504 505 152 504 minecraft:red_terracotta
setblock 506 149 467 minecraft:terracotta
setblock 506 149 502 minecraft:terracotta
fill 506 149 503 506 152 503 minecraft:red_terracotta
setblock 507 149 466 minecraft:terracotta
fill 507 149 467 507 152 467 minecraft:red_terracotta
fill 507 149 502 507 152 502 minecraft:red_terracotta
setblock 508 149 465 minecraft:terracotta
fill 508 149 466 508 152 466 minecraft:red_terracotta
setblock 509 149 464 minecraft:terracotta
fill 509 149 465 509 152 465 minecraft:red_terracotta
setblock 509 149 469 minecraft:terracotta
fill 509 149 485 509 149 487 minecraft:red_terracotta
fill 509 149 500 509 150 500 minecraft:red_terracotta
setblock 509 149 504 minecraft:terracotta
setblock 509 149 505 minecraft:red_terracotta
fill 510 149 464 511 151 464 minecraft:red_terracotta
setblock 510 149 468 minecraft:terracotta
fill 510 149 469 510 152 469 minecraft:red_terracotta
setblock 510 149 483 minecraft:terracotta
fill 510 149 484 511 151 484 minecraft:red_terracotta
fill 510 149 486 510 149 487 minecraft:red_terracotta
setblock 510 149 488 minecraft:terracotta
fill 510 149 489 510 152 489 minecraft:red_terracotta
setblock 510 149 492 minecraft:red_terracotta
setblock 510 149 493 minecraft:terracotta
fill 510 149 496 510 150 496 minecraft:red_terracotta
setblock 510 149 498 minecraft:terracotta
fill 510 149 499 510 151 499 minecraft:red_terracotta
setblock 510 149 503 minecraft:terracotta
fill 510 149 504 510 152 504 minecraft:red_terracotta
setblock 511 149 467 minecraft:terracotta
fill 511 149 468 511 152 468 minecraft:red_terracotta
setblock 511 149 482 minecraft:terracotta
fill 511 149 483 512 149 483 minecraft:red_terracotta
setblock 511 149 487 minecraft:terracotta
fill 511 149 488 511 152 488 minecraft:red_terracotta
fill 511 149 491 512 149 491 minecraft:red_terracotta
setblock 511 149 492 minecraft:terracotta
fill 511 149 493 511 152 493 minecraft:red_terracotta
setblock 511 149 497 minecraft:terracotta
fill 511 149 498 511 152 498 minecraft:red_terracotta
setblock 511 149 502 minecraft:terracotta
fill 511 149 503 511 152 503 minecraft:red_terracotta
fill 512 149 464 512 151 464 minecraft:brown_terracotta
fill 512 149 468 512 151 468 minecraft:brown_terracotta
fill 512 149 470 512 151 470 minecraft:brown_terracotta
fill 512 149 480 512 151 482 minecraft:brown_terracotta
fill 512 149 484 512 151 484 minecraft:brown_terracotta
setblock 512 149 489 minecraft:red_terracotta
fill 512 149 492 512 151 497 minecraft:brown_terracotta
fill 470 150 469 470 151 469 minecraft:brown_terracotta
fill 470 150 483 470 151 484 minecraft:brown_terracotta
fill 470 150 485 471 150 485 minecraft:red_terracotta
fill 470 150 486 470 151 486 minecraft:brown_terracotta
fill 470 150 490 470 151 492 minecraft:brown_terracotta
setblock 470 150 493 minecraft:red_terracotta
fill 470 150 494 470 151 495 minecraft:brown_terracotta
setblock 470 150 496 minecraft:red_terracotta
fill 470 150 497 470 151 500 minecraft:brown_terracotta
setblock 471 150 466 minecraft:terracotta
fill 471 150 467 471 153 467 minecraft:red_terracotta
fill 471 150 469 471 151 469 minecraft:red_terracotta
fill 471 150 479 471 150 480 minecraft:red_terracotta
setblock 471 150 481 minecraft:terracotta
fill 471 150 482 471 151 484 minecraft:red_terracotta
setblock 471 150 486 minecraft:terracotta
fill 471 150 487 471 153 487 minecraft:red_terracotta
setblock 471 150 491 minecraft:terracotta
fill 471 150 492 471 153 492 minecraft:red_terracotta
setblock 471 150 496 minecraft:terracotta
fill 471 150 497 471 153 497 minecraft:red_terracotta
setblock 471 150 501 minecraft:terracotta
fill 471 150 502 471 152 502 minecraft:red_terracotta
setblock 472 150 485 minecraft:terracotta
fill 472 150 486 472 153 486 minecraft:red_terracotta
setblock 472 150 490 minecraft:terracotta
fill 472 150 491 472 153 491 minecraft:red_terracotta
fill 473 150 463 473 151 463 minecraft:brown_terracotta
setblock 473 150 464 minecraft:terracotta
setblock 473 150 466 minecraft:light[level=14]
setblock 473 150 474 minecraft:light[level=14]
setblock 473 150 482 minecraft:light[level=14]
setblock 473 150 485 minecraft:red_terracotta
setblock 473 150 489 minecraft:terracotta
setblock 473 150 490 minecraft:light[level=14]
setblock 473 150 498 minecraft:light[level=14]
setblock 473 150 504 minecraft:terracotta
setblock 473 150 505 minecraft:red_terracotta
fill 474 150 464 477 150 464 minecraft:red_terracotta
fill 474 150 504 477 150 504 minecraft:red_terracotta
fill 474 150 505 474 151 505 minecraft:brown_terracotta
setblock 475 150 505 minecraft:red_terracotta
setblock 476 150 463 minecraft:red_terracotta
fill 476 150 505 476 152 505 minecraft:brown_terracotta
setblock 478 150 463 minecraft:red_terracotta
setblock 478 150 464 minecraft:terracotta
setblock 478 150 504 minecraft:terracotta
fill 479 150 464 479 153 464 minecraft:red_terracotta
fill 479 150 504 479 151 504 minecraft:red_terracotta
setblock 481 150 465 minecraft:red_terracotta
setblock 481 150 466 minecraft:light[level=14]
setblock 481 150 474 minecraft:light[level=14]
setblock 481 150 482 minecraft:light[level=14]
setblock 481 150 490 minecraft:light[level=14]
setblock 481 150 498 minecraft:light[level=14]
setblock 482 150 465 minecraft:terracotta
setblock 483 150 464 minecraft:terracotta
fill 483 150 465 485 150 466 minecraft:red_terracotta
setblock 483 150 504 minecraft:terracotta
fill 484 150 464 484 153 464 minecraft:red_terracotta
setblock 484 150 503 minecraft:terracotta
fill 484 150 504 484 153 504 minecraft:red_terracotta
setblock 485 150 463 minecraft:red_terracotta
fill 485 150 503 485 151 503 minecraft:red_terracotta
setblock 486 150 465 minecraft:red_terracotta
setblock 486 150 466 minecraft:terracotta
setblock 487 150 465 minecraft:terracotta
fill 487 150 466 487 152 467 minecraft:red_terracotta
fill 488 150 463 488 152 463 minecraft:brown_terracotta
setblock 488 150 464 minecraft:terracotta
fill 488 150 465 488 153 465 minecraft:red_terracotta
setblock 488 150 504 minecraft:terracotta
fill 488 150 505 488 151 505 minecraft:brown_terracotta
fill 489 150 464 489 153 464 minecraft:red_terracotta
setblock 489 150 474 minecraft:light[level=14]
setblock 489 150 482 minecraft:light[level=14]
setblock 489 150 490 minecraft:light[level=14]
setblock 489 150 498 minecraft:light[level=14]
fill 489 150 504 489 152 504 minecraft:red_terracotta
fill 490 150 463 493 151 463 minecraft:brown_terracotta
setblock 491 150 466 minecraft:terracotta
setblock 492 150 465 minecraft:terracotta
fill 492 150 466 492 152 466 minecraft:red_terracotta
setblock 492 150 505 minecraft:red_terracotta
setblock 493 150 464 minecraft:terracotta
fill 493 150 465 496 150 465 minecraft:red_terracotta
setblock 493 150 504 minecraft:terracotta
fill 494 150 463 494 150 464 minecraft:red_terracotta
fill 494 150 466 494 151 466 minecraft:red_terracotta
setblock 494 150 504 minecraft:red_terracotta
fill 495 150 463 496 151 463 minecraft:brown_terracotta
setblock 495 150 505 minecraft:red_terracotta
fill 496 150 505 498 151 505 minecraft:brown_terracotta
setblock 497 150 463 minecraft:red_terracotta
setblock 497 150 465 minecraft:terracotta
fill 497 150 466 498 152 466 minecraft:red_terracotta
setblock 497 150 474 minecraft:light[level=14]
setblock 497 150 482 minecraft:light[level=14]
setblock 497 150 490 minecraft:light[level=14]
setblock 497 150 498 minecraft:light[level=14]
setblock 498 150 464 minecraft:terracotta
fill 498 150 465 498 153 465 minecraft:red_terracotta
setblock 498 150 504 minecraft:terracotta
fill 499 150 464 500 152 464 minecraft:red_terracotta
fill 499 150 504 499 150 505 minecraft:red_terracotta
fill 500 150 463 500 151 463 minecraft:brown_terracotta
fill 500 150 503 500 152 503 minecraft:red_terracotta
setblock 501 150 466 minecraft:terracotta
fill 501 150 505 501 152 505 minecraft:brown_terracotta
setblock 502 150 465 minecraft:terracotta
fill 502 150 466 502 152 467 minecraft:red_terracotta
fill 502 150 498 502 157 502 minecraft:terracotta
setblock 503 150 464 minecraft:terracotta
fill 503 150 465 503 153 465 minecraft:red_terracotta
fill 503 150 498 503 157 501 minecraft:terracotta
fill 503 150 502 503 151 502 minecraft:red_terracotta
setblock 503 150 504 minecraft:terracotta
fill 504 150 463 504 150 464 minecraft:red_terracotta
setblock 504 150 467 minecraft:red_terracotta
setblock 504 150 503 minecraft:terracotta
fill 504 150 504 504 153 504 minecraft:red_terracotta
fill 505 150 463 509 151 463 minecraft:brown_terracotta
setblock 505 150 467 minecraft:terracotta
setblock 505 150 474 minecraft:light[level=14]
setblock 505 150 482 minecraft:light[level=14]
setblock 505 150 490 minecraft:light[level=14]
setblock 505 150 502 minecraft:terracotta
fill 505 150 503 505 153 503 minecraft:red_terracotta
setblock 506 150 466 minecraft:terracotta
fill 506 150 467 506 153 467 minecraft:red_terracotta
fill 506 150 502 506 152 502 minecraft:red_terracotta
setblock 507 150 465 minecraft:terracotta
fill 507 150 466 507 153 466 minecraft:red_terracotta
setblock 508 150 464 minecraft:terracotta
fill 508 150 465 508 153 465 minecraft:red_terracotta
setblock 508 150 504 minecraft:terracotta
fill 509 150 464 509 153 464 minecraft:red_terracotta
setblock 509 150 467 minecraft:red_terracotta
setblock 509 150 468 minecraft:terracotta
fill 509 150 469 509 151 469 minecraft:red_terracotta
fill 509 150 486 509 150 487 minecraft:red_terracotta
setblock 509 150 488 minecraft:terracotta
fill 509 150 489 509 151 489 minecraft:red_terracotta
setblock 509 150 503 minecraft:terracotta
fill 509 150 504 509 153 504 minecraft:red_terracotta
fill 509 150 505 509 151 505 minecraft:brown_terracotta
fill 510 150 463 511 150 463 minecraft:red_terracotta
setblock 510 150 467 minecraft:terracotta
fill 510 150 468 510 153 468 minecraft:red_terracotta
fill 510 150 483 511 150 483 minecraft:red_terracotta
setblock 510 150 486 minecraft:red_terracotta
setblock 510 150 487 minecraft:terracotta
fill 510 150 488 510 153 488 minecraft:red_terracotta
setblock 510 150 492 minecraft:terracotta
fill 510 150 493 510 151 495 minecraft:red_terracotta
setblock 510 150 497 minecraft:terracotta
fill 510 150 498 510 151 498 minecraft:red_terracotta
setblock 510 150 502 minecraft:terracotta
fill 510 150 503 510 153 503 minecraft:red_terracotta
setblock 511 150 466 minecraft:terracotta
fill 511 150 467 511 153 467 minecraft:red_terracotta
setblock 511 150 471 minecraft:terracotta
setblock 511 150 481 minecraft:terracotta
fill 511 150 482 511 151 482 minecraft:red_terracotta
setblock 511 150 486 minecraft:terracotta
fill 511 150 487 511 153 487 minecraft:red_terracotta
setblock 511 150 491 minecraft:terracotta
fill 511 150 492 511 153 492 minecraft:red_terracotta
setblock 511 150 496 minecraft:terracotta
fill 511 150 497 511 153 497 minecraft:red_terracotta
setblock 511 150 501 minecraft:terracotta
fill 511 150 502 511 153 502 minecraft:red_terracotta
fill 512 150 463 512 151 463 minecraft:brown_terracotta
setblock 512 150 465 minecraft:red_terracotta
fill 512 150 471 512 151 471 minecraft:brown_terracotta
fill 512 150 472 512 150 473 minecraft:red_terracotta
fill 512 150 474 512 151 477 minecraft:brown_terracotta
fill 512 150 483 512 151 483 minecraft:brown_terracotta
fill 512 150 489 512 151 489 minecraft:brown_terracotta
setblock 512 150 490 minecraft:red_terracotta
fill 512 150 491 512 151 491 minecraft:brown_terracotta
setblock 512 150 501 minecraft:red_terracotta
fill 512 150 502 512 151 502 minecraft:brown_terracotta
setblock 470 151 485 minecraft:brown_terracotta
setblock 470 151 493 minecraft:brown_terracotta
setblock 470 151 496 minecraft:brown_terracotta
setblock 471 151 465 minecraft:terracotta
fill 471 151 466 471 153 466 minecraft:red_terracotta
fill 471 151 479 471 157 479 minecraft:magma_block
setblock 471 151 480 minecraft:terracotta
fill 471 151 481 471 152 481 minecraft:red_terracotta
setblock 471 151 485 minecraft:terracotta
fill 471 151 486 471 154 486 minecraft:red_terracotta
setblock 471 151 490 minecraft:terracotta
fill 471 151 491 471 154 491 minecraft:red_terracotta
setblock 471 151 495 minecraft:terracotta
fill 471 151 496 471 154 496 minecraft:red_terracotta
setblock 471 151 500 minecraft:terracotta
fill 471 151 501 471 152 501 minecraft:red_terracotta
setblock 472 151 464 minecraft:terracotta
setblock 472 151 484 minecraft:terracotta
fill 472 151 485 472 153 485 minecraft:red_terracotta
setblock 472 151 489 minecraft:terracotta
fill 472 151 490 472 154 490 minecraft:red_terracotta
setblock 472 151 494 minecraft:terracotta
setblock 472 151 504 minecraft:terracotta
fill 473 151 464 474 151 464 minecraft:red_terracotta
setblock 473 151 488 minecraft:terracotta
fill 473 151 489 473 152 489 minecraft:red_terracotta
fill 473 151 504 475 151 504 minecraft:red_terracotta
setblock 473 151 505 minecraft:brown_terracotta
setblock 475 151 505 minecraft:brown_terracotta
setblock 476 151 463 minecraft:brown_terracotta
setblock 477 151 464 minecraft:terracotta
setblock 478 151 463 minecraft:brown_terracotta
fill 478 151 464 478 153 464 minecraft:red_terracotta
setblock 478 151 504 minecraft:red_terracotta
setblock 480 151 465 minecraft:red_terracotta
setblock 481 151 465 minecraft:terracotta
setblock 482 151 464 minecraft:terracotta
fill 482 151 465 484 151 466 minecraft:red_terracotta
setblock 482 151 504 minecraft:terracotta
fill 483 151 464 483 154 464 minecraft:red_terracotta
fill 483 151 500 489 153 500 minecraft:terracotta
fill 483 151 504 483 154 504 minecraft:red_terracotta
setblock 484 151 503 minecraft:red_terracotta
setblock 485 151 463 minecraft:brown_terracotta
setblock 485 151 465 minecraft:red_terracotta
setblock 485 151 466 minecraft:terracotta
setblock 486 151 465 minecraft:terracotta
fill 486 151 466 486 152 467 minecraft:red_terracotta
setblock 487 151 464 minecraft:terracotta
fill 487 151 465 487 154 465 minecraft:red_terracotta
setblock 487 151 504 minecraft:terracotta
fill 488 151 464 488 154 464 minecraft:red_terracotta
setblock 488 151 467 minecraft:red_terracotta
fill 488 151 501 500 152 501 minecraft:terracotta
fill 488 151 504 488 153 504 minecraft:red_terracotta
setblock 490 151 466 minecraft:terracotta
setblock 491 151 465 minecraft:terracotta
fill 491 151 466 491 153 466 minecraft:red_terracotta
setblock 492 151 464 minecraft:terracotta
fill 492 151 465 495 151 465 minecraft:red_terracotta
setblock 492 151 504 minecraft:terracotta
setblock 492 151 505 minecraft:brown_terracotta
fill 493 151 464 494 153 464 minecraft:red_terracotta
setblock 493 151 504 minecraft:red_terracotta
setblock 494 151 463 minecraft:brown_terracotta
setblock 495 151 466 minecraft:terracotta
fill 495 151 502 500 152 502 minecraft:terracotta
fill 495 151 505 495 152 505 minecraft:brown_terracotta
setblock 496 151 465 minecraft:terracotta
fill 496 151 466 496 152 466 minecraft:red_terracotta
setblock 497 151 463 minecraft:brown_terracotta
setblock 497 151 464 minecraft:terracotta
fill 497 151 465 497 154 465 minecraft:red_terracotta
setblock 497 151 504 minecraft:terracotta
fill 498 151 464 498 154 464 minecraft:red_terracotta
fill 498 151 504 499 153 504 minecraft:red_terracotta
setblock 499 151 505 minecraft:brown_terracotta
setblock 500 151 465 minecraft:red_terracotta
setblock 500 151 466 minecraft:terracotta
setblock 501 151 465 minecraft:terracotta
fill 501 151 466 501 153 467 minecraft:red_terracotta
setblock 502 151 464 minecraft:terracotta
fill 502 151 465 502 154 465 minecraft:red_terracotta
setblock 502 151 504 minecraft:terracotta
fill 503 151 464 504 153 464 minecraft:red_terracotta
setblock 503 151 503 minecraft:terracotta
fill 503 151 504 503 154 504 minecraft:red_terracotta
setblock 504 151 463 minecraft:brown_terracotta
setblock 504 151 467 minecraft:terracotta
setblock 504 151 502 minecraft:terracotta
fill 504 151 503 504 154 503 minecraft:red_terracotta
setblock 505 151 466 minecraft:terracotta
fill 505 151 467 505 154 467 minecraft:red_terracotta
fill 505 151 502 505 153 502 minecraft:red_terracotta
setblock 506 151 465 minecraft:terracotta
fill 506 151 466 506 154 466 minecraft:red_terracotta
setblock 507 151 464 minecraft:terracotta
fill 507 151 465 507 154 465 minecraft:red_terracotta
setblock 507 151 504 minecraft:terracotta
fill 508 151 464 508 154 464 minecraft:red_terracotta
setblock 508 151 503 minecraft:terracotta
fill 508 151 504 508 154 504 minecraft:red_terracotta
setblock 509 151 467 minecraft:terracotta
fill 509 151 468 509 152 468 minecraft:red_terracotta
setblock 509 151 487 minecraft:terracotta
setblock 509 151 488 minecraft:red_terracotta
fill 509 151 502 509 152 502 minecraft:terracotta
fill 509 151 503 509 154 503 minecraft:red_terracotta
fill 510 151 463 511 151 463 minecraft:brown_terracotta
setblock 510 151 466 minecraft:terracotta
fill 510 151 467 510 154 467 minecraft:red_terracotta
setblock 510 151 486 minecraft:terracotta
fill 510 151 487 510 153 487 minecraft:red_terracotta
setblock 510 151 490 minecraft:red_terracotta
setblock 510 151 491 minecraft:terracotta
fill 510 151 492 510 154 492 minecraft:red_terracotta
setblock 510 151 501 minecraft:terracotta
fill 510 151 502 510 153 502 minecraft:red_terracotta
setblock 511 151 465 minecraft:terracotta
fill 511 151 466 511 154 466 minecraft:red_terracotta
setblock 511 151 470 minecraft:terracotta
fill 511 151 471 511 152 471 minecraft:red_terracotta
fill 511 151 483 511 152 483 minecraft:red_terracotta
setblock 511 151 485 minecraft:terracotta
fill 511 151 486 511 154 486 minecraft:red_terracotta
setblock 511 151 490 minecraft:terracotta
fill 511 151 491 511 154 491 minecraft:red_terracotta
setblock 511 151 495 minecraft:terracotta
fill 511 151 496 511 154 496 minecraft:red_terracotta
setblock 511 151 500 minecraft:terracotta
fill 511 151 501 511 153 501 minecraft:red_terracotta
setblock 512 151 465 minecraft:brown_terracotta
fill 512 151 472 512 151 473 minecraft:brown_terracotta
setblock 512 151 490 minecraft:brown_terracotta
setblock 512 151 501 minecraft:brown_terracotta
fill 470 152 463 470 152 480 minecraft:red_terracotta
setblock 470 152 481 minecraft:brown_terracotta
fill 470 152 482 470 152 489 minecraft:red_terracotta
setblock 470 152 490 minecraft:brown_terracotta
fill 470 152 491 470 152 493 minecraft:red_terracotta
setblock 470 152 494 minecraft:brown_terracotta
fill 470 152 495 470 152 501 minecraft:red_terracotta
fill 470 152 503 470 227 505 minecraft:red_terracotta
fill 471 152 463 478 152 463 minecraft:red_terracotta
setblock 471 152 464 minecraft:terracotta
fill 471 152 465 471 153 465 minecraft:red_terracotta
setblock 471 152 469 minecraft:terracotta
fill 471 152 480 471 157 480 minecraft:shroomlight
fill 471 152 482 471 152 483 minecraft:red_terracotta
setblock 471 152 484 minecraft:terracotta
fill 471 152 485 471 155 485 minecraft:red_terracotta
setblock 471 152 488 minecraft:red_terracotta
setblock 471 152 489 minecraft:terracotta
fill 471 152 490 471 155 490 minecraft:red_terracotta
setblock 471 152 494 minecraft:terracotta
fill 471 152 495 471 155 495 minecraft:red_terracotta
fill 471 152 499 485 152 499 minecraft:terracotta
setblock 471 152 500 minecraft:red_terracotta
setblock 471 152 504 minecraft:terracotta
fill 471 152 505 475 153 505 minecraft:red_terracotta
setblock 472 152 464 minecraft:red_terracotta
setblock 472 152 484 minecraft:red_terracotta
setblock 472 152 488 minecraft:terracotta
fill 472 152 489 472 155 489 minecraft:red_terracotta
setblock 472 152 493 minecraft:terracotta
fill 472 152 498 474 153 498 minecraft:terracotta
fill 472 152 504 473 152 504 minecraft:red_terracotta
fill 473 152 486 473 157 487 minecraft:terracotta
setblock 473 152 488 minecraft:red_terracotta
fill 473 152 500 482 153 500 minecraft:terracotta
setblock 477 152 464 minecraft:red_terracotta
fill 477 152 505 494 152 505 minecraft:red_terracotta
setblock 480 152 465 minecraft:terracotta
setblock 481 152 463 minecraft:brown_terracotta
setblock 481 152 464 minecraft:terracotta
fill 481 152 465 484 152 465 minecraft:red_terracotta
setblock 481 152 504 minecraft:terracotta
fill 482 152 463 482 153 464 minecraft:red_terracotta
fill 482 152 466 483 152 466 minecraft:red_terracotta
fill 482 152 501 487 152 501 minecraft:terracotta
fill 482 152 504 482 154 504 minecraft:red_terracotta
fill 483 152 463 487 227 463 minecraft:red_terracotta
setblock 484 152 466 minecraft:terracotta
setblock 485 152 465 minecraft:terracotta
fill 485 152 466 485 152 467 minecraft:red_terracotta
setblock 486 152 464 minecraft:terracotta
fill 486 152 465 486 155 465 minecraft:red_terracotta
setblock 486 152 504 minecraft:terracotta
fill 487 152 464 487 155 464 minecraft:red_terracotta
fill 487 152 504 487 153 504 minecraft:red_terracotta
fill 489 152 463 490 229 463 minecraft:red_terracotta
setblock 489 152 466 minecraft:terracotta
setblock 490 152 465 minecraft:terracotta
fill 490 152 466 490 153 466 minecraft:red_terracotta
fill 490 152 500 495 152 500 minecraft:terracotta
setblock 491 152 463 minecraft:brown_terracotta
setblock 491 152 464 minecraft:terracotta
fill 491 152 465 494 152 465 minecraft:red_terracotta
fill 492 152 463 492 155 464 minecraft:red_terracotta
fill 492 152 502 494 152 502 minecraft:terracotta
fill 493 152 463 494 153 463 minecraft:red_terracotta
setblock 495 152 463 minecraft:brown_terracotta
setblock 495 152 465 minecraft:terracotta
fill 496 152 463 505 152 463 minecraft:red_terracotta
setblock 496 152 464 minecraft:terracotta
fill 496 152 465 496 155 465 minecraft:red_terracotta
fill 496 152 505 500 153 505 minecraft:red_terracotta
fill 497 152 464 497 155 464 minecraft:red_terracotta
fill 497 152 504 497 153 504 minecraft:red_terracotta
setblock 499 152 465 minecraft:red_terracotta
setblock 499 152 466 minecraft:terracotta
setblock 500 152 465 minecraft:terracotta
fill 500 152 466 500 153 467 minecraft:red_terracotta
setblock 501 152 464 minecraft:terracotta
fill 501 152 465 501 155 465 minecraft:red_terracotta
setblock 501 152 504 minecraft:terracotta
fill 502 152 464 502 155 464 minecraft:red_terracotta
setblock 502 152 503 minecraft:terracotta
fill 502 152 504 502 155 505 minecraft:red_terracotta
setblock 503 152 466 minecraft:red_terracotta
setblock 503 152 467 minecraft:terracotta
fill 503 152 502 503 157 502 minecraft:terracotta
fill 503 152 503 503 155 503 minecraft:red_terracotta
fill 503 152 505 504 229 505 minecraft:red_terracotta
setblock 504 152 466 minecraft:terracotta
fill 504 152 467 504 154 467 minecraft:red_terracotta
setblock 504 152 502 minecraft:red_terracotta
setblock 505 152 465 minecraft:terracotta
fill 505 152 466 505 155 466 minecraft:red_terracotta
fill 505 152 505 506 152 505 minecraft:brown_terracotta
setblock 506 152 463 minecraft:brown_terracotta
setblock 506 152 464 minecraft:terracotta
fill 506 152 465 506 155 465 minecraft:red_terracotta
setblock 506 152 504 minecraft:terracotta
fill 507 152 463 507 155 464 minecraft:red_terracotta
setblock 507 152 503 minecraft:terracotta
fill 507 152 504 507 155 505 minecraft:red_terracotta
setblock 508 152 463 minecraft:brown_terracotta
setblock 508 152 502 minecraft:terracotta
fill 508 152 503 508 154 503 minecraft:red_terracotta
fill 508 152 505 512 152 505 minecraft:red_terracotta
fill 509 152 463 512 152 463 minecraft:red_terracotta
setblock 509 152 466 minecraft:terracotta
fill 509 152 467 509 153 467 minecraft:red_terracotta
setblock 510 152 464 minecraft:red_terracotta
setblock 510 152 465 minecraft:terracotta
fill 510 152 466 510 154 466 minecraft:red_terracotta
setblock 510 152 485 minecraft:terracotta
setblock 510 152 486 minecraft:red_terracotta
setblock 510 152 490 minecraft:terracotta
fill 510 152 491 510 155 491 minecraft:red_terracotta
fill 510 152 493 510 152 494 minecraft:red_terracotta
setblock 510 152 500 minecraft:terracotta
setblock 510 152 501 minecraft:red_terracotta
setblock 511 152 464 minecraft:terracotta
fill 511 152 465 512 155 465 minecraft:red_terracotta
setblock 511 152 469 minecraft:terracotta
fill 511 152 470 512 153 470 minecraft:red_terracotta
setblock 511 152 484 minecraft:terracotta
fill 511 152 485 512 153 485 minecraft:red_terracotta
setblock 511 152 489 minecraft:terracotta
fill 511 152 490 512 155 490 minecraft:red_terracotta
setblock 511 152 494 minecraft:terracotta
fill 511 152 495 512 155 495 minecraft:red_terracotta
setblock 511 152 499 minecraft:terracotta
fill 511 152 500 512 153 500 minecraft:red_terracotta
setblock 511 152 504 minecraft:terracotta
fill 512 152 464 512 229 464 minecraft:red_terracotta
fill 512 152 466 512 152 469 minecraft:red_terracotta
fill 512 152 471 512 229 474 minecraft:red_terracotta
setblock 512 152 475 minecraft:brown_terracotta
fill 512 152 476 512 153 481 minecraft:red_terracotta
setblock 512 152 482 minecraft:brown_terracotta
fill 512 152 483 512 152 484 minecraft:red_terracotta
fill 512 152 486 512 152 489 minecraft:red_terracotta
fill 512 152 491 512 229 492 minecraft:red_terracotta
setblock 512 152 493 minecraft:brown_terracotta
fill 512 152 494 512 153 494 minecraft:red_terracotta
setblock 512 152 496 minecraft:brown_terracotta
fill 512 152 497 512 153 499 minecraft:red_terracotta
fill 512 152 501 512 153 504 minecraft:red_terracotta
fill 470 153 463 470 153 468 minecraft:red_terracotta
setblock 470 153 469 minecraft:brown_terracotta
fill 470 153 470 470 229 470 minecraft:red_terracotta
setblock 470 153 471 minecraft:brown_terracotta
fill 470 153 472 470 153 485 minecraft:red_terracotta
setblock 470 153 486 minecraft:brown_terracotta
fill 470 153 487 470 229 488 minecraft:red_terracotta
fill 470 153 489 470 154 489 minecraft:brown_terracotta
fill 470 153 490 470 229 491 minecraft:red_terracotta
setblock 470 153 492 minecraft:brown_terracotta
fill 470 153 493 470 227 498 minecraft:red_terracotta
fill 470 153 499 470 153 500 minecraft:brown_terracotta
fill 470 153 501 470 226 502 minecraft:red_terracotta
fill 471 153 463 471 153 464 minecraft:red_terracotta
setblock 471 153 468 minecraft:terracotta
fill 471 153 481 471 157 481 minecraft:magma_block
setblock 471 153 482 minecraft:red_terracotta
setblock 471 153 483 minecraft:terracotta
fill 471 153 484 471 154 484 minecraft:red_terracotta
setblock 471 153 488 minecraft:terracotta
fill 471 153 489 471 156 489 minecraft:red_terracotta
setblock 471 153 493 minecraft:terracotta
fill 471 153 494 471 156 494 minecraft:red_terracotta
fill 471 153 498 471 153 499 minecraft:terracotta
setblock 471 153 504 minecraft:red_terracotta
fill 472 153 463 476 226 463 minecraft:red_terracotta
setblock 472 153 487 minecraft:terracotta
fill 472 153 488 472 155 488 minecraft:red_terracotta
setblock 472 153 492 minecraft:terracotta
fill 472 153 493 472 154 493 minecraft:red_terracotta
fill 472 153 499 482 153 499 minecraft:terracotta
fill 473 153 488 473 157 488 minecraft:terracotta
fill 476 153 505 480 225 505 minecraft:red_terracotta
setblock 477 153 463 minecraft:brown_terracotta
fill 478 153 463 481 226 463 minecraft:red_terracotta
setblock 480 153 464 minecraft:terracotta
fill 480 153 465 483 153 465 minecraft:red_terracotta
fill 481 153 464 481 156 464 minecraft:red_terracotta
setblock 481 153 504 minecraft:red_terracotta
setblock 481 153 505 minecraft:brown_terracotta
setblock 482 153 466 minecraft:red_terracotta
fill 482 153 505 490 153 505 minecraft:red_terracotta
setblock 483 153 466 minecraft:terracotta
setblock 484 153 465 minecraft:terracotta
fill 484 153 466 487 153 466 minecraft:red_terracotta
setblock 485 153 464 minecraft:terracotta
fill 485 153 465 485 156 465 minecraft:red_terracotta
fill 485 153 501 496 153 501 minecraft:terracotta
setblock 485 153 504 minecraft:terracotta
fill 486 153 464 486 156 464 minecraft:red_terracotta
setblock 486 153 504 minecraft:red_terracotta
fill 488 153 463 488 229 463 minecraft:red_terracotta
setblock 488 153 466 minecraft:terracotta
setblock 489 153 465 minecraft:terracotta
fill 489 153 466 489 154 466 minecraft:red_terracotta
setblock 490 153 464 minecraft:terracotta
fill 490 153 465 493 153 465 minecraft:red_terracotta
setblock 490 153 500 minecraft:terracotta
fill 491 153 463 491 156 464 minecraft:red_terracotta
fill 491 153 505 492 153 505 minecraft:brown_terracotta
fill 493 153 505 495 162 505 minecraft:red_terracotta
setblock 494 153 465 minecraft:terracotta
fill 495 153 463 498 153 463 minecraft:red_terracotta
setblock 495 153 464 minecraft:terracotta
fill 495 153 465 495 155 465 minecraft:red_terracotta
fill 496 153 464 496 156 464 minecraft:red_terracotta
setblock 497 153 466 minecraft:red_terracotta
setblock 498 153 466 minecraft:terracotta
fill 499 153 463 500 153 463 minecraft:brown_terracotta
setblock 499 153 464 minecraft:red_terracotta
setblock 499 153 465 minecraft:terracotta
fill 499 153 466 499 156 466 minecraft:red_terracotta
setblock 500 153 464 minecraft:terracotta
fill 500 153 465 500 156 465 minecraft:red_terracotta
fill 500 153 502 500 156 502 minecraft:orange_concrete
setblock 500 153 504 minecraft:terracotta
fill 501 153 463 501 156 464 minecraft:red_terracotta
setblock 501 153 503 minecraft:terracotta
fill 501 153 504 501 156 505 minecraft:red_terracotta
fill 502 153 463 503 225 463 minecraft:red_terracotta
setblock 502 153 466 minecraft:red_terracotta
setblock 502 153 467 minecraft:terracotta
fill 502 153 503 502 156 503 minecraft:red_terracotta
setblock 503 153 466 minecraft:terracotta
fill 503 153 467 503 155 467 minecraft:red_terracotta
setblock 504 153 463 minecraft:brown_terracotta
setblock 504 153 465 minecraft:terracotta
fill 504 153 466 504 156 466 minecraft:red_terracotta
fill 504 153 502 504 157 502 minecraft:terracotta
fill 505 153 463 506 229 463 minecraft:red_terracotta
setblock 505 153 464 minecraft:terracotta
fill 505 153 465 505 156 465 minecraft:red_terracotta
setblock 505 153 504 minecraft:terracotta
fill 505 153 505 506 227 505 minecraft:red_terracotta
fill 506 153 464 506 156 464 minecraft:red_terracotta
fill 506 153 502 508 154 502 minecraft:orange_concrete
setblock 506 153 503 minecraft:terracotta
fill 506 153 504 506 156 504 minecraft:red_terracotta
fill 507 153 503 507 155 503 minecraft:red_terracotta
fill 508 153 463 511 153 463 minecraft:red_terracotta
setblock 508 153 466 minecraft:terracotta
fill 508 153 505 508 229 505 minecraft:red_terracotta
setblock 509 153 465 minecraft:terracotta
setblock 509 153 466 minecraft:red_terracotta
fill 509 153 505 509 154 505 minecraft:brown_terracotta
setblock 510 153 464 minecraft:terracotta
fill 510 153 465 510 154 465 minecraft:red_terracotta
setblock 510 153 469 minecraft:terracotta
setblock 510 153 489 minecraft:terracotta
fill 510 153 490 510 155 490 minecraft:red_terracotta
setblock 510 153 493 minecraft:red_terracotta
setblock 510 153 494 minecraft:terracotta
setblock 510 153 504 minecraft:terracotta
fill 510 153 505 512 153 505 minecraft:red_terracotta
fill 511 153 464 511 154 464 minecraft:red_terracotta
setblock 511 153 468 minecraft:terracotta
fill 511 153 469 511 154 469 minecraft:red_terracotta
setblock 511 153 484 minecraft:red_terracotta
setblock 511 153 488 minecraft:terracotta
fill 511 153 489 512 156 489 minecraft:red_terracotta
setblock 511 153 493 minecraft:terracotta
fill 511 153 494 511 156 494 minecraft:red_terracotta
setblock 511 153 498 minecraft:terracotta
setblock 511 153 499 minecraft:red_terracotta
setblock 511 153 503 minecraft:terracotta
fill 511 153 504 511 154 504 minecraft:red_terracotta
setblock 512 153 463 minecraft:brown_terracotta
fill 512 153 466 512 229 468 minecraft:red_terracotta
setblock 512 153 469 minecraft:brown_terracotta
fill 512 153 475 512 229 475 minecraft:red_terracotta
fill 512 153 482 512 227 483 minecraft:red_terracotta
setblock 512 153 484 minecraft:brown_terracotta
fill 512 153 486 512 225 487 minecraft:red_terracotta
fill 512 153 488 512 154 488 minecraft:brown_terracotta
fill 512 153 493 512 229 493 minecraft:red_terracotta
setblock 512 153 496 minecraft:red_terracotta
fill 470 154 463 470 227 465 minecraft:red_terracotta
setblock 470 154 466 minecraft:brown_terracotta
fill 470 154 467 470 229 469 minecraft:red_terracotta
fill 470 154 471 470 226 484 minecraft:red_terracotta
setblock 470 154 485 minecraft:brown_terracotta
fill 470 154 486 470 230 486 minecraft:red_terracotta
fill 470 154 492 470 229 492 minecraft:red_terracotta
fill 470 154 499 470 227 499 minecraft:red_terracotta
setblock 470 154 500 minecraft:brown_terracotta
fill 471 154 463 471 229 463 minecraft:red_terracotta
setblock 471 154 483 minecraft:red_terracotta
setblock 471 154 487 minecraft:terracotta
fill 471 154 488 471 157 488 minecraft:red_terracotta
setblock 471 154 492 minecraft:terracotta
fill 471 154 493 471 157 493 minecraft:red_terracotta
fill 471 154 499 478 154 499 minecraft:orange_concrete
fill 471 154 505 471 229 505 minecraft:red_terracotta
fill 472 154 484 473 154 485 minecraft:orange_concrete
fill 472 154 486 472 157 486 minecraft:terracotta
fill 472 154 487 472 155 487 minecraft:red_terracotta
setblock 472 154 491 minecraft:terracotta
fill 472 154 492 472 157 492 minecraft:red_terracotta
setblock 472 154 505 minecraft:brown_terracotta
fill 473 154 489 476 154 490 minecraft:orange_concrete
fill 473 154 505 475 225 505 minecraft:red_terracotta
fill 474 154 484 476 154 484 minecraft:orange_concrete
fill 475 154 485 476 155 485 minecraft:orange_concrete
fill 476 154 486 477 154 488 minecraft:orange_concrete
fill 477 154 463 477 227 463 minecraft:red_terracotta
fill 478 154 500 487 154 500 minecraft:orange_concrete
setblock 479 154 464 minecraft:terracotta
fill 480 154 464 480 154 465 minecraft:red_terracotta
fill 481 154 465 482 154 465 minecraft:red_terracotta
fill 481 154 505 481 230 505 minecraft:red_terracotta
setblock 482 154 463 minecraft:brown_terracotta
fill 482 154 464 482 155 464 minecraft:red_terracotta
setblock 482 154 466 minecraft:terracotta
setblock 482 154 505 minecraft:brown_terracotta
setblock 483 154 465 minecraft:terracotta
fill 483 154 466 486 154 466 minecraft:red_terracotta
fill 483 154 505 492 162 505 minecraft:red_terracotta
setblock 484 154 464 minecraft:terracotta
fill 484 154 465 484 157 465 minecraft:red_terracotta
setblock 484 154 504 minecraft:terracotta
fill 485 154 464 485 157 464 minecraft:red_terracotta
setblock 485 154 504 minecraft:red_terracotta
setblock 487 154 466 minecraft:terracotta
setblock 488 154 465 minecraft:terracotta
setblock 488 154 466 minecraft:red_terracotta
setblock 489 154 464 minecraft:terracotta
fill 489 154 465 492 154 465 minecraft:red_terracotta
fill 490 154 464 490 156 464 minecraft:red_terracotta
fill 490 154 501 495 154 501 minecraft:orange_concrete
setblock 493 154 463 minecraft:brown_terracotta
setblock 493 154 464 minecraft:red_terracotta
setblock 493 154 465 minecraft:terracotta
fill 494 154 463 497 225 463 minecraft:red_terracotta
setblock 494 154 464 minecraft:terracotta
setblock 494 154 465 minecraft:red_terracotta
fill 495 154 464 495 157 464 minecraft:red_terracotta
fill 496 154 505 499 162 505 minecraft:red_terracotta
setblock 497 154 466 minecraft:terracotta
setblock 498 154 463 minecraft:brown_terracotta
setblock 498 154 465 minecraft:terracotta
fill 498 154 466 498 156 466 minecraft:red_terracotta
fill 498 154 498 499 154 502 minecraft:orange_concrete
setblock 498 154 504 minecraft:red_terracotta
fill 499 154 463 500 229 463 minecraft:red_terracotta
setblock 499 154 464 minecraft:terracotta
fill 499 154 465 499 157 465 minecraft:red_terracotta
fill 499 154 496 502 154 497 minecraft:orange_concrete
fill 499 154 503 500 154 503 minecraft:orange_concrete
setblock 499 154 504 minecraft:terracotta
fill 500 154 464 500 157 464 minecraft:red_terracotta
fill 500 154 466 501 154 466 minecraft:red_terracotta
fill 500 154 498 500 156 501 minecraft:orange_concrete
fill 500 154 504 500 157 504 minecraft:red_terracotta
setblock 500 154 505 minecraft:brown_terracotta
setblock 501 154 467 minecraft:terracotta
fill 501 154 495 506 154 495 minecraft:orange_concrete
fill 501 154 503 501 155 503 minecraft:red_terracotta
setblock 502 154 466 minecraft:terracotta
fill 502 154 467 502 155 467 minecraft:red_terracotta
setblock 503 154 464 minecraft:red_terracotta
setblock 503 154 465 minecraft:terracotta
fill 503 154 466 503 157 466 minecraft:red_terracotta
fill 503 154 496 507 154 496 minecraft:orange_concrete
fill 504 154 463 504 229 463 minecraft:red_terracotta
setblock 504 154 464 minecraft:terracotta
fill 504 154 465 504 157 465 minecraft:red_terracotta
setblock 504 154 504 minecraft:terracotta
fill 505 154 464 505 157 464 minecraft:red_terracotta
fill 505 154 497 508 154 497 minecraft:orange_concrete
fill 505 154 502 505 154 503 minecraft:terracotta
fill 505 154 504 505 157 504 minecraft:red_terracotta
fill 506 154 498 508 154 498 minecraft:orange_concrete
fill 506 154 503 506 155 503 minecraft:red_terracotta
setblock 507 154 466 minecraft:terracotta
fill 507 154 499 508 155 501 minecraft:orange_concrete
fill 508 154 463 510 225 463 minecraft:red_terracotta
setblock 508 154 465 minecraft:terracotta
setblock 508 154 466 minecraft:red_terracotta
setblock 509 154 464 minecraft:terracotta
setblock 509 154 465 minecraft:red_terracotta
fill 509 154 499 509 154 500 minecraft:orange_concrete
setblock 509 154 504 minecraft:terracotta
fill 510 154 464 510 155 464 minecraft:red_terracotta
setblock 510 154 488 minecraft:terracotta
setblock 510 154 489 minecraft:red_terracotta
setblock 510 154 493 minecraft:terracotta
fill 510 154 504 510 155 504 minecraft:red_terracotta
setblock 510 154 505 minecraft:brown_terracotta
setblock 511 154 463 minecraft:brown_terracotta
setblock 511 154 467 minecraft:terracotta
fill 511 154 468 511 155 468 minecraft:red_terracotta
setblock 511 154 487 minecraft:terracotta
fill 511 154 488 511 157 488 minecraft:red_terracotta
setblock 511 154 492 minecraft:terracotta
fill 511 154 493 511 157 493 minecraft:red_terracotta
setblock 511 154 497 minecraft:terracotta
setblock 511 154 502 minecraft:terracotta
fill 511 154 503 512 154 503 minecraft:red_terracotta
fill 511 154 505 512 229 505 minecraft:red_terracotta
fill 512 154 463 512 230 463 minecraft:red_terracotta
fill 512 154 469 512 226 470 minecraft:red_terracotta
setblock 512 154 476 minecraft:brown_terracotta
fill 512 154 477 512 225 481 minecraft:red_terracotta
fill 512 154 484 512 229 485 minecraft:red_terracotta
setblock 512 154 494 minecraft:brown_terracotta
fill 512 154 496 512 154 497 minecraft:brown_terracotta
fill 512 154 498 512 226 502 minecraft:red_terracotta
setblock 512 154 504 minecraft:brown_terracotta
fill 470 155 466 470 229 466 minecraft:red_terracotta
fill 470 155 485 470 229 485 minecraft:red_terracotta
fill 470 155 489 470 225 489 minecraft:red_terracotta
fill 470 155 500 470 229 500 minecraft:red_terracotta
setblock 471 155 486 minecraft:terracotta
fill 471 155 487 471 157 487 minecraft:red_terracotta
setblock 471 155 491 minecraft:terracotta
fill 471 155 492 471 157 492 minecraft:red_terracotta
setblock 471 155 496 minecraft:terracotta
fill 472 155 485 473 156 485 minecraft:orange_concrete
setblock 472 155 490 minecraft:terracotta
fill 472 155 491 472 157 491 minecraft:red_terracotta
fill 472 155 505 472 229 505 minecraft:red_terracotta
fill 473 155 484 475 155 484 minecraft:orange_concrete
fill 473 155 489 474 155 490 minecraft:orange_concrete
fill 475 155 489 476 155 489 minecraft:orange_concrete
fill 476 155 486 476 156 488 minecraft:orange_concrete
fill 479 155 464 480 156 464 minecraft:red_terracotta
setblock 481 155 465 minecraft:red_terracotta
fill 482 155 463 482 229 463 minecraft:red_terracotta
setblock 482 155 465 minecraft:terracotta
fill 482 155 505 482 162 505 minecraft:red_terracotta
setblock 483 155 464 minecraft:terracotta
fill 483 155 465 483 155 466 minecraft:red_terracotta
fill 484 155 464 484 157 464 minecraft:red_terracotta
fill 484 155 466 485 155 466 minecraft:red_terracotta
setblock 486 155 466 minecraft:terracotta
setblock 487 155 465 minecraft:terracotta
setblock 487 155 466 minecraft:red_terracotta
setblock 488 155 464 minecraft:terracotta
fill 488 155 465 490 155 465 minecraft:red_terracotta
fill 489 155 464 489 157 464 minecraft:red_terracotta
fill 493 155 463 493 226 463 minecraft:red_terracotta
setblock 493 155 464 minecraft:terracotta
fill 494 155 464 494 157 464 minecraft:red_terracotta
setblock 497 155 465 minecraft:terracotta
fill 498 155 463 498 229 463 minecraft:red_terracotta
setblock 498 155 464 minecraft:terracotta
fill 498 155 465 498 157 465 minecraft:red_terracotta
setblock 498 155 504 minecraft:terracotta
fill 499 155 464 499 157 464 minecraft:red_terracotta
fill 499 155 498 499 155 502 minecraft:orange_concrete
fill 499 155 504 499 157 504 minecraft:red_terracotta
setblock 500 155 466 minecraft:red_terracotta
fill 500 155 497 502 155 497 minecraft:orange_concrete
setblock 500 155 503 minecraft:orange_concrete
fill 500 155 505 500 162 505 minecraft:red_terracotta
setblock 501 155 466 minecraft:terracotta
fill 501 155 496 506 155 496 minecraft:orange_concrete
setblock 502 155 465 minecraft:terracotta
fill 502 155 466 502 157 466 minecraft:red_terracotta
setblock 503 155 464 minecraft:terracotta
fill 503 155 465 503 157 465 minecraft:red_terracotta
setblock 503 155 495 minecraft:orange_concrete
setblock 503 155 504 minecraft:terracotta
fill 504 155 464 504 157 464 minecraft:red_terracotta
setblock 504 155 503 minecraft:terracotta
fill 504 155 504 504 157 504 minecraft:red_terracotta
fill 505 155 497 507 155 497 minecraft:orange_concrete
fill 505 155 502 505 157 502 minecraft:terracotta
fill 505 155 503 505 156 503 minecraft:red_terracotta
setblock 506 155 466 minecraft:terracotta
fill 506 155 498 507 155 498 minecraft:orange_concrete
fill 506 155 502 507 155 502 minecraft:orange_concrete
setblock 507 155 465 minecraft:terracotta
setblock 508 155 464 minecraft:terracotta
setblock 508 155 465 minecraft:red_terracotta
setblock 508 155 504 minecraft:terracotta
fill 509 155 464 509 156 464 minecraft:red_terracotta
fill 509 155 504 509 156 505 minecraft:red_terracotta
setblock 510 155 492 minecraft:terracotta
setblock 510 155 493 minecraft:red_terracotta
fill 510 155 505 510 229 505 minecraft:red_terracotta
fill 511 155 463 511 229 463 minecraft:red_terracotta
setblock 511 155 466 minecraft:terracotta
setblock 511 155 467 minecraft:red_terracotta
setblock 511 155 487 minecraft:red_terracotta
setblock 511 155 491 minecraft:terracotta
fill 511 155 492 511 157 492 minecraft:red_terracotta
setblock 511 155 496 minecraft:terracotta
fill 512 155 476 512 225 476 minecraft:red_terracotta
fill 512 155 488 512 229 488 minecraft:red_terracotta
fill 512 155 494 512 229 494 minecraft:red_terracotta
fill 512 155 496 512 226 497 minecraft:red_terracotta
fill 512 155 503 512 227 504 minecraft:red_terracotta
fill 471 156 486 471 157 486 minecraft:red_terracotta
setblock 471 156 490 minecraft:terracotta
fill 471 156 491 471 157 491 minecraft:red_terracotta
setblock 471 156 495 minecraft:terracotta
fill 472 156 487 472 156 489 minecraft:terracotta
fill 472 156 490 472 157 490 minecraft:red_terracotta
fill 473 156 489 475 156 489 minecraft:orange_concrete
setblock 475 156 485 minecraft:orange_concrete
setblock 481 156 465 minecraft:terracotta
setblock 482 156 464 minecraft:terracotta
fill 482 156 465 483 157 465 minecraft:red_terracotta
fill 483 156 464 483 157 464 minecraft:red_terracotta
setblock 486 156 465 minecraft:terracotta
setblock 487 156 464 minecraft:terracotta
fill 487 156 465 488 156 465 minecraft:red_terracotta
fill 488 156 464 488 157 464 minecraft:red_terracotta
fill 492 156 463 492 229 463 minecraft:red_terracotta
setblock 492 156 464 minecraft:terracotta
setblock 493 156 464 minecraft:red_terracotta
setblock 496 156 465 minecraft:terracotta
setblock 497 156 464 minecraft:terracotta
fill 497 156 465 497 157 465 minecraft:red_terracotta
fill 498 156 464 498 157 464 minecraft:red_terracotta
fill 498 156 504 498 157 504 minecraft:red_terracotta
setblock 500 156 466 minecraft:terracotta
setblock 501 156 465 minecraft:terracotta
fill 501 156 466 501 157 466 minecraft:red_terracotta
fill 501 156 497 502 156 497 minecraft:orange_concrete
setblock 501 156 503 minecraft:orange_concrete
setblock 502 156 464 minecraft:terracotta
fill 502 156 465 502 157 465 minecraft:red_terracotta
setblock 502 156 504 minecraft:terracotta
fill 502 156 505 502 227 505 minecraft:red_terracotta
fill 503 156 464 503 157 464 minecraft:red_terracotta
fill 503 156 496 504 156 496 minecraft:orange_concrete
setblock 503 156 503 minecraft:terracotta
fill 503 156 504 503 157 504 minecraft:red_terracotta
fill 504 156 503 504 157 503 minecraft:red_terracotta
setblock 505 156 466 minecraft:terracotta
setblock 505 156 497 minecraft:orange_concrete
setblock 506 156 465 minecraft:terracotta
setblock 506 156 498 minecraft:orange_concrete
setblock 506 156 502 minecraft:orange_concrete
fill 507 156 463 507 229 463 minecraft:red_terracotta
setblock 507 156 464 minecraft:terracotta
setblock 507 156 465 minecraft:red_terracotta
fill 507 156 499 507 156 501 minecraft:orange_concrete
setblock 507 156 504 minecraft:terracotta
fill 507 156 505 507 225 505 minecraft:red_terracotta
fill 508 156 464 508 157 464 minecraft:red_terracotta
setblock 508 156 504 minecraft:red_terracotta
setblock 510 156 492 minecraft:red_terracotta
setblock 511 156 490 minecraft:terracotta
fill 511 156 491 511 157 491 minecraft:red_terracotta
setblock 511 156 495 minecraft:terracotta
fill 511 156 496 511 157 496 minecraft:red_terracotta
fill 512 156 465 512 229 465 minecraft:red_terracotta
fill 512 156 490 512 229 490 minecraft:red_terracotta
fill 512 156 495 512 229 495 minecraft:red_terracotta
setblock 471 157 489 minecraft:terracotta
setblock 471 157 490 minecraft:red_terracotta
setblock 471 157 494 minecraft:terracotta
setblock 471 157 495 minecraft:red_terracotta
fill 472 157 487 472 157 488 minecraft:terracotta
setblock 480 157 464 minecraft:red_terracotta
setblock 481 157 464 minecraft:terracotta
setblock 481 157 465 minecraft:red_terracotta
setblock 482 157 464 minecraft:red_terracotta
setblock 485 157 465 minecraft:terracotta
setblock 486 157 464 minecraft:terracotta
setblock 486 157 465 minecraft:red_terracotta
setblock 487 157 464 minecraft:red_terracotta
setblock 490 157 464 minecraft:magma_block
fill 491 157 463 491 229 463 minecraft:red_terracotta
setblock 491 157 464 minecraft:shroomlight
setblock 492 157 464 minecraft:magma_block
setblock 496 157 464 minecraft:terracotta
setblock 496 157 465 minecraft:red_terracotta
setblock 497 157 464 minecraft:red_terracotta
setblock 499 157 466 minecraft:terracotta
setblock 500 157 465 minecraft:terracotta
setblock 500 157 466 minecraft:red_terracotta
fill 501 157 463 501 229 463 minecraft:red_terracotta
setblock 501 157 464 minecraft:terracotta
setblock 501 157 465 minecraft:red_terracotta
setblock 501 157 504 minecraft:terracotta
fill 501 157 505 501 225 505 minecraft:red_terracotta
setblock 502 157 464 minecraft:red_terracotta
setblock 502 157 503 minecraft:terracotta
setblock 502 157 504 minecraft:red_terracotta
setblock 503 157 503 minecraft:red_terracotta
setblock 504 157 466 minecraft:terracotta
setblock 505 157 465 minecraft:terracotta
setblock 506 157 464 minecraft:terracotta
setblock 506 157 465 minecraft:red_terracotta
setblock 506 157 504 minecraft:terracotta
setblock 507 157 464 minecraft:red_terracotta
setblock 507 157 504 minecraft:red_terracotta
fill 509 157 505 509 230 505 minecraft:red_terracotta
setblock 511 157 489 minecraft:terracotta
setblock 511 157 490 minecraft:red_terracotta
setblock 511 157 494 minecraft:terracotta
setblock 511 157 495 minecraft:red_terracotta
fill 512 157 489 512 230 489 minecraft:red_terracotta
setblock 473 158 466 minecraft:light[level=14]
setblock 473 158 474 minecraft:light[level=14]
setblock 473 158 482 minecraft:light[level=14]
setblock 473 158 490 minecraft:light[level=14]
setblock 473 158 498 minecraft:light[level=14]
setblock 481 158 466 minecraft:light[level=14]
setblock 481 158 474 minecraft:light[level=14]
setblock 481 158 482 minecraft:light[level=14]
setblock 481 158 490 minecraft:light[level=14]
setblock 481 158 498 minecraft:light[level=14]
setblock 489 158 466 minecraft:light[level=14]
setblock 489 158 474 minecraft:light[level=14]
setblock 489 158 482 minecraft:light[level=14]
setblock 489 158 490 minecraft:light[level=14]
setblock 489 158 498 minecraft:light[level=14]
setblock 497 158 466 minecraft:light[level=14]
setblock 497 158 474 minecraft:light[level=14]
setblock 497 158 482 minecraft:light[level=14]
setblock 497 158 490 minecraft:light[level=14]
setblock 497 158 498 minecraft:light[level=14]
setblock 505 158 466 minecraft:light[level=14]
setblock 505 158 474 minecraft:light[level=14]
setblock 505 158 482 minecraft:light[level=14]
setblock 505 158 490 minecraft:light[level=14]
setblock 505 158 498 minecraft:light[level=14]
fill 485 162 488 487 162 490 minecraft:redstone_block
fill 487 162 493 489 162 495 minecraft:redstone_block
fill 489 162 484 491 162 486 minecraft:redstone_block
fill 494 162 486 496 162 488 minecraft:redstone_block
fill 473 163 490 484 163 490 minecraft:blackstone
fill 474 163 485 484 163 489 minecraft:blackstone
fill 474 163 491 486 163 495 minecraft:blackstone
fill 475 163 482 488 163 484 minecraft:blackstone
fill 475 163 496 507 163 498 minecraft:blackstone
fill 476 163 481 506 163 481 minecraft:blackstone
fill 476 163 499 506 163 499 minecraft:blackstone
fill 477 163 479 505 163 480 minecraft:blackstone
fill 477 163 500 505 163 501 minecraft:blackstone
fill 478 163 478 504 163 478 minecraft:blackstone
fill 478 163 502 504 163 502 minecraft:blackstone
fill 479 163 477 503 163 477 minecraft:blackstone
fill 479 163 503 503 163 503 minecraft:blackstone
fill 480 163 476 502 163 476 minecraft:blackstone
fill 480 163 504 502 163 504 minecraft:blackstone
fill 482 163 475 500 163 475 minecraft:blackstone
fill 482 163 505 500 163 505 minecraft:blackstone
fill 483 163 474 499 163 474 minecraft:blackstone
fill 485 163 485 488 163 487 minecraft:blackstone
fill 486 163 473 496 163 473 minecraft:blackstone
fill 487 163 491 489 163 492 minecraft:blackstone
fill 488 163 488 489 163 490 minecraft:blackstone
fill 489 163 482 507 163 483 minecraft:blackstone
fill 489 163 487 493 163 487 minecraft:blackstone
fill 490 163 488 493 163 488 minecraft:blackstone
fill 490 163 492 508 163 495 minecraft:blackstone
fill 491 163 472 491 170 472 minecraft:blackstone
fill 492 163 484 493 163 486 minecraft:blackstone
fill 493 163 489 508 163 491 minecraft:blackstone
fill 494 163 484 507 163 485 minecraft:blackstone
fill 497 163 486 508 163 488 minecraft:blackstone
fill 508 163 485 508 170 485 minecraft:blackstone
fill 509 163 490 509 170 490 minecraft:blackstone
fill 471 164 464 473 164 504 minecraft:blackstone
fill 474 164 464 476 164 486 minecraft:blackstone
fill 474 164 487 475 170 487 minecraft:orange_concrete
fill 474 164 488 474 164 504 minecraft:blackstone
fill 475 164 488 475 170 493 minecraft:blackstone
fill 475 164 494 475 170 494 minecraft:orange_concrete
fill 475 164 495 477 164 504 minecraft:blackstone
fill 476 164 487 476 170 492 minecraft:blackstone
fill 476 164 493 476 170 493 minecraft:orange_concrete
fill 476 164 494 481 164 494 minecraft:blackstone
fill 477 164 464 481 164 479 minecraft:blackstone
fill 477 164 480 478 170 480 minecraft:orange_concrete
fill 477 164 481 481 164 485 minecraft:blackstone
fill 477 164 486 478 164 486 minecraft:orange_concrete
fill 477 164 487 478 164 491 minecraft:blackstone
fill 477 164 492 477 170 492 minecraft:orange_concrete
fill 477 164 493 482 164 493 minecraft:blackstone
fill 478 164 492 485 164 492 minecraft:blackstone
fill 478 164 495 478 164 501 minecraft:blackstone
fill 478 164 502 478 170 502 minecraft:orange_concrete
fill 478 164 503 483 164 504 minecraft:blackstone
fill 479 164 480 488 168 480 minecraft:blackstone
fill 479 164 486 483 164 490 minecraft:blackstone
setblock 479 164 491 minecraft:orange_concrete
fill 479 164 495 479 164 498 minecraft:blackstone
setblock 479 164 499 minecraft:orange_concrete
fill 479 164 500 483 169 502 minecraft:blackstone
fill 480 164 491 483 164 491 minecraft:blackstone
fill 480 164 495 480 164 496 minecraft:blackstone
setblock 480 164 497 minecraft:orange_concrete
fill 480 164 498 491 164 499 minecraft:blackstone
setblock 481 164 495 minecraft:orange_concrete
fill 481 164 496 485 164 497 minecraft:blackstone
fill 482 164 464 489 164 474 minecraft:blackstone
fill 482 164 475 483 170 475 minecraft:orange_concrete
fill 482 164 476 485 169 479 minecraft:blackstone
fill 482 164 481 483 164 481 minecraft:orange_concrete
fill 482 164 482 484 164 485 minecraft:blackstone
setblock 482 164 494 minecraft:orange_concrete
fill 482 164 495 485 164 495 minecraft:blackstone
fill 482 164 505 498 170 505 minecraft:blackstone
setblock 483 164 493 minecraft:orange_concrete
fill 483 164 494 485 164 494 minecraft:blackstone
fill 484 164 475 511 164 475 minecraft:blackstone
fill 484 164 481 502 164 481 minecraft:blackstone
setblock 484 164 486 minecraft:blackstone
fill 484 164 487 484 164 491 minecraft:shroomlight
fill 484 164 493 485 164 493 minecraft:blackstone
fill 484 164 500 484 169 504 minecraft:orange_concrete
setblock 485 164 482 minecraft:orange_concrete
fill 485 164 483 487 164 485 minecraft:blackstone
setblock 485 164 486 minecraft:orange_concrete
fill 485 164 487 493 164 487 minecraft:shroomlight
fill 485 164 488 487 164 490 minecraft:blackstone
fill 485 164 491 488 164 491 minecraft:shroomlight
fill 485 164 500 488 168 504 minecraft:blackstone
fill 486 164 476 491 170 476 minecraft:blackstone
fill 486 164 477 486 170 477 minecraft:orange_concrete
fill 486 164 478 486 169 479 minecraft:blackstone
fill 486 164 482 489 164 482 minecraft:blackstone
fill 486 164 486 487 164 486 minecraft:blackstone
fill 486 164 492 486 164 496 minecraft:shroomlight
fill 486 164 497 511 164 497 minecraft:blackstone
fill 487 164 477 497 169 477 minecraft:blackstone
fill 487 164 478 487 169 478 minecraft:orange_concrete
fill 487 164 479 487 169 479 minecraft:blackstone
fill 487 164 492 489 164 492 minecraft:shroomlight
fill 487 164 493 489 164 495 minecraft:blackstone
fill 487 164 496 490 164 496 minecraft:shroomlight
fill 488 164 478 492 169 478 minecraft:blackstone
fill 488 164 479 488 169 479 minecraft:orange_concrete
fill 488 164 483 488 164 486 minecraft:shroomlight
fill 488 164 488 488 164 490 minecraft:shroomlight
fill 489 164 479 492 168 479 minecraft:blackstone
fill 489 164 480 489 168 480 minecraft:orange_concrete
fill 489 164 483 492 164 483 minecraft:shroomlight
fill 489 164 484 491 164 486 minecraft:blackstone
setblock 489 164 488 minecraft:shroomlight
fill 489 164 489 489 164 491 minecraft:ochre_froglight
fill 489 164 500 492 168 500 minecraft:blackstone
fill 489 164 501 489 168 502 minecraft:orange_concrete
fill 489 164 503 489 169 504 minecraft:blackstone
fill 490 164 464 490 164 472 minecraft:blackstone
fill 490 164 473 490 170 473 minecraft:orange_concrete
fill 490 164 474 490 170 474 minecraft:blackstone
fill 490 164 480 497 168 480 minecraft:blackstone
fill 490 164 482 490 167 482 minecraft:orange_concrete
fill 490 164 488 492 164 488 minecraft:ochre_froglight
fill 490 164 492 492 164 492 minecraft:ochre_froglight
fill 490 164 493 490 164 495 minecraft:shroomlight
fill 490 164 501 493 168 503 minecraft:blackstone
fill 490 164 504 490 170 504 minecraft:orange_concrete
fill 491 164 464 511 164 471 minecraft:blackstone
fill 491 164 473 511 164 473 minecraft:blackstone
fill 491 164 474 491 170 474 minecraft:orange_concrete
fill 491 164 482 511 164 482 minecraft:blackstone
fill 491 164 493 493 165 494 minecraft:magma_block
fill 491 164 495 491 166 495 minecraft:orange_concrete
fill 491 164 496 511 164 496 minecraft:blackstone
fill 491 164 504 511 164 504 minecraft:blackstone
fill 492 164 472 511 164 472 minecraft:blackstone
fill 492 164 474 511 164 474 minecraft:blackstone
fill 492 164 476 492 170 476 minecraft:orange_concrete
fill 492 164 484 492 164 486 minecraft:shroomlight
fill 492 164 495 511 164 495 minecraft:blackstone
fill 492 164 498 492 167 498 minecraft:orange_concrete
fill 492 164 499 498 164 499 minecraft:blackstone
fill 493 164 476 497 170 476 minecraft:blackstone
fill 493 164 478 493 168 479 minecraft:orange_concrete
fill 493 164 483 501 164 484 minecraft:blackstone
fill 493 164 485 493 164 486 minecraft:shroomlight
setblock 493 164 488 minecraft:shroomlight
fill 493 164 489 493 164 491 minecraft:ochre_froglight
setblock 493 164 492 minecraft:shroomlight
fill 493 164 498 496 164 498 minecraft:blackstone
fill 493 164 500 493 168 500 minecraft:orange_concrete
fill 494 164 478 497 169 479 minecraft:blackstone
fill 494 164 485 497 164 485 minecraft:shroomlight
fill 494 164 486 496 164 488 minecraft:blackstone
fill 494 164 489 497 164 489 minecraft:shroomlight
fill 494 164 490 494 165 493 minecraft:magma_block
fill 494 164 494 496 164 494 minecraft:blackstone
fill 494 164 500 503 168 500 minecraft:blackstone
fill 494 164 501 494 169 501 minecraft:orange_concrete
fill 494 164 502 494 169 503 minecraft:blackstone
fill 495 164 490 495 164 492 minecraft:magma_block
fill 495 164 493 506 164 493 minecraft:blackstone
fill 495 164 501 511 164 501 minecraft:blackstone
fill 495 164 502 495 169 502 minecraft:orange_concrete
fill 495 164 503 495 170 503 minecraft:blackstone
fill 496 164 490 497 164 492 minecraft:blackstone
fill 496 164 502 511 164 502 minecraft:blackstone
fill 496 164 503 496 170 503 minecraft:orange_concrete
fill 497 164 486 497 164 488 minecraft:shroomlight
setblock 497 164 494 minecraft:orange_concrete
setblock 497 164 498 minecraft:orange_concrete
fill 497 164 503 511 164 503 minecraft:blackstone
fill 498 164 476 498 169 480 minecraft:orange_concrete
fill 498 164 485 498 164 490 minecraft:blackstone
setblock 498 164 491 minecraft:orange_concrete
fill 498 164 492 511 164 492 minecraft:blackstone
fill 498 164 494 503 164 494 minecraft:blackstone
fill 498 164 498 511 164 498 minecraft:blackstone
fill 499 164 476 503 164 480 minecraft:blackstone
fill 499 164 485 499 164 486 minecraft:blackstone
setblock 499 164 487 minecraft:orange_concrete
fill 499 164 488 502 164 491 minecraft:blackstone
fill 499 164 499 500 164 499 minecraft:orange_concrete
fill 499 164 505 500 170 505 minecraft:orange_concrete
setblock 500 164 485 minecraft:blackstone
setblock 500 164 486 minecraft:orange_concrete
fill 500 164 487 505 164 487 minecraft:blackstone
setblock 501 164 485 minecraft:orange_concrete
fill 501 164 486 506 164 486 minecraft:blackstone
fill 501 164 499 511 164 499 minecraft:blackstone
setblock 502 164 483 minecraft:orange_concrete
fill 502 164 484 507 164 485 minecraft:blackstone
setblock 503 164 481 minecraft:orange_concrete
fill 503 164 483 511 164 483 minecraft:blackstone
fill 503 164 488 504 164 488 minecraft:blackstone
setblock 503 164 489 minecraft:orange_concrete
fill 503 164 490 508 164 491 minecraft:blackstone
fill 504 164 476 511 164 477 minecraft:blackstone
fill 504 164 478 504 170 478 minecraft:orange_concrete
fill 504 164 479 511 164 481 minecraft:blackstone
fill 504 164 489 511 164 489 minecraft:blackstone
fill 504 164 494 505 164 494 minecraft:orange_concrete
fill 504 164 500 505 170 500 minecraft:orange_concrete
fill 505 164 478 511 164 478 minecraft:blackstone
fill 505 164 488 505 170 488 minecraft:orange_concrete
fill 506 164 487 506 170 487 minecraft:orange_concrete
fill 506 164 488 511 164 488 minecraft:blackstone
fill 506 164 494 511 164 494 minecraft:blackstone
fill 506 164 500 511 164 500 minecraft:blackstone
fill 507 164 486 507 170 486 minecraft:orange_concrete
fill 507 164 487 511 164 487 minecraft:blackstone
fill 507 164 493 508 170 493 minecraft:orange_concrete
fill 508 164 484 511 164 484 minecraft:blackstone
fill 508 164 486 511 164 486 minecraft:blackstone
fill 509 164 485 511 164 485 minecraft:blackstone
fill 509 164 491 511 164 491 minecraft:blackstone
fill 509 164 493 511 164 493 minecraft:blackstone
fill 510 164 490 511 164 490 minecraft:blackstone
fill 473 165 490 474 170 490 minecraft:blackstone
fill 474 165 485 476 170 486 minecraft:blackstone
fill 474 165 488 474 170 489 minecraft:blackstone
fill 474 165 491 474 170 495 minecraft:blackstone
fill 475 165 482 477 170 484 minecraft:blackstone
fill 475 165 495 477 170 498 minecraft:blackstone
fill 476 165 481 477 170 481 minecraft:blackstone
fill 476 165 494 477 170 494 minecraft:blackstone
fill 476 165 499 477 170 499 minecraft:blackstone
fill 477 165 479 481 170 479 minecraft:blackstone
fill 477 165 485 477 170 485 minecraft:blackstone
fill 477 165 486 477 170 486 minecraft:orange_concrete
fill 477 165 487 477 170 491 minecraft:blackstone
fill 477 165 493 477 170 493 minecraft:blackstone
fill 477 165 500 478 170 501 minecraft:blackstone
fill 478 165 478 481 170 478 minecraft:blackstone
fill 478 165 481 487 173 499 minecraft:smooth_stone
fill 479 165 477 481 170 477 minecraft:blackstone
fill 479 165 503 483 170 503 minecraft:blackstone
fill 480 165 476 481 170 476 minecraft:blackstone
fill 480 165 504 483 170 504 minecraft:blackstone
fill 483 165 474 489 170 474 minecraft:blackstone
fill 484 165 475 500 170 475 minecraft:blackstone
fill 486 165 473 489 170 473 minecraft:blackstone
fill 488 165 481 488 173 499 minecraft:oak_planks
fill 489 165 481 489 166 485 minecraft:blackstone
fill 489 165 486 489 165 488 minecraft:magma_block
fill 489 165 492 489 165 494 minecraft:magma_block
fill 489 165 495 490 166 499 minecraft:blackstone
fill 490 165 481 494 167 481 minecraft:blackstone
fill 490 165 483 490 166 485 minecraft:blackstone
fill 490 165 486 493 165 487 minecraft:magma_block
fill 490 165 493 490 165 494 minecraft:magma_block
fill 491 165 473 496 170 473 minecraft:blackstone
fill 491 165 482 494 166 484 minecraft:blackstone
fill 491 165 485 491 166 485 minecraft:orange_concrete
fill 491 165 496 491 166 499 minecraft:blackstone
fill 491 165 504 502 170 504 minecraft:blackstone
fill 492 165 474 499 170 474 minecraft:blackstone
fill 492 165 485 494 166 485 minecraft:blackstone
fill 492 165 495 494 166 497 minecraft:blackstone
fill 492 165 499 494 167 499 minecraft:blackstone
fill 493 165 488 494 165 488 minecraft:magma_block
setblock 493 165 492 minecraft:magma_block
fill 493 165 498 494 167 498 minecraft:blackstone
fill 494 165 486 494 166 486 minecraft:blackstone
setblock 494 165 487 minecraft:magma_block
schedule function dropper:buildpart/118_6 1t
