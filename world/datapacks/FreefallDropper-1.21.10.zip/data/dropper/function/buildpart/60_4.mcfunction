setblock 8 200 287 minecraft:nether_wart_block
fill 8 200 288 9 200 288 minecraft:orange_terracotta
fill 8 200 290 8 201 291 minecraft:orange_terracotta
setblock 9 200 284 minecraft:nether_wart_block
fill 9 200 285 9 201 285 minecraft:red_nether_bricks
setblock 9 200 287 minecraft:red_nether_bricks
fill 9 200 289 9 201 290 minecraft:red_nether_bricks
setblock 10 200 289 minecraft:nether_wart_block
setblock 10 200 317 minecraft:purple_concrete
fill 11 200 283 11 200 285 minecraft:red_nether_bricks
setblock 11 200 286 minecraft:nether_wart_block
fill 11 200 287 11 201 287 minecraft:red_nether_bricks
setblock 12 200 283 minecraft:nether_wart_block
setblock 12 200 284 minecraft:red_nether_bricks
setblock 13 200 284 minecraft:nether_wart_block
setblock 14 200 317 minecraft:purple_concrete
fill 15 200 317 18 201 317 minecraft:blackstone
fill 23 200 317 23 215 317 minecraft:blackstone
fill 36 200 314 36 201 314 minecraft:amethyst_block
fill 36 200 316 36 201 316 minecraft:amethyst_block
fill 37 200 313 37 202 313 minecraft:amethyst_block
fill 39 200 313 39 202 313 minecraft:amethyst_block
fill 39 200 317 39 217 317 minecraft:blackstone
fill 40 200 314 40 201 314 minecraft:amethyst_block
fill 40 200 316 40 201 316 minecraft:amethyst_block
setblock 42 200 301 minecraft:crying_obsidian
fill 42 200 302 42 219 302 minecraft:blackstone
fill 0 201 315 0 219 315 minecraft:blackstone
setblock 0 201 316 minecraft:amethyst_block
fill 0 201 317 0 217 317 minecraft:blackstone
fill 5 201 289 5 201 290 minecraft:red_nether_bricks
setblock 5 201 291 minecraft:nether_wart_block
fill 5 201 292 5 201 293 minecraft:red_nether_bricks
setblock 6 201 288 minecraft:nether_wart_block
fill 6 201 289 6 203 289 minecraft:red_nether_bricks
fill 6 201 293 6 203 294 minecraft:orange_terracotta
setblock 7 201 286 minecraft:red_nether_bricks
setblock 7 201 289 minecraft:orange_terracotta
setblock 7 201 293 minecraft:nether_wart_block
setblock 8 201 286 minecraft:nether_wart_block
fill 8 201 287 8 201 289 minecraft:red_nether_bricks
fill 8 201 292 8 202 292 minecraft:red_nether_bricks
fill 9 201 286 11 201 286 minecraft:red_nether_bricks
setblock 9 201 287 minecraft:nether_wart_block
fill 9 201 288 9 203 288 minecraft:red_nether_bricks
setblock 9 201 291 minecraft:nether_wart_block
setblock 10 201 284 minecraft:nether_wart_block
setblock 10 201 288 minecraft:nether_wart_block
fill 10 201 289 10 202 289 minecraft:red_nether_bricks
fill 10 201 317 10 219 317 minecraft:blackstone
setblock 11 201 285 minecraft:nether_wart_block
fill 14 201 317 14 219 317 minecraft:blackstone
fill 37 201 312 39 202 312 minecraft:amethyst_block
fill 42 201 301 42 219 301 minecraft:blackstone
fill 0 202 316 0 219 316 minecraft:blackstone
fill 4 202 291 5 202 292 minecraft:red_nether_bricks
setblock 4 202 293 minecraft:nether_wart_block
fill 4 202 294 4 204 294 minecraft:red_nether_bricks
setblock 5 202 289 minecraft:red_nether_bricks
setblock 5 202 290 minecraft:nether_wart_block
fill 5 202 293 5 202 295 minecraft:orange_terracotta
setblock 6 202 287 minecraft:nether_wart_block
fill 6 202 288 6 203 288 minecraft:red_nether_bricks
fill 6 202 290 8 202 290 minecraft:red_nether_bricks
fill 6 202 291 7 202 291 minecraft:orange_terracotta
fill 6 202 292 6 204 292 minecraft:red_nether_bricks
fill 6 202 295 7 203 295 minecraft:orange_terracotta
setblock 6 202 296 minecraft:red_nether_bricks
fill 7 202 287 9 202 287 minecraft:red_nether_bricks
setblock 7 202 288 minecraft:nether_wart_block
fill 7 202 289 7 204 289 minecraft:red_nether_bricks
setblock 7 202 292 minecraft:nether_wart_block
fill 7 202 293 7 202 294 minecraft:orange_terracotta
setblock 8 202 286 minecraft:red_nether_bricks
setblock 8 202 288 minecraft:red_nether_bricks
setblock 8 202 289 minecraft:nether_wart_block
fill 8 202 291 9 203 291 minecraft:red_nether_bricks
setblock 8 202 293 minecraft:nether_wart_block
fill 8 202 294 8 204 294 minecraft:red_nether_bricks
setblock 9 202 286 minecraft:nether_wart_block
setblock 9 202 289 minecraft:red_nether_bricks
setblock 9 202 290 minecraft:nether_wart_block
setblock 9 202 292 minecraft:red_nether_bricks
setblock 10 202 286 minecraft:red_nether_bricks
setblock 10 202 287 minecraft:nether_wart_block
setblock 10 202 288 minecraft:red_nether_bricks
setblock 15 202 317 minecraft:magma_block
fill 16 202 317 18 215 317 minecraft:blackstone
setblock 38 202 311 minecraft:amethyst_block
setblock 0 203 294 minecraft:magma_block
fill 0 203 296 0 219 296 minecraft:blackstone
setblock 0 203 297 minecraft:purple_concrete
fill 0 203 298 0 217 299 minecraft:blackstone
setblock 2 203 317 minecraft:amethyst_block
fill 4 203 291 5 203 291 minecraft:red_nether_bricks
setblock 4 203 292 minecraft:nether_wart_block
fill 4 203 293 4 205 293 minecraft:red_nether_bricks
setblock 4 203 295 minecraft:red_nether_bricks
setblock 4 203 296 minecraft:nether_wart_block
setblock 5 203 289 minecraft:nether_wart_block
fill 5 203 290 5 204 290 minecraft:red_nether_bricks
setblock 5 203 292 minecraft:red_nether_bricks
setblock 5 203 293 minecraft:nether_wart_block
fill 5 203 294 5 203 295 minecraft:orange_terracotta
setblock 5 203 296 minecraft:red_nether_bricks
fill 5 203 297 7 204 297 minecraft:orange_terracotta
setblock 6 203 290 minecraft:nether_wart_block
fill 6 203 291 7 205 291 minecraft:bone_block
fill 6 203 296 6 204 296 minecraft:orange_terracotta
fill 6 203 298 6 205 298 minecraft:orange_terracotta
setblock 7 203 288 minecraft:red_nether_bricks
fill 7 203 290 9 203 290 minecraft:red_nether_bricks
fill 7 203 292 7 204 293 minecraft:red_nether_bricks
setblock 7 203 294 minecraft:orange_terracotta
fill 7 203 296 7 205 296 minecraft:red_nether_bricks
setblock 8 203 288 minecraft:nether_wart_block
setblock 8 203 289 minecraft:red_nether_bricks
setblock 8 203 292 minecraft:nether_wart_block
fill 8 203 293 8 205 293 minecraft:red_nether_bricks
setblock 8 203 295 minecraft:red_nether_bricks
setblock 9 203 289 minecraft:nether_wart_block
fill 15 203 317 15 219 317 minecraft:blackstone
setblock 38 203 314 minecraft:amethyst_block
fill 39 203 298 41 206 300 minecraft:amethyst_block
fill 0 204 294 0 219 294 minecraft:blackstone
fill 0 204 297 0 219 297 minecraft:blackstone
fill 2 204 276 4 207 277 minecraft:amethyst_block
fill 2 204 317 2 219 317 minecraft:blackstone
setblock 3 204 278 minecraft:light[level=12]
fill 3 204 285 3 204 286 minecraft:light[level=12]
setblock 3 204 292 minecraft:light[level=12]
setblock 3 204 294 minecraft:light[level=12]
setblock 3 204 299 minecraft:light[level=12]
setblock 3 204 302 minecraft:light[level=12]
setblock 3 204 306 minecraft:light[level=12]
setblock 3 204 310 minecraft:light[level=12]
setblock 3 204 313 minecraft:light[level=12]
setblock 4 204 292 minecraft:red_nether_bricks
setblock 4 204 295 minecraft:nether_wart_block
fill 4 204 296 4 204 298 minecraft:red_nether_bricks
setblock 5 204 291 minecraft:red_nether_bricks
setblock 5 204 292 minecraft:nether_wart_block
fill 5 204 293 5 204 295 minecraft:red_nether_bricks
setblock 5 204 296 minecraft:orange_terracotta
fill 5 204 298 5 204 299 minecraft:orange_terracotta
setblock 6 204 290 minecraft:red_nether_bricks
setblock 6 204 293 minecraft:nether_wart_block
fill 6 204 294 6 205 295 minecraft:red_nether_bricks
fill 6 204 299 7 204 299 minecraft:orange_terracotta
setblock 6 204 300 minecraft:red_nether_bricks
setblock 7 204 290 minecraft:nether_wart_block
setblock 7 204 294 minecraft:nether_wart_block
fill 7 204 295 7 206 295 minecraft:red_nether_bricks
fill 7 204 298 7 205 298 minecraft:orange_terracotta
setblock 8 204 290 minecraft:red_nether_bricks
setblock 8 204 291 minecraft:nether_wart_block
setblock 8 204 292 minecraft:red_nether_bricks
setblock 8 204 295 minecraft:nether_wart_block
fill 8 204 296 8 205 297 minecraft:red_nether_bricks
fill 10 204 278 11 204 278 minecraft:light[level=12]
setblock 10 204 285 minecraft:light[level=12]
setblock 10 204 292 minecraft:light[level=12]
setblock 10 204 299 minecraft:light[level=12]
setblock 10 204 306 minecraft:light[level=12]
setblock 10 204 313 minecraft:light[level=12]
setblock 11 204 286 minecraft:light[level=12]
setblock 11 204 294 minecraft:light[level=12]
setblock 11 204 302 minecraft:light[level=12]
setblock 11 204 310 minecraft:light[level=12]
setblock 17 204 278 minecraft:light[level=12]
setblock 17 204 285 minecraft:light[level=12]
setblock 17 204 292 minecraft:light[level=12]
setblock 17 204 299 minecraft:light[level=12]
setblock 17 204 306 minecraft:light[level=12]
setblock 17 204 313 minecraft:light[level=12]
setblock 19 204 278 minecraft:light[level=12]
setblock 19 204 286 minecraft:light[level=12]
setblock 19 204 294 minecraft:light[level=12]
setblock 19 204 302 minecraft:light[level=12]
setblock 19 204 310 minecraft:light[level=12]
setblock 24 204 278 minecraft:light[level=12]
setblock 24 204 285 minecraft:light[level=12]
setblock 24 204 292 minecraft:light[level=12]
setblock 24 204 299 minecraft:light[level=12]
setblock 24 204 306 minecraft:light[level=12]
setblock 24 204 313 minecraft:light[level=12]
setblock 27 204 278 minecraft:light[level=12]
setblock 27 204 286 minecraft:light[level=12]
setblock 27 204 294 minecraft:light[level=12]
setblock 27 204 302 minecraft:light[level=12]
setblock 27 204 310 minecraft:light[level=12]
setblock 31 204 278 minecraft:light[level=12]
setblock 31 204 285 minecraft:light[level=12]
setblock 31 204 292 minecraft:light[level=12]
setblock 31 204 299 minecraft:light[level=12]
setblock 31 204 306 minecraft:light[level=12]
setblock 31 204 313 minecraft:light[level=12]
setblock 35 204 278 minecraft:light[level=12]
setblock 35 204 286 minecraft:light[level=12]
setblock 35 204 294 minecraft:light[level=12]
setblock 35 204 302 minecraft:light[level=12]
setblock 35 204 310 minecraft:light[level=12]
fill 37 204 299 38 206 299 minecraft:amethyst_block
setblock 38 204 278 minecraft:light[level=12]
setblock 38 204 285 minecraft:light[level=12]
setblock 38 204 292 minecraft:light[level=12]
fill 38 204 298 38 206 298 minecraft:amethyst_block
fill 38 204 300 38 206 300 minecraft:amethyst_block
setblock 38 204 306 minecraft:light[level=12]
setblock 38 204 313 minecraft:light[level=12]
fill 40 204 297 40 205 297 minecraft:amethyst_block
fill 40 204 301 40 205 301 minecraft:amethyst_block
fill 1 205 276 1 206 277 minecraft:amethyst_block
fill 2 205 278 4 207 278 minecraft:amethyst_block
setblock 4 205 294 minecraft:nether_wart_block
fill 4 205 295 4 205 297 minecraft:red_nether_bricks
setblock 4 205 298 minecraft:nether_wart_block
fill 4 205 299 4 207 299 minecraft:red_nether_bricks
fill 5 205 276 5 206 277 minecraft:amethyst_block
fill 5 205 292 5 205 294 minecraft:red_nether_bricks
setblock 5 205 295 minecraft:nether_wart_block
fill 5 205 296 5 206 297 minecraft:red_nether_bricks
setblock 5 205 298 minecraft:orange_terracotta
setblock 5 205 299 minecraft:nether_wart_block
fill 5 205 300 5 206 301 minecraft:red_nether_bricks
setblock 6 205 292 minecraft:nether_wart_block
fill 6 205 293 6 206 293 minecraft:red_nether_bricks
setblock 6 205 296 minecraft:nether_wart_block
setblock 6 205 297 minecraft:orange_terracotta
fill 6 205 299 6 205 301 minecraft:orange_terracotta
setblock 7 205 292 minecraft:red_nether_bricks
setblock 7 205 293 minecraft:nether_wart_block
fill 7 205 294 7 206 294 minecraft:red_nether_bricks
setblock 7 205 297 minecraft:nether_wart_block
fill 7 205 299 8 206 299 minecraft:red_nether_bricks
fill 7 205 300 7 206 302 minecraft:orange_terracotta
setblock 8 205 294 minecraft:nether_wart_block
setblock 8 205 295 minecraft:red_nether_bricks
setblock 8 205 298 minecraft:nether_wart_block
fill 8 205 300 8 206 300 minecraft:red_nether_bricks
fill 36 205 299 36 206 299 minecraft:amethyst_block
setblock 37 205 298 minecraft:amethyst_block
setblock 37 205 300 minecraft:amethyst_block
fill 3 206 279 3 208 279 minecraft:amethyst_block
fill 4 206 295 4 206 296 minecraft:red_nether_bricks
setblock 4 206 297 minecraft:nether_wart_block
fill 4 206 298 4 207 298 minecraft:red_nether_bricks
setblock 4 206 300 minecraft:red_nether_bricks
setblock 5 206 293 minecraft:red_nether_bricks
setblock 5 206 294 minecraft:nether_wart_block
fill 5 206 295 5 207 295 minecraft:red_nether_bricks
setblock 5 206 298 minecraft:nether_wart_block
fill 5 206 299 5 208 299 minecraft:red_nether_bricks
setblock 5 206 302 minecraft:nether_wart_block
setblock 6 206 294 minecraft:red_nether_bricks
setblock 6 206 295 minecraft:nether_wart_block
fill 6 206 296 6 207 297 minecraft:red_nether_bricks
fill 6 206 298 6 209 298 minecraft:bone_block
setblock 6 206 299 minecraft:nether_wart_block
fill 6 206 300 6 206 302 minecraft:orange_terracotta
setblock 6 206 303 minecraft:nether_wart_block
setblock 7 206 275 minecraft:magma_block
setblock 7 206 291 minecraft:bone_block
setblock 7 206 296 minecraft:nether_wart_block
fill 7 206 297 7 207 298 minecraft:red_nether_bricks
fill 7 206 303 8 206 303 minecraft:red_nether_bricks
setblock 8 206 296 minecraft:red_nether_bricks
setblock 8 206 297 minecraft:nether_wart_block
fill 8 206 298 8 207 298 minecraft:red_nether_bricks
fill 8 206 301 8 206 302 minecraft:orange_terracotta
fill 8 206 304 8 209 304 minecraft:orange_terracotta
setblock 2 207 279 minecraft:amethyst_block
fill 3 207 280 3 208 280 minecraft:amethyst_block
setblock 4 207 279 minecraft:amethyst_block
setblock 4 207 297 minecraft:red_nether_bricks
setblock 4 207 300 minecraft:nether_wart_block
setblock 4 207 301 minecraft:red_nether_bricks
setblock 5 207 296 minecraft:red_nether_bricks
setblock 5 207 297 minecraft:nether_wart_block
fill 5 207 298 5 208 298 minecraft:red_nether_bricks
fill 5 207 300 7 207 300 minecraft:red_nether_bricks
setblock 5 207 301 minecraft:nether_wart_block
fill 5 207 302 5 208 303 minecraft:red_nether_bricks
setblock 5 207 317 minecraft:crying_obsidian
setblock 6 207 295 minecraft:red_nether_bricks
fill 6 207 299 6 209 299 minecraft:red_nether_bricks
fill 6 207 301 7 207 302 minecraft:orange_terracotta
fill 6 207 303 6 208 304 minecraft:red_nether_bricks
fill 6 207 317 8 217 317 minecraft:blackstone
fill 7 207 275 7 219 275 minecraft:blackstone
setblock 7 207 296 minecraft:red_nether_bricks
setblock 7 207 299 minecraft:nether_wart_block
fill 7 207 303 7 208 304 minecraft:orange_terracotta
fill 7 207 305 7 208 305 minecraft:red_nether_bricks
setblock 8 207 297 minecraft:red_nether_bricks
setblock 8 207 299 minecraft:red_nether_bricks
setblock 8 207 300 minecraft:nether_wart_block
fill 8 207 301 8 208 302 minecraft:red_nether_bricks
fill 8 207 303 9 207 303 minecraft:orange_terracotta
fill 8 207 305 9 209 305 minecraft:orange_terracotta
setblock 9 207 300 minecraft:red_nether_bricks
setblock 9 207 301 minecraft:nether_wart_block
fill 9 207 302 9 209 302 minecraft:red_nether_bricks
fill 9 207 304 9 209 304 minecraft:orange_terracotta
fill 3 208 277 3 208 278 minecraft:amethyst_block
setblock 4 208 300 minecraft:red_nether_bricks
setblock 5 208 297 minecraft:red_nether_bricks
setblock 5 208 300 minecraft:nether_wart_block
fill 5 208 301 5 209 301 minecraft:red_nether_bricks
fill 5 208 313 5 209 313 minecraft:blackstone
fill 5 208 317 5 217 317 minecraft:blackstone
setblock 6 208 297 minecraft:nether_wart_block
fill 6 208 300 8 208 300 minecraft:red_nether_bricks
setblock 6 208 301 minecraft:nether_wart_block
fill 6 208 302 6 210 302 minecraft:red_nether_bricks
setblock 6 208 305 minecraft:nether_wart_block
setblock 7 208 297 minecraft:red_nether_bricks
setblock 7 208 298 minecraft:nether_wart_block
fill 7 208 299 7 209 299 minecraft:red_nether_bricks
setblock 7 208 301 minecraft:red_nether_bricks
setblock 7 208 302 minecraft:nether_wart_block
setblock 7 208 306 minecraft:nether_wart_block
setblock 8 208 299 minecraft:nether_wart_block
setblock 8 208 303 minecraft:orange_terracotta
setblock 8 208 306 minecraft:red_nether_bricks
fill 9 208 301 9 209 301 minecraft:red_nether_bricks
fill 9 208 303 10 208 303 minecraft:red_nether_bricks
fill 9 208 306 10 209 306 minecraft:orange_terracotta
setblock 9 208 307 minecraft:red_nether_bricks
setblock 10 208 304 minecraft:red_nether_bricks
setblock 10 208 305 minecraft:nether_wart_block
fill 10 208 307 10 210 307 minecraft:orange_terracotta
setblock 5 209 300 minecraft:red_nether_bricks
setblock 5 209 302 minecraft:red_nether_bricks
setblock 5 209 303 minecraft:nether_wart_block
setblock 6 209 300 minecraft:nether_wart_block
fill 6 209 301 6 210 301 minecraft:red_nether_bricks
fill 6 209 303 8 209 303 minecraft:red_nether_bricks
setblock 6 209 304 minecraft:nether_wart_block
fill 6 209 305 6 210 305 minecraft:red_nether_bricks
fill 7 209 300 8 209 300 minecraft:red_nether_bricks
setblock 7 209 301 minecraft:nether_wart_block
fill 7 209 302 7 210 302 minecraft:red_nether_bricks
setblock 7 209 304 minecraft:red_nether_bricks
setblock 7 209 305 minecraft:nether_wart_block
fill 7 209 306 7 211 306 minecraft:red_nether_bricks
setblock 8 209 301 minecraft:red_nether_bricks
setblock 8 209 302 minecraft:nether_wart_block
setblock 8 209 306 minecraft:nether_wart_block
fill 8 209 307 8 211 307 minecraft:red_nether_bricks
setblock 9 209 303 minecraft:nether_wart_block
setblock 9 209 307 minecraft:orange_terracotta
fill 9 209 308 9 211 308 minecraft:red_nether_bricks
setblock 10 209 303 minecraft:red_nether_bricks
setblock 10 209 304 minecraft:nether_wart_block
fill 10 209 305 10 211 305 minecraft:red_nether_bricks
fill 10 209 308 11 210 308 minecraft:orange_terracotta
setblock 11 209 304 minecraft:red_nether_bricks
setblock 11 209 305 minecraft:nether_wart_block
fill 11 209 306 11 210 307 minecraft:orange_terracotta
fill 12 209 307 12 210 307 minecraft:orange_terracotta
setblock 0 210 300 minecraft:magma_block
fill 3 210 278 3 211 278 minecraft:light[level=12]
setblock 3 210 285 minecraft:light[level=12]
setblock 3 210 292 minecraft:light[level=12]
setblock 3 210 299 minecraft:light[level=12]
setblock 3 210 306 minecraft:light[level=12]
setblock 3 210 313 minecraft:light[level=12]
fill 4 210 314 6 213 316 minecraft:amethyst_block
fill 5 210 313 5 213 313 minecraft:amethyst_block
setblock 6 210 303 minecraft:nether_wart_block
setblock 6 210 304 minecraft:red_nether_bricks
setblock 7 210 301 minecraft:red_nether_bricks
fill 7 210 303 9 210 303 minecraft:red_nether_bricks
setblock 7 210 304 minecraft:nether_wart_block
fill 7 210 305 7 211 305 minecraft:red_nether_bricks
setblock 8 210 301 minecraft:nether_wart_block
setblock 8 210 302 minecraft:red_nether_bricks
fill 8 210 304 10 210 304 minecraft:red_nether_bricks
fill 8 210 305 9 213 305 minecraft:bone_block
fill 8 210 306 8 212 306 minecraft:red_nether_bricks
setblock 8 210 308 minecraft:red_nether_bricks
fill 9 210 275 9 219 275 minecraft:blackstone
setblock 9 210 302 minecraft:nether_wart_block
setblock 9 210 306 minecraft:nether_wart_block
fill 9 210 307 9 212 307 minecraft:red_nether_bricks
setblock 10 210 275 minecraft:purple_concrete
setblock 10 210 278 minecraft:light[level=12]
setblock 10 210 285 minecraft:light[level=12]
setblock 10 210 292 minecraft:light[level=12]
setblock 10 210 299 minecraft:light[level=12]
setblock 10 210 303 minecraft:nether_wart_block
setblock 10 210 306 minecraft:orange_terracotta
fill 10 210 309 11 211 309 minecraft:red_nether_bricks
setblock 10 210 313 minecraft:light[level=12]
setblock 11 210 304 minecraft:nether_wart_block
fill 11 210 305 11 212 305 minecraft:red_nether_bricks
setblock 12 210 305 minecraft:nether_wart_block
fill 12 210 306 12 212 306 minecraft:red_nether_bricks
fill 12 210 308 13 211 309 minecraft:orange_terracotta
fill 13 210 307 13 212 307 minecraft:red_nether_bricks
setblock 17 210 278 minecraft:light[level=12]
setblock 17 210 285 minecraft:light[level=12]
setblock 17 210 292 minecraft:light[level=12]
setblock 17 210 299 minecraft:light[level=12]
setblock 17 210 306 minecraft:light[level=12]
setblock 17 210 313 minecraft:light[level=12]
setblock 24 210 278 minecraft:light[level=12]
setblock 24 210 285 minecraft:light[level=12]
setblock 24 210 292 minecraft:light[level=12]
setblock 24 210 299 minecraft:light[level=12]
setblock 24 210 306 minecraft:light[level=12]
setblock 24 210 313 minecraft:light[level=12]
setblock 31 210 278 minecraft:light[level=12]
setblock 31 210 285 minecraft:light[level=12]
setblock 31 210 292 minecraft:light[level=12]
setblock 31 210 299 minecraft:light[level=12]
setblock 31 210 306 minecraft:light[level=12]
setblock 31 210 313 minecraft:light[level=12]
setblock 38 210 278 minecraft:light[level=12]
setblock 38 210 285 minecraft:light[level=12]
setblock 38 210 292 minecraft:light[level=12]
setblock 38 210 299 minecraft:light[level=12]
setblock 38 210 306 minecraft:light[level=12]
setblock 38 210 313 minecraft:light[level=12]
fill 0 211 300 0 219 300 minecraft:blackstone
setblock 3 211 286 minecraft:light[level=12]
setblock 3 211 294 minecraft:light[level=12]
setblock 3 211 302 minecraft:light[level=12]
setblock 3 211 310 minecraft:light[level=12]
fill 3 211 314 3 212 316 minecraft:amethyst_block
fill 4 211 312 4 213 313 minecraft:amethyst_block
fill 5 211 312 6 213 312 minecraft:amethyst_block
fill 6 211 313 6 213 313 minecraft:amethyst_block
setblock 7 211 303 minecraft:nether_wart_block
setblock 7 211 304 minecraft:red_nether_bricks
fill 7 211 314 7 212 316 minecraft:amethyst_block
fill 8 211 303 9 211 303 minecraft:red_nether_bricks
setblock 8 211 304 minecraft:nether_wart_block
setblock 8 211 308 minecraft:nether_wart_block
fill 9 211 304 11 211 304 minecraft:red_nether_bricks
fill 9 211 306 9 213 306 minecraft:red_nether_bricks
setblock 9 211 309 minecraft:nether_wart_block
fill 10 211 275 10 216 275 minecraft:blackstone
setblock 10 211 306 minecraft:nether_wart_block
fill 10 211 307 10 212 308 minecraft:red_nether_bricks
setblock 11 211 278 minecraft:light[level=12]
setblock 11 211 286 minecraft:light[level=12]
setblock 11 211 294 minecraft:light[level=12]
setblock 11 211 302 minecraft:light[level=12]
setblock 11 211 306 minecraft:red_nether_bricks
setblock 11 211 307 minecraft:orange_terracotta
fill 11 211 308 11 213 308 minecraft:red_nether_bricks
fill 11 211 310 12 211 310 minecraft:red_nether_bricks
setblock 12 211 305 minecraft:red_nether_bricks
setblock 12 211 307 minecraft:red_nether_bricks
fill 13 211 306 13 212 306 minecraft:red_nether_bricks
fill 13 211 310 14 212 310 minecraft:orange_terracotta
fill 14 211 307 14 213 307 minecraft:red_nether_bricks
fill 14 211 308 14 211 309 minecraft:orange_terracotta
fill 15 211 309 15 211 310 minecraft:red_nether_bricks
setblock 19 211 278 minecraft:light[level=12]
setblock 19 211 286 minecraft:light[level=12]
setblock 19 211 294 minecraft:light[level=12]
setblock 19 211 302 minecraft:light[level=12]
setblock 19 211 310 minecraft:light[level=12]
setblock 27 211 278 minecraft:light[level=12]
setblock 27 211 286 minecraft:light[level=12]
setblock 27 211 294 minecraft:light[level=12]
setblock 27 211 302 minecraft:light[level=12]
setblock 27 211 310 minecraft:light[level=12]
fill 33 211 317 33 217 317 minecraft:blackstone
setblock 34 211 317 minecraft:crying_obsidian
setblock 35 211 278 minecraft:light[level=12]
setblock 35 211 286 minecraft:light[level=12]
setblock 35 211 294 minecraft:light[level=12]
setblock 35 211 302 minecraft:light[level=12]
setblock 35 211 310 minecraft:light[level=12]
setblock 42 211 306 minecraft:crying_obsidian
fill 42 211 307 42 211 309 minecraft:blackstone
setblock 0 212 301 minecraft:crying_obsidian
fill 4 212 311 6 213 311 minecraft:amethyst_block
fill 5 212 310 5 213 310 minecraft:amethyst_block
setblock 8 212 304 minecraft:red_nether_bricks
setblock 8 212 307 minecraft:nether_wart_block
setblock 9 212 304 minecraft:nether_wart_block
setblock 9 212 308 minecraft:nether_wart_block
setblock 9 212 309 minecraft:red_nether_bricks
setblock 10 212 304 minecraft:red_nether_bricks
setblock 10 212 305 minecraft:nether_wart_block
fill 10 212 306 10 213 306 minecraft:red_nether_bricks
setblock 10 212 309 minecraft:nether_wart_block
setblock 11 212 306 minecraft:nether_wart_block
fill 11 212 307 11 214 307 minecraft:red_nether_bricks
setblock 11 212 309 minecraft:red_nether_bricks
setblock 11 212 310 minecraft:nether_wart_block
setblock 12 212 307 minecraft:nether_wart_block
fill 12 212 308 12 214 308 minecraft:red_nether_bricks
fill 12 212 309 15 212 309 minecraft:orange_terracotta
setblock 12 212 310 minecraft:red_nether_bricks
setblock 12 212 311 minecraft:nether_wart_block
setblock 13 212 308 minecraft:orange_terracotta
fill 13 212 311 14 212 311 minecraft:red_nether_bricks
fill 14 212 279 14 213 280 minecraft:amethyst_block
fill 14 212 308 15 212 308 minecraft:red_nether_bricks
fill 15 212 310 17 213 311 minecraft:orange_terracotta
setblock 16 212 309 minecraft:red_nether_bricks
fill 34 212 317 34 219 317 minecraft:blackstone
fill 42 212 306 42 219 308 minecraft:blackstone
setblock 42 212 309 minecraft:purple_concrete
fill 0 213 301 0 216 301 minecraft:blackstone
fill 5 213 308 5 213 309 minecraft:amethyst_block
setblock 9 213 307 minecraft:nether_wart_block
setblock 9 213 308 minecraft:red_nether_bricks
setblock 10 213 307 minecraft:red_nether_bricks
setblock 10 213 308 minecraft:nether_wart_block
setblock 10 213 309 minecraft:red_nether_bricks
setblock 11 213 306 minecraft:red_nether_bricks
setblock 11 213 309 minecraft:nether_wart_block
fill 11 213 310 11 214 310 minecraft:red_nether_bricks
setblock 12 213 306 minecraft:nether_wart_block
fill 12 213 307 12 214 307 minecraft:red_nether_bricks
fill 12 213 309 13 213 309 minecraft:red_nether_bricks
setblock 12 213 310 minecraft:nether_wart_block
fill 12 213 311 12 214 311 minecraft:red_nether_bricks
fill 13 213 276 15 214 278 minecraft:amethyst_block
setblock 13 213 307 minecraft:nether_wart_block
fill 13 213 308 13 215 308 minecraft:red_nether_bricks
fill 13 213 310 14 213 310 minecraft:red_nether_bricks
setblock 13 213 311 minecraft:nether_wart_block
setblock 14 213 308 minecraft:nether_wart_block
fill 14 213 309 14 216 309 minecraft:bone_block
setblock 14 213 311 minecraft:red_nether_bricks
setblock 14 213 312 minecraft:nether_wart_block
fill 15 213 308 16 213 308 minecraft:red_nether_bricks
setblock 15 213 309 minecraft:nether_wart_block
fill 15 213 312 16 213 312 minecraft:red_nether_bricks
setblock 16 213 309 minecraft:orange_terracotta
fill 17 213 309 17 214 309 minecraft:red_nether_bricks
setblock 17 213 312 minecraft:orange_terracotta
fill 18 213 310 18 214 311 minecraft:orange_terracotta
setblock 18 213 312 minecraft:nether_wart_block
fill 42 213 309 42 219 309 minecraft:blackstone
fill 4 214 313 6 216 313 minecraft:blackstone
fill 5 214 312 5 216 312 minecraft:blackstone
fill 5 214 314 5 216 314 minecraft:blackstone
setblock 11 214 308 minecraft:nether_wart_block
setblock 11 214 309 minecraft:red_nether_bricks
setblock 12 214 309 minecraft:nether_wart_block
setblock 12 214 310 minecraft:red_nether_bricks
setblock 13 214 307 minecraft:red_nether_bricks
setblock 13 214 309 minecraft:red_nether_bricks
setblock 13 214 310 minecraft:nether_wart_block
fill 13 214 311 13 215 311 minecraft:red_nether_bricks
setblock 14 214 279 minecraft:amethyst_block
setblock 14 214 307 minecraft:nether_wart_block
fill 14 214 308 14 215 308 minecraft:red_nether_bricks
fill 14 214 310 14 216 310 minecraft:bone_block
setblock 14 214 311 minecraft:nether_wart_block
fill 14 214 312 14 215 312 minecraft:red_nether_bricks
setblock 15 214 308 minecraft:nether_wart_block
fill 15 214 309 15 214 311 minecraft:red_nether_bricks
setblock 15 214 312 minecraft:nether_wart_block
fill 16 214 308 17 214 308 minecraft:red_nether_bricks
setblock 16 214 309 minecraft:nether_wart_block
fill 16 214 310 17 214 311 minecraft:orange_terracotta
fill 16 214 312 18 214 312 minecraft:red_nether_bricks
fill 17 214 313 18 214 313 minecraft:red_nether_bricks
fill 18 214 309 19 215 309 minecraft:red_nether_bricks
fill 19 214 310 20 215 312 minecraft:orange_terracotta
fill 21 214 311 21 216 311 minecraft:orange_terracotta
fill 27 214 311 27 215 311 minecraft:gold_block
setblock 42 214 296 minecraft:purple_concrete
fill 4 215 312 4 216 312 minecraft:blackstone
fill 4 215 314 4 216 314 minecraft:blackstone
fill 6 215 312 6 216 312 minecraft:blackstone
fill 6 215 314 6 216 314 minecraft:blackstone
setblock 12 215 309 minecraft:red_nether_bricks
fill 13 215 276 15 215 277 minecraft:amethyst_block
setblock 13 215 309 minecraft:nether_wart_block
setblock 13 215 310 minecraft:red_nether_bricks
setblock 14 215 278 minecraft:amethyst_block
fill 14 215 311 14 216 311 minecraft:red_nether_bricks
fill 15 215 308 15 215 310 minecraft:red_nether_bricks
setblock 15 215 311 minecraft:nether_wart_block
fill 15 215 312 15 216 312 minecraft:red_nether_bricks
fill 16 215 278 17 216 278 minecraft:gold_block
setblock 16 215 308 minecraft:nether_wart_block
fill 16 215 309 16 215 311 minecraft:red_nether_bricks
setblock 16 215 312 minecraft:nether_wart_block
setblock 16 215 313 minecraft:red_nether_bricks
fill 17 215 277 17 216 277 minecraft:gold_block
setblock 17 215 308 minecraft:red_nether_bricks
setblock 17 215 309 minecraft:nether_wart_block
fill 17 215 310 17 215 312 minecraft:red_nether_bricks
setblock 17 215 313 minecraft:nether_wart_block
setblock 18 215 310 minecraft:nether_wart_block
fill 18 215 311 18 215 313 minecraft:red_nether_bricks
fill 19 215 313 20 216 313 minecraft:red_nether_bricks
fill 20 215 309 20 217 309 minecraft:red_nether_bricks
setblock 21 215 310 minecraft:orange_terracotta
fill 21 215 312 21 216 312 minecraft:orange_terracotta
setblock 21 215 313 minecraft:nether_wart_block
setblock 22 215 310 minecraft:nether_wart_block
fill 22 215 311 22 215 312 minecraft:red_nether_bricks
fill 23 215 311 23 217 311 minecraft:orange_terracotta
fill 42 215 296 42 219 296 minecraft:blackstone
setblock 0 216 275 minecraft:deepslate_tiles
setblock 0 216 295 minecraft:deepslate_tiles
setblock 0 216 304 minecraft:deepslate_tiles
setblock 0 216 312 minecraft:deepslate_tiles
setblock 3 216 275 minecraft:deepslate_tiles
setblock 3 216 278 minecraft:light[level=12]
setblock 3 216 285 minecraft:light[level=12]
setblock 3 216 292 minecraft:light[level=12]
setblock 3 216 299 minecraft:light[level=12]
setblock 3 216 306 minecraft:light[level=12]
setblock 3 216 313 minecraft:light[level=12]
setblock 8 216 275 minecraft:deepslate_tiles
setblock 10 216 278 minecraft:light[level=12]
setblock 10 216 285 minecraft:light[level=12]
setblock 10 216 292 minecraft:light[level=12]
setblock 10 216 299 minecraft:light[level=12]
setblock 10 216 306 minecraft:light[level=12]
setblock 10 216 313 minecraft:light[level=12]
fill 13 216 276 15 216 276 minecraft:amethyst_block
setblock 14 216 277 minecraft:amethyst_block
setblock 15 216 275 minecraft:deepslate_tiles
fill 15 216 309 17 216 309 minecraft:red_nether_bricks
setblock 15 216 310 minecraft:nether_wart_block
setblock 15 216 311 minecraft:red_nether_bricks
fill 16 216 310 18 216 310 minecraft:red_nether_bricks
setblock 16 216 311 minecraft:nether_wart_block
setblock 16 216 312 minecraft:red_nether_bricks
fill 16 216 317 17 219 317 minecraft:blackstone
setblock 17 216 285 minecraft:light[level=12]
setblock 17 216 292 minecraft:light[level=12]
setblock 17 216 299 minecraft:light[level=12]
setblock 17 216 306 minecraft:light[level=12]
fill 17 216 311 19 216 311 minecraft:red_nether_bricks
setblock 17 216 312 minecraft:nether_wart_block
setblock 17 216 313 minecraft:red_nether_bricks
setblock 18 216 309 minecraft:nether_wart_block
fill 18 216 312 19 216 312 minecraft:red_nether_bricks
setblock 18 216 313 minecraft:nether_wart_block
setblock 18 216 317 minecraft:deepslate_tiles
setblock 19 216 309 minecraft:red_nether_bricks
setblock 19 216 310 minecraft:nether_wart_block
fill 20 216 310 21 216 310 minecraft:red_nether_bricks
fill 20 216 311 20 216 312 minecraft:orange_terracotta
fill 21 216 309 21 218 309 minecraft:red_nether_bricks
fill 21 216 313 21 218 313 minecraft:red_nether_bricks
setblock 22 216 309 minecraft:nether_wart_block
fill 22 216 310 22 216 312 minecraft:orange_terracotta
setblock 22 216 313 minecraft:nether_wart_block
fill 23 216 275 23 217 275 minecraft:blackstone
fill 23 216 310 24 217 310 minecraft:orange_terracotta
fill 23 216 312 24 217 312 minecraft:orange_terracotta
setblock 23 216 313 minecraft:red_nether_bricks
setblock 23 216 317 minecraft:deepslate_tiles
setblock 24 216 275 minecraft:amethyst_block
setblock 24 216 278 minecraft:light[level=12]
setblock 24 216 285 minecraft:light[level=12]
setblock 24 216 292 minecraft:light[level=12]
setblock 24 216 299 minecraft:light[level=12]
setblock 24 216 306 minecraft:light[level=12]
fill 24 216 311 25 217 311 minecraft:orange_terracotta
setblock 24 216 313 minecraft:light[level=12]
setblock 26 216 275 minecraft:deepslate_tiles
setblock 31 216 278 minecraft:light[level=12]
setblock 31 216 285 minecraft:light[level=12]
setblock 31 216 292 minecraft:light[level=12]
setblock 31 216 299 minecraft:light[level=12]
setblock 31 216 306 minecraft:light[level=12]
setblock 31 216 313 minecraft:light[level=12]
setblock 38 216 278 minecraft:light[level=12]
setblock 38 216 285 minecraft:light[level=12]
setblock 38 216 292 minecraft:light[level=12]
setblock 38 216 299 minecraft:light[level=12]
setblock 38 216 306 minecraft:light[level=12]
setblock 38 216 313 minecraft:light[level=12]
fill 42 216 275 42 217 275 minecraft:deepslate_tiles
fill 42 216 276 42 219 276 minecraft:blackstone
setblock 42 216 277 minecraft:deepslate_tiles
setblock 42 216 298 minecraft:deepslate_tiles
setblock 42 216 311 minecraft:deepslate_tiles
fill 0 217 275 0 220 275 minecraft:blackstone
setblock 0 217 281 minecraft:deepslate_tiles
setblock 0 217 287 minecraft:deepslate_tiles
fill 0 217 295 0 219 295 minecraft:blackstone
setblock 0 217 301 minecraft:deepslate_tiles
setblock 0 217 303 minecraft:deepslate_tiles
fill 0 217 304 0 219 304 minecraft:blackstone
fill 0 217 306 0 219 307 minecraft:blackstone
setblock 0 217 308 minecraft:deepslate_tiles
fill 0 217 309 0 219 309 minecraft:blackstone
fill 0 217 312 0 219 312 minecraft:blackstone
setblock 1 217 275 minecraft:deepslate_tiles
setblock 3 217 275 minecraft:blackstone
fill 8 217 275 8 219 275 minecraft:blackstone
setblock 10 217 275 minecraft:deepslate_tiles
fill 15 217 275 15 219 275 minecraft:blackstone
setblock 16 217 310 minecraft:nether_wart_block
setblock 16 217 311 minecraft:red_nether_bricks
setblock 17 217 275 minecraft:magma_block
fill 17 217 310 19 217 310 minecraft:red_nether_bricks
setblock 17 217 311 minecraft:nether_wart_block
setblock 17 217 312 minecraft:red_nether_bricks
fill 18 217 275 18 219 275 minecraft:blackstone
setblock 18 217 309 minecraft:red_nether_bricks
fill 18 217 311 19 217 311 minecraft:red_nether_bricks
setblock 18 217 312 minecraft:nether_wart_block
setblock 18 217 313 minecraft:red_nether_bricks
fill 18 217 317 18 219 317 minecraft:blackstone
setblock 19 217 309 minecraft:nether_wart_block
fill 19 217 312 21 217 312 minecraft:red_nether_bricks
setblock 19 217 313 minecraft:nether_wart_block
setblock 20 217 310 minecraft:nether_wart_block
fill 20 217 311 21 220 311 minecraft:bone_block
setblock 20 217 313 minecraft:red_nether_bricks
fill 21 217 310 22 217 310 minecraft:red_nether_bricks
fill 22 217 309 22 219 309 minecraft:red_nether_bricks
setblock 22 217 311 minecraft:orange_terracotta
setblock 22 217 312 minecraft:nether_wart_block
fill 22 217 313 22 219 313 minecraft:red_nether_bricks
setblock 23 217 309 minecraft:nether_wart_block
setblock 23 217 313 minecraft:nether_wart_block
fill 23 217 317 23 219 317 minecraft:blackstone
fill 24 217 275 24 220 275 minecraft:blackstone
fill 24 217 309 25 217 309 minecraft:red_nether_bricks
setblock 24 217 313 minecraft:red_nether_bricks
fill 24 217 317 24 218 317 minecraft:deepslate_tiles
fill 25 217 310 27 218 310 minecraft:orange_terracotta
fill 25 217 312 25 219 312 minecraft:red_nether_bricks
fill 25 217 317 26 219 317 minecraft:blackstone
fill 26 217 275 26 220 275 minecraft:blackstone
fill 26 217 311 26 219 311 minecraft:orange_terracotta
setblock 26 217 312 minecraft:nether_wart_block
setblock 30 217 317 minecraft:deepslate_tiles
fill 34 217 275 36 219 275 minecraft:blackstone
setblock 37 217 275 minecraft:deepslate_tiles
fill 38 217 275 39 217 275 minecraft:blackstone
setblock 40 217 317 minecraft:deepslate_tiles
fill 42 217 277 42 219 277 minecraft:blackstone
fill 42 217 291 42 218 291 minecraft:deepslate_tiles
fill 42 217 298 42 219 298 minecraft:blackstone
setblock 42 217 310 minecraft:amethyst_block
fill 42 217 311 42 220 311 minecraft:blackstone
fill 0 218 281 0 219 282 minecraft:blackstone
setblock 0 218 283 minecraft:deepslate_tiles
fill 0 218 287 0 219 287 minecraft:blackstone
setblock 0 218 291 minecraft:purple_concrete
setblock 0 218 298 minecraft:deepslate_tiles
fill 0 218 299 0 219 299 minecraft:blackstone
fill 0 218 301 0 219 301 minecraft:blackstone
fill 0 218 303 0 220 303 minecraft:blackstone
fill 0 218 308 0 219 308 minecraft:blackstone
setblock 0 218 310 minecraft:deepslate_tiles
setblock 0 218 317 minecraft:deepslate_tiles
fill 1 218 275 1 219 275 minecraft:blackstone
setblock 3 218 275 minecraft:deepslate_tiles
setblock 3 218 278 minecraft:light[level=12]
setblock 3 218 286 minecraft:light[level=12]
setblock 3 218 294 minecraft:light[level=12]
setblock 3 218 302 minecraft:light[level=12]
setblock 3 218 310 minecraft:light[level=12]
setblock 3 218 317 minecraft:deepslate_tiles
setblock 5 218 317 minecraft:deepslate_tiles
fill 6 218 317 7 219 317 minecraft:blackstone
setblock 8 218 317 minecraft:deepslate_tiles
fill 10 218 275 10 219 275 minecraft:blackstone
setblock 11 218 278 minecraft:light[level=12]
setblock 11 218 286 minecraft:light[level=12]
setblock 11 218 294 minecraft:light[level=12]
setblock 11 218 302 minecraft:light[level=12]
setblock 11 218 310 minecraft:light[level=12]
fill 17 218 275 17 219 275 minecraft:blackstone
fill 18 218 310 20 218 310 minecraft:red_nether_bricks
setblock 18 218 311 minecraft:nether_wart_block
setblock 18 218 312 minecraft:red_nether_bricks
setblock 19 218 278 minecraft:light[level=12]
setblock 19 218 286 minecraft:light[level=12]
setblock 19 218 294 minecraft:light[level=12]
setblock 19 218 302 minecraft:light[level=12]
setblock 19 218 311 minecraft:red_nether_bricks
setblock 19 218 312 minecraft:nether_wart_block
setblock 20 218 309 minecraft:nether_wart_block
fill 20 218 312 22 218 312 minecraft:red_nether_bricks
setblock 20 218 313 minecraft:nether_wart_block
setblock 21 218 310 minecraft:nether_wart_block
fill 22 218 310 24 218 310 minecraft:red_nether_bricks
setblock 22 218 311 minecraft:nether_wart_block
setblock 23 218 275 minecraft:deepslate_tiles
fill 23 218 309 23 219 309 minecraft:red_nether_bricks
setblock 23 218 311 minecraft:red_nether_bricks
setblock 23 218 312 minecraft:nether_wart_block
fill 23 218 313 23 219 313 minecraft:red_nether_bricks
setblock 24 218 309 minecraft:nether_wart_block
setblock 24 218 311 minecraft:orange_terracotta
setblock 24 218 312 minecraft:red_nether_bricks
setblock 24 218 313 minecraft:nether_wart_block
setblock 25 218 309 minecraft:red_nether_bricks
fill 25 218 311 25 220 311 minecraft:red_nether_bricks
setblock 25 218 313 minecraft:red_nether_bricks
fill 26 218 309 28 218 309 minecraft:orange_terracotta
fill 26 218 312 26 220 312 minecraft:red_nether_bricks
setblock 27 218 278 minecraft:light[level=12]
setblock 27 218 286 minecraft:light[level=12]
setblock 27 218 294 minecraft:light[level=12]
setblock 27 218 302 minecraft:light[level=12]
fill 27 218 311 27 219 311 minecraft:orange_terracotta
setblock 27 218 312 minecraft:nether_wart_block
fill 28 218 310 28 219 310 minecraft:orange_terracotta
setblock 28 218 311 minecraft:red_nether_bricks
fill 30 218 317 30 219 317 minecraft:blackstone
fill 32 218 317 33 218 317 minecraft:deepslate_tiles
setblock 35 218 278 minecraft:light[level=12]
setblock 35 218 286 minecraft:light[level=12]
setblock 35 218 294 minecraft:light[level=12]
setblock 35 218 302 minecraft:light[level=12]
setblock 35 218 310 minecraft:light[level=12]
fill 37 218 275 38 219 275 minecraft:blackstone
fill 38 218 317 39 218 317 minecraft:deepslate_tiles
fill 39 218 275 40 218 275 minecraft:deepslate_tiles
fill 40 218 317 40 220 317 minecraft:blackstone
fill 42 218 275 42 219 275 minecraft:blackstone
setblock 42 218 278 minecraft:deepslate_tiles
fill 42 218 280 42 218 281 minecraft:deepslate_tiles
fill 42 218 282 42 219 282 minecraft:blackstone
setblock 42 218 289 minecraft:deepslate_tiles
setblock 42 218 293 minecraft:deepslate_tiles
setblock 42 218 310 minecraft:deepslate_tiles
setblock 0 219 283 minecraft:blackstone
setblock 0 219 291 minecraft:blackstone
setblock 0 219 298 minecraft:blackstone
setblock 0 219 310 minecraft:blackstone
setblock 0 219 313 minecraft:blackstone
setblock 0 219 314 minecraft:purple_concrete
setblock 0 219 317 minecraft:blackstone
fill 3 219 275 3 220 275 minecraft:blackstone
setblock 3 219 317 minecraft:blackstone
setblock 4 219 275 minecraft:magma_block
setblock 5 219 317 minecraft:blackstone
setblock 8 219 317 minecraft:blackstone
fill 14 219 305 14 220 305 minecraft:raw_gold_block
fill 20 219 310 21 219 310 minecraft:red_nether_bricks
setblock 20 219 312 minecraft:nether_wart_block
fill 21 219 312 23 219 312 minecraft:red_nether_bricks
setblock 21 219 313 minecraft:nether_wart_block
setblock 22 219 310 minecraft:nether_wart_block
fill 22 219 311 22 220 311 minecraft:red_nether_bricks
setblock 23 219 275 minecraft:blackstone
fill 23 219 310 25 219 310 minecraft:red_nether_bricks
setblock 23 219 311 minecraft:nether_wart_block
fill 24 219 309 24 220 309 minecraft:red_nether_bricks
setblock 24 219 311 minecraft:red_nether_bricks
setblock 24 219 312 minecraft:nether_wart_block
fill 24 219 313 24 220 313 minecraft:red_nether_bricks
setblock 24 219 317 minecraft:blackstone
fill 25 219 308 27 219 308 minecraft:red_nether_bricks
setblock 25 219 309 minecraft:nether_wart_block
setblock 25 219 313 minecraft:nether_wart_block
setblock 26 219 309 minecraft:red_nether_bricks
fill 26 219 310 27 219 310 minecraft:orange_terracotta
setblock 26 219 313 minecraft:red_nether_bricks
fill 27 219 309 30 219 309 minecraft:orange_terracotta
fill 27 219 312 27 221 312 minecraft:red_nether_bricks
setblock 28 219 308 minecraft:nether_wart_block
setblock 28 219 311 minecraft:orange_terracotta
setblock 28 219 312 minecraft:nether_wart_block
fill 29 219 308 30 221 308 minecraft:orange_terracotta
fill 29 219 310 29 219 311 minecraft:red_nether_bricks
setblock 30 219 310 minecraft:nether_wart_block
fill 32 219 317 33 219 317 minecraft:blackstone
fill 38 219 317 39 219 317 minecraft:blackstone
fill 39 219 275 40 219 275 minecraft:blackstone
setblock 42 219 278 minecraft:blackstone
fill 42 219 280 42 219 281 minecraft:blackstone
fill 42 219 289 42 220 289 minecraft:blackstone
setblock 42 219 291 minecraft:blackstone
setblock 42 219 293 minecraft:purple_concrete
setblock 42 219 310 minecraft:blackstone
fill 0 220 276 0 220 287 minecraft:deepslate_tiles
fill 0 220 288 0 220 289 minecraft:blackstone
fill 0 220 290 0 220 302 minecraft:deepslate_tiles
fill 0 220 304 0 246 304 minecraft:deepslate_tiles
fill 0 220 306 0 220 311 minecraft:deepslate_tiles
setblock 0 220 312 minecraft:magma_block
fill 0 220 313 0 221 317 minecraft:deepslate_tiles
fill 1 220 275 2 220 275 minecraft:deepslate_tiles
fill 1 220 317 26 220 317 minecraft:deepslate_tiles
fill 4 220 275 20 220 275 minecraft:deepslate_tiles
fill 22 220 275 23 256 275 minecraft:deepslate_tiles
setblock 22 220 310 minecraft:red_nether_bricks
fill 22 220 312 24 220 312 minecraft:red_nether_bricks
setblock 23 220 310 minecraft:nether_wart_block
setblock 23 220 311 minecraft:red_nether_bricks
fill 24 220 310 26 220 310 minecraft:red_nether_bricks
setblock 24 220 311 minecraft:nether_wart_block
fill 25 220 275 25 308 275 minecraft:deepslate_tiles
setblock 25 220 308 minecraft:nether_wart_block
fill 25 220 309 25 221 309 minecraft:red_nether_bricks
setblock 25 220 312 minecraft:nether_wart_block
setblock 25 220 313 minecraft:red_nether_bricks
fill 26 220 308 28 220 308 minecraft:red_nether_bricks
setblock 26 220 309 minecraft:nether_wart_block
fill 26 220 311 27 221 311 minecraft:red_nether_bricks
fill 27 220 275 42 221 275 minecraft:deepslate_tiles
fill 27 220 309 28 220 309 minecraft:red_nether_bricks
setblock 27 220 310 minecraft:orange_terracotta
setblock 28 220 307 minecraft:nether_wart_block
setblock 28 220 310 minecraft:red_nether_bricks
setblock 28 220 311 minecraft:nether_wart_block
fill 28 220 312 28 221 312 minecraft:red_nether_bricks
fill 28 220 317 31 221 317 minecraft:deepslate_tiles
setblock 29 220 307 minecraft:red_nether_bricks
fill 29 220 309 29 220 310 minecraft:orange_terracotta
fill 29 220 311 30 220 311 minecraft:red_nether_bricks
fill 30 220 307 31 221 307 minecraft:orange_terracotta
fill 30 220 309 31 221 309 minecraft:orange_terracotta
fill 30 220 310 30 222 310 minecraft:red_nether_bricks
fill 31 220 308 31 221 308 minecraft:orange_terracotta
setblock 31 220 310 minecraft:nether_wart_block
setblock 32 220 317 minecraft:blackstone
fill 33 220 317 38 221 317 minecraft:deepslate_tiles
setblock 39 220 317 minecraft:blackstone
fill 41 220 317 41 273 317 minecraft:deepslate_tiles
fill 42 220 276 42 221 282 minecraft:deepslate_tiles
fill 42 220 284 42 220 288 minecraft:deepslate_tiles
fill 42 220 290 42 220 298 minecraft:deepslate_tiles
fill 42 220 301 42 235 310 minecraft:deepslate_tiles
fill 42 220 312 42 221 313 minecraft:deepslate_tiles
fill 42 220 315 42 221 315 minecraft:deepslate_tiles
fill 0 221 275 0 236 280 minecraft:deepslate_tiles
setblock 0 221 281 minecraft:blackstone
fill 0 221 282 0 295 285 minecraft:deepslate_tiles
setblock 0 221 286 minecraft:blackstone
fill 0 221 287 0 221 299 minecraft:deepslate_tiles
setblock 0 221 300 minecraft:blackstone
fill 0 221 301 0 235 303 minecraft:deepslate_tiles
setblock 0 221 306 minecraft:blackstone
fill 0 221 307 0 221 311 minecraft:deepslate_tiles
setblock 0 221 312 minecraft:blackstone
setblock 1 221 275 minecraft:crying_obsidian
fill 1 221 317 17 221 317 minecraft:deepslate_tiles
fill 2 221 275 10 221 275 minecraft:deepslate_tiles
setblock 11 221 275 minecraft:blackstone
fill 12 221 275 20 221 275 minecraft:deepslate_tiles
setblock 18 221 317 minecraft:blackstone
fill 19 221 317 20 274 317 minecraft:deepslate_tiles
setblock 21 221 275 minecraft:purple_concrete
setblock 21 221 317 minecraft:blackstone
fill 22 221 317 27 241 317 minecraft:deepslate_tiles
fill 24 221 275 24 308 275 minecraft:deepslate_tiles
setblock 24 221 310 minecraft:nether_wart_block
fill 24 221 311 24 221 312 minecraft:red_nether_bricks
fill 25 221 310 26 221 310 minecraft:red_nether_bricks
setblock 25 221 311 minecraft:nether_wart_block
setblock 25 221 312 minecraft:red_nether_bricks
fill 26 221 275 26 308 275 minecraft:deepslate_tiles
setblock 26 221 308 minecraft:nether_wart_block
fill 26 221 309 26 222 309 minecraft:red_nether_bricks
setblock 26 221 312 minecraft:nether_wart_block
fill 27 221 308 28 221 308 minecraft:red_nether_bricks
setblock 27 221 309 minecraft:nether_wart_block
fill 27 221 310 28 223 310 minecraft:bone_block
fill 28 221 307 28 222 307 minecraft:red_nether_bricks
setblock 28 221 309 minecraft:red_nether_bricks
fill 28 221 311 28 222 311 minecraft:red_nether_bricks
fill 29 221 306 30 221 306 minecraft:red_nether_bricks
setblock 29 221 307 minecraft:nether_wart_block
setblock 29 221 309 minecraft:orange_terracotta
setblock 29 221 310 minecraft:red_nether_bricks
setblock 29 221 311 minecraft:nether_wart_block
setblock 30 221 311 minecraft:red_nether_bricks
fill 31 221 306 33 222 306 minecraft:orange_terracotta
fill 31 221 310 31 223 310 minecraft:red_nether_bricks
fill 32 221 307 33 222 307 minecraft:orange_terracotta
fill 32 221 308 32 221 309 minecraft:red_nether_bricks
fill 32 221 317 32 308 317 minecraft:deepslate_tiles
fill 33 221 305 33 223 305 minecraft:orange_terracotta
fill 33 221 308 33 223 308 minecraft:red_nether_bricks
fill 39 221 317 40 238 317 minecraft:deepslate_tiles
fill 42 221 284 42 308 284 minecraft:deepslate_tiles
fill 42 221 285 42 222 285 minecraft:blackstone
fill 42 221 286 42 221 293 minecraft:deepslate_tiles
setblock 42 221 294 minecraft:blackstone
fill 42 221 295 42 231 300 minecraft:deepslate_tiles
fill 42 221 311 42 308 311 minecraft:deepslate_tiles
fill 42 221 314 42 271 314 minecraft:deepslate_tiles
fill 42 221 316 42 308 316 minecraft:deepslate_tiles
fill 0 222 281 0 230 281 minecraft:deepslate_tiles
fill 0 222 286 0 235 289 minecraft:deepslate_tiles
setblock 0 222 290 minecraft:blackstone
fill 0 222 291 0 231 296 minecraft:deepslate_tiles
setblock 0 222 297 minecraft:blackstone
fill 0 222 298 0 239 300 minecraft:deepslate_tiles
fill 0 222 305 0 262 306 minecraft:deepslate_tiles
setblock 0 222 307 minecraft:blackstone
fill 0 222 308 0 290 313 minecraft:deepslate_tiles
setblock 0 222 314 minecraft:blackstone
fill 0 222 315 0 243 316 minecraft:deepslate_tiles
setblock 0 222 317 minecraft:blackstone
fill 1 222 275 5 263 275 minecraft:deepslate_tiles
fill 1 222 317 9 228 317 minecraft:deepslate_tiles
setblock 3 222 278 minecraft:light[level=12]
setblock 3 222 285 minecraft:light[level=12]
setblock 3 222 292 minecraft:light[level=12]
setblock 3 222 299 minecraft:light[level=12]
setblock 3 222 306 minecraft:light[level=12]
setblock 3 222 313 minecraft:light[level=12]
setblock 6 222 275 minecraft:blackstone
fill 7 222 275 7 308 275 minecraft:deepslate_tiles
setblock 8 222 275 minecraft:blackstone
fill 9 222 275 16 246 275 minecraft:deepslate_tiles
setblock 10 222 278 minecraft:light[level=12]
setblock 10 222 285 minecraft:light[level=12]
setblock 10 222 292 minecraft:light[level=12]
setblock 10 222 299 minecraft:light[level=12]
setblock 10 222 306 minecraft:light[level=12]
setblock 10 222 313 minecraft:light[level=12]
setblock 10 222 317 minecraft:blackstone
fill 11 222 317 18 233 317 minecraft:deepslate_tiles
setblock 17 222 275 minecraft:blackstone
setblock 17 222 278 minecraft:light[level=12]
setblock 17 222 285 minecraft:light[level=12]
setblock 17 222 292 minecraft:light[level=12]
setblock 17 222 299 minecraft:light[level=12]
setblock 17 222 306 minecraft:light[level=12]
setblock 17 222 313 minecraft:light[level=12]
fill 18 222 275 21 231 275 minecraft:deepslate_tiles
fill 21 222 317 21 232 317 minecraft:deepslate_tiles
setblock 24 222 278 minecraft:light[level=12]
setblock 24 222 285 minecraft:light[level=12]
setblock 24 222 292 minecraft:light[level=12]
setblock 24 222 299 minecraft:light[level=12]
setblock 24 222 306 minecraft:light[level=12]
setblock 24 222 313 minecraft:light[level=12]
setblock 26 222 310 minecraft:red_nether_bricks
setblock 26 222 311 minecraft:nether_wart_block
fill 27 222 275 29 231 275 minecraft:deepslate_tiles
setblock 27 222 308 minecraft:nether_wart_block
fill 27 222 309 27 223 309 minecraft:red_nether_bricks
setblock 27 222 311 minecraft:red_nether_bricks
fill 28 222 308 30 222 308 minecraft:red_nether_bricks
setblock 28 222 309 minecraft:nether_wart_block
setblock 28 222 317 minecraft:blackstone
setblock 29 222 306 minecraft:nether_wart_block
fill 29 222 307 29 224 307 minecraft:red_nether_bricks
fill 29 222 309 31 222 309 minecraft:red_nether_bricks
setblock 29 222 310 minecraft:nether_wart_block
setblock 29 222 311 minecraft:red_nether_bricks
fill 29 222 317 29 308 317 minecraft:deepslate_tiles
setblock 30 222 275 minecraft:blackstone
setblock 30 222 306 minecraft:red_nether_bricks
setblock 30 222 307 minecraft:nether_wart_block
setblock 30 222 311 minecraft:nether_wart_block
setblock 30 222 317 minecraft:blackstone
fill 31 222 275 32 308 275 minecraft:deepslate_tiles
setblock 31 222 278 minecraft:light[level=12]
setblock 31 222 285 minecraft:light[level=12]
setblock 31 222 292 minecraft:light[level=12]
setblock 31 222 299 minecraft:light[level=12]
fill 31 222 305 31 224 305 minecraft:red_nether_bricks
setblock 31 222 307 minecraft:orange_terracotta
setblock 31 222 308 minecraft:nether_wart_block
setblock 31 222 313 minecraft:light[level=12]
fill 31 222 317 31 308 317 minecraft:deepslate_tiles
fill 32 222 304 34 222 304 minecraft:red_nether_bricks
fill 32 222 305 32 223 305 minecraft:orange_terracotta
setblock 32 222 308 minecraft:red_nether_bricks
setblock 32 222 309 minecraft:nether_wart_block
setblock 33 222 275 minecraft:blackstone
fill 33 222 283 33 223 284 minecraft:raw_gold_block
setblock 33 222 309 minecraft:red_nether_bricks
fill 33 222 317 35 246 317 minecraft:deepslate_tiles
fill 34 222 275 36 308 275 minecraft:deepslate_tiles
fill 34 222 305 34 222 306 minecraft:orange_terracotta
setblock 34 222 307 minecraft:nether_wart_block
setblock 36 222 317 minecraft:blackstone
setblock 37 222 275 minecraft:blackstone
fill 37 222 317 38 232 317 minecraft:deepslate_tiles
fill 38 222 275 40 232 275 minecraft:deepslate_tiles
setblock 38 222 278 minecraft:light[level=12]
setblock 38 222 285 minecraft:light[level=12]
setblock 38 222 292 minecraft:light[level=12]
setblock 38 222 299 minecraft:light[level=12]
setblock 38 222 306 minecraft:light[level=12]
setblock 38 222 313 minecraft:light[level=12]
setblock 41 222 275 minecraft:blackstone
fill 42 222 275 42 224 280 minecraft:deepslate_tiles
setblock 42 222 281 minecraft:blackstone
fill 42 222 282 42 308 282 minecraft:deepslate_tiles
fill 42 222 286 42 272 286 minecraft:deepslate_tiles
setblock 42 222 287 minecraft:blackstone
fill 42 222 288 42 235 294 minecraft:deepslate_tiles
fill 42 222 312 42 222 313 minecraft:blackstone
setblock 42 222 315 minecraft:blackstone
fill 42 222 317 42 308 317 minecraft:deepslate_tiles
fill 0 223 290 0 225 290 minecraft:deepslate_tiles
fill 0 223 297 0 308 297 minecraft:deepslate_tiles
fill 0 223 307 0 241 307 minecraft:deepslate_tiles
fill 0 223 314 0 308 314 minecraft:deepslate_tiles
fill 0 223 317 0 308 317 minecraft:deepslate_tiles
fill 6 223 275 6 255 275 minecraft:deepslate_tiles
fill 8 223 275 8 308 275 minecraft:deepslate_tiles
fill 10 223 317 10 266 317 minecraft:deepslate_tiles
fill 17 223 275 17 237 275 minecraft:deepslate_tiles
setblock 28 223 308 minecraft:nether_wart_block
setblock 28 223 309 minecraft:red_nether_bricks
fill 28 223 317 28 308 317 minecraft:deepslate_tiles
setblock 29 223 306 minecraft:red_nether_bricks
fill 29 223 308 31 223 308 minecraft:red_nether_bricks
setblock 29 223 309 minecraft:nether_wart_block
setblock 29 223 310 minecraft:red_nether_bricks
fill 30 223 275 30 308 275 minecraft:deepslate_tiles
setblock 30 223 305 minecraft:red_nether_bricks
setblock 30 223 306 minecraft:nether_wart_block
fill 30 223 307 30 224 307 minecraft:red_nether_bricks
fill 30 223 309 32 223 309 minecraft:red_nether_bricks
setblock 30 223 310 minecraft:nether_wart_block
fill 30 223 317 30 308 317 minecraft:deepslate_tiles
fill 31 223 304 31 225 304 minecraft:red_nether_bricks
setblock 31 223 306 minecraft:red_nether_bricks
setblock 31 223 307 minecraft:nether_wart_block
setblock 32 223 304 minecraft:nether_wart_block
fill 32 223 306 33 223 306 minecraft:orange_terracotta
fill 32 223 307 34 223 307 minecraft:red_nether_bricks
setblock 32 223 308 minecraft:nether_wart_block
fill 33 223 275 33 308 275 minecraft:deepslate_tiles
fill 33 223 303 35 223 304 minecraft:orange_terracotta
setblock 33 223 309 minecraft:nether_wart_block
fill 34 223 302 35 225 302 minecraft:orange_terracotta
fill 34 223 305 35 223 305 minecraft:red_nether_bricks
setblock 34 223 306 minecraft:nether_wart_block
fill 34 223 308 34 224 308 minecraft:red_nether_bricks
setblock 35 223 306 minecraft:red_nether_bricks
fill 36 223 317 36 308 317 minecraft:deepslate_tiles
fill 37 223 275 37 231 275 minecraft:deepslate_tiles
fill 41 223 275 41 308 275 minecraft:deepslate_tiles
fill 42 223 281 42 225 281 minecraft:deepslate_tiles
fill 42 223 283 42 308 283 minecraft:deepslate_tiles
fill 42 223 285 42 256 285 minecraft:deepslate_tiles
fill 42 223 287 42 308 287 minecraft:deepslate_tiles
fill 42 223 312 42 253 313 minecraft:deepslate_tiles
fill 42 223 315 42 227 315 minecraft:deepslate_tiles
fill 24 224 310 24 225 311 minecraft:raw_gold_block
setblock 27 224 310 minecraft:bone_block
setblock 29 224 308 minecraft:nether_wart_block
setblock 29 224 309 minecraft:red_nether_bricks
setblock 30 224 306 minecraft:red_nether_bricks
fill 30 224 308 32 224 308 minecraft:red_nether_bricks
setblock 30 224 309 minecraft:nether_wart_block
setblock 31 224 306 minecraft:nether_wart_block
fill 31 224 307 31 225 307 minecraft:red_nether_bricks
fill 31 224 309 32 224 309 minecraft:red_nether_bricks
setblock 32 224 303 minecraft:nether_wart_block
fill 32 224 304 32 224 306 minecraft:red_nether_bricks
setblock 32 224 307 minecraft:nether_wart_block
fill 33 224 302 33 224 303 minecraft:red_nether_bricks
fill 33 224 304 35 224 304 minecraft:orange_terracotta
fill 33 224 305 33 227 306 minecraft:bone_block
fill 33 224 307 34 224 307 minecraft:red_nether_bricks
setblock 33 224 308 minecraft:nether_wart_block
setblock 34 224 301 minecraft:nether_wart_block
fill 34 224 303 36 224 303 minecraft:orange_terracotta
setblock 34 224 305 minecraft:nether_wart_block
fill 34 224 306 34 226 306 minecraft:red_nether_bricks
fill 35 224 300 36 226 300 minecraft:orange_terracotta
fill 35 224 301 36 224 301 minecraft:red_nether_bricks
fill 35 224 305 36 224 305 minecraft:red_nether_bricks
setblock 35 224 306 minecraft:nether_wart_block
fill 36 224 277 36 228 277 minecraft:blackstone
setblock 36 224 302 minecraft:orange_terracotta
fill 36 224 304 36 226 304 minecraft:red_nether_bricks
setblock 3 225 278 minecraft:light[level=12]
setblock 3 225 286 minecraft:light[level=12]
setblock 3 225 294 minecraft:light[level=12]
setblock 3 225 302 minecraft:light[level=12]
setblock 3 225 310 minecraft:light[level=12]
setblock 11 225 278 minecraft:light[level=12]
setblock 11 225 286 minecraft:light[level=12]
setblock 11 225 294 minecraft:light[level=12]
setblock 11 225 302 minecraft:light[level=12]
setblock 11 225 310 minecraft:light[level=12]
setblock 19 225 278 minecraft:light[level=12]
setblock 19 225 286 minecraft:light[level=12]
setblock 19 225 294 minecraft:light[level=12]
setblock 19 225 302 minecraft:light[level=12]
setblock 19 225 310 minecraft:light[level=12]
setblock 27 225 278 minecraft:light[level=12]
setblock 27 225 286 minecraft:light[level=12]
setblock 27 225 294 minecraft:light[level=12]
setblock 27 225 302 minecraft:light[level=12]
setblock 27 225 310 minecraft:light[level=12]
setblock 31 225 305 minecraft:nether_wart_block
setblock 31 225 306 minecraft:red_nether_bricks
fill 31 225 308 33 225 308 minecraft:red_nether_bricks
fill 32 225 303 32 225 305 minecraft:red_nether_bricks
setblock 32 225 306 minecraft:nether_wart_block
setblock 32 225 307 minecraft:red_nether_bricks
fill 33 225 301 33 225 302 minecraft:red_nether_bricks
setblock 33 225 303 minecraft:nether_wart_block
fill 33 225 304 33 227 304 minecraft:red_nether_bricks
setblock 33 225 307 minecraft:nether_wart_block
setblock 34 225 300 minecraft:nether_wart_block
fill 34 225 301 34 227 301 minecraft:red_nether_bricks
fill 34 225 303 35 225 303 minecraft:orange_terracotta
setblock 34 225 304 minecraft:nether_wart_block
fill 34 225 305 34 227 305 minecraft:red_nether_bricks
setblock 34 225 307 minecraft:red_nether_bricks
setblock 35 225 278 minecraft:light[level=12]
setblock 35 225 286 minecraft:light[level=12]
setblock 35 225 294 minecraft:light[level=12]
fill 35 225 299 36 226 299 minecraft:orange_terracotta
fill 35 225 301 36 226 301 minecraft:orange_terracotta
setblock 35 225 304 minecraft:red_nether_bricks
setblock 35 225 305 minecraft:nether_wart_block
fill 35 225 306 35 226 306 minecraft:red_nether_bricks
setblock 35 225 310 minecraft:light[level=12]
setblock 36 225 302 minecraft:nether_wart_block
fill 36 225 303 36 227 303 minecraft:red_nether_bricks
setblock 36 225 305 minecraft:red_nether_bricks
fill 37 225 300 37 225 302 minecraft:red_nether_bricks
setblock 37 225 303 minecraft:nether_wart_block
fill 41 225 279 42 227 280 minecraft:amethyst_block
fill 42 225 275 42 291 278 minecraft:deepslate_tiles
setblock 0 226 290 minecraft:crying_obsidian
fill 12 226 300 13 227 300 minecraft:raw_gold_block
fill 32 226 303 32 226 304 minecraft:red_nether_bricks
setblock 32 226 305 minecraft:nether_wart_block
setblock 32 226 306 minecraft:red_nether_bricks
fill 33 226 300 33 226 301 minecraft:red_nether_bricks
setblock 33 226 302 minecraft:nether_wart_block
fill 33 226 303 33 227 303 minecraft:red_nether_bricks
setblock 34 226 299 minecraft:nether_wart_block
fill 34 226 300 34 228 300 minecraft:red_nether_bricks
fill 34 226 302 36 226 302 minecraft:red_nether_bricks
setblock 34 226 303 minecraft:nether_wart_block
fill 34 226 304 34 227 304 minecraft:red_nether_bricks
fill 35 226 297 35 226 298 minecraft:red_nether_bricks
setblock 35 226 303 minecraft:red_nether_bricks
setblock 35 226 304 minecraft:nether_wart_block
fill 35 226 305 35 227 305 minecraft:red_nether_bricks
fill 36 226 296 36 227 298 minecraft:orange_terracotta
setblock 36 226 305 minecraft:nether_wart_block
fill 37 226 297 37 228 297 minecraft:orange_terracotta
setblock 37 226 298 minecraft:nether_wart_block
fill 37 226 299 37 226 300 minecraft:orange_terracotta
setblock 37 226 301 minecraft:red_nether_bricks
setblock 37 226 302 minecraft:nether_wart_block
fill 37 226 303 37 227 303 minecraft:red_nether_bricks
setblock 38 226 299 minecraft:nether_wart_block
fill 38 226 300 38 228 300 minecraft:red_nether_bricks
fill 40 226 279 40 227 281 minecraft:amethyst_block
fill 41 226 281 42 227 281 minecraft:amethyst_block
fill 0 227 290 0 308 290 minecraft:deepslate_tiles
setblock 33 227 300 minecraft:red_nether_bricks
setblock 33 227 301 minecraft:nether_wart_block
setblock 33 227 302 minecraft:red_nether_bricks
setblock 34 227 297 minecraft:red_nether_bricks
setblock 34 227 298 minecraft:nether_wart_block
fill 34 227 299 34 229 299 minecraft:red_nether_bricks
setblock 34 227 302 minecraft:nether_wart_block
fill 34 227 303 34 228 303 minecraft:red_nether_bricks
fill 35 227 277 35 228 277 minecraft:blackstone
setblock 35 227 295 minecraft:nether_wart_block
fill 35 227 296 35 227 297 minecraft:orange_terracotta
setblock 35 227 298 minecraft:red_nether_bricks
setblock 35 227 299 minecraft:nether_wart_block
fill 35 227 300 35 227 302 minecraft:red_nether_bricks
setblock 35 227 303 minecraft:nether_wart_block
setblock 35 227 304 minecraft:red_nether_bricks
fill 36 227 276 36 228 276 minecraft:blackstone
fill 36 227 278 36 228 278 minecraft:blackstone
fill 36 227 295 37 228 295 minecraft:orange_terracotta
setblock 36 227 299 minecraft:orange_terracotta
setblock 36 227 300 minecraft:nether_wart_block
fill 36 227 301 36 228 302 minecraft:red_nether_bricks
setblock 36 227 304 minecraft:nether_wart_block
fill 37 227 277 37 228 277 minecraft:blackstone
fill 37 227 296 37 228 296 minecraft:orange_terracotta
setblock 37 227 298 minecraft:orange_terracotta
fill 37 227 299 37 227 300 minecraft:red_nether_bricks
setblock 37 227 301 minecraft:nether_wart_block
fill 37 227 302 37 228 302 minecraft:red_nether_bricks
fill 38 227 296 38 227 297 minecraft:red_nether_bricks
setblock 38 227 298 minecraft:nether_wart_block
fill 38 227 299 38 229 299 minecraft:red_nether_bricks
setblock 38 227 301 minecraft:red_nether_bricks
setblock 3 228 278 minecraft:light[level=12]
setblock 3 228 285 minecraft:light[level=12]
setblock 3 228 292 minecraft:light[level=12]
setblock 3 228 299 minecraft:light[level=12]
setblock 3 228 306 minecraft:light[level=12]
setblock 3 228 313 minecraft:light[level=12]
setblock 10 228 278 minecraft:light[level=12]
setblock 10 228 285 minecraft:light[level=12]
setblock 10 228 292 minecraft:light[level=12]
setblock 10 228 299 minecraft:light[level=12]
setblock 10 228 306 minecraft:light[level=12]
setblock 10 228 313 minecraft:light[level=12]
setblock 17 228 278 minecraft:light[level=12]
setblock 17 228 285 minecraft:light[level=12]
setblock 17 228 292 minecraft:light[level=12]
setblock 17 228 299 minecraft:light[level=12]
setblock 17 228 306 minecraft:light[level=12]
setblock 17 228 313 minecraft:light[level=12]
setblock 24 228 278 minecraft:light[level=12]
setblock 24 228 285 minecraft:light[level=12]
setblock 24 228 292 minecraft:light[level=12]
setblock 24 228 299 minecraft:light[level=12]
setblock 24 228 306 minecraft:light[level=12]
setblock 24 228 313 minecraft:light[level=12]
fill 29 228 276 31 229 277 minecraft:amethyst_block
fill 30 228 278 30 229 278 minecraft:amethyst_block
setblock 31 228 278 minecraft:light[level=12]
setblock 31 228 285 minecraft:light[level=12]
setblock 31 228 292 minecraft:light[level=12]
setblock 31 228 299 minecraft:light[level=12]
setblock 31 228 306 minecraft:light[level=12]
setblock 31 228 313 minecraft:light[level=12]
fill 34 228 295 34 228 296 minecraft:red_nether_bricks
setblock 34 228 297 minecraft:nether_wart_block
fill 34 228 298 34 229 298 minecraft:red_nether_bricks
setblock 34 228 301 minecraft:nether_wart_block
setblock 34 228 302 minecraft:red_nether_bricks
setblock 35 228 276 minecraft:blackstone
setblock 35 228 278 minecraft:blackstone
fill 35 228 293 37 229 293 minecraft:orange_terracotta
setblock 35 228 294 minecraft:nether_wart_block
fill 35 228 295 35 230 295 minecraft:red_nether_bricks
fill 35 228 296 36 228 296 minecraft:orange_terracotta
setblock 35 228 297 minecraft:red_nether_bricks
setblock 35 228 298 minecraft:nether_wart_block
fill 35 228 299 35 228 301 minecraft:red_nether_bricks
setblock 35 228 302 minecraft:nether_wart_block
setblock 35 228 303 minecraft:red_nether_bricks
fill 36 228 292 36 230 292 minecraft:orange_terracotta
fill 36 228 294 36 230 294 minecraft:orange_terracotta
setblock 36 228 297 minecraft:orange_terracotta
fill 36 228 298 38 228 298 minecraft:red_nether_bricks
fill 36 228 299 36 231 299 minecraft:bone_block
fill 36 228 300 36 229 300 minecraft:red_nether_bricks
setblock 36 228 303 minecraft:nether_wart_block
setblock 37 228 276 minecraft:blackstone
setblock 37 228 278 minecraft:blackstone
setblock 37 228 294 minecraft:red_nether_bricks
setblock 37 228 299 minecraft:red_nether_bricks
setblock 37 228 300 minecraft:nether_wart_block
fill 37 228 301 37 229 301 minecraft:red_nether_bricks
setblock 38 228 278 minecraft:light[level=12]
setblock 38 228 285 minecraft:light[level=12]
setblock 38 228 292 minecraft:light[level=12]
fill 38 228 295 38 228 296 minecraft:red_nether_bricks
setblock 38 228 297 minecraft:nether_wart_block
setblock 38 228 306 minecraft:light[level=12]
setblock 38 228 313 minecraft:light[level=12]
setblock 40 228 280 minecraft:amethyst_block
setblock 41 228 279 minecraft:amethyst_block
setblock 41 228 281 minecraft:amethyst_block
fill 42 228 279 42 308 279 minecraft:deepslate_tiles
setblock 42 228 280 minecraft:amethyst_block
fill 42 228 281 42 308 281 minecraft:deepslate_tiles
setblock 42 228 315 minecraft:amethyst_block
fill 1 229 317 1 308 317 minecraft:deepslate_tiles
setblock 2 229 317 minecraft:purple_concrete
fill 3 229 317 9 275 317 minecraft:deepslate_tiles
setblock 29 229 278 minecraft:amethyst_block
fill 30 229 279 30 229 281 minecraft:amethyst_block
setblock 31 229 278 minecraft:amethyst_block
fill 34 229 293 34 229 295 minecraft:red_nether_bricks
setblock 34 229 296 minecraft:nether_wart_block
fill 34 229 297 34 230 297 minecraft:red_nether_bricks
setblock 34 229 300 minecraft:nether_wart_block
setblock 35 229 291 minecraft:red_nether_bricks
fill 35 229 292 35 230 292 minecraft:orange_terracotta
setblock 35 229 294 minecraft:orange_terracotta
fill 35 229 296 37 229 296 minecraft:red_nether_bricks
setblock 35 229 297 minecraft:nether_wart_block
fill 35 229 298 35 229 300 minecraft:red_nether_bricks
setblock 35 229 301 minecraft:nether_wart_block
fill 36 229 291 36 230 291 minecraft:orange_terracotta
fill 36 229 295 36 231 295 minecraft:red_nether_bricks
fill 36 229 297 38 229 297 minecraft:red_nether_bricks
setblock 36 229 298 minecraft:nether_wart_block
setblock 36 229 301 minecraft:red_nether_bricks
setblock 37 229 292 minecraft:orange_terracotta
setblock 37 229 294 minecraft:orange_terracotta
setblock 37 229 295 minecraft:nether_wart_block
fill 37 229 298 38 229 298 minecraft:red_nether_bricks
setblock 37 229 299 minecraft:nether_wart_block
setblock 37 229 300 minecraft:red_nether_bricks
fill 38 229 293 38 229 295 minecraft:red_nether_bricks
setblock 38 229 296 minecraft:nether_wart_block
fill 42 229 280 42 250 280 minecraft:deepslate_tiles
fill 42 229 315 42 308 315 minecraft:deepslate_tiles
fill 2 230 317 2 242 317 minecraft:deepslate_tiles
fill 34 230 289 35 232 290 minecraft:orange_terracotta
setblock 34 230 291 minecraft:nether_wart_block
fill 34 230 292 34 230 294 minecraft:red_nether_bricks
setblock 34 230 295 minecraft:nether_wart_block
setblock 34 230 296 minecraft:red_nether_bricks
fill 35 230 291 35 231 291 minecraft:orange_terracotta
fill 35 230 293 36 230 293 minecraft:orange_terracotta
fill 35 230 294 35 231 294 minecraft:red_nether_bricks
setblock 35 230 296 minecraft:nether_wart_block
fill 35 230 297 35 230 299 minecraft:red_nether_bricks
setblock 36 230 289 minecraft:nether_wart_block
fill 36 230 290 36 231 290 minecraft:orange_terracotta
fill 36 230 296 38 230 296 minecraft:red_nether_bricks
setblock 36 230 297 minecraft:nether_wart_block
setblock 36 230 298 minecraft:red_nether_bricks
setblock 37 230 290 minecraft:nether_wart_block
fill 37 230 291 37 230 293 minecraft:red_nether_bricks
setblock 37 230 294 minecraft:nether_wart_block
fill 37 230 295 37 232 295 minecraft:red_nether_bricks
fill 37 230 297 38 230 297 minecraft:red_nether_bricks
setblock 37 230 298 minecraft:nether_wart_block
setblock 37 230 299 minecraft:red_nether_bricks
fill 38 230 292 38 230 294 minecraft:red_nether_bricks
setblock 38 230 295 minecraft:nether_wart_block
setblock 38 230 298 minecraft:red_nether_bricks
setblock 0 231 281 minecraft:magma_block
fill 33 231 287 33 233 287 minecraft:orange_terracotta
setblock 33 231 288 minecraft:red_nether_bricks
setblock 33 231 289 minecraft:nether_wart_block
fill 33 231 290 33 231 292 minecraft:red_nether_bricks
setblock 34 231 287 minecraft:red_nether_bricks
fill 34 231 288 35 232 288 minecraft:orange_terracotta
fill 34 231 291 34 231 293 minecraft:red_nether_bricks
setblock 34 231 294 minecraft:nether_wart_block
setblock 34 231 295 minecraft:red_nether_bricks
fill 35 231 292 35 232 293 minecraft:red_nether_bricks
setblock 35 231 295 minecraft:nether_wart_block
fill 35 231 296 35 231 297 minecraft:red_nether_bricks
setblock 36 231 288 minecraft:nether_wart_block
setblock 36 231 289 minecraft:orange_terracotta
fill 36 231 291 38 231 291 minecraft:red_nether_bricks
fill 36 231 292 36 234 292 minecraft:bone_block
fill 36 231 293 36 232 294 minecraft:red_nether_bricks
setblock 36 231 296 minecraft:nether_wart_block
setblock 36 231 297 minecraft:red_nether_bricks
setblock 37 231 289 minecraft:nether_wart_block
fill 37 231 290 37 233 290 minecraft:red_nether_bricks
fill 37 231 292 38 231 292 minecraft:red_nether_bricks
setblock 37 231 293 minecraft:nether_wart_block
fill 37 231 294 37 232 294 minecraft:red_nether_bricks
fill 37 231 296 38 231 296 minecraft:red_nether_bricks
setblock 37 231 297 minecraft:nether_wart_block
setblock 38 231 293 minecraft:red_nether_bricks
setblock 38 231 294 minecraft:nether_wart_block
setblock 38 231 295 minecraft:red_nether_bricks
fill 0 232 281 0 258 281 minecraft:deepslate_tiles
fill 0 232 291 0 308 292 minecraft:deepslate_tiles
setblock 0 232 293 minecraft:purple_concrete
fill 0 232 294 0 279 296 minecraft:deepslate_tiles
setblock 3 232 278 minecraft:light[level=12]
setblock 3 232 286 minecraft:light[level=12]
setblock 3 232 294 minecraft:light[level=12]
setblock 3 232 302 minecraft:light[level=12]
setblock 3 232 310 minecraft:light[level=12]
setblock 11 232 278 minecraft:light[level=12]
setblock 11 232 286 minecraft:light[level=12]
setblock 11 232 294 minecraft:light[level=12]
setblock 11 232 302 minecraft:light[level=12]
setblock 11 232 310 minecraft:light[level=12]
fill 18 232 275 18 308 275 minecraft:deepslate_tiles
setblock 19 232 275 minecraft:purple_concrete
setblock 19 232 278 minecraft:light[level=12]
setblock 19 232 286 minecraft:light[level=12]
setblock 19 232 294 minecraft:light[level=12]
setblock 19 232 302 minecraft:light[level=12]
setblock 19 232 310 minecraft:light[level=12]
fill 20 232 275 21 235 275 minecraft:deepslate_tiles
fill 27 232 275 27 308 275 minecraft:deepslate_tiles
setblock 27 232 278 minecraft:light[level=12]
setblock 27 232 286 minecraft:light[level=12]
setblock 27 232 294 minecraft:light[level=12]
setblock 27 232 302 minecraft:light[level=12]
setblock 27 232 310 minecraft:light[level=12]
setblock 28 232 275 minecraft:magma_block
fill 29 232 275 29 308 275 minecraft:deepslate_tiles
fill 32 232 286 32 233 287 minecraft:orange_terracotta
fill 32 232 288 32 233 289 minecraft:red_nether_bricks
fill 33 232 286 34 233 286 minecraft:orange_terracotta
fill 33 232 288 33 233 288 minecraft:orange_terracotta
fill 33 232 289 33 232 291 minecraft:red_nether_bricks
setblock 33 232 292 minecraft:nether_wart_block
fill 34 232 287 34 233 287 minecraft:orange_terracotta
fill 34 232 291 34 232 292 minecraft:red_nether_bricks
setblock 34 232 293 minecraft:nether_wart_block
setblock 34 232 294 minecraft:red_nether_bricks
setblock 35 232 278 minecraft:light[level=12]
setblock 35 232 286 minecraft:light[level=12]
fill 35 232 287 35 234 287 minecraft:red_nether_bricks
fill 35 232 291 35 234 291 minecraft:red_nether_bricks
setblock 35 232 294 minecraft:nether_wart_block
setblock 35 232 295 minecraft:red_nether_bricks
setblock 35 232 302 minecraft:light[level=12]
setblock 35 232 310 minecraft:light[level=12]
setblock 36 232 287 minecraft:nether_wart_block
fill 36 232 288 36 232 290 minecraft:red_nether_bricks
setblock 36 232 291 minecraft:nether_wart_block
setblock 36 232 295 minecraft:nether_wart_block
setblock 37 232 275 minecraft:magma_block
fill 37 232 289 37 233 289 minecraft:red_nether_bricks
setblock 37 232 291 minecraft:red_nether_bricks
setblock 37 232 292 minecraft:nether_wart_block
fill 37 232 293 37 233 293 minecraft:red_nether_bricks
setblock 38 232 292 minecraft:red_nether_bricks
setblock 38 232 293 minecraft:nether_wart_block
fill 42 232 295 42 252 298 minecraft:deepslate_tiles
setblock 42 232 299 minecraft:magma_block
fill 42 232 300 42 308 300 minecraft:deepslate_tiles
fill 0 233 293 0 308 293 minecraft:deepslate_tiles
fill 19 233 275 19 308 275 minecraft:deepslate_tiles
setblock 21 233 317 minecraft:amethyst_block
fill 28 233 275 28 308 275 minecraft:deepslate_tiles
fill 31 233 284 31 234 285 minecraft:orange_terracotta
fill 31 233 286 31 234 287 minecraft:red_nether_bricks
setblock 32 233 284 minecraft:red_nether_bricks
fill 32 233 285 33 233 285 minecraft:orange_terracotta
fill 33 233 289 34 233 290 minecraft:red_nether_bricks
setblock 33 233 291 minecraft:nether_wart_block
fill 34 233 285 34 234 285 minecraft:red_nether_bricks
setblock 34 233 288 minecraft:nether_wart_block
setblock 34 233 291 minecraft:red_nether_bricks
setblock 34 233 292 minecraft:nether_wart_block
fill 35 233 286 35 234 286 minecraft:red_nether_bricks
fill 35 233 288 36 233 288 minecraft:red_nether_bricks
setblock 35 233 289 minecraft:nether_wart_block
fill 35 233 290 35 234 290 minecraft:red_nether_bricks
setblock 35 233 292 minecraft:red_nether_bricks
setblock 35 233 293 minecraft:nether_wart_block
fill 36 233 287 36 234 287 minecraft:red_nether_bricks
setblock 36 233 289 minecraft:red_nether_bricks
setblock 36 233 290 minecraft:nether_wart_block
fill 36 233 291 36 234 291 minecraft:red_nether_bricks
setblock 36 233 293 minecraft:red_nether_bricks
setblock 36 233 294 minecraft:nether_wart_block
fill 37 233 275 37 308 275 minecraft:deepslate_tiles
setblock 37 233 291 minecraft:nether_wart_block
setblock 37 233 292 minecraft:red_nether_bricks
fill 37 233 317 37 308 317 minecraft:deepslate_tiles
setblock 38 233 275 minecraft:amethyst_block
setblock 38 233 317 minecraft:amethyst_block
fill 39 233 275 40 240 275 minecraft:deepslate_tiles
fill 42 233 299 42 251 299 minecraft:deepslate_tiles
setblock 3 234 278 minecraft:light[level=12]
setblock 3 234 285 minecraft:light[level=12]
setblock 3 234 292 minecraft:light[level=12]
setblock 3 234 299 minecraft:light[level=12]
setblock 3 234 306 minecraft:light[level=12]
setblock 3 234 313 minecraft:light[level=12]
setblock 10 234 278 minecraft:light[level=12]
setblock 10 234 285 minecraft:light[level=12]
setblock 10 234 292 minecraft:light[level=12]
setblock 10 234 299 minecraft:light[level=12]
setblock 10 234 306 minecraft:light[level=12]
setblock 10 234 313 minecraft:light[level=12]
fill 11 234 317 15 241 317 minecraft:deepslate_tiles
setblock 16 234 317 minecraft:purple_concrete
setblock 17 234 278 minecraft:light[level=12]
setblock 17 234 285 minecraft:light[level=12]
setblock 17 234 292 minecraft:light[level=12]
setblock 17 234 299 minecraft:light[level=12]
setblock 17 234 306 minecraft:light[level=12]
setblock 17 234 313 minecraft:light[level=12]
fill 17 234 317 18 251 317 minecraft:deepslate_tiles
fill 21 234 317 21 235 317 minecraft:deepslate_tiles
setblock 24 234 278 minecraft:light[level=12]
setblock 24 234 285 minecraft:light[level=12]
setblock 24 234 299 minecraft:light[level=12]
setblock 24 234 306 minecraft:light[level=12]
setblock 24 234 313 minecraft:light[level=12]
fill 29 234 283 30 234 284 minecraft:orange_terracotta
setblock 29 234 285 minecraft:red_nether_bricks
setblock 30 234 285 minecraft:orange_terracotta
setblock 30 234 286 minecraft:red_nether_bricks
setblock 31 234 278 minecraft:light[level=12]
setblock 31 234 283 minecraft:orange_terracotta
setblock 31 234 288 minecraft:nether_wart_block
setblock 31 234 292 minecraft:light[level=12]
setblock 31 234 299 minecraft:light[level=12]
setblock 31 234 306 minecraft:light[level=12]
setblock 31 234 313 minecraft:light[level=12]
setblock 32 234 283 minecraft:red_nether_bricks
fill 32 234 284 32 234 286 minecraft:orange_terracotta
fill 32 234 287 33 234 288 minecraft:red_nether_bricks
setblock 32 234 289 minecraft:nether_wart_block
fill 33 234 284 33 234 285 minecraft:red_nether_bricks
setblock 33 234 286 minecraft:orange_terracotta
fill 33 234 289 35 234 289 minecraft:red_nether_bricks
setblock 33 234 290 minecraft:nether_wart_block
setblock 34 234 286 minecraft:red_nether_bricks
setblock 34 234 287 minecraft:nether_wart_block
setblock 34 234 288 minecraft:red_nether_bricks
setblock 34 234 290 minecraft:red_nether_bricks
setblock 34 234 291 minecraft:nether_wart_block
setblock 35 234 288 minecraft:nether_wart_block
setblock 35 234 292 minecraft:nether_wart_block
setblock 36 234 288 minecraft:red_nether_bricks
setblock 36 234 289 minecraft:nether_wart_block
setblock 36 234 290 minecraft:red_nether_bricks
fill 38 234 275 38 239 275 minecraft:deepslate_tiles
setblock 38 234 278 minecraft:light[level=12]
setblock 38 234 285 minecraft:light[level=12]
setblock 38 234 292 minecraft:light[level=12]
setblock 38 234 299 minecraft:light[level=12]
setblock 38 234 306 minecraft:light[level=12]
setblock 38 234 313 minecraft:light[level=12]
fill 38 234 317 38 283 317 minecraft:deepslate_tiles
fill 1 235 276 19 235 316 minecraft:red_terracotta
fill 16 235 317 16 308 317 minecraft:deepslate_tiles
fill 20 235 276 20 235 293 minecraft:red_terracotta
fill 20 235 295 20 235 316 minecraft:red_terracotta
fill 21 235 276 22 235 291 minecraft:red_terracotta
fill 21 235 297 22 235 316 minecraft:red_terracotta
fill 23 235 276 41 235 290 minecraft:red_terracotta
fill 23 235 298 41 235 316 minecraft:red_terracotta
fill 24 235 291 41 235 291 minecraft:red_terracotta
fill 24 235 297 41 235 297 minecraft:red_terracotta
fill 26 235 292 41 235 293 minecraft:red_terracotta
fill 26 235 295 41 235 296 minecraft:red_terracotta
fill 27 235 294 41 235 294 minecraft:red_terracotta
fill 0 236 286 0 263 288 minecraft:deepslate_tiles
fill 0 236 289 0 237 289 minecraft:bone_block
fill 0 236 301 0 308 302 minecraft:deepslate_tiles
fill 0 236 303 0 237 303 minecraft:bone_block
fill 1 236 276 2 236 286 minecraft:red_terracotta
fill 1 236 287 1 236 291 minecraft:red_concrete
fill 1 236 292 1 236 300 minecraft:red_terracotta
fill 1 236 301 1 236 305 minecraft:red_concrete
fill 1 236 306 2 236 316 minecraft:red_terracotta
fill 2 236 287 12 236 287 minecraft:red_terracotta
fill 2 236 288 3 236 292 minecraft:red_concrete
fill 2 236 293 6 236 299 minecraft:red_terracotta
fill 2 236 300 3 236 304 minecraft:red_concrete
fill 2 236 305 12 236 305 minecraft:red_terracotta
fill 3 236 276 9 236 276 minecraft:red_concrete
fill 3 236 277 3 236 286 minecraft:red_terracotta
fill 3 236 306 3 236 315 minecraft:red_terracotta
fill 3 236 316 9 236 316 minecraft:red_concrete
fill 4 236 277 10 236 277 minecraft:red_concrete
fill 4 236 278 4 236 286 minecraft:red_terracotta
fill 4 236 288 13 236 288 minecraft:red_terracotta
fill 4 236 289 5 236 292 minecraft:red_concrete
fill 4 236 300 5 236 303 minecraft:red_concrete
fill 4 236 304 13 236 304 minecraft:red_terracotta
fill 4 236 306 4 236 314 minecraft:red_terracotta
fill 4 236 315 10 236 315 minecraft:red_concrete
fill 5 236 278 10 236 278 minecraft:red_concrete
fill 5 236 279 5 236 286 minecraft:red_terracotta
fill 5 236 306 5 236 313 minecraft:red_terracotta
fill 5 236 314 10 236 314 minecraft:red_concrete
fill 6 236 279 11 236 279 minecraft:red_concrete
fill 6 236 280 6 236 286 minecraft:red_terracotta
fill 6 236 289 14 236 289 minecraft:red_terracotta
fill 6 236 290 7 236 292 minecraft:red_concrete
fill 6 236 300 7 236 302 minecraft:red_concrete
fill 6 236 303 14 236 303 minecraft:red_terracotta
fill 6 236 306 6 236 312 minecraft:red_terracotta
fill 6 236 313 11 236 313 minecraft:red_concrete
fill 7 236 280 11 236 280 minecraft:red_concrete
fill 7 236 281 7 236 286 minecraft:red_terracotta
fill 7 236 293 14 236 293 minecraft:red_concrete
fill 7 236 294 11 236 298 minecraft:red_terracotta
fill 7 236 299 14 236 299 minecraft:red_concrete
fill 7 236 306 7 236 311 minecraft:red_terracotta
fill 7 236 312 11 236 312 minecraft:red_concrete
fill 8 236 281 12 236 281 minecraft:red_concrete
fill 8 236 282 8 236 286 minecraft:red_terracotta
fill 8 236 290 15 236 290 minecraft:red_terracotta
fill 8 236 291 10 236 292 minecraft:red_concrete
fill 8 236 300 10 236 301 minecraft:red_concrete
fill 8 236 302 15 236 302 minecraft:red_terracotta
fill 8 236 306 8 236 310 minecraft:red_terracotta
fill 8 236 311 12 236 311 minecraft:red_concrete
fill 9 236 282 13 236 282 minecraft:red_concrete
fill 9 236 283 9 236 286 minecraft:red_terracotta
fill 9 236 306 9 236 309 minecraft:red_terracotta
fill 9 236 310 13 236 310 minecraft:red_concrete
fill 10 236 276 18 236 276 minecraft:red_terracotta
fill 10 236 283 13 236 283 minecraft:red_concrete
fill 10 236 284 10 236 286 minecraft:red_terracotta
fill 10 236 306 10 236 308 minecraft:red_terracotta
fill 10 236 309 13 236 309 minecraft:red_concrete
fill 10 236 316 18 236 316 minecraft:red_terracotta
fill 11 236 277 18 236 278 minecraft:red_terracotta
fill 11 236 284 14 236 285 minecraft:red_concrete
setblock 11 236 286 minecraft:red_terracotta
fill 11 236 291 16 236 291 minecraft:red_terracotta
fill 11 236 292 12 236 292 minecraft:red_concrete
fill 11 236 300 12 236 300 minecraft:red_concrete
fill 11 236 301 16 236 301 minecraft:red_terracotta
setblock 11 236 306 minecraft:red_terracotta
fill 11 236 307 14 236 308 minecraft:red_concrete
fill 11 236 314 18 236 315 minecraft:red_terracotta
fill 12 236 279 19 236 280 minecraft:red_terracotta
fill 12 236 286 15 236 286 minecraft:red_concrete
fill 12 236 294 16 236 294 minecraft:red_concrete
fill 12 236 295 16 236 297 minecraft:red_terracotta
fill 12 236 298 16 236 298 minecraft:red_concrete
fill 12 236 306 15 236 306 minecraft:red_concrete
fill 12 236 312 19 236 313 minecraft:red_terracotta
fill 13 236 281 19 236 281 minecraft:red_terracotta
fill 13 236 287 15 236 287 minecraft:red_concrete
fill 13 236 292 17 236 292 minecraft:red_terracotta
fill 13 236 300 17 236 300 minecraft:red_terracotta
fill 13 236 305 15 236 305 minecraft:red_concrete
fill 13 236 311 19 236 311 minecraft:red_terracotta
fill 14 236 282 19 236 283 minecraft:red_terracotta
fill 14 236 288 16 236 288 minecraft:red_concrete
fill 14 236 304 16 236 304 minecraft:red_concrete
fill 14 236 309 19 236 310 minecraft:red_terracotta
fill 15 236 284 19 236 285 minecraft:red_terracotta
fill 15 236 289 17 236 289 minecraft:red_concrete
fill 15 236 293 18 236 293 minecraft:red_terracotta
fill 15 236 299 18 236 299 minecraft:red_terracotta
fill 15 236 303 17 236 303 minecraft:red_concrete
fill 15 236 307 19 236 308 minecraft:red_terracotta
fill 16 236 286 19 236 287 minecraft:red_terracotta
fill 16 236 290 17 236 290 minecraft:red_concrete
fill 16 236 302 17 236 302 minecraft:red_concrete
fill 16 236 305 19 236 306 minecraft:red_terracotta
fill 17 236 288 19 236 288 minecraft:red_terracotta
fill 17 236 291 18 236 291 minecraft:red_concrete
fill 17 236 294 18 236 294 minecraft:red_terracotta
fill 17 236 295 18 236 295 minecraft:red_concrete
fill 17 236 296 18 236 296 minecraft:red_terracotta
fill 17 236 297 18 236 297 minecraft:red_concrete
fill 17 236 298 18 236 298 minecraft:red_terracotta
fill 17 236 301 18 236 301 minecraft:red_concrete
fill 17 236 304 19 236 304 minecraft:red_terracotta
fill 18 236 289 19 236 290 minecraft:red_terracotta
setblock 18 236 292 minecraft:red_concrete
setblock 18 236 300 minecraft:red_concrete
fill 18 236 302 19 236 303 minecraft:red_terracotta
fill 19 236 276 23 236 278 minecraft:red_concrete
fill 19 236 291 19 236 292 minecraft:red_nether_bricks
fill 19 236 293 20 236 293 minecraft:shroomlight
fill 19 236 294 19 238 294 minecraft:quartz_block
fill 19 236 295 20 236 295 minecraft:shroomlight
fill 19 236 296 19 236 301 minecraft:red_nether_bricks
fill 19 236 314 23 236 316 minecraft:red_concrete
fill 20 236 275 20 308 275 minecraft:deepslate_tiles
fill 20 236 279 20 236 285 minecraft:red_concrete
fill 20 236 286 21 236 290 minecraft:red_nether_bricks
fill 20 236 291 20 236 292 minecraft:shroomlight
fill 20 236 296 20 236 297 minecraft:shroomlight
fill 20 236 298 21 236 306 minecraft:red_nether_bricks
fill 20 236 307 20 236 313 minecraft:red_concrete
fill 21 236 275 21 237 275 minecraft:bone_block
fill 21 236 279 22 236 283 minecraft:red_concrete
fill 21 236 284 21 237 285 minecraft:red_nether_bricks
fill 21 236 291 22 236 291 minecraft:shroomlight
fill 21 236 297 22 236 297 minecraft:shroomlight
fill 21 236 307 21 237 308 minecraft:red_nether_bricks
fill 21 236 309 22 236 313 minecraft:red_concrete
fill 21 236 317 21 237 317 minecraft:bone_block
fill 22 236 284 22 236 285 minecraft:red_concrete
fill 22 236 286 22 238 289 minecraft:red_nether_bricks
setblock 22 236 290 minecraft:shroomlight
setblock 22 236 298 minecraft:shroomlight
fill 22 236 299 22 238 306 minecraft:red_nether_bricks
fill 22 236 307 22 236 308 minecraft:red_concrete
fill 23 236 279 24 236 289 minecraft:red_terracotta
fill 23 236 290 23 238 290 minecraft:quartz_block
fill 23 236 298 23 238 298 minecraft:quartz_block
fill 23 236 299 23 237 301 minecraft:red_nether_bricks
fill 23 236 302 24 236 313 minecraft:red_terracotta
fill 24 236 276 31 236 278 minecraft:red_terracotta
fill 24 236 290 24 236 291 minecraft:shroomlight
fill 24 236 297 24 236 298 minecraft:shroomlight
fill 24 236 299 27 236 299 minecraft:red_terracotta
fill 24 236 300 24 236 301 minecraft:red_concrete
fill 24 236 314 31 236 316 minecraft:red_terracotta
fill 25 236 279 25 236 288 minecraft:red_terracotta
fill 25 236 289 26 236 290 minecraft:red_concrete
fill 25 236 291 26 236 291 minecraft:shroomlight
fill 25 236 297 26 236 297 minecraft:shroomlight
setblock 25 236 298 minecraft:red_terracotta
fill 25 236 300 29 236 300 minecraft:red_terracotta
fill 25 236 301 25 236 303 minecraft:red_concrete
fill 25 236 304 25 236 313 minecraft:red_terracotta
fill 26 236 279 26 236 287 minecraft:red_terracotta
fill 26 236 288 28 236 288 minecraft:red_concrete
fill 26 236 292 26 236 293 minecraft:shroomlight
fill 26 236 295 26 236 296 minecraft:shroomlight
fill 26 236 298 30 236 298 minecraft:red_concrete
fill 26 236 301 31 236 301 minecraft:red_terracotta
fill 26 236 302 26 236 304 minecraft:red_concrete
fill 26 236 305 26 236 313 minecraft:red_terracotta
fill 27 236 279 27 236 285 minecraft:red_terracotta
fill 27 236 286 29 236 287 minecraft:red_concrete
setblock 27 236 289 minecraft:red_concrete
fill 27 236 290 29 236 292 minecraft:red_terracotta
setblock 27 236 293 minecraft:shroomlight
fill 27 236 294 27 238 294 minecraft:quartz_block
setblock 27 236 295 minecraft:shroomlight
fill 27 236 296 41 236 297 minecraft:red_terracotta
fill 27 236 302 34 236 302 minecraft:red_terracotta
fill 27 236 303 27 236 306 minecraft:red_concrete
fill 27 236 307 27 236 313 minecraft:red_terracotta
fill 28 236 279 28 236 283 minecraft:red_terracotta
fill 28 236 284 31 236 285 minecraft:red_concrete
fill 28 236 289 36 236 289 minecraft:red_terracotta
fill 28 236 293 30 236 294 minecraft:red_concrete
fill 28 236 295 41 236 295 minecraft:red_terracotta
fill 28 236 299 35 236 299 minecraft:red_concrete
fill 28 236 303 36 236 303 minecraft:red_terracotta
fill 28 236 304 28 236 308 minecraft:red_concrete
fill 28 236 309 28 236 313 minecraft:red_terracotta
fill 29 236 279 29 236 281 minecraft:red_terracotta
fill 29 236 282 32 236 283 minecraft:red_concrete
fill 29 236 288 38 236 288 minecraft:red_terracotta
fill 29 236 304 38 236 304 minecraft:red_terracotta
fill 29 236 305 29 236 310 minecraft:red_concrete
fill 29 236 311 29 236 313 minecraft:red_terracotta
fill 30 236 279 30 236 280 minecraft:red_terracotta
fill 30 236 281 34 236 281 minecraft:red_concrete
setblock 30 236 286 minecraft:red_concrete
fill 30 236 287 40 236 287 minecraft:red_terracotta
fill 30 236 290 31 236 291 minecraft:red_terracotta
fill 30 236 292 40 236 292 minecraft:red_concrete
fill 30 236 300 40 236 300 minecraft:red_concrete
fill 30 236 305 40 236 305 minecraft:red_terracotta
fill 30 236 306 30 236 311 minecraft:red_concrete
fill 30 236 312 30 236 313 minecraft:red_terracotta
fill 31 236 279 35 236 280 minecraft:red_concrete
fill 31 236 286 41 236 286 minecraft:red_terracotta
fill 31 236 293 35 236 293 minecraft:red_concrete
fill 31 236 294 41 236 294 minecraft:red_terracotta
fill 31 236 298 41 236 298 minecraft:red_terracotta
fill 31 236 306 41 236 306 minecraft:red_terracotta
fill 31 236 307 31 236 313 minecraft:red_concrete
setblock 32 236 276 minecraft:red_terracotta
fill 32 236 277 37 236 278 minecraft:red_concrete
fill 32 236 284 41 236 285 minecraft:red_terracotta
fill 32 236 290 34 236 290 minecraft:red_terracotta
fill 32 236 291 41 236 291 minecraft:red_concrete
fill 32 236 301 41 236 301 minecraft:red_concrete
fill 32 236 307 41 236 308 minecraft:red_terracotta
fill 32 236 309 32 236 315 minecraft:red_concrete
setblock 32 236 316 minecraft:red_terracotta
fill 33 236 276 39 236 276 minecraft:red_concrete
setblock 33 236 282 minecraft:red_concrete
fill 33 236 283 41 236 283 minecraft:red_terracotta
fill 33 236 309 41 236 309 minecraft:red_terracotta
fill 33 236 310 33 236 316 minecraft:red_concrete
fill 34 236 282 41 236 282 minecraft:red_terracotta
fill 34 236 310 41 236 310 minecraft:red_terracotta
fill 34 236 311 34 236 316 minecraft:red_concrete
fill 35 236 281 41 236 281 minecraft:red_terracotta
fill 35 236 290 41 236 290 minecraft:red_concrete
fill 35 236 302 41 236 302 minecraft:red_concrete
fill 35 236 311 41 236 311 minecraft:red_terracotta
fill 35 236 312 35 236 316 minecraft:red_concrete
setblock 36 236 279 minecraft:red_concrete
fill 36 236 280 41 236 280 minecraft:red_terracotta
fill 36 236 293 41 236 293 minecraft:red_terracotta
fill 36 236 299 41 236 299 minecraft:red_terracotta
fill 36 236 312 41 236 312 minecraft:red_terracotta
fill 36 236 313 36 236 316 minecraft:red_concrete
fill 37 236 279 41 236 279 minecraft:red_terracotta
fill 37 236 289 41 236 289 minecraft:red_concrete
fill 37 236 303 41 236 303 minecraft:red_concrete
fill 37 236 313 41 236 313 minecraft:red_terracotta
fill 37 236 314 37 236 316 minecraft:red_concrete
setblock 38 236 277 minecraft:red_concrete
fill 38 236 278 41 236 278 minecraft:red_terracotta
fill 38 236 314 41 236 314 minecraft:red_terracotta
fill 38 236 315 38 236 316 minecraft:red_concrete
fill 39 236 277 41 236 277 minecraft:red_terracotta
fill 39 236 288 41 236 288 minecraft:red_concrete
fill 39 236 304 41 236 304 minecraft:red_concrete
fill 39 236 315 41 236 315 minecraft:red_terracotta
setblock 39 236 316 minecraft:red_concrete
fill 40 236 276 41 236 276 minecraft:red_terracotta
fill 40 236 316 41 236 316 minecraft:red_terracotta
setblock 41 236 287 minecraft:red_concrete
setblock 41 236 292 minecraft:red_terracotta
setblock 41 236 300 minecraft:red_terracotta
setblock 41 236 305 minecraft:red_concrete
fill 42 236 288 42 308 288 minecraft:deepslate_tiles
fill 42 236 289 42 237 289 minecraft:bone_block
fill 42 236 290 42 251 294 minecraft:deepslate_tiles
fill 42 236 301 42 281 302 minecraft:deepslate_tiles
fill 42 236 303 42 237 303 minecraft:bone_block
fill 42 236 304 42 236 310 minecraft:deepslate_tiles
fill 0 237 275 0 299 276 minecraft:deepslate_tiles
setblock 0 237 277 minecraft:magma_block
fill 0 237 278 0 285 280 minecraft:deepslate_tiles
fill 1 237 289 1 237 290 minecraft:bone_block
fill 1 237 302 1 237 303 minecraft:bone_block
fill 2 237 290 4 237 290 minecraft:bone_block
fill 2 237 302 4 237 302 minecraft:bone_block
fill 4 237 291 7 237 291 minecraft:bone_block
fill 4 237 301 7 237 301 minecraft:bone_block
fill 7 237 292 10 237 292 minecraft:bone_block
fill 7 237 300 10 237 300 minecraft:bone_block
fill 8 237 278 8 237 279 minecraft:bone_block
fill 8 237 313 8 237 314 minecraft:bone_block
fill 9 237 279 9 237 280 minecraft:bone_block
fill 9 237 312 9 237 313 minecraft:bone_block
fill 10 237 280 10 237 281 minecraft:bone_block
fill 10 237 293 13 237 293 minecraft:bone_block
fill 10 237 299 13 237 299 minecraft:bone_block
fill 10 237 311 10 237 312 minecraft:bone_block
fill 11 237 282 11 237 283 minecraft:bone_block
fill 11 237 309 11 237 310 minecraft:bone_block
fill 12 237 283 12 237 284 minecraft:bone_block
fill 12 237 308 12 237 309 minecraft:bone_block
setblock 13 237 285 minecraft:bone_block
setblock 13 237 307 minecraft:bone_block
fill 14 237 286 14 237 287 minecraft:bone_block
fill 14 237 294 16 237 294 minecraft:bone_block
fill 14 237 298 16 237 298 minecraft:bone_block
fill 14 237 305 14 237 306 minecraft:bone_block
fill 15 237 287 15 237 288 minecraft:bone_block
fill 15 237 304 15 237 305 minecraft:bone_block
fill 16 237 289 16 237 290 minecraft:bone_block
fill 16 237 302 16 237 303 minecraft:bone_block
fill 17 237 290 17 237 291 minecraft:bone_block
fill 17 237 294 18 237 294 minecraft:red_nether_bricks
setblock 17 237 295 minecraft:bone_block
fill 17 237 297 18 237 297 minecraft:bone_block
fill 17 237 301 17 237 302 minecraft:bone_block
setblock 18 237 291 minecraft:bone_block
fill 18 237 292 18 237 293 minecraft:red_nether_bricks
fill 18 237 295 18 237 296 minecraft:red_nether_bricks
fill 18 237 300 18 237 301 minecraft:bone_block
fill 19 237 288 20 237 291 minecraft:red_nether_bricks
fill 19 237 292 20 237 292 minecraft:quartz_block
fill 19 237 293 19 238 293 minecraft:red_nether_bricks
fill 19 237 295 19 238 295 minecraft:red_nether_bricks
fill 19 237 296 20 237 296 minecraft:quartz_block
fill 19 237 297 20 237 304 minecraft:red_nether_bricks
fill 20 237 284 20 237 287 minecraft:red_nether_bricks
fill 20 237 305 20 237 308 minecraft:red_nether_bricks
fill 21 237 276 21 237 281 minecraft:bone_block
fill 21 237 282 21 237 283 minecraft:red_nether_bricks
fill 21 237 286 21 238 286 minecraft:red_nether_bricks
fill 21 237 287 21 239 287 minecraft:bone_block
fill 21 237 288 21 246 288 minecraft:red_nether_bricks
setblock 21 237 289 minecraft:bone_block
fill 21 237 290 21 237 291 minecraft:quartz_block
fill 21 237 297 21 237 298 minecraft:quartz_block
setblock 21 237 299 minecraft:bone_block
fill 21 237 300 21 246 300 minecraft:red_nether_bricks
fill 21 237 301 21 239 301 minecraft:bone_block
fill 21 237 302 21 238 302 minecraft:red_nether_bricks
fill 21 237 303 21 239 303 minecraft:bone_block
fill 21 237 304 21 238 304 minecraft:red_nether_bricks
fill 21 237 305 21 239 305 minecraft:bone_block
fill 21 237 306 21 238 306 minecraft:red_nether_bricks
fill 21 237 309 21 237 310 minecraft:red_nether_bricks
fill 21 237 311 21 237 316 minecraft:bone_block
fill 22 237 284 22 237 285 minecraft:red_nether_bricks
fill 22 237 290 22 238 290 minecraft:red_nether_bricks
fill 22 237 298 22 238 298 minecraft:red_nether_bricks
fill 22 237 307 22 237 308 minecraft:red_nether_bricks
fill 23 237 281 27 237 281 minecraft:orange_terracotta
fill 23 237 288 23 237 289 minecraft:red_nether_bricks
fill 23 237 302 23 237 304 minecraft:red_nether_bricks
fill 24 237 282 28 237 282 minecraft:orange_terracotta
fill 24 237 290 24 238 290 minecraft:red_nether_bricks
fill 24 237 298 24 238 298 minecraft:red_nether_bricks
fill 24 237 300 24 237 301 minecraft:bone_block
setblock 25 237 280 minecraft:red_nether_bricks
setblock 25 237 283 minecraft:nether_wart_block
fill 25 237 290 25 237 291 minecraft:quartz_block
fill 25 237 297 25 237 298 minecraft:quartz_block
fill 25 237 301 25 237 302 minecraft:bone_block
setblock 26 237 280 minecraft:nether_wart_block
fill 26 237 283 28 237 283 minecraft:orange_terracotta
setblock 26 237 284 minecraft:nether_wart_block
setblock 26 237 289 minecraft:bone_block
fill 26 237 290 26 237 291 minecraft:red_nether_bricks
fill 26 237 292 27 237 292 minecraft:quartz_block
fill 26 237 296 27 237 296 minecraft:quartz_block
fill 26 237 297 26 237 298 minecraft:red_nether_bricks
fill 26 237 302 26 237 303 minecraft:bone_block
fill 27 237 280 28 237 280 minecraft:red_nether_bricks
fill 27 237 284 29 237 284 minecraft:red_nether_bricks
fill 27 237 287 27 237 288 minecraft:bone_block
setblock 27 237 291 minecraft:red_nether_bricks
fill 27 237 293 28 238 293 minecraft:red_nether_bricks
fill 27 237 295 28 238 295 minecraft:red_nether_bricks
setblock 27 237 297 minecraft:red_nether_bricks
fill 27 237 298 28 237 298 minecraft:bone_block
fill 27 237 304 27 237 305 minecraft:bone_block
fill 28 237 281 30 237 281 minecraft:red_nether_bricks
setblock 28 237 285 minecraft:red_nether_bricks
fill 28 237 286 28 237 287 minecraft:bone_block
fill 28 237 292 28 243 292 minecraft:red_nether_bricks
fill 28 237 294 29 237 294 minecraft:red_nether_bricks
fill 28 237 296 28 243 296 minecraft:red_nether_bricks
fill 28 237 305 28 237 306 minecraft:bone_block
fill 29 237 282 30 237 282 minecraft:red_nether_bricks
setblock 29 237 283 minecraft:nether_wart_block
setblock 29 237 285 minecraft:bone_block
fill 29 237 286 31 237 286 minecraft:red_nether_bricks
fill 29 237 293 32 237 293 minecraft:bone_block
fill 29 237 299 32 237 299 minecraft:bone_block
setblock 29 237 307 minecraft:bone_block
fill 30 237 283 30 237 284 minecraft:bone_block
fill 30 237 285 30 238 285 minecraft:red_nether_bricks
fill 30 237 308 30 237 309 minecraft:bone_block
fill 31 237 282 31 237 283 minecraft:bone_block
fill 31 237 284 33 237 284 minecraft:red_nether_bricks
setblock 31 237 285 minecraft:nether_wart_block
fill 31 237 309 31 237 310 minecraft:bone_block
fill 32 237 280 32 237 281 minecraft:bone_block
setblock 32 237 283 minecraft:red_nether_bricks
fill 32 237 285 33 237 285 minecraft:red_nether_bricks
fill 32 237 286 33 238 286 minecraft:bone_block
setblock 32 237 287 minecraft:red_nether_bricks
fill 32 237 292 35 237 292 minecraft:bone_block
fill 32 237 300 35 237 300 minecraft:bone_block
fill 32 237 311 32 237 312 minecraft:bone_block
fill 33 237 279 33 237 280 minecraft:bone_block
fill 33 237 312 33 237 313 minecraft:bone_block
fill 34 237 278 34 237 279 minecraft:bone_block
fill 34 237 313 34 237 314 minecraft:bone_block
fill 35 237 291 38 237 291 minecraft:bone_block
fill 35 237 301 38 237 301 minecraft:bone_block
fill 38 237 290 41 237 290 minecraft:bone_block
fill 38 237 302 41 237 302 minecraft:bone_block
setblock 41 237 289 minecraft:bone_block
setblock 41 237 303 minecraft:bone_block
setblock 42 237 304 minecraft:amethyst_block
fill 42 237 305 42 262 310 minecraft:deepslate_tiles
fill 0 238 277 0 251 277 minecraft:deepslate_tiles
fill 0 238 289 0 255 289 minecraft:deepslate_tiles
fill 0 238 303 0 306 303 minecraft:deepslate_tiles
fill 12 238 293 17 244 295 minecraft:nether_bricks
fill 13 238 292 17 244 292 minecraft:nether_bricks
fill 13 238 296 17 244 296 minecraft:nether_bricks
setblock 17 238 275 minecraft:purple_concrete
fill 17 238 291 18 238 291 minecraft:red_nether_bricks
fill 17 238 297 18 238 297 minecraft:red_nether_bricks
fill 18 238 290 19 244 290 minecraft:red_nether_bricks
setblock 18 238 292 minecraft:red_nether_bricks
fill 18 238 293 18 242 293 minecraft:nether_bricks
setblock 18 238 294 minecraft:quartz_block
fill 18 238 295 18 242 295 minecraft:nether_bricks
setblock 18 238 296 minecraft:red_nether_bricks
fill 18 238 298 19 244 298 minecraft:red_nether_bricks
fill 19 238 289 21 243 289 minecraft:red_nether_bricks
fill 19 238 291 19 238 292 minecraft:quartz_block
fill 19 238 296 19 238 297 minecraft:quartz_block
fill 19 238 299 20 238 301 minecraft:red_nether_bricks
fill 20 238 286 20 238 288 minecraft:red_nether_bricks
fill 20 238 290 21 238 290 minecraft:quartz_block
fill 20 238 291 20 239 291 minecraft:red_nether_bricks
fill 20 238 297 20 239 297 minecraft:red_nether_bricks
fill 20 238 298 21 238 298 minecraft:quartz_block
fill 20 238 302 20 238 306 minecraft:red_nether_bricks
fill 21 238 275 21 308 275 minecraft:deepslate_tiles
setblock 21 238 283 minecraft:bone_block
setblock 21 238 284 minecraft:red_nether_bricks
setblock 21 238 285 minecraft:bone_block
fill 21 238 299 21 243 299 minecraft:red_nether_bricks
setblock 21 238 307 minecraft:bone_block
setblock 21 238 308 minecraft:red_nether_bricks
setblock 21 238 309 minecraft:bone_block
fill 21 238 317 21 246 317 minecraft:deepslate_tiles
fill 22 238 280 22 238 282 minecraft:red_nether_bricks
fill 23 238 280 25 238 282 minecraft:orange_terracotta
fill 23 238 288 24 245 288 minecraft:red_nether_bricks
setblock 23 238 289 minecraft:quartz_block
setblock 23 238 299 minecraft:quartz_block
fill 23 238 300 23 238 301 minecraft:red_nether_bricks
fill 24 238 283 25 239 283 minecraft:red_nether_bricks
fill 24 238 289 27 242 289 minecraft:red_nether_bricks
fill 24 238 299 24 242 300 minecraft:red_nether_bricks
fill 25 238 279 25 240 279 minecraft:red_nether_bricks
fill 25 238 290 26 238 290 minecraft:quartz_block
fill 25 238 298 26 238 298 minecraft:quartz_block
fill 25 238 299 27 243 299 minecraft:red_nether_bricks
fill 26 238 280 26 238 282 minecraft:red_nether_bricks
setblock 26 238 283 minecraft:nether_wart_block
fill 26 238 284 26 239 284 minecraft:red_nether_bricks
fill 26 238 291 26 239 291 minecraft:red_nether_bricks
fill 26 238 297 26 239 297 minecraft:red_nether_bricks
setblock 27 238 280 minecraft:nether_wart_block
fill 27 238 281 27 240 281 minecraft:red_nether_bricks
fill 27 238 282 27 242 282 minecraft:bone_block
fill 27 238 283 29 238 283 minecraft:red_nether_bricks
setblock 27 238 284 minecraft:nether_wart_block
fill 27 238 290 28 244 290 minecraft:red_nether_bricks
fill 27 238 291 27 238 292 minecraft:quartz_block
fill 27 238 296 27 238 297 minecraft:quartz_block
fill 27 238 298 28 244 298 minecraft:red_nether_bricks
setblock 28 238 280 minecraft:red_nether_bricks
setblock 28 238 281 minecraft:nether_wart_block
fill 28 238 282 28 240 282 minecraft:red_nether_bricks
fill 28 238 284 30 238 284 minecraft:red_nether_bricks
setblock 28 238 285 minecraft:nether_wart_block
fill 28 238 291 29 244 291 minecraft:red_nether_bricks
setblock 28 238 294 minecraft:quartz_block
fill 28 238 297 29 244 297 minecraft:red_nether_bricks
fill 29 238 281 30 238 281 minecraft:red_nether_bricks
setblock 29 238 282 minecraft:nether_wart_block
setblock 29 238 285 minecraft:red_nether_bricks
fill 29 238 292 30 245 296 minecraft:red_nether_bricks
fill 30 238 282 31 238 282 minecraft:red_nether_bricks
setblock 30 238 283 minecraft:nether_wart_block
setblock 31 238 283 minecraft:red_nether_bricks
setblock 31 238 284 minecraft:nether_wart_block
setblock 31 238 285 minecraft:red_nether_bricks
setblock 32 238 284 minecraft:red_nether_bricks
fill 42 238 289 42 308 289 minecraft:deepslate_tiles
fill 42 238 303 42 299 304 minecraft:deepslate_tiles
fill 3 239 278 3 240 278 minecraft:light[level=12]
setblock 3 239 286 minecraft:light[level=12]
setblock 3 239 294 minecraft:light[level=12]
setblock 3 239 302 minecraft:light[level=12]
setblock 3 239 310 minecraft:light[level=12]
fill 10 239 294 11 243 294 minecraft:nether_bricks
setblock 11 239 278 minecraft:light[level=12]
setblock 11 239 286 minecraft:light[level=12]
fill 11 239 292 11 241 293 minecraft:nether_bricks
fill 11 239 295 11 241 296 minecraft:nether_bricks
setblock 11 239 302 minecraft:light[level=12]
setblock 11 239 310 minecraft:light[level=12]
fill 12 239 291 12 243 292 minecraft:nether_bricks
fill 12 239 296 12 243 297 minecraft:nether_bricks
fill 13 239 291 18 243 291 minecraft:nether_bricks
fill 13 239 297 18 243 297 minecraft:nether_bricks
fill 17 239 275 17 282 275 minecraft:deepslate_tiles
setblock 17 239 290 minecraft:red_nether_bricks
setblock 17 239 298 minecraft:red_nether_bricks
fill 18 239 289 18 247 289 minecraft:red_nether_bricks
fill 18 239 292 19 240 292 minecraft:nether_bricks
fill 18 239 294 18 241 294 minecraft:nether_bricks
fill 18 239 296 19 240 296 minecraft:nether_bricks
fill 18 239 299 20 244 299 minecraft:red_nether_bricks
setblock 19 239 278 minecraft:light[level=12]
setblock 19 239 286 minecraft:light[level=12]
fill 19 239 288 20 246 288 minecraft:red_nether_bricks
setblock 19 239 291 minecraft:red_nether_bricks
setblock 19 239 297 minecraft:red_nether_bricks
fill 19 239 300 20 246 300 minecraft:red_nether_bricks
setblock 19 239 302 minecraft:light[level=12]
setblock 19 239 310 minecraft:light[level=12]
fill 20 239 280 24 239 281 minecraft:orange_terracotta
fill 20 239 290 21 240 290 minecraft:red_nether_bricks
fill 20 239 298 21 240 298 minecraft:red_nether_bricks
fill 21 239 282 21 240 282 minecraft:orange_terracotta
fill 22 239 279 22 241 279 minecraft:red_nether_bricks
setblock 22 239 282 minecraft:nether_wart_block
fill 22 239 283 22 241 283 minecraft:red_nether_bricks
fill 22 239 288 22 242 289 minecraft:red_nether_bricks
fill 22 239 299 23 241 300 minecraft:red_nether_bricks
setblock 23 239 279 minecraft:nether_wart_block
fill 23 239 282 24 239 282 minecraft:orange_terracotta
setblock 23 239 283 minecraft:nether_wart_block
fill 23 239 289 23 241 289 minecraft:red_nether_bricks
setblock 24 239 279 minecraft:red_nether_bricks
fill 25 239 280 27 239 280 minecraft:red_nether_bricks
setblock 25 239 281 minecraft:orange_terracotta
fill 25 239 282 25 241 282 minecraft:red_nether_bricks
setblock 25 239 284 minecraft:red_nether_bricks
fill 25 239 288 27 246 288 minecraft:red_nether_bricks
fill 25 239 290 26 240 290 minecraft:red_nether_bricks
fill 25 239 298 26 240 298 minecraft:red_nether_bricks
fill 25 239 300 27 246 300 minecraft:red_nether_bricks
setblock 26 239 279 minecraft:red_nether_bricks
setblock 26 239 281 minecraft:red_nether_bricks
setblock 26 239 282 minecraft:nether_wart_block
fill 26 239 283 26 240 283 minecraft:red_nether_bricks
setblock 27 239 278 minecraft:light[level=12]
setblock 27 239 283 minecraft:nether_wart_block
setblock 27 239 284 minecraft:red_nether_bricks
setblock 27 239 286 minecraft:light[level=12]
fill 27 239 291 27 240 292 minecraft:red_nether_bricks
fill 27 239 296 27 240 297 minecraft:red_nether_bricks
setblock 27 239 302 minecraft:light[level=12]
setblock 27 239 310 minecraft:light[level=12]
setblock 28 239 280 minecraft:nether_wart_block
fill 28 239 281 28 240 281 minecraft:red_nether_bricks
fill 28 239 283 30 239 283 minecraft:red_nether_bricks
setblock 28 239 284 minecraft:nether_wart_block
fill 28 239 289 28 247 289 minecraft:red_nether_bricks
fill 28 239 293 28 241 295 minecraft:red_nether_bricks
fill 28 239 299 28 247 299 minecraft:red_nether_bricks
setblock 29 239 281 minecraft:nether_wart_block
setblock 29 239 282 minecraft:red_nether_bricks
fill 29 239 284 30 239 284 minecraft:red_nether_bricks
fill 29 239 290 29 247 290 minecraft:red_nether_bricks
fill 29 239 298 29 247 298 minecraft:red_nether_bricks
setblock 30 239 282 minecraft:nether_wart_block
fill 30 239 291 30 247 291 minecraft:red_nether_bricks
fill 30 239 297 30 247 297 minecraft:red_nether_bricks
fill 31 239 292 31 246 296 minecraft:red_nether_bricks
setblock 35 239 278 minecraft:light[level=12]
setblock 35 239 286 minecraft:light[level=12]
setblock 35 239 294 minecraft:light[level=12]
setblock 35 239 302 minecraft:light[level=12]
setblock 35 239 310 minecraft:light[level=12]
fill 39 239 317 39 308 317 minecraft:deepslate_tiles
setblock 40 239 317 minecraft:magma_block
fill 0 240 298 0 308 298 minecraft:deepslate_tiles
setblock 0 240 299 minecraft:magma_block
fill 0 240 300 0 262 300 minecraft:deepslate_tiles
setblock 3 240 285 minecraft:light[level=12]
setblock 3 240 292 minecraft:light[level=12]
setblock 3 240 299 minecraft:light[level=12]
setblock 3 240 306 minecraft:light[level=12]
setblock 3 240 313 minecraft:light[level=12]
setblock 10 240 278 minecraft:light[level=12]
setblock 10 240 285 minecraft:light[level=12]
fill 10 240 292 10 242 293 minecraft:nether_bricks
fill 10 240 295 10 242 296 minecraft:nether_bricks
setblock 10 240 299 minecraft:light[level=12]
setblock 10 240 306 minecraft:light[level=12]
setblock 10 240 313 minecraft:light[level=12]
fill 11 240 291 11 242 291 minecraft:nether_bricks
fill 11 240 297 11 242 297 minecraft:nether_bricks
fill 13 240 290 17 242 290 minecraft:nether_bricks
fill 13 240 298 17 242 298 minecraft:nether_bricks
fill 15 240 303 16 241 304 minecraft:raw_gold_block
setblock 17 240 278 minecraft:light[level=12]
setblock 17 240 285 minecraft:light[level=12]
fill 17 240 289 17 246 289 minecraft:red_nether_bricks
fill 17 240 299 17 246 299 minecraft:red_nether_bricks
setblock 17 240 306 minecraft:light[level=12]
setblock 17 240 313 minecraft:light[level=12]
setblock 18 240 280 minecraft:red_nether_bricks
setblock 18 240 281 minecraft:nether_wart_block
fill 18 240 288 18 245 288 minecraft:red_nether_bricks
fill 18 240 300 18 245 300 minecraft:red_nether_bricks
fill 19 240 280 22 240 281 minecraft:orange_terracotta
setblock 19 240 282 minecraft:nether_wart_block
fill 19 240 291 19 241 291 minecraft:nether_bricks
fill 19 240 297 19 241 297 minecraft:nether_bricks
setblock 20 240 279 minecraft:nether_wart_block
setblock 20 240 282 minecraft:orange_terracotta
fill 20 240 287 26 244 287 minecraft:red_nether_bricks
fill 20 240 301 26 244 301 minecraft:red_nether_bricks
setblock 21 240 279 minecraft:red_nether_bricks
setblock 21 240 283 minecraft:red_nether_bricks
fill 22 240 282 22 242 282 minecraft:red_nether_bricks
fill 23 240 279 23 240 281 minecraft:red_nether_bricks
setblock 23 240 282 minecraft:nether_wart_block
fill 23 240 283 23 241 283 minecraft:red_nether_bricks
setblock 24 240 278 minecraft:light[level=12]
setblock 24 240 279 minecraft:nether_wart_block
fill 24 240 280 24 240 282 minecraft:red_nether_bricks
setblock 24 240 283 minecraft:nether_wart_block
setblock 24 240 285 minecraft:light[level=12]
setblock 24 240 306 minecraft:light[level=12]
setblock 24 240 313 minecraft:light[level=12]
setblock 25 240 280 minecraft:nether_wart_block
fill 25 240 281 25 242 281 minecraft:red_nether_bricks
setblock 25 240 283 minecraft:red_nether_bricks
fill 26 240 280 27 240 280 minecraft:red_nether_bricks
setblock 26 240 281 minecraft:nether_wart_block
fill 26 240 282 26 241 282 minecraft:red_nether_bricks
setblock 27 240 283 minecraft:red_nether_bricks
setblock 28 240 283 minecraft:nether_wart_block
fill 28 240 288 28 245 288 minecraft:red_nether_bricks
fill 28 240 300 28 245 300 minecraft:red_nether_bricks
fill 29 240 289 29 246 289 minecraft:red_nether_bricks
fill 29 240 299 29 246 299 minecraft:red_nether_bricks
fill 30 240 290 30 246 290 minecraft:red_nether_bricks
fill 30 240 298 30 246 298 minecraft:red_nether_bricks
setblock 31 240 278 minecraft:light[level=12]
setblock 31 240 285 minecraft:light[level=12]
fill 31 240 291 31 246 291 minecraft:red_nether_bricks
fill 31 240 297 31 246 297 minecraft:red_nether_bricks
setblock 31 240 299 minecraft:light[level=12]
setblock 31 240 306 minecraft:light[level=12]
setblock 31 240 313 minecraft:light[level=12]
fill 32 240 293 32 245 295 minecraft:red_nether_bricks
fill 37 240 276 39 241 276 minecraft:amethyst_block
setblock 38 240 275 minecraft:amethyst_block
fill 38 240 277 38 241 277 minecraft:amethyst_block
setblock 38 240 278 minecraft:light[level=12]
setblock 38 240 285 minecraft:light[level=12]
setblock 38 240 292 minecraft:light[level=12]
setblock 38 240 299 minecraft:light[level=12]
setblock 38 240 306 minecraft:light[level=12]
setblock 38 240 313 minecraft:light[level=12]
fill 40 240 317 40 284 317 minecraft:deepslate_tiles
fill 0 241 299 0 254 299 minecraft:deepslate_tiles
fill 16 241 281 18 242 282 minecraft:orange_terracotta
fill 16 241 289 16 245 289 minecraft:red_nether_bricks
fill 16 241 299 16 245 299 minecraft:red_nether_bricks
fill 17 241 280 18 241 280 minecraft:orange_terracotta
fill 17 241 288 17 244 288 minecraft:red_nether_bricks
fill 17 241 300 17 244 300 minecraft:red_nether_bricks
fill 18 241 279 20 241 279 minecraft:red_nether_bricks
fill 18 241 283 20 241 283 minecraft:red_nether_bricks
fill 18 241 292 18 243 292 minecraft:nether_bricks
fill 18 241 296 18 243 296 minecraft:nether_bricks
setblock 19 241 280 minecraft:red_nether_bricks
fill 19 241 281 21 241 281 minecraft:orange_terracotta
fill 19 241 282 19 243 282 minecraft:red_nether_bricks
fill 19 241 287 19 244 287 minecraft:red_nether_bricks
fill 19 241 301 19 244 301 minecraft:red_nether_bricks
setblock 20 241 280 minecraft:orange_terracotta
setblock 20 241 282 minecraft:nether_wart_block
setblock 20 241 290 minecraft:red_nether_bricks
setblock 20 241 298 minecraft:red_nether_bricks
setblock 21 241 279 minecraft:nether_wart_block
fill 21 241 280 21 243 280 minecraft:red_nether_bricks
setblock 21 241 282 minecraft:red_nether_bricks
setblock 21 241 283 minecraft:nether_wart_block
setblock 22 241 280 minecraft:nether_wart_block
fill 22 241 281 22 243 281 minecraft:red_nether_bricks
fill 23 241 279 24 241 280 minecraft:red_nether_bricks
setblock 23 241 281 minecraft:nether_wart_block
fill 23 241 282 23 242 282 minecraft:red_nether_bricks
setblock 24 241 281 minecraft:red_nether_bricks
setblock 24 241 282 minecraft:nether_wart_block
setblock 24 241 283 minecraft:red_nether_bricks
setblock 25 241 280 minecraft:red_nether_bricks
setblock 25 241 283 minecraft:nether_wart_block
setblock 26 241 280 minecraft:nether_wart_block
setblock 26 241 281 minecraft:red_nether_bricks
setblock 26 241 290 minecraft:red_nether_bricks
setblock 26 241 298 minecraft:red_nether_bricks
fill 27 241 287 27 244 287 minecraft:red_nether_bricks
setblock 27 241 291 minecraft:red_nether_bricks
setblock 27 241 297 minecraft:red_nether_bricks
fill 27 241 301 27 244 301 minecraft:red_nether_bricks
fill 29 241 288 29 244 288 minecraft:red_nether_bricks
fill 29 241 300 29 244 300 minecraft:red_nether_bricks
fill 30 241 289 30 245 289 minecraft:red_nether_bricks
fill 30 241 299 30 245 299 minecraft:red_nether_bricks
fill 31 241 290 31 245 290 minecraft:red_nether_bricks
fill 31 241 298 31 245 298 minecraft:red_nether_bricks
fill 32 241 292 32 245 292 minecraft:red_nether_bricks
fill 32 241 296 32 245 296 minecraft:red_nether_bricks
setblock 37 241 277 minecraft:amethyst_block
fill 38 241 275 38 308 275 minecraft:deepslate_tiles
setblock 39 241 275 minecraft:amethyst_block
fill 40 241 275 40 308 275 minecraft:deepslate_tiles
setblock 0 242 307 minecraft:amethyst_block
fill 11 242 292 11 243 292 minecraft:black_concrete
fill 11 242 293 11 243 293 minecraft:nether_bricks
fill 11 242 295 11 243 295 minecraft:nether_bricks
fill 11 242 296 11 243 296 minecraft:black_concrete
fill 11 242 317 12 308 317 minecraft:deepslate_tiles
fill 12 242 316 14 243 316 minecraft:amethyst_block
setblock 13 242 315 minecraft:amethyst_block
fill 13 242 317 13 243 317 minecraft:amethyst_block
fill 14 242 282 14 244 283 minecraft:orange_terracotta
fill 14 242 317 15 308 317 minecraft:deepslate_tiles
setblock 15 242 280 minecraft:nether_wart_block
fill 15 242 281 15 244 281 minecraft:red_nether_bricks
fill 15 242 282 15 244 282 minecraft:orange_terracotta
fill 15 242 283 17 242 283 minecraft:red_nether_bricks
setblock 16 242 280 minecraft:red_nether_bricks
fill 17 242 279 17 244 279 minecraft:red_nether_bricks
setblock 17 242 280 minecraft:orange_terracotta
setblock 18 242 279 minecraft:nether_wart_block
fill 18 242 280 18 244 280 minecraft:red_nether_bricks
setblock 18 242 283 minecraft:nether_wart_block
fill 19 242 279 21 242 279 minecraft:red_nether_bricks
setblock 19 242 280 minecraft:nether_wart_block
fill 19 242 281 19 244 281 minecraft:red_nether_bricks
fill 19 242 283 21 242 283 minecraft:red_nether_bricks
setblock 20 242 280 minecraft:red_nether_bricks
fill 20 242 281 20 245 281 minecraft:bone_block
fill 20 242 282 20 244 282 minecraft:red_nether_bricks
setblock 21 242 281 minecraft:red_nether_bricks
setblock 21 242 282 minecraft:nether_wart_block
setblock 22 242 279 minecraft:nether_wart_block
fill 22 242 280 22 243 280 minecraft:red_nether_bricks
setblock 22 242 283 minecraft:nether_wart_block
fill 22 242 299 22 242 300 minecraft:red_nether_bricks
fill 22 242 317 25 248 317 minecraft:deepslate_tiles
setblock 23 242 279 minecraft:red_nether_bricks
setblock 23 242 280 minecraft:nether_wart_block
fill 23 242 281 23 243 281 minecraft:red_nether_bricks
fill 23 242 300 23 245 300 minecraft:red_nether_bricks
setblock 24 242 280 minecraft:red_nether_bricks
setblock 24 242 281 minecraft:nether_wart_block
setblock 24 242 282 minecraft:red_nether_bricks
setblock 26 242 317 minecraft:magma_block
fill 27 242 317 27 308 317 minecraft:deepslate_tiles
setblock 28 242 293 minecraft:red_nether_bricks
setblock 28 242 295 minecraft:red_nether_bricks
fill 32 242 291 32 244 291 minecraft:red_nether_bricks
fill 32 242 297 32 244 297 minecraft:red_nether_bricks
fill 34 242 289 35 243 290 minecraft:raw_gold_block
fill 34 242 299 34 243 301 minecraft:gold_block
fill 35 242 300 35 243 300 minecraft:gold_block
fill 39 242 275 39 308 275 minecraft:deepslate_tiles
fill 0 243 307 0 308 307 minecraft:deepslate_tiles
setblock 2 243 317 minecraft:purple_concrete
setblock 10 243 293 minecraft:nether_bricks
setblock 10 243 295 minecraft:nether_bricks
setblock 13 243 281 minecraft:nether_wart_block
fill 13 243 282 13 244 284 minecraft:orange_terracotta
fill 14 243 280 14 243 281 minecraft:red_nether_bricks
fill 14 243 284 15 243 284 minecraft:red_nether_bricks
fill 15 243 280 15 245 280 minecraft:red_nether_bricks
fill 15 243 283 15 244 283 minecraft:orange_terracotta
fill 15 243 290 17 245 290 minecraft:red_nether_bricks
fill 15 243 298 17 245 298 minecraft:red_nether_bricks
setblock 16 243 279 minecraft:red_nether_bricks
setblock 16 243 280 minecraft:nether_wart_block
fill 16 243 281 17 243 282 minecraft:orange_terracotta
fill 16 243 283 18 243 283 minecraft:red_nether_bricks
setblock 16 243 284 minecraft:nether_wart_block
setblock 17 243 280 minecraft:red_nether_bricks
fill 18 243 279 18 244 279 minecraft:red_nether_bricks
setblock 18 243 281 minecraft:red_nether_bricks
setblock 18 243 282 minecraft:nether_wart_block
setblock 19 243 279 minecraft:nether_wart_block
fill 19 243 280 19 244 280 minecraft:red_nether_bricks
setblock 19 243 283 minecraft:nether_wart_block
fill 20 243 279 21 243 279 minecraft:red_nether_bricks
setblock 20 243 280 minecraft:nether_wart_block
setblock 20 243 283 minecraft:red_nether_bricks
setblock 21 243 281 minecraft:nether_wart_block
setblock 21 243 282 minecraft:red_nether_bricks
setblock 22 243 282 minecraft:nether_wart_block
fill 22 243 288 22 245 288 minecraft:red_nether_bricks
fill 22 243 300 22 245 300 minecraft:red_nether_bricks
fill 24 243 300 24 245 300 minecraft:red_nether_bricks
fill 25 243 289 27 243 289 minecraft:red_nether_bricks
fill 26 243 317 26 304 317 minecraft:deepslate_tiles
fill 0 244 315 0 268 315 minecraft:deepslate_tiles
setblock 0 244 316 minecraft:crying_obsidian
fill 2 244 317 2 308 317 minecraft:deepslate_tiles
setblock 11 244 283 minecraft:red_nether_bricks
fill 11 244 284 12 245 285 minecraft:orange_terracotta
setblock 11 244 294 minecraft:nether_bricks
setblock 12 244 282 minecraft:red_nether_bricks
setblock 12 244 283 minecraft:orange_terracotta
setblock 12 244 292 minecraft:nether_bricks
setblock 12 244 296 minecraft:nether_bricks
fill 13 244 281 13 246 281 minecraft:red_nether_bricks
fill 13 244 285 13 246 285 minecraft:red_nether_bricks
fill 13 244 317 13 308 317 minecraft:deepslate_tiles
setblock 14 244 280 minecraft:red_nether_bricks
setblock 14 244 281 minecraft:nether_wart_block
setblock 14 244 284 minecraft:orange_terracotta
setblock 14 244 285 minecraft:nether_wart_block
fill 14 244 291 16 244 291 minecraft:nether_bricks
fill 14 244 297 16 244 297 minecraft:nether_bricks
fill 15 244 284 16 245 284 minecraft:red_nether_bricks
setblock 16 244 279 minecraft:nether_wart_block
fill 16 244 280 16 244 282 minecraft:red_nether_bricks
setblock 16 244 283 minecraft:nether_wart_block
setblock 17 244 280 minecraft:nether_wart_block
fill 17 244 281 17 244 283 minecraft:red_nether_bricks
setblock 17 244 284 minecraft:nether_wart_block
fill 17 244 291 18 244 291 minecraft:red_nether_bricks
fill 17 244 297 18 244 297 minecraft:red_nether_bricks
setblock 18 244 281 minecraft:nether_wart_block
fill 18 244 282 18 244 283 minecraft:red_nether_bricks
setblock 19 244 279 minecraft:red_nether_bricks
setblock 19 244 282 minecraft:nether_wart_block
setblock 19 244 283 minecraft:red_nether_bricks
fill 19 244 289 20 244 289 minecraft:red_nether_bricks
setblock 20 244 280 minecraft:red_nether_bricks
setblock 21 244 281 minecraft:red_nether_bricks
fill 26 244 289 27 244 289 minecraft:red_nether_bricks
fill 26 244 299 27 244 299 minecraft:red_nether_bricks
fill 0 245 316 0 308 316 minecraft:deepslate_tiles
fill 9 245 285 9 246 285 minecraft:red_nether_bricks
setblock 10 245 283 minecraft:red_nether_bricks
fill 10 245 284 10 246 286 minecraft:orange_terracotta
fill 11 245 282 11 247 282 minecraft:red_nether_bricks
setblock 11 245 283 minecraft:orange_terracotta
fill 11 245 286 11 246 286 minecraft:orange_terracotta
setblock 12 245 281 minecraft:red_nether_bricks
setblock 12 245 282 minecraft:nether_wart_block
fill 12 245 283 12 247 283 minecraft:red_nether_bricks
setblock 12 245 286 minecraft:nether_wart_block
fill 13 245 282 15 245 282 minecraft:red_nether_bricks
setblock 13 245 283 minecraft:orange_terracotta
fill 13 245 284 13 247 284 minecraft:red_nether_bricks
setblock 14 245 280 minecraft:nether_wart_block
fill 14 245 281 14 246 281 minecraft:red_nether_bricks
fill 14 245 283 16 245 283 minecraft:red_nether_bricks
setblock 14 245 284 minecraft:nether_wart_block
fill 14 245 285 14 247 285 minecraft:red_nether_bricks
fill 14 245 292 17 245 293 minecraft:red_nether_bricks
fill 14 245 294 16 245 294 minecraft:nether_bricks
fill 14 245 295 17 245 296 minecraft:red_nether_bricks
setblock 15 245 281 minecraft:nether_wart_block
fill 15 245 291 17 246 291 minecraft:red_nether_bricks
fill 15 245 297 17 246 297 minecraft:red_nether_bricks
fill 16 245 280 17 245 281 minecraft:red_nether_bricks
setblock 16 245 282 minecraft:nether_wart_block
fill 17 245 282 18 245 282 minecraft:red_nether_bricks
setblock 17 245 283 minecraft:nether_wart_block
setblock 17 245 294 minecraft:red_nether_bricks
setblock 18 245 280 minecraft:nether_wart_block
setblock 18 245 281 minecraft:red_nether_bricks
fill 18 245 290 18 246 290 minecraft:red_nether_bricks
schedule function dropper:buildpart/60_5 1t
