setblock 333 202 417 minecraft:red_concrete
setblock 336 202 457 minecraft:red_concrete
setblock 340 202 417 minecraft:red_concrete
setblock 343 202 457 minecraft:red_concrete
setblock 347 202 417 minecraft:red_concrete
setblock 350 202 457 minecraft:red_concrete
setblock 354 202 417 minecraft:red_concrete
setblock 357 202 457 minecraft:red_concrete
setblock 361 202 417 minecraft:red_concrete
setblock 364 202 457 minecraft:red_concrete
setblock 368 202 417 minecraft:red_concrete
setblock 370 202 422 minecraft:red_concrete
setblock 370 202 429 minecraft:red_concrete
setblock 370 202 436 minecraft:red_concrete
setblock 370 202 443 minecraft:red_concrete
setblock 370 202 450 minecraft:red_concrete
setblock 330 204 423 minecraft:red_concrete
setblock 330 204 430 minecraft:red_concrete
setblock 330 204 437 minecraft:red_concrete
setblock 330 204 444 minecraft:red_concrete
setblock 330 204 451 minecraft:red_concrete
setblock 331 204 417 minecraft:red_concrete
setblock 331 204 457 minecraft:red_concrete
setblock 338 204 417 minecraft:red_concrete
setblock 338 204 457 minecraft:red_concrete
setblock 345 204 417 minecraft:red_concrete
setblock 345 204 457 minecraft:red_concrete
setblock 352 204 417 minecraft:red_concrete
setblock 352 204 457 minecraft:red_concrete
setblock 359 204 417 minecraft:red_concrete
setblock 359 204 457 minecraft:red_concrete
setblock 366 204 417 minecraft:red_concrete
setblock 366 204 457 minecraft:red_concrete
setblock 370 204 420 minecraft:red_concrete
setblock 370 204 427 minecraft:red_concrete
setblock 370 204 434 minecraft:red_concrete
setblock 370 204 441 minecraft:red_concrete
setblock 370 204 448 minecraft:red_concrete
setblock 370 204 455 minecraft:red_concrete
setblock 330 205 417 minecraft:red_concrete
setblock 330 205 424 minecraft:red_concrete
setblock 330 205 431 minecraft:red_concrete
setblock 330 205 438 minecraft:red_concrete
setblock 330 205 445 minecraft:red_concrete
setblock 330 205 452 minecraft:red_concrete
setblock 332 205 457 minecraft:red_concrete
setblock 337 205 417 minecraft:red_concrete
setblock 339 205 457 minecraft:red_concrete
fill 343 205 442 343 206 443 minecraft:red_wool
setblock 344 205 417 minecraft:red_concrete
setblock 346 205 457 minecraft:red_concrete
setblock 351 205 417 minecraft:red_concrete
setblock 353 205 457 minecraft:red_concrete
setblock 358 205 417 minecraft:red_concrete
setblock 360 205 457 minecraft:red_concrete
setblock 365 205 417 minecraft:red_concrete
setblock 367 205 457 minecraft:red_concrete
setblock 370 205 419 minecraft:red_concrete
setblock 370 205 426 minecraft:red_concrete
setblock 370 205 433 minecraft:red_concrete
setblock 370 205 440 minecraft:red_concrete
setblock 370 205 447 minecraft:red_concrete
setblock 370 205 454 minecraft:red_concrete
setblock 330 206 418 minecraft:red_concrete
setblock 330 206 425 minecraft:red_concrete
setblock 330 206 432 minecraft:red_concrete
setblock 330 206 439 minecraft:red_concrete
setblock 330 206 446 minecraft:red_concrete
setblock 330 206 453 minecraft:red_concrete
setblock 333 206 457 minecraft:red_concrete
setblock 336 206 417 minecraft:red_concrete
setblock 340 206 457 minecraft:red_concrete
setblock 343 206 417 minecraft:red_concrete
setblock 347 206 457 minecraft:red_concrete
setblock 350 206 417 minecraft:red_concrete
setblock 354 206 457 minecraft:red_concrete
setblock 357 206 417 minecraft:red_concrete
setblock 361 206 457 minecraft:red_concrete
setblock 364 206 417 minecraft:red_concrete
setblock 368 206 457 minecraft:red_concrete
setblock 370 206 418 minecraft:red_concrete
setblock 370 206 425 minecraft:red_concrete
setblock 370 206 432 minecraft:red_concrete
setblock 370 206 439 minecraft:red_concrete
setblock 370 206 446 minecraft:red_concrete
setblock 370 206 453 minecraft:red_concrete
setblock 330 207 419 minecraft:red_concrete
setblock 330 207 426 minecraft:red_concrete
setblock 330 207 433 minecraft:red_concrete
setblock 330 207 440 minecraft:red_concrete
setblock 330 207 447 minecraft:red_concrete
setblock 330 207 454 minecraft:red_concrete
setblock 334 207 457 minecraft:red_concrete
setblock 335 207 417 minecraft:red_concrete
setblock 341 207 457 minecraft:red_concrete
setblock 342 207 417 minecraft:red_concrete
setblock 348 207 457 minecraft:red_concrete
setblock 349 207 417 minecraft:red_concrete
setblock 355 207 457 minecraft:red_concrete
setblock 356 207 417 minecraft:red_concrete
setblock 362 207 457 minecraft:red_concrete
setblock 363 207 417 minecraft:red_concrete
setblock 369 207 457 minecraft:red_concrete
setblock 370 207 417 minecraft:red_concrete
setblock 370 207 424 minecraft:red_concrete
setblock 370 207 431 minecraft:red_concrete
setblock 370 207 438 minecraft:red_concrete
setblock 370 207 445 minecraft:red_concrete
setblock 370 207 452 minecraft:red_concrete
setblock 330 208 420 minecraft:red_concrete
setblock 330 208 427 minecraft:red_concrete
setblock 330 208 434 minecraft:red_concrete
setblock 330 208 441 minecraft:red_concrete
setblock 330 208 448 minecraft:red_concrete
setblock 330 208 455 minecraft:red_concrete
setblock 332 208 419 minecraft:light[level=12]
setblock 332 208 427 minecraft:light[level=12]
setblock 332 208 435 minecraft:light[level=12]
setblock 332 208 443 minecraft:light[level=12]
setblock 332 208 451 minecraft:light[level=12]
setblock 334 208 417 minecraft:red_concrete
setblock 335 208 457 minecraft:red_concrete
setblock 340 208 419 minecraft:light[level=12]
setblock 340 208 427 minecraft:light[level=12]
setblock 340 208 435 minecraft:light[level=12]
setblock 340 208 443 minecraft:light[level=12]
setblock 340 208 451 minecraft:light[level=12]
setblock 341 208 417 minecraft:red_concrete
setblock 342 208 457 minecraft:red_concrete
setblock 348 208 417 minecraft:red_concrete
setblock 348 208 419 minecraft:light[level=12]
setblock 348 208 427 minecraft:light[level=12]
setblock 348 208 435 minecraft:light[level=12]
setblock 348 208 443 minecraft:light[level=12]
setblock 348 208 451 minecraft:light[level=12]
setblock 349 208 457 minecraft:red_concrete
setblock 355 208 417 minecraft:red_concrete
setblock 356 208 419 minecraft:light[level=12]
setblock 356 208 427 minecraft:light[level=12]
setblock 356 208 443 minecraft:light[level=12]
setblock 356 208 451 minecraft:light[level=12]
setblock 356 208 457 minecraft:red_concrete
setblock 362 208 417 minecraft:red_concrete
setblock 363 208 457 minecraft:red_concrete
setblock 364 208 419 minecraft:light[level=12]
setblock 364 208 427 minecraft:light[level=12]
setblock 364 208 435 minecraft:light[level=12]
setblock 364 208 443 minecraft:light[level=12]
setblock 364 208 451 minecraft:light[level=12]
setblock 369 208 417 minecraft:red_concrete
setblock 370 208 423 minecraft:red_concrete
setblock 370 208 430 minecraft:red_concrete
setblock 370 208 437 minecraft:red_concrete
setblock 370 208 444 minecraft:red_concrete
setblock 370 208 451 minecraft:red_concrete
setblock 370 208 457 minecraft:red_concrete
fill 330 209 421 330 210 421 minecraft:red_concrete
fill 330 209 428 330 210 428 minecraft:red_concrete
fill 330 209 435 330 210 435 minecraft:red_concrete
fill 330 209 442 330 210 442 minecraft:red_concrete
fill 330 209 449 330 210 449 minecraft:red_concrete
fill 330 209 456 330 210 456 minecraft:red_concrete
fill 333 209 417 333 210 417 minecraft:red_concrete
fill 336 209 457 336 210 457 minecraft:red_concrete
fill 340 209 417 340 210 417 minecraft:red_concrete
fill 343 209 457 343 210 457 minecraft:red_concrete
fill 347 209 417 347 210 417 minecraft:red_concrete
fill 350 209 457 350 210 457 minecraft:red_concrete
fill 354 209 417 354 210 417 minecraft:red_concrete
fill 357 209 457 357 210 457 minecraft:red_concrete
fill 359 209 433 360 210 434 minecraft:red_wool
fill 361 209 417 361 210 417 minecraft:red_concrete
fill 364 209 457 364 210 457 minecraft:red_concrete
fill 368 209 417 368 210 417 minecraft:red_concrete
fill 370 209 422 370 210 422 minecraft:red_concrete
fill 370 209 429 370 210 429 minecraft:red_concrete
fill 370 209 436 370 210 436 minecraft:red_concrete
fill 370 209 443 370 210 443 minecraft:red_concrete
fill 370 209 450 370 210 450 minecraft:red_concrete
fill 330 210 417 330 210 420 minecraft:red_concrete
fill 330 210 423 330 210 427 minecraft:red_concrete
fill 330 210 430 330 210 434 minecraft:red_concrete
fill 330 210 437 330 210 441 minecraft:red_concrete
fill 330 210 444 330 210 448 minecraft:red_concrete
fill 330 210 451 330 210 455 minecraft:red_concrete
fill 331 210 417 331 211 417 minecraft:red_concrete
fill 331 210 457 335 210 457 minecraft:red_concrete
fill 334 210 417 338 210 417 minecraft:red_concrete
fill 338 210 457 342 210 457 minecraft:red_concrete
fill 341 210 417 345 210 417 minecraft:red_concrete
fill 345 210 457 349 210 457 minecraft:red_concrete
fill 348 210 417 352 210 417 minecraft:red_concrete
fill 352 210 457 356 210 457 minecraft:red_concrete
fill 355 210 417 359 210 417 minecraft:red_concrete
fill 359 210 457 363 210 457 minecraft:red_concrete
fill 362 210 417 366 210 417 minecraft:red_concrete
fill 366 210 457 370 210 457 minecraft:red_concrete
fill 369 210 417 370 210 417 minecraft:red_concrete
fill 370 210 418 370 210 420 minecraft:red_concrete
fill 370 210 423 370 210 427 minecraft:red_concrete
fill 370 210 430 370 210 434 minecraft:red_concrete
fill 370 210 437 370 210 441 minecraft:red_concrete
fill 370 210 444 370 210 448 minecraft:red_concrete
fill 370 210 451 370 210 455 minecraft:red_concrete
setblock 330 211 423 minecraft:red_concrete
setblock 330 211 430 minecraft:red_concrete
setblock 330 211 437 minecraft:red_concrete
setblock 330 211 444 minecraft:red_concrete
setblock 330 211 451 minecraft:red_concrete
setblock 331 211 457 minecraft:red_concrete
setblock 338 211 417 minecraft:red_concrete
setblock 338 211 457 minecraft:red_concrete
setblock 345 211 417 minecraft:red_concrete
setblock 345 211 457 minecraft:red_concrete
setblock 352 211 417 minecraft:red_concrete
setblock 352 211 457 minecraft:red_concrete
setblock 359 211 417 minecraft:red_concrete
setblock 359 211 457 minecraft:red_concrete
setblock 366 211 417 minecraft:red_concrete
setblock 366 211 457 minecraft:red_concrete
setblock 370 211 420 minecraft:red_concrete
setblock 370 211 427 minecraft:red_concrete
setblock 370 211 434 minecraft:red_concrete
setblock 370 211 441 minecraft:red_concrete
setblock 370 211 448 minecraft:red_concrete
setblock 370 211 455 minecraft:red_concrete
setblock 330 212 417 minecraft:red_concrete
setblock 330 212 424 minecraft:red_concrete
setblock 330 212 431 minecraft:red_concrete
setblock 330 212 438 minecraft:red_concrete
setblock 330 212 445 minecraft:red_concrete
setblock 330 212 452 minecraft:red_concrete
setblock 332 212 457 minecraft:red_concrete
setblock 337 212 417 minecraft:red_concrete
setblock 339 212 457 minecraft:red_concrete
setblock 344 212 417 minecraft:red_concrete
setblock 346 212 457 minecraft:red_concrete
setblock 351 212 417 minecraft:red_concrete
setblock 353 212 457 minecraft:red_concrete
setblock 358 212 417 minecraft:red_concrete
setblock 360 212 457 minecraft:red_concrete
setblock 365 212 417 minecraft:red_concrete
setblock 367 212 457 minecraft:red_concrete
setblock 370 212 419 minecraft:red_concrete
setblock 370 212 426 minecraft:red_concrete
setblock 370 212 433 minecraft:red_concrete
setblock 370 212 440 minecraft:red_concrete
setblock 370 212 447 minecraft:red_concrete
setblock 370 212 454 minecraft:red_concrete
setblock 330 213 418 minecraft:red_concrete
setblock 330 213 425 minecraft:red_concrete
setblock 330 213 432 minecraft:red_concrete
setblock 330 213 439 minecraft:red_concrete
setblock 330 213 446 minecraft:red_concrete
setblock 330 213 453 minecraft:red_concrete
setblock 333 213 457 minecraft:red_concrete
setblock 336 213 417 minecraft:red_concrete
setblock 340 213 457 minecraft:red_concrete
setblock 343 213 417 minecraft:red_concrete
setblock 347 213 457 minecraft:red_concrete
setblock 350 213 417 minecraft:red_concrete
setblock 354 213 457 minecraft:red_concrete
setblock 357 213 417 minecraft:red_concrete
setblock 361 213 457 minecraft:red_concrete
setblock 364 213 417 minecraft:red_concrete
setblock 368 213 457 minecraft:red_concrete
setblock 370 213 418 minecraft:red_concrete
setblock 370 213 425 minecraft:red_concrete
setblock 370 213 432 minecraft:red_concrete
setblock 370 213 439 minecraft:red_concrete
setblock 370 213 446 minecraft:red_concrete
setblock 370 213 453 minecraft:red_concrete
setblock 330 214 419 minecraft:red_concrete
setblock 330 214 426 minecraft:red_concrete
setblock 330 214 433 minecraft:red_concrete
setblock 330 214 440 minecraft:red_concrete
setblock 330 214 447 minecraft:red_concrete
setblock 330 214 454 minecraft:red_concrete
setblock 334 214 457 minecraft:red_concrete
setblock 335 214 417 minecraft:red_concrete
setblock 341 214 457 minecraft:red_concrete
setblock 342 214 417 minecraft:red_concrete
setblock 348 214 457 minecraft:red_concrete
setblock 349 214 417 minecraft:red_concrete
setblock 355 214 457 minecraft:red_concrete
setblock 356 214 417 minecraft:red_concrete
setblock 362 214 457 minecraft:red_concrete
setblock 363 214 417 minecraft:red_concrete
setblock 369 214 457 minecraft:red_concrete
setblock 370 214 417 minecraft:red_concrete
setblock 370 214 424 minecraft:red_concrete
setblock 370 214 431 minecraft:red_concrete
setblock 370 214 438 minecraft:red_concrete
setblock 370 214 445 minecraft:red_concrete
setblock 370 214 452 minecraft:red_concrete
setblock 330 215 420 minecraft:red_concrete
setblock 330 215 427 minecraft:red_concrete
setblock 330 215 434 minecraft:red_concrete
setblock 330 215 441 minecraft:red_concrete
setblock 330 215 448 minecraft:red_concrete
setblock 330 215 455 minecraft:red_concrete
setblock 334 215 417 minecraft:red_concrete
setblock 335 215 457 minecraft:red_concrete
setblock 341 215 417 minecraft:red_concrete
setblock 342 215 457 minecraft:red_concrete
setblock 348 215 417 minecraft:red_concrete
setblock 349 215 457 minecraft:red_concrete
setblock 355 215 417 minecraft:red_concrete
setblock 356 215 457 minecraft:red_concrete
setblock 362 215 417 minecraft:red_concrete
setblock 363 215 457 minecraft:red_concrete
setblock 369 215 417 minecraft:red_concrete
setblock 370 215 423 minecraft:red_concrete
setblock 370 215 430 minecraft:red_concrete
setblock 370 215 437 minecraft:red_concrete
setblock 370 215 444 minecraft:red_concrete
setblock 370 215 451 minecraft:red_concrete
setblock 370 215 457 minecraft:red_concrete
setblock 330 216 421 minecraft:red_concrete
setblock 330 216 428 minecraft:red_concrete
setblock 330 216 435 minecraft:red_concrete
setblock 330 216 442 minecraft:red_concrete
setblock 330 216 449 minecraft:red_concrete
setblock 330 216 456 minecraft:red_concrete
setblock 332 216 419 minecraft:light[level=12]
setblock 332 216 427 minecraft:light[level=12]
setblock 332 216 435 minecraft:light[level=12]
setblock 332 216 443 minecraft:light[level=12]
setblock 332 216 451 minecraft:light[level=12]
setblock 333 216 417 minecraft:red_concrete
setblock 336 216 457 minecraft:red_concrete
setblock 340 216 417 minecraft:red_concrete
setblock 340 216 419 minecraft:light[level=12]
setblock 340 216 427 minecraft:light[level=12]
setblock 340 216 435 minecraft:light[level=12]
setblock 340 216 443 minecraft:light[level=12]
setblock 340 216 451 minecraft:light[level=12]
setblock 343 216 457 minecraft:red_concrete
setblock 347 216 417 minecraft:red_concrete
setblock 348 216 419 minecraft:light[level=12]
setblock 348 216 427 minecraft:light[level=12]
setblock 348 216 435 minecraft:light[level=12]
setblock 348 216 443 minecraft:light[level=12]
setblock 348 216 451 minecraft:light[level=12]
setblock 350 216 457 minecraft:red_concrete
setblock 354 216 417 minecraft:red_concrete
setblock 356 216 419 minecraft:light[level=12]
setblock 356 216 427 minecraft:light[level=12]
setblock 356 216 443 minecraft:light[level=12]
setblock 356 216 451 minecraft:light[level=12]
setblock 357 216 457 minecraft:red_concrete
setblock 361 216 417 minecraft:red_concrete
setblock 364 216 419 minecraft:light[level=12]
setblock 364 216 427 minecraft:light[level=12]
setblock 364 216 435 minecraft:light[level=12]
setblock 364 216 443 minecraft:light[level=12]
setblock 364 216 451 minecraft:light[level=12]
setblock 364 216 457 minecraft:red_concrete
setblock 368 216 417 minecraft:red_concrete
setblock 370 216 422 minecraft:red_concrete
setblock 370 216 429 minecraft:red_concrete
setblock 370 216 436 minecraft:red_concrete
setblock 370 216 443 minecraft:red_concrete
setblock 370 216 450 minecraft:red_concrete
setblock 330 218 423 minecraft:red_concrete
setblock 330 218 430 minecraft:red_concrete
setblock 330 218 437 minecraft:red_concrete
setblock 330 218 444 minecraft:red_concrete
setblock 330 218 451 minecraft:red_concrete
setblock 331 218 417 minecraft:red_concrete
setblock 331 218 457 minecraft:red_concrete
setblock 338 218 417 minecraft:red_concrete
setblock 338 218 457 minecraft:red_concrete
setblock 345 218 417 minecraft:red_concrete
setblock 345 218 457 minecraft:red_concrete
setblock 352 218 417 minecraft:red_concrete
setblock 352 218 457 minecraft:red_concrete
setblock 359 218 417 minecraft:red_concrete
setblock 359 218 457 minecraft:red_concrete
setblock 366 218 417 minecraft:red_concrete
setblock 366 218 457 minecraft:red_concrete
setblock 370 218 420 minecraft:red_concrete
setblock 370 218 427 minecraft:red_concrete
setblock 370 218 434 minecraft:red_concrete
setblock 370 218 441 minecraft:red_concrete
setblock 370 218 448 minecraft:red_concrete
setblock 370 218 455 minecraft:red_concrete
fill 330 219 417 330 220 417 minecraft:red_concrete
fill 330 219 424 330 220 424 minecraft:red_concrete
fill 330 219 431 330 220 431 minecraft:red_concrete
fill 330 219 438 330 220 438 minecraft:red_concrete
fill 330 219 445 330 220 445 minecraft:red_concrete
fill 330 219 452 330 220 452 minecraft:red_concrete
fill 332 219 457 332 220 457 minecraft:red_concrete
fill 337 219 417 337 220 417 minecraft:red_concrete
fill 339 219 457 339 220 457 minecraft:red_concrete
fill 344 219 417 344 220 417 minecraft:red_concrete
fill 346 219 457 346 220 457 minecraft:red_concrete
fill 351 219 417 351 220 417 minecraft:red_concrete
fill 353 219 457 353 220 457 minecraft:red_concrete
fill 358 219 417 358 220 417 minecraft:red_concrete
fill 360 219 457 360 220 457 minecraft:red_concrete
fill 365 219 417 365 220 417 minecraft:red_concrete
fill 367 219 457 367 220 457 minecraft:red_concrete
fill 370 219 419 370 220 419 minecraft:red_concrete
fill 370 219 426 370 220 426 minecraft:red_concrete
fill 370 219 433 370 220 433 minecraft:red_concrete
fill 370 219 440 370 220 440 minecraft:red_concrete
fill 370 219 447 370 220 447 minecraft:red_concrete
fill 370 219 454 370 220 454 minecraft:red_concrete
fill 330 220 418 330 220 421 minecraft:red_concrete
setblock 330 220 423 minecraft:red_concrete
fill 330 220 425 330 220 428 minecraft:red_concrete
setblock 330 220 430 minecraft:red_concrete
fill 330 220 432 330 220 435 minecraft:red_concrete
setblock 330 220 437 minecraft:red_concrete
fill 330 220 439 330 220 442 minecraft:red_concrete
setblock 330 220 444 minecraft:red_concrete
fill 330 220 446 330 220 449 minecraft:red_concrete
setblock 330 220 451 minecraft:red_concrete
fill 330 220 453 330 220 456 minecraft:red_concrete
setblock 331 220 417 minecraft:red_concrete
setblock 331 220 457 minecraft:red_concrete
fill 333 220 417 336 220 417 minecraft:red_concrete
fill 333 220 457 336 220 457 minecraft:red_concrete
setblock 338 220 417 minecraft:red_concrete
setblock 338 220 457 minecraft:red_concrete
fill 340 220 417 343 220 417 minecraft:red_concrete
fill 340 220 457 343 220 457 minecraft:red_concrete
setblock 345 220 417 minecraft:red_concrete
setblock 345 220 457 minecraft:red_concrete
fill 347 220 417 350 220 417 minecraft:red_concrete
fill 347 220 457 350 220 457 minecraft:red_concrete
setblock 352 220 417 minecraft:red_concrete
setblock 352 220 457 minecraft:red_concrete
fill 354 220 417 357 220 417 minecraft:red_concrete
fill 354 220 457 357 220 457 minecraft:red_concrete
setblock 359 220 417 minecraft:red_concrete
setblock 359 220 457 minecraft:red_concrete
fill 361 220 417 364 220 417 minecraft:red_concrete
fill 361 220 457 364 220 457 minecraft:red_concrete
setblock 366 220 417 minecraft:red_concrete
setblock 366 220 457 minecraft:red_concrete
fill 368 220 417 370 220 417 minecraft:red_concrete
fill 368 220 457 370 220 457 minecraft:red_concrete
setblock 370 220 418 minecraft:red_concrete
setblock 370 220 420 minecraft:red_concrete
fill 370 220 422 370 220 425 minecraft:red_concrete
setblock 370 220 427 minecraft:red_concrete
fill 370 220 429 370 220 432 minecraft:red_concrete
setblock 370 220 434 minecraft:red_concrete
fill 370 220 436 370 220 439 minecraft:red_concrete
setblock 370 220 441 minecraft:red_concrete
fill 370 220 443 370 220 446 minecraft:red_concrete
setblock 370 220 448 minecraft:red_concrete
fill 370 220 450 370 220 453 minecraft:red_concrete
setblock 370 220 455 minecraft:red_concrete
setblock 330 221 419 minecraft:red_concrete
setblock 330 221 426 minecraft:red_concrete
setblock 330 221 433 minecraft:red_concrete
setblock 330 221 440 minecraft:red_concrete
setblock 330 221 447 minecraft:red_concrete
setblock 330 221 454 minecraft:red_concrete
setblock 334 221 457 minecraft:red_concrete
setblock 335 221 417 minecraft:red_concrete
setblock 341 221 457 minecraft:red_concrete
setblock 342 221 417 minecraft:red_concrete
setblock 348 221 457 minecraft:red_concrete
setblock 349 221 417 minecraft:red_concrete
setblock 355 221 457 minecraft:red_concrete
setblock 356 221 417 minecraft:red_concrete
setblock 362 221 457 minecraft:red_concrete
setblock 363 221 417 minecraft:red_concrete
fill 363 221 439 364 222 440 minecraft:red_wool
setblock 369 221 457 minecraft:red_concrete
setblock 370 221 417 minecraft:red_concrete
setblock 370 221 424 minecraft:red_concrete
setblock 370 221 431 minecraft:red_concrete
setblock 370 221 438 minecraft:red_concrete
setblock 370 221 445 minecraft:red_concrete
setblock 370 221 452 minecraft:red_concrete
setblock 330 222 420 minecraft:red_concrete
setblock 330 222 427 minecraft:red_concrete
setblock 330 222 434 minecraft:red_concrete
setblock 330 222 441 minecraft:red_concrete
setblock 330 222 448 minecraft:red_concrete
setblock 330 222 455 minecraft:red_concrete
setblock 334 222 417 minecraft:red_concrete
setblock 335 222 457 minecraft:red_concrete
setblock 341 222 417 minecraft:red_concrete
setblock 342 222 457 minecraft:red_concrete
setblock 348 222 417 minecraft:red_concrete
setblock 349 222 457 minecraft:red_concrete
setblock 355 222 417 minecraft:red_concrete
setblock 356 222 457 minecraft:red_concrete
setblock 362 222 417 minecraft:red_concrete
setblock 363 222 457 minecraft:red_concrete
setblock 369 222 417 minecraft:red_concrete
setblock 370 222 423 minecraft:red_concrete
setblock 370 222 430 minecraft:red_concrete
setblock 370 222 437 minecraft:red_concrete
setblock 370 222 444 minecraft:red_concrete
setblock 370 222 451 minecraft:red_concrete
setblock 370 222 457 minecraft:red_concrete
setblock 330 223 421 minecraft:red_concrete
setblock 330 223 428 minecraft:red_concrete
setblock 330 223 435 minecraft:red_concrete
setblock 330 223 442 minecraft:red_concrete
setblock 330 223 449 minecraft:red_concrete
setblock 330 223 456 minecraft:red_concrete
setblock 333 223 417 minecraft:red_concrete
setblock 336 223 457 minecraft:red_concrete
setblock 340 223 417 minecraft:red_concrete
setblock 343 223 457 minecraft:red_concrete
setblock 347 223 417 minecraft:red_concrete
setblock 350 223 457 minecraft:red_concrete
setblock 354 223 417 minecraft:red_concrete
setblock 357 223 457 minecraft:red_concrete
setblock 361 223 417 minecraft:red_concrete
setblock 364 223 457 minecraft:red_concrete
setblock 368 223 417 minecraft:red_concrete
setblock 370 223 422 minecraft:red_concrete
setblock 370 223 429 minecraft:red_concrete
setblock 370 223 436 minecraft:red_concrete
setblock 370 223 443 minecraft:red_concrete
setblock 370 223 450 minecraft:red_concrete
setblock 332 224 419 minecraft:light[level=12]
setblock 332 224 427 minecraft:light[level=12]
setblock 332 224 435 minecraft:light[level=12]
setblock 332 224 443 minecraft:light[level=12]
setblock 332 224 451 minecraft:light[level=12]
setblock 340 224 419 minecraft:light[level=12]
setblock 340 224 427 minecraft:light[level=12]
setblock 340 224 435 minecraft:light[level=12]
setblock 340 224 443 minecraft:light[level=12]
setblock 340 224 451 minecraft:light[level=12]
setblock 348 224 419 minecraft:light[level=12]
setblock 348 224 427 minecraft:light[level=12]
setblock 348 224 435 minecraft:light[level=12]
setblock 348 224 443 minecraft:light[level=12]
setblock 348 224 451 minecraft:light[level=12]
setblock 356 224 419 minecraft:light[level=12]
setblock 356 224 427 minecraft:light[level=12]
setblock 356 224 443 minecraft:light[level=12]
setblock 356 224 451 minecraft:light[level=12]
setblock 364 224 419 minecraft:light[level=12]
setblock 364 224 427 minecraft:light[level=12]
setblock 364 224 435 minecraft:light[level=12]
setblock 364 224 443 minecraft:light[level=12]
setblock 364 224 451 minecraft:light[level=12]
setblock 330 225 423 minecraft:red_concrete
setblock 330 225 430 minecraft:red_concrete
setblock 330 225 437 minecraft:red_concrete
setblock 330 225 444 minecraft:red_concrete
setblock 330 225 451 minecraft:red_concrete
setblock 331 225 417 minecraft:red_concrete
setblock 331 225 457 minecraft:red_concrete
setblock 338 225 417 minecraft:red_concrete
fill 338 225 440 339 226 441 minecraft:red_wool
setblock 338 225 457 minecraft:red_concrete
setblock 345 225 417 minecraft:red_concrete
setblock 345 225 457 minecraft:red_concrete
setblock 352 225 417 minecraft:red_concrete
setblock 352 225 457 minecraft:red_concrete
setblock 359 225 417 minecraft:red_concrete
setblock 359 225 457 minecraft:red_concrete
setblock 366 225 417 minecraft:red_concrete
setblock 366 225 457 minecraft:red_concrete
setblock 370 225 420 minecraft:red_concrete
setblock 370 225 427 minecraft:red_concrete
setblock 370 225 434 minecraft:red_concrete
setblock 370 225 441 minecraft:red_concrete
setblock 370 225 448 minecraft:red_concrete
setblock 370 225 455 minecraft:red_concrete
setblock 330 226 417 minecraft:red_concrete
setblock 330 226 424 minecraft:red_concrete
setblock 330 226 431 minecraft:red_concrete
setblock 330 226 438 minecraft:red_concrete
setblock 330 226 445 minecraft:red_concrete
setblock 330 226 452 minecraft:red_concrete
setblock 332 226 457 minecraft:red_concrete
setblock 337 226 417 minecraft:red_concrete
setblock 339 226 457 minecraft:red_concrete
setblock 344 226 417 minecraft:red_concrete
setblock 346 226 457 minecraft:red_concrete
setblock 351 226 417 minecraft:red_concrete
setblock 353 226 457 minecraft:red_concrete
setblock 358 226 417 minecraft:red_concrete
setblock 360 226 457 minecraft:red_concrete
setblock 365 226 417 minecraft:red_concrete
setblock 367 226 457 minecraft:red_concrete
setblock 370 226 419 minecraft:red_concrete
setblock 370 226 426 minecraft:red_concrete
setblock 370 226 433 minecraft:red_concrete
setblock 370 226 440 minecraft:red_concrete
setblock 370 226 447 minecraft:red_concrete
setblock 370 226 454 minecraft:red_concrete
setblock 332 232 419 minecraft:light[level=12]
setblock 332 232 427 minecraft:light[level=12]
setblock 332 232 435 minecraft:light[level=12]
setblock 332 232 443 minecraft:light[level=12]
setblock 332 232 451 minecraft:light[level=12]
setblock 340 232 419 minecraft:light[level=12]
setblock 340 232 427 minecraft:light[level=12]
setblock 340 232 435 minecraft:light[level=12]
setblock 340 232 443 minecraft:light[level=12]
setblock 340 232 451 minecraft:light[level=12]
fill 347 232 433 349 234 435 minecraft:orange_concrete
fill 347 232 436 349 234 437 minecraft:yellow_concrete
setblock 348 232 419 minecraft:light[level=12]
setblock 348 232 427 minecraft:light[level=12]
fill 348 232 431 350 234 432 minecraft:orange_concrete
fill 348 232 438 350 234 439 minecraft:yellow_concrete
setblock 348 232 443 minecraft:light[level=12]
setblock 348 232 451 minecraft:light[level=12]
fill 349 232 429 351 234 430 minecraft:orange_concrete
fill 349 232 440 351 234 441 minecraft:yellow_concrete
fill 351 232 428 359 234 428 minecraft:red_concrete
fill 351 232 431 351 234 431 minecraft:orange_concrete
fill 351 232 439 351 234 439 minecraft:yellow_concrete
fill 351 232 442 359 234 442 minecraft:red_concrete
fill 352 232 429 358 234 429 minecraft:red_concrete
fill 352 232 430 352 234 430 minecraft:orange_concrete
fill 352 232 440 352 234 440 minecraft:yellow_concrete
fill 352 232 441 358 234 441 minecraft:red_concrete
fill 353 232 427 357 234 427 minecraft:red_concrete
fill 353 232 443 357 234 443 minecraft:red_concrete
setblock 356 232 419 minecraft:light[level=12]
setblock 356 232 451 minecraft:light[level=12]
fill 358 232 430 361 234 430 minecraft:yellow_concrete
fill 358 232 440 361 234 440 minecraft:orange_concrete
fill 359 232 429 361 234 429 minecraft:yellow_concrete
fill 359 232 431 362 234 431 minecraft:yellow_concrete
fill 359 232 439 362 234 439 minecraft:orange_concrete
fill 359 232 441 361 234 441 minecraft:orange_concrete
fill 360 232 432 362 234 432 minecraft:yellow_concrete
fill 360 232 438 362 234 438 minecraft:orange_concrete
fill 361 232 433 363 234 434 minecraft:yellow_concrete
fill 361 232 435 363 234 437 minecraft:orange_concrete
setblock 364 232 419 minecraft:light[level=12]
setblock 364 232 427 minecraft:light[level=12]
setblock 364 232 435 minecraft:light[level=12]
setblock 364 232 443 minecraft:light[level=12]
setblock 364 232 451 minecraft:light[level=12]
fill 330 233 417 346 233 457 minecraft:black_concrete
fill 347 233 417 347 233 431 minecraft:black_concrete
setblock 347 233 432 minecraft:orange_concrete
setblock 347 233 438 minecraft:yellow_concrete
fill 347 233 439 347 233 457 minecraft:black_concrete
fill 348 233 417 348 233 429 minecraft:black_concrete
setblock 348 233 430 minecraft:orange_concrete
setblock 348 233 440 minecraft:yellow_concrete
fill 348 233 441 348 233 457 minecraft:black_concrete
fill 349 233 417 349 233 428 minecraft:black_concrete
fill 349 233 442 349 233 457 minecraft:black_concrete
fill 350 233 417 351 233 427 minecraft:black_concrete
setblock 350 233 428 minecraft:orange_concrete
setblock 350 233 433 minecraft:orange_concrete
fill 350 233 434 351 233 436 minecraft:black_concrete
setblock 350 233 437 minecraft:yellow_concrete
setblock 350 233 442 minecraft:yellow_concrete
fill 350 233 443 351 233 457 minecraft:black_concrete
fill 351 233 432 352 233 433 minecraft:black_concrete
fill 351 233 437 352 233 438 minecraft:black_concrete
fill 352 233 417 370 233 426 minecraft:black_concrete
setblock 352 233 427 minecraft:red_concrete
fill 352 233 431 358 233 431 minecraft:black_concrete
fill 352 233 434 352 233 436 minecraft:jack_o_lantern
fill 352 233 439 358 233 439 minecraft:black_concrete
setblock 352 233 443 minecraft:red_concrete
fill 352 233 444 370 233 457 minecraft:black_concrete
setblock 353 233 430 minecraft:red_concrete
setblock 353 233 432 minecraft:black_concrete
fill 353 233 433 353 233 434 minecraft:jack_o_lantern
fill 353 233 436 353 233 437 minecraft:jack_o_lantern
setblock 353 233 438 minecraft:black_concrete
setblock 353 233 440 minecraft:red_concrete
fill 354 233 430 356 233 430 minecraft:black_concrete
fill 354 233 432 354 233 433 minecraft:jack_o_lantern
fill 354 233 437 354 233 438 minecraft:jack_o_lantern
fill 354 233 440 356 233 440 minecraft:black_concrete
fill 355 233 432 356 233 432 minecraft:jack_o_lantern
fill 355 233 438 356 233 438 minecraft:jack_o_lantern
fill 356 233 433 357 233 433 minecraft:jack_o_lantern
fill 356 233 437 357 233 437 minecraft:jack_o_lantern
setblock 357 233 430 minecraft:red_concrete
fill 357 233 432 359 233 432 minecraft:black_concrete
fill 357 233 434 358 233 434 minecraft:jack_o_lantern
fill 357 233 436 358 233 436 minecraft:jack_o_lantern
fill 357 233 438 359 233 438 minecraft:black_concrete
setblock 357 233 440 minecraft:red_concrete
setblock 358 233 427 minecraft:red_concrete
fill 358 233 433 359 233 433 minecraft:black_concrete
setblock 358 233 435 minecraft:jack_o_lantern
fill 358 233 437 359 233 437 minecraft:black_concrete
setblock 358 233 443 minecraft:red_concrete
fill 359 233 427 370 233 427 minecraft:black_concrete
fill 359 233 434 360 233 436 minecraft:black_concrete
fill 359 233 443 370 233 443 minecraft:black_concrete
setblock 360 233 428 minecraft:yellow_concrete
setblock 360 233 433 minecraft:yellow_concrete
setblock 360 233 437 minecraft:orange_concrete
setblock 360 233 442 minecraft:orange_concrete
fill 361 233 428 370 233 428 minecraft:black_concrete
fill 361 233 442 370 233 442 minecraft:black_concrete
fill 362 233 429 370 233 429 minecraft:black_concrete
setblock 362 233 430 minecraft:yellow_concrete
setblock 362 233 440 minecraft:orange_concrete
fill 362 233 441 370 233 441 minecraft:black_concrete
fill 363 233 430 370 233 431 minecraft:black_concrete
setblock 363 233 432 minecraft:yellow_concrete
setblock 363 233 438 minecraft:orange_concrete
fill 363 233 439 370 233 440 minecraft:black_concrete
fill 364 233 432 370 233 438 minecraft:black_concrete
fill 330 237 421 330 237 422 minecraft:red_concrete
fill 330 237 428 330 237 429 minecraft:red_concrete
fill 330 237 435 330 237 436 minecraft:red_concrete
fill 330 237 439 338 237 447 minecraft:red_concrete
fill 330 237 449 330 237 450 minecraft:red_concrete
fill 330 237 456 330 237 457 minecraft:red_concrete
fill 332 237 417 333 237 417 minecraft:red_concrete
fill 336 237 457 337 237 457 minecraft:red_concrete
fill 339 237 417 340 237 417 minecraft:red_concrete
fill 343 237 457 344 237 457 minecraft:red_concrete
fill 346 237 417 347 237 417 minecraft:red_concrete
fill 350 237 457 351 237 457 minecraft:red_concrete
fill 353 237 417 354 237 417 minecraft:red_concrete
fill 357 237 447 367 261 457 minecraft:red_concrete
fill 360 237 417 361 237 417 minecraft:red_concrete
fill 367 237 417 368 237 417 minecraft:red_concrete
fill 370 237 421 370 237 422 minecraft:red_concrete
fill 370 237 428 370 237 429 minecraft:red_concrete
fill 370 237 435 370 237 436 minecraft:red_concrete
fill 370 237 442 370 237 443 minecraft:red_concrete
fill 370 237 449 370 237 450 minecraft:red_concrete
fill 370 237 456 370 273 456 minecraft:red_concrete
fill 330 238 422 330 273 422 minecraft:red_concrete
fill 330 238 429 330 273 429 minecraft:red_concrete
fill 330 238 436 330 273 436 minecraft:red_concrete
setblock 330 238 439 minecraft:jack_o_lantern
fill 330 238 440 330 250 440 minecraft:red_concrete
setblock 330 238 441 minecraft:jack_o_lantern
fill 330 238 442 330 251 442 minecraft:red_concrete
setblock 330 238 443 minecraft:jack_o_lantern
fill 330 238 444 330 250 444 minecraft:red_concrete
setblock 330 238 445 minecraft:jack_o_lantern
fill 330 238 446 330 250 446 minecraft:red_concrete
setblock 330 238 447 minecraft:jack_o_lantern
fill 330 238 450 330 273 450 minecraft:red_concrete
fill 330 238 457 330 273 457 minecraft:red_concrete
fill 331 238 439 331 249 439 minecraft:red_concrete
setblock 331 238 440 minecraft:jack_o_lantern
fill 331 238 441 331 249 441 minecraft:red_concrete
setblock 331 238 442 minecraft:jack_o_lantern
fill 331 238 443 331 249 443 minecraft:red_concrete
setblock 331 238 444 minecraft:jack_o_lantern
fill 331 238 445 331 249 445 minecraft:red_concrete
setblock 331 238 446 minecraft:jack_o_lantern
fill 331 238 447 331 249 447 minecraft:red_concrete
fill 332 238 417 332 273 417 minecraft:red_concrete
setblock 332 238 439 minecraft:jack_o_lantern
fill 332 238 440 332 249 440 minecraft:red_concrete
setblock 332 238 441 minecraft:jack_o_lantern
fill 332 238 442 332 249 442 minecraft:red_concrete
setblock 332 238 443 minecraft:jack_o_lantern
fill 332 238 444 332 249 444 minecraft:red_concrete
setblock 332 238 445 minecraft:jack_o_lantern
fill 332 238 446 332 249 446 minecraft:red_concrete
setblock 332 238 447 minecraft:jack_o_lantern
fill 333 238 439 333 249 439 minecraft:red_concrete
setblock 333 238 440 minecraft:jack_o_lantern
fill 333 238 441 333 249 441 minecraft:red_concrete
setblock 333 238 442 minecraft:jack_o_lantern
fill 333 238 443 333 249 443 minecraft:red_concrete
setblock 333 238 444 minecraft:jack_o_lantern
fill 333 238 445 333 249 445 minecraft:red_concrete
setblock 333 238 446 minecraft:jack_o_lantern
fill 333 238 447 333 249 447 minecraft:red_concrete
setblock 334 238 439 minecraft:jack_o_lantern
fill 334 238 440 334 249 440 minecraft:red_concrete
setblock 334 238 441 minecraft:jack_o_lantern
fill 334 238 442 334 249 442 minecraft:red_concrete
setblock 334 238 443 minecraft:jack_o_lantern
fill 334 238 444 334 249 444 minecraft:red_concrete
setblock 334 238 445 minecraft:jack_o_lantern
fill 334 238 446 334 249 446 minecraft:red_concrete
setblock 334 238 447 minecraft:jack_o_lantern
fill 335 238 439 335 249 439 minecraft:red_concrete
setblock 335 238 440 minecraft:jack_o_lantern
fill 335 238 441 335 249 441 minecraft:red_concrete
setblock 335 238 442 minecraft:jack_o_lantern
fill 335 238 443 335 249 443 minecraft:red_concrete
setblock 335 238 444 minecraft:jack_o_lantern
fill 335 238 445 335 249 445 minecraft:red_concrete
setblock 335 238 446 minecraft:jack_o_lantern
fill 335 238 447 335 249 447 minecraft:red_concrete
setblock 336 238 439 minecraft:jack_o_lantern
fill 336 238 440 336 249 440 minecraft:red_concrete
setblock 336 238 441 minecraft:jack_o_lantern
fill 336 238 442 336 249 442 minecraft:red_concrete
setblock 336 238 443 minecraft:jack_o_lantern
fill 336 238 444 336 249 444 minecraft:red_concrete
setblock 336 238 445 minecraft:jack_o_lantern
fill 336 238 446 336 249 446 minecraft:red_concrete
setblock 336 238 447 minecraft:jack_o_lantern
fill 337 238 439 337 249 439 minecraft:red_concrete
setblock 337 238 440 minecraft:jack_o_lantern
fill 337 238 441 337 249 441 minecraft:red_concrete
setblock 337 238 442 minecraft:jack_o_lantern
fill 337 238 443 337 249 443 minecraft:red_concrete
setblock 337 238 444 minecraft:jack_o_lantern
fill 337 238 445 337 249 445 minecraft:red_concrete
setblock 337 238 446 minecraft:jack_o_lantern
fill 337 238 447 337 249 447 minecraft:red_concrete
fill 337 238 457 337 273 457 minecraft:red_concrete
setblock 338 238 439 minecraft:jack_o_lantern
fill 338 238 440 338 249 440 minecraft:red_concrete
setblock 338 238 441 minecraft:jack_o_lantern
fill 338 238 442 338 249 442 minecraft:red_concrete
setblock 338 238 443 minecraft:jack_o_lantern
fill 338 238 444 338 249 444 minecraft:red_concrete
setblock 338 238 445 minecraft:jack_o_lantern
fill 338 238 446 338 249 446 minecraft:red_concrete
setblock 338 238 447 minecraft:jack_o_lantern
fill 339 238 417 339 273 417 minecraft:red_concrete
fill 344 238 457 344 273 457 minecraft:red_concrete
fill 346 238 417 346 273 417 minecraft:red_concrete
fill 351 238 457 351 273 457 minecraft:red_concrete
fill 353 238 417 353 273 417 minecraft:red_concrete
fill 360 238 417 360 273 417 minecraft:red_concrete
fill 367 238 417 367 273 417 minecraft:red_concrete
fill 370 238 421 370 273 421 minecraft:red_concrete
fill 370 238 428 370 273 428 minecraft:red_concrete
fill 370 238 435 370 273 435 minecraft:red_concrete
fill 370 238 442 370 273 442 minecraft:red_concrete
fill 370 238 449 370 273 449 minecraft:red_concrete
fill 330 239 423 330 240 423 minecraft:red_concrete
fill 330 239 430 330 240 430 minecraft:red_concrete
fill 330 239 437 330 240 437 minecraft:red_concrete
fill 330 239 439 330 240 439 minecraft:red_concrete
fill 330 239 441 330 240 441 minecraft:red_concrete
fill 330 239 443 330 240 443 minecraft:red_concrete
fill 330 239 445 330 240 445 minecraft:red_concrete
fill 330 239 447 330 240 447 minecraft:red_concrete
fill 330 239 451 330 240 451 minecraft:red_concrete
fill 331 239 417 331 240 417 minecraft:red_concrete
fill 331 239 440 331 240 440 minecraft:red_concrete
fill 331 239 442 331 240 442 minecraft:red_concrete
fill 331 239 444 331 240 444 minecraft:red_concrete
fill 331 239 446 331 240 446 minecraft:red_concrete
fill 331 239 457 331 240 457 minecraft:red_concrete
fill 332 239 439 332 240 439 minecraft:red_concrete
fill 332 239 441 332 240 441 minecraft:red_concrete
fill 332 239 443 332 240 443 minecraft:red_concrete
fill 332 239 445 332 240 445 minecraft:red_concrete
fill 332 239 447 332 240 447 minecraft:red_concrete
fill 333 239 440 333 240 440 minecraft:red_concrete
fill 333 239 442 333 240 442 minecraft:red_concrete
fill 333 239 444 333 240 444 minecraft:red_concrete
fill 333 239 446 333 240 446 minecraft:red_concrete
fill 334 239 439 334 240 439 minecraft:red_concrete
fill 334 239 441 334 240 441 minecraft:red_concrete
fill 334 239 443 334 240 443 minecraft:red_concrete
fill 334 239 445 334 240 445 minecraft:red_concrete
fill 334 239 447 334 240 447 minecraft:red_concrete
fill 335 239 440 335 240 440 minecraft:red_concrete
fill 335 239 442 335 240 442 minecraft:red_concrete
fill 335 239 444 335 240 444 minecraft:red_concrete
fill 335 239 446 335 240 446 minecraft:red_concrete
fill 336 239 439 336 240 439 minecraft:red_concrete
fill 336 239 441 336 240 441 minecraft:red_concrete
fill 336 239 443 336 240 443 minecraft:red_concrete
fill 336 239 445 336 240 445 minecraft:red_concrete
fill 336 239 447 336 240 447 minecraft:red_concrete
fill 337 239 440 337 240 440 minecraft:red_concrete
fill 337 239 442 337 240 442 minecraft:red_concrete
fill 337 239 444 337 240 444 minecraft:red_concrete
fill 337 239 446 337 240 446 minecraft:red_concrete
fill 338 239 417 338 240 417 minecraft:red_concrete
fill 338 239 439 338 240 439 minecraft:red_concrete
fill 338 239 441 338 240 441 minecraft:red_concrete
fill 338 239 443 338 240 443 minecraft:red_concrete
fill 338 239 445 338 240 445 minecraft:red_concrete
fill 338 239 447 338 240 447 minecraft:red_concrete
fill 338 239 457 338 240 457 minecraft:red_concrete
fill 345 239 417 345 240 417 minecraft:red_concrete
fill 345 239 457 345 240 457 minecraft:red_concrete
fill 352 239 417 352 240 417 minecraft:red_concrete
fill 352 239 457 352 240 457 minecraft:red_concrete
fill 359 239 417 359 240 417 minecraft:red_concrete
fill 366 239 417 366 240 417 minecraft:red_concrete
fill 370 239 420 370 240 420 minecraft:red_concrete
fill 370 239 427 370 240 427 minecraft:red_concrete
fill 370 239 434 370 240 434 minecraft:red_concrete
fill 370 239 441 370 240 441 minecraft:red_concrete
fill 370 239 448 370 240 448 minecraft:red_concrete
fill 370 239 455 370 240 455 minecraft:red_concrete
fill 330 240 417 330 240 421 minecraft:red_concrete
fill 330 240 424 330 240 428 minecraft:red_concrete
fill 330 240 431 330 240 435 minecraft:red_concrete
setblock 330 240 438 minecraft:red_concrete
fill 330 240 448 330 240 449 minecraft:red_concrete
fill 330 240 452 330 240 456 minecraft:red_concrete
setblock 332 240 419 minecraft:light[level=12]
setblock 332 240 427 minecraft:light[level=12]
setblock 332 240 435 minecraft:light[level=12]
setblock 332 240 451 minecraft:light[level=12]
fill 332 240 457 336 240 457 minecraft:red_concrete
fill 333 240 417 337 240 417 minecraft:red_concrete
fill 339 240 457 343 240 457 minecraft:red_concrete
fill 340 240 417 344 240 417 minecraft:red_concrete
setblock 340 240 419 minecraft:light[level=12]
setblock 340 240 427 minecraft:light[level=12]
setblock 340 240 435 minecraft:light[level=12]
setblock 340 240 443 minecraft:light[level=12]
setblock 340 240 451 minecraft:light[level=12]
fill 346 240 457 350 240 457 minecraft:red_concrete
fill 347 240 417 351 240 417 minecraft:red_concrete
setblock 348 240 419 minecraft:light[level=12]
setblock 348 240 427 minecraft:light[level=12]
setblock 348 240 435 minecraft:light[level=12]
setblock 348 240 443 minecraft:light[level=12]
setblock 348 240 451 minecraft:light[level=12]
fill 353 240 457 356 240 457 minecraft:red_concrete
fill 354 240 417 358 240 417 minecraft:red_concrete
setblock 356 240 419 minecraft:light[level=12]
setblock 356 240 427 minecraft:light[level=12]
setblock 356 240 435 minecraft:light[level=12]
setblock 356 240 443 minecraft:light[level=12]
setblock 356 240 451 minecraft:light[level=12]
fill 361 240 417 365 240 417 minecraft:red_concrete
setblock 364 240 419 minecraft:light[level=12]
setblock 364 240 427 minecraft:light[level=12]
setblock 364 240 435 minecraft:light[level=12]
setblock 364 240 443 minecraft:light[level=12]
fill 368 240 417 370 240 417 minecraft:red_concrete
fill 368 240 457 370 240 457 minecraft:red_concrete
fill 370 240 418 370 240 419 minecraft:red_concrete
fill 370 240 422 370 240 426 minecraft:red_concrete
fill 370 240 429 370 240 433 minecraft:red_concrete
fill 370 240 436 370 240 440 minecraft:red_concrete
fill 370 240 443 370 240 447 minecraft:red_concrete
fill 370 240 450 370 240 454 minecraft:red_concrete
setblock 330 241 418 minecraft:red_concrete
setblock 330 241 425 minecraft:red_concrete
setblock 330 241 432 minecraft:red_concrete
setblock 330 241 439 minecraft:jack_o_lantern
setblock 330 241 441 minecraft:jack_o_lantern
setblock 330 241 443 minecraft:jack_o_lantern
setblock 330 241 445 minecraft:jack_o_lantern
setblock 330 241 447 minecraft:jack_o_lantern
setblock 330 241 453 minecraft:red_concrete
setblock 331 241 440 minecraft:jack_o_lantern
setblock 331 241 442 minecraft:jack_o_lantern
setblock 331 241 444 minecraft:jack_o_lantern
setblock 331 241 446 minecraft:jack_o_lantern
setblock 332 241 439 minecraft:jack_o_lantern
setblock 332 241 441 minecraft:jack_o_lantern
setblock 332 241 443 minecraft:jack_o_lantern
setblock 332 241 445 minecraft:jack_o_lantern
setblock 332 241 447 minecraft:jack_o_lantern
setblock 333 241 440 minecraft:jack_o_lantern
setblock 333 241 442 minecraft:jack_o_lantern
setblock 333 241 444 minecraft:jack_o_lantern
setblock 333 241 446 minecraft:jack_o_lantern
setblock 333 241 457 minecraft:red_concrete
setblock 334 241 439 minecraft:jack_o_lantern
setblock 334 241 441 minecraft:jack_o_lantern
setblock 334 241 443 minecraft:jack_o_lantern
setblock 334 241 445 minecraft:jack_o_lantern
setblock 334 241 447 minecraft:jack_o_lantern
setblock 335 241 440 minecraft:jack_o_lantern
setblock 335 241 442 minecraft:jack_o_lantern
setblock 335 241 444 minecraft:jack_o_lantern
setblock 335 241 446 minecraft:jack_o_lantern
setblock 336 241 417 minecraft:red_concrete
setblock 336 241 439 minecraft:jack_o_lantern
setblock 336 241 441 minecraft:jack_o_lantern
setblock 336 241 443 minecraft:jack_o_lantern
setblock 336 241 445 minecraft:jack_o_lantern
setblock 336 241 447 minecraft:jack_o_lantern
setblock 337 241 440 minecraft:jack_o_lantern
setblock 337 241 442 minecraft:jack_o_lantern
setblock 337 241 444 minecraft:jack_o_lantern
setblock 337 241 446 minecraft:jack_o_lantern
setblock 338 241 439 minecraft:jack_o_lantern
setblock 338 241 441 minecraft:jack_o_lantern
setblock 338 241 443 minecraft:jack_o_lantern
setblock 338 241 445 minecraft:jack_o_lantern
setblock 338 241 447 minecraft:jack_o_lantern
setblock 340 241 457 minecraft:red_concrete
setblock 343 241 417 minecraft:red_concrete
setblock 347 241 457 minecraft:red_concrete
setblock 350 241 417 minecraft:red_concrete
setblock 354 241 457 minecraft:red_concrete
setblock 357 241 417 minecraft:red_concrete
setblock 364 241 417 minecraft:red_concrete
setblock 368 241 457 minecraft:red_concrete
setblock 370 241 418 minecraft:red_concrete
setblock 370 241 425 minecraft:red_concrete
setblock 370 241 432 minecraft:red_concrete
setblock 370 241 439 minecraft:red_concrete
setblock 370 241 446 minecraft:red_concrete
setblock 370 241 453 minecraft:red_concrete
setblock 330 242 419 minecraft:red_concrete
setblock 330 242 426 minecraft:red_concrete
setblock 330 242 433 minecraft:red_concrete
fill 330 242 439 330 243 439 minecraft:red_concrete
fill 330 242 441 330 243 441 minecraft:red_concrete
fill 330 242 443 330 243 443 minecraft:red_concrete
fill 330 242 445 330 243 445 minecraft:red_concrete
fill 330 242 447 330 243 447 minecraft:red_concrete
setblock 330 242 454 minecraft:red_concrete
fill 331 242 440 331 243 440 minecraft:red_concrete
fill 331 242 442 331 243 442 minecraft:red_concrete
fill 331 242 444 331 243 444 minecraft:red_concrete
fill 331 242 446 331 243 446 minecraft:red_concrete
fill 332 242 439 332 243 439 minecraft:red_concrete
fill 332 242 441 332 243 441 minecraft:red_concrete
fill 332 242 443 332 243 443 minecraft:red_concrete
fill 332 242 445 332 243 445 minecraft:red_concrete
fill 332 242 447 332 243 447 minecraft:red_concrete
fill 333 242 440 333 243 440 minecraft:red_concrete
fill 333 242 442 333 243 442 minecraft:red_concrete
fill 333 242 444 333 243 444 minecraft:red_concrete
fill 333 242 446 333 243 446 minecraft:red_concrete
fill 334 242 439 334 243 439 minecraft:red_concrete
fill 334 242 441 334 243 441 minecraft:red_concrete
fill 334 242 443 334 243 443 minecraft:red_concrete
fill 334 242 445 334 243 445 minecraft:red_concrete
fill 334 242 447 334 243 447 minecraft:red_concrete
setblock 334 242 457 minecraft:red_concrete
setblock 335 242 417 minecraft:red_concrete
fill 335 242 440 335 243 440 minecraft:red_concrete
fill 335 242 442 335 243 442 minecraft:red_concrete
fill 335 242 444 335 243 444 minecraft:red_concrete
fill 335 242 446 335 243 446 minecraft:red_concrete
fill 336 242 439 336 243 439 minecraft:red_concrete
fill 336 242 441 336 243 441 minecraft:red_concrete
fill 336 242 443 336 243 443 minecraft:red_concrete
fill 336 242 445 336 243 445 minecraft:red_concrete
fill 336 242 447 336 243 447 minecraft:red_concrete
fill 337 242 440 337 243 440 minecraft:red_concrete
fill 337 242 442 337 243 442 minecraft:red_concrete
fill 337 242 444 337 243 444 minecraft:red_concrete
fill 337 242 446 337 243 446 minecraft:red_concrete
fill 338 242 439 338 243 439 minecraft:red_concrete
fill 338 242 441 338 243 441 minecraft:red_concrete
fill 338 242 443 338 243 443 minecraft:red_concrete
fill 338 242 445 338 243 445 minecraft:red_concrete
fill 338 242 447 338 243 447 minecraft:red_concrete
setblock 341 242 457 minecraft:red_concrete
setblock 342 242 417 minecraft:red_concrete
setblock 348 242 457 minecraft:red_concrete
setblock 349 242 417 minecraft:red_concrete
setblock 355 242 457 minecraft:red_concrete
setblock 356 242 417 minecraft:red_concrete
setblock 363 242 417 minecraft:red_concrete
setblock 369 242 457 minecraft:red_concrete
setblock 370 242 417 minecraft:red_concrete
setblock 370 242 424 minecraft:red_concrete
setblock 370 242 431 minecraft:red_concrete
setblock 370 242 438 minecraft:red_concrete
setblock 370 242 445 minecraft:red_concrete
setblock 370 242 452 minecraft:red_concrete
setblock 330 243 420 minecraft:red_concrete
setblock 330 243 427 minecraft:red_concrete
setblock 330 243 434 minecraft:red_concrete
setblock 330 243 448 minecraft:red_concrete
setblock 330 243 455 minecraft:red_concrete
setblock 334 243 417 minecraft:red_concrete
setblock 335 243 457 minecraft:red_concrete
setblock 341 243 417 minecraft:red_concrete
setblock 342 243 457 minecraft:red_concrete
setblock 348 243 417 minecraft:red_concrete
setblock 349 243 457 minecraft:red_concrete
setblock 355 243 417 minecraft:red_concrete
setblock 356 243 457 minecraft:red_concrete
setblock 362 243 417 minecraft:red_concrete
setblock 369 243 417 minecraft:red_concrete
setblock 370 243 423 minecraft:red_concrete
setblock 370 243 430 minecraft:red_concrete
setblock 370 243 437 minecraft:red_concrete
setblock 370 243 444 minecraft:red_concrete
setblock 370 243 451 minecraft:red_concrete
setblock 370 243 457 minecraft:red_concrete
setblock 330 244 421 minecraft:red_concrete
setblock 330 244 428 minecraft:red_concrete
setblock 330 244 435 minecraft:red_concrete
setblock 330 244 439 minecraft:jack_o_lantern
setblock 330 244 441 minecraft:jack_o_lantern
setblock 330 244 443 minecraft:jack_o_lantern
setblock 330 244 445 minecraft:jack_o_lantern
setblock 330 244 447 minecraft:jack_o_lantern
setblock 330 244 449 minecraft:red_concrete
setblock 330 244 456 minecraft:red_concrete
setblock 331 244 440 minecraft:jack_o_lantern
setblock 331 244 442 minecraft:jack_o_lantern
setblock 331 244 444 minecraft:jack_o_lantern
setblock 331 244 446 minecraft:jack_o_lantern
setblock 332 244 439 minecraft:jack_o_lantern
setblock 332 244 441 minecraft:jack_o_lantern
setblock 332 244 443 minecraft:jack_o_lantern
setblock 332 244 445 minecraft:jack_o_lantern
setblock 332 244 447 minecraft:jack_o_lantern
setblock 333 244 417 minecraft:red_concrete
setblock 333 244 440 minecraft:jack_o_lantern
setblock 333 244 442 minecraft:jack_o_lantern
setblock 333 244 444 minecraft:jack_o_lantern
setblock 333 244 446 minecraft:jack_o_lantern
setblock 334 244 439 minecraft:jack_o_lantern
setblock 334 244 441 minecraft:jack_o_lantern
setblock 334 244 443 minecraft:jack_o_lantern
setblock 334 244 445 minecraft:jack_o_lantern
setblock 334 244 447 minecraft:jack_o_lantern
setblock 335 244 440 minecraft:jack_o_lantern
setblock 335 244 442 minecraft:jack_o_lantern
setblock 335 244 444 minecraft:jack_o_lantern
setblock 335 244 446 minecraft:jack_o_lantern
setblock 336 244 439 minecraft:jack_o_lantern
setblock 336 244 441 minecraft:jack_o_lantern
setblock 336 244 443 minecraft:jack_o_lantern
setblock 336 244 445 minecraft:jack_o_lantern
setblock 336 244 447 minecraft:jack_o_lantern
setblock 336 244 457 minecraft:red_concrete
setblock 337 244 440 minecraft:jack_o_lantern
setblock 337 244 442 minecraft:jack_o_lantern
setblock 337 244 444 minecraft:jack_o_lantern
setblock 337 244 446 minecraft:jack_o_lantern
setblock 338 244 439 minecraft:jack_o_lantern
setblock 338 244 441 minecraft:jack_o_lantern
setblock 338 244 443 minecraft:jack_o_lantern
setblock 338 244 445 minecraft:jack_o_lantern
setblock 338 244 447 minecraft:jack_o_lantern
setblock 340 244 417 minecraft:red_concrete
setblock 343 244 457 minecraft:red_concrete
setblock 347 244 417 minecraft:red_concrete
setblock 350 244 457 minecraft:red_concrete
setblock 354 244 417 minecraft:red_concrete
setblock 361 244 417 minecraft:red_concrete
setblock 368 244 417 minecraft:red_concrete
setblock 370 244 422 minecraft:red_concrete
setblock 370 244 429 minecraft:red_concrete
setblock 370 244 436 minecraft:red_concrete
setblock 370 244 443 minecraft:red_concrete
setblock 370 244 450 minecraft:red_concrete
fill 330 245 439 330 246 439 minecraft:red_concrete
fill 330 245 441 330 246 441 minecraft:red_concrete
fill 330 245 443 330 246 443 minecraft:red_concrete
fill 330 245 445 330 246 445 minecraft:red_concrete
fill 330 245 447 330 246 447 minecraft:red_concrete
fill 331 245 440 331 246 440 minecraft:red_concrete
fill 331 245 442 331 246 442 minecraft:red_concrete
fill 331 245 444 331 246 444 minecraft:red_concrete
fill 331 245 446 331 246 446 minecraft:red_concrete
fill 332 245 439 332 246 439 minecraft:red_concrete
fill 332 245 441 332 246 441 minecraft:red_concrete
fill 332 245 443 332 246 443 minecraft:red_concrete
fill 332 245 445 332 246 445 minecraft:red_concrete
fill 332 245 447 332 246 447 minecraft:red_concrete
fill 333 245 440 333 246 440 minecraft:red_concrete
fill 333 245 442 333 246 442 minecraft:red_concrete
fill 333 245 444 333 246 444 minecraft:red_concrete
fill 333 245 446 333 246 446 minecraft:red_concrete
fill 334 245 439 334 246 439 minecraft:red_concrete
fill 334 245 441 334 246 441 minecraft:red_concrete
fill 334 245 443 334 246 443 minecraft:red_concrete
fill 334 245 445 334 246 445 minecraft:red_concrete
fill 334 245 447 334 246 447 minecraft:red_concrete
fill 335 245 440 335 246 440 minecraft:red_concrete
fill 335 245 442 335 246 442 minecraft:red_concrete
fill 335 245 444 335 246 444 minecraft:red_concrete
fill 335 245 446 335 246 446 minecraft:red_concrete
fill 336 245 439 336 246 439 minecraft:red_concrete
fill 336 245 441 336 246 441 minecraft:red_concrete
fill 336 245 443 336 246 443 minecraft:red_concrete
fill 336 245 445 336 246 445 minecraft:red_concrete
fill 336 245 447 336 246 447 minecraft:red_concrete
fill 337 245 440 337 246 440 minecraft:red_concrete
fill 337 245 442 337 246 442 minecraft:red_concrete
fill 337 245 444 337 246 444 minecraft:red_concrete
fill 337 245 446 337 246 446 minecraft:red_concrete
fill 338 245 439 338 246 439 minecraft:red_concrete
fill 338 245 441 338 246 441 minecraft:red_concrete
fill 338 245 443 338 246 443 minecraft:red_concrete
fill 338 245 445 338 246 445 minecraft:red_concrete
fill 338 245 447 338 246 447 minecraft:red_concrete
setblock 330 246 423 minecraft:red_concrete
setblock 330 246 430 minecraft:red_concrete
setblock 330 246 437 minecraft:red_concrete
setblock 330 246 451 minecraft:red_concrete
setblock 331 246 417 minecraft:red_concrete
setblock 331 246 457 minecraft:red_concrete
setblock 338 246 417 minecraft:red_concrete
setblock 338 246 457 minecraft:red_concrete
setblock 345 246 417 minecraft:red_concrete
setblock 345 246 457 minecraft:red_concrete
setblock 352 246 417 minecraft:red_concrete
setblock 352 246 457 minecraft:red_concrete
setblock 359 246 417 minecraft:red_concrete
setblock 366 246 417 minecraft:red_concrete
setblock 370 246 420 minecraft:red_concrete
setblock 370 246 427 minecraft:red_concrete
setblock 370 246 434 minecraft:red_concrete
setblock 370 246 441 minecraft:red_concrete
setblock 370 246 448 minecraft:red_concrete
setblock 370 246 455 minecraft:red_concrete
setblock 330 247 417 minecraft:red_concrete
setblock 330 247 424 minecraft:red_concrete
setblock 330 247 431 minecraft:red_concrete
setblock 330 247 438 minecraft:red_concrete
setblock 330 247 439 minecraft:jack_o_lantern
setblock 330 247 441 minecraft:jack_o_lantern
setblock 330 247 443 minecraft:jack_o_lantern
setblock 330 247 445 minecraft:jack_o_lantern
setblock 330 247 447 minecraft:jack_o_lantern
setblock 330 247 452 minecraft:red_concrete
setblock 331 247 440 minecraft:jack_o_lantern
setblock 331 247 442 minecraft:jack_o_lantern
setblock 331 247 444 minecraft:jack_o_lantern
setblock 331 247 446 minecraft:jack_o_lantern
setblock 332 247 439 minecraft:jack_o_lantern
setblock 332 247 441 minecraft:jack_o_lantern
setblock 332 247 443 minecraft:jack_o_lantern
setblock 332 247 445 minecraft:jack_o_lantern
setblock 332 247 447 minecraft:jack_o_lantern
setblock 332 247 457 minecraft:red_concrete
setblock 333 247 440 minecraft:jack_o_lantern
setblock 333 247 442 minecraft:jack_o_lantern
setblock 333 247 444 minecraft:jack_o_lantern
setblock 333 247 446 minecraft:jack_o_lantern
setblock 334 247 439 minecraft:jack_o_lantern
setblock 334 247 441 minecraft:jack_o_lantern
setblock 334 247 443 minecraft:jack_o_lantern
setblock 334 247 445 minecraft:jack_o_lantern
setblock 334 247 447 minecraft:jack_o_lantern
setblock 335 247 440 minecraft:jack_o_lantern
setblock 335 247 442 minecraft:jack_o_lantern
setblock 335 247 444 minecraft:jack_o_lantern
setblock 335 247 446 minecraft:jack_o_lantern
setblock 336 247 439 minecraft:jack_o_lantern
setblock 336 247 441 minecraft:jack_o_lantern
setblock 336 247 443 minecraft:jack_o_lantern
setblock 336 247 445 minecraft:jack_o_lantern
setblock 336 247 447 minecraft:jack_o_lantern
setblock 337 247 417 minecraft:red_concrete
setblock 337 247 440 minecraft:jack_o_lantern
setblock 337 247 442 minecraft:jack_o_lantern
setblock 337 247 444 minecraft:jack_o_lantern
setblock 337 247 446 minecraft:jack_o_lantern
setblock 338 247 439 minecraft:jack_o_lantern
setblock 338 247 441 minecraft:jack_o_lantern
setblock 338 247 443 minecraft:jack_o_lantern
setblock 338 247 445 minecraft:jack_o_lantern
setblock 338 247 447 minecraft:jack_o_lantern
setblock 339 247 457 minecraft:red_concrete
setblock 344 247 417 minecraft:red_concrete
setblock 346 247 457 minecraft:red_concrete
setblock 351 247 417 minecraft:red_concrete
setblock 353 247 457 minecraft:red_concrete
setblock 358 247 417 minecraft:red_concrete
setblock 365 247 417 minecraft:red_concrete
setblock 370 247 419 minecraft:red_concrete
setblock 370 247 426 minecraft:red_concrete
setblock 370 247 433 minecraft:red_concrete
setblock 370 247 440 minecraft:red_concrete
setblock 370 247 447 minecraft:red_concrete
setblock 370 247 454 minecraft:red_concrete
setblock 330 248 418 minecraft:red_concrete
setblock 330 248 425 minecraft:red_concrete
setblock 330 248 432 minecraft:red_concrete
fill 330 248 439 330 250 439 minecraft:red_concrete
fill 330 248 441 330 250 441 minecraft:red_concrete
fill 330 248 443 330 273 443 minecraft:red_concrete
fill 330 248 445 330 250 445 minecraft:red_concrete
fill 330 248 447 330 250 447 minecraft:red_concrete
setblock 330 248 453 minecraft:red_concrete
fill 331 248 440 331 249 440 minecraft:red_concrete
fill 331 248 442 331 249 442 minecraft:red_concrete
fill 331 248 444 331 249 444 minecraft:red_concrete
fill 331 248 446 331 249 446 minecraft:red_concrete
setblock 332 248 419 minecraft:light[level=12]
setblock 332 248 427 minecraft:light[level=12]
setblock 332 248 435 minecraft:light[level=12]
fill 332 248 439 332 249 439 minecraft:red_concrete
fill 332 248 441 332 249 441 minecraft:red_concrete
fill 332 248 443 332 249 443 minecraft:red_concrete
fill 332 248 445 332 249 445 minecraft:red_concrete
fill 332 248 447 332 249 447 minecraft:red_concrete
setblock 332 248 451 minecraft:light[level=12]
fill 333 248 440 333 249 440 minecraft:red_concrete
fill 333 248 442 333 249 442 minecraft:red_concrete
fill 333 248 444 333 249 444 minecraft:red_concrete
fill 333 248 446 333 249 446 minecraft:red_concrete
setblock 333 248 457 minecraft:red_concrete
fill 334 248 439 334 249 439 minecraft:red_concrete
fill 334 248 441 334 249 441 minecraft:red_concrete
fill 334 248 443 334 249 443 minecraft:red_concrete
fill 334 248 445 334 249 445 minecraft:red_concrete
fill 334 248 447 334 249 447 minecraft:red_concrete
fill 335 248 440 335 249 440 minecraft:red_concrete
fill 335 248 442 335 249 442 minecraft:red_concrete
fill 335 248 444 335 249 444 minecraft:red_concrete
fill 335 248 446 335 249 446 minecraft:red_concrete
setblock 336 248 417 minecraft:red_concrete
fill 336 248 439 336 249 439 minecraft:red_concrete
fill 336 248 441 336 249 441 minecraft:red_concrete
fill 336 248 443 336 249 443 minecraft:red_concrete
fill 336 248 445 336 249 445 minecraft:red_concrete
fill 336 248 447 336 249 447 minecraft:red_concrete
fill 337 248 440 337 249 440 minecraft:red_concrete
fill 337 248 442 337 249 442 minecraft:red_concrete
fill 337 248 444 337 249 444 minecraft:red_concrete
fill 337 248 446 337 249 446 minecraft:red_concrete
fill 338 248 439 338 249 439 minecraft:red_concrete
fill 338 248 441 338 249 441 minecraft:red_concrete
fill 338 248 443 338 249 443 minecraft:red_concrete
fill 338 248 445 338 249 445 minecraft:red_concrete
fill 338 248 447 338 249 447 minecraft:red_concrete
setblock 340 248 419 minecraft:light[level=12]
setblock 340 248 427 minecraft:light[level=12]
setblock 340 248 435 minecraft:light[level=12]
setblock 340 248 443 minecraft:light[level=12]
setblock 340 248 451 minecraft:light[level=12]
setblock 340 248 457 minecraft:red_concrete
setblock 343 248 417 minecraft:red_concrete
setblock 347 248 457 minecraft:red_concrete
setblock 348 248 419 minecraft:light[level=12]
setblock 348 248 427 minecraft:light[level=12]
setblock 348 248 435 minecraft:light[level=12]
setblock 348 248 443 minecraft:light[level=12]
setblock 348 248 451 minecraft:light[level=12]
setblock 350 248 417 minecraft:red_concrete
setblock 354 248 457 minecraft:red_concrete
setblock 356 248 419 minecraft:light[level=12]
setblock 356 248 427 minecraft:light[level=12]
setblock 356 248 435 minecraft:light[level=12]
setblock 356 248 443 minecraft:light[level=12]
setblock 356 248 451 minecraft:light[level=12]
setblock 357 248 417 minecraft:red_concrete
setblock 364 248 417 minecraft:red_concrete
setblock 364 248 419 minecraft:light[level=12]
setblock 364 248 427 minecraft:light[level=12]
setblock 364 248 435 minecraft:light[level=12]
setblock 364 248 443 minecraft:light[level=12]
setblock 368 248 457 minecraft:red_concrete
setblock 370 248 418 minecraft:red_concrete
setblock 370 248 425 minecraft:red_concrete
setblock 370 248 432 minecraft:red_concrete
setblock 370 248 439 minecraft:red_concrete
setblock 370 248 446 minecraft:red_concrete
setblock 370 248 453 minecraft:red_concrete
fill 330 249 419 330 250 419 minecraft:red_concrete
fill 330 249 426 330 250 426 minecraft:red_concrete
fill 330 249 433 330 250 433 minecraft:red_concrete
fill 330 249 454 330 250 454 minecraft:red_concrete
fill 334 249 457 334 250 457 minecraft:red_concrete
fill 335 249 417 335 250 417 minecraft:red_concrete
fill 341 249 457 341 250 457 minecraft:red_concrete
fill 342 249 417 342 250 417 minecraft:red_concrete
fill 348 249 457 348 250 457 minecraft:red_concrete
fill 349 249 417 349 250 417 minecraft:red_concrete
fill 355 249 457 355 250 457 minecraft:red_concrete
fill 356 249 417 356 250 417 minecraft:red_concrete
fill 363 249 417 363 250 417 minecraft:red_concrete
fill 369 249 457 369 250 457 minecraft:red_concrete
fill 370 249 417 370 250 417 minecraft:red_concrete
fill 370 249 424 370 250 424 minecraft:red_concrete
fill 370 249 431 370 250 431 minecraft:red_concrete
fill 370 249 438 370 250 438 minecraft:red_concrete
fill 370 249 445 370 250 445 minecraft:red_concrete
fill 370 249 452 370 250 452 minecraft:red_concrete
fill 330 250 417 330 250 418 minecraft:red_concrete
fill 330 250 420 330 250 421 minecraft:red_concrete
fill 330 250 423 330 250 425 minecraft:red_concrete
fill 330 250 427 330 250 428 minecraft:red_concrete
fill 330 250 430 330 250 432 minecraft:red_concrete
fill 330 250 434 330 250 435 minecraft:red_concrete
fill 330 250 437 330 250 438 minecraft:red_concrete
fill 330 250 448 330 250 449 minecraft:red_concrete
fill 330 250 451 330 250 453 minecraft:red_concrete
fill 330 250 455 330 250 456 minecraft:red_concrete
setblock 331 250 417 minecraft:red_concrete
fill 331 250 440 337 250 446 minecraft:white_concrete
fill 331 250 457 333 250 457 minecraft:red_concrete
fill 333 250 417 334 250 417 minecraft:red_concrete
fill 335 250 457 336 250 457 minecraft:red_concrete
fill 336 250 417 338 250 417 minecraft:red_concrete
fill 338 250 457 340 250 457 minecraft:red_concrete
fill 340 250 417 341 250 417 minecraft:red_concrete
fill 342 250 457 343 250 457 minecraft:red_concrete
fill 343 250 417 345 250 417 minecraft:red_concrete
fill 345 250 457 347 250 457 minecraft:red_concrete
fill 347 250 417 348 250 417 minecraft:red_concrete
fill 349 250 457 350 250 457 minecraft:red_concrete
fill 350 250 417 352 250 417 minecraft:red_concrete
fill 352 250 457 354 250 457 minecraft:red_concrete
fill 354 250 417 355 250 417 minecraft:red_concrete
setblock 356 250 457 minecraft:red_concrete
fill 357 250 417 359 250 417 minecraft:red_concrete
fill 361 250 417 362 250 417 minecraft:red_concrete
fill 364 250 417 366 250 417 minecraft:red_concrete
fill 368 250 417 369 250 417 minecraft:red_concrete
setblock 368 250 457 minecraft:red_concrete
fill 370 250 418 370 250 420 minecraft:red_concrete
fill 370 250 422 370 250 423 minecraft:red_concrete
fill 370 250 425 370 250 427 minecraft:red_concrete
fill 370 250 429 370 250 430 minecraft:red_concrete
fill 370 250 432 370 250 434 minecraft:red_concrete
fill 370 250 436 370 250 437 minecraft:red_concrete
fill 370 250 439 370 250 441 minecraft:red_concrete
fill 370 250 443 370 250 444 minecraft:red_concrete
fill 370 250 446 370 250 448 minecraft:red_concrete
fill 370 250 450 370 250 451 minecraft:red_concrete
fill 370 250 453 370 250 455 minecraft:red_concrete
setblock 370 250 457 minecraft:red_concrete
setblock 330 251 421 minecraft:red_concrete
setblock 330 251 428 minecraft:red_concrete
setblock 330 251 435 minecraft:red_concrete
setblock 330 251 449 minecraft:red_concrete
setblock 330 251 456 minecraft:red_concrete
fill 332 251 441 336 251 445 minecraft:white_concrete
setblock 333 251 417 minecraft:red_concrete
setblock 336 251 457 minecraft:red_concrete
fill 337 251 448 338 252 450 minecraft:white_wool
setblock 340 251 417 minecraft:red_concrete
setblock 343 251 457 minecraft:red_concrete
setblock 347 251 417 minecraft:red_concrete
setblock 350 251 457 minecraft:red_concrete
setblock 354 251 417 minecraft:red_concrete
setblock 361 251 417 minecraft:red_concrete
setblock 368 251 417 minecraft:red_concrete
setblock 370 251 422 minecraft:red_concrete
setblock 370 251 429 minecraft:red_concrete
setblock 370 251 436 minecraft:red_concrete
setblock 370 251 443 minecraft:red_concrete
setblock 370 251 450 minecraft:red_concrete
fill 333 252 442 335 252 444 minecraft:white_concrete
setblock 330 253 423 minecraft:red_concrete
setblock 330 253 430 minecraft:red_concrete
setblock 330 253 437 minecraft:red_concrete
setblock 330 253 444 minecraft:red_concrete
setblock 330 253 451 minecraft:red_concrete
setblock 331 253 417 minecraft:red_concrete
setblock 331 253 457 minecraft:red_concrete
setblock 334 253 443 minecraft:white_concrete
setblock 338 253 417 minecraft:red_concrete
setblock 338 253 457 minecraft:red_concrete
setblock 345 253 417 minecraft:red_concrete
setblock 345 253 457 minecraft:red_concrete
setblock 352 253 417 minecraft:red_concrete
setblock 352 253 457 minecraft:red_concrete
setblock 359 253 417 minecraft:red_concrete
setblock 366 253 417 minecraft:red_concrete
setblock 370 253 420 minecraft:red_concrete
setblock 370 253 427 minecraft:red_concrete
setblock 370 253 434 minecraft:red_concrete
setblock 370 253 441 minecraft:red_concrete
setblock 370 253 448 minecraft:red_concrete
setblock 370 253 455 minecraft:red_concrete
setblock 330 254 417 minecraft:red_concrete
setblock 330 254 424 minecraft:red_concrete
setblock 330 254 431 minecraft:red_concrete
setblock 330 254 438 minecraft:red_concrete
setblock 330 254 445 minecraft:red_concrete
setblock 330 254 452 minecraft:red_concrete
setblock 332 254 457 minecraft:red_concrete
setblock 337 254 417 minecraft:red_concrete
setblock 339 254 457 minecraft:red_concrete
setblock 344 254 417 minecraft:red_concrete
setblock 346 254 457 minecraft:red_concrete
setblock 351 254 417 minecraft:red_concrete
setblock 353 254 457 minecraft:red_concrete
setblock 358 254 417 minecraft:red_concrete
setblock 365 254 417 minecraft:red_concrete
setblock 370 254 419 minecraft:red_concrete
setblock 370 254 426 minecraft:red_concrete
setblock 370 254 433 minecraft:red_concrete
setblock 370 254 440 minecraft:red_concrete
setblock 370 254 447 minecraft:red_concrete
setblock 370 254 454 minecraft:red_concrete
setblock 330 255 418 minecraft:red_concrete
setblock 330 255 425 minecraft:red_concrete
setblock 330 255 432 minecraft:red_concrete
setblock 330 255 439 minecraft:red_concrete
setblock 330 255 446 minecraft:red_concrete
setblock 330 255 453 minecraft:red_concrete
setblock 333 255 457 minecraft:red_concrete
setblock 336 255 417 minecraft:red_concrete
setblock 340 255 457 minecraft:red_concrete
setblock 343 255 417 minecraft:red_concrete
setblock 347 255 457 minecraft:red_concrete
setblock 350 255 417 minecraft:red_concrete
setblock 354 255 457 minecraft:red_concrete
setblock 357 255 417 minecraft:red_concrete
setblock 364 255 417 minecraft:red_concrete
setblock 368 255 457 minecraft:red_concrete
setblock 370 255 418 minecraft:red_concrete
setblock 370 255 425 minecraft:red_concrete
setblock 370 255 432 minecraft:red_concrete
setblock 370 255 439 minecraft:red_concrete
setblock 370 255 446 minecraft:red_concrete
setblock 370 255 453 minecraft:red_concrete
setblock 330 256 419 minecraft:red_concrete
setblock 330 256 426 minecraft:red_concrete
setblock 330 256 433 minecraft:red_concrete
setblock 330 256 440 minecraft:red_concrete
setblock 330 256 447 minecraft:red_concrete
setblock 330 256 454 minecraft:red_concrete
setblock 332 256 419 minecraft:light[level=12]
setblock 332 256 427 minecraft:light[level=12]
setblock 332 256 435 minecraft:light[level=12]
setblock 332 256 443 minecraft:light[level=12]
setblock 332 256 451 minecraft:light[level=12]
setblock 334 256 457 minecraft:red_concrete
setblock 335 256 417 minecraft:red_concrete
setblock 340 256 419 minecraft:light[level=12]
setblock 340 256 427 minecraft:light[level=12]
setblock 340 256 435 minecraft:light[level=12]
setblock 340 256 443 minecraft:light[level=12]
setblock 340 256 451 minecraft:light[level=12]
setblock 341 256 457 minecraft:red_concrete
setblock 342 256 417 minecraft:red_concrete
setblock 348 256 419 minecraft:light[level=12]
setblock 348 256 427 minecraft:light[level=12]
setblock 348 256 435 minecraft:light[level=12]
setblock 348 256 443 minecraft:light[level=12]
setblock 348 256 451 minecraft:light[level=12]
setblock 348 256 457 minecraft:red_concrete
setblock 349 256 417 minecraft:red_concrete
setblock 355 256 457 minecraft:red_concrete
setblock 356 256 417 minecraft:red_concrete
setblock 356 256 419 minecraft:light[level=12]
setblock 356 256 427 minecraft:light[level=12]
setblock 356 256 435 minecraft:light[level=12]
setblock 356 256 443 minecraft:light[level=12]
setblock 356 256 451 minecraft:light[level=12]
setblock 363 256 417 minecraft:red_concrete
setblock 364 256 419 minecraft:light[level=12]
setblock 364 256 427 minecraft:light[level=12]
setblock 364 256 435 minecraft:light[level=12]
setblock 364 256 443 minecraft:light[level=12]
setblock 369 256 457 minecraft:red_concrete
setblock 370 256 417 minecraft:red_concrete
setblock 370 256 424 minecraft:red_concrete
setblock 370 256 431 minecraft:red_concrete
setblock 370 256 438 minecraft:red_concrete
setblock 370 256 445 minecraft:red_concrete
setblock 370 256 452 minecraft:red_concrete
setblock 330 257 420 minecraft:red_concrete
setblock 330 257 427 minecraft:red_concrete
setblock 330 257 434 minecraft:red_concrete
setblock 330 257 441 minecraft:red_concrete
setblock 330 257 448 minecraft:red_concrete
setblock 330 257 455 minecraft:red_concrete
setblock 334 257 417 minecraft:red_concrete
setblock 335 257 457 minecraft:red_concrete
setblock 341 257 417 minecraft:red_concrete
setblock 342 257 457 minecraft:red_concrete
setblock 348 257 417 minecraft:red_concrete
setblock 349 257 457 minecraft:red_concrete
setblock 355 257 417 minecraft:red_concrete
setblock 356 257 457 minecraft:red_concrete
setblock 362 257 417 minecraft:red_concrete
setblock 369 257 417 minecraft:red_concrete
setblock 370 257 423 minecraft:red_concrete
setblock 370 257 430 minecraft:red_concrete
setblock 370 257 437 minecraft:red_concrete
setblock 370 257 444 minecraft:red_concrete
setblock 370 257 451 minecraft:red_concrete
setblock 370 257 457 minecraft:red_concrete
setblock 330 258 421 minecraft:red_concrete
setblock 330 258 428 minecraft:red_concrete
setblock 330 258 435 minecraft:red_concrete
setblock 330 258 442 minecraft:red_concrete
setblock 330 258 449 minecraft:red_concrete
setblock 330 258 456 minecraft:red_concrete
setblock 333 258 417 minecraft:red_concrete
setblock 336 258 457 minecraft:red_concrete
setblock 340 258 417 minecraft:red_concrete
setblock 343 258 457 minecraft:red_concrete
setblock 347 258 417 minecraft:red_concrete
setblock 350 258 457 minecraft:red_concrete
setblock 354 258 417 minecraft:red_concrete
setblock 361 258 417 minecraft:red_concrete
setblock 368 258 417 minecraft:red_concrete
setblock 370 258 422 minecraft:red_concrete
setblock 370 258 429 minecraft:red_concrete
setblock 370 258 436 minecraft:red_concrete
setblock 370 258 443 minecraft:red_concrete
setblock 370 258 450 minecraft:red_concrete
fill 330 260 417 330 260 421 minecraft:red_concrete
fill 330 260 423 330 260 428 minecraft:red_concrete
fill 330 260 430 330 260 435 minecraft:red_concrete
fill 330 260 437 330 260 442 minecraft:red_concrete
fill 330 260 444 330 260 449 minecraft:red_concrete
fill 330 260 451 330 260 456 minecraft:red_concrete
setblock 331 260 417 minecraft:red_concrete
fill 331 260 457 336 260 457 minecraft:red_concrete
fill 333 260 417 338 260 417 minecraft:red_concrete
fill 338 260 457 343 260 457 minecraft:red_concrete
fill 340 260 417 345 260 417 minecraft:red_concrete
fill 345 260 457 350 260 457 minecraft:red_concrete
fill 347 260 417 352 260 417 minecraft:red_concrete
fill 352 260 457 356 260 457 minecraft:red_concrete
fill 354 260 417 359 260 417 minecraft:red_concrete
fill 355 260 446 355 261 447 minecraft:red_wool
fill 361 260 417 366 260 417 minecraft:red_concrete
fill 368 260 417 370 260 417 minecraft:red_concrete
fill 368 260 457 370 260 457 minecraft:red_concrete
fill 370 260 418 370 260 420 minecraft:red_concrete
fill 370 260 422 370 260 427 minecraft:red_concrete
fill 370 260 429 370 260 434 minecraft:red_concrete
fill 370 260 436 370 260 441 minecraft:red_concrete
fill 370 260 443 370 260 448 minecraft:red_concrete
fill 370 260 450 370 260 455 minecraft:red_concrete
setblock 330 261 417 minecraft:red_concrete
setblock 330 261 424 minecraft:red_concrete
setblock 330 261 431 minecraft:red_concrete
setblock 330 261 438 minecraft:red_concrete
setblock 330 261 445 minecraft:red_concrete
setblock 330 261 452 minecraft:red_concrete
setblock 332 261 457 minecraft:red_concrete
setblock 337 261 417 minecraft:red_concrete
setblock 339 261 457 minecraft:red_concrete
setblock 344 261 417 minecraft:red_concrete
setblock 346 261 457 minecraft:red_concrete
setblock 351 261 417 minecraft:red_concrete
setblock 353 261 457 minecraft:red_concrete
setblock 358 261 417 minecraft:red_concrete
setblock 365 261 417 minecraft:red_concrete
setblock 370 261 419 minecraft:red_concrete
setblock 370 261 426 minecraft:red_concrete
setblock 370 261 433 minecraft:red_concrete
setblock 370 261 440 minecraft:red_concrete
setblock 370 261 447 minecraft:red_concrete
setblock 370 261 454 minecraft:red_concrete
setblock 330 262 418 minecraft:red_concrete
setblock 330 262 425 minecraft:red_concrete
setblock 330 262 432 minecraft:red_concrete
setblock 330 262 439 minecraft:red_concrete
setblock 330 262 446 minecraft:red_concrete
setblock 330 262 453 minecraft:red_concrete
setblock 333 262 457 minecraft:red_concrete
setblock 336 262 417 minecraft:red_concrete
setblock 340 262 457 minecraft:red_concrete
setblock 343 262 417 minecraft:red_concrete
setblock 347 262 457 minecraft:red_concrete
setblock 350 262 417 minecraft:red_concrete
setblock 354 262 457 minecraft:red_concrete
setblock 357 262 417 minecraft:red_concrete
fill 358 262 448 366 262 456 minecraft:white_concrete
fill 358 262 457 358 273 457 minecraft:red_concrete
setblock 361 262 457 minecraft:red_concrete
setblock 364 262 417 minecraft:red_concrete
fill 365 262 457 365 273 457 minecraft:red_concrete
setblock 368 262 457 minecraft:red_concrete
setblock 370 262 418 minecraft:red_concrete
setblock 370 262 425 minecraft:red_concrete
setblock 370 262 432 minecraft:red_concrete
setblock 370 262 439 minecraft:red_concrete
setblock 370 262 446 minecraft:red_concrete
setblock 370 262 453 minecraft:red_concrete
setblock 330 263 419 minecraft:red_concrete
setblock 330 263 426 minecraft:red_concrete
setblock 330 263 433 minecraft:red_concrete
setblock 330 263 440 minecraft:red_concrete
setblock 330 263 447 minecraft:red_concrete
setblock 330 263 454 minecraft:red_concrete
setblock 334 263 457 minecraft:red_concrete
setblock 335 263 417 minecraft:red_concrete
setblock 341 263 457 minecraft:red_concrete
setblock 342 263 417 minecraft:red_concrete
setblock 348 263 457 minecraft:red_concrete
setblock 349 263 417 minecraft:red_concrete
setblock 355 263 457 minecraft:red_concrete
setblock 356 263 417 minecraft:red_concrete
fill 359 263 449 365 263 455 minecraft:white_concrete
setblock 362 263 457 minecraft:red_concrete
setblock 363 263 417 minecraft:red_concrete
setblock 369 263 457 minecraft:red_concrete
setblock 370 263 417 minecraft:red_concrete
setblock 370 263 424 minecraft:red_concrete
setblock 370 263 431 minecraft:red_concrete
setblock 370 263 438 minecraft:red_concrete
setblock 370 263 445 minecraft:red_concrete
setblock 370 263 452 minecraft:red_concrete
setblock 330 264 420 minecraft:red_concrete
setblock 330 264 427 minecraft:red_concrete
setblock 330 264 434 minecraft:red_concrete
setblock 330 264 441 minecraft:red_concrete
setblock 330 264 448 minecraft:red_concrete
setblock 330 264 455 minecraft:red_concrete
setblock 332 264 419 minecraft:light[level=12]
setblock 332 264 427 minecraft:light[level=12]
setblock 332 264 435 minecraft:light[level=12]
setblock 332 264 443 minecraft:light[level=12]
setblock 332 264 451 minecraft:light[level=12]
setblock 334 264 417 minecraft:red_concrete
setblock 335 264 457 minecraft:red_concrete
setblock 340 264 419 minecraft:light[level=12]
setblock 340 264 427 minecraft:light[level=12]
setblock 340 264 435 minecraft:light[level=12]
setblock 340 264 443 minecraft:light[level=12]
setblock 340 264 451 minecraft:light[level=12]
setblock 341 264 417 minecraft:red_concrete
setblock 342 264 457 minecraft:red_concrete
setblock 348 264 417 minecraft:red_concrete
setblock 348 264 419 minecraft:light[level=12]
setblock 348 264 427 minecraft:light[level=12]
setblock 348 264 435 minecraft:light[level=12]
setblock 348 264 443 minecraft:light[level=12]
setblock 348 264 451 minecraft:light[level=12]
setblock 349 264 457 minecraft:red_concrete
setblock 355 264 417 minecraft:red_concrete
setblock 356 264 419 minecraft:light[level=12]
setblock 356 264 427 minecraft:light[level=12]
setblock 356 264 435 minecraft:light[level=12]
setblock 356 264 443 minecraft:light[level=12]
setblock 356 264 451 minecraft:light[level=12]
setblock 356 264 457 minecraft:red_concrete
fill 360 264 450 364 264 454 minecraft:white_concrete
setblock 362 264 417 minecraft:red_concrete
setblock 363 264 457 minecraft:red_concrete
setblock 364 264 419 minecraft:light[level=12]
setblock 364 264 427 minecraft:light[level=12]
setblock 364 264 435 minecraft:light[level=12]
setblock 364 264 443 minecraft:light[level=12]
setblock 369 264 417 minecraft:red_concrete
setblock 370 264 423 minecraft:red_concrete
setblock 370 264 430 minecraft:red_concrete
setblock 370 264 437 minecraft:red_concrete
setblock 370 264 444 minecraft:red_concrete
setblock 370 264 451 minecraft:red_concrete
setblock 370 264 457 minecraft:red_concrete
setblock 330 265 421 minecraft:red_concrete
setblock 330 265 428 minecraft:red_concrete
setblock 330 265 435 minecraft:red_concrete
setblock 330 265 442 minecraft:red_concrete
setblock 330 265 449 minecraft:red_concrete
setblock 330 265 456 minecraft:red_concrete
setblock 333 265 417 minecraft:red_concrete
setblock 336 265 457 minecraft:red_concrete
setblock 340 265 417 minecraft:red_concrete
setblock 343 265 457 minecraft:red_concrete
setblock 347 265 417 minecraft:red_concrete
setblock 350 265 457 minecraft:red_concrete
setblock 354 265 417 minecraft:red_concrete
setblock 357 265 457 minecraft:red_concrete
setblock 361 265 417 minecraft:red_concrete
fill 361 265 451 363 265 453 minecraft:white_concrete
setblock 364 265 457 minecraft:red_concrete
setblock 368 265 417 minecraft:red_concrete
setblock 370 265 422 minecraft:red_concrete
setblock 370 265 429 minecraft:red_concrete
setblock 370 265 436 minecraft:red_concrete
setblock 370 265 443 minecraft:red_concrete
setblock 370 265 450 minecraft:red_concrete
setblock 330 267 423 minecraft:red_concrete
setblock 330 267 430 minecraft:red_concrete
setblock 330 267 437 minecraft:red_concrete
setblock 330 267 444 minecraft:red_concrete
setblock 330 267 451 minecraft:red_concrete
setblock 331 267 417 minecraft:red_concrete
setblock 331 267 457 minecraft:red_concrete
setblock 338 267 417 minecraft:red_concrete
setblock 338 267 457 minecraft:red_concrete
setblock 345 267 417 minecraft:red_concrete
setblock 345 267 457 minecraft:red_concrete
setblock 352 267 417 minecraft:red_concrete
setblock 352 267 457 minecraft:red_concrete
setblock 359 267 417 minecraft:red_concrete
setblock 359 267 457 minecraft:red_concrete
setblock 366 267 417 minecraft:red_concrete
setblock 366 267 457 minecraft:red_concrete
setblock 370 267 420 minecraft:red_concrete
setblock 370 267 427 minecraft:red_concrete
setblock 370 267 434 minecraft:red_concrete
setblock 370 267 441 minecraft:red_concrete
setblock 370 267 448 minecraft:red_concrete
setblock 370 267 455 minecraft:red_concrete
setblock 330 268 417 minecraft:red_concrete
setblock 330 268 424 minecraft:red_concrete
setblock 330 268 431 minecraft:red_concrete
setblock 330 268 438 minecraft:red_concrete
setblock 330 268 445 minecraft:red_concrete
setblock 330 268 452 minecraft:red_concrete
setblock 332 268 457 minecraft:red_concrete
setblock 337 268 417 minecraft:red_concrete
setblock 339 268 457 minecraft:red_concrete
setblock 344 268 417 minecraft:red_concrete
setblock 346 268 457 minecraft:red_concrete
setblock 351 268 417 minecraft:red_concrete
setblock 353 268 457 minecraft:red_concrete
setblock 358 268 417 minecraft:red_concrete
setblock 360 268 457 minecraft:red_concrete
setblock 365 268 417 minecraft:red_concrete
setblock 367 268 457 minecraft:red_concrete
setblock 370 268 419 minecraft:red_concrete
setblock 370 268 426 minecraft:red_concrete
setblock 370 268 433 minecraft:red_concrete
setblock 370 268 440 minecraft:red_concrete
setblock 370 268 447 minecraft:red_concrete
setblock 370 268 454 minecraft:red_concrete
fill 330 269 418 330 270 418 minecraft:red_concrete
fill 330 269 425 330 270 425 minecraft:red_concrete
fill 330 269 432 330 270 432 minecraft:red_concrete
fill 330 269 439 330 270 439 minecraft:red_concrete
fill 330 269 446 330 270 446 minecraft:red_concrete
fill 330 269 453 330 270 453 minecraft:red_concrete
fill 333 269 457 333 270 457 minecraft:red_concrete
fill 336 269 417 336 270 417 minecraft:red_concrete
fill 340 269 457 340 270 457 minecraft:red_concrete
fill 343 269 417 343 270 417 minecraft:red_concrete
fill 347 269 457 347 270 457 minecraft:red_concrete
fill 350 269 417 350 270 417 minecraft:red_concrete
fill 354 269 457 354 270 457 minecraft:red_concrete
fill 357 269 417 357 270 417 minecraft:red_concrete
fill 361 269 457 361 270 457 minecraft:red_concrete
fill 364 269 417 364 270 417 minecraft:red_concrete
fill 368 269 457 368 270 457 minecraft:red_concrete
fill 370 269 418 370 270 418 minecraft:red_concrete
fill 370 269 425 370 270 425 minecraft:red_concrete
fill 370 269 432 370 270 432 minecraft:red_concrete
fill 370 269 439 370 270 439 minecraft:red_concrete
fill 370 269 446 370 270 446 minecraft:red_concrete
fill 370 269 453 370 270 453 minecraft:red_concrete
fill 330 270 417 331 270 417 minecraft:red_concrete
fill 330 270 419 330 270 421 minecraft:red_concrete
fill 330 270 423 330 270 424 minecraft:red_concrete
fill 330 270 426 330 270 428 minecraft:red_concrete
fill 330 270 430 330 270 431 minecraft:red_concrete
fill 330 270 433 330 270 435 minecraft:red_concrete
fill 330 270 437 330 270 438 minecraft:red_concrete
fill 330 270 440 330 270 442 minecraft:red_concrete
fill 330 270 444 330 270 445 minecraft:red_concrete
fill 330 270 447 330 270 449 minecraft:red_concrete
fill 330 270 451 330 270 452 minecraft:red_concrete
fill 330 270 454 330 270 456 minecraft:red_concrete
fill 331 270 457 332 270 457 minecraft:red_concrete
fill 333 270 417 335 270 417 minecraft:red_concrete
fill 334 270 457 336 270 457 minecraft:red_concrete
fill 337 270 417 338 270 417 minecraft:red_concrete
fill 338 270 457 339 270 457 minecraft:red_concrete
fill 340 270 417 342 270 417 minecraft:red_concrete
fill 341 270 457 343 270 457 minecraft:red_concrete
fill 344 270 417 345 270 417 minecraft:red_concrete
fill 345 270 457 346 270 457 minecraft:red_concrete
fill 347 270 417 349 270 417 minecraft:red_concrete
fill 348 270 457 350 270 457 minecraft:red_concrete
fill 351 270 417 352 270 417 minecraft:red_concrete
fill 352 270 457 353 270 457 minecraft:red_concrete
fill 354 270 417 356 270 417 minecraft:red_concrete
fill 355 270 457 357 270 457 minecraft:red_concrete
fill 358 270 417 359 270 417 minecraft:red_concrete
fill 359 270 457 360 270 457 minecraft:red_concrete
fill 361 270 417 363 270 417 minecraft:red_concrete
fill 362 270 457 364 270 457 minecraft:red_concrete
fill 365 270 417 366 270 417 minecraft:red_concrete
fill 366 270 457 367 270 457 minecraft:red_concrete
fill 368 270 417 370 270 417 minecraft:red_concrete
fill 369 270 457 370 270 457 minecraft:red_concrete
fill 370 270 419 370 270 420 minecraft:red_concrete
fill 370 270 422 370 270 424 minecraft:red_concrete
fill 370 270 426 370 270 427 minecraft:red_concrete
fill 370 270 429 370 270 431 minecraft:red_concrete
fill 370 270 433 370 270 434 minecraft:red_concrete
fill 370 270 436 370 270 438 minecraft:red_concrete
fill 370 270 440 370 270 441 minecraft:red_concrete
fill 370 270 443 370 270 445 minecraft:red_concrete
fill 370 270 447 370 270 448 minecraft:red_concrete
fill 370 270 450 370 270 452 minecraft:red_concrete
fill 370 270 454 370 270 455 minecraft:red_concrete
setblock 330 271 420 minecraft:red_concrete
setblock 330 271 427 minecraft:red_concrete
setblock 330 271 434 minecraft:red_concrete
setblock 330 271 441 minecraft:red_concrete
setblock 330 271 448 minecraft:red_concrete
setblock 330 271 455 minecraft:red_concrete
setblock 334 271 417 minecraft:red_concrete
setblock 335 271 457 minecraft:red_concrete
setblock 341 271 417 minecraft:red_concrete
setblock 342 271 457 minecraft:red_concrete
setblock 348 271 417 minecraft:red_concrete
setblock 349 271 457 minecraft:red_concrete
setblock 355 271 417 minecraft:red_concrete
setblock 356 271 457 minecraft:red_concrete
setblock 362 271 417 minecraft:red_concrete
setblock 363 271 457 minecraft:red_concrete
setblock 369 271 417 minecraft:red_concrete
setblock 370 271 423 minecraft:red_concrete
setblock 370 271 430 minecraft:red_concrete
setblock 370 271 437 minecraft:red_concrete
setblock 370 271 444 minecraft:red_concrete
setblock 370 271 451 minecraft:red_concrete
setblock 370 271 457 minecraft:red_concrete
setblock 330 272 421 minecraft:red_concrete
setblock 330 272 428 minecraft:red_concrete
setblock 330 272 435 minecraft:red_concrete
setblock 330 272 442 minecraft:red_concrete
setblock 330 272 449 minecraft:red_concrete
setblock 330 272 456 minecraft:red_concrete
setblock 332 272 419 minecraft:light[level=12]
setblock 332 272 427 minecraft:light[level=12]
setblock 332 272 435 minecraft:light[level=12]
setblock 332 272 443 minecraft:light[level=12]
setblock 332 272 451 minecraft:light[level=12]
setblock 333 272 417 minecraft:red_concrete
setblock 336 272 457 minecraft:red_concrete
setblock 340 272 417 minecraft:red_concrete
setblock 340 272 419 minecraft:light[level=12]
setblock 340 272 427 minecraft:light[level=12]
setblock 340 272 435 minecraft:light[level=12]
setblock 340 272 443 minecraft:light[level=12]
setblock 340 272 451 minecraft:light[level=12]
setblock 343 272 457 minecraft:red_concrete
setblock 347 272 417 minecraft:red_concrete
setblock 348 272 419 minecraft:light[level=12]
setblock 348 272 427 minecraft:light[level=12]
setblock 348 272 435 minecraft:light[level=12]
setblock 348 272 443 minecraft:light[level=12]
setblock 348 272 451 minecraft:light[level=12]
setblock 350 272 457 minecraft:red_concrete
setblock 354 272 417 minecraft:red_concrete
setblock 356 272 419 minecraft:light[level=12]
setblock 356 272 427 minecraft:light[level=12]
setblock 356 272 435 minecraft:light[level=12]
setblock 356 272 443 minecraft:light[level=12]
setblock 356 272 451 minecraft:light[level=12]
setblock 357 272 457 minecraft:red_concrete
setblock 361 272 417 minecraft:red_concrete
setblock 364 272 419 minecraft:light[level=12]
setblock 364 272 427 minecraft:light[level=12]
setblock 364 272 435 minecraft:light[level=12]
setblock 364 272 443 minecraft:light[level=12]
setblock 364 272 451 minecraft:light[level=12]
setblock 364 272 457 minecraft:red_concrete
setblock 368 272 417 minecraft:red_concrete
setblock 370 272 422 minecraft:red_concrete
setblock 370 272 429 minecraft:red_concrete
setblock 370 272 436 minecraft:red_concrete
setblock 370 272 443 minecraft:red_concrete
setblock 370 272 450 minecraft:red_concrete
fill 330 279 425 348 279 449 minecraft:black_wool
fill 331 279 424 369 280 424 minecraft:black_wool
fill 331 279 450 369 280 450 minecraft:black_wool
fill 332 279 422 368 280 423 minecraft:black_wool
fill 332 279 451 368 280 452 minecraft:black_wool
fill 333 279 421 367 280 421 minecraft:black_wool
fill 333 279 453 367 280 453 minecraft:black_wool
fill 334 279 420 366 280 420 minecraft:black_wool
fill 334 279 454 366 280 454 minecraft:black_wool
fill 335 279 419 365 280 419 minecraft:black_wool
fill 335 279 455 365 280 455 minecraft:black_wool
fill 337 279 418 363 280 418 minecraft:black_wool
fill 337 279 456 363 280 456 minecraft:black_wool
fill 338 279 417 362 280 417 minecraft:black_wool
fill 338 279 457 362 280 457 minecraft:black_wool
fill 349 279 425 349 279 433 minecraft:black_wool
fill 349 279 434 349 279 437 minecraft:white_wool
fill 349 279 438 349 279 449 minecraft:black_wool
fill 350 279 425 350 279 432 minecraft:black_wool
setblock 350 279 433 minecraft:white_wool
fill 350 279 437 350 279 438 minecraft:white_wool
fill 350 279 439 370 279 449 minecraft:black_wool
fill 351 279 425 370 279 431 minecraft:black_wool
fill 351 279 432 353 279 432 minecraft:white_wool
fill 351 279 438 353 279 438 minecraft:white_wool
fill 354 279 432 370 279 432 minecraft:black_wool
setblock 354 279 433 minecraft:white_wool
setblock 354 279 437 minecraft:white_wool
fill 354 279 438 370 279 438 minecraft:black_wool
fill 355 279 433 370 279 433 minecraft:black_wool
fill 355 279 434 355 279 436 minecraft:white_wool
fill 355 279 437 370 279 437 minecraft:black_wool
fill 356 279 434 370 279 436 minecraft:black_wool
fill 330 280 417 330 280 457 minecraft:black_wool
fill 331 280 417 331 280 423 minecraft:black_wool
fill 331 280 425 346 280 449 minecraft:black_wool
fill 331 280 451 331 280 457 minecraft:black_wool
fill 332 280 417 332 280 421 minecraft:black_wool
fill 332 280 453 332 280 457 minecraft:black_wool
fill 333 280 417 333 280 420 minecraft:black_wool
fill 333 280 454 333 280 457 minecraft:black_wool
fill 334 280 417 334 280 419 minecraft:black_wool
fill 334 280 455 334 280 457 minecraft:black_wool
fill 335 280 417 336 280 418 minecraft:black_wool
fill 335 280 456 336 280 457 minecraft:black_wool
setblock 337 280 417 minecraft:black_wool
setblock 337 280 457 minecraft:black_wool
fill 347 280 425 347 280 433 minecraft:black_wool
fill 347 280 434 348 280 437 minecraft:red_wool
fill 347 280 438 347 280 449 minecraft:black_wool
fill 348 280 425 348 280 431 minecraft:black_wool
fill 348 280 432 348 280 433 minecraft:red_wool
fill 348 280 438 349 280 439 minecraft:red_wool
fill 348 280 440 349 280 449 minecraft:black_wool
fill 349 280 425 370 280 430 minecraft:black_wool
fill 349 280 431 349 280 432 minecraft:red_wool
fill 349 280 433 349 280 437 minecraft:jack_o_lantern
fill 350 280 431 354 280 431 minecraft:red_wool
fill 350 280 432 350 280 433 minecraft:jack_o_lantern
fill 350 280 437 350 280 438 minecraft:jack_o_lantern
fill 350 280 439 353 280 440 minecraft:red_wool
fill 350 280 441 370 280 449 minecraft:black_wool
fill 351 280 432 354 280 432 minecraft:jack_o_lantern
fill 351 280 438 354 280 438 minecraft:jack_o_lantern
fill 354 280 433 355 280 433 minecraft:jack_o_lantern
fill 354 280 437 355 280 437 minecraft:jack_o_lantern
fill 354 280 439 355 280 439 minecraft:red_wool
fill 354 280 440 370 280 440 minecraft:black_wool
fill 355 280 431 370 280 431 minecraft:black_wool
setblock 355 280 432 minecraft:red_wool
fill 355 280 434 355 280 436 minecraft:jack_o_lantern
fill 355 280 438 356 280 438 minecraft:red_wool
fill 356 280 432 370 280 432 minecraft:black_wool
fill 356 280 433 356 280 437 minecraft:red_wool
fill 356 280 439 370 280 439 minecraft:black_wool
fill 357 280 433 370 280 438 minecraft:black_wool
fill 363 280 417 370 280 417 minecraft:black_wool
fill 363 280 457 370 280 457 minecraft:black_wool
fill 364 280 418 370 280 418 minecraft:black_wool
fill 364 280 456 370 280 456 minecraft:black_wool
fill 366 280 419 370 280 419 minecraft:black_wool
fill 366 280 455 370 280 455 minecraft:black_wool
fill 367 280 420 370 280 420 minecraft:black_wool
fill 367 280 454 370 280 454 minecraft:black_wool
fill 368 280 421 370 280 421 minecraft:black_wool
fill 368 280 453 370 280 453 minecraft:black_wool
fill 369 280 422 370 280 423 minecraft:black_wool
fill 369 280 451 370 280 452 minecraft:black_wool
setblock 370 280 424 minecraft:black_wool
setblock 370 280 450 minecraft:black_wool
fill 330 281 428 344 281 446 minecraft:black_wool
fill 331 281 426 369 281 427 minecraft:black_wool
fill 331 281 447 369 281 448 minecraft:black_wool
fill 332 281 424 368 281 425 minecraft:black_wool
fill 332 281 449 368 281 450 minecraft:black_wool
fill 333 281 423 367 281 423 minecraft:black_wool
fill 333 281 451 367 281 451 minecraft:black_wool
fill 334 281 422 366 281 422 minecraft:black_wool
fill 334 281 452 366 281 452 minecraft:black_wool
fill 335 281 421 365 281 421 minecraft:black_wool
fill 335 281 453 365 281 453 minecraft:black_wool
fill 336 281 420 364 281 420 minecraft:black_wool
fill 336 281 454 364 281 454 minecraft:black_wool
fill 337 281 419 363 281 419 minecraft:black_wool
fill 337 281 455 363 281 455 minecraft:black_wool
fill 339 281 418 361 281 418 minecraft:black_wool
fill 339 281 456 361 281 456 minecraft:black_wool
fill 341 281 417 359 281 417 minecraft:black_wool
fill 341 281 457 359 281 457 minecraft:black_wool
fill 345 281 428 345 281 433 minecraft:black_wool
fill 345 281 434 346 281 438 minecraft:red_wool
fill 345 281 439 345 281 446 minecraft:black_wool
fill 346 281 428 346 281 431 minecraft:black_wool
fill 346 281 432 347 281 433 minecraft:red_wool
fill 346 281 439 347 281 439 minecraft:red_wool
fill 346 281 440 346 281 446 minecraft:black_wool
fill 347 281 428 347 281 430 minecraft:black_wool
fill 347 281 431 348 281 431 minecraft:red_wool
setblock 347 281 438 minecraft:red_wool
fill 347 281 440 349 281 440 minecraft:red_wool
fill 347 281 441 347 281 446 minecraft:black_wool
fill 348 281 428 350 281 429 minecraft:black_wool
fill 348 281 430 354 281 430 minecraft:red_wool
fill 348 281 441 355 281 441 minecraft:red_wool
fill 348 281 442 348 281 446 minecraft:black_wool
fill 349 281 442 353 281 442 minecraft:red_wool
fill 349 281 443 370 281 446 minecraft:black_wool
fill 351 281 428 370 281 428 minecraft:black_wool
setblock 351 281 429 minecraft:red_wool
fill 352 281 429 370 281 429 minecraft:black_wool
fill 354 281 440 356 281 440 minecraft:red_wool
fill 354 281 442 370 281 442 minecraft:black_wool
fill 355 281 430 370 281 430 minecraft:black_wool
fill 355 281 431 356 281 431 minecraft:red_wool
setblock 356 281 432 minecraft:red_wool
fill 356 281 439 357 281 439 minecraft:red_wool
fill 356 281 441 370 281 441 minecraft:black_wool
fill 357 281 431 370 281 432 minecraft:black_wool
fill 357 281 433 357 281 438 minecraft:red_wool
fill 357 281 440 370 281 440 minecraft:black_wool
fill 358 281 433 370 281 435 minecraft:black_wool
setblock 358 281 436 minecraft:red_wool
fill 358 281 437 370 281 439 minecraft:black_wool
fill 359 281 436 370 281 436 minecraft:black_wool
fill 330 282 429 342 282 445 minecraft:black_wool
fill 331 282 427 348 282 428 minecraft:black_wool
fill 331 282 446 369 282 447 minecraft:black_wool
fill 332 282 425 368 282 426 minecraft:black_wool
fill 332 282 448 368 282 449 minecraft:black_wool
fill 333 282 424 367 282 424 minecraft:black_wool
fill 333 282 450 367 282 450 minecraft:black_wool
fill 334 282 423 366 282 423 minecraft:black_wool
fill 334 282 451 366 282 451 minecraft:black_wool
fill 335 282 422 365 282 422 minecraft:black_wool
fill 335 282 452 365 282 452 minecraft:black_wool
fill 336 282 421 364 282 421 minecraft:black_wool
fill 336 282 453 364 282 453 minecraft:black_wool
fill 337 282 420 363 282 420 minecraft:black_wool
fill 337 282 454 363 282 454 minecraft:black_wool
fill 338 282 419 362 282 419 minecraft:black_wool
fill 338 282 455 362 282 455 minecraft:black_wool
fill 340 282 418 360 282 418 minecraft:black_wool
fill 340 282 456 360 282 456 minecraft:black_wool
fill 342 282 417 358 282 417 minecraft:black_wool
fill 342 282 457 358 282 457 minecraft:black_wool
fill 343 282 429 343 282 433 minecraft:black_wool
fill 343 282 434 344 282 438 minecraft:white_wool
fill 343 282 439 343 282 445 minecraft:black_wool
fill 344 282 429 344 282 431 minecraft:black_wool
fill 344 282 432 345 282 433 minecraft:white_wool
fill 344 282 439 345 282 440 minecraft:white_wool
fill 344 282 441 344 282 445 minecraft:black_wool
fill 345 282 429 345 282 430 minecraft:black_wool
fill 345 282 431 346 282 431 minecraft:white_wool
fill 345 282 441 347 282 441 minecraft:white_wool
fill 345 282 442 345 282 445 minecraft:black_wool
setblock 346 282 429 minecraft:black_wool
fill 346 282 430 347 282 430 minecraft:white_wool
setblock 346 282 440 minecraft:white_wool
fill 346 282 442 348 282 442 minecraft:white_wool
fill 346 282 443 346 282 445 minecraft:black_wool
fill 347 282 429 350 282 429 minecraft:white_wool
fill 347 282 443 355 282 443 minecraft:white_wool
fill 347 282 444 348 282 445 minecraft:black_wool
fill 349 282 427 369 282 427 minecraft:black_wool
fill 349 282 428 353 282 428 minecraft:white_wool
fill 349 282 444 353 282 444 minecraft:white_wool
fill 349 282 445 370 282 445 minecraft:black_wool
fill 352 282 429 355 282 429 minecraft:white_wool
fill 354 282 428 369 282 428 minecraft:black_wool
fill 354 282 442 356 282 442 minecraft:white_wool
fill 354 282 444 370 282 444 minecraft:black_wool
fill 355 282 430 356 282 430 minecraft:white_wool
fill 356 282 429 370 282 429 minecraft:black_wool
fill 356 282 441 357 282 441 minecraft:white_wool
fill 356 282 443 370 282 443 minecraft:black_wool
fill 357 282 430 370 282 430 minecraft:black_wool
fill 357 282 431 357 282 432 minecraft:white_wool
fill 357 282 440 358 282 440 minecraft:white_wool
fill 357 282 442 370 282 442 minecraft:black_wool
fill 358 282 431 370 282 431 minecraft:black_wool
fill 358 282 432 358 282 435 minecraft:white_wool
fill 358 282 437 358 282 439 minecraft:white_wool
fill 358 282 441 370 282 441 minecraft:black_wool
fill 359 282 432 370 282 433 minecraft:black_wool
fill 359 282 434 359 282 438 minecraft:white_wool
fill 359 282 439 370 282 440 minecraft:black_wool
fill 360 282 434 370 282 438 minecraft:black_wool
fill 330 283 432 340 283 442 minecraft:black_wool
fill 331 283 429 342 283 431 minecraft:black_wool
fill 331 283 443 343 283 445 minecraft:black_wool
fill 332 283 427 345 283 428 minecraft:black_wool
fill 332 283 446 348 283 447 minecraft:black_wool
fill 333 283 425 367 283 426 minecraft:black_wool
fill 333 283 448 367 283 449 minecraft:black_wool
fill 334 283 424 366 283 424 minecraft:black_wool
fill 334 283 450 366 283 450 minecraft:black_wool
fill 335 283 423 365 283 423 minecraft:black_wool
fill 335 283 451 365 283 451 minecraft:black_wool
fill 336 283 422 364 283 422 minecraft:black_wool
fill 336 283 452 364 283 452 minecraft:black_wool
fill 337 283 421 363 283 421 minecraft:black_wool
fill 337 283 453 363 283 453 minecraft:black_wool
fill 338 283 420 362 283 420 minecraft:black_wool
fill 338 283 454 362 283 454 minecraft:black_wool
fill 340 283 419 360 283 419 minecraft:black_wool
fill 340 283 455 360 283 455 minecraft:black_wool
fill 341 283 432 341 283 434 minecraft:black_wool
fill 341 283 435 342 283 438 minecraft:red_wool
fill 341 283 439 341 283 442 minecraft:black_wool
fill 342 283 418 358 283 418 minecraft:black_wool
fill 342 283 432 342 283 434 minecraft:red_wool
fill 342 283 439 343 283 441 minecraft:red_wool
setblock 342 283 442 minecraft:black_wool
fill 342 283 456 358 283 456 minecraft:black_wool
setblock 343 283 429 minecraft:black_wool
fill 343 283 430 343 283 433 minecraft:red_wool
fill 343 283 442 345 283 442 minecraft:red_wool
fill 344 283 429 344 283 431 minecraft:red_wool
setblock 344 283 441 minecraft:red_wool
fill 344 283 443 346 283 443 minecraft:red_wool
fill 344 283 444 344 283 445 minecraft:black_wool
fill 345 283 417 355 283 417 minecraft:black_wool
fill 345 283 429 345 283 430 minecraft:red_wool
fill 345 283 444 348 283 444 minecraft:red_wool
setblock 345 283 445 minecraft:black_wool
fill 345 283 457 355 283 457 minecraft:black_wool
fill 346 283 427 347 283 427 minecraft:black_wool
fill 346 283 428 346 283 429 minecraft:red_wool
fill 346 283 445 355 283 445 minecraft:red_wool
fill 347 283 428 348 283 428 minecraft:red_wool
fill 348 283 427 354 283 427 minecraft:red_wool
fill 349 283 446 352 283 446 minecraft:red_wool
fill 349 283 447 368 283 447 minecraft:black_wool
fill 353 283 446 368 283 446 minecraft:black_wool
fill 354 283 428 356 283 428 minecraft:red_wool
fill 354 283 444 357 283 444 minecraft:red_wool
fill 355 283 427 368 283 427 minecraft:black_wool
fill 356 283 429 357 283 429 minecraft:red_wool
fill 356 283 443 358 283 443 minecraft:red_wool
fill 356 283 445 369 283 445 minecraft:black_wool
fill 357 283 428 368 283 428 minecraft:black_wool
fill 357 283 430 358 283 430 minecraft:red_wool
fill 357 283 442 358 283 442 minecraft:red_wool
fill 358 283 429 369 283 429 minecraft:black_wool
fill 358 283 431 359 283 431 minecraft:red_wool
fill 358 283 441 359 283 441 minecraft:red_wool
fill 358 283 444 369 283 444 minecraft:black_wool
fill 359 283 430 369 283 430 minecraft:black_wool
fill 359 283 432 359 283 433 minecraft:red_wool
fill 359 283 439 359 283 440 minecraft:red_wool
fill 359 283 442 369 283 443 minecraft:black_wool
fill 360 283 431 369 283 432 minecraft:black_wool
fill 360 283 433 360 283 439 minecraft:red_wool
fill 360 283 440 370 283 441 minecraft:black_wool
fill 361 283 433 370 283 439 minecraft:black_wool
setblock 370 283 432 minecraft:black_wool
setblock 370 283 442 minecraft:black_wool
setblock 330 284 419 minecraft:red_concrete
fill 330 284 422 330 300 422 minecraft:red_concrete
setblock 330 284 426 minecraft:red_concrete
fill 330 284 429 330 300 429 minecraft:red_concrete
setblock 330 284 433 minecraft:red_concrete
fill 330 284 436 330 300 436 minecraft:red_concrete
setblock 330 284 440 minecraft:red_concrete
fill 330 284 443 330 300 443 minecraft:red_concrete
setblock 330 284 447 minecraft:red_concrete
fill 330 284 450 330 300 450 minecraft:red_concrete
setblock 330 284 454 minecraft:red_concrete
fill 330 284 457 330 300 457 minecraft:red_concrete
fill 331 284 431 338 284 443 minecraft:black_wool
fill 332 284 417 332 300 417 minecraft:red_concrete
fill 332 284 429 340 284 430 minecraft:black_wool
fill 332 284 444 341 284 445 minecraft:black_wool
fill 333 284 427 342 284 428 minecraft:black_wool
fill 333 284 446 343 284 447 minecraft:black_wool
fill 334 284 426 345 284 426 minecraft:black_wool
fill 334 284 448 348 284 448 minecraft:black_wool
setblock 334 284 457 minecraft:red_concrete
setblock 335 284 417 minecraft:red_concrete
fill 335 284 424 365 284 425 minecraft:black_wool
fill 335 284 449 365 284 450 minecraft:black_wool
fill 336 284 423 364 284 423 minecraft:black_wool
fill 336 284 451 364 284 451 minecraft:black_wool
fill 337 284 422 363 284 422 minecraft:black_wool
fill 337 284 452 363 284 452 minecraft:black_wool
fill 337 284 457 337 300 457 minecraft:red_concrete
fill 339 284 417 339 300 417 minecraft:red_concrete
fill 339 284 421 361 284 421 minecraft:black_wool
fill 339 284 431 339 284 434 minecraft:black_wool
fill 339 284 435 340 284 438 minecraft:red_wool
fill 339 284 439 339 284 443 minecraft:black_wool
fill 339 284 453 361 284 453 minecraft:black_wool
fill 340 284 420 360 284 420 minecraft:black_wool
setblock 340 284 431 minecraft:black_wool
fill 340 284 432 341 284 434 minecraft:red_wool
fill 340 284 439 341 284 441 minecraft:red_wool
fill 340 284 442 340 284 443 minecraft:black_wool
fill 340 284 454 360 284 454 minecraft:black_wool
setblock 341 284 429 minecraft:black_wool
fill 341 284 430 342 284 431 minecraft:red_wool
fill 341 284 442 342 284 443 minecraft:red_wool
setblock 341 284 457 minecraft:red_concrete
setblock 342 284 417 minecraft:red_concrete
fill 342 284 419 358 284 419 minecraft:black_wool
fill 342 284 429 343 284 429 minecraft:red_wool
fill 342 284 444 344 284 444 minecraft:red_wool
setblock 342 284 445 minecraft:black_wool
fill 342 284 455 358 284 455 minecraft:black_wool
setblock 343 284 427 minecraft:black_wool
fill 343 284 428 345 284 428 minecraft:red_wool
setblock 343 284 443 minecraft:red_wool
fill 343 284 445 345 284 445 minecraft:red_wool
fill 344 284 418 356 284 418 minecraft:black_wool
fill 344 284 427 347 284 427 minecraft:red_wool
fill 344 284 446 348 284 446 minecraft:red_wool
fill 344 284 447 345 284 447 minecraft:black_wool
fill 344 284 456 356 284 456 minecraft:black_wool
fill 344 284 457 344 300 457 minecraft:red_concrete
fill 346 284 417 346 300 417 minecraft:red_concrete
fill 346 284 426 355 284 426 minecraft:red_wool
fill 346 284 447 355 284 447 minecraft:red_wool
setblock 348 284 457 minecraft:red_concrete
setblock 349 284 417 minecraft:red_concrete
fill 349 284 448 352 284 448 minecraft:red_wool
fill 351 284 457 351 300 457 minecraft:red_concrete
fill 353 284 417 353 300 417 minecraft:red_concrete
fill 353 284 446 357 284 446 minecraft:red_wool
fill 353 284 448 366 284 448 minecraft:black_wool
fill 355 284 427 356 284 427 minecraft:red_wool
fill 355 284 457 367 285 457 minecraft:red_concrete
setblock 356 284 417 minecraft:red_concrete
fill 356 284 426 366 284 426 minecraft:black_wool
fill 356 284 445 358 284 445 minecraft:red_wool
fill 356 284 447 367 284 447 minecraft:black_wool
fill 357 284 427 367 284 427 minecraft:black_wool
fill 357 284 428 358 284 428 minecraft:red_wool
fill 357 284 456 367 285 456 minecraft:red_concrete
fill 358 284 429 359 284 429 minecraft:red_wool
fill 358 284 444 359 284 444 minecraft:red_wool
fill 358 284 446 367 284 446 minecraft:black_wool
fill 359 284 428 367 284 428 minecraft:black_wool
setblock 359 284 430 minecraft:red_wool
fill 359 284 442 360 284 443 minecraft:red_wool
fill 359 284 445 368 284 445 minecraft:black_wool
fill 359 284 455 367 285 455 minecraft:red_concrete
fill 360 284 417 360 300 417 minecraft:red_concrete
fill 360 284 429 368 284 430 minecraft:black_wool
fill 360 284 431 360 284 432 minecraft:red_wool
fill 360 284 440 361 284 441 minecraft:red_wool
fill 360 284 444 368 284 444 minecraft:black_wool
fill 361 284 431 369 284 431 minecraft:black_wool
fill 361 284 432 361 284 439 minecraft:red_wool
fill 361 284 442 369 284 443 minecraft:black_wool
fill 361 284 454 367 285 454 minecraft:red_concrete
fill 362 284 432 369 284 441 minecraft:black_wool
fill 362 284 453 367 285 453 minecraft:red_concrete
setblock 363 284 417 minecraft:red_concrete
fill 364 284 452 367 285 452 minecraft:red_concrete
fill 365 284 451 367 285 451 minecraft:red_concrete
fill 367 284 417 367 300 417 minecraft:red_concrete
setblock 369 284 457 minecraft:red_concrete
setblock 370 284 417 minecraft:red_concrete
fill 370 284 421 370 300 421 minecraft:red_concrete
setblock 370 284 424 minecraft:red_concrete
fill 370 284 428 370 300 428 minecraft:red_concrete
setblock 370 284 431 minecraft:red_concrete
fill 370 284 435 370 300 435 minecraft:red_concrete
setblock 370 284 438 minecraft:red_concrete
fill 370 284 442 370 300 442 minecraft:red_concrete
setblock 370 284 445 minecraft:red_concrete
fill 370 284 449 370 300 449 minecraft:red_concrete
setblock 370 284 452 minecraft:red_concrete
fill 370 284 456 370 300 456 minecraft:red_concrete
setblock 330 285 420 minecraft:red_concrete
setblock 330 285 427 minecraft:red_concrete
setblock 330 285 434 minecraft:red_concrete
setblock 330 285 441 minecraft:red_concrete
setblock 330 285 448 minecraft:red_concrete
setblock 330 285 455 minecraft:red_concrete
fill 332 285 432 336 285 442 minecraft:black_wool
fill 333 285 429 338 285 431 minecraft:black_wool
fill 333 285 443 338 285 445 minecraft:black_wool
setblock 334 285 417 minecraft:red_concrete
fill 334 285 428 340 285 428 minecraft:black_wool
fill 334 285 446 340 285 446 minecraft:black_wool
fill 335 285 426 341 285 427 minecraft:black_wool
fill 335 285 447 341 285 448 minecraft:black_wool
setblock 335 285 457 minecraft:red_concrete
fill 336 285 425 344 285 425 minecraft:black_wool
fill 336 285 449 344 285 449 minecraft:black_wool
fill 337 285 424 347 285 424 minecraft:black_wool
fill 337 285 432 337 285 435 minecraft:black_wool
fill 337 285 436 338 285 438 minecraft:white_wool
fill 337 285 439 337 285 442 minecraft:black_wool
fill 337 285 450 348 285 450 minecraft:black_wool
fill 338 285 423 362 285 423 minecraft:black_wool
fill 338 285 432 338 285 435 minecraft:white_wool
fill 338 285 439 339 285 442 minecraft:white_wool
fill 338 285 451 362 285 451 minecraft:black_wool
fill 339 285 422 361 285 422 minecraft:black_wool
setblock 339 285 429 minecraft:black_wool
fill 339 285 430 339 285 434 minecraft:white_wool
fill 339 285 443 340 285 443 minecraft:white_wool
fill 339 285 444 339 285 445 minecraft:black_wool
fill 339 285 452 361 285 452 minecraft:black_wool
fill 340 285 429 340 285 431 minecraft:white_wool
setblock 340 285 442 minecraft:white_wool
fill 340 285 444 341 285 445 minecraft:white_wool
setblock 341 285 417 minecraft:red_concrete
fill 341 285 421 359 285 421 minecraft:black_wool
fill 341 285 428 341 285 429 minecraft:white_wool
fill 341 285 446 343 285 446 minecraft:white_wool
fill 341 285 453 359 285 453 minecraft:black_wool
fill 342 285 420 358 285 420 minecraft:black_wool
setblock 342 285 426 minecraft:black_wool
fill 342 285 427 342 285 428 minecraft:white_wool
setblock 342 285 445 minecraft:white_wool
fill 342 285 447 345 285 447 minecraft:white_wool
fill 342 285 448 343 285 448 minecraft:black_wool
fill 342 285 454 358 285 454 minecraft:black_wool
setblock 342 285 457 minecraft:red_concrete
fill 343 285 426 343 285 427 minecraft:white_wool
fill 344 285 426 345 285 426 minecraft:white_wool
fill 344 285 448 348 285 448 minecraft:white_wool
fill 345 285 419 355 285 419 minecraft:black_wool
fill 345 285 425 355 285 425 minecraft:white_wool
fill 345 285 449 355 285 449 minecraft:white_wool
fill 345 285 455 355 285 455 minecraft:black_wool
setblock 348 285 417 minecraft:red_concrete
fill 348 285 424 353 285 424 minecraft:white_wool
fill 349 285 450 351 285 450 minecraft:white_wool
setblock 349 285 457 minecraft:red_concrete
fill 352 285 450 363 285 450 minecraft:black_wool
fill 353 285 448 357 285 448 minecraft:white_wool
fill 354 285 424 363 285 424 minecraft:black_wool
setblock 355 285 417 minecraft:red_concrete
fill 355 285 456 356 285 456 minecraft:red_concrete
fill 356 285 425 364 285 425 minecraft:black_wool
fill 356 285 426 357 285 426 minecraft:white_wool
fill 356 285 447 358 285 447 minecraft:white_wool
fill 356 285 449 364 285 449 minecraft:black_wool
fill 356 285 455 358 285 455 minecraft:red_concrete
fill 357 285 427 358 285 427 minecraft:white_wool
fill 358 285 426 365 285 426 minecraft:black_wool
fill 358 285 446 359 285 446 minecraft:white_wool
fill 358 285 448 365 285 448 minecraft:black_wool
fill 359 285 427 365 285 427 minecraft:black_wool
setblock 359 285 428 minecraft:white_wool
fill 359 285 445 360 285 445 minecraft:white_wool
fill 359 285 447 365 285 447 minecraft:black_wool
fill 359 285 454 360 285 454 minecraft:red_concrete
fill 360 285 428 366 285 428 minecraft:black_wool
fill 360 285 429 360 285 430 minecraft:white_wool
fill 360 285 444 361 285 444 minecraft:white_wool
fill 360 285 446 366 285 446 minecraft:black_wool
fill 360 285 453 361 285 453 minecraft:red_concrete
fill 361 285 429 367 285 429 minecraft:black_wool
fill 361 285 430 361 285 431 minecraft:white_wool
fill 361 285 442 361 285 443 minecraft:white_wool
fill 361 285 445 367 285 445 minecraft:black_wool
setblock 362 285 417 minecraft:red_concrete
fill 362 285 430 367 285 431 minecraft:black_wool
fill 362 285 432 362 285 442 minecraft:white_wool
fill 362 285 443 367 285 444 minecraft:black_wool
fill 362 285 452 363 285 452 minecraft:red_concrete
fill 363 285 432 368 285 433 minecraft:black_wool
fill 363 285 434 363 285 439 minecraft:white_wool
fill 363 285 440 368 285 442 minecraft:black_wool
fill 363 285 451 364 285 451 minecraft:red_concrete
fill 364 285 434 368 285 439 minecraft:black_wool
setblock 369 285 417 minecraft:red_concrete
setblock 370 285 423 minecraft:red_concrete
setblock 370 285 430 minecraft:red_concrete
setblock 370 285 437 minecraft:red_concrete
setblock 370 285 444 minecraft:red_concrete
setblock 370 285 451 minecraft:red_concrete
setblock 370 285 457 minecraft:red_concrete
setblock 330 286 421 minecraft:red_concrete
setblock 330 286 428 minecraft:red_concrete
setblock 330 286 435 minecraft:red_concrete
setblock 330 286 442 minecraft:red_concrete
setblock 330 286 449 minecraft:red_concrete
setblock 330 286 456 minecraft:red_concrete
setblock 333 286 417 minecraft:red_concrete
fill 333 286 435 335 286 439 minecraft:black_wool
fill 334 286 431 336 286 434 minecraft:black_wool
fill 334 286 440 336 286 443 minecraft:black_wool
fill 335 286 429 337 286 430 minecraft:black_wool
fill 335 286 444 337 286 445 minecraft:black_wool
fill 336 286 427 339 286 428 minecraft:black_wool
setblock 336 286 435 minecraft:black_wool
fill 336 286 436 336 286 438 minecraft:red_wool
setblock 336 286 439 minecraft:black_wool
fill 336 286 446 339 286 447 minecraft:black_wool
setblock 336 286 457 minecraft:red_concrete
fill 337 286 426 341 286 426 minecraft:black_wool
setblock 337 286 431 minecraft:black_wool
fill 337 286 432 337 286 435 minecraft:red_wool
fill 337 286 439 337 286 442 minecraft:red_wool
setblock 337 286 443 minecraft:black_wool
fill 337 286 448 341 286 448 minecraft:black_wool
fill 338 286 425 342 286 425 minecraft:black_wool
setblock 338 286 429 minecraft:black_wool
fill 338 286 430 338 286 431 minecraft:red_wool
fill 338 286 443 338 286 444 minecraft:red_wool
setblock 338 286 445 minecraft:black_wool
fill 338 286 449 342 286 449 minecraft:black_wool
fill 339 286 424 344 286 424 minecraft:black_wool
setblock 339 286 429 minecraft:red_wool
fill 339 286 444 339 286 445 minecraft:red_wool
fill 339 286 450 344 286 450 minecraft:black_wool
setblock 340 286 417 minecraft:red_concrete
fill 340 286 423 347 286 423 minecraft:black_wool
setblock 340 286 427 minecraft:black_wool
setblock 340 286 428 minecraft:red_wool
setblock 340 286 446 minecraft:red_wool
setblock 340 286 447 minecraft:black_wool
fill 340 286 451 348 286 451 minecraft:black_wool
setblock 341 286 427 minecraft:red_wool
fill 341 286 447 341 288 447 minecraft:red_wool
fill 342 286 422 358 286 422 minecraft:black_wool
setblock 342 286 426 minecraft:red_wool
fill 342 286 432 343 287 432 minecraft:white_wool
fill 342 286 448 343 286 448 minecraft:red_wool
fill 342 286 452 354 286 452 minecraft:black_wool
fill 343 286 425 344 286 425 minecraft:red_wool
fill 343 286 449 344 286 449 minecraft:red_wool
setblock 343 286 457 minecraft:red_concrete
fill 344 286 421 356 286 421 minecraft:black_wool
fill 344 286 453 355 286 453 minecraft:black_wool
fill 345 286 424 347 286 424 minecraft:red_wool
fill 345 286 450 348 286 450 minecraft:red_wool
setblock 347 286 417 minecraft:red_concrete
fill 348 286 420 352 286 420 minecraft:black_wool
fill 348 286 423 353 286 423 minecraft:red_wool
fill 348 286 454 352 286 454 minecraft:black_wool
schedule function dropper:buildpart/103_5 1t
