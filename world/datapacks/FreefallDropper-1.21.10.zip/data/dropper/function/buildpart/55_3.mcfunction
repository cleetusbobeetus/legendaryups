fill 341 277 229 341 277 243 minecraft:white_concrete
fill 341 277 257 341 277 269 minecraft:white_concrete
fill 342 277 229 342 277 241 minecraft:white_concrete
fill 342 277 259 342 277 269 minecraft:white_concrete
fill 343 277 229 343 277 240 minecraft:white_concrete
fill 343 277 260 343 277 269 minecraft:white_concrete
setblock 343 277 270 minecraft:mossy_stone_bricks
fill 344 277 229 344 278 239 minecraft:white_concrete
fill 344 277 261 344 278 269 minecraft:white_concrete
fill 345 277 229 347 277 238 minecraft:white_concrete
fill 345 277 262 347 277 269 minecraft:white_concrete
setblock 346 277 245 minecraft:light[level=12]
setblock 346 277 252 minecraft:light[level=12]
setblock 346 277 259 minecraft:light[level=12]
fill 348 277 229 370 278 237 minecraft:white_concrete
fill 348 277 263 370 278 269 minecraft:white_concrete
fill 353 277 238 370 277 238 minecraft:white_concrete
setblock 353 277 245 minecraft:light[level=12]
setblock 353 277 252 minecraft:light[level=12]
setblock 353 277 259 minecraft:light[level=12]
fill 353 277 262 370 277 262 minecraft:white_concrete
fill 356 277 239 370 278 239 minecraft:white_concrete
fill 356 277 261 370 278 261 minecraft:white_concrete
fill 357 277 240 370 277 240 minecraft:white_concrete
fill 357 277 260 370 277 260 minecraft:white_concrete
fill 358 277 241 370 277 241 minecraft:white_concrete
fill 358 277 259 370 277 259 minecraft:white_concrete
fill 359 277 242 370 277 243 minecraft:white_concrete
fill 359 277 257 370 277 258 minecraft:white_concrete
fill 360 277 244 370 277 245 minecraft:white_concrete
setblock 360 277 252 minecraft:light[level=12]
fill 360 277 255 370 277 256 minecraft:white_concrete
fill 361 277 246 370 277 254 minecraft:white_concrete
setblock 371 277 250 minecraft:mossy_cobblestone
fill 329 278 247 329 280 247 minecraft:stone_bricks
fill 330 278 229 338 278 269 minecraft:white_concrete
fill 339 278 228 339 280 228 minecraft:stone_bricks
fill 339 278 229 339 278 247 minecraft:white_concrete
fill 339 278 253 339 278 269 minecraft:white_concrete
fill 340 278 229 340 278 243 minecraft:white_concrete
fill 340 278 257 340 278 269 minecraft:white_concrete
fill 341 278 229 341 278 242 minecraft:white_concrete
fill 341 278 258 341 278 269 minecraft:white_concrete
fill 342 278 229 342 278 240 minecraft:white_concrete
fill 342 278 260 342 278 269 minecraft:white_concrete
fill 343 278 229 343 278 239 minecraft:white_concrete
fill 343 278 261 343 278 269 minecraft:white_concrete
fill 343 278 270 343 280 270 minecraft:stone_bricks
fill 345 278 229 345 278 238 minecraft:white_concrete
fill 345 278 262 345 278 269 minecraft:white_concrete
fill 346 278 229 347 278 237 minecraft:white_concrete
fill 346 278 263 347 278 269 minecraft:white_concrete
fill 355 278 238 370 278 238 minecraft:white_concrete
fill 355 278 262 370 278 262 minecraft:white_concrete
fill 358 278 240 370 278 240 minecraft:white_concrete
fill 358 278 260 370 278 260 minecraft:white_concrete
fill 359 278 241 370 278 242 minecraft:white_concrete
fill 359 278 258 370 278 259 minecraft:white_concrete
fill 360 278 243 370 278 243 minecraft:white_concrete
fill 360 278 257 370 278 257 minecraft:white_concrete
fill 361 278 244 370 278 247 minecraft:white_concrete
fill 361 278 253 370 278 256 minecraft:white_concrete
fill 362 278 248 370 278 252 minecraft:white_concrete
fill 371 278 250 371 280 250 minecraft:stone_bricks
fill 330 279 229 338 279 269 minecraft:smooth_quartz
fill 339 279 229 339 279 245 minecraft:smooth_quartz
fill 339 279 255 339 279 269 minecraft:smooth_quartz
fill 340 279 229 340 279 243 minecraft:smooth_quartz
setblock 340 279 247 minecraft:light[level=15]
setblock 340 279 255 minecraft:light[level=15]
fill 340 279 257 340 279 269 minecraft:smooth_quartz
fill 341 279 229 341 279 241 minecraft:smooth_quartz
fill 341 279 259 341 279 269 minecraft:smooth_quartz
fill 342 279 229 342 279 240 minecraft:smooth_quartz
fill 342 279 260 342 279 269 minecraft:smooth_quartz
fill 343 279 229 343 279 239 minecraft:smooth_quartz
fill 343 279 261 343 279 269 minecraft:smooth_quartz
fill 344 279 229 344 279 238 minecraft:smooth_quartz
fill 344 279 262 344 279 269 minecraft:smooth_quartz
fill 345 279 229 347 279 237 minecraft:smooth_quartz
fill 345 279 263 347 279 269 minecraft:smooth_quartz
setblock 347 279 228 minecraft:mossy_stone_bricks
fill 348 279 229 370 279 236 minecraft:smooth_quartz
setblock 348 279 239 minecraft:light[level=15]
setblock 348 279 247 minecraft:light[level=15]
setblock 348 279 255 minecraft:light[level=15]
setblock 348 279 263 minecraft:light[level=15]
fill 348 279 264 370 279 269 minecraft:smooth_quartz
fill 353 279 237 370 279 237 minecraft:smooth_quartz
fill 353 279 263 370 279 263 minecraft:smooth_quartz
fill 356 279 238 370 279 238 minecraft:smooth_quartz
setblock 356 279 239 minecraft:light[level=15]
setblock 356 279 247 minecraft:light[level=15]
setblock 356 279 255 minecraft:light[level=15]
fill 356 279 262 370 279 262 minecraft:smooth_quartz
fill 357 279 239 370 279 239 minecraft:smooth_quartz
fill 357 279 261 370 279 261 minecraft:smooth_quartz
fill 358 279 240 370 279 240 minecraft:smooth_quartz
fill 358 279 260 370 279 260 minecraft:smooth_quartz
fill 359 279 241 370 279 241 minecraft:smooth_quartz
fill 359 279 259 370 279 259 minecraft:smooth_quartz
fill 360 279 242 370 279 243 minecraft:smooth_quartz
fill 360 279 257 370 279 258 minecraft:smooth_quartz
fill 361 279 244 370 279 245 minecraft:smooth_quartz
fill 361 279 255 370 279 256 minecraft:smooth_quartz
fill 362 279 246 370 279 254 minecraft:smooth_quartz
setblock 371 279 257 minecraft:cobblestone
fill 330 280 229 337 281 269 minecraft:white_concrete
setblock 330 280 270 minecraft:mossy_cobblestone
setblock 335 280 228 minecraft:mossy_cobblestone
fill 338 280 229 338 280 248 minecraft:white_concrete
fill 338 280 252 338 280 269 minecraft:white_concrete
fill 339 280 229 339 280 244 minecraft:white_concrete
fill 339 280 256 339 280 269 minecraft:white_concrete
fill 340 280 229 340 280 242 minecraft:white_concrete
fill 340 280 258 340 280 269 minecraft:white_concrete
fill 341 280 229 341 281 240 minecraft:white_concrete
fill 341 280 260 341 281 269 minecraft:white_concrete
fill 342 280 229 342 280 239 minecraft:white_concrete
fill 342 280 261 342 280 269 minecraft:white_concrete
fill 343 280 229 343 281 238 minecraft:white_concrete
fill 343 280 262 343 281 269 minecraft:white_concrete
fill 344 280 229 345 280 237 minecraft:white_concrete
fill 344 280 263 345 280 269 minecraft:white_concrete
fill 346 280 229 370 280 236 minecraft:white_concrete
fill 346 280 264 370 280 269 minecraft:white_concrete
setblock 347 280 228 minecraft:stone_bricks
fill 355 280 237 370 280 237 minecraft:white_concrete
fill 355 280 263 370 280 263 minecraft:white_concrete
fill 357 280 238 370 281 238 minecraft:white_concrete
fill 357 280 262 370 281 262 minecraft:white_concrete
fill 358 280 239 370 280 239 minecraft:white_concrete
fill 358 280 261 370 280 261 minecraft:white_concrete
fill 359 280 240 370 281 240 minecraft:white_concrete
fill 359 280 260 370 281 260 minecraft:white_concrete
fill 360 280 241 370 280 242 minecraft:white_concrete
fill 360 280 258 370 280 259 minecraft:white_concrete
fill 361 280 243 370 280 244 minecraft:white_concrete
fill 361 280 256 370 280 257 minecraft:white_concrete
fill 362 280 245 370 280 248 minecraft:white_concrete
fill 362 280 252 370 280 255 minecraft:white_concrete
fill 363 280 249 370 281 251 minecraft:white_concrete
setblock 371 280 257 minecraft:stone_bricks
fill 329 281 228 329 281 229 minecraft:light_blue_concrete
fill 329 281 230 329 281 231 minecraft:white_concrete
fill 329 281 232 329 281 233 minecraft:light_blue_concrete
fill 329 281 234 329 281 235 minecraft:white_concrete
fill 329 281 236 329 281 237 minecraft:light_blue_concrete
fill 329 281 238 329 281 239 minecraft:white_concrete
fill 329 281 240 329 281 241 minecraft:light_blue_concrete
fill 329 281 242 329 281 243 minecraft:white_concrete
fill 329 281 244 329 281 245 minecraft:light_blue_concrete
fill 329 281 246 329 281 247 minecraft:white_concrete
fill 329 281 248 329 281 249 minecraft:light_blue_concrete
fill 329 281 250 329 281 251 minecraft:white_concrete
fill 329 281 252 329 281 253 minecraft:light_blue_concrete
fill 329 281 254 329 281 255 minecraft:white_concrete
fill 329 281 256 329 281 257 minecraft:light_blue_concrete
fill 329 281 258 329 281 259 minecraft:white_concrete
fill 329 281 260 329 281 261 minecraft:light_blue_concrete
fill 329 281 262 329 281 263 minecraft:white_concrete
fill 329 281 264 329 281 265 minecraft:light_blue_concrete
fill 329 281 266 329 281 267 minecraft:white_concrete
fill 329 281 268 329 281 270 minecraft:light_blue_concrete
setblock 330 281 228 minecraft:light_blue_concrete
setblock 330 281 270 minecraft:light_blue_concrete
fill 331 281 228 332 281 228 minecraft:white_concrete
fill 331 281 270 332 281 270 minecraft:white_concrete
fill 333 281 228 334 281 228 minecraft:light_blue_concrete
fill 333 281 270 334 281 270 minecraft:light_blue_concrete
fill 335 281 228 336 281 228 minecraft:white_concrete
fill 335 281 270 336 281 270 minecraft:white_concrete
fill 337 281 228 338 281 228 minecraft:light_blue_concrete
fill 337 281 270 338 281 270 minecraft:light_blue_concrete
fill 338 281 229 338 281 245 minecraft:white_concrete
fill 338 281 255 338 281 269 minecraft:white_concrete
fill 339 281 228 339 281 243 minecraft:white_concrete
fill 339 281 257 339 281 270 minecraft:white_concrete
fill 340 281 228 340 281 241 minecraft:white_concrete
fill 340 281 255 341 282 255 minecraft:white_stained_glass
fill 340 281 259 340 281 270 minecraft:white_concrete
fill 341 281 228 342 281 228 minecraft:light_blue_concrete
fill 341 281 254 341 282 254 minecraft:white_stained_glass
fill 341 281 256 341 282 256 minecraft:white_stained_glass
fill 341 281 270 342 281 270 minecraft:light_blue_concrete
fill 342 281 229 342 281 238 minecraft:white_concrete
fill 342 281 262 342 281 269 minecraft:white_concrete
fill 343 281 228 344 281 228 minecraft:white_concrete
fill 343 281 270 344 281 270 minecraft:white_concrete
fill 344 281 229 344 281 237 minecraft:white_concrete
fill 344 281 263 344 281 269 minecraft:white_concrete
fill 345 281 228 346 281 228 minecraft:light_blue_concrete
fill 345 281 229 347 281 236 minecraft:white_concrete
fill 345 281 264 347 281 269 minecraft:white_concrete
fill 345 281 270 346 281 270 minecraft:light_blue_concrete
fill 347 281 228 348 281 228 minecraft:white_concrete
fill 347 281 270 348 281 270 minecraft:white_concrete
fill 348 281 229 370 281 235 minecraft:white_concrete
fill 348 281 265 370 281 269 minecraft:white_concrete
fill 349 281 228 350 281 228 minecraft:light_blue_concrete
fill 349 281 270 350 281 270 minecraft:light_blue_concrete
fill 351 281 228 352 281 228 minecraft:white_concrete
fill 351 281 270 352 281 270 minecraft:white_concrete
fill 353 281 228 354 281 228 minecraft:light_blue_concrete
fill 353 281 236 370 281 236 minecraft:white_concrete
fill 353 281 264 370 281 264 minecraft:white_concrete
fill 353 281 270 354 281 270 minecraft:light_blue_concrete
fill 355 281 228 356 281 228 minecraft:white_concrete
fill 355 281 270 356 281 270 minecraft:white_concrete
fill 356 281 237 370 281 237 minecraft:white_concrete
fill 356 281 263 371 281 263 minecraft:white_concrete
fill 357 281 228 358 281 228 minecraft:light_blue_concrete
fill 357 281 270 358 281 270 minecraft:light_blue_concrete
fill 359 281 228 360 281 228 minecraft:white_concrete
fill 359 281 239 371 281 239 minecraft:white_concrete
fill 359 281 261 370 281 261 minecraft:white_concrete
fill 359 281 270 360 281 270 minecraft:white_concrete
fill 360 281 241 370 281 241 minecraft:white_concrete
fill 360 281 259 371 281 259 minecraft:white_concrete
fill 361 281 228 362 281 228 minecraft:light_blue_concrete
fill 361 281 242 371 281 243 minecraft:white_concrete
fill 361 281 257 370 281 258 minecraft:white_concrete
fill 361 281 270 362 281 270 minecraft:light_blue_concrete
fill 362 281 244 370 281 245 minecraft:white_concrete
fill 362 281 255 370 281 256 minecraft:white_concrete
fill 363 281 228 364 281 228 minecraft:white_concrete
fill 363 281 246 370 281 248 minecraft:white_concrete
fill 363 281 252 370 281 254 minecraft:white_concrete
fill 363 281 270 364 281 270 minecraft:white_concrete
fill 365 281 228 366 281 228 minecraft:light_blue_concrete
fill 365 281 270 366 281 270 minecraft:light_blue_concrete
fill 367 281 228 368 281 228 minecraft:white_concrete
fill 367 281 270 368 281 270 minecraft:white_concrete
fill 369 281 228 371 281 228 minecraft:light_blue_concrete
fill 369 281 270 370 281 270 minecraft:light_blue_concrete
setblock 371 281 229 minecraft:light_blue_concrete
fill 371 281 230 371 281 231 minecraft:white_concrete
fill 371 281 232 371 281 233 minecraft:light_blue_concrete
fill 371 281 234 371 281 235 minecraft:white_concrete
fill 371 281 236 371 281 237 minecraft:light_blue_concrete
setblock 371 281 238 minecraft:white_concrete
fill 371 281 240 371 281 241 minecraft:light_blue_concrete
fill 371 281 244 371 281 245 minecraft:light_blue_concrete
fill 371 281 246 371 281 247 minecraft:white_concrete
fill 371 281 248 371 281 249 minecraft:light_blue_concrete
fill 371 281 250 371 281 251 minecraft:white_concrete
fill 371 281 252 371 281 253 minecraft:light_blue_concrete
fill 371 281 254 371 281 255 minecraft:white_concrete
fill 371 281 256 371 281 257 minecraft:light_blue_concrete
setblock 371 281 258 minecraft:white_concrete
fill 371 281 260 371 281 261 minecraft:light_blue_concrete
setblock 371 281 262 minecraft:white_concrete
fill 371 281 264 371 281 265 minecraft:light_blue_concrete
fill 371 281 266 371 281 267 minecraft:white_concrete
fill 371 281 268 371 281 269 minecraft:light_blue_concrete
setblock 371 281 270 minecraft:white_concrete
fill 329 282 228 329 283 229 minecraft:white_concrete
fill 329 282 230 329 283 231 minecraft:light_blue_concrete
fill 329 282 232 329 283 233 minecraft:white_concrete
fill 329 282 234 329 283 235 minecraft:light_blue_concrete
fill 329 282 236 329 283 237 minecraft:white_concrete
fill 329 282 238 329 283 239 minecraft:light_blue_concrete
fill 329 282 240 329 283 241 minecraft:white_concrete
fill 329 282 242 329 283 243 minecraft:light_blue_concrete
fill 329 282 244 329 283 245 minecraft:white_concrete
fill 329 282 246 329 283 247 minecraft:light_blue_concrete
fill 329 282 248 329 283 249 minecraft:white_concrete
fill 329 282 250 329 283 251 minecraft:light_blue_concrete
fill 329 282 252 329 283 253 minecraft:white_concrete
fill 329 282 254 329 283 255 minecraft:light_blue_concrete
fill 329 282 256 329 283 257 minecraft:white_concrete
fill 329 282 258 329 283 259 minecraft:light_blue_concrete
fill 329 282 260 329 283 261 minecraft:white_concrete
fill 329 282 262 329 283 263 minecraft:light_blue_concrete
fill 329 282 264 329 283 265 minecraft:white_concrete
fill 329 282 266 329 283 267 minecraft:light_blue_concrete
fill 329 282 268 329 283 269 minecraft:white_concrete
fill 329 282 270 329 308 270 minecraft:light_blue_concrete
fill 330 282 228 330 283 228 minecraft:white_concrete
fill 330 282 229 337 282 269 minecraft:smooth_quartz
fill 330 282 270 330 283 270 minecraft:white_concrete
fill 331 282 228 332 283 228 minecraft:light_blue_concrete
fill 331 282 270 332 283 270 minecraft:light_blue_concrete
fill 333 282 228 334 283 228 minecraft:white_concrete
fill 333 282 270 334 283 270 minecraft:white_concrete
fill 335 282 228 336 283 228 minecraft:light_blue_concrete
fill 335 282 270 336 283 270 minecraft:light_blue_concrete
fill 337 282 228 338 283 228 minecraft:white_concrete
fill 337 282 270 338 283 270 minecraft:white_concrete
fill 338 282 229 338 282 244 minecraft:smooth_quartz
fill 338 282 256 338 282 269 minecraft:smooth_quartz
fill 339 282 228 340 283 228 minecraft:light_blue_concrete
fill 339 282 229 339 282 242 minecraft:smooth_quartz
fill 339 282 258 339 282 269 minecraft:smooth_quartz
fill 339 282 270 340 283 270 minecraft:light_blue_concrete
fill 340 282 229 340 282 240 minecraft:smooth_quartz
fill 340 282 260 340 282 269 minecraft:smooth_quartz
fill 341 282 228 342 283 228 minecraft:white_concrete
fill 341 282 229 341 282 239 minecraft:smooth_quartz
fill 341 282 261 341 282 269 minecraft:smooth_quartz
fill 341 282 270 342 283 270 minecraft:white_concrete
fill 342 282 229 342 282 238 minecraft:smooth_quartz
fill 342 282 262 342 282 269 minecraft:smooth_quartz
fill 343 282 228 344 283 228 minecraft:light_blue_concrete
fill 343 282 229 343 282 237 minecraft:smooth_quartz
fill 343 282 263 343 282 269 minecraft:smooth_quartz
fill 343 282 270 344 283 270 minecraft:light_blue_concrete
fill 344 282 229 345 282 236 minecraft:smooth_quartz
fill 344 282 264 345 282 269 minecraft:smooth_quartz
fill 345 282 228 346 283 228 minecraft:white_concrete
fill 345 282 270 346 283 270 minecraft:white_concrete
fill 346 282 229 370 282 235 minecraft:smooth_quartz
fill 346 282 265 370 282 269 minecraft:smooth_quartz
fill 347 282 228 348 283 228 minecraft:light_blue_concrete
fill 347 282 270 348 283 270 minecraft:light_blue_concrete
fill 349 282 228 350 283 228 minecraft:white_concrete
fill 349 282 270 350 283 270 minecraft:white_concrete
fill 351 282 228 352 283 228 minecraft:light_blue_concrete
fill 351 282 270 352 283 270 minecraft:light_blue_concrete
fill 353 282 228 354 283 228 minecraft:white_concrete
fill 353 282 270 354 283 270 minecraft:white_concrete
fill 355 282 228 356 283 228 minecraft:light_blue_concrete
fill 355 282 236 370 282 236 minecraft:smooth_quartz
fill 355 282 264 370 282 264 minecraft:smooth_quartz
fill 355 282 270 356 283 270 minecraft:light_blue_concrete
fill 357 282 228 358 283 228 minecraft:white_concrete
fill 357 282 237 370 282 237 minecraft:smooth_quartz
fill 357 282 263 370 282 263 minecraft:smooth_quartz
fill 357 282 270 358 283 270 minecraft:white_concrete
fill 358 282 238 370 282 238 minecraft:smooth_quartz
fill 358 282 262 370 282 262 minecraft:smooth_quartz
fill 359 282 228 360 283 228 minecraft:light_blue_concrete
fill 359 282 239 370 282 239 minecraft:smooth_quartz
fill 359 282 261 370 282 261 minecraft:smooth_quartz
fill 359 282 270 360 283 270 minecraft:light_blue_concrete
fill 360 282 240 370 282 240 minecraft:smooth_quartz
fill 360 282 260 370 282 260 minecraft:smooth_quartz
fill 361 282 228 362 283 228 minecraft:white_concrete
fill 361 282 241 370 282 242 minecraft:smooth_quartz
fill 361 282 258 370 282 259 minecraft:smooth_quartz
fill 361 282 270 362 283 270 minecraft:white_concrete
fill 362 282 243 370 282 244 minecraft:smooth_quartz
fill 362 282 256 370 282 257 minecraft:smooth_quartz
fill 363 282 228 364 283 228 minecraft:light_blue_concrete
fill 363 282 245 370 282 255 minecraft:smooth_quartz
fill 363 282 270 364 283 270 minecraft:light_blue_concrete
fill 365 282 228 366 283 228 minecraft:white_concrete
fill 365 282 270 366 283 270 minecraft:white_concrete
fill 367 282 228 368 283 228 minecraft:light_blue_concrete
fill 367 282 270 368 283 270 minecraft:light_blue_concrete
fill 369 282 228 370 283 228 minecraft:white_concrete
fill 369 282 270 370 283 270 minecraft:white_concrete
fill 371 282 228 371 308 228 minecraft:light_blue_concrete
fill 371 282 229 371 283 229 minecraft:white_concrete
fill 371 282 230 371 283 231 minecraft:light_blue_concrete
fill 371 282 232 371 283 233 minecraft:white_concrete
fill 371 282 234 371 283 235 minecraft:light_blue_concrete
fill 371 282 236 371 283 237 minecraft:white_concrete
fill 371 282 238 371 283 239 minecraft:light_blue_concrete
fill 371 282 240 371 283 241 minecraft:white_concrete
fill 371 282 242 371 283 243 minecraft:light_blue_concrete
fill 371 282 244 371 283 245 minecraft:white_concrete
fill 371 282 246 371 283 247 minecraft:light_blue_concrete
fill 371 282 248 371 283 249 minecraft:white_concrete
fill 371 282 250 371 283 251 minecraft:light_blue_concrete
fill 371 282 252 371 283 253 minecraft:white_concrete
fill 371 282 254 371 283 255 minecraft:light_blue_concrete
fill 371 282 256 371 283 257 minecraft:white_concrete
fill 371 282 258 371 283 259 minecraft:light_blue_concrete
fill 371 282 260 371 283 261 minecraft:white_concrete
fill 371 282 262 371 283 263 minecraft:light_blue_concrete
fill 371 282 264 371 283 265 minecraft:white_concrete
fill 371 282 266 371 283 267 minecraft:light_blue_concrete
fill 371 282 268 371 283 269 minecraft:white_concrete
fill 371 282 270 371 283 270 minecraft:light_blue_concrete
fill 330 283 229 336 284 269 minecraft:white_concrete
fill 337 283 229 337 283 246 minecraft:white_concrete
fill 337 283 254 337 283 269 minecraft:white_concrete
fill 338 283 229 338 283 243 minecraft:white_concrete
fill 338 283 257 338 283 269 minecraft:white_concrete
fill 339 283 229 339 283 241 minecraft:white_concrete
setblock 339 283 245 minecraft:light[level=12]
setblock 339 283 252 minecraft:light[level=12]
fill 339 283 259 339 283 269 minecraft:white_concrete
fill 340 283 229 340 284 239 minecraft:white_concrete
fill 340 283 261 340 284 269 minecraft:white_concrete
fill 341 283 229 341 284 238 minecraft:white_concrete
fill 341 283 262 341 284 269 minecraft:white_concrete
fill 342 283 229 342 284 237 minecraft:white_concrete
fill 342 283 263 342 284 269 minecraft:white_concrete
fill 343 283 229 344 283 236 minecraft:white_concrete
fill 343 283 264 344 283 269 minecraft:white_concrete
fill 345 283 229 347 283 235 minecraft:white_concrete
fill 345 283 265 347 283 269 minecraft:white_concrete
setblock 346 283 238 minecraft:light[level=12]
setblock 346 283 245 minecraft:light[level=12]
setblock 346 283 252 minecraft:light[level=12]
setblock 346 283 259 minecraft:light[level=12]
fill 348 283 229 370 284 234 minecraft:white_concrete
fill 348 283 266 370 284 269 minecraft:white_concrete
fill 353 283 235 370 283 235 minecraft:white_concrete
setblock 353 283 238 minecraft:light[level=12]
setblock 353 283 245 minecraft:light[level=12]
setblock 353 283 252 minecraft:light[level=12]
setblock 353 283 259 minecraft:light[level=12]
fill 353 283 265 370 283 265 minecraft:white_concrete
fill 356 283 236 370 283 236 minecraft:white_concrete
fill 356 283 264 370 283 264 minecraft:white_concrete
fill 358 283 237 370 284 237 minecraft:white_concrete
fill 358 283 263 370 284 263 minecraft:white_concrete
fill 359 283 238 370 284 238 minecraft:white_concrete
fill 359 283 262 370 284 262 minecraft:white_concrete
fill 360 283 239 370 284 239 minecraft:white_concrete
setblock 360 283 245 minecraft:light[level=12]
setblock 360 283 252 minecraft:light[level=12]
setblock 360 283 259 minecraft:light[level=12]
fill 360 283 261 370 284 261 minecraft:white_concrete
fill 361 283 240 370 283 241 minecraft:white_concrete
fill 361 283 259 370 283 260 minecraft:white_concrete
fill 362 283 242 370 283 243 minecraft:white_concrete
fill 362 283 257 370 283 258 minecraft:white_concrete
fill 363 283 244 370 283 246 minecraft:white_concrete
fill 363 283 247 363 284 247 minecraft:white_stained_glass
fill 363 283 254 370 283 256 minecraft:white_concrete
fill 364 283 247 370 284 253 minecraft:white_concrete
fill 329 284 228 329 285 229 minecraft:light_blue_concrete
fill 329 284 230 329 285 231 minecraft:white_concrete
fill 329 284 232 329 285 233 minecraft:light_blue_concrete
fill 329 284 234 329 285 235 minecraft:white_concrete
fill 329 284 236 329 285 237 minecraft:light_blue_concrete
fill 329 284 238 329 285 239 minecraft:white_concrete
fill 329 284 240 329 285 241 minecraft:light_blue_concrete
fill 329 284 242 329 285 243 minecraft:white_concrete
fill 329 284 244 329 285 245 minecraft:light_blue_concrete
fill 329 284 246 329 285 247 minecraft:white_concrete
fill 329 284 248 329 285 249 minecraft:light_blue_concrete
fill 329 284 250 329 285 251 minecraft:white_concrete
fill 329 284 252 329 285 253 minecraft:light_blue_concrete
fill 329 284 254 329 285 255 minecraft:white_concrete
fill 329 284 256 329 285 257 minecraft:light_blue_concrete
fill 329 284 258 329 285 259 minecraft:white_concrete
fill 329 284 260 329 285 261 minecraft:light_blue_concrete
fill 329 284 262 329 285 263 minecraft:white_concrete
fill 329 284 264 329 285 265 minecraft:light_blue_concrete
fill 329 284 266 329 285 267 minecraft:white_concrete
fill 329 284 268 329 285 269 minecraft:light_blue_concrete
fill 330 284 228 330 285 228 minecraft:light_blue_concrete
fill 330 284 270 330 285 270 minecraft:light_blue_concrete
fill 331 284 228 332 285 228 minecraft:white_concrete
fill 331 284 270 332 285 270 minecraft:white_concrete
fill 333 284 228 334 285 228 minecraft:light_blue_concrete
fill 333 284 270 334 285 270 minecraft:light_blue_concrete
fill 335 284 228 336 285 228 minecraft:white_concrete
fill 335 284 270 336 285 270 minecraft:white_concrete
fill 337 284 228 338 285 228 minecraft:light_blue_concrete
fill 337 284 229 337 284 244 minecraft:white_concrete
fill 337 284 256 337 284 269 minecraft:white_concrete
fill 337 284 270 338 285 270 minecraft:light_blue_concrete
fill 338 284 229 338 284 242 minecraft:white_concrete
fill 338 284 258 338 284 269 minecraft:white_concrete
fill 339 284 228 339 284 240 minecraft:white_concrete
fill 339 284 260 339 284 270 minecraft:white_concrete
fill 340 284 228 340 285 228 minecraft:white_concrete
fill 340 284 270 340 285 270 minecraft:white_concrete
fill 341 284 228 342 285 228 minecraft:light_blue_concrete
fill 341 284 270 342 285 270 minecraft:light_blue_concrete
fill 343 284 228 343 284 236 minecraft:white_concrete
fill 343 284 264 343 284 270 minecraft:white_concrete
fill 344 284 228 344 284 235 minecraft:white_concrete
fill 344 284 265 344 284 270 minecraft:white_concrete
fill 345 284 228 346 285 228 minecraft:light_blue_concrete
fill 345 284 229 345 284 235 minecraft:white_concrete
fill 345 284 265 345 284 269 minecraft:white_concrete
fill 345 284 270 346 285 270 minecraft:light_blue_concrete
fill 346 284 229 347 284 234 minecraft:white_concrete
fill 346 284 266 347 284 269 minecraft:white_concrete
fill 347 284 228 348 285 228 minecraft:white_concrete
fill 347 284 270 348 285 270 minecraft:white_concrete
fill 349 284 228 350 285 228 minecraft:light_blue_concrete
fill 349 284 270 350 285 270 minecraft:light_blue_concrete
fill 351 284 228 352 285 228 minecraft:white_concrete
fill 351 284 270 352 285 270 minecraft:white_concrete
fill 353 284 228 354 285 228 minecraft:light_blue_concrete
fill 353 284 270 354 285 270 minecraft:light_blue_concrete
fill 355 284 228 356 285 228 minecraft:white_concrete
fill 355 284 235 371 284 235 minecraft:white_concrete
fill 355 284 265 370 284 265 minecraft:white_concrete
fill 355 284 270 356 285 270 minecraft:white_concrete
fill 357 284 228 358 285 228 minecraft:light_blue_concrete
fill 357 284 236 370 284 236 minecraft:white_concrete
fill 357 284 264 370 284 264 minecraft:white_concrete
fill 357 284 270 358 285 270 minecraft:light_blue_concrete
fill 359 284 228 360 285 228 minecraft:white_concrete
fill 359 284 270 360 285 270 minecraft:white_concrete
fill 361 284 228 362 285 228 minecraft:light_blue_concrete
fill 361 284 240 370 284 240 minecraft:white_concrete
fill 361 284 260 370 284 260 minecraft:white_concrete
fill 361 284 270 362 285 270 minecraft:light_blue_concrete
fill 362 284 241 370 284 242 minecraft:white_concrete
fill 362 284 258 371 284 259 minecraft:white_concrete
fill 363 284 228 364 285 228 minecraft:white_concrete
fill 363 284 243 370 284 244 minecraft:white_concrete
fill 363 284 256 370 284 257 minecraft:white_concrete
fill 363 284 270 364 285 270 minecraft:white_concrete
fill 364 284 245 370 284 246 minecraft:white_concrete
fill 364 284 254 371 284 255 minecraft:white_concrete
fill 365 284 228 366 285 228 minecraft:light_blue_concrete
fill 365 284 270 366 285 270 minecraft:light_blue_concrete
fill 367 284 228 368 285 228 minecraft:white_concrete
fill 367 284 270 368 285 270 minecraft:white_concrete
fill 369 284 228 370 285 228 minecraft:light_blue_concrete
fill 369 284 270 370 285 270 minecraft:light_blue_concrete
fill 371 284 229 371 285 229 minecraft:light_blue_concrete
fill 371 284 230 371 285 231 minecraft:white_concrete
fill 371 284 232 371 285 233 minecraft:light_blue_concrete
fill 371 284 234 371 285 234 minecraft:white_concrete
fill 371 284 236 371 285 237 minecraft:light_blue_concrete
fill 371 284 238 371 285 239 minecraft:white_concrete
fill 371 284 240 371 285 241 minecraft:light_blue_concrete
fill 371 284 242 371 285 243 minecraft:white_concrete
fill 371 284 244 371 285 245 minecraft:light_blue_concrete
fill 371 284 246 371 285 247 minecraft:white_concrete
fill 371 284 248 371 285 249 minecraft:light_blue_concrete
fill 371 284 250 371 285 251 minecraft:white_concrete
fill 371 284 252 371 285 253 minecraft:light_blue_concrete
fill 371 284 256 371 285 257 minecraft:light_blue_concrete
fill 371 284 260 371 285 261 minecraft:light_blue_concrete
fill 371 284 262 371 285 263 minecraft:white_concrete
fill 371 284 264 371 285 265 minecraft:light_blue_concrete
fill 371 284 266 371 285 267 minecraft:white_concrete
fill 371 284 268 371 285 269 minecraft:light_blue_concrete
fill 371 284 270 371 285 270 minecraft:white_concrete
setblock 332 285 262 minecraft:light_gray_concrete
fill 332 285 263 334 300 263 minecraft:iron_block
setblock 332 285 264 minecraft:light_gray_concrete
fill 333 285 262 333 300 262 minecraft:iron_block
fill 333 285 264 333 300 264 minecraft:iron_block
fill 334 285 229 341 299 233 minecraft:white_concrete
fill 334 285 244 337 285 256 minecraft:light_gray_concrete
setblock 334 285 262 minecraft:light_gray_concrete
setblock 334 285 264 minecraft:light_gray_concrete
fill 335 285 241 339 285 243 minecraft:light_gray_concrete
fill 335 285 257 339 285 259 minecraft:light_gray_concrete
fill 336 285 240 341 285 240 minecraft:light_gray_concrete
fill 336 285 260 341 285 260 minecraft:light_gray_concrete
fill 337 285 238 342 285 239 minecraft:light_gray_concrete
fill 337 285 261 342 285 262 minecraft:light_gray_concrete
fill 338 285 237 346 285 237 minecraft:light_gray_concrete
fill 338 285 244 338 285 248 minecraft:light_gray_concrete
fill 338 285 252 338 285 256 minecraft:light_gray_concrete
fill 338 285 263 346 285 263 minecraft:light_gray_concrete
setblock 339 285 228 minecraft:white_concrete
fill 339 285 236 361 285 236 minecraft:light_gray_concrete
setblock 339 285 244 minecraft:light_gray_concrete
setblock 339 285 256 minecraft:light_gray_concrete
fill 339 285 264 361 285 264 minecraft:light_gray_concrete
setblock 339 285 270 minecraft:white_concrete
fill 340 285 235 360 285 235 minecraft:light_gray_concrete
fill 340 285 241 340 285 242 minecraft:light_gray_concrete
fill 340 285 258 340 285 259 minecraft:light_gray_concrete
fill 340 285 265 360 285 265 minecraft:light_gray_concrete
fill 341 285 234 359 285 234 minecraft:light_gray_concrete
fill 341 285 266 359 285 266 minecraft:light_gray_concrete
fill 342 285 229 343 299 232 minecraft:white_concrete
fill 342 285 233 358 285 233 minecraft:light_gray_concrete
fill 342 285 267 358 285 267 minecraft:light_gray_concrete
fill 343 285 228 344 285 228 minecraft:white_concrete
fill 343 285 238 344 285 238 minecraft:light_gray_concrete
fill 343 285 262 344 285 262 minecraft:light_gray_concrete
fill 343 285 270 344 285 270 minecraft:white_concrete
fill 344 285 229 346 299 231 minecraft:white_concrete
fill 344 285 232 356 285 232 minecraft:light_gray_concrete
fill 344 285 268 356 285 268 minecraft:light_gray_concrete
fill 347 285 229 366 299 230 minecraft:white_concrete
fill 347 285 231 353 285 231 minecraft:light_gray_concrete
fill 347 285 269 353 285 269 minecraft:light_gray_concrete
fill 354 285 231 366 299 231 minecraft:white_concrete
fill 354 285 237 362 285 237 minecraft:light_gray_concrete
fill 354 285 263 362 285 263 minecraft:light_gray_concrete
fill 356 285 238 363 285 238 minecraft:light_gray_concrete
fill 356 285 262 363 285 262 minecraft:light_gray_concrete
fill 357 285 232 366 299 232 minecraft:white_concrete
fill 358 285 239 363 285 239 minecraft:light_gray_concrete
fill 358 285 261 363 285 261 minecraft:light_gray_concrete
fill 359 285 233 366 299 233 minecraft:white_concrete
fill 359 285 240 364 285 240 minecraft:light_gray_concrete
fill 359 285 260 364 285 260 minecraft:light_gray_concrete
fill 360 285 241 365 285 242 minecraft:light_gray_concrete
fill 360 285 258 365 285 259 minecraft:light_gray_concrete
fill 361 285 243 365 285 244 minecraft:light_gray_concrete
fill 361 285 256 365 285 257 minecraft:light_gray_concrete
fill 362 285 245 366 285 248 minecraft:light_gray_concrete
fill 362 285 252 366 285 255 minecraft:light_gray_concrete
fill 363 285 249 366 285 251 minecraft:light_gray_concrete
setblock 366 285 244 minecraft:light_gray_concrete
setblock 366 285 256 minecraft:light_gray_concrete
setblock 371 285 235 minecraft:white_concrete
fill 371 285 254 371 285 255 minecraft:white_concrete
fill 371 285 258 371 285 259 minecraft:white_concrete
fill 329 286 228 329 287 229 minecraft:white_concrete
fill 329 286 230 329 287 231 minecraft:light_blue_concrete
fill 329 286 232 329 287 233 minecraft:white_concrete
fill 329 286 234 329 287 235 minecraft:light_blue_concrete
fill 329 286 236 329 287 237 minecraft:white_concrete
fill 329 286 238 329 287 239 minecraft:light_blue_concrete
fill 329 286 240 329 287 241 minecraft:white_concrete
fill 329 286 242 329 287 243 minecraft:light_blue_concrete
fill 329 286 244 329 287 245 minecraft:white_concrete
fill 329 286 246 329 287 247 minecraft:light_blue_concrete
fill 329 286 248 329 287 249 minecraft:white_concrete
fill 329 286 250 329 287 251 minecraft:light_blue_concrete
fill 329 286 252 329 287 253 minecraft:white_concrete
fill 329 286 254 329 287 255 minecraft:light_blue_concrete
fill 329 286 256 329 287 257 minecraft:white_concrete
fill 329 286 258 329 287 259 minecraft:light_blue_concrete
fill 329 286 260 329 287 261 minecraft:white_concrete
fill 329 286 262 329 287 263 minecraft:light_blue_concrete
fill 329 286 264 329 287 265 minecraft:white_concrete
fill 329 286 266 329 287 267 minecraft:light_blue_concrete
fill 329 286 268 329 287 269 minecraft:white_concrete
fill 330 286 228 330 287 228 minecraft:white_concrete
fill 330 286 263 331 287 263 minecraft:iron_block
fill 330 286 270 330 287 270 minecraft:white_concrete
fill 331 286 228 332 287 228 minecraft:light_blue_concrete
fill 331 286 270 332 287 270 minecraft:light_blue_concrete
setblock 332 286 231 minecraft:light[level=15]
setblock 332 286 239 minecraft:light[level=15]
setblock 332 286 247 minecraft:light[level=15]
setblock 332 286 255 minecraft:light[level=15]
fill 333 286 228 334 287 228 minecraft:white_concrete
fill 333 286 270 334 287 270 minecraft:white_concrete
fill 335 286 228 336 287 228 minecraft:light_blue_concrete
fill 335 286 270 336 287 270 minecraft:light_blue_concrete
fill 337 286 228 338 287 228 minecraft:white_concrete
fill 337 286 270 338 287 270 minecraft:white_concrete
fill 339 286 228 340 287 228 minecraft:light_blue_concrete
fill 339 286 270 340 287 270 minecraft:light_blue_concrete
setblock 340 286 239 minecraft:light[level=15]
setblock 340 286 247 minecraft:light[level=15]
setblock 340 286 255 minecraft:light[level=15]
setblock 340 286 263 minecraft:light[level=15]
fill 341 286 228 342 287 228 minecraft:white_concrete
fill 341 286 270 342 287 270 minecraft:white_concrete
fill 342 286 233 358 299 233 minecraft:white_concrete
fill 343 286 228 344 287 228 minecraft:light_blue_concrete
fill 343 286 270 344 287 270 minecraft:light_blue_concrete
fill 344 286 232 356 299 232 minecraft:white_concrete
fill 345 286 228 346 287 228 minecraft:white_concrete
fill 345 286 270 346 287 270 minecraft:white_concrete
fill 347 286 228 348 287 228 minecraft:light_blue_concrete
fill 347 286 231 353 299 231 minecraft:white_concrete
fill 347 286 235 353 303 235 minecraft:white_terracotta
fill 347 286 270 348 287 270 minecraft:light_blue_concrete
setblock 348 286 239 minecraft:light[level=15]
setblock 348 286 247 minecraft:light[level=15]
setblock 348 286 255 minecraft:light[level=15]
setblock 348 286 263 minecraft:light[level=15]
fill 349 286 228 350 287 228 minecraft:white_concrete
fill 349 286 270 350 287 270 minecraft:white_concrete
fill 351 286 228 352 287 228 minecraft:light_blue_concrete
fill 351 286 270 352 287 270 minecraft:light_blue_concrete
fill 353 286 228 354 287 228 minecraft:white_concrete
fill 353 286 270 354 287 270 minecraft:white_concrete
fill 355 286 228 356 287 228 minecraft:light_blue_concrete
fill 355 286 270 356 287 270 minecraft:light_blue_concrete
setblock 356 286 239 minecraft:light[level=15]
setblock 356 286 247 minecraft:light[level=15]
setblock 356 286 255 minecraft:light[level=15]
setblock 356 286 263 minecraft:light[level=15]
fill 357 286 228 358 287 228 minecraft:white_concrete
fill 357 286 270 358 287 270 minecraft:white_concrete
fill 359 286 228 360 287 228 minecraft:light_blue_concrete
fill 359 286 270 360 287 270 minecraft:light_blue_concrete
fill 361 286 228 362 287 228 minecraft:white_concrete
fill 361 286 270 362 287 270 minecraft:white_concrete
fill 363 286 228 364 287 228 minecraft:light_blue_concrete
fill 363 286 270 364 287 270 minecraft:light_blue_concrete
setblock 364 286 239 minecraft:light[level=15]
setblock 364 286 247 minecraft:light[level=15]
setblock 364 286 255 minecraft:light[level=15]
setblock 364 286 263 minecraft:light[level=15]
fill 365 286 228 366 287 228 minecraft:white_concrete
fill 365 286 270 366 287 270 minecraft:white_concrete
fill 367 286 228 368 287 228 minecraft:light_blue_concrete
fill 367 286 270 368 287 270 minecraft:light_blue_concrete
fill 369 286 228 370 287 228 minecraft:white_concrete
fill 369 286 270 370 287 270 minecraft:white_concrete
fill 371 286 229 371 287 229 minecraft:white_concrete
fill 371 286 230 371 287 231 minecraft:light_blue_concrete
fill 371 286 232 371 287 233 minecraft:white_concrete
fill 371 286 234 371 287 235 minecraft:light_blue_concrete
fill 371 286 236 371 287 237 minecraft:white_concrete
fill 371 286 238 371 287 239 minecraft:light_blue_concrete
fill 371 286 240 371 287 241 minecraft:white_concrete
fill 371 286 242 371 287 243 minecraft:light_blue_concrete
fill 371 286 244 371 287 245 minecraft:white_concrete
fill 371 286 246 371 287 247 minecraft:light_blue_concrete
fill 371 286 248 371 287 249 minecraft:white_concrete
fill 371 286 250 371 287 251 minecraft:light_blue_concrete
fill 371 286 252 371 287 253 minecraft:white_concrete
fill 371 286 254 371 287 255 minecraft:light_blue_concrete
fill 371 286 256 371 287 257 minecraft:white_concrete
fill 371 286 258 371 287 259 minecraft:light_blue_concrete
fill 371 286 260 371 287 261 minecraft:white_concrete
fill 371 286 262 371 287 263 minecraft:light_blue_concrete
fill 371 286 264 371 287 265 minecraft:white_concrete
fill 371 286 266 371 287 267 minecraft:light_blue_concrete
fill 371 286 268 371 287 269 minecraft:white_concrete
fill 371 286 270 371 287 270 minecraft:light_blue_concrete
setblock 335 287 263 minecraft:sea_lantern
fill 344 287 235 346 303 235 minecraft:white_terracotta
fill 354 287 235 356 303 235 minecraft:white_terracotta
fill 329 288 228 329 289 229 minecraft:light_blue_concrete
fill 329 288 230 329 289 231 minecraft:white_concrete
fill 329 288 232 329 289 233 minecraft:light_blue_concrete
fill 329 288 234 329 289 235 minecraft:white_concrete
fill 329 288 236 329 289 237 minecraft:light_blue_concrete
fill 329 288 238 329 289 239 minecraft:white_concrete
fill 329 288 240 329 289 241 minecraft:light_blue_concrete
fill 329 288 242 329 289 243 minecraft:white_concrete
fill 329 288 244 329 289 245 minecraft:light_blue_concrete
fill 329 288 246 329 289 247 minecraft:white_concrete
fill 329 288 248 329 289 249 minecraft:light_blue_concrete
fill 329 288 250 329 289 251 minecraft:white_concrete
fill 329 288 252 329 289 253 minecraft:light_blue_concrete
fill 329 288 254 329 289 255 minecraft:white_concrete
fill 329 288 256 329 289 257 minecraft:light_blue_concrete
fill 329 288 258 329 289 259 minecraft:white_concrete
fill 329 288 260 329 289 261 minecraft:light_blue_concrete
fill 329 288 262 329 289 263 minecraft:white_concrete
fill 329 288 264 329 289 265 minecraft:light_blue_concrete
fill 329 288 266 329 289 267 minecraft:white_concrete
fill 329 288 268 329 289 269 minecraft:light_blue_concrete
fill 330 288 228 330 289 228 minecraft:light_blue_concrete
fill 330 288 270 330 289 270 minecraft:light_blue_concrete
fill 331 288 228 332 289 228 minecraft:white_concrete
fill 331 288 270 332 289 270 minecraft:white_concrete
fill 333 288 228 334 289 228 minecraft:light_blue_concrete
fill 333 288 270 334 289 270 minecraft:light_blue_concrete
fill 335 288 228 336 289 228 minecraft:white_concrete
fill 335 288 270 336 289 270 minecraft:white_concrete
fill 337 288 228 338 289 228 minecraft:light_blue_concrete
fill 337 288 270 338 289 270 minecraft:light_blue_concrete
fill 339 288 228 340 289 228 minecraft:white_concrete
fill 339 288 270 340 289 270 minecraft:white_concrete
fill 341 288 228 342 289 228 minecraft:light_blue_concrete
fill 341 288 270 342 289 270 minecraft:light_blue_concrete
fill 343 288 228 344 289 228 minecraft:white_concrete
fill 343 288 235 343 303 235 minecraft:white_terracotta
fill 343 288 270 344 289 270 minecraft:white_concrete
fill 345 288 228 346 289 228 minecraft:light_blue_concrete
fill 345 288 270 346 289 270 minecraft:light_blue_concrete
fill 347 288 228 348 289 228 minecraft:white_concrete
fill 347 288 270 348 289 270 minecraft:white_concrete
fill 348 288 236 352 303 236 minecraft:white_concrete
fill 349 288 228 350 289 228 minecraft:light_blue_concrete
fill 349 288 270 350 289 270 minecraft:light_blue_concrete
fill 351 288 228 352 289 228 minecraft:white_concrete
fill 351 288 270 352 289 270 minecraft:white_concrete
fill 353 288 228 354 289 228 minecraft:light_blue_concrete
fill 353 288 270 354 289 270 minecraft:light_blue_concrete
fill 355 288 228 356 289 228 minecraft:white_concrete
fill 355 288 270 356 289 270 minecraft:white_concrete
fill 357 288 228 358 289 228 minecraft:light_blue_concrete
fill 357 288 235 357 303 235 minecraft:white_terracotta
fill 357 288 270 358 289 270 minecraft:light_blue_concrete
fill 359 288 228 360 289 228 minecraft:white_concrete
fill 359 288 270 360 289 270 minecraft:white_concrete
fill 361 288 228 362 289 228 minecraft:light_blue_concrete
fill 361 288 270 362 289 270 minecraft:light_blue_concrete
fill 363 288 228 364 289 228 minecraft:white_concrete
fill 363 288 270 364 289 270 minecraft:white_concrete
fill 365 288 228 366 289 228 minecraft:light_blue_concrete
fill 365 288 270 366 289 270 minecraft:light_blue_concrete
fill 367 288 228 368 289 228 minecraft:white_concrete
fill 367 288 270 368 289 270 minecraft:white_concrete
fill 369 288 228 370 289 228 minecraft:light_blue_concrete
fill 369 288 270 370 289 270 minecraft:light_blue_concrete
fill 371 288 229 371 289 229 minecraft:light_blue_concrete
fill 371 288 230 371 289 231 minecraft:white_concrete
fill 371 288 232 371 289 233 minecraft:light_blue_concrete
fill 371 288 234 371 289 235 minecraft:white_concrete
fill 371 288 236 371 289 237 minecraft:light_blue_concrete
fill 371 288 238 371 289 239 minecraft:white_concrete
fill 371 288 240 371 289 241 minecraft:light_blue_concrete
fill 371 288 242 371 289 243 minecraft:white_concrete
fill 371 288 244 371 289 245 minecraft:light_blue_concrete
fill 371 288 246 371 289 247 minecraft:white_concrete
fill 371 288 248 371 289 249 minecraft:light_blue_concrete
fill 371 288 250 371 289 251 minecraft:white_concrete
fill 371 288 252 371 289 253 minecraft:light_blue_concrete
fill 371 288 254 371 289 255 minecraft:white_concrete
fill 371 288 256 371 289 257 minecraft:light_blue_concrete
fill 371 288 258 371 289 259 minecraft:white_concrete
fill 371 288 260 371 289 261 minecraft:light_blue_concrete
fill 371 288 262 371 289 263 minecraft:white_concrete
fill 371 288 264 371 289 265 minecraft:light_blue_concrete
fill 371 288 266 371 289 267 minecraft:white_concrete
fill 371 288 268 371 289 269 minecraft:light_blue_concrete
fill 371 288 270 371 289 270 minecraft:white_concrete
setblock 332 289 231 minecraft:light[level=12]
setblock 332 289 238 minecraft:light[level=12]
setblock 332 289 245 minecraft:light[level=12]
setblock 332 289 252 minecraft:light[level=12]
setblock 332 289 259 minecraft:light[level=12]
setblock 332 289 266 minecraft:light[level=12]
setblock 339 289 238 minecraft:light[level=12]
setblock 339 289 245 minecraft:light[level=12]
setblock 339 289 252 minecraft:light[level=12]
setblock 339 289 259 minecraft:light[level=12]
setblock 339 289 266 minecraft:light[level=12]
fill 341 289 235 342 303 235 minecraft:white_terracotta
fill 345 289 236 347 303 236 minecraft:white_concrete
setblock 346 289 238 minecraft:light[level=12]
setblock 346 289 245 minecraft:light[level=12]
setblock 346 289 252 minecraft:light[level=12]
setblock 346 289 259 minecraft:light[level=12]
setblock 346 289 266 minecraft:light[level=12]
fill 353 289 236 355 303 236 minecraft:white_concrete
setblock 353 289 238 minecraft:light[level=12]
setblock 353 289 245 minecraft:light[level=12]
setblock 353 289 252 minecraft:light[level=12]
setblock 353 289 259 minecraft:light[level=12]
setblock 353 289 266 minecraft:light[level=12]
fill 358 289 235 359 303 235 minecraft:white_terracotta
setblock 360 289 238 minecraft:light[level=12]
setblock 360 289 245 minecraft:light[level=12]
setblock 360 289 252 minecraft:light[level=12]
setblock 360 289 259 minecraft:light[level=12]
setblock 360 289 266 minecraft:light[level=12]
setblock 367 289 231 minecraft:light[level=12]
setblock 367 289 238 minecraft:light[level=12]
setblock 367 289 245 minecraft:light[level=12]
setblock 367 289 252 minecraft:light[level=12]
setblock 367 289 259 minecraft:light[level=12]
setblock 367 289 266 minecraft:light[level=12]
fill 329 290 228 329 291 229 minecraft:white_concrete
fill 329 290 230 329 291 231 minecraft:light_blue_concrete
fill 329 290 232 329 291 233 minecraft:white_concrete
fill 329 290 234 329 291 235 minecraft:light_blue_concrete
fill 329 290 236 329 291 237 minecraft:white_concrete
fill 329 290 238 329 291 239 minecraft:light_blue_concrete
fill 329 290 240 329 291 241 minecraft:white_concrete
fill 329 290 242 329 291 243 minecraft:light_blue_concrete
fill 329 290 244 329 291 245 minecraft:white_concrete
fill 329 290 246 329 291 247 minecraft:light_blue_concrete
fill 329 290 248 329 291 249 minecraft:white_concrete
fill 329 290 250 329 291 251 minecraft:light_blue_concrete
fill 329 290 252 329 291 253 minecraft:white_concrete
fill 329 290 254 329 291 255 minecraft:light_blue_concrete
fill 329 290 256 329 291 257 minecraft:white_concrete
fill 329 290 258 329 291 259 minecraft:light_blue_concrete
fill 329 290 260 329 291 261 minecraft:white_concrete
fill 329 290 262 329 291 263 minecraft:light_blue_concrete
fill 329 290 264 329 291 265 minecraft:white_concrete
fill 329 290 266 329 291 267 minecraft:light_blue_concrete
fill 329 290 268 329 291 269 minecraft:white_concrete
fill 330 290 228 330 291 228 minecraft:white_concrete
fill 330 290 229 330 290 240 minecraft:light_blue_terracotta
fill 330 290 241 332 291 257 minecraft:pink_wool
fill 330 290 258 330 290 269 minecraft:light_blue_terracotta
fill 330 290 270 330 291 270 minecraft:white_concrete
fill 331 290 228 332 291 228 minecraft:light_blue_concrete
fill 331 290 229 333 290 229 minecraft:light_blue_terracotta
fill 331 290 269 370 290 269 minecraft:light_blue_terracotta
fill 331 290 270 332 291 270 minecraft:light_blue_concrete
fill 333 290 228 334 291 228 minecraft:white_concrete
fill 333 290 270 334 291 270 minecraft:white_concrete
fill 335 290 228 336 291 228 minecraft:light_blue_concrete
fill 335 290 270 336 291 270 minecraft:light_blue_concrete
fill 337 290 228 338 291 228 minecraft:white_concrete
fill 337 290 270 338 291 270 minecraft:white_concrete
fill 339 290 228 340 291 228 minecraft:light_blue_concrete
fill 339 290 270 340 291 270 minecraft:light_blue_concrete
fill 340 290 235 340 303 235 minecraft:white_terracotta
fill 341 290 228 342 291 228 minecraft:white_concrete
fill 341 290 270 342 291 270 minecraft:white_concrete
fill 343 290 228 344 291 228 minecraft:light_blue_concrete
fill 343 290 236 344 303 236 minecraft:white_concrete
fill 343 290 270 344 291 270 minecraft:light_blue_concrete
fill 345 290 228 346 291 228 minecraft:white_concrete
fill 345 290 270 346 291 270 minecraft:white_concrete
fill 347 290 228 348 291 228 minecraft:light_blue_concrete
fill 347 290 270 348 291 270 minecraft:light_blue_concrete
fill 349 290 228 350 291 228 minecraft:white_concrete
fill 349 290 270 350 291 270 minecraft:white_concrete
fill 351 290 228 352 291 228 minecraft:light_blue_concrete
fill 351 290 270 352 291 270 minecraft:light_blue_concrete
fill 353 290 228 354 291 228 minecraft:white_concrete
fill 353 290 270 354 291 270 minecraft:white_concrete
fill 355 290 228 356 291 228 minecraft:light_blue_concrete
fill 355 290 270 356 291 270 minecraft:light_blue_concrete
fill 356 290 236 357 303 236 minecraft:white_concrete
fill 357 290 228 358 291 228 minecraft:white_concrete
fill 357 290 270 358 291 270 minecraft:white_concrete
fill 359 290 228 360 291 228 minecraft:light_blue_concrete
fill 359 290 270 360 291 270 minecraft:light_blue_concrete
fill 360 290 235 360 303 235 minecraft:white_terracotta
fill 361 290 228 362 291 228 minecraft:white_concrete
fill 361 290 270 362 291 270 minecraft:white_concrete
fill 363 290 228 364 291 228 minecraft:light_blue_concrete
fill 363 290 270 364 291 270 minecraft:light_blue_concrete
fill 365 290 228 366 291 228 minecraft:white_concrete
fill 365 290 270 366 291 270 minecraft:white_concrete
fill 367 290 228 368 291 228 minecraft:light_blue_concrete
fill 367 290 229 370 290 229 minecraft:light_blue_terracotta
fill 367 290 270 368 291 270 minecraft:light_blue_concrete
fill 369 290 228 370 291 228 minecraft:white_concrete
fill 369 290 270 370 291 270 minecraft:white_concrete
fill 370 290 230 370 290 268 minecraft:light_blue_terracotta
fill 371 290 229 371 291 229 minecraft:white_concrete
fill 371 290 230 371 291 231 minecraft:light_blue_concrete
fill 371 290 232 371 291 233 minecraft:white_concrete
fill 371 290 234 371 291 235 minecraft:light_blue_concrete
fill 371 290 236 371 291 237 minecraft:white_concrete
fill 371 290 238 371 291 239 minecraft:light_blue_concrete
fill 371 290 240 371 291 241 minecraft:white_concrete
fill 371 290 242 371 291 243 minecraft:light_blue_concrete
fill 371 290 244 371 291 245 minecraft:white_concrete
fill 371 290 246 371 291 247 minecraft:light_blue_concrete
fill 371 290 248 371 291 249 minecraft:white_concrete
fill 371 290 250 371 291 251 minecraft:light_blue_concrete
fill 371 290 252 371 291 253 minecraft:white_concrete
fill 371 290 254 371 291 255 minecraft:light_blue_concrete
fill 371 290 256 371 291 257 minecraft:white_concrete
fill 371 290 258 371 291 259 minecraft:light_blue_concrete
fill 371 290 260 371 291 261 minecraft:white_concrete
fill 371 290 262 371 291 263 minecraft:light_blue_concrete
fill 371 290 264 371 291 265 minecraft:white_concrete
fill 371 290 266 371 291 267 minecraft:light_blue_concrete
fill 371 290 268 371 291 269 minecraft:white_concrete
fill 371 290 270 371 291 270 minecraft:light_blue_concrete
setblock 332 291 262 minecraft:light_gray_concrete
setblock 332 291 264 minecraft:light_gray_concrete
setblock 334 291 262 minecraft:light_gray_concrete
setblock 334 291 264 minecraft:light_gray_concrete
fill 342 291 236 342 302 236 minecraft:white_concrete
fill 348 291 234 352 302 234 minecraft:white_terracotta
fill 349 291 267 351 297 267 minecraft:light_gray_concrete
fill 350 291 266 350 297 266 minecraft:light_gray_concrete
fill 350 291 268 350 297 268 minecraft:light_gray_concrete
fill 358 291 236 358 302 236 minecraft:white_concrete
fill 329 292 228 329 293 229 minecraft:light_blue_concrete
fill 329 292 230 329 293 231 minecraft:white_concrete
fill 329 292 232 329 293 233 minecraft:light_blue_concrete
fill 329 292 234 329 293 235 minecraft:white_concrete
fill 329 292 236 329 293 237 minecraft:light_blue_concrete
fill 329 292 238 329 293 239 minecraft:white_concrete
fill 329 292 240 329 293 241 minecraft:light_blue_concrete
fill 329 292 242 329 293 243 minecraft:white_concrete
fill 329 292 244 329 293 245 minecraft:light_blue_concrete
fill 329 292 246 329 293 247 minecraft:white_concrete
fill 329 292 248 329 293 249 minecraft:light_blue_concrete
fill 329 292 250 329 293 251 minecraft:white_concrete
fill 329 292 252 329 293 253 minecraft:light_blue_concrete
fill 329 292 254 329 293 255 minecraft:white_concrete
fill 329 292 256 329 293 257 minecraft:light_blue_concrete
fill 329 292 258 329 293 259 minecraft:white_concrete
fill 329 292 260 329 293 261 minecraft:light_blue_concrete
fill 329 292 262 329 293 263 minecraft:white_concrete
fill 329 292 264 329 293 265 minecraft:light_blue_concrete
fill 329 292 266 329 293 267 minecraft:white_concrete
fill 329 292 268 329 293 269 minecraft:light_blue_concrete
fill 330 292 228 330 293 228 minecraft:light_blue_concrete
fill 330 292 241 331 303 257 minecraft:pink_wool
fill 330 292 270 330 293 270 minecraft:light_blue_concrete
fill 331 292 228 332 293 228 minecraft:white_concrete
fill 331 292 270 332 293 270 minecraft:white_concrete
fill 332 292 241 332 292 257 minecraft:magenta_wool
fill 333 292 228 334 293 228 minecraft:light_blue_concrete
fill 333 292 270 334 293 270 minecraft:light_blue_concrete
fill 335 292 228 336 293 228 minecraft:white_concrete
fill 335 292 270 336 293 270 minecraft:white_concrete
fill 337 292 228 338 293 228 minecraft:light_blue_concrete
fill 337 292 270 338 293 270 minecraft:light_blue_concrete
fill 339 292 228 340 293 228 minecraft:white_concrete
fill 339 292 235 339 301 235 minecraft:white_terracotta
fill 339 292 270 340 293 270 minecraft:white_concrete
fill 341 292 228 342 293 228 minecraft:light_blue_concrete
fill 341 292 270 342 293 270 minecraft:light_blue_concrete
fill 343 292 228 344 293 228 minecraft:white_concrete
fill 343 292 256 343 293 256 minecraft:light_blue_stained_glass
fill 343 292 270 344 293 270 minecraft:white_concrete
fill 345 292 228 346 293 228 minecraft:light_blue_concrete
fill 345 292 270 346 293 270 minecraft:light_blue_concrete
fill 346 292 234 347 301 234 minecraft:white_terracotta
fill 347 292 228 348 293 228 minecraft:white_concrete
fill 347 292 266 348 296 268 minecraft:white_wool
fill 347 292 270 348 293 270 minecraft:white_concrete
fill 348 292 265 352 296 265 minecraft:white_wool
fill 348 292 269 352 296 269 minecraft:white_wool
fill 349 292 228 350 293 228 minecraft:light_blue_concrete
fill 349 292 264 351 296 264 minecraft:white_wool
fill 349 292 266 349 296 266 minecraft:white_wool
fill 349 292 268 349 296 268 minecraft:white_wool
fill 349 292 270 350 293 270 minecraft:light_blue_concrete
fill 351 292 228 352 293 228 minecraft:white_concrete
fill 351 292 266 353 296 266 minecraft:white_wool
fill 351 292 268 353 296 268 minecraft:white_wool
fill 351 292 270 352 293 270 minecraft:white_concrete
fill 352 292 267 353 296 267 minecraft:white_wool
fill 353 292 228 354 293 228 minecraft:light_blue_concrete
fill 353 292 234 354 301 234 minecraft:white_terracotta
fill 353 292 270 354 293 270 minecraft:light_blue_concrete
fill 355 292 228 356 293 228 minecraft:white_concrete
fill 355 292 270 356 293 270 minecraft:white_concrete
fill 357 292 228 358 293 228 minecraft:light_blue_concrete
fill 357 292 270 358 293 270 minecraft:light_blue_concrete
fill 359 292 228 360 293 228 minecraft:white_concrete
fill 359 292 270 360 293 270 minecraft:white_concrete
fill 361 292 228 362 293 228 minecraft:light_blue_concrete
fill 361 292 235 361 301 235 minecraft:white_terracotta
fill 361 292 270 362 293 270 minecraft:light_blue_concrete
fill 363 292 228 364 293 228 minecraft:white_concrete
fill 363 292 270 364 293 270 minecraft:white_concrete
fill 365 292 228 366 293 228 minecraft:light_blue_concrete
fill 365 292 270 366 293 270 minecraft:light_blue_concrete
fill 367 292 228 368 293 228 minecraft:white_concrete
fill 367 292 270 368 293 270 minecraft:white_concrete
fill 369 292 228 370 293 228 minecraft:light_blue_concrete
fill 369 292 270 370 293 270 minecraft:light_blue_concrete
fill 371 292 229 371 293 229 minecraft:light_blue_concrete
fill 371 292 230 371 293 231 minecraft:white_concrete
fill 371 292 232 371 293 233 minecraft:light_blue_concrete
fill 371 292 234 371 293 235 minecraft:white_concrete
fill 371 292 236 371 293 237 minecraft:light_blue_concrete
fill 371 292 238 371 293 239 minecraft:white_concrete
fill 371 292 240 371 293 241 minecraft:light_blue_concrete
fill 371 292 242 371 293 243 minecraft:white_concrete
fill 371 292 244 371 293 245 minecraft:light_blue_concrete
fill 371 292 246 371 293 247 minecraft:white_concrete
fill 371 292 248 371 293 249 minecraft:light_blue_concrete
fill 371 292 250 371 293 251 minecraft:white_concrete
fill 371 292 252 371 293 253 minecraft:light_blue_concrete
fill 371 292 254 371 293 255 minecraft:white_concrete
fill 371 292 256 371 293 257 minecraft:light_blue_concrete
fill 371 292 258 371 293 259 minecraft:white_concrete
fill 371 292 260 371 293 261 minecraft:light_blue_concrete
fill 371 292 262 371 293 263 minecraft:white_concrete
fill 371 292 264 371 293 265 minecraft:light_blue_concrete
fill 371 292 266 371 293 267 minecraft:white_concrete
fill 371 292 268 371 293 269 minecraft:light_blue_concrete
fill 371 292 270 371 293 270 minecraft:white_concrete
setblock 332 293 231 minecraft:light[level=15]
setblock 332 293 239 minecraft:light[level=15]
fill 332 293 241 332 295 257 minecraft:pink_wool
setblock 340 293 239 minecraft:light[level=15]
setblock 340 293 247 minecraft:light[level=15]
setblock 340 293 255 minecraft:light[level=15]
setblock 340 293 263 minecraft:light[level=15]
fill 341 293 236 341 300 236 minecraft:white_concrete
fill 343 293 243 344 294 243 minecraft:white_stained_glass
fill 345 293 234 345 300 234 minecraft:white_terracotta
setblock 348 293 239 minecraft:light[level=15]
setblock 348 293 247 minecraft:light[level=15]
setblock 348 293 255 minecraft:light[level=15]
setblock 348 293 263 minecraft:light[level=15]
fill 355 293 234 355 300 234 minecraft:white_terracotta
setblock 356 293 239 minecraft:light[level=15]
setblock 356 293 247 minecraft:light[level=15]
setblock 356 293 255 minecraft:light[level=15]
setblock 356 293 263 minecraft:light[level=15]
fill 359 293 236 359 300 236 minecraft:white_concrete
setblock 364 293 239 minecraft:light[level=15]
setblock 364 293 247 minecraft:light[level=15]
setblock 364 293 255 minecraft:light[level=15]
setblock 364 293 263 minecraft:light[level=15]
fill 329 294 228 329 295 229 minecraft:white_concrete
fill 329 294 230 329 295 231 minecraft:light_blue_concrete
fill 329 294 232 329 295 233 minecraft:white_concrete
fill 329 294 234 329 295 235 minecraft:light_blue_concrete
fill 329 294 236 329 295 237 minecraft:white_concrete
fill 329 294 238 329 295 239 minecraft:light_blue_concrete
fill 329 294 240 329 295 241 minecraft:white_concrete
fill 329 294 242 329 295 243 minecraft:light_blue_concrete
fill 329 294 244 329 295 245 minecraft:white_concrete
fill 329 294 246 329 295 247 minecraft:light_blue_concrete
fill 329 294 248 329 295 249 minecraft:white_concrete
fill 329 294 250 329 295 251 minecraft:light_blue_concrete
fill 329 294 252 329 295 253 minecraft:white_concrete
fill 329 294 254 329 295 255 minecraft:light_blue_concrete
fill 329 294 256 329 295 257 minecraft:white_concrete
fill 329 294 258 329 295 259 minecraft:light_blue_concrete
fill 329 294 260 329 295 261 minecraft:white_concrete
fill 329 294 262 329 295 263 minecraft:light_blue_concrete
fill 329 294 264 329 295 265 minecraft:white_concrete
fill 329 294 266 329 295 267 minecraft:light_blue_concrete
fill 329 294 268 329 295 269 minecraft:white_concrete
fill 330 294 228 330 295 228 minecraft:white_concrete
fill 330 294 270 330 295 270 minecraft:white_concrete
fill 331 294 228 332 295 228 minecraft:light_blue_concrete
fill 331 294 270 332 295 270 minecraft:light_blue_concrete
fill 333 294 228 334 295 228 minecraft:white_concrete
fill 333 294 270 334 295 270 minecraft:white_concrete
fill 335 294 228 336 295 228 minecraft:light_blue_concrete
fill 335 294 270 336 295 270 minecraft:light_blue_concrete
fill 337 294 228 338 295 228 minecraft:white_concrete
fill 337 294 270 338 295 270 minecraft:white_concrete
fill 338 294 235 338 299 235 minecraft:white_terracotta
fill 339 294 228 340 295 228 minecraft:light_blue_concrete
fill 339 294 270 340 295 270 minecraft:light_blue_concrete
fill 341 294 228 342 295 228 minecraft:white_concrete
fill 341 294 270 342 295 270 minecraft:white_concrete
fill 343 294 228 344 295 228 minecraft:light_blue_concrete
fill 343 294 270 344 295 270 minecraft:light_blue_concrete
fill 344 294 234 344 299 234 minecraft:white_terracotta
fill 345 294 228 346 295 228 minecraft:white_concrete
fill 345 294 270 346 295 270 minecraft:white_concrete
fill 347 294 228 348 295 228 minecraft:light_blue_concrete
fill 347 294 270 348 295 270 minecraft:light_blue_concrete
fill 349 294 228 350 295 228 minecraft:white_concrete
fill 349 294 270 350 295 270 minecraft:white_concrete
fill 351 294 228 352 295 228 minecraft:light_blue_concrete
fill 351 294 270 352 295 270 minecraft:light_blue_concrete
fill 353 294 228 354 295 228 minecraft:white_concrete
fill 353 294 270 354 295 270 minecraft:white_concrete
fill 355 294 228 356 295 228 minecraft:light_blue_concrete
fill 355 294 270 356 295 270 minecraft:light_blue_concrete
fill 356 294 234 356 299 234 minecraft:white_terracotta
fill 357 294 228 358 295 228 minecraft:white_concrete
fill 357 294 270 358 295 270 minecraft:white_concrete
fill 359 294 228 360 295 228 minecraft:light_blue_concrete
fill 359 294 270 360 295 270 minecraft:light_blue_concrete
fill 361 294 228 362 295 228 minecraft:white_concrete
fill 361 294 270 362 295 270 minecraft:white_concrete
fill 362 294 235 362 299 235 minecraft:white_terracotta
fill 363 294 228 364 295 228 minecraft:light_blue_concrete
fill 363 294 270 364 295 270 minecraft:light_blue_concrete
fill 365 294 228 366 295 228 minecraft:white_concrete
fill 365 294 270 366 295 270 minecraft:white_concrete
fill 367 294 228 368 295 228 minecraft:light_blue_concrete
fill 367 294 270 368 295 270 minecraft:light_blue_concrete
fill 369 294 228 370 295 228 minecraft:white_concrete
fill 369 294 270 370 295 270 minecraft:white_concrete
fill 371 294 229 371 295 229 minecraft:white_concrete
fill 371 294 230 371 295 231 minecraft:light_blue_concrete
fill 371 294 232 371 295 233 minecraft:white_concrete
fill 371 294 234 371 295 235 minecraft:light_blue_concrete
fill 371 294 236 371 295 237 minecraft:white_concrete
fill 371 294 238 371 295 239 minecraft:light_blue_concrete
fill 371 294 240 371 295 241 minecraft:white_concrete
fill 371 294 242 371 295 243 minecraft:light_blue_concrete
fill 371 294 244 371 295 245 minecraft:white_concrete
fill 371 294 246 371 295 247 minecraft:light_blue_concrete
fill 371 294 248 371 295 249 minecraft:white_concrete
fill 371 294 250 371 295 251 minecraft:light_blue_concrete
fill 371 294 252 371 295 253 minecraft:white_concrete
fill 371 294 254 371 295 255 minecraft:light_blue_concrete
fill 371 294 256 371 295 257 minecraft:white_concrete
fill 371 294 258 371 295 259 minecraft:light_blue_concrete
fill 371 294 260 371 295 261 minecraft:white_concrete
fill 371 294 262 371 295 263 minecraft:light_blue_concrete
fill 371 294 264 371 295 265 minecraft:white_concrete
fill 371 294 266 371 295 267 minecraft:light_blue_concrete
fill 371 294 268 371 295 269 minecraft:white_concrete
fill 371 294 270 371 295 270 minecraft:light_blue_concrete
setblock 332 295 231 minecraft:light[level=12]
setblock 332 295 238 minecraft:light[level=12]
setblock 332 295 259 minecraft:light[level=12]
setblock 332 295 266 minecraft:light[level=12]
setblock 339 295 238 minecraft:light[level=12]
setblock 339 295 245 minecraft:light[level=12]
setblock 339 295 252 minecraft:light[level=12]
setblock 339 295 259 minecraft:light[level=12]
setblock 339 295 266 minecraft:light[level=12]
fill 340 295 236 340 298 236 minecraft:white_concrete
setblock 346 295 238 minecraft:light[level=12]
setblock 346 295 245 minecraft:light[level=12]
setblock 346 295 252 minecraft:light[level=12]
setblock 346 295 259 minecraft:light[level=12]
setblock 346 295 266 minecraft:light[level=12]
setblock 353 295 238 minecraft:light[level=12]
setblock 353 295 245 minecraft:light[level=12]
setblock 353 295 252 minecraft:light[level=12]
setblock 353 295 259 minecraft:light[level=12]
fill 360 295 236 360 298 236 minecraft:white_concrete
setblock 360 295 238 minecraft:light[level=12]
setblock 360 295 245 minecraft:light[level=12]
setblock 360 295 252 minecraft:light[level=12]
setblock 360 295 259 minecraft:light[level=12]
setblock 360 295 266 minecraft:light[level=12]
setblock 367 295 231 minecraft:light[level=12]
setblock 367 295 238 minecraft:light[level=12]
setblock 367 295 245 minecraft:light[level=12]
setblock 367 295 252 minecraft:light[level=12]
setblock 367 295 259 minecraft:light[level=12]
setblock 367 295 266 minecraft:light[level=12]
fill 329 296 228 329 297 229 minecraft:light_blue_concrete
fill 329 296 230 329 297 231 minecraft:white_concrete
fill 329 296 232 329 297 233 minecraft:light_blue_concrete
fill 329 296 234 329 297 235 minecraft:white_concrete
fill 329 296 236 329 297 237 minecraft:light_blue_concrete
fill 329 296 238 329 297 239 minecraft:white_concrete
fill 329 296 240 329 297 241 minecraft:light_blue_concrete
fill 329 296 242 329 297 243 minecraft:white_concrete
fill 329 296 244 329 297 245 minecraft:light_blue_concrete
fill 329 296 246 329 297 247 minecraft:white_concrete
fill 329 296 248 329 297 249 minecraft:light_blue_concrete
fill 329 296 250 329 297 251 minecraft:white_concrete
fill 329 296 252 329 297 253 minecraft:light_blue_concrete
fill 329 296 254 329 297 255 minecraft:white_concrete
fill 329 296 256 329 297 257 minecraft:light_blue_concrete
fill 329 296 258 329 297 259 minecraft:white_concrete
fill 329 296 260 329 297 261 minecraft:light_blue_concrete
fill 329 296 262 329 297 263 minecraft:white_concrete
fill 329 296 264 329 297 265 minecraft:light_blue_concrete
fill 329 296 266 329 297 267 minecraft:white_concrete
fill 329 296 268 329 297 269 minecraft:light_blue_concrete
fill 330 296 228 330 297 228 minecraft:light_blue_concrete
fill 330 296 270 330 297 270 minecraft:light_blue_concrete
fill 331 296 228 332 297 228 minecraft:white_concrete
fill 331 296 270 332 297 270 minecraft:white_concrete
fill 332 296 241 332 296 257 minecraft:magenta_wool
fill 333 296 228 334 297 228 minecraft:light_blue_concrete
fill 333 296 270 334 297 270 minecraft:light_blue_concrete
fill 335 296 228 336 297 228 minecraft:white_concrete
fill 335 296 270 336 297 270 minecraft:white_concrete
fill 337 296 228 338 297 228 minecraft:light_blue_concrete
fill 337 296 270 338 297 270 minecraft:light_blue_concrete
fill 339 296 228 340 297 228 minecraft:white_concrete
fill 339 296 270 340 297 270 minecraft:white_concrete
fill 341 296 228 342 297 228 minecraft:light_blue_concrete
fill 341 296 270 342 297 270 minecraft:light_blue_concrete
fill 343 296 228 344 297 228 minecraft:white_concrete
fill 343 296 270 344 297 270 minecraft:white_concrete
fill 345 296 228 346 297 228 minecraft:light_blue_concrete
fill 345 296 270 346 297 270 minecraft:light_blue_concrete
fill 347 296 228 348 297 228 minecraft:white_concrete
fill 347 296 270 348 297 270 minecraft:white_concrete
fill 349 296 228 350 297 228 minecraft:light_blue_concrete
fill 349 296 270 350 297 270 minecraft:light_blue_concrete
fill 351 296 228 352 297 228 minecraft:white_concrete
fill 351 296 270 352 297 270 minecraft:white_concrete
fill 353 296 228 354 297 228 minecraft:light_blue_concrete
fill 353 296 270 354 297 270 minecraft:light_blue_concrete
fill 355 296 228 356 297 228 minecraft:white_concrete
fill 355 296 270 356 297 270 minecraft:white_concrete
fill 357 296 228 358 297 228 minecraft:light_blue_concrete
fill 357 296 270 358 297 270 minecraft:light_blue_concrete
fill 359 296 228 360 297 228 minecraft:white_concrete
fill 359 296 270 360 297 270 minecraft:white_concrete
fill 361 296 228 362 297 228 minecraft:light_blue_concrete
fill 361 296 270 362 297 270 minecraft:light_blue_concrete
fill 363 296 228 364 297 228 minecraft:white_concrete
fill 363 296 270 364 297 270 minecraft:white_concrete
fill 365 296 228 366 297 228 minecraft:light_blue_concrete
fill 365 296 270 366 297 270 minecraft:light_blue_concrete
fill 367 296 228 368 297 228 minecraft:white_concrete
fill 367 296 270 368 297 270 minecraft:white_concrete
fill 369 296 228 370 297 228 minecraft:light_blue_concrete
fill 369 296 270 370 297 270 minecraft:light_blue_concrete
fill 370 296 240 370 296 258 minecraft:light_gray_concrete
fill 371 296 229 371 297 229 minecraft:light_blue_concrete
fill 371 296 230 371 297 231 minecraft:white_concrete
fill 371 296 232 371 297 233 minecraft:light_blue_concrete
fill 371 296 234 371 297 235 minecraft:white_concrete
fill 371 296 236 371 297 237 minecraft:light_blue_concrete
fill 371 296 238 371 297 239 minecraft:white_concrete
fill 371 296 240 371 297 241 minecraft:light_blue_concrete
fill 371 296 242 371 297 243 minecraft:white_concrete
fill 371 296 244 371 297 245 minecraft:light_blue_concrete
fill 371 296 246 371 297 247 minecraft:white_concrete
fill 371 296 248 371 297 249 minecraft:light_blue_concrete
fill 371 296 250 371 297 251 minecraft:white_concrete
fill 371 296 252 371 297 253 minecraft:light_blue_concrete
fill 371 296 254 371 297 255 minecraft:white_concrete
fill 371 296 256 371 297 257 minecraft:light_blue_concrete
fill 371 296 258 371 297 259 minecraft:white_concrete
fill 371 296 260 371 297 261 minecraft:light_blue_concrete
fill 371 296 262 371 297 263 minecraft:white_concrete
fill 371 296 264 371 297 265 minecraft:light_blue_concrete
fill 371 296 266 371 297 267 minecraft:white_concrete
fill 371 296 268 371 297 269 minecraft:light_blue_concrete
fill 371 296 270 371 297 270 minecraft:white_concrete
fill 332 297 241 332 299 257 minecraft:pink_wool
setblock 332 297 262 minecraft:light_gray_concrete
setblock 332 297 264 minecraft:light_gray_concrete
setblock 334 297 262 minecraft:light_gray_concrete
setblock 334 297 264 minecraft:light_gray_concrete
fill 362 297 234 365 298 234 minecraft:iron_block
fill 370 297 240 370 303 240 minecraft:light_gray_concrete
fill 370 297 241 370 303 257 minecraft:light_blue_stained_glass
fill 370 297 258 370 303 258 minecraft:light_gray_concrete
fill 329 298 228 329 299 229 minecraft:white_concrete
fill 329 298 230 329 299 231 minecraft:light_blue_concrete
fill 329 298 232 329 299 233 minecraft:white_concrete
fill 329 298 234 329 299 235 minecraft:light_blue_concrete
fill 329 298 236 329 299 237 minecraft:white_concrete
fill 329 298 238 329 299 239 minecraft:light_blue_concrete
fill 329 298 240 329 299 241 minecraft:white_concrete
fill 329 298 242 329 299 243 minecraft:light_blue_concrete
fill 329 298 244 329 299 245 minecraft:white_concrete
fill 329 298 246 329 299 247 minecraft:light_blue_concrete
fill 329 298 248 329 299 249 minecraft:white_concrete
fill 329 298 250 329 299 251 minecraft:light_blue_concrete
fill 329 298 252 329 299 253 minecraft:white_concrete
fill 329 298 254 329 299 255 minecraft:light_blue_concrete
fill 329 298 256 329 299 257 minecraft:white_concrete
fill 329 298 258 329 299 259 minecraft:light_blue_concrete
fill 329 298 260 329 299 261 minecraft:white_concrete
fill 329 298 262 329 299 263 minecraft:light_blue_concrete
fill 329 298 264 329 299 265 minecraft:white_concrete
fill 329 298 266 329 299 267 minecraft:light_blue_concrete
fill 329 298 268 329 299 269 minecraft:white_concrete
fill 330 298 228 330 299 228 minecraft:white_concrete
fill 330 298 270 330 299 270 minecraft:white_concrete
fill 331 298 228 332 299 228 minecraft:light_blue_concrete
fill 331 298 270 332 299 270 minecraft:light_blue_concrete
fill 333 298 228 334 299 228 minecraft:white_concrete
fill 333 298 270 334 299 270 minecraft:white_concrete
fill 335 298 228 336 299 228 minecraft:light_blue_concrete
fill 335 298 270 336 299 270 minecraft:light_blue_concrete
fill 337 298 228 338 299 228 minecraft:white_concrete
fill 337 298 270 338 299 270 minecraft:white_concrete
fill 339 298 228 340 299 228 minecraft:light_blue_concrete
fill 339 298 270 340 299 270 minecraft:light_blue_concrete
fill 341 298 228 342 299 228 minecraft:white_concrete
fill 341 298 270 342 299 270 minecraft:white_concrete
fill 343 298 228 344 299 228 minecraft:light_blue_concrete
fill 343 298 270 344 299 270 minecraft:light_blue_concrete
fill 345 298 228 346 299 228 minecraft:white_concrete
fill 345 298 270 346 299 270 minecraft:white_concrete
fill 347 298 228 348 299 228 minecraft:light_blue_concrete
fill 347 298 270 348 299 270 minecraft:light_blue_concrete
fill 349 298 228 350 299 228 minecraft:white_concrete
fill 349 298 270 350 299 270 minecraft:white_concrete
fill 351 298 228 352 299 228 minecraft:light_blue_concrete
fill 351 298 270 352 299 270 minecraft:light_blue_concrete
fill 353 298 228 354 299 228 minecraft:white_concrete
fill 353 298 270 354 299 270 minecraft:white_concrete
fill 355 298 228 356 299 228 minecraft:light_blue_concrete
fill 355 298 270 356 299 270 minecraft:light_blue_concrete
fill 357 298 228 358 299 228 minecraft:white_concrete
fill 357 298 270 358 299 270 minecraft:white_concrete
fill 359 298 228 360 299 228 minecraft:light_blue_concrete
fill 359 298 270 360 299 270 minecraft:light_blue_concrete
fill 361 298 228 362 299 228 minecraft:white_concrete
fill 361 298 270 362 299 270 minecraft:white_concrete
fill 363 298 228 364 299 228 minecraft:light_blue_concrete
fill 363 298 270 364 299 270 minecraft:light_blue_concrete
fill 365 298 228 366 299 228 minecraft:white_concrete
fill 365 298 270 366 299 270 minecraft:white_concrete
fill 367 298 228 368 299 228 minecraft:light_blue_concrete
fill 367 298 270 368 299 270 minecraft:light_blue_concrete
fill 369 298 228 370 299 228 minecraft:white_concrete
fill 369 298 270 370 299 270 minecraft:white_concrete
fill 371 298 229 371 299 229 minecraft:white_concrete
fill 371 298 230 371 299 231 minecraft:light_blue_concrete
fill 371 298 232 371 299 233 minecraft:white_concrete
fill 371 298 234 371 299 235 minecraft:light_blue_concrete
fill 371 298 236 371 299 237 minecraft:white_concrete
fill 371 298 238 371 299 239 minecraft:light_blue_concrete
fill 371 298 240 371 299 241 minecraft:white_concrete
fill 371 298 242 371 299 243 minecraft:light_blue_concrete
fill 371 298 244 371 299 245 minecraft:white_concrete
fill 371 298 246 371 299 247 minecraft:light_blue_concrete
fill 371 298 248 371 299 249 minecraft:white_concrete
fill 371 298 250 371 299 251 minecraft:light_blue_concrete
fill 371 298 252 371 299 253 minecraft:white_concrete
fill 371 298 254 371 299 255 minecraft:light_blue_concrete
fill 371 298 256 371 299 257 minecraft:white_concrete
fill 371 298 258 371 299 259 minecraft:light_blue_concrete
fill 371 298 260 371 299 261 minecraft:white_concrete
fill 371 298 262 371 299 263 minecraft:light_blue_concrete
fill 371 298 264 371 299 265 minecraft:white_concrete
fill 371 298 266 371 299 267 minecraft:light_blue_concrete
fill 371 298 268 371 299 269 minecraft:white_concrete
fill 371 298 270 371 299 270 minecraft:light_blue_concrete
fill 329 300 228 329 301 229 minecraft:light_blue_concrete
fill 329 300 230 329 301 231 minecraft:white_concrete
fill 329 300 232 329 301 233 minecraft:light_blue_concrete
fill 329 300 234 329 301 235 minecraft:white_concrete
fill 329 300 236 329 301 237 minecraft:light_blue_concrete
fill 329 300 238 329 301 239 minecraft:white_concrete
fill 329 300 240 329 301 241 minecraft:light_blue_concrete
fill 329 300 242 329 301 243 minecraft:white_concrete
fill 329 300 244 329 301 245 minecraft:light_blue_concrete
fill 329 300 246 329 301 247 minecraft:white_concrete
fill 329 300 248 329 301 249 minecraft:light_blue_concrete
fill 329 300 250 329 301 251 minecraft:white_concrete
fill 329 300 252 329 301 253 minecraft:light_blue_concrete
fill 329 300 254 329 301 255 minecraft:white_concrete
fill 329 300 256 329 301 257 minecraft:light_blue_concrete
fill 329 300 258 329 301 259 minecraft:white_concrete
fill 329 300 260 329 301 261 minecraft:light_blue_concrete
fill 329 300 262 329 301 263 minecraft:white_concrete
fill 329 300 264 329 301 265 minecraft:light_blue_concrete
fill 329 300 266 329 301 267 minecraft:white_concrete
fill 329 300 268 329 301 269 minecraft:light_blue_concrete
fill 330 300 228 330 301 228 minecraft:light_blue_concrete
fill 330 300 270 330 301 270 minecraft:light_blue_concrete
fill 331 300 228 332 301 228 minecraft:white_concrete
fill 331 300 270 332 301 270 minecraft:white_concrete
setblock 332 300 231 minecraft:light[level=15]
setblock 332 300 239 minecraft:light[level=15]
fill 332 300 241 332 300 257 minecraft:magenta_wool
fill 333 300 228 334 301 228 minecraft:light_blue_concrete
fill 333 300 270 334 301 270 minecraft:light_blue_concrete
fill 334 300 229 344 301 234 minecraft:smooth_quartz
fill 335 300 228 336 301 228 minecraft:white_concrete
fill 335 300 270 336 301 270 minecraft:white_concrete
fill 337 300 228 338 301 228 minecraft:light_blue_concrete
fill 337 300 270 338 301 270 minecraft:light_blue_concrete
fill 339 300 228 340 301 228 minecraft:white_concrete
fill 339 300 270 340 301 270 minecraft:white_concrete
setblock 340 300 239 minecraft:light[level=15]
setblock 340 300 247 minecraft:light[level=15]
setblock 340 300 255 minecraft:light[level=15]
setblock 340 300 263 minecraft:light[level=15]
fill 341 300 228 342 301 228 minecraft:light_blue_concrete
fill 341 300 270 342 301 270 minecraft:light_blue_concrete
fill 343 300 228 344 301 228 minecraft:white_concrete
fill 343 300 270 344 301 270 minecraft:white_concrete
fill 345 300 228 346 301 228 minecraft:light_blue_concrete
fill 345 300 229 366 301 233 minecraft:smooth_quartz
fill 345 300 270 346 301 270 minecraft:light_blue_concrete
fill 347 300 228 348 301 228 minecraft:white_concrete
fill 347 300 270 348 301 270 minecraft:white_concrete
setblock 348 300 239 minecraft:light[level=15]
setblock 348 300 247 minecraft:light[level=15]
setblock 348 300 255 minecraft:light[level=15]
setblock 348 300 263 minecraft:light[level=15]
fill 349 300 228 350 301 228 minecraft:light_blue_concrete
fill 349 300 270 350 301 270 minecraft:light_blue_concrete
fill 351 300 228 352 301 228 minecraft:white_concrete
fill 351 300 270 352 301 270 minecraft:white_concrete
fill 353 300 228 354 301 228 minecraft:light_blue_concrete
fill 353 300 270 354 301 270 minecraft:light_blue_concrete
fill 355 300 228 356 301 228 minecraft:white_concrete
fill 355 300 270 356 301 270 minecraft:white_concrete
fill 356 300 234 366 301 234 minecraft:smooth_quartz
setblock 356 300 239 minecraft:light[level=15]
setblock 356 300 247 minecraft:light[level=15]
setblock 356 300 255 minecraft:light[level=15]
setblock 356 300 263 minecraft:light[level=15]
fill 357 300 228 358 301 228 minecraft:light_blue_concrete
fill 357 300 270 358 301 270 minecraft:light_blue_concrete
fill 359 300 228 360 301 228 minecraft:white_concrete
fill 359 300 270 360 301 270 minecraft:white_concrete
fill 361 300 228 362 301 228 minecraft:light_blue_concrete
fill 361 300 270 362 301 270 minecraft:light_blue_concrete
fill 363 300 228 364 301 228 minecraft:white_concrete
fill 363 300 270 364 301 270 minecraft:white_concrete
setblock 364 300 239 minecraft:light[level=15]
setblock 364 300 247 minecraft:light[level=15]
setblock 364 300 255 minecraft:light[level=15]
setblock 364 300 263 minecraft:light[level=15]
fill 365 300 228 366 301 228 minecraft:light_blue_concrete
fill 365 300 270 366 301 270 minecraft:light_blue_concrete
fill 367 300 228 368 301 228 minecraft:white_concrete
fill 367 300 270 368 301 270 minecraft:white_concrete
fill 369 300 228 370 301 228 minecraft:light_blue_concrete
fill 369 300 270 370 301 270 minecraft:light_blue_concrete
fill 371 300 229 371 301 229 minecraft:light_blue_concrete
fill 371 300 230 371 301 231 minecraft:white_concrete
fill 371 300 232 371 301 233 minecraft:light_blue_concrete
fill 371 300 234 371 301 235 minecraft:white_concrete
fill 371 300 236 371 301 237 minecraft:light_blue_concrete
fill 371 300 238 371 301 239 minecraft:white_concrete
fill 371 300 240 371 301 241 minecraft:light_blue_concrete
fill 371 300 242 371 301 243 minecraft:white_concrete
fill 371 300 244 371 301 245 minecraft:light_blue_concrete
fill 371 300 246 371 301 247 minecraft:white_concrete
fill 371 300 248 371 301 249 minecraft:light_blue_concrete
fill 371 300 250 371 301 251 minecraft:white_concrete
fill 371 300 252 371 301 253 minecraft:light_blue_concrete
fill 371 300 254 371 301 255 minecraft:white_concrete
fill 371 300 256 371 301 257 minecraft:light_blue_concrete
fill 371 300 258 371 301 259 minecraft:white_concrete
fill 371 300 260 371 301 261 minecraft:light_blue_concrete
fill 371 300 262 371 301 263 minecraft:white_concrete
fill 371 300 264 371 301 265 minecraft:light_blue_concrete
fill 371 300 266 371 301 267 minecraft:white_concrete
fill 371 300 268 371 301 269 minecraft:light_blue_concrete
fill 371 300 270 371 301 270 minecraft:white_concrete
setblock 332 301 231 minecraft:light[level=12]
setblock 332 301 238 minecraft:light[level=12]
fill 332 301 241 332 303 257 minecraft:pink_wool
setblock 332 301 259 minecraft:light[level=12]
setblock 332 301 266 minecraft:light[level=12]
setblock 339 301 238 minecraft:light[level=12]
setblock 339 301 245 minecraft:light[level=12]
setblock 339 301 252 minecraft:light[level=12]
setblock 339 301 259 minecraft:light[level=12]
setblock 339 301 266 minecraft:light[level=12]
setblock 345 301 234 minecraft:smooth_quartz
setblock 346 301 238 minecraft:light[level=12]
setblock 346 301 245 minecraft:light[level=12]
setblock 346 301 252 minecraft:light[level=12]
setblock 346 301 259 minecraft:light[level=12]
setblock 346 301 266 minecraft:light[level=12]
setblock 353 301 238 minecraft:light[level=12]
setblock 353 301 245 minecraft:light[level=12]
setblock 353 301 252 minecraft:light[level=12]
setblock 353 301 259 minecraft:light[level=12]
setblock 353 301 266 minecraft:light[level=12]
setblock 355 301 234 minecraft:smooth_quartz
setblock 360 301 238 minecraft:light[level=12]
setblock 360 301 245 minecraft:light[level=12]
setblock 360 301 252 minecraft:light[level=12]
setblock 360 301 259 minecraft:light[level=12]
setblock 360 301 266 minecraft:light[level=12]
setblock 367 301 231 minecraft:light[level=12]
setblock 367 301 238 minecraft:light[level=12]
setblock 367 301 245 minecraft:light[level=12]
setblock 367 301 252 minecraft:light[level=12]
setblock 367 301 259 minecraft:light[level=12]
setblock 367 301 266 minecraft:light[level=12]
fill 329 302 228 329 303 229 minecraft:white_concrete
fill 329 302 230 329 303 231 minecraft:light_blue_concrete
fill 329 302 232 329 303 233 minecraft:white_concrete
fill 329 302 234 329 303 235 minecraft:light_blue_concrete
fill 329 302 236 329 303 237 minecraft:white_concrete
fill 329 302 238 329 303 239 minecraft:light_blue_concrete
fill 329 302 240 329 303 241 minecraft:white_concrete
fill 329 302 242 329 303 243 minecraft:light_blue_concrete
fill 329 302 244 329 303 245 minecraft:white_concrete
fill 329 302 246 329 303 247 minecraft:light_blue_concrete
fill 329 302 248 329 303 249 minecraft:white_concrete
fill 329 302 250 329 303 251 minecraft:light_blue_concrete
fill 329 302 252 329 303 253 minecraft:white_concrete
fill 329 302 254 329 303 255 minecraft:light_blue_concrete
fill 329 302 256 329 303 257 minecraft:white_concrete
fill 329 302 258 329 303 259 minecraft:light_blue_concrete
fill 329 302 260 329 303 261 minecraft:white_concrete
fill 329 302 262 329 303 263 minecraft:light_blue_concrete
fill 329 302 264 329 303 265 minecraft:white_concrete
fill 329 302 266 329 303 267 minecraft:light_blue_concrete
fill 329 302 268 329 303 269 minecraft:white_concrete
fill 330 302 228 330 303 228 minecraft:white_concrete
fill 330 302 270 330 303 270 minecraft:white_concrete
fill 331 302 228 332 303 228 minecraft:light_blue_concrete
fill 331 302 270 332 303 270 minecraft:light_blue_concrete
fill 333 302 228 334 303 228 minecraft:white_concrete
fill 333 302 270 334 303 270 minecraft:white_concrete
fill 335 302 228 336 303 228 minecraft:light_blue_concrete
fill 335 302 270 336 303 270 minecraft:light_blue_concrete
fill 337 302 228 338 303 228 minecraft:white_concrete
fill 337 302 270 338 303 270 minecraft:white_concrete
fill 339 302 228 340 303 228 minecraft:light_blue_concrete
fill 339 302 270 340 303 270 minecraft:light_blue_concrete
fill 341 302 228 342 303 228 minecraft:white_concrete
fill 341 302 270 342 303 270 minecraft:white_concrete
fill 343 302 228 344 303 228 minecraft:light_blue_concrete
fill 343 302 270 344 303 270 minecraft:light_blue_concrete
fill 345 302 228 346 303 228 minecraft:white_concrete
fill 345 302 270 346 303 270 minecraft:white_concrete
fill 347 302 228 348 303 228 minecraft:light_blue_concrete
fill 347 302 270 348 303 270 minecraft:light_blue_concrete
fill 349 302 228 350 303 228 minecraft:white_concrete
fill 349 302 270 350 303 270 minecraft:white_concrete
fill 351 302 228 352 303 228 minecraft:light_blue_concrete
fill 351 302 270 352 303 270 minecraft:light_blue_concrete
fill 353 302 228 354 303 228 minecraft:white_concrete
fill 353 302 270 354 303 270 minecraft:white_concrete
fill 355 302 228 356 303 228 minecraft:light_blue_concrete
fill 355 302 270 356 303 270 minecraft:light_blue_concrete
fill 357 302 228 358 303 228 minecraft:white_concrete
fill 357 302 270 358 303 270 minecraft:white_concrete
fill 359 302 228 360 303 228 minecraft:light_blue_concrete
fill 359 302 270 360 303 270 minecraft:light_blue_concrete
fill 361 302 228 362 303 228 minecraft:white_concrete
fill 361 302 270 362 303 270 minecraft:white_concrete
fill 363 302 228 364 303 228 minecraft:light_blue_concrete
fill 363 302 270 364 303 270 minecraft:light_blue_concrete
fill 365 302 228 366 303 228 minecraft:white_concrete
fill 365 302 270 366 303 270 minecraft:white_concrete
fill 367 302 228 368 303 228 minecraft:light_blue_concrete
fill 367 302 270 368 303 270 minecraft:light_blue_concrete
fill 369 302 228 370 303 228 minecraft:white_concrete
fill 369 302 270 370 303 270 minecraft:white_concrete
fill 371 302 229 371 303 229 minecraft:white_concrete
fill 371 302 230 371 303 231 minecraft:light_blue_concrete
fill 371 302 232 371 303 233 minecraft:white_concrete
fill 371 302 234 371 303 235 minecraft:light_blue_concrete
fill 371 302 236 371 303 237 minecraft:white_concrete
fill 371 302 238 371 303 239 minecraft:light_blue_concrete
fill 371 302 240 371 303 241 minecraft:white_concrete
fill 371 302 242 371 303 243 minecraft:light_blue_concrete
fill 371 302 244 371 303 245 minecraft:white_concrete
fill 371 302 246 371 303 247 minecraft:light_blue_concrete
fill 371 302 248 371 303 249 minecraft:white_concrete
fill 371 302 250 371 303 251 minecraft:light_blue_concrete
fill 371 302 252 371 303 253 minecraft:white_concrete
fill 371 302 254 371 303 255 minecraft:light_blue_concrete
fill 371 302 256 371 303 257 minecraft:white_concrete
fill 371 302 258 371 303 259 minecraft:light_blue_concrete
fill 371 302 260 371 303 261 minecraft:white_concrete
fill 371 302 262 371 303 263 minecraft:light_blue_concrete
fill 371 302 264 371 303 265 minecraft:white_concrete
fill 371 302 266 371 303 267 minecraft:light_blue_concrete
fill 371 302 268 371 303 269 minecraft:white_concrete
fill 371 302 270 371 303 270 minecraft:light_blue_concrete
fill 329 304 228 329 305 229 minecraft:light_blue_concrete
fill 329 304 230 329 305 231 minecraft:white_concrete
fill 329 304 232 329 305 233 minecraft:light_blue_concrete
fill 329 304 234 329 305 235 minecraft:white_concrete
fill 329 304 236 329 305 237 minecraft:light_blue_concrete
fill 329 304 238 329 305 239 minecraft:white_concrete
fill 329 304 240 329 305 241 minecraft:light_blue_concrete
fill 329 304 242 329 305 243 minecraft:white_concrete
fill 329 304 244 329 305 245 minecraft:light_blue_concrete
fill 329 304 246 329 305 247 minecraft:white_concrete
fill 329 304 248 329 305 249 minecraft:light_blue_concrete
fill 329 304 250 329 305 251 minecraft:white_concrete
fill 329 304 252 329 305 253 minecraft:light_blue_concrete
fill 329 304 254 329 305 255 minecraft:white_concrete
fill 329 304 256 329 305 257 minecraft:light_blue_concrete
fill 329 304 258 329 305 259 minecraft:white_concrete
fill 329 304 260 329 305 261 minecraft:light_blue_concrete
fill 329 304 262 329 305 263 minecraft:white_concrete
fill 329 304 264 329 305 265 minecraft:light_blue_concrete
fill 329 304 266 329 305 267 minecraft:white_concrete
fill 329 304 268 329 305 269 minecraft:light_blue_concrete
fill 330 304 228 330 305 228 minecraft:light_blue_concrete
fill 330 304 270 330 305 270 minecraft:light_blue_concrete
fill 331 304 228 332 305 228 minecraft:white_concrete
fill 331 304 270 332 305 270 minecraft:white_concrete
fill 333 304 228 334 305 228 minecraft:light_blue_concrete
fill 333 304 270 334 305 270 minecraft:light_blue_concrete
fill 335 304 228 336 305 228 minecraft:white_concrete
fill 335 304 270 336 305 270 minecraft:white_concrete
fill 337 304 228 338 305 228 minecraft:light_blue_concrete
fill 337 304 270 338 305 270 minecraft:light_blue_concrete
fill 339 304 228 340 305 228 minecraft:white_concrete
fill 339 304 270 340 305 270 minecraft:white_concrete
fill 341 304 228 342 305 228 minecraft:light_blue_concrete
fill 341 304 270 342 305 270 minecraft:light_blue_concrete
fill 343 304 228 344 305 228 minecraft:white_concrete
fill 343 304 270 344 305 270 minecraft:white_concrete
fill 345 304 228 346 305 228 minecraft:light_blue_concrete
fill 345 304 270 346 305 270 minecraft:light_blue_concrete
fill 347 304 228 348 305 228 minecraft:white_concrete
fill 347 304 270 348 305 270 minecraft:white_concrete
fill 349 304 228 350 305 228 minecraft:light_blue_concrete
fill 349 304 270 350 305 270 minecraft:light_blue_concrete
fill 351 304 228 352 305 228 minecraft:white_concrete
fill 351 304 270 352 305 270 minecraft:white_concrete
fill 353 304 228 354 305 228 minecraft:light_blue_concrete
fill 353 304 270 354 305 270 minecraft:light_blue_concrete
fill 355 304 228 356 305 228 minecraft:white_concrete
fill 355 304 270 356 305 270 minecraft:white_concrete
fill 357 304 228 358 305 228 minecraft:light_blue_concrete
fill 357 304 270 358 305 270 minecraft:light_blue_concrete
fill 359 304 228 360 305 228 minecraft:white_concrete
fill 359 304 270 360 305 270 minecraft:white_concrete
fill 361 304 228 362 305 228 minecraft:light_blue_concrete
fill 361 304 270 362 305 270 minecraft:light_blue_concrete
fill 363 304 228 364 305 228 minecraft:white_concrete
fill 363 304 270 364 305 270 minecraft:white_concrete
fill 365 304 228 366 305 228 minecraft:light_blue_concrete
fill 365 304 270 366 305 270 minecraft:light_blue_concrete
fill 367 304 228 368 305 228 minecraft:white_concrete
fill 367 304 270 368 305 270 minecraft:white_concrete
fill 369 304 228 370 305 228 minecraft:light_blue_concrete
fill 369 304 270 370 305 270 minecraft:light_blue_concrete
fill 371 304 229 371 305 229 minecraft:light_blue_concrete
fill 371 304 230 371 305 231 minecraft:white_concrete
fill 371 304 232 371 305 233 minecraft:light_blue_concrete
fill 371 304 234 371 305 235 minecraft:white_concrete
fill 371 304 236 371 305 237 minecraft:light_blue_concrete
fill 371 304 238 371 305 239 minecraft:white_concrete
fill 371 304 240 371 305 241 minecraft:light_blue_concrete
fill 371 304 242 371 305 243 minecraft:white_concrete
fill 371 304 244 371 305 245 minecraft:light_blue_concrete
fill 371 304 246 371 305 247 minecraft:white_concrete
fill 371 304 248 371 305 249 minecraft:light_blue_concrete
fill 371 304 250 371 305 251 minecraft:white_concrete
fill 371 304 252 371 305 253 minecraft:light_blue_concrete
fill 371 304 254 371 305 255 minecraft:white_concrete
fill 371 304 256 371 305 257 minecraft:light_blue_concrete
fill 371 304 258 371 305 259 minecraft:white_concrete
fill 371 304 260 371 305 261 minecraft:light_blue_concrete
fill 371 304 262 371 305 263 minecraft:white_concrete
fill 371 304 264 371 305 265 minecraft:light_blue_concrete
fill 371 304 266 371 305 267 minecraft:white_concrete
fill 371 304 268 371 305 269 minecraft:light_blue_concrete
fill 371 304 270 371 305 270 minecraft:white_concrete
fill 329 306 228 329 307 229 minecraft:white_concrete
fill 329 306 230 329 307 231 minecraft:light_blue_concrete
fill 329 306 232 329 307 233 minecraft:white_concrete
fill 329 306 234 329 307 235 minecraft:light_blue_concrete
fill 329 306 236 329 307 237 minecraft:white_concrete
fill 329 306 238 329 307 239 minecraft:light_blue_concrete
fill 329 306 240 329 307 241 minecraft:white_concrete
fill 329 306 242 329 307 243 minecraft:light_blue_concrete
fill 329 306 244 329 307 245 minecraft:white_concrete
fill 329 306 246 329 307 247 minecraft:light_blue_concrete
fill 329 306 248 329 307 249 minecraft:white_concrete
fill 329 306 250 329 307 251 minecraft:light_blue_concrete
fill 329 306 252 329 307 253 minecraft:white_concrete
fill 329 306 254 329 307 255 minecraft:light_blue_concrete
fill 329 306 256 329 307 257 minecraft:white_concrete
fill 329 306 258 329 307 259 minecraft:light_blue_concrete
fill 329 306 260 329 307 261 minecraft:white_concrete
fill 329 306 262 329 307 263 minecraft:light_blue_concrete
fill 329 306 264 329 307 265 minecraft:white_concrete
fill 329 306 266 329 307 267 minecraft:light_blue_concrete
fill 329 306 268 329 307 269 minecraft:white_concrete
fill 330 306 228 330 307 228 minecraft:white_concrete
fill 330 306 270 330 307 270 minecraft:white_concrete
fill 331 306 228 332 307 228 minecraft:light_blue_concrete
fill 331 306 270 332 307 270 minecraft:light_blue_concrete
fill 333 306 228 334 307 228 minecraft:white_concrete
fill 333 306 270 334 307 270 minecraft:white_concrete
fill 335 306 228 336 307 228 minecraft:light_blue_concrete
fill 335 306 270 336 307 270 minecraft:light_blue_concrete
fill 337 306 228 338 307 228 minecraft:white_concrete
fill 337 306 270 338 307 270 minecraft:white_concrete
fill 339 306 228 340 307 228 minecraft:light_blue_concrete
fill 339 306 270 340 307 270 minecraft:light_blue_concrete
fill 341 306 228 342 307 228 minecraft:white_concrete
fill 341 306 270 342 307 270 minecraft:white_concrete
fill 343 306 228 344 307 228 minecraft:light_blue_concrete
fill 343 306 270 344 307 270 minecraft:light_blue_concrete
fill 345 306 228 346 307 228 minecraft:white_concrete
fill 345 306 270 346 307 270 minecraft:white_concrete
fill 347 306 228 348 307 228 minecraft:light_blue_concrete
fill 347 306 270 348 307 270 minecraft:light_blue_concrete
fill 349 306 228 350 307 228 minecraft:white_concrete
fill 349 306 270 350 307 270 minecraft:white_concrete
fill 351 306 228 352 307 228 minecraft:light_blue_concrete
fill 351 306 270 352 307 270 minecraft:light_blue_concrete
fill 353 306 228 354 307 228 minecraft:white_concrete
fill 353 306 270 354 307 270 minecraft:white_concrete
fill 355 306 228 356 307 228 minecraft:light_blue_concrete
fill 355 306 270 356 307 270 minecraft:light_blue_concrete
fill 357 306 228 358 307 228 minecraft:white_concrete
fill 357 306 270 358 307 270 minecraft:white_concrete
fill 359 306 228 360 307 228 minecraft:light_blue_concrete
fill 359 306 270 360 307 270 minecraft:light_blue_concrete
fill 361 306 228 362 307 228 minecraft:white_concrete
fill 361 306 270 362 307 270 minecraft:white_concrete
fill 363 306 228 364 307 228 minecraft:light_blue_concrete
fill 363 306 270 364 307 270 minecraft:light_blue_concrete
fill 365 306 228 366 307 228 minecraft:white_concrete
fill 365 306 270 366 307 270 minecraft:white_concrete
fill 367 306 228 368 307 228 minecraft:light_blue_concrete
fill 367 306 270 368 307 270 minecraft:light_blue_concrete
fill 369 306 228 370 307 228 minecraft:white_concrete
fill 369 306 270 370 307 270 minecraft:white_concrete
fill 371 306 229 371 307 229 minecraft:white_concrete
fill 371 306 230 371 307 231 minecraft:light_blue_concrete
fill 371 306 232 371 307 233 minecraft:white_concrete
fill 371 306 234 371 307 235 minecraft:light_blue_concrete
fill 371 306 236 371 307 237 minecraft:white_concrete
fill 371 306 238 371 307 239 minecraft:light_blue_concrete
fill 371 306 240 371 307 241 minecraft:white_concrete
fill 371 306 242 371 307 243 minecraft:light_blue_concrete
fill 371 306 244 371 307 245 minecraft:white_concrete
fill 371 306 246 371 307 247 minecraft:light_blue_concrete
fill 371 306 248 371 307 249 minecraft:white_concrete
fill 371 306 250 371 307 251 minecraft:light_blue_concrete
fill 371 306 252 371 307 253 minecraft:white_concrete
fill 371 306 254 371 307 255 minecraft:light_blue_concrete
fill 371 306 256 371 307 257 minecraft:white_concrete
fill 371 306 258 371 307 259 minecraft:light_blue_concrete
fill 371 306 260 371 307 261 minecraft:white_concrete
fill 371 306 262 371 307 263 minecraft:light_blue_concrete
fill 371 306 264 371 307 265 minecraft:white_concrete
fill 371 306 266 371 307 267 minecraft:light_blue_concrete
fill 371 306 268 371 307 269 minecraft:white_concrete
fill 371 306 270 371 307 270 minecraft:light_blue_concrete
fill 347 307 235 353 307 235 minecraft:white_terracotta
fill 329 308 228 329 308 229 minecraft:light_blue_concrete
fill 329 308 230 329 308 231 minecraft:white_concrete
fill 329 308 232 329 308 233 minecraft:light_blue_concrete
fill 329 308 234 329 308 235 minecraft:white_concrete
fill 329 308 236 329 308 237 minecraft:light_blue_concrete
fill 329 308 238 329 308 239 minecraft:white_concrete
fill 329 308 240 329 308 241 minecraft:light_blue_concrete
fill 329 308 242 329 308 243 minecraft:white_concrete
fill 329 308 244 329 308 245 minecraft:light_blue_concrete
fill 329 308 246 329 308 247 minecraft:white_concrete
fill 329 308 248 329 308 249 minecraft:light_blue_concrete
fill 329 308 250 329 308 251 minecraft:white_concrete
fill 329 308 252 329 308 253 minecraft:light_blue_concrete
fill 329 308 254 329 308 255 minecraft:white_concrete
fill 329 308 256 329 308 257 minecraft:light_blue_concrete
fill 329 308 258 329 308 259 minecraft:white_concrete
fill 329 308 260 329 308 261 minecraft:light_blue_concrete
fill 329 308 262 329 308 263 minecraft:white_concrete
fill 329 308 264 329 308 265 minecraft:light_blue_concrete
fill 329 308 266 329 308 267 minecraft:white_concrete
fill 329 308 268 329 308 269 minecraft:light_blue_concrete
setblock 330 308 228 minecraft:light_blue_concrete
setblock 330 308 270 minecraft:light_blue_concrete
fill 331 308 228 332 308 228 minecraft:white_concrete
fill 331 308 270 332 308 270 minecraft:white_concrete
fill 333 308 228 334 308 228 minecraft:light_blue_concrete
fill 333 308 270 334 308 270 minecraft:light_blue_concrete
fill 335 308 228 336 308 228 minecraft:white_concrete
fill 335 308 270 336 308 270 minecraft:white_concrete
fill 337 308 228 338 308 228 minecraft:light_blue_concrete
fill 337 308 270 338 308 270 minecraft:light_blue_concrete
fill 339 308 228 340 308 228 minecraft:white_concrete
fill 339 308 270 340 308 270 minecraft:white_concrete
fill 341 308 228 342 308 228 minecraft:light_blue_concrete
fill 341 308 270 342 308 270 minecraft:light_blue_concrete
fill 343 308 228 344 308 228 minecraft:white_concrete
fill 343 308 270 344 308 270 minecraft:white_concrete
fill 345 308 228 346 308 228 minecraft:light_blue_concrete
fill 345 308 270 346 308 270 minecraft:light_blue_concrete
fill 347 308 228 348 308 228 minecraft:white_concrete
fill 347 308 270 348 308 270 minecraft:white_concrete
fill 349 308 228 350 308 228 minecraft:light_blue_concrete
fill 349 308 270 350 308 270 minecraft:light_blue_concrete
fill 351 308 228 352 308 228 minecraft:white_concrete
fill 351 308 270 352 308 270 minecraft:white_concrete
fill 353 308 228 354 308 228 minecraft:light_blue_concrete
fill 353 308 270 354 308 270 minecraft:light_blue_concrete
fill 355 308 228 356 308 228 minecraft:white_concrete
fill 355 308 270 356 308 270 minecraft:white_concrete
fill 357 308 228 358 308 228 minecraft:light_blue_concrete
fill 357 308 270 358 308 270 minecraft:light_blue_concrete
fill 359 308 228 360 308 228 minecraft:white_concrete
fill 359 308 270 360 308 270 minecraft:white_concrete
fill 361 308 228 362 308 228 minecraft:light_blue_concrete
fill 361 308 270 362 308 270 minecraft:light_blue_concrete
fill 363 308 228 364 308 228 minecraft:white_concrete
fill 363 308 270 364 308 270 minecraft:white_concrete
fill 365 308 228 366 308 228 minecraft:light_blue_concrete
fill 365 308 270 366 308 270 minecraft:light_blue_concrete
fill 367 308 228 368 308 228 minecraft:white_concrete
fill 367 308 270 368 308 270 minecraft:white_concrete
fill 369 308 228 370 308 228 minecraft:light_blue_concrete
fill 369 308 270 370 308 270 minecraft:light_blue_concrete
setblock 371 308 229 minecraft:light_blue_concrete
fill 371 308 230 371 308 231 minecraft:white_concrete
fill 371 308 232 371 308 233 minecraft:light_blue_concrete
fill 371 308 234 371 308 235 minecraft:white_concrete
fill 371 308 236 371 308 237 minecraft:light_blue_concrete
fill 371 308 238 371 308 239 minecraft:white_concrete
fill 371 308 240 371 308 241 minecraft:light_blue_concrete
fill 371 308 242 371 308 243 minecraft:white_concrete
fill 371 308 244 371 308 245 minecraft:light_blue_concrete
fill 371 308 246 371 308 247 minecraft:white_concrete
fill 371 308 248 371 308 249 minecraft:light_blue_concrete
fill 371 308 250 371 308 251 minecraft:white_concrete
fill 371 308 252 371 308 253 minecraft:light_blue_concrete
fill 371 308 254 371 308 255 minecraft:white_concrete
fill 371 308 256 371 308 257 minecraft:light_blue_concrete
fill 371 308 258 371 308 259 minecraft:white_concrete
fill 371 308 260 371 308 261 minecraft:light_blue_concrete
fill 371 308 262 371 308 263 minecraft:white_concrete
fill 371 308 264 371 308 265 minecraft:light_blue_concrete
fill 371 308 266 371 308 267 minecraft:white_concrete
fill 371 308 268 371 308 269 minecraft:light_blue_concrete
setblock 371 308 270 minecraft:white_concrete
