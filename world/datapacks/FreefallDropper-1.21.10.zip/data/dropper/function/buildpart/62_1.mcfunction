fill 98 110 307 100 117 307 minecraft:yellow_concrete
fill 98 110 317 99 111 317 minecraft:white_concrete
fill 100 110 275 101 111 275 minecraft:red_concrete
fill 100 110 317 101 111 317 minecraft:red_concrete
fill 102 110 275 103 111 275 minecraft:white_concrete
fill 102 110 294 102 117 294 minecraft:yellow_concrete
fill 102 110 306 102 117 306 minecraft:yellow_concrete
fill 102 110 317 103 111 317 minecraft:white_concrete
fill 104 110 275 105 111 275 minecraft:red_concrete
setblock 104 110 278 minecraft:light[level=12]
setblock 104 110 285 minecraft:light[level=12]
setblock 104 110 292 minecraft:light[level=12]
fill 104 110 295 104 117 295 minecraft:yellow_concrete
fill 104 110 305 104 117 305 minecraft:yellow_concrete
setblock 104 110 306 minecraft:light[level=12]
setblock 104 110 313 minecraft:light[level=12]
fill 104 110 317 105 111 317 minecraft:red_concrete
fill 105 110 297 105 117 297 minecraft:yellow_concrete
fill 105 110 303 105 117 303 minecraft:yellow_concrete
fill 106 110 275 107 111 275 minecraft:white_concrete
fill 106 110 299 106 117 301 minecraft:yellow_concrete
fill 106 110 317 107 111 317 minecraft:white_concrete
fill 108 110 275 109 111 275 minecraft:red_concrete
setblock 108 110 311 minecraft:red_terracotta
setblock 108 110 313 minecraft:red_terracotta
fill 108 110 317 109 111 317 minecraft:red_concrete
fill 110 110 275 111 111 275 minecraft:white_concrete
setblock 110 110 311 minecraft:red_terracotta
setblock 110 110 313 minecraft:red_terracotta
fill 110 110 317 111 111 317 minecraft:white_concrete
setblock 111 110 278 minecraft:light[level=12]
setblock 111 110 285 minecraft:light[level=12]
setblock 111 110 292 minecraft:light[level=12]
setblock 111 110 299 minecraft:light[level=12]
setblock 111 110 306 minecraft:light[level=12]
setblock 111 110 313 minecraft:light[level=12]
fill 112 110 275 113 111 275 minecraft:red_concrete
fill 112 110 317 113 111 317 minecraft:red_concrete
fill 114 110 275 115 111 275 minecraft:white_concrete
fill 114 110 317 115 111 317 minecraft:white_concrete
fill 116 110 275 117 111 275 minecraft:red_concrete
fill 116 110 317 117 111 317 minecraft:red_concrete
fill 118 110 275 119 111 275 minecraft:white_concrete
setblock 118 110 278 minecraft:light[level=12]
setblock 118 110 285 minecraft:light[level=12]
setblock 118 110 292 minecraft:light[level=12]
setblock 118 110 299 minecraft:light[level=12]
setblock 118 110 306 minecraft:light[level=12]
setblock 118 110 313 minecraft:light[level=12]
fill 118 110 317 119 111 317 minecraft:white_concrete
fill 120 110 275 121 111 275 minecraft:red_concrete
fill 120 110 317 121 111 317 minecraft:red_concrete
fill 122 110 275 123 111 275 minecraft:white_concrete
fill 122 110 317 123 111 317 minecraft:white_concrete
fill 124 110 275 125 111 275 minecraft:red_concrete
fill 124 110 317 125 111 317 minecraft:red_concrete
setblock 125 110 278 minecraft:light[level=12]
setblock 125 110 285 minecraft:light[level=12]
setblock 125 110 292 minecraft:light[level=12]
setblock 125 110 299 minecraft:light[level=12]
setblock 125 110 306 minecraft:light[level=12]
setblock 125 110 313 minecraft:light[level=12]
fill 126 110 275 127 111 275 minecraft:white_concrete
fill 126 110 317 127 111 317 minecraft:white_concrete
fill 128 110 275 129 111 275 minecraft:red_concrete
fill 128 110 317 129 111 317 minecraft:red_concrete
fill 130 110 275 131 111 275 minecraft:white_concrete
fill 130 110 311 130 110 314 minecraft:brown_terracotta
fill 130 110 317 131 111 317 minecraft:white_concrete
fill 131 110 310 133 110 310 minecraft:brown_terracotta
setblock 131 110 314 minecraft:brown_terracotta
fill 132 110 275 133 111 275 minecraft:red_concrete
setblock 132 110 285 minecraft:light[level=12]
setblock 132 110 292 minecraft:light[level=12]
setblock 132 110 299 minecraft:light[level=12]
setblock 132 110 306 minecraft:light[level=12]
fill 132 110 317 133 111 317 minecraft:red_concrete
setblock 133 110 314 minecraft:brown_terracotta
fill 134 110 275 135 111 275 minecraft:white_concrete
fill 134 110 311 134 110 313 minecraft:brown_terracotta
fill 134 110 317 135 111 317 minecraft:white_concrete
fill 136 110 276 136 111 276 minecraft:white_concrete
fill 136 110 277 136 111 278 minecraft:red_concrete
fill 136 110 279 136 111 280 minecraft:white_concrete
fill 136 110 281 136 111 282 minecraft:red_concrete
fill 136 110 283 136 111 284 minecraft:white_concrete
fill 136 110 285 136 111 286 minecraft:red_concrete
fill 136 110 287 136 111 288 minecraft:white_concrete
fill 136 110 289 136 111 290 minecraft:red_concrete
fill 136 110 291 136 111 292 minecraft:white_concrete
fill 136 110 293 136 111 294 minecraft:red_concrete
fill 136 110 295 136 111 296 minecraft:white_concrete
fill 136 110 297 136 111 298 minecraft:red_concrete
fill 136 110 299 136 111 300 minecraft:white_concrete
fill 136 110 301 136 111 302 minecraft:red_concrete
fill 136 110 303 136 111 304 minecraft:white_concrete
fill 136 110 305 136 111 306 minecraft:red_concrete
fill 136 110 307 136 111 308 minecraft:white_concrete
fill 136 110 309 136 111 310 minecraft:red_concrete
fill 136 110 311 136 111 312 minecraft:white_concrete
fill 136 110 313 136 111 314 minecraft:red_concrete
fill 136 110 315 136 111 316 minecraft:white_concrete
fill 136 110 317 136 111 317 minecraft:red_concrete
setblock 95 111 294 minecraft:yellow_concrete
fill 97 111 293 97 116 293 minecraft:yellow_concrete
fill 97 111 307 97 116 307 minecraft:yellow_concrete
fill 101 111 293 101 116 293 minecraft:yellow_concrete
fill 101 111 307 101 116 307 minecraft:yellow_concrete
fill 103 111 294 103 116 294 minecraft:yellow_concrete
fill 103 111 306 103 116 306 minecraft:yellow_concrete
fill 105 111 296 105 116 296 minecraft:yellow_concrete
fill 105 111 304 105 116 304 minecraft:yellow_concrete
fill 106 111 298 106 116 298 minecraft:yellow_concrete
fill 106 111 302 106 116 302 minecraft:yellow_concrete
fill 94 112 275 94 113 276 minecraft:red_concrete
fill 94 112 277 94 113 278 minecraft:white_concrete
fill 94 112 279 94 113 280 minecraft:red_concrete
fill 94 112 281 94 113 282 minecraft:white_concrete
fill 94 112 283 94 113 284 minecraft:red_concrete
fill 94 112 285 94 113 286 minecraft:white_concrete
fill 94 112 287 94 113 288 minecraft:red_concrete
fill 94 112 289 94 113 290 minecraft:white_concrete
fill 94 112 291 94 113 292 minecraft:red_concrete
fill 94 112 293 94 113 294 minecraft:white_concrete
fill 94 112 295 94 113 296 minecraft:red_concrete
fill 94 112 297 94 113 298 minecraft:white_concrete
fill 94 112 299 94 113 300 minecraft:red_concrete
fill 94 112 301 94 113 302 minecraft:white_concrete
fill 94 112 303 94 113 304 minecraft:red_concrete
fill 94 112 305 94 113 306 minecraft:white_concrete
fill 94 112 307 94 113 308 minecraft:red_concrete
fill 94 112 309 94 113 310 minecraft:white_concrete
fill 94 112 311 94 113 312 minecraft:red_concrete
fill 94 112 313 94 113 314 minecraft:white_concrete
fill 94 112 315 94 113 316 minecraft:red_concrete
fill 95 112 275 95 113 275 minecraft:red_concrete
fill 95 112 276 95 113 281 minecraft:red_terracotta
fill 95 112 284 96 112 289 minecraft:red_terracotta
fill 95 112 292 96 112 297 minecraft:red_terracotta
fill 95 112 300 96 112 305 minecraft:red_terracotta
fill 95 112 308 96 112 313 minecraft:red_terracotta
fill 95 112 316 100 113 316 minecraft:red_terracotta
fill 95 112 317 95 113 317 minecraft:red_concrete
fill 96 112 275 97 113 275 minecraft:white_concrete
fill 96 112 277 96 112 283 minecraft:red_terracotta
fill 96 112 290 96 112 291 minecraft:red_terracotta
fill 96 112 298 96 112 299 minecraft:red_terracotta
fill 96 112 306 96 112 307 minecraft:red_terracotta
fill 96 112 314 96 112 315 minecraft:red_terracotta
fill 96 112 317 97 113 317 minecraft:white_concrete
fill 97 112 277 134 112 277 minecraft:red_terracotta
fill 97 112 303 102 120 303 minecraft:yellow_concrete
fill 97 112 315 135 112 315 minecraft:red_terracotta
fill 98 112 275 99 113 275 minecraft:red_concrete
fill 98 112 276 103 112 276 minecraft:red_terracotta
fill 98 112 317 99 113 317 minecraft:red_concrete
fill 100 112 275 101 113 275 minecraft:white_concrete
fill 100 112 317 101 113 317 minecraft:white_concrete
fill 102 112 275 103 112 275 minecraft:red_concrete
fill 102 112 293 102 115 293 minecraft:yellow_concrete
fill 102 112 307 102 115 307 minecraft:yellow_concrete
fill 102 112 317 103 113 317 minecraft:red_concrete
fill 103 112 316 108 113 316 minecraft:red_terracotta
fill 104 112 275 105 113 275 minecraft:white_concrete
fill 104 112 294 104 115 294 minecraft:yellow_concrete
fill 104 112 306 104 115 306 minecraft:yellow_concrete
fill 104 112 317 105 113 317 minecraft:white_concrete
fill 105 112 295 105 115 295 minecraft:yellow_concrete
fill 105 112 305 105 115 305 minecraft:yellow_concrete
fill 106 112 275 107 113 275 minecraft:red_concrete
fill 106 112 276 111 113 276 minecraft:red_terracotta
fill 106 112 297 106 115 297 minecraft:yellow_concrete
fill 106 112 303 106 115 303 minecraft:yellow_concrete
fill 106 112 317 107 113 317 minecraft:red_concrete
fill 108 112 275 109 113 275 minecraft:white_concrete
fill 108 112 317 109 113 317 minecraft:white_concrete
fill 110 112 275 111 113 275 minecraft:red_concrete
fill 110 112 317 111 113 317 minecraft:red_concrete
fill 111 112 316 116 113 316 minecraft:red_terracotta
fill 112 112 275 113 113 275 minecraft:white_concrete
fill 112 112 317 113 113 317 minecraft:white_concrete
fill 114 112 275 115 113 275 minecraft:red_concrete
fill 114 112 276 119 113 276 minecraft:red_terracotta
fill 114 112 317 115 113 317 minecraft:red_concrete
fill 116 112 275 117 113 275 minecraft:white_concrete
fill 116 112 317 117 113 317 minecraft:white_concrete
fill 118 112 275 119 113 275 minecraft:red_concrete
fill 118 112 317 119 113 317 minecraft:red_concrete
fill 119 112 316 124 113 316 minecraft:red_terracotta
fill 120 112 275 121 113 275 minecraft:white_concrete
fill 120 112 317 121 113 317 minecraft:white_concrete
fill 122 112 275 123 113 275 minecraft:red_concrete
fill 122 112 276 127 113 276 minecraft:red_terracotta
fill 122 112 317 123 113 317 minecraft:red_concrete
fill 124 112 275 125 113 275 minecraft:white_concrete
fill 124 112 317 125 113 317 minecraft:white_concrete
fill 126 112 275 127 113 275 minecraft:red_concrete
fill 126 112 317 127 113 317 minecraft:red_concrete
fill 127 112 316 132 113 316 minecraft:red_terracotta
fill 128 112 275 129 113 275 minecraft:white_concrete
fill 128 112 317 129 113 317 minecraft:white_concrete
fill 130 112 275 131 113 275 minecraft:red_concrete
fill 130 112 276 135 113 276 minecraft:red_terracotta
fill 130 112 317 131 113 317 minecraft:red_concrete
fill 132 112 275 133 113 275 minecraft:white_concrete
fill 132 112 317 133 113 317 minecraft:white_concrete
fill 134 112 275 135 113 275 minecraft:red_concrete
fill 134 112 278 134 112 314 minecraft:red_terracotta
fill 134 112 317 135 113 317 minecraft:red_concrete
fill 135 112 279 135 113 284 minecraft:red_terracotta
fill 135 112 287 135 113 292 minecraft:red_terracotta
fill 135 112 295 135 113 300 minecraft:red_terracotta
fill 135 112 303 135 113 308 minecraft:red_terracotta
fill 135 112 311 135 113 314 minecraft:red_terracotta
fill 135 112 316 135 113 316 minecraft:red_terracotta
fill 136 112 276 136 113 276 minecraft:red_concrete
fill 136 112 277 136 113 278 minecraft:white_concrete
fill 136 112 279 136 113 280 minecraft:red_concrete
fill 136 112 281 136 113 282 minecraft:white_concrete
fill 136 112 283 136 113 284 minecraft:red_concrete
fill 136 112 285 136 113 286 minecraft:white_concrete
fill 136 112 287 136 113 288 minecraft:red_concrete
fill 136 112 289 136 113 290 minecraft:white_concrete
fill 136 112 291 136 113 292 minecraft:red_concrete
fill 136 112 293 136 113 294 minecraft:white_concrete
fill 136 112 295 136 113 296 minecraft:red_concrete
fill 136 112 297 136 113 298 minecraft:white_concrete
fill 136 112 299 136 113 300 minecraft:red_concrete
fill 136 112 301 136 113 302 minecraft:white_concrete
fill 136 112 303 136 113 304 minecraft:red_concrete
fill 136 112 305 136 113 306 minecraft:white_concrete
fill 136 112 307 136 113 308 minecraft:red_concrete
fill 136 112 309 136 113 310 minecraft:white_concrete
fill 136 112 311 136 113 312 minecraft:red_concrete
fill 136 112 313 136 113 314 minecraft:white_concrete
fill 136 112 315 136 113 316 minecraft:red_concrete
fill 136 112 317 136 113 317 minecraft:white_concrete
fill 95 113 284 95 113 289 minecraft:red_terracotta
fill 95 113 292 95 113 297 minecraft:red_terracotta
fill 95 113 300 95 113 305 minecraft:red_terracotta
fill 95 113 308 95 113 313 minecraft:red_terracotta
fill 96 113 290 103 114 290 minecraft:shroomlight
fill 96 113 293 96 115 307 minecraft:yellow_concrete
fill 96 113 310 103 114 310 minecraft:shroomlight
fill 98 113 276 101 113 276 minecraft:red_terracotta
fill 98 113 289 100 114 289 minecraft:shroomlight
fill 98 113 311 100 114 311 minecraft:shroomlight
setblock 101 113 277 minecraft:iron_block
setblock 102 113 275 minecraft:red_concrete
setblock 102 113 276 minecraft:iron_block
fill 102 113 277 104 113 277 minecraft:black_concrete
setblock 102 113 278 minecraft:iron_block
setblock 103 113 275 minecraft:iron_block
setblock 103 113 276 minecraft:black_concrete
setblock 103 113 278 minecraft:black_concrete
setblock 103 113 279 minecraft:iron_block
setblock 104 113 276 minecraft:iron_block
setblock 104 113 278 minecraft:iron_block
fill 104 113 291 105 114 291 minecraft:shroomlight
fill 104 113 309 105 114 309 minecraft:shroomlight
fill 105 113 276 105 150 276 minecraft:red_terracotta
setblock 105 113 277 minecraft:iron_block
fill 105 113 292 106 114 292 minecraft:shroomlight
fill 105 113 308 106 114 308 minecraft:shroomlight
fill 106 113 293 107 114 293 minecraft:shroomlight
fill 106 113 307 107 114 307 minecraft:shroomlight
fill 107 113 294 108 114 294 minecraft:shroomlight
fill 107 113 306 108 114 306 minecraft:shroomlight
fill 108 113 295 108 114 295 minecraft:shroomlight
fill 108 113 305 108 114 305 minecraft:shroomlight
fill 109 113 296 109 114 304 minecraft:shroomlight
fill 110 113 299 110 114 301 minecraft:shroomlight
setblock 135 113 315 minecraft:red_terracotta
fill 94 114 275 94 115 276 minecraft:white_concrete
fill 94 114 277 94 115 278 minecraft:red_concrete
fill 94 114 279 94 115 280 minecraft:white_concrete
fill 94 114 281 94 115 282 minecraft:red_concrete
fill 94 114 283 94 115 284 minecraft:white_concrete
fill 94 114 285 94 115 286 minecraft:red_concrete
fill 94 114 287 94 115 288 minecraft:white_concrete
fill 94 114 289 94 115 290 minecraft:red_concrete
fill 94 114 291 94 115 292 minecraft:white_concrete
fill 94 114 293 94 115 294 minecraft:red_concrete
fill 94 114 295 94 115 296 minecraft:white_concrete
fill 94 114 297 94 115 298 minecraft:red_concrete
fill 94 114 299 94 115 300 minecraft:white_concrete
fill 94 114 301 94 115 302 minecraft:red_concrete
fill 94 114 303 94 115 304 minecraft:white_concrete
fill 94 114 305 94 115 306 minecraft:red_concrete
fill 94 114 307 94 115 308 minecraft:white_concrete
fill 94 114 309 94 115 310 minecraft:red_concrete
fill 94 114 311 94 115 312 minecraft:white_concrete
fill 94 114 313 94 115 314 minecraft:red_concrete
fill 94 114 315 94 115 316 minecraft:white_concrete
fill 95 114 275 95 115 275 minecraft:white_concrete
fill 95 114 294 95 116 297 minecraft:yellow_concrete
fill 95 114 300 95 118 305 minecraft:yellow_concrete
setblock 95 114 310 minecraft:shroomlight
fill 95 114 317 95 115 317 minecraft:white_concrete
fill 96 114 275 97 115 275 minecraft:red_concrete
fill 96 114 317 97 115 317 minecraft:red_concrete
setblock 97 114 278 minecraft:light[level=15]
setblock 97 114 286 minecraft:light[level=15]
fill 98 114 275 99 115 275 minecraft:white_concrete
fill 98 114 317 99 115 317 minecraft:white_concrete
fill 100 114 275 101 115 275 minecraft:red_concrete
fill 100 114 317 101 115 317 minecraft:red_concrete
fill 102 114 275 103 115 275 minecraft:white_concrete
fill 102 114 317 103 115 317 minecraft:white_concrete
fill 104 114 275 105 115 275 minecraft:red_concrete
fill 104 114 276 104 150 276 minecraft:red_terracotta
fill 104 114 317 105 115 317 minecraft:red_concrete
setblock 105 114 278 minecraft:light[level=15]
setblock 105 114 286 minecraft:light[level=15]
setblock 105 114 294 minecraft:light[level=15]
setblock 105 114 310 minecraft:light[level=15]
fill 106 114 275 107 115 275 minecraft:white_concrete
fill 106 114 317 107 115 317 minecraft:white_concrete
fill 108 114 275 109 115 275 minecraft:red_concrete
fill 108 114 317 109 115 317 minecraft:red_concrete
fill 110 114 275 111 115 275 minecraft:white_concrete
fill 110 114 317 111 115 317 minecraft:white_concrete
fill 112 114 275 113 115 275 minecraft:red_concrete
fill 112 114 317 113 115 317 minecraft:red_concrete
setblock 113 114 278 minecraft:light[level=15]
setblock 113 114 286 minecraft:light[level=15]
setblock 113 114 294 minecraft:light[level=15]
setblock 113 114 302 minecraft:light[level=15]
setblock 113 114 310 minecraft:light[level=15]
fill 114 114 275 115 115 275 minecraft:white_concrete
fill 114 114 317 115 115 317 minecraft:white_concrete
fill 116 114 275 117 115 275 minecraft:red_concrete
fill 116 114 317 117 115 317 minecraft:red_concrete
fill 118 114 275 119 115 275 minecraft:white_concrete
fill 118 114 317 119 115 317 minecraft:white_concrete
fill 120 114 275 121 115 275 minecraft:red_concrete
fill 120 114 317 121 115 317 minecraft:red_concrete
setblock 121 114 278 minecraft:light[level=15]
setblock 121 114 286 minecraft:light[level=15]
setblock 121 114 294 minecraft:light[level=15]
setblock 121 114 310 minecraft:light[level=15]
fill 122 114 275 123 115 275 minecraft:white_concrete
fill 122 114 317 123 115 317 minecraft:white_concrete
fill 124 114 275 125 115 275 minecraft:red_concrete
fill 124 114 317 125 115 317 minecraft:red_concrete
fill 126 114 275 127 115 275 minecraft:white_concrete
fill 126 114 317 127 115 317 minecraft:white_concrete
fill 128 114 275 129 115 275 minecraft:red_concrete
fill 128 114 317 129 115 317 minecraft:red_concrete
setblock 129 114 278 minecraft:light[level=15]
setblock 129 114 286 minecraft:light[level=15]
setblock 129 114 294 minecraft:light[level=15]
setblock 129 114 302 minecraft:light[level=15]
setblock 129 114 310 minecraft:light[level=15]
fill 130 114 275 131 115 275 minecraft:white_concrete
fill 130 114 317 131 115 317 minecraft:white_concrete
fill 132 114 275 133 115 275 minecraft:red_concrete
fill 132 114 317 133 115 317 minecraft:red_concrete
fill 134 114 275 135 115 275 minecraft:white_concrete
fill 134 114 317 135 115 317 minecraft:white_concrete
fill 136 114 276 136 115 276 minecraft:white_concrete
fill 136 114 277 136 115 278 minecraft:red_concrete
fill 136 114 279 136 115 280 minecraft:white_concrete
fill 136 114 281 136 115 282 minecraft:red_concrete
fill 136 114 283 136 115 284 minecraft:white_concrete
fill 136 114 285 136 115 286 minecraft:red_concrete
fill 136 114 287 136 115 288 minecraft:white_concrete
fill 136 114 289 136 115 290 minecraft:red_concrete
fill 136 114 291 136 115 292 minecraft:white_concrete
fill 136 114 293 136 115 294 minecraft:red_concrete
fill 136 114 295 136 115 296 minecraft:white_concrete
fill 136 114 297 136 115 298 minecraft:red_concrete
fill 136 114 299 136 115 300 minecraft:white_concrete
fill 136 114 301 136 115 302 minecraft:red_concrete
fill 136 114 303 136 115 304 minecraft:white_concrete
fill 136 114 305 136 115 306 minecraft:red_concrete
fill 136 114 307 136 115 308 minecraft:white_concrete
fill 136 114 309 136 115 310 minecraft:red_concrete
fill 136 114 311 136 115 312 minecraft:white_concrete
fill 136 114 313 136 115 314 minecraft:red_concrete
fill 136 114 315 136 115 316 minecraft:white_concrete
fill 136 114 317 136 115 317 minecraft:red_concrete
setblock 108 115 311 minecraft:red_terracotta
setblock 108 115 313 minecraft:red_terracotta
setblock 110 115 311 minecraft:red_terracotta
setblock 110 115 313 minecraft:red_terracotta
fill 130 115 278 130 115 280 minecraft:red_terracotta
fill 131 115 277 133 115 277 minecraft:red_terracotta
fill 131 115 281 133 115 281 minecraft:red_terracotta
fill 134 115 278 134 115 280 minecraft:red_terracotta
fill 94 116 275 94 117 276 minecraft:red_concrete
fill 94 116 277 94 117 278 minecraft:white_concrete
fill 94 116 279 94 117 279 minecraft:red_concrete
fill 94 116 280 94 121 280 minecraft:shroomlight
fill 94 116 281 94 117 282 minecraft:white_concrete
fill 94 116 283 94 117 284 minecraft:red_concrete
fill 94 116 285 94 117 286 minecraft:white_concrete
fill 94 116 287 94 117 287 minecraft:red_concrete
fill 94 116 288 94 121 288 minecraft:shroomlight
fill 94 116 289 94 117 290 minecraft:white_concrete
fill 94 116 291 94 117 292 minecraft:red_concrete
fill 94 116 293 94 117 294 minecraft:white_concrete
fill 94 116 295 94 117 295 minecraft:red_concrete
fill 94 116 296 94 121 296 minecraft:shroomlight
fill 94 116 297 94 117 298 minecraft:white_concrete
fill 94 116 299 94 117 300 minecraft:red_concrete
fill 94 116 301 94 117 302 minecraft:white_concrete
fill 94 116 303 94 117 303 minecraft:red_concrete
fill 94 116 304 94 121 304 minecraft:shroomlight
fill 94 116 305 94 117 306 minecraft:white_concrete
fill 94 116 307 94 117 308 minecraft:red_concrete
fill 94 116 309 94 117 310 minecraft:white_concrete
fill 94 116 311 94 117 311 minecraft:red_concrete
fill 94 116 312 94 121 312 minecraft:shroomlight
fill 94 116 313 94 117 314 minecraft:white_concrete
fill 94 116 315 94 117 316 minecraft:red_concrete
fill 95 116 275 95 117 275 minecraft:red_concrete
fill 95 116 317 95 117 317 minecraft:red_concrete
fill 96 116 275 97 117 275 minecraft:white_concrete
fill 96 116 294 96 117 306 minecraft:yellow_concrete
fill 96 116 317 96 117 317 minecraft:white_concrete
setblock 97 116 278 minecraft:light[level=12]
setblock 97 116 285 minecraft:light[level=12]
setblock 97 116 292 minecraft:light[level=12]
setblock 97 116 313 minecraft:light[level=12]
fill 97 116 317 97 121 317 minecraft:shroomlight
fill 98 116 275 99 117 275 minecraft:red_concrete
fill 98 116 317 99 117 317 minecraft:red_concrete
fill 100 116 275 100 117 275 minecraft:white_concrete
fill 100 116 317 101 117 317 minecraft:white_concrete
fill 101 116 275 101 121 275 minecraft:shroomlight
fill 102 116 275 103 117 275 minecraft:red_concrete
fill 102 116 317 103 117 317 minecraft:red_concrete
fill 104 116 275 105 117 275 minecraft:white_concrete
setblock 104 116 278 minecraft:light[level=12]
setblock 104 116 285 minecraft:light[level=12]
setblock 104 116 292 minecraft:light[level=12]
setblock 104 116 306 minecraft:light[level=12]
setblock 104 116 313 minecraft:light[level=12]
fill 104 116 317 104 117 317 minecraft:white_concrete
fill 105 116 317 105 121 317 minecraft:shroomlight
fill 106 116 275 107 117 275 minecraft:red_concrete
fill 106 116 317 107 117 317 minecraft:red_concrete
fill 108 116 275 108 117 275 minecraft:white_concrete
fill 108 116 317 109 117 317 minecraft:white_concrete
fill 109 116 275 109 121 275 minecraft:shroomlight
fill 110 116 275 111 117 275 minecraft:red_concrete
fill 110 116 317 111 117 317 minecraft:red_concrete
setblock 111 116 278 minecraft:light[level=12]
setblock 111 116 285 minecraft:light[level=12]
setblock 111 116 292 minecraft:light[level=12]
setblock 111 116 299 minecraft:light[level=12]
setblock 111 116 306 minecraft:light[level=12]
setblock 111 116 313 minecraft:light[level=12]
fill 112 116 275 113 117 275 minecraft:white_concrete
fill 112 116 317 112 117 317 minecraft:white_concrete
fill 113 116 317 113 121 317 minecraft:shroomlight
fill 114 116 275 115 117 275 minecraft:red_concrete
fill 114 116 317 115 117 317 minecraft:red_concrete
fill 116 116 275 116 117 275 minecraft:white_concrete
fill 116 116 317 117 117 317 minecraft:white_concrete
fill 117 116 275 117 121 275 minecraft:shroomlight
fill 118 116 275 119 117 275 minecraft:red_concrete
setblock 118 116 278 minecraft:light[level=12]
setblock 118 116 285 minecraft:light[level=12]
setblock 118 116 292 minecraft:light[level=12]
setblock 118 116 299 minecraft:light[level=12]
setblock 118 116 306 minecraft:light[level=12]
setblock 118 116 313 minecraft:light[level=12]
fill 118 116 317 119 117 317 minecraft:red_concrete
fill 120 116 275 121 117 275 minecraft:white_concrete
fill 120 116 317 120 117 317 minecraft:white_concrete
fill 121 116 317 121 121 317 minecraft:shroomlight
fill 122 116 275 123 117 275 minecraft:red_concrete
fill 122 116 317 123 117 317 minecraft:red_concrete
fill 124 116 275 124 117 275 minecraft:white_concrete
fill 124 116 317 125 117 317 minecraft:white_concrete
fill 125 116 275 125 121 275 minecraft:shroomlight
setblock 125 116 278 minecraft:light[level=12]
setblock 125 116 285 minecraft:light[level=12]
setblock 125 116 292 minecraft:light[level=12]
setblock 125 116 299 minecraft:light[level=12]
setblock 125 116 306 minecraft:light[level=12]
setblock 125 116 313 minecraft:light[level=12]
fill 126 116 275 127 117 275 minecraft:red_concrete
fill 126 116 317 127 117 317 minecraft:red_concrete
fill 128 116 275 129 117 275 minecraft:white_concrete
fill 128 116 317 128 117 317 minecraft:white_concrete
fill 129 116 317 129 121 317 minecraft:shroomlight
fill 130 116 275 131 117 275 minecraft:red_concrete
fill 130 116 317 131 117 317 minecraft:red_concrete
fill 132 116 275 132 117 275 minecraft:white_concrete
setblock 132 116 285 minecraft:light[level=12]
setblock 132 116 292 minecraft:light[level=12]
setblock 132 116 299 minecraft:light[level=12]
setblock 132 116 306 minecraft:light[level=12]
fill 132 116 317 133 117 317 minecraft:white_concrete
fill 133 116 275 133 121 275 minecraft:shroomlight
fill 134 116 275 135 117 275 minecraft:red_concrete
fill 134 116 317 135 117 317 minecraft:red_concrete
fill 136 116 276 136 117 276 minecraft:red_concrete
fill 136 116 277 136 117 278 minecraft:white_concrete
fill 136 116 279 136 117 279 minecraft:red_concrete
fill 136 116 280 136 121 280 minecraft:shroomlight
fill 136 116 281 136 117 282 minecraft:white_concrete
fill 136 116 283 136 117 284 minecraft:red_concrete
fill 136 116 285 136 117 286 minecraft:white_concrete
fill 136 116 287 136 117 287 minecraft:red_concrete
fill 136 116 288 136 121 288 minecraft:shroomlight
fill 136 116 289 136 117 290 minecraft:white_concrete
fill 136 116 291 136 117 292 minecraft:red_concrete
fill 136 116 293 136 117 294 minecraft:white_concrete
fill 136 116 295 136 117 295 minecraft:red_concrete
fill 136 116 296 136 121 296 minecraft:shroomlight
fill 136 116 297 136 117 298 minecraft:white_concrete
fill 136 116 299 136 117 300 minecraft:red_concrete
fill 136 116 301 136 117 302 minecraft:white_concrete
fill 136 116 303 136 117 303 minecraft:red_concrete
fill 136 116 304 136 121 304 minecraft:shroomlight
fill 136 116 305 136 117 306 minecraft:white_concrete
fill 136 116 307 136 117 308 minecraft:red_concrete
fill 136 116 309 136 117 310 minecraft:white_concrete
fill 136 116 311 136 117 311 minecraft:red_concrete
fill 136 116 312 136 121 312 minecraft:shroomlight
fill 136 116 313 136 117 314 minecraft:white_concrete
fill 136 116 315 136 117 316 minecraft:red_concrete
fill 136 116 317 136 117 317 minecraft:white_concrete
fill 95 117 295 95 118 297 minecraft:yellow_concrete
fill 94 118 275 94 119 276 minecraft:white_concrete
fill 94 118 277 94 119 278 minecraft:red_concrete
fill 94 118 279 94 119 279 minecraft:white_concrete
fill 94 118 281 94 119 282 minecraft:red_concrete
fill 94 118 283 94 119 284 minecraft:white_concrete
fill 94 118 285 94 119 286 minecraft:red_concrete
fill 94 118 287 94 119 287 minecraft:white_concrete
fill 94 118 289 94 119 290 minecraft:red_concrete
fill 94 118 291 94 119 292 minecraft:white_concrete
fill 94 118 293 94 119 294 minecraft:red_concrete
fill 94 118 295 94 119 295 minecraft:white_concrete
fill 94 118 297 94 119 298 minecraft:red_concrete
fill 94 118 299 94 119 300 minecraft:white_concrete
fill 94 118 301 94 119 302 minecraft:red_concrete
fill 94 118 303 94 119 303 minecraft:white_concrete
fill 94 118 305 94 119 306 minecraft:red_concrete
fill 94 118 307 94 119 308 minecraft:white_concrete
fill 94 118 309 94 119 310 minecraft:red_concrete
fill 94 118 311 94 119 311 minecraft:white_concrete
fill 94 118 313 94 119 314 minecraft:red_concrete
fill 94 118 315 94 119 316 minecraft:white_concrete
fill 95 118 275 95 119 275 minecraft:white_concrete
fill 95 118 317 95 119 317 minecraft:white_concrete
fill 96 118 275 97 119 275 minecraft:red_concrete
fill 96 118 295 96 118 305 minecraft:yellow_concrete
fill 96 118 317 96 119 317 minecraft:red_concrete
fill 98 118 275 99 119 275 minecraft:white_concrete
fill 98 118 317 99 119 317 minecraft:white_concrete
fill 100 118 275 100 119 275 minecraft:red_concrete
fill 100 118 317 101 119 317 minecraft:red_concrete
fill 102 118 275 103 119 275 minecraft:white_concrete
fill 102 118 317 103 119 317 minecraft:white_concrete
fill 104 118 275 105 119 275 minecraft:red_concrete
fill 104 118 317 104 119 317 minecraft:red_concrete
fill 106 118 275 107 119 275 minecraft:white_concrete
fill 106 118 317 107 119 317 minecraft:white_concrete
fill 108 118 275 108 119 275 minecraft:red_concrete
fill 108 118 317 109 119 317 minecraft:red_concrete
fill 110 118 275 111 119 275 minecraft:white_concrete
fill 110 118 317 111 119 317 minecraft:white_concrete
fill 112 118 275 113 119 275 minecraft:red_concrete
fill 112 118 317 112 119 317 minecraft:red_concrete
fill 114 118 275 115 119 275 minecraft:white_concrete
fill 114 118 317 115 119 317 minecraft:white_concrete
fill 116 118 275 116 119 275 minecraft:red_concrete
fill 116 118 317 117 119 317 minecraft:red_concrete
fill 118 118 275 119 119 275 minecraft:white_concrete
fill 118 118 317 119 119 317 minecraft:white_concrete
fill 120 118 275 121 119 275 minecraft:red_concrete
fill 120 118 317 120 119 317 minecraft:red_concrete
fill 122 118 275 123 119 275 minecraft:white_concrete
fill 122 118 317 123 119 317 minecraft:white_concrete
fill 124 118 275 124 119 275 minecraft:red_concrete
fill 124 118 317 125 119 317 minecraft:red_concrete
fill 126 118 275 127 119 275 minecraft:white_concrete
fill 126 118 317 127 119 317 minecraft:white_concrete
fill 128 118 275 129 119 275 minecraft:red_concrete
fill 128 118 317 128 119 317 minecraft:red_concrete
fill 130 118 275 131 119 275 minecraft:white_concrete
fill 130 118 311 130 118 314 minecraft:brown_terracotta
fill 130 118 317 131 119 317 minecraft:white_concrete
fill 131 118 310 133 118 310 minecraft:brown_terracotta
setblock 131 118 314 minecraft:brown_terracotta
fill 132 118 275 132 119 275 minecraft:red_concrete
fill 132 118 317 133 119 317 minecraft:red_concrete
setblock 133 118 314 minecraft:brown_terracotta
fill 134 118 275 135 119 275 minecraft:white_concrete
fill 134 118 311 134 118 313 minecraft:brown_terracotta
fill 134 118 317 135 119 317 minecraft:white_concrete
fill 136 118 276 136 119 276 minecraft:white_concrete
fill 136 118 277 136 119 278 minecraft:red_concrete
fill 136 118 279 136 119 279 minecraft:white_concrete
fill 136 118 281 136 119 282 minecraft:red_concrete
fill 136 118 283 136 119 284 minecraft:white_concrete
fill 136 118 285 136 119 286 minecraft:red_concrete
fill 136 118 287 136 119 287 minecraft:white_concrete
fill 136 118 289 136 119 290 minecraft:red_concrete
fill 136 118 291 136 119 292 minecraft:white_concrete
fill 136 118 293 136 119 294 minecraft:red_concrete
fill 136 118 295 136 119 295 minecraft:white_concrete
fill 136 118 297 136 119 298 minecraft:red_concrete
fill 136 118 299 136 119 300 minecraft:white_concrete
fill 136 118 301 136 119 302 minecraft:red_concrete
fill 136 118 303 136 119 303 minecraft:white_concrete
fill 136 118 305 136 119 306 minecraft:red_concrete
fill 136 118 307 136 119 308 minecraft:white_concrete
fill 136 118 309 136 119 310 minecraft:red_concrete
fill 136 118 311 136 119 311 minecraft:white_concrete
fill 136 118 313 136 119 314 minecraft:red_concrete
fill 136 118 315 136 119 316 minecraft:white_concrete
fill 136 118 317 136 119 317 minecraft:red_concrete
fill 95 119 296 96 119 297 minecraft:yellow_concrete
fill 95 119 300 96 119 304 minecraft:yellow_concrete
fill 96 119 298 96 120 299 minecraft:yellow_concrete
fill 94 120 275 94 121 276 minecraft:red_concrete
fill 94 120 277 94 121 278 minecraft:white_concrete
fill 94 120 279 94 121 279 minecraft:red_concrete
fill 94 120 281 94 121 282 minecraft:white_concrete
fill 94 120 283 94 121 284 minecraft:red_concrete
fill 94 120 285 94 121 286 minecraft:white_concrete
fill 94 120 287 94 121 287 minecraft:red_concrete
fill 94 120 289 94 121 290 minecraft:white_concrete
fill 94 120 291 94 121 292 minecraft:red_concrete
fill 94 120 293 94 121 294 minecraft:white_concrete
fill 94 120 295 94 121 295 minecraft:red_concrete
fill 94 120 297 94 121 298 minecraft:white_concrete
fill 94 120 299 94 121 300 minecraft:red_concrete
fill 94 120 301 94 121 302 minecraft:white_concrete
fill 94 120 303 94 121 303 minecraft:red_concrete
fill 94 120 305 94 121 306 minecraft:white_concrete
fill 94 120 307 94 121 308 minecraft:red_concrete
fill 94 120 309 94 121 310 minecraft:white_concrete
fill 94 120 311 94 121 311 minecraft:red_concrete
fill 94 120 313 94 121 314 minecraft:white_concrete
fill 94 120 315 94 121 316 minecraft:red_concrete
fill 95 120 275 95 121 275 minecraft:red_concrete
fill 95 120 300 96 120 302 minecraft:yellow_concrete
fill 95 120 317 95 121 317 minecraft:red_concrete
fill 96 120 275 97 121 275 minecraft:white_concrete
setblock 96 120 297 minecraft:yellow_concrete
setblock 96 120 303 minecraft:yellow_concrete
fill 96 120 317 96 121 317 minecraft:white_concrete
fill 98 120 275 99 121 275 minecraft:red_concrete
fill 98 120 317 99 121 317 minecraft:red_concrete
fill 100 120 275 100 121 275 minecraft:white_concrete
fill 100 120 317 101 121 317 minecraft:white_concrete
fill 102 120 275 103 121 275 minecraft:red_concrete
fill 102 120 317 103 121 317 minecraft:red_concrete
fill 104 120 275 105 121 275 minecraft:white_concrete
fill 104 120 317 104 121 317 minecraft:white_concrete
fill 106 120 275 107 121 275 minecraft:red_concrete
fill 106 120 317 107 121 317 minecraft:red_concrete
fill 108 120 275 108 121 275 minecraft:white_concrete
setblock 108 120 311 minecraft:red_terracotta
setblock 108 120 313 minecraft:red_terracotta
fill 108 120 317 109 121 317 minecraft:white_concrete
fill 110 120 275 111 121 275 minecraft:red_concrete
setblock 110 120 311 minecraft:red_terracotta
setblock 110 120 313 minecraft:red_terracotta
fill 110 120 317 111 121 317 minecraft:red_concrete
fill 112 120 275 113 121 275 minecraft:white_concrete
fill 112 120 317 112 121 317 minecraft:white_concrete
fill 114 120 275 115 121 275 minecraft:red_concrete
fill 114 120 317 115 121 317 minecraft:red_concrete
fill 116 120 275 116 121 275 minecraft:white_concrete
fill 116 120 317 117 121 317 minecraft:white_concrete
fill 118 120 275 119 121 275 minecraft:red_concrete
fill 118 120 317 119 121 317 minecraft:red_concrete
fill 120 120 275 121 121 275 minecraft:white_concrete
fill 120 120 317 120 121 317 minecraft:white_concrete
fill 122 120 275 123 121 275 minecraft:red_concrete
fill 122 120 317 123 121 317 minecraft:red_concrete
fill 124 120 275 124 121 275 minecraft:white_concrete
fill 124 120 317 125 121 317 minecraft:white_concrete
fill 126 120 275 127 121 275 minecraft:red_concrete
fill 126 120 317 127 121 317 minecraft:red_concrete
fill 128 120 275 129 121 275 minecraft:white_concrete
fill 128 120 317 128 121 317 minecraft:white_concrete
fill 130 120 275 131 121 275 minecraft:red_concrete
fill 130 120 317 131 121 317 minecraft:red_concrete
fill 132 120 275 132 121 275 minecraft:white_concrete
fill 132 120 317 133 121 317 minecraft:white_concrete
fill 134 120 275 135 121 275 minecraft:red_concrete
fill 134 120 317 135 121 317 minecraft:red_concrete
fill 136 120 276 136 121 276 minecraft:red_concrete
fill 136 120 277 136 121 278 minecraft:white_concrete
fill 136 120 279 136 121 279 minecraft:red_concrete
fill 136 120 281 136 121 282 minecraft:white_concrete
fill 136 120 283 136 121 284 minecraft:red_concrete
fill 136 120 285 136 121 286 minecraft:white_concrete
fill 136 120 287 136 121 287 minecraft:red_concrete
fill 136 120 289 136 121 290 minecraft:white_concrete
fill 136 120 291 136 121 292 minecraft:red_concrete
fill 136 120 293 136 121 294 minecraft:white_concrete
fill 136 120 295 136 121 295 minecraft:red_concrete
fill 136 120 297 136 121 298 minecraft:white_concrete
fill 136 120 299 136 121 300 minecraft:red_concrete
fill 136 120 301 136 121 302 minecraft:white_concrete
fill 136 120 303 136 121 303 minecraft:red_concrete
fill 136 120 305 136 121 306 minecraft:white_concrete
fill 136 120 307 136 121 308 minecraft:red_concrete
fill 136 120 309 136 121 310 minecraft:white_concrete
fill 136 120 311 136 121 311 minecraft:red_concrete
fill 136 120 313 136 121 314 minecraft:white_concrete
fill 136 120 315 136 121 316 minecraft:red_concrete
fill 136 120 317 136 121 317 minecraft:white_concrete
fill 126 121 293 126 122 293 minecraft:yellow_wool
fill 94 122 275 94 123 276 minecraft:white_concrete
fill 94 122 277 94 123 278 minecraft:red_concrete
fill 94 122 279 94 123 280 minecraft:white_concrete
fill 94 122 281 94 123 282 minecraft:red_concrete
fill 94 122 283 94 123 284 minecraft:white_concrete
fill 94 122 285 94 123 286 minecraft:red_concrete
fill 94 122 287 94 123 288 minecraft:white_concrete
fill 94 122 289 94 123 290 minecraft:red_concrete
fill 94 122 291 94 123 292 minecraft:white_concrete
fill 94 122 293 94 123 294 minecraft:red_concrete
fill 94 122 295 94 123 296 minecraft:white_concrete
fill 94 122 297 94 123 298 minecraft:red_concrete
fill 94 122 299 94 123 300 minecraft:white_concrete
fill 94 122 301 94 123 302 minecraft:red_concrete
fill 94 122 303 94 123 304 minecraft:white_concrete
fill 94 122 305 94 123 306 minecraft:red_concrete
fill 94 122 307 94 123 308 minecraft:white_concrete
fill 94 122 309 94 123 310 minecraft:red_concrete
fill 94 122 311 94 123 312 minecraft:white_concrete
fill 94 122 313 94 123 314 minecraft:red_concrete
fill 94 122 315 94 123 316 minecraft:white_concrete
fill 95 122 275 95 123 275 minecraft:white_concrete
fill 95 122 317 95 123 317 minecraft:white_concrete
fill 96 122 275 97 123 275 minecraft:red_concrete
fill 96 122 317 97 123 317 minecraft:red_concrete
setblock 97 122 278 minecraft:light[level=15]
setblock 97 122 285 minecraft:light[level=12]
setblock 97 122 286 minecraft:light[level=15]
setblock 97 122 292 minecraft:light[level=12]
setblock 97 122 294 minecraft:light[level=15]
setblock 97 122 299 minecraft:light[level=12]
setblock 97 122 302 minecraft:light[level=15]
setblock 97 122 306 minecraft:light[level=12]
setblock 97 122 310 minecraft:light[level=15]
setblock 97 122 313 minecraft:light[level=12]
fill 98 122 275 99 123 275 minecraft:white_concrete
fill 98 122 317 99 123 317 minecraft:white_concrete
fill 100 122 275 101 123 275 minecraft:red_concrete
fill 100 122 317 101 123 317 minecraft:red_concrete
fill 102 122 275 103 123 275 minecraft:white_concrete
fill 102 122 317 103 123 317 minecraft:white_concrete
fill 104 122 275 105 123 275 minecraft:red_concrete
setblock 104 122 278 minecraft:light[level=12]
setblock 104 122 285 minecraft:light[level=12]
setblock 104 122 292 minecraft:light[level=12]
setblock 104 122 299 minecraft:light[level=12]
setblock 104 122 306 minecraft:light[level=12]
setblock 104 122 313 minecraft:light[level=12]
fill 104 122 317 105 123 317 minecraft:red_concrete
setblock 105 122 278 minecraft:light[level=15]
setblock 105 122 286 minecraft:light[level=15]
setblock 105 122 294 minecraft:light[level=15]
setblock 105 122 302 minecraft:light[level=15]
setblock 105 122 310 minecraft:light[level=15]
fill 106 122 275 107 123 275 minecraft:white_concrete
fill 106 122 317 107 123 317 minecraft:white_concrete
fill 108 122 275 109 123 275 minecraft:red_concrete
fill 108 122 317 109 123 317 minecraft:red_concrete
fill 110 122 275 111 123 275 minecraft:white_concrete
fill 110 122 317 111 123 317 minecraft:white_concrete
setblock 111 122 278 minecraft:light[level=12]
setblock 111 122 285 minecraft:light[level=12]
setblock 111 122 292 minecraft:light[level=12]
setblock 111 122 299 minecraft:light[level=12]
setblock 111 122 306 minecraft:light[level=12]
setblock 111 122 313 minecraft:light[level=12]
fill 112 122 275 113 123 275 minecraft:red_concrete
fill 112 122 317 113 123 317 minecraft:red_concrete
setblock 113 122 278 minecraft:light[level=15]
setblock 113 122 286 minecraft:light[level=15]
setblock 113 122 294 minecraft:light[level=15]
setblock 113 122 302 minecraft:light[level=15]
setblock 113 122 310 minecraft:light[level=15]
fill 114 122 275 115 123 275 minecraft:white_concrete
fill 114 122 317 115 123 317 minecraft:white_concrete
fill 116 122 275 117 123 275 minecraft:red_concrete
fill 116 122 317 117 123 317 minecraft:red_concrete
fill 118 122 275 119 123 275 minecraft:white_concrete
setblock 118 122 278 minecraft:light[level=12]
setblock 118 122 285 minecraft:light[level=12]
setblock 118 122 292 minecraft:light[level=12]
setblock 118 122 299 minecraft:light[level=12]
setblock 118 122 306 minecraft:light[level=12]
setblock 118 122 313 minecraft:light[level=12]
fill 118 122 317 119 123 317 minecraft:white_concrete
fill 120 122 275 121 123 275 minecraft:red_concrete
fill 120 122 317 121 123 317 minecraft:red_concrete
setblock 121 122 278 minecraft:light[level=15]
setblock 121 122 286 minecraft:light[level=15]
setblock 121 122 294 minecraft:light[level=15]
setblock 121 122 310 minecraft:light[level=15]
fill 122 122 275 123 123 275 minecraft:white_concrete
fill 122 122 317 123 123 317 minecraft:white_concrete
fill 124 122 275 125 123 275 minecraft:red_concrete
fill 124 122 317 125 123 317 minecraft:red_concrete
setblock 125 122 278 minecraft:light[level=12]
setblock 125 122 285 minecraft:light[level=12]
setblock 125 122 292 minecraft:light[level=12]
setblock 125 122 299 minecraft:light[level=12]
setblock 125 122 306 minecraft:light[level=12]
setblock 125 122 313 minecraft:light[level=12]
fill 126 122 275 127 123 275 minecraft:white_concrete
fill 126 122 317 127 123 317 minecraft:white_concrete
fill 128 122 275 129 123 275 minecraft:red_concrete
fill 128 122 317 129 123 317 minecraft:red_concrete
setblock 129 122 278 minecraft:light[level=15]
setblock 129 122 286 minecraft:light[level=15]
setblock 129 122 294 minecraft:light[level=15]
setblock 129 122 302 minecraft:light[level=15]
setblock 129 122 310 minecraft:light[level=15]
fill 130 122 275 131 123 275 minecraft:white_concrete
fill 130 122 278 130 122 280 minecraft:red_terracotta
fill 130 122 317 131 123 317 minecraft:white_concrete
fill 131 122 277 133 122 277 minecraft:red_terracotta
fill 131 122 281 133 122 281 minecraft:red_terracotta
fill 132 122 275 133 123 275 minecraft:red_concrete
setblock 132 122 285 minecraft:light[level=12]
setblock 132 122 292 minecraft:light[level=12]
setblock 132 122 299 minecraft:light[level=12]
setblock 132 122 306 minecraft:light[level=12]
fill 132 122 317 133 123 317 minecraft:red_concrete
fill 134 122 275 135 123 275 minecraft:white_concrete
fill 134 122 278 134 122 280 minecraft:red_terracotta
fill 134 122 317 135 123 317 minecraft:white_concrete
fill 136 122 276 136 123 276 minecraft:white_concrete
fill 136 122 277 136 123 278 minecraft:red_concrete
fill 136 122 279 136 123 280 minecraft:white_concrete
fill 136 122 281 136 123 282 minecraft:red_concrete
fill 136 122 283 136 123 284 minecraft:white_concrete
fill 136 122 285 136 123 286 minecraft:red_concrete
fill 136 122 287 136 123 288 minecraft:white_concrete
fill 136 122 289 136 123 290 minecraft:red_concrete
fill 136 122 291 136 123 292 minecraft:white_concrete
fill 136 122 293 136 123 294 minecraft:red_concrete
fill 136 122 295 136 123 296 minecraft:white_concrete
fill 136 122 297 136 123 298 minecraft:red_concrete
fill 136 122 299 136 123 300 minecraft:white_concrete
fill 136 122 301 136 123 302 minecraft:red_concrete
fill 136 122 303 136 123 304 minecraft:white_concrete
fill 136 122 305 136 123 306 minecraft:red_concrete
fill 136 122 307 136 123 308 minecraft:white_concrete
fill 136 122 309 136 123 310 minecraft:red_concrete
fill 136 122 311 136 123 312 minecraft:white_concrete
fill 136 122 313 136 123 314 minecraft:red_concrete
fill 136 122 315 136 123 316 minecraft:white_concrete
fill 136 122 317 136 123 317 minecraft:red_concrete
fill 94 124 275 94 125 276 minecraft:red_concrete
fill 94 124 277 94 125 278 minecraft:white_concrete
fill 94 124 279 94 125 280 minecraft:red_concrete
fill 94 124 281 94 125 282 minecraft:white_concrete
fill 94 124 283 94 125 284 minecraft:red_concrete
fill 94 124 285 94 125 286 minecraft:white_concrete
fill 94 124 287 94 125 288 minecraft:red_concrete
fill 94 124 289 94 125 290 minecraft:white_concrete
fill 94 124 291 94 125 292 minecraft:red_concrete
fill 94 124 293 94 125 294 minecraft:white_concrete
fill 94 124 295 94 125 296 minecraft:red_concrete
fill 94 124 297 94 125 298 minecraft:white_concrete
fill 94 124 299 94 125 300 minecraft:red_concrete
fill 94 124 301 94 125 302 minecraft:white_concrete
fill 94 124 303 94 125 304 minecraft:red_concrete
fill 94 124 305 94 125 306 minecraft:white_concrete
fill 94 124 307 94 125 308 minecraft:red_concrete
fill 94 124 309 94 125 310 minecraft:white_concrete
fill 94 124 311 94 125 312 minecraft:red_concrete
fill 94 124 313 94 125 314 minecraft:white_concrete
fill 94 124 315 94 125 316 minecraft:red_concrete
fill 95 124 275 95 125 275 minecraft:red_concrete
fill 95 124 317 95 125 317 minecraft:red_concrete
fill 96 124 275 97 125 275 minecraft:white_concrete
fill 96 124 317 97 125 317 minecraft:white_concrete
fill 98 124 275 99 125 275 minecraft:red_concrete
fill 98 124 317 99 125 317 minecraft:red_concrete
fill 100 124 275 101 125 275 minecraft:white_concrete
fill 100 124 317 101 125 317 minecraft:white_concrete
fill 102 124 275 103 125 275 minecraft:red_concrete
fill 102 124 317 103 125 317 minecraft:red_concrete
fill 104 124 275 105 125 275 minecraft:white_concrete
fill 104 124 317 105 125 317 minecraft:white_concrete
fill 106 124 275 107 125 275 minecraft:red_concrete
fill 106 124 317 107 125 317 minecraft:red_concrete
fill 108 124 275 109 125 275 minecraft:white_concrete
fill 108 124 317 109 125 317 minecraft:white_concrete
fill 110 124 275 111 125 275 minecraft:red_concrete
fill 110 124 317 111 125 317 minecraft:red_concrete
fill 112 124 275 113 125 275 minecraft:white_concrete
fill 112 124 317 113 125 317 minecraft:white_concrete
fill 114 124 275 115 125 275 minecraft:red_concrete
fill 114 124 317 115 125 317 minecraft:red_concrete
fill 116 124 275 117 125 275 minecraft:white_concrete
fill 116 124 317 117 125 317 minecraft:white_concrete
fill 118 124 275 119 125 275 minecraft:red_concrete
fill 118 124 317 119 125 317 minecraft:red_concrete
fill 120 124 275 121 125 275 minecraft:white_concrete
fill 120 124 317 121 125 317 minecraft:white_concrete
fill 122 124 275 123 125 275 minecraft:red_concrete
fill 122 124 317 123 125 317 minecraft:red_concrete
fill 124 124 275 125 125 275 minecraft:white_concrete
fill 124 124 317 125 125 317 minecraft:white_concrete
fill 126 124 275 127 125 275 minecraft:red_concrete
fill 126 124 317 127 125 317 minecraft:red_concrete
fill 128 124 275 129 125 275 minecraft:white_concrete
fill 128 124 317 129 125 317 minecraft:white_concrete
fill 130 124 275 131 125 275 minecraft:red_concrete
fill 130 124 317 131 125 317 minecraft:red_concrete
fill 132 124 275 133 125 275 minecraft:white_concrete
fill 132 124 317 133 125 317 minecraft:white_concrete
fill 134 124 275 135 125 275 minecraft:red_concrete
fill 134 124 317 135 125 317 minecraft:red_concrete
fill 136 124 276 136 125 276 minecraft:red_concrete
fill 136 124 277 136 125 278 minecraft:white_concrete
fill 136 124 279 136 125 280 minecraft:red_concrete
fill 136 124 281 136 125 282 minecraft:white_concrete
fill 136 124 283 136 125 284 minecraft:red_concrete
fill 136 124 285 136 125 286 minecraft:white_concrete
fill 136 124 287 136 125 288 minecraft:red_concrete
fill 136 124 289 136 125 290 minecraft:white_concrete
fill 136 124 291 136 125 292 minecraft:red_concrete
fill 136 124 293 136 125 294 minecraft:white_concrete
fill 136 124 295 136 125 296 minecraft:red_concrete
fill 136 124 297 136 125 298 minecraft:white_concrete
fill 136 124 299 136 125 300 minecraft:red_concrete
fill 136 124 301 136 125 302 minecraft:white_concrete
fill 136 124 303 136 125 304 minecraft:red_concrete
fill 136 124 305 136 125 306 minecraft:white_concrete
fill 136 124 307 136 125 308 minecraft:red_concrete
fill 136 124 309 136 125 310 minecraft:white_concrete
fill 136 124 311 136 125 312 minecraft:red_concrete
fill 136 124 313 136 125 314 minecraft:white_concrete
fill 136 124 315 136 125 316 minecraft:red_concrete
fill 136 124 317 136 125 317 minecraft:white_concrete
setblock 108 125 311 minecraft:red_terracotta
setblock 108 125 313 minecraft:red_terracotta
setblock 110 125 311 minecraft:red_terracotta
setblock 110 125 313 minecraft:red_terracotta
fill 94 126 275 94 127 276 minecraft:white_concrete
fill 94 126 277 94 127 278 minecraft:red_concrete
fill 94 126 279 94 127 280 minecraft:white_concrete
fill 94 126 281 94 127 282 minecraft:red_concrete
fill 94 126 283 94 127 284 minecraft:white_concrete
fill 94 126 285 94 127 286 minecraft:red_concrete
fill 94 126 287 94 127 288 minecraft:white_concrete
fill 94 126 289 94 127 290 minecraft:red_concrete
fill 94 126 291 94 127 292 minecraft:white_concrete
fill 94 126 293 94 127 294 minecraft:red_concrete
fill 94 126 295 94 127 296 minecraft:white_concrete
fill 94 126 297 94 127 298 minecraft:red_concrete
fill 94 126 299 94 127 300 minecraft:white_concrete
fill 94 126 301 94 127 302 minecraft:red_concrete
fill 94 126 303 94 127 304 minecraft:white_concrete
fill 94 126 305 94 127 306 minecraft:red_concrete
fill 94 126 307 94 127 308 minecraft:white_concrete
fill 94 126 309 94 127 310 minecraft:red_concrete
fill 94 126 311 94 127 312 minecraft:white_concrete
fill 94 126 313 94 127 314 minecraft:red_concrete
fill 94 126 315 94 127 316 minecraft:white_concrete
fill 95 126 275 95 127 275 minecraft:white_concrete
fill 95 126 276 95 127 281 minecraft:red_terracotta
fill 95 126 284 96 126 289 minecraft:red_terracotta
fill 95 126 292 96 126 297 minecraft:red_terracotta
fill 95 126 300 96 126 305 minecraft:red_terracotta
fill 95 126 308 96 126 313 minecraft:red_terracotta
fill 95 126 316 100 127 316 minecraft:red_terracotta
fill 95 126 317 95 127 317 minecraft:white_concrete
fill 96 126 275 97 127 275 minecraft:red_concrete
fill 96 126 277 96 126 283 minecraft:red_terracotta
fill 96 126 290 96 126 291 minecraft:red_terracotta
fill 96 126 298 96 126 299 minecraft:red_terracotta
fill 96 126 306 96 126 307 minecraft:red_terracotta
fill 96 126 314 96 126 315 minecraft:red_terracotta
fill 96 126 317 97 127 317 minecraft:red_concrete
fill 97 126 277 134 126 277 minecraft:red_terracotta
fill 97 126 315 135 126 315 minecraft:red_terracotta
fill 98 126 275 99 127 275 minecraft:white_concrete
fill 98 126 276 103 127 276 minecraft:red_terracotta
fill 98 126 317 99 127 317 minecraft:white_concrete
fill 100 126 275 101 127 275 minecraft:red_concrete
fill 100 126 317 101 127 317 minecraft:red_concrete
fill 102 126 275 103 127 275 minecraft:white_concrete
fill 102 126 317 103 127 317 minecraft:white_concrete
fill 103 126 316 108 127 316 minecraft:red_terracotta
fill 104 126 275 105 127 275 minecraft:red_concrete
fill 104 126 317 105 127 317 minecraft:red_concrete
fill 106 126 275 107 127 275 minecraft:white_concrete
fill 106 126 276 111 127 276 minecraft:red_terracotta
fill 106 126 317 107 127 317 minecraft:white_concrete
fill 108 126 275 109 127 275 minecraft:red_concrete
fill 108 126 317 109 127 317 minecraft:red_concrete
fill 109 126 314 109 127 314 minecraft:iron_block
fill 110 126 275 111 127 275 minecraft:white_concrete
fill 110 126 317 111 127 317 minecraft:white_concrete
fill 111 126 316 116 127 316 minecraft:red_terracotta
fill 112 126 275 113 127 275 minecraft:red_concrete
fill 112 126 317 113 127 317 minecraft:red_concrete
fill 114 126 275 115 127 275 minecraft:white_concrete
fill 114 126 276 119 127 276 minecraft:red_terracotta
fill 114 126 317 115 127 317 minecraft:white_concrete
fill 116 126 275 117 127 275 minecraft:red_concrete
fill 116 126 317 117 127 317 minecraft:red_concrete
fill 118 126 275 119 127 275 minecraft:white_concrete
fill 118 126 317 119 127 317 minecraft:white_concrete
fill 119 126 316 124 127 316 minecraft:red_terracotta
fill 120 126 275 121 127 275 minecraft:red_concrete
fill 120 126 317 121 127 317 minecraft:red_concrete
fill 122 126 275 123 127 275 minecraft:white_concrete
fill 122 126 276 127 127 276 minecraft:red_terracotta
fill 122 126 307 123 127 308 minecraft:green_concrete
fill 122 126 317 123 127 317 minecraft:white_concrete
fill 124 126 275 125 127 275 minecraft:red_concrete
fill 124 126 317 125 127 317 minecraft:red_concrete
fill 126 126 275 127 127 275 minecraft:white_concrete
fill 126 126 317 127 127 317 minecraft:white_concrete
fill 127 126 316 132 127 316 minecraft:red_terracotta
fill 128 126 275 129 127 275 minecraft:red_concrete
fill 128 126 317 129 127 317 minecraft:red_concrete
fill 130 126 275 131 127 275 minecraft:white_concrete
fill 130 126 276 135 127 276 minecraft:red_terracotta
fill 130 126 311 130 126 314 minecraft:brown_terracotta
fill 130 126 317 131 127 317 minecraft:white_concrete
fill 131 126 310 133 126 310 minecraft:brown_terracotta
setblock 131 126 314 minecraft:brown_terracotta
fill 132 126 275 133 127 275 minecraft:red_concrete
fill 132 126 317 133 127 317 minecraft:red_concrete
setblock 133 126 314 minecraft:brown_terracotta
fill 134 126 275 135 127 275 minecraft:white_concrete
fill 134 126 278 134 126 314 minecraft:red_terracotta
fill 134 126 317 135 127 317 minecraft:white_concrete
fill 135 126 279 135 127 284 minecraft:red_terracotta
fill 135 126 287 135 127 292 minecraft:red_terracotta
fill 135 126 295 135 127 300 minecraft:red_terracotta
fill 135 126 303 135 127 308 minecraft:red_terracotta
fill 135 126 311 135 127 314 minecraft:red_terracotta
fill 135 126 316 135 127 316 minecraft:red_terracotta
fill 136 126 276 136 127 276 minecraft:white_concrete
fill 136 126 277 136 127 278 minecraft:red_concrete
fill 136 126 279 136 127 280 minecraft:white_concrete
fill 136 126 281 136 127 282 minecraft:red_concrete
fill 136 126 283 136 127 284 minecraft:white_concrete
fill 136 126 285 136 127 286 minecraft:red_concrete
fill 136 126 287 136 127 288 minecraft:white_concrete
fill 136 126 289 136 127 290 minecraft:red_concrete
fill 136 126 291 136 127 292 minecraft:white_concrete
fill 136 126 293 136 127 294 minecraft:red_concrete
fill 136 126 295 136 127 296 minecraft:white_concrete
fill 136 126 297 136 127 298 minecraft:red_concrete
fill 136 126 299 136 127 300 minecraft:white_concrete
fill 136 126 301 136 127 302 minecraft:red_concrete
fill 136 126 303 136 127 304 minecraft:white_concrete
fill 136 126 305 136 127 306 minecraft:red_concrete
fill 136 126 307 136 127 308 minecraft:white_concrete
fill 136 126 309 136 127 310 minecraft:red_concrete
fill 136 126 311 136 127 312 minecraft:white_concrete
fill 136 126 313 136 127 314 minecraft:red_concrete
fill 136 126 315 136 127 316 minecraft:white_concrete
fill 136 126 317 136 127 317 minecraft:red_concrete
fill 95 127 284 95 127 289 minecraft:red_terracotta
fill 95 127 292 95 127 297 minecraft:red_terracotta
fill 95 127 300 95 127 305 minecraft:red_terracotta
fill 95 127 308 95 127 313 minecraft:red_terracotta
fill 105 127 292 106 128 292 minecraft:brown_terracotta
setblock 109 127 310 minecraft:shroomlight
setblock 109 127 315 minecraft:iron_block
setblock 135 127 315 minecraft:red_terracotta
fill 94 128 275 94 129 276 minecraft:red_concrete
fill 94 128 277 94 129 278 minecraft:white_concrete
fill 94 128 279 94 129 280 minecraft:red_concrete
fill 94 128 281 94 129 282 minecraft:white_concrete
fill 94 128 283 94 129 284 minecraft:red_concrete
fill 94 128 285 94 129 286 minecraft:white_concrete
fill 94 128 287 94 129 288 minecraft:red_concrete
fill 94 128 289 94 129 290 minecraft:white_concrete
fill 94 128 291 94 129 292 minecraft:red_concrete
fill 94 128 293 94 129 294 minecraft:white_concrete
fill 94 128 295 94 129 296 minecraft:red_concrete
fill 94 128 297 94 129 298 minecraft:white_concrete
fill 94 128 299 94 129 300 minecraft:red_concrete
fill 94 128 301 94 129 302 minecraft:white_concrete
fill 94 128 303 94 129 304 minecraft:red_concrete
fill 94 128 305 94 129 306 minecraft:white_concrete
fill 94 128 307 94 129 308 minecraft:red_concrete
fill 94 128 309 94 129 310 minecraft:white_concrete
fill 94 128 311 94 129 312 minecraft:red_concrete
fill 94 128 313 94 129 314 minecraft:white_concrete
fill 94 128 315 94 129 316 minecraft:red_concrete
fill 95 128 275 95 129 275 minecraft:red_concrete
fill 95 128 317 95 129 317 minecraft:red_concrete
fill 96 128 275 97 129 275 minecraft:white_concrete
fill 96 128 317 97 129 317 minecraft:white_concrete
setblock 97 128 278 minecraft:light[level=12]
setblock 97 128 285 minecraft:light[level=12]
setblock 97 128 292 minecraft:light[level=12]
setblock 97 128 299 minecraft:light[level=12]
setblock 97 128 306 minecraft:light[level=12]
setblock 97 128 313 minecraft:light[level=12]
fill 98 128 275 99 129 275 minecraft:red_concrete
fill 98 128 317 99 129 317 minecraft:red_concrete
fill 100 128 275 101 129 275 minecraft:white_concrete
fill 100 128 317 101 129 317 minecraft:white_concrete
fill 102 128 275 103 129 275 minecraft:red_concrete
fill 102 128 317 103 129 317 minecraft:red_concrete
fill 104 128 275 105 129 275 minecraft:white_concrete
setblock 104 128 278 minecraft:light[level=12]
setblock 104 128 285 minecraft:light[level=12]
setblock 104 128 292 minecraft:light[level=12]
setblock 104 128 299 minecraft:light[level=12]
setblock 104 128 306 minecraft:light[level=12]
setblock 104 128 313 minecraft:light[level=12]
fill 104 128 317 105 129 317 minecraft:white_concrete
fill 106 128 275 107 129 275 minecraft:red_concrete
fill 106 128 317 107 129 317 minecraft:red_concrete
fill 108 128 275 109 129 275 minecraft:white_concrete
fill 108 128 317 109 129 317 minecraft:white_concrete
fill 110 128 275 111 129 275 minecraft:red_concrete
fill 110 128 317 111 129 317 minecraft:red_concrete
setblock 111 128 278 minecraft:light[level=12]
setblock 111 128 285 minecraft:light[level=12]
setblock 111 128 292 minecraft:light[level=12]
setblock 111 128 299 minecraft:light[level=12]
setblock 111 128 306 minecraft:light[level=12]
setblock 111 128 313 minecraft:light[level=12]
fill 112 128 275 113 129 275 minecraft:white_concrete
fill 112 128 317 113 129 317 minecraft:white_concrete
fill 114 128 275 115 129 275 minecraft:red_concrete
fill 114 128 317 115 129 317 minecraft:red_concrete
fill 116 128 275 117 129 275 minecraft:white_concrete
fill 116 128 317 117 129 317 minecraft:white_concrete
fill 118 128 275 119 129 275 minecraft:red_concrete
setblock 118 128 278 minecraft:light[level=12]
setblock 118 128 285 minecraft:light[level=12]
setblock 118 128 292 minecraft:light[level=12]
setblock 118 128 299 minecraft:light[level=12]
setblock 118 128 306 minecraft:light[level=12]
setblock 118 128 313 minecraft:light[level=12]
fill 118 128 317 119 129 317 minecraft:red_concrete
fill 120 128 275 121 129 275 minecraft:white_concrete
fill 120 128 317 121 129 317 minecraft:white_concrete
fill 122 128 275 123 129 275 minecraft:red_concrete
fill 122 128 317 123 129 317 minecraft:red_concrete
fill 124 128 275 125 129 275 minecraft:white_concrete
fill 124 128 317 125 129 317 minecraft:white_concrete
setblock 125 128 278 minecraft:light[level=12]
setblock 125 128 285 minecraft:light[level=12]
setblock 125 128 292 minecraft:light[level=12]
setblock 125 128 299 minecraft:light[level=12]
setblock 125 128 306 minecraft:light[level=12]
setblock 125 128 313 minecraft:light[level=12]
fill 126 128 275 127 129 275 minecraft:red_concrete
fill 126 128 317 127 129 317 minecraft:red_concrete
fill 128 128 275 129 129 275 minecraft:white_concrete
fill 128 128 317 129 129 317 minecraft:white_concrete
fill 130 128 275 131 129 275 minecraft:red_concrete
fill 130 128 317 131 129 317 minecraft:red_concrete
fill 132 128 275 133 129 275 minecraft:white_concrete
setblock 132 128 285 minecraft:light[level=12]
setblock 132 128 292 minecraft:light[level=12]
setblock 132 128 299 minecraft:light[level=12]
setblock 132 128 306 minecraft:light[level=12]
fill 132 128 317 133 129 317 minecraft:white_concrete
fill 134 128 275 135 129 275 minecraft:red_concrete
fill 134 128 317 135 129 317 minecraft:red_concrete
fill 136 128 276 136 129 276 minecraft:red_concrete
fill 136 128 277 136 129 278 minecraft:white_concrete
fill 136 128 279 136 129 280 minecraft:red_concrete
fill 136 128 281 136 129 282 minecraft:white_concrete
fill 136 128 283 136 129 284 minecraft:red_concrete
fill 136 128 285 136 129 286 minecraft:white_concrete
fill 136 128 287 136 129 288 minecraft:red_concrete
fill 136 128 289 136 129 290 minecraft:white_concrete
fill 136 128 291 136 129 292 minecraft:red_concrete
fill 136 128 293 136 129 294 minecraft:white_concrete
fill 136 128 295 136 129 296 minecraft:red_concrete
fill 136 128 297 136 129 298 minecraft:white_concrete
fill 136 128 299 136 129 300 minecraft:red_concrete
fill 136 128 301 136 129 302 minecraft:white_concrete
fill 136 128 303 136 129 304 minecraft:red_concrete
fill 136 128 305 136 129 306 minecraft:white_concrete
fill 136 128 307 136 129 308 minecraft:red_concrete
fill 136 128 309 136 129 310 minecraft:white_concrete
fill 136 128 311 136 129 312 minecraft:red_concrete
fill 136 128 313 136 129 314 minecraft:white_concrete
fill 136 128 315 136 129 316 minecraft:red_concrete
fill 136 128 317 136 129 317 minecraft:white_concrete
fill 130 129 278 130 129 280 minecraft:red_terracotta
fill 131 129 277 133 129 277 minecraft:red_terracotta
fill 131 129 281 133 129 281 minecraft:red_terracotta
fill 134 129 278 134 129 280 minecraft:red_terracotta
fill 94 130 275 94 131 276 minecraft:white_concrete
fill 94 130 277 94 131 278 minecraft:red_concrete
fill 94 130 279 94 131 279 minecraft:white_concrete
fill 94 130 280 94 135 280 minecraft:shroomlight
fill 94 130 281 94 131 282 minecraft:red_concrete
fill 94 130 283 94 131 284 minecraft:white_concrete
fill 94 130 285 94 131 286 minecraft:red_concrete
fill 94 130 287 94 131 287 minecraft:white_concrete
fill 94 130 288 94 135 288 minecraft:shroomlight
fill 94 130 289 94 131 290 minecraft:red_concrete
fill 94 130 291 94 131 292 minecraft:white_concrete
fill 94 130 293 94 131 294 minecraft:red_concrete
fill 94 130 295 94 131 295 minecraft:white_concrete
fill 94 130 296 94 135 296 minecraft:shroomlight
fill 94 130 297 94 131 298 minecraft:red_concrete
fill 94 130 299 94 131 300 minecraft:white_concrete
fill 94 130 301 94 131 302 minecraft:red_concrete
fill 94 130 303 94 131 303 minecraft:white_concrete
fill 94 130 304 94 135 304 minecraft:shroomlight
fill 94 130 305 94 131 306 minecraft:red_concrete
fill 94 130 307 94 131 308 minecraft:white_concrete
fill 94 130 309 94 131 310 minecraft:red_concrete
fill 94 130 311 94 131 311 minecraft:white_concrete
fill 94 130 312 94 135 312 minecraft:shroomlight
fill 94 130 313 94 131 314 minecraft:red_concrete
fill 94 130 315 94 131 316 minecraft:white_concrete
fill 95 130 275 95 131 275 minecraft:white_concrete
fill 95 130 317 95 131 317 minecraft:white_concrete
fill 96 130 275 97 131 275 minecraft:red_concrete
fill 96 130 317 96 131 317 minecraft:red_concrete
setblock 97 130 278 minecraft:light[level=15]
setblock 97 130 286 minecraft:light[level=15]
setblock 97 130 294 minecraft:light[level=15]
setblock 97 130 302 minecraft:light[level=15]
setblock 97 130 310 minecraft:light[level=15]
fill 97 130 317 97 135 317 minecraft:shroomlight
fill 98 130 275 99 131 275 minecraft:white_concrete
fill 98 130 317 99 131 317 minecraft:white_concrete
fill 100 130 275 100 131 275 minecraft:red_concrete
fill 100 130 317 101 131 317 minecraft:red_concrete
fill 101 130 275 101 135 275 minecraft:shroomlight
fill 102 130 275 103 131 275 minecraft:white_concrete
fill 102 130 317 103 131 317 minecraft:white_concrete
fill 104 130 275 105 131 275 minecraft:red_concrete
fill 104 130 317 104 131 317 minecraft:red_concrete
setblock 105 130 278 minecraft:light[level=15]
setblock 105 130 286 minecraft:light[level=15]
setblock 105 130 294 minecraft:light[level=15]
setblock 105 130 302 minecraft:light[level=15]
setblock 105 130 310 minecraft:light[level=15]
fill 105 130 317 105 135 317 minecraft:shroomlight
fill 106 130 275 107 131 275 minecraft:white_concrete
fill 106 130 317 107 131 317 minecraft:white_concrete
fill 108 130 275 108 131 275 minecraft:red_concrete
setblock 108 130 311 minecraft:red_terracotta
setblock 108 130 313 minecraft:red_terracotta
fill 108 130 317 109 131 317 minecraft:red_concrete
fill 109 130 275 109 135 275 minecraft:shroomlight
fill 110 130 275 111 131 275 minecraft:white_concrete
setblock 110 130 311 minecraft:red_terracotta
setblock 110 130 313 minecraft:red_terracotta
fill 110 130 317 111 131 317 minecraft:white_concrete
fill 112 130 275 113 131 275 minecraft:red_concrete
fill 112 130 317 112 131 317 minecraft:red_concrete
setblock 113 130 278 minecraft:light[level=15]
setblock 113 130 286 minecraft:light[level=15]
setblock 113 130 294 minecraft:light[level=15]
setblock 113 130 302 minecraft:light[level=15]
setblock 113 130 310 minecraft:light[level=15]
fill 113 130 317 113 135 317 minecraft:shroomlight
fill 114 130 275 115 131 275 minecraft:white_concrete
fill 114 130 317 115 131 317 minecraft:white_concrete
fill 116 130 275 116 131 275 minecraft:red_concrete
fill 116 130 317 117 131 317 minecraft:red_concrete
fill 117 130 275 117 135 275 minecraft:shroomlight
fill 118 130 275 119 131 275 minecraft:white_concrete
fill 118 130 317 119 131 317 minecraft:white_concrete
fill 120 130 275 121 131 275 minecraft:red_concrete
fill 120 130 317 120 131 317 minecraft:red_concrete
setblock 121 130 278 minecraft:light[level=15]
setblock 121 130 286 minecraft:light[level=15]
setblock 121 130 294 minecraft:light[level=15]
setblock 121 130 310 minecraft:light[level=15]
fill 121 130 317 121 135 317 minecraft:shroomlight
fill 122 130 275 123 131 275 minecraft:white_concrete
fill 122 130 317 123 131 317 minecraft:white_concrete
fill 124 130 275 124 131 275 minecraft:red_concrete
fill 124 130 317 125 131 317 minecraft:red_concrete
fill 125 130 275 125 135 275 minecraft:shroomlight
fill 126 130 275 127 131 275 minecraft:white_concrete
fill 126 130 317 127 131 317 minecraft:white_concrete
fill 128 130 275 129 131 275 minecraft:red_concrete
fill 128 130 317 128 131 317 minecraft:red_concrete
setblock 129 130 278 minecraft:light[level=15]
setblock 129 130 286 minecraft:light[level=15]
setblock 129 130 294 minecraft:light[level=15]
setblock 129 130 302 minecraft:light[level=15]
setblock 129 130 310 minecraft:light[level=15]
fill 129 130 317 129 135 317 minecraft:shroomlight
fill 130 130 275 131 131 275 minecraft:white_concrete
fill 130 130 317 131 131 317 minecraft:white_concrete
fill 132 130 275 132 131 275 minecraft:red_concrete
fill 132 130 317 133 131 317 minecraft:red_concrete
fill 133 130 275 133 135 275 minecraft:shroomlight
fill 134 130 275 135 131 275 minecraft:white_concrete
fill 134 130 317 135 131 317 minecraft:white_concrete
fill 136 130 276 136 131 276 minecraft:white_concrete
fill 136 130 277 136 131 278 minecraft:red_concrete
fill 136 130 279 136 131 279 minecraft:white_concrete
fill 136 130 280 136 135 280 minecraft:shroomlight
fill 136 130 281 136 131 282 minecraft:red_concrete
fill 136 130 283 136 131 284 minecraft:white_concrete
fill 136 130 285 136 131 286 minecraft:red_concrete
fill 136 130 287 136 131 287 minecraft:white_concrete
fill 136 130 288 136 135 288 minecraft:shroomlight
fill 136 130 289 136 131 290 minecraft:red_concrete
fill 136 130 291 136 131 292 minecraft:white_concrete
fill 136 130 293 136 131 294 minecraft:red_concrete
fill 136 130 295 136 131 295 minecraft:white_concrete
fill 136 130 296 136 135 296 minecraft:shroomlight
fill 136 130 297 136 131 298 minecraft:red_concrete
fill 136 130 299 136 131 300 minecraft:white_concrete
fill 136 130 301 136 131 302 minecraft:red_concrete
fill 136 130 303 136 131 303 minecraft:white_concrete
fill 136 130 304 136 135 304 minecraft:shroomlight
fill 136 130 305 136 131 306 minecraft:red_concrete
fill 136 130 307 136 131 308 minecraft:white_concrete
fill 136 130 309 136 131 310 minecraft:red_concrete
fill 136 130 311 136 131 311 minecraft:white_concrete
fill 136 130 312 136 135 312 minecraft:shroomlight
fill 136 130 313 136 131 314 minecraft:red_concrete
fill 136 130 315 136 131 316 minecraft:white_concrete
fill 136 130 317 136 131 317 minecraft:red_concrete
fill 94 132 275 94 133 276 minecraft:red_concrete
fill 94 132 277 94 133 278 minecraft:white_concrete
fill 94 132 279 94 133 279 minecraft:red_concrete
fill 94 132 281 94 133 282 minecraft:white_concrete
fill 94 132 283 94 133 284 minecraft:red_concrete
fill 94 132 285 94 133 286 minecraft:white_concrete
fill 94 132 287 94 133 287 minecraft:red_concrete
fill 94 132 289 94 133 290 minecraft:white_concrete
fill 94 132 291 94 133 292 minecraft:red_concrete
fill 94 132 293 94 133 294 minecraft:white_concrete
fill 94 132 295 94 133 295 minecraft:red_concrete
fill 94 132 297 94 133 298 minecraft:white_concrete
fill 94 132 299 94 133 300 minecraft:red_concrete
fill 94 132 301 94 133 302 minecraft:white_concrete
fill 94 132 303 94 133 303 minecraft:red_concrete
fill 94 132 305 94 133 306 minecraft:white_concrete
fill 94 132 307 94 133 308 minecraft:red_concrete
fill 94 132 309 94 133 310 minecraft:white_concrete
fill 94 132 311 94 133 311 minecraft:red_concrete
fill 94 132 313 94 133 314 minecraft:white_concrete
fill 94 132 315 94 133 316 minecraft:red_concrete
fill 95 132 275 95 133 275 minecraft:red_concrete
fill 95 132 317 95 133 317 minecraft:red_concrete
fill 96 132 275 97 133 275 minecraft:white_concrete
fill 96 132 317 96 133 317 minecraft:white_concrete
fill 98 132 275 99 133 275 minecraft:red_concrete
fill 98 132 317 99 133 317 minecraft:red_concrete
fill 100 132 275 100 133 275 minecraft:white_concrete
fill 100 132 317 101 133 317 minecraft:white_concrete
fill 102 132 275 103 133 275 minecraft:red_concrete
fill 102 132 317 103 133 317 minecraft:red_concrete
fill 104 132 275 105 133 275 minecraft:white_concrete
fill 104 132 317 104 133 317 minecraft:white_concrete
fill 106 132 275 107 133 275 minecraft:red_concrete
fill 106 132 317 107 133 317 minecraft:red_concrete
fill 108 132 275 108 133 275 minecraft:white_concrete
fill 108 132 317 109 133 317 minecraft:white_concrete
fill 110 132 275 111 133 275 minecraft:red_concrete
fill 110 132 317 111 133 317 minecraft:red_concrete
fill 112 132 275 113 133 275 minecraft:white_concrete
fill 112 132 317 112 133 317 minecraft:white_concrete
fill 114 132 275 115 133 275 minecraft:red_concrete
fill 114 132 317 115 133 317 minecraft:red_concrete
fill 116 132 275 116 133 275 minecraft:white_concrete
fill 116 132 317 117 133 317 minecraft:white_concrete
fill 118 132 275 119 133 275 minecraft:red_concrete
fill 118 132 317 119 133 317 minecraft:red_concrete
fill 120 132 275 121 133 275 minecraft:white_concrete
fill 120 132 317 120 133 317 minecraft:white_concrete
fill 122 132 275 123 133 275 minecraft:red_concrete
fill 122 132 317 123 133 317 minecraft:red_concrete
fill 124 132 275 124 133 275 minecraft:white_concrete
fill 124 132 317 125 133 317 minecraft:white_concrete
fill 126 132 275 127 133 275 minecraft:red_concrete
fill 126 132 317 127 133 317 minecraft:red_concrete
fill 128 132 275 129 133 275 minecraft:white_concrete
fill 128 132 317 128 133 317 minecraft:white_concrete
fill 130 132 275 131 133 275 minecraft:red_concrete
fill 130 132 317 131 133 317 minecraft:red_concrete
fill 132 132 275 132 133 275 minecraft:white_concrete
fill 132 132 317 133 133 317 minecraft:white_concrete
fill 134 132 275 135 133 275 minecraft:red_concrete
fill 134 132 317 135 133 317 minecraft:red_concrete
fill 136 132 276 136 133 276 minecraft:red_concrete
fill 136 132 277 136 133 278 minecraft:white_concrete
fill 136 132 279 136 133 279 minecraft:red_concrete
fill 136 132 281 136 133 282 minecraft:white_concrete
fill 136 132 283 136 133 284 minecraft:red_concrete
fill 136 132 285 136 133 286 minecraft:white_concrete
fill 136 132 287 136 133 287 minecraft:red_concrete
fill 136 132 289 136 133 290 minecraft:white_concrete
fill 136 132 291 136 133 292 minecraft:red_concrete
fill 136 132 293 136 133 294 minecraft:white_concrete
fill 136 132 295 136 133 295 minecraft:red_concrete
fill 136 132 297 136 133 298 minecraft:white_concrete
fill 136 132 299 136 133 300 minecraft:red_concrete
fill 136 132 301 136 133 302 minecraft:white_concrete
fill 136 132 303 136 133 303 minecraft:red_concrete
fill 136 132 305 136 133 306 minecraft:white_concrete
fill 136 132 307 136 133 308 minecraft:red_concrete
fill 136 132 309 136 133 310 minecraft:white_concrete
fill 136 132 311 136 133 311 minecraft:red_concrete
fill 136 132 313 136 133 314 minecraft:white_concrete
fill 136 132 315 136 133 316 minecraft:red_concrete
fill 136 132 317 136 133 317 minecraft:white_concrete
fill 112 133 313 113 134 314 minecraft:green_concrete
fill 113 133 312 113 134 312 minecraft:green_concrete
fill 94 134 275 94 135 276 minecraft:white_concrete
fill 94 134 277 94 135 278 minecraft:red_concrete
fill 94 134 279 94 135 279 minecraft:white_concrete
fill 94 134 281 94 135 282 minecraft:red_concrete
fill 94 134 283 94 135 284 minecraft:white_concrete
fill 94 134 285 94 135 286 minecraft:red_concrete
fill 94 134 287 94 135 287 minecraft:white_concrete
fill 94 134 289 94 135 290 minecraft:red_concrete
fill 94 134 291 94 135 292 minecraft:white_concrete
fill 94 134 293 94 135 294 minecraft:red_concrete
fill 94 134 295 94 135 295 minecraft:white_concrete
fill 94 134 297 94 135 298 minecraft:red_concrete
fill 94 134 299 94 135 300 minecraft:white_concrete
fill 94 134 301 94 135 302 minecraft:red_concrete
fill 94 134 303 94 135 303 minecraft:white_concrete
fill 94 134 305 94 135 306 minecraft:red_concrete
fill 94 134 307 94 135 308 minecraft:white_concrete
fill 94 134 309 94 135 310 minecraft:red_concrete
fill 94 134 311 94 135 311 minecraft:white_concrete
fill 94 134 313 94 135 314 minecraft:red_concrete
fill 94 134 315 94 135 316 minecraft:white_concrete
fill 95 134 275 95 135 275 minecraft:white_concrete
fill 95 134 317 95 135 317 minecraft:white_concrete
fill 96 134 275 97 135 275 minecraft:red_concrete
fill 96 134 317 96 135 317 minecraft:red_concrete
setblock 97 134 278 minecraft:light[level=12]
setblock 97 134 285 minecraft:light[level=12]
setblock 97 134 292 minecraft:light[level=12]
setblock 97 134 299 minecraft:light[level=12]
setblock 97 134 306 minecraft:light[level=12]
setblock 97 134 313 minecraft:light[level=12]
fill 98 134 275 99 135 275 minecraft:white_concrete
fill 98 134 317 99 135 317 minecraft:white_concrete
fill 100 134 275 100 135 275 minecraft:red_concrete
fill 100 134 317 101 135 317 minecraft:red_concrete
fill 102 134 275 103 135 275 minecraft:white_concrete
fill 102 134 317 103 135 317 minecraft:white_concrete
fill 104 134 275 105 135 275 minecraft:red_concrete
setblock 104 134 278 minecraft:light[level=12]
setblock 104 134 285 minecraft:light[level=12]
setblock 104 134 292 minecraft:light[level=12]
setblock 104 134 299 minecraft:light[level=12]
setblock 104 134 306 minecraft:light[level=12]
setblock 104 134 313 minecraft:light[level=12]
fill 104 134 317 104 135 317 minecraft:red_concrete
fill 106 134 275 107 135 275 minecraft:white_concrete
fill 106 134 317 107 135 317 minecraft:white_concrete
fill 108 134 275 108 135 275 minecraft:red_concrete
fill 108 134 317 109 135 317 minecraft:red_concrete
fill 110 134 275 111 135 275 minecraft:white_concrete
fill 110 134 317 111 135 317 minecraft:white_concrete
setblock 111 134 278 minecraft:light[level=12]
setblock 111 134 285 minecraft:light[level=12]
setblock 111 134 292 minecraft:light[level=12]
setblock 111 134 299 minecraft:light[level=12]
setblock 111 134 306 minecraft:light[level=12]
setblock 111 134 313 minecraft:light[level=12]
fill 112 134 275 113 135 275 minecraft:red_concrete
fill 112 134 317 112 135 317 minecraft:red_concrete
fill 114 134 275 115 135 275 minecraft:white_concrete
fill 114 134 317 115 135 317 minecraft:white_concrete
fill 116 134 275 116 135 275 minecraft:red_concrete
fill 116 134 317 117 135 317 minecraft:red_concrete
fill 118 134 275 119 135 275 minecraft:white_concrete
setblock 118 134 278 minecraft:light[level=12]
setblock 118 134 285 minecraft:light[level=12]
setblock 118 134 292 minecraft:light[level=12]
setblock 118 134 299 minecraft:light[level=12]
setblock 118 134 306 minecraft:light[level=12]
setblock 118 134 313 minecraft:light[level=12]
fill 118 134 317 119 135 317 minecraft:white_concrete
fill 120 134 275 121 135 275 minecraft:red_concrete
fill 120 134 317 120 135 317 minecraft:red_concrete
fill 122 134 275 123 135 275 minecraft:white_concrete
fill 122 134 317 123 135 317 minecraft:white_concrete
fill 124 134 275 124 135 275 minecraft:red_concrete
fill 124 134 317 125 135 317 minecraft:red_concrete
setblock 125 134 278 minecraft:light[level=12]
setblock 125 134 285 minecraft:light[level=12]
setblock 125 134 292 minecraft:light[level=12]
setblock 125 134 299 minecraft:light[level=12]
setblock 125 134 306 minecraft:light[level=12]
setblock 125 134 313 minecraft:light[level=12]
fill 126 134 275 127 135 275 minecraft:white_concrete
fill 126 134 317 127 135 317 minecraft:white_concrete
fill 128 134 275 129 135 275 minecraft:red_concrete
fill 128 134 317 128 135 317 minecraft:red_concrete
fill 130 134 275 131 135 275 minecraft:white_concrete
fill 130 134 311 130 134 314 minecraft:brown_terracotta
fill 130 134 317 131 135 317 minecraft:white_concrete
fill 131 134 310 133 134 310 minecraft:brown_terracotta
setblock 131 134 314 minecraft:brown_terracotta
fill 132 134 275 132 135 275 minecraft:red_concrete
setblock 132 134 285 minecraft:light[level=12]
setblock 132 134 292 minecraft:light[level=12]
setblock 132 134 299 minecraft:light[level=12]
setblock 132 134 306 minecraft:light[level=12]
fill 132 134 317 133 135 317 minecraft:red_concrete
setblock 133 134 314 minecraft:brown_terracotta
fill 134 134 275 135 135 275 minecraft:white_concrete
fill 134 134 311 134 134 313 minecraft:brown_terracotta
fill 134 134 317 135 135 317 minecraft:white_concrete
fill 136 134 276 136 135 276 minecraft:white_concrete
fill 136 134 277 136 135 278 minecraft:red_concrete
fill 136 134 279 136 135 279 minecraft:white_concrete
fill 136 134 281 136 135 282 minecraft:red_concrete
fill 136 134 283 136 135 284 minecraft:white_concrete
fill 136 134 285 136 135 286 minecraft:red_concrete
fill 136 134 287 136 135 287 minecraft:white_concrete
fill 136 134 289 136 135 290 minecraft:red_concrete
fill 136 134 291 136 135 292 minecraft:white_concrete
fill 136 134 293 136 135 294 minecraft:red_concrete
fill 136 134 295 136 135 295 minecraft:white_concrete
fill 136 134 297 136 135 298 minecraft:red_concrete
fill 136 134 299 136 135 300 minecraft:white_concrete
fill 136 134 301 136 135 302 minecraft:red_concrete
fill 136 134 303 136 135 303 minecraft:white_concrete
fill 136 134 305 136 135 306 minecraft:red_concrete
fill 136 134 307 136 135 308 minecraft:white_concrete
fill 136 134 309 136 135 310 minecraft:red_concrete
fill 136 134 311 136 135 311 minecraft:white_concrete
fill 136 134 313 136 135 314 minecraft:red_concrete
fill 136 134 315 136 135 316 minecraft:white_concrete
fill 136 134 317 136 135 317 minecraft:red_concrete
setblock 108 135 311 minecraft:red_terracotta
setblock 108 135 313 minecraft:red_terracotta
setblock 110 135 311 minecraft:red_terracotta
setblock 110 135 313 minecraft:red_terracotta
fill 94 136 275 94 137 276 minecraft:red_concrete
fill 94 136 277 94 137 278 minecraft:white_concrete
fill 94 136 279 94 137 280 minecraft:red_concrete
fill 94 136 281 94 137 282 minecraft:white_concrete
fill 94 136 283 94 137 284 minecraft:red_concrete
fill 94 136 285 94 137 286 minecraft:white_concrete
fill 94 136 287 94 137 288 minecraft:red_concrete
fill 94 136 289 94 137 290 minecraft:white_concrete
fill 94 136 291 94 137 292 minecraft:red_concrete
fill 94 136 293 94 137 294 minecraft:white_concrete
fill 94 136 295 94 137 296 minecraft:red_concrete
fill 94 136 297 94 137 298 minecraft:white_concrete
fill 94 136 299 94 137 300 minecraft:red_concrete
fill 94 136 301 94 137 302 minecraft:white_concrete
fill 94 136 303 94 137 304 minecraft:red_concrete
fill 94 136 305 94 137 306 minecraft:white_concrete
fill 94 136 307 94 137 308 minecraft:red_concrete
fill 94 136 309 94 137 310 minecraft:white_concrete
fill 94 136 311 94 137 312 minecraft:red_concrete
fill 94 136 313 94 137 314 minecraft:white_concrete
fill 94 136 315 94 137 316 minecraft:red_concrete
fill 95 136 275 95 137 275 minecraft:red_concrete
fill 95 136 317 95 137 317 minecraft:red_concrete
fill 96 136 275 97 137 275 minecraft:white_concrete
fill 96 136 317 97 137 317 minecraft:white_concrete
fill 98 136 275 99 137 275 minecraft:red_concrete
fill 98 136 317 99 137 317 minecraft:red_concrete
fill 100 136 275 101 137 275 minecraft:white_concrete
fill 100 136 317 101 137 317 minecraft:white_concrete
fill 102 136 275 103 137 275 minecraft:red_concrete
fill 102 136 317 103 137 317 minecraft:red_concrete
fill 104 136 275 105 137 275 minecraft:white_concrete
fill 104 136 317 105 137 317 minecraft:white_concrete
fill 106 136 275 107 137 275 minecraft:red_concrete
fill 106 136 317 107 137 317 minecraft:red_concrete
fill 108 136 275 109 137 275 minecraft:white_concrete
fill 108 136 317 109 137 317 minecraft:white_concrete
fill 110 136 275 111 137 275 minecraft:red_concrete
fill 110 136 317 111 137 317 minecraft:red_concrete
fill 112 136 275 113 137 275 minecraft:white_concrete
fill 112 136 317 113 137 317 minecraft:white_concrete
fill 114 136 275 115 137 275 minecraft:red_concrete
fill 114 136 317 115 137 317 minecraft:red_concrete
fill 116 136 275 117 137 275 minecraft:white_concrete
fill 116 136 317 117 137 317 minecraft:white_concrete
fill 118 136 275 119 137 275 minecraft:red_concrete
fill 118 136 317 119 137 317 minecraft:red_concrete
fill 120 136 275 121 137 275 minecraft:white_concrete
fill 120 136 317 121 137 317 minecraft:white_concrete
fill 122 136 275 123 137 275 minecraft:red_concrete
fill 122 136 317 123 137 317 minecraft:red_concrete
fill 124 136 275 125 137 275 minecraft:white_concrete
fill 124 136 317 125 137 317 minecraft:white_concrete
fill 126 136 275 127 137 275 minecraft:red_concrete
fill 126 136 317 127 137 317 minecraft:red_concrete
fill 128 136 275 129 137 275 minecraft:white_concrete
fill 128 136 317 129 137 317 minecraft:white_concrete
fill 130 136 275 131 137 275 minecraft:red_concrete
fill 130 136 278 130 136 280 minecraft:red_terracotta
fill 130 136 317 131 137 317 minecraft:red_concrete
fill 131 136 277 133 136 277 minecraft:red_terracotta
fill 131 136 281 133 136 281 minecraft:red_terracotta
fill 132 136 275 133 137 275 minecraft:white_concrete
fill 132 136 317 133 137 317 minecraft:white_concrete
fill 134 136 275 135 137 275 minecraft:red_concrete
fill 134 136 278 134 136 280 minecraft:red_terracotta
fill 134 136 317 135 137 317 minecraft:red_concrete
fill 136 136 276 136 137 276 minecraft:red_concrete
fill 136 136 277 136 137 278 minecraft:white_concrete
fill 136 136 279 136 137 280 minecraft:red_concrete
fill 136 136 281 136 137 282 minecraft:white_concrete
fill 136 136 283 136 137 284 minecraft:red_concrete
fill 136 136 285 136 137 286 minecraft:white_concrete
fill 136 136 287 136 137 288 minecraft:red_concrete
fill 136 136 289 136 137 290 minecraft:white_concrete
fill 136 136 291 136 137 292 minecraft:red_concrete
fill 136 136 293 136 137 294 minecraft:white_concrete
fill 136 136 295 136 137 296 minecraft:red_concrete
fill 136 136 297 136 137 298 minecraft:white_concrete
fill 136 136 299 136 137 300 minecraft:red_concrete
fill 136 136 301 136 137 302 minecraft:white_concrete
fill 136 136 303 136 137 304 minecraft:red_concrete
fill 136 136 305 136 137 306 minecraft:white_concrete
fill 136 136 307 136 137 308 minecraft:red_concrete
fill 136 136 309 136 137 310 minecraft:white_concrete
fill 136 136 311 136 137 312 minecraft:red_concrete
fill 136 136 313 136 137 314 minecraft:white_concrete
fill 136 136 315 136 137 316 minecraft:red_concrete
fill 136 136 317 136 137 317 minecraft:white_concrete
fill 94 138 275 94 139 276 minecraft:white_concrete
fill 94 138 277 94 139 278 minecraft:red_concrete
fill 94 138 279 94 139 280 minecraft:white_concrete
fill 94 138 281 94 139 282 minecraft:red_concrete
fill 94 138 283 94 139 284 minecraft:white_concrete
fill 94 138 285 94 139 286 minecraft:red_concrete
fill 94 138 287 94 139 288 minecraft:white_concrete
fill 94 138 289 94 139 290 minecraft:red_concrete
fill 94 138 291 94 139 292 minecraft:white_concrete
fill 94 138 293 94 139 294 minecraft:red_concrete
fill 94 138 295 94 139 296 minecraft:white_concrete
fill 94 138 297 94 139 298 minecraft:red_concrete
fill 94 138 299 94 139 300 minecraft:white_concrete
fill 94 138 301 94 139 302 minecraft:red_concrete
fill 94 138 303 94 139 304 minecraft:white_concrete
fill 94 138 305 94 139 306 minecraft:red_concrete
fill 94 138 307 94 139 308 minecraft:white_concrete
fill 94 138 309 94 139 310 minecraft:red_concrete
fill 94 138 311 94 139 312 minecraft:white_concrete
fill 94 138 313 94 139 314 minecraft:red_concrete
fill 94 138 315 94 139 316 minecraft:white_concrete
fill 95 138 275 95 139 275 minecraft:white_concrete
fill 95 138 317 95 139 317 minecraft:white_concrete
fill 96 138 275 97 139 275 minecraft:red_concrete
fill 96 138 317 97 139 317 minecraft:red_concrete
setblock 97 138 278 minecraft:light[level=15]
setblock 97 138 286 minecraft:light[level=15]
setblock 97 138 294 minecraft:light[level=15]
setblock 97 138 302 minecraft:light[level=15]
setblock 97 138 310 minecraft:light[level=15]
fill 98 138 275 99 139 275 minecraft:white_concrete
fill 98 138 317 99 139 317 minecraft:white_concrete
fill 100 138 275 101 139 275 minecraft:red_concrete
fill 100 138 317 101 139 317 minecraft:red_concrete
fill 102 138 275 103 139 275 minecraft:white_concrete
fill 102 138 317 103 139 317 minecraft:white_concrete
fill 104 138 275 105 139 275 minecraft:red_concrete
fill 104 138 317 105 139 317 minecraft:red_concrete
setblock 105 138 278 minecraft:light[level=15]
setblock 105 138 286 minecraft:light[level=15]
setblock 105 138 294 minecraft:light[level=15]
setblock 105 138 302 minecraft:light[level=15]
setblock 105 138 310 minecraft:light[level=15]
fill 106 138 275 107 139 275 minecraft:white_concrete
fill 106 138 317 107 139 317 minecraft:white_concrete
fill 108 138 275 109 139 275 minecraft:red_concrete
fill 108 138 317 109 139 317 minecraft:red_concrete
fill 110 138 275 111 139 275 minecraft:white_concrete
fill 110 138 317 111 139 317 minecraft:white_concrete
fill 112 138 275 113 139 275 minecraft:red_concrete
fill 112 138 317 113 139 317 minecraft:red_concrete
setblock 113 138 278 minecraft:light[level=15]
setblock 113 138 286 minecraft:light[level=15]
setblock 113 138 294 minecraft:light[level=15]
setblock 113 138 302 minecraft:light[level=15]
setblock 113 138 310 minecraft:light[level=15]
fill 114 138 275 115 139 275 minecraft:white_concrete
fill 114 138 317 115 139 317 minecraft:white_concrete
fill 116 138 275 117 139 275 minecraft:red_concrete
fill 116 138 317 117 139 317 minecraft:red_concrete
fill 118 138 275 119 139 275 minecraft:white_concrete
fill 118 138 317 119 139 317 minecraft:white_concrete
fill 120 138 275 121 139 275 minecraft:red_concrete
fill 120 138 317 121 139 317 minecraft:red_concrete
setblock 121 138 278 minecraft:light[level=15]
setblock 121 138 286 minecraft:light[level=15]
setblock 121 138 294 minecraft:light[level=15]
setblock 121 138 310 minecraft:light[level=15]
fill 122 138 275 123 139 275 minecraft:white_concrete
fill 122 138 317 123 139 317 minecraft:white_concrete
fill 124 138 275 125 139 275 minecraft:red_concrete
fill 124 138 317 125 139 317 minecraft:red_concrete
fill 126 138 275 127 139 275 minecraft:white_concrete
fill 126 138 317 127 139 317 minecraft:white_concrete
fill 128 138 275 129 139 275 minecraft:red_concrete
fill 128 138 317 129 139 317 minecraft:red_concrete
setblock 129 138 278 minecraft:light[level=15]
setblock 129 138 286 minecraft:light[level=15]
setblock 129 138 294 minecraft:light[level=15]
setblock 129 138 302 minecraft:light[level=15]
setblock 129 138 310 minecraft:light[level=15]
fill 130 138 275 131 139 275 minecraft:white_concrete
fill 130 138 317 131 139 317 minecraft:white_concrete
fill 132 138 275 133 139 275 minecraft:red_concrete
fill 132 138 317 133 139 317 minecraft:red_concrete
fill 134 138 275 135 139 275 minecraft:white_concrete
fill 134 138 317 135 139 317 minecraft:white_concrete
fill 136 138 276 136 139 276 minecraft:white_concrete
fill 136 138 277 136 139 278 minecraft:red_concrete
fill 136 138 279 136 139 280 minecraft:white_concrete
fill 136 138 281 136 139 282 minecraft:red_concrete
fill 136 138 283 136 139 284 minecraft:white_concrete
fill 136 138 285 136 139 286 minecraft:red_concrete
fill 136 138 287 136 139 288 minecraft:white_concrete
fill 136 138 289 136 139 290 minecraft:red_concrete
fill 136 138 291 136 139 292 minecraft:white_concrete
fill 136 138 293 136 139 294 minecraft:red_concrete
fill 136 138 295 136 139 296 minecraft:white_concrete
fill 136 138 297 136 139 298 minecraft:red_concrete
fill 136 138 299 136 139 300 minecraft:white_concrete
fill 136 138 301 136 139 302 minecraft:red_concrete
fill 136 138 303 136 139 304 minecraft:white_concrete
fill 136 138 305 136 139 306 minecraft:red_concrete
fill 136 138 307 136 139 308 minecraft:white_concrete
fill 136 138 309 136 139 310 minecraft:red_concrete
fill 136 138 311 136 139 312 minecraft:white_concrete
fill 136 138 313 136 139 314 minecraft:red_concrete
fill 136 138 315 136 139 316 minecraft:white_concrete
fill 136 138 317 136 139 317 minecraft:red_concrete
fill 103 139 276 103 141 276 minecraft:red_terracotta
fill 103 139 315 105 140 316 minecraft:red_terracotta
fill 94 140 275 94 141 276 minecraft:red_concrete
fill 94 140 277 94 141 278 minecraft:white_concrete
fill 94 140 279 94 141 280 minecraft:red_concrete
fill 94 140 281 94 141 282 minecraft:white_concrete
fill 94 140 283 94 141 284 minecraft:red_concrete
fill 94 140 285 94 141 286 minecraft:white_concrete
fill 94 140 287 94 141 288 minecraft:red_concrete
fill 94 140 289 94 141 290 minecraft:white_concrete
fill 94 140 291 94 141 292 minecraft:red_concrete
fill 94 140 293 94 141 294 minecraft:white_concrete
fill 94 140 295 94 141 296 minecraft:red_concrete
fill 94 140 297 94 141 298 minecraft:white_concrete
fill 94 140 299 94 141 300 minecraft:red_concrete
fill 94 140 301 94 141 302 minecraft:white_concrete
fill 94 140 303 94 141 304 minecraft:red_concrete
fill 94 140 305 94 141 306 minecraft:white_concrete
fill 94 140 307 94 141 308 minecraft:red_concrete
fill 94 140 309 94 141 310 minecraft:white_concrete
fill 94 140 311 94 141 312 minecraft:red_concrete
fill 94 140 313 94 141 314 minecraft:white_concrete
fill 94 140 315 94 141 316 minecraft:red_concrete
fill 95 140 275 95 141 275 minecraft:red_concrete
fill 95 140 276 95 141 281 minecraft:red_terracotta
fill 95 140 284 96 140 289 minecraft:red_terracotta
fill 95 140 292 96 140 297 minecraft:red_terracotta
fill 95 140 300 96 140 305 minecraft:red_terracotta
fill 95 140 308 96 140 313 minecraft:red_terracotta
fill 95 140 316 100 141 316 minecraft:red_terracotta
fill 95 140 317 95 141 317 minecraft:red_concrete
fill 96 140 275 97 141 275 minecraft:white_concrete
fill 96 140 277 96 140 283 minecraft:red_terracotta
fill 96 140 290 96 140 291 minecraft:red_terracotta
fill 96 140 298 96 140 299 minecraft:red_terracotta
fill 96 140 306 96 140 307 minecraft:red_terracotta
fill 96 140 314 96 140 315 minecraft:red_terracotta
fill 96 140 317 97 141 317 minecraft:white_concrete
fill 97 140 277 134 140 277 minecraft:red_terracotta
setblock 97 140 278 minecraft:light[level=12]
setblock 97 140 285 minecraft:light[level=12]
setblock 97 140 292 minecraft:light[level=12]
setblock 97 140 299 minecraft:light[level=12]
setblock 97 140 306 minecraft:light[level=12]
setblock 97 140 313 minecraft:light[level=12]
fill 97 140 315 102 140 315 minecraft:red_terracotta
fill 98 140 275 99 141 275 minecraft:red_concrete
fill 98 140 276 102 141 276 minecraft:red_terracotta
fill 98 140 317 99 141 317 minecraft:red_concrete
fill 100 140 275 101 141 275 minecraft:white_concrete
fill 100 140 317 101 141 317 minecraft:white_concrete
fill 101 140 300 102 141 301 minecraft:green_concrete
fill 102 140 275 103 141 275 minecraft:red_concrete
fill 102 140 317 103 141 317 minecraft:red_concrete
fill 103 140 314 105 141 314 minecraft:red_terracotta
fill 104 140 275 105 141 275 minecraft:white_concrete
fill 104 140 278 104 143 278 minecraft:red_terracotta
setblock 104 140 285 minecraft:light[level=12]
setblock 104 140 292 minecraft:light[level=12]
setblock 104 140 299 minecraft:light[level=12]
setblock 104 140 306 minecraft:light[level=12]
fill 104 140 313 104 143 313 minecraft:red_terracotta
fill 104 140 317 105 141 317 minecraft:white_concrete
fill 106 140 275 107 141 275 minecraft:red_concrete
fill 106 140 276 111 141 276 minecraft:red_terracotta
fill 106 140 315 108 140 316 minecraft:red_terracotta
fill 106 140 317 107 141 317 minecraft:red_concrete
fill 108 140 275 109 141 275 minecraft:white_concrete
setblock 108 140 311 minecraft:red_terracotta
setblock 108 140 313 minecraft:red_terracotta
fill 108 140 317 109 141 317 minecraft:white_concrete
fill 109 140 315 135 140 315 minecraft:red_terracotta
fill 110 140 275 111 141 275 minecraft:red_concrete
setblock 110 140 311 minecraft:red_terracotta
setblock 110 140 313 minecraft:red_terracotta
fill 110 140 317 111 141 317 minecraft:red_concrete
setblock 111 140 278 minecraft:light[level=12]
setblock 111 140 285 minecraft:light[level=12]
setblock 111 140 292 minecraft:light[level=12]
setblock 111 140 299 minecraft:light[level=12]
setblock 111 140 306 minecraft:light[level=12]
setblock 111 140 313 minecraft:light[level=12]
fill 111 140 316 116 141 316 minecraft:red_terracotta
fill 112 140 275 113 141 275 minecraft:white_concrete
fill 112 140 317 113 141 317 minecraft:white_concrete
fill 114 140 275 115 141 275 minecraft:red_concrete
fill 114 140 276 119 141 276 minecraft:red_terracotta
fill 114 140 317 115 141 317 minecraft:red_concrete
fill 116 140 275 117 141 275 minecraft:white_concrete
fill 116 140 317 117 141 317 minecraft:white_concrete
fill 118 140 275 119 141 275 minecraft:red_concrete
setblock 118 140 278 minecraft:light[level=12]
setblock 118 140 285 minecraft:light[level=12]
setblock 118 140 292 minecraft:light[level=12]
setblock 118 140 299 minecraft:light[level=12]
setblock 118 140 306 minecraft:light[level=12]
setblock 118 140 313 minecraft:light[level=12]
fill 118 140 317 119 141 317 minecraft:red_concrete
fill 119 140 316 124 141 316 minecraft:red_terracotta
fill 120 140 275 121 141 275 minecraft:white_concrete
fill 120 140 317 121 141 317 minecraft:white_concrete
fill 122 140 275 123 141 275 minecraft:red_concrete
fill 122 140 276 127 141 276 minecraft:red_terracotta
fill 122 140 317 123 141 317 minecraft:red_concrete
fill 124 140 275 125 141 275 minecraft:white_concrete
fill 124 140 317 125 141 317 minecraft:white_concrete
setblock 125 140 278 minecraft:light[level=12]
setblock 125 140 285 minecraft:light[level=12]
setblock 125 140 292 minecraft:light[level=12]
setblock 125 140 299 minecraft:light[level=12]
setblock 125 140 306 minecraft:light[level=12]
setblock 125 140 313 minecraft:light[level=12]
fill 126 140 275 127 141 275 minecraft:red_concrete
fill 126 140 317 127 141 317 minecraft:red_concrete
fill 127 140 316 132 141 316 minecraft:red_terracotta
fill 128 140 275 129 141 275 minecraft:white_concrete
fill 128 140 317 129 141 317 minecraft:white_concrete
fill 130 140 275 131 141 275 minecraft:red_concrete
fill 130 140 276 135 141 276 minecraft:red_terracotta
fill 130 140 317 131 141 317 minecraft:red_concrete
fill 132 140 275 133 141 275 minecraft:white_concrete
setblock 132 140 285 minecraft:light[level=12]
setblock 132 140 292 minecraft:light[level=12]
setblock 132 140 299 minecraft:light[level=12]
setblock 132 140 306 minecraft:light[level=12]
fill 132 140 317 133 141 317 minecraft:white_concrete
fill 134 140 275 135 141 275 minecraft:red_concrete
fill 134 140 278 134 140 314 minecraft:red_terracotta
fill 134 140 317 135 141 317 minecraft:red_concrete
fill 135 140 279 135 141 284 minecraft:red_terracotta
fill 135 140 287 135 141 292 minecraft:red_terracotta
fill 135 140 295 135 141 300 minecraft:red_terracotta
fill 135 140 303 135 141 308 minecraft:red_terracotta
fill 135 140 311 135 141 314 minecraft:red_terracotta
fill 135 140 316 135 141 316 minecraft:red_terracotta
fill 136 140 276 136 141 276 minecraft:red_concrete
fill 136 140 277 136 141 278 minecraft:white_concrete
fill 136 140 279 136 141 280 minecraft:red_concrete
fill 136 140 281 136 141 282 minecraft:white_concrete
fill 136 140 283 136 141 284 minecraft:red_concrete
fill 136 140 285 136 141 286 minecraft:white_concrete
fill 136 140 287 136 141 288 minecraft:red_concrete
fill 136 140 289 136 141 290 minecraft:white_concrete
fill 136 140 291 136 141 292 minecraft:red_concrete
fill 136 140 293 136 141 294 minecraft:white_concrete
fill 136 140 295 136 141 296 minecraft:red_concrete
fill 136 140 297 136 141 298 minecraft:white_concrete
fill 136 140 299 136 141 300 minecraft:red_concrete
fill 136 140 301 136 141 302 minecraft:white_concrete
fill 136 140 303 136 141 304 minecraft:red_concrete
fill 136 140 305 136 141 306 minecraft:white_concrete
fill 136 140 307 136 141 308 minecraft:red_concrete
fill 136 140 309 136 141 310 minecraft:white_concrete
fill 136 140 311 136 141 312 minecraft:red_concrete
fill 136 140 313 136 141 314 minecraft:white_concrete
fill 136 140 315 136 141 316 minecraft:red_concrete
fill 136 140 317 136 141 317 minecraft:white_concrete
fill 95 141 284 95 141 289 minecraft:red_terracotta
fill 95 141 292 95 141 297 minecraft:red_terracotta
fill 95 141 300 95 141 305 minecraft:red_terracotta
fill 95 141 308 95 141 313 minecraft:red_terracotta
fill 103 141 277 103 141 278 minecraft:red_terracotta
fill 103 141 313 103 142 313 minecraft:red_terracotta
fill 103 141 316 108 141 316 minecraft:red_terracotta
fill 104 141 277 105 141 277 minecraft:red_terracotta
fill 104 141 279 104 143 279 minecraft:red_terracotta
fill 104 141 312 104 143 312 minecraft:red_terracotta
setblock 104 141 315 minecraft:red_terracotta
fill 105 141 278 105 142 278 minecraft:red_terracotta
fill 105 141 313 105 142 313 minecraft:red_terracotta
setblock 135 141 315 minecraft:red_terracotta
fill 94 142 275 94 143 276 minecraft:white_concrete
fill 94 142 277 94 143 278 minecraft:red_concrete
fill 94 142 279 94 143 280 minecraft:white_concrete
fill 94 142 281 94 143 282 minecraft:red_concrete
fill 94 142 283 94 143 284 minecraft:white_concrete
fill 94 142 285 94 143 286 minecraft:red_concrete
fill 94 142 287 94 143 288 minecraft:white_concrete
fill 94 142 289 94 143 290 minecraft:red_concrete
fill 94 142 291 94 143 292 minecraft:white_concrete
fill 94 142 293 94 143 294 minecraft:red_concrete
fill 94 142 295 94 143 296 minecraft:white_concrete
fill 94 142 297 94 143 298 minecraft:red_concrete
fill 94 142 299 94 143 300 minecraft:white_concrete
fill 94 142 301 94 143 302 minecraft:red_concrete
fill 94 142 303 94 143 304 minecraft:white_concrete
fill 94 142 305 94 143 306 minecraft:red_concrete
fill 94 142 307 94 143 308 minecraft:white_concrete
fill 94 142 309 94 143 310 minecraft:red_concrete
fill 94 142 311 94 143 312 minecraft:white_concrete
fill 94 142 313 94 143 314 minecraft:red_concrete
fill 94 142 315 94 143 316 minecraft:white_concrete
fill 95 142 275 95 143 275 minecraft:white_concrete
fill 95 142 317 95 143 317 minecraft:white_concrete
fill 96 142 275 97 143 275 minecraft:red_concrete
fill 96 142 317 97 143 317 minecraft:red_concrete
fill 98 142 275 99 143 275 minecraft:white_concrete
fill 98 142 317 99 143 317 minecraft:white_concrete
fill 100 142 275 101 143 275 minecraft:red_concrete
fill 100 142 303 101 143 303 minecraft:brown_terracotta
fill 100 142 317 101 143 317 minecraft:red_concrete
fill 102 142 275 103 143 275 minecraft:white_concrete
fill 102 142 317 103 143 317 minecraft:white_concrete
fill 103 142 278 103 142 280 minecraft:red_terracotta
fill 103 142 311 103 143 312 minecraft:red_terracotta
fill 104 142 275 105 143 275 minecraft:red_concrete
setblock 104 142 277 minecraft:red_terracotta
fill 104 142 280 105 143 280 minecraft:red_terracotta
fill 104 142 311 105 143 311 minecraft:red_terracotta
setblock 104 142 314 minecraft:red_terracotta
setblock 104 142 315 minecraft:yellow_concrete
fill 104 142 317 105 143 317 minecraft:red_concrete
fill 105 142 279 105 143 279 minecraft:red_terracotta
fill 105 142 312 105 143 312 minecraft:red_terracotta
fill 106 142 275 107 143 275 minecraft:white_concrete
fill 106 142 317 107 143 317 minecraft:white_concrete
fill 108 142 275 109 143 275 minecraft:red_concrete
fill 108 142 317 109 143 317 minecraft:red_concrete
fill 110 142 275 111 143 275 minecraft:white_concrete
fill 110 142 317 111 143 317 minecraft:white_concrete
fill 112 142 275 113 143 275 minecraft:red_concrete
fill 112 142 317 113 143 317 minecraft:red_concrete
fill 114 142 275 115 143 275 minecraft:white_concrete
fill 114 142 317 115 143 317 minecraft:white_concrete
fill 116 142 275 117 143 275 minecraft:red_concrete
fill 116 142 317 117 143 317 minecraft:red_concrete
fill 118 142 275 119 143 275 minecraft:white_concrete
fill 118 142 317 119 143 317 minecraft:white_concrete
fill 120 142 275 121 143 275 minecraft:red_concrete
fill 120 142 317 121 143 317 minecraft:red_concrete
fill 121 142 287 121 143 287 minecraft:red_concrete
fill 122 142 275 123 143 275 minecraft:white_concrete
fill 122 142 317 123 143 317 minecraft:white_concrete
fill 124 142 275 125 143 275 minecraft:red_concrete
fill 124 142 317 125 143 317 minecraft:red_concrete
fill 126 142 275 127 143 275 minecraft:white_concrete
fill 126 142 317 127 143 317 minecraft:white_concrete
fill 128 142 275 129 143 275 minecraft:red_concrete
fill 128 142 317 129 143 317 minecraft:red_concrete
fill 130 142 275 131 143 275 minecraft:white_concrete
fill 130 142 311 130 142 314 minecraft:brown_terracotta
fill 130 142 317 131 143 317 minecraft:white_concrete
fill 131 142 310 133 142 310 minecraft:brown_terracotta
setblock 131 142 314 minecraft:brown_terracotta
fill 132 142 275 133 143 275 minecraft:red_concrete
fill 132 142 317 133 143 317 minecraft:red_concrete
setblock 133 142 314 minecraft:brown_terracotta
fill 134 142 275 135 143 275 minecraft:white_concrete
fill 134 142 311 134 142 313 minecraft:brown_terracotta
fill 134 142 317 135 143 317 minecraft:white_concrete
fill 136 142 276 136 143 276 minecraft:white_concrete
fill 136 142 277 136 143 278 minecraft:red_concrete
fill 136 142 279 136 143 280 minecraft:white_concrete
fill 136 142 281 136 143 282 minecraft:red_concrete
fill 136 142 283 136 143 284 minecraft:white_concrete
fill 136 142 285 136 143 286 minecraft:red_concrete
fill 136 142 287 136 143 288 minecraft:white_concrete
fill 136 142 289 136 143 290 minecraft:red_concrete
fill 136 142 291 136 143 292 minecraft:white_concrete
fill 136 142 293 136 143 294 minecraft:red_concrete
fill 136 142 295 136 143 296 minecraft:white_concrete
fill 136 142 297 136 143 298 minecraft:red_concrete
fill 136 142 299 136 143 300 minecraft:white_concrete
fill 136 142 301 136 143 302 minecraft:red_concrete
fill 136 142 303 136 143 304 minecraft:white_concrete
fill 136 142 305 136 143 306 minecraft:red_concrete
fill 136 142 307 136 143 308 minecraft:white_concrete
fill 136 142 309 136 143 310 minecraft:red_concrete
fill 136 142 311 136 143 312 minecraft:white_concrete
fill 136 142 313 136 143 314 minecraft:red_concrete
fill 136 142 315 136 143 316 minecraft:white_concrete
fill 136 142 317 136 143 317 minecraft:red_concrete
fill 103 143 279 103 143 281 minecraft:red_terracotta
fill 103 143 310 105 144 310 minecraft:red_terracotta
setblock 104 143 277 minecraft:yellow_concrete
fill 104 143 281 104 145 282 minecraft:red_terracotta
fill 104 143 309 104 145 309 minecraft:red_terracotta
setblock 104 143 314 minecraft:yellow_concrete
fill 105 143 281 105 144 281 minecraft:red_terracotta
setblock 128 143 301 minecraft:iron_block
setblock 129 143 300 minecraft:iron_block
fill 129 143 301 131 143 301 minecraft:black_concrete
setblock 129 143 302 minecraft:iron_block
fill 130 143 278 130 143 280 minecraft:red_terracotta
setblock 130 143 299 minecraft:iron_block
setblock 130 143 300 minecraft:black_concrete
setblock 130 143 302 minecraft:black_concrete
setblock 130 143 303 minecraft:iron_block
fill 131 143 277 133 143 277 minecraft:red_terracotta
fill 131 143 281 133 143 281 minecraft:red_terracotta
setblock 131 143 300 minecraft:iron_block
setblock 131 143 302 minecraft:iron_block
setblock 132 143 301 minecraft:iron_block
fill 134 143 278 134 143 280 minecraft:red_terracotta
fill 94 144 275 94 145 276 minecraft:red_concrete
fill 94 144 277 94 145 278 minecraft:white_concrete
fill 94 144 279 94 145 279 minecraft:red_concrete
fill 94 144 280 94 149 280 minecraft:shroomlight
fill 94 144 281 94 145 282 minecraft:white_concrete
fill 94 144 283 94 145 284 minecraft:red_concrete
fill 94 144 285 94 145 286 minecraft:white_concrete
fill 94 144 287 94 145 287 minecraft:red_concrete
fill 94 144 288 94 149 288 minecraft:shroomlight
fill 94 144 289 94 145 290 minecraft:white_concrete
fill 94 144 291 94 145 292 minecraft:red_concrete
fill 94 144 293 94 145 294 minecraft:white_concrete
fill 94 144 295 94 145 295 minecraft:red_concrete
fill 94 144 296 94 149 296 minecraft:shroomlight
fill 94 144 297 94 145 298 minecraft:white_concrete
fill 94 144 299 94 145 300 minecraft:red_concrete
fill 94 144 301 94 145 302 minecraft:white_concrete
fill 94 144 303 94 145 303 minecraft:red_concrete
fill 94 144 304 94 149 304 minecraft:shroomlight
fill 94 144 305 94 145 306 minecraft:white_concrete
fill 94 144 307 94 145 308 minecraft:red_concrete
fill 94 144 309 94 145 310 minecraft:white_concrete
fill 94 144 311 94 145 311 minecraft:red_concrete
fill 94 144 312 94 149 312 minecraft:shroomlight
fill 94 144 313 94 145 314 minecraft:white_concrete
fill 94 144 315 94 145 316 minecraft:red_concrete
fill 95 144 275 95 145 275 minecraft:red_concrete
fill 95 144 317 95 145 317 minecraft:red_concrete
fill 96 144 275 97 145 275 minecraft:white_concrete
fill 96 144 317 96 145 317 minecraft:white_concrete
fill 97 144 317 97 149 317 minecraft:shroomlight
fill 98 144 275 99 145 275 minecraft:red_concrete
fill 98 144 317 99 145 317 minecraft:red_concrete
fill 100 144 275 100 145 275 minecraft:white_concrete
fill 100 144 317 101 145 317 minecraft:white_concrete
fill 101 144 275 101 149 275 minecraft:shroomlight
fill 102 144 275 103 145 275 minecraft:red_concrete
fill 102 144 317 103 145 317 minecraft:red_concrete
fill 103 144 281 103 144 282 minecraft:red_terracotta
fill 103 144 309 103 145 309 minecraft:red_terracotta
fill 104 144 275 105 145 275 minecraft:white_concrete
setblock 104 144 279 minecraft:yellow_concrete
setblock 104 144 280 minecraft:red_terracotta
fill 104 144 283 104 146 283 minecraft:red_terracotta
fill 104 144 308 104 146 308 minecraft:red_terracotta
setblock 104 144 311 minecraft:red_terracotta
setblock 104 144 312 minecraft:yellow_concrete
fill 104 144 317 104 145 317 minecraft:white_concrete
fill 105 144 282 105 145 282 minecraft:red_terracotta
fill 105 144 309 105 145 309 minecraft:red_terracotta
fill 105 144 317 105 149 317 minecraft:shroomlight
fill 106 144 275 107 145 275 minecraft:red_concrete
fill 106 144 317 107 145 317 minecraft:red_concrete
fill 108 144 275 108 145 275 minecraft:white_concrete
fill 108 144 317 109 145 317 minecraft:white_concrete
fill 109 144 275 109 149 275 minecraft:shroomlight
fill 110 144 275 111 145 275 minecraft:red_concrete
fill 110 144 317 111 145 317 minecraft:red_concrete
fill 112 144 275 113 145 275 minecraft:white_concrete
fill 112 144 317 112 145 317 minecraft:white_concrete
fill 113 144 317 113 149 317 minecraft:shroomlight
fill 114 144 275 115 145 275 minecraft:red_concrete
fill 114 144 317 115 145 317 minecraft:red_concrete
fill 116 144 275 116 145 275 minecraft:white_concrete
fill 116 144 317 117 145 317 minecraft:white_concrete
fill 117 144 275 117 149 275 minecraft:shroomlight
fill 118 144 275 119 145 275 minecraft:red_concrete
fill 118 144 317 119 145 317 minecraft:red_concrete
fill 120 144 275 121 145 275 minecraft:white_concrete
fill 120 144 317 120 145 317 minecraft:white_concrete
fill 121 144 317 121 149 317 minecraft:shroomlight
fill 122 144 275 123 145 275 minecraft:red_concrete
fill 122 144 317 123 145 317 minecraft:red_concrete
fill 124 144 275 124 145 275 minecraft:white_concrete
fill 124 144 317 125 145 317 minecraft:white_concrete
fill 125 144 275 125 149 275 minecraft:shroomlight
fill 126 144 275 127 145 275 minecraft:red_concrete
fill 126 144 317 127 145 317 minecraft:red_concrete
fill 128 144 275 129 145 275 minecraft:white_concrete
fill 128 144 317 128 145 317 minecraft:white_concrete
fill 129 144 317 129 149 317 minecraft:shroomlight
fill 130 144 275 131 145 275 minecraft:red_concrete
fill 130 144 317 131 145 317 minecraft:red_concrete
fill 132 144 275 132 145 275 minecraft:white_concrete
fill 132 144 317 133 145 317 minecraft:white_concrete
fill 133 144 275 133 149 275 minecraft:shroomlight
fill 134 144 275 135 145 275 minecraft:red_concrete
fill 134 144 317 135 145 317 minecraft:red_concrete
fill 136 144 276 136 145 276 minecraft:red_concrete
fill 136 144 277 136 145 278 minecraft:white_concrete
fill 136 144 279 136 145 279 minecraft:red_concrete
fill 136 144 280 136 149 280 minecraft:shroomlight
fill 136 144 281 136 145 282 minecraft:white_concrete
fill 136 144 283 136 145 284 minecraft:red_concrete
fill 136 144 285 136 145 286 minecraft:white_concrete
fill 136 144 287 136 145 287 minecraft:red_concrete
fill 136 144 288 136 149 288 minecraft:shroomlight
fill 136 144 289 136 145 290 minecraft:white_concrete
fill 136 144 291 136 145 292 minecraft:red_concrete
fill 136 144 293 136 145 294 minecraft:white_concrete
fill 136 144 295 136 145 295 minecraft:red_concrete
fill 136 144 296 136 149 296 minecraft:shroomlight
fill 136 144 297 136 145 298 minecraft:white_concrete
fill 136 144 299 136 145 300 minecraft:red_concrete
fill 136 144 301 136 145 302 minecraft:white_concrete
fill 136 144 303 136 145 303 minecraft:red_concrete
fill 136 144 304 136 149 304 minecraft:shroomlight
fill 136 144 305 136 145 306 minecraft:white_concrete
fill 136 144 307 136 145 308 minecraft:red_concrete
fill 136 144 309 136 145 310 minecraft:white_concrete
fill 136 144 311 136 145 311 minecraft:red_concrete
fill 136 144 312 136 149 312 minecraft:shroomlight
fill 136 144 313 136 145 314 minecraft:white_concrete
fill 136 144 315 136 145 316 minecraft:red_concrete
fill 136 144 317 136 145 317 minecraft:white_concrete
fill 103 145 282 103 145 284 minecraft:red_terracotta
fill 103 145 307 103 145 308 minecraft:red_terracotta
setblock 104 145 280 minecraft:yellow_concrete
fill 104 145 284 104 147 285 minecraft:red_terracotta
fill 104 145 306 104 147 307 minecraft:red_terracotta
setblock 104 145 310 minecraft:red_terracotta
setblock 104 145 311 minecraft:yellow_concrete
fill 105 145 283 105 145 284 minecraft:red_terracotta
fill 105 145 307 105 145 308 minecraft:red_terracotta
setblock 108 145 311 minecraft:red_terracotta
setblock 108 145 313 minecraft:red_terracotta
setblock 110 145 311 minecraft:red_terracotta
setblock 110 145 313 minecraft:red_terracotta
fill 94 146 275 94 147 276 minecraft:white_concrete
fill 94 146 277 94 147 278 minecraft:red_concrete
fill 94 146 279 94 147 279 minecraft:white_concrete
fill 94 146 281 94 147 282 minecraft:red_concrete
fill 94 146 283 94 147 284 minecraft:white_concrete
fill 94 146 285 94 147 286 minecraft:red_concrete
fill 94 146 287 94 147 287 minecraft:white_concrete
fill 94 146 289 94 147 290 minecraft:red_concrete
fill 94 146 291 94 147 292 minecraft:white_concrete
fill 94 146 293 94 147 294 minecraft:red_concrete
fill 94 146 295 94 147 295 minecraft:white_concrete
fill 94 146 297 94 147 298 minecraft:red_concrete
fill 94 146 299 94 147 300 minecraft:white_concrete
fill 94 146 301 94 147 302 minecraft:red_concrete
fill 94 146 303 94 147 303 minecraft:white_concrete
fill 94 146 305 94 147 306 minecraft:red_concrete
fill 94 146 307 94 147 308 minecraft:white_concrete
fill 94 146 309 94 147 310 minecraft:red_concrete
fill 94 146 311 94 147 311 minecraft:white_concrete
fill 94 146 313 94 147 314 minecraft:red_concrete
fill 94 146 315 94 147 316 minecraft:white_concrete
fill 95 146 275 95 147 275 minecraft:white_concrete
fill 95 146 317 95 147 317 minecraft:white_concrete
fill 96 146 275 97 147 275 minecraft:red_concrete
fill 96 146 317 96 147 317 minecraft:red_concrete
setblock 97 146 278 minecraft:light[level=15]
setblock 97 146 285 minecraft:light[level=12]
setblock 97 146 286 minecraft:light[level=15]
setblock 97 146 292 minecraft:light[level=12]
setblock 97 146 294 minecraft:light[level=15]
setblock 97 146 299 minecraft:light[level=12]
setblock 97 146 302 minecraft:light[level=15]
setblock 97 146 306 minecraft:light[level=12]
setblock 97 146 310 minecraft:light[level=15]
setblock 97 146 313 minecraft:light[level=12]
fill 98 146 275 99 147 275 minecraft:white_concrete
fill 98 146 317 99 147 317 minecraft:white_concrete
fill 100 146 275 100 147 275 minecraft:red_concrete
fill 100 146 317 101 147 317 minecraft:red_concrete
fill 102 146 275 103 147 275 minecraft:white_concrete
fill 102 146 317 103 147 317 minecraft:white_concrete
fill 103 146 284 103 146 286 minecraft:red_terracotta
fill 103 146 305 103 146 307 minecraft:red_terracotta
fill 104 146 275 105 147 275 minecraft:red_concrete
setblock 104 146 278 minecraft:light[level=12]
setblock 104 146 282 minecraft:yellow_concrete
fill 104 146 286 104 148 287 minecraft:red_terracotta
setblock 104 146 292 minecraft:light[level=12]
setblock 104 146 299 minecraft:light[level=12]
fill 104 146 304 104 148 305 minecraft:red_terracotta
setblock 104 146 309 minecraft:yellow_concrete
setblock 104 146 313 minecraft:light[level=12]
fill 104 146 317 104 147 317 minecraft:red_concrete
setblock 105 146 278 minecraft:light[level=15]
fill 105 146 284 105 146 286 minecraft:red_terracotta
setblock 105 146 294 minecraft:light[level=15]
setblock 105 146 302 minecraft:light[level=15]
fill 105 146 305 105 146 307 minecraft:red_terracotta
setblock 105 146 310 minecraft:light[level=15]
fill 106 146 275 107 147 275 minecraft:white_concrete
fill 106 146 317 107 147 317 minecraft:white_concrete
fill 108 146 275 108 147 275 minecraft:red_concrete
fill 108 146 317 109 147 317 minecraft:red_concrete
fill 110 146 275 111 147 275 minecraft:white_concrete
fill 110 146 317 111 147 317 minecraft:white_concrete
setblock 111 146 278 minecraft:light[level=12]
setblock 111 146 285 minecraft:light[level=12]
setblock 111 146 292 minecraft:light[level=12]
setblock 111 146 299 minecraft:light[level=12]
setblock 111 146 306 minecraft:light[level=12]
setblock 111 146 313 minecraft:light[level=12]
fill 112 146 275 113 147 275 minecraft:red_concrete
fill 112 146 317 112 147 317 minecraft:red_concrete
setblock 113 146 278 minecraft:light[level=15]
setblock 113 146 286 minecraft:light[level=15]
setblock 113 146 294 minecraft:light[level=15]
setblock 113 146 302 minecraft:light[level=15]
setblock 113 146 310 minecraft:light[level=15]
fill 114 146 275 115 147 275 minecraft:white_concrete
fill 114 146 317 115 147 317 minecraft:white_concrete
fill 116 146 275 116 147 275 minecraft:red_concrete
fill 116 146 317 117 147 317 minecraft:red_concrete
fill 118 146 275 119 147 275 minecraft:white_concrete
setblock 118 146 278 minecraft:light[level=12]
setblock 118 146 285 minecraft:light[level=12]
setblock 118 146 292 minecraft:light[level=12]
setblock 118 146 299 minecraft:light[level=12]
setblock 118 146 306 minecraft:light[level=12]
setblock 118 146 313 minecraft:light[level=12]
fill 118 146 317 119 147 317 minecraft:white_concrete
fill 120 146 275 121 147 275 minecraft:red_concrete
fill 120 146 317 120 147 317 minecraft:red_concrete
setblock 121 146 278 minecraft:light[level=15]
setblock 121 146 286 minecraft:light[level=15]
setblock 121 146 294 minecraft:light[level=15]
setblock 121 146 310 minecraft:light[level=15]
fill 122 146 275 123 147 275 minecraft:white_concrete
fill 122 146 317 123 147 317 minecraft:white_concrete
fill 124 146 275 124 147 275 minecraft:red_concrete
fill 124 146 317 125 147 317 minecraft:red_concrete
setblock 125 146 278 minecraft:light[level=12]
setblock 125 146 285 minecraft:light[level=12]
setblock 125 146 292 minecraft:light[level=12]
setblock 125 146 299 minecraft:light[level=12]
setblock 125 146 306 minecraft:light[level=12]
setblock 125 146 313 minecraft:light[level=12]
fill 126 146 275 127 147 275 minecraft:white_concrete
fill 126 146 317 127 147 317 minecraft:white_concrete
fill 128 146 275 129 147 275 minecraft:red_concrete
fill 128 146 317 128 147 317 minecraft:red_concrete
setblock 129 146 278 minecraft:light[level=15]
setblock 129 146 286 minecraft:light[level=15]
setblock 129 146 294 minecraft:light[level=15]
setblock 129 146 302 minecraft:light[level=15]
setblock 129 146 310 minecraft:light[level=15]
fill 130 146 275 131 147 275 minecraft:white_concrete
fill 130 146 317 131 147 317 minecraft:white_concrete
fill 132 146 275 132 147 275 minecraft:red_concrete
setblock 132 146 285 minecraft:light[level=12]
setblock 132 146 292 minecraft:light[level=12]
setblock 132 146 299 minecraft:light[level=12]
setblock 132 146 306 minecraft:light[level=12]
fill 132 146 317 133 147 317 minecraft:red_concrete
fill 134 146 275 135 147 275 minecraft:white_concrete
fill 134 146 317 135 147 317 minecraft:white_concrete
fill 136 146 276 136 147 276 minecraft:white_concrete
fill 136 146 277 136 147 278 minecraft:red_concrete
fill 136 146 279 136 147 279 minecraft:white_concrete
fill 136 146 281 136 147 282 minecraft:red_concrete
fill 136 146 283 136 147 284 minecraft:white_concrete
fill 136 146 285 136 147 286 minecraft:red_concrete
fill 136 146 287 136 147 287 minecraft:white_concrete
fill 136 146 289 136 147 290 minecraft:red_concrete
fill 136 146 291 136 147 292 minecraft:white_concrete
fill 136 146 293 136 147 294 minecraft:red_concrete
fill 136 146 295 136 147 295 minecraft:white_concrete
fill 136 146 297 136 147 298 minecraft:red_concrete
fill 136 146 299 136 147 300 minecraft:white_concrete
fill 136 146 301 136 147 302 minecraft:red_concrete
fill 136 146 303 136 147 303 minecraft:white_concrete
fill 136 146 305 136 147 306 minecraft:red_concrete
fill 136 146 307 136 147 308 minecraft:white_concrete
fill 136 146 309 136 147 310 minecraft:red_concrete
fill 136 146 311 136 147 311 minecraft:white_concrete
fill 136 146 313 136 147 314 minecraft:red_concrete
fill 136 146 315 136 147 316 minecraft:white_concrete
fill 136 146 317 136 147 317 minecraft:red_concrete
fill 103 147 285 103 147 288 minecraft:red_terracotta
fill 103 147 303 103 147 306 minecraft:red_terracotta
setblock 104 147 283 minecraft:yellow_concrete
fill 104 147 288 104 149 289 minecraft:red_terracotta
fill 104 147 302 104 149 303 minecraft:red_terracotta
setblock 104 147 308 minecraft:yellow_concrete
fill 105 147 285 105 147 288 minecraft:red_terracotta
fill 105 147 303 105 147 306 minecraft:red_terracotta
fill 119 147 301 119 147 304 minecraft:yellow_concrete
fill 120 147 300 120 147 301 minecraft:yellow_concrete
fill 120 147 304 122 147 305 minecraft:yellow_concrete
fill 121 147 300 122 147 300 minecraft:yellow_concrete
fill 122 147 301 123 148 301 minecraft:yellow_concrete
fill 123 147 302 123 147 304 minecraft:yellow_concrete
fill 94 148 275 94 149 276 minecraft:red_concrete
fill 94 148 277 94 149 278 minecraft:white_concrete
fill 94 148 279 94 149 279 minecraft:red_concrete
fill 94 148 281 94 149 282 minecraft:white_concrete
fill 94 148 283 94 149 284 minecraft:red_concrete
fill 94 148 285 94 149 286 minecraft:white_concrete
fill 94 148 287 94 149 287 minecraft:red_concrete
fill 94 148 289 94 149 290 minecraft:white_concrete
fill 94 148 291 94 149 292 minecraft:red_concrete
fill 94 148 293 94 149 294 minecraft:white_concrete
fill 94 148 295 94 149 295 minecraft:red_concrete
fill 94 148 297 94 149 298 minecraft:white_concrete
fill 94 148 299 94 149 300 minecraft:red_concrete
fill 94 148 301 94 149 302 minecraft:white_concrete
fill 94 148 303 94 149 303 minecraft:red_concrete
fill 94 148 305 94 149 306 minecraft:white_concrete
fill 94 148 307 94 149 308 minecraft:red_concrete
fill 94 148 309 94 149 310 minecraft:white_concrete
fill 94 148 311 94 149 311 minecraft:red_concrete
fill 94 148 313 94 149 314 minecraft:white_concrete
fill 94 148 315 94 149 316 minecraft:red_concrete
fill 95 148 275 95 149 275 minecraft:red_concrete
fill 95 148 317 95 149 317 minecraft:red_concrete
fill 96 148 275 97 149 275 minecraft:white_concrete
fill 96 148 317 96 149 317 minecraft:white_concrete
fill 98 148 275 99 149 275 minecraft:red_concrete
fill 98 148 317 99 149 317 minecraft:red_concrete
fill 100 148 275 100 149 275 minecraft:white_concrete
fill 100 148 317 101 149 317 minecraft:white_concrete
fill 102 148 275 103 149 275 minecraft:red_concrete
fill 102 148 317 103 149 317 minecraft:red_concrete
fill 103 148 287 103 148 290 minecraft:red_terracotta
fill 103 148 301 103 148 304 minecraft:red_terracotta
fill 104 148 275 105 149 275 minecraft:white_concrete
setblock 104 148 285 minecraft:yellow_concrete
fill 104 148 290 104 149 293 minecraft:red_terracotta
fill 104 148 298 104 149 301 minecraft:red_terracotta
setblock 104 148 306 minecraft:yellow_concrete
fill 104 148 317 104 149 317 minecraft:white_concrete
fill 105 148 287 105 148 290 minecraft:red_terracotta
fill 105 148 301 105 148 304 minecraft:red_terracotta
fill 106 148 275 107 149 275 minecraft:red_concrete
fill 106 148 317 107 149 317 minecraft:red_concrete
fill 108 148 275 108 149 275 minecraft:white_concrete
fill 108 148 317 109 149 317 minecraft:white_concrete
fill 110 148 275 111 149 275 minecraft:red_concrete
fill 110 148 317 111 149 317 minecraft:red_concrete
fill 112 148 275 113 149 275 minecraft:white_concrete
fill 112 148 317 112 149 317 minecraft:white_concrete
fill 114 148 275 115 149 275 minecraft:red_concrete
fill 114 148 317 115 149 317 minecraft:red_concrete
fill 116 148 275 116 149 275 minecraft:white_concrete
fill 116 148 317 117 149 317 minecraft:white_concrete
fill 118 148 275 119 149 275 minecraft:red_concrete
fill 118 148 317 119 149 317 minecraft:red_concrete
fill 119 148 301 119 148 303 minecraft:yellow_concrete
fill 120 148 275 121 149 275 minecraft:white_concrete
fill 120 148 301 120 149 301 minecraft:yellow_concrete
fill 120 148 304 122 149 304 minecraft:yellow_concrete
fill 120 148 317 120 149 317 minecraft:white_concrete
setblock 121 148 300 minecraft:yellow_concrete
fill 122 148 275 123 149 275 minecraft:red_concrete
fill 122 148 317 123 149 317 minecraft:red_concrete
fill 123 148 302 123 148 303 minecraft:yellow_concrete
fill 124 148 275 124 149 275 minecraft:white_concrete
fill 124 148 317 125 149 317 minecraft:white_concrete
fill 126 148 275 127 149 275 minecraft:red_concrete
fill 126 148 317 127 149 317 minecraft:red_concrete
fill 128 148 275 129 149 275 minecraft:white_concrete
fill 128 148 317 128 149 317 minecraft:white_concrete
fill 130 148 275 131 149 275 minecraft:red_concrete
fill 130 148 317 131 149 317 minecraft:red_concrete
fill 132 148 275 132 149 275 minecraft:white_concrete
fill 132 148 317 133 149 317 minecraft:white_concrete
fill 134 148 275 135 149 275 minecraft:red_concrete
fill 134 148 317 135 149 317 minecraft:red_concrete
fill 136 148 276 136 149 276 minecraft:red_concrete
fill 136 148 277 136 149 278 minecraft:white_concrete
fill 136 148 279 136 149 279 minecraft:red_concrete
fill 136 148 281 136 149 282 minecraft:white_concrete
fill 136 148 283 136 149 284 minecraft:red_concrete
fill 136 148 285 136 149 286 minecraft:white_concrete
fill 136 148 287 136 149 287 minecraft:red_concrete
fill 136 148 289 136 149 290 minecraft:white_concrete
fill 136 148 291 136 149 292 minecraft:red_concrete
fill 136 148 293 136 149 294 minecraft:white_concrete
fill 136 148 295 136 149 295 minecraft:red_concrete
fill 136 148 297 136 149 298 minecraft:white_concrete
fill 136 148 299 136 149 300 minecraft:red_concrete
fill 136 148 301 136 149 302 minecraft:white_concrete
fill 136 148 303 136 149 303 minecraft:red_concrete
fill 136 148 305 136 149 306 minecraft:white_concrete
fill 136 148 307 136 149 308 minecraft:red_concrete
fill 136 148 309 136 149 310 minecraft:white_concrete
fill 136 148 311 136 149 311 minecraft:red_concrete
fill 136 148 313 136 149 314 minecraft:white_concrete
fill 136 148 315 136 149 316 minecraft:red_concrete
fill 136 148 317 136 149 317 minecraft:white_concrete
fill 103 149 290 103 149 301 minecraft:red_terracotta
fill 104 149 286 104 149 287 minecraft:yellow_concrete
fill 104 149 294 105 150 297 minecraft:red_terracotta
fill 104 149 304 104 149 305 minecraft:yellow_concrete
fill 105 149 290 105 149 293 minecraft:red_terracotta
fill 105 149 298 105 149 301 minecraft:red_terracotta
setblock 119 149 302 minecraft:yellow_concrete
setblock 122 149 301 minecraft:yellow_concrete
fill 130 149 311 130 150 313 minecraft:yellow_concrete
fill 131 149 314 131 150 314 minecraft:yellow_concrete
fill 132 149 310 132 150 310 minecraft:yellow_concrete
fill 133 149 314 133 150 314 minecraft:yellow_concrete
fill 134 149 312 134 150 313 minecraft:yellow_concrete
fill 94 150 275 94 151 276 minecraft:white_concrete
fill 94 150 277 94 151 278 minecraft:red_concrete
fill 94 150 279 94 151 280 minecraft:white_concrete
fill 94 150 281 94 151 282 minecraft:red_concrete
fill 94 150 283 94 151 284 minecraft:white_concrete
fill 94 150 285 94 151 286 minecraft:red_concrete
fill 94 150 287 94 151 288 minecraft:white_concrete
fill 94 150 289 94 151 290 minecraft:red_concrete
fill 94 150 291 94 151 292 minecraft:white_concrete
fill 94 150 293 94 151 294 minecraft:red_concrete
fill 94 150 295 94 151 296 minecraft:white_concrete
fill 94 150 297 94 151 298 minecraft:red_concrete
fill 94 150 299 94 151 300 minecraft:white_concrete
fill 94 150 301 94 151 302 minecraft:red_concrete
fill 94 150 303 94 151 304 minecraft:white_concrete
fill 94 150 305 94 151 306 minecraft:red_concrete
fill 94 150 307 94 151 308 minecraft:white_concrete
fill 94 150 309 94 151 310 minecraft:red_concrete
fill 94 150 311 94 151 312 minecraft:white_concrete
fill 94 150 313 94 151 314 minecraft:red_concrete
fill 94 150 315 94 151 316 minecraft:white_concrete
fill 95 150 275 95 151 275 minecraft:white_concrete
fill 95 150 317 95 151 317 minecraft:white_concrete
fill 96 150 275 97 151 275 minecraft:red_concrete
fill 96 150 317 97 151 317 minecraft:red_concrete
fill 98 150 275 99 151 275 minecraft:white_concrete
fill 98 150 317 99 151 317 minecraft:white_concrete
fill 100 150 275 101 151 275 minecraft:red_concrete
fill 100 150 317 101 151 317 minecraft:red_concrete
fill 102 150 275 103 151 275 minecraft:white_concrete
fill 102 150 317 103 151 317 minecraft:white_concrete
fill 103 150 293 103 150 298 minecraft:red_terracotta
fill 104 150 275 105 151 275 minecraft:red_concrete
fill 104 150 289 104 150 290 minecraft:yellow_concrete
fill 104 150 291 104 150 293 minecraft:red_terracotta
fill 104 150 298 104 150 300 minecraft:red_terracotta
fill 104 150 301 104 150 302 minecraft:yellow_concrete
fill 104 150 317 105 151 317 minecraft:red_concrete
setblock 105 150 293 minecraft:red_terracotta
setblock 105 150 298 minecraft:red_terracotta
fill 106 150 275 107 151 275 minecraft:white_concrete
fill 106 150 317 107 151 317 minecraft:white_concrete
fill 108 150 275 109 151 275 minecraft:red_concrete
fill 108 150 317 109 151 317 minecraft:red_concrete
fill 110 150 275 111 151 275 minecraft:white_concrete
fill 110 150 317 111 151 317 minecraft:white_concrete
fill 112 150 275 113 151 275 minecraft:red_concrete
fill 112 150 317 113 151 317 minecraft:red_concrete
fill 114 150 275 115 151 275 minecraft:white_concrete
fill 114 150 317 115 151 317 minecraft:white_concrete
fill 116 150 275 117 151 275 minecraft:red_concrete
fill 116 150 317 117 151 317 minecraft:red_concrete
fill 118 150 275 119 151 275 minecraft:white_concrete
fill 118 150 317 119 151 317 minecraft:white_concrete
fill 120 150 275 121 151 275 minecraft:red_concrete
fill 120 150 317 121 151 317 minecraft:red_concrete
fill 122 150 275 123 151 275 minecraft:white_concrete
fill 122 150 317 123 151 317 minecraft:white_concrete
fill 124 150 275 125 151 275 minecraft:red_concrete
schedule function dropper:buildpart/62_2 1t
