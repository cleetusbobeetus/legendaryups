fill 406 164 276 409 164 276 minecraft:red_terracotta
setblock 408 164 311 minecraft:stripped_oak_log
setblock 409 164 277 minecraft:stripped_oak_log
setblock 410 164 276 minecraft:stripped_oak_log
fill 410 164 277 410 167 277 minecraft:red_terracotta
setblock 410 164 316 minecraft:stripped_oak_log
fill 411 164 276 411 167 276 minecraft:red_terracotta
setblock 411 164 315 minecraft:stripped_oak_log
fill 411 164 316 411 167 316 minecraft:red_terracotta
setblock 412 164 278 minecraft:red_terracotta
fill 412 164 315 412 167 315 minecraft:red_terracotta
setblock 413 164 278 minecraft:stripped_oak_log
setblock 414 164 276 minecraft:red_terracotta
setblock 414 164 277 minecraft:stripped_oak_log
fill 414 164 278 416 165 278 minecraft:red_terracotta
setblock 414 164 292 minecraft:stripped_oak_log
fill 414 164 293 414 166 293 minecraft:red_terracotta
fill 414 164 295 414 164 296 minecraft:red_terracotta
setblock 414 164 297 minecraft:stripped_oak_log
fill 414 164 298 414 167 298 minecraft:red_terracotta
setblock 415 164 276 minecraft:stripped_oak_log
fill 415 164 277 416 166 277 minecraft:red_terracotta
fill 415 164 279 415 164 280 minecraft:red_terracotta
setblock 415 164 281 minecraft:stripped_oak_log
fill 415 164 282 415 164 285 minecraft:red_terracotta
setblock 415 164 286 minecraft:stripped_oak_log
fill 415 164 287 415 166 287 minecraft:red_terracotta
setblock 415 164 291 minecraft:stripped_oak_log
fill 415 164 292 415 167 292 minecraft:red_terracotta
setblock 415 164 296 minecraft:stripped_oak_log
fill 415 164 297 415 167 297 minecraft:red_terracotta
setblock 415 164 316 minecraft:stripped_oak_log
fill 416 164 276 416 167 276 minecraft:red_terracotta
setblock 416 164 279 minecraft:red_terracotta
setblock 416 164 280 minecraft:stripped_oak_log
fill 416 164 281 416 167 281 minecraft:red_terracotta
setblock 416 164 285 minecraft:stripped_oak_log
fill 416 164 286 416 167 286 minecraft:red_terracotta
setblock 416 164 290 minecraft:stripped_oak_log
fill 416 164 291 416 167 291 minecraft:red_terracotta
setblock 416 164 295 minecraft:stripped_oak_log
fill 416 164 296 416 167 296 minecraft:red_terracotta
setblock 416 164 299 minecraft:red_terracotta
setblock 416 164 300 minecraft:stripped_oak_log
fill 416 164 301 416 167 301 minecraft:red_terracotta
setblock 416 164 315 minecraft:stripped_oak_log
fill 416 164 316 416 167 316 minecraft:red_terracotta
setblock 417 164 279 minecraft:stripped_oak_log
fill 417 164 280 417 167 280 minecraft:red_terracotta
setblock 417 164 284 minecraft:stripped_oak_log
fill 417 164 285 417 167 285 minecraft:red_terracotta
setblock 417 164 289 minecraft:stripped_oak_log
fill 417 164 290 417 167 290 minecraft:red_terracotta
setblock 417 164 294 minecraft:stripped_oak_log
fill 417 164 295 417 167 295 minecraft:red_terracotta
setblock 417 164 299 minecraft:stripped_oak_log
fill 417 164 300 417 167 300 minecraft:red_terracotta
setblock 417 164 304 minecraft:stripped_oak_log
setblock 417 164 310 minecraft:red_terracotta
setblock 417 164 314 minecraft:stripped_oak_log
fill 417 164 315 417 167 315 minecraft:red_terracotta
fill 418 164 276 418 167 316 minecraft:light_gray_terracotta
fill 377 165 275 391 167 275 minecraft:light_gray_terracotta
setblock 377 165 278 minecraft:stripped_oak_log
fill 377 165 279 377 168 279 minecraft:red_terracotta
setblock 377 165 283 minecraft:stripped_oak_log
fill 377 165 284 377 168 284 minecraft:red_terracotta
setblock 377 165 288 minecraft:stripped_oak_log
fill 377 165 289 377 166 289 minecraft:red_terracotta
setblock 377 165 293 minecraft:stripped_oak_log
fill 377 165 294 377 168 294 minecraft:red_terracotta
setblock 377 165 298 minecraft:stripped_oak_log
fill 377 165 299 377 168 299 minecraft:red_terracotta
setblock 377 165 303 minecraft:stripped_oak_log
fill 377 165 304 377 168 304 minecraft:red_terracotta
setblock 377 165 308 minecraft:stripped_oak_log
fill 377 165 309 377 166 309 minecraft:red_terracotta
setblock 377 165 313 minecraft:stripped_oak_log
fill 377 165 314 377 168 314 minecraft:red_terracotta
setblock 378 165 277 minecraft:stripped_oak_log
fill 378 165 278 378 168 278 minecraft:red_terracotta
setblock 378 165 282 minecraft:stripped_oak_log
fill 378 165 283 378 166 283 minecraft:red_terracotta
setblock 378 165 293 minecraft:red_terracotta
setblock 378 165 297 minecraft:stripped_oak_log
fill 378 165 298 378 166 298 minecraft:red_terracotta
setblock 378 165 312 minecraft:stripped_oak_log
fill 378 165 313 378 166 313 minecraft:red_terracotta
setblock 378 165 316 minecraft:red_terracotta
setblock 379 165 276 minecraft:stripped_oak_log
fill 379 165 277 379 168 277 minecraft:red_terracotta
setblock 379 165 316 minecraft:stripped_oak_log
fill 380 165 276 383 165 276 minecraft:red_terracotta
setblock 380 165 294 minecraft:brown_terracotta
setblock 380 165 296 minecraft:brown_terracotta
setblock 380 165 315 minecraft:stripped_oak_log
fill 380 165 316 383 165 316 minecraft:red_terracotta
fill 381 165 315 384 165 315 minecraft:red_terracotta
setblock 382 165 277 minecraft:red_terracotta
setblock 382 165 294 minecraft:brown_terracotta
setblock 382 165 296 minecraft:brown_terracotta
setblock 383 165 277 minecraft:stripped_oak_log
fill 383 165 298 383 167 298 minecraft:brown_terracotta
fill 383 165 300 383 167 300 minecraft:brown_terracotta
setblock 384 165 276 minecraft:stripped_oak_log
fill 384 165 277 387 165 277 minecraft:red_terracotta
fill 384 165 297 384 167 297 minecraft:brown_terracotta
setblock 384 165 316 minecraft:stripped_oak_log
fill 385 165 276 385 168 276 minecraft:red_terracotta
fill 385 165 302 385 167 302 minecraft:brown_terracotta
setblock 385 165 315 minecraft:stripped_oak_log
fill 385 165 316 388 165 316 minecraft:red_terracotta
fill 386 165 315 386 168 315 minecraft:red_terracotta
fill 387 165 297 387 167 297 minecraft:brown_terracotta
fill 387 165 301 387 167 301 minecraft:brown_terracotta
setblock 388 165 277 minecraft:stripped_oak_log
fill 388 165 279 398 165 279 minecraft:orange_terracotta
fill 388 165 299 388 167 300 minecraft:brown_terracotta
setblock 389 165 276 minecraft:stripped_oak_log
fill 389 165 277 389 168 277 minecraft:red_terracotta
setblock 389 165 316 minecraft:stripped_oak_log
fill 390 165 276 390 168 276 minecraft:red_terracotta
setblock 390 165 315 minecraft:stripped_oak_log
fill 390 165 316 390 168 316 minecraft:red_terracotta
setblock 391 165 314 minecraft:stripped_oak_log
fill 391 165 315 391 168 315 minecraft:red_terracotta
fill 392 165 275 394 168 275 minecraft:shroomlight
setblock 392 165 277 minecraft:red_terracotta
setblock 392 165 278 minecraft:stripped_oak_log
setblock 392 165 313 minecraft:stripped_oak_log
fill 392 165 314 392 168 314 minecraft:red_terracotta
setblock 393 165 277 minecraft:stripped_oak_log
fill 393 165 278 394 167 278 minecraft:red_terracotta
setblock 393 165 313 minecraft:red_terracotta
setblock 394 165 276 minecraft:stripped_oak_log
fill 394 165 277 394 168 277 minecraft:red_terracotta
setblock 394 165 316 minecraft:stripped_oak_log
fill 395 165 275 418 167 275 minecraft:light_gray_terracotta
fill 395 165 276 395 168 276 minecraft:red_terracotta
setblock 395 165 315 minecraft:stripped_oak_log
fill 395 165 316 395 168 316 minecraft:red_terracotta
setblock 396 165 314 minecraft:stripped_oak_log
fill 396 165 315 396 168 315 minecraft:red_terracotta
setblock 397 165 314 minecraft:red_terracotta
fill 397 165 316 398 165 316 minecraft:red_terracotta
setblock 398 165 277 minecraft:stripped_oak_log
setblock 399 165 276 minecraft:stripped_oak_log
setblock 399 165 316 minecraft:stripped_oak_log
fill 400 165 276 400 167 276 minecraft:red_terracotta
setblock 400 165 315 minecraft:stripped_oak_log
fill 400 165 316 400 167 316 minecraft:red_terracotta
setblock 403 165 276 minecraft:red_terracotta
setblock 404 165 276 minecraft:stripped_oak_log
fill 405 165 276 408 165 276 minecraft:red_terracotta
setblock 408 165 277 minecraft:stripped_oak_log
fill 408 165 314 408 167 314 minecraft:green_concrete
setblock 409 165 276 minecraft:stripped_oak_log
fill 409 165 277 409 168 277 minecraft:red_terracotta
setblock 409 165 316 minecraft:stripped_oak_log
fill 410 165 276 410 168 276 minecraft:red_terracotta
fill 410 165 316 410 168 316 minecraft:red_terracotta
setblock 411 165 278 minecraft:red_terracotta
fill 411 165 315 411 167 315 minecraft:red_terracotta
setblock 412 165 277 minecraft:red_terracotta
setblock 412 165 278 minecraft:stripped_oak_log
setblock 413 165 277 minecraft:stripped_oak_log
fill 413 165 278 413 168 278 minecraft:red_terracotta
setblock 414 165 276 minecraft:stripped_oak_log
fill 414 165 277 414 168 277 minecraft:red_terracotta
fill 414 165 279 414 165 280 minecraft:red_terracotta
setblock 414 165 291 minecraft:stripped_oak_log
fill 414 165 292 414 166 292 minecraft:red_terracotta
setblock 414 165 295 minecraft:red_terracotta
setblock 414 165 296 minecraft:stripped_oak_log
fill 414 165 297 414 167 297 minecraft:red_terracotta
fill 414 165 299 414 166 299 minecraft:red_terracotta
setblock 414 165 316 minecraft:stripped_oak_log
fill 415 165 276 415 168 276 minecraft:red_terracotta
setblock 415 165 279 minecraft:red_terracotta
setblock 415 165 280 minecraft:stripped_oak_log
fill 415 165 281 415 165 284 minecraft:red_terracotta
setblock 415 165 285 minecraft:stripped_oak_log
fill 415 165 286 415 166 286 minecraft:red_terracotta
setblock 415 165 290 minecraft:stripped_oak_log
fill 415 165 291 415 167 291 minecraft:red_terracotta
setblock 415 165 295 minecraft:stripped_oak_log
fill 415 165 296 415 168 296 minecraft:red_terracotta
setblock 415 165 300 minecraft:stripped_oak_log
fill 415 165 301 415 167 301 minecraft:red_terracotta
setblock 415 165 315 minecraft:stripped_oak_log
fill 415 165 316 415 168 316 minecraft:red_terracotta
setblock 416 165 279 minecraft:stripped_oak_log
fill 416 165 280 416 168 280 minecraft:red_terracotta
setblock 416 165 284 minecraft:stripped_oak_log
fill 416 165 285 416 168 285 minecraft:red_terracotta
setblock 416 165 289 minecraft:stripped_oak_log
fill 416 165 290 416 168 290 minecraft:red_terracotta
setblock 416 165 294 minecraft:stripped_oak_log
fill 416 165 295 416 168 295 minecraft:red_terracotta
setblock 416 165 299 minecraft:stripped_oak_log
fill 416 165 300 416 168 300 minecraft:red_terracotta
setblock 416 165 303 minecraft:red_terracotta
setblock 416 165 314 minecraft:stripped_oak_log
fill 416 165 315 416 167 315 minecraft:red_terracotta
setblock 417 165 278 minecraft:stripped_oak_log
fill 417 165 279 417 168 279 minecraft:red_terracotta
setblock 417 165 283 minecraft:stripped_oak_log
fill 417 165 284 417 168 284 minecraft:red_terracotta
setblock 417 165 288 minecraft:stripped_oak_log
fill 417 165 289 417 168 289 minecraft:red_terracotta
setblock 417 165 293 minecraft:stripped_oak_log
fill 417 165 294 417 168 294 minecraft:red_terracotta
setblock 417 165 298 minecraft:stripped_oak_log
fill 417 165 299 417 168 299 minecraft:red_terracotta
setblock 417 165 303 minecraft:stripped_oak_log
fill 417 165 304 417 165 305 minecraft:red_terracotta
setblock 417 165 313 minecraft:stripped_oak_log
fill 417 165 314 417 168 314 minecraft:red_terracotta
setblock 377 166 277 minecraft:stripped_oak_log
fill 377 166 278 377 169 278 minecraft:red_terracotta
setblock 377 166 282 minecraft:stripped_oak_log
fill 377 166 283 377 169 283 minecraft:red_terracotta
setblock 377 166 287 minecraft:stripped_oak_log
setblock 377 166 288 minecraft:red_terracotta
setblock 377 166 292 minecraft:stripped_oak_log
fill 377 166 293 377 167 293 minecraft:red_terracotta
setblock 377 166 297 minecraft:stripped_oak_log
fill 377 166 298 377 169 298 minecraft:red_terracotta
setblock 377 166 301 minecraft:red_terracotta
setblock 377 166 302 minecraft:stripped_oak_log
fill 377 166 303 377 169 303 minecraft:red_terracotta
fill 377 166 305 377 167 305 minecraft:red_terracotta
setblock 377 166 312 minecraft:stripped_oak_log
fill 377 166 313 377 169 313 minecraft:red_terracotta
setblock 378 166 276 minecraft:stripped_oak_log
fill 378 166 277 378 169 277 minecraft:red_terracotta
setblock 378 166 281 minecraft:stripped_oak_log
fill 378 166 282 378 168 282 minecraft:red_terracotta
fill 378 166 290 384 167 291 minecraft:stripped_oak_log
setblock 378 166 296 minecraft:stripped_oak_log
setblock 378 166 297 minecraft:red_terracotta
setblock 378 166 316 minecraft:stripped_oak_log
fill 379 166 276 382 166 276 minecraft:red_terracotta
setblock 379 166 315 minecraft:stripped_oak_log
fill 379 166 316 382 166 316 minecraft:red_terracotta
fill 380 166 315 383 166 315 minecraft:red_terracotta
setblock 382 166 277 minecraft:stripped_oak_log
setblock 383 166 276 minecraft:stripped_oak_log
fill 383 166 277 386 166 277 minecraft:red_terracotta
fill 383 166 297 383 167 297 minecraft:brown_terracotta
fill 383 166 301 383 167 301 minecraft:brown_terracotta
setblock 383 166 316 minecraft:stripped_oak_log
fill 384 166 276 384 169 276 minecraft:red_terracotta
fill 384 166 302 384 167 302 minecraft:brown_terracotta
setblock 384 166 315 minecraft:stripped_oak_log
fill 384 166 316 387 166 316 minecraft:red_terracotta
fill 385 166 290 391 167 290 minecraft:stripped_oak_log
fill 385 166 296 385 167 296 minecraft:brown_terracotta
fill 385 166 315 385 168 315 minecraft:red_terracotta
fill 386 166 302 387 167 302 minecraft:brown_terracotta
setblock 387 166 277 minecraft:stripped_oak_log
setblock 388 166 276 minecraft:stripped_oak_log
fill 388 166 277 388 169 277 minecraft:red_terracotta
setblock 388 166 279 minecraft:stripped_oak_log
fill 388 166 298 388 167 298 minecraft:brown_terracotta
fill 388 166 301 388 167 301 minecraft:brown_terracotta
setblock 388 166 316 minecraft:stripped_oak_log
fill 389 166 276 389 169 276 minecraft:red_terracotta
setblock 389 166 315 minecraft:stripped_oak_log
fill 389 166 316 389 169 316 minecraft:red_terracotta
setblock 390 166 278 minecraft:red_terracotta
setblock 390 166 314 minecraft:stripped_oak_log
fill 390 166 315 390 169 315 minecraft:red_terracotta
setblock 391 166 278 minecraft:stripped_oak_log
fill 391 166 314 391 168 314 minecraft:red_terracotta
setblock 392 166 277 minecraft:stripped_oak_log
fill 392 166 278 392 168 278 minecraft:red_terracotta
setblock 393 166 276 minecraft:stripped_oak_log
fill 393 166 277 393 169 277 minecraft:red_terracotta
setblock 393 166 279 minecraft:stripped_oak_log
setblock 393 166 316 minecraft:stripped_oak_log
fill 394 166 276 394 169 276 minecraft:red_terracotta
fill 394 166 289 396 167 289 minecraft:stripped_oak_log
setblock 394 166 315 minecraft:stripped_oak_log
fill 394 166 316 394 169 316 minecraft:red_terracotta
setblock 395 166 314 minecraft:stripped_oak_log
fill 395 166 315 395 169 315 minecraft:red_terracotta
setblock 396 166 314 minecraft:red_terracotta
setblock 397 166 277 minecraft:stripped_oak_log
setblock 397 166 316 minecraft:red_terracotta
setblock 398 166 276 minecraft:stripped_oak_log
setblock 398 166 277 minecraft:red_terracotta
setblock 398 166 279 minecraft:stripped_oak_log
setblock 398 166 316 minecraft:stripped_oak_log
fill 399 166 276 399 168 276 minecraft:red_terracotta
fill 399 166 315 399 168 315 minecraft:green_concrete
fill 399 166 316 399 168 316 minecraft:red_terracotta
setblock 403 166 276 minecraft:stripped_oak_log
fill 404 166 276 407 166 276 minecraft:red_terracotta
fill 404 166 277 404 168 277 minecraft:green_concrete
setblock 407 166 277 minecraft:stripped_oak_log
setblock 407 166 316 minecraft:red_terracotta
setblock 408 166 276 minecraft:stripped_oak_log
fill 408 166 277 408 169 277 minecraft:red_terracotta
setblock 408 166 316 minecraft:stripped_oak_log
fill 409 166 276 409 169 276 minecraft:red_terracotta
fill 409 166 316 409 169 316 minecraft:red_terracotta
setblock 410 166 278 minecraft:red_terracotta
setblock 411 166 278 minecraft:stripped_oak_log
setblock 412 166 277 minecraft:stripped_oak_log
fill 412 166 278 412 168 279 minecraft:red_terracotta
setblock 413 166 276 minecraft:stripped_oak_log
fill 413 166 277 413 169 277 minecraft:red_terracotta
fill 413 166 279 414 166 279 minecraft:red_terracotta
setblock 413 166 316 minecraft:stripped_oak_log
fill 414 166 276 414 169 276 minecraft:red_terracotta
fill 414 166 278 415 166 278 minecraft:red_terracotta
setblock 414 166 280 minecraft:stripped_oak_log
fill 414 166 281 415 168 281 minecraft:red_terracotta
setblock 414 166 295 minecraft:stripped_oak_log
fill 414 166 296 414 167 296 minecraft:red_terracotta
setblock 414 166 315 minecraft:stripped_oak_log
fill 414 166 316 414 169 316 minecraft:red_terracotta
setblock 415 166 279 minecraft:stripped_oak_log
fill 415 166 280 415 169 280 minecraft:red_terracotta
fill 415 166 282 415 166 283 minecraft:red_terracotta
setblock 415 166 284 minecraft:stripped_oak_log
fill 415 166 285 415 167 285 minecraft:red_terracotta
setblock 415 166 289 minecraft:stripped_oak_log
fill 415 166 290 415 167 290 minecraft:red_terracotta
setblock 415 166 294 minecraft:stripped_oak_log
fill 415 166 295 415 168 295 minecraft:red_terracotta
setblock 415 166 299 minecraft:stripped_oak_log
fill 415 166 300 415 168 300 minecraft:red_terracotta
fill 415 166 315 415 167 315 minecraft:red_terracotta
setblock 416 166 278 minecraft:stripped_oak_log
fill 416 166 279 416 169 279 minecraft:red_terracotta
setblock 416 166 283 minecraft:stripped_oak_log
fill 416 166 284 416 169 284 minecraft:red_terracotta
setblock 416 166 288 minecraft:stripped_oak_log
fill 416 166 289 416 168 289 minecraft:red_terracotta
setblock 416 166 293 minecraft:stripped_oak_log
fill 416 166 294 416 168 294 minecraft:red_terracotta
setblock 416 166 298 minecraft:stripped_oak_log
fill 416 166 299 416 169 299 minecraft:red_terracotta
setblock 416 166 303 minecraft:stripped_oak_log
setblock 416 166 314 minecraft:red_terracotta
setblock 417 166 277 minecraft:stripped_oak_log
fill 417 166 278 417 169 278 minecraft:red_terracotta
setblock 417 166 282 minecraft:stripped_oak_log
fill 417 166 283 417 169 283 minecraft:red_terracotta
setblock 417 166 287 minecraft:stripped_oak_log
fill 417 166 288 417 169 288 minecraft:red_terracotta
setblock 417 166 292 minecraft:stripped_oak_log
fill 417 166 293 417 169 293 minecraft:red_terracotta
setblock 417 166 297 minecraft:stripped_oak_log
fill 417 166 298 417 169 298 minecraft:red_terracotta
setblock 417 166 302 minecraft:stripped_oak_log
fill 417 166 303 417 168 304 minecraft:red_terracotta
setblock 417 166 312 minecraft:stripped_oak_log
fill 417 166 313 417 167 313 minecraft:red_terracotta
setblock 377 167 276 minecraft:stripped_oak_log
fill 377 167 277 377 170 277 minecraft:red_terracotta
setblock 377 167 281 minecraft:stripped_oak_log
fill 377 167 282 377 170 282 minecraft:red_terracotta
setblock 377 167 286 minecraft:stripped_oak_log
setblock 377 167 287 minecraft:red_terracotta
setblock 377 167 291 minecraft:stripped_oak_log
setblock 377 167 292 minecraft:red_terracotta
setblock 377 167 296 minecraft:stripped_oak_log
fill 377 167 297 377 169 297 minecraft:red_terracotta
setblock 377 167 301 minecraft:stripped_oak_log
fill 377 167 302 377 170 302 minecraft:red_terracotta
setblock 377 167 311 minecraft:stripped_oak_log
fill 377 167 312 377 168 312 minecraft:red_terracotta
setblock 377 167 315 minecraft:red_terracotta
setblock 377 167 316 minecraft:stripped_oak_log
fill 378 167 276 381 167 276 minecraft:red_terracotta
setblock 378 167 280 minecraft:stripped_oak_log
fill 378 167 281 378 169 281 minecraft:red_terracotta
setblock 378 167 315 minecraft:stripped_oak_log
fill 378 167 316 381 167 316 minecraft:red_terracotta
setblock 379 167 279 minecraft:stripped_oak_log
setblock 379 167 285 minecraft:light[level=12]
setblock 379 167 286 minecraft:light[level=15]
setblock 379 167 292 minecraft:light[level=12]
setblock 379 167 294 minecraft:light[level=15]
setblock 379 167 299 minecraft:light[level=12]
setblock 379 167 302 minecraft:light[level=15]
setblock 379 167 306 minecraft:light[level=12]
setblock 379 167 313 minecraft:light[level=12]
fill 379 167 315 382 167 315 minecraft:red_terracotta
setblock 381 167 277 minecraft:stripped_oak_log
setblock 382 167 276 minecraft:stripped_oak_log
fill 382 167 277 385 167 277 minecraft:red_terracotta
fill 382 167 298 382 167 300 minecraft:brown_terracotta
setblock 382 167 316 minecraft:stripped_oak_log
fill 383 167 276 383 170 276 minecraft:red_terracotta
setblock 383 167 302 minecraft:brown_terracotta
setblock 383 167 315 minecraft:stripped_oak_log
fill 383 167 316 386 167 316 minecraft:red_terracotta
setblock 384 167 296 minecraft:brown_terracotta
setblock 384 167 315 minecraft:red_terracotta
fill 385 167 291 386 167 291 minecraft:stripped_oak_log
setblock 386 167 277 minecraft:stripped_oak_log
setblock 386 167 278 minecraft:light[level=12]
setblock 386 167 285 minecraft:light[level=12]
setblock 386 167 292 minecraft:light[level=12]
fill 386 167 296 387 167 296 minecraft:brown_terracotta
setblock 386 167 306 minecraft:light[level=12]
setblock 386 167 313 minecraft:light[level=12]
setblock 387 167 276 minecraft:stripped_oak_log
fill 387 167 277 387 170 277 minecraft:red_terracotta
setblock 387 167 278 minecraft:light[level=15]
setblock 387 167 294 minecraft:light[level=15]
setblock 387 167 310 minecraft:light[level=15]
setblock 387 167 316 minecraft:stripped_oak_log
fill 388 167 276 388 170 276 minecraft:red_terracotta
fill 388 167 289 393 167 289 minecraft:stripped_oak_log
setblock 388 167 297 minecraft:brown_terracotta
setblock 388 167 315 minecraft:stripped_oak_log
fill 388 167 316 388 170 316 minecraft:red_terracotta
setblock 389 167 299 minecraft:brown_terracotta
setblock 389 167 314 minecraft:stripped_oak_log
fill 389 167 315 389 170 315 minecraft:red_terracotta
setblock 390 167 278 minecraft:stripped_oak_log
fill 390 167 314 390 168 314 minecraft:red_terracotta
setblock 391 167 277 minecraft:stripped_oak_log
fill 391 167 278 391 168 278 minecraft:red_terracotta
setblock 392 167 276 minecraft:stripped_oak_log
fill 392 167 277 392 170 277 minecraft:red_terracotta
fill 392 167 290 397 167 290 minecraft:stripped_oak_log
setblock 392 167 316 minecraft:stripped_oak_log
fill 393 167 276 393 170 276 minecraft:red_terracotta
setblock 393 167 285 minecraft:light[level=12]
setblock 393 167 292 minecraft:light[level=12]
setblock 393 167 299 minecraft:light[level=12]
setblock 393 167 306 minecraft:light[level=12]
setblock 393 167 313 minecraft:light[level=12]
setblock 393 167 315 minecraft:stripped_oak_log
fill 393 167 316 393 170 316 minecraft:red_terracotta
setblock 394 167 314 minecraft:stripped_oak_log
fill 394 167 315 394 169 315 minecraft:red_terracotta
setblock 395 167 278 minecraft:light[level=15]
setblock 395 167 286 minecraft:light[level=15]
setblock 395 167 294 minecraft:light[level=15]
setblock 395 167 302 minecraft:light[level=15]
setblock 395 167 310 minecraft:light[level=15]
setblock 395 167 314 minecraft:red_terracotta
setblock 396 167 277 minecraft:stripped_oak_log
setblock 397 167 276 minecraft:stripped_oak_log
setblock 397 167 277 minecraft:red_terracotta
fill 397 167 289 407 167 289 minecraft:stripped_oak_log
setblock 397 167 316 minecraft:stripped_oak_log
fill 398 167 276 398 169 276 minecraft:red_terracotta
fill 398 167 288 415 167 288 minecraft:stripped_oak_log
fill 398 167 316 398 168 316 minecraft:red_terracotta
setblock 400 167 278 minecraft:light[level=12]
setblock 400 167 285 minecraft:light[level=12]
setblock 400 167 292 minecraft:light[level=12]
setblock 400 167 299 minecraft:light[level=12]
setblock 400 167 313 minecraft:light[level=12]
setblock 402 167 276 minecraft:stripped_oak_log
fill 403 167 276 406 167 276 minecraft:red_terracotta
setblock 403 167 278 minecraft:light[level=15]
setblock 403 167 286 minecraft:light[level=15]
setblock 403 167 294 minecraft:light[level=15]
setblock 403 167 302 minecraft:light[level=15]
setblock 403 167 310 minecraft:light[level=15]
setblock 407 167 276 minecraft:stripped_oak_log
fill 407 167 277 407 170 277 minecraft:red_terracotta
setblock 407 167 278 minecraft:light[level=12]
setblock 407 167 285 minecraft:light[level=12]
setblock 407 167 292 minecraft:light[level=12]
setblock 407 167 299 minecraft:light[level=12]
setblock 407 167 306 minecraft:light[level=12]
setblock 407 167 313 minecraft:light[level=12]
setblock 407 167 316 minecraft:stripped_oak_log
fill 408 167 276 408 170 276 minecraft:red_terracotta
fill 408 167 316 408 168 316 minecraft:red_terracotta
setblock 409 167 278 minecraft:red_terracotta
fill 409 167 287 416 167 287 minecraft:stripped_oak_log
setblock 410 167 278 minecraft:stripped_oak_log
setblock 411 167 277 minecraft:stripped_oak_log
fill 411 167 278 411 169 279 minecraft:red_terracotta
setblock 411 167 286 minecraft:light[level=15]
setblock 411 167 294 minecraft:light[level=15]
setblock 411 167 302 minecraft:light[level=15]
setblock 411 167 310 minecraft:light[level=15]
setblock 412 167 276 minecraft:stripped_oak_log
fill 412 167 277 412 170 277 minecraft:red_terracotta
setblock 412 167 316 minecraft:stripped_oak_log
fill 413 167 276 413 170 276 minecraft:red_terracotta
setblock 413 167 279 minecraft:red_terracotta
setblock 413 167 315 minecraft:stripped_oak_log
fill 413 167 316 413 170 316 minecraft:red_terracotta
setblock 414 167 278 minecraft:red_terracotta
setblock 414 167 279 minecraft:stripped_oak_log
fill 414 167 280 414 170 280 minecraft:red_terracotta
setblock 414 167 285 minecraft:light[level=12]
setblock 414 167 292 minecraft:light[level=12]
setblock 414 167 294 minecraft:stripped_oak_log
setblock 414 167 295 minecraft:red_terracotta
setblock 414 167 299 minecraft:light[level=12]
setblock 414 167 306 minecraft:light[level=12]
setblock 414 167 313 minecraft:light[level=12]
setblock 414 167 315 minecraft:red_terracotta
setblock 415 167 277 minecraft:red_terracotta
setblock 415 167 278 minecraft:stripped_oak_log
fill 415 167 279 415 170 279 minecraft:red_terracotta
setblock 415 167 282 minecraft:red_terracotta
setblock 415 167 283 minecraft:stripped_oak_log
fill 415 167 284 415 169 284 minecraft:red_terracotta
setblock 415 167 293 minecraft:stripped_oak_log
fill 415 167 294 415 168 294 minecraft:red_terracotta
setblock 415 167 298 minecraft:stripped_oak_log
fill 415 167 299 415 168 299 minecraft:red_terracotta
setblock 416 167 277 minecraft:stripped_oak_log
fill 416 167 278 416 170 278 minecraft:red_terracotta
setblock 416 167 282 minecraft:stripped_oak_log
fill 416 167 283 416 170 283 minecraft:red_terracotta
fill 416 167 288 416 168 288 minecraft:red_terracotta
setblock 416 167 292 minecraft:stripped_oak_log
fill 416 167 293 416 168 293 minecraft:red_terracotta
setblock 416 167 297 minecraft:stripped_oak_log
fill 416 167 298 416 169 298 minecraft:red_terracotta
setblock 416 167 302 minecraft:stripped_oak_log
setblock 417 167 276 minecraft:stripped_oak_log
fill 417 167 277 417 170 277 minecraft:red_terracotta
setblock 417 167 281 minecraft:stripped_oak_log
fill 417 167 282 417 170 282 minecraft:red_terracotta
setblock 417 167 286 minecraft:stripped_oak_log
fill 417 167 287 417 170 287 minecraft:red_terracotta
setblock 417 167 291 minecraft:stripped_oak_log
fill 417 167 292 417 169 292 minecraft:red_terracotta
setblock 417 167 296 minecraft:stripped_oak_log
fill 417 167 297 417 170 297 minecraft:red_terracotta
setblock 417 167 301 minecraft:stripped_oak_log
fill 417 167 302 417 170 302 minecraft:red_terracotta
setblock 417 167 316 minecraft:stripped_oak_log
fill 376 168 275 376 171 317 minecraft:orange_terracotta
fill 377 168 275 391 171 275 minecraft:orange_terracotta
fill 377 168 276 380 168 276 minecraft:red_terracotta
setblock 377 168 280 minecraft:stripped_oak_log
fill 377 168 281 377 171 281 minecraft:red_terracotta
setblock 377 168 285 minecraft:stripped_oak_log
fill 377 168 291 382 168 291 minecraft:orange_terracotta
setblock 377 168 295 minecraft:stripped_oak_log
setblock 377 168 296 minecraft:red_terracotta
setblock 377 168 300 minecraft:stripped_oak_log
fill 377 168 301 377 170 301 minecraft:red_terracotta
setblock 377 168 315 minecraft:stripped_oak_log
fill 377 168 316 380 168 316 minecraft:red_terracotta
fill 377 168 317 418 171 317 minecraft:orange_terracotta
setblock 378 168 279 minecraft:stripped_oak_log
fill 378 168 280 378 170 280 minecraft:red_terracotta
fill 378 168 315 379 168 315 minecraft:red_terracotta
setblock 379 168 278 minecraft:stripped_oak_log
setblock 380 168 277 minecraft:stripped_oak_log
setblock 381 168 276 minecraft:stripped_oak_log
fill 381 168 277 384 168 277 minecraft:red_terracotta
setblock 381 168 316 minecraft:stripped_oak_log
fill 382 168 276 382 171 276 minecraft:red_terracotta
fill 382 168 290 391 168 290 minecraft:orange_terracotta
fill 382 168 316 385 168 316 minecraft:red_terracotta
setblock 385 168 277 minecraft:stripped_oak_log
fill 385 168 298 385 168 300 minecraft:shroomlight
setblock 386 168 276 minecraft:stripped_oak_log
fill 386 168 277 386 170 277 minecraft:red_terracotta
fill 386 168 299 386 169 300 minecraft:shroomlight
setblock 386 168 316 minecraft:stripped_oak_log
fill 387 168 276 387 171 276 minecraft:red_terracotta
setblock 387 168 315 minecraft:stripped_oak_log
fill 387 168 316 387 171 316 minecraft:red_terracotta
fill 388 168 315 388 171 315 minecraft:red_terracotta
setblock 389 168 314 minecraft:red_terracotta
setblock 390 168 277 minecraft:stripped_oak_log
setblock 390 168 278 minecraft:red_terracotta
setblock 391 168 276 minecraft:stripped_oak_log
fill 391 168 277 391 171 277 minecraft:red_terracotta
setblock 391 168 316 minecraft:stripped_oak_log
fill 392 168 276 392 171 276 minecraft:red_terracotta
setblock 392 168 315 minecraft:stripped_oak_log
fill 392 168 316 392 171 316 minecraft:red_terracotta
fill 393 168 289 396 168 289 minecraft:orange_terracotta
setblock 393 168 314 minecraft:stripped_oak_log
fill 393 168 315 393 170 315 minecraft:red_terracotta
fill 395 168 275 418 171 275 minecraft:orange_terracotta
setblock 395 168 277 minecraft:stripped_oak_log
setblock 396 168 276 minecraft:stripped_oak_log
setblock 396 168 277 minecraft:red_terracotta
setblock 396 168 316 minecraft:stripped_oak_log
fill 397 168 276 397 169 276 minecraft:red_terracotta
fill 397 168 289 403 168 289 minecraft:stripped_oak_log
fill 397 168 316 397 169 316 minecraft:red_terracotta
fill 403 168 288 415 168 288 minecraft:stripped_oak_log
fill 404 168 276 405 168 276 minecraft:red_terracotta
setblock 406 168 276 minecraft:stripped_oak_log
fill 407 168 276 407 171 276 minecraft:red_terracotta
setblock 409 168 278 minecraft:stripped_oak_log
setblock 410 168 277 minecraft:stripped_oak_log
fill 410 168 278 410 171 278 minecraft:red_terracotta
setblock 411 168 276 minecraft:stripped_oak_log
fill 411 168 277 411 171 277 minecraft:red_terracotta
fill 411 168 287 415 168 287 minecraft:stripped_oak_log
setblock 411 168 316 minecraft:stripped_oak_log
fill 412 168 276 412 171 276 minecraft:red_terracotta
fill 412 168 316 412 171 316 minecraft:red_terracotta
setblock 413 168 279 minecraft:stripped_oak_log
setblock 414 168 278 minecraft:stripped_oak_log
fill 414 168 279 414 170 279 minecraft:red_terracotta
setblock 415 168 277 minecraft:stripped_oak_log
fill 415 168 278 415 171 278 minecraft:red_terracotta
setblock 415 168 282 minecraft:stripped_oak_log
fill 415 168 283 415 171 283 minecraft:red_terracotta
setblock 415 168 297 minecraft:stripped_oak_log
setblock 415 168 298 minecraft:red_terracotta
setblock 416 168 276 minecraft:stripped_oak_log
fill 416 168 277 416 171 277 minecraft:red_terracotta
setblock 416 168 281 minecraft:stripped_oak_log
fill 416 168 282 416 171 282 minecraft:red_terracotta
setblock 416 168 286 minecraft:stripped_oak_log
setblock 416 168 287 minecraft:red_terracotta
setblock 416 168 291 minecraft:stripped_oak_log
setblock 416 168 292 minecraft:red_terracotta
setblock 416 168 296 minecraft:stripped_oak_log
fill 416 168 297 416 169 297 minecraft:red_terracotta
setblock 416 168 301 minecraft:stripped_oak_log
setblock 416 168 302 minecraft:red_terracotta
setblock 416 168 316 minecraft:stripped_oak_log
fill 417 168 276 417 171 276 minecraft:red_terracotta
setblock 417 168 280 minecraft:stripped_oak_log
fill 417 168 281 417 171 281 minecraft:red_terracotta
setblock 417 168 285 minecraft:stripped_oak_log
fill 417 168 286 417 171 286 minecraft:red_terracotta
setblock 417 168 290 minecraft:stripped_oak_log
fill 417 168 291 417 169 291 minecraft:red_terracotta
setblock 417 168 295 minecraft:stripped_oak_log
fill 417 168 296 417 170 296 minecraft:red_terracotta
setblock 417 168 300 minecraft:stripped_oak_log
fill 417 168 301 417 170 301 minecraft:red_terracotta
setblock 417 168 315 minecraft:stripped_oak_log
fill 417 168 316 417 169 316 minecraft:red_terracotta
fill 418 168 276 418 171 316 minecraft:orange_terracotta
fill 377 169 276 379 169 276 minecraft:red_terracotta
setblock 377 169 279 minecraft:stripped_oak_log
fill 377 169 280 377 172 280 minecraft:red_terracotta
setblock 377 169 284 minecraft:stripped_oak_log
setblock 377 169 299 minecraft:stripped_oak_log
fill 377 169 300 377 170 300 minecraft:red_terracotta
setblock 377 169 304 minecraft:stripped_oak_log
setblock 377 169 314 minecraft:stripped_oak_log
fill 377 169 315 377 170 316 minecraft:red_terracotta
setblock 378 169 278 minecraft:stripped_oak_log
fill 378 169 279 378 171 279 minecraft:red_terracotta
fill 378 169 316 379 169 316 minecraft:red_terracotta
setblock 379 169 277 minecraft:stripped_oak_log
setblock 380 169 276 minecraft:stripped_oak_log
fill 380 169 277 382 169 277 minecraft:red_terracotta
setblock 380 169 316 minecraft:stripped_oak_log
fill 381 169 276 381 171 276 minecraft:red_terracotta
fill 381 169 316 384 169 316 minecraft:red_terracotta
setblock 384 169 277 minecraft:stripped_oak_log
setblock 385 169 276 minecraft:stripped_oak_log
setblock 385 169 277 minecraft:red_terracotta
fill 385 169 299 385 169 300 minecraft:shroomlight
setblock 385 169 316 minecraft:stripped_oak_log
fill 386 169 276 386 172 276 minecraft:red_terracotta
setblock 386 169 315 minecraft:stripped_oak_log
fill 386 169 316 386 172 316 minecraft:red_terracotta
fill 387 169 315 387 170 315 minecraft:red_terracotta
setblock 389 169 277 minecraft:stripped_oak_log
setblock 390 169 276 minecraft:stripped_oak_log
fill 390 169 277 390 172 277 minecraft:red_terracotta
setblock 390 169 316 minecraft:stripped_oak_log
fill 391 169 276 391 172 276 minecraft:red_terracotta
setblock 391 169 315 minecraft:stripped_oak_log
fill 391 169 316 391 172 316 minecraft:red_terracotta
fill 392 169 275 394 171 275 minecraft:orange_terracotta
fill 392 169 315 392 170 315 minecraft:red_terracotta
setblock 394 169 277 minecraft:stripped_oak_log
setblock 395 169 276 minecraft:stripped_oak_log
setblock 395 169 277 minecraft:red_terracotta
setblock 395 169 316 minecraft:stripped_oak_log
fill 396 169 276 396 170 276 minecraft:red_terracotta
setblock 396 169 316 minecraft:red_terracotta
setblock 405 169 276 minecraft:stripped_oak_log
fill 405 169 288 413 169 288 minecraft:orange_terracotta
fill 406 169 276 406 172 276 minecraft:red_terracotta
setblock 409 169 277 minecraft:stripped_oak_log
fill 409 169 278 409 172 278 minecraft:red_terracotta
setblock 410 169 276 minecraft:stripped_oak_log
fill 410 169 277 410 172 277 minecraft:red_terracotta
setblock 410 169 316 minecraft:stripped_oak_log
fill 411 169 276 411 172 276 minecraft:red_terracotta
fill 411 169 316 411 171 316 minecraft:red_terracotta
setblock 412 169 278 minecraft:red_terracotta
setblock 412 169 279 minecraft:stripped_oak_log
setblock 413 169 278 minecraft:stripped_oak_log
fill 413 169 279 413 171 279 minecraft:red_terracotta
setblock 414 169 277 minecraft:stripped_oak_log
fill 414 169 278 414 172 278 minecraft:red_terracotta
setblock 414 169 281 minecraft:red_terracotta
fill 414 169 287 416 169 287 minecraft:orange_terracotta
setblock 415 169 276 minecraft:stripped_oak_log
fill 415 169 277 415 172 277 minecraft:red_terracotta
setblock 415 169 281 minecraft:stripped_oak_log
fill 415 169 282 415 172 282 minecraft:red_terracotta
setblock 415 169 316 minecraft:stripped_oak_log
fill 416 169 276 416 172 276 minecraft:red_terracotta
setblock 416 169 280 minecraft:stripped_oak_log
fill 416 169 281 416 172 281 minecraft:red_terracotta
setblock 416 169 285 minecraft:stripped_oak_log
setblock 416 169 286 minecraft:red_terracotta
setblock 416 169 295 minecraft:stripped_oak_log
setblock 416 169 296 minecraft:red_terracotta
setblock 416 169 300 minecraft:stripped_oak_log
setblock 416 169 301 minecraft:red_terracotta
fill 416 169 316 416 170 316 minecraft:red_terracotta
setblock 417 169 279 minecraft:stripped_oak_log
fill 417 169 280 417 172 280 minecraft:red_terracotta
setblock 417 169 284 minecraft:stripped_oak_log
fill 417 169 285 417 172 285 minecraft:red_terracotta
setblock 417 169 289 minecraft:stripped_oak_log
setblock 417 169 290 minecraft:red_terracotta
setblock 417 169 294 minecraft:stripped_oak_log
setblock 417 169 295 minecraft:red_terracotta
setblock 417 169 299 minecraft:stripped_oak_log
fill 417 169 300 417 170 300 minecraft:red_terracotta
setblock 417 169 303 minecraft:red_terracotta
fill 377 170 276 378 170 276 minecraft:red_terracotta
setblock 377 170 278 minecraft:stripped_oak_log
fill 377 170 279 377 173 279 minecraft:red_terracotta
setblock 377 170 283 minecraft:stripped_oak_log
setblock 377 170 284 minecraft:red_terracotta
setblock 377 170 299 minecraft:red_terracotta
setblock 377 170 303 minecraft:stripped_oak_log
setblock 378 170 277 minecraft:stripped_oak_log
fill 378 170 278 378 171 278 minecraft:red_terracotta
setblock 378 170 316 minecraft:red_terracotta
setblock 379 170 276 minecraft:stripped_oak_log
setblock 379 170 277 minecraft:red_terracotta
setblock 379 170 316 minecraft:stripped_oak_log
fill 380 170 276 380 171 276 minecraft:red_terracotta
fill 380 170 316 383 170 316 minecraft:red_terracotta
setblock 384 170 276 minecraft:stripped_oak_log
setblock 384 170 316 minecraft:stripped_oak_log
fill 385 170 276 385 173 276 minecraft:red_terracotta
fill 385 170 299 386 170 299 minecraft:shroomlight
fill 385 170 316 385 173 316 minecraft:red_terracotta
setblock 388 170 277 minecraft:stripped_oak_log
setblock 389 170 276 minecraft:stripped_oak_log
fill 389 170 277 389 172 277 minecraft:red_terracotta
setblock 389 170 316 minecraft:stripped_oak_log
fill 390 170 276 390 173 276 minecraft:red_terracotta
setblock 390 170 315 minecraft:stripped_oak_log
fill 390 170 316 390 173 316 minecraft:red_terracotta
fill 391 170 315 391 171 315 minecraft:red_terracotta
setblock 393 170 277 minecraft:stripped_oak_log
setblock 394 170 276 minecraft:stripped_oak_log
setblock 394 170 277 minecraft:red_terracotta
setblock 394 170 316 minecraft:stripped_oak_log
setblock 395 170 276 minecraft:red_terracotta
setblock 395 170 316 minecraft:red_terracotta
setblock 405 170 276 minecraft:red_terracotta
setblock 408 170 277 minecraft:stripped_oak_log
fill 408 170 278 408 173 278 minecraft:red_terracotta
setblock 409 170 276 minecraft:stripped_oak_log
fill 409 170 277 409 173 277 minecraft:red_terracotta
fill 410 170 276 410 173 276 minecraft:red_terracotta
setblock 410 170 316 minecraft:red_terracotta
setblock 411 170 278 minecraft:red_terracotta
setblock 411 170 279 minecraft:stripped_oak_log
setblock 412 170 278 minecraft:stripped_oak_log
fill 412 170 279 412 171 279 minecraft:red_terracotta
setblock 413 170 277 minecraft:stripped_oak_log
fill 413 170 278 413 173 278 minecraft:red_terracotta
setblock 414 170 276 minecraft:stripped_oak_log
fill 414 170 277 414 173 277 minecraft:red_terracotta
setblock 414 170 281 minecraft:stripped_oak_log
setblock 414 170 316 minecraft:stripped_oak_log
fill 415 170 276 415 173 276 minecraft:red_terracotta
setblock 415 170 280 minecraft:stripped_oak_log
fill 415 170 281 415 173 281 minecraft:red_terracotta
setblock 415 170 316 minecraft:red_terracotta
setblock 416 170 279 minecraft:stripped_oak_log
fill 416 170 280 416 173 280 minecraft:red_terracotta
setblock 416 170 284 minecraft:stripped_oak_log
fill 416 170 285 416 171 285 minecraft:red_terracotta
setblock 417 170 278 minecraft:stripped_oak_log
fill 417 170 279 417 173 279 minecraft:red_terracotta
setblock 417 170 283 minecraft:stripped_oak_log
fill 417 170 284 417 173 284 minecraft:red_terracotta
setblock 417 170 298 minecraft:stripped_oak_log
setblock 417 170 299 minecraft:red_terracotta
setblock 377 171 276 minecraft:red_terracotta
setblock 377 171 277 minecraft:stripped_oak_log
fill 377 171 278 377 174 278 minecraft:red_terracotta
setblock 377 171 282 minecraft:stripped_oak_log
fill 377 171 283 377 174 283 minecraft:red_terracotta
setblock 377 171 316 minecraft:red_terracotta
setblock 378 171 276 minecraft:stripped_oak_log
setblock 378 171 277 minecraft:red_terracotta
setblock 378 171 316 minecraft:stripped_oak_log
fill 379 171 276 379 172 276 minecraft:red_terracotta
setblock 383 171 276 minecraft:stripped_oak_log
setblock 383 171 316 minecraft:stripped_oak_log
fill 384 171 276 384 173 276 minecraft:red_terracotta
fill 384 171 316 384 174 316 minecraft:red_terracotta
setblock 385 171 299 minecraft:shroomlight
setblock 387 171 277 minecraft:stripped_oak_log
setblock 388 171 276 minecraft:stripped_oak_log
setblock 388 171 277 minecraft:red_terracotta
setblock 388 171 316 minecraft:stripped_oak_log
fill 389 171 276 389 174 276 minecraft:red_terracotta
setblock 389 171 315 minecraft:stripped_oak_log
fill 389 171 316 389 174 316 minecraft:red_terracotta
setblock 390 171 315 minecraft:red_terracotta
setblock 392 171 277 minecraft:stripped_oak_log
setblock 393 171 276 minecraft:stripped_oak_log
setblock 393 171 316 minecraft:stripped_oak_log
setblock 394 171 276 minecraft:red_terracotta
setblock 394 171 316 minecraft:red_terracotta
setblock 407 171 277 minecraft:stripped_oak_log
setblock 408 171 276 minecraft:stripped_oak_log
fill 408 171 277 408 174 277 minecraft:red_terracotta
fill 409 171 276 409 174 276 minecraft:red_terracotta
setblock 411 171 278 minecraft:stripped_oak_log
setblock 411 171 279 minecraft:red_terracotta
setblock 412 171 277 minecraft:stripped_oak_log
fill 412 171 278 412 174 278 minecraft:red_terracotta
setblock 413 171 276 minecraft:stripped_oak_log
fill 413 171 277 413 174 277 minecraft:red_terracotta
setblock 413 171 316 minecraft:stripped_oak_log
fill 414 171 276 414 174 276 minecraft:red_terracotta
setblock 415 171 279 minecraft:stripped_oak_log
fill 415 171 280 415 174 280 minecraft:red_terracotta
setblock 416 171 278 minecraft:stripped_oak_log
fill 416 171 279 416 174 279 minecraft:red_terracotta
setblock 416 171 283 minecraft:stripped_oak_log
fill 416 171 284 416 174 284 minecraft:red_terracotta
setblock 417 171 277 minecraft:stripped_oak_log
fill 417 171 278 417 174 278 minecraft:red_terracotta
setblock 417 171 282 minecraft:stripped_oak_log
fill 417 171 283 417 174 283 minecraft:red_terracotta
fill 376 172 275 376 175 317 minecraft:red_terracotta
fill 377 172 275 418 175 275 minecraft:red_terracotta
setblock 377 172 276 minecraft:stripped_oak_log
fill 377 172 277 377 174 277 minecraft:red_terracotta
setblock 377 172 281 minecraft:stripped_oak_log
fill 377 172 282 377 175 282 minecraft:red_terracotta
fill 377 172 317 418 175 317 minecraft:red_terracotta
setblock 378 172 276 minecraft:red_terracotta
setblock 383 172 276 minecraft:red_terracotta
setblock 387 172 276 minecraft:stripped_oak_log
setblock 387 172 316 minecraft:stripped_oak_log
fill 388 172 276 388 175 276 minecraft:red_terracotta
fill 388 172 316 388 175 316 minecraft:red_terracotta
setblock 392 172 276 minecraft:stripped_oak_log
setblock 392 172 316 minecraft:stripped_oak_log
setblock 393 172 276 minecraft:red_terracotta
setblock 393 172 316 minecraft:red_terracotta
setblock 407 172 276 minecraft:stripped_oak_log
fill 407 172 277 407 175 277 minecraft:red_terracotta
fill 408 172 276 408 175 276 minecraft:red_terracotta
setblock 410 172 278 minecraft:stripped_oak_log
setblock 411 172 277 minecraft:stripped_oak_log
fill 411 172 278 411 175 278 minecraft:red_terracotta
setblock 412 172 276 minecraft:stripped_oak_log
fill 412 172 277 412 175 277 minecraft:red_terracotta
fill 413 172 276 413 175 276 minecraft:red_terracotta
setblock 415 172 278 minecraft:stripped_oak_log
fill 415 172 279 415 173 279 minecraft:red_terracotta
setblock 415 172 283 minecraft:stripped_oak_log
setblock 416 172 277 minecraft:stripped_oak_log
fill 416 172 278 416 175 278 minecraft:red_terracotta
setblock 416 172 282 minecraft:stripped_oak_log
fill 416 172 283 416 175 283 minecraft:red_terracotta
setblock 417 172 276 minecraft:stripped_oak_log
fill 417 172 277 418 175 277 minecraft:red_terracotta
setblock 417 172 281 minecraft:stripped_oak_log
fill 417 172 282 418 175 282 minecraft:red_terracotta
setblock 417 172 286 minecraft:stripped_oak_log
fill 418 172 276 418 175 276 minecraft:red_terracotta
fill 418 172 278 418 175 281 minecraft:red_terracotta
fill 418 172 283 418 175 316 minecraft:red_terracotta
setblock 377 173 276 minecraft:red_terracotta
setblock 377 173 280 minecraft:stripped_oak_log
fill 377 173 281 377 176 281 minecraft:red_terracotta
setblock 379 173 278 minecraft:light[level=12]
setblock 379 173 285 minecraft:light[level=12]
setblock 379 173 292 minecraft:light[level=12]
setblock 379 173 299 minecraft:light[level=12]
setblock 379 173 306 minecraft:light[level=12]
setblock 379 173 313 minecraft:light[level=12]
setblock 386 173 276 minecraft:stripped_oak_log
setblock 386 173 278 minecraft:light[level=12]
setblock 386 173 285 minecraft:light[level=12]
setblock 386 173 292 minecraft:light[level=12]
setblock 386 173 299 minecraft:light[level=12]
setblock 386 173 306 minecraft:light[level=12]
setblock 386 173 313 minecraft:light[level=12]
setblock 386 173 316 minecraft:stripped_oak_log
fill 387 173 276 387 176 276 minecraft:red_terracotta
fill 387 173 316 387 176 316 minecraft:red_terracotta
setblock 391 173 276 minecraft:stripped_oak_log
setblock 391 173 316 minecraft:stripped_oak_log
setblock 392 173 276 minecraft:red_terracotta
setblock 392 173 316 minecraft:red_terracotta
setblock 393 173 278 minecraft:light[level=12]
setblock 393 173 285 minecraft:light[level=12]
setblock 393 173 292 minecraft:light[level=12]
setblock 393 173 299 minecraft:light[level=12]
setblock 393 173 306 minecraft:light[level=12]
setblock 393 173 313 minecraft:light[level=12]
setblock 400 173 278 minecraft:light[level=12]
setblock 400 173 285 minecraft:light[level=12]
setblock 400 173 292 minecraft:light[level=12]
setblock 400 173 299 minecraft:light[level=12]
setblock 400 173 313 minecraft:light[level=12]
setblock 406 173 276 minecraft:stripped_oak_log
fill 407 173 276 407 176 276 minecraft:red_terracotta
setblock 407 173 278 minecraft:light[level=12]
setblock 407 173 285 minecraft:light[level=12]
setblock 407 173 292 minecraft:light[level=12]
setblock 407 173 299 minecraft:light[level=12]
setblock 407 173 306 minecraft:light[level=12]
setblock 407 173 313 minecraft:light[level=12]
setblock 409 173 278 minecraft:stripped_oak_log
setblock 410 173 277 minecraft:stripped_oak_log
fill 410 173 278 410 176 278 minecraft:red_terracotta
setblock 411 173 276 minecraft:stripped_oak_log
fill 411 173 277 411 176 277 minecraft:red_terracotta
fill 412 173 276 412 176 276 minecraft:red_terracotta
setblock 414 173 278 minecraft:stripped_oak_log
setblock 414 173 285 minecraft:light[level=12]
setblock 414 173 292 minecraft:light[level=12]
setblock 414 173 299 minecraft:light[level=12]
setblock 414 173 306 minecraft:light[level=12]
setblock 414 173 313 minecraft:light[level=12]
setblock 415 173 277 minecraft:stripped_oak_log
setblock 415 173 282 minecraft:stripped_oak_log
setblock 416 173 276 minecraft:stripped_oak_log
setblock 416 173 277 minecraft:red_terracotta
setblock 416 173 281 minecraft:stripped_oak_log
fill 416 173 282 416 176 282 minecraft:red_terracotta
fill 417 173 276 417 176 276 minecraft:red_terracotta
setblock 417 173 280 minecraft:stripped_oak_log
fill 417 173 281 417 176 281 minecraft:red_terracotta
setblock 417 173 285 minecraft:stripped_oak_log
fill 417 173 286 417 176 286 minecraft:red_terracotta
setblock 377 174 279 minecraft:stripped_oak_log
fill 377 174 280 377 177 280 minecraft:red_terracotta
setblock 377 174 304 minecraft:stripped_oak_log
fill 377 174 305 377 177 305 minecraft:red_terracotta
setblock 385 174 276 minecraft:stripped_oak_log
setblock 385 174 316 minecraft:stripped_oak_log
fill 386 174 276 386 177 276 minecraft:red_terracotta
fill 386 174 316 386 177 316 minecraft:red_terracotta
setblock 390 174 276 minecraft:stripped_oak_log
setblock 390 174 316 minecraft:stripped_oak_log
setblock 391 174 276 minecraft:red_terracotta
setblock 391 174 316 minecraft:red_terracotta
setblock 405 174 276 minecraft:stripped_oak_log
fill 406 174 276 406 176 277 minecraft:red_terracotta
setblock 408 174 278 minecraft:stripped_oak_log
setblock 409 174 277 minecraft:stripped_oak_log
fill 409 174 278 409 177 278 minecraft:red_terracotta
setblock 410 174 276 minecraft:stripped_oak_log
fill 410 174 277 410 177 277 minecraft:red_terracotta
fill 411 174 276 411 177 276 minecraft:red_terracotta
setblock 413 174 278 minecraft:stripped_oak_log
setblock 414 174 277 minecraft:stripped_oak_log
setblock 415 174 276 minecraft:stripped_oak_log
fill 415 174 277 415 175 277 minecraft:red_terracotta
setblock 415 174 281 minecraft:stripped_oak_log
fill 415 174 282 415 176 282 minecraft:red_terracotta
fill 416 174 276 416 177 276 minecraft:red_terracotta
setblock 416 174 280 minecraft:stripped_oak_log
fill 416 174 281 416 177 281 minecraft:red_terracotta
setblock 417 174 279 minecraft:stripped_oak_log
fill 417 174 280 417 177 280 minecraft:red_terracotta
setblock 417 174 284 minecraft:stripped_oak_log
fill 417 174 285 417 177 285 minecraft:red_terracotta
setblock 377 175 278 minecraft:stripped_oak_log
fill 377 175 279 377 177 279 minecraft:red_terracotta
setblock 377 175 283 minecraft:stripped_oak_log
setblock 377 175 303 minecraft:stripped_oak_log
fill 377 175 304 377 178 304 minecraft:red_terracotta
fill 377 175 306 377 175 307 minecraft:red_terracotta
setblock 377 175 308 minecraft:stripped_oak_log
setblock 379 175 278 minecraft:light[level=15]
setblock 379 175 286 minecraft:light[level=15]
setblock 379 175 294 minecraft:light[level=15]
setblock 379 175 302 minecraft:light[level=15]
setblock 383 175 316 minecraft:red_terracotta
setblock 384 175 276 minecraft:stripped_oak_log
setblock 384 175 316 minecraft:stripped_oak_log
fill 385 175 276 385 178 276 minecraft:red_terracotta
fill 385 175 316 385 178 316 minecraft:red_terracotta
setblock 387 175 278 minecraft:light[level=15]
setblock 387 175 294 minecraft:light[level=15]
setblock 387 175 302 minecraft:light[level=15]
setblock 387 175 310 minecraft:light[level=15]
setblock 389 175 276 minecraft:stripped_oak_log
setblock 389 175 316 minecraft:stripped_oak_log
setblock 390 175 276 minecraft:red_terracotta
fill 390 175 316 390 178 316 minecraft:red_terracotta
setblock 395 175 278 minecraft:light[level=15]
setblock 395 175 286 minecraft:light[level=15]
setblock 395 175 294 minecraft:light[level=15]
setblock 395 175 302 minecraft:light[level=15]
setblock 395 175 310 minecraft:light[level=15]
fill 397 175 314 399 175 316 minecraft:terracotta
setblock 403 175 278 minecraft:light[level=15]
setblock 403 175 286 minecraft:light[level=15]
setblock 403 175 294 minecraft:light[level=15]
setblock 403 175 302 minecraft:light[level=15]
setblock 403 175 310 minecraft:light[level=15]
fill 405 175 276 405 178 276 minecraft:red_terracotta
setblock 407 175 278 minecraft:stripped_oak_log
setblock 408 175 277 minecraft:stripped_oak_log
fill 408 175 278 408 178 278 minecraft:red_terracotta
setblock 409 175 276 minecraft:stripped_oak_log
fill 409 175 277 409 178 277 minecraft:red_terracotta
fill 410 175 276 410 178 276 minecraft:red_terracotta
setblock 411 175 286 minecraft:light[level=15]
setblock 411 175 294 minecraft:light[level=15]
setblock 411 175 302 minecraft:light[level=15]
setblock 411 175 310 minecraft:light[level=15]
setblock 412 175 278 minecraft:stripped_oak_log
setblock 413 175 277 minecraft:stripped_oak_log
setblock 414 175 276 minecraft:stripped_oak_log
fill 414 175 277 414 177 277 minecraft:red_terracotta
fill 415 175 276 415 178 276 minecraft:red_terracotta
setblock 415 175 281 minecraft:red_terracotta
setblock 416 175 279 minecraft:stripped_oak_log
fill 416 175 280 416 178 280 minecraft:red_terracotta
setblock 416 175 284 minecraft:stripped_oak_log
fill 416 175 285 416 178 285 minecraft:red_terracotta
setblock 417 175 278 minecraft:stripped_oak_log
fill 417 175 279 417 178 279 minecraft:red_terracotta
setblock 417 175 283 minecraft:stripped_oak_log
fill 417 175 284 417 178 284 minecraft:red_terracotta
fill 376 176 275 376 179 317 minecraft:yellow_terracotta
fill 377 176 275 418 179 275 minecraft:yellow_terracotta
setblock 377 176 282 minecraft:stripped_oak_log
fill 377 176 283 377 178 284 minecraft:red_terracotta
fill 377 176 303 377 179 303 minecraft:red_terracotta
setblock 377 176 306 minecraft:red_terracotta
setblock 377 176 307 minecraft:stripped_oak_log
fill 377 176 308 377 177 310 minecraft:red_terracotta
fill 377 176 317 418 179 317 minecraft:yellow_terracotta
setblock 382 176 316 minecraft:red_terracotta
setblock 383 176 316 minecraft:stripped_oak_log
fill 384 176 276 384 179 276 minecraft:red_terracotta
fill 384 176 316 384 179 316 minecraft:red_terracotta
fill 387 176 315 387 177 315 minecraft:red_terracotta
setblock 388 176 276 minecraft:stripped_oak_log
setblock 388 176 316 minecraft:stripped_oak_log
fill 389 176 276 389 177 276 minecraft:red_terracotta
fill 389 176 316 389 179 316 minecraft:red_terracotta
fill 398 176 315 398 182 315 minecraft:green_concrete
fill 404 176 276 404 179 276 minecraft:red_terracotta
fill 405 176 277 405 177 277 minecraft:red_terracotta
setblock 407 176 277 minecraft:stripped_oak_log
fill 407 176 278 407 179 278 minecraft:red_terracotta
setblock 408 176 276 minecraft:stripped_oak_log
fill 408 176 277 408 179 277 minecraft:red_terracotta
fill 409 176 276 409 179 276 minecraft:red_terracotta
setblock 411 176 278 minecraft:stripped_oak_log
setblock 412 176 277 minecraft:stripped_oak_log
setblock 412 176 278 minecraft:red_terracotta
setblock 413 176 276 minecraft:stripped_oak_log
fill 413 176 277 413 178 277 minecraft:red_terracotta
fill 414 176 276 414 179 276 minecraft:red_terracotta
fill 416 176 279 416 177 279 minecraft:red_terracotta
setblock 416 176 283 minecraft:stripped_oak_log
fill 416 176 284 416 179 284 minecraft:red_terracotta
setblock 417 176 277 minecraft:stripped_oak_log
fill 417 176 278 417 179 278 minecraft:red_terracotta
setblock 417 176 282 minecraft:stripped_oak_log
fill 417 176 283 417 179 283 minecraft:red_terracotta
setblock 417 176 287 minecraft:stripped_oak_log
fill 418 176 276 418 179 316 minecraft:yellow_terracotta
setblock 377 177 281 minecraft:stripped_oak_log
fill 377 177 282 377 180 282 minecraft:red_terracotta
fill 377 177 302 377 180 302 minecraft:red_terracotta
setblock 377 177 306 minecraft:stripped_oak_log
fill 377 177 307 378 179 307 minecraft:red_terracotta
setblock 377 177 311 minecraft:stripped_oak_log
fill 377 177 312 377 179 313 minecraft:red_terracotta
setblock 378 177 305 minecraft:stripped_oak_log
fill 378 177 306 378 180 306 minecraft:red_terracotta
fill 378 177 308 378 177 309 minecraft:red_terracotta
fill 379 177 308 382 178 309 minecraft:stripped_oak_log
setblock 381 177 316 minecraft:red_terracotta
setblock 382 177 316 minecraft:stripped_oak_log
fill 383 177 276 383 180 276 minecraft:red_terracotta
fill 383 177 316 383 180 316 minecraft:red_terracotta
fill 384 177 315 386 178 315 minecraft:red_terracotta
setblock 387 177 276 minecraft:stripped_oak_log
setblock 387 177 316 minecraft:stripped_oak_log
fill 388 177 276 388 179 276 minecraft:red_terracotta
setblock 388 177 315 minecraft:stripped_oak_log
fill 388 177 316 388 180 316 minecraft:red_terracotta
fill 403 177 276 403 180 276 minecraft:red_terracotta
setblock 406 177 276 minecraft:red_terracotta
setblock 406 177 277 minecraft:stripped_oak_log
fill 406 177 278 406 180 278 minecraft:red_terracotta
setblock 407 177 276 minecraft:stripped_oak_log
fill 407 177 277 407 180 277 minecraft:red_terracotta
fill 408 177 276 408 180 276 minecraft:red_terracotta
fill 408 177 316 410 178 316 minecraft:red_terracotta
setblock 410 177 278 minecraft:stripped_oak_log
setblock 411 177 277 minecraft:stripped_oak_log
fill 411 177 278 411 178 278 minecraft:red_terracotta
setblock 412 177 276 minecraft:stripped_oak_log
fill 412 177 277 412 179 277 minecraft:red_terracotta
fill 413 177 276 413 180 276 minecraft:red_terracotta
setblock 416 177 282 minecraft:stripped_oak_log
fill 416 177 283 416 180 283 minecraft:red_terracotta
setblock 416 177 286 minecraft:red_terracotta
setblock 417 177 276 minecraft:stripped_oak_log
fill 417 177 277 417 180 277 minecraft:red_terracotta
setblock 417 177 281 minecraft:stripped_oak_log
fill 417 177 282 417 180 282 minecraft:red_terracotta
setblock 417 177 286 minecraft:stripped_oak_log
fill 417 177 287 417 179 288 minecraft:red_terracotta
setblock 377 178 280 minecraft:stripped_oak_log
fill 377 178 281 377 179 281 minecraft:red_terracotta
setblock 377 178 285 minecraft:stripped_oak_log
setblock 377 178 305 minecraft:stripped_oak_log
fill 377 178 306 377 181 306 minecraft:red_terracotta
fill 377 178 308 377 178 309 minecraft:red_terracotta
setblock 377 178 310 minecraft:stripped_oak_log
fill 377 178 311 378 180 311 minecraft:red_terracotta
setblock 377 178 314 minecraft:red_terracotta
setblock 377 178 315 minecraft:stripped_oak_log
setblock 378 178 304 minecraft:stripped_oak_log
fill 378 178 305 378 181 305 minecraft:red_terracotta
setblock 378 178 308 minecraft:red_terracotta
setblock 378 178 309 minecraft:stripped_oak_log
fill 378 178 310 378 181 310 minecraft:red_terracotta
fill 379 178 316 380 178 316 minecraft:red_terracotta
setblock 381 178 316 minecraft:stripped_oak_log
setblock 382 178 315 minecraft:stripped_oak_log
fill 382 178 316 382 181 316 minecraft:red_terracotta
fill 383 178 315 383 181 315 minecraft:red_terracotta
setblock 386 178 276 minecraft:stripped_oak_log
setblock 386 178 316 minecraft:stripped_oak_log
fill 387 178 276 387 180 276 minecraft:red_terracotta
setblock 387 178 315 minecraft:stripped_oak_log
fill 387 178 316 387 181 316 minecraft:red_terracotta
fill 388 178 315 388 181 315 minecraft:red_terracotta
setblock 404 178 277 minecraft:red_terracotta
setblock 405 178 277 minecraft:stripped_oak_log
setblock 406 178 276 minecraft:stripped_oak_log
fill 406 178 277 406 181 277 minecraft:red_terracotta
setblock 406 178 316 minecraft:stripped_oak_log
fill 407 178 276 407 181 276 minecraft:red_terracotta
fill 407 178 316 407 181 316 minecraft:red_terracotta
setblock 409 178 278 minecraft:stripped_oak_log
setblock 410 178 277 minecraft:stripped_oak_log
fill 410 178 278 410 179 278 minecraft:red_terracotta
setblock 411 178 276 minecraft:stripped_oak_log
fill 411 178 277 411 180 277 minecraft:red_terracotta
setblock 411 178 316 minecraft:stripped_oak_log
fill 412 178 276 412 181 276 minecraft:red_terracotta
setblock 416 178 276 minecraft:stripped_oak_log
setblock 416 178 281 minecraft:stripped_oak_log
fill 416 178 282 416 180 282 minecraft:red_terracotta
setblock 416 178 286 minecraft:stripped_oak_log
fill 417 178 276 417 181 276 minecraft:red_terracotta
setblock 417 178 280 minecraft:stripped_oak_log
fill 417 178 281 417 181 281 minecraft:red_terracotta
setblock 417 178 285 minecraft:stripped_oak_log
fill 417 178 286 417 181 286 minecraft:red_terracotta
setblock 417 178 305 minecraft:stripped_oak_log
fill 417 178 306 417 178 309 minecraft:red_terracotta
setblock 417 178 310 minecraft:stripped_oak_log
setblock 377 179 283 minecraft:red_terracotta
setblock 377 179 284 minecraft:stripped_oak_log
fill 377 179 285 377 181 286 minecraft:red_terracotta
setblock 377 179 304 minecraft:stripped_oak_log
fill 377 179 305 377 182 305 minecraft:red_terracotta
setblock 377 179 308 minecraft:red_terracotta
setblock 377 179 309 minecraft:stripped_oak_log
fill 377 179 310 377 182 310 minecraft:red_terracotta
setblock 377 179 314 minecraft:stripped_oak_log
fill 377 179 315 377 181 316 minecraft:red_terracotta
fill 378 179 304 378 182 304 minecraft:red_terracotta
setblock 378 179 308 minecraft:stripped_oak_log
fill 378 179 309 379 181 309 minecraft:red_terracotta
setblock 378 179 312 minecraft:red_terracotta
setblock 378 179 313 minecraft:stripped_oak_log
fill 378 179 316 379 179 316 minecraft:red_terracotta
setblock 379 179 278 minecraft:light[level=12]
setblock 379 179 285 minecraft:light[level=12]
setblock 379 179 292 minecraft:light[level=12]
setblock 379 179 299 minecraft:light[level=12]
setblock 379 179 306 minecraft:red_terracotta
fill 379 179 308 379 182 308 minecraft:red_terracotta
fill 379 179 310 379 180 310 minecraft:red_terracotta
fill 379 179 311 381 180 311 minecraft:stripped_oak_log
setblock 379 179 313 minecraft:light[level=12]
fill 380 179 308 381 179 310 minecraft:stripped_oak_log
setblock 380 179 316 minecraft:stripped_oak_log
setblock 381 179 315 minecraft:stripped_oak_log
fill 381 179 316 381 182 316 minecraft:red_terracotta
fill 382 179 276 382 181 276 minecraft:red_terracotta
fill 382 179 308 382 208 309 minecraft:stripped_oak_log
fill 382 179 315 382 182 315 minecraft:red_terracotta
fill 384 179 314 385 179 315 minecraft:red_terracotta
setblock 385 179 276 minecraft:stripped_oak_log
setblock 385 179 316 minecraft:stripped_oak_log
fill 386 179 276 386 181 276 minecraft:red_terracotta
setblock 386 179 278 minecraft:light[level=12]
setblock 386 179 285 minecraft:light[level=12]
setblock 386 179 292 minecraft:light[level=12]
setblock 386 179 299 minecraft:light[level=12]
setblock 386 179 306 minecraft:light[level=12]
setblock 386 179 313 minecraft:light[level=12]
setblock 386 179 314 minecraft:red_terracotta
setblock 386 179 315 minecraft:stripped_oak_log
fill 386 179 316 386 182 316 minecraft:red_terracotta
fill 387 179 315 387 182 315 minecraft:red_terracotta
setblock 390 179 316 minecraft:stripped_oak_log
setblock 393 179 278 minecraft:light[level=12]
setblock 393 179 285 minecraft:light[level=12]
setblock 393 179 292 minecraft:light[level=12]
setblock 393 179 299 minecraft:light[level=12]
setblock 393 179 306 minecraft:light[level=12]
setblock 393 179 313 minecraft:light[level=12]
fill 399 179 315 399 181 315 minecraft:green_concrete
setblock 400 179 278 minecraft:light[level=12]
setblock 400 179 285 minecraft:light[level=12]
setblock 400 179 292 minecraft:light[level=12]
setblock 400 179 299 minecraft:light[level=12]
setblock 400 179 313 minecraft:light[level=12]
fill 402 179 276 402 181 276 minecraft:red_terracotta
setblock 404 179 277 minecraft:stripped_oak_log
setblock 405 179 276 minecraft:stripped_oak_log
fill 405 179 277 405 180 278 minecraft:red_terracotta
setblock 405 179 316 minecraft:stripped_oak_log
fill 406 179 276 406 182 276 minecraft:red_terracotta
fill 406 179 316 406 182 316 minecraft:red_terracotta
setblock 407 179 285 minecraft:light[level=12]
setblock 407 179 292 minecraft:light[level=12]
setblock 407 179 299 minecraft:light[level=12]
setblock 407 179 306 minecraft:light[level=12]
setblock 407 179 313 minecraft:light[level=12]
setblock 408 179 278 minecraft:stripped_oak_log
fill 408 179 316 409 179 316 minecraft:red_terracotta
setblock 409 179 277 minecraft:stripped_oak_log
fill 409 179 278 409 180 278 minecraft:red_terracotta
setblock 410 179 276 minecraft:stripped_oak_log
fill 410 179 277 410 181 277 minecraft:red_terracotta
setblock 410 179 316 minecraft:stripped_oak_log
fill 411 179 276 411 182 276 minecraft:red_terracotta
fill 411 179 316 412 181 316 minecraft:red_terracotta
setblock 414 179 278 minecraft:light[level=12]
setblock 414 179 285 minecraft:light[level=12]
setblock 414 179 292 minecraft:light[level=12]
setblock 414 179 299 minecraft:light[level=12]
setblock 414 179 306 minecraft:light[level=12]
setblock 414 179 313 minecraft:light[level=12]
setblock 415 179 276 minecraft:stripped_oak_log
fill 416 179 276 416 180 276 minecraft:red_terracotta
setblock 416 179 280 minecraft:stripped_oak_log
fill 416 179 281 416 180 281 minecraft:red_terracotta
setblock 416 179 285 minecraft:stripped_oak_log
fill 416 179 286 416 180 287 minecraft:red_terracotta
setblock 417 179 279 minecraft:stripped_oak_log
fill 417 179 280 417 182 280 minecraft:red_terracotta
setblock 417 179 284 minecraft:stripped_oak_log
fill 417 179 285 417 182 285 minecraft:red_terracotta
setblock 417 179 289 minecraft:stripped_oak_log
fill 417 179 305 417 179 308 minecraft:red_terracotta
setblock 417 179 309 minecraft:stripped_oak_log
fill 417 179 310 417 179 313 minecraft:red_terracotta
fill 376 180 275 376 183 317 minecraft:white_terracotta
fill 377 180 275 418 183 275 minecraft:white_terracotta
setblock 377 180 283 minecraft:stripped_oak_log
fill 377 180 284 377 181 284 minecraft:red_terracotta
setblock 377 180 287 minecraft:red_terracotta
setblock 377 180 303 minecraft:stripped_oak_log
fill 377 180 304 377 183 304 minecraft:red_terracotta
setblock 377 180 307 minecraft:red_terracotta
setblock 377 180 308 minecraft:stripped_oak_log
fill 377 180 309 377 183 309 minecraft:red_terracotta
setblock 377 180 312 minecraft:red_terracotta
setblock 377 180 313 minecraft:stripped_oak_log
fill 377 180 314 378 182 314 minecraft:red_terracotta
fill 377 180 317 418 183 317 minecraft:white_terracotta
setblock 378 180 307 minecraft:stripped_oak_log
fill 378 180 308 378 183 308 minecraft:red_terracotta
setblock 378 180 312 minecraft:stripped_oak_log
fill 378 180 313 378 183 313 minecraft:red_terracotta
setblock 378 180 316 minecraft:red_terracotta
setblock 379 180 305 minecraft:red_terracotta
setblock 379 180 306 minecraft:stripped_oak_log
fill 379 180 307 379 183 307 minecraft:red_terracotta
setblock 379 180 316 minecraft:stripped_oak_log
fill 380 180 307 381 180 307 minecraft:stripped_oak_log
fill 380 180 308 380 181 308 minecraft:red_terracotta
fill 380 180 309 381 180 310 minecraft:stripped_oak_log
setblock 380 180 315 minecraft:stripped_oak_log
fill 380 180 316 380 183 316 minecraft:red_terracotta
fill 381 180 308 381 208 308 minecraft:stripped_oak_log
fill 381 180 315 381 183 315 minecraft:red_terracotta
fill 382 180 314 385 180 314 minecraft:red_terracotta
setblock 384 180 276 minecraft:stripped_oak_log
setblock 384 180 315 minecraft:red_terracotta
setblock 384 180 316 minecraft:stripped_oak_log
fill 385 180 276 385 182 276 minecraft:red_terracotta
setblock 385 180 315 minecraft:stripped_oak_log
fill 385 180 316 385 183 316 minecraft:red_terracotta
setblock 386 180 314 minecraft:stripped_oak_log
fill 386 180 315 386 183 315 minecraft:red_terracotta
fill 387 180 314 387 181 314 minecraft:red_terracotta
setblock 389 180 316 minecraft:stripped_oak_log
setblock 390 180 316 minecraft:red_terracotta
setblock 403 180 277 minecraft:stripped_oak_log
setblock 404 180 276 minecraft:stripped_oak_log
fill 404 180 277 404 183 277 minecraft:red_terracotta
setblock 404 180 316 minecraft:stripped_oak_log
fill 405 180 276 405 183 276 minecraft:red_terracotta
fill 405 180 316 405 183 316 minecraft:red_terracotta
setblock 407 180 278 minecraft:stripped_oak_log
setblock 408 180 277 minecraft:stripped_oak_log
setblock 408 180 278 minecraft:red_terracotta
setblock 408 180 316 minecraft:red_terracotta
setblock 409 180 276 minecraft:stripped_oak_log
fill 409 180 277 409 182 277 minecraft:red_terracotta
setblock 409 180 316 minecraft:stripped_oak_log
fill 410 180 276 410 183 276 minecraft:red_terracotta
fill 410 180 316 410 183 316 minecraft:red_terracotta
setblock 414 180 276 minecraft:stripped_oak_log
fill 415 180 276 415 181 276 minecraft:red_terracotta
setblock 416 180 284 minecraft:stripped_oak_log
fill 416 180 285 416 181 285 minecraft:red_terracotta
setblock 417 180 278 minecraft:stripped_oak_log
fill 417 180 279 417 181 279 minecraft:red_terracotta
setblock 417 180 283 minecraft:stripped_oak_log
fill 417 180 284 417 183 284 minecraft:red_terracotta
setblock 417 180 287 minecraft:red_terracotta
setblock 417 180 288 minecraft:stripped_oak_log
fill 417 180 289 417 183 289 minecraft:red_terracotta
fill 417 180 305 417 180 307 minecraft:red_terracotta
setblock 417 180 308 minecraft:stripped_oak_log
fill 417 180 309 417 180 312 minecraft:red_terracotta
setblock 417 180 313 minecraft:stripped_oak_log
fill 417 180 314 417 182 315 minecraft:red_terracotta
fill 418 180 276 418 183 316 minecraft:white_terracotta
setblock 377 181 287 minecraft:stripped_oak_log
fill 377 181 288 377 184 288 minecraft:red_terracotta
setblock 377 181 302 minecraft:stripped_oak_log
fill 377 181 303 377 183 303 minecraft:red_terracotta
setblock 377 181 307 minecraft:stripped_oak_log
fill 377 181 308 377 184 308 minecraft:red_terracotta
setblock 377 181 311 minecraft:red_terracotta
setblock 377 181 312 minecraft:stripped_oak_log
fill 377 181 313 377 184 313 minecraft:red_terracotta
setblock 378 181 306 minecraft:stripped_oak_log
fill 378 181 307 378 184 307 minecraft:red_terracotta
setblock 378 181 311 minecraft:stripped_oak_log
fill 378 181 312 379 183 312 minecraft:red_terracotta
setblock 378 181 315 minecraft:red_terracotta
setblock 378 181 316 minecraft:stripped_oak_log
setblock 379 181 305 minecraft:stripped_oak_log
fill 379 181 306 379 184 306 minecraft:red_terracotta
setblock 379 181 310 minecraft:stripped_oak_log
fill 379 181 311 379 184 311 minecraft:red_terracotta
setblock 379 181 315 minecraft:stripped_oak_log
fill 379 181 316 379 184 316 minecraft:red_terracotta
fill 380 181 307 380 182 307 minecraft:red_terracotta
fill 380 181 309 381 181 309 minecraft:stripped_oak_log
fill 380 181 310 380 184 310 minecraft:red_terracotta
fill 380 181 311 381 181 311 minecraft:stripped_oak_log
fill 380 181 315 380 184 315 minecraft:red_terracotta
fill 381 181 307 381 208 307 minecraft:stripped_oak_log
fill 381 181 310 381 208 310 minecraft:stripped_oak_log
fill 381 181 314 384 181 314 minecraft:red_terracotta
setblock 383 181 276 minecraft:stripped_oak_log
setblock 383 181 316 minecraft:stripped_oak_log
fill 384 181 276 384 182 276 minecraft:red_terracotta
fill 384 181 313 384 182 313 minecraft:red_terracotta
setblock 384 181 315 minecraft:stripped_oak_log
fill 384 181 316 384 184 316 minecraft:red_terracotta
setblock 385 181 314 minecraft:stripped_oak_log
fill 385 181 315 385 184 315 minecraft:red_terracotta
fill 386 181 314 386 183 314 minecraft:red_terracotta
setblock 388 181 316 minecraft:stripped_oak_log
fill 389 181 316 389 182 316 minecraft:red_terracotta
fill 401 181 276 401 182 276 minecraft:red_terracotta
setblock 403 181 276 minecraft:stripped_oak_log
fill 403 181 277 403 184 277 minecraft:red_terracotta
setblock 403 181 316 minecraft:stripped_oak_log
fill 404 181 276 404 184 276 minecraft:red_terracotta
fill 404 181 316 404 184 316 minecraft:red_terracotta
fill 405 181 277 405 182 277 minecraft:red_terracotta
setblock 406 181 278 minecraft:stripped_oak_log
fill 406 181 315 407 182 315 minecraft:red_terracotta
setblock 407 181 277 minecraft:stripped_oak_log
setblock 407 181 278 minecraft:red_terracotta
setblock 408 181 276 minecraft:stripped_oak_log
fill 408 181 277 408 183 277 minecraft:red_terracotta
setblock 408 181 316 minecraft:stripped_oak_log
fill 409 181 276 409 184 276 minecraft:red_terracotta
fill 409 181 316 409 184 316 minecraft:red_terracotta
setblock 413 181 276 minecraft:stripped_oak_log
setblock 414 181 276 minecraft:red_terracotta
setblock 416 181 283 minecraft:stripped_oak_log
setblock 416 181 284 minecraft:red_terracotta
setblock 416 181 286 minecraft:red_terracotta
fill 416 181 316 417 181 316 minecraft:red_terracotta
setblock 417 181 277 minecraft:stripped_oak_log
setblock 417 181 278 minecraft:red_terracotta
setblock 417 181 282 minecraft:stripped_oak_log
fill 417 181 283 417 183 283 minecraft:red_terracotta
setblock 417 181 287 minecraft:stripped_oak_log
fill 417 181 288 417 184 288 minecraft:red_terracotta
fill 417 181 290 417 182 290 minecraft:red_terracotta
fill 417 181 305 417 181 306 minecraft:red_terracotta
setblock 417 181 307 minecraft:stripped_oak_log
fill 417 181 308 417 181 311 minecraft:red_terracotta
setblock 417 181 312 minecraft:stripped_oak_log
fill 417 181 313 417 184 313 minecraft:red_terracotta
fill 377 182 283 379 182 285 minecraft:terracotta
setblock 377 182 286 minecraft:stripped_oak_log
fill 377 182 287 377 183 287 minecraft:red_terracotta
fill 377 182 289 377 183 289 minecraft:red_terracotta
setblock 377 182 306 minecraft:stripped_oak_log
fill 377 182 307 377 185 307 minecraft:red_terracotta
setblock 377 182 311 minecraft:stripped_oak_log
fill 377 182 312 377 185 312 minecraft:red_terracotta
setblock 377 182 315 minecraft:red_terracotta
setblock 377 182 316 minecraft:stripped_oak_log
setblock 378 182 305 minecraft:stripped_oak_log
fill 378 182 306 378 185 306 minecraft:red_terracotta
setblock 378 182 309 minecraft:red_terracotta
setblock 378 182 310 minecraft:stripped_oak_log
fill 378 182 311 378 185 311 minecraft:red_terracotta
setblock 378 182 315 minecraft:stripped_oak_log
fill 378 182 316 378 185 316 minecraft:red_terracotta
setblock 379 182 305 minecraft:red_terracotta
setblock 379 182 309 minecraft:stripped_oak_log
fill 379 182 310 379 185 310 minecraft:red_terracotta
setblock 379 182 313 minecraft:red_terracotta
fill 379 182 315 379 185 315 minecraft:red_terracotta
setblock 380 182 308 minecraft:stripped_oak_log
fill 380 182 309 380 184 309 minecraft:red_terracotta
fill 380 182 311 380 183 311 minecraft:red_terracotta
fill 380 182 314 383 182 314 minecraft:red_terracotta
fill 381 182 309 381 208 309 minecraft:stripped_oak_log
fill 381 182 311 381 208 311 minecraft:stripped_oak_log
setblock 382 182 316 minecraft:stripped_oak_log
setblock 383 182 276 minecraft:red_terracotta
fill 383 182 313 383 183 313 minecraft:red_terracotta
setblock 383 182 315 minecraft:stripped_oak_log
fill 383 182 316 383 185 316 minecraft:red_terracotta
setblock 384 182 314 minecraft:stripped_oak_log
fill 384 182 315 384 185 315 minecraft:red_terracotta
fill 385 182 314 385 184 314 minecraft:red_terracotta
setblock 387 182 316 minecraft:stripped_oak_log
setblock 388 182 315 minecraft:stripped_oak_log
fill 388 182 316 388 184 316 minecraft:red_terracotta
setblock 402 182 276 minecraft:stripped_oak_log
setblock 402 182 316 minecraft:stripped_oak_log
fill 403 182 276 403 185 276 minecraft:red_terracotta
fill 403 182 316 403 185 316 minecraft:red_terracotta
fill 405 182 315 405 184 315 minecraft:red_terracotta
setblock 406 182 277 minecraft:stripped_oak_log
setblock 407 182 276 minecraft:stripped_oak_log
fill 407 182 277 407 183 277 minecraft:red_terracotta
setblock 407 182 316 minecraft:stripped_oak_log
fill 408 182 276 408 185 276 minecraft:red_terracotta
fill 408 182 316 408 185 316 minecraft:red_terracotta
setblock 411 182 316 minecraft:red_terracotta
setblock 412 182 276 minecraft:stripped_oak_log
setblock 412 182 316 minecraft:stripped_oak_log
setblock 413 182 276 minecraft:red_terracotta
setblock 413 182 316 minecraft:red_terracotta
fill 415 182 316 416 182 316 minecraft:red_terracotta
setblock 417 182 281 minecraft:stripped_oak_log
fill 417 182 282 417 183 282 minecraft:red_terracotta
setblock 417 182 286 minecraft:stripped_oak_log
fill 417 182 287 417 185 287 minecraft:red_terracotta
setblock 417 182 306 minecraft:stripped_oak_log
fill 417 182 307 417 182 310 minecraft:red_terracotta
setblock 417 182 311 minecraft:stripped_oak_log
fill 417 182 312 417 185 312 minecraft:red_terracotta
setblock 417 182 316 minecraft:stripped_oak_log
setblock 377 183 305 minecraft:stripped_oak_log
fill 377 183 306 377 186 306 minecraft:red_terracotta
setblock 377 183 310 minecraft:stripped_oak_log
fill 377 183 311 377 186 311 minecraft:red_terracotta
setblock 377 183 314 minecraft:red_terracotta
setblock 377 183 315 minecraft:stripped_oak_log
fill 377 183 316 377 186 316 minecraft:red_terracotta
fill 378 183 284 378 189 284 minecraft:green_concrete
setblock 378 183 304 minecraft:stripped_oak_log
fill 378 183 305 378 185 305 minecraft:red_terracotta
setblock 378 183 309 minecraft:stripped_oak_log
fill 378 183 310 378 186 310 minecraft:red_terracotta
setblock 378 183 314 minecraft:stripped_oak_log
fill 378 183 315 378 186 315 minecraft:red_terracotta
setblock 379 183 278 minecraft:light[level=15]
setblock 379 183 286 minecraft:light[level=15]
setblock 379 183 294 minecraft:light[level=15]
setblock 379 183 302 minecraft:light[level=15]
setblock 379 183 308 minecraft:stripped_oak_log
fill 379 183 309 379 186 309 minecraft:red_terracotta
setblock 379 183 313 minecraft:stripped_oak_log
fill 379 183 314 382 183 314 minecraft:red_terracotta
fill 380 183 307 380 208 307 minecraft:stripped_oak_log
setblock 380 183 308 minecraft:red_terracotta
setblock 381 183 316 minecraft:stripped_oak_log
setblock 382 183 315 minecraft:stripped_oak_log
fill 382 183 316 382 186 316 minecraft:red_terracotta
setblock 383 183 314 minecraft:stripped_oak_log
fill 383 183 315 383 186 315 minecraft:red_terracotta
fill 384 183 314 384 186 314 minecraft:red_terracotta
setblock 386 183 316 minecraft:stripped_oak_log
setblock 387 183 278 minecraft:light[level=15]
setblock 387 183 294 minecraft:light[level=15]
setblock 387 183 302 minecraft:light[level=15]
setblock 387 183 310 minecraft:light[level=15]
setblock 387 183 315 minecraft:stripped_oak_log
fill 387 183 316 387 186 316 minecraft:red_terracotta
setblock 395 183 278 minecraft:light[level=15]
setblock 395 183 286 minecraft:light[level=15]
setblock 395 183 294 minecraft:light[level=15]
setblock 395 183 302 minecraft:light[level=15]
setblock 395 183 310 minecraft:light[level=15]
setblock 401 183 276 minecraft:stripped_oak_log
setblock 401 183 316 minecraft:stripped_oak_log
fill 402 183 276 402 186 276 minecraft:red_terracotta
fill 402 183 316 402 186 316 minecraft:red_terracotta
setblock 403 183 278 minecraft:light[level=15]
setblock 403 183 286 minecraft:light[level=15]
setblock 403 183 294 minecraft:light[level=15]
setblock 403 183 302 minecraft:light[level=15]
setblock 403 183 310 minecraft:light[level=15]
fill 404 183 315 404 185 315 minecraft:red_terracotta
setblock 405 183 277 minecraft:stripped_oak_log
setblock 406 183 276 minecraft:stripped_oak_log
fill 406 183 277 406 184 277 minecraft:red_terracotta
setblock 406 183 315 minecraft:red_terracotta
setblock 406 183 316 minecraft:stripped_oak_log
fill 407 183 276 407 186 276 minecraft:red_terracotta
setblock 407 183 315 minecraft:stripped_oak_log
fill 407 183 316 407 186 316 minecraft:red_terracotta
setblock 411 183 276 minecraft:stripped_oak_log
setblock 411 183 278 minecraft:light[level=15]
setblock 411 183 286 minecraft:light[level=15]
setblock 411 183 294 minecraft:light[level=15]
setblock 411 183 302 minecraft:light[level=15]
setblock 411 183 310 minecraft:light[level=15]
setblock 411 183 316 minecraft:stripped_oak_log
fill 412 183 316 412 186 316 minecraft:red_terracotta
fill 414 183 314 416 184 314 minecraft:iron_bars
fill 414 183 316 415 183 316 minecraft:red_terracotta
setblock 416 183 311 minecraft:stripped_oak_log
fill 416 183 312 416 186 312 minecraft:red_terracotta
setblock 416 183 316 minecraft:stripped_oak_log
setblock 417 183 285 minecraft:stripped_oak_log
fill 417 183 286 417 184 286 minecraft:red_terracotta
setblock 417 183 290 minecraft:stripped_oak_log
fill 417 183 306 417 183 309 minecraft:red_terracotta
setblock 417 183 310 minecraft:stripped_oak_log
fill 417 183 311 417 186 311 minecraft:red_terracotta
setblock 417 183 314 minecraft:red_terracotta
setblock 417 183 315 minecraft:stripped_oak_log
fill 417 183 316 417 186 316 minecraft:red_terracotta
fill 376 184 275 376 187 317 minecraft:terracotta
fill 377 184 275 418 187 275 minecraft:terracotta
setblock 377 184 289 minecraft:stripped_oak_log
fill 377 184 290 377 187 290 minecraft:red_terracotta
setblock 377 184 304 minecraft:stripped_oak_log
fill 377 184 305 377 187 305 minecraft:red_terracotta
setblock 377 184 309 minecraft:stripped_oak_log
fill 377 184 310 377 187 310 minecraft:red_terracotta
setblock 377 184 314 minecraft:stripped_oak_log
fill 377 184 315 377 187 315 minecraft:red_terracotta
fill 377 184 317 418 187 317 minecraft:terracotta
setblock 378 184 308 minecraft:stripped_oak_log
fill 378 184 309 378 187 309 minecraft:red_terracotta
setblock 378 184 312 minecraft:red_terracotta
setblock 378 184 313 minecraft:stripped_oak_log
fill 378 184 314 381 184 314 minecraft:red_terracotta
setblock 379 184 307 minecraft:stripped_oak_log
fill 379 184 308 379 187 308 minecraft:red_terracotta
setblock 379 184 312 minecraft:stripped_oak_log
fill 379 184 313 379 187 313 minecraft:red_terracotta
fill 380 184 308 380 208 308 minecraft:stripped_oak_log
setblock 380 184 311 minecraft:stripped_oak_log
setblock 380 184 316 minecraft:stripped_oak_log
setblock 381 184 315 minecraft:stripped_oak_log
fill 381 184 316 381 187 316 minecraft:red_terracotta
setblock 382 184 314 minecraft:stripped_oak_log
fill 382 184 315 382 187 315 minecraft:red_terracotta
fill 383 184 314 383 187 314 minecraft:red_terracotta
setblock 385 184 316 minecraft:stripped_oak_log
setblock 386 184 315 minecraft:stripped_oak_log
fill 386 184 316 386 187 316 minecraft:red_terracotta
setblock 387 184 315 minecraft:red_terracotta
fill 401 184 276 401 187 276 minecraft:red_terracotta
fill 401 184 316 401 187 316 minecraft:red_terracotta
fill 403 184 315 403 186 315 minecraft:red_terracotta
setblock 404 184 277 minecraft:stripped_oak_log
setblock 405 184 276 minecraft:stripped_oak_log
fill 405 184 277 405 185 277 minecraft:red_terracotta
setblock 405 184 316 minecraft:stripped_oak_log
fill 406 184 276 406 187 276 minecraft:red_terracotta
setblock 406 184 315 minecraft:stripped_oak_log
fill 406 184 316 406 187 316 minecraft:red_terracotta
setblock 407 184 315 minecraft:red_terracotta
setblock 410 184 276 minecraft:stripped_oak_log
setblock 410 184 316 minecraft:stripped_oak_log
fill 411 184 316 411 187 316 minecraft:red_terracotta
fill 413 184 316 414 184 316 minecraft:red_terracotta
setblock 415 184 316 minecraft:stripped_oak_log
fill 416 184 311 416 187 311 minecraft:red_terracotta
fill 416 184 313 416 185 313 minecraft:red_terracotta
fill 416 184 316 416 187 316 minecraft:red_terracotta
setblock 417 184 285 minecraft:red_terracotta
setblock 417 184 289 minecraft:stripped_oak_log
setblock 417 184 290 minecraft:red_terracotta
fill 417 184 306 417 184 308 minecraft:red_terracotta
setblock 417 184 309 minecraft:stripped_oak_log
fill 417 184 310 417 187 310 minecraft:red_terracotta
setblock 417 184 314 minecraft:stripped_oak_log
fill 417 184 315 417 187 315 minecraft:red_terracotta
fill 418 184 276 418 187 316 minecraft:terracotta
fill 377 185 289 377 188 289 minecraft:red_terracotta
fill 377 185 291 377 186 291 minecraft:red_terracotta
fill 377 185 304 377 188 304 minecraft:red_terracotta
setblock 377 185 308 minecraft:stripped_oak_log
fill 377 185 309 377 188 309 minecraft:red_terracotta
setblock 377 185 313 minecraft:stripped_oak_log
fill 377 185 314 380 185 314 minecraft:red_terracotta
setblock 378 185 307 minecraft:stripped_oak_log
fill 378 185 308 378 188 308 minecraft:red_terracotta
setblock 378 185 312 minecraft:stripped_oak_log
fill 378 185 313 378 188 313 minecraft:red_terracotta
setblock 379 185 278 minecraft:light[level=12]
setblock 379 185 285 minecraft:light[level=12]
setblock 379 185 292 minecraft:light[level=12]
setblock 379 185 299 minecraft:light[level=12]
setblock 379 185 306 minecraft:light[level=12]
setblock 379 185 307 minecraft:red_terracotta
setblock 379 185 311 minecraft:stripped_oak_log
fill 379 185 312 379 188 312 minecraft:red_terracotta
setblock 379 185 316 minecraft:stripped_oak_log
fill 380 185 309 380 208 310 minecraft:stripped_oak_log
setblock 380 185 311 minecraft:red_terracotta
setblock 380 185 315 minecraft:stripped_oak_log
fill 380 185 316 380 188 316 minecraft:red_terracotta
setblock 381 185 314 minecraft:stripped_oak_log
fill 381 185 315 381 188 315 minecraft:red_terracotta
fill 382 185 314 382 188 314 minecraft:red_terracotta
setblock 384 185 316 minecraft:stripped_oak_log
setblock 385 185 315 minecraft:stripped_oak_log
fill 385 185 316 385 188 316 minecraft:red_terracotta
setblock 386 185 278 minecraft:light[level=12]
setblock 386 185 285 minecraft:light[level=12]
setblock 386 185 292 minecraft:light[level=12]
setblock 386 185 299 minecraft:light[level=12]
setblock 386 185 306 minecraft:light[level=12]
setblock 386 185 313 minecraft:light[level=12]
setblock 386 185 315 minecraft:red_terracotta
setblock 393 185 278 minecraft:light[level=12]
setblock 393 185 285 minecraft:light[level=12]
setblock 393 185 292 minecraft:light[level=12]
setblock 393 185 299 minecraft:light[level=12]
setblock 393 185 306 minecraft:light[level=12]
setblock 393 185 313 minecraft:light[level=12]
fill 400 185 276 400 188 276 minecraft:red_terracotta
setblock 400 185 278 minecraft:light[level=12]
setblock 400 185 285 minecraft:light[level=12]
setblock 400 185 292 minecraft:light[level=12]
setblock 400 185 299 minecraft:light[level=12]
setblock 400 185 313 minecraft:light[level=12]
fill 400 185 316 400 188 316 minecraft:red_terracotta
setblock 403 185 277 minecraft:stripped_oak_log
setblock 404 185 276 minecraft:stripped_oak_log
fill 404 185 277 404 188 277 minecraft:red_terracotta
setblock 404 185 316 minecraft:stripped_oak_log
fill 405 185 276 405 188 276 minecraft:red_terracotta
setblock 405 185 315 minecraft:stripped_oak_log
fill 405 185 316 405 188 316 minecraft:red_terracotta
fill 406 185 315 406 188 315 minecraft:red_terracotta
setblock 407 185 278 minecraft:light[level=12]
setblock 407 185 285 minecraft:light[level=12]
setblock 407 185 292 minecraft:light[level=12]
setblock 407 185 299 minecraft:light[level=12]
setblock 407 185 306 minecraft:light[level=12]
setblock 407 185 313 minecraft:light[level=12]
setblock 409 185 276 minecraft:stripped_oak_log
setblock 409 185 316 minecraft:stripped_oak_log
setblock 410 185 276 minecraft:red_terracotta
fill 410 185 316 410 188 316 minecraft:red_terracotta
setblock 413 185 316 minecraft:red_terracotta
setblock 414 185 278 minecraft:light[level=12]
setblock 414 185 285 minecraft:light[level=12]
setblock 414 185 292 minecraft:light[level=12]
setblock 414 185 299 minecraft:light[level=12]
setblock 414 185 306 minecraft:light[level=12]
setblock 414 185 313 minecraft:light[level=12]
setblock 414 185 316 minecraft:stripped_oak_log
fill 415 185 316 415 188 316 minecraft:red_terracotta
setblock 416 185 314 minecraft:stripped_oak_log
setblock 417 185 288 minecraft:stripped_oak_log
setblock 417 185 289 minecraft:red_terracotta
setblock 417 185 307 minecraft:red_terracotta
setblock 417 185 308 minecraft:stripped_oak_log
fill 417 185 309 417 188 309 minecraft:red_terracotta
setblock 417 185 313 minecraft:stripped_oak_log
fill 417 185 314 417 188 314 minecraft:red_terracotta
setblock 377 186 292 minecraft:stripped_oak_log
fill 377 186 293 377 189 293 minecraft:red_terracotta
setblock 377 186 307 minecraft:stripped_oak_log
fill 377 186 308 377 189 308 minecraft:red_terracotta
setblock 377 186 312 minecraft:stripped_oak_log
fill 377 186 313 377 188 314 minecraft:red_terracotta
fill 378 186 285 378 188 285 minecraft:green_concrete
setblock 378 186 306 minecraft:stripped_oak_log
fill 378 186 307 378 189 307 minecraft:red_terracotta
setblock 378 186 311 minecraft:stripped_oak_log
fill 378 186 312 378 189 312 minecraft:red_terracotta
fill 378 186 314 379 186 314 minecraft:red_terracotta
setblock 378 186 316 minecraft:stripped_oak_log
fill 379 186 307 379 192 307 minecraft:stripped_oak_log
setblock 379 186 310 minecraft:stripped_oak_log
fill 379 186 311 379 189 311 minecraft:red_terracotta
setblock 379 186 315 minecraft:stripped_oak_log
fill 379 186 316 379 189 316 minecraft:red_terracotta
fill 380 186 311 380 208 311 minecraft:stripped_oak_log
setblock 380 186 314 minecraft:stripped_oak_log
fill 380 186 315 380 189 315 minecraft:red_terracotta
fill 381 186 314 381 189 314 minecraft:red_terracotta
setblock 383 186 316 minecraft:stripped_oak_log
setblock 384 186 315 minecraft:stripped_oak_log
fill 384 186 316 384 189 316 minecraft:red_terracotta
fill 385 186 315 385 189 315 minecraft:red_terracotta
fill 399 186 276 399 189 276 minecraft:red_terracotta
fill 399 186 316 399 189 316 minecraft:red_terracotta
fill 402 186 315 402 187 315 minecraft:red_terracotta
setblock 403 186 276 minecraft:stripped_oak_log
fill 403 186 277 403 189 277 minecraft:red_terracotta
setblock 403 186 316 minecraft:stripped_oak_log
fill 404 186 276 404 189 276 minecraft:red_terracotta
setblock 404 186 315 minecraft:stripped_oak_log
fill 404 186 316 404 189 316 minecraft:red_terracotta
fill 405 186 315 405 189 315 minecraft:red_terracotta
setblock 408 186 276 minecraft:stripped_oak_log
setblock 408 186 316 minecraft:stripped_oak_log
fill 409 186 276 409 189 276 minecraft:red_terracotta
fill 409 186 316 409 189 316 minecraft:red_terracotta
setblock 413 186 316 minecraft:stripped_oak_log
fill 414 186 316 414 189 316 minecraft:red_terracotta
setblock 416 186 313 minecraft:stripped_oak_log
fill 416 186 314 416 188 315 minecraft:red_terracotta
setblock 417 186 307 minecraft:stripped_oak_log
fill 417 186 308 417 189 308 minecraft:red_terracotta
setblock 417 186 312 minecraft:stripped_oak_log
fill 417 186 313 417 189 313 minecraft:red_terracotta
setblock 377 187 291 minecraft:stripped_oak_log
fill 377 187 292 377 190 292 minecraft:red_terracotta
fill 377 187 294 377 187 295 minecraft:red_terracotta
setblock 377 187 296 minecraft:stripped_oak_log
setblock 377 187 306 minecraft:stripped_oak_log
fill 377 187 307 377 190 307 minecraft:red_terracotta
setblock 377 187 311 minecraft:stripped_oak_log
fill 377 187 312 377 190 312 minecraft:red_terracotta
setblock 377 187 316 minecraft:stripped_oak_log
fill 378 187 306 378 190 306 minecraft:red_terracotta
setblock 378 187 310 minecraft:stripped_oak_log
fill 378 187 311 378 190 311 minecraft:red_terracotta
setblock 378 187 314 minecraft:red_terracotta
setblock 378 187 315 minecraft:stripped_oak_log
fill 378 187 316 378 190 316 minecraft:red_terracotta
setblock 379 187 309 minecraft:stripped_oak_log
fill 379 187 310 379 190 310 minecraft:red_terracotta
setblock 379 187 314 minecraft:stripped_oak_log
fill 379 187 315 379 190 315 minecraft:red_terracotta
fill 380 187 314 380 190 314 minecraft:red_terracotta
setblock 382 187 316 minecraft:stripped_oak_log
setblock 383 187 315 minecraft:stripped_oak_log
fill 383 187 316 383 190 316 minecraft:red_terracotta
fill 384 187 315 384 190 315 minecraft:red_terracotta
fill 401 187 315 401 188 315 minecraft:red_terracotta
setblock 402 187 276 minecraft:stripped_oak_log
fill 402 187 277 402 190 277 minecraft:red_terracotta
setblock 402 187 316 minecraft:stripped_oak_log
fill 403 187 276 403 190 276 minecraft:red_terracotta
setblock 403 187 315 minecraft:stripped_oak_log
fill 403 187 316 403 190 316 minecraft:red_terracotta
fill 404 187 315 404 190 315 minecraft:red_terracotta
setblock 405 187 277 minecraft:red_terracotta
setblock 407 187 276 minecraft:stripped_oak_log
setblock 407 187 316 minecraft:stripped_oak_log
fill 408 187 276 408 190 276 minecraft:red_terracotta
fill 408 187 316 408 190 316 minecraft:red_terracotta
setblock 412 187 316 minecraft:stripped_oak_log
fill 413 187 316 413 190 316 minecraft:red_terracotta
fill 415 187 315 415 189 315 minecraft:red_terracotta
setblock 416 187 312 minecraft:stripped_oak_log
fill 416 187 313 416 190 313 minecraft:red_terracotta
setblock 417 187 276 minecraft:stripped_oak_log
fill 417 187 307 417 190 307 minecraft:red_terracotta
setblock 417 187 311 minecraft:stripped_oak_log
fill 417 187 312 417 190 312 minecraft:red_terracotta
setblock 417 187 316 minecraft:stripped_oak_log
fill 376 188 275 376 191 317 minecraft:brown_terracotta
fill 377 188 275 418 191 275 minecraft:brown_terracotta
setblock 377 188 290 minecraft:stripped_oak_log
fill 377 188 291 378 190 291 minecraft:red_terracotta
setblock 377 188 294 minecraft:red_terracotta
setblock 377 188 295 minecraft:stripped_oak_log
fill 377 188 296 377 188 299 minecraft:red_terracotta
setblock 377 188 300 minecraft:stripped_oak_log
fill 377 188 303 377 189 303 minecraft:red_terracotta
setblock 377 188 305 minecraft:stripped_oak_log
fill 377 188 306 377 191 306 minecraft:red_terracotta
setblock 377 188 310 minecraft:stripped_oak_log
fill 377 188 311 377 191 311 minecraft:red_terracotta
setblock 377 188 315 minecraft:stripped_oak_log
fill 377 188 316 377 191 316 minecraft:red_terracotta
fill 377 188 317 418 191 317 minecraft:brown_terracotta
fill 378 188 292 378 188 293 minecraft:red_terracotta
setblock 378 188 294 minecraft:stripped_oak_log
fill 378 188 295 378 190 296 minecraft:red_terracotta
setblock 378 188 309 minecraft:stripped_oak_log
fill 378 188 310 378 191 310 minecraft:red_terracotta
setblock 378 188 314 minecraft:stripped_oak_log
fill 378 188 315 378 191 315 minecraft:red_terracotta
setblock 379 188 308 minecraft:stripped_oak_log
fill 379 188 309 379 191 309 minecraft:red_terracotta
setblock 379 188 313 minecraft:stripped_oak_log
fill 379 188 314 379 191 314 minecraft:red_terracotta
setblock 380 188 276 minecraft:red_terracotta
setblock 381 188 276 minecraft:stripped_oak_log
setblock 381 188 316 minecraft:stripped_oak_log
setblock 382 188 315 minecraft:stripped_oak_log
fill 382 188 316 382 191 316 minecraft:red_terracotta
setblock 383 188 314 minecraft:stripped_oak_log
fill 383 188 315 383 191 315 minecraft:red_terracotta
setblock 386 188 316 minecraft:stripped_oak_log
fill 397 188 276 398 190 276 minecraft:red_terracotta
fill 397 188 316 398 190 316 minecraft:red_terracotta
setblock 400 188 277 minecraft:stripped_oak_log
fill 400 188 315 400 189 315 minecraft:red_terracotta
setblock 401 188 276 minecraft:stripped_oak_log
fill 401 188 277 401 191 277 minecraft:red_terracotta
setblock 401 188 316 minecraft:stripped_oak_log
fill 402 188 276 402 191 276 minecraft:red_terracotta
setblock 402 188 315 minecraft:stripped_oak_log
fill 402 188 316 402 191 316 minecraft:red_terracotta
fill 403 188 315 403 191 315 minecraft:red_terracotta
setblock 405 188 277 minecraft:stripped_oak_log
setblock 406 188 276 minecraft:stripped_oak_log
setblock 406 188 316 minecraft:stripped_oak_log
fill 407 188 276 407 191 276 minecraft:red_terracotta
fill 407 188 316 407 191 316 minecraft:red_terracotta
setblock 410 188 276 minecraft:red_terracotta
setblock 411 188 316 minecraft:stripped_oak_log
fill 412 188 316 412 191 316 minecraft:red_terracotta
fill 414 188 315 414 190 315 minecraft:red_terracotta
setblock 415 188 276 minecraft:red_terracotta
setblock 416 188 276 minecraft:stripped_oak_log
setblock 416 188 310 minecraft:red_terracotta
setblock 416 188 311 minecraft:stripped_oak_log
fill 416 188 312 416 191 312 minecraft:red_terracotta
setblock 416 188 316 minecraft:stripped_oak_log
fill 417 188 276 417 190 277 minecraft:red_terracotta
setblock 417 188 290 minecraft:stripped_oak_log
fill 417 188 291 417 189 293 minecraft:red_terracotta
setblock 417 188 310 minecraft:stripped_oak_log
fill 417 188 311 417 191 311 minecraft:red_terracotta
setblock 417 188 315 minecraft:stripped_oak_log
fill 417 188 316 417 191 316 minecraft:red_terracotta
fill 418 188 276 418 191 316 minecraft:brown_terracotta
fill 377 189 276 379 189 276 minecraft:red_terracotta
setblock 377 189 288 minecraft:red_terracotta
setblock 377 189 289 minecraft:stripped_oak_log
fill 377 189 290 378 191 290 minecraft:red_terracotta
setblock 377 189 294 minecraft:stripped_oak_log
fill 377 189 295 377 189 298 minecraft:red_terracotta
setblock 377 189 299 minecraft:stripped_oak_log
fill 377 189 300 377 190 302 minecraft:red_terracotta
setblock 377 189 304 minecraft:stripped_oak_log
fill 377 189 305 378 191 305 minecraft:red_terracotta
setblock 377 189 309 minecraft:stripped_oak_log
fill 377 189 310 377 192 310 minecraft:red_terracotta
setblock 377 189 313 minecraft:red_terracotta
setblock 377 189 314 minecraft:stripped_oak_log
fill 377 189 315 377 192 315 minecraft:red_terracotta
setblock 378 189 292 minecraft:red_terracotta
setblock 378 189 293 minecraft:stripped_oak_log
fill 378 189 294 379 191 294 minecraft:red_terracotta
setblock 378 189 297 minecraft:red_terracotta
setblock 378 189 298 minecraft:stripped_oak_log
fill 378 189 299 378 192 299 minecraft:red_terracotta
setblock 378 189 308 minecraft:stripped_oak_log
fill 378 189 309 378 192 309 minecraft:red_terracotta
setblock 378 189 313 minecraft:stripped_oak_log
fill 378 189 314 378 192 314 minecraft:red_terracotta
setblock 379 189 292 minecraft:stripped_oak_log
fill 379 189 293 379 192 293 minecraft:red_terracotta
fill 379 189 295 379 189 296 minecraft:red_terracotta
fill 379 189 308 379 192 308 minecraft:red_terracotta
setblock 379 189 312 minecraft:stripped_oak_log
fill 379 189 313 379 192 313 minecraft:red_terracotta
setblock 380 189 276 minecraft:stripped_oak_log
setblock 380 189 316 minecraft:stripped_oak_log
fill 381 189 276 382 191 276 minecraft:red_terracotta
setblock 381 189 315 minecraft:stripped_oak_log
fill 381 189 316 381 192 316 minecraft:red_terracotta
setblock 382 189 314 minecraft:stripped_oak_log
fill 382 189 315 382 192 315 minecraft:red_terracotta
fill 383 189 314 383 190 314 minecraft:red_terracotta
setblock 385 189 316 minecraft:stripped_oak_log
fill 386 189 316 386 192 316 minecraft:red_terracotta
fill 396 189 276 396 192 276 minecraft:red_terracotta
fill 396 189 316 396 192 316 minecraft:red_terracotta
setblock 399 189 277 minecraft:stripped_oak_log
fill 399 189 315 399 190 315 minecraft:red_terracotta
setblock 400 189 276 minecraft:stripped_oak_log
fill 400 189 277 400 192 277 minecraft:red_terracotta
setblock 400 189 316 minecraft:stripped_oak_log
fill 401 189 276 401 192 276 minecraft:red_terracotta
setblock 401 189 315 minecraft:stripped_oak_log
fill 401 189 316 401 192 316 minecraft:red_terracotta
fill 402 189 315 402 192 315 minecraft:red_terracotta
setblock 404 189 277 minecraft:stripped_oak_log
setblock 405 189 276 minecraft:stripped_oak_log
fill 405 189 277 406 191 277 minecraft:red_terracotta
setblock 405 189 316 minecraft:stripped_oak_log
fill 406 189 276 406 192 276 minecraft:red_terracotta
setblock 406 189 315 minecraft:stripped_oak_log
fill 406 189 316 406 192 316 minecraft:red_terracotta
fill 407 189 315 407 192 315 minecraft:red_terracotta
setblock 410 189 276 minecraft:stripped_oak_log
setblock 410 189 316 minecraft:stripped_oak_log
fill 411 189 276 414 189 276 minecraft:red_terracotta
fill 411 189 316 411 192 316 minecraft:red_terracotta
fill 413 189 315 413 191 315 minecraft:red_terracotta
setblock 415 189 276 minecraft:stripped_oak_log
setblock 415 189 316 minecraft:stripped_oak_log
fill 416 189 276 416 192 276 minecraft:red_terracotta
setblock 416 189 310 minecraft:stripped_oak_log
fill 416 189 311 416 192 311 minecraft:red_terracotta
setblock 416 189 314 minecraft:red_terracotta
setblock 416 189 315 minecraft:stripped_oak_log
fill 416 189 316 416 192 316 minecraft:red_terracotta
setblock 417 189 278 minecraft:red_terracotta
setblock 417 189 289 minecraft:stripped_oak_log
fill 417 189 290 417 192 290 minecraft:red_terracotta
setblock 417 189 294 minecraft:stripped_oak_log
fill 417 189 295 417 191 296 minecraft:red_terracotta
fill 417 189 306 417 191 306 minecraft:red_terracotta
setblock 417 189 309 minecraft:stripped_oak_log
fill 417 189 310 417 192 310 minecraft:red_terracotta
setblock 417 189 314 minecraft:stripped_oak_log
fill 417 189 315 417 192 315 minecraft:red_terracotta
fill 377 190 276 377 190 277 minecraft:red_terracotta
setblock 377 190 288 minecraft:stripped_oak_log
fill 377 190 289 378 192 289 minecraft:red_terracotta
setblock 377 190 293 minecraft:stripped_oak_log
fill 377 190 294 377 190 297 minecraft:red_terracotta
setblock 377 190 298 minecraft:stripped_oak_log
fill 377 190 299 377 193 299 minecraft:red_terracotta
setblock 377 190 303 minecraft:stripped_oak_log
fill 377 190 304 378 192 304 minecraft:red_terracotta
setblock 377 190 308 minecraft:stripped_oak_log
fill 377 190 309 377 193 309 minecraft:red_terracotta
setblock 377 190 313 minecraft:stripped_oak_log
fill 377 190 314 377 193 314 minecraft:red_terracotta
setblock 378 190 276 minecraft:red_terracotta
setblock 378 190 292 minecraft:stripped_oak_log
fill 378 190 293 378 193 293 minecraft:red_terracotta
setblock 378 190 297 minecraft:stripped_oak_log
fill 378 190 298 379 192 298 minecraft:red_terracotta
fill 378 190 300 378 190 301 minecraft:red_terracotta
setblock 378 190 302 minecraft:stripped_oak_log
fill 378 190 303 378 193 303 minecraft:red_terracotta
setblock 378 190 307 minecraft:stripped_oak_log
fill 378 190 308 378 193 308 minecraft:red_terracotta
setblock 378 190 312 minecraft:stripped_oak_log
fill 378 190 313 378 193 313 minecraft:red_terracotta
setblock 379 190 276 minecraft:stripped_oak_log
setblock 379 190 291 minecraft:stripped_oak_log
fill 379 190 292 379 193 292 minecraft:red_terracotta
setblock 379 190 295 minecraft:red_terracotta
setblock 379 190 296 minecraft:stripped_oak_log
fill 379 190 297 379 193 297 minecraft:red_terracotta
fill 379 190 299 379 191 299 minecraft:red_terracotta
setblock 379 190 311 minecraft:stripped_oak_log
fill 379 190 312 379 193 312 minecraft:red_terracotta
setblock 379 190 316 minecraft:stripped_oak_log
fill 380 190 276 380 193 276 minecraft:red_terracotta
setblock 380 190 315 minecraft:stripped_oak_log
fill 380 190 316 380 193 316 minecraft:red_terracotta
setblock 381 190 314 minecraft:stripped_oak_log
fill 381 190 315 381 193 315 minecraft:red_terracotta
fill 382 190 314 382 193 314 minecraft:red_terracotta
setblock 383 190 276 minecraft:red_terracotta
setblock 384 190 316 minecraft:stripped_oak_log
setblock 385 190 315 minecraft:stripped_oak_log
fill 385 190 316 385 193 316 minecraft:red_terracotta
fill 395 190 276 395 193 276 minecraft:red_terracotta
fill 395 190 316 395 193 316 minecraft:red_terracotta
setblock 397 190 277 minecraft:red_terracotta
fill 397 190 315 398 191 315 minecraft:red_terracotta
setblock 398 190 277 minecraft:stripped_oak_log
setblock 399 190 276 minecraft:stripped_oak_log
fill 399 190 277 399 193 277 minecraft:red_terracotta
setblock 399 190 316 minecraft:stripped_oak_log
fill 400 190 276 400 193 276 minecraft:red_terracotta
setblock 400 190 315 minecraft:stripped_oak_log
fill 400 190 316 400 193 316 minecraft:red_terracotta
fill 401 190 315 401 193 315 minecraft:red_terracotta
setblock 403 190 277 minecraft:stripped_oak_log
setblock 404 190 276 minecraft:stripped_oak_log
fill 404 190 277 404 193 277 minecraft:red_terracotta
setblock 404 190 316 minecraft:stripped_oak_log
fill 405 190 276 405 193 276 minecraft:red_terracotta
setblock 405 190 315 minecraft:stripped_oak_log
fill 405 190 316 405 193 316 minecraft:red_terracotta
fill 406 190 315 406 193 315 minecraft:red_terracotta
fill 408 190 315 409 190 315 minecraft:red_terracotta
setblock 409 190 276 minecraft:stripped_oak_log
setblock 409 190 316 minecraft:stripped_oak_log
fill 410 190 276 413 190 276 minecraft:red_terracotta
setblock 410 190 315 minecraft:stripped_oak_log
fill 410 190 316 410 193 316 minecraft:red_terracotta
fill 411 190 315 412 192 315 minecraft:red_terracotta
setblock 414 190 276 minecraft:stripped_oak_log
setblock 414 190 316 minecraft:stripped_oak_log
fill 415 190 276 415 193 276 minecraft:red_terracotta
fill 415 190 313 415 190 314 minecraft:red_terracotta
setblock 415 190 315 minecraft:stripped_oak_log
fill 415 190 316 415 193 316 minecraft:red_terracotta
setblock 416 190 309 minecraft:stripped_oak_log
fill 416 190 310 416 193 310 minecraft:red_terracotta
setblock 416 190 314 minecraft:stripped_oak_log
fill 416 190 315 416 193 315 minecraft:red_terracotta
setblock 417 190 278 minecraft:stripped_oak_log
fill 417 190 279 417 193 279 minecraft:red_terracotta
fill 417 190 289 417 193 289 minecraft:red_terracotta
fill 417 190 291 417 190 292 minecraft:red_terracotta
setblock 417 190 293 minecraft:stripped_oak_log
fill 417 190 294 417 193 294 minecraft:red_terracotta
setblock 417 190 297 minecraft:red_terracotta
setblock 417 190 298 minecraft:stripped_oak_log
fill 417 190 299 417 193 299 minecraft:red_terracotta
fill 417 190 305 417 192 305 minecraft:red_terracotta
setblock 417 190 308 minecraft:stripped_oak_log
fill 417 190 309 417 193 309 minecraft:red_terracotta
setblock 417 190 313 minecraft:stripped_oak_log
fill 417 190 314 417 193 314 minecraft:red_terracotta
setblock 377 191 276 minecraft:red_terracotta
setblock 377 191 277 minecraft:stripped_oak_log
fill 377 191 278 377 194 278 minecraft:red_terracotta
setblock 377 191 287 minecraft:stripped_oak_log
fill 377 191 288 377 194 288 minecraft:red_terracotta
setblock 377 191 291 minecraft:red_terracotta
setblock 377 191 292 minecraft:stripped_oak_log
fill 377 191 293 377 191 296 minecraft:red_terracotta
setblock 377 191 297 minecraft:stripped_oak_log
fill 377 191 298 377 194 298 minecraft:red_terracotta
fill 377 191 300 377 191 301 minecraft:red_terracotta
setblock 377 191 302 minecraft:stripped_oak_log
fill 377 191 303 377 194 303 minecraft:red_terracotta
setblock 377 191 307 minecraft:stripped_oak_log
fill 377 191 308 377 194 308 minecraft:red_terracotta
setblock 377 191 312 minecraft:stripped_oak_log
fill 377 191 313 377 194 313 minecraft:red_terracotta
setblock 378 191 276 minecraft:stripped_oak_log
setblock 378 191 291 minecraft:stripped_oak_log
fill 378 191 292 378 194 292 minecraft:red_terracotta
setblock 378 191 295 minecraft:red_terracotta
setblock 378 191 296 minecraft:stripped_oak_log
fill 378 191 297 378 194 297 minecraft:red_terracotta
setblock 378 191 300 minecraft:red_terracotta
setblock 378 191 301 minecraft:stripped_oak_log
fill 378 191 302 378 194 302 minecraft:red_terracotta
setblock 378 191 306 minecraft:stripped_oak_log
fill 378 191 307 378 194 307 minecraft:red_terracotta
setblock 378 191 311 minecraft:stripped_oak_log
fill 378 191 312 378 194 312 minecraft:red_terracotta
setblock 378 191 316 minecraft:stripped_oak_log
fill 379 191 276 379 194 276 minecraft:red_terracotta
setblock 379 191 278 minecraft:light[level=15]
setblock 379 191 285 minecraft:light[level=12]
setblock 379 191 286 minecraft:light[level=15]
fill 379 191 291 379 194 291 minecraft:red_terracotta
setblock 379 191 295 minecraft:stripped_oak_log
fill 379 191 296 380 193 296 minecraft:red_terracotta
setblock 379 191 300 minecraft:stripped_oak_log
fill 379 191 301 379 194 301 minecraft:red_terracotta
setblock 379 191 302 minecraft:light[level=15]
setblock 379 191 306 minecraft:light[level=12]
setblock 379 191 310 minecraft:stripped_oak_log
fill 379 191 311 379 194 311 minecraft:red_terracotta
setblock 379 191 315 minecraft:stripped_oak_log
fill 379 191 316 379 194 316 minecraft:red_terracotta
setblock 380 191 293 minecraft:red_terracotta
setblock 380 191 294 minecraft:stripped_oak_log
fill 380 191 295 380 194 295 minecraft:red_terracotta
fill 380 191 297 380 192 297 minecraft:red_terracotta
setblock 380 191 314 minecraft:stripped_oak_log
fill 380 191 315 380 194 315 minecraft:red_terracotta
fill 381 191 314 381 194 314 minecraft:red_terracotta
setblock 383 191 276 minecraft:stripped_oak_log
setblock 383 191 316 minecraft:stripped_oak_log
fill 384 191 276 384 194 276 minecraft:red_terracotta
setblock 384 191 315 minecraft:stripped_oak_log
fill 384 191 316 384 194 316 minecraft:red_terracotta
setblock 385 191 315 minecraft:red_terracotta
setblock 386 191 278 minecraft:light[level=12]
setblock 386 191 285 minecraft:light[level=12]
setblock 386 191 292 minecraft:light[level=12]
setblock 386 191 299 minecraft:light[level=12]
setblock 386 191 306 minecraft:light[level=12]
setblock 386 191 313 minecraft:light[level=12]
setblock 387 191 278 minecraft:light[level=15]
setblock 387 191 294 minecraft:light[level=15]
setblock 387 191 302 minecraft:light[level=15]
setblock 387 191 310 minecraft:light[level=15]
setblock 387 191 316 minecraft:red_terracotta
setblock 393 191 276 minecraft:stripped_oak_log
setblock 393 191 278 minecraft:light[level=12]
setblock 393 191 285 minecraft:light[level=12]
setblock 393 191 292 minecraft:light[level=12]
setblock 393 191 299 minecraft:light[level=12]
setblock 393 191 306 minecraft:light[level=12]
setblock 393 191 313 minecraft:light[level=12]
setblock 393 191 316 minecraft:stripped_oak_log
fill 394 191 276 394 194 276 minecraft:red_terracotta
fill 394 191 316 394 194 316 minecraft:red_terracotta
setblock 395 191 278 minecraft:light[level=15]
setblock 395 191 286 minecraft:light[level=15]
setblock 395 191 294 minecraft:light[level=15]
setblock 395 191 302 minecraft:light[level=15]
setblock 395 191 310 minecraft:light[level=15]
setblock 396 191 277 minecraft:red_terracotta
fill 396 191 315 396 193 315 minecraft:red_terracotta
setblock 397 191 276 minecraft:red_terracotta
setblock 397 191 277 minecraft:stripped_oak_log
setblock 397 191 316 minecraft:red_terracotta
setblock 398 191 276 minecraft:stripped_oak_log
fill 398 191 277 398 193 278 minecraft:red_terracotta
setblock 398 191 316 minecraft:stripped_oak_log
fill 399 191 276 399 194 276 minecraft:red_terracotta
fill 399 191 278 400 191 278 minecraft:red_terracotta
setblock 399 191 315 minecraft:stripped_oak_log
fill 399 191 316 399 194 316 minecraft:red_terracotta
setblock 400 191 285 minecraft:light[level=12]
setblock 400 191 292 minecraft:light[level=12]
setblock 400 191 299 minecraft:light[level=12]
setblock 400 191 313 minecraft:light[level=12]
setblock 400 191 314 minecraft:stripped_oak_log
fill 400 191 315 400 194 315 minecraft:red_terracotta
setblock 401 191 278 minecraft:stripped_oak_log
fill 401 191 314 402 193 314 minecraft:red_terracotta
setblock 402 191 277 minecraft:stripped_oak_log
fill 402 191 278 403 192 278 minecraft:red_terracotta
setblock 403 191 276 minecraft:stripped_oak_log
fill 403 191 277 403 194 277 minecraft:red_terracotta
setblock 403 191 286 minecraft:light[level=15]
setblock 403 191 294 minecraft:light[level=15]
setblock 403 191 302 minecraft:light[level=15]
setblock 403 191 310 minecraft:light[level=15]
setblock 403 191 316 minecraft:stripped_oak_log
fill 404 191 276 404 194 276 minecraft:red_terracotta
setblock 404 191 315 minecraft:stripped_oak_log
fill 404 191 316 404 194 316 minecraft:red_terracotta
fill 405 191 315 405 194 315 minecraft:red_terracotta
setblock 407 191 277 minecraft:stripped_oak_log
setblock 407 191 278 minecraft:light[level=12]
setblock 407 191 285 minecraft:light[level=12]
setblock 407 191 292 minecraft:light[level=12]
setblock 407 191 299 minecraft:light[level=12]
setblock 407 191 306 minecraft:light[level=12]
setblock 407 191 313 minecraft:light[level=12]
setblock 408 191 276 minecraft:stripped_oak_log
setblock 408 191 315 minecraft:red_terracotta
setblock 408 191 316 minecraft:stripped_oak_log
fill 409 191 276 412 191 276 minecraft:red_terracotta
setblock 409 191 315 minecraft:stripped_oak_log
fill 409 191 316 409 194 316 minecraft:red_terracotta
fill 410 191 315 410 194 315 minecraft:red_terracotta
setblock 411 191 278 minecraft:light[level=15]
setblock 411 191 286 minecraft:light[level=15]
setblock 411 191 294 minecraft:light[level=15]
setblock 411 191 302 minecraft:light[level=15]
setblock 411 191 310 minecraft:light[level=15]
setblock 413 191 276 minecraft:stripped_oak_log
setblock 413 191 316 minecraft:stripped_oak_log
fill 414 191 276 414 193 277 minecraft:red_terracotta
setblock 414 191 278 minecraft:light[level=12]
setblock 414 191 285 minecraft:light[level=12]
setblock 414 191 292 minecraft:light[level=12]
setblock 414 191 299 minecraft:light[level=12]
setblock 414 191 306 minecraft:light[level=12]
setblock 414 191 313 minecraft:light[level=12]
setblock 414 191 314 minecraft:red_terracotta
setblock 414 191 315 minecraft:stripped_oak_log
fill 414 191 316 414 194 316 minecraft:red_terracotta
fill 415 191 277 416 191 277 minecraft:red_terracotta
fill 415 191 312 415 191 313 minecraft:red_terracotta
setblock 415 191 314 minecraft:stripped_oak_log
fill 415 191 315 415 194 315 minecraft:red_terracotta
fill 416 191 309 416 194 309 minecraft:red_terracotta
setblock 416 191 313 minecraft:stripped_oak_log
fill 416 191 314 416 194 314 minecraft:red_terracotta
setblock 417 191 276 minecraft:red_terracotta
setblock 417 191 277 minecraft:stripped_oak_log
fill 417 191 278 417 194 278 minecraft:red_terracotta
fill 417 191 280 417 192 280 minecraft:red_terracotta
fill 417 191 288 417 194 288 minecraft:red_terracotta
setblock 417 191 291 minecraft:red_terracotta
setblock 417 191 292 minecraft:stripped_oak_log
fill 417 191 293 417 194 293 minecraft:red_terracotta
setblock 417 191 297 minecraft:stripped_oak_log
fill 417 191 298 417 194 298 minecraft:red_terracotta
fill 417 191 300 417 191 301 minecraft:red_terracotta
setblock 417 191 302 minecraft:stripped_oak_log
fill 417 191 303 417 193 304 minecraft:red_terracotta
setblock 417 191 307 minecraft:stripped_oak_log
fill 417 191 308 417 194 308 minecraft:red_terracotta
setblock 417 191 312 minecraft:stripped_oak_log
fill 417 191 313 417 194 313 minecraft:red_terracotta
fill 376 192 275 376 195 317 minecraft:light_gray_terracotta
fill 377 192 275 418 195 275 minecraft:light_gray_terracotta
setblock 377 192 276 minecraft:stripped_oak_log
fill 377 192 277 380 192 277 minecraft:red_terracotta
fill 377 192 279 377 192 280 minecraft:red_terracotta
fill 377 192 287 377 195 287 minecraft:red_terracotta
setblock 377 192 290 minecraft:red_terracotta
setblock 377 192 291 minecraft:stripped_oak_log
fill 377 192 292 377 192 295 minecraft:red_terracotta
setblock 377 192 296 minecraft:stripped_oak_log
fill 377 192 297 377 195 297 minecraft:red_terracotta
setblock 377 192 300 minecraft:red_terracotta
setblock 377 192 301 minecraft:stripped_oak_log
fill 377 192 302 377 195 302 minecraft:red_terracotta
setblock 377 192 305 minecraft:red_terracotta
setblock 377 192 306 minecraft:stripped_oak_log
fill 377 192 307 377 195 307 minecraft:red_terracotta
setblock 377 192 311 minecraft:stripped_oak_log
fill 377 192 312 377 195 312 minecraft:red_terracotta
setblock 377 192 316 minecraft:stripped_oak_log
fill 377 192 317 418 195 317 minecraft:light_gray_terracotta
fill 378 192 276 378 195 276 minecraft:red_terracotta
setblock 378 192 290 minecraft:stripped_oak_log
fill 378 192 291 378 195 291 minecraft:red_terracotta
setblock 378 192 294 minecraft:red_terracotta
setblock 378 192 295 minecraft:stripped_oak_log
fill 378 192 296 378 195 296 minecraft:red_terracotta
setblock 378 192 300 minecraft:stripped_oak_log
fill 378 192 301 378 195 301 minecraft:red_terracotta
setblock 378 192 305 minecraft:stripped_oak_log
fill 378 192 306 378 195 306 minecraft:red_terracotta
setblock 378 192 310 minecraft:stripped_oak_log
fill 378 192 311 378 195 311 minecraft:red_terracotta
setblock 378 192 315 minecraft:stripped_oak_log
fill 378 192 316 378 195 316 minecraft:red_terracotta
fill 379 192 290 379 194 290 minecraft:red_terracotta
setblock 379 192 294 minecraft:stripped_oak_log
fill 379 192 295 379 195 295 minecraft:red_terracotta
setblock 379 192 299 minecraft:stripped_oak_log
fill 379 192 300 379 195 300 minecraft:red_terracotta
fill 379 192 302 379 192 303 minecraft:red_terracotta
setblock 379 192 304 minecraft:stripped_oak_log
setblock 379 192 309 minecraft:stripped_oak_log
fill 379 192 310 379 194 310 minecraft:red_terracotta
setblock 379 192 314 minecraft:stripped_oak_log
fill 379 192 315 379 195 315 minecraft:red_terracotta
setblock 380 192 293 minecraft:stripped_oak_log
fill 380 192 294 380 195 294 minecraft:red_terracotta
setblock 380 192 298 minecraft:stripped_oak_log
fill 380 192 299 380 195 299 minecraft:red_terracotta
fill 380 192 314 380 195 314 minecraft:red_terracotta
setblock 381 192 276 minecraft:red_terracotta
setblock 381 192 277 minecraft:stripped_oak_log
setblock 382 192 276 minecraft:stripped_oak_log
setblock 382 192 316 minecraft:stripped_oak_log
fill 383 192 276 383 195 276 minecraft:red_terracotta
setblock 383 192 315 minecraft:stripped_oak_log
fill 383 192 316 383 195 316 minecraft:red_terracotta
fill 384 192 315 384 193 315 minecraft:red_terracotta
fill 385 192 276 385 193 276 minecraft:red_terracotta
setblock 387 192 316 minecraft:stripped_oak_log
setblock 391 192 276 minecraft:red_terracotta
setblock 392 192 276 minecraft:stripped_oak_log
setblock 392 192 316 minecraft:stripped_oak_log
fill 393 192 276 393 195 276 minecraft:red_terracotta
fill 393 192 316 393 195 316 minecraft:red_terracotta
fill 394 192 277 395 192 277 minecraft:red_terracotta
fill 395 192 315 395 194 315 minecraft:red_terracotta
setblock 396 192 277 minecraft:stripped_oak_log
setblock 397 192 276 minecraft:stripped_oak_log
fill 397 192 277 397 194 278 minecraft:red_terracotta
setblock 397 192 315 minecraft:red_terracotta
setblock 397 192 316 minecraft:stripped_oak_log
fill 398 192 276 398 195 276 minecraft:red_terracotta
setblock 398 192 315 minecraft:stripped_oak_log
fill 398 192 316 398 195 316 minecraft:red_terracotta
setblock 399 192 278 minecraft:red_terracotta
setblock 399 192 314 minecraft:stripped_oak_log
fill 399 192 315 399 195 315 minecraft:red_terracotta
setblock 400 192 278 minecraft:stripped_oak_log
fill 400 192 314 400 194 314 minecraft:red_terracotta
setblock 401 192 277 minecraft:stripped_oak_log
setblock 401 192 278 minecraft:red_terracotta
setblock 402 192 276 minecraft:stripped_oak_log
fill 402 192 277 402 195 277 minecraft:red_terracotta
setblock 402 192 316 minecraft:stripped_oak_log
fill 403 192 276 403 195 276 minecraft:red_terracotta
setblock 403 192 315 minecraft:stripped_oak_log
fill 403 192 316 403 195 316 minecraft:red_terracotta
setblock 404 192 278 minecraft:red_terracotta
fill 404 192 315 404 195 315 minecraft:red_terracotta
setblock 405 192 277 minecraft:red_terracotta
setblock 406 192 277 minecraft:stripped_oak_log
setblock 407 192 276 minecraft:stripped_oak_log
fill 407 192 277 410 192 277 minecraft:red_terracotta
setblock 407 192 316 minecraft:stripped_oak_log
fill 408 192 276 411 192 276 minecraft:red_terracotta
setblock 408 192 315 minecraft:stripped_oak_log
fill 408 192 316 408 195 316 minecraft:red_terracotta
fill 409 192 315 409 195 315 minecraft:red_terracotta
setblock 411 192 277 minecraft:stripped_oak_log
setblock 412 192 276 minecraft:stripped_oak_log
fill 412 192 277 413 194 277 minecraft:red_terracotta
setblock 412 192 316 minecraft:stripped_oak_log
fill 413 192 276 413 195 276 minecraft:red_terracotta
setblock 413 192 314 minecraft:red_terracotta
setblock 413 192 315 minecraft:stripped_oak_log
fill 413 192 316 413 195 316 minecraft:red_terracotta
setblock 414 192 314 minecraft:stripped_oak_log
fill 414 192 315 414 195 315 minecraft:red_terracotta
setblock 415 192 277 minecraft:red_terracotta
setblock 415 192 312 minecraft:red_terracotta
setblock 415 192 313 minecraft:stripped_oak_log
fill 415 192 314 415 195 314 minecraft:red_terracotta
setblock 416 192 277 minecraft:stripped_oak_log
fill 416 192 278 416 194 279 minecraft:red_terracotta
setblock 416 192 292 minecraft:stripped_oak_log
fill 416 192 293 416 192 296 minecraft:red_terracotta
setblock 416 192 297 minecraft:stripped_oak_log
fill 416 192 298 416 194 299 minecraft:red_terracotta
fill 416 192 308 416 195 308 minecraft:red_terracotta
setblock 416 192 312 minecraft:stripped_oak_log
fill 416 192 313 416 195 313 minecraft:red_terracotta
setblock 417 192 276 minecraft:stripped_oak_log
fill 417 192 277 417 195 277 minecraft:red_terracotta
setblock 417 192 281 minecraft:stripped_oak_log
fill 417 192 282 417 195 282 minecraft:red_terracotta
setblock 417 192 291 minecraft:stripped_oak_log
fill 417 192 292 417 195 292 minecraft:red_terracotta
setblock 417 192 295 minecraft:red_terracotta
setblock 417 192 296 minecraft:stripped_oak_log
fill 417 192 297 417 195 297 minecraft:red_terracotta
setblock 417 192 300 minecraft:red_terracotta
setblock 417 192 301 minecraft:stripped_oak_log
fill 417 192 302 417 195 302 minecraft:red_terracotta
setblock 417 192 306 minecraft:stripped_oak_log
fill 417 192 307 417 195 307 minecraft:red_terracotta
setblock 417 192 311 minecraft:stripped_oak_log
fill 417 192 312 417 195 312 minecraft:red_terracotta
setblock 417 192 316 minecraft:stripped_oak_log
fill 418 192 276 418 195 316 minecraft:light_gray_terracotta
fill 377 193 276 377 195 277 minecraft:red_terracotta
setblock 377 193 279 minecraft:red_terracotta
setblock 377 193 280 minecraft:stripped_oak_log
fill 377 193 281 377 195 282 minecraft:red_terracotta
fill 377 193 286 377 196 286 minecraft:red_terracotta
setblock 377 193 289 minecraft:red_terracotta
setblock 377 193 290 minecraft:stripped_oak_log
fill 377 193 291 377 193 294 minecraft:red_terracotta
setblock 377 193 295 minecraft:stripped_oak_log
fill 377 193 296 377 196 296 minecraft:red_terracotta
setblock 377 193 300 minecraft:stripped_oak_log
fill 377 193 301 377 196 301 minecraft:red_terracotta
setblock 377 193 304 minecraft:red_terracotta
setblock 377 193 305 minecraft:stripped_oak_log
fill 377 193 306 377 196 306 minecraft:red_terracotta
setblock 377 193 310 minecraft:stripped_oak_log
fill 377 193 311 377 196 311 minecraft:red_terracotta
setblock 377 193 315 minecraft:stripped_oak_log
fill 377 193 316 377 196 316 minecraft:red_terracotta
fill 378 193 277 378 193 278 minecraft:red_terracotta
setblock 378 193 279 minecraft:stripped_oak_log
setblock 378 193 288 minecraft:red_terracotta
setblock 378 193 289 minecraft:stripped_oak_log
fill 378 193 290 378 196 290 minecraft:red_terracotta
setblock 378 193 294 minecraft:stripped_oak_log
fill 378 193 295 378 196 295 minecraft:red_terracotta
setblock 378 193 298 minecraft:red_terracotta
setblock 378 193 299 minecraft:stripped_oak_log
fill 378 193 300 378 196 300 minecraft:red_terracotta
setblock 378 193 304 minecraft:stripped_oak_log
fill 378 193 305 379 195 305 minecraft:red_terracotta
setblock 378 193 309 minecraft:stripped_oak_log
fill 378 193 310 378 196 310 minecraft:red_terracotta
setblock 378 193 314 minecraft:stripped_oak_log
fill 378 193 315 378 196 315 minecraft:red_terracotta
setblock 379 193 277 minecraft:red_terracotta
setblock 379 193 293 minecraft:stripped_oak_log
fill 379 193 294 379 196 294 minecraft:red_terracotta
setblock 379 193 298 minecraft:stripped_oak_log
fill 379 193 299 379 196 299 minecraft:red_terracotta
setblock 379 193 302 minecraft:red_terracotta
setblock 379 193 303 minecraft:stripped_oak_log
fill 379 193 304 379 196 304 minecraft:red_terracotta
fill 379 193 306 379 193 307 minecraft:red_terracotta
fill 379 193 308 379 208 308 minecraft:stripped_oak_log
setblock 379 193 309 minecraft:red_terracotta
setblock 379 193 313 minecraft:stripped_oak_log
fill 379 193 314 379 195 314 minecraft:red_terracotta
setblock 380 193 277 minecraft:stripped_oak_log
setblock 380 193 292 minecraft:stripped_oak_log
fill 380 193 293 380 195 293 minecraft:red_terracotta
setblock 380 193 297 minecraft:stripped_oak_log
fill 380 193 298 380 196 298 minecraft:red_terracotta
fill 380 193 300 380 193 301 minecraft:red_terracotta
setblock 381 193 276 minecraft:stripped_oak_log
fill 381 193 277 382 195 277 minecraft:red_terracotta
setblock 381 193 316 minecraft:stripped_oak_log
fill 382 193 276 382 196 276 minecraft:red_terracotta
setblock 382 193 315 minecraft:stripped_oak_log
fill 382 193 316 382 196 316 minecraft:red_terracotta
fill 383 193 315 383 194 315 minecraft:red_terracotta
setblock 386 193 276 minecraft:stripped_oak_log
setblock 386 193 316 minecraft:stripped_oak_log
fill 387 193 276 390 193 276 minecraft:red_terracotta
fill 387 193 316 387 194 316 minecraft:red_terracotta
setblock 391 193 276 minecraft:stripped_oak_log
setblock 391 193 316 minecraft:stripped_oak_log
fill 392 193 276 392 196 276 minecraft:red_terracotta
fill 392 193 316 392 196 316 minecraft:red_terracotta
fill 393 193 277 394 193 277 minecraft:red_terracotta
fill 394 193 315 394 195 315 minecraft:red_terracotta
setblock 395 193 277 minecraft:stripped_oak_log
fill 395 193 278 396 195 278 minecraft:red_terracotta
setblock 396 193 276 minecraft:stripped_oak_log
fill 396 193 277 396 196 277 minecraft:red_terracotta
setblock 396 193 316 minecraft:stripped_oak_log
fill 397 193 276 397 196 276 minecraft:red_terracotta
setblock 397 193 315 minecraft:stripped_oak_log
fill 397 193 316 397 196 316 minecraft:red_terracotta
setblock 398 193 314 minecraft:stripped_oak_log
fill 398 193 315 398 196 315 minecraft:red_terracotta
setblock 399 193 278 minecraft:stripped_oak_log
fill 399 193 279 399 196 279 minecraft:red_terracotta
fill 399 193 314 399 194 314 minecraft:red_terracotta
setblock 400 193 277 minecraft:stripped_oak_log
fill 400 193 278 402 193 280 minecraft:terracotta
setblock 401 193 276 minecraft:stripped_oak_log
fill 401 193 277 401 196 277 minecraft:red_terracotta
setblock 401 193 316 minecraft:stripped_oak_log
fill 402 193 276 402 196 276 minecraft:red_terracotta
setblock 402 193 315 minecraft:stripped_oak_log
fill 402 193 316 402 196 316 minecraft:red_terracotta
setblock 403 193 278 minecraft:red_terracotta
fill 403 193 315 403 196 315 minecraft:red_terracotta
setblock 404 193 278 minecraft:stripped_oak_log
setblock 405 193 277 minecraft:stripped_oak_log
fill 405 193 278 405 196 278 minecraft:red_terracotta
setblock 406 193 276 minecraft:stripped_oak_log
fill 406 193 277 409 193 277 minecraft:red_terracotta
setblock 406 193 316 minecraft:stripped_oak_log
fill 407 193 276 410 193 276 minecraft:red_terracotta
setblock 407 193 315 minecraft:stripped_oak_log
fill 407 193 316 407 196 316 minecraft:red_terracotta
fill 408 193 315 408 196 315 minecraft:red_terracotta
setblock 410 193 277 minecraft:stripped_oak_log
setblock 411 193 276 minecraft:stripped_oak_log
fill 411 193 277 411 196 277 minecraft:red_terracotta
setblock 411 193 315 minecraft:red_terracotta
setblock 411 193 316 minecraft:stripped_oak_log
fill 412 193 276 412 196 276 minecraft:red_terracotta
setblock 412 193 314 minecraft:red_terracotta
setblock 412 193 315 minecraft:stripped_oak_log
fill 412 193 316 412 196 316 minecraft:red_terracotta
setblock 413 193 314 minecraft:stripped_oak_log
fill 413 193 315 413 196 315 minecraft:red_terracotta
fill 414 193 314 414 196 314 minecraft:red_terracotta
setblock 415 193 277 minecraft:stripped_oak_log
setblock 415 193 311 minecraft:red_terracotta
setblock 415 193 312 minecraft:stripped_oak_log
fill 415 193 313 415 196 313 minecraft:red_terracotta
setblock 416 193 276 minecraft:stripped_oak_log
fill 416 193 277 416 196 277 minecraft:red_terracotta
schedule function dropper:buildpart/68_6 1t
