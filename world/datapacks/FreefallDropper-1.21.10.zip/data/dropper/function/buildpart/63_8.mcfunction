fill 151 211 285 151 212 285 minecraft:gray_concrete
fill 151 211 287 151 212 287 minecraft:gray_concrete
fill 151 211 289 151 212 289 minecraft:gray_concrete
fill 151 211 291 151 212 291 minecraft:gray_concrete
fill 151 211 293 151 212 293 minecraft:gray_concrete
fill 151 211 295 151 212 295 minecraft:gray_concrete
fill 151 211 297 151 212 297 minecraft:gray_concrete
setblock 152 211 277 minecraft:snow_block
fill 152 211 284 152 212 284 minecraft:gray_concrete
fill 152 211 299 152 212 299 minecraft:gray_concrete
setblock 153 211 276 minecraft:snow_block
fill 153 211 277 155 211 278 minecraft:packed_ice
fill 154 211 276 157 211 276 minecraft:packed_ice
fill 154 211 284 154 212 284 minecraft:gray_concrete
fill 154 211 299 154 212 299 minecraft:gray_concrete
setblock 155 211 279 minecraft:snow_block
setblock 156 211 277 minecraft:packed_ice
setblock 156 211 278 minecraft:snow_block
fill 156 211 279 158 211 279 minecraft:packed_ice
fill 156 211 284 156 212 284 minecraft:gray_concrete
fill 156 211 299 156 212 299 minecraft:gray_concrete
fill 156 211 316 157 211 316 minecraft:packed_ice
fill 157 211 275 161 221 275 minecraft:packed_ice
setblock 157 211 277 minecraft:snow_block
fill 157 211 278 160 211 278 minecraft:packed_ice
setblock 158 211 276 minecraft:snow_block
fill 158 211 277 161 211 277 minecraft:packed_ice
fill 158 211 284 158 212 284 minecraft:gray_concrete
fill 158 211 299 158 212 299 minecraft:gray_concrete
setblock 158 211 316 minecraft:snow_block
fill 159 211 276 162 211 276 minecraft:packed_ice
fill 159 211 316 160 211 316 minecraft:packed_ice
fill 160 211 284 160 212 284 minecraft:gray_concrete
fill 160 211 299 160 212 299 minecraft:gray_concrete
setblock 161 211 278 minecraft:snow_block
setblock 162 211 275 minecraft:white_concrete
setblock 162 211 277 minecraft:snow_block
fill 162 211 284 162 212 284 minecraft:gray_concrete
fill 162 211 299 162 212 299 minecraft:gray_concrete
setblock 163 211 276 minecraft:snow_block
setblock 163 211 277 minecraft:packed_ice
fill 164 211 276 166 211 276 minecraft:packed_ice
fill 164 211 284 164 212 284 minecraft:gray_concrete
fill 164 211 299 164 212 299 minecraft:gray_concrete
setblock 165 211 275 minecraft:light_blue_concrete
fill 166 211 285 166 212 285 minecraft:gray_concrete
fill 166 211 287 166 212 287 minecraft:gray_concrete
fill 166 211 289 166 212 289 minecraft:gray_concrete
fill 166 211 291 166 212 291 minecraft:gray_concrete
fill 166 211 293 166 212 293 minecraft:gray_concrete
fill 166 211 295 166 212 295 minecraft:gray_concrete
fill 166 211 297 166 212 297 minecraft:gray_concrete
fill 166 211 307 168 216 308 minecraft:packed_ice
fill 167 211 309 168 216 309 minecraft:packed_ice
fill 169 211 276 172 211 276 minecraft:packed_ice
fill 171 211 316 172 211 316 minecraft:packed_ice
setblock 173 211 276 minecraft:snow_block
setblock 173 211 316 minecraft:snow_block
fill 174 211 276 176 211 277 minecraft:packed_ice
fill 174 211 316 177 211 316 minecraft:packed_ice
setblock 176 211 315 minecraft:packed_ice
setblock 177 211 276 minecraft:packed_ice
setblock 177 211 277 minecraft:snow_block
setblock 178 211 276 minecraft:snow_block
setblock 178 211 316 minecraft:snow_block
fill 179 211 276 180 211 276 minecraft:packed_ice
fill 179 211 303 179 211 304 minecraft:packed_ice
fill 179 211 316 180 211 316 minecraft:packed_ice
fill 180 211 300 180 211 303 minecraft:packed_ice
setblock 180 211 304 minecraft:snow_block
fill 180 211 305 181 211 307 minecraft:packed_ice
setblock 181 211 298 minecraft:snow_block
fill 181 211 299 181 211 302 minecraft:packed_ice
setblock 181 211 303 minecraft:snow_block
fill 181 211 304 182 213 304 minecraft:packed_ice
setblock 181 211 308 minecraft:snow_block
fill 181 211 309 182 213 309 minecraft:packed_ice
fill 182 211 280 182 211 281 minecraft:packed_ice
setblock 182 211 282 minecraft:snow_block
setblock 182 211 283 minecraft:packed_ice
setblock 182 211 296 minecraft:packed_ice
setblock 182 211 297 minecraft:snow_block
fill 182 211 298 182 211 301 minecraft:packed_ice
setblock 182 211 302 minecraft:snow_block
fill 182 211 303 182 214 303 minecraft:packed_ice
fill 182 211 305 182 211 306 minecraft:packed_ice
setblock 182 211 307 minecraft:snow_block
fill 182 211 308 182 214 308 minecraft:packed_ice
fill 182 211 310 182 212 310 minecraft:packed_ice
setblock 142 212 280 minecraft:packed_ice
setblock 142 212 281 minecraft:snow_block
fill 142 212 282 142 212 285 minecraft:packed_ice
setblock 142 212 286 minecraft:snow_block
fill 142 212 287 142 215 287 minecraft:packed_ice
setblock 142 212 296 minecraft:snow_block
fill 142 212 297 142 212 300 minecraft:packed_ice
setblock 142 212 301 minecraft:snow_block
fill 142 212 302 142 212 305 minecraft:packed_ice
setblock 142 212 306 minecraft:snow_block
fill 142 212 307 142 215 307 minecraft:packed_ice
fill 148 212 291 148 214 291 minecraft:blue_ice
fill 149 212 290 149 214 290 minecraft:blue_ice
fill 149 212 292 149 214 292 minecraft:blue_ice
fill 150 212 291 150 214 291 minecraft:blue_ice
setblock 151 212 276 minecraft:packed_ice
setblock 152 212 276 minecraft:snow_block
fill 152 212 277 155 212 277 minecraft:packed_ice
fill 153 212 276 156 212 276 minecraft:packed_ice
fill 153 212 278 154 212 278 minecraft:packed_ice
fill 153 212 311 153 218 311 minecraft:packed_ice
fill 153 212 317 153 237 317 minecraft:packed_ice
setblock 154 212 317 minecraft:white_concrete
setblock 155 212 278 minecraft:snow_block
setblock 156 212 277 minecraft:snow_block
fill 156 212 278 159 212 278 minecraft:packed_ice
setblock 156 212 316 minecraft:packed_ice
setblock 157 212 276 minecraft:snow_block
fill 157 212 277 160 212 277 minecraft:packed_ice
fill 157 212 282 157 214 282 minecraft:blue_ice
fill 157 212 300 157 214 300 minecraft:blue_ice
setblock 157 212 316 minecraft:snow_block
fill 158 212 276 161 212 276 minecraft:packed_ice
fill 158 212 281 158 214 281 minecraft:blue_ice
fill 158 212 283 158 214 283 minecraft:blue_ice
fill 158 212 301 158 214 301 minecraft:blue_ice
fill 158 212 316 159 212 316 minecraft:packed_ice
fill 159 212 282 159 214 282 minecraft:blue_ice
fill 159 212 300 159 214 300 minecraft:blue_ice
setblock 160 212 278 minecraft:snow_block
setblock 161 212 277 minecraft:snow_block
fill 162 212 275 162 233 275 minecraft:packed_ice
setblock 162 212 276 minecraft:snow_block
setblock 162 212 277 minecraft:packed_ice
fill 163 212 276 164 212 276 minecraft:packed_ice
fill 165 212 275 165 237 275 minecraft:packed_ice
fill 166 212 309 166 216 309 minecraft:packed_ice
fill 167 212 290 167 214 290 minecraft:blue_ice
fill 167 212 292 167 214 292 minecraft:blue_ice
fill 167 212 306 168 216 306 minecraft:packed_ice
fill 168 212 291 168 214 291 minecraft:blue_ice
fill 169 212 307 169 216 308 minecraft:packed_ice
setblock 171 212 276 minecraft:packed_ice
setblock 171 212 316 minecraft:packed_ice
setblock 172 212 276 minecraft:snow_block
setblock 172 212 316 minecraft:snow_block
fill 173 212 276 176 212 276 minecraft:packed_ice
fill 173 212 316 176 212 316 minecraft:packed_ice
fill 176 212 312 176 218 312 minecraft:packed_ice
setblock 177 212 276 minecraft:snow_block
setblock 177 212 316 minecraft:snow_block
setblock 178 212 276 minecraft:packed_ice
fill 178 212 316 179 212 316 minecraft:packed_ice
fill 180 212 301 180 212 302 minecraft:packed_ice
setblock 180 212 303 minecraft:snow_block
fill 180 212 304 180 212 307 minecraft:packed_ice
fill 181 212 299 181 212 301 minecraft:packed_ice
setblock 181 212 302 minecraft:snow_block
fill 181 212 303 181 215 303 minecraft:packed_ice
fill 181 212 305 181 212 306 minecraft:packed_ice
setblock 181 212 307 minecraft:snow_block
fill 181 212 308 181 215 308 minecraft:packed_ice
fill 182 212 297 182 212 300 minecraft:packed_ice
setblock 182 212 301 minecraft:snow_block
fill 182 212 302 182 215 302 minecraft:packed_ice
fill 182 212 305 183 212 305 minecraft:packed_ice
setblock 182 212 306 minecraft:snow_block
fill 182 212 307 182 215 307 minecraft:packed_ice
fill 183 212 304 183 238 304 minecraft:packed_ice
setblock 183 212 306 minecraft:white_concrete
setblock 142 213 280 minecraft:snow_block
fill 142 213 281 142 213 284 minecraft:packed_ice
setblock 142 213 285 minecraft:snow_block
fill 142 213 286 142 216 286 minecraft:packed_ice
setblock 142 213 289 minecraft:packed_ice
fill 142 213 298 142 213 299 minecraft:packed_ice
setblock 142 213 300 minecraft:snow_block
fill 142 213 301 142 213 304 minecraft:packed_ice
setblock 142 213 305 minecraft:snow_block
fill 142 213 306 142 216 306 minecraft:packed_ice
setblock 151 213 276 minecraft:snow_block
setblock 151 213 285 minecraft:black_stained_glass
setblock 151 213 287 minecraft:light_blue_stained_glass
setblock 151 213 289 minecraft:black_stained_glass
setblock 151 213 291 minecraft:black_stained_glass
setblock 151 213 293 minecraft:light_blue_stained_glass
setblock 151 213 295 minecraft:light_blue_stained_glass
setblock 151 213 297 minecraft:light_blue_stained_glass
fill 152 213 276 154 213 277 minecraft:packed_ice
setblock 152 213 284 minecraft:black_stained_glass
setblock 152 213 299 minecraft:sea_lantern
setblock 153 213 278 minecraft:packed_ice
setblock 154 213 278 minecraft:snow_block
setblock 154 213 284 minecraft:sea_lantern
setblock 154 213 299 minecraft:black_stained_glass
fill 154 213 317 154 234 317 minecraft:packed_ice
setblock 155 213 276 minecraft:packed_ice
setblock 155 213 277 minecraft:snow_block
fill 155 213 278 158 213 278 minecraft:packed_ice
setblock 156 213 276 minecraft:snow_block
fill 156 213 277 159 213 277 minecraft:packed_ice
setblock 156 213 284 minecraft:sea_lantern
setblock 156 213 299 minecraft:light_blue_stained_glass
setblock 156 213 316 minecraft:snow_block
fill 157 213 276 160 213 276 minecraft:packed_ice
fill 157 213 316 158 215 316 minecraft:packed_ice
setblock 158 213 284 minecraft:light_blue_stained_glass
setblock 158 213 299 minecraft:black_stained_glass
setblock 160 213 277 minecraft:snow_block
setblock 160 213 284 minecraft:black_stained_glass
setblock 160 213 299 minecraft:black_stained_glass
setblock 161 213 276 minecraft:snow_block
fill 162 213 276 162 214 276 minecraft:packed_ice
setblock 162 213 284 minecraft:black_stained_glass
setblock 162 213 299 minecraft:sea_lantern
setblock 164 213 284 minecraft:sea_lantern
setblock 164 213 299 minecraft:sea_lantern
fill 165 213 307 165 216 308 minecraft:packed_ice
setblock 166 213 285 minecraft:black_stained_glass
setblock 166 213 287 minecraft:light_blue_stained_glass
setblock 166 213 289 minecraft:light_blue_stained_glass
setblock 166 213 291 minecraft:black_stained_glass
setblock 166 213 293 minecraft:sea_lantern
setblock 166 213 295 minecraft:light_blue_stained_glass
setblock 166 213 297 minecraft:black_stained_glass
fill 166 213 306 166 216 306 minecraft:packed_ice
fill 167 213 310 168 216 310 minecraft:packed_ice
fill 169 213 306 169 216 306 minecraft:packed_ice
fill 169 213 309 169 216 309 minecraft:packed_ice
setblock 171 213 276 minecraft:snow_block
setblock 171 213 316 minecraft:snow_block
fill 172 213 276 175 213 276 minecraft:packed_ice
fill 172 213 316 175 213 316 minecraft:packed_ice
setblock 176 213 276 minecraft:snow_block
setblock 176 213 316 minecraft:snow_block
setblock 177 213 276 minecraft:packed_ice
fill 177 213 316 178 214 316 minecraft:packed_ice
setblock 180 213 301 minecraft:packed_ice
setblock 180 213 302 minecraft:snow_block
fill 180 213 303 180 213 306 minecraft:packed_ice
setblock 180 213 307 minecraft:snow_block
fill 181 213 299 181 213 300 minecraft:packed_ice
setblock 181 213 301 minecraft:snow_block
fill 181 213 302 181 216 302 minecraft:packed_ice
setblock 181 213 305 minecraft:packed_ice
setblock 181 213 306 minecraft:snow_block
fill 181 213 307 181 216 307 minecraft:packed_ice
fill 182 213 298 182 213 299 minecraft:packed_ice
setblock 182 213 300 minecraft:snow_block
fill 182 213 301 182 216 301 minecraft:packed_ice
setblock 182 213 305 minecraft:snow_block
fill 182 213 306 183 216 306 minecraft:packed_ice
setblock 182 213 310 minecraft:snow_block
fill 183 213 305 183 237 305 minecraft:packed_ice
fill 142 214 281 142 214 283 minecraft:packed_ice
setblock 142 214 284 minecraft:snow_block
fill 142 214 285 142 217 285 minecraft:packed_ice
setblock 142 214 289 minecraft:snow_block
fill 142 214 290 142 217 290 minecraft:packed_ice
setblock 142 214 299 minecraft:snow_block
fill 142 214 300 142 214 303 minecraft:packed_ice
setblock 142 214 304 minecraft:snow_block
fill 142 214 305 142 217 305 minecraft:packed_ice
setblock 148 214 290 minecraft:blue_ice
setblock 148 214 292 minecraft:blue_ice
setblock 150 214 276 minecraft:snow_block
setblock 150 214 290 minecraft:blue_ice
setblock 150 214 292 minecraft:blue_ice
fill 151 214 276 154 214 276 minecraft:packed_ice
fill 151 214 285 151 215 285 minecraft:gray_concrete
fill 151 214 287 151 215 287 minecraft:gray_concrete
fill 151 214 289 151 215 289 minecraft:gray_concrete
fill 151 214 291 151 215 291 minecraft:gray_concrete
fill 151 214 293 151 215 293 minecraft:gray_concrete
fill 151 214 295 151 215 295 minecraft:gray_concrete
fill 151 214 297 151 215 297 minecraft:gray_concrete
fill 152 214 277 153 214 277 minecraft:packed_ice
fill 152 214 284 152 215 284 minecraft:gray_concrete
fill 152 214 299 152 215 299 minecraft:gray_concrete
setblock 153 214 278 minecraft:snow_block
setblock 154 214 277 minecraft:snow_block
fill 154 214 278 157 214 278 minecraft:packed_ice
fill 154 214 284 154 215 284 minecraft:gray_concrete
fill 154 214 299 154 215 299 minecraft:gray_concrete
setblock 155 214 276 minecraft:snow_block
fill 155 214 277 158 214 277 minecraft:packed_ice
setblock 155 214 316 minecraft:snow_block
fill 156 214 276 159 214 276 minecraft:packed_ice
fill 156 214 284 156 215 284 minecraft:gray_concrete
fill 156 214 299 156 215 299 minecraft:gray_concrete
fill 156 214 316 156 217 316 minecraft:packed_ice
setblock 157 214 281 minecraft:blue_ice
setblock 157 214 283 minecraft:blue_ice
setblock 157 214 301 minecraft:blue_ice
fill 158 214 284 158 215 284 minecraft:gray_concrete
fill 158 214 299 158 215 299 minecraft:gray_concrete
setblock 159 214 277 minecraft:snow_block
setblock 159 214 281 minecraft:blue_ice
setblock 159 214 283 minecraft:blue_ice
setblock 159 214 301 minecraft:blue_ice
setblock 160 214 276 minecraft:snow_block
setblock 160 214 277 minecraft:packed_ice
fill 160 214 284 160 215 284 minecraft:gray_concrete
fill 160 214 299 160 215 299 minecraft:gray_concrete
fill 161 214 276 161 216 276 minecraft:packed_ice
fill 162 214 284 162 215 284 minecraft:gray_concrete
fill 162 214 299 162 215 299 minecraft:gray_concrete
fill 164 214 284 164 215 284 minecraft:gray_concrete
fill 164 214 299 164 215 299 minecraft:gray_concrete
fill 165 214 306 165 216 306 minecraft:packed_ice
fill 165 214 309 165 216 309 minecraft:packed_ice
fill 166 214 285 166 215 285 minecraft:gray_concrete
fill 166 214 287 166 215 287 minecraft:gray_concrete
fill 166 214 289 166 215 289 minecraft:gray_concrete
fill 166 214 291 166 215 291 minecraft:gray_concrete
fill 166 214 293 166 215 293 minecraft:gray_concrete
fill 166 214 295 166 215 295 minecraft:gray_concrete
fill 166 214 297 166 215 297 minecraft:gray_concrete
fill 166 214 305 168 216 305 minecraft:packed_ice
fill 166 214 310 166 216 310 minecraft:packed_ice
setblock 168 214 290 minecraft:blue_ice
setblock 168 214 292 minecraft:blue_ice
fill 169 214 310 169 216 310 minecraft:packed_ice
fill 170 214 307 170 216 308 minecraft:packed_ice
setblock 170 214 316 minecraft:snow_block
fill 171 214 316 174 214 316 minecraft:packed_ice
fill 172 214 276 174 214 276 minecraft:packed_ice
fill 174 214 312 174 223 312 minecraft:packed_ice
setblock 175 214 276 minecraft:snow_block
setblock 175 214 316 minecraft:snow_block
setblock 176 214 276 minecraft:packed_ice
fill 176 214 316 176 217 316 minecraft:packed_ice
fill 180 214 302 180 214 305 minecraft:packed_ice
setblock 180 214 306 minecraft:snow_block
fill 180 214 307 180 217 307 minecraft:packed_ice
setblock 181 214 300 minecraft:snow_block
fill 181 214 301 181 216 301 minecraft:packed_ice
setblock 181 214 304 minecraft:packed_ice
setblock 181 214 305 minecraft:snow_block
fill 181 214 306 181 217 306 minecraft:packed_ice
setblock 181 214 309 minecraft:packed_ice
setblock 182 214 298 minecraft:packed_ice
setblock 182 214 299 minecraft:snow_block
fill 182 214 300 182 217 300 minecraft:packed_ice
setblock 182 214 304 minecraft:snow_block
fill 182 214 305 182 217 305 minecraft:packed_ice
setblock 182 214 309 minecraft:snow_block
fill 182 214 310 182 217 310 minecraft:packed_ice
fill 142 215 278 142 218 280 minecraft:blue_ice
fill 142 215 281 142 215 282 minecraft:packed_ice
setblock 142 215 283 minecraft:snow_block
fill 142 215 284 143 217 284 minecraft:packed_ice
setblock 142 215 288 minecraft:snow_block
fill 142 215 289 142 218 289 minecraft:packed_ice
fill 142 215 291 142 216 291 minecraft:packed_ice
fill 142 215 300 142 215 302 minecraft:packed_ice
setblock 142 215 303 minecraft:snow_block
fill 142 215 304 142 218 304 minecraft:packed_ice
fill 143 215 279 143 218 279 minecraft:blue_ice
fill 143 215 285 143 215 286 minecraft:packed_ice
fill 150 215 276 153 215 276 minecraft:packed_ice
fill 151 215 277 152 215 277 minecraft:packed_ice
setblock 153 215 277 minecraft:snow_block
fill 153 215 278 156 215 278 minecraft:packed_ice
setblock 153 215 316 minecraft:packed_ice
setblock 154 215 276 minecraft:snow_block
fill 154 215 277 157 215 277 minecraft:packed_ice
setblock 154 215 316 minecraft:snow_block
fill 155 215 276 158 215 276 minecraft:packed_ice
fill 155 215 316 155 218 316 minecraft:packed_ice
setblock 157 215 278 minecraft:snow_block
setblock 158 215 277 minecraft:snow_block
setblock 159 215 276 minecraft:snow_block
setblock 159 215 277 minecraft:packed_ice
setblock 159 215 316 minecraft:snow_block
fill 160 215 276 160 218 276 minecraft:packed_ice
setblock 164 215 275 minecraft:white_concrete
fill 164 215 307 164 216 308 minecraft:packed_ice
fill 165 215 310 165 216 310 minecraft:packed_ice
fill 167 215 311 168 216 311 minecraft:packed_ice
fill 169 215 305 169 216 305 minecraft:packed_ice
setblock 169 215 316 minecraft:snow_block
fill 170 215 306 170 216 306 minecraft:packed_ice
fill 170 215 309 170 216 309 minecraft:packed_ice
fill 170 215 316 173 215 316 minecraft:packed_ice
fill 171 215 276 173 215 276 minecraft:packed_ice
fill 172 215 315 174 215 315 minecraft:packed_ice
setblock 174 215 276 minecraft:snow_block
setblock 174 215 316 minecraft:snow_block
fill 175 215 276 175 218 276 minecraft:packed_ice
setblock 175 215 315 minecraft:snow_block
fill 175 215 316 175 218 316 minecraft:packed_ice
fill 176 215 278 176 223 278 minecraft:snow_block
fill 177 215 316 177 216 316 minecraft:packed_ice
fill 180 215 303 180 215 304 minecraft:packed_ice
setblock 180 215 305 minecraft:snow_block
fill 180 215 306 180 218 306 minecraft:packed_ice
setblock 181 215 304 minecraft:snow_block
fill 181 215 305 181 218 305 minecraft:packed_ice
setblock 181 215 309 minecraft:snow_block
fill 182 215 284 182 215 287 minecraft:packed_ice
setblock 182 215 298 minecraft:snow_block
fill 182 215 299 182 218 299 minecraft:packed_ice
setblock 182 215 303 minecraft:snow_block
fill 182 215 304 182 218 304 minecraft:packed_ice
setblock 182 215 308 minecraft:snow_block
fill 182 215 309 182 218 309 minecraft:packed_ice
setblock 183 215 302 minecraft:light_blue_concrete
fill 183 215 303 183 237 303 minecraft:packed_ice
setblock 142 216 281 minecraft:packed_ice
setblock 142 216 282 minecraft:snow_block
fill 142 216 283 143 218 283 minecraft:packed_ice
setblock 142 216 287 minecraft:snow_block
fill 142 216 288 143 218 288 minecraft:packed_ice
setblock 142 216 292 minecraft:snow_block
setblock 142 216 301 minecraft:packed_ice
setblock 142 216 302 minecraft:snow_block
fill 142 216 303 142 218 303 minecraft:packed_ice
setblock 142 216 307 minecraft:snow_block
fill 142 216 308 142 219 308 minecraft:packed_ice
fill 143 216 278 144 218 278 minecraft:blue_ice
fill 143 216 280 144 218 280 minecraft:blue_ice
setblock 143 216 285 minecraft:packed_ice
setblock 143 216 286 minecraft:snow_block
fill 143 216 287 143 219 287 minecraft:packed_ice
fill 144 216 279 145 218 279 minecraft:blue_ice
setblock 144 216 285 minecraft:light[level=12]
setblock 144 216 286 minecraft:light[level=15]
setblock 144 216 292 minecraft:light[level=12]
setblock 144 216 294 minecraft:light[level=15]
setblock 144 216 299 minecraft:light[level=12]
setblock 144 216 302 minecraft:light[level=15]
setblock 144 216 306 minecraft:light[level=12]
setblock 144 216 310 minecraft:light[level=15]
setblock 144 216 313 minecraft:light[level=12]
fill 149 216 276 152 216 276 minecraft:packed_ice
fill 150 216 277 151 216 277 minecraft:packed_ice
setblock 151 216 278 minecraft:light[level=12]
setblock 151 216 285 minecraft:black_stained_glass
setblock 151 216 287 minecraft:black_stained_glass
setblock 151 216 289 minecraft:black_stained_glass
setblock 151 216 291 minecraft:black_stained_glass
setblock 151 216 293 minecraft:light_blue_stained_glass
setblock 151 216 295 minecraft:black_stained_glass
setblock 151 216 297 minecraft:light_blue_stained_glass
setblock 151 216 306 minecraft:light[level=12]
setblock 151 216 313 minecraft:light[level=12]
setblock 152 216 277 minecraft:snow_block
fill 152 216 278 155 216 278 minecraft:packed_ice
setblock 152 216 284 minecraft:light_blue_stained_glass
setblock 152 216 299 minecraft:black_stained_glass
setblock 152 216 302 minecraft:light[level=15]
setblock 152 216 310 minecraft:light[level=15]
setblock 152 216 316 minecraft:packed_ice
setblock 153 216 276 minecraft:snow_block
fill 153 216 277 156 216 277 minecraft:packed_ice
setblock 153 216 316 minecraft:snow_block
fill 154 216 276 157 216 276 minecraft:packed_ice
setblock 154 216 284 minecraft:light_blue_stained_glass
setblock 154 216 299 minecraft:sea_lantern
fill 154 216 316 154 219 316 minecraft:packed_ice
setblock 156 216 278 minecraft:snow_block
fill 156 216 280 157 217 281 minecraft:snow_block
setblock 156 216 284 minecraft:black_stained_glass
setblock 156 216 299 minecraft:light_blue_stained_glass
setblock 157 216 277 minecraft:snow_block
setblock 157 216 316 minecraft:packed_ice
setblock 158 216 276 minecraft:snow_block
fill 158 216 277 158 218 277 minecraft:packed_ice
setblock 158 216 278 minecraft:light[level=12]
setblock 158 216 284 minecraft:sea_lantern
setblock 158 216 299 minecraft:sea_lantern
setblock 158 216 306 minecraft:light[level=12]
setblock 158 216 313 minecraft:light[level=12]
setblock 158 216 316 minecraft:snow_block
fill 159 216 276 159 219 276 minecraft:packed_ice
fill 159 216 316 159 219 316 minecraft:packed_ice
setblock 160 216 278 minecraft:light[level=15]
setblock 160 216 284 minecraft:light_blue_stained_glass
setblock 160 216 299 minecraft:sea_lantern
setblock 160 216 302 minecraft:light[level=15]
setblock 160 216 310 minecraft:light[level=15]
setblock 162 216 284 minecraft:light_blue_stained_glass
setblock 162 216 299 minecraft:black_stained_glass
fill 164 216 275 164 237 275 minecraft:packed_ice
setblock 164 216 284 minecraft:light_blue_stained_glass
setblock 164 216 299 minecraft:sea_lantern
setblock 164 216 306 minecraft:packed_ice
setblock 164 216 309 minecraft:packed_ice
setblock 165 216 278 minecraft:light[level=12]
setblock 165 216 305 minecraft:packed_ice
setblock 165 216 313 minecraft:light[level=12]
setblock 166 216 285 minecraft:light_blue_stained_glass
setblock 166 216 287 minecraft:black_stained_glass
setblock 166 216 289 minecraft:black_stained_glass
setblock 166 216 291 minecraft:black_stained_glass
setblock 166 216 293 minecraft:black_stained_glass
setblock 166 216 295 minecraft:black_stained_glass
setblock 166 216 297 minecraft:sea_lantern
fill 166 216 304 168 216 304 minecraft:packed_ice
setblock 166 216 311 minecraft:packed_ice
setblock 167 216 275 minecraft:light_blue_concrete
setblock 167 216 316 minecraft:packed_ice
setblock 168 216 278 minecraft:light[level=15]
setblock 168 216 286 minecraft:light[level=15]
setblock 168 216 294 minecraft:light[level=15]
setblock 168 216 302 minecraft:light[level=15]
setblock 168 216 316 minecraft:snow_block
setblock 169 216 311 minecraft:packed_ice
fill 169 216 316 172 216 316 minecraft:packed_ice
fill 170 216 276 172 216 276 minecraft:packed_ice
setblock 170 216 305 minecraft:packed_ice
setblock 170 216 310 minecraft:packed_ice
fill 170 216 315 173 216 315 minecraft:packed_ice
fill 171 216 307 171 216 309 minecraft:packed_ice
setblock 172 216 278 minecraft:light[level=12]
setblock 172 216 285 minecraft:light[level=12]
setblock 172 216 292 minecraft:light[level=12]
setblock 172 216 299 minecraft:light[level=12]
setblock 172 216 306 minecraft:light[level=12]
setblock 172 216 313 minecraft:light[level=12]
setblock 173 216 276 minecraft:snow_block
setblock 173 216 316 minecraft:snow_block
fill 174 216 276 174 219 276 minecraft:packed_ice
setblock 174 216 315 minecraft:snow_block
fill 174 216 316 174 219 316 minecraft:packed_ice
fill 175 216 315 176 218 315 minecraft:packed_ice
setblock 176 216 286 minecraft:light[level=15]
setblock 176 216 294 minecraft:light[level=15]
setblock 176 216 302 minecraft:light[level=15]
setblock 176 216 310 minecraft:light[level=15]
setblock 178 216 316 minecraft:snow_block
setblock 179 216 278 minecraft:light[level=12]
setblock 179 216 285 minecraft:light[level=12]
setblock 179 216 292 minecraft:light[level=12]
setblock 179 216 299 minecraft:light[level=12]
setblock 179 216 306 minecraft:light[level=12]
setblock 179 216 313 minecraft:light[level=12]
setblock 180 216 303 minecraft:packed_ice
setblock 180 216 304 minecraft:snow_block
fill 180 216 305 180 218 305 minecraft:packed_ice
setblock 180 216 308 minecraft:packed_ice
setblock 181 216 303 minecraft:snow_block
fill 181 216 304 181 219 304 minecraft:packed_ice
setblock 181 216 308 minecraft:snow_block
fill 181 216 309 181 218 310 minecraft:packed_ice
fill 182 216 283 182 216 286 minecraft:packed_ice
setblock 182 216 287 minecraft:snow_block
fill 182 216 288 182 217 290 minecraft:packed_ice
setblock 182 216 302 minecraft:snow_block
fill 182 216 303 182 219 303 minecraft:packed_ice
setblock 182 216 307 minecraft:snow_block
fill 182 216 308 182 219 308 minecraft:packed_ice
setblock 182 216 311 minecraft:packed_ice
fill 183 216 302 183 237 302 minecraft:packed_ice
setblock 141 217 291 minecraft:light_blue_concrete
setblock 141 217 299 minecraft:light_blue_concrete
setblock 142 217 281 minecraft:snow_block
fill 142 217 282 142 220 282 minecraft:packed_ice
setblock 142 217 286 minecraft:snow_block
fill 142 217 287 142 220 287 minecraft:packed_ice
setblock 142 217 291 minecraft:snow_block
fill 142 217 292 142 219 293 minecraft:packed_ice
setblock 142 217 302 minecraft:packed_ice
setblock 142 217 306 minecraft:snow_block
fill 142 217 307 142 220 307 minecraft:packed_ice
setblock 143 217 285 minecraft:snow_block
fill 143 217 286 143 220 286 minecraft:packed_ice
setblock 143 217 289 minecraft:packed_ice
setblock 143 217 290 minecraft:snow_block
fill 145 217 278 145 218 278 minecraft:blue_ice
fill 145 217 280 145 218 280 minecraft:blue_ice
fill 146 217 279 147 218 279 minecraft:blue_ice
fill 148 217 276 151 217 276 minecraft:packed_ice
fill 149 217 277 149 217 278 minecraft:blue_ice
setblock 150 217 277 minecraft:packed_ice
fill 150 217 316 151 217 316 minecraft:packed_ice
setblock 151 217 277 minecraft:snow_block
fill 151 217 278 154 217 278 minecraft:packed_ice
fill 151 217 285 151 218 285 minecraft:gray_concrete
fill 151 217 287 151 218 287 minecraft:gray_concrete
fill 151 217 289 151 218 289 minecraft:gray_concrete
fill 151 217 291 151 218 291 minecraft:gray_concrete
fill 151 217 293 151 218 293 minecraft:gray_concrete
fill 151 217 295 151 218 295 minecraft:gray_concrete
fill 151 217 297 151 218 297 minecraft:gray_concrete
setblock 152 217 275 minecraft:white_concrete
setblock 152 217 276 minecraft:snow_block
fill 152 217 277 155 217 277 minecraft:packed_ice
fill 152 217 284 152 218 284 minecraft:gray_concrete
fill 152 217 299 152 218 299 minecraft:gray_concrete
fill 152 217 311 152 218 311 minecraft:packed_ice
setblock 152 217 316 minecraft:snow_block
fill 153 217 276 156 217 276 minecraft:packed_ice
fill 153 217 310 153 218 310 minecraft:packed_ice
fill 153 217 312 153 218 312 minecraft:packed_ice
fill 153 217 316 153 220 316 minecraft:packed_ice
fill 154 217 284 154 218 284 minecraft:gray_concrete
fill 154 217 299 154 218 299 minecraft:gray_concrete
fill 154 217 311 154 218 311 minecraft:packed_ice
fill 154 217 315 156 218 315 minecraft:packed_ice
setblock 155 217 278 minecraft:snow_block
setblock 156 217 277 minecraft:snow_block
setblock 156 217 278 minecraft:packed_ice
fill 156 217 284 156 218 284 minecraft:gray_concrete
fill 156 217 299 156 218 299 minecraft:gray_concrete
setblock 157 217 276 minecraft:snow_block
fill 157 217 277 157 219 277 minecraft:packed_ice
setblock 157 217 316 minecraft:snow_block
fill 158 217 276 158 220 276 minecraft:packed_ice
fill 158 217 284 158 218 284 minecraft:gray_concrete
fill 158 217 299 158 218 299 minecraft:gray_concrete
fill 158 217 316 158 220 316 minecraft:packed_ice
fill 160 217 284 160 218 284 minecraft:gray_concrete
fill 160 217 299 160 218 299 minecraft:gray_concrete
fill 160 217 316 161 217 316 minecraft:packed_ice
fill 162 217 284 162 218 284 minecraft:gray_concrete
fill 162 217 299 162 218 299 minecraft:gray_concrete
fill 164 217 284 164 218 284 minecraft:gray_concrete
fill 164 217 299 164 218 299 minecraft:gray_concrete
fill 165 217 316 166 217 316 minecraft:packed_ice
fill 166 217 285 166 218 285 minecraft:gray_concrete
fill 166 217 287 166 218 287 minecraft:gray_concrete
fill 166 217 289 166 218 289 minecraft:gray_concrete
fill 166 217 291 166 218 291 minecraft:gray_concrete
fill 166 217 293 166 218 293 minecraft:gray_concrete
fill 166 217 295 166 218 295 minecraft:gray_concrete
fill 166 217 297 166 218 297 minecraft:gray_concrete
setblock 166 217 317 minecraft:light_blue_concrete
fill 167 217 275 167 237 275 minecraft:packed_ice
fill 167 217 307 168 218 308 minecraft:blue_ice
setblock 167 217 316 minecraft:snow_block
setblock 168 217 315 minecraft:snow_block
fill 168 217 316 171 217 316 minecraft:packed_ice
fill 169 217 276 171 217 276 minecraft:packed_ice
fill 169 217 315 172 217 315 minecraft:packed_ice
fill 171 217 314 173 217 314 minecraft:packed_ice
setblock 172 217 276 minecraft:snow_block
setblock 172 217 316 minecraft:snow_block
fill 173 217 276 173 220 276 minecraft:packed_ice
setblock 173 217 315 minecraft:snow_block
fill 173 217 316 173 220 316 minecraft:packed_ice
setblock 174 217 314 minecraft:snow_block
fill 174 217 315 174 220 315 minecraft:packed_ice
fill 175 217 312 175 218 312 minecraft:packed_ice
fill 176 217 311 176 218 311 minecraft:packed_ice
fill 176 217 313 176 218 313 minecraft:packed_ice
fill 177 217 312 177 218 312 minecraft:packed_ice
setblock 177 217 316 minecraft:snow_block
fill 178 217 316 178 220 316 minecraft:packed_ice
setblock 180 217 304 minecraft:packed_ice
setblock 180 217 308 minecraft:snow_block
setblock 181 217 302 minecraft:snow_block
fill 181 217 303 181 219 303 minecraft:packed_ice
setblock 181 217 307 minecraft:snow_block
fill 181 217 308 181 220 308 minecraft:packed_ice
fill 182 217 283 182 217 285 minecraft:packed_ice
setblock 182 217 286 minecraft:snow_block
fill 182 217 287 182 220 287 minecraft:packed_ice
setblock 182 217 291 minecraft:snow_block
fill 182 217 292 182 220 292 minecraft:packed_ice
fill 182 217 298 182 219 298 minecraft:packed_ice
setblock 182 217 301 minecraft:snow_block
fill 182 217 302 182 220 302 minecraft:packed_ice
setblock 182 217 306 minecraft:snow_block
fill 182 217 307 182 220 307 minecraft:packed_ice
setblock 182 217 311 minecraft:snow_block
fill 183 217 306 183 237 306 minecraft:packed_ice
fill 141 218 291 143 220 291 minecraft:packed_ice
fill 141 218 299 141 234 299 minecraft:packed_ice
fill 142 218 281 142 221 281 minecraft:packed_ice
setblock 142 218 284 minecraft:packed_ice
setblock 142 218 285 minecraft:snow_block
fill 142 218 286 142 221 286 minecraft:packed_ice
setblock 142 218 290 minecraft:snow_block
setblock 142 218 294 minecraft:packed_ice
setblock 142 218 305 minecraft:snow_block
fill 142 218 306 142 220 306 minecraft:packed_ice
setblock 142 218 309 minecraft:packed_ice
setblock 143 218 284 minecraft:snow_block
fill 143 218 285 144 220 285 minecraft:packed_ice
setblock 143 218 289 minecraft:snow_block
fill 143 218 290 143 221 290 minecraft:packed_ice
fill 144 218 286 144 218 287 minecraft:packed_ice
setblock 144 218 288 minecraft:snow_block
setblock 146 218 278 minecraft:blue_ice
setblock 146 218 280 minecraft:blue_ice
fill 147 218 276 150 218 276 minecraft:packed_ice
fill 148 218 277 148 218 279 minecraft:blue_ice
setblock 149 218 277 minecraft:packed_ice
fill 149 218 278 149 218 281 minecraft:blue_ice
fill 149 218 316 150 218 316 minecraft:packed_ice
setblock 150 218 277 minecraft:snow_block
fill 150 218 278 150 218 279 minecraft:blue_ice
setblock 151 218 276 minecraft:snow_block
fill 151 218 277 153 218 278 minecraft:packed_ice
setblock 151 218 315 minecraft:packed_ice
setblock 151 218 316 minecraft:snow_block
fill 152 218 275 152 221 276 minecraft:packed_ice
setblock 152 218 315 minecraft:snow_block
fill 152 218 316 152 221 316 minecraft:packed_ice
fill 153 218 276 155 218 276 minecraft:packed_ice
fill 153 218 315 153 221 315 minecraft:packed_ice
setblock 154 218 277 minecraft:packed_ice
setblock 154 218 278 minecraft:snow_block
setblock 155 218 277 minecraft:snow_block
fill 155 218 278 155 219 278 minecraft:packed_ice
setblock 156 218 275 minecraft:white_concrete
setblock 156 218 276 minecraft:snow_block
fill 156 218 277 156 221 277 minecraft:packed_ice
setblock 156 218 316 minecraft:snow_block
fill 157 218 276 157 221 276 minecraft:packed_ice
setblock 157 218 315 minecraft:snow_block
fill 157 218 316 157 221 316 minecraft:packed_ice
setblock 160 218 316 minecraft:packed_ice
setblock 161 218 316 minecraft:snow_block
fill 162 218 316 162 221 317 minecraft:packed_ice
fill 163 218 316 165 218 316 minecraft:packed_ice
setblock 163 218 317 minecraft:light_blue_concrete
setblock 166 218 316 minecraft:snow_block
fill 166 218 317 166 237 317 minecraft:packed_ice
setblock 167 218 315 minecraft:snow_block
fill 167 218 316 170 218 316 minecraft:packed_ice
fill 168 218 276 170 218 276 minecraft:packed_ice
fill 168 218 315 171 218 315 minecraft:packed_ice
fill 169 218 314 172 218 314 minecraft:packed_ice
setblock 171 218 276 minecraft:snow_block
setblock 171 218 316 minecraft:snow_block
fill 172 218 276 172 221 276 minecraft:packed_ice
fill 172 218 313 173 218 313 minecraft:packed_ice
setblock 172 218 315 minecraft:snow_block
fill 172 218 316 172 221 316 minecraft:packed_ice
setblock 173 218 314 minecraft:snow_block
fill 173 218 315 173 221 315 minecraft:packed_ice
fill 174 218 314 175 220 314 minecraft:packed_ice
fill 176 218 275 176 237 275 minecraft:packed_ice
setblock 176 218 316 minecraft:snow_block
setblock 177 218 275 minecraft:light_blue_concrete
fill 177 218 316 177 221 316 minecraft:packed_ice
setblock 180 218 307 minecraft:snow_block
fill 180 218 308 180 219 308 minecraft:packed_ice
setblock 181 218 286 minecraft:snow_block
fill 181 218 287 181 219 289 minecraft:packed_ice
setblock 181 218 302 minecraft:packed_ice
setblock 181 218 306 minecraft:snow_block
fill 181 218 307 181 221 307 minecraft:packed_ice
fill 182 218 283 182 218 284 minecraft:packed_ice
setblock 182 218 285 minecraft:snow_block
fill 182 218 286 182 221 286 minecraft:packed_ice
fill 182 218 288 182 218 289 minecraft:packed_ice
setblock 182 218 290 minecraft:snow_block
fill 182 218 291 182 221 291 minecraft:packed_ice
fill 182 218 293 182 218 294 minecraft:packed_ice
setblock 182 218 295 minecraft:snow_block
setblock 182 218 300 minecraft:snow_block
fill 182 218 301 182 220 301 minecraft:packed_ice
setblock 182 218 305 minecraft:snow_block
fill 182 218 306 182 221 306 minecraft:packed_ice
setblock 182 218 310 minecraft:snow_block
fill 182 218 311 182 220 312 minecraft:packed_ice
setblock 142 219 283 minecraft:packed_ice
setblock 142 219 284 minecraft:snow_block
fill 142 219 285 142 222 285 minecraft:packed_ice
setblock 142 219 288 minecraft:packed_ice
setblock 142 219 289 minecraft:snow_block
fill 142 219 290 142 222 290 minecraft:packed_ice
setblock 142 219 294 minecraft:snow_block
fill 142 219 295 142 222 295 minecraft:packed_ice
setblock 142 219 304 minecraft:snow_block
setblock 142 219 305 minecraft:packed_ice
setblock 142 219 309 minecraft:snow_block
fill 142 219 310 142 221 310 minecraft:packed_ice
setblock 143 219 283 minecraft:snow_block
fill 143 219 284 143 222 284 minecraft:packed_ice
setblock 143 219 288 minecraft:snow_block
fill 143 219 289 144 221 289 minecraft:packed_ice
setblock 143 219 292 minecraft:packed_ice
setblock 144 219 286 minecraft:packed_ice
setblock 144 219 287 minecraft:snow_block
fill 144 219 288 144 222 288 minecraft:packed_ice
fill 147 219 276 149 219 276 minecraft:packed_ice
setblock 147 219 317 minecraft:light_blue_concrete
setblock 148 219 277 minecraft:packed_ice
fill 148 219 278 149 219 278 minecraft:blue_ice
fill 148 219 316 149 219 316 minecraft:packed_ice
setblock 149 219 277 minecraft:snow_block
fill 149 219 279 149 219 280 minecraft:blue_ice
setblock 150 219 276 minecraft:snow_block
fill 150 219 277 152 219 278 minecraft:packed_ice
setblock 150 219 315 minecraft:packed_ice
setblock 150 219 316 minecraft:snow_block
fill 151 219 276 151 222 276 minecraft:packed_ice
setblock 151 219 285 minecraft:sea_lantern
setblock 151 219 287 minecraft:black_stained_glass
setblock 151 219 289 minecraft:sea_lantern
setblock 151 219 291 minecraft:sea_lantern
setblock 151 219 293 minecraft:sea_lantern
setblock 151 219 295 minecraft:light_blue_stained_glass
setblock 151 219 297 minecraft:sea_lantern
setblock 151 219 315 minecraft:snow_block
fill 151 219 316 151 222 316 minecraft:packed_ice
setblock 152 219 284 minecraft:black_stained_glass
setblock 152 219 299 minecraft:black_stained_glass
fill 152 219 315 152 222 315 minecraft:packed_ice
fill 153 219 276 153 219 277 minecraft:packed_ice
setblock 153 219 278 minecraft:snow_block
fill 153 219 314 154 221 314 minecraft:packed_ice
setblock 154 219 276 minecraft:packed_ice
setblock 154 219 277 minecraft:snow_block
fill 154 219 278 154 220 278 minecraft:packed_ice
setblock 154 219 284 minecraft:light_blue_stained_glass
setblock 154 219 299 minecraft:black_stained_glass
fill 154 219 315 155 219 315 minecraft:packed_ice
setblock 155 219 276 minecraft:snow_block
fill 155 219 277 155 222 277 minecraft:packed_ice
setblock 155 219 316 minecraft:snow_block
fill 156 219 275 156 222 276 minecraft:packed_ice
setblock 156 219 284 minecraft:black_stained_glass
setblock 156 219 299 minecraft:sea_lantern
setblock 156 219 315 minecraft:snow_block
fill 156 219 316 156 222 316 minecraft:packed_ice
fill 157 219 315 158 221 315 minecraft:packed_ice
setblock 158 219 284 minecraft:black_stained_glass
setblock 158 219 299 minecraft:black_stained_glass
setblock 160 219 276 minecraft:snow_block
setblock 160 219 284 minecraft:black_stained_glass
setblock 160 219 299 minecraft:black_stained_glass
setblock 160 219 316 minecraft:snow_block
fill 161 219 316 161 222 316 minecraft:packed_ice
setblock 162 219 284 minecraft:sea_lantern
setblock 162 219 299 minecraft:black_stained_glass
fill 163 219 316 163 220 317 minecraft:packed_ice
setblock 164 219 284 minecraft:sea_lantern
setblock 164 219 299 minecraft:light_blue_stained_glass
setblock 164 219 316 minecraft:packed_ice
setblock 165 219 315 minecraft:packed_ice
setblock 165 219 316 minecraft:snow_block
setblock 166 219 285 minecraft:black_stained_glass
setblock 166 219 287 minecraft:black_stained_glass
setblock 166 219 289 minecraft:black_stained_glass
setblock 166 219 291 minecraft:light_blue_stained_glass
setblock 166 219 293 minecraft:black_stained_glass
setblock 166 219 295 minecraft:sea_lantern
setblock 166 219 297 minecraft:light_blue_stained_glass
setblock 166 219 315 minecraft:snow_block
fill 166 219 316 169 219 316 minecraft:packed_ice
fill 167 219 276 169 219 276 minecraft:packed_ice
fill 167 219 307 167 219 308 minecraft:blue_ice
setblock 167 219 314 minecraft:snow_block
fill 167 219 315 170 219 315 minecraft:packed_ice
setblock 168 219 308 minecraft:blue_ice
fill 168 219 314 171 219 314 minecraft:packed_ice
fill 169 219 313 172 219 313 minecraft:packed_ice
setblock 170 219 276 minecraft:snow_block
setblock 170 219 316 minecraft:snow_block
fill 171 219 276 171 222 276 minecraft:packed_ice
setblock 171 219 315 minecraft:snow_block
fill 171 219 316 171 222 316 minecraft:packed_ice
setblock 172 219 314 minecraft:snow_block
fill 172 219 315 172 222 315 minecraft:packed_ice
setblock 173 219 313 minecraft:snow_block
fill 173 219 314 173 222 314 minecraft:packed_ice
fill 174 219 313 174 223 313 minecraft:packed_ice
setblock 175 219 315 minecraft:packed_ice
setblock 175 219 316 minecraft:snow_block
setblock 176 219 315 minecraft:snow_block
fill 176 219 316 176 222 316 minecraft:packed_ice
fill 177 219 275 177 237 275 minecraft:packed_ice
setblock 180 219 307 minecraft:packed_ice
fill 181 219 286 181 220 286 minecraft:packed_ice
setblock 181 219 290 minecraft:snow_block
fill 181 219 291 181 222 291 minecraft:packed_ice
setblock 181 219 305 minecraft:snow_block
fill 181 219 306 181 220 306 minecraft:packed_ice
setblock 181 219 309 minecraft:packed_ice
setblock 181 219 310 minecraft:snow_block
setblock 181 219 311 minecraft:packed_ice
setblock 182 219 283 minecraft:packed_ice
setblock 182 219 284 minecraft:snow_block
fill 182 219 285 182 222 285 minecraft:packed_ice
setblock 182 219 288 minecraft:packed_ice
setblock 182 219 289 minecraft:snow_block
fill 182 219 290 182 222 290 minecraft:packed_ice
setblock 182 219 293 minecraft:packed_ice
setblock 182 219 294 minecraft:snow_block
fill 182 219 295 182 220 297 minecraft:packed_ice
setblock 182 219 299 minecraft:snow_block
fill 182 219 300 182 220 300 minecraft:packed_ice
setblock 182 219 304 minecraft:snow_block
fill 182 219 305 182 222 305 minecraft:packed_ice
setblock 182 219 309 minecraft:snow_block
fill 182 219 310 182 222 310 minecraft:packed_ice
setblock 183 219 290 minecraft:light_blue_concrete
setblock 141 220 302 minecraft:light_blue_concrete
setblock 142 220 283 minecraft:snow_block
fill 142 220 284 142 223 284 minecraft:packed_ice
setblock 142 220 288 minecraft:snow_block
fill 142 220 289 142 223 289 minecraft:packed_ice
setblock 142 220 292 minecraft:packed_ice
setblock 142 220 293 minecraft:snow_block
fill 142 220 294 142 223 294 minecraft:packed_ice
setblock 142 220 308 minecraft:snow_block
fill 142 220 309 142 221 309 minecraft:packed_ice
fill 143 220 283 143 221 283 minecraft:packed_ice
setblock 143 220 287 minecraft:snow_block
fill 143 220 288 143 223 288 minecraft:packed_ice
setblock 143 220 292 minecraft:snow_block
fill 143 220 293 143 223 293 minecraft:packed_ice
setblock 144 220 286 minecraft:snow_block
fill 144 220 287 144 223 287 minecraft:packed_ice
setblock 144 220 290 minecraft:packed_ice
fill 146 220 276 148 220 276 minecraft:packed_ice
fill 147 220 316 147 221 317 minecraft:packed_ice
setblock 148 220 277 minecraft:snow_block
setblock 148 220 316 minecraft:packed_ice
setblock 149 220 276 minecraft:snow_block
fill 149 220 277 152 220 277 minecraft:packed_ice
setblock 149 220 315 minecraft:packed_ice
setblock 149 220 316 minecraft:snow_block
fill 150 220 276 150 223 276 minecraft:packed_ice
fill 150 220 278 151 220 278 minecraft:packed_ice
setblock 150 220 315 minecraft:snow_block
fill 150 220 316 150 223 316 minecraft:packed_ice
fill 151 220 285 151 223 285 minecraft:gray_concrete
fill 151 220 287 151 223 287 minecraft:gray_concrete
fill 151 220 289 151 223 289 minecraft:gray_concrete
fill 151 220 291 151 223 291 minecraft:gray_concrete
fill 151 220 293 151 223 293 minecraft:gray_concrete
fill 151 220 295 151 223 295 minecraft:gray_concrete
fill 151 220 297 151 223 297 minecraft:gray_concrete
setblock 151 220 314 minecraft:snow_block
fill 151 220 315 151 223 315 minecraft:packed_ice
setblock 152 220 278 minecraft:snow_block
fill 152 220 284 152 222 284 minecraft:gray_concrete
fill 152 220 299 152 223 299 minecraft:gray_concrete
fill 152 220 314 152 223 314 minecraft:packed_ice
setblock 153 220 276 minecraft:packed_ice
setblock 153 220 277 minecraft:snow_block
setblock 153 220 278 minecraft:packed_ice
setblock 154 220 276 minecraft:snow_block
fill 154 220 277 154 223 277 minecraft:packed_ice
fill 154 220 284 154 222 284 minecraft:gray_concrete
fill 154 220 299 154 223 299 minecraft:gray_concrete
setblock 154 220 315 minecraft:packed_ice
setblock 154 220 316 minecraft:snow_block
fill 155 220 276 155 223 276 minecraft:packed_ice
setblock 155 220 314 minecraft:packed_ice
setblock 155 220 315 minecraft:snow_block
fill 155 220 316 155 223 316 minecraft:packed_ice
fill 156 220 284 156 222 284 minecraft:gray_concrete
fill 156 220 299 156 223 299 minecraft:gray_concrete
fill 156 220 315 156 223 315 minecraft:packed_ice
fill 158 220 284 158 222 284 minecraft:gray_concrete
fill 158 220 299 158 223 299 minecraft:gray_concrete
setblock 159 220 276 minecraft:snow_block
setblock 159 220 315 minecraft:packed_ice
setblock 159 220 316 minecraft:snow_block
setblock 160 220 276 minecraft:packed_ice
fill 160 220 284 160 222 284 minecraft:gray_concrete
fill 160 220 299 160 223 299 minecraft:gray_concrete
setblock 160 220 315 minecraft:snow_block
fill 160 220 316 160 223 316 minecraft:packed_ice
fill 162 220 284 162 222 284 minecraft:gray_concrete
fill 162 220 299 162 223 299 minecraft:gray_concrete
fill 163 220 315 164 220 315 minecraft:packed_ice
fill 164 220 284 164 222 284 minecraft:gray_concrete
fill 164 220 299 164 223 299 minecraft:gray_concrete
setblock 164 220 316 minecraft:snow_block
setblock 165 220 315 minecraft:snow_block
fill 165 220 316 168 220 316 minecraft:packed_ice
fill 166 220 285 166 223 285 minecraft:gray_concrete
fill 166 220 287 166 223 287 minecraft:gray_concrete
fill 166 220 289 166 223 289 minecraft:gray_concrete
fill 166 220 291 166 223 291 minecraft:gray_concrete
fill 166 220 293 166 223 293 minecraft:gray_concrete
fill 166 220 295 166 223 295 minecraft:gray_concrete
fill 166 220 297 166 223 297 minecraft:gray_concrete
setblock 166 220 314 minecraft:snow_block
fill 166 220 315 169 220 315 minecraft:packed_ice
fill 167 220 276 168 220 276 minecraft:packed_ice
setblock 167 220 308 minecraft:blue_ice
fill 167 220 314 170 220 314 minecraft:packed_ice
fill 168 220 313 171 220 313 minecraft:packed_ice
setblock 169 220 276 minecraft:snow_block
setblock 169 220 316 minecraft:snow_block
fill 170 220 276 170 223 276 minecraft:packed_ice
setblock 170 220 315 minecraft:snow_block
fill 170 220 316 170 223 316 minecraft:packed_ice
setblock 171 220 314 minecraft:snow_block
fill 171 220 315 171 223 315 minecraft:packed_ice
setblock 172 220 313 minecraft:snow_block
fill 172 220 314 172 223 314 minecraft:packed_ice
fill 173 220 313 173 222 313 minecraft:packed_ice
setblock 174 220 276 minecraft:snow_block
setblock 174 220 316 minecraft:snow_block
setblock 175 220 315 minecraft:snow_block
fill 175 220 316 175 223 316 minecraft:packed_ice
fill 176 220 315 176 222 315 minecraft:packed_ice
fill 181 220 287 181 220 288 minecraft:packed_ice
setblock 181 220 289 minecraft:snow_block
fill 181 220 290 181 223 290 minecraft:packed_ice
fill 181 220 292 181 221 292 minecraft:packed_ice
setblock 181 220 305 minecraft:packed_ice
setblock 181 220 309 minecraft:snow_block
fill 181 220 310 181 221 310 minecraft:packed_ice
fill 182 220 284 182 221 284 minecraft:packed_ice
setblock 182 220 288 minecraft:snow_block
fill 182 220 289 182 223 289 minecraft:packed_ice
setblock 182 220 293 minecraft:snow_block
fill 182 220 294 182 223 294 minecraft:packed_ice
setblock 182 220 298 minecraft:snow_block
setblock 182 220 299 minecraft:packed_ice
setblock 182 220 303 minecraft:snow_block
fill 182 220 304 182 222 304 minecraft:packed_ice
setblock 182 220 308 minecraft:snow_block
fill 182 220 309 182 223 309 minecraft:packed_ice
setblock 182 220 313 minecraft:snow_block
fill 183 220 290 183 237 290 minecraft:packed_ice
setblock 183 220 316 minecraft:white_concrete
fill 141 221 291 142 221 291 minecraft:packed_ice
fill 141 221 302 141 230 302 minecraft:packed_ice
setblock 142 221 282 minecraft:snow_block
fill 142 221 283 142 224 283 minecraft:packed_ice
setblock 142 221 287 minecraft:snow_block
fill 142 221 288 142 224 288 minecraft:packed_ice
setblock 142 221 292 minecraft:snow_block
fill 142 221 293 142 224 293 minecraft:packed_ice
setblock 142 221 308 minecraft:packed_ice
setblock 143 221 285 minecraft:packed_ice
setblock 143 221 286 minecraft:snow_block
fill 143 221 287 143 224 287 minecraft:packed_ice
setblock 143 221 291 minecraft:snow_block
fill 143 221 292 143 224 292 minecraft:packed_ice
setblock 144 221 285 minecraft:snow_block
fill 144 221 286 144 222 286 minecraft:packed_ice
setblock 144 221 290 minecraft:snow_block
fill 144 221 291 144 224 291 minecraft:packed_ice
fill 145 221 276 147 221 276 minecraft:packed_ice
setblock 145 221 317 minecraft:light_blue_concrete
fill 146 221 316 146 222 316 minecraft:packed_ice
setblock 147 221 277 minecraft:snow_block
setblock 148 221 276 minecraft:snow_block
fill 148 221 277 151 221 277 minecraft:packed_ice
setblock 148 221 315 minecraft:packed_ice
setblock 148 221 316 minecraft:snow_block
fill 149 221 276 149 224 276 minecraft:packed_ice
setblock 149 221 315 minecraft:snow_block
fill 149 221 316 149 224 316 minecraft:packed_ice
setblock 150 221 278 minecraft:packed_ice
setblock 150 221 314 minecraft:snow_block
fill 150 221 315 150 224 315 minecraft:packed_ice
setblock 151 221 278 minecraft:snow_block
fill 151 221 314 151 224 314 minecraft:packed_ice
setblock 152 221 277 minecraft:snow_block
setblock 152 221 278 minecraft:packed_ice
setblock 153 221 276 minecraft:snow_block
fill 153 221 277 153 224 277 minecraft:packed_ice
setblock 153 221 316 minecraft:snow_block
fill 154 221 276 154 224 276 minecraft:packed_ice
setblock 154 221 315 minecraft:snow_block
fill 154 221 316 154 224 316 minecraft:packed_ice
setblock 155 221 314 minecraft:snow_block
fill 155 221 315 155 224 315 minecraft:packed_ice
setblock 158 221 276 minecraft:snow_block
setblock 158 221 316 minecraft:snow_block
setblock 159 221 276 minecraft:packed_ice
setblock 159 221 315 minecraft:snow_block
fill 159 221 316 159 224 316 minecraft:packed_ice
fill 160 221 315 163 221 315 minecraft:packed_ice
setblock 163 221 316 minecraft:snow_block
fill 163 221 317 163 222 317 minecraft:packed_ice
setblock 164 221 315 minecraft:snow_block
fill 164 221 316 167 221 316 minecraft:packed_ice
setblock 165 221 314 minecraft:snow_block
fill 165 221 315 168 221 315 minecraft:packed_ice
fill 166 221 276 167 221 276 minecraft:packed_ice
fill 166 221 314 169 221 314 minecraft:packed_ice
fill 167 221 313 170 221 313 minecraft:packed_ice
setblock 168 221 276 minecraft:snow_block
setblock 168 221 316 minecraft:snow_block
fill 169 221 276 169 224 276 minecraft:packed_ice
setblock 169 221 315 minecraft:snow_block
fill 169 221 316 169 224 316 minecraft:packed_ice
setblock 170 221 314 minecraft:snow_block
fill 170 221 315 170 224 315 minecraft:packed_ice
setblock 171 221 313 minecraft:snow_block
fill 171 221 314 171 224 314 minecraft:packed_ice
fill 172 221 313 172 223 313 minecraft:packed_ice
setblock 173 221 276 minecraft:snow_block
fill 173 221 312 173 223 312 minecraft:packed_ice
setblock 173 221 316 minecraft:snow_block
fill 174 221 311 174 223 311 minecraft:packed_ice
setblock 174 221 314 minecraft:packed_ice
setblock 174 221 315 minecraft:snow_block
fill 174 221 316 174 224 316 minecraft:packed_ice
fill 175 221 278 175 223 278 minecraft:snow_block
fill 175 221 312 175 223 312 minecraft:packed_ice
setblock 175 221 314 minecraft:snow_block
fill 175 221 315 175 223 315 minecraft:packed_ice
fill 176 221 277 176 223 277 minecraft:snow_block
fill 176 221 279 176 223 279 minecraft:snow_block
fill 177 221 278 177 223 278 minecraft:snow_block
setblock 181 221 287 minecraft:packed_ice
setblock 181 221 288 minecraft:snow_block
fill 181 221 289 181 224 289 minecraft:packed_ice
setblock 181 221 293 minecraft:snow_block
setblock 181 221 308 minecraft:snow_block
setblock 181 221 309 minecraft:packed_ice
setblock 182 221 287 minecraft:snow_block
fill 182 221 288 182 224 288 minecraft:packed_ice
setblock 182 221 292 minecraft:snow_block
fill 182 221 293 182 224 293 minecraft:packed_ice
fill 182 221 295 182 221 296 minecraft:packed_ice
setblock 182 221 297 minecraft:snow_block
setblock 182 221 298 minecraft:packed_ice
setblock 182 221 302 minecraft:snow_block
setblock 182 221 303 minecraft:packed_ice
setblock 182 221 307 minecraft:snow_block
fill 182 221 308 182 223 308 minecraft:packed_ice
setblock 182 221 311 minecraft:packed_ice
setblock 182 221 312 minecraft:snow_block
fill 182 221 313 182 222 313 minecraft:packed_ice
fill 183 221 316 183 237 316 minecraft:packed_ice
fill 141 222 291 141 238 291 minecraft:packed_ice
setblock 142 222 282 minecraft:packed_ice
setblock 142 222 286 minecraft:snow_block
fill 142 222 287 142 225 287 minecraft:packed_ice
setblock 142 222 291 minecraft:snow_block
fill 142 222 292 142 225 292 minecraft:packed_ice
setblock 143 222 285 minecraft:snow_block
fill 143 222 286 143 225 286 minecraft:packed_ice
setblock 143 222 289 minecraft:packed_ice
setblock 143 222 290 minecraft:snow_block
fill 143 222 291 143 225 291 minecraft:packed_ice
setblock 144 222 278 minecraft:light[level=12]
setblock 144 222 285 minecraft:light[level=12]
setblock 144 222 289 minecraft:snow_block
fill 144 222 290 144 225 290 minecraft:packed_ice
setblock 144 222 292 minecraft:light[level=12]
setblock 144 222 299 minecraft:light[level=12]
setblock 144 222 306 minecraft:light[level=12]
setblock 144 222 313 minecraft:light[level=12]
fill 145 222 276 146 222 276 minecraft:packed_ice
fill 145 222 316 145 223 317 minecraft:packed_ice
setblock 147 222 276 minecraft:snow_block
fill 147 222 277 150 222 277 minecraft:packed_ice
setblock 147 222 315 minecraft:packed_ice
setblock 147 222 316 minecraft:snow_block
fill 147 222 317 147 224 317 minecraft:packed_ice
fill 148 222 276 148 225 276 minecraft:packed_ice
setblock 148 222 315 minecraft:snow_block
fill 148 222 316 148 225 316 minecraft:packed_ice
setblock 149 222 314 minecraft:snow_block
fill 149 222 315 149 225 315 minecraft:packed_ice
fill 150 222 314 150 225 314 minecraft:packed_ice
setblock 151 222 277 minecraft:snow_block
setblock 151 222 278 minecraft:light[level=12]
setblock 151 222 306 minecraft:light[level=12]
setblock 151 222 313 minecraft:light[level=12]
fill 152 222 275 152 237 275 minecraft:packed_ice
setblock 152 222 276 minecraft:snow_block
fill 152 222 277 152 225 277 minecraft:packed_ice
setblock 152 222 316 minecraft:snow_block
fill 153 222 276 153 225 276 minecraft:packed_ice
setblock 153 222 314 minecraft:packed_ice
setblock 153 222 315 minecraft:snow_block
fill 153 222 316 153 225 316 minecraft:packed_ice
setblock 154 222 314 minecraft:snow_block
fill 154 222 315 154 225 315 minecraft:packed_ice
setblock 155 222 314 minecraft:packed_ice
fill 157 222 275 157 228 275 minecraft:packed_ice
setblock 157 222 276 minecraft:snow_block
setblock 157 222 315 minecraft:packed_ice
setblock 157 222 316 minecraft:snow_block
setblock 158 222 275 minecraft:white_concrete
setblock 158 222 276 minecraft:packed_ice
setblock 158 222 278 minecraft:light[level=12]
setblock 158 222 306 minecraft:light[level=12]
setblock 158 222 313 minecraft:light[level=12]
setblock 158 222 315 minecraft:snow_block
fill 158 222 316 158 225 316 minecraft:packed_ice
fill 159 222 275 161 237 275 minecraft:packed_ice
fill 159 222 315 162 222 315 minecraft:packed_ice
setblock 162 222 316 minecraft:snow_block
fill 162 222 317 162 235 317 minecraft:packed_ice
setblock 163 222 315 minecraft:snow_block
fill 163 222 316 166 222 316 minecraft:packed_ice
setblock 164 222 314 minecraft:snow_block
fill 164 222 315 167 222 315 minecraft:packed_ice
setblock 165 222 278 minecraft:light[level=12]
setblock 165 222 306 minecraft:light[level=12]
setblock 165 222 313 minecraft:light[level=12]
fill 165 222 314 168 222 314 minecraft:packed_ice
setblock 166 222 276 minecraft:packed_ice
setblock 167 222 276 minecraft:snow_block
fill 167 222 313 169 222 313 minecraft:packed_ice
setblock 167 222 316 minecraft:snow_block
fill 168 222 276 168 225 276 minecraft:packed_ice
setblock 168 222 315 minecraft:snow_block
fill 168 222 316 168 225 316 minecraft:packed_ice
setblock 169 222 314 minecraft:snow_block
fill 169 222 315 169 225 315 minecraft:packed_ice
setblock 170 222 313 minecraft:snow_block
fill 170 222 314 170 225 314 minecraft:packed_ice
fill 171 222 313 171 224 313 minecraft:packed_ice
setblock 172 222 276 minecraft:snow_block
setblock 172 222 278 minecraft:light[level=12]
setblock 172 222 285 minecraft:light[level=12]
setblock 172 222 292 minecraft:light[level=12]
setblock 172 222 299 minecraft:light[level=12]
setblock 172 222 306 minecraft:light[level=12]
setblock 172 222 316 minecraft:snow_block
setblock 173 222 315 minecraft:snow_block
fill 173 222 316 173 225 316 minecraft:packed_ice
setblock 174 222 314 minecraft:snow_block
fill 174 222 315 174 225 315 minecraft:packed_ice
setblock 177 222 316 minecraft:snow_block
fill 178 222 305 178 228 305 minecraft:packed_ice
setblock 179 222 278 minecraft:light[level=12]
setblock 179 222 285 minecraft:light[level=12]
setblock 179 222 292 minecraft:light[level=12]
setblock 179 222 299 minecraft:light[level=12]
setblock 179 222 306 minecraft:light[level=12]
setblock 179 222 313 minecraft:light[level=12]
fill 181 222 288 181 223 288 minecraft:packed_ice
setblock 181 222 292 minecraft:snow_block
fill 181 222 293 181 225 293 minecraft:packed_ice
setblock 182 222 286 minecraft:snow_block
fill 182 222 287 182 225 287 minecraft:packed_ice
setblock 182 222 291 minecraft:snow_block
fill 182 222 292 182 225 292 minecraft:packed_ice
setblock 182 222 295 minecraft:packed_ice
setblock 182 222 296 minecraft:snow_block
fill 182 222 297 182 225 297 minecraft:packed_ice
setblock 182 222 306 minecraft:snow_block
fill 182 222 307 182 223 307 minecraft:packed_ice
setblock 182 222 311 minecraft:snow_block
fill 182 222 312 182 223 312 minecraft:packed_ice
setblock 182 222 317 minecraft:white_concrete
setblock 141 223 316 minecraft:light_blue_concrete
fill 141 223 317 141 237 317 minecraft:packed_ice
setblock 142 223 285 minecraft:snow_block
fill 142 223 286 142 226 286 minecraft:packed_ice
setblock 142 223 290 minecraft:snow_block
fill 142 223 291 142 226 291 minecraft:packed_ice
setblock 142 223 295 minecraft:snow_block
setblock 143 223 284 minecraft:snow_block
fill 143 223 285 143 224 285 minecraft:packed_ice
setblock 143 223 289 minecraft:snow_block
fill 143 223 290 143 226 290 minecraft:packed_ice
fill 144 223 276 145 223 276 minecraft:packed_ice
setblock 144 223 288 minecraft:snow_block
fill 144 223 289 144 225 289 minecraft:packed_ice
setblock 146 223 276 minecraft:snow_block
setblock 146 223 316 minecraft:snow_block
fill 147 223 276 147 225 277 minecraft:packed_ice
setblock 147 223 315 minecraft:snow_block
fill 147 223 316 147 226 316 minecraft:packed_ice
fill 148 223 277 149 223 277 minecraft:packed_ice
fill 148 223 315 148 226 315 minecraft:packed_ice
fill 149 223 314 149 226 314 minecraft:packed_ice
setblock 150 223 277 minecraft:snow_block
setblock 151 223 276 minecraft:snow_block
fill 151 223 277 151 226 277 minecraft:packed_ice
fill 151 223 284 166 223 284 minecraft:yellow_concrete
setblock 151 223 316 minecraft:snow_block
fill 152 223 276 152 226 276 minecraft:packed_ice
setblock 152 223 315 minecraft:snow_block
fill 152 223 316 152 226 316 minecraft:packed_ice
setblock 153 223 314 minecraft:snow_block
fill 153 223 315 153 226 315 minecraft:packed_ice
fill 154 223 314 154 224 314 minecraft:packed_ice
fill 156 223 275 156 235 275 minecraft:packed_ice
setblock 156 223 276 minecraft:snow_block
setblock 156 223 316 minecraft:snow_block
fill 157 223 276 157 224 276 minecraft:packed_ice
setblock 157 223 315 minecraft:snow_block
fill 157 223 316 157 226 316 minecraft:packed_ice
fill 158 223 275 158 237 275 minecraft:packed_ice
fill 158 223 315 161 223 315 minecraft:packed_ice
setblock 161 223 316 minecraft:snow_block
setblock 162 223 315 minecraft:snow_block
fill 162 223 316 165 223 316 minecraft:packed_ice
setblock 163 223 275 minecraft:light_blue_concrete
fill 163 223 315 166 223 315 minecraft:packed_ice
setblock 163 223 317 minecraft:white_concrete
fill 164 223 314 167 223 314 minecraft:packed_ice
setblock 166 223 276 minecraft:snow_block
fill 166 223 313 168 223 313 minecraft:packed_ice
setblock 166 223 316 minecraft:snow_block
fill 167 223 276 167 226 276 minecraft:packed_ice
setblock 167 223 315 minecraft:snow_block
fill 167 223 316 167 226 316 minecraft:packed_ice
setblock 168 223 314 minecraft:snow_block
fill 168 223 315 168 226 315 minecraft:packed_ice
setblock 169 223 313 minecraft:snow_block
fill 169 223 314 169 226 314 minecraft:packed_ice
fill 170 223 313 170 225 313 minecraft:packed_ice
setblock 171 223 276 minecraft:snow_block
setblock 171 223 316 minecraft:snow_block
setblock 172 223 276 minecraft:packed_ice
setblock 172 223 315 minecraft:snow_block
fill 172 223 316 172 226 316 minecraft:packed_ice
setblock 173 223 314 minecraft:snow_block
fill 173 223 315 173 226 315 minecraft:packed_ice
setblock 174 223 314 minecraft:packed_ice
fill 176 223 281 178 272 283 minecraft:snow_block
setblock 176 223 316 minecraft:snow_block
fill 177 223 280 177 272 280 minecraft:snow_block
fill 179 223 282 179 240 282 minecraft:snow_block
setblock 181 223 291 minecraft:snow_block
fill 181 223 292 181 226 292 minecraft:packed_ice
setblock 182 223 285 minecraft:snow_block
fill 182 223 286 182 225 286 minecraft:packed_ice
setblock 182 223 290 minecraft:snow_block
fill 182 223 291 182 226 291 minecraft:packed_ice
setblock 182 223 295 minecraft:snow_block
fill 182 223 296 182 226 296 minecraft:packed_ice
setblock 182 223 310 minecraft:snow_block
fill 182 223 311 182 224 311 minecraft:packed_ice
fill 182 223 317 182 226 317 minecraft:packed_ice
fill 141 224 316 141 227 316 minecraft:packed_ice
setblock 142 224 284 minecraft:snow_block
fill 142 224 285 142 227 285 minecraft:packed_ice
setblock 142 224 289 minecraft:snow_block
fill 142 224 290 142 227 290 minecraft:packed_ice
setblock 142 224 294 minecraft:snow_block
fill 142 224 295 142 227 295 minecraft:packed_ice
setblock 143 224 288 minecraft:snow_block
fill 143 224 289 143 227 289 minecraft:packed_ice
setblock 143 224 293 minecraft:snow_block
fill 143 224 294 143 227 294 minecraft:packed_ice
setblock 144 224 276 minecraft:packed_ice
setblock 144 224 278 minecraft:light[level=15]
setblock 144 224 286 minecraft:light[level=15]
setblock 144 224 288 minecraft:packed_ice
setblock 144 224 294 minecraft:light[level=15]
setblock 144 224 302 minecraft:light[level=15]
setblock 144 224 310 minecraft:light[level=15]
setblock 144 224 316 minecraft:packed_ice
setblock 145 224 276 minecraft:snow_block
setblock 145 224 316 minecraft:snow_block
fill 145 224 317 145 237 317 minecraft:packed_ice
fill 146 224 276 146 226 277 minecraft:packed_ice
setblock 146 224 315 minecraft:snow_block
fill 146 224 316 146 227 316 minecraft:packed_ice
fill 147 224 315 147 227 315 minecraft:packed_ice
setblock 148 224 277 minecraft:packed_ice
setblock 149 224 277 minecraft:snow_block
setblock 150 224 276 minecraft:snow_block
fill 150 224 277 150 227 277 minecraft:packed_ice
setblock 150 224 316 minecraft:snow_block
fill 151 224 276 151 227 276 minecraft:packed_ice
setblock 151 224 315 minecraft:snow_block
fill 151 224 316 151 227 316 minecraft:packed_ice
setblock 152 224 278 minecraft:light[level=15]
setblock 152 224 286 minecraft:light[level=15]
setblock 152 224 294 minecraft:light[level=15]
setblock 152 224 302 minecraft:light[level=15]
setblock 152 224 310 minecraft:light[level=15]
setblock 152 224 314 minecraft:snow_block
fill 152 224 315 152 227 315 minecraft:packed_ice
fill 153 224 314 153 225 314 minecraft:packed_ice
setblock 155 224 276 minecraft:snow_block
setblock 155 224 316 minecraft:snow_block
fill 156 224 276 156 227 276 minecraft:packed_ice
setblock 156 224 315 minecraft:snow_block
fill 156 224 316 156 227 316 minecraft:packed_ice
fill 157 224 315 160 224 315 minecraft:packed_ice
setblock 160 224 278 minecraft:light[level=15]
setblock 160 224 286 minecraft:light[level=15]
setblock 160 224 302 minecraft:light[level=15]
setblock 160 224 310 minecraft:light[level=15]
setblock 160 224 316 minecraft:snow_block
setblock 161 224 315 minecraft:snow_block
fill 161 224 316 164 224 316 minecraft:packed_ice
fill 162 224 315 165 224 315 minecraft:packed_ice
fill 163 224 275 163 237 275 minecraft:packed_ice
fill 163 224 317 163 234 317 minecraft:packed_ice
fill 164 224 289 164 272 291 minecraft:snow_block
fill 164 224 314 166 224 314 minecraft:packed_ice
setblock 165 224 316 minecraft:snow_block
fill 166 224 276 166 227 276 minecraft:packed_ice
setblock 166 224 315 minecraft:snow_block
fill 166 224 316 166 227 316 minecraft:packed_ice
setblock 167 224 313 minecraft:packed_ice
setblock 167 224 314 minecraft:snow_block
fill 167 224 315 167 227 315 minecraft:packed_ice
setblock 168 224 278 minecraft:light[level=15]
setblock 168 224 286 minecraft:light[level=15]
setblock 168 224 294 minecraft:light[level=15]
setblock 168 224 302 minecraft:light[level=15]
setblock 168 224 310 minecraft:light[level=15]
setblock 168 224 313 minecraft:snow_block
fill 168 224 314 168 227 314 minecraft:packed_ice
fill 169 224 313 169 225 313 minecraft:packed_ice
setblock 170 224 276 minecraft:snow_block
setblock 170 224 316 minecraft:snow_block
setblock 171 224 276 minecraft:packed_ice
setblock 171 224 315 minecraft:snow_block
fill 171 224 316 171 227 316 minecraft:packed_ice
setblock 172 224 314 minecraft:snow_block
fill 172 224 315 172 227 315 minecraft:packed_ice
setblock 173 224 314 minecraft:packed_ice
fill 175 224 281 175 225 283 minecraft:packed_ice
setblock 175 224 316 minecraft:snow_block
setblock 176 224 278 minecraft:light[level=15]
fill 176 224 280 176 225 280 minecraft:packed_ice
fill 176 224 284 179 225 284 minecraft:packed_ice
setblock 176 224 286 minecraft:light[level=15]
setblock 176 224 294 minecraft:light[level=15]
setblock 176 224 302 minecraft:light[level=15]
setblock 176 224 310 minecraft:light[level=15]
setblock 176 224 316 minecraft:packed_ice
fill 178 224 280 179 225 280 minecraft:packed_ice
fill 179 224 281 179 225 281 minecraft:packed_ice
fill 179 224 283 179 225 283 minecraft:packed_ice
fill 180 224 282 180 225 282 minecraft:packed_ice
setblock 181 224 290 minecraft:snow_block
fill 181 224 291 181 227 291 minecraft:packed_ice
setblock 181 224 294 minecraft:packed_ice
setblock 182 224 289 minecraft:snow_block
fill 182 224 290 182 227 290 minecraft:packed_ice
setblock 182 224 294 minecraft:snow_block
fill 182 224 295 182 227 295 minecraft:packed_ice
setblock 182 224 310 minecraft:packed_ice
fill 142 225 284 142 228 284 minecraft:packed_ice
setblock 142 225 288 minecraft:snow_block
fill 142 225 289 142 228 289 minecraft:packed_ice
setblock 142 225 293 minecraft:snow_block
fill 142 225 294 142 228 294 minecraft:packed_ice
fill 142 225 296 142 226 296 minecraft:packed_ice
setblock 143 225 276 minecraft:packed_ice
setblock 143 225 287 minecraft:snow_block
fill 143 225 288 143 228 288 minecraft:packed_ice
setblock 143 225 292 minecraft:snow_block
fill 143 225 293 143 228 293 minecraft:packed_ice
setblock 144 225 276 minecraft:snow_block
setblock 144 225 291 minecraft:snow_block
setblock 144 225 316 minecraft:snow_block
fill 145 225 276 145 228 276 minecraft:packed_ice
fill 145 225 316 145 228 316 minecraft:packed_ice
fill 146 225 315 146 228 315 minecraft:packed_ice
setblock 147 225 317 minecraft:white_concrete
setblock 148 225 277 minecraft:snow_block
fill 148 225 314 148 227 314 minecraft:packed_ice
setblock 149 225 276 minecraft:snow_block
fill 149 225 277 149 228 277 minecraft:packed_ice
setblock 149 225 316 minecraft:snow_block
fill 150 225 276 150 228 276 minecraft:packed_ice
setblock 150 225 315 minecraft:snow_block
fill 150 225 316 150 228 316 minecraft:packed_ice
setblock 151 225 314 minecraft:snow_block
fill 151 225 315 151 228 315 minecraft:packed_ice
fill 152 225 314 152 226 314 minecraft:packed_ice
setblock 154 225 276 minecraft:snow_block
setblock 154 225 316 minecraft:snow_block
fill 155 225 276 155 228 276 minecraft:packed_ice
setblock 155 225 315 minecraft:snow_block
fill 155 225 316 155 228 316 minecraft:packed_ice
fill 156 225 315 159 225 315 minecraft:packed_ice
setblock 159 225 316 minecraft:snow_block
setblock 160 225 315 minecraft:snow_block
fill 160 225 316 163 225 316 minecraft:packed_ice
fill 161 225 315 164 225 315 minecraft:packed_ice
fill 162 225 289 163 235 290 minecraft:snow_block
fill 163 225 291 163 253 291 minecraft:snow_block
fill 164 225 314 165 225 314 minecraft:packed_ice
setblock 164 225 316 minecraft:snow_block
fill 165 225 276 165 228 276 minecraft:packed_ice
setblock 165 225 315 minecraft:snow_block
fill 165 225 316 165 228 316 minecraft:packed_ice
setblock 166 225 314 minecraft:snow_block
fill 166 225 315 166 228 315 minecraft:packed_ice
setblock 167 225 313 minecraft:snow_block
fill 167 225 314 167 228 314 minecraft:packed_ice
fill 168 225 275 169 235 275 minecraft:packed_ice
fill 168 225 313 168 226 313 minecraft:packed_ice
setblock 169 225 276 minecraft:snow_block
setblock 169 225 316 minecraft:snow_block
setblock 170 225 275 minecraft:white_concrete
fill 170 225 276 170 228 276 minecraft:packed_ice
setblock 170 225 315 minecraft:snow_block
fill 170 225 316 170 228 316 minecraft:packed_ice
fill 171 225 275 173 229 275 minecraft:packed_ice
setblock 171 225 314 minecraft:snow_block
fill 171 225 315 171 228 315 minecraft:packed_ice
fill 172 225 277 172 234 277 minecraft:packed_ice
setblock 172 225 314 minecraft:packed_ice
fill 174 225 281 174 225 283 minecraft:packed_ice
setblock 174 225 316 minecraft:snow_block
setblock 175 225 280 minecraft:packed_ice
setblock 175 225 284 minecraft:packed_ice
setblock 175 225 316 minecraft:packed_ice
fill 176 225 279 179 225 279 minecraft:packed_ice
fill 176 225 285 179 225 285 minecraft:packed_ice
fill 177 225 314 177 233 314 minecraft:packed_ice
fill 180 225 280 180 225 281 minecraft:packed_ice
fill 180 225 283 180 225 284 minecraft:packed_ice
fill 181 225 290 181 228 290 minecraft:packed_ice
setblock 181 225 294 minecraft:snow_block
setblock 182 225 288 minecraft:snow_block
fill 182 225 289 182 228 289 minecraft:packed_ice
setblock 182 225 293 minecraft:snow_block
fill 182 225 294 182 228 294 minecraft:packed_ice
setblock 182 225 298 minecraft:snow_block
setblock 142 226 287 minecraft:snow_block
fill 142 226 288 142 229 288 minecraft:packed_ice
setblock 142 226 292 minecraft:snow_block
fill 142 226 293 142 229 293 minecraft:packed_ice
setblock 143 226 276 minecraft:snow_block
fill 143 226 287 143 229 287 minecraft:packed_ice
setblock 143 226 291 minecraft:snow_block
fill 143 226 292 143 229 292 minecraft:packed_ice
setblock 143 226 316 minecraft:snow_block
fill 144 226 276 144 229 276 minecraft:packed_ice
fill 144 226 292 145 228 294 minecraft:blue_ice
fill 144 226 316 144 229 316 minecraft:packed_ice
fill 145 226 277 145 227 277 minecraft:packed_ice
fill 145 226 315 145 229 315 minecraft:packed_ice
setblock 146 226 317 minecraft:light_blue_concrete
setblock 147 226 276 minecraft:packed_ice
setblock 147 226 277 minecraft:snow_block
fill 147 226 317 147 238 317 minecraft:packed_ice
setblock 148 226 276 minecraft:snow_block
fill 148 226 277 148 229 277 minecraft:packed_ice
setblock 148 226 316 minecraft:snow_block
fill 149 226 276 149 229 276 minecraft:packed_ice
setblock 149 226 315 minecraft:snow_block
fill 149 226 316 149 229 316 minecraft:packed_ice
setblock 150 226 314 minecraft:snow_block
fill 150 226 315 150 229 315 minecraft:packed_ice
fill 151 226 314 151 228 314 minecraft:packed_ice
setblock 152 226 277 minecraft:snow_block
setblock 153 226 276 minecraft:snow_block
setblock 153 226 316 minecraft:snow_block
fill 154 226 276 154 229 276 minecraft:packed_ice
setblock 154 226 315 minecraft:snow_block
fill 154 226 316 154 229 316 minecraft:packed_ice
fill 155 226 315 158 226 315 minecraft:packed_ice
setblock 158 226 316 minecraft:snow_block
setblock 159 226 315 minecraft:snow_block
fill 159 226 316 162 226 316 minecraft:packed_ice
fill 160 226 315 163 226 315 minecraft:packed_ice
fill 162 226 312 162 232 312 minecraft:packed_ice
fill 163 226 314 164 226 314 minecraft:packed_ice
setblock 163 226 316 minecraft:snow_block
fill 164 226 276 164 229 276 minecraft:packed_ice
setblock 164 226 315 minecraft:snow_block
fill 164 226 316 164 229 316 minecraft:packed_ice
setblock 165 226 314 minecraft:snow_block
fill 165 226 315 165 229 315 minecraft:packed_ice
fill 166 226 314 166 229 314 minecraft:packed_ice
setblock 167 226 313 minecraft:packed_ice
setblock 168 226 276 minecraft:snow_block
setblock 168 226 316 minecraft:snow_block
fill 169 226 276 169 229 276 minecraft:packed_ice
setblock 169 226 315 minecraft:snow_block
fill 169 226 316 169 229 316 minecraft:packed_ice
fill 170 226 275 170 237 275 minecraft:packed_ice
setblock 170 226 314 minecraft:snow_block
fill 170 226 315 170 229 315 minecraft:packed_ice
fill 171 226 314 171 227 314 minecraft:packed_ice
setblock 173 226 316 minecraft:snow_block
fill 174 226 316 174 229 316 minecraft:packed_ice
setblock 181 226 293 minecraft:snow_block
fill 181 226 294 181 228 295 minecraft:packed_ice
setblock 182 226 287 minecraft:snow_block
fill 182 226 288 182 229 288 minecraft:packed_ice
setblock 182 226 292 minecraft:snow_block
fill 182 226 293 182 229 293 minecraft:packed_ice
setblock 182 226 297 minecraft:snow_block
fill 182 226 298 182 229 298 minecraft:packed_ice
setblock 141 227 295 minecraft:white_concrete
fill 141 227 296 141 237 297 minecraft:packed_ice
setblock 142 227 276 minecraft:snow_block
fill 142 227 277 142 229 278 minecraft:packed_ice
setblock 142 227 286 minecraft:snow_block
fill 142 227 287 142 230 287 minecraft:packed_ice
setblock 142 227 291 minecraft:snow_block
fill 142 227 292 142 230 292 minecraft:packed_ice
setblock 142 227 296 minecraft:snow_block
fill 142 227 297 142 230 297 minecraft:packed_ice
fill 142 227 314 142 227 315 minecraft:packed_ice
setblock 142 227 316 minecraft:snow_block
fill 143 227 276 143 230 276 minecraft:packed_ice
setblock 143 227 290 minecraft:snow_block
fill 143 227 291 143 230 291 minecraft:packed_ice
setblock 143 227 295 minecraft:snow_block
fill 143 227 316 143 230 316 minecraft:packed_ice
fill 144 227 277 144 228 277 minecraft:packed_ice
fill 144 227 315 144 230 315 minecraft:packed_ice
setblock 146 227 276 minecraft:packed_ice
setblock 146 227 277 minecraft:snow_block
fill 146 227 292 146 228 294 minecraft:blue_ice
fill 146 227 317 146 237 317 minecraft:packed_ice
setblock 147 227 276 minecraft:snow_block
fill 147 227 277 147 230 277 minecraft:packed_ice
fill 147 227 293 148 228 293 minecraft:blue_ice
setblock 147 227 316 minecraft:snow_block
fill 148 227 276 148 230 276 minecraft:packed_ice
setblock 148 227 315 minecraft:snow_block
fill 148 227 316 148 230 316 minecraft:packed_ice
setblock 149 227 314 minecraft:snow_block
fill 149 227 315 149 230 315 minecraft:packed_ice
fill 150 227 314 150 230 314 minecraft:packed_ice
setblock 151 227 277 minecraft:snow_block
setblock 152 227 276 minecraft:snow_block
fill 152 227 277 152 230 277 minecraft:packed_ice
setblock 152 227 316 minecraft:snow_block
fill 153 227 276 153 230 276 minecraft:packed_ice
setblock 153 227 315 minecraft:snow_block
fill 153 227 316 153 230 316 minecraft:packed_ice
fill 154 227 315 157 227 315 minecraft:packed_ice
setblock 157 227 316 minecraft:snow_block
setblock 158 227 315 minecraft:snow_block
fill 158 227 316 161 227 316 minecraft:packed_ice
fill 159 227 315 162 227 315 minecraft:packed_ice
setblock 162 227 316 minecraft:snow_block
fill 163 227 276 163 230 276 minecraft:packed_ice
setblock 163 227 314 minecraft:packed_ice
setblock 163 227 315 minecraft:snow_block
fill 163 227 316 163 230 316 minecraft:packed_ice
setblock 164 227 314 minecraft:snow_block
fill 164 227 315 164 230 315 minecraft:packed_ice
fill 165 227 314 165 230 314 minecraft:packed_ice
setblock 167 227 276 minecraft:snow_block
setblock 167 227 316 minecraft:snow_block
fill 168 227 276 168 230 276 minecraft:packed_ice
setblock 168 227 315 minecraft:snow_block
fill 168 227 316 168 230 316 minecraft:packed_ice
setblock 169 227 314 minecraft:snow_block
fill 169 227 315 169 230 315 minecraft:packed_ice
fill 170 227 314 170 229 314 minecraft:packed_ice
setblock 172 227 316 minecraft:snow_block
fill 173 227 316 173 230 316 minecraft:packed_ice
fill 177 227 305 177 228 305 minecraft:packed_ice
fill 178 227 304 178 228 304 minecraft:packed_ice
fill 178 227 306 178 228 306 minecraft:packed_ice
fill 179 227 305 179 228 305 minecraft:packed_ice
setblock 181 227 292 minecraft:snow_block
fill 181 227 293 181 230 293 minecraft:packed_ice
setblock 181 227 296 minecraft:packed_ice
fill 182 227 287 182 230 287 minecraft:packed_ice
setblock 182 227 291 minecraft:snow_block
fill 182 227 292 182 230 292 minecraft:packed_ice
setblock 182 227 296 minecraft:snow_block
fill 182 227 297 183 230 297 minecraft:packed_ice
fill 182 227 299 182 228 299 minecraft:packed_ice
setblock 182 227 317 minecraft:white_concrete
fill 183 227 294 183 235 295 minecraft:packed_ice
setblock 183 227 296 minecraft:white_concrete
setblock 141 228 288 minecraft:white_concrete
fill 141 228 289 141 235 290 minecraft:packed_ice
fill 141 228 295 141 234 295 minecraft:packed_ice
setblock 141 228 316 minecraft:white_concrete
fill 142 228 276 142 231 276 minecraft:packed_ice
setblock 142 228 279 minecraft:packed_ice
setblock 142 228 280 minecraft:snow_block
fill 142 228 281 142 229 283 minecraft:packed_ice
setblock 142 228 285 minecraft:snow_block
fill 142 228 286 142 231 286 minecraft:packed_ice
setblock 142 228 290 minecraft:snow_block
fill 142 228 291 142 231 291 minecraft:packed_ice
setblock 142 228 295 minecraft:snow_block
fill 142 228 296 142 231 296 minecraft:packed_ice
fill 142 228 313 142 228 314 minecraft:packed_ice
setblock 142 228 315 minecraft:snow_block
fill 142 228 316 142 231 316 minecraft:packed_ice
fill 143 228 277 143 228 278 minecraft:packed_ice
setblock 143 228 289 minecraft:snow_block
fill 143 228 290 143 231 290 minecraft:packed_ice
setblock 143 228 294 minecraft:snow_block
fill 143 228 295 143 231 295 minecraft:packed_ice
setblock 144 228 278 minecraft:light[level=12]
setblock 144 228 285 minecraft:light[level=12]
setblock 144 228 299 minecraft:light[level=12]
setblock 144 228 306 minecraft:light[level=12]
setblock 144 228 313 minecraft:light[level=12]
setblock 145 228 277 minecraft:snow_block
setblock 146 228 276 minecraft:snow_block
fill 146 228 277 146 231 277 minecraft:packed_ice
setblock 146 228 316 minecraft:snow_block
fill 147 228 276 147 231 276 minecraft:packed_ice
fill 147 228 278 147 229 278 minecraft:packed_ice
setblock 147 228 314 minecraft:packed_ice
setblock 147 228 315 minecraft:snow_block
fill 147 228 316 147 231 316 minecraft:packed_ice
setblock 148 228 314 minecraft:snow_block
fill 148 228 315 148 231 315 minecraft:packed_ice
setblock 149 228 293 minecraft:blue_ice
fill 149 228 314 149 231 314 minecraft:packed_ice
setblock 150 228 277 minecraft:snow_block
setblock 151 228 276 minecraft:snow_block
fill 151 228 277 151 231 277 minecraft:packed_ice
setblock 151 228 278 minecraft:light[level=12]
setblock 151 228 285 minecraft:light[level=12]
setblock 151 228 292 minecraft:light[level=12]
setblock 151 228 299 minecraft:light[level=12]
setblock 151 228 306 minecraft:light[level=12]
setblock 151 228 313 minecraft:light[level=12]
setblock 151 228 316 minecraft:snow_block
fill 152 228 276 152 231 276 minecraft:packed_ice
setblock 152 228 315 minecraft:snow_block
fill 152 228 316 152 231 316 minecraft:packed_ice
fill 153 228 315 156 228 315 minecraft:packed_ice
setblock 156 228 276 minecraft:snow_block
setblock 156 228 316 minecraft:snow_block
setblock 157 228 315 minecraft:snow_block
fill 157 228 316 160 228 316 minecraft:packed_ice
setblock 158 228 278 minecraft:light[level=12]
setblock 158 228 285 minecraft:light[level=12]
setblock 158 228 299 minecraft:light[level=12]
setblock 158 228 306 minecraft:light[level=12]
setblock 158 228 313 minecraft:light[level=12]
fill 158 228 315 161 228 315 minecraft:packed_ice
setblock 161 228 276 minecraft:snow_block
setblock 161 228 316 minecraft:snow_block
fill 162 228 276 162 231 276 minecraft:packed_ice
setblock 162 228 314 minecraft:packed_ice
setblock 162 228 315 minecraft:snow_block
fill 162 228 316 162 231 316 minecraft:packed_ice
setblock 163 228 314 minecraft:snow_block
fill 163 228 315 163 231 315 minecraft:packed_ice
fill 164 228 314 164 231 314 minecraft:packed_ice
setblock 165 228 278 minecraft:light[level=12]
setblock 165 228 285 minecraft:light[level=12]
setblock 165 228 292 minecraft:light[level=12]
setblock 165 228 299 minecraft:light[level=12]
setblock 165 228 306 minecraft:light[level=12]
setblock 165 228 313 minecraft:light[level=12]
setblock 166 228 276 minecraft:snow_block
setblock 166 228 316 minecraft:snow_block
fill 167 228 276 167 231 276 minecraft:packed_ice
setblock 167 228 315 minecraft:snow_block
fill 167 228 316 167 231 316 minecraft:packed_ice
setblock 168 228 314 minecraft:snow_block
fill 168 228 315 168 231 315 minecraft:packed_ice
fill 169 228 314 169 231 314 minecraft:packed_ice
setblock 171 228 316 minecraft:snow_block
setblock 172 228 278 minecraft:light[level=12]
setblock 172 228 285 minecraft:light[level=12]
setblock 172 228 292 minecraft:light[level=12]
setblock 172 228 299 minecraft:light[level=12]
setblock 172 228 306 minecraft:light[level=12]
setblock 172 228 313 minecraft:light[level=12]
setblock 172 228 315 minecraft:snow_block
fill 172 228 316 172 231 316 minecraft:packed_ice
setblock 179 228 278 minecraft:light[level=12]
setblock 179 228 285 minecraft:light[level=12]
setblock 179 228 292 minecraft:light[level=12]
setblock 179 228 299 minecraft:light[level=12]
setblock 179 228 306 minecraft:light[level=12]
setblock 179 228 313 minecraft:light[level=12]
setblock 181 228 291 minecraft:snow_block
fill 181 228 292 181 231 292 minecraft:packed_ice
setblock 181 228 296 minecraft:snow_block
fill 181 228 297 181 231 297 minecraft:packed_ice
fill 182 228 286 182 231 286 minecraft:packed_ice
setblock 182 228 290 minecraft:snow_block
fill 182 228 291 182 231 291 minecraft:packed_ice
setblock 182 228 295 minecraft:snow_block
fill 182 228 296 183 231 296 minecraft:packed_ice
setblock 182 228 300 minecraft:snow_block
fill 182 228 317 182 237 317 minecraft:packed_ice
fill 141 229 288 141 235 288 minecraft:packed_ice
fill 141 229 316 141 233 316 minecraft:packed_ice
setblock 142 229 279 minecraft:snow_block
fill 142 229 280 143 231 280 minecraft:packed_ice
setblock 142 229 284 minecraft:snow_block
fill 142 229 285 142 232 285 minecraft:packed_ice
setblock 142 229 289 minecraft:snow_block
fill 142 229 290 142 232 290 minecraft:packed_ice
setblock 142 229 294 minecraft:snow_block
fill 142 229 295 142 232 295 minecraft:packed_ice
setblock 142 229 298 minecraft:packed_ice
fill 142 229 312 142 229 313 minecraft:packed_ice
setblock 142 229 314 minecraft:snow_block
fill 142 229 315 143 231 315 minecraft:packed_ice
setblock 143 229 277 minecraft:packed_ice
setblock 143 229 278 minecraft:snow_block
fill 143 229 279 143 232 279 minecraft:packed_ice
setblock 143 229 288 minecraft:snow_block
fill 143 229 289 143 232 289 minecraft:packed_ice
setblock 143 229 293 minecraft:snow_block
fill 143 229 294 143 232 294 minecraft:packed_ice
fill 143 229 296 143 229 297 minecraft:packed_ice
fill 143 229 314 143 232 314 minecraft:packed_ice
setblock 144 229 277 minecraft:snow_block
setblock 144 229 292 minecraft:snow_block
fill 144 229 293 144 232 293 minecraft:packed_ice
setblock 145 229 276 minecraft:snow_block
fill 145 229 277 145 231 278 minecraft:packed_ice
setblock 145 229 316 minecraft:snow_block
fill 146 229 276 146 232 276 minecraft:packed_ice
fill 146 229 278 146 230 278 minecraft:packed_ice
setblock 146 229 314 minecraft:packed_ice
setblock 146 229 315 minecraft:snow_block
fill 146 229 316 146 232 316 minecraft:packed_ice
setblock 147 229 314 minecraft:snow_block
fill 147 229 315 147 232 315 minecraft:packed_ice
setblock 148 229 278 minecraft:snow_block
fill 148 229 314 148 232 314 minecraft:packed_ice
setblock 149 229 277 minecraft:snow_block
fill 149 229 278 149 232 278 minecraft:packed_ice
setblock 150 229 276 minecraft:snow_block
fill 150 229 277 150 232 277 minecraft:packed_ice
setblock 150 229 316 minecraft:snow_block
fill 151 229 276 151 232 276 minecraft:packed_ice
setblock 151 229 315 minecraft:snow_block
fill 151 229 316 151 232 316 minecraft:packed_ice
fill 152 229 315 155 229 315 minecraft:packed_ice
fill 154 229 311 154 235 311 minecraft:packed_ice
setblock 155 229 276 minecraft:snow_block
setblock 155 229 316 minecraft:snow_block
fill 156 229 276 159 229 276 minecraft:packed_ice
setblock 156 229 315 minecraft:snow_block
fill 156 229 316 159 229 316 minecraft:packed_ice
setblock 157 229 275 minecraft:white_concrete
fill 157 229 315 160 229 315 minecraft:packed_ice
setblock 160 229 276 minecraft:snow_block
setblock 160 229 316 minecraft:snow_block
fill 161 229 276 161 232 276 minecraft:packed_ice
setblock 161 229 315 minecraft:snow_block
fill 161 229 316 161 232 316 minecraft:packed_ice
setblock 162 229 314 minecraft:snow_block
fill 162 229 315 162 232 315 minecraft:packed_ice
fill 163 229 314 163 232 314 minecraft:packed_ice
setblock 165 229 276 minecraft:snow_block
setblock 165 229 316 minecraft:snow_block
fill 166 229 276 166 232 276 minecraft:packed_ice
setblock 166 229 315 minecraft:snow_block
fill 166 229 316 166 232 316 minecraft:packed_ice
setblock 167 229 314 minecraft:snow_block
fill 167 229 315 167 232 315 minecraft:packed_ice
fill 168 229 314 168 232 314 minecraft:packed_ice
setblock 170 229 276 minecraft:snow_block
setblock 170 229 316 minecraft:snow_block
fill 171 229 276 171 232 276 minecraft:packed_ice
setblock 171 229 315 minecraft:snow_block
fill 171 229 316 171 232 316 minecraft:packed_ice
setblock 172 229 315 minecraft:packed_ice
setblock 181 229 290 minecraft:snow_block
fill 181 229 291 181 232 291 minecraft:packed_ice
setblock 181 229 294 minecraft:packed_ice
setblock 181 229 295 minecraft:snow_block
fill 181 229 296 181 232 296 minecraft:packed_ice
fill 181 229 298 181 230 298 minecraft:packed_ice
fill 182 229 276 182 230 277 minecraft:packed_ice
setblock 182 229 289 minecraft:snow_block
fill 182 229 290 182 232 290 minecraft:packed_ice
setblock 182 229 294 minecraft:snow_block
fill 182 229 295 182 232 295 minecraft:packed_ice
setblock 182 229 299 minecraft:snow_block
fill 182 229 300 182 231 301 minecraft:packed_ice
setblock 182 229 314 minecraft:snow_block
fill 182 229 315 182 231 316 minecraft:packed_ice
setblock 142 230 277 minecraft:packed_ice
setblock 142 230 278 minecraft:snow_block
fill 142 230 279 142 233 279 minecraft:packed_ice
fill 142 230 281 142 230 282 minecraft:packed_ice
setblock 142 230 283 minecraft:snow_block
fill 142 230 284 143 232 284 minecraft:packed_ice
setblock 142 230 288 minecraft:snow_block
fill 142 230 289 142 233 289 minecraft:packed_ice
setblock 142 230 293 minecraft:snow_block
fill 142 230 294 142 233 294 minecraft:packed_ice
setblock 142 230 298 minecraft:snow_block
fill 142 230 299 142 232 300 minecraft:packed_ice
setblock 142 230 312 minecraft:packed_ice
setblock 142 230 313 minecraft:snow_block
fill 142 230 314 142 233 314 minecraft:packed_ice
setblock 143 230 277 minecraft:snow_block
fill 143 230 278 144 232 278 minecraft:packed_ice
setblock 143 230 281 minecraft:packed_ice
setblock 143 230 282 minecraft:snow_block
fill 143 230 283 143 233 283 minecraft:packed_ice
fill 143 230 285 143 230 286 minecraft:packed_ice
setblock 143 230 287 minecraft:snow_block
fill 143 230 288 143 233 288 minecraft:packed_ice
setblock 143 230 292 minecraft:snow_block
fill 143 230 293 143 233 293 minecraft:packed_ice
setblock 143 230 296 minecraft:packed_ice
setblock 143 230 297 minecraft:snow_block
fill 143 230 298 143 233 298 minecraft:packed_ice
fill 143 230 313 143 233 313 minecraft:packed_ice
setblock 144 230 276 minecraft:snow_block
fill 144 230 277 144 233 277 minecraft:packed_ice
fill 144 230 279 144 231 279 minecraft:packed_ice
setblock 144 230 291 minecraft:snow_block
fill 144 230 292 144 233 292 minecraft:packed_ice
fill 144 230 294 144 230 295 minecraft:packed_ice
setblock 144 230 316 minecraft:snow_block
fill 145 230 276 145 233 276 minecraft:packed_ice
setblock 145 230 314 minecraft:packed_ice
setblock 145 230 315 minecraft:snow_block
fill 145 230 316 145 233 316 minecraft:packed_ice
setblock 146 230 314 minecraft:snow_block
fill 146 230 315 146 233 315 minecraft:packed_ice
setblock 147 230 278 minecraft:snow_block
fill 147 230 314 147 233 314 minecraft:packed_ice
setblock 148 230 277 minecraft:snow_block
fill 148 230 278 148 233 278 minecraft:packed_ice
setblock 149 230 276 minecraft:snow_block
fill 149 230 277 149 233 277 minecraft:packed_ice
setblock 149 230 316 minecraft:snow_block
fill 150 230 276 150 233 276 minecraft:packed_ice
fill 150 230 278 150 231 278 minecraft:packed_ice
setblock 150 230 315 minecraft:snow_block
fill 150 230 316 150 233 316 minecraft:packed_ice
setblock 151 230 275 minecraft:white_concrete
fill 151 230 315 154 230 315 minecraft:packed_ice
setblock 153 230 277 minecraft:snow_block
setblock 154 230 276 minecraft:snow_block
setblock 154 230 316 minecraft:snow_block
fill 155 230 276 158 230 276 minecraft:packed_ice
setblock 155 230 315 minecraft:snow_block
fill 155 230 316 158 230 316 minecraft:packed_ice
fill 156 230 315 159 230 315 minecraft:packed_ice
fill 156 230 317 156 238 317 minecraft:packed_ice
fill 157 230 275 157 234 275 minecraft:packed_ice
setblock 157 230 317 minecraft:light_blue_concrete
setblock 159 230 276 minecraft:snow_block
setblock 159 230 316 minecraft:snow_block
fill 160 230 276 160 233 276 minecraft:packed_ice
setblock 160 230 315 minecraft:snow_block
fill 160 230 316 160 233 316 minecraft:packed_ice
setblock 161 230 314 minecraft:snow_block
fill 161 230 315 161 233 315 minecraft:packed_ice
fill 162 230 314 162 233 314 minecraft:packed_ice
setblock 164 230 276 minecraft:snow_block
fill 164 230 277 167 230 277 minecraft:packed_ice
setblock 164 230 316 minecraft:snow_block
fill 165 230 276 165 233 276 minecraft:packed_ice
setblock 165 230 315 minecraft:snow_block
fill 165 230 316 165 233 316 minecraft:packed_ice
setblock 166 230 314 minecraft:snow_block
fill 166 230 315 166 233 315 minecraft:packed_ice
fill 167 230 314 167 233 314 minecraft:packed_ice
setblock 169 230 276 minecraft:snow_block
setblock 169 230 316 minecraft:snow_block
fill 170 230 276 170 233 276 minecraft:packed_ice
setblock 170 230 315 minecraft:snow_block
fill 170 230 316 170 233 316 minecraft:packed_ice
fill 171 230 275 171 237 275 minecraft:packed_ice
fill 171 230 277 171 234 277 minecraft:packed_ice
fill 171 230 315 171 232 315 minecraft:packed_ice
setblock 172 230 275 minecraft:light_blue_concrete
fill 172 230 276 172 231 276 minecraft:packed_ice
fill 172 230 278 172 234 278 minecraft:packed_ice
fill 173 230 275 173 237 275 minecraft:packed_ice
fill 173 230 277 173 234 277 minecraft:packed_ice
setblock 174 230 316 minecraft:snow_block
fill 180 230 276 181 232 276 minecraft:packed_ice
setblock 180 230 294 minecraft:packed_ice
setblock 180 230 295 minecraft:snow_block
setblock 181 230 289 minecraft:snow_block
fill 181 230 290 181 233 290 minecraft:packed_ice
setblock 181 230 294 minecraft:snow_block
fill 181 230 295 181 233 295 minecraft:packed_ice
setblock 181 230 299 minecraft:snow_block
fill 181 230 316 181 232 316 minecraft:packed_ice
setblock 182 230 278 minecraft:snow_block
fill 182 230 279 182 230 282 minecraft:packed_ice
setblock 182 230 283 minecraft:snow_block
fill 182 230 284 182 232 285 minecraft:packed_ice
setblock 182 230 288 minecraft:snow_block
fill 182 230 289 182 233 289 minecraft:packed_ice
setblock 182 230 293 minecraft:snow_block
fill 182 230 294 182 233 294 minecraft:packed_ice
setblock 182 230 298 minecraft:snow_block
fill 182 230 299 182 233 299 minecraft:packed_ice
setblock 182 230 302 minecraft:packed_ice
setblock 182 230 313 minecraft:snow_block
fill 182 230 314 182 233 314 minecraft:packed_ice
setblock 141 231 292 minecraft:white_concrete
setblock 141 231 302 minecraft:white_concrete
setblock 142 231 277 minecraft:snow_block
fill 142 231 278 142 234 278 minecraft:packed_ice
setblock 142 231 281 minecraft:packed_ice
setblock 142 231 282 minecraft:snow_block
fill 142 231 283 142 234 283 minecraft:packed_ice
setblock 142 231 287 minecraft:snow_block
fill 142 231 288 142 234 288 minecraft:packed_ice
setblock 142 231 292 minecraft:snow_block
fill 142 231 293 142 234 293 minecraft:packed_ice
setblock 142 231 297 minecraft:snow_block
fill 142 231 298 142 234 298 minecraft:packed_ice
setblock 142 231 301 minecraft:packed_ice
setblock 142 231 311 minecraft:packed_ice
setblock 142 231 312 minecraft:snow_block
fill 142 231 313 142 234 313 minecraft:packed_ice
setblock 143 231 276 minecraft:snow_block
fill 143 231 277 143 234 277 minecraft:packed_ice
setblock 143 231 281 minecraft:snow_block
fill 143 231 282 143 234 282 minecraft:packed_ice
setblock 143 231 285 minecraft:packed_ice
setblock 143 231 286 minecraft:snow_block
fill 143 231 287 143 234 287 minecraft:packed_ice
setblock 143 231 291 minecraft:snow_block
fill 143 231 292 143 234 292 minecraft:packed_ice
setblock 143 231 296 minecraft:snow_block
fill 143 231 297 143 234 297 minecraft:packed_ice
fill 143 231 299 143 232 299 minecraft:packed_ice
setblock 143 231 316 minecraft:snow_block
fill 144 231 276 144 234 276 minecraft:packed_ice
setblock 144 231 280 minecraft:snow_block
fill 144 231 281 144 234 281 minecraft:packed_ice
setblock 144 231 291 minecraft:packed_ice
setblock 144 231 294 minecraft:packed_ice
setblock 144 231 295 minecraft:snow_block
fill 144 231 296 144 234 296 minecraft:packed_ice
setblock 144 231 314 minecraft:packed_ice
setblock 144 231 315 minecraft:snow_block
fill 144 231 316 144 234 316 minecraft:packed_ice
setblock 145 231 314 minecraft:snow_block
fill 145 231 315 145 234 315 minecraft:packed_ice
setblock 146 231 278 minecraft:snow_block
fill 146 231 314 146 234 314 minecraft:packed_ice
setblock 147 231 277 minecraft:snow_block
fill 147 231 278 147 234 278 minecraft:packed_ice
setblock 148 231 276 minecraft:snow_block
fill 148 231 277 148 234 277 minecraft:packed_ice
setblock 148 231 316 minecraft:snow_block
fill 149 231 276 149 234 276 minecraft:packed_ice
setblock 149 231 315 minecraft:snow_block
fill 149 231 316 149 234 316 minecraft:packed_ice
setblock 150 231 314 minecraft:snow_block
fill 150 231 315 153 231 315 minecraft:packed_ice
fill 151 231 275 151 234 275 minecraft:packed_ice
setblock 152 231 277 minecraft:snow_block
setblock 153 231 276 minecraft:snow_block
fill 153 231 277 154 233 277 minecraft:packed_ice
setblock 153 231 316 minecraft:snow_block
fill 154 231 276 157 231 276 minecraft:packed_ice
setblock 154 231 315 minecraft:snow_block
fill 154 231 316 157 231 316 minecraft:packed_ice
fill 155 231 315 158 231 315 minecraft:packed_ice
fill 157 231 317 157 237 317 minecraft:packed_ice
setblock 158 231 276 minecraft:snow_block
setblock 158 231 316 minecraft:snow_block
fill 159 231 276 159 234 276 minecraft:packed_ice
setblock 159 231 315 minecraft:snow_block
fill 159 231 316 159 234 316 minecraft:packed_ice
setblock 160 231 314 minecraft:snow_block
fill 160 231 315 160 234 315 minecraft:packed_ice
setblock 161 231 277 minecraft:packed_ice
fill 161 231 312 161 232 312 minecraft:packed_ice
fill 161 231 314 161 234 314 minecraft:packed_ice
setblock 162 231 277 minecraft:snow_block
fill 162 231 311 162 232 311 minecraft:packed_ice
fill 162 231 313 162 232 313 minecraft:packed_ice
setblock 163 231 276 minecraft:snow_block
fill 163 231 277 166 231 277 minecraft:packed_ice
fill 163 231 312 163 232 312 minecraft:packed_ice
setblock 163 231 316 minecraft:snow_block
fill 164 231 276 164 234 276 minecraft:packed_ice
setblock 164 231 315 minecraft:snow_block
fill 164 231 316 164 234 316 minecraft:packed_ice
setblock 165 231 314 minecraft:snow_block
fill 165 231 315 165 234 315 minecraft:packed_ice
fill 166 231 314 166 234 314 minecraft:packed_ice
setblock 167 231 277 minecraft:snow_block
setblock 168 231 276 minecraft:snow_block
fill 168 231 277 168 234 277 minecraft:packed_ice
setblock 168 231 316 minecraft:snow_block
fill 169 231 276 169 234 276 minecraft:packed_ice
setblock 169 231 315 minecraft:snow_block
fill 169 231 316 169 234 316 minecraft:packed_ice
fill 170 231 315 170 233 315 minecraft:packed_ice
fill 172 231 275 172 237 275 minecraft:packed_ice
setblock 173 231 316 minecraft:snow_block
fill 174 231 316 174 232 316 minecraft:packed_ice
fill 176 231 314 176 233 314 minecraft:packed_ice
fill 177 231 313 177 233 313 minecraft:packed_ice
fill 177 231 315 177 233 315 minecraft:packed_ice
fill 178 231 310 178 237 310 minecraft:packed_ice
fill 178 231 314 178 233 314 minecraft:packed_ice
fill 179 231 276 179 234 276 minecraft:packed_ice
fill 180 231 292 180 231 293 minecraft:packed_ice
setblock 180 231 294 minecraft:snow_block
fill 180 231 295 180 232 297 minecraft:packed_ice
fill 180 231 316 180 233 316 minecraft:packed_ice
setblock 181 231 277 minecraft:packed_ice
setblock 181 231 288 minecraft:snow_block
fill 181 231 289 181 234 289 minecraft:packed_ice
setblock 181 231 293 minecraft:snow_block
fill 181 231 294 181 234 294 minecraft:packed_ice
setblock 181 231 298 minecraft:snow_block
fill 181 231 299 181 233 300 minecraft:packed_ice
setblock 182 231 276 minecraft:packed_ice
setblock 182 231 277 minecraft:snow_block
fill 182 231 278 182 231 281 minecraft:packed_ice
setblock 182 231 282 minecraft:snow_block
fill 182 231 283 182 234 283 minecraft:packed_ice
setblock 182 231 287 minecraft:snow_block
fill 182 231 288 182 234 288 minecraft:packed_ice
setblock 182 231 292 minecraft:snow_block
fill 182 231 293 182 234 293 minecraft:packed_ice
setblock 182 231 297 minecraft:snow_block
fill 182 231 298 182 234 298 minecraft:packed_ice
setblock 182 231 302 minecraft:snow_block
fill 182 231 303 182 234 303 minecraft:packed_ice
setblock 182 231 312 minecraft:snow_block
fill 182 231 313 182 234 313 minecraft:packed_ice
fill 183 231 297 183 238 297 minecraft:packed_ice
fill 141 232 292 142 235 292 minecraft:packed_ice
fill 141 232 302 142 235 302 minecraft:packed_ice
setblock 142 232 276 minecraft:snow_block
fill 142 232 277 142 235 277 minecraft:packed_ice
setblock 142 232 280 minecraft:packed_ice
setblock 142 232 281 minecraft:snow_block
fill 142 232 282 142 235 282 minecraft:packed_ice
setblock 142 232 286 minecraft:snow_block
fill 142 232 287 142 235 287 minecraft:packed_ice
setblock 142 232 291 minecraft:snow_block
setblock 142 232 296 minecraft:snow_block
fill 142 232 297 142 235 297 minecraft:packed_ice
setblock 142 232 301 minecraft:snow_block
fill 142 232 303 142 234 303 minecraft:packed_ice
setblock 142 232 311 minecraft:snow_block
fill 142 232 312 143 234 312 minecraft:packed_ice
setblock 142 232 315 minecraft:packed_ice
setblock 142 232 316 minecraft:snow_block
fill 143 232 276 143 235 276 minecraft:packed_ice
setblock 143 232 280 minecraft:snow_block
fill 143 232 281 143 235 281 minecraft:packed_ice
setblock 143 232 285 minecraft:snow_block
fill 143 232 286 143 235 286 minecraft:packed_ice
setblock 143 232 290 minecraft:snow_block
fill 143 232 291 143 235 291 minecraft:packed_ice
setblock 143 232 295 minecraft:snow_block
fill 143 232 296 143 235 296 minecraft:packed_ice
setblock 143 232 300 minecraft:snow_block
setblock 143 232 315 minecraft:snow_block
fill 143 232 316 143 235 316 minecraft:packed_ice
setblock 144 232 279 minecraft:snow_block
fill 144 232 280 145 234 280 minecraft:packed_ice
fill 144 232 282 144 232 283 minecraft:packed_ice
setblock 144 232 286 minecraft:light[level=15]
setblock 144 232 294 minecraft:snow_block
fill 144 232 295 144 235 295 minecraft:packed_ice
fill 144 232 297 144 232 298 minecraft:packed_ice
setblock 144 232 302 minecraft:light[level=15]
setblock 144 232 310 minecraft:light[level=15]
setblock 144 232 314 minecraft:snow_block
fill 144 232 315 144 235 315 minecraft:packed_ice
setblock 145 232 277 minecraft:packed_ice
setblock 145 232 278 minecraft:snow_block
fill 145 232 279 147 233 279 minecraft:packed_ice
fill 145 232 314 145 235 314 minecraft:packed_ice
setblock 146 232 277 minecraft:snow_block
fill 146 232 278 146 235 278 minecraft:packed_ice
setblock 147 232 276 minecraft:snow_block
fill 147 232 277 147 235 277 minecraft:packed_ice
setblock 147 232 316 minecraft:snow_block
fill 148 232 276 148 235 276 minecraft:packed_ice
setblock 148 232 315 minecraft:snow_block
fill 148 232 316 148 235 316 minecraft:packed_ice
setblock 149 232 314 minecraft:snow_block
fill 149 232 315 152 232 315 minecraft:packed_ice
setblock 150 232 278 minecraft:snow_block
setblock 150 232 314 minecraft:packed_ice
setblock 151 232 277 minecraft:snow_block
setblock 152 232 276 minecraft:snow_block
fill 152 232 277 152 235 277 minecraft:packed_ice
setblock 152 232 278 minecraft:light[level=15]
setblock 152 232 286 minecraft:light[level=15]
setblock 152 232 294 minecraft:light[level=15]
setblock 152 232 302 minecraft:light[level=15]
setblock 152 232 310 minecraft:light[level=15]
setblock 152 232 316 minecraft:snow_block
fill 153 232 276 156 232 276 minecraft:packed_ice
setblock 153 232 315 minecraft:snow_block
fill 153 232 316 156 232 316 minecraft:packed_ice
fill 154 232 315 157 232 315 minecraft:packed_ice
setblock 155 232 277 minecraft:packed_ice
setblock 157 232 276 minecraft:snow_block
setblock 157 232 316 minecraft:snow_block
fill 158 232 276 158 234 277 minecraft:packed_ice
setblock 158 232 315 minecraft:snow_block
fill 158 232 316 158 235 316 minecraft:packed_ice
fill 159 232 277 160 232 277 minecraft:packed_ice
setblock 159 232 314 minecraft:snow_block
fill 159 232 315 159 235 315 minecraft:packed_ice
setblock 160 232 278 minecraft:light[level=15]
setblock 160 232 286 minecraft:light[level=15]
setblock 160 232 294 minecraft:light[level=15]
setblock 160 232 302 minecraft:light[level=15]
setblock 160 232 310 minecraft:light[level=15]
fill 160 232 314 160 235 314 minecraft:packed_ice
setblock 161 232 277 minecraft:snow_block
setblock 162 232 276 minecraft:snow_block
fill 162 232 277 165 232 277 minecraft:packed_ice
setblock 162 232 316 minecraft:snow_block
fill 163 232 276 163 235 276 minecraft:packed_ice
setblock 163 232 315 minecraft:snow_block
fill 163 232 316 163 235 316 minecraft:packed_ice
setblock 164 232 314 minecraft:snow_block
fill 164 232 315 164 235 315 minecraft:packed_ice
fill 165 232 314 165 235 314 minecraft:packed_ice
setblock 165 232 317 minecraft:white_concrete
setblock 166 232 277 minecraft:snow_block
setblock 167 232 276 minecraft:snow_block
fill 167 232 277 167 235 277 minecraft:packed_ice
setblock 167 232 316 minecraft:snow_block
fill 168 232 276 168 235 276 minecraft:packed_ice
setblock 168 232 278 minecraft:light[level=15]
setblock 168 232 286 minecraft:light[level=15]
setblock 168 232 294 minecraft:light[level=15]
setblock 168 232 302 minecraft:light[level=15]
setblock 168 232 310 minecraft:light[level=15]
setblock 168 232 315 minecraft:snow_block
fill 168 232 316 168 235 316 minecraft:packed_ice
fill 169 232 277 169 233 277 minecraft:packed_ice
fill 169 232 291 170 233 291 minecraft:snow_block
fill 169 232 315 169 234 315 minecraft:packed_ice
fill 171 232 278 171 234 278 minecraft:packed_ice
setblock 172 232 276 minecraft:snow_block
setblock 172 232 316 minecraft:snow_block
fill 173 232 276 173 235 276 minecraft:packed_ice
fill 173 232 278 173 234 278 minecraft:packed_ice
fill 173 232 316 173 233 316 minecraft:packed_ice
fill 174 232 287 174 233 287 minecraft:blue_ice
setblock 176 232 278 minecraft:light[level=15]
setblock 176 232 286 minecraft:light[level=15]
setblock 176 232 294 minecraft:light[level=15]
setblock 176 232 302 minecraft:light[level=15]
setblock 176 232 310 minecraft:light[level=15]
setblock 177 232 276 minecraft:snow_block
fill 178 232 276 178 235 276 minecraft:packed_ice
fill 179 232 316 179 234 316 minecraft:packed_ice
setblock 180 232 277 minecraft:packed_ice
setblock 180 232 292 minecraft:packed_ice
setblock 180 232 293 minecraft:snow_block
fill 180 232 294 180 235 294 minecraft:packed_ice
setblock 180 232 298 minecraft:snow_block
fill 180 232 299 180 235 299 minecraft:packed_ice
setblock 181 232 277 minecraft:snow_block
fill 181 232 278 181 232 281 minecraft:packed_ice
setblock 181 232 282 minecraft:snow_block
setblock 181 232 287 minecraft:snow_block
fill 181 232 288 181 235 288 minecraft:packed_ice
setblock 181 232 292 minecraft:snow_block
fill 181 232 293 181 235 293 minecraft:packed_ice
setblock 181 232 297 minecraft:snow_block
fill 181 232 298 181 235 298 minecraft:packed_ice
setblock 181 232 301 minecraft:packed_ice
setblock 181 232 302 minecraft:snow_block
setblock 182 232 276 minecraft:snow_block
fill 182 232 277 182 232 280 minecraft:packed_ice
setblock 182 232 281 minecraft:snow_block
fill 182 232 282 182 235 282 minecraft:packed_ice
setblock 182 232 286 minecraft:snow_block
fill 182 232 287 182 235 287 minecraft:packed_ice
setblock 182 232 291 minecraft:snow_block
fill 182 232 292 182 235 292 minecraft:packed_ice
setblock 182 232 296 minecraft:snow_block
fill 182 232 297 182 235 297 minecraft:packed_ice
setblock 182 232 300 minecraft:packed_ice
setblock 182 232 301 minecraft:snow_block
fill 182 232 302 182 235 302 minecraft:packed_ice
fill 182 232 304 182 233 304 minecraft:packed_ice
fill 182 232 312 182 235 312 minecraft:packed_ice
setblock 182 232 315 minecraft:packed_ice
setblock 182 232 316 minecraft:snow_block
fill 183 232 296 183 234 296 minecraft:packed_ice
fill 141 233 282 141 234 283 minecraft:packed_ice
setblock 141 233 284 minecraft:light_blue_concrete
setblock 141 233 293 minecraft:light_blue_concrete
fill 142 233 276 142 236 276 minecraft:packed_ice
setblock 142 233 280 minecraft:snow_block
fill 142 233 281 142 236 281 minecraft:packed_ice
setblock 142 233 284 minecraft:packed_ice
setblock 142 233 285 minecraft:snow_block
fill 142 233 286 142 236 286 minecraft:packed_ice
setblock 142 233 290 minecraft:snow_block
fill 142 233 291 142 236 291 minecraft:packed_ice
setblock 142 233 295 minecraft:snow_block
fill 142 233 296 142 236 296 minecraft:packed_ice
setblock 142 233 299 minecraft:packed_ice
setblock 142 233 300 minecraft:snow_block
fill 142 233 301 143 235 301 minecraft:packed_ice
setblock 142 233 304 minecraft:packed_ice
setblock 142 233 305 minecraft:snow_block
setblock 142 233 310 minecraft:snow_block
fill 142 233 311 142 236 311 minecraft:packed_ice
setblock 142 233 315 minecraft:snow_block
fill 142 233 316 142 236 316 minecraft:packed_ice
setblock 143 233 278 minecraft:packed_ice
setblock 143 233 279 minecraft:snow_block
fill 143 233 280 143 236 280 minecraft:packed_ice
setblock 143 233 284 minecraft:snow_block
fill 143 233 285 143 236 285 minecraft:packed_ice
setblock 143 233 289 minecraft:snow_block
fill 143 233 290 143 236 290 minecraft:packed_ice
setblock 143 233 294 minecraft:snow_block
fill 143 233 295 143 236 295 minecraft:packed_ice
setblock 143 233 299 minecraft:snow_block
fill 143 233 300 143 236 300 minecraft:packed_ice
fill 143 233 302 143 234 302 minecraft:packed_ice
setblock 143 233 314 minecraft:snow_block
fill 143 233 315 143 236 315 minecraft:packed_ice
setblock 144 233 278 minecraft:snow_block
fill 144 233 279 144 236 279 minecraft:packed_ice
setblock 144 233 282 minecraft:packed_ice
setblock 144 233 283 minecraft:snow_block
fill 144 233 284 144 236 284 minecraft:packed_ice
setblock 144 233 293 minecraft:snow_block
fill 144 233 294 144 234 294 minecraft:packed_ice
setblock 144 233 297 minecraft:packed_ice
setblock 144 233 298 minecraft:snow_block
fill 144 233 299 144 236 299 minecraft:packed_ice
fill 144 233 314 144 235 314 minecraft:packed_ice
setblock 145 233 277 minecraft:snow_block
fill 145 233 278 145 236 278 minecraft:packed_ice
setblock 145 233 281 minecraft:packed_ice
setblock 146 233 276 minecraft:snow_block
fill 146 233 277 146 236 277 minecraft:packed_ice
setblock 146 233 316 minecraft:snow_block
fill 147 233 276 147 236 276 minecraft:packed_ice
setblock 147 233 315 minecraft:snow_block
fill 147 233 316 147 236 316 minecraft:packed_ice
setblock 148 233 279 minecraft:snow_block
setblock 148 233 314 minecraft:snow_block
fill 148 233 315 151 233 315 minecraft:packed_ice
setblock 149 233 278 minecraft:snow_block
setblock 149 233 314 minecraft:packed_ice
setblock 150 233 277 minecraft:snow_block
fill 150 233 278 151 234 278 minecraft:packed_ice
setblock 151 233 276 minecraft:snow_block
fill 151 233 277 151 236 277 minecraft:packed_ice
setblock 151 233 316 minecraft:snow_block
fill 152 233 276 155 233 276 minecraft:packed_ice
setblock 152 233 315 minecraft:snow_block
fill 152 233 316 155 233 316 minecraft:packed_ice
fill 153 233 315 156 233 315 minecraft:packed_ice
setblock 155 233 277 minecraft:snow_block
setblock 156 233 276 minecraft:snow_block
fill 156 233 277 157 235 277 minecraft:packed_ice
setblock 156 233 316 minecraft:snow_block
fill 157 233 276 157 236 276 minecraft:packed_ice
setblock 157 233 315 minecraft:snow_block
fill 157 233 316 157 236 316 minecraft:packed_ice
fill 158 233 315 158 236 315 minecraft:packed_ice
setblock 159 233 277 minecraft:packed_ice
fill 159 233 314 159 235 314 minecraft:packed_ice
setblock 160 233 277 minecraft:snow_block
setblock 161 233 276 minecraft:snow_block
fill 161 233 277 164 233 277 minecraft:packed_ice
setblock 161 233 316 minecraft:snow_block
fill 162 233 276 162 236 276 minecraft:packed_ice
setblock 162 233 315 minecraft:snow_block
fill 162 233 316 162 236 316 minecraft:packed_ice
setblock 163 233 314 minecraft:snow_block
fill 163 233 315 163 236 315 minecraft:packed_ice
fill 164 233 314 164 235 314 minecraft:packed_ice
setblock 165 233 277 minecraft:snow_block
fill 165 233 317 165 237 317 minecraft:packed_ice
setblock 166 233 276 minecraft:snow_block
fill 166 233 277 166 236 277 minecraft:packed_ice
setblock 166 233 316 minecraft:snow_block
fill 167 233 276 167 236 276 minecraft:packed_ice
setblock 167 233 315 minecraft:snow_block
fill 167 233 316 167 236 316 minecraft:packed_ice
fill 168 233 315 168 235 315 minecraft:packed_ice
setblock 168 233 317 minecraft:light_blue_concrete
setblock 171 233 276 minecraft:snow_block
setblock 171 233 316 minecraft:snow_block
fill 172 233 276 172 236 276 minecraft:packed_ice
fill 172 233 316 172 234 316 minecraft:packed_ice
fill 174 233 276 175 233 276 minecraft:packed_ice
setblock 176 233 276 minecraft:snow_block
fill 177 233 276 177 236 276 minecraft:packed_ice
fill 178 233 316 178 235 316 minecraft:packed_ice
setblock 179 233 277 minecraft:packed_ice
setblock 180 233 276 minecraft:packed_ice
setblock 180 233 277 minecraft:snow_block
setblock 180 233 291 minecraft:packed_ice
setblock 180 233 292 minecraft:snow_block
fill 180 233 293 180 236 293 minecraft:packed_ice
fill 180 233 295 180 233 296 minecraft:packed_ice
setblock 180 233 297 minecraft:snow_block
fill 180 233 298 180 236 298 minecraft:packed_ice
fill 180 233 300 180 234 300 minecraft:packed_ice
setblock 181 233 276 minecraft:snow_block
fill 181 233 277 181 233 280 minecraft:packed_ice
setblock 181 233 281 minecraft:snow_block
fill 181 233 282 181 233 285 minecraft:packed_ice
setblock 181 233 286 minecraft:snow_block
fill 181 233 287 181 236 287 minecraft:packed_ice
setblock 181 233 291 minecraft:snow_block
fill 181 233 292 181 236 292 minecraft:packed_ice
setblock 181 233 296 minecraft:snow_block
fill 181 233 297 181 236 297 minecraft:packed_ice
setblock 181 233 301 minecraft:snow_block
fill 181 233 302 181 235 303 minecraft:packed_ice
setblock 181 233 316 minecraft:snow_block
fill 182 233 276 182 233 279 minecraft:packed_ice
setblock 182 233 280 minecraft:snow_block
fill 182 233 281 182 236 281 minecraft:packed_ice
setblock 182 233 284 minecraft:packed_ice
setblock 182 233 285 minecraft:snow_block
fill 182 233 286 182 236 286 minecraft:packed_ice
setblock 182 233 290 minecraft:snow_block
fill 182 233 291 182 236 291 minecraft:packed_ice
setblock 182 233 295 minecraft:snow_block
fill 182 233 296 182 236 296 minecraft:packed_ice
setblock 182 233 300 minecraft:snow_block
fill 182 233 301 182 236 301 minecraft:packed_ice
setblock 182 233 305 minecraft:snow_block
fill 182 233 306 182 236 306 minecraft:packed_ice
setblock 182 233 315 minecraft:snow_block
fill 182 233 316 182 236 316 minecraft:packed_ice
fill 141 234 279 141 237 279 minecraft:packed_ice
fill 141 234 280 141 235 280 minecraft:snow_block
fill 141 234 281 141 237 281 minecraft:packed_ice
fill 141 234 284 141 237 284 minecraft:packed_ice
setblock 141 234 293 minecraft:packed_ice
fill 141 234 316 141 235 316 minecraft:snow_block
setblock 142 234 279 minecraft:snow_block
fill 142 234 280 142 237 280 minecraft:packed_ice
setblock 142 234 284 minecraft:snow_block
fill 142 234 285 142 237 285 minecraft:packed_ice
setblock 142 234 289 minecraft:snow_block
fill 142 234 290 142 237 290 minecraft:packed_ice
setblock 142 234 294 minecraft:snow_block
fill 142 234 295 142 237 295 minecraft:packed_ice
setblock 142 234 299 minecraft:snow_block
fill 142 234 300 142 237 300 minecraft:packed_ice
setblock 142 234 304 minecraft:snow_block
fill 142 234 305 142 234 308 minecraft:packed_ice
setblock 142 234 309 minecraft:snow_block
fill 142 234 310 142 237 310 minecraft:packed_ice
setblock 142 234 314 minecraft:snow_block
fill 142 234 315 142 237 315 minecraft:packed_ice
setblock 143 234 278 minecraft:snow_block
fill 143 234 279 143 237 279 minecraft:packed_ice
setblock 143 234 283 minecraft:snow_block
fill 143 234 284 143 237 284 minecraft:packed_ice
setblock 143 234 288 minecraft:snow_block
fill 143 234 289 143 236 289 minecraft:packed_ice
setblock 143 234 293 minecraft:snow_block
fill 143 234 294 143 237 294 minecraft:packed_ice
setblock 143 234 298 minecraft:snow_block
fill 143 234 299 143 237 299 minecraft:packed_ice
setblock 143 234 303 minecraft:snow_block
setblock 143 234 313 minecraft:snow_block
fill 143 234 314 143 237 314 minecraft:packed_ice
setblock 144 234 277 minecraft:snow_block
fill 144 234 278 144 237 278 minecraft:packed_ice
setblock 144 234 282 minecraft:snow_block
fill 144 234 283 144 237 283 minecraft:packed_ice
setblock 144 234 285 minecraft:light[level=12]
setblock 144 234 292 minecraft:light[level=12]
setblock 144 234 297 minecraft:snow_block
fill 144 234 298 144 236 298 minecraft:packed_ice
fill 144 234 300 144 235 300 minecraft:packed_ice
setblock 144 234 306 minecraft:light[level=12]
setblock 144 234 313 minecraft:light[level=12]
setblock 145 234 276 minecraft:snow_block
fill 145 234 277 145 237 277 minecraft:packed_ice
fill 145 234 279 146 234 279 minecraft:packed_ice
setblock 145 234 281 minecraft:snow_block
setblock 145 234 316 minecraft:snow_block
fill 146 234 276 146 237 276 minecraft:packed_ice
setblock 146 234 315 minecraft:snow_block
fill 146 234 316 146 237 316 minecraft:packed_ice
setblock 147 234 279 minecraft:snow_block
setblock 147 234 314 minecraft:snow_block
fill 147 234 315 150 234 315 minecraft:packed_ice
setblock 148 234 278 minecraft:snow_block
setblock 148 234 279 minecraft:packed_ice
setblock 148 234 314 minecraft:packed_ice
setblock 149 234 277 minecraft:snow_block
fill 149 234 278 149 236 278 minecraft:packed_ice
setblock 150 234 276 minecraft:snow_block
fill 150 234 277 150 237 277 minecraft:packed_ice
setblock 150 234 316 minecraft:snow_block
fill 151 234 276 154 234 276 minecraft:packed_ice
setblock 151 234 285 minecraft:light[level=12]
setblock 151 234 292 minecraft:light[level=12]
setblock 151 234 299 minecraft:light[level=12]
setblock 151 234 306 minecraft:light[level=12]
setblock 151 234 313 minecraft:light[level=12]
setblock 151 234 315 minecraft:snow_block
fill 151 234 316 154 234 316 minecraft:packed_ice
fill 152 234 315 155 234 315 minecraft:packed_ice
setblock 153 234 277 minecraft:packed_ice
fill 153 234 311 153 235 311 minecraft:packed_ice
setblock 154 234 277 minecraft:snow_block
fill 154 234 310 154 235 310 minecraft:packed_ice
fill 154 234 312 154 235 312 minecraft:packed_ice
setblock 155 234 276 minecraft:snow_block
fill 155 234 277 155 236 277 minecraft:packed_ice
fill 155 234 311 155 235 311 minecraft:packed_ice
setblock 155 234 316 minecraft:snow_block
fill 156 234 276 156 237 276 minecraft:packed_ice
setblock 156 234 315 minecraft:snow_block
fill 156 234 316 156 237 316 minecraft:packed_ice
fill 157 234 315 157 237 315 minecraft:packed_ice
schedule function dropper:buildpart/63_9 1t
