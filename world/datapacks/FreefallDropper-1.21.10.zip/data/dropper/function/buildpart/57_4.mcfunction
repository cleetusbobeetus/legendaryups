fill 455 254 228 455 273 228 minecraft:black_concrete
fill 461 254 228 461 308 228 minecraft:black_concrete
setblock 465 254 264 minecraft:pearlescent_froglight
setblock 423 255 236 minecraft:white_concrete
fill 423 255 237 423 263 237 minecraft:black_concrete
setblock 426 255 231 minecraft:light[level=15]
setblock 426 255 239 minecraft:light[level=15]
setblock 426 255 247 minecraft:light[level=15]
setblock 426 255 255 minecraft:light[level=15]
setblock 426 255 263 minecraft:light[level=15]
setblock 434 255 231 minecraft:light[level=15]
setblock 434 255 239 minecraft:light[level=15]
setblock 434 255 247 minecraft:light[level=15]
setblock 434 255 255 minecraft:light[level=15]
setblock 434 255 263 minecraft:light[level=15]
fill 439 255 242 441 256 242 minecraft:andesite
fill 440 255 243 440 256 243 minecraft:andesite
setblock 442 255 231 minecraft:light[level=15]
setblock 442 255 239 minecraft:light[level=15]
setblock 442 255 247 minecraft:light[level=15]
setblock 442 255 255 minecraft:light[level=15]
setblock 442 255 263 minecraft:light[level=15]
setblock 444 255 228 minecraft:ochre_froglight
fill 448 255 270 448 268 270 minecraft:black_concrete
setblock 450 255 231 minecraft:light[level=15]
setblock 450 255 239 minecraft:light[level=15]
setblock 450 255 247 minecraft:light[level=15]
setblock 450 255 255 minecraft:light[level=15]
setblock 450 255 263 minecraft:light[level=15]
setblock 458 255 231 minecraft:light[level=15]
setblock 458 255 239 minecraft:light[level=15]
setblock 458 255 247 minecraft:light[level=15]
setblock 458 255 255 minecraft:light[level=15]
setblock 458 255 263 minecraft:light[level=15]
setblock 465 255 240 minecraft:purple_terracotta
setblock 465 255 246 minecraft:pearlescent_froglight
setblock 465 255 247 minecraft:white_concrete
setblock 465 255 250 minecraft:sea_lantern
fill 465 255 264 465 295 264 minecraft:black_concrete
fill 423 256 236 423 308 236 minecraft:black_concrete
fill 424 256 260 430 256 260 minecraft:gray_concrete
setblock 426 256 231 minecraft:light[level=12]
setblock 426 256 238 minecraft:light[level=12]
setblock 426 256 245 minecraft:light[level=12]
setblock 426 256 252 minecraft:light[level=12]
fill 426 256 258 430 257 259 minecraft:gray_concrete
fill 426 256 261 430 257 262 minecraft:gray_concrete
setblock 426 256 266 minecraft:light[level=12]
setblock 431 256 228 minecraft:purple_terracotta
setblock 433 256 231 minecraft:light[level=12]
setblock 433 256 238 minecraft:light[level=12]
setblock 433 256 245 minecraft:light[level=12]
setblock 433 256 252 minecraft:light[level=12]
setblock 433 256 259 minecraft:light[level=12]
setblock 433 256 266 minecraft:light[level=12]
setblock 440 256 231 minecraft:light[level=12]
setblock 440 256 238 minecraft:light[level=12]
setblock 440 256 245 minecraft:light[level=12]
setblock 440 256 252 minecraft:light[level=12]
setblock 440 256 259 minecraft:light[level=12]
setblock 440 256 266 minecraft:light[level=12]
fill 444 256 228 444 284 228 minecraft:black_concrete
setblock 447 256 231 minecraft:light[level=12]
setblock 447 256 238 minecraft:light[level=12]
setblock 447 256 245 minecraft:light[level=12]
setblock 447 256 252 minecraft:light[level=12]
setblock 447 256 259 minecraft:light[level=12]
setblock 447 256 266 minecraft:light[level=12]
setblock 454 256 231 minecraft:light[level=12]
setblock 454 256 238 minecraft:light[level=12]
setblock 454 256 245 minecraft:light[level=12]
setblock 454 256 252 minecraft:light[level=12]
setblock 454 256 259 minecraft:light[level=12]
setblock 454 256 266 minecraft:light[level=12]
setblock 461 256 231 minecraft:light[level=12]
setblock 461 256 238 minecraft:light[level=12]
setblock 461 256 245 minecraft:light[level=12]
setblock 461 256 252 minecraft:light[level=12]
setblock 461 256 259 minecraft:light[level=12]
setblock 461 256 266 minecraft:light[level=12]
fill 465 256 240 465 282 240 minecraft:black_concrete
fill 465 256 246 465 308 247 minecraft:black_concrete
fill 465 256 250 465 265 250 minecraft:black_concrete
fill 426 257 260 430 257 260 minecraft:gray_concrete
fill 431 257 228 431 297 228 minecraft:black_concrete
setblock 434 257 228 minecraft:sea_lantern
setblock 435 257 270 minecraft:ochre_froglight
setblock 423 258 231 minecraft:pearlescent_froglight
fill 434 258 228 434 308 228 minecraft:black_concrete
fill 435 258 270 435 302 270 minecraft:black_concrete
setblock 465 258 252 minecraft:pearlescent_froglight
setblock 465 258 253 minecraft:white_concrete
setblock 423 259 231 minecraft:magenta_terracotta
fill 428 259 260 428 266 260 minecraft:orange_concrete
setblock 461 259 270 minecraft:pearlescent_froglight
fill 465 259 252 465 273 253 minecraft:black_concrete
setblock 465 259 255 minecraft:sea_lantern
fill 423 260 231 423 283 231 minecraft:black_concrete
fill 426 260 259 427 265 261 minecraft:orange_concrete
fill 427 260 258 429 265 258 minecraft:orange_concrete
fill 427 260 262 429 265 262 minecraft:orange_concrete
fill 428 260 259 430 265 259 minecraft:orange_concrete
fill 428 260 261 430 265 261 minecraft:orange_concrete
fill 429 260 260 430 265 260 minecraft:orange_concrete
fill 461 260 270 461 293 270 minecraft:black_concrete
fill 465 260 255 465 294 255 minecraft:black_concrete
setblock 465 260 263 minecraft:sea_lantern
setblock 423 261 253 minecraft:ochre_froglight
setblock 423 261 262 minecraft:white_concrete
fill 425 261 259 425 264 261 minecraft:orange_concrete
fill 426 261 258 426 264 258 minecraft:orange_concrete
fill 426 261 262 426 264 262 minecraft:orange_concrete
fill 427 261 257 429 264 257 minecraft:orange_concrete
fill 427 261 263 429 264 263 minecraft:orange_concrete
fill 430 261 258 430 264 258 minecraft:orange_concrete
fill 430 261 262 430 264 262 minecraft:orange_concrete
fill 431 261 259 431 264 261 minecraft:orange_concrete
setblock 436 261 270 minecraft:pearlescent_froglight
setblock 447 261 228 minecraft:ochre_froglight
setblock 448 261 228 minecraft:white_concrete
fill 465 261 263 465 308 263 minecraft:black_concrete
fill 423 262 253 423 282 253 minecraft:black_concrete
fill 423 262 262 423 308 262 minecraft:black_concrete
setblock 426 262 231 minecraft:light[level=15]
setblock 426 262 238 minecraft:light[level=12]
setblock 426 262 239 minecraft:light[level=15]
setblock 426 262 245 minecraft:light[level=12]
setblock 426 262 247 minecraft:light[level=15]
setblock 426 262 252 minecraft:light[level=12]
setblock 426 262 255 minecraft:light[level=15]
setblock 426 262 263 minecraft:light[level=15]
setblock 426 262 266 minecraft:light[level=12]
setblock 429 262 270 minecraft:magenta_terracotta
setblock 433 262 231 minecraft:light[level=12]
setblock 433 262 238 minecraft:light[level=12]
setblock 433 262 245 minecraft:light[level=12]
setblock 433 262 252 minecraft:light[level=12]
setblock 433 262 259 minecraft:light[level=12]
setblock 433 262 266 minecraft:light[level=12]
setblock 434 262 231 minecraft:light[level=15]
setblock 434 262 239 minecraft:light[level=15]
setblock 434 262 247 minecraft:light[level=15]
setblock 434 262 255 minecraft:light[level=15]
setblock 434 262 263 minecraft:light[level=15]
fill 436 262 270 436 308 270 minecraft:black_concrete
setblock 440 262 231 minecraft:light[level=12]
setblock 440 262 238 minecraft:light[level=12]
setblock 440 262 245 minecraft:light[level=12]
setblock 440 262 252 minecraft:light[level=12]
setblock 440 262 259 minecraft:light[level=12]
setblock 440 262 266 minecraft:light[level=12]
setblock 442 262 231 minecraft:light[level=15]
setblock 442 262 239 minecraft:light[level=15]
setblock 442 262 247 minecraft:light[level=15]
setblock 442 262 255 minecraft:light[level=15]
setblock 442 262 263 minecraft:light[level=15]
setblock 443 262 270 minecraft:magenta_terracotta
fill 447 262 228 448 265 228 minecraft:black_concrete
setblock 447 262 231 minecraft:light[level=12]
setblock 447 262 238 minecraft:light[level=12]
setblock 447 262 245 minecraft:light[level=12]
setblock 447 262 252 minecraft:light[level=12]
setblock 447 262 259 minecraft:light[level=12]
setblock 447 262 266 minecraft:light[level=12]
setblock 450 262 231 minecraft:light[level=15]
setblock 450 262 239 minecraft:light[level=15]
setblock 450 262 247 minecraft:light[level=15]
setblock 450 262 255 minecraft:light[level=15]
setblock 450 262 263 minecraft:light[level=15]
setblock 454 262 231 minecraft:light[level=12]
setblock 454 262 238 minecraft:light[level=12]
setblock 454 262 245 minecraft:light[level=12]
setblock 454 262 252 minecraft:light[level=12]
setblock 454 262 259 minecraft:light[level=12]
setblock 454 262 266 minecraft:light[level=12]
setblock 458 262 231 minecraft:light[level=15]
setblock 458 262 239 minecraft:light[level=15]
setblock 458 262 247 minecraft:light[level=15]
setblock 458 262 255 minecraft:light[level=15]
setblock 458 262 263 minecraft:light[level=15]
setblock 458 262 270 minecraft:ochre_froglight
setblock 461 262 231 minecraft:light[level=12]
setblock 461 262 238 minecraft:light[level=12]
setblock 461 262 245 minecraft:light[level=12]
setblock 461 262 252 minecraft:light[level=12]
setblock 461 262 259 minecraft:light[level=12]
setblock 461 262 266 minecraft:light[level=12]
setblock 465 262 266 minecraft:pearlescent_froglight
setblock 423 263 252 minecraft:white_concrete
fill 429 263 270 429 308 270 minecraft:black_concrete
fill 443 263 270 443 308 270 minecraft:black_concrete
fill 458 263 270 458 289 270 minecraft:black_concrete
fill 465 263 266 465 275 266 minecraft:black_concrete
setblock 423 264 237 minecraft:pearlescent_froglight
fill 423 264 252 423 293 252 minecraft:black_concrete
fill 423 265 237 423 275 237 minecraft:black_concrete
setblock 426 265 270 minecraft:sea_lantern
setblock 449 265 228 minecraft:sea_lantern
fill 426 266 270 426 287 270 minecraft:black_concrete
setblock 447 266 228 minecraft:purple_concrete
fill 448 266 228 449 274 228 minecraft:black_concrete
setblock 465 266 232 minecraft:sea_lantern
setblock 465 266 244 minecraft:sea_lantern
setblock 465 266 250 minecraft:ochre_froglight
fill 433 267 250 434 268 250 minecraft:gray_concrete
fill 447 267 228 447 279 228 minecraft:black_concrete
setblock 453 267 228 minecraft:blue_concrete
fill 465 267 232 465 305 232 minecraft:black_concrete
fill 465 267 244 465 308 244 minecraft:black_concrete
fill 465 267 250 465 308 250 minecraft:black_concrete
setblock 465 267 260 minecraft:pearlescent_froglight
setblock 424 268 228 minecraft:white_concrete
setblock 426 268 231 minecraft:light[level=12]
setblock 426 268 238 minecraft:light[level=12]
setblock 426 268 245 minecraft:light[level=12]
setblock 426 268 252 minecraft:light[level=12]
setblock 426 268 259 minecraft:light[level=12]
setblock 426 268 266 minecraft:light[level=12]
setblock 433 268 231 minecraft:light[level=12]
setblock 433 268 238 minecraft:light[level=12]
setblock 433 268 245 minecraft:light[level=12]
setblock 433 268 252 minecraft:light[level=12]
setblock 433 268 259 minecraft:light[level=12]
setblock 433 268 266 minecraft:light[level=12]
setblock 439 268 228 minecraft:ochre_froglight
setblock 440 268 231 minecraft:light[level=12]
setblock 440 268 238 minecraft:light[level=12]
setblock 440 268 245 minecraft:light[level=12]
setblock 440 268 252 minecraft:light[level=12]
setblock 440 268 259 minecraft:light[level=12]
setblock 440 268 266 minecraft:light[level=12]
setblock 447 268 231 minecraft:light[level=12]
setblock 447 268 238 minecraft:light[level=12]
setblock 447 268 245 minecraft:light[level=12]
setblock 447 268 252 minecraft:light[level=12]
setblock 447 268 259 minecraft:light[level=12]
setblock 447 268 266 minecraft:light[level=12]
fill 453 268 228 453 299 228 minecraft:black_concrete
setblock 454 268 231 minecraft:light[level=12]
setblock 454 268 238 minecraft:light[level=12]
setblock 454 268 245 minecraft:light[level=12]
setblock 454 268 252 minecraft:light[level=12]
setblock 454 268 259 minecraft:light[level=12]
setblock 454 268 266 minecraft:light[level=12]
setblock 461 268 231 minecraft:light[level=12]
setblock 461 268 238 minecraft:light[level=12]
setblock 461 268 245 minecraft:light[level=12]
setblock 461 268 252 minecraft:light[level=12]
setblock 461 268 259 minecraft:light[level=12]
setblock 461 268 266 minecraft:light[level=12]
fill 465 268 260 465 300 260 minecraft:black_concrete
fill 424 269 228 424 272 228 minecraft:black_concrete
setblock 426 269 231 minecraft:light[level=15]
setblock 426 269 239 minecraft:light[level=15]
setblock 426 269 247 minecraft:light[level=15]
setblock 426 269 255 minecraft:light[level=15]
setblock 426 269 263 minecraft:light[level=15]
setblock 434 269 231 minecraft:light[level=15]
setblock 434 269 239 minecraft:light[level=15]
setblock 434 269 247 minecraft:light[level=15]
setblock 434 269 255 minecraft:light[level=15]
setblock 434 269 263 minecraft:light[level=15]
fill 439 269 228 439 308 228 minecraft:black_concrete
setblock 442 269 231 minecraft:light[level=15]
setblock 442 269 239 minecraft:light[level=15]
setblock 442 269 247 minecraft:light[level=15]
setblock 442 269 255 minecraft:light[level=15]
setblock 442 269 263 minecraft:light[level=15]
setblock 448 269 270 minecraft:sea_lantern
setblock 450 269 231 minecraft:light[level=15]
setblock 450 269 239 minecraft:light[level=15]
setblock 450 269 247 minecraft:light[level=15]
setblock 450 269 255 minecraft:light[level=15]
setblock 450 269 263 minecraft:light[level=15]
setblock 452 269 270 minecraft:ochre_froglight
setblock 458 269 231 minecraft:light[level=15]
setblock 458 269 239 minecraft:light[level=15]
setblock 458 269 247 minecraft:light[level=15]
setblock 458 269 255 minecraft:light[level=15]
setblock 458 269 263 minecraft:light[level=15]
fill 448 270 270 448 297 270 minecraft:black_concrete
fill 452 270 270 452 294 270 minecraft:black_concrete
setblock 457 270 228 minecraft:sea_lantern
setblock 462 270 270 minecraft:ochre_froglight
setblock 464 270 270 minecraft:magenta_terracotta
setblock 423 271 232 minecraft:white_concrete
setblock 423 271 243 minecraft:purple_terracotta
setblock 423 271 256 minecraft:ochre_froglight
fill 457 271 228 457 297 228 minecraft:black_concrete
fill 462 271 270 462 273 270 minecraft:black_concrete
fill 464 271 270 464 308 270 minecraft:black_concrete
setblock 465 271 241 minecraft:purple_concrete
setblock 465 271 261 minecraft:pearlescent_froglight
fill 423 272 232 423 308 232 minecraft:black_concrete
setblock 423 272 238 minecraft:sea_lantern
fill 423 272 243 423 308 243 minecraft:black_concrete
fill 423 272 256 423 308 256 minecraft:black_concrete
setblock 443 272 228 minecraft:white_concrete
setblock 445 272 228 minecraft:ochre_froglight
fill 465 272 241 465 299 241 minecraft:black_concrete
fill 465 272 261 465 285 261 minecraft:black_concrete
fill 423 273 238 423 308 238 minecraft:black_concrete
setblock 424 273 228 minecraft:sea_lantern
setblock 436 273 228 minecraft:white_concrete
setblock 443 273 228 minecraft:black_concrete
fill 445 273 228 445 276 228 minecraft:black_concrete
fill 460 273 244 462 274 246 minecraft:gold_block
setblock 423 274 242 minecraft:purple_terracotta
fill 424 274 228 424 289 228 minecraft:black_concrete
setblock 426 274 231 minecraft:light[level=12]
setblock 426 274 238 minecraft:light[level=12]
setblock 426 274 245 minecraft:light[level=12]
setblock 426 274 252 minecraft:light[level=12]
setblock 426 274 259 minecraft:light[level=12]
setblock 426 274 266 minecraft:light[level=12]
setblock 431 274 270 minecraft:pearlescent_froglight
setblock 433 274 231 minecraft:light[level=12]
setblock 433 274 238 minecraft:light[level=12]
setblock 433 274 245 minecraft:light[level=12]
setblock 433 274 252 minecraft:light[level=12]
setblock 433 274 259 minecraft:light[level=12]
setblock 433 274 266 minecraft:light[level=12]
setblock 435 274 228 minecraft:white_concrete
fill 436 274 228 436 308 228 minecraft:black_concrete
setblock 440 274 231 minecraft:light[level=12]
setblock 440 274 238 minecraft:light[level=12]
setblock 440 274 245 minecraft:light[level=12]
setblock 440 274 259 minecraft:light[level=12]
setblock 440 274 266 minecraft:light[level=12]
setblock 441 274 270 minecraft:purple_concrete
setblock 443 274 228 minecraft:blue_concrete
setblock 447 274 231 minecraft:light[level=12]
setblock 447 274 238 minecraft:light[level=12]
setblock 447 274 245 minecraft:light[level=12]
setblock 447 274 252 minecraft:light[level=12]
setblock 447 274 259 minecraft:light[level=12]
setblock 447 274 266 minecraft:light[level=12]
setblock 454 274 231 minecraft:light[level=12]
setblock 454 274 238 minecraft:light[level=12]
setblock 454 274 245 minecraft:light[level=12]
setblock 454 274 252 minecraft:light[level=12]
setblock 454 274 259 minecraft:light[level=12]
setblock 454 274 266 minecraft:light[level=12]
setblock 455 274 228 minecraft:pearlescent_froglight
setblock 459 274 270 minecraft:pearlescent_froglight
fill 460 274 239 462 274 243 minecraft:blue_stained_glass
fill 460 274 247 462 274 251 minecraft:blue_stained_glass
setblock 461 274 231 minecraft:light[level=12]
setblock 461 274 238 minecraft:light[level=12]
setblock 461 274 252 minecraft:light[level=12]
setblock 461 274 259 minecraft:light[level=12]
setblock 461 274 266 minecraft:light[level=12]
setblock 462 274 270 minecraft:pearlescent_froglight
setblock 465 274 252 minecraft:sea_lantern
fill 465 274 253 465 308 253 minecraft:black_concrete
fill 423 275 242 423 281 242 minecraft:black_concrete
fill 427 275 247 430 275 251 minecraft:white_concrete
fill 428 275 243 430 275 246 minecraft:white_concrete
fill 428 275 252 430 275 255 minecraft:white_concrete
fill 429 275 241 432 275 242 minecraft:white_concrete
fill 429 275 256 432 275 257 minecraft:white_concrete
fill 430 275 239 433 275 240 minecraft:white_concrete
fill 430 275 258 433 275 259 minecraft:white_concrete
fill 431 275 238 435 275 238 minecraft:white_concrete
fill 431 275 243 431 278 244 minecraft:white_concrete
fill 431 275 254 431 275 255 minecraft:white_concrete
fill 431 275 260 435 275 260 minecraft:white_concrete
fill 431 275 270 431 283 270 minecraft:black_concrete
fill 432 275 237 437 275 237 minecraft:white_concrete
fill 432 275 261 437 275 261 minecraft:white_concrete
fill 433 275 236 439 275 236 minecraft:white_concrete
fill 433 275 262 439 275 262 minecraft:white_concrete
fill 434 275 235 454 275 235 minecraft:white_concrete
setblock 434 275 239 minecraft:white_concrete
setblock 434 275 259 minecraft:white_concrete
fill 434 275 263 454 275 263 minecraft:white_concrete
fill 435 275 228 435 308 228 minecraft:black_concrete
fill 436 275 234 452 275 234 minecraft:white_concrete
fill 436 275 264 452 275 264 minecraft:white_concrete
fill 437 275 247 438 275 251 minecraft:white_concrete
setblock 437 275 270 minecraft:purple_terracotta
fill 438 275 233 450 275 233 minecraft:white_concrete
fill 438 275 245 450 275 246 minecraft:white_concrete
fill 438 275 252 439 275 253 minecraft:white_concrete
fill 438 275 265 450 275 265 minecraft:white_concrete
fill 439 275 244 449 275 244 minecraft:white_concrete
fill 439 275 247 439 278 249 minecraft:white_concrete
fill 439 275 251 439 278 251 minecraft:white_concrete
fill 439 275 254 449 275 254 minecraft:white_concrete
fill 440 275 243 448 275 243 minecraft:white_concrete
fill 440 275 247 441 278 247 minecraft:white_concrete
fill 440 275 253 441 278 253 minecraft:white_concrete
fill 440 275 255 448 275 255 minecraft:white_concrete
fill 441 275 270 441 308 270 minecraft:black_concrete
fill 442 275 232 446 275 232 minecraft:white_concrete
fill 442 275 242 446 275 242 minecraft:white_concrete
fill 442 275 256 446 275 256 minecraft:white_concrete
fill 442 275 266 446 275 266 minecraft:white_concrete
fill 443 275 228 443 308 228 minecraft:black_concrete
fill 443 275 247 451 275 247 minecraft:white_concrete
fill 443 275 253 450 275 253 minecraft:white_concrete
fill 445 275 248 451 275 249 minecraft:white_concrete
fill 445 275 251 450 275 252 minecraft:white_concrete
fill 446 275 250 451 275 250 minecraft:white_concrete
setblock 448 275 228 minecraft:pearlescent_froglight
setblock 449 275 228 minecraft:blue_concrete
fill 449 275 236 455 275 236 minecraft:white_concrete
fill 449 275 262 455 275 262 minecraft:white_concrete
setblock 451 275 228 minecraft:ochre_froglight
fill 451 275 237 456 275 237 minecraft:white_concrete
setblock 451 275 251 minecraft:white_concrete
fill 451 275 261 456 275 261 minecraft:white_concrete
fill 453 275 238 457 275 238 minecraft:white_concrete
fill 453 275 260 457 275 260 minecraft:white_concrete
fill 454 275 239 458 275 239 minecraft:white_concrete
fill 454 275 259 458 275 259 minecraft:white_concrete
fill 455 275 228 455 292 228 minecraft:black_concrete
fill 455 275 240 458 275 240 minecraft:white_concrete
fill 455 275 258 458 275 258 minecraft:white_concrete
fill 456 275 241 459 275 242 minecraft:white_concrete
fill 456 275 256 459 275 257 minecraft:white_concrete
fill 457 275 243 460 275 244 minecraft:white_concrete
fill 457 275 254 460 275 255 minecraft:white_concrete
fill 458 275 245 460 275 253 minecraft:white_concrete
fill 459 275 270 459 308 270 minecraft:black_concrete
fill 461 275 244 462 275 246 minecraft:gold_block
fill 461 275 247 461 275 251 minecraft:white_concrete
fill 462 275 270 462 279 270 minecraft:black_concrete
setblock 465 275 238 minecraft:blue_concrete
setblock 465 275 252 minecraft:black_concrete
setblock 465 275 268 minecraft:white_concrete
setblock 423 276 237 minecraft:pearlescent_froglight
setblock 426 276 231 minecraft:light[level=15]
setblock 426 276 239 minecraft:light[level=15]
setblock 426 276 247 minecraft:light[level=15]
setblock 426 276 255 minecraft:light[level=15]
setblock 426 276 263 minecraft:light[level=15]
fill 427 276 244 430 277 244 minecraft:sea_lantern
setblock 427 276 245 minecraft:blue_stained_glass
setblock 427 276 246 minecraft:black_stained_glass
fill 427 276 247 427 276 248 minecraft:blue_stained_glass
setblock 427 276 249 minecraft:black_stained_glass
fill 427 276 250 427 276 251 minecraft:blue_stained_glass
setblock 427 276 252 minecraft:black_stained_glass
setblock 427 276 253 minecraft:blue_stained_glass
fill 427 276 254 430 277 254 minecraft:white_concrete
fill 428 276 242 430 277 242 minecraft:white_concrete
fill 428 276 243 428 277 243 minecraft:sea_lantern
fill 428 276 245 428 278 246 minecraft:white_concrete
fill 428 276 247 429 277 249 minecraft:sea_lantern
fill 428 276 250 429 278 251 minecraft:white_concrete
fill 428 276 252 428 277 253 minecraft:sea_lantern
fill 428 276 255 428 278 255 minecraft:white_concrete
fill 428 276 256 430 277 256 minecraft:sea_lantern
fill 429 276 240 430 277 241 minecraft:sea_lantern
fill 429 276 243 430 278 243 minecraft:white_concrete
fill 429 276 245 431 277 245 minecraft:sea_lantern
fill 429 276 246 431 277 246 minecraft:white_concrete
fill 429 276 252 431 277 252 minecraft:sea_lantern
fill 429 276 253 431 277 253 minecraft:white_concrete
fill 429 276 255 432 277 255 minecraft:sea_lantern
fill 429 276 257 430 277 258 minecraft:white_concrete
fill 430 276 239 432 278 239 minecraft:white_concrete
fill 430 276 247 430 278 247 minecraft:white_concrete
fill 430 276 248 430 277 249 minecraft:sea_lantern
fill 430 276 250 430 278 250 minecraft:white_concrete
fill 430 276 251 430 277 251 minecraft:sea_lantern
fill 430 276 259 432 277 259 minecraft:sea_lantern
fill 431 276 237 432 277 238 minecraft:sea_lantern
fill 431 276 240 433 278 240 minecraft:white_concrete
fill 431 276 241 431 277 242 minecraft:sea_lantern
fill 431 276 254 431 277 254 minecraft:sea_lantern
fill 431 276 256 431 278 257 minecraft:white_concrete
fill 431 276 258 433 277 258 minecraft:sea_lantern
fill 431 276 260 432 277 261 minecraft:white_concrete
fill 432 276 236 434 277 236 minecraft:white_concrete
fill 432 276 241 433 277 241 minecraft:white_concrete
fill 432 276 242 432 277 242 minecraft:sea_lantern
fill 432 276 243 432 277 243 minecraft:white_concrete
fill 432 276 256 432 278 256 minecraft:white_concrete
fill 432 276 257 433 277 257 minecraft:sea_lantern
fill 432 276 262 434 277 262 minecraft:sea_lantern
fill 433 276 237 434 278 237 minecraft:white_concrete
fill 433 276 238 434 277 239 minecraft:light_gray_concrete
fill 433 276 259 434 277 260 minecraft:light_gray_concrete
fill 433 276 261 434 277 261 minecraft:sea_lantern
setblock 434 276 231 minecraft:light[level=15]
fill 434 276 235 435 277 235 minecraft:sea_lantern
fill 434 276 240 436 277 240 minecraft:light_gray_concrete
setblock 434 276 247 minecraft:light[level=15]
setblock 434 276 255 minecraft:light[level=15]
fill 434 276 258 436 277 258 minecraft:light_gray_concrete
fill 434 276 263 435 278 263 minecraft:white_concrete
fill 435 276 234 435 277 234 minecraft:sea_lantern
fill 435 276 236 436 277 237 minecraft:sea_lantern
fill 435 276 238 435 278 238 minecraft:white_concrete
fill 435 276 239 435 277 239 minecraft:light_gray_concrete
fill 435 276 241 437 277 241 minecraft:light_gray_concrete
fill 435 276 257 437 277 257 minecraft:light_gray_concrete
fill 435 276 259 435 277 259 minecraft:light_gray_concrete
fill 435 276 260 435 277 260 minecraft:sea_lantern
fill 435 276 261 436 278 262 minecraft:white_concrete
fill 435 276 264 435 277 264 minecraft:white_concrete
fill 436 276 234 437 278 235 minecraft:white_concrete
fill 436 276 238 436 277 238 minecraft:sea_lantern
fill 436 276 242 438 277 242 minecraft:light_gray_concrete
fill 436 276 256 438 277 256 minecraft:light_gray_concrete
fill 436 276 260 436 277 260 minecraft:white_concrete
fill 436 276 263 437 277 264 minecraft:sea_lantern
fill 437 276 233 438 277 233 minecraft:sea_lantern
fill 437 276 236 438 277 237 minecraft:white_concrete
fill 437 276 243 439 277 243 minecraft:light_gray_concrete
fill 437 276 247 437 276 251 minecraft:light_blue_stained_glass
fill 437 276 255 439 277 255 minecraft:light_gray_concrete
fill 437 276 261 438 277 262 minecraft:sea_lantern
fill 437 276 265 438 277 265 minecraft:white_concrete
fill 437 276 270 437 308 270 minecraft:black_concrete
fill 438 276 234 439 277 235 minecraft:sea_lantern
fill 438 276 244 440 277 244 minecraft:light_gray_concrete
fill 438 276 245 438 276 246 minecraft:light_blue_stained_glass
fill 438 276 247 438 278 251 minecraft:white_concrete
fill 438 276 252 438 276 253 minecraft:light_blue_stained_glass
fill 438 276 254 440 277 254 minecraft:light_gray_concrete
fill 438 276 263 439 278 264 minecraft:white_concrete
fill 439 276 232 439 277 233 minecraft:white_concrete
fill 439 276 236 439 277 236 minecraft:sea_lantern
fill 439 276 245 439 277 245 minecraft:light_gray_concrete
fill 439 276 246 449 278 246 minecraft:white_concrete
fill 439 276 252 439 278 252 minecraft:white_concrete
fill 439 276 253 439 277 253 minecraft:light_gray_concrete
fill 439 276 262 439 278 262 minecraft:white_concrete
fill 439 276 265 440 277 266 minecraft:sea_lantern
setblock 440 276 232 minecraft:blue_stained_glass
fill 440 276 233 440 277 236 minecraft:white_concrete
fill 440 276 243 441 276 243 minecraft:light_blue_stained_glass
fill 440 276 245 448 278 245 minecraft:white_concrete
fill 440 276 255 441 276 255 minecraft:light_blue_stained_glass
fill 440 276 262 440 277 264 minecraft:sea_lantern
setblock 440 276 267 minecraft:blue_stained_glass
setblock 441 276 232 minecraft:black_stained_glass
fill 441 276 233 442 277 234 minecraft:sea_lantern
fill 441 276 235 441 277 236 minecraft:white_concrete
fill 441 276 244 447 278 244 minecraft:white_concrete
fill 441 276 254 447 278 254 minecraft:white_concrete
fill 441 276 262 441 277 263 minecraft:sea_lantern
fill 441 276 264 442 277 266 minecraft:white_concrete
setblock 441 276 267 minecraft:black_stained_glass
setblock 442 276 231 minecraft:light[level=15]
fill 442 276 232 443 276 232 minecraft:blue_stained_glass
fill 442 276 235 442 277 235 minecraft:sea_lantern
setblock 442 276 239 minecraft:light[level=15]
fill 442 276 242 446 276 242 minecraft:light_blue_stained_glass
fill 442 276 243 446 278 243 minecraft:white_concrete
fill 442 276 255 446 278 255 minecraft:white_concrete
fill 442 276 256 446 276 256 minecraft:light_blue_stained_glass
fill 442 276 263 442 278 263 minecraft:white_concrete
fill 442 276 267 443 276 267 minecraft:blue_stained_glass
fill 443 276 233 444 278 235 minecraft:white_concrete
fill 443 276 247 450 278 247 minecraft:white_concrete
fill 443 276 253 448 278 253 minecraft:white_concrete
fill 443 276 263 444 277 266 minecraft:sea_lantern
setblock 444 276 232 minecraft:black_stained_glass
setblock 444 276 267 minecraft:black_stained_glass
fill 445 276 232 446 276 232 minecraft:blue_stained_glass
fill 445 276 233 445 277 235 minecraft:sea_lantern
fill 445 276 248 450 278 249 minecraft:white_concrete
fill 445 276 251 449 278 252 minecraft:white_concrete
fill 445 276 263 445 278 266 minecraft:white_concrete
fill 445 276 267 446 276 267 minecraft:blue_stained_glass
fill 446 276 233 446 277 233 minecraft:sea_lantern
fill 446 276 234 447 278 235 minecraft:white_concrete
fill 446 276 250 450 278 250 minecraft:white_concrete
fill 446 276 263 447 277 264 minecraft:sea_lantern
fill 446 276 265 446 278 266 minecraft:white_concrete
setblock 447 276 232 minecraft:black_stained_glass
fill 447 276 233 447 278 233 minecraft:white_concrete
fill 447 276 236 447 277 236 minecraft:white_concrete
fill 447 276 243 448 276 243 minecraft:light_blue_stained_glass
fill 447 276 255 448 276 255 minecraft:light_blue_stained_glass
fill 447 276 262 447 277 262 minecraft:sea_lantern
fill 447 276 265 447 277 266 minecraft:sea_lantern
setblock 447 276 267 minecraft:black_stained_glass
fill 448 276 228 449 287 228 minecraft:black_concrete
setblock 448 276 232 minecraft:blue_stained_glass
fill 448 276 233 448 277 236 minecraft:sea_lantern
fill 448 276 244 450 277 244 minecraft:light_gray_concrete
fill 448 276 254 450 277 254 minecraft:light_gray_concrete
fill 448 276 262 448 277 265 minecraft:white_concrete
fill 448 276 266 448 277 266 minecraft:sea_lantern
setblock 448 276 267 minecraft:blue_stained_glass
fill 449 276 232 449 277 235 minecraft:sea_lantern
fill 449 276 236 450 278 236 minecraft:white_concrete
fill 449 276 243 451 277 243 minecraft:light_gray_concrete
fill 449 276 245 449 277 245 minecraft:light_gray_concrete
fill 449 276 253 449 277 253 minecraft:light_gray_concrete
fill 449 276 255 451 277 255 minecraft:light_gray_concrete
fill 449 276 262 450 277 262 minecraft:sea_lantern
fill 449 276 263 449 277 266 minecraft:white_concrete
setblock 450 276 231 minecraft:light[level=15]
fill 450 276 233 450 278 235 minecraft:white_concrete
fill 450 276 237 451 277 237 minecraft:sea_lantern
setblock 450 276 239 minecraft:light[level=15]
fill 450 276 242 452 277 242 minecraft:light_gray_concrete
fill 450 276 245 450 276 246 minecraft:light_blue_stained_glass
fill 450 276 251 450 278 251 minecraft:white_concrete
fill 450 276 252 450 276 253 minecraft:light_blue_stained_glass
fill 450 276 256 452 277 256 minecraft:light_gray_concrete
fill 450 276 261 451 277 261 minecraft:white_concrete
fill 450 276 263 450 277 265 minecraft:sea_lantern
fill 451 276 228 451 291 228 minecraft:black_concrete
fill 451 276 233 451 277 234 minecraft:white_concrete
fill 451 276 235 452 277 236 minecraft:sea_lantern
fill 451 276 241 453 277 241 minecraft:light_gray_concrete
fill 451 276 247 451 276 251 minecraft:light_blue_stained_glass
fill 451 276 257 453 277 257 minecraft:light_gray_concrete
fill 451 276 262 452 278 263 minecraft:white_concrete
fill 451 276 264 451 277 265 minecraft:sea_lantern
fill 452 276 234 453 277 234 minecraft:sea_lantern
fill 452 276 237 452 277 238 minecraft:white_concrete
fill 452 276 240 454 277 240 minecraft:light_gray_concrete
fill 452 276 258 454 277 258 minecraft:light_gray_concrete
fill 452 276 260 452 277 261 minecraft:sea_lantern
fill 452 276 264 453 277 264 minecraft:white_concrete
fill 453 276 235 453 278 237 minecraft:white_concrete
fill 453 276 238 453 277 238 minecraft:sea_lantern
fill 453 276 239 455 277 239 minecraft:light_gray_concrete
fill 453 276 259 455 277 259 minecraft:light_gray_concrete
fill 453 276 260 453 278 260 minecraft:white_concrete
fill 453 276 261 453 277 263 minecraft:sea_lantern
fill 454 276 235 454 278 236 minecraft:white_concrete
fill 454 276 237 456 277 237 minecraft:sea_lantern
fill 454 276 238 455 277 238 minecraft:light_gray_concrete
fill 454 276 260 455 277 260 minecraft:light_gray_concrete
fill 454 276 261 456 278 261 minecraft:white_concrete
fill 454 276 262 454 277 263 minecraft:sea_lantern
fill 455 276 236 456 277 236 minecraft:sea_lantern
fill 455 276 240 455 278 240 minecraft:white_concrete
fill 455 276 241 456 277 241 minecraft:sea_lantern
fill 455 276 257 456 277 257 minecraft:white_concrete
fill 455 276 258 455 277 258 minecraft:sea_lantern
fill 455 276 262 456 277 262 minecraft:white_concrete
fill 456 276 238 456 278 239 minecraft:white_concrete
fill 456 276 240 458 277 240 minecraft:sea_lantern
fill 456 276 242 456 277 243 minecraft:white_concrete
fill 456 276 255 456 277 256 minecraft:sea_lantern
fill 456 276 258 458 278 258 minecraft:white_concrete
fill 456 276 259 456 277 260 minecraft:sea_lantern
fill 457 276 237 457 277 238 minecraft:white_concrete
fill 457 276 239 458 277 239 minecraft:sea_lantern
fill 457 276 241 458 278 242 minecraft:white_concrete
fill 457 276 243 458 277 244 minecraft:sea_lantern
fill 457 276 245 457 277 246 minecraft:white_concrete
fill 457 276 252 457 277 253 minecraft:sea_lantern
fill 457 276 254 458 278 255 minecraft:white_concrete
fill 457 276 256 458 277 257 minecraft:sea_lantern
fill 457 276 259 458 278 259 minecraft:white_concrete
fill 457 276 260 457 277 261 minecraft:sea_lantern
setblock 458 276 231 minecraft:light[level=15]
fill 458 276 245 461 277 245 minecraft:white_concrete
fill 458 276 246 461 277 247 minecraft:sea_lantern
fill 458 276 248 461 278 248 minecraft:white_concrete
fill 458 276 249 461 277 250 minecraft:sea_lantern
fill 458 276 251 461 277 252 minecraft:white_concrete
fill 458 276 253 461 277 253 minecraft:sea_lantern
setblock 458 276 263 minecraft:light[level=15]
fill 459 276 240 459 277 241 minecraft:white_concrete
fill 459 276 242 460 277 243 minecraft:sea_lantern
fill 459 276 244 461 277 244 minecraft:white_concrete
fill 459 276 254 461 277 254 minecraft:sea_lantern
fill 459 276 255 460 277 256 minecraft:white_concrete
fill 459 276 257 459 277 258 minecraft:sea_lantern
setblock 462 276 245 minecraft:blue_stained_glass
setblock 462 276 246 minecraft:black_stained_glass
fill 462 276 247 462 276 248 minecraft:blue_stained_glass
setblock 462 276 249 minecraft:black_stained_glass
fill 462 276 250 462 276 251 minecraft:blue_stained_glass
setblock 462 276 252 minecraft:black_stained_glass
setblock 462 276 253 minecraft:blue_stained_glass
setblock 465 276 236 minecraft:ochre_froglight
fill 465 276 238 465 297 238 minecraft:black_concrete
setblock 465 276 252 minecraft:pearlescent_froglight
setblock 465 276 266 minecraft:purple_concrete
fill 465 276 268 465 303 268 minecraft:black_concrete
fill 423 277 237 423 308 237 minecraft:black_concrete
fill 427 277 245 427 277 246 minecraft:white_concrete
fill 427 277 247 427 277 249 minecraft:sea_lantern
fill 427 277 250 427 277 251 minecraft:white_concrete
fill 427 277 252 427 277 253 minecraft:sea_lantern
setblock 428 277 270 minecraft:purple_concrete
fill 437 277 247 437 277 251 minecraft:white_concrete
setblock 438 277 228 minecraft:pearlescent_froglight
fill 438 277 245 438 277 246 minecraft:white_concrete
fill 438 277 252 438 277 253 minecraft:white_concrete
setblock 440 277 232 minecraft:white_concrete
fill 440 277 243 441 277 243 minecraft:white_concrete
fill 440 277 255 441 277 255 minecraft:white_concrete
fill 441 277 232 442 277 232 minecraft:sea_lantern
fill 442 277 242 446 277 242 minecraft:white_concrete
fill 442 277 256 446 277 256 minecraft:white_concrete
fill 443 277 232 444 277 232 minecraft:white_concrete
setblock 445 277 228 minecraft:white_concrete
fill 445 277 232 446 277 232 minecraft:sea_lantern
fill 447 277 232 448 277 232 minecraft:white_concrete
fill 447 277 243 448 277 243 minecraft:white_concrete
fill 447 277 255 448 277 255 minecraft:white_concrete
fill 450 277 245 450 277 246 minecraft:white_concrete
fill 450 277 252 450 277 253 minecraft:white_concrete
fill 451 277 247 451 277 251 minecraft:white_concrete
fill 465 277 236 465 308 236 minecraft:black_concrete
fill 465 277 252 465 308 252 minecraft:black_concrete
fill 465 277 266 465 280 266 minecraft:black_concrete
setblock 423 278 249 minecraft:ochre_froglight
setblock 427 278 245 minecraft:blue_stained_glass
setblock 427 278 246 minecraft:black_stained_glass
fill 427 278 247 427 278 248 minecraft:blue_stained_glass
setblock 427 278 249 minecraft:black_stained_glass
fill 427 278 250 427 278 251 minecraft:blue_stained_glass
setblock 427 278 252 minecraft:black_stained_glass
setblock 427 278 253 minecraft:blue_stained_glass
fill 428 278 243 428 278 244 minecraft:white_concrete
fill 428 278 247 429 278 249 minecraft:white_concrete
fill 428 278 252 430 278 254 minecraft:white_concrete
fill 428 278 270 428 282 270 minecraft:black_concrete
fill 429 278 241 432 278 242 minecraft:white_concrete
fill 429 278 244 430 278 246 minecraft:white_concrete
fill 429 278 255 430 278 257 minecraft:white_concrete
setblock 430 278 240 minecraft:white_concrete
fill 430 278 248 430 278 249 minecraft:white_concrete
setblock 430 278 251 minecraft:white_concrete
fill 430 278 258 433 278 259 minecraft:white_concrete
fill 431 278 238 434 278 238 minecraft:white_concrete
fill 431 278 254 431 278 255 minecraft:white_concrete
fill 431 278 260 435 278 260 minecraft:white_concrete
setblock 432 278 228 minecraft:white_concrete
setblock 432 278 237 minecraft:white_concrete
setblock 432 278 257 minecraft:white_concrete
fill 432 278 261 434 278 261 minecraft:white_concrete
fill 433 278 236 439 278 236 minecraft:white_concrete
fill 433 278 239 434 278 239 minecraft:white_concrete
fill 433 278 262 434 278 262 minecraft:white_concrete
fill 434 278 235 435 278 235 minecraft:white_concrete
setblock 434 278 259 minecraft:white_concrete
fill 435 278 237 437 278 237 minecraft:white_concrete
fill 436 278 263 437 278 264 minecraft:white_concrete
fill 437 278 247 437 278 251 minecraft:light_blue_stained_glass
fill 437 278 261 437 278 262 minecraft:white_concrete
fill 438 278 228 438 293 228 minecraft:black_concrete
fill 438 278 233 442 278 235 minecraft:white_concrete
fill 438 278 245 438 278 246 minecraft:light_blue_stained_glass
fill 438 278 252 438 278 253 minecraft:light_blue_stained_glass
setblock 438 278 262 minecraft:white_concrete
fill 438 278 265 444 278 265 minecraft:white_concrete
fill 439 278 244 439 278 245 minecraft:light_blue_stained_glass
fill 439 278 253 439 278 254 minecraft:light_blue_stained_glass
setblock 440 278 232 minecraft:blue_stained_glass
fill 440 278 243 440 278 244 minecraft:light_blue_stained_glass
fill 440 278 254 440 278 255 minecraft:light_blue_stained_glass
fill 440 278 263 441 278 264 minecraft:white_concrete
setblock 440 278 267 minecraft:blue_stained_glass
setblock 441 278 232 minecraft:black_stained_glass
setblock 441 278 243 minecraft:light_blue_stained_glass
setblock 441 278 255 minecraft:light_blue_stained_glass
setblock 441 278 267 minecraft:black_stained_glass
fill 442 278 232 443 278 232 minecraft:blue_stained_glass
fill 442 278 242 446 278 242 minecraft:light_blue_stained_glass
fill 442 278 256 446 278 256 minecraft:light_blue_stained_glass
fill 442 278 264 444 278 264 minecraft:white_concrete
fill 442 278 266 444 278 266 minecraft:white_concrete
fill 442 278 267 443 278 267 minecraft:blue_stained_glass
fill 443 278 263 444 278 263 minecraft:white_concrete
setblock 444 278 232 minecraft:black_stained_glass
setblock 444 278 267 minecraft:black_stained_glass
fill 445 278 228 445 308 228 minecraft:black_concrete
fill 445 278 232 446 278 232 minecraft:blue_stained_glass
fill 445 278 233 445 278 235 minecraft:white_concrete
fill 445 278 267 446 278 267 minecraft:blue_stained_glass
setblock 446 278 233 minecraft:white_concrete
fill 446 278 263 450 278 264 minecraft:white_concrete
setblock 447 278 232 minecraft:black_stained_glass
fill 447 278 243 448 278 243 minecraft:light_blue_stained_glass
fill 447 278 255 448 278 255 minecraft:light_blue_stained_glass
fill 447 278 265 450 278 265 minecraft:white_concrete
setblock 447 278 267 minecraft:black_stained_glass
setblock 448 278 232 minecraft:blue_stained_glass
fill 448 278 233 449 278 235 minecraft:white_concrete
fill 448 278 244 449 278 244 minecraft:light_blue_stained_glass
fill 448 278 254 449 278 254 minecraft:light_blue_stained_glass
setblock 448 278 267 minecraft:blue_stained_glass
fill 449 278 245 450 278 245 minecraft:light_blue_stained_glass
fill 449 278 253 450 278 253 minecraft:light_blue_stained_glass
fill 449 278 262 450 278 262 minecraft:white_concrete
setblock 450 278 246 minecraft:light_blue_stained_glass
setblock 450 278 252 minecraft:light_blue_stained_glass
fill 451 278 234 452 278 237 minecraft:white_concrete
fill 451 278 247 451 278 251 minecraft:light_blue_stained_glass
fill 451 278 261 453 278 261 minecraft:white_concrete
fill 451 278 264 452 278 264 minecraft:white_concrete
setblock 451 278 270 minecraft:magenta_terracotta
fill 453 278 238 455 278 238 minecraft:white_concrete
fill 453 278 262 454 278 263 minecraft:white_concrete
fill 454 278 237 456 278 237 minecraft:white_concrete
fill 454 278 239 455 278 239 minecraft:white_concrete
fill 454 278 259 456 278 260 minecraft:white_concrete
setblock 455 278 236 minecraft:white_concrete
setblock 455 278 258 minecraft:white_concrete
setblock 455 278 262 minecraft:white_concrete
fill 456 278 240 456 278 242 minecraft:white_concrete
fill 456 278 256 459 278 257 minecraft:white_concrete
fill 457 278 238 457 278 240 minecraft:white_concrete
fill 457 278 243 460 278 244 minecraft:white_concrete
setblock 457 278 260 minecraft:white_concrete
fill 458 278 239 458 278 240 minecraft:white_concrete
fill 458 278 245 460 278 247 minecraft:white_concrete
fill 458 278 249 460 278 253 minecraft:white_concrete
fill 459 278 241 459 278 242 minecraft:white_concrete
fill 459 278 254 460 278 255 minecraft:white_concrete
setblock 461 278 247 minecraft:white_concrete
fill 461 278 249 461 278 251 minecraft:white_concrete
setblock 462 278 245 minecraft:blue_stained_glass
setblock 462 278 246 minecraft:black_stained_glass
fill 462 278 247 462 278 248 minecraft:blue_stained_glass
setblock 462 278 249 minecraft:black_stained_glass
fill 462 278 250 462 278 251 minecraft:blue_stained_glass
setblock 462 278 252 minecraft:black_stained_glass
setblock 462 278 253 minecraft:blue_stained_glass
setblock 465 278 237 minecraft:white_concrete
setblock 465 278 262 minecraft:white_concrete
setblock 423 279 249 minecraft:purple_concrete
fill 424 279 229 424 279 236 minecraft:light_blue_stained_glass
setblock 424 279 237 minecraft:sea_lantern
fill 424 279 238 424 279 247 minecraft:light_blue_stained_glass
setblock 424 279 248 minecraft:sea_lantern
fill 424 279 249 424 279 258 minecraft:light_blue_stained_glass
setblock 424 279 259 minecraft:sea_lantern
fill 424 279 260 424 279 269 minecraft:light_blue_stained_glass
fill 425 279 229 425 279 234 minecraft:light_blue_stained_glass
setblock 425 279 235 minecraft:sea_lantern
fill 425 279 236 425 279 245 minecraft:light_blue_stained_glass
setblock 425 279 246 minecraft:sea_lantern
fill 425 279 247 425 279 256 minecraft:light_blue_stained_glass
setblock 425 279 257 minecraft:sea_lantern
fill 425 279 258 425 279 267 minecraft:light_blue_stained_glass
setblock 425 279 268 minecraft:sea_lantern
fill 425 279 269 429 279 269 minecraft:light_blue_stained_glass
fill 426 279 229 426 279 232 minecraft:light_blue_stained_glass
setblock 426 279 233 minecraft:sea_lantern
fill 426 279 234 426 279 243 minecraft:light_blue_stained_glass
setblock 426 279 244 minecraft:sea_lantern
fill 426 279 245 426 279 254 minecraft:light_blue_stained_glass
setblock 426 279 255 minecraft:sea_lantern
fill 426 279 256 426 279 265 minecraft:light_blue_stained_glass
setblock 426 279 266 minecraft:sea_lantern
fill 426 279 267 430 279 268 minecraft:light_blue_stained_glass
fill 427 279 229 427 279 230 minecraft:light_blue_stained_glass
setblock 427 279 231 minecraft:sea_lantern
fill 427 279 232 427 279 241 minecraft:light_blue_stained_glass
setblock 427 279 242 minecraft:sea_lantern
fill 427 279 243 427 279 252 minecraft:light_blue_stained_glass
setblock 427 279 253 minecraft:sea_lantern
fill 427 279 254 427 279 263 minecraft:light_blue_stained_glass
setblock 427 279 264 minecraft:sea_lantern
fill 427 279 265 431 279 266 minecraft:light_blue_stained_glass
setblock 428 279 229 minecraft:sea_lantern
fill 428 279 230 428 279 239 minecraft:light_blue_stained_glass
setblock 428 279 240 minecraft:sea_lantern
fill 428 279 241 428 279 250 minecraft:light_blue_stained_glass
setblock 428 279 251 minecraft:sea_lantern
fill 428 279 252 428 279 261 minecraft:light_blue_stained_glass
setblock 428 279 262 minecraft:sea_lantern
fill 428 279 263 432 279 264 minecraft:light_blue_stained_glass
fill 429 279 229 429 279 237 minecraft:light_blue_stained_glass
setblock 429 279 238 minecraft:sea_lantern
fill 429 279 239 429 279 248 minecraft:light_blue_stained_glass
setblock 429 279 249 minecraft:sea_lantern
fill 429 279 250 429 279 259 minecraft:light_blue_stained_glass
setblock 429 279 260 minecraft:sea_lantern
fill 429 279 261 433 279 262 minecraft:light_blue_stained_glass
fill 430 279 229 430 279 235 minecraft:light_blue_stained_glass
setblock 430 279 236 minecraft:sea_lantern
fill 430 279 237 430 279 246 minecraft:light_blue_stained_glass
setblock 430 279 247 minecraft:sea_lantern
fill 430 279 248 430 279 257 minecraft:light_blue_stained_glass
setblock 430 279 258 minecraft:sea_lantern
fill 430 279 259 434 279 260 minecraft:light_blue_stained_glass
setblock 430 279 269 minecraft:sea_lantern
fill 431 279 229 431 279 233 minecraft:light_blue_stained_glass
setblock 431 279 234 minecraft:sea_lantern
fill 431 279 235 431 279 244 minecraft:light_blue_stained_glass
setblock 431 279 245 minecraft:sea_lantern
fill 431 279 246 431 279 255 minecraft:light_blue_stained_glass
setblock 431 279 256 minecraft:sea_lantern
fill 431 279 257 435 279 258 minecraft:light_blue_stained_glass
setblock 431 279 267 minecraft:sea_lantern
fill 431 279 268 435 279 269 minecraft:light_blue_stained_glass
fill 432 279 228 432 308 228 minecraft:black_concrete
fill 432 279 229 432 279 231 minecraft:light_blue_stained_glass
setblock 432 279 232 minecraft:sea_lantern
fill 432 279 233 432 279 242 minecraft:light_blue_stained_glass
setblock 432 279 243 minecraft:sea_lantern
fill 432 279 244 432 279 253 minecraft:light_blue_stained_glass
setblock 432 279 254 minecraft:sea_lantern
fill 432 279 255 436 279 256 minecraft:light_blue_stained_glass
setblock 432 279 265 minecraft:sea_lantern
fill 432 279 266 436 279 267 minecraft:light_blue_stained_glass
fill 433 279 229 438 279 229 minecraft:light_blue_stained_glass
setblock 433 279 230 minecraft:sea_lantern
fill 433 279 231 433 279 240 minecraft:light_blue_stained_glass
setblock 433 279 241 minecraft:sea_lantern
fill 433 279 242 433 279 251 minecraft:light_blue_stained_glass
setblock 433 279 252 minecraft:sea_lantern
fill 433 279 253 437 279 254 minecraft:light_blue_stained_glass
setblock 433 279 263 minecraft:sea_lantern
fill 433 279 264 437 279 265 minecraft:light_blue_stained_glass
fill 434 279 230 434 279 238 minecraft:light_blue_stained_glass
setblock 434 279 239 minecraft:sea_lantern
fill 434 279 240 434 279 249 minecraft:light_blue_stained_glass
setblock 434 279 250 minecraft:sea_lantern
fill 434 279 251 436 279 252 minecraft:light_blue_stained_glass
setblock 434 279 261 minecraft:sea_lantern
fill 434 279 262 438 279 263 minecraft:light_blue_stained_glass
fill 435 279 230 435 279 236 minecraft:light_blue_stained_glass
setblock 435 279 237 minecraft:sea_lantern
fill 435 279 238 435 279 247 minecraft:light_blue_stained_glass
setblock 435 279 248 minecraft:sea_lantern
fill 435 279 249 436 279 250 minecraft:light_blue_stained_glass
setblock 435 279 259 minecraft:sea_lantern
fill 435 279 260 439 279 261 minecraft:light_blue_stained_glass
fill 436 279 230 436 279 234 minecraft:light_blue_stained_glass
setblock 436 279 235 minecraft:sea_lantern
fill 436 279 236 436 279 245 minecraft:light_blue_stained_glass
setblock 436 279 246 minecraft:sea_lantern
fill 436 279 247 436 279 248 minecraft:light_blue_stained_glass
setblock 436 279 257 minecraft:sea_lantern
fill 436 279 258 440 279 259 minecraft:light_blue_stained_glass
setblock 436 279 268 minecraft:sea_lantern
fill 436 279 269 440 279 269 minecraft:light_blue_stained_glass
fill 437 279 230 437 279 232 minecraft:light_blue_stained_glass
setblock 437 279 233 minecraft:sea_lantern
fill 437 279 234 437 279 243 minecraft:light_blue_stained_glass
setblock 437 279 244 minecraft:sea_lantern
fill 437 279 245 437 279 246 minecraft:light_blue_stained_glass
setblock 437 279 247 minecraft:smooth_quartz
fill 437 279 248 437 279 252 minecraft:lime_concrete
setblock 437 279 255 minecraft:sea_lantern
fill 437 279 256 441 279 257 minecraft:light_blue_stained_glass
setblock 437 279 266 minecraft:sea_lantern
fill 437 279 267 441 279 268 minecraft:light_blue_stained_glass
fill 438 279 230 443 279 230 minecraft:light_blue_stained_glass
setblock 438 279 231 minecraft:sea_lantern
fill 438 279 232 438 279 241 minecraft:light_blue_stained_glass
setblock 438 279 242 minecraft:sea_lantern
fill 438 279 243 438 279 244 minecraft:light_blue_stained_glass
fill 438 279 245 439 279 245 minecraft:smooth_quartz
fill 438 279 246 438 279 248 minecraft:lime_concrete
fill 438 279 249 438 279 251 minecraft:sea_lantern
fill 438 279 252 438 279 254 minecraft:lime_concrete
fill 438 279 255 439 279 255 minecraft:light_blue_stained_glass
setblock 438 279 264 minecraft:sea_lantern
fill 438 279 265 442 279 266 minecraft:light_blue_stained_glass
setblock 439 279 229 minecraft:sea_lantern
fill 439 279 231 439 279 239 minecraft:light_blue_stained_glass
setblock 439 279 240 minecraft:sea_lantern
fill 439 279 241 439 279 243 minecraft:light_blue_stained_glass
fill 439 279 244 441 279 244 minecraft:smooth_quartz
fill 439 279 246 440 279 246 minecraft:lime_concrete
fill 439 279 247 439 279 249 minecraft:sea_lantern
fill 439 279 251 439 279 253 minecraft:sea_lantern
fill 439 279 254 440 279 254 minecraft:lime_concrete
setblock 439 279 262 minecraft:sea_lantern
fill 439 279 263 443 279 264 minecraft:light_blue_stained_glass
fill 440 279 229 449 279 229 minecraft:light_blue_stained_glass
fill 440 279 231 440 279 237 minecraft:light_blue_stained_glass
setblock 440 279 238 minecraft:sea_lantern
fill 440 279 239 441 279 242 minecraft:light_blue_stained_glass
fill 440 279 243 448 279 243 minecraft:smooth_quartz
fill 440 279 245 444 279 245 minecraft:lime_concrete
fill 440 279 247 441 279 247 minecraft:sea_lantern
fill 440 279 253 441 279 253 minecraft:sea_lantern
fill 440 279 255 444 279 255 minecraft:lime_concrete
setblock 440 279 260 minecraft:sea_lantern
fill 440 279 261 444 279 262 minecraft:light_blue_stained_glass
fill 441 279 231 441 279 235 minecraft:light_blue_stained_glass
setblock 441 279 236 minecraft:sea_lantern
fill 441 279 237 445 279 238 minecraft:light_blue_stained_glass
fill 441 279 246 443 279 246 minecraft:sea_lantern
fill 441 279 254 443 279 254 minecraft:sea_lantern
setblock 441 279 258 minecraft:sea_lantern
fill 441 279 259 445 279 260 minecraft:light_blue_stained_glass
setblock 441 279 269 minecraft:sea_lantern
fill 442 279 231 442 279 233 minecraft:light_blue_stained_glass
setblock 442 279 234 minecraft:sea_lantern
fill 442 279 235 446 279 236 minecraft:light_blue_stained_glass
fill 442 279 239 443 279 241 minecraft:light_blue_stained_glass
fill 442 279 242 446 279 242 minecraft:smooth_quartz
fill 442 279 244 446 279 244 minecraft:light_gray_concrete
fill 442 279 256 446 279 256 minecraft:smooth_quartz
fill 442 279 257 446 279 258 minecraft:light_blue_stained_glass
setblock 442 279 267 minecraft:sea_lantern
fill 442 279 268 446 279 269 minecraft:light_blue_stained_glass
fill 443 279 231 448 279 231 minecraft:light_blue_stained_glass
setblock 443 279 232 minecraft:sea_lantern
fill 443 279 233 447 279 234 minecraft:light_blue_stained_glass
fill 443 279 247 445 279 247 minecraft:sea_lantern
fill 443 279 253 445 279 253 minecraft:sea_lantern
setblock 443 279 265 minecraft:sea_lantern
fill 443 279 266 447 279 267 minecraft:light_blue_stained_glass
setblock 444 279 230 minecraft:sea_lantern
fill 444 279 232 453 279 232 minecraft:light_blue_stained_glass
fill 444 279 239 444 279 240 minecraft:light_blue_stained_glass
setblock 444 279 241 minecraft:sea_lantern
fill 444 279 246 446 279 246 minecraft:lime_concrete
fill 444 279 254 446 279 254 minecraft:lime_concrete
setblock 444 279 263 minecraft:sea_lantern
fill 444 279 264 448 279 265 minecraft:light_blue_stained_glass
fill 445 279 230 454 279 230 minecraft:light_blue_stained_glass
setblock 445 279 239 minecraft:sea_lantern
fill 445 279 240 449 279 241 minecraft:light_blue_stained_glass
fill 445 279 245 447 279 245 minecraft:light_gray_concrete
fill 445 279 248 445 279 249 minecraft:sea_lantern
fill 445 279 251 445 279 252 minecraft:sea_lantern
fill 445 279 255 448 279 255 minecraft:smooth_quartz
setblock 445 279 261 minecraft:sea_lantern
fill 445 279 262 449 279 263 minecraft:light_blue_stained_glass
setblock 446 279 237 minecraft:sea_lantern
fill 446 279 238 450 279 239 minecraft:light_blue_stained_glass
fill 446 279 247 446 279 248 minecraft:lime_concrete
fill 446 279 249 446 279 251 minecraft:sea_lantern
fill 446 279 252 446 279 253 minecraft:lime_concrete
setblock 446 279 259 minecraft:sea_lantern
fill 446 279 260 450 279 261 minecraft:light_blue_stained_glass
setblock 447 279 235 minecraft:sea_lantern
fill 447 279 236 451 279 237 minecraft:light_blue_stained_glass
fill 447 279 242 448 279 242 minecraft:light_blue_stained_glass
fill 447 279 244 449 279 244 minecraft:smooth_quartz
fill 447 279 246 448 279 246 minecraft:light_gray_concrete
setblock 447 279 247 minecraft:smooth_quartz
fill 447 279 248 447 279 252 minecraft:lime_concrete
setblock 447 279 253 minecraft:light_gray_concrete
fill 447 279 254 449 279 254 minecraft:smooth_quartz
fill 447 279 256 452 279 256 minecraft:light_blue_stained_glass
setblock 447 279 257 minecraft:sea_lantern
fill 447 279 258 451 279 259 minecraft:light_blue_stained_glass
setblock 447 279 268 minecraft:sea_lantern
fill 447 279 269 451 279 269 minecraft:light_blue_stained_glass
setblock 447 279 270 minecraft:sea_lantern
setblock 448 279 233 minecraft:sea_lantern
fill 448 279 234 452 279 235 minecraft:light_blue_stained_glass
fill 448 279 245 450 279 245 minecraft:smooth_quartz
fill 448 279 247 449 279 248 minecraft:light_gray_concrete
setblock 448 279 249 minecraft:smooth_quartz
fill 448 279 250 448 279 252 minecraft:light_gray_concrete
fill 448 279 253 450 279 253 minecraft:smooth_quartz
fill 448 279 257 457 279 257 minecraft:light_blue_stained_glass
setblock 448 279 266 minecraft:sea_lantern
fill 448 279 267 452 279 268 minecraft:light_blue_stained_glass
setblock 449 279 231 minecraft:sea_lantern
fill 449 279 233 458 279 233 minecraft:light_blue_stained_glass
setblock 449 279 242 minecraft:sea_lantern
fill 449 279 243 453 279 243 minecraft:light_blue_stained_glass
fill 449 279 246 450 279 246 minecraft:smooth_quartz
fill 449 279 249 449 279 251 minecraft:light_gray_concrete
fill 449 279 252 450 279 252 minecraft:smooth_quartz
fill 449 279 255 458 279 255 minecraft:light_blue_stained_glass
setblock 449 279 264 minecraft:sea_lantern
fill 449 279 265 453 279 266 minecraft:light_blue_stained_glass
setblock 450 279 229 minecraft:sea_lantern
fill 450 279 231 459 279 231 minecraft:light_blue_stained_glass
setblock 450 279 240 minecraft:sea_lantern
fill 450 279 241 454 279 242 minecraft:light_blue_stained_glass
fill 450 279 244 458 279 244 minecraft:light_blue_stained_glass
fill 450 279 247 451 279 251 minecraft:smooth_quartz
fill 450 279 254 453 279 254 minecraft:light_blue_stained_glass
setblock 450 279 262 minecraft:sea_lantern
fill 450 279 263 454 279 264 minecraft:light_blue_stained_glass
fill 451 279 229 460 279 229 minecraft:light_blue_stained_glass
setblock 451 279 238 minecraft:sea_lantern
fill 451 279 239 455 279 240 minecraft:light_blue_stained_glass
fill 451 279 245 452 279 246 minecraft:light_blue_stained_glass
fill 451 279 252 454 279 253 minecraft:light_blue_stained_glass
setblock 451 279 260 minecraft:sea_lantern
fill 451 279 261 455 279 262 minecraft:light_blue_stained_glass
fill 451 279 270 451 294 270 minecraft:black_concrete
setblock 452 279 228 minecraft:ochre_froglight
setblock 452 279 236 minecraft:sea_lantern
fill 452 279 237 456 279 238 minecraft:light_blue_stained_glass
setblock 452 279 247 minecraft:sea_lantern
fill 452 279 248 455 279 251 minecraft:light_blue_stained_glass
setblock 452 279 258 minecraft:sea_lantern
fill 452 279 259 456 279 260 minecraft:light_blue_stained_glass
setblock 452 279 269 minecraft:sea_lantern
setblock 453 279 234 minecraft:sea_lantern
fill 453 279 235 457 279 236 minecraft:light_blue_stained_glass
setblock 453 279 245 minecraft:sea_lantern
fill 453 279 246 457 279 247 minecraft:light_blue_stained_glass
setblock 453 279 256 minecraft:sea_lantern
fill 453 279 258 462 279 258 minecraft:light_blue_stained_glass
setblock 453 279 267 minecraft:sea_lantern
fill 453 279 268 457 279 269 minecraft:light_blue_stained_glass
setblock 454 279 232 minecraft:sea_lantern
fill 454 279 234 463 279 234 minecraft:light_blue_stained_glass
setblock 454 279 243 minecraft:sea_lantern
fill 454 279 245 463 279 245 minecraft:light_blue_stained_glass
setblock 454 279 254 minecraft:sea_lantern
fill 454 279 256 463 279 256 minecraft:light_blue_stained_glass
setblock 454 279 265 minecraft:sea_lantern
fill 454 279 266 458 279 267 minecraft:light_blue_stained_glass
setblock 455 279 230 minecraft:sea_lantern
fill 455 279 232 464 279 232 minecraft:light_blue_stained_glass
setblock 455 279 241 minecraft:sea_lantern
fill 455 279 242 459 279 243 minecraft:light_blue_stained_glass
setblock 455 279 252 minecraft:sea_lantern
fill 455 279 253 459 279 254 minecraft:light_blue_stained_glass
setblock 455 279 263 minecraft:sea_lantern
fill 455 279 264 459 279 265 minecraft:light_blue_stained_glass
fill 456 279 230 464 279 230 minecraft:light_blue_stained_glass
setblock 456 279 239 minecraft:sea_lantern
fill 456 279 240 460 279 241 minecraft:light_blue_stained_glass
fill 456 279 248 456 279 249 minecraft:light_blue_stained_glass
setblock 456 279 250 minecraft:sea_lantern
fill 456 279 251 460 279 252 minecraft:light_blue_stained_glass
setblock 456 279 261 minecraft:sea_lantern
fill 456 279 262 460 279 263 minecraft:light_blue_stained_glass
setblock 457 279 237 minecraft:sea_lantern
fill 457 279 238 461 279 239 minecraft:light_blue_stained_glass
setblock 457 279 248 minecraft:sea_lantern
fill 457 279 249 461 279 250 minecraft:light_blue_stained_glass
setblock 457 279 259 minecraft:sea_lantern
fill 457 279 260 461 279 261 minecraft:light_blue_stained_glass
setblock 458 279 235 minecraft:sea_lantern
fill 458 279 236 462 279 237 minecraft:light_blue_stained_glass
setblock 458 279 246 minecraft:sea_lantern
fill 458 279 247 462 279 248 minecraft:light_blue_stained_glass
setblock 458 279 257 minecraft:sea_lantern
fill 458 279 259 464 279 259 minecraft:light_blue_stained_glass
setblock 458 279 268 minecraft:sea_lantern
fill 458 279 269 462 279 269 minecraft:light_blue_stained_glass
setblock 459 279 233 minecraft:sea_lantern
fill 459 279 235 464 279 235 minecraft:light_blue_stained_glass
setblock 459 279 244 minecraft:sea_lantern
fill 459 279 246 464 279 246 minecraft:light_blue_stained_glass
setblock 459 279 255 minecraft:sea_lantern
fill 459 279 257 464 279 257 minecraft:light_blue_stained_glass
setblock 459 279 266 minecraft:sea_lantern
fill 459 279 267 463 279 268 minecraft:light_blue_stained_glass
setblock 460 279 231 minecraft:sea_lantern
fill 460 279 233 464 279 233 minecraft:light_blue_stained_glass
setblock 460 279 242 minecraft:sea_lantern
fill 460 279 243 464 279 244 minecraft:light_blue_stained_glass
setblock 460 279 253 minecraft:sea_lantern
fill 460 279 254 464 279 255 minecraft:light_blue_stained_glass
setblock 460 279 264 minecraft:sea_lantern
fill 460 279 265 464 279 266 minecraft:light_blue_stained_glass
setblock 461 279 229 minecraft:sea_lantern
fill 461 279 231 464 279 231 minecraft:light_blue_stained_glass
setblock 461 279 240 minecraft:sea_lantern
fill 461 279 241 464 279 242 minecraft:light_blue_stained_glass
setblock 461 279 251 minecraft:sea_lantern
fill 461 279 252 464 279 253 minecraft:light_blue_stained_glass
setblock 461 279 262 minecraft:sea_lantern
fill 461 279 263 464 279 264 minecraft:light_blue_stained_glass
fill 462 279 229 464 279 229 minecraft:light_blue_stained_glass
setblock 462 279 238 minecraft:sea_lantern
fill 462 279 239 464 279 240 minecraft:light_blue_stained_glass
setblock 462 279 249 minecraft:sea_lantern
fill 462 279 250 464 279 251 minecraft:light_blue_stained_glass
setblock 462 279 260 minecraft:sea_lantern
fill 462 279 261 464 279 262 minecraft:light_blue_stained_glass
setblock 463 279 236 minecraft:sea_lantern
fill 463 279 237 464 279 238 minecraft:light_blue_stained_glass
setblock 463 279 247 minecraft:sea_lantern
fill 463 279 248 464 279 249 minecraft:light_blue_stained_glass
setblock 463 279 258 minecraft:sea_lantern
fill 463 279 260 464 279 260 minecraft:light_blue_stained_glass
setblock 463 279 269 minecraft:sea_lantern
setblock 464 279 234 minecraft:sea_lantern
setblock 464 279 236 minecraft:light_blue_stained_glass
setblock 464 279 245 minecraft:sea_lantern
setblock 464 279 247 minecraft:light_blue_stained_glass
setblock 464 279 256 minecraft:sea_lantern
setblock 464 279 258 minecraft:light_blue_stained_glass
setblock 464 279 267 minecraft:sea_lantern
fill 464 279 268 464 279 269 minecraft:light_blue_stained_glass
fill 465 279 237 465 308 237 minecraft:black_concrete
setblock 465 279 239 minecraft:sea_lantern
setblock 465 279 249 minecraft:sea_lantern
fill 465 279 262 465 308 262 minecraft:black_concrete
fill 423 280 249 423 308 249 minecraft:black_concrete
setblock 426 280 231 minecraft:light[level=12]
setblock 426 280 238 minecraft:light[level=12]
setblock 426 280 245 minecraft:light[level=12]
setblock 426 280 252 minecraft:light[level=12]
setblock 426 280 259 minecraft:light[level=12]
setblock 426 280 266 minecraft:light[level=12]
setblock 433 280 231 minecraft:light[level=12]
setblock 433 280 238 minecraft:light[level=12]
setblock 433 280 245 minecraft:light[level=12]
setblock 433 280 252 minecraft:light[level=12]
setblock 433 280 259 minecraft:light[level=12]
setblock 433 280 266 minecraft:light[level=12]
setblock 440 280 231 minecraft:light[level=12]
setblock 440 280 238 minecraft:light[level=12]
setblock 440 280 245 minecraft:light[level=12]
setblock 440 280 259 minecraft:light[level=12]
setblock 440 280 266 minecraft:light[level=12]
fill 446 280 228 447 280 228 minecraft:pearlescent_froglight
setblock 447 280 231 minecraft:light[level=12]
setblock 447 280 238 minecraft:light[level=12]
setblock 447 280 245 minecraft:light[level=12]
setblock 447 280 252 minecraft:light[level=12]
setblock 447 280 259 minecraft:light[level=12]
setblock 447 280 266 minecraft:light[level=12]
fill 447 280 270 447 308 270 minecraft:black_concrete
fill 452 280 228 452 308 228 minecraft:black_concrete
setblock 454 280 231 minecraft:light[level=12]
setblock 454 280 238 minecraft:light[level=12]
setblock 454 280 245 minecraft:light[level=12]
setblock 454 280 252 minecraft:light[level=12]
setblock 454 280 259 minecraft:light[level=12]
setblock 454 280 266 minecraft:light[level=12]
setblock 461 280 231 minecraft:light[level=12]
setblock 461 280 238 minecraft:light[level=12]
setblock 461 280 245 minecraft:light[level=12]
setblock 461 280 252 minecraft:light[level=12]
setblock 461 280 259 minecraft:light[level=12]
setblock 461 280 266 minecraft:light[level=12]
setblock 462 280 270 minecraft:pearlescent_froglight
fill 465 280 239 465 292 239 minecraft:black_concrete
fill 465 280 249 465 300 249 minecraft:black_concrete
fill 446 281 228 447 286 228 minecraft:black_concrete
fill 462 281 270 462 308 270 minecraft:black_concrete
setblock 465 281 266 minecraft:sea_lantern
setblock 423 282 242 minecraft:purple_concrete
setblock 450 282 228 minecraft:white_concrete
setblock 465 282 234 minecraft:ochre_froglight
fill 465 282 266 465 308 266 minecraft:black_concrete
fill 423 283 242 423 304 242 minecraft:black_concrete
setblock 423 283 253 minecraft:white_concrete
setblock 426 283 231 minecraft:light[level=15]
setblock 426 283 239 minecraft:light[level=15]
setblock 426 283 247 minecraft:light[level=15]
setblock 426 283 255 minecraft:light[level=15]
setblock 426 283 263 minecraft:light[level=15]
setblock 428 283 270 minecraft:purple_terracotta
setblock 434 283 231 minecraft:light[level=15]
setblock 434 283 239 minecraft:light[level=15]
setblock 434 283 247 minecraft:light[level=15]
setblock 434 283 255 minecraft:light[level=15]
setblock 434 283 263 minecraft:light[level=15]
setblock 442 283 231 minecraft:light[level=15]
setblock 442 283 239 minecraft:light[level=15]
setblock 442 283 247 minecraft:light[level=15]
setblock 442 283 255 minecraft:light[level=15]
setblock 442 283 263 minecraft:light[level=15]
fill 450 283 228 450 308 228 minecraft:black_concrete
setblock 450 283 231 minecraft:light[level=15]
setblock 450 283 239 minecraft:light[level=15]
setblock 450 283 247 minecraft:light[level=15]
setblock 450 283 255 minecraft:light[level=15]
setblock 450 283 263 minecraft:light[level=15]
setblock 458 283 231 minecraft:light[level=15]
setblock 458 283 239 minecraft:light[level=15]
setblock 458 283 247 minecraft:light[level=15]
setblock 458 283 255 minecraft:light[level=15]
setblock 458 283 263 minecraft:light[level=15]
setblock 463 283 270 minecraft:ochre_froglight
fill 465 283 234 465 308 234 minecraft:black_concrete
setblock 465 283 240 minecraft:ochre_froglight
setblock 465 283 254 minecraft:blue_concrete
setblock 465 283 258 minecraft:ochre_froglight
setblock 423 284 231 minecraft:white_concrete
fill 423 284 253 423 304 253 minecraft:black_concrete
fill 428 284 270 428 308 270 minecraft:black_concrete
setblock 431 284 270 minecraft:sea_lantern
fill 463 284 270 463 299 270 minecraft:black_concrete
fill 465 284 240 465 308 240 minecraft:black_concrete
fill 465 284 254 465 308 254 minecraft:black_concrete
fill 465 284 258 465 308 258 minecraft:black_concrete
fill 423 285 231 423 288 231 minecraft:black_concrete
setblock 423 285 251 minecraft:purple_terracotta
setblock 427 285 270 minecraft:pearlescent_froglight
fill 431 285 270 431 308 270 minecraft:black_concrete
setblock 444 285 228 minecraft:pearlescent_froglight
setblock 446 285 270 minecraft:pearlescent_froglight
fill 423 286 251 423 308 251 minecraft:black_concrete
setblock 426 286 231 minecraft:light[level=12]
setblock 426 286 238 minecraft:light[level=12]
setblock 426 286 245 minecraft:light[level=12]
setblock 426 286 252 minecraft:light[level=12]
setblock 426 286 259 minecraft:light[level=12]
setblock 426 286 266 minecraft:light[level=12]
fill 427 286 270 427 308 270 minecraft:black_concrete
setblock 433 286 231 minecraft:light[level=12]
setblock 433 286 238 minecraft:light[level=12]
setblock 433 286 245 minecraft:light[level=12]
setblock 433 286 252 minecraft:light[level=12]
setblock 433 286 259 minecraft:light[level=12]
setblock 433 286 266 minecraft:light[level=12]
setblock 440 286 231 minecraft:light[level=12]
setblock 440 286 238 minecraft:light[level=12]
setblock 440 286 245 minecraft:light[level=12]
setblock 440 286 252 minecraft:light[level=12]
setblock 440 286 259 minecraft:light[level=12]
setblock 440 286 266 minecraft:light[level=12]
fill 444 286 228 444 308 228 minecraft:black_concrete
fill 446 286 270 446 308 270 minecraft:black_concrete
setblock 447 286 231 minecraft:light[level=12]
setblock 447 286 238 minecraft:light[level=12]
setblock 447 286 245 minecraft:light[level=12]
setblock 447 286 252 minecraft:light[level=12]
setblock 447 286 259 minecraft:light[level=12]
setblock 447 286 266 minecraft:light[level=12]
setblock 454 286 231 minecraft:light[level=12]
setblock 454 286 238 minecraft:light[level=12]
setblock 454 286 245 minecraft:light[level=12]
setblock 454 286 252 minecraft:light[level=12]
setblock 454 286 259 minecraft:light[level=12]
setblock 454 286 266 minecraft:light[level=12]
setblock 461 286 231 minecraft:light[level=12]
setblock 461 286 238 minecraft:light[level=12]
setblock 461 286 245 minecraft:light[level=12]
setblock 461 286 252 minecraft:light[level=12]
setblock 461 286 259 minecraft:light[level=12]
setblock 461 286 266 minecraft:light[level=12]
setblock 465 286 261 minecraft:white_concrete
setblock 446 287 228 minecraft:sea_lantern
fill 447 287 228 447 305 228 minecraft:black_concrete
fill 448 287 267 449 288 267 minecraft:gray_concrete
fill 449 287 266 449 288 266 minecraft:gray_concrete
fill 449 287 268 449 288 268 minecraft:gray_concrete
fill 465 287 261 465 308 261 minecraft:black_concrete
setblock 423 288 245 minecraft:purple_terracotta
setblock 426 288 270 minecraft:ochre_froglight
setblock 433 288 228 minecraft:white_concrete
fill 446 288 228 446 305 228 minecraft:black_concrete
fill 448 288 228 448 293 228 minecraft:black_concrete
setblock 449 288 228 minecraft:pearlescent_froglight
setblock 465 288 259 minecraft:sea_lantern
setblock 423 289 231 minecraft:white_concrete
fill 423 289 245 423 294 245 minecraft:black_concrete
setblock 423 289 259 minecraft:ochre_froglight
fill 426 289 270 426 308 270 minecraft:black_concrete
fill 433 289 228 433 298 228 minecraft:black_concrete
fill 449 289 228 449 296 228 minecraft:black_concrete
setblock 456 289 228 minecraft:pearlescent_froglight
setblock 465 289 229 minecraft:ochre_froglight
fill 465 289 259 465 298 259 minecraft:black_concrete
fill 423 290 231 423 294 231 minecraft:black_concrete
fill 423 290 259 423 308 259 minecraft:black_concrete
setblock 424 290 228 minecraft:purple_concrete
setblock 426 290 231 minecraft:light[level=15]
setblock 426 290 239 minecraft:light[level=15]
setblock 426 290 247 minecraft:light[level=15]
setblock 426 290 255 minecraft:light[level=15]
setblock 426 290 263 minecraft:light[level=15]
setblock 430 290 270 minecraft:white_concrete
setblock 434 290 231 minecraft:light[level=15]
setblock 434 290 239 minecraft:light[level=15]
setblock 434 290 247 minecraft:light[level=15]
setblock 434 290 255 minecraft:light[level=15]
setblock 434 290 263 minecraft:light[level=15]
setblock 442 290 231 minecraft:light[level=15]
setblock 442 290 239 minecraft:light[level=15]
setblock 442 290 247 minecraft:light[level=15]
setblock 442 290 255 minecraft:light[level=15]
setblock 442 290 263 minecraft:light[level=15]
setblock 450 290 231 minecraft:light[level=15]
setblock 450 290 239 minecraft:light[level=15]
setblock 450 290 247 minecraft:light[level=15]
setblock 450 290 255 minecraft:light[level=15]
setblock 450 290 263 minecraft:light[level=15]
fill 456 290 228 456 308 228 minecraft:black_concrete
setblock 456 290 270 minecraft:ochre_froglight
setblock 458 290 231 minecraft:light[level=15]
setblock 458 290 239 minecraft:light[level=15]
setblock 458 290 247 minecraft:light[level=15]
setblock 458 290 255 minecraft:light[level=15]
setblock 458 290 263 minecraft:light[level=15]
setblock 458 290 270 minecraft:pearlescent_froglight
fill 465 290 229 465 305 229 minecraft:black_concrete
fill 424 291 228 424 308 228 minecraft:black_concrete
fill 430 291 270 430 298 270 minecraft:black_concrete
fill 456 291 270 456 308 270 minecraft:black_concrete
fill 458 291 270 458 308 270 minecraft:black_concrete
setblock 423 292 261 minecraft:pearlescent_froglight
setblock 426 292 231 minecraft:light[level=12]
setblock 426 292 238 minecraft:light[level=12]
setblock 426 292 245 minecraft:light[level=12]
setblock 426 292 252 minecraft:light[level=12]
setblock 426 292 259 minecraft:light[level=12]
setblock 426 292 266 minecraft:light[level=12]
setblock 433 292 231 minecraft:light[level=12]
setblock 433 292 238 minecraft:light[level=12]
setblock 433 292 245 minecraft:light[level=12]
setblock 433 292 252 minecraft:light[level=12]
setblock 433 292 259 minecraft:light[level=12]
setblock 433 292 266 minecraft:light[level=12]
setblock 440 292 231 minecraft:light[level=12]
setblock 440 292 238 minecraft:light[level=12]
setblock 440 292 245 minecraft:light[level=12]
setblock 440 292 252 minecraft:light[level=12]
setblock 440 292 259 minecraft:light[level=12]
setblock 440 292 266 minecraft:light[level=12]
setblock 447 292 231 minecraft:light[level=12]
setblock 447 292 238 minecraft:light[level=12]
setblock 447 292 245 minecraft:light[level=12]
setblock 447 292 252 minecraft:light[level=12]
setblock 447 292 259 minecraft:light[level=12]
setblock 447 292 266 minecraft:light[level=12]
setblock 451 292 228 minecraft:sea_lantern
setblock 454 292 231 minecraft:light[level=12]
setblock 454 292 238 minecraft:light[level=12]
setblock 454 292 245 minecraft:light[level=12]
setblock 454 292 252 minecraft:light[level=12]
setblock 454 292 259 minecraft:light[level=12]
setblock 454 292 266 minecraft:light[level=12]
setblock 460 292 270 minecraft:magenta_terracotta
setblock 461 292 231 minecraft:light[level=12]
setblock 461 292 238 minecraft:light[level=12]
setblock 461 292 245 minecraft:light[level=12]
setblock 461 292 252 minecraft:light[level=12]
setblock 461 292 259 minecraft:light[level=12]
setblock 461 292 266 minecraft:light[level=12]
setblock 465 292 242 minecraft:pearlescent_froglight
fill 423 293 261 423 308 261 minecraft:black_concrete
fill 451 293 228 451 295 228 minecraft:black_concrete
setblock 455 293 228 minecraft:purple_terracotta
fill 460 293 270 460 308 270 minecraft:black_concrete
setblock 465 293 239 minecraft:purple_concrete
fill 465 293 242 465 308 242 minecraft:black_concrete
setblock 423 294 252 minecraft:sea_lantern
setblock 423 294 269 minecraft:white_concrete
setblock 438 294 228 minecraft:white_concrete
setblock 448 294 228 minecraft:white_concrete
setblock 449 294 270 minecraft:pearlescent_froglight
fill 455 294 228 455 308 228 minecraft:black_concrete
setblock 461 294 270 minecraft:pearlescent_froglight
fill 465 294 239 465 300 239 minecraft:black_concrete
setblock 423 295 231 minecraft:purple_terracotta
setblock 423 295 239 minecraft:pearlescent_froglight
setblock 423 295 245 minecraft:white_concrete
fill 423 295 252 423 308 252 minecraft:black_concrete
fill 423 295 269 423 308 269 minecraft:black_concrete
fill 435 295 249 435 296 249 minecraft:gray_concrete
fill 438 295 228 438 308 228 minecraft:black_concrete
fill 448 295 228 448 308 228 minecraft:black_concrete
fill 449 295 270 449 299 270 minecraft:black_concrete
setblock 451 295 270 minecraft:purple_concrete
setblock 452 295 270 minecraft:purple_terracotta
fill 461 295 270 461 308 270 minecraft:black_concrete
setblock 465 295 255 minecraft:ochre_froglight
fill 423 296 231 423 300 231 minecraft:black_concrete
fill 423 296 239 423 308 239 minecraft:black_concrete
fill 423 296 245 423 308 245 minecraft:black_concrete
setblock 424 296 270 minecraft:ochre_froglight
setblock 451 296 228 minecraft:sea_lantern
fill 451 296 270 452 302 270 minecraft:black_concrete
fill 465 296 255 465 298 255 minecraft:black_concrete
setblock 465 296 264 minecraft:blue_concrete
setblock 423 297 254 minecraft:pearlescent_froglight
fill 424 297 270 424 308 270 minecraft:black_concrete
setblock 426 297 231 minecraft:light[level=15]
setblock 426 297 239 minecraft:light[level=15]
setblock 426 297 247 minecraft:light[level=15]
setblock 426 297 255 minecraft:light[level=15]
setblock 426 297 263 minecraft:light[level=15]
setblock 434 297 231 minecraft:light[level=15]
setblock 434 297 239 minecraft:light[level=15]
setblock 434 297 247 minecraft:light[level=15]
setblock 434 297 255 minecraft:light[level=15]
setblock 434 297 263 minecraft:light[level=15]
setblock 442 297 231 minecraft:light[level=15]
setblock 442 297 239 minecraft:light[level=15]
setblock 442 297 247 minecraft:light[level=15]
setblock 442 297 255 minecraft:light[level=15]
setblock 442 297 263 minecraft:light[level=15]
setblock 449 297 228 minecraft:ochre_froglight
setblock 450 297 231 minecraft:light[level=15]
setblock 450 297 239 minecraft:light[level=15]
setblock 450 297 247 minecraft:light[level=15]
setblock 450 297 255 minecraft:light[level=15]
setblock 450 297 263 minecraft:light[level=15]
fill 451 297 228 451 308 228 minecraft:black_concrete
setblock 458 297 228 minecraft:white_concrete
setblock 458 297 231 minecraft:light[level=15]
setblock 458 297 239 minecraft:light[level=15]
setblock 458 297 247 minecraft:light[level=15]
setblock 458 297 255 minecraft:light[level=15]
setblock 458 297 263 minecraft:light[level=15]
fill 465 297 264 465 308 264 minecraft:black_concrete
fill 423 298 254 423 308 254 minecraft:black_concrete
setblock 426 298 231 minecraft:light[level=12]
setblock 426 298 238 minecraft:light[level=12]
setblock 426 298 245 minecraft:light[level=12]
setblock 426 298 252 minecraft:light[level=12]
setblock 426 298 259 minecraft:light[level=12]
setblock 426 298 266 minecraft:light[level=12]
setblock 431 298 228 minecraft:ochre_froglight
setblock 433 298 231 minecraft:light[level=12]
setblock 433 298 238 minecraft:light[level=12]
setblock 433 298 245 minecraft:light[level=12]
setblock 433 298 252 minecraft:light[level=12]
setblock 433 298 259 minecraft:light[level=12]
setblock 433 298 266 minecraft:light[level=12]
setblock 440 298 231 minecraft:light[level=12]
setblock 440 298 238 minecraft:light[level=12]
setblock 440 298 245 minecraft:light[level=12]
setblock 440 298 252 minecraft:light[level=12]
setblock 440 298 259 minecraft:light[level=12]
setblock 440 298 266 minecraft:light[level=12]
setblock 447 298 231 minecraft:light[level=12]
setblock 447 298 238 minecraft:light[level=12]
setblock 447 298 245 minecraft:light[level=12]
setblock 447 298 252 minecraft:light[level=12]
setblock 447 298 259 minecraft:light[level=12]
setblock 447 298 266 minecraft:light[level=12]
setblock 448 298 270 minecraft:ochre_froglight
fill 449 298 228 449 308 228 minecraft:black_concrete
setblock 454 298 231 minecraft:light[level=12]
setblock 454 298 238 minecraft:light[level=12]
setblock 454 298 245 minecraft:light[level=12]
setblock 454 298 252 minecraft:light[level=12]
setblock 454 298 259 minecraft:light[level=12]
setblock 454 298 266 minecraft:light[level=12]
setblock 457 298 228 minecraft:sea_lantern
fill 458 298 228 458 299 228 minecraft:black_concrete
setblock 461 298 231 minecraft:light[level=12]
setblock 461 298 238 minecraft:light[level=12]
setblock 461 298 245 minecraft:light[level=12]
setblock 461 298 252 minecraft:light[level=12]
setblock 461 298 259 minecraft:light[level=12]
setblock 461 298 266 minecraft:light[level=12]
setblock 465 298 238 minecraft:sea_lantern
setblock 423 299 263 minecraft:ochre_froglight
setblock 430 299 270 minecraft:purple_terracotta
fill 431 299 228 431 308 228 minecraft:black_concrete
setblock 433 299 228 minecraft:pearlescent_froglight
fill 448 299 270 448 301 270 minecraft:black_concrete
fill 457 299 228 457 308 228 minecraft:black_concrete
setblock 465 299 235 minecraft:purple_terracotta
fill 465 299 238 465 308 238 minecraft:black_concrete
setblock 465 299 255 minecraft:pearlescent_froglight
setblock 465 299 257 minecraft:blue_concrete
setblock 465 299 259 minecraft:ochre_froglight
fill 423 300 263 423 304 263 minecraft:black_concrete
setblock 426 300 228 minecraft:sea_lantern
fill 430 300 270 430 308 270 minecraft:black_concrete
fill 433 300 228 433 302 228 minecraft:black_concrete
setblock 441 300 228 minecraft:ochre_froglight
setblock 449 300 270 minecraft:white_concrete
setblock 453 300 228 minecraft:pearlescent_froglight
setblock 458 300 228 minecraft:sea_lantern
setblock 463 300 270 minecraft:white_concrete
fill 465 300 235 465 308 235 minecraft:black_concrete
setblock 465 300 241 minecraft:sea_lantern
fill 465 300 255 465 308 255 minecraft:black_concrete
fill 465 300 257 465 301 257 minecraft:black_concrete
fill 465 300 259 465 308 259 minecraft:black_concrete
setblock 423 301 231 minecraft:sea_lantern
fill 426 301 228 426 304 228 minecraft:black_concrete
fill 441 301 228 441 308 228 minecraft:black_concrete
fill 449 301 270 449 304 270 minecraft:black_concrete
fill 453 301 228 453 308 228 minecraft:black_concrete
fill 458 301 228 458 303 228 minecraft:black_concrete
fill 463 301 270 463 308 270 minecraft:black_concrete
setblock 465 301 239 minecraft:white_concrete
fill 465 301 241 465 308 241 minecraft:black_concrete
setblock 465 301 249 minecraft:ochre_froglight
setblock 465 301 260 minecraft:purple_concrete
fill 423 302 231 423 308 231 minecraft:black_concrete
setblock 448 302 270 minecraft:magenta_terracotta
fill 465 302 239 465 308 239 minecraft:black_concrete
fill 465 302 249 465 308 249 minecraft:black_concrete
setblock 465 302 257 minecraft:purple_concrete
fill 465 302 260 465 308 260 minecraft:black_concrete
setblock 433 303 228 minecraft:white_concrete
setblock 435 303 270 minecraft:white_concrete
setblock 445 303 270 minecraft:white_concrete
fill 448 303 270 448 308 270 minecraft:black_concrete
setblock 451 303 270 minecraft:sea_lantern
fill 452 303 270 452 308 270 minecraft:black_concrete
fill 465 303 257 465 308 257 minecraft:black_concrete
setblock 423 304 258 minecraft:ochre_froglight
setblock 428 304 228 minecraft:ochre_froglight
fill 433 304 228 433 308 228 minecraft:black_concrete
setblock 435 304 270 minecraft:black_concrete
fill 445 304 270 445 308 270 minecraft:black_concrete
fill 451 304 270 451 308 270 minecraft:black_concrete
setblock 454 304 228 minecraft:ochre_froglight
setblock 458 304 228 minecraft:white_concrete
setblock 465 304 268 minecraft:white_concrete
setblock 423 305 242 minecraft:magenta_terracotta
setblock 423 305 253 minecraft:sea_lantern
fill 423 305 258 423 308 258 minecraft:black_concrete
setblock 423 305 263 minecraft:white_concrete
setblock 425 305 228 minecraft:ochre_froglight
setblock 426 305 228 minecraft:white_concrete
fill 428 305 228 428 308 228 minecraft:black_concrete
setblock 435 305 270 minecraft:sea_lantern
setblock 449 305 270 minecraft:sea_lantern
fill 454 305 228 454 308 228 minecraft:black_concrete
fill 458 305 228 458 308 228 minecraft:black_concrete
setblock 460 305 228 minecraft:white_concrete
setblock 464 305 228 minecraft:ochre_froglight
fill 465 305 268 465 308 268 minecraft:black_concrete
fill 423 306 242 423 308 242 minecraft:black_concrete
fill 423 306 253 423 308 253 minecraft:black_concrete
setblock 423 306 255 minecraft:white_concrete
fill 423 306 263 423 308 263 minecraft:black_concrete
setblock 423 306 264 minecraft:white_concrete
setblock 423 306 266 minecraft:sea_lantern
fill 425 306 228 426 308 228 minecraft:black_concrete
fill 435 306 270 435 308 270 minecraft:black_concrete
setblock 437 306 228 minecraft:ochre_froglight
setblock 444 306 270 minecraft:ochre_froglight
fill 446 306 228 447 306 228 minecraft:pearlescent_froglight
fill 449 306 270 449 308 270 minecraft:black_concrete
fill 460 306 228 460 308 228 minecraft:black_concrete
fill 464 306 228 464 308 228 minecraft:black_concrete
setblock 465 306 229 minecraft:white_concrete
setblock 465 306 232 minecraft:pearlescent_froglight
setblock 423 307 246 minecraft:purple_terracotta
fill 423 307 255 423 308 255 minecraft:black_concrete
setblock 423 307 264 minecraft:black_concrete
fill 423 307 266 423 308 266 minecraft:black_concrete
setblock 425 307 270 minecraft:pearlescent_froglight
fill 437 307 228 437 308 228 minecraft:black_concrete
fill 444 307 270 444 308 270 minecraft:black_concrete
fill 446 307 228 447 308 228 minecraft:black_concrete
fill 465 307 229 465 308 229 minecraft:black_concrete
fill 465 307 232 465 308 232 minecraft:black_concrete
setblock 423 308 246 minecraft:black_concrete
setblock 423 308 247 minecraft:pearlescent_froglight
setblock 423 308 264 minecraft:pearlescent_froglight
setblock 425 308 270 minecraft:black_concrete
