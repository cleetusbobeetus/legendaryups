fill 379 216 645 381 216 645 minecraft:polished_blackstone
fill 380 216 646 381 221 646 minecraft:black_concrete
fill 381 216 605 383 216 605 minecraft:polished_blackstone
fill 383 216 645 385 216 645 minecraft:polished_blackstone
fill 385 216 604 386 221 604 minecraft:black_concrete
fill 385 216 605 387 216 605 minecraft:polished_blackstone
fill 387 216 604 388 216 604 minecraft:red_concrete
fill 387 216 645 389 216 645 minecraft:polished_blackstone
fill 387 216 646 387 217 646 minecraft:red_concrete
fill 388 216 646 389 217 646 minecraft:black_concrete
fill 389 216 604 389 221 604 minecraft:black_concrete
fill 389 216 605 391 216 605 minecraft:polished_blackstone
fill 390 216 646 391 216 646 minecraft:red_concrete
fill 391 216 645 393 216 645 minecraft:polished_blackstone
fill 392 216 646 392 221 646 minecraft:black_concrete
fill 393 216 605 395 216 605 minecraft:polished_blackstone
fill 395 216 645 397 216 645 minecraft:polished_blackstone
fill 397 216 604 398 221 604 minecraft:black_concrete
fill 397 216 605 399 216 605 minecraft:polished_blackstone
fill 398 216 646 399 217 646 minecraft:red_concrete
fill 399 216 604 400 217 604 minecraft:red_concrete
fill 399 216 645 401 216 645 minecraft:polished_blackstone
fill 400 216 646 401 221 646 minecraft:black_concrete
fill 401 216 604 404 217 604 minecraft:black_concrete
fill 401 216 605 403 216 605 minecraft:polished_blackstone
fill 403 216 645 405 216 645 minecraft:polished_blackstone
fill 405 216 605 407 216 605 minecraft:polished_blackstone
fill 406 216 604 406 221 604 minecraft:black_concrete
fill 407 216 645 409 216 645 minecraft:polished_blackstone
setblock 408 216 604 minecraft:red_concrete
fill 408 216 646 409 217 646 minecraft:black_concrete
fill 409 216 604 410 221 604 minecraft:black_concrete
fill 409 216 605 411 216 605 minecraft:polished_blackstone
fill 410 216 631 411 224 632 minecraft:polished_blackstone
fill 410 216 646 411 216 646 minecraft:red_concrete
fill 411 216 604 411 217 604 minecraft:red_concrete
fill 411 216 645 413 216 645 minecraft:polished_blackstone
fill 412 216 646 413 221 646 minecraft:black_concrete
fill 413 216 605 415 216 605 minecraft:polished_blackstone
fill 415 216 645 417 216 645 minecraft:polished_blackstone
fill 417 216 604 418 221 604 minecraft:black_concrete
fill 417 216 605 417 216 607 minecraft:polished_blackstone
fill 417 216 609 417 216 611 minecraft:polished_blackstone
fill 417 216 613 417 216 615 minecraft:polished_blackstone
fill 417 216 617 417 216 619 minecraft:polished_blackstone
fill 417 216 621 417 216 623 minecraft:polished_blackstone
fill 417 216 625 417 216 627 minecraft:polished_blackstone
fill 417 216 629 417 216 631 minecraft:polished_blackstone
fill 417 216 633 417 216 635 minecraft:polished_blackstone
fill 417 216 637 417 216 639 minecraft:polished_blackstone
fill 417 216 641 417 216 643 minecraft:polished_blackstone
fill 418 216 605 418 216 606 minecraft:red_concrete
fill 418 216 615 418 221 616 minecraft:black_concrete
fill 418 216 617 418 217 618 minecraft:red_concrete
fill 418 216 623 418 218 624 minecraft:black_concrete
fill 418 216 625 418 216 626 minecraft:red_concrete
fill 418 216 627 418 221 627 minecraft:black_concrete
fill 418 216 629 418 217 629 minecraft:red_concrete
setblock 418 216 630 minecraft:black_concrete
fill 418 216 635 418 221 636 minecraft:black_concrete
fill 418 216 637 418 217 638 minecraft:red_concrete
fill 418 216 644 418 218 644 minecraft:black_concrete
fill 418 216 646 418 217 646 minecraft:red_concrete
setblock 376 217 604 minecraft:red_concrete
fill 376 217 608 376 220 608 minecraft:black_concrete
fill 376 217 624 376 217 625 minecraft:red_concrete
setblock 376 217 628 minecraft:red_concrete
fill 376 217 629 376 220 629 minecraft:black_concrete
fill 376 217 640 376 220 640 minecraft:black_concrete
setblock 376 217 645 minecraft:red_concrete
fill 378 217 608 379 240 609 minecraft:polished_blackstone
setblock 386 217 646 minecraft:red_concrete
fill 387 217 604 387 220 604 minecraft:black_concrete
setblock 388 217 604 minecraft:red_concrete
setblock 390 217 604 minecraft:black_concrete
fill 390 217 646 391 220 646 minecraft:black_concrete
fill 391 217 604 392 217 604 minecraft:red_concrete
fill 393 217 604 394 217 604 minecraft:black_concrete
fill 406 217 626 406 218 626 minecraft:magma_block
setblock 407 217 646 minecraft:red_concrete
fill 408 217 604 408 220 604 minecraft:black_concrete
fill 409 217 631 409 218 632 minecraft:black_concrete
fill 410 217 630 411 218 630 minecraft:black_concrete
fill 410 217 633 411 218 633 minecraft:black_concrete
setblock 410 217 646 minecraft:red_concrete
fill 411 217 646 411 220 646 minecraft:black_concrete
setblock 412 217 604 minecraft:red_concrete
fill 412 217 631 412 218 632 minecraft:black_concrete
fill 418 217 605 418 220 605 minecraft:black_concrete
setblock 418 217 606 minecraft:red_concrete
setblock 418 217 609 minecraft:red_concrete
fill 418 217 625 418 220 625 minecraft:black_concrete
setblock 418 217 626 minecraft:red_concrete
setblock 418 217 630 minecraft:red_concrete
setblock 418 217 641 minecraft:red_concrete
fill 418 217 642 418 219 642 minecraft:black_concrete
fill 376 218 604 376 223 605 minecraft:black_concrete
fill 376 218 614 376 218 615 minecraft:red_concrete
fill 376 218 616 376 223 617 minecraft:black_concrete
fill 376 218 623 376 219 623 minecraft:red_concrete
fill 376 218 624 376 223 625 minecraft:black_concrete
setblock 376 218 626 minecraft:red_concrete
fill 376 218 628 376 223 628 minecraft:black_concrete
fill 376 218 634 376 219 635 minecraft:red_concrete
fill 376 218 636 376 223 637 minecraft:black_concrete
fill 376 218 645 376 223 645 minecraft:black_concrete
fill 376 218 646 377 218 646 minecraft:red_concrete
fill 378 218 646 379 223 646 minecraft:black_concrete
fill 379 218 604 380 223 604 minecraft:black_concrete
setblock 379 218 607 minecraft:light[level=12]
setblock 379 218 615 minecraft:light[level=12]
setblock 379 218 623 minecraft:light[level=12]
setblock 379 218 631 minecraft:light[level=12]
setblock 379 218 639 minecraft:light[level=12]
fill 381 218 604 382 219 604 minecraft:red_concrete
fill 384 218 646 385 219 646 minecraft:red_concrete
fill 386 218 646 387 223 646 minecraft:black_concrete
setblock 387 218 607 minecraft:light[level=12]
setblock 387 218 615 minecraft:light[level=12]
setblock 387 218 623 minecraft:light[level=12]
setblock 387 218 631 minecraft:light[level=12]
setblock 387 218 639 minecraft:light[level=12]
fill 388 218 604 388 223 604 minecraft:black_concrete
setblock 388 218 646 minecraft:red_concrete
fill 389 218 646 389 221 646 minecraft:black_concrete
setblock 390 218 604 minecraft:red_concrete
fill 391 218 604 392 223 604 minecraft:black_concrete
fill 393 218 604 393 219 604 minecraft:red_concrete
setblock 394 218 604 minecraft:black_concrete
setblock 395 218 607 minecraft:light[level=12]
setblock 395 218 615 minecraft:light[level=12]
setblock 395 218 623 minecraft:light[level=12]
setblock 395 218 631 minecraft:light[level=12]
setblock 395 218 639 minecraft:light[level=12]
fill 396 218 646 397 219 646 minecraft:red_concrete
fill 398 218 646 399 223 646 minecraft:black_concrete
fill 399 218 604 400 223 604 minecraft:black_concrete
fill 401 218 604 402 218 604 minecraft:red_concrete
fill 403 218 604 404 219 604 minecraft:black_concrete
setblock 403 218 607 minecraft:light[level=12]
setblock 403 218 615 minecraft:light[level=12]
setblock 403 218 623 minecraft:light[level=12]
setblock 403 218 631 minecraft:light[level=12]
setblock 403 218 639 minecraft:light[level=12]
fill 405 218 646 405 219 646 minecraft:red_concrete
fill 407 218 646 407 223 646 minecraft:black_concrete
fill 408 218 646 409 218 646 minecraft:red_concrete
setblock 409 218 630 minecraft:black_concrete
setblock 409 218 633 minecraft:black_concrete
fill 410 218 646 410 223 646 minecraft:black_concrete
fill 411 218 604 412 223 604 minecraft:black_concrete
setblock 411 218 607 minecraft:light[level=12]
setblock 411 218 615 minecraft:light[level=12]
setblock 411 218 623 minecraft:light[level=12]
setblock 411 218 639 minecraft:light[level=12]
setblock 412 218 630 minecraft:black_concrete
setblock 412 218 633 minecraft:black_concrete
fill 413 218 604 414 219 604 minecraft:red_concrete
fill 413 218 631 413 218 632 minecraft:black_concrete
fill 416 218 646 417 219 646 minecraft:red_concrete
fill 418 218 606 418 223 606 minecraft:black_concrete
fill 418 218 607 418 218 608 minecraft:red_concrete
fill 418 218 609 418 223 609 minecraft:black_concrete
fill 418 218 611 418 219 611 minecraft:red_concrete
fill 418 218 617 418 223 618 minecraft:black_concrete
fill 418 218 619 418 219 620 minecraft:red_concrete
fill 418 218 626 418 220 626 minecraft:black_concrete
setblock 418 218 628 minecraft:red_concrete
fill 418 218 629 418 223 630 minecraft:black_concrete
fill 418 218 631 418 219 632 minecraft:red_concrete
fill 418 218 637 418 223 638 minecraft:black_concrete
fill 418 218 639 418 218 640 minecraft:red_concrete
fill 418 218 641 418 219 641 minecraft:black_concrete
fill 418 218 646 418 223 646 minecraft:black_concrete
setblock 376 219 611 minecraft:red_concrete
setblock 376 219 614 minecraft:red_concrete
fill 376 219 615 376 222 615 minecraft:black_concrete
setblock 376 219 622 minecraft:red_concrete
fill 376 219 626 376 222 626 minecraft:black_concrete
fill 376 219 642 376 219 643 minecraft:red_concrete
setblock 376 219 646 minecraft:red_concrete
fill 377 219 646 377 222 646 minecraft:black_concrete
fill 378 219 610 379 219 610 minecraft:black_concrete
setblock 379 219 607 minecraft:black_concrete
fill 380 219 608 380 219 609 minecraft:black_concrete
fill 388 219 646 388 222 646 minecraft:black_concrete
fill 390 219 604 390 222 604 minecraft:black_concrete
setblock 393 219 646 minecraft:red_concrete
setblock 394 219 604 minecraft:red_concrete
fill 401 219 604 401 222 604 minecraft:black_concrete
setblock 402 219 604 minecraft:red_concrete
setblock 404 219 646 minecraft:red_concrete
setblock 405 219 604 minecraft:red_concrete
fill 408 219 646 409 221 646 minecraft:black_concrete
fill 418 219 607 418 222 608 minecraft:black_concrete
setblock 418 219 612 minecraft:red_concrete
setblock 418 219 623 minecraft:red_concrete
fill 418 219 624 418 221 624 minecraft:black_concrete
fill 418 219 628 418 222 628 minecraft:black_concrete
fill 418 219 639 418 222 639 minecraft:black_concrete
setblock 418 219 640 minecraft:red_concrete
fill 418 219 643 418 219 644 minecraft:red_concrete
fill 376 220 609 376 221 609 minecraft:red_concrete
fill 376 220 611 376 225 611 minecraft:black_concrete
fill 376 220 612 376 220 613 minecraft:red_concrete
fill 376 220 614 376 225 614 minecraft:black_concrete
fill 376 220 620 376 221 621 minecraft:red_concrete
fill 376 220 622 376 225 623 minecraft:black_concrete
fill 376 220 632 376 220 633 minecraft:red_concrete
fill 376 220 634 376 225 635 minecraft:black_concrete
fill 376 220 641 376 221 641 minecraft:red_concrete
fill 376 220 642 376 225 643 minecraft:black_concrete
setblock 376 220 644 minecraft:red_concrete
fill 376 220 646 376 225 646 minecraft:black_concrete
fill 381 220 604 382 225 604 minecraft:black_concrete
fill 382 220 646 383 221 646 minecraft:red_concrete
fill 383 220 604 384 220 604 minecraft:red_concrete
fill 384 220 646 385 225 646 minecraft:black_concrete
fill 393 220 604 394 225 604 minecraft:black_concrete
fill 393 220 646 393 225 646 minecraft:black_concrete
fill 394 220 646 395 220 646 minecraft:red_concrete
fill 395 220 604 396 221 604 minecraft:red_concrete
fill 396 220 646 397 225 646 minecraft:black_concrete
fill 402 220 604 402 225 604 minecraft:black_concrete
fill 402 220 646 403 221 646 minecraft:red_concrete
fill 403 220 604 404 220 604 minecraft:red_concrete
fill 404 220 646 405 225 646 minecraft:black_concrete
fill 405 220 604 405 225 604 minecraft:black_concrete
setblock 406 220 646 minecraft:red_concrete
fill 407 220 604 407 221 604 minecraft:red_concrete
fill 413 220 604 414 225 604 minecraft:black_concrete
fill 414 220 646 415 221 646 minecraft:red_concrete
fill 415 220 604 416 221 604 minecraft:red_concrete
fill 416 220 646 417 225 646 minecraft:black_concrete
setblock 418 220 610 minecraft:red_concrete
fill 418 220 611 418 225 612 minecraft:black_concrete
fill 418 220 613 418 221 614 minecraft:red_concrete
fill 418 220 619 418 225 620 minecraft:black_concrete
fill 418 220 621 418 220 622 minecraft:red_concrete
fill 418 220 623 418 225 623 minecraft:black_concrete
fill 418 220 631 418 225 632 minecraft:black_concrete
fill 418 220 633 418 221 634 minecraft:red_concrete
fill 418 220 640 418 225 640 minecraft:black_concrete
fill 418 220 641 418 220 642 minecraft:red_concrete
fill 418 220 643 418 221 644 minecraft:black_concrete
fill 418 220 645 418 221 645 minecraft:red_concrete
setblock 376 221 608 minecraft:red_concrete
fill 376 221 612 376 224 613 minecraft:black_concrete
setblock 376 221 629 minecraft:red_concrete
setblock 376 221 632 minecraft:red_concrete
fill 376 221 633 376 224 633 minecraft:black_concrete
setblock 376 221 640 minecraft:red_concrete
fill 376 221 644 376 224 644 minecraft:black_concrete
fill 383 221 604 383 224 604 minecraft:black_concrete
setblock 384 221 604 minecraft:red_concrete
setblock 387 221 604 minecraft:red_concrete
fill 390 221 646 391 221 646 minecraft:red_concrete
setblock 394 221 646 minecraft:red_concrete
fill 395 221 646 395 224 646 minecraft:black_concrete
fill 403 221 604 404 224 604 minecraft:black_concrete
fill 406 221 646 406 223 646 minecraft:black_concrete
setblock 408 221 604 minecraft:red_concrete
setblock 411 221 646 minecraft:red_concrete
setblock 418 221 605 minecraft:red_concrete
fill 418 221 610 418 224 610 minecraft:black_concrete
fill 418 221 621 418 224 621 minecraft:black_concrete
setblock 418 221 622 minecraft:red_concrete
fill 418 221 625 418 221 626 minecraft:red_concrete
fill 418 221 641 418 223 642 minecraft:black_concrete
fill 376 222 606 376 223 607 minecraft:red_concrete
fill 376 222 608 376 227 609 minecraft:black_concrete
setblock 376 222 610 minecraft:red_concrete
fill 376 222 618 376 223 619 minecraft:red_concrete
fill 376 222 620 376 227 621 minecraft:black_concrete
fill 376 222 627 376 223 627 minecraft:red_concrete
fill 376 222 629 376 227 629 minecraft:black_concrete
fill 376 222 630 376 222 631 minecraft:red_concrete
fill 376 222 632 376 227 632 minecraft:black_concrete
fill 376 222 638 376 223 639 minecraft:red_concrete
fill 376 222 640 376 227 641 minecraft:black_concrete
fill 377 222 604 378 223 604 minecraft:red_concrete
fill 377 222 605 379 222 605 minecraft:polished_blackstone
fill 377 222 607 377 222 609 minecraft:polished_blackstone
fill 377 222 611 377 222 613 minecraft:polished_blackstone
fill 377 222 615 377 222 617 minecraft:polished_blackstone
fill 377 222 619 377 222 621 minecraft:polished_blackstone
fill 377 222 623 377 222 625 minecraft:polished_blackstone
fill 377 222 627 377 222 629 minecraft:polished_blackstone
fill 377 222 631 377 222 633 minecraft:polished_blackstone
fill 377 222 635 377 222 637 minecraft:polished_blackstone
fill 377 222 639 377 222 641 minecraft:polished_blackstone
fill 377 222 643 377 222 645 minecraft:polished_blackstone
fill 379 222 645 381 222 645 minecraft:polished_blackstone
fill 380 222 646 381 222 646 minecraft:red_concrete
fill 381 222 605 383 222 605 minecraft:polished_blackstone
fill 382 222 646 383 227 646 minecraft:black_concrete
fill 383 222 645 385 222 645 minecraft:polished_blackstone
fill 384 222 604 384 227 604 minecraft:black_concrete
fill 385 222 604 386 222 604 minecraft:red_concrete
fill 385 222 605 387 222 605 minecraft:polished_blackstone
fill 387 222 604 387 227 604 minecraft:black_concrete
fill 387 222 645 389 222 645 minecraft:polished_blackstone
fill 389 222 604 389 223 604 minecraft:red_concrete
fill 389 222 605 391 222 605 minecraft:polished_blackstone
fill 389 222 646 389 223 646 minecraft:red_concrete
fill 390 222 646 391 227 646 minecraft:black_concrete
fill 391 222 645 393 222 645 minecraft:polished_blackstone
setblock 392 222 646 minecraft:red_concrete
fill 393 222 605 395 222 605 minecraft:polished_blackstone
fill 394 222 646 394 227 646 minecraft:black_concrete
fill 395 222 604 396 227 604 minecraft:black_concrete
fill 395 222 645 397 222 645 minecraft:polished_blackstone
fill 397 222 604 398 223 604 minecraft:red_concrete
fill 397 222 605 399 222 605 minecraft:polished_blackstone
fill 399 222 645 401 222 645 minecraft:polished_blackstone
fill 400 222 646 401 223 646 minecraft:red_concrete
fill 401 222 605 403 222 605 minecraft:polished_blackstone
fill 402 222 646 403 227 646 minecraft:black_concrete
fill 403 222 645 405 222 645 minecraft:polished_blackstone
fill 405 222 605 407 222 605 minecraft:polished_blackstone
setblock 406 222 604 minecraft:red_concrete
fill 407 222 604 408 227 604 minecraft:black_concrete
fill 407 222 645 409 222 645 minecraft:polished_blackstone
setblock 408 222 646 minecraft:black_concrete
fill 409 222 604 410 223 604 minecraft:red_concrete
fill 409 222 605 411 222 605 minecraft:polished_blackstone
fill 409 222 646 409 223 646 minecraft:red_concrete
fill 411 222 645 413 222 645 minecraft:polished_blackstone
fill 411 222 646 411 227 646 minecraft:black_concrete
fill 412 222 646 413 222 646 minecraft:red_concrete
fill 413 222 605 415 222 605 minecraft:polished_blackstone
fill 414 222 646 415 224 646 minecraft:black_concrete
fill 415 222 604 416 227 604 minecraft:black_concrete
fill 415 222 645 417 222 645 minecraft:polished_blackstone
fill 417 222 604 418 222 604 minecraft:red_concrete
fill 417 222 605 417 222 607 minecraft:polished_blackstone
fill 417 222 609 417 222 611 minecraft:polished_blackstone
fill 417 222 613 417 222 615 minecraft:polished_blackstone
fill 417 222 617 417 222 619 minecraft:polished_blackstone
fill 417 222 621 417 222 623 minecraft:polished_blackstone
fill 417 222 625 417 222 627 minecraft:polished_blackstone
fill 417 222 629 417 222 631 minecraft:polished_blackstone
fill 417 222 633 417 222 635 minecraft:polished_blackstone
fill 417 222 637 417 222 639 minecraft:polished_blackstone
fill 417 222 641 417 222 643 minecraft:polished_blackstone
fill 418 222 605 418 227 605 minecraft:black_concrete
fill 418 222 613 418 227 614 minecraft:black_concrete
fill 418 222 615 418 223 616 minecraft:red_concrete
fill 418 222 622 418 227 622 minecraft:black_concrete
setblock 418 222 624 minecraft:red_concrete
fill 418 222 625 418 227 626 minecraft:black_concrete
fill 418 222 627 418 223 627 minecraft:red_concrete
fill 418 222 633 418 227 634 minecraft:black_concrete
fill 418 222 635 418 223 636 minecraft:red_concrete
fill 418 222 643 418 225 643 minecraft:black_concrete
setblock 418 222 644 minecraft:red_concrete
fill 418 222 645 418 227 645 minecraft:black_concrete
fill 376 223 610 376 226 610 minecraft:black_concrete
setblock 376 223 615 minecraft:red_concrete
setblock 376 223 626 minecraft:red_concrete
fill 376 223 630 376 226 631 minecraft:black_concrete
setblock 377 223 646 minecraft:red_concrete
setblock 380 223 646 minecraft:red_concrete
fill 381 223 646 381 226 646 minecraft:black_concrete
fill 385 223 604 386 226 604 minecraft:black_concrete
setblock 388 223 646 minecraft:red_concrete
setblock 390 223 604 minecraft:red_concrete
fill 392 223 646 392 226 646 minecraft:black_concrete
fill 393 223 608 394 224 608 minecraft:magma_block
setblock 401 223 604 minecraft:red_concrete
fill 406 223 604 406 226 604 minecraft:black_concrete
setblock 408 223 646 minecraft:red_concrete
setblock 412 223 646 minecraft:red_concrete
fill 413 223 646 413 226 646 minecraft:black_concrete
fill 417 223 604 417 226 604 minecraft:black_concrete
setblock 418 223 604 minecraft:red_concrete
fill 418 223 607 418 223 608 minecraft:red_concrete
fill 418 223 624 418 226 624 minecraft:black_concrete
setblock 418 223 628 minecraft:red_concrete
setblock 418 223 639 minecraft:red_concrete
fill 418 223 644 418 225 644 minecraft:black_concrete
fill 376 224 604 376 225 605 minecraft:red_concrete
fill 376 224 606 376 229 607 minecraft:black_concrete
fill 376 224 615 376 229 615 minecraft:black_concrete
fill 376 224 616 376 224 617 minecraft:red_concrete
fill 376 224 618 376 229 619 minecraft:black_concrete
fill 376 224 624 376 225 625 minecraft:red_concrete
fill 376 224 626 376 229 627 minecraft:black_concrete
setblock 376 224 628 minecraft:red_concrete
fill 376 224 636 376 225 637 minecraft:red_concrete
fill 376 224 638 376 229 639 minecraft:black_concrete
fill 376 224 645 376 225 645 minecraft:red_concrete
fill 377 224 604 378 229 604 minecraft:black_concrete
fill 377 224 646 377 229 646 minecraft:black_concrete
fill 378 224 646 379 224 646 minecraft:red_concrete
fill 379 224 604 380 225 604 minecraft:red_concrete
fill 380 224 646 380 229 646 minecraft:black_concrete
fill 386 224 646 387 225 646 minecraft:red_concrete
setblock 388 224 604 minecraft:red_concrete
fill 388 224 646 389 229 646 minecraft:black_concrete
fill 389 224 604 390 229 604 minecraft:black_concrete
fill 391 224 604 392 225 604 minecraft:red_concrete
fill 397 224 604 398 229 604 minecraft:black_concrete
fill 398 224 646 399 224 646 minecraft:red_concrete
fill 399 224 604 400 224 604 minecraft:red_concrete
fill 399 224 636 400 225 637 minecraft:red_concrete
fill 400 224 646 401 229 646 minecraft:black_concrete
fill 401 224 604 401 229 604 minecraft:black_concrete
fill 401 224 636 401 225 636 minecraft:red_concrete
fill 406 224 646 407 225 646 minecraft:red_concrete
fill 408 224 632 408 225 632 minecraft:crying_obsidian
fill 408 224 646 409 229 646 minecraft:black_concrete
fill 409 224 604 410 229 604 minecraft:black_concrete
setblock 410 224 646 minecraft:red_concrete
fill 411 224 604 412 225 604 minecraft:red_concrete
fill 412 224 646 412 226 646 minecraft:black_concrete
fill 418 224 604 418 229 604 minecraft:black_concrete
setblock 418 224 606 minecraft:red_concrete
fill 418 224 607 418 229 608 minecraft:black_concrete
fill 418 224 609 418 225 609 minecraft:red_concrete
fill 418 224 615 418 229 616 minecraft:black_concrete
fill 418 224 617 418 224 618 minecraft:red_concrete
fill 418 224 627 418 229 628 minecraft:black_concrete
fill 418 224 629 418 225 630 minecraft:red_concrete
fill 418 224 635 418 226 636 minecraft:black_concrete
fill 418 224 637 418 224 638 minecraft:red_concrete
fill 418 224 639 418 229 639 minecraft:black_concrete
fill 418 224 641 418 225 641 minecraft:red_concrete
setblock 418 224 642 minecraft:black_concrete
fill 418 224 646 418 225 646 minecraft:red_concrete
fill 376 225 612 376 225 613 minecraft:red_concrete
setblock 376 225 616 minecraft:red_concrete
fill 376 225 617 376 228 617 minecraft:black_concrete
fill 376 225 628 376 228 628 minecraft:black_concrete
setblock 376 225 633 minecraft:red_concrete
setblock 376 225 644 minecraft:red_concrete
fill 378 225 646 379 228 646 minecraft:black_concrete
setblock 383 225 604 minecraft:red_concrete
fill 386 225 618 386 226 618 minecraft:blackstone
fill 388 225 604 388 228 604 minecraft:black_concrete
setblock 395 225 646 minecraft:red_concrete
setblock 398 225 646 minecraft:red_concrete
fill 399 225 604 399 228 604 minecraft:black_concrete
fill 399 225 646 399 228 646 minecraft:black_concrete
setblock 400 225 604 minecraft:red_concrete
fill 403 225 604 404 225 604 minecraft:red_concrete
fill 408 225 631 410 225 631 minecraft:crying_obsidian
setblock 409 225 632 minecraft:crying_obsidian
fill 410 225 632 411 240 632 minecraft:polished_blackstone
fill 410 225 646 410 228 646 minecraft:black_concrete
setblock 411 225 631 minecraft:polished_blackstone
fill 414 225 646 414 227 646 minecraft:black_concrete
setblock 415 225 646 minecraft:red_concrete
fill 418 225 606 418 228 606 minecraft:black_concrete
setblock 418 225 610 minecraft:red_concrete
fill 418 225 617 418 228 617 minecraft:black_concrete
setblock 418 225 618 minecraft:red_concrete
setblock 418 225 621 minecraft:red_concrete
fill 418 225 637 418 228 637 minecraft:black_concrete
setblock 418 225 638 minecraft:red_concrete
setblock 418 225 642 minecraft:red_concrete
fill 376 226 604 376 231 605 minecraft:black_concrete
fill 376 226 611 376 227 611 minecraft:red_concrete
fill 376 226 612 376 231 613 minecraft:black_concrete
setblock 376 226 614 minecraft:red_concrete
fill 376 226 616 376 231 616 minecraft:black_concrete
fill 376 226 622 376 227 623 minecraft:red_concrete
fill 376 226 624 376 231 625 minecraft:black_concrete
fill 376 226 633 376 231 633 minecraft:black_concrete
fill 376 226 634 376 226 635 minecraft:red_concrete
fill 376 226 636 376 231 637 minecraft:black_concrete
fill 376 226 642 376 227 643 minecraft:red_concrete
fill 376 226 644 376 231 645 minecraft:black_concrete
setblock 376 226 646 minecraft:red_concrete
fill 379 226 604 380 231 604 minecraft:black_concrete
setblock 379 226 607 minecraft:light[level=12]
setblock 379 226 615 minecraft:light[level=12]
setblock 379 226 623 minecraft:light[level=12]
setblock 379 226 631 minecraft:light[level=12]
setblock 379 226 639 minecraft:light[level=12]
fill 381 226 604 382 226 604 minecraft:red_concrete
fill 383 226 604 383 231 604 minecraft:black_concrete
fill 384 226 646 385 227 646 minecraft:red_concrete
fill 386 226 646 387 231 646 minecraft:black_concrete
setblock 387 226 607 minecraft:light[level=12]
setblock 387 226 615 minecraft:light[level=12]
setblock 387 226 623 minecraft:light[level=12]
setblock 387 226 631 minecraft:light[level=12]
setblock 387 226 639 minecraft:light[level=12]
fill 391 226 604 392 231 604 minecraft:black_concrete
fill 393 226 604 394 227 604 minecraft:red_concrete
fill 393 226 646 393 227 646 minecraft:red_concrete
setblock 395 226 607 minecraft:light[level=12]
setblock 395 226 615 minecraft:light[level=12]
setblock 395 226 623 minecraft:light[level=12]
setblock 395 226 631 minecraft:light[level=12]
setblock 395 226 639 minecraft:light[level=12]
fill 395 226 646 395 231 646 minecraft:black_concrete
fill 396 226 646 397 226 646 minecraft:red_concrete
fill 398 226 646 398 231 646 minecraft:black_concrete
fill 400 226 604 400 231 604 minecraft:black_concrete
setblock 402 226 604 minecraft:red_concrete
fill 403 226 604 404 231 604 minecraft:black_concrete
setblock 403 226 607 minecraft:light[level=12]
setblock 403 226 615 minecraft:light[level=12]
setblock 403 226 623 minecraft:light[level=12]
setblock 403 226 631 minecraft:light[level=12]
setblock 403 226 639 minecraft:light[level=12]
fill 404 226 646 405 227 646 minecraft:red_concrete
fill 405 226 604 405 227 604 minecraft:red_concrete
fill 406 226 646 407 231 646 minecraft:black_concrete
fill 409 226 631 411 226 631 minecraft:crying_obsidian
fill 410 226 630 411 226 630 minecraft:crying_obsidian
fill 411 226 604 412 231 604 minecraft:black_concrete
setblock 411 226 607 minecraft:light[level=12]
setblock 411 226 615 minecraft:light[level=12]
setblock 411 226 623 minecraft:light[level=12]
setblock 411 226 639 minecraft:light[level=12]
fill 413 226 604 414 226 604 minecraft:red_concrete
fill 415 226 646 415 227 646 minecraft:black_concrete
fill 416 226 646 417 226 646 minecraft:red_concrete
fill 418 226 609 418 231 610 minecraft:black_concrete
fill 418 226 611 418 227 612 minecraft:red_concrete
fill 418 226 618 418 231 618 minecraft:black_concrete
fill 418 226 619 418 226 620 minecraft:red_concrete
fill 418 226 621 418 231 621 minecraft:black_concrete
fill 418 226 623 418 227 623 minecraft:red_concrete
fill 418 226 629 418 231 630 minecraft:black_concrete
fill 418 226 631 418 227 632 minecraft:red_concrete
fill 418 226 638 418 228 638 minecraft:black_concrete
setblock 418 226 640 minecraft:red_concrete
fill 418 226 641 418 231 642 minecraft:black_concrete
fill 418 226 643 418 227 644 minecraft:red_concrete
fill 418 226 646 418 231 646 minecraft:black_concrete
setblock 376 227 610 minecraft:red_concrete
fill 376 227 614 376 230 614 minecraft:black_concrete
fill 376 227 630 376 227 631 minecraft:red_concrete
setblock 376 227 634 minecraft:red_concrete
fill 376 227 635 376 230 635 minecraft:black_concrete
fill 376 227 646 376 230 646 minecraft:black_concrete
fill 381 227 604 381 230 604 minecraft:black_concrete
setblock 381 227 646 minecraft:red_concrete
setblock 382 227 604 minecraft:red_concrete
fill 385 227 604 386 227 604 minecraft:red_concrete
setblock 392 227 646 minecraft:red_concrete
fill 396 227 646 397 229 646 minecraft:black_concrete
fill 402 227 604 402 230 604 minecraft:black_concrete
setblock 406 227 604 minecraft:red_concrete
fill 410 227 631 411 240 631 minecraft:polished_blackstone
fill 411 227 630 412 227 630 minecraft:crying_obsidian
fill 412 227 629 413 227 629 minecraft:crying_obsidian
fill 412 227 646 413 227 646 minecraft:red_concrete
fill 413 227 604 413 230 604 minecraft:black_concrete
setblock 414 227 604 minecraft:red_concrete
setblock 416 227 646 minecraft:red_concrete
setblock 417 227 604 minecraft:red_concrete
fill 417 227 646 417 230 646 minecraft:black_concrete
fill 418 227 619 418 230 620 minecraft:black_concrete
setblock 418 227 624 minecraft:red_concrete
setblock 418 227 635 minecraft:red_concrete
fill 418 227 636 418 229 636 minecraft:black_concrete
fill 418 227 640 418 230 640 minecraft:black_concrete
fill 376 228 608 376 229 609 minecraft:red_concrete
fill 376 228 610 376 233 611 minecraft:black_concrete
fill 376 228 620 376 228 621 minecraft:red_concrete
fill 376 228 622 376 233 623 minecraft:black_concrete
fill 376 228 629 376 229 629 minecraft:red_concrete
fill 376 228 630 376 233 631 minecraft:black_concrete
setblock 376 228 632 minecraft:red_concrete
fill 376 228 634 376 233 634 minecraft:black_concrete
fill 376 228 640 376 229 641 minecraft:red_concrete
fill 376 228 642 376 233 643 minecraft:black_concrete
fill 377 228 605 379 228 605 minecraft:polished_blackstone
fill 377 228 607 377 228 609 minecraft:polished_blackstone
fill 377 228 611 377 228 613 minecraft:polished_blackstone
fill 377 228 615 377 228 617 minecraft:polished_blackstone
fill 377 228 619 377 228 621 minecraft:polished_blackstone
fill 377 228 623 377 228 625 minecraft:polished_blackstone
fill 377 228 627 377 228 629 minecraft:polished_blackstone
fill 377 228 631 377 228 633 minecraft:polished_blackstone
fill 377 228 635 377 228 637 minecraft:polished_blackstone
fill 377 228 639 377 228 641 minecraft:polished_blackstone
fill 377 228 643 377 228 645 minecraft:polished_blackstone
fill 379 228 645 381 228 645 minecraft:polished_blackstone
fill 381 228 605 383 228 605 minecraft:polished_blackstone
fill 381 228 646 381 233 646 minecraft:black_concrete
fill 382 228 604 382 233 604 minecraft:black_concrete
fill 382 228 646 383 228 646 minecraft:red_concrete
fill 383 228 645 385 228 645 minecraft:polished_blackstone
setblock 384 228 604 minecraft:red_concrete
fill 384 228 646 385 233 646 minecraft:black_concrete
fill 385 228 604 386 233 604 minecraft:black_concrete
fill 385 228 605 387 228 605 minecraft:polished_blackstone
fill 387 228 604 387 229 604 minecraft:red_concrete
fill 387 228 645 389 228 645 minecraft:polished_blackstone
fill 389 228 605 391 228 605 minecraft:polished_blackstone
fill 390 228 646 391 229 646 minecraft:red_concrete
fill 391 228 645 393 228 645 minecraft:polished_blackstone
fill 392 228 646 393 233 646 minecraft:black_concrete
fill 393 228 604 394 233 604 minecraft:black_concrete
fill 393 228 605 395 228 605 minecraft:polished_blackstone
setblock 394 228 646 minecraft:red_concrete
fill 395 228 604 396 228 604 minecraft:red_concrete
fill 395 228 645 397 228 645 minecraft:polished_blackstone
fill 397 228 605 399 228 605 minecraft:polished_blackstone
fill 399 228 645 401 228 645 minecraft:polished_blackstone
fill 401 228 605 403 228 605 minecraft:polished_blackstone
fill 402 228 646 403 229 646 minecraft:red_concrete
fill 403 228 645 405 228 645 minecraft:polished_blackstone
fill 404 228 646 405 233 646 minecraft:black_concrete
fill 405 228 604 406 233 604 minecraft:black_concrete
fill 405 228 605 407 228 605 minecraft:polished_blackstone
fill 407 228 604 408 229 604 minecraft:red_concrete
fill 407 228 645 409 228 645 minecraft:polished_blackstone
fill 409 228 605 411 228 605 minecraft:polished_blackstone
fill 411 228 645 413 228 645 minecraft:polished_blackstone
fill 411 228 646 411 229 646 minecraft:red_concrete
fill 412 228 646 413 229 646 minecraft:black_concrete
fill 413 228 605 415 228 605 minecraft:polished_blackstone
fill 413 228 629 414 228 629 minecraft:crying_obsidian
fill 414 228 604 414 233 604 minecraft:black_concrete
fill 414 228 628 414 229 628 minecraft:crying_obsidian
fill 414 228 646 415 228 646 minecraft:red_concrete
fill 415 228 604 416 228 604 minecraft:red_concrete
fill 415 228 645 417 228 645 minecraft:polished_blackstone
fill 416 228 646 416 233 646 minecraft:black_concrete
fill 417 228 604 417 233 604 minecraft:black_concrete
fill 417 228 605 417 228 607 minecraft:polished_blackstone
fill 417 228 609 417 228 611 minecraft:polished_blackstone
fill 417 228 613 417 228 615 minecraft:polished_blackstone
fill 417 228 617 417 228 619 minecraft:polished_blackstone
fill 417 228 621 417 228 623 minecraft:polished_blackstone
fill 417 228 625 417 228 627 minecraft:polished_blackstone
fill 417 228 629 417 228 631 minecraft:polished_blackstone
fill 417 228 633 417 228 635 minecraft:polished_blackstone
fill 417 228 637 417 228 639 minecraft:polished_blackstone
fill 417 228 641 417 228 643 minecraft:polished_blackstone
fill 418 228 605 418 229 605 minecraft:red_concrete
fill 418 228 611 418 233 612 minecraft:black_concrete
fill 418 228 613 418 229 614 minecraft:red_concrete
setblock 418 228 622 minecraft:red_concrete
fill 418 228 623 418 233 624 minecraft:black_concrete
fill 418 228 625 418 229 626 minecraft:red_concrete
fill 418 228 631 418 233 632 minecraft:black_concrete
fill 418 228 633 418 228 634 minecraft:red_concrete
fill 418 228 635 418 233 635 minecraft:black_concrete
fill 418 228 643 418 233 644 minecraft:black_concrete
fill 418 228 645 418 229 645 minecraft:red_concrete
setblock 376 229 617 minecraft:red_concrete
setblock 376 229 620 minecraft:red_concrete
fill 376 229 621 376 232 621 minecraft:black_concrete
setblock 376 229 628 minecraft:red_concrete
fill 376 229 632 376 232 632 minecraft:black_concrete
fill 378 229 646 379 229 646 minecraft:red_concrete
setblock 382 229 646 minecraft:red_concrete
fill 383 229 646 383 232 646 minecraft:black_concrete
fill 384 229 604 384 232 604 minecraft:black_concrete
setblock 388 229 604 minecraft:red_concrete
fill 394 229 646 394 231 646 minecraft:black_concrete
fill 395 229 604 395 232 604 minecraft:black_concrete
setblock 396 229 604 minecraft:red_concrete
setblock 399 229 604 minecraft:red_concrete
setblock 399 229 646 minecraft:red_concrete
setblock 410 229 646 minecraft:red_concrete
setblock 414 229 629 minecraft:crying_obsidian
fill 414 229 646 415 231 646 minecraft:black_concrete
fill 415 229 604 416 232 604 minecraft:black_concrete
fill 415 229 628 416 229 628 minecraft:crying_obsidian
setblock 418 229 606 minecraft:red_concrete
setblock 418 229 617 minecraft:red_concrete
fill 418 229 622 418 232 622 minecraft:black_concrete
fill 418 229 633 418 232 633 minecraft:black_concrete
setblock 418 229 634 minecraft:red_concrete
fill 418 229 637 418 229 638 minecraft:red_concrete
fill 376 230 606 376 231 607 minecraft:red_concrete
fill 376 230 608 376 235 609 minecraft:black_concrete
fill 376 230 615 376 231 615 minecraft:red_concrete
fill 376 230 617 376 235 617 minecraft:black_concrete
fill 376 230 618 376 230 619 minecraft:red_concrete
fill 376 230 620 376 235 620 minecraft:black_concrete
fill 376 230 626 376 231 627 minecraft:red_concrete
fill 376 230 628 376 235 629 minecraft:black_concrete
fill 376 230 638 376 230 639 minecraft:red_concrete
fill 376 230 640 376 235 641 minecraft:black_concrete
fill 377 230 604 378 230 604 minecraft:red_concrete
fill 377 230 646 377 231 646 minecraft:red_concrete
fill 378 230 646 379 235 646 minecraft:black_concrete
setblock 380 230 646 minecraft:red_concrete
fill 382 230 646 382 235 646 minecraft:black_concrete
fill 387 230 604 388 235 604 minecraft:black_concrete
fill 388 230 646 389 231 646 minecraft:red_concrete
fill 389 230 604 390 231 604 minecraft:red_concrete
fill 390 230 646 391 235 646 minecraft:black_concrete
fill 396 230 604 396 235 604 minecraft:black_concrete
setblock 396 230 646 minecraft:black_concrete
fill 397 230 604 398 230 604 minecraft:red_concrete
fill 397 230 646 397 231 646 minecraft:red_concrete
fill 399 230 604 399 235 604 minecraft:black_concrete
fill 399 230 646 399 235 646 minecraft:black_concrete
fill 400 230 646 401 230 646 minecraft:red_concrete
fill 401 230 604 401 231 604 minecraft:red_concrete
fill 402 230 646 403 232 646 minecraft:black_concrete
fill 407 230 604 408 235 604 minecraft:black_concrete
fill 408 230 646 409 231 646 minecraft:red_concrete
fill 409 230 604 410 231 604 minecraft:red_concrete
fill 410 230 646 411 235 646 minecraft:black_concrete
setblock 412 230 646 minecraft:red_concrete
fill 413 230 646 413 233 646 minecraft:black_concrete
setblock 416 230 628 minecraft:crying_obsidian
setblock 418 230 604 minecraft:red_concrete
fill 418 230 605 418 235 606 minecraft:black_concrete
fill 418 230 607 418 231 608 minecraft:red_concrete
fill 418 230 613 418 235 614 minecraft:black_concrete
fill 418 230 615 418 230 616 minecraft:red_concrete
fill 418 230 617 418 235 617 minecraft:black_concrete
fill 418 230 625 418 235 626 minecraft:black_concrete
fill 418 230 627 418 231 628 minecraft:red_concrete
fill 418 230 634 418 235 634 minecraft:black_concrete
setblock 418 230 636 minecraft:red_concrete
fill 418 230 637 418 235 638 minecraft:black_concrete
fill 418 230 639 418 231 639 minecraft:red_concrete
fill 418 230 645 418 235 645 minecraft:black_concrete
setblock 376 231 614 minecraft:red_concrete
fill 376 231 618 376 234 619 minecraft:black_concrete
setblock 376 231 635 minecraft:red_concrete
setblock 376 231 638 minecraft:red_concrete
fill 376 231 639 376 234 639 minecraft:black_concrete
setblock 376 231 646 minecraft:red_concrete
fill 377 231 604 377 234 604 minecraft:black_concrete
setblock 378 231 604 minecraft:red_concrete
fill 380 231 646 380 234 646 minecraft:black_concrete
setblock 381 231 604 minecraft:red_concrete
setblock 396 231 646 minecraft:red_concrete
fill 397 231 604 398 234 604 minecraft:black_concrete
setblock 400 231 646 minecraft:red_concrete
fill 401 231 646 401 234 646 minecraft:black_concrete
setblock 402 231 604 minecraft:red_concrete
fill 412 231 646 412 233 646 minecraft:black_concrete
setblock 413 231 604 minecraft:red_concrete
setblock 417 231 646 minecraft:red_concrete
fill 418 231 604 418 234 604 minecraft:black_concrete
fill 418 231 615 418 234 615 minecraft:black_concrete
setblock 418 231 616 minecraft:red_concrete
fill 418 231 619 418 231 620 minecraft:red_concrete
fill 418 231 636 418 234 636 minecraft:black_concrete
setblock 418 231 640 minecraft:red_concrete
fill 376 232 604 376 232 605 minecraft:red_concrete
fill 376 232 606 376 237 607 minecraft:black_concrete
fill 376 232 612 376 233 613 minecraft:red_concrete
fill 376 232 614 376 237 615 minecraft:black_concrete
setblock 376 232 616 minecraft:red_concrete
fill 376 232 624 376 233 625 minecraft:red_concrete
fill 376 232 626 376 237 627 minecraft:black_concrete
fill 376 232 633 376 233 633 minecraft:red_concrete
fill 376 232 635 376 237 635 minecraft:black_concrete
fill 376 232 636 376 232 637 minecraft:red_concrete
fill 376 232 638 376 237 638 minecraft:black_concrete
fill 376 232 644 376 233 645 minecraft:red_concrete
fill 376 232 646 377 237 646 minecraft:black_concrete
fill 378 232 604 378 237 604 minecraft:black_concrete
fill 379 232 604 380 232 604 minecraft:red_concrete
fill 381 232 604 381 237 604 minecraft:black_concrete
fill 383 232 604 383 233 604 minecraft:red_concrete
fill 386 232 646 387 232 646 minecraft:red_concrete
fill 388 232 646 389 237 646 minecraft:black_concrete
fill 389 232 604 390 237 604 minecraft:black_concrete
fill 391 232 604 392 233 604 minecraft:red_concrete
fill 394 232 646 395 233 646 minecraft:red_concrete
fill 396 232 640 396 233 640 minecraft:red_concrete
fill 396 232 646 397 237 646 minecraft:black_concrete
setblock 398 232 646 minecraft:red_concrete
setblock 400 232 604 minecraft:red_concrete
fill 400 232 646 400 234 646 minecraft:black_concrete
fill 401 232 604 402 237 604 minecraft:black_concrete
fill 403 232 604 404 233 604 minecraft:red_concrete
fill 406 232 646 407 233 646 minecraft:red_concrete
fill 408 232 646 409 237 646 minecraft:black_concrete
fill 409 232 604 410 237 604 minecraft:black_concrete
fill 411 232 604 412 232 604 minecraft:red_concrete
fill 413 232 604 413 237 604 minecraft:black_concrete
setblock 414 232 646 minecraft:black_concrete
fill 415 232 646 415 233 646 minecraft:red_concrete
fill 417 232 646 417 237 646 minecraft:black_concrete
fill 418 232 607 418 237 608 minecraft:black_concrete
fill 418 232 609 418 233 610 minecraft:red_concrete
fill 418 232 616 418 237 616 minecraft:black_concrete
setblock 418 232 618 minecraft:red_concrete
fill 418 232 619 418 237 620 minecraft:black_concrete
fill 418 232 621 418 233 621 minecraft:red_concrete
fill 418 232 627 418 237 628 minecraft:black_concrete
fill 418 232 629 418 232 630 minecraft:red_concrete
fill 418 232 639 418 237 640 minecraft:black_concrete
fill 418 232 641 418 233 642 minecraft:red_concrete
fill 418 232 646 418 233 646 minecraft:red_concrete
setblock 376 233 604 minecraft:red_concrete
fill 376 233 605 376 236 605 minecraft:black_concrete
fill 376 233 616 376 236 616 minecraft:black_concrete
setblock 376 233 621 minecraft:red_concrete
setblock 376 233 632 minecraft:red_concrete
fill 376 233 636 376 236 637 minecraft:black_concrete
fill 379 233 604 380 236 604 minecraft:black_concrete
setblock 383 233 646 minecraft:red_concrete
setblock 384 233 604 minecraft:red_concrete
setblock 386 233 646 minecraft:red_concrete
fill 387 233 646 387 236 646 minecraft:black_concrete
setblock 395 233 604 minecraft:red_concrete
fill 398 233 646 398 236 646 minecraft:black_concrete
fill 400 233 604 400 236 604 minecraft:black_concrete
fill 402 233 646 402 235 646 minecraft:black_concrete
setblock 403 233 646 minecraft:red_concrete
fill 411 233 604 411 236 604 minecraft:black_concrete
setblock 412 233 604 minecraft:red_concrete
setblock 414 233 646 minecraft:red_concrete
fill 415 233 604 416 233 604 minecraft:red_concrete
fill 418 233 618 418 236 618 minecraft:black_concrete
setblock 418 233 622 minecraft:red_concrete
fill 418 233 629 418 236 629 minecraft:black_concrete
setblock 418 233 630 minecraft:red_concrete
setblock 418 233 633 minecraft:red_concrete
fill 376 234 604 376 239 604 minecraft:black_concrete
fill 376 234 610 376 235 611 minecraft:red_concrete
fill 376 234 612 376 239 613 minecraft:black_concrete
fill 376 234 621 376 239 621 minecraft:black_concrete
fill 376 234 622 376 234 623 minecraft:red_concrete
fill 376 234 624 376 239 625 minecraft:black_concrete
fill 376 234 630 376 235 631 minecraft:red_concrete
fill 376 234 632 376 239 633 minecraft:black_concrete
setblock 376 234 634 minecraft:red_concrete
fill 376 234 642 376 235 643 minecraft:red_concrete
fill 376 234 644 376 239 645 minecraft:black_concrete
fill 377 234 605 379 234 605 minecraft:polished_blackstone
fill 377 234 607 377 234 609 minecraft:polished_blackstone
fill 377 234 611 377 234 613 minecraft:polished_blackstone
fill 377 234 615 377 234 617 minecraft:polished_blackstone
fill 377 234 619 377 234 621 minecraft:polished_blackstone
fill 377 234 623 377 234 625 minecraft:polished_blackstone
fill 377 234 627 377 234 629 minecraft:polished_blackstone
fill 377 234 631 377 234 633 minecraft:polished_blackstone
fill 377 234 635 377 234 637 minecraft:polished_blackstone
fill 377 234 639 377 234 641 minecraft:polished_blackstone
fill 377 234 643 377 234 645 minecraft:polished_blackstone
setblock 379 234 607 minecraft:light[level=12]
setblock 379 234 615 minecraft:light[level=12]
setblock 379 234 623 minecraft:light[level=12]
setblock 379 234 631 minecraft:light[level=12]
setblock 379 234 639 minecraft:light[level=12]
fill 379 234 645 381 234 645 minecraft:polished_blackstone
fill 381 234 605 383 234 605 minecraft:polished_blackstone
fill 381 234 646 381 235 646 minecraft:red_concrete
setblock 382 234 604 minecraft:red_concrete
fill 383 234 604 384 239 604 minecraft:black_concrete
fill 383 234 645 385 234 645 minecraft:polished_blackstone
fill 383 234 646 383 239 646 minecraft:black_concrete
fill 384 234 646 385 234 646 minecraft:red_concrete
fill 385 234 604 386 235 604 minecraft:red_concrete
fill 385 234 605 387 234 605 minecraft:polished_blackstone
fill 386 234 646 386 239 646 minecraft:black_concrete
setblock 387 234 607 minecraft:light[level=12]
setblock 387 234 615 minecraft:light[level=12]
setblock 387 234 623 minecraft:light[level=12]
setblock 387 234 631 minecraft:light[level=12]
setblock 387 234 639 minecraft:light[level=12]
fill 387 234 645 389 234 645 minecraft:polished_blackstone
fill 389 234 605 391 234 605 minecraft:polished_blackstone
fill 391 234 604 392 239 604 minecraft:black_concrete
fill 391 234 645 393 234 645 minecraft:polished_blackstone
fill 392 234 646 393 235 646 minecraft:red_concrete
fill 393 234 604 394 234 604 minecraft:red_concrete
fill 393 234 605 395 234 605 minecraft:polished_blackstone
fill 394 234 646 395 239 646 minecraft:black_concrete
fill 395 234 604 395 239 604 minecraft:black_concrete
setblock 395 234 607 minecraft:light[level=12]
setblock 395 234 615 minecraft:light[level=12]
setblock 395 234 623 minecraft:light[level=12]
setblock 395 234 631 minecraft:light[level=12]
setblock 395 234 639 minecraft:light[level=12]
fill 395 234 645 397 234 645 minecraft:polished_blackstone
fill 397 234 605 399 234 605 minecraft:polished_blackstone
fill 399 234 639 400 235 639 minecraft:red_concrete
fill 399 234 645 401 234 645 minecraft:polished_blackstone
fill 401 234 605 403 234 605 minecraft:polished_blackstone
fill 403 234 604 404 239 604 minecraft:black_concrete
setblock 403 234 607 minecraft:light[level=12]
setblock 403 234 615 minecraft:light[level=12]
setblock 403 234 623 minecraft:light[level=12]
setblock 403 234 631 minecraft:light[level=12]
setblock 403 234 639 minecraft:light[level=12]
fill 403 234 645 405 234 645 minecraft:polished_blackstone
fill 403 234 646 403 235 646 minecraft:black_concrete
fill 404 234 646 405 234 646 minecraft:red_concrete
fill 405 234 604 406 235 604 minecraft:red_concrete
fill 405 234 605 407 234 605 minecraft:polished_blackstone
fill 406 234 646 407 239 646 minecraft:black_concrete
fill 407 234 645 409 234 645 minecraft:polished_blackstone
fill 409 234 605 411 234 605 minecraft:polished_blackstone
setblock 411 234 607 minecraft:light[level=12]
setblock 411 234 615 minecraft:light[level=12]
setblock 411 234 623 minecraft:light[level=12]
setblock 411 234 639 minecraft:light[level=12]
fill 411 234 645 413 234 645 minecraft:polished_blackstone
fill 412 234 604 412 239 604 minecraft:black_concrete
fill 412 234 646 413 235 646 minecraft:red_concrete
fill 413 234 605 415 234 605 minecraft:polished_blackstone
setblock 414 234 604 minecraft:red_concrete
fill 414 234 646 415 239 646 minecraft:black_concrete
fill 415 234 604 416 239 604 minecraft:black_concrete
fill 415 234 645 417 234 645 minecraft:polished_blackstone
setblock 416 234 646 minecraft:red_concrete
fill 417 234 604 417 235 604 minecraft:red_concrete
fill 417 234 605 417 234 607 minecraft:polished_blackstone
fill 417 234 609 417 234 611 minecraft:polished_blackstone
fill 417 234 613 417 234 615 minecraft:polished_blackstone
fill 417 234 617 417 234 619 minecraft:polished_blackstone
fill 417 234 621 417 234 623 minecraft:polished_blackstone
fill 417 234 625 417 234 627 minecraft:polished_blackstone
fill 417 234 629 417 234 631 minecraft:polished_blackstone
fill 417 234 633 417 234 635 minecraft:polished_blackstone
fill 417 234 637 417 234 639 minecraft:polished_blackstone
fill 417 234 641 417 234 643 minecraft:polished_blackstone
fill 418 234 609 418 239 610 minecraft:black_concrete
fill 418 234 611 418 234 612 minecraft:red_concrete
fill 418 234 621 418 239 622 minecraft:black_concrete
fill 418 234 623 418 235 624 minecraft:red_concrete
fill 418 234 630 418 239 630 minecraft:black_concrete
fill 418 234 631 418 234 632 minecraft:red_concrete
fill 418 234 633 418 239 633 minecraft:black_concrete
fill 418 234 635 418 235 635 minecraft:red_concrete
fill 418 234 641 418 239 642 minecraft:black_concrete
fill 418 234 643 418 235 644 minecraft:red_concrete
fill 418 234 646 418 236 646 minecraft:black_concrete
fill 376 235 618 376 235 619 minecraft:red_concrete
setblock 376 235 622 minecraft:red_concrete
fill 376 235 623 376 238 623 minecraft:black_concrete
fill 376 235 634 376 238 634 minecraft:black_concrete
setblock 376 235 639 minecraft:red_concrete
setblock 377 235 604 minecraft:red_concrete
setblock 380 235 646 minecraft:red_concrete
fill 382 235 604 382 238 604 minecraft:black_concrete
fill 384 235 646 385 237 646 minecraft:black_concrete
fill 393 235 604 393 238 604 minecraft:black_concrete
setblock 394 235 604 minecraft:red_concrete
fill 397 235 604 398 235 604 minecraft:red_concrete
fill 400 235 646 401 235 646 minecraft:red_concrete
setblock 404 235 646 minecraft:red_concrete
fill 405 235 646 405 238 646 minecraft:black_concrete
fill 414 235 604 414 238 604 minecraft:black_concrete
fill 416 235 646 416 238 646 minecraft:black_concrete
setblock 418 235 604 minecraft:red_concrete
fill 418 235 611 418 238 611 minecraft:black_concrete
setblock 418 235 612 minecraft:red_concrete
setblock 418 235 615 minecraft:red_concrete
fill 418 235 631 418 238 632 minecraft:black_concrete
setblock 418 235 636 minecraft:red_concrete
fill 376 236 608 376 236 609 minecraft:red_concrete
fill 376 236 610 376 253 611 minecraft:black_concrete
fill 376 236 617 376 237 617 minecraft:red_concrete
fill 376 236 618 376 250 619 minecraft:black_concrete
setblock 376 236 620 minecraft:red_concrete
fill 376 236 622 376 253 622 minecraft:black_concrete
fill 376 236 628 376 237 629 minecraft:red_concrete
fill 376 236 630 376 253 631 minecraft:black_concrete
fill 376 236 639 376 250 639 minecraft:black_concrete
fill 376 236 640 376 236 641 minecraft:red_concrete
fill 376 236 642 376 253 643 minecraft:black_concrete
fill 377 236 604 377 250 604 minecraft:black_concrete
fill 378 236 646 379 237 646 minecraft:red_concrete
fill 380 236 646 381 250 646 minecraft:black_concrete
setblock 382 236 646 minecraft:red_concrete
fill 385 236 604 386 254 604 minecraft:black_concrete
fill 387 236 604 388 237 604 minecraft:red_concrete
fill 390 236 646 391 237 646 minecraft:red_concrete
fill 392 236 646 393 253 646 minecraft:black_concrete
fill 394 236 604 394 253 604 minecraft:black_concrete
setblock 396 236 604 minecraft:red_concrete
fill 397 236 604 398 250 604 minecraft:black_concrete
fill 399 236 604 399 237 604 minecraft:red_concrete
fill 399 236 646 399 237 646 minecraft:red_concrete
fill 400 236 646 401 237 646 minecraft:black_concrete
fill 402 236 646 403 236 646 minecraft:red_concrete
fill 403 236 638 404 237 639 minecraft:magma_block
fill 404 236 646 404 253 646 minecraft:black_concrete
fill 405 236 604 406 253 604 minecraft:black_concrete
fill 407 236 604 408 236 604 minecraft:red_concrete
fill 410 236 646 411 237 646 minecraft:red_concrete
fill 412 236 646 413 254 646 minecraft:black_concrete
fill 417 236 604 418 250 604 minecraft:black_concrete
fill 418 236 605 418 237 606 minecraft:red_concrete
fill 418 236 612 418 253 612 minecraft:black_concrete
fill 418 236 613 418 236 614 minecraft:red_concrete
fill 418 236 615 418 250 615 minecraft:black_concrete
fill 418 236 617 418 237 617 minecraft:red_concrete
fill 418 236 623 418 253 624 minecraft:black_concrete
fill 418 236 625 418 237 626 minecraft:red_concrete
setblock 418 236 634 minecraft:red_concrete
fill 418 236 635 418 250 636 minecraft:black_concrete
fill 418 236 637 418 237 638 minecraft:red_concrete
fill 418 236 643 418 253 644 minecraft:black_concrete
setblock 418 236 645 minecraft:red_concrete
setblock 376 237 605 minecraft:red_concrete
fill 376 237 608 377 237 608 minecraft:red_concrete
fill 376 237 609 376 255 609 minecraft:black_concrete
setblock 376 237 616 minecraft:red_concrete
fill 376 237 620 376 255 620 minecraft:black_concrete
fill 376 237 636 376 237 637 minecraft:red_concrete
setblock 376 237 640 minecraft:red_concrete
fill 376 237 641 376 255 641 minecraft:black_concrete
setblock 377 237 609 minecraft:red_concrete
fill 378 237 607 379 237 607 minecraft:red_concrete
fill 378 237 610 379 237 610 minecraft:red_concrete
fill 379 237 604 380 237 604 minecraft:red_concrete
fill 380 237 608 380 237 609 minecraft:red_concrete
fill 382 237 646 382 239 646 minecraft:black_concrete
setblock 387 237 646 minecraft:red_concrete
fill 396 237 604 396 255 604 minecraft:black_concrete
setblock 398 237 646 minecraft:red_concrete
setblock 400 237 604 minecraft:red_concrete
fill 402 237 646 403 239 646 minecraft:black_concrete
fill 407 237 604 407 255 604 minecraft:black_concrete
setblock 408 237 604 minecraft:red_concrete
fill 409 237 630 409 237 633 minecraft:red_concrete
fill 410 237 630 412 238 630 minecraft:red_concrete
fill 410 237 633 412 238 633 minecraft:red_concrete
setblock 411 237 604 minecraft:red_concrete
setblock 411 237 629 minecraft:red_concrete
fill 412 237 631 413 237 632 minecraft:red_concrete
fill 418 237 613 418 255 614 minecraft:black_concrete
setblock 418 237 618 minecraft:red_concrete
setblock 418 237 629 minecraft:red_concrete
fill 418 237 634 418 255 634 minecraft:black_concrete
fill 418 237 645 418 255 645 minecraft:black_concrete
setblock 418 237 646 minecraft:red_concrete
fill 376 238 605 376 251 605 minecraft:black_concrete
fill 376 238 606 376 238 607 minecraft:red_concrete
fill 376 238 608 376 255 608 minecraft:black_concrete
fill 376 238 614 376 239 615 minecraft:red_concrete
fill 376 238 616 376 251 617 minecraft:black_concrete
fill 376 238 626 376 238 627 minecraft:red_concrete
fill 376 238 628 376 251 629 minecraft:black_concrete
fill 376 238 635 376 239 635 minecraft:red_concrete
fill 376 238 636 376 251 637 minecraft:black_concrete
setblock 376 238 638 minecraft:red_concrete
fill 376 238 640 376 255 640 minecraft:black_concrete
fill 376 238 646 377 239 646 minecraft:red_concrete
setblock 378 238 604 minecraft:red_concrete
fill 378 238 646 379 251 646 minecraft:black_concrete
fill 379 238 604 380 251 604 minecraft:black_concrete
setblock 380 238 609 minecraft:red_concrete
fill 381 238 604 381 239 604 minecraft:red_concrete
setblock 384 238 646 minecraft:black_concrete
fill 385 238 646 385 239 646 minecraft:red_concrete
fill 387 238 604 388 251 604 minecraft:black_concrete
fill 387 238 646 387 251 646 minecraft:black_concrete
fill 388 238 646 389 238 646 minecraft:red_concrete
fill 389 238 604 390 238 604 minecraft:red_concrete
fill 390 238 646 391 255 646 minecraft:black_concrete
fill 396 238 646 397 239 646 minecraft:red_concrete
fill 398 238 646 399 251 646 minecraft:black_concrete
fill 399 238 604 400 251 604 minecraft:black_concrete
setblock 400 238 646 minecraft:red_concrete
fill 401 238 604 402 239 604 minecraft:red_concrete
fill 401 238 646 401 250 646 minecraft:black_concrete
fill 408 238 604 408 255 604 minecraft:black_concrete
fill 408 238 646 409 239 646 minecraft:red_concrete
fill 409 238 604 410 238 604 minecraft:red_concrete
fill 409 238 631 409 238 632 minecraft:red_concrete
fill 410 238 646 411 251 646 minecraft:black_concrete
fill 411 238 604 411 251 604 minecraft:black_concrete
fill 412 238 631 412 239 632 minecraft:red_concrete
fill 413 238 604 413 239 604 minecraft:red_concrete
fill 417 238 646 417 239 646 minecraft:red_concrete
fill 418 238 605 418 251 606 minecraft:black_concrete
fill 418 238 607 418 239 608 minecraft:red_concrete
setblock 418 238 616 minecraft:red_concrete
fill 418 238 617 418 251 618 minecraft:black_concrete
fill 418 238 619 418 239 620 minecraft:red_concrete
fill 418 238 625 418 255 626 minecraft:black_concrete
fill 418 238 627 418 238 628 minecraft:red_concrete
fill 418 238 629 418 251 629 minecraft:black_concrete
fill 418 238 637 418 251 638 minecraft:black_concrete
fill 418 238 639 418 239 640 minecraft:red_concrete
fill 418 238 646 418 251 646 minecraft:black_concrete
fill 376 239 606 376 250 607 minecraft:black_concrete
setblock 376 239 623 minecraft:red_concrete
setblock 376 239 626 minecraft:red_concrete
fill 376 239 627 376 250 627 minecraft:black_concrete
setblock 376 239 634 minecraft:red_concrete
fill 376 239 638 376 250 638 minecraft:black_concrete
fill 378 239 604 378 250 604 minecraft:black_concrete
setblock 382 239 604 minecraft:red_concrete
setblock 384 239 646 minecraft:red_concrete
setblock 388 239 646 minecraft:red_concrete
fill 389 239 604 389 250 604 minecraft:black_concrete
fill 389 239 646 389 250 646 minecraft:black_concrete
setblock 390 239 604 minecraft:red_concrete
setblock 393 239 604 minecraft:red_concrete
fill 400 239 646 400 250 646 minecraft:black_concrete
setblock 405 239 646 minecraft:red_concrete
fill 409 239 604 410 250 604 minecraft:black_concrete
fill 410 239 630 411 239 630 minecraft:red_concrete
setblock 411 239 633 minecraft:red_concrete
setblock 414 239 604 minecraft:red_concrete
setblock 416 239 646 minecraft:red_concrete
setblock 418 239 611 minecraft:red_concrete
fill 418 239 616 418 250 616 minecraft:black_concrete
fill 418 239 627 418 250 627 minecraft:black_concrete
setblock 418 239 628 minecraft:red_concrete
fill 418 239 631 418 239 632 minecraft:red_concrete
setblock 376 240 604 minecraft:red_concrete
fill 376 240 612 376 240 613 minecraft:red_concrete
fill 376 240 614 376 250 615 minecraft:black_concrete
setblock 376 240 621 minecraft:red_concrete
fill 376 240 623 376 253 623 minecraft:black_concrete
fill 376 240 624 376 240 625 minecraft:red_concrete
fill 376 240 626 376 250 626 minecraft:black_concrete
fill 376 240 632 376 240 633 minecraft:red_concrete
fill 376 240 634 376 253 635 minecraft:black_concrete
fill 376 240 644 376 240 645 minecraft:red_concrete
fill 376 240 646 377 250 646 minecraft:black_concrete
fill 377 240 605 379 240 605 minecraft:polished_blackstone
fill 377 240 607 377 240 609 minecraft:polished_blackstone
fill 377 240 611 377 240 613 minecraft:polished_blackstone
fill 377 240 615 377 240 617 minecraft:polished_blackstone
fill 377 240 619 377 240 621 minecraft:polished_blackstone
fill 377 240 623 377 240 625 minecraft:polished_blackstone
fill 377 240 627 377 240 629 minecraft:polished_blackstone
fill 377 240 631 377 240 633 minecraft:polished_blackstone
fill 377 240 635 377 240 637 minecraft:polished_blackstone
fill 377 240 639 377 240 641 minecraft:polished_blackstone
fill 377 240 643 377 240 645 minecraft:polished_blackstone
fill 379 240 645 381 240 645 minecraft:polished_blackstone
fill 381 240 604 382 253 604 minecraft:black_concrete
fill 381 240 605 383 240 605 minecraft:polished_blackstone
fill 382 240 646 383 240 646 minecraft:red_concrete
fill 383 240 604 384 240 604 minecraft:red_concrete
fill 383 240 645 385 240 645 minecraft:polished_blackstone
fill 384 240 646 385 253 646 minecraft:black_concrete
fill 385 240 605 387 240 605 minecraft:polished_blackstone
setblock 386 240 646 minecraft:red_concrete
fill 387 240 645 389 240 645 minecraft:polished_blackstone
fill 388 240 646 388 250 646 minecraft:black_concrete
fill 389 240 605 391 240 605 minecraft:polished_blackstone
fill 390 240 604 390 250 604 minecraft:black_concrete
fill 391 240 604 392 240 604 minecraft:red_concrete
fill 391 240 645 393 240 645 minecraft:polished_blackstone
fill 393 240 604 393 253 604 minecraft:black_concrete
fill 393 240 605 395 240 605 minecraft:polished_blackstone
fill 394 240 646 395 240 646 minecraft:red_concrete
setblock 395 240 604 minecraft:red_concrete
fill 395 240 645 397 240 645 minecraft:polished_blackstone
fill 396 240 646 397 250 646 minecraft:black_concrete
fill 397 240 605 399 240 605 minecraft:polished_blackstone
fill 399 240 645 401 240 645 minecraft:polished_blackstone
fill 401 240 604 402 250 604 minecraft:black_concrete
fill 401 240 605 403 240 605 minecraft:polished_blackstone
fill 402 240 646 402 255 646 minecraft:black_concrete
fill 403 240 604 404 240 604 minecraft:red_concrete
fill 403 240 645 405 240 645 minecraft:polished_blackstone
setblock 403 240 646 minecraft:red_concrete
fill 405 240 605 407 240 605 minecraft:polished_blackstone
fill 405 240 646 405 253 646 minecraft:black_concrete
fill 406 240 646 407 240 646 minecraft:red_concrete
fill 407 240 645 409 240 645 minecraft:polished_blackstone
fill 408 240 646 409 250 646 minecraft:black_concrete
fill 409 240 605 411 240 605 minecraft:polished_blackstone
fill 411 240 645 413 240 645 minecraft:polished_blackstone
setblock 412 240 604 minecraft:red_concrete
fill 413 240 604 414 253 604 minecraft:black_concrete
fill 413 240 605 415 240 605 minecraft:polished_blackstone
fill 414 240 646 415 240 646 minecraft:red_concrete
fill 415 240 604 416 240 604 minecraft:red_concrete
fill 415 240 645 417 240 645 minecraft:polished_blackstone
fill 416 240 646 417 253 646 minecraft:black_concrete
fill 417 240 605 417 240 607 minecraft:polished_blackstone
fill 417 240 609 417 240 611 minecraft:polished_blackstone
fill 417 240 613 417 240 615 minecraft:polished_blackstone
fill 417 240 617 417 240 619 minecraft:polished_blackstone
fill 417 240 621 417 240 623 minecraft:polished_blackstone
fill 417 240 625 417 240 627 minecraft:polished_blackstone
fill 417 240 629 417 240 631 minecraft:polished_blackstone
fill 417 240 633 417 240 635 minecraft:polished_blackstone
fill 417 240 637 417 240 639 minecraft:polished_blackstone
fill 417 240 641 417 240 643 minecraft:polished_blackstone
fill 418 240 607 418 250 608 minecraft:black_concrete
fill 418 240 609 418 240 610 minecraft:red_concrete
fill 418 240 611 418 253 611 minecraft:black_concrete
fill 418 240 619 418 253 620 minecraft:black_concrete
fill 418 240 621 418 240 622 minecraft:red_concrete
fill 418 240 628 418 250 628 minecraft:black_concrete
setblock 418 240 630 minecraft:red_concrete
fill 418 240 631 418 253 632 minecraft:black_concrete
setblock 418 240 633 minecraft:red_concrete
fill 418 240 639 418 250 640 minecraft:black_concrete
fill 418 240 641 418 240 642 minecraft:red_concrete
fill 376 241 604 376 251 604 minecraft:black_concrete
fill 376 241 612 376 252 613 minecraft:black_concrete
fill 376 241 621 376 255 621 minecraft:black_concrete
fill 376 241 624 376 251 625 minecraft:black_concrete
fill 376 241 632 376 252 633 minecraft:black_concrete
fill 376 241 644 376 251 645 minecraft:black_concrete
fill 382 241 646 383 255 646 minecraft:black_concrete
fill 383 241 604 384 252 604 minecraft:black_concrete
fill 386 241 646 386 251 646 minecraft:black_concrete
fill 391 241 604 392 251 604 minecraft:black_concrete
fill 394 241 646 395 252 646 minecraft:black_concrete
fill 395 241 604 395 255 604 minecraft:black_concrete
fill 403 241 604 404 252 604 minecraft:black_concrete
fill 403 241 646 403 255 646 minecraft:black_concrete
fill 406 241 646 407 251 646 minecraft:black_concrete
fill 412 241 604 412 251 604 minecraft:black_concrete
fill 414 241 646 415 252 646 minecraft:black_concrete
fill 415 241 604 416 255 604 minecraft:black_concrete
fill 418 241 609 418 251 610 minecraft:black_concrete
fill 418 241 621 418 252 622 minecraft:black_concrete
fill 418 241 630 418 251 630 minecraft:black_concrete
fill 418 241 633 418 255 633 minecraft:black_concrete
fill 418 241 641 418 251 642 minecraft:black_concrete
setblock 379 242 607 minecraft:light[level=12]
setblock 379 242 615 minecraft:light[level=12]
setblock 379 242 623 minecraft:light[level=12]
setblock 379 242 631 minecraft:light[level=12]
setblock 379 242 639 minecraft:light[level=12]
setblock 387 242 607 minecraft:light[level=12]
setblock 387 242 615 minecraft:light[level=12]
setblock 387 242 623 minecraft:light[level=12]
setblock 387 242 631 minecraft:light[level=12]
setblock 387 242 639 minecraft:light[level=12]
setblock 395 242 607 minecraft:light[level=12]
setblock 395 242 615 minecraft:light[level=12]
setblock 395 242 623 minecraft:light[level=12]
setblock 395 242 631 minecraft:light[level=12]
setblock 395 242 639 minecraft:light[level=12]
setblock 403 242 607 minecraft:light[level=12]
setblock 403 242 615 minecraft:light[level=12]
setblock 403 242 623 minecraft:light[level=12]
setblock 403 242 631 minecraft:light[level=12]
setblock 403 242 639 minecraft:light[level=12]
setblock 411 242 607 minecraft:light[level=12]
setblock 411 242 615 minecraft:light[level=12]
setblock 411 242 623 minecraft:light[level=12]
setblock 411 242 631 minecraft:light[level=12]
setblock 411 242 639 minecraft:light[level=12]
fill 391 245 623 393 245 625 minecraft:redstone_block
fill 396 245 618 398 245 620 minecraft:redstone_block
fill 396 245 628 398 245 630 minecraft:redstone_block
fill 401 245 623 403 245 625 minecraft:redstone_block
fill 386 246 623 386 248 625 minecraft:netherite_block
fill 387 246 620 387 248 623 minecraft:netherite_block
fill 387 246 624 388 247 624 minecraft:black_concrete
fill 387 246 625 387 248 628 minecraft:netherite_block
fill 388 246 618 388 248 619 minecraft:netherite_block
fill 388 246 620 388 247 621 minecraft:black_concrete
fill 388 246 622 388 247 622 minecraft:red_concrete
fill 388 246 623 389 247 623 minecraft:black_concrete
fill 388 246 625 388 247 625 minecraft:red_concrete
fill 388 246 626 388 247 627 minecraft:black_concrete
fill 388 246 628 388 247 628 minecraft:red_concrete
fill 388 246 629 388 248 630 minecraft:netherite_block
fill 389 246 617 389 248 617 minecraft:netherite_block
fill 389 246 618 389 247 618 minecraft:red_concrete
fill 389 246 619 389 247 620 minecraft:black_concrete
fill 389 246 621 389 247 621 minecraft:red_concrete
fill 389 246 622 390 246 622 minecraft:black_concrete
fill 389 246 624 389 247 624 minecraft:red_concrete
fill 389 246 625 389 247 626 minecraft:black_concrete
fill 389 246 627 389 247 627 minecraft:red_concrete
fill 389 246 628 389 247 629 minecraft:black_concrete
fill 389 246 630 389 247 630 minecraft:red_concrete
fill 389 246 631 389 248 631 minecraft:netherite_block
fill 390 246 616 390 248 616 minecraft:netherite_block
fill 390 246 617 390 247 617 minecraft:red_concrete
fill 390 246 618 390 247 619 minecraft:black_concrete
fill 390 246 620 390 247 620 minecraft:red_concrete
fill 390 246 621 391 247 621 minecraft:black_concrete
setblock 390 246 623 minecraft:red_concrete
fill 390 246 624 390 246 625 minecraft:black_concrete
setblock 390 246 626 minecraft:red_concrete
fill 390 246 627 390 247 628 minecraft:black_concrete
fill 390 246 629 390 247 629 minecraft:red_concrete
fill 390 246 630 390 247 631 minecraft:black_concrete
fill 390 246 632 390 248 632 minecraft:netherite_block
fill 391 246 615 392 248 615 minecraft:netherite_block
fill 391 246 616 391 247 616 minecraft:red_concrete
fill 391 246 617 391 247 618 minecraft:black_concrete
fill 391 246 619 391 247 619 minecraft:red_concrete
fill 391 246 620 392 247 620 minecraft:black_concrete
setblock 391 246 622 minecraft:red_concrete
fill 391 246 626 391 246 627 minecraft:black_concrete
fill 391 246 628 391 247 628 minecraft:red_concrete
fill 391 246 629 391 247 630 minecraft:black_concrete
fill 391 246 631 391 247 631 minecraft:red_concrete
fill 391 246 632 392 247 632 minecraft:black_concrete
fill 391 246 633 392 248 633 minecraft:netherite_block
fill 392 246 616 392 247 617 minecraft:black_concrete
fill 392 246 618 392 247 618 minecraft:red_concrete
fill 392 246 619 393 247 619 minecraft:black_concrete
fill 392 246 621 392 247 621 minecraft:red_concrete
fill 392 246 622 393 246 622 minecraft:black_concrete
setblock 392 246 626 minecraft:black_concrete
fill 392 246 627 392 247 627 minecraft:red_concrete
fill 392 246 628 392 247 629 minecraft:black_concrete
fill 392 246 630 392 247 630 minecraft:red_concrete
fill 392 246 631 393 247 631 minecraft:black_concrete
fill 393 246 614 396 248 614 minecraft:netherite_block
fill 393 246 615 393 247 616 minecraft:black_concrete
fill 393 246 617 393 247 617 minecraft:red_concrete
fill 393 246 618 394 247 618 minecraft:black_concrete
fill 393 246 620 393 247 620 minecraft:red_concrete
fill 393 246 621 394 247 621 minecraft:black_concrete
setblock 393 246 626 minecraft:red_concrete
fill 393 246 627 393 247 628 minecraft:black_concrete
fill 393 246 629 393 247 629 minecraft:red_concrete
fill 393 246 630 394 247 630 minecraft:black_concrete
fill 393 246 632 393 247 632 minecraft:red_concrete
fill 393 246 633 394 247 633 minecraft:black_concrete
fill 393 246 634 396 248 634 minecraft:netherite_block
fill 394 246 615 394 247 615 minecraft:black_concrete
fill 394 246 616 394 247 616 minecraft:red_concrete
fill 394 246 617 395 246 617 minecraft:black_concrete
fill 394 246 619 394 247 619 minecraft:red_concrete
fill 394 246 620 395 246 620 minecraft:black_concrete
setblock 394 246 622 minecraft:red_concrete
fill 394 246 623 394 246 624 minecraft:black_concrete
setblock 394 246 625 minecraft:red_concrete
fill 394 246 626 394 246 627 minecraft:black_concrete
fill 394 246 628 394 247 628 minecraft:red_concrete
fill 394 246 629 395 246 629 minecraft:black_concrete
fill 394 246 631 394 247 631 minecraft:red_concrete
fill 394 246 632 395 247 632 minecraft:black_concrete
fill 395 246 615 395 247 615 minecraft:red_concrete
fill 395 246 616 396 247 616 minecraft:black_concrete
setblock 395 246 618 minecraft:red_concrete
setblock 395 246 619 minecraft:black_concrete
setblock 395 246 621 minecraft:red_concrete
fill 395 246 622 395 246 623 minecraft:black_concrete
setblock 395 246 624 minecraft:red_concrete
fill 395 246 625 395 246 626 minecraft:black_concrete
setblock 395 246 627 minecraft:red_concrete
setblock 395 246 628 minecraft:black_concrete
setblock 395 246 630 minecraft:red_concrete
fill 395 246 631 396 246 631 minecraft:black_concrete
fill 395 246 633 395 247 633 minecraft:red_concrete
fill 396 246 613 398 248 613 minecraft:netherite_block
fill 396 246 615 397 247 615 minecraft:black_concrete
setblock 396 246 617 minecraft:red_concrete
fill 396 246 621 396 246 622 minecraft:black_concrete
setblock 396 246 626 minecraft:red_concrete
fill 396 246 627 397 246 627 minecraft:black_concrete
fill 396 246 632 396 247 632 minecraft:red_concrete
fill 396 246 633 397 247 633 minecraft:black_concrete
fill 396 246 635 398 248 635 minecraft:netherite_block
fill 397 246 614 397 247 614 minecraft:black_concrete
fill 397 246 616 397 247 616 minecraft:red_concrete
fill 397 246 617 398 246 617 minecraft:black_concrete
setblock 397 246 621 minecraft:black_concrete
setblock 397 246 622 minecraft:red_concrete
fill 397 246 626 398 246 626 minecraft:black_concrete
setblock 397 246 631 minecraft:red_concrete
fill 397 246 632 398 247 632 minecraft:black_concrete
fill 397 246 634 397 247 634 minecraft:red_concrete
fill 398 246 614 401 248 614 minecraft:netherite_block
fill 398 246 615 398 247 615 minecraft:red_concrete
fill 398 246 616 399 247 616 minecraft:black_concrete
setblock 398 246 621 minecraft:red_concrete
fill 398 246 622 399 246 622 minecraft:black_concrete
setblock 398 246 627 minecraft:red_concrete
fill 398 246 631 399 246 631 minecraft:black_concrete
fill 398 246 633 398 247 633 minecraft:red_concrete
fill 398 246 634 401 248 634 minecraft:netherite_block
fill 399 246 615 400 247 615 minecraft:black_concrete
setblock 399 246 617 minecraft:red_concrete
fill 399 246 618 399 246 619 minecraft:black_concrete
setblock 399 246 620 minecraft:red_concrete
fill 399 246 621 400 246 621 minecraft:black_concrete
setblock 399 246 623 minecraft:red_concrete
fill 399 246 624 399 246 625 minecraft:black_concrete
setblock 399 246 626 minecraft:red_concrete
fill 399 246 627 399 246 628 minecraft:black_concrete
setblock 399 246 629 minecraft:red_concrete
fill 399 246 630 400 246 630 minecraft:black_concrete
fill 399 246 632 399 247 632 minecraft:red_concrete
fill 399 246 633 400 247 633 minecraft:black_concrete
fill 400 246 616 400 247 616 minecraft:red_concrete
fill 400 246 617 400 247 618 minecraft:black_concrete
fill 400 246 619 400 247 619 minecraft:red_concrete
fill 400 246 620 401 247 620 minecraft:black_concrete
setblock 400 246 622 minecraft:red_concrete
fill 400 246 623 400 246 624 minecraft:black_concrete
setblock 400 246 625 minecraft:red_concrete
fill 400 246 626 400 246 627 minecraft:black_concrete
fill 400 246 628 400 247 628 minecraft:red_concrete
fill 400 246 629 401 247 629 minecraft:black_concrete
fill 400 246 631 400 247 631 minecraft:red_concrete
fill 400 246 632 401 247 632 minecraft:black_concrete
fill 401 246 615 401 247 615 minecraft:red_concrete
fill 401 246 616 401 247 617 minecraft:black_concrete
fill 401 246 618 401 247 618 minecraft:red_concrete
fill 401 246 619 402 247 619 minecraft:black_concrete
fill 401 246 621 401 247 621 minecraft:red_concrete
fill 401 246 622 402 246 622 minecraft:black_concrete
setblock 401 246 626 minecraft:black_concrete
fill 401 246 627 401 247 627 minecraft:red_concrete
fill 401 246 628 402 247 628 minecraft:black_concrete
fill 401 246 630 401 247 630 minecraft:red_concrete
fill 401 246 631 402 247 631 minecraft:black_concrete
fill 401 246 633 401 247 633 minecraft:red_concrete
fill 402 246 615 403 248 615 minecraft:netherite_block
fill 402 246 616 402 247 616 minecraft:black_concrete
fill 402 246 617 402 247 617 minecraft:red_concrete
fill 402 246 618 403 247 618 minecraft:black_concrete
fill 402 246 620 402 247 620 minecraft:red_concrete
fill 402 246 621 403 247 621 minecraft:black_concrete
setblock 402 246 626 minecraft:red_concrete
fill 402 246 627 403 247 627 minecraft:black_concrete
fill 402 246 629 402 247 629 minecraft:red_concrete
fill 402 246 630 403 247 630 minecraft:black_concrete
fill 402 246 632 402 247 632 minecraft:red_concrete
fill 402 246 633 403 248 633 minecraft:netherite_block
fill 403 246 616 403 247 616 minecraft:red_concrete
fill 403 246 617 404 247 617 minecraft:black_concrete
fill 403 246 619 403 247 619 minecraft:red_concrete
fill 403 246 620 404 247 620 minecraft:black_concrete
setblock 403 246 622 minecraft:red_concrete
fill 403 246 626 404 246 626 minecraft:black_concrete
fill 403 246 628 403 247 628 minecraft:red_concrete
fill 403 246 629 404 247 629 minecraft:black_concrete
fill 403 246 631 403 247 631 minecraft:red_concrete
fill 403 246 632 403 247 632 minecraft:black_concrete
fill 404 246 616 404 248 616 minecraft:netherite_block
fill 404 246 618 404 247 618 minecraft:red_concrete
fill 404 246 619 405 247 619 minecraft:black_concrete
fill 404 246 621 404 247 621 minecraft:red_concrete
fill 404 246 622 404 246 623 minecraft:black_concrete
setblock 404 246 624 minecraft:red_concrete
fill 404 246 625 405 246 625 minecraft:black_concrete
fill 404 246 627 404 247 627 minecraft:red_concrete
fill 404 246 628 405 247 628 minecraft:black_concrete
fill 404 246 630 404 247 630 minecraft:red_concrete
fill 404 246 631 404 247 631 minecraft:black_concrete
fill 404 246 632 404 248 632 minecraft:netherite_block
fill 405 246 617 405 248 617 minecraft:netherite_block
fill 405 246 618 405 247 618 minecraft:black_concrete
fill 405 246 620 405 247 620 minecraft:red_concrete
fill 405 246 621 405 247 622 minecraft:black_concrete
fill 405 246 623 405 247 623 minecraft:red_concrete
fill 405 246 624 406 247 624 minecraft:black_concrete
fill 405 246 626 405 247 626 minecraft:red_concrete
fill 405 246 627 406 247 627 minecraft:black_concrete
fill 405 246 629 405 247 629 minecraft:red_concrete
fill 405 246 630 405 247 630 minecraft:black_concrete
fill 405 246 631 405 248 631 minecraft:netherite_block
fill 406 246 618 406 248 619 minecraft:netherite_block
fill 406 246 620 406 247 621 minecraft:black_concrete
fill 406 246 622 406 247 622 minecraft:red_concrete
fill 406 246 623 406 247 623 minecraft:black_concrete
fill 406 246 625 406 247 625 minecraft:red_concrete
fill 406 246 626 406 247 626 minecraft:black_concrete
fill 406 246 628 406 247 628 minecraft:red_concrete
fill 406 246 629 406 248 630 minecraft:netherite_block
fill 407 246 620 407 248 623 minecraft:netherite_block
fill 407 246 624 407 247 624 minecraft:red_concrete
fill 407 246 625 407 248 628 minecraft:netherite_block
fill 408 246 623 408 248 625 minecraft:netherite_block
fill 377 247 605 385 247 645 minecraft:black_concrete
fill 386 247 605 386 247 620 minecraft:black_concrete
fill 386 247 621 386 247 622 minecraft:netherite_block
fill 386 247 626 386 247 627 minecraft:netherite_block
fill 386 247 628 386 247 645 minecraft:black_concrete
fill 387 247 605 387 247 618 minecraft:black_concrete
setblock 387 247 619 minecraft:netherite_block
setblock 387 247 629 minecraft:netherite_block
fill 387 247 630 387 247 645 minecraft:black_concrete
fill 388 247 605 388 247 616 minecraft:black_concrete
setblock 388 247 617 minecraft:netherite_block
setblock 388 247 631 minecraft:netherite_block
fill 388 247 632 388 247 645 minecraft:black_concrete
fill 389 247 605 389 247 615 minecraft:black_concrete
setblock 389 247 616 minecraft:netherite_block
setblock 389 247 622 minecraft:black_concrete
setblock 389 247 632 minecraft:netherite_block
fill 389 247 633 389 247 645 minecraft:black_concrete
fill 390 247 605 391 247 614 minecraft:black_concrete
setblock 390 247 615 minecraft:netherite_block
fill 390 247 622 390 247 626 minecraft:shroomlight
setblock 390 247 633 minecraft:netherite_block
fill 390 247 634 391 247 645 minecraft:black_concrete
fill 391 247 622 404 247 622 minecraft:shroomlight
fill 391 247 623 393 247 625 minecraft:black_concrete
fill 391 247 626 404 247 626 minecraft:shroomlight
setblock 391 247 627 minecraft:black_concrete
fill 392 247 605 393 247 613 minecraft:black_concrete
setblock 392 247 614 minecraft:netherite_block
setblock 392 247 634 minecraft:netherite_block
fill 392 247 635 393 247 645 minecraft:black_concrete
fill 394 247 605 417 247 612 minecraft:black_concrete
fill 394 247 613 395 247 613 minecraft:netherite_block
setblock 394 247 617 minecraft:black_concrete
setblock 394 247 620 minecraft:black_concrete
fill 394 247 623 395 247 625 minecraft:shroomlight
setblock 394 247 627 minecraft:black_concrete
setblock 394 247 629 minecraft:black_concrete
fill 394 247 635 395 247 635 minecraft:netherite_block
fill 394 247 636 417 247 645 minecraft:black_concrete
fill 395 247 617 395 247 621 minecraft:shroomlight
fill 395 247 627 395 247 631 minecraft:shroomlight
fill 396 247 617 399 247 617 minecraft:shroomlight
fill 396 247 618 398 247 620 minecraft:black_concrete
fill 396 247 621 399 247 621 minecraft:shroomlight
fill 396 247 627 399 247 627 minecraft:shroomlight
fill 396 247 628 398 247 630 minecraft:black_concrete
fill 396 247 631 399 247 631 minecraft:shroomlight
fill 399 247 613 400 247 613 minecraft:netherite_block
fill 399 247 618 399 247 620 minecraft:shroomlight
fill 399 247 623 400 247 625 minecraft:shroomlight
fill 399 247 628 399 247 630 minecraft:shroomlight
fill 399 247 635 400 247 635 minecraft:netherite_block
setblock 400 247 621 minecraft:black_concrete
setblock 400 247 627 minecraft:black_concrete
setblock 400 247 630 minecraft:black_concrete
fill 401 247 613 417 247 613 minecraft:black_concrete
fill 401 247 623 403 247 625 minecraft:black_concrete
fill 401 247 635 417 247 635 minecraft:black_concrete
setblock 402 247 614 minecraft:netherite_block
setblock 402 247 634 minecraft:netherite_block
fill 403 247 614 417 247 614 minecraft:black_concrete
fill 403 247 634 417 247 634 minecraft:black_concrete
setblock 404 247 615 minecraft:netherite_block
fill 404 247 623 404 247 625 minecraft:shroomlight
setblock 404 247 633 minecraft:netherite_block
fill 405 247 615 417 247 615 minecraft:black_concrete
setblock 405 247 616 minecraft:netherite_block
setblock 405 247 625 minecraft:black_concrete
setblock 405 247 632 minecraft:netherite_block
fill 405 247 633 417 247 633 minecraft:black_concrete
fill 406 247 616 417 247 616 minecraft:black_concrete
setblock 406 247 617 minecraft:netherite_block
setblock 406 247 631 minecraft:netherite_block
fill 406 247 632 417 247 632 minecraft:black_concrete
fill 407 247 617 417 247 618 minecraft:black_concrete
setblock 407 247 619 minecraft:netherite_block
setblock 407 247 629 minecraft:netherite_block
fill 407 247 630 417 247 631 minecraft:black_concrete
fill 408 247 619 417 247 620 minecraft:black_concrete
fill 408 247 621 408 247 622 minecraft:netherite_block
fill 408 247 626 408 247 627 minecraft:netherite_block
fill 408 247 628 417 247 629 minecraft:black_concrete
fill 409 247 621 417 247 627 minecraft:black_concrete
fill 387 248 624 388 248 624 minecraft:netherite_block
fill 388 248 620 388 248 623 minecraft:netherite_block
fill 388 248 625 388 248 628 minecraft:netherite_block
fill 389 248 618 389 248 620 minecraft:netherite_block
fill 389 248 628 389 248 630 minecraft:netherite_block
fill 390 248 617 390 248 618 minecraft:netherite_block
fill 390 248 630 390 248 631 minecraft:netherite_block
fill 391 248 616 391 248 617 minecraft:netherite_block
fill 391 248 631 391 248 632 minecraft:netherite_block
fill 392 248 616 393 248 616 minecraft:netherite_block
fill 392 248 632 393 248 632 minecraft:netherite_block
fill 393 248 615 401 248 615 minecraft:netherite_block
fill 393 248 633 401 248 633 minecraft:netherite_block
setblock 397 248 614 minecraft:netherite_block
setblock 397 248 634 minecraft:netherite_block
fill 401 248 616 403 248 616 minecraft:netherite_block
fill 401 248 632 403 248 632 minecraft:netherite_block
fill 403 248 617 404 248 617 minecraft:netherite_block
fill 403 248 631 404 248 631 minecraft:netherite_block
fill 404 248 618 405 248 618 minecraft:netherite_block
fill 404 248 630 405 248 630 minecraft:netherite_block
fill 405 248 619 405 248 620 minecraft:netherite_block
fill 405 248 628 405 248 629 minecraft:netherite_block
fill 406 248 620 406 248 628 minecraft:netherite_block
setblock 407 248 624 minecraft:netherite_block
setblock 379 250 607 minecraft:light[level=12]
setblock 379 250 615 minecraft:light[level=12]
setblock 379 250 623 minecraft:light[level=12]
setblock 379 250 631 minecraft:light[level=12]
setblock 379 250 639 minecraft:light[level=12]
setblock 387 250 607 minecraft:light[level=12]
setblock 387 250 615 minecraft:light[level=12]
setblock 387 250 623 minecraft:light[level=12]
setblock 387 250 631 minecraft:light[level=12]
setblock 387 250 639 minecraft:light[level=12]
setblock 395 250 607 minecraft:light[level=12]
setblock 395 250 615 minecraft:light[level=12]
setblock 395 250 623 minecraft:light[level=12]
setblock 395 250 631 minecraft:light[level=12]
setblock 395 250 639 minecraft:light[level=12]
setblock 403 250 607 minecraft:light[level=12]
setblock 403 250 615 minecraft:light[level=12]
setblock 403 250 623 minecraft:light[level=12]
setblock 403 250 631 minecraft:light[level=12]
setblock 403 250 639 minecraft:light[level=12]
setblock 411 250 607 minecraft:light[level=12]
setblock 411 250 615 minecraft:light[level=12]
setblock 411 250 623 minecraft:light[level=12]
setblock 411 250 631 minecraft:light[level=12]
setblock 411 250 639 minecraft:light[level=12]
fill 376 251 606 376 251 607 minecraft:red_concrete
fill 376 251 614 376 253 614 minecraft:black_concrete
setblock 376 251 615 minecraft:red_concrete
fill 376 251 618 376 251 619 minecraft:red_concrete
fill 376 251 626 376 251 627 minecraft:red_concrete
fill 376 251 638 376 251 639 minecraft:red_concrete
fill 376 251 646 377 251 646 minecraft:red_concrete
fill 377 251 604 378 251 604 minecraft:red_concrete
setblock 380 251 646 minecraft:red_concrete
fill 381 251 646 381 254 646 minecraft:black_concrete
fill 386 251 621 386 254 627 minecraft:iron_block
fill 386 251 638 388 251 638 minecraft:blackstone
fill 387 251 619 387 254 620 minecraft:iron_block
fill 387 251 628 387 254 629 minecraft:iron_block
setblock 387 251 637 minecraft:blackstone
setblock 387 251 639 minecraft:blackstone
fill 388 251 617 388 254 618 minecraft:iron_block
fill 388 251 630 388 254 631 minecraft:iron_block
fill 388 251 646 389 251 646 minecraft:red_concrete
fill 389 251 604 390 251 604 minecraft:red_concrete
fill 389 251 616 389 251 617 minecraft:iron_block
fill 389 251 631 389 251 632 minecraft:iron_block
fill 390 251 615 390 254 616 minecraft:iron_block
fill 390 251 632 390 254 633 minecraft:iron_block
fill 391 251 615 391 254 615 minecraft:iron_block
fill 391 251 633 391 254 633 minecraft:iron_block
fill 392 251 614 393 254 614 minecraft:iron_block
fill 392 251 634 393 254 634 minecraft:iron_block
fill 394 251 613 400 254 613 minecraft:iron_block
fill 394 251 635 400 254 635 minecraft:iron_block
fill 396 251 646 396 253 646 minecraft:black_concrete
fill 397 251 604 398 251 604 minecraft:red_concrete
setblock 397 251 646 minecraft:red_concrete
fill 398 251 614 398 251 615 minecraft:blackstone
fill 400 251 646 401 251 646 minecraft:red_concrete
setblock 401 251 604 minecraft:red_concrete
fill 401 251 614 402 254 614 minecraft:iron_block
fill 401 251 634 402 254 634 minecraft:iron_block
fill 402 251 604 402 253 604 minecraft:black_concrete
fill 403 251 615 404 254 615 minecraft:iron_block
fill 403 251 633 404 254 633 minecraft:iron_block
fill 404 251 616 405 251 616 minecraft:iron_block
fill 404 251 632 405 251 632 minecraft:iron_block
fill 405 251 617 406 254 617 minecraft:iron_block
fill 405 251 631 406 254 631 minecraft:iron_block
fill 406 251 618 406 254 618 minecraft:iron_block
fill 406 251 630 406 254 630 minecraft:iron_block
fill 407 251 619 407 254 620 minecraft:iron_block
fill 407 251 628 407 254 629 minecraft:iron_block
fill 408 251 621 408 254 627 minecraft:iron_block
fill 408 251 646 409 251 646 minecraft:red_concrete
fill 409 251 604 410 251 604 minecraft:red_concrete
setblock 412 251 617 minecraft:magma_block
fill 417 251 604 417 254 604 minecraft:black_concrete
setblock 418 251 604 minecraft:red_concrete
fill 418 251 607 418 251 608 minecraft:red_concrete
fill 418 251 615 418 251 616 minecraft:red_concrete
fill 418 251 627 418 251 628 minecraft:red_concrete
fill 418 251 635 418 254 635 minecraft:black_concrete
setblock 418 251 636 minecraft:red_concrete
setblock 418 251 639 minecraft:red_concrete
fill 418 251 640 418 253 640 minecraft:black_concrete
fill 376 252 604 376 253 605 minecraft:red_concrete
fill 376 252 606 376 257 607 minecraft:black_concrete
fill 376 252 615 376 257 615 minecraft:black_concrete
fill 376 252 616 376 252 617 minecraft:red_concrete
fill 376 252 618 376 257 619 minecraft:black_concrete
fill 376 252 624 376 253 625 minecraft:red_concrete
fill 376 252 626 376 257 627 minecraft:black_concrete
setblock 376 252 628 minecraft:red_concrete
fill 376 252 629 376 255 629 minecraft:black_concrete
fill 376 252 636 376 253 637 minecraft:red_concrete
fill 376 252 638 376 257 639 minecraft:black_concrete
setblock 376 252 644 minecraft:black_concrete
fill 376 252 645 376 253 645 minecraft:red_concrete
fill 376 252 646 377 253 646 minecraft:black_concrete
fill 377 252 604 378 257 604 minecraft:black_concrete
fill 377 252 605 379 252 605 minecraft:polished_blackstone
fill 377 252 607 377 252 609 minecraft:polished_blackstone
fill 377 252 611 377 252 613 minecraft:polished_blackstone
fill 377 252 615 377 252 617 minecraft:polished_blackstone
fill 377 252 619 377 252 621 minecraft:polished_blackstone
fill 377 252 623 377 252 625 minecraft:polished_blackstone
fill 377 252 627 377 252 629 minecraft:polished_blackstone
fill 377 252 631 377 252 633 minecraft:polished_blackstone
fill 377 252 635 377 252 637 minecraft:polished_blackstone
fill 377 252 639 377 252 641 minecraft:polished_blackstone
fill 377 252 643 377 252 645 minecraft:polished_blackstone
fill 378 252 646 379 252 646 minecraft:red_concrete
fill 379 252 604 380 253 604 minecraft:red_concrete
fill 379 252 645 381 252 645 minecraft:polished_blackstone
fill 380 252 646 380 257 646 minecraft:black_concrete
fill 381 252 605 383 252 605 minecraft:polished_blackstone
fill 383 252 645 385 252 645 minecraft:polished_blackstone
fill 385 252 605 387 252 605 minecraft:polished_blackstone
fill 385 252 621 385 252 627 minecraft:iron_block
fill 386 252 619 386 253 620 minecraft:iron_block
fill 386 252 628 386 253 629 minecraft:iron_block
fill 386 252 646 387 253 646 minecraft:red_concrete
fill 387 252 604 387 255 604 minecraft:black_concrete
fill 387 252 617 387 253 618 minecraft:iron_block
fill 387 252 621 387 253 627 minecraft:iron_block
fill 387 252 630 387 253 631 minecraft:iron_block
fill 387 252 645 389 252 645 minecraft:polished_blackstone
setblock 388 252 604 minecraft:red_concrete
fill 388 252 616 388 253 616 minecraft:iron_block
fill 388 252 619 388 253 621 minecraft:iron_block
fill 388 252 627 388 253 629 minecraft:iron_block
fill 388 252 632 388 253 632 minecraft:iron_block
fill 388 252 646 389 257 646 minecraft:black_concrete
fill 389 252 604 390 257 604 minecraft:black_concrete
fill 389 252 605 391 252 605 minecraft:polished_blackstone
fill 389 252 615 389 253 615 minecraft:iron_block
fill 389 252 616 389 253 616 minecraft:light_gray_concrete
fill 389 252 617 389 253 618 minecraft:iron_block
fill 389 252 630 389 253 631 minecraft:iron_block
fill 389 252 632 389 253 632 minecraft:light_gray_concrete
fill 389 252 633 389 253 633 minecraft:iron_block
fill 390 252 614 391 253 614 minecraft:iron_block
fill 390 252 617 390 253 617 minecraft:light_gray_concrete
fill 390 252 631 390 253 631 minecraft:light_gray_concrete
fill 390 252 634 391 253 634 minecraft:iron_block
fill 391 252 604 392 253 604 minecraft:red_concrete
fill 391 252 616 391 253 616 minecraft:iron_block
fill 391 252 618 391 253 618 minecraft:light_gray_concrete
fill 391 252 630 391 253 630 minecraft:light_gray_concrete
fill 391 252 632 391 253 632 minecraft:iron_block
fill 391 252 645 393 252 645 minecraft:polished_blackstone
fill 392 252 613 393 253 613 minecraft:iron_block
fill 392 252 615 394 253 615 minecraft:iron_block
fill 392 252 619 392 253 619 minecraft:light_gray_concrete
fill 392 252 629 392 253 629 minecraft:light_gray_concrete
fill 392 252 633 394 253 633 minecraft:iron_block
fill 392 252 635 393 253 635 minecraft:iron_block
fill 393 252 605 395 252 605 minecraft:polished_blackstone
fill 393 252 620 393 253 620 minecraft:light_gray_concrete
fill 393 252 623 394 253 625 minecraft:white_concrete
fill 393 252 628 393 253 628 minecraft:light_gray_concrete
fill 394 252 612 400 253 612 minecraft:iron_block
fill 394 252 614 400 253 614 minecraft:iron_block
fill 394 252 621 394 253 621 minecraft:light_gray_concrete
fill 394 252 622 394 253 622 minecraft:white_concrete
fill 394 252 626 394 253 626 minecraft:white_concrete
fill 394 252 627 394 253 627 minecraft:light_gray_concrete
fill 394 252 634 400 253 634 minecraft:iron_block
fill 394 252 636 400 253 636 minecraft:iron_block
fill 395 252 621 399 253 621 minecraft:white_concrete
fill 395 252 627 399 253 627 minecraft:white_concrete
fill 395 252 645 397 252 645 minecraft:polished_blackstone
fill 396 252 620 398 253 620 minecraft:white_concrete
fill 396 252 628 398 253 628 minecraft:white_concrete
fill 397 252 604 398 257 604 minecraft:black_concrete
fill 397 252 605 399 252 605 minecraft:polished_blackstone
fill 397 252 646 397 257 646 minecraft:black_concrete
fill 398 252 646 399 252 646 minecraft:red_concrete
fill 399 252 604 400 252 604 minecraft:red_concrete
fill 399 252 645 401 252 645 minecraft:polished_blackstone
fill 400 252 615 402 253 615 minecraft:iron_block
fill 400 252 621 400 253 621 minecraft:light_gray_concrete
fill 400 252 622 400 253 626 minecraft:white_concrete
fill 400 252 627 400 253 627 minecraft:light_gray_concrete
fill 400 252 633 402 253 633 minecraft:iron_block
fill 400 252 646 401 257 646 minecraft:black_concrete
fill 401 252 604 401 257 604 minecraft:black_concrete
fill 401 252 605 403 252 605 minecraft:polished_blackstone
fill 401 252 613 402 253 613 minecraft:iron_block
fill 401 252 620 401 253 620 minecraft:light_gray_concrete
fill 401 252 623 401 253 625 minecraft:white_concrete
fill 401 252 628 401 253 628 minecraft:light_gray_concrete
fill 401 252 635 402 253 635 minecraft:iron_block
fill 402 252 619 402 253 619 minecraft:light_gray_concrete
fill 402 252 629 402 253 629 minecraft:light_gray_concrete
fill 403 252 614 404 253 614 minecraft:iron_block
fill 403 252 616 404 253 616 minecraft:iron_block
fill 403 252 618 403 253 618 minecraft:light_gray_concrete
fill 403 252 630 403 253 630 minecraft:light_gray_concrete
fill 403 252 632 404 253 632 minecraft:iron_block
fill 403 252 634 404 253 634 minecraft:iron_block
fill 403 252 645 405 252 645 minecraft:polished_blackstone
fill 404 252 617 404 253 617 minecraft:light_gray_concrete
fill 404 252 631 404 253 631 minecraft:light_gray_concrete
fill 405 252 605 407 252 605 minecraft:polished_blackstone
fill 405 252 615 405 253 615 minecraft:iron_block
fill 405 252 616 405 253 616 minecraft:light_gray_concrete
fill 405 252 618 405 253 618 minecraft:iron_block
fill 405 252 630 405 253 630 minecraft:iron_block
fill 405 252 632 405 253 632 minecraft:light_gray_concrete
fill 405 252 633 405 253 633 minecraft:iron_block
fill 406 252 616 406 253 616 minecraft:iron_block
fill 406 252 619 406 253 621 minecraft:iron_block
fill 406 252 627 406 253 629 minecraft:iron_block
fill 406 252 632 406 253 632 minecraft:iron_block
fill 406 252 646 407 253 646 minecraft:red_concrete
fill 407 252 617 407 253 618 minecraft:iron_block
fill 407 252 621 407 253 627 minecraft:iron_block
fill 407 252 630 407 253 631 minecraft:iron_block
fill 407 252 645 409 252 645 minecraft:polished_blackstone
fill 408 252 619 408 253 620 minecraft:iron_block
fill 408 252 628 408 253 629 minecraft:iron_block
fill 408 252 646 409 257 646 minecraft:black_concrete
fill 409 252 604 410 257 604 minecraft:black_concrete
fill 409 252 605 411 252 605 minecraft:polished_blackstone
fill 409 252 621 409 252 627 minecraft:iron_block
setblock 410 252 646 minecraft:red_concrete
fill 411 252 604 412 253 604 minecraft:red_concrete
fill 411 252 645 413 252 645 minecraft:polished_blackstone
fill 411 252 646 411 255 646 minecraft:black_concrete
fill 413 252 605 415 252 605 minecraft:polished_blackstone
fill 415 252 645 417 252 645 minecraft:polished_blackstone
fill 417 252 605 417 252 607 minecraft:polished_blackstone
fill 417 252 609 417 252 611 minecraft:polished_blackstone
fill 417 252 613 417 252 615 minecraft:polished_blackstone
fill 417 252 617 417 252 619 minecraft:polished_blackstone
fill 417 252 621 417 252 623 minecraft:polished_blackstone
fill 417 252 625 417 252 627 minecraft:polished_blackstone
fill 417 252 629 417 252 631 minecraft:polished_blackstone
fill 417 252 633 417 252 635 minecraft:polished_blackstone
fill 417 252 637 417 252 639 minecraft:polished_blackstone
fill 417 252 641 417 252 643 minecraft:polished_blackstone
fill 418 252 604 418 255 605 minecraft:black_concrete
setblock 418 252 606 minecraft:red_concrete
fill 418 252 607 418 257 608 minecraft:black_concrete
fill 418 252 609 418 253 609 minecraft:red_concrete
setblock 418 252 610 minecraft:black_concrete
fill 418 252 615 418 257 616 minecraft:black_concrete
fill 418 252 617 418 252 618 minecraft:red_concrete
fill 418 252 627 418 257 628 minecraft:black_concrete
fill 418 252 629 418 253 630 minecraft:red_concrete
fill 418 252 636 418 257 636 minecraft:black_concrete
fill 418 252 637 418 252 638 minecraft:red_concrete
fill 418 252 639 418 257 639 minecraft:black_concrete
fill 418 252 641 418 253 641 minecraft:red_concrete
setblock 418 252 642 minecraft:black_concrete
fill 418 252 646 418 253 646 minecraft:red_concrete
fill 376 253 612 376 253 613 minecraft:red_concrete
setblock 376 253 616 minecraft:red_concrete
fill 376 253 617 376 256 617 minecraft:black_concrete
fill 376 253 628 376 255 628 minecraft:black_concrete
fill 376 253 632 376 255 632 minecraft:black_concrete
setblock 376 253 633 minecraft:red_concrete
setblock 376 253 644 minecraft:red_concrete
fill 378 253 646 379 255 646 minecraft:black_concrete
fill 381 253 621 385 253 627 minecraft:blue_stained_glass
setblock 383 253 604 minecraft:red_concrete
fill 384 253 604 384 255 604 minecraft:black_concrete
fill 388 253 604 388 256 604 minecraft:black_concrete
fill 393 253 639 393 273 640 minecraft:polished_blackstone
fill 394 253 640 394 273 640 minecraft:polished_blackstone
fill 394 253 646 395 253 646 minecraft:red_concrete
fill 397 253 638 398 254 638 minecraft:crying_obsidian
setblock 398 253 646 minecraft:red_concrete
fill 399 253 604 399 256 604 minecraft:black_concrete
fill 399 253 646 399 256 646 minecraft:black_concrete
setblock 400 253 604 minecraft:red_concrete
fill 403 253 604 404 253 604 minecraft:red_concrete
fill 409 253 621 413 253 627 minecraft:blue_stained_glass
fill 410 253 646 410 256 646 minecraft:black_concrete
fill 414 253 646 414 255 646 minecraft:black_concrete
setblock 415 253 646 minecraft:red_concrete
fill 418 253 606 418 256 606 minecraft:black_concrete
setblock 418 253 610 minecraft:red_concrete
fill 418 253 617 418 256 617 minecraft:black_concrete
setblock 418 253 618 minecraft:red_concrete
setblock 418 253 621 minecraft:red_concrete
fill 418 253 622 418 255 622 minecraft:black_concrete
fill 418 253 637 418 256 638 minecraft:black_concrete
setblock 418 253 642 minecraft:red_concrete
fill 376 254 604 376 259 605 minecraft:black_concrete
setblock 376 254 610 minecraft:black_concrete
fill 376 254 611 376 255 611 minecraft:red_concrete
fill 376 254 612 376 259 613 minecraft:black_concrete
setblock 376 254 614 minecraft:red_concrete
fill 376 254 616 376 259 616 minecraft:black_concrete
fill 376 254 622 376 255 623 minecraft:red_concrete
fill 376 254 624 376 259 625 minecraft:black_concrete
setblock 376 254 630 minecraft:black_concrete
fill 376 254 631 376 255 631 minecraft:red_concrete
fill 376 254 633 376 259 633 minecraft:black_concrete
fill 376 254 634 376 254 635 minecraft:red_concrete
fill 376 254 636 376 256 637 minecraft:black_concrete
fill 376 254 642 376 255 643 minecraft:red_concrete
fill 376 254 644 376 259 645 minecraft:black_concrete
setblock 376 254 646 minecraft:red_concrete
fill 377 254 646 377 257 646 minecraft:black_concrete
fill 379 254 604 380 259 604 minecraft:black_concrete
fill 381 254 604 382 254 604 minecraft:red_concrete
fill 383 254 604 383 259 604 minecraft:black_concrete
fill 384 254 646 385 255 646 minecraft:red_concrete
fill 386 254 646 387 259 646 minecraft:black_concrete
fill 389 254 616 389 254 617 minecraft:iron_block
fill 389 254 631 389 254 632 minecraft:iron_block
fill 391 254 604 392 259 604 minecraft:black_concrete
fill 392 254 640 392 255 640 minecraft:black_concrete
setblock 392 254 646 minecraft:black_concrete
fill 393 254 604 394 255 604 minecraft:red_concrete
fill 393 254 641 394 255 641 minecraft:black_concrete
fill 393 254 646 393 255 646 minecraft:red_concrete
fill 394 254 639 394 255 639 minecraft:black_concrete
fill 394 254 646 395 259 646 minecraft:black_concrete
setblock 396 254 646 minecraft:red_concrete
fill 398 254 639 399 254 639 minecraft:crying_obsidian
fill 398 254 646 398 259 646 minecraft:black_concrete
fill 400 254 604 400 259 604 minecraft:black_concrete
setblock 402 254 604 minecraft:red_concrete
fill 403 254 604 404 259 604 minecraft:black_concrete
fill 404 254 616 405 254 616 minecraft:iron_block
fill 404 254 632 405 254 632 minecraft:iron_block
fill 404 254 646 405 255 646 minecraft:red_concrete
fill 405 254 604 405 255 604 minecraft:red_concrete
setblock 406 254 604 minecraft:black_concrete
fill 406 254 646 407 259 646 minecraft:black_concrete
fill 411 254 604 412 259 604 minecraft:black_concrete
fill 413 254 604 414 254 604 minecraft:red_concrete
fill 415 254 646 415 259 646 minecraft:black_concrete
fill 416 254 646 417 254 646 minecraft:red_concrete
fill 418 254 609 418 259 610 minecraft:black_concrete
fill 418 254 611 418 255 612 minecraft:red_concrete
fill 418 254 618 418 259 618 minecraft:black_concrete
fill 418 254 619 418 254 620 minecraft:red_concrete
fill 418 254 621 418 259 621 minecraft:black_concrete
fill 418 254 623 418 255 623 minecraft:red_concrete
setblock 418 254 624 minecraft:black_concrete
fill 418 254 629 418 259 630 minecraft:black_concrete
fill 418 254 631 418 255 632 minecraft:red_concrete
setblock 418 254 640 minecraft:red_concrete
fill 418 254 641 418 259 642 minecraft:black_concrete
fill 418 254 643 418 255 644 minecraft:red_concrete
fill 418 254 646 418 259 646 minecraft:black_concrete
setblock 376 255 610 minecraft:red_concrete
fill 376 255 614 376 258 614 minecraft:black_concrete
setblock 376 255 630 minecraft:red_concrete
setblock 376 255 634 minecraft:red_concrete
fill 376 255 635 376 258 635 minecraft:black_concrete
fill 376 255 646 376 257 646 minecraft:black_concrete
fill 381 255 604 381 258 604 minecraft:black_concrete
setblock 381 255 646 minecraft:red_concrete
setblock 382 255 604 minecraft:red_concrete
fill 385 255 604 386 255 604 minecraft:red_concrete
setblock 392 255 639 minecraft:black_concrete
setblock 392 255 641 minecraft:black_concrete
setblock 392 255 646 minecraft:red_concrete
setblock 395 255 640 minecraft:black_concrete
fill 396 255 646 396 258 646 minecraft:black_concrete
fill 399 255 639 400 255 639 minecraft:crying_obsidian
fill 400 255 640 401 256 640 minecraft:crying_obsidian
fill 402 255 604 402 258 604 minecraft:black_concrete
setblock 406 255 604 minecraft:red_concrete
fill 412 255 646 413 255 646 minecraft:red_concrete
fill 413 255 604 413 258 604 minecraft:black_concrete
setblock 414 255 604 minecraft:red_concrete
setblock 416 255 646 minecraft:red_concrete
setblock 417 255 604 minecraft:red_concrete
fill 417 255 646 417 258 646 minecraft:black_concrete
fill 418 255 619 418 258 620 minecraft:black_concrete
setblock 418 255 624 minecraft:red_concrete
setblock 418 255 635 minecraft:red_concrete
fill 418 255 640 418 258 640 minecraft:black_concrete
fill 376 256 608 376 257 609 minecraft:red_concrete
fill 376 256 610 376 261 611 minecraft:black_concrete
fill 376 256 620 376 256 621 minecraft:red_concrete
fill 376 256 622 376 261 623 minecraft:black_concrete
fill 376 256 628 376 257 629 minecraft:red_concrete
fill 376 256 630 376 261 631 minecraft:black_concrete
setblock 376 256 632 minecraft:red_concrete
fill 376 256 634 376 258 634 minecraft:black_concrete
fill 376 256 640 376 257 641 minecraft:red_concrete
fill 376 256 642 376 261 643 minecraft:black_concrete
setblock 378 256 646 minecraft:black_concrete
fill 379 256 646 379 257 646 minecraft:red_concrete
fill 380 256 619 380 273 620 minecraft:polished_blackstone
fill 381 256 620 381 273 620 minecraft:polished_blackstone
fill 381 256 646 381 261 646 minecraft:black_concrete
fill 382 256 604 382 261 604 minecraft:black_concrete
fill 382 256 646 383 256 646 minecraft:red_concrete
setblock 384 256 604 minecraft:red_concrete
fill 384 256 621 385 273 622 minecraft:polished_blackstone
fill 384 256 646 385 258 646 minecraft:black_concrete
fill 385 256 604 386 261 604 minecraft:black_concrete
fill 387 256 604 387 257 604 minecraft:red_concrete
fill 390 256 646 391 257 646 minecraft:red_concrete
fill 392 256 646 393 261 646 minecraft:black_concrete
fill 393 256 604 394 261 604 minecraft:black_concrete
fill 395 256 604 396 256 604 minecraft:red_concrete
fill 402 256 640 402 257 641 minecraft:crying_obsidian
fill 402 256 646 403 256 646 minecraft:red_concrete
fill 404 256 646 405 261 646 minecraft:black_concrete
fill 405 256 604 406 261 604 minecraft:black_concrete
fill 407 256 604 408 257 604 minecraft:red_concrete
fill 411 256 646 411 257 646 minecraft:red_concrete
fill 412 256 646 413 261 646 minecraft:black_concrete
fill 414 256 604 414 261 604 minecraft:black_concrete
setblock 414 256 646 minecraft:red_concrete
fill 415 256 604 416 256 604 minecraft:red_concrete
fill 416 256 646 416 261 646 minecraft:black_concrete
fill 417 256 604 418 257 604 minecraft:black_concrete
fill 418 256 605 418 257 605 minecraft:red_concrete
fill 418 256 611 418 261 612 minecraft:black_concrete
fill 418 256 613 418 257 614 minecraft:red_concrete
setblock 418 256 622 minecraft:red_concrete
fill 418 256 623 418 261 624 minecraft:black_concrete
fill 418 256 625 418 257 626 minecraft:red_concrete
fill 418 256 631 418 261 632 minecraft:black_concrete
fill 418 256 633 418 256 634 minecraft:red_concrete
fill 418 256 635 418 261 635 minecraft:black_concrete
fill 418 256 643 418 261 644 minecraft:black_concrete
fill 418 256 645 418 257 645 minecraft:red_concrete
setblock 376 257 617 minecraft:red_concrete
setblock 376 257 620 minecraft:red_concrete
fill 376 257 621 376 260 621 minecraft:black_concrete
fill 376 257 632 376 260 632 minecraft:black_concrete
fill 376 257 636 376 259 636 minecraft:black_concrete
setblock 376 257 637 minecraft:red_concrete
setblock 378 257 646 minecraft:red_concrete
fill 379 257 619 379 258 620 minecraft:black_concrete
fill 380 257 621 380 258 621 minecraft:black_concrete
fill 381 257 619 381 258 619 minecraft:black_concrete
setblock 382 257 646 minecraft:red_concrete
fill 383 257 646 383 260 646 minecraft:black_concrete
fill 384 257 604 384 260 604 minecraft:black_concrete
fill 384 257 620 385 258 620 minecraft:black_concrete
fill 385 257 623 385 258 623 minecraft:black_concrete
fill 386 257 621 386 258 622 minecraft:black_concrete
setblock 388 257 604 minecraft:red_concrete
fill 395 257 604 395 260 604 minecraft:black_concrete
setblock 396 257 604 minecraft:red_concrete
setblock 399 257 604 minecraft:red_concrete
setblock 399 257 646 minecraft:red_concrete
setblock 402 257 646 minecraft:red_concrete
fill 403 257 641 403 258 641 minecraft:crying_obsidian
fill 403 257 646 403 260 646 minecraft:black_concrete
setblock 410 257 646 minecraft:red_concrete
fill 414 257 646 414 260 646 minecraft:black_concrete
fill 415 257 604 416 260 604 minecraft:black_concrete
setblock 418 257 606 minecraft:red_concrete
setblock 418 257 617 minecraft:red_concrete
fill 418 257 622 418 260 622 minecraft:black_concrete
fill 418 257 633 418 260 633 minecraft:black_concrete
setblock 418 257 634 minecraft:red_concrete
fill 418 257 637 418 257 638 minecraft:red_concrete
fill 376 258 606 376 259 607 minecraft:red_concrete
fill 376 258 608 376 263 609 minecraft:black_concrete
fill 376 258 615 376 259 615 minecraft:red_concrete
fill 376 258 617 376 263 617 minecraft:black_concrete
fill 376 258 618 376 258 619 minecraft:red_concrete
fill 376 258 620 376 263 620 minecraft:black_concrete
fill 376 258 626 376 259 627 minecraft:red_concrete
fill 376 258 628 376 263 629 minecraft:black_concrete
fill 376 258 637 376 259 637 minecraft:black_concrete
fill 376 258 638 376 258 639 minecraft:red_concrete
fill 376 258 640 376 263 641 minecraft:black_concrete
fill 376 258 646 377 259 646 minecraft:red_concrete
fill 377 258 604 378 258 604 minecraft:red_concrete
fill 377 258 605 379 258 605 minecraft:polished_blackstone
fill 377 258 607 377 258 609 minecraft:polished_blackstone
fill 377 258 611 377 258 613 minecraft:polished_blackstone
fill 377 258 615 377 258 617 minecraft:polished_blackstone
fill 377 258 619 377 258 621 minecraft:polished_blackstone
fill 377 258 623 377 258 625 minecraft:polished_blackstone
fill 377 258 627 377 258 629 minecraft:polished_blackstone
fill 377 258 631 377 258 633 minecraft:polished_blackstone
fill 377 258 635 377 258 637 minecraft:polished_blackstone
fill 377 258 639 377 258 641 minecraft:polished_blackstone
fill 377 258 643 377 258 645 minecraft:polished_blackstone
fill 378 258 646 379 263 646 minecraft:black_concrete
setblock 379 258 607 minecraft:light[level=12]
setblock 379 258 615 minecraft:light[level=12]
setblock 379 258 621 minecraft:black_concrete
setblock 379 258 623 minecraft:light[level=12]
setblock 379 258 631 minecraft:light[level=12]
setblock 379 258 639 minecraft:light[level=12]
fill 379 258 645 381 258 645 minecraft:polished_blackstone
setblock 380 258 618 minecraft:black_concrete
setblock 380 258 646 minecraft:red_concrete
fill 381 258 605 383 258 605 minecraft:polished_blackstone
setblock 381 258 621 minecraft:black_concrete
fill 382 258 646 382 260 646 minecraft:black_concrete
fill 383 258 621 383 258 622 minecraft:black_concrete
fill 383 258 645 385 258 645 minecraft:polished_blackstone
setblock 384 258 623 minecraft:black_concrete
fill 385 258 605 387 258 605 minecraft:polished_blackstone
setblock 386 258 620 minecraft:black_concrete
setblock 386 258 623 minecraft:black_concrete
fill 387 258 604 388 263 604 minecraft:black_concrete
setblock 387 258 607 minecraft:light[level=12]
setblock 387 258 615 minecraft:light[level=12]
setblock 387 258 623 minecraft:light[level=12]
setblock 387 258 631 minecraft:light[level=12]
setblock 387 258 639 minecraft:light[level=12]
fill 387 258 645 389 258 645 minecraft:polished_blackstone
fill 388 258 646 389 259 646 minecraft:red_concrete
fill 389 258 604 390 259 604 minecraft:red_concrete
fill 389 258 605 391 258 605 minecraft:polished_blackstone
fill 390 258 646 391 263 646 minecraft:black_concrete
fill 391 258 645 393 258 645 minecraft:polished_blackstone
fill 393 258 605 395 258 605 minecraft:polished_blackstone
setblock 395 258 607 minecraft:light[level=12]
setblock 395 258 615 minecraft:light[level=12]
setblock 395 258 623 minecraft:light[level=12]
setblock 395 258 631 minecraft:light[level=12]
setblock 395 258 639 minecraft:light[level=12]
fill 395 258 645 397 258 645 minecraft:polished_blackstone
fill 396 258 604 396 263 604 minecraft:black_concrete
fill 397 258 604 398 258 604 minecraft:red_concrete
fill 397 258 605 399 258 605 minecraft:polished_blackstone
fill 397 258 646 397 259 646 minecraft:red_concrete
fill 399 258 604 399 263 604 minecraft:black_concrete
fill 399 258 645 401 258 645 minecraft:polished_blackstone
fill 399 258 646 399 263 646 minecraft:black_concrete
fill 400 258 646 401 258 646 minecraft:red_concrete
fill 401 258 604 401 259 604 minecraft:red_concrete
fill 401 258 605 403 258 605 minecraft:polished_blackstone
fill 402 258 646 402 263 646 minecraft:black_concrete
setblock 403 258 607 minecraft:light[level=12]
setblock 403 258 615 minecraft:light[level=12]
setblock 403 258 623 minecraft:light[level=12]
setblock 403 258 631 minecraft:light[level=12]
setblock 403 258 639 minecraft:light[level=12]
fill 403 258 645 405 258 645 minecraft:polished_blackstone
fill 404 258 641 404 258 642 minecraft:crying_obsidian
fill 405 258 605 407 258 605 minecraft:polished_blackstone
fill 405 258 642 405 259 642 minecraft:crying_obsidian
fill 407 258 604 408 263 604 minecraft:black_concrete
fill 407 258 645 409 258 645 minecraft:polished_blackstone
fill 408 258 646 409 259 646 minecraft:red_concrete
fill 409 258 604 410 259 604 minecraft:red_concrete
fill 409 258 605 411 258 605 minecraft:polished_blackstone
fill 410 258 646 411 263 646 minecraft:black_concrete
setblock 411 258 607 minecraft:light[level=12]
setblock 411 258 615 minecraft:light[level=12]
setblock 411 258 623 minecraft:light[level=12]
setblock 411 258 631 minecraft:light[level=12]
setblock 411 258 639 minecraft:light[level=12]
fill 411 258 645 413 258 645 minecraft:polished_blackstone
fill 413 258 605 415 258 605 minecraft:polished_blackstone
fill 415 258 645 417 258 645 minecraft:polished_blackstone
fill 417 258 604 417 261 604 minecraft:black_concrete
fill 417 258 605 417 258 607 minecraft:polished_blackstone
fill 417 258 609 417 258 611 minecraft:polished_blackstone
fill 417 258 613 417 258 615 minecraft:polished_blackstone
fill 417 258 617 417 258 619 minecraft:polished_blackstone
fill 417 258 621 417 258 623 minecraft:polished_blackstone
fill 417 258 625 417 258 627 minecraft:polished_blackstone
fill 417 258 629 417 258 631 minecraft:polished_blackstone
fill 417 258 633 417 258 635 minecraft:polished_blackstone
fill 417 258 637 417 258 639 minecraft:polished_blackstone
fill 417 258 641 417 258 643 minecraft:polished_blackstone
setblock 418 258 604 minecraft:red_concrete
fill 418 258 605 418 263 606 minecraft:black_concrete
fill 418 258 607 418 259 608 minecraft:red_concrete
fill 418 258 613 418 263 614 minecraft:black_concrete
fill 418 258 615 418 258 616 minecraft:red_concrete
fill 418 258 617 418 263 617 minecraft:black_concrete
fill 418 258 625 418 263 626 minecraft:black_concrete
fill 418 258 627 418 259 628 minecraft:red_concrete
fill 418 258 634 418 263 634 minecraft:black_concrete
setblock 418 258 636 minecraft:red_concrete
fill 418 258 637 418 263 638 minecraft:black_concrete
fill 418 258 639 418 259 639 minecraft:red_concrete
fill 418 258 645 418 263 645 minecraft:black_concrete
setblock 376 259 614 minecraft:red_concrete
fill 376 259 618 376 261 619 minecraft:black_concrete
fill 376 259 634 376 259 635 minecraft:red_concrete
setblock 376 259 638 minecraft:red_concrete
fill 376 259 639 376 262 639 minecraft:black_concrete
fill 377 259 604 377 262 604 minecraft:black_concrete
setblock 378 259 604 minecraft:red_concrete
fill 380 259 646 380 262 646 minecraft:black_concrete
setblock 381 259 604 minecraft:red_concrete
fill 384 259 646 384 261 646 minecraft:black_concrete
setblock 385 259 646 minecraft:red_concrete
setblock 396 259 646 minecraft:red_concrete
fill 397 259 604 398 262 604 minecraft:black_concrete
fill 400 259 646 401 262 646 minecraft:black_concrete
setblock 402 259 604 minecraft:red_concrete
setblock 413 259 604 minecraft:red_concrete
setblock 417 259 646 minecraft:red_concrete
fill 418 259 604 418 262 604 minecraft:black_concrete
fill 418 259 615 418 262 615 minecraft:black_concrete
setblock 418 259 616 minecraft:red_concrete
fill 418 259 619 418 259 620 minecraft:red_concrete
fill 418 259 636 418 262 636 minecraft:black_concrete
setblock 418 259 640 minecraft:red_concrete
fill 376 260 604 376 260 605 minecraft:red_concrete
fill 376 260 606 376 265 607 minecraft:black_concrete
fill 376 260 612 376 261 613 minecraft:red_concrete
fill 376 260 614 376 265 615 minecraft:black_concrete
setblock 376 260 616 minecraft:red_concrete
fill 376 260 624 376 261 625 minecraft:red_concrete
fill 376 260 626 376 265 627 minecraft:black_concrete
fill 376 260 633 376 261 633 minecraft:red_concrete
fill 376 260 634 376 261 635 minecraft:black_concrete
fill 376 260 636 376 260 637 minecraft:red_concrete
fill 376 260 638 376 265 638 minecraft:black_concrete
fill 376 260 644 376 261 645 minecraft:red_concrete
fill 376 260 646 377 265 646 minecraft:black_concrete
fill 378 260 604 378 265 604 minecraft:black_concrete
fill 379 260 604 380 260 604 minecraft:red_concrete
fill 381 260 604 381 265 604 minecraft:black_concrete
fill 383 260 604 383 261 604 minecraft:red_concrete
fill 385 260 646 385 265 646 minecraft:black_concrete
fill 386 260 646 387 260 646 minecraft:red_concrete
fill 388 260 646 389 265 646 minecraft:black_concrete
fill 389 260 604 390 265 604 minecraft:black_concrete
fill 391 260 604 392 261 604 minecraft:red_concrete
fill 394 260 646 395 261 646 minecraft:red_concrete
fill 396 260 646 397 265 646 minecraft:black_concrete
setblock 398 260 646 minecraft:red_concrete
setblock 400 260 604 minecraft:red_concrete
fill 401 260 604 402 265 604 minecraft:black_concrete
fill 403 260 604 404 261 604 minecraft:red_concrete
fill 406 260 646 407 261 646 minecraft:red_concrete
fill 408 260 646 409 265 646 minecraft:black_concrete
fill 409 260 604 410 265 604 minecraft:black_concrete
fill 411 260 604 412 260 604 minecraft:red_concrete
fill 413 260 604 413 265 604 minecraft:black_concrete
fill 415 260 646 415 261 646 minecraft:red_concrete
fill 417 260 646 417 265 646 minecraft:black_concrete
fill 418 260 607 418 265 608 minecraft:black_concrete
fill 418 260 609 418 261 610 minecraft:red_concrete
fill 418 260 616 418 265 616 minecraft:black_concrete
setblock 418 260 618 minecraft:red_concrete
fill 418 260 619 418 265 620 minecraft:black_concrete
fill 418 260 621 418 261 621 minecraft:red_concrete
fill 418 260 627 418 265 628 minecraft:black_concrete
fill 418 260 629 418 260 630 minecraft:red_concrete
fill 418 260 639 418 265 640 minecraft:black_concrete
fill 418 260 641 418 261 642 minecraft:red_concrete
setblock 418 260 646 minecraft:red_concrete
setblock 376 261 604 minecraft:red_concrete
fill 376 261 605 376 264 605 minecraft:black_concrete
fill 376 261 616 376 263 616 minecraft:black_concrete
setblock 376 261 621 minecraft:red_concrete
setblock 376 261 632 minecraft:red_concrete
fill 376 261 636 376 263 637 minecraft:black_concrete
fill 379 261 604 380 264 604 minecraft:black_concrete
fill 382 261 646 383 261 646 minecraft:red_concrete
setblock 384 261 604 minecraft:red_concrete
setblock 386 261 646 minecraft:red_concrete
fill 387 261 646 387 264 646 minecraft:black_concrete
setblock 395 261 604 minecraft:red_concrete
fill 398 261 646 398 264 646 minecraft:black_concrete
fill 400 261 604 400 264 604 minecraft:black_concrete
setblock 403 261 646 minecraft:red_concrete
fill 411 261 604 411 264 604 minecraft:black_concrete
setblock 412 261 604 minecraft:red_concrete
setblock 414 261 646 minecraft:red_concrete
fill 415 261 604 416 261 604 minecraft:red_concrete
fill 418 261 618 418 264 618 minecraft:black_concrete
setblock 418 261 622 minecraft:red_concrete
fill 418 261 629 418 264 629 minecraft:black_concrete
setblock 418 261 630 minecraft:red_concrete
setblock 418 261 633 minecraft:red_concrete
fill 418 261 646 418 264 646 minecraft:black_concrete
fill 376 262 604 376 267 604 minecraft:black_concrete
fill 376 262 610 376 263 611 minecraft:red_concrete
fill 376 262 612 376 267 613 minecraft:black_concrete
setblock 376 262 618 minecraft:black_concrete
fill 376 262 619 376 263 619 minecraft:red_concrete
fill 376 262 621 376 267 621 minecraft:black_concrete
fill 376 262 622 376 262 623 minecraft:red_concrete
fill 376 262 624 376 264 625 minecraft:black_concrete
fill 376 262 630 376 263 631 minecraft:red_concrete
fill 376 262 632 376 267 633 minecraft:black_concrete
setblock 376 262 634 minecraft:red_concrete
fill 376 262 635 376 265 635 minecraft:black_concrete
fill 376 262 642 376 263 643 minecraft:red_concrete
fill 376 262 644 376 267 645 minecraft:black_concrete
fill 381 262 646 381 263 646 minecraft:red_concrete
setblock 382 262 604 minecraft:red_concrete
fill 382 262 646 383 267 646 minecraft:black_concrete
fill 383 262 604 384 267 604 minecraft:black_concrete
setblock 384 262 646 minecraft:red_concrete
fill 385 262 604 386 263 604 minecraft:red_concrete
fill 386 262 646 386 267 646 minecraft:black_concrete
fill 391 262 604 392 267 604 minecraft:black_concrete
fill 392 262 646 393 263 646 minecraft:red_concrete
fill 393 262 604 394 262 604 minecraft:red_concrete
fill 394 262 646 395 267 646 minecraft:black_concrete
fill 395 262 604 395 267 604 minecraft:black_concrete
fill 403 262 604 404 267 604 minecraft:black_concrete
fill 403 262 646 403 267 646 minecraft:black_concrete
fill 404 262 646 405 262 646 minecraft:red_concrete
fill 405 262 604 406 263 604 minecraft:red_concrete
fill 406 262 646 407 267 646 minecraft:black_concrete
fill 412 262 604 412 267 604 minecraft:black_concrete
fill 412 262 646 413 263 646 minecraft:red_concrete
setblock 414 262 604 minecraft:red_concrete
fill 414 262 646 415 267 646 minecraft:black_concrete
fill 415 262 604 416 267 604 minecraft:black_concrete
setblock 416 262 646 minecraft:red_concrete
fill 417 262 604 417 263 604 minecraft:red_concrete
fill 418 262 609 418 267 610 minecraft:black_concrete
fill 418 262 611 418 262 612 minecraft:red_concrete
fill 418 262 621 418 267 622 minecraft:black_concrete
fill 418 262 623 418 263 624 minecraft:red_concrete
fill 418 262 630 418 267 630 minecraft:black_concrete
fill 418 262 631 418 262 632 minecraft:red_concrete
fill 418 262 633 418 267 633 minecraft:black_concrete
fill 418 262 635 418 263 635 minecraft:red_concrete
fill 418 262 641 418 267 642 minecraft:black_concrete
fill 418 262 643 418 263 644 minecraft:red_concrete
setblock 376 263 618 minecraft:red_concrete
setblock 376 263 622 minecraft:red_concrete
fill 376 263 623 376 266 623 minecraft:black_concrete
fill 376 263 634 376 265 634 minecraft:black_concrete
setblock 376 263 639 minecraft:red_concrete
setblock 377 263 604 minecraft:red_concrete
setblock 380 263 646 minecraft:red_concrete
fill 382 263 604 382 266 604 minecraft:black_concrete
fill 384 263 646 384 266 646 minecraft:black_concrete
fill 393 263 604 393 266 604 minecraft:black_concrete
setblock 394 263 604 minecraft:red_concrete
fill 397 263 604 398 263 604 minecraft:red_concrete
fill 400 263 646 401 263 646 minecraft:red_concrete
setblock 404 263 646 minecraft:red_concrete
fill 405 263 646 405 266 646 minecraft:black_concrete
fill 414 263 604 414 266 604 minecraft:black_concrete
fill 416 263 646 416 266 646 minecraft:black_concrete
setblock 418 263 604 minecraft:red_concrete
fill 418 263 611 418 266 611 minecraft:black_concrete
setblock 418 263 612 minecraft:red_concrete
setblock 418 263 615 minecraft:red_concrete
fill 418 263 631 418 266 632 minecraft:black_concrete
setblock 418 263 636 minecraft:red_concrete
fill 376 264 608 376 264 609 minecraft:red_concrete
fill 376 264 610 376 269 611 minecraft:black_concrete
fill 376 264 616 376 265 617 minecraft:red_concrete
fill 376 264 618 376 269 619 minecraft:black_concrete
setblock 376 264 620 minecraft:red_concrete
fill 376 264 622 376 266 622 minecraft:black_concrete
fill 376 264 628 376 265 629 minecraft:red_concrete
fill 376 264 630 376 269 631 minecraft:black_concrete
setblock 376 264 636 minecraft:black_concrete
fill 376 264 637 376 265 637 minecraft:red_concrete
fill 376 264 639 376 269 639 minecraft:black_concrete
fill 376 264 640 376 264 641 minecraft:red_concrete
fill 376 264 642 376 266 643 minecraft:black_concrete
fill 377 264 604 377 269 604 minecraft:black_concrete
fill 377 264 605 379 264 605 minecraft:polished_blackstone
fill 377 264 607 377 264 609 minecraft:polished_blackstone
fill 377 264 611 377 264 613 minecraft:polished_blackstone
fill 377 264 615 377 264 617 minecraft:polished_blackstone
fill 377 264 619 377 264 621 minecraft:polished_blackstone
fill 377 264 623 377 264 625 minecraft:polished_blackstone
fill 377 264 627 377 264 629 minecraft:polished_blackstone
fill 377 264 631 377 264 633 minecraft:polished_blackstone
fill 377 264 635 377 264 637 minecraft:polished_blackstone
fill 377 264 639 377 264 641 minecraft:polished_blackstone
fill 377 264 643 377 264 645 minecraft:polished_blackstone
fill 378 264 646 379 265 646 minecraft:red_concrete
fill 379 264 645 381 264 645 minecraft:polished_blackstone
fill 380 264 646 381 269 646 minecraft:black_concrete
fill 381 264 605 383 264 605 minecraft:polished_blackstone
fill 383 264 645 385 264 645 minecraft:polished_blackstone
fill 385 264 604 386 269 604 minecraft:black_concrete
fill 385 264 605 387 264 605 minecraft:polished_blackstone
fill 387 264 604 388 265 604 minecraft:red_concrete
fill 387 264 645 389 264 645 minecraft:polished_blackstone
fill 389 264 605 391 264 605 minecraft:polished_blackstone
fill 390 264 646 391 264 646 minecraft:red_concrete
fill 391 264 645 393 264 645 minecraft:polished_blackstone
fill 392 264 613 393 265 613 minecraft:red_concrete
fill 392 264 646 393 269 646 minecraft:black_concrete
fill 393 264 605 395 264 605 minecraft:polished_blackstone
fill 393 264 609 394 265 609 minecraft:magma_block
fill 393 264 612 393 265 612 minecraft:red_concrete
fill 393 264 614 393 265 614 minecraft:red_concrete
fill 394 264 604 394 269 604 minecraft:black_concrete
fill 395 264 645 397 264 645 minecraft:polished_blackstone
setblock 396 264 604 minecraft:red_concrete
fill 397 264 604 398 269 604 minecraft:black_concrete
fill 397 264 605 399 264 605 minecraft:polished_blackstone
fill 399 264 604 399 265 604 minecraft:red_concrete
fill 399 264 645 401 264 645 minecraft:polished_blackstone
fill 399 264 646 399 265 646 minecraft:red_concrete
fill 400 264 646 401 269 646 minecraft:black_concrete
fill 401 264 605 403 264 605 minecraft:polished_blackstone
setblock 402 264 646 minecraft:red_concrete
fill 403 264 645 405 264 645 minecraft:polished_blackstone
fill 404 264 646 404 269 646 minecraft:black_concrete
fill 405 264 604 406 269 604 minecraft:black_concrete
fill 405 264 605 407 264 605 minecraft:polished_blackstone
fill 407 264 604 408 264 604 minecraft:red_concrete
fill 407 264 645 409 264 645 minecraft:polished_blackstone
fill 409 264 605 411 264 605 minecraft:polished_blackstone
fill 410 264 646 411 265 646 minecraft:red_concrete
fill 411 264 645 413 264 645 minecraft:polished_blackstone
fill 412 264 646 413 269 646 minecraft:black_concrete
fill 413 264 605 415 264 605 minecraft:polished_blackstone
fill 415 264 645 417 264 645 minecraft:polished_blackstone
fill 417 264 604 418 269 604 minecraft:black_concrete
fill 417 264 605 417 264 607 minecraft:polished_blackstone
fill 417 264 609 417 264 611 minecraft:polished_blackstone
fill 417 264 613 417 264 615 minecraft:polished_blackstone
fill 417 264 617 417 264 619 minecraft:polished_blackstone
fill 417 264 621 417 264 623 minecraft:polished_blackstone
fill 417 264 625 417 264 627 minecraft:polished_blackstone
fill 417 264 629 417 264 631 minecraft:polished_blackstone
fill 417 264 633 417 264 635 minecraft:polished_blackstone
fill 417 264 637 417 264 639 minecraft:polished_blackstone
fill 417 264 641 417 264 643 minecraft:polished_blackstone
fill 418 264 605 418 265 606 minecraft:red_concrete
fill 418 264 612 418 269 612 minecraft:black_concrete
fill 418 264 613 418 264 614 minecraft:red_concrete
fill 418 264 615 418 269 615 minecraft:black_concrete
fill 418 264 617 418 265 617 minecraft:red_concrete
fill 418 264 623 418 269 624 minecraft:black_concrete
fill 418 264 625 418 265 626 minecraft:red_concrete
setblock 418 264 634 minecraft:red_concrete
fill 418 264 635 418 269 636 minecraft:black_concrete
fill 418 264 637 418 265 638 minecraft:red_concrete
fill 418 264 643 418 269 644 minecraft:black_concrete
setblock 418 264 645 minecraft:red_concrete
setblock 376 265 605 minecraft:red_concrete
setblock 376 265 608 minecraft:red_concrete
fill 376 265 609 376 268 609 minecraft:black_concrete
fill 376 265 620 376 268 620 minecraft:black_concrete
fill 376 265 624 376 267 624 minecraft:black_concrete
setblock 376 265 625 minecraft:red_concrete
setblock 376 265 636 minecraft:red_concrete
setblock 376 265 640 minecraft:red_concrete
fill 376 265 641 376 268 641 minecraft:black_concrete
fill 379 265 604 380 265 604 minecraft:red_concrete
setblock 387 265 646 minecraft:red_concrete
setblock 390 265 646 minecraft:red_concrete
fill 391 265 646 391 268 646 minecraft:black_concrete
fill 396 265 604 396 268 604 minecraft:black_concrete
setblock 398 265 646 minecraft:red_concrete
setblock 400 265 604 minecraft:red_concrete
fill 402 265 646 402 268 646 minecraft:black_concrete
fill 407 265 604 407 268 604 minecraft:black_concrete
setblock 408 265 604 minecraft:red_concrete
setblock 411 265 604 minecraft:red_concrete
fill 418 265 613 418 268 614 minecraft:black_concrete
setblock 418 265 618 minecraft:red_concrete
setblock 418 265 629 minecraft:red_concrete
fill 418 265 634 418 268 634 minecraft:black_concrete
fill 418 265 645 418 268 645 minecraft:black_concrete
setblock 418 265 646 minecraft:red_concrete
fill 376 266 605 376 271 605 minecraft:black_concrete
fill 376 266 606 376 266 607 minecraft:red_concrete
fill 376 266 608 376 271 608 minecraft:black_concrete
fill 376 266 614 376 267 615 minecraft:red_concrete
fill 376 266 616 376 271 617 minecraft:black_concrete
fill 376 266 625 376 267 625 minecraft:black_concrete
fill 376 266 626 376 266 627 minecraft:red_concrete
fill 376 266 628 376 271 629 minecraft:black_concrete
fill 376 266 634 376 267 635 minecraft:red_concrete
fill 376 266 636 376 271 637 minecraft:black_concrete
setblock 376 266 638 minecraft:red_concrete
fill 376 266 640 376 268 640 minecraft:black_concrete
fill 376 266 646 377 267 646 minecraft:red_concrete
setblock 378 266 604 minecraft:red_concrete
fill 378 266 646 379 271 646 minecraft:black_concrete
fill 379 266 604 380 271 604 minecraft:black_concrete
setblock 379 266 607 minecraft:light[level=12]
setblock 379 266 615 minecraft:light[level=12]
setblock 379 266 623 minecraft:light[level=12]
setblock 379 266 631 minecraft:light[level=12]
setblock 379 266 639 minecraft:light[level=12]
fill 381 266 604 381 267 604 minecraft:red_concrete
fill 385 266 646 385 267 646 minecraft:red_concrete
fill 387 266 604 388 271 604 minecraft:black_concrete
setblock 387 266 607 minecraft:light[level=12]
setblock 387 266 615 minecraft:light[level=12]
setblock 387 266 623 minecraft:light[level=12]
setblock 387 266 631 minecraft:light[level=12]
setblock 387 266 639 minecraft:light[level=12]
fill 387 266 646 387 271 646 minecraft:black_concrete
fill 388 266 646 389 266 646 minecraft:red_concrete
fill 389 266 604 390 266 604 minecraft:red_concrete
fill 390 266 646 390 271 646 minecraft:black_concrete
setblock 395 266 607 minecraft:light[level=12]
setblock 395 266 615 minecraft:light[level=12]
setblock 395 266 623 minecraft:light[level=12]
setblock 395 266 631 minecraft:light[level=12]
setblock 395 266 639 minecraft:light[level=12]
fill 396 266 646 397 267 646 minecraft:red_concrete
fill 398 266 646 399 271 646 minecraft:black_concrete
fill 399 266 604 400 271 604 minecraft:black_concrete
fill 401 266 604 402 267 604 minecraft:red_concrete
setblock 403 266 607 minecraft:light[level=12]
setblock 403 266 615 minecraft:light[level=12]
setblock 403 266 623 minecraft:light[level=12]
setblock 403 266 631 minecraft:light[level=12]
setblock 403 266 639 minecraft:light[level=12]
fill 408 266 604 408 271 604 minecraft:black_concrete
fill 408 266 646 409 266 646 minecraft:red_concrete
fill 409 266 604 410 266 604 minecraft:red_concrete
fill 410 266 646 411 271 646 minecraft:black_concrete
fill 411 266 604 411 271 604 minecraft:black_concrete
setblock 411 266 607 minecraft:light[level=12]
setblock 411 266 615 minecraft:light[level=12]
setblock 411 266 623 minecraft:light[level=12]
setblock 411 266 631 minecraft:light[level=12]
setblock 411 266 639 minecraft:light[level=12]
fill 413 266 604 413 267 604 minecraft:red_concrete
fill 417 266 646 417 267 646 minecraft:red_concrete
fill 418 266 605 418 271 606 minecraft:black_concrete
fill 418 266 607 418 267 608 minecraft:red_concrete
setblock 418 266 616 minecraft:red_concrete
fill 418 266 617 418 271 618 minecraft:black_concrete
fill 418 266 619 418 267 620 minecraft:red_concrete
fill 418 266 625 418 271 626 minecraft:black_concrete
schedule function dropper:buildpart/152_5 1t
