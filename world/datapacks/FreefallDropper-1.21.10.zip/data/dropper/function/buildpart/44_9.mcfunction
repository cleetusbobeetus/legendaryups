fill 377 201 219 377 204 219 minecraft:mossy_cobblestone
setblock 378 201 182 minecraft:stone_bricks
setblock 378 201 202 minecraft:stone_bricks
fill 378 201 203 378 203 203 minecraft:mossy_cobblestone
setblock 378 201 207 minecraft:stone_bricks
setblock 378 201 217 minecraft:stone_bricks
setblock 378 201 218 minecraft:mossy_cobblestone
setblock 378 201 222 minecraft:stone_bricks
fill 379 201 182 379 202 182 minecraft:mossy_cobblestone
setblock 379 201 184 minecraft:light[level=12]
setblock 379 201 192 minecraft:light[level=12]
setblock 379 201 200 minecraft:light[level=12]
setblock 379 201 208 minecraft:light[level=12]
setblock 379 201 216 minecraft:light[level=12]
setblock 379 201 221 minecraft:stone_bricks
fill 379 201 222 382 201 222 minecraft:mossy_cobblestone
fill 380 201 221 381 201 221 minecraft:mossy_cobblestone
setblock 383 201 222 minecraft:stone_bricks
fill 384 201 182 387 201 182 minecraft:mossy_cobblestone
fill 384 201 222 384 203 222 minecraft:mossy_cobblestone
fill 386 201 210 386 202 211 minecraft:cobbled_deepslate
fill 386 201 213 386 202 214 minecraft:cobbled_deepslate
fill 386 201 221 388 201 221 minecraft:mossy_cobblestone
setblock 387 201 184 minecraft:light[level=12]
setblock 387 201 192 minecraft:light[level=12]
setblock 387 201 200 minecraft:light[level=12]
setblock 387 201 208 minecraft:light[level=12]
fill 387 201 209 387 202 209 minecraft:cobbled_deepslate
fill 387 201 215 387 202 215 minecraft:cobbled_deepslate
setblock 387 201 216 minecraft:light[level=12]
setblock 388 201 182 minecraft:stone_bricks
fill 388 201 183 388 204 183 minecraft:mossy_cobblestone
setblock 388 201 222 minecraft:stone_bricks
fill 389 201 182 389 204 182 minecraft:mossy_cobblestone
setblock 389 201 221 minecraft:stone_bricks
fill 389 201 222 389 204 222 minecraft:mossy_cobblestone
fill 390 201 221 390 203 221 minecraft:mossy_cobblestone
setblock 391 201 183 minecraft:mossy_cobblestone
setblock 392 201 183 minecraft:stone_bricks
fill 392 201 209 392 202 209 minecraft:cobbled_deepslate
fill 392 201 215 392 202 215 minecraft:cobbled_deepslate
setblock 393 201 182 minecraft:stone_bricks
fill 393 201 183 393 204 183 minecraft:mossy_cobblestone
fill 393 201 211 393 202 213 minecraft:cobbled_deepslate
setblock 393 201 222 minecraft:stone_bricks
fill 394 201 182 394 204 182 minecraft:mossy_cobblestone
setblock 394 201 221 minecraft:stone_bricks
fill 394 201 222 394 204 222 minecraft:mossy_cobblestone
setblock 395 201 184 minecraft:light[level=12]
setblock 395 201 192 minecraft:light[level=12]
setblock 395 201 200 minecraft:light[level=12]
setblock 395 201 208 minecraft:light[level=12]
setblock 395 201 216 minecraft:light[level=12]
setblock 395 201 221 minecraft:mossy_cobblestone
setblock 397 201 183 minecraft:stone_bricks
setblock 398 201 182 minecraft:stone_bricks
fill 398 201 183 398 203 183 minecraft:mossy_cobblestone
setblock 398 201 222 minecraft:stone_bricks
fill 399 201 182 402 201 182 minecraft:mossy_cobblestone
fill 399 201 222 402 201 222 minecraft:mossy_cobblestone
setblock 401 201 183 minecraft:mossy_cobblestone
setblock 402 201 183 minecraft:stone_bricks
setblock 403 201 182 minecraft:stone_bricks
fill 403 201 183 403 204 183 minecraft:mossy_cobblestone
setblock 403 201 184 minecraft:light[level=12]
setblock 403 201 192 minecraft:light[level=12]
setblock 403 201 200 minecraft:light[level=12]
setblock 403 201 208 minecraft:light[level=12]
setblock 403 201 216 minecraft:light[level=12]
setblock 403 201 222 minecraft:stone_bricks
fill 404 201 182 404 204 182 minecraft:mossy_cobblestone
fill 404 201 222 404 204 222 minecraft:mossy_cobblestone
setblock 406 201 184 minecraft:stone_bricks
setblock 407 201 183 minecraft:stone_bricks
fill 407 201 184 407 204 184 minecraft:mossy_cobblestone
setblock 408 201 182 minecraft:stone_bricks
fill 408 201 183 408 204 183 minecraft:mossy_cobblestone
setblock 408 201 222 minecraft:stone_bricks
fill 409 201 182 409 204 182 minecraft:mossy_cobblestone
setblock 409 201 221 minecraft:stone_bricks
fill 409 201 222 409 204 222 minecraft:mossy_cobblestone
setblock 410 201 185 minecraft:stone_bricks
setblock 410 201 220 minecraft:stone_bricks
fill 410 201 221 410 204 221 minecraft:mossy_cobblestone
setblock 411 201 184 minecraft:stone_bricks
fill 411 201 185 411 204 185 minecraft:mossy_cobblestone
setblock 411 201 192 minecraft:light[level=12]
setblock 411 201 200 minecraft:light[level=12]
setblock 411 201 208 minecraft:light[level=12]
setblock 411 201 216 minecraft:light[level=12]
fill 411 201 220 411 203 220 minecraft:mossy_cobblestone
setblock 412 201 183 minecraft:stone_bricks
fill 412 201 184 412 204 184 minecraft:mossy_cobblestone
setblock 413 201 182 minecraft:stone_bricks
fill 413 201 183 413 204 183 minecraft:mossy_cobblestone
setblock 413 201 222 minecraft:stone_bricks
fill 414 201 182 414 204 182 minecraft:mossy_cobblestone
setblock 414 201 221 minecraft:stone_bricks
fill 414 201 222 414 204 222 minecraft:mossy_cobblestone
setblock 415 201 185 minecraft:stone_bricks
setblock 415 201 186 minecraft:mossy_cobblestone
setblock 415 201 220 minecraft:stone_bricks
fill 415 201 221 415 204 221 minecraft:mossy_cobblestone
setblock 416 201 184 minecraft:stone_bricks
fill 416 201 185 416 204 185 minecraft:mossy_cobblestone
setblock 416 201 199 minecraft:stone_bricks
setblock 416 201 200 minecraft:mossy_cobblestone
setblock 416 201 203 minecraft:mossy_cobblestone
setblock 416 201 204 minecraft:stone_bricks
fill 416 201 205 417 201 205 minecraft:mossy_cobblestone
setblock 416 201 219 minecraft:stone_bricks
fill 416 201 220 416 204 220 minecraft:mossy_cobblestone
setblock 417 201 183 minecraft:stone_bricks
fill 417 201 184 417 204 184 minecraft:mossy_cobblestone
setblock 417 201 188 minecraft:stone_bricks
setblock 417 201 198 minecraft:stone_bricks
fill 417 201 199 417 202 199 minecraft:mossy_cobblestone
setblock 417 201 203 minecraft:stone_bricks
fill 417 201 204 417 204 204 minecraft:mossy_cobblestone
fill 417 201 206 417 201 207 minecraft:mossy_cobblestone
setblock 417 201 208 minecraft:stone_bricks
setblock 417 201 209 minecraft:mossy_cobblestone
setblock 417 201 213 minecraft:stone_bricks
setblock 417 201 214 minecraft:mossy_cobblestone
setblock 417 201 218 minecraft:stone_bricks
fill 417 201 219 417 204 219 minecraft:mossy_cobblestone
setblock 377 202 182 minecraft:stone_bricks
fill 377 202 183 377 203 183 minecraft:mossy_cobblestone
setblock 377 202 198 minecraft:mossy_cobblestone
setblock 377 202 202 minecraft:stone_bricks
fill 377 202 203 377 205 203 minecraft:mossy_cobblestone
setblock 377 202 207 minecraft:stone_bricks
fill 377 202 208 377 205 208 minecraft:mossy_cobblestone
setblock 377 202 212 minecraft:stone_bricks
fill 377 202 213 377 203 213 minecraft:mossy_cobblestone
setblock 377 202 217 minecraft:stone_bricks
fill 377 202 218 377 203 218 minecraft:mossy_cobblestone
setblock 377 202 222 minecraft:stone_bricks
fill 378 202 182 378 203 182 minecraft:mossy_cobblestone
setblock 378 202 202 minecraft:mossy_cobblestone
setblock 378 202 206 minecraft:stone_bricks
fill 378 202 207 378 203 207 minecraft:mossy_cobblestone
setblock 378 202 221 minecraft:stone_bricks
fill 378 202 222 381 202 222 minecraft:mossy_cobblestone
setblock 379 202 221 minecraft:mossy_cobblestone
setblock 382 202 222 minecraft:stone_bricks
fill 383 202 222 383 203 222 minecraft:mossy_cobblestone
fill 385 202 182 386 202 182 minecraft:mossy_cobblestone
setblock 385 202 212 minecraft:cobbled_deepslate
setblock 387 202 182 minecraft:stone_bricks
setblock 387 202 221 minecraft:mossy_cobblestone
setblock 387 202 222 minecraft:stone_bricks
fill 388 202 182 388 205 182 minecraft:mossy_cobblestone
fill 388 202 208 391 202 208 minecraft:cobbled_deepslate
fill 388 202 216 391 202 216 minecraft:cobbled_deepslate
setblock 388 202 221 minecraft:stone_bricks
fill 388 202 222 388 205 222 minecraft:mossy_cobblestone
fill 389 202 221 389 203 221 minecraft:mossy_cobblestone
setblock 391 202 183 minecraft:stone_bricks
setblock 392 202 182 minecraft:stone_bricks
fill 392 202 183 392 205 183 minecraft:mossy_cobblestone
setblock 392 202 222 minecraft:stone_bricks
fill 393 202 182 393 205 182 minecraft:mossy_cobblestone
setblock 393 202 210 minecraft:cobbled_deepslate
setblock 393 202 214 minecraft:cobbled_deepslate
setblock 393 202 221 minecraft:stone_bricks
fill 393 202 222 393 204 222 minecraft:mossy_cobblestone
setblock 394 202 221 minecraft:mossy_cobblestone
setblock 396 202 183 minecraft:stone_bricks
setblock 397 202 182 minecraft:stone_bricks
fill 397 202 183 397 204 183 minecraft:mossy_cobblestone
setblock 397 202 222 minecraft:stone_bricks
fill 398 202 182 401 202 182 minecraft:mossy_cobblestone
setblock 398 202 222 minecraft:mossy_cobblestone
setblock 401 202 183 minecraft:stone_bricks
setblock 402 202 182 minecraft:stone_bricks
fill 402 202 183 402 205 183 minecraft:mossy_cobblestone
fill 403 202 182 403 205 182 minecraft:mossy_cobblestone
setblock 403 202 222 minecraft:mossy_cobblestone
setblock 406 202 183 minecraft:stone_bricks
fill 406 202 184 406 205 184 minecraft:mossy_cobblestone
setblock 407 202 182 minecraft:stone_bricks
fill 407 202 183 407 205 183 minecraft:mossy_cobblestone
setblock 407 202 222 minecraft:stone_bricks
fill 408 202 182 408 205 182 minecraft:mossy_cobblestone
setblock 408 202 221 minecraft:stone_bricks
fill 408 202 222 408 205 222 minecraft:mossy_cobblestone
fill 409 202 221 409 205 221 minecraft:mossy_cobblestone
setblock 410 202 184 minecraft:stone_bricks
fill 410 202 185 410 205 185 minecraft:mossy_cobblestone
setblock 410 202 220 minecraft:mossy_cobblestone
setblock 411 202 183 minecraft:stone_bricks
fill 411 202 184 411 205 184 minecraft:mossy_cobblestone
setblock 412 202 182 minecraft:stone_bricks
fill 412 202 183 412 205 183 minecraft:mossy_cobblestone
setblock 412 202 185 minecraft:mossy_cobblestone
setblock 412 202 222 minecraft:stone_bricks
fill 413 202 182 413 205 182 minecraft:mossy_cobblestone
setblock 413 202 221 minecraft:stone_bricks
fill 413 202 222 413 205 222 minecraft:mossy_cobblestone
setblock 414 202 220 minecraft:stone_bricks
fill 414 202 221 414 205 221 minecraft:mossy_cobblestone
setblock 415 202 184 minecraft:stone_bricks
setblock 415 202 185 minecraft:mossy_cobblestone
setblock 415 202 219 minecraft:stone_bricks
setblock 415 202 220 minecraft:mossy_cobblestone
setblock 416 202 183 minecraft:stone_bricks
fill 416 202 184 416 205 184 minecraft:mossy_cobblestone
setblock 416 202 203 minecraft:stone_bricks
setblock 416 202 218 minecraft:stone_bricks
fill 416 202 219 416 203 219 minecraft:mossy_cobblestone
setblock 417 202 182 minecraft:stone_bricks
fill 417 202 183 417 205 183 minecraft:mossy_cobblestone
setblock 417 202 187 minecraft:stone_bricks
setblock 417 202 202 minecraft:stone_bricks
fill 417 202 203 417 203 203 minecraft:mossy_cobblestone
fill 417 202 205 417 202 206 minecraft:mossy_cobblestone
setblock 417 202 207 minecraft:stone_bricks
fill 417 202 208 417 203 208 minecraft:mossy_cobblestone
setblock 417 202 217 minecraft:stone_bricks
fill 417 202 218 417 204 218 minecraft:mossy_cobblestone
setblock 417 202 222 minecraft:stone_bricks
fill 377 203 182 377 204 182 minecraft:mossy_cobblestone
setblock 377 203 201 minecraft:stone_bricks
fill 377 203 202 377 205 202 minecraft:mossy_cobblestone
setblock 377 203 206 minecraft:stone_bricks
fill 377 203 207 377 206 207 minecraft:mossy_cobblestone
setblock 377 203 211 minecraft:stone_bricks
setblock 377 203 212 minecraft:mossy_cobblestone
setblock 377 203 216 minecraft:stone_bricks
setblock 377 203 217 minecraft:mossy_cobblestone
setblock 377 203 221 minecraft:stone_bricks
fill 377 203 222 380 203 222 minecraft:mossy_cobblestone
setblock 378 203 205 minecraft:stone_bricks
fill 378 203 206 378 204 206 minecraft:mossy_cobblestone
setblock 381 203 222 minecraft:stone_bricks
setblock 382 203 222 minecraft:mossy_cobblestone
setblock 385 203 182 minecraft:mossy_cobblestone
setblock 386 203 182 minecraft:stone_bricks
setblock 386 203 222 minecraft:stone_bricks
fill 387 203 182 387 206 182 minecraft:mossy_cobblestone
fill 387 203 222 387 206 222 minecraft:mossy_cobblestone
fill 389 203 211 390 203 213 minecraft:lantern
setblock 390 203 183 minecraft:stone_bricks
setblock 391 203 182 minecraft:stone_bricks
fill 391 203 183 391 206 183 minecraft:mossy_cobblestone
setblock 391 203 222 minecraft:stone_bricks
fill 392 203 182 392 206 182 minecraft:mossy_cobblestone
fill 392 203 222 392 205 222 minecraft:mossy_cobblestone
setblock 395 203 183 minecraft:stone_bricks
setblock 396 203 182 minecraft:stone_bricks
fill 396 203 183 396 204 183 minecraft:mossy_cobblestone
setblock 396 203 222 minecraft:stone_bricks
fill 397 203 182 400 203 182 minecraft:mossy_cobblestone
setblock 401 203 182 minecraft:stone_bricks
setblock 401 203 183 minecraft:mossy_cobblestone
fill 402 203 182 402 206 182 minecraft:mossy_cobblestone
setblock 405 203 183 minecraft:stone_bricks
fill 405 203 184 405 206 184 minecraft:mossy_cobblestone
setblock 406 203 182 minecraft:stone_bricks
fill 406 203 183 406 206 183 minecraft:mossy_cobblestone
setblock 406 203 222 minecraft:stone_bricks
fill 407 203 182 407 206 182 minecraft:mossy_cobblestone
setblock 407 203 221 minecraft:stone_bricks
fill 407 203 222 407 206 222 minecraft:mossy_cobblestone
fill 408 203 221 408 206 221 minecraft:mossy_cobblestone
setblock 409 203 184 minecraft:stone_bricks
fill 409 203 185 409 206 185 minecraft:mossy_cobblestone
setblock 410 203 183 minecraft:stone_bricks
fill 410 203 184 410 206 184 minecraft:mossy_cobblestone
setblock 411 203 182 minecraft:stone_bricks
fill 411 203 183 411 206 183 minecraft:mossy_cobblestone
setblock 411 203 222 minecraft:stone_bricks
fill 412 203 182 412 206 182 minecraft:mossy_cobblestone
setblock 412 203 221 minecraft:stone_bricks
fill 412 203 222 412 206 222 minecraft:mossy_cobblestone
setblock 413 203 220 minecraft:stone_bricks
fill 413 203 221 413 206 221 minecraft:mossy_cobblestone
setblock 414 203 184 minecraft:stone_bricks
setblock 414 203 220 minecraft:mossy_cobblestone
setblock 415 203 183 minecraft:stone_bricks
setblock 415 203 184 minecraft:mossy_cobblestone
setblock 416 203 182 minecraft:stone_bricks
fill 416 203 183 416 205 183 minecraft:mossy_cobblestone
setblock 416 203 222 minecraft:stone_bricks
fill 417 203 182 417 206 182 minecraft:mossy_cobblestone
setblock 417 203 186 minecraft:stone_bricks
setblock 417 203 187 minecraft:mossy_cobblestone
setblock 417 203 202 minecraft:mossy_cobblestone
setblock 417 203 205 minecraft:mossy_cobblestone
setblock 417 203 206 minecraft:stone_bricks
fill 417 203 207 417 206 207 minecraft:mossy_cobblestone
setblock 417 203 217 minecraft:mossy_cobblestone
setblock 417 203 221 minecraft:stone_bricks
fill 417 203 222 417 206 222 minecraft:mossy_cobblestone
setblock 377 204 201 minecraft:mossy_cobblestone
setblock 377 204 205 minecraft:stone_bricks
fill 377 204 206 377 207 206 minecraft:mossy_cobblestone
setblock 377 204 210 minecraft:stone_bricks
fill 377 204 211 377 207 211 minecraft:mossy_cobblestone
setblock 377 204 220 minecraft:stone_bricks
fill 377 204 221 377 204 222 minecraft:mossy_cobblestone
setblock 378 204 205 minecraft:mossy_cobblestone
setblock 378 204 222 minecraft:mossy_cobblestone
setblock 385 204 182 minecraft:stone_bricks
setblock 385 204 222 minecraft:stone_bricks
fill 386 204 182 386 207 182 minecraft:mossy_cobblestone
fill 386 204 222 386 205 222 minecraft:mossy_cobblestone
setblock 389 204 183 minecraft:stone_bricks
fill 389 204 212 390 205 212 minecraft:lantern
setblock 390 204 182 minecraft:stone_bricks
fill 390 204 183 390 207 183 minecraft:mossy_cobblestone
setblock 390 204 222 minecraft:stone_bricks
fill 391 204 182 391 207 182 minecraft:mossy_cobblestone
fill 391 204 222 391 205 222 minecraft:mossy_cobblestone
setblock 394 204 183 minecraft:stone_bricks
setblock 395 204 182 minecraft:stone_bricks
fill 395 204 183 395 205 183 minecraft:mossy_cobblestone
fill 396 204 182 399 204 182 minecraft:mossy_cobblestone
setblock 400 204 182 minecraft:stone_bricks
fill 401 204 182 401 207 182 minecraft:mossy_cobblestone
setblock 404 204 183 minecraft:stone_bricks
setblock 405 204 182 minecraft:stone_bricks
fill 405 204 183 405 207 183 minecraft:mossy_cobblestone
setblock 405 204 222 minecraft:stone_bricks
fill 406 204 182 406 207 182 minecraft:mossy_cobblestone
fill 406 204 222 406 207 222 minecraft:mossy_cobblestone
fill 407 204 221 407 205 221 minecraft:mossy_cobblestone
setblock 408 204 184 minecraft:stone_bricks
setblock 409 204 183 minecraft:stone_bricks
fill 409 204 184 409 207 184 minecraft:mossy_cobblestone
setblock 410 204 182 minecraft:stone_bricks
fill 410 204 183 410 207 183 minecraft:mossy_cobblestone
setblock 410 204 222 minecraft:stone_bricks
fill 411 204 182 411 207 182 minecraft:mossy_cobblestone
setblock 411 204 221 minecraft:stone_bricks
fill 411 204 222 411 207 222 minecraft:mossy_cobblestone
fill 412 204 221 412 207 221 minecraft:mossy_cobblestone
setblock 413 204 184 minecraft:stone_bricks
setblock 414 204 183 minecraft:stone_bricks
fill 414 204 184 414 205 184 minecraft:mossy_cobblestone
setblock 415 204 182 minecraft:stone_bricks
fill 415 204 183 415 207 183 minecraft:mossy_cobblestone
setblock 415 204 222 minecraft:stone_bricks
fill 416 204 182 416 207 182 minecraft:mossy_cobblestone
setblock 416 204 221 minecraft:stone_bricks
fill 416 204 222 416 207 222 minecraft:mossy_cobblestone
setblock 417 204 185 minecraft:stone_bricks
fill 417 204 186 417 205 186 minecraft:mossy_cobblestone
setblock 417 204 205 minecraft:stone_bricks
fill 417 204 206 417 207 206 minecraft:mossy_cobblestone
setblock 417 204 220 minecraft:stone_bricks
fill 417 204 221 417 206 221 minecraft:mossy_cobblestone
setblock 377 205 204 minecraft:stone_bricks
fill 377 205 205 377 208 205 minecraft:mossy_cobblestone
setblock 377 205 209 minecraft:stone_bricks
fill 377 205 210 377 208 210 minecraft:mossy_cobblestone
setblock 377 205 222 minecraft:mossy_cobblestone
fill 385 205 182 385 208 182 minecraft:mossy_cobblestone
setblock 387 205 183 minecraft:mossy_cobblestone
setblock 388 205 183 minecraft:stone_bricks
setblock 389 205 182 minecraft:stone_bricks
fill 389 205 183 389 208 183 minecraft:mossy_cobblestone
setblock 389 205 222 minecraft:stone_bricks
fill 390 205 182 390 208 182 minecraft:mossy_cobblestone
fill 390 205 222 390 206 222 minecraft:mossy_cobblestone
setblock 393 205 183 minecraft:stone_bricks
setblock 394 205 182 minecraft:stone_bricks
fill 394 205 183 394 207 183 minecraft:mossy_cobblestone
fill 395 205 182 398 205 182 minecraft:mossy_cobblestone
setblock 399 205 182 minecraft:stone_bricks
fill 400 205 182 400 208 182 minecraft:mossy_cobblestone
setblock 403 205 183 minecraft:stone_bricks
setblock 404 205 182 minecraft:stone_bricks
fill 404 205 183 404 208 183 minecraft:mossy_cobblestone
setblock 404 205 222 minecraft:stone_bricks
fill 405 205 182 405 208 182 minecraft:mossy_cobblestone
fill 405 205 222 405 208 222 minecraft:mossy_cobblestone
setblock 407 205 184 minecraft:stone_bricks
setblock 408 205 183 minecraft:stone_bricks
fill 408 205 184 408 208 184 minecraft:mossy_cobblestone
setblock 409 205 182 minecraft:stone_bricks
fill 409 205 183 409 208 183 minecraft:mossy_cobblestone
setblock 409 205 222 minecraft:stone_bricks
fill 410 205 182 410 208 182 minecraft:mossy_cobblestone
setblock 410 205 221 minecraft:stone_bricks
fill 410 205 222 410 208 222 minecraft:mossy_cobblestone
fill 411 205 221 411 208 221 minecraft:mossy_cobblestone
setblock 412 205 184 minecraft:stone_bricks
setblock 413 205 183 minecraft:stone_bricks
fill 413 205 184 413 206 184 minecraft:mossy_cobblestone
setblock 414 205 182 minecraft:stone_bricks
fill 414 205 183 414 208 183 minecraft:mossy_cobblestone
setblock 414 205 222 minecraft:stone_bricks
fill 415 205 182 415 208 182 minecraft:mossy_cobblestone
setblock 415 205 221 minecraft:stone_bricks
fill 415 205 222 415 208 222 minecraft:mossy_cobblestone
setblock 417 205 184 minecraft:stone_bricks
fill 417 205 185 417 208 185 minecraft:mossy_cobblestone
setblock 417 205 205 minecraft:mossy_cobblestone
setblock 417 205 220 minecraft:mossy_cobblestone
setblock 377 206 203 minecraft:stone_bricks
fill 377 206 204 377 209 204 minecraft:mossy_cobblestone
setblock 377 206 208 minecraft:stone_bricks
fill 377 206 209 377 209 209 minecraft:mossy_cobblestone
setblock 387 206 183 minecraft:stone_bricks
setblock 388 206 182 minecraft:stone_bricks
fill 388 206 183 388 209 183 minecraft:mossy_cobblestone
setblock 388 206 222 minecraft:stone_bricks
fill 389 206 182 389 209 182 minecraft:mossy_cobblestone
setblock 389 206 212 minecraft:lantern
setblock 389 206 222 minecraft:mossy_cobblestone
setblock 392 206 183 minecraft:stone_bricks
setblock 393 206 182 minecraft:stone_bricks
fill 393 206 183 393 209 183 minecraft:mossy_cobblestone
fill 394 206 182 397 206 182 minecraft:mossy_cobblestone
setblock 398 206 182 minecraft:stone_bricks
fill 399 206 182 399 209 182 minecraft:mossy_cobblestone
setblock 401 206 183 minecraft:mossy_cobblestone
setblock 402 206 183 minecraft:stone_bricks
setblock 403 206 182 minecraft:stone_bricks
fill 403 206 183 403 209 183 minecraft:mossy_cobblestone
fill 404 206 182 404 209 182 minecraft:mossy_cobblestone
fill 404 206 184 404 207 184 minecraft:mossy_cobblestone
fill 404 206 222 404 209 222 minecraft:mossy_cobblestone
setblock 406 206 184 minecraft:stone_bricks
setblock 407 206 183 minecraft:stone_bricks
fill 407 206 184 407 209 184 minecraft:mossy_cobblestone
setblock 408 206 182 minecraft:stone_bricks
fill 408 206 183 408 209 183 minecraft:mossy_cobblestone
fill 408 206 185 408 207 185 minecraft:mossy_cobblestone
setblock 408 206 222 minecraft:stone_bricks
fill 409 206 182 409 209 182 minecraft:mossy_cobblestone
setblock 409 206 221 minecraft:stone_bricks
fill 409 206 222 409 209 222 minecraft:mossy_cobblestone
fill 410 206 221 410 209 221 minecraft:mossy_cobblestone
setblock 411 206 184 minecraft:stone_bricks
setblock 412 206 183 minecraft:stone_bricks
fill 412 206 184 412 209 184 minecraft:mossy_cobblestone
setblock 413 206 182 minecraft:stone_bricks
fill 413 206 183 413 209 183 minecraft:mossy_cobblestone
setblock 413 206 222 minecraft:stone_bricks
fill 414 206 182 414 209 182 minecraft:mossy_cobblestone
setblock 414 206 221 minecraft:stone_bricks
fill 414 206 222 414 209 222 minecraft:mossy_cobblestone
setblock 417 206 183 minecraft:stone_bricks
fill 417 206 184 417 209 184 minecraft:mossy_cobblestone
setblock 417 206 208 minecraft:stone_bricks
fill 377 207 203 377 210 203 minecraft:mossy_cobblestone
setblock 377 207 207 minecraft:stone_bricks
fill 377 207 208 377 210 208 minecraft:mossy_cobblestone
setblock 377 207 212 minecraft:stone_bricks
setblock 378 207 206 minecraft:stone_bricks
fill 378 207 207 378 210 207 minecraft:mossy_cobblestone
setblock 387 207 182 minecraft:stone_bricks
fill 387 207 183 387 210 183 minecraft:mossy_cobblestone
fill 388 207 182 388 210 182 minecraft:mossy_cobblestone
setblock 391 207 183 minecraft:stone_bricks
setblock 392 207 182 minecraft:stone_bricks
fill 392 207 183 392 210 183 minecraft:mossy_cobblestone
fill 393 207 182 396 207 182 minecraft:mossy_cobblestone
setblock 397 207 182 minecraft:stone_bricks
fill 398 207 182 398 210 182 minecraft:mossy_cobblestone
setblock 401 207 183 minecraft:stone_bricks
setblock 402 207 182 minecraft:stone_bricks
fill 402 207 183 402 210 183 minecraft:mossy_cobblestone
fill 403 207 182 403 210 182 minecraft:mossy_cobblestone
setblock 405 207 184 minecraft:stone_bricks
setblock 406 207 183 minecraft:stone_bricks
fill 406 207 184 406 210 184 minecraft:mossy_cobblestone
setblock 407 207 182 minecraft:stone_bricks
fill 407 207 183 407 210 183 minecraft:mossy_cobblestone
fill 407 207 185 407 208 185 minecraft:mossy_cobblestone
setblock 407 207 222 minecraft:stone_bricks
fill 408 207 182 408 210 182 minecraft:mossy_cobblestone
setblock 408 207 221 minecraft:stone_bricks
fill 408 207 222 408 210 222 minecraft:mossy_cobblestone
setblock 409 207 185 minecraft:stone_bricks
fill 409 207 221 409 210 221 minecraft:mossy_cobblestone
setblock 410 207 184 minecraft:stone_bricks
setblock 411 207 183 minecraft:stone_bricks
fill 411 207 184 411 210 184 minecraft:mossy_cobblestone
setblock 412 207 182 minecraft:stone_bricks
fill 412 207 183 412 210 183 minecraft:mossy_cobblestone
setblock 412 207 222 minecraft:stone_bricks
fill 413 207 182 413 210 182 minecraft:mossy_cobblestone
fill 413 207 222 413 210 222 minecraft:mossy_cobblestone
setblock 417 207 182 minecraft:stone_bricks
fill 417 207 183 417 208 183 minecraft:mossy_cobblestone
setblock 417 207 207 minecraft:stone_bricks
fill 417 207 208 417 208 210 minecraft:mossy_cobblestone
setblock 417 207 222 minecraft:stone_bricks
setblock 377 208 206 minecraft:stone_bricks
fill 377 208 207 377 211 207 minecraft:mossy_cobblestone
setblock 377 208 211 minecraft:stone_bricks
fill 377 208 212 377 210 213 minecraft:mossy_cobblestone
fill 378 208 206 378 211 206 minecraft:mossy_cobblestone
fill 378 208 208 378 208 209 minecraft:mossy_cobblestone
fill 384 208 182 384 209 182 minecraft:mossy_cobblestone
setblock 386 208 182 minecraft:stone_bricks
fill 386 208 183 386 211 183 minecraft:mossy_cobblestone
fill 387 208 182 387 211 182 minecraft:mossy_cobblestone
setblock 390 208 183 minecraft:stone_bricks
setblock 391 208 182 minecraft:stone_bricks
fill 391 208 183 391 211 183 minecraft:mossy_cobblestone
fill 392 208 182 395 208 182 minecraft:mossy_cobblestone
setblock 396 208 182 minecraft:stone_bricks
fill 397 208 182 397 211 182 minecraft:mossy_cobblestone
setblock 400 208 183 minecraft:stone_bricks
setblock 401 208 182 minecraft:stone_bricks
fill 401 208 183 401 211 183 minecraft:mossy_cobblestone
fill 402 208 182 402 211 182 minecraft:mossy_cobblestone
setblock 403 208 184 minecraft:mossy_cobblestone
setblock 404 208 184 minecraft:stone_bricks
setblock 405 208 183 minecraft:stone_bricks
fill 405 208 184 405 211 184 minecraft:mossy_cobblestone
setblock 406 208 182 minecraft:stone_bricks
fill 406 208 183 406 211 183 minecraft:mossy_cobblestone
fill 406 208 185 406 209 185 minecraft:mossy_cobblestone
setblock 406 208 222 minecraft:stone_bricks
fill 407 208 182 407 211 182 minecraft:mossy_cobblestone
setblock 407 208 221 minecraft:stone_bricks
fill 407 208 222 407 211 222 minecraft:mossy_cobblestone
setblock 408 208 185 minecraft:stone_bricks
fill 408 208 221 408 211 221 minecraft:mossy_cobblestone
setblock 409 208 184 minecraft:stone_bricks
fill 409 208 185 409 211 185 minecraft:mossy_cobblestone
setblock 410 208 183 minecraft:stone_bricks
fill 410 208 184 410 211 184 minecraft:mossy_cobblestone
setblock 411 208 182 minecraft:stone_bricks
fill 411 208 183 411 211 183 minecraft:mossy_cobblestone
setblock 411 208 222 minecraft:stone_bricks
fill 412 208 182 412 211 182 minecraft:mossy_cobblestone
setblock 412 208 221 minecraft:stone_bricks
fill 412 208 222 412 211 222 minecraft:mossy_cobblestone
setblock 416 208 182 minecraft:stone_bricks
setblock 416 208 222 minecraft:stone_bricks
setblock 417 208 206 minecraft:stone_bricks
fill 417 208 207 417 211 207 minecraft:mossy_cobblestone
setblock 417 208 211 minecraft:stone_bricks
setblock 377 209 205 minecraft:stone_bricks
fill 377 209 206 377 212 206 minecraft:mossy_cobblestone
setblock 377 209 210 minecraft:stone_bricks
fill 377 209 211 378 211 211 minecraft:mossy_cobblestone
setblock 377 209 214 minecraft:mossy_cobblestone
fill 378 209 205 378 212 205 minecraft:mossy_cobblestone
setblock 378 209 208 minecraft:mossy_cobblestone
setblock 378 209 209 minecraft:stone_bricks
fill 378 209 210 378 212 210 minecraft:mossy_cobblestone
setblock 379 209 184 minecraft:light[level=12]
setblock 379 209 192 minecraft:light[level=12]
setblock 379 209 200 minecraft:light[level=12]
setblock 379 209 208 minecraft:light[level=12]
setblock 379 209 216 minecraft:light[level=12]
setblock 385 209 182 minecraft:stone_bricks
fill 385 209 183 385 212 183 minecraft:mossy_cobblestone
fill 386 209 182 386 212 182 minecraft:mossy_cobblestone
setblock 387 209 184 minecraft:light[level=12]
setblock 387 209 192 minecraft:light[level=12]
setblock 387 209 200 minecraft:light[level=12]
setblock 387 209 208 minecraft:light[level=12]
setblock 387 209 216 minecraft:light[level=12]
setblock 389 209 183 minecraft:stone_bricks
fill 389 209 184 389 212 184 minecraft:mossy_cobblestone
setblock 390 209 182 minecraft:stone_bricks
fill 390 209 183 390 212 183 minecraft:mossy_cobblestone
fill 391 209 182 394 209 182 minecraft:mossy_cobblestone
setblock 395 209 182 minecraft:stone_bricks
setblock 395 209 184 minecraft:light[level=12]
setblock 395 209 192 minecraft:light[level=12]
setblock 395 209 200 minecraft:light[level=12]
setblock 395 209 208 minecraft:light[level=12]
setblock 395 209 216 minecraft:light[level=12]
fill 396 209 182 396 212 182 minecraft:mossy_cobblestone
setblock 400 209 182 minecraft:stone_bricks
fill 400 209 183 400 212 183 minecraft:mossy_cobblestone
fill 401 209 182 401 212 182 minecraft:mossy_cobblestone
setblock 402 209 184 minecraft:mossy_cobblestone
setblock 403 209 184 minecraft:stone_bricks
setblock 403 209 192 minecraft:light[level=12]
setblock 403 209 200 minecraft:light[level=12]
setblock 403 209 208 minecraft:light[level=12]
setblock 403 209 216 minecraft:light[level=12]
fill 403 209 222 403 210 222 minecraft:mossy_cobblestone
setblock 404 209 183 minecraft:stone_bricks
fill 404 209 184 404 212 184 minecraft:mossy_cobblestone
setblock 405 209 182 minecraft:stone_bricks
fill 405 209 183 405 212 183 minecraft:mossy_cobblestone
fill 405 209 185 405 210 185 minecraft:mossy_cobblestone
setblock 405 209 222 minecraft:stone_bricks
fill 406 209 182 406 212 182 minecraft:mossy_cobblestone
setblock 406 209 221 minecraft:stone_bricks
fill 406 209 222 406 212 222 minecraft:mossy_cobblestone
setblock 407 209 185 minecraft:stone_bricks
fill 407 209 221 407 212 221 minecraft:mossy_cobblestone
setblock 408 209 184 minecraft:stone_bricks
fill 408 209 185 408 212 185 minecraft:mossy_cobblestone
setblock 409 209 183 minecraft:stone_bricks
fill 409 209 184 409 212 184 minecraft:mossy_cobblestone
setblock 410 209 182 minecraft:stone_bricks
fill 410 209 183 410 212 183 minecraft:mossy_cobblestone
setblock 410 209 222 minecraft:stone_bricks
fill 411 209 182 411 212 182 minecraft:mossy_cobblestone
setblock 411 209 192 minecraft:light[level=12]
setblock 411 209 200 minecraft:light[level=12]
setblock 411 209 208 minecraft:light[level=12]
setblock 411 209 216 minecraft:light[level=12]
setblock 411 209 221 minecraft:stone_bricks
fill 411 209 222 411 212 222 minecraft:mossy_cobblestone
setblock 414 209 183 minecraft:stone_bricks
setblock 415 209 182 minecraft:stone_bricks
setblock 415 209 222 minecraft:stone_bricks
setblock 416 209 182 minecraft:mossy_cobblestone
setblock 417 209 185 minecraft:stone_bricks
fill 417 209 206 417 212 206 minecraft:mossy_cobblestone
fill 417 209 208 417 209 209 minecraft:mossy_cobblestone
setblock 417 209 210 minecraft:stone_bricks
fill 417 209 211 417 210 213 minecraft:mossy_cobblestone
setblock 377 210 204 minecraft:stone_bricks
fill 377 210 205 377 213 205 minecraft:mossy_cobblestone
setblock 377 210 209 minecraft:stone_bricks
fill 377 210 210 377 213 210 minecraft:mossy_cobblestone
setblock 377 210 214 minecraft:stone_bricks
fill 377 210 215 377 213 215 minecraft:mossy_cobblestone
setblock 378 210 208 minecraft:stone_bricks
fill 378 210 209 378 213 209 minecraft:mossy_cobblestone
setblock 378 210 212 minecraft:mossy_cobblestone
setblock 383 210 182 minecraft:mossy_cobblestone
setblock 384 210 182 minecraft:stone_bricks
fill 385 210 182 385 213 182 minecraft:mossy_cobblestone
setblock 387 210 184 minecraft:stone_bricks
setblock 388 210 183 minecraft:stone_bricks
fill 388 210 184 388 212 184 minecraft:mossy_cobblestone
setblock 389 210 182 minecraft:stone_bricks
fill 389 210 183 389 213 183 minecraft:mossy_cobblestone
fill 390 210 182 393 210 182 minecraft:mossy_cobblestone
setblock 393 210 183 minecraft:stone_bricks
setblock 394 210 182 minecraft:stone_bricks
fill 395 210 182 395 213 182 minecraft:mossy_cobblestone
setblock 399 210 182 minecraft:stone_bricks
fill 399 210 183 399 213 183 minecraft:mossy_cobblestone
fill 400 210 182 400 213 182 minecraft:mossy_cobblestone
setblock 401 210 184 minecraft:mossy_cobblestone
setblock 402 210 184 minecraft:stone_bricks
setblock 403 210 183 minecraft:stone_bricks
fill 403 210 184 403 213 184 minecraft:mossy_cobblestone
setblock 404 210 182 minecraft:stone_bricks
fill 404 210 183 404 213 183 minecraft:mossy_cobblestone
fill 404 210 185 404 211 185 minecraft:mossy_cobblestone
setblock 404 210 222 minecraft:stone_bricks
fill 405 210 182 405 213 182 minecraft:mossy_cobblestone
fill 405 210 222 405 213 222 minecraft:mossy_cobblestone
setblock 406 210 185 minecraft:stone_bricks
fill 406 210 221 406 213 221 minecraft:mossy_cobblestone
setblock 407 210 184 minecraft:stone_bricks
fill 407 210 185 407 213 185 minecraft:mossy_cobblestone
setblock 408 210 183 minecraft:stone_bricks
fill 408 210 184 408 213 184 minecraft:mossy_cobblestone
setblock 409 210 182 minecraft:stone_bricks
fill 409 210 183 409 213 183 minecraft:mossy_cobblestone
setblock 409 210 222 minecraft:stone_bricks
fill 410 210 182 410 213 182 minecraft:mossy_cobblestone
setblock 410 210 221 minecraft:stone_bricks
fill 410 210 222 410 213 222 minecraft:mossy_cobblestone
fill 411 210 221 411 213 221 minecraft:mossy_cobblestone
setblock 413 210 183 minecraft:stone_bricks
setblock 414 210 182 minecraft:stone_bricks
setblock 414 210 222 minecraft:stone_bricks
fill 415 210 182 415 211 182 minecraft:mossy_cobblestone
fill 415 210 222 415 211 222 minecraft:mossy_cobblestone
setblock 416 210 209 minecraft:mossy_cobblestone
setblock 416 210 210 minecraft:stone_bricks
fill 416 210 211 416 213 211 minecraft:mossy_cobblestone
fill 417 210 185 417 211 186 minecraft:mossy_cobblestone
fill 417 210 205 417 213 205 minecraft:mossy_cobblestone
setblock 417 210 208 minecraft:mossy_cobblestone
setblock 417 210 209 minecraft:stone_bricks
fill 417 210 210 417 213 210 minecraft:mossy_cobblestone
setblock 417 210 214 minecraft:stone_bricks
fill 417 210 215 417 213 215 minecraft:mossy_cobblestone
setblock 377 211 203 minecraft:stone_bricks
fill 377 211 204 377 213 204 minecraft:mossy_cobblestone
setblock 377 211 208 minecraft:stone_bricks
fill 377 211 209 377 213 209 minecraft:mossy_cobblestone
setblock 377 211 212 minecraft:mossy_cobblestone
setblock 377 211 213 minecraft:stone_bricks
fill 377 211 214 377 213 214 minecraft:mossy_cobblestone
fill 377 211 216 377 212 216 minecraft:mossy_cobblestone
setblock 378 211 207 minecraft:stone_bricks
fill 378 211 208 379 213 208 minecraft:mossy_cobblestone
setblock 378 211 212 minecraft:stone_bricks
fill 378 211 213 378 213 213 minecraft:mossy_cobblestone
fill 379 211 207 379 213 207 minecraft:mossy_cobblestone
fill 379 211 209 379 211 210 minecraft:mossy_cobblestone
setblock 379 211 211 minecraft:stone_bricks
setblock 382 211 182 minecraft:mossy_cobblestone
setblock 383 211 182 minecraft:stone_bricks
fill 384 211 182 384 213 183 minecraft:mossy_cobblestone
setblock 386 211 184 minecraft:stone_bricks
setblock 387 211 183 minecraft:stone_bricks
fill 387 211 184 387 213 184 minecraft:mossy_cobblestone
setblock 388 211 182 minecraft:stone_bricks
fill 388 211 183 388 213 183 minecraft:mossy_cobblestone
fill 389 211 182 392 211 182 minecraft:mossy_cobblestone
setblock 392 211 183 minecraft:stone_bricks
setblock 393 211 182 minecraft:stone_bricks
fill 394 211 182 394 213 182 minecraft:mossy_cobblestone
setblock 398 211 182 minecraft:stone_bricks
fill 398 211 183 398 213 183 minecraft:mossy_cobblestone
fill 399 211 182 399 213 182 minecraft:mossy_cobblestone
setblock 400 211 184 minecraft:mossy_cobblestone
setblock 401 211 184 minecraft:stone_bricks
setblock 402 211 183 minecraft:stone_bricks
fill 402 211 184 402 213 184 minecraft:mossy_cobblestone
setblock 402 211 222 minecraft:mossy_cobblestone
setblock 403 211 182 minecraft:stone_bricks
fill 403 211 183 403 213 183 minecraft:mossy_cobblestone
fill 403 211 185 403 212 185 minecraft:mossy_cobblestone
setblock 403 211 222 minecraft:stone_bricks
fill 404 211 182 404 213 182 minecraft:mossy_cobblestone
fill 404 211 222 404 213 222 minecraft:mossy_cobblestone
setblock 405 211 185 minecraft:stone_bricks
fill 405 211 221 405 213 221 minecraft:mossy_cobblestone
setblock 406 211 184 minecraft:stone_bricks
fill 406 211 185 406 213 185 minecraft:mossy_cobblestone
setblock 407 211 183 minecraft:stone_bricks
fill 407 211 184 407 213 184 minecraft:mossy_cobblestone
setblock 408 211 182 minecraft:stone_bricks
fill 408 211 183 408 213 183 minecraft:mossy_cobblestone
setblock 408 211 222 minecraft:stone_bricks
fill 409 211 182 409 213 182 minecraft:mossy_cobblestone
setblock 409 211 221 minecraft:stone_bricks
fill 409 211 222 409 213 222 minecraft:mossy_cobblestone
fill 410 211 221 410 213 221 minecraft:mossy_cobblestone
setblock 411 211 184 minecraft:stone_bricks
setblock 412 211 183 minecraft:stone_bricks
setblock 413 211 182 minecraft:stone_bricks
setblock 413 211 183 minecraft:mossy_cobblestone
setblock 413 211 222 minecraft:stone_bricks
fill 414 211 182 414 212 182 minecraft:mossy_cobblestone
fill 414 211 222 414 213 222 minecraft:mossy_cobblestone
setblock 416 211 208 minecraft:mossy_cobblestone
setblock 416 211 209 minecraft:stone_bricks
fill 416 211 210 416 213 210 minecraft:mossy_cobblestone
fill 416 211 212 416 211 213 minecraft:mossy_cobblestone
setblock 417 211 187 minecraft:mossy_cobblestone
setblock 417 211 208 minecraft:stone_bricks
fill 417 211 209 417 213 209 minecraft:mossy_cobblestone
fill 417 211 211 417 211 212 minecraft:mossy_cobblestone
setblock 417 211 213 minecraft:stone_bricks
fill 417 211 214 417 213 214 minecraft:mossy_cobblestone
fill 417 211 216 417 211 217 minecraft:mossy_cobblestone
setblock 377 212 187 minecraft:stone_bricks
fill 377 212 188 377 212 191 minecraft:mossy_cobblestone
setblock 377 212 202 minecraft:stone_bricks
fill 377 212 203 377 213 203 minecraft:mossy_cobblestone
setblock 377 212 207 minecraft:stone_bricks
fill 377 212 208 377 213 208 minecraft:mossy_cobblestone
setblock 377 212 211 minecraft:mossy_cobblestone
setblock 377 212 212 minecraft:stone_bricks
fill 377 212 213 377 213 213 minecraft:mossy_cobblestone
fill 378 212 204 378 213 204 minecraft:mossy_cobblestone
setblock 378 212 206 minecraft:stone_bricks
fill 378 212 207 378 213 207 minecraft:mossy_cobblestone
setblock 378 212 211 minecraft:stone_bricks
fill 378 212 212 379 213 212 minecraft:mossy_cobblestone
fill 378 212 214 378 213 214 minecraft:mossy_cobblestone
fill 379 212 206 379 213 206 minecraft:mossy_cobblestone
setblock 379 212 209 minecraft:mossy_cobblestone
setblock 379 212 210 minecraft:stone_bricks
fill 379 212 211 379 213 211 minecraft:mossy_cobblestone
setblock 382 212 182 minecraft:stone_bricks
fill 383 212 182 383 213 182 minecraft:mossy_cobblestone
fill 385 212 222 386 212 222 minecraft:mossy_cobblestone
setblock 386 212 183 minecraft:stone_bricks
fill 386 212 184 386 213 184 minecraft:mossy_cobblestone
setblock 387 212 182 minecraft:stone_bricks
fill 387 212 183 387 213 183 minecraft:mossy_cobblestone
fill 388 212 182 391 212 182 minecraft:mossy_cobblestone
setblock 391 212 183 minecraft:stone_bricks
setblock 392 212 182 minecraft:stone_bricks
setblock 392 212 183 minecraft:mossy_cobblestone
fill 393 212 182 393 213 182 minecraft:mossy_cobblestone
setblock 397 212 182 minecraft:stone_bricks
fill 398 212 182 398 213 182 minecraft:mossy_cobblestone
setblock 400 212 184 minecraft:stone_bricks
setblock 401 212 183 minecraft:stone_bricks
fill 401 212 184 401 213 184 minecraft:mossy_cobblestone
setblock 401 212 222 minecraft:mossy_cobblestone
setblock 402 212 182 minecraft:stone_bricks
fill 402 212 183 402 213 183 minecraft:mossy_cobblestone
fill 402 212 185 402 213 185 minecraft:mossy_cobblestone
setblock 402 212 222 minecraft:stone_bricks
fill 403 212 182 403 213 182 minecraft:mossy_cobblestone
fill 403 212 222 403 213 222 minecraft:mossy_cobblestone
setblock 404 212 185 minecraft:stone_bricks
fill 404 212 221 404 213 221 minecraft:mossy_cobblestone
setblock 405 212 184 minecraft:stone_bricks
fill 405 212 185 405 213 185 minecraft:mossy_cobblestone
setblock 406 212 183 minecraft:stone_bricks
fill 406 212 184 406 213 184 minecraft:mossy_cobblestone
setblock 407 212 182 minecraft:stone_bricks
fill 407 212 183 407 213 183 minecraft:mossy_cobblestone
setblock 407 212 222 minecraft:stone_bricks
fill 408 212 182 408 213 182 minecraft:mossy_cobblestone
setblock 408 212 221 minecraft:stone_bricks
fill 408 212 222 408 213 222 minecraft:mossy_cobblestone
fill 409 212 221 409 213 221 minecraft:mossy_cobblestone
setblock 410 212 184 minecraft:stone_bricks
setblock 411 212 183 minecraft:stone_bricks
setblock 412 212 182 minecraft:stone_bricks
setblock 412 212 183 minecraft:mossy_cobblestone
setblock 412 212 222 minecraft:stone_bricks
fill 413 212 182 413 213 182 minecraft:mossy_cobblestone
fill 413 212 222 413 213 222 minecraft:mossy_cobblestone
setblock 416 212 208 minecraft:stone_bricks
fill 416 212 209 416 213 209 minecraft:mossy_cobblestone
setblock 416 212 212 minecraft:mossy_cobblestone
setblock 416 212 213 minecraft:stone_bricks
fill 416 212 214 416 213 215 minecraft:mossy_cobblestone
setblock 417 212 186 minecraft:mossy_cobblestone
setblock 417 212 187 minecraft:stone_bricks
fill 417 212 188 417 213 189 minecraft:mossy_cobblestone
setblock 417 212 207 minecraft:stone_bricks
fill 417 212 208 417 213 208 minecraft:mossy_cobblestone
setblock 417 212 211 minecraft:mossy_cobblestone
setblock 417 212 212 minecraft:stone_bricks
fill 417 212 213 417 213 213 minecraft:mossy_cobblestone
setblock 417 212 216 minecraft:mossy_cobblestone
setblock 417 212 217 minecraft:stone_bricks
fill 417 212 218 417 213 219 minecraft:mossy_cobblestone
fill 377 213 187 377 213 190 minecraft:mossy_cobblestone
setblock 377 213 191 minecraft:stone_bricks
fill 377 213 192 377 213 194 minecraft:mossy_cobblestone
setblock 377 213 202 minecraft:mossy_cobblestone
setblock 377 213 206 minecraft:stone_bricks
setblock 377 213 207 minecraft:mossy_cobblestone
setblock 377 213 211 minecraft:stone_bricks
setblock 377 213 212 minecraft:mossy_cobblestone
setblock 377 213 216 minecraft:stone_bricks
setblock 377 213 217 minecraft:mossy_cobblestone
setblock 378 213 205 minecraft:stone_bricks
setblock 378 213 206 minecraft:mossy_cobblestone
setblock 378 213 210 minecraft:stone_bricks
setblock 378 213 211 minecraft:mossy_cobblestone
setblock 378 213 215 minecraft:stone_bricks
setblock 379 213 209 minecraft:stone_bricks
setblock 379 213 210 minecraft:mossy_cobblestone
setblock 379 213 213 minecraft:mossy_cobblestone
setblock 382 213 182 minecraft:mossy_cobblestone
fill 384 213 222 385 213 222 minecraft:mossy_cobblestone
setblock 385 213 183 minecraft:stone_bricks
setblock 386 213 182 minecraft:stone_bricks
setblock 386 213 183 minecraft:mossy_cobblestone
setblock 386 213 222 minecraft:stone_bricks
fill 387 213 182 390 213 182 minecraft:mossy_cobblestone
setblock 390 213 183 minecraft:stone_bricks
setblock 391 213 182 minecraft:stone_bricks
setblock 392 213 182 minecraft:mossy_cobblestone
setblock 396 213 182 minecraft:stone_bricks
setblock 397 213 182 minecraft:mossy_cobblestone
setblock 400 213 183 minecraft:stone_bricks
setblock 400 213 184 minecraft:mossy_cobblestone
setblock 400 213 222 minecraft:mossy_cobblestone
setblock 401 213 182 minecraft:stone_bricks
setblock 401 213 183 minecraft:mossy_cobblestone
setblock 401 213 222 minecraft:stone_bricks
setblock 402 213 182 minecraft:mossy_cobblestone
setblock 402 213 222 minecraft:mossy_cobblestone
setblock 403 213 185 minecraft:stone_bricks
setblock 403 213 221 minecraft:mossy_cobblestone
setblock 404 213 184 minecraft:stone_bricks
setblock 404 213 185 minecraft:mossy_cobblestone
setblock 405 213 183 minecraft:stone_bricks
setblock 405 213 184 minecraft:mossy_cobblestone
setblock 406 213 182 minecraft:stone_bricks
setblock 406 213 183 minecraft:mossy_cobblestone
setblock 406 213 222 minecraft:stone_bricks
setblock 407 213 182 minecraft:mossy_cobblestone
setblock 407 213 221 minecraft:stone_bricks
setblock 407 213 222 minecraft:mossy_cobblestone
setblock 408 213 221 minecraft:mossy_cobblestone
setblock 409 213 184 minecraft:stone_bricks
setblock 410 213 183 minecraft:stone_bricks
setblock 411 213 182 minecraft:stone_bricks
setblock 411 213 183 minecraft:mossy_cobblestone
setblock 411 213 222 minecraft:stone_bricks
setblock 412 213 182 minecraft:mossy_cobblestone
setblock 412 213 222 minecraft:mossy_cobblestone
setblock 416 213 208 minecraft:mossy_cobblestone
setblock 416 213 212 minecraft:stone_bricks
setblock 416 213 213 minecraft:mossy_cobblestone
setblock 416 213 216 minecraft:mossy_cobblestone
setblock 417 213 186 minecraft:stone_bricks
setblock 417 213 187 minecraft:mossy_cobblestone
setblock 417 213 190 minecraft:mossy_cobblestone
setblock 417 213 206 minecraft:stone_bricks
setblock 417 213 207 minecraft:mossy_cobblestone
setblock 417 213 211 minecraft:stone_bricks
setblock 417 213 212 minecraft:mossy_cobblestone
setblock 417 213 216 minecraft:stone_bricks
setblock 417 213 217 minecraft:mossy_cobblestone
setblock 417 213 220 minecraft:mossy_cobblestone
setblock 379 217 184 minecraft:light[level=12]
setblock 379 217 192 minecraft:light[level=12]
setblock 379 217 200 minecraft:light[level=12]
setblock 379 217 208 minecraft:light[level=12]
setblock 379 217 216 minecraft:light[level=12]
setblock 387 217 184 minecraft:light[level=12]
setblock 387 217 192 minecraft:light[level=12]
setblock 387 217 200 minecraft:light[level=12]
setblock 387 217 208 minecraft:light[level=12]
setblock 387 217 216 minecraft:light[level=12]
setblock 395 217 184 minecraft:light[level=12]
setblock 395 217 192 minecraft:light[level=12]
setblock 395 217 200 minecraft:light[level=12]
setblock 395 217 208 minecraft:light[level=12]
setblock 395 217 216 minecraft:light[level=12]
setblock 403 217 184 minecraft:light[level=12]
setblock 403 217 192 minecraft:light[level=12]
setblock 403 217 200 minecraft:light[level=12]
setblock 403 217 208 minecraft:light[level=12]
setblock 403 217 216 minecraft:light[level=12]
setblock 411 217 184 minecraft:light[level=12]
setblock 411 217 192 minecraft:light[level=12]
setblock 411 217 200 minecraft:light[level=12]
setblock 411 217 208 minecraft:light[level=12]
setblock 411 217 216 minecraft:light[level=12]
fill 377 219 182 378 221 183 minecraft:stone_bricks
fill 377 219 184 378 220 190 minecraft:mossy_cobblestone
fill 377 219 191 378 220 197 minecraft:stone_bricks
fill 377 219 198 378 220 204 minecraft:mossy_cobblestone
fill 377 219 205 378 220 211 minecraft:stone_bricks
fill 377 219 212 378 220 218 minecraft:mossy_cobblestone
fill 377 219 219 378 220 222 minecraft:stone_bricks
fill 379 219 182 385 220 183 minecraft:mossy_cobblestone
fill 379 219 184 385 220 190 minecraft:stone_bricks
fill 379 219 191 385 220 197 minecraft:mossy_cobblestone
fill 379 219 198 385 220 204 minecraft:stone_bricks
fill 379 219 205 385 220 211 minecraft:mossy_cobblestone
fill 379 219 212 385 220 218 minecraft:stone_bricks
fill 379 219 219 385 220 222 minecraft:mossy_cobblestone
fill 386 219 182 392 220 183 minecraft:stone_bricks
fill 386 219 184 392 220 190 minecraft:mossy_cobblestone
fill 386 219 191 392 220 197 minecraft:stone_bricks
fill 386 219 198 392 220 204 minecraft:mossy_cobblestone
fill 386 219 205 392 220 211 minecraft:stone_bricks
fill 386 219 212 392 220 218 minecraft:mossy_cobblestone
fill 386 219 219 392 220 222 minecraft:stone_bricks
fill 393 219 182 399 220 183 minecraft:mossy_cobblestone
fill 393 219 184 399 220 190 minecraft:stone_bricks
fill 393 219 191 397 220 197 minecraft:mossy_cobblestone
fill 393 219 198 396 220 204 minecraft:stone_bricks
fill 393 219 205 399 220 211 minecraft:mossy_cobblestone
fill 393 219 212 399 220 218 minecraft:stone_bricks
fill 393 219 219 399 220 222 minecraft:mossy_cobblestone
fill 397 219 199 397 220 204 minecraft:stone_bricks
fill 398 219 191 399 220 195 minecraft:mossy_cobblestone
fill 398 219 201 399 220 204 minecraft:stone_bricks
fill 400 219 182 406 220 183 minecraft:stone_bricks
fill 400 219 184 406 220 190 minecraft:mossy_cobblestone
fill 400 219 191 406 220 194 minecraft:stone_bricks
fill 400 219 202 406 220 204 minecraft:mossy_cobblestone
fill 400 219 205 406 220 211 minecraft:stone_bricks
fill 400 219 212 406 220 218 minecraft:mossy_cobblestone
fill 400 219 219 406 220 222 minecraft:stone_bricks
fill 401 219 195 406 220 195 minecraft:stone_bricks
fill 401 219 201 406 220 201 minecraft:mossy_cobblestone
fill 403 219 196 406 220 197 minecraft:stone_bricks
fill 403 219 199 406 220 200 minecraft:mossy_cobblestone
fill 404 219 198 406 220 198 minecraft:mossy_cobblestone
fill 407 219 182 413 220 183 minecraft:mossy_cobblestone
fill 407 219 184 413 220 190 minecraft:stone_bricks
fill 407 219 191 413 220 197 minecraft:mossy_cobblestone
fill 407 219 198 413 220 204 minecraft:stone_bricks
fill 407 219 205 413 220 211 minecraft:mossy_cobblestone
fill 407 219 212 413 220 218 minecraft:stone_bricks
fill 407 219 219 413 220 222 minecraft:mossy_cobblestone
fill 414 219 182 417 220 183 minecraft:stone_bricks
fill 414 219 184 417 220 190 minecraft:mossy_cobblestone
fill 414 219 191 417 220 197 minecraft:stone_bricks
fill 414 219 198 417 220 204 minecraft:mossy_cobblestone
fill 414 219 205 417 220 211 minecraft:stone_bricks
fill 414 219 212 417 220 218 minecraft:mossy_cobblestone
fill 414 219 219 417 220 222 minecraft:stone_bricks
fill 377 221 184 417 221 184 minecraft:spruce_planks
fill 377 221 185 378 221 190 minecraft:mossy_cobblestone
fill 377 221 191 417 221 191 minecraft:spruce_planks
fill 377 221 192 378 221 197 minecraft:stone_bricks
fill 377 221 198 395 221 198 minecraft:spruce_planks
fill 377 221 199 378 221 204 minecraft:mossy_cobblestone
fill 377 221 205 417 221 205 minecraft:spruce_planks
fill 377 221 206 378 221 211 minecraft:stone_bricks
fill 377 221 212 417 221 212 minecraft:spruce_planks
fill 377 221 213 378 221 218 minecraft:mossy_cobblestone
fill 377 221 219 417 221 219 minecraft:spruce_planks
fill 377 221 220 378 221 222 minecraft:stone_bricks
fill 379 221 182 379 221 183 minecraft:spruce_planks
fill 379 221 185 379 221 190 minecraft:spruce_planks
fill 379 221 192 379 221 197 minecraft:spruce_planks
fill 379 221 199 379 221 204 minecraft:spruce_planks
fill 379 221 206 379 221 211 minecraft:spruce_planks
fill 379 221 213 379 221 218 minecraft:spruce_planks
fill 379 221 220 379 221 222 minecraft:spruce_planks
fill 380 221 182 385 221 183 minecraft:mossy_cobblestone
fill 380 221 185 385 221 190 minecraft:stone_bricks
fill 380 221 192 385 221 197 minecraft:mossy_cobblestone
fill 380 221 199 385 221 204 minecraft:stone_bricks
fill 380 221 206 385 221 211 minecraft:mossy_cobblestone
fill 380 221 213 385 221 218 minecraft:stone_bricks
fill 380 221 220 385 221 222 minecraft:mossy_cobblestone
fill 386 221 182 386 221 183 minecraft:spruce_planks
fill 386 221 185 386 221 190 minecraft:spruce_planks
fill 386 221 192 386 221 197 minecraft:spruce_planks
fill 386 221 199 386 221 204 minecraft:spruce_planks
fill 386 221 206 386 221 211 minecraft:spruce_planks
fill 386 221 213 386 221 218 minecraft:spruce_planks
fill 386 221 220 386 221 222 minecraft:spruce_planks
fill 387 221 182 392 221 183 minecraft:stone_bricks
fill 387 221 185 392 221 190 minecraft:mossy_cobblestone
fill 387 221 192 392 221 197 minecraft:stone_bricks
fill 387 221 199 392 221 204 minecraft:mossy_cobblestone
fill 387 221 206 392 221 211 minecraft:stone_bricks
fill 387 221 213 392 221 218 minecraft:mossy_cobblestone
fill 387 221 220 392 221 222 minecraft:stone_bricks
fill 393 221 182 393 221 183 minecraft:spruce_planks
fill 393 221 185 393 221 190 minecraft:spruce_planks
fill 393 221 192 393 221 197 minecraft:spruce_planks
fill 393 221 199 393 221 204 minecraft:spruce_planks
fill 393 221 206 393 221 211 minecraft:spruce_planks
fill 393 221 213 393 221 218 minecraft:spruce_planks
fill 393 221 220 393 221 222 minecraft:spruce_planks
fill 394 221 182 399 221 183 minecraft:mossy_cobblestone
fill 394 221 185 399 221 190 minecraft:stone_bricks
fill 394 221 192 395 221 197 minecraft:mossy_cobblestone
fill 394 221 199 395 221 204 minecraft:stone_bricks
fill 394 221 206 399 221 211 minecraft:mossy_cobblestone
fill 394 221 213 399 221 218 minecraft:stone_bricks
fill 394 221 220 399 221 222 minecraft:mossy_cobblestone
fill 396 221 192 396 221 196 minecraft:mossy_cobblestone
fill 396 221 197 396 221 199 minecraft:lantern
fill 396 221 200 396 221 204 minecraft:stone_bricks
fill 397 221 192 398 221 194 minecraft:mossy_cobblestone
fill 397 221 195 397 221 197 minecraft:lantern
fill 397 221 199 397 221 201 minecraft:lantern
fill 397 221 202 398 221 204 minecraft:stone_bricks
fill 398 221 195 399 221 195 minecraft:lantern
fill 398 221 201 399 221 201 minecraft:lantern
fill 399 221 192 399 221 193 minecraft:mossy_cobblestone
fill 399 221 194 401 221 194 minecraft:lantern
fill 399 221 202 401 221 202 minecraft:lantern
fill 399 221 203 399 221 204 minecraft:stone_bricks
fill 400 221 182 400 221 183 minecraft:spruce_planks
fill 400 221 185 400 221 190 minecraft:spruce_planks
fill 400 221 192 400 221 193 minecraft:spruce_planks
fill 400 221 203 400 221 204 minecraft:spruce_planks
fill 400 221 206 400 221 211 minecraft:spruce_planks
fill 400 221 213 400 221 218 minecraft:spruce_planks
fill 400 221 220 400 221 222 minecraft:spruce_planks
fill 401 221 182 406 221 183 minecraft:stone_bricks
fill 401 221 185 406 221 190 minecraft:mossy_cobblestone
fill 401 221 192 406 221 193 minecraft:stone_bricks
fill 401 221 195 403 221 195 minecraft:lantern
fill 401 221 201 403 221 201 minecraft:lantern
fill 401 221 203 406 221 204 minecraft:mossy_cobblestone
fill 401 221 206 406 221 211 minecraft:stone_bricks
fill 401 221 213 406 221 218 minecraft:mossy_cobblestone
fill 401 221 220 406 221 222 minecraft:stone_bricks
fill 402 221 194 406 221 194 minecraft:stone_bricks
fill 402 221 202 406 221 202 minecraft:mossy_cobblestone
fill 403 221 196 403 221 197 minecraft:lantern
fill 403 221 199 403 221 200 minecraft:lantern
fill 404 221 195 406 221 196 minecraft:stone_bricks
fill 404 221 197 404 221 199 minecraft:lantern
fill 404 221 200 406 221 201 minecraft:mossy_cobblestone
fill 405 221 197 406 221 197 minecraft:stone_bricks
fill 405 221 198 417 221 198 minecraft:spruce_planks
fill 405 221 199 406 221 199 minecraft:mossy_cobblestone
fill 407 221 182 407 221 183 minecraft:spruce_planks
fill 407 221 185 407 221 190 minecraft:spruce_planks
fill 407 221 192 407 221 197 minecraft:spruce_planks
fill 407 221 199 407 221 204 minecraft:spruce_planks
fill 407 221 206 407 221 211 minecraft:spruce_planks
fill 407 221 213 407 221 218 minecraft:spruce_planks
fill 407 221 220 407 221 222 minecraft:spruce_planks
fill 408 221 182 413 221 183 minecraft:mossy_cobblestone
fill 408 221 185 413 221 190 minecraft:stone_bricks
fill 408 221 192 413 221 197 minecraft:mossy_cobblestone
fill 408 221 199 413 221 204 minecraft:stone_bricks
fill 408 221 206 413 221 211 minecraft:mossy_cobblestone
fill 408 221 213 413 221 218 minecraft:stone_bricks
fill 408 221 220 413 221 222 minecraft:mossy_cobblestone
fill 414 221 182 414 221 183 minecraft:spruce_planks
fill 414 221 185 414 221 190 minecraft:spruce_planks
fill 414 221 192 414 221 197 minecraft:spruce_planks
fill 414 221 199 414 221 204 minecraft:spruce_planks
fill 414 221 206 414 221 211 minecraft:spruce_planks
fill 414 221 213 414 221 218 minecraft:spruce_planks
fill 414 221 220 414 221 222 minecraft:spruce_planks
fill 415 221 182 417 221 183 minecraft:stone_bricks
fill 415 221 185 417 221 190 minecraft:mossy_cobblestone
fill 415 221 192 417 221 197 minecraft:stone_bricks
fill 415 221 199 417 221 204 minecraft:mossy_cobblestone
fill 415 221 206 417 221 211 minecraft:stone_bricks
fill 415 221 213 417 221 218 minecraft:mossy_cobblestone
fill 415 221 220 417 221 222 minecraft:stone_bricks
fill 377 225 182 377 225 183 minecraft:mossy_cobblestone
setblock 377 225 184 minecraft:stone_bricks
fill 377 225 185 377 225 188 minecraft:mossy_cobblestone
setblock 377 225 189 minecraft:stone_bricks
fill 377 225 190 377 225 193 minecraft:mossy_cobblestone
setblock 377 225 194 minecraft:stone_bricks
fill 377 225 195 377 225 198 minecraft:mossy_cobblestone
setblock 377 225 199 minecraft:stone_bricks
fill 377 225 200 377 225 203 minecraft:mossy_cobblestone
setblock 377 225 204 minecraft:stone_bricks
fill 377 225 205 377 225 208 minecraft:mossy_cobblestone
setblock 377 225 209 minecraft:stone_bricks
fill 377 225 210 377 225 213 minecraft:mossy_cobblestone
setblock 377 225 214 minecraft:stone_bricks
fill 377 225 215 377 225 218 minecraft:mossy_cobblestone
setblock 377 225 219 minecraft:stone_bricks
fill 377 225 220 378 225 222 minecraft:mossy_cobblestone
setblock 378 225 182 minecraft:mossy_cobblestone
setblock 378 225 188 minecraft:stone_bricks
fill 378 225 189 378 225 192 minecraft:mossy_cobblestone
setblock 378 225 193 minecraft:stone_bricks
fill 378 225 194 378 225 197 minecraft:mossy_cobblestone
setblock 378 225 198 minecraft:stone_bricks
fill 378 225 199 378 225 202 minecraft:mossy_cobblestone
setblock 378 225 203 minecraft:stone_bricks
fill 378 225 204 378 225 207 minecraft:mossy_cobblestone
setblock 378 225 208 minecraft:stone_bricks
setblock 378 225 213 minecraft:stone_bricks
fill 378 225 214 378 225 217 minecraft:mossy_cobblestone
setblock 378 225 218 minecraft:stone_bricks
fill 378 225 219 378 228 219 minecraft:mossy_cobblestone
setblock 379 225 182 minecraft:stone_bricks
fill 379 225 183 381 226 183 minecraft:mossy_cobblestone
setblock 379 225 184 minecraft:light[level=12]
setblock 379 225 191 minecraft:mossy_cobblestone
setblock 379 225 192 minecraft:stone_bricks
fill 379 225 193 379 225 196 minecraft:mossy_cobblestone
setblock 379 225 197 minecraft:stone_bricks
fill 379 225 198 379 225 201 minecraft:mossy_cobblestone
setblock 379 225 202 minecraft:stone_bricks
fill 379 225 203 379 227 204 minecraft:mossy_cobblestone
setblock 379 225 208 minecraft:light[level=12]
setblock 379 225 216 minecraft:light[level=12]
setblock 379 225 221 minecraft:mossy_cobblestone
setblock 379 225 222 minecraft:stone_bricks
fill 380 225 182 383 225 182 minecraft:mossy_cobblestone
fill 380 225 193 380 225 195 minecraft:mossy_cobblestone
setblock 380 225 196 minecraft:stone_bricks
fill 380 225 197 380 225 200 minecraft:mossy_cobblestone
setblock 380 225 201 minecraft:stone_bricks
setblock 380 225 221 minecraft:stone_bricks
fill 380 225 222 383 225 222 minecraft:mossy_cobblestone
fill 381 225 221 382 227 221 minecraft:mossy_cobblestone
setblock 384 225 182 minecraft:stone_bricks
setblock 384 225 222 minecraft:stone_bricks
fill 385 225 182 388 225 182 minecraft:mossy_cobblestone
fill 385 225 222 388 225 222 minecraft:mossy_cobblestone
setblock 387 225 184 minecraft:light[level=12]
setblock 387 225 192 minecraft:light[level=12]
setblock 387 225 200 minecraft:light[level=12]
setblock 387 225 208 minecraft:light[level=12]
setblock 387 225 216 minecraft:light[level=12]
fill 388 225 196 388 226 196 minecraft:lantern
setblock 389 225 182 minecraft:stone_bricks
setblock 389 225 222 minecraft:stone_bricks
fill 390 225 182 393 225 182 minecraft:mossy_cobblestone
fill 390 225 222 393 225 222 minecraft:mossy_cobblestone
fill 392 225 221 394 225 221 minecraft:mossy_cobblestone
setblock 393 225 183 minecraft:stone_bricks
setblock 394 225 182 minecraft:stone_bricks
fill 394 225 183 397 225 183 minecraft:mossy_cobblestone
fill 394 225 220 395 225 220 minecraft:mossy_cobblestone
setblock 394 225 222 minecraft:stone_bricks
fill 395 225 182 398 225 182 minecraft:mossy_cobblestone
setblock 395 225 184 minecraft:light[level=12]
setblock 395 225 192 minecraft:light[level=12]
setblock 395 225 200 minecraft:light[level=12]
setblock 395 225 208 minecraft:light[level=12]
setblock 395 225 216 minecraft:light[level=12]
setblock 395 225 221 minecraft:stone_bricks
fill 395 225 222 398 225 222 minecraft:mossy_cobblestone
setblock 396 225 220 minecraft:stone_bricks
fill 396 225 221 399 225 221 minecraft:mossy_cobblestone
setblock 397 225 219 minecraft:stone_bricks
fill 397 225 220 400 225 220 minecraft:mossy_cobblestone
setblock 398 225 183 minecraft:stone_bricks
fill 398 225 219 401 225 219 minecraft:mossy_cobblestone
setblock 399 225 182 minecraft:stone_bricks
fill 399 225 183 402 225 183 minecraft:mossy_cobblestone
setblock 399 225 222 minecraft:stone_bricks
fill 400 225 182 403 225 182 minecraft:mossy_cobblestone
setblock 400 225 221 minecraft:stone_bricks
fill 400 225 222 403 225 222 minecraft:mossy_cobblestone
setblock 401 225 220 minecraft:stone_bricks
fill 401 225 221 404 225 221 minecraft:mossy_cobblestone
setblock 402 225 219 minecraft:stone_bricks
fill 402 225 220 405 225 220 minecraft:mossy_cobblestone
setblock 403 225 184 minecraft:light[level=12]
setblock 403 225 192 minecraft:light[level=12]
setblock 403 225 200 minecraft:light[level=12]
setblock 403 225 208 minecraft:light[level=12]
setblock 403 225 216 minecraft:light[level=12]
fill 403 225 219 403 227 219 minecraft:mossy_cobblestone
setblock 404 225 182 minecraft:stone_bricks
setblock 404 225 222 minecraft:stone_bricks
fill 405 225 182 405 228 182 minecraft:mossy_cobblestone
setblock 405 225 221 minecraft:stone_bricks
fill 405 225 222 408 225 222 minecraft:mossy_cobblestone
setblock 406 225 220 minecraft:stone_bricks
fill 406 225 221 409 225 221 minecraft:mossy_cobblestone
setblock 409 225 222 minecraft:stone_bricks
setblock 410 225 221 minecraft:stone_bricks
fill 410 225 222 413 225 222 minecraft:mossy_cobblestone
setblock 411 225 184 minecraft:light[level=12]
setblock 411 225 192 minecraft:light[level=12]
setblock 411 225 200 minecraft:light[level=12]
setblock 411 225 208 minecraft:light[level=12]
setblock 411 225 216 minecraft:light[level=12]
fill 411 225 221 414 225 221 minecraft:mossy_cobblestone
fill 414 225 220 415 225 220 minecraft:mossy_cobblestone
setblock 414 225 222 minecraft:stone_bricks
fill 415 225 197 415 225 200 minecraft:mossy_cobblestone
setblock 415 225 201 minecraft:stone_bricks
setblock 415 225 215 minecraft:mossy_cobblestone
setblock 415 225 216 minecraft:stone_bricks
fill 415 225 217 416 225 219 minecraft:mossy_cobblestone
setblock 415 225 221 minecraft:stone_bricks
fill 415 225 222 417 226 222 minecraft:mossy_cobblestone
fill 416 225 182 417 226 182 minecraft:mossy_cobblestone
fill 416 225 193 416 225 194 minecraft:mossy_cobblestone
setblock 416 225 195 minecraft:stone_bricks
fill 416 225 196 416 225 199 minecraft:mossy_cobblestone
setblock 416 225 200 minecraft:stone_bricks
fill 416 225 201 416 225 204 minecraft:mossy_cobblestone
setblock 416 225 205 minecraft:stone_bricks
fill 416 225 206 416 225 209 minecraft:mossy_cobblestone
setblock 416 225 210 minecraft:stone_bricks
fill 416 225 211 416 225 214 minecraft:mossy_cobblestone
setblock 416 225 215 minecraft:stone_bricks
fill 416 225 216 417 227 216 minecraft:mossy_cobblestone
setblock 416 225 220 minecraft:stone_bricks
fill 416 225 221 417 227 221 minecraft:mossy_cobblestone
fill 417 225 190 417 225 193 minecraft:mossy_cobblestone
setblock 417 225 194 minecraft:stone_bricks
fill 417 225 195 417 225 198 minecraft:mossy_cobblestone
setblock 417 225 199 minecraft:stone_bricks
fill 417 225 200 417 225 203 minecraft:mossy_cobblestone
setblock 417 225 204 minecraft:stone_bricks
fill 417 225 205 417 225 208 minecraft:mossy_cobblestone
setblock 417 225 209 minecraft:stone_bricks
fill 417 225 210 417 225 213 minecraft:mossy_cobblestone
setblock 417 225 214 minecraft:stone_bricks
fill 417 225 215 417 228 215 minecraft:mossy_cobblestone
fill 417 225 217 417 225 218 minecraft:mossy_cobblestone
setblock 417 225 219 minecraft:stone_bricks
fill 417 225 220 417 228 220 minecraft:mossy_cobblestone
setblock 377 226 182 minecraft:mossy_cobblestone
setblock 377 226 183 minecraft:stone_bricks
fill 377 226 184 377 226 187 minecraft:mossy_cobblestone
setblock 377 226 188 minecraft:stone_bricks
fill 377 226 189 377 226 192 minecraft:mossy_cobblestone
setblock 377 226 193 minecraft:stone_bricks
fill 377 226 194 377 226 197 minecraft:mossy_cobblestone
setblock 377 226 198 minecraft:stone_bricks
fill 377 226 199 377 226 202 minecraft:mossy_cobblestone
setblock 377 226 203 minecraft:stone_bricks
fill 377 226 204 377 226 207 minecraft:mossy_cobblestone
setblock 377 226 208 minecraft:stone_bricks
fill 377 226 209 377 226 212 minecraft:mossy_cobblestone
setblock 377 226 213 minecraft:stone_bricks
fill 377 226 214 377 226 217 minecraft:mossy_cobblestone
setblock 377 226 218 minecraft:stone_bricks
fill 377 226 219 377 226 222 minecraft:mossy_cobblestone
setblock 378 226 182 minecraft:stone_bricks
fill 378 226 183 378 226 186 minecraft:mossy_cobblestone
setblock 378 226 187 minecraft:stone_bricks
fill 378 226 188 378 226 191 minecraft:mossy_cobblestone
setblock 378 226 192 minecraft:stone_bricks
fill 378 226 193 378 226 196 minecraft:mossy_cobblestone
setblock 378 226 197 minecraft:stone_bricks
fill 378 226 198 378 226 201 minecraft:mossy_cobblestone
setblock 378 226 202 minecraft:stone_bricks
fill 378 226 203 378 226 206 minecraft:mossy_cobblestone
setblock 378 226 207 minecraft:stone_bricks
fill 378 226 208 378 228 209 minecraft:mossy_cobblestone
fill 378 226 213 378 226 216 minecraft:mossy_cobblestone
setblock 378 226 217 minecraft:stone_bricks
fill 378 226 218 378 229 218 minecraft:mossy_cobblestone
fill 378 226 220 378 226 221 minecraft:mossy_cobblestone
setblock 378 226 222 minecraft:stone_bricks
fill 379 226 182 382 226 182 minecraft:mossy_cobblestone
setblock 379 226 191 minecraft:stone_bricks
fill 379 226 192 379 226 195 minecraft:mossy_cobblestone
setblock 379 226 196 minecraft:stone_bricks
fill 379 226 197 379 226 200 minecraft:mossy_cobblestone
setblock 379 226 201 minecraft:stone_bricks
fill 379 226 202 380 228 202 minecraft:mossy_cobblestone
setblock 379 226 205 minecraft:mossy_cobblestone
setblock 379 226 220 minecraft:mossy_cobblestone
setblock 379 226 221 minecraft:stone_bricks
fill 379 226 222 382 226 222 minecraft:mossy_cobblestone
setblock 380 226 194 minecraft:mossy_cobblestone
setblock 380 226 195 minecraft:stone_bricks
fill 380 226 196 380 226 199 minecraft:mossy_cobblestone
setblock 380 226 200 minecraft:stone_bricks
fill 380 226 201 380 229 201 minecraft:mossy_cobblestone
fill 380 226 221 380 229 221 minecraft:mossy_cobblestone
setblock 382 226 183 minecraft:stone_bricks
setblock 383 226 182 minecraft:stone_bricks
fill 383 226 183 383 229 183 minecraft:mossy_cobblestone
setblock 383 226 221 minecraft:mossy_cobblestone
setblock 383 226 222 minecraft:stone_bricks
fill 384 226 182 387 226 182 minecraft:mossy_cobblestone
fill 384 226 222 387 226 222 minecraft:mossy_cobblestone
setblock 388 226 182 minecraft:stone_bricks
setblock 388 226 222 minecraft:stone_bricks
fill 389 226 182 392 226 182 minecraft:mossy_cobblestone
fill 389 226 222 392 226 222 minecraft:mossy_cobblestone
setblock 391 226 183 minecraft:mossy_cobblestone
fill 391 226 221 393 226 221 minecraft:mossy_cobblestone
setblock 392 226 183 minecraft:stone_bricks
setblock 393 226 182 minecraft:stone_bricks
fill 393 226 183 396 226 183 minecraft:mossy_cobblestone
fill 393 226 220 394 226 220 minecraft:mossy_cobblestone
setblock 393 226 222 minecraft:stone_bricks
fill 394 226 182 397 226 182 minecraft:mossy_cobblestone
setblock 394 226 221 minecraft:stone_bricks
fill 394 226 222 397 226 222 minecraft:mossy_cobblestone
setblock 395 226 220 minecraft:stone_bricks
fill 395 226 221 398 226 221 minecraft:mossy_cobblestone
setblock 396 226 184 minecraft:stone_bricks
setblock 396 226 219 minecraft:stone_bricks
fill 396 226 220 399 226 220 minecraft:mossy_cobblestone
setblock 397 226 183 minecraft:stone_bricks
fill 397 226 184 399 227 184 minecraft:mossy_cobblestone
fill 397 226 219 400 226 219 minecraft:mossy_cobblestone
setblock 398 226 182 minecraft:stone_bricks
fill 398 226 183 401 226 183 minecraft:mossy_cobblestone
setblock 398 226 222 minecraft:stone_bricks
fill 399 226 182 402 226 182 minecraft:mossy_cobblestone
setblock 399 226 221 minecraft:stone_bricks
fill 399 226 222 402 226 222 minecraft:mossy_cobblestone
setblock 400 226 220 minecraft:stone_bricks
fill 400 226 221 403 226 221 minecraft:mossy_cobblestone
setblock 401 226 219 minecraft:stone_bricks
fill 401 226 220 404 226 220 minecraft:mossy_cobblestone
setblock 402 226 183 minecraft:stone_bricks
fill 402 226 219 402 228 219 minecraft:mossy_cobblestone
setblock 403 226 182 minecraft:stone_bricks
fill 403 226 183 403 229 183 minecraft:mossy_cobblestone
setblock 403 226 222 minecraft:stone_bricks
fill 404 226 182 404 229 182 minecraft:mossy_cobblestone
setblock 404 226 221 minecraft:stone_bricks
fill 404 226 222 407 226 222 minecraft:mossy_cobblestone
setblock 405 226 220 minecraft:stone_bricks
fill 405 226 221 408 226 221 minecraft:mossy_cobblestone
fill 406 226 182 406 227 182 minecraft:mossy_cobblestone
fill 406 226 220 407 227 220 minecraft:mossy_cobblestone
setblock 408 226 222 minecraft:stone_bricks
setblock 409 226 221 minecraft:stone_bricks
fill 409 226 222 412 226 222 minecraft:mossy_cobblestone
fill 410 226 221 413 226 221 minecraft:mossy_cobblestone
fill 412 226 220 414 226 220 minecraft:mossy_cobblestone
setblock 413 226 222 minecraft:stone_bricks
fill 414 226 182 415 228 182 minecraft:mossy_cobblestone
setblock 414 226 221 minecraft:stone_bricks
fill 414 226 222 414 229 222 minecraft:mossy_cobblestone
fill 415 226 196 415 226 199 minecraft:mossy_cobblestone
setblock 415 226 200 minecraft:stone_bricks
fill 415 226 201 415 226 204 minecraft:mossy_cobblestone
setblock 415 226 214 minecraft:mossy_cobblestone
setblock 415 226 215 minecraft:stone_bricks
fill 415 226 216 415 226 219 minecraft:mossy_cobblestone
setblock 415 226 220 minecraft:stone_bricks
fill 415 226 221 415 229 221 minecraft:mossy_cobblestone
setblock 416 226 193 minecraft:mossy_cobblestone
setblock 416 226 194 minecraft:stone_bricks
fill 416 226 195 416 226 198 minecraft:mossy_cobblestone
setblock 416 226 199 minecraft:stone_bricks
fill 416 226 200 416 226 203 minecraft:mossy_cobblestone
setblock 416 226 204 minecraft:stone_bricks
fill 416 226 205 416 226 208 minecraft:mossy_cobblestone
setblock 416 226 209 minecraft:stone_bricks
fill 416 226 210 416 226 213 minecraft:mossy_cobblestone
setblock 416 226 214 minecraft:stone_bricks
fill 416 226 215 416 229 215 minecraft:mossy_cobblestone
fill 416 226 217 416 226 218 minecraft:mossy_cobblestone
setblock 416 226 219 minecraft:stone_bricks
fill 416 226 220 416 229 220 minecraft:mossy_cobblestone
setblock 417 226 183 minecraft:stone_bricks
fill 417 226 184 417 228 185 minecraft:mossy_cobblestone
fill 417 226 189 417 226 192 minecraft:mossy_cobblestone
setblock 417 226 193 minecraft:stone_bricks
fill 417 226 194 417 226 197 minecraft:mossy_cobblestone
setblock 417 226 198 minecraft:stone_bricks
fill 417 226 199 417 226 202 minecraft:mossy_cobblestone
setblock 417 226 203 minecraft:stone_bricks
fill 417 226 204 417 226 207 minecraft:mossy_cobblestone
setblock 417 226 208 minecraft:stone_bricks
fill 417 226 209 417 226 212 minecraft:mossy_cobblestone
setblock 417 226 213 minecraft:stone_bricks
fill 417 226 214 417 229 214 minecraft:mossy_cobblestone
setblock 417 226 217 minecraft:mossy_cobblestone
setblock 417 226 218 minecraft:stone_bricks
fill 417 226 219 417 229 219 minecraft:mossy_cobblestone
setblock 377 227 182 minecraft:stone_bricks
fill 377 227 183 377 227 186 minecraft:mossy_cobblestone
setblock 377 227 187 minecraft:stone_bricks
fill 377 227 188 377 227 191 minecraft:mossy_cobblestone
setblock 377 227 192 minecraft:stone_bricks
fill 377 227 193 377 227 196 minecraft:mossy_cobblestone
setblock 377 227 197 minecraft:stone_bricks
fill 377 227 198 377 227 201 minecraft:mossy_cobblestone
setblock 377 227 202 minecraft:stone_bricks
fill 377 227 203 377 227 206 minecraft:mossy_cobblestone
setblock 377 227 207 minecraft:stone_bricks
fill 377 227 208 377 227 211 minecraft:mossy_cobblestone
setblock 377 227 212 minecraft:stone_bricks
fill 377 227 213 377 227 216 minecraft:mossy_cobblestone
setblock 377 227 217 minecraft:stone_bricks
fill 377 227 218 377 227 221 minecraft:mossy_cobblestone
setblock 377 227 222 minecraft:stone_bricks
fill 378 227 182 378 227 185 minecraft:mossy_cobblestone
setblock 378 227 186 minecraft:stone_bricks
fill 378 227 187 378 227 190 minecraft:mossy_cobblestone
setblock 378 227 191 minecraft:stone_bricks
fill 378 227 192 378 227 195 minecraft:mossy_cobblestone
setblock 378 227 196 minecraft:stone_bricks
fill 378 227 197 378 227 200 minecraft:mossy_cobblestone
setblock 378 227 201 minecraft:stone_bricks
fill 378 227 202 378 227 205 minecraft:mossy_cobblestone
setblock 378 227 206 minecraft:stone_bricks
fill 378 227 207 378 230 207 minecraft:mossy_cobblestone
fill 378 227 214 378 227 215 minecraft:mossy_cobblestone
setblock 378 227 216 minecraft:stone_bricks
fill 378 227 217 378 229 217 minecraft:mossy_cobblestone
setblock 378 227 220 minecraft:mossy_cobblestone
setblock 378 227 221 minecraft:stone_bricks
fill 378 227 222 381 227 222 minecraft:mossy_cobblestone
fill 379 227 182 380 227 183 minecraft:mossy_cobblestone
fill 379 227 191 379 227 194 minecraft:mossy_cobblestone
setblock 379 227 195 minecraft:stone_bricks
fill 379 227 196 379 227 199 minecraft:mossy_cobblestone
setblock 379 227 200 minecraft:stone_bricks
fill 379 227 201 379 230 201 minecraft:mossy_cobblestone
setblock 379 227 205 minecraft:stone_bricks
setblock 379 227 220 minecraft:stone_bricks
fill 379 227 221 379 230 221 minecraft:mossy_cobblestone
setblock 380 227 194 minecraft:stone_bricks
fill 380 227 195 380 227 198 minecraft:mossy_cobblestone
setblock 380 227 199 minecraft:stone_bricks
fill 380 227 200 380 229 200 minecraft:mossy_cobblestone
setblock 381 227 182 minecraft:mossy_cobblestone
setblock 381 227 183 minecraft:stone_bricks
setblock 382 227 182 minecraft:stone_bricks
fill 382 227 183 382 230 183 minecraft:mossy_cobblestone
setblock 382 227 222 minecraft:stone_bricks
fill 383 227 182 386 227 182 minecraft:mossy_cobblestone
setblock 383 227 221 minecraft:stone_bricks
fill 383 227 222 386 227 222 minecraft:mossy_cobblestone
fill 384 227 183 385 227 183 minecraft:mossy_cobblestone
setblock 387 227 182 minecraft:stone_bricks
setblock 387 227 222 minecraft:stone_bricks
fill 388 227 182 391 227 182 minecraft:mossy_cobblestone
fill 388 227 196 388 234 196 minecraft:cobbled_deepslate
fill 388 227 222 391 227 222 minecraft:mossy_cobblestone
fill 389 227 183 390 227 183 minecraft:mossy_cobblestone
fill 389 227 221 392 227 221 minecraft:mossy_cobblestone
setblock 391 227 183 minecraft:stone_bricks
setblock 392 227 182 minecraft:stone_bricks
fill 392 227 183 395 227 183 minecraft:mossy_cobblestone
fill 392 227 220 393 227 220 minecraft:mossy_cobblestone
setblock 392 227 222 minecraft:stone_bricks
fill 393 227 182 396 227 182 minecraft:mossy_cobblestone
setblock 393 227 221 minecraft:stone_bricks
fill 393 227 222 396 227 222 minecraft:mossy_cobblestone
setblock 394 227 184 minecraft:mossy_cobblestone
setblock 394 227 220 minecraft:stone_bricks
fill 394 227 221 397 227 221 minecraft:mossy_cobblestone
setblock 395 227 184 minecraft:stone_bricks
setblock 395 227 219 minecraft:stone_bricks
fill 395 227 220 398 227 220 minecraft:mossy_cobblestone
setblock 396 227 183 minecraft:stone_bricks
fill 396 227 184 396 230 184 minecraft:mossy_cobblestone
fill 396 227 219 399 227 219 minecraft:mossy_cobblestone
setblock 397 227 182 minecraft:stone_bricks
fill 397 227 183 400 227 183 minecraft:mossy_cobblestone
setblock 397 227 222 minecraft:stone_bricks
fill 398 227 182 401 227 182 minecraft:mossy_cobblestone
setblock 398 227 221 minecraft:stone_bricks
fill 398 227 222 401 227 222 minecraft:mossy_cobblestone
setblock 399 227 220 minecraft:stone_bricks
fill 399 227 221 402 227 221 minecraft:mossy_cobblestone
setblock 400 227 219 minecraft:stone_bricks
fill 400 227 220 403 227 220 minecraft:mossy_cobblestone
setblock 401 227 183 minecraft:stone_bricks
fill 401 227 219 401 229 219 minecraft:mossy_cobblestone
setblock 402 227 182 minecraft:stone_bricks
fill 402 227 183 402 230 183 minecraft:mossy_cobblestone
setblock 402 227 222 minecraft:stone_bricks
fill 403 227 182 403 230 182 minecraft:mossy_cobblestone
setblock 403 227 221 minecraft:stone_bricks
fill 403 227 222 406 227 222 minecraft:mossy_cobblestone
setblock 404 227 220 minecraft:stone_bricks
fill 404 227 221 407 227 221 minecraft:mossy_cobblestone
fill 405 227 220 405 229 220 minecraft:mossy_cobblestone
setblock 407 227 182 minecraft:stone_bricks
setblock 407 227 222 minecraft:stone_bricks
setblock 408 227 221 minecraft:stone_bricks
fill 408 227 222 411 227 222 minecraft:mossy_cobblestone
fill 409 227 221 412 227 221 minecraft:mossy_cobblestone
fill 411 227 220 413 227 220 minecraft:mossy_cobblestone
setblock 412 227 182 minecraft:stone_bricks
setblock 412 227 222 minecraft:stone_bricks
fill 413 227 182 413 230 182 minecraft:mossy_cobblestone
setblock 413 227 221 minecraft:stone_bricks
fill 413 227 222 413 230 222 minecraft:mossy_cobblestone
setblock 414 227 220 minecraft:stone_bricks
fill 414 227 221 414 230 221 minecraft:mossy_cobblestone
fill 415 227 196 415 227 198 minecraft:mossy_cobblestone
setblock 415 227 199 minecraft:stone_bricks
fill 415 227 200 415 227 203 minecraft:mossy_cobblestone
setblock 415 227 204 minecraft:stone_bricks
fill 415 227 205 416 227 207 minecraft:mossy_cobblestone
setblock 415 227 214 minecraft:stone_bricks
fill 415 227 215 415 227 218 minecraft:mossy_cobblestone
setblock 415 227 219 minecraft:stone_bricks
fill 415 227 220 415 230 220 minecraft:mossy_cobblestone
fill 415 227 222 416 227 222 minecraft:mossy_cobblestone
setblock 416 227 182 minecraft:mossy_cobblestone
setblock 416 227 192 minecraft:mossy_cobblestone
setblock 416 227 193 minecraft:stone_bricks
fill 416 227 194 416 227 197 minecraft:mossy_cobblestone
setblock 416 227 198 minecraft:stone_bricks
fill 416 227 199 416 227 202 minecraft:mossy_cobblestone
setblock 416 227 203 minecraft:stone_bricks
fill 416 227 204 417 229 204 minecraft:mossy_cobblestone
setblock 416 227 208 minecraft:stone_bricks
fill 416 227 209 416 227 212 minecraft:mossy_cobblestone
setblock 416 227 213 minecraft:stone_bricks
fill 416 227 214 416 230 214 minecraft:mossy_cobblestone
setblock 416 227 217 minecraft:mossy_cobblestone
setblock 416 227 218 minecraft:stone_bricks
fill 416 227 219 416 230 219 minecraft:mossy_cobblestone
setblock 417 227 182 minecraft:stone_bricks
fill 417 227 183 417 230 183 minecraft:mossy_cobblestone
setblock 417 227 186 minecraft:mossy_cobblestone
setblock 417 227 187 minecraft:stone_bricks
fill 417 227 188 417 227 191 minecraft:mossy_cobblestone
setblock 417 227 192 minecraft:stone_bricks
fill 417 227 193 417 227 196 minecraft:mossy_cobblestone
setblock 417 227 197 minecraft:stone_bricks
fill 417 227 198 417 227 201 minecraft:mossy_cobblestone
setblock 417 227 202 minecraft:stone_bricks
fill 417 227 203 417 230 203 minecraft:mossy_cobblestone
fill 417 227 205 417 227 206 minecraft:mossy_cobblestone
setblock 417 227 207 minecraft:stone_bricks
fill 417 227 208 417 227 211 minecraft:mossy_cobblestone
setblock 417 227 212 minecraft:stone_bricks
fill 417 227 213 417 230 213 minecraft:mossy_cobblestone
setblock 417 227 217 minecraft:stone_bricks
fill 417 227 218 417 230 218 minecraft:mossy_cobblestone
setblock 417 227 222 minecraft:stone_bricks
fill 377 228 182 377 228 185 minecraft:mossy_cobblestone
setblock 377 228 186 minecraft:stone_bricks
fill 377 228 187 377 228 190 minecraft:mossy_cobblestone
setblock 377 228 191 minecraft:stone_bricks
fill 377 228 192 377 228 195 minecraft:mossy_cobblestone
setblock 377 228 196 minecraft:stone_bricks
fill 377 228 197 377 228 200 minecraft:mossy_cobblestone
setblock 377 228 201 minecraft:stone_bricks
fill 377 228 202 377 228 205 minecraft:mossy_cobblestone
setblock 377 228 206 minecraft:stone_bricks
fill 377 228 207 377 228 210 minecraft:mossy_cobblestone
setblock 377 228 211 minecraft:stone_bricks
fill 377 228 212 377 228 215 minecraft:mossy_cobblestone
setblock 377 228 216 minecraft:stone_bricks
fill 377 228 217 377 228 220 minecraft:mossy_cobblestone
setblock 377 228 221 minecraft:stone_bricks
fill 377 228 222 380 228 222 minecraft:mossy_cobblestone
fill 378 228 182 378 228 184 minecraft:mossy_cobblestone
setblock 378 228 185 minecraft:stone_bricks
fill 378 228 186 378 228 189 minecraft:mossy_cobblestone
setblock 378 228 190 minecraft:stone_bricks
fill 378 228 191 378 228 194 minecraft:mossy_cobblestone
setblock 378 228 195 minecraft:stone_bricks
fill 378 228 196 378 228 199 minecraft:mossy_cobblestone
setblock 378 228 200 minecraft:stone_bricks
fill 378 228 201 378 228 204 minecraft:mossy_cobblestone
setblock 378 228 205 minecraft:stone_bricks
fill 378 228 206 378 231 206 minecraft:mossy_cobblestone
setblock 378 228 215 minecraft:stone_bricks
setblock 378 228 216 minecraft:mossy_cobblestone
setblock 378 228 220 minecraft:stone_bricks
fill 378 228 221 378 231 221 minecraft:mossy_cobblestone
fill 379 228 182 379 228 183 minecraft:mossy_cobblestone
setblock 379 228 184 minecraft:stone_bricks
fill 379 228 191 379 228 193 minecraft:mossy_cobblestone
setblock 379 228 194 minecraft:stone_bricks
fill 379 228 195 379 228 198 minecraft:mossy_cobblestone
setblock 379 228 199 minecraft:stone_bricks
fill 379 228 200 379 231 200 minecraft:mossy_cobblestone
setblock 379 228 203 minecraft:mossy_cobblestone
setblock 379 228 204 minecraft:stone_bricks
fill 379 228 205 379 230 205 minecraft:mossy_cobblestone
fill 379 228 209 379 236 209 minecraft:spruce_log
setblock 380 228 182 minecraft:mossy_cobblestone
setblock 380 228 183 minecraft:stone_bricks
fill 380 228 195 380 228 197 minecraft:mossy_cobblestone
setblock 380 228 198 minecraft:stone_bricks
fill 380 228 199 380 229 199 minecraft:mossy_cobblestone
setblock 381 228 182 minecraft:stone_bricks
fill 381 228 183 381 231 183 minecraft:mossy_cobblestone
setblock 381 228 221 minecraft:mossy_cobblestone
setblock 381 228 222 minecraft:stone_bricks
fill 382 228 182 385 228 182 minecraft:mossy_cobblestone
setblock 382 228 221 minecraft:stone_bricks
fill 382 228 222 385 228 222 minecraft:mossy_cobblestone
setblock 383 228 221 minecraft:mossy_cobblestone
setblock 384 228 183 minecraft:mossy_cobblestone
setblock 385 228 183 minecraft:stone_bricks
setblock 386 228 182 minecraft:stone_bricks
fill 386 228 183 389 228 183 minecraft:mossy_cobblestone
setblock 386 228 222 minecraft:stone_bricks
fill 387 228 182 390 228 182 minecraft:mossy_cobblestone
fill 387 228 222 390 228 222 minecraft:mossy_cobblestone
fill 389 228 221 391 228 221 minecraft:mossy_cobblestone
setblock 390 228 183 minecraft:stone_bricks
setblock 391 228 182 minecraft:stone_bricks
fill 391 228 183 394 228 183 minecraft:mossy_cobblestone
setblock 391 228 222 minecraft:stone_bricks
fill 392 228 182 395 228 182 minecraft:mossy_cobblestone
setblock 392 228 220 minecraft:mossy_cobblestone
setblock 392 228 221 minecraft:stone_bricks
fill 392 228 222 395 228 222 minecraft:mossy_cobblestone
setblock 393 228 184 minecraft:mossy_cobblestone
setblock 393 228 220 minecraft:stone_bricks
fill 393 228 221 396 228 221 minecraft:mossy_cobblestone
setblock 394 228 184 minecraft:stone_bricks
fill 394 228 220 397 228 220 minecraft:mossy_cobblestone
setblock 395 228 183 minecraft:stone_bricks
fill 395 228 184 395 231 184 minecraft:mossy_cobblestone
fill 395 228 219 398 228 219 minecraft:mossy_cobblestone
setblock 396 228 182 minecraft:stone_bricks
fill 396 228 183 399 228 183 minecraft:mossy_cobblestone
setblock 396 228 222 minecraft:stone_bricks
fill 397 228 182 400 228 182 minecraft:mossy_cobblestone
fill 397 228 184 398 228 184 minecraft:mossy_cobblestone
setblock 397 228 221 minecraft:stone_bricks
fill 397 228 222 400 228 222 minecraft:mossy_cobblestone
setblock 398 228 220 minecraft:stone_bricks
fill 398 228 221 401 228 221 minecraft:mossy_cobblestone
setblock 399 228 184 minecraft:stone_bricks
setblock 399 228 219 minecraft:stone_bricks
fill 399 228 220 402 228 220 minecraft:mossy_cobblestone
setblock 400 228 183 minecraft:stone_bricks
fill 400 228 184 400 229 184 minecraft:mossy_cobblestone
fill 400 228 219 400 229 219 minecraft:mossy_cobblestone
setblock 401 228 182 minecraft:stone_bricks
fill 401 228 183 401 231 183 minecraft:mossy_cobblestone
setblock 401 228 222 minecraft:stone_bricks
fill 402 228 182 402 231 182 minecraft:mossy_cobblestone
setblock 402 228 221 minecraft:stone_bricks
fill 402 228 222 405 228 222 minecraft:mossy_cobblestone
setblock 403 228 220 minecraft:stone_bricks
fill 403 228 221 406 228 221 minecraft:mossy_cobblestone
fill 404 228 220 404 229 220 minecraft:mossy_cobblestone
setblock 406 228 182 minecraft:stone_bricks
setblock 406 228 220 minecraft:mossy_cobblestone
setblock 406 228 222 minecraft:stone_bricks
fill 407 228 182 408 230 182 minecraft:mossy_cobblestone
setblock 407 228 221 minecraft:stone_bricks
fill 407 228 222 410 228 222 minecraft:mossy_cobblestone
fill 408 228 221 411 228 221 minecraft:mossy_cobblestone
setblock 410 228 182 minecraft:mossy_cobblestone
setblock 411 228 182 minecraft:stone_bricks
fill 411 228 220 412 228 220 minecraft:mossy_cobblestone
setblock 411 228 222 minecraft:stone_bricks
fill 412 228 182 412 231 182 minecraft:mossy_cobblestone
setblock 412 228 221 minecraft:stone_bricks
fill 412 228 222 412 231 222 minecraft:mossy_cobblestone
setblock 413 228 220 minecraft:stone_bricks
fill 413 228 221 413 231 221 minecraft:mossy_cobblestone
setblock 414 228 199 minecraft:stone_bricks
fill 414 228 200 414 228 203 minecraft:mossy_cobblestone
fill 414 228 220 414 230 220 minecraft:mossy_cobblestone
fill 415 228 195 415 228 197 minecraft:mossy_cobblestone
setblock 415 228 198 minecraft:stone_bricks
fill 415 228 199 415 228 202 minecraft:mossy_cobblestone
setblock 415 228 203 minecraft:stone_bricks
fill 415 228 204 415 228 207 minecraft:mossy_cobblestone
setblock 415 228 208 minecraft:stone_bricks
fill 415 228 209 417 229 209 minecraft:mossy_cobblestone
fill 415 228 214 415 228 217 minecraft:mossy_cobblestone
setblock 415 228 218 minecraft:stone_bricks
fill 415 228 219 415 230 219 minecraft:mossy_cobblestone
setblock 415 228 222 minecraft:mossy_cobblestone
setblock 416 228 182 minecraft:stone_bricks
fill 416 228 183 416 231 183 minecraft:mossy_cobblestone
setblock 416 228 192 minecraft:stone_bricks
fill 416 228 193 416 228 196 minecraft:mossy_cobblestone
setblock 416 228 197 minecraft:stone_bricks
fill 416 228 198 416 228 201 minecraft:mossy_cobblestone
setblock 416 228 202 minecraft:stone_bricks
fill 416 228 203 416 231 203 minecraft:mossy_cobblestone
fill 416 228 205 416 228 206 minecraft:mossy_cobblestone
setblock 416 228 207 minecraft:stone_bricks
fill 416 228 208 417 230 208 minecraft:mossy_cobblestone
fill 416 228 210 416 228 211 minecraft:mossy_cobblestone
setblock 416 228 212 minecraft:stone_bricks
fill 416 228 213 416 231 213 minecraft:mossy_cobblestone
setblock 416 228 216 minecraft:mossy_cobblestone
setblock 416 228 217 minecraft:stone_bricks
fill 416 228 218 416 231 218 minecraft:mossy_cobblestone
setblock 416 228 221 minecraft:mossy_cobblestone
setblock 416 228 222 minecraft:stone_bricks
fill 417 228 182 417 231 182 minecraft:mossy_cobblestone
setblock 417 228 186 minecraft:stone_bricks
fill 417 228 187 417 228 190 minecraft:mossy_cobblestone
setblock 417 228 191 minecraft:stone_bricks
fill 417 228 192 417 228 195 minecraft:mossy_cobblestone
setblock 417 228 196 minecraft:stone_bricks
fill 417 228 197 417 228 200 minecraft:mossy_cobblestone
setblock 417 228 201 minecraft:stone_bricks
fill 417 228 202 417 231 202 minecraft:mossy_cobblestone
setblock 417 228 205 minecraft:mossy_cobblestone
setblock 417 228 206 minecraft:stone_bricks
fill 417 228 207 417 231 207 minecraft:mossy_cobblestone
setblock 417 228 210 minecraft:mossy_cobblestone
setblock 417 228 211 minecraft:stone_bricks
fill 417 228 212 417 231 212 minecraft:mossy_cobblestone
setblock 417 228 216 minecraft:stone_bricks
fill 417 228 217 417 231 217 minecraft:mossy_cobblestone
setblock 417 228 221 minecraft:stone_bricks
fill 417 228 222 417 231 222 minecraft:mossy_cobblestone
fill 377 229 182 377 229 184 minecraft:mossy_cobblestone
setblock 377 229 185 minecraft:stone_bricks
fill 377 229 186 377 229 189 minecraft:mossy_cobblestone
setblock 377 229 190 minecraft:stone_bricks
fill 377 229 191 377 229 194 minecraft:mossy_cobblestone
setblock 377 229 195 minecraft:stone_bricks
fill 377 229 196 377 229 199 minecraft:mossy_cobblestone
setblock 377 229 200 minecraft:stone_bricks
fill 377 229 201 377 229 204 minecraft:mossy_cobblestone
setblock 377 229 205 minecraft:stone_bricks
fill 377 229 206 377 229 209 minecraft:mossy_cobblestone
setblock 377 229 210 minecraft:stone_bricks
fill 377 229 211 377 229 214 minecraft:mossy_cobblestone
setblock 377 229 215 minecraft:stone_bricks
fill 377 229 216 377 229 219 minecraft:mossy_cobblestone
setblock 377 229 220 minecraft:stone_bricks
fill 377 229 221 377 231 222 minecraft:mossy_cobblestone
fill 378 229 182 378 229 183 minecraft:mossy_cobblestone
setblock 378 229 184 minecraft:stone_bricks
fill 378 229 185 378 229 188 minecraft:mossy_cobblestone
setblock 378 229 189 minecraft:stone_bricks
fill 378 229 190 378 229 193 minecraft:mossy_cobblestone
setblock 378 229 194 minecraft:stone_bricks
fill 378 229 195 378 229 198 minecraft:mossy_cobblestone
setblock 378 229 199 minecraft:stone_bricks
fill 378 229 200 378 229 203 minecraft:mossy_cobblestone
setblock 378 229 204 minecraft:stone_bricks
fill 378 229 205 378 232 205 minecraft:mossy_cobblestone
setblock 378 229 208 minecraft:mossy_cobblestone
setblock 378 229 209 minecraft:stone_bricks
setblock 378 229 219 minecraft:stone_bricks
fill 378 229 220 378 231 220 minecraft:mossy_cobblestone
fill 378 229 222 379 229 222 minecraft:mossy_cobblestone
setblock 379 229 182 minecraft:mossy_cobblestone
setblock 379 229 183 minecraft:stone_bricks
fill 379 229 184 379 231 185 minecraft:mossy_cobblestone
setblock 379 229 192 minecraft:mossy_cobblestone
setblock 379 229 193 minecraft:stone_bricks
fill 379 229 194 379 229 197 minecraft:mossy_cobblestone
setblock 379 229 198 minecraft:stone_bricks
fill 379 229 199 379 232 199 minecraft:mossy_cobblestone
setblock 379 229 202 minecraft:mossy_cobblestone
setblock 379 229 203 minecraft:stone_bricks
fill 379 229 204 379 231 204 minecraft:mossy_cobblestone
setblock 380 229 182 minecraft:stone_bricks
fill 380 229 183 380 231 184 minecraft:mossy_cobblestone
setblock 380 229 197 minecraft:stone_bricks
setblock 380 229 198 minecraft:mossy_cobblestone
setblock 380 229 202 minecraft:stone_bricks
setblock 380 229 222 minecraft:stone_bricks
fill 381 229 182 384 229 182 minecraft:mossy_cobblestone
setblock 381 229 221 minecraft:stone_bricks
fill 381 229 222 384 229 222 minecraft:mossy_cobblestone
setblock 382 229 221 minecraft:mossy_cobblestone
setblock 384 229 183 minecraft:stone_bricks
setblock 385 229 182 minecraft:stone_bricks
fill 385 229 183 388 229 183 minecraft:mossy_cobblestone
setblock 385 229 222 minecraft:stone_bricks
fill 386 229 182 389 229 182 minecraft:mossy_cobblestone
fill 386 229 222 389 229 222 minecraft:mossy_cobblestone
fill 387 229 196 387 234 196 minecraft:cobbled_deepslate
fill 388 229 195 388 234 195 minecraft:cobbled_deepslate
fill 388 229 221 390 229 221 minecraft:mossy_cobblestone
setblock 389 229 183 minecraft:stone_bricks
fill 389 229 196 389 234 196 minecraft:cobbled_deepslate
setblock 390 229 182 minecraft:stone_bricks
fill 390 229 183 393 229 183 minecraft:mossy_cobblestone
setblock 390 229 222 minecraft:stone_bricks
fill 391 229 182 394 229 182 minecraft:mossy_cobblestone
fill 391 229 184 392 229 184 minecraft:mossy_cobblestone
setblock 391 229 221 minecraft:stone_bricks
fill 391 229 222 394 229 222 minecraft:mossy_cobblestone
setblock 392 229 220 minecraft:stone_bricks
fill 392 229 221 395 229 221 minecraft:mossy_cobblestone
setblock 393 229 184 minecraft:stone_bricks
fill 393 229 220 396 229 220 minecraft:mossy_cobblestone
setblock 394 229 183 minecraft:stone_bricks
fill 394 229 184 394 232 184 minecraft:mossy_cobblestone
setblock 395 229 182 minecraft:stone_bricks
fill 395 229 183 398 229 183 minecraft:mossy_cobblestone
fill 395 229 219 397 229 219 minecraft:mossy_cobblestone
setblock 395 229 222 minecraft:stone_bricks
fill 396 229 182 399 229 182 minecraft:mossy_cobblestone
setblock 396 229 221 minecraft:stone_bricks
fill 396 229 222 399 229 222 minecraft:mossy_cobblestone
setblock 397 229 184 minecraft:mossy_cobblestone
setblock 397 229 220 minecraft:stone_bricks
fill 397 229 221 400 229 221 minecraft:mossy_cobblestone
setblock 398 229 184 minecraft:stone_bricks
setblock 398 229 219 minecraft:stone_bricks
fill 398 229 220 401 229 220 minecraft:mossy_cobblestone
setblock 399 229 183 minecraft:stone_bricks
fill 399 229 184 399 231 184 minecraft:mossy_cobblestone
fill 399 229 219 399 230 219 minecraft:mossy_cobblestone
setblock 400 229 182 minecraft:stone_bricks
fill 400 229 183 400 232 183 minecraft:mossy_cobblestone
setblock 400 229 222 minecraft:stone_bricks
fill 401 229 182 401 232 182 minecraft:mossy_cobblestone
setblock 401 229 221 minecraft:stone_bricks
fill 401 229 222 404 229 222 minecraft:mossy_cobblestone
setblock 402 229 220 minecraft:stone_bricks
fill 402 229 221 405 229 221 minecraft:mossy_cobblestone
fill 403 229 220 403 230 220 minecraft:mossy_cobblestone
setblock 405 229 182 minecraft:stone_bricks
setblock 405 229 222 minecraft:stone_bricks
fill 406 229 182 406 231 182 minecraft:mossy_cobblestone
setblock 406 229 221 minecraft:stone_bricks
fill 406 229 222 409 229 222 minecraft:mossy_cobblestone
fill 407 229 221 410 229 221 minecraft:mossy_cobblestone
setblock 409 229 182 minecraft:mossy_cobblestone
setblock 410 229 182 minecraft:stone_bricks
setblock 410 229 222 minecraft:stone_bricks
fill 411 229 182 411 232 182 minecraft:mossy_cobblestone
setblock 411 229 220 minecraft:mossy_cobblestone
setblock 411 229 221 minecraft:stone_bricks
fill 411 229 222 411 232 222 minecraft:mossy_cobblestone
setblock 412 229 220 minecraft:stone_bricks
fill 412 229 221 412 232 221 minecraft:mossy_cobblestone
fill 413 229 220 413 230 220 minecraft:mossy_cobblestone
setblock 414 229 182 minecraft:mossy_cobblestone
setblock 414 229 183 minecraft:stone_bricks
fill 414 229 199 414 229 202 minecraft:mossy_cobblestone
setblock 414 229 203 minecraft:stone_bricks
fill 414 229 204 415 230 205 minecraft:mossy_cobblestone
setblock 415 229 182 minecraft:stone_bricks
fill 415 229 183 415 232 183 minecraft:mossy_cobblestone
fill 415 229 195 415 229 196 minecraft:mossy_cobblestone
setblock 415 229 197 minecraft:stone_bricks
fill 415 229 198 415 229 201 minecraft:mossy_cobblestone
setblock 415 229 202 minecraft:stone_bricks
fill 415 229 203 415 232 203 minecraft:mossy_cobblestone
setblock 415 229 206 minecraft:mossy_cobblestone
setblock 415 229 207 minecraft:stone_bricks
fill 415 229 208 415 232 208 minecraft:mossy_cobblestone
setblock 415 229 216 minecraft:mossy_cobblestone
setblock 415 229 217 minecraft:stone_bricks
fill 415 229 218 415 230 218 minecraft:mossy_cobblestone
setblock 415 229 222 minecraft:stone_bricks
fill 416 229 182 416 232 182 minecraft:mossy_cobblestone
fill 416 229 184 417 229 184 minecraft:mossy_cobblestone
fill 416 229 192 416 229 195 minecraft:mossy_cobblestone
setblock 416 229 196 minecraft:stone_bricks
fill 416 229 197 416 229 200 minecraft:mossy_cobblestone
setblock 416 229 201 minecraft:stone_bricks
fill 416 229 202 416 232 202 minecraft:mossy_cobblestone
setblock 416 229 205 minecraft:mossy_cobblestone
setblock 416 229 206 minecraft:stone_bricks
fill 416 229 207 416 232 207 minecraft:mossy_cobblestone
setblock 416 229 210 minecraft:mossy_cobblestone
setblock 416 229 211 minecraft:stone_bricks
fill 416 229 212 416 232 212 minecraft:mossy_cobblestone
setblock 416 229 216 minecraft:stone_bricks
fill 416 229 217 416 231 217 minecraft:mossy_cobblestone
setblock 416 229 221 minecraft:stone_bricks
fill 416 229 222 416 232 222 minecraft:mossy_cobblestone
setblock 417 229 185 minecraft:stone_bricks
fill 417 229 186 417 229 189 minecraft:mossy_cobblestone
setblock 417 229 190 minecraft:stone_bricks
fill 417 229 191 417 229 194 minecraft:mossy_cobblestone
setblock 417 229 195 minecraft:stone_bricks
fill 417 229 196 417 229 199 minecraft:mossy_cobblestone
setblock 417 229 200 minecraft:stone_bricks
fill 417 229 201 417 232 201 minecraft:mossy_cobblestone
setblock 417 229 205 minecraft:stone_bricks
fill 417 229 206 417 232 206 minecraft:mossy_cobblestone
setblock 417 229 210 minecraft:stone_bricks
fill 417 229 211 417 232 211 minecraft:mossy_cobblestone
setblock 417 229 215 minecraft:stone_bricks
fill 417 229 216 417 232 216 minecraft:mossy_cobblestone
setblock 417 229 220 minecraft:stone_bricks
fill 417 229 221 417 232 221 minecraft:mossy_cobblestone
fill 377 230 182 377 230 183 minecraft:mossy_cobblestone
setblock 377 230 184 minecraft:stone_bricks
fill 377 230 185 377 230 188 minecraft:mossy_cobblestone
setblock 377 230 189 minecraft:stone_bricks
fill 377 230 190 377 230 193 minecraft:mossy_cobblestone
setblock 377 230 194 minecraft:stone_bricks
fill 377 230 195 377 230 198 minecraft:mossy_cobblestone
setblock 377 230 199 minecraft:stone_bricks
fill 377 230 200 377 230 203 minecraft:mossy_cobblestone
setblock 377 230 204 minecraft:stone_bricks
fill 377 230 205 377 230 208 minecraft:mossy_cobblestone
setblock 377 230 209 minecraft:stone_bricks
fill 377 230 210 377 230 213 minecraft:mossy_cobblestone
setblock 377 230 214 minecraft:stone_bricks
fill 377 230 215 377 230 218 minecraft:mossy_cobblestone
setblock 377 230 219 minecraft:stone_bricks
fill 377 230 220 377 233 220 minecraft:mossy_cobblestone
setblock 378 230 182 minecraft:mossy_cobblestone
setblock 378 230 183 minecraft:stone_bricks
fill 378 230 184 378 230 187 minecraft:mossy_cobblestone
setblock 378 230 188 minecraft:stone_bricks
fill 378 230 189 378 230 192 minecraft:mossy_cobblestone
setblock 378 230 193 minecraft:stone_bricks
fill 378 230 194 378 230 197 minecraft:mossy_cobblestone
setblock 378 230 198 minecraft:stone_bricks
fill 378 230 199 378 230 202 minecraft:mossy_cobblestone
setblock 378 230 203 minecraft:stone_bricks
fill 378 230 204 378 233 204 minecraft:mossy_cobblestone
setblock 378 230 208 minecraft:stone_bricks
setblock 378 230 219 minecraft:mossy_cobblestone
setblock 378 230 222 minecraft:mossy_cobblestone
setblock 379 230 182 minecraft:stone_bricks
fill 379 230 183 379 233 183 minecraft:mossy_cobblestone
fill 379 230 194 379 230 196 minecraft:mossy_cobblestone
setblock 379 230 197 minecraft:stone_bricks
fill 379 230 198 379 231 198 minecraft:mossy_cobblestone
setblock 379 230 202 minecraft:stone_bricks
fill 379 230 203 379 232 203 minecraft:mossy_cobblestone
setblock 379 230 222 minecraft:stone_bricks
fill 380 230 182 383 230 182 minecraft:mossy_cobblestone
setblock 380 230 221 minecraft:stone_bricks
fill 380 230 222 383 230 222 minecraft:mossy_cobblestone
setblock 381 230 221 minecraft:mossy_cobblestone
setblock 383 230 183 minecraft:stone_bricks
setblock 384 230 182 minecraft:stone_bricks
fill 384 230 183 387 230 183 minecraft:mossy_cobblestone
setblock 384 230 222 minecraft:stone_bricks
fill 385 230 182 388 230 182 minecraft:mossy_cobblestone
fill 385 230 222 388 230 222 minecraft:mossy_cobblestone
fill 387 230 195 387 234 195 minecraft:cobbled_deepslate
fill 387 230 197 389 234 197 minecraft:cobbled_deepslate
setblock 388 230 183 minecraft:stone_bricks
setblock 389 230 182 minecraft:stone_bricks
fill 389 230 183 392 230 183 minecraft:mossy_cobblestone
fill 389 230 195 389 234 195 minecraft:cobbled_deepslate
setblock 389 230 221 minecraft:mossy_cobblestone
setblock 389 230 222 minecraft:stone_bricks
fill 390 230 182 393 230 182 minecraft:mossy_cobblestone
setblock 390 230 221 minecraft:stone_bricks
fill 390 230 222 393 230 222 minecraft:mossy_cobblestone
setblock 391 230 184 minecraft:mossy_cobblestone
fill 391 230 221 394 230 221 minecraft:mossy_cobblestone
setblock 392 230 184 minecraft:stone_bricks
fill 392 230 220 395 230 220 minecraft:mossy_cobblestone
setblock 393 230 183 minecraft:stone_bricks
fill 393 230 184 393 233 184 minecraft:mossy_cobblestone
setblock 394 230 182 minecraft:stone_bricks
fill 394 230 183 397 230 183 minecraft:mossy_cobblestone
setblock 394 230 222 minecraft:stone_bricks
fill 395 230 182 398 230 182 minecraft:mossy_cobblestone
fill 395 230 219 396 230 219 minecraft:mossy_cobblestone
setblock 395 230 221 minecraft:stone_bricks
fill 395 230 222 398 230 222 minecraft:mossy_cobblestone
setblock 396 230 220 minecraft:stone_bricks
fill 396 230 221 399 230 221 minecraft:mossy_cobblestone
setblock 397 230 184 minecraft:stone_bricks
setblock 397 230 219 minecraft:stone_bricks
fill 397 230 220 400 230 220 minecraft:mossy_cobblestone
setblock 398 230 183 minecraft:stone_bricks
fill 398 230 184 398 232 184 minecraft:mossy_cobblestone
setblock 398 230 219 minecraft:mossy_cobblestone
setblock 399 230 182 minecraft:stone_bricks
fill 399 230 183 399 233 183 minecraft:mossy_cobblestone
setblock 399 230 222 minecraft:stone_bricks
fill 400 230 182 400 233 182 minecraft:mossy_cobblestone
setblock 400 230 221 minecraft:stone_bricks
fill 400 230 222 403 230 222 minecraft:mossy_cobblestone
setblock 401 230 220 minecraft:stone_bricks
fill 401 230 221 404 230 221 minecraft:mossy_cobblestone
setblock 402 230 220 minecraft:mossy_cobblestone
setblock 404 230 182 minecraft:stone_bricks
setblock 404 230 222 minecraft:stone_bricks
fill 405 230 182 405 231 182 minecraft:mossy_cobblestone
setblock 405 230 221 minecraft:stone_bricks
fill 405 230 222 408 230 222 minecraft:mossy_cobblestone
fill 406 230 221 409 230 221 minecraft:mossy_cobblestone
setblock 409 230 182 minecraft:stone_bricks
setblock 409 230 222 minecraft:stone_bricks
fill 410 230 182 410 233 182 minecraft:mossy_cobblestone
setblock 410 230 221 minecraft:stone_bricks
fill 410 230 222 410 233 222 minecraft:mossy_cobblestone
fill 411 230 221 411 232 221 minecraft:mossy_cobblestone
setblock 412 230 220 minecraft:mossy_cobblestone
setblock 414 230 182 minecraft:stone_bricks
fill 414 230 183 414 233 183 minecraft:mossy_cobblestone
fill 414 230 199 414 230 201 minecraft:mossy_cobblestone
setblock 414 230 202 minecraft:stone_bricks
fill 414 230 203 414 233 203 minecraft:mossy_cobblestone
setblock 414 230 206 minecraft:mossy_cobblestone
setblock 414 230 222 minecraft:stone_bricks
fill 415 230 182 415 233 182 minecraft:mossy_cobblestone
setblock 415 230 196 minecraft:stone_bricks
fill 415 230 197 415 230 200 minecraft:mossy_cobblestone
setblock 415 230 201 minecraft:stone_bricks
fill 415 230 202 415 233 202 minecraft:mossy_cobblestone
setblock 415 230 206 minecraft:stone_bricks
fill 415 230 207 415 233 207 minecraft:mossy_cobblestone
fill 415 230 209 416 230 209 minecraft:mossy_cobblestone
setblock 415 230 221 minecraft:stone_bricks
fill 415 230 222 415 233 222 minecraft:mossy_cobblestone
setblock 416 230 184 minecraft:mossy_cobblestone
setblock 416 230 185 minecraft:stone_bricks
fill 416 230 193 416 230 194 minecraft:mossy_cobblestone
setblock 416 230 195 minecraft:stone_bricks
fill 416 230 196 416 230 199 minecraft:mossy_cobblestone
setblock 416 230 200 minecraft:stone_bricks
fill 416 230 201 416 233 201 minecraft:mossy_cobblestone
setblock 416 230 204 minecraft:mossy_cobblestone
setblock 416 230 205 minecraft:stone_bricks
fill 416 230 206 416 233 206 minecraft:mossy_cobblestone
setblock 416 230 210 minecraft:stone_bricks
fill 416 230 211 416 233 211 minecraft:mossy_cobblestone
setblock 416 230 215 minecraft:stone_bricks
fill 416 230 216 416 231 216 minecraft:mossy_cobblestone
setblock 416 230 220 minecraft:stone_bricks
fill 416 230 221 416 232 221 minecraft:mossy_cobblestone
setblock 417 230 184 minecraft:stone_bricks
fill 417 230 185 417 230 188 minecraft:mossy_cobblestone
setblock 417 230 189 minecraft:stone_bricks
fill 417 230 190 417 230 193 minecraft:mossy_cobblestone
setblock 417 230 194 minecraft:stone_bricks
fill 417 230 195 417 230 198 minecraft:mossy_cobblestone
setblock 417 230 199 minecraft:stone_bricks
fill 417 230 200 417 233 200 minecraft:mossy_cobblestone
setblock 417 230 204 minecraft:stone_bricks
fill 417 230 205 417 233 205 minecraft:mossy_cobblestone
setblock 417 230 209 minecraft:stone_bricks
fill 417 230 210 417 233 210 minecraft:mossy_cobblestone
setblock 417 230 214 minecraft:stone_bricks
fill 417 230 215 417 232 215 minecraft:mossy_cobblestone
setblock 417 230 219 minecraft:stone_bricks
fill 417 230 220 417 233 220 minecraft:mossy_cobblestone
setblock 377 231 182 minecraft:mossy_cobblestone
setblock 377 231 183 minecraft:stone_bricks
fill 377 231 184 377 231 187 minecraft:mossy_cobblestone
setblock 377 231 188 minecraft:stone_bricks
fill 377 231 189 377 231 192 minecraft:mossy_cobblestone
setblock 377 231 193 minecraft:stone_bricks
fill 377 231 194 377 231 197 minecraft:mossy_cobblestone
setblock 377 231 198 minecraft:stone_bricks
fill 377 231 199 377 231 202 minecraft:mossy_cobblestone
setblock 377 231 203 minecraft:stone_bricks
fill 377 231 204 377 231 207 minecraft:mossy_cobblestone
setblock 377 231 208 minecraft:stone_bricks
fill 377 231 209 377 231 212 minecraft:mossy_cobblestone
fill 377 231 216 377 231 217 minecraft:mossy_cobblestone
setblock 377 231 218 minecraft:stone_bricks
fill 377 231 219 377 232 219 minecraft:mossy_cobblestone
setblock 378 231 182 minecraft:stone_bricks
fill 378 231 183 378 231 186 minecraft:mossy_cobblestone
setblock 378 231 187 minecraft:stone_bricks
fill 378 231 188 378 231 191 minecraft:mossy_cobblestone
setblock 378 231 192 minecraft:stone_bricks
fill 378 231 193 378 231 196 minecraft:mossy_cobblestone
setblock 378 231 197 minecraft:stone_bricks
fill 378 231 198 378 231 201 minecraft:mossy_cobblestone
setblock 378 231 202 minecraft:stone_bricks
fill 378 231 203 378 234 203 minecraft:mossy_cobblestone
setblock 378 231 207 minecraft:stone_bricks
setblock 378 231 208 minecraft:mossy_cobblestone
setblock 378 231 222 minecraft:stone_bricks
fill 379 231 182 382 231 182 minecraft:mossy_cobblestone
setblock 379 231 196 minecraft:stone_bricks
setblock 379 231 197 minecraft:mossy_cobblestone
setblock 379 231 201 minecraft:stone_bricks
fill 379 231 202 379 232 202 minecraft:mossy_cobblestone
setblock 379 231 221 minecraft:stone_bricks
fill 379 231 222 382 231 222 minecraft:mossy_cobblestone
setblock 382 231 183 minecraft:stone_bricks
setblock 383 231 182 minecraft:stone_bricks
fill 383 231 183 386 231 183 minecraft:mossy_cobblestone
setblock 383 231 222 minecraft:stone_bricks
fill 384 231 182 387 231 182 minecraft:mossy_cobblestone
fill 384 231 222 387 231 222 minecraft:mossy_cobblestone
fill 386 231 196 386 234 196 minecraft:cobbled_deepslate
setblock 387 231 183 minecraft:stone_bricks
fill 387 231 194 389 234 194 minecraft:cobbled_deepslate
setblock 388 231 182 minecraft:stone_bricks
fill 388 231 183 391 231 183 minecraft:mossy_cobblestone
setblock 388 231 222 minecraft:stone_bricks
fill 389 231 182 392 231 182 minecraft:mossy_cobblestone
setblock 389 231 221 minecraft:stone_bricks
fill 389 231 222 392 231 222 minecraft:mossy_cobblestone
setblock 390 231 184 minecraft:mossy_cobblestone
fill 390 231 196 390 234 196 minecraft:cobbled_deepslate
fill 390 231 221 393 231 221 minecraft:mossy_cobblestone
setblock 391 231 184 minecraft:stone_bricks
setblock 392 231 183 minecraft:stone_bricks
fill 392 231 184 392 234 184 minecraft:mossy_cobblestone
fill 392 231 220 394 231 220 minecraft:mossy_cobblestone
setblock 393 231 182 minecraft:stone_bricks
fill 393 231 183 396 231 183 minecraft:mossy_cobblestone
setblock 393 231 222 minecraft:stone_bricks
fill 394 231 182 397 231 182 minecraft:mossy_cobblestone
setblock 394 231 221 minecraft:stone_bricks
fill 394 231 222 397 231 222 minecraft:mossy_cobblestone
setblock 395 231 220 minecraft:stone_bricks
fill 395 231 221 398 231 221 minecraft:mossy_cobblestone
setblock 396 231 184 minecraft:stone_bricks
fill 396 231 220 399 231 220 minecraft:mossy_cobblestone
setblock 397 231 183 minecraft:stone_bricks
fill 397 231 184 397 233 184 minecraft:mossy_cobblestone
setblock 398 231 182 minecraft:stone_bricks
fill 398 231 183 398 234 183 minecraft:mossy_cobblestone
setblock 398 231 222 minecraft:stone_bricks
fill 399 231 182 399 234 182 minecraft:mossy_cobblestone
setblock 399 231 221 minecraft:stone_bricks
fill 399 231 222 402 231 222 minecraft:mossy_cobblestone
setblock 400 231 220 minecraft:stone_bricks
fill 400 231 221 403 231 221 minecraft:mossy_cobblestone
setblock 401 231 220 minecraft:mossy_cobblestone
setblock 402 231 183 minecraft:stone_bricks
setblock 403 231 182 minecraft:stone_bricks
setblock 403 231 222 minecraft:stone_bricks
fill 404 231 182 404 232 182 minecraft:mossy_cobblestone
setblock 404 231 221 minecraft:stone_bricks
fill 404 231 222 407 231 222 minecraft:mossy_cobblestone
fill 405 231 221 408 231 221 minecraft:mossy_cobblestone
setblock 407 231 182 minecraft:mossy_cobblestone
setblock 408 231 182 minecraft:stone_bricks
setblock 408 231 222 minecraft:stone_bricks
fill 409 231 182 409 234 182 minecraft:mossy_cobblestone
setblock 409 231 221 minecraft:stone_bricks
fill 409 231 222 409 234 222 minecraft:mossy_cobblestone
fill 410 231 221 410 232 221 minecraft:mossy_cobblestone
setblock 413 231 182 minecraft:stone_bricks
fill 413 231 183 413 234 183 minecraft:mossy_cobblestone
setblock 413 231 222 minecraft:stone_bricks
fill 414 231 182 414 234 182 minecraft:mossy_cobblestone
fill 414 231 199 414 231 200 minecraft:mossy_cobblestone
setblock 414 231 201 minecraft:stone_bricks
fill 414 231 202 414 234 202 minecraft:mossy_cobblestone
fill 414 231 204 414 231 205 minecraft:mossy_cobblestone
setblock 414 231 206 minecraft:stone_bricks
setblock 414 231 221 minecraft:stone_bricks
fill 414 231 222 414 234 222 minecraft:mossy_cobblestone
fill 415 231 196 415 231 199 minecraft:mossy_cobblestone
setblock 415 231 200 minecraft:stone_bricks
fill 415 231 201 415 234 201 minecraft:mossy_cobblestone
setblock 415 231 204 minecraft:mossy_cobblestone
setblock 415 231 205 minecraft:stone_bricks
fill 415 231 206 415 234 206 minecraft:mossy_cobblestone
setblock 415 231 209 minecraft:mossy_cobblestone
fill 415 231 221 415 233 221 minecraft:mossy_cobblestone
setblock 416 231 184 minecraft:stone_bricks
fill 416 231 185 417 233 185 minecraft:mossy_cobblestone
setblock 416 231 193 minecraft:mossy_cobblestone
setblock 416 231 194 minecraft:stone_bricks
fill 416 231 195 416 231 198 minecraft:mossy_cobblestone
setblock 416 231 199 minecraft:stone_bricks
fill 416 231 200 416 234 200 minecraft:mossy_cobblestone
setblock 416 231 204 minecraft:stone_bricks
fill 416 231 205 416 234 205 minecraft:mossy_cobblestone
setblock 416 231 208 minecraft:mossy_cobblestone
setblock 416 231 209 minecraft:stone_bricks
fill 416 231 210 416 234 210 minecraft:mossy_cobblestone
setblock 416 231 214 minecraft:stone_bricks
setblock 416 231 215 minecraft:mossy_cobblestone
setblock 416 231 219 minecraft:stone_bricks
fill 416 231 220 416 232 220 minecraft:mossy_cobblestone
setblock 417 231 183 minecraft:stone_bricks
fill 417 231 184 417 234 184 minecraft:mossy_cobblestone
fill 417 231 186 417 231 187 minecraft:mossy_cobblestone
setblock 417 231 188 minecraft:stone_bricks
fill 417 231 189 417 231 192 minecraft:mossy_cobblestone
setblock 417 231 193 minecraft:stone_bricks
fill 417 231 194 417 231 197 minecraft:mossy_cobblestone
setblock 417 231 198 minecraft:stone_bricks
fill 417 231 199 417 234 199 minecraft:mossy_cobblestone
setblock 417 231 203 minecraft:stone_bricks
fill 417 231 204 417 234 204 minecraft:mossy_cobblestone
setblock 417 231 208 minecraft:stone_bricks
fill 417 231 209 417 234 209 minecraft:mossy_cobblestone
setblock 417 231 213 minecraft:stone_bricks
fill 417 231 214 417 233 214 minecraft:mossy_cobblestone
setblock 417 231 218 minecraft:stone_bricks
fill 417 231 219 417 233 219 minecraft:mossy_cobblestone
setblock 377 232 182 minecraft:stone_bricks
fill 377 232 183 377 232 186 minecraft:mossy_cobblestone
setblock 377 232 187 minecraft:stone_bricks
fill 377 232 188 377 232 191 minecraft:mossy_cobblestone
setblock 377 232 192 minecraft:stone_bricks
fill 377 232 193 377 232 196 minecraft:mossy_cobblestone
setblock 377 232 197 minecraft:stone_bricks
fill 377 232 198 377 232 201 minecraft:mossy_cobblestone
setblock 377 232 202 minecraft:stone_bricks
fill 377 232 203 377 232 206 minecraft:mossy_cobblestone
setblock 377 232 207 minecraft:stone_bricks
fill 377 232 208 377 233 210 minecraft:mossy_cobblestone
setblock 377 232 218 minecraft:mossy_cobblestone
setblock 377 232 221 minecraft:mossy_cobblestone
setblock 377 232 222 minecraft:stone_bricks
fill 378 232 182 378 232 185 minecraft:mossy_cobblestone
setblock 378 232 186 minecraft:stone_bricks
fill 378 232 187 378 232 190 minecraft:mossy_cobblestone
setblock 378 232 191 minecraft:stone_bricks
fill 378 232 192 378 232 195 minecraft:mossy_cobblestone
setblock 378 232 196 minecraft:stone_bricks
fill 378 232 197 378 232 200 minecraft:mossy_cobblestone
setblock 378 232 201 minecraft:stone_bricks
fill 378 232 202 378 235 202 minecraft:mossy_cobblestone
setblock 378 232 206 minecraft:stone_bricks
fill 378 232 207 378 233 207 minecraft:mossy_cobblestone
fill 378 232 222 381 232 222 minecraft:mossy_cobblestone
fill 379 232 182 381 232 182 minecraft:mossy_cobblestone
setblock 379 232 184 minecraft:mossy_cobblestone
setblock 379 232 200 minecraft:stone_bricks
setblock 379 232 201 minecraft:mossy_cobblestone
setblock 380 232 183 minecraft:mossy_cobblestone
setblock 381 232 183 minecraft:stone_bricks
setblock 382 232 182 minecraft:stone_bricks
fill 382 232 183 385 232 183 minecraft:mossy_cobblestone
setblock 382 232 222 minecraft:stone_bricks
fill 383 232 182 386 232 182 minecraft:mossy_cobblestone
fill 383 232 222 386 232 222 minecraft:mossy_cobblestone
setblock 386 232 183 minecraft:stone_bricks
fill 386 232 195 386 234 195 minecraft:cobbled_deepslate
fill 386 232 197 386 234 197 minecraft:cobbled_deepslate
setblock 387 232 182 minecraft:stone_bricks
fill 387 232 183 390 232 183 minecraft:mossy_cobblestone
fill 387 232 198 389 234 198 minecraft:cobbled_deepslate
setblock 387 232 222 minecraft:stone_bricks
fill 388 232 182 391 232 182 minecraft:mossy_cobblestone
fill 388 232 222 391 232 222 minecraft:mossy_cobblestone
fill 389 232 221 392 232 221 minecraft:mossy_cobblestone
setblock 390 232 184 minecraft:stone_bricks
fill 390 232 195 390 234 195 minecraft:cobbled_deepslate
fill 390 232 197 390 234 197 minecraft:cobbled_deepslate
setblock 391 232 183 minecraft:stone_bricks
fill 391 232 184 391 235 184 minecraft:mossy_cobblestone
setblock 392 232 182 minecraft:stone_bricks
fill 392 232 183 395 232 183 minecraft:mossy_cobblestone
fill 392 232 220 393 232 220 minecraft:mossy_cobblestone
setblock 392 232 222 minecraft:stone_bricks
fill 393 232 182 396 232 182 minecraft:mossy_cobblestone
setblock 393 232 221 minecraft:stone_bricks
fill 393 232 222 396 232 222 minecraft:mossy_cobblestone
setblock 394 232 220 minecraft:stone_bricks
fill 394 232 221 397 232 221 minecraft:mossy_cobblestone
setblock 395 232 184 minecraft:stone_bricks
fill 395 232 220 398 232 220 minecraft:mossy_cobblestone
setblock 396 232 183 minecraft:stone_bricks
fill 396 232 184 396 235 184 minecraft:mossy_cobblestone
setblock 397 232 182 minecraft:stone_bricks
fill 397 232 183 397 235 183 minecraft:mossy_cobblestone
setblock 397 232 222 minecraft:stone_bricks
fill 398 232 182 398 235 182 minecraft:mossy_cobblestone
setblock 398 232 221 minecraft:stone_bricks
fill 398 232 222 401 232 222 minecraft:mossy_cobblestone
setblock 399 232 220 minecraft:stone_bricks
fill 399 232 221 402 232 221 minecraft:mossy_cobblestone
setblock 400 232 220 minecraft:mossy_cobblestone
setblock 401 232 183 minecraft:stone_bricks
setblock 402 232 182 minecraft:stone_bricks
setblock 402 232 222 minecraft:stone_bricks
fill 403 232 182 403 233 182 minecraft:mossy_cobblestone
setblock 403 232 221 minecraft:stone_bricks
fill 403 232 222 406 232 222 minecraft:mossy_cobblestone
setblock 407 232 222 minecraft:stone_bricks
setblock 408 232 182 minecraft:mossy_cobblestone
fill 408 232 222 408 235 222 minecraft:mossy_cobblestone
setblock 412 232 182 minecraft:stone_bricks
setblock 412 232 222 minecraft:stone_bricks
fill 413 232 182 413 235 182 minecraft:mossy_cobblestone
setblock 413 232 221 minecraft:stone_bricks
fill 413 232 222 413 235 222 minecraft:mossy_cobblestone
setblock 414 232 200 minecraft:stone_bricks
fill 414 232 201 414 233 201 minecraft:mossy_cobblestone
setblock 414 232 204 minecraft:mossy_cobblestone
setblock 414 232 205 minecraft:stone_bricks
fill 414 232 206 414 235 206 minecraft:mossy_cobblestone
fill 414 232 221 414 233 221 minecraft:mossy_cobblestone
fill 415 232 197 415 232 198 minecraft:mossy_cobblestone
setblock 415 232 199 minecraft:stone_bricks
fill 415 232 200 415 235 200 minecraft:mossy_cobblestone
setblock 415 232 204 minecraft:stone_bricks
fill 415 232 205 415 235 205 minecraft:mossy_cobblestone
setblock 415 232 209 minecraft:stone_bricks
setblock 416 232 183 minecraft:stone_bricks
fill 416 232 184 416 235 184 minecraft:mossy_cobblestone
fill 416 232 186 417 232 186 minecraft:mossy_cobblestone
fill 416 232 194 416 232 197 minecraft:mossy_cobblestone
setblock 416 232 198 minecraft:stone_bricks
fill 416 232 199 416 235 199 minecraft:mossy_cobblestone
setblock 416 232 203 minecraft:stone_bricks
fill 416 232 204 416 235 204 minecraft:mossy_cobblestone
setblock 416 232 208 minecraft:stone_bricks
fill 416 232 209 416 235 209 minecraft:mossy_cobblestone
setblock 416 232 219 minecraft:mossy_cobblestone
setblock 417 232 182 minecraft:stone_bricks
fill 417 232 183 417 235 183 minecraft:mossy_cobblestone
setblock 417 232 187 minecraft:stone_bricks
fill 417 232 188 417 232 191 minecraft:mossy_cobblestone
setblock 417 232 192 minecraft:stone_bricks
fill 417 232 193 417 232 196 minecraft:mossy_cobblestone
setblock 417 232 197 minecraft:stone_bricks
fill 417 232 198 417 235 198 minecraft:mossy_cobblestone
setblock 417 232 202 minecraft:stone_bricks
fill 417 232 203 417 235 203 minecraft:mossy_cobblestone
setblock 417 232 207 minecraft:stone_bricks
fill 417 232 208 417 235 208 minecraft:mossy_cobblestone
setblock 417 232 212 minecraft:stone_bricks
fill 417 232 213 417 234 213 minecraft:mossy_cobblestone
setblock 417 232 217 minecraft:stone_bricks
fill 417 232 218 417 233 218 minecraft:mossy_cobblestone
setblock 417 232 222 minecraft:stone_bricks
fill 377 233 182 377 233 185 minecraft:mossy_cobblestone
setblock 377 233 186 minecraft:stone_bricks
fill 377 233 187 377 233 190 minecraft:mossy_cobblestone
setblock 377 233 191 minecraft:stone_bricks
fill 377 233 192 377 233 195 minecraft:mossy_cobblestone
setblock 377 233 196 minecraft:stone_bricks
fill 377 233 197 377 233 200 minecraft:mossy_cobblestone
setblock 377 233 201 minecraft:stone_bricks
fill 377 233 202 377 233 205 minecraft:mossy_cobblestone
setblock 377 233 206 minecraft:stone_bricks
fill 377 233 207 377 236 207 minecraft:mossy_cobblestone
setblock 377 233 221 minecraft:stone_bricks
fill 377 233 222 380 233 222 minecraft:mossy_cobblestone
fill 378 233 182 378 233 184 minecraft:mossy_cobblestone
setblock 378 233 185 minecraft:stone_bricks
fill 378 233 186 378 233 189 minecraft:mossy_cobblestone
setblock 378 233 190 minecraft:stone_bricks
fill 378 233 196 378 233 199 minecraft:mossy_cobblestone
setblock 378 233 200 minecraft:stone_bricks
fill 378 233 201 378 234 201 minecraft:mossy_cobblestone
setblock 378 233 205 minecraft:stone_bricks
fill 378 233 206 378 234 206 minecraft:mossy_cobblestone
fill 379 233 182 380 233 182 minecraft:mossy_cobblestone
setblock 379 233 184 minecraft:light[level=12]
setblock 379 233 192 minecraft:light[level=12]
setblock 379 233 200 minecraft:light[level=12]
setblock 379 233 208 minecraft:light[level=12]
setblock 379 233 216 minecraft:light[level=12]
setblock 380 233 183 minecraft:stone_bricks
setblock 381 233 182 minecraft:stone_bricks
fill 381 233 183 384 233 183 minecraft:mossy_cobblestone
fill 382 233 182 385 233 182 minecraft:mossy_cobblestone
setblock 385 233 183 minecraft:stone_bricks
fill 385 233 196 385 234 196 minecraft:cobbled_deepslate
setblock 386 233 182 minecraft:stone_bricks
fill 386 233 183 389 233 183 minecraft:mossy_cobblestone
fill 386 233 194 386 234 194 minecraft:cobbled_deepslate
fill 386 233 198 386 234 198 minecraft:cobbled_deepslate
setblock 386 233 222 minecraft:stone_bricks
fill 387 233 182 390 233 182 minecraft:mossy_cobblestone
setblock 387 233 184 minecraft:light[level=12]
setblock 387 233 192 minecraft:light[level=12]
fill 387 233 193 389 234 193 minecraft:cobbled_deepslate
setblock 387 233 200 minecraft:light[level=12]
setblock 387 233 208 minecraft:light[level=12]
setblock 387 233 216 minecraft:light[level=12]
fill 387 233 222 390 233 222 minecraft:mossy_cobblestone
setblock 389 233 184 minecraft:stone_bricks
setblock 390 233 183 minecraft:stone_bricks
fill 390 233 184 390 236 184 minecraft:mossy_cobblestone
fill 390 233 194 390 234 194 minecraft:cobbled_deepslate
fill 390 233 221 391 233 221 minecraft:mossy_cobblestone
setblock 391 233 182 minecraft:stone_bricks
fill 391 233 183 394 233 183 minecraft:mossy_cobblestone
setblock 391 233 222 minecraft:stone_bricks
fill 392 233 182 395 233 182 minecraft:mossy_cobblestone
setblock 392 233 221 minecraft:stone_bricks
fill 392 233 222 395 233 222 minecraft:mossy_cobblestone
setblock 393 233 220 minecraft:stone_bricks
fill 393 233 221 396 233 221 minecraft:mossy_cobblestone
setblock 394 233 184 minecraft:stone_bricks
fill 394 233 220 397 233 220 minecraft:mossy_cobblestone
setblock 395 233 183 minecraft:stone_bricks
fill 395 233 184 395 236 184 minecraft:mossy_cobblestone
setblock 395 233 192 minecraft:light[level=12]
setblock 395 233 200 minecraft:light[level=12]
setblock 395 233 208 minecraft:light[level=12]
setblock 395 233 216 minecraft:light[level=12]
setblock 396 233 182 minecraft:stone_bricks
fill 396 233 183 396 236 183 minecraft:mossy_cobblestone
setblock 396 233 222 minecraft:stone_bricks
fill 397 233 182 397 236 182 minecraft:mossy_cobblestone
setblock 397 233 221 minecraft:stone_bricks
fill 397 233 222 400 233 222 minecraft:mossy_cobblestone
setblock 398 233 220 minecraft:stone_bricks
fill 398 233 221 401 233 221 minecraft:mossy_cobblestone
setblock 400 233 183 minecraft:stone_bricks
setblock 401 233 182 minecraft:stone_bricks
setblock 401 233 222 minecraft:stone_bricks
fill 402 233 182 402 234 182 minecraft:mossy_cobblestone
fill 402 233 222 405 233 222 minecraft:mossy_cobblestone
setblock 403 233 184 minecraft:light[level=12]
setblock 403 233 192 minecraft:light[level=12]
setblock 403 233 200 minecraft:light[level=12]
setblock 403 233 208 minecraft:light[level=12]
setblock 403 233 216 minecraft:light[level=12]
setblock 406 233 222 minecraft:stone_bricks
fill 407 233 222 407 234 222 minecraft:mossy_cobblestone
setblock 411 233 182 minecraft:stone_bricks
setblock 411 233 184 minecraft:light[level=12]
setblock 411 233 192 minecraft:light[level=12]
setblock 411 233 200 minecraft:light[level=12]
setblock 411 233 208 minecraft:light[level=12]
setblock 411 233 216 minecraft:light[level=12]
setblock 411 233 222 minecraft:stone_bricks
fill 412 233 182 412 236 182 minecraft:mossy_cobblestone
setblock 412 233 221 minecraft:stone_bricks
fill 412 233 222 412 236 222 minecraft:mossy_cobblestone
setblock 413 233 221 minecraft:mossy_cobblestone
setblock 414 233 204 minecraft:stone_bricks
fill 414 233 205 414 236 205 minecraft:mossy_cobblestone
setblock 415 233 183 minecraft:stone_bricks
setblock 415 233 198 minecraft:stone_bricks
fill 415 233 199 415 234 199 minecraft:mossy_cobblestone
setblock 415 233 203 minecraft:stone_bricks
fill 415 233 204 415 236 204 minecraft:mossy_cobblestone
setblock 415 233 208 minecraft:stone_bricks
fill 415 233 209 415 236 209 minecraft:mossy_cobblestone
setblock 416 233 182 minecraft:stone_bricks
fill 416 233 183 416 236 183 minecraft:mossy_cobblestone
setblock 416 233 186 minecraft:mossy_cobblestone
fill 416 233 195 416 233 196 minecraft:mossy_cobblestone
setblock 416 233 197 minecraft:stone_bricks
fill 416 233 198 416 236 198 minecraft:mossy_cobblestone
setblock 416 233 202 minecraft:stone_bricks
fill 416 233 203 416 236 203 minecraft:mossy_cobblestone
setblock 416 233 207 minecraft:stone_bricks
fill 416 233 208 416 236 208 minecraft:mossy_cobblestone
setblock 416 233 222 minecraft:stone_bricks
fill 417 233 182 417 236 182 minecraft:mossy_cobblestone
setblock 417 233 186 minecraft:stone_bricks
fill 417 233 187 417 233 190 minecraft:mossy_cobblestone
setblock 417 233 191 minecraft:stone_bricks
fill 417 233 192 417 233 195 minecraft:mossy_cobblestone
setblock 417 233 196 minecraft:stone_bricks
fill 417 233 197 417 236 197 minecraft:mossy_cobblestone
setblock 417 233 201 minecraft:stone_bricks
fill 417 233 202 417 236 202 minecraft:mossy_cobblestone
setblock 417 233 206 minecraft:stone_bricks
fill 417 233 207 417 236 207 minecraft:mossy_cobblestone
setblock 417 233 211 minecraft:stone_bricks
fill 417 233 212 417 236 212 minecraft:mossy_cobblestone
setblock 417 233 221 minecraft:stone_bricks
fill 417 233 222 417 234 222 minecraft:mossy_cobblestone
fill 377 234 182 377 234 184 minecraft:mossy_cobblestone
setblock 377 234 185 minecraft:stone_bricks
fill 377 234 186 377 234 189 minecraft:mossy_cobblestone
setblock 377 234 190 minecraft:stone_bricks
fill 377 234 191 377 234 194 minecraft:mossy_cobblestone
setblock 377 234 195 minecraft:stone_bricks
fill 377 234 196 377 234 199 minecraft:mossy_cobblestone
setblock 377 234 200 minecraft:stone_bricks
fill 377 234 201 377 234 204 minecraft:mossy_cobblestone
setblock 377 234 205 minecraft:stone_bricks
fill 377 234 206 377 237 206 minecraft:mossy_cobblestone
fill 377 234 208 377 234 209 minecraft:mossy_cobblestone
fill 377 234 222 378 234 222 minecraft:mossy_cobblestone
fill 378 234 182 378 234 183 minecraft:mossy_cobblestone
setblock 378 234 184 minecraft:stone_bricks
fill 378 234 185 378 234 188 minecraft:mossy_cobblestone
setblock 378 234 189 minecraft:stone_bricks
setblock 378 234 199 minecraft:stone_bricks
setblock 378 234 200 minecraft:mossy_cobblestone
setblock 378 234 204 minecraft:stone_bricks
fill 378 234 205 378 235 205 minecraft:mossy_cobblestone
setblock 379 234 182 minecraft:mossy_cobblestone
setblock 379 234 183 minecraft:stone_bricks
setblock 380 234 182 minecraft:stone_bricks
fill 380 234 183 383 234 183 minecraft:mossy_cobblestone
fill 381 234 182 384 234 182 minecraft:mossy_cobblestone
setblock 384 234 183 minecraft:stone_bricks
setblock 385 234 182 minecraft:stone_bricks
schedule function dropper:buildpart/44_10 1t
