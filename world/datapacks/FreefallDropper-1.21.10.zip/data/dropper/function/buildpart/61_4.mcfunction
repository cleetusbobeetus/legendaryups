setblock 81 244 313 minecraft:shroomlight
setblock 81 244 315 minecraft:shroomlight
setblock 82 244 276 minecraft:shroomlight
setblock 82 244 278 minecraft:shroomlight
setblock 82 244 280 minecraft:shroomlight
setblock 82 244 282 minecraft:shroomlight
setblock 82 244 308 minecraft:shroomlight
setblock 82 244 310 minecraft:shroomlight
setblock 82 244 312 minecraft:shroomlight
setblock 82 244 314 minecraft:shroomlight
setblock 82 244 316 minecraft:shroomlight
setblock 83 244 277 minecraft:shroomlight
setblock 83 244 279 minecraft:shroomlight
setblock 83 244 281 minecraft:shroomlight
setblock 83 244 283 minecraft:shroomlight
setblock 83 244 307 minecraft:shroomlight
setblock 83 244 309 minecraft:shroomlight
setblock 83 244 311 minecraft:shroomlight
setblock 83 244 313 minecraft:shroomlight
setblock 83 244 315 minecraft:shroomlight
setblock 84 244 276 minecraft:shroomlight
setblock 84 244 278 minecraft:shroomlight
setblock 84 244 280 minecraft:shroomlight
setblock 84 244 282 minecraft:shroomlight
setblock 84 244 308 minecraft:shroomlight
setblock 84 244 310 minecraft:shroomlight
setblock 84 244 312 minecraft:shroomlight
setblock 84 244 314 minecraft:shroomlight
setblock 84 244 316 minecraft:shroomlight
setblock 85 244 277 minecraft:shroomlight
setblock 85 244 279 minecraft:shroomlight
setblock 85 244 281 minecraft:shroomlight
setblock 85 244 283 minecraft:shroomlight
setblock 85 244 307 minecraft:shroomlight
setblock 85 244 309 minecraft:shroomlight
setblock 85 244 311 minecraft:shroomlight
setblock 85 244 313 minecraft:shroomlight
setblock 85 244 315 minecraft:shroomlight
setblock 86 244 276 minecraft:shroomlight
setblock 86 244 278 minecraft:shroomlight
setblock 86 244 280 minecraft:shroomlight
setblock 86 244 282 minecraft:shroomlight
setblock 88 244 281 minecraft:spruce_planks
setblock 88 244 288 minecraft:spruce_planks
setblock 88 244 295 minecraft:spruce_planks
setblock 88 244 302 minecraft:spruce_planks
setblock 88 244 309 minecraft:spruce_planks
setblock 89 244 276 minecraft:light_blue_wool
fill 89 244 311 89 249 311 minecraft:cyan_concrete
fill 56 245 298 56 246 298 minecraft:stripped_dark_oak_log
fill 75 245 307 75 246 307 minecraft:spruce_planks
fill 75 245 309 75 246 309 minecraft:spruce_planks
fill 75 245 311 75 246 311 minecraft:spruce_planks
fill 75 245 313 75 246 313 minecraft:spruce_planks
fill 75 245 315 75 246 315 minecraft:spruce_planks
fill 76 245 308 76 246 308 minecraft:spruce_planks
fill 76 245 310 76 246 310 minecraft:spruce_planks
fill 76 245 312 76 246 312 minecraft:spruce_planks
fill 76 245 314 76 246 314 minecraft:spruce_planks
fill 76 245 316 76 246 316 minecraft:spruce_planks
fill 77 245 307 77 246 307 minecraft:spruce_planks
fill 77 245 309 77 246 309 minecraft:spruce_planks
fill 77 245 311 77 246 311 minecraft:spruce_planks
fill 77 245 313 77 246 313 minecraft:spruce_planks
fill 77 245 315 77 246 315 minecraft:spruce_planks
fill 78 245 308 78 246 308 minecraft:spruce_planks
fill 78 245 310 78 246 310 minecraft:spruce_planks
fill 78 245 312 78 246 312 minecraft:spruce_planks
fill 78 245 314 78 246 314 minecraft:spruce_planks
fill 78 245 316 78 246 316 minecraft:spruce_planks
fill 79 245 307 79 246 307 minecraft:spruce_planks
fill 79 245 309 79 246 309 minecraft:spruce_planks
fill 79 245 311 79 246 311 minecraft:spruce_planks
fill 79 245 313 79 246 313 minecraft:spruce_planks
fill 79 245 315 79 246 315 minecraft:spruce_planks
fill 80 245 276 80 246 276 minecraft:spruce_planks
fill 80 245 278 80 246 278 minecraft:spruce_planks
fill 80 245 280 80 246 280 minecraft:spruce_planks
fill 80 245 282 80 246 282 minecraft:spruce_planks
fill 80 245 308 80 246 308 minecraft:spruce_planks
fill 80 245 310 80 246 310 minecraft:spruce_planks
fill 80 245 312 80 246 312 minecraft:spruce_planks
fill 80 245 314 80 246 314 minecraft:spruce_planks
fill 80 245 316 80 246 316 minecraft:spruce_planks
fill 81 245 277 81 246 277 minecraft:spruce_planks
fill 81 245 279 81 246 279 minecraft:spruce_planks
fill 81 245 281 81 246 281 minecraft:spruce_planks
fill 81 245 283 81 246 283 minecraft:spruce_planks
fill 81 245 307 81 246 307 minecraft:spruce_planks
fill 81 245 309 81 246 309 minecraft:spruce_planks
fill 81 245 311 81 246 311 minecraft:spruce_planks
fill 81 245 313 81 246 313 minecraft:spruce_planks
fill 81 245 315 81 246 315 minecraft:spruce_planks
fill 82 245 276 82 246 276 minecraft:spruce_planks
fill 82 245 278 82 246 278 minecraft:spruce_planks
fill 82 245 280 82 246 280 minecraft:spruce_planks
fill 82 245 282 82 246 282 minecraft:spruce_planks
fill 82 245 308 82 246 308 minecraft:spruce_planks
fill 82 245 310 82 246 310 minecraft:spruce_planks
fill 82 245 312 82 246 312 minecraft:spruce_planks
fill 82 245 314 82 246 314 minecraft:spruce_planks
fill 82 245 316 82 246 316 minecraft:spruce_planks
fill 83 245 277 83 246 277 minecraft:spruce_planks
fill 83 245 279 83 246 279 minecraft:spruce_planks
fill 83 245 281 83 246 281 minecraft:spruce_planks
fill 83 245 283 83 246 283 minecraft:spruce_planks
fill 83 245 307 83 246 307 minecraft:spruce_planks
fill 83 245 309 83 246 309 minecraft:spruce_planks
fill 83 245 311 83 246 311 minecraft:spruce_planks
fill 83 245 313 83 246 313 minecraft:spruce_planks
fill 83 245 315 83 246 315 minecraft:spruce_planks
fill 84 245 276 84 246 276 minecraft:spruce_planks
fill 84 245 278 84 246 278 minecraft:spruce_planks
fill 84 245 280 84 246 280 minecraft:spruce_planks
fill 84 245 282 84 246 282 minecraft:spruce_planks
fill 84 245 308 84 246 308 minecraft:spruce_planks
fill 84 245 310 84 246 310 minecraft:spruce_planks
fill 84 245 312 84 246 312 minecraft:spruce_log
fill 84 245 314 84 246 314 minecraft:spruce_planks
fill 84 245 316 84 246 316 minecraft:spruce_planks
fill 85 245 277 85 246 277 minecraft:spruce_planks
fill 85 245 279 85 246 279 minecraft:spruce_planks
fill 85 245 281 85 246 281 minecraft:spruce_planks
fill 85 245 283 85 246 283 minecraft:spruce_planks
fill 85 245 307 85 246 307 minecraft:spruce_planks
fill 85 245 309 85 246 309 minecraft:spruce_planks
fill 85 245 311 85 246 311 minecraft:spruce_planks
fill 85 245 313 85 246 313 minecraft:spruce_planks
fill 85 245 315 85 246 315 minecraft:spruce_planks
fill 86 245 276 86 246 276 minecraft:spruce_planks
fill 86 245 278 86 246 278 minecraft:spruce_planks
fill 86 245 280 86 246 280 minecraft:spruce_planks
fill 86 245 282 86 246 282 minecraft:spruce_planks
fill 89 245 276 89 250 276 minecraft:cyan_concrete
fill 89 245 279 89 246 281 minecraft:cyan_concrete
setblock 89 245 282 minecraft:white_wool
setblock 89 245 284 minecraft:light_blue_wool
setblock 47 246 282 minecraft:cyan_concrete
fill 47 246 283 47 246 284 minecraft:light_blue_concrete
setblock 47 246 309 minecraft:light_blue_wool
setblock 48 246 275 minecraft:light_blue_concrete
setblock 48 246 282 minecraft:spruce_planks
setblock 48 246 289 minecraft:spruce_planks
setblock 48 246 296 minecraft:spruce_planks
setblock 48 246 310 minecraft:spruce_planks
setblock 48 246 317 minecraft:light_blue_concrete
setblock 49 246 276 minecraft:spruce_planks
setblock 49 246 316 minecraft:spruce_planks
fill 51 246 275 51 248 275 minecraft:light_blue_concrete
setblock 53 246 317 minecraft:light_blue_concrete
setblock 55 246 275 minecraft:light_blue_concrete
setblock 56 246 276 minecraft:spruce_planks
setblock 56 246 316 minecraft:spruce_planks
setblock 56 246 317 minecraft:light_blue_concrete
fill 59 246 313 59 247 315 minecraft:iron_bars
setblock 63 246 275 minecraft:light_blue_concrete
setblock 63 246 276 minecraft:spruce_planks
setblock 63 246 316 minecraft:spruce_planks
setblock 68 246 317 minecraft:light_blue_concrete
setblock 70 246 276 minecraft:spruce_planks
setblock 70 246 316 minecraft:spruce_planks
setblock 73 246 275 minecraft:light_blue_concrete
setblock 75 246 275 minecraft:light_blue_concrete
setblock 76 246 275 minecraft:cyan_concrete
setblock 76 246 317 minecraft:light_blue_concrete
setblock 77 246 276 minecraft:spruce_planks
setblock 85 246 275 minecraft:light_blue_concrete
setblock 85 246 317 minecraft:white_wool
setblock 86 246 275 minecraft:white_wool
setblock 88 246 279 minecraft:spruce_planks
setblock 88 246 286 minecraft:spruce_planks
setblock 88 246 293 minecraft:spruce_planks
setblock 88 246 300 minecraft:spruce_planks
setblock 88 246 307 minecraft:spruce_planks
setblock 88 246 314 minecraft:spruce_planks
fill 89 246 282 89 249 282 minecraft:cyan_concrete
setblock 89 246 283 minecraft:light_blue_concrete
setblock 89 246 284 minecraft:cyan_concrete
setblock 89 246 288 minecraft:light_blue_concrete
fill 89 246 291 89 246 293 minecraft:light_blue_concrete
setblock 89 246 298 minecraft:light_blue_concrete
setblock 89 246 300 minecraft:light_blue_concrete
setblock 89 246 313 minecraft:light_blue_concrete
setblock 47 247 276 minecraft:light_blue_concrete
setblock 47 247 282 minecraft:light_blue_concrete
fill 47 247 283 47 247 284 minecraft:cyan_concrete
setblock 47 247 288 minecraft:light_blue_concrete
setblock 47 247 292 minecraft:light_blue_concrete
setblock 47 247 306 minecraft:light_blue_concrete
fill 47 247 309 47 249 309 minecraft:cyan_concrete
fill 48 247 275 48 251 275 minecraft:cyan_concrete
setblock 48 247 276 minecraft:spruce_planks
setblock 48 247 283 minecraft:spruce_planks
setblock 48 247 290 minecraft:spruce_planks
setblock 48 247 297 minecraft:spruce_planks
fill 48 247 302 48 272 302 minecraft:spruce_planks
setblock 48 247 304 minecraft:spruce_planks
setblock 48 247 311 minecraft:spruce_planks
setblock 48 247 317 minecraft:cyan_concrete
setblock 50 247 316 minecraft:spruce_planks
setblock 50 247 317 minecraft:light_blue_concrete
fill 53 247 286 53 250 286 minecraft:iron_bars
fill 53 247 317 53 249 317 minecraft:cyan_concrete
fill 55 247 275 55 249 275 minecraft:cyan_concrete
setblock 55 247 276 minecraft:spruce_planks
fill 56 247 317 56 249 317 minecraft:cyan_concrete
setblock 57 247 316 minecraft:spruce_planks
setblock 62 247 276 minecraft:spruce_planks
fill 63 247 275 63 249 275 minecraft:cyan_concrete
setblock 64 247 316 minecraft:spruce_planks
setblock 65 247 317 minecraft:light_blue_concrete
fill 68 247 317 68 249 317 minecraft:cyan_concrete
setblock 69 247 276 minecraft:spruce_planks
setblock 71 247 316 minecraft:spruce_planks
fill 72 247 275 72 248 275 minecraft:light_blue_concrete
setblock 73 247 275 minecraft:light_blue_wool
fill 75 247 275 75 249 275 minecraft:cyan_concrete
setblock 75 247 307 minecraft:shroomlight
setblock 75 247 309 minecraft:shroomlight
setblock 75 247 311 minecraft:shroomlight
setblock 75 247 313 minecraft:shroomlight
setblock 75 247 315 minecraft:shroomlight
setblock 76 247 275 minecraft:white_wool
setblock 76 247 276 minecraft:spruce_planks
setblock 76 247 308 minecraft:shroomlight
setblock 76 247 310 minecraft:shroomlight
setblock 76 247 312 minecraft:shroomlight
setblock 76 247 314 minecraft:shroomlight
setblock 76 247 316 minecraft:shroomlight
fill 76 247 317 76 249 317 minecraft:cyan_concrete
setblock 77 247 307 minecraft:shroomlight
setblock 77 247 309 minecraft:shroomlight
setblock 77 247 311 minecraft:shroomlight
setblock 77 247 313 minecraft:shroomlight
setblock 77 247 315 minecraft:shroomlight
setblock 78 247 308 minecraft:shroomlight
setblock 78 247 310 minecraft:shroomlight
setblock 78 247 312 minecraft:shroomlight
setblock 78 247 314 minecraft:shroomlight
setblock 78 247 316 minecraft:shroomlight
setblock 79 247 275 minecraft:white_wool
setblock 79 247 307 minecraft:shroomlight
setblock 79 247 309 minecraft:shroomlight
setblock 79 247 311 minecraft:shroomlight
setblock 79 247 313 minecraft:shroomlight
setblock 79 247 315 minecraft:shroomlight
setblock 80 247 276 minecraft:shroomlight
setblock 80 247 278 minecraft:shroomlight
setblock 80 247 280 minecraft:shroomlight
setblock 80 247 282 minecraft:shroomlight
setblock 80 247 308 minecraft:shroomlight
setblock 80 247 310 minecraft:shroomlight
setblock 80 247 312 minecraft:shroomlight
setblock 80 247 314 minecraft:shroomlight
setblock 80 247 316 minecraft:shroomlight
setblock 81 247 277 minecraft:shroomlight
setblock 81 247 279 minecraft:shroomlight
setblock 81 247 281 minecraft:shroomlight
setblock 81 247 283 minecraft:shroomlight
setblock 81 247 307 minecraft:shroomlight
setblock 81 247 309 minecraft:shroomlight
setblock 81 247 311 minecraft:shroomlight
setblock 81 247 313 minecraft:shroomlight
setblock 81 247 315 minecraft:shroomlight
setblock 82 247 276 minecraft:shroomlight
setblock 82 247 278 minecraft:shroomlight
setblock 82 247 280 minecraft:shroomlight
setblock 82 247 282 minecraft:shroomlight
setblock 82 247 308 minecraft:shroomlight
setblock 82 247 310 minecraft:shroomlight
setblock 82 247 312 minecraft:shroomlight
setblock 82 247 314 minecraft:shroomlight
setblock 82 247 316 minecraft:shroomlight
setblock 83 247 277 minecraft:shroomlight
setblock 83 247 279 minecraft:shroomlight
setblock 83 247 281 minecraft:shroomlight
setblock 83 247 283 minecraft:shroomlight
setblock 83 247 307 minecraft:shroomlight
setblock 83 247 309 minecraft:shroomlight
setblock 83 247 311 minecraft:shroomlight
setblock 83 247 313 minecraft:shroomlight
setblock 83 247 315 minecraft:shroomlight
setblock 84 247 276 minecraft:shroomlight
setblock 84 247 278 minecraft:shroomlight
setblock 84 247 280 minecraft:shroomlight
setblock 84 247 282 minecraft:shroomlight
setblock 84 247 308 minecraft:shroomlight
setblock 84 247 310 minecraft:shroomlight
setblock 84 247 312 minecraft:shroomlight
setblock 84 247 314 minecraft:shroomlight
setblock 84 247 316 minecraft:shroomlight
fill 85 247 275 86 249 275 minecraft:cyan_concrete
setblock 85 247 277 minecraft:shroomlight
setblock 85 247 279 minecraft:shroomlight
setblock 85 247 281 minecraft:shroomlight
setblock 85 247 283 minecraft:shroomlight
setblock 85 247 307 minecraft:shroomlight
setblock 85 247 309 minecraft:shroomlight
setblock 85 247 311 minecraft:shroomlight
setblock 85 247 313 minecraft:shroomlight
setblock 85 247 315 minecraft:shroomlight
fill 85 247 317 85 249 317 minecraft:cyan_concrete
setblock 86 247 276 minecraft:shroomlight
setblock 86 247 278 minecraft:shroomlight
setblock 86 247 280 minecraft:shroomlight
setblock 86 247 282 minecraft:shroomlight
setblock 88 247 278 minecraft:spruce_planks
setblock 88 247 285 minecraft:spruce_planks
setblock 88 247 292 minecraft:spruce_planks
setblock 88 247 299 minecraft:spruce_planks
setblock 88 247 306 minecraft:spruce_planks
setblock 88 247 313 minecraft:spruce_planks
fill 89 247 275 89 248 275 minecraft:light_blue_concrete
fill 89 247 279 89 247 281 minecraft:light_blue_concrete
fill 89 247 283 89 249 283 minecraft:cyan_concrete
setblock 89 247 284 minecraft:white_wool
setblock 89 247 286 minecraft:light_blue_concrete
fill 89 247 288 89 249 288 minecraft:cyan_concrete
setblock 89 247 289 minecraft:light_blue_concrete
setblock 89 247 291 minecraft:light_blue_concrete
fill 89 247 292 89 247 293 minecraft:cyan_concrete
fill 89 247 298 89 249 298 minecraft:cyan_concrete
fill 89 247 300 89 249 303 minecraft:cyan_concrete
setblock 89 247 304 minecraft:light_blue_concrete
fill 89 247 313 89 248 313 minecraft:cyan_concrete
setblock 89 247 316 minecraft:light_blue_concrete
fill 47 248 276 47 249 276 minecraft:cyan_concrete
fill 47 248 282 47 249 282 minecraft:cyan_concrete
setblock 47 248 283 minecraft:light_blue_concrete
setblock 47 248 284 minecraft:light_blue_wool
setblock 47 248 287 minecraft:light_blue_concrete
fill 47 248 288 47 249 288 minecraft:cyan_concrete
fill 47 248 292 47 249 292 minecraft:cyan_concrete
setblock 47 248 299 minecraft:light_blue_concrete
fill 47 248 300 47 249 300 minecraft:cyan_concrete
fill 47 248 301 47 248 303 minecraft:light_blue_concrete
fill 47 248 306 47 250 306 minecraft:cyan_concrete
setblock 48 248 277 minecraft:spruce_planks
setblock 48 248 284 minecraft:spruce_planks
setblock 48 248 291 minecraft:spruce_planks
setblock 48 248 298 minecraft:spruce_planks
setblock 48 248 305 minecraft:spruce_planks
setblock 48 248 312 minecraft:spruce_planks
setblock 48 248 317 minecraft:light_blue_concrete
setblock 50 248 278 minecraft:light[level=12]
setblock 50 248 285 minecraft:light[level=12]
setblock 50 248 292 minecraft:light[level=12]
setblock 50 248 299 minecraft:light[level=12]
setblock 50 248 306 minecraft:light[level=12]
setblock 50 248 313 minecraft:light[level=12]
fill 50 248 317 50 249 317 minecraft:cyan_concrete
setblock 51 248 316 minecraft:spruce_planks
setblock 53 248 275 minecraft:light_blue_concrete
setblock 54 248 276 minecraft:spruce_planks
setblock 57 248 278 minecraft:light[level=12]
setblock 57 248 285 minecraft:light[level=12]
setblock 57 248 292 minecraft:light[level=12]
setblock 57 248 299 minecraft:light[level=12]
setblock 57 248 306 minecraft:light[level=12]
setblock 57 248 313 minecraft:light[level=12]
setblock 58 248 316 minecraft:spruce_planks
setblock 61 248 276 minecraft:spruce_planks
setblock 64 248 278 minecraft:light[level=12]
setblock 64 248 285 minecraft:light[level=12]
setblock 64 248 292 minecraft:light[level=12]
setblock 64 248 299 minecraft:light[level=12]
setblock 64 248 306 minecraft:light[level=12]
setblock 64 248 313 minecraft:light[level=12]
setblock 65 248 316 minecraft:spruce_planks
fill 65 248 317 65 249 317 minecraft:cyan_concrete
setblock 67 248 275 minecraft:white_wool
fill 68 248 275 71 249 275 minecraft:cyan_concrete
setblock 68 248 276 minecraft:spruce_planks
setblock 71 248 278 minecraft:light[level=12]
setblock 71 248 285 minecraft:light[level=12]
setblock 71 248 292 minecraft:light[level=12]
setblock 71 248 299 minecraft:light[level=12]
setblock 71 248 306 minecraft:light[level=12]
setblock 71 248 313 minecraft:light[level=12]
setblock 72 248 316 minecraft:spruce_planks
fill 73 248 275 73 249 275 minecraft:cyan_concrete
setblock 75 248 276 minecraft:spruce_planks
fill 75 248 307 75 249 307 minecraft:spruce_planks
fill 75 248 309 75 249 309 minecraft:spruce_planks
fill 75 248 311 75 249 311 minecraft:spruce_planks
fill 75 248 313 75 249 313 minecraft:spruce_planks
fill 75 248 315 75 249 315 minecraft:spruce_planks
fill 76 248 275 76 251 275 minecraft:cyan_concrete
fill 76 248 308 76 249 308 minecraft:spruce_planks
fill 76 248 310 76 249 310 minecraft:spruce_planks
fill 76 248 312 76 249 312 minecraft:spruce_planks
fill 76 248 314 76 249 314 minecraft:spruce_planks
fill 76 248 316 76 249 316 minecraft:spruce_planks
fill 77 248 275 78 248 275 minecraft:light_blue_concrete
fill 77 248 307 77 249 307 minecraft:spruce_planks
fill 77 248 309 77 249 309 minecraft:spruce_planks
fill 77 248 311 77 249 311 minecraft:spruce_planks
fill 77 248 313 77 249 313 minecraft:spruce_planks
fill 77 248 315 77 249 315 minecraft:spruce_planks
setblock 78 248 278 minecraft:light[level=12]
setblock 78 248 285 minecraft:light[level=12]
setblock 78 248 292 minecraft:light[level=12]
setblock 78 248 299 minecraft:light[level=12]
setblock 78 248 306 minecraft:light[level=12]
fill 78 248 308 78 249 308 minecraft:spruce_planks
fill 78 248 310 78 249 310 minecraft:spruce_planks
fill 78 248 312 78 249 312 minecraft:spruce_planks
fill 78 248 314 78 249 314 minecraft:spruce_planks
fill 78 248 316 78 249 316 minecraft:spruce_planks
fill 79 248 275 79 249 275 minecraft:cyan_concrete
fill 79 248 307 79 249 307 minecraft:spruce_planks
fill 79 248 309 79 249 309 minecraft:spruce_planks
fill 79 248 311 79 249 311 minecraft:spruce_planks
fill 79 248 313 79 249 313 minecraft:spruce_planks
fill 79 248 315 79 249 315 minecraft:spruce_planks
fill 80 248 276 80 249 276 minecraft:spruce_planks
fill 80 248 278 80 249 278 minecraft:spruce_planks
fill 80 248 280 80 249 280 minecraft:spruce_planks
fill 80 248 282 80 249 282 minecraft:spruce_planks
fill 80 248 308 80 249 308 minecraft:spruce_planks
fill 80 248 310 80 249 310 minecraft:spruce_planks
fill 80 248 312 80 249 312 minecraft:spruce_planks
fill 80 248 314 80 249 314 minecraft:spruce_planks
fill 80 248 316 80 249 316 minecraft:spruce_planks
fill 81 248 277 81 249 277 minecraft:spruce_planks
fill 81 248 279 81 249 279 minecraft:spruce_planks
fill 81 248 281 81 249 281 minecraft:spruce_planks
fill 81 248 283 81 249 283 minecraft:spruce_planks
fill 81 248 307 81 249 307 minecraft:spruce_planks
fill 81 248 309 81 249 309 minecraft:spruce_planks
fill 81 248 311 81 249 311 minecraft:spruce_planks
fill 81 248 313 81 249 313 minecraft:spruce_planks
fill 81 248 315 81 249 315 minecraft:spruce_planks
fill 82 248 276 82 249 276 minecraft:spruce_planks
fill 82 248 278 82 249 278 minecraft:spruce_planks
fill 82 248 280 82 249 280 minecraft:spruce_planks
fill 82 248 282 82 249 282 minecraft:spruce_planks
fill 82 248 308 82 249 308 minecraft:spruce_planks
fill 82 248 310 82 249 310 minecraft:spruce_planks
fill 82 248 312 82 249 312 minecraft:spruce_planks
fill 82 248 314 82 249 314 minecraft:spruce_planks
fill 82 248 316 82 249 316 minecraft:spruce_planks
fill 83 248 277 83 249 277 minecraft:spruce_planks
fill 83 248 279 83 249 279 minecraft:spruce_planks
fill 83 248 281 83 249 281 minecraft:spruce_planks
fill 83 248 283 83 249 283 minecraft:spruce_planks
fill 83 248 307 83 249 307 minecraft:spruce_planks
fill 83 248 309 83 249 309 minecraft:spruce_planks
fill 83 248 311 83 249 311 minecraft:spruce_planks
fill 83 248 313 83 249 313 minecraft:spruce_planks
fill 83 248 315 83 249 315 minecraft:spruce_planks
fill 84 248 276 84 249 276 minecraft:spruce_planks
fill 84 248 278 84 249 278 minecraft:spruce_planks
fill 84 248 280 84 249 280 minecraft:spruce_planks
fill 84 248 282 84 249 282 minecraft:spruce_planks
fill 84 248 308 84 249 308 minecraft:spruce_planks
fill 84 248 310 84 249 310 minecraft:spruce_planks
fill 84 248 312 84 249 312 minecraft:spruce_log
fill 84 248 314 84 249 314 minecraft:spruce_planks
fill 84 248 316 84 249 316 minecraft:spruce_planks
fill 85 248 277 85 249 277 minecraft:spruce_planks
fill 85 248 279 85 249 279 minecraft:spruce_planks
fill 85 248 281 85 249 281 minecraft:spruce_planks
fill 85 248 283 85 249 283 minecraft:spruce_planks
setblock 85 248 285 minecraft:light[level=12]
setblock 85 248 292 minecraft:light[level=12]
setblock 85 248 299 minecraft:light[level=12]
setblock 85 248 306 minecraft:light[level=12]
fill 85 248 307 85 249 307 minecraft:spruce_planks
fill 85 248 309 85 249 309 minecraft:spruce_planks
fill 85 248 311 85 249 311 minecraft:spruce_planks
fill 85 248 313 85 249 313 minecraft:spruce_planks
fill 85 248 315 85 249 315 minecraft:spruce_planks
fill 86 248 276 86 249 276 minecraft:spruce_planks
fill 86 248 278 86 249 278 minecraft:spruce_planks
fill 86 248 280 86 249 280 minecraft:spruce_planks
fill 86 248 282 86 249 282 minecraft:spruce_planks
setblock 86 248 316 minecraft:spruce_planks
setblock 88 248 277 minecraft:spruce_planks
setblock 88 248 284 minecraft:spruce_planks
setblock 88 248 291 minecraft:spruce_planks
setblock 88 248 298 minecraft:spruce_planks
setblock 88 248 305 minecraft:spruce_planks
setblock 88 248 312 minecraft:spruce_planks
fill 89 248 279 89 249 281 minecraft:cyan_concrete
fill 89 248 284 89 249 284 minecraft:cyan_concrete
fill 89 248 286 89 249 286 minecraft:cyan_concrete
setblock 89 248 287 minecraft:light_blue_concrete
fill 89 248 289 89 249 289 minecraft:cyan_concrete
fill 89 248 291 89 249 292 minecraft:cyan_concrete
setblock 89 248 293 minecraft:light_blue_concrete
fill 89 248 304 89 249 304 minecraft:cyan_concrete
fill 89 248 306 89 250 306 minecraft:cyan_concrete
setblock 89 248 307 minecraft:light_blue_concrete
setblock 89 248 309 minecraft:light_blue_concrete
fill 89 248 316 89 249 316 minecraft:cyan_concrete
setblock 89 248 317 minecraft:light_blue_concrete
fill 47 249 283 47 249 284 minecraft:cyan_concrete
setblock 47 249 287 minecraft:cyan_concrete
setblock 47 249 299 minecraft:cyan_concrete
fill 47 249 301 47 249 303 minecraft:cyan_concrete
fill 48 249 278 48 250 278 minecraft:spruce_planks
fill 48 249 285 48 250 285 minecraft:spruce_planks
fill 48 249 292 48 250 292 minecraft:spruce_planks
fill 48 249 299 48 250 299 minecraft:spruce_planks
fill 48 249 306 48 250 306 minecraft:spruce_planks
fill 48 249 313 48 250 313 minecraft:spruce_planks
setblock 48 249 317 minecraft:cyan_concrete
setblock 51 249 275 minecraft:cyan_concrete
fill 52 249 316 52 250 316 minecraft:spruce_planks
setblock 53 249 275 minecraft:cyan_concrete
fill 53 249 276 53 250 276 minecraft:spruce_planks
fill 59 249 316 59 250 316 minecraft:spruce_planks
fill 60 249 276 60 250 276 minecraft:spruce_planks
fill 66 249 316 66 250 316 minecraft:spruce_planks
setblock 67 249 275 minecraft:cyan_concrete
fill 67 249 276 67 250 276 minecraft:spruce_planks
fill 72 249 275 72 250 275 minecraft:cyan_concrete
fill 73 249 316 73 250 316 minecraft:spruce_planks
fill 74 249 276 74 250 276 minecraft:spruce_planks
fill 77 249 275 78 249 275 minecraft:cyan_concrete
fill 87 249 316 87 250 316 minecraft:spruce_planks
fill 88 249 276 88 250 276 minecraft:spruce_planks
fill 88 249 283 88 250 283 minecraft:spruce_planks
fill 88 249 290 88 250 290 minecraft:spruce_planks
fill 88 249 297 88 250 297 minecraft:spruce_planks
fill 88 249 304 88 250 304 minecraft:spruce_planks
fill 88 249 311 88 250 311 minecraft:spruce_planks
setblock 89 249 275 minecraft:cyan_concrete
setblock 89 249 287 minecraft:cyan_concrete
setblock 89 249 293 minecraft:cyan_concrete
setblock 89 249 307 minecraft:cyan_concrete
setblock 89 249 309 minecraft:cyan_concrete
setblock 89 249 313 minecraft:white_wool
fill 89 249 317 89 250 317 minecraft:cyan_concrete
fill 47 250 275 47 250 305 minecraft:light_blue_concrete
fill 47 250 307 47 251 312 minecraft:light_blue_concrete
fill 47 250 314 47 250 317 minecraft:light_blue_concrete
fill 48 250 276 48 250 277 minecraft:spruce_planks
fill 48 250 279 48 250 280 minecraft:spruce_planks
fill 48 250 282 48 250 284 minecraft:spruce_planks
fill 48 250 286 48 250 287 minecraft:spruce_planks
fill 48 250 289 48 250 291 minecraft:spruce_planks
fill 48 250 293 48 250 294 minecraft:spruce_planks
fill 48 250 296 48 250 298 minecraft:spruce_planks
fill 48 250 300 48 250 301 minecraft:spruce_planks
fill 48 250 303 48 250 305 minecraft:spruce_planks
fill 48 250 307 48 250 308 minecraft:spruce_planks
fill 48 250 310 48 250 312 minecraft:spruce_planks
fill 48 250 314 48 250 315 minecraft:spruce_planks
fill 48 250 317 56 256 317 minecraft:light_blue_concrete
fill 49 250 275 69 250 275 minecraft:light_blue_concrete
setblock 49 250 276 minecraft:spruce_planks
fill 49 250 316 51 250 316 minecraft:spruce_planks
setblock 50 250 278 minecraft:light[level=15]
setblock 50 250 286 minecraft:light[level=15]
setblock 50 250 294 minecraft:light[level=15]
setblock 50 250 302 minecraft:light[level=15]
setblock 50 250 310 minecraft:light[level=15]
fill 51 250 276 52 250 276 minecraft:spruce_planks
fill 53 250 316 54 250 316 minecraft:spruce_planks
fill 54 250 276 56 250 276 minecraft:spruce_planks
fill 56 250 316 58 250 316 minecraft:spruce_planks
fill 58 250 276 59 250 276 minecraft:spruce_planks
setblock 58 250 278 minecraft:light[level=15]
setblock 58 250 286 minecraft:light[level=15]
setblock 58 250 294 minecraft:light[level=15]
setblock 58 250 302 minecraft:light[level=15]
setblock 58 250 310 minecraft:light[level=15]
fill 58 250 317 77 250 317 minecraft:light_blue_concrete
fill 60 250 316 61 250 316 minecraft:spruce_planks
fill 61 250 276 63 250 276 minecraft:spruce_planks
fill 63 250 316 65 250 316 minecraft:spruce_planks
fill 65 250 276 66 250 276 minecraft:spruce_planks
setblock 66 250 278 minecraft:light[level=15]
setblock 66 250 286 minecraft:light[level=15]
setblock 66 250 294 minecraft:light[level=15]
setblock 66 250 302 minecraft:light[level=15]
setblock 66 250 310 minecraft:light[level=15]
fill 67 250 316 68 250 316 minecraft:spruce_planks
fill 68 250 276 70 250 276 minecraft:spruce_planks
setblock 70 250 275 minecraft:cyan_concrete
fill 70 250 316 72 250 316 minecraft:spruce_planks
fill 71 250 275 71 251 275 minecraft:light_blue_concrete
fill 72 250 276 73 250 276 minecraft:spruce_planks
fill 73 250 275 75 250 275 minecraft:light_blue_concrete
setblock 74 250 278 minecraft:light[level=15]
setblock 74 250 286 minecraft:light[level=15]
setblock 74 250 294 minecraft:light[level=15]
setblock 74 250 302 minecraft:light[level=15]
setblock 74 250 310 minecraft:light[level=15]
setblock 74 250 316 minecraft:spruce_planks
fill 75 250 276 77 250 276 minecraft:spruce_planks
setblock 75 250 307 minecraft:shroomlight
setblock 75 250 309 minecraft:shroomlight
setblock 75 250 311 minecraft:shroomlight
setblock 75 250 313 minecraft:shroomlight
setblock 75 250 315 minecraft:shroomlight
setblock 76 250 308 minecraft:shroomlight
setblock 76 250 310 minecraft:shroomlight
setblock 76 250 312 minecraft:shroomlight
setblock 76 250 314 minecraft:shroomlight
setblock 76 250 316 minecraft:shroomlight
fill 77 250 275 79 263 275 minecraft:light_blue_concrete
setblock 77 250 307 minecraft:shroomlight
setblock 77 250 309 minecraft:shroomlight
setblock 77 250 311 minecraft:shroomlight
setblock 77 250 313 minecraft:shroomlight
setblock 77 250 315 minecraft:shroomlight
setblock 78 250 308 minecraft:shroomlight
setblock 78 250 310 minecraft:shroomlight
setblock 78 250 312 minecraft:shroomlight
setblock 78 250 314 minecraft:shroomlight
setblock 78 250 316 minecraft:shroomlight
fill 79 250 276 79 251 276 minecraft:spruce_planks
setblock 79 250 307 minecraft:shroomlight
setblock 79 250 309 minecraft:shroomlight
setblock 79 250 311 minecraft:shroomlight
setblock 79 250 313 minecraft:shroomlight
setblock 79 250 315 minecraft:shroomlight
fill 79 250 317 88 251 317 minecraft:light_blue_concrete
setblock 80 250 275 minecraft:cyan_concrete
setblock 80 250 276 minecraft:shroomlight
setblock 80 250 278 minecraft:shroomlight
setblock 80 250 280 minecraft:shroomlight
setblock 80 250 282 minecraft:shroomlight
setblock 80 250 308 minecraft:shroomlight
setblock 80 250 310 minecraft:shroomlight
setblock 80 250 312 minecraft:shroomlight
setblock 80 250 314 minecraft:shroomlight
setblock 80 250 316 minecraft:shroomlight
fill 81 250 275 89 250 275 minecraft:light_blue_concrete
setblock 81 250 277 minecraft:shroomlight
setblock 81 250 279 minecraft:shroomlight
setblock 81 250 281 minecraft:shroomlight
setblock 81 250 283 minecraft:shroomlight
setblock 81 250 307 minecraft:shroomlight
setblock 81 250 309 minecraft:shroomlight
setblock 81 250 311 minecraft:shroomlight
setblock 81 250 313 minecraft:shroomlight
setblock 81 250 315 minecraft:shroomlight
setblock 82 250 276 minecraft:shroomlight
setblock 82 250 278 minecraft:shroomlight
setblock 82 250 280 minecraft:shroomlight
setblock 82 250 282 minecraft:shroomlight
setblock 82 250 286 minecraft:light[level=15]
setblock 82 250 294 minecraft:light[level=15]
setblock 82 250 302 minecraft:light[level=15]
setblock 82 250 308 minecraft:shroomlight
setblock 82 250 310 minecraft:shroomlight
setblock 82 250 312 minecraft:shroomlight
setblock 82 250 314 minecraft:shroomlight
setblock 82 250 316 minecraft:shroomlight
setblock 83 250 277 minecraft:shroomlight
setblock 83 250 279 minecraft:shroomlight
setblock 83 250 281 minecraft:shroomlight
setblock 83 250 283 minecraft:shroomlight
setblock 83 250 307 minecraft:shroomlight
setblock 83 250 309 minecraft:shroomlight
setblock 83 250 311 minecraft:shroomlight
setblock 83 250 313 minecraft:shroomlight
setblock 83 250 315 minecraft:shroomlight
setblock 84 250 276 minecraft:shroomlight
setblock 84 250 278 minecraft:shroomlight
setblock 84 250 280 minecraft:shroomlight
setblock 84 250 282 minecraft:shroomlight
setblock 84 250 308 minecraft:shroomlight
setblock 84 250 310 minecraft:shroomlight
setblock 84 250 312 minecraft:shroomlight
setblock 84 250 314 minecraft:shroomlight
setblock 84 250 316 minecraft:shroomlight
setblock 85 250 277 minecraft:shroomlight
setblock 85 250 279 minecraft:shroomlight
setblock 85 250 281 minecraft:shroomlight
setblock 85 250 283 minecraft:shroomlight
setblock 85 250 307 minecraft:shroomlight
setblock 85 250 309 minecraft:shroomlight
setblock 85 250 311 minecraft:shroomlight
setblock 85 250 313 minecraft:shroomlight
setblock 85 250 315 minecraft:shroomlight
setblock 86 250 276 minecraft:shroomlight
setblock 86 250 278 minecraft:shroomlight
setblock 86 250 280 minecraft:shroomlight
setblock 86 250 282 minecraft:shroomlight
setblock 86 250 316 minecraft:spruce_planks
setblock 87 250 276 minecraft:spruce_planks
fill 88 250 277 88 250 279 minecraft:spruce_planks
fill 88 250 281 88 250 282 minecraft:spruce_planks
fill 88 250 284 88 250 286 minecraft:spruce_planks
fill 88 250 288 88 250 289 minecraft:spruce_planks
fill 88 250 291 88 250 293 minecraft:spruce_planks
fill 88 250 295 88 250 296 minecraft:spruce_planks
fill 88 250 298 88 250 300 minecraft:spruce_planks
fill 88 250 302 88 250 303 minecraft:spruce_planks
fill 88 250 305 88 250 307 minecraft:spruce_planks
fill 88 250 309 88 250 310 minecraft:spruce_planks
fill 88 250 312 88 250 314 minecraft:spruce_planks
setblock 88 250 316 minecraft:spruce_planks
fill 89 250 277 89 250 281 minecraft:light_blue_concrete
setblock 89 250 282 minecraft:white_wool
fill 89 250 283 89 250 289 minecraft:light_blue_concrete
fill 89 250 291 89 308 291 minecraft:light_blue_concrete
fill 89 250 292 89 251 292 minecraft:cyan_concrete
fill 89 250 293 89 250 297 minecraft:light_blue_concrete
setblock 89 250 298 minecraft:white_wool
setblock 89 250 299 minecraft:light_blue_wool
fill 89 250 300 89 308 301 minecraft:light_blue_concrete
setblock 89 250 302 minecraft:cyan_concrete
fill 89 250 303 89 250 305 minecraft:light_blue_concrete
fill 89 250 307 89 251 311 minecraft:light_blue_concrete
fill 89 250 313 89 308 316 minecraft:light_blue_concrete
fill 47 251 275 47 251 278 minecraft:light_blue_concrete
setblock 47 251 279 minecraft:cyan_concrete
fill 47 251 280 47 252 287 minecraft:light_blue_concrete
setblock 47 251 288 minecraft:cyan_concrete
fill 47 251 289 47 265 290 minecraft:light_blue_concrete
setblock 47 251 291 minecraft:cyan_concrete
fill 47 251 292 47 251 299 minecraft:light_blue_concrete
setblock 47 251 300 minecraft:cyan_concrete
fill 47 251 301 47 308 304 minecraft:light_blue_concrete
setblock 47 251 305 minecraft:cyan_concrete
fill 47 251 306 47 274 306 minecraft:light_blue_concrete
fill 47 251 313 47 267 314 minecraft:light_blue_concrete
setblock 47 251 315 minecraft:cyan_concrete
fill 47 251 316 47 251 317 minecraft:light_blue_concrete
setblock 48 251 280 minecraft:spruce_planks
fill 48 251 283 53 251 286 minecraft:dark_oak_planks
fill 48 251 287 48 252 287 minecraft:spruce_planks
fill 48 251 289 53 251 289 minecraft:dark_oak_planks
setblock 48 251 294 minecraft:spruce_planks
setblock 48 251 301 minecraft:spruce_planks
setblock 48 251 308 minecraft:spruce_planks
setblock 48 251 315 minecraft:spruce_planks
fill 49 251 275 51 262 275 minecraft:light_blue_concrete
fill 49 251 287 53 251 288 minecraft:dark_oak_planks
setblock 51 251 276 minecraft:spruce_planks
setblock 52 251 275 minecraft:cyan_concrete
fill 53 251 275 70 251 275 minecraft:light_blue_concrete
setblock 54 251 316 minecraft:spruce_planks
fill 57 251 317 60 251 317 minecraft:light_blue_concrete
setblock 58 251 276 minecraft:spruce_planks
setblock 61 251 316 minecraft:spruce_planks
setblock 61 251 317 minecraft:cyan_concrete
fill 62 251 317 62 308 317 minecraft:light_blue_concrete
setblock 63 251 317 minecraft:white_wool
fill 64 251 317 78 251 317 minecraft:light_blue_concrete
setblock 65 251 276 minecraft:spruce_planks
setblock 68 251 316 minecraft:spruce_planks
fill 72 251 275 73 251 275 minecraft:light_blue_concrete
setblock 72 251 276 minecraft:spruce_planks
setblock 74 251 275 minecraft:cyan_concrete
setblock 75 251 275 minecraft:light_blue_concrete
fill 75 251 307 75 252 307 minecraft:spruce_planks
fill 75 251 309 75 252 309 minecraft:spruce_planks
fill 75 251 311 75 252 311 minecraft:spruce_planks
fill 75 251 313 75 252 313 minecraft:spruce_planks
fill 75 251 315 75 252 315 minecraft:spruce_planks
fill 76 251 308 76 252 308 minecraft:spruce_planks
fill 76 251 310 76 252 310 minecraft:spruce_planks
fill 76 251 312 76 252 312 minecraft:spruce_planks
fill 76 251 314 76 252 314 minecraft:spruce_planks
fill 76 251 316 76 252 316 minecraft:spruce_planks
fill 77 251 307 77 252 307 minecraft:spruce_planks
fill 77 251 309 77 252 309 minecraft:spruce_planks
fill 77 251 311 77 252 311 minecraft:spruce_planks
fill 77 251 313 77 252 313 minecraft:spruce_planks
fill 77 251 315 77 252 315 minecraft:spruce_planks
fill 78 251 308 78 252 308 minecraft:spruce_planks
fill 78 251 310 78 252 310 minecraft:spruce_planks
fill 78 251 312 78 252 312 minecraft:spruce_planks
fill 78 251 314 78 252 314 minecraft:spruce_planks
fill 78 251 316 78 252 316 minecraft:spruce_planks
fill 79 251 307 79 252 307 minecraft:spruce_planks
fill 79 251 309 79 252 309 minecraft:spruce_planks
fill 79 251 311 79 252 311 minecraft:spruce_planks
fill 79 251 313 79 252 313 minecraft:spruce_planks
fill 79 251 315 79 252 315 minecraft:spruce_planks
fill 80 251 275 84 251 275 minecraft:light_blue_concrete
fill 80 251 276 80 253 276 minecraft:spruce_planks
fill 80 251 278 80 253 278 minecraft:spruce_planks
fill 80 251 280 80 253 280 minecraft:spruce_planks
fill 80 251 282 80 253 282 minecraft:spruce_planks
fill 80 251 308 80 252 308 minecraft:spruce_planks
fill 80 251 310 80 252 310 minecraft:spruce_planks
fill 80 251 312 80 252 312 minecraft:spruce_planks
fill 80 251 314 80 252 314 minecraft:spruce_planks
fill 80 251 316 80 252 316 minecraft:spruce_planks
fill 81 251 277 81 253 277 minecraft:spruce_planks
fill 81 251 279 81 253 279 minecraft:spruce_planks
fill 81 251 281 81 253 281 minecraft:spruce_planks
fill 81 251 283 81 253 283 minecraft:spruce_planks
fill 81 251 307 81 252 307 minecraft:spruce_planks
fill 81 251 309 81 252 309 minecraft:spruce_planks
fill 81 251 311 81 252 311 minecraft:spruce_planks
fill 81 251 313 81 252 313 minecraft:spruce_planks
fill 81 251 315 81 252 315 minecraft:spruce_planks
fill 82 251 276 82 253 276 minecraft:spruce_planks
fill 82 251 278 82 253 278 minecraft:spruce_planks
fill 82 251 280 82 253 280 minecraft:spruce_planks
fill 82 251 282 82 253 282 minecraft:spruce_planks
fill 82 251 308 82 252 308 minecraft:spruce_planks
fill 82 251 310 82 252 310 minecraft:spruce_planks
fill 82 251 312 82 252 312 minecraft:spruce_planks
fill 82 251 314 82 252 314 minecraft:spruce_planks
fill 82 251 316 82 252 316 minecraft:spruce_planks
fill 83 251 277 83 253 277 minecraft:spruce_planks
fill 83 251 279 83 253 279 minecraft:spruce_planks
fill 83 251 281 83 253 281 minecraft:spruce_planks
fill 83 251 283 83 253 283 minecraft:spruce_planks
fill 83 251 307 83 252 307 minecraft:spruce_planks
fill 83 251 309 83 252 309 minecraft:spruce_planks
fill 83 251 311 83 252 311 minecraft:spruce_planks
fill 83 251 313 83 252 313 minecraft:spruce_planks
fill 83 251 315 83 252 315 minecraft:spruce_planks
fill 84 251 276 84 253 276 minecraft:spruce_planks
fill 84 251 278 84 253 278 minecraft:spruce_planks
fill 84 251 280 84 253 280 minecraft:spruce_planks
fill 84 251 282 84 253 282 minecraft:spruce_planks
fill 84 251 308 84 252 308 minecraft:spruce_planks
fill 84 251 310 84 252 310 minecraft:spruce_planks
fill 84 251 312 84 252 312 minecraft:spruce_log
fill 84 251 314 84 252 314 minecraft:spruce_planks
fill 84 251 316 84 252 316 minecraft:spruce_planks
setblock 85 251 275 minecraft:cyan_concrete
fill 85 251 277 85 253 277 minecraft:spruce_planks
fill 85 251 279 85 253 279 minecraft:spruce_planks
fill 85 251 281 85 253 281 minecraft:spruce_planks
fill 85 251 283 85 253 283 minecraft:spruce_planks
fill 85 251 307 85 252 307 minecraft:spruce_planks
fill 85 251 309 85 252 309 minecraft:spruce_planks
fill 85 251 311 85 252 311 minecraft:spruce_planks
fill 85 251 313 85 252 313 minecraft:spruce_planks
fill 85 251 315 85 252 315 minecraft:spruce_planks
fill 86 251 275 89 308 275 minecraft:light_blue_concrete
fill 86 251 276 86 253 276 minecraft:spruce_planks
fill 86 251 278 86 253 278 minecraft:spruce_planks
fill 86 251 280 86 253 280 minecraft:spruce_planks
fill 86 251 282 86 253 282 minecraft:spruce_planks
setblock 88 251 281 minecraft:spruce_planks
setblock 88 251 288 minecraft:spruce_planks
setblock 88 251 295 minecraft:spruce_planks
setblock 88 251 302 minecraft:spruce_planks
setblock 88 251 309 minecraft:spruce_planks
fill 89 251 276 89 308 276 minecraft:light_blue_concrete
setblock 89 251 277 minecraft:light_blue_wool
setblock 89 251 278 minecraft:cyan_concrete
setblock 89 251 279 minecraft:light_blue_wool
setblock 89 251 280 minecraft:cyan_concrete
fill 89 251 281 89 253 284 minecraft:light_blue_concrete
setblock 89 251 285 minecraft:cyan_concrete
fill 89 251 286 89 251 290 minecraft:light_blue_concrete
fill 89 251 293 89 308 294 minecraft:light_blue_concrete
setblock 89 251 295 minecraft:cyan_concrete
fill 89 251 296 89 254 299 minecraft:light_blue_concrete
setblock 89 251 302 minecraft:light_blue_concrete
fill 89 251 303 89 252 303 minecraft:cyan_concrete
fill 89 251 304 89 262 306 minecraft:light_blue_concrete
fill 89 251 312 89 308 312 minecraft:light_blue_concrete
fill 89 251 317 89 308 317 minecraft:light_blue_concrete
fill 47 252 275 48 308 275 minecraft:light_blue_concrete
setblock 47 252 276 minecraft:cyan_concrete
fill 47 252 277 47 273 279 minecraft:light_blue_concrete
fill 47 252 288 47 265 288 minecraft:light_blue_concrete
fill 47 252 291 47 259 292 minecraft:light_blue_concrete
setblock 47 252 293 minecraft:cyan_concrete
fill 47 252 294 47 308 294 minecraft:light_blue_concrete
setblock 47 252 295 minecraft:cyan_concrete
fill 47 252 296 47 308 296 minecraft:light_blue_concrete
setblock 47 252 297 minecraft:cyan_concrete
fill 47 252 298 47 308 300 minecraft:light_blue_concrete
fill 47 252 305 47 308 305 minecraft:light_blue_concrete
fill 47 252 307 47 268 309 minecraft:light_blue_concrete
setblock 47 252 310 minecraft:cyan_concrete
fill 47 252 311 47 307 312 minecraft:light_blue_concrete
fill 47 252 315 47 308 315 minecraft:light_blue_concrete
setblock 47 252 316 minecraft:cyan_concrete
fill 47 252 317 47 308 317 minecraft:light_blue_concrete
fill 48 252 283 53 252 286 minecraft:spruce_planks
fill 48 252 289 53 252 289 minecraft:spruce_planks
fill 49 252 287 53 252 288 minecraft:spruce_planks
fill 52 252 275 56 262 275 minecraft:light_blue_concrete
setblock 57 252 275 minecraft:cyan_concrete
fill 57 252 317 59 279 317 minecraft:light_blue_concrete
fill 58 252 275 70 272 275 minecraft:light_blue_concrete
setblock 60 252 317 minecraft:cyan_concrete
fill 61 252 317 61 290 317 minecraft:light_blue_concrete
fill 63 252 317 68 272 317 minecraft:light_blue_concrete
setblock 69 252 317 minecraft:cyan_concrete
fill 70 252 317 80 253 317 minecraft:light_blue_concrete
setblock 71 252 275 minecraft:cyan_concrete
fill 72 252 275 72 256 275 minecraft:light_blue_concrete
setblock 73 252 275 minecraft:cyan_concrete
fill 74 252 275 74 256 275 minecraft:light_blue_concrete
setblock 75 252 275 minecraft:cyan_concrete
fill 76 252 275 76 308 275 minecraft:light_blue_concrete
fill 80 252 275 80 308 275 minecraft:light_blue_concrete
setblock 81 252 275 minecraft:cyan_concrete
setblock 81 252 317 minecraft:cyan_concrete
fill 82 252 275 85 283 275 minecraft:light_blue_concrete
fill 82 252 317 88 252 317 minecraft:light_blue_concrete
fill 89 252 277 89 275 280 minecraft:light_blue_concrete
fill 89 252 285 89 308 285 minecraft:light_blue_concrete
fill 89 252 286 89 252 289 minecraft:cyan_concrete
fill 89 252 290 89 273 290 minecraft:light_blue_concrete
fill 89 252 292 89 290 292 minecraft:light_blue_concrete
fill 89 252 295 89 308 295 minecraft:light_blue_concrete
setblock 89 252 302 minecraft:cyan_concrete
setblock 89 252 307 minecraft:cyan_concrete
fill 89 252 308 89 301 311 minecraft:light_blue_concrete
fill 47 253 276 47 288 276 minecraft:light_blue_concrete
setblock 47 253 280 minecraft:white_wool
fill 47 253 281 47 261 284 minecraft:light_blue_concrete
fill 47 253 285 47 256 287 minecraft:shroomlight
fill 47 253 293 47 308 293 minecraft:light_blue_concrete
fill 47 253 295 47 308 295 minecraft:light_blue_concrete
fill 47 253 297 47 308 297 minecraft:light_blue_concrete
fill 47 253 310 47 308 310 minecraft:light_blue_concrete
fill 47 253 316 47 305 316 minecraft:light_blue_concrete
setblock 48 253 282 minecraft:spruce_planks
setblock 48 253 289 minecraft:spruce_planks
setblock 48 253 296 minecraft:spruce_planks
setblock 48 253 303 minecraft:spruce_planks
setblock 48 253 310 minecraft:spruce_planks
setblock 49 253 276 minecraft:spruce_planks
setblock 49 253 316 minecraft:spruce_planks
fill 53 253 283 53 253 289 minecraft:dark_oak_planks
setblock 56 253 276 minecraft:spruce_planks
setblock 56 253 316 minecraft:spruce_planks
fill 57 253 275 57 308 275 minecraft:light_blue_concrete
fill 60 253 317 60 259 317 minecraft:light_blue_concrete
setblock 63 253 276 minecraft:spruce_planks
setblock 63 253 316 minecraft:spruce_planks
fill 69 253 317 69 308 317 minecraft:light_blue_concrete
setblock 70 253 276 minecraft:spruce_planks
setblock 70 253 316 minecraft:spruce_planks
fill 71 253 275 71 308 275 minecraft:light_blue_concrete
fill 73 253 275 73 308 275 minecraft:light_blue_concrete
fill 75 253 275 75 281 275 minecraft:light_blue_concrete
setblock 75 253 307 minecraft:shroomlight
setblock 75 253 309 minecraft:shroomlight
setblock 75 253 311 minecraft:shroomlight
setblock 75 253 313 minecraft:shroomlight
setblock 75 253 315 minecraft:shroomlight
setblock 76 253 308 minecraft:shroomlight
setblock 76 253 310 minecraft:shroomlight
setblock 76 253 312 minecraft:shroomlight
setblock 76 253 314 minecraft:shroomlight
setblock 76 253 316 minecraft:shroomlight
setblock 77 253 276 minecraft:spruce_planks
setblock 77 253 307 minecraft:shroomlight
setblock 77 253 309 minecraft:shroomlight
setblock 77 253 311 minecraft:shroomlight
setblock 77 253 313 minecraft:shroomlight
setblock 77 253 315 minecraft:shroomlight
setblock 78 253 308 minecraft:shroomlight
setblock 78 253 310 minecraft:shroomlight
setblock 78 253 312 minecraft:shroomlight
setblock 78 253 314 minecraft:shroomlight
setblock 78 253 316 minecraft:shroomlight
setblock 79 253 307 minecraft:shroomlight
setblock 79 253 309 minecraft:shroomlight
setblock 79 253 311 minecraft:shroomlight
setblock 79 253 313 minecraft:shroomlight
setblock 79 253 315 minecraft:shroomlight
setblock 80 253 308 minecraft:shroomlight
setblock 80 253 310 minecraft:shroomlight
setblock 80 253 312 minecraft:shroomlight
setblock 80 253 314 minecraft:shroomlight
setblock 80 253 316 minecraft:shroomlight
fill 81 253 275 81 290 275 minecraft:light_blue_concrete
setblock 81 253 307 minecraft:shroomlight
setblock 81 253 309 minecraft:shroomlight
setblock 81 253 311 minecraft:shroomlight
setblock 81 253 313 minecraft:shroomlight
setblock 81 253 315 minecraft:shroomlight
fill 81 253 317 86 255 317 minecraft:light_blue_concrete
setblock 82 253 308 minecraft:shroomlight
setblock 82 253 310 minecraft:shroomlight
setblock 82 253 312 minecraft:shroomlight
setblock 82 253 314 minecraft:shroomlight
setblock 82 253 316 minecraft:shroomlight
setblock 83 253 307 minecraft:shroomlight
setblock 83 253 309 minecraft:shroomlight
setblock 83 253 311 minecraft:shroomlight
setblock 83 253 313 minecraft:shroomlight
setblock 83 253 315 minecraft:shroomlight
setblock 84 253 308 minecraft:shroomlight
setblock 84 253 310 minecraft:shroomlight
setblock 84 253 312 minecraft:shroomlight
setblock 84 253 314 minecraft:shroomlight
setblock 84 253 316 minecraft:shroomlight
setblock 85 253 307 minecraft:shroomlight
setblock 85 253 309 minecraft:shroomlight
setblock 85 253 311 minecraft:shroomlight
setblock 85 253 313 minecraft:shroomlight
setblock 85 253 315 minecraft:shroomlight
setblock 87 253 317 minecraft:white_wool
setblock 88 253 279 minecraft:spruce_planks
setblock 88 253 286 minecraft:spruce_planks
setblock 88 253 293 minecraft:spruce_planks
setblock 88 253 300 minecraft:spruce_planks
setblock 88 253 307 minecraft:spruce_planks
setblock 88 253 314 minecraft:spruce_planks
fill 88 253 317 88 256 317 minecraft:light_blue_concrete
fill 89 253 286 89 275 289 minecraft:light_blue_concrete
fill 89 253 302 89 281 303 minecraft:light_blue_concrete
fill 89 253 307 89 304 307 minecraft:light_blue_concrete
fill 47 254 280 47 271 280 minecraft:light_blue_concrete
setblock 48 254 276 minecraft:spruce_planks
setblock 48 254 283 minecraft:spruce_planks
setblock 48 254 290 minecraft:spruce_planks
setblock 48 254 297 minecraft:spruce_planks
setblock 48 254 304 minecraft:spruce_planks
setblock 48 254 311 minecraft:spruce_planks
setblock 50 254 278 minecraft:light[level=12]
setblock 50 254 285 minecraft:light[level=12]
setblock 50 254 292 minecraft:light[level=12]
setblock 50 254 299 minecraft:light[level=12]
setblock 50 254 306 minecraft:light[level=12]
setblock 50 254 313 minecraft:light[level=12]
setblock 50 254 316 minecraft:spruce_planks
setblock 53 254 283 minecraft:spruce_planks
setblock 53 254 286 minecraft:spruce_planks
setblock 53 254 289 minecraft:spruce_planks
setblock 55 254 276 minecraft:spruce_planks
setblock 57 254 278 minecraft:light[level=12]
setblock 57 254 285 minecraft:light[level=12]
setblock 57 254 292 minecraft:light[level=12]
setblock 57 254 299 minecraft:light[level=12]
setblock 57 254 306 minecraft:light[level=12]
setblock 57 254 313 minecraft:light[level=12]
setblock 57 254 316 minecraft:spruce_planks
setblock 62 254 276 minecraft:spruce_planks
setblock 64 254 278 minecraft:light[level=12]
setblock 64 254 285 minecraft:light[level=12]
setblock 64 254 292 minecraft:light[level=12]
setblock 64 254 299 minecraft:light[level=12]
setblock 64 254 306 minecraft:light[level=12]
setblock 64 254 313 minecraft:light[level=12]
setblock 64 254 316 minecraft:spruce_planks
setblock 69 254 276 minecraft:spruce_planks
setblock 70 254 317 minecraft:white_wool
setblock 71 254 278 minecraft:light[level=12]
setblock 71 254 285 minecraft:light[level=12]
setblock 71 254 292 minecraft:light[level=12]
setblock 71 254 299 minecraft:light[level=12]
setblock 71 254 306 minecraft:light[level=12]
setblock 71 254 313 minecraft:light[level=12]
setblock 71 254 316 minecraft:spruce_planks
fill 71 254 317 80 257 317 minecraft:light_blue_concrete
fill 75 254 307 75 255 307 minecraft:spruce_planks
fill 75 254 309 75 255 309 minecraft:spruce_planks
fill 75 254 311 75 255 311 minecraft:spruce_planks
fill 75 254 313 75 255 313 minecraft:spruce_planks
fill 75 254 315 75 255 315 minecraft:spruce_planks
setblock 76 254 276 minecraft:spruce_planks
fill 76 254 308 76 255 308 minecraft:spruce_planks
fill 76 254 310 76 255 310 minecraft:spruce_planks
fill 76 254 312 76 255 312 minecraft:spruce_planks
fill 76 254 314 76 255 314 minecraft:spruce_planks
fill 76 254 316 76 272 316 minecraft:spruce_planks
fill 77 254 307 77 255 307 minecraft:spruce_planks
fill 77 254 309 77 255 309 minecraft:spruce_planks
fill 77 254 311 77 255 311 minecraft:spruce_planks
fill 77 254 313 77 255 313 minecraft:spruce_planks
fill 77 254 315 77 255 315 minecraft:spruce_planks
setblock 78 254 278 minecraft:light[level=12]
setblock 78 254 285 minecraft:light[level=12]
setblock 78 254 292 minecraft:light[level=12]
setblock 78 254 299 minecraft:light[level=12]
setblock 78 254 306 minecraft:light[level=12]
fill 78 254 308 78 255 308 minecraft:spruce_planks
fill 78 254 310 78 255 310 minecraft:spruce_planks
fill 78 254 312 78 255 312 minecraft:spruce_planks
fill 78 254 314 78 255 314 minecraft:spruce_planks
fill 78 254 316 78 255 316 minecraft:spruce_planks
fill 79 254 307 79 255 307 minecraft:spruce_planks
fill 79 254 309 79 255 309 minecraft:spruce_planks
fill 79 254 311 79 255 311 minecraft:spruce_planks
fill 79 254 313 79 255 313 minecraft:spruce_planks
fill 79 254 315 79 255 315 minecraft:spruce_planks
fill 80 254 308 80 255 308 minecraft:spruce_planks
fill 80 254 310 80 255 310 minecraft:spruce_planks
fill 80 254 312 80 255 312 minecraft:spruce_planks
fill 80 254 314 80 255 314 minecraft:spruce_planks
fill 80 254 316 80 256 316 minecraft:spruce_planks
fill 81 254 307 81 255 307 minecraft:spruce_planks
fill 81 254 309 81 255 309 minecraft:spruce_planks
fill 81 254 311 81 255 311 minecraft:spruce_planks
fill 81 254 313 81 255 313 minecraft:spruce_planks
fill 81 254 315 81 255 315 minecraft:spruce_planks
fill 82 254 308 82 255 308 minecraft:spruce_planks
fill 82 254 310 82 255 310 minecraft:spruce_planks
fill 82 254 312 82 255 312 minecraft:spruce_planks
fill 82 254 314 82 255 314 minecraft:spruce_planks
fill 82 254 316 82 255 316 minecraft:spruce_planks
fill 83 254 307 83 255 307 minecraft:spruce_planks
fill 83 254 309 83 255 309 minecraft:spruce_planks
fill 83 254 311 83 255 311 minecraft:spruce_planks
fill 83 254 313 83 255 313 minecraft:spruce_planks
fill 83 254 315 83 255 315 minecraft:spruce_planks
fill 84 254 308 84 255 308 minecraft:spruce_planks
fill 84 254 310 84 255 310 minecraft:spruce_planks
fill 84 254 312 84 255 312 minecraft:spruce_log
fill 84 254 314 84 255 314 minecraft:spruce_planks
fill 84 254 316 84 255 316 minecraft:spruce_planks
setblock 85 254 278 minecraft:light[level=12]
setblock 85 254 285 minecraft:light[level=12]
setblock 85 254 292 minecraft:light[level=12]
setblock 85 254 299 minecraft:light[level=12]
setblock 85 254 306 minecraft:light[level=12]
fill 85 254 307 85 255 307 minecraft:spruce_planks
fill 85 254 309 85 255 309 minecraft:spruce_planks
fill 85 254 311 85 255 311 minecraft:spruce_planks
fill 85 254 313 85 255 313 minecraft:spruce_planks
fill 85 254 315 85 255 315 minecraft:spruce_planks
fill 87 254 317 87 308 317 minecraft:light_blue_concrete
setblock 88 254 278 minecraft:spruce_planks
setblock 88 254 285 minecraft:spruce_planks
setblock 88 254 292 minecraft:spruce_planks
setblock 88 254 299 minecraft:spruce_planks
setblock 88 254 306 minecraft:spruce_planks
setblock 88 254 313 minecraft:spruce_planks
fill 89 254 281 89 284 283 minecraft:light_blue_concrete
setblock 89 254 284 minecraft:white_wool
setblock 48 255 277 minecraft:spruce_planks
setblock 48 255 284 minecraft:spruce_planks
setblock 48 255 291 minecraft:spruce_planks
setblock 48 255 298 minecraft:spruce_planks
setblock 48 255 305 minecraft:spruce_planks
setblock 48 255 312 minecraft:spruce_planks
setblock 51 255 316 minecraft:spruce_planks
setblock 54 255 276 minecraft:spruce_planks
setblock 58 255 316 minecraft:spruce_planks
setblock 61 255 276 minecraft:spruce_planks
setblock 65 255 316 minecraft:spruce_planks
setblock 68 255 276 minecraft:spruce_planks
fill 70 255 317 70 304 317 minecraft:light_blue_concrete
setblock 72 255 316 minecraft:spruce_planks
setblock 75 255 276 minecraft:spruce_planks
setblock 82 255 276 minecraft:spruce_planks
setblock 86 255 316 minecraft:spruce_planks
setblock 88 255 277 minecraft:spruce_planks
setblock 88 255 284 minecraft:spruce_planks
setblock 88 255 291 minecraft:spruce_planks
setblock 88 255 298 minecraft:spruce_planks
setblock 88 255 305 minecraft:spruce_planks
setblock 88 255 312 minecraft:spruce_planks
fill 89 255 284 89 308 284 minecraft:light_blue_concrete
setblock 89 255 296 minecraft:light_blue_wool
fill 89 255 297 89 308 299 minecraft:light_blue_concrete
setblock 48 256 278 minecraft:spruce_planks
fill 48 256 280 56 262 280 minecraft:white_wool
setblock 48 256 285 minecraft:spruce_planks
setblock 48 256 292 minecraft:spruce_planks
setblock 48 256 299 minecraft:spruce_planks
setblock 48 256 306 minecraft:spruce_planks
setblock 48 256 313 minecraft:spruce_planks
setblock 52 256 316 minecraft:spruce_planks
setblock 53 256 276 minecraft:spruce_planks
setblock 59 256 316 minecraft:spruce_planks
setblock 60 256 276 minecraft:spruce_planks
setblock 66 256 316 minecraft:spruce_planks
setblock 67 256 276 minecraft:spruce_planks
setblock 73 256 316 minecraft:spruce_planks
setblock 74 256 276 minecraft:spruce_planks
fill 80 256 312 88 262 312 minecraft:white_wool
setblock 81 256 276 minecraft:spruce_planks
setblock 81 256 317 minecraft:light_blue_wool
fill 82 256 317 86 258 317 minecraft:light_blue_concrete
setblock 87 256 316 minecraft:spruce_planks
setblock 88 256 276 minecraft:spruce_planks
setblock 88 256 283 minecraft:spruce_planks
setblock 88 256 290 minecraft:spruce_planks
setblock 88 256 297 minecraft:spruce_planks
setblock 88 256 304 minecraft:spruce_planks
setblock 88 256 311 minecraft:spruce_planks
fill 89 256 296 89 308 296 minecraft:light_blue_concrete
fill 47 257 285 47 265 287 minecraft:light_blue_concrete
setblock 48 257 279 minecraft:spruce_planks
setblock 48 257 286 minecraft:spruce_planks
setblock 48 257 293 minecraft:spruce_planks
setblock 48 257 300 minecraft:spruce_planks
setblock 48 257 307 minecraft:spruce_planks
setblock 48 257 314 minecraft:spruce_planks
fill 48 257 317 52 289 317 minecraft:light_blue_concrete
setblock 52 257 276 minecraft:spruce_planks
setblock 53 257 316 minecraft:spruce_planks
setblock 53 257 317 minecraft:light_blue_wool
fill 54 257 317 56 298 317 minecraft:light_blue_concrete
setblock 59 257 276 minecraft:spruce_planks
setblock 60 257 316 minecraft:spruce_planks
setblock 66 257 276 minecraft:spruce_planks
setblock 67 257 316 minecraft:spruce_planks
setblock 72 257 275 minecraft:light_blue_wool
setblock 73 257 276 minecraft:spruce_planks
setblock 74 257 275 minecraft:white_wool
setblock 74 257 316 minecraft:spruce_planks
setblock 80 257 276 minecraft:spruce_planks
setblock 81 257 316 minecraft:spruce_planks
fill 81 257 317 81 308 317 minecraft:light_blue_concrete
setblock 87 257 276 minecraft:spruce_planks
setblock 88 257 282 minecraft:spruce_planks
setblock 88 257 289 minecraft:spruce_planks
setblock 88 257 296 minecraft:spruce_planks
setblock 88 257 303 minecraft:spruce_planks
setblock 88 257 310 minecraft:spruce_planks
setblock 88 257 316 minecraft:spruce_planks
setblock 88 257 317 minecraft:light_blue_wool
setblock 48 258 287 minecraft:spruce_planks
setblock 48 258 294 minecraft:spruce_planks
setblock 48 258 301 minecraft:spruce_planks
setblock 48 258 308 minecraft:spruce_planks
setblock 48 258 315 minecraft:spruce_planks
setblock 50 258 278 minecraft:light[level=15]
setblock 50 258 286 minecraft:light[level=15]
setblock 50 258 294 minecraft:light[level=15]
setblock 50 258 302 minecraft:light[level=15]
setblock 50 258 310 minecraft:light[level=15]
setblock 51 258 276 minecraft:spruce_planks
fill 53 258 317 53 264 317 minecraft:light_blue_concrete
setblock 54 258 316 minecraft:spruce_planks
setblock 58 258 276 minecraft:spruce_planks
setblock 58 258 278 minecraft:light[level=15]
setblock 58 258 286 minecraft:light[level=15]
setblock 58 258 294 minecraft:light[level=15]
setblock 58 258 302 minecraft:light[level=15]
setblock 58 258 310 minecraft:light[level=15]
setblock 61 258 316 minecraft:spruce_planks
setblock 65 258 276 minecraft:spruce_planks
setblock 66 258 278 minecraft:light[level=15]
setblock 66 258 286 minecraft:light[level=15]
setblock 66 258 294 minecraft:light[level=15]
setblock 66 258 302 minecraft:light[level=15]
setblock 66 258 310 minecraft:light[level=15]
setblock 68 258 316 minecraft:spruce_planks
fill 71 258 317 71 294 317 minecraft:light_blue_concrete
fill 72 258 275 72 308 275 minecraft:light_blue_concrete
setblock 72 258 276 minecraft:spruce_planks
setblock 72 258 317 minecraft:light_blue_wool
fill 73 258 317 80 261 317 minecraft:light_blue_concrete
fill 74 258 275 74 282 275 minecraft:light_blue_concrete
setblock 74 258 278 minecraft:light[level=15]
setblock 74 258 286 minecraft:light[level=15]
setblock 74 258 294 minecraft:light[level=15]
setblock 74 258 302 minecraft:light[level=15]
setblock 74 258 310 minecraft:light[level=15]
setblock 75 258 316 minecraft:spruce_planks
setblock 79 258 276 minecraft:spruce_planks
setblock 82 258 278 minecraft:light[level=15]
setblock 82 258 286 minecraft:light[level=15]
setblock 82 258 294 minecraft:light[level=15]
setblock 82 258 302 minecraft:light[level=15]
setblock 82 258 310 minecraft:light[level=15]
setblock 82 258 316 minecraft:spruce_planks
setblock 86 258 276 minecraft:spruce_planks
setblock 88 258 281 minecraft:spruce_planks
setblock 88 258 288 minecraft:spruce_planks
setblock 88 258 295 minecraft:spruce_planks
setblock 88 258 302 minecraft:spruce_planks
setblock 88 258 309 minecraft:spruce_planks
fill 88 258 317 88 308 317 minecraft:light_blue_concrete
fill 72 259 317 72 308 317 minecraft:light_blue_concrete
fill 82 259 317 83 269 317 minecraft:light_blue_concrete
setblock 84 259 317 minecraft:white_wool
fill 85 259 317 86 263 317 minecraft:light_blue_concrete
fill 47 260 291 47 281 291 minecraft:light_blue_concrete
setblock 47 260 292 minecraft:light_blue_wool
fill 48 260 276 48 260 279 minecraft:spruce_planks
fill 48 260 282 48 260 287 minecraft:spruce_planks
fill 48 260 289 48 260 294 minecraft:spruce_planks
fill 48 260 296 48 260 301 minecraft:spruce_planks
fill 48 260 303 48 260 308 minecraft:spruce_planks
fill 48 260 310 48 260 315 minecraft:spruce_planks
setblock 49 260 276 minecraft:spruce_planks
fill 49 260 316 54 260 316 minecraft:spruce_planks
setblock 50 260 278 minecraft:light[level=12]
setblock 50 260 285 minecraft:light[level=12]
setblock 50 260 292 minecraft:light[level=12]
setblock 50 260 299 minecraft:light[level=12]
setblock 50 260 306 minecraft:light[level=12]
setblock 50 260 313 minecraft:light[level=12]
fill 51 260 276 56 260 276 minecraft:spruce_planks
fill 51 260 288 51 263 288 minecraft:iron_bars
fill 56 260 316 61 260 316 minecraft:spruce_planks
setblock 57 260 278 minecraft:light[level=12]
setblock 57 260 285 minecraft:light[level=12]
setblock 57 260 292 minecraft:light[level=12]
setblock 57 260 299 minecraft:light[level=12]
setblock 57 260 306 minecraft:light[level=12]
setblock 57 260 313 minecraft:light[level=12]
fill 58 260 276 63 260 276 minecraft:spruce_planks
setblock 60 260 317 minecraft:white_wool
fill 63 260 316 68 260 316 minecraft:spruce_planks
setblock 64 260 278 minecraft:light[level=12]
setblock 64 260 285 minecraft:light[level=12]
setblock 64 260 292 minecraft:light[level=12]
setblock 64 260 299 minecraft:light[level=12]
setblock 64 260 306 minecraft:light[level=12]
setblock 64 260 313 minecraft:light[level=12]
fill 65 260 276 70 260 276 minecraft:spruce_planks
fill 68 260 313 68 261 315 minecraft:iron_bars
fill 70 260 316 75 260 316 minecraft:spruce_planks
setblock 71 260 278 minecraft:light[level=12]
setblock 71 260 285 minecraft:light[level=12]
setblock 71 260 292 minecraft:light[level=12]
setblock 71 260 299 minecraft:light[level=12]
setblock 71 260 306 minecraft:light[level=12]
setblock 71 260 313 minecraft:light[level=12]
fill 72 260 276 77 260 276 minecraft:spruce_planks
fill 77 260 316 82 260 316 minecraft:spruce_planks
setblock 78 260 278 minecraft:light[level=12]
setblock 78 260 285 minecraft:light[level=12]
setblock 78 260 292 minecraft:light[level=12]
setblock 78 260 299 minecraft:light[level=12]
setblock 78 260 306 minecraft:light[level=12]
setblock 78 260 313 minecraft:light[level=12]
fill 79 260 276 84 260 276 minecraft:spruce_planks
fill 84 260 316 88 260 316 minecraft:spruce_planks
fill 84 260 317 84 308 317 minecraft:light_blue_concrete
setblock 85 260 278 minecraft:light[level=12]
setblock 85 260 285 minecraft:light[level=12]
setblock 85 260 292 minecraft:light[level=12]
setblock 85 260 299 minecraft:light[level=12]
setblock 85 260 306 minecraft:light[level=12]
setblock 85 260 313 minecraft:light[level=12]
fill 86 260 276 88 260 276 minecraft:spruce_planks
fill 88 260 277 88 260 279 minecraft:spruce_planks
fill 88 260 281 88 260 286 minecraft:spruce_planks
fill 88 260 288 88 260 293 minecraft:spruce_planks
fill 88 260 295 88 260 300 minecraft:spruce_planks
fill 88 260 302 88 260 307 minecraft:spruce_planks
fill 88 260 309 88 260 311 minecraft:spruce_planks
fill 88 260 313 88 260 314 minecraft:spruce_planks
fill 47 261 292 47 308 292 minecraft:light_blue_concrete
setblock 48 261 276 minecraft:spruce_planks
setblock 48 261 283 minecraft:spruce_planks
setblock 48 261 290 minecraft:spruce_planks
fill 48 261 294 50 262 294 minecraft:iron_bars
setblock 48 261 297 minecraft:spruce_planks
setblock 48 261 304 minecraft:spruce_planks
setblock 48 261 311 minecraft:spruce_planks
setblock 50 261 316 minecraft:spruce_planks
setblock 55 261 276 minecraft:spruce_planks
setblock 57 261 316 minecraft:spruce_planks
fill 60 261 317 60 282 317 minecraft:light_blue_concrete
setblock 62 261 276 minecraft:spruce_planks
setblock 64 261 316 minecraft:spruce_planks
setblock 69 261 276 minecraft:spruce_planks
setblock 71 261 316 minecraft:spruce_planks
setblock 76 261 276 minecraft:spruce_planks
setblock 78 261 316 minecraft:spruce_planks
setblock 83 261 276 minecraft:spruce_planks
setblock 85 261 316 minecraft:spruce_planks
setblock 88 261 278 minecraft:spruce_planks
setblock 88 261 285 minecraft:spruce_planks
setblock 88 261 292 minecraft:spruce_planks
setblock 88 261 299 minecraft:spruce_planks
setblock 88 261 306 minecraft:spruce_planks
setblock 88 261 313 minecraft:spruce_planks
setblock 47 262 281 minecraft:white_wool
fill 47 262 282 47 275 284 minecraft:light_blue_concrete
setblock 48 262 277 minecraft:spruce_planks
setblock 48 262 284 minecraft:spruce_planks
setblock 48 262 291 minecraft:spruce_planks
setblock 48 262 298 minecraft:spruce_planks
setblock 48 262 305 minecraft:spruce_planks
setblock 48 262 312 minecraft:spruce_planks
setblock 51 262 316 minecraft:spruce_planks
setblock 54 262 276 minecraft:spruce_planks
setblock 58 262 316 minecraft:spruce_planks
setblock 61 262 276 minecraft:spruce_planks
setblock 65 262 316 minecraft:spruce_planks
setblock 68 262 276 minecraft:spruce_planks
setblock 72 262 316 minecraft:spruce_planks
setblock 73 262 317 minecraft:white_wool
fill 74 262 317 80 277 317 minecraft:light_blue_concrete
setblock 75 262 276 minecraft:spruce_planks
setblock 79 262 316 minecraft:spruce_planks
setblock 82 262 276 minecraft:spruce_planks
setblock 86 262 316 minecraft:spruce_planks
setblock 88 262 277 minecraft:spruce_planks
setblock 88 262 284 minecraft:spruce_planks
setblock 88 262 291 minecraft:spruce_planks
setblock 88 262 298 minecraft:spruce_planks
setblock 88 262 305 minecraft:spruce_planks
fill 47 263 281 47 308 281 minecraft:light_blue_concrete
setblock 48 263 278 minecraft:spruce_planks
fill 48 263 280 56 263 280 minecraft:spruce_log
setblock 48 263 285 minecraft:spruce_planks
setblock 48 263 292 minecraft:spruce_planks
setblock 48 263 299 minecraft:spruce_planks
setblock 48 263 306 minecraft:spruce_planks
setblock 48 263 313 minecraft:spruce_planks
fill 49 263 275 50 308 275 minecraft:light_blue_concrete
setblock 51 263 275 minecraft:white_wool
fill 52 263 275 52 308 275 minecraft:light_blue_concrete
setblock 52 263 316 minecraft:spruce_planks
setblock 53 263 275 minecraft:white_wool
setblock 53 263 276 minecraft:spruce_planks
fill 54 263 275 56 264 275 minecraft:light_blue_concrete
setblock 59 263 316 minecraft:spruce_planks
setblock 60 263 276 minecraft:spruce_planks
setblock 66 263 316 minecraft:spruce_planks
setblock 67 263 276 minecraft:spruce_planks
setblock 73 263 316 minecraft:spruce_planks
fill 73 263 317 73 294 317 minecraft:light_blue_concrete
setblock 74 263 276 minecraft:spruce_planks
fill 80 263 312 88 263 312 minecraft:spruce_log
setblock 80 263 316 minecraft:spruce_planks
setblock 81 263 276 minecraft:spruce_planks
setblock 87 263 316 minecraft:spruce_planks
setblock 88 263 276 minecraft:spruce_planks
setblock 88 263 283 minecraft:spruce_planks
setblock 88 263 290 minecraft:spruce_planks
setblock 88 263 297 minecraft:spruce_planks
setblock 88 263 304 minecraft:spruce_planks
setblock 88 263 311 minecraft:spruce_planks
setblock 89 263 304 minecraft:white_wool
fill 89 263 305 89 308 306 minecraft:light_blue_concrete
setblock 48 264 279 minecraft:spruce_planks
fill 48 264 283 51 264 285 minecraft:dark_oak_planks
fill 48 264 286 48 265 286 minecraft:spruce_planks
fill 48 264 287 51 264 287 minecraft:dark_oak_planks
fill 48 264 289 51 264 292 minecraft:dark_oak_planks
fill 48 264 293 48 265 293 minecraft:spruce_planks
setblock 48 264 300 minecraft:spruce_planks
setblock 48 264 307 minecraft:spruce_planks
setblock 48 264 314 minecraft:spruce_planks
fill 49 264 286 51 264 286 minecraft:dark_oak_planks
fill 49 264 288 51 264 288 minecraft:dark_oak_planks
fill 49 264 293 51 264 293 minecraft:dark_oak_planks
fill 51 264 275 51 308 275 minecraft:light_blue_concrete
fill 51 264 280 53 277 280 minecraft:spruce_log
setblock 52 264 276 minecraft:spruce_planks
fill 53 264 275 53 308 275 minecraft:light_blue_concrete
setblock 53 264 316 minecraft:spruce_planks
setblock 59 264 276 minecraft:spruce_planks
setblock 60 264 316 minecraft:spruce_planks
setblock 66 264 276 minecraft:spruce_planks
setblock 67 264 316 minecraft:spruce_planks
setblock 73 264 276 minecraft:spruce_planks
setblock 74 264 316 minecraft:spruce_planks
fill 77 264 275 78 308 275 minecraft:light_blue_concrete
setblock 79 264 275 minecraft:light_blue_wool
setblock 80 264 276 minecraft:spruce_planks
setblock 81 264 316 minecraft:spruce_planks
fill 83 264 312 85 277 312 minecraft:spruce_log
setblock 85 264 317 minecraft:white_wool
fill 86 264 317 86 287 317 minecraft:light_blue_concrete
setblock 87 264 276 minecraft:spruce_planks
setblock 88 264 282 minecraft:spruce_planks
setblock 88 264 289 minecraft:spruce_planks
setblock 88 264 296 minecraft:spruce_planks
setblock 88 264 303 minecraft:spruce_planks
setblock 88 264 310 minecraft:spruce_planks
setblock 88 264 316 minecraft:spruce_planks
fill 89 264 304 89 308 304 minecraft:light_blue_concrete
setblock 48 265 280 minecraft:spruce_planks
fill 48 265 283 51 265 285 minecraft:spruce_planks
fill 48 265 287 51 265 287 minecraft:spruce_planks
fill 48 265 289 51 265 292 minecraft:spruce_planks
setblock 48 265 294 minecraft:spruce_planks
setblock 48 265 301 minecraft:spruce_planks
setblock 48 265 308 minecraft:spruce_planks
setblock 48 265 315 minecraft:spruce_planks
fill 49 265 286 51 265 286 minecraft:spruce_planks
fill 49 265 288 51 265 288 minecraft:spruce_planks
fill 49 265 293 51 265 293 minecraft:spruce_planks
setblock 51 265 276 minecraft:spruce_planks
setblock 53 265 317 minecraft:white_wool
fill 54 265 275 54 308 275 minecraft:light_blue_concrete
setblock 54 265 316 minecraft:spruce_planks
setblock 55 265 275 minecraft:white_wool
fill 56 265 275 56 301 275 minecraft:light_blue_concrete
setblock 58 265 276 minecraft:spruce_planks
setblock 61 265 316 minecraft:spruce_planks
setblock 65 265 276 minecraft:spruce_planks
setblock 68 265 316 minecraft:spruce_planks
setblock 72 265 276 minecraft:spruce_planks
setblock 75 265 316 minecraft:spruce_planks
fill 79 265 275 79 295 275 minecraft:light_blue_concrete
setblock 79 265 276 minecraft:spruce_planks
setblock 82 265 316 minecraft:spruce_planks
fill 85 265 317 85 308 317 minecraft:light_blue_concrete
setblock 86 265 276 minecraft:spruce_planks
setblock 88 265 281 minecraft:spruce_planks
setblock 88 265 288 minecraft:spruce_planks
setblock 88 265 295 minecraft:spruce_planks
setblock 88 265 302 minecraft:spruce_planks
setblock 88 265 309 minecraft:spruce_planks
fill 47 266 285 47 308 286 minecraft:light_blue_concrete
fill 47 266 287 47 269 289 minecraft:shroomlight
fill 47 266 290 47 302 290 minecraft:light_blue_concrete
setblock 50 266 278 minecraft:light[level=15]
setblock 50 266 285 minecraft:light[level=12]
setblock 50 266 286 minecraft:light[level=15]
setblock 50 266 292 minecraft:light[level=12]
setblock 50 266 294 minecraft:light[level=15]
setblock 50 266 299 minecraft:light[level=12]
setblock 50 266 302 minecraft:light[level=15]
setblock 50 266 306 minecraft:light[level=12]
setblock 50 266 310 minecraft:light[level=15]
setblock 50 266 313 minecraft:light[level=12]
fill 51 266 283 51 266 293 minecraft:dark_oak_planks
fill 53 266 317 53 308 317 minecraft:light_blue_concrete
fill 55 266 275 55 268 275 minecraft:light_blue_concrete
setblock 57 266 278 minecraft:light[level=12]
setblock 57 266 285 minecraft:light[level=12]
setblock 57 266 292 minecraft:light[level=12]
setblock 57 266 299 minecraft:light[level=12]
setblock 57 266 306 minecraft:light[level=12]
setblock 57 266 313 minecraft:light[level=12]
setblock 58 266 278 minecraft:light[level=15]
setblock 58 266 286 minecraft:light[level=15]
setblock 58 266 294 minecraft:light[level=15]
setblock 58 266 302 minecraft:light[level=15]
setblock 58 266 310 minecraft:light[level=15]
setblock 64 266 278 minecraft:light[level=12]
setblock 64 266 285 minecraft:light[level=12]
setblock 64 266 292 minecraft:light[level=12]
setblock 64 266 299 minecraft:light[level=12]
setblock 64 266 306 minecraft:light[level=12]
setblock 64 266 313 minecraft:light[level=12]
setblock 66 266 278 minecraft:light[level=15]
setblock 66 266 286 minecraft:light[level=15]
setblock 66 266 294 minecraft:light[level=15]
setblock 66 266 302 minecraft:light[level=15]
setblock 66 266 310 minecraft:light[level=15]
setblock 71 266 278 minecraft:light[level=12]
setblock 71 266 285 minecraft:light[level=12]
setblock 71 266 292 minecraft:light[level=12]
setblock 71 266 299 minecraft:light[level=12]
setblock 71 266 306 minecraft:light[level=12]
setblock 71 266 313 minecraft:light[level=12]
setblock 74 266 278 minecraft:light[level=15]
setblock 74 266 286 minecraft:light[level=15]
setblock 74 266 294 minecraft:light[level=15]
setblock 74 266 302 minecraft:light[level=15]
setblock 74 266 310 minecraft:light[level=15]
setblock 78 266 278 minecraft:light[level=12]
setblock 78 266 285 minecraft:light[level=12]
setblock 78 266 292 minecraft:light[level=12]
setblock 78 266 299 minecraft:light[level=12]
setblock 78 266 306 minecraft:light[level=12]
setblock 78 266 313 minecraft:light[level=12]
setblock 82 266 278 minecraft:light[level=15]
setblock 82 266 286 minecraft:light[level=15]
setblock 82 266 294 minecraft:light[level=15]
setblock 82 266 302 minecraft:light[level=15]
setblock 82 266 310 minecraft:light[level=15]
setblock 85 266 278 minecraft:light[level=12]
setblock 85 266 285 minecraft:light[level=12]
setblock 85 266 292 minecraft:light[level=12]
setblock 85 266 299 minecraft:light[level=12]
setblock 85 266 306 minecraft:light[level=12]
setblock 85 266 313 minecraft:light[level=12]
setblock 48 267 282 minecraft:spruce_planks
setblock 48 267 289 minecraft:spruce_planks
setblock 48 267 296 minecraft:spruce_planks
setblock 48 267 303 minecraft:spruce_planks
setblock 48 267 310 minecraft:spruce_planks
setblock 49 267 276 minecraft:spruce_planks
setblock 49 267 316 minecraft:spruce_planks
setblock 51 267 283 minecraft:spruce_planks
setblock 51 267 288 minecraft:spruce_planks
setblock 51 267 293 minecraft:spruce_planks
setblock 56 267 276 minecraft:spruce_planks
setblock 56 267 316 minecraft:spruce_planks
setblock 63 267 276 minecraft:spruce_planks
setblock 63 267 316 minecraft:spruce_planks
setblock 70 267 276 minecraft:spruce_planks
setblock 70 267 316 minecraft:spruce_planks
setblock 77 267 276 minecraft:spruce_planks
setblock 77 267 316 minecraft:spruce_planks
setblock 84 267 276 minecraft:spruce_planks
setblock 84 267 316 minecraft:spruce_planks
setblock 88 267 279 minecraft:spruce_planks
setblock 88 267 286 minecraft:spruce_planks
setblock 88 267 293 minecraft:spruce_planks
setblock 88 267 300 minecraft:spruce_planks
setblock 88 267 307 minecraft:spruce_planks
setblock 88 267 314 minecraft:spruce_planks
fill 47 268 313 47 308 313 minecraft:light_blue_concrete
setblock 47 268 314 minecraft:white_wool
setblock 48 268 276 minecraft:spruce_planks
setblock 48 268 283 minecraft:spruce_planks
setblock 48 268 290 minecraft:spruce_planks
setblock 48 268 297 minecraft:spruce_planks
setblock 48 268 304 minecraft:spruce_planks
setblock 48 268 311 minecraft:spruce_planks
setblock 50 268 316 minecraft:spruce_planks
setblock 55 268 276 minecraft:spruce_planks
setblock 57 268 316 minecraft:spruce_planks
setblock 62 268 276 minecraft:spruce_planks
setblock 64 268 316 minecraft:spruce_planks
setblock 69 268 276 minecraft:spruce_planks
setblock 71 268 316 minecraft:spruce_planks
setblock 76 268 276 minecraft:spruce_planks
setblock 78 268 316 minecraft:spruce_planks
setblock 83 268 276 minecraft:spruce_planks
setblock 85 268 316 minecraft:spruce_planks
setblock 88 268 278 minecraft:spruce_planks
setblock 88 268 285 minecraft:spruce_planks
setblock 88 268 292 minecraft:spruce_planks
setblock 88 268 299 minecraft:spruce_planks
setblock 88 268 306 minecraft:spruce_planks
setblock 88 268 313 minecraft:spruce_planks
setblock 47 269 307 minecraft:white_wool
fill 47 269 308 47 308 309 minecraft:light_blue_concrete
fill 47 269 314 47 308 314 minecraft:light_blue_concrete
fill 48 269 277 48 270 277 minecraft:spruce_planks
fill 48 269 282 57 270 282 minecraft:spruce_planks
fill 48 269 284 48 270 284 minecraft:spruce_planks
fill 48 269 291 48 270 291 minecraft:spruce_planks
fill 48 269 298 48 270 298 minecraft:spruce_planks
fill 48 269 305 48 270 305 minecraft:spruce_planks
fill 48 269 312 48 270 312 minecraft:spruce_planks
fill 49 269 281 51 270 281 minecraft:spruce_planks
fill 51 269 316 51 270 316 minecraft:spruce_planks
fill 54 269 276 54 270 276 minecraft:spruce_planks
setblock 55 269 275 minecraft:light_blue_wool
fill 58 269 316 58 270 316 minecraft:spruce_planks
fill 61 269 276 61 270 276 minecraft:spruce_planks
fill 65 269 316 65 270 316 minecraft:spruce_planks
fill 68 269 276 68 270 276 minecraft:spruce_planks
fill 72 269 316 72 270 316 minecraft:spruce_planks
fill 75 269 276 75 270 276 minecraft:spruce_planks
fill 79 269 316 79 270 316 minecraft:spruce_planks
fill 80 269 313 80 270 315 minecraft:iron_bars
fill 82 269 276 82 270 276 minecraft:spruce_planks
fill 86 269 316 86 270 316 minecraft:spruce_planks
fill 88 269 277 88 270 277 minecraft:spruce_planks
fill 88 269 284 88 272 284 minecraft:spruce_planks
fill 88 269 291 88 270 291 minecraft:spruce_planks
fill 88 269 298 88 270 298 minecraft:spruce_planks
fill 88 269 305 88 270 305 minecraft:spruce_planks
fill 88 269 312 88 270 312 minecraft:spruce_planks
fill 47 270 287 47 274 289 minecraft:light_blue_concrete
fill 47 270 307 47 308 307 minecraft:light_blue_concrete
fill 48 270 276 49 270 276 minecraft:spruce_planks
fill 48 270 278 48 270 280 minecraft:spruce_planks
setblock 48 270 283 minecraft:spruce_planks
fill 48 270 285 48 270 287 minecraft:spruce_planks
fill 48 270 289 48 270 290 minecraft:spruce_planks
fill 48 270 292 48 270 294 minecraft:spruce_planks
fill 48 270 296 48 270 297 minecraft:spruce_planks
fill 48 270 299 48 270 301 minecraft:spruce_planks
fill 48 270 303 48 270 304 minecraft:spruce_planks
fill 48 270 306 48 270 308 minecraft:spruce_planks
fill 48 270 310 48 270 311 minecraft:spruce_planks
fill 48 270 313 48 270 315 minecraft:spruce_planks
fill 49 270 316 50 270 316 minecraft:spruce_planks
fill 51 270 276 53 270 276 minecraft:spruce_planks
fill 52 270 316 54 270 316 minecraft:spruce_planks
fill 53 270 281 59 270 281 minecraft:spruce_planks
fill 55 270 275 55 277 275 minecraft:light_blue_concrete
fill 55 270 276 56 270 276 minecraft:spruce_planks
fill 56 270 316 57 270 316 minecraft:spruce_planks
fill 58 270 276 60 270 276 minecraft:spruce_planks
fill 58 270 282 72 271 282 minecraft:spruce_planks
fill 59 270 316 61 270 316 minecraft:spruce_planks
fill 60 270 283 77 270 283 minecraft:spruce_planks
fill 62 270 276 63 270 276 minecraft:spruce_planks
fill 63 270 316 64 270 316 minecraft:spruce_planks
fill 65 270 276 67 270 276 minecraft:spruce_planks
fill 66 270 316 68 270 316 minecraft:spruce_planks
fill 69 270 276 70 270 276 minecraft:spruce_planks
fill 70 270 316 71 270 316 minecraft:spruce_planks
fill 72 270 276 74 270 276 minecraft:spruce_planks
fill 73 270 316 75 270 316 minecraft:spruce_planks
fill 76 270 276 77 270 276 minecraft:spruce_planks
fill 77 270 316 78 270 316 minecraft:spruce_planks
fill 79 270 276 81 270 276 minecraft:spruce_planks
fill 80 270 316 82 270 316 minecraft:spruce_planks
setblock 82 270 317 minecraft:white_wool
fill 83 270 276 84 270 276 minecraft:spruce_planks
fill 83 270 317 83 302 317 minecraft:light_blue_concrete
fill 84 270 316 85 270 316 minecraft:spruce_planks
fill 86 270 276 88 270 276 minecraft:spruce_planks
fill 87 270 316 88 270 316 minecraft:spruce_planks
fill 88 270 278 88 270 279 minecraft:spruce_planks
fill 88 270 281 88 270 283 minecraft:spruce_planks
fill 88 270 285 88 270 286 minecraft:spruce_planks
fill 88 270 288 88 270 290 minecraft:spruce_planks
fill 88 270 292 88 270 293 minecraft:spruce_planks
fill 88 270 295 88 270 297 minecraft:spruce_planks
fill 88 270 299 88 270 300 minecraft:spruce_planks
fill 88 270 302 88 270 304 minecraft:spruce_planks
fill 88 270 306 88 270 307 minecraft:spruce_planks
fill 88 270 309 88 270 311 minecraft:spruce_planks
fill 88 270 313 88 270 314 minecraft:spruce_planks
setblock 48 271 279 minecraft:spruce_planks
setblock 48 271 286 minecraft:spruce_planks
setblock 48 271 293 minecraft:spruce_planks
setblock 48 271 300 minecraft:spruce_planks
setblock 48 271 307 minecraft:spruce_planks
setblock 48 271 314 minecraft:spruce_planks
fill 49 271 281 50 271 282 minecraft:dark_oak_planks
fill 51 271 282 57 271 282 minecraft:dark_oak_planks
setblock 52 271 276 minecraft:spruce_planks
setblock 53 271 316 minecraft:spruce_planks
setblock 59 271 276 minecraft:spruce_planks
setblock 60 271 316 minecraft:spruce_planks
fill 65 271 283 88 271 283 minecraft:spruce_planks
setblock 66 271 276 minecraft:spruce_planks
setblock 67 271 316 minecraft:spruce_planks
setblock 73 271 276 minecraft:spruce_planks
fill 73 271 282 79 271 282 minecraft:spruce_planks
setblock 74 271 316 minecraft:spruce_planks
setblock 80 271 276 minecraft:spruce_planks
fill 80 271 284 87 271 284 minecraft:spruce_planks
setblock 81 271 316 minecraft:spruce_planks
fill 82 271 317 82 308 317 minecraft:light_blue_concrete
setblock 87 271 276 minecraft:spruce_planks
setblock 88 271 282 minecraft:spruce_planks
setblock 88 271 289 minecraft:spruce_planks
setblock 88 271 296 minecraft:spruce_planks
setblock 88 271 303 minecraft:spruce_planks
setblock 88 271 310 minecraft:spruce_planks
setblock 88 271 316 minecraft:spruce_planks
setblock 47 272 280 minecraft:white_wool
setblock 48 272 280 minecraft:spruce_planks
setblock 48 272 287 minecraft:spruce_planks
setblock 48 272 294 minecraft:spruce_planks
setblock 48 272 301 minecraft:spruce_planks
setblock 48 272 308 minecraft:spruce_planks
setblock 48 272 315 minecraft:spruce_planks
setblock 50 272 278 minecraft:light[level=12]
setblock 50 272 285 minecraft:light[level=12]
setblock 50 272 292 minecraft:light[level=12]
setblock 50 272 299 minecraft:light[level=12]
setblock 50 272 306 minecraft:light[level=12]
setblock 50 272 313 minecraft:light[level=12]
setblock 51 272 276 minecraft:spruce_planks
setblock 54 272 316 minecraft:spruce_planks
setblock 57 272 278 minecraft:light[level=12]
setblock 57 272 285 minecraft:light[level=12]
setblock 57 272 292 minecraft:light[level=12]
setblock 57 272 299 minecraft:light[level=12]
setblock 57 272 306 minecraft:light[level=12]
setblock 57 272 313 minecraft:light[level=12]
setblock 58 272 276 minecraft:spruce_planks
fill 59 272 282 70 272 282 minecraft:dark_oak_planks
setblock 61 272 316 minecraft:spruce_planks
setblock 64 272 278 minecraft:light[level=12]
setblock 64 272 285 minecraft:light[level=12]
setblock 64 272 292 minecraft:light[level=12]
setblock 64 272 299 minecraft:light[level=12]
setblock 64 272 306 minecraft:light[level=12]
setblock 64 272 313 minecraft:light[level=12]
setblock 65 272 276 minecraft:spruce_planks
setblock 68 272 316 minecraft:spruce_planks
fill 69 272 283 77 272 283 minecraft:dark_oak_planks
setblock 71 272 278 minecraft:light[level=12]
setblock 71 272 285 minecraft:light[level=12]
setblock 71 272 292 minecraft:light[level=12]
setblock 71 272 299 minecraft:light[level=12]
setblock 71 272 306 minecraft:light[level=12]
setblock 71 272 313 minecraft:light[level=12]
setblock 72 272 276 minecraft:spruce_planks
setblock 75 272 316 minecraft:spruce_planks
setblock 78 272 278 minecraft:light[level=12]
fill 78 272 283 88 272 283 minecraft:spruce_planks
setblock 78 272 285 minecraft:light[level=12]
setblock 78 272 292 minecraft:light[level=12]
setblock 78 272 299 minecraft:light[level=12]
setblock 78 272 306 minecraft:light[level=12]
setblock 78 272 313 minecraft:light[level=12]
setblock 79 272 276 minecraft:spruce_planks
setblock 82 272 316 minecraft:spruce_planks
setblock 85 272 278 minecraft:light[level=12]
fill 85 272 284 87 272 284 minecraft:spruce_planks
setblock 85 272 285 minecraft:light[level=12]
setblock 85 272 292 minecraft:light[level=12]
setblock 85 272 299 minecraft:light[level=12]
setblock 85 272 306 minecraft:light[level=12]
setblock 85 272 313 minecraft:light[level=12]
setblock 86 272 276 minecraft:spruce_planks
setblock 86 272 288 minecraft:white_wool
setblock 88 272 281 minecraft:spruce_planks
setblock 88 272 288 minecraft:spruce_planks
setblock 88 272 295 minecraft:spruce_planks
setblock 88 272 302 minecraft:spruce_planks
setblock 88 272 309 minecraft:spruce_planks
fill 47 273 280 47 306 280 minecraft:light_blue_concrete
fill 58 273 275 63 301 275 minecraft:light_blue_concrete
fill 63 273 317 64 281 317 minecraft:light_blue_concrete
setblock 64 273 275 minecraft:light_blue_wool
fill 65 273 275 70 278 275 minecraft:light_blue_concrete
setblock 65 273 317 minecraft:white_wool
fill 66 273 317 68 292 317 minecraft:light_blue_concrete
fill 47 274 277 47 275 278 minecraft:light_blue_concrete
setblock 47 274 279 minecraft:light_blue_wool
setblock 50 274 278 minecraft:light[level=15]
setblock 50 274 286 minecraft:light[level=15]
setblock 50 274 294 minecraft:light[level=15]
setblock 50 274 302 minecraft:light[level=15]
setblock 50 274 310 minecraft:light[level=15]
setblock 58 274 278 minecraft:light[level=15]
setblock 58 274 286 minecraft:light[level=15]
setblock 58 274 294 minecraft:light[level=15]
setblock 58 274 302 minecraft:light[level=15]
setblock 58 274 310 minecraft:light[level=15]
fill 64 274 275 64 308 275 minecraft:light_blue_concrete
fill 65 274 317 65 308 317 minecraft:light_blue_concrete
setblock 66 274 278 minecraft:light[level=15]
setblock 66 274 286 minecraft:light[level=15]
setblock 66 274 294 minecraft:light[level=15]
setblock 66 274 302 minecraft:light[level=15]
setblock 66 274 310 minecraft:light[level=15]
setblock 74 274 278 minecraft:light[level=15]
setblock 74 274 286 minecraft:light[level=15]
setblock 74 274 294 minecraft:light[level=15]
setblock 74 274 302 minecraft:light[level=15]
setblock 74 274 310 minecraft:light[level=15]
setblock 82 274 278 minecraft:light[level=15]
setblock 82 274 286 minecraft:light[level=15]
setblock 82 274 294 minecraft:light[level=15]
setblock 82 274 302 minecraft:light[level=15]
setblock 82 274 310 minecraft:light[level=15]
setblock 89 274 290 minecraft:light_blue_wool
fill 47 275 279 47 286 279 minecraft:light_blue_concrete
setblock 47 275 287 minecraft:white_wool
fill 47 275 288 47 308 289 minecraft:light_blue_concrete
setblock 47 275 306 minecraft:white_wool
fill 89 275 290 89 308 290 minecraft:light_blue_concrete
setblock 47 276 277 minecraft:light_blue_wool
fill 47 276 278 47 281 278 minecraft:light_blue_concrete
fill 47 276 282 47 293 283 minecraft:light_blue_concrete
setblock 47 276 284 minecraft:light_blue_wool
fill 47 276 287 47 308 287 minecraft:light_blue_concrete
fill 47 276 306 47 308 306 minecraft:light_blue_concrete
setblock 89 276 277 minecraft:white_wool
fill 89 276 278 89 276 280 minecraft:light_blue_concrete
fill 89 276 286 89 296 287 minecraft:light_blue_concrete
setblock 89 276 288 minecraft:light_blue_wool
fill 89 276 289 89 308 289 minecraft:light_blue_concrete
fill 47 277 277 47 283 277 minecraft:light_blue_concrete
fill 47 277 284 47 308 284 minecraft:light_blue_concrete
setblock 89 277 277 minecraft:light_blue_wool
fill 89 277 278 89 287 278 minecraft:light_blue_concrete
setblock 89 277 279 minecraft:white_wool
fill 89 277 280 89 279 280 minecraft:light_blue_concrete
fill 89 277 288 89 304 288 minecraft:light_blue_concrete
fill 48 278 276 88 279 280 minecraft:white_wool
fill 48 278 281 88 279 281 minecraft:light_gray_wool
fill 48 278 282 88 279 286 minecraft:white_wool
fill 48 278 287 88 279 287 minecraft:light_gray_wool
fill 48 278 288 88 279 292 minecraft:white_wool
fill 48 278 293 88 279 293 minecraft:light_gray_wool
fill 48 278 294 64 278 298 minecraft:white_wool
fill 48 278 299 63 278 299 minecraft:light_gray_wool
fill 48 278 300 64 278 304 minecraft:white_wool
fill 48 278 305 88 278 305 minecraft:light_gray_wool
fill 48 278 306 88 278 310 minecraft:white_wool
fill 48 278 311 88 278 311 minecraft:light_gray_wool
fill 48 278 312 88 278 316 minecraft:white_wool
setblock 55 278 275 minecraft:light_blue_wool
fill 65 278 294 66 278 296 minecraft:white_wool
fill 65 278 302 66 278 304 minecraft:white_wool
fill 67 278 294 88 278 295 minecraft:white_wool
fill 67 278 303 88 278 304 minecraft:white_wool
fill 68 278 296 88 278 296 minecraft:white_wool
fill 68 278 302 88 278 302 minecraft:white_wool
fill 70 278 297 88 278 298 minecraft:white_wool
fill 70 278 300 88 278 301 minecraft:white_wool
fill 71 278 299 88 278 299 minecraft:light_gray_wool
fill 74 278 317 74 308 317 minecraft:light_blue_concrete
setblock 75 278 317 minecraft:white_wool
fill 76 278 317 80 300 317 minecraft:light_blue_concrete
fill 89 278 277 89 308 277 minecraft:light_blue_concrete
fill 89 278 279 89 308 279 minecraft:light_blue_concrete
fill 48 279 294 62 279 298 minecraft:white_wool
fill 48 279 299 62 279 299 minecraft:light_gray_wool
fill 48 279 300 62 279 304 minecraft:white_wool
fill 48 279 305 67 279 305 minecraft:light_gray_wool
fill 48 279 306 67 279 310 minecraft:white_wool
fill 48 279 311 69 279 311 minecraft:light_gray_wool
fill 48 279 312 69 279 316 minecraft:white_wool
fill 55 279 275 55 308 275 minecraft:light_blue_concrete
fill 63 279 294 63 279 297 minecraft:white_wool
fill 63 279 298 63 279 300 minecraft:red_wool
fill 63 279 301 63 279 304 minecraft:white_wool
fill 64 279 294 65 279 295 minecraft:white_wool
fill 64 279 296 64 279 298 minecraft:red_wool
fill 64 279 300 64 279 302 minecraft:red_wool
fill 64 279 303 65 279 304 minecraft:white_wool
fill 65 279 275 68 280 275 minecraft:light_blue_concrete
fill 65 279 296 66 279 296 minecraft:red_wool
fill 65 279 302 66 279 302 minecraft:red_wool
fill 66 279 294 88 279 294 minecraft:white_wool
fill 66 279 295 68 279 295 minecraft:red_wool
fill 66 279 303 68 279 303 minecraft:red_wool
fill 66 279 304 67 279 304 minecraft:white_wool
fill 68 279 296 70 279 296 minecraft:red_wool
fill 68 279 302 70 279 302 minecraft:red_wool
fill 68 279 304 69 279 310 minecraft:black_wool
setblock 69 279 275 minecraft:light_blue_wool
fill 69 279 295 88 279 295 minecraft:white_wool
fill 69 279 303 73 279 303 minecraft:black_wool
fill 70 279 275 70 308 275 minecraft:light_blue_concrete
fill 70 279 297 70 279 298 minecraft:red_wool
fill 70 279 300 70 279 301 minecraft:red_wool
fill 70 279 304 73 279 304 minecraft:black_wool
fill 70 279 305 73 279 305 minecraft:light_gray_wool
fill 70 279 306 73 279 308 minecraft:white_wool
fill 70 279 309 79 279 312 minecraft:black_wool
fill 70 279 313 88 279 316 minecraft:white_wool
fill 71 279 296 88 279 297 minecraft:white_wool
fill 71 279 298 71 279 300 minecraft:red_wool
fill 71 279 301 79 279 302 minecraft:black_wool
fill 72 279 298 88 279 298 minecraft:white_wool
fill 72 279 299 73 279 299 minecraft:light_gray_wool
fill 72 279 300 73 279 300 minecraft:white_wool
fill 74 279 299 75 279 300 minecraft:black_wool
fill 74 279 303 75 279 304 minecraft:white_wool
fill 74 279 305 75 279 308 minecraft:black_wool
fill 75 279 317 75 283 317 minecraft:light_blue_concrete
fill 76 279 299 77 279 299 minecraft:light_gray_wool
fill 76 279 300 77 279 300 minecraft:white_wool
fill 76 279 303 81 279 304 minecraft:black_wool
fill 76 279 305 79 279 305 minecraft:light_gray_wool
fill 76 279 306 79 279 308 minecraft:white_wool
fill 78 279 299 79 279 300 minecraft:black_wool
fill 80 279 299 88 279 299 minecraft:light_gray_wool
fill 80 279 300 88 279 302 minecraft:white_wool
fill 80 279 305 81 279 310 minecraft:black_wool
fill 80 279 311 88 279 311 minecraft:light_gray_wool
fill 80 279 312 88 286 312 minecraft:white_wool
fill 82 279 303 88 279 304 minecraft:white_wool
fill 82 279 305 88 279 305 minecraft:light_gray_wool
fill 82 279 306 88 279 310 minecraft:white_wool
fill 48 280 280 56 286 280 minecraft:white_wool
fill 52 280 279 52 303 279 minecraft:spruce_log
fill 52 280 281 52 303 281 minecraft:spruce_log
fill 57 280 317 58 283 317 minecraft:light_blue_concrete
setblock 59 280 317 minecraft:light_blue_wool
fill 69 280 275 69 308 275 minecraft:light_blue_concrete
fill 84 280 311 84 303 311 minecraft:spruce_log
fill 84 280 313 84 303 313 minecraft:spruce_log
setblock 89 280 280 minecraft:white_wool
fill 59 281 317 59 308 317 minecraft:light_blue_concrete
setblock 65 281 275 minecraft:white_wool
fill 66 281 275 68 289 275 minecraft:light_blue_concrete
fill 89 281 280 89 286 280 minecraft:light_blue_concrete
setblock 47 282 278 minecraft:light_blue_wool
setblock 47 282 291 minecraft:white_wool
setblock 50 282 278 minecraft:light[level=15]
setblock 50 282 286 minecraft:light[level=15]
setblock 50 282 294 minecraft:light[level=15]
setblock 50 282 302 minecraft:light[level=15]
setblock 50 282 310 minecraft:light[level=15]
setblock 58 282 278 minecraft:light[level=15]
setblock 58 282 286 minecraft:light[level=15]
setblock 58 282 294 minecraft:light[level=15]
setblock 58 282 302 minecraft:light[level=15]
setblock 58 282 310 minecraft:light[level=15]
setblock 63 282 317 minecraft:light_blue_wool
fill 64 282 317 64 308 317 minecraft:light_blue_concrete
fill 65 282 275 65 308 275 minecraft:light_blue_concrete
setblock 66 282 278 minecraft:light[level=15]
setblock 66 282 286 minecraft:light[level=15]
setblock 66 282 294 minecraft:light[level=15]
setblock 66 282 302 minecraft:light[level=15]
setblock 66 282 310 minecraft:light[level=15]
setblock 74 282 278 minecraft:light[level=15]
setblock 74 282 286 minecraft:light[level=15]
setblock 74 282 294 minecraft:light[level=15]
setblock 74 282 302 minecraft:light[level=15]
setblock 74 282 310 minecraft:light[level=15]
setblock 75 282 275 minecraft:white_wool
setblock 82 282 278 minecraft:light[level=15]
setblock 82 282 286 minecraft:light[level=15]
setblock 82 282 294 minecraft:light[level=15]
setblock 82 282 302 minecraft:light[level=15]
setblock 82 282 310 minecraft:light[level=15]
fill 89 282 302 89 282 303 minecraft:white_wool
fill 47 283 278 47 308 278 minecraft:light_blue_concrete
fill 47 283 291 47 288 291 minecraft:light_blue_concrete
setblock 48 283 277 minecraft:spruce_planks
fill 48 283 281 48 300 281 minecraft:spruce_planks
setblock 48 283 284 minecraft:spruce_planks
fill 48 283 288 48 300 288 minecraft:spruce_planks
setblock 48 283 291 minecraft:spruce_planks
fill 48 283 295 48 300 295 minecraft:spruce_planks
setblock 48 283 298 minecraft:spruce_planks
fill 48 283 302 48 300 302 minecraft:spruce_planks
setblock 48 283 305 minecraft:spruce_planks
fill 48 283 309 48 300 309 minecraft:spruce_planks
setblock 48 283 312 minecraft:spruce_planks
fill 48 283 316 48 300 316 minecraft:spruce_planks
fill 50 283 276 50 300 276 minecraft:spruce_planks
fill 51 283 314 55 288 314 minecraft:white_wool
setblock 51 283 316 minecraft:spruce_planks
fill 54 283 276 68 283 276 minecraft:spruce_planks
fill 55 283 277 67 285 279 minecraft:spruce_planks
fill 55 283 316 55 300 316 minecraft:spruce_planks
setblock 58 283 316 minecraft:spruce_planks
setblock 60 283 317 minecraft:white_wool
fill 62 283 316 62 300 316 minecraft:spruce_planks
fill 63 283 282 66 286 285 minecraft:dark_oak_planks
fill 63 283 317 63 308 317 minecraft:light_blue_concrete
fill 64 283 281 65 286 281 minecraft:dark_oak_planks
setblock 65 283 316 minecraft:spruce_planks
fill 69 283 316 69 300 316 minecraft:spruce_planks
fill 71 283 276 71 300 276 minecraft:spruce_planks
setblock 72 283 316 minecraft:spruce_planks
setblock 74 283 275 minecraft:light_blue_wool
fill 75 283 275 75 308 275 minecraft:light_blue_concrete
setblock 75 283 276 minecraft:spruce_planks
fill 76 283 316 76 300 316 minecraft:spruce_planks
fill 78 283 276 78 300 276 minecraft:spruce_planks
setblock 79 283 316 minecraft:spruce_planks
fill 82 283 276 82 285 276 minecraft:spruce_planks
fill 83 283 316 83 300 316 minecraft:spruce_planks
fill 85 283 276 85 300 276 minecraft:spruce_planks
fill 86 283 286 86 283 290 minecraft:white_wool
setblock 86 283 316 minecraft:spruce_planks
setblock 88 283 277 minecraft:spruce_planks
fill 88 283 280 88 300 280 minecraft:spruce_planks
setblock 88 283 284 minecraft:spruce_planks
fill 88 283 287 88 300 287 minecraft:spruce_planks
setblock 88 283 291 minecraft:spruce_planks
fill 88 283 294 88 300 294 minecraft:spruce_planks
setblock 88 283 298 minecraft:spruce_planks
fill 88 283 301 88 300 301 minecraft:spruce_planks
setblock 88 283 305 minecraft:spruce_planks
fill 88 283 308 88 300 308 minecraft:spruce_planks
fill 88 283 315 88 300 315 minecraft:spruce_planks
fill 89 283 302 89 308 303 minecraft:light_blue_concrete
setblock 47 284 277 minecraft:white_wool
setblock 48 284 278 minecraft:spruce_planks
setblock 48 284 285 minecraft:spruce_planks
setblock 48 284 292 minecraft:spruce_planks
setblock 48 284 299 minecraft:spruce_planks
setblock 48 284 306 minecraft:spruce_planks
setblock 48 284 313 minecraft:spruce_planks
setblock 50 284 278 minecraft:light[level=12]
setblock 50 284 285 minecraft:light[level=12]
setblock 50 284 292 minecraft:light[level=12]
setblock 50 284 299 minecraft:light[level=12]
setblock 50 284 306 minecraft:light[level=12]
setblock 50 284 313 minecraft:light[level=12]
setblock 52 284 316 minecraft:spruce_planks
setblock 53 284 276 minecraft:spruce_planks
fill 55 284 276 67 285 276 minecraft:spruce_planks
setblock 57 284 285 minecraft:light[level=12]
setblock 57 284 292 minecraft:light[level=12]
setblock 57 284 299 minecraft:light[level=12]
setblock 57 284 306 minecraft:light[level=12]
setblock 57 284 313 minecraft:light[level=12]
fill 57 284 317 57 308 317 minecraft:light_blue_concrete
setblock 58 284 317 minecraft:light_blue_wool
setblock 59 284 316 minecraft:spruce_planks
fill 60 284 317 60 308 317 minecraft:light_blue_concrete
fill 62 284 282 62 286 284 minecraft:dark_oak_planks
fill 63 284 281 63 286 281 minecraft:dark_oak_planks
fill 64 284 286 65 286 286 minecraft:dark_oak_planks
setblock 64 284 292 minecraft:light[level=12]
setblock 64 284 299 minecraft:light[level=12]
setblock 64 284 306 minecraft:light[level=12]
setblock 64 284 313 minecraft:light[level=12]
fill 66 284 281 66 286 281 minecraft:dark_oak_planks
setblock 66 284 316 minecraft:spruce_planks
fill 67 284 282 67 286 284 minecraft:dark_oak_planks
setblock 71 284 278 minecraft:light[level=12]
setblock 71 284 285 minecraft:light[level=12]
setblock 71 284 292 minecraft:light[level=12]
setblock 71 284 299 minecraft:light[level=12]
setblock 71 284 306 minecraft:light[level=12]
setblock 71 284 313 minecraft:light[level=12]
setblock 73 284 316 minecraft:spruce_planks
fill 74 284 275 74 288 275 minecraft:light_blue_concrete
setblock 74 284 276 minecraft:spruce_planks
setblock 75 284 317 minecraft:light_blue_wool
setblock 78 284 278 minecraft:light[level=12]
setblock 78 284 285 minecraft:light[level=12]
setblock 78 284 292 minecraft:light[level=12]
setblock 78 284 299 minecraft:light[level=12]
setblock 78 284 306 minecraft:light[level=12]
setblock 78 284 313 minecraft:light[level=12]
setblock 80 284 316 minecraft:spruce_planks
setblock 81 284 276 minecraft:spruce_planks
fill 82 284 275 82 308 275 minecraft:light_blue_concrete
fill 82 284 315 82 285 316 minecraft:spruce_planks
setblock 83 284 275 minecraft:white_wool
fill 83 284 276 84 285 276 minecraft:spruce_planks
fill 83 284 315 84 285 315 minecraft:spruce_planks
fill 84 284 275 85 308 275 minecraft:light_blue_concrete
fill 84 284 316 84 285 316 minecraft:spruce_planks
setblock 85 284 278 minecraft:light[level=12]
setblock 85 284 285 minecraft:light[level=12]
setblock 85 284 292 minecraft:light[level=12]
setblock 85 284 299 minecraft:light[level=12]
setblock 85 284 306 minecraft:light[level=12]
setblock 85 284 313 minecraft:light[level=12]
fill 86 284 285 86 285 291 minecraft:iron_bars
setblock 87 284 316 minecraft:spruce_planks
setblock 88 284 276 minecraft:spruce_planks
setblock 88 284 283 minecraft:spruce_planks
setblock 88 284 290 minecraft:spruce_planks
setblock 88 284 297 minecraft:spruce_planks
setblock 88 284 304 minecraft:spruce_planks
setblock 88 284 311 minecraft:spruce_planks
fill 47 285 277 47 308 277 minecraft:light_blue_concrete
setblock 48 285 279 minecraft:spruce_planks
setblock 48 285 286 minecraft:spruce_planks
setblock 48 285 293 minecraft:spruce_planks
setblock 48 285 300 minecraft:spruce_planks
setblock 48 285 307 minecraft:spruce_planks
setblock 48 285 314 minecraft:spruce_planks
setblock 52 285 276 minecraft:spruce_planks
setblock 53 285 316 minecraft:spruce_planks
fill 58 285 317 58 308 317 minecraft:light_blue_concrete
setblock 60 285 316 minecraft:spruce_planks
fill 62 285 285 62 286 285 minecraft:dark_oak_planks
fill 63 285 286 63 286 286 minecraft:dark_oak_planks
fill 64 285 280 65 286 280 minecraft:dark_oak_planks
fill 66 285 286 66 286 286 minecraft:dark_oak_planks
fill 67 285 285 67 286 285 minecraft:dark_oak_planks
setblock 67 285 316 minecraft:spruce_planks
setblock 73 285 276 minecraft:spruce_planks
setblock 74 285 316 minecraft:spruce_planks
fill 75 285 317 75 293 317 minecraft:light_blue_concrete
setblock 80 285 276 minecraft:spruce_planks
setblock 81 285 316 minecraft:spruce_planks
fill 82 285 277 84 286 277 minecraft:spruce_planks
fill 82 285 314 84 286 314 minecraft:spruce_planks
fill 83 285 275 83 308 275 minecraft:light_blue_concrete
fill 83 285 278 83 288 278 minecraft:spruce_planks
fill 83 285 313 83 288 313 minecraft:spruce_planks
setblock 87 285 276 minecraft:spruce_planks
setblock 88 285 282 minecraft:spruce_planks
setblock 88 285 289 minecraft:spruce_planks
setblock 88 285 296 minecraft:spruce_planks
setblock 88 285 303 minecraft:spruce_planks
setblock 88 285 310 minecraft:spruce_planks
setblock 88 285 316 minecraft:spruce_planks
fill 89 285 281 89 308 281 minecraft:light_blue_concrete
setblock 89 285 282 minecraft:light_blue_wool
fill 89 285 283 89 308 283 minecraft:light_blue_concrete
setblock 48 286 287 minecraft:spruce_planks
setblock 48 286 294 minecraft:spruce_planks
setblock 48 286 301 minecraft:spruce_planks
setblock 48 286 308 minecraft:spruce_planks
setblock 48 286 315 minecraft:spruce_planks
setblock 51 286 276 minecraft:spruce_planks
setblock 54 286 316 minecraft:spruce_planks
fill 55 286 276 55 300 276 minecraft:spruce_planks
setblock 55 286 277 minecraft:shroomlight
fill 55 286 278 55 300 278 minecraft:spruce_planks
setblock 55 286 279 minecraft:shroomlight
setblock 56 286 276 minecraft:shroomlight
fill 56 286 277 56 300 277 minecraft:spruce_planks
setblock 56 286 278 minecraft:shroomlight
fill 56 286 279 56 300 279 minecraft:spruce_planks
fill 57 286 276 57 300 276 minecraft:spruce_planks
setblock 57 286 277 minecraft:shroomlight
fill 57 286 278 57 300 278 minecraft:spruce_planks
setblock 57 286 279 minecraft:shroomlight
setblock 58 286 276 minecraft:shroomlight
fill 58 286 277 58 300 277 minecraft:spruce_planks
setblock 58 286 278 minecraft:shroomlight
fill 58 286 279 58 300 279 minecraft:spruce_planks
fill 59 286 276 59 300 276 minecraft:spruce_planks
setblock 59 286 277 minecraft:shroomlight
fill 59 286 278 59 300 278 minecraft:spruce_planks
setblock 59 286 279 minecraft:shroomlight
setblock 60 286 276 minecraft:shroomlight
fill 60 286 277 60 300 277 minecraft:spruce_planks
setblock 60 286 278 minecraft:shroomlight
fill 60 286 279 60 300 279 minecraft:spruce_planks
fill 61 286 276 61 300 276 minecraft:spruce_planks
setblock 61 286 277 minecraft:shroomlight
fill 61 286 278 61 300 278 minecraft:spruce_planks
setblock 61 286 279 minecraft:shroomlight
fill 61 286 282 61 286 284 minecraft:dark_oak_planks
setblock 61 286 316 minecraft:spruce_planks
setblock 62 286 276 minecraft:shroomlight
fill 62 286 277 62 300 277 minecraft:spruce_planks
setblock 62 286 278 minecraft:shroomlight
fill 62 286 279 62 300 279 minecraft:spruce_planks
setblock 62 286 281 minecraft:dark_oak_planks
setblock 62 286 286 minecraft:dark_oak_planks
fill 63 286 276 63 300 276 minecraft:spruce_planks
setblock 63 286 277 minecraft:shroomlight
fill 63 286 278 63 300 278 minecraft:spruce_planks
setblock 63 286 279 minecraft:shroomlight
setblock 63 286 280 minecraft:dark_oak_planks
setblock 64 286 276 minecraft:shroomlight
fill 64 286 277 64 300 277 minecraft:spruce_planks
setblock 64 286 278 minecraft:shroomlight
fill 64 286 279 64 300 279 minecraft:spruce_planks
fill 64 286 287 65 286 287 minecraft:dark_oak_planks
fill 65 286 276 65 300 276 minecraft:spruce_planks
setblock 65 286 277 minecraft:shroomlight
fill 65 286 278 65 300 278 minecraft:spruce_planks
setblock 65 286 279 minecraft:shroomlight
setblock 66 286 276 minecraft:shroomlight
fill 66 286 277 66 300 277 minecraft:spruce_planks
setblock 66 286 278 minecraft:shroomlight
fill 66 286 279 66 300 279 minecraft:spruce_planks
setblock 66 286 280 minecraft:dark_oak_planks
fill 67 286 276 67 300 276 minecraft:spruce_planks
setblock 67 286 277 minecraft:shroomlight
fill 67 286 278 67 300 278 minecraft:spruce_planks
setblock 67 286 279 minecraft:shroomlight
setblock 67 286 281 minecraft:dark_oak_planks
setblock 67 286 286 minecraft:dark_oak_planks
fill 68 286 282 68 286 284 minecraft:dark_oak_planks
setblock 68 286 316 minecraft:spruce_planks
setblock 72 286 276 minecraft:spruce_planks
setblock 75 286 316 minecraft:spruce_planks
setblock 79 286 276 minecraft:spruce_planks
fill 82 286 278 82 287 278 minecraft:spruce_planks
fill 82 286 313 82 287 313 minecraft:spruce_planks
setblock 82 286 316 minecraft:spruce_planks
setblock 83 286 276 minecraft:spruce_planks
fill 83 286 279 83 288 279 minecraft:spruce_planks
setblock 83 286 315 minecraft:spruce_planks
fill 84 286 278 84 287 278 minecraft:spruce_planks
setblock 86 286 276 minecraft:spruce_planks
setblock 88 286 281 minecraft:spruce_planks
setblock 88 286 288 minecraft:spruce_planks
setblock 88 286 295 minecraft:spruce_planks
setblock 88 286 302 minecraft:spruce_planks
setblock 88 286 309 minecraft:spruce_planks
fill 89 286 282 89 308 282 minecraft:light_blue_concrete
setblock 47 287 279 minecraft:white_wool
fill 48 287 280 56 287 280 minecraft:spruce_log
fill 55 287 277 55 288 277 minecraft:spruce_planks
fill 55 287 279 55 288 279 minecraft:spruce_planks
fill 56 287 276 56 288 276 minecraft:spruce_planks
fill 56 287 278 56 288 278 minecraft:spruce_planks
fill 57 287 277 57 288 277 minecraft:spruce_planks
fill 57 287 279 57 288 279 minecraft:spruce_planks
fill 58 287 276 58 288 276 minecraft:spruce_planks
fill 58 287 278 58 288 278 minecraft:spruce_planks
fill 59 287 277 59 288 277 minecraft:spruce_planks
fill 59 287 279 59 288 279 minecraft:spruce_planks
fill 60 287 276 60 288 276 minecraft:spruce_planks
fill 60 287 278 60 288 278 minecraft:spruce_planks
fill 61 287 277 61 288 277 minecraft:spruce_planks
fill 61 287 279 61 288 279 minecraft:spruce_planks
fill 62 287 276 62 288 276 minecraft:spruce_planks
fill 62 287 278 62 288 278 minecraft:spruce_planks
fill 63 287 277 63 288 277 minecraft:spruce_planks
fill 63 287 279 63 288 279 minecraft:spruce_planks
fill 63 287 284 63 288 284 minecraft:spruce_planks
fill 64 287 276 64 288 276 minecraft:spruce_planks
fill 64 287 278 64 288 278 minecraft:spruce_planks
fill 64 287 282 64 290 282 minecraft:spruce_planks
fill 65 287 277 65 288 277 minecraft:spruce_planks
fill 65 287 279 65 288 279 minecraft:spruce_planks
fill 66 287 276 66 288 276 minecraft:spruce_planks
fill 66 287 278 66 288 278 minecraft:spruce_planks
fill 66 287 284 66 289 284 minecraft:spruce_planks
fill 67 287 277 67 288 277 minecraft:spruce_planks
fill 67 287 279 67 288 279 minecraft:spruce_planks
fill 80 287 312 88 287 312 minecraft:spruce_log
fill 82 287 279 82 288 280 minecraft:spruce_planks
fill 82 287 311 83 288 311 minecraft:spruce_planks
setblock 83 287 276 minecraft:dark_oak_planks
setblock 83 287 277 minecraft:spruce_planks
fill 83 287 280 84 288 280 minecraft:spruce_planks
setblock 83 287 314 minecraft:spruce_planks
setblock 83 287 315 minecraft:dark_oak_planks
fill 84 287 279 84 288 279 minecraft:spruce_planks
setblock 89 287 280 minecraft:light_blue_wool
fill 47 288 279 47 308 279 minecraft:light_blue_concrete
setblock 48 288 282 minecraft:spruce_planks
setblock 48 288 289 minecraft:spruce_planks
setblock 48 288 296 minecraft:spruce_planks
setblock 48 288 303 minecraft:spruce_planks
setblock 48 288 310 minecraft:spruce_planks
setblock 49 288 276 minecraft:spruce_planks
setblock 49 288 316 minecraft:spruce_planks
fill 51 288 280 53 303 280 minecraft:spruce_log
setblock 56 288 316 minecraft:spruce_planks
setblock 63 288 316 minecraft:spruce_planks
setblock 70 288 276 minecraft:spruce_planks
setblock 70 288 316 minecraft:spruce_planks
setblock 77 288 276 minecraft:spruce_planks
setblock 77 288 316 minecraft:spruce_planks
fill 82 288 281 84 289 281 minecraft:spruce_planks
fill 82 288 310 84 289 310 minecraft:spruce_planks
setblock 82 288 312 minecraft:spruce_planks
setblock 83 288 277 minecraft:dark_oak_planks
fill 83 288 282 83 290 282 minecraft:spruce_planks
fill 83 288 309 83 290 309 minecraft:spruce_planks
fill 83 288 312 85 303 312 minecraft:spruce_log
setblock 83 288 314 minecraft:dark_oak_planks
setblock 84 288 276 minecraft:spruce_planks
setblock 84 288 316 minecraft:spruce_planks
setblock 86 288 317 minecraft:light_blue_wool
setblock 88 288 279 minecraft:spruce_planks
setblock 88 288 286 minecraft:spruce_planks
setblock 88 288 293 minecraft:spruce_planks
setblock 88 288 300 minecraft:spruce_planks
setblock 88 288 307 minecraft:spruce_planks
setblock 88 288 314 minecraft:spruce_planks
setblock 89 288 278 minecraft:light_blue_wool
fill 89 288 280 89 308 280 minecraft:light_blue_concrete
setblock 47 289 276 minecraft:light_blue_wool
fill 47 289 291 47 290 291 minecraft:white_wool
fill 48 289 276 48 290 276 minecraft:spruce_planks
fill 48 289 283 48 290 283 minecraft:spruce_planks
fill 48 289 290 48 290 290 minecraft:spruce_planks
fill 48 289 297 48 290 297 minecraft:spruce_planks
fill 48 289 304 48 290 304 minecraft:spruce_planks
fill 48 289 311 48 290 311 minecraft:spruce_planks
fill 50 289 314 56 290 314 minecraft:iron_bars
fill 50 289 316 50 290 316 minecraft:spruce_planks
setblock 55 289 277 minecraft:shroomlight
setblock 55 289 279 minecraft:shroomlight
setblock 56 289 276 minecraft:shroomlight
setblock 56 289 278 minecraft:shroomlight
setblock 57 289 277 minecraft:shroomlight
setblock 57 289 279 minecraft:shroomlight
fill 57 289 316 57 290 316 minecraft:spruce_planks
setblock 58 289 276 minecraft:shroomlight
setblock 58 289 278 minecraft:shroomlight
setblock 59 289 277 minecraft:shroomlight
setblock 59 289 279 minecraft:shroomlight
setblock 60 289 276 minecraft:shroomlight
setblock 60 289 278 minecraft:shroomlight
setblock 61 289 277 minecraft:shroomlight
setblock 61 289 279 minecraft:shroomlight
setblock 62 289 276 minecraft:shroomlight
setblock 62 289 278 minecraft:shroomlight
setblock 63 289 277 minecraft:shroomlight
setblock 63 289 279 minecraft:shroomlight
setblock 64 289 276 minecraft:shroomlight
setblock 64 289 278 minecraft:shroomlight
fill 64 289 316 64 290 316 minecraft:spruce_planks
setblock 65 289 277 minecraft:shroomlight
setblock 65 289 279 minecraft:shroomlight
setblock 66 289 276 minecraft:shroomlight
setblock 66 289 278 minecraft:shroomlight
setblock 67 289 277 minecraft:shroomlight
setblock 67 289 279 minecraft:shroomlight
fill 69 289 276 69 290 276 minecraft:spruce_planks
fill 71 289 316 71 290 316 minecraft:spruce_planks
setblock 74 289 275 minecraft:light_blue_wool
fill 76 289 276 76 290 276 minecraft:spruce_planks
fill 78 289 316 78 290 316 minecraft:spruce_planks
fill 82 289 282 82 290 282 minecraft:spruce_planks
fill 82 289 309 82 290 309 minecraft:spruce_planks
fill 83 289 276 83 290 276 minecraft:spruce_planks
setblock 83 289 279 minecraft:dark_oak_planks
setblock 83 289 280 minecraft:spruce_planks
fill 83 289 283 83 291 283 minecraft:spruce_planks
fill 83 289 308 83 291 308 minecraft:spruce_planks
setblock 83 289 311 minecraft:spruce_planks
fill 84 289 282 84 290 282 minecraft:spruce_planks
fill 84 289 309 84 290 309 minecraft:spruce_planks
fill 85 289 316 85 290 316 minecraft:spruce_planks
fill 86 289 317 86 308 317 minecraft:light_blue_concrete
fill 88 289 278 88 290 278 minecraft:spruce_planks
fill 88 289 285 88 290 285 minecraft:spruce_planks
fill 88 289 292 88 290 292 minecraft:spruce_planks
fill 88 289 299 88 290 299 minecraft:spruce_planks
fill 88 289 306 88 290 306 minecraft:spruce_planks
fill 88 289 313 88 290 313 minecraft:spruce_planks
fill 89 289 278 89 308 278 minecraft:light_blue_concrete
fill 47 290 276 47 308 276 minecraft:light_blue_concrete
fill 48 290 277 48 290 280 minecraft:spruce_planks
setblock 48 290 282 minecraft:spruce_planks
fill 48 290 284 48 290 287 minecraft:spruce_planks
setblock 48 290 289 minecraft:spruce_planks
fill 48 290 291 48 290 294 minecraft:spruce_planks
setblock 48 290 296 minecraft:spruce_planks
fill 48 290 298 48 290 301 minecraft:spruce_planks
setblock 48 290 303 minecraft:spruce_planks
fill 48 290 305 48 290 308 minecraft:spruce_planks
setblock 48 290 310 minecraft:spruce_planks
fill 48 290 312 48 290 315 minecraft:spruce_planks
fill 48 290 317 49 307 317 minecraft:light_blue_concrete
setblock 49 290 276 minecraft:spruce_planks
setblock 49 290 316 minecraft:spruce_planks
setblock 50 290 278 minecraft:light[level=15]
setblock 50 290 285 minecraft:light[level=12]
setblock 50 290 286 minecraft:light[level=15]
setblock 50 290 292 minecraft:light[level=12]
setblock 50 290 294 minecraft:light[level=15]
setblock 50 290 299 minecraft:light[level=12]
setblock 50 290 302 minecraft:light[level=15]
setblock 50 290 306 minecraft:light[level=12]
setblock 50 290 310 minecraft:light[level=15]
setblock 50 290 313 minecraft:light[level=12]
setblock 50 290 317 minecraft:light_blue_wool
fill 51 290 276 54 290 276 minecraft:spruce_planks
fill 51 290 316 54 290 316 minecraft:spruce_planks
fill 51 290 317 52 308 317 minecraft:light_blue_concrete
fill 55 290 277 55 291 277 minecraft:spruce_planks
fill 55 290 279 55 291 279 minecraft:spruce_planks
fill 56 290 276 56 291 276 minecraft:spruce_planks
fill 56 290 278 56 291 278 minecraft:spruce_planks
fill 56 290 303 56 291 303 minecraft:shroomlight
setblock 56 290 316 minecraft:spruce_planks
fill 57 290 277 57 291 277 minecraft:spruce_planks
fill 57 290 279 57 291 279 minecraft:spruce_planks
setblock 57 290 285 minecraft:light[level=12]
setblock 57 290 292 minecraft:light[level=12]
setblock 57 290 299 minecraft:light[level=12]
setblock 57 290 306 minecraft:light[level=12]
setblock 57 290 313 minecraft:light[level=12]
fill 58 290 276 58 291 276 minecraft:spruce_planks
fill 58 290 278 58 291 278 minecraft:spruce_planks
setblock 58 290 286 minecraft:light[level=15]
setblock 58 290 294 minecraft:light[level=15]
setblock 58 290 302 minecraft:light[level=15]
setblock 58 290 310 minecraft:light[level=15]
fill 58 290 316 61 290 316 minecraft:spruce_planks
fill 59 290 277 59 291 277 minecraft:spruce_planks
fill 59 290 279 59 291 279 minecraft:spruce_planks
fill 60 290 276 60 291 276 minecraft:spruce_planks
fill 60 290 278 60 291 278 minecraft:spruce_planks
fill 61 290 277 61 291 277 minecraft:spruce_planks
fill 61 290 279 61 291 279 minecraft:spruce_planks
fill 62 290 276 62 291 276 minecraft:spruce_planks
fill 62 290 278 62 291 278 minecraft:spruce_planks
fill 63 290 277 63 291 277 minecraft:spruce_planks
fill 63 290 279 63 291 279 minecraft:spruce_planks
setblock 63 290 316 minecraft:spruce_planks
fill 64 290 276 64 291 276 minecraft:spruce_planks
fill 64 290 278 64 291 278 minecraft:spruce_planks
setblock 64 290 285 minecraft:light[level=12]
setblock 64 290 292 minecraft:light[level=12]
setblock 64 290 299 minecraft:light[level=12]
setblock 64 290 306 minecraft:light[level=12]
setblock 64 290 313 minecraft:light[level=12]
fill 65 290 277 65 291 277 minecraft:spruce_planks
fill 65 290 279 65 291 279 minecraft:spruce_planks
fill 65 290 316 68 290 316 minecraft:spruce_planks
fill 66 290 275 66 308 275 minecraft:light_blue_concrete
fill 66 290 276 66 291 276 minecraft:spruce_planks
fill 66 290 278 66 291 278 minecraft:spruce_planks
setblock 66 290 286 minecraft:light[level=15]
setblock 66 290 294 minecraft:light[level=15]
setblock 66 290 302 minecraft:light[level=15]
setblock 66 290 310 minecraft:light[level=15]
setblock 67 290 275 minecraft:white_wool
fill 67 290 277 67 291 277 minecraft:spruce_planks
fill 67 290 279 67 291 279 minecraft:spruce_planks
fill 68 290 275 68 308 275 minecraft:light_blue_concrete
setblock 68 290 276 minecraft:spruce_planks
setblock 70 290 276 minecraft:spruce_planks
setblock 70 290 316 minecraft:spruce_planks
setblock 71 290 278 minecraft:light[level=12]
setblock 71 290 285 minecraft:light[level=12]
setblock 71 290 292 minecraft:light[level=12]
setblock 71 290 299 minecraft:light[level=12]
setblock 71 290 306 minecraft:light[level=12]
setblock 71 290 313 minecraft:light[level=12]
fill 72 290 276 75 290 276 minecraft:spruce_planks
fill 72 290 316 75 290 316 minecraft:spruce_planks
fill 74 290 275 74 295 275 minecraft:light_blue_concrete
setblock 74 290 278 minecraft:light[level=15]
setblock 74 290 286 minecraft:light[level=15]
setblock 74 290 294 minecraft:light[level=15]
setblock 74 290 302 minecraft:light[level=15]
setblock 74 290 310 minecraft:light[level=15]
setblock 77 290 276 minecraft:spruce_planks
setblock 77 290 316 minecraft:spruce_planks
setblock 78 290 278 minecraft:light[level=12]
setblock 78 290 285 minecraft:light[level=12]
setblock 78 290 292 minecraft:light[level=12]
setblock 78 290 299 minecraft:light[level=12]
setblock 78 290 306 minecraft:light[level=12]
setblock 78 290 313 minecraft:light[level=12]
fill 79 290 276 82 290 276 minecraft:spruce_planks
fill 79 290 316 82 290 316 minecraft:spruce_planks
setblock 82 290 278 minecraft:light[level=15]
fill 82 290 283 82 290 284 minecraft:spruce_planks
setblock 82 290 286 minecraft:light[level=15]
setblock 82 290 294 minecraft:light[level=15]
setblock 82 290 302 minecraft:light[level=15]
fill 82 290 307 82 290 308 minecraft:spruce_planks
setblock 82 290 310 minecraft:light[level=15]
setblock 83 290 280 minecraft:dark_oak_planks
setblock 83 290 281 minecraft:spruce_planks
fill 83 290 284 83 292 285 minecraft:spruce_planks
fill 83 290 306 83 292 307 minecraft:spruce_planks
setblock 83 290 310 minecraft:spruce_planks
setblock 83 290 311 minecraft:dark_oak_planks
setblock 84 290 276 minecraft:spruce_planks
fill 84 290 283 84 290 284 minecraft:spruce_planks
fill 84 290 307 84 290 308 minecraft:spruce_planks
setblock 84 290 316 minecraft:spruce_planks
setblock 85 290 278 minecraft:light[level=12]
setblock 85 290 285 minecraft:light[level=12]
setblock 85 290 292 minecraft:light[level=12]
setblock 85 290 299 minecraft:light[level=12]
setblock 85 290 306 minecraft:light[level=12]
setblock 85 290 313 minecraft:light[level=12]
fill 86 290 276 88 290 276 minecraft:spruce_planks
fill 86 290 316 88 290 316 minecraft:spruce_planks
setblock 88 290 277 minecraft:spruce_planks
schedule function dropper:buildpart/61_5 1t
