fill 24 114 279 24 122 279 minecraft:basalt
fill 24 114 289 29 114 289 minecraft:red_nether_bricks
fill 24 114 290 24 114 295 minecraft:magma_block
fill 24 114 296 29 114 297 minecraft:red_nether_bricks
fill 24 114 303 24 122 303 minecraft:basalt
setblock 24 114 313 minecraft:light[level=12]
setblock 25 114 279 minecraft:magma_block
fill 25 114 290 29 116 290 minecraft:red_nether_bricks
fill 25 114 295 30 114 295 minecraft:red_nether_bricks
setblock 25 114 303 minecraft:magma_block
fill 26 114 279 26 121 280 minecraft:basalt
setblock 26 114 301 minecraft:red_nether_bricks
fill 26 114 302 26 121 303 minecraft:basalt
fill 27 114 281 27 122 281 minecraft:basalt
fill 27 114 283 27 115 283 minecraft:red_nether_bricks
fill 27 114 301 27 122 301 minecraft:basalt
fill 27 114 308 30 114 308 minecraft:basalt
fill 28 114 282 29 121 282 minecraft:basalt
setblock 28 114 284 minecraft:nether_wart_block
fill 28 114 300 29 121 300 minecraft:basalt
fill 29 114 283 29 122 283 minecraft:basalt
fill 29 114 299 29 122 299 minecraft:basalt
fill 29 114 305 33 114 305 minecraft:basalt
fill 29 114 307 30 115 307 minecraft:basalt
fill 30 114 277 33 114 277 minecraft:basalt
fill 30 114 280 35 114 280 minecraft:basalt
fill 30 114 285 31 114 285 minecraft:basalt
setblock 30 114 286 minecraft:red_nether_bricks
setblock 30 114 287 minecraft:nether_wart_block
setblock 30 114 296 minecraft:red_nether_bricks
setblock 30 114 297 minecraft:basalt
setblock 31 114 286 minecraft:magma_block
fill 31 114 287 31 122 288 minecraft:basalt
setblock 31 114 289 minecraft:red_nether_bricks
setblock 31 114 290 minecraft:nether_wart_block
fill 31 114 294 31 122 294 minecraft:basalt
setblock 31 114 295 minecraft:magma_block
setblock 31 114 307 minecraft:magma_block
setblock 31 114 313 minecraft:light[level=12]
setblock 32 114 276 minecraft:basalt
fill 32 114 279 35 114 279 minecraft:basalt
fill 32 114 287 32 121 287 minecraft:basalt
fill 32 114 290 32 121 290 minecraft:basalt
fill 32 114 293 32 121 293 minecraft:basalt
fill 32 114 301 36 114 301 minecraft:basalt
fill 32 114 303 35 114 303 minecraft:basalt
setblock 32 114 306 minecraft:basalt
fill 35 114 281 36 114 281 minecraft:basalt
fill 35 114 284 36 115 284 minecraft:basalt
fill 35 114 299 36 115 299 minecraft:basalt
setblock 35 114 302 minecraft:basalt
fill 36 114 287 38 114 287 minecraft:basalt
fill 36 114 293 38 115 293 minecraft:basalt
fill 36 114 296 38 114 296 minecraft:basalt
setblock 37 114 284 minecraft:magma_block
setblock 37 114 299 minecraft:magma_block
setblock 38 114 278 minecraft:light[level=12]
setblock 38 114 285 minecraft:basalt
setblock 38 114 288 minecraft:basalt
setblock 38 114 294 minecraft:basalt
setblock 38 114 297 minecraft:basalt
setblock 38 114 299 minecraft:light[level=12]
setblock 38 114 306 minecraft:light[level=12]
setblock 38 114 313 minecraft:light[level=12]
fill 42 114 289 42 127 289 minecraft:cobbled_deepslate
fill 1 115 281 1 115 301 minecraft:basalt
fill 2 115 279 4 115 279 minecraft:basalt
fill 3 115 278 4 115 278 minecraft:basalt
fill 4 115 277 10 115 277 minecraft:basalt
fill 4 115 289 5 121 289 minecraft:basalt
fill 4 115 292 5 122 292 minecraft:basalt
setblock 4 115 305 minecraft:basalt
fill 5 115 290 5 123 291 minecraft:basalt
fill 5 115 293 5 121 293 minecraft:basalt
fill 6 115 286 6 123 286 minecraft:basalt
setblock 6 115 287 minecraft:magma_block
fill 6 115 295 6 123 295 minecraft:basalt
setblock 6 115 296 minecraft:magma_block
fill 6 115 307 10 115 307 minecraft:basalt
fill 7 115 284 7 123 284 minecraft:basalt
fill 7 115 298 7 123 298 minecraft:basalt
fill 8 115 283 8 123 283 minecraft:basalt
fill 8 115 299 8 123 299 minecraft:basalt
fill 9 115 282 9 123 282 minecraft:basalt
fill 9 115 300 9 123 300 minecraft:basalt
fill 9 115 309 13 115 309 minecraft:basalt
fill 10 115 281 10 122 281 minecraft:basalt
setblock 10 115 291 minecraft:nether_wart_block
fill 10 115 293 10 116 293 minecraft:red_nether_bricks
setblock 10 115 294 minecraft:nether_wart_block
fill 10 115 296 13 116 296 minecraft:red_nether_bricks
setblock 10 115 297 minecraft:nether_wart_block
fill 10 115 298 10 115 299 minecraft:red_nether_bricks
setblock 10 115 300 minecraft:nether_wart_block
fill 10 115 301 10 122 302 minecraft:basalt
fill 11 115 279 11 121 280 minecraft:basalt
setblock 11 115 288 minecraft:nether_wart_block
fill 11 115 290 11 116 290 minecraft:red_nether_bricks
fill 11 115 297 14 115 297 minecraft:red_nether_bricks
fill 11 115 302 11 121 303 minecraft:basalt
setblock 12 115 279 minecraft:magma_block
fill 12 115 287 12 116 287 minecraft:red_nether_bricks
fill 12 115 301 24 115 302 minecraft:red_nether_bricks
setblock 12 115 303 minecraft:magma_block
fill 13 115 279 14 123 279 minecraft:basalt
setblock 13 115 285 minecraft:nether_wart_block
setblock 13 115 286 minecraft:red_nether_bricks
fill 13 115 303 13 122 304 minecraft:basalt
fill 14 115 278 14 121 278 minecraft:basalt
setblock 14 115 284 minecraft:red_nether_bricks
fill 14 115 290 14 116 296 minecraft:red_terracotta
fill 14 115 303 14 123 303 minecraft:basalt
setblock 15 115 278 minecraft:magma_block
fill 15 115 289 15 116 289 minecraft:red_terracotta
setblock 15 115 297 minecraft:red_terracotta
fill 15 115 303 21 115 303 minecraft:red_nether_bricks
fill 16 115 278 20 122 278 minecraft:basalt
fill 16 115 288 16 116 288 minecraft:red_terracotta
setblock 16 115 298 minecraft:red_terracotta
fill 16 115 304 17 123 304 minecraft:basalt
setblock 16 115 311 minecraft:basalt
fill 17 115 282 19 115 282 minecraft:nether_wart_block
fill 17 115 287 17 116 287 minecraft:red_terracotta
setblock 17 115 299 minecraft:red_terracotta
setblock 17 115 300 minecraft:red_nether_bricks
fill 18 115 286 20 116 286 minecraft:red_terracotta
fill 18 115 300 20 115 300 minecraft:red_terracotta
setblock 18 115 304 minecraft:magma_block
fill 18 115 311 20 115 311 minecraft:basalt
fill 19 115 304 19 122 305 minecraft:basalt
fill 20 115 281 22 115 282 minecraft:red_nether_bricks
fill 20 115 304 20 123 304 minecraft:basalt
fill 21 115 287 22 115 287 minecraft:red_terracotta
fill 21 115 299 22 115 299 minecraft:red_terracotta
fill 21 115 300 26 115 300 minecraft:red_nether_bricks
fill 21 115 310 24 115 310 minecraft:basalt
fill 21 115 311 22 115 311 minecraft:red_nether_bricks
fill 22 115 279 23 123 279 minecraft:basalt
fill 22 115 303 22 122 304 minecraft:basalt
setblock 22 115 317 minecraft:magma_block
fill 23 115 282 25 115 282 minecraft:nether_wart_block
fill 23 115 287 29 116 287 minecraft:red_nether_bricks
fill 23 115 288 23 116 288 minecraft:red_terracotta
setblock 23 115 298 minecraft:red_terracotta
fill 23 115 299 27 115 299 minecraft:red_nether_bricks
fill 23 115 303 23 123 303 minecraft:basalt
fill 24 115 288 30 115 288 minecraft:red_nether_bricks
fill 24 115 289 24 115 291 minecraft:red_terracotta
fill 24 115 295 24 115 297 minecraft:red_terracotta
fill 24 115 298 28 115 298 minecraft:red_nether_bricks
fill 24 115 309 27 115 309 minecraft:basalt
fill 25 115 279 25 122 280 minecraft:basalt
fill 25 115 289 29 117 289 minecraft:red_nether_bricks
fill 25 115 291 29 115 291 minecraft:red_nether_bricks
fill 25 115 292 25 116 294 minecraft:red_terracotta
fill 25 115 295 29 115 297 minecraft:red_nether_bricks
setblock 25 115 301 minecraft:red_nether_bricks
fill 25 115 302 25 122 303 minecraft:basalt
setblock 25 115 310 minecraft:red_nether_bricks
fill 26 115 281 26 123 281 minecraft:basalt
fill 26 115 292 29 116 294 minecraft:red_nether_bricks
fill 26 115 301 26 123 301 minecraft:basalt
fill 27 115 278 32 116 278 minecraft:basalt
fill 27 115 282 27 123 282 minecraft:basalt
fill 27 115 300 27 123 300 minecraft:basalt
fill 27 115 308 28 115 308 minecraft:basalt
fill 28 115 283 28 123 283 minecraft:basalt
setblock 28 115 284 minecraft:red_nether_bricks
fill 28 115 299 28 122 299 minecraft:basalt
fill 29 115 284 29 123 284 minecraft:basalt
setblock 29 115 285 minecraft:nether_wart_block
setblock 29 115 286 minecraft:red_nether_bricks
fill 29 115 298 29 123 298 minecraft:basalt
fill 29 115 305 32 115 305 minecraft:basalt
fill 30 115 277 32 115 277 minecraft:basalt
fill 30 115 280 34 115 280 minecraft:basalt
setblock 30 115 285 minecraft:magma_block
fill 30 115 286 30 123 287 minecraft:basalt
fill 30 115 295 30 123 296 minecraft:basalt
setblock 30 115 297 minecraft:magma_block
fill 30 115 304 33 115 304 minecraft:basalt
fill 31 115 285 31 121 286 minecraft:basalt
fill 31 115 289 31 122 293 minecraft:basalt
fill 31 115 295 31 122 295 minecraft:basalt
fill 32 115 279 34 115 279 minecraft:basalt
fill 32 115 282 35 115 283 minecraft:basalt
fill 32 115 300 35 115 301 minecraft:basalt
fill 32 115 303 34 115 303 minecraft:basalt
setblock 33 115 275 minecraft:crying_obsidian
setblock 33 115 278 minecraft:magma_block
setblock 35 115 281 minecraft:basalt
fill 35 115 297 35 117 298 minecraft:basalt
setblock 36 115 282 minecraft:basalt
setblock 36 115 283 minecraft:magma_block
fill 36 115 287 37 115 287 minecraft:basalt
fill 36 115 290 38 115 290 minecraft:basalt
fill 36 115 296 37 115 297 minecraft:basalt
setblock 36 115 298 minecraft:magma_block
setblock 36 115 300 minecraft:basalt
setblock 38 115 291 minecraft:basalt
fill 1 116 282 1 116 300 minecraft:basalt
setblock 2 116 281 minecraft:magma_block
fill 2 116 282 4 117 282 minecraft:basalt
fill 3 116 279 4 116 279 minecraft:basalt
fill 3 116 281 4 117 281 minecraft:basalt
fill 3 116 302 4 116 303 minecraft:basalt
setblock 4 116 278 minecraft:basalt
fill 4 116 304 9 116 304 minecraft:basalt
setblock 5 116 277 minecraft:magma_block
fill 6 116 277 10 116 277 minecraft:basalt
fill 6 116 287 6 123 294 minecraft:basalt
fill 6 116 296 7 116 296 minecraft:basalt
fill 7 116 285 7 122 286 minecraft:basalt
fill 7 116 297 7 122 297 minecraft:basalt
fill 8 116 284 8 124 284 minecraft:basalt
fill 8 116 298 8 124 298 minecraft:basalt
fill 8 116 307 10 116 307 minecraft:basalt
fill 9 116 283 9 123 283 minecraft:basalt
fill 9 116 299 9 124 299 minecraft:basalt
fill 9 116 308 10 116 308 minecraft:basalt
fill 10 116 282 10 124 282 minecraft:basalt
setblock 10 116 292 minecraft:nether_wart_block
fill 10 116 294 10 117 294 minecraft:red_nether_bricks
setblock 10 116 295 minecraft:nether_wart_block
fill 10 116 297 13 117 297 minecraft:red_nether_bricks
setblock 10 116 298 minecraft:nether_wart_block
fill 10 116 299 15 116 299 minecraft:red_nether_bricks
fill 10 116 300 10 124 300 minecraft:basalt
setblock 11 116 281 minecraft:magma_block
setblock 11 116 289 minecraft:nether_wart_block
fill 11 116 300 16 116 300 minecraft:red_nether_bricks
fill 11 116 301 11 124 301 minecraft:basalt
setblock 11 116 308 minecraft:magma_block
fill 12 116 279 12 122 280 minecraft:basalt
fill 12 116 298 14 117 298 minecraft:red_nether_bricks
fill 12 116 301 18 116 301 minecraft:red_nether_bricks
fill 12 116 302 12 122 303 minecraft:basalt
fill 12 116 308 13 116 309 minecraft:basalt
fill 13 116 280 13 124 280 minecraft:basalt
setblock 13 116 286 minecraft:nether_wart_block
fill 13 116 302 13 124 302 minecraft:basalt
setblock 14 116 297 minecraft:red_terracotta
fill 14 116 302 18 116 302 minecraft:red_nether_bricks
fill 14 116 308 16 118 308 minecraft:basalt
fill 15 116 278 15 122 279 minecraft:basalt
setblock 15 116 298 minecraft:red_terracotta
fill 15 116 303 16 123 303 minecraft:basalt
fill 15 116 310 19 116 310 minecraft:basalt
fill 16 116 279 16 124 279 minecraft:basalt
setblock 16 116 283 minecraft:nether_wart_block
setblock 16 116 299 minecraft:red_terracotta
setblock 17 116 279 minecraft:magma_block
fill 17 116 282 25 116 282 minecraft:red_nether_bricks
setblock 17 116 300 minecraft:red_terracotta
setblock 17 116 303 minecraft:magma_block
fill 18 116 279 21 123 279 minecraft:basalt
fill 18 116 293 18 116 295 minecraft:quartz_block
fill 18 116 297 18 116 300 minecraft:quartz_block
fill 18 116 303 18 123 304 minecraft:basalt
fill 19 116 290 20 116 290 minecraft:quartz_block
fill 19 116 301 20 116 301 minecraft:red_terracotta
fill 19 116 302 20 116 302 minecraft:quartz_block
fill 19 116 303 21 123 303 minecraft:basalt
setblock 21 116 286 minecraft:red_terracotta
fill 21 116 300 22 116 300 minecraft:red_terracotta
fill 21 116 301 21 116 302 minecraft:red_nether_bricks
setblock 21 116 310 minecraft:basalt
fill 22 116 286 27 117 286 minecraft:red_nether_bricks
setblock 22 116 287 minecraft:red_terracotta
fill 22 116 290 23 116 290 minecraft:quartz_block
fill 22 116 301 24 116 301 minecraft:red_nether_bricks
setblock 22 116 302 minecraft:quartz_block
fill 22 116 310 25 116 310 minecraft:nether_wart_block
fill 22 116 317 22 129 317 minecraft:cobbled_deepslate
setblock 23 116 280 minecraft:magma_block
setblock 23 116 299 minecraft:red_terracotta
setblock 23 116 300 minecraft:red_nether_bricks
fill 23 116 302 24 123 302 minecraft:basalt
fill 24 116 276 30 116 276 minecraft:basalt
fill 24 116 280 24 123 280 minecraft:basalt
fill 24 116 288 29 116 288 minecraft:red_nether_bricks
fill 24 116 289 24 116 290 minecraft:red_terracotta
fill 24 116 292 24 116 295 minecraft:quartz_block
fill 24 116 297 24 116 300 minecraft:quartz_block
fill 24 116 306 30 116 306 minecraft:basalt
setblock 24 116 309 minecraft:basalt
fill 25 116 281 25 124 281 minecraft:basalt
setblock 25 116 291 minecraft:red_terracotta
fill 25 116 295 25 116 296 minecraft:red_terracotta
fill 25 116 297 25 116 300 minecraft:red_nether_bricks
fill 25 116 301 25 124 301 minecraft:basalt
fill 25 116 309 26 117 309 minecraft:red_nether_bricks
setblock 26 116 282 minecraft:magma_block
setblock 26 116 283 minecraft:nether_wart_block
fill 26 116 291 29 117 291 minecraft:red_nether_bricks
fill 26 116 295 26 116 299 minecraft:red_nether_bricks
setblock 26 116 300 minecraft:magma_block
fill 27 116 283 27 123 283 minecraft:basalt
fill 27 116 295 27 116 298 minecraft:red_nether_bricks
fill 27 116 299 27 124 299 minecraft:basalt
setblock 27 116 308 minecraft:basalt
fill 28 116 284 28 124 284 minecraft:basalt
fill 28 116 295 28 116 297 minecraft:red_nether_bricks
fill 28 116 298 28 124 298 minecraft:basalt
fill 29 116 285 29 123 286 minecraft:basalt
setblock 29 116 295 minecraft:red_nether_bricks
setblock 29 116 296 minecraft:magma_block
fill 29 116 297 30 122 297 minecraft:basalt
fill 29 116 305 31 116 305 minecraft:basalt
fill 30 116 277 31 116 277 minecraft:basalt
fill 30 116 280 33 116 280 minecraft:basalt
fill 30 116 285 30 122 285 minecraft:basalt
fill 30 116 288 30 123 294 minecraft:basalt
fill 30 116 302 33 116 302 minecraft:basalt
fill 30 116 304 31 117 304 minecraft:basalt
fill 32 116 279 33 116 279 minecraft:basalt
fill 32 116 282 34 117 283 minecraft:basalt
fill 32 116 300 34 116 301 minecraft:basalt
fill 32 116 303 33 116 303 minecraft:basalt
setblock 32 116 304 minecraft:magma_block
fill 33 116 275 33 129 275 minecraft:cobbled_deepslate
setblock 35 116 282 minecraft:magma_block
fill 35 116 283 35 116 286 minecraft:basalt
fill 35 116 294 36 116 295 minecraft:basalt
setblock 35 116 299 minecraft:basalt
setblock 35 116 300 minecraft:magma_block
fill 36 116 285 36 116 287 minecraft:basalt
fill 36 116 290 37 116 290 minecraft:basalt
fill 36 116 293 37 116 293 minecraft:basalt
fill 36 116 296 36 116 297 minecraft:basalt
setblock 37 116 294 minecraft:basalt
setblock 42 116 304 minecraft:crying_obsidian
fill 1 117 284 1 117 285 minecraft:basalt
setblock 1 117 286 minecraft:magma_block
fill 1 117 287 1 118 294 minecraft:basalt
setblock 1 117 295 minecraft:magma_block
fill 1 117 296 1 117 297 minecraft:basalt
setblock 1 117 298 minecraft:magma_block
fill 4 117 280 6 117 280 minecraft:basalt
setblock 4 117 302 minecraft:basalt
fill 5 117 304 9 117 304 minecraft:basalt
fill 6 117 296 6 123 296 minecraft:basalt
fill 7 117 277 10 117 277 minecraft:basalt
setblock 7 117 287 minecraft:magma_block
fill 7 117 288 7 125 288 minecraft:basalt
fill 7 117 294 7 124 295 minecraft:basalt
setblock 7 117 296 minecraft:magma_block
setblock 7 117 305 minecraft:magma_block
fill 8 117 276 13 117 276 minecraft:basalt
fill 8 117 285 8 124 285 minecraft:basalt
fill 8 117 297 8 124 297 minecraft:basalt
fill 8 117 306 13 117 306 minecraft:basalt
fill 9 117 284 9 125 284 minecraft:basalt
fill 9 117 298 9 125 298 minecraft:basalt
setblock 9 117 307 minecraft:basalt
setblock 10 117 283 minecraft:magma_block
setblock 10 117 293 minecraft:nether_wart_block
setblock 10 117 295 minecraft:red_nether_bricks
setblock 10 117 296 minecraft:nether_wart_block
setblock 10 117 298 minecraft:red_nether_bricks
fill 10 117 299 10 125 299 minecraft:basalt
setblock 10 117 307 minecraft:magma_block
fill 11 117 281 11 124 282 minecraft:basalt
setblock 11 117 290 minecraft:nether_wart_block
fill 11 117 296 13 119 296 minecraft:red_nether_bricks
fill 11 117 299 14 118 299 minecraft:red_nether_bricks
fill 11 117 300 11 125 300 minecraft:basalt
fill 11 117 308 13 117 308 minecraft:basalt
fill 12 117 281 12 124 281 minecraft:basalt
fill 12 117 300 15 117 300 minecraft:red_nether_bricks
fill 12 117 301 12 124 301 minecraft:basalt
setblock 13 117 286 minecraft:red_nether_bricks
setblock 13 117 287 minecraft:nether_wart_block
fill 13 117 301 16 117 301 minecraft:red_nether_bricks
fill 14 117 280 15 117 280 minecraft:basalt
fill 14 117 287 16 119 287 minecraft:red_nether_bricks
fill 14 117 290 14 117 297 minecraft:magma_block
fill 14 117 302 15 123 302 minecraft:basalt
setblock 15 117 284 minecraft:nether_wart_block
setblock 15 117 289 minecraft:magma_block
fill 15 117 298 15 117 299 minecraft:magma_block
fill 15 117 309 21 117 309 minecraft:basalt
fill 16 117 275 16 129 275 minecraft:cobbled_deepslate
setblock 16 117 283 minecraft:red_nether_bricks
setblock 16 117 288 minecraft:magma_block
fill 16 117 295 17 118 295 minecraft:quartz_block
fill 16 117 297 17 118 297 minecraft:quartz_block
setblock 16 117 300 minecraft:magma_block
fill 16 117 302 18 117 302 minecraft:red_nether_bricks
setblock 17 117 275 minecraft:purple_concrete
fill 17 117 279 17 124 279 minecraft:basalt
setblock 17 117 287 minecraft:magma_block
fill 17 117 291 17 118 293 minecraft:quartz_block
fill 17 117 299 17 118 301 minecraft:quartz_block
fill 17 117 303 17 124 303 minecraft:basalt
fill 18 117 282 24 117 282 minecraft:red_nether_bricks
fill 18 117 286 21 117 286 minecraft:magma_block
setblock 18 117 293 minecraft:quartz_block
setblock 18 117 299 minecraft:quartz_block
fill 18 117 301 18 118 301 minecraft:quartz_block
fill 18 117 308 24 117 308 minecraft:basalt
fill 18 117 310 24 117 310 minecraft:red_nether_bricks
fill 19 117 289 19 118 290 minecraft:quartz_block
fill 19 117 301 22 117 301 minecraft:magma_block
setblock 19 117 302 minecraft:quartz_block
fill 20 117 288 20 118 289 minecraft:quartz_block
setblock 20 117 302 minecraft:red_nether_bricks
fill 21 117 280 23 124 280 minecraft:basalt
fill 21 117 302 22 117 302 minecraft:basalt
fill 21 117 307 27 117 307 minecraft:basalt
fill 22 117 287 23 117 287 minecraft:magma_block
fill 22 117 288 22 118 289 minecraft:quartz_block
fill 22 117 309 24 117 309 minecraft:red_nether_bricks
fill 23 117 289 23 118 290 minecraft:quartz_block
setblock 23 117 300 minecraft:magma_block
setblock 23 117 301 minecraft:red_nether_bricks
fill 24 117 276 28 117 276 minecraft:basalt
fill 24 117 281 24 123 281 minecraft:basalt
fill 24 117 287 28 117 287 minecraft:red_nether_bricks
fill 24 117 288 24 117 289 minecraft:magma_block
fill 24 117 291 25 118 291 minecraft:quartz_block
fill 24 117 293 25 117 293 minecraft:quartz_block
fill 24 117 299 25 117 299 minecraft:quartz_block
setblock 24 117 300 minecraft:red_nether_bricks
fill 24 117 301 24 124 301 minecraft:basalt
fill 24 117 306 28 117 306 minecraft:basalt
fill 25 117 282 26 124 282 minecraft:basalt
fill 25 117 288 28 118 288 minecraft:red_nether_bricks
setblock 25 117 290 minecraft:magma_block
fill 25 117 292 25 119 292 minecraft:quartz_block
fill 25 117 295 26 118 295 minecraft:quartz_block
setblock 25 117 296 minecraft:magma_block
fill 25 117 297 26 118 297 minecraft:quartz_block
setblock 25 117 298 minecraft:magma_block
fill 25 117 300 26 124 300 minecraft:basalt
setblock 25 117 308 minecraft:magma_block
fill 26 117 283 26 125 283 minecraft:basalt
fill 26 117 290 29 117 290 minecraft:red_nether_bricks
fill 26 117 292 29 117 292 minecraft:red_nether_bricks
fill 26 117 293 26 117 294 minecraft:magma_block
fill 26 117 296 28 117 296 minecraft:red_nether_bricks
setblock 26 117 298 minecraft:red_nether_bricks
fill 26 117 299 26 125 299 minecraft:basalt
fill 26 117 308 26 118 308 minecraft:red_nether_bricks
fill 27 117 278 31 117 278 minecraft:basalt
fill 27 117 284 27 125 284 minecraft:basalt
fill 27 117 293 28 117 295 minecraft:red_nether_bricks
setblock 27 117 297 minecraft:red_nether_bricks
fill 27 117 298 27 125 298 minecraft:basalt
setblock 27 117 308 minecraft:nether_wart_block
fill 28 117 285 28 124 285 minecraft:basalt
fill 28 117 297 28 124 297 minecraft:basalt
setblock 28 117 307 minecraft:red_nether_bricks
fill 29 117 279 30 118 279 minecraft:basalt
fill 29 117 287 29 124 288 minecraft:basalt
setblock 29 117 293 minecraft:red_nether_bricks
fill 29 117 294 29 124 296 minecraft:basalt
fill 29 117 303 30 118 303 minecraft:basalt
setblock 29 117 305 minecraft:basalt
setblock 29 117 306 minecraft:red_nether_bricks
fill 30 117 280 32 117 280 minecraft:basalt
fill 30 117 302 32 117 302 minecraft:basalt
setblock 31 117 279 minecraft:magma_block
setblock 31 117 303 minecraft:magma_block
fill 32 117 281 33 117 281 minecraft:basalt
fill 32 117 299 33 117 301 minecraft:basalt
setblock 34 117 299 minecraft:magma_block
setblock 34 117 300 minecraft:basalt
fill 35 117 284 35 117 286 minecraft:basalt
fill 35 117 288 36 117 289 minecraft:basalt
fill 35 117 291 36 117 292 minecraft:basalt
fill 35 117 294 35 118 295 minecraft:basalt
setblock 36 117 290 minecraft:basalt
fill 36 117 293 36 117 294 minecraft:basalt
fill 42 117 304 42 129 304 minecraft:cobbled_deepslate
setblock 1 118 295 minecraft:basalt
fill 3 118 282 4 118 282 minecraft:basalt
setblock 3 118 299 minecraft:magma_block
fill 3 118 300 4 118 300 minecraft:basalt
setblock 4 118 281 minecraft:basalt
fill 4 118 299 4 119 299 minecraft:basalt
fill 4 118 301 5 118 301 minecraft:basalt
fill 5 118 280 6 118 280 minecraft:basalt
setblock 7 118 278 minecraft:basalt
fill 7 118 287 8 118 287 minecraft:basalt
fill 7 118 289 7 125 293 minecraft:basalt
fill 7 118 296 8 124 296 minecraft:basalt
fill 7 118 304 9 118 304 minecraft:basalt
fill 8 118 277 10 118 277 minecraft:basalt
fill 8 118 286 8 125 286 minecraft:basalt
fill 8 118 295 8 125 295 minecraft:basalt
setblock 9 118 276 minecraft:magma_block
setblock 9 118 285 minecraft:magma_block
setblock 9 118 297 minecraft:magma_block
setblock 9 118 306 minecraft:magma_block
fill 10 118 276 13 118 276 minecraft:basalt
fill 10 118 283 10 125 283 minecraft:basalt
fill 10 118 306 13 118 306 minecraft:basalt
setblock 11 118 291 minecraft:nether_wart_block
setblock 11 118 294 minecraft:nether_wart_block
fill 11 118 295 13 118 295 minecraft:red_nether_bricks
setblock 11 118 297 minecraft:nether_wart_block
fill 12 118 282 12 125 282 minecraft:basalt
fill 12 118 294 13 118 294 minecraft:red_nether_bricks
fill 12 118 297 13 120 298 minecraft:red_nether_bricks
fill 12 118 300 12 125 300 minecraft:basalt
fill 13 118 281 14 125 281 minecraft:basalt
setblock 13 118 287 minecraft:red_nether_bricks
setblock 13 118 288 minecraft:nether_wart_block
fill 13 118 300 15 118 300 minecraft:red_nether_bricks
fill 13 118 301 14 124 301 minecraft:basalt
fill 14 118 280 14 124 280 minecraft:basalt
fill 14 118 288 14 120 288 minecraft:red_nether_bricks
fill 14 118 290 14 118 298 minecraft:red_terracotta
setblock 15 118 280 minecraft:magma_block
setblock 15 118 285 minecraft:nether_wart_block
fill 15 118 289 15 119 289 minecraft:red_terracotta
fill 15 118 299 15 119 299 minecraft:red_terracotta
fill 15 118 301 16 118 301 minecraft:red_nether_bricks
fill 16 118 280 20 125 280 minecraft:basalt
fill 16 118 285 26 118 285 minecraft:red_nether_bricks
fill 16 118 288 16 119 288 minecraft:red_terracotta
fill 16 118 292 16 119 294 minecraft:quartz_block
fill 16 118 298 16 119 300 minecraft:quartz_block
fill 16 118 302 20 118 302 minecraft:basalt
fill 17 118 275 17 129 275 minecraft:cobbled_deepslate
fill 17 118 287 17 119 287 minecraft:red_terracotta
fill 17 118 290 18 119 290 minecraft:quartz_block
fill 17 118 309 20 118 309 minecraft:nether_wart_block
fill 18 118 286 22 118 286 minecraft:red_terracotta
fill 18 118 288 18 119 289 minecraft:quartz_block
fill 18 118 308 20 118 308 minecraft:basalt
fill 19 118 288 19 119 288 minecraft:quartz_block
fill 20 118 287 20 119 287 minecraft:quartz_block
setblock 21 118 282 minecraft:nether_wart_block
fill 21 118 288 21 119 288 minecraft:quartz_block
setblock 21 118 302 minecraft:magma_block
fill 21 118 307 23 118 307 minecraft:basalt
setblock 21 118 308 minecraft:magma_block
fill 21 118 309 21 118 310 minecraft:red_nether_bricks
fill 22 118 281 23 125 281 minecraft:basalt
fill 22 118 287 22 119 287 minecraft:quartz_block
fill 22 118 301 22 124 302 minecraft:basalt
setblock 22 118 308 minecraft:basalt
fill 22 118 309 25 118 309 minecraft:nether_wart_block
fill 23 118 286 27 118 286 minecraft:red_nether_bricks
fill 23 118 287 23 119 287 minecraft:red_terracotta
fill 23 118 288 24 119 288 minecraft:quartz_block
fill 23 118 301 23 124 301 minecraft:basalt
fill 23 118 308 25 119 308 minecraft:red_nether_bricks
fill 24 118 276 26 118 276 minecraft:basalt
fill 24 118 282 24 125 282 minecraft:basalt
fill 24 118 287 27 119 287 minecraft:red_nether_bricks
fill 24 118 289 24 119 290 minecraft:quartz_block
fill 24 118 300 24 125 300 minecraft:basalt
fill 24 118 306 26 118 306 minecraft:basalt
setblock 24 118 307 minecraft:magma_block
setblock 25 118 289 minecraft:red_terracotta
fill 25 118 290 25 119 290 minecraft:quartz_block
fill 25 118 293 26 118 293 minecraft:quartz_block
setblock 25 118 298 minecraft:red_terracotta
setblock 25 118 299 minecraft:quartz_block
setblock 25 118 307 minecraft:basalt
fill 26 118 289 28 118 290 minecraft:red_nether_bricks
setblock 26 118 291 minecraft:red_terracotta
fill 26 118 292 26 119 292 minecraft:quartz_block
fill 26 118 294 26 119 294 minecraft:quartz_block
fill 26 118 296 26 119 296 minecraft:red_terracotta
setblock 26 118 298 minecraft:quartz_block
fill 26 118 307 27 118 307 minecraft:red_nether_bricks
setblock 27 118 276 minecraft:magma_block
fill 27 118 278 29 118 278 minecraft:basalt
setblock 27 118 285 minecraft:magma_block
fill 27 118 291 27 118 296 minecraft:red_nether_bricks
setblock 27 118 297 minecraft:magma_block
setblock 27 118 306 minecraft:magma_block
fill 28 118 286 28 125 287 minecraft:basalt
fill 28 118 291 28 118 294 minecraft:red_nether_bricks
fill 28 118 295 28 125 296 minecraft:basalt
setblock 28 118 306 minecraft:nether_wart_block
fill 29 118 289 29 118 293 minecraft:basalt
setblock 29 118 305 minecraft:red_nether_bricks
fill 30 118 280 31 118 280 minecraft:basalt
fill 30 118 302 31 118 302 minecraft:basalt
fill 32 118 281 32 118 283 minecraft:basalt
fill 32 118 299 32 118 301 minecraft:basalt
setblock 33 118 282 minecraft:basalt
setblock 33 118 283 minecraft:magma_block
fill 33 118 299 33 118 300 minecraft:basalt
fill 35 118 288 35 118 289 minecraft:basalt
fill 35 118 291 35 118 292 minecraft:basalt
fill 0 119 280 0 125 287 minecraft:cobbled_deepslate
setblock 0 119 288 minecraft:purple_concrete
fill 0 119 289 0 120 289 minecraft:cobbled_deepslate
fill 0 119 309 0 126 312 minecraft:cobbled_deepslate
setblock 0 119 313 minecraft:crying_obsidian
setblock 2 119 289 minecraft:magma_block
setblock 2 119 292 minecraft:magma_block
setblock 2 119 295 minecraft:magma_block
fill 3 119 284 3 119 285 minecraft:basalt
fill 3 119 295 3 119 297 minecraft:basalt
fill 4 119 282 4 119 283 minecraft:basalt
setblock 4 119 300 minecraft:basalt
setblock 5 119 301 minecraft:basalt
setblock 6 119 280 minecraft:basalt
setblock 6 119 302 minecraft:basalt
fill 7 119 279 8 119 279 minecraft:basalt
fill 7 119 287 7 124 287 minecraft:basalt
setblock 7 119 303 minecraft:basalt
setblock 8 119 278 minecraft:magma_block
setblock 8 119 287 minecraft:magma_block
fill 8 119 288 8 124 289 minecraft:basalt
setblock 8 119 293 minecraft:magma_block
fill 8 119 294 8 124 294 minecraft:basalt
fill 8 119 304 9 119 304 minecraft:basalt
fill 9 119 277 10 119 277 minecraft:basalt
fill 9 119 285 9 125 286 minecraft:basalt
fill 9 119 296 9 125 297 minecraft:basalt
fill 10 119 284 10 125 284 minecraft:basalt
fill 10 119 298 10 125 298 minecraft:basalt
fill 11 119 276 13 119 276 minecraft:basalt
setblock 11 119 283 minecraft:magma_block
fill 11 119 293 12 119 294 minecraft:red_nether_bricks
setblock 11 119 295 minecraft:nether_wart_block
setblock 11 119 297 minecraft:red_nether_bricks
setblock 11 119 298 minecraft:nether_wart_block
fill 11 119 299 11 124 299 minecraft:basalt
fill 11 119 306 13 119 306 minecraft:basalt
setblock 12 119 292 minecraft:nether_wart_block
fill 12 119 295 12 121 295 minecraft:red_nether_bricks
fill 12 119 299 14 119 299 minecraft:red_nether_bricks
fill 13 119 282 13 125 282 minecraft:basalt
setblock 13 119 288 minecraft:red_nether_bricks
setblock 13 119 289 minecraft:nether_wart_block
fill 13 119 292 13 119 293 minecraft:red_nether_bricks
fill 13 119 294 13 119 295 minecraft:red_terracotta
fill 13 119 300 13 125 300 minecraft:basalt
fill 14 119 290 14 119 293 minecraft:red_terracotta
fill 14 119 296 14 119 298 minecraft:red_terracotta
setblock 14 119 300 minecraft:red_nether_bricks
fill 14 119 307 19 119 307 minecraft:basalt
fill 15 119 280 15 125 281 minecraft:basalt
setblock 15 119 286 minecraft:nether_wart_block
setblock 15 119 292 minecraft:quartz_block
fill 15 119 294 15 119 295 minecraft:quartz_block
fill 15 119 297 15 119 298 minecraft:quartz_block
setblock 15 119 300 minecraft:quartz_block
fill 15 119 301 16 119 301 minecraft:basalt
fill 16 119 281 16 125 281 minecraft:basalt
fill 16 119 285 17 119 286 minecraft:red_nether_bricks
fill 16 119 290 16 119 291 minecraft:quartz_block
setblock 16 119 295 minecraft:quartz_block
setblock 16 119 297 minecraft:quartz_block
fill 16 119 302 16 125 302 minecraft:basalt
setblock 17 119 289 minecraft:quartz_block
setblock 17 119 292 minecraft:quartz_block
setblock 17 119 300 minecraft:quartz_block
setblock 17 119 302 minecraft:magma_block
fill 17 119 308 22 119 308 minecraft:red_nether_bricks
fill 18 119 285 19 119 285 minecraft:red_nether_bricks
fill 18 119 286 19 119 286 minecraft:red_terracotta
fill 18 119 302 21 124 302 minecraft:basalt
fill 19 119 283 23 119 283 minecraft:nether_wart_block
setblock 19 119 289 minecraft:quartz_block
fill 19 119 309 23 119 309 minecraft:red_nether_bricks
fill 20 119 276 22 120 276 minecraft:basalt
fill 20 119 281 21 124 281 minecraft:basalt
setblock 20 119 285 minecraft:red_terracotta
setblock 20 119 288 minecraft:quartz_block
setblock 20 119 301 minecraft:magma_block
fill 20 119 306 22 120 306 minecraft:basalt
setblock 20 119 307 minecraft:magma_block
fill 21 119 285 26 119 285 minecraft:red_nether_bricks
fill 21 119 286 22 119 286 minecraft:red_terracotta
setblock 21 119 287 minecraft:quartz_block
fill 21 119 301 21 125 301 minecraft:basalt
fill 21 119 307 22 119 307 minecraft:basalt
setblock 22 119 288 minecraft:quartz_block
setblock 23 119 276 minecraft:magma_block
setblock 23 119 282 minecraft:magma_block
fill 23 119 286 26 119 286 minecraft:red_nether_bricks
setblock 23 119 289 minecraft:quartz_block
setblock 23 119 300 minecraft:magma_block
setblock 23 119 306 minecraft:magma_block
fill 23 119 307 25 120 307 minecraft:red_nether_bricks
fill 24 119 276 25 119 276 minecraft:basalt
fill 24 119 305 25 119 306 minecraft:basalt
fill 25 119 283 25 125 283 minecraft:basalt
fill 25 119 288 27 119 288 minecraft:red_nether_bricks
setblock 25 119 289 minecraft:quartz_block
fill 25 119 299 25 125 299 minecraft:basalt
fill 26 119 277 27 119 277 minecraft:basalt
setblock 26 119 284 minecraft:magma_block
fill 26 119 289 27 119 289 minecraft:red_nether_bricks
fill 26 119 290 26 119 291 minecraft:quartz_block
setblock 26 119 293 minecraft:quartz_block
fill 26 119 295 27 119 295 minecraft:quartz_block
setblock 26 119 297 minecraft:quartz_block
fill 26 119 298 26 125 298 minecraft:basalt
setblock 26 119 305 minecraft:magma_block
fill 26 119 306 27 120 306 minecraft:red_nether_bricks
setblock 26 119 307 minecraft:nether_wart_block
fill 27 119 278 28 119 278 minecraft:basalt
fill 27 119 285 27 125 286 minecraft:basalt
fill 27 119 290 28 119 291 minecraft:red_nether_bricks
setblock 27 119 292 minecraft:quartz_block
setblock 27 119 293 minecraft:red_nether_bricks
setblock 27 119 294 minecraft:quartz_block
fill 27 119 296 27 125 297 minecraft:basalt
fill 27 119 304 27 119 305 minecraft:basalt
fill 28 119 288 28 125 289 minecraft:basalt
setblock 28 119 292 minecraft:red_nether_bricks
fill 28 119 293 28 125 294 minecraft:basalt
setblock 28 119 304 minecraft:basalt
setblock 28 119 305 minecraft:red_nether_bricks
setblock 29 119 279 minecraft:basalt
fill 29 119 289 29 124 291 minecraft:basalt
setblock 29 119 292 minecraft:magma_block
fill 29 119 293 29 124 293 minecraft:basalt
setblock 29 119 303 minecraft:basalt
setblock 29 119 304 minecraft:nether_wart_block
setblock 30 119 280 minecraft:basalt
setblock 30 119 302 minecraft:basalt
setblock 32 119 282 minecraft:magma_block
setblock 32 119 283 minecraft:basalt
setblock 32 119 299 minecraft:basalt
setblock 32 119 300 minecraft:magma_block
fill 33 119 284 33 119 286 minecraft:basalt
fill 33 119 296 33 119 298 minecraft:basalt
setblock 42 119 316 minecraft:amethyst_block
fill 0 120 288 0 129 288 minecraft:cobbled_deepslate
fill 0 120 313 0 127 313 minecraft:cobbled_deepslate
setblock 3 120 278 minecraft:light[level=12]
setblock 3 120 285 minecraft:light[level=12]
fill 3 120 295 3 120 296 minecraft:basalt
setblock 3 120 299 minecraft:light[level=12]
setblock 3 120 302 minecraft:light[level=12]
setblock 3 120 306 minecraft:light[level=12]
setblock 3 120 310 minecraft:light[level=12]
setblock 3 120 313 minecraft:light[level=12]
setblock 4 120 284 minecraft:magma_block
fill 5 120 284 5 121 284 minecraft:basalt
setblock 7 120 280 minecraft:magma_block
fill 7 120 281 7 121 281 minecraft:basalt
setblock 8 120 279 minecraft:basalt
fill 8 120 287 9 125 287 minecraft:basalt
fill 8 120 290 8 124 293 minecraft:basalt
fill 9 120 288 9 125 288 minecraft:basalt
fill 9 120 294 9 125 295 minecraft:basalt
setblock 9 120 304 minecraft:basalt
setblock 10 120 285 minecraft:magma_block
setblock 10 120 292 minecraft:light[level=12]
setblock 10 120 297 minecraft:magma_block
setblock 10 120 306 minecraft:light[level=12]
setblock 10 120 313 minecraft:light[level=12]
fill 11 120 283 11 124 284 minecraft:basalt
setblock 11 120 286 minecraft:light[level=12]
setblock 11 120 294 minecraft:light[level=12]
fill 11 120 298 11 125 298 minecraft:basalt
setblock 11 120 310 minecraft:light[level=12]
fill 12 120 283 12 125 283 minecraft:basalt
fill 12 120 292 13 120 292 minecraft:red_nether_bricks
setblock 12 120 293 minecraft:nether_wart_block
setblock 12 120 294 minecraft:red_nether_bricks
setblock 12 120 296 minecraft:nether_wart_block
fill 12 120 299 12 125 299 minecraft:basalt
setblock 13 120 276 minecraft:basalt
setblock 13 120 289 minecraft:red_nether_bricks
setblock 13 120 290 minecraft:nether_wart_block
fill 13 120 293 13 120 296 minecraft:magma_block
setblock 13 120 299 minecraft:red_nether_bricks
setblock 13 120 306 minecraft:basalt
fill 14 120 282 15 120 282 minecraft:basalt
fill 14 120 290 14 120 292 minecraft:magma_block
fill 14 120 297 14 120 299 minecraft:magma_block
fill 14 120 300 15 120 300 minecraft:basalt
fill 15 120 286 16 120 286 minecraft:red_nether_bricks
setblock 15 120 287 minecraft:nether_wart_block
fill 15 120 288 15 120 289 minecraft:magma_block
fill 15 120 301 15 125 301 minecraft:basalt
fill 16 120 276 18 120 276 minecraft:basalt
setblock 16 120 287 minecraft:magma_block
setblock 16 120 301 minecraft:magma_block
fill 16 120 306 18 120 306 minecraft:basalt
fill 17 120 281 19 125 281 minecraft:basalt
fill 17 120 285 18 120 285 minecraft:red_nether_bricks
fill 17 120 286 18 120 286 minecraft:magma_block
setblock 17 120 292 minecraft:light[level=12]
setblock 17 120 299 minecraft:light[level=12]
fill 17 120 301 17 125 302 minecraft:basalt
fill 17 120 307 22 120 307 minecraft:red_nether_bricks
setblock 17 120 313 minecraft:light[level=12]
fill 18 120 284 24 120 284 minecraft:nether_wart_block
fill 18 120 301 20 125 301 minecraft:basalt
fill 18 120 308 24 120 308 minecraft:nether_wart_block
setblock 19 120 276 minecraft:magma_block
fill 19 120 285 21 120 285 minecraft:magma_block
setblock 19 120 286 minecraft:light[level=12]
setblock 19 120 294 minecraft:light[level=12]
setblock 19 120 306 minecraft:magma_block
setblock 19 120 310 minecraft:light[level=12]
fill 21 120 282 23 125 282 minecraft:basalt
fill 21 120 300 23 125 300 minecraft:basalt
fill 22 120 285 25 120 285 minecraft:red_nether_bricks
fill 22 120 286 23 120 286 minecraft:magma_block
setblock 23 120 276 minecraft:basalt
setblock 23 120 306 minecraft:basalt
fill 24 120 283 24 125 283 minecraft:basalt
fill 24 120 286 26 120 286 minecraft:red_nether_bricks
setblock 24 120 287 minecraft:magma_block
setblock 24 120 292 minecraft:light[level=12]
fill 24 120 299 24 125 299 minecraft:basalt
fill 24 120 305 25 120 305 minecraft:basalt
fill 24 120 306 25 120 306 minecraft:red_nether_bricks
setblock 24 120 313 minecraft:light[level=12]
setblock 25 120 277 minecraft:magma_block
fill 25 120 278 25 121 278 minecraft:basalt
fill 25 120 284 26 125 284 minecraft:basalt
fill 25 120 287 26 120 287 minecraft:red_nether_bricks
setblock 25 120 288 minecraft:magma_block
setblock 25 120 298 minecraft:magma_block
fill 26 120 285 26 124 285 minecraft:basalt
fill 26 120 288 26 121 288 minecraft:red_nether_bricks
fill 26 120 289 26 120 291 minecraft:magma_block
fill 26 120 297 26 124 297 minecraft:basalt
fill 26 120 305 26 121 305 minecraft:red_nether_bricks
fill 26 120 310 26 120 311 minecraft:red_nether_bricks
fill 27 120 278 27 120 279 minecraft:basalt
fill 27 120 287 27 125 288 minecraft:basalt
fill 27 120 289 27 120 291 minecraft:red_nether_bricks
fill 27 120 292 27 120 293 minecraft:magma_block
fill 27 120 294 27 125 295 minecraft:basalt
fill 27 120 303 27 120 304 minecraft:basalt
setblock 27 120 305 minecraft:nether_wart_block
setblock 27 120 310 minecraft:light[level=12]
setblock 28 120 279 minecraft:magma_block
fill 28 120 290 28 125 290 minecraft:basalt
setblock 28 120 291 minecraft:magma_block
fill 28 120 292 29 125 292 minecraft:basalt
setblock 28 120 303 minecraft:magma_block
setblock 28 120 304 minecraft:red_nether_bricks
setblock 29 120 303 minecraft:red_nether_bricks
setblock 31 120 278 minecraft:light[level=12]
setblock 31 120 282 minecraft:basalt
fill 31 120 298 31 121 298 minecraft:basalt
setblock 31 120 299 minecraft:magma_block
setblock 31 120 300 minecraft:basalt
setblock 31 120 306 minecraft:light[level=12]
setblock 31 120 313 minecraft:light[level=12]
fill 33 120 286 33 120 287 minecraft:basalt
fill 33 120 292 33 120 293 minecraft:basalt
fill 33 120 295 33 120 296 minecraft:basalt
setblock 35 120 278 minecraft:light[level=12]
setblock 35 120 286 minecraft:light[level=12]
setblock 35 120 294 minecraft:light[level=12]
setblock 35 120 302 minecraft:light[level=12]
setblock 35 120 310 minecraft:light[level=12]
setblock 38 120 278 minecraft:light[level=12]
setblock 38 120 285 minecraft:light[level=12]
setblock 38 120 292 minecraft:light[level=12]
setblock 38 120 299 minecraft:light[level=12]
setblock 38 120 306 minecraft:light[level=12]
setblock 38 120 313 minecraft:light[level=12]
fill 42 120 316 42 121 316 minecraft:cobbled_deepslate
setblock 0 121 289 minecraft:purple_concrete
fill 6 121 283 6 121 284 minecraft:basalt
fill 6 121 298 6 121 299 minecraft:basalt
setblock 6 121 317 minecraft:magma_block
fill 9 121 289 9 125 289 minecraft:basalt
setblock 9 121 290 minecraft:magma_block
fill 9 121 291 9 125 292 minecraft:basalt
setblock 9 121 293 minecraft:magma_block
setblock 9 121 302 minecraft:magma_block
fill 10 121 285 10 125 287 minecraft:basalt
fill 10 121 295 10 125 297 minecraft:basalt
fill 11 121 278 12 121 278 minecraft:basalt
fill 11 121 285 11 125 285 minecraft:basalt
fill 11 121 288 11 122 290 minecraft:ochre_froglight
fill 11 121 297 11 125 297 minecraft:basalt
fill 12 121 284 12 125 284 minecraft:basalt
fill 12 121 288 12 123 288 minecraft:ochre_froglight
fill 12 121 289 12 124 289 minecraft:black_concrete
fill 12 121 290 12 124 290 minecraft:ochre_froglight
setblock 12 121 296 minecraft:red_nether_bricks
setblock 12 121 297 minecraft:nether_wart_block
setblock 12 121 298 minecraft:magma_block
setblock 12 121 304 minecraft:magma_block
fill 13 121 283 14 124 283 minecraft:basalt
setblock 13 121 291 minecraft:nether_wart_block
setblock 13 121 292 minecraft:red_nether_bricks
fill 13 121 293 13 121 297 minecraft:red_terracotta
setblock 13 121 298 minecraft:red_nether_bricks
fill 13 121 299 14 121 299 minecraft:basalt
fill 14 121 282 14 125 282 minecraft:basalt
fill 14 121 290 14 121 292 minecraft:red_terracotta
setblock 14 121 298 minecraft:red_terracotta
fill 14 121 300 14 125 300 minecraft:basalt
setblock 15 121 277 minecraft:basalt
setblock 15 121 282 minecraft:magma_block
fill 15 121 288 15 121 289 minecraft:red_terracotta
setblock 15 121 300 minecraft:magma_block
fill 15 121 305 17 121 305 minecraft:basalt
fill 16 121 282 20 124 282 minecraft:basalt
setblock 16 121 287 minecraft:red_terracotta
fill 16 121 300 16 125 301 minecraft:basalt
fill 17 121 286 18 121 286 minecraft:red_terracotta
fill 17 121 292 17 122 293 minecraft:bone_block
fill 17 121 295 17 122 297 minecraft:bone_block
fill 17 121 299 17 122 299 minecraft:bone_block
fill 17 121 300 20 124 300 minecraft:basalt
fill 17 121 306 18 121 306 minecraft:nether_wart_block
fill 18 121 277 20 121 277 minecraft:basalt
setblock 18 121 285 minecraft:nether_wart_block
fill 18 121 290 18 122 290 minecraft:bone_block
setblock 18 121 305 minecraft:magma_block
fill 18 121 307 24 121 307 minecraft:red_nether_bricks
fill 19 121 285 22 121 285 minecraft:red_terracotta
fill 19 121 289 19 122 289 minecraft:bone_block
fill 19 121 306 23 122 306 minecraft:red_nether_bricks
fill 20 121 288 22 122 288 minecraft:bone_block
setblock 21 121 277 minecraft:magma_block
fill 22 121 283 23 124 283 minecraft:basalt
fill 22 121 299 23 125 299 minecraft:basalt
fill 23 121 285 24 121 285 minecraft:nether_wart_block
fill 23 121 286 23 122 286 minecraft:red_terracotta
fill 23 121 289 23 122 289 minecraft:bone_block
fill 24 121 284 24 125 284 minecraft:basalt
fill 24 121 286 25 121 286 minecraft:red_nether_bricks
setblock 24 121 287 minecraft:red_terracotta
fill 24 121 290 24 122 290 minecraft:bone_block
fill 24 121 298 25 125 298 minecraft:basalt
fill 24 121 305 25 122 305 minecraft:red_nether_bricks
fill 24 121 306 25 121 306 minecraft:nether_wart_block
setblock 24 121 310 minecraft:nether_wart_block
fill 24 121 311 24 123 311 minecraft:red_nether_bricks
fill 25 121 285 25 125 285 minecraft:basalt
setblock 25 121 287 minecraft:red_nether_bricks
setblock 25 121 288 minecraft:red_terracotta
fill 25 121 292 25 122 293 minecraft:bone_block
fill 25 121 295 25 121 296 minecraft:bone_block
fill 25 121 297 25 125 297 minecraft:basalt
fill 25 121 309 25 121 310 minecraft:red_nether_bricks
setblock 25 121 311 minecraft:nether_wart_block
fill 25 121 312 25 123 312 minecraft:red_nether_bricks
fill 26 121 286 26 125 287 minecraft:basalt
fill 26 121 289 26 121 290 minecraft:red_terracotta
fill 26 121 295 26 121 296 minecraft:basalt
fill 26 121 304 27 121 304 minecraft:red_nether_bricks
fill 26 121 309 26 123 309 minecraft:red_nether_bricks
fill 26 121 310 27 122 311 minecraft:orange_terracotta
setblock 26 121 312 minecraft:nether_wart_block
fill 27 121 289 27 125 289 minecraft:basalt
setblock 27 121 290 minecraft:magma_block
fill 27 121 291 27 125 292 minecraft:basalt
setblock 27 121 293 minecraft:magma_block
setblock 27 121 302 minecraft:magma_block
fill 27 121 303 27 122 303 minecraft:red_nether_bricks
fill 27 121 309 28 123 309 minecraft:orange_terracotta
setblock 27 121 312 minecraft:red_nether_bricks
fill 28 121 291 28 125 291 minecraft:basalt
setblock 28 121 303 minecraft:nether_wart_block
fill 28 121 310 28 123 310 minecraft:orange_terracotta
setblock 28 121 311 minecraft:red_nether_bricks
setblock 29 121 317 minecraft:amethyst_block
setblock 30 121 283 minecraft:magma_block
fill 30 121 284 30 122 284 minecraft:basalt
setblock 32 121 294 minecraft:basalt
setblock 41 121 317 minecraft:crying_obsidian
fill 0 122 289 0 129 289 minecraft:cobbled_deepslate
setblock 5 122 286 minecraft:basalt
setblock 5 122 287 minecraft:magma_block
fill 5 122 288 5 122 289 minecraft:basalt
setblock 5 122 293 minecraft:magma_block
fill 5 122 294 5 122 295 minecraft:basalt
setblock 5 122 296 minecraft:magma_block
setblock 6 122 284 minecraft:basalt
setblock 6 122 298 minecraft:basalt
fill 6 122 317 6 129 317 minecraft:cobbled_deepslate
setblock 8 122 300 minecraft:basalt
fill 9 122 290 9 125 290 minecraft:basalt
fill 9 122 293 10 122 293 minecraft:basalt
fill 10 122 288 10 125 289 minecraft:basalt
setblock 10 122 290 minecraft:ochre_froglight
fill 10 122 294 10 125 294 minecraft:basalt
setblock 11 122 279 minecraft:magma_block
fill 11 122 280 11 123 280 minecraft:basalt
fill 11 122 286 11 125 286 minecraft:basalt
fill 11 122 296 11 124 296 minecraft:basalt
fill 11 122 302 11 123 302 minecraft:basalt
setblock 11 122 303 minecraft:magma_block
fill 12 122 285 12 125 285 minecraft:basalt
fill 12 122 297 12 125 298 minecraft:basalt
fill 13 122 284 13 125 284 minecraft:basalt
fill 13 122 288 13 123 290 minecraft:ochre_froglight
fill 13 122 294 13 122 297 minecraft:red_terracotta
fill 13 122 298 13 125 299 minecraft:basalt
setblock 14 122 278 minecraft:magma_block
fill 14 122 291 14 122 292 minecraft:red_terracotta
setblock 14 122 299 minecraft:magma_block
setblock 14 122 304 minecraft:basalt
fill 15 122 282 15 125 283 minecraft:basalt
setblock 15 122 289 minecraft:red_terracotta
fill 15 122 296 16 123 296 minecraft:bone_block
fill 15 122 299 15 125 300 minecraft:basalt
fill 16 122 283 16 125 283 minecraft:basalt
fill 16 122 291 16 123 294 minecraft:bone_block
fill 16 122 298 16 123 298 minecraft:bone_block
fill 16 122 299 16 125 299 minecraft:basalt
setblock 17 122 277 minecraft:magma_block
fill 17 122 289 18 123 289 minecraft:bone_block
fill 17 122 291 17 123 291 minecraft:bone_block
fill 17 122 305 18 122 305 minecraft:basalt
fill 18 122 277 19 122 277 minecraft:basalt
fill 18 122 288 19 123 288 minecraft:bone_block
fill 20 122 283 21 125 283 minecraft:basalt
fill 20 122 287 22 124 287 minecraft:bone_block
fill 20 122 299 21 124 299 minecraft:basalt
fill 20 122 305 22 124 305 minecraft:bone_block
fill 21 122 278 22 122 278 minecraft:basalt
setblock 23 122 278 minecraft:magma_block
setblock 23 122 284 minecraft:magma_block
fill 23 122 288 24 123 288 minecraft:bone_block
fill 23 122 298 23 124 298 minecraft:basalt
setblock 23 122 304 minecraft:basalt
setblock 23 122 305 minecraft:red_terracotta
fill 24 122 285 24 125 285 minecraft:basalt
fill 24 122 289 25 123 289 minecraft:bone_block
fill 24 122 297 24 125 297 minecraft:basalt
fill 24 122 304 24 124 304 minecraft:bone_block
setblock 24 122 309 minecraft:nether_wart_block
setblock 24 122 310 minecraft:red_nether_bricks
setblock 24 122 312 minecraft:red_nether_bricks
fill 25 122 286 25 125 286 minecraft:basalt
setblock 25 122 287 minecraft:red_terracotta
fill 25 122 291 26 122 291 minecraft:bone_block
setblock 25 122 295 minecraft:bone_block
fill 25 122 296 26 125 296 minecraft:basalt
fill 25 122 304 26 122 304 minecraft:nether_wart_block
setblock 25 122 309 minecraft:red_nether_bricks
setblock 25 122 310 minecraft:nether_wart_block
fill 25 122 311 25 124 311 minecraft:red_nether_bricks
setblock 26 122 280 minecraft:magma_block
fill 26 122 288 26 124 288 minecraft:basalt
setblock 26 122 289 minecraft:magma_block
setblock 26 122 292 minecraft:bone_block
fill 26 122 293 26 124 294 minecraft:basalt
setblock 26 122 295 minecraft:magma_block
setblock 26 122 302 minecraft:basalt
setblock 26 122 303 minecraft:red_nether_bricks
fill 26 122 308 26 124 308 minecraft:red_nether_bricks
fill 26 122 312 26 124 312 minecraft:red_nether_bricks
fill 27 122 290 27 125 290 minecraft:basalt
fill 27 122 293 27 125 293 minecraft:basalt
setblock 27 122 302 minecraft:red_nether_bricks
setblock 27 122 308 minecraft:nether_wart_block
setblock 27 122 312 minecraft:nether_wart_block
setblock 28 122 282 minecraft:basalt
setblock 28 122 300 minecraft:basalt
setblock 28 122 301 minecraft:nether_wart_block
fill 28 122 308 29 122 308 minecraft:red_nether_bricks
setblock 28 122 311 minecraft:orange_terracotta
setblock 28 122 312 minecraft:red_nether_bricks
fill 29 122 309 29 122 310 minecraft:orange_terracotta
fill 29 122 311 29 124 311 minecraft:red_nether_bricks
fill 29 122 317 29 129 317 minecraft:cobbled_deepslate
setblock 30 122 298 minecraft:basalt
fill 30 122 308 30 124 308 minecraft:orange_terracotta
setblock 30 122 309 minecraft:red_nether_bricks
setblock 31 122 286 minecraft:basalt
setblock 31 122 296 minecraft:basalt
fill 32 122 288 32 123 289 minecraft:ochre_froglight
setblock 32 122 290 minecraft:magma_block
setblock 38 122 317 minecraft:amethyst_block
fill 39 122 317 39 129 317 minecraft:cobbled_deepslate
fill 41 122 317 41 129 317 minecraft:cobbled_deepslate
setblock 42 122 316 minecraft:magma_block
setblock 5 123 289 minecraft:basalt
fill 5 123 292 5 123 293 minecraft:basalt
setblock 7 123 285 minecraft:magma_block
fill 7 123 286 7 124 286 minecraft:basalt
setblock 7 123 297 minecraft:magma_block
fill 9 123 293 9 125 293 minecraft:basalt
setblock 10 123 281 minecraft:magma_block
setblock 10 123 290 minecraft:magma_block
fill 10 123 291 10 125 292 minecraft:basalt
setblock 10 123 293 minecraft:magma_block
setblock 10 123 301 minecraft:basalt
fill 11 123 287 11 124 288 minecraft:basalt
fill 11 123 289 11 123 290 minecraft:ochre_froglight
fill 11 123 294 11 125 295 minecraft:basalt
setblock 12 123 280 minecraft:basalt
fill 12 123 286 12 125 286 minecraft:basalt
fill 12 123 296 12 125 296 minecraft:basalt
setblock 12 123 302 minecraft:basalt
fill 13 123 285 13 125 285 minecraft:basalt
fill 13 123 297 13 125 297 minecraft:basalt
setblock 13 123 303 minecraft:basalt
fill 14 123 284 15 123 284 minecraft:basalt
fill 14 123 298 14 124 299 minecraft:basalt
setblock 15 123 279 minecraft:basalt
fill 15 123 292 15 125 292 minecraft:bone_block
fill 15 123 294 15 125 294 minecraft:bone_block
fill 15 123 298 15 125 298 minecraft:basalt
fill 16 123 278 18 123 278 minecraft:basalt
fill 16 123 290 17 123 290 minecraft:bone_block
fill 17 123 283 19 125 283 minecraft:basalt
fill 17 123 288 17 125 288 minecraft:bone_block
fill 17 123 299 18 125 299 minecraft:basalt
fill 18 123 287 19 125 287 minecraft:bone_block
fill 18 123 305 19 125 305 minecraft:bone_block
fill 18 123 309 19 124 310 minecraft:magma_block
setblock 19 123 278 minecraft:magma_block
setblock 19 123 299 minecraft:magma_block
setblock 19 123 304 minecraft:basalt
setblock 20 123 278 minecraft:basalt
setblock 20 123 288 minecraft:bone_block
fill 21 123 284 23 125 284 minecraft:basalt
fill 21 123 286 21 125 286 minecraft:bone_block
fill 21 123 298 21 125 298 minecraft:basalt
fill 21 123 306 21 125 306 minecraft:bone_block
setblock 22 123 288 minecraft:bone_block
setblock 22 123 298 minecraft:magma_block
setblock 22 123 303 minecraft:basalt
fill 22 123 304 23 123 304 minecraft:bone_block
fill 23 123 285 23 125 285 minecraft:basalt
fill 23 123 287 24 123 287 minecraft:bone_block
fill 23 123 297 23 125 297 minecraft:basalt
fill 23 123 305 24 125 305 minecraft:bone_block
fill 23 123 309 24 124 310 minecraft:magma_block
fill 23 123 317 23 129 317 minecraft:cobbled_deepslate
fill 24 123 286 24 125 286 minecraft:basalt
fill 24 123 296 24 125 296 minecraft:basalt
fill 24 123 303 25 123 303 minecraft:bone_block
setblock 24 123 312 minecraft:nether_wart_block
setblock 24 123 317 minecraft:crying_obsidian
setblock 25 123 280 minecraft:basalt
fill 25 123 287 25 125 287 minecraft:basalt
setblock 25 123 288 minecraft:magma_block
fill 25 123 290 25 123 291 minecraft:bone_block
setblock 25 123 294 minecraft:magma_block
fill 25 123 295 26 125 295 minecraft:basalt
setblock 25 123 302 minecraft:basalt
fill 25 123 304 25 125 304 minecraft:bone_block
setblock 25 123 308 minecraft:red_nether_bricks
setblock 25 123 309 minecraft:nether_wart_block
fill 25 123 310 25 125 310 minecraft:red_nether_bricks
fill 25 123 317 27 127 317 minecraft:cobbled_deepslate
fill 26 123 289 26 124 292 minecraft:basalt
fill 26 123 302 26 125 302 minecraft:bone_block
setblock 26 123 310 minecraft:nether_wart_block
fill 26 123 311 26 125 311 minecraft:red_nether_bricks
fill 27 123 308 27 125 308 minecraft:red_nether_bricks
setblock 27 123 310 minecraft:orange_terracotta
setblock 27 123 311 minecraft:nether_wart_block
fill 27 123 312 27 124 312 minecraft:red_nether_bricks
setblock 28 123 299 minecraft:magma_block
fill 28 123 307 29 123 307 minecraft:red_nether_bricks
setblock 28 123 308 minecraft:nether_wart_block
setblock 28 123 311 minecraft:red_nether_bricks
setblock 28 123 312 minecraft:nether_wart_block
setblock 29 123 297 minecraft:basalt
fill 29 123 308 29 124 309 minecraft:orange_terracotta
fill 29 123 310 29 125 310 minecraft:red_nether_bricks
fill 30 123 285 31 124 285 minecraft:gold_block
fill 30 123 307 31 124 307 minecraft:orange_terracotta
fill 30 123 309 31 124 309 minecraft:orange_terracotta
setblock 30 123 310 minecraft:nether_wart_block
fill 30 123 311 30 125 311 minecraft:red_nether_bricks
setblock 31 123 288 minecraft:ochre_froglight
setblock 31 123 289 minecraft:magma_block
fill 31 123 290 31 123 291 minecraft:basalt
setblock 31 123 292 minecraft:magma_block
setblock 31 123 293 minecraft:basalt
fill 31 123 308 31 125 308 minecraft:orange_terracotta
setblock 32 123 290 minecraft:ochre_froglight
fill 38 123 317 38 129 317 minecraft:cobbled_deepslate
fill 42 123 316 42 130 316 minecraft:cobbled_deepslate
setblock 6 124 289 minecraft:basalt
setblock 6 124 290 minecraft:magma_block
fill 6 124 291 6 124 292 minecraft:basalt
setblock 6 124 293 minecraft:magma_block
setblock 9 124 283 minecraft:magma_block
setblock 10 124 275 minecraft:magma_block
fill 10 124 290 11 124 290 minecraft:basalt
fill 10 124 293 11 124 293 minecraft:basalt
fill 11 124 289 11 125 289 minecraft:basalt
fill 11 124 291 11 124 292 minecraft:basalt
fill 12 124 287 12 125 287 minecraft:basalt
setblock 12 124 288 minecraft:bone_block
fill 12 124 295 12 125 295 minecraft:basalt
setblock 13 124 286 minecraft:basalt
setblock 13 124 296 minecraft:basalt
fill 14 124 284 14 125 285 minecraft:basalt
fill 14 124 291 14 124 296 minecraft:bone_block
fill 14 124 297 14 125 297 minecraft:basalt
setblock 14 124 302 minecraft:basalt
setblock 15 124 284 minecraft:magma_block
fill 15 124 289 16 124 291 minecraft:bone_block
fill 15 124 293 15 125 293 minecraft:bone_block
fill 15 124 295 15 124 297 minecraft:bone_block
setblock 15 124 302 minecraft:magma_block
fill 15 124 303 15 125 303 minecraft:bone_block
fill 16 124 284 20 124 284 minecraft:basalt
fill 16 124 288 16 125 288 minecraft:bone_block
setblock 16 124 292 minecraft:bone_block
fill 16 124 298 17 124 298 minecraft:basalt
setblock 16 124 303 minecraft:basalt
fill 16 124 304 18 124 304 minecraft:bone_block
fill 17 124 287 17 125 287 minecraft:bone_block
fill 17 124 289 17 125 289 minecraft:bone_block
fill 17 124 305 17 125 305 minecraft:bone_block
fill 18 124 279 20 124 279 minecraft:basalt
fill 18 124 286 20 125 286 minecraft:bone_block
setblock 18 124 288 minecraft:bone_block
fill 18 124 298 18 125 298 minecraft:magma_block
fill 18 124 303 20 124 303 minecraft:basalt
fill 18 124 306 20 125 306 minecraft:bone_block
fill 19 124 285 21 124 285 minecraft:bone_block
fill 19 124 298 19 124 299 minecraft:basalt
fill 19 124 307 23 125 307 minecraft:bone_block
fill 20 124 298 20 125 298 minecraft:basalt
fill 22 124 285 22 125 285 minecraft:basalt
setblock 22 124 286 minecraft:bone_block
fill 22 124 297 22 125 298 minecraft:basalt
fill 22 124 306 24 125 306 minecraft:bone_block
setblock 23 124 286 minecraft:basalt
setblock 23 124 287 minecraft:bone_block
setblock 23 124 296 minecraft:basalt
setblock 23 124 302 minecraft:basalt
setblock 24 124 281 minecraft:magma_block
setblock 24 124 287 minecraft:magma_block
setblock 24 124 288 minecraft:bone_block
fill 24 124 295 24 125 295 minecraft:basalt
setblock 24 124 311 minecraft:nether_wart_block
fill 24 124 317 24 129 317 minecraft:cobbled_deepslate
fill 25 124 288 25 124 294 minecraft:basalt
fill 25 124 303 27 125 303 minecraft:bone_block
fill 25 124 305 25 125 305 minecraft:bone_block
setblock 25 124 309 minecraft:red_nether_bricks
setblock 25 124 312 minecraft:nether_wart_block
fill 26 124 301 28 124 301 minecraft:bone_block
fill 26 124 304 26 125 304 minecraft:bone_block
setblock 26 124 309 minecraft:nether_wart_block
fill 26 124 310 26 125 310 minecraft:red_nether_bricks
setblock 27 124 283 minecraft:magma_block
fill 27 124 300 28 125 300 minecraft:bone_block
fill 27 124 302 27 125 302 minecraft:bone_block
setblock 27 124 309 minecraft:red_nether_bricks
setblock 27 124 310 minecraft:nether_wart_block
fill 27 124 311 27 125 311 minecraft:red_nether_bricks
fill 28 124 299 28 125 299 minecraft:bone_block
setblock 28 124 307 minecraft:nether_wart_block
fill 28 124 308 28 126 308 minecraft:red_nether_bricks
fill 28 124 309 28 127 310 minecraft:bone_block
setblock 28 124 311 minecraft:nether_wart_block
setblock 28 124 312 minecraft:red_nether_bricks
setblock 29 124 286 minecraft:basalt
setblock 29 124 307 minecraft:red_nether_bricks
fill 30 124 286 31 125 288 minecraft:bone_block
fill 30 124 289 30 124 290 minecraft:basalt
setblock 30 124 291 minecraft:magma_block
fill 30 124 292 30 124 293 minecraft:basalt
fill 30 124 306 30 126 306 minecraft:red_nether_bricks
fill 30 124 310 30 126 310 minecraft:red_nether_bricks
setblock 31 124 289 minecraft:black_concrete
setblock 31 124 290 minecraft:ochre_froglight
setblock 31 124 306 minecraft:nether_wart_block
setblock 31 124 310 minecraft:nether_wart_block
fill 32 124 306 32 124 308 minecraft:orange_terracotta
fill 32 124 309 32 125 309 minecraft:red_nether_bricks
fill 33 124 306 33 126 306 minecraft:orange_terracotta
setblock 33 124 307 minecraft:red_nether_bricks
setblock 7 125 294 minecraft:basalt
setblock 8 125 288 minecraft:magma_block
fill 8 125 289 8 125 290 minecraft:basalt
setblock 8 125 291 minecraft:magma_block
fill 8 125 292 8 125 293 minecraft:basalt
setblock 8 125 294 minecraft:magma_block
setblock 8 125 296 minecraft:basalt
fill 10 125 275 10 129 275 minecraft:cobbled_deepslate
setblock 10 125 290 minecraft:basalt
setblock 10 125 293 minecraft:basalt
fill 11 125 282 11 125 283 minecraft:basalt
setblock 11 125 284 minecraft:magma_block
setblock 11 125 287 minecraft:magma_block
setblock 11 125 288 minecraft:basalt
fill 11 125 290 11 125 293 minecraft:magma_block
setblock 11 125 296 minecraft:magma_block
setblock 11 125 299 minecraft:magma_block
fill 12 125 288 12 125 290 minecraft:magma_block
fill 12 125 292 12 125 294 minecraft:magma_block
setblock 13 125 283 minecraft:basalt
fill 13 125 286 13 125 287 minecraft:magma_block
fill 13 125 293 14 125 294 minecraft:bone_block
fill 13 125 295 13 125 296 minecraft:magma_block
setblock 13 125 301 minecraft:basalt
setblock 14 125 283 minecraft:magma_block
setblock 14 125 286 minecraft:magma_block
fill 14 125 289 16 125 289 minecraft:bone_block
fill 14 125 291 14 125 292 minecraft:bone_block
setblock 14 125 295 minecraft:bone_block
setblock 14 125 296 minecraft:magma_block
setblock 14 125 298 minecraft:magma_block
setblock 14 125 299 minecraft:basalt
setblock 14 125 301 minecraft:magma_block
setblock 14 125 303 minecraft:bone_block
fill 15 125 284 16 125 284 minecraft:basalt
fill 15 125 285 17 125 285 minecraft:magma_block
setblock 15 125 288 minecraft:bone_block
fill 15 125 290 15 125 291 minecraft:bone_block
setblock 15 125 296 minecraft:bone_block
fill 15 125 297 17 125 297 minecraft:magma_block
setblock 15 125 302 minecraft:basalt
fill 15 125 304 17 125 304 minecraft:bone_block
setblock 16 125 282 minecraft:basalt
setblock 16 125 287 minecraft:bone_block
setblock 16 125 290 minecraft:bone_block
setblock 16 125 298 minecraft:basalt
fill 16 125 303 17 125 303 minecraft:bone_block
setblock 16 125 305 minecraft:bone_block
setblock 17 125 282 minecraft:magma_block
fill 17 125 284 20 125 284 minecraft:magma_block
setblock 17 125 286 minecraft:bone_block
setblock 17 125 298 minecraft:magma_block
setblock 17 125 300 minecraft:magma_block
setblock 17 125 306 minecraft:bone_block
fill 18 125 282 20 125 282 minecraft:basalt
setblock 18 125 285 minecraft:bone_block
fill 18 125 300 20 125 300 minecraft:basalt
fill 18 125 302 19 125 302 minecraft:basalt
setblock 18 125 307 minecraft:bone_block
fill 19 125 285 21 125 285 minecraft:magma_block
fill 19 125 297 19 125 298 minecraft:magma_block
setblock 19 125 299 minecraft:basalt
setblock 20 125 281 minecraft:magma_block
setblock 20 125 287 minecraft:bone_block
fill 20 125 297 21 125 297 minecraft:magma_block
setblock 20 125 299 minecraft:magma_block
setblock 20 125 302 minecraft:magma_block
setblock 20 125 305 minecraft:bone_block
fill 21 125 280 21 125 281 minecraft:basalt
setblock 21 125 299 minecraft:basalt
setblock 21 125 302 minecraft:basalt
setblock 21 125 308 minecraft:bone_block
setblock 22 125 283 minecraft:basalt
fill 22 125 286 23 125 286 minecraft:magma_block
setblock 22 125 287 minecraft:bone_block
fill 22 125 296 23 125 296 minecraft:magma_block
setblock 22 125 301 minecraft:basalt
setblock 22 125 305 minecraft:bone_block
setblock 23 125 283 minecraft:magma_block
setblock 23 125 287 minecraft:magma_block
setblock 23 125 295 minecraft:magma_block
setblock 23 125 298 minecraft:magma_block
setblock 23 125 301 minecraft:magma_block
setblock 24 125 287 minecraft:basalt
fill 24 125 288 24 125 290 minecraft:magma_block
fill 24 125 292 24 125 294 minecraft:magma_block
setblock 24 125 307 minecraft:bone_block
setblock 25 125 282 minecraft:basalt
fill 25 125 288 25 125 289 minecraft:basalt
fill 25 125 290 25 125 292 minecraft:magma_block
fill 25 125 293 25 125 294 minecraft:basalt
setblock 25 125 300 minecraft:basalt
setblock 25 125 306 minecraft:bone_block
setblock 26 125 285 minecraft:magma_block
setblock 26 125 288 minecraft:magma_block
fill 26 125 289 26 125 290 minecraft:basalt
setblock 26 125 291 minecraft:magma_block
fill 26 125 292 26 125 293 minecraft:basalt
setblock 26 125 294 minecraft:magma_block
setblock 26 125 297 minecraft:magma_block
setblock 26 125 305 minecraft:bone_block
setblock 26 125 309 minecraft:red_nether_bricks
setblock 27 125 299 minecraft:bone_block
fill 27 125 301 28 125 301 minecraft:bone_block
setblock 27 125 304 minecraft:bone_block
setblock 27 125 309 minecraft:nether_wart_block
fill 27 125 310 27 126 310 minecraft:red_nether_bricks
fill 28 125 297 29 125 298 minecraft:bone_block
setblock 28 125 303 minecraft:bone_block
fill 28 125 307 28 126 307 minecraft:red_nether_bricks
setblock 28 125 311 minecraft:red_nether_bricks
fill 29 125 288 29 125 289 minecraft:basalt
setblock 29 125 290 minecraft:magma_block
setblock 29 125 291 minecraft:basalt
setblock 29 125 293 minecraft:magma_block
setblock 29 125 294 minecraft:basalt
fill 29 125 295 29 125 296 minecraft:bone_block
setblock 29 125 299 minecraft:bone_block
setblock 29 125 306 minecraft:red_nether_bricks
setblock 29 125 307 minecraft:nether_wart_block
fill 29 125 308 29 126 309 minecraft:red_nether_bricks
setblock 29 125 311 minecraft:nether_wart_block
setblock 30 125 307 minecraft:red_nether_bricks
setblock 30 125 308 minecraft:nether_wart_block
fill 30 125 309 30 127 309 minecraft:red_nether_bricks
fill 31 125 285 31 128 285 minecraft:bone_block
setblock 31 125 305 minecraft:nether_wart_block
fill 31 125 306 31 127 306 minecraft:red_nether_bricks
fill 31 125 307 33 125 307 minecraft:orange_terracotta
setblock 31 125 309 minecraft:nether_wart_block
fill 31 125 310 31 126 310 minecraft:red_nether_bricks
fill 32 125 286 32 127 286 minecraft:bone_block
fill 32 125 305 32 126 306 minecraft:orange_terracotta
fill 32 125 308 33 126 308 minecraft:red_nether_bricks
fill 33 125 304 33 126 305 minecraft:orange_terracotta
fill 34 125 305 34 126 306 minecraft:orange_terracotta
setblock 34 125 307 minecraft:red_nether_bricks
fill 0 126 275 0 126 277 minecraft:cobbled_deepslate
fill 0 126 278 0 126 279 minecraft:blackstone
fill 0 126 280 0 127 284 minecraft:cobbled_deepslate
fill 0 126 285 0 126 286 minecraft:blackstone
fill 0 126 287 0 129 287 minecraft:cobbled_deepslate
setblock 0 126 299 minecraft:blackstone
fill 0 126 300 0 130 300 minecraft:cobbled_deepslate
setblock 0 126 301 minecraft:blackstone
setblock 0 126 303 minecraft:blackstone
setblock 0 126 314 minecraft:blackstone
fill 1 126 275 1 129 275 minecraft:cobbled_deepslate
setblock 2 126 275 minecraft:blackstone
fill 3 126 275 3 127 275 minecraft:cobbled_deepslate
fill 3 126 278 3 127 278 minecraft:light[level=12]
setblock 3 126 285 minecraft:light[level=12]
setblock 3 126 292 minecraft:light[level=12]
setblock 3 126 299 minecraft:light[level=12]
setblock 3 126 306 minecraft:light[level=12]
setblock 3 126 313 minecraft:light[level=12]
setblock 4 126 317 minecraft:blackstone
setblock 9 126 275 minecraft:blackstone
setblock 10 126 278 minecraft:light[level=12]
fill 10 126 285 11 127 286 minecraft:bone_block
setblock 10 126 292 minecraft:light[level=12]
setblock 10 126 299 minecraft:light[level=12]
setblock 10 126 306 minecraft:light[level=12]
setblock 10 126 313 minecraft:light[level=12]
fill 11 126 287 12 126 287 minecraft:bone_block
setblock 12 126 286 minecraft:bone_block
setblock 14 126 317 minecraft:blackstone
setblock 15 126 275 minecraft:blackstone
fill 15 126 317 17 127 317 minecraft:cobbled_deepslate
setblock 17 126 278 minecraft:light[level=12]
setblock 17 126 285 minecraft:light[level=12]
setblock 17 126 292 minecraft:light[level=12]
setblock 17 126 299 minecraft:light[level=12]
setblock 17 126 306 minecraft:light[level=12]
setblock 17 126 313 minecraft:light[level=12]
fill 19 126 275 19 129 275 minecraft:cobbled_deepslate
setblock 20 126 275 minecraft:blackstone
setblock 24 126 278 minecraft:light[level=12]
setblock 24 126 285 minecraft:light[level=12]
setblock 24 126 292 minecraft:light[level=12]
setblock 24 126 299 minecraft:light[level=12]
setblock 24 126 306 minecraft:light[level=12]
setblock 24 126 313 minecraft:light[level=12]
setblock 27 126 309 minecraft:red_nether_bricks
setblock 29 126 306 minecraft:nether_wart_block
fill 29 126 307 29 127 307 minecraft:red_nether_bricks
setblock 29 126 310 minecraft:nether_wart_block
setblock 30 126 275 minecraft:blackstone
fill 30 126 286 31 126 287 minecraft:bone_block
fill 30 126 305 31 127 305 minecraft:red_nether_bricks
setblock 30 126 307 minecraft:nether_wart_block
fill 30 126 308 30 127 308 minecraft:red_nether_bricks
setblock 31 126 278 minecraft:light[level=12]
setblock 31 126 292 minecraft:light[level=12]
setblock 31 126 299 minecraft:light[level=12]
setblock 31 126 304 minecraft:nether_wart_block
fill 31 126 307 33 126 307 minecraft:red_nether_bricks
setblock 31 126 308 minecraft:nether_wart_block
fill 31 126 309 31 127 309 minecraft:red_nether_bricks
setblock 31 126 313 minecraft:light[level=12]
fill 32 126 285 32 129 285 minecraft:bone_block
setblock 32 126 304 minecraft:red_nether_bricks
setblock 32 126 309 minecraft:nether_wart_block
fill 33 126 303 33 128 303 minecraft:red_nether_bricks
setblock 33 126 309 minecraft:red_nether_bricks
fill 34 126 303 35 127 304 minecraft:orange_terracotta
setblock 34 126 307 minecraft:nether_wart_block
fill 34 126 308 34 127 308 minecraft:red_nether_bricks
fill 35 126 302 35 128 302 minecraft:orange_terracotta
fill 35 126 305 35 127 306 minecraft:red_nether_bricks
setblock 36 126 275 minecraft:blackstone
setblock 36 126 317 minecraft:blackstone
setblock 38 126 278 minecraft:light[level=12]
setblock 38 126 285 minecraft:light[level=12]
setblock 38 126 292 minecraft:light[level=12]
setblock 38 126 299 minecraft:light[level=12]
setblock 38 126 306 minecraft:light[level=12]
setblock 38 126 313 minecraft:light[level=12]
fill 40 126 275 42 126 275 minecraft:blackstone
setblock 42 126 282 minecraft:purple_concrete
fill 42 126 314 42 126 315 minecraft:blackstone
setblock 42 126 317 minecraft:blackstone
setblock 0 127 275 minecraft:cobbled_deepslate
fill 0 127 276 0 127 277 minecraft:blackstone
fill 0 127 278 0 129 279 minecraft:cobbled_deepslate
fill 0 127 285 0 129 286 minecraft:cobbled_deepslate
setblock 0 127 299 minecraft:cobbled_deepslate
fill 0 127 301 0 129 301 minecraft:cobbled_deepslate
setblock 0 127 303 minecraft:cobbled_deepslate
fill 0 127 307 0 129 307 minecraft:cobbled_deepslate
setblock 0 127 308 minecraft:blackstone
fill 0 127 309 0 129 310 minecraft:cobbled_deepslate
fill 0 127 311 0 128 311 minecraft:blackstone
fill 0 127 312 0 129 312 minecraft:cobbled_deepslate
fill 0 127 314 0 129 314 minecraft:cobbled_deepslate
fill 2 127 275 2 129 275 minecraft:cobbled_deepslate
setblock 3 127 286 minecraft:light[level=12]
setblock 3 127 294 minecraft:light[level=12]
setblock 3 127 302 minecraft:light[level=12]
setblock 3 127 310 minecraft:light[level=12]
setblock 3 127 317 minecraft:amethyst_block
fill 4 127 317 4 130 317 minecraft:cobbled_deepslate
fill 7 127 317 8 129 317 minecraft:cobbled_deepslate
fill 9 127 275 9 129 275 minecraft:cobbled_deepslate
setblock 9 127 317 minecraft:blackstone
fill 10 127 284 11 128 284 minecraft:bone_block
setblock 10 127 317 minecraft:cobbled_deepslate
setblock 11 127 278 minecraft:light[level=12]
setblock 11 127 294 minecraft:light[level=12]
setblock 11 127 302 minecraft:light[level=12]
setblock 11 127 310 minecraft:light[level=12]
setblock 12 127 275 minecraft:blackstone
fill 13 127 275 13 129 275 minecraft:cobbled_deepslate
setblock 14 127 275 minecraft:blackstone
fill 14 127 317 14 129 317 minecraft:cobbled_deepslate
fill 15 127 275 15 129 275 minecraft:cobbled_deepslate
setblock 19 127 278 minecraft:light[level=12]
setblock 19 127 286 minecraft:light[level=12]
setblock 19 127 294 minecraft:light[level=12]
setblock 19 127 302 minecraft:light[level=12]
setblock 19 127 310 minecraft:light[level=12]
fill 20 127 275 20 129 275 minecraft:cobbled_deepslate
setblock 27 127 278 minecraft:light[level=12]
setblock 27 127 286 minecraft:light[level=12]
setblock 27 127 294 minecraft:light[level=12]
setblock 27 127 302 minecraft:light[level=12]
setblock 27 127 310 minecraft:light[level=12]
setblock 29 127 308 minecraft:red_nether_bricks
setblock 29 127 309 minecraft:nether_wart_block
fill 30 127 275 30 129 275 minecraft:cobbled_deepslate
setblock 30 127 306 minecraft:nether_wart_block
fill 30 127 307 30 128 307 minecraft:red_nether_bricks
fill 31 127 284 32 128 284 minecraft:bone_block
setblock 31 127 286 minecraft:bone_block
fill 31 127 304 31 128 304 minecraft:red_nether_bricks
setblock 31 127 307 minecraft:nether_wart_block
fill 31 127 308 31 128 308 minecraft:red_nether_bricks
setblock 32 127 303 minecraft:red_nether_bricks
setblock 32 127 304 minecraft:nether_wart_block
fill 32 127 305 32 127 307 minecraft:red_nether_bricks
setblock 32 127 308 minecraft:nether_wart_block
setblock 32 127 309 minecraft:red_nether_bricks
fill 33 127 302 33 129 302 minecraft:red_nether_bricks
setblock 33 127 304 minecraft:red_nether_bricks
setblock 33 127 305 minecraft:orange_terracotta
fill 33 127 306 33 127 308 minecraft:red_nether_bricks
setblock 34 127 301 minecraft:red_nether_bricks
fill 34 127 302 34 128 302 minecraft:orange_terracotta
setblock 34 127 305 minecraft:red_nether_bricks
setblock 34 127 306 minecraft:nether_wart_block
fill 34 127 307 34 128 307 minecraft:red_nether_bricks
setblock 35 127 278 minecraft:light[level=12]
setblock 35 127 286 minecraft:light[level=12]
setblock 35 127 294 minecraft:light[level=12]
fill 35 127 301 35 128 301 minecraft:orange_terracotta
setblock 35 127 310 minecraft:light[level=12]
fill 36 127 275 36 129 275 minecraft:cobbled_deepslate
fill 36 127 301 36 128 301 minecraft:red_nether_bricks
fill 36 127 302 36 127 303 minecraft:orange_terracotta
setblock 36 127 304 minecraft:nether_wart_block
fill 36 127 305 36 129 305 minecraft:red_nether_bricks
fill 36 127 317 36 129 317 minecraft:cobbled_deepslate
setblock 37 127 275 minecraft:blackstone
fill 38 127 275 38 129 275 minecraft:cobbled_deepslate
fill 40 127 275 41 127 275 minecraft:cobbled_deepslate
fill 42 127 275 42 127 277 minecraft:blackstone
fill 42 127 282 42 129 282 minecraft:cobbled_deepslate
setblock 42 127 291 minecraft:blackstone
setblock 42 127 310 minecraft:blackstone
fill 42 127 314 42 127 315 minecraft:cobbled_deepslate
fill 42 127 317 42 130 317 minecraft:cobbled_deepslate
setblock 0 128 275 minecraft:blackstone
setblock 0 128 276 minecraft:purple_concrete
fill 0 128 277 0 129 277 minecraft:cobbled_deepslate
setblock 0 128 280 minecraft:blackstone
fill 0 128 281 0 129 284 minecraft:cobbled_deepslate
setblock 0 128 290 minecraft:blackstone
setblock 0 128 297 minecraft:blackstone
fill 0 128 298 0 129 298 minecraft:cobbled_deepslate
setblock 0 128 299 minecraft:blackstone
setblock 0 128 303 minecraft:blackstone
fill 0 128 308 0 129 308 minecraft:cobbled_deepslate
setblock 0 128 313 minecraft:blackstone
setblock 3 128 275 minecraft:blackstone
fill 3 128 317 3 129 317 minecraft:cobbled_deepslate
fill 9 128 283 9 128 285 minecraft:bone_block
fill 9 128 317 9 129 317 minecraft:cobbled_deepslate
fill 10 128 283 10 130 283 minecraft:bone_block
fill 10 128 285 11 128 285 minecraft:bone_block
setblock 10 128 317 minecraft:blackstone
fill 12 128 275 12 129 275 minecraft:cobbled_deepslate
setblock 13 128 317 minecraft:blackstone
fill 14 128 275 14 130 275 minecraft:cobbled_deepslate
setblock 15 128 317 minecraft:blackstone
fill 16 128 317 17 129 317 minecraft:cobbled_deepslate
fill 21 128 285 21 129 285 minecraft:amethyst_block
fill 25 128 317 26 129 317 minecraft:cobbled_deepslate
setblock 27 128 317 minecraft:blackstone
setblock 29 128 275 minecraft:blackstone
setblock 30 128 317 minecraft:blackstone
fill 31 128 305 32 128 305 minecraft:red_nether_bricks
setblock 31 128 306 minecraft:nether_wart_block
setblock 31 128 307 minecraft:red_nether_bricks
fill 32 128 283 33 130 283 minecraft:bone_block
setblock 32 128 303 minecraft:nether_wart_block
fill 32 128 304 32 129 304 minecraft:red_nether_bricks
fill 32 128 306 34 128 306 minecraft:red_nether_bricks
setblock 32 128 307 minecraft:nether_wart_block
setblock 32 128 308 minecraft:red_nether_bricks
setblock 32 128 317 minecraft:blackstone
fill 33 128 284 33 128 285 minecraft:bone_block
fill 33 128 301 33 130 301 minecraft:red_nether_bricks
setblock 33 128 304 minecraft:nether_wart_block
fill 33 128 305 33 131 305 minecraft:bone_block
setblock 33 128 307 minecraft:red_nether_bricks
setblock 33 128 308 minecraft:nether_wart_block
fill 33 128 317 33 129 317 minecraft:cobbled_deepslate
setblock 34 128 300 minecraft:red_nether_bricks
setblock 34 128 301 minecraft:nether_wart_block
fill 34 128 303 35 128 303 minecraft:orange_terracotta
fill 34 128 304 36 128 304 minecraft:red_nether_bricks
setblock 34 128 305 minecraft:nether_wart_block
setblock 35 128 275 minecraft:blackstone
fill 35 128 299 36 129 300 minecraft:orange_terracotta
setblock 35 128 305 minecraft:red_nether_bricks
setblock 35 128 306 minecraft:nether_wart_block
fill 36 128 298 36 130 298 minecraft:orange_terracotta
setblock 36 128 302 minecraft:orange_terracotta
setblock 36 128 303 minecraft:nether_wart_block
fill 37 128 275 37 129 275 minecraft:cobbled_deepslate
setblock 37 128 300 minecraft:nether_wart_block
fill 37 128 301 37 128 303 minecraft:red_nether_bricks
setblock 40 128 275 minecraft:amethyst_block
fill 41 128 275 41 129 275 minecraft:cobbled_deepslate
setblock 42 128 275 minecraft:blackstone
fill 42 128 276 42 129 277 minecraft:cobbled_deepslate
setblock 42 128 281 minecraft:amethyst_block
fill 42 128 283 42 128 284 minecraft:blackstone
setblock 42 128 289 minecraft:blackstone
fill 42 128 291 42 129 291 minecraft:cobbled_deepslate
setblock 42 128 299 minecraft:blackstone
fill 42 128 300 42 129 300 minecraft:cobbled_deepslate
setblock 42 128 306 minecraft:blackstone
fill 42 128 310 42 129 310 minecraft:cobbled_deepslate
fill 42 128 314 42 129 314 minecraft:cobbled_deepslate
setblock 42 128 315 minecraft:blackstone
fill 0 129 275 0 129 276 minecraft:cobbled_deepslate
fill 0 129 280 0 130 280 minecraft:cobbled_deepslate
setblock 0 129 290 minecraft:cobbled_deepslate
setblock 0 129 297 minecraft:cobbled_deepslate
setblock 0 129 299 minecraft:cobbled_deepslate
setblock 0 129 303 minecraft:cobbled_deepslate
fill 0 129 311 0 130 311 minecraft:cobbled_deepslate
fill 0 129 313 0 130 313 minecraft:cobbled_deepslate
setblock 2 129 317 minecraft:crying_obsidian
setblock 3 129 275 minecraft:cobbled_deepslate
fill 9 129 282 9 130 284 minecraft:bone_block
fill 10 129 284 10 129 285 minecraft:bone_block
fill 10 129 317 10 130 317 minecraft:cobbled_deepslate
setblock 13 129 317 minecraft:cobbled_deepslate
setblock 15 129 317 minecraft:cobbled_deepslate
fill 27 129 317 27 130 317 minecraft:cobbled_deepslate
setblock 29 129 275 minecraft:cobbled_deepslate
setblock 30 129 317 minecraft:cobbled_deepslate
fill 32 129 284 33 130 284 minecraft:bone_block
setblock 32 129 303 minecraft:red_nether_bricks
setblock 32 129 305 minecraft:red_nether_bricks
setblock 32 129 306 minecraft:nether_wart_block
setblock 32 129 307 minecraft:red_nether_bricks
setblock 32 129 317 minecraft:cobbled_deepslate
fill 33 129 282 33 132 282 minecraft:bone_block
setblock 33 129 303 minecraft:nether_wart_block
fill 33 129 304 33 130 304 minecraft:red_nether_bricks
fill 33 129 306 35 129 306 minecraft:red_nether_bricks
setblock 33 129 307 minecraft:nether_wart_block
setblock 34 129 299 minecraft:red_nether_bricks
setblock 34 129 300 minecraft:nether_wart_block
fill 34 129 301 34 129 303 minecraft:red_nether_bricks
setblock 34 129 304 minecraft:nether_wart_block
fill 34 129 305 34 130 305 minecraft:red_nether_bricks
setblock 35 129 275 minecraft:cobbled_deepslate
fill 35 129 298 35 130 298 minecraft:orange_terracotta
setblock 35 129 301 minecraft:nether_wart_block
fill 35 129 302 35 129 304 minecraft:red_nether_bricks
setblock 35 129 305 minecraft:nether_wart_block
fill 36 129 297 37 129 297 minecraft:red_nether_bricks
setblock 36 129 301 minecraft:orange_terracotta
setblock 36 129 302 minecraft:nether_wart_block
fill 36 129 303 36 130 304 minecraft:red_nether_bricks
fill 37 129 298 37 129 300 minecraft:orange_terracotta
fill 37 129 301 37 129 302 minecraft:red_nether_bricks
setblock 37 129 303 minecraft:nether_wart_block
setblock 40 129 275 minecraft:cobbled_deepslate
setblock 42 129 275 minecraft:cobbled_deepslate
setblock 42 129 281 minecraft:cobbled_deepslate
fill 42 129 283 42 129 284 minecraft:cobbled_deepslate
setblock 42 129 289 minecraft:cobbled_deepslate
setblock 42 129 299 minecraft:cobbled_deepslate
setblock 42 129 306 minecraft:cobbled_deepslate
fill 42 129 315 42 130 315 minecraft:cobbled_deepslate
fill 0 130 275 0 132 275 minecraft:cobbled_deepslate
fill 0 130 276 0 130 279 minecraft:blackstone
fill 0 130 281 0 130 299 minecraft:blackstone
fill 0 130 301 0 131 303 minecraft:blackstone
setblock 0 130 304 minecraft:purple_concrete
fill 0 130 305 0 177 309 minecraft:blackstone
setblock 0 130 310 minecraft:crying_obsidian
fill 0 130 312 0 139 312 minecraft:blackstone
fill 0 130 314 0 131 317 minecraft:blackstone
fill 1 130 275 5 139 275 minecraft:blackstone
fill 1 130 317 3 136 317 minecraft:blackstone
fill 5 130 317 9 182 317 minecraft:blackstone
setblock 6 130 275 minecraft:cobbled_deepslate
fill 7 130 275 13 178 275 minecraft:blackstone
fill 8 130 282 8 131 283 minecraft:bone_block
setblock 10 130 282 minecraft:bone_block
setblock 10 130 284 minecraft:bone_block
fill 11 130 317 26 131 317 minecraft:blackstone
fill 15 130 275 21 131 275 minecraft:blackstone
fill 21 130 285 21 140 285 minecraft:blackstone
fill 23 130 275 42 130 275 minecraft:blackstone
fill 28 130 317 30 131 317 minecraft:blackstone
setblock 32 130 282 minecraft:bone_block
fill 32 130 317 41 130 317 minecraft:blackstone
fill 33 130 300 34 130 300 minecraft:red_nether_bricks
setblock 33 130 302 minecraft:nether_wart_block
setblock 33 130 303 minecraft:red_nether_bricks
fill 34 130 282 34 131 283 minecraft:bone_block
fill 34 130 297 34 130 298 minecraft:red_nether_bricks
setblock 34 130 299 minecraft:nether_wart_block
fill 34 130 301 35 130 302 minecraft:red_nether_bricks
setblock 34 130 303 minecraft:nether_wart_block
setblock 34 130 304 minecraft:red_nether_bricks
fill 35 130 296 37 131 296 minecraft:orange_terracotta
fill 35 130 297 35 132 297 minecraft:red_nether_bricks
fill 35 130 299 37 130 299 minecraft:orange_terracotta
setblock 35 130 300 minecraft:nether_wart_block
setblock 35 130 303 minecraft:red_nether_bricks
setblock 35 130 304 minecraft:nether_wart_block
setblock 35 130 305 minecraft:red_nether_bricks
fill 36 130 295 37 132 295 minecraft:orange_terracotta
fill 36 130 297 37 131 297 minecraft:orange_terracotta
setblock 36 130 300 minecraft:orange_terracotta
setblock 36 130 301 minecraft:nether_wart_block
fill 36 130 302 36 131 302 minecraft:red_nether_bricks
setblock 37 130 298 minecraft:nether_wart_block
fill 37 130 300 38 130 301 minecraft:red_nether_bricks
setblock 37 130 302 minecraft:nether_wart_block
setblock 37 130 303 minecraft:red_nether_bricks
fill 38 130 297 38 130 298 minecraft:red_nether_bricks
setblock 38 130 299 minecraft:nether_wart_block
fill 42 130 276 42 131 281 minecraft:blackstone
setblock 42 130 282 minecraft:crying_obsidian
fill 42 130 283 42 130 295 minecraft:blackstone
fill 42 130 297 42 130 314 minecraft:blackstone
setblock 0 131 276 minecraft:blackstone
setblock 0 131 277 minecraft:cobbled_deepslate
fill 0 131 278 0 131 280 minecraft:blackstone
setblock 0 131 281 minecraft:cobbled_deepslate
fill 0 131 282 0 217 283 minecraft:blackstone
setblock 0 131 284 minecraft:cobbled_deepslate
fill 0 131 285 0 154 285 minecraft:blackstone
setblock 0 131 286 minecraft:cobbled_deepslate
fill 0 131 287 0 131 300 minecraft:blackstone
fill 0 131 304 0 159 304 minecraft:blackstone
setblock 0 131 310 minecraft:cobbled_deepslate
fill 0 131 311 0 219 311 minecraft:blackstone
setblock 0 131 313 minecraft:blackstone
fill 4 131 317 4 219 317 minecraft:blackstone
fill 6 131 275 6 152 275 minecraft:blackstone
fill 8 131 281 9 133 281 minecraft:bone_block
fill 9 131 282 9 131 283 minecraft:bone_block
fill 10 131 317 10 132 317 minecraft:blackstone
fill 14 131 275 14 197 275 minecraft:blackstone
fill 22 131 275 22 219 275 minecraft:blackstone
fill 22 131 285 22 140 285 minecraft:blackstone
setblock 23 131 275 minecraft:cobbled_deepslate
fill 24 131 275 32 131 275 minecraft:blackstone
setblock 27 131 317 minecraft:blackstone
fill 31 131 317 36 131 317 minecraft:blackstone
setblock 33 131 275 minecraft:cobbled_deepslate
fill 33 131 281 34 133 281 minecraft:bone_block
setblock 33 131 283 minecraft:bone_block
fill 34 131 275 41 149 275 minecraft:blackstone
fill 34 131 296 34 131 297 minecraft:red_nether_bricks
setblock 34 131 298 minecraft:nether_wart_block
fill 34 131 299 34 131 301 minecraft:red_nether_bricks
setblock 34 131 302 minecraft:nether_wart_block
setblock 34 131 303 minecraft:red_nether_bricks
setblock 35 131 294 minecraft:red_nether_bricks
setblock 35 131 295 minecraft:orange_terracotta
setblock 35 131 298 minecraft:red_nether_bricks
setblock 35 131 299 minecraft:nether_wart_block
fill 35 131 300 35 131 302 minecraft:red_nether_bricks
setblock 35 131 303 minecraft:nether_wart_block
fill 36 131 293 36 132 294 minecraft:orange_terracotta
fill 36 131 298 36 134 299 minecraft:bone_block
setblock 36 131 300 minecraft:nether_wart_block
fill 36 131 301 36 132 301 minecraft:red_nether_bricks
setblock 36 131 303 minecraft:red_nether_bricks
setblock 37 131 293 minecraft:nether_wart_block
setblock 37 131 294 minecraft:orange_terracotta
fill 37 131 298 37 131 300 minecraft:red_nether_bricks
setblock 37 131 301 minecraft:nether_wart_block
setblock 37 131 302 minecraft:red_nether_bricks
setblock 37 131 317 minecraft:cobbled_deepslate
fill 38 131 295 38 131 297 minecraft:red_nether_bricks
setblock 38 131 298 minecraft:nether_wart_block
fill 38 131 299 38 131 300 minecraft:red_nether_bricks
fill 38 131 317 40 198 317 minecraft:blackstone
setblock 41 131 317 minecraft:cobbled_deepslate
setblock 42 131 275 minecraft:cobbled_deepslate
fill 42 131 282 42 131 287 minecraft:blackstone
setblock 42 131 288 minecraft:cobbled_deepslate
fill 42 131 289 42 142 292 minecraft:blackstone
setblock 42 131 293 minecraft:cobbled_deepslate
fill 42 131 294 42 131 302 minecraft:blackstone
setblock 42 131 303 minecraft:cobbled_deepslate
fill 42 131 304 42 131 308 minecraft:blackstone
setblock 42 131 309 minecraft:cobbled_deepslate
fill 42 131 310 42 139 317 minecraft:blackstone
setblock 0 132 276 minecraft:cobbled_deepslate
fill 0 132 277 0 219 278 minecraft:blackstone
setblock 0 132 279 minecraft:cobbled_deepslate
fill 0 132 280 0 165 281 minecraft:blackstone
fill 0 132 284 0 219 284 minecraft:blackstone
fill 0 132 286 0 153 286 minecraft:blackstone
setblock 0 132 287 minecraft:cobbled_deepslate
fill 0 132 288 0 219 290 minecraft:blackstone
setblock 0 132 291 minecraft:cobbled_deepslate
fill 0 132 292 0 157 293 minecraft:blackstone
fill 0 132 294 0 132 295 minecraft:cobbled_deepslate
fill 0 132 296 0 151 300 minecraft:blackstone
setblock 0 132 301 minecraft:cobbled_deepslate
fill 0 132 302 0 191 303 minecraft:blackstone
fill 0 132 310 0 217 310 minecraft:blackstone
setblock 0 132 313 minecraft:magma_block
setblock 0 132 314 minecraft:cobbled_deepslate
fill 0 132 315 0 200 317 minecraft:blackstone
setblock 3 132 278 minecraft:light[level=12]
setblock 3 132 285 minecraft:light[level=12]
setblock 3 132 292 minecraft:light[level=12]
setblock 3 132 299 minecraft:light[level=12]
setblock 3 132 306 minecraft:light[level=12]
setblock 3 132 313 minecraft:light[level=12]
fill 7 132 280 7 134 281 minecraft:bone_block
fill 8 132 280 8 134 280 minecraft:bone_block
fill 8 132 282 9 132 282 minecraft:bone_block
setblock 10 132 278 minecraft:light[level=12]
setblock 10 132 285 minecraft:light[level=12]
setblock 10 132 292 minecraft:light[level=12]
setblock 10 132 299 minecraft:light[level=12]
setblock 10 132 306 minecraft:light[level=12]
setblock 10 132 313 minecraft:light[level=12]
fill 11 132 317 18 135 317 minecraft:blackstone
fill 15 132 275 15 215 275 minecraft:blackstone
setblock 16 132 275 minecraft:cobbled_deepslate
fill 17 132 275 21 133 275 minecraft:blackstone
setblock 17 132 278 minecraft:light[level=12]
setblock 17 132 285 minecraft:light[level=12]
setblock 17 132 292 minecraft:light[level=12]
setblock 17 132 299 minecraft:light[level=12]
setblock 17 132 306 minecraft:light[level=12]
setblock 17 132 313 minecraft:light[level=12]
setblock 19 132 317 minecraft:cobbled_deepslate
fill 20 132 285 20 140 285 minecraft:blackstone
fill 20 132 317 26 169 317 minecraft:blackstone
fill 21 132 284 22 140 284 minecraft:blackstone
fill 21 132 286 22 140 286 minecraft:blackstone
fill 23 132 275 24 215 275 minecraft:blackstone
setblock 24 132 278 minecraft:light[level=12]
setblock 24 132 285 minecraft:light[level=12]
setblock 24 132 292 minecraft:light[level=12]
setblock 24 132 299 minecraft:light[level=12]
setblock 24 132 306 minecraft:light[level=12]
setblock 24 132 313 minecraft:light[level=12]
setblock 25 132 275 minecraft:cobbled_deepslate
fill 26 132 275 31 159 275 minecraft:blackstone
setblock 27 132 317 minecraft:cobbled_deepslate
fill 28 132 317 29 219 317 minecraft:blackstone
setblock 30 132 317 minecraft:cobbled_deepslate
setblock 31 132 278 minecraft:light[level=12]
setblock 31 132 285 minecraft:light[level=12]
setblock 31 132 292 minecraft:light[level=12]
setblock 31 132 299 minecraft:light[level=12]
setblock 31 132 306 minecraft:light[level=12]
setblock 31 132 313 minecraft:light[level=12]
fill 31 132 317 34 132 317 minecraft:blackstone
setblock 32 132 275 minecraft:cobbled_deepslate
fill 33 132 275 33 219 275 minecraft:blackstone
fill 34 132 280 35 134 280 minecraft:bone_block
fill 34 132 282 34 133 282 minecraft:bone_block
setblock 34 132 293 minecraft:nether_wart_block
fill 34 132 294 34 132 296 minecraft:red_nether_bricks
setblock 34 132 297 minecraft:nether_wart_block
fill 34 132 298 34 132 300 minecraft:red_nether_bricks
fill 35 132 281 35 134 281 minecraft:bone_block
fill 35 132 291 35 133 293 minecraft:orange_terracotta
setblock 35 132 294 minecraft:nether_wart_block
fill 35 132 295 35 133 296 minecraft:red_nether_bricks
setblock 35 132 298 minecraft:nether_wart_block
fill 35 132 299 35 132 301 minecraft:red_nether_bricks
setblock 35 132 317 minecraft:cobbled_deepslate
fill 36 132 291 36 133 292 minecraft:orange_terracotta
setblock 36 132 296 minecraft:orange_terracotta
fill 36 132 297 37 133 297 minecraft:red_nether_bricks
fill 36 132 300 36 133 300 minecraft:red_nether_bricks
fill 36 132 317 37 219 317 minecraft:blackstone
fill 37 132 292 37 133 293 minecraft:orange_terracotta
fill 37 132 294 38 133 294 minecraft:red_nether_bricks
setblock 37 132 296 minecraft:nether_wart_block
fill 37 132 298 38 132 299 minecraft:red_nether_bricks
setblock 37 132 300 minecraft:nether_wart_block
setblock 37 132 301 minecraft:red_nether_bricks
setblock 38 132 278 minecraft:light[level=12]
setblock 38 132 285 minecraft:light[level=12]
setblock 38 132 292 minecraft:light[level=12]
setblock 38 132 293 minecraft:nether_wart_block
fill 38 132 295 38 132 296 minecraft:red_nether_bricks
setblock 38 132 297 minecraft:nether_wart_block
setblock 38 132 306 minecraft:light[level=12]
setblock 38 132 313 minecraft:light[level=12]
fill 41 132 317 41 219 317 minecraft:blackstone
fill 42 132 275 42 215 276 minecraft:blackstone
setblock 42 132 277 minecraft:amethyst_block
fill 42 132 278 42 144 282 minecraft:blackstone
setblock 42 132 283 minecraft:cobbled_deepslate
fill 42 132 284 42 176 288 minecraft:blackstone
fill 42 132 293 42 146 299 minecraft:blackstone
setblock 42 132 300 minecraft:cobbled_deepslate
fill 42 132 301 42 160 303 minecraft:blackstone
fill 42 132 304 42 132 305 minecraft:cobbled_deepslate
fill 42 132 306 42 210 309 minecraft:blackstone
fill 0 133 275 0 136 276 minecraft:blackstone
fill 0 133 279 0 219 279 minecraft:blackstone
fill 0 133 287 0 216 287 minecraft:blackstone
fill 0 133 291 0 217 291 minecraft:blackstone
fill 0 133 294 0 159 295 minecraft:blackstone
fill 0 133 301 0 211 301 minecraft:blackstone
fill 0 133 313 0 218 314 minecraft:blackstone
fill 7 133 279 8 134 279 minecraft:bone_block
setblock 8 133 282 minecraft:bone_block
setblock 10 133 317 minecraft:amethyst_block
fill 16 133 275 16 219 275 minecraft:blackstone
fill 19 133 317 19 219 317 minecraft:blackstone
fill 20 133 284 20 140 284 minecraft:blackstone
fill 20 133 286 20 140 286 minecraft:blackstone
fill 23 133 284 23 140 286 minecraft:blackstone
fill 25 133 275 25 184 275 minecraft:blackstone
fill 27 133 317 27 220 317 minecraft:blackstone
fill 30 133 317 30 195 317 minecraft:blackstone
setblock 31 133 317 minecraft:amethyst_block
fill 32 133 275 32 160 275 minecraft:blackstone
fill 32 133 317 35 139 317 minecraft:blackstone
fill 34 133 279 35 134 279 minecraft:bone_block
fill 34 133 289 35 135 290 minecraft:orange_terracotta
setblock 34 133 291 minecraft:red_nether_bricks
setblock 34 133 292 minecraft:nether_wart_block
fill 34 133 293 34 133 295 minecraft:red_nether_bricks
setblock 34 133 296 minecraft:nether_wart_block
setblock 34 133 297 minecraft:red_nether_bricks
fill 35 133 294 35 135 294 minecraft:red_nether_bricks
setblock 35 133 297 minecraft:nether_wart_block
fill 35 133 298 35 133 299 minecraft:red_nether_bricks
setblock 36 133 290 minecraft:nether_wart_block
setblock 36 133 293 minecraft:orange_terracotta
setblock 36 133 294 minecraft:nether_wart_block
fill 36 133 295 36 134 296 minecraft:red_nether_bricks
setblock 37 133 290 minecraft:red_nether_bricks
setblock 37 133 291 minecraft:nether_wart_block
setblock 37 133 295 minecraft:nether_wart_block
fill 37 133 296 37 134 296 minecraft:red_nether_bricks
fill 37 133 298 38 133 298 minecraft:red_nether_bricks
setblock 37 133 299 minecraft:nether_wart_block
setblock 38 133 292 minecraft:nether_wart_block
fill 38 133 293 38 135 293 minecraft:red_nether_bricks
setblock 38 133 295 minecraft:red_nether_bricks
setblock 38 133 296 minecraft:nether_wart_block
setblock 38 133 297 minecraft:red_nether_bricks
fill 42 133 277 42 215 277 minecraft:blackstone
fill 42 133 283 42 181 283 minecraft:blackstone
fill 42 133 300 42 186 300 minecraft:blackstone
fill 42 133 304 42 219 305 minecraft:blackstone
setblock 3 134 278 minecraft:light[level=12]
setblock 3 134 286 minecraft:light[level=12]
setblock 3 134 294 minecraft:light[level=12]
setblock 3 134 302 minecraft:light[level=12]
setblock 3 134 310 minecraft:light[level=12]
setblock 8 134 281 minecraft:bone_block
fill 10 134 317 10 181 317 minecraft:blackstone
setblock 11 134 278 minecraft:light[level=12]
setblock 11 134 286 minecraft:light[level=12]
setblock 11 134 294 minecraft:light[level=12]
setblock 11 134 302 minecraft:light[level=12]
setblock 11 134 310 minecraft:light[level=12]
fill 17 134 275 19 192 275 minecraft:blackstone
setblock 19 134 278 minecraft:light[level=12]
fill 19 134 285 19 140 285 minecraft:blackstone
setblock 19 134 286 minecraft:light[level=12]
setblock 19 134 294 minecraft:light[level=12]
setblock 19 134 302 minecraft:light[level=12]
setblock 19 134 310 minecraft:light[level=12]
setblock 20 134 275 minecraft:crying_obsidian
fill 20 134 287 22 140 287 minecraft:blackstone
fill 21 134 275 21 165 275 minecraft:blackstone
fill 21 134 283 22 140 283 minecraft:blackstone
setblock 27 134 278 minecraft:light[level=12]
setblock 27 134 286 minecraft:light[level=12]
setblock 27 134 294 minecraft:light[level=12]
setblock 27 134 302 minecraft:light[level=12]
setblock 27 134 310 minecraft:light[level=12]
fill 31 134 317 31 219 317 minecraft:blackstone
fill 33 134 288 35 135 288 minecraft:orange_terracotta
setblock 33 134 289 minecraft:red_nether_bricks
setblock 33 134 290 minecraft:nether_wart_block
fill 33 134 291 33 136 291 minecraft:red_nether_bricks
setblock 34 134 281 minecraft:bone_block
setblock 34 134 291 minecraft:nether_wart_block
fill 34 134 292 34 134 294 minecraft:red_nether_bricks
setblock 34 134 295 minecraft:nether_wart_block
setblock 35 134 278 minecraft:light[level=12]
setblock 35 134 286 minecraft:light[level=12]
fill 35 134 291 37 134 291 minecraft:red_nether_bricks
fill 35 134 292 36 134 292 minecraft:orange_terracotta
fill 35 134 293 35 136 293 minecraft:red_nether_bricks
setblock 35 134 295 minecraft:red_nether_bricks
setblock 35 134 296 minecraft:nether_wart_block
setblock 35 134 297 minecraft:red_nether_bricks
setblock 35 134 302 minecraft:light[level=12]
setblock 35 134 310 minecraft:light[level=12]
setblock 36 134 288 minecraft:red_nether_bricks
fill 36 134 289 36 134 290 minecraft:orange_terracotta
setblock 36 134 293 minecraft:nether_wart_block
fill 36 134 294 36 136 294 minecraft:red_nether_bricks
setblock 36 134 297 minecraft:nether_wart_block
setblock 37 134 289 minecraft:red_nether_bricks
setblock 37 134 290 minecraft:nether_wart_block
fill 37 134 292 37 134 293 minecraft:red_nether_bricks
setblock 37 134 294 minecraft:nether_wart_block
fill 37 134 295 37 135 295 minecraft:red_nether_bricks
setblock 37 134 297 minecraft:red_nether_bricks
setblock 38 134 291 minecraft:nether_wart_block
fill 38 134 292 38 135 292 minecraft:red_nether_bricks
setblock 38 134 294 minecraft:red_nether_bricks
setblock 38 134 295 minecraft:nether_wart_block
setblock 38 134 296 minecraft:red_nether_bricks
fill 7 135 277 7 135 279 minecraft:bone_block
fill 19 135 284 19 140 284 minecraft:blackstone
fill 19 135 286 19 140 286 minecraft:blackstone
fill 20 135 275 20 185 275 minecraft:blackstone
fill 20 135 283 20 140 283 minecraft:blackstone
fill 23 135 283 23 140 283 minecraft:blackstone
fill 23 135 287 23 140 287 minecraft:blackstone
fill 24 135 284 24 140 286 minecraft:blackstone
fill 32 135 286 33 137 287 minecraft:orange_terracotta
setblock 32 135 288 minecraft:nether_wart_block
fill 32 135 289 32 137 289 minecraft:red_nether_bricks
setblock 33 135 289 minecraft:orange_terracotta
fill 33 135 290 33 137 290 minecraft:red_nether_bricks
fill 33 135 292 34 135 292 minecraft:red_nether_bricks
setblock 34 135 286 minecraft:nether_wart_block
setblock 34 135 287 minecraft:red_nether_bricks
fill 34 135 291 34 137 291 minecraft:red_nether_bricks
setblock 34 135 293 minecraft:red_nether_bricks
setblock 34 135 294 minecraft:nether_wart_block
fill 35 135 277 35 135 279 minecraft:bone_block
setblock 35 135 287 minecraft:nether_wart_block
setblock 35 135 291 minecraft:nether_wart_block
fill 35 135 292 36 137 292 minecraft:bone_block
setblock 35 135 295 minecraft:nether_wart_block
setblock 36 135 288 minecraft:nether_wart_block
fill 36 135 289 36 135 291 minecraft:red_nether_bricks
fill 36 135 293 36 136 293 minecraft:red_nether_bricks
setblock 36 135 295 minecraft:red_nether_bricks
setblock 36 135 296 minecraft:nether_wart_block
setblock 37 135 289 minecraft:nether_wart_block
fill 37 135 290 37 135 292 minecraft:red_nether_bricks
setblock 37 135 293 minecraft:nether_wart_block
setblock 37 135 294 minecraft:red_nether_bricks
setblock 38 135 291 minecraft:red_nether_bricks
setblock 38 135 294 minecraft:nether_wart_block
fill 6 136 276 7 136 276 minecraft:bone_block
setblock 7 136 277 minecraft:bone_block
fill 7 136 296 9 137 296 minecraft:gold_block
fill 8 136 295 8 137 295 minecraft:gold_block
fill 8 136 297 8 137 297 minecraft:gold_block
setblock 11 136 317 minecraft:magma_block
fill 12 136 317 18 166 317 minecraft:blackstone
fill 18 136 285 18 140 285 minecraft:blackstone
fill 19 136 283 19 140 283 minecraft:blackstone
fill 19 136 287 19 140 287 minecraft:blackstone
fill 20 136 282 22 140 282 minecraft:blackstone
fill 20 136 288 23 140 288 minecraft:blackstone
fill 24 136 283 24 140 283 minecraft:blackstone
fill 24 136 287 24 140 287 minecraft:blackstone
fill 31 136 285 31 137 286 minecraft:orange_terracotta
fill 31 136 287 31 138 287 minecraft:red_nether_bricks
fill 32 136 284 32 138 284 minecraft:red_nether_bricks
fill 32 136 285 33 137 285 minecraft:orange_terracotta
fill 32 136 288 32 138 288 minecraft:red_nether_bricks
setblock 33 136 288 minecraft:nether_wart_block
fill 33 136 289 33 138 289 minecraft:red_nether_bricks
setblock 34 136 285 minecraft:nether_wart_block
fill 34 136 286 34 136 287 minecraft:orange_terracotta
fill 34 136 288 36 136 288 minecraft:red_nether_bricks
setblock 34 136 289 minecraft:nether_wart_block
fill 34 136 290 34 138 290 minecraft:red_nether_bricks
setblock 34 136 292 minecraft:red_nether_bricks
setblock 34 136 293 minecraft:nether_wart_block
fill 35 136 276 35 136 277 minecraft:bone_block
setblock 35 136 286 minecraft:nether_wart_block
fill 35 136 287 35 138 287 minecraft:red_nether_bricks
fill 35 136 289 37 136 289 minecraft:red_nether_bricks
setblock 35 136 290 minecraft:nether_wart_block
fill 35 136 291 35 137 291 minecraft:red_nether_bricks
setblock 36 136 276 minecraft:bone_block
setblock 36 136 287 minecraft:nether_wart_block
fill 36 136 290 37 136 290 minecraft:red_nether_bricks
setblock 36 136 291 minecraft:nether_wart_block
setblock 37 136 291 minecraft:red_nether_bricks
setblock 37 136 292 minecraft:nether_wart_block
setblock 37 136 293 minecraft:red_nether_bricks
fill 0 137 275 0 215 275 minecraft:blackstone
setblock 0 137 276 minecraft:magma_block
fill 1 137 317 1 219 317 minecraft:blackstone
setblock 2 137 317 minecraft:magma_block
fill 3 137 317 3 217 317 minecraft:blackstone
fill 11 137 317 11 163 317 minecraft:blackstone
fill 18 137 284 18 140 284 minecraft:blackstone
fill 18 137 286 18 140 286 minecraft:blackstone
fill 19 137 282 19 140 282 minecraft:blackstone
fill 19 137 288 19 140 288 minecraft:blackstone
fill 23 137 282 23 140 282 minecraft:blackstone
fill 25 137 284 25 140 286 minecraft:blackstone
fill 29 137 283 31 138 284 minecraft:orange_terracotta
fill 30 137 285 30 138 285 minecraft:orange_terracotta
fill 30 137 286 30 138 286 minecraft:red_nether_bricks
setblock 31 137 288 minecraft:red_nether_bricks
fill 32 137 283 32 139 283 minecraft:red_nether_bricks
fill 33 137 284 33 139 284 minecraft:red_nether_bricks
fill 33 137 288 33 139 288 minecraft:red_nether_bricks
fill 34 137 285 34 137 287 minecraft:red_nether_bricks
setblock 34 137 288 minecraft:nether_wart_block
fill 34 137 289 34 138 289 minecraft:red_nether_bricks
fill 35 137 286 35 138 286 minecraft:red_nether_bricks
fill 35 137 288 36 137 288 minecraft:red_nether_bricks
setblock 35 137 289 minecraft:nether_wart_block
fill 35 137 290 35 138 290 minecraft:red_nether_bricks
setblock 36 137 287 minecraft:red_nether_bricks
setblock 36 137 289 minecraft:red_nether_bricks
setblock 36 137 290 minecraft:nether_wart_block
setblock 36 137 291 minecraft:red_nether_bricks
fill 0 138 276 0 219 276 minecraft:blackstone
fill 2 138 317 2 202 317 minecraft:blackstone
setblock 3 138 278 minecraft:light[level=12]
setblock 3 138 285 minecraft:light[level=12]
setblock 3 138 292 minecraft:light[level=12]
setblock 3 138 299 minecraft:light[level=12]
setblock 3 138 306 minecraft:light[level=12]
setblock 3 138 313 minecraft:light[level=12]
setblock 10 138 278 minecraft:light[level=12]
setblock 10 138 285 minecraft:light[level=12]
setblock 10 138 292 minecraft:light[level=12]
setblock 10 138 299 minecraft:light[level=12]
setblock 10 138 306 minecraft:light[level=12]
setblock 10 138 313 minecraft:light[level=12]
setblock 17 138 278 minecraft:light[level=12]
fill 17 138 285 17 140 285 minecraft:blackstone
setblock 17 138 292 minecraft:light[level=12]
setblock 17 138 299 minecraft:light[level=12]
setblock 17 138 306 minecraft:light[level=12]
setblock 17 138 313 minecraft:light[level=12]
fill 18 138 283 18 140 283 minecraft:blackstone
fill 18 138 287 18 140 287 minecraft:blackstone
fill 20 138 281 23 140 281 minecraft:blackstone
fill 20 138 289 23 140 289 minecraft:blackstone
setblock 24 138 278 minecraft:light[level=12]
fill 24 138 282 24 139 282 minecraft:blackstone
fill 24 138 288 24 140 288 minecraft:blackstone
setblock 24 138 292 minecraft:light[level=12]
setblock 24 138 299 minecraft:light[level=12]
setblock 24 138 306 minecraft:light[level=12]
setblock 24 138 313 minecraft:light[level=12]
fill 25 138 283 25 139 283 minecraft:blackstone
fill 25 138 287 25 140 287 minecraft:blackstone
fill 28 138 282 28 138 284 minecraft:red_nether_bricks
setblock 29 138 282 minecraft:orange_terracotta
setblock 29 138 285 minecraft:red_nether_bricks
setblock 29 138 286 minecraft:nether_wart_block
fill 30 138 282 31 138 282 minecraft:red_nether_bricks
setblock 30 138 287 minecraft:nether_wart_block
setblock 31 138 278 minecraft:light[level=12]
setblock 31 138 285 minecraft:orange_terracotta
fill 31 138 286 31 139 286 minecraft:red_nether_bricks
setblock 31 138 288 minecraft:nether_wart_block
setblock 31 138 292 minecraft:light[level=12]
setblock 31 138 299 minecraft:light[level=12]
setblock 31 138 306 minecraft:light[level=12]
setblock 31 138 313 minecraft:light[level=12]
fill 32 138 285 32 141 286 minecraft:bone_block
fill 32 138 287 33 139 287 minecraft:red_nether_bricks
setblock 32 138 289 minecraft:nether_wart_block
fill 33 138 283 33 139 283 minecraft:red_nether_bricks
fill 33 138 285 34 138 285 minecraft:red_nether_bricks
setblock 33 138 286 minecraft:nether_wart_block
setblock 34 138 284 minecraft:red_nether_bricks
setblock 34 138 286 minecraft:red_nether_bricks
setblock 34 138 287 minecraft:nether_wart_block
fill 34 138 288 34 139 288 minecraft:red_nether_bricks
setblock 35 138 288 minecraft:nether_wart_block
setblock 35 138 289 minecraft:red_nether_bricks
setblock 36 138 288 minecraft:red_nether_bricks
setblock 36 138 289 minecraft:nether_wart_block
setblock 36 138 292 minecraft:bone_block
setblock 38 138 278 minecraft:light[level=12]
setblock 38 138 285 minecraft:light[level=12]
setblock 38 138 292 minecraft:light[level=12]
setblock 38 138 299 minecraft:light[level=12]
setblock 38 138 306 minecraft:light[level=12]
setblock 38 138 313 minecraft:light[level=12]
fill 17 139 283 17 140 284 minecraft:blackstone
fill 17 139 286 17 140 287 minecraft:blackstone
fill 18 139 282 18 140 282 minecraft:blackstone
fill 18 139 288 18 140 288 minecraft:blackstone
fill 19 139 281 19 140 281 minecraft:blackstone
fill 19 139 289 19 140 289 minecraft:blackstone
setblock 24 139 281 minecraft:blackstone
fill 24 139 289 24 140 289 minecraft:blackstone
setblock 25 139 282 minecraft:blackstone
fill 25 139 288 25 140 288 minecraft:blackstone
fill 26 139 281 27 140 282 minecraft:orange_terracotta
setblock 26 139 283 minecraft:red_nether_bricks
fill 26 139 284 26 139 286 minecraft:blackstone
fill 27 139 283 30 139 283 minecraft:orange_terracotta
fill 27 139 284 27 141 284 minecraft:red_nether_bricks
fill 28 139 281 28 141 281 minecraft:red_nether_bricks
fill 28 139 282 28 140 282 minecraft:orange_terracotta
setblock 28 139 284 minecraft:nether_wart_block
fill 28 139 285 28 141 285 minecraft:red_nether_bricks
setblock 29 139 281 minecraft:nether_wart_block
fill 29 139 282 29 141 282 minecraft:red_nether_bricks
fill 29 139 284 30 139 284 minecraft:orange_terracotta
setblock 29 139 285 minecraft:nether_wart_block
fill 29 139 286 29 140 286 minecraft:red_nether_bricks
setblock 30 139 281 minecraft:red_nether_bricks
setblock 30 139 282 minecraft:nether_wart_block
fill 30 139 285 31 139 285 minecraft:red_nether_bricks
setblock 30 139 286 minecraft:nether_wart_block
setblock 30 139 287 minecraft:red_nether_bricks
setblock 31 139 282 minecraft:red_nether_bricks
setblock 31 139 283 minecraft:nether_wart_block
fill 31 139 284 31 141 284 minecraft:red_nether_bricks
setblock 31 139 287 minecraft:nether_wart_block
setblock 32 139 284 minecraft:nether_wart_block
setblock 32 139 288 minecraft:nether_wart_block
setblock 33 139 285 minecraft:nether_wart_block
fill 33 139 286 33 140 286 minecraft:red_nether_bricks
setblock 34 139 285 minecraft:red_nether_bricks
setblock 34 139 286 minecraft:nether_wart_block
setblock 34 139 287 minecraft:red_nether_bricks
setblock 0 140 312 minecraft:amethyst_block
fill 1 140 275 3 170 275 minecraft:blackstone
setblock 4 140 275 minecraft:magma_block
fill 5 140 275 5 219 275 minecraft:blackstone
setblock 17 140 282 minecraft:blackstone
setblock 17 140 288 minecraft:blackstone
setblock 18 140 281 minecraft:blackstone
setblock 18 140 289 minecraft:blackstone
fill 20 140 280 23 140 280 minecraft:blackstone
fill 22 140 290 23 140 290 minecraft:blackstone
fill 24 140 281 24 142 281 minecraft:orange_terracotta
setblock 24 140 282 minecraft:red_nether_bricks
setblock 25 140 280 minecraft:nether_wart_block
setblock 25 140 281 minecraft:red_nether_bricks
fill 25 140 282 25 141 282 minecraft:orange_terracotta
setblock 25 140 283 minecraft:red_nether_bricks
setblock 25 140 289 minecraft:blackstone
fill 26 140 280 28 140 280 minecraft:red_nether_bricks
fill 26 140 283 28 140 283 minecraft:orange_terracotta
setblock 26 140 284 minecraft:red_nether_bricks
fill 26 140 285 26 140 287 minecraft:blackstone
fill 28 140 284 28 142 284 minecraft:red_nether_bricks
fill 29 140 281 29 142 281 minecraft:red_nether_bricks
fill 29 140 283 31 140 283 minecraft:red_nether_bricks
setblock 29 140 284 minecraft:nether_wart_block
fill 29 140 285 29 141 285 minecraft:red_nether_bricks
setblock 30 140 281 minecraft:nether_wart_block
fill 30 140 282 30 142 282 minecraft:red_nether_bricks
setblock 30 140 284 minecraft:red_nether_bricks
setblock 30 140 285 minecraft:nether_wart_block
setblock 30 140 286 minecraft:red_nether_bricks
setblock 31 140 282 minecraft:nether_wart_block
setblock 31 140 285 minecraft:red_nether_bricks
setblock 31 140 286 minecraft:nether_wart_block
setblock 31 140 287 minecraft:red_nether_bricks
setblock 32 140 283 minecraft:nether_wart_block
fill 32 140 284 32 141 284 minecraft:red_nether_bricks
setblock 32 140 287 minecraft:nether_wart_block
setblock 32 140 317 minecraft:purple_concrete
setblock 33 140 284 minecraft:nether_wart_block
setblock 33 140 285 minecraft:red_nether_bricks
setblock 33 140 287 minecraft:red_nether_bricks
fill 33 140 317 35 144 317 minecraft:blackstone
fill 42 140 310 42 144 312 minecraft:blackstone
setblock 42 140 313 minecraft:amethyst_block
fill 42 140 314 42 177 317 minecraft:blackstone
fill 0 141 312 0 215 312 minecraft:blackstone
setblock 3 141 278 minecraft:light[level=12]
setblock 3 141 286 minecraft:light[level=12]
setblock 3 141 294 minecraft:light[level=12]
setblock 3 141 302 minecraft:light[level=12]
setblock 3 141 310 minecraft:light[level=12]
fill 4 141 275 4 218 275 minecraft:blackstone
setblock 11 141 278 minecraft:light[level=12]
setblock 11 141 286 minecraft:light[level=12]
setblock 11 141 294 minecraft:light[level=12]
setblock 11 141 302 minecraft:light[level=12]
setblock 11 141 310 minecraft:light[level=12]
setblock 19 141 278 minecraft:light[level=12]
setblock 19 141 286 minecraft:light[level=12]
setblock 19 141 294 minecraft:light[level=12]
setblock 19 141 302 minecraft:light[level=12]
setblock 19 141 310 minecraft:light[level=12]
fill 21 141 284 22 141 286 minecraft:amethyst_block
fill 22 141 281 23 142 281 minecraft:orange_terracotta
fill 23 141 280 24 142 280 minecraft:orange_terracotta
fill 23 141 282 24 142 282 minecraft:orange_terracotta
fill 24 141 283 24 143 283 minecraft:red_nether_bricks
fill 25 141 280 25 143 280 minecraft:red_nether_bricks
fill 25 141 281 26 141 281 minecraft:orange_terracotta
setblock 25 141 283 minecraft:nether_wart_block
setblock 26 141 280 minecraft:nether_wart_block
fill 26 141 282 27 141 282 minecraft:orange_terracotta
fill 26 141 283 28 141 283 minecraft:red_nether_bricks
setblock 26 141 284 minecraft:nether_wart_block
setblock 27 141 278 minecraft:light[level=12]
fill 27 141 280 28 141 280 minecraft:red_nether_bricks
setblock 27 141 281 minecraft:nether_wart_block
setblock 27 141 286 minecraft:light[level=12]
setblock 27 141 294 minecraft:light[level=12]
setblock 27 141 302 minecraft:light[level=12]
setblock 27 141 310 minecraft:light[level=12]
setblock 28 141 282 minecraft:nether_wart_block
setblock 29 141 283 minecraft:nether_wart_block
fill 29 141 284 29 142 284 minecraft:red_nether_bricks
setblock 30 141 281 minecraft:red_nether_bricks
fill 30 141 283 31 141 283 minecraft:red_nether_bricks
setblock 30 141 284 minecraft:nether_wart_block
setblock 30 141 285 minecraft:red_nether_bricks
setblock 31 141 282 minecraft:red_nether_bricks
setblock 31 141 285 minecraft:nether_wart_block
fill 32 141 317 32 217 317 minecraft:blackstone
setblock 35 141 278 minecraft:light[level=12]
setblock 35 141 286 minecraft:light[level=12]
setblock 35 141 294 minecraft:light[level=12]
setblock 35 141 302 minecraft:light[level=12]
setblock 35 141 310 minecraft:light[level=12]
fill 42 141 313 42 219 313 minecraft:blackstone
fill 20 142 280 21 143 281 minecraft:orange_terracotta
setblock 21 142 282 minecraft:nether_wart_block
fill 21 142 285 21 142 286 minecraft:amethyst_block
setblock 22 142 279 minecraft:nether_wart_block
setblock 22 142 280 minecraft:orange_terracotta
setblock 22 142 282 minecraft:orange_terracotta
fill 22 142 285 22 143 285 minecraft:amethyst_block
fill 23 142 279 25 142 279 minecraft:red_nether_bricks
setblock 23 142 283 minecraft:red_nether_bricks
setblock 25 142 281 minecraft:orange_terracotta
setblock 25 142 282 minecraft:nether_wart_block
fill 25 142 283 25 142 284 minecraft:red_nether_bricks
setblock 26 142 279 minecraft:nether_wart_block
fill 26 142 280 26 143 281 minecraft:red_nether_bricks
fill 26 142 282 26 145 282 minecraft:bone_block
setblock 26 142 283 minecraft:nether_wart_block
setblock 26 142 284 minecraft:red_nether_bricks
setblock 27 142 280 minecraft:nether_wart_block
fill 27 142 281 27 142 283 minecraft:red_nether_bricks
setblock 27 142 284 minecraft:nether_wart_block
setblock 28 142 280 minecraft:red_nether_bricks
setblock 28 142 281 minecraft:nether_wart_block
fill 28 142 282 28 143 283 minecraft:red_nether_bricks
setblock 29 142 282 minecraft:nether_wart_block
setblock 29 142 283 minecraft:red_nether_bricks
setblock 30 142 283 minecraft:nether_wart_block
setblock 30 142 284 minecraft:red_nether_bricks
fill 40 142 287 40 145 287 minecraft:amethyst_block
setblock 18 143 281 minecraft:red_nether_bricks
fill 19 143 280 19 144 282 minecraft:orange_terracotta
fill 20 143 279 22 143 279 minecraft:red_nether_bricks
fill 20 143 282 21 143 282 minecraft:orange_terracotta
fill 21 143 283 22 144 283 minecraft:red_nether_bricks
fill 21 143 285 21 144 285 minecraft:amethyst_block
fill 22 143 280 22 143 281 minecraft:red_nether_bricks
setblock 22 143 282 minecraft:nether_wart_block
setblock 23 143 279 minecraft:nether_wart_block
fill 23 143 280 23 145 280 minecraft:red_nether_bricks
setblock 23 143 281 minecraft:orange_terracotta
fill 23 143 282 25 143 282 minecraft:red_nether_bricks
setblock 23 143 283 minecraft:nether_wart_block
fill 24 143 279 25 143 279 minecraft:red_nether_bricks
setblock 24 143 280 minecraft:nether_wart_block
fill 24 143 281 24 145 281 minecraft:red_nether_bricks
setblock 25 143 281 minecraft:nether_wart_block
fill 25 143 283 26 144 283 minecraft:red_nether_bricks
fill 27 143 280 27 143 282 minecraft:red_nether_bricks
setblock 27 143 283 minecraft:nether_wart_block
setblock 28 143 281 minecraft:red_nether_bricks
fill 38 143 287 39 145 287 minecraft:amethyst_block
fill 39 143 286 41 144 286 minecraft:amethyst_block
fill 39 143 288 41 144 288 minecraft:amethyst_block
fill 41 143 287 41 144 287 minecraft:amethyst_block
setblock 42 143 289 minecraft:magma_block
fill 42 143 290 42 163 292 minecraft:blackstone
setblock 3 144 278 minecraft:light[level=12]
setblock 3 144 285 minecraft:light[level=12]
setblock 3 144 292 minecraft:light[level=12]
setblock 3 144 299 minecraft:light[level=12]
setblock 3 144 306 minecraft:light[level=12]
setblock 3 144 313 minecraft:light[level=12]
setblock 10 144 278 minecraft:light[level=12]
setblock 10 144 285 minecraft:light[level=12]
setblock 10 144 292 minecraft:light[level=12]
setblock 10 144 299 minecraft:light[level=12]
setblock 10 144 306 minecraft:light[level=12]
setblock 10 144 313 minecraft:light[level=12]
fill 16 144 281 17 146 282 minecraft:orange_terracotta
setblock 17 144 278 minecraft:light[level=12]
setblock 17 144 280 minecraft:nether_wart_block
setblock 17 144 285 minecraft:light[level=12]
setblock 17 144 292 minecraft:light[level=12]
setblock 17 144 299 minecraft:light[level=12]
setblock 17 144 306 minecraft:light[level=12]
setblock 17 144 313 minecraft:light[level=12]
fill 18 144 279 18 144 280 minecraft:red_nether_bricks
fill 18 144 281 18 145 281 minecraft:orange_terracotta
fill 18 144 282 18 144 283 minecraft:red_nether_bricks
fill 19 144 279 19 146 279 minecraft:red_nether_bricks
fill 19 144 283 19 146 283 minecraft:red_nether_bricks
setblock 20 144 279 minecraft:nether_wart_block
fill 20 144 280 20 144 282 minecraft:orange_terracotta
setblock 20 144 283 minecraft:nether_wart_block
fill 21 144 279 23 144 279 minecraft:red_nether_bricks
setblock 21 144 280 minecraft:nether_wart_block
setblock 21 144 281 minecraft:orange_terracotta
fill 21 144 282 22 145 282 minecraft:red_nether_bricks
setblock 22 144 280 minecraft:red_nether_bricks
setblock 22 144 281 minecraft:nether_wart_block
setblock 23 144 281 minecraft:red_nether_bricks
setblock 23 144 282 minecraft:nether_wart_block
setblock 23 144 283 minecraft:red_nether_bricks
setblock 24 144 278 minecraft:light[level=12]
setblock 24 144 279 minecraft:nether_wart_block
fill 24 144 280 24 145 280 minecraft:red_nether_bricks
fill 24 144 282 25 144 282 minecraft:red_nether_bricks
setblock 24 144 283 minecraft:nether_wart_block
setblock 24 144 285 minecraft:light[level=12]
setblock 24 144 292 minecraft:light[level=12]
setblock 24 144 299 minecraft:light[level=12]
setblock 24 144 306 minecraft:light[level=12]
setblock 24 144 313 minecraft:light[level=12]
setblock 25 144 280 minecraft:nether_wart_block
fill 25 144 281 25 145 281 minecraft:red_nether_bricks
setblock 26 144 280 minecraft:red_nether_bricks
setblock 26 144 281 minecraft:nether_wart_block
setblock 27 144 281 minecraft:red_nether_bricks
setblock 27 144 282 minecraft:nether_wart_block
setblock 31 144 278 minecraft:light[level=12]
setblock 31 144 285 minecraft:light[level=12]
setblock 31 144 292 minecraft:light[level=12]
setblock 31 144 299 minecraft:light[level=12]
setblock 31 144 306 minecraft:light[level=12]
setblock 31 144 313 minecraft:light[level=12]
fill 35 144 287 37 145 287 minecraft:amethyst_block
fill 37 144 286 38 144 286 minecraft:amethyst_block
fill 37 144 288 38 144 288 minecraft:amethyst_block
setblock 38 144 278 minecraft:light[level=12]
setblock 38 144 285 minecraft:light[level=12]
setblock 38 144 292 minecraft:light[level=12]
setblock 38 144 299 minecraft:light[level=12]
setblock 38 144 306 minecraft:light[level=12]
setblock 38 144 313 minecraft:light[level=12]
fill 42 144 289 42 217 289 minecraft:blackstone
fill 15 145 281 15 146 282 minecraft:orange_terracotta
fill 15 145 283 15 146 283 minecraft:red_nether_bricks
fill 16 145 280 16 146 280 minecraft:red_nether_bricks
setblock 16 145 283 minecraft:orange_terracotta
setblock 17 145 279 minecraft:nether_wart_block
setblock 17 145 280 minecraft:orange_terracotta
schedule function dropper:buildpart/60_3 1t
