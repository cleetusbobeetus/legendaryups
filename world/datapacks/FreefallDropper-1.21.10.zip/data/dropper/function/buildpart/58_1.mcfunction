fill 474 68 269 474 72 269 minecraft:red_concrete
fill 483 68 246 484 68 247 minecraft:magenta_concrete
fill 484 68 244 485 68 245 minecraft:magenta_concrete
fill 485 68 243 488 68 243 minecraft:magenta_concrete
fill 486 68 244 489 68 244 minecraft:magenta_concrete
fill 489 68 245 490 68 245 minecraft:magenta_concrete
setblock 490 68 246 minecraft:magenta_concrete
fill 490 68 259 491 68 260 minecraft:magenta_concrete
fill 491 68 257 491 68 258 minecraft:magenta_concrete
fill 491 68 261 495 68 261 minecraft:magenta_concrete
fill 492 68 257 495 68 257 minecraft:magenta_concrete
fill 492 68 262 494 68 262 minecraft:magenta_concrete
fill 495 68 258 495 69 260 minecraft:magenta_concrete
setblock 496 68 259 minecraft:magenta_concrete
setblock 507 68 230 minecraft:red_concrete
setblock 507 68 266 minecraft:red_concrete
fill 508 68 229 508 72 230 minecraft:white_concrete
fill 508 68 265 508 72 266 minecraft:white_concrete
setblock 510 68 232 minecraft:white_concrete
fill 510 68 233 510 72 233 minecraft:red_concrete
setblock 510 68 268 minecraft:white_concrete
fill 510 68 269 510 72 269 minecraft:red_concrete
fill 471 69 230 471 73 231 minecraft:white_concrete
fill 471 69 266 471 73 267 minecraft:white_concrete
fill 472 69 231 472 74 231 minecraft:white_concrete
fill 472 69 267 472 74 267 minecraft:white_concrete
fill 474 69 232 475 72 232 minecraft:red_concrete
fill 474 69 268 475 72 268 minecraft:red_concrete
fill 484 69 245 484 69 247 minecraft:magenta_concrete
fill 485 69 244 485 69 245 minecraft:magenta_concrete
fill 486 69 244 488 69 244 minecraft:magenta_concrete
setblock 489 69 245 minecraft:magenta_concrete
fill 491 69 258 491 69 260 minecraft:magenta_concrete
fill 492 69 257 494 69 257 minecraft:magenta_concrete
fill 492 69 261 494 70 261 minecraft:magenta_concrete
fill 507 69 230 507 73 231 minecraft:white_concrete
fill 507 69 266 507 73 267 minecraft:white_concrete
fill 508 69 231 508 74 231 minecraft:white_concrete
fill 508 69 267 508 74 267 minecraft:white_concrete
fill 510 69 232 511 72 232 minecraft:red_concrete
fill 510 69 268 511 72 268 minecraft:red_concrete
fill 471 70 232 471 75 232 minecraft:white_concrete
fill 471 70 268 471 75 268 minecraft:white_concrete
setblock 472 70 232 minecraft:red_concrete
setblock 472 70 268 minecraft:red_concrete
fill 473 70 231 475 73 231 minecraft:red_concrete
setblock 473 70 238 minecraft:light[level=12]
setblock 473 70 239 minecraft:light[level=15]
setblock 473 70 245 minecraft:light[level=12]
setblock 473 70 247 minecraft:light[level=15]
setblock 473 70 252 minecraft:light[level=12]
setblock 473 70 255 minecraft:light[level=15]
setblock 473 70 259 minecraft:light[level=12]
setblock 473 70 263 minecraft:light[level=15]
fill 473 70 267 475 73 267 minecraft:red_concrete
setblock 480 70 231 minecraft:light[level=12]
setblock 480 70 238 minecraft:light[level=12]
setblock 480 70 245 minecraft:light[level=12]
setblock 480 70 252 minecraft:light[level=12]
setblock 480 70 259 minecraft:light[level=12]
setblock 480 70 266 minecraft:light[level=12]
setblock 481 70 231 minecraft:light[level=15]
setblock 481 70 239 minecraft:light[level=15]
setblock 481 70 247 minecraft:light[level=15]
setblock 481 70 255 minecraft:light[level=15]
setblock 481 70 263 minecraft:light[level=15]
setblock 485 70 245 minecraft:magenta_concrete
fill 486 70 244 487 70 244 minecraft:magenta_concrete
setblock 487 70 231 minecraft:light[level=12]
setblock 487 70 238 minecraft:light[level=12]
setblock 487 70 252 minecraft:light[level=12]
setblock 487 70 259 minecraft:light[level=12]
setblock 487 70 266 minecraft:light[level=12]
setblock 489 70 231 minecraft:light[level=15]
setblock 489 70 239 minecraft:light[level=15]
setblock 489 70 247 minecraft:light[level=15]
setblock 489 70 255 minecraft:light[level=15]
setblock 489 70 263 minecraft:light[level=15]
fill 491 70 259 491 70 260 minecraft:magenta_concrete
setblock 494 70 231 minecraft:light[level=12]
setblock 494 70 238 minecraft:light[level=12]
setblock 494 70 245 minecraft:light[level=12]
setblock 494 70 252 minecraft:light[level=12]
setblock 494 70 266 minecraft:light[level=12]
setblock 495 70 259 minecraft:magenta_concrete
setblock 497 70 231 minecraft:light[level=15]
setblock 497 70 239 minecraft:light[level=15]
setblock 497 70 247 minecraft:light[level=15]
setblock 497 70 255 minecraft:light[level=15]
setblock 497 70 263 minecraft:light[level=15]
setblock 501 70 231 minecraft:light[level=12]
setblock 501 70 238 minecraft:light[level=12]
setblock 501 70 245 minecraft:light[level=12]
setblock 501 70 252 minecraft:light[level=12]
setblock 501 70 259 minecraft:light[level=12]
setblock 501 70 266 minecraft:light[level=12]
setblock 505 70 231 minecraft:light[level=15]
setblock 505 70 239 minecraft:light[level=15]
setblock 505 70 247 minecraft:light[level=15]
setblock 505 70 255 minecraft:light[level=15]
setblock 505 70 263 minecraft:light[level=15]
fill 507 70 232 507 75 232 minecraft:white_concrete
fill 507 70 268 507 75 268 minecraft:white_concrete
setblock 508 70 232 minecraft:red_concrete
setblock 508 70 238 minecraft:light[level=12]
setblock 508 70 245 minecraft:light[level=12]
setblock 508 70 252 minecraft:light[level=12]
setblock 508 70 259 minecraft:light[level=12]
setblock 508 70 268 minecraft:red_concrete
fill 509 70 231 511 73 231 minecraft:red_concrete
fill 509 70 267 511 73 267 minecraft:red_concrete
fill 472 71 232 472 75 233 minecraft:white_concrete
fill 472 71 268 472 75 269 minecraft:white_concrete
setblock 473 71 233 minecraft:red_concrete
setblock 473 71 269 minecraft:red_concrete
setblock 474 71 229 minecraft:white_concrete
fill 474 71 230 475 74 230 minecraft:red_concrete
setblock 474 71 265 minecraft:white_concrete
fill 474 71 266 475 74 266 minecraft:red_concrete
fill 491 71 235 493 71 238 minecraft:orange_terracotta
fill 492 71 234 497 71 234 minecraft:orange_terracotta
fill 492 71 239 497 71 239 minecraft:orange_terracotta
fill 493 71 233 497 71 233 minecraft:orange_terracotta
fill 494 71 235 498 71 235 minecraft:orange_terracotta
fill 494 71 238 498 71 238 minecraft:orange_terracotta
fill 494 71 240 495 71 240 minecraft:orange_terracotta
fill 496 71 236 498 71 237 minecraft:orange_terracotta
fill 508 71 232 508 75 233 minecraft:white_concrete
fill 508 71 268 508 75 269 minecraft:white_concrete
setblock 509 71 233 minecraft:red_concrete
setblock 509 71 269 minecraft:red_concrete
setblock 510 71 229 minecraft:white_concrete
fill 510 71 230 511 74 230 minecraft:red_concrete
setblock 510 71 265 minecraft:white_concrete
fill 510 71 266 511 74 266 minecraft:red_concrete
fill 473 72 229 473 76 230 minecraft:red_concrete
fill 473 72 232 473 76 233 minecraft:white_concrete
fill 473 72 265 473 76 266 minecraft:red_concrete
fill 473 72 268 473 76 269 minecraft:white_concrete
fill 474 72 229 474 75 229 minecraft:red_concrete
fill 474 72 265 474 75 265 minecraft:red_concrete
fill 491 72 235 493 72 238 minecraft:white_concrete
fill 492 72 234 497 72 234 minecraft:white_concrete
fill 492 72 239 497 72 239 minecraft:white_concrete
fill 493 72 233 497 72 233 minecraft:white_concrete
fill 494 72 235 498 72 235 minecraft:white_concrete
fill 494 72 238 498 72 238 minecraft:white_concrete
fill 494 72 240 495 72 240 minecraft:white_concrete
fill 496 72 236 498 72 237 minecraft:white_concrete
fill 496 72 269 496 84 269 minecraft:brown_terracotta
fill 509 72 229 509 76 230 minecraft:red_concrete
fill 509 72 232 509 76 233 minecraft:white_concrete
fill 509 72 265 509 76 266 minecraft:red_concrete
fill 509 72 268 509 76 269 minecraft:white_concrete
fill 510 72 229 510 75 229 minecraft:red_concrete
fill 510 72 265 510 75 265 minecraft:red_concrete
fill 472 73 229 472 77 229 minecraft:red_concrete
setblock 472 73 230 minecraft:white_concrete
fill 472 73 265 472 77 265 minecraft:red_concrete
setblock 472 73 266 minecraft:white_concrete
fill 474 73 232 474 77 233 minecraft:white_concrete
fill 474 73 268 474 77 269 minecraft:white_concrete
setblock 475 73 232 minecraft:red_concrete
setblock 475 73 268 minecraft:red_concrete
fill 508 73 229 508 77 229 minecraft:red_concrete
setblock 508 73 230 minecraft:white_concrete
fill 508 73 265 508 77 265 minecraft:red_concrete
setblock 508 73 266 minecraft:white_concrete
fill 510 73 232 510 77 233 minecraft:white_concrete
fill 510 73 268 510 77 269 minecraft:white_concrete
setblock 511 73 232 minecraft:red_concrete
setblock 511 73 268 minecraft:red_concrete
fill 471 74 230 472 77 230 minecraft:red_concrete
setblock 471 74 231 minecraft:white_concrete
fill 471 74 266 472 77 266 minecraft:red_concrete
setblock 471 74 267 minecraft:white_concrete
fill 473 74 231 475 79 231 minecraft:white_concrete
fill 473 74 267 475 79 267 minecraft:white_concrete
fill 475 74 232 475 78 232 minecraft:white_concrete
fill 475 74 268 475 78 268 minecraft:white_concrete
fill 507 74 230 508 77 230 minecraft:red_concrete
setblock 507 74 231 minecraft:white_concrete
fill 507 74 266 508 77 266 minecraft:red_concrete
setblock 507 74 267 minecraft:white_concrete
fill 509 74 231 511 79 231 minecraft:white_concrete
fill 509 74 267 511 79 267 minecraft:white_concrete
fill 511 74 232 511 78 232 minecraft:white_concrete
fill 511 74 268 511 78 268 minecraft:white_concrete
fill 471 75 231 472 79 231 minecraft:red_concrete
fill 471 75 267 472 79 267 minecraft:red_concrete
setblock 474 75 230 minecraft:red_concrete
setblock 474 75 266 minecraft:red_concrete
fill 475 75 230 475 80 230 minecraft:white_concrete
fill 475 75 266 475 80 266 minecraft:white_concrete
fill 507 75 231 508 79 231 minecraft:red_concrete
fill 507 75 267 508 79 267 minecraft:red_concrete
setblock 510 75 230 minecraft:red_concrete
setblock 510 75 266 minecraft:red_concrete
fill 511 75 230 511 80 230 minecraft:white_concrete
fill 511 75 266 511 80 266 minecraft:white_concrete
fill 471 76 232 472 79 232 minecraft:red_concrete
fill 471 76 268 472 79 268 minecraft:red_concrete
setblock 472 76 233 minecraft:white_concrete
setblock 472 76 269 minecraft:white_concrete
setblock 473 76 238 minecraft:light[level=12]
setblock 473 76 245 minecraft:light[level=12]
setblock 473 76 252 minecraft:light[level=12]
setblock 473 76 259 minecraft:light[level=12]
fill 474 76 229 474 80 230 minecraft:white_concrete
fill 474 76 265 474 80 266 minecraft:white_concrete
setblock 480 76 231 minecraft:light[level=12]
setblock 480 76 238 minecraft:light[level=12]
setblock 480 76 245 minecraft:light[level=12]
setblock 480 76 252 minecraft:light[level=12]
setblock 480 76 259 minecraft:light[level=12]
setblock 480 76 266 minecraft:light[level=12]
setblock 487 76 231 minecraft:light[level=12]
setblock 487 76 238 minecraft:light[level=12]
setblock 487 76 245 minecraft:light[level=12]
setblock 487 76 252 minecraft:light[level=12]
setblock 487 76 259 minecraft:light[level=12]
setblock 487 76 266 minecraft:light[level=12]
fill 488 76 269 488 86 269 minecraft:brown_concrete
setblock 494 76 231 minecraft:light[level=12]
setblock 494 76 238 minecraft:light[level=12]
setblock 494 76 245 minecraft:light[level=12]
setblock 494 76 252 minecraft:light[level=12]
setblock 494 76 259 minecraft:light[level=12]
setblock 494 76 266 minecraft:light[level=12]
setblock 501 76 231 minecraft:light[level=12]
setblock 501 76 238 minecraft:light[level=12]
setblock 501 76 245 minecraft:light[level=12]
setblock 501 76 252 minecraft:light[level=12]
setblock 501 76 259 minecraft:light[level=12]
setblock 501 76 266 minecraft:light[level=12]
fill 507 76 232 508 79 232 minecraft:red_concrete
fill 507 76 268 508 79 268 minecraft:red_concrete
setblock 508 76 233 minecraft:white_concrete
setblock 508 76 238 minecraft:light[level=12]
setblock 508 76 245 minecraft:light[level=12]
setblock 508 76 252 minecraft:light[level=12]
setblock 508 76 259 minecraft:light[level=12]
setblock 508 76 269 minecraft:white_concrete
fill 510 76 229 510 80 230 minecraft:white_concrete
fill 510 76 265 510 80 266 minecraft:white_concrete
fill 472 77 233 473 80 233 minecraft:red_concrete
fill 472 77 269 473 80 269 minecraft:red_concrete
fill 473 77 229 473 81 230 minecraft:white_concrete
fill 473 77 232 473 81 232 minecraft:red_concrete
setblock 473 77 239 minecraft:light[level=15]
setblock 473 77 247 minecraft:light[level=15]
setblock 473 77 255 minecraft:light[level=15]
setblock 473 77 263 minecraft:light[level=15]
fill 473 77 265 473 81 266 minecraft:white_concrete
fill 473 77 268 473 81 268 minecraft:red_concrete
fill 478 77 244 479 81 248 minecraft:red_concrete
fill 478 77 249 479 81 252 minecraft:purple_concrete
fill 479 77 242 482 81 242 minecraft:orange_concrete
fill 479 77 243 479 81 243 minecraft:red_concrete
fill 479 77 253 479 81 253 minecraft:purple_concrete
fill 479 77 254 482 81 254 minecraft:light_blue_concrete
fill 480 77 241 483 81 241 minecraft:orange_concrete
fill 480 77 243 481 81 243 minecraft:orange_concrete
fill 480 77 244 480 81 246 minecraft:red_concrete
fill 480 77 248 484 78 248 minecraft:lime_stained_glass
fill 480 77 250 480 81 252 minecraft:purple_concrete
fill 480 77 253 481 81 253 minecraft:light_blue_concrete
fill 480 77 255 483 81 255 minecraft:light_blue_concrete
setblock 481 77 231 minecraft:light[level=15]
setblock 481 77 239 minecraft:light[level=15]
fill 481 77 240 483 81 240 minecraft:orange_concrete
fill 481 77 245 485 78 247 minecraft:lime_stained_glass
fill 481 77 249 485 78 251 minecraft:lime_stained_glass
fill 481 77 256 483 81 256 minecraft:light_blue_concrete
setblock 481 77 263 minecraft:light[level=15]
fill 482 77 239 482 81 239 minecraft:orange_concrete
fill 482 77 243 494 78 244 minecraft:lime_stained_glass
fill 482 77 252 494 78 253 minecraft:lime_stained_glass
fill 482 77 257 482 81 257 minecraft:light_blue_concrete
fill 483 77 239 487 81 239 minecraft:yellow_concrete
fill 483 77 242 493 78 242 minecraft:lime_stained_glass
fill 483 77 254 493 78 254 minecraft:lime_stained_glass
fill 483 77 257 488 81 257 minecraft:lime_concrete
fill 484 77 238 487 81 238 minecraft:yellow_concrete
fill 484 77 240 486 81 240 minecraft:yellow_concrete
fill 484 77 256 486 81 256 minecraft:lime_concrete
fill 484 77 258 488 81 258 minecraft:lime_concrete
fill 485 77 241 491 78 241 minecraft:lime_stained_glass
fill 485 77 255 491 78 255 minecraft:lime_stained_glass
fill 486 77 245 487 78 245 minecraft:lime_stained_glass
fill 486 77 251 487 78 251 minecraft:lime_stained_glass
fill 488 77 238 492 81 239 minecraft:lime_concrete
fill 488 77 240 488 78 240 minecraft:lime_stained_glass
fill 488 77 256 488 79 256 minecraft:lime_stained_glass
setblock 489 77 231 minecraft:light[level=15]
fill 489 77 245 495 78 245 minecraft:lime_stained_glass
fill 489 77 251 495 78 251 minecraft:lime_stained_glass
fill 489 77 257 492 81 258 minecraft:yellow_concrete
setblock 489 77 263 minecraft:light[level=15]
fill 490 77 240 492 81 240 minecraft:lime_concrete
fill 490 77 256 492 81 256 minecraft:yellow_concrete
fill 491 77 246 495 78 247 minecraft:lime_stained_glass
fill 491 77 249 495 78 250 minecraft:lime_stained_glass
fill 492 77 248 496 78 248 minecraft:lime_stained_glass
fill 493 77 239 493 81 239 minecraft:lime_concrete
fill 493 77 240 495 81 241 minecraft:light_blue_concrete
fill 493 77 255 495 81 256 minecraft:orange_concrete
fill 493 77 257 493 81 257 minecraft:yellow_concrete
fill 494 77 239 494 81 239 minecraft:light_blue_concrete
fill 494 77 242 497 81 242 minecraft:light_blue_concrete
fill 494 77 254 497 81 254 minecraft:orange_concrete
fill 494 77 257 494 81 257 minecraft:orange_concrete
fill 495 77 243 496 81 243 minecraft:light_blue_concrete
fill 495 77 253 496 81 253 minecraft:orange_concrete
fill 496 77 241 496 81 241 minecraft:light_blue_concrete
fill 496 77 244 498 81 246 minecraft:purple_concrete
fill 496 77 250 498 81 252 minecraft:red_concrete
fill 496 77 255 496 81 255 minecraft:orange_concrete
setblock 497 77 231 minecraft:light[level=15]
setblock 497 77 239 minecraft:light[level=15]
fill 497 77 243 497 81 243 minecraft:purple_concrete
fill 497 77 247 498 81 247 minecraft:purple_concrete
fill 497 77 248 498 81 249 minecraft:red_concrete
fill 497 77 253 497 81 253 minecraft:red_concrete
setblock 497 77 255 minecraft:light[level=15]
setblock 497 77 263 minecraft:light[level=15]
setblock 505 77 231 minecraft:light[level=15]
setblock 505 77 239 minecraft:light[level=15]
setblock 505 77 247 minecraft:light[level=15]
setblock 505 77 255 minecraft:light[level=15]
setblock 505 77 263 minecraft:light[level=15]
fill 508 77 233 509 80 233 minecraft:red_concrete
fill 508 77 269 509 80 269 minecraft:red_concrete
fill 509 77 229 509 81 230 minecraft:white_concrete
fill 509 77 232 509 81 232 minecraft:red_concrete
fill 509 77 265 509 81 266 minecraft:white_concrete
fill 509 77 268 509 81 268 minecraft:red_concrete
setblock 471 78 230 minecraft:red_concrete
setblock 471 78 266 minecraft:red_concrete
fill 472 78 229 472 82 230 minecraft:white_concrete
fill 472 78 265 472 82 266 minecraft:white_concrete
setblock 474 78 232 minecraft:white_concrete
fill 474 78 233 474 82 233 minecraft:red_concrete
setblock 474 78 268 minecraft:white_concrete
fill 474 78 269 474 82 269 minecraft:red_concrete
fill 477 78 245 477 80 248 minecraft:red_concrete
fill 477 78 249 477 80 251 minecraft:purple_concrete
fill 478 78 242 478 80 242 minecraft:orange_concrete
fill 478 78 243 478 80 243 minecraft:red_concrete
fill 478 78 253 478 80 253 minecraft:purple_concrete
fill 478 78 254 478 80 254 minecraft:light_blue_concrete
fill 479 78 241 479 80 241 minecraft:orange_concrete
fill 479 78 255 479 80 255 minecraft:light_blue_concrete
fill 480 78 240 480 80 240 minecraft:orange_concrete
fill 480 78 247 480 80 247 minecraft:red_concrete
fill 480 78 249 480 80 249 minecraft:purple_concrete
fill 480 78 256 480 80 256 minecraft:light_blue_concrete
fill 481 78 239 481 80 239 minecraft:orange_concrete
fill 481 78 244 481 80 244 minecraft:red_concrete
fill 481 78 252 481 80 252 minecraft:purple_concrete
fill 481 78 257 481 80 257 minecraft:light_blue_concrete
fill 482 78 238 482 80 238 minecraft:orange_concrete
fill 482 78 258 482 80 258 minecraft:light_blue_concrete
fill 483 78 238 483 80 238 minecraft:yellow_concrete
fill 483 78 258 483 80 258 minecraft:lime_concrete
fill 484 78 241 484 80 241 minecraft:yellow_concrete
fill 484 78 255 484 80 255 minecraft:lime_concrete
fill 485 78 237 487 80 237 minecraft:yellow_concrete
fill 485 78 259 488 80 259 minecraft:lime_concrete
fill 487 78 240 487 80 240 minecraft:yellow_concrete
fill 487 78 256 487 80 256 minecraft:lime_concrete
fill 488 78 237 491 80 237 minecraft:lime_concrete
fill 489 78 240 489 80 240 minecraft:lime_concrete
fill 489 78 256 489 80 256 minecraft:yellow_concrete
fill 489 78 259 491 80 259 minecraft:yellow_concrete
fill 492 78 241 492 80 241 minecraft:lime_concrete
fill 492 78 255 492 80 255 minecraft:yellow_concrete
fill 493 78 238 493 80 238 minecraft:lime_concrete
fill 493 78 258 493 80 258 minecraft:yellow_concrete
fill 494 78 238 494 80 238 minecraft:light_blue_concrete
fill 494 78 258 494 80 258 minecraft:orange_concrete
fill 495 78 239 495 80 239 minecraft:light_blue_concrete
fill 495 78 244 495 80 244 minecraft:purple_concrete
fill 495 78 252 495 80 252 minecraft:red_concrete
fill 495 78 257 495 80 257 minecraft:orange_concrete
fill 496 78 240 496 80 240 minecraft:light_blue_concrete
fill 496 78 247 496 80 247 minecraft:purple_concrete
fill 496 78 249 496 80 249 minecraft:red_concrete
fill 496 78 256 496 80 256 minecraft:orange_concrete
fill 497 78 241 497 80 241 minecraft:light_blue_concrete
fill 497 78 255 497 80 255 minecraft:orange_concrete
fill 498 78 242 498 80 242 minecraft:light_blue_concrete
fill 498 78 243 498 80 243 minecraft:purple_concrete
fill 498 78 253 498 80 253 minecraft:red_concrete
fill 498 78 254 498 80 254 minecraft:orange_concrete
fill 499 78 245 499 80 247 minecraft:purple_concrete
fill 499 78 248 499 80 251 minecraft:red_concrete
setblock 507 78 230 minecraft:red_concrete
setblock 507 78 266 minecraft:red_concrete
fill 508 78 229 508 82 230 minecraft:white_concrete
fill 508 78 265 508 82 266 minecraft:white_concrete
setblock 510 78 232 minecraft:white_concrete
fill 510 78 233 510 82 233 minecraft:red_concrete
setblock 510 78 268 minecraft:white_concrete
fill 510 78 269 510 82 269 minecraft:red_concrete
setblock 471 79 229 minecraft:lime_stained_glass
fill 471 79 230 471 83 230 minecraft:white_concrete
fill 471 79 233 471 79 234 minecraft:lime_stained_glass
setblock 471 79 235 minecraft:green_stained_glass
fill 471 79 236 471 79 238 minecraft:lime_stained_glass
setblock 471 79 239 minecraft:green_stained_glass
fill 471 79 240 471 79 242 minecraft:lime_stained_glass
setblock 471 79 243 minecraft:green_stained_glass
fill 471 79 244 471 79 246 minecraft:lime_stained_glass
setblock 471 79 247 minecraft:green_stained_glass
fill 471 79 248 471 79 250 minecraft:lime_stained_glass
setblock 471 79 251 minecraft:green_stained_glass
fill 471 79 252 471 79 254 minecraft:lime_stained_glass
setblock 471 79 255 minecraft:green_stained_glass
fill 471 79 256 471 79 258 minecraft:lime_stained_glass
setblock 471 79 259 minecraft:green_stained_glass
fill 471 79 260 471 79 262 minecraft:lime_stained_glass
setblock 471 79 263 minecraft:green_stained_glass
fill 471 79 264 471 79 265 minecraft:lime_stained_glass
fill 471 79 266 471 83 266 minecraft:white_concrete
setblock 471 79 269 minecraft:lime_stained_glass
setblock 472 79 234 minecraft:green_stained_glass
fill 472 79 235 472 79 237 minecraft:lime_stained_glass
setblock 472 79 238 minecraft:green_stained_glass
fill 472 79 239 472 79 241 minecraft:lime_stained_glass
setblock 472 79 242 minecraft:green_stained_glass
fill 472 79 243 472 79 245 minecraft:lime_stained_glass
setblock 472 79 246 minecraft:green_stained_glass
fill 472 79 247 472 79 249 minecraft:lime_stained_glass
setblock 472 79 250 minecraft:green_stained_glass
fill 472 79 251 472 79 253 minecraft:lime_stained_glass
setblock 472 79 254 minecraft:green_stained_glass
fill 472 79 255 472 79 257 minecraft:lime_stained_glass
setblock 472 79 258 minecraft:green_stained_glass
fill 472 79 259 472 79 261 minecraft:lime_stained_glass
setblock 472 79 262 minecraft:green_stained_glass
fill 472 79 263 473 79 264 minecraft:lime_stained_glass
fill 473 79 234 473 79 236 minecraft:lime_stained_glass
setblock 473 79 237 minecraft:green_stained_glass
fill 473 79 238 473 79 240 minecraft:lime_stained_glass
setblock 473 79 241 minecraft:green_stained_glass
fill 473 79 242 473 79 244 minecraft:lime_stained_glass
setblock 473 79 245 minecraft:green_stained_glass
fill 473 79 246 473 79 248 minecraft:lime_stained_glass
setblock 473 79 249 minecraft:green_stained_glass
fill 473 79 250 473 79 252 minecraft:lime_stained_glass
setblock 473 79 253 minecraft:green_stained_glass
fill 473 79 254 473 79 256 minecraft:lime_stained_glass
setblock 473 79 257 minecraft:green_stained_glass
fill 473 79 258 473 79 260 minecraft:lime_stained_glass
setblock 473 79 261 minecraft:green_stained_glass
fill 473 79 262 475 79 262 minecraft:lime_stained_glass
fill 474 79 232 475 82 232 minecraft:red_concrete
fill 474 79 234 474 79 235 minecraft:lime_stained_glass
setblock 474 79 236 minecraft:green_stained_glass
fill 474 79 237 474 79 239 minecraft:lime_stained_glass
setblock 474 79 240 minecraft:green_stained_glass
fill 474 79 241 474 79 243 minecraft:lime_stained_glass
setblock 474 79 244 minecraft:green_stained_glass
fill 474 79 245 474 79 247 minecraft:lime_stained_glass
setblock 474 79 248 minecraft:green_stained_glass
fill 474 79 249 474 79 251 minecraft:lime_stained_glass
setblock 474 79 252 minecraft:green_stained_glass
fill 474 79 253 474 79 255 minecraft:lime_stained_glass
setblock 474 79 256 minecraft:green_stained_glass
fill 474 79 257 474 79 259 minecraft:lime_stained_glass
setblock 474 79 260 minecraft:green_stained_glass
fill 474 79 261 476 79 261 minecraft:lime_stained_glass
setblock 474 79 263 minecraft:lime_stained_glass
setblock 474 79 264 minecraft:green_stained_glass
fill 474 79 268 475 82 268 minecraft:red_concrete
fill 475 79 229 476 79 229 minecraft:lime_stained_glass
fill 475 79 233 475 79 234 minecraft:lime_stained_glass
setblock 475 79 235 minecraft:green_stained_glass
fill 475 79 236 475 79 238 minecraft:lime_stained_glass
setblock 475 79 239 minecraft:green_stained_glass
fill 475 79 240 475 79 242 minecraft:lime_stained_glass
setblock 475 79 243 minecraft:green_stained_glass
fill 475 79 244 475 79 246 minecraft:lime_stained_glass
setblock 475 79 247 minecraft:green_stained_glass
fill 475 79 248 475 79 250 minecraft:lime_stained_glass
setblock 475 79 251 minecraft:green_stained_glass
fill 475 79 252 475 79 254 minecraft:lime_stained_glass
setblock 475 79 255 minecraft:green_stained_glass
fill 475 79 256 475 79 258 minecraft:lime_stained_glass
setblock 475 79 259 minecraft:green_stained_glass
fill 475 79 260 477 79 260 minecraft:lime_stained_glass
setblock 475 79 263 minecraft:green_stained_glass
fill 475 79 264 476 79 265 minecraft:lime_stained_glass
fill 475 79 269 476 79 269 minecraft:lime_stained_glass
setblock 476 79 230 minecraft:green_stained_glass
fill 476 79 231 476 79 233 minecraft:lime_stained_glass
setblock 476 79 234 minecraft:green_stained_glass
fill 476 79 235 476 79 237 minecraft:lime_stained_glass
setblock 476 79 238 minecraft:green_stained_glass
fill 476 79 239 476 79 241 minecraft:lime_stained_glass
setblock 476 79 242 minecraft:green_stained_glass
fill 476 79 243 476 79 245 minecraft:lime_stained_glass
setblock 476 79 246 minecraft:green_stained_glass
fill 476 79 247 476 79 249 minecraft:lime_stained_glass
setblock 476 79 250 minecraft:green_stained_glass
fill 476 79 251 476 79 253 minecraft:lime_stained_glass
setblock 476 79 254 minecraft:green_stained_glass
fill 476 79 255 476 79 257 minecraft:lime_stained_glass
setblock 476 79 258 minecraft:green_stained_glass
fill 476 79 259 478 79 259 minecraft:lime_stained_glass
setblock 476 79 262 minecraft:green_stained_glass
fill 476 79 263 478 79 263 minecraft:lime_stained_glass
setblock 476 79 266 minecraft:green_stained_glass
fill 476 79 267 477 79 268 minecraft:lime_stained_glass
setblock 477 79 229 minecraft:green_stained_glass
fill 477 79 230 477 79 232 minecraft:lime_stained_glass
setblock 477 79 233 minecraft:green_stained_glass
fill 477 79 234 477 79 236 minecraft:lime_stained_glass
setblock 477 79 237 minecraft:green_stained_glass
fill 477 79 238 477 79 240 minecraft:lime_stained_glass
setblock 477 79 241 minecraft:green_stained_glass
fill 477 79 242 477 79 243 minecraft:lime_stained_glass
setblock 477 79 244 minecraft:red_concrete
setblock 477 79 252 minecraft:purple_concrete
setblock 477 79 253 minecraft:green_stained_glass
fill 477 79 254 477 79 256 minecraft:lime_stained_glass
setblock 477 79 257 minecraft:green_stained_glass
fill 477 79 258 479 79 258 minecraft:lime_stained_glass
setblock 477 79 261 minecraft:green_stained_glass
fill 477 79 262 479 79 262 minecraft:lime_stained_glass
setblock 477 79 264 minecraft:lime_stained_glass
setblock 477 79 265 minecraft:green_stained_glass
fill 477 79 266 479 79 266 minecraft:lime_stained_glass
setblock 477 79 269 minecraft:green_stained_glass
fill 478 79 229 478 79 231 minecraft:lime_stained_glass
setblock 478 79 232 minecraft:green_stained_glass
fill 478 79 233 478 79 235 minecraft:lime_stained_glass
setblock 478 79 236 minecraft:green_stained_glass
fill 478 79 237 478 79 239 minecraft:lime_stained_glass
setblock 478 79 240 minecraft:green_stained_glass
setblock 478 79 241 minecraft:lime_stained_glass
setblock 478 79 255 minecraft:lime_stained_glass
setblock 478 79 256 minecraft:green_stained_glass
fill 478 79 257 480 79 257 minecraft:lime_stained_glass
setblock 478 79 260 minecraft:green_stained_glass
fill 478 79 261 480 79 261 minecraft:lime_stained_glass
setblock 478 79 264 minecraft:green_stained_glass
fill 478 79 265 480 79 265 minecraft:lime_stained_glass
setblock 478 79 267 minecraft:lime_stained_glass
setblock 478 79 268 minecraft:green_stained_glass
fill 478 79 269 480 79 269 minecraft:lime_stained_glass
fill 479 79 229 479 79 230 minecraft:lime_stained_glass
setblock 479 79 231 minecraft:green_stained_glass
fill 479 79 232 479 79 234 minecraft:lime_stained_glass
setblock 479 79 235 minecraft:green_stained_glass
fill 479 79 236 479 79 238 minecraft:lime_stained_glass
setblock 479 79 239 minecraft:green_stained_glass
setblock 479 79 240 minecraft:lime_stained_glass
setblock 479 79 256 minecraft:lime_stained_glass
setblock 479 79 259 minecraft:green_stained_glass
fill 479 79 260 481 79 260 minecraft:lime_stained_glass
setblock 479 79 263 minecraft:green_stained_glass
fill 479 79 264 481 79 264 minecraft:lime_stained_glass
setblock 479 79 267 minecraft:green_stained_glass
fill 479 79 268 481 79 268 minecraft:lime_stained_glass
setblock 480 79 229 minecraft:lime_stained_glass
setblock 480 79 230 minecraft:green_stained_glass
fill 480 79 231 480 79 233 minecraft:lime_stained_glass
setblock 480 79 234 minecraft:green_stained_glass
fill 480 79 235 480 79 237 minecraft:lime_stained_glass
setblock 480 79 238 minecraft:green_stained_glass
setblock 480 79 239 minecraft:lime_stained_glass
setblock 480 79 248 minecraft:green_stained_glass
setblock 480 79 258 minecraft:green_stained_glass
fill 480 79 259 482 79 259 minecraft:lime_stained_glass
setblock 480 79 262 minecraft:green_stained_glass
fill 480 79 263 482 79 263 minecraft:lime_stained_glass
setblock 480 79 266 minecraft:green_stained_glass
fill 480 79 267 482 79 267 minecraft:lime_stained_glass
setblock 481 79 229 minecraft:green_stained_glass
fill 481 79 230 481 79 232 minecraft:lime_stained_glass
setblock 481 79 233 minecraft:green_stained_glass
fill 481 79 234 481 79 236 minecraft:lime_stained_glass
setblock 481 79 237 minecraft:green_stained_glass
setblock 481 79 238 minecraft:lime_stained_glass
fill 481 79 245 481 79 246 minecraft:lime_stained_glass
setblock 481 79 247 minecraft:green_stained_glass
fill 481 79 248 481 79 249 minecraft:lime_stained_glass
setblock 481 79 250 minecraft:green_stained_glass
fill 481 79 251 482 79 251 minecraft:lime_stained_glass
setblock 481 79 258 minecraft:lime_stained_glass
setblock 481 79 261 minecraft:green_stained_glass
fill 481 79 262 483 79 262 minecraft:lime_stained_glass
setblock 481 79 265 minecraft:green_stained_glass
fill 481 79 266 483 79 266 minecraft:lime_stained_glass
setblock 481 79 269 minecraft:green_stained_glass
fill 482 79 229 482 79 231 minecraft:lime_stained_glass
setblock 482 79 232 minecraft:green_stained_glass
fill 482 79 233 482 79 235 minecraft:lime_stained_glass
setblock 482 79 236 minecraft:green_stained_glass
fill 482 79 237 483 79 237 minecraft:lime_stained_glass
setblock 482 79 243 minecraft:green_stained_glass
fill 482 79 244 482 79 245 minecraft:lime_stained_glass
setblock 482 79 246 minecraft:green_stained_glass
fill 482 79 247 482 79 248 minecraft:lime_stained_glass
setblock 482 79 249 minecraft:green_stained_glass
fill 482 79 250 483 79 250 minecraft:lime_stained_glass
setblock 482 79 252 minecraft:green_stained_glass
fill 482 79 253 483 79 253 minecraft:lime_stained_glass
setblock 482 79 260 minecraft:green_stained_glass
fill 482 79 261 484 79 261 minecraft:lime_stained_glass
setblock 482 79 264 minecraft:green_stained_glass
fill 482 79 265 484 79 265 minecraft:lime_stained_glass
setblock 482 79 268 minecraft:green_stained_glass
fill 482 79 269 484 79 269 minecraft:lime_stained_glass
fill 483 79 229 483 79 230 minecraft:lime_stained_glass
setblock 483 79 231 minecraft:green_stained_glass
fill 483 79 232 483 79 234 minecraft:lime_stained_glass
setblock 483 79 235 minecraft:green_stained_glass
fill 483 79 236 485 79 236 minecraft:lime_stained_glass
setblock 483 79 242 minecraft:green_stained_glass
fill 483 79 243 483 79 244 minecraft:lime_stained_glass
setblock 483 79 245 minecraft:green_stained_glass
fill 483 79 246 483 79 247 minecraft:lime_stained_glass
setblock 483 79 248 minecraft:green_stained_glass
setblock 483 79 249 minecraft:lime_stained_glass
setblock 483 79 251 minecraft:green_stained_glass
fill 483 79 252 484 79 252 minecraft:lime_stained_glass
setblock 483 79 254 minecraft:green_stained_glass
setblock 483 79 259 minecraft:green_stained_glass
fill 483 79 260 485 79 260 minecraft:lime_stained_glass
setblock 483 79 263 minecraft:green_stained_glass
fill 483 79 264 485 79 264 minecraft:lime_stained_glass
setblock 483 79 267 minecraft:green_stained_glass
fill 483 79 268 485 79 268 minecraft:lime_stained_glass
setblock 484 79 229 minecraft:lime_stained_glass
setblock 484 79 230 minecraft:green_stained_glass
fill 484 79 231 484 79 233 minecraft:lime_stained_glass
setblock 484 79 234 minecraft:green_stained_glass
fill 484 79 235 486 79 235 minecraft:lime_stained_glass
setblock 484 79 237 minecraft:yellow_concrete
fill 484 79 242 484 79 243 minecraft:lime_stained_glass
setblock 484 79 244 minecraft:green_stained_glass
fill 484 79 245 484 79 246 minecraft:lime_stained_glass
fill 484 79 247 484 79 249 minecraft:lime_concrete
setblock 484 79 250 minecraft:green_stained_glass
setblock 484 79 251 minecraft:lime_stained_glass
setblock 484 79 253 minecraft:green_stained_glass
fill 484 79 254 485 79 254 minecraft:lime_stained_glass
setblock 484 79 259 minecraft:lime_concrete
setblock 484 79 262 minecraft:green_stained_glass
fill 484 79 263 486 79 263 minecraft:lime_stained_glass
setblock 484 79 266 minecraft:green_stained_glass
fill 484 79 267 486 79 267 minecraft:lime_stained_glass
setblock 485 79 229 minecraft:green_stained_glass
fill 485 79 230 485 79 232 minecraft:lime_stained_glass
setblock 485 79 233 minecraft:green_stained_glass
fill 485 79 234 487 79 234 minecraft:lime_stained_glass
fill 485 79 241 485 79 242 minecraft:lime_stained_glass
setblock 485 79 243 minecraft:green_stained_glass
fill 485 79 244 486 79 244 minecraft:lime_stained_glass
fill 485 79 245 485 79 247 minecraft:lime_concrete
fill 485 79 249 485 79 251 minecraft:lime_concrete
setblock 485 79 252 minecraft:green_stained_glass
fill 485 79 253 486 79 253 minecraft:lime_stained_glass
setblock 485 79 255 minecraft:green_stained_glass
setblock 485 79 261 minecraft:green_stained_glass
fill 485 79 262 487 79 262 minecraft:lime_stained_glass
setblock 485 79 265 minecraft:green_stained_glass
fill 485 79 266 487 79 266 minecraft:lime_stained_glass
setblock 485 79 269 minecraft:green_stained_glass
fill 486 79 229 486 79 231 minecraft:lime_stained_glass
setblock 486 79 232 minecraft:green_stained_glass
fill 486 79 233 488 79 233 minecraft:lime_stained_glass
setblock 486 79 236 minecraft:green_stained_glass
setblock 486 79 241 minecraft:lime_stained_glass
setblock 486 79 242 minecraft:green_stained_glass
fill 486 79 243 487 79 243 minecraft:lime_stained_glass
fill 486 79 245 487 79 245 minecraft:lime_concrete
fill 486 79 251 487 79 251 minecraft:lime_concrete
setblock 486 79 252 minecraft:lime_stained_glass
setblock 486 79 254 minecraft:green_stained_glass
fill 486 79 255 487 79 255 minecraft:lime_stained_glass
setblock 486 79 260 minecraft:green_stained_glass
fill 486 79 261 488 79 261 minecraft:lime_stained_glass
setblock 486 79 264 minecraft:green_stained_glass
fill 486 79 265 488 79 265 minecraft:lime_stained_glass
setblock 486 79 268 minecraft:green_stained_glass
fill 486 79 269 487 79 269 minecraft:lime_stained_glass
fill 487 79 229 487 79 230 minecraft:lime_stained_glass
setblock 487 79 231 minecraft:green_stained_glass
fill 487 79 232 489 79 232 minecraft:lime_stained_glass
setblock 487 79 235 minecraft:green_stained_glass
fill 487 79 236 489 79 236 minecraft:lime_stained_glass
setblock 487 79 241 minecraft:green_stained_glass
fill 487 79 242 488 79 242 minecraft:lime_stained_glass
fill 487 79 244 489 79 244 minecraft:lime_concrete
fill 487 79 252 489 79 252 minecraft:lime_concrete
setblock 487 79 253 minecraft:green_stained_glass
fill 487 79 254 488 79 254 minecraft:lime_stained_glass
fill 487 79 260 489 79 260 minecraft:lime_stained_glass
setblock 487 79 263 minecraft:green_stained_glass
fill 487 79 264 489 79 264 minecraft:lime_stained_glass
setblock 487 79 267 minecraft:green_stained_glass
fill 487 79 268 489 79 268 minecraft:lime_stained_glass
setblock 488 79 229 minecraft:lime_stained_glass
setblock 488 79 230 minecraft:green_stained_glass
fill 488 79 231 490 79 231 minecraft:lime_stained_glass
setblock 488 79 234 minecraft:green_stained_glass
fill 488 79 235 490 79 235 minecraft:lime_stained_glass
setblock 488 79 240 minecraft:green_stained_glass
fill 488 79 241 489 79 241 minecraft:lime_stained_glass
setblock 488 79 243 minecraft:green_stained_glass
fill 488 79 253 489 79 253 minecraft:lime_stained_glass
setblock 488 79 255 minecraft:green_stained_glass
setblock 488 79 262 minecraft:green_stained_glass
fill 488 79 263 490 79 263 minecraft:lime_stained_glass
setblock 488 79 266 minecraft:green_stained_glass
fill 488 79 267 490 79 267 minecraft:lime_stained_glass
setblock 489 79 229 minecraft:green_stained_glass
fill 489 79 230 491 79 230 minecraft:lime_stained_glass
setblock 489 79 233 minecraft:green_stained_glass
fill 489 79 234 491 79 234 minecraft:lime_stained_glass
setblock 489 79 242 minecraft:green_stained_glass
fill 489 79 243 490 79 243 minecraft:lime_stained_glass
fill 489 79 245 491 79 245 minecraft:lime_concrete
fill 489 79 251 491 79 251 minecraft:lime_concrete
setblock 489 79 254 minecraft:green_stained_glass
fill 489 79 255 490 79 255 minecraft:lime_stained_glass
setblock 489 79 261 minecraft:green_stained_glass
fill 489 79 262 491 79 262 minecraft:lime_stained_glass
setblock 489 79 265 minecraft:green_stained_glass
fill 489 79 266 491 79 266 minecraft:lime_stained_glass
setblock 489 79 269 minecraft:green_stained_glass
fill 490 79 229 492 79 229 minecraft:lime_stained_glass
setblock 490 79 232 minecraft:green_stained_glass
fill 490 79 233 492 79 233 minecraft:lime_stained_glass
setblock 490 79 236 minecraft:green_stained_glass
setblock 490 79 241 minecraft:green_stained_glass
fill 490 79 242 491 79 242 minecraft:lime_stained_glass
setblock 490 79 244 minecraft:green_stained_glass
setblock 490 79 252 minecraft:lime_stained_glass
setblock 490 79 253 minecraft:green_stained_glass
fill 490 79 254 491 79 254 minecraft:lime_stained_glass
setblock 490 79 260 minecraft:green_stained_glass
fill 490 79 261 492 79 261 minecraft:lime_stained_glass
setblock 490 79 264 minecraft:green_stained_glass
fill 490 79 265 492 79 265 minecraft:lime_stained_glass
setblock 490 79 268 minecraft:green_stained_glass
fill 490 79 269 492 79 269 minecraft:lime_stained_glass
setblock 491 79 231 minecraft:green_stained_glass
fill 491 79 232 493 79 232 minecraft:lime_stained_glass
setblock 491 79 235 minecraft:green_stained_glass
fill 491 79 236 493 79 236 minecraft:lime_stained_glass
setblock 491 79 241 minecraft:lime_stained_glass
setblock 491 79 243 minecraft:green_stained_glass
fill 491 79 244 492 79 244 minecraft:lime_stained_glass
fill 491 79 246 491 79 247 minecraft:lime_concrete
fill 491 79 249 491 79 250 minecraft:lime_concrete
setblock 491 79 252 minecraft:green_stained_glass
fill 491 79 253 492 79 253 minecraft:lime_stained_glass
setblock 491 79 255 minecraft:green_stained_glass
fill 491 79 260 493 79 260 minecraft:lime_stained_glass
setblock 491 79 263 minecraft:green_stained_glass
fill 491 79 264 493 79 264 minecraft:lime_stained_glass
setblock 491 79 267 minecraft:green_stained_glass
fill 491 79 268 493 79 268 minecraft:lime_stained_glass
setblock 492 79 230 minecraft:green_stained_glass
fill 492 79 231 494 79 231 minecraft:lime_stained_glass
setblock 492 79 234 minecraft:green_stained_glass
fill 492 79 235 494 79 235 minecraft:lime_stained_glass
setblock 492 79 237 minecraft:lime_concrete
setblock 492 79 242 minecraft:green_stained_glass
fill 492 79 243 493 79 243 minecraft:lime_stained_glass
setblock 492 79 245 minecraft:green_stained_glass
fill 492 79 246 493 79 246 minecraft:lime_stained_glass
fill 492 79 247 492 79 249 minecraft:lime_concrete
setblock 492 79 250 minecraft:lime_stained_glass
setblock 492 79 251 minecraft:green_stained_glass
fill 492 79 252 493 79 252 minecraft:lime_stained_glass
setblock 492 79 254 minecraft:green_stained_glass
setblock 492 79 259 minecraft:yellow_concrete
setblock 492 79 262 minecraft:green_stained_glass
fill 492 79 263 494 79 263 minecraft:lime_stained_glass
setblock 492 79 266 minecraft:green_stained_glass
fill 492 79 267 494 79 267 minecraft:lime_stained_glass
setblock 493 79 229 minecraft:green_stained_glass
fill 493 79 230 495 79 230 minecraft:lime_stained_glass
setblock 493 79 233 minecraft:green_stained_glass
fill 493 79 234 495 79 234 minecraft:lime_stained_glass
setblock 493 79 237 minecraft:green_stained_glass
setblock 493 79 242 minecraft:lime_stained_glass
setblock 493 79 244 minecraft:green_stained_glass
fill 493 79 245 494 79 245 minecraft:lime_stained_glass
setblock 493 79 247 minecraft:green_stained_glass
fill 493 79 248 493 79 249 minecraft:lime_stained_glass
setblock 493 79 250 minecraft:green_stained_glass
fill 493 79 251 494 79 251 minecraft:lime_stained_glass
setblock 493 79 253 minecraft:green_stained_glass
setblock 493 79 254 minecraft:lime_stained_glass
fill 493 79 259 494 79 259 minecraft:lime_stained_glass
setblock 493 79 261 minecraft:green_stained_glass
fill 493 79 262 495 79 262 minecraft:lime_stained_glass
setblock 493 79 265 minecraft:green_stained_glass
fill 493 79 266 495 79 266 minecraft:lime_stained_glass
setblock 493 79 269 minecraft:green_stained_glass
fill 494 79 229 496 79 229 minecraft:lime_stained_glass
setblock 494 79 232 minecraft:green_stained_glass
fill 494 79 233 496 79 233 minecraft:lime_stained_glass
setblock 494 79 236 minecraft:green_stained_glass
fill 494 79 237 496 79 237 minecraft:lime_stained_glass
setblock 494 79 243 minecraft:green_stained_glass
setblock 494 79 244 minecraft:lime_stained_glass
setblock 494 79 246 minecraft:green_stained_glass
fill 494 79 247 494 79 248 minecraft:lime_stained_glass
setblock 494 79 249 minecraft:green_stained_glass
fill 494 79 250 495 79 250 minecraft:lime_stained_glass
setblock 494 79 252 minecraft:green_stained_glass
setblock 494 79 253 minecraft:lime_stained_glass
setblock 494 79 260 minecraft:green_stained_glass
fill 494 79 261 496 79 261 minecraft:lime_stained_glass
setblock 494 79 264 minecraft:green_stained_glass
fill 494 79 265 496 79 265 minecraft:lime_stained_glass
setblock 494 79 268 minecraft:green_stained_glass
fill 494 79 269 495 79 269 minecraft:lime_stained_glass
setblock 495 79 231 minecraft:green_stained_glass
fill 495 79 232 497 79 232 minecraft:lime_stained_glass
setblock 495 79 235 minecraft:green_stained_glass
fill 495 79 236 497 79 236 minecraft:lime_stained_glass
setblock 495 79 238 minecraft:lime_stained_glass
setblock 495 79 245 minecraft:green_stained_glass
fill 495 79 246 495 79 247 minecraft:lime_stained_glass
setblock 495 79 248 minecraft:green_stained_glass
setblock 495 79 249 minecraft:lime_stained_glass
setblock 495 79 251 minecraft:green_stained_glass
setblock 495 79 258 minecraft:lime_stained_glass
setblock 495 79 259 minecraft:green_stained_glass
fill 495 79 260 497 79 260 minecraft:lime_stained_glass
setblock 495 79 263 minecraft:green_stained_glass
fill 495 79 264 497 79 264 minecraft:lime_stained_glass
setblock 495 79 267 minecraft:green_stained_glass
fill 495 79 268 497 79 268 minecraft:lime_stained_glass
setblock 496 79 230 minecraft:green_stained_glass
fill 496 79 231 498 79 231 minecraft:lime_stained_glass
setblock 496 79 234 minecraft:green_stained_glass
fill 496 79 235 498 79 235 minecraft:lime_stained_glass
setblock 496 79 238 minecraft:green_stained_glass
fill 496 79 239 498 79 239 minecraft:lime_stained_glass
setblock 496 79 248 minecraft:lime_stained_glass
setblock 496 79 257 minecraft:lime_stained_glass
setblock 496 79 258 minecraft:green_stained_glass
fill 496 79 259 498 79 259 minecraft:lime_stained_glass
setblock 496 79 262 minecraft:green_stained_glass
fill 496 79 263 498 79 263 minecraft:lime_stained_glass
setblock 496 79 266 minecraft:green_stained_glass
fill 496 79 267 498 79 267 minecraft:lime_stained_glass
setblock 497 79 229 minecraft:green_stained_glass
fill 497 79 230 499 79 230 minecraft:lime_stained_glass
setblock 497 79 233 minecraft:green_stained_glass
fill 497 79 234 499 79 234 minecraft:lime_stained_glass
setblock 497 79 237 minecraft:green_stained_glass
fill 497 79 238 499 79 238 minecraft:lime_stained_glass
setblock 497 79 240 minecraft:lime_stained_glass
setblock 497 79 256 minecraft:lime_stained_glass
setblock 497 79 257 minecraft:green_stained_glass
fill 497 79 258 499 79 258 minecraft:lime_stained_glass
setblock 497 79 261 minecraft:green_stained_glass
fill 497 79 262 499 79 262 minecraft:lime_stained_glass
setblock 497 79 265 minecraft:green_stained_glass
fill 497 79 266 499 79 266 minecraft:lime_stained_glass
setblock 497 79 269 minecraft:green_stained_glass
fill 498 79 229 500 79 229 minecraft:lime_stained_glass
setblock 498 79 232 minecraft:green_stained_glass
fill 498 79 233 500 79 233 minecraft:lime_stained_glass
setblock 498 79 236 minecraft:green_stained_glass
fill 498 79 237 500 79 237 minecraft:lime_stained_glass
setblock 498 79 240 minecraft:green_stained_glass
fill 498 79 241 500 79 241 minecraft:lime_stained_glass
setblock 498 79 255 minecraft:lime_stained_glass
setblock 498 79 256 minecraft:green_stained_glass
fill 498 79 257 500 79 257 minecraft:lime_stained_glass
setblock 498 79 260 minecraft:green_stained_glass
fill 498 79 261 500 79 261 minecraft:lime_stained_glass
setblock 498 79 264 minecraft:green_stained_glass
fill 498 79 265 500 79 265 minecraft:lime_stained_glass
setblock 498 79 268 minecraft:green_stained_glass
fill 498 79 269 500 79 269 minecraft:lime_stained_glass
setblock 499 79 231 minecraft:green_stained_glass
fill 499 79 232 501 79 232 minecraft:lime_stained_glass
setblock 499 79 235 minecraft:green_stained_glass
fill 499 79 236 501 79 236 minecraft:lime_stained_glass
setblock 499 79 239 minecraft:green_stained_glass
fill 499 79 240 501 79 240 minecraft:lime_stained_glass
setblock 499 79 242 minecraft:lime_stained_glass
setblock 499 79 243 minecraft:green_stained_glass
setblock 499 79 244 minecraft:purple_concrete
setblock 499 79 252 minecraft:red_concrete
fill 499 79 253 499 79 254 minecraft:lime_stained_glass
setblock 499 79 255 minecraft:green_stained_glass
fill 499 79 256 501 79 256 minecraft:lime_stained_glass
setblock 499 79 259 minecraft:green_stained_glass
fill 499 79 260 501 79 260 minecraft:lime_stained_glass
setblock 499 79 263 minecraft:green_stained_glass
fill 499 79 264 501 79 264 minecraft:lime_stained_glass
setblock 499 79 267 minecraft:green_stained_glass
fill 499 79 268 501 79 268 minecraft:lime_stained_glass
setblock 500 79 230 minecraft:green_stained_glass
fill 500 79 231 502 79 231 minecraft:lime_stained_glass
setblock 500 79 234 minecraft:green_stained_glass
fill 500 79 235 502 79 235 minecraft:lime_stained_glass
setblock 500 79 238 minecraft:green_stained_glass
fill 500 79 239 502 79 239 minecraft:lime_stained_glass
setblock 500 79 242 minecraft:green_stained_glass
fill 500 79 243 500 79 245 minecraft:lime_stained_glass
setblock 500 79 246 minecraft:green_stained_glass
fill 500 79 247 500 79 249 minecraft:lime_stained_glass
setblock 500 79 250 minecraft:green_stained_glass
fill 500 79 251 500 79 253 minecraft:lime_stained_glass
setblock 500 79 254 minecraft:green_stained_glass
fill 500 79 255 502 79 255 minecraft:lime_stained_glass
setblock 500 79 258 minecraft:green_stained_glass
fill 500 79 259 502 79 259 minecraft:lime_stained_glass
setblock 500 79 262 minecraft:green_stained_glass
fill 500 79 263 502 79 263 minecraft:lime_stained_glass
setblock 500 79 266 minecraft:green_stained_glass
fill 500 79 267 502 79 267 minecraft:lime_stained_glass
setblock 501 79 229 minecraft:green_stained_glass
fill 501 79 230 503 79 230 minecraft:lime_stained_glass
setblock 501 79 233 minecraft:green_stained_glass
fill 501 79 234 503 79 234 minecraft:lime_stained_glass
setblock 501 79 237 minecraft:green_stained_glass
fill 501 79 238 503 79 238 minecraft:lime_stained_glass
setblock 501 79 241 minecraft:green_stained_glass
fill 501 79 242 501 79 244 minecraft:lime_stained_glass
setblock 501 79 245 minecraft:green_stained_glass
fill 501 79 246 501 79 248 minecraft:lime_stained_glass
setblock 501 79 249 minecraft:green_stained_glass
fill 501 79 250 501 79 252 minecraft:lime_stained_glass
setblock 501 79 253 minecraft:green_stained_glass
fill 501 79 254 503 79 254 minecraft:lime_stained_glass
setblock 501 79 257 minecraft:green_stained_glass
fill 501 79 258 503 79 258 minecraft:lime_stained_glass
setblock 501 79 261 minecraft:green_stained_glass
fill 501 79 262 503 79 262 minecraft:lime_stained_glass
setblock 501 79 265 minecraft:green_stained_glass
fill 501 79 266 503 79 266 minecraft:lime_stained_glass
setblock 501 79 269 minecraft:green_stained_glass
fill 502 79 229 504 79 229 minecraft:lime_stained_glass
setblock 502 79 232 minecraft:green_stained_glass
fill 502 79 233 504 79 233 minecraft:lime_stained_glass
setblock 502 79 236 minecraft:green_stained_glass
fill 502 79 237 504 79 237 minecraft:lime_stained_glass
setblock 502 79 240 minecraft:green_stained_glass
fill 502 79 241 502 79 243 minecraft:lime_stained_glass
setblock 502 79 244 minecraft:green_stained_glass
fill 502 79 245 502 79 247 minecraft:lime_stained_glass
setblock 502 79 248 minecraft:green_stained_glass
fill 502 79 249 502 79 251 minecraft:lime_stained_glass
setblock 502 79 252 minecraft:green_stained_glass
fill 502 79 253 504 79 253 minecraft:lime_stained_glass
setblock 502 79 256 minecraft:green_stained_glass
fill 502 79 257 504 79 257 minecraft:lime_stained_glass
setblock 502 79 260 minecraft:green_stained_glass
fill 502 79 261 504 79 261 minecraft:lime_stained_glass
setblock 502 79 264 minecraft:green_stained_glass
fill 502 79 265 504 79 265 minecraft:lime_stained_glass
setblock 502 79 268 minecraft:green_stained_glass
fill 502 79 269 504 79 269 minecraft:lime_stained_glass
setblock 503 79 231 minecraft:green_stained_glass
fill 503 79 232 505 79 232 minecraft:lime_stained_glass
setblock 503 79 235 minecraft:green_stained_glass
fill 503 79 236 505 79 236 minecraft:lime_stained_glass
setblock 503 79 239 minecraft:green_stained_glass
fill 503 79 240 503 79 242 minecraft:lime_stained_glass
setblock 503 79 243 minecraft:green_stained_glass
fill 503 79 244 503 79 246 minecraft:lime_stained_glass
setblock 503 79 247 minecraft:green_stained_glass
fill 503 79 248 503 79 250 minecraft:lime_stained_glass
setblock 503 79 251 minecraft:green_stained_glass
fill 503 79 252 505 79 252 minecraft:lime_stained_glass
setblock 503 79 255 minecraft:green_stained_glass
fill 503 79 256 505 79 256 minecraft:lime_stained_glass
setblock 503 79 259 minecraft:green_stained_glass
fill 503 79 260 505 79 260 minecraft:lime_stained_glass
setblock 503 79 263 minecraft:green_stained_glass
fill 503 79 264 505 79 264 minecraft:lime_stained_glass
setblock 503 79 267 minecraft:green_stained_glass
fill 503 79 268 505 79 268 minecraft:lime_stained_glass
setblock 504 79 230 minecraft:green_stained_glass
fill 504 79 231 506 79 231 minecraft:lime_stained_glass
setblock 504 79 234 minecraft:green_stained_glass
fill 504 79 235 506 79 235 minecraft:lime_stained_glass
setblock 504 79 238 minecraft:green_stained_glass
fill 504 79 239 504 79 241 minecraft:lime_stained_glass
setblock 504 79 242 minecraft:green_stained_glass
fill 504 79 243 504 79 245 minecraft:lime_stained_glass
setblock 504 79 246 minecraft:green_stained_glass
fill 504 79 247 504 79 249 minecraft:lime_stained_glass
setblock 504 79 250 minecraft:green_stained_glass
fill 504 79 251 506 79 251 minecraft:lime_stained_glass
setblock 504 79 254 minecraft:green_stained_glass
fill 504 79 255 506 79 255 minecraft:lime_stained_glass
setblock 504 79 258 minecraft:green_stained_glass
fill 504 79 259 506 79 259 minecraft:lime_stained_glass
setblock 504 79 262 minecraft:green_stained_glass
fill 504 79 263 506 79 263 minecraft:lime_stained_glass
setblock 504 79 266 minecraft:green_stained_glass
fill 504 79 267 506 79 267 minecraft:lime_stained_glass
setblock 505 79 229 minecraft:green_stained_glass
fill 505 79 230 506 79 230 minecraft:lime_stained_glass
setblock 505 79 233 minecraft:green_stained_glass
fill 505 79 234 507 79 234 minecraft:lime_stained_glass
setblock 505 79 237 minecraft:green_stained_glass
fill 505 79 238 505 79 240 minecraft:lime_stained_glass
setblock 505 79 241 minecraft:green_stained_glass
fill 505 79 242 505 79 244 minecraft:lime_stained_glass
setblock 505 79 245 minecraft:green_stained_glass
fill 505 79 246 505 79 248 minecraft:lime_stained_glass
setblock 505 79 249 minecraft:green_stained_glass
fill 505 79 250 507 79 250 minecraft:lime_stained_glass
setblock 505 79 253 minecraft:green_stained_glass
fill 505 79 254 507 79 254 minecraft:lime_stained_glass
setblock 505 79 257 minecraft:green_stained_glass
fill 505 79 258 507 79 258 minecraft:lime_stained_glass
setblock 505 79 261 minecraft:green_stained_glass
fill 505 79 262 507 79 262 minecraft:lime_stained_glass
setblock 505 79 265 minecraft:green_stained_glass
fill 505 79 266 506 79 266 minecraft:lime_stained_glass
setblock 505 79 269 minecraft:green_stained_glass
fill 506 79 229 507 79 229 minecraft:lime_stained_glass
setblock 506 79 232 minecraft:green_stained_glass
fill 506 79 233 507 79 233 minecraft:lime_stained_glass
setblock 506 79 236 minecraft:green_stained_glass
fill 506 79 237 506 79 239 minecraft:lime_stained_glass
setblock 506 79 240 minecraft:green_stained_glass
fill 506 79 241 506 79 243 minecraft:lime_stained_glass
setblock 506 79 244 minecraft:green_stained_glass
fill 506 79 245 506 79 247 minecraft:lime_stained_glass
setblock 506 79 248 minecraft:green_stained_glass
fill 506 79 249 508 79 249 minecraft:lime_stained_glass
setblock 506 79 252 minecraft:green_stained_glass
fill 506 79 253 508 79 253 minecraft:lime_stained_glass
setblock 506 79 256 minecraft:green_stained_glass
fill 506 79 257 508 79 257 minecraft:lime_stained_glass
setblock 506 79 260 minecraft:green_stained_glass
fill 506 79 261 508 79 261 minecraft:lime_stained_glass
setblock 506 79 264 minecraft:green_stained_glass
fill 506 79 265 507 79 265 minecraft:lime_stained_glass
setblock 506 79 268 minecraft:green_stained_glass
fill 506 79 269 507 79 269 minecraft:lime_stained_glass
fill 507 79 230 507 83 230 minecraft:white_concrete
setblock 507 79 235 minecraft:green_stained_glass
fill 507 79 236 507 79 238 minecraft:lime_stained_glass
setblock 507 79 239 minecraft:green_stained_glass
fill 507 79 240 507 79 242 minecraft:lime_stained_glass
setblock 507 79 243 minecraft:green_stained_glass
fill 507 79 244 507 79 246 minecraft:lime_stained_glass
setblock 507 79 247 minecraft:green_stained_glass
fill 507 79 248 509 79 248 minecraft:lime_stained_glass
setblock 507 79 251 minecraft:green_stained_glass
fill 507 79 252 509 79 252 minecraft:lime_stained_glass
setblock 507 79 255 minecraft:green_stained_glass
fill 507 79 256 509 79 256 minecraft:lime_stained_glass
setblock 507 79 259 minecraft:green_stained_glass
fill 507 79 260 509 79 260 minecraft:lime_stained_glass
setblock 507 79 263 minecraft:green_stained_glass
fill 507 79 264 509 79 264 minecraft:lime_stained_glass
fill 507 79 266 507 83 266 minecraft:white_concrete
setblock 508 79 234 minecraft:green_stained_glass
fill 508 79 235 508 79 237 minecraft:lime_stained_glass
setblock 508 79 238 minecraft:green_stained_glass
fill 508 79 239 508 79 241 minecraft:lime_stained_glass
setblock 508 79 242 minecraft:green_stained_glass
fill 508 79 243 508 79 245 minecraft:lime_stained_glass
setblock 508 79 246 minecraft:green_stained_glass
fill 508 79 247 510 79 247 minecraft:lime_stained_glass
setblock 508 79 250 minecraft:green_stained_glass
fill 508 79 251 510 79 251 minecraft:lime_stained_glass
setblock 508 79 254 minecraft:green_stained_glass
fill 508 79 255 510 79 255 minecraft:lime_stained_glass
setblock 508 79 258 minecraft:green_stained_glass
fill 508 79 259 510 79 259 minecraft:lime_stained_glass
setblock 508 79 262 minecraft:green_stained_glass
fill 508 79 263 510 79 263 minecraft:lime_stained_glass
fill 509 79 234 509 79 236 minecraft:lime_stained_glass
setblock 509 79 237 minecraft:green_stained_glass
fill 509 79 238 509 79 240 minecraft:lime_stained_glass
setblock 509 79 241 minecraft:green_stained_glass
fill 509 79 242 509 79 244 minecraft:lime_stained_glass
setblock 509 79 245 minecraft:green_stained_glass
fill 509 79 246 511 79 246 minecraft:lime_stained_glass
setblock 509 79 249 minecraft:green_stained_glass
fill 509 79 250 511 79 250 minecraft:lime_stained_glass
setblock 509 79 253 minecraft:green_stained_glass
fill 509 79 254 511 79 254 minecraft:lime_stained_glass
setblock 509 79 257 minecraft:green_stained_glass
fill 509 79 258 511 79 258 minecraft:lime_stained_glass
setblock 509 79 261 minecraft:green_stained_glass
fill 509 79 262 511 79 262 minecraft:lime_stained_glass
fill 510 79 232 511 82 232 minecraft:red_concrete
fill 510 79 234 510 79 235 minecraft:lime_stained_glass
setblock 510 79 236 minecraft:green_stained_glass
fill 510 79 237 510 79 239 minecraft:lime_stained_glass
setblock 510 79 240 minecraft:green_stained_glass
fill 510 79 241 510 79 243 minecraft:lime_stained_glass
setblock 510 79 244 minecraft:green_stained_glass
fill 510 79 245 511 79 245 minecraft:lime_stained_glass
setblock 510 79 248 minecraft:green_stained_glass
fill 510 79 249 511 79 249 minecraft:lime_stained_glass
setblock 510 79 252 minecraft:green_stained_glass
fill 510 79 253 511 79 253 minecraft:lime_stained_glass
setblock 510 79 256 minecraft:green_stained_glass
fill 510 79 257 511 79 257 minecraft:lime_stained_glass
setblock 510 79 260 minecraft:green_stained_glass
fill 510 79 261 511 79 261 minecraft:lime_stained_glass
setblock 510 79 264 minecraft:green_stained_glass
fill 510 79 268 511 82 268 minecraft:red_concrete
setblock 511 79 229 minecraft:lime_stained_glass
fill 511 79 233 511 79 234 minecraft:lime_stained_glass
setblock 511 79 235 minecraft:green_stained_glass
fill 511 79 236 511 79 238 minecraft:lime_stained_glass
setblock 511 79 239 minecraft:green_stained_glass
fill 511 79 240 511 79 242 minecraft:lime_stained_glass
setblock 511 79 243 minecraft:green_stained_glass
setblock 511 79 244 minecraft:lime_stained_glass
setblock 511 79 247 minecraft:green_stained_glass
setblock 511 79 248 minecraft:lime_stained_glass
setblock 511 79 251 minecraft:green_stained_glass
setblock 511 79 252 minecraft:lime_stained_glass
setblock 511 79 255 minecraft:green_stained_glass
setblock 511 79 256 minecraft:lime_stained_glass
setblock 511 79 259 minecraft:green_stained_glass
setblock 511 79 260 minecraft:lime_stained_glass
setblock 511 79 263 minecraft:green_stained_glass
fill 511 79 264 511 79 265 minecraft:lime_stained_glass
setblock 511 79 269 minecraft:lime_stained_glass
fill 471 80 231 471 83 232 minecraft:white_concrete
fill 471 80 267 471 83 268 minecraft:white_concrete
fill 472 80 231 472 83 231 minecraft:white_concrete
setblock 472 80 232 minecraft:red_concrete
fill 472 80 267 472 83 267 minecraft:white_concrete
setblock 472 80 268 minecraft:red_concrete
fill 473 80 231 475 83 231 minecraft:red_concrete
fill 473 80 267 475 83 267 minecraft:red_concrete
setblock 480 80 248 minecraft:red_concrete
setblock 481 80 245 minecraft:red_concrete
setblock 481 80 251 minecraft:purple_concrete
setblock 482 80 243 minecraft:orange_concrete
setblock 482 80 253 minecraft:light_blue_concrete
setblock 483 80 242 minecraft:orange_concrete
setblock 483 80 254 minecraft:light_blue_concrete
setblock 485 80 241 minecraft:yellow_concrete
setblock 485 80 255 minecraft:lime_concrete
setblock 488 80 240 minecraft:lime_concrete
setblock 488 80 256 minecraft:lime_concrete
setblock 491 80 241 minecraft:lime_concrete
setblock 491 80 255 minecraft:yellow_concrete
setblock 493 80 242 minecraft:light_blue_concrete
setblock 493 80 254 minecraft:orange_concrete
setblock 494 80 243 minecraft:light_blue_concrete
setblock 494 80 253 minecraft:orange_concrete
setblock 495 80 245 minecraft:purple_concrete
setblock 495 80 251 minecraft:red_concrete
setblock 496 80 248 minecraft:red_concrete
fill 507 80 231 507 83 232 minecraft:white_concrete
fill 507 80 267 507 83 268 minecraft:white_concrete
fill 508 80 231 508 83 231 minecraft:white_concrete
setblock 508 80 232 minecraft:red_concrete
fill 508 80 267 508 83 267 minecraft:white_concrete
setblock 508 80 268 minecraft:red_concrete
fill 509 80 231 511 83 231 minecraft:red_concrete
fill 509 80 267 511 83 267 minecraft:red_concrete
fill 472 81 232 472 83 233 minecraft:white_concrete
fill 472 81 268 472 83 269 minecraft:white_concrete
setblock 473 81 233 minecraft:red_concrete
setblock 473 81 269 minecraft:red_concrete
setblock 474 81 229 minecraft:white_concrete
fill 474 81 230 475 83 230 minecraft:red_concrete
setblock 474 81 265 minecraft:white_concrete
fill 474 81 266 475 84 266 minecraft:red_concrete
fill 508 81 232 508 85 233 minecraft:white_concrete
fill 508 81 268 508 83 269 minecraft:white_concrete
setblock 509 81 233 minecraft:red_concrete
setblock 509 81 269 minecraft:red_concrete
setblock 510 81 229 minecraft:white_concrete
fill 510 81 230 511 83 230 minecraft:red_concrete
setblock 510 81 265 minecraft:white_concrete
fill 510 81 266 511 83 266 minecraft:red_concrete
fill 473 82 229 473 83 230 minecraft:red_concrete
fill 473 82 232 473 83 233 minecraft:white_concrete
setblock 473 82 238 minecraft:light[level=12]
setblock 473 82 245 minecraft:light[level=12]
setblock 473 82 252 minecraft:light[level=12]
setblock 473 82 259 minecraft:light[level=12]
fill 473 82 265 473 83 266 minecraft:red_concrete
fill 473 82 268 473 83 269 minecraft:white_concrete
fill 474 82 229 474 83 229 minecraft:red_concrete
fill 474 82 265 474 85 265 minecraft:red_concrete
setblock 480 82 231 minecraft:light[level=12]
setblock 480 82 238 minecraft:light[level=12]
setblock 480 82 245 minecraft:light[level=12]
setblock 480 82 252 minecraft:light[level=12]
setblock 480 82 259 minecraft:light[level=12]
setblock 480 82 266 minecraft:light[level=12]
setblock 487 82 231 minecraft:light[level=12]
setblock 487 82 238 minecraft:light[level=12]
setblock 487 82 245 minecraft:light[level=12]
setblock 487 82 252 minecraft:light[level=12]
setblock 487 82 259 minecraft:light[level=12]
setblock 487 82 266 minecraft:light[level=12]
setblock 494 82 231 minecraft:light[level=12]
setblock 494 82 238 minecraft:light[level=12]
setblock 494 82 245 minecraft:light[level=12]
setblock 494 82 252 minecraft:light[level=12]
setblock 494 82 259 minecraft:light[level=12]
setblock 494 82 266 minecraft:light[level=12]
setblock 501 82 231 minecraft:light[level=12]
setblock 501 82 238 minecraft:light[level=12]
setblock 501 82 245 minecraft:light[level=12]
setblock 501 82 252 minecraft:light[level=12]
setblock 501 82 259 minecraft:light[level=12]
setblock 501 82 266 minecraft:light[level=12]
setblock 508 82 238 minecraft:light[level=12]
setblock 508 82 245 minecraft:light[level=12]
setblock 508 82 252 minecraft:light[level=12]
setblock 508 82 259 minecraft:light[level=12]
fill 509 82 229 509 83 230 minecraft:red_concrete
fill 509 82 232 509 83 233 minecraft:white_concrete
fill 509 82 265 509 83 266 minecraft:red_concrete
fill 509 82 268 509 83 269 minecraft:white_concrete
fill 510 82 229 510 83 229 minecraft:red_concrete
fill 510 82 265 510 83 265 minecraft:red_concrete
setblock 472 83 229 minecraft:red_concrete
setblock 472 83 230 minecraft:white_concrete
setblock 472 83 265 minecraft:red_concrete
setblock 472 83 266 minecraft:white_concrete
fill 474 83 232 474 87 233 minecraft:white_concrete
fill 474 83 268 474 83 269 minecraft:white_concrete
setblock 475 83 232 minecraft:red_concrete
setblock 475 83 268 minecraft:red_concrete
setblock 508 83 229 minecraft:red_concrete
setblock 508 83 230 minecraft:white_concrete
fill 508 83 265 508 87 265 minecraft:red_concrete
setblock 508 83 266 minecraft:white_concrete
fill 510 83 232 510 83 233 minecraft:white_concrete
fill 510 83 268 510 83 269 minecraft:white_concrete
setblock 511 83 232 minecraft:red_concrete
setblock 511 83 268 minecraft:red_concrete
fill 471 84 229 473 84 269 minecraft:black_concrete
fill 474 84 229 511 84 231 minecraft:black_concrete
fill 474 84 267 487 84 269 minecraft:black_concrete
fill 475 84 232 475 88 232 minecraft:white_concrete
setblock 481 84 239 minecraft:light[level=15]
setblock 481 84 247 minecraft:light[level=15]
setblock 481 84 255 minecraft:light[level=15]
setblock 481 84 263 minecraft:light[level=15]
fill 488 84 267 511 84 268 minecraft:black_concrete
setblock 489 84 239 minecraft:light[level=15]
setblock 489 84 247 minecraft:light[level=15]
setblock 489 84 255 minecraft:light[level=15]
setblock 489 84 263 minecraft:light[level=15]
fill 489 84 269 495 84 269 minecraft:black_concrete
setblock 497 84 239 minecraft:light[level=15]
setblock 497 84 247 minecraft:light[level=15]
setblock 497 84 255 minecraft:light[level=15]
setblock 497 84 263 minecraft:light[level=15]
fill 497 84 269 511 84 269 minecraft:black_concrete
setblock 505 84 239 minecraft:light[level=15]
setblock 505 84 247 minecraft:light[level=15]
setblock 505 84 255 minecraft:light[level=15]
setblock 505 84 263 minecraft:light[level=15]
fill 507 84 232 507 85 232 minecraft:white_concrete
fill 507 84 266 508 87 266 minecraft:red_concrete
fill 509 84 232 510 84 266 minecraft:black_concrete
fill 511 84 232 511 84 244 minecraft:black_concrete
fill 511 84 245 511 93 245 minecraft:brown_terracotta
fill 511 84 246 511 84 266 minecraft:black_concrete
fill 471 85 229 473 85 269 minecraft:gray_concrete
fill 474 85 229 511 85 231 minecraft:gray_concrete
setblock 474 85 266 minecraft:red_concrete
fill 474 85 267 487 85 269 minecraft:gray_concrete
fill 475 85 266 475 90 266 minecraft:white_concrete
fill 488 85 267 511 85 268 minecraft:gray_concrete
fill 489 85 269 511 85 269 minecraft:gray_concrete
fill 506 85 243 508 86 243 minecraft:lime_concrete
fill 507 85 242 507 86 242 minecraft:lime_concrete
fill 507 85 244 507 86 244 minecraft:lime_concrete
fill 509 85 232 510 85 266 minecraft:gray_concrete
fill 511 85 232 511 85 244 minecraft:gray_concrete
fill 511 85 246 511 85 266 minecraft:gray_concrete
fill 471 86 230 472 87 232 minecraft:red_concrete
setblock 471 86 258 minecraft:lime_concrete
fill 471 86 266 472 87 268 minecraft:red_concrete
fill 472 86 229 473 86 229 minecraft:red_concrete
fill 472 86 233 473 86 233 minecraft:white_concrete
setblock 472 86 239 minecraft:yellow_concrete
fill 472 86 265 472 87 265 minecraft:red_concrete
fill 472 86 269 474 86 269 minecraft:white_concrete
setblock 473 86 230 minecraft:red_concrete
fill 473 86 231 473 86 232 minecraft:white_concrete
setblock 473 86 243 minecraft:white_concrete
setblock 473 86 250 minecraft:lime_concrete
setblock 473 86 265 minecraft:lime_concrete
setblock 473 86 266 minecraft:red_concrete
fill 473 86 267 475 86 268 minecraft:white_concrete
fill 474 86 229 474 89 231 minecraft:white_concrete
fill 474 86 265 474 90 266 minecraft:white_concrete
fill 475 86 230 475 89 231 minecraft:white_concrete
setblock 477 86 268 minecraft:red_concrete
setblock 484 86 231 minecraft:magenta_concrete
setblock 488 86 229 minecraft:lime_concrete
setblock 492 86 268 minecraft:red_concrete
setblock 493 86 269 minecraft:red_concrete
fill 499 86 269 499 87 269 minecraft:brown_concrete
setblock 500 86 231 minecraft:red_concrete
setblock 500 86 267 minecraft:magenta_concrete
setblock 505 86 230 minecraft:light_blue_concrete
fill 507 86 230 508 87 232 minecraft:red_concrete
fill 507 86 267 508 89 268 minecraft:red_concrete
fill 508 86 229 509 86 229 minecraft:red_concrete
fill 508 86 233 510 86 233 minecraft:white_concrete
fill 508 86 269 510 86 269 minecraft:white_concrete
setblock 509 86 230 minecraft:red_concrete
fill 509 86 231 511 86 232 minecraft:white_concrete
setblock 509 86 240 minecraft:light_blue_concrete
fill 509 86 262 509 87 262 minecraft:brown_concrete
fill 509 86 265 509 86 266 minecraft:red_concrete
fill 509 86 267 511 86 268 minecraft:white_concrete
fill 510 86 229 510 90 230 minecraft:white_concrete
fill 510 86 265 510 90 266 minecraft:white_concrete
fill 511 86 230 511 90 230 minecraft:white_concrete
fill 511 86 266 511 90 266 minecraft:white_concrete
setblock 472 87 229 minecraft:red_concrete
fill 472 87 233 473 90 233 minecraft:red_concrete
fill 472 87 269 473 90 269 minecraft:red_concrete
fill 473 87 229 473 89 231 minecraft:white_concrete
fill 473 87 232 473 91 232 minecraft:red_concrete
fill 473 87 265 473 89 267 minecraft:white_concrete
fill 473 87 268 473 91 268 minecraft:red_concrete
fill 474 87 267 474 87 269 minecraft:white_concrete
fill 475 87 267 475 88 268 minecraft:white_concrete
setblock 508 87 229 minecraft:red_concrete
fill 508 87 233 509 90 233 minecraft:red_concrete
fill 508 87 269 509 90 269 minecraft:red_concrete
fill 509 87 229 509 89 231 minecraft:white_concrete
fill 509 87 232 509 91 232 minecraft:red_concrete
fill 509 87 265 509 89 267 minecraft:white_concrete
fill 509 87 268 509 91 268 minecraft:red_concrete
fill 510 87 231 510 87 233 minecraft:white_concrete
fill 510 87 267 510 87 269 minecraft:white_concrete
fill 511 87 231 511 88 232 minecraft:white_concrete
fill 511 87 267 511 88 268 minecraft:white_concrete
fill 471 88 230 471 88 232 minecraft:red_concrete
fill 471 88 266 471 88 268 minecraft:red_concrete
fill 472 88 229 472 92 230 minecraft:white_concrete
fill 472 88 231 472 89 232 minecraft:red_concrete
fill 472 88 265 472 92 266 minecraft:white_concrete
fill 472 88 267 472 89 268 minecraft:red_concrete
setblock 473 88 238 minecraft:light[level=12]
setblock 473 88 245 minecraft:light[level=12]
setblock 473 88 252 minecraft:light[level=12]
setblock 473 88 259 minecraft:light[level=12]
setblock 474 88 232 minecraft:white_concrete
fill 474 88 233 474 92 233 minecraft:red_concrete
fill 474 88 267 474 88 268 minecraft:white_concrete
fill 474 88 269 474 92 269 minecraft:red_concrete
setblock 480 88 231 minecraft:light[level=12]
setblock 480 88 238 minecraft:light[level=12]
setblock 480 88 245 minecraft:light[level=12]
setblock 480 88 252 minecraft:light[level=12]
setblock 480 88 259 minecraft:light[level=12]
setblock 480 88 266 minecraft:light[level=12]
setblock 487 88 231 minecraft:light[level=12]
setblock 487 88 238 minecraft:light[level=12]
setblock 487 88 245 minecraft:light[level=12]
setblock 487 88 252 minecraft:light[level=12]
setblock 487 88 259 minecraft:light[level=12]
setblock 487 88 266 minecraft:light[level=12]
setblock 494 88 231 minecraft:light[level=12]
setblock 494 88 238 minecraft:light[level=12]
setblock 494 88 245 minecraft:light[level=12]
setblock 494 88 252 minecraft:light[level=12]
setblock 494 88 259 minecraft:light[level=12]
setblock 494 88 266 minecraft:light[level=12]
setblock 501 88 231 minecraft:light[level=12]
setblock 501 88 238 minecraft:light[level=12]
setblock 501 88 245 minecraft:light[level=12]
setblock 501 88 252 minecraft:light[level=12]
setblock 501 88 259 minecraft:light[level=12]
setblock 501 88 266 minecraft:light[level=12]
fill 507 88 230 507 88 232 minecraft:red_concrete
setblock 507 88 266 minecraft:red_concrete
fill 508 88 229 508 92 230 minecraft:white_concrete
fill 508 88 231 508 89 232 minecraft:red_concrete
setblock 508 88 238 minecraft:light[level=12]
setblock 508 88 245 minecraft:light[level=12]
setblock 508 88 252 minecraft:light[level=12]
setblock 508 88 259 minecraft:light[level=12]
fill 508 88 265 508 92 266 minecraft:white_concrete
fill 510 88 231 510 88 232 minecraft:white_concrete
fill 510 88 233 510 92 233 minecraft:red_concrete
fill 510 88 267 510 88 268 minecraft:white_concrete
fill 510 88 269 510 92 269 minecraft:red_concrete
fill 471 89 230 471 93 230 minecraft:white_concrete
fill 471 89 231 471 89 232 minecraft:red_concrete
fill 471 89 266 471 93 266 minecraft:white_concrete
fill 471 89 267 471 89 268 minecraft:red_concrete
fill 474 89 232 475 92 232 minecraft:red_concrete
fill 474 89 267 475 89 267 minecraft:white_concrete
fill 474 89 268 475 92 268 minecraft:red_concrete
fill 507 89 230 507 93 230 minecraft:white_concrete
fill 507 89 231 507 89 232 minecraft:red_concrete
fill 507 89 266 507 93 266 minecraft:white_concrete
fill 510 89 231 511 89 231 minecraft:white_concrete
fill 510 89 232 511 92 232 minecraft:red_concrete
fill 510 89 267 511 89 267 minecraft:white_concrete
fill 510 89 268 511 92 268 minecraft:red_concrete
fill 471 90 231 471 94 232 minecraft:white_concrete
fill 471 90 267 471 94 268 minecraft:white_concrete
fill 472 90 231 472 94 231 minecraft:white_concrete
setblock 472 90 232 minecraft:red_concrete
fill 472 90 267 472 94 267 minecraft:white_concrete
setblock 472 90 268 minecraft:red_concrete
fill 473 90 229 474 90 230 minecraft:white_concrete
fill 473 90 231 475 94 231 minecraft:red_concrete
fill 473 90 265 473 91 266 minecraft:white_concrete
fill 473 90 267 475 94 267 minecraft:red_concrete
setblock 475 90 230 minecraft:white_concrete
fill 505 90 257 507 91 257 minecraft:lime_concrete
fill 506 90 256 506 91 256 minecraft:lime_concrete
fill 507 90 231 507 94 232 minecraft:white_concrete
fill 507 90 267 507 94 268 minecraft:white_concrete
fill 508 90 231 508 94 231 minecraft:white_concrete
setblock 508 90 232 minecraft:red_concrete
fill 508 90 267 508 94 267 minecraft:white_concrete
setblock 508 90 268 minecraft:red_concrete
fill 509 90 229 509 91 230 minecraft:white_concrete
fill 509 90 231 511 94 231 minecraft:red_concrete
fill 509 90 265 509 91 266 minecraft:white_concrete
fill 509 90 267 511 94 267 minecraft:red_concrete
fill 472 91 232 472 95 233 minecraft:white_concrete
fill 472 91 268 472 95 269 minecraft:white_concrete
fill 473 91 229 473 91 230 minecraft:white_concrete
setblock 473 91 233 minecraft:red_concrete
setblock 473 91 239 minecraft:light[level=15]
setblock 473 91 247 minecraft:light[level=15]
setblock 473 91 255 minecraft:light[level=15]
setblock 473 91 263 minecraft:light[level=15]
setblock 473 91 269 minecraft:red_concrete
setblock 474 91 229 minecraft:white_concrete
fill 474 91 230 475 94 230 minecraft:red_concrete
setblock 474 91 265 minecraft:white_concrete
fill 474 91 266 475 94 266 minecraft:red_concrete
setblock 481 91 231 minecraft:light[level=15]
setblock 481 91 239 minecraft:light[level=15]
setblock 481 91 247 minecraft:light[level=15]
setblock 481 91 255 minecraft:light[level=15]
setblock 481 91 263 minecraft:light[level=15]
setblock 489 91 231 minecraft:light[level=15]
setblock 489 91 239 minecraft:light[level=15]
setblock 489 91 247 minecraft:light[level=15]
setblock 489 91 255 minecraft:light[level=15]
setblock 489 91 263 minecraft:light[level=15]
setblock 497 91 231 minecraft:light[level=15]
setblock 497 91 239 minecraft:light[level=15]
setblock 497 91 247 minecraft:light[level=15]
setblock 497 91 255 minecraft:light[level=15]
setblock 497 91 263 minecraft:light[level=15]
setblock 505 91 231 minecraft:light[level=15]
setblock 505 91 239 minecraft:light[level=15]
setblock 505 91 247 minecraft:light[level=15]
setblock 505 91 255 minecraft:light[level=15]
setblock 505 91 263 minecraft:light[level=15]
fill 508 91 232 508 95 233 minecraft:white_concrete
fill 508 91 268 508 95 269 minecraft:white_concrete
setblock 509 91 233 minecraft:red_concrete
setblock 509 91 269 minecraft:red_concrete
setblock 510 91 229 minecraft:white_concrete
fill 510 91 230 511 94 230 minecraft:red_concrete
setblock 510 91 265 minecraft:white_concrete
fill 510 91 266 511 94 266 minecraft:red_concrete
fill 473 92 229 473 96 230 minecraft:red_concrete
fill 473 92 232 473 96 233 minecraft:white_concrete
fill 473 92 265 473 96 266 minecraft:red_concrete
fill 473 92 268 473 96 269 minecraft:white_concrete
fill 474 92 229 474 95 229 minecraft:red_concrete
fill 474 92 265 474 95 265 minecraft:red_concrete
fill 475 92 255 476 93 256 minecraft:light_blue_concrete
fill 477 92 256 477 93 256 minecraft:light_blue_concrete
fill 509 92 229 509 96 230 minecraft:red_concrete
fill 509 92 232 509 96 233 minecraft:white_concrete
fill 509 92 265 509 96 266 minecraft:red_concrete
fill 509 92 268 509 96 269 minecraft:white_concrete
fill 510 92 229 510 95 229 minecraft:red_concrete
fill 510 92 265 510 95 265 minecraft:red_concrete
fill 472 93 229 472 97 229 minecraft:red_concrete
setblock 472 93 230 minecraft:white_concrete
fill 472 93 265 472 97 265 minecraft:red_concrete
setblock 472 93 266 minecraft:white_concrete
fill 474 93 232 474 97 233 minecraft:white_concrete
fill 474 93 268 474 97 269 minecraft:white_concrete
setblock 475 93 232 minecraft:red_concrete
setblock 475 93 268 minecraft:red_concrete
fill 508 93 229 508 97 229 minecraft:red_concrete
setblock 508 93 230 minecraft:white_concrete
fill 508 93 265 508 97 265 minecraft:red_concrete
setblock 508 93 266 minecraft:white_concrete
fill 510 93 232 510 97 233 minecraft:white_concrete
fill 510 93 268 510 97 269 minecraft:white_concrete
setblock 511 93 232 minecraft:red_concrete
setblock 511 93 268 minecraft:red_concrete
fill 471 94 230 472 97 230 minecraft:red_concrete
fill 471 94 266 472 97 266 minecraft:red_concrete
setblock 473 94 238 minecraft:light[level=12]
setblock 473 94 245 minecraft:light[level=12]
setblock 473 94 252 minecraft:light[level=12]
setblock 473 94 259 minecraft:light[level=12]
fill 475 94 232 475 98 232 minecraft:white_concrete
fill 475 94 268 475 98 268 minecraft:white_concrete
setblock 480 94 231 minecraft:light[level=12]
setblock 480 94 238 minecraft:light[level=12]
setblock 480 94 245 minecraft:light[level=12]
setblock 480 94 252 minecraft:light[level=12]
setblock 480 94 259 minecraft:light[level=12]
setblock 480 94 266 minecraft:light[level=12]
setblock 487 94 231 minecraft:light[level=12]
setblock 487 94 238 minecraft:light[level=12]
setblock 487 94 245 minecraft:light[level=12]
setblock 487 94 252 minecraft:light[level=12]
setblock 487 94 259 minecraft:light[level=12]
setblock 487 94 266 minecraft:light[level=12]
setblock 494 94 231 minecraft:light[level=12]
setblock 494 94 238 minecraft:light[level=12]
setblock 494 94 245 minecraft:light[level=12]
setblock 494 94 252 minecraft:light[level=12]
setblock 494 94 259 minecraft:light[level=12]
setblock 494 94 266 minecraft:light[level=12]
setblock 501 94 231 minecraft:light[level=12]
setblock 501 94 238 minecraft:light[level=12]
setblock 501 94 245 minecraft:light[level=12]
setblock 501 94 252 minecraft:light[level=12]
setblock 501 94 259 minecraft:light[level=12]
setblock 501 94 266 minecraft:light[level=12]
fill 507 94 230 508 97 230 minecraft:red_concrete
fill 507 94 266 508 97 266 minecraft:red_concrete
setblock 508 94 238 minecraft:light[level=12]
setblock 508 94 245 minecraft:light[level=12]
setblock 508 94 252 minecraft:light[level=12]
setblock 508 94 259 minecraft:light[level=12]
fill 511 94 232 511 98 232 minecraft:white_concrete
fill 511 94 268 511 98 268 minecraft:white_concrete
fill 471 95 231 472 99 231 minecraft:red_concrete
setblock 471 95 232 minecraft:white_concrete
fill 471 95 267 472 99 267 minecraft:red_concrete
setblock 471 95 268 minecraft:white_concrete
fill 473 95 231 475 99 231 minecraft:white_concrete
fill 473 95 267 475 99 267 minecraft:white_concrete
setblock 474 95 230 minecraft:red_concrete
setblock 474 95 266 minecraft:red_concrete
fill 475 95 230 475 100 230 minecraft:white_concrete
fill 475 95 266 475 100 266 minecraft:white_concrete
fill 504 95 237 508 96 241 minecraft:brown_terracotta
fill 507 95 231 508 99 231 minecraft:red_concrete
setblock 507 95 232 minecraft:white_concrete
fill 507 95 267 508 99 267 minecraft:red_concrete
setblock 507 95 268 minecraft:white_concrete
fill 509 95 231 511 99 231 minecraft:white_concrete
fill 509 95 239 510 95 239 minecraft:brown_terracotta
fill 509 95 267 511 99 267 minecraft:white_concrete
setblock 510 95 230 minecraft:red_concrete
setblock 510 95 266 minecraft:red_concrete
fill 511 95 230 511 100 230 minecraft:white_concrete
fill 511 95 266 511 100 266 minecraft:white_concrete
fill 471 96 232 472 99 232 minecraft:red_concrete
fill 471 96 268 472 99 268 minecraft:red_concrete
setblock 472 96 233 minecraft:white_concrete
setblock 472 96 269 minecraft:white_concrete
fill 474 96 229 474 100 230 minecraft:white_concrete
fill 474 96 265 474 100 266 minecraft:white_concrete
fill 507 96 232 508 99 232 minecraft:red_concrete
fill 507 96 268 508 99 268 minecraft:red_concrete
setblock 508 96 233 minecraft:white_concrete
setblock 508 96 269 minecraft:white_concrete
fill 510 96 229 510 100 230 minecraft:white_concrete
fill 510 96 265 510 100 266 minecraft:white_concrete
fill 472 97 233 473 100 233 minecraft:red_concrete
fill 472 97 269 473 100 269 minecraft:red_concrete
fill 473 97 229 473 101 230 minecraft:white_concrete
fill 473 97 232 473 101 232 minecraft:red_concrete
fill 473 97 265 473 101 266 minecraft:white_concrete
fill 473 97 268 473 101 268 minecraft:red_concrete
fill 505 97 239 507 103 239 minecraft:white_concrete
fill 506 97 238 506 103 238 minecraft:white_concrete
fill 506 97 240 506 103 240 minecraft:white_concrete
fill 508 97 233 509 100 233 minecraft:red_concrete
fill 508 97 269 509 100 269 minecraft:red_concrete
fill 509 97 229 509 101 230 minecraft:white_concrete
fill 509 97 232 509 101 232 minecraft:red_concrete
fill 509 97 265 509 101 266 minecraft:white_concrete
fill 509 97 268 509 101 268 minecraft:red_concrete
setblock 471 98 230 minecraft:red_concrete
setblock 471 98 266 minecraft:red_concrete
fill 472 98 229 472 102 230 minecraft:white_concrete
fill 472 98 265 472 102 266 minecraft:white_concrete
setblock 473 98 239 minecraft:light[level=15]
setblock 473 98 247 minecraft:light[level=15]
setblock 473 98 255 minecraft:light[level=15]
setblock 473 98 263 minecraft:light[level=15]
setblock 474 98 232 minecraft:white_concrete
fill 474 98 233 474 102 233 minecraft:red_concrete
setblock 474 98 268 minecraft:white_concrete
fill 474 98 269 474 102 269 minecraft:red_concrete
setblock 481 98 231 minecraft:light[level=15]
setblock 481 98 239 minecraft:light[level=15]
setblock 481 98 247 minecraft:light[level=15]
setblock 481 98 255 minecraft:light[level=15]
setblock 481 98 263 minecraft:light[level=15]
setblock 489 98 231 minecraft:light[level=15]
setblock 489 98 239 minecraft:light[level=15]
setblock 489 98 247 minecraft:light[level=15]
setblock 489 98 255 minecraft:light[level=15]
setblock 489 98 263 minecraft:light[level=15]
setblock 497 98 231 minecraft:light[level=15]
setblock 497 98 239 minecraft:light[level=15]
setblock 497 98 247 minecraft:light[level=15]
setblock 497 98 255 minecraft:light[level=15]
setblock 497 98 263 minecraft:light[level=15]
setblock 505 98 231 minecraft:light[level=15]
setblock 505 98 247 minecraft:light[level=15]
setblock 505 98 255 minecraft:light[level=15]
setblock 505 98 263 minecraft:light[level=15]
setblock 507 98 230 minecraft:red_concrete
setblock 507 98 266 minecraft:red_concrete
fill 508 98 229 508 102 230 minecraft:white_concrete
fill 508 98 265 508 102 266 minecraft:white_concrete
setblock 510 98 232 minecraft:white_concrete
fill 510 98 233 510 102 233 minecraft:red_concrete
setblock 510 98 268 minecraft:white_concrete
fill 510 98 269 510 102 269 minecraft:red_concrete
fill 471 99 230 471 103 230 minecraft:white_concrete
fill 471 99 266 471 103 266 minecraft:white_concrete
fill 474 99 232 475 102 232 minecraft:red_concrete
fill 474 99 268 475 102 268 minecraft:red_concrete
fill 507 99 230 507 103 230 minecraft:white_concrete
fill 507 99 266 507 103 266 minecraft:white_concrete
fill 510 99 232 511 102 232 minecraft:red_concrete
fill 510 99 268 511 102 268 minecraft:red_concrete
fill 471 100 231 471 104 232 minecraft:white_concrete
fill 471 100 267 471 104 268 minecraft:white_concrete
fill 472 100 231 472 104 231 minecraft:white_concrete
setblock 472 100 232 minecraft:red_concrete
fill 472 100 267 472 104 267 minecraft:white_concrete
setblock 472 100 268 minecraft:red_concrete
fill 473 100 231 475 104 231 minecraft:red_concrete
setblock 473 100 238 minecraft:light[level=12]
setblock 473 100 245 minecraft:light[level=12]
setblock 473 100 252 minecraft:light[level=12]
setblock 473 100 259 minecraft:light[level=12]
fill 473 100 267 475 104 267 minecraft:red_concrete
setblock 480 100 231 minecraft:light[level=12]
setblock 480 100 238 minecraft:light[level=12]
setblock 480 100 245 minecraft:light[level=12]
setblock 480 100 252 minecraft:light[level=12]
setblock 480 100 259 minecraft:light[level=12]
setblock 480 100 266 minecraft:light[level=12]
fill 483 100 253 483 101 253 minecraft:yellow_concrete
setblock 487 100 231 minecraft:light[level=12]
setblock 487 100 238 minecraft:light[level=12]
setblock 487 100 245 minecraft:light[level=12]
setblock 487 100 252 minecraft:light[level=12]
setblock 487 100 259 minecraft:light[level=12]
setblock 487 100 266 minecraft:light[level=12]
setblock 494 100 231 minecraft:light[level=12]
setblock 494 100 238 minecraft:light[level=12]
setblock 494 100 245 minecraft:light[level=12]
setblock 494 100 252 minecraft:light[level=12]
setblock 494 100 259 minecraft:light[level=12]
setblock 494 100 266 minecraft:light[level=12]
setblock 501 100 231 minecraft:light[level=12]
setblock 501 100 238 minecraft:light[level=12]
setblock 501 100 245 minecraft:light[level=12]
setblock 501 100 252 minecraft:light[level=12]
setblock 501 100 259 minecraft:light[level=12]
setblock 501 100 266 minecraft:light[level=12]
fill 507 100 231 507 104 232 minecraft:white_concrete
fill 507 100 267 507 104 268 minecraft:white_concrete
fill 508 100 231 508 104 231 minecraft:white_concrete
setblock 508 100 232 minecraft:red_concrete
setblock 508 100 238 minecraft:light[level=12]
setblock 508 100 245 minecraft:light[level=12]
setblock 508 100 252 minecraft:light[level=12]
setblock 508 100 259 minecraft:light[level=12]
fill 508 100 267 508 104 267 minecraft:white_concrete
setblock 508 100 268 minecraft:red_concrete
fill 509 100 231 511 104 231 minecraft:red_concrete
fill 509 100 267 511 104 267 minecraft:red_concrete
fill 472 101 232 472 104 233 minecraft:white_concrete
fill 472 101 268 472 104 269 minecraft:white_concrete
setblock 473 101 233 minecraft:red_concrete
setblock 473 101 269 minecraft:red_concrete
setblock 474 101 229 minecraft:white_concrete
fill 474 101 230 475 104 230 minecraft:red_concrete
setblock 474 101 265 minecraft:white_concrete
fill 474 101 266 475 104 266 minecraft:red_concrete
fill 508 101 232 508 105 233 minecraft:white_concrete
fill 508 101 268 508 104 269 minecraft:white_concrete
setblock 509 101 233 minecraft:red_concrete
setblock 509 101 269 minecraft:red_concrete
setblock 510 101 229 minecraft:white_concrete
fill 510 101 230 511 104 230 minecraft:red_concrete
setblock 510 101 265 minecraft:white_concrete
fill 510 101 266 511 104 266 minecraft:red_concrete
fill 473 102 229 473 104 230 minecraft:red_concrete
fill 473 102 232 473 104 233 minecraft:white_concrete
fill 473 102 265 473 104 266 minecraft:red_concrete
fill 473 102 268 473 104 269 minecraft:white_concrete
fill 474 102 229 474 104 229 minecraft:red_concrete
fill 474 102 265 474 105 265 minecraft:red_concrete
fill 504 102 237 504 105 241 minecraft:magenta_concrete
fill 504 102 247 505 103 248 minecraft:lime_concrete
fill 505 102 237 505 105 238 minecraft:magenta_concrete
fill 505 102 240 505 105 241 minecraft:magenta_concrete
fill 506 102 237 508 105 237 minecraft:magenta_concrete
fill 506 102 241 508 105 241 minecraft:magenta_concrete
fill 507 102 238 508 105 238 minecraft:magenta_concrete
fill 507 102 240 508 105 240 minecraft:magenta_concrete
fill 508 102 239 508 105 239 minecraft:magenta_concrete
fill 509 102 229 509 104 230 minecraft:red_concrete
fill 509 102 232 509 104 233 minecraft:white_concrete
fill 509 102 265 509 104 266 minecraft:red_concrete
fill 509 102 268 509 104 269 minecraft:white_concrete
fill 510 102 229 510 104 229 minecraft:red_concrete
fill 510 102 265 510 104 265 minecraft:red_concrete
fill 472 103 229 472 104 229 minecraft:red_concrete
setblock 472 103 230 minecraft:white_concrete
fill 472 103 265 472 104 265 minecraft:red_concrete
setblock 472 103 266 minecraft:white_concrete
fill 474 103 232 474 107 233 minecraft:white_concrete
fill 474 103 268 474 104 269 minecraft:white_concrete
setblock 475 103 232 minecraft:red_concrete
setblock 475 103 268 minecraft:red_concrete
fill 503 103 237 503 104 241 minecraft:magenta_concrete
fill 504 103 236 508 104 236 minecraft:magenta_concrete
fill 504 103 242 508 104 242 minecraft:magenta_concrete
fill 508 103 229 508 104 229 minecraft:red_concrete
setblock 508 103 230 minecraft:white_concrete
fill 508 103 265 508 107 265 minecraft:red_concrete
setblock 508 103 266 minecraft:white_concrete
fill 509 103 237 509 104 241 minecraft:magenta_concrete
fill 510 103 232 510 104 233 minecraft:white_concrete
fill 510 103 268 510 104 269 minecraft:white_concrete
setblock 511 103 232 minecraft:red_concrete
setblock 511 103 268 minecraft:red_concrete
fill 471 104 230 472 104 230 minecraft:red_concrete
fill 471 104 266 472 104 266 minecraft:red_concrete
fill 475 104 232 475 108 232 minecraft:white_concrete
setblock 475 104 268 minecraft:white_concrete
fill 493 104 269 493 113 269 minecraft:brown_terracotta
fill 505 104 239 507 105 239 minecraft:magenta_concrete
fill 506 104 238 506 105 238 minecraft:magenta_concrete
fill 506 104 240 506 105 240 minecraft:magenta_concrete
fill 507 104 230 508 104 230 minecraft:red_concrete
fill 507 104 266 508 107 266 minecraft:red_concrete
setblock 511 104 232 minecraft:white_concrete
setblock 511 104 268 minecraft:white_concrete
fill 471 105 229 473 105 269 minecraft:black_concrete
fill 474 105 229 511 105 231 minecraft:black_concrete
setblock 474 105 266 minecraft:red_concrete
fill 474 105 267 492 105 269 minecraft:black_concrete
fill 475 105 266 475 110 266 minecraft:white_concrete
setblock 481 105 239 minecraft:light[level=15]
setblock 481 105 247 minecraft:light[level=15]
setblock 481 105 255 minecraft:light[level=15]
setblock 481 105 263 minecraft:light[level=15]
setblock 489 105 239 minecraft:light[level=15]
setblock 489 105 247 minecraft:light[level=15]
setblock 489 105 255 minecraft:light[level=15]
setblock 489 105 263 minecraft:light[level=15]
fill 493 105 267 511 105 268 minecraft:black_concrete
fill 494 105 269 511 105 269 minecraft:black_concrete
setblock 497 105 239 minecraft:light[level=15]
setblock 497 105 247 minecraft:light[level=15]
setblock 497 105 255 minecraft:light[level=15]
setblock 497 105 263 minecraft:light[level=15]
setblock 505 105 247 minecraft:light[level=15]
setblock 505 105 255 minecraft:light[level=15]
setblock 505 105 263 minecraft:light[level=15]
setblock 507 105 232 minecraft:white_concrete
fill 509 105 232 511 105 266 minecraft:black_concrete
fill 471 106 229 473 106 269 minecraft:gray_concrete
fill 474 106 229 511 106 231 minecraft:gray_concrete
fill 474 106 265 474 110 266 minecraft:white_concrete
fill 474 106 267 492 106 269 minecraft:gray_concrete
fill 479 106 241 480 107 241 minecraft:pink_concrete
setblock 480 106 238 minecraft:light[level=12]
setblock 480 106 245 minecraft:light[level=12]
setblock 480 106 252 minecraft:light[level=12]
setblock 480 106 259 minecraft:light[level=12]
setblock 480 106 266 minecraft:light[level=12]
setblock 487 106 238 minecraft:light[level=12]
setblock 487 106 245 minecraft:light[level=12]
setblock 487 106 252 minecraft:light[level=12]
setblock 487 106 259 minecraft:light[level=12]
setblock 487 106 266 minecraft:light[level=12]
fill 493 106 267 511 106 268 minecraft:gray_concrete
setblock 494 106 238 minecraft:light[level=12]
setblock 494 106 245 minecraft:light[level=12]
setblock 494 106 252 minecraft:light[level=12]
setblock 494 106 259 minecraft:light[level=12]
setblock 494 106 266 minecraft:light[level=12]
fill 494 106 269 511 106 269 minecraft:gray_concrete
setblock 501 106 238 minecraft:light[level=12]
setblock 501 106 245 minecraft:light[level=12]
setblock 501 106 252 minecraft:light[level=12]
setblock 501 106 259 minecraft:light[level=12]
setblock 501 106 266 minecraft:light[level=12]
fill 507 106 232 508 109 232 minecraft:red_concrete
setblock 508 106 233 minecraft:white_concrete
setblock 508 106 238 minecraft:light[level=12]
setblock 508 106 245 minecraft:light[level=12]
setblock 508 106 252 minecraft:light[level=12]
setblock 508 106 259 minecraft:light[level=12]
fill 509 106 232 511 106 266 minecraft:gray_concrete
fill 471 107 230 472 107 232 minecraft:red_concrete
fill 471 107 266 472 107 268 minecraft:red_concrete
setblock 472 107 229 minecraft:red_concrete
fill 472 107 233 473 110 233 minecraft:red_concrete
setblock 472 107 249 minecraft:lime_concrete
setblock 472 107 259 minecraft:light_blue_concrete
setblock 472 107 265 minecraft:red_concrete
fill 472 107 269 473 110 269 minecraft:red_concrete
fill 473 107 229 474 109 231 minecraft:white_concrete
fill 473 107 232 473 111 232 minecraft:red_concrete
setblock 473 107 262 minecraft:white_concrete
fill 473 107 265 473 109 267 minecraft:white_concrete
fill 473 107 268 473 111 268 minecraft:red_concrete
fill 474 107 267 474 107 269 minecraft:white_concrete
fill 475 107 230 475 109 231 minecraft:white_concrete
fill 475 107 267 475 108 268 minecraft:white_concrete
fill 476 107 268 476 108 268 minecraft:brown_concrete
fill 483 107 244 484 108 245 minecraft:light_blue_concrete
setblock 486 107 267 minecraft:magenta_concrete
fill 487 107 269 487 108 269 minecraft:brown_concrete
setblock 490 107 267 minecraft:lime_concrete
setblock 492 107 267 minecraft:yellow_concrete
setblock 495 107 230 minecraft:light_blue_concrete
setblock 498 107 269 minecraft:orange_concrete
setblock 501 107 230 minecraft:magenta_concrete
setblock 501 107 269 minecraft:yellow_concrete
fill 504 107 267 504 108 267 minecraft:brown_concrete
fill 507 107 230 508 107 231 minecraft:red_concrete
fill 507 107 267 508 109 268 minecraft:red_concrete
setblock 508 107 229 minecraft:red_concrete
fill 508 107 233 509 110 233 minecraft:red_concrete
fill 508 107 269 509 110 269 minecraft:red_concrete
fill 509 107 229 510 109 231 minecraft:white_concrete
fill 509 107 232 509 111 232 minecraft:red_concrete
fill 509 107 254 509 108 254 minecraft:brown_concrete
fill 509 107 265 510 109 267 minecraft:white_concrete
fill 509 107 268 509 111 268 minecraft:red_concrete
fill 510 107 232 510 107 233 minecraft:white_concrete
setblock 510 107 261 minecraft:orange_concrete
fill 510 107 268 510 107 269 minecraft:white_concrete
fill 511 107 230 511 108 232 minecraft:white_concrete
fill 511 107 266 511 108 268 minecraft:white_concrete
fill 471 108 230 471 108 232 minecraft:red_concrete
fill 471 108 266 471 108 268 minecraft:red_concrete
fill 472 108 229 472 112 230 minecraft:white_concrete
fill 472 108 231 472 109 232 minecraft:red_concrete
fill 472 108 265 472 112 266 minecraft:white_concrete
fill 472 108 267 472 109 268 minecraft:red_concrete
setblock 474 108 232 minecraft:white_concrete
fill 474 108 233 474 112 233 minecraft:red_concrete
fill 474 108 267 474 108 268 minecraft:white_concrete
fill 474 108 269 474 112 269 minecraft:red_concrete
fill 507 108 230 507 108 231 minecraft:red_concrete
setblock 507 108 266 minecraft:red_concrete
fill 508 108 229 508 112 230 minecraft:white_concrete
fill 508 108 231 508 109 231 minecraft:red_concrete
fill 508 108 265 508 112 266 minecraft:white_concrete
setblock 510 108 232 minecraft:white_concrete
fill 510 108 233 510 112 233 minecraft:red_concrete
setblock 510 108 268 minecraft:white_concrete
fill 510 108 269 510 112 269 minecraft:red_concrete
fill 471 109 230 471 113 230 minecraft:white_concrete
fill 471 109 231 471 109 232 minecraft:red_concrete
fill 471 109 266 471 113 266 minecraft:white_concrete
fill 471 109 267 471 109 268 minecraft:red_concrete
fill 474 109 232 475 112 232 minecraft:red_concrete
fill 474 109 267 475 109 267 minecraft:white_concrete
fill 474 109 268 475 112 268 minecraft:red_concrete
fill 507 109 230 507 113 230 minecraft:white_concrete
setblock 507 109 231 minecraft:red_concrete
fill 507 109 266 507 113 266 minecraft:white_concrete
fill 510 109 232 511 112 232 minecraft:red_concrete
fill 510 109 268 511 112 268 minecraft:red_concrete
fill 511 109 230 511 109 231 minecraft:white_concrete
fill 511 109 266 511 109 267 minecraft:white_concrete
fill 471 110 231 471 114 232 minecraft:white_concrete
fill 471 110 267 471 114 268 minecraft:white_concrete
fill 472 110 231 472 114 231 minecraft:white_concrete
setblock 472 110 232 minecraft:red_concrete
fill 472 110 267 472 114 267 minecraft:white_concrete
setblock 472 110 268 minecraft:red_concrete
fill 473 110 229 474 110 230 minecraft:white_concrete
fill 473 110 231 475 114 231 minecraft:red_concrete
fill 473 110 265 473 111 266 minecraft:white_concrete
fill 473 110 267 475 114 267 minecraft:red_concrete
setblock 475 110 230 minecraft:white_concrete
fill 507 110 231 507 114 232 minecraft:white_concrete
fill 507 110 267 507 114 268 minecraft:white_concrete
fill 508 110 231 508 114 231 minecraft:white_concrete
setblock 508 110 232 minecraft:red_concrete
fill 508 110 267 508 114 267 minecraft:white_concrete
setblock 508 110 268 minecraft:red_concrete
fill 509 110 229 510 110 230 minecraft:white_concrete
fill 509 110 231 511 114 231 minecraft:red_concrete
fill 509 110 265 510 110 266 minecraft:white_concrete
fill 509 110 267 511 114 267 minecraft:red_concrete
setblock 511 110 230 minecraft:white_concrete
setblock 511 110 266 minecraft:white_concrete
fill 472 111 232 472 115 233 minecraft:white_concrete
fill 472 111 268 472 115 269 minecraft:white_concrete
fill 473 111 229 473 111 230 minecraft:white_concrete
setblock 473 111 233 minecraft:red_concrete
setblock 473 111 269 minecraft:red_concrete
setblock 474 111 229 minecraft:white_concrete
fill 474 111 230 475 114 230 minecraft:red_concrete
setblock 474 111 265 minecraft:white_concrete
fill 474 111 266 475 114 266 minecraft:red_concrete
fill 482 111 239 484 112 239 minecraft:lime_concrete
fill 483 111 238 483 112 238 minecraft:lime_concrete
fill 483 111 240 483 112 240 minecraft:lime_concrete
fill 508 111 232 508 115 233 minecraft:white_concrete
fill 508 111 268 508 115 269 minecraft:white_concrete
fill 509 111 229 509 111 230 minecraft:white_concrete
setblock 509 111 233 minecraft:red_concrete
fill 509 111 265 509 111 266 minecraft:white_concrete
setblock 509 111 269 minecraft:red_concrete
setblock 510 111 229 minecraft:white_concrete
fill 510 111 230 511 114 230 minecraft:red_concrete
setblock 510 111 265 minecraft:white_concrete
fill 510 111 266 511 114 266 minecraft:red_concrete
fill 473 112 229 473 116 230 minecraft:red_concrete
fill 473 112 232 473 116 233 minecraft:white_concrete
setblock 473 112 238 minecraft:light[level=12]
setblock 473 112 239 minecraft:light[level=15]
setblock 473 112 245 minecraft:light[level=12]
setblock 473 112 247 minecraft:light[level=15]
setblock 473 112 252 minecraft:light[level=12]
setblock 473 112 255 minecraft:light[level=15]
setblock 473 112 259 minecraft:light[level=12]
setblock 473 112 263 minecraft:light[level=15]
fill 473 112 265 473 116 266 minecraft:red_concrete
fill 473 112 268 473 116 269 minecraft:white_concrete
fill 474 112 229 474 115 229 minecraft:red_concrete
fill 474 112 265 474 115 265 minecraft:red_concrete
setblock 480 112 231 minecraft:light[level=12]
setblock 480 112 238 minecraft:light[level=12]
setblock 480 112 245 minecraft:light[level=12]
setblock 480 112 252 minecraft:light[level=12]
setblock 480 112 259 minecraft:light[level=12]
setblock 480 112 266 minecraft:light[level=12]
setblock 481 112 231 minecraft:light[level=15]
setblock 481 112 239 minecraft:light[level=15]
setblock 481 112 247 minecraft:light[level=15]
setblock 481 112 255 minecraft:light[level=15]
setblock 481 112 263 minecraft:light[level=15]
setblock 487 112 231 minecraft:light[level=12]
setblock 487 112 238 minecraft:light[level=12]
setblock 487 112 245 minecraft:light[level=12]
setblock 487 112 252 minecraft:light[level=12]
setblock 487 112 259 minecraft:light[level=12]
setblock 487 112 266 minecraft:light[level=12]
setblock 489 112 231 minecraft:light[level=15]
setblock 489 112 239 minecraft:light[level=15]
setblock 489 112 247 minecraft:light[level=15]
setblock 489 112 255 minecraft:light[level=15]
setblock 489 112 263 minecraft:light[level=15]
setblock 494 112 231 minecraft:light[level=12]
setblock 494 112 238 minecraft:light[level=12]
setblock 494 112 245 minecraft:light[level=12]
setblock 494 112 252 minecraft:light[level=12]
setblock 494 112 259 minecraft:light[level=12]
setblock 494 112 266 minecraft:light[level=12]
setblock 497 112 231 minecraft:light[level=15]
setblock 497 112 239 minecraft:light[level=15]
setblock 497 112 247 minecraft:light[level=15]
setblock 497 112 255 minecraft:light[level=15]
setblock 497 112 263 minecraft:light[level=15]
setblock 501 112 231 minecraft:light[level=12]
setblock 501 112 238 minecraft:light[level=12]
setblock 501 112 245 minecraft:light[level=12]
setblock 501 112 252 minecraft:light[level=12]
setblock 501 112 259 minecraft:light[level=12]
setblock 501 112 266 minecraft:light[level=12]
setblock 505 112 231 minecraft:light[level=15]
setblock 505 112 239 minecraft:light[level=15]
setblock 505 112 247 minecraft:light[level=15]
setblock 505 112 255 minecraft:light[level=15]
setblock 505 112 263 minecraft:light[level=15]
setblock 508 112 238 minecraft:light[level=12]
setblock 508 112 245 minecraft:light[level=12]
setblock 508 112 252 minecraft:light[level=12]
setblock 508 112 259 minecraft:light[level=12]
fill 509 112 229 509 116 230 minecraft:red_concrete
fill 509 112 232 509 116 233 minecraft:white_concrete
fill 509 112 265 509 116 266 minecraft:red_concrete
fill 509 112 268 509 116 269 minecraft:white_concrete
fill 510 112 229 510 115 229 minecraft:red_concrete
fill 510 112 265 510 115 265 minecraft:red_concrete
fill 472 113 229 472 117 229 minecraft:red_concrete
setblock 472 113 230 minecraft:white_concrete
fill 472 113 265 472 117 265 minecraft:red_concrete
setblock 472 113 266 minecraft:white_concrete
fill 474 113 232 474 117 233 minecraft:white_concrete
fill 474 113 268 474 117 269 minecraft:white_concrete
setblock 475 113 232 minecraft:red_concrete
setblock 475 113 268 minecraft:red_concrete
fill 508 113 229 508 117 229 minecraft:red_concrete
setblock 508 113 230 minecraft:white_concrete
fill 508 113 265 508 117 265 minecraft:red_concrete
setblock 508 113 266 minecraft:white_concrete
fill 510 113 232 510 117 233 minecraft:white_concrete
fill 510 113 268 510 117 269 minecraft:white_concrete
setblock 511 113 232 minecraft:red_concrete
setblock 511 113 268 minecraft:red_concrete
fill 471 114 230 472 117 230 minecraft:red_concrete
fill 471 114 266 472 117 266 minecraft:red_concrete
fill 475 114 232 475 118 232 minecraft:white_concrete
fill 475 114 268 475 118 268 minecraft:white_concrete
fill 507 114 230 508 117 230 minecraft:red_concrete
fill 507 114 266 508 117 266 minecraft:red_concrete
fill 511 114 232 511 118 232 minecraft:white_concrete
fill 511 114 268 511 118 268 minecraft:white_concrete
fill 471 115 231 472 119 231 minecraft:red_concrete
setblock 471 115 232 minecraft:white_concrete
fill 471 115 267 472 119 267 minecraft:red_concrete
setblock 471 115 268 minecraft:white_concrete
fill 473 115 231 475 119 231 minecraft:white_concrete
fill 473 115 267 475 119 267 minecraft:white_concrete
setblock 474 115 230 minecraft:red_concrete
setblock 474 115 266 minecraft:red_concrete
fill 475 115 230 475 120 230 minecraft:white_concrete
fill 475 115 266 475 120 266 minecraft:white_concrete
fill 507 115 231 508 119 231 minecraft:red_concrete
setblock 507 115 232 minecraft:white_concrete
fill 507 115 267 508 119 267 minecraft:red_concrete
setblock 507 115 268 minecraft:white_concrete
fill 509 115 231 511 119 231 minecraft:white_concrete
fill 509 115 267 511 119 267 minecraft:white_concrete
setblock 510 115 230 minecraft:red_concrete
setblock 510 115 266 minecraft:red_concrete
fill 511 115 230 511 120 230 minecraft:white_concrete
fill 511 115 266 511 120 266 minecraft:white_concrete
fill 471 116 232 472 119 232 minecraft:red_concrete
fill 471 116 268 472 119 268 minecraft:red_concrete
setblock 472 116 233 minecraft:white_concrete
setblock 472 116 269 minecraft:white_concrete
fill 474 116 229 474 120 230 minecraft:white_concrete
fill 474 116 265 474 120 266 minecraft:white_concrete
fill 507 116 232 508 119 232 minecraft:red_concrete
fill 507 116 268 508 119 268 minecraft:red_concrete
setblock 508 116 233 minecraft:white_concrete
setblock 508 116 269 minecraft:white_concrete
fill 510 116 229 510 120 230 minecraft:white_concrete
fill 510 116 265 510 120 266 minecraft:white_concrete
fill 472 117 233 473 120 233 minecraft:red_concrete
fill 472 117 269 473 120 269 minecraft:red_concrete
fill 473 117 229 473 121 230 minecraft:white_concrete
fill 473 117 232 473 121 232 minecraft:red_concrete
fill 473 117 265 473 121 266 minecraft:white_concrete
fill 473 117 268 473 121 268 minecraft:red_concrete
fill 508 117 233 509 120 233 minecraft:red_concrete
fill 508 117 269 509 120 269 minecraft:red_concrete
fill 509 117 229 509 121 230 minecraft:white_concrete
fill 509 117 232 509 121 232 minecraft:red_concrete
fill 509 117 265 509 121 266 minecraft:white_concrete
fill 509 117 268 509 121 268 minecraft:red_concrete
setblock 471 118 230 minecraft:red_concrete
setblock 471 118 266 minecraft:red_concrete
fill 472 118 229 472 122 230 minecraft:white_concrete
fill 472 118 265 472 122 266 minecraft:white_concrete
setblock 473 118 238 minecraft:light[level=12]
setblock 473 118 245 minecraft:light[level=12]
setblock 473 118 252 minecraft:light[level=12]
setblock 473 118 259 minecraft:light[level=12]
setblock 474 118 232 minecraft:white_concrete
fill 474 118 233 474 122 233 minecraft:red_concrete
setblock 474 118 268 minecraft:white_concrete
fill 474 118 269 474 122 269 minecraft:red_concrete
setblock 480 118 231 minecraft:light[level=12]
setblock 480 118 238 minecraft:light[level=12]
setblock 480 118 245 minecraft:light[level=12]
setblock 480 118 252 minecraft:light[level=12]
setblock 480 118 259 minecraft:light[level=12]
setblock 480 118 266 minecraft:light[level=12]
setblock 487 118 231 minecraft:light[level=12]
setblock 487 118 238 minecraft:light[level=12]
setblock 487 118 245 minecraft:light[level=12]
setblock 487 118 252 minecraft:light[level=12]
setblock 487 118 259 minecraft:light[level=12]
setblock 487 118 266 minecraft:light[level=12]
setblock 494 118 231 minecraft:light[level=12]
setblock 494 118 238 minecraft:light[level=12]
setblock 494 118 245 minecraft:light[level=12]
setblock 494 118 252 minecraft:light[level=12]
setblock 494 118 259 minecraft:light[level=12]
setblock 494 118 266 minecraft:light[level=12]
setblock 501 118 231 minecraft:light[level=12]
setblock 501 118 238 minecraft:light[level=12]
setblock 501 118 245 minecraft:light[level=12]
setblock 501 118 252 minecraft:light[level=12]
setblock 501 118 259 minecraft:light[level=12]
setblock 501 118 266 minecraft:light[level=12]
setblock 507 118 230 minecraft:red_concrete
setblock 507 118 266 minecraft:red_concrete
fill 508 118 229 508 122 230 minecraft:white_concrete
setblock 508 118 238 minecraft:light[level=12]
setblock 508 118 245 minecraft:light[level=12]
setblock 508 118 252 minecraft:light[level=12]
setblock 508 118 259 minecraft:light[level=12]
fill 508 118 265 508 122 266 minecraft:white_concrete
setblock 510 118 232 minecraft:white_concrete
fill 510 118 233 510 122 233 minecraft:red_concrete
setblock 510 118 268 minecraft:white_concrete
fill 510 118 269 510 122 269 minecraft:red_concrete
fill 471 119 230 471 123 230 minecraft:white_concrete
fill 471 119 266 471 123 266 minecraft:white_concrete
setblock 473 119 239 minecraft:light[level=15]
setblock 473 119 247 minecraft:light[level=15]
setblock 473 119 255 minecraft:light[level=15]
setblock 473 119 263 minecraft:light[level=15]
fill 474 119 232 475 122 232 minecraft:red_concrete
fill 474 119 268 475 122 268 minecraft:red_concrete
setblock 481 119 231 minecraft:light[level=15]
setblock 481 119 239 minecraft:light[level=15]
setblock 481 119 247 minecraft:light[level=15]
setblock 481 119 255 minecraft:light[level=15]
setblock 481 119 263 minecraft:light[level=15]
setblock 489 119 231 minecraft:light[level=15]
setblock 489 119 239 minecraft:light[level=15]
setblock 489 119 247 minecraft:light[level=15]
setblock 489 119 255 minecraft:light[level=15]
setblock 489 119 263 minecraft:light[level=15]
setblock 497 119 231 minecraft:light[level=15]
setblock 497 119 239 minecraft:light[level=15]
setblock 497 119 247 minecraft:light[level=15]
setblock 497 119 255 minecraft:light[level=15]
setblock 497 119 263 minecraft:light[level=15]
setblock 505 119 231 minecraft:light[level=15]
setblock 505 119 239 minecraft:light[level=15]
setblock 505 119 247 minecraft:light[level=15]
setblock 505 119 255 minecraft:light[level=15]
setblock 505 119 263 minecraft:light[level=15]
fill 507 119 230 507 123 230 minecraft:white_concrete
fill 507 119 266 507 123 266 minecraft:white_concrete
fill 510 119 232 511 122 232 minecraft:red_concrete
fill 510 119 268 511 122 268 minecraft:red_concrete
fill 511 119 256 511 128 256 minecraft:brown_concrete
fill 471 120 231 471 124 232 minecraft:white_concrete
fill 471 120 267 471 124 268 minecraft:white_concrete
fill 472 120 231 472 124 231 minecraft:white_concrete
setblock 472 120 232 minecraft:red_concrete
fill 472 120 267 472 124 267 minecraft:white_concrete
setblock 472 120 268 minecraft:red_concrete
fill 473 120 231 475 124 231 minecraft:red_concrete
fill 473 120 267 475 124 267 minecraft:red_concrete
fill 507 120 231 507 124 232 minecraft:white_concrete
fill 507 120 267 507 124 268 minecraft:white_concrete
fill 508 120 231 508 124 231 minecraft:white_concrete
setblock 508 120 232 minecraft:red_concrete
fill 508 120 267 508 124 267 minecraft:white_concrete
setblock 508 120 268 minecraft:red_concrete
fill 509 120 231 511 124 231 minecraft:red_concrete
fill 509 120 267 511 124 267 minecraft:red_concrete
fill 472 121 232 472 125 233 minecraft:white_concrete
fill 472 121 268 472 125 269 minecraft:white_concrete
setblock 473 121 233 minecraft:red_concrete
setblock 473 121 269 minecraft:red_concrete
setblock 474 121 229 minecraft:white_concrete
fill 474 121 230 475 124 230 minecraft:red_concrete
setblock 474 121 265 minecraft:white_concrete
fill 474 121 266 475 124 266 minecraft:red_concrete
fill 508 121 232 508 125 233 minecraft:white_concrete
fill 508 121 268 508 125 269 minecraft:white_concrete
setblock 509 121 233 minecraft:red_concrete
setblock 509 121 269 minecraft:red_concrete
setblock 510 121 229 minecraft:white_concrete
fill 510 121 230 511 124 230 minecraft:red_concrete
setblock 510 121 265 minecraft:white_concrete
fill 510 121 266 511 124 266 minecraft:red_concrete
fill 473 122 229 473 125 230 minecraft:red_concrete
fill 473 122 232 473 125 233 minecraft:white_concrete
fill 473 122 265 473 125 266 minecraft:red_concrete
fill 473 122 268 473 125 269 minecraft:white_concrete
fill 474 122 229 474 125 229 minecraft:red_concrete
fill 474 122 265 474 125 265 minecraft:red_concrete
fill 509 122 229 509 125 230 minecraft:red_concrete
fill 509 122 232 509 125 233 minecraft:white_concrete
fill 509 122 265 509 125 266 minecraft:red_concrete
fill 509 122 268 509 125 269 minecraft:white_concrete
fill 510 122 229 510 125 229 minecraft:red_concrete
fill 510 122 265 510 125 265 minecraft:red_concrete
fill 472 123 229 472 125 229 minecraft:red_concrete
setblock 472 123 230 minecraft:white_concrete
fill 472 123 265 472 125 265 minecraft:red_concrete
setblock 472 123 266 minecraft:white_concrete
fill 474 123 232 474 127 233 minecraft:white_concrete
fill 474 123 268 474 125 269 minecraft:white_concrete
setblock 475 123 232 minecraft:red_concrete
setblock 475 123 268 minecraft:red_concrete
fill 508 123 229 508 125 229 minecraft:red_concrete
setblock 508 123 230 minecraft:white_concrete
fill 508 123 265 508 127 265 minecraft:red_concrete
setblock 508 123 266 minecraft:white_concrete
fill 510 123 232 510 125 233 minecraft:white_concrete
fill 510 123 268 510 125 269 minecraft:white_concrete
setblock 511 123 232 minecraft:red_concrete
setblock 511 123 268 minecraft:red_concrete
fill 471 124 230 472 125 230 minecraft:red_concrete
fill 471 124 266 472 125 266 minecraft:red_concrete
setblock 473 124 238 minecraft:light[level=12]
setblock 473 124 245 minecraft:light[level=12]
setblock 473 124 252 minecraft:light[level=12]
setblock 473 124 259 minecraft:light[level=12]
fill 475 124 232 475 128 232 minecraft:white_concrete
fill 475 124 268 475 125 268 minecraft:white_concrete
setblock 480 124 231 minecraft:light[level=12]
setblock 480 124 238 minecraft:light[level=12]
setblock 480 124 245 minecraft:light[level=12]
setblock 480 124 252 minecraft:light[level=12]
setblock 480 124 259 minecraft:light[level=12]
setblock 480 124 266 minecraft:light[level=12]
setblock 487 124 231 minecraft:light[level=12]
setblock 487 124 238 minecraft:light[level=12]
setblock 487 124 245 minecraft:light[level=12]
setblock 487 124 252 minecraft:light[level=12]
setblock 487 124 259 minecraft:light[level=12]
setblock 487 124 266 minecraft:light[level=12]
fill 491 124 264 491 138 264 minecraft:magenta_concrete
setblock 494 124 231 minecraft:light[level=12]
setblock 494 124 238 minecraft:light[level=12]
setblock 494 124 245 minecraft:light[level=12]
setblock 494 124 252 minecraft:light[level=12]
setblock 494 124 259 minecraft:light[level=12]
setblock 494 124 266 minecraft:light[level=12]
fill 497 124 238 499 124 239 minecraft:orange_terracotta
fill 498 124 236 504 124 237 minecraft:orange_terracotta
fill 498 124 240 503 124 241 minecraft:orange_terracotta
fill 499 124 235 503 124 235 minecraft:orange_terracotta
fill 500 124 242 502 124 242 minecraft:orange_terracotta
setblock 501 124 231 minecraft:light[level=12]
setblock 501 124 238 minecraft:light[level=12]
setblock 501 124 245 minecraft:light[level=12]
setblock 501 124 252 minecraft:light[level=12]
setblock 501 124 259 minecraft:light[level=12]
setblock 501 124 266 minecraft:light[level=12]
fill 502 124 239 504 124 239 minecraft:orange_terracotta
fill 503 124 238 504 124 238 minecraft:orange_terracotta
setblock 504 124 240 minecraft:orange_terracotta
fill 507 124 230 508 125 230 minecraft:red_concrete
fill 507 124 266 508 127 266 minecraft:red_concrete
setblock 508 124 238 minecraft:light[level=12]
setblock 508 124 245 minecraft:light[level=12]
setblock 508 124 252 minecraft:light[level=12]
setblock 508 124 259 minecraft:light[level=12]
fill 511 124 232 511 125 232 minecraft:white_concrete
fill 511 124 268 511 125 268 minecraft:white_concrete
fill 471 125 231 472 125 231 minecraft:red_concrete
setblock 471 125 232 minecraft:white_concrete
fill 471 125 267 472 125 267 minecraft:red_concrete
setblock 471 125 268 minecraft:white_concrete
fill 473 125 231 475 125 231 minecraft:white_concrete
fill 473 125 267 475 125 267 minecraft:white_concrete
setblock 474 125 230 minecraft:red_concrete
setblock 474 125 266 minecraft:red_concrete
setblock 475 125 230 minecraft:white_concrete
fill 475 125 266 475 130 266 minecraft:white_concrete
fill 488 125 262 490 137 266 minecraft:magenta_concrete
fill 489 125 261 493 137 261 minecraft:magenta_concrete
fill 489 125 267 493 125 267 minecraft:magenta_concrete
fill 491 125 262 494 137 263 minecraft:magenta_concrete
fill 491 125 265 494 137 266 minecraft:magenta_concrete
fill 492 125 264 494 137 264 minecraft:magenta_concrete
fill 497 125 238 499 125 239 minecraft:white_concrete
fill 498 125 236 504 125 237 minecraft:white_concrete
fill 498 125 240 503 125 241 minecraft:white_concrete
fill 499 125 235 503 125 235 minecraft:white_concrete
fill 500 125 242 502 125 242 minecraft:white_concrete
fill 502 125 239 504 125 239 minecraft:white_concrete
fill 503 125 238 504 125 238 minecraft:white_concrete
setblock 504 125 240 minecraft:white_concrete
fill 505 125 259 506 126 260 minecraft:yellow_concrete
fill 507 125 231 508 125 231 minecraft:red_concrete
setblock 507 125 232 minecraft:white_concrete
fill 507 125 267 508 125 267 minecraft:red_concrete
setblock 507 125 268 minecraft:white_concrete
fill 509 125 231 511 125 231 minecraft:white_concrete
fill 509 125 267 511 125 267 minecraft:white_concrete
setblock 510 125 230 minecraft:red_concrete
setblock 510 125 266 minecraft:red_concrete
setblock 511 125 230 minecraft:white_concrete
setblock 511 125 266 minecraft:white_concrete
fill 471 126 229 473 126 269 minecraft:black_concrete
fill 474 126 229 511 126 231 minecraft:black_concrete
fill 474 126 265 474 130 266 minecraft:white_concrete
fill 474 126 267 511 126 269 minecraft:black_concrete
setblock 481 126 239 minecraft:light[level=15]
setblock 481 126 247 minecraft:light[level=15]
setblock 481 126 255 minecraft:light[level=15]
setblock 481 126 263 minecraft:light[level=15]
fill 487 126 262 487 136 266 minecraft:magenta_concrete
fill 488 126 261 488 136 261 minecraft:magenta_concrete
setblock 489 126 239 minecraft:light[level=15]
setblock 489 126 247 minecraft:light[level=15]
setblock 489 126 255 minecraft:light[level=15]
fill 489 126 260 493 136 260 minecraft:magenta_concrete
fill 494 126 261 494 136 261 minecraft:magenta_concrete
fill 495 126 262 495 136 266 minecraft:magenta_concrete
setblock 497 126 239 minecraft:light[level=15]
setblock 497 126 247 minecraft:light[level=15]
setblock 497 126 255 minecraft:light[level=15]
setblock 497 126 263 minecraft:light[level=15]
setblock 505 126 239 minecraft:light[level=15]
setblock 505 126 247 minecraft:light[level=15]
setblock 505 126 255 minecraft:light[level=15]
setblock 505 126 263 minecraft:light[level=15]
fill 507 126 232 508 129 232 minecraft:red_concrete
setblock 508 126 233 minecraft:white_concrete
fill 509 126 232 510 126 266 minecraft:black_concrete
fill 511 126 232 511 126 255 minecraft:black_concrete
fill 511 126 257 511 126 266 minecraft:black_concrete
fill 471 127 229 473 127 269 minecraft:gray_concrete
fill 474 127 229 511 127 231 minecraft:gray_concrete
fill 474 127 267 511 127 269 minecraft:gray_concrete
fill 486 127 262 486 135 266 minecraft:magenta_concrete
fill 487 127 260 487 135 261 minecraft:magenta_concrete
fill 488 127 260 488 135 260 minecraft:magenta_concrete
fill 489 127 259 493 135 259 minecraft:magenta_concrete
fill 494 127 260 495 135 260 minecraft:magenta_concrete
fill 495 127 261 495 135 261 minecraft:magenta_concrete
fill 496 127 262 496 135 266 minecraft:magenta_concrete
fill 508 127 233 508 130 233 minecraft:red_concrete
fill 509 127 232 510 127 266 minecraft:gray_concrete
fill 511 127 232 511 127 255 minecraft:gray_concrete
fill 511 127 257 511 127 266 minecraft:gray_concrete
fill 471 128 230 471 128 232 minecraft:red_concrete
setblock 471 128 240 minecraft:lime_concrete
setblock 471 128 261 minecraft:light_blue_concrete
fill 471 128 266 471 128 268 minecraft:red_concrete
fill 472 128 229 474 130 230 minecraft:white_concrete
fill 472 128 231 472 129 233 minecraft:red_concrete
fill 472 128 237 472 129 237 minecraft:brown_concrete
fill 472 128 252 472 129 252 minecraft:brown_concrete
fill 472 128 265 473 131 266 minecraft:white_concrete
fill 472 128 267 472 129 269 minecraft:red_concrete
fill 473 128 231 475 129 231 minecraft:white_concrete
fill 473 128 232 473 131 233 minecraft:red_concrete
fill 473 128 267 475 129 267 minecraft:white_concrete
fill 473 128 268 473 131 269 minecraft:red_concrete
setblock 474 128 232 minecraft:white_concrete
fill 474 128 233 474 132 233 minecraft:red_concrete
fill 474 128 268 475 128 268 minecraft:white_concrete
fill 474 128 269 474 132 269 minecraft:red_concrete
setblock 475 128 230 minecraft:magenta_concrete
fill 476 128 229 476 129 229 minecraft:brown_concrete
fill 483 128 230 483 129 230 minecraft:brown_concrete
setblock 483 128 231 minecraft:light_blue_concrete
setblock 483 128 269 minecraft:light_blue_concrete
fill 485 128 262 485 134 266 minecraft:magenta_concrete
fill 486 128 261 486 134 261 minecraft:magenta_concrete
fill 486 128 267 496 134 267 minecraft:magenta_concrete
fill 487 128 268 495 135 268 minecraft:magenta_concrete
setblock 488 128 229 minecraft:magenta_concrete
fill 488 128 259 488 134 259 minecraft:magenta_concrete
fill 488 128 269 494 134 269 minecraft:magenta_concrete
fill 489 128 258 493 134 258 minecraft:magenta_concrete
fill 494 128 259 494 134 259 minecraft:magenta_concrete
setblock 495 128 231 minecraft:light_blue_concrete
fill 496 128 261 496 134 261 minecraft:magenta_concrete
fill 497 128 262 497 134 266 minecraft:magenta_concrete
fill 501 128 231 501 129 231 minecraft:brown_concrete
setblock 501 128 267 minecraft:magenta_concrete
fill 507 128 230 507 128 231 minecraft:red_concrete
fill 507 128 266 507 128 268 minecraft:red_concrete
fill 508 128 229 510 130 230 minecraft:white_concrete
fill 508 128 231 508 129 231 minecraft:red_concrete
fill 508 128 265 510 130 266 minecraft:white_concrete
fill 508 128 267 508 129 269 minecraft:red_concrete
fill 509 128 231 511 129 231 minecraft:white_concrete
fill 509 128 232 509 131 233 minecraft:red_concrete
fill 509 128 267 511 129 267 minecraft:white_concrete
fill 509 128 268 509 131 269 minecraft:red_concrete
fill 510 128 232 511 128 232 minecraft:white_concrete
fill 510 128 233 510 132 233 minecraft:red_concrete
fill 510 128 243 510 129 243 minecraft:brown_concrete
setblock 510 128 252 minecraft:lime_concrete
fill 510 128 268 511 128 268 minecraft:white_concrete
fill 510 128 269 510 132 269 minecraft:red_concrete
fill 511 128 230 511 130 230 minecraft:white_concrete
fill 511 128 261 511 129 261 minecraft:brown_concrete
fill 511 128 266 511 130 266 minecraft:white_concrete
fill 471 129 230 471 133 230 minecraft:white_concrete
fill 471 129 231 471 129 232 minecraft:red_concrete
fill 471 129 266 471 133 266 minecraft:white_concrete
fill 471 129 267 471 129 268 minecraft:red_concrete
fill 474 129 232 475 132 232 minecraft:red_concrete
fill 474 129 268 475 132 268 minecraft:red_concrete
fill 475 129 230 475 130 230 minecraft:white_concrete
fill 485 129 261 485 133 261 minecraft:magenta_concrete
fill 485 129 267 485 133 267 minecraft:magenta_concrete
fill 486 129 260 486 133 260 minecraft:magenta_concrete
fill 486 129 268 486 133 268 minecraft:magenta_concrete
fill 487 129 259 487 133 259 minecraft:magenta_concrete
fill 487 129 269 487 133 269 minecraft:magenta_concrete
fill 488 129 258 488 133 258 minecraft:magenta_concrete
fill 494 129 258 494 133 258 minecraft:magenta_concrete
fill 495 129 259 495 133 259 minecraft:magenta_concrete
fill 495 129 269 495 133 269 minecraft:magenta_concrete
fill 496 129 260 496 133 260 minecraft:magenta_concrete
fill 496 129 268 496 133 268 minecraft:magenta_concrete
fill 497 129 261 497 133 261 minecraft:magenta_concrete
fill 497 129 267 497 133 267 minecraft:magenta_concrete
fill 501 129 229 501 138 229 minecraft:brown_terracotta
fill 507 129 230 507 133 230 minecraft:white_concrete
setblock 507 129 231 minecraft:red_concrete
fill 507 129 266 507 133 266 minecraft:white_concrete
fill 507 129 267 507 129 268 minecraft:red_concrete
fill 510 129 232 511 132 232 minecraft:red_concrete
fill 510 129 268 511 132 268 minecraft:red_concrete
fill 471 130 231 471 134 232 minecraft:white_concrete
fill 471 130 267 471 134 268 minecraft:white_concrete
fill 472 130 231 472 134 231 minecraft:white_concrete
fill 472 130 232 472 130 233 minecraft:red_concrete
fill 472 130 267 472 134 267 minecraft:white_concrete
fill 472 130 268 472 130 269 minecraft:red_concrete
fill 473 130 231 475 134 231 minecraft:red_concrete
setblock 473 130 238 minecraft:light[level=12]
setblock 473 130 245 minecraft:light[level=12]
setblock 473 130 252 minecraft:light[level=12]
setblock 473 130 259 minecraft:light[level=12]
fill 473 130 267 475 134 267 minecraft:red_concrete
setblock 480 130 231 minecraft:light[level=12]
setblock 480 130 238 minecraft:light[level=12]
setblock 480 130 245 minecraft:light[level=12]
setblock 480 130 252 minecraft:light[level=12]
setblock 480 130 259 minecraft:light[level=12]
setblock 480 130 266 minecraft:light[level=12]
setblock 487 130 231 minecraft:light[level=12]
setblock 487 130 238 minecraft:light[level=12]
setblock 487 130 245 minecraft:light[level=12]
setblock 487 130 252 minecraft:light[level=12]
setblock 494 130 231 minecraft:light[level=12]
setblock 494 130 238 minecraft:light[level=12]
setblock 494 130 245 minecraft:light[level=12]
setblock 494 130 252 minecraft:light[level=12]
fill 499 130 243 499 131 245 minecraft:lime_concrete
fill 500 130 243 500 131 244 minecraft:lime_concrete
setblock 501 130 231 minecraft:light[level=12]
setblock 501 130 238 minecraft:light[level=12]
setblock 501 130 245 minecraft:light[level=12]
setblock 501 130 252 minecraft:light[level=12]
setblock 501 130 259 minecraft:light[level=12]
setblock 501 130 266 minecraft:light[level=12]
fill 507 130 231 507 134 232 minecraft:white_concrete
fill 507 130 267 507 134 268 minecraft:white_concrete
fill 508 130 231 508 134 231 minecraft:white_concrete
setblock 508 130 232 minecraft:red_concrete
setblock 508 130 238 minecraft:light[level=12]
setblock 508 130 245 minecraft:light[level=12]
setblock 508 130 252 minecraft:light[level=12]
setblock 508 130 259 minecraft:light[level=12]
fill 508 130 267 508 134 267 minecraft:white_concrete
fill 508 130 268 508 130 269 minecraft:red_concrete
fill 509 130 231 511 134 231 minecraft:red_concrete
fill 509 130 267 511 134 267 minecraft:red_concrete
fill 472 131 229 473 131 230 minecraft:white_concrete
fill 472 131 232 472 135 233 minecraft:white_concrete
fill 472 131 268 472 135 269 minecraft:white_concrete
setblock 474 131 229 minecraft:white_concrete
fill 474 131 230 475 134 230 minecraft:red_concrete
setblock 474 131 265 minecraft:white_concrete
fill 474 131 266 475 134 266 minecraft:red_concrete
fill 481 131 262 482 131 266 minecraft:shroomlight
fill 482 131 259 482 131 261 minecraft:shroomlight
fill 482 131 267 482 131 269 minecraft:shroomlight
fill 483 131 258 483 131 260 minecraft:shroomlight
fill 483 131 268 483 131 269 minecraft:shroomlight
fill 484 131 257 484 131 258 minecraft:shroomlight
setblock 484 131 264 minecraft:magenta_concrete
fill 485 131 256 485 131 257 minecraft:shroomlight
fill 486 131 255 487 131 256 minecraft:shroomlight
fill 488 131 255 496 131 255 minecraft:shroomlight
fill 489 131 254 493 131 254 minecraft:shroomlight
setblock 491 131 257 minecraft:magenta_concrete
fill 495 131 256 497 131 256 minecraft:shroomlight
fill 497 131 257 498 131 257 minecraft:shroomlight
fill 498 131 258 499 131 258 minecraft:shroomlight
schedule function dropper:buildpart/58_2 1t
