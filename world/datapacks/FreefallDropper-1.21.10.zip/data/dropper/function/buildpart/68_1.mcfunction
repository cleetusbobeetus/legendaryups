fill 410 65 293 410 66 293 minecraft:stripped_oak_log
fill 410 65 295 410 66 295 minecraft:stripped_oak_log
fill 410 65 297 410 66 297 minecraft:stripped_oak_log
fill 410 65 299 410 66 299 minecraft:stripped_oak_log
fill 410 65 301 410 66 301 minecraft:stripped_oak_log
setblock 410 65 315 minecraft:stripped_oak_log
fill 410 65 316 410 68 316 minecraft:red_terracotta
fill 411 65 292 411 66 292 minecraft:stripped_oak_log
fill 411 65 294 411 66 294 minecraft:stripped_oak_log
fill 411 65 296 411 66 296 minecraft:stripped_oak_log
fill 411 65 298 411 66 298 minecraft:stripped_oak_log
fill 411 65 300 411 66 300 minecraft:stripped_oak_log
fill 411 65 302 411 66 302 minecraft:stripped_oak_log
setblock 411 65 314 minecraft:stripped_oak_log
fill 411 65 315 411 68 315 minecraft:red_terracotta
fill 412 65 293 412 66 293 minecraft:stripped_oak_log
fill 412 65 295 412 66 295 minecraft:stripped_oak_log
fill 412 65 297 412 66 297 minecraft:stripped_oak_log
fill 412 65 299 412 66 299 minecraft:stripped_oak_log
fill 412 65 301 412 66 301 minecraft:stripped_oak_log
setblock 412 65 313 minecraft:stripped_oak_log
fill 412 65 314 412 68 314 minecraft:red_terracotta
fill 413 65 292 413 66 292 minecraft:stripped_oak_log
fill 413 65 294 413 66 294 minecraft:stripped_oak_log
fill 413 65 296 413 66 296 minecraft:stripped_oak_log
fill 413 65 298 413 66 298 minecraft:stripped_oak_log
fill 413 65 300 413 66 300 minecraft:stripped_oak_log
fill 413 65 302 413 66 302 minecraft:stripped_oak_log
setblock 414 65 278 minecraft:light[level=12]
setblock 414 65 285 minecraft:light[level=12]
fill 414 65 293 414 66 293 minecraft:stripped_oak_log
fill 414 65 295 414 66 295 minecraft:stripped_oak_log
fill 414 65 297 414 66 297 minecraft:stripped_oak_log
fill 414 65 299 414 66 299 minecraft:stripped_oak_log
fill 414 65 301 414 66 301 minecraft:stripped_oak_log
setblock 414 65 306 minecraft:light[level=12]
setblock 414 65 313 minecraft:light[level=12]
setblock 414 65 316 minecraft:stripped_oak_log
fill 415 65 292 415 66 292 minecraft:stripped_oak_log
fill 415 65 294 415 66 294 minecraft:stripped_oak_log
fill 415 65 296 415 66 296 minecraft:stripped_oak_log
fill 415 65 298 415 66 298 minecraft:stripped_oak_log
fill 415 65 300 415 66 300 minecraft:stripped_oak_log
fill 415 65 302 415 66 302 minecraft:stripped_oak_log
setblock 415 65 310 minecraft:stripped_oak_log
fill 415 65 311 415 66 311 minecraft:red_terracotta
setblock 415 65 315 minecraft:stripped_oak_log
fill 415 65 316 415 68 316 minecraft:red_terracotta
fill 416 65 293 417 65 293 minecraft:stripped_oak_log
fill 416 65 295 416 66 295 minecraft:stripped_oak_log
fill 416 65 297 416 66 297 minecraft:stripped_oak_log
fill 416 65 299 416 66 299 minecraft:stripped_oak_log
fill 416 65 301 417 66 301 minecraft:stripped_oak_log
setblock 416 65 305 minecraft:red_terracotta
setblock 416 65 309 minecraft:stripped_oak_log
fill 416 65 310 416 67 310 minecraft:red_terracotta
setblock 416 65 314 minecraft:stripped_oak_log
setblock 417 65 288 minecraft:stripped_oak_log
fill 417 65 289 417 67 289 minecraft:red_terracotta
setblock 417 65 292 minecraft:red_terracotta
fill 417 65 294 417 66 294 minecraft:red_terracotta
fill 417 65 296 417 66 296 minecraft:stripped_oak_log
fill 417 65 298 417 66 298 minecraft:stripped_oak_log
fill 417 65 300 417 66 300 minecraft:stripped_oak_log
setblock 417 65 302 minecraft:red_terracotta
setblock 417 65 303 minecraft:stripped_oak_log
fill 417 65 304 417 66 304 minecraft:red_terracotta
setblock 417 65 308 minecraft:stripped_oak_log
fill 417 65 309 417 68 309 minecraft:red_terracotta
setblock 417 65 313 minecraft:stripped_oak_log
fill 417 65 314 417 68 314 minecraft:red_terracotta
setblock 377 66 287 minecraft:stripped_oak_log
fill 377 66 288 377 66 291 minecraft:red_terracotta
setblock 377 66 292 minecraft:stripped_oak_log
fill 377 66 293 377 66 296 minecraft:red_terracotta
setblock 377 66 297 minecraft:stripped_oak_log
setblock 377 66 307 minecraft:stripped_oak_log
setblock 377 66 308 minecraft:red_terracotta
setblock 377 66 312 minecraft:stripped_oak_log
setblock 377 66 313 minecraft:red_terracotta
setblock 378 66 291 minecraft:stripped_oak_log
fill 378 66 292 378 69 292 minecraft:red_terracotta
setblock 383 66 276 minecraft:stripped_oak_log
setblock 383 66 316 minecraft:stripped_oak_log
fill 384 66 276 387 66 276 minecraft:red_terracotta
fill 384 66 316 387 66 316 minecraft:red_terracotta
fill 385 66 315 385 69 315 minecraft:red_terracotta
setblock 386 66 277 minecraft:red_terracotta
setblock 387 66 277 minecraft:stripped_oak_log
setblock 388 66 276 minecraft:stripped_oak_log
fill 388 66 277 388 69 277 minecraft:red_terracotta
setblock 388 66 315 minecraft:red_terracotta
setblock 388 66 316 minecraft:stripped_oak_log
fill 389 66 276 389 69 276 minecraft:red_terracotta
setblock 389 66 315 minecraft:stripped_oak_log
fill 389 66 316 389 69 316 minecraft:red_terracotta
fill 390 66 315 390 69 315 minecraft:red_terracotta
setblock 393 66 276 minecraft:stripped_oak_log
setblock 393 66 316 minecraft:stripped_oak_log
fill 394 66 276 397 66 276 minecraft:red_terracotta
fill 394 66 316 397 66 316 minecraft:red_terracotta
setblock 398 66 276 minecraft:stripped_oak_log
setblock 398 66 316 minecraft:stripped_oak_log
fill 399 66 276 402 66 276 minecraft:red_terracotta
fill 399 66 316 402 66 316 minecraft:red_terracotta
fill 400 66 315 400 69 315 minecraft:red_terracotta
fill 402 66 314 404 66 314 minecraft:red_terracotta
setblock 403 66 276 minecraft:stripped_oak_log
setblock 403 66 316 minecraft:stripped_oak_log
fill 404 66 276 404 69 276 minecraft:red_terracotta
fill 404 66 313 405 66 313 minecraft:red_terracotta
setblock 404 66 315 minecraft:stripped_oak_log
fill 404 66 316 404 69 316 minecraft:red_terracotta
setblock 405 66 314 minecraft:stripped_oak_log
fill 405 66 315 405 69 315 minecraft:red_terracotta
setblock 406 66 313 minecraft:stripped_oak_log
fill 406 66 314 406 69 314 minecraft:red_terracotta
setblock 407 66 277 minecraft:stripped_oak_log
fill 407 66 313 407 69 313 minecraft:red_terracotta
setblock 408 66 276 minecraft:stripped_oak_log
setblock 408 66 312 minecraft:red_terracotta
setblock 408 66 316 minecraft:stripped_oak_log
fill 409 66 276 409 69 276 minecraft:red_terracotta
setblock 409 66 315 minecraft:stripped_oak_log
fill 409 66 316 409 69 316 minecraft:red_terracotta
setblock 410 66 314 minecraft:stripped_oak_log
fill 410 66 315 410 69 315 minecraft:red_terracotta
setblock 411 66 313 minecraft:stripped_oak_log
fill 411 66 314 411 69 314 minecraft:red_terracotta
setblock 412 66 313 minecraft:red_terracotta
setblock 413 66 316 minecraft:stripped_oak_log
setblock 414 66 315 minecraft:stripped_oak_log
fill 414 66 316 414 69 316 minecraft:red_terracotta
setblock 415 66 310 minecraft:red_terracotta
setblock 415 66 315 minecraft:red_terracotta
setblock 416 66 293 minecraft:stripped_oak_log
setblock 416 66 308 minecraft:stripped_oak_log
fill 416 66 309 416 67 309 minecraft:red_terracotta
setblock 416 66 313 minecraft:stripped_oak_log
setblock 416 66 314 minecraft:red_terracotta
setblock 417 66 288 minecraft:red_terracotta
setblock 417 66 292 minecraft:stripped_oak_log
fill 417 66 293 417 69 293 minecraft:red_terracotta
setblock 417 66 302 minecraft:stripped_oak_log
setblock 417 66 307 minecraft:stripped_oak_log
fill 417 66 308 417 68 308 minecraft:red_terracotta
setblock 417 66 312 minecraft:stripped_oak_log
fill 417 66 313 417 69 313 minecraft:red_terracotta
setblock 377 67 286 minecraft:stripped_oak_log
fill 377 67 287 377 67 290 minecraft:red_terracotta
setblock 377 67 291 minecraft:stripped_oak_log
fill 377 67 292 377 67 295 minecraft:red_terracotta
setblock 377 67 296 minecraft:stripped_oak_log
fill 377 67 297 377 70 297 minecraft:red_terracotta
setblock 378 67 290 minecraft:stripped_oak_log
fill 378 67 291 378 70 291 minecraft:red_terracotta
setblock 382 67 316 minecraft:stripped_oak_log
fill 383 67 276 386 67 276 minecraft:red_terracotta
fill 383 67 316 386 67 316 minecraft:red_terracotta
fill 385 67 304 385 75 304 minecraft:brown_terracotta
setblock 386 67 277 minecraft:stripped_oak_log
setblock 387 67 276 minecraft:stripped_oak_log
fill 387 67 277 387 70 277 minecraft:red_terracotta
setblock 387 67 316 minecraft:stripped_oak_log
fill 388 67 276 388 70 276 minecraft:red_terracotta
setblock 388 67 315 minecraft:stripped_oak_log
fill 388 67 316 388 70 316 minecraft:red_terracotta
fill 389 67 315 389 70 315 minecraft:red_terracotta
setblock 391 67 277 minecraft:stripped_oak_log
setblock 392 67 276 minecraft:stripped_oak_log
setblock 392 67 316 minecraft:stripped_oak_log
fill 393 67 276 396 67 276 minecraft:red_terracotta
fill 393 67 316 396 67 316 minecraft:red_terracotta
setblock 397 67 276 minecraft:stripped_oak_log
setblock 397 67 316 minecraft:stripped_oak_log
fill 398 67 276 401 67 276 minecraft:red_terracotta
fill 398 67 316 401 67 316 minecraft:red_terracotta
fill 399 67 315 399 70 315 minecraft:red_terracotta
setblock 402 67 276 minecraft:stripped_oak_log
fill 402 67 314 403 67 314 minecraft:red_terracotta
setblock 402 67 316 minecraft:stripped_oak_log
fill 403 67 276 403 70 276 minecraft:red_terracotta
setblock 403 67 315 minecraft:stripped_oak_log
fill 403 67 316 403 70 316 minecraft:red_terracotta
setblock 404 67 313 minecraft:red_terracotta
setblock 404 67 314 minecraft:stripped_oak_log
fill 404 67 315 404 70 315 minecraft:red_terracotta
setblock 405 67 313 minecraft:stripped_oak_log
fill 405 67 314 405 70 314 minecraft:red_terracotta
setblock 406 67 277 minecraft:stripped_oak_log
fill 406 67 313 406 70 313 minecraft:red_terracotta
setblock 407 67 276 minecraft:stripped_oak_log
setblock 407 67 316 minecraft:stripped_oak_log
fill 408 67 276 408 70 276 minecraft:red_terracotta
setblock 408 67 315 minecraft:stripped_oak_log
fill 408 67 316 408 70 316 minecraft:red_terracotta
setblock 409 67 314 minecraft:stripped_oak_log
fill 409 67 315 409 70 315 minecraft:red_terracotta
setblock 410 67 293 minecraft:shroomlight
setblock 410 67 295 minecraft:shroomlight
setblock 410 67 297 minecraft:shroomlight
setblock 410 67 299 minecraft:shroomlight
setblock 410 67 301 minecraft:shroomlight
setblock 410 67 313 minecraft:stripped_oak_log
fill 410 67 314 410 70 314 minecraft:red_terracotta
setblock 411 67 292 minecraft:shroomlight
setblock 411 67 294 minecraft:shroomlight
setblock 411 67 296 minecraft:shroomlight
setblock 411 67 298 minecraft:shroomlight
setblock 411 67 300 minecraft:shroomlight
setblock 411 67 302 minecraft:shroomlight
setblock 411 67 313 minecraft:red_terracotta
setblock 412 67 293 minecraft:shroomlight
setblock 412 67 295 minecraft:shroomlight
setblock 412 67 297 minecraft:shroomlight
setblock 412 67 299 minecraft:shroomlight
setblock 412 67 301 minecraft:shroomlight
setblock 412 67 316 minecraft:stripped_oak_log
setblock 413 67 292 minecraft:shroomlight
setblock 413 67 294 minecraft:shroomlight
setblock 413 67 296 minecraft:shroomlight
setblock 413 67 298 minecraft:shroomlight
setblock 413 67 300 minecraft:shroomlight
setblock 413 67 302 minecraft:shroomlight
setblock 413 67 315 minecraft:stripped_oak_log
fill 413 67 316 413 70 316 minecraft:red_terracotta
setblock 414 67 293 minecraft:shroomlight
setblock 414 67 295 minecraft:shroomlight
setblock 414 67 297 minecraft:shroomlight
setblock 414 67 299 minecraft:shroomlight
setblock 414 67 301 minecraft:shroomlight
setblock 414 67 315 minecraft:red_terracotta
setblock 415 67 292 minecraft:shroomlight
setblock 415 67 294 minecraft:shroomlight
setblock 415 67 296 minecraft:shroomlight
setblock 415 67 298 minecraft:shroomlight
setblock 415 67 300 minecraft:shroomlight
setblock 415 67 302 minecraft:shroomlight
setblock 416 67 293 minecraft:shroomlight
setblock 416 67 295 minecraft:shroomlight
setblock 416 67 297 minecraft:shroomlight
setblock 416 67 299 minecraft:shroomlight
setblock 416 67 301 minecraft:shroomlight
setblock 416 67 312 minecraft:stripped_oak_log
setblock 416 67 313 minecraft:red_terracotta
setblock 417 67 291 minecraft:stripped_oak_log
setblock 417 67 292 minecraft:shroomlight
setblock 417 67 294 minecraft:shroomlight
setblock 417 67 296 minecraft:shroomlight
setblock 417 67 298 minecraft:shroomlight
setblock 417 67 300 minecraft:shroomlight
fill 417 67 301 417 70 301 minecraft:stripped_oak_log
setblock 417 67 302 minecraft:shroomlight
setblock 417 67 306 minecraft:stripped_oak_log
setblock 417 67 307 minecraft:red_terracotta
setblock 417 67 311 minecraft:stripped_oak_log
fill 417 67 312 417 70 312 minecraft:red_terracotta
fill 376 68 275 376 71 317 minecraft:white_terracotta
fill 377 68 275 418 71 275 minecraft:white_terracotta
fill 377 68 287 377 68 289 minecraft:red_terracotta
setblock 377 68 290 minecraft:stripped_oak_log
fill 377 68 291 377 68 294 minecraft:red_terracotta
setblock 377 68 295 minecraft:stripped_oak_log
fill 377 68 296 377 71 296 minecraft:red_terracotta
fill 377 68 317 418 71 317 minecraft:white_terracotta
setblock 378 68 289 minecraft:stripped_oak_log
fill 378 68 290 378 71 290 minecraft:red_terracotta
setblock 378 68 294 minecraft:stripped_oak_log
fill 378 68 295 378 71 295 minecraft:red_terracotta
fill 382 68 276 385 68 276 minecraft:red_terracotta
fill 382 68 316 385 68 316 minecraft:red_terracotta
fill 384 68 315 384 70 315 minecraft:red_terracotta
setblock 385 68 277 minecraft:stripped_oak_log
fill 385 68 305 385 75 305 minecraft:brown_terracotta
setblock 386 68 276 minecraft:stripped_oak_log
fill 386 68 277 386 71 277 minecraft:red_terracotta
setblock 386 68 316 minecraft:stripped_oak_log
fill 387 68 276 387 71 276 minecraft:red_terracotta
setblock 387 68 315 minecraft:stripped_oak_log
fill 387 68 316 387 71 316 minecraft:red_terracotta
fill 388 68 315 388 71 315 minecraft:red_terracotta
setblock 390 68 277 minecraft:stripped_oak_log
setblock 391 68 276 minecraft:stripped_oak_log
setblock 391 68 316 minecraft:stripped_oak_log
fill 392 68 276 395 68 276 minecraft:red_terracotta
fill 392 68 316 395 68 316 minecraft:red_terracotta
setblock 396 68 276 minecraft:stripped_oak_log
setblock 396 68 316 minecraft:stripped_oak_log
fill 397 68 276 400 68 276 minecraft:red_terracotta
fill 397 68 316 400 68 316 minecraft:red_terracotta
setblock 401 68 276 minecraft:stripped_oak_log
fill 401 68 314 402 68 314 minecraft:red_terracotta
setblock 401 68 316 minecraft:stripped_oak_log
fill 402 68 276 402 71 276 minecraft:red_terracotta
setblock 402 68 315 minecraft:stripped_oak_log
fill 402 68 316 402 71 316 minecraft:red_terracotta
setblock 403 68 314 minecraft:stripped_oak_log
fill 403 68 315 403 71 315 minecraft:red_terracotta
setblock 404 68 313 minecraft:stripped_oak_log
fill 404 68 314 404 71 314 minecraft:red_terracotta
fill 405 68 313 405 71 313 minecraft:red_terracotta
setblock 406 68 276 minecraft:stripped_oak_log
setblock 406 68 316 minecraft:stripped_oak_log
fill 407 68 276 407 71 276 minecraft:red_terracotta
setblock 407 68 315 minecraft:stripped_oak_log
fill 407 68 316 407 71 316 minecraft:red_terracotta
setblock 408 68 314 minecraft:stripped_oak_log
fill 408 68 315 408 71 315 minecraft:red_terracotta
setblock 409 68 313 minecraft:stripped_oak_log
fill 409 68 314 409 71 314 minecraft:red_terracotta
fill 410 68 293 410 70 293 minecraft:stripped_oak_log
fill 410 68 295 410 70 295 minecraft:stripped_oak_log
fill 410 68 297 410 70 297 minecraft:stripped_oak_log
fill 410 68 299 410 70 299 minecraft:stripped_oak_log
fill 410 68 301 410 70 301 minecraft:stripped_oak_log
fill 411 68 292 411 70 292 minecraft:stripped_oak_log
fill 411 68 294 411 70 294 minecraft:stripped_oak_log
fill 411 68 296 411 70 296 minecraft:stripped_oak_log
fill 411 68 298 411 70 298 minecraft:stripped_oak_log
fill 411 68 300 411 70 300 minecraft:stripped_oak_log
fill 411 68 302 411 70 302 minecraft:stripped_oak_log
setblock 411 68 316 minecraft:stripped_oak_log
fill 412 68 293 412 70 293 minecraft:stripped_oak_log
fill 412 68 295 412 70 295 minecraft:stripped_oak_log
fill 412 68 297 412 70 297 minecraft:stripped_oak_log
fill 412 68 299 412 70 299 minecraft:stripped_oak_log
fill 412 68 301 412 70 301 minecraft:stripped_oak_log
fill 412 68 313 412 69 313 minecraft:iron_bars
setblock 412 68 315 minecraft:stripped_oak_log
fill 412 68 316 412 71 316 minecraft:red_terracotta
fill 413 68 292 413 70 292 minecraft:stripped_oak_log
fill 413 68 294 413 70 294 minecraft:stripped_oak_log
fill 413 68 296 413 70 296 minecraft:stripped_oak_log
fill 413 68 298 413 70 298 minecraft:stripped_oak_log
fill 413 68 300 413 70 300 minecraft:stripped_oak_log
fill 413 68 302 413 70 302 minecraft:stripped_oak_log
fill 413 68 315 413 69 315 minecraft:red_terracotta
fill 414 68 293 414 70 293 minecraft:stripped_oak_log
fill 414 68 295 414 70 295 minecraft:stripped_oak_log
fill 414 68 297 414 70 297 minecraft:stripped_oak_log
fill 414 68 299 414 70 299 minecraft:stripped_oak_log
fill 414 68 301 414 70 301 minecraft:stripped_oak_log
fill 415 68 292 415 70 292 minecraft:stripped_oak_log
fill 415 68 294 415 70 294 minecraft:stripped_oak_log
fill 415 68 296 415 70 296 minecraft:stripped_oak_log
fill 415 68 298 415 70 298 minecraft:stripped_oak_log
fill 415 68 300 415 70 300 minecraft:stripped_oak_log
fill 415 68 302 415 70 302 minecraft:stripped_oak_log
fill 416 68 293 416 70 293 minecraft:stripped_oak_log
fill 416 68 295 417 68 295 minecraft:stripped_oak_log
fill 416 68 297 416 70 297 minecraft:stripped_oak_log
fill 416 68 299 416 70 299 minecraft:stripped_oak_log
fill 416 68 301 416 70 301 minecraft:stripped_oak_log
setblock 417 68 290 minecraft:stripped_oak_log
fill 417 68 291 417 70 292 minecraft:red_terracotta
setblock 417 68 294 minecraft:red_terracotta
fill 417 68 296 417 71 296 minecraft:red_terracotta
fill 417 68 298 417 70 298 minecraft:stripped_oak_log
fill 417 68 300 417 70 300 minecraft:stripped_oak_log
fill 417 68 302 417 70 302 minecraft:stripped_oak_log
setblock 417 68 310 minecraft:stripped_oak_log
fill 417 68 311 417 70 311 minecraft:red_terracotta
setblock 417 68 315 minecraft:stripped_oak_log
fill 418 68 276 418 71 316 minecraft:white_terracotta
setblock 377 69 288 minecraft:red_terracotta
setblock 377 69 289 minecraft:stripped_oak_log
fill 377 69 290 377 69 293 minecraft:red_terracotta
setblock 377 69 294 minecraft:stripped_oak_log
fill 377 69 295 377 72 295 minecraft:red_terracotta
setblock 378 69 293 minecraft:stripped_oak_log
fill 378 69 294 378 72 294 minecraft:red_terracotta
fill 381 69 316 384 69 316 minecraft:red_terracotta
fill 382 69 276 384 69 276 minecraft:red_terracotta
setblock 384 69 277 minecraft:stripped_oak_log
fill 384 69 304 384 75 305 minecraft:brown_terracotta
setblock 385 69 276 minecraft:stripped_oak_log
fill 385 69 277 385 72 277 minecraft:red_terracotta
fill 385 69 303 385 75 303 minecraft:brown_terracotta
setblock 385 69 316 minecraft:stripped_oak_log
fill 386 69 276 386 72 276 minecraft:red_terracotta
fill 386 69 304 386 75 305 minecraft:brown_terracotta
setblock 386 69 315 minecraft:stripped_oak_log
fill 386 69 316 386 72 316 minecraft:red_terracotta
fill 387 69 315 387 72 315 minecraft:red_terracotta
setblock 389 69 277 minecraft:stripped_oak_log
fill 389 69 278 389 70 278 minecraft:iron_bars
setblock 390 69 276 minecraft:stripped_oak_log
fill 390 69 277 390 72 277 minecraft:red_terracotta
setblock 390 69 316 minecraft:stripped_oak_log
fill 391 69 276 394 69 276 minecraft:red_terracotta
fill 391 69 316 394 69 316 minecraft:red_terracotta
setblock 395 69 276 minecraft:stripped_oak_log
setblock 395 69 316 minecraft:stripped_oak_log
fill 396 69 276 399 69 276 minecraft:red_terracotta
fill 396 69 316 399 69 316 minecraft:red_terracotta
fill 398 69 315 398 71 315 minecraft:red_terracotta
setblock 400 69 276 minecraft:stripped_oak_log
setblock 400 69 316 minecraft:stripped_oak_log
fill 401 69 276 401 72 276 minecraft:red_terracotta
setblock 401 69 314 minecraft:red_terracotta
setblock 401 69 315 minecraft:stripped_oak_log
fill 401 69 316 401 72 316 minecraft:red_terracotta
setblock 402 69 314 minecraft:stripped_oak_log
fill 402 69 315 402 72 315 minecraft:red_terracotta
fill 403 69 314 403 72 314 minecraft:red_terracotta
fill 404 69 313 404 72 313 minecraft:red_terracotta
setblock 405 69 276 minecraft:stripped_oak_log
setblock 405 69 316 minecraft:stripped_oak_log
fill 406 69 276 406 72 276 minecraft:red_terracotta
setblock 406 69 315 minecraft:stripped_oak_log
fill 406 69 316 406 72 316 minecraft:red_terracotta
setblock 407 69 314 minecraft:stripped_oak_log
fill 407 69 315 407 72 315 minecraft:red_terracotta
setblock 408 69 313 minecraft:stripped_oak_log
fill 408 69 314 408 72 314 minecraft:red_terracotta
setblock 410 69 276 minecraft:stripped_oak_log
setblock 410 69 316 minecraft:stripped_oak_log
setblock 411 69 315 minecraft:stripped_oak_log
fill 411 69 316 411 72 316 minecraft:red_terracotta
setblock 412 69 314 minecraft:iron_bars
fill 412 69 315 412 70 315 minecraft:red_terracotta
setblock 415 69 316 minecraft:stripped_oak_log
fill 416 69 295 416 70 295 minecraft:stripped_oak_log
setblock 417 69 294 minecraft:stripped_oak_log
fill 417 69 295 417 72 295 minecraft:red_terracotta
fill 417 69 297 417 70 297 minecraft:red_terracotta
setblock 417 69 310 minecraft:red_terracotta
setblock 417 69 314 minecraft:stripped_oak_log
setblock 417 69 315 minecraft:red_terracotta
setblock 377 70 288 minecraft:stripped_oak_log
fill 377 70 289 377 70 292 minecraft:red_terracotta
setblock 377 70 293 minecraft:stripped_oak_log
fill 377 70 294 377 73 294 minecraft:red_terracotta
setblock 377 70 298 minecraft:stripped_oak_log
setblock 378 70 292 minecraft:stripped_oak_log
fill 378 70 293 378 73 293 minecraft:red_terracotta
setblock 378 70 296 minecraft:red_terracotta
fill 381 70 276 383 70 276 minecraft:red_terracotta
fill 381 70 316 383 70 316 minecraft:red_terracotta
setblock 383 70 277 minecraft:stripped_oak_log
fill 383 70 315 383 71 315 minecraft:red_terracotta
setblock 384 70 276 minecraft:stripped_oak_log
fill 384 70 277 384 73 277 minecraft:red_terracotta
fill 384 70 303 384 75 303 minecraft:brown_terracotta
setblock 384 70 316 minecraft:stripped_oak_log
fill 385 70 276 385 73 276 minecraft:red_terracotta
fill 385 70 306 385 75 306 minecraft:brown_terracotta
setblock 385 70 315 minecraft:stripped_oak_log
fill 385 70 316 385 73 316 minecraft:red_terracotta
fill 386 70 303 386 75 303 minecraft:brown_terracotta
fill 386 70 315 386 73 315 minecraft:red_terracotta
setblock 388 70 277 minecraft:stripped_oak_log
setblock 389 70 276 minecraft:stripped_oak_log
fill 389 70 277 389 73 277 minecraft:red_terracotta
setblock 389 70 316 minecraft:stripped_oak_log
fill 390 70 276 393 70 276 minecraft:red_terracotta
setblock 390 70 315 minecraft:stripped_oak_log
fill 390 70 316 393 70 316 minecraft:red_terracotta
setblock 394 70 276 minecraft:stripped_oak_log
setblock 394 70 316 minecraft:stripped_oak_log
fill 395 70 276 398 70 276 minecraft:red_terracotta
fill 395 70 316 398 70 316 minecraft:red_terracotta
setblock 399 70 276 minecraft:stripped_oak_log
setblock 399 70 316 minecraft:stripped_oak_log
fill 400 70 276 400 73 276 minecraft:red_terracotta
setblock 400 70 315 minecraft:stripped_oak_log
fill 400 70 316 400 73 316 minecraft:red_terracotta
setblock 401 70 314 minecraft:stripped_oak_log
fill 401 70 315 401 73 315 minecraft:red_terracotta
fill 402 70 314 402 73 314 minecraft:red_terracotta
setblock 403 70 277 minecraft:stripped_oak_log
setblock 404 70 276 minecraft:stripped_oak_log
fill 404 70 277 405 72 277 minecraft:red_terracotta
setblock 404 70 316 minecraft:stripped_oak_log
fill 405 70 276 405 73 276 minecraft:red_terracotta
setblock 405 70 315 minecraft:stripped_oak_log
fill 405 70 316 405 73 316 minecraft:red_terracotta
setblock 406 70 314 minecraft:stripped_oak_log
fill 406 70 315 406 73 315 minecraft:red_terracotta
setblock 407 70 313 minecraft:stripped_oak_log
fill 407 70 314 407 73 314 minecraft:red_terracotta
setblock 409 70 276 minecraft:stripped_oak_log
setblock 409 70 316 minecraft:stripped_oak_log
setblock 410 70 315 minecraft:stripped_oak_log
fill 410 70 316 410 73 316 minecraft:red_terracotta
fill 411 70 315 411 73 315 minecraft:red_terracotta
setblock 414 70 316 minecraft:stripped_oak_log
setblock 417 70 293 minecraft:stripped_oak_log
fill 417 70 294 417 73 294 minecraft:red_terracotta
setblock 417 70 313 minecraft:stripped_oak_log
fill 417 70 314 417 73 314 minecraft:red_terracotta
fill 377 71 288 377 71 291 minecraft:red_terracotta
setblock 377 71 292 minecraft:stripped_oak_log
fill 377 71 293 377 74 293 minecraft:red_terracotta
setblock 377 71 297 minecraft:stripped_oak_log
fill 377 71 298 377 73 299 minecraft:red_terracotta
setblock 378 71 291 minecraft:stripped_oak_log
fill 378 71 292 378 74 292 minecraft:red_terracotta
setblock 378 71 296 minecraft:stripped_oak_log
setblock 379 71 278 minecraft:light[level=15]
setblock 379 71 285 minecraft:light[level=12]
setblock 379 71 286 minecraft:light[level=15]
setblock 379 71 292 minecraft:light[level=12]
fill 379 71 293 379 72 293 minecraft:red_terracotta
setblock 379 71 294 minecraft:light[level=15]
setblock 379 71 299 minecraft:light[level=12]
setblock 379 71 302 minecraft:light[level=15]
setblock 379 71 306 minecraft:light[level=12]
setblock 379 71 310 minecraft:light[level=15]
setblock 379 71 313 minecraft:light[level=12]
fill 380 71 276 382 71 276 minecraft:red_terracotta
fill 380 71 316 382 71 316 minecraft:red_terracotta
setblock 382 71 277 minecraft:stripped_oak_log
setblock 383 71 276 minecraft:stripped_oak_log
fill 383 71 277 383 74 277 minecraft:red_terracotta
fill 383 71 303 383 75 305 minecraft:brown_terracotta
setblock 383 71 316 minecraft:stripped_oak_log
fill 384 71 276 384 74 276 minecraft:red_terracotta
fill 384 71 306 384 75 306 minecraft:brown_terracotta
setblock 384 71 315 minecraft:stripped_oak_log
fill 384 71 316 384 74 316 minecraft:red_terracotta
fill 385 71 302 385 75 302 minecraft:brown_terracotta
fill 385 71 315 385 74 315 minecraft:red_terracotta
setblock 386 71 278 minecraft:light[level=12]
setblock 386 71 285 minecraft:light[level=12]
setblock 386 71 292 minecraft:light[level=12]
setblock 386 71 299 minecraft:light[level=12]
fill 386 71 306 386 75 306 minecraft:brown_terracotta
setblock 386 71 313 minecraft:light[level=12]
setblock 387 71 277 minecraft:stripped_oak_log
setblock 387 71 278 minecraft:light[level=15]
setblock 387 71 286 minecraft:light[level=15]
setblock 387 71 294 minecraft:light[level=15]
setblock 387 71 302 minecraft:light[level=15]
fill 387 71 303 387 75 305 minecraft:brown_terracotta
setblock 387 71 310 minecraft:light[level=15]
setblock 388 71 276 minecraft:stripped_oak_log
fill 388 71 277 388 74 277 minecraft:red_terracotta
setblock 388 71 316 minecraft:stripped_oak_log
fill 389 71 276 392 71 276 minecraft:red_terracotta
setblock 389 71 315 minecraft:stripped_oak_log
fill 389 71 316 392 71 316 minecraft:red_terracotta
setblock 393 71 276 minecraft:stripped_oak_log
setblock 393 71 278 minecraft:light[level=12]
setblock 393 71 285 minecraft:light[level=12]
setblock 393 71 292 minecraft:light[level=12]
setblock 393 71 299 minecraft:light[level=12]
setblock 393 71 306 minecraft:light[level=12]
setblock 393 71 313 minecraft:light[level=12]
setblock 393 71 316 minecraft:stripped_oak_log
fill 394 71 276 397 71 276 minecraft:red_terracotta
fill 394 71 316 397 71 316 minecraft:red_terracotta
setblock 395 71 278 minecraft:light[level=15]
setblock 395 71 286 minecraft:light[level=15]
setblock 395 71 302 minecraft:light[level=15]
setblock 395 71 310 minecraft:light[level=15]
fill 397 71 315 397 72 315 minecraft:red_terracotta
setblock 398 71 276 minecraft:stripped_oak_log
setblock 398 71 316 minecraft:stripped_oak_log
fill 399 71 276 399 74 276 minecraft:red_terracotta
setblock 399 71 315 minecraft:stripped_oak_log
fill 399 71 316 399 74 316 minecraft:red_terracotta
setblock 400 71 278 minecraft:light[level=12]
setblock 400 71 285 minecraft:light[level=12]
setblock 400 71 292 minecraft:light[level=12]
setblock 400 71 299 minecraft:light[level=12]
setblock 400 71 306 minecraft:light[level=12]
setblock 400 71 313 minecraft:light[level=12]
setblock 400 71 314 minecraft:stripped_oak_log
fill 400 71 315 400 74 315 minecraft:red_terracotta
setblock 401 71 277 minecraft:red_terracotta
fill 401 71 314 401 74 314 minecraft:red_terracotta
setblock 402 71 277 minecraft:stripped_oak_log
setblock 403 71 276 minecraft:stripped_oak_log
fill 403 71 277 403 74 277 minecraft:red_terracotta
setblock 403 71 278 minecraft:light[level=15]
setblock 403 71 286 minecraft:light[level=15]
setblock 403 71 294 minecraft:light[level=15]
setblock 403 71 302 minecraft:light[level=15]
setblock 403 71 310 minecraft:light[level=15]
setblock 403 71 316 minecraft:stripped_oak_log
fill 404 71 276 404 74 276 minecraft:red_terracotta
setblock 404 71 315 minecraft:stripped_oak_log
fill 404 71 316 404 74 316 minecraft:red_terracotta
setblock 405 71 314 minecraft:stripped_oak_log
fill 405 71 315 405 74 315 minecraft:red_terracotta
setblock 406 71 277 minecraft:red_terracotta
setblock 406 71 313 minecraft:stripped_oak_log
fill 406 71 314 406 74 314 minecraft:red_terracotta
setblock 407 71 278 minecraft:light[level=12]
setblock 407 71 285 minecraft:light[level=12]
setblock 407 71 292 minecraft:light[level=12]
setblock 407 71 299 minecraft:light[level=12]
setblock 407 71 306 minecraft:light[level=12]
setblock 407 71 313 minecraft:light[level=12]
setblock 408 71 276 minecraft:stripped_oak_log
setblock 408 71 316 minecraft:stripped_oak_log
fill 409 71 276 409 74 276 minecraft:red_terracotta
setblock 409 71 315 minecraft:stripped_oak_log
fill 409 71 316 409 74 316 minecraft:red_terracotta
fill 410 71 315 410 74 315 minecraft:red_terracotta
setblock 411 71 278 minecraft:light[level=15]
setblock 411 71 286 minecraft:light[level=15]
fill 411 71 293 411 72 293 minecraft:shroomlight
setblock 411 71 294 minecraft:light[level=15]
setblock 411 71 302 minecraft:light[level=15]
setblock 411 71 310 minecraft:light[level=15]
setblock 413 71 316 minecraft:stripped_oak_log
setblock 414 71 278 minecraft:light[level=12]
setblock 414 71 285 minecraft:light[level=12]
setblock 414 71 292 minecraft:light[level=12]
setblock 414 71 299 minecraft:light[level=12]
setblock 414 71 306 minecraft:light[level=12]
setblock 414 71 313 minecraft:light[level=12]
fill 414 71 316 414 74 316 minecraft:red_terracotta
setblock 417 71 291 minecraft:red_terracotta
setblock 417 71 292 minecraft:stripped_oak_log
fill 417 71 293 417 74 293 minecraft:red_terracotta
setblock 417 71 297 minecraft:stripped_oak_log
fill 417 71 298 417 73 299 minecraft:red_terracotta
fill 417 71 313 417 74 313 minecraft:red_terracotta
fill 376 72 275 376 75 317 minecraft:terracotta
fill 377 72 275 418 75 275 minecraft:terracotta
fill 377 72 288 377 72 290 minecraft:red_terracotta
setblock 377 72 291 minecraft:stripped_oak_log
fill 377 72 292 377 75 292 minecraft:red_terracotta
setblock 377 72 296 minecraft:stripped_oak_log
fill 377 72 297 378 74 297 minecraft:red_terracotta
fill 377 72 317 418 75 317 minecraft:terracotta
fill 378 72 276 381 72 276 minecraft:red_terracotta
setblock 378 72 290 minecraft:stripped_oak_log
fill 378 72 291 378 75 291 minecraft:red_terracotta
setblock 378 72 295 minecraft:stripped_oak_log
fill 378 72 296 378 75 296 minecraft:red_terracotta
fill 378 72 298 378 73 298 minecraft:red_terracotta
fill 379 72 292 379 73 292 minecraft:red_terracotta
setblock 379 72 294 minecraft:stripped_oak_log
fill 379 72 295 379 75 295 minecraft:red_terracotta
fill 379 72 316 381 72 316 minecraft:red_terracotta
setblock 381 72 277 minecraft:stripped_oak_log
setblock 382 72 276 minecraft:stripped_oak_log
fill 382 72 277 382 75 277 minecraft:red_terracotta
setblock 382 72 315 minecraft:red_terracotta
setblock 382 72 316 minecraft:stripped_oak_log
fill 383 72 276 383 75 276 minecraft:red_terracotta
fill 383 72 306 383 75 306 minecraft:brown_terracotta
setblock 383 72 315 minecraft:stripped_oak_log
fill 383 72 316 383 75 316 minecraft:red_terracotta
fill 384 72 302 384 75 302 minecraft:brown_terracotta
fill 384 72 315 384 75 315 minecraft:red_terracotta
setblock 385 72 278 minecraft:stripped_oak_log
fill 385 72 307 385 75 307 minecraft:brown_terracotta
setblock 386 72 277 minecraft:stripped_oak_log
fill 386 72 302 386 75 302 minecraft:brown_terracotta
setblock 387 72 276 minecraft:stripped_oak_log
fill 387 72 277 387 75 277 minecraft:red_terracotta
fill 387 72 306 387 75 306 minecraft:brown_terracotta
setblock 387 72 316 minecraft:stripped_oak_log
fill 388 72 276 391 72 276 minecraft:red_terracotta
setblock 388 72 315 minecraft:stripped_oak_log
fill 388 72 316 391 72 316 minecraft:red_terracotta
fill 389 72 315 389 75 315 minecraft:red_terracotta
setblock 391 72 277 minecraft:stripped_oak_log
setblock 392 72 276 minecraft:stripped_oak_log
setblock 392 72 316 minecraft:stripped_oak_log
fill 393 72 276 396 72 276 minecraft:red_terracotta
fill 393 72 316 396 72 316 minecraft:red_terracotta
fill 396 72 315 396 73 315 minecraft:red_terracotta
setblock 397 72 276 minecraft:stripped_oak_log
setblock 397 72 316 minecraft:stripped_oak_log
fill 398 72 276 398 75 276 minecraft:red_terracotta
setblock 398 72 315 minecraft:stripped_oak_log
fill 398 72 316 398 75 316 minecraft:red_terracotta
fill 399 72 277 400 72 277 minecraft:red_terracotta
fill 399 72 315 399 75 315 minecraft:red_terracotta
fill 400 72 314 400 75 314 minecraft:red_terracotta
setblock 401 72 277 minecraft:stripped_oak_log
setblock 402 72 276 minecraft:stripped_oak_log
fill 402 72 277 402 75 277 minecraft:red_terracotta
setblock 402 72 316 minecraft:stripped_oak_log
fill 403 72 276 403 75 276 minecraft:red_terracotta
setblock 403 72 315 minecraft:stripped_oak_log
fill 403 72 316 403 75 316 minecraft:red_terracotta
setblock 404 72 314 minecraft:stripped_oak_log
fill 404 72 315 404 75 315 minecraft:red_terracotta
setblock 405 72 313 minecraft:stripped_oak_log
fill 405 72 314 405 75 314 minecraft:red_terracotta
setblock 406 72 277 minecraft:stripped_oak_log
setblock 407 72 276 minecraft:stripped_oak_log
setblock 407 72 316 minecraft:stripped_oak_log
fill 408 72 276 408 75 276 minecraft:red_terracotta
setblock 408 72 315 minecraft:stripped_oak_log
fill 408 72 316 408 75 316 minecraft:red_terracotta
setblock 409 72 314 minecraft:stripped_oak_log
fill 409 72 315 409 75 315 minecraft:red_terracotta
setblock 412 72 316 minecraft:stripped_oak_log
fill 413 72 316 413 75 316 minecraft:red_terracotta
fill 416 72 295 416 72 296 minecraft:red_terracotta
setblock 417 72 290 minecraft:red_terracotta
setblock 417 72 291 minecraft:stripped_oak_log
fill 417 72 292 417 75 292 minecraft:red_terracotta
setblock 417 72 296 minecraft:stripped_oak_log
fill 417 72 297 417 75 297 minecraft:red_terracotta
setblock 417 72 300 minecraft:red_terracotta
setblock 417 72 301 minecraft:stripped_oak_log
setblock 417 72 315 minecraft:red_terracotta
fill 418 72 276 418 75 316 minecraft:terracotta
fill 377 73 276 377 75 277 minecraft:red_terracotta
fill 377 73 287 377 73 289 minecraft:red_terracotta
setblock 377 73 290 minecraft:stripped_oak_log
fill 377 73 291 377 76 291 minecraft:red_terracotta
setblock 377 73 295 minecraft:stripped_oak_log
fill 377 73 296 377 76 296 minecraft:red_terracotta
setblock 377 73 300 minecraft:stripped_oak_log
fill 377 73 301 377 76 301 minecraft:red_terracotta
fill 378 73 276 380 73 276 minecraft:red_terracotta
setblock 378 73 289 minecraft:stripped_oak_log
fill 378 73 290 378 76 290 minecraft:red_terracotta
setblock 378 73 294 minecraft:stripped_oak_log
fill 378 73 295 378 76 295 minecraft:red_terracotta
setblock 378 73 299 minecraft:stripped_oak_log
fill 378 73 316 380 73 316 minecraft:red_terracotta
setblock 379 73 277 minecraft:red_terracotta
fill 379 73 291 379 74 291 minecraft:red_terracotta
setblock 379 73 293 minecraft:stripped_oak_log
fill 379 73 294 379 76 294 minecraft:red_terracotta
fill 379 73 296 379 73 297 minecraft:red_terracotta
setblock 380 73 277 minecraft:stripped_oak_log
setblock 381 73 276 minecraft:stripped_oak_log
fill 381 73 277 381 76 277 minecraft:red_terracotta
setblock 381 73 315 minecraft:red_terracotta
setblock 381 73 316 minecraft:stripped_oak_log
fill 382 73 276 382 76 276 minecraft:red_terracotta
fill 382 73 278 383 73 278 minecraft:red_terracotta
fill 382 73 303 382 75 305 minecraft:brown_terracotta
setblock 382 73 315 minecraft:stripped_oak_log
fill 382 73 316 382 76 316 minecraft:red_terracotta
fill 383 73 302 383 75 302 minecraft:brown_terracotta
fill 383 73 315 383 76 315 minecraft:red_terracotta
setblock 384 73 278 minecraft:stripped_oak_log
fill 384 73 301 385 75 301 minecraft:brown_terracotta
fill 384 73 307 384 75 307 minecraft:brown_terracotta
setblock 385 73 277 minecraft:stripped_oak_log
fill 385 73 278 387 74 278 minecraft:red_terracotta
setblock 386 73 276 minecraft:stripped_oak_log
fill 386 73 277 386 76 277 minecraft:red_terracotta
fill 386 73 307 386 75 307 minecraft:brown_terracotta
setblock 386 73 316 minecraft:stripped_oak_log
fill 387 73 276 390 73 276 minecraft:red_terracotta
fill 387 73 302 387 75 302 minecraft:brown_terracotta
setblock 387 73 315 minecraft:stripped_oak_log
fill 387 73 316 390 73 316 minecraft:red_terracotta
fill 388 73 303 388 75 305 minecraft:brown_terracotta
fill 388 73 315 388 76 315 minecraft:red_terracotta
setblock 390 73 277 minecraft:stripped_oak_log
setblock 391 73 276 minecraft:stripped_oak_log
fill 391 73 277 392 75 277 minecraft:red_terracotta
setblock 391 73 316 minecraft:stripped_oak_log
fill 392 73 276 395 73 276 minecraft:red_terracotta
fill 392 73 316 395 73 316 minecraft:red_terracotta
fill 395 73 315 395 74 315 minecraft:red_terracotta
setblock 396 73 276 minecraft:stripped_oak_log
setblock 396 73 316 minecraft:stripped_oak_log
fill 397 73 276 397 75 277 minecraft:red_terracotta
setblock 397 73 315 minecraft:stripped_oak_log
fill 397 73 316 397 76 316 minecraft:red_terracotta
fill 398 73 277 399 73 277 minecraft:red_terracotta
fill 398 73 315 398 76 315 minecraft:red_terracotta
fill 399 73 314 399 76 314 minecraft:red_terracotta
setblock 400 73 277 minecraft:stripped_oak_log
setblock 401 73 276 minecraft:stripped_oak_log
fill 401 73 277 401 76 277 minecraft:red_terracotta
setblock 401 73 316 minecraft:stripped_oak_log
fill 402 73 276 402 76 276 minecraft:red_terracotta
setblock 402 73 315 minecraft:stripped_oak_log
fill 402 73 316 402 76 316 minecraft:red_terracotta
setblock 403 73 313 minecraft:red_terracotta
setblock 403 73 314 minecraft:stripped_oak_log
fill 403 73 315 403 76 315 minecraft:red_terracotta
setblock 404 73 277 minecraft:red_terracotta
setblock 404 73 313 minecraft:stripped_oak_log
fill 404 73 314 404 76 314 minecraft:red_terracotta
setblock 405 73 277 minecraft:stripped_oak_log
setblock 405 73 313 minecraft:red_terracotta
setblock 406 73 276 minecraft:stripped_oak_log
fill 406 73 277 407 75 277 minecraft:red_terracotta
setblock 406 73 316 minecraft:stripped_oak_log
fill 407 73 276 407 76 276 minecraft:red_terracotta
setblock 407 73 315 minecraft:stripped_oak_log
fill 407 73 316 407 76 316 minecraft:red_terracotta
setblock 408 73 314 minecraft:stripped_oak_log
fill 408 73 315 408 76 315 minecraft:red_terracotta
setblock 410 73 276 minecraft:red_terracotta
fill 411 73 293 411 80 293 minecraft:brown_terracotta
setblock 411 73 316 minecraft:stripped_oak_log
fill 412 73 316 412 76 316 minecraft:red_terracotta
setblock 415 73 316 minecraft:red_terracotta
fill 416 73 293 416 73 295 minecraft:red_terracotta
setblock 416 73 296 minecraft:stripped_oak_log
fill 416 73 297 416 74 299 minecraft:red_terracotta
setblock 416 73 316 minecraft:stripped_oak_log
setblock 417 73 290 minecraft:stripped_oak_log
fill 417 73 291 417 76 291 minecraft:red_terracotta
setblock 417 73 295 minecraft:stripped_oak_log
fill 417 73 296 417 76 296 minecraft:red_terracotta
setblock 417 73 300 minecraft:stripped_oak_log
fill 417 73 301 417 75 302 minecraft:red_terracotta
setblock 417 73 315 minecraft:stripped_oak_log
fill 417 73 316 417 76 316 minecraft:red_terracotta
setblock 377 74 278 minecraft:red_terracotta
setblock 377 74 279 minecraft:stripped_oak_log
fill 377 74 280 377 75 282 minecraft:red_terracotta
fill 377 74 285 377 74 288 minecraft:red_terracotta
setblock 377 74 289 minecraft:stripped_oak_log
fill 377 74 290 377 77 290 minecraft:red_terracotta
setblock 377 74 294 minecraft:stripped_oak_log
fill 377 74 295 377 77 295 minecraft:red_terracotta
setblock 377 74 298 minecraft:red_terracotta
setblock 377 74 299 minecraft:stripped_oak_log
fill 377 74 300 378 76 300 minecraft:red_terracotta
fill 377 74 302 377 75 302 minecraft:red_terracotta
fill 377 74 315 377 76 316 minecraft:red_terracotta
fill 378 74 276 378 74 277 minecraft:red_terracotta
setblock 378 74 278 minecraft:stripped_oak_log
setblock 378 74 288 minecraft:stripped_oak_log
fill 378 74 289 378 77 289 minecraft:red_terracotta
setblock 378 74 293 minecraft:stripped_oak_log
fill 378 74 294 378 77 294 minecraft:red_terracotta
setblock 378 74 298 minecraft:stripped_oak_log
fill 378 74 299 378 77 299 minecraft:red_terracotta
fill 378 74 316 379 74 316 minecraft:red_terracotta
setblock 379 74 276 minecraft:red_terracotta
setblock 379 74 277 minecraft:stripped_oak_log
setblock 379 74 292 minecraft:stripped_oak_log
fill 379 74 293 379 77 293 minecraft:red_terracotta
setblock 379 74 296 minecraft:red_terracotta
setblock 379 74 297 minecraft:stripped_oak_log
fill 379 74 298 379 77 298 minecraft:red_terracotta
setblock 380 74 276 minecraft:stripped_oak_log
fill 380 74 277 380 76 278 minecraft:red_terracotta
setblock 380 74 315 minecraft:red_terracotta
setblock 380 74 316 minecraft:stripped_oak_log
fill 381 74 276 381 77 276 minecraft:red_terracotta
fill 381 74 278 382 74 278 minecraft:red_terracotta
setblock 381 74 315 minecraft:stripped_oak_log
fill 381 74 316 381 77 316 minecraft:red_terracotta
fill 382 74 302 382 75 302 minecraft:brown_terracotta
fill 382 74 306 382 75 306 minecraft:brown_terracotta
fill 382 74 315 382 77 315 minecraft:red_terracotta
setblock 383 74 278 minecraft:stripped_oak_log
fill 383 74 301 383 75 301 minecraft:brown_terracotta
fill 383 74 307 383 75 307 minecraft:brown_terracotta
setblock 384 74 277 minecraft:stripped_oak_log
fill 384 74 278 384 77 278 minecraft:red_terracotta
setblock 385 74 276 minecraft:stripped_oak_log
fill 385 74 277 385 77 277 minecraft:red_terracotta
fill 385 74 308 385 75 308 minecraft:brown_terracotta
setblock 385 74 316 minecraft:stripped_oak_log
fill 386 74 276 389 74 276 minecraft:red_terracotta
fill 386 74 301 387 75 301 minecraft:brown_terracotta
setblock 386 74 315 minecraft:stripped_oak_log
fill 386 74 316 389 74 316 minecraft:red_terracotta
fill 387 74 307 387 75 307 minecraft:brown_terracotta
fill 387 74 315 387 77 315 minecraft:red_terracotta
setblock 388 74 278 minecraft:stripped_oak_log
fill 388 74 302 388 75 302 minecraft:brown_terracotta
fill 388 74 306 388 75 306 minecraft:brown_terracotta
setblock 389 74 277 minecraft:stripped_oak_log
setblock 390 74 276 minecraft:stripped_oak_log
fill 390 74 277 390 77 277 minecraft:red_terracotta
setblock 390 74 315 minecraft:red_terracotta
setblock 390 74 316 minecraft:stripped_oak_log
fill 391 74 276 394 74 276 minecraft:red_terracotta
fill 391 74 316 394 74 316 minecraft:red_terracotta
setblock 393 74 277 minecraft:red_terracotta
setblock 394 74 277 minecraft:stripped_oak_log
fill 394 74 315 394 75 315 minecraft:red_terracotta
setblock 395 74 276 minecraft:stripped_oak_log
fill 395 74 277 396 76 277 minecraft:red_terracotta
setblock 395 74 316 minecraft:stripped_oak_log
fill 396 74 276 396 77 276 minecraft:red_terracotta
setblock 396 74 315 minecraft:stripped_oak_log
fill 396 74 316 396 77 316 minecraft:red_terracotta
fill 397 74 315 397 77 315 minecraft:red_terracotta
setblock 398 74 277 minecraft:red_terracotta
fill 398 74 314 398 77 314 minecraft:red_terracotta
setblock 399 74 277 minecraft:stripped_oak_log
setblock 400 74 276 minecraft:stripped_oak_log
fill 400 74 277 400 77 277 minecraft:red_terracotta
setblock 400 74 316 minecraft:stripped_oak_log
fill 401 74 276 401 77 276 minecraft:red_terracotta
setblock 401 74 315 minecraft:stripped_oak_log
fill 401 74 316 401 77 316 minecraft:red_terracotta
setblock 402 74 278 minecraft:red_terracotta
setblock 402 74 313 minecraft:red_terracotta
setblock 402 74 314 minecraft:stripped_oak_log
fill 402 74 315 402 77 315 minecraft:red_terracotta
setblock 403 74 313 minecraft:stripped_oak_log
fill 403 74 314 403 77 314 minecraft:red_terracotta
setblock 404 74 277 minecraft:stripped_oak_log
fill 404 74 313 404 75 313 minecraft:red_terracotta
setblock 405 74 276 minecraft:stripped_oak_log
fill 405 74 277 405 77 277 minecraft:red_terracotta
setblock 405 74 316 minecraft:stripped_oak_log
fill 406 74 276 406 77 276 minecraft:red_terracotta
setblock 406 74 315 minecraft:stripped_oak_log
fill 406 74 316 406 77 316 minecraft:red_terracotta
setblock 407 74 314 minecraft:stripped_oak_log
fill 407 74 315 407 77 315 minecraft:red_terracotta
setblock 408 74 314 minecraft:red_terracotta
setblock 410 74 276 minecraft:stripped_oak_log
setblock 410 74 316 minecraft:stripped_oak_log
fill 411 74 316 411 77 316 minecraft:red_terracotta
setblock 415 74 316 minecraft:stripped_oak_log
fill 416 74 293 416 74 294 minecraft:red_terracotta
setblock 416 74 295 minecraft:stripped_oak_log
fill 416 74 296 416 77 296 minecraft:red_terracotta
setblock 416 74 300 minecraft:stripped_oak_log
fill 416 74 316 416 77 316 minecraft:red_terracotta
setblock 417 74 289 minecraft:stripped_oak_log
fill 417 74 290 417 77 290 minecraft:red_terracotta
setblock 417 74 294 minecraft:stripped_oak_log
fill 417 74 295 417 77 295 minecraft:red_terracotta
setblock 417 74 298 minecraft:red_terracotta
setblock 417 74 299 minecraft:stripped_oak_log
fill 417 74 300 417 77 300 minecraft:red_terracotta
setblock 417 74 303 minecraft:red_terracotta
setblock 417 74 304 minecraft:stripped_oak_log
setblock 417 74 314 minecraft:stripped_oak_log
fill 417 74 315 417 77 315 minecraft:red_terracotta
setblock 377 75 278 minecraft:stripped_oak_log
fill 377 75 279 379 76 279 minecraft:red_terracotta
setblock 377 75 283 minecraft:stripped_oak_log
fill 377 75 284 377 75 287 minecraft:red_terracotta
setblock 377 75 288 minecraft:stripped_oak_log
fill 377 75 289 377 78 289 minecraft:red_terracotta
setblock 377 75 293 minecraft:stripped_oak_log
fill 377 75 294 377 78 294 minecraft:red_terracotta
setblock 377 75 297 minecraft:red_terracotta
setblock 377 75 298 minecraft:stripped_oak_log
fill 377 75 299 377 78 299 minecraft:red_terracotta
setblock 377 75 303 minecraft:stripped_oak_log
fill 377 75 314 377 78 314 minecraft:red_terracotta
setblock 378 75 276 minecraft:red_terracotta
setblock 378 75 277 minecraft:stripped_oak_log
fill 378 75 278 379 77 278 minecraft:red_terracotta
fill 378 75 280 378 75 281 minecraft:red_terracotta
setblock 378 75 282 minecraft:stripped_oak_log
fill 378 75 283 378 78 283 minecraft:red_terracotta
setblock 378 75 287 minecraft:stripped_oak_log
fill 378 75 288 378 78 288 minecraft:red_terracotta
setblock 378 75 292 minecraft:stripped_oak_log
fill 378 75 293 378 78 293 minecraft:red_terracotta
setblock 378 75 297 minecraft:stripped_oak_log
fill 378 75 298 378 78 298 minecraft:red_terracotta
setblock 378 75 301 minecraft:red_terracotta
setblock 378 75 316 minecraft:red_terracotta
setblock 379 75 276 minecraft:stripped_oak_log
fill 379 75 277 379 78 277 minecraft:red_terracotta
setblock 379 75 290 minecraft:red_terracotta
setblock 379 75 291 minecraft:stripped_oak_log
fill 379 75 292 379 78 292 minecraft:red_terracotta
setblock 379 75 296 minecraft:stripped_oak_log
fill 379 75 297 379 78 297 minecraft:red_terracotta
fill 379 75 299 379 76 299 minecraft:red_terracotta
setblock 379 75 315 minecraft:red_terracotta
setblock 379 75 316 minecraft:stripped_oak_log
fill 380 75 276 380 78 276 minecraft:red_terracotta
setblock 380 75 294 minecraft:red_terracotta
setblock 380 75 295 minecraft:stripped_oak_log
fill 380 75 296 380 78 296 minecraft:red_terracotta
setblock 380 75 315 minecraft:stripped_oak_log
fill 380 75 316 380 78 316 minecraft:red_terracotta
setblock 381 75 278 minecraft:red_terracotta
fill 381 75 303 381 75 305 minecraft:brown_terracotta
fill 381 75 315 381 78 315 minecraft:red_terracotta
setblock 382 75 278 minecraft:stripped_oak_log
fill 382 75 279 385 75 279 minecraft:red_terracotta
setblock 382 75 307 minecraft:brown_terracotta
setblock 383 75 277 minecraft:stripped_oak_log
fill 383 75 278 383 78 278 minecraft:red_terracotta
fill 383 75 308 384 75 308 minecraft:brown_terracotta
setblock 384 75 276 minecraft:stripped_oak_log
fill 384 75 277 384 78 277 minecraft:red_terracotta
setblock 384 75 316 minecraft:stripped_oak_log
fill 385 75 276 388 75 276 minecraft:red_terracotta
fill 385 75 278 386 75 278 minecraft:red_terracotta
setblock 385 75 300 minecraft:brown_terracotta
setblock 385 75 315 minecraft:stripped_oak_log
fill 385 75 316 388 75 316 minecraft:red_terracotta
setblock 386 75 308 minecraft:brown_terracotta
fill 386 75 315 386 78 315 minecraft:red_terracotta
setblock 387 75 278 minecraft:stripped_oak_log
setblock 388 75 277 minecraft:stripped_oak_log
fill 388 75 278 389 77 278 minecraft:red_terracotta
setblock 388 75 307 minecraft:brown_terracotta
setblock 389 75 276 minecraft:stripped_oak_log
fill 389 75 277 389 78 277 minecraft:red_terracotta
fill 389 75 303 389 75 305 minecraft:brown_terracotta
setblock 389 75 316 minecraft:stripped_oak_log
fill 390 75 276 393 75 276 minecraft:red_terracotta
setblock 390 75 315 minecraft:stripped_oak_log
fill 390 75 316 393 75 316 minecraft:red_terracotta
setblock 393 75 277 minecraft:stripped_oak_log
fill 393 75 315 393 76 315 minecraft:red_terracotta
setblock 394 75 276 minecraft:stripped_oak_log
fill 394 75 277 394 78 277 minecraft:red_terracotta
setblock 394 75 316 minecraft:stripped_oak_log
fill 395 75 276 395 78 276 minecraft:red_terracotta
setblock 395 75 315 minecraft:stripped_oak_log
fill 395 75 316 395 78 316 minecraft:red_terracotta
fill 396 75 315 396 78 315 minecraft:red_terracotta
setblock 398 75 277 minecraft:stripped_oak_log
fill 398 75 278 401 75 278 minecraft:red_terracotta
setblock 399 75 276 minecraft:stripped_oak_log
fill 399 75 277 399 78 277 minecraft:red_terracotta
setblock 399 75 316 minecraft:stripped_oak_log
fill 400 75 276 400 78 276 minecraft:red_terracotta
setblock 400 75 315 minecraft:stripped_oak_log
fill 400 75 316 400 78 316 minecraft:red_terracotta
setblock 401 75 314 minecraft:stripped_oak_log
fill 401 75 315 401 78 315 minecraft:red_terracotta
setblock 402 75 278 minecraft:stripped_oak_log
setblock 402 75 313 minecraft:stripped_oak_log
fill 402 75 314 402 78 314 minecraft:red_terracotta
setblock 403 75 277 minecraft:stripped_oak_log
fill 403 75 278 404 77 278 minecraft:red_terracotta
fill 403 75 313 403 76 313 minecraft:red_terracotta
setblock 404 75 276 minecraft:stripped_oak_log
fill 404 75 277 404 78 277 minecraft:red_terracotta
setblock 404 75 316 minecraft:stripped_oak_log
fill 405 75 276 405 78 276 minecraft:red_terracotta
setblock 405 75 315 minecraft:stripped_oak_log
fill 405 75 316 405 78 316 minecraft:red_terracotta
setblock 406 75 314 minecraft:stripped_oak_log
fill 406 75 315 406 78 315 minecraft:red_terracotta
fill 407 75 314 407 76 314 minecraft:red_terracotta
setblock 409 75 276 minecraft:stripped_oak_log
setblock 409 75 316 minecraft:stripped_oak_log
fill 410 75 276 410 78 276 minecraft:red_terracotta
fill 410 75 293 410 80 294 minecraft:brown_terracotta
setblock 410 75 315 minecraft:stripped_oak_log
fill 410 75 316 410 78 316 minecraft:red_terracotta
fill 411 75 294 411 80 294 minecraft:brown_terracotta
setblock 414 75 316 minecraft:stripped_oak_log
fill 415 75 297 416 75 298 minecraft:red_terracotta
fill 415 75 316 415 78 316 minecraft:red_terracotta
fill 416 75 276 417 76 276 minecraft:red_terracotta
fill 416 75 292 416 75 293 minecraft:red_terracotta
setblock 416 75 294 minecraft:stripped_oak_log
fill 416 75 295 416 78 295 minecraft:red_terracotta
setblock 416 75 299 minecraft:stripped_oak_log
fill 416 75 300 416 76 302 minecraft:red_terracotta
setblock 417 75 277 minecraft:red_terracotta
setblock 417 75 278 minecraft:stripped_oak_log
fill 417 75 279 417 78 279 minecraft:red_terracotta
fill 417 75 289 417 78 289 minecraft:red_terracotta
setblock 417 75 293 minecraft:stripped_oak_log
fill 417 75 294 417 78 294 minecraft:red_terracotta
setblock 417 75 298 minecraft:stripped_oak_log
fill 417 75 299 417 78 299 minecraft:red_terracotta
setblock 417 75 303 minecraft:stripped_oak_log
fill 417 75 304 417 76 306 minecraft:red_terracotta
setblock 417 75 312 minecraft:red_terracotta
setblock 417 75 313 minecraft:stripped_oak_log
fill 417 75 314 417 78 314 minecraft:red_terracotta
fill 376 76 275 376 79 317 minecraft:brown_terracotta
fill 377 76 275 418 79 275 minecraft:brown_terracotta
setblock 377 76 276 minecraft:red_terracotta
setblock 377 76 277 minecraft:stripped_oak_log
fill 377 76 278 377 79 278 minecraft:red_terracotta
fill 377 76 280 377 76 281 minecraft:red_terracotta
setblock 377 76 282 minecraft:stripped_oak_log
fill 377 76 283 377 76 286 minecraft:red_terracotta
setblock 377 76 287 minecraft:stripped_oak_log
fill 377 76 288 377 79 288 minecraft:red_terracotta
setblock 377 76 292 minecraft:stripped_oak_log
fill 377 76 293 377 79 293 minecraft:red_terracotta
setblock 377 76 297 minecraft:stripped_oak_log
fill 377 76 298 377 79 298 minecraft:red_terracotta
setblock 377 76 302 minecraft:stripped_oak_log
fill 377 76 303 377 78 304 minecraft:red_terracotta
fill 377 76 317 418 79 317 minecraft:brown_terracotta
setblock 378 76 276 minecraft:stripped_oak_log
fill 378 76 277 378 79 277 minecraft:red_terracotta
setblock 378 76 280 minecraft:red_terracotta
setblock 378 76 281 minecraft:stripped_oak_log
fill 378 76 282 379 78 282 minecraft:red_terracotta
fill 378 76 284 378 76 285 minecraft:red_terracotta
setblock 378 76 286 minecraft:stripped_oak_log
fill 378 76 287 378 79 287 minecraft:red_terracotta
setblock 378 76 291 minecraft:stripped_oak_log
fill 378 76 292 378 79 292 minecraft:red_terracotta
setblock 378 76 296 minecraft:stripped_oak_log
fill 378 76 297 378 79 297 minecraft:red_terracotta
setblock 378 76 301 minecraft:stripped_oak_log
fill 378 76 302 378 79 302 minecraft:red_terracotta
setblock 378 76 316 minecraft:stripped_oak_log
fill 379 76 276 379 79 276 minecraft:red_terracotta
setblock 379 76 280 minecraft:stripped_oak_log
fill 379 76 281 379 79 281 minecraft:red_terracotta
fill 379 76 283 379 77 283 minecraft:red_terracotta
setblock 379 76 290 minecraft:stripped_oak_log
fill 379 76 291 379 79 291 minecraft:red_terracotta
setblock 379 76 295 minecraft:stripped_oak_log
fill 379 76 296 379 79 296 minecraft:red_terracotta
setblock 379 76 300 minecraft:stripped_oak_log
setblock 379 76 315 minecraft:stripped_oak_log
fill 379 76 316 379 79 316 minecraft:red_terracotta
setblock 380 76 279 minecraft:stripped_oak_log
setblock 380 76 293 minecraft:red_terracotta
setblock 380 76 294 minecraft:stripped_oak_log
fill 380 76 295 380 78 295 minecraft:red_terracotta
fill 380 76 297 380 76 298 minecraft:red_terracotta
fill 380 76 315 380 79 315 minecraft:red_terracotta
setblock 381 76 278 minecraft:stripped_oak_log
fill 381 76 279 384 76 279 minecraft:red_terracotta
setblock 382 76 277 minecraft:stripped_oak_log
fill 382 76 278 382 79 278 minecraft:red_terracotta
setblock 383 76 276 minecraft:stripped_oak_log
fill 383 76 277 383 79 277 minecraft:red_terracotta
setblock 383 76 316 minecraft:stripped_oak_log
fill 384 76 276 387 76 276 minecraft:red_terracotta
fill 384 76 305 384 80 305 minecraft:stripped_oak_log
setblock 384 76 315 minecraft:stripped_oak_log
fill 384 76 316 387 76 316 minecraft:red_terracotta
setblock 385 76 278 minecraft:red_terracotta
setblock 385 76 279 minecraft:stripped_oak_log
fill 385 76 303 385 80 303 minecraft:stripped_oak_log
fill 385 76 315 385 78 315 minecraft:red_terracotta
setblock 386 76 278 minecraft:stripped_oak_log
fill 386 76 279 386 78 279 minecraft:red_terracotta
fill 386 76 305 386 79 305 minecraft:stripped_oak_log
setblock 387 76 277 minecraft:stripped_oak_log
fill 387 76 278 387 79 278 minecraft:red_terracotta
setblock 388 76 276 minecraft:stripped_oak_log
fill 388 76 277 388 79 277 minecraft:red_terracotta
setblock 388 76 316 minecraft:stripped_oak_log
fill 389 76 276 392 76 276 minecraft:red_terracotta
setblock 389 76 315 minecraft:stripped_oak_log
fill 389 76 316 392 76 316 minecraft:red_terracotta
setblock 390 76 278 minecraft:red_terracotta
setblock 391 76 277 minecraft:red_terracotta
setblock 392 76 277 minecraft:stripped_oak_log
fill 392 76 315 392 77 315 minecraft:red_terracotta
setblock 393 76 276 minecraft:stripped_oak_log
fill 393 76 277 393 79 277 minecraft:red_terracotta
setblock 393 76 316 minecraft:stripped_oak_log
fill 394 76 276 394 79 276 minecraft:red_terracotta
setblock 394 76 315 minecraft:stripped_oak_log
fill 394 76 316 394 79 316 minecraft:red_terracotta
fill 395 76 315 395 79 315 minecraft:red_terracotta
setblock 396 76 278 minecraft:stripped_oak_log
setblock 397 76 276 minecraft:red_terracotta
setblock 397 76 277 minecraft:stripped_oak_log
fill 397 76 278 400 76 278 minecraft:red_terracotta
fill 397 76 314 397 78 314 minecraft:red_terracotta
setblock 398 76 276 minecraft:stripped_oak_log
fill 398 76 277 398 79 277 minecraft:red_terracotta
setblock 398 76 316 minecraft:stripped_oak_log
fill 399 76 276 399 79 276 minecraft:red_terracotta
setblock 399 76 315 minecraft:stripped_oak_log
fill 399 76 316 399 79 316 minecraft:red_terracotta
setblock 400 76 314 minecraft:stripped_oak_log
fill 400 76 315 400 79 315 minecraft:red_terracotta
setblock 401 76 278 minecraft:stripped_oak_log
setblock 401 76 313 minecraft:stripped_oak_log
fill 401 76 314 401 79 314 minecraft:red_terracotta
setblock 402 76 277 minecraft:stripped_oak_log
fill 402 76 278 402 79 278 minecraft:red_terracotta
setblock 402 76 313 minecraft:red_terracotta
setblock 403 76 276 minecraft:stripped_oak_log
fill 403 76 277 403 79 277 minecraft:red_terracotta
setblock 403 76 316 minecraft:stripped_oak_log
fill 404 76 276 404 79 276 minecraft:red_terracotta
setblock 404 76 315 minecraft:stripped_oak_log
fill 404 76 316 404 79 316 minecraft:red_terracotta
setblock 405 76 314 minecraft:stripped_oak_log
fill 405 76 315 405 79 315 minecraft:red_terracotta
setblock 406 76 277 minecraft:red_terracotta
fill 406 76 314 406 77 314 minecraft:red_terracotta
setblock 407 76 277 minecraft:stripped_oak_log
setblock 408 76 276 minecraft:stripped_oak_log
setblock 408 76 316 minecraft:stripped_oak_log
fill 409 76 276 409 79 276 minecraft:red_terracotta
setblock 409 76 315 minecraft:stripped_oak_log
fill 409 76 316 409 79 316 minecraft:red_terracotta
fill 410 76 292 411 80 292 minecraft:brown_terracotta
fill 411 76 276 411 77 276 minecraft:red_terracotta
fill 412 76 293 412 80 293 minecraft:brown_terracotta
setblock 413 76 316 minecraft:stripped_oak_log
fill 414 76 276 415 78 276 minecraft:red_terracotta
fill 414 76 316 414 78 316 minecraft:red_terracotta
fill 415 76 295 415 76 298 minecraft:red_terracotta
setblock 415 76 299 minecraft:stripped_oak_log
fill 415 76 300 415 79 300 minecraft:red_terracotta
setblock 416 76 292 minecraft:red_terracotta
setblock 416 76 293 minecraft:stripped_oak_log
fill 416 76 294 416 79 294 minecraft:red_terracotta
setblock 416 76 297 minecraft:red_terracotta
setblock 416 76 298 minecraft:stripped_oak_log
fill 416 76 299 416 79 299 minecraft:red_terracotta
setblock 416 76 303 minecraft:stripped_oak_log
setblock 417 76 277 minecraft:stripped_oak_log
fill 417 76 278 417 79 278 minecraft:red_terracotta
fill 417 76 280 417 76 281 minecraft:red_terracotta
setblock 417 76 282 minecraft:stripped_oak_log
setblock 417 76 287 minecraft:stripped_oak_log
fill 417 76 288 417 79 288 minecraft:red_terracotta
setblock 417 76 292 minecraft:stripped_oak_log
fill 417 76 293 417 79 293 minecraft:red_terracotta
setblock 417 76 297 minecraft:stripped_oak_log
fill 417 76 298 417 79 298 minecraft:red_terracotta
setblock 417 76 301 minecraft:red_terracotta
setblock 417 76 302 minecraft:stripped_oak_log
fill 417 76 303 417 79 303 minecraft:red_terracotta
setblock 417 76 307 minecraft:stripped_oak_log
fill 417 76 308 417 79 308 minecraft:red_terracotta
setblock 417 76 312 minecraft:stripped_oak_log
fill 417 76 313 417 78 313 minecraft:red_terracotta
fill 418 76 276 418 79 316 minecraft:brown_terracotta
setblock 377 77 276 minecraft:stripped_oak_log
fill 377 77 277 377 80 277 minecraft:red_terracotta
fill 377 77 279 377 77 280 minecraft:red_terracotta
setblock 377 77 281 minecraft:stripped_oak_log
fill 377 77 282 377 77 285 minecraft:red_terracotta
setblock 377 77 286 minecraft:stripped_oak_log
fill 377 77 287 377 80 287 minecraft:red_terracotta
setblock 377 77 291 minecraft:stripped_oak_log
fill 377 77 292 377 80 292 minecraft:red_terracotta
setblock 377 77 296 minecraft:stripped_oak_log
fill 377 77 297 377 80 297 minecraft:red_terracotta
setblock 377 77 300 minecraft:red_terracotta
setblock 377 77 301 minecraft:stripped_oak_log
fill 377 77 302 377 80 302 minecraft:red_terracotta
setblock 377 77 305 minecraft:red_terracotta
setblock 377 77 315 minecraft:red_terracotta
setblock 377 77 316 minecraft:stripped_oak_log
fill 378 77 276 378 80 276 minecraft:red_terracotta
setblock 378 77 279 minecraft:red_terracotta
setblock 378 77 280 minecraft:stripped_oak_log
fill 378 77 281 378 80 281 minecraft:red_terracotta
setblock 378 77 284 minecraft:red_terracotta
setblock 378 77 285 minecraft:stripped_oak_log
fill 378 77 286 378 80 286 minecraft:red_terracotta
setblock 378 77 290 minecraft:stripped_oak_log
fill 378 77 291 378 80 291 minecraft:red_terracotta
setblock 378 77 295 minecraft:stripped_oak_log
fill 378 77 296 378 80 296 minecraft:red_terracotta
setblock 378 77 300 minecraft:stripped_oak_log
fill 378 77 301 379 79 301 minecraft:red_terracotta
fill 378 77 303 378 78 303 minecraft:red_terracotta
fill 378 77 316 378 80 316 minecraft:red_terracotta
setblock 379 77 279 minecraft:stripped_oak_log
fill 379 77 280 380 79 280 minecraft:red_terracotta
setblock 379 77 284 minecraft:stripped_oak_log
fill 379 77 285 379 80 285 minecraft:red_terracotta
setblock 379 77 289 minecraft:stripped_oak_log
fill 379 77 290 379 78 290 minecraft:red_terracotta
setblock 379 77 294 minecraft:stripped_oak_log
fill 379 77 295 379 80 295 minecraft:red_terracotta
setblock 379 77 299 minecraft:stripped_oak_log
fill 379 77 300 379 80 300 minecraft:red_terracotta
setblock 379 77 306 minecraft:light[level=12]
setblock 379 77 313 minecraft:light[level=12]
fill 379 77 315 379 79 315 minecraft:red_terracotta
setblock 380 77 277 minecraft:red_terracotta
setblock 380 77 278 minecraft:stripped_oak_log
fill 380 77 279 383 77 279 minecraft:red_terracotta
fill 380 77 281 380 77 282 minecraft:red_terracotta
setblock 380 77 294 minecraft:red_terracotta
setblock 380 77 297 minecraft:red_terracotta
setblock 380 77 298 minecraft:stripped_oak_log
setblock 381 77 277 minecraft:stripped_oak_log
fill 381 77 278 381 80 278 minecraft:red_terracotta
setblock 382 77 276 minecraft:stripped_oak_log
fill 382 77 277 382 80 277 minecraft:red_terracotta
setblock 382 77 316 minecraft:stripped_oak_log
fill 383 77 276 386 77 276 minecraft:red_terracotta
setblock 383 77 315 minecraft:stripped_oak_log
fill 383 77 316 386 77 316 minecraft:red_terracotta
setblock 384 77 279 minecraft:stripped_oak_log
fill 384 77 315 384 79 315 minecraft:red_terracotta
setblock 385 77 278 minecraft:stripped_oak_log
fill 385 77 279 385 80 279 minecraft:red_terracotta
setblock 386 77 277 minecraft:stripped_oak_log
fill 386 77 278 386 80 278 minecraft:red_terracotta
setblock 386 77 285 minecraft:light[level=12]
setblock 386 77 292 minecraft:light[level=12]
setblock 386 77 299 minecraft:light[level=12]
setblock 386 77 306 minecraft:light[level=12]
setblock 386 77 313 minecraft:light[level=12]
setblock 387 77 276 minecraft:stripped_oak_log
fill 387 77 277 387 80 277 minecraft:red_terracotta
setblock 387 77 316 minecraft:stripped_oak_log
fill 388 77 276 391 77 276 minecraft:red_terracotta
setblock 388 77 315 minecraft:stripped_oak_log
fill 388 77 316 391 77 316 minecraft:red_terracotta
setblock 390 77 278 minecraft:stripped_oak_log
setblock 391 77 277 minecraft:stripped_oak_log
setblock 392 77 276 minecraft:stripped_oak_log
fill 392 77 277 392 80 277 minecraft:red_terracotta
setblock 392 77 316 minecraft:stripped_oak_log
fill 393 77 276 393 80 276 minecraft:red_terracotta
setblock 393 77 278 minecraft:light[level=12]
setblock 393 77 285 minecraft:light[level=12]
setblock 393 77 292 minecraft:light[level=12]
setblock 393 77 299 minecraft:light[level=12]
setblock 393 77 306 minecraft:light[level=12]
setblock 393 77 313 minecraft:light[level=12]
setblock 393 77 315 minecraft:stripped_oak_log
fill 393 77 316 393 80 316 minecraft:red_terracotta
setblock 394 77 278 minecraft:red_terracotta
fill 394 77 315 394 80 315 minecraft:red_terracotta
setblock 395 77 277 minecraft:red_terracotta
setblock 395 77 278 minecraft:stripped_oak_log
setblock 396 77 277 minecraft:stripped_oak_log
fill 396 77 278 399 77 278 minecraft:red_terracotta
setblock 397 77 276 minecraft:stripped_oak_log
fill 397 77 277 397 80 277 minecraft:red_terracotta
setblock 397 77 316 minecraft:stripped_oak_log
fill 398 77 276 398 80 276 minecraft:red_terracotta
setblock 398 77 315 minecraft:stripped_oak_log
fill 398 77 316 398 80 316 minecraft:red_terracotta
setblock 399 77 314 minecraft:stripped_oak_log
fill 399 77 315 399 80 315 minecraft:red_terracotta
setblock 400 77 278 minecraft:stripped_oak_log
setblock 400 77 285 minecraft:light[level=12]
setblock 400 77 292 minecraft:light[level=12]
setblock 400 77 299 minecraft:light[level=12]
setblock 400 77 306 minecraft:light[level=12]
setblock 400 77 313 minecraft:light[level=12]
fill 400 77 314 400 80 314 minecraft:red_terracotta
setblock 401 77 277 minecraft:stripped_oak_log
fill 401 77 278 401 80 278 minecraft:red_terracotta
setblock 402 77 276 minecraft:stripped_oak_log
fill 402 77 277 402 80 277 minecraft:red_terracotta
setblock 402 77 316 minecraft:stripped_oak_log
fill 403 77 276 403 80 276 minecraft:red_terracotta
setblock 403 77 315 minecraft:stripped_oak_log
fill 403 77 316 403 80 316 minecraft:red_terracotta
setblock 404 77 314 minecraft:stripped_oak_log
fill 404 77 315 404 80 315 minecraft:red_terracotta
fill 405 77 314 405 78 314 minecraft:red_terracotta
setblock 406 77 277 minecraft:stripped_oak_log
setblock 407 77 276 minecraft:stripped_oak_log
fill 407 77 277 407 78 277 minecraft:red_terracotta
setblock 407 77 278 minecraft:light[level=12]
setblock 407 77 285 minecraft:light[level=12]
setblock 407 77 292 minecraft:light[level=12]
setblock 407 77 299 minecraft:light[level=12]
setblock 407 77 306 minecraft:light[level=12]
setblock 407 77 313 minecraft:light[level=12]
setblock 407 77 316 minecraft:stripped_oak_log
fill 408 77 276 408 79 276 minecraft:red_terracotta
setblock 408 77 315 minecraft:stripped_oak_log
fill 408 77 316 408 79 316 minecraft:red_terracotta
fill 409 77 293 409 80 294 minecraft:brown_terracotta
fill 410 77 295 411 80 295 minecraft:brown_terracotta
setblock 412 77 276 minecraft:stripped_oak_log
fill 412 77 294 412 80 294 minecraft:brown_terracotta
setblock 412 77 316 minecraft:stripped_oak_log
fill 413 77 276 413 79 276 minecraft:red_terracotta
fill 413 77 316 413 78 316 minecraft:red_terracotta
setblock 414 77 278 minecraft:light[level=12]
setblock 414 77 285 minecraft:light[level=12]
setblock 414 77 292 minecraft:light[level=12]
setblock 414 77 299 minecraft:light[level=12]
setblock 414 77 306 minecraft:light[level=12]
setblock 414 77 313 minecraft:light[level=12]
fill 415 77 295 415 77 297 minecraft:red_terracotta
setblock 415 77 298 minecraft:stripped_oak_log
fill 415 77 299 415 80 299 minecraft:red_terracotta
fill 415 77 301 416 77 301 minecraft:red_terracotta
setblock 416 77 276 minecraft:red_terracotta
setblock 416 77 291 minecraft:red_terracotta
setblock 416 77 292 minecraft:stripped_oak_log
fill 416 77 293 416 80 293 minecraft:red_terracotta
setblock 416 77 297 minecraft:stripped_oak_log
fill 416 77 298 416 80 298 minecraft:red_terracotta
fill 416 77 300 416 78 300 minecraft:red_terracotta
setblock 416 77 302 minecraft:stripped_oak_log
fill 416 77 303 416 79 304 minecraft:red_terracotta
setblock 417 77 276 minecraft:stripped_oak_log
fill 417 77 277 417 80 277 minecraft:red_terracotta
setblock 417 77 280 minecraft:red_terracotta
setblock 417 77 281 minecraft:stripped_oak_log
fill 417 77 282 417 77 285 minecraft:red_terracotta
setblock 417 77 286 minecraft:stripped_oak_log
fill 417 77 287 417 80 287 minecraft:red_terracotta
setblock 417 77 291 minecraft:stripped_oak_log
fill 417 77 292 417 80 292 minecraft:red_terracotta
setblock 417 77 296 minecraft:stripped_oak_log
fill 417 77 297 417 80 297 minecraft:red_terracotta
setblock 417 77 301 minecraft:stripped_oak_log
fill 417 77 302 417 80 302 minecraft:red_terracotta
fill 417 77 304 417 77 305 minecraft:red_terracotta
setblock 417 77 306 minecraft:stripped_oak_log
fill 417 77 307 417 80 307 minecraft:red_terracotta
fill 417 77 309 417 78 309 minecraft:red_terracotta
setblock 417 77 311 minecraft:stripped_oak_log
fill 417 77 312 417 78 312 minecraft:red_terracotta
setblock 417 77 316 minecraft:stripped_oak_log
fill 377 78 276 377 81 276 minecraft:red_terracotta
setblock 377 78 279 minecraft:red_terracotta
setblock 377 78 280 minecraft:stripped_oak_log
fill 377 78 281 377 78 284 minecraft:red_terracotta
setblock 377 78 285 minecraft:stripped_oak_log
fill 377 78 286 377 81 286 minecraft:red_terracotta
setblock 377 78 290 minecraft:stripped_oak_log
fill 377 78 291 377 81 291 minecraft:red_terracotta
setblock 377 78 295 minecraft:stripped_oak_log
fill 377 78 296 377 81 296 minecraft:red_terracotta
setblock 377 78 300 minecraft:stripped_oak_log
fill 377 78 301 377 81 301 minecraft:red_terracotta
setblock 377 78 305 minecraft:stripped_oak_log
fill 377 78 306 377 81 306 minecraft:red_terracotta
setblock 377 78 315 minecraft:stripped_oak_log
fill 377 78 316 377 81 316 minecraft:red_terracotta
setblock 378 78 278 minecraft:red_terracotta
setblock 378 78 279 minecraft:stripped_oak_log
fill 378 78 280 378 81 280 minecraft:red_terracotta
setblock 378 78 284 minecraft:stripped_oak_log
fill 378 78 285 378 81 285 minecraft:red_terracotta
setblock 378 78 289 minecraft:stripped_oak_log
fill 378 78 290 378 81 290 minecraft:red_terracotta
setblock 378 78 294 minecraft:stripped_oak_log
fill 378 78 295 378 81 295 minecraft:red_terracotta
setblock 378 78 299 minecraft:stripped_oak_log
fill 378 78 300 378 81 300 minecraft:red_terracotta
setblock 378 78 304 minecraft:stripped_oak_log
setblock 379 78 278 minecraft:stripped_oak_log
fill 379 78 279 382 78 279 minecraft:red_terracotta
setblock 379 78 283 minecraft:stripped_oak_log
fill 379 78 284 379 81 284 minecraft:red_terracotta
fill 379 78 286 379 78 287 minecraft:red_terracotta
setblock 379 78 288 minecraft:stripped_oak_log
setblock 379 78 289 minecraft:red_terracotta
setblock 379 78 293 minecraft:stripped_oak_log
fill 379 78 294 379 80 294 minecraft:red_terracotta
setblock 379 78 298 minecraft:stripped_oak_log
fill 379 78 299 379 81 299 minecraft:red_terracotta
setblock 379 78 302 minecraft:red_terracotta
setblock 380 78 277 minecraft:stripped_oak_log
fill 380 78 278 380 81 278 minecraft:red_terracotta
setblock 380 78 281 minecraft:red_terracotta
setblock 380 78 282 minecraft:stripped_oak_log
fill 380 78 283 380 81 283 minecraft:red_terracotta
setblock 380 78 297 minecraft:stripped_oak_log
setblock 380 78 298 minecraft:red_terracotta
setblock 381 78 276 minecraft:stripped_oak_log
fill 381 78 277 381 81 277 minecraft:red_terracotta
setblock 381 78 316 minecraft:stripped_oak_log
fill 382 78 276 385 78 276 minecraft:red_terracotta
setblock 382 78 315 minecraft:stripped_oak_log
fill 382 78 316 385 78 316 minecraft:red_terracotta
setblock 383 78 279 minecraft:stripped_oak_log
fill 383 78 315 383 79 315 minecraft:red_terracotta
setblock 384 78 278 minecraft:stripped_oak_log
fill 384 78 279 384 80 279 minecraft:red_terracotta
setblock 385 78 277 minecraft:stripped_oak_log
fill 385 78 278 385 81 278 minecraft:red_terracotta
setblock 386 78 276 minecraft:stripped_oak_log
fill 386 78 277 386 81 277 minecraft:red_terracotta
setblock 386 78 316 minecraft:stripped_oak_log
fill 387 78 276 390 78 276 minecraft:red_terracotta
fill 387 78 316 390 78 316 minecraft:red_terracotta
setblock 388 78 278 minecraft:red_terracotta
setblock 389 78 278 minecraft:stripped_oak_log
setblock 390 78 277 minecraft:stripped_oak_log
fill 390 78 278 393 78 278 minecraft:red_terracotta
setblock 391 78 276 minecraft:stripped_oak_log
fill 391 78 277 391 81 277 minecraft:red_terracotta
setblock 391 78 316 minecraft:stripped_oak_log
fill 392 78 276 392 81 276 minecraft:red_terracotta
fill 392 78 316 392 81 316 minecraft:red_terracotta
fill 393 78 315 393 79 315 minecraft:red_terracotta
setblock 394 78 278 minecraft:stripped_oak_log
setblock 395 78 277 minecraft:stripped_oak_log
fill 395 78 278 398 78 278 minecraft:red_terracotta
setblock 396 78 276 minecraft:stripped_oak_log
fill 396 78 277 396 81 277 minecraft:red_terracotta
setblock 396 78 316 minecraft:stripped_oak_log
fill 397 78 276 397 81 276 minecraft:red_terracotta
setblock 397 78 315 minecraft:stripped_oak_log
fill 397 78 316 397 81 316 minecraft:red_terracotta
setblock 398 78 314 minecraft:stripped_oak_log
fill 398 78 315 398 81 315 minecraft:red_terracotta
setblock 399 78 278 minecraft:stripped_oak_log
fill 399 78 314 399 80 314 minecraft:red_terracotta
setblock 400 78 277 minecraft:stripped_oak_log
fill 400 78 278 400 81 278 minecraft:red_terracotta
setblock 401 78 276 minecraft:stripped_oak_log
fill 401 78 277 401 81 277 minecraft:red_terracotta
setblock 401 78 316 minecraft:stripped_oak_log
fill 402 78 276 402 81 276 minecraft:red_terracotta
setblock 402 78 315 minecraft:stripped_oak_log
fill 402 78 316 402 81 316 minecraft:red_terracotta
setblock 403 78 278 minecraft:red_terracotta
setblock 403 78 314 minecraft:stripped_oak_log
fill 403 78 315 403 81 315 minecraft:red_terracotta
setblock 404 78 278 minecraft:stripped_oak_log
setblock 404 78 314 minecraft:red_terracotta
setblock 405 78 277 minecraft:stripped_oak_log
setblock 406 78 276 minecraft:stripped_oak_log
fill 406 78 277 406 79 277 minecraft:red_terracotta
setblock 406 78 316 minecraft:stripped_oak_log
fill 407 78 276 407 80 276 minecraft:red_terracotta
setblock 407 78 315 minecraft:stripped_oak_log
fill 407 78 316 407 80 316 minecraft:red_terracotta
fill 409 78 292 409 80 292 minecraft:brown_terracotta
fill 409 78 295 409 80 295 minecraft:brown_terracotta
setblock 411 78 276 minecraft:stripped_oak_log
setblock 411 78 316 minecraft:stripped_oak_log
setblock 412 78 276 minecraft:red_terracotta
fill 412 78 292 412 80 292 minecraft:brown_terracotta
fill 412 78 295 412 80 295 minecraft:brown_terracotta
setblock 412 78 316 minecraft:red_terracotta
fill 415 78 295 415 78 296 minecraft:red_terracotta
setblock 415 78 297 minecraft:stripped_oak_log
fill 415 78 298 415 81 298 minecraft:red_terracotta
setblock 415 78 301 minecraft:red_terracotta
setblock 415 78 302 minecraft:stripped_oak_log
setblock 416 78 276 minecraft:stripped_oak_log
fill 416 78 277 416 78 280 minecraft:red_terracotta
setblock 416 78 291 minecraft:stripped_oak_log
fill 416 78 292 416 81 292 minecraft:red_terracotta
setblock 416 78 296 minecraft:stripped_oak_log
fill 416 78 297 416 81 297 minecraft:red_terracotta
setblock 416 78 301 minecraft:stripped_oak_log
fill 416 78 302 416 81 302 minecraft:red_terracotta
setblock 416 78 305 minecraft:red_terracotta
setblock 416 78 316 minecraft:stripped_oak_log
fill 417 78 276 417 81 276 minecraft:red_terracotta
setblock 417 78 280 minecraft:stripped_oak_log
fill 417 78 281 417 78 284 minecraft:red_terracotta
setblock 417 78 285 minecraft:stripped_oak_log
fill 417 78 286 417 81 286 minecraft:red_terracotta
setblock 417 78 290 minecraft:stripped_oak_log
fill 417 78 291 417 81 291 minecraft:red_terracotta
setblock 417 78 295 minecraft:stripped_oak_log
fill 417 78 296 417 81 296 minecraft:red_terracotta
setblock 417 78 300 minecraft:stripped_oak_log
fill 417 78 301 417 81 301 minecraft:red_terracotta
setblock 417 78 304 minecraft:red_terracotta
setblock 417 78 305 minecraft:stripped_oak_log
fill 417 78 306 417 81 306 minecraft:red_terracotta
setblock 417 78 310 minecraft:stripped_oak_log
setblock 417 78 315 minecraft:stripped_oak_log
fill 417 78 316 417 81 316 minecraft:red_terracotta
setblock 377 79 279 minecraft:stripped_oak_log
fill 377 79 280 377 79 283 minecraft:red_terracotta
setblock 377 79 284 minecraft:stripped_oak_log
fill 377 79 285 377 82 285 minecraft:red_terracotta
setblock 377 79 289 minecraft:stripped_oak_log
fill 377 79 290 377 82 290 minecraft:red_terracotta
setblock 377 79 294 minecraft:stripped_oak_log
fill 377 79 295 377 82 295 minecraft:red_terracotta
setblock 377 79 299 minecraft:stripped_oak_log
fill 377 79 300 377 82 300 minecraft:red_terracotta
setblock 377 79 303 minecraft:red_terracotta
setblock 377 79 304 minecraft:stripped_oak_log
fill 377 79 305 377 82 305 minecraft:red_terracotta
fill 377 79 307 377 80 307 minecraft:red_terracotta
setblock 377 79 314 minecraft:stripped_oak_log
fill 377 79 315 377 81 315 minecraft:red_terracotta
setblock 378 79 278 minecraft:stripped_oak_log
fill 378 79 279 381 79 279 minecraft:red_terracotta
setblock 378 79 282 minecraft:red_terracotta
setblock 378 79 283 minecraft:stripped_oak_log
fill 378 79 284 378 82 284 minecraft:red_terracotta
setblock 378 79 288 minecraft:stripped_oak_log
fill 378 79 289 378 82 289 minecraft:red_terracotta
setblock 378 79 293 minecraft:stripped_oak_log
fill 378 79 294 378 82 294 minecraft:red_terracotta
setblock 378 79 298 minecraft:stripped_oak_log
fill 378 79 299 378 82 299 minecraft:red_terracotta
setblock 378 79 303 minecraft:stripped_oak_log
fill 378 79 304 378 82 304 minecraft:red_terracotta
setblock 379 79 277 minecraft:stripped_oak_log
fill 379 79 278 379 82 278 minecraft:red_terracotta
setblock 379 79 282 minecraft:stripped_oak_log
fill 379 79 283 379 82 283 minecraft:red_terracotta
setblock 379 79 286 minecraft:red_terracotta
setblock 379 79 287 minecraft:stripped_oak_log
setblock 379 79 288 minecraft:red_terracotta
setblock 379 79 292 minecraft:stripped_oak_log
setblock 379 79 293 minecraft:red_terracotta
setblock 379 79 297 minecraft:stripped_oak_log
fill 379 79 298 379 81 298 minecraft:red_terracotta
setblock 379 79 302 minecraft:stripped_oak_log
setblock 379 79 310 minecraft:light[level=15]
setblock 380 79 276 minecraft:stripped_oak_log
fill 380 79 277 380 82 277 minecraft:red_terracotta
setblock 380 79 281 minecraft:stripped_oak_log
fill 380 79 282 380 82 282 minecraft:red_terracotta
setblock 380 79 316 minecraft:stripped_oak_log
fill 381 79 276 384 79 276 minecraft:red_terracotta
setblock 381 79 280 minecraft:stripped_oak_log
setblock 381 79 315 minecraft:stripped_oak_log
fill 381 79 316 384 79 316 minecraft:red_terracotta
setblock 382 79 279 minecraft:stripped_oak_log
setblock 382 79 315 minecraft:red_terracotta
setblock 383 79 278 minecraft:stripped_oak_log
fill 383 79 279 383 81 279 minecraft:red_terracotta
setblock 384 79 277 minecraft:stripped_oak_log
fill 384 79 278 384 82 278 minecraft:red_terracotta
setblock 385 79 276 minecraft:stripped_oak_log
fill 385 79 277 385 82 277 minecraft:red_terracotta
setblock 385 79 316 minecraft:stripped_oak_log
fill 386 79 276 389 79 276 minecraft:red_terracotta
fill 386 79 316 389 79 316 minecraft:red_terracotta
setblock 387 79 286 minecraft:light[level=15]
setblock 387 79 294 minecraft:light[level=15]
setblock 387 79 302 minecraft:light[level=15]
setblock 387 79 310 minecraft:light[level=15]
setblock 388 79 278 minecraft:stripped_oak_log
setblock 389 79 277 minecraft:stripped_oak_log
fill 389 79 278 390 79 278 minecraft:red_terracotta
setblock 390 79 276 minecraft:stripped_oak_log
fill 390 79 277 390 82 277 minecraft:red_terracotta
setblock 390 79 316 minecraft:stripped_oak_log
fill 391 79 276 391 82 276 minecraft:red_terracotta
fill 391 79 316 391 82 316 minecraft:red_terracotta
setblock 393 79 278 minecraft:stripped_oak_log
setblock 394 79 277 minecraft:stripped_oak_log
fill 394 79 278 397 79 278 minecraft:red_terracotta
setblock 395 79 276 minecraft:stripped_oak_log
fill 395 79 277 395 82 277 minecraft:red_terracotta
setblock 395 79 286 minecraft:light[level=15]
setblock 395 79 302 minecraft:light[level=15]
setblock 395 79 310 minecraft:light[level=15]
setblock 395 79 316 minecraft:stripped_oak_log
fill 396 79 276 396 82 276 minecraft:red_terracotta
setblock 396 79 315 minecraft:stripped_oak_log
fill 396 79 316 396 82 316 minecraft:red_terracotta
setblock 397 79 314 minecraft:stripped_oak_log
fill 397 79 315 397 82 315 minecraft:red_terracotta
setblock 398 79 278 minecraft:stripped_oak_log
fill 398 79 314 398 80 314 minecraft:red_terracotta
setblock 399 79 277 minecraft:stripped_oak_log
fill 399 79 278 399 82 278 minecraft:red_terracotta
setblock 400 79 276 minecraft:stripped_oak_log
fill 400 79 277 400 82 277 minecraft:red_terracotta
setblock 400 79 316 minecraft:stripped_oak_log
fill 401 79 276 401 82 276 minecraft:red_terracotta
setblock 401 79 315 minecraft:stripped_oak_log
fill 401 79 316 401 82 316 minecraft:red_terracotta
setblock 402 79 314 minecraft:stripped_oak_log
fill 402 79 315 402 81 315 minecraft:red_terracotta
setblock 403 79 278 minecraft:stripped_oak_log
setblock 403 79 286 minecraft:light[level=15]
setblock 403 79 294 minecraft:light[level=15]
setblock 403 79 302 minecraft:light[level=15]
setblock 403 79 310 minecraft:light[level=15]
setblock 403 79 314 minecraft:red_terracotta
setblock 404 79 277 minecraft:stripped_oak_log
setblock 405 79 276 minecraft:stripped_oak_log
fill 405 79 277 405 80 277 minecraft:red_terracotta
setblock 405 79 316 minecraft:stripped_oak_log
fill 406 79 276 406 80 276 minecraft:red_terracotta
setblock 406 79 315 minecraft:stripped_oak_log
fill 406 79 316 406 81 316 minecraft:red_terracotta
fill 408 79 293 408 80 294 minecraft:brown_terracotta
fill 410 79 296 411 80 296 minecraft:brown_terracotta
setblock 411 79 278 minecraft:light[level=15]
setblock 411 79 286 minecraft:light[level=15]
setblock 411 79 302 minecraft:light[level=15]
setblock 411 79 310 minecraft:light[level=15]
fill 412 79 291 412 80 291 minecraft:brown_terracotta
fill 413 79 292 413 80 294 minecraft:brown_terracotta
setblock 414 79 276 minecraft:red_terracotta
setblock 415 79 276 minecraft:stripped_oak_log
setblock 415 79 295 minecraft:red_terracotta
setblock 415 79 296 minecraft:stripped_oak_log
fill 415 79 297 415 82 297 minecraft:red_terracotta
setblock 415 79 301 minecraft:stripped_oak_log
fill 415 79 302 415 81 303 minecraft:red_terracotta
setblock 415 79 316 minecraft:stripped_oak_log
fill 416 79 276 416 79 279 minecraft:red_terracotta
setblock 416 79 280 minecraft:stripped_oak_log
fill 416 79 281 417 80 282 minecraft:red_terracotta
fill 416 79 291 416 81 291 minecraft:red_terracotta
setblock 416 79 295 minecraft:stripped_oak_log
fill 416 79 296 416 82 296 minecraft:red_terracotta
setblock 416 79 300 minecraft:stripped_oak_log
fill 416 79 301 416 82 301 minecraft:red_terracotta
setblock 416 79 305 minecraft:stripped_oak_log
fill 416 79 306 416 82 306 minecraft:red_terracotta
fill 416 79 316 416 80 316 minecraft:red_terracotta
setblock 417 79 279 minecraft:stripped_oak_log
fill 417 79 280 417 82 280 minecraft:red_terracotta
setblock 417 79 283 minecraft:red_terracotta
setblock 417 79 284 minecraft:stripped_oak_log
fill 417 79 285 417 82 285 minecraft:red_terracotta
setblock 417 79 289 minecraft:stripped_oak_log
fill 417 79 290 417 82 290 minecraft:red_terracotta
setblock 417 79 294 minecraft:stripped_oak_log
fill 417 79 295 417 82 295 minecraft:red_terracotta
setblock 417 79 299 minecraft:stripped_oak_log
fill 417 79 300 417 82 300 minecraft:red_terracotta
setblock 417 79 304 minecraft:stripped_oak_log
fill 417 79 305 417 82 305 minecraft:red_terracotta
setblock 417 79 309 minecraft:stripped_oak_log
setblock 417 79 310 minecraft:red_terracotta
setblock 417 79 314 minecraft:stripped_oak_log
fill 417 79 315 417 80 315 minecraft:red_terracotta
fill 376 80 275 376 83 317 minecraft:light_gray_terracotta
fill 377 80 275 418 83 275 minecraft:light_gray_terracotta
setblock 377 80 278 minecraft:stripped_oak_log
fill 377 80 279 377 80 282 minecraft:red_terracotta
setblock 377 80 283 minecraft:stripped_oak_log
fill 377 80 284 377 83 284 minecraft:red_terracotta
setblock 377 80 288 minecraft:stripped_oak_log
fill 377 80 289 377 83 289 minecraft:red_terracotta
setblock 377 80 293 minecraft:stripped_oak_log
fill 377 80 294 377 83 294 minecraft:red_terracotta
setblock 377 80 298 minecraft:stripped_oak_log
fill 377 80 299 377 83 299 minecraft:red_terracotta
setblock 377 80 303 minecraft:stripped_oak_log
fill 377 80 304 377 83 304 minecraft:red_terracotta
fill 377 80 317 418 83 317 minecraft:light_gray_terracotta
setblock 378 80 277 minecraft:stripped_oak_log
fill 378 80 278 378 82 279 minecraft:red_terracotta
setblock 378 80 282 minecraft:stripped_oak_log
fill 378 80 283 378 83 283 minecraft:red_terracotta
setblock 378 80 287 minecraft:stripped_oak_log
fill 378 80 288 378 83 288 minecraft:red_terracotta
setblock 378 80 292 minecraft:stripped_oak_log
fill 378 80 293 378 82 293 minecraft:red_terracotta
setblock 378 80 297 minecraft:stripped_oak_log
fill 378 80 298 378 83 298 minecraft:red_terracotta
setblock 378 80 301 minecraft:red_terracotta
setblock 378 80 302 minecraft:stripped_oak_log
fill 378 80 303 378 83 303 minecraft:red_terracotta
fill 378 80 305 378 81 305 minecraft:red_terracotta
setblock 379 80 276 minecraft:stripped_oak_log
fill 379 80 277 379 83 277 minecraft:red_terracotta
fill 379 80 279 379 80 280 minecraft:red_terracotta
setblock 379 80 281 minecraft:stripped_oak_log
fill 379 80 282 379 83 282 minecraft:red_terracotta
setblock 379 80 286 minecraft:stripped_oak_log
fill 379 80 287 379 81 287 minecraft:red_terracotta
setblock 379 80 296 minecraft:stripped_oak_log
fill 379 80 297 379 81 297 minecraft:red_terracotta
setblock 379 80 301 minecraft:stripped_oak_log
setblock 379 80 302 minecraft:red_terracotta
setblock 379 80 316 minecraft:stripped_oak_log
fill 380 80 276 383 80 276 minecraft:red_terracotta
setblock 380 80 279 minecraft:red_terracotta
setblock 380 80 280 minecraft:stripped_oak_log
fill 380 80 281 380 83 281 minecraft:red_terracotta
setblock 380 80 284 minecraft:red_terracotta
fill 380 80 316 383 80 316 minecraft:red_terracotta
setblock 381 80 279 minecraft:stripped_oak_log
setblock 382 80 278 minecraft:stripped_oak_log
fill 382 80 279 382 82 279 minecraft:red_terracotta
setblock 383 80 277 minecraft:stripped_oak_log
fill 383 80 278 383 83 278 minecraft:red_terracotta
setblock 384 80 276 minecraft:stripped_oak_log
fill 384 80 277 384 83 277 minecraft:red_terracotta
setblock 384 80 316 minecraft:stripped_oak_log
fill 385 80 276 388 80 276 minecraft:red_terracotta
fill 385 80 316 388 80 316 minecraft:red_terracotta
setblock 387 80 278 minecraft:stripped_oak_log
setblock 388 80 277 minecraft:stripped_oak_log
setblock 388 80 278 minecraft:red_terracotta
setblock 389 80 276 minecraft:stripped_oak_log
fill 389 80 277 389 82 277 minecraft:red_terracotta
setblock 389 80 316 minecraft:stripped_oak_log
fill 390 80 276 390 83 276 minecraft:red_terracotta
fill 390 80 316 390 81 316 minecraft:red_terracotta
setblock 393 80 277 minecraft:stripped_oak_log
setblock 394 80 276 minecraft:stripped_oak_log
fill 394 80 277 394 80 278 minecraft:red_terracotta
setblock 394 80 316 minecraft:stripped_oak_log
fill 395 80 276 395 83 276 minecraft:red_terracotta
fill 395 80 278 396 80 278 minecraft:red_terracotta
setblock 395 80 315 minecraft:stripped_oak_log
fill 395 80 316 395 83 316 minecraft:red_terracotta
fill 396 80 315 396 83 315 minecraft:red_terracotta
setblock 397 80 278 minecraft:stripped_oak_log
setblock 398 80 277 minecraft:stripped_oak_log
fill 398 80 278 398 82 278 minecraft:red_terracotta
setblock 399 80 276 minecraft:stripped_oak_log
fill 399 80 277 399 83 277 minecraft:red_terracotta
setblock 399 80 316 minecraft:stripped_oak_log
fill 400 80 276 400 83 276 minecraft:red_terracotta
setblock 400 80 315 minecraft:stripped_oak_log
fill 400 80 316 400 83 316 minecraft:red_terracotta
setblock 401 80 314 minecraft:stripped_oak_log
fill 401 80 315 401 82 315 minecraft:red_terracotta
setblock 402 80 278 minecraft:stripped_oak_log
setblock 402 80 314 minecraft:red_terracotta
setblock 403 80 277 minecraft:stripped_oak_log
setblock 404 80 276 minecraft:stripped_oak_log
setblock 404 80 277 minecraft:red_terracotta
setblock 404 80 316 minecraft:stripped_oak_log
fill 405 80 276 405 81 276 minecraft:red_terracotta
setblock 405 80 315 minecraft:stripped_oak_log
fill 405 80 316 405 81 316 minecraft:red_terracotta
setblock 408 80 292 minecraft:brown_terracotta
setblock 408 80 295 minecraft:brown_terracotta
setblock 409 80 296 minecraft:brown_terracotta
setblock 412 80 296 minecraft:brown_terracotta
setblock 413 80 295 minecraft:brown_terracotta
setblock 414 80 276 minecraft:stripped_oak_log
fill 415 80 276 416 82 276 minecraft:red_terracotta
fill 415 80 296 415 81 296 minecraft:red_terracotta
setblock 415 80 300 minecraft:stripped_oak_log
fill 415 80 301 415 83 301 minecraft:red_terracotta
fill 416 80 277 416 80 278 minecraft:red_terracotta
setblock 416 80 279 minecraft:stripped_oak_log
fill 416 80 280 416 83 280 minecraft:red_terracotta
setblock 416 80 283 minecraft:red_terracotta
setblock 416 80 284 minecraft:stripped_oak_log
setblock 416 80 294 minecraft:stripped_oak_log
fill 416 80 295 416 83 295 minecraft:red_terracotta
setblock 416 80 299 minecraft:stripped_oak_log
fill 416 80 300 416 83 300 minecraft:red_terracotta
setblock 416 80 303 minecraft:red_terracotta
setblock 416 80 304 minecraft:stripped_oak_log
fill 416 80 305 416 83 305 minecraft:red_terracotta
setblock 417 80 278 minecraft:stripped_oak_log
fill 417 80 279 417 83 279 minecraft:red_terracotta
setblock 417 80 283 minecraft:stripped_oak_log
fill 417 80 284 417 83 284 minecraft:red_terracotta
setblock 417 80 288 minecraft:stripped_oak_log
fill 417 80 289 417 83 289 minecraft:red_terracotta
setblock 417 80 293 minecraft:stripped_oak_log
fill 417 80 294 417 83 294 minecraft:red_terracotta
setblock 417 80 298 minecraft:stripped_oak_log
fill 417 80 299 417 83 299 minecraft:red_terracotta
setblock 417 80 303 minecraft:stripped_oak_log
fill 417 80 304 417 83 304 minecraft:red_terracotta
setblock 417 80 308 minecraft:stripped_oak_log
fill 417 80 309 417 83 309 minecraft:red_terracotta
fill 418 80 276 418 83 316 minecraft:light_gray_terracotta
setblock 377 81 277 minecraft:stripped_oak_log
fill 377 81 278 377 81 281 minecraft:red_terracotta
setblock 377 81 282 minecraft:stripped_oak_log
fill 377 81 283 377 84 283 minecraft:red_terracotta
setblock 377 81 287 minecraft:stripped_oak_log
fill 377 81 288 377 84 288 minecraft:red_terracotta
setblock 377 81 292 minecraft:stripped_oak_log
fill 377 81 293 377 84 293 minecraft:red_terracotta
setblock 377 81 297 minecraft:stripped_oak_log
fill 377 81 298 377 84 298 minecraft:red_terracotta
setblock 377 81 302 minecraft:stripped_oak_log
fill 377 81 303 377 84 303 minecraft:red_terracotta
setblock 377 81 307 minecraft:stripped_oak_log
setblock 378 81 276 minecraft:stripped_oak_log
fill 378 81 277 378 84 277 minecraft:red_terracotta
setblock 378 81 281 minecraft:stripped_oak_log
fill 378 81 282 378 84 282 minecraft:red_terracotta
setblock 378 81 286 minecraft:stripped_oak_log
fill 378 81 287 378 84 287 minecraft:red_terracotta
setblock 378 81 291 minecraft:stripped_oak_log
fill 378 81 292 378 82 292 minecraft:red_terracotta
setblock 378 81 296 minecraft:stripped_oak_log
fill 378 81 297 378 83 297 minecraft:red_terracotta
setblock 378 81 301 minecraft:stripped_oak_log
fill 378 81 302 378 84 302 minecraft:red_terracotta
setblock 378 81 316 minecraft:stripped_oak_log
fill 379 81 276 382 81 276 minecraft:red_terracotta
setblock 379 81 279 minecraft:red_terracotta
setblock 379 81 280 minecraft:stripped_oak_log
fill 379 81 281 379 84 281 minecraft:red_terracotta
setblock 379 81 285 minecraft:stripped_oak_log
fill 379 81 286 379 84 286 minecraft:red_terracotta
setblock 379 81 300 minecraft:stripped_oak_log
setblock 379 81 301 minecraft:red_terracotta
fill 379 81 316 382 81 316 minecraft:red_terracotta
setblock 380 81 279 minecraft:stripped_oak_log
fill 380 81 280 380 84 280 minecraft:red_terracotta
setblock 381 81 278 minecraft:stripped_oak_log
fill 381 81 279 381 82 279 minecraft:red_terracotta
setblock 382 81 277 minecraft:stripped_oak_log
fill 382 81 278 382 84 278 minecraft:red_terracotta
setblock 383 81 276 minecraft:stripped_oak_log
fill 383 81 277 383 84 277 minecraft:red_terracotta
setblock 383 81 316 minecraft:stripped_oak_log
fill 384 81 276 387 81 276 minecraft:red_terracotta
fill 384 81 316 387 81 316 minecraft:red_terracotta
setblock 386 81 278 minecraft:stripped_oak_log
setblock 387 81 277 minecraft:stripped_oak_log
setblock 388 81 276 minecraft:stripped_oak_log
fill 388 81 277 388 82 277 minecraft:red_terracotta
setblock 388 81 316 minecraft:stripped_oak_log
fill 389 81 276 389 84 276 minecraft:red_terracotta
setblock 389 81 316 minecraft:red_terracotta
setblock 392 81 277 minecraft:stripped_oak_log
setblock 393 81 276 minecraft:stripped_oak_log
fill 393 81 277 394 83 277 minecraft:red_terracotta
setblock 393 81 316 minecraft:stripped_oak_log
fill 394 81 276 394 84 276 minecraft:red_terracotta
fill 394 81 316 394 84 316 minecraft:red_terracotta
setblock 395 81 278 minecraft:red_terracotta
fill 395 81 315 395 82 315 minecraft:red_terracotta
setblock 396 81 278 minecraft:stripped_oak_log
setblock 397 81 277 minecraft:stripped_oak_log
fill 397 81 278 397 82 278 minecraft:red_terracotta
setblock 398 81 276 minecraft:stripped_oak_log
fill 398 81 277 398 84 277 minecraft:red_terracotta
setblock 398 81 316 minecraft:stripped_oak_log
fill 399 81 276 399 84 276 minecraft:red_terracotta
setblock 399 81 315 minecraft:stripped_oak_log
fill 399 81 316 399 84 316 minecraft:red_terracotta
fill 400 81 315 400 83 315 minecraft:red_terracotta
setblock 401 81 278 minecraft:stripped_oak_log
setblock 402 81 277 minecraft:stripped_oak_log
setblock 403 81 276 minecraft:stripped_oak_log
setblock 403 81 277 minecraft:red_terracotta
setblock 403 81 316 minecraft:stripped_oak_log
fill 404 81 276 404 82 276 minecraft:red_terracotta
fill 404 81 316 404 82 316 minecraft:red_terracotta
fill 410 81 293 411 82 294 minecraft:shroomlight
setblock 414 81 276 minecraft:red_terracotta
setblock 415 81 299 minecraft:stripped_oak_log
fill 415 81 300 415 84 300 minecraft:red_terracotta
setblock 416 81 277 minecraft:red_terracotta
setblock 416 81 278 minecraft:stripped_oak_log
fill 416 81 279 416 84 279 minecraft:red_terracotta
fill 416 81 281 416 81 282 minecraft:red_terracotta
setblock 416 81 283 minecraft:stripped_oak_log
fill 416 81 284 416 82 286 minecraft:red_terracotta
setblock 416 81 293 minecraft:stripped_oak_log
fill 416 81 294 416 84 294 minecraft:red_terracotta
setblock 416 81 298 minecraft:stripped_oak_log
fill 416 81 299 416 84 299 minecraft:red_terracotta
setblock 416 81 303 minecraft:stripped_oak_log
fill 416 81 304 416 84 304 minecraft:red_terracotta
setblock 417 81 277 minecraft:stripped_oak_log
fill 417 81 278 417 84 278 minecraft:red_terracotta
setblock 417 81 281 minecraft:red_terracotta
setblock 417 81 282 minecraft:stripped_oak_log
fill 417 81 283 417 84 283 minecraft:red_terracotta
setblock 417 81 287 minecraft:stripped_oak_log
fill 417 81 288 417 84 288 minecraft:red_terracotta
setblock 417 81 292 minecraft:stripped_oak_log
fill 417 81 293 417 84 293 minecraft:red_terracotta
setblock 417 81 297 minecraft:stripped_oak_log
fill 417 81 298 417 84 298 minecraft:red_terracotta
setblock 417 81 302 minecraft:stripped_oak_log
fill 417 81 303 417 84 303 minecraft:red_terracotta
setblock 417 81 307 minecraft:stripped_oak_log
fill 417 81 308 417 84 308 minecraft:red_terracotta
setblock 377 82 276 minecraft:stripped_oak_log
fill 377 82 277 377 82 280 minecraft:red_terracotta
setblock 377 82 281 minecraft:stripped_oak_log
fill 377 82 282 377 85 282 minecraft:red_terracotta
setblock 377 82 286 minecraft:stripped_oak_log
fill 377 82 287 377 85 287 minecraft:red_terracotta
setblock 377 82 291 minecraft:stripped_oak_log
fill 377 82 292 377 85 292 minecraft:red_terracotta
setblock 377 82 296 minecraft:stripped_oak_log
fill 377 82 297 377 85 297 minecraft:red_terracotta
setblock 377 82 301 minecraft:stripped_oak_log
fill 377 82 302 377 85 302 minecraft:red_terracotta
setblock 377 82 306 minecraft:stripped_oak_log
fill 377 82 307 377 85 307 minecraft:red_terracotta
setblock 377 82 316 minecraft:stripped_oak_log
fill 378 82 276 381 82 276 minecraft:red_terracotta
setblock 378 82 280 minecraft:stripped_oak_log
fill 378 82 281 378 85 281 minecraft:red_terracotta
setblock 378 82 285 minecraft:stripped_oak_log
fill 378 82 286 378 85 286 minecraft:red_terracotta
setblock 378 82 290 minecraft:stripped_oak_log
setblock 378 82 291 minecraft:red_terracotta
setblock 378 82 295 minecraft:stripped_oak_log
setblock 378 82 296 minecraft:red_terracotta
setblock 378 82 300 minecraft:stripped_oak_log
fill 378 82 301 378 85 301 minecraft:red_terracotta
setblock 378 82 305 minecraft:stripped_oak_log
fill 378 82 316 381 82 316 minecraft:red_terracotta
setblock 379 82 279 minecraft:stripped_oak_log
fill 379 82 280 379 85 280 minecraft:red_terracotta
setblock 379 82 284 minecraft:stripped_oak_log
fill 379 82 285 379 85 285 minecraft:red_terracotta
setblock 380 82 278 minecraft:stripped_oak_log
fill 380 82 279 380 83 279 minecraft:red_terracotta
setblock 380 82 283 minecraft:stripped_oak_log
setblock 381 82 277 minecraft:stripped_oak_log
fill 381 82 278 381 84 278 minecraft:red_terracotta
setblock 382 82 276 minecraft:stripped_oak_log
fill 382 82 277 382 85 277 minecraft:red_terracotta
setblock 382 82 316 minecraft:stripped_oak_log
fill 383 82 276 386 82 276 minecraft:red_terracotta
fill 383 82 316 384 82 316 minecraft:red_terracotta
setblock 385 82 278 minecraft:stripped_oak_log
setblock 386 82 277 minecraft:stripped_oak_log
setblock 387 82 276 minecraft:stripped_oak_log
setblock 387 82 277 minecraft:red_terracotta
fill 388 82 276 388 84 276 minecraft:red_terracotta
setblock 391 82 277 minecraft:stripped_oak_log
setblock 392 82 276 minecraft:stripped_oak_log
setblock 392 82 277 minecraft:red_terracotta
setblock 392 82 316 minecraft:stripped_oak_log
fill 393 82 276 393 85 276 minecraft:red_terracotta
fill 393 82 316 393 85 316 minecraft:red_terracotta
setblock 396 82 277 minecraft:stripped_oak_log
setblock 396 82 278 minecraft:red_terracotta
setblock 397 82 276 minecraft:stripped_oak_log
fill 397 82 277 397 84 277 minecraft:red_terracotta
setblock 397 82 316 minecraft:stripped_oak_log
fill 398 82 276 398 85 276 minecraft:red_terracotta
setblock 398 82 315 minecraft:stripped_oak_log
fill 398 82 316 398 85 316 minecraft:red_terracotta
fill 399 82 315 399 83 315 minecraft:red_terracotta
setblock 401 82 277 minecraft:stripped_oak_log
fill 401 82 283 401 83 283 minecraft:shroomlight
setblock 402 82 276 minecraft:stripped_oak_log
setblock 402 82 277 minecraft:red_terracotta
setblock 402 82 316 minecraft:stripped_oak_log
setblock 403 82 276 minecraft:red_terracotta
fill 403 82 316 403 83 316 minecraft:red_terracotta
setblock 415 82 298 minecraft:stripped_oak_log
fill 415 82 299 415 84 299 minecraft:red_terracotta
setblock 415 82 302 minecraft:red_terracotta
setblock 415 82 303 minecraft:stripped_oak_log
fill 415 82 304 415 85 304 minecraft:red_terracotta
setblock 416 82 277 minecraft:stripped_oak_log
fill 416 82 278 416 85 278 minecraft:red_terracotta
setblock 416 82 281 minecraft:red_terracotta
setblock 416 82 282 minecraft:stripped_oak_log
fill 416 82 283 416 85 283 minecraft:red_terracotta
setblock 416 82 287 minecraft:stripped_oak_log
fill 416 82 288 416 85 288 minecraft:red_terracotta
setblock 416 82 292 minecraft:stripped_oak_log
fill 416 82 293 416 85 293 minecraft:red_terracotta
setblock 416 82 297 minecraft:stripped_oak_log
fill 416 82 298 416 85 298 minecraft:red_terracotta
setblock 416 82 302 minecraft:stripped_oak_log
fill 416 82 303 416 85 303 minecraft:red_terracotta
setblock 417 82 276 minecraft:stripped_oak_log
fill 417 82 277 417 85 277 minecraft:red_terracotta
setblock 417 82 281 minecraft:stripped_oak_log
fill 417 82 282 417 85 282 minecraft:red_terracotta
setblock 417 82 286 minecraft:stripped_oak_log
fill 417 82 287 417 85 287 minecraft:red_terracotta
setblock 417 82 291 minecraft:stripped_oak_log
fill 417 82 292 417 85 292 minecraft:red_terracotta
setblock 417 82 296 minecraft:stripped_oak_log
fill 417 82 297 417 85 297 minecraft:red_terracotta
setblock 417 82 301 minecraft:stripped_oak_log
fill 417 82 302 417 85 302 minecraft:red_terracotta
setblock 417 82 306 minecraft:stripped_oak_log
fill 417 82 307 417 85 307 minecraft:red_terracotta
fill 377 83 276 377 83 279 minecraft:red_terracotta
setblock 377 83 280 minecraft:stripped_oak_log
fill 377 83 281 377 86 281 minecraft:red_terracotta
setblock 377 83 285 minecraft:stripped_oak_log
fill 377 83 286 377 86 286 minecraft:red_terracotta
setblock 377 83 290 minecraft:stripped_oak_log
fill 377 83 291 377 86 291 minecraft:red_terracotta
setblock 377 83 295 minecraft:stripped_oak_log
fill 377 83 296 377 86 296 minecraft:red_terracotta
setblock 377 83 300 minecraft:stripped_oak_log
fill 377 83 301 377 86 301 minecraft:red_terracotta
setblock 377 83 305 minecraft:stripped_oak_log
fill 377 83 306 377 86 306 minecraft:red_terracotta
fill 377 83 308 377 84 308 minecraft:red_terracotta
fill 378 83 276 380 83 276 minecraft:red_terracotta
setblock 378 83 278 minecraft:red_terracotta
setblock 378 83 279 minecraft:stripped_oak_log
fill 378 83 280 378 86 280 minecraft:red_terracotta
setblock 378 83 284 minecraft:stripped_oak_log
fill 378 83 285 378 86 285 minecraft:red_terracotta
setblock 378 83 289 minecraft:stripped_oak_log
setblock 378 83 290 minecraft:red_terracotta
setblock 378 83 299 minecraft:stripped_oak_log
fill 378 83 300 378 84 300 minecraft:red_terracotta
setblock 378 83 304 minecraft:stripped_oak_log
fill 378 83 305 378 86 305 minecraft:red_terracotta
fill 378 83 316 380 83 316 minecraft:red_terracotta
setblock 379 83 278 minecraft:stripped_oak_log
fill 379 83 279 379 86 279 minecraft:red_terracotta
setblock 379 83 283 minecraft:stripped_oak_log
fill 379 83 284 379 86 284 minecraft:red_terracotta
setblock 379 83 292 minecraft:light[level=12]
setblock 379 83 299 minecraft:light[level=12]
setblock 379 83 306 minecraft:light[level=12]
setblock 379 83 313 minecraft:light[level=12]
setblock 380 83 277 minecraft:stripped_oak_log
fill 380 83 278 380 85 278 minecraft:red_terracotta
setblock 380 83 282 minecraft:stripped_oak_log
setblock 380 83 283 minecraft:red_terracotta
setblock 381 83 276 minecraft:stripped_oak_log
fill 381 83 277 381 86 277 minecraft:red_terracotta
setblock 381 83 316 minecraft:stripped_oak_log
fill 382 83 276 385 83 276 minecraft:red_terracotta
setblock 385 83 277 minecraft:stripped_oak_log
setblock 386 83 276 minecraft:stripped_oak_log
setblock 386 83 277 minecraft:red_terracotta
setblock 386 83 278 minecraft:light[level=12]
setblock 386 83 285 minecraft:light[level=12]
setblock 386 83 292 minecraft:light[level=12]
setblock 386 83 299 minecraft:light[level=12]
setblock 386 83 306 minecraft:light[level=12]
setblock 386 83 313 minecraft:light[level=12]
fill 387 83 276 387 84 276 minecraft:red_terracotta
fill 389 83 277 389 92 277 minecraft:brown_terracotta
setblock 391 83 276 minecraft:stripped_oak_log
fill 392 83 276 392 86 276 minecraft:red_terracotta
fill 392 83 316 392 86 316 minecraft:red_terracotta
setblock 393 83 278 minecraft:light[level=12]
setblock 393 83 285 minecraft:light[level=12]
setblock 393 83 292 minecraft:light[level=12]
setblock 393 83 299 minecraft:light[level=12]
setblock 393 83 306 minecraft:light[level=12]
setblock 393 83 313 minecraft:light[level=12]
setblock 395 83 277 minecraft:stripped_oak_log
setblock 396 83 276 minecraft:stripped_oak_log
fill 396 83 277 396 85 277 minecraft:red_terracotta
setblock 396 83 316 minecraft:stripped_oak_log
fill 397 83 276 397 86 276 minecraft:red_terracotta
setblock 397 83 315 minecraft:stripped_oak_log
fill 397 83 316 397 86 316 minecraft:red_terracotta
fill 398 83 315 398 84 315 minecraft:red_terracotta
setblock 400 83 277 minecraft:stripped_oak_log
setblock 400 83 278 minecraft:light[level=12]
setblock 400 83 285 minecraft:light[level=12]
setblock 400 83 292 minecraft:light[level=12]
setblock 400 83 299 minecraft:light[level=12]
setblock 400 83 306 minecraft:light[level=12]
setblock 400 83 313 minecraft:light[level=12]
setblock 401 83 276 minecraft:stripped_oak_log
setblock 401 83 316 minecraft:stripped_oak_log
setblock 402 83 276 minecraft:red_terracotta
setblock 402 83 316 minecraft:red_terracotta
setblock 407 83 278 minecraft:light[level=12]
setblock 407 83 285 minecraft:light[level=12]
setblock 407 83 292 minecraft:light[level=12]
setblock 407 83 299 minecraft:light[level=12]
setblock 407 83 306 minecraft:light[level=12]
setblock 407 83 313 minecraft:light[level=12]
fill 410 83 293 411 83 293 minecraft:shroomlight
setblock 411 83 294 minecraft:shroomlight
setblock 414 83 278 minecraft:light[level=12]
setblock 414 83 285 minecraft:light[level=12]
setblock 414 83 292 minecraft:light[level=12]
setblock 414 83 299 minecraft:light[level=12]
setblock 414 83 306 minecraft:light[level=12]
setblock 414 83 313 minecraft:light[level=12]
setblock 415 83 276 minecraft:red_terracotta
setblock 415 83 298 minecraft:red_terracotta
setblock 415 83 302 minecraft:stripped_oak_log
fill 415 83 303 415 86 303 minecraft:red_terracotta
setblock 416 83 276 minecraft:stripped_oak_log
setblock 416 83 281 minecraft:stripped_oak_log
fill 416 83 282 416 86 282 minecraft:red_terracotta
fill 416 83 284 416 83 285 minecraft:red_terracotta
setblock 416 83 286 minecraft:stripped_oak_log
fill 416 83 287 416 86 287 minecraft:red_terracotta
fill 416 83 289 416 84 289 minecraft:red_terracotta
setblock 416 83 296 minecraft:stripped_oak_log
fill 416 83 297 416 86 297 minecraft:red_terracotta
setblock 416 83 301 minecraft:stripped_oak_log
fill 416 83 302 416 86 302 minecraft:red_terracotta
setblock 416 83 306 minecraft:stripped_oak_log
fill 416 83 307 416 86 307 minecraft:red_terracotta
fill 417 83 276 417 86 276 minecraft:red_terracotta
setblock 417 83 280 minecraft:stripped_oak_log
fill 417 83 281 417 86 281 minecraft:red_terracotta
setblock 417 83 285 minecraft:stripped_oak_log
fill 417 83 286 417 86 286 minecraft:red_terracotta
setblock 417 83 290 minecraft:stripped_oak_log
fill 417 83 291 417 86 291 minecraft:red_terracotta
setblock 417 83 295 minecraft:stripped_oak_log
fill 417 83 296 417 86 296 minecraft:red_terracotta
setblock 417 83 300 minecraft:stripped_oak_log
fill 417 83 301 417 86 301 minecraft:red_terracotta
setblock 417 83 305 minecraft:stripped_oak_log
fill 417 83 306 417 86 306 minecraft:red_terracotta
fill 376 84 275 376 87 317 minecraft:orange_terracotta
fill 377 84 275 418 87 275 minecraft:orange_terracotta
fill 377 84 276 377 84 278 minecraft:red_terracotta
setblock 377 84 279 minecraft:stripped_oak_log
fill 377 84 280 377 87 280 minecraft:red_terracotta
setblock 377 84 284 minecraft:stripped_oak_log
fill 377 84 285 377 87 285 minecraft:red_terracotta
setblock 377 84 289 minecraft:stripped_oak_log
fill 377 84 290 377 87 290 minecraft:red_terracotta
setblock 377 84 294 minecraft:stripped_oak_log
fill 377 84 295 377 87 295 minecraft:red_terracotta
setblock 377 84 299 minecraft:stripped_oak_log
fill 377 84 300 377 87 300 minecraft:red_terracotta
setblock 377 84 304 minecraft:stripped_oak_log
fill 377 84 305 377 87 305 minecraft:red_terracotta
fill 377 84 317 418 87 317 minecraft:orange_terracotta
fill 378 84 276 379 84 276 minecraft:red_terracotta
setblock 378 84 278 minecraft:stripped_oak_log
fill 378 84 279 378 87 279 minecraft:red_terracotta
setblock 378 84 283 minecraft:stripped_oak_log
fill 378 84 284 378 87 284 minecraft:red_terracotta
setblock 378 84 288 minecraft:stripped_oak_log
fill 378 84 289 378 87 289 minecraft:red_terracotta
setblock 378 84 299 minecraft:red_terracotta
setblock 378 84 303 minecraft:stripped_oak_log
fill 378 84 304 378 87 304 minecraft:red_terracotta
setblock 379 84 277 minecraft:stripped_oak_log
fill 379 84 278 379 86 278 minecraft:red_terracotta
setblock 379 84 282 minecraft:stripped_oak_log
fill 379 84 283 379 87 283 minecraft:red_terracotta
setblock 380 84 276 minecraft:stripped_oak_log
fill 380 84 277 380 87 277 minecraft:red_terracotta
setblock 380 84 281 minecraft:stripped_oak_log
setblock 380 84 282 minecraft:red_terracotta
fill 381 84 276 384 84 276 minecraft:red_terracotta
setblock 384 84 277 minecraft:stripped_oak_log
setblock 385 84 276 minecraft:stripped_oak_log
setblock 386 84 276 minecraft:red_terracotta
setblock 390 84 276 minecraft:stripped_oak_log
fill 391 84 276 391 87 276 minecraft:red_terracotta
setblock 394 84 277 minecraft:stripped_oak_log
setblock 395 84 276 minecraft:stripped_oak_log
fill 395 84 277 395 85 277 minecraft:red_terracotta
setblock 395 84 316 minecraft:stripped_oak_log
fill 396 84 276 396 87 276 minecraft:red_terracotta
setblock 396 84 315 minecraft:stripped_oak_log
fill 396 84 316 396 87 316 minecraft:red_terracotta
fill 397 84 315 397 87 315 minecraft:red_terracotta
setblock 399 84 277 minecraft:stripped_oak_log
setblock 400 84 276 minecraft:stripped_oak_log
setblock 400 84 316 minecraft:stripped_oak_log
setblock 401 84 276 minecraft:red_terracotta
fill 401 84 283 401 94 283 minecraft:brown_terracotta
setblock 401 84 316 minecraft:red_terracotta
setblock 415 84 276 minecraft:stripped_oak_log
setblock 415 84 301 minecraft:stripped_oak_log
fill 415 84 302 415 87 302 minecraft:red_terracotta
fill 416 84 276 416 87 276 minecraft:red_terracotta
setblock 416 84 280 minecraft:stripped_oak_log
fill 416 84 281 416 87 281 minecraft:red_terracotta
setblock 416 84 284 minecraft:red_terracotta
setblock 416 84 285 minecraft:stripped_oak_log
fill 416 84 286 416 87 286 minecraft:red_terracotta
setblock 416 84 290 minecraft:stripped_oak_log
setblock 416 84 295 minecraft:stripped_oak_log
fill 416 84 296 416 87 296 minecraft:red_terracotta
setblock 416 84 300 minecraft:stripped_oak_log
fill 416 84 301 416 87 301 minecraft:red_terracotta
setblock 416 84 305 minecraft:stripped_oak_log
fill 416 84 306 416 87 306 minecraft:red_terracotta
setblock 417 84 279 minecraft:stripped_oak_log
fill 417 84 280 417 87 280 minecraft:red_terracotta
setblock 417 84 284 minecraft:stripped_oak_log
fill 417 84 285 417 87 285 minecraft:red_terracotta
setblock 417 84 289 minecraft:stripped_oak_log
fill 417 84 290 417 87 290 minecraft:red_terracotta
setblock 417 84 294 minecraft:stripped_oak_log
fill 417 84 295 417 87 295 minecraft:red_terracotta
setblock 417 84 299 minecraft:stripped_oak_log
fill 417 84 300 417 87 300 minecraft:red_terracotta
setblock 417 84 304 minecraft:stripped_oak_log
fill 417 84 305 417 87 305 minecraft:red_terracotta
setblock 417 84 309 minecraft:stripped_oak_log
fill 418 84 276 418 87 316 minecraft:orange_terracotta
fill 377 85 276 377 85 277 minecraft:red_terracotta
setblock 377 85 278 minecraft:stripped_oak_log
fill 377 85 279 377 88 279 minecraft:red_terracotta
setblock 377 85 283 minecraft:stripped_oak_log
fill 377 85 284 377 88 284 minecraft:red_terracotta
setblock 377 85 288 minecraft:stripped_oak_log
fill 377 85 289 377 88 289 minecraft:red_terracotta
setblock 377 85 293 minecraft:stripped_oak_log
fill 377 85 294 377 88 294 minecraft:red_terracotta
setblock 377 85 298 minecraft:stripped_oak_log
fill 377 85 299 377 88 299 minecraft:red_terracotta
setblock 377 85 303 minecraft:stripped_oak_log
fill 377 85 304 377 88 304 minecraft:red_terracotta
setblock 377 85 308 minecraft:stripped_oak_log
fill 377 85 309 377 88 309 minecraft:red_terracotta
setblock 378 85 276 minecraft:red_terracotta
setblock 378 85 277 minecraft:stripped_oak_log
fill 378 85 278 378 88 278 minecraft:red_terracotta
setblock 378 85 282 minecraft:stripped_oak_log
fill 378 85 283 378 88 283 minecraft:red_terracotta
setblock 378 85 287 minecraft:stripped_oak_log
fill 378 85 288 378 88 288 minecraft:red_terracotta
setblock 378 85 302 minecraft:stripped_oak_log
fill 378 85 303 378 86 303 minecraft:red_terracotta
setblock 379 85 276 minecraft:stripped_oak_log
fill 379 85 277 379 88 277 minecraft:red_terracotta
setblock 379 85 281 minecraft:stripped_oak_log
fill 379 85 282 379 88 282 minecraft:red_terracotta
setblock 379 85 286 minecraft:stripped_oak_log
fill 380 85 276 383 85 276 minecraft:red_terracotta
setblock 384 85 276 minecraft:stripped_oak_log
setblock 385 85 276 minecraft:red_terracotta
setblock 394 85 276 minecraft:stripped_oak_log
setblock 394 85 316 minecraft:stripped_oak_log
fill 395 85 276 395 88 276 minecraft:red_terracotta
fill 395 85 316 395 88 316 minecraft:red_terracotta
fill 396 85 315 396 88 315 minecraft:red_terracotta
setblock 399 85 276 minecraft:stripped_oak_log
setblock 399 85 316 minecraft:stripped_oak_log
setblock 400 85 276 minecraft:red_terracotta
fill 400 85 316 400 86 316 minecraft:red_terracotta
fill 415 85 282 415 85 284 minecraft:red_terracotta
setblock 415 85 285 minecraft:stripped_oak_log
setblock 415 85 300 minecraft:stripped_oak_log
fill 415 85 301 415 88 301 minecraft:red_terracotta
setblock 416 85 279 minecraft:stripped_oak_log
fill 416 85 280 416 88 280 minecraft:red_terracotta
setblock 416 85 284 minecraft:stripped_oak_log
fill 416 85 285 416 88 285 minecraft:red_terracotta
setblock 416 85 289 minecraft:stripped_oak_log
fill 416 85 290 416 86 292 minecraft:red_terracotta
setblock 416 85 294 minecraft:stripped_oak_log
fill 416 85 295 416 88 295 minecraft:red_terracotta
setblock 416 85 299 minecraft:stripped_oak_log
fill 416 85 300 416 88 300 minecraft:red_terracotta
setblock 416 85 304 minecraft:stripped_oak_log
fill 416 85 305 416 88 305 minecraft:red_terracotta
setblock 417 85 278 minecraft:stripped_oak_log
fill 417 85 279 417 88 279 minecraft:red_terracotta
setblock 417 85 283 minecraft:stripped_oak_log
fill 417 85 284 417 88 284 minecraft:red_terracotta
setblock 417 85 288 minecraft:stripped_oak_log
fill 417 85 289 417 88 289 minecraft:red_terracotta
setblock 417 85 293 minecraft:stripped_oak_log
fill 417 85 294 417 88 294 minecraft:red_terracotta
setblock 417 85 298 minecraft:stripped_oak_log
fill 417 85 299 417 88 299 minecraft:red_terracotta
setblock 417 85 303 minecraft:stripped_oak_log
fill 417 85 304 417 88 304 minecraft:red_terracotta
setblock 417 85 308 minecraft:stripped_oak_log
fill 417 85 309 417 87 310 minecraft:red_terracotta
setblock 377 86 276 minecraft:red_terracotta
setblock 377 86 277 minecraft:stripped_oak_log
fill 377 86 278 377 89 278 minecraft:red_terracotta
setblock 377 86 282 minecraft:stripped_oak_log
fill 377 86 283 377 89 283 minecraft:red_terracotta
setblock 377 86 287 minecraft:stripped_oak_log
fill 377 86 288 377 89 288 minecraft:red_terracotta
setblock 377 86 292 minecraft:stripped_oak_log
fill 377 86 293 377 89 293 minecraft:red_terracotta
setblock 377 86 297 minecraft:stripped_oak_log
fill 377 86 298 377 88 298 minecraft:red_terracotta
setblock 377 86 302 minecraft:stripped_oak_log
fill 377 86 303 377 89 303 minecraft:red_terracotta
setblock 377 86 307 minecraft:stripped_oak_log
fill 377 86 308 377 89 308 minecraft:red_terracotta
fill 377 86 310 377 87 310 minecraft:red_terracotta
setblock 378 86 276 minecraft:stripped_oak_log
fill 378 86 277 378 89 277 minecraft:red_terracotta
setblock 378 86 281 minecraft:stripped_oak_log
fill 378 86 282 378 89 282 minecraft:red_terracotta
setblock 378 86 286 minecraft:stripped_oak_log
fill 378 86 287 378 89 287 minecraft:red_terracotta
fill 379 86 276 382 86 276 minecraft:red_terracotta
setblock 379 86 280 minecraft:stripped_oak_log
fill 379 86 281 379 89 281 minecraft:red_terracotta
setblock 379 86 285 minecraft:stripped_oak_log
fill 379 86 286 379 89 286 minecraft:red_terracotta
setblock 383 86 276 minecraft:stripped_oak_log
setblock 384 86 276 minecraft:red_terracotta
setblock 393 86 276 minecraft:stripped_oak_log
setblock 393 86 316 minecraft:stripped_oak_log
fill 394 86 276 394 89 276 minecraft:red_terracotta
fill 394 86 316 394 89 316 minecraft:red_terracotta
fill 395 86 315 395 89 315 minecraft:red_terracotta
setblock 398 86 276 minecraft:stripped_oak_log
setblock 398 86 316 minecraft:stripped_oak_log
setblock 399 86 276 minecraft:red_terracotta
fill 399 86 316 399 89 316 minecraft:red_terracotta
fill 400 86 282 400 94 283 minecraft:brown_terracotta
fill 401 86 282 401 94 282 minecraft:brown_terracotta
fill 401 86 284 401 94 284 minecraft:brown_terracotta
fill 402 86 283 402 94 283 minecraft:brown_terracotta
fill 415 86 281 415 86 283 minecraft:red_terracotta
setblock 415 86 284 minecraft:stripped_oak_log
fill 415 86 285 415 87 287 minecraft:red_terracotta
setblock 415 86 304 minecraft:stripped_oak_log
fill 415 86 305 415 89 305 minecraft:red_terracotta
setblock 416 86 278 minecraft:stripped_oak_log
fill 416 86 279 416 89 279 minecraft:red_terracotta
setblock 416 86 283 minecraft:stripped_oak_log
fill 416 86 284 416 89 284 minecraft:red_terracotta
setblock 416 86 288 minecraft:stripped_oak_log
fill 416 86 289 416 89 289 minecraft:red_terracotta
setblock 416 86 293 minecraft:stripped_oak_log
fill 416 86 294 416 89 294 minecraft:red_terracotta
setblock 416 86 298 minecraft:stripped_oak_log
fill 416 86 299 416 89 299 minecraft:red_terracotta
setblock 416 86 303 minecraft:stripped_oak_log
fill 416 86 304 416 89 304 minecraft:red_terracotta
setblock 416 86 308 minecraft:stripped_oak_log
setblock 417 86 277 minecraft:stripped_oak_log
fill 417 86 278 417 89 278 minecraft:red_terracotta
setblock 417 86 282 minecraft:stripped_oak_log
fill 417 86 283 417 89 283 minecraft:red_terracotta
setblock 417 86 287 minecraft:stripped_oak_log
fill 417 86 288 417 89 288 minecraft:red_terracotta
setblock 417 86 292 minecraft:stripped_oak_log
fill 417 86 293 417 89 293 minecraft:red_terracotta
setblock 417 86 297 minecraft:stripped_oak_log
fill 417 86 298 417 89 298 minecraft:red_terracotta
setblock 417 86 302 minecraft:stripped_oak_log
fill 417 86 303 417 89 303 minecraft:red_terracotta
setblock 417 86 307 minecraft:stripped_oak_log
fill 417 86 308 417 89 308 minecraft:red_terracotta
setblock 377 87 276 minecraft:stripped_oak_log
fill 377 87 277 377 90 277 minecraft:red_terracotta
setblock 377 87 281 minecraft:stripped_oak_log
fill 377 87 282 377 90 282 minecraft:red_terracotta
setblock 377 87 286 minecraft:stripped_oak_log
fill 377 87 287 377 90 287 minecraft:red_terracotta
setblock 377 87 291 minecraft:stripped_oak_log
fill 377 87 292 377 90 292 minecraft:red_terracotta
setblock 377 87 297 minecraft:red_terracotta
setblock 377 87 301 minecraft:stripped_oak_log
fill 377 87 302 377 90 302 minecraft:red_terracotta
setblock 377 87 306 minecraft:stripped_oak_log
fill 377 87 307 378 89 307 minecraft:red_terracotta
setblock 377 87 311 minecraft:stripped_oak_log
fill 377 87 312 377 90 312 minecraft:red_terracotta
fill 378 87 276 381 87 276 minecraft:red_terracotta
setblock 378 87 280 minecraft:stripped_oak_log
fill 378 87 281 378 90 281 minecraft:red_terracotta
setblock 378 87 285 minecraft:stripped_oak_log
fill 378 87 286 378 90 286 minecraft:red_terracotta
setblock 378 87 290 minecraft:stripped_oak_log
setblock 378 87 305 minecraft:stripped_oak_log
fill 378 87 306 378 90 306 minecraft:red_terracotta
setblock 379 87 278 minecraft:light[level=15]
setblock 379 87 279 minecraft:stripped_oak_log
fill 379 87 280 379 89 280 minecraft:red_terracotta
setblock 379 87 284 minecraft:stripped_oak_log
fill 379 87 285 379 90 285 minecraft:red_terracotta
fill 379 87 287 379 88 287 minecraft:red_terracotta
setblock 379 87 294 minecraft:light[level=15]
setblock 379 87 302 minecraft:light[level=15]
setblock 379 87 310 minecraft:light[level=15]
setblock 381 87 277 minecraft:stripped_oak_log
setblock 382 87 276 minecraft:stripped_oak_log
setblock 383 87 276 minecraft:red_terracotta
setblock 387 87 278 minecraft:light[level=15]
setblock 387 87 286 minecraft:light[level=15]
setblock 387 87 294 minecraft:light[level=15]
setblock 387 87 302 minecraft:light[level=15]
setblock 387 87 310 minecraft:light[level=15]
setblock 391 87 316 minecraft:red_terracotta
setblock 392 87 276 minecraft:stripped_oak_log
setblock 392 87 316 minecraft:stripped_oak_log
fill 393 87 276 393 90 276 minecraft:red_terracotta
fill 393 87 316 393 90 316 minecraft:red_terracotta
fill 394 87 315 394 90 315 minecraft:red_terracotta
setblock 395 87 278 minecraft:light[level=15]
setblock 395 87 286 minecraft:light[level=15]
setblock 395 87 302 minecraft:light[level=15]
setblock 395 87 310 minecraft:light[level=15]
setblock 397 87 276 minecraft:stripped_oak_log
setblock 397 87 316 minecraft:stripped_oak_log
setblock 398 87 276 minecraft:red_terracotta
fill 398 87 316 398 90 316 minecraft:red_terracotta
fill 400 87 284 400 94 284 minecraft:brown_terracotta
fill 402 87 282 402 94 282 minecraft:brown_terracotta
fill 402 87 284 402 94 284 minecraft:brown_terracotta
setblock 403 87 278 minecraft:light[level=15]
setblock 403 87 286 minecraft:light[level=15]
setblock 403 87 294 minecraft:light[level=15]
setblock 403 87 302 minecraft:light[level=15]
setblock 403 87 310 minecraft:light[level=15]
setblock 411 87 278 minecraft:light[level=15]
setblock 411 87 286 minecraft:light[level=15]
setblock 411 87 294 minecraft:light[level=15]
setblock 411 87 302 minecraft:light[level=15]
setblock 411 87 310 minecraft:light[level=15]
fill 415 87 276 415 88 276 minecraft:red_terracotta
fill 415 87 281 415 87 282 minecraft:red_terracotta
setblock 415 87 283 minecraft:stripped_oak_log
fill 415 87 284 415 90 284 minecraft:red_terracotta
setblock 415 87 288 minecraft:stripped_oak_log
fill 415 87 289 415 90 289 minecraft:red_terracotta
setblock 415 87 303 minecraft:stripped_oak_log
fill 415 87 304 415 90 304 minecraft:red_terracotta
fill 415 87 306 415 88 306 minecraft:red_terracotta
fill 416 87 278 416 90 278 minecraft:red_terracotta
setblock 416 87 282 minecraft:stripped_oak_log
fill 416 87 283 416 90 283 minecraft:red_terracotta
setblock 416 87 287 minecraft:stripped_oak_log
fill 416 87 288 416 90 288 minecraft:red_terracotta
fill 416 87 290 416 87 291 minecraft:red_terracotta
setblock 416 87 292 minecraft:stripped_oak_log
fill 416 87 293 416 90 293 minecraft:red_terracotta
setblock 416 87 297 minecraft:stripped_oak_log
fill 416 87 298 416 90 298 minecraft:red_terracotta
setblock 416 87 302 minecraft:stripped_oak_log
fill 416 87 303 416 90 303 minecraft:red_terracotta
setblock 416 87 307 minecraft:stripped_oak_log
fill 416 87 308 416 89 309 minecraft:red_terracotta
setblock 417 87 276 minecraft:stripped_oak_log
fill 417 87 277 417 90 277 minecraft:red_terracotta
setblock 417 87 281 minecraft:stripped_oak_log
fill 417 87 282 417 90 282 minecraft:red_terracotta
setblock 417 87 286 minecraft:stripped_oak_log
fill 417 87 287 417 90 287 minecraft:red_terracotta
setblock 417 87 291 minecraft:stripped_oak_log
schedule function dropper:buildpart/68_2 1t
