setblock 48 217 611 minecraft:sea_lantern
setblock 48 217 613 minecraft:sea_lantern
setblock 48 217 615 minecraft:sea_lantern
setblock 48 217 617 minecraft:sea_lantern
setblock 48 217 619 minecraft:sea_lantern
setblock 48 217 621 minecraft:sea_lantern
setblock 49 217 604 minecraft:sea_lantern
setblock 49 217 606 minecraft:sea_lantern
setblock 49 217 608 minecraft:sea_lantern
setblock 49 217 610 minecraft:sea_lantern
setblock 49 217 612 minecraft:sea_lantern
setblock 49 217 614 minecraft:sea_lantern
setblock 49 217 616 minecraft:sea_lantern
setblock 49 217 618 minecraft:sea_lantern
setblock 49 217 620 minecraft:sea_lantern
setblock 49 217 622 minecraft:sea_lantern
setblock 50 217 605 minecraft:sea_lantern
setblock 50 217 607 minecraft:sea_lantern
setblock 50 217 609 minecraft:sea_lantern
setblock 50 217 611 minecraft:sea_lantern
setblock 50 217 613 minecraft:sea_lantern
setblock 50 217 615 minecraft:sea_lantern
setblock 50 217 617 minecraft:sea_lantern
setblock 50 217 619 minecraft:sea_lantern
setblock 50 217 621 minecraft:sea_lantern
setblock 51 217 604 minecraft:sea_lantern
setblock 51 217 606 minecraft:sea_lantern
setblock 51 217 608 minecraft:sea_lantern
setblock 51 217 610 minecraft:sea_lantern
setblock 51 217 612 minecraft:sea_lantern
setblock 51 217 614 minecraft:sea_lantern
setblock 51 217 616 minecraft:sea_lantern
setblock 51 217 618 minecraft:sea_lantern
setblock 51 217 620 minecraft:sea_lantern
setblock 51 217 622 minecraft:sea_lantern
setblock 52 217 605 minecraft:sea_lantern
setblock 52 217 607 minecraft:sea_lantern
setblock 52 217 609 minecraft:sea_lantern
setblock 52 217 611 minecraft:sea_lantern
setblock 52 217 613 minecraft:sea_lantern
setblock 52 217 615 minecraft:sea_lantern
setblock 52 217 617 minecraft:sea_lantern
setblock 52 217 619 minecraft:sea_lantern
setblock 52 217 621 minecraft:sea_lantern
setblock 53 217 606 minecraft:sea_lantern
setblock 53 217 608 minecraft:sea_lantern
setblock 53 217 612 minecraft:sea_lantern
setblock 53 217 614 minecraft:sea_lantern
setblock 53 217 616 minecraft:sea_lantern
setblock 53 217 618 minecraft:sea_lantern
setblock 53 217 620 minecraft:sea_lantern
setblock 53 217 622 minecraft:sea_lantern
setblock 54 217 605 minecraft:sea_lantern
setblock 54 217 607 minecraft:sea_lantern
setblock 54 217 609 minecraft:sea_lantern
setblock 54 217 613 minecraft:sea_lantern
setblock 54 217 615 minecraft:sea_lantern
setblock 54 217 617 minecraft:sea_lantern
setblock 54 217 619 minecraft:sea_lantern
setblock 54 217 621 minecraft:sea_lantern
setblock 55 217 606 minecraft:sea_lantern
setblock 55 217 608 minecraft:sea_lantern
setblock 55 217 612 minecraft:sea_lantern
setblock 55 217 614 minecraft:sea_lantern
setblock 55 217 616 minecraft:sea_lantern
setblock 55 217 618 minecraft:sea_lantern
setblock 55 217 620 minecraft:sea_lantern
setblock 55 217 622 minecraft:sea_lantern
setblock 56 217 605 minecraft:sea_lantern
setblock 56 217 607 minecraft:sea_lantern
setblock 56 217 609 minecraft:sea_lantern
setblock 57 217 606 minecraft:sea_lantern
setblock 57 217 608 minecraft:sea_lantern
setblock 58 217 605 minecraft:sea_lantern
setblock 58 217 607 minecraft:sea_lantern
setblock 58 217 609 minecraft:sea_lantern
setblock 59 217 606 minecraft:sea_lantern
setblock 59 217 608 minecraft:sea_lantern
setblock 60 217 605 minecraft:sea_lantern
setblock 60 217 607 minecraft:sea_lantern
setblock 60 217 609 minecraft:sea_lantern
setblock 61 217 606 minecraft:sea_lantern
setblock 61 217 608 minecraft:sea_lantern
setblock 78 217 619 minecraft:sea_lantern
setblock 78 217 621 minecraft:sea_lantern
setblock 78 217 623 minecraft:sea_lantern
setblock 78 217 625 minecraft:sea_lantern
setblock 78 217 627 minecraft:sea_lantern
setblock 78 217 629 minecraft:sea_lantern
setblock 79 217 620 minecraft:sea_lantern
setblock 79 217 622 minecraft:sea_lantern
setblock 79 217 624 minecraft:sea_lantern
setblock 79 217 626 minecraft:sea_lantern
setblock 79 217 628 minecraft:sea_lantern
setblock 80 217 619 minecraft:sea_lantern
setblock 80 217 621 minecraft:sea_lantern
setblock 80 217 623 minecraft:sea_lantern
setblock 80 217 625 minecraft:sea_lantern
setblock 80 217 627 minecraft:sea_lantern
setblock 80 217 629 minecraft:sea_lantern
setblock 81 217 620 minecraft:sea_lantern
setblock 81 217 622 minecraft:sea_lantern
setblock 81 217 624 minecraft:sea_lantern
setblock 81 217 626 minecraft:sea_lantern
setblock 81 217 628 minecraft:sea_lantern
setblock 82 217 619 minecraft:sea_lantern
setblock 82 217 621 minecraft:sea_lantern
setblock 82 217 623 minecraft:sea_lantern
setblock 82 217 625 minecraft:sea_lantern
setblock 82 217 627 minecraft:sea_lantern
setblock 82 217 629 minecraft:sea_lantern
setblock 83 217 620 minecraft:sea_lantern
setblock 83 217 622 minecraft:sea_lantern
setblock 83 217 624 minecraft:sea_lantern
setblock 83 217 626 minecraft:sea_lantern
setblock 83 217 628 minecraft:sea_lantern
setblock 84 217 619 minecraft:sea_lantern
setblock 84 217 621 minecraft:sea_lantern
setblock 84 217 623 minecraft:sea_lantern
setblock 84 217 625 minecraft:sea_lantern
setblock 84 217 627 minecraft:sea_lantern
setblock 84 217 629 minecraft:sea_lantern
setblock 85 217 620 minecraft:sea_lantern
setblock 85 217 622 minecraft:sea_lantern
setblock 85 217 624 minecraft:sea_lantern
setblock 85 217 626 minecraft:sea_lantern
setblock 85 217 628 minecraft:sea_lantern
setblock 86 217 619 minecraft:sea_lantern
setblock 86 217 621 minecraft:sea_lantern
setblock 86 217 623 minecraft:sea_lantern
setblock 86 217 625 minecraft:sea_lantern
setblock 86 217 627 minecraft:sea_lantern
setblock 86 217 629 minecraft:sea_lantern
setblock 87 217 620 minecraft:sea_lantern
setblock 87 217 622 minecraft:sea_lantern
setblock 87 217 624 minecraft:sea_lantern
setblock 87 217 626 minecraft:sea_lantern
setblock 87 217 628 minecraft:sea_lantern
setblock 88 217 619 minecraft:sea_lantern
setblock 88 217 621 minecraft:sea_lantern
setblock 88 217 623 minecraft:sea_lantern
setblock 88 217 625 minecraft:sea_lantern
setblock 88 217 627 minecraft:sea_lantern
setblock 88 217 629 minecraft:sea_lantern
fill 48 218 605 48 219 605 minecraft:light_gray_concrete
fill 48 218 607 48 219 607 minecraft:light_gray_concrete
fill 48 218 609 48 219 609 minecraft:light_gray_concrete
fill 48 218 611 48 219 611 minecraft:light_gray_concrete
fill 48 218 613 48 219 613 minecraft:light_gray_concrete
fill 48 218 615 48 219 615 minecraft:light_gray_concrete
fill 48 218 617 48 219 617 minecraft:light_gray_concrete
fill 48 218 619 48 219 619 minecraft:light_gray_concrete
fill 48 218 621 48 219 621 minecraft:light_gray_concrete
fill 49 218 604 49 219 604 minecraft:gray_concrete
fill 49 218 606 49 219 606 minecraft:light_gray_concrete
fill 49 218 608 49 219 608 minecraft:light_gray_concrete
fill 49 218 610 49 219 610 minecraft:light_gray_concrete
fill 49 218 612 49 219 612 minecraft:light_gray_concrete
fill 49 218 614 49 219 614 minecraft:light_gray_concrete
fill 49 218 616 49 219 616 minecraft:light_gray_concrete
fill 49 218 618 49 219 618 minecraft:light_gray_concrete
fill 49 218 620 49 219 620 minecraft:light_gray_concrete
fill 49 218 622 49 219 622 minecraft:light_gray_concrete
fill 50 218 605 50 219 605 minecraft:light_gray_concrete
fill 50 218 607 50 219 607 minecraft:light_gray_concrete
fill 50 218 609 50 219 609 minecraft:light_gray_concrete
fill 50 218 611 50 219 611 minecraft:light_gray_concrete
fill 50 218 613 50 219 613 minecraft:light_gray_concrete
fill 50 218 615 50 219 615 minecraft:light_gray_concrete
fill 50 218 617 50 219 617 minecraft:light_gray_concrete
fill 50 218 619 50 219 619 minecraft:light_gray_concrete
fill 50 218 621 50 219 621 minecraft:light_gray_concrete
fill 51 218 604 51 219 604 minecraft:gray_concrete
fill 51 218 606 51 219 606 minecraft:light_gray_concrete
fill 51 218 608 51 219 608 minecraft:light_gray_concrete
fill 51 218 610 51 219 610 minecraft:light_gray_concrete
fill 51 218 612 51 219 612 minecraft:light_gray_concrete
fill 51 218 614 51 219 614 minecraft:light_gray_concrete
fill 51 218 616 51 219 616 minecraft:light_gray_concrete
fill 51 218 618 51 219 618 minecraft:light_gray_concrete
fill 51 218 620 51 219 620 minecraft:light_gray_concrete
fill 51 218 622 51 219 622 minecraft:light_gray_concrete
fill 52 218 605 52 219 605 minecraft:light_gray_concrete
fill 52 218 607 52 219 607 minecraft:light_gray_concrete
fill 52 218 609 52 219 609 minecraft:light_gray_concrete
fill 52 218 611 52 219 611 minecraft:light_gray_concrete
fill 52 218 613 52 219 613 minecraft:light_gray_concrete
fill 52 218 615 52 219 615 minecraft:light_gray_concrete
fill 52 218 617 52 219 617 minecraft:light_gray_concrete
fill 52 218 619 52 219 619 minecraft:light_gray_concrete
fill 52 218 621 52 219 621 minecraft:light_gray_concrete
fill 53 218 606 53 219 606 minecraft:light_gray_concrete
fill 53 218 608 53 219 608 minecraft:light_gray_concrete
fill 53 218 612 53 219 612 minecraft:light_gray_concrete
fill 53 218 614 53 219 614 minecraft:light_gray_concrete
fill 53 218 616 53 219 616 minecraft:light_gray_concrete
fill 53 218 618 53 219 618 minecraft:light_gray_concrete
fill 53 218 620 53 219 620 minecraft:light_gray_concrete
fill 53 218 622 53 219 622 minecraft:light_gray_concrete
fill 54 218 605 54 219 605 minecraft:light_gray_concrete
fill 54 218 607 54 219 607 minecraft:light_gray_concrete
fill 54 218 609 54 219 609 minecraft:light_gray_concrete
fill 54 218 613 54 219 613 minecraft:light_gray_concrete
fill 54 218 615 54 219 615 minecraft:light_gray_concrete
fill 54 218 617 54 219 617 minecraft:light_gray_concrete
fill 54 218 619 54 219 619 minecraft:light_gray_concrete
fill 54 218 621 54 219 621 minecraft:light_gray_concrete
fill 55 218 606 55 219 606 minecraft:light_gray_concrete
fill 55 218 608 55 219 608 minecraft:light_gray_concrete
fill 55 218 612 55 219 612 minecraft:light_gray_concrete
fill 55 218 614 55 219 614 minecraft:light_gray_concrete
fill 55 218 616 55 219 616 minecraft:light_gray_concrete
fill 55 218 618 55 219 618 minecraft:light_gray_concrete
fill 55 218 620 55 219 620 minecraft:light_gray_concrete
fill 55 218 622 55 219 622 minecraft:light_gray_concrete
fill 56 218 605 56 219 605 minecraft:light_gray_concrete
fill 56 218 607 56 219 607 minecraft:light_gray_concrete
fill 56 218 609 56 219 609 minecraft:light_gray_concrete
fill 57 218 606 57 219 606 minecraft:light_gray_concrete
fill 57 218 608 57 219 608 minecraft:light_gray_concrete
fill 58 218 605 58 219 605 minecraft:light_gray_concrete
fill 58 218 607 58 219 607 minecraft:light_gray_concrete
fill 58 218 609 58 219 609 minecraft:light_gray_concrete
fill 59 218 606 59 219 606 minecraft:light_gray_concrete
fill 59 218 608 59 219 608 minecraft:light_gray_concrete
fill 60 218 605 60 219 605 minecraft:light_gray_concrete
fill 60 218 607 60 219 607 minecraft:light_gray_concrete
fill 60 218 609 60 219 609 minecraft:light_gray_concrete
fill 61 218 606 61 219 606 minecraft:light_gray_concrete
fill 61 218 608 61 219 608 minecraft:light_gray_concrete
fill 78 218 619 78 219 619 minecraft:light_gray_concrete
fill 78 218 621 78 219 621 minecraft:light_gray_concrete
fill 78 218 623 78 219 623 minecraft:light_gray_concrete
fill 78 218 625 78 219 625 minecraft:light_gray_concrete
fill 78 218 627 78 219 627 minecraft:light_gray_concrete
fill 78 218 629 78 219 629 minecraft:light_gray_concrete
fill 79 218 620 79 219 620 minecraft:light_gray_concrete
fill 79 218 622 79 219 622 minecraft:light_gray_concrete
fill 79 218 624 79 219 624 minecraft:light_gray_concrete
fill 79 218 626 79 219 626 minecraft:light_gray_concrete
fill 79 218 628 79 219 628 minecraft:light_gray_concrete
fill 80 218 619 80 219 619 minecraft:light_gray_concrete
fill 80 218 621 80 219 621 minecraft:light_gray_concrete
fill 80 218 623 80 219 623 minecraft:light_gray_concrete
fill 80 218 625 80 219 625 minecraft:light_gray_concrete
fill 80 218 627 80 219 627 minecraft:light_gray_concrete
fill 80 218 629 80 219 629 minecraft:light_gray_concrete
fill 81 218 620 81 219 620 minecraft:light_gray_concrete
fill 81 218 622 81 219 622 minecraft:light_gray_concrete
fill 81 218 624 81 219 624 minecraft:light_gray_concrete
fill 81 218 626 81 219 626 minecraft:light_gray_concrete
fill 81 218 628 81 219 628 minecraft:light_gray_concrete
fill 82 218 619 82 219 619 minecraft:light_gray_concrete
fill 82 218 621 82 219 621 minecraft:light_gray_concrete
fill 82 218 623 82 219 623 minecraft:light_gray_concrete
fill 82 218 625 82 219 625 minecraft:light_gray_concrete
fill 82 218 627 82 219 627 minecraft:light_gray_concrete
fill 82 218 629 82 219 629 minecraft:light_gray_concrete
fill 83 218 620 83 219 620 minecraft:light_gray_concrete
fill 83 218 622 83 219 622 minecraft:light_gray_concrete
fill 83 218 624 83 219 624 minecraft:light_gray_concrete
fill 83 218 626 83 219 626 minecraft:light_gray_concrete
fill 83 218 628 83 219 628 minecraft:light_gray_concrete
fill 84 218 619 84 219 619 minecraft:light_gray_concrete
fill 84 218 621 84 219 621 minecraft:light_gray_concrete
fill 84 218 623 84 219 623 minecraft:light_gray_concrete
fill 84 218 625 84 219 625 minecraft:light_gray_concrete
fill 84 218 627 84 219 627 minecraft:light_gray_concrete
fill 84 218 629 84 219 629 minecraft:light_gray_concrete
fill 85 218 620 85 219 620 minecraft:light_gray_concrete
fill 85 218 622 85 219 622 minecraft:light_gray_concrete
fill 85 218 624 85 219 624 minecraft:light_gray_concrete
fill 85 218 626 85 219 626 minecraft:light_gray_concrete
fill 85 218 628 85 219 628 minecraft:light_gray_concrete
fill 86 218 619 86 219 619 minecraft:light_gray_concrete
fill 86 218 621 86 219 621 minecraft:light_gray_concrete
fill 86 218 623 86 219 623 minecraft:light_gray_concrete
fill 86 218 625 86 219 625 minecraft:light_gray_concrete
fill 86 218 627 86 219 627 minecraft:light_gray_concrete
fill 86 218 629 86 219 629 minecraft:light_gray_concrete
fill 87 218 620 87 219 620 minecraft:light_gray_concrete
fill 87 218 622 87 219 622 minecraft:light_gray_concrete
fill 87 218 624 87 219 624 minecraft:light_gray_concrete
fill 87 218 626 87 219 626 minecraft:light_gray_concrete
fill 87 218 628 87 219 628 minecraft:light_gray_concrete
fill 88 218 619 88 219 619 minecraft:light_gray_concrete
fill 88 218 621 88 219 621 minecraft:light_gray_concrete
fill 88 218 623 88 219 623 minecraft:light_gray_concrete
fill 88 218 625 88 219 625 minecraft:light_gray_concrete
fill 88 218 627 88 219 627 minecraft:light_gray_concrete
fill 88 218 629 88 219 629 minecraft:light_gray_concrete
fill 47 220 609 47 241 609 minecraft:gray_concrete
fill 47 220 617 47 241 617 minecraft:gray_concrete
fill 47 220 625 47 241 625 minecraft:gray_concrete
fill 47 220 633 47 241 633 minecraft:gray_concrete
fill 47 220 641 47 241 641 minecraft:gray_concrete
setblock 48 220 605 minecraft:sea_lantern
setblock 48 220 607 minecraft:sea_lantern
setblock 48 220 609 minecraft:sea_lantern
setblock 48 220 611 minecraft:sea_lantern
setblock 48 220 613 minecraft:sea_lantern
setblock 48 220 615 minecraft:sea_lantern
setblock 48 220 617 minecraft:sea_lantern
setblock 48 220 619 minecraft:sea_lantern
setblock 48 220 621 minecraft:sea_lantern
setblock 49 220 604 minecraft:sea_lantern
setblock 49 220 606 minecraft:sea_lantern
setblock 49 220 608 minecraft:sea_lantern
setblock 49 220 610 minecraft:sea_lantern
setblock 49 220 612 minecraft:sea_lantern
setblock 49 220 614 minecraft:sea_lantern
setblock 49 220 616 minecraft:sea_lantern
setblock 49 220 618 minecraft:sea_lantern
setblock 49 220 620 minecraft:sea_lantern
setblock 49 220 622 minecraft:sea_lantern
setblock 50 220 605 minecraft:sea_lantern
setblock 50 220 607 minecraft:sea_lantern
setblock 50 220 609 minecraft:sea_lantern
setblock 50 220 611 minecraft:sea_lantern
setblock 50 220 613 minecraft:sea_lantern
setblock 50 220 615 minecraft:sea_lantern
setblock 50 220 617 minecraft:sea_lantern
setblock 50 220 619 minecraft:sea_lantern
setblock 50 220 621 minecraft:sea_lantern
fill 50 220 646 50 241 646 minecraft:gray_concrete
setblock 51 220 604 minecraft:sea_lantern
setblock 51 220 606 minecraft:sea_lantern
setblock 51 220 608 minecraft:sea_lantern
setblock 51 220 610 minecraft:sea_lantern
setblock 51 220 612 minecraft:sea_lantern
setblock 51 220 614 minecraft:sea_lantern
setblock 51 220 616 minecraft:sea_lantern
setblock 51 220 618 minecraft:sea_lantern
setblock 51 220 620 minecraft:sea_lantern
setblock 51 220 622 minecraft:sea_lantern
setblock 52 220 605 minecraft:sea_lantern
setblock 52 220 607 minecraft:sea_lantern
setblock 52 220 609 minecraft:sea_lantern
setblock 52 220 611 minecraft:sea_lantern
setblock 52 220 613 minecraft:sea_lantern
setblock 52 220 615 minecraft:sea_lantern
setblock 52 220 617 minecraft:sea_lantern
setblock 52 220 619 minecraft:sea_lantern
setblock 52 220 621 minecraft:sea_lantern
setblock 53 220 606 minecraft:sea_lantern
setblock 53 220 608 minecraft:sea_lantern
setblock 53 220 612 minecraft:sea_lantern
setblock 53 220 614 minecraft:sea_lantern
setblock 53 220 616 minecraft:sea_lantern
setblock 53 220 618 minecraft:sea_lantern
setblock 53 220 620 minecraft:sea_lantern
setblock 53 220 622 minecraft:sea_lantern
fill 54 220 604 54 241 604 minecraft:gray_concrete
setblock 54 220 605 minecraft:sea_lantern
setblock 54 220 607 minecraft:sea_lantern
setblock 54 220 609 minecraft:sea_lantern
setblock 54 220 613 minecraft:sea_lantern
setblock 54 220 615 minecraft:sea_lantern
setblock 54 220 617 minecraft:sea_lantern
setblock 54 220 619 minecraft:sea_lantern
setblock 54 220 621 minecraft:sea_lantern
setblock 55 220 606 minecraft:sea_lantern
setblock 55 220 608 minecraft:sea_lantern
setblock 55 220 612 minecraft:sea_lantern
setblock 55 220 614 minecraft:sea_lantern
setblock 55 220 616 minecraft:sea_lantern
setblock 55 220 618 minecraft:sea_lantern
setblock 55 220 620 minecraft:sea_lantern
setblock 55 220 622 minecraft:sea_lantern
setblock 56 220 605 minecraft:sea_lantern
setblock 56 220 607 minecraft:sea_lantern
setblock 56 220 609 minecraft:sea_lantern
setblock 57 220 606 minecraft:sea_lantern
setblock 57 220 608 minecraft:sea_lantern
setblock 58 220 605 minecraft:sea_lantern
setblock 58 220 607 minecraft:sea_lantern
setblock 58 220 609 minecraft:sea_lantern
fill 58 220 646 58 241 646 minecraft:gray_concrete
setblock 59 220 606 minecraft:sea_lantern
setblock 59 220 608 minecraft:sea_lantern
setblock 60 220 605 minecraft:sea_lantern
setblock 60 220 607 minecraft:sea_lantern
setblock 60 220 609 minecraft:sea_lantern
setblock 61 220 606 minecraft:sea_lantern
setblock 61 220 608 minecraft:sea_lantern
fill 62 220 604 62 241 604 minecraft:gray_concrete
fill 66 220 646 66 241 646 minecraft:gray_concrete
fill 70 220 604 70 241 604 minecraft:gray_concrete
fill 74 220 646 74 241 646 minecraft:gray_concrete
fill 78 220 604 78 241 604 minecraft:gray_concrete
setblock 78 220 619 minecraft:sea_lantern
setblock 78 220 621 minecraft:sea_lantern
setblock 78 220 623 minecraft:sea_lantern
setblock 78 220 625 minecraft:sea_lantern
setblock 78 220 627 minecraft:sea_lantern
setblock 78 220 629 minecraft:sea_lantern
setblock 79 220 620 minecraft:sea_lantern
setblock 79 220 622 minecraft:sea_lantern
setblock 79 220 624 minecraft:sea_lantern
setblock 79 220 626 minecraft:sea_lantern
setblock 79 220 628 minecraft:sea_lantern
fill 79 220 639 79 221 639 minecraft:glass
setblock 80 220 619 minecraft:sea_lantern
setblock 80 220 621 minecraft:sea_lantern
setblock 80 220 623 minecraft:sea_lantern
setblock 80 220 625 minecraft:sea_lantern
setblock 80 220 627 minecraft:sea_lantern
setblock 80 220 629 minecraft:sea_lantern
setblock 81 220 620 minecraft:sea_lantern
setblock 81 220 622 minecraft:sea_lantern
setblock 81 220 624 minecraft:sea_lantern
setblock 81 220 626 minecraft:sea_lantern
setblock 81 220 628 minecraft:sea_lantern
setblock 82 220 619 minecraft:sea_lantern
setblock 82 220 621 minecraft:sea_lantern
setblock 82 220 623 minecraft:sea_lantern
setblock 82 220 625 minecraft:sea_lantern
setblock 82 220 627 minecraft:sea_lantern
setblock 82 220 629 minecraft:sea_lantern
fill 82 220 646 82 241 646 minecraft:gray_concrete
setblock 83 220 620 minecraft:sea_lantern
setblock 83 220 622 minecraft:sea_lantern
setblock 83 220 624 minecraft:sea_lantern
setblock 83 220 626 minecraft:sea_lantern
setblock 83 220 628 minecraft:sea_lantern
setblock 84 220 619 minecraft:sea_lantern
setblock 84 220 621 minecraft:sea_lantern
setblock 84 220 623 minecraft:sea_lantern
setblock 84 220 625 minecraft:sea_lantern
setblock 84 220 627 minecraft:sea_lantern
setblock 84 220 629 minecraft:sea_lantern
setblock 85 220 620 minecraft:sea_lantern
setblock 85 220 622 minecraft:sea_lantern
setblock 85 220 624 minecraft:sea_lantern
setblock 85 220 626 minecraft:sea_lantern
setblock 85 220 628 minecraft:sea_lantern
fill 86 220 604 86 241 604 minecraft:gray_concrete
setblock 86 220 619 minecraft:sea_lantern
setblock 86 220 621 minecraft:sea_lantern
setblock 86 220 623 minecraft:sea_lantern
setblock 86 220 625 minecraft:sea_lantern
setblock 86 220 627 minecraft:sea_lantern
setblock 86 220 629 minecraft:sea_lantern
setblock 87 220 620 minecraft:sea_lantern
setblock 87 220 622 minecraft:sea_lantern
setblock 87 220 624 minecraft:sea_lantern
setblock 87 220 626 minecraft:sea_lantern
setblock 87 220 628 minecraft:sea_lantern
setblock 88 220 619 minecraft:sea_lantern
setblock 88 220 621 minecraft:sea_lantern
setblock 88 220 623 minecraft:sea_lantern
setblock 88 220 625 minecraft:sea_lantern
setblock 88 220 627 minecraft:sea_lantern
setblock 88 220 629 minecraft:sea_lantern
fill 89 220 609 89 241 609 minecraft:gray_concrete
fill 89 220 617 89 241 617 minecraft:gray_concrete
fill 89 220 625 89 241 625 minecraft:gray_concrete
fill 89 220 633 89 241 633 minecraft:gray_concrete
fill 89 220 641 89 241 641 minecraft:gray_concrete
fill 48 221 605 48 222 605 minecraft:light_gray_concrete
fill 48 221 607 48 222 607 minecraft:light_gray_concrete
fill 48 221 609 48 222 609 minecraft:light_gray_concrete
fill 48 221 611 48 222 611 minecraft:light_gray_concrete
fill 48 221 613 48 222 613 minecraft:light_gray_concrete
fill 48 221 615 48 222 615 minecraft:light_gray_concrete
fill 48 221 617 48 222 617 minecraft:light_gray_concrete
fill 48 221 619 48 222 619 minecraft:light_gray_concrete
fill 48 221 621 48 222 621 minecraft:light_gray_concrete
fill 49 221 604 49 222 604 minecraft:gray_concrete
fill 49 221 606 49 222 606 minecraft:light_gray_concrete
fill 49 221 608 49 222 608 minecraft:light_gray_concrete
fill 49 221 610 49 222 610 minecraft:light_gray_concrete
fill 49 221 612 49 222 612 minecraft:light_gray_concrete
fill 49 221 614 49 222 614 minecraft:light_gray_concrete
fill 49 221 616 49 222 616 minecraft:light_gray_concrete
fill 49 221 618 49 222 618 minecraft:light_gray_concrete
fill 49 221 620 49 222 620 minecraft:light_gray_concrete
fill 49 221 622 49 222 622 minecraft:light_gray_concrete
fill 50 221 605 50 222 605 minecraft:light_gray_concrete
fill 50 221 607 50 222 607 minecraft:light_gray_concrete
fill 50 221 609 50 222 609 minecraft:light_gray_concrete
fill 50 221 611 50 222 611 minecraft:light_gray_concrete
fill 50 221 613 50 222 613 minecraft:light_gray_concrete
fill 50 221 615 50 222 615 minecraft:light_gray_concrete
fill 50 221 617 50 222 617 minecraft:light_gray_concrete
fill 50 221 619 50 222 619 minecraft:light_gray_concrete
fill 50 221 621 50 222 621 minecraft:light_gray_concrete
fill 51 221 604 51 222 604 minecraft:gray_concrete
fill 51 221 606 51 222 606 minecraft:light_gray_concrete
fill 51 221 608 51 222 608 minecraft:light_gray_concrete
fill 51 221 610 51 222 610 minecraft:light_gray_concrete
fill 51 221 612 51 222 612 minecraft:light_gray_concrete
fill 51 221 614 51 222 614 minecraft:light_gray_concrete
fill 51 221 616 51 222 616 minecraft:light_gray_concrete
fill 51 221 618 51 222 618 minecraft:light_gray_concrete
fill 51 221 620 51 222 620 minecraft:light_gray_concrete
fill 51 221 622 51 222 622 minecraft:light_gray_concrete
fill 52 221 605 52 222 605 minecraft:light_gray_concrete
fill 52 221 607 52 222 607 minecraft:light_gray_concrete
fill 52 221 609 52 222 609 minecraft:light_gray_concrete
fill 52 221 611 52 222 611 minecraft:light_gray_concrete
fill 52 221 613 52 222 613 minecraft:light_gray_concrete
fill 52 221 615 52 222 615 minecraft:light_gray_concrete
fill 52 221 617 52 222 617 minecraft:light_gray_concrete
fill 52 221 619 52 222 619 minecraft:light_gray_concrete
fill 52 221 621 52 222 621 minecraft:light_gray_concrete
fill 53 221 606 53 222 606 minecraft:light_gray_concrete
fill 53 221 608 53 222 608 minecraft:light_gray_concrete
fill 53 221 612 53 222 612 minecraft:light_gray_concrete
fill 53 221 614 53 222 614 minecraft:light_gray_concrete
fill 53 221 616 53 222 616 minecraft:light_gray_concrete
fill 53 221 618 53 222 618 minecraft:light_gray_concrete
fill 53 221 620 53 222 620 minecraft:light_gray_concrete
fill 53 221 622 53 222 622 minecraft:light_gray_concrete
fill 54 221 605 54 222 605 minecraft:light_gray_concrete
fill 54 221 607 54 222 607 minecraft:light_gray_concrete
fill 54 221 609 54 222 609 minecraft:light_gray_concrete
fill 54 221 613 54 222 613 minecraft:light_gray_concrete
fill 54 221 615 54 222 615 minecraft:light_gray_concrete
fill 54 221 617 54 222 617 minecraft:light_gray_concrete
fill 54 221 619 54 222 619 minecraft:light_gray_concrete
fill 54 221 621 54 222 621 minecraft:light_gray_concrete
fill 55 221 606 55 222 606 minecraft:light_gray_concrete
fill 55 221 608 55 222 608 minecraft:light_gray_concrete
fill 55 221 612 55 222 612 minecraft:light_gray_concrete
fill 55 221 614 55 222 614 minecraft:light_gray_concrete
fill 55 221 616 55 222 616 minecraft:light_gray_concrete
fill 55 221 618 55 222 618 minecraft:light_gray_concrete
fill 55 221 620 55 222 620 minecraft:light_gray_concrete
fill 55 221 622 55 222 622 minecraft:light_gray_concrete
fill 56 221 605 56 222 605 minecraft:light_gray_concrete
fill 56 221 607 56 222 607 minecraft:light_gray_concrete
fill 56 221 609 56 222 609 minecraft:light_gray_concrete
fill 57 221 606 57 222 606 minecraft:light_gray_concrete
fill 57 221 608 57 222 608 minecraft:light_gray_concrete
fill 58 221 605 58 222 605 minecraft:light_gray_concrete
fill 58 221 607 58 222 607 minecraft:light_gray_concrete
fill 58 221 609 58 222 609 minecraft:light_gray_concrete
fill 59 221 606 59 222 606 minecraft:light_gray_concrete
fill 59 221 608 59 222 608 minecraft:light_gray_concrete
fill 60 221 605 60 222 605 minecraft:light_gray_concrete
fill 60 221 607 60 222 607 minecraft:light_gray_concrete
fill 60 221 609 60 222 609 minecraft:light_gray_concrete
fill 61 221 606 61 222 606 minecraft:light_gray_concrete
fill 61 221 608 61 222 608 minecraft:light_gray_concrete
fill 78 221 619 78 222 619 minecraft:light_gray_concrete
fill 78 221 621 78 222 621 minecraft:light_gray_concrete
fill 78 221 623 78 222 623 minecraft:light_gray_concrete
fill 78 221 625 78 222 625 minecraft:light_gray_concrete
fill 78 221 627 78 222 627 minecraft:light_gray_concrete
fill 78 221 629 78 222 629 minecraft:light_gray_concrete
fill 79 221 620 79 222 620 minecraft:light_gray_concrete
fill 79 221 622 79 222 622 minecraft:light_gray_concrete
fill 79 221 624 79 222 624 minecraft:light_gray_concrete
fill 79 221 626 79 222 626 minecraft:light_gray_concrete
fill 79 221 628 79 222 628 minecraft:light_gray_concrete
fill 80 221 619 80 222 619 minecraft:light_gray_concrete
fill 80 221 621 80 222 621 minecraft:light_gray_concrete
fill 80 221 623 80 222 623 minecraft:light_gray_concrete
fill 80 221 625 80 222 625 minecraft:light_gray_concrete
fill 80 221 627 80 222 627 minecraft:light_gray_concrete
fill 80 221 629 80 222 629 minecraft:light_gray_concrete
fill 81 221 620 81 222 620 minecraft:light_gray_concrete
fill 81 221 622 81 222 622 minecraft:light_gray_concrete
fill 81 221 624 81 222 624 minecraft:light_gray_concrete
fill 81 221 626 81 222 626 minecraft:light_gray_concrete
fill 81 221 628 81 222 628 minecraft:light_gray_concrete
fill 82 221 619 82 222 619 minecraft:light_gray_concrete
fill 82 221 621 82 222 621 minecraft:light_gray_concrete
fill 82 221 623 82 222 623 minecraft:light_gray_concrete
fill 82 221 625 82 222 625 minecraft:light_gray_concrete
fill 82 221 627 82 222 627 minecraft:light_gray_concrete
fill 82 221 629 82 222 629 minecraft:light_gray_concrete
fill 83 221 620 83 222 620 minecraft:light_gray_concrete
fill 83 221 622 83 222 622 minecraft:light_gray_concrete
fill 83 221 624 83 222 624 minecraft:light_gray_concrete
fill 83 221 626 83 222 626 minecraft:light_gray_concrete
fill 83 221 628 83 222 628 minecraft:light_gray_concrete
fill 84 221 619 84 222 619 minecraft:light_gray_concrete
fill 84 221 621 84 222 621 minecraft:light_gray_concrete
fill 84 221 623 84 222 623 minecraft:light_gray_concrete
fill 84 221 625 84 222 625 minecraft:light_gray_concrete
fill 84 221 627 84 222 627 minecraft:light_gray_concrete
fill 84 221 629 84 222 629 minecraft:light_gray_concrete
fill 85 221 620 85 222 620 minecraft:light_gray_concrete
fill 85 221 622 85 222 622 minecraft:light_gray_concrete
fill 85 221 624 85 222 624 minecraft:light_gray_concrete
fill 85 221 626 85 222 626 minecraft:light_gray_concrete
fill 85 221 628 85 222 628 minecraft:light_gray_concrete
fill 86 221 619 86 222 619 minecraft:light_gray_concrete
fill 86 221 621 86 222 621 minecraft:light_gray_concrete
fill 86 221 623 86 222 623 minecraft:light_gray_concrete
fill 86 221 625 86 222 625 minecraft:light_gray_concrete
fill 86 221 627 86 222 627 minecraft:light_gray_concrete
fill 86 221 629 86 222 629 minecraft:light_gray_concrete
fill 87 221 620 87 222 620 minecraft:light_gray_concrete
fill 87 221 622 87 222 622 minecraft:light_gray_concrete
fill 87 221 624 87 222 624 minecraft:light_gray_concrete
fill 87 221 626 87 222 626 minecraft:light_gray_concrete
fill 87 221 628 87 222 628 minecraft:light_gray_concrete
fill 88 221 619 88 222 619 minecraft:light_gray_concrete
fill 88 221 621 88 222 621 minecraft:light_gray_concrete
fill 88 221 623 88 222 623 minecraft:light_gray_concrete
fill 88 221 625 88 222 625 minecraft:light_gray_concrete
fill 88 221 627 88 222 627 minecraft:light_gray_concrete
fill 88 221 629 88 222 629 minecraft:light_gray_concrete
setblock 48 223 605 minecraft:sea_lantern
setblock 48 223 607 minecraft:sea_lantern
setblock 48 223 609 minecraft:sea_lantern
setblock 48 223 611 minecraft:sea_lantern
setblock 48 223 613 minecraft:sea_lantern
setblock 48 223 615 minecraft:sea_lantern
setblock 48 223 617 minecraft:sea_lantern
setblock 48 223 619 minecraft:sea_lantern
setblock 48 223 621 minecraft:sea_lantern
setblock 49 223 604 minecraft:sea_lantern
setblock 49 223 606 minecraft:sea_lantern
setblock 49 223 608 minecraft:sea_lantern
setblock 49 223 610 minecraft:sea_lantern
setblock 49 223 612 minecraft:sea_lantern
setblock 49 223 614 minecraft:sea_lantern
setblock 49 223 616 minecraft:sea_lantern
setblock 49 223 618 minecraft:sea_lantern
setblock 49 223 620 minecraft:sea_lantern
setblock 49 223 622 minecraft:sea_lantern
setblock 50 223 605 minecraft:sea_lantern
setblock 50 223 607 minecraft:sea_lantern
setblock 50 223 609 minecraft:sea_lantern
setblock 50 223 611 minecraft:sea_lantern
setblock 50 223 613 minecraft:sea_lantern
setblock 50 223 615 minecraft:sea_lantern
setblock 50 223 617 minecraft:sea_lantern
setblock 50 223 619 minecraft:sea_lantern
setblock 50 223 621 minecraft:sea_lantern
setblock 51 223 604 minecraft:sea_lantern
setblock 51 223 606 minecraft:sea_lantern
setblock 51 223 608 minecraft:sea_lantern
setblock 51 223 610 minecraft:sea_lantern
setblock 51 223 612 minecraft:sea_lantern
setblock 51 223 614 minecraft:sea_lantern
setblock 51 223 616 minecraft:sea_lantern
setblock 51 223 618 minecraft:sea_lantern
setblock 51 223 620 minecraft:sea_lantern
setblock 51 223 622 minecraft:sea_lantern
setblock 52 223 605 minecraft:sea_lantern
setblock 52 223 607 minecraft:sea_lantern
setblock 52 223 609 minecraft:sea_lantern
setblock 52 223 611 minecraft:sea_lantern
setblock 52 223 613 minecraft:sea_lantern
setblock 52 223 615 minecraft:sea_lantern
setblock 52 223 617 minecraft:sea_lantern
setblock 52 223 619 minecraft:sea_lantern
setblock 52 223 621 minecraft:sea_lantern
setblock 53 223 606 minecraft:sea_lantern
setblock 53 223 608 minecraft:sea_lantern
setblock 53 223 612 minecraft:sea_lantern
setblock 53 223 614 minecraft:sea_lantern
setblock 53 223 616 minecraft:sea_lantern
setblock 53 223 618 minecraft:sea_lantern
setblock 53 223 620 minecraft:sea_lantern
setblock 53 223 622 minecraft:sea_lantern
setblock 54 223 605 minecraft:sea_lantern
setblock 54 223 607 minecraft:sea_lantern
setblock 54 223 609 minecraft:sea_lantern
setblock 54 223 613 minecraft:sea_lantern
setblock 54 223 615 minecraft:sea_lantern
setblock 54 223 617 minecraft:sea_lantern
setblock 54 223 619 minecraft:sea_lantern
setblock 54 223 621 minecraft:sea_lantern
setblock 55 223 606 minecraft:sea_lantern
setblock 55 223 608 minecraft:sea_lantern
setblock 55 223 612 minecraft:sea_lantern
setblock 55 223 614 minecraft:sea_lantern
setblock 55 223 616 minecraft:sea_lantern
setblock 55 223 618 minecraft:sea_lantern
setblock 55 223 620 minecraft:sea_lantern
setblock 55 223 622 minecraft:sea_lantern
setblock 56 223 605 minecraft:sea_lantern
setblock 56 223 607 minecraft:sea_lantern
setblock 56 223 609 minecraft:sea_lantern
setblock 57 223 606 minecraft:sea_lantern
setblock 57 223 608 minecraft:sea_lantern
setblock 58 223 605 minecraft:sea_lantern
setblock 58 223 607 minecraft:sea_lantern
setblock 58 223 609 minecraft:sea_lantern
setblock 59 223 606 minecraft:sea_lantern
setblock 59 223 608 minecraft:sea_lantern
setblock 60 223 605 minecraft:sea_lantern
setblock 60 223 607 minecraft:sea_lantern
setblock 60 223 609 minecraft:sea_lantern
setblock 61 223 606 minecraft:sea_lantern
setblock 61 223 608 minecraft:sea_lantern
setblock 78 223 619 minecraft:sea_lantern
setblock 78 223 621 minecraft:sea_lantern
setblock 78 223 623 minecraft:sea_lantern
setblock 78 223 625 minecraft:sea_lantern
setblock 78 223 627 minecraft:sea_lantern
setblock 78 223 629 minecraft:sea_lantern
setblock 79 223 620 minecraft:sea_lantern
setblock 79 223 622 minecraft:sea_lantern
setblock 79 223 624 minecraft:sea_lantern
setblock 79 223 626 minecraft:sea_lantern
setblock 79 223 628 minecraft:sea_lantern
setblock 80 223 619 minecraft:sea_lantern
setblock 80 223 621 minecraft:sea_lantern
setblock 80 223 623 minecraft:sea_lantern
setblock 80 223 625 minecraft:sea_lantern
setblock 80 223 627 minecraft:sea_lantern
setblock 80 223 629 minecraft:sea_lantern
setblock 81 223 620 minecraft:sea_lantern
setblock 81 223 622 minecraft:sea_lantern
setblock 81 223 624 minecraft:sea_lantern
setblock 81 223 626 minecraft:sea_lantern
setblock 81 223 628 minecraft:sea_lantern
setblock 82 223 619 minecraft:sea_lantern
setblock 82 223 621 minecraft:sea_lantern
setblock 82 223 623 minecraft:sea_lantern
setblock 82 223 625 minecraft:sea_lantern
setblock 82 223 627 minecraft:sea_lantern
setblock 82 223 629 minecraft:sea_lantern
setblock 83 223 620 minecraft:sea_lantern
setblock 83 223 622 minecraft:sea_lantern
setblock 83 223 624 minecraft:sea_lantern
setblock 83 223 626 minecraft:sea_lantern
setblock 83 223 628 minecraft:sea_lantern
setblock 84 223 619 minecraft:sea_lantern
setblock 84 223 621 minecraft:sea_lantern
setblock 84 223 623 minecraft:sea_lantern
setblock 84 223 625 minecraft:sea_lantern
setblock 84 223 627 minecraft:sea_lantern
setblock 84 223 629 minecraft:sea_lantern
setblock 85 223 620 minecraft:sea_lantern
setblock 85 223 622 minecraft:sea_lantern
setblock 85 223 624 minecraft:sea_lantern
setblock 85 223 626 minecraft:sea_lantern
setblock 85 223 628 minecraft:sea_lantern
setblock 86 223 619 minecraft:sea_lantern
setblock 86 223 621 minecraft:sea_lantern
setblock 86 223 623 minecraft:sea_lantern
setblock 86 223 625 minecraft:sea_lantern
setblock 86 223 627 minecraft:sea_lantern
setblock 86 223 629 minecraft:sea_lantern
setblock 87 223 620 minecraft:sea_lantern
setblock 87 223 622 minecraft:sea_lantern
setblock 87 223 624 minecraft:sea_lantern
setblock 87 223 626 minecraft:sea_lantern
setblock 87 223 628 minecraft:sea_lantern
setblock 88 223 619 minecraft:sea_lantern
setblock 88 223 621 minecraft:sea_lantern
setblock 88 223 623 minecraft:sea_lantern
setblock 88 223 625 minecraft:sea_lantern
setblock 88 223 627 minecraft:sea_lantern
setblock 88 223 629 minecraft:sea_lantern
fill 48 224 605 48 225 605 minecraft:light_gray_concrete
fill 48 224 607 48 225 607 minecraft:light_gray_concrete
fill 48 224 609 48 225 609 minecraft:light_gray_concrete
fill 48 224 611 48 225 611 minecraft:light_gray_concrete
fill 48 224 613 48 225 613 minecraft:light_gray_concrete
fill 48 224 615 48 225 615 minecraft:light_gray_concrete
fill 48 224 617 48 225 617 minecraft:light_gray_concrete
fill 48 224 619 48 225 619 minecraft:light_gray_concrete
fill 48 224 621 48 225 621 minecraft:light_gray_concrete
fill 48 224 623 49 224 626 minecraft:light_gray_concrete
fill 48 224 629 49 224 634 minecraft:light_gray_concrete
fill 48 224 637 49 224 642 minecraft:light_gray_concrete
fill 48 224 645 53 225 645 minecraft:light_gray_concrete
fill 49 224 604 49 307 604 minecraft:gray_concrete
fill 49 224 606 49 225 606 minecraft:light_gray_concrete
fill 49 224 608 49 225 608 minecraft:light_gray_concrete
fill 49 224 610 49 225 610 minecraft:light_gray_concrete
fill 49 224 612 49 225 612 minecraft:light_gray_concrete
fill 49 224 614 49 225 614 minecraft:light_gray_concrete
fill 49 224 616 49 225 616 minecraft:light_gray_concrete
fill 49 224 618 49 225 618 minecraft:light_gray_concrete
fill 49 224 620 49 225 620 minecraft:light_gray_concrete
fill 49 224 622 49 225 622 minecraft:light_gray_concrete
fill 49 224 627 49 224 628 minecraft:light_gray_concrete
fill 49 224 635 49 224 636 minecraft:light_gray_concrete
fill 49 224 643 49 224 644 minecraft:light_gray_concrete
fill 50 224 605 50 225 605 minecraft:light_gray_concrete
fill 50 224 607 50 225 607 minecraft:light_gray_concrete
fill 50 224 609 50 225 609 minecraft:light_gray_concrete
fill 50 224 611 50 225 611 minecraft:light_gray_concrete
fill 50 224 613 50 225 613 minecraft:light_gray_concrete
fill 50 224 615 50 225 615 minecraft:light_gray_concrete
fill 50 224 617 50 225 617 minecraft:light_gray_concrete
fill 50 224 619 50 225 619 minecraft:light_gray_concrete
fill 50 224 621 50 225 621 minecraft:light_gray_concrete
setblock 50 224 623 minecraft:light[level=14]
setblock 50 224 631 minecraft:light[level=14]
setblock 50 224 639 minecraft:light[level=14]
fill 50 224 644 88 224 644 minecraft:light_gray_concrete
fill 51 224 604 51 307 604 minecraft:gray_concrete
fill 51 224 606 51 225 606 minecraft:light_gray_concrete
fill 51 224 608 51 225 608 minecraft:light_gray_concrete
fill 51 224 610 51 225 610 minecraft:light_gray_concrete
fill 51 224 612 51 225 612 minecraft:light_gray_concrete
fill 51 224 614 51 225 614 minecraft:light_gray_concrete
fill 51 224 616 51 225 616 minecraft:light_gray_concrete
fill 51 224 618 51 225 618 minecraft:light_gray_concrete
fill 51 224 620 51 225 620 minecraft:light_gray_concrete
fill 51 224 622 51 225 622 minecraft:light_gray_concrete
fill 52 224 605 52 225 605 minecraft:light_gray_concrete
fill 52 224 607 52 225 607 minecraft:light_gray_concrete
fill 52 224 609 52 225 609 minecraft:light_gray_concrete
fill 52 224 611 52 225 611 minecraft:light_gray_concrete
fill 52 224 613 52 225 613 minecraft:light_gray_concrete
fill 52 224 615 52 225 615 minecraft:light_gray_concrete
fill 52 224 617 52 225 617 minecraft:light_gray_concrete
fill 52 224 619 52 225 619 minecraft:light_gray_concrete
fill 52 224 621 52 225 621 minecraft:light_gray_concrete
fill 53 224 606 53 225 606 minecraft:light_gray_concrete
fill 53 224 608 53 225 608 minecraft:light_gray_concrete
fill 53 224 612 53 225 612 minecraft:light_gray_concrete
fill 53 224 614 53 225 614 minecraft:light_gray_concrete
fill 53 224 616 53 225 616 minecraft:light_gray_concrete
fill 53 224 618 53 225 618 minecraft:light_gray_concrete
fill 53 224 620 53 225 620 minecraft:light_gray_concrete
fill 53 224 622 53 225 622 minecraft:light_gray_concrete
fill 54 224 605 54 225 605 minecraft:light_gray_concrete
fill 54 224 607 54 225 607 minecraft:light_gray_concrete
fill 54 224 609 54 225 609 minecraft:light_gray_concrete
fill 54 224 613 54 225 613 minecraft:light_gray_concrete
fill 54 224 615 54 225 615 minecraft:light_gray_concrete
fill 54 224 617 54 225 617 minecraft:light_gray_concrete
fill 54 224 619 54 225 619 minecraft:light_gray_concrete
fill 54 224 621 54 225 621 minecraft:light_gray_concrete
fill 55 224 606 55 225 606 minecraft:light_gray_concrete
fill 55 224 608 55 225 608 minecraft:light_gray_concrete
fill 55 224 612 55 225 612 minecraft:light_gray_concrete
fill 55 224 614 55 225 614 minecraft:light_gray_concrete
fill 55 224 616 55 225 616 minecraft:light_gray_concrete
fill 55 224 618 55 225 618 minecraft:light_gray_concrete
fill 55 224 620 55 225 620 minecraft:light_gray_concrete
fill 55 224 622 55 225 622 minecraft:light_gray_concrete
fill 56 224 605 56 225 605 minecraft:light_gray_concrete
fill 56 224 607 56 225 607 minecraft:light_gray_concrete
fill 56 224 609 56 225 609 minecraft:light_gray_concrete
fill 56 224 645 61 225 645 minecraft:light_gray_concrete
fill 57 224 606 57 225 606 minecraft:light_gray_concrete
fill 57 224 608 57 225 608 minecraft:light_gray_concrete
fill 58 224 605 58 225 605 minecraft:light_gray_concrete
fill 58 224 607 58 225 607 minecraft:light_gray_concrete
fill 58 224 609 58 225 609 minecraft:light_gray_concrete
setblock 58 224 615 minecraft:light[level=14]
setblock 58 224 623 minecraft:light[level=14]
setblock 58 224 631 minecraft:light[level=14]
setblock 58 224 639 minecraft:light[level=14]
fill 59 224 606 59 225 606 minecraft:light_gray_concrete
fill 59 224 608 59 225 608 minecraft:light_gray_concrete
fill 60 224 605 60 225 605 minecraft:light_gray_concrete
fill 60 224 607 60 225 607 minecraft:light_gray_concrete
fill 60 224 609 60 225 609 minecraft:light_gray_concrete
fill 61 224 606 87 224 606 minecraft:light_gray_concrete
fill 61 224 608 61 225 608 minecraft:light_gray_concrete
fill 62 224 605 64 225 605 minecraft:light_gray_concrete
fill 64 224 645 69 225 645 minecraft:light_gray_concrete
setblock 66 224 607 minecraft:light[level=14]
setblock 66 224 615 minecraft:light[level=14]
setblock 66 224 631 minecraft:light[level=14]
setblock 66 224 639 minecraft:light[level=14]
fill 67 224 605 72 225 605 minecraft:light_gray_concrete
fill 72 224 645 77 225 645 minecraft:light_gray_concrete
setblock 74 224 607 minecraft:light[level=14]
setblock 74 224 615 minecraft:light[level=14]
setblock 74 224 623 minecraft:light[level=14]
setblock 74 224 631 minecraft:light[level=14]
setblock 74 224 639 minecraft:light[level=14]
fill 75 224 605 80 225 605 minecraft:light_gray_concrete
fill 78 224 619 78 225 619 minecraft:light_gray_concrete
fill 78 224 621 78 225 621 minecraft:light_gray_concrete
fill 78 224 623 78 225 623 minecraft:light_gray_concrete
fill 78 224 625 78 225 625 minecraft:light_gray_concrete
fill 78 224 627 78 225 627 minecraft:light_gray_concrete
fill 78 224 629 78 225 629 minecraft:light_gray_concrete
fill 79 224 620 79 225 620 minecraft:light_gray_concrete
fill 79 224 622 79 225 622 minecraft:light_gray_concrete
fill 79 224 624 79 225 624 minecraft:light_gray_concrete
fill 79 224 626 79 225 626 minecraft:light_gray_concrete
fill 79 224 628 79 225 628 minecraft:light_gray_concrete
fill 80 224 619 80 225 619 minecraft:light_gray_concrete
fill 80 224 621 80 225 621 minecraft:light_gray_concrete
fill 80 224 623 80 225 623 minecraft:light_gray_concrete
fill 80 224 625 80 225 625 minecraft:light_gray_concrete
fill 80 224 627 80 225 627 minecraft:light_gray_concrete
fill 80 224 629 80 225 629 minecraft:light_gray_concrete
fill 80 224 645 85 225 645 minecraft:light_gray_concrete
fill 81 224 620 81 225 620 minecraft:light_gray_concrete
fill 81 224 622 81 225 622 minecraft:light_gray_concrete
fill 81 224 624 81 225 624 minecraft:light_gray_concrete
fill 81 224 626 81 225 626 minecraft:light_gray_concrete
fill 81 224 628 81 225 628 minecraft:light_gray_concrete
setblock 82 224 607 minecraft:light[level=14]
setblock 82 224 615 minecraft:light[level=14]
fill 82 224 619 82 225 619 minecraft:light_gray_concrete
fill 82 224 621 82 225 621 minecraft:light_gray_concrete
fill 82 224 623 82 225 623 minecraft:light_gray_concrete
fill 82 224 625 82 225 625 minecraft:light_gray_concrete
fill 82 224 627 82 225 627 minecraft:light_gray_concrete
fill 82 224 629 82 225 629 minecraft:light_gray_concrete
setblock 82 224 631 minecraft:light[level=14]
setblock 82 224 639 minecraft:light[level=14]
fill 83 224 605 88 225 605 minecraft:light_gray_concrete
fill 83 224 620 83 225 620 minecraft:light_gray_concrete
fill 83 224 622 83 225 622 minecraft:light_gray_concrete
fill 83 224 624 83 225 624 minecraft:light_gray_concrete
fill 83 224 626 83 225 626 minecraft:light_gray_concrete
fill 83 224 628 83 225 628 minecraft:light_gray_concrete
fill 84 224 619 84 225 619 minecraft:light_gray_concrete
fill 84 224 621 84 225 621 minecraft:light_gray_concrete
fill 84 224 623 84 225 623 minecraft:light_gray_concrete
fill 84 224 625 84 225 625 minecraft:light_gray_concrete
fill 84 224 627 84 225 627 minecraft:light_gray_concrete
fill 84 224 629 84 225 629 minecraft:light_gray_concrete
fill 85 224 620 85 225 620 minecraft:light_gray_concrete
fill 85 224 622 85 225 622 minecraft:light_gray_concrete
fill 85 224 624 85 225 624 minecraft:light_gray_concrete
fill 85 224 626 85 225 626 minecraft:light_gray_concrete
fill 85 224 628 85 225 628 minecraft:light_gray_concrete
fill 86 224 619 86 225 619 minecraft:light_gray_concrete
fill 86 224 621 86 225 621 minecraft:light_gray_concrete
fill 86 224 623 86 225 623 minecraft:light_gray_concrete
fill 86 224 625 86 225 625 minecraft:light_gray_concrete
fill 86 224 627 86 225 627 minecraft:light_gray_concrete
fill 86 224 629 86 225 629 minecraft:light_gray_concrete
fill 87 224 607 87 224 618 minecraft:light_gray_concrete
fill 87 224 620 87 225 620 minecraft:light_gray_concrete
fill 87 224 622 87 225 622 minecraft:light_gray_concrete
fill 87 224 624 87 225 624 minecraft:light_gray_concrete
fill 87 224 626 87 225 626 minecraft:light_gray_concrete
fill 87 224 628 87 225 628 minecraft:light_gray_concrete
fill 87 224 630 87 224 643 minecraft:light_gray_concrete
fill 88 224 608 88 225 613 minecraft:light_gray_concrete
fill 88 224 616 88 225 619 minecraft:light_gray_concrete
fill 88 224 621 88 225 621 minecraft:light_gray_concrete
fill 88 224 623 88 225 623 minecraft:light_gray_concrete
fill 88 224 625 88 225 625 minecraft:light_gray_concrete
fill 88 224 627 88 225 627 minecraft:light_gray_concrete
fill 88 224 629 88 225 629 minecraft:light_gray_concrete
fill 88 224 632 88 225 637 minecraft:light_gray_concrete
fill 88 224 640 88 225 643 minecraft:light_gray_concrete
fill 88 224 645 88 225 645 minecraft:light_gray_concrete
fill 48 225 623 48 225 626 minecraft:light_gray_concrete
fill 48 225 629 48 225 634 minecraft:light_gray_concrete
fill 48 225 637 48 225 642 minecraft:light_gray_concrete
setblock 61 225 606 minecraft:light_gray_concrete
setblock 88 225 644 minecraft:light_gray_concrete
fill 62 230 619 64 230 621 minecraft:redstone_block
fill 62 230 625 64 230 627 minecraft:redstone_block
fill 69 230 626 71 230 628 minecraft:redstone_block
fill 70 230 619 72 230 621 minecraft:redstone_block
fill 48 231 605 51 232 607 minecraft:black_concrete
fill 48 231 608 51 231 612 minecraft:gray_concrete
fill 48 231 613 51 231 617 minecraft:black_concrete
fill 48 231 618 51 231 622 minecraft:gray_concrete
fill 48 231 623 51 231 627 minecraft:black_concrete
fill 48 231 628 51 231 632 minecraft:gray_concrete
fill 48 231 633 51 231 637 minecraft:black_concrete
fill 48 231 638 51 231 642 minecraft:gray_concrete
fill 48 231 643 51 231 645 minecraft:black_concrete
fill 52 231 605 56 231 607 minecraft:gray_concrete
fill 52 231 608 56 231 612 minecraft:black_concrete
fill 52 231 613 56 231 617 minecraft:gray_concrete
fill 52 231 618 56 231 622 minecraft:black_concrete
fill 52 231 623 56 231 627 minecraft:gray_concrete
fill 52 231 628 56 231 632 minecraft:black_concrete
fill 52 231 633 56 231 637 minecraft:gray_concrete
fill 52 231 638 56 231 642 minecraft:black_concrete
fill 52 231 643 56 231 645 minecraft:gray_concrete
fill 57 231 605 61 231 607 minecraft:black_concrete
fill 57 231 608 61 231 612 minecraft:gray_concrete
fill 57 231 613 61 231 617 minecraft:black_concrete
fill 57 231 618 61 231 622 minecraft:gray_concrete
fill 57 231 623 61 231 627 minecraft:black_concrete
fill 57 231 628 61 231 632 minecraft:gray_concrete
fill 57 231 633 61 231 637 minecraft:black_concrete
fill 57 231 638 61 231 642 minecraft:gray_concrete
fill 57 231 643 61 231 645 minecraft:black_concrete
fill 62 231 605 66 231 607 minecraft:gray_concrete
fill 62 231 608 66 231 612 minecraft:black_concrete
fill 62 231 613 66 231 617 minecraft:gray_concrete
fill 62 231 618 66 231 618 minecraft:black_concrete
fill 62 231 622 65 231 622 minecraft:black_concrete
fill 62 231 623 65 231 624 minecraft:gray_concrete
fill 62 231 628 66 231 632 minecraft:black_concrete
fill 62 231 633 66 231 637 minecraft:gray_concrete
fill 62 231 638 66 231 642 minecraft:black_concrete
fill 62 231 643 66 231 645 minecraft:gray_concrete
fill 65 231 619 66 231 621 minecraft:black_concrete
fill 65 231 625 66 231 627 minecraft:gray_concrete
fill 67 231 605 71 231 607 minecraft:black_concrete
fill 67 231 608 71 231 612 minecraft:gray_concrete
fill 67 231 613 71 231 617 minecraft:black_concrete
fill 67 231 618 69 231 621 minecraft:gray_concrete
fill 67 231 625 68 231 627 minecraft:black_concrete
fill 67 231 628 68 231 632 minecraft:gray_concrete
fill 67 231 633 71 231 637 minecraft:black_concrete
fill 67 231 638 71 231 642 minecraft:gray_concrete
fill 67 231 643 71 231 645 minecraft:black_concrete
fill 69 231 622 71 231 622 minecraft:gray_concrete
fill 69 231 623 71 231 625 minecraft:black_concrete
fill 69 231 629 71 231 632 minecraft:gray_concrete
fill 70 231 618 71 231 618 minecraft:gray_concrete
fill 72 231 605 76 231 607 minecraft:gray_concrete
fill 72 231 608 76 231 612 minecraft:black_concrete
fill 72 231 613 76 231 617 minecraft:gray_concrete
fill 72 231 618 76 231 618 minecraft:black_concrete
fill 72 231 622 76 231 622 minecraft:black_concrete
fill 72 231 623 76 231 627 minecraft:gray_concrete
fill 72 231 628 76 231 632 minecraft:black_concrete
fill 72 231 633 76 231 637 minecraft:gray_concrete
fill 72 231 638 76 231 642 minecraft:black_concrete
fill 72 231 643 76 231 645 minecraft:gray_concrete
fill 73 231 619 76 231 621 minecraft:black_concrete
fill 77 231 605 81 231 607 minecraft:black_concrete
fill 77 231 608 81 231 612 minecraft:gray_concrete
fill 77 231 613 81 231 617 minecraft:black_concrete
fill 77 231 618 81 231 622 minecraft:gray_concrete
fill 77 231 623 81 231 627 minecraft:black_concrete
fill 77 231 628 81 231 632 minecraft:gray_concrete
fill 77 231 633 81 231 637 minecraft:black_concrete
fill 77 231 638 81 231 642 minecraft:gray_concrete
fill 77 231 643 81 231 645 minecraft:black_concrete
fill 82 231 605 86 231 607 minecraft:gray_concrete
fill 82 231 608 86 231 612 minecraft:black_concrete
fill 82 231 613 86 231 617 minecraft:gray_concrete
fill 82 231 618 86 231 622 minecraft:black_concrete
fill 82 231 623 86 231 627 minecraft:gray_concrete
fill 82 231 628 86 231 632 minecraft:black_concrete
fill 82 231 633 86 231 637 minecraft:gray_concrete
fill 82 231 638 86 231 642 minecraft:black_concrete
fill 82 231 643 86 231 645 minecraft:gray_concrete
fill 87 231 605 88 231 607 minecraft:black_concrete
fill 87 231 608 88 231 612 minecraft:gray_concrete
fill 87 231 613 88 231 617 minecraft:black_concrete
fill 87 231 618 88 231 622 minecraft:gray_concrete
fill 87 231 623 88 231 627 minecraft:black_concrete
fill 87 231 628 88 231 632 minecraft:gray_concrete
fill 87 231 633 88 231 637 minecraft:black_concrete
fill 87 231 638 88 231 642 minecraft:gray_concrete
fill 87 231 643 88 231 645 minecraft:black_concrete
fill 48 232 608 88 232 608 minecraft:magenta_concrete
fill 48 232 609 51 232 612 minecraft:gray_concrete
fill 48 232 613 88 232 613 minecraft:magenta_concrete
fill 48 232 614 51 232 617 minecraft:black_concrete
fill 48 232 618 60 232 618 minecraft:magenta_concrete
fill 48 232 619 51 232 622 minecraft:gray_concrete
fill 48 232 623 64 232 623 minecraft:magenta_concrete
fill 48 232 624 51 232 627 minecraft:black_concrete
fill 48 232 628 60 232 628 minecraft:magenta_concrete
fill 48 232 629 51 232 632 minecraft:gray_concrete
fill 48 232 633 88 232 633 minecraft:magenta_concrete
fill 48 232 634 51 232 637 minecraft:black_concrete
fill 48 232 638 88 232 638 minecraft:magenta_concrete
fill 48 232 639 51 232 642 minecraft:gray_concrete
fill 48 232 643 88 232 643 minecraft:magenta_concrete
fill 48 232 644 51 232 645 minecraft:black_concrete
fill 52 232 605 52 232 607 minecraft:magenta_concrete
fill 52 232 609 52 232 612 minecraft:magenta_concrete
fill 52 232 614 52 232 617 minecraft:magenta_concrete
fill 52 232 619 52 232 622 minecraft:magenta_concrete
fill 52 232 624 52 232 627 minecraft:magenta_concrete
fill 52 232 629 52 232 632 minecraft:magenta_concrete
fill 52 232 634 52 232 637 minecraft:magenta_concrete
fill 52 232 639 52 232 642 minecraft:magenta_concrete
fill 52 232 644 52 232 645 minecraft:magenta_concrete
fill 53 232 605 56 232 607 minecraft:gray_concrete
fill 53 232 609 56 232 612 minecraft:black_concrete
fill 53 232 614 56 232 617 minecraft:gray_concrete
fill 53 232 619 56 232 622 minecraft:black_concrete
fill 53 232 624 56 232 627 minecraft:gray_concrete
fill 53 232 629 56 232 632 minecraft:black_concrete
fill 53 232 634 56 232 637 minecraft:gray_concrete
fill 53 232 639 56 232 642 minecraft:black_concrete
fill 53 232 644 56 232 645 minecraft:gray_concrete
fill 57 232 605 57 232 607 minecraft:magenta_concrete
fill 57 232 609 57 232 612 minecraft:magenta_concrete
fill 57 232 614 57 232 617 minecraft:magenta_concrete
fill 57 232 619 57 232 622 minecraft:magenta_concrete
fill 57 232 624 57 232 627 minecraft:magenta_concrete
fill 57 232 629 57 232 632 minecraft:magenta_concrete
fill 57 232 634 57 232 637 minecraft:magenta_concrete
fill 57 232 639 57 232 642 minecraft:magenta_concrete
fill 57 232 644 57 232 645 minecraft:magenta_concrete
fill 58 232 605 61 232 607 minecraft:black_concrete
fill 58 232 609 61 232 612 minecraft:gray_concrete
fill 58 232 614 61 232 617 minecraft:black_concrete
fill 58 232 619 60 232 622 minecraft:gray_concrete
fill 58 232 624 60 232 627 minecraft:black_concrete
fill 58 232 629 61 232 632 minecraft:gray_concrete
fill 58 232 634 61 232 637 minecraft:black_concrete
fill 58 232 639 61 232 642 minecraft:gray_concrete
fill 58 232 644 61 232 645 minecraft:black_concrete
fill 61 232 618 61 232 622 minecraft:sea_lantern
fill 61 232 624 61 232 628 minecraft:sea_lantern
fill 62 232 605 62 232 607 minecraft:magenta_concrete
fill 62 232 609 62 232 612 minecraft:magenta_concrete
fill 62 232 614 62 232 617 minecraft:magenta_concrete
fill 62 232 618 65 232 618 minecraft:sea_lantern
fill 62 232 619 64 232 621 minecraft:gray_concrete
fill 62 232 622 65 232 622 minecraft:sea_lantern
fill 62 232 624 65 232 624 minecraft:sea_lantern
fill 62 232 625 64 232 627 minecraft:gray_concrete
fill 62 232 628 65 232 628 minecraft:sea_lantern
fill 62 232 629 62 232 632 minecraft:magenta_concrete
fill 62 232 634 62 232 637 minecraft:magenta_concrete
fill 62 232 639 62 232 642 minecraft:magenta_concrete
fill 62 232 644 62 232 645 minecraft:magenta_concrete
fill 63 232 605 66 232 607 minecraft:gray_concrete
fill 63 232 609 66 232 612 minecraft:black_concrete
fill 63 232 614 66 232 617 minecraft:gray_concrete
fill 63 232 629 66 232 632 minecraft:black_concrete
fill 63 232 634 66 232 637 minecraft:gray_concrete
fill 63 232 639 66 232 642 minecraft:black_concrete
fill 63 232 644 66 232 645 minecraft:gray_concrete
fill 65 232 619 65 232 621 minecraft:sea_lantern
setblock 65 232 623 minecraft:sea_lantern
fill 65 232 625 65 232 627 minecraft:sea_lantern
fill 66 232 618 68 232 618 minecraft:magenta_concrete
fill 66 232 619 66 232 620 minecraft:black_concrete
fill 66 232 621 69 232 621 minecraft:sea_lantern
fill 66 232 625 72 232 625 minecraft:sea_lantern
fill 66 232 626 66 232 627 minecraft:gray_concrete
fill 66 232 628 67 232 628 minecraft:magenta_concrete
fill 67 232 605 67 232 607 minecraft:magenta_concrete
fill 67 232 609 67 232 612 minecraft:magenta_concrete
fill 67 232 614 67 232 617 minecraft:magenta_concrete
fill 67 232 619 67 232 620 minecraft:magenta_concrete
fill 67 232 626 67 232 627 minecraft:magenta_concrete
fill 67 232 629 67 232 632 minecraft:magenta_concrete
fill 67 232 634 67 232 637 minecraft:magenta_concrete
fill 67 232 639 67 232 642 minecraft:magenta_concrete
fill 67 232 644 67 232 645 minecraft:magenta_concrete
fill 68 232 605 71 232 607 minecraft:black_concrete
fill 68 232 609 71 232 612 minecraft:gray_concrete
fill 68 232 614 71 232 617 minecraft:black_concrete
fill 68 232 619 68 232 620 minecraft:gray_concrete
fill 68 232 626 68 232 629 minecraft:sea_lantern
fill 68 232 630 71 232 632 minecraft:gray_concrete
fill 68 232 634 71 232 637 minecraft:black_concrete
fill 68 232 639 71 232 642 minecraft:gray_concrete
fill 68 232 644 71 232 645 minecraft:black_concrete
fill 69 232 618 69 232 620 minecraft:sea_lantern
fill 69 232 622 69 232 624 minecraft:sea_lantern
fill 69 232 626 71 232 628 minecraft:gray_concrete
fill 69 232 629 72 232 629 minecraft:sea_lantern
fill 70 232 618 73 232 618 minecraft:sea_lantern
fill 70 232 619 72 232 621 minecraft:gray_concrete
fill 70 232 622 73 232 622 minecraft:sea_lantern
fill 70 232 623 88 232 623 minecraft:magenta_concrete
fill 70 232 624 71 232 624 minecraft:black_concrete
fill 72 232 605 72 232 607 minecraft:magenta_concrete
fill 72 232 609 72 232 612 minecraft:magenta_concrete
fill 72 232 614 72 232 617 minecraft:magenta_concrete
setblock 72 232 624 minecraft:magenta_concrete
fill 72 232 626 72 232 628 minecraft:sea_lantern
fill 72 232 630 72 232 632 minecraft:magenta_concrete
fill 72 232 634 72 232 637 minecraft:magenta_concrete
fill 72 232 639 72 232 642 minecraft:magenta_concrete
fill 72 232 644 72 232 645 minecraft:magenta_concrete
fill 73 232 605 76 232 607 minecraft:gray_concrete
fill 73 232 609 76 232 612 minecraft:black_concrete
fill 73 232 614 76 232 617 minecraft:gray_concrete
fill 73 232 619 73 232 621 minecraft:sea_lantern
fill 73 232 624 76 232 627 minecraft:gray_concrete
fill 73 232 628 88 232 628 minecraft:magenta_concrete
fill 73 232 629 76 232 632 minecraft:black_concrete
fill 73 232 634 76 232 637 minecraft:gray_concrete
fill 73 232 639 76 232 642 minecraft:black_concrete
fill 73 232 644 76 232 645 minecraft:gray_concrete
fill 74 232 618 88 232 618 minecraft:magenta_concrete
fill 74 232 619 76 232 622 minecraft:black_concrete
fill 77 232 605 77 232 607 minecraft:magenta_concrete
fill 77 232 609 77 232 612 minecraft:magenta_concrete
fill 77 232 614 77 232 617 minecraft:magenta_concrete
fill 77 232 619 77 232 622 minecraft:magenta_concrete
fill 77 232 624 77 232 627 minecraft:magenta_concrete
fill 77 232 629 77 232 632 minecraft:magenta_concrete
fill 77 232 634 77 232 637 minecraft:magenta_concrete
fill 77 232 639 77 232 642 minecraft:magenta_concrete
fill 77 232 644 77 232 645 minecraft:magenta_concrete
fill 78 232 605 81 232 607 minecraft:black_concrete
fill 78 232 609 81 232 612 minecraft:gray_concrete
fill 78 232 614 81 232 617 minecraft:black_concrete
fill 78 232 619 81 232 622 minecraft:gray_concrete
fill 78 232 624 81 232 627 minecraft:black_concrete
fill 78 232 629 81 232 632 minecraft:gray_concrete
fill 78 232 634 81 232 637 minecraft:black_concrete
fill 78 232 639 81 232 642 minecraft:gray_concrete
fill 78 232 644 81 232 645 minecraft:black_concrete
fill 82 232 605 82 232 607 minecraft:magenta_concrete
fill 82 232 609 82 232 612 minecraft:magenta_concrete
fill 82 232 614 82 232 617 minecraft:magenta_concrete
fill 82 232 619 82 232 622 minecraft:magenta_concrete
fill 82 232 624 82 232 627 minecraft:magenta_concrete
fill 82 232 629 82 232 632 minecraft:magenta_concrete
fill 82 232 634 82 232 637 minecraft:magenta_concrete
fill 82 232 639 82 232 642 minecraft:magenta_concrete
fill 82 232 644 82 232 645 minecraft:magenta_concrete
fill 83 232 605 86 232 607 minecraft:gray_concrete
fill 83 232 609 86 232 612 minecraft:black_concrete
fill 83 232 614 86 232 617 minecraft:gray_concrete
fill 83 232 619 86 232 622 minecraft:black_concrete
fill 83 232 624 86 232 627 minecraft:gray_concrete
fill 83 232 629 86 232 632 minecraft:black_concrete
fill 83 232 634 86 232 637 minecraft:gray_concrete
fill 83 232 639 86 232 642 minecraft:black_concrete
fill 83 232 644 86 232 645 minecraft:gray_concrete
fill 87 232 605 87 232 607 minecraft:magenta_concrete
fill 87 232 609 87 232 612 minecraft:magenta_concrete
fill 87 232 614 87 232 617 minecraft:magenta_concrete
fill 87 232 619 87 232 622 minecraft:magenta_concrete
fill 87 232 624 87 232 627 minecraft:magenta_concrete
fill 87 232 629 87 232 632 minecraft:magenta_concrete
fill 87 232 634 87 232 637 minecraft:magenta_concrete
fill 87 232 639 87 232 642 minecraft:magenta_concrete
fill 87 232 644 87 232 645 minecraft:magenta_concrete
fill 88 232 605 88 232 607 minecraft:black_concrete
fill 88 232 609 88 232 612 minecraft:gray_concrete
fill 88 232 614 88 232 617 minecraft:black_concrete
fill 88 232 619 88 232 622 minecraft:gray_concrete
fill 88 232 624 88 232 627 minecraft:black_concrete
fill 88 232 629 88 232 632 minecraft:gray_concrete
fill 88 232 634 88 232 637 minecraft:black_concrete
fill 88 232 639 88 232 642 minecraft:gray_concrete
fill 88 232 644 88 232 645 minecraft:black_concrete
fill 48 236 611 48 273 612 minecraft:light_gray_concrete
fill 48 236 619 48 273 620 minecraft:light_gray_concrete
fill 48 236 627 48 273 628 minecraft:light_gray_concrete
fill 48 236 635 48 273 636 minecraft:light_gray_concrete
fill 48 236 643 48 273 644 minecraft:light_gray_concrete
fill 49 236 605 50 273 605 minecraft:light_gray_concrete
fill 54 236 645 55 273 645 minecraft:light_gray_concrete
fill 57 236 605 58 273 605 minecraft:light_gray_concrete
fill 62 236 645 63 273 645 minecraft:light_gray_concrete
fill 65 236 605 66 273 605 minecraft:light_gray_concrete
fill 70 236 645 71 261 645 minecraft:light_gray_concrete
fill 73 236 605 74 273 605 minecraft:light_gray_concrete
fill 77 236 626 77 237 627 minecraft:glass
fill 78 236 645 79 273 645 minecraft:light_gray_concrete
fill 81 236 605 82 273 605 minecraft:light_gray_concrete
fill 86 236 645 87 273 645 minecraft:light_gray_concrete
fill 88 236 606 88 273 607 minecraft:light_gray_concrete
fill 88 236 614 88 273 615 minecraft:light_gray_concrete
fill 88 236 622 88 273 623 minecraft:light_gray_concrete
fill 88 236 630 88 273 631 minecraft:light_gray_concrete
fill 88 236 638 88 273 639 minecraft:light_gray_concrete
fill 81 237 632 82 238 633 minecraft:magenta_concrete
fill 48 238 605 48 239 610 minecraft:light_gray_concrete
fill 48 238 613 49 238 618 minecraft:light_gray_concrete
fill 48 238 621 49 238 626 minecraft:light_gray_concrete
fill 48 238 629 49 238 634 minecraft:light_gray_concrete
fill 48 238 637 49 238 642 minecraft:light_gray_concrete
fill 48 238 645 53 239 645 minecraft:light_gray_concrete
fill 49 238 606 49 238 612 minecraft:light_gray_concrete
fill 49 238 619 49 238 620 minecraft:light_gray_concrete
fill 49 238 627 49 238 628 minecraft:light_gray_concrete
fill 49 238 635 49 238 636 minecraft:light_gray_concrete
fill 49 238 643 49 238 644 minecraft:light_gray_concrete
fill 50 238 606 87 238 606 minecraft:light_gray_concrete
fill 50 238 644 88 238 644 minecraft:light_gray_concrete
fill 51 238 605 56 239 605 minecraft:light_gray_concrete
fill 56 238 645 61 239 645 minecraft:light_gray_concrete
fill 59 238 605 64 239 605 minecraft:light_gray_concrete
fill 64 238 645 69 239 645 minecraft:light_gray_concrete
fill 67 238 605 72 239 605 minecraft:light_gray_concrete
fill 72 238 645 77 239 645 minecraft:light_gray_concrete
fill 75 238 605 80 239 605 minecraft:light_gray_concrete
fill 80 238 645 85 239 645 minecraft:light_gray_concrete
fill 83 238 605 88 239 605 minecraft:light_gray_concrete
fill 87 238 607 87 238 643 minecraft:light_gray_concrete
fill 88 238 608 88 239 613 minecraft:light_gray_concrete
fill 88 238 616 88 239 621 minecraft:light_gray_concrete
fill 88 238 624 88 239 629 minecraft:light_gray_concrete
fill 88 238 632 88 239 637 minecraft:light_gray_concrete
fill 88 238 640 88 239 643 minecraft:light_gray_concrete
fill 88 238 645 88 239 645 minecraft:light_gray_concrete
fill 48 239 613 48 239 618 minecraft:light_gray_concrete
fill 48 239 621 48 239 626 minecraft:light_gray_concrete
fill 48 239 629 48 239 634 minecraft:light_gray_concrete
fill 48 239 637 48 239 642 minecraft:light_gray_concrete
setblock 88 239 644 minecraft:light_gray_concrete
setblock 50 240 607 minecraft:light[level=14]
setblock 50 240 615 minecraft:light[level=14]
setblock 50 240 623 minecraft:light[level=14]
setblock 50 240 631 minecraft:light[level=14]
setblock 50 240 639 minecraft:light[level=14]
fill 56 240 611 57 241 611 minecraft:magenta_concrete
setblock 58 240 607 minecraft:light[level=14]
setblock 58 240 615 minecraft:light[level=14]
setblock 58 240 623 minecraft:light[level=14]
setblock 58 240 631 minecraft:light[level=14]
setblock 58 240 639 minecraft:light[level=14]
setblock 66 240 607 minecraft:light[level=14]
setblock 66 240 615 minecraft:light[level=14]
setblock 66 240 631 minecraft:light[level=14]
setblock 66 240 639 minecraft:light[level=14]
setblock 74 240 607 minecraft:light[level=14]
setblock 74 240 615 minecraft:light[level=14]
setblock 74 240 623 minecraft:light[level=14]
setblock 74 240 631 minecraft:light[level=14]
setblock 74 240 639 minecraft:light[level=14]
setblock 82 240 607 minecraft:light[level=14]
setblock 82 240 615 minecraft:light[level=14]
setblock 82 240 623 minecraft:light[level=14]
setblock 82 240 631 minecraft:light[level=14]
setblock 82 240 639 minecraft:light[level=14]
fill 47 242 609 47 247 609 minecraft:sea_lantern
fill 47 242 617 47 247 617 minecraft:sea_lantern
fill 47 242 625 47 247 625 minecraft:sea_lantern
fill 47 242 633 47 247 633 minecraft:sea_lantern
fill 47 242 641 47 247 641 minecraft:sea_lantern
fill 50 242 646 50 247 646 minecraft:sea_lantern
fill 54 242 604 54 247 604 minecraft:sea_lantern
fill 58 242 646 58 247 646 minecraft:sea_lantern
fill 62 242 604 62 247 604 minecraft:sea_lantern
fill 66 242 646 66 247 646 minecraft:sea_lantern
fill 70 242 604 70 247 604 minecraft:sea_lantern
fill 74 242 646 74 247 646 minecraft:sea_lantern
fill 78 242 604 78 247 604 minecraft:sea_lantern
fill 82 242 646 82 247 646 minecraft:sea_lantern
fill 86 242 604 86 247 604 minecraft:sea_lantern
fill 89 242 609 89 247 609 minecraft:sea_lantern
fill 89 242 617 89 247 617 minecraft:sea_lantern
fill 89 242 625 89 247 625 minecraft:sea_lantern
fill 89 242 633 89 247 633 minecraft:sea_lantern
fill 89 242 641 89 247 641 minecraft:sea_lantern
fill 47 248 609 47 255 609 minecraft:gray_concrete
fill 47 248 617 47 255 617 minecraft:gray_concrete
fill 47 248 625 47 255 625 minecraft:gray_concrete
fill 47 248 633 47 255 633 minecraft:gray_concrete
fill 47 248 641 47 255 641 minecraft:gray_concrete
setblock 50 248 607 minecraft:light[level=14]
setblock 50 248 615 minecraft:light[level=14]
setblock 50 248 623 minecraft:light[level=14]
setblock 50 248 631 minecraft:light[level=14]
setblock 50 248 639 minecraft:light[level=14]
fill 50 248 646 50 255 646 minecraft:gray_concrete
fill 54 248 604 54 255 604 minecraft:gray_concrete
setblock 58 248 607 minecraft:light[level=14]
setblock 58 248 615 minecraft:light[level=14]
setblock 58 248 623 minecraft:light[level=14]
setblock 58 248 631 minecraft:light[level=14]
setblock 58 248 639 minecraft:light[level=14]
fill 58 248 646 58 255 646 minecraft:gray_concrete
fill 62 248 604 62 255 604 minecraft:gray_concrete
setblock 66 248 607 minecraft:light[level=14]
setblock 66 248 615 minecraft:light[level=14]
setblock 66 248 631 minecraft:light[level=14]
setblock 66 248 639 minecraft:light[level=14]
fill 66 248 646 66 255 646 minecraft:gray_concrete
fill 70 248 604 70 255 604 minecraft:gray_concrete
setblock 74 248 607 minecraft:light[level=14]
setblock 74 248 615 minecraft:light[level=14]
setblock 74 248 623 minecraft:light[level=14]
setblock 74 248 631 minecraft:light[level=14]
setblock 74 248 639 minecraft:light[level=14]
fill 74 248 646 74 255 646 minecraft:gray_concrete
fill 78 248 604 78 255 604 minecraft:gray_concrete
setblock 82 248 607 minecraft:light[level=14]
setblock 82 248 615 minecraft:light[level=14]
setblock 82 248 623 minecraft:light[level=14]
setblock 82 248 631 minecraft:light[level=14]
setblock 82 248 639 minecraft:light[level=14]
fill 82 248 646 82 255 646 minecraft:gray_concrete
fill 86 248 604 86 255 604 minecraft:gray_concrete
fill 89 248 609 89 255 609 minecraft:gray_concrete
fill 89 248 617 89 255 617 minecraft:gray_concrete
fill 89 248 625 89 255 625 minecraft:gray_concrete
fill 89 248 633 89 255 633 minecraft:gray_concrete
fill 89 248 641 89 255 641 minecraft:gray_concrete
fill 71 249 633 71 250 633 minecraft:glass
fill 48 252 605 48 253 610 minecraft:light_gray_concrete
fill 48 252 613 49 252 618 minecraft:light_gray_concrete
fill 48 252 621 49 252 626 minecraft:light_gray_concrete
fill 48 252 629 49 252 634 minecraft:light_gray_concrete
fill 48 252 637 49 252 642 minecraft:light_gray_concrete
fill 48 252 645 53 253 645 minecraft:light_gray_concrete
fill 49 252 606 49 252 612 minecraft:light_gray_concrete
fill 49 252 619 49 252 620 minecraft:light_gray_concrete
fill 49 252 627 49 252 628 minecraft:light_gray_concrete
fill 49 252 635 49 252 636 minecraft:light_gray_concrete
fill 49 252 643 49 252 644 minecraft:light_gray_concrete
fill 50 252 606 87 252 606 minecraft:light_gray_concrete
fill 50 252 644 88 252 644 minecraft:light_gray_concrete
fill 51 252 605 56 253 605 minecraft:light_gray_concrete
fill 56 252 645 61 253 645 minecraft:light_gray_concrete
fill 59 252 605 64 253 605 minecraft:light_gray_concrete
fill 64 252 645 69 253 645 minecraft:light_gray_concrete
fill 67 252 605 72 253 605 minecraft:light_gray_concrete
fill 72 252 645 77 253 645 minecraft:light_gray_concrete
fill 75 252 605 80 253 605 minecraft:light_gray_concrete
fill 80 252 645 85 253 645 minecraft:light_gray_concrete
fill 83 252 605 88 253 605 minecraft:light_gray_concrete
fill 87 252 607 87 252 643 minecraft:light_gray_concrete
fill 88 252 608 88 253 613 minecraft:light_gray_concrete
fill 88 252 616 88 253 621 minecraft:light_gray_concrete
fill 88 252 624 88 253 629 minecraft:light_gray_concrete
fill 88 252 632 88 253 637 minecraft:light_gray_concrete
fill 88 252 640 88 253 643 minecraft:light_gray_concrete
fill 88 252 645 88 253 645 minecraft:light_gray_concrete
fill 48 253 613 48 253 618 minecraft:light_gray_concrete
fill 48 253 621 48 253 626 minecraft:light_gray_concrete
fill 48 253 629 48 253 634 minecraft:light_gray_concrete
fill 48 253 637 48 253 642 minecraft:light_gray_concrete
setblock 88 253 644 minecraft:light_gray_concrete
fill 57 255 616 58 256 617 minecraft:gray_concrete
fill 69 255 640 69 260 640 minecraft:magenta_concrete
fill 47 256 609 47 261 609 minecraft:sea_lantern
fill 47 256 617 47 261 617 minecraft:sea_lantern
fill 47 256 625 47 261 625 minecraft:sea_lantern
fill 47 256 633 47 261 633 minecraft:sea_lantern
fill 47 256 641 47 261 641 minecraft:sea_lantern
setblock 50 256 607 minecraft:light[level=14]
setblock 50 256 615 minecraft:light[level=14]
setblock 50 256 623 minecraft:light[level=14]
setblock 50 256 631 minecraft:light[level=14]
setblock 50 256 639 minecraft:light[level=14]
fill 50 256 646 50 261 646 minecraft:sea_lantern
fill 54 256 604 54 261 604 minecraft:sea_lantern
setblock 58 256 607 minecraft:light[level=14]
setblock 58 256 615 minecraft:light[level=14]
setblock 58 256 623 minecraft:light[level=14]
setblock 58 256 631 minecraft:light[level=14]
setblock 58 256 639 minecraft:light[level=14]
fill 58 256 646 58 261 646 minecraft:sea_lantern
fill 61 256 641 62 257 642 minecraft:glass
fill 62 256 604 62 261 604 minecraft:sea_lantern
setblock 66 256 607 minecraft:light[level=14]
setblock 66 256 615 minecraft:light[level=14]
setblock 66 256 631 minecraft:light[level=14]
setblock 66 256 639 minecraft:light[level=14]
fill 66 256 646 66 261 646 minecraft:sea_lantern
fill 69 256 641 69 260 641 minecraft:magenta_concrete
fill 70 256 604 70 261 604 minecraft:sea_lantern
setblock 74 256 607 minecraft:light[level=14]
setblock 74 256 615 minecraft:light[level=14]
setblock 74 256 623 minecraft:light[level=14]
setblock 74 256 631 minecraft:light[level=14]
setblock 74 256 639 minecraft:light[level=14]
fill 74 256 646 74 261 646 minecraft:sea_lantern
fill 78 256 604 78 261 604 minecraft:sea_lantern
setblock 82 256 607 minecraft:light[level=14]
setblock 82 256 615 minecraft:light[level=14]
setblock 82 256 623 minecraft:light[level=14]
setblock 82 256 631 minecraft:light[level=14]
setblock 82 256 639 minecraft:light[level=14]
fill 82 256 646 82 261 646 minecraft:sea_lantern
fill 86 256 604 86 261 604 minecraft:sea_lantern
fill 89 256 609 89 261 609 minecraft:sea_lantern
fill 89 256 617 89 261 617 minecraft:sea_lantern
fill 89 256 625 89 261 625 minecraft:sea_lantern
fill 89 256 633 89 261 633 minecraft:sea_lantern
fill 89 256 641 89 261 641 minecraft:sea_lantern
fill 68 257 639 68 260 641 minecraft:magenta_concrete
fill 69 257 639 70 260 639 minecraft:magenta_concrete
fill 70 257 640 70 260 641 minecraft:magenta_concrete
fill 67 258 640 67 260 641 minecraft:magenta_concrete
fill 68 258 642 70 260 642 minecraft:magenta_concrete
fill 69 258 638 69 260 638 minecraft:magenta_concrete
fill 71 258 640 71 260 641 minecraft:magenta_concrete
fill 56 259 617 57 260 617 minecraft:glass
fill 67 259 639 67 260 639 minecraft:magenta_concrete
fill 67 259 642 67 260 642 minecraft:magenta_concrete
fill 68 259 638 68 260 638 minecraft:magenta_concrete
fill 68 259 643 70 260 643 minecraft:magenta_concrete
fill 70 259 638 70 260 638 minecraft:magenta_concrete
fill 71 259 639 71 260 639 minecraft:magenta_concrete
fill 71 259 642 71 260 642 minecraft:magenta_concrete
fill 66 260 639 66 260 642 minecraft:magenta_concrete
setblock 67 260 638 minecraft:magenta_concrete
setblock 67 260 643 minecraft:magenta_concrete
fill 68 260 637 70 260 637 minecraft:magenta_concrete
setblock 71 260 638 minecraft:magenta_concrete
setblock 71 260 643 minecraft:magenta_concrete
fill 72 260 639 72 260 642 minecraft:magenta_concrete
fill 64 261 636 69 261 645 minecraft:light_gray_concrete
fill 70 261 636 74 261 644 minecraft:light_gray_concrete
fill 72 261 645 74 261 645 minecraft:light_gray_concrete
fill 47 262 609 47 269 609 minecraft:gray_concrete
fill 47 262 617 47 269 617 minecraft:gray_concrete
fill 47 262 625 47 269 625 minecraft:gray_concrete
fill 47 262 633 47 269 633 minecraft:gray_concrete
fill 47 262 641 47 269 641 minecraft:gray_concrete
fill 50 262 646 50 269 646 minecraft:gray_concrete
fill 54 262 604 54 269 604 minecraft:gray_concrete
fill 58 262 646 58 269 646 minecraft:gray_concrete
fill 62 262 604 62 269 604 minecraft:gray_concrete
fill 64 262 636 64 273 636 minecraft:light_gray_concrete
setblock 64 262 637 minecraft:sea_lantern
fill 64 262 638 64 273 638 minecraft:light_gray_concrete
setblock 64 262 639 minecraft:sea_lantern
fill 64 262 640 64 273 640 minecraft:light_gray_concrete
setblock 64 262 641 minecraft:sea_lantern
fill 64 262 642 64 273 642 minecraft:light_gray_concrete
setblock 64 262 643 minecraft:sea_lantern
fill 64 262 644 64 273 644 minecraft:light_gray_concrete
setblock 64 262 645 minecraft:sea_lantern
setblock 65 262 636 minecraft:sea_lantern
fill 65 262 637 65 273 637 minecraft:light_gray_concrete
setblock 65 262 638 minecraft:sea_lantern
fill 65 262 639 65 273 639 minecraft:light_gray_concrete
setblock 65 262 640 minecraft:sea_lantern
fill 65 262 641 65 273 641 minecraft:light_gray_concrete
setblock 65 262 642 minecraft:sea_lantern
fill 65 262 643 65 273 643 minecraft:light_gray_concrete
setblock 65 262 644 minecraft:sea_lantern
fill 65 262 645 65 273 645 minecraft:light_gray_concrete
fill 66 262 636 66 273 636 minecraft:light_gray_concrete
setblock 66 262 637 minecraft:sea_lantern
fill 66 262 638 66 273 638 minecraft:light_gray_concrete
setblock 66 262 639 minecraft:sea_lantern
fill 66 262 640 66 273 640 minecraft:light_gray_concrete
setblock 66 262 641 minecraft:sea_lantern
fill 66 262 642 66 273 642 minecraft:light_gray_concrete
setblock 66 262 643 minecraft:sea_lantern
fill 66 262 644 66 273 644 minecraft:light_gray_concrete
setblock 66 262 645 minecraft:sea_lantern
fill 66 262 646 66 269 646 minecraft:gray_concrete
setblock 67 262 636 minecraft:sea_lantern
fill 67 262 637 67 273 637 minecraft:light_gray_concrete
setblock 67 262 638 minecraft:sea_lantern
fill 67 262 639 67 273 639 minecraft:light_gray_concrete
setblock 67 262 640 minecraft:sea_lantern
fill 67 262 641 67 273 641 minecraft:light_gray_concrete
setblock 67 262 642 minecraft:sea_lantern
fill 67 262 643 67 273 643 minecraft:light_gray_concrete
setblock 67 262 644 minecraft:sea_lantern
fill 67 262 645 67 273 645 minecraft:light_gray_concrete
fill 68 262 636 68 273 636 minecraft:light_gray_concrete
setblock 68 262 637 minecraft:sea_lantern
fill 68 262 638 68 273 638 minecraft:light_gray_concrete
setblock 68 262 639 minecraft:sea_lantern
fill 68 262 640 68 273 640 minecraft:light_gray_concrete
setblock 68 262 641 minecraft:sea_lantern
fill 68 262 642 68 273 642 minecraft:light_gray_concrete
setblock 68 262 643 minecraft:sea_lantern
fill 68 262 644 68 273 644 minecraft:light_gray_concrete
setblock 68 262 645 minecraft:sea_lantern
setblock 69 262 636 minecraft:sea_lantern
fill 69 262 637 69 273 637 minecraft:light_gray_concrete
setblock 69 262 638 minecraft:sea_lantern
fill 69 262 639 69 273 639 minecraft:light_gray_concrete
setblock 69 262 640 minecraft:sea_lantern
fill 69 262 641 69 273 641 minecraft:light_gray_concrete
setblock 69 262 642 minecraft:sea_lantern
fill 69 262 643 69 273 643 minecraft:light_gray_concrete
setblock 69 262 644 minecraft:sea_lantern
fill 69 262 645 69 273 645 minecraft:light_gray_concrete
fill 70 262 604 70 269 604 minecraft:gray_concrete
fill 70 262 636 70 273 636 minecraft:light_gray_concrete
setblock 70 262 637 minecraft:sea_lantern
fill 70 262 638 70 273 638 minecraft:light_gray_concrete
setblock 70 262 639 minecraft:sea_lantern
fill 70 262 640 70 273 640 minecraft:light_gray_concrete
setblock 70 262 641 minecraft:sea_lantern
fill 70 262 642 70 273 642 minecraft:light_gray_concrete
setblock 70 262 643 minecraft:sea_lantern
fill 70 262 644 70 273 644 minecraft:light_gray_concrete
setblock 70 262 645 minecraft:sea_lantern
setblock 71 262 636 minecraft:sea_lantern
fill 71 262 637 71 273 637 minecraft:light_gray_concrete
setblock 71 262 638 minecraft:sea_lantern
fill 71 262 639 71 273 639 minecraft:light_gray_concrete
setblock 71 262 640 minecraft:sea_lantern
fill 71 262 641 71 273 641 minecraft:light_gray_concrete
setblock 71 262 642 minecraft:sea_lantern
fill 71 262 643 71 273 643 minecraft:light_gray_concrete
setblock 71 262 644 minecraft:sea_lantern
fill 71 262 645 71 273 645 minecraft:light_gray_concrete
fill 72 262 636 72 273 636 minecraft:light_gray_concrete
setblock 72 262 637 minecraft:sea_lantern
fill 72 262 638 72 273 638 minecraft:light_gray_concrete
setblock 72 262 639 minecraft:sea_lantern
fill 72 262 640 72 273 640 minecraft:light_gray_concrete
setblock 72 262 641 minecraft:sea_lantern
fill 72 262 642 72 273 642 minecraft:light_gray_concrete
setblock 72 262 643 minecraft:sea_lantern
fill 72 262 644 72 273 644 minecraft:light_gray_concrete
setblock 72 262 645 minecraft:sea_lantern
setblock 73 262 636 minecraft:sea_lantern
fill 73 262 637 73 273 637 minecraft:light_gray_concrete
setblock 73 262 638 minecraft:sea_lantern
fill 73 262 639 73 273 639 minecraft:light_gray_concrete
setblock 73 262 640 minecraft:sea_lantern
fill 73 262 641 73 273 641 minecraft:light_gray_concrete
setblock 73 262 642 minecraft:sea_lantern
fill 73 262 643 73 273 643 minecraft:light_gray_concrete
setblock 73 262 644 minecraft:sea_lantern
fill 73 262 645 73 273 645 minecraft:light_gray_concrete
fill 74 262 636 74 273 636 minecraft:light_gray_concrete
setblock 74 262 637 minecraft:sea_lantern
fill 74 262 638 74 273 638 minecraft:light_gray_concrete
setblock 74 262 639 minecraft:sea_lantern
fill 74 262 640 74 273 640 minecraft:light_gray_concrete
setblock 74 262 641 minecraft:sea_lantern
fill 74 262 642 74 273 642 minecraft:light_gray_concrete
setblock 74 262 643 minecraft:sea_lantern
fill 74 262 644 74 273 644 minecraft:light_gray_concrete
setblock 74 262 645 minecraft:sea_lantern
fill 74 262 646 74 269 646 minecraft:gray_concrete
fill 78 262 604 78 269 604 minecraft:gray_concrete
fill 81 262 617 82 263 618 minecraft:glass
fill 82 262 646 82 269 646 minecraft:gray_concrete
fill 86 262 604 86 269 604 minecraft:gray_concrete
fill 89 262 609 89 269 609 minecraft:gray_concrete
fill 89 262 617 89 269 617 minecraft:gray_concrete
fill 89 262 625 89 269 625 minecraft:gray_concrete
fill 89 262 633 89 269 633 minecraft:gray_concrete
fill 89 262 641 89 269 641 minecraft:gray_concrete
fill 64 263 637 64 264 637 minecraft:light_gray_concrete
fill 64 263 639 64 264 639 minecraft:light_gray_concrete
fill 64 263 641 64 264 641 minecraft:light_gray_concrete
fill 64 263 643 64 264 643 minecraft:light_gray_concrete
fill 64 263 645 64 264 645 minecraft:light_gray_concrete
fill 65 263 636 65 264 636 minecraft:light_gray_concrete
fill 65 263 638 65 264 638 minecraft:light_gray_concrete
fill 65 263 640 65 264 640 minecraft:light_gray_concrete
fill 65 263 642 65 264 642 minecraft:light_gray_concrete
fill 65 263 644 65 264 644 minecraft:light_gray_concrete
fill 66 263 637 66 264 637 minecraft:light_gray_concrete
fill 66 263 639 66 264 639 minecraft:light_gray_concrete
fill 66 263 641 66 264 641 minecraft:light_gray_concrete
fill 66 263 643 66 264 643 minecraft:light_gray_concrete
fill 66 263 645 66 264 645 minecraft:light_gray_concrete
fill 67 263 636 67 264 636 minecraft:light_gray_concrete
fill 67 263 638 67 264 638 minecraft:light_gray_concrete
fill 67 263 640 67 264 640 minecraft:light_gray_concrete
fill 67 263 642 67 264 642 minecraft:light_gray_concrete
fill 67 263 644 67 264 644 minecraft:light_gray_concrete
fill 68 263 637 68 264 637 minecraft:light_gray_concrete
fill 68 263 639 68 264 639 minecraft:light_gray_concrete
fill 68 263 641 68 264 641 minecraft:light_gray_concrete
fill 68 263 643 68 264 643 minecraft:light_gray_concrete
fill 68 263 645 68 264 645 minecraft:light_gray_concrete
fill 69 263 636 69 264 636 minecraft:light_gray_concrete
fill 69 263 638 69 264 638 minecraft:light_gray_concrete
fill 69 263 640 69 264 640 minecraft:light_gray_concrete
fill 69 263 642 69 264 642 minecraft:light_gray_concrete
fill 69 263 644 69 264 644 minecraft:light_gray_concrete
fill 70 263 637 70 264 637 minecraft:light_gray_concrete
fill 70 263 639 70 264 639 minecraft:light_gray_concrete
fill 70 263 641 70 264 641 minecraft:light_gray_concrete
fill 70 263 643 70 264 643 minecraft:light_gray_concrete
fill 70 263 645 70 264 645 minecraft:light_gray_concrete
fill 71 263 636 71 264 636 minecraft:light_gray_concrete
fill 71 263 638 71 264 638 minecraft:light_gray_concrete
fill 71 263 640 71 264 640 minecraft:light_gray_concrete
fill 71 263 642 71 264 642 minecraft:light_gray_concrete
fill 71 263 644 71 264 644 minecraft:light_gray_concrete
fill 72 263 637 72 264 637 minecraft:light_gray_concrete
fill 72 263 639 72 264 639 minecraft:light_gray_concrete
fill 72 263 641 72 264 641 minecraft:light_gray_concrete
fill 72 263 643 72 264 643 minecraft:light_gray_concrete
fill 72 263 645 72 264 645 minecraft:light_gray_concrete
fill 73 263 636 73 264 636 minecraft:light_gray_concrete
fill 73 263 638 73 264 638 minecraft:light_gray_concrete
fill 73 263 640 73 264 640 minecraft:light_gray_concrete
fill 73 263 642 73 264 642 minecraft:light_gray_concrete
fill 73 263 644 73 264 644 minecraft:light_gray_concrete
fill 74 263 637 74 264 637 minecraft:light_gray_concrete
fill 74 263 639 74 264 639 minecraft:light_gray_concrete
fill 74 263 641 74 264 641 minecraft:light_gray_concrete
fill 74 263 643 74 264 643 minecraft:light_gray_concrete
fill 74 263 645 74 264 645 minecraft:light_gray_concrete
setblock 50 264 607 minecraft:light[level=14]
setblock 50 264 615 minecraft:light[level=14]
setblock 50 264 623 minecraft:light[level=14]
setblock 50 264 631 minecraft:light[level=14]
setblock 50 264 639 minecraft:light[level=14]
setblock 58 264 607 minecraft:light[level=14]
setblock 58 264 615 minecraft:light[level=14]
setblock 58 264 623 minecraft:light[level=14]
setblock 58 264 631 minecraft:light[level=14]
setblock 58 264 639 minecraft:light[level=14]
setblock 66 264 607 minecraft:light[level=14]
setblock 66 264 615 minecraft:light[level=14]
setblock 66 264 623 minecraft:light[level=14]
setblock 66 264 631 minecraft:light[level=14]
setblock 74 264 607 minecraft:light[level=14]
setblock 74 264 615 minecraft:light[level=14]
setblock 74 264 623 minecraft:light[level=14]
setblock 74 264 631 minecraft:light[level=14]
setblock 82 264 607 minecraft:light[level=14]
setblock 82 264 615 minecraft:light[level=14]
setblock 82 264 623 minecraft:light[level=14]
setblock 82 264 631 minecraft:light[level=14]
setblock 82 264 639 minecraft:light[level=14]
setblock 64 265 637 minecraft:sea_lantern
setblock 64 265 639 minecraft:sea_lantern
setblock 64 265 641 minecraft:sea_lantern
setblock 64 265 643 minecraft:sea_lantern
setblock 64 265 645 minecraft:sea_lantern
setblock 65 265 636 minecraft:sea_lantern
setblock 65 265 638 minecraft:sea_lantern
setblock 65 265 640 minecraft:sea_lantern
setblock 65 265 642 minecraft:sea_lantern
setblock 65 265 644 minecraft:sea_lantern
setblock 66 265 637 minecraft:sea_lantern
setblock 66 265 639 minecraft:sea_lantern
setblock 66 265 641 minecraft:sea_lantern
setblock 66 265 643 minecraft:sea_lantern
setblock 66 265 645 minecraft:sea_lantern
setblock 67 265 636 minecraft:sea_lantern
setblock 67 265 638 minecraft:sea_lantern
setblock 67 265 640 minecraft:sea_lantern
setblock 67 265 642 minecraft:sea_lantern
setblock 67 265 644 minecraft:sea_lantern
setblock 68 265 637 minecraft:sea_lantern
setblock 68 265 639 minecraft:sea_lantern
setblock 68 265 641 minecraft:sea_lantern
setblock 68 265 643 minecraft:sea_lantern
setblock 68 265 645 minecraft:sea_lantern
setblock 69 265 636 minecraft:sea_lantern
setblock 69 265 638 minecraft:sea_lantern
setblock 69 265 640 minecraft:sea_lantern
setblock 69 265 642 minecraft:sea_lantern
setblock 69 265 644 minecraft:sea_lantern
setblock 70 265 637 minecraft:sea_lantern
setblock 70 265 639 minecraft:sea_lantern
setblock 70 265 641 minecraft:sea_lantern
setblock 70 265 643 minecraft:sea_lantern
setblock 70 265 645 minecraft:sea_lantern
setblock 71 265 636 minecraft:sea_lantern
setblock 71 265 638 minecraft:sea_lantern
setblock 71 265 640 minecraft:sea_lantern
setblock 71 265 642 minecraft:sea_lantern
setblock 71 265 644 minecraft:sea_lantern
setblock 72 265 637 minecraft:sea_lantern
setblock 72 265 639 minecraft:sea_lantern
setblock 72 265 641 minecraft:sea_lantern
setblock 72 265 643 minecraft:sea_lantern
setblock 72 265 645 minecraft:sea_lantern
setblock 73 265 636 minecraft:sea_lantern
setblock 73 265 638 minecraft:sea_lantern
setblock 73 265 640 minecraft:sea_lantern
setblock 73 265 642 minecraft:sea_lantern
setblock 73 265 644 minecraft:sea_lantern
setblock 74 265 637 minecraft:sea_lantern
setblock 74 265 639 minecraft:sea_lantern
setblock 74 265 641 minecraft:sea_lantern
setblock 74 265 643 minecraft:sea_lantern
setblock 74 265 645 minecraft:sea_lantern
fill 48 266 605 48 267 610 minecraft:light_gray_concrete
fill 48 266 613 49 266 618 minecraft:light_gray_concrete
fill 48 266 621 49 266 626 minecraft:light_gray_concrete
fill 48 266 629 49 266 634 minecraft:light_gray_concrete
fill 48 266 637 49 266 642 minecraft:light_gray_concrete
fill 48 266 645 53 267 645 minecraft:light_gray_concrete
fill 49 266 606 49 266 612 minecraft:light_gray_concrete
fill 49 266 619 49 266 620 minecraft:light_gray_concrete
fill 49 266 627 49 266 628 minecraft:light_gray_concrete
fill 49 266 635 49 266 636 minecraft:light_gray_concrete
fill 49 266 643 49 266 644 minecraft:light_gray_concrete
fill 50 266 606 87 266 606 minecraft:light_gray_concrete
fill 50 266 644 63 266 644 minecraft:light_gray_concrete
fill 51 266 605 56 267 605 minecraft:light_gray_concrete
fill 56 266 645 61 267 645 minecraft:light_gray_concrete
fill 59 266 605 64 267 605 minecraft:light_gray_concrete
fill 64 266 637 64 267 637 minecraft:light_gray_concrete
fill 64 266 639 64 267 639 minecraft:light_gray_concrete
fill 64 266 641 64 267 641 minecraft:light_gray_concrete
fill 64 266 643 64 267 643 minecraft:light_gray_concrete
fill 64 266 645 64 267 645 minecraft:light_gray_concrete
fill 65 266 616 65 267 616 minecraft:glass
fill 65 266 636 65 267 636 minecraft:light_gray_concrete
fill 65 266 638 65 267 638 minecraft:light_gray_concrete
fill 65 266 640 65 267 640 minecraft:light_gray_concrete
fill 65 266 642 65 267 642 minecraft:light_gray_concrete
fill 65 266 644 65 267 644 minecraft:light_gray_concrete
fill 66 266 637 66 267 637 minecraft:light_gray_concrete
fill 66 266 639 66 267 639 minecraft:light_gray_concrete
fill 66 266 641 66 267 641 minecraft:light_gray_concrete
fill 66 266 643 66 267 643 minecraft:light_gray_concrete
fill 66 266 645 66 267 645 minecraft:light_gray_concrete
fill 67 266 605 72 267 605 minecraft:light_gray_concrete
fill 67 266 636 67 267 636 minecraft:light_gray_concrete
fill 67 266 638 67 267 638 minecraft:light_gray_concrete
fill 67 266 640 67 267 640 minecraft:light_gray_concrete
fill 67 266 642 67 267 642 minecraft:light_gray_concrete
fill 67 266 644 67 267 644 minecraft:light_gray_concrete
fill 68 266 637 68 267 637 minecraft:light_gray_concrete
fill 68 266 639 68 267 639 minecraft:light_gray_concrete
fill 68 266 641 68 267 641 minecraft:light_gray_concrete
fill 68 266 643 68 267 643 minecraft:light_gray_concrete
fill 68 266 645 68 267 645 minecraft:light_gray_concrete
fill 69 266 636 69 267 636 minecraft:light_gray_concrete
fill 69 266 638 69 267 638 minecraft:light_gray_concrete
fill 69 266 640 69 267 640 minecraft:light_gray_concrete
fill 69 266 642 69 267 642 minecraft:light_gray_concrete
fill 69 266 644 69 267 644 minecraft:light_gray_concrete
fill 70 266 637 70 267 637 minecraft:light_gray_concrete
fill 70 266 639 70 267 639 minecraft:light_gray_concrete
fill 70 266 641 70 267 641 minecraft:light_gray_concrete
fill 70 266 643 70 267 643 minecraft:light_gray_concrete
fill 70 266 645 70 267 645 minecraft:light_gray_concrete
fill 71 266 636 71 267 636 minecraft:light_gray_concrete
fill 71 266 638 71 267 638 minecraft:light_gray_concrete
fill 71 266 640 71 267 640 minecraft:light_gray_concrete
fill 71 266 642 71 267 642 minecraft:light_gray_concrete
fill 71 266 644 71 267 644 minecraft:light_gray_concrete
fill 72 266 637 72 267 637 minecraft:light_gray_concrete
fill 72 266 639 72 267 639 minecraft:light_gray_concrete
fill 72 266 641 72 267 641 minecraft:light_gray_concrete
fill 72 266 643 72 267 643 minecraft:light_gray_concrete
fill 72 266 645 72 267 645 minecraft:light_gray_concrete
fill 73 266 636 73 267 636 minecraft:light_gray_concrete
fill 73 266 638 73 267 638 minecraft:light_gray_concrete
fill 73 266 640 73 267 640 minecraft:light_gray_concrete
fill 73 266 642 73 267 642 minecraft:light_gray_concrete
fill 73 266 644 73 267 644 minecraft:light_gray_concrete
fill 74 266 637 74 267 637 minecraft:light_gray_concrete
fill 74 266 639 74 267 639 minecraft:light_gray_concrete
fill 74 266 641 74 267 641 minecraft:light_gray_concrete
fill 74 266 643 74 267 643 minecraft:light_gray_concrete
fill 74 266 645 77 267 645 minecraft:light_gray_concrete
fill 75 266 605 80 267 605 minecraft:light_gray_concrete
fill 75 266 644 88 266 644 minecraft:light_gray_concrete
fill 80 266 645 85 267 645 minecraft:light_gray_concrete
fill 83 266 605 88 267 605 minecraft:light_gray_concrete
fill 87 266 607 87 266 643 minecraft:light_gray_concrete
fill 88 266 608 88 267 613 minecraft:light_gray_concrete
fill 88 266 616 88 267 621 minecraft:light_gray_concrete
fill 88 266 624 88 267 629 minecraft:light_gray_concrete
fill 88 266 632 88 267 637 minecraft:light_gray_concrete
fill 88 266 640 88 267 643 minecraft:light_gray_concrete
fill 88 266 645 88 267 645 minecraft:light_gray_concrete
fill 48 267 613 48 267 618 minecraft:light_gray_concrete
fill 48 267 621 48 267 626 minecraft:light_gray_concrete
fill 48 267 629 48 267 634 minecraft:light_gray_concrete
fill 48 267 637 48 267 642 minecraft:light_gray_concrete
setblock 88 267 644 minecraft:light_gray_concrete
setblock 64 268 637 minecraft:sea_lantern
setblock 64 268 639 minecraft:sea_lantern
setblock 64 268 641 minecraft:sea_lantern
setblock 64 268 643 minecraft:sea_lantern
setblock 64 268 645 minecraft:sea_lantern
setblock 65 268 636 minecraft:sea_lantern
setblock 65 268 638 minecraft:sea_lantern
setblock 65 268 640 minecraft:sea_lantern
setblock 65 268 642 minecraft:sea_lantern
setblock 65 268 644 minecraft:sea_lantern
setblock 66 268 637 minecraft:sea_lantern
setblock 66 268 639 minecraft:sea_lantern
setblock 66 268 641 minecraft:sea_lantern
setblock 66 268 643 minecraft:sea_lantern
setblock 66 268 645 minecraft:sea_lantern
setblock 67 268 636 minecraft:sea_lantern
setblock 67 268 638 minecraft:sea_lantern
setblock 67 268 640 minecraft:sea_lantern
setblock 67 268 642 minecraft:sea_lantern
setblock 67 268 644 minecraft:sea_lantern
setblock 68 268 637 minecraft:sea_lantern
setblock 68 268 639 minecraft:sea_lantern
setblock 68 268 641 minecraft:sea_lantern
setblock 68 268 643 minecraft:sea_lantern
setblock 68 268 645 minecraft:sea_lantern
setblock 69 268 636 minecraft:sea_lantern
setblock 69 268 638 minecraft:sea_lantern
setblock 69 268 640 minecraft:sea_lantern
setblock 69 268 642 minecraft:sea_lantern
setblock 69 268 644 minecraft:sea_lantern
setblock 70 268 637 minecraft:sea_lantern
setblock 70 268 639 minecraft:sea_lantern
setblock 70 268 641 minecraft:sea_lantern
setblock 70 268 643 minecraft:sea_lantern
setblock 70 268 645 minecraft:sea_lantern
setblock 71 268 636 minecraft:sea_lantern
setblock 71 268 638 minecraft:sea_lantern
setblock 71 268 640 minecraft:sea_lantern
setblock 71 268 642 minecraft:sea_lantern
setblock 71 268 644 minecraft:sea_lantern
setblock 72 268 637 minecraft:sea_lantern
setblock 72 268 639 minecraft:sea_lantern
setblock 72 268 641 minecraft:sea_lantern
setblock 72 268 643 minecraft:sea_lantern
setblock 72 268 645 minecraft:sea_lantern
setblock 73 268 636 minecraft:sea_lantern
setblock 73 268 638 minecraft:sea_lantern
setblock 73 268 640 minecraft:sea_lantern
setblock 73 268 642 minecraft:sea_lantern
setblock 73 268 644 minecraft:sea_lantern
setblock 74 268 637 minecraft:sea_lantern
setblock 74 268 639 minecraft:sea_lantern
setblock 74 268 641 minecraft:sea_lantern
setblock 74 268 643 minecraft:sea_lantern
setblock 74 268 645 minecraft:sea_lantern
fill 64 269 637 64 270 637 minecraft:light_gray_concrete
fill 64 269 639 64 270 639 minecraft:light_gray_concrete
fill 64 269 641 64 270 641 minecraft:light_gray_concrete
fill 64 269 643 64 270 643 minecraft:light_gray_concrete
fill 64 269 645 64 270 645 minecraft:light_gray_concrete
fill 65 269 636 65 270 636 minecraft:light_gray_concrete
fill 65 269 638 65 270 638 minecraft:light_gray_concrete
fill 65 269 640 65 270 640 minecraft:light_gray_concrete
fill 65 269 642 65 270 642 minecraft:light_gray_concrete
fill 65 269 644 65 270 644 minecraft:light_gray_concrete
fill 66 269 637 66 270 637 minecraft:light_gray_concrete
fill 66 269 639 66 270 639 minecraft:light_gray_concrete
fill 66 269 641 66 270 641 minecraft:light_gray_concrete
fill 66 269 643 66 270 643 minecraft:light_gray_concrete
fill 66 269 645 66 270 645 minecraft:light_gray_concrete
fill 67 269 636 67 270 636 minecraft:light_gray_concrete
fill 67 269 638 67 270 638 minecraft:light_gray_concrete
fill 67 269 640 67 270 640 minecraft:light_gray_concrete
fill 67 269 642 67 270 642 minecraft:light_gray_concrete
fill 67 269 644 67 270 644 minecraft:light_gray_concrete
fill 68 269 637 68 270 637 minecraft:light_gray_concrete
fill 68 269 639 68 270 639 minecraft:light_gray_concrete
fill 68 269 641 68 270 641 minecraft:light_gray_concrete
fill 68 269 643 68 270 643 minecraft:light_gray_concrete
fill 68 269 645 68 270 645 minecraft:light_gray_concrete
fill 69 269 636 69 270 636 minecraft:light_gray_concrete
fill 69 269 638 69 270 638 minecraft:light_gray_concrete
fill 69 269 640 69 270 640 minecraft:light_gray_concrete
fill 69 269 642 69 270 642 minecraft:light_gray_concrete
fill 69 269 644 69 270 644 minecraft:light_gray_concrete
fill 70 269 637 70 270 637 minecraft:light_gray_concrete
fill 70 269 639 70 270 639 minecraft:light_gray_concrete
fill 70 269 641 70 270 641 minecraft:light_gray_concrete
fill 70 269 643 70 270 643 minecraft:light_gray_concrete
fill 70 269 645 70 270 645 minecraft:light_gray_concrete
fill 71 269 636 71 270 636 minecraft:light_gray_concrete
fill 71 269 638 71 270 638 minecraft:light_gray_concrete
fill 71 269 640 71 270 640 minecraft:light_gray_concrete
fill 71 269 642 71 270 642 minecraft:light_gray_concrete
fill 71 269 644 71 270 644 minecraft:light_gray_concrete
fill 72 269 637 72 270 637 minecraft:light_gray_concrete
fill 72 269 639 72 270 639 minecraft:light_gray_concrete
fill 72 269 641 72 270 641 minecraft:light_gray_concrete
fill 72 269 643 72 270 643 minecraft:light_gray_concrete
fill 72 269 645 72 270 645 minecraft:light_gray_concrete
fill 73 269 636 73 270 636 minecraft:light_gray_concrete
fill 73 269 638 73 270 638 minecraft:light_gray_concrete
fill 73 269 640 73 270 640 minecraft:light_gray_concrete
fill 73 269 642 73 270 642 minecraft:light_gray_concrete
fill 73 269 644 73 270 644 minecraft:light_gray_concrete
fill 74 269 637 74 270 637 minecraft:light_gray_concrete
fill 74 269 639 74 270 639 minecraft:light_gray_concrete
fill 74 269 641 74 270 641 minecraft:light_gray_concrete
fill 74 269 643 74 270 643 minecraft:light_gray_concrete
fill 74 269 645 74 270 645 minecraft:light_gray_concrete
fill 47 270 609 47 273 609 minecraft:sea_lantern
fill 47 270 617 47 273 617 minecraft:sea_lantern
fill 47 270 625 47 273 625 minecraft:sea_lantern
fill 47 270 633 47 273 633 minecraft:sea_lantern
fill 47 270 641 47 273 641 minecraft:sea_lantern
fill 50 270 646 50 273 646 minecraft:sea_lantern
fill 54 270 604 54 273 604 minecraft:sea_lantern
fill 58 270 646 58 273 646 minecraft:sea_lantern
fill 62 270 604 62 273 604 minecraft:sea_lantern
fill 66 270 646 66 273 646 minecraft:sea_lantern
fill 70 270 604 70 273 604 minecraft:sea_lantern
fill 74 270 646 74 273 646 minecraft:sea_lantern
fill 78 270 604 78 273 604 minecraft:sea_lantern
fill 82 270 646 82 273 646 minecraft:sea_lantern
fill 86 270 604 86 273 604 minecraft:sea_lantern
fill 89 270 609 89 273 609 minecraft:sea_lantern
fill 89 270 617 89 273 617 minecraft:sea_lantern
fill 89 270 625 89 273 625 minecraft:sea_lantern
fill 89 270 633 89 273 633 minecraft:sea_lantern
fill 89 270 641 89 273 641 minecraft:sea_lantern
setblock 64 271 637 minecraft:sea_lantern
setblock 64 271 639 minecraft:sea_lantern
setblock 64 271 641 minecraft:sea_lantern
setblock 64 271 643 minecraft:sea_lantern
setblock 64 271 645 minecraft:sea_lantern
setblock 65 271 636 minecraft:sea_lantern
setblock 65 271 638 minecraft:sea_lantern
setblock 65 271 640 minecraft:sea_lantern
setblock 65 271 642 minecraft:sea_lantern
setblock 65 271 644 minecraft:sea_lantern
setblock 66 271 637 minecraft:sea_lantern
setblock 66 271 639 minecraft:sea_lantern
setblock 66 271 641 minecraft:sea_lantern
setblock 66 271 643 minecraft:sea_lantern
setblock 66 271 645 minecraft:sea_lantern
setblock 67 271 636 minecraft:sea_lantern
setblock 67 271 638 minecraft:sea_lantern
setblock 67 271 640 minecraft:sea_lantern
setblock 67 271 642 minecraft:sea_lantern
setblock 67 271 644 minecraft:sea_lantern
setblock 68 271 637 minecraft:sea_lantern
setblock 68 271 639 minecraft:sea_lantern
setblock 68 271 641 minecraft:sea_lantern
setblock 68 271 643 minecraft:sea_lantern
setblock 68 271 645 minecraft:sea_lantern
setblock 69 271 636 minecraft:sea_lantern
setblock 69 271 638 minecraft:sea_lantern
setblock 69 271 640 minecraft:sea_lantern
setblock 69 271 642 minecraft:sea_lantern
setblock 69 271 644 minecraft:sea_lantern
setblock 70 271 637 minecraft:sea_lantern
setblock 70 271 639 minecraft:sea_lantern
setblock 70 271 641 minecraft:sea_lantern
setblock 70 271 643 minecraft:sea_lantern
setblock 70 271 645 minecraft:sea_lantern
setblock 71 271 636 minecraft:sea_lantern
setblock 71 271 638 minecraft:sea_lantern
setblock 71 271 640 minecraft:sea_lantern
setblock 71 271 642 minecraft:sea_lantern
setblock 71 271 644 minecraft:sea_lantern
setblock 72 271 637 minecraft:sea_lantern
setblock 72 271 639 minecraft:sea_lantern
setblock 72 271 641 minecraft:sea_lantern
setblock 72 271 643 minecraft:sea_lantern
setblock 72 271 645 minecraft:sea_lantern
setblock 73 271 636 minecraft:sea_lantern
setblock 73 271 638 minecraft:sea_lantern
setblock 73 271 640 minecraft:sea_lantern
setblock 73 271 642 minecraft:sea_lantern
setblock 73 271 644 minecraft:sea_lantern
setblock 74 271 637 minecraft:sea_lantern
setblock 74 271 639 minecraft:sea_lantern
setblock 74 271 641 minecraft:sea_lantern
setblock 74 271 643 minecraft:sea_lantern
setblock 74 271 645 minecraft:sea_lantern
setblock 50 272 607 minecraft:light[level=14]
setblock 50 272 615 minecraft:light[level=14]
setblock 50 272 623 minecraft:light[level=14]
setblock 50 272 631 minecraft:light[level=14]
setblock 50 272 639 minecraft:light[level=14]
setblock 58 272 607 minecraft:light[level=14]
setblock 58 272 615 minecraft:light[level=14]
setblock 58 272 623 minecraft:light[level=14]
setblock 58 272 631 minecraft:light[level=14]
setblock 58 272 639 minecraft:light[level=14]
fill 64 272 637 64 273 637 minecraft:light_gray_concrete
fill 64 272 639 64 273 639 minecraft:light_gray_concrete
fill 64 272 641 64 273 641 minecraft:light_gray_concrete
fill 64 272 643 64 273 643 minecraft:light_gray_concrete
fill 64 272 645 64 273 645 minecraft:light_gray_concrete
fill 65 272 636 65 273 636 minecraft:light_gray_concrete
fill 65 272 638 65 273 638 minecraft:light_gray_concrete
fill 65 272 640 65 273 640 minecraft:light_gray_concrete
fill 65 272 642 65 273 642 minecraft:light_gray_concrete
fill 65 272 644 65 273 644 minecraft:light_gray_concrete
setblock 66 272 607 minecraft:light[level=14]
setblock 66 272 615 minecraft:light[level=14]
setblock 66 272 623 minecraft:light[level=14]
setblock 66 272 631 minecraft:light[level=14]
fill 66 272 637 66 273 637 minecraft:light_gray_concrete
fill 66 272 639 66 273 639 minecraft:light_gray_concrete
fill 66 272 641 66 273 641 minecraft:light_gray_concrete
fill 66 272 643 66 273 643 minecraft:light_gray_concrete
fill 66 272 645 66 273 645 minecraft:light_gray_concrete
fill 67 272 636 67 273 636 minecraft:light_gray_concrete
fill 67 272 638 67 273 638 minecraft:light_gray_concrete
fill 67 272 640 67 273 640 minecraft:light_gray_concrete
fill 67 272 642 67 273 642 minecraft:light_gray_concrete
fill 67 272 644 67 273 644 minecraft:light_gray_concrete
fill 68 272 637 68 273 637 minecraft:light_gray_concrete
fill 68 272 639 68 273 639 minecraft:light_gray_concrete
fill 68 272 641 68 273 641 minecraft:light_gray_concrete
fill 68 272 643 68 273 643 minecraft:light_gray_concrete
fill 68 272 645 68 273 645 minecraft:light_gray_concrete
fill 69 272 636 69 273 636 minecraft:light_gray_concrete
fill 69 272 638 69 273 638 minecraft:light_gray_concrete
fill 69 272 640 69 273 640 minecraft:light_gray_concrete
fill 69 272 642 69 273 642 minecraft:light_gray_concrete
fill 69 272 644 69 273 644 minecraft:light_gray_concrete
fill 70 272 637 70 273 637 minecraft:light_gray_concrete
fill 70 272 639 70 273 639 minecraft:light_gray_concrete
fill 70 272 641 70 273 641 minecraft:light_gray_concrete
fill 70 272 643 70 273 643 minecraft:light_gray_concrete
fill 70 272 645 70 273 645 minecraft:light_gray_concrete
fill 71 272 636 71 273 636 minecraft:light_gray_concrete
fill 71 272 638 71 273 638 minecraft:light_gray_concrete
fill 71 272 640 71 273 640 minecraft:light_gray_concrete
fill 71 272 642 71 273 642 minecraft:light_gray_concrete
fill 71 272 644 71 273 644 minecraft:light_gray_concrete
fill 72 272 637 72 273 637 minecraft:light_gray_concrete
fill 72 272 639 72 273 639 minecraft:light_gray_concrete
fill 72 272 641 72 273 641 minecraft:light_gray_concrete
fill 72 272 643 72 273 643 minecraft:light_gray_concrete
fill 72 272 645 72 273 645 minecraft:light_gray_concrete
fill 73 272 636 73 273 636 minecraft:light_gray_concrete
fill 73 272 638 73 273 638 minecraft:light_gray_concrete
fill 73 272 640 73 273 640 minecraft:light_gray_concrete
fill 73 272 642 73 273 642 minecraft:light_gray_concrete
fill 73 272 644 73 273 644 minecraft:light_gray_concrete
setblock 74 272 607 minecraft:light[level=14]
setblock 74 272 615 minecraft:light[level=14]
setblock 74 272 623 minecraft:light[level=14]
setblock 74 272 631 minecraft:light[level=14]
fill 74 272 637 74 273 637 minecraft:light_gray_concrete
fill 74 272 639 74 273 639 minecraft:light_gray_concrete
fill 74 272 641 74 273 641 minecraft:light_gray_concrete
fill 74 272 643 74 273 643 minecraft:light_gray_concrete
fill 74 272 645 74 273 645 minecraft:light_gray_concrete
setblock 82 272 607 minecraft:light[level=14]
setblock 82 272 615 minecraft:light[level=14]
setblock 82 272 623 minecraft:light[level=14]
setblock 82 272 631 minecraft:light[level=14]
setblock 82 272 639 minecraft:light[level=14]
fill 47 274 609 47 283 609 minecraft:gray_concrete
fill 47 274 617 47 283 617 minecraft:gray_concrete
fill 47 274 625 47 283 625 minecraft:gray_concrete
fill 47 274 633 47 283 633 minecraft:gray_concrete
fill 47 274 641 47 283 641 minecraft:gray_concrete
fill 50 274 646 50 283 646 minecraft:gray_concrete
fill 54 274 604 54 283 604 minecraft:gray_concrete
fill 58 274 646 58 283 646 minecraft:gray_concrete
fill 62 274 604 62 283 604 minecraft:gray_concrete
fill 66 274 646 66 283 646 minecraft:gray_concrete
fill 70 274 604 70 283 604 minecraft:gray_concrete
fill 74 274 646 74 283 646 minecraft:gray_concrete
fill 78 274 604 78 283 604 minecraft:gray_concrete
fill 82 274 646 82 283 646 minecraft:gray_concrete
fill 86 274 604 86 283 604 minecraft:gray_concrete
fill 89 274 609 89 283 609 minecraft:gray_concrete
fill 89 274 617 89 283 617 minecraft:gray_concrete
fill 89 274 625 89 283 625 minecraft:gray_concrete
fill 89 274 633 89 283 633 minecraft:gray_concrete
fill 89 274 641 89 283 641 minecraft:gray_concrete
fill 61 278 628 63 278 630 minecraft:redstone_block
fill 68 278 621 70 278 623 minecraft:redstone_block
fill 68 278 627 70 278 629 minecraft:redstone_block
fill 48 279 605 48 280 615 minecraft:light_blue_concrete
fill 48 279 616 52 280 617 minecraft:white_concrete
fill 48 279 618 48 280 627 minecraft:light_blue_concrete
fill 48 279 628 52 280 629 minecraft:white_concrete
fill 48 279 630 48 280 640 minecraft:light_blue_concrete
fill 48 279 641 52 280 642 minecraft:white_concrete
fill 48 279 643 48 280 645 minecraft:light_blue_concrete
fill 49 279 605 52 280 605 minecraft:white_concrete
fill 49 279 606 49 280 614 minecraft:light_blue_concrete
fill 49 279 615 52 280 615 minecraft:white_concrete
fill 49 279 618 49 280 626 minecraft:light_blue_concrete
fill 49 279 627 52 280 627 minecraft:white_concrete
fill 49 279 630 52 280 630 minecraft:white_concrete
fill 49 279 631 55 280 639 minecraft:light_blue_concrete
fill 49 279 640 52 280 640 minecraft:white_concrete
fill 49 279 643 52 280 643 minecraft:white_concrete
fill 49 279 644 88 280 645 minecraft:light_blue_concrete
fill 50 279 606 55 280 613 minecraft:light_blue_concrete
fill 50 279 614 50 280 614 minecraft:white_concrete
fill 50 279 618 51 280 618 minecraft:white_concrete
fill 50 279 619 55 280 626 minecraft:light_blue_concrete
fill 51 279 614 65 280 614 minecraft:light_blue_concrete
fill 52 279 618 64 280 618 minecraft:light_blue_concrete
fill 53 279 605 64 280 605 minecraft:light_blue_concrete
fill 53 279 615 63 280 615 minecraft:light_blue_concrete
fill 53 279 616 53 280 616 minecraft:white_concrete
fill 53 279 617 63 280 617 minecraft:light_blue_concrete
fill 53 279 627 60 279 628 minecraft:light_blue_concrete
fill 53 279 629 53 280 629 minecraft:white_concrete
fill 53 279 630 60 279 630 minecraft:light_blue_concrete
fill 53 279 640 63 280 640 minecraft:light_blue_concrete
fill 53 279 641 53 280 641 minecraft:white_concrete
fill 53 279 642 63 280 643 minecraft:light_blue_concrete
fill 54 279 616 63 280 616 minecraft:light_blue_concrete
fill 54 279 629 60 279 629 minecraft:light_blue_concrete
fill 54 279 641 63 280 641 minecraft:light_blue_concrete
fill 56 279 606 56 280 608 minecraft:light_blue_concrete
fill 56 279 609 60 280 611 minecraft:white_concrete
fill 56 279 612 88 280 613 minecraft:light_blue_concrete
fill 56 279 619 56 280 621 minecraft:light_blue_concrete
fill 56 279 622 60 280 623 minecraft:white_concrete
fill 56 279 624 56 280 626 minecraft:light_blue_concrete
fill 56 279 631 56 280 633 minecraft:light_blue_concrete
fill 56 279 634 60 280 636 minecraft:white_concrete
fill 56 279 637 57 280 639 minecraft:light_blue_concrete
fill 57 279 606 88 280 607 minecraft:light_blue_concrete
fill 57 279 608 59 280 608 minecraft:white_concrete
fill 57 279 619 88 279 620 minecraft:light_blue_concrete
fill 57 279 621 60 280 621 minecraft:white_concrete
fill 57 279 624 60 280 624 minecraft:white_concrete
fill 57 279 625 63 279 626 minecraft:light_blue_concrete
fill 57 279 631 88 279 632 minecraft:light_blue_concrete
fill 57 279 633 59 280 633 minecraft:white_concrete
fill 58 279 637 58 280 637 minecraft:white_concrete
fill 58 279 638 88 280 639 minecraft:light_blue_concrete
fill 59 279 637 73 280 637 minecraft:light_blue_concrete
fill 60 279 608 72 280 608 minecraft:light_blue_concrete
fill 60 279 633 72 280 633 minecraft:light_blue_concrete
fill 61 279 609 71 280 611 minecraft:light_blue_concrete
fill 61 279 621 63 279 624 minecraft:light_blue_concrete
fill 61 279 627 64 279 627 minecraft:light_blue_concrete
fill 61 279 634 71 280 636 minecraft:light_blue_concrete
fill 64 279 615 68 280 617 minecraft:white_concrete
fill 64 279 621 67 279 623 minecraft:light_blue_concrete
fill 64 279 628 67 279 630 minecraft:white_concrete
fill 64 279 640 68 280 642 minecraft:white_concrete
fill 64 279 643 64 280 643 minecraft:light_blue_concrete
fill 65 279 605 68 280 605 minecraft:white_concrete
fill 65 279 618 67 280 618 minecraft:white_concrete
fill 65 279 627 67 279 627 minecraft:white_concrete
fill 65 279 643 67 280 643 minecraft:white_concrete
fill 66 279 614 66 280 614 minecraft:white_concrete
fill 67 279 614 81 280 614 minecraft:light_blue_concrete
fill 67 279 624 72 279 626 minecraft:light_blue_concrete
fill 68 279 618 80 280 618 minecraft:light_blue_concrete
setblock 68 279 630 minecraft:white_concrete
fill 68 279 643 80 280 643 minecraft:light_blue_concrete
fill 69 279 605 79 280 605 minecraft:light_blue_concrete
fill 69 279 615 79 280 617 minecraft:light_blue_concrete
fill 69 279 630 79 279 630 minecraft:light_blue_concrete
fill 69 279 640 79 280 642 minecraft:light_blue_concrete
fill 71 279 621 71 279 623 minecraft:light_blue_concrete
fill 71 279 627 79 279 629 minecraft:light_blue_concrete
fill 72 279 609 76 280 611 minecraft:white_concrete
fill 72 279 621 76 280 623 minecraft:white_concrete
fill 72 279 634 76 280 636 minecraft:white_concrete
fill 73 279 608 75 280 608 minecraft:white_concrete
fill 73 279 624 75 280 624 minecraft:white_concrete
fill 73 279 625 88 280 626 minecraft:light_blue_concrete
fill 73 279 633 75 280 633 minecraft:white_concrete
fill 74 279 637 74 280 637 minecraft:white_concrete
fill 75 279 637 88 280 637 minecraft:light_blue_concrete
fill 76 279 608 88 280 608 minecraft:light_blue_concrete
fill 76 279 624 87 280 624 minecraft:light_blue_concrete
fill 76 279 633 88 280 633 minecraft:light_blue_concrete
fill 77 279 609 87 280 611 minecraft:light_blue_concrete
fill 77 279 621 87 280 623 minecraft:light_blue_concrete
fill 77 279 634 87 280 636 minecraft:light_blue_concrete
fill 80 279 605 83 280 605 minecraft:white_concrete
fill 80 279 615 84 280 617 minecraft:white_concrete
fill 80 279 627 83 280 630 minecraft:white_concrete
fill 80 279 640 84 280 642 minecraft:white_concrete
fill 81 279 618 83 280 618 minecraft:white_concrete
fill 81 279 643 83 280 643 minecraft:white_concrete
fill 82 279 614 82 280 614 minecraft:white_concrete
fill 83 279 614 88 280 614 minecraft:light_blue_concrete
fill 84 279 605 88 280 605 minecraft:light_blue_concrete
fill 84 279 618 88 280 618 minecraft:light_blue_concrete
fill 84 279 627 88 280 627 minecraft:light_blue_concrete
fill 84 279 628 84 280 630 minecraft:white_concrete
fill 84 279 643 88 280 643 minecraft:light_blue_concrete
fill 85 279 615 88 280 617 minecraft:light_blue_concrete
fill 85 279 628 88 280 630 minecraft:light_blue_concrete
fill 85 279 640 88 280 642 minecraft:light_blue_concrete
fill 88 279 609 88 280 611 minecraft:white_concrete
fill 88 279 621 88 280 624 minecraft:white_concrete
fill 88 279 634 88 280 636 minecraft:white_concrete
fill 53 280 627 59 280 628 minecraft:light_blue_concrete
fill 53 280 630 59 280 630 minecraft:light_blue_concrete
fill 54 280 629 59 280 629 minecraft:light_blue_concrete
fill 57 280 619 66 280 620 minecraft:light_blue_concrete
fill 57 280 625 62 280 626 minecraft:light_blue_concrete
fill 57 280 631 59 280 632 minecraft:light_blue_concrete
fill 60 280 627 60 280 631 minecraft:sea_lantern
fill 60 280 632 88 280 632 minecraft:light_blue_concrete
fill 61 280 621 62 280 624 minecraft:light_blue_concrete
fill 61 280 627 67 280 627 minecraft:sea_lantern
fill 61 280 628 63 280 630 minecraft:light_blue_concrete
fill 61 280 631 64 280 631 minecraft:sea_lantern
fill 63 280 621 66 280 622 minecraft:light_blue_concrete
fill 63 280 623 63 280 626 minecraft:sea_lantern
fill 64 280 623 67 280 623 minecraft:sea_lantern
fill 64 280 628 64 280 630 minecraft:sea_lantern
fill 65 280 628 66 280 630 minecraft:white_concrete
fill 65 280 631 88 280 631 minecraft:light_blue_concrete
fill 67 280 619 88 280 619 minecraft:light_blue_concrete
fill 67 280 620 67 280 622 minecraft:sea_lantern
fill 67 280 624 67 280 626 minecraft:sea_lantern
fill 67 280 628 67 280 630 minecraft:sea_lantern
fill 68 280 620 71 280 620 minecraft:sea_lantern
fill 68 280 621 70 280 623 minecraft:light_blue_concrete
fill 68 280 624 71 280 624 minecraft:sea_lantern
fill 68 280 625 72 280 625 minecraft:light_blue_concrete
fill 68 280 626 71 280 626 minecraft:sea_lantern
fill 68 280 627 70 280 629 minecraft:light_blue_concrete
fill 68 280 630 71 280 630 minecraft:sea_lantern
fill 71 280 621 71 280 623 minecraft:sea_lantern
fill 71 280 627 71 280 629 minecraft:sea_lantern
fill 72 280 620 88 280 620 minecraft:light_blue_concrete
setblock 72 280 624 minecraft:light_blue_concrete
fill 72 280 626 72 280 630 minecraft:light_blue_concrete
fill 73 280 627 79 280 630 minecraft:light_blue_concrete
fill 47 284 609 47 289 609 minecraft:sea_lantern
fill 47 284 617 47 289 617 minecraft:sea_lantern
fill 47 284 625 47 289 625 minecraft:sea_lantern
fill 47 284 633 47 289 633 minecraft:sea_lantern
fill 47 284 641 47 289 641 minecraft:sea_lantern
fill 48 284 611 48 300 612 minecraft:light_gray_concrete
fill 48 284 619 48 300 620 minecraft:light_gray_concrete
fill 48 284 627 48 300 628 minecraft:light_gray_concrete
fill 48 284 635 48 300 636 minecraft:light_gray_concrete
fill 48 284 643 48 300 644 minecraft:light_gray_concrete
fill 49 284 605 50 300 605 minecraft:light_gray_concrete
fill 50 284 646 50 289 646 minecraft:sea_lantern
fill 54 284 604 54 289 604 minecraft:sea_lantern
fill 54 284 645 55 300 645 minecraft:light_gray_concrete
fill 57 284 605 58 300 605 minecraft:light_gray_concrete
fill 58 284 646 58 289 646 minecraft:sea_lantern
fill 60 284 605 70 285 613 minecraft:light_gray_concrete
fill 62 284 604 62 289 604 minecraft:sea_lantern
fill 62 284 645 63 291 645 minecraft:light_gray_concrete
fill 63 284 640 63 289 640 minecraft:magenta_concrete
fill 66 284 646 66 289 646 minecraft:sea_lantern
fill 70 284 604 70 289 604 minecraft:sea_lantern
fill 70 284 645 71 300 645 minecraft:light_gray_concrete
fill 73 284 605 74 300 605 minecraft:light_gray_concrete
fill 74 284 638 82 285 645 minecraft:light_gray_concrete
fill 74 284 646 74 289 646 minecraft:sea_lantern
fill 78 284 604 78 289 604 minecraft:sea_lantern
fill 79 284 606 88 294 614 minecraft:light_gray_concrete
fill 81 284 605 82 300 605 minecraft:light_gray_concrete
fill 82 284 646 82 289 646 minecraft:sea_lantern
fill 85 284 626 86 287 626 minecraft:magenta_concrete
fill 86 284 604 86 289 604 minecraft:sea_lantern
fill 86 284 645 87 300 645 minecraft:light_gray_concrete
fill 88 284 615 88 300 615 minecraft:light_gray_concrete
fill 88 284 622 88 288 623 minecraft:light_gray_concrete
fill 88 284 630 88 288 631 minecraft:light_gray_concrete
fill 88 284 638 88 300 639 minecraft:light_gray_concrete
fill 89 284 609 89 289 609 minecraft:sea_lantern
fill 89 284 617 89 289 617 minecraft:sea_lantern
fill 89 284 625 89 289 625 minecraft:sea_lantern
fill 89 284 633 89 289 633 minecraft:sea_lantern
fill 89 284 641 89 289 641 minecraft:sea_lantern
fill 62 285 640 62 289 640 minecraft:magenta_concrete
fill 63 285 639 63 289 639 minecraft:magenta_concrete
fill 64 285 640 64 289 640 minecraft:magenta_concrete
fill 57 286 634 57 287 635 minecraft:magenta_concrete
setblock 60 286 605 minecraft:sea_lantern
fill 60 286 606 60 300 606 minecraft:light_gray_concrete
setblock 60 286 607 minecraft:sea_lantern
fill 60 286 608 60 300 608 minecraft:light_gray_concrete
setblock 60 286 609 minecraft:sea_lantern
fill 60 286 610 60 300 610 minecraft:light_gray_concrete
setblock 60 286 611 minecraft:sea_lantern
fill 60 286 612 60 300 612 minecraft:light_gray_concrete
setblock 60 286 613 minecraft:sea_lantern
fill 61 286 605 61 300 605 minecraft:light_gray_concrete
setblock 61 286 606 minecraft:sea_lantern
fill 61 286 607 61 300 607 minecraft:light_gray_concrete
setblock 61 286 608 minecraft:sea_lantern
fill 61 286 609 61 300 609 minecraft:light_gray_concrete
setblock 61 286 610 minecraft:sea_lantern
fill 61 286 611 61 300 611 minecraft:light_gray_concrete
setblock 61 286 612 minecraft:sea_lantern
fill 61 286 613 61 300 613 minecraft:light_gray_concrete
setblock 62 286 605 minecraft:sea_lantern
fill 62 286 606 62 300 606 minecraft:light_gray_concrete
setblock 62 286 607 minecraft:sea_lantern
fill 62 286 608 62 300 608 minecraft:light_gray_concrete
setblock 62 286 609 minecraft:sea_lantern
fill 62 286 610 62 300 610 minecraft:light_gray_concrete
setblock 62 286 611 minecraft:sea_lantern
fill 62 286 612 62 300 612 minecraft:light_gray_concrete
setblock 62 286 613 minecraft:sea_lantern
fill 62 286 639 62 289 639 minecraft:magenta_concrete
fill 62 286 641 64 289 641 minecraft:magenta_concrete
fill 63 286 605 63 300 605 minecraft:light_gray_concrete
setblock 63 286 606 minecraft:sea_lantern
fill 63 286 607 63 300 607 minecraft:light_gray_concrete
setblock 63 286 608 minecraft:sea_lantern
fill 63 286 609 63 300 609 minecraft:light_gray_concrete
setblock 63 286 610 minecraft:sea_lantern
fill 63 286 611 63 300 611 minecraft:light_gray_concrete
setblock 63 286 612 minecraft:sea_lantern
fill 63 286 613 63 300 613 minecraft:light_gray_concrete
fill 63 286 638 63 289 638 minecraft:magenta_concrete
setblock 64 286 605 minecraft:sea_lantern
fill 64 286 606 64 300 606 minecraft:light_gray_concrete
setblock 64 286 607 minecraft:sea_lantern
fill 64 286 608 64 300 608 minecraft:light_gray_concrete
setblock 64 286 609 minecraft:sea_lantern
fill 64 286 610 64 300 610 minecraft:light_gray_concrete
setblock 64 286 611 minecraft:sea_lantern
fill 64 286 612 64 300 612 minecraft:light_gray_concrete
setblock 64 286 613 minecraft:sea_lantern
fill 64 286 639 64 289 639 minecraft:magenta_concrete
fill 65 286 605 65 300 605 minecraft:light_gray_concrete
setblock 65 286 606 minecraft:sea_lantern
fill 65 286 607 65 300 607 minecraft:light_gray_concrete
setblock 65 286 608 minecraft:sea_lantern
fill 65 286 609 65 300 609 minecraft:light_gray_concrete
setblock 65 286 610 minecraft:sea_lantern
fill 65 286 611 65 300 611 minecraft:light_gray_concrete
setblock 65 286 612 minecraft:sea_lantern
fill 65 286 613 65 300 613 minecraft:light_gray_concrete
setblock 66 286 605 minecraft:sea_lantern
fill 66 286 606 66 300 606 minecraft:light_gray_concrete
setblock 66 286 607 minecraft:sea_lantern
fill 66 286 608 66 300 608 minecraft:light_gray_concrete
setblock 66 286 609 minecraft:sea_lantern
fill 66 286 610 66 300 610 minecraft:light_gray_concrete
setblock 66 286 611 minecraft:sea_lantern
fill 66 286 612 66 300 612 minecraft:light_gray_concrete
setblock 66 286 613 minecraft:sea_lantern
fill 66 286 635 66 287 636 minecraft:gray_concrete
fill 67 286 605 67 300 605 minecraft:light_gray_concrete
setblock 67 286 606 minecraft:sea_lantern
fill 67 286 607 67 300 607 minecraft:light_gray_concrete
setblock 67 286 608 minecraft:sea_lantern
fill 67 286 609 67 300 609 minecraft:light_gray_concrete
setblock 67 286 610 minecraft:sea_lantern
fill 67 286 611 67 300 611 minecraft:light_gray_concrete
setblock 67 286 612 minecraft:sea_lantern
fill 67 286 613 67 300 613 minecraft:light_gray_concrete
setblock 68 286 605 minecraft:sea_lantern
fill 68 286 606 68 300 606 minecraft:light_gray_concrete
setblock 68 286 607 minecraft:sea_lantern
fill 68 286 608 68 300 608 minecraft:light_gray_concrete
setblock 68 286 609 minecraft:sea_lantern
fill 68 286 610 68 300 610 minecraft:light_gray_concrete
setblock 68 286 611 minecraft:sea_lantern
fill 68 286 612 68 300 612 minecraft:light_gray_concrete
setblock 68 286 613 minecraft:sea_lantern
fill 69 286 605 69 300 605 minecraft:light_gray_concrete
setblock 69 286 606 minecraft:sea_lantern
fill 69 286 607 69 300 607 minecraft:light_gray_concrete
setblock 69 286 608 minecraft:sea_lantern
fill 69 286 609 69 300 609 minecraft:light_gray_concrete
setblock 69 286 610 minecraft:sea_lantern
fill 69 286 611 69 300 611 minecraft:light_gray_concrete
setblock 69 286 612 minecraft:sea_lantern
fill 69 286 613 69 300 613 minecraft:light_gray_concrete
setblock 70 286 605 minecraft:sea_lantern
fill 70 286 606 70 300 606 minecraft:light_gray_concrete
setblock 70 286 607 minecraft:sea_lantern
fill 70 286 608 70 300 608 minecraft:light_gray_concrete
setblock 70 286 609 minecraft:sea_lantern
fill 70 286 610 70 300 610 minecraft:light_gray_concrete
setblock 70 286 611 minecraft:sea_lantern
fill 70 286 612 70 300 612 minecraft:light_gray_concrete
setblock 70 286 613 minecraft:sea_lantern
fill 74 286 638 74 300 638 minecraft:light_gray_concrete
setblock 74 286 639 minecraft:sea_lantern
fill 74 286 640 74 300 640 minecraft:light_gray_concrete
setblock 74 286 641 minecraft:sea_lantern
fill 74 286 642 74 300 642 minecraft:light_gray_concrete
setblock 74 286 643 minecraft:sea_lantern
fill 74 286 644 74 300 644 minecraft:light_gray_concrete
setblock 74 286 645 minecraft:sea_lantern
setblock 75 286 638 minecraft:sea_lantern
fill 75 286 639 75 300 639 minecraft:light_gray_concrete
setblock 75 286 640 minecraft:sea_lantern
fill 75 286 641 75 300 641 minecraft:light_gray_concrete
setblock 75 286 642 minecraft:sea_lantern
fill 75 286 643 75 300 643 minecraft:light_gray_concrete
setblock 75 286 644 minecraft:sea_lantern
fill 75 286 645 75 300 645 minecraft:light_gray_concrete
fill 76 286 638 76 300 638 minecraft:light_gray_concrete
setblock 76 286 639 minecraft:sea_lantern
fill 76 286 640 76 300 640 minecraft:light_gray_concrete
setblock 76 286 641 minecraft:sea_lantern
fill 76 286 642 76 300 642 minecraft:light_gray_concrete
setblock 76 286 643 minecraft:sea_lantern
fill 76 286 644 76 300 644 minecraft:light_gray_concrete
setblock 76 286 645 minecraft:sea_lantern
setblock 77 286 638 minecraft:sea_lantern
fill 77 286 639 77 300 639 minecraft:light_gray_concrete
setblock 77 286 640 minecraft:sea_lantern
fill 77 286 641 77 300 641 minecraft:light_gray_concrete
setblock 77 286 642 minecraft:sea_lantern
fill 77 286 643 77 300 643 minecraft:light_gray_concrete
setblock 77 286 644 minecraft:sea_lantern
fill 77 286 645 77 300 645 minecraft:light_gray_concrete
fill 78 286 638 78 300 638 minecraft:light_gray_concrete
setblock 78 286 639 minecraft:sea_lantern
fill 78 286 640 78 300 640 minecraft:light_gray_concrete
setblock 78 286 641 minecraft:sea_lantern
fill 78 286 642 78 300 642 minecraft:light_gray_concrete
setblock 78 286 643 minecraft:sea_lantern
fill 78 286 644 78 300 644 minecraft:light_gray_concrete
setblock 78 286 645 minecraft:sea_lantern
setblock 79 286 638 minecraft:sea_lantern
fill 79 286 639 79 300 639 minecraft:light_gray_concrete
setblock 79 286 640 minecraft:sea_lantern
fill 79 286 641 79 300 641 minecraft:light_gray_concrete
setblock 79 286 642 minecraft:sea_lantern
fill 79 286 643 79 300 643 minecraft:light_gray_concrete
setblock 79 286 644 minecraft:sea_lantern
fill 79 286 645 79 300 645 minecraft:light_gray_concrete
fill 80 286 638 80 300 638 minecraft:light_gray_concrete
setblock 80 286 639 minecraft:sea_lantern
fill 80 286 640 80 300 640 minecraft:light_gray_concrete
setblock 80 286 641 minecraft:sea_lantern
fill 80 286 642 80 300 642 minecraft:light_gray_concrete
setblock 80 286 643 minecraft:sea_lantern
fill 80 286 644 80 300 644 minecraft:light_gray_concrete
setblock 80 286 645 minecraft:sea_lantern
setblock 81 286 638 minecraft:sea_lantern
fill 81 286 639 81 300 639 minecraft:light_gray_concrete
setblock 81 286 640 minecraft:sea_lantern
fill 81 286 641 81 300 641 minecraft:light_gray_concrete
setblock 81 286 642 minecraft:sea_lantern
fill 81 286 643 81 300 643 minecraft:light_gray_concrete
setblock 81 286 644 minecraft:sea_lantern
fill 81 286 645 81 300 645 minecraft:light_gray_concrete
fill 82 286 638 82 300 638 minecraft:light_gray_concrete
setblock 82 286 639 minecraft:sea_lantern
fill 82 286 640 82 300 640 minecraft:light_gray_concrete
setblock 82 286 641 minecraft:sea_lantern
fill 82 286 642 82 300 642 minecraft:light_gray_concrete
setblock 82 286 643 minecraft:sea_lantern
fill 82 286 644 82 300 644 minecraft:light_gray_concrete
setblock 82 286 645 minecraft:sea_lantern
fill 85 286 625 86 287 625 minecraft:magenta_concrete
fill 85 286 627 86 287 627 minecraft:magenta_concrete
fill 87 286 626 87 287 626 minecraft:magenta_concrete
fill 60 287 605 60 288 605 minecraft:light_gray_concrete
fill 60 287 607 60 288 607 minecraft:light_gray_concrete
fill 60 287 609 60 288 609 minecraft:light_gray_concrete
fill 60 287 611 60 288 611 minecraft:light_gray_concrete
fill 60 287 613 60 288 613 minecraft:light_gray_concrete
schedule function dropper:buildpart/145_4 1t
