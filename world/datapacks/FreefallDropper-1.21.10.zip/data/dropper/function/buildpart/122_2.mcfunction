setblock 108 21 513 minecraft:blackstone
fill 108 21 550 108 24 550 minecraft:blackstone
setblock 109 21 513 minecraft:smooth_basalt
setblock 110 21 512 minecraft:smooth_basalt
fill 110 21 513 110 22 513 minecraft:blackstone
setblock 111 21 511 minecraft:smooth_basalt
fill 111 21 512 111 24 512 minecraft:blackstone
setblock 111 21 551 minecraft:smooth_basalt
fill 112 21 511 112 24 511 minecraft:blackstone
setblock 112 21 550 minecraft:smooth_basalt
fill 112 21 551 112 24 551 minecraft:blackstone
setblock 113 21 513 minecraft:light[level=12]
setblock 113 21 521 minecraft:light[level=12]
setblock 113 21 529 minecraft:light[level=12]
setblock 113 21 537 minecraft:light[level=12]
setblock 113 21 545 minecraft:light[level=12]
setblock 113 21 550 minecraft:blackstone
setblock 121 21 513 minecraft:light[level=12]
setblock 121 21 521 minecraft:light[level=12]
setblock 121 21 529 minecraft:light[level=12]
setblock 121 21 537 minecraft:light[level=12]
setblock 121 21 545 minecraft:light[level=12]
setblock 125 21 511 minecraft:blackstone
setblock 126 21 511 minecraft:smooth_basalt
fill 127 21 511 127 24 511 minecraft:blackstone
setblock 128 21 513 minecraft:blackstone
setblock 129 21 513 minecraft:smooth_basalt
setblock 129 21 521 minecraft:light[level=12]
setblock 129 21 529 minecraft:light[level=12]
setblock 129 21 537 minecraft:light[level=12]
setblock 130 21 512 minecraft:smooth_basalt
fill 130 21 513 130 24 513 minecraft:blackstone
setblock 131 21 511 minecraft:smooth_basalt
fill 131 21 512 131 24 512 minecraft:blackstone
fill 131 21 514 132 21 514 minecraft:blackstone
setblock 131 21 551 minecraft:smooth_basalt
fill 132 21 511 132 24 511 minecraft:blackstone
setblock 132 21 515 minecraft:smooth_basalt
fill 132 21 516 132 22 518 minecraft:blackstone
fill 132 21 551 132 23 551 minecraft:blackstone
setblock 133 21 514 minecraft:smooth_basalt
fill 133 21 515 133 24 515 minecraft:blackstone
fill 133 21 517 133 21 518 minecraft:blackstone
setblock 133 21 519 minecraft:smooth_basalt
fill 133 21 520 133 23 521 minecraft:blackstone
setblock 133 21 534 minecraft:smooth_basalt
fill 133 21 535 133 22 535 minecraft:blackstone
setblock 134 21 513 minecraft:smooth_basalt
fill 134 21 514 134 24 514 minecraft:blackstone
setblock 134 21 518 minecraft:smooth_basalt
fill 134 21 519 134 24 519 minecraft:blackstone
setblock 134 21 523 minecraft:smooth_basalt
fill 134 21 524 134 24 524 minecraft:blackstone
setblock 134 21 533 minecraft:smooth_basalt
fill 134 21 534 134 23 534 minecraft:blackstone
setblock 134 21 538 minecraft:smooth_basalt
fill 134 21 539 134 24 539 minecraft:blackstone
setblock 135 21 512 minecraft:smooth_basalt
fill 135 21 513 135 24 513 minecraft:blackstone
setblock 135 21 517 minecraft:smooth_basalt
fill 135 21 518 135 24 518 minecraft:blackstone
setblock 135 21 522 minecraft:smooth_basalt
fill 135 21 523 135 24 523 minecraft:blackstone
setblock 135 21 527 minecraft:smooth_basalt
fill 135 21 528 135 23 528 minecraft:blackstone
setblock 135 21 532 minecraft:smooth_basalt
fill 135 21 533 135 24 533 minecraft:blackstone
setblock 135 21 537 minecraft:smooth_basalt
fill 135 21 538 135 24 538 minecraft:blackstone
setblock 95 22 511 minecraft:smooth_basalt
fill 95 22 512 95 25 512 minecraft:blackstone
setblock 95 22 516 minecraft:smooth_basalt
fill 95 22 517 95 25 517 minecraft:blackstone
setblock 95 22 521 minecraft:smooth_basalt
fill 95 22 522 95 25 522 minecraft:blackstone
fill 95 22 533 95 23 533 minecraft:smooth_basalt
setblock 95 22 536 minecraft:smooth_basalt
fill 95 22 537 95 25 537 minecraft:blackstone
setblock 95 22 541 minecraft:smooth_basalt
fill 95 22 542 95 25 542 minecraft:blackstone
setblock 95 22 550 minecraft:blackstone
setblock 95 22 551 minecraft:smooth_basalt
fill 96 22 511 96 25 511 minecraft:blackstone
setblock 96 22 515 minecraft:smooth_basalt
fill 96 22 516 96 25 516 minecraft:blackstone
fill 96 22 522 96 23 522 minecraft:smooth_basalt
fill 96 22 551 96 25 551 minecraft:blackstone
setblock 99 22 512 minecraft:smooth_basalt
setblock 100 22 511 minecraft:smooth_basalt
fill 100 22 512 101 23 512 minecraft:blackstone
setblock 100 22 551 minecraft:smooth_basalt
fill 101 22 511 101 25 511 minecraft:blackstone
fill 101 22 551 101 25 551 minecraft:blackstone
setblock 104 22 511 minecraft:blackstone
setblock 104 22 512 minecraft:smooth_basalt
setblock 105 22 511 minecraft:smooth_basalt
fill 105 22 512 105 25 512 minecraft:blackstone
setblock 105 22 550 minecraft:blackstone
setblock 105 22 551 minecraft:smooth_basalt
fill 106 22 511 106 25 511 minecraft:blackstone
setblock 106 22 550 minecraft:smooth_basalt
fill 106 22 551 106 25 551 minecraft:blackstone
setblock 107 22 513 minecraft:blackstone
fill 107 22 550 107 25 550 minecraft:blackstone
setblock 108 22 513 minecraft:smooth_basalt
setblock 109 22 512 minecraft:smooth_basalt
fill 109 22 513 109 23 513 minecraft:blackstone
setblock 110 22 511 minecraft:smooth_basalt
fill 110 22 512 110 25 512 minecraft:blackstone
setblock 110 22 551 minecraft:smooth_basalt
fill 111 22 511 111 25 511 minecraft:blackstone
setblock 111 22 550 minecraft:smooth_basalt
fill 111 22 551 111 25 551 minecraft:blackstone
fill 112 22 550 112 23 550 minecraft:blackstone
setblock 115 22 511 minecraft:smooth_basalt
setblock 115 22 551 minecraft:smooth_basalt
fill 124 22 543 124 23 544 minecraft:gilded_blackstone
setblock 125 22 511 minecraft:smooth_basalt
fill 126 22 511 126 24 512 minecraft:blackstone
setblock 127 22 513 minecraft:blackstone
setblock 128 22 513 minecraft:smooth_basalt
setblock 129 22 512 minecraft:smooth_basalt
fill 129 22 513 129 24 514 minecraft:blackstone
setblock 129 22 551 minecraft:blackstone
setblock 130 22 511 minecraft:smooth_basalt
fill 130 22 512 130 25 512 minecraft:blackstone
fill 130 22 514 131 22 514 minecraft:blackstone
setblock 130 22 551 minecraft:smooth_basalt
fill 131 22 511 131 25 511 minecraft:blackstone
fill 131 22 551 131 25 551 minecraft:blackstone
setblock 132 22 514 minecraft:smooth_basalt
fill 132 22 515 132 25 515 minecraft:blackstone
setblock 132 22 519 minecraft:smooth_basalt
fill 132 22 520 132 25 520 minecraft:blackstone
setblock 133 22 513 minecraft:smooth_basalt
fill 133 22 514 133 25 514 minecraft:blackstone
setblock 133 22 517 minecraft:blackstone
setblock 133 22 518 minecraft:smooth_basalt
fill 133 22 519 133 25 519 minecraft:blackstone
setblock 133 22 522 minecraft:blackstone
setblock 134 22 512 minecraft:smooth_basalt
fill 134 22 513 134 25 513 minecraft:blackstone
setblock 134 22 517 minecraft:smooth_basalt
fill 134 22 518 134 25 518 minecraft:blackstone
setblock 134 22 522 minecraft:smooth_basalt
fill 134 22 523 134 25 523 minecraft:blackstone
setblock 134 22 532 minecraft:smooth_basalt
fill 134 22 533 134 23 533 minecraft:blackstone
setblock 134 22 537 minecraft:smooth_basalt
fill 134 22 538 134 24 538 minecraft:blackstone
setblock 135 22 511 minecraft:smooth_basalt
fill 135 22 512 135 25 512 minecraft:blackstone
setblock 135 22 516 minecraft:smooth_basalt
fill 135 22 517 135 25 517 minecraft:blackstone
setblock 135 22 521 minecraft:smooth_basalt
fill 135 22 522 135 25 522 minecraft:blackstone
setblock 135 22 526 minecraft:smooth_basalt
fill 135 22 527 135 24 527 minecraft:blackstone
setblock 135 22 531 minecraft:smooth_basalt
fill 135 22 532 135 24 532 minecraft:blackstone
setblock 135 22 536 minecraft:smooth_basalt
fill 135 22 537 135 25 537 minecraft:blackstone
setblock 135 22 541 minecraft:smooth_basalt
fill 95 23 511 95 26 511 minecraft:blackstone
setblock 95 23 515 minecraft:smooth_basalt
fill 95 23 516 95 26 516 minecraft:blackstone
setblock 95 23 520 minecraft:smooth_basalt
fill 95 23 521 95 26 521 minecraft:blackstone
fill 95 23 523 95 24 523 minecraft:blackstone
fill 95 23 524 95 24 525 minecraft:smooth_basalt
setblock 95 23 535 minecraft:smooth_basalt
fill 95 23 536 95 25 536 minecraft:blackstone
setblock 95 23 540 minecraft:smooth_basalt
fill 95 23 541 95 26 541 minecraft:blackstone
fill 95 23 543 95 23 544 minecraft:blackstone
setblock 95 23 550 minecraft:smooth_basalt
fill 95 23 551 95 26 551 minecraft:blackstone
setblock 96 23 514 minecraft:smooth_basalt
fill 96 23 515 96 26 515 minecraft:blackstone
setblock 96 23 519 minecraft:smooth_basalt
setblock 98 23 512 minecraft:smooth_basalt
setblock 98 23 551 minecraft:blackstone
setblock 99 23 511 minecraft:smooth_basalt
setblock 99 23 512 minecraft:blackstone
setblock 99 23 551 minecraft:smooth_basalt
fill 100 23 511 100 26 511 minecraft:blackstone
fill 100 23 551 100 26 551 minecraft:blackstone
setblock 103 23 511 minecraft:blackstone
setblock 103 23 512 minecraft:smooth_basalt
setblock 104 23 511 minecraft:smooth_basalt
fill 104 23 512 104 26 512 minecraft:blackstone
setblock 104 23 550 minecraft:blackstone
setblock 104 23 551 minecraft:smooth_basalt
fill 105 23 511 105 26 511 minecraft:blackstone
setblock 105 23 550 minecraft:smooth_basalt
fill 105 23 551 105 26 551 minecraft:blackstone
setblock 106 23 513 minecraft:blackstone
fill 106 23 550 106 26 550 minecraft:blackstone
setblock 107 23 513 minecraft:smooth_basalt
setblock 108 23 512 minecraft:smooth_basalt
fill 108 23 513 108 24 513 minecraft:blackstone
setblock 109 23 511 minecraft:smooth_basalt
fill 109 23 512 109 25 512 minecraft:blackstone
setblock 109 23 551 minecraft:smooth_basalt
fill 110 23 511 110 26 511 minecraft:blackstone
setblock 110 23 550 minecraft:smooth_basalt
fill 110 23 551 110 26 551 minecraft:blackstone
fill 111 23 550 111 25 550 minecraft:blackstone
setblock 114 23 511 minecraft:smooth_basalt
setblock 114 23 551 minecraft:smooth_basalt
setblock 124 23 511 minecraft:smooth_basalt
fill 125 23 511 125 25 512 minecraft:blackstone
setblock 127 23 513 minecraft:smooth_basalt
setblock 128 23 512 minecraft:smooth_basalt
fill 128 23 513 128 26 513 minecraft:blackstone
setblock 128 23 551 minecraft:blackstone
setblock 129 23 511 minecraft:smooth_basalt
fill 129 23 512 129 26 512 minecraft:blackstone
setblock 129 23 551 minecraft:smooth_basalt
fill 130 23 511 130 26 511 minecraft:blackstone
setblock 130 23 514 minecraft:blackstone
fill 130 23 551 130 25 551 minecraft:blackstone
setblock 131 23 514 minecraft:smooth_basalt
setblock 132 23 513 minecraft:smooth_basalt
fill 132 23 514 132 24 514 minecraft:blackstone
fill 132 23 516 132 23 517 minecraft:blackstone
setblock 132 23 518 minecraft:smooth_basalt
fill 132 23 519 132 26 519 minecraft:blackstone
fill 132 23 521 132 24 521 minecraft:blackstone
setblock 133 23 512 minecraft:smooth_basalt
fill 133 23 513 133 25 513 minecraft:blackstone
setblock 133 23 517 minecraft:smooth_basalt
fill 133 23 518 133 26 518 minecraft:blackstone
setblock 133 23 522 minecraft:smooth_basalt
fill 133 23 523 133 26 523 minecraft:blackstone
setblock 134 23 511 minecraft:smooth_basalt
fill 134 23 512 134 26 512 minecraft:blackstone
setblock 134 23 516 minecraft:smooth_basalt
fill 134 23 517 134 26 517 minecraft:blackstone
setblock 134 23 521 minecraft:smooth_basalt
fill 134 23 522 134 26 522 minecraft:blackstone
setblock 134 23 525 minecraft:blackstone
setblock 134 23 536 minecraft:smooth_basalt
fill 134 23 537 134 24 537 minecraft:blackstone
setblock 134 23 540 minecraft:blackstone
fill 135 23 511 135 26 511 minecraft:blackstone
setblock 135 23 515 minecraft:smooth_basalt
fill 135 23 516 135 26 516 minecraft:blackstone
setblock 135 23 520 minecraft:smooth_basalt
fill 135 23 521 135 26 521 minecraft:blackstone
setblock 135 23 525 minecraft:smooth_basalt
fill 135 23 526 135 26 526 minecraft:blackstone
setblock 135 23 530 minecraft:smooth_basalt
setblock 135 23 531 minecraft:blackstone
setblock 135 23 535 minecraft:smooth_basalt
fill 135 23 536 135 25 536 minecraft:blackstone
setblock 135 23 539 minecraft:blackstone
setblock 135 23 540 minecraft:smooth_basalt
fill 135 23 541 135 25 542 minecraft:blackstone
setblock 95 24 514 minecraft:smooth_basalt
fill 95 24 515 95 27 515 minecraft:blackstone
setblock 95 24 519 minecraft:smooth_basalt
fill 95 24 520 96 25 520 minecraft:blackstone
setblock 95 24 535 minecraft:blackstone
setblock 95 24 539 minecraft:smooth_basalt
fill 95 24 540 95 27 540 minecraft:blackstone
setblock 95 24 543 minecraft:blackstone
setblock 95 24 544 minecraft:smooth_basalt
fill 95 24 545 95 26 546 minecraft:blackstone
fill 95 24 550 95 25 550 minecraft:blackstone
setblock 96 24 513 minecraft:smooth_basalt
fill 96 24 514 96 26 514 minecraft:blackstone
setblock 96 24 518 minecraft:smooth_basalt
fill 96 24 519 96 26 519 minecraft:blackstone
setblock 96 24 533 minecraft:smooth_basalt
setblock 97 24 512 minecraft:smooth_basalt
setblock 97 24 522 minecraft:smooth_basalt
setblock 98 24 511 minecraft:smooth_basalt
fill 98 24 521 104 24 521 minecraft:smooth_basalt
setblock 98 24 551 minecraft:smooth_basalt
fill 99 24 511 99 26 511 minecraft:blackstone
fill 99 24 551 99 27 551 minecraft:blackstone
setblock 102 24 511 minecraft:blackstone
setblock 102 24 512 minecraft:smooth_basalt
setblock 103 24 511 minecraft:smooth_basalt
fill 103 24 512 103 25 512 minecraft:blackstone
setblock 103 24 551 minecraft:smooth_basalt
fill 104 24 511 104 27 511 minecraft:blackstone
setblock 104 24 550 minecraft:smooth_basalt
fill 104 24 551 104 27 551 minecraft:blackstone
fill 105 24 550 105 27 550 minecraft:blackstone
setblock 107 24 512 minecraft:smooth_basalt
setblock 107 24 513 minecraft:blackstone
setblock 108 24 511 minecraft:smooth_basalt
fill 108 24 512 108 26 512 minecraft:blackstone
fill 108 24 549 108 25 549 minecraft:blackstone
setblock 108 24 551 minecraft:smooth_basalt
fill 109 24 511 109 27 511 minecraft:blackstone
setblock 109 24 550 minecraft:smooth_basalt
fill 109 24 551 109 27 551 minecraft:blackstone
fill 110 24 550 110 26 550 minecraft:blackstone
setblock 113 24 511 minecraft:smooth_basalt
setblock 113 24 551 minecraft:smooth_basalt
fill 124 24 511 124 27 511 minecraft:blackstone
setblock 126 24 513 minecraft:smooth_basalt
fill 126 24 521 127 25 521 minecraft:gold_block
setblock 127 24 512 minecraft:smooth_basalt
fill 127 24 513 127 27 513 minecraft:blackstone
setblock 128 24 511 minecraft:smooth_basalt
fill 128 24 512 128 27 512 minecraft:blackstone
fill 128 24 514 128 25 514 minecraft:blackstone
setblock 128 24 551 minecraft:smooth_basalt
fill 129 24 511 129 27 511 minecraft:blackstone
fill 129 24 551 129 26 551 minecraft:blackstone
setblock 130 24 514 minecraft:smooth_basalt
setblock 131 24 513 minecraft:smooth_basalt
fill 131 24 514 131 25 514 minecraft:blackstone
setblock 132 24 512 minecraft:smooth_basalt
fill 132 24 513 132 26 513 minecraft:blackstone
setblock 132 24 516 minecraft:blackstone
setblock 132 24 517 minecraft:smooth_basalt
fill 132 24 518 132 27 518 minecraft:blackstone
setblock 133 24 511 minecraft:smooth_basalt
fill 133 24 512 133 26 512 minecraft:blackstone
setblock 133 24 516 minecraft:smooth_basalt
fill 133 24 517 133 27 517 minecraft:blackstone
setblock 133 24 520 minecraft:blackstone
setblock 133 24 521 minecraft:smooth_basalt
fill 133 24 522 133 27 522 minecraft:blackstone
fill 134 24 511 134 27 511 minecraft:blackstone
setblock 134 24 515 minecraft:smooth_basalt
fill 134 24 516 134 27 516 minecraft:blackstone
setblock 134 24 520 minecraft:smooth_basalt
fill 134 24 521 134 27 521 minecraft:blackstone
setblock 134 24 525 minecraft:smooth_basalt
setblock 134 24 535 minecraft:smooth_basalt
setblock 134 24 536 minecraft:blackstone
setblock 134 24 540 minecraft:smooth_basalt
setblock 135 24 514 minecraft:smooth_basalt
fill 135 24 515 135 27 515 minecraft:blackstone
setblock 135 24 519 minecraft:smooth_basalt
fill 135 24 520 135 27 520 minecraft:blackstone
setblock 135 24 524 minecraft:smooth_basalt
fill 135 24 525 135 27 525 minecraft:blackstone
setblock 135 24 534 minecraft:smooth_basalt
fill 135 24 535 135 25 535 minecraft:blackstone
setblock 135 24 539 minecraft:smooth_basalt
fill 135 24 540 135 27 540 minecraft:blackstone
setblock 95 25 513 minecraft:smooth_basalt
fill 95 25 514 95 28 514 minecraft:blackstone
setblock 95 25 518 minecraft:smooth_basalt
fill 95 25 519 95 28 519 minecraft:blackstone
setblock 95 25 523 minecraft:smooth_basalt
setblock 95 25 525 minecraft:smooth_basalt
setblock 95 25 538 minecraft:smooth_basalt
fill 95 25 539 95 27 539 minecraft:blackstone
setblock 95 25 543 minecraft:smooth_basalt
fill 95 25 544 95 28 544 minecraft:blackstone
setblock 95 25 547 minecraft:blackstone
setblock 96 25 512 minecraft:smooth_basalt
setblock 96 25 513 minecraft:blackstone
setblock 96 25 517 minecraft:smooth_basalt
fill 96 25 518 96 26 518 minecraft:blackstone
setblock 97 25 511 minecraft:smooth_basalt
setblock 97 25 533 minecraft:smooth_basalt
fill 98 25 511 98 26 511 minecraft:blackstone
setblock 98 25 551 minecraft:blackstone
setblock 102 25 511 minecraft:smooth_basalt
setblock 102 25 512 minecraft:blackstone
setblock 102 25 551 minecraft:smooth_basalt
fill 103 25 511 103 28 511 minecraft:blackstone
setblock 103 25 550 minecraft:smooth_basalt
fill 103 25 551 103 28 551 minecraft:blackstone
fill 104 25 550 104 28 550 minecraft:blackstone
setblock 106 25 512 minecraft:smooth_basalt
fill 106 25 549 107 26 549 minecraft:blackstone
setblock 107 25 511 minecraft:smooth_basalt
fill 107 25 512 107 26 512 minecraft:blackstone
setblock 107 25 551 minecraft:smooth_basalt
fill 108 25 511 108 28 511 minecraft:blackstone
setblock 108 25 550 minecraft:smooth_basalt
fill 108 25 551 108 28 551 minecraft:blackstone
fill 109 25 550 109 28 550 minecraft:blackstone
setblock 112 25 511 minecraft:smooth_basalt
setblock 112 25 551 minecraft:smooth_basalt
setblock 113 25 551 minecraft:blackstone
setblock 126 25 511 minecraft:blackstone
setblock 126 25 512 minecraft:smooth_basalt
fill 126 25 513 126 26 513 minecraft:blackstone
setblock 127 25 511 minecraft:smooth_basalt
fill 127 25 512 127 28 512 minecraft:blackstone
setblock 127 25 551 minecraft:smooth_basalt
fill 128 25 511 128 28 511 minecraft:blackstone
fill 128 25 551 128 26 551 minecraft:blackstone
setblock 129 25 513 minecraft:blackstone
setblock 129 25 514 minecraft:smooth_basalt
setblock 130 25 513 minecraft:smooth_basalt
setblock 130 25 514 minecraft:blackstone
setblock 131 25 512 minecraft:smooth_basalt
fill 131 25 513 131 26 513 minecraft:blackstone
setblock 132 25 511 minecraft:smooth_basalt
fill 132 25 512 132 27 512 minecraft:blackstone
setblock 132 25 516 minecraft:smooth_basalt
fill 132 25 517 132 26 517 minecraft:blackstone
setblock 132 25 521 minecraft:smooth_basalt
fill 133 25 511 133 28 511 minecraft:blackstone
setblock 133 25 515 minecraft:smooth_basalt
fill 133 25 516 133 27 516 minecraft:blackstone
setblock 133 25 520 minecraft:smooth_basalt
fill 133 25 521 133 28 521 minecraft:blackstone
setblock 134 25 514 minecraft:smooth_basalt
fill 134 25 515 134 28 515 minecraft:blackstone
setblock 134 25 519 minecraft:smooth_basalt
fill 134 25 520 134 28 520 minecraft:blackstone
setblock 134 25 524 minecraft:smooth_basalt
setblock 134 25 525 minecraft:blackstone
setblock 134 25 539 minecraft:smooth_basalt
setblock 135 25 513 minecraft:smooth_basalt
fill 135 25 514 135 28 514 minecraft:blackstone
setblock 135 25 518 minecraft:smooth_basalt
fill 135 25 519 135 28 519 minecraft:blackstone
setblock 135 25 523 minecraft:smooth_basalt
fill 135 25 524 135 28 524 minecraft:blackstone
setblock 135 25 538 minecraft:smooth_basalt
fill 135 25 539 135 26 539 minecraft:blackstone
setblock 135 25 543 minecraft:smooth_basalt
setblock 95 26 512 minecraft:smooth_basalt
fill 95 26 513 95 27 513 minecraft:blackstone
setblock 95 26 517 minecraft:smooth_basalt
fill 95 26 518 95 29 518 minecraft:blackstone
fill 95 26 520 95 27 520 minecraft:blackstone
setblock 95 26 522 minecraft:smooth_basalt
setblock 95 26 523 minecraft:blackstone
setblock 95 26 537 minecraft:smooth_basalt
fill 95 26 538 95 27 538 minecraft:blackstone
setblock 95 26 542 minecraft:smooth_basalt
fill 95 26 543 95 29 543 minecraft:blackstone
setblock 95 26 547 minecraft:smooth_basalt
fill 95 26 548 95 29 548 minecraft:blackstone
setblock 96 26 511 minecraft:smooth_basalt
setblock 96 26 516 minecraft:smooth_basalt
setblock 96 26 517 minecraft:blackstone
fill 96 26 526 96 26 530 minecraft:smooth_basalt
setblock 97 26 511 minecraft:blackstone
fill 98 26 524 98 26 525 minecraft:smooth_basalt
setblock 98 26 532 minecraft:smooth_basalt
fill 99 26 529 106 26 529 minecraft:smooth_basalt
setblock 101 26 511 minecraft:smooth_basalt
setblock 101 26 551 minecraft:smooth_basalt
fill 102 26 511 102 28 511 minecraft:blackstone
fill 102 26 551 102 29 551 minecraft:blackstone
fill 103 26 550 103 29 550 minecraft:blackstone
setblock 105 26 512 minecraft:smooth_basalt
setblock 106 26 511 minecraft:smooth_basalt
setblock 106 26 512 minecraft:blackstone
setblock 106 26 551 minecraft:smooth_basalt
fill 107 26 511 107 28 511 minecraft:blackstone
setblock 107 26 550 minecraft:smooth_basalt
fill 107 26 551 107 29 551 minecraft:blackstone
setblock 108 26 549 minecraft:smooth_basalt
fill 108 26 550 108 29 550 minecraft:blackstone
setblock 111 26 511 minecraft:smooth_basalt
setblock 111 26 551 minecraft:smooth_basalt
setblock 112 26 551 minecraft:blackstone
setblock 125 26 511 minecraft:blackstone
setblock 125 26 512 minecraft:smooth_basalt
setblock 126 26 511 minecraft:smooth_basalt
fill 126 26 512 126 28 512 minecraft:blackstone
fill 127 26 511 127 29 511 minecraft:blackstone
setblock 127 26 551 minecraft:blackstone
setblock 129 26 513 minecraft:smooth_basalt
setblock 130 26 512 minecraft:smooth_basalt
fill 130 26 513 130 27 513 minecraft:blackstone
setblock 131 26 511 minecraft:smooth_basalt
fill 131 26 512 131 27 512 minecraft:blackstone
fill 132 26 511 132 28 511 minecraft:blackstone
setblock 132 26 516 minecraft:blackstone
setblock 132 26 520 minecraft:smooth_basalt
setblock 132 26 521 minecraft:blackstone
setblock 133 26 514 minecraft:smooth_basalt
fill 133 26 515 133 27 515 minecraft:blackstone
setblock 133 26 519 minecraft:smooth_basalt
fill 133 26 520 133 28 520 minecraft:blackstone
setblock 134 26 513 minecraft:smooth_basalt
fill 134 26 514 134 27 514 minecraft:blackstone
setblock 134 26 518 minecraft:smooth_basalt
fill 134 26 519 134 29 519 minecraft:blackstone
setblock 134 26 523 minecraft:smooth_basalt
fill 134 26 524 134 27 524 minecraft:blackstone
setblock 135 26 512 minecraft:smooth_basalt
fill 135 26 513 135 28 513 minecraft:blackstone
setblock 135 26 517 minecraft:smooth_basalt
fill 135 26 518 135 29 518 minecraft:blackstone
setblock 135 26 522 minecraft:smooth_basalt
fill 135 26 523 135 29 523 minecraft:blackstone
setblock 135 26 537 minecraft:smooth_basalt
setblock 135 26 538 minecraft:blackstone
setblock 135 26 541 minecraft:blackstone
setblock 135 26 542 minecraft:smooth_basalt
setblock 135 26 543 minecraft:blackstone
setblock 95 27 511 minecraft:smooth_basalt
setblock 95 27 512 minecraft:blackstone
setblock 95 27 516 minecraft:smooth_basalt
fill 95 27 517 95 29 517 minecraft:blackstone
setblock 95 27 521 minecraft:smooth_basalt
fill 95 27 522 95 28 522 minecraft:blackstone
setblock 95 27 541 minecraft:smooth_basalt
fill 95 27 542 95 30 542 minecraft:blackstone
setblock 95 27 545 minecraft:blackstone
setblock 95 27 546 minecraft:smooth_basalt
fill 95 27 547 95 30 547 minecraft:blackstone
setblock 97 27 529 minecraft:smooth_basalt
fill 99 27 529 105 27 529 minecraft:smooth_basalt
setblock 100 27 511 minecraft:smooth_basalt
setblock 100 27 551 minecraft:smooth_basalt
setblock 101 27 511 minecraft:blackstone
fill 101 27 551 101 30 551 minecraft:blackstone
fill 102 27 550 102 30 550 minecraft:blackstone
setblock 105 27 511 minecraft:smooth_basalt
fill 105 27 549 106 27 549 minecraft:blackstone
setblock 105 27 551 minecraft:smooth_basalt
fill 106 27 511 106 28 511 minecraft:blackstone
setblock 106 27 550 minecraft:smooth_basalt
fill 106 27 551 106 30 551 minecraft:blackstone
setblock 107 27 549 minecraft:smooth_basalt
fill 107 27 550 107 30 550 minecraft:blackstone
setblock 110 27 551 minecraft:smooth_basalt
setblock 111 27 551 minecraft:blackstone
setblock 125 27 511 minecraft:smooth_basalt
setblock 125 27 512 minecraft:blackstone
fill 126 27 511 126 30 511 minecraft:blackstone
setblock 128 27 513 minecraft:smooth_basalt
setblock 129 27 512 minecraft:smooth_basalt
setblock 129 27 513 minecraft:blackstone
setblock 130 27 511 minecraft:smooth_basalt
fill 130 27 512 130 28 512 minecraft:blackstone
fill 131 27 511 131 29 511 minecraft:blackstone
setblock 132 27 519 minecraft:smooth_basalt
setblock 132 27 520 minecraft:blackstone
setblock 133 27 518 minecraft:smooth_basalt
fill 133 27 519 133 28 519 minecraft:blackstone
setblock 134 27 513 minecraft:blackstone
setblock 134 27 517 minecraft:smooth_basalt
fill 134 27 518 134 29 518 minecraft:blackstone
setblock 134 27 522 minecraft:smooth_basalt
fill 134 27 523 134 29 523 minecraft:blackstone
setblock 135 27 511 minecraft:smooth_basalt
fill 135 27 512 135 28 512 minecraft:blackstone
setblock 135 27 516 minecraft:smooth_basalt
fill 135 27 517 135 30 517 minecraft:blackstone
setblock 135 27 521 minecraft:smooth_basalt
fill 135 27 522 135 30 522 minecraft:blackstone
setblock 135 27 541 minecraft:smooth_basalt
setblock 135 27 542 minecraft:blackstone
setblock 95 28 515 minecraft:smooth_basalt
setblock 95 28 516 minecraft:blackstone
setblock 95 28 520 minecraft:smooth_basalt
fill 95 28 521 95 29 521 minecraft:blackstone
setblock 95 28 540 minecraft:smooth_basalt
fill 95 28 541 95 30 541 minecraft:blackstone
setblock 95 28 545 minecraft:smooth_basalt
fill 95 28 546 95 31 546 minecraft:blackstone
setblock 99 28 551 minecraft:smooth_basalt
fill 100 28 551 100 31 551 minecraft:blackstone
setblock 104 28 511 minecraft:smooth_basalt
setblock 104 28 551 minecraft:smooth_basalt
fill 105 28 511 105 29 511 minecraft:blackstone
setblock 105 28 549 minecraft:blackstone
setblock 105 28 550 minecraft:smooth_basalt
fill 105 28 551 105 31 551 minecraft:blackstone
setblock 106 28 549 minecraft:smooth_basalt
fill 106 28 550 106 31 550 minecraft:blackstone
setblock 109 28 551 minecraft:smooth_basalt
setblock 110 28 551 minecraft:blackstone
setblock 124 28 511 minecraft:smooth_basalt
fill 125 28 511 125 31 511 minecraft:blackstone
setblock 128 28 512 minecraft:smooth_basalt
setblock 129 28 511 minecraft:smooth_basalt
setblock 129 28 512 minecraft:blackstone
fill 130 28 511 130 30 511 minecraft:blackstone
setblock 133 28 517 minecraft:smooth_basalt
setblock 133 28 518 minecraft:blackstone
setblock 133 28 522 minecraft:smooth_basalt
setblock 134 28 516 minecraft:smooth_basalt
fill 134 28 517 134 29 517 minecraft:blackstone
setblock 134 28 521 minecraft:smooth_basalt
fill 134 28 522 134 29 522 minecraft:blackstone
setblock 135 28 515 minecraft:smooth_basalt
fill 135 28 516 135 30 516 minecraft:blackstone
setblock 135 28 520 minecraft:smooth_basalt
fill 135 28 521 135 31 521 minecraft:blackstone
setblock 135 28 525 minecraft:smooth_basalt
setblock 95 29 519 minecraft:smooth_basalt
setblock 95 29 520 minecraft:blackstone
setblock 95 29 544 minecraft:smooth_basalt
fill 95 29 545 95 32 545 minecraft:blackstone
setblock 97 29 513 minecraft:light[level=12]
setblock 97 29 521 minecraft:light[level=12]
setblock 97 29 529 minecraft:light[level=12]
setblock 97 29 537 minecraft:light[level=12]
setblock 97 29 545 minecraft:light[level=12]
fill 99 29 551 99 32 551 minecraft:blackstone
setblock 103 29 511 minecraft:smooth_basalt
setblock 103 29 551 minecraft:smooth_basalt
setblock 104 29 511 minecraft:blackstone
setblock 104 29 550 minecraft:smooth_basalt
fill 104 29 551 104 32 551 minecraft:blackstone
setblock 105 29 513 minecraft:light[level=12]
setblock 105 29 521 minecraft:light[level=12]
setblock 105 29 529 minecraft:light[level=12]
setblock 105 29 537 minecraft:light[level=12]
setblock 105 29 545 minecraft:light[level=12]
setblock 105 29 549 minecraft:smooth_basalt
fill 105 29 550 105 32 550 minecraft:blackstone
setblock 108 29 551 minecraft:smooth_basalt
fill 109 29 551 109 30 551 minecraft:blackstone
setblock 113 29 513 minecraft:light[level=12]
setblock 113 29 521 minecraft:light[level=12]
setblock 113 29 529 minecraft:light[level=12]
setblock 113 29 537 minecraft:light[level=12]
setblock 113 29 545 minecraft:light[level=12]
setblock 121 29 513 minecraft:light[level=12]
setblock 121 29 521 minecraft:light[level=12]
setblock 121 29 529 minecraft:light[level=12]
setblock 121 29 537 minecraft:light[level=12]
setblock 121 29 545 minecraft:light[level=12]
setblock 124 29 511 minecraft:blackstone
setblock 128 29 511 minecraft:smooth_basalt
fill 129 29 511 129 30 511 minecraft:blackstone
setblock 129 29 513 minecraft:light[level=12]
setblock 129 29 521 minecraft:light[level=12]
setblock 129 29 529 minecraft:light[level=12]
setblock 129 29 537 minecraft:light[level=12]
setblock 134 29 520 minecraft:smooth_basalt
fill 134 29 521 134 30 521 minecraft:blackstone
setblock 135 29 514 minecraft:smooth_basalt
fill 135 29 515 135 30 515 minecraft:blackstone
setblock 135 29 519 minecraft:smooth_basalt
fill 135 29 520 135 32 520 minecraft:blackstone
setblock 135 29 524 minecraft:smooth_basalt
setblock 95 30 543 minecraft:smooth_basalt
fill 95 30 544 95 33 544 minecraft:blackstone
setblock 95 30 548 minecraft:smooth_basalt
fill 101 30 550 101 31 550 minecraft:blackstone
setblock 102 30 551 minecraft:smooth_basalt
setblock 103 30 550 minecraft:smooth_basalt
fill 103 30 551 103 33 551 minecraft:blackstone
fill 104 30 550 104 33 550 minecraft:blackstone
setblock 107 30 551 minecraft:smooth_basalt
fill 108 30 551 108 33 551 minecraft:blackstone
setblock 127 30 511 minecraft:smooth_basalt
fill 128 30 511 128 33 511 minecraft:blackstone
setblock 134 30 519 minecraft:smooth_basalt
setblock 134 30 520 minecraft:blackstone
setblock 135 30 518 minecraft:smooth_basalt
fill 135 30 519 135 32 519 minecraft:blackstone
setblock 135 30 523 minecraft:smooth_basalt
fill 135 30 524 135 33 524 minecraft:blackstone
setblock 95 31 542 minecraft:smooth_basalt
fill 95 31 543 95 34 543 minecraft:blackstone
setblock 95 31 547 minecraft:smooth_basalt
fill 95 31 548 95 33 549 minecraft:blackstone
fill 98 31 551 98 33 551 minecraft:blackstone
setblock 101 31 551 minecraft:smooth_basalt
setblock 102 31 550 minecraft:smooth_basalt
fill 102 31 551 102 34 551 minecraft:blackstone
setblock 103 31 549 minecraft:smooth_basalt
fill 103 31 550 103 34 550 minecraft:blackstone
fill 104 31 549 104 34 549 minecraft:blackstone
setblock 106 31 551 minecraft:smooth_basalt
setblock 107 31 550 minecraft:smooth_basalt
fill 107 31 551 107 34 551 minecraft:blackstone
setblock 126 31 511 minecraft:smooth_basalt
fill 127 31 511 127 34 511 minecraft:blackstone
setblock 135 31 517 minecraft:smooth_basalt
setblock 135 31 518 minecraft:blackstone
setblock 135 31 522 minecraft:smooth_basalt
fill 135 31 523 135 34 523 minecraft:blackstone
fill 95 32 542 95 35 542 minecraft:blackstone
setblock 95 32 546 minecraft:smooth_basalt
fill 95 32 547 95 35 547 minecraft:blackstone
setblock 96 32 545 minecraft:smooth_basalt
fill 97 32 551 97 34 551 minecraft:blackstone
fill 99 32 550 100 32 550 minecraft:blackstone
setblock 100 32 551 minecraft:smooth_basalt
setblock 101 32 550 minecraft:smooth_basalt
fill 101 32 551 101 35 551 minecraft:blackstone
setblock 102 32 549 minecraft:smooth_basalt
fill 102 32 550 102 35 550 minecraft:blackstone
fill 103 32 549 103 35 549 minecraft:blackstone
fill 105 32 549 105 33 549 minecraft:blackstone
setblock 105 32 551 minecraft:smooth_basalt
setblock 106 32 550 minecraft:smooth_basalt
fill 106 32 551 106 35 551 minecraft:blackstone
setblock 124 32 511 minecraft:blackstone
setblock 125 32 511 minecraft:smooth_basalt
fill 126 32 511 126 35 511 minecraft:blackstone
setblock 135 32 521 minecraft:smooth_basalt
fill 135 32 522 135 35 522 minecraft:blackstone
setblock 95 33 545 minecraft:smooth_basalt
fill 95 33 546 96 35 546 minecraft:blackstone
setblock 95 33 550 minecraft:smooth_basalt
fill 95 33 551 96 35 551 minecraft:blackstone
setblock 96 33 544 minecraft:smooth_basalt
fill 96 33 545 96 36 545 minecraft:blackstone
fill 96 33 547 96 33 548 minecraft:blackstone
fill 98 33 550 99 33 550 minecraft:blackstone
setblock 99 33 551 minecraft:smooth_basalt
setblock 100 33 549 minecraft:blackstone
setblock 100 33 550 minecraft:smooth_basalt
fill 100 33 551 100 36 551 minecraft:blackstone
setblock 101 33 549 minecraft:smooth_basalt
fill 101 33 550 101 36 550 minecraft:blackstone
fill 102 33 549 102 36 549 minecraft:blackstone
setblock 104 33 551 minecraft:smooth_basalt
setblock 105 33 550 minecraft:smooth_basalt
fill 105 33 551 105 36 551 minecraft:blackstone
fill 106 33 550 107 35 550 minecraft:blackstone
setblock 123 33 511 minecraft:blackstone
setblock 124 33 511 minecraft:smooth_basalt
setblock 124 33 551 minecraft:smooth_basalt
fill 125 33 511 125 36 511 minecraft:blackstone
fill 125 33 551 126 35 551 minecraft:blackstone
setblock 135 33 520 minecraft:smooth_basalt
fill 135 33 521 135 36 521 minecraft:blackstone
setblock 95 34 544 minecraft:smooth_basalt
fill 95 34 545 95 37 545 minecraft:blackstone
setblock 95 34 548 minecraft:blackstone
setblock 95 34 549 minecraft:smooth_basalt
fill 95 34 550 98 34 550 minecraft:blackstone
setblock 96 34 543 minecraft:smooth_basalt
fill 96 34 544 96 37 544 minecraft:blackstone
setblock 96 34 547 minecraft:blackstone
setblock 96 34 548 minecraft:smooth_basalt
fill 96 34 549 96 37 549 minecraft:blackstone
setblock 97 34 546 minecraft:blackstone
setblock 98 34 551 minecraft:smooth_basalt
setblock 99 34 549 minecraft:blackstone
setblock 99 34 550 minecraft:smooth_basalt
fill 99 34 551 99 37 551 minecraft:blackstone
setblock 100 34 549 minecraft:smooth_basalt
fill 100 34 550 100 37 550 minecraft:blackstone
fill 101 34 549 101 37 549 minecraft:blackstone
fill 102 34 548 103 36 548 minecraft:blackstone
setblock 103 34 551 minecraft:smooth_basalt
setblock 104 34 550 minecraft:smooth_basalt
fill 104 34 551 104 37 551 minecraft:blackstone
setblock 105 34 549 minecraft:smooth_basalt
fill 105 34 550 105 37 550 minecraft:blackstone
setblock 108 34 551 minecraft:smooth_basalt
fill 121 34 551 122 34 551 minecraft:blackstone
setblock 122 34 511 minecraft:blackstone
setblock 123 34 511 minecraft:smooth_basalt
setblock 123 34 551 minecraft:smooth_basalt
fill 124 34 511 124 37 511 minecraft:blackstone
fill 124 34 551 124 37 551 minecraft:blackstone
setblock 127 34 551 minecraft:blackstone
setblock 128 34 511 minecraft:smooth_basalt
setblock 128 34 551 minecraft:smooth_basalt
fill 135 34 520 135 37 520 minecraft:blackstone
setblock 135 34 524 minecraft:smooth_basalt
fill 135 34 545 135 34 548 minecraft:blackstone
setblock 135 34 549 minecraft:smooth_basalt
fill 135 34 550 135 37 550 minecraft:blackstone
fill 95 35 541 95 36 541 minecraft:blackstone
setblock 95 35 543 minecraft:smooth_basalt
fill 95 35 544 95 38 544 minecraft:blackstone
setblock 95 35 548 minecraft:smooth_basalt
fill 95 35 549 95 37 550 minecraft:blackstone
fill 96 35 543 96 38 543 minecraft:blackstone
setblock 96 35 547 minecraft:smooth_basalt
fill 96 35 548 97 37 548 minecraft:blackstone
fill 96 35 550 97 35 550 minecraft:blackstone
fill 97 35 544 97 35 545 minecraft:blackstone
setblock 97 35 546 minecraft:smooth_basalt
fill 97 35 547 97 38 547 minecraft:blackstone
fill 97 35 549 98 35 549 minecraft:blackstone
setblock 97 35 551 minecraft:smooth_basalt
setblock 98 35 550 minecraft:smooth_basalt
fill 98 35 551 98 38 551 minecraft:blackstone
fill 99 35 511 101 35 511 minecraft:blackstone
setblock 99 35 549 minecraft:smooth_basalt
fill 99 35 550 99 38 550 minecraft:blackstone
setblock 100 35 548 minecraft:smooth_basalt
fill 100 35 549 100 38 549 minecraft:blackstone
fill 101 35 548 101 38 548 minecraft:blackstone
setblock 102 35 511 minecraft:smooth_basalt
setblock 102 35 551 minecraft:smooth_basalt
fill 103 35 511 103 38 511 minecraft:blackstone
setblock 103 35 550 minecraft:smooth_basalt
fill 103 35 551 103 38 551 minecraft:blackstone
setblock 104 35 548 minecraft:blackstone
setblock 104 35 549 minecraft:smooth_basalt
fill 104 35 550 104 38 550 minecraft:blackstone
fill 105 35 549 106 37 549 minecraft:blackstone
setblock 107 35 551 minecraft:smooth_basalt
fill 108 35 551 108 38 551 minecraft:blackstone
fill 119 35 551 121 35 551 minecraft:blackstone
fill 120 35 511 121 35 511 minecraft:blackstone
setblock 122 35 511 minecraft:smooth_basalt
setblock 122 35 550 minecraft:blackstone
setblock 122 35 551 minecraft:smooth_basalt
fill 123 35 511 123 38 511 minecraft:blackstone
setblock 123 35 550 minecraft:smooth_basalt
fill 123 35 551 123 38 551 minecraft:blackstone
fill 124 35 550 125 37 550 minecraft:blackstone
setblock 127 35 511 minecraft:smooth_basalt
setblock 127 35 551 minecraft:smooth_basalt
fill 128 35 511 129 37 511 minecraft:blackstone
fill 128 35 551 130 36 551 minecraft:blackstone
fill 133 35 551 135 36 551 minecraft:blackstone
setblock 135 35 523 minecraft:smooth_basalt
fill 135 35 524 135 36 526 minecraft:blackstone
fill 135 35 544 135 35 547 minecraft:blackstone
setblock 135 35 548 minecraft:smooth_basalt
fill 135 35 549 135 38 549 minecraft:blackstone
fill 95 36 525 95 36 526 minecraft:blackstone
setblock 95 36 542 minecraft:smooth_basalt
fill 95 36 543 95 39 543 minecraft:blackstone
setblock 95 36 546 minecraft:blackstone
setblock 95 36 547 minecraft:smooth_basalt
fill 95 36 548 95 39 548 minecraft:blackstone
setblock 95 36 551 minecraft:blackstone
fill 96 36 542 96 39 542 minecraft:blackstone
setblock 96 36 546 minecraft:smooth_basalt
fill 96 36 547 96 39 547 minecraft:blackstone
setblock 96 36 550 minecraft:blackstone
setblock 96 36 551 minecraft:smooth_basalt
fill 97 36 511 100 36 511 minecraft:blackstone
setblock 97 36 544 minecraft:blackstone
setblock 97 36 545 minecraft:smooth_basalt
fill 97 36 546 98 38 546 minecraft:blackstone
setblock 97 36 549 minecraft:blackstone
setblock 97 36 550 minecraft:smooth_basalt
fill 97 36 551 97 39 551 minecraft:blackstone
fill 98 36 547 98 36 548 minecraft:blackstone
setblock 98 36 549 minecraft:smooth_basalt
fill 98 36 550 98 39 550 minecraft:blackstone
setblock 99 36 548 minecraft:smooth_basalt
fill 99 36 549 99 39 549 minecraft:blackstone
fill 100 36 548 100 39 548 minecraft:blackstone
setblock 101 36 511 minecraft:smooth_basalt
setblock 101 36 551 minecraft:smooth_basalt
fill 102 36 511 102 39 511 minecraft:blackstone
setblock 102 36 550 minecraft:smooth_basalt
fill 102 36 551 102 39 551 minecraft:blackstone
setblock 103 36 549 minecraft:smooth_basalt
fill 103 36 550 103 39 550 minecraft:blackstone
fill 104 36 511 104 37 511 minecraft:blackstone
setblock 104 36 548 minecraft:smooth_basalt
fill 104 36 549 104 39 549 minecraft:blackstone
setblock 106 36 550 minecraft:blackstone
setblock 106 36 551 minecraft:smooth_basalt
setblock 107 36 550 minecraft:smooth_basalt
fill 107 36 551 107 39 551 minecraft:blackstone
fill 109 36 551 109 37 551 minecraft:blackstone
fill 117 36 551 120 36 551 minecraft:blackstone
fill 119 36 511 120 36 511 minecraft:blackstone
fill 120 36 550 121 36 550 minecraft:blackstone
setblock 121 36 511 minecraft:smooth_basalt
fill 121 36 512 124 36 512 minecraft:blackstone
setblock 121 36 551 minecraft:smooth_basalt
fill 122 36 511 122 39 511 minecraft:blackstone
setblock 122 36 550 minecraft:smooth_basalt
fill 122 36 551 122 39 551 minecraft:blackstone
fill 123 36 550 123 39 550 minecraft:blackstone
setblock 125 36 512 minecraft:smooth_basalt
setblock 125 36 551 minecraft:blackstone
setblock 126 36 511 minecraft:smooth_basalt
fill 126 36 512 126 39 512 minecraft:blackstone
setblock 126 36 550 minecraft:blackstone
setblock 126 36 551 minecraft:smooth_basalt
fill 127 36 511 127 39 511 minecraft:blackstone
setblock 127 36 550 minecraft:smooth_basalt
fill 127 36 551 127 39 551 minecraft:blackstone
setblock 130 36 511 minecraft:blackstone
setblock 131 36 511 minecraft:smooth_basalt
setblock 131 36 551 minecraft:smooth_basalt
fill 132 36 511 135 36 511 minecraft:blackstone
fill 132 36 551 132 39 551 minecraft:blackstone
setblock 135 36 512 minecraft:smooth_basalt
setblock 135 36 522 minecraft:smooth_basalt
fill 135 36 523 135 39 523 minecraft:blackstone
setblock 135 36 527 minecraft:smooth_basalt
fill 135 36 544 135 36 546 minecraft:blackstone
setblock 135 36 547 minecraft:smooth_basalt
fill 135 36 548 135 39 548 minecraft:blackstone
setblock 95 37 511 minecraft:smooth_basalt
fill 95 37 524 95 37 525 minecraft:blackstone
setblock 95 37 526 minecraft:smooth_basalt
fill 95 37 527 95 37 530 minecraft:blackstone
setblock 95 37 540 minecraft:blackstone
setblock 95 37 541 minecraft:smooth_basalt
fill 95 37 542 95 40 542 minecraft:blackstone
setblock 95 37 546 minecraft:smooth_basalt
fill 95 37 547 95 40 547 minecraft:blackstone
setblock 95 37 551 minecraft:smooth_basalt
fill 96 37 511 99 37 511 minecraft:blackstone
setblock 96 37 545 minecraft:smooth_basalt
fill 96 37 546 96 40 546 minecraft:blackstone
setblock 96 37 550 minecraft:smooth_basalt
fill 96 37 551 96 40 551 minecraft:blackstone
setblock 97 37 513 minecraft:light[level=12]
setblock 97 37 521 minecraft:light[level=12]
setblock 97 37 529 minecraft:light[level=12]
setblock 97 37 537 minecraft:light[level=12]
setblock 97 37 543 minecraft:blackstone
setblock 97 37 544 minecraft:smooth_basalt
fill 97 37 545 98 39 545 minecraft:blackstone
setblock 97 37 549 minecraft:smooth_basalt
fill 97 37 550 97 40 550 minecraft:blackstone
setblock 98 37 547 minecraft:blackstone
setblock 98 37 548 minecraft:smooth_basalt
fill 98 37 549 98 40 549 minecraft:blackstone
fill 99 37 548 99 40 548 minecraft:blackstone
setblock 100 37 511 minecraft:smooth_basalt
setblock 100 37 551 minecraft:smooth_basalt
fill 101 37 511 101 40 511 minecraft:blackstone
setblock 101 37 550 minecraft:smooth_basalt
fill 101 37 551 101 40 551 minecraft:blackstone
setblock 102 37 548 minecraft:blackstone
setblock 102 37 549 minecraft:smooth_basalt
fill 102 37 550 102 40 550 minecraft:blackstone
setblock 103 37 548 minecraft:smooth_basalt
fill 103 37 549 103 40 549 minecraft:blackstone
fill 104 37 548 104 38 548 minecraft:blackstone
setblock 105 37 511 minecraft:smooth_basalt
setblock 105 37 513 minecraft:light[level=12]
setblock 105 37 521 minecraft:light[level=12]
setblock 105 37 529 minecraft:light[level=12]
setblock 105 37 537 minecraft:light[level=12]
setblock 105 37 545 minecraft:light[level=12]
setblock 105 37 551 minecraft:smooth_basalt
setblock 106 37 550 minecraft:smooth_basalt
fill 106 37 551 106 40 551 minecraft:blackstone
fill 107 37 550 107 40 550 minecraft:blackstone
setblock 113 37 513 minecraft:light[level=12]
setblock 113 37 521 minecraft:light[level=12]
setblock 113 37 529 minecraft:light[level=12]
setblock 113 37 537 minecraft:light[level=12]
setblock 113 37 545 minecraft:light[level=12]
fill 116 37 551 119 37 551 minecraft:blackstone
fill 117 37 511 119 37 511 minecraft:blackstone
fill 118 37 550 120 37 550 minecraft:blackstone
setblock 120 37 511 minecraft:smooth_basalt
fill 120 37 512 123 37 512 minecraft:blackstone
setblock 120 37 551 minecraft:smooth_basalt
fill 121 37 511 121 40 511 minecraft:blackstone
setblock 121 37 513 minecraft:light[level=12]
setblock 121 37 521 minecraft:light[level=12]
setblock 121 37 529 minecraft:light[level=12]
setblock 121 37 537 minecraft:light[level=12]
setblock 121 37 545 minecraft:light[level=12]
setblock 121 37 550 minecraft:smooth_basalt
fill 121 37 551 121 40 551 minecraft:blackstone
setblock 122 37 549 minecraft:smooth_basalt
fill 122 37 550 122 40 550 minecraft:blackstone
setblock 124 37 512 minecraft:smooth_basalt
setblock 125 37 511 minecraft:smooth_basalt
fill 125 37 512 125 40 512 minecraft:blackstone
setblock 125 37 551 minecraft:smooth_basalt
fill 126 37 511 126 40 511 minecraft:blackstone
setblock 126 37 550 minecraft:smooth_basalt
fill 126 37 551 126 40 551 minecraft:blackstone
fill 127 37 512 127 38 512 minecraft:blackstone
fill 127 37 550 128 39 550 minecraft:blackstone
fill 128 37 551 129 37 551 minecraft:blackstone
setblock 129 37 513 minecraft:light[level=12]
setblock 129 37 521 minecraft:light[level=12]
setblock 129 37 529 minecraft:light[level=12]
setblock 129 37 537 minecraft:light[level=12]
setblock 130 37 511 minecraft:smooth_basalt
setblock 130 37 551 minecraft:smooth_basalt
fill 131 37 511 134 37 511 minecraft:blackstone
fill 131 37 551 131 40 551 minecraft:blackstone
fill 133 37 550 134 37 551 minecraft:blackstone
setblock 134 37 547 minecraft:smooth_basalt
fill 134 37 548 134 39 549 minecraft:blackstone
setblock 135 37 511 minecraft:smooth_basalt
fill 135 37 512 135 38 514 minecraft:blackstone
setblock 135 37 521 minecraft:smooth_basalt
fill 135 37 522 135 40 522 minecraft:blackstone
fill 135 37 524 135 37 525 minecraft:blackstone
setblock 135 37 526 minecraft:smooth_basalt
fill 135 37 527 135 38 529 minecraft:blackstone
fill 135 37 543 135 37 545 minecraft:blackstone
setblock 135 37 546 minecraft:smooth_basalt
fill 135 37 547 135 40 547 minecraft:blackstone
setblock 135 37 551 minecraft:smooth_basalt
fill 95 38 511 95 40 512 minecraft:blackstone
fill 95 38 523 95 38 524 minecraft:blackstone
setblock 95 38 525 minecraft:smooth_basalt
fill 95 38 526 95 38 529 minecraft:blackstone
setblock 95 38 530 minecraft:smooth_basalt
fill 95 38 531 95 38 534 minecraft:blackstone
setblock 95 38 539 minecraft:blackstone
setblock 95 38 540 minecraft:smooth_basalt
fill 95 38 541 96 40 541 minecraft:blackstone
setblock 95 38 545 minecraft:smooth_basalt
fill 95 38 546 95 41 546 minecraft:blackstone
setblock 95 38 549 minecraft:blackstone
setblock 95 38 550 minecraft:smooth_basalt
fill 95 38 551 95 41 551 minecraft:blackstone
fill 96 38 511 98 38 511 minecraft:blackstone
fill 96 38 526 96 38 528 minecraft:blackstone
setblock 96 38 529 minecraft:smooth_basalt
fill 96 38 530 96 40 531 minecraft:blackstone
setblock 96 38 544 minecraft:smooth_basalt
fill 96 38 545 96 41 545 minecraft:blackstone
setblock 96 38 548 minecraft:blackstone
setblock 96 38 549 minecraft:smooth_basalt
fill 96 38 550 96 41 550 minecraft:blackstone
setblock 97 38 542 minecraft:blackstone
setblock 97 38 543 minecraft:smooth_basalt
fill 97 38 544 98 39 544 minecraft:blackstone
setblock 97 38 548 minecraft:smooth_basalt
fill 97 38 549 97 41 549 minecraft:blackstone
setblock 98 38 547 minecraft:smooth_basalt
fill 98 38 548 98 41 548 minecraft:blackstone
setblock 99 38 511 minecraft:smooth_basalt
fill 99 38 512 100 40 512 minecraft:blackstone
setblock 99 38 551 minecraft:smooth_basalt
fill 100 38 511 100 41 511 minecraft:blackstone
setblock 100 38 547 minecraft:blackstone
setblock 100 38 550 minecraft:smooth_basalt
fill 100 38 551 100 41 551 minecraft:blackstone
setblock 101 38 549 minecraft:smooth_basalt
fill 101 38 550 101 41 550 minecraft:blackstone
setblock 102 38 548 minecraft:smooth_basalt
fill 102 38 549 102 41 549 minecraft:blackstone
fill 103 38 548 103 39 548 minecraft:blackstone
setblock 104 38 511 minecraft:smooth_basalt
setblock 104 38 551 minecraft:smooth_basalt
fill 105 38 511 105 41 511 minecraft:blackstone
setblock 105 38 549 minecraft:blackstone
setblock 105 38 550 minecraft:smooth_basalt
fill 105 38 551 105 41 551 minecraft:blackstone
setblock 106 38 549 minecraft:smooth_basalt
fill 106 38 550 106 41 550 minecraft:blackstone
setblock 108 38 550 minecraft:blackstone
setblock 109 38 551 minecraft:smooth_basalt
fill 110 38 551 110 41 551 minecraft:blackstone
setblock 113 38 551 minecraft:blackstone
setblock 114 38 551 minecraft:smooth_basalt
fill 115 38 551 118 38 551 minecraft:blackstone
fill 116 38 511 118 38 511 minecraft:blackstone
fill 117 38 550 119 38 550 minecraft:blackstone
setblock 118 38 512 minecraft:smooth_basalt
setblock 119 38 511 minecraft:smooth_basalt
fill 119 38 512 122 38 512 minecraft:blackstone
setblock 119 38 551 minecraft:smooth_basalt
fill 120 38 511 120 41 511 minecraft:blackstone
setblock 120 38 549 minecraft:blackstone
setblock 120 38 550 minecraft:smooth_basalt
fill 120 38 551 120 41 551 minecraft:blackstone
setblock 121 38 549 minecraft:smooth_basalt
fill 121 38 550 121 41 550 minecraft:blackstone
setblock 122 38 513 minecraft:smooth_basalt
fill 122 38 549 124 39 549 minecraft:blackstone
setblock 123 38 512 minecraft:smooth_basalt
setblock 124 38 511 minecraft:smooth_basalt
fill 124 38 512 124 41 512 minecraft:blackstone
setblock 124 38 550 minecraft:blackstone
setblock 124 38 551 minecraft:smooth_basalt
fill 125 38 511 125 41 511 minecraft:blackstone
setblock 125 38 550 minecraft:smooth_basalt
fill 125 38 551 125 41 551 minecraft:blackstone
fill 126 38 550 126 41 550 minecraft:blackstone
setblock 128 38 511 minecraft:blackstone
setblock 128 38 512 minecraft:smooth_basalt
setblock 128 38 551 minecraft:blackstone
setblock 129 38 511 minecraft:smooth_basalt
setblock 129 38 550 minecraft:blackstone
setblock 129 38 551 minecraft:smooth_basalt
fill 130 38 511 133 38 511 minecraft:blackstone
setblock 130 38 550 minecraft:smooth_basalt
fill 130 38 551 130 41 551 minecraft:blackstone
fill 131 38 550 134 38 550 minecraft:blackstone
setblock 133 38 551 minecraft:blackstone
setblock 134 38 511 minecraft:smooth_basalt
setblock 134 38 546 minecraft:smooth_basalt
fill 134 38 547 134 41 547 minecraft:blackstone
setblock 134 38 551 minecraft:smooth_basalt
fill 135 38 511 135 41 511 minecraft:blackstone
setblock 135 38 515 minecraft:smooth_basalt
fill 135 38 516 135 41 516 minecraft:blackstone
setblock 135 38 520 minecraft:smooth_basalt
fill 135 38 521 135 40 521 minecraft:blackstone
setblock 135 38 524 minecraft:blackstone
setblock 135 38 525 minecraft:smooth_basalt
fill 135 38 526 135 41 526 minecraft:blackstone
setblock 135 38 530 minecraft:smooth_basalt
fill 135 38 543 135 38 544 minecraft:blackstone
setblock 135 38 545 minecraft:smooth_basalt
fill 135 38 546 135 41 546 minecraft:blackstone
setblock 135 38 550 minecraft:smooth_basalt
fill 135 38 551 135 41 551 minecraft:blackstone
setblock 95 39 513 minecraft:blackstone
setblock 95 39 523 minecraft:blackstone
setblock 95 39 524 minecraft:smooth_basalt
fill 95 39 525 95 39 528 minecraft:blackstone
setblock 95 39 529 minecraft:smooth_basalt
fill 95 39 530 95 39 533 minecraft:blackstone
setblock 95 39 534 minecraft:smooth_basalt
fill 95 39 535 95 39 538 minecraft:blackstone
setblock 95 39 539 minecraft:smooth_basalt
fill 95 39 540 96 41 540 minecraft:blackstone
setblock 95 39 544 minecraft:smooth_basalt
fill 95 39 545 95 42 545 minecraft:blackstone
setblock 95 39 549 minecraft:smooth_basalt
fill 95 39 550 95 42 550 minecraft:blackstone
fill 96 39 511 97 39 511 minecraft:blackstone
fill 96 39 525 96 39 527 minecraft:blackstone
setblock 96 39 528 minecraft:smooth_basalt
fill 96 39 529 97 41 529 minecraft:blackstone
setblock 96 39 532 minecraft:blackstone
setblock 96 39 533 minecraft:smooth_basalt
fill 96 39 534 96 42 534 minecraft:blackstone
setblock 96 39 543 minecraft:smooth_basalt
fill 96 39 544 96 42 544 minecraft:blackstone
setblock 96 39 548 minecraft:smooth_basalt
fill 96 39 549 96 42 549 minecraft:blackstone
setblock 97 39 512 minecraft:smooth_basalt
fill 97 39 528 97 42 528 minecraft:blackstone
fill 97 39 530 97 39 531 minecraft:blackstone
setblock 97 39 542 minecraft:smooth_basalt
fill 97 39 543 97 42 543 minecraft:blackstone
setblock 97 39 546 minecraft:blackstone
setblock 97 39 547 minecraft:smooth_basalt
fill 97 39 548 97 42 548 minecraft:blackstone
setblock 98 39 511 minecraft:smooth_basalt
fill 98 39 512 98 42 512 minecraft:blackstone
setblock 98 39 546 minecraft:smooth_basalt
fill 98 39 547 98 42 547 minecraft:blackstone
setblock 98 39 551 minecraft:smooth_basalt
fill 99 39 511 99 42 511 minecraft:blackstone
setblock 99 39 550 minecraft:smooth_basalt
fill 99 39 551 99 42 551 minecraft:blackstone
setblock 100 39 549 minecraft:smooth_basalt
fill 100 39 550 100 42 550 minecraft:blackstone
setblock 101 39 512 minecraft:blackstone
setblock 101 39 548 minecraft:smooth_basalt
fill 101 39 549 101 42 549 minecraft:blackstone
fill 102 39 548 102 40 548 minecraft:blackstone
setblock 103 39 511 minecraft:smooth_basalt
setblock 103 39 551 minecraft:smooth_basalt
fill 104 39 511 104 42 511 minecraft:blackstone
setblock 104 39 550 minecraft:smooth_basalt
fill 104 39 551 104 42 551 minecraft:blackstone
setblock 105 39 549 minecraft:smooth_basalt
fill 105 39 550 105 42 550 minecraft:blackstone
fill 106 39 511 106 40 511 minecraft:blackstone
setblock 108 39 551 minecraft:smooth_basalt
fill 109 39 551 109 41 551 minecraft:blackstone
fill 111 39 551 112 39 551 minecraft:blackstone
setblock 113 39 551 minecraft:smooth_basalt
fill 114 39 511 117 39 511 minecraft:blackstone
fill 114 39 551 117 39 551 minecraft:blackstone
fill 116 39 550 118 39 550 minecraft:blackstone
setblock 117 39 512 minecraft:smooth_basalt
setblock 118 39 511 minecraft:smooth_basalt
fill 118 39 512 121 39 512 minecraft:blackstone
setblock 118 39 551 minecraft:smooth_basalt
fill 119 39 511 119 42 511 minecraft:blackstone
setblock 119 39 549 minecraft:blackstone
setblock 119 39 550 minecraft:smooth_basalt
fill 119 39 551 119 42 551 minecraft:blackstone
setblock 120 39 513 minecraft:blackstone
setblock 120 39 549 minecraft:smooth_basalt
fill 120 39 550 120 42 550 minecraft:blackstone
setblock 121 39 513 minecraft:smooth_basalt
fill 121 39 549 121 41 549 minecraft:blackstone
setblock 122 39 512 minecraft:smooth_basalt
fill 122 39 513 124 40 513 minecraft:blackstone
setblock 123 39 511 minecraft:smooth_basalt
fill 123 39 512 123 42 512 minecraft:blackstone
setblock 123 39 551 minecraft:smooth_basalt
fill 124 39 511 124 42 511 minecraft:blackstone
setblock 124 39 550 minecraft:smooth_basalt
fill 124 39 551 124 42 551 minecraft:blackstone
fill 125 39 550 125 42 550 minecraft:blackstone
setblock 127 39 512 minecraft:smooth_basalt
setblock 128 39 511 minecraft:smooth_basalt
fill 128 39 512 130 40 512 minecraft:blackstone
setblock 128 39 551 minecraft:smooth_basalt
fill 129 39 511 132 39 511 minecraft:blackstone
setblock 129 39 550 minecraft:smooth_basalt
fill 129 39 551 129 42 551 minecraft:blackstone
fill 130 39 550 133 39 550 minecraft:blackstone
setblock 132 39 512 minecraft:smooth_basalt
setblock 133 39 511 minecraft:smooth_basalt
fill 133 39 512 135 40 512 minecraft:blackstone
setblock 133 39 551 minecraft:smooth_basalt
fill 134 39 511 134 42 511 minecraft:blackstone
fill 134 39 513 135 39 513 minecraft:blackstone
fill 134 39 546 134 42 546 minecraft:blackstone
setblock 134 39 550 minecraft:smooth_basalt
fill 134 39 551 134 42 551 minecraft:blackstone
setblock 135 39 514 minecraft:smooth_basalt
fill 135 39 515 135 42 515 minecraft:blackstone
fill 135 39 517 135 39 518 minecraft:blackstone
setblock 135 39 519 minecraft:smooth_basalt
fill 135 39 520 135 40 520 minecraft:blackstone
setblock 135 39 524 minecraft:smooth_basalt
fill 135 39 525 135 42 525 minecraft:blackstone
fill 135 39 527 135 39 528 minecraft:blackstone
setblock 135 39 529 minecraft:smooth_basalt
fill 135 39 530 135 40 532 minecraft:blackstone
fill 135 39 542 135 39 543 minecraft:blackstone
setblock 135 39 544 minecraft:smooth_basalt
fill 135 39 545 135 42 545 minecraft:blackstone
setblock 135 39 549 minecraft:smooth_basalt
fill 135 39 550 135 42 550 minecraft:blackstone
setblock 95 40 513 minecraft:smooth_basalt
fill 95 40 514 95 43 514 minecraft:blackstone
setblock 95 40 523 minecraft:smooth_basalt
fill 95 40 524 95 40 527 minecraft:blackstone
setblock 95 40 528 minecraft:smooth_basalt
fill 95 40 529 95 40 532 minecraft:blackstone
setblock 95 40 533 minecraft:smooth_basalt
fill 95 40 534 95 40 537 minecraft:blackstone
setblock 95 40 538 minecraft:smooth_basalt
fill 95 40 539 96 42 539 minecraft:blackstone
setblock 95 40 543 minecraft:smooth_basalt
fill 95 40 544 95 43 544 minecraft:blackstone
setblock 95 40 548 minecraft:smooth_basalt
fill 95 40 549 95 43 549 minecraft:blackstone
setblock 96 40 511 minecraft:blackstone
setblock 96 40 512 minecraft:smooth_basalt
fill 96 40 525 96 40 526 minecraft:blackstone
setblock 96 40 527 minecraft:smooth_basalt
fill 96 40 528 96 43 528 minecraft:blackstone
setblock 96 40 532 minecraft:smooth_basalt
fill 96 40 533 97 42 533 minecraft:blackstone
fill 96 40 535 96 40 536 minecraft:blackstone
setblock 96 40 537 minecraft:smooth_basalt
fill 96 40 538 96 43 538 minecraft:blackstone
setblock 96 40 542 minecraft:smooth_basalt
fill 96 40 543 96 43 543 minecraft:blackstone
setblock 96 40 547 minecraft:smooth_basalt
fill 96 40 548 96 43 548 minecraft:blackstone
setblock 97 40 511 minecraft:smooth_basalt
fill 97 40 512 97 43 512 minecraft:blackstone
fill 97 40 527 97 41 527 minecraft:blackstone
setblock 97 40 530 minecraft:blackstone
setblock 97 40 531 minecraft:smooth_basalt
fill 97 40 532 97 43 532 minecraft:blackstone
fill 97 40 534 97 41 534 minecraft:blackstone
fill 97 40 542 97 41 542 minecraft:blackstone
fill 97 40 544 97 40 545 minecraft:blackstone
setblock 97 40 546 minecraft:smooth_basalt
fill 97 40 547 97 43 547 minecraft:blackstone
setblock 97 40 551 minecraft:smooth_basalt
fill 98 40 511 98 43 511 minecraft:blackstone
setblock 98 40 545 minecraft:smooth_basalt
fill 98 40 546 98 41 546 minecraft:blackstone
setblock 98 40 550 minecraft:smooth_basalt
fill 98 40 551 98 43 551 minecraft:blackstone
setblock 99 40 549 minecraft:smooth_basalt
fill 99 40 550 99 43 550 minecraft:blackstone
setblock 100 40 548 minecraft:smooth_basalt
fill 100 40 549 100 43 549 minecraft:blackstone
setblock 101 40 512 minecraft:smooth_basalt
fill 101 40 548 101 41 548 minecraft:blackstone
setblock 102 40 511 minecraft:smooth_basalt
fill 102 40 512 102 41 512 minecraft:blackstone
setblock 102 40 551 minecraft:smooth_basalt
fill 103 40 511 103 43 511 minecraft:blackstone
setblock 103 40 550 minecraft:smooth_basalt
fill 103 40 551 103 43 551 minecraft:blackstone
setblock 104 40 549 minecraft:smooth_basalt
fill 104 40 550 104 42 550 minecraft:blackstone
setblock 105 40 549 minecraft:blackstone
setblock 107 40 551 minecraft:smooth_basalt
fill 108 40 551 108 42 551 minecraft:blackstone
setblock 111 40 551 minecraft:blackstone
setblock 112 40 551 minecraft:smooth_basalt
fill 113 40 511 116 40 511 minecraft:blackstone
fill 113 40 551 116 40 551 minecraft:blackstone
fill 115 40 550 117 40 550 minecraft:blackstone
setblock 116 40 512 minecraft:smooth_basalt
setblock 117 40 511 minecraft:smooth_basalt
fill 117 40 512 120 40 512 minecraft:blackstone
setblock 117 40 551 minecraft:smooth_basalt
fill 118 40 511 118 43 511 minecraft:blackstone
setblock 118 40 550 minecraft:smooth_basalt
fill 118 40 551 118 43 551 minecraft:blackstone
setblock 119 40 513 minecraft:blackstone
setblock 119 40 549 minecraft:smooth_basalt
fill 119 40 550 119 43 550 minecraft:blackstone
setblock 120 40 513 minecraft:smooth_basalt
fill 120 40 549 120 41 549 minecraft:blackstone
setblock 121 40 512 minecraft:smooth_basalt
fill 121 40 513 121 43 513 minecraft:blackstone
setblock 122 40 511 minecraft:smooth_basalt
fill 122 40 512 122 43 512 minecraft:blackstone
fill 122 40 549 123 40 549 minecraft:blackstone
setblock 122 40 551 minecraft:smooth_basalt
fill 123 40 511 123 43 511 minecraft:blackstone
setblock 123 40 550 minecraft:smooth_basalt
fill 123 40 551 123 43 551 minecraft:blackstone
fill 124 40 550 124 43 550 minecraft:blackstone
setblock 126 40 512 minecraft:smooth_basalt
setblock 127 40 511 minecraft:smooth_basalt
fill 127 40 512 127 43 512 minecraft:blackstone
setblock 127 40 550 minecraft:blackstone
setblock 127 40 551 minecraft:smooth_basalt
fill 128 40 511 131 40 511 minecraft:blackstone
setblock 128 40 550 minecraft:smooth_basalt
fill 128 40 551 128 43 551 minecraft:blackstone
fill 129 40 550 132 40 550 minecraft:blackstone
setblock 131 40 512 minecraft:smooth_basalt
setblock 132 40 511 minecraft:smooth_basalt
fill 132 40 512 132 43 512 minecraft:blackstone
setblock 132 40 551 minecraft:smooth_basalt
fill 133 40 511 133 43 511 minecraft:blackstone
setblock 133 40 549 minecraft:blackstone
setblock 133 40 550 minecraft:smooth_basalt
fill 133 40 551 133 43 551 minecraft:blackstone
setblock 134 40 513 minecraft:blackstone
setblock 134 40 548 minecraft:blackstone
setblock 134 40 549 minecraft:smooth_basalt
fill 134 40 550 134 43 550 minecraft:blackstone
setblock 135 40 513 minecraft:smooth_basalt
fill 135 40 514 135 43 514 minecraft:blackstone
setblock 135 40 517 minecraft:blackstone
setblock 135 40 518 minecraft:smooth_basalt
setblock 135 40 523 minecraft:smooth_basalt
fill 135 40 524 135 42 524 minecraft:blackstone
setblock 135 40 527 minecraft:blackstone
setblock 135 40 528 minecraft:smooth_basalt
fill 135 40 529 135 43 529 minecraft:blackstone
setblock 135 40 533 minecraft:smooth_basalt
fill 135 40 534 135 43 534 minecraft:blackstone
setblock 135 40 542 minecraft:blackstone
setblock 135 40 543 minecraft:smooth_basalt
fill 135 40 544 135 43 544 minecraft:blackstone
setblock 135 40 548 minecraft:smooth_basalt
fill 135 40 549 135 43 549 minecraft:blackstone
setblock 95 41 511 minecraft:blackstone
setblock 95 41 512 minecraft:smooth_basalt
fill 95 41 513 96 43 513 minecraft:blackstone
fill 95 41 524 95 41 526 minecraft:blackstone
setblock 95 41 527 minecraft:smooth_basalt
fill 95 41 528 95 41 531 minecraft:blackstone
setblock 95 41 532 minecraft:smooth_basalt
fill 95 41 533 95 41 536 minecraft:blackstone
setblock 95 41 537 minecraft:smooth_basalt
fill 95 41 538 95 44 538 minecraft:blackstone
setblock 95 41 541 minecraft:blackstone
setblock 95 41 542 minecraft:smooth_basalt
fill 95 41 543 95 44 543 minecraft:blackstone
setblock 95 41 547 minecraft:smooth_basalt
fill 95 41 548 95 44 548 minecraft:blackstone
setblock 96 41 511 minecraft:smooth_basalt
fill 96 41 512 96 44 512 minecraft:blackstone
setblock 96 41 525 minecraft:blackstone
setblock 96 41 526 minecraft:smooth_basalt
fill 96 41 527 96 44 527 minecraft:blackstone
setblock 96 41 530 minecraft:blackstone
setblock 96 41 531 minecraft:smooth_basalt
fill 96 41 532 96 44 532 minecraft:blackstone
setblock 96 41 535 minecraft:blackstone
setblock 96 41 536 minecraft:smooth_basalt
fill 96 41 537 96 44 537 minecraft:blackstone
setblock 96 41 541 minecraft:smooth_basalt
fill 96 41 542 96 44 542 minecraft:blackstone
setblock 96 41 546 minecraft:smooth_basalt
fill 96 41 547 96 44 547 minecraft:blackstone
setblock 96 41 551 minecraft:smooth_basalt
fill 97 41 511 97 44 511 minecraft:blackstone
setblock 97 41 530 minecraft:smooth_basalt
fill 97 41 531 98 43 531 minecraft:blackstone
setblock 97 41 535 minecraft:smooth_basalt
fill 97 41 536 97 44 536 minecraft:blackstone
setblock 97 41 544 minecraft:blackstone
setblock 97 41 545 minecraft:smooth_basalt
fill 97 41 546 97 43 546 minecraft:blackstone
setblock 97 41 550 minecraft:smooth_basalt
fill 97 41 551 97 44 551 minecraft:blackstone
fill 98 41 530 98 42 530 minecraft:blackstone
setblock 98 41 549 minecraft:smooth_basalt
fill 98 41 550 98 44 550 minecraft:blackstone
setblock 99 41 512 minecraft:blackstone
setblock 99 41 548 minecraft:smooth_basalt
fill 99 41 549 99 44 549 minecraft:blackstone
setblock 100 41 512 minecraft:smooth_basalt
setblock 100 41 548 minecraft:blackstone
setblock 101 41 511 minecraft:smooth_basalt
fill 101 41 512 101 42 512 minecraft:blackstone
setblock 101 41 551 minecraft:smooth_basalt
fill 102 41 511 102 44 511 minecraft:blackstone
setblock 102 41 550 minecraft:smooth_basalt
fill 102 41 551 102 44 551 minecraft:blackstone
setblock 103 41 549 minecraft:smooth_basalt
fill 103 41 550 103 43 550 minecraft:blackstone
setblock 104 41 549 minecraft:blackstone
setblock 106 41 551 minecraft:smooth_basalt
fill 107 41 551 107 42 551 minecraft:blackstone
setblock 111 41 551 minecraft:smooth_basalt
fill 112 41 511 115 41 511 minecraft:blackstone
fill 112 41 551 115 41 551 minecraft:blackstone
setblock 115 41 512 minecraft:smooth_basalt
fill 115 41 550 116 41 550 minecraft:blackstone
setblock 116 41 511 minecraft:smooth_basalt
fill 116 41 512 119 41 512 minecraft:blackstone
setblock 116 41 551 minecraft:smooth_basalt
fill 117 41 511 117 44 511 minecraft:blackstone
setblock 117 41 550 minecraft:smooth_basalt
fill 117 41 551 117 44 551 minecraft:blackstone
setblock 118 41 513 minecraft:blackstone
fill 118 41 550 118 44 550 minecraft:blackstone
setblock 119 41 513 minecraft:smooth_basalt
setblock 119 41 549 minecraft:blackstone
setblock 120 41 512 minecraft:smooth_basalt
fill 120 41 513 120 44 513 minecraft:blackstone
setblock 121 41 511 minecraft:smooth_basalt
fill 121 41 512 121 44 512 minecraft:blackstone
setblock 121 41 551 minecraft:smooth_basalt
fill 122 41 511 122 44 511 minecraft:blackstone
fill 122 41 513 123 41 513 minecraft:blackstone
setblock 122 41 550 minecraft:smooth_basalt
fill 122 41 551 122 44 551 minecraft:blackstone
fill 123 41 550 123 43 550 minecraft:blackstone
setblock 124 41 513 minecraft:smooth_basalt
setblock 125 41 512 minecraft:smooth_basalt
setblock 126 41 511 minecraft:smooth_basalt
fill 126 41 512 126 44 512 minecraft:blackstone
setblock 126 41 551 minecraft:smooth_basalt
fill 127 41 511 130 41 511 minecraft:blackstone
setblock 127 41 550 minecraft:smooth_basalt
fill 127 41 551 127 44 551 minecraft:blackstone
fill 128 41 512 129 41 512 minecraft:blackstone
fill 128 41 550 131 41 550 minecraft:blackstone
setblock 130 41 512 minecraft:smooth_basalt
setblock 131 41 511 minecraft:smooth_basalt
fill 131 41 512 131 44 512 minecraft:blackstone
setblock 131 41 551 minecraft:smooth_basalt
fill 132 41 511 132 44 511 minecraft:blackstone
setblock 132 41 550 minecraft:smooth_basalt
fill 132 41 551 132 44 551 minecraft:blackstone
fill 133 41 512 134 41 512 minecraft:blackstone
setblock 133 41 549 minecraft:smooth_basalt
fill 133 41 550 133 44 550 minecraft:blackstone
setblock 134 41 513 minecraft:smooth_basalt
fill 134 41 514 134 44 514 minecraft:blackstone
setblock 134 41 548 minecraft:smooth_basalt
fill 134 41 549 134 44 549 minecraft:blackstone
setblock 135 41 512 minecraft:smooth_basalt
fill 135 41 513 135 44 513 minecraft:blackstone
setblock 135 41 517 minecraft:smooth_basalt
setblock 135 41 518 minecraft:blackstone
setblock 135 41 522 minecraft:smooth_basalt
setblock 135 41 523 minecraft:blackstone
setblock 135 41 527 minecraft:smooth_basalt
fill 135 41 528 135 44 528 minecraft:blackstone
fill 135 41 530 135 41 531 minecraft:blackstone
setblock 135 41 532 minecraft:smooth_basalt
fill 135 41 533 135 44 533 minecraft:blackstone
fill 135 41 535 135 42 535 minecraft:blackstone
setblock 135 41 542 minecraft:smooth_basalt
fill 135 41 543 135 44 543 minecraft:blackstone
setblock 135 41 547 minecraft:smooth_basalt
fill 135 41 548 135 44 548 minecraft:blackstone
setblock 95 42 511 minecraft:smooth_basalt
fill 95 42 512 95 45 512 minecraft:blackstone
setblock 95 42 515 minecraft:blackstone
fill 95 42 524 95 42 525 minecraft:blackstone
setblock 95 42 526 minecraft:smooth_basalt
fill 95 42 527 95 42 530 minecraft:blackstone
setblock 95 42 531 minecraft:smooth_basalt
fill 95 42 532 95 42 535 minecraft:blackstone
setblock 95 42 536 minecraft:smooth_basalt
fill 95 42 537 95 45 537 minecraft:blackstone
setblock 95 42 540 minecraft:blackstone
setblock 95 42 541 minecraft:smooth_basalt
fill 95 42 542 95 45 542 minecraft:blackstone
setblock 95 42 546 minecraft:smooth_basalt
fill 95 42 547 95 45 547 minecraft:blackstone
setblock 95 42 551 minecraft:smooth_basalt
fill 96 42 511 96 45 511 minecraft:blackstone
fill 96 42 526 96 43 526 minecraft:blackstone
setblock 96 42 529 minecraft:blackstone
setblock 96 42 530 minecraft:smooth_basalt
fill 96 42 531 96 45 531 minecraft:blackstone
setblock 96 42 535 minecraft:smooth_basalt
fill 96 42 536 96 45 536 minecraft:blackstone
setblock 96 42 540 minecraft:smooth_basalt
fill 96 42 541 96 45 541 minecraft:blackstone
setblock 96 42 545 minecraft:smooth_basalt
fill 96 42 546 96 45 546 minecraft:blackstone
setblock 96 42 550 minecraft:smooth_basalt
fill 96 42 551 96 45 551 minecraft:blackstone
setblock 97 42 529 minecraft:smooth_basalt
fill 97 42 530 97 45 530 minecraft:blackstone
setblock 97 42 534 minecraft:smooth_basalt
fill 97 42 535 97 45 535 minecraft:blackstone
fill 97 42 537 97 43 537 minecraft:blackstone
setblock 97 42 544 minecraft:smooth_basalt
fill 97 42 545 97 43 545 minecraft:blackstone
setblock 97 42 549 minecraft:smooth_basalt
fill 97 42 550 97 45 550 minecraft:blackstone
setblock 98 42 532 minecraft:blackstone
setblock 98 42 533 minecraft:smooth_basalt
setblock 98 42 548 minecraft:smooth_basalt
fill 98 42 549 98 44 549 minecraft:blackstone
setblock 99 42 512 minecraft:smooth_basalt
setblock 99 42 548 minecraft:blackstone
setblock 100 42 511 minecraft:smooth_basalt
fill 100 42 512 100 44 512 minecraft:blackstone
setblock 100 42 551 minecraft:smooth_basalt
fill 101 42 511 101 45 511 minecraft:blackstone
setblock 101 42 550 minecraft:smooth_basalt
fill 101 42 551 101 45 551 minecraft:blackstone
setblock 102 42 549 minecraft:smooth_basalt
fill 102 42 550 102 44 550 minecraft:blackstone
setblock 105 42 511 minecraft:smooth_basalt
setblock 105 42 551 minecraft:smooth_basalt
fill 106 42 551 106 43 551 minecraft:blackstone
fill 111 42 551 114 42 551 minecraft:blackstone
fill 112 42 511 114 42 511 minecraft:blackstone
setblock 114 42 512 minecraft:smooth_basalt
setblock 115 42 511 minecraft:smooth_basalt
fill 115 42 512 118 42 512 minecraft:blackstone
setblock 115 42 550 minecraft:blackstone
setblock 115 42 551 minecraft:smooth_basalt
fill 116 42 511 116 45 511 minecraft:blackstone
setblock 116 42 550 minecraft:smooth_basalt
fill 116 42 551 116 45 551 minecraft:blackstone
setblock 117 42 513 minecraft:blackstone
fill 117 42 550 117 44 550 minecraft:blackstone
setblock 118 42 513 minecraft:smooth_basalt
setblock 119 42 512 minecraft:smooth_basalt
fill 119 42 513 119 45 513 minecraft:blackstone
setblock 120 42 511 minecraft:smooth_basalt
fill 120 42 512 120 45 512 minecraft:blackstone
setblock 120 42 551 minecraft:smooth_basalt
fill 121 42 511 121 45 511 minecraft:blackstone
setblock 121 42 550 minecraft:smooth_basalt
fill 121 42 551 121 45 551 minecraft:blackstone
setblock 122 42 513 minecraft:blackstone
fill 122 42 550 122 43 550 minecraft:blackstone
setblock 123 42 513 minecraft:smooth_basalt
setblock 124 42 512 minecraft:smooth_basalt
setblock 124 42 513 minecraft:blackstone
setblock 125 42 511 minecraft:smooth_basalt
fill 125 42 512 125 45 512 minecraft:blackstone
setblock 125 42 551 minecraft:smooth_basalt
fill 126 42 511 129 42 511 minecraft:blackstone
setblock 126 42 550 minecraft:smooth_basalt
fill 126 42 551 126 45 551 minecraft:blackstone
fill 127 42 550 130 42 550 minecraft:blackstone
setblock 128 42 512 minecraft:blackstone
setblock 129 42 512 minecraft:smooth_basalt
setblock 130 42 511 minecraft:smooth_basalt
fill 130 42 512 130 45 512 minecraft:blackstone
setblock 130 42 551 minecraft:smooth_basalt
fill 131 42 511 131 45 511 minecraft:blackstone
setblock 131 42 550 minecraft:smooth_basalt
fill 131 42 551 131 45 551 minecraft:blackstone
fill 132 42 550 132 45 550 minecraft:blackstone
setblock 133 42 512 minecraft:blackstone
setblock 134 42 512 minecraft:smooth_basalt
fill 134 42 513 134 45 513 minecraft:blackstone
setblock 134 42 547 minecraft:smooth_basalt
fill 134 42 548 134 45 548 minecraft:blackstone
setblock 135 42 511 minecraft:smooth_basalt
fill 135 42 512 135 45 512 minecraft:blackstone
setblock 135 42 516 minecraft:smooth_basalt
fill 135 42 517 135 45 517 minecraft:blackstone
setblock 135 42 526 minecraft:smooth_basalt
fill 135 42 527 135 44 527 minecraft:blackstone
setblock 135 42 530 minecraft:blackstone
setblock 135 42 531 minecraft:smooth_basalt
fill 135 42 532 135 45 532 minecraft:blackstone
setblock 135 42 536 minecraft:smooth_basalt
fill 135 42 537 135 45 537 minecraft:blackstone
fill 135 42 542 135 45 542 minecraft:blackstone
setblock 135 42 546 minecraft:smooth_basalt
fill 135 42 547 135 45 547 minecraft:blackstone
setblock 135 42 551 minecraft:smooth_basalt
fill 95 43 511 95 46 511 minecraft:blackstone
setblock 95 43 515 minecraft:smooth_basalt
setblock 95 43 525 minecraft:smooth_basalt
fill 95 43 526 95 43 529 minecraft:blackstone
setblock 95 43 530 minecraft:smooth_basalt
fill 95 43 531 95 43 534 minecraft:blackstone
setblock 95 43 535 minecraft:smooth_basalt
fill 95 43 536 95 46 536 minecraft:blackstone
setblock 95 43 539 minecraft:blackstone
setblock 95 43 540 minecraft:smooth_basalt
fill 95 43 541 95 46 541 minecraft:blackstone
setblock 95 43 545 minecraft:smooth_basalt
fill 95 43 546 95 46 546 minecraft:blackstone
setblock 95 43 550 minecraft:smooth_basalt
fill 95 43 551 95 46 551 minecraft:blackstone
setblock 96 43 529 minecraft:smooth_basalt
fill 96 43 530 96 46 530 minecraft:blackstone
setblock 96 43 533 minecraft:blackstone
setblock 96 43 534 minecraft:smooth_basalt
fill 96 43 535 96 46 535 minecraft:blackstone
setblock 96 43 539 minecraft:smooth_basalt
fill 96 43 540 96 46 540 minecraft:blackstone
setblock 96 43 544 minecraft:smooth_basalt
fill 96 43 545 96 46 545 minecraft:blackstone
setblock 96 43 549 minecraft:smooth_basalt
fill 96 43 550 96 46 550 minecraft:blackstone
setblock 97 43 528 minecraft:smooth_basalt
fill 97 43 529 97 44 529 minecraft:blackstone
setblock 97 43 533 minecraft:smooth_basalt
fill 97 43 534 97 46 534 minecraft:blackstone
setblock 97 43 548 minecraft:smooth_basalt
fill 97 43 549 97 45 549 minecraft:blackstone
setblock 98 43 512 minecraft:smooth_basalt
setblock 98 43 532 minecraft:smooth_basalt
fill 98 43 533 98 44 533 minecraft:blackstone
setblock 99 43 511 minecraft:smooth_basalt
fill 99 43 512 99 45 512 minecraft:blackstone
setblock 99 43 551 minecraft:smooth_basalt
fill 100 43 511 100 46 511 minecraft:blackstone
setblock 100 43 550 minecraft:smooth_basalt
fill 100 43 551 100 46 551 minecraft:blackstone
setblock 101 43 549 minecraft:smooth_basalt
fill 101 43 550 101 44 550 minecraft:blackstone
setblock 104 43 511 minecraft:smooth_basalt
setblock 104 43 551 minecraft:smooth_basalt
setblock 105 43 551 minecraft:blackstone
fill 111 43 511 113 43 511 minecraft:blackstone
fill 112 43 551 113 43 551 minecraft:blackstone
setblock 114 43 511 minecraft:smooth_basalt
fill 114 43 512 117 43 512 minecraft:blackstone
setblock 114 43 551 minecraft:smooth_basalt
fill 115 43 511 115 46 511 minecraft:blackstone
fill 115 43 551 115 46 551 minecraft:blackstone
setblock 116 43 513 minecraft:blackstone
setblock 116 43 550 minecraft:blackstone
setblock 117 43 513 minecraft:smooth_basalt
setblock 118 43 512 minecraft:smooth_basalt
fill 118 43 513 118 46 513 minecraft:blackstone
setblock 119 43 511 minecraft:smooth_basalt
fill 119 43 512 119 46 512 minecraft:blackstone
setblock 119 43 551 minecraft:smooth_basalt
fill 120 43 511 120 46 511 minecraft:blackstone
setblock 120 43 550 minecraft:smooth_basalt
fill 120 43 551 120 46 551 minecraft:blackstone
fill 121 43 550 121 44 550 minecraft:blackstone
setblock 122 43 513 minecraft:smooth_basalt
setblock 123 43 512 minecraft:smooth_basalt
fill 123 43 513 123 44 513 minecraft:blackstone
setblock 124 43 511 minecraft:smooth_basalt
fill 124 43 512 124 46 512 minecraft:blackstone
setblock 124 43 551 minecraft:smooth_basalt
fill 125 43 511 128 43 511 minecraft:blackstone
fill 125 43 551 125 46 551 minecraft:blackstone
setblock 128 43 512 minecraft:smooth_basalt
setblock 129 43 511 minecraft:smooth_basalt
fill 129 43 512 129 46 512 minecraft:blackstone
setblock 129 43 551 minecraft:smooth_basalt
fill 130 43 511 130 46 511 minecraft:blackstone
setblock 130 43 550 minecraft:smooth_basalt
fill 130 43 551 130 46 551 minecraft:blackstone
fill 131 43 550 131 45 550 minecraft:blackstone
setblock 133 43 512 minecraft:smooth_basalt
setblock 134 43 511 minecraft:smooth_basalt
fill 134 43 512 134 46 512 minecraft:blackstone
setblock 134 43 546 minecraft:smooth_basalt
fill 134 43 547 134 46 547 minecraft:blackstone
setblock 134 43 551 minecraft:smooth_basalt
fill 135 43 511 135 46 511 minecraft:blackstone
setblock 135 43 515 minecraft:smooth_basalt
fill 135 43 516 135 46 516 minecraft:blackstone
setblock 135 43 525 minecraft:smooth_basalt
setblock 135 43 526 minecraft:blackstone
setblock 135 43 530 minecraft:smooth_basalt
fill 135 43 531 135 46 531 minecraft:blackstone
setblock 135 43 535 minecraft:smooth_basalt
fill 135 43 536 135 46 536 minecraft:blackstone
fill 135 43 538 135 43 539 minecraft:blackstone
fill 135 43 541 135 46 541 minecraft:blackstone
setblock 135 43 545 minecraft:smooth_basalt
fill 135 43 546 135 46 546 minecraft:blackstone
setblock 135 43 550 minecraft:smooth_basalt
fill 135 43 551 135 46 551 minecraft:blackstone
setblock 95 44 513 minecraft:blackstone
setblock 95 44 514 minecraft:smooth_basalt
fill 95 44 515 95 47 515 minecraft:blackstone
fill 95 44 525 95 44 528 minecraft:blackstone
setblock 95 44 529 minecraft:smooth_basalt
fill 95 44 530 95 44 533 minecraft:blackstone
setblock 95 44 534 minecraft:smooth_basalt
fill 95 44 535 95 47 535 minecraft:blackstone
setblock 95 44 539 minecraft:smooth_basalt
fill 95 44 540 95 47 540 minecraft:blackstone
setblock 95 44 544 minecraft:smooth_basalt
fill 95 44 545 95 47 545 minecraft:blackstone
setblock 95 44 549 minecraft:smooth_basalt
fill 95 44 550 95 47 550 minecraft:blackstone
setblock 96 44 513 minecraft:smooth_basalt
setblock 96 44 528 minecraft:smooth_basalt
fill 96 44 529 96 47 529 minecraft:blackstone
setblock 96 44 533 minecraft:smooth_basalt
fill 96 44 534 96 47 534 minecraft:blackstone
setblock 96 44 538 minecraft:smooth_basalt
fill 96 44 539 96 47 539 minecraft:blackstone
setblock 96 44 543 minecraft:smooth_basalt
fill 96 44 544 96 47 544 minecraft:blackstone
setblock 96 44 548 minecraft:smooth_basalt
fill 96 44 549 96 47 549 minecraft:blackstone
setblock 97 44 512 minecraft:smooth_basalt
setblock 97 44 531 minecraft:blackstone
setblock 97 44 532 minecraft:smooth_basalt
fill 97 44 533 97 47 533 minecraft:blackstone
setblock 97 44 537 minecraft:smooth_basalt
fill 97 44 538 97 47 538 minecraft:blackstone
setblock 97 44 547 minecraft:smooth_basalt
setblock 97 44 548 minecraft:blackstone
setblock 98 44 511 minecraft:smooth_basalt
fill 98 44 512 98 46 512 minecraft:blackstone
setblock 98 44 532 minecraft:blackstone
setblock 98 44 551 minecraft:smooth_basalt
fill 99 44 511 99 47 511 minecraft:blackstone
setblock 99 44 550 minecraft:smooth_basalt
fill 99 44 551 99 47 551 minecraft:blackstone
fill 100 44 550 100 45 550 minecraft:blackstone
setblock 103 44 511 minecraft:smooth_basalt
setblock 103 44 551 minecraft:smooth_basalt
setblock 104 44 551 minecraft:blackstone
fill 111 44 511 112 44 511 minecraft:blackstone
setblock 113 44 511 minecraft:smooth_basalt
fill 113 44 512 116 44 512 minecraft:blackstone
setblock 113 44 551 minecraft:smooth_basalt
fill 114 44 511 114 47 511 minecraft:blackstone
fill 114 44 551 114 47 551 minecraft:blackstone
setblock 116 44 513 minecraft:smooth_basalt
setblock 117 44 512 minecraft:smooth_basalt
fill 117 44 513 117 47 513 minecraft:blackstone
setblock 118 44 511 minecraft:smooth_basalt
fill 118 44 512 118 47 512 minecraft:blackstone
setblock 118 44 551 minecraft:smooth_basalt
fill 119 44 511 119 47 511 minecraft:blackstone
setblock 119 44 550 minecraft:smooth_basalt
fill 119 44 551 119 47 551 minecraft:blackstone
setblock 120 44 550 minecraft:blackstone
setblock 121 44 513 minecraft:smooth_basalt
setblock 122 44 512 minecraft:smooth_basalt
fill 122 44 513 122 46 513 minecraft:blackstone
setblock 123 44 511 minecraft:smooth_basalt
fill 123 44 512 123 47 512 minecraft:blackstone
setblock 123 44 551 minecraft:smooth_basalt
fill 124 44 511 127 44 511 minecraft:blackstone
fill 124 44 551 124 46 551 minecraft:blackstone
setblock 127 44 512 minecraft:smooth_basalt
setblock 128 44 511 minecraft:smooth_basalt
fill 128 44 512 128 47 512 minecraft:blackstone
setblock 128 44 551 minecraft:smooth_basalt
fill 129 44 511 129 47 511 minecraft:blackstone
fill 129 44 551 129 47 551 minecraft:blackstone
setblock 132 44 512 minecraft:smooth_basalt
setblock 133 44 511 minecraft:smooth_basalt
fill 133 44 512 133 47 512 minecraft:blackstone
setblock 133 44 551 minecraft:smooth_basalt
fill 134 44 511 134 47 511 minecraft:blackstone
setblock 134 44 515 minecraft:smooth_basalt
setblock 134 44 550 minecraft:smooth_basalt
fill 134 44 551 134 47 551 minecraft:blackstone
setblock 135 44 514 minecraft:smooth_basalt
fill 135 44 515 135 47 515 minecraft:blackstone
setblock 135 44 529 minecraft:smooth_basalt
fill 135 44 530 135 47 530 minecraft:blackstone
setblock 135 44 534 minecraft:smooth_basalt
fill 135 44 535 135 47 535 minecraft:blackstone
setblock 135 44 538 minecraft:blackstone
setblock 135 44 539 minecraft:smooth_basalt
fill 135 44 540 135 47 540 minecraft:blackstone
setblock 135 44 544 minecraft:smooth_basalt
fill 135 44 545 135 47 545 minecraft:blackstone
setblock 135 44 549 minecraft:smooth_basalt
fill 135 44 550 135 47 550 minecraft:blackstone
setblock 95 45 513 minecraft:smooth_basalt
fill 95 45 514 95 48 514 minecraft:blackstone
fill 95 45 516 95 46 516 minecraft:blackstone
fill 95 45 526 95 45 527 minecraft:blackstone
setblock 95 45 528 minecraft:smooth_basalt
fill 95 45 529 95 45 532 minecraft:blackstone
setblock 95 45 533 minecraft:smooth_basalt
fill 95 45 534 95 48 534 minecraft:blackstone
setblock 95 45 538 minecraft:smooth_basalt
fill 95 45 539 95 48 539 minecraft:blackstone
setblock 95 45 543 minecraft:smooth_basalt
fill 95 45 544 95 48 544 minecraft:blackstone
setblock 95 45 548 minecraft:smooth_basalt
fill 95 45 549 95 48 549 minecraft:blackstone
setblock 96 45 512 minecraft:smooth_basalt
fill 96 45 513 96 48 513 minecraft:blackstone
fill 96 45 528 96 47 528 minecraft:blackstone
setblock 96 45 532 minecraft:smooth_basalt
fill 96 45 533 96 48 533 minecraft:blackstone
setblock 96 45 537 minecraft:smooth_basalt
fill 96 45 538 96 48 538 minecraft:blackstone
setblock 96 45 542 minecraft:smooth_basalt
fill 96 45 543 96 48 543 minecraft:blackstone
setblock 96 45 547 minecraft:smooth_basalt
fill 96 45 548 96 48 548 minecraft:blackstone
setblock 97 45 511 minecraft:smooth_basalt
fill 97 45 512 97 48 512 minecraft:blackstone
setblock 97 45 513 minecraft:light[level=12]
setblock 97 45 521 minecraft:light[level=12]
setblock 97 45 529 minecraft:light[level=12]
setblock 97 45 531 minecraft:smooth_basalt
fill 97 45 532 97 48 532 minecraft:blackstone
setblock 97 45 536 minecraft:smooth_basalt
fill 97 45 537 97 48 537 minecraft:blackstone
setblock 97 45 545 minecraft:light[level=12]
setblock 97 45 551 minecraft:smooth_basalt
fill 98 45 511 98 48 511 minecraft:blackstone
setblock 98 45 550 minecraft:smooth_basalt
fill 98 45 551 98 48 551 minecraft:blackstone
fill 99 45 550 99 46 550 minecraft:blackstone
setblock 102 45 511 minecraft:smooth_basalt
setblock 102 45 551 minecraft:smooth_basalt
setblock 103 45 551 minecraft:blackstone
setblock 105 45 513 minecraft:light[level=12]
setblock 105 45 521 minecraft:light[level=12]
setblock 105 45 529 minecraft:light[level=12]
setblock 105 45 537 minecraft:light[level=12]
setblock 105 45 545 minecraft:light[level=12]
setblock 111 45 511 minecraft:blackstone
setblock 112 45 511 minecraft:smooth_basalt
fill 113 45 511 113 47 512 minecraft:blackstone
setblock 113 45 513 minecraft:light[level=12]
setblock 113 45 521 minecraft:light[level=12]
setblock 113 45 529 minecraft:light[level=12]
setblock 113 45 537 minecraft:light[level=12]
setblock 113 45 545 minecraft:light[level=12]
fill 113 45 551 113 48 551 minecraft:blackstone
fill 114 45 512 115 45 512 minecraft:blackstone
setblock 115 45 513 minecraft:smooth_basalt
setblock 116 45 512 minecraft:smooth_basalt
fill 116 45 513 116 48 513 minecraft:blackstone
setblock 117 45 511 minecraft:smooth_basalt
fill 117 45 512 117 48 512 minecraft:blackstone
setblock 117 45 551 minecraft:smooth_basalt
fill 118 45 511 118 48 511 minecraft:blackstone
fill 118 45 551 118 48 551 minecraft:blackstone
setblock 120 45 513 minecraft:smooth_basalt
setblock 121 45 512 minecraft:smooth_basalt
fill 121 45 513 121 48 513 minecraft:blackstone
setblock 121 45 521 minecraft:light[level=12]
setblock 121 45 529 minecraft:light[level=12]
setblock 121 45 537 minecraft:light[level=12]
setblock 121 45 545 minecraft:light[level=12]
setblock 122 45 511 minecraft:smooth_basalt
fill 122 45 512 122 48 512 minecraft:blackstone
setblock 122 45 551 minecraft:smooth_basalt
fill 123 45 511 126 45 511 minecraft:blackstone
fill 123 45 551 123 47 551 minecraft:blackstone
setblock 126 45 512 minecraft:smooth_basalt
setblock 127 45 511 minecraft:smooth_basalt
fill 127 45 512 127 48 512 minecraft:blackstone
setblock 127 45 551 minecraft:smooth_basalt
fill 128 45 511 128 48 511 minecraft:blackstone
fill 128 45 551 128 48 551 minecraft:blackstone
setblock 129 45 513 minecraft:light[level=12]
setblock 129 45 521 minecraft:light[level=12]
setblock 129 45 529 minecraft:light[level=12]
setblock 129 45 537 minecraft:light[level=12]
setblock 131 45 512 minecraft:smooth_basalt
setblock 132 45 511 minecraft:smooth_basalt
fill 132 45 512 132 48 512 minecraft:blackstone
setblock 132 45 551 minecraft:smooth_basalt
fill 133 45 511 133 48 511 minecraft:blackstone
setblock 133 45 550 minecraft:smooth_basalt
fill 133 45 551 133 48 551 minecraft:blackstone
setblock 134 45 514 minecraft:smooth_basalt
fill 134 45 515 134 48 515 minecraft:blackstone
setblock 134 45 549 minecraft:smooth_basalt
fill 134 45 550 134 48 550 minecraft:blackstone
setblock 135 45 513 minecraft:smooth_basalt
fill 135 45 514 135 48 514 minecraft:blackstone
setblock 135 45 528 minecraft:smooth_basalt
fill 135 45 529 135 48 529 minecraft:blackstone
setblock 135 45 533 minecraft:smooth_basalt
fill 135 45 534 135 48 534 minecraft:blackstone
setblock 135 45 538 minecraft:smooth_basalt
fill 135 45 539 135 48 539 minecraft:blackstone
setblock 135 45 543 minecraft:smooth_basalt
fill 135 45 544 135 48 544 minecraft:blackstone
setblock 135 45 548 minecraft:smooth_basalt
fill 135 45 549 135 48 549 minecraft:blackstone
setblock 95 46 512 minecraft:smooth_basalt
fill 95 46 513 95 49 513 minecraft:blackstone
setblock 95 46 526 minecraft:blackstone
setblock 95 46 527 minecraft:smooth_basalt
fill 95 46 528 95 46 531 minecraft:blackstone
setblock 95 46 532 minecraft:smooth_basalt
fill 95 46 533 95 49 533 minecraft:blackstone
setblock 95 46 537 minecraft:smooth_basalt
fill 95 46 538 95 49 538 minecraft:blackstone
setblock 95 46 542 minecraft:smooth_basalt
fill 95 46 543 95 49 543 minecraft:blackstone
setblock 95 46 547 minecraft:smooth_basalt
fill 95 46 548 95 49 548 minecraft:blackstone
setblock 96 46 511 minecraft:smooth_basalt
fill 96 46 512 96 49 512 minecraft:blackstone
setblock 96 46 531 minecraft:smooth_basalt
fill 96 46 532 96 49 532 minecraft:blackstone
setblock 96 46 536 minecraft:smooth_basalt
fill 96 46 537 96 49 537 minecraft:blackstone
setblock 96 46 541 minecraft:smooth_basalt
fill 96 46 542 96 49 542 minecraft:blackstone
setblock 96 46 546 minecraft:smooth_basalt
fill 96 46 547 96 47 547 minecraft:blackstone
setblock 96 46 551 minecraft:smooth_basalt
fill 97 46 511 97 49 511 minecraft:blackstone
setblock 97 46 530 minecraft:smooth_basalt
fill 97 46 531 97 49 531 minecraft:blackstone
setblock 97 46 535 minecraft:smooth_basalt
fill 97 46 536 97 49 536 minecraft:blackstone
setblock 97 46 539 minecraft:blackstone
setblock 97 46 550 minecraft:smooth_basalt
fill 97 46 551 97 49 551 minecraft:blackstone
fill 98 46 550 98 47 550 minecraft:blackstone
setblock 101 46 511 minecraft:smooth_basalt
setblock 101 46 551 minecraft:smooth_basalt
setblock 102 46 551 minecraft:blackstone
setblock 110 46 511 minecraft:blackstone
setblock 111 46 511 minecraft:smooth_basalt
fill 112 46 511 112 48 512 minecraft:blackstone
setblock 114 46 512 minecraft:blackstone
setblock 115 46 512 minecraft:smooth_basalt
fill 115 46 513 115 49 513 minecraft:blackstone
setblock 116 46 511 minecraft:smooth_basalt
fill 116 46 512 116 49 512 minecraft:blackstone
setblock 116 46 551 minecraft:smooth_basalt
fill 117 46 511 117 49 511 minecraft:blackstone
fill 117 46 551 117 49 551 minecraft:blackstone
setblock 119 46 513 minecraft:smooth_basalt
setblock 120 46 512 minecraft:smooth_basalt
fill 120 46 513 120 49 513 minecraft:blackstone
setblock 121 46 511 minecraft:smooth_basalt
fill 121 46 512 121 49 512 minecraft:blackstone
setblock 121 46 551 minecraft:smooth_basalt
fill 122 46 511 125 46 511 minecraft:blackstone
fill 122 46 551 122 47 551 minecraft:blackstone
setblock 125 46 512 minecraft:smooth_basalt
setblock 126 46 511 minecraft:smooth_basalt
fill 126 46 512 126 49 512 minecraft:blackstone
setblock 126 46 551 minecraft:smooth_basalt
fill 127 46 511 127 49 511 minecraft:blackstone
fill 127 46 551 127 47 551 minecraft:blackstone
setblock 130 46 512 minecraft:smooth_basalt
setblock 131 46 511 minecraft:smooth_basalt
fill 131 46 512 131 49 512 minecraft:blackstone
setblock 131 46 551 minecraft:smooth_basalt
fill 132 46 511 132 49 511 minecraft:blackstone
setblock 132 46 550 minecraft:smooth_basalt
fill 132 46 551 132 49 551 minecraft:blackstone
fill 133 46 550 133 49 550 minecraft:blackstone
setblock 134 46 513 minecraft:smooth_basalt
fill 134 46 514 134 49 514 minecraft:blackstone
fill 134 46 534 134 49 534 minecraft:blackstone
setblock 134 46 548 minecraft:smooth_basalt
fill 134 46 549 134 49 549 minecraft:blackstone
setblock 135 46 512 minecraft:smooth_basalt
fill 135 46 513 135 49 513 minecraft:blackstone
setblock 135 46 517 minecraft:smooth_basalt
fill 135 46 518 135 49 518 minecraft:blackstone
setblock 135 46 528 minecraft:blackstone
setblock 135 46 532 minecraft:smooth_basalt
fill 135 46 533 135 49 533 minecraft:blackstone
setblock 135 46 537 minecraft:smooth_basalt
fill 135 46 538 135 49 538 minecraft:blackstone
setblock 135 46 542 minecraft:smooth_basalt
fill 135 46 543 135 49 543 minecraft:blackstone
setblock 135 46 547 minecraft:smooth_basalt
fill 135 46 548 135 49 548 minecraft:blackstone
setblock 95 47 511 minecraft:smooth_basalt
fill 95 47 512 95 50 512 minecraft:blackstone
setblock 95 47 516 minecraft:smooth_basalt
fill 95 47 517 95 50 517 minecraft:blackstone
fill 95 47 527 95 47 530 minecraft:blackstone
setblock 95 47 531 minecraft:smooth_basalt
fill 95 47 532 95 50 532 minecraft:blackstone
setblock 95 47 536 minecraft:smooth_basalt
fill 95 47 537 95 50 537 minecraft:blackstone
setblock 95 47 541 minecraft:smooth_basalt
fill 95 47 542 95 50 542 minecraft:blackstone
setblock 95 47 546 minecraft:smooth_basalt
fill 95 47 547 95 50 547 minecraft:blackstone
setblock 95 47 551 minecraft:smooth_basalt
fill 96 47 511 96 50 511 minecraft:blackstone
setblock 96 47 514 minecraft:blackstone
setblock 96 47 530 minecraft:smooth_basalt
fill 96 47 531 96 50 531 minecraft:blackstone
setblock 96 47 535 minecraft:smooth_basalt
fill 96 47 536 96 50 536 minecraft:blackstone
setblock 96 47 540 minecraft:smooth_basalt
fill 96 47 541 96 50 541 minecraft:blackstone
setblock 96 47 545 minecraft:smooth_basalt
setblock 96 47 546 minecraft:blackstone
setblock 96 47 550 minecraft:smooth_basalt
fill 96 47 551 96 50 551 minecraft:blackstone
setblock 97 47 534 minecraft:smooth_basalt
fill 97 47 535 97 50 535 minecraft:blackstone
setblock 97 47 539 minecraft:smooth_basalt
fill 97 47 550 97 48 550 minecraft:blackstone
setblock 100 47 511 minecraft:smooth_basalt
setblock 100 47 551 minecraft:smooth_basalt
setblock 101 47 511 minecraft:blackstone
setblock 110 47 511 minecraft:smooth_basalt
fill 111 47 511 111 50 511 minecraft:blackstone
setblock 114 47 512 minecraft:smooth_basalt
fill 114 47 513 114 50 513 minecraft:blackstone
setblock 115 47 511 minecraft:smooth_basalt
fill 115 47 512 115 50 512 minecraft:blackstone
setblock 115 47 551 minecraft:smooth_basalt
fill 116 47 511 116 50 511 minecraft:blackstone
fill 116 47 551 116 50 551 minecraft:blackstone
setblock 118 47 513 minecraft:smooth_basalt
setblock 119 47 512 minecraft:smooth_basalt
fill 119 47 513 119 50 513 minecraft:blackstone
setblock 120 47 511 minecraft:smooth_basalt
fill 120 47 512 120 50 512 minecraft:blackstone
setblock 120 47 551 minecraft:smooth_basalt
fill 121 47 511 124 47 511 minecraft:blackstone
fill 121 47 551 121 48 551 minecraft:blackstone
setblock 124 47 512 minecraft:smooth_basalt
setblock 125 47 511 minecraft:smooth_basalt
fill 125 47 512 125 50 512 minecraft:blackstone
fill 126 47 511 126 50 511 minecraft:blackstone
setblock 129 47 512 minecraft:smooth_basalt
setblock 130 47 511 minecraft:smooth_basalt
fill 130 47 512 130 50 512 minecraft:blackstone
setblock 130 47 551 minecraft:smooth_basalt
fill 131 47 511 131 50 511 minecraft:blackstone
fill 131 47 551 131 50 551 minecraft:blackstone
fill 132 47 550 132 50 550 minecraft:blackstone
setblock 133 47 513 minecraft:smooth_basalt
setblock 134 47 512 minecraft:smooth_basalt
fill 134 47 513 134 50 513 minecraft:blackstone
setblock 134 47 516 minecraft:blackstone
fill 134 47 533 134 50 533 minecraft:blackstone
fill 134 47 535 134 47 536 minecraft:blackstone
setblock 134 47 537 minecraft:smooth_basalt
fill 134 47 538 134 50 538 minecraft:blackstone
fill 134 47 548 134 50 548 minecraft:blackstone
setblock 135 47 511 minecraft:smooth_basalt
fill 135 47 512 135 50 512 minecraft:blackstone
setblock 135 47 516 minecraft:smooth_basalt
fill 135 47 517 135 50 517 minecraft:blackstone
setblock 135 47 531 minecraft:smooth_basalt
fill 135 47 532 135 50 532 minecraft:blackstone
setblock 135 47 536 minecraft:smooth_basalt
fill 135 47 537 135 50 537 minecraft:blackstone
setblock 135 47 541 minecraft:smooth_basalt
fill 135 47 542 135 50 542 minecraft:blackstone
setblock 135 47 546 minecraft:smooth_basalt
fill 135 47 547 135 50 547 minecraft:blackstone
setblock 135 47 551 minecraft:smooth_basalt
fill 95 48 511 95 51 511 minecraft:blackstone
setblock 95 48 515 minecraft:smooth_basalt
fill 95 48 516 95 51 516 minecraft:blackstone
fill 95 48 518 95 49 518 minecraft:blackstone
fill 95 48 527 95 48 529 minecraft:blackstone
setblock 95 48 530 minecraft:smooth_basalt
fill 95 48 531 95 51 531 minecraft:blackstone
setblock 95 48 535 minecraft:smooth_basalt
fill 95 48 536 95 51 536 minecraft:blackstone
setblock 95 48 540 minecraft:smooth_basalt
fill 95 48 541 95 51 541 minecraft:blackstone
setblock 95 48 545 minecraft:smooth_basalt
fill 95 48 546 95 51 546 minecraft:blackstone
setblock 95 48 550 minecraft:smooth_basalt
fill 95 48 551 95 51 551 minecraft:blackstone
setblock 96 48 514 minecraft:smooth_basalt
setblock 96 48 529 minecraft:smooth_basalt
fill 96 48 530 96 51 530 minecraft:blackstone
setblock 96 48 534 minecraft:smooth_basalt
fill 96 48 535 96 51 535 minecraft:blackstone
setblock 96 48 539 minecraft:smooth_basalt
fill 96 48 540 97 50 540 minecraft:blackstone
setblock 96 48 544 minecraft:smooth_basalt
setblock 96 48 549 minecraft:smooth_basalt
fill 96 48 550 96 49 550 minecraft:blackstone
setblock 97 48 533 minecraft:smooth_basalt
fill 97 48 534 97 51 534 minecraft:blackstone
setblock 97 48 538 minecraft:smooth_basalt
fill 97 48 539 97 51 539 minecraft:blackstone
setblock 99 48 511 minecraft:smooth_basalt
setblock 99 48 551 minecraft:smooth_basalt
fill 100 48 511 100 49 511 minecraft:blackstone
setblock 100 48 551 minecraft:blackstone
setblock 109 48 511 minecraft:smooth_basalt
fill 110 48 511 110 51 511 minecraft:blackstone
fill 111 48 512 111 49 512 minecraft:blackstone
setblock 113 48 511 minecraft:blackstone
setblock 113 48 512 minecraft:smooth_basalt
fill 113 48 513 113 51 513 minecraft:blackstone
setblock 114 48 511 minecraft:smooth_basalt
fill 114 48 512 114 51 512 minecraft:blackstone
setblock 114 48 551 minecraft:smooth_basalt
fill 115 48 511 115 51 511 minecraft:blackstone
fill 115 48 551 115 51 551 minecraft:blackstone
setblock 116 48 514 minecraft:smooth_basalt
setblock 117 48 513 minecraft:smooth_basalt
fill 117 48 514 117 51 514 minecraft:blackstone
setblock 118 48 512 minecraft:smooth_basalt
fill 118 48 513 118 51 513 minecraft:blackstone
setblock 119 48 511 minecraft:smooth_basalt
fill 119 48 512 119 51 512 minecraft:blackstone
setblock 119 48 551 minecraft:smooth_basalt
fill 120 48 511 123 48 511 minecraft:blackstone
fill 120 48 551 120 51 551 minecraft:blackstone
setblock 123 48 512 minecraft:smooth_basalt
setblock 124 48 511 minecraft:smooth_basalt
fill 124 48 512 124 51 512 minecraft:blackstone
fill 125 48 511 125 51 511 minecraft:blackstone
setblock 128 48 512 minecraft:smooth_basalt
setblock 129 48 511 minecraft:smooth_basalt
fill 129 48 512 129 51 512 minecraft:blackstone
setblock 129 48 551 minecraft:smooth_basalt
fill 130 48 511 130 51 511 minecraft:blackstone
fill 130 48 551 130 51 551 minecraft:blackstone
fill 131 48 550 131 51 550 minecraft:blackstone
setblock 132 48 513 minecraft:smooth_basalt
setblock 133 48 512 minecraft:smooth_basalt
fill 133 48 513 133 51 513 minecraft:blackstone
setblock 134 48 511 minecraft:smooth_basalt
fill 134 48 512 134 51 512 minecraft:blackstone
setblock 134 48 516 minecraft:smooth_basalt
fill 134 48 532 134 51 532 minecraft:blackstone
setblock 134 48 535 minecraft:blackstone
setblock 134 48 536 minecraft:smooth_basalt
fill 134 48 537 134 51 537 minecraft:blackstone
fill 134 48 539 134 48 540 minecraft:blackstone
setblock 134 48 541 minecraft:smooth_basalt
fill 134 48 547 134 51 547 minecraft:blackstone
setblock 134 48 551 minecraft:smooth_basalt
fill 135 48 511 135 51 511 minecraft:blackstone
setblock 135 48 515 minecraft:smooth_basalt
fill 135 48 516 135 51 516 minecraft:blackstone
setblock 135 48 519 minecraft:blackstone
setblock 135 48 530 minecraft:smooth_basalt
fill 135 48 531 135 51 531 minecraft:blackstone
setblock 135 48 535 minecraft:smooth_basalt
fill 135 48 536 135 51 536 minecraft:blackstone
setblock 135 48 540 minecraft:smooth_basalt
fill 135 48 541 135 51 541 minecraft:blackstone
setblock 135 48 545 minecraft:smooth_basalt
fill 135 48 546 135 51 546 minecraft:blackstone
setblock 135 48 550 minecraft:smooth_basalt
fill 135 48 551 135 51 551 minecraft:blackstone
setblock 95 49 514 minecraft:smooth_basalt
fill 95 49 515 96 51 515 minecraft:blackstone
setblock 95 49 519 minecraft:smooth_basalt
fill 95 49 520 95 52 520 minecraft:blackstone
fill 95 49 526 95 49 528 minecraft:blackstone
setblock 95 49 529 minecraft:smooth_basalt
fill 95 49 530 95 52 530 minecraft:blackstone
setblock 95 49 534 minecraft:smooth_basalt
fill 95 49 535 95 52 535 minecraft:blackstone
setblock 95 49 539 minecraft:smooth_basalt
fill 95 49 540 95 52 540 minecraft:blackstone
setblock 95 49 544 minecraft:smooth_basalt
fill 95 49 545 96 51 545 minecraft:blackstone
setblock 95 49 549 minecraft:smooth_basalt
fill 95 49 550 95 52 550 minecraft:blackstone
setblock 96 49 513 minecraft:smooth_basalt
fill 96 49 514 96 52 514 minecraft:blackstone
fill 96 49 516 96 50 516 minecraft:blackstone
fill 96 49 529 96 52 529 minecraft:blackstone
setblock 96 49 533 minecraft:smooth_basalt
fill 96 49 534 96 52 534 minecraft:blackstone
setblock 96 49 538 minecraft:smooth_basalt
fill 96 49 539 96 52 539 minecraft:blackstone
setblock 96 49 543 minecraft:smooth_basalt
fill 96 49 544 96 52 544 minecraft:blackstone
setblock 97 49 512 minecraft:smooth_basalt
setblock 97 49 532 minecraft:smooth_basalt
fill 97 49 533 97 52 533 minecraft:blackstone
setblock 97 49 537 minecraft:smooth_basalt
fill 97 49 538 97 52 538 minecraft:blackstone
setblock 97 49 541 minecraft:blackstone
setblock 98 49 511 minecraft:smooth_basalt
setblock 98 49 535 minecraft:blackstone
setblock 98 49 536 minecraft:smooth_basalt
setblock 98 49 551 minecraft:smooth_basalt
fill 99 49 511 99 51 511 minecraft:blackstone
setblock 99 49 551 minecraft:blackstone
fill 109 49 511 109 52 511 minecraft:blackstone
fill 110 49 512 110 50 512 minecraft:blackstone
setblock 112 49 511 minecraft:blackstone
setblock 112 49 512 minecraft:smooth_basalt
fill 112 49 513 112 52 513 minecraft:blackstone
setblock 113 49 511 minecraft:smooth_basalt
fill 113 49 512 113 52 512 minecraft:blackstone
setblock 113 49 551 minecraft:smooth_basalt
fill 114 49 511 114 52 511 minecraft:blackstone
setblock 114 49 514 minecraft:blackstone
fill 114 49 551 114 52 551 minecraft:blackstone
setblock 115 49 514 minecraft:smooth_basalt
setblock 116 49 513 minecraft:smooth_basalt
fill 116 49 514 116 52 514 minecraft:blackstone
setblock 117 49 512 minecraft:smooth_basalt
fill 117 49 513 117 52 513 minecraft:blackstone
setblock 118 49 511 minecraft:smooth_basalt
fill 118 49 512 118 52 512 minecraft:blackstone
fill 118 49 514 118 50 514 minecraft:blackstone
setblock 118 49 551 minecraft:smooth_basalt
fill 119 49 511 122 49 511 minecraft:blackstone
fill 119 49 551 119 52 551 minecraft:blackstone
setblock 121 49 513 minecraft:smooth_basalt
setblock 122 49 512 minecraft:smooth_basalt
setblock 123 49 511 minecraft:smooth_basalt
fill 123 49 512 123 52 512 minecraft:blackstone
fill 124 49 511 124 52 511 minecraft:blackstone
setblock 127 49 512 minecraft:smooth_basalt
setblock 127 49 551 minecraft:blackstone
setblock 128 49 511 minecraft:smooth_basalt
fill 128 49 512 128 52 512 minecraft:blackstone
setblock 128 49 551 minecraft:smooth_basalt
fill 129 49 511 129 52 511 minecraft:blackstone
fill 129 49 551 129 52 551 minecraft:blackstone
setblock 131 49 513 minecraft:smooth_basalt
setblock 132 49 512 minecraft:smooth_basalt
fill 132 49 513 132 52 513 minecraft:blackstone
setblock 133 49 511 minecraft:smooth_basalt
fill 133 49 512 133 52 512 minecraft:blackstone
fill 133 49 514 133 50 514 minecraft:blackstone
setblock 133 49 551 minecraft:smooth_basalt
fill 134 49 511 134 52 511 minecraft:blackstone
setblock 134 49 515 minecraft:smooth_basalt
fill 134 49 516 134 51 517 minecraft:blackstone
setblock 134 49 535 minecraft:smooth_basalt
fill 134 49 536 134 52 536 minecraft:blackstone
setblock 134 49 539 minecraft:blackstone
setblock 134 49 540 minecraft:smooth_basalt
fill 134 49 541 134 49 544 minecraft:blackstone
setblock 134 49 545 minecraft:smooth_basalt
fill 134 49 546 134 52 546 minecraft:blackstone
setblock 134 49 550 minecraft:smooth_basalt
fill 134 49 551 134 52 551 minecraft:blackstone
setblock 135 49 514 minecraft:smooth_basalt
fill 135 49 515 135 52 515 minecraft:blackstone
setblock 135 49 519 minecraft:smooth_basalt
fill 135 49 520 135 52 520 minecraft:blackstone
setblock 135 49 529 minecraft:smooth_basalt
fill 135 49 530 135 52 530 minecraft:blackstone
setblock 135 49 534 minecraft:smooth_basalt
fill 135 49 535 135 52 535 minecraft:blackstone
setblock 135 49 539 minecraft:smooth_basalt
fill 135 49 540 135 52 540 minecraft:blackstone
setblock 135 49 544 minecraft:smooth_basalt
fill 135 49 545 135 52 545 minecraft:blackstone
setblock 135 49 549 minecraft:smooth_basalt
fill 135 49 550 135 52 550 minecraft:blackstone
setblock 95 50 513 minecraft:smooth_basalt
fill 95 50 514 95 53 514 minecraft:blackstone
setblock 95 50 518 minecraft:smooth_basalt
fill 95 50 519 95 53 519 minecraft:blackstone
fill 95 50 521 95 50 522 minecraft:blackstone
setblock 95 50 523 minecraft:smooth_basalt
fill 95 50 524 95 50 527 minecraft:blackstone
setblock 95 50 528 minecraft:smooth_basalt
fill 95 50 529 95 53 529 minecraft:blackstone
setblock 95 50 533 minecraft:smooth_basalt
fill 95 50 534 95 53 534 minecraft:blackstone
setblock 95 50 538 minecraft:smooth_basalt
fill 95 50 539 95 53 539 minecraft:blackstone
setblock 95 50 543 minecraft:smooth_basalt
fill 95 50 544 95 53 544 minecraft:blackstone
setblock 95 50 548 minecraft:smooth_basalt
fill 95 50 549 95 53 549 minecraft:blackstone
setblock 96 50 512 minecraft:smooth_basalt
fill 96 50 513 96 53 513 minecraft:blackstone
setblock 96 50 517 minecraft:smooth_basalt
setblock 96 50 532 minecraft:smooth_basalt
fill 96 50 533 96 53 533 minecraft:blackstone
setblock 96 50 537 minecraft:smooth_basalt
fill 96 50 538 96 53 538 minecraft:blackstone
setblock 96 50 542 minecraft:smooth_basalt
fill 96 50 543 96 53 543 minecraft:blackstone
setblock 96 50 546 minecraft:blackstone
setblock 97 50 511 minecraft:smooth_basalt
setblock 97 50 512 minecraft:blackstone
setblock 97 50 531 minecraft:smooth_basalt
fill 97 50 532 97 53 532 minecraft:blackstone
setblock 97 50 536 minecraft:smooth_basalt
fill 97 50 537 98 52 537 minecraft:blackstone
setblock 97 50 541 minecraft:smooth_basalt
setblock 97 50 551 minecraft:smooth_basalt
fill 98 50 511 98 52 511 minecraft:blackstone
setblock 98 50 535 minecraft:smooth_basalt
fill 98 50 536 98 53 536 minecraft:blackstone
fill 98 50 551 98 51 551 minecraft:blackstone
fill 108 50 511 108 53 511 minecraft:blackstone
fill 109 50 512 109 51 512 minecraft:blackstone
setblock 111 50 512 minecraft:smooth_basalt
fill 111 50 513 111 53 513 minecraft:blackstone
setblock 112 50 511 minecraft:smooth_basalt
fill 112 50 512 112 53 512 minecraft:blackstone
setblock 112 50 551 minecraft:smooth_basalt
fill 113 50 511 113 53 511 minecraft:blackstone
setblock 113 50 514 minecraft:blackstone
fill 113 50 551 113 53 551 minecraft:blackstone
setblock 114 50 514 minecraft:smooth_basalt
setblock 115 50 513 minecraft:smooth_basalt
fill 115 50 514 115 53 514 minecraft:blackstone
setblock 116 50 512 minecraft:smooth_basalt
fill 116 50 513 116 53 513 minecraft:blackstone
setblock 117 50 511 minecraft:smooth_basalt
fill 117 50 512 117 53 512 minecraft:blackstone
setblock 117 50 551 minecraft:smooth_basalt
fill 118 50 511 121 50 511 minecraft:blackstone
fill 118 50 551 118 53 551 minecraft:blackstone
setblock 120 50 513 minecraft:smooth_basalt
setblock 121 50 512 minecraft:smooth_basalt
fill 121 50 513 121 52 513 minecraft:blackstone
setblock 122 50 511 minecraft:smooth_basalt
fill 122 50 512 122 53 512 minecraft:blackstone
fill 123 50 511 123 53 511 minecraft:blackstone
setblock 126 50 512 minecraft:smooth_basalt
setblock 127 50 511 minecraft:smooth_basalt
fill 127 50 512 127 53 512 minecraft:blackstone
setblock 127 50 551 minecraft:smooth_basalt
fill 128 50 511 128 53 511 minecraft:blackstone
fill 128 50 551 128 53 551 minecraft:blackstone
setblock 130 50 513 minecraft:smooth_basalt
fill 130 50 550 130 52 550 minecraft:blackstone
setblock 131 50 512 minecraft:smooth_basalt
fill 131 50 513 131 53 513 minecraft:blackstone
setblock 132 50 511 minecraft:smooth_basalt
fill 132 50 512 132 53 512 minecraft:blackstone
setblock 132 50 551 minecraft:smooth_basalt
fill 133 50 511 133 53 511 minecraft:blackstone
setblock 133 50 515 minecraft:smooth_basalt
fill 133 50 516 133 53 516 minecraft:blackstone
setblock 133 50 535 minecraft:smooth_basalt
fill 133 50 536 133 50 539 minecraft:blackstone
setblock 133 50 540 minecraft:smooth_basalt
setblock 133 50 550 minecraft:smooth_basalt
fill 133 50 551 133 53 551 minecraft:blackstone
setblock 134 50 514 minecraft:smooth_basalt
fill 134 50 515 134 53 515 minecraft:blackstone
setblock 134 50 518 minecraft:blackstone
fill 134 50 531 134 52 531 minecraft:blackstone
setblock 134 50 534 minecraft:smooth_basalt
fill 134 50 535 134 53 535 minecraft:blackstone
setblock 134 50 539 minecraft:smooth_basalt
fill 134 50 540 134 50 543 minecraft:blackstone
setblock 134 50 544 minecraft:smooth_basalt
fill 134 50 545 134 53 545 minecraft:blackstone
setblock 134 50 549 minecraft:smooth_basalt
fill 134 50 550 134 53 550 minecraft:blackstone
setblock 135 50 513 minecraft:smooth_basalt
fill 135 50 514 135 53 514 minecraft:blackstone
setblock 135 50 518 minecraft:smooth_basalt
fill 135 50 519 135 53 519 minecraft:blackstone
fill 135 50 521 135 51 521 minecraft:blackstone
fill 135 50 529 135 53 529 minecraft:blackstone
setblock 135 50 533 minecraft:smooth_basalt
fill 135 50 534 135 53 534 minecraft:blackstone
setblock 135 50 538 minecraft:smooth_basalt
fill 135 50 539 135 53 539 minecraft:blackstone
setblock 135 50 543 minecraft:smooth_basalt
fill 135 50 544 135 53 544 minecraft:blackstone
setblock 135 50 548 minecraft:smooth_basalt
fill 135 50 549 135 53 549 minecraft:blackstone
setblock 95 51 512 minecraft:smooth_basalt
fill 95 51 513 95 54 513 minecraft:blackstone
setblock 95 51 517 minecraft:smooth_basalt
fill 95 51 518 96 53 518 minecraft:blackstone
setblock 95 51 521 minecraft:blackstone
setblock 95 51 522 minecraft:smooth_basalt
fill 95 51 523 95 51 526 minecraft:blackstone
setblock 95 51 527 minecraft:smooth_basalt
fill 95 51 528 96 53 528 minecraft:blackstone
setblock 95 51 532 minecraft:smooth_basalt
fill 95 51 533 95 54 533 minecraft:blackstone
setblock 95 51 537 minecraft:smooth_basalt
fill 95 51 538 95 54 538 minecraft:blackstone
setblock 95 51 542 minecraft:smooth_basalt
fill 95 51 543 95 54 543 minecraft:blackstone
setblock 95 51 547 minecraft:smooth_basalt
fill 95 51 548 95 54 548 minecraft:blackstone
setblock 96 51 511 minecraft:smooth_basalt
fill 96 51 512 96 52 512 minecraft:blackstone
setblock 96 51 516 minecraft:smooth_basalt
fill 96 51 517 96 54 517 minecraft:blackstone
fill 96 51 519 96 52 519 minecraft:blackstone
setblock 96 51 531 minecraft:smooth_basalt
fill 96 51 532 96 54 532 minecraft:blackstone
setblock 96 51 536 minecraft:smooth_basalt
fill 96 51 537 96 54 537 minecraft:blackstone
setblock 96 51 540 minecraft:blackstone
setblock 96 51 541 minecraft:smooth_basalt
fill 96 51 542 97 53 542 minecraft:blackstone
setblock 96 51 546 minecraft:smooth_basalt
setblock 96 51 551 minecraft:smooth_basalt
fill 97 51 511 97 53 511 minecraft:blackstone
setblock 97 51 531 minecraft:blackstone
setblock 97 51 535 minecraft:smooth_basalt
fill 97 51 536 97 54 536 minecraft:blackstone
setblock 97 51 540 minecraft:smooth_basalt
fill 97 51 541 97 54 541 minecraft:blackstone
fill 97 51 551 97 52 551 minecraft:blackstone
fill 98 51 535 98 52 535 minecraft:blackstone
setblock 98 51 538 minecraft:blackstone
fill 107 51 511 107 54 511 minecraft:blackstone
setblock 110 51 512 minecraft:smooth_basalt
fill 110 51 513 110 54 513 minecraft:blackstone
setblock 111 51 511 minecraft:smooth_basalt
fill 111 51 512 111 54 512 minecraft:blackstone
fill 112 51 511 112 54 511 minecraft:blackstone
setblock 112 51 514 minecraft:blackstone
fill 112 51 551 112 54 551 minecraft:blackstone
setblock 113 51 514 minecraft:smooth_basalt
setblock 114 51 513 minecraft:smooth_basalt
fill 114 51 514 114 54 514 minecraft:blackstone
setblock 115 51 512 minecraft:smooth_basalt
fill 115 51 513 115 54 513 minecraft:blackstone
setblock 116 51 511 minecraft:smooth_basalt
fill 116 51 512 116 54 512 minecraft:blackstone
setblock 116 51 551 minecraft:smooth_basalt
fill 117 51 511 120 51 511 minecraft:blackstone
fill 117 51 551 117 54 551 minecraft:blackstone
setblock 118 51 514 minecraft:smooth_basalt
setblock 119 51 513 minecraft:smooth_basalt
setblock 120 51 512 minecraft:smooth_basalt
fill 120 51 513 120 53 513 minecraft:blackstone
setblock 121 51 511 minecraft:smooth_basalt
fill 121 51 512 121 54 512 minecraft:blackstone
fill 122 51 511 122 54 511 minecraft:blackstone
setblock 125 51 512 minecraft:smooth_basalt
setblock 126 51 511 minecraft:smooth_basalt
fill 126 51 512 126 54 512 minecraft:blackstone
setblock 126 51 551 minecraft:smooth_basalt
fill 127 51 511 127 54 511 minecraft:blackstone
fill 127 51 551 127 54 551 minecraft:blackstone
setblock 129 51 513 minecraft:smooth_basalt
setblock 130 51 512 minecraft:smooth_basalt
fill 130 51 513 130 54 513 minecraft:blackstone
setblock 131 51 511 minecraft:smooth_basalt
fill 131 51 512 131 54 512 minecraft:blackstone
setblock 131 51 551 minecraft:smooth_basalt
fill 132 51 511 132 54 511 minecraft:blackstone
setblock 132 51 550 minecraft:smooth_basalt
fill 132 51 551 132 54 551 minecraft:blackstone
setblock 133 51 514 minecraft:smooth_basalt
fill 133 51 515 133 54 515 minecraft:blackstone
fill 133 51 517 133 52 517 minecraft:blackstone
setblock 133 51 534 minecraft:smooth_basalt
fill 133 51 535 133 51 538 minecraft:blackstone
setblock 133 51 539 minecraft:smooth_basalt
fill 133 51 540 133 51 543 minecraft:blackstone
fill 133 51 550 133 54 550 minecraft:blackstone
setblock 134 51 513 minecraft:smooth_basalt
fill 134 51 514 134 54 514 minecraft:blackstone
setblock 134 51 518 minecraft:smooth_basalt
fill 134 51 519 134 54 519 minecraft:blackstone
setblock 134 51 533 minecraft:smooth_basalt
fill 134 51 534 134 54 534 minecraft:blackstone
setblock 134 51 538 minecraft:smooth_basalt
fill 134 51 539 134 51 542 minecraft:blackstone
setblock 134 51 543 minecraft:smooth_basalt
fill 134 51 544 134 54 544 minecraft:blackstone
setblock 134 51 548 minecraft:smooth_basalt
fill 134 51 549 134 54 549 minecraft:blackstone
setblock 135 51 512 minecraft:smooth_basalt
fill 135 51 513 135 54 513 minecraft:blackstone
setblock 135 51 517 minecraft:smooth_basalt
fill 135 51 518 135 54 518 minecraft:blackstone
setblock 135 51 522 minecraft:smooth_basalt
fill 135 51 528 135 54 528 minecraft:blackstone
setblock 135 51 532 minecraft:smooth_basalt
fill 135 51 533 135 54 533 minecraft:blackstone
setblock 135 51 537 minecraft:smooth_basalt
fill 135 51 538 135 54 538 minecraft:blackstone
setblock 135 51 542 minecraft:smooth_basalt
fill 135 51 543 135 54 543 minecraft:blackstone
setblock 135 51 547 minecraft:smooth_basalt
fill 135 51 548 135 54 548 minecraft:blackstone
setblock 95 52 511 minecraft:smooth_basalt
fill 95 52 512 95 55 512 minecraft:blackstone
setblock 95 52 515 minecraft:blackstone
setblock 95 52 516 minecraft:smooth_basalt
fill 95 52 517 95 55 517 minecraft:blackstone
setblock 95 52 521 minecraft:smooth_basalt
fill 95 52 522 95 52 525 minecraft:blackstone
setblock 95 52 526 minecraft:smooth_basalt
fill 95 52 527 95 55 527 minecraft:blackstone
setblock 95 52 531 minecraft:smooth_basalt
fill 95 52 532 95 55 532 minecraft:blackstone
setblock 95 52 536 minecraft:smooth_basalt
fill 95 52 537 95 55 537 minecraft:blackstone
setblock 95 52 541 minecraft:smooth_basalt
fill 95 52 542 95 55 542 minecraft:blackstone
setblock 95 52 545 minecraft:blackstone
setblock 95 52 546 minecraft:smooth_basalt
fill 95 52 547 95 55 547 minecraft:blackstone
schedule function dropper:buildpart/122_3 1t
