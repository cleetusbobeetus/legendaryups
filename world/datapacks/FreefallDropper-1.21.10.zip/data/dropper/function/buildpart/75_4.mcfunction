setblock 167 49 325 minecraft:blue_terracotta
setblock 168 49 325 minecraft:dark_prismarine
fill 168 49 363 169 49 363 minecraft:blue_terracotta
setblock 169 49 324 minecraft:dark_prismarine
fill 169 49 325 171 49 326 minecraft:blue_terracotta
setblock 170 49 323 minecraft:dark_prismarine
fill 170 49 324 170 52 324 minecraft:blue_terracotta
setblock 170 49 363 minecraft:dark_prismarine
fill 171 49 323 171 52 323 minecraft:blue_terracotta
fill 171 49 363 171 52 363 minecraft:blue_terracotta
setblock 172 49 325 minecraft:blue_terracotta
setblock 172 49 326 minecraft:dark_prismarine
setblock 173 49 325 minecraft:dark_prismarine
fill 173 49 326 173 52 326 minecraft:blue_terracotta
setblock 174 49 324 minecraft:dark_prismarine
fill 174 49 325 174 52 325 minecraft:blue_terracotta
setblock 175 49 323 minecraft:dark_prismarine
fill 175 49 324 175 52 324 minecraft:blue_terracotta
setblock 175 49 363 minecraft:dark_prismarine
fill 176 49 323 176 52 323 minecraft:blue_terracotta
fill 176 49 363 176 52 363 minecraft:blue_terracotta
setblock 178 49 325 minecraft:dark_prismarine
setblock 179 49 324 minecraft:dark_prismarine
setblock 180 49 323 minecraft:dark_prismarine
fill 180 49 324 180 52 324 minecraft:blue_terracotta
setblock 180 49 363 minecraft:dark_prismarine
fill 181 49 323 181 52 323 minecraft:blue_terracotta
setblock 181 49 327 minecraft:dark_prismarine
fill 181 49 363 181 52 363 minecraft:blue_terracotta
setblock 182 49 326 minecraft:dark_prismarine
fill 182 49 327 182 52 327 minecraft:blue_terracotta
fill 182 49 329 182 50 329 minecraft:blue_terracotta
setblock 182 49 336 minecraft:purple_concrete
setblock 182 49 361 minecraft:purple_concrete
fill 142 50 323 143 50 323 minecraft:blue_terracotta
setblock 142 50 325 minecraft:dark_prismarine
fill 142 50 326 142 52 327 minecraft:blue_terracotta
setblock 142 50 331 minecraft:purple_concrete
setblock 142 50 344 minecraft:blue_terracotta
setblock 142 50 345 minecraft:dark_prismarine
fill 142 50 346 142 50 349 minecraft:blue_terracotta
setblock 142 50 350 minecraft:dark_prismarine
fill 142 50 351 143 52 351 minecraft:blue_terracotta
setblock 142 50 355 minecraft:dark_prismarine
fill 142 50 356 142 53 356 minecraft:blue_terracotta
fill 143 50 346 143 50 348 minecraft:blue_terracotta
setblock 143 50 349 minecraft:dark_prismarine
fill 143 50 350 144 52 350 minecraft:blue_terracotta
fill 143 50 352 143 50 353 minecraft:blue_terracotta
setblock 143 50 363 minecraft:blue_terracotta
setblock 144 50 323 minecraft:dark_prismarine
setblock 144 50 348 minecraft:dark_prismarine
fill 144 50 349 144 53 349 minecraft:blue_terracotta
setblock 144 50 363 minecraft:dark_prismarine
fill 145 50 323 145 53 323 minecraft:blue_terracotta
fill 145 50 363 148 50 363 minecraft:blue_terracotta
fill 146 50 324 147 50 324 minecraft:blue_terracotta
fill 147 50 362 149 50 362 minecraft:blue_terracotta
setblock 148 50 324 minecraft:dark_prismarine
setblock 149 50 323 minecraft:dark_prismarine
fill 149 50 324 149 53 324 minecraft:blue_terracotta
setblock 149 50 363 minecraft:dark_prismarine
fill 150 50 323 150 53 323 minecraft:blue_terracotta
setblock 150 50 362 minecraft:dark_prismarine
fill 150 50 363 153 50 363 minecraft:blue_terracotta
setblock 151 50 362 minecraft:blue_terracotta
setblock 152 50 322 minecraft:light_blue_wool
setblock 153 50 324 minecraft:dark_prismarine
setblock 154 50 323 minecraft:dark_prismarine
fill 154 50 324 154 51 324 minecraft:blue_terracotta
setblock 154 50 363 minecraft:dark_prismarine
fill 155 50 323 155 52 323 minecraft:blue_terracotta
fill 161 50 357 161 84 357 minecraft:magenta_terracotta
fill 162 50 323 163 50 323 minecraft:blue_terracotta
fill 162 50 355 162 86 355 minecraft:magenta_terracotta
setblock 164 50 323 minecraft:dark_prismarine
fill 164 50 324 167 50 324 minecraft:blue_terracotta
fill 165 50 323 168 50 323 minecraft:blue_terracotta
setblock 166 50 325 minecraft:blue_terracotta
fill 167 50 322 167 85 322 minecraft:black_concrete
setblock 167 50 325 minecraft:dark_prismarine
fill 167 50 326 170 50 326 minecraft:blue_terracotta
fill 167 50 363 168 50 363 minecraft:blue_terracotta
setblock 168 50 324 minecraft:dark_prismarine
fill 168 50 325 171 50 325 minecraft:blue_terracotta
setblock 169 50 323 minecraft:dark_prismarine
fill 169 50 324 169 53 324 minecraft:blue_terracotta
setblock 169 50 363 minecraft:dark_prismarine
fill 170 50 323 170 53 323 minecraft:blue_terracotta
setblock 170 50 327 minecraft:dark_prismarine
fill 170 50 363 170 53 363 minecraft:blue_terracotta
setblock 171 50 326 minecraft:dark_prismarine
fill 171 50 327 172 52 327 minecraft:blue_terracotta
setblock 172 50 325 minecraft:dark_prismarine
fill 172 50 326 172 53 326 minecraft:blue_terracotta
setblock 173 50 324 minecraft:dark_prismarine
fill 173 50 325 173 53 325 minecraft:blue_terracotta
setblock 174 50 323 minecraft:dark_prismarine
fill 174 50 324 174 53 324 minecraft:blue_terracotta
setblock 174 50 363 minecraft:dark_prismarine
fill 175 50 323 175 53 323 minecraft:blue_terracotta
fill 175 50 363 175 53 363 minecraft:blue_terracotta
setblock 177 50 325 minecraft:dark_prismarine
setblock 178 50 324 minecraft:dark_prismarine
fill 178 50 325 178 51 325 minecraft:blue_terracotta
setblock 179 50 323 minecraft:dark_prismarine
fill 179 50 324 179 53 324 minecraft:blue_terracotta
setblock 179 50 363 minecraft:dark_prismarine
fill 180 50 323 180 53 323 minecraft:blue_terracotta
fill 180 50 363 180 53 363 minecraft:blue_terracotta
setblock 181 50 326 minecraft:dark_prismarine
fill 181 50 327 181 52 328 minecraft:blue_terracotta
setblock 182 50 325 minecraft:dark_prismarine
fill 182 50 326 182 53 326 minecraft:blue_terracotta
setblock 182 50 330 minecraft:dark_prismarine
fill 182 50 348 182 50 349 minecraft:blue_terracotta
setblock 182 50 350 minecraft:dark_prismarine
fill 182 50 351 182 53 351 minecraft:blue_terracotta
setblock 182 50 355 minecraft:purple_concrete
fill 182 50 362 182 52 362 minecraft:blue_terracotta
setblock 142 51 323 minecraft:blue_terracotta
setblock 142 51 324 minecraft:dark_prismarine
fill 142 51 325 142 54 325 minecraft:blue_terracotta
setblock 142 51 328 minecraft:blue_terracotta
setblock 142 51 329 minecraft:dark_prismarine
setblock 142 51 337 minecraft:purple_concrete
setblock 142 51 344 minecraft:dark_prismarine
fill 142 51 345 142 51 348 minecraft:blue_terracotta
setblock 142 51 349 minecraft:dark_prismarine
fill 142 51 350 142 54 350 minecraft:blue_terracotta
fill 142 51 352 142 51 353 minecraft:blue_terracotta
setblock 142 51 354 minecraft:dark_prismarine
fill 142 51 355 143 53 355 minecraft:blue_terracotta
fill 142 51 357 142 51 358 minecraft:blue_terracotta
setblock 142 51 359 minecraft:dark_prismarine
fill 142 51 360 142 53 361 minecraft:blue_terracotta
setblock 143 51 323 minecraft:dark_prismarine
fill 143 51 345 143 51 347 minecraft:blue_terracotta
setblock 143 51 348 minecraft:dark_prismarine
fill 143 51 349 143 54 349 minecraft:blue_terracotta
setblock 143 51 352 minecraft:blue_terracotta
setblock 143 51 353 minecraft:dark_prismarine
fill 143 51 354 143 54 354 minecraft:blue_terracotta
setblock 143 51 363 minecraft:dark_prismarine
fill 144 51 323 144 54 323 minecraft:blue_terracotta
setblock 144 51 347 minecraft:dark_prismarine
fill 144 51 348 144 54 348 minecraft:blue_terracotta
setblock 144 51 351 minecraft:blue_terracotta
setblock 144 51 352 minecraft:dark_prismarine
fill 144 51 353 144 54 353 minecraft:blue_terracotta
fill 144 51 363 147 51 363 minecraft:blue_terracotta
fill 145 51 349 145 51 350 minecraft:blue_terracotta
setblock 146 51 324 minecraft:blue_terracotta
setblock 147 51 324 minecraft:dark_prismarine
fill 147 51 362 148 51 362 minecraft:blue_terracotta
setblock 148 51 323 minecraft:dark_prismarine
fill 148 51 324 148 54 324 minecraft:blue_terracotta
setblock 148 51 363 minecraft:dark_prismarine
fill 149 51 323 149 54 323 minecraft:blue_terracotta
setblock 149 51 362 minecraft:dark_prismarine
fill 149 51 363 152 51 363 minecraft:blue_terracotta
setblock 150 51 349 minecraft:magenta_terracotta
fill 150 51 362 150 52 362 minecraft:blue_terracotta
fill 152 51 322 152 77 322 minecraft:black_concrete
setblock 152 51 324 minecraft:dark_prismarine
setblock 153 51 323 minecraft:dark_prismarine
fill 153 51 324 153 52 324 minecraft:blue_terracotta
setblock 153 51 363 minecraft:dark_prismarine
fill 154 51 323 154 53 323 minecraft:blue_terracotta
setblock 154 51 363 minecraft:blue_terracotta
setblock 160 51 363 minecraft:purple_concrete
fill 161 51 323 162 51 323 minecraft:blue_terracotta
setblock 163 51 323 minecraft:dark_prismarine
fill 163 51 324 166 51 324 minecraft:blue_terracotta
fill 164 51 323 167 51 323 minecraft:blue_terracotta
setblock 165 51 325 minecraft:blue_terracotta
setblock 166 51 325 minecraft:dark_prismarine
fill 166 51 326 169 51 326 minecraft:blue_terracotta
setblock 167 51 324 minecraft:dark_prismarine
fill 167 51 325 170 51 325 minecraft:blue_terracotta
setblock 167 51 363 minecraft:blue_terracotta
setblock 168 51 323 minecraft:dark_prismarine
fill 168 51 324 168 54 324 minecraft:blue_terracotta
setblock 168 51 363 minecraft:dark_prismarine
fill 169 51 323 169 54 323 minecraft:blue_terracotta
setblock 169 51 327 minecraft:dark_prismarine
fill 169 51 363 169 54 363 minecraft:blue_terracotta
setblock 170 51 326 minecraft:dark_prismarine
fill 170 51 327 170 54 327 minecraft:blue_terracotta
setblock 171 51 325 minecraft:dark_prismarine
fill 171 51 326 171 54 326 minecraft:blue_terracotta
setblock 172 51 324 minecraft:dark_prismarine
fill 172 51 325 172 54 325 minecraft:blue_terracotta
setblock 173 51 323 minecraft:dark_prismarine
fill 173 51 324 173 54 324 minecraft:blue_terracotta
setblock 173 51 363 minecraft:dark_prismarine
fill 174 51 323 174 54 323 minecraft:blue_terracotta
setblock 174 51 326 minecraft:blue_terracotta
fill 174 51 363 174 54 363 minecraft:blue_terracotta
setblock 175 51 326 minecraft:dark_prismarine
setblock 176 51 325 minecraft:dark_prismarine
setblock 177 51 324 minecraft:dark_prismarine
fill 177 51 325 177 52 325 minecraft:blue_terracotta
setblock 178 51 323 minecraft:dark_prismarine
fill 178 51 324 178 53 324 minecraft:blue_terracotta
fill 178 51 337 178 102 337 minecraft:magenta_terracotta
setblock 178 51 363 minecraft:dark_prismarine
fill 179 51 323 179 54 323 minecraft:blue_terracotta
fill 179 51 363 179 53 363 minecraft:blue_terracotta
setblock 181 51 325 minecraft:dark_prismarine
fill 181 51 326 181 54 326 minecraft:blue_terracotta
setblock 182 51 324 minecraft:dark_prismarine
fill 182 51 325 182 54 325 minecraft:blue_terracotta
setblock 182 51 329 minecraft:dark_prismarine
fill 182 51 330 182 53 331 minecraft:blue_terracotta
fill 182 51 347 182 51 348 minecraft:blue_terracotta
setblock 182 51 349 minecraft:dark_prismarine
fill 182 51 350 182 54 350 minecraft:blue_terracotta
fill 182 51 352 182 51 353 minecraft:blue_terracotta
setblock 182 51 354 minecraft:dark_prismarine
fill 182 51 355 182 54 355 minecraft:blue_terracotta
fill 183 51 323 183 82 323 minecraft:black_concrete
setblock 183 51 324 minecraft:light_blue_wool
fill 183 51 325 183 61 326 minecraft:black_concrete
fill 141 52 357 141 129 357 minecraft:black_concrete
setblock 141 52 358 minecraft:cyan_concrete
fill 141 52 359 141 131 361 minecraft:black_concrete
setblock 142 52 323 minecraft:dark_prismarine
fill 142 52 324 142 54 324 minecraft:blue_terracotta
setblock 142 52 328 minecraft:dark_prismarine
fill 142 52 329 142 54 330 minecraft:blue_terracotta
setblock 142 52 343 minecraft:purple_concrete
fill 142 52 344 142 52 347 minecraft:blue_terracotta
setblock 142 52 348 minecraft:dark_prismarine
fill 142 52 349 142 55 349 minecraft:blue_terracotta
setblock 142 52 352 minecraft:blue_terracotta
setblock 142 52 353 minecraft:dark_prismarine
fill 142 52 354 142 55 354 minecraft:blue_terracotta
setblock 142 52 357 minecraft:blue_terracotta
setblock 142 52 358 minecraft:dark_prismarine
fill 142 52 359 142 55 359 minecraft:blue_terracotta
setblock 142 52 362 minecraft:blue_terracotta
setblock 142 52 363 minecraft:dark_prismarine
fill 143 52 323 143 54 323 minecraft:blue_terracotta
fill 143 52 345 143 52 346 minecraft:blue_terracotta
setblock 143 52 347 minecraft:dark_prismarine
fill 143 52 348 143 55 348 minecraft:blue_terracotta
setblock 143 52 352 minecraft:dark_prismarine
fill 143 52 353 143 55 353 minecraft:blue_terracotta
setblock 143 52 356 minecraft:blue_terracotta
setblock 143 52 357 minecraft:dark_prismarine
fill 143 52 363 146 52 363 minecraft:blue_terracotta
setblock 144 52 346 minecraft:dark_prismarine
fill 144 52 347 144 55 347 minecraft:blue_terracotta
setblock 144 52 351 minecraft:dark_prismarine
fill 144 52 352 145 54 352 minecraft:blue_terracotta
fill 144 52 354 144 52 355 minecraft:blue_terracotta
fill 145 52 348 145 52 349 minecraft:blue_terracotta
setblock 145 52 350 minecraft:dark_prismarine
fill 145 52 351 145 55 351 minecraft:blue_terracotta
setblock 146 52 324 minecraft:dark_prismarine
fill 146 52 362 147 52 362 minecraft:blue_terracotta
setblock 147 52 323 minecraft:dark_prismarine
fill 147 52 324 147 54 324 minecraft:blue_terracotta
setblock 147 52 363 minecraft:dark_prismarine
fill 148 52 323 148 55 323 minecraft:blue_terracotta
setblock 148 52 362 minecraft:dark_prismarine
fill 148 52 363 151 52 363 minecraft:blue_terracotta
setblock 149 52 362 minecraft:blue_terracotta
setblock 151 52 324 minecraft:dark_prismarine
setblock 152 52 323 minecraft:dark_prismarine
fill 152 52 324 152 53 324 minecraft:blue_terracotta
setblock 152 52 363 minecraft:dark_prismarine
fill 153 52 323 153 53 323 minecraft:blue_terracotta
setblock 153 52 363 minecraft:blue_terracotta
setblock 158 52 323 minecraft:purple_concrete
setblock 161 52 323 minecraft:blue_terracotta
fill 161 52 356 161 83 356 minecraft:magenta_terracotta
setblock 162 52 323 minecraft:dark_prismarine
fill 163 52 323 165 52 324 minecraft:blue_terracotta
setblock 164 52 325 minecraft:blue_terracotta
setblock 165 52 325 minecraft:dark_prismarine
setblock 166 52 323 minecraft:blue_terracotta
setblock 166 52 324 minecraft:dark_prismarine
fill 166 52 325 168 52 326 minecraft:blue_terracotta
setblock 166 52 363 minecraft:blue_terracotta
setblock 167 52 323 minecraft:dark_prismarine
fill 167 52 324 167 55 324 minecraft:blue_terracotta
setblock 167 52 363 minecraft:dark_prismarine
fill 168 52 323 168 55 323 minecraft:blue_terracotta
setblock 168 52 327 minecraft:dark_prismarine
fill 168 52 363 168 55 363 minecraft:blue_terracotta
setblock 169 52 325 minecraft:blue_terracotta
setblock 169 52 326 minecraft:dark_prismarine
fill 169 52 327 169 54 327 minecraft:blue_terracotta
setblock 170 52 325 minecraft:dark_prismarine
fill 170 52 326 170 55 326 minecraft:blue_terracotta
setblock 171 52 324 minecraft:dark_prismarine
fill 171 52 325 171 55 325 minecraft:blue_terracotta
setblock 172 52 323 minecraft:dark_prismarine
fill 172 52 324 172 55 324 minecraft:blue_terracotta
setblock 172 52 363 minecraft:dark_prismarine
fill 173 52 323 173 55 323 minecraft:blue_terracotta
fill 173 52 363 173 55 363 minecraft:blue_terracotta
fill 173 52 364 173 131 364 minecraft:black_concrete
setblock 174 52 326 minecraft:dark_prismarine
setblock 174 52 364 minecraft:light_blue_wool
setblock 175 52 325 minecraft:dark_prismarine
setblock 175 52 326 minecraft:blue_terracotta
fill 175 52 364 175 131 364 minecraft:black_concrete
setblock 176 52 324 minecraft:dark_prismarine
fill 176 52 325 176 53 325 minecraft:blue_terracotta
setblock 177 52 323 minecraft:dark_prismarine
fill 177 52 324 177 54 324 minecraft:blue_terracotta
setblock 177 52 363 minecraft:dark_prismarine
fill 178 52 323 178 55 323 minecraft:blue_terracotta
fill 178 52 363 178 53 363 minecraft:blue_terracotta
setblock 181 52 324 minecraft:dark_prismarine
fill 181 52 325 181 54 325 minecraft:blue_terracotta
setblock 181 52 329 minecraft:dark_prismarine
setblock 182 52 323 minecraft:dark_prismarine
fill 182 52 324 182 55 324 minecraft:blue_terracotta
setblock 182 52 328 minecraft:dark_prismarine
fill 182 52 329 182 55 329 minecraft:blue_terracotta
setblock 182 52 332 minecraft:blue_terracotta
setblock 182 52 343 minecraft:purple_concrete
fill 182 52 346 182 52 347 minecraft:blue_terracotta
setblock 182 52 348 minecraft:dark_prismarine
fill 182 52 349 182 55 349 minecraft:blue_terracotta
setblock 182 52 352 minecraft:blue_terracotta
setblock 182 52 353 minecraft:dark_prismarine
fill 182 52 354 182 55 354 minecraft:blue_terracotta
fill 182 52 356 182 52 357 minecraft:blue_terracotta
setblock 182 52 358 minecraft:dark_prismarine
fill 182 52 359 182 53 361 minecraft:blue_terracotta
setblock 182 52 363 minecraft:dark_prismarine
fill 183 52 324 183 118 324 minecraft:black_concrete
fill 141 53 358 141 122 358 minecraft:black_concrete
setblock 142 53 323 minecraft:blue_terracotta
setblock 142 53 326 minecraft:blue_terracotta
setblock 142 53 327 minecraft:dark_prismarine
fill 142 53 328 142 56 328 minecraft:blue_terracotta
setblock 142 53 331 minecraft:blue_terracotta
setblock 142 53 332 minecraft:dark_prismarine
fill 142 53 344 142 53 346 minecraft:blue_terracotta
setblock 142 53 347 minecraft:dark_prismarine
fill 142 53 348 142 56 348 minecraft:blue_terracotta
setblock 142 53 351 minecraft:blue_terracotta
setblock 142 53 352 minecraft:dark_prismarine
fill 142 53 353 142 56 353 minecraft:blue_terracotta
setblock 142 53 357 minecraft:dark_prismarine
fill 142 53 358 143 55 358 minecraft:blue_terracotta
setblock 142 53 362 minecraft:dark_prismarine
fill 142 53 363 145 53 363 minecraft:blue_terracotta
setblock 143 53 345 minecraft:blue_terracotta
setblock 143 53 346 minecraft:dark_prismarine
fill 143 53 347 143 56 347 minecraft:blue_terracotta
setblock 143 53 350 minecraft:blue_terracotta
setblock 143 53 351 minecraft:dark_prismarine
fill 143 53 352 143 56 352 minecraft:blue_terracotta
setblock 143 53 356 minecraft:dark_prismarine
fill 143 53 357 143 56 357 minecraft:blue_terracotta
setblock 144 53 325 minecraft:light[level=13]
setblock 144 53 332 minecraft:light[level=12]
setblock 144 53 333 minecraft:light[level=13]
setblock 144 53 339 minecraft:light[level=12]
setblock 144 53 341 minecraft:light[level=13]
fill 144 53 346 144 55 346 minecraft:blue_terracotta
setblock 144 53 350 minecraft:dark_prismarine
fill 144 53 351 144 56 351 minecraft:blue_terracotta
setblock 144 53 354 minecraft:blue_terracotta
setblock 144 53 355 minecraft:dark_prismarine
fill 144 53 356 144 56 356 minecraft:blue_terracotta
setblock 144 53 357 minecraft:light[level=13]
setblock 144 53 360 minecraft:light[level=12]
fill 145 53 347 145 53 348 minecraft:blue_terracotta
setblock 145 53 349 minecraft:dark_prismarine
fill 145 53 350 145 56 350 minecraft:blue_terracotta
setblock 145 53 353 minecraft:blue_terracotta
setblock 145 53 354 minecraft:dark_prismarine
setblock 146 53 323 minecraft:dark_prismarine
setblock 146 53 324 minecraft:blue_terracotta
setblock 146 53 363 minecraft:dark_prismarine
fill 147 53 323 147 56 323 minecraft:blue_terracotta
setblock 147 53 362 minecraft:dark_prismarine
fill 147 53 363 150 53 363 minecraft:blue_terracotta
setblock 148 53 362 minecraft:blue_terracotta
setblock 150 53 324 minecraft:dark_prismarine
setblock 151 53 323 minecraft:dark_prismarine
setblock 151 53 324 minecraft:blue_terracotta
setblock 151 53 325 minecraft:light[level=12]
setblock 151 53 332 minecraft:light[level=12]
setblock 151 53 339 minecraft:light[level=12]
setblock 151 53 346 minecraft:light[level=12]
setblock 151 53 353 minecraft:light[level=12]
setblock 151 53 360 minecraft:light[level=12]
setblock 151 53 363 minecraft:dark_prismarine
fill 152 53 323 152 54 323 minecraft:blue_terracotta
setblock 152 53 325 minecraft:light[level=13]
setblock 152 53 333 minecraft:light[level=13]
fill 152 53 335 153 54 335 minecraft:dark_prismarine
setblock 152 53 341 minecraft:light[level=13]
setblock 152 53 349 minecraft:light[level=13]
setblock 152 53 357 minecraft:light[level=13]
setblock 152 53 363 minecraft:blue_terracotta
setblock 153 53 363 minecraft:purple_concrete
setblock 158 53 325 minecraft:light[level=12]
setblock 158 53 332 minecraft:light[level=12]
setblock 158 53 339 minecraft:light[level=12]
setblock 158 53 346 minecraft:light[level=12]
setblock 158 53 353 minecraft:light[level=12]
setblock 158 53 360 minecraft:light[level=12]
setblock 160 53 325 minecraft:light[level=13]
fill 160 53 328 161 63 328 minecraft:magenta_terracotta
setblock 160 53 333 minecraft:light[level=13]
setblock 160 53 341 minecraft:light[level=13]
setblock 160 53 349 minecraft:light[level=13]
setblock 160 53 357 minecraft:light[level=13]
setblock 161 53 323 minecraft:dark_prismarine
fill 162 53 323 165 53 323 minecraft:blue_terracotta
fill 163 53 324 164 53 324 minecraft:blue_terracotta
fill 163 53 356 164 58 356 minecraft:magenta_terracotta
setblock 164 53 325 minecraft:dark_prismarine
setblock 165 53 324 minecraft:dark_prismarine
fill 165 53 325 167 53 326 minecraft:blue_terracotta
setblock 165 53 332 minecraft:light[level=12]
setblock 165 53 339 minecraft:light[level=12]
setblock 165 53 346 minecraft:light[level=12]
setblock 165 53 353 minecraft:light[level=12]
setblock 165 53 360 minecraft:light[level=12]
setblock 166 53 323 minecraft:dark_prismarine
fill 166 53 324 166 56 324 minecraft:blue_terracotta
setblock 166 53 363 minecraft:dark_prismarine
fill 167 53 323 167 56 323 minecraft:blue_terracotta
setblock 167 53 327 minecraft:dark_prismarine
fill 167 53 363 167 56 363 minecraft:blue_terracotta
setblock 168 53 325 minecraft:blue_terracotta
setblock 168 53 326 minecraft:dark_prismarine
fill 168 53 327 168 54 327 minecraft:blue_terracotta
setblock 168 53 333 minecraft:light[level=13]
setblock 168 53 341 minecraft:light[level=13]
setblock 168 53 349 minecraft:light[level=13]
setblock 168 53 357 minecraft:light[level=13]
setblock 169 53 325 minecraft:dark_prismarine
fill 169 53 326 169 56 326 minecraft:blue_terracotta
setblock 170 53 324 minecraft:dark_prismarine
fill 170 53 325 170 56 325 minecraft:blue_terracotta
setblock 171 53 323 minecraft:dark_prismarine
fill 171 53 324 171 56 324 minecraft:blue_terracotta
setblock 171 53 327 minecraft:blue_terracotta
setblock 171 53 363 minecraft:dark_prismarine
fill 172 53 323 172 56 323 minecraft:blue_terracotta
setblock 172 53 332 minecraft:light[level=12]
setblock 172 53 339 minecraft:light[level=12]
setblock 172 53 346 minecraft:light[level=12]
setblock 172 53 353 minecraft:light[level=12]
setblock 172 53 360 minecraft:light[level=12]
fill 172 53 363 172 56 363 minecraft:blue_terracotta
setblock 173 53 326 minecraft:dark_prismarine
setblock 174 53 325 minecraft:dark_prismarine
setblock 174 53 326 minecraft:blue_terracotta
fill 174 53 364 174 129 364 minecraft:black_concrete
setblock 175 53 324 minecraft:dark_prismarine
fill 175 53 325 175 54 325 minecraft:blue_terracotta
setblock 176 53 323 minecraft:dark_prismarine
fill 176 53 324 176 54 324 minecraft:blue_terracotta
setblock 176 53 333 minecraft:light[level=13]
setblock 176 53 341 minecraft:light[level=13]
fill 176 53 349 178 58 351 minecraft:magenta_terracotta
setblock 176 53 357 minecraft:light[level=13]
setblock 176 53 363 minecraft:dark_prismarine
fill 177 53 323 177 55 323 minecraft:blue_terracotta
setblock 177 53 363 minecraft:blue_terracotta
setblock 179 53 325 minecraft:light[level=12]
setblock 179 53 332 minecraft:light[level=12]
setblock 179 53 339 minecraft:light[level=12]
setblock 179 53 346 minecraft:light[level=12]
fill 179 53 350 179 56 351 minecraft:magenta_terracotta
setblock 179 53 353 minecraft:light[level=12]
setblock 179 53 360 minecraft:light[level=12]
setblock 180 53 324 minecraft:dark_prismarine
setblock 181 53 323 minecraft:dark_prismarine
setblock 181 53 324 minecraft:blue_terracotta
setblock 181 53 327 minecraft:blue_terracotta
setblock 181 53 328 minecraft:dark_prismarine
fill 181 53 329 181 54 329 minecraft:blue_terracotta
fill 181 53 351 181 53 352 minecraft:blue_terracotta
setblock 181 53 363 minecraft:dark_prismarine
fill 182 53 323 182 56 323 minecraft:blue_terracotta
setblock 182 53 327 minecraft:dark_prismarine
fill 182 53 328 182 56 328 minecraft:blue_terracotta
setblock 182 53 332 minecraft:dark_prismarine
setblock 182 53 337 minecraft:purple_concrete
setblock 182 53 346 minecraft:blue_terracotta
setblock 182 53 347 minecraft:dark_prismarine
fill 182 53 348 182 56 348 minecraft:blue_terracotta
setblock 182 53 352 minecraft:dark_prismarine
fill 182 53 353 182 56 353 minecraft:blue_terracotta
setblock 182 53 356 minecraft:blue_terracotta
setblock 182 53 357 minecraft:dark_prismarine
fill 182 53 358 182 56 358 minecraft:blue_terracotta
setblock 182 53 362 minecraft:dark_prismarine
fill 182 53 363 182 56 363 minecraft:blue_terracotta
setblock 142 54 326 minecraft:dark_prismarine
fill 142 54 327 142 56 327 minecraft:blue_terracotta
setblock 142 54 331 minecraft:dark_prismarine
fill 142 54 332 142 56 333 minecraft:blue_terracotta
setblock 142 54 336 minecraft:purple_concrete
fill 142 54 344 142 54 345 minecraft:blue_terracotta
setblock 142 54 346 minecraft:dark_prismarine
fill 142 54 347 142 57 347 minecraft:blue_terracotta
setblock 142 54 351 minecraft:dark_prismarine
fill 142 54 352 142 57 352 minecraft:blue_terracotta
setblock 142 54 355 minecraft:blue_terracotta
setblock 142 54 356 minecraft:dark_prismarine
fill 142 54 357 142 57 357 minecraft:blue_terracotta
setblock 142 54 360 minecraft:blue_terracotta
setblock 142 54 361 minecraft:dark_prismarine
fill 142 54 362 142 54 363 minecraft:blue_terracotta
setblock 143 54 345 minecraft:dark_prismarine
fill 143 54 346 143 57 346 minecraft:blue_terracotta
setblock 143 54 350 minecraft:dark_prismarine
fill 143 54 351 143 57 351 minecraft:blue_terracotta
setblock 143 54 355 minecraft:dark_prismarine
fill 143 54 356 143 57 356 minecraft:blue_terracotta
setblock 143 54 359 minecraft:blue_terracotta
fill 143 54 363 144 54 363 minecraft:blue_terracotta
setblock 144 54 349 minecraft:dark_prismarine
fill 144 54 350 144 57 350 minecraft:blue_terracotta
setblock 144 54 354 minecraft:dark_prismarine
fill 144 54 355 144 57 355 minecraft:blue_terracotta
setblock 145 54 323 minecraft:dark_prismarine
setblock 145 54 347 minecraft:blue_terracotta
setblock 145 54 348 minecraft:dark_prismarine
fill 145 54 349 145 56 349 minecraft:blue_terracotta
setblock 145 54 353 minecraft:dark_prismarine
fill 145 54 354 145 57 354 minecraft:blue_terracotta
setblock 145 54 363 minecraft:dark_prismarine
fill 146 54 323 146 55 323 minecraft:blue_terracotta
setblock 146 54 351 minecraft:blue_terracotta
fill 146 54 363 149 54 363 minecraft:blue_terracotta
setblock 149 54 324 minecraft:dark_prismarine
setblock 150 54 323 minecraft:dark_prismarine
setblock 150 54 324 minecraft:blue_terracotta
setblock 150 54 363 minecraft:dark_prismarine
setblock 151 54 323 minecraft:blue_terracotta
fill 151 54 347 151 55 348 minecraft:black_concrete
setblock 151 54 363 minecraft:blue_terracotta
setblock 159 54 363 minecraft:purple_concrete
fill 162 54 323 164 54 323 minecraft:blue_terracotta
fill 162 54 331 162 90 331 minecraft:magenta_terracotta
fill 162 54 357 164 58 357 minecraft:magenta_terracotta
setblock 163 54 324 minecraft:blue_terracotta
setblock 164 54 324 minecraft:dark_prismarine
fill 164 54 325 167 54 325 minecraft:blue_terracotta
setblock 165 54 323 minecraft:dark_prismarine
fill 165 54 324 165 57 324 minecraft:blue_terracotta
fill 165 54 326 166 54 326 minecraft:blue_terracotta
fill 166 54 323 166 57 323 minecraft:blue_terracotta
fill 166 54 363 166 57 363 minecraft:blue_terracotta
setblock 167 54 326 minecraft:dark_prismarine
setblock 168 54 325 minecraft:dark_prismarine
fill 168 54 326 168 56 326 minecraft:blue_terracotta
setblock 169 54 324 minecraft:dark_prismarine
fill 169 54 325 169 57 325 minecraft:blue_terracotta
setblock 170 54 323 minecraft:dark_prismarine
fill 170 54 324 170 57 324 minecraft:blue_terracotta
setblock 170 54 363 minecraft:dark_prismarine
fill 171 54 323 171 57 323 minecraft:blue_terracotta
fill 171 54 363 171 57 363 minecraft:blue_terracotta
setblock 172 54 326 minecraft:dark_prismarine
setblock 173 54 325 minecraft:dark_prismarine
setblock 173 54 326 minecraft:blue_terracotta
setblock 174 54 324 minecraft:dark_prismarine
setblock 174 54 325 minecraft:blue_terracotta
fill 174 54 337 176 56 337 minecraft:magenta_terracotta
setblock 175 54 323 minecraft:dark_prismarine
fill 175 54 324 175 55 324 minecraft:blue_terracotta
fill 175 54 336 176 72 336 minecraft:magenta_terracotta
setblock 175 54 363 minecraft:dark_prismarine
fill 176 54 323 176 56 323 minecraft:blue_terracotta
setblock 176 54 363 minecraft:blue_terracotta
setblock 178 54 363 minecraft:purple_concrete
setblock 180 54 323 minecraft:dark_prismarine
setblock 180 54 363 minecraft:dark_prismarine
fill 181 54 323 181 55 323 minecraft:blue_terracotta
setblock 181 54 327 minecraft:dark_prismarine
fill 181 54 328 181 55 328 minecraft:blue_terracotta
setblock 181 54 351 minecraft:blue_terracotta
setblock 181 54 352 minecraft:dark_prismarine
fill 181 54 353 181 55 355 minecraft:blue_terracotta
fill 181 54 363 181 57 363 minecraft:blue_terracotta
setblock 182 54 326 minecraft:dark_prismarine
fill 182 54 327 182 57 327 minecraft:blue_terracotta
setblock 182 54 330 minecraft:blue_terracotta
setblock 182 54 331 minecraft:dark_prismarine
fill 182 54 332 182 56 333 minecraft:blue_terracotta
fill 182 54 347 182 56 347 minecraft:blue_terracotta
setblock 182 54 351 minecraft:dark_prismarine
fill 182 54 352 182 57 352 minecraft:blue_terracotta
setblock 182 54 356 minecraft:dark_prismarine
fill 182 54 357 182 57 357 minecraft:blue_terracotta
fill 182 54 359 182 54 360 minecraft:blue_terracotta
setblock 182 54 361 minecraft:dark_prismarine
fill 182 54 362 182 57 362 minecraft:blue_terracotta
setblock 142 55 326 minecraft:blue_terracotta
setblock 142 55 329 minecraft:blue_terracotta
setblock 142 55 330 minecraft:dark_prismarine
fill 142 55 331 142 58 331 minecraft:blue_terracotta
setblock 142 55 334 minecraft:blue_terracotta
setblock 142 55 342 minecraft:purple_concrete
setblock 142 55 344 minecraft:blue_terracotta
setblock 142 55 345 minecraft:dark_prismarine
fill 142 55 346 142 58 346 minecraft:blue_terracotta
setblock 142 55 350 minecraft:dark_prismarine
fill 142 55 351 142 58 351 minecraft:blue_terracotta
setblock 142 55 355 minecraft:dark_prismarine
fill 142 55 356 142 58 356 minecraft:blue_terracotta
setblock 142 55 360 minecraft:dark_prismarine
fill 142 55 361 142 56 362 minecraft:blue_terracotta
fill 143 55 345 143 56 345 minecraft:blue_terracotta
setblock 143 55 349 minecraft:dark_prismarine
fill 143 55 350 143 58 350 minecraft:blue_terracotta
setblock 143 55 354 minecraft:dark_prismarine
fill 143 55 355 143 58 355 minecraft:blue_terracotta
setblock 143 55 359 minecraft:dark_prismarine
setblock 143 55 363 minecraft:blue_terracotta
setblock 144 55 348 minecraft:dark_prismarine
fill 144 55 349 144 58 349 minecraft:blue_terracotta
setblock 144 55 352 minecraft:blue_terracotta
setblock 144 55 353 minecraft:dark_prismarine
fill 144 55 354 144 58 354 minecraft:blue_terracotta
setblock 144 55 357 minecraft:blue_terracotta
setblock 144 55 363 minecraft:dark_prismarine
setblock 145 55 323 minecraft:blue_terracotta
setblock 145 55 348 minecraft:blue_terracotta
setblock 145 55 352 minecraft:dark_prismarine
fill 145 55 353 145 58 353 minecraft:blue_terracotta
fill 145 55 355 145 56 355 minecraft:blue_terracotta
fill 145 55 363 148 55 363 minecraft:blue_terracotta
setblock 146 55 351 minecraft:dark_prismarine
setblock 149 55 323 minecraft:dark_prismarine
setblock 149 55 363 minecraft:dark_prismarine
setblock 150 55 323 minecraft:blue_terracotta
setblock 150 55 363 minecraft:blue_terracotta
setblock 159 55 323 minecraft:purple_concrete
setblock 159 55 364 minecraft:cyan_concrete
fill 160 55 330 161 58 330 minecraft:magenta_terracotta
fill 160 55 364 164 128 364 minecraft:black_concrete
fill 162 55 323 163 55 323 minecraft:blue_terracotta
setblock 163 55 324 minecraft:dark_prismarine
fill 163 55 329 163 84 329 minecraft:magenta_terracotta
setblock 164 55 323 minecraft:dark_prismarine
fill 164 55 324 164 55 325 minecraft:blue_terracotta
fill 165 55 323 165 58 323 minecraft:blue_terracotta
fill 165 55 325 166 55 325 minecraft:blue_terracotta
setblock 165 55 363 minecraft:purple_concrete
setblock 166 55 326 minecraft:dark_prismarine
setblock 167 55 325 minecraft:dark_prismarine
fill 167 55 326 167 56 326 minecraft:blue_terracotta
setblock 168 55 324 minecraft:dark_prismarine
fill 168 55 325 168 57 325 minecraft:blue_terracotta
setblock 169 55 323 minecraft:dark_prismarine
fill 169 55 324 169 58 324 minecraft:blue_terracotta
setblock 169 55 363 minecraft:dark_prismarine
fill 170 55 323 170 58 323 minecraft:blue_terracotta
fill 170 55 363 170 58 363 minecraft:blue_terracotta
setblock 171 55 326 minecraft:dark_prismarine
setblock 172 55 325 minecraft:dark_prismarine
setblock 173 55 324 minecraft:dark_prismarine
setblock 173 55 325 minecraft:blue_terracotta
setblock 174 55 323 minecraft:dark_prismarine
setblock 174 55 324 minecraft:blue_terracotta
setblock 174 55 363 minecraft:dark_prismarine
fill 175 55 323 175 56 323 minecraft:blue_terracotta
fill 178 55 336 178 102 336 minecraft:magenta_terracotta
setblock 179 55 323 minecraft:dark_prismarine
setblock 180 55 323 minecraft:blue_terracotta
setblock 181 55 351 minecraft:dark_prismarine
fill 181 55 352 181 58 352 minecraft:blue_terracotta
setblock 181 55 356 minecraft:dark_prismarine
setblock 182 55 325 minecraft:dark_prismarine
fill 182 55 326 182 57 326 minecraft:blue_terracotta
setblock 182 55 330 minecraft:dark_prismarine
fill 182 55 331 182 58 331 minecraft:blue_terracotta
setblock 182 55 344 minecraft:purple_concrete
setblock 182 55 350 minecraft:dark_prismarine
fill 182 55 351 182 58 351 minecraft:blue_terracotta
setblock 182 55 355 minecraft:dark_prismarine
fill 182 55 356 182 58 356 minecraft:blue_terracotta
setblock 182 55 359 minecraft:blue_terracotta
setblock 182 55 360 minecraft:dark_prismarine
fill 182 55 361 182 58 361 minecraft:blue_terracotta
setblock 142 56 323 minecraft:purple_concrete
setblock 142 56 329 minecraft:dark_prismarine
fill 142 56 330 142 59 330 minecraft:blue_terracotta
setblock 142 56 334 minecraft:dark_prismarine
fill 142 56 335 142 59 335 minecraft:blue_terracotta
setblock 142 56 344 minecraft:dark_prismarine
fill 142 56 345 142 59 345 minecraft:blue_terracotta
setblock 142 56 349 minecraft:dark_prismarine
fill 142 56 350 142 59 350 minecraft:blue_terracotta
setblock 142 56 354 minecraft:dark_prismarine
fill 142 56 355 142 59 355 minecraft:blue_terracotta
setblock 142 56 358 minecraft:blue_terracotta
setblock 142 56 359 minecraft:dark_prismarine
fill 142 56 360 142 59 360 minecraft:blue_terracotta
setblock 143 56 331 minecraft:blue_terracotta
setblock 143 56 348 minecraft:dark_prismarine
fill 143 56 349 143 59 349 minecraft:blue_terracotta
setblock 143 56 353 minecraft:dark_prismarine
fill 143 56 354 143 59 354 minecraft:blue_terracotta
setblock 143 56 358 minecraft:dark_prismarine
fill 143 56 359 143 59 359 minecraft:blue_terracotta
setblock 143 56 363 minecraft:dark_prismarine
setblock 144 56 347 minecraft:dark_prismarine
fill 144 56 348 144 58 348 minecraft:blue_terracotta
setblock 144 56 352 minecraft:dark_prismarine
fill 144 56 353 144 59 353 minecraft:blue_terracotta
setblock 144 56 357 minecraft:dark_prismarine
fill 144 56 363 147 56 363 minecraft:blue_terracotta
setblock 145 56 351 minecraft:dark_prismarine
fill 145 56 352 145 58 352 minecraft:blue_terracotta
setblock 148 56 323 minecraft:dark_prismarine
setblock 148 56 363 minecraft:dark_prismarine
setblock 153 56 323 minecraft:purple_concrete
fill 159 56 364 159 72 364 minecraft:black_concrete
setblock 162 56 323 minecraft:blue_terracotta
setblock 163 56 323 minecraft:dark_prismarine
fill 163 56 330 163 83 330 minecraft:magenta_terracotta
fill 164 56 323 164 58 324 minecraft:blue_terracotta
setblock 165 56 325 minecraft:blue_terracotta
setblock 166 56 325 minecraft:dark_prismarine
setblock 167 56 324 minecraft:dark_prismarine
fill 167 56 325 167 57 325 minecraft:blue_terracotta
setblock 168 56 323 minecraft:dark_prismarine
fill 168 56 324 168 59 324 minecraft:blue_terracotta
setblock 168 56 363 minecraft:dark_prismarine
fill 169 56 323 169 59 323 minecraft:blue_terracotta
fill 169 56 363 169 59 363 minecraft:blue_terracotta
setblock 171 56 325 minecraft:dark_prismarine
setblock 172 56 324 minecraft:dark_prismarine
setblock 173 56 323 minecraft:dark_prismarine
setblock 173 56 324 minecraft:blue_terracotta
setblock 173 56 363 minecraft:dark_prismarine
fill 174 56 323 174 57 323 minecraft:blue_terracotta
fill 175 56 350 175 102 350 minecraft:magenta_terracotta
setblock 178 56 323 minecraft:purple_concrete
fill 181 56 351 181 59 351 minecraft:blue_terracotta
fill 181 56 353 181 56 354 minecraft:blue_terracotta
setblock 181 56 355 minecraft:dark_prismarine
fill 181 56 356 181 58 357 minecraft:blue_terracotta
setblock 182 56 324 minecraft:dark_prismarine
fill 182 56 325 182 57 325 minecraft:blue_terracotta
setblock 182 56 329 minecraft:dark_prismarine
fill 182 56 330 182 59 330 minecraft:blue_terracotta
setblock 182 56 334 minecraft:dark_prismarine
setblock 182 56 338 minecraft:purple_concrete
setblock 182 56 349 minecraft:dark_prismarine
fill 182 56 350 182 59 350 minecraft:blue_terracotta
setblock 182 56 354 minecraft:dark_prismarine
fill 182 56 355 182 59 355 minecraft:blue_terracotta
setblock 182 56 359 minecraft:dark_prismarine
fill 182 56 360 182 59 360 minecraft:blue_terracotta
setblock 142 57 328 minecraft:dark_prismarine
fill 142 57 329 142 59 329 minecraft:blue_terracotta
setblock 142 57 332 minecraft:blue_terracotta
setblock 142 57 333 minecraft:dark_prismarine
fill 142 57 334 142 60 334 minecraft:blue_terracotta
fill 142 57 336 142 58 336 minecraft:blue_terracotta
fill 142 57 344 142 60 344 minecraft:blue_terracotta
setblock 142 57 348 minecraft:dark_prismarine
fill 142 57 349 142 60 349 minecraft:blue_terracotta
setblock 142 57 353 minecraft:dark_prismarine
fill 142 57 354 142 60 354 minecraft:blue_terracotta
setblock 142 57 358 minecraft:dark_prismarine
fill 142 57 359 142 60 359 minecraft:blue_terracotta
fill 142 57 361 142 58 361 minecraft:blue_terracotta
setblock 143 57 332 minecraft:dark_prismarine
fill 143 57 333 143 60 333 minecraft:blue_terracotta
setblock 143 57 347 minecraft:dark_prismarine
fill 143 57 348 143 60 348 minecraft:blue_terracotta
setblock 143 57 352 minecraft:dark_prismarine
fill 143 57 353 143 60 353 minecraft:blue_terracotta
setblock 143 57 357 minecraft:dark_prismarine
fill 143 57 358 143 60 358 minecraft:blue_terracotta
setblock 144 57 351 minecraft:dark_prismarine
fill 144 57 352 144 60 352 minecraft:blue_terracotta
setblock 144 57 356 minecraft:dark_prismarine
fill 144 57 357 144 60 357 minecraft:blue_terracotta
fill 144 57 363 146 57 363 minecraft:blue_terracotta
setblock 145 57 350 minecraft:dark_prismarine
fill 145 57 351 145 58 351 minecraft:blue_terracotta
setblock 145 57 355 minecraft:dark_prismarine
setblock 147 57 323 minecraft:purple_concrete
fill 147 57 349 148 58 351 minecraft:magenta_terracotta
setblock 147 57 363 minecraft:dark_prismarine
fill 149 57 349 149 71 350 minecraft:magenta_terracotta
setblock 152 57 363 minecraft:purple_concrete
fill 156 57 336 156 58 336 minecraft:black_concrete
fill 158 57 363 158 58 363 minecraft:purple_concrete
fill 160 57 329 161 58 329 minecraft:magenta_terracotta
fill 163 57 323 163 60 323 minecraft:blue_terracotta
setblock 166 57 324 minecraft:dark_prismarine
setblock 166 57 325 minecraft:blue_terracotta
setblock 167 57 323 minecraft:dark_prismarine
fill 167 57 324 167 60 324 minecraft:blue_terracotta
setblock 167 57 363 minecraft:dark_prismarine
fill 168 57 323 168 60 323 minecraft:blue_terracotta
fill 168 57 363 168 60 363 minecraft:blue_terracotta
setblock 171 57 324 minecraft:dark_prismarine
setblock 172 57 323 minecraft:dark_prismarine
setblock 173 57 323 minecraft:blue_terracotta
fill 175 57 337 176 58 337 minecraft:magenta_terracotta
fill 176 57 335 176 67 335 minecraft:magenta_terracotta
setblock 177 57 363 minecraft:purple_concrete
fill 179 57 350 179 61 350 minecraft:magenta_terracotta
setblock 181 57 353 minecraft:blue_terracotta
setblock 181 57 354 minecraft:dark_prismarine
fill 181 57 355 181 60 355 minecraft:blue_terracotta
setblock 181 57 358 minecraft:blue_terracotta
setblock 182 57 328 minecraft:dark_prismarine
fill 182 57 329 182 60 329 minecraft:blue_terracotta
setblock 182 57 332 minecraft:blue_terracotta
setblock 182 57 333 minecraft:dark_prismarine
fill 182 57 334 182 60 334 minecraft:blue_terracotta
setblock 182 57 348 minecraft:dark_prismarine
fill 182 57 349 182 60 349 minecraft:blue_terracotta
setblock 182 57 353 minecraft:dark_prismarine
fill 182 57 354 182 60 354 minecraft:blue_terracotta
setblock 182 57 358 minecraft:dark_prismarine
fill 182 57 359 182 60 359 minecraft:blue_terracotta
setblock 182 57 363 minecraft:dark_prismarine
setblock 142 58 332 minecraft:dark_prismarine
fill 142 58 333 142 61 333 minecraft:blue_terracotta
setblock 142 58 337 minecraft:dark_prismarine
fill 142 58 338 142 61 338 minecraft:blue_terracotta
setblock 142 58 341 minecraft:purple_concrete
setblock 142 58 347 minecraft:dark_prismarine
fill 142 58 348 142 61 348 minecraft:blue_terracotta
setblock 142 58 352 minecraft:dark_prismarine
fill 142 58 353 142 61 353 minecraft:blue_terracotta
setblock 142 58 357 minecraft:dark_prismarine
fill 142 58 358 142 61 358 minecraft:blue_terracotta
setblock 142 58 362 minecraft:dark_prismarine
fill 143 58 332 143 61 332 minecraft:blue_terracotta
fill 143 58 334 143 58 335 minecraft:blue_terracotta
setblock 143 58 346 minecraft:dark_prismarine
fill 143 58 347 143 61 347 minecraft:blue_terracotta
setblock 143 58 351 minecraft:dark_prismarine
fill 143 58 352 143 61 352 minecraft:blue_terracotta
setblock 143 58 356 minecraft:dark_prismarine
fill 143 58 357 143 61 357 minecraft:blue_terracotta
setblock 144 58 350 minecraft:dark_prismarine
fill 144 58 351 144 61 351 minecraft:blue_terracotta
setblock 144 58 355 minecraft:dark_prismarine
fill 144 58 356 144 61 356 minecraft:blue_terracotta
setblock 145 58 354 minecraft:dark_prismarine
setblock 145 58 355 minecraft:blue_terracotta
fill 146 58 348 146 102 348 minecraft:magenta_terracotta
fill 149 58 336 149 102 336 minecraft:magenta_terracotta
setblock 160 58 323 minecraft:purple_concrete
setblock 164 58 363 minecraft:purple_concrete
setblock 165 58 324 minecraft:dark_prismarine
setblock 166 58 323 minecraft:dark_prismarine
fill 166 58 324 166 61 324 minecraft:blue_terracotta
setblock 166 58 363 minecraft:dark_prismarine
fill 167 58 323 167 61 323 minecraft:blue_terracotta
fill 167 58 363 167 61 363 minecraft:blue_terracotta
setblock 170 58 324 minecraft:dark_prismarine
setblock 171 58 323 minecraft:dark_prismarine
setblock 172 58 323 minecraft:blue_terracotta
setblock 181 58 353 minecraft:dark_prismarine
fill 181 58 354 181 61 354 minecraft:blue_terracotta
setblock 181 58 358 minecraft:dark_prismarine
fill 181 58 359 181 61 359 minecraft:blue_terracotta
setblock 181 58 363 minecraft:dark_prismarine
setblock 182 58 326 minecraft:purple_concrete
setblock 182 58 327 minecraft:dark_prismarine
setblock 182 58 328 minecraft:blue_terracotta
setblock 182 58 332 minecraft:dark_prismarine
fill 182 58 333 182 61 333 minecraft:blue_terracotta
setblock 182 58 345 minecraft:purple_concrete
fill 182 58 348 182 61 348 minecraft:blue_terracotta
setblock 182 58 352 minecraft:dark_prismarine
fill 182 58 353 182 61 353 minecraft:blue_terracotta
setblock 182 58 357 minecraft:dark_prismarine
fill 182 58 358 182 61 358 minecraft:blue_terracotta
setblock 182 58 362 minecraft:dark_prismarine
fill 182 58 363 182 61 363 minecraft:blue_terracotta
setblock 142 59 331 minecraft:dark_prismarine
fill 142 59 332 142 62 332 minecraft:blue_terracotta
setblock 142 59 336 minecraft:dark_prismarine
fill 142 59 337 143 61 337 minecraft:blue_terracotta
fill 142 59 339 142 59 340 minecraft:blue_terracotta
setblock 142 59 341 minecraft:dark_prismarine
fill 142 59 343 142 61 343 minecraft:blue_terracotta
setblock 142 59 346 minecraft:dark_prismarine
fill 142 59 347 142 62 347 minecraft:blue_terracotta
setblock 142 59 351 minecraft:dark_prismarine
fill 142 59 352 142 62 352 minecraft:blue_terracotta
setblock 142 59 356 minecraft:dark_prismarine
fill 142 59 357 142 62 357 minecraft:blue_terracotta
setblock 142 59 361 minecraft:dark_prismarine
fill 142 59 362 142 62 362 minecraft:blue_terracotta
setblock 143 59 334 minecraft:blue_terracotta
setblock 143 59 335 minecraft:dark_prismarine
fill 143 59 336 143 62 336 minecraft:blue_terracotta
setblock 143 59 350 minecraft:dark_prismarine
fill 143 59 351 143 62 351 minecraft:blue_terracotta
setblock 143 59 355 minecraft:dark_prismarine
fill 143 59 356 143 62 356 minecraft:blue_terracotta
setblock 143 59 360 minecraft:dark_prismarine
setblock 144 59 325 minecraft:light[level=12]
setblock 144 59 332 minecraft:light[level=12]
setblock 144 59 339 minecraft:light[level=12]
setblock 144 59 346 minecraft:light[level=12]
setblock 144 59 349 minecraft:dark_prismarine
fill 144 59 350 144 62 350 minecraft:blue_terracotta
setblock 144 59 354 minecraft:dark_prismarine
fill 144 59 355 144 62 355 minecraft:blue_terracotta
setblock 144 59 358 minecraft:blue_terracotta
setblock 144 59 360 minecraft:light[level=12]
fill 145 59 335 146 60 336 minecraft:magenta_terracotta
setblock 145 59 353 minecraft:dark_prismarine
setblock 145 59 354 minecraft:blue_terracotta
setblock 145 59 363 minecraft:purple_concrete
fill 147 59 335 147 59 336 minecraft:pink_terracotta
fill 147 59 349 148 59 349 minecraft:pink_terracotta
fill 147 59 350 147 86 351 minecraft:magenta_terracotta
fill 148 59 335 148 83 336 minecraft:magenta_terracotta
setblock 148 59 350 minecraft:pink_terracotta
fill 148 59 351 148 71 351 minecraft:magenta_terracotta
setblock 151 59 325 minecraft:light[level=12]
setblock 151 59 332 minecraft:light[level=12]
setblock 151 59 339 minecraft:light[level=12]
setblock 151 59 346 minecraft:light[level=12]
setblock 151 59 353 minecraft:light[level=12]
setblock 151 59 360 minecraft:light[level=12]
setblock 154 59 323 minecraft:purple_concrete
setblock 158 59 325 minecraft:light[level=12]
setblock 158 59 332 minecraft:light[level=12]
setblock 158 59 339 minecraft:light[level=12]
setblock 158 59 346 minecraft:light[level=12]
setblock 158 59 353 minecraft:light[level=12]
setblock 158 59 360 minecraft:light[level=12]
fill 160 59 329 160 69 330 minecraft:magenta_terracotta
fill 161 59 329 161 59 330 minecraft:pink_terracotta
fill 161 59 358 161 94 358 minecraft:magenta_terracotta
setblock 162 59 329 minecraft:pink_terracotta
fill 162 59 356 163 59 357 minecraft:pink_terracotta
setblock 164 59 323 minecraft:blue_terracotta
fill 164 59 356 164 66 357 minecraft:magenta_terracotta
setblock 165 59 323 minecraft:dark_prismarine
fill 165 59 324 165 62 324 minecraft:blue_terracotta
setblock 165 59 325 minecraft:light[level=12]
setblock 165 59 332 minecraft:light[level=12]
setblock 165 59 339 minecraft:light[level=12]
setblock 165 59 346 minecraft:light[level=12]
setblock 165 59 353 minecraft:light[level=12]
setblock 165 59 360 minecraft:light[level=12]
setblock 165 59 363 minecraft:dark_prismarine
fill 166 59 323 166 62 323 minecraft:blue_terracotta
fill 166 59 363 166 62 363 minecraft:blue_terracotta
setblock 170 59 323 minecraft:dark_prismarine
setblock 170 59 363 minecraft:dark_prismarine
setblock 171 59 323 minecraft:blue_terracotta
setblock 172 59 325 minecraft:light[level=12]
setblock 172 59 332 minecraft:light[level=12]
setblock 172 59 339 minecraft:light[level=12]
fill 172 59 346 173 60 347 minecraft:spruce_planks
setblock 172 59 353 minecraft:light[level=12]
setblock 172 59 360 minecraft:light[level=12]
setblock 175 59 322 minecraft:light_blue_wool
fill 175 59 337 175 80 337 minecraft:magenta_terracotta
fill 176 59 322 177 131 322 minecraft:black_concrete
fill 176 59 337 177 59 337 minecraft:pink_terracotta
fill 176 59 349 176 61 352 minecraft:magenta_terracotta
fill 177 59 335 177 69 336 minecraft:magenta_terracotta
fill 177 59 349 178 76 349 minecraft:magenta_terracotta
fill 177 59 350 177 59 351 minecraft:pink_terracotta
fill 177 59 352 177 76 352 minecraft:magenta_terracotta
fill 178 59 350 178 78 351 minecraft:magenta_terracotta
setblock 179 59 323 minecraft:purple_concrete
setblock 179 59 325 minecraft:light[level=12]
setblock 179 59 332 minecraft:light[level=12]
setblock 179 59 339 minecraft:light[level=12]
setblock 179 59 346 minecraft:light[level=12]
setblock 179 59 353 minecraft:light[level=12]
setblock 179 59 360 minecraft:light[level=12]
setblock 181 59 352 minecraft:dark_prismarine
fill 181 59 353 181 62 353 minecraft:blue_terracotta
setblock 181 59 356 minecraft:blue_terracotta
setblock 181 59 357 minecraft:dark_prismarine
fill 181 59 358 181 62 358 minecraft:blue_terracotta
fill 181 59 360 181 60 360 minecraft:blue_terracotta
fill 181 59 363 181 62 363 minecraft:blue_terracotta
setblock 182 59 331 minecraft:dark_prismarine
fill 182 59 332 182 62 332 minecraft:blue_terracotta
setblock 182 59 335 minecraft:blue_terracotta
setblock 182 59 339 minecraft:purple_concrete
setblock 182 59 351 minecraft:dark_prismarine
fill 182 59 352 182 62 352 minecraft:blue_terracotta
setblock 182 59 356 minecraft:dark_prismarine
fill 182 59 357 182 62 357 minecraft:blue_terracotta
setblock 182 59 361 minecraft:dark_prismarine
fill 182 59 362 182 62 362 minecraft:blue_terracotta
setblock 142 60 328 minecraft:purple_concrete
setblock 142 60 330 minecraft:dark_prismarine
fill 142 60 331 142 63 331 minecraft:blue_terracotta
setblock 142 60 335 minecraft:dark_prismarine
fill 142 60 336 142 63 336 minecraft:blue_terracotta
setblock 142 60 339 minecraft:blue_terracotta
setblock 142 60 340 minecraft:dark_prismarine
fill 142 60 341 142 62 342 minecraft:blue_terracotta
setblock 142 60 345 minecraft:dark_prismarine
fill 142 60 346 142 63 346 minecraft:blue_terracotta
setblock 142 60 350 minecraft:dark_prismarine
fill 142 60 351 142 63 351 minecraft:blue_terracotta
setblock 142 60 355 minecraft:dark_prismarine
fill 142 60 356 142 63 356 minecraft:blue_terracotta
setblock 142 60 360 minecraft:dark_prismarine
fill 142 60 361 142 63 361 minecraft:blue_terracotta
setblock 143 60 334 minecraft:dark_prismarine
fill 143 60 335 143 63 335 minecraft:blue_terracotta
setblock 143 60 338 minecraft:blue_terracotta
setblock 143 60 339 minecraft:dark_prismarine
setblock 143 60 349 minecraft:dark_prismarine
fill 143 60 350 143 63 350 minecraft:blue_terracotta
setblock 143 60 354 minecraft:dark_prismarine
fill 143 60 355 143 63 355 minecraft:blue_terracotta
setblock 143 60 359 minecraft:dark_prismarine
fill 143 60 360 143 63 360 minecraft:blue_terracotta
setblock 143 60 363 minecraft:blue_terracotta
setblock 144 60 353 minecraft:dark_prismarine
fill 144 60 354 144 63 354 minecraft:blue_terracotta
setblock 144 60 358 minecraft:dark_prismarine
setblock 144 60 363 minecraft:dark_prismarine
fill 147 60 335 147 102 335 minecraft:magenta_terracotta
setblock 147 60 336 minecraft:pink_terracotta
fill 147 60 349 148 83 349 minecraft:magenta_terracotta
setblock 148 60 323 minecraft:purple_concrete
fill 148 60 350 148 102 350 minecraft:magenta_terracotta
fill 149 60 335 149 102 335 minecraft:magenta_terracotta
setblock 151 60 363 minecraft:purple_concrete
setblock 161 60 329 minecraft:pink_terracotta
fill 161 60 330 161 83 330 minecraft:magenta_terracotta
fill 162 60 323 162 61 323 minecraft:blue_terracotta
fill 162 60 329 162 95 329 minecraft:magenta_terracotta
fill 162 60 356 163 79 357 minecraft:magenta_terracotta
setblock 164 60 323 minecraft:dark_prismarine
setblock 164 60 363 minecraft:dark_prismarine
fill 165 60 323 165 63 323 minecraft:blue_terracotta
fill 165 60 363 165 63 363 minecraft:blue_terracotta
setblock 169 60 323 minecraft:dark_prismarine
setblock 169 60 363 minecraft:dark_prismarine
fill 170 60 323 170 63 323 minecraft:blue_terracotta
fill 170 60 363 170 63 363 minecraft:blue_terracotta
setblock 173 60 323 minecraft:purple_concrete
fill 175 60 322 175 93 322 minecraft:black_concrete
setblock 176 60 337 minecraft:pink_terracotta
setblock 176 60 363 minecraft:purple_concrete
fill 177 60 337 177 83 337 minecraft:magenta_terracotta
setblock 177 60 350 minecraft:pink_terracotta
fill 177 60 351 177 96 351 minecraft:magenta_terracotta
fill 178 60 338 178 102 338 minecraft:magenta_terracotta
fill 180 60 363 180 63 363 minecraft:blue_terracotta
setblock 181 60 351 minecraft:dark_prismarine
fill 181 60 352 181 63 352 minecraft:blue_terracotta
setblock 181 60 356 minecraft:dark_prismarine
fill 181 60 357 181 63 357 minecraft:blue_terracotta
setblock 181 60 361 minecraft:dark_prismarine
setblock 182 60 330 minecraft:dark_prismarine
fill 182 60 331 182 63 331 minecraft:blue_terracotta
setblock 182 60 335 minecraft:dark_prismarine
fill 182 60 336 182 62 337 minecraft:blue_terracotta
setblock 182 60 350 minecraft:dark_prismarine
fill 182 60 351 182 63 351 minecraft:blue_terracotta
setblock 182 60 355 minecraft:dark_prismarine
fill 182 60 356 182 63 356 minecraft:blue_terracotta
setblock 182 60 360 minecraft:dark_prismarine
fill 182 60 361 182 63 361 minecraft:blue_terracotta
fill 142 61 330 142 64 330 minecraft:blue_terracotta
setblock 142 61 334 minecraft:dark_prismarine
fill 142 61 335 142 64 335 minecraft:blue_terracotta
setblock 142 61 339 minecraft:dark_prismarine
fill 142 61 340 143 63 340 minecraft:blue_terracotta
setblock 142 61 344 minecraft:dark_prismarine
fill 142 61 345 142 64 345 minecraft:blue_terracotta
setblock 142 61 349 minecraft:dark_prismarine
fill 142 61 350 142 64 350 minecraft:blue_terracotta
setblock 142 61 354 minecraft:dark_prismarine
fill 142 61 355 142 64 355 minecraft:blue_terracotta
setblock 142 61 359 minecraft:dark_prismarine
fill 142 61 360 142 64 360 minecraft:blue_terracotta
setblock 142 61 363 minecraft:blue_terracotta
setblock 143 61 333 minecraft:dark_prismarine
fill 143 61 334 144 63 334 minecraft:blue_terracotta
setblock 143 61 338 minecraft:dark_prismarine
fill 143 61 339 143 64 339 minecraft:blue_terracotta
fill 143 61 341 143 61 342 minecraft:blue_terracotta
fill 143 61 346 143 62 346 minecraft:blue_terracotta
setblock 143 61 348 minecraft:dark_prismarine
fill 143 61 349 143 64 349 minecraft:blue_terracotta
setblock 143 61 353 minecraft:dark_prismarine
fill 143 61 354 143 64 354 minecraft:blue_terracotta
setblock 143 61 358 minecraft:dark_prismarine
fill 143 61 359 144 63 359 minecraft:blue_terracotta
fill 143 61 361 143 62 361 minecraft:blue_terracotta
setblock 143 61 363 minecraft:dark_prismarine
setblock 144 61 325 minecraft:light[level=13]
setblock 144 61 333 minecraft:light[level=13]
fill 144 61 335 144 61 336 minecraft:blue_terracotta
setblock 144 61 337 minecraft:dark_prismarine
setblock 144 61 341 minecraft:light[level=13]
setblock 144 61 349 minecraft:light[level=13]
setblock 144 61 352 minecraft:dark_prismarine
fill 144 61 353 144 64 353 minecraft:blue_terracotta
setblock 144 61 357 minecraft:dark_prismarine
fill 144 61 358 144 64 358 minecraft:blue_terracotta
fill 144 61 363 145 63 363 minecraft:blue_terracotta
fill 145 61 336 147 61 336 minecraft:magenta_terracotta
fill 146 61 335 146 83 335 minecraft:magenta_terracotta
setblock 152 61 325 minecraft:light[level=13]
setblock 152 61 333 minecraft:light[level=13]
setblock 152 61 341 minecraft:light[level=13]
setblock 152 61 349 minecraft:light[level=13]
setblock 152 61 357 minecraft:light[level=13]
setblock 157 61 363 minecraft:purple_concrete
setblock 160 61 325 minecraft:light[level=13]
setblock 160 61 333 minecraft:light[level=13]
setblock 160 61 341 minecraft:light[level=13]
setblock 160 61 349 minecraft:light[level=13]
setblock 160 61 357 minecraft:light[level=13]
fill 161 61 329 161 82 329 minecraft:magenta_terracotta
fill 161 61 355 161 99 355 minecraft:magenta_terracotta
setblock 163 61 323 minecraft:dark_prismarine
fill 163 61 358 163 70 358 minecraft:magenta_terracotta
setblock 163 61 363 minecraft:dark_prismarine
fill 164 61 323 164 63 324 minecraft:blue_terracotta
fill 164 61 363 164 64 363 minecraft:blue_terracotta
setblock 168 61 323 minecraft:dark_prismarine
setblock 168 61 325 minecraft:light[level=13]
setblock 168 61 333 minecraft:light[level=13]
setblock 168 61 341 minecraft:light[level=13]
setblock 168 61 349 minecraft:light[level=13]
setblock 168 61 357 minecraft:light[level=13]
setblock 168 61 363 minecraft:dark_prismarine
fill 169 61 323 169 64 323 minecraft:blue_terracotta
fill 169 61 363 169 64 363 minecraft:blue_terracotta
setblock 170 61 322 minecraft:cyan_concrete
setblock 176 61 325 minecraft:light[level=13]
setblock 176 61 333 minecraft:light[level=13]
fill 176 61 337 176 102 337 minecraft:magenta_terracotta
setblock 176 61 341 minecraft:light[level=13]
setblock 176 61 357 minecraft:light[level=13]
fill 177 61 350 177 100 350 minecraft:magenta_terracotta
setblock 178 61 363 minecraft:dark_prismarine
fill 179 61 363 179 64 363 minecraft:blue_terracotta
setblock 180 61 355 minecraft:blue_terracotta
setblock 180 61 356 minecraft:dark_prismarine
fill 180 61 357 180 63 358 minecraft:blue_terracotta
fill 181 61 351 181 64 351 minecraft:blue_terracotta
setblock 181 61 355 minecraft:dark_prismarine
fill 181 61 356 181 64 356 minecraft:blue_terracotta
setblock 181 61 360 minecraft:dark_prismarine
fill 181 61 361 181 63 362 minecraft:blue_terracotta
setblock 182 61 327 minecraft:purple_concrete
fill 182 61 330 182 64 330 minecraft:blue_terracotta
setblock 182 61 334 minecraft:dark_prismarine
fill 182 61 335 182 64 335 minecraft:blue_terracotta
setblock 182 61 338 minecraft:blue_terracotta
setblock 182 61 339 minecraft:dark_prismarine
setblock 182 61 349 minecraft:dark_prismarine
fill 182 61 350 182 64 350 minecraft:blue_terracotta
setblock 182 61 354 minecraft:dark_prismarine
fill 182 61 355 182 64 355 minecraft:blue_terracotta
setblock 182 61 359 minecraft:dark_prismarine
fill 182 61 360 182 64 360 minecraft:blue_terracotta
fill 142 62 329 142 65 329 minecraft:blue_terracotta
setblock 142 62 333 minecraft:dark_prismarine
fill 142 62 334 142 65 334 minecraft:blue_terracotta
setblock 142 62 337 minecraft:blue_terracotta
setblock 142 62 338 minecraft:dark_prismarine
fill 142 62 339 142 65 339 minecraft:blue_terracotta
setblock 142 62 343 minecraft:dark_prismarine
fill 142 62 344 143 64 344 minecraft:blue_terracotta
setblock 142 62 348 minecraft:dark_prismarine
fill 142 62 349 142 65 349 minecraft:blue_terracotta
setblock 142 62 353 minecraft:dark_prismarine
fill 142 62 354 142 65 354 minecraft:blue_terracotta
setblock 142 62 358 minecraft:dark_prismarine
fill 142 62 359 142 65 359 minecraft:blue_terracotta
setblock 142 62 363 minecraft:dark_prismarine
setblock 143 62 331 minecraft:blue_terracotta
setblock 143 62 332 minecraft:dark_prismarine
fill 143 62 333 143 65 333 minecraft:blue_terracotta
setblock 143 62 337 minecraft:dark_prismarine
fill 143 62 338 144 64 338 minecraft:blue_terracotta
setblock 143 62 341 minecraft:blue_terracotta
setblock 143 62 342 minecraft:dark_prismarine
fill 143 62 343 143 65 343 minecraft:blue_terracotta
fill 143 62 345 143 63 345 minecraft:blue_terracotta
setblock 143 62 347 minecraft:dark_prismarine
fill 143 62 348 143 65 348 minecraft:blue_terracotta
setblock 143 62 352 minecraft:dark_prismarine
fill 143 62 353 143 65 353 minecraft:blue_terracotta
setblock 143 62 357 minecraft:dark_prismarine
fill 143 62 358 143 65 358 minecraft:blue_terracotta
setblock 143 62 362 minecraft:dark_prismarine
fill 143 62 363 143 65 363 minecraft:blue_terracotta
setblock 144 62 335 minecraft:blue_terracotta
setblock 144 62 336 minecraft:dark_prismarine
fill 144 62 337 144 65 337 minecraft:blue_terracotta
fill 144 62 339 144 62 340 minecraft:blue_terracotta
setblock 144 62 351 minecraft:dark_prismarine
fill 144 62 352 144 65 352 minecraft:blue_terracotta
setblock 144 62 356 minecraft:dark_prismarine
fill 144 62 357 144 65 357 minecraft:blue_terracotta
fill 146 62 336 147 85 336 minecraft:magenta_terracotta
setblock 146 62 363 minecraft:blue_terracotta
fill 160 62 323 161 62 323 minecraft:blue_terracotta
setblock 161 62 363 minecraft:blue_terracotta
setblock 162 62 323 minecraft:dark_prismarine
setblock 162 62 363 minecraft:dark_prismarine
fill 163 62 323 163 64 324 minecraft:blue_terracotta
fill 163 62 363 163 65 363 minecraft:blue_terracotta
fill 164 62 362 167 62 362 minecraft:blue_terracotta
setblock 166 62 322 minecraft:light_blue_wool
setblock 166 62 324 minecraft:dark_prismarine
setblock 167 62 323 minecraft:dark_prismarine
setblock 167 62 363 minecraft:dark_prismarine
fill 168 62 323 168 65 323 minecraft:blue_terracotta
setblock 168 62 362 minecraft:dark_prismarine
fill 168 62 363 168 65 363 minecraft:blue_terracotta
fill 170 62 322 170 131 322 minecraft:black_concrete
setblock 171 62 363 minecraft:blue_terracotta
setblock 172 62 363 minecraft:dark_prismarine
fill 176 62 349 176 83 351 minecraft:magenta_terracotta
setblock 176 62 363 minecraft:blue_terracotta
setblock 177 62 363 minecraft:dark_prismarine
fill 178 62 363 178 65 363 minecraft:blue_terracotta
fill 179 62 362 180 64 362 minecraft:blue_terracotta
setblock 180 62 323 minecraft:purple_concrete
setblock 180 62 354 minecraft:blue_terracotta
setblock 180 62 355 minecraft:dark_prismarine
fill 180 62 356 180 65 356 minecraft:blue_terracotta
setblock 180 62 359 minecraft:blue_terracotta
setblock 180 62 360 minecraft:dark_prismarine
setblock 181 62 354 minecraft:dark_prismarine
fill 181 62 355 181 65 355 minecraft:blue_terracotta
setblock 181 62 359 minecraft:dark_prismarine
fill 181 62 360 181 65 360 minecraft:blue_terracotta
setblock 182 62 333 minecraft:dark_prismarine
fill 182 62 334 182 65 334 minecraft:blue_terracotta
setblock 182 62 338 minecraft:dark_prismarine
fill 182 62 339 182 62 342 minecraft:blue_terracotta
fill 182 62 346 182 62 347 minecraft:blue_terracotta
setblock 182 62 348 minecraft:dark_prismarine
fill 182 62 349 182 65 349 minecraft:blue_terracotta
setblock 182 62 353 minecraft:dark_prismarine
fill 182 62 354 182 65 354 minecraft:blue_terracotta
setblock 182 62 358 minecraft:dark_prismarine
fill 182 62 359 182 65 359 minecraft:blue_terracotta
setblock 182 62 363 minecraft:dark_prismarine
setblock 183 62 325 minecraft:light_blue_wool
fill 183 62 326 183 131 326 minecraft:black_concrete
setblock 142 63 327 minecraft:purple_concrete
setblock 142 63 332 minecraft:dark_prismarine
fill 142 63 333 142 66 333 minecraft:blue_terracotta
setblock 142 63 337 minecraft:dark_prismarine
fill 142 63 338 142 66 338 minecraft:blue_terracotta
setblock 142 63 341 minecraft:blue_terracotta
setblock 142 63 342 minecraft:dark_prismarine
fill 142 63 343 142 66 343 minecraft:blue_terracotta
setblock 142 63 347 minecraft:dark_prismarine
fill 142 63 348 142 66 348 minecraft:blue_terracotta
setblock 142 63 352 minecraft:dark_prismarine
fill 142 63 353 142 66 353 minecraft:blue_terracotta
setblock 142 63 357 minecraft:dark_prismarine
fill 142 63 358 142 66 358 minecraft:blue_terracotta
setblock 142 63 362 minecraft:dark_prismarine
fill 142 63 363 142 66 363 minecraft:blue_terracotta
setblock 143 63 331 minecraft:dark_prismarine
fill 143 63 332 143 66 332 minecraft:blue_terracotta
setblock 143 63 336 minecraft:dark_prismarine
fill 143 63 337 143 66 337 minecraft:blue_terracotta
setblock 143 63 341 minecraft:dark_prismarine
fill 143 63 342 144 65 342 minecraft:blue_terracotta
setblock 143 63 346 minecraft:dark_prismarine
fill 143 63 347 143 66 347 minecraft:blue_terracotta
setblock 143 63 351 minecraft:dark_prismarine
fill 143 63 352 143 66 352 minecraft:blue_terracotta
setblock 143 63 356 minecraft:dark_prismarine
fill 143 63 357 143 66 357 minecraft:blue_terracotta
setblock 143 63 361 minecraft:dark_prismarine
fill 143 63 362 145 64 362 minecraft:blue_terracotta
fill 144 63 333 144 64 333 minecraft:blue_terracotta
setblock 144 63 335 minecraft:dark_prismarine
fill 144 63 336 144 66 336 minecraft:blue_terracotta
setblock 144 63 339 minecraft:blue_terracotta
setblock 144 63 340 minecraft:dark_prismarine
fill 144 63 341 144 66 341 minecraft:blue_terracotta
fill 144 63 351 144 64 351 minecraft:blue_terracotta
setblock 144 63 355 minecraft:dark_prismarine
fill 144 63 356 144 66 356 minecraft:blue_terracotta
setblock 144 63 360 minecraft:dark_prismarine
setblock 146 63 363 minecraft:dark_prismarine
setblock 150 63 363 minecraft:purple_concrete
setblock 155 63 323 minecraft:purple_concrete
fill 159 63 323 160 63 323 minecraft:blue_terracotta
fill 160 63 333 160 64 334 minecraft:dark_prismarine
setblock 160 63 363 minecraft:blue_terracotta
setblock 161 63 323 minecraft:dark_prismarine
setblock 161 63 363 minecraft:dark_prismarine
fill 162 63 323 162 65 324 minecraft:blue_terracotta
setblock 162 63 362 minecraft:dark_prismarine
fill 162 63 363 162 66 363 minecraft:blue_terracotta
fill 163 63 328 163 95 328 minecraft:magenta_terracotta
fill 163 63 362 166 63 362 minecraft:blue_terracotta
setblock 165 63 324 minecraft:dark_prismarine
fill 166 63 322 166 131 322 minecraft:black_concrete
setblock 166 63 323 minecraft:dark_prismarine
fill 166 63 324 167 65 324 minecraft:blue_terracotta
setblock 166 63 363 minecraft:dark_prismarine
fill 167 63 323 167 66 323 minecraft:blue_terracotta
setblock 167 63 362 minecraft:dark_prismarine
fill 167 63 363 167 66 363 minecraft:blue_terracotta
fill 168 63 362 169 65 362 minecraft:blue_terracotta
setblock 171 63 363 minecraft:dark_prismarine
fill 172 63 363 175 63 363 minecraft:blue_terracotta
setblock 174 63 323 minecraft:purple_concrete
fill 175 63 351 175 102 351 minecraft:magenta_terracotta
fill 176 63 352 176 94 352 minecraft:magenta_terracotta
setblock 176 63 363 minecraft:dark_prismarine
setblock 177 63 362 minecraft:dark_prismarine
fill 177 63 363 177 66 363 minecraft:blue_terracotta
fill 178 63 362 178 66 362 minecraft:blue_terracotta
fill 179 63 361 180 65 361 minecraft:blue_terracotta
setblock 180 63 354 minecraft:dark_prismarine
fill 180 63 355 180 66 355 minecraft:blue_terracotta
setblock 180 63 359 minecraft:dark_prismarine
fill 180 63 360 180 66 360 minecraft:blue_terracotta
fill 181 63 335 181 63 337 minecraft:blue_terracotta
setblock 181 63 338 minecraft:dark_prismarine
fill 181 63 350 181 65 350 minecraft:blue_terracotta
setblock 181 63 353 minecraft:dark_prismarine
fill 181 63 354 181 66 354 minecraft:blue_terracotta
setblock 181 63 358 minecraft:dark_prismarine
fill 181 63 359 181 66 359 minecraft:blue_terracotta
setblock 181 63 363 minecraft:dark_prismarine
fill 182 63 323 182 66 323 minecraft:blue_terracotta
setblock 182 63 332 minecraft:dark_prismarine
fill 182 63 333 182 66 333 minecraft:blue_terracotta
setblock 182 63 336 minecraft:blue_terracotta
setblock 182 63 337 minecraft:dark_prismarine
fill 182 63 338 182 63 341 minecraft:blue_terracotta
setblock 182 63 342 minecraft:dark_prismarine
fill 182 63 343 182 63 346 minecraft:blue_terracotta
setblock 182 63 347 minecraft:dark_prismarine
fill 182 63 348 182 66 348 minecraft:blue_terracotta
setblock 182 63 352 minecraft:dark_prismarine
fill 182 63 353 182 66 353 minecraft:blue_terracotta
setblock 182 63 357 minecraft:dark_prismarine
fill 182 63 358 182 66 358 minecraft:blue_terracotta
setblock 182 63 362 minecraft:dark_prismarine
fill 182 63 363 182 66 363 minecraft:blue_terracotta
fill 183 63 325 183 109 325 minecraft:black_concrete
setblock 142 64 331 minecraft:dark_prismarine
fill 142 64 332 142 67 332 minecraft:blue_terracotta
setblock 142 64 336 minecraft:dark_prismarine
fill 142 64 337 142 67 337 minecraft:blue_terracotta
setblock 142 64 340 minecraft:blue_terracotta
setblock 142 64 341 minecraft:dark_prismarine
fill 142 64 342 142 67 342 minecraft:blue_terracotta
setblock 142 64 346 minecraft:dark_prismarine
fill 142 64 347 142 67 347 minecraft:blue_terracotta
setblock 142 64 351 minecraft:dark_prismarine
fill 142 64 352 142 67 352 minecraft:blue_terracotta
setblock 142 64 356 minecraft:dark_prismarine
fill 142 64 357 142 67 357 minecraft:blue_terracotta
setblock 142 64 361 minecraft:dark_prismarine
fill 142 64 362 142 67 362 minecraft:blue_terracotta
setblock 143 64 323 minecraft:purple_concrete
fill 143 64 331 143 67 331 minecraft:blue_terracotta
setblock 143 64 334 minecraft:blue_terracotta
setblock 143 64 335 minecraft:dark_prismarine
fill 143 64 336 143 67 336 minecraft:blue_terracotta
setblock 143 64 340 minecraft:dark_prismarine
fill 143 64 341 143 67 341 minecraft:blue_terracotta
setblock 143 64 345 minecraft:dark_prismarine
fill 143 64 346 143 67 346 minecraft:blue_terracotta
setblock 143 64 350 minecraft:dark_prismarine
fill 143 64 351 143 67 351 minecraft:blue_terracotta
setblock 143 64 355 minecraft:dark_prismarine
fill 143 64 356 143 67 356 minecraft:blue_terracotta
setblock 143 64 359 minecraft:blue_terracotta
setblock 143 64 360 minecraft:dark_prismarine
fill 143 64 361 144 66 361 minecraft:blue_terracotta
setblock 144 64 334 minecraft:dark_prismarine
fill 144 64 335 144 67 335 minecraft:blue_terracotta
setblock 144 64 339 minecraft:dark_prismarine
fill 144 64 340 144 67 340 minecraft:blue_terracotta
setblock 144 64 343 minecraft:blue_terracotta
setblock 144 64 344 minecraft:dark_prismarine
setblock 144 64 354 minecraft:dark_prismarine
fill 144 64 355 144 67 355 minecraft:blue_terracotta
setblock 144 64 359 minecraft:dark_prismarine
fill 144 64 360 144 67 360 minecraft:blue_terracotta
setblock 144 64 363 minecraft:blue_terracotta
fill 145 64 336 145 64 337 minecraft:blue_terracotta
setblock 145 64 338 minecraft:dark_prismarine
fill 145 64 339 145 67 339 minecraft:blue_terracotta
setblock 145 64 363 minecraft:dark_prismarine
fill 146 64 363 147 66 363 minecraft:blue_terracotta
setblock 149 64 323 minecraft:purple_concrete
setblock 156 64 363 minecraft:purple_concrete
fill 158 64 323 159 64 323 minecraft:blue_terracotta
fill 158 64 363 159 64 363 minecraft:blue_terracotta
setblock 160 64 323 minecraft:dark_prismarine
fill 160 64 324 161 66 324 minecraft:blue_terracotta
setblock 160 64 362 minecraft:blue_terracotta
setblock 160 64 363 minecraft:dark_prismarine
fill 161 64 323 161 67 323 minecraft:blue_terracotta
fill 161 64 328 161 73 328 minecraft:magenta_terracotta
setblock 161 64 362 minecraft:dark_prismarine
fill 161 64 363 161 67 363 minecraft:blue_terracotta
setblock 162 64 361 minecraft:dark_prismarine
fill 162 64 362 165 64 362 minecraft:blue_terracotta
fill 163 64 361 166 64 361 minecraft:blue_terracotta
setblock 164 64 323 minecraft:blue_terracotta
setblock 164 64 324 minecraft:dark_prismarine
setblock 165 64 323 minecraft:dark_prismarine
fill 165 64 324 165 67 324 minecraft:blue_terracotta
setblock 165 64 363 minecraft:dark_prismarine
fill 166 64 323 166 67 323 minecraft:blue_terracotta
setblock 166 64 362 minecraft:dark_prismarine
fill 166 64 363 166 67 363 minecraft:blue_terracotta
setblock 167 64 361 minecraft:dark_prismarine
fill 167 64 362 167 67 362 minecraft:blue_terracotta
setblock 170 64 323 minecraft:dark_prismarine
setblock 170 64 362 minecraft:blue_terracotta
setblock 170 64 363 minecraft:dark_prismarine
fill 171 64 322 171 131 322 minecraft:black_concrete
setblock 171 64 362 minecraft:dark_prismarine
fill 171 64 363 174 64 363 minecraft:blue_terracotta
setblock 172 64 322 minecraft:cyan_concrete
fill 172 64 362 175 64 362 minecraft:blue_terracotta
fill 173 64 322 174 97 322 minecraft:black_concrete
setblock 175 64 363 minecraft:dark_prismarine
setblock 176 64 362 minecraft:dark_prismarine
fill 176 64 363 176 67 363 minecraft:blue_terracotta
setblock 177 64 361 minecraft:dark_prismarine
fill 177 64 362 177 67 362 minecraft:blue_terracotta
fill 178 64 361 178 67 361 minecraft:blue_terracotta
setblock 179 64 323 minecraft:blue_terracotta
fill 179 64 357 179 64 358 minecraft:blue_terracotta
setblock 179 64 359 minecraft:dark_prismarine
setblock 180 64 323 minecraft:dark_prismarine
setblock 180 64 353 minecraft:dark_prismarine
fill 180 64 354 180 67 354 minecraft:blue_terracotta
setblock 180 64 357 minecraft:blue_terracotta
setblock 180 64 358 minecraft:dark_prismarine
fill 180 64 359 180 67 359 minecraft:blue_terracotta
setblock 180 64 363 minecraft:dark_prismarine
fill 181 64 323 181 67 323 minecraft:blue_terracotta
fill 181 64 333 181 64 336 minecraft:blue_terracotta
setblock 181 64 337 minecraft:dark_prismarine
fill 181 64 338 181 64 341 minecraft:blue_terracotta
fill 181 64 349 181 66 349 minecraft:blue_terracotta
setblock 181 64 352 minecraft:dark_prismarine
fill 181 64 353 181 67 353 minecraft:blue_terracotta
setblock 181 64 357 minecraft:dark_prismarine
fill 181 64 358 181 67 358 minecraft:blue_terracotta
setblock 181 64 361 minecraft:blue_terracotta
setblock 181 64 362 minecraft:dark_prismarine
fill 181 64 363 181 67 363 minecraft:blue_terracotta
fill 182 64 324 182 65 324 minecraft:blue_terracotta
fill 182 64 329 182 65 329 minecraft:blue_terracotta
setblock 182 64 331 minecraft:dark_prismarine
fill 182 64 332 182 67 332 minecraft:blue_terracotta
setblock 182 64 336 minecraft:dark_prismarine
fill 182 64 337 182 64 340 minecraft:blue_terracotta
setblock 182 64 341 minecraft:dark_prismarine
fill 182 64 342 182 64 345 minecraft:blue_terracotta
setblock 182 64 346 minecraft:dark_prismarine
fill 182 64 347 182 67 347 minecraft:blue_terracotta
setblock 182 64 351 minecraft:dark_prismarine
fill 182 64 352 182 67 352 minecraft:blue_terracotta
setblock 182 64 356 minecraft:dark_prismarine
fill 182 64 357 182 67 357 minecraft:blue_terracotta
setblock 182 64 361 minecraft:dark_prismarine
fill 182 64 362 182 67 362 minecraft:blue_terracotta
fill 142 65 323 142 65 324 minecraft:blue_terracotta
fill 142 65 328 142 66 328 minecraft:blue_terracotta
setblock 142 65 330 minecraft:dark_prismarine
fill 142 65 331 142 68 331 minecraft:blue_terracotta
setblock 142 65 335 minecraft:dark_prismarine
fill 142 65 336 142 68 336 minecraft:blue_terracotta
setblock 142 65 340 minecraft:dark_prismarine
fill 142 65 341 142 68 341 minecraft:blue_terracotta
setblock 142 65 344 minecraft:blue_terracotta
setblock 142 65 345 minecraft:dark_prismarine
fill 142 65 346 142 68 346 minecraft:blue_terracotta
setblock 142 65 350 minecraft:dark_prismarine
fill 142 65 351 142 68 351 minecraft:blue_terracotta
setblock 142 65 355 minecraft:dark_prismarine
fill 142 65 356 142 68 356 minecraft:blue_terracotta
setblock 142 65 360 minecraft:dark_prismarine
fill 142 65 361 142 68 361 minecraft:blue_terracotta
setblock 143 65 323 minecraft:blue_terracotta
setblock 143 65 334 minecraft:dark_prismarine
fill 143 65 335 143 68 335 minecraft:blue_terracotta
setblock 143 65 338 minecraft:blue_terracotta
setblock 143 65 339 minecraft:dark_prismarine
fill 143 65 340 143 68 340 minecraft:blue_terracotta
setblock 143 65 344 minecraft:dark_prismarine
fill 143 65 345 144 67 345 minecraft:blue_terracotta
setblock 143 65 349 minecraft:dark_prismarine
fill 143 65 350 143 68 350 minecraft:blue_terracotta
setblock 143 65 354 minecraft:dark_prismarine
fill 143 65 355 143 68 355 minecraft:blue_terracotta
setblock 143 65 359 minecraft:dark_prismarine
fill 143 65 360 143 68 360 minecraft:blue_terracotta
fill 143 65 362 144 65 362 minecraft:blue_terracotta
setblock 144 65 323 minecraft:dark_prismarine
setblock 144 65 325 minecraft:light[level=12]
setblock 144 65 332 minecraft:light[level=12]
setblock 144 65 333 minecraft:dark_prismarine
fill 144 65 334 144 68 334 minecraft:blue_terracotta
setblock 144 65 338 minecraft:dark_prismarine
fill 144 65 339 144 68 339 minecraft:blue_terracotta
setblock 144 65 343 minecraft:dark_prismarine
fill 144 65 344 144 68 344 minecraft:blue_terracotta
fill 144 65 346 144 66 346 minecraft:blue_terracotta
setblock 144 65 353 minecraft:dark_prismarine
fill 144 65 354 144 66 354 minecraft:blue_terracotta
setblock 144 65 358 minecraft:dark_prismarine
fill 144 65 359 144 68 359 minecraft:blue_terracotta
setblock 144 65 363 minecraft:dark_prismarine
setblock 145 65 336 minecraft:blue_terracotta
setblock 145 65 337 minecraft:dark_prismarine
fill 145 65 338 145 68 338 minecraft:blue_terracotta
fill 145 65 340 145 65 341 minecraft:blue_terracotta
setblock 145 65 362 minecraft:dark_prismarine
fill 145 65 363 145 68 363 minecraft:blue_terracotta
fill 146 65 362 146 68 362 minecraft:blue_terracotta
setblock 148 65 363 minecraft:blue_terracotta
setblock 151 65 325 minecraft:light[level=12]
setblock 151 65 332 minecraft:light[level=12]
setblock 151 65 339 minecraft:light[level=12]
setblock 151 65 346 minecraft:light[level=12]
setblock 151 65 353 minecraft:light[level=12]
setblock 151 65 360 minecraft:light[level=12]
fill 156 65 323 158 65 323 minecraft:blue_terracotta
fill 157 65 363 158 65 363 minecraft:blue_terracotta
setblock 158 65 325 minecraft:light[level=12]
setblock 158 65 332 minecraft:light[level=12]
setblock 158 65 339 minecraft:light[level=12]
setblock 158 65 346 minecraft:light[level=12]
setblock 158 65 353 minecraft:light[level=12]
setblock 158 65 360 minecraft:light[level=12]
fill 158 65 362 159 65 362 minecraft:blue_terracotta
setblock 159 65 323 minecraft:dark_prismarine
fill 159 65 324 159 68 324 minecraft:blue_terracotta
setblock 159 65 363 minecraft:dark_prismarine
fill 160 65 323 160 68 323 minecraft:blue_terracotta
setblock 160 65 362 minecraft:dark_prismarine
fill 160 65 363 160 68 363 minecraft:blue_terracotta
setblock 161 65 361 minecraft:dark_prismarine
fill 161 65 362 164 65 362 minecraft:blue_terracotta
setblock 162 65 325 minecraft:dark_prismarine
fill 162 65 361 165 65 361 minecraft:blue_terracotta
setblock 163 65 323 minecraft:blue_terracotta
setblock 163 65 324 minecraft:dark_prismarine
fill 163 65 325 163 68 325 minecraft:blue_terracotta
setblock 164 65 323 minecraft:dark_prismarine
fill 164 65 324 164 68 324 minecraft:blue_terracotta
setblock 164 65 363 minecraft:dark_prismarine
fill 165 65 323 165 68 323 minecraft:blue_terracotta
setblock 165 65 325 minecraft:light[level=12]
setblock 165 65 332 minecraft:light[level=12]
setblock 165 65 339 minecraft:light[level=12]
setblock 165 65 346 minecraft:light[level=12]
setblock 165 65 353 minecraft:light[level=12]
setblock 165 65 360 minecraft:light[level=12]
setblock 165 65 362 minecraft:dark_prismarine
fill 165 65 363 165 68 363 minecraft:blue_terracotta
setblock 166 65 361 minecraft:dark_prismarine
fill 166 65 362 166 68 362 minecraft:blue_terracotta
fill 167 65 361 168 67 361 minecraft:blue_terracotta
setblock 169 65 323 minecraft:dark_prismarine
setblock 169 65 363 minecraft:dark_prismarine
fill 170 65 323 171 67 323 minecraft:blue_terracotta
setblock 170 65 362 minecraft:dark_prismarine
fill 170 65 363 173 65 363 minecraft:blue_terracotta
fill 171 65 362 174 65 362 minecraft:blue_terracotta
fill 172 65 322 172 131 322 minecraft:black_concrete
setblock 172 65 325 minecraft:light[level=12]
setblock 172 65 332 minecraft:light[level=12]
setblock 172 65 339 minecraft:light[level=12]
setblock 172 65 346 minecraft:light[level=12]
setblock 172 65 353 minecraft:light[level=12]
setblock 172 65 360 minecraft:light[level=12]
setblock 174 65 363 minecraft:dark_prismarine
setblock 175 65 361 minecraft:blue_terracotta
setblock 175 65 362 minecraft:dark_prismarine
fill 175 65 363 175 68 363 minecraft:blue_terracotta
setblock 176 65 361 minecraft:dark_prismarine
fill 176 65 362 176 68 362 minecraft:blue_terracotta
fill 177 65 323 178 65 323 minecraft:blue_terracotta
fill 177 65 361 177 68 361 minecraft:blue_terracotta
fill 178 65 360 179 67 360 minecraft:blue_terracotta
setblock 179 65 323 minecraft:dark_prismarine
setblock 179 65 325 minecraft:light[level=12]
setblock 179 65 332 minecraft:light[level=12]
setblock 179 65 339 minecraft:light[level=12]
setblock 179 65 346 minecraft:light[level=12]
setblock 179 65 353 minecraft:light[level=12]
fill 179 65 356 179 65 357 minecraft:blue_terracotta
setblock 179 65 358 minecraft:dark_prismarine
fill 179 65 359 179 68 359 minecraft:blue_terracotta
setblock 179 65 362 minecraft:blue_terracotta
setblock 179 65 363 minecraft:dark_prismarine
fill 180 65 323 180 68 323 minecraft:blue_terracotta
setblock 180 65 352 minecraft:dark_prismarine
fill 180 65 353 180 68 353 minecraft:blue_terracotta
setblock 180 65 357 minecraft:dark_prismarine
fill 180 65 358 180 68 358 minecraft:blue_terracotta
setblock 180 65 362 minecraft:dark_prismarine
fill 180 65 363 180 68 363 minecraft:blue_terracotta
fill 181 65 333 181 65 335 minecraft:blue_terracotta
setblock 181 65 336 minecraft:dark_prismarine
fill 181 65 337 181 65 340 minecraft:blue_terracotta
setblock 181 65 341 minecraft:dark_prismarine
fill 181 65 342 181 65 345 minecraft:blue_terracotta
setblock 181 65 346 minecraft:dark_prismarine
fill 181 65 347 181 67 348 minecraft:blue_terracotta
setblock 181 65 351 minecraft:dark_prismarine
fill 181 65 352 181 68 352 minecraft:blue_terracotta
setblock 181 65 356 minecraft:dark_prismarine
fill 181 65 357 181 68 357 minecraft:blue_terracotta
setblock 181 65 361 minecraft:dark_prismarine
fill 181 65 362 181 68 362 minecraft:blue_terracotta
setblock 182 65 325 minecraft:dark_prismarine
fill 182 65 326 182 68 326 minecraft:blue_terracotta
fill 182 65 328 182 66 328 minecraft:blue_terracotta
setblock 182 65 330 minecraft:dark_prismarine
fill 182 65 331 182 68 331 minecraft:blue_terracotta
setblock 182 65 335 minecraft:dark_prismarine
fill 182 65 336 182 65 339 minecraft:blue_terracotta
setblock 182 65 340 minecraft:dark_prismarine
fill 182 65 341 182 65 344 minecraft:blue_terracotta
setblock 182 65 345 minecraft:dark_prismarine
fill 182 65 346 182 68 346 minecraft:blue_terracotta
setblock 182 65 350 minecraft:dark_prismarine
fill 182 65 351 182 68 351 minecraft:blue_terracotta
setblock 182 65 355 minecraft:dark_prismarine
fill 182 65 356 182 68 356 minecraft:blue_terracotta
setblock 182 65 360 minecraft:dark_prismarine
fill 182 65 361 182 68 361 minecraft:blue_terracotta
setblock 183 65 327 minecraft:light_blue_wool
setblock 142 66 323 minecraft:blue_terracotta
setblock 142 66 324 minecraft:dark_prismarine
fill 142 66 325 142 67 327 minecraft:blue_terracotta
setblock 142 66 329 minecraft:dark_prismarine
fill 142 66 330 142 69 330 minecraft:blue_terracotta
setblock 142 66 334 minecraft:dark_prismarine
fill 142 66 335 142 69 335 minecraft:blue_terracotta
setblock 142 66 339 minecraft:dark_prismarine
fill 142 66 340 142 69 340 minecraft:blue_terracotta
setblock 142 66 344 minecraft:dark_prismarine
fill 142 66 345 142 69 345 minecraft:blue_terracotta
setblock 142 66 349 minecraft:dark_prismarine
fill 142 66 350 142 69 350 minecraft:blue_terracotta
setblock 142 66 354 minecraft:dark_prismarine
fill 142 66 355 142 69 355 minecraft:blue_terracotta
setblock 142 66 359 minecraft:dark_prismarine
fill 142 66 360 142 69 360 minecraft:blue_terracotta
setblock 143 66 323 minecraft:dark_prismarine
setblock 143 66 333 minecraft:dark_prismarine
fill 143 66 334 143 69 334 minecraft:blue_terracotta
setblock 143 66 338 minecraft:dark_prismarine
fill 143 66 339 143 69 339 minecraft:blue_terracotta
setblock 143 66 342 minecraft:blue_terracotta
setblock 143 66 343 minecraft:dark_prismarine
fill 143 66 344 143 69 344 minecraft:blue_terracotta
setblock 143 66 348 minecraft:dark_prismarine
fill 143 66 349 143 69 349 minecraft:blue_terracotta
setblock 143 66 353 minecraft:dark_prismarine
fill 143 66 354 143 69 354 minecraft:blue_terracotta
setblock 143 66 358 minecraft:dark_prismarine
fill 143 66 359 143 69 359 minecraft:blue_terracotta
setblock 143 66 362 minecraft:blue_terracotta
setblock 143 66 363 minecraft:dark_prismarine
fill 144 66 323 146 67 323 minecraft:blue_terracotta
fill 144 66 333 144 67 333 minecraft:blue_terracotta
setblock 144 66 337 minecraft:dark_prismarine
fill 144 66 338 144 69 338 minecraft:blue_terracotta
setblock 144 66 342 minecraft:dark_prismarine
fill 144 66 343 144 69 343 minecraft:blue_terracotta
setblock 144 66 353 minecraft:blue_terracotta
setblock 144 66 357 minecraft:dark_prismarine
fill 144 66 358 144 68 358 minecraft:blue_terracotta
setblock 144 66 362 minecraft:dark_prismarine
fill 144 66 363 144 69 363 minecraft:blue_terracotta
setblock 145 66 336 minecraft:dark_prismarine
fill 145 66 337 145 68 337 minecraft:blue_terracotta
setblock 145 66 340 minecraft:blue_terracotta
setblock 145 66 341 minecraft:dark_prismarine
fill 145 66 342 145 69 342 minecraft:blue_terracotta
fill 145 66 362 145 69 362 minecraft:blue_terracotta
setblock 148 66 363 minecraft:dark_prismarine
fill 155 66 323 157 66 323 minecraft:blue_terracotta
fill 155 66 363 157 66 363 minecraft:blue_terracotta
fill 157 66 362 158 66 362 minecraft:blue_terracotta
setblock 158 66 323 minecraft:dark_prismarine
fill 158 66 324 158 69 324 minecraft:blue_terracotta
setblock 158 66 363 minecraft:dark_prismarine
fill 159 66 323 159 69 323 minecraft:blue_terracotta
setblock 159 66 361 minecraft:blue_terracotta
setblock 159 66 362 minecraft:dark_prismarine
fill 159 66 363 159 69 363 minecraft:blue_terracotta
setblock 160 66 325 minecraft:blue_terracotta
setblock 160 66 361 minecraft:dark_prismarine
fill 160 66 362 163 66 362 minecraft:blue_terracotta
setblock 161 66 325 minecraft:dark_prismarine
fill 161 66 361 164 66 361 minecraft:blue_terracotta
setblock 162 66 323 minecraft:blue_terracotta
setblock 162 66 324 minecraft:dark_prismarine
fill 162 66 325 162 69 325 minecraft:blue_terracotta
setblock 163 66 323 minecraft:dark_prismarine
fill 163 66 324 163 69 324 minecraft:blue_terracotta
fill 163 66 331 163 102 331 minecraft:magenta_terracotta
setblock 163 66 363 minecraft:dark_prismarine
fill 164 66 323 164 69 323 minecraft:blue_terracotta
fill 164 66 325 164 67 325 minecraft:blue_terracotta
setblock 164 66 362 minecraft:dark_prismarine
fill 164 66 363 164 69 363 minecraft:blue_terracotta
setblock 165 66 361 minecraft:dark_prismarine
fill 165 66 362 165 69 362 minecraft:blue_terracotta
setblock 166 66 324 minecraft:blue_terracotta
fill 166 66 361 166 69 361 minecraft:blue_terracotta
setblock 167 66 324 minecraft:dark_prismarine
setblock 168 66 323 minecraft:dark_prismarine
fill 168 66 324 168 68 324 minecraft:blue_terracotta
setblock 168 66 362 minecraft:blue_terracotta
setblock 168 66 363 minecraft:dark_prismarine
fill 169 66 323 169 69 323 minecraft:blue_terracotta
setblock 169 66 361 minecraft:blue_terracotta
setblock 169 66 362 minecraft:dark_prismarine
fill 169 66 363 172 66 363 minecraft:blue_terracotta
setblock 170 66 361 minecraft:dark_prismarine
fill 170 66 362 173 66 362 minecraft:blue_terracotta
setblock 172 66 323 minecraft:blue_terracotta
setblock 173 66 323 minecraft:dark_prismarine
fill 173 66 361 174 66 361 minecraft:blue_terracotta
setblock 173 66 363 minecraft:dark_prismarine
fill 174 66 323 177 66 323 minecraft:blue_terracotta
setblock 174 66 362 minecraft:dark_prismarine
fill 174 66 363 174 69 363 minecraft:blue_terracotta
fill 175 66 330 175 83 330 minecraft:green_terracotta
fill 175 66 349 175 102 349 minecraft:magenta_terracotta
setblock 175 66 361 minecraft:dark_prismarine
fill 175 66 362 175 69 362 minecraft:blue_terracotta
fill 176 66 361 176 69 361 minecraft:blue_terracotta
fill 177 66 360 177 69 360 minecraft:blue_terracotta
setblock 178 66 323 minecraft:dark_prismarine
setblock 178 66 363 minecraft:dark_prismarine
fill 179 66 323 179 69 323 minecraft:blue_terracotta
setblock 179 66 356 minecraft:blue_terracotta
setblock 179 66 357 minecraft:dark_prismarine
fill 179 66 358 179 69 358 minecraft:blue_terracotta
setblock 179 66 361 minecraft:blue_terracotta
setblock 179 66 362 minecraft:dark_prismarine
fill 179 66 363 179 69 363 minecraft:blue_terracotta
fill 180 66 337 180 66 340 minecraft:blue_terracotta
setblock 180 66 341 minecraft:dark_prismarine
fill 180 66 352 180 69 352 minecraft:blue_terracotta
setblock 180 66 356 minecraft:dark_prismarine
fill 180 66 357 180 69 357 minecraft:blue_terracotta
setblock 180 66 361 minecraft:dark_prismarine
fill 180 66 362 180 69 362 minecraft:blue_terracotta
fill 181 66 333 181 66 334 minecraft:blue_terracotta
setblock 181 66 335 minecraft:dark_prismarine
fill 181 66 336 181 66 339 minecraft:blue_terracotta
setblock 181 66 340 minecraft:dark_prismarine
fill 181 66 341 181 66 344 minecraft:blue_terracotta
setblock 181 66 345 minecraft:dark_prismarine
fill 181 66 346 181 69 346 minecraft:blue_terracotta
setblock 181 66 350 minecraft:dark_prismarine
fill 181 66 351 181 69 351 minecraft:blue_terracotta
setblock 181 66 355 minecraft:dark_prismarine
fill 181 66 356 181 69 356 minecraft:blue_terracotta
setblock 181 66 360 minecraft:dark_prismarine
fill 181 66 361 181 69 361 minecraft:blue_terracotta
setblock 182 66 324 minecraft:dark_prismarine
fill 182 66 325 182 69 325 minecraft:blue_terracotta
fill 182 66 327 182 67 327 minecraft:blue_terracotta
setblock 182 66 329 minecraft:dark_prismarine
fill 182 66 330 182 68 330 minecraft:blue_terracotta
setblock 182 66 334 minecraft:dark_prismarine
fill 182 66 335 182 66 338 minecraft:blue_terracotta
setblock 182 66 339 minecraft:dark_prismarine
fill 182 66 340 182 66 343 minecraft:blue_terracotta
setblock 182 66 344 minecraft:dark_prismarine
fill 182 66 345 182 69 345 minecraft:blue_terracotta
setblock 182 66 349 minecraft:dark_prismarine
fill 182 66 350 182 69 350 minecraft:blue_terracotta
setblock 182 66 354 minecraft:dark_prismarine
fill 182 66 355 182 69 355 minecraft:blue_terracotta
setblock 182 66 359 minecraft:dark_prismarine
fill 182 66 360 182 69 360 minecraft:blue_terracotta
fill 183 66 327 183 82 327 minecraft:black_concrete
setblock 142 67 323 minecraft:dark_prismarine
fill 142 67 324 142 70 324 minecraft:blue_terracotta
setblock 142 67 328 minecraft:dark_prismarine
fill 142 67 329 142 70 329 minecraft:blue_terracotta
setblock 142 67 333 minecraft:dark_prismarine
fill 142 67 334 142 70 334 minecraft:blue_terracotta
setblock 142 67 338 minecraft:dark_prismarine
fill 142 67 339 142 70 339 minecraft:blue_terracotta
setblock 142 67 343 minecraft:dark_prismarine
fill 142 67 344 142 70 344 minecraft:blue_terracotta
setblock 142 67 348 minecraft:dark_prismarine
fill 142 67 349 142 70 349 minecraft:blue_terracotta
setblock 142 67 353 minecraft:dark_prismarine
fill 142 67 354 142 70 354 minecraft:blue_terracotta
setblock 142 67 358 minecraft:dark_prismarine
fill 142 67 359 142 70 359 minecraft:blue_terracotta
setblock 142 67 363 minecraft:dark_prismarine
fill 143 67 323 143 70 323 minecraft:blue_terracotta
setblock 143 67 332 minecraft:dark_prismarine
fill 143 67 333 143 70 333 minecraft:blue_terracotta
setblock 143 67 337 minecraft:dark_prismarine
fill 143 67 338 143 70 338 minecraft:blue_terracotta
setblock 143 67 342 minecraft:dark_prismarine
fill 143 67 343 143 70 343 minecraft:blue_terracotta
setblock 143 67 347 minecraft:dark_prismarine
fill 143 67 348 143 70 348 minecraft:blue_terracotta
setblock 143 67 352 minecraft:dark_prismarine
fill 143 67 353 143 69 353 minecraft:blue_terracotta
setblock 143 67 357 minecraft:dark_prismarine
fill 143 67 358 143 70 358 minecraft:blue_terracotta
setblock 143 67 361 minecraft:blue_terracotta
setblock 143 67 362 minecraft:dark_prismarine
fill 143 67 363 143 70 363 minecraft:blue_terracotta
setblock 144 67 336 minecraft:dark_prismarine
fill 144 67 337 144 70 337 minecraft:blue_terracotta
setblock 144 67 341 minecraft:dark_prismarine
fill 144 67 342 144 70 342 minecraft:blue_terracotta
setblock 144 67 346 minecraft:dark_prismarine
setblock 144 67 347 minecraft:blue_terracotta
setblock 144 67 356 minecraft:dark_prismarine
setblock 144 67 357 minecraft:blue_terracotta
setblock 144 67 361 minecraft:dark_prismarine
fill 144 67 362 144 70 362 minecraft:blue_terracotta
setblock 145 67 336 minecraft:blue_terracotta
setblock 145 67 340 minecraft:dark_prismarine
fill 145 67 341 145 69 341 minecraft:blue_terracotta
setblock 146 67 363 minecraft:blue_terracotta
setblock 147 67 363 minecraft:dark_prismarine
fill 148 67 348 148 102 348 minecraft:magenta_terracotta
fill 148 67 363 148 69 363 minecraft:blue_terracotta
setblock 149 67 363 minecraft:purple_concrete
setblock 150 67 323 minecraft:purple_concrete
fill 153 67 323 156 67 323 minecraft:blue_terracotta
fill 154 67 363 156 67 363 minecraft:blue_terracotta
setblock 156 67 324 minecraft:dark_prismarine
fill 156 67 362 157 67 362 minecraft:blue_terracotta
setblock 157 67 323 minecraft:dark_prismarine
fill 157 67 324 157 70 324 minecraft:blue_terracotta
setblock 157 67 363 minecraft:dark_prismarine
fill 158 67 323 158 70 323 minecraft:blue_terracotta
setblock 158 67 361 minecraft:blue_terracotta
setblock 158 67 362 minecraft:dark_prismarine
fill 158 67 363 158 70 363 minecraft:blue_terracotta
setblock 159 67 325 minecraft:blue_terracotta
setblock 159 67 361 minecraft:dark_prismarine
fill 159 67 362 162 67 362 minecraft:blue_terracotta
setblock 160 67 324 minecraft:blue_terracotta
setblock 160 67 325 minecraft:dark_prismarine
fill 160 67 356 160 84 357 minecraft:magenta_terracotta
fill 160 67 361 163 67 361 minecraft:blue_terracotta
setblock 161 67 324 minecraft:dark_prismarine
fill 161 67 325 161 70 325 minecraft:blue_terracotta
setblock 162 67 323 minecraft:dark_prismarine
fill 162 67 324 162 70 324 minecraft:blue_terracotta
fill 162 67 360 164 67 360 minecraft:blue_terracotta
setblock 162 67 363 minecraft:dark_prismarine
fill 163 67 323 163 70 323 minecraft:blue_terracotta
setblock 163 67 362 minecraft:dark_prismarine
fill 163 67 363 163 70 363 minecraft:blue_terracotta
setblock 164 67 361 minecraft:dark_prismarine
fill 164 67 362 164 70 362 minecraft:blue_terracotta
fill 165 67 361 165 70 361 minecraft:blue_terracotta
setblock 166 67 324 minecraft:dark_prismarine
setblock 167 67 323 minecraft:dark_prismarine
fill 167 67 324 167 70 324 minecraft:blue_terracotta
setblock 167 67 363 minecraft:dark_prismarine
fill 168 67 323 168 70 323 minecraft:blue_terracotta
setblock 168 67 362 minecraft:dark_prismarine
fill 168 67 363 171 67 363 minecraft:blue_terracotta
setblock 169 67 361 minecraft:dark_prismarine
fill 169 67 362 172 67 362 minecraft:blue_terracotta
fill 170 67 361 173 67 361 minecraft:blue_terracotta
setblock 172 67 323 minecraft:dark_prismarine
setblock 172 67 363 minecraft:dark_prismarine
fill 173 67 323 176 67 323 minecraft:blue_terracotta
setblock 173 67 362 minecraft:dark_prismarine
fill 173 67 363 173 70 363 minecraft:blue_terracotta
setblock 174 67 361 minecraft:dark_prismarine
fill 174 67 362 174 70 362 minecraft:blue_terracotta
fill 175 67 361 175 70 361 minecraft:blue_terracotta
fill 176 67 360 176 70 360 minecraft:blue_terracotta
setblock 177 67 323 minecraft:dark_prismarine
setblock 177 67 363 minecraft:dark_prismarine
fill 178 67 323 178 70 323 minecraft:blue_terracotta
setblock 178 67 362 minecraft:dark_prismarine
fill 178 67 363 178 70 363 minecraft:blue_terracotta
setblock 179 67 356 minecraft:dark_prismarine
fill 179 67 357 179 69 357 minecraft:blue_terracotta
setblock 179 67 361 minecraft:dark_prismarine
fill 179 67 362 179 70 362 minecraft:blue_terracotta
fill 180 67 337 180 67 339 minecraft:blue_terracotta
setblock 180 67 340 minecraft:dark_prismarine
fill 180 67 341 180 67 344 minecraft:blue_terracotta
setblock 180 67 355 minecraft:dark_prismarine
fill 180 67 356 180 70 356 minecraft:blue_terracotta
setblock 180 67 360 minecraft:dark_prismarine
fill 180 67 361 180 70 361 minecraft:blue_terracotta
setblock 181 67 324 minecraft:dark_prismarine
setblock 181 67 333 minecraft:blue_terracotta
setblock 181 67 334 minecraft:dark_prismarine
fill 181 67 335 181 67 338 minecraft:blue_terracotta
setblock 181 67 339 minecraft:dark_prismarine
fill 181 67 340 181 67 343 minecraft:blue_terracotta
setblock 181 67 344 minecraft:dark_prismarine
fill 181 67 345 181 70 345 minecraft:blue_terracotta
setblock 181 67 349 minecraft:dark_prismarine
fill 181 67 350 181 70 350 minecraft:blue_terracotta
setblock 181 67 354 minecraft:dark_prismarine
fill 181 67 355 181 70 355 minecraft:blue_terracotta
setblock 181 67 359 minecraft:dark_prismarine
fill 181 67 360 181 70 360 minecraft:blue_terracotta
setblock 182 67 323 minecraft:dark_prismarine
fill 182 67 324 182 70 324 minecraft:blue_terracotta
setblock 182 67 328 minecraft:dark_prismarine
fill 182 67 329 182 68 329 minecraft:blue_terracotta
setblock 182 67 333 minecraft:dark_prismarine
fill 182 67 334 182 67 337 minecraft:blue_terracotta
setblock 182 67 338 minecraft:dark_prismarine
fill 182 67 339 182 67 342 minecraft:blue_terracotta
setblock 182 67 343 minecraft:dark_prismarine
fill 182 67 344 182 70 344 minecraft:blue_terracotta
setblock 182 67 348 minecraft:dark_prismarine
fill 182 67 349 182 70 349 minecraft:blue_terracotta
setblock 182 67 353 minecraft:dark_prismarine
fill 182 67 354 182 70 354 minecraft:blue_terracotta
setblock 182 67 358 minecraft:dark_prismarine
fill 182 67 359 182 70 359 minecraft:blue_terracotta
setblock 182 67 363 minecraft:dark_prismarine
fill 141 68 326 141 91 327 minecraft:black_concrete
setblock 141 68 328 minecraft:cyan_concrete
fill 142 68 323 142 71 323 minecraft:blue_terracotta
fill 142 68 325 142 68 326 minecraft:blue_terracotta
setblock 142 68 327 minecraft:dark_prismarine
fill 142 68 328 142 71 328 minecraft:blue_terracotta
setblock 142 68 332 minecraft:dark_prismarine
fill 142 68 333 142 71 333 minecraft:blue_terracotta
setblock 142 68 337 minecraft:dark_prismarine
fill 142 68 338 142 71 338 minecraft:blue_terracotta
setblock 142 68 342 minecraft:dark_prismarine
fill 142 68 343 142 71 343 minecraft:blue_terracotta
setblock 142 68 347 minecraft:dark_prismarine
fill 142 68 348 142 71 348 minecraft:blue_terracotta
setblock 142 68 352 minecraft:dark_prismarine
fill 142 68 353 142 71 353 minecraft:blue_terracotta
setblock 142 68 357 minecraft:dark_prismarine
fill 142 68 358 142 71 358 minecraft:blue_terracotta
setblock 142 68 362 minecraft:dark_prismarine
fill 142 68 363 142 71 363 minecraft:blue_terracotta
setblock 143 68 331 minecraft:dark_prismarine
fill 143 68 332 143 69 332 minecraft:blue_terracotta
setblock 143 68 336 minecraft:dark_prismarine
fill 143 68 337 143 71 337 minecraft:blue_terracotta
setblock 143 68 341 minecraft:dark_prismarine
fill 143 68 342 143 71 342 minecraft:blue_terracotta
setblock 143 68 345 minecraft:blue_terracotta
setblock 143 68 346 minecraft:dark_prismarine
fill 143 68 347 143 71 347 minecraft:blue_terracotta
setblock 143 68 351 minecraft:dark_prismarine
fill 143 68 352 143 69 352 minecraft:blue_terracotta
setblock 143 68 356 minecraft:dark_prismarine
fill 143 68 357 143 70 357 minecraft:blue_terracotta
setblock 143 68 361 minecraft:dark_prismarine
fill 143 68 362 143 71 362 minecraft:blue_terracotta
fill 144 68 323 145 68 323 minecraft:blue_terracotta
setblock 144 68 335 minecraft:dark_prismarine
fill 144 68 336 144 70 336 minecraft:blue_terracotta
setblock 144 68 340 minecraft:dark_prismarine
fill 144 68 341 144 71 341 minecraft:blue_terracotta
setblock 144 68 345 minecraft:dark_prismarine
fill 144 68 346 144 70 346 minecraft:blue_terracotta
setblock 144 68 360 minecraft:dark_prismarine
setblock 144 68 361 minecraft:blue_terracotta
setblock 145 68 339 minecraft:dark_prismarine
fill 145 68 340 145 69 340 minecraft:blue_terracotta
fill 145 68 353 147 69 353 minecraft:dark_prismarine
setblock 146 68 323 minecraft:dark_prismarine
fill 146 68 352 147 69 352 minecraft:dark_prismarine
setblock 146 68 363 minecraft:dark_prismarine
fill 147 68 323 147 70 323 minecraft:blue_terracotta
fill 147 68 334 148 86 334 minecraft:magenta_terracotta
fill 147 68 363 147 70 363 minecraft:blue_terracotta
setblock 149 68 363 minecraft:blue_terracotta
fill 152 68 323 155 68 323 minecraft:blue_terracotta
fill 152 68 363 155 68 363 minecraft:blue_terracotta
setblock 155 68 324 minecraft:dark_prismarine
fill 155 68 362 156 68 362 minecraft:blue_terracotta
setblock 156 68 323 minecraft:dark_prismarine
fill 156 68 324 156 71 324 minecraft:blue_terracotta
setblock 156 68 363 minecraft:dark_prismarine
fill 157 68 323 157 71 323 minecraft:blue_terracotta
setblock 157 68 362 minecraft:dark_prismarine
fill 157 68 363 157 71 363 minecraft:blue_terracotta
setblock 158 68 325 minecraft:blue_terracotta
setblock 158 68 361 minecraft:dark_prismarine
fill 158 68 362 161 68 362 minecraft:blue_terracotta
setblock 159 68 325 minecraft:dark_prismarine
fill 159 68 361 162 68 361 minecraft:blue_terracotta
setblock 160 68 324 minecraft:dark_prismarine
fill 160 68 325 160 71 325 minecraft:blue_terracotta
setblock 161 68 323 minecraft:dark_prismarine
fill 161 68 324 161 71 324 minecraft:blue_terracotta
setblock 161 68 363 minecraft:dark_prismarine
fill 162 68 323 162 71 323 minecraft:blue_terracotta
fill 162 68 360 163 68 360 minecraft:blue_terracotta
setblock 162 68 362 minecraft:dark_prismarine
fill 162 68 363 162 71 363 minecraft:blue_terracotta
setblock 163 68 361 minecraft:dark_prismarine
fill 163 68 362 163 71 362 minecraft:blue_terracotta
setblock 164 68 325 minecraft:dark_prismarine
fill 164 68 361 164 71 361 minecraft:blue_terracotta
setblock 165 68 324 minecraft:dark_prismarine
setblock 166 68 323 minecraft:dark_prismarine
fill 166 68 324 166 71 324 minecraft:blue_terracotta
setblock 166 68 363 minecraft:dark_prismarine
fill 167 68 323 167 71 323 minecraft:blue_terracotta
setblock 167 68 361 minecraft:blue_terracotta
setblock 167 68 362 minecraft:dark_prismarine
fill 167 68 363 170 68 363 minecraft:blue_terracotta
setblock 168 68 361 minecraft:dark_prismarine
fill 168 68 362 171 68 362 minecraft:blue_terracotta
fill 169 68 361 172 68 361 minecraft:blue_terracotta
setblock 170 68 323 minecraft:blue_terracotta
setblock 171 68 323 minecraft:dark_prismarine
setblock 171 68 363 minecraft:dark_prismarine
fill 172 68 323 175 68 323 minecraft:blue_terracotta
setblock 172 68 362 minecraft:dark_prismarine
fill 172 68 363 172 71 363 minecraft:blue_terracotta
setblock 173 68 361 minecraft:dark_prismarine
fill 173 68 362 173 71 362 minecraft:blue_terracotta
fill 174 68 361 174 71 361 minecraft:blue_terracotta
setblock 176 68 323 minecraft:dark_prismarine
setblock 176 68 363 minecraft:dark_prismarine
fill 177 68 323 177 71 323 minecraft:blue_terracotta
fill 177 68 339 177 69 339 minecraft:magenta_terracotta
setblock 177 68 362 minecraft:dark_prismarine
fill 177 68 363 177 71 363 minecraft:blue_terracotta
fill 178 68 324 179 68 324 minecraft:blue_terracotta
setblock 178 68 360 minecraft:blue_terracotta
setblock 178 68 361 minecraft:dark_prismarine
fill 178 68 362 178 71 362 minecraft:blue_terracotta
setblock 179 68 356 minecraft:blue_terracotta
setblock 179 68 360 minecraft:dark_prismarine
fill 179 68 361 179 71 361 minecraft:blue_terracotta
setblock 180 68 324 minecraft:dark_prismarine
fill 180 68 337 180 68 338 minecraft:blue_terracotta
setblock 180 68 339 minecraft:dark_prismarine
fill 180 68 340 180 68 343 minecraft:blue_terracotta
setblock 180 68 344 minecraft:dark_prismarine
fill 180 68 345 180 70 346 minecraft:blue_terracotta
setblock 180 68 351 minecraft:blue_terracotta
setblock 180 68 354 minecraft:dark_prismarine
fill 180 68 355 180 70 355 minecraft:blue_terracotta
setblock 180 68 359 minecraft:dark_prismarine
fill 180 68 360 180 71 360 minecraft:blue_terracotta
setblock 181 68 323 minecraft:dark_prismarine
fill 181 68 324 181 71 324 minecraft:blue_terracotta
fill 181 68 334 181 68 337 minecraft:blue_terracotta
setblock 181 68 338 minecraft:dark_prismarine
fill 181 68 339 181 68 342 minecraft:blue_terracotta
setblock 181 68 343 minecraft:dark_prismarine
fill 181 68 344 181 71 344 minecraft:blue_terracotta
setblock 181 68 347 minecraft:blue_terracotta
setblock 181 68 348 minecraft:dark_prismarine
fill 181 68 349 181 71 349 minecraft:blue_terracotta
setblock 181 68 353 minecraft:dark_prismarine
fill 181 68 354 181 71 354 minecraft:blue_terracotta
setblock 181 68 358 minecraft:dark_prismarine
fill 181 68 359 181 71 359 minecraft:blue_terracotta
setblock 181 68 363 minecraft:dark_prismarine
fill 182 68 323 182 71 323 minecraft:blue_terracotta
setblock 182 68 327 minecraft:dark_prismarine
setblock 182 68 328 minecraft:blue_terracotta
setblock 182 68 332 minecraft:dark_prismarine
fill 182 68 333 182 68 336 minecraft:blue_terracotta
setblock 182 68 337 minecraft:dark_prismarine
fill 182 68 338 182 68 341 minecraft:blue_terracotta
setblock 182 68 342 minecraft:dark_prismarine
fill 182 68 343 182 71 343 minecraft:blue_terracotta
setblock 182 68 347 minecraft:dark_prismarine
fill 182 68 348 182 71 348 minecraft:blue_terracotta
setblock 182 68 352 minecraft:dark_prismarine
fill 182 68 353 182 71 353 minecraft:blue_terracotta
setblock 182 68 357 minecraft:dark_prismarine
fill 182 68 358 182 71 358 minecraft:blue_terracotta
setblock 182 68 362 minecraft:dark_prismarine
fill 182 68 363 182 71 363 minecraft:blue_terracotta
fill 141 69 328 141 132 328 minecraft:black_concrete
setblock 142 69 325 minecraft:blue_terracotta
setblock 142 69 326 minecraft:dark_prismarine
fill 142 69 327 142 72 327 minecraft:blue_terracotta
setblock 142 69 331 minecraft:dark_prismarine
fill 142 69 332 142 72 332 minecraft:blue_terracotta
setblock 142 69 336 minecraft:dark_prismarine
fill 142 69 337 142 72 337 minecraft:blue_terracotta
setblock 142 69 341 minecraft:dark_prismarine
fill 142 69 342 142 72 342 minecraft:blue_terracotta
setblock 142 69 346 minecraft:dark_prismarine
fill 142 69 347 142 72 347 minecraft:blue_terracotta
setblock 142 69 351 minecraft:dark_prismarine
fill 142 69 352 142 72 352 minecraft:blue_terracotta
setblock 142 69 356 minecraft:dark_prismarine
fill 142 69 357 142 72 357 minecraft:blue_terracotta
setblock 142 69 361 minecraft:dark_prismarine
fill 142 69 362 142 72 362 minecraft:blue_terracotta
setblock 143 69 335 minecraft:dark_prismarine
fill 143 69 336 143 72 336 minecraft:blue_terracotta
setblock 143 69 340 minecraft:dark_prismarine
fill 143 69 341 143 72 341 minecraft:blue_terracotta
setblock 143 69 345 minecraft:dark_prismarine
fill 143 69 346 143 72 346 minecraft:blue_terracotta
setblock 143 69 350 minecraft:dark_prismarine
setblock 143 69 351 minecraft:blue_terracotta
setblock 143 69 355 minecraft:dark_prismarine
setblock 143 69 356 minecraft:blue_terracotta
setblock 143 69 360 minecraft:dark_prismarine
fill 143 69 361 143 70 361 minecraft:blue_terracotta
setblock 144 69 323 minecraft:blue_terracotta
setblock 144 69 325 minecraft:light[level=13]
setblock 144 69 333 minecraft:light[level=13]
setblock 144 69 335 minecraft:blue_terracotta
setblock 144 69 339 minecraft:dark_prismarine
fill 144 69 340 144 72 340 minecraft:blue_terracotta
setblock 144 69 344 minecraft:dark_prismarine
fill 144 69 345 144 71 345 minecraft:blue_terracotta
setblock 144 69 349 minecraft:light[level=13]
setblock 144 69 357 minecraft:light[level=13]
setblock 145 69 323 minecraft:dark_prismarine
setblock 145 69 339 minecraft:blue_terracotta
setblock 145 69 363 minecraft:dark_prismarine
fill 146 69 323 146 71 323 minecraft:blue_terracotta
fill 146 69 363 146 70 363 minecraft:blue_terracotta
fill 151 69 323 154 69 323 minecraft:blue_terracotta
setblock 152 69 325 minecraft:light[level=13]
setblock 152 69 333 minecraft:light[level=13]
setblock 152 69 341 minecraft:light[level=13]
setblock 152 69 349 minecraft:light[level=13]
setblock 152 69 357 minecraft:light[level=13]
fill 152 69 363 154 69 363 minecraft:blue_terracotta
setblock 155 69 323 minecraft:dark_prismarine
fill 155 69 324 155 72 324 minecraft:blue_terracotta
setblock 155 69 362 minecraft:blue_terracotta
setblock 155 69 363 minecraft:dark_prismarine
fill 156 69 323 156 72 323 minecraft:blue_terracotta
setblock 156 69 362 minecraft:dark_prismarine
fill 156 69 363 156 72 363 minecraft:blue_terracotta
setblock 157 69 325 minecraft:blue_terracotta
setblock 157 69 361 minecraft:dark_prismarine
fill 157 69 362 160 69 362 minecraft:blue_terracotta
setblock 158 69 325 minecraft:dark_prismarine
fill 158 69 361 161 69 361 minecraft:blue_terracotta
setblock 159 69 324 minecraft:dark_prismarine
fill 159 69 325 159 72 325 minecraft:blue_terracotta
setblock 160 69 323 minecraft:dark_prismarine
fill 160 69 324 160 72 324 minecraft:blue_terracotta
setblock 160 69 333 minecraft:light[level=13]
setblock 160 69 341 minecraft:light[level=13]
setblock 160 69 349 minecraft:light[level=13]
setblock 160 69 363 minecraft:dark_prismarine
fill 161 69 323 161 72 323 minecraft:blue_terracotta
setblock 161 69 362 minecraft:dark_prismarine
fill 161 69 363 161 72 363 minecraft:blue_terracotta
setblock 162 69 361 minecraft:dark_prismarine
fill 162 69 362 162 72 362 minecraft:blue_terracotta
setblock 163 69 325 minecraft:dark_prismarine
fill 163 69 361 163 71 361 minecraft:blue_terracotta
setblock 164 69 324 minecraft:dark_prismarine
setblock 164 69 325 minecraft:blue_terracotta
setblock 165 69 323 minecraft:dark_prismarine
fill 165 69 324 165 72 324 minecraft:blue_terracotta
setblock 165 69 363 minecraft:dark_prismarine
fill 166 69 323 166 72 323 minecraft:blue_terracotta
setblock 166 69 362 minecraft:dark_prismarine
fill 166 69 363 169 69 363 minecraft:blue_terracotta
setblock 167 69 361 minecraft:dark_prismarine
fill 167 69 362 170 69 362 minecraft:blue_terracotta
setblock 168 69 325 minecraft:light[level=13]
setblock 168 69 333 minecraft:light[level=13]
setblock 168 69 341 minecraft:light[level=13]
setblock 168 69 349 minecraft:light[level=13]
setblock 168 69 357 minecraft:light[level=13]
fill 168 69 361 169 69 361 minecraft:blue_terracotta
setblock 170 69 323 minecraft:dark_prismarine
setblock 170 69 363 minecraft:dark_prismarine
fill 171 69 323 174 69 323 minecraft:blue_terracotta
setblock 171 69 361 minecraft:blue_terracotta
setblock 171 69 362 minecraft:dark_prismarine
fill 171 69 363 171 72 363 minecraft:blue_terracotta
setblock 172 69 361 minecraft:dark_prismarine
fill 172 69 362 172 72 362 minecraft:blue_terracotta
fill 173 69 361 173 71 361 minecraft:blue_terracotta
setblock 175 69 323 minecraft:dark_prismarine
fill 175 69 326 175 79 326 minecraft:dark_prismarine
setblock 175 69 363 minecraft:dark_prismarine
fill 176 69 323 176 72 323 minecraft:blue_terracotta
setblock 176 69 325 minecraft:light[level=13]
setblock 176 69 333 minecraft:light[level=13]
setblock 176 69 341 minecraft:light[level=13]
setblock 176 69 357 minecraft:light[level=13]
setblock 176 69 362 minecraft:dark_prismarine
fill 176 69 363 176 72 363 minecraft:blue_terracotta
fill 177 69 324 178 69 324 minecraft:blue_terracotta
setblock 177 69 361 minecraft:dark_prismarine
fill 177 69 362 177 72 362 minecraft:blue_terracotta
setblock 178 69 360 minecraft:dark_prismarine
fill 178 69 361 178 72 361 minecraft:blue_terracotta
setblock 179 69 324 minecraft:dark_prismarine
setblock 179 69 359 minecraft:dark_prismarine
fill 179 69 360 179 71 360 minecraft:blue_terracotta
setblock 180 69 323 minecraft:dark_prismarine
fill 180 69 324 180 72 324 minecraft:blue_terracotta
setblock 180 69 337 minecraft:blue_terracotta
setblock 180 69 338 minecraft:dark_prismarine
fill 180 69 339 180 69 342 minecraft:blue_terracotta
setblock 180 69 343 minecraft:dark_prismarine
fill 180 69 344 180 72 344 minecraft:blue_terracotta
setblock 180 69 347 minecraft:blue_terracotta
setblock 180 69 348 minecraft:dark_prismarine
setblock 180 69 353 minecraft:dark_prismarine
fill 180 69 354 180 70 354 minecraft:blue_terracotta
setblock 180 69 358 minecraft:dark_prismarine
fill 180 69 359 180 72 359 minecraft:blue_terracotta
setblock 180 69 363 minecraft:dark_prismarine
fill 181 69 323 181 72 323 minecraft:blue_terracotta
fill 181 69 335 181 69 336 minecraft:blue_terracotta
setblock 181 69 337 minecraft:dark_prismarine
fill 181 69 338 181 69 341 minecraft:blue_terracotta
setblock 181 69 342 minecraft:dark_prismarine
fill 181 69 343 181 72 343 minecraft:blue_terracotta
setblock 181 69 347 minecraft:dark_prismarine
fill 181 69 348 181 72 348 minecraft:blue_terracotta
setblock 181 69 352 minecraft:dark_prismarine
fill 181 69 353 181 72 353 minecraft:blue_terracotta
setblock 181 69 357 minecraft:dark_prismarine
fill 181 69 358 181 72 358 minecraft:blue_terracotta
setblock 181 69 362 minecraft:dark_prismarine
fill 181 69 363 181 72 363 minecraft:blue_terracotta
setblock 182 69 326 minecraft:dark_prismarine
setblock 182 69 327 minecraft:blue_terracotta
setblock 182 69 331 minecraft:dark_prismarine
fill 182 69 332 182 69 335 minecraft:blue_terracotta
setblock 182 69 336 minecraft:dark_prismarine
fill 182 69 337 182 69 340 minecraft:blue_terracotta
setblock 182 69 341 minecraft:dark_prismarine
fill 182 69 342 182 72 342 minecraft:blue_terracotta
setblock 182 69 346 minecraft:dark_prismarine
fill 182 69 347 182 72 347 minecraft:blue_terracotta
setblock 182 69 351 minecraft:dark_prismarine
fill 182 69 352 182 72 352 minecraft:blue_terracotta
setblock 182 69 356 minecraft:dark_prismarine
fill 182 69 357 182 72 357 minecraft:blue_terracotta
setblock 182 69 361 minecraft:dark_prismarine
fill 182 69 362 182 72 362 minecraft:blue_terracotta
setblock 142 70 325 minecraft:dark_prismarine
fill 142 70 326 142 73 326 minecraft:blue_terracotta
setblock 142 70 330 minecraft:dark_prismarine
fill 142 70 331 142 71 331 minecraft:blue_terracotta
setblock 142 70 335 minecraft:dark_prismarine
fill 142 70 336 142 73 336 minecraft:blue_terracotta
setblock 142 70 340 minecraft:dark_prismarine
fill 142 70 341 142 73 341 minecraft:blue_terracotta
setblock 142 70 345 minecraft:dark_prismarine
fill 142 70 346 142 73 346 minecraft:blue_terracotta
setblock 142 70 350 minecraft:dark_prismarine
fill 142 70 351 142 73 351 minecraft:blue_terracotta
setblock 142 70 355 minecraft:dark_prismarine
fill 142 70 356 142 71 356 minecraft:blue_terracotta
setblock 142 70 360 minecraft:dark_prismarine
fill 142 70 361 142 73 361 minecraft:blue_terracotta
setblock 143 70 334 minecraft:dark_prismarine
fill 143 70 335 143 71 335 minecraft:blue_terracotta
setblock 143 70 339 minecraft:dark_prismarine
fill 143 70 340 143 73 340 minecraft:blue_terracotta
setblock 143 70 344 minecraft:dark_prismarine
fill 143 70 345 143 73 345 minecraft:blue_terracotta
setblock 143 70 349 minecraft:dark_prismarine
setblock 143 70 350 minecraft:blue_terracotta
setblock 143 70 359 minecraft:dark_prismarine
setblock 143 70 360 minecraft:blue_terracotta
setblock 144 70 323 minecraft:dark_prismarine
setblock 144 70 338 minecraft:dark_prismarine
fill 144 70 339 144 71 339 minecraft:blue_terracotta
setblock 144 70 343 minecraft:dark_prismarine
fill 144 70 344 144 72 344 minecraft:blue_terracotta
setblock 144 70 363 minecraft:dark_prismarine
fill 145 70 323 145 73 323 minecraft:blue_terracotta
fill 145 70 363 145 71 363 minecraft:blue_terracotta
setblock 148 70 363 minecraft:purple_concrete
fill 150 70 323 153 70 323 minecraft:blue_terracotta
fill 152 70 363 153 70 363 minecraft:blue_terracotta
setblock 154 70 323 minecraft:dark_prismarine
fill 154 70 324 154 73 324 minecraft:blue_terracotta
setblock 154 70 363 minecraft:dark_prismarine
fill 155 70 323 155 73 323 minecraft:blue_terracotta
setblock 155 70 362 minecraft:dark_prismarine
fill 155 70 363 155 73 363 minecraft:blue_terracotta
fill 156 70 362 159 70 362 minecraft:blue_terracotta
setblock 157 70 325 minecraft:dark_prismarine
setblock 158 70 324 minecraft:dark_prismarine
fill 158 70 325 158 73 325 minecraft:blue_terracotta
fill 158 70 361 160 70 361 minecraft:blue_terracotta
setblock 159 70 323 minecraft:dark_prismarine
fill 159 70 324 159 73 324 minecraft:blue_terracotta
setblock 159 70 363 minecraft:dark_prismarine
fill 160 70 323 160 73 323 minecraft:blue_terracotta
setblock 160 70 362 minecraft:dark_prismarine
fill 160 70 363 160 73 363 minecraft:blue_terracotta
setblock 161 70 361 minecraft:dark_prismarine
fill 161 70 362 161 73 362 minecraft:blue_terracotta
setblock 162 70 325 minecraft:dark_prismarine
fill 162 70 361 162 72 361 minecraft:blue_terracotta
setblock 163 70 324 minecraft:dark_prismarine
fill 163 70 325 163 71 325 minecraft:blue_terracotta
setblock 164 70 323 minecraft:dark_prismarine
fill 164 70 324 164 73 324 minecraft:blue_terracotta
setblock 164 70 363 minecraft:dark_prismarine
fill 165 70 323 165 73 323 minecraft:blue_terracotta
setblock 165 70 362 minecraft:dark_prismarine
fill 165 70 363 168 70 363 minecraft:blue_terracotta
setblock 166 70 361 minecraft:dark_prismarine
fill 166 70 362 169 70 362 minecraft:blue_terracotta
setblock 169 70 323 minecraft:dark_prismarine
setblock 169 70 363 minecraft:dark_prismarine
fill 170 70 323 173 70 323 minecraft:blue_terracotta
setblock 170 70 362 minecraft:dark_prismarine
fill 170 70 363 170 73 363 minecraft:blue_terracotta
fill 171 70 362 171 73 362 minecraft:blue_terracotta
setblock 172 70 361 minecraft:blue_terracotta
setblock 174 70 323 minecraft:dark_prismarine
setblock 174 70 363 minecraft:dark_prismarine
fill 175 70 323 175 73 323 minecraft:blue_terracotta
setblock 175 70 362 minecraft:dark_prismarine
fill 175 70 363 175 73 363 minecraft:blue_terracotta
setblock 176 70 361 minecraft:dark_prismarine
fill 176 70 362 176 73 362 minecraft:blue_terracotta
setblock 177 70 324 minecraft:blue_terracotta
fill 177 70 336 177 102 336 minecraft:magenta_terracotta
setblock 177 70 360 minecraft:dark_prismarine
fill 177 70 361 177 73 361 minecraft:blue_terracotta
fill 177 70 364 178 131 364 minecraft:black_concrete
setblock 178 70 324 minecraft:dark_prismarine
fill 178 70 360 178 71 360 minecraft:blue_terracotta
setblock 179 70 323 minecraft:dark_prismarine
fill 179 70 324 179 73 324 minecraft:blue_terracotta
setblock 179 70 358 minecraft:dark_prismarine
setblock 179 70 359 minecraft:blue_terracotta
setblock 179 70 363 minecraft:dark_prismarine
setblock 179 70 364 minecraft:light_blue_wool
fill 180 70 323 180 73 323 minecraft:blue_terracotta
fill 180 70 338 180 70 341 minecraft:blue_terracotta
setblock 180 70 342 minecraft:dark_prismarine
fill 180 70 343 180 73 343 minecraft:blue_terracotta
setblock 180 70 347 minecraft:dark_prismarine
fill 180 70 348 180 73 348 minecraft:blue_terracotta
setblock 180 70 357 minecraft:dark_prismarine
fill 180 70 358 180 72 358 minecraft:blue_terracotta
setblock 180 70 362 minecraft:dark_prismarine
fill 180 70 363 180 73 363 minecraft:blue_terracotta
fill 180 70 364 180 131 364 minecraft:black_concrete
setblock 181 70 335 minecraft:blue_terracotta
setblock 181 70 336 minecraft:dark_prismarine
fill 181 70 337 181 70 340 minecraft:blue_terracotta
setblock 181 70 341 minecraft:dark_prismarine
fill 181 70 342 181 73 342 minecraft:blue_terracotta
setblock 181 70 346 minecraft:dark_prismarine
fill 181 70 347 181 73 347 minecraft:blue_terracotta
setblock 181 70 351 minecraft:dark_prismarine
fill 181 70 352 181 73 352 minecraft:blue_terracotta
setblock 181 70 356 minecraft:dark_prismarine
fill 181 70 357 181 73 357 minecraft:blue_terracotta
setblock 181 70 361 minecraft:dark_prismarine
fill 181 70 362 181 73 362 minecraft:blue_terracotta
setblock 182 70 325 minecraft:dark_prismarine
fill 182 70 326 182 71 326 minecraft:blue_terracotta
fill 182 70 333 182 70 334 minecraft:blue_terracotta
setblock 182 70 335 minecraft:dark_prismarine
fill 182 70 336 182 70 339 minecraft:blue_terracotta
setblock 182 70 340 minecraft:dark_prismarine
fill 182 70 341 182 73 341 minecraft:blue_terracotta
setblock 182 70 345 minecraft:dark_prismarine
fill 182 70 346 182 73 346 minecraft:blue_terracotta
setblock 182 70 350 minecraft:dark_prismarine
fill 182 70 351 182 73 351 minecraft:blue_terracotta
setblock 182 70 355 minecraft:dark_prismarine
fill 182 70 356 182 73 356 minecraft:blue_terracotta
setblock 182 70 360 minecraft:dark_prismarine
fill 182 70 361 182 73 361 minecraft:blue_terracotta
setblock 141 71 330 minecraft:light_blue_wool
fill 141 71 331 141 100 331 minecraft:black_concrete
setblock 142 71 324 minecraft:dark_prismarine
fill 142 71 325 142 74 325 minecraft:blue_terracotta
setblock 142 71 330 minecraft:blue_terracotta
setblock 142 71 334 minecraft:dark_prismarine
fill 142 71 335 142 74 335 minecraft:blue_terracotta
setblock 142 71 339 minecraft:dark_prismarine
fill 142 71 340 142 74 340 minecraft:blue_terracotta
setblock 142 71 344 minecraft:dark_prismarine
fill 142 71 345 142 74 345 minecraft:blue_terracotta
setblock 142 71 349 minecraft:dark_prismarine
fill 142 71 350 142 74 350 minecraft:blue_terracotta
setblock 142 71 354 minecraft:dark_prismarine
setblock 142 71 355 minecraft:blue_terracotta
setblock 142 71 359 minecraft:dark_prismarine
fill 142 71 360 142 72 360 minecraft:blue_terracotta
setblock 143 71 323 minecraft:dark_prismarine
setblock 143 71 338 minecraft:dark_prismarine
fill 143 71 339 143 74 339 minecraft:blue_terracotta
setblock 143 71 343 minecraft:dark_prismarine
fill 143 71 344 143 74 344 minecraft:blue_terracotta
setblock 143 71 348 minecraft:dark_prismarine
setblock 143 71 363 minecraft:dark_prismarine
fill 144 71 323 144 74 323 minecraft:blue_terracotta
setblock 144 71 325 minecraft:light[level=12]
setblock 144 71 332 minecraft:light[level=12]
setblock 144 71 338 minecraft:blue_terracotta
setblock 144 71 342 minecraft:dark_prismarine
fill 144 71 343 144 72 343 minecraft:blue_terracotta
setblock 144 71 346 minecraft:light[level=12]
setblock 144 71 353 minecraft:light[level=12]
setblock 144 71 360 minecraft:light[level=12]
fill 144 71 363 144 72 363 minecraft:blue_terracotta
fill 149 71 323 152 71 323 minecraft:blue_terracotta
setblock 151 71 325 minecraft:light[level=12]
setblock 151 71 332 minecraft:light[level=12]
setblock 151 71 339 minecraft:light[level=12]
setblock 151 71 346 minecraft:light[level=12]
setblock 151 71 353 minecraft:light[level=12]
setblock 151 71 360 minecraft:light[level=12]
setblock 152 71 363 minecraft:blue_terracotta
setblock 153 71 323 minecraft:dark_prismarine
fill 153 71 324 153 74 324 minecraft:blue_terracotta
setblock 153 71 363 minecraft:dark_prismarine
fill 154 71 323 154 74 323 minecraft:blue_terracotta
fill 154 71 363 154 74 363 minecraft:blue_terracotta
fill 155 71 362 158 71 362 minecraft:blue_terracotta
setblock 156 71 325 minecraft:dark_prismarine
setblock 157 71 324 minecraft:dark_prismarine
fill 157 71 325 157 74 325 minecraft:blue_terracotta
setblock 158 71 323 minecraft:dark_prismarine
fill 158 71 324 158 74 324 minecraft:blue_terracotta
setblock 158 71 332 minecraft:light[level=12]
setblock 158 71 339 minecraft:light[level=12]
setblock 158 71 346 minecraft:light[level=12]
setblock 158 71 353 minecraft:light[level=12]
setblock 158 71 360 minecraft:light[level=12]
fill 158 71 361 159 71 361 minecraft:blue_terracotta
setblock 158 71 363 minecraft:dark_prismarine
fill 159 71 323 159 74 323 minecraft:blue_terracotta
setblock 159 71 362 minecraft:dark_prismarine
fill 159 71 363 159 74 363 minecraft:blue_terracotta
setblock 160 71 361 minecraft:dark_prismarine
fill 160 71 362 160 74 362 minecraft:blue_terracotta
setblock 161 71 325 minecraft:dark_prismarine
fill 161 71 361 161 72 361 minecraft:blue_terracotta
setblock 162 71 324 minecraft:dark_prismarine
fill 162 71 325 162 73 325 minecraft:blue_terracotta
setblock 163 71 323 minecraft:dark_prismarine
fill 163 71 324 163 74 324 minecraft:blue_terracotta
setblock 163 71 363 minecraft:dark_prismarine
fill 164 71 323 164 74 323 minecraft:blue_terracotta
fill 164 71 330 164 102 330 minecraft:magenta_terracotta
setblock 164 71 362 minecraft:dark_prismarine
fill 164 71 363 167 71 363 minecraft:blue_terracotta
setblock 165 71 325 minecraft:light[level=12]
setblock 165 71 332 minecraft:light[level=12]
setblock 165 71 339 minecraft:light[level=12]
setblock 165 71 346 minecraft:light[level=12]
schedule function dropper:buildpart/75_5 1t
