setblock 142 22 328 minecraft:dark_prismarine
fill 142 22 329 142 25 329 minecraft:blue_terracotta
setblock 142 22 332 minecraft:blue_terracotta
setblock 142 22 333 minecraft:dark_prismarine
fill 142 22 334 142 25 334 minecraft:blue_terracotta
setblock 142 22 337 minecraft:blue_terracotta
setblock 142 22 338 minecraft:dark_prismarine
fill 142 22 339 142 25 339 minecraft:blue_terracotta
setblock 142 22 343 minecraft:dark_prismarine
fill 142 22 344 142 25 344 minecraft:blue_terracotta
setblock 142 22 347 minecraft:blue_terracotta
setblock 142 22 348 minecraft:dark_prismarine
fill 142 22 349 142 25 349 minecraft:blue_terracotta
setblock 142 22 353 minecraft:dark_prismarine
fill 142 22 354 142 23 356 minecraft:blue_terracotta
setblock 142 22 362 minecraft:blue_terracotta
setblock 142 22 363 minecraft:dark_prismarine
fill 143 22 323 143 25 323 minecraft:blue_terracotta
setblock 143 22 327 minecraft:dark_prismarine
fill 143 22 328 143 25 328 minecraft:blue_terracotta
setblock 143 22 332 minecraft:dark_prismarine
fill 143 22 333 143 25 333 minecraft:blue_terracotta
fill 143 22 341 143 28 342 minecraft:dark_prismarine
setblock 143 22 343 minecraft:blue_terracotta
setblock 143 22 347 minecraft:dark_prismarine
fill 143 22 348 144 23 348 minecraft:blue_terracotta
setblock 143 22 352 minecraft:dark_prismarine
fill 143 22 353 143 25 353 minecraft:blue_terracotta
fill 143 22 363 143 25 363 minecraft:blue_terracotta
setblock 144 22 326 minecraft:dark_prismarine
fill 144 22 327 144 25 327 minecraft:blue_terracotta
setblock 144 22 331 minecraft:dark_prismarine
fill 144 22 332 145 24 332 minecraft:blue_terracotta
fill 144 22 334 144 23 334 minecraft:blue_terracotta
fill 144 22 349 144 23 349 minecraft:blue_terracotta
setblock 145 22 325 minecraft:dark_prismarine
fill 145 22 326 145 25 326 minecraft:blue_terracotta
setblock 145 22 330 minecraft:dark_prismarine
fill 145 22 331 145 25 331 minecraft:blue_terracotta
fill 145 22 362 147 22 362 minecraft:blue_terracotta
setblock 146 22 324 minecraft:dark_prismarine
fill 146 22 325 146 25 325 minecraft:blue_terracotta
setblock 146 22 329 minecraft:dark_prismarine
setblock 147 22 323 minecraft:dark_prismarine
fill 147 22 324 147 25 324 minecraft:blue_terracotta
setblock 147 22 363 minecraft:dark_prismarine
fill 148 22 323 148 25 323 minecraft:blue_terracotta
setblock 148 22 362 minecraft:dark_prismarine
fill 148 22 363 148 25 363 minecraft:blue_terracotta
setblock 149 22 326 minecraft:dark_prismarine
fill 149 22 362 149 23 362 minecraft:blue_terracotta
setblock 150 22 325 minecraft:dark_prismarine
setblock 150 22 326 minecraft:blue_terracotta
setblock 151 22 324 minecraft:dark_prismarine
fill 151 22 325 151 23 325 minecraft:blue_terracotta
setblock 152 22 323 minecraft:dark_prismarine
fill 152 22 324 152 24 324 minecraft:blue_terracotta
setblock 152 22 363 minecraft:dark_prismarine
fill 153 22 323 156 22 323 minecraft:blue_terracotta
fill 153 22 363 153 25 363 minecraft:blue_terracotta
fill 155 22 364 155 114 364 minecraft:black_concrete
setblock 156 22 364 minecraft:light_blue_wool
setblock 157 22 323 minecraft:dark_prismarine
fill 157 22 328 157 26 328 minecraft:magenta_terracotta
setblock 157 22 363 minecraft:dark_prismarine
fill 158 22 323 158 25 323 minecraft:blue_terracotta
fill 158 22 363 158 25 363 minecraft:blue_terracotta
setblock 161 22 324 minecraft:dark_prismarine
fill 161 22 362 161 23 362 minecraft:blue_terracotta
setblock 162 22 323 minecraft:dark_prismarine
fill 162 22 324 162 25 324 minecraft:blue_terracotta
setblock 162 22 363 minecraft:dark_prismarine
fill 163 22 323 163 25 323 minecraft:blue_terracotta
setblock 163 22 362 minecraft:dark_prismarine
fill 163 22 363 163 25 363 minecraft:blue_terracotta
fill 164 22 362 164 25 362 minecraft:blue_terracotta
setblock 165 22 325 minecraft:dark_prismarine
setblock 166 22 324 minecraft:dark_prismarine
fill 167 22 322 167 48 322 minecraft:black_concrete
setblock 167 22 323 minecraft:dark_prismarine
fill 167 22 324 167 24 324 minecraft:blue_terracotta
setblock 167 22 363 minecraft:dark_prismarine
fill 168 22 323 168 24 323 minecraft:blue_terracotta
setblock 168 22 362 minecraft:dark_prismarine
fill 168 22 363 168 25 363 minecraft:blue_terracotta
fill 174 22 338 174 33 338 minecraft:magenta_terracotta
setblock 174 22 351 minecraft:sea_lantern
setblock 174 22 353 minecraft:sea_lantern
setblock 174 22 355 minecraft:sea_lantern
setblock 174 22 357 minecraft:sea_lantern
setblock 174 22 359 minecraft:sea_lantern
setblock 174 22 361 minecraft:sea_lantern
setblock 175 22 352 minecraft:sea_lantern
setblock 175 22 354 minecraft:sea_lantern
setblock 175 22 356 minecraft:sea_lantern
setblock 175 22 358 minecraft:sea_lantern
setblock 175 22 360 minecraft:sea_lantern
setblock 175 22 363 minecraft:purple_concrete
setblock 176 22 351 minecraft:sea_lantern
setblock 176 22 353 minecraft:sea_lantern
setblock 176 22 355 minecraft:sea_lantern
setblock 176 22 357 minecraft:sea_lantern
setblock 176 22 359 minecraft:sea_lantern
setblock 176 22 361 minecraft:sea_lantern
setblock 177 22 352 minecraft:sea_lantern
setblock 177 22 354 minecraft:sea_lantern
setblock 177 22 356 minecraft:sea_lantern
setblock 177 22 358 minecraft:sea_lantern
setblock 177 22 360 minecraft:sea_lantern
setblock 178 22 351 minecraft:sea_lantern
setblock 178 22 353 minecraft:sea_lantern
setblock 178 22 355 minecraft:sea_lantern
setblock 178 22 357 minecraft:sea_lantern
setblock 178 22 359 minecraft:sea_lantern
setblock 178 22 361 minecraft:sea_lantern
setblock 179 22 352 minecraft:sea_lantern
setblock 179 22 354 minecraft:sea_lantern
setblock 179 22 356 minecraft:sea_lantern
setblock 179 22 358 minecraft:sea_lantern
setblock 179 22 360 minecraft:sea_lantern
fill 180 22 347 180 22 349 minecraft:blue_terracotta
setblock 180 22 351 minecraft:sea_lantern
setblock 180 22 353 minecraft:sea_lantern
setblock 180 22 355 minecraft:sea_lantern
setblock 180 22 357 minecraft:sea_lantern
setblock 180 22 359 minecraft:sea_lantern
setblock 180 22 361 minecraft:sea_lantern
setblock 181 22 323 minecraft:blue_terracotta
setblock 181 22 324 minecraft:dark_prismarine
fill 181 22 325 181 22 328 minecraft:blue_terracotta
setblock 181 22 329 minecraft:dark_prismarine
fill 181 22 330 181 22 333 minecraft:blue_terracotta
setblock 181 22 334 minecraft:dark_prismarine
fill 181 22 335 181 22 338 minecraft:blue_terracotta
setblock 181 22 339 minecraft:dark_prismarine
fill 181 22 340 181 25 340 minecraft:blue_terracotta
setblock 181 22 344 minecraft:dark_prismarine
fill 181 22 345 181 25 345 minecraft:blue_terracotta
setblock 181 22 348 minecraft:blue_terracotta
setblock 181 22 349 minecraft:dark_prismarine
fill 181 22 350 181 24 351 minecraft:blue_terracotta
setblock 181 22 352 minecraft:sea_lantern
setblock 181 22 353 minecraft:blue_terracotta
setblock 181 22 354 minecraft:sea_lantern
setblock 181 22 356 minecraft:sea_lantern
setblock 181 22 358 minecraft:sea_lantern
setblock 181 22 360 minecraft:sea_lantern
setblock 182 22 323 minecraft:dark_prismarine
fill 182 22 324 182 25 324 minecraft:blue_terracotta
setblock 182 22 328 minecraft:dark_prismarine
fill 182 22 329 182 22 332 minecraft:blue_terracotta
setblock 182 22 333 minecraft:dark_prismarine
fill 182 22 334 182 25 334 minecraft:blue_terracotta
setblock 182 22 338 minecraft:dark_prismarine
fill 182 22 339 182 25 339 minecraft:blue_terracotta
setblock 182 22 343 minecraft:dark_prismarine
fill 182 22 344 182 25 344 minecraft:blue_terracotta
setblock 182 22 348 minecraft:dark_prismarine
fill 182 22 349 182 25 349 minecraft:blue_terracotta
setblock 182 22 351 minecraft:sea_lantern
setblock 182 22 353 minecraft:sea_lantern
fill 182 22 354 182 25 354 minecraft:blue_terracotta
setblock 182 22 355 minecraft:sea_lantern
fill 182 22 356 182 23 356 minecraft:blue_terracotta
setblock 182 22 357 minecraft:sea_lantern
setblock 182 22 359 minecraft:sea_lantern
setblock 182 22 361 minecraft:sea_lantern
fill 183 22 333 183 131 333 minecraft:black_concrete
fill 183 22 346 183 131 346 minecraft:black_concrete
setblock 142 23 322 minecraft:cyan_concrete
fill 142 23 323 142 26 323 minecraft:blue_terracotta
setblock 142 23 327 minecraft:dark_prismarine
fill 142 23 328 142 26 328 minecraft:blue_terracotta
setblock 142 23 332 minecraft:dark_prismarine
fill 142 23 333 142 26 333 minecraft:blue_terracotta
setblock 142 23 337 minecraft:dark_prismarine
fill 142 23 338 143 25 338 minecraft:blue_terracotta
setblock 142 23 342 minecraft:dark_prismarine
fill 142 23 343 142 26 343 minecraft:blue_terracotta
setblock 142 23 347 minecraft:dark_prismarine
fill 142 23 348 142 26 348 minecraft:blue_terracotta
setblock 142 23 351 minecraft:blue_terracotta
setblock 142 23 352 minecraft:dark_prismarine
fill 142 23 353 142 26 353 minecraft:blue_terracotta
setblock 142 23 357 minecraft:dark_prismarine
fill 142 23 358 142 23 361 minecraft:blue_terracotta
setblock 142 23 362 minecraft:dark_prismarine
fill 142 23 363 142 26 363 minecraft:blue_terracotta
fill 143 23 322 144 42 322 minecraft:black_concrete
setblock 143 23 326 minecraft:dark_prismarine
fill 143 23 327 143 26 327 minecraft:blue_terracotta
setblock 143 23 331 minecraft:dark_prismarine
fill 143 23 332 143 26 332 minecraft:blue_terracotta
setblock 143 23 336 minecraft:dark_prismarine
fill 143 23 337 143 26 337 minecraft:blue_terracotta
fill 143 23 343 143 28 343 minecraft:dark_prismarine
setblock 143 23 346 minecraft:dark_prismarine
fill 143 23 347 143 25 347 minecraft:blue_terracotta
setblock 143 23 351 minecraft:dark_prismarine
fill 143 23 352 144 25 352 minecraft:blue_terracotta
fill 143 23 354 143 23 355 minecraft:blue_terracotta
setblock 144 23 325 minecraft:dark_prismarine
fill 144 23 326 144 26 326 minecraft:blue_terracotta
setblock 144 23 329 minecraft:blue_terracotta
setblock 144 23 330 minecraft:dark_prismarine
fill 144 23 331 144 26 331 minecraft:blue_terracotta
setblock 144 23 350 minecraft:dark_prismarine
fill 144 23 351 144 25 351 minecraft:blue_terracotta
setblock 144 23 353 minecraft:light[level=12]
setblock 144 23 360 minecraft:light[level=12]
fill 144 23 362 146 23 362 minecraft:blue_terracotta
setblock 145 23 324 minecraft:dark_prismarine
fill 145 23 325 145 26 325 minecraft:blue_terracotta
fill 145 23 327 146 23 327 minecraft:blue_terracotta
setblock 145 23 329 minecraft:dark_prismarine
fill 145 23 330 145 26 330 minecraft:blue_terracotta
setblock 145 23 333 minecraft:blue_terracotta
setblock 146 23 323 minecraft:dark_prismarine
fill 146 23 324 146 26 324 minecraft:blue_terracotta
setblock 146 23 328 minecraft:dark_prismarine
fill 146 23 329 146 24 329 minecraft:blue_terracotta
setblock 146 23 363 minecraft:dark_prismarine
fill 147 23 323 147 26 323 minecraft:blue_terracotta
setblock 147 23 327 minecraft:dark_prismarine
fill 147 23 351 147 33 351 minecraft:magenta_terracotta
setblock 147 23 362 minecraft:dark_prismarine
fill 147 23 363 147 26 363 minecraft:blue_terracotta
setblock 148 23 326 minecraft:dark_prismarine
fill 148 23 362 148 24 362 minecraft:blue_terracotta
setblock 149 23 325 minecraft:dark_prismarine
setblock 149 23 326 minecraft:blue_terracotta
setblock 150 23 324 minecraft:dark_prismarine
fill 150 23 325 150 24 325 minecraft:blue_terracotta
setblock 151 23 323 minecraft:dark_prismarine
fill 151 23 324 151 25 324 minecraft:blue_terracotta
setblock 151 23 332 minecraft:light[level=12]
setblock 151 23 339 minecraft:light[level=12]
setblock 151 23 346 minecraft:light[level=12]
setblock 151 23 353 minecraft:light[level=12]
setblock 151 23 360 minecraft:light[level=12]
setblock 151 23 363 minecraft:dark_prismarine
fill 152 23 323 155 23 323 minecraft:blue_terracotta
fill 152 23 363 152 25 363 minecraft:blue_terracotta
setblock 156 23 323 minecraft:dark_prismarine
setblock 156 23 363 minecraft:dark_prismarine
fill 156 23 364 156 127 364 minecraft:black_concrete
fill 157 23 323 157 24 323 minecraft:blue_terracotta
fill 157 23 363 157 26 363 minecraft:blue_terracotta
setblock 158 23 325 minecraft:light[level=12]
setblock 158 23 332 minecraft:light[level=12]
setblock 158 23 339 minecraft:light[level=12]
setblock 158 23 346 minecraft:light[level=12]
setblock 158 23 353 minecraft:light[level=12]
setblock 158 23 360 minecraft:light[level=12]
setblock 160 23 324 minecraft:dark_prismarine
setblock 161 23 323 minecraft:dark_prismarine
fill 161 23 324 161 24 324 minecraft:blue_terracotta
setblock 161 23 363 minecraft:dark_prismarine
fill 162 23 323 162 26 323 minecraft:blue_terracotta
setblock 162 23 362 minecraft:dark_prismarine
fill 162 23 363 162 26 363 minecraft:blue_terracotta
fill 163 23 362 163 26 362 minecraft:blue_terracotta
setblock 165 23 324 minecraft:dark_prismarine
setblock 165 23 325 minecraft:light[level=12]
setblock 165 23 332 minecraft:light[level=12]
setblock 165 23 339 minecraft:light[level=12]
setblock 165 23 346 minecraft:light[level=12]
setblock 165 23 353 minecraft:light[level=12]
setblock 165 23 360 minecraft:light[level=12]
setblock 166 23 323 minecraft:dark_prismarine
fill 166 23 324 166 24 324 minecraft:blue_terracotta
setblock 166 23 363 minecraft:dark_prismarine
fill 167 23 323 167 25 323 minecraft:blue_terracotta
setblock 167 23 362 minecraft:dark_prismarine
fill 167 23 363 167 26 363 minecraft:blue_terracotta
setblock 172 23 325 minecraft:light[level=12]
setblock 172 23 332 minecraft:light[level=12]
setblock 172 23 339 minecraft:light[level=12]
setblock 172 23 346 minecraft:light[level=12]
setblock 172 23 353 minecraft:light[level=12]
setblock 172 23 360 minecraft:light[level=12]
fill 174 23 351 174 24 351 minecraft:dark_prismarine
fill 174 23 353 174 24 353 minecraft:dark_prismarine
fill 174 23 355 174 24 355 minecraft:dark_prismarine
fill 174 23 357 174 24 357 minecraft:dark_prismarine
fill 174 23 359 174 24 359 minecraft:dark_prismarine
fill 174 23 361 174 24 361 minecraft:dark_prismarine
fill 175 23 352 175 24 352 minecraft:dark_prismarine
fill 175 23 354 175 24 354 minecraft:dark_prismarine
fill 175 23 356 175 24 356 minecraft:dark_prismarine
fill 175 23 358 175 24 358 minecraft:dark_prismarine
fill 175 23 360 175 24 360 minecraft:dark_prismarine
fill 176 23 351 176 24 351 minecraft:magenta_terracotta
fill 176 23 353 176 24 353 minecraft:dark_prismarine
fill 176 23 355 176 24 355 minecraft:dark_prismarine
fill 176 23 357 176 24 357 minecraft:dark_prismarine
fill 176 23 359 176 24 359 minecraft:dark_prismarine
fill 176 23 361 176 24 361 minecraft:dark_prismarine
fill 177 23 352 177 24 352 minecraft:magenta_terracotta
fill 177 23 354 177 24 354 minecraft:dark_prismarine
fill 177 23 356 177 24 356 minecraft:dark_prismarine
fill 177 23 358 177 24 358 minecraft:dark_prismarine
fill 177 23 360 177 24 360 minecraft:dark_prismarine
fill 178 23 351 178 24 351 minecraft:magenta_terracotta
fill 178 23 353 178 24 353 minecraft:dark_prismarine
fill 178 23 355 178 24 355 minecraft:dark_prismarine
fill 178 23 357 178 24 357 minecraft:dark_prismarine
fill 178 23 359 178 24 359 minecraft:dark_prismarine
fill 178 23 361 178 24 361 minecraft:dark_prismarine
fill 179 23 323 179 24 323 minecraft:blue_terracotta
setblock 179 23 325 minecraft:light[level=12]
setblock 179 23 332 minecraft:light[level=12]
setblock 179 23 339 minecraft:light[level=12]
setblock 179 23 346 minecraft:light[level=12]
fill 179 23 352 179 24 352 minecraft:magenta_terracotta
fill 179 23 354 179 24 354 minecraft:dark_prismarine
fill 179 23 356 179 24 356 minecraft:dark_prismarine
fill 179 23 358 179 24 358 minecraft:dark_prismarine
fill 179 23 360 179 24 360 minecraft:dark_prismarine
fill 180 23 327 180 23 328 minecraft:blue_terracotta
setblock 180 23 329 minecraft:dark_prismarine
fill 180 23 330 180 23 333 minecraft:blue_terracotta
fill 180 23 347 180 23 348 minecraft:blue_terracotta
setblock 180 23 349 minecraft:dark_prismarine
setblock 180 23 351 minecraft:magenta_terracotta
fill 180 23 353 181 23 353 minecraft:dark_prismarine
fill 180 23 355 180 24 355 minecraft:dark_prismarine
fill 180 23 357 180 24 357 minecraft:dark_prismarine
fill 180 23 359 180 24 359 minecraft:dark_prismarine
fill 180 23 361 180 24 361 minecraft:dark_prismarine
setblock 181 23 323 minecraft:dark_prismarine
fill 181 23 324 181 23 327 minecraft:blue_terracotta
setblock 181 23 328 minecraft:dark_prismarine
fill 181 23 329 181 23 332 minecraft:blue_terracotta
setblock 181 23 333 minecraft:dark_prismarine
fill 181 23 334 181 23 337 minecraft:blue_terracotta
setblock 181 23 338 minecraft:dark_prismarine
fill 181 23 339 181 26 339 minecraft:blue_terracotta
setblock 181 23 343 minecraft:dark_prismarine
fill 181 23 344 181 26 344 minecraft:blue_terracotta
setblock 181 23 348 minecraft:dark_prismarine
fill 181 23 349 181 26 349 minecraft:blue_terracotta
setblock 181 23 352 minecraft:blue_terracotta
fill 181 23 354 181 24 354 minecraft:blue_terracotta
fill 181 23 356 181 24 356 minecraft:dark_prismarine
fill 181 23 358 181 24 358 minecraft:dark_prismarine
fill 181 23 360 181 24 360 minecraft:dark_prismarine
setblock 181 23 363 minecraft:purple_concrete
fill 182 23 323 182 26 323 minecraft:blue_terracotta
setblock 182 23 327 minecraft:dark_prismarine
fill 182 23 328 182 23 331 minecraft:blue_terracotta
setblock 182 23 332 minecraft:dark_prismarine
fill 182 23 333 182 26 333 minecraft:blue_terracotta
setblock 182 23 337 minecraft:dark_prismarine
fill 182 23 338 182 26 338 minecraft:blue_terracotta
setblock 182 23 342 minecraft:dark_prismarine
fill 182 23 343 182 26 343 minecraft:blue_terracotta
setblock 182 23 347 minecraft:dark_prismarine
fill 182 23 348 182 26 348 minecraft:blue_terracotta
setblock 182 23 351 minecraft:blue_terracotta
setblock 182 23 352 minecraft:dark_prismarine
fill 182 23 353 182 24 353 minecraft:blue_terracotta
fill 182 23 355 182 24 355 minecraft:blue_terracotta
setblock 182 23 357 minecraft:dark_prismarine
fill 182 23 359 182 24 359 minecraft:dark_prismarine
fill 182 23 361 182 24 361 minecraft:dark_prismarine
fill 183 23 358 183 131 358 minecraft:black_concrete
setblock 183 23 359 minecraft:cyan_concrete
fill 142 24 322 142 131 322 minecraft:black_concrete
setblock 142 24 326 minecraft:dark_prismarine
fill 142 24 327 142 27 327 minecraft:blue_terracotta
setblock 142 24 331 minecraft:dark_prismarine
fill 142 24 332 142 27 332 minecraft:blue_terracotta
setblock 142 24 335 minecraft:blue_terracotta
setblock 142 24 336 minecraft:dark_prismarine
fill 142 24 337 142 27 337 minecraft:blue_terracotta
setblock 142 24 341 minecraft:dark_prismarine
fill 142 24 342 142 26 342 minecraft:blue_terracotta
setblock 142 24 346 minecraft:dark_prismarine
fill 142 24 347 142 27 347 minecraft:blue_terracotta
setblock 142 24 350 minecraft:blue_terracotta
setblock 142 24 351 minecraft:dark_prismarine
fill 142 24 352 142 27 352 minecraft:blue_terracotta
fill 142 24 354 142 24 355 minecraft:blue_terracotta
setblock 142 24 356 minecraft:dark_prismarine
fill 142 24 357 142 24 360 minecraft:blue_terracotta
setblock 142 24 361 minecraft:dark_prismarine
fill 142 24 362 142 27 362 minecraft:blue_terracotta
setblock 143 24 325 minecraft:dark_prismarine
fill 143 24 326 143 27 326 minecraft:blue_terracotta
setblock 143 24 330 minecraft:dark_prismarine
fill 143 24 331 143 27 331 minecraft:blue_terracotta
setblock 143 24 335 minecraft:dark_prismarine
fill 143 24 336 143 27 336 minecraft:blue_terracotta
fill 143 24 344 143 28 345 minecraft:dark_prismarine
fill 143 24 346 143 25 346 minecraft:blue_terracotta
fill 143 24 348 143 25 348 minecraft:blue_terracotta
setblock 143 24 350 minecraft:dark_prismarine
fill 143 24 351 143 27 351 minecraft:blue_terracotta
setblock 143 24 354 minecraft:blue_terracotta
setblock 143 24 355 minecraft:dark_prismarine
fill 143 24 356 143 26 357 minecraft:blue_terracotta
setblock 144 24 324 minecraft:dark_prismarine
fill 144 24 325 144 27 325 minecraft:blue_terracotta
setblock 144 24 329 minecraft:dark_prismarine
fill 144 24 330 144 27 330 minecraft:blue_terracotta
setblock 144 24 334 minecraft:dark_prismarine
fill 144 24 335 144 27 335 minecraft:blue_terracotta
setblock 144 24 349 minecraft:dark_prismarine
fill 144 24 350 144 25 350 minecraft:blue_terracotta
setblock 144 24 353 minecraft:blue_terracotta
fill 144 24 362 145 24 362 minecraft:blue_terracotta
setblock 145 24 322 minecraft:light_blue_wool
setblock 145 24 323 minecraft:dark_prismarine
fill 145 24 324 145 27 324 minecraft:blue_terracotta
setblock 145 24 327 minecraft:blue_terracotta
setblock 145 24 328 minecraft:dark_prismarine
fill 145 24 329 145 27 329 minecraft:blue_terracotta
setblock 145 24 333 minecraft:dark_prismarine
setblock 145 24 363 minecraft:dark_prismarine
fill 146 24 323 146 27 323 minecraft:blue_terracotta
setblock 146 24 327 minecraft:dark_prismarine
setblock 146 24 328 minecraft:blue_terracotta
setblock 146 24 362 minecraft:dark_prismarine
fill 146 24 363 146 27 363 minecraft:blue_terracotta
setblock 147 24 326 minecraft:dark_prismarine
fill 147 24 362 147 25 362 minecraft:blue_terracotta
setblock 148 24 325 minecraft:dark_prismarine
setblock 148 24 326 minecraft:blue_terracotta
setblock 149 24 324 minecraft:dark_prismarine
fill 149 24 325 149 25 325 minecraft:blue_terracotta
setblock 150 24 323 minecraft:dark_prismarine
fill 150 24 324 150 25 324 minecraft:blue_terracotta
setblock 150 24 363 minecraft:dark_prismarine
fill 151 24 323 154 24 323 minecraft:blue_terracotta
fill 151 24 363 151 26 363 minecraft:blue_terracotta
setblock 155 24 323 minecraft:dark_prismarine
setblock 155 24 363 minecraft:dark_prismarine
setblock 156 24 323 minecraft:blue_terracotta
fill 156 24 363 156 25 363 minecraft:blue_terracotta
setblock 160 24 323 minecraft:dark_prismarine
setblock 160 24 362 minecraft:blue_terracotta
setblock 160 24 363 minecraft:dark_prismarine
fill 161 24 323 161 27 323 minecraft:blue_terracotta
fill 161 24 327 161 33 327 minecraft:magenta_terracotta
setblock 161 24 362 minecraft:dark_prismarine
fill 161 24 363 161 27 363 minecraft:blue_terracotta
fill 162 24 362 162 27 362 minecraft:blue_terracotta
setblock 164 24 324 minecraft:dark_prismarine
setblock 165 24 323 minecraft:dark_prismarine
fill 165 24 324 165 25 324 minecraft:blue_terracotta
setblock 165 24 363 minecraft:dark_prismarine
fill 166 24 323 166 26 323 minecraft:blue_terracotta
setblock 166 24 362 minecraft:dark_prismarine
fill 166 24 363 166 27 363 minecraft:blue_terracotta
setblock 180 24 323 minecraft:dark_prismarine
fill 180 24 324 181 24 324 minecraft:blue_terracotta
setblock 180 24 327 minecraft:blue_terracotta
setblock 180 24 328 minecraft:dark_prismarine
fill 180 24 329 180 24 332 minecraft:blue_terracotta
setblock 180 24 333 minecraft:dark_prismarine
fill 180 24 334 181 25 335 minecraft:blue_terracotta
setblock 180 24 347 minecraft:blue_terracotta
setblock 180 24 348 minecraft:dark_prismarine
fill 180 24 349 180 25 349 minecraft:blue_terracotta
setblock 180 24 351 minecraft:blue_terracotta
setblock 180 24 353 minecraft:dark_prismarine
fill 181 24 323 181 27 323 minecraft:blue_terracotta
fill 181 24 325 181 24 326 minecraft:blue_terracotta
setblock 181 24 327 minecraft:dark_prismarine
fill 181 24 328 181 24 331 minecraft:blue_terracotta
setblock 181 24 332 minecraft:dark_prismarine
fill 181 24 333 181 27 333 minecraft:blue_terracotta
setblock 181 24 336 minecraft:blue_terracotta
setblock 181 24 337 minecraft:dark_prismarine
fill 181 24 338 181 27 338 minecraft:blue_terracotta
setblock 181 24 342 minecraft:dark_prismarine
fill 181 24 343 181 26 343 minecraft:blue_terracotta
setblock 181 24 347 minecraft:dark_prismarine
fill 181 24 348 181 27 348 minecraft:blue_terracotta
setblock 181 24 352 minecraft:dark_prismarine
fill 181 24 353 181 27 353 minecraft:blue_terracotta
fill 181 24 355 181 25 355 minecraft:blue_terracotta
setblock 182 24 326 minecraft:dark_prismarine
fill 182 24 327 182 24 330 minecraft:blue_terracotta
setblock 182 24 331 minecraft:dark_prismarine
fill 182 24 332 182 27 332 minecraft:blue_terracotta
setblock 182 24 336 minecraft:dark_prismarine
fill 182 24 337 182 27 337 minecraft:blue_terracotta
setblock 182 24 341 minecraft:dark_prismarine
fill 182 24 342 182 27 342 minecraft:blue_terracotta
setblock 182 24 346 minecraft:dark_prismarine
fill 182 24 347 182 27 347 minecraft:blue_terracotta
setblock 182 24 351 minecraft:dark_prismarine
fill 182 24 352 182 27 352 minecraft:blue_terracotta
setblock 182 24 356 minecraft:dark_prismarine
fill 182 24 357 182 24 358 minecraft:blue_terracotta
setblock 183 24 345 minecraft:cyan_concrete
fill 183 24 359 183 27 359 minecraft:black_concrete
setblock 142 25 325 minecraft:dark_prismarine
fill 142 25 326 142 28 326 minecraft:blue_terracotta
setblock 142 25 330 minecraft:dark_prismarine
fill 142 25 331 142 28 331 minecraft:blue_terracotta
setblock 142 25 335 minecraft:dark_prismarine
fill 142 25 336 142 28 336 minecraft:blue_terracotta
setblock 142 25 340 minecraft:dark_prismarine
fill 142 25 341 142 27 341 minecraft:blue_terracotta
setblock 142 25 345 minecraft:dark_prismarine
fill 142 25 346 142 27 346 minecraft:blue_terracotta
setblock 142 25 350 minecraft:dark_prismarine
fill 142 25 351 142 28 351 minecraft:blue_terracotta
setblock 142 25 354 minecraft:blue_terracotta
setblock 142 25 355 minecraft:dark_prismarine
fill 142 25 356 142 25 359 minecraft:blue_terracotta
setblock 142 25 360 minecraft:dark_prismarine
fill 142 25 361 142 28 361 minecraft:blue_terracotta
setblock 143 25 324 minecraft:dark_prismarine
fill 143 25 325 143 28 325 minecraft:blue_terracotta
setblock 143 25 329 minecraft:dark_prismarine
fill 143 25 330 143 28 330 minecraft:blue_terracotta
setblock 143 25 334 minecraft:dark_prismarine
fill 143 25 335 143 28 335 minecraft:blue_terracotta
setblock 143 25 349 minecraft:dark_prismarine
fill 143 25 350 143 27 350 minecraft:blue_terracotta
setblock 143 25 354 minecraft:dark_prismarine
fill 143 25 355 143 28 355 minecraft:blue_terracotta
setblock 143 25 358 minecraft:blue_terracotta
setblock 143 25 359 minecraft:dark_prismarine
fill 143 25 362 144 25 362 minecraft:blue_terracotta
setblock 144 25 323 minecraft:dark_prismarine
fill 144 25 324 144 28 324 minecraft:blue_terracotta
setblock 144 25 328 minecraft:dark_prismarine
fill 144 25 329 144 28 329 minecraft:blue_terracotta
setblock 144 25 332 minecraft:blue_terracotta
setblock 144 25 333 minecraft:dark_prismarine
fill 144 25 334 144 28 334 minecraft:blue_terracotta
setblock 144 25 353 minecraft:dark_prismarine
fill 144 25 354 144 26 354 minecraft:blue_terracotta
setblock 144 25 363 minecraft:dark_prismarine
fill 145 25 322 145 45 322 minecraft:black_concrete
fill 145 25 323 145 28 323 minecraft:blue_terracotta
setblock 145 25 327 minecraft:dark_prismarine
fill 145 25 328 145 26 328 minecraft:blue_terracotta
setblock 145 25 332 minecraft:dark_prismarine
setblock 145 25 333 minecraft:blue_terracotta
fill 145 25 347 146 25 348 minecraft:purple_concrete
setblock 145 25 362 minecraft:dark_prismarine
fill 145 25 363 145 28 363 minecraft:blue_terracotta
setblock 146 25 326 minecraft:dark_prismarine
setblock 146 25 349 minecraft:purple_concrete
fill 146 25 362 146 26 362 minecraft:blue_terracotta
setblock 147 25 325 minecraft:dark_prismarine
setblock 147 25 326 minecraft:blue_terracotta
fill 147 25 348 147 27 348 minecraft:purple_concrete
fill 147 25 349 147 33 349 minecraft:magenta_terracotta
setblock 148 25 324 minecraft:dark_prismarine
setblock 148 25 325 minecraft:blue_terracotta
setblock 149 25 323 minecraft:dark_prismarine
fill 149 25 324 149 26 324 minecraft:blue_terracotta
setblock 149 25 363 minecraft:dark_prismarine
fill 150 25 323 153 25 323 minecraft:blue_terracotta
fill 150 25 347 151 25 348 minecraft:purple_concrete
fill 150 25 363 150 26 363 minecraft:blue_terracotta
fill 151 25 345 151 25 346 minecraft:purple_concrete
setblock 159 25 323 minecraft:dark_prismarine
setblock 159 25 363 minecraft:dark_prismarine
fill 160 25 323 160 26 323 minecraft:blue_terracotta
setblock 160 25 362 minecraft:dark_prismarine
fill 160 25 363 160 28 363 minecraft:blue_terracotta
fill 161 25 362 161 28 362 minecraft:blue_terracotta
setblock 163 25 324 minecraft:dark_prismarine
fill 163 25 356 163 33 356 minecraft:magenta_terracotta
fill 163 25 359 163 33 359 minecraft:magenta_terracotta
setblock 164 25 323 minecraft:dark_prismarine
setblock 164 25 324 minecraft:blue_terracotta
setblock 164 25 363 minecraft:dark_prismarine
fill 165 25 323 165 26 323 minecraft:blue_terracotta
setblock 165 25 362 minecraft:dark_prismarine
fill 165 25 363 165 28 363 minecraft:blue_terracotta
setblock 166 25 362 minecraft:blue_terracotta
fill 169 25 323 169 26 323 minecraft:purple_concrete
setblock 174 25 351 minecraft:sea_lantern
setblock 174 25 353 minecraft:sea_lantern
setblock 174 25 355 minecraft:sea_lantern
setblock 174 25 357 minecraft:sea_lantern
setblock 174 25 359 minecraft:sea_lantern
setblock 174 25 361 minecraft:sea_lantern
setblock 174 25 363 minecraft:purple_concrete
setblock 175 25 323 minecraft:purple_concrete
setblock 175 25 352 minecraft:sea_lantern
setblock 175 25 354 minecraft:sea_lantern
setblock 175 25 356 minecraft:sea_lantern
setblock 175 25 358 minecraft:sea_lantern
setblock 175 25 360 minecraft:sea_lantern
setblock 176 25 351 minecraft:sea_lantern
setblock 176 25 353 minecraft:sea_lantern
setblock 176 25 355 minecraft:sea_lantern
setblock 176 25 357 minecraft:sea_lantern
setblock 176 25 359 minecraft:sea_lantern
setblock 176 25 361 minecraft:sea_lantern
fill 177 25 336 177 33 336 minecraft:magenta_terracotta
setblock 177 25 352 minecraft:sea_lantern
setblock 177 25 354 minecraft:sea_lantern
setblock 177 25 356 minecraft:sea_lantern
setblock 177 25 358 minecraft:sea_lantern
setblock 177 25 360 minecraft:sea_lantern
setblock 178 25 351 minecraft:sea_lantern
setblock 178 25 353 minecraft:sea_lantern
setblock 178 25 355 minecraft:sea_lantern
setblock 178 25 357 minecraft:sea_lantern
setblock 178 25 359 minecraft:sea_lantern
setblock 178 25 361 minecraft:sea_lantern
setblock 179 25 323 minecraft:dark_prismarine
setblock 179 25 352 minecraft:sea_lantern
setblock 179 25 354 minecraft:sea_lantern
setblock 179 25 356 minecraft:sea_lantern
setblock 179 25 358 minecraft:sea_lantern
setblock 179 25 360 minecraft:sea_lantern
fill 180 25 323 180 28 323 minecraft:blue_terracotta
setblock 180 25 327 minecraft:dark_prismarine
fill 180 25 328 180 25 331 minecraft:blue_terracotta
setblock 180 25 332 minecraft:dark_prismarine
fill 180 25 333 180 28 333 minecraft:blue_terracotta
setblock 180 25 336 minecraft:blue_terracotta
setblock 180 25 351 minecraft:sea_lantern
setblock 180 25 353 minecraft:sea_lantern
setblock 180 25 355 minecraft:sea_lantern
setblock 180 25 357 minecraft:sea_lantern
setblock 180 25 359 minecraft:sea_lantern
setblock 180 25 361 minecraft:sea_lantern
fill 181 25 324 181 25 325 minecraft:blue_terracotta
setblock 181 25 326 minecraft:dark_prismarine
fill 181 25 327 181 25 330 minecraft:blue_terracotta
setblock 181 25 331 minecraft:dark_prismarine
fill 181 25 332 181 28 332 minecraft:blue_terracotta
setblock 181 25 336 minecraft:dark_prismarine
fill 181 25 337 181 28 337 minecraft:blue_terracotta
setblock 181 25 341 minecraft:dark_prismarine
fill 181 25 342 181 26 342 minecraft:blue_terracotta
setblock 181 25 346 minecraft:dark_prismarine
fill 181 25 347 181 27 347 minecraft:blue_terracotta
setblock 181 25 350 minecraft:blue_terracotta
setblock 181 25 351 minecraft:dark_prismarine
setblock 181 25 352 minecraft:sea_lantern
setblock 181 25 354 minecraft:sea_lantern
setblock 181 25 356 minecraft:sea_lantern
setblock 181 25 358 minecraft:sea_lantern
setblock 181 25 360 minecraft:sea_lantern
setblock 182 25 325 minecraft:dark_prismarine
fill 182 25 326 182 25 329 minecraft:blue_terracotta
setblock 182 25 330 minecraft:dark_prismarine
fill 182 25 331 182 28 331 minecraft:blue_terracotta
setblock 182 25 335 minecraft:dark_prismarine
fill 182 25 336 182 28 336 minecraft:blue_terracotta
setblock 182 25 340 minecraft:dark_prismarine
fill 182 25 341 182 28 341 minecraft:blue_terracotta
setblock 182 25 345 minecraft:dark_prismarine
fill 182 25 346 182 28 346 minecraft:blue_terracotta
setblock 182 25 350 minecraft:dark_prismarine
setblock 182 25 351 minecraft:sea_lantern
setblock 182 25 353 minecraft:sea_lantern
setblock 182 25 355 minecraft:sea_lantern
fill 182 25 356 182 28 356 minecraft:blue_terracotta
setblock 182 25 357 minecraft:sea_lantern
fill 182 25 358 182 26 358 minecraft:blue_terracotta
setblock 182 25 359 minecraft:sea_lantern
setblock 182 25 360 minecraft:purple_concrete
setblock 182 25 361 minecraft:sea_lantern
fill 183 25 345 183 131 345 minecraft:black_concrete
setblock 142 26 324 minecraft:dark_prismarine
fill 142 26 325 142 28 325 minecraft:blue_terracotta
setblock 142 26 329 minecraft:dark_prismarine
fill 142 26 330 142 28 330 minecraft:blue_terracotta
setblock 142 26 334 minecraft:dark_prismarine
fill 142 26 335 142 28 335 minecraft:blue_terracotta
setblock 142 26 338 minecraft:blue_terracotta
setblock 142 26 339 minecraft:dark_prismarine
fill 142 26 340 142 28 340 minecraft:blue_terracotta
fill 142 26 344 142 27 344 minecraft:dark_prismarine
fill 142 26 345 142 27 345 minecraft:blue_terracotta
setblock 142 26 349 minecraft:dark_prismarine
fill 142 26 350 142 28 350 minecraft:blue_terracotta
setblock 142 26 354 minecraft:dark_prismarine
fill 142 26 355 142 26 358 minecraft:blue_terracotta
setblock 142 26 359 minecraft:dark_prismarine
fill 142 26 360 143 28 360 minecraft:blue_terracotta
setblock 143 26 323 minecraft:dark_prismarine
fill 143 26 324 143 28 324 minecraft:blue_terracotta
setblock 143 26 328 minecraft:dark_prismarine
fill 143 26 329 143 28 329 minecraft:blue_terracotta
setblock 143 26 333 minecraft:dark_prismarine
fill 143 26 334 143 28 334 minecraft:blue_terracotta
setblock 143 26 338 minecraft:dark_prismarine
fill 143 26 346 143 28 346 minecraft:dark_prismarine
setblock 143 26 348 minecraft:dark_prismarine
fill 143 26 349 143 27 349 minecraft:blue_terracotta
setblock 143 26 352 minecraft:blue_terracotta
setblock 143 26 353 minecraft:dark_prismarine
fill 143 26 354 143 28 354 minecraft:blue_terracotta
setblock 143 26 358 minecraft:dark_prismarine
fill 143 26 359 143 28 359 minecraft:blue_terracotta
fill 143 26 361 143 26 362 minecraft:blue_terracotta
setblock 143 26 363 minecraft:dark_prismarine
fill 144 26 323 144 28 323 minecraft:blue_terracotta
setblock 144 26 327 minecraft:dark_prismarine
fill 144 26 328 144 28 328 minecraft:blue_terracotta
setblock 144 26 332 minecraft:dark_prismarine
fill 144 26 333 144 28 333 minecraft:blue_terracotta
setblock 144 26 352 minecraft:dark_prismarine
setblock 144 26 353 minecraft:blue_terracotta
setblock 144 26 355 minecraft:blue_terracotta
setblock 144 26 362 minecraft:dark_prismarine
fill 144 26 363 144 28 363 minecraft:blue_terracotta
setblock 145 26 326 minecraft:dark_prismarine
setblock 145 26 327 minecraft:blue_terracotta
setblock 145 26 331 minecraft:dark_prismarine
setblock 145 26 332 minecraft:blue_terracotta
fill 145 26 362 145 27 362 minecraft:blue_terracotta
setblock 146 26 325 minecraft:dark_prismarine
fill 146 26 347 146 26 348 minecraft:purple_concrete
setblock 147 26 324 minecraft:dark_prismarine
setblock 147 26 325 minecraft:blue_terracotta
setblock 148 26 323 minecraft:dark_prismarine
setblock 148 26 324 minecraft:blue_terracotta
fill 148 26 348 148 33 348 minecraft:magenta_terracotta
setblock 148 26 363 minecraft:dark_prismarine
fill 149 26 323 151 26 323 minecraft:blue_terracotta
fill 149 26 363 149 27 363 minecraft:blue_terracotta
fill 150 26 347 150 26 348 minecraft:purple_concrete
fill 151 26 346 151 26 347 minecraft:purple_concrete
setblock 155 26 363 minecraft:purple_concrete
setblock 158 26 363 minecraft:dark_prismarine
setblock 159 26 323 minecraft:blue_terracotta
fill 159 26 363 159 28 363 minecraft:blue_terracotta
setblock 160 26 362 minecraft:blue_terracotta
setblock 163 26 323 minecraft:dark_prismarine
setblock 163 26 363 minecraft:dark_prismarine
setblock 164 26 323 minecraft:blue_terracotta
setblock 164 26 362 minecraft:dark_prismarine
fill 164 26 363 164 28 363 minecraft:blue_terracotta
fill 167 26 358 167 27 358 minecraft:dark_prismarine
fill 174 26 351 174 28 351 minecraft:dark_prismarine
fill 174 26 353 174 28 353 minecraft:dark_prismarine
fill 174 26 355 174 28 355 minecraft:dark_prismarine
fill 174 26 357 174 28 357 minecraft:dark_prismarine
fill 174 26 359 174 28 359 minecraft:dark_prismarine
fill 174 26 361 174 28 361 minecraft:dark_prismarine
fill 175 26 352 175 28 352 minecraft:dark_prismarine
fill 175 26 354 175 28 354 minecraft:dark_prismarine
fill 175 26 356 175 28 356 minecraft:dark_prismarine
fill 175 26 358 175 28 358 minecraft:dark_prismarine
fill 175 26 360 175 28 360 minecraft:dark_prismarine
fill 176 26 351 176 33 351 minecraft:magenta_terracotta
fill 176 26 353 176 28 353 minecraft:dark_prismarine
fill 176 26 355 176 28 355 minecraft:dark_prismarine
fill 176 26 357 176 28 357 minecraft:dark_prismarine
fill 176 26 359 176 28 359 minecraft:dark_prismarine
fill 176 26 361 176 28 361 minecraft:dark_prismarine
fill 177 26 352 177 33 352 minecraft:magenta_terracotta
fill 177 26 354 177 28 354 minecraft:dark_prismarine
fill 177 26 356 177 28 356 minecraft:dark_prismarine
fill 177 26 358 177 28 358 minecraft:dark_prismarine
fill 177 26 360 177 28 360 minecraft:dark_prismarine
fill 178 26 351 178 33 351 minecraft:magenta_terracotta
fill 178 26 353 178 28 353 minecraft:dark_prismarine
fill 178 26 355 178 28 355 minecraft:dark_prismarine
fill 178 26 357 178 28 357 minecraft:dark_prismarine
fill 178 26 359 178 28 359 minecraft:dark_prismarine
fill 178 26 361 178 28 361 minecraft:dark_prismarine
fill 179 26 352 179 33 352 minecraft:magenta_terracotta
fill 179 26 354 179 28 354 minecraft:dark_prismarine
fill 179 26 356 179 28 356 minecraft:dark_prismarine
fill 179 26 358 179 28 358 minecraft:dark_prismarine
fill 179 26 360 179 28 360 minecraft:dark_prismarine
fill 180 26 327 180 26 330 minecraft:blue_terracotta
setblock 180 26 331 minecraft:dark_prismarine
fill 180 26 332 180 28 332 minecraft:blue_terracotta
fill 180 26 334 180 26 335 minecraft:blue_terracotta
setblock 180 26 336 minecraft:dark_prismarine
fill 180 26 351 180 28 351 minecraft:dark_prismarine
fill 180 26 353 180 28 353 minecraft:dark_prismarine
fill 180 26 355 181 26 355 minecraft:dark_prismarine
fill 180 26 357 180 28 357 minecraft:dark_prismarine
fill 180 26 359 180 28 359 minecraft:dark_prismarine
fill 180 26 361 180 28 361 minecraft:dark_prismarine
setblock 180 26 363 minecraft:purple_concrete
setblock 181 26 324 minecraft:blue_terracotta
setblock 181 26 325 minecraft:dark_prismarine
fill 181 26 326 181 26 329 minecraft:blue_terracotta
setblock 181 26 330 minecraft:dark_prismarine
fill 181 26 331 181 28 331 minecraft:blue_terracotta
setblock 181 26 334 minecraft:blue_terracotta
setblock 181 26 335 minecraft:dark_prismarine
fill 181 26 336 181 28 336 minecraft:blue_terracotta
setblock 181 26 340 minecraft:dark_prismarine
fill 181 26 341 181 28 341 minecraft:blue_terracotta
setblock 181 26 345 minecraft:dark_prismarine
fill 181 26 346 181 27 346 minecraft:blue_terracotta
setblock 181 26 350 minecraft:dark_prismarine
fill 181 26 351 181 28 352 minecraft:blue_terracotta
setblock 181 26 354 minecraft:blue_terracotta
fill 181 26 356 181 28 356 minecraft:blue_terracotta
fill 181 26 358 181 28 358 minecraft:dark_prismarine
fill 181 26 360 182 26 360 minecraft:dark_prismarine
setblock 182 26 324 minecraft:dark_prismarine
fill 182 26 325 182 26 328 minecraft:blue_terracotta
setblock 182 26 329 minecraft:dark_prismarine
fill 182 26 330 182 28 330 minecraft:blue_terracotta
setblock 182 26 334 minecraft:dark_prismarine
fill 182 26 335 182 28 335 minecraft:blue_terracotta
setblock 182 26 339 minecraft:dark_prismarine
fill 182 26 340 182 28 340 minecraft:blue_terracotta
setblock 182 26 344 minecraft:dark_prismarine
fill 182 26 345 182 28 345 minecraft:blue_terracotta
setblock 182 26 349 minecraft:dark_prismarine
fill 182 26 350 182 28 351 minecraft:blue_terracotta
setblock 182 26 353 minecraft:blue_terracotta
setblock 182 26 354 minecraft:dark_prismarine
fill 182 26 355 182 28 355 minecraft:blue_terracotta
fill 182 26 357 182 27 357 minecraft:blue_terracotta
setblock 182 26 359 minecraft:dark_prismarine
fill 182 26 361 182 27 361 minecraft:dark_prismarine
setblock 142 27 323 minecraft:dark_prismarine
fill 142 27 324 142 28 324 minecraft:blue_terracotta
setblock 142 27 328 minecraft:dark_prismarine
fill 142 27 329 142 28 329 minecraft:blue_terracotta
setblock 142 27 333 minecraft:dark_prismarine
fill 142 27 334 142 28 334 minecraft:blue_terracotta
setblock 142 27 338 minecraft:dark_prismarine
fill 142 27 339 142 28 339 minecraft:blue_terracotta
fill 142 27 342 142 28 343 minecraft:dark_prismarine
setblock 142 27 348 minecraft:dark_prismarine
fill 142 27 349 142 28 349 minecraft:blue_terracotta
setblock 142 27 353 minecraft:dark_prismarine
fill 142 27 354 142 27 357 minecraft:blue_terracotta
setblock 142 27 358 minecraft:dark_prismarine
fill 142 27 359 142 28 359 minecraft:blue_terracotta
setblock 142 27 363 minecraft:dark_prismarine
fill 143 27 323 143 28 323 minecraft:blue_terracotta
setblock 143 27 327 minecraft:dark_prismarine
fill 143 27 328 143 28 328 minecraft:blue_terracotta
setblock 143 27 332 minecraft:dark_prismarine
fill 143 27 333 143 28 333 minecraft:blue_terracotta
setblock 143 27 337 minecraft:dark_prismarine
setblock 143 27 338 minecraft:blue_terracotta
setblock 143 27 352 minecraft:dark_prismarine
fill 143 27 353 143 28 353 minecraft:blue_terracotta
setblock 143 27 356 minecraft:blue_terracotta
setblock 143 27 357 minecraft:dark_prismarine
fill 143 27 358 143 28 358 minecraft:blue_terracotta
setblock 143 27 361 minecraft:blue_terracotta
fill 143 27 363 143 28 363 minecraft:blue_terracotta
setblock 144 27 326 minecraft:dark_prismarine
fill 144 27 327 144 28 327 minecraft:blue_terracotta
setblock 144 27 331 minecraft:dark_prismarine
fill 144 27 332 144 28 332 minecraft:blue_terracotta
setblock 144 27 362 minecraft:blue_terracotta
setblock 145 27 325 minecraft:dark_prismarine
setblock 145 27 330 minecraft:dark_prismarine
setblock 145 27 331 minecraft:blue_terracotta
setblock 146 27 324 minecraft:dark_prismarine
setblock 146 27 347 minecraft:purple_concrete
setblock 147 27 323 minecraft:dark_prismarine
setblock 147 27 324 minecraft:blue_terracotta
setblock 147 27 363 minecraft:dark_prismarine
fill 148 27 323 149 27 323 minecraft:blue_terracotta
setblock 148 27 337 minecraft:magenta_terracotta
fill 148 27 363 148 28 363 minecraft:blue_terracotta
fill 149 27 337 150 28 337 minecraft:dark_prismarine
setblock 150 27 347 minecraft:purple_concrete
setblock 157 27 323 minecraft:purple_concrete
setblock 157 27 363 minecraft:dark_prismarine
fill 158 27 363 158 28 363 minecraft:blue_terracotta
setblock 162 27 323 minecraft:dark_prismarine
setblock 162 27 363 minecraft:dark_prismarine
setblock 163 27 323 minecraft:blue_terracotta
setblock 163 27 362 minecraft:dark_prismarine
fill 163 27 363 163 28 363 minecraft:blue_terracotta
fill 167 27 363 167 28 363 minecraft:purple_concrete
fill 180 27 327 180 27 329 minecraft:blue_terracotta
setblock 180 27 330 minecraft:dark_prismarine
fill 180 27 331 180 28 331 minecraft:blue_terracotta
setblock 180 27 334 minecraft:blue_terracotta
setblock 180 27 335 minecraft:dark_prismarine
fill 180 27 336 180 28 337 minecraft:blue_terracotta
fill 180 27 355 180 28 355 minecraft:dark_prismarine
setblock 181 27 324 minecraft:dark_prismarine
fill 181 27 325 181 27 328 minecraft:blue_terracotta
setblock 181 27 329 minecraft:dark_prismarine
fill 181 27 330 181 28 330 minecraft:blue_terracotta
setblock 181 27 334 minecraft:dark_prismarine
fill 181 27 335 181 28 335 minecraft:blue_terracotta
setblock 181 27 339 minecraft:dark_prismarine
fill 181 27 340 181 28 340 minecraft:blue_terracotta
setblock 181 27 349 minecraft:dark_prismarine
fill 181 27 350 181 28 350 minecraft:blue_terracotta
setblock 181 27 354 minecraft:dark_prismarine
fill 181 27 355 181 28 355 minecraft:blue_terracotta
fill 181 27 360 181 28 360 minecraft:dark_prismarine
setblock 182 27 323 minecraft:dark_prismarine
fill 182 27 324 182 27 327 minecraft:blue_terracotta
setblock 182 27 328 minecraft:dark_prismarine
fill 182 27 329 182 28 329 minecraft:blue_terracotta
setblock 182 27 333 minecraft:dark_prismarine
fill 182 27 334 182 28 334 minecraft:blue_terracotta
setblock 182 27 338 minecraft:dark_prismarine
fill 182 27 339 182 28 339 minecraft:blue_terracotta
setblock 182 27 343 minecraft:dark_prismarine
fill 182 27 344 182 28 344 minecraft:blue_terracotta
setblock 182 27 348 minecraft:dark_prismarine
fill 182 27 349 182 28 349 minecraft:blue_terracotta
setblock 182 27 353 minecraft:dark_prismarine
fill 182 27 354 182 28 354 minecraft:blue_terracotta
setblock 182 27 358 minecraft:dark_prismarine
fill 182 27 359 182 28 360 minecraft:blue_terracotta
setblock 142 28 323 minecraft:blue_terracotta
setblock 142 28 327 minecraft:dark_prismarine
setblock 142 28 328 minecraft:blue_terracotta
setblock 142 28 332 minecraft:dark_prismarine
setblock 142 28 333 minecraft:blue_terracotta
setblock 142 28 337 minecraft:dark_prismarine
setblock 142 28 338 minecraft:blue_terracotta
setblock 142 28 341 minecraft:dark_prismarine
setblock 142 28 344 minecraft:purple_concrete
fill 142 28 345 142 28 347 minecraft:dark_prismarine
setblock 142 28 348 minecraft:blue_terracotta
setblock 142 28 352 minecraft:dark_prismarine
fill 142 28 353 142 28 356 minecraft:blue_terracotta
setblock 142 28 357 minecraft:dark_prismarine
setblock 142 28 358 minecraft:blue_terracotta
setblock 142 28 362 minecraft:dark_prismarine
setblock 142 28 363 minecraft:blue_terracotta
setblock 143 28 326 minecraft:dark_prismarine
setblock 143 28 327 minecraft:blue_terracotta
setblock 143 28 331 minecraft:dark_prismarine
setblock 143 28 332 minecraft:blue_terracotta
setblock 143 28 336 minecraft:dark_prismarine
setblock 143 28 337 minecraft:blue_terracotta
setblock 143 28 338 minecraft:dark_prismarine
setblock 143 28 351 minecraft:dark_prismarine
setblock 143 28 352 minecraft:blue_terracotta
setblock 143 28 356 minecraft:dark_prismarine
setblock 143 28 357 minecraft:blue_terracotta
setblock 143 28 361 minecraft:dark_prismarine
setblock 144 28 326 minecraft:blue_terracotta
setblock 144 28 330 minecraft:dark_prismarine
setblock 144 28 331 minecraft:blue_terracotta
setblock 144 28 335 minecraft:dark_prismarine
setblock 145 28 324 minecraft:dark_prismarine
setblock 146 28 323 minecraft:dark_prismarine
setblock 146 28 324 minecraft:blue_terracotta
setblock 146 28 363 minecraft:dark_prismarine
fill 147 28 323 148 28 323 minecraft:blue_terracotta
setblock 147 28 363 minecraft:blue_terracotta
setblock 148 28 337 minecraft:dark_prismarine
setblock 151 28 323 minecraft:purple_concrete
setblock 157 28 363 minecraft:blue_terracotta
setblock 161 28 363 minecraft:dark_prismarine
setblock 162 28 362 minecraft:dark_prismarine
setblock 162 28 363 minecraft:blue_terracotta
setblock 173 28 363 minecraft:purple_concrete
setblock 176 28 323 minecraft:purple_concrete
setblock 180 28 328 minecraft:blue_terracotta
setblock 180 28 329 minecraft:dark_prismarine
setblock 180 28 330 minecraft:blue_terracotta
setblock 180 28 334 minecraft:dark_prismarine
setblock 180 28 335 minecraft:blue_terracotta
setblock 181 28 323 minecraft:dark_prismarine
fill 181 28 325 181 28 327 minecraft:blue_terracotta
setblock 181 28 328 minecraft:dark_prismarine
setblock 181 28 329 minecraft:blue_terracotta
setblock 181 28 333 minecraft:dark_prismarine
setblock 181 28 334 minecraft:blue_terracotta
setblock 181 28 338 minecraft:dark_prismarine
setblock 181 28 339 minecraft:blue_terracotta
setblock 181 28 349 minecraft:blue_terracotta
setblock 181 28 353 minecraft:dark_prismarine
setblock 181 28 354 minecraft:blue_terracotta
fill 182 28 323 182 28 326 minecraft:blue_terracotta
setblock 182 28 327 minecraft:dark_prismarine
setblock 182 28 328 minecraft:blue_terracotta
setblock 182 28 332 minecraft:dark_prismarine
setblock 182 28 333 minecraft:blue_terracotta
setblock 182 28 337 minecraft:dark_prismarine
setblock 182 28 338 minecraft:blue_terracotta
setblock 182 28 342 minecraft:dark_prismarine
setblock 182 28 343 minecraft:blue_terracotta
setblock 182 28 347 minecraft:dark_prismarine
setblock 182 28 348 minecraft:blue_terracotta
setblock 182 28 352 minecraft:dark_prismarine
setblock 182 28 353 minecraft:blue_terracotta
setblock 182 28 357 minecraft:dark_prismarine
setblock 182 28 358 minecraft:blue_terracotta
setblock 182 28 361 minecraft:purple_concrete
setblock 183 28 359 minecraft:light_blue_wool
setblock 144 29 325 minecraft:light[level=13]
setblock 144 29 332 minecraft:light[level=12]
setblock 144 29 333 minecraft:light[level=13]
setblock 144 29 339 minecraft:light[level=12]
setblock 144 29 341 minecraft:light[level=13]
setblock 144 29 346 minecraft:light[level=12]
setblock 144 29 349 minecraft:light[level=13]
setblock 144 29 353 minecraft:light[level=12]
setblock 144 29 357 minecraft:light[level=13]
setblock 144 29 360 minecraft:light[level=12]
setblock 146 29 322 minecraft:cyan_concrete
setblock 151 29 325 minecraft:light[level=12]
setblock 151 29 332 minecraft:light[level=12]
setblock 151 29 339 minecraft:light[level=12]
setblock 151 29 346 minecraft:light[level=12]
setblock 151 29 353 minecraft:light[level=12]
setblock 151 29 360 minecraft:light[level=12]
setblock 152 29 325 minecraft:light[level=13]
setblock 152 29 333 minecraft:light[level=13]
setblock 152 29 341 minecraft:light[level=13]
setblock 152 29 349 minecraft:light[level=13]
setblock 152 29 357 minecraft:light[level=13]
setblock 158 29 325 minecraft:light[level=12]
setblock 158 29 332 minecraft:light[level=12]
setblock 158 29 339 minecraft:light[level=12]
setblock 158 29 346 minecraft:light[level=12]
setblock 158 29 353 minecraft:light[level=12]
setblock 158 29 360 minecraft:light[level=12]
setblock 160 29 325 minecraft:light[level=13]
setblock 160 29 333 minecraft:light[level=13]
setblock 160 29 341 minecraft:light[level=13]
setblock 160 29 349 minecraft:light[level=13]
setblock 160 29 357 minecraft:light[level=13]
fill 161 29 330 161 33 330 minecraft:magenta_terracotta
setblock 162 29 322 minecraft:light_blue_wool
setblock 165 29 325 minecraft:light[level=12]
setblock 165 29 332 minecraft:light[level=12]
setblock 165 29 339 minecraft:light[level=12]
setblock 165 29 346 minecraft:light[level=12]
setblock 165 29 353 minecraft:light[level=12]
setblock 165 29 360 minecraft:light[level=12]
setblock 168 29 325 minecraft:light[level=13]
setblock 168 29 333 minecraft:light[level=13]
setblock 168 29 341 minecraft:light[level=13]
setblock 168 29 349 minecraft:light[level=13]
setblock 168 29 357 minecraft:light[level=13]
setblock 172 29 325 minecraft:light[level=12]
setblock 172 29 332 minecraft:light[level=12]
setblock 172 29 339 minecraft:light[level=12]
setblock 172 29 346 minecraft:light[level=12]
setblock 172 29 353 minecraft:light[level=12]
setblock 172 29 360 minecraft:light[level=12]
setblock 176 29 325 minecraft:light[level=13]
setblock 176 29 333 minecraft:light[level=13]
fill 176 29 338 176 33 338 minecraft:magenta_terracotta
setblock 176 29 341 minecraft:light[level=13]
setblock 176 29 357 minecraft:light[level=13]
setblock 179 29 325 minecraft:light[level=12]
setblock 179 29 332 minecraft:light[level=12]
setblock 179 29 339 minecraft:light[level=12]
setblock 179 29 346 minecraft:light[level=12]
setblock 179 29 353 minecraft:light[level=12]
setblock 179 29 360 minecraft:light[level=12]
fill 183 29 323 183 50 326 minecraft:black_concrete
setblock 183 29 327 minecraft:cyan_concrete
fill 183 29 328 183 117 329 minecraft:black_concrete
fill 183 29 359 183 129 359 minecraft:black_concrete
fill 146 30 322 146 131 322 minecraft:black_concrete
fill 162 30 322 162 132 322 minecraft:black_concrete
fill 177 30 337 177 33 337 minecraft:magenta_terracotta
fill 183 30 327 183 35 327 minecraft:black_concrete
fill 148 31 337 148 33 337 minecraft:magenta_terracotta
setblock 149 33 350 minecraft:pink_terracotta
setblock 159 33 327 minecraft:magenta_terracotta
setblock 160 33 329 minecraft:pink_terracotta
setblock 162 33 357 minecraft:magenta_terracotta
setblock 164 33 355 minecraft:magenta_terracotta
setblock 164 33 357 minecraft:pink_terracotta
setblock 175 33 336 minecraft:pink_terracotta
setblock 178 33 350 minecraft:pink_terracotta
fill 142 34 323 142 35 323 minecraft:light_blue_stained_glass
fill 142 34 324 142 35 324 minecraft:white_stained_glass
fill 142 34 325 142 35 329 minecraft:blue_stained_glass
fill 142 34 330 142 35 332 minecraft:light_blue_stained_glass
fill 142 34 333 142 35 334 minecraft:white_stained_glass
fill 142 34 335 142 35 355 minecraft:blue_stained_glass
fill 142 34 356 142 35 356 minecraft:white_stained_glass
fill 142 34 357 142 35 360 minecraft:light_blue_stained_glass
fill 142 34 361 142 35 363 minecraft:blue_stained_glass
fill 143 34 323 143 35 323 minecraft:white_stained_glass
fill 143 34 324 143 35 327 minecraft:blue_stained_glass
fill 143 34 328 143 35 330 minecraft:light_blue_stained_glass
fill 143 34 331 143 35 332 minecraft:white_stained_glass
fill 143 34 333 143 35 339 minecraft:blue_stained_glass
fill 143 34 340 144 35 349 minecraft:light_blue_stained_glass
fill 143 34 350 143 35 357 minecraft:blue_stained_glass
fill 143 34 358 143 35 358 minecraft:white_stained_glass
fill 143 34 359 143 35 361 minecraft:light_blue_stained_glass
fill 143 34 362 143 35 363 minecraft:blue_stained_glass
fill 144 34 323 144 35 326 minecraft:blue_stained_glass
fill 144 34 327 144 35 329 minecraft:light_blue_stained_glass
fill 144 34 330 144 35 330 minecraft:white_stained_glass
fill 144 34 331 144 35 336 minecraft:blue_stained_glass
fill 144 34 337 145 35 339 minecraft:light_blue_stained_glass
fill 144 34 350 145 35 352 minecraft:light_blue_stained_glass
fill 144 34 353 144 35 358 minecraft:blue_stained_glass
fill 144 34 359 144 35 360 minecraft:white_stained_glass
fill 144 34 361 144 35 363 minecraft:light_blue_stained_glass
fill 145 34 323 145 35 325 minecraft:blue_stained_glass
fill 145 34 326 145 35 328 minecraft:light_blue_stained_glass
fill 145 34 329 145 35 329 minecraft:white_stained_glass
fill 145 34 330 145 35 334 minecraft:blue_stained_glass
fill 145 34 335 146 35 336 minecraft:light_blue_stained_glass
fill 145 34 340 145 35 349 minecraft:white_stained_glass
fill 145 34 353 146 35 354 minecraft:light_blue_stained_glass
fill 145 34 355 145 35 360 minecraft:blue_stained_glass
fill 145 34 361 145 35 361 minecraft:white_stained_glass
fill 145 34 362 145 35 363 minecraft:light_blue_stained_glass
fill 146 34 323 146 35 324 minecraft:blue_stained_glass
fill 146 34 325 146 35 327 minecraft:light_blue_stained_glass
fill 146 34 328 146 35 328 minecraft:white_stained_glass
fill 146 34 329 146 35 332 minecraft:blue_stained_glass
fill 146 34 333 147 35 334 minecraft:light_blue_stained_glass
fill 146 34 337 146 35 339 minecraft:white_stained_glass
fill 146 34 340 147 35 350 minecraft:blue_stained_glass
fill 146 34 351 146 35 352 minecraft:white_stained_glass
fill 146 34 355 147 35 356 minecraft:light_blue_stained_glass
fill 146 34 357 146 35 361 minecraft:blue_stained_glass
fill 146 34 362 146 35 362 minecraft:white_stained_glass
fill 146 34 363 146 35 363 minecraft:light_blue_stained_glass
fill 147 34 323 148 35 323 minecraft:blue_stained_glass
fill 147 34 324 147 35 326 minecraft:light_blue_stained_glass
fill 147 34 327 147 35 327 minecraft:white_stained_glass
fill 147 34 328 147 35 331 minecraft:blue_stained_glass
fill 147 34 332 149 35 332 minecraft:light_blue_stained_glass
fill 147 34 335 147 35 336 minecraft:white_stained_glass
fill 147 34 337 148 35 339 minecraft:blue_stained_glass
fill 147 34 351 149 35 352 minecraft:blue_stained_glass
fill 147 34 353 147 35 354 minecraft:white_stained_glass
fill 147 34 357 148 35 358 minecraft:light_blue_stained_glass
fill 147 34 359 147 35 362 minecraft:blue_stained_glass
fill 147 34 363 147 35 363 minecraft:white_stained_glass
fill 148 34 324 148 35 325 minecraft:light_blue_stained_glass
fill 148 34 326 148 35 326 minecraft:white_stained_glass
fill 148 34 327 148 35 330 minecraft:blue_stained_glass
fill 148 34 331 150 35 331 minecraft:light_blue_stained_glass
fill 148 34 333 148 35 333 minecraft:light_blue_stained_glass
fill 148 34 334 148 35 334 minecraft:white_stained_glass
fill 148 34 335 150 35 336 minecraft:blue_stained_glass
fill 148 34 340 148 35 343 minecraft:blue_stained_glass
fill 148 34 344 149 35 345 minecraft:light_blue_stained_glass
fill 148 34 346 148 35 350 minecraft:blue_stained_glass
fill 148 34 353 150 35 354 minecraft:blue_stained_glass
fill 148 34 355 148 35 356 minecraft:white_stained_glass
fill 148 34 359 150 35 359 minecraft:light_blue_stained_glass
fill 148 34 360 148 35 363 minecraft:blue_stained_glass
fill 149 34 323 150 35 324 minecraft:light_blue_stained_glass
fill 149 34 325 150 35 325 minecraft:white_stained_glass
fill 149 34 326 149 35 329 minecraft:blue_stained_glass
fill 149 34 330 151 35 330 minecraft:light_blue_stained_glass
fill 149 34 333 149 35 333 minecraft:white_stained_glass
fill 149 34 334 152 35 334 minecraft:blue_stained_glass
fill 149 34 337 149 35 338 minecraft:blue_stained_glass
fill 149 34 339 149 35 343 minecraft:light_blue_stained_glass
fill 149 34 346 149 35 350 minecraft:light_blue_stained_glass
fill 149 34 355 151 35 356 minecraft:blue_stained_glass
fill 149 34 357 149 35 357 minecraft:white_stained_glass
fill 149 34 358 149 35 358 minecraft:light_blue_stained_glass
fill 149 34 360 151 35 360 minecraft:light_blue_stained_glass
fill 149 34 361 149 35 363 minecraft:blue_stained_glass
fill 150 34 326 150 35 328 minecraft:blue_stained_glass
fill 150 34 329 152 35 329 minecraft:light_blue_stained_glass
fill 150 34 332 150 35 332 minecraft:white_stained_glass
fill 150 34 333 153 35 333 minecraft:blue_stained_glass
fill 150 34 337 150 35 342 minecraft:light_blue_stained_glass
fill 150 34 343 150 35 346 minecraft:white_stained_glass
fill 150 34 347 150 35 352 minecraft:light_blue_stained_glass
fill 150 34 357 153 35 357 minecraft:blue_stained_glass
fill 150 34 358 150 35 358 minecraft:white_stained_glass
fill 150 34 361 152 35 361 minecraft:light_blue_stained_glass
fill 150 34 362 150 35 363 minecraft:blue_stained_glass
fill 151 34 323 152 35 323 minecraft:light_blue_stained_glass
fill 151 34 324 152 35 324 minecraft:white_stained_glass
fill 151 34 325 152 35 327 minecraft:blue_stained_glass
fill 151 34 328 154 35 328 minecraft:light_blue_stained_glass
fill 151 34 331 151 35 331 minecraft:white_stained_glass
fill 151 34 332 154 35 332 minecraft:blue_stained_glass
fill 151 34 335 151 35 335 minecraft:blue_stained_glass
fill 151 34 336 151 35 339 minecraft:light_blue_stained_glass
fill 151 34 340 151 35 341 minecraft:white_stained_glass
fill 151 34 342 153 35 347 minecraft:blue_stained_glass
fill 151 34 348 151 35 350 minecraft:white_stained_glass
fill 151 34 351 151 35 354 minecraft:light_blue_stained_glass
fill 151 34 358 154 35 358 minecraft:blue_stained_glass
fill 151 34 359 151 35 359 minecraft:white_stained_glass
fill 151 34 362 153 35 362 minecraft:light_blue_stained_glass
fill 151 34 363 152 35 363 minecraft:blue_stained_glass
fill 152 34 330 152 35 330 minecraft:white_stained_glass
fill 152 34 331 156 35 331 minecraft:blue_stained_glass
fill 152 34 335 152 35 337 minecraft:light_blue_stained_glass
fill 152 34 338 152 35 338 minecraft:white_stained_glass
fill 152 34 339 154 35 341 minecraft:blue_stained_glass
fill 152 34 348 153 35 350 minecraft:blue_stained_glass
fill 152 34 351 152 35 352 minecraft:white_stained_glass
fill 152 34 353 152 35 355 minecraft:light_blue_stained_glass
fill 152 34 356 152 35 356 minecraft:blue_stained_glass
fill 152 34 359 155 35 359 minecraft:blue_stained_glass
fill 152 34 360 152 35 360 minecraft:white_stained_glass
fill 153 34 323 154 35 323 minecraft:white_stained_glass
fill 153 34 324 154 35 326 minecraft:blue_stained_glass
fill 153 34 327 157 35 327 minecraft:light_blue_stained_glass
fill 153 34 329 154 35 329 minecraft:white_stained_glass
fill 153 34 330 169 35 330 minecraft:blue_stained_glass
fill 153 34 334 153 35 335 minecraft:light_blue_stained_glass
fill 153 34 336 153 35 337 minecraft:white_stained_glass
fill 153 34 338 155 35 338 minecraft:blue_stained_glass
fill 153 34 351 155 35 352 minecraft:blue_stained_glass
fill 153 34 353 153 35 353 minecraft:white_stained_glass
fill 153 34 354 153 35 356 minecraft:light_blue_stained_glass
fill 153 34 360 157 35 360 minecraft:blue_stained_glass
fill 153 34 361 153 35 361 minecraft:white_stained_glass
fill 153 34 363 155 35 363 minecraft:light_blue_stained_glass
fill 154 34 333 155 35 334 minecraft:light_blue_stained_glass
fill 154 34 335 154 35 336 minecraft:white_stained_glass
fill 154 34 337 156 35 337 minecraft:blue_stained_glass
fill 154 34 342 155 35 348 minecraft:light_blue_stained_glass
fill 154 34 349 154 35 350 minecraft:blue_stained_glass
fill 154 34 353 157 35 353 minecraft:blue_stained_glass
fill 154 34 354 154 35 354 minecraft:white_stained_glass
fill 154 34 355 154 35 357 minecraft:light_blue_stained_glass
fill 154 34 361 159 35 361 minecraft:blue_stained_glass
fill 154 34 362 155 35 362 minecraft:white_stained_glass
fill 155 34 323 157 35 325 minecraft:blue_stained_glass
fill 155 34 326 168 35 326 minecraft:light_blue_stained_glass
fill 155 34 328 156 35 328 minecraft:white_stained_glass
fill 155 34 329 168 35 329 minecraft:blue_stained_glass
fill 155 34 332 160 35 332 minecraft:light_blue_stained_glass
fill 155 34 335 155 35 335 minecraft:white_stained_glass
fill 155 34 336 158 35 336 minecraft:blue_stained_glass
fill 155 34 339 155 35 339 minecraft:blue_stained_glass
fill 155 34 340 156 35 341 minecraft:light_blue_stained_glass
fill 155 34 349 156 35 350 minecraft:light_blue_stained_glass
fill 155 34 354 158 35 354 minecraft:blue_stained_glass
fill 155 34 355 155 35 355 minecraft:white_stained_glass
fill 155 34 356 155 35 358 minecraft:light_blue_stained_glass
fill 156 34 333 156 35 333 minecraft:light_blue_stained_glass
fill 156 34 334 156 35 334 minecraft:white_stained_glass
fill 156 34 335 167 35 335 minecraft:blue_stained_glass
fill 156 34 338 157 35 339 minecraft:light_blue_stained_glass
fill 156 34 342 156 35 348 minecraft:white_stained_glass
fill 156 34 351 157 35 351 minecraft:light_blue_stained_glass
fill 156 34 352 156 35 352 minecraft:blue_stained_glass
fill 156 34 355 159 35 355 minecraft:blue_stained_glass
fill 156 34 356 156 35 356 minecraft:white_stained_glass
fill 156 34 357 156 35 359 minecraft:light_blue_stained_glass
fill 156 34 362 163 35 362 minecraft:blue_stained_glass
fill 156 34 363 157 35 363 minecraft:white_stained_glass
fill 157 34 328 165 35 328 minecraft:blue_stained_glass
fill 157 34 331 166 35 331 minecraft:light_blue_stained_glass
fill 157 34 333 159 35 333 minecraft:white_stained_glass
fill 157 34 334 165 35 334 minecraft:blue_stained_glass
fill 157 34 337 165 35 337 minecraft:light_blue_stained_glass
fill 157 34 340 157 35 340 minecraft:white_stained_glass
fill 157 34 341 158 35 348 minecraft:blue_stained_glass
fill 157 34 349 157 35 349 minecraft:white_stained_glass
fill 157 34 350 157 35 350 minecraft:light_blue_stained_glass
fill 157 34 352 158 35 352 minecraft:light_blue_stained_glass
fill 157 34 356 162 35 356 minecraft:blue_stained_glass
fill 157 34 357 157 35 357 minecraft:white_stained_glass
fill 157 34 358 157 35 359 minecraft:light_blue_stained_glass
fill 158 34 323 168 35 324 minecraft:blue_stained_glass
fill 158 34 325 165 35 325 minecraft:light_blue_stained_glass
fill 158 34 327 165 35 327 minecraft:white_stained_glass
fill 158 34 338 158 35 338 minecraft:light_blue_stained_glass
fill 158 34 339 158 35 339 minecraft:white_stained_glass
fill 158 34 340 162 34 340 minecraft:blue_stained_glass
fill 158 34 349 160 35 349 minecraft:blue_stained_glass
fill 158 34 350 158 35 351 minecraft:white_stained_glass
fill 158 34 353 160 35 353 minecraft:light_blue_stained_glass
fill 158 34 357 175 35 357 minecraft:blue_stained_glass
fill 158 34 358 159 35 358 minecraft:white_stained_glass
fill 158 34 359 160 35 360 minecraft:light_blue_stained_glass
fill 158 34 363 175 35 363 minecraft:blue_stained_glass
fill 159 34 336 164 35 336 minecraft:light_blue_stained_glass
fill 159 34 338 160 35 338 minecraft:white_stained_glass
fill 159 34 339 164 34 339 minecraft:blue_stained_glass
fill 159 34 341 159 35 342 minecraft:blue_stained_glass
fill 159 34 343 160 35 346 minecraft:light_blue_stained_glass
fill 159 34 347 159 35 348 minecraft:blue_stained_glass
fill 159 34 350 162 35 351 minecraft:blue_stained_glass
fill 159 34 352 160 35 352 minecraft:white_stained_glass
fill 159 34 354 162 35 354 minecraft:light_blue_stained_glass
fill 159 34 364 164 54 364 minecraft:black_concrete
fill 160 34 333 163 35 333 minecraft:blue_stained_glass
fill 160 34 341 160 35 341 minecraft:blue_stained_glass
fill 160 34 342 161 34 342 minecraft:light_blue_stained_glass
fill 160 34 347 161 35 348 minecraft:light_blue_stained_glass
fill 160 34 355 173 35 355 minecraft:light_blue_stained_glass
fill 160 34 358 173 35 358 minecraft:blue_stained_glass
fill 160 34 361 173 35 361 minecraft:light_blue_stained_glass
fill 161 34 332 162 35 332 minecraft:white_stained_glass
fill 161 34 338 162 35 338 minecraft:blue_stained_glass
setblock 161 34 341 minecraft:light_blue_stained_glass
fill 161 34 343 161 34 346 minecraft:white_stained_glass
fill 161 34 349 164 35 349 minecraft:light_blue_stained_glass
fill 161 34 352 173 35 352 minecraft:blue_stained_glass
fill 161 34 353 161 35 353 minecraft:white_stained_glass
fill 161 34 359 162 35 359 minecraft:white_stained_glass
fill 161 34 360 163 35 360 minecraft:light_blue_stained_glass
fill 162 34 344 162 34 346 minecraft:blue_stained_glass
fill 162 34 347 162 35 347 minecraft:white_stained_glass
fill 162 34 348 162 35 348 minecraft:light_blue_stained_glass
fill 162 34 353 171 35 353 minecraft:blue_stained_glass
fill 163 34 332 167 35 332 minecraft:light_blue_stained_glass
fill 163 34 338 164 35 338 minecraft:white_stained_glass
fill 163 34 345 163 34 347 minecraft:blue_stained_glass
fill 163 34 348 163 35 348 minecraft:white_stained_glass
fill 163 34 350 171 35 350 minecraft:light_blue_stained_glass
fill 163 34 351 164 35 351 minecraft:blue_stained_glass
fill 163 34 354 171 35 354 minecraft:white_stained_glass
fill 163 34 356 171 35 356 minecraft:light_blue_stained_glass
fill 163 34 359 170 35 359 minecraft:blue_stained_glass
fill 164 34 333 165 35 333 minecraft:white_stained_glass
fill 164 34 345 169 34 345 minecraft:light_blue_stained_glass
fill 164 34 346 165 35 348 minecraft:blue_stained_glass
fill 164 34 360 169 35 360 minecraft:white_stained_glass
fill 164 34 362 169 35 362 minecraft:light_blue_stained_glass
fill 165 34 336 168 35 336 minecraft:blue_stained_glass
fill 165 34 338 166 35 338 minecraft:light_blue_stained_glass
setblock 165 34 339 minecraft:white_stained_glass
fill 165 34 349 168 35 349 minecraft:white_stained_glass
fill 165 34 351 168 35 351 minecraft:light_blue_stained_glass
setblock 165 34 364 minecraft:light_blue_wool
fill 166 34 325 172 35 325 minecraft:blue_stained_glass
fill 166 34 327 170 35 327 minecraft:light_blue_stained_glass
fill 166 34 328 167 35 328 minecraft:white_stained_glass
fill 166 34 333 169 35 333 minecraft:light_blue_stained_glass
fill 166 34 334 167 35 334 minecraft:white_stained_glass
fill 166 34 337 168 35 337 minecraft:blue_stained_glass
fill 166 34 339 166 34 340 minecraft:light_blue_stained_glass
fill 166 34 344 167 34 344 minecraft:white_stained_glass
fill 166 34 346 167 35 346 minecraft:light_blue_stained_glass
fill 166 34 347 169 35 348 minecraft:blue_stained_glass
fill 167 34 331 170 35 331 minecraft:blue_stained_glass
fill 167 34 338 167 34 343 minecraft:blue_stained_glass
fill 168 34 328 171 35 328 minecraft:light_blue_stained_glass
fill 168 34 332 171 35 332 minecraft:blue_stained_glass
fill 168 34 334 169 35 334 minecraft:light_blue_stained_glass
fill 168 34 335 168 35 335 minecraft:white_stained_glass
fill 168 34 338 168 35 342 minecraft:blue_stained_glass
fill 168 34 343 168 35 343 minecraft:white_stained_glass
fill 168 34 344 170 35 344 minecraft:light_blue_stained_glass
fill 168 34 346 172 35 346 minecraft:blue_stained_glass
fill 169 34 323 170 35 323 minecraft:white_stained_glass
fill 169 34 324 170 35 324 minecraft:blue_stained_glass
fill 169 34 326 173 35 326 minecraft:blue_stained_glass
fill 169 34 329 169 35 329 minecraft:white_stained_glass
fill 169 34 335 170 35 335 minecraft:light_blue_stained_glass
fill 169 34 336 169 35 337 minecraft:white_stained_glass
fill 169 34 338 169 35 341 minecraft:blue_stained_glass
fill 169 34 342 169 35 342 minecraft:white_stained_glass
fill 169 34 343 171 35 343 minecraft:light_blue_stained_glass
fill 169 34 349 172 35 349 minecraft:light_blue_stained_glass
fill 169 34 351 174 35 351 minecraft:blue_stained_glass
fill 170 34 329 172 35 329 minecraft:light_blue_stained_glass
fill 170 34 330 170 35 330 minecraft:white_stained_glass
fill 170 34 333 172 35 334 minecraft:blue_stained_glass
fill 170 34 336 171 35 338 minecraft:light_blue_stained_glass
fill 170 34 339 170 35 340 minecraft:white_stained_glass
fill 170 34 341 171 35 342 minecraft:light_blue_stained_glass
fill 170 34 345 172 35 345 minecraft:blue_stained_glass
fill 170 34 347 171 35 347 minecraft:blue_stained_glass
fill 170 34 348 171 35 348 minecraft:white_stained_glass
fill 170 34 360 175 35 360 minecraft:light_blue_stained_glass
fill 170 34 362 177 35 362 minecraft:blue_stained_glass
fill 171 34 323 174 35 323 minecraft:light_blue_stained_glass
fill 171 34 324 172 35 324 minecraft:white_stained_glass
fill 171 34 327 174 35 327 minecraft:blue_stained_glass
fill 171 34 330 173 35 330 minecraft:light_blue_stained_glass
fill 171 34 331 172 35 331 minecraft:white_stained_glass
fill 171 34 335 173 35 335 minecraft:blue_stained_glass
fill 171 34 339 171 35 340 minecraft:light_blue_stained_glass
fill 171 34 344 173 35 344 minecraft:blue_stained_glass
fill 171 34 359 173 35 359 minecraft:white_stained_glass
fill 172 34 328 175 35 328 minecraft:blue_stained_glass
fill 172 34 332 172 35 332 minecraft:white_stained_glass
fill 172 34 336 173 35 343 minecraft:blue_stained_glass
fill 172 34 347 172 35 347 minecraft:white_stained_glass
fill 172 34 348 173 35 348 minecraft:light_blue_stained_glass
fill 172 34 350 175 35 350 minecraft:blue_stained_glass
fill 172 34 353 173 35 353 minecraft:white_stained_glass
fill 172 34 354 175 35 354 minecraft:light_blue_stained_glass
fill 172 34 356 177 35 356 minecraft:blue_stained_glass
fill 173 34 324 175 35 324 minecraft:light_blue_stained_glass
fill 173 34 325 173 35 325 minecraft:white_stained_glass
fill 173 34 329 176 35 329 minecraft:blue_stained_glass
fill 173 34 331 174 35 332 minecraft:light_blue_stained_glass
fill 173 34 333 173 35 333 minecraft:white_stained_glass
fill 173 34 334 173 35 334 minecraft:blue_stained_glass
fill 173 34 345 173 35 346 minecraft:white_stained_glass
fill 173 34 347 174 35 347 minecraft:light_blue_stained_glass
fill 173 34 349 176 35 349 minecraft:blue_stained_glass
fill 174 34 325 176 35 325 minecraft:light_blue_stained_glass
fill 174 34 326 174 35 326 minecraft:white_stained_glass
fill 174 34 330 177 35 330 minecraft:blue_stained_glass
fill 174 34 333 175 35 333 minecraft:light_blue_stained_glass
fill 174 34 334 174 35 335 minecraft:white_stained_glass
fill 174 34 336 174 35 342 minecraft:blue_stained_glass
fill 174 34 343 174 35 344 minecraft:white_stained_glass
fill 174 34 345 175 35 346 minecraft:light_blue_stained_glass
fill 174 34 348 177 35 348 minecraft:blue_stained_glass
fill 174 34 352 174 35 352 minecraft:white_stained_glass
fill 174 34 353 176 35 353 minecraft:light_blue_stained_glass
fill 174 34 355 178 35 355 minecraft:blue_stained_glass
fill 174 34 358 175 35 358 minecraft:white_stained_glass
fill 174 34 359 177 35 359 minecraft:light_blue_stained_glass
fill 174 34 361 179 35 361 minecraft:blue_stained_glass
fill 175 34 323 178 35 323 minecraft:blue_stained_glass
fill 175 34 326 177 35 326 minecraft:light_blue_stained_glass
fill 175 34 327 175 35 327 minecraft:white_stained_glass
fill 175 34 331 177 35 331 minecraft:blue_stained_glass
fill 175 34 332 175 35 332 minecraft:light_blue_stained_glass
fill 175 34 334 176 35 336 minecraft:light_blue_stained_glass
fill 175 34 337 175 35 342 minecraft:white_stained_glass
fill 175 34 343 176 35 344 minecraft:light_blue_stained_glass
fill 175 34 347 178 35 347 minecraft:blue_stained_glass
fill 175 34 351 175 35 351 minecraft:white_stained_glass
fill 175 34 352 177 35 352 minecraft:light_blue_stained_glass
fill 176 34 324 179 35 324 minecraft:blue_stained_glass
fill 176 34 327 178 35 327 minecraft:light_blue_stained_glass
fill 176 34 328 176 35 328 minecraft:white_stained_glass
fill 176 34 332 178 35 333 minecraft:blue_stained_glass
fill 176 34 337 177 35 342 minecraft:light_blue_stained_glass
fill 176 34 345 176 35 345 minecraft:light_blue_stained_glass
fill 176 34 346 178 35 346 minecraft:blue_stained_glass
fill 176 34 350 176 35 350 minecraft:white_stained_glass
fill 176 34 351 178 35 351 minecraft:light_blue_stained_glass
fill 176 34 354 179 35 354 minecraft:blue_stained_glass
fill 176 34 357 177 35 357 minecraft:white_stained_glass
fill 176 34 358 179 35 358 minecraft:light_blue_stained_glass
fill 176 34 360 181 35 360 minecraft:blue_stained_glass
fill 176 34 363 177 35 363 minecraft:white_stained_glass
fill 177 34 325 180 35 325 minecraft:blue_stained_glass
fill 177 34 328 179 35 328 minecraft:light_blue_stained_glass
fill 177 34 329 177 35 329 minecraft:white_stained_glass
fill 177 34 334 179 35 336 minecraft:blue_stained_glass
fill 177 34 343 179 35 345 minecraft:blue_stained_glass
fill 177 34 349 177 35 349 minecraft:white_stained_glass
fill 177 34 350 179 35 350 minecraft:light_blue_stained_glass
fill 177 34 353 180 35 353 minecraft:blue_stained_glass
fill 178 34 326 181 35 326 minecraft:blue_stained_glass
fill 178 34 329 179 35 329 minecraft:light_blue_stained_glass
fill 178 34 330 178 35 331 minecraft:white_stained_glass
fill 178 34 337 179 35 342 minecraft:blue_stained_glass
fill 178 34 348 178 35 348 minecraft:white_stained_glass
fill 178 34 349 180 35 349 minecraft:light_blue_stained_glass
fill 178 34 352 181 35 352 minecraft:blue_stained_glass
fill 178 34 356 178 35 356 minecraft:white_stained_glass
fill 178 34 357 180 35 357 minecraft:light_blue_stained_glass
fill 178 34 359 182 35 359 minecraft:blue_stained_glass
fill 178 34 362 179 35 362 minecraft:white_stained_glass
fill 178 34 363 181 35 363 minecraft:light_blue_stained_glass
fill 179 34 323 179 35 323 minecraft:white_stained_glass
fill 179 34 327 181 35 327 minecraft:blue_stained_glass
fill 179 34 330 180 35 331 minecraft:light_blue_stained_glass
fill 179 34 332 179 35 333 minecraft:white_stained_glass
fill 179 34 346 179 35 347 minecraft:white_stained_glass
fill 179 34 348 180 35 348 minecraft:light_blue_stained_glass
fill 179 34 351 182 35 351 minecraft:blue_stained_glass
fill 179 34 355 179 35 355 minecraft:white_stained_glass
fill 179 34 356 181 35 356 minecraft:light_blue_stained_glass
fill 180 34 323 182 35 323 minecraft:light_blue_stained_glass
fill 180 34 324 180 35 324 minecraft:white_stained_glass
fill 180 34 328 182 35 329 minecraft:blue_stained_glass
fill 180 34 332 181 35 333 minecraft:light_blue_stained_glass
fill 180 34 334 180 35 338 minecraft:white_stained_glass
fill 180 34 339 180 35 340 minecraft:blue_stained_glass
fill 180 34 341 180 35 344 minecraft:white_stained_glass
fill 180 34 345 181 35 347 minecraft:light_blue_stained_glass
fill 180 34 350 182 35 350 minecraft:blue_stained_glass
fill 180 34 354 180 35 354 minecraft:white_stained_glass
fill 180 34 355 182 35 355 minecraft:light_blue_stained_glass
fill 180 34 358 182 35 358 minecraft:blue_stained_glass
fill 180 34 361 181 35 361 minecraft:white_stained_glass
fill 180 34 362 182 35 362 minecraft:light_blue_stained_glass
fill 181 34 324 182 35 324 minecraft:light_blue_stained_glass
fill 181 34 325 181 35 325 minecraft:white_stained_glass
fill 181 34 330 182 35 331 minecraft:blue_stained_glass
fill 181 34 334 182 35 344 minecraft:light_blue_stained_glass
fill 181 34 348 182 35 349 minecraft:blue_stained_glass
fill 181 34 353 181 35 353 minecraft:white_stained_glass
fill 181 34 354 182 35 354 minecraft:light_blue_stained_glass
fill 181 34 357 182 35 357 minecraft:blue_stained_glass
fill 182 34 325 182 35 325 minecraft:light_blue_stained_glass
fill 182 34 326 182 35 327 minecraft:white_stained_glass
fill 182 34 332 182 35 333 minecraft:blue_stained_glass
fill 182 34 345 182 35 347 minecraft:blue_stained_glass
fill 182 34 352 182 35 352 minecraft:white_stained_glass
fill 182 34 353 182 35 353 minecraft:light_blue_stained_glass
fill 182 34 356 182 35 356 minecraft:blue_stained_glass
fill 182 34 360 182 35 360 minecraft:white_stained_glass
fill 182 34 361 182 35 361 minecraft:light_blue_stained_glass
fill 182 34 363 182 35 363 minecraft:blue_stained_glass
fill 158 35 340 160 35 340 minecraft:blue_stained_glass
fill 159 35 339 161 35 339 minecraft:blue_stained_glass
setblock 160 35 342 minecraft:light_blue_stained_glass
fill 161 35 340 161 35 344 minecraft:sea_lantern
fill 161 35 345 161 35 346 minecraft:white_stained_glass
fill 162 35 339 162 35 340 minecraft:sea_lantern
fill 162 35 344 162 35 345 minecraft:sea_lantern
fill 162 35 346 163 35 346 minecraft:blue_stained_glass
fill 163 35 339 166 35 339 minecraft:sea_lantern
fill 163 35 345 166 35 345 minecraft:sea_lantern
setblock 163 35 347 minecraft:blue_stained_glass
fill 165 35 364 165 36 364 minecraft:black_concrete
fill 166 35 340 167 35 340 minecraft:sea_lantern
fill 166 35 344 167 35 344 minecraft:sea_lantern
fill 167 35 338 167 35 339 minecraft:blue_stained_glass
fill 167 35 341 167 35 343 minecraft:sea_lantern
fill 167 35 345 169 35 345 minecraft:light_blue_stained_glass
fill 145 36 334 148 43 337 minecraft:magenta_terracotta
fill 147 36 349 150 41 351 minecraft:magenta_terracotta
fill 148 36 348 149 66 348 minecraft:magenta_terracotta
fill 158 36 328 161 40 329 minecraft:magenta_terracotta
fill 159 36 327 161 42 327 minecraft:magenta_terracotta
fill 159 36 330 161 54 330 minecraft:magenta_terracotta
fill 162 36 357 166 39 357 minecraft:magenta_terracotta
fill 163 36 356 165 52 356 minecraft:magenta_terracotta
fill 163 36 358 165 37 359 minecraft:magenta_terracotta
fill 164 36 355 164 57 355 minecraft:magenta_terracotta
setblock 166 36 358 minecraft:magenta_terracotta
fill 174 36 335 176 43 338 minecraft:magenta_terracotta
fill 176 36 349 179 52 351 minecraft:magenta_terracotta
fill 177 36 335 177 58 337 minecraft:magenta_terracotta
fill 177 36 352 178 58 352 minecraft:magenta_terracotta
setblock 183 36 327 minecraft:light_blue_wool
setblock 144 37 325 minecraft:light[level=13]
setblock 144 37 333 minecraft:light[level=13]
setblock 144 37 341 minecraft:light[level=13]
setblock 144 37 349 minecraft:light[level=13]
setblock 144 37 357 minecraft:light[level=13]
setblock 152 37 325 minecraft:light[level=13]
setblock 152 37 333 minecraft:light[level=13]
setblock 152 37 341 minecraft:light[level=13]
setblock 152 37 349 minecraft:light[level=13]
setblock 152 37 357 minecraft:light[level=13]
setblock 160 37 325 minecraft:light[level=13]
setblock 160 37 333 minecraft:light[level=13]
setblock 160 37 341 minecraft:light[level=13]
setblock 160 37 349 minecraft:light[level=13]
setblock 160 37 357 minecraft:light[level=13]
fill 162 37 329 162 58 329 minecraft:magenta_terracotta
fill 162 37 358 162 81 358 minecraft:magenta_terracotta
setblock 165 37 364 minecraft:cyan_concrete
setblock 168 37 325 minecraft:light[level=13]
setblock 168 37 333 minecraft:light[level=13]
setblock 168 37 341 minecraft:light[level=13]
setblock 168 37 349 minecraft:light[level=13]
setblock 168 37 357 minecraft:light[level=13]
setblock 176 37 325 minecraft:light[level=13]
setblock 176 37 333 minecraft:light[level=13]
setblock 176 37 341 minecraft:light[level=13]
setblock 176 37 357 minecraft:light[level=13]
fill 183 37 327 183 64 327 minecraft:black_concrete
setblock 183 37 351 minecraft:light_blue_wool
setblock 141 38 363 minecraft:cyan_concrete
fill 162 38 356 162 58 356 minecraft:magenta_terracotta
fill 163 38 358 164 44 359 minecraft:magenta_terracotta
fill 165 38 358 165 48 358 minecraft:magenta_terracotta
fill 165 38 364 165 131 364 minecraft:black_concrete
fill 183 38 351 183 131 351 minecraft:black_concrete
fill 141 39 339 141 131 339 minecraft:black_concrete
setblock 141 39 340 minecraft:light_blue_wool
fill 141 39 341 141 73 343 minecraft:black_concrete
fill 141 39 363 141 42 363 minecraft:black_concrete
fill 142 39 323 142 39 325 minecraft:blue_terracotta
setblock 142 39 326 minecraft:dark_prismarine
fill 142 39 327 142 40 327 minecraft:blue_terracotta
setblock 142 39 328 minecraft:purple_concrete
fill 142 39 334 142 39 335 minecraft:blue_terracotta
setblock 142 39 336 minecraft:dark_prismarine
fill 142 39 337 142 39 340 minecraft:blue_terracotta
setblock 142 39 341 minecraft:dark_prismarine
fill 142 39 342 142 39 345 minecraft:blue_terracotta
setblock 142 39 347 minecraft:purple_concrete
fill 142 39 353 142 39 355 minecraft:blue_terracotta
setblock 142 39 356 minecraft:dark_prismarine
fill 142 39 357 142 39 360 minecraft:blue_terracotta
setblock 142 39 361 minecraft:dark_prismarine
fill 142 39 362 144 39 363 minecraft:blue_terracotta
fill 143 39 323 143 39 324 minecraft:blue_terracotta
fill 143 39 356 143 39 359 minecraft:blue_terracotta
setblock 143 39 360 minecraft:dark_prismarine
fill 143 39 361 146 39 361 minecraft:blue_terracotta
setblock 144 39 323 minecraft:blue_terracotta
setblock 144 39 359 minecraft:dark_prismarine
setblock 144 39 360 minecraft:blue_terracotta
setblock 145 39 323 minecraft:dark_prismarine
setblock 145 39 362 minecraft:blue_terracotta
setblock 145 39 363 minecraft:dark_prismarine
fill 146 39 323 149 39 323 minecraft:blue_terracotta
setblock 146 39 362 minecraft:dark_prismarine
fill 146 39 363 149 39 363 minecraft:blue_terracotta
fill 147 39 348 147 102 348 minecraft:magenta_terracotta
setblock 147 39 361 minecraft:dark_prismarine
fill 147 39 362 150 39 362 minecraft:blue_terracotta
fill 148 39 361 151 39 361 minecraft:blue_terracotta
setblock 150 39 323 minecraft:dark_prismarine
setblock 150 39 363 minecraft:dark_prismarine
fill 151 39 323 154 39 323 minecraft:blue_terracotta
setblock 151 39 362 minecraft:dark_prismarine
fill 151 39 363 154 39 363 minecraft:blue_terracotta
setblock 152 39 360 minecraft:blue_terracotta
setblock 152 39 361 minecraft:dark_prismarine
fill 152 39 362 155 39 362 minecraft:blue_terracotta
setblock 153 39 360 minecraft:dark_prismarine
fill 153 39 361 156 39 361 minecraft:blue_terracotta
fill 154 39 360 157 39 360 minecraft:blue_terracotta
setblock 155 39 323 minecraft:dark_prismarine
fill 155 39 324 157 40 324 minecraft:blue_terracotta
setblock 155 39 363 minecraft:dark_prismarine
fill 156 39 323 159 39 323 minecraft:blue_terracotta
setblock 156 39 362 minecraft:dark_prismarine
fill 156 39 363 159 39 363 minecraft:blue_terracotta
setblock 157 39 361 minecraft:dark_prismarine
fill 157 39 362 160 39 362 minecraft:blue_terracotta
setblock 158 39 360 minecraft:dark_prismarine
fill 158 39 361 161 39 361 minecraft:blue_terracotta
setblock 160 39 323 minecraft:dark_prismarine
setblock 160 39 363 minecraft:dark_prismarine
fill 161 39 323 162 40 323 minecraft:blue_terracotta
setblock 161 39 362 minecraft:dark_prismarine
fill 161 39 363 164 39 363 minecraft:blue_terracotta
fill 162 39 328 162 84 328 minecraft:magenta_terracotta
fill 162 39 362 163 39 362 minecraft:blue_terracotta
setblock 165 39 363 minecraft:dark_prismarine
setblock 169 39 323 minecraft:blue_terracotta
setblock 169 39 363 minecraft:blue_terracotta
setblock 170 39 323 minecraft:dark_prismarine
setblock 170 39 363 minecraft:dark_prismarine
fill 171 39 323 174 39 323 minecraft:blue_terracotta
fill 171 39 363 174 39 363 minecraft:blue_terracotta
fill 172 39 324 173 39 324 minecraft:blue_terracotta
fill 172 39 362 175 39 362 minecraft:blue_terracotta
setblock 174 39 324 minecraft:dark_prismarine
setblock 175 39 323 minecraft:dark_prismarine
fill 175 39 324 177 39 325 minecraft:blue_terracotta
fill 175 39 361 176 39 361 minecraft:blue_terracotta
setblock 175 39 363 minecraft:dark_prismarine
fill 176 39 323 179 39 323 minecraft:blue_terracotta
setblock 176 39 362 minecraft:dark_prismarine
fill 176 39 363 179 39 363 minecraft:blue_terracotta
setblock 177 39 361 minecraft:dark_prismarine
fill 177 39 362 180 39 362 minecraft:blue_terracotta
setblock 178 39 324 minecraft:blue_terracotta
setblock 178 39 325 minecraft:dark_prismarine
fill 178 39 361 181 39 361 minecraft:blue_terracotta
setblock 179 39 324 minecraft:dark_prismarine
fill 179 39 325 182 39 325 minecraft:blue_terracotta
fill 179 39 336 179 39 338 minecraft:blue_terracotta
setblock 179 39 339 minecraft:dark_prismarine
fill 179 39 340 182 39 340 minecraft:blue_terracotta
setblock 180 39 323 minecraft:dark_prismarine
fill 180 39 324 182 40 324 minecraft:blue_terracotta
fill 180 39 326 181 39 326 minecraft:blue_terracotta
setblock 180 39 333 minecraft:dark_prismarine
fill 180 39 334 180 39 337 minecraft:blue_terracotta
setblock 180 39 338 minecraft:dark_prismarine
fill 180 39 339 182 40 339 minecraft:blue_terracotta
fill 180 39 341 180 39 342 minecraft:blue_terracotta
fill 180 39 360 182 39 360 minecraft:blue_terracotta
setblock 180 39 363 minecraft:dark_prismarine
fill 181 39 323 182 41 323 minecraft:blue_terracotta
setblock 181 39 327 minecraft:dark_prismarine
fill 181 39 328 181 39 331 minecraft:blue_terracotta
setblock 181 39 332 minecraft:dark_prismarine
fill 181 39 333 181 39 336 minecraft:blue_terracotta
setblock 181 39 337 minecraft:dark_prismarine
fill 181 39 338 182 41 338 minecraft:blue_terracotta
setblock 181 39 341 minecraft:blue_terracotta
setblock 181 39 342 minecraft:dark_prismarine
fill 181 39 343 182 39 344 minecraft:blue_terracotta
fill 181 39 358 182 39 359 minecraft:blue_terracotta
setblock 181 39 362 minecraft:dark_prismarine
fill 181 39 363 182 41 363 minecraft:blue_terracotta
setblock 182 39 326 minecraft:dark_prismarine
fill 182 39 327 182 39 330 minecraft:blue_terracotta
setblock 182 39 331 minecraft:dark_prismarine
fill 182 39 332 182 39 335 minecraft:blue_terracotta
setblock 182 39 336 minecraft:dark_prismarine
fill 182 39 337 182 41 337 minecraft:blue_terracotta
setblock 182 39 341 minecraft:dark_prismarine
fill 182 39 342 182 42 342 minecraft:blue_terracotta
setblock 182 39 345 minecraft:blue_terracotta
setblock 182 39 356 minecraft:dark_prismarine
fill 182 39 357 182 40 357 minecraft:blue_terracotta
setblock 182 39 361 minecraft:dark_prismarine
fill 182 39 362 182 42 362 minecraft:blue_terracotta
setblock 183 39 361 minecraft:cyan_concrete
fill 141 40 340 141 131 340 minecraft:black_concrete
fill 142 40 323 142 40 324 minecraft:blue_terracotta
setblock 142 40 325 minecraft:dark_prismarine
fill 142 40 326 142 41 326 minecraft:blue_terracotta
setblock 142 40 334 minecraft:purple_concrete
fill 142 40 337 142 40 339 minecraft:blue_terracotta
setblock 142 40 340 minecraft:dark_prismarine
fill 142 40 341 142 40 344 minecraft:blue_terracotta
setblock 142 40 345 minecraft:dark_prismarine
setblock 142 40 355 minecraft:dark_prismarine
fill 142 40 356 142 40 359 minecraft:blue_terracotta
setblock 142 40 360 minecraft:dark_prismarine
fill 142 40 361 143 40 363 minecraft:blue_terracotta
setblock 143 40 323 minecraft:blue_terracotta
fill 143 40 357 143 40 358 minecraft:blue_terracotta
setblock 143 40 359 minecraft:dark_prismarine
fill 143 40 360 143 42 360 minecraft:blue_terracotta
setblock 144 40 323 minecraft:dark_prismarine
fill 144 40 361 144 40 362 minecraft:blue_terracotta
setblock 144 40 363 minecraft:dark_prismarine
fill 145 40 323 148 40 323 minecraft:blue_terracotta
setblock 145 40 361 minecraft:blue_terracotta
setblock 145 40 362 minecraft:dark_prismarine
fill 145 40 363 148 40 363 minecraft:blue_terracotta
fill 146 40 362 149 40 362 minecraft:blue_terracotta
fill 147 40 361 150 40 361 minecraft:blue_terracotta
setblock 149 40 323 minecraft:dark_prismarine
setblock 149 40 363 minecraft:dark_prismarine
fill 150 40 323 153 40 323 minecraft:blue_terracotta
setblock 150 40 362 minecraft:dark_prismarine
fill 150 40 363 153 40 363 minecraft:blue_terracotta
setblock 151 40 361 minecraft:dark_prismarine
fill 151 40 362 154 40 362 minecraft:blue_terracotta
fill 152 40 361 155 40 361 minecraft:blue_terracotta
fill 153 40 360 156 40 360 minecraft:blue_terracotta
setblock 154 40 323 minecraft:dark_prismarine
fill 154 40 324 154 43 324 minecraft:blue_terracotta
setblock 154 40 363 minecraft:dark_prismarine
fill 155 40 323 158 40 323 minecraft:blue_terracotta
setblock 155 40 362 minecraft:dark_prismarine
fill 155 40 363 158 40 363 minecraft:blue_terracotta
setblock 156 40 361 minecraft:dark_prismarine
fill 156 40 362 159 40 362 minecraft:blue_terracotta
setblock 157 40 360 minecraft:dark_prismarine
fill 157 40 361 160 40 361 minecraft:blue_terracotta
setblock 157 40 364 minecraft:cyan_concrete
setblock 159 40 323 minecraft:dark_prismarine
setblock 159 40 363 minecraft:dark_prismarine
fill 160 40 323 160 43 323 minecraft:blue_terracotta
fill 160 40 331 160 60 331 minecraft:magenta_terracotta
setblock 160 40 362 minecraft:dark_prismarine
fill 160 40 363 163 40 363 minecraft:blue_terracotta
fill 161 40 362 162 40 362 minecraft:blue_terracotta
fill 162 40 357 165 53 357 minecraft:magenta_terracotta
fill 163 40 355 163 73 355 minecraft:magenta_terracotta
setblock 164 40 363 minecraft:dark_prismarine
setblock 167 40 323 minecraft:purple_concrete
setblock 168 40 323 minecraft:blue_terracotta
setblock 168 40 363 minecraft:blue_terracotta
setblock 169 40 323 minecraft:dark_prismarine
setblock 169 40 363 minecraft:dark_prismarine
fill 170 40 323 173 40 323 minecraft:blue_terracotta
fill 170 40 363 173 40 363 minecraft:blue_terracotta
fill 171 40 324 172 40 324 minecraft:blue_terracotta
fill 172 40 362 174 40 362 minecraft:blue_terracotta
setblock 173 40 324 minecraft:dark_prismarine
setblock 174 40 323 minecraft:dark_prismarine
fill 174 40 324 176 40 325 minecraft:blue_terracotta
setblock 174 40 363 minecraft:dark_prismarine
fill 175 40 323 178 40 323 minecraft:blue_terracotta
setblock 175 40 361 minecraft:blue_terracotta
setblock 175 40 362 minecraft:dark_prismarine
fill 175 40 363 178 40 363 minecraft:blue_terracotta
setblock 176 40 361 minecraft:dark_prismarine
fill 176 40 362 179 40 362 minecraft:blue_terracotta
setblock 177 40 324 minecraft:blue_terracotta
setblock 177 40 325 minecraft:dark_prismarine
fill 177 40 361 180 40 361 minecraft:blue_terracotta
setblock 178 40 324 minecraft:dark_prismarine
fill 178 40 325 181 40 325 minecraft:blue_terracotta
setblock 179 40 323 minecraft:dark_prismarine
fill 179 40 324 179 43 324 minecraft:blue_terracotta
setblock 179 40 363 minecraft:dark_prismarine
fill 180 40 323 180 43 323 minecraft:blue_terracotta
setblock 180 40 326 minecraft:blue_terracotta
setblock 180 40 336 minecraft:blue_terracotta
setblock 180 40 337 minecraft:dark_prismarine
setblock 180 40 338 minecraft:blue_terracotta
fill 180 40 340 180 40 341 minecraft:blue_terracotta
setblock 180 40 362 minecraft:dark_prismarine
fill 180 40 363 180 43 363 minecraft:blue_terracotta
setblock 181 40 326 minecraft:dark_prismarine
fill 181 40 327 182 40 329 minecraft:blue_terracotta
fill 181 40 333 181 40 335 minecraft:blue_terracotta
setblock 181 40 336 minecraft:dark_prismarine
fill 181 40 337 181 41 337 minecraft:blue_terracotta
setblock 181 40 340 minecraft:blue_terracotta
setblock 181 40 341 minecraft:dark_prismarine
fill 181 40 342 181 40 343 minecraft:blue_terracotta
fill 181 40 359 181 40 360 minecraft:blue_terracotta
setblock 181 40 361 minecraft:dark_prismarine
fill 181 40 362 181 43 362 minecraft:blue_terracotta
setblock 182 40 325 minecraft:dark_prismarine
fill 182 40 326 182 43 326 minecraft:blue_terracotta
setblock 182 40 330 minecraft:dark_prismarine
fill 182 40 331 182 40 334 minecraft:blue_terracotta
setblock 182 40 335 minecraft:dark_prismarine
fill 182 40 336 182 41 336 minecraft:blue_terracotta
setblock 182 40 340 minecraft:dark_prismarine
fill 182 40 341 182 42 341 minecraft:blue_terracotta
fill 182 40 343 182 40 344 minecraft:blue_terracotta
setblock 182 40 345 minecraft:dark_prismarine
setblock 182 40 352 minecraft:purple_concrete
fill 182 40 358 182 40 359 minecraft:blue_terracotta
setblock 182 40 360 minecraft:dark_prismarine
fill 182 40 361 182 43 361 minecraft:blue_terracotta
fill 183 40 361 183 131 361 minecraft:black_concrete
setblock 142 41 323 minecraft:blue_terracotta
setblock 142 41 324 minecraft:dark_prismarine
fill 142 41 325 142 43 325 minecraft:blue_terracotta
fill 142 41 340 142 41 343 minecraft:blue_terracotta
setblock 142 41 344 minecraft:dark_prismarine
fill 142 41 356 142 41 358 minecraft:blue_terracotta
setblock 142 41 359 minecraft:dark_prismarine
fill 142 41 360 142 41 363 minecraft:blue_terracotta
setblock 143 41 323 minecraft:dark_prismarine
setblock 143 41 359 minecraft:blue_terracotta
fill 143 41 361 143 41 362 minecraft:blue_terracotta
setblock 143 41 363 minecraft:dark_prismarine
fill 144 41 323 147 41 323 minecraft:blue_terracotta
setblock 144 41 325 minecraft:light[level=12]
setblock 144 41 332 minecraft:light[level=12]
setblock 144 41 339 minecraft:light[level=12]
setblock 144 41 346 minecraft:light[level=12]
setblock 144 41 353 minecraft:light[level=12]
setblock 144 41 360 minecraft:light[level=12]
setblock 144 41 362 minecraft:dark_prismarine
fill 144 41 363 147 41 363 minecraft:blue_terracotta
fill 145 41 362 148 41 362 minecraft:blue_terracotta
setblock 148 41 323 minecraft:dark_prismarine
setblock 148 41 363 minecraft:dark_prismarine
fill 149 41 323 152 41 323 minecraft:blue_terracotta
setblock 149 41 361 minecraft:blue_terracotta
setblock 149 41 362 minecraft:dark_prismarine
fill 149 41 363 152 41 363 minecraft:blue_terracotta
setblock 150 41 361 minecraft:dark_prismarine
fill 150 41 362 153 41 362 minecraft:blue_terracotta
setblock 151 41 325 minecraft:light[level=12]
setblock 151 41 332 minecraft:light[level=12]
setblock 151 41 339 minecraft:light[level=12]
setblock 151 41 346 minecraft:light[level=12]
setblock 151 41 353 minecraft:light[level=12]
setblock 151 41 360 minecraft:light[level=12]
fill 151 41 361 154 41 361 minecraft:blue_terracotta
setblock 153 41 323 minecraft:dark_prismarine
setblock 153 41 363 minecraft:dark_prismarine
fill 154 41 323 157 41 323 minecraft:blue_terracotta
setblock 154 41 362 minecraft:dark_prismarine
fill 154 41 363 157 41 363 minecraft:blue_terracotta
fill 155 41 324 156 41 324 minecraft:blue_terracotta
setblock 155 41 361 minecraft:dark_prismarine
fill 155 41 362 158 41 362 minecraft:blue_terracotta
fill 156 41 361 158 41 361 minecraft:blue_terracotta
setblock 157 41 324 minecraft:dark_prismarine
fill 157 41 364 157 86 364 minecraft:black_concrete
setblock 158 41 323 minecraft:dark_prismarine
setblock 158 41 325 minecraft:light[level=12]
fill 158 41 329 161 42 329 minecraft:magenta_terracotta
setblock 158 41 332 minecraft:light[level=12]
setblock 158 41 339 minecraft:light[level=12]
setblock 158 41 346 minecraft:light[level=12]
setblock 158 41 353 minecraft:light[level=12]
setblock 158 41 360 minecraft:light[level=12]
setblock 158 41 363 minecraft:dark_prismarine
fill 159 41 323 159 44 323 minecraft:blue_terracotta
fill 159 41 328 161 52 328 minecraft:magenta_terracotta
setblock 159 41 362 minecraft:dark_prismarine
fill 159 41 363 162 41 363 minecraft:blue_terracotta
setblock 160 41 362 minecraft:blue_terracotta
setblock 161 41 323 minecraft:blue_terracotta
setblock 163 41 363 minecraft:dark_prismarine
setblock 165 41 325 minecraft:light[level=12]
setblock 165 41 332 minecraft:light[level=12]
setblock 165 41 339 minecraft:light[level=12]
setblock 165 41 346 minecraft:light[level=12]
setblock 165 41 353 minecraft:light[level=12]
setblock 165 41 360 minecraft:light[level=12]
setblock 168 41 323 minecraft:dark_prismarine
fill 169 41 323 172 41 323 minecraft:blue_terracotta
fill 169 41 363 172 41 363 minecraft:blue_terracotta
setblock 171 41 324 minecraft:blue_terracotta
setblock 172 41 324 minecraft:dark_prismarine
setblock 172 41 325 minecraft:light[level=12]
setblock 172 41 332 minecraft:light[level=12]
setblock 172 41 339 minecraft:light[level=12]
setblock 172 41 346 minecraft:light[level=12]
setblock 172 41 353 minecraft:light[level=12]
setblock 172 41 360 minecraft:light[level=12]
fill 172 41 362 173 41 362 minecraft:blue_terracotta
setblock 173 41 323 minecraft:dark_prismarine
fill 173 41 324 175 41 325 minecraft:blue_terracotta
setblock 173 41 363 minecraft:dark_prismarine
fill 174 41 323 177 41 323 minecraft:blue_terracotta
setblock 174 41 362 minecraft:dark_prismarine
fill 174 41 363 177 41 363 minecraft:blue_terracotta
fill 175 41 362 178 41 362 minecraft:blue_terracotta
setblock 176 41 324 minecraft:blue_terracotta
setblock 176 41 325 minecraft:dark_prismarine
fill 176 41 361 178 41 361 minecraft:blue_terracotta
setblock 177 41 324 minecraft:dark_prismarine
fill 177 41 325 180 41 325 minecraft:blue_terracotta
fill 177 41 338 177 102 338 minecraft:magenta_terracotta
setblock 178 41 323 minecraft:dark_prismarine
fill 178 41 324 178 44 324 minecraft:blue_terracotta
setblock 178 41 363 minecraft:dark_prismarine
fill 179 41 323 179 44 323 minecraft:blue_terracotta
setblock 179 41 332 minecraft:light[level=12]
setblock 179 41 339 minecraft:light[level=12]
setblock 179 41 346 minecraft:light[level=12]
setblock 179 41 353 minecraft:light[level=12]
setblock 179 41 360 minecraft:light[level=12]
setblock 179 41 362 minecraft:dark_prismarine
fill 179 41 363 179 44 363 minecraft:blue_terracotta
fill 180 41 324 181 41 324 minecraft:blue_terracotta
fill 180 41 362 180 43 362 minecraft:blue_terracotta
setblock 181 41 325 minecraft:dark_prismarine
fill 181 41 326 181 41 327 minecraft:blue_terracotta
setblock 181 41 339 minecraft:blue_terracotta
setblock 181 41 340 minecraft:dark_prismarine
fill 181 41 341 181 41 342 minecraft:blue_terracotta
setblock 181 41 360 minecraft:dark_prismarine
fill 181 41 361 181 42 361 minecraft:blue_terracotta
setblock 182 41 324 minecraft:dark_prismarine
fill 182 41 325 182 44 325 minecraft:blue_terracotta
fill 182 41 327 182 41 328 minecraft:blue_terracotta
setblock 182 41 329 minecraft:dark_prismarine
setblock 182 41 330 minecraft:blue_terracotta
setblock 182 41 334 minecraft:dark_prismarine
setblock 182 41 335 minecraft:blue_terracotta
setblock 182 41 339 minecraft:dark_prismarine
fill 182 41 340 182 42 340 minecraft:blue_terracotta
setblock 182 41 343 minecraft:blue_terracotta
setblock 182 41 344 minecraft:dark_prismarine
setblock 182 41 346 minecraft:purple_concrete
setblock 182 41 358 minecraft:blue_terracotta
setblock 182 41 359 minecraft:dark_prismarine
fill 182 41 360 182 43 360 minecraft:blue_terracotta
fill 141 42 326 141 67 328 minecraft:black_concrete
setblock 141 42 329 minecraft:light_blue_wool
fill 141 42 330 141 70 331 minecraft:black_concrete
setblock 142 42 323 minecraft:dark_prismarine
fill 142 42 324 142 45 324 minecraft:blue_terracotta
setblock 142 42 327 minecraft:purple_concrete
setblock 142 42 346 minecraft:purple_concrete
setblock 142 42 357 minecraft:blue_terracotta
setblock 142 42 358 minecraft:dark_prismarine
fill 142 42 359 142 42 362 minecraft:blue_terracotta
setblock 142 42 363 minecraft:dark_prismarine
fill 143 42 323 146 42 323 minecraft:blue_terracotta
setblock 143 42 361 minecraft:blue_terracotta
setblock 143 42 362 minecraft:dark_prismarine
fill 143 42 363 146 42 363 minecraft:blue_terracotta
fill 144 42 362 147 42 362 minecraft:blue_terracotta
setblock 147 42 323 minecraft:dark_prismarine
fill 147 42 349 149 56 351 minecraft:magenta_terracotta
setblock 147 42 363 minecraft:dark_prismarine
fill 148 42 323 151 42 323 minecraft:blue_terracotta
setblock 148 42 362 minecraft:dark_prismarine
fill 148 42 363 151 42 363 minecraft:blue_terracotta
fill 149 42 362 152 42 362 minecraft:blue_terracotta
fill 150 42 349 150 50 350 minecraft:magenta_terracotta
fill 150 42 361 153 42 361 minecraft:blue_terracotta
setblock 152 42 323 minecraft:dark_prismarine
setblock 152 42 363 minecraft:dark_prismarine
fill 153 42 323 153 44 324 minecraft:blue_terracotta
setblock 153 42 362 minecraft:dark_prismarine
fill 153 42 363 156 42 363 minecraft:blue_terracotta
fill 154 42 323 156 42 323 minecraft:blue_terracotta
setblock 154 42 361 minecraft:dark_prismarine
fill 154 42 362 157 42 362 minecraft:blue_terracotta
setblock 155 42 324 minecraft:blue_terracotta
fill 155 42 361 157 42 361 minecraft:blue_terracotta
setblock 156 42 324 minecraft:dark_prismarine
setblock 157 42 323 minecraft:dark_prismarine
setblock 157 42 363 minecraft:dark_prismarine
fill 158 42 323 158 45 323 minecraft:blue_terracotta
setblock 158 42 362 minecraft:dark_prismarine
fill 158 42 363 161 42 363 minecraft:blue_terracotta
setblock 159 42 362 minecraft:blue_terracotta
fill 162 42 330 162 97 330 minecraft:magenta_terracotta
setblock 162 42 363 minecraft:dark_prismarine
setblock 167 42 323 minecraft:dark_prismarine
fill 168 42 323 171 42 323 minecraft:blue_terracotta
fill 169 42 363 171 42 363 minecraft:blue_terracotta
fill 169 42 364 171 99 364 minecraft:black_concrete
setblock 170 42 324 minecraft:blue_terracotta
setblock 171 42 324 minecraft:dark_prismarine
setblock 172 42 323 minecraft:dark_prismarine
fill 172 42 324 175 42 324 minecraft:blue_terracotta
setblock 172 42 362 minecraft:blue_terracotta
setblock 172 42 363 minecraft:dark_prismarine
setblock 172 42 364 minecraft:light_blue_wool
fill 173 42 323 176 42 323 minecraft:blue_terracotta
fill 173 42 325 174 42 325 minecraft:blue_terracotta
setblock 173 42 362 minecraft:dark_prismarine
fill 173 42 363 176 42 363 minecraft:blue_terracotta
fill 173 42 364 175 51 364 minecraft:black_concrete
fill 174 42 362 177 42 362 minecraft:blue_terracotta
setblock 175 42 325 minecraft:dark_prismarine
setblock 176 42 324 minecraft:dark_prismarine
fill 176 42 325 179 42 325 minecraft:blue_terracotta
setblock 177 42 323 minecraft:dark_prismarine
fill 177 42 324 177 45 324 minecraft:blue_terracotta
setblock 177 42 363 minecraft:dark_prismarine
fill 178 42 323 178 45 323 minecraft:blue_terracotta
setblock 178 42 362 minecraft:dark_prismarine
fill 178 42 363 178 45 363 minecraft:blue_terracotta
fill 179 42 362 179 44 362 minecraft:blue_terracotta
setblock 180 42 324 minecraft:blue_terracotta
setblock 181 42 323 minecraft:blue_terracotta
setblock 181 42 324 minecraft:dark_prismarine
fill 181 42 325 181 43 326 minecraft:blue_terracotta
setblock 181 42 363 minecraft:blue_terracotta
setblock 182 42 323 minecraft:dark_prismarine
fill 182 42 324 182 45 324 minecraft:blue_terracotta
setblock 182 42 327 minecraft:blue_terracotta
setblock 182 42 328 minecraft:dark_prismarine
setblock 182 42 339 minecraft:blue_terracotta
setblock 182 42 343 minecraft:dark_prismarine
setblock 182 42 359 minecraft:blue_terracotta
setblock 182 42 363 minecraft:dark_prismarine
fill 183 42 355 183 131 355 minecraft:black_concrete
setblock 183 42 356 minecraft:cyan_concrete
setblock 183 42 362 minecraft:light_blue_wool
fill 141 43 329 141 101 329 minecraft:black_concrete
setblock 141 43 363 minecraft:light_blue_wool
fill 142 43 323 145 43 323 minecraft:blue_terracotta
setblock 142 43 333 minecraft:purple_concrete
setblock 142 43 352 minecraft:purple_concrete
fill 142 43 358 142 43 361 minecraft:blue_terracotta
setblock 142 43 362 minecraft:dark_prismarine
fill 142 43 363 145 43 363 minecraft:blue_terracotta
setblock 143 43 322 minecraft:cyan_concrete
fill 143 43 362 146 43 362 minecraft:blue_terracotta
fill 144 43 322 144 127 322 minecraft:black_concrete
setblock 146 43 323 minecraft:dark_prismarine
setblock 146 43 363 minecraft:dark_prismarine
fill 147 43 323 150 43 323 minecraft:blue_terracotta
setblock 147 43 362 minecraft:dark_prismarine
fill 147 43 363 150 43 363 minecraft:blue_terracotta
fill 148 43 362 151 43 362 minecraft:blue_terracotta
fill 150 43 364 153 100 364 minecraft:black_concrete
setblock 151 43 323 minecraft:dark_prismarine
fill 151 43 361 152 43 361 minecraft:blue_terracotta
setblock 151 43 363 minecraft:dark_prismarine
fill 152 43 323 152 46 323 minecraft:blue_terracotta
setblock 152 43 362 minecraft:dark_prismarine
fill 152 43 363 155 43 363 minecraft:blue_terracotta
setblock 153 43 361 minecraft:dark_prismarine
fill 153 43 362 156 43 362 minecraft:blue_terracotta
fill 154 43 323 155 43 323 minecraft:blue_terracotta
fill 154 43 361 155 43 361 minecraft:blue_terracotta
setblock 154 43 364 minecraft:light_blue_wool
setblock 155 43 324 minecraft:dark_prismarine
setblock 156 43 323 minecraft:dark_prismarine
setblock 156 43 363 minecraft:dark_prismarine
fill 157 43 323 157 46 323 minecraft:blue_terracotta
setblock 157 43 362 minecraft:dark_prismarine
fill 157 43 363 160 43 363 minecraft:blue_terracotta
setblock 158 43 362 minecraft:blue_terracotta
fill 159 43 329 161 56 329 minecraft:magenta_terracotta
fill 160 43 327 161 48 327 minecraft:magenta_terracotta
fill 167 43 323 170 43 323 minecraft:blue_terracotta
fill 169 43 363 170 43 363 minecraft:blue_terracotta
setblock 170 43 324 minecraft:dark_prismarine
setblock 171 43 323 minecraft:dark_prismarine
fill 171 43 324 174 43 324 minecraft:blue_terracotta
setblock 171 43 363 minecraft:dark_prismarine
fill 172 43 323 175 43 323 minecraft:blue_terracotta
fill 172 43 325 173 43 325 minecraft:blue_terracotta
setblock 172 43 362 minecraft:dark_prismarine
fill 172 43 363 175 43 363 minecraft:blue_terracotta
fill 172 43 364 172 131 364 minecraft:black_concrete
fill 173 43 362 176 43 362 minecraft:blue_terracotta
setblock 174 43 325 minecraft:dark_prismarine
setblock 175 43 324 minecraft:dark_prismarine
fill 175 43 325 178 43 325 minecraft:blue_terracotta
setblock 176 43 323 minecraft:dark_prismarine
fill 176 43 324 176 46 324 minecraft:blue_terracotta
setblock 176 43 363 minecraft:dark_prismarine
fill 177 43 323 177 46 323 minecraft:blue_terracotta
setblock 177 43 362 minecraft:dark_prismarine
fill 177 43 363 177 46 363 minecraft:blue_terracotta
fill 178 43 362 178 44 362 minecraft:blue_terracotta
setblock 179 43 325 minecraft:dark_prismarine
setblock 180 43 324 minecraft:dark_prismarine
setblock 181 43 323 minecraft:dark_prismarine
fill 181 43 324 181 46 324 minecraft:blue_terracotta
setblock 181 43 363 minecraft:dark_prismarine
fill 182 43 323 182 46 323 minecraft:blue_terracotta
setblock 182 43 327 minecraft:dark_prismarine
setblock 182 43 334 minecraft:purple_concrete
setblock 182 43 353 minecraft:purple_concrete
setblock 182 43 362 minecraft:dark_prismarine
fill 182 43 363 182 46 363 minecraft:blue_terracotta
setblock 183 43 352 minecraft:light_blue_wool
fill 183 43 356 183 131 356 minecraft:black_concrete
fill 183 43 362 183 131 362 minecraft:black_concrete
fill 141 44 363 141 129 363 minecraft:black_concrete
fill 142 44 323 144 44 323 minecraft:blue_terracotta
setblock 142 44 339 minecraft:purple_concrete
setblock 142 44 358 minecraft:purple_concrete
setblock 142 44 360 minecraft:blue_terracotta
setblock 142 44 361 minecraft:dark_prismarine
fill 142 44 362 142 46 363 minecraft:blue_terracotta
fill 143 44 322 143 113 322 minecraft:black_concrete
fill 143 44 363 144 44 363 minecraft:blue_terracotta
setblock 145 44 323 minecraft:dark_prismarine
fill 145 44 335 148 44 337 minecraft:magenta_terracotta
setblock 145 44 363 minecraft:dark_prismarine
fill 146 44 323 149 44 323 minecraft:blue_terracotta
fill 146 44 334 148 67 334 minecraft:magenta_terracotta
fill 146 44 363 149 44 363 minecraft:blue_terracotta
fill 147 44 362 150 44 362 minecraft:blue_terracotta
setblock 150 44 323 minecraft:dark_prismarine
setblock 150 44 363 minecraft:dark_prismarine
fill 151 44 323 151 47 323 minecraft:blue_terracotta
setblock 151 44 362 minecraft:dark_prismarine
fill 151 44 363 154 44 363 minecraft:blue_terracotta
fill 152 44 362 155 44 362 minecraft:blue_terracotta
setblock 154 44 323 minecraft:blue_terracotta
setblock 154 44 324 minecraft:dark_prismarine
fill 154 44 364 154 131 364 minecraft:black_concrete
setblock 155 44 323 minecraft:dark_prismarine
setblock 155 44 363 minecraft:dark_prismarine
fill 156 44 323 156 47 323 minecraft:blue_terracotta
setblock 156 44 362 minecraft:dark_prismarine
fill 156 44 363 159 44 363 minecraft:blue_terracotta
fill 161 44 331 161 77 331 minecraft:magenta_terracotta
setblock 162 44 323 minecraft:purple_concrete
setblock 162 44 363 minecraft:purple_concrete
fill 167 44 323 169 44 323 minecraft:blue_terracotta
setblock 169 44 324 minecraft:dark_prismarine
setblock 169 44 363 minecraft:blue_terracotta
setblock 170 44 323 minecraft:dark_prismarine
fill 170 44 324 173 44 324 minecraft:blue_terracotta
setblock 170 44 363 minecraft:dark_prismarine
fill 171 44 323 174 44 323 minecraft:blue_terracotta
fill 171 44 325 172 44 325 minecraft:blue_terracotta
fill 171 44 363 174 44 363 minecraft:blue_terracotta
setblock 173 44 325 minecraft:dark_prismarine
fill 173 44 362 175 44 362 minecraft:blue_terracotta
setblock 174 44 324 minecraft:dark_prismarine
fill 174 44 325 177 44 325 minecraft:blue_terracotta
fill 174 44 336 176 44 338 minecraft:magenta_terracotta
setblock 175 44 323 minecraft:dark_prismarine
fill 175 44 324 175 47 324 minecraft:blue_terracotta
fill 175 44 335 176 56 335 minecraft:magenta_terracotta
setblock 175 44 363 minecraft:dark_prismarine
fill 176 44 323 176 47 323 minecraft:blue_terracotta
setblock 176 44 362 minecraft:dark_prismarine
fill 176 44 363 176 47 363 minecraft:blue_terracotta
fill 177 44 362 177 45 362 minecraft:blue_terracotta
setblock 178 44 325 minecraft:dark_prismarine
setblock 179 44 324 minecraft:dark_prismarine
setblock 180 44 323 minecraft:dark_prismarine
fill 180 44 324 180 47 324 minecraft:blue_terracotta
setblock 180 44 363 minecraft:dark_prismarine
fill 181 44 323 181 47 323 minecraft:blue_terracotta
fill 181 44 325 181 45 325 minecraft:blue_terracotta
fill 181 44 363 181 47 363 minecraft:blue_terracotta
setblock 182 44 326 minecraft:dark_prismarine
fill 182 44 327 182 47 327 minecraft:blue_terracotta
setblock 182 44 328 minecraft:purple_concrete
setblock 182 44 347 minecraft:purple_concrete
setblock 182 44 361 minecraft:dark_prismarine
fill 182 44 362 182 45 362 minecraft:blue_terracotta
fill 183 44 352 183 92 352 minecraft:black_concrete
fill 142 45 323 143 45 323 minecraft:blue_terracotta
setblock 142 45 345 minecraft:purple_concrete
fill 142 45 361 142 46 361 minecraft:blue_terracotta
setblock 143 45 363 minecraft:blue_terracotta
setblock 144 45 323 minecraft:dark_prismarine
setblock 144 45 325 minecraft:light[level=13]
setblock 144 45 333 minecraft:light[level=13]
setblock 144 45 341 minecraft:light[level=13]
setblock 144 45 349 minecraft:light[level=13]
setblock 144 45 357 minecraft:light[level=13]
setblock 144 45 363 minecraft:dark_prismarine
fill 145 45 323 148 45 323 minecraft:blue_terracotta
fill 145 45 335 148 58 336 minecraft:magenta_terracotta
fill 145 45 363 148 45 363 minecraft:blue_terracotta
fill 146 45 337 148 75 337 minecraft:magenta_terracotta
fill 148 45 362 149 45 362 minecraft:blue_terracotta
setblock 149 45 323 minecraft:dark_prismarine
setblock 149 45 363 minecraft:dark_prismarine
fill 150 45 323 150 48 323 minecraft:blue_terracotta
setblock 150 45 362 minecraft:dark_prismarine
fill 150 45 363 153 45 363 minecraft:blue_terracotta
fill 151 45 362 154 45 362 minecraft:blue_terracotta
setblock 152 45 324 minecraft:blue_terracotta
setblock 152 45 325 minecraft:light[level=13]
setblock 152 45 333 minecraft:light[level=13]
setblock 152 45 341 minecraft:light[level=13]
setblock 152 45 349 minecraft:light[level=13]
setblock 152 45 357 minecraft:light[level=13]
setblock 153 45 323 minecraft:blue_terracotta
setblock 153 45 324 minecraft:dark_prismarine
setblock 154 45 323 minecraft:dark_prismarine
fill 154 45 324 154 48 324 minecraft:blue_terracotta
setblock 154 45 363 minecraft:dark_prismarine
fill 155 45 323 155 48 323 minecraft:blue_terracotta
setblock 155 45 362 minecraft:dark_prismarine
fill 155 45 363 158 45 363 minecraft:blue_terracotta
setblock 160 45 325 minecraft:light[level=13]
setblock 160 45 333 minecraft:light[level=13]
setblock 160 45 341 minecraft:light[level=13]
setblock 160 45 349 minecraft:light[level=13]
setblock 160 45 357 minecraft:light[level=13]
fill 163 45 358 164 60 358 minecraft:magenta_terracotta
fill 166 45 323 168 45 323 minecraft:blue_terracotta
setblock 168 45 324 minecraft:dark_prismarine
setblock 168 45 325 minecraft:light[level=13]
setblock 168 45 333 minecraft:light[level=13]
setblock 168 45 341 minecraft:light[level=13]
setblock 168 45 349 minecraft:light[level=13]
setblock 168 45 357 minecraft:light[level=13]
setblock 168 45 363 minecraft:purple_concrete
setblock 169 45 323 minecraft:dark_prismarine
fill 169 45 324 172 45 324 minecraft:blue_terracotta
setblock 169 45 363 minecraft:dark_prismarine
fill 170 45 323 173 45 323 minecraft:blue_terracotta
fill 170 45 363 173 45 363 minecraft:blue_terracotta
setblock 171 45 325 minecraft:blue_terracotta
setblock 172 45 325 minecraft:dark_prismarine
setblock 173 45 324 minecraft:dark_prismarine
fill 173 45 325 176 45 325 minecraft:blue_terracotta
fill 173 45 362 174 45 362 minecraft:blue_terracotta
setblock 174 45 323 minecraft:dark_prismarine
fill 174 45 324 174 48 324 minecraft:blue_terracotta
fill 174 45 336 176 53 337 minecraft:magenta_terracotta
setblock 174 45 363 minecraft:dark_prismarine
fill 175 45 323 175 48 323 minecraft:blue_terracotta
fill 175 45 338 176 74 338 minecraft:magenta_terracotta
setblock 175 45 362 minecraft:dark_prismarine
fill 175 45 363 175 48 363 minecraft:blue_terracotta
setblock 176 45 333 minecraft:light[level=13]
setblock 176 45 341 minecraft:light[level=13]
setblock 176 45 357 minecraft:light[level=13]
setblock 176 45 362 minecraft:blue_terracotta
setblock 177 45 325 minecraft:dark_prismarine
setblock 178 45 324 minecraft:dark_prismarine
fill 178 45 325 178 48 325 minecraft:blue_terracotta
setblock 179 45 323 minecraft:dark_prismarine
fill 179 45 324 179 48 324 minecraft:blue_terracotta
setblock 179 45 363 minecraft:dark_prismarine
fill 180 45 323 180 48 323 minecraft:blue_terracotta
fill 180 45 363 180 48 363 minecraft:blue_terracotta
setblock 182 45 325 minecraft:dark_prismarine
fill 182 45 326 182 48 326 minecraft:blue_terracotta
setblock 182 45 341 minecraft:purple_concrete
setblock 142 46 323 minecraft:blue_terracotta
setblock 142 46 324 minecraft:dark_prismarine
setblock 142 46 326 minecraft:purple_concrete
setblock 142 46 351 minecraft:purple_concrete
setblock 143 46 323 minecraft:dark_prismarine
setblock 143 46 363 minecraft:dark_prismarine
fill 144 46 323 147 46 323 minecraft:blue_terracotta
fill 144 46 363 147 46 363 minecraft:blue_terracotta
setblock 145 46 322 minecraft:light_blue_wool
fill 146 46 350 146 102 350 minecraft:magenta_terracotta
setblock 148 46 323 minecraft:dark_prismarine
setblock 148 46 362 minecraft:blue_terracotta
setblock 148 46 363 minecraft:dark_prismarine
fill 149 46 323 149 49 323 minecraft:blue_terracotta
setblock 149 46 362 minecraft:dark_prismarine
fill 149 46 363 152 46 363 minecraft:blue_terracotta
fill 150 46 362 153 46 362 minecraft:blue_terracotta
setblock 151 46 324 minecraft:blue_terracotta
fill 151 46 327 151 47 328 minecraft:black_concrete
setblock 152 46 324 minecraft:dark_prismarine
setblock 153 46 323 minecraft:dark_prismarine
fill 153 46 324 153 49 324 minecraft:blue_terracotta
setblock 153 46 363 minecraft:dark_prismarine
fill 154 46 323 154 49 323 minecraft:blue_terracotta
setblock 154 46 362 minecraft:dark_prismarine
fill 154 46 363 157 46 363 minecraft:blue_terracotta
setblock 158 46 323 minecraft:dark_prismarine
fill 166 46 323 167 46 323 minecraft:blue_terracotta
setblock 168 46 323 minecraft:dark_prismarine
fill 168 46 324 171 46 324 minecraft:blue_terracotta
fill 169 46 323 172 46 323 minecraft:blue_terracotta
fill 169 46 363 172 46 363 minecraft:blue_terracotta
setblock 170 46 325 minecraft:blue_terracotta
setblock 171 46 325 minecraft:dark_prismarine
setblock 172 46 324 minecraft:dark_prismarine
fill 172 46 325 175 46 325 minecraft:blue_terracotta
setblock 173 46 323 minecraft:dark_prismarine
fill 173 46 324 173 49 324 minecraft:blue_terracotta
setblock 173 46 363 minecraft:dark_prismarine
fill 174 46 323 174 49 323 minecraft:blue_terracotta
fill 174 46 363 174 49 363 minecraft:blue_terracotta
setblock 176 46 325 minecraft:dark_prismarine
setblock 177 46 324 minecraft:dark_prismarine
fill 177 46 325 177 49 325 minecraft:blue_terracotta
setblock 178 46 323 minecraft:dark_prismarine
fill 178 46 324 178 49 324 minecraft:blue_terracotta
setblock 178 46 363 minecraft:dark_prismarine
fill 179 46 323 179 49 323 minecraft:blue_terracotta
fill 179 46 363 179 49 363 minecraft:blue_terracotta
setblock 181 46 325 minecraft:dark_prismarine
setblock 182 46 324 minecraft:dark_prismarine
fill 182 46 325 182 49 325 minecraft:blue_terracotta
setblock 182 46 335 minecraft:purple_concrete
fill 182 46 354 182 47 354 minecraft:purple_concrete
setblock 182 46 360 minecraft:purple_concrete
setblock 142 47 323 minecraft:dark_prismarine
fill 142 47 324 142 50 324 minecraft:blue_terracotta
setblock 142 47 332 minecraft:purple_concrete
setblock 142 47 347 minecraft:blue_terracotta
setblock 142 47 348 minecraft:dark_prismarine
setblock 142 47 357 minecraft:purple_concrete
setblock 142 47 362 minecraft:blue_terracotta
setblock 142 47 363 minecraft:dark_prismarine
fill 143 47 323 146 47 323 minecraft:blue_terracotta
fill 143 47 363 146 47 363 minecraft:blue_terracotta
setblock 144 47 325 minecraft:light[level=12]
setblock 144 47 332 minecraft:light[level=12]
setblock 144 47 339 minecraft:light[level=12]
setblock 144 47 346 minecraft:light[level=12]
setblock 144 47 353 minecraft:light[level=12]
setblock 144 47 360 minecraft:light[level=12]
fill 145 47 322 145 131 322 minecraft:black_concrete
fill 146 47 349 146 84 349 minecraft:magenta_terracotta
setblock 147 47 323 minecraft:dark_prismarine
setblock 147 47 363 minecraft:dark_prismarine
fill 148 47 323 148 50 323 minecraft:blue_terracotta
fill 148 47 363 151 47 363 minecraft:blue_terracotta
fill 149 47 362 152 47 362 minecraft:blue_terracotta
setblock 150 47 324 minecraft:blue_terracotta
setblock 151 47 324 minecraft:dark_prismarine
setblock 151 47 325 minecraft:light[level=12]
setblock 151 47 332 minecraft:light[level=12]
setblock 151 47 339 minecraft:light[level=12]
setblock 151 47 346 minecraft:light[level=12]
setblock 151 47 353 minecraft:light[level=12]
setblock 151 47 360 minecraft:light[level=12]
setblock 152 47 323 minecraft:dark_prismarine
fill 152 47 324 152 50 324 minecraft:blue_terracotta
setblock 152 47 363 minecraft:dark_prismarine
fill 153 47 323 153 50 323 minecraft:blue_terracotta
setblock 153 47 362 minecraft:dark_prismarine
fill 153 47 363 156 47 363 minecraft:blue_terracotta
setblock 157 47 323 minecraft:dark_prismarine
setblock 158 47 323 minecraft:blue_terracotta
setblock 158 47 325 minecraft:light[level=12]
setblock 158 47 332 minecraft:light[level=12]
setblock 158 47 339 minecraft:light[level=12]
setblock 158 47 346 minecraft:light[level=12]
setblock 158 47 353 minecraft:light[level=12]
setblock 158 47 360 minecraft:light[level=12]
fill 161 47 363 161 48 363 minecraft:purple_concrete
setblock 163 47 323 minecraft:purple_concrete
fill 165 47 323 166 47 323 minecraft:blue_terracotta
setblock 165 47 325 minecraft:light[level=12]
setblock 165 47 332 minecraft:light[level=12]
setblock 165 47 339 minecraft:light[level=12]
setblock 165 47 346 minecraft:light[level=12]
setblock 165 47 353 minecraft:light[level=12]
setblock 165 47 360 minecraft:light[level=12]
setblock 167 47 323 minecraft:dark_prismarine
fill 167 47 324 170 47 324 minecraft:blue_terracotta
fill 168 47 323 171 47 323 minecraft:blue_terracotta
setblock 169 47 325 minecraft:blue_terracotta
fill 169 47 363 171 47 363 minecraft:blue_terracotta
setblock 170 47 325 minecraft:dark_prismarine
setblock 171 47 324 minecraft:dark_prismarine
fill 171 47 325 173 47 326 minecraft:blue_terracotta
setblock 172 47 323 minecraft:dark_prismarine
fill 172 47 324 172 50 324 minecraft:blue_terracotta
setblock 172 47 332 minecraft:light[level=12]
setblock 172 47 339 minecraft:light[level=12]
setblock 172 47 346 minecraft:light[level=12]
setblock 172 47 353 minecraft:light[level=12]
setblock 172 47 360 minecraft:light[level=12]
setblock 172 47 363 minecraft:dark_prismarine
fill 173 47 323 173 50 323 minecraft:blue_terracotta
fill 173 47 363 173 50 363 minecraft:blue_terracotta
setblock 174 47 325 minecraft:blue_terracotta
setblock 174 47 326 minecraft:dark_prismarine
setblock 175 47 325 minecraft:dark_prismarine
setblock 176 47 324 minecraft:dark_prismarine
fill 176 47 325 176 50 325 minecraft:blue_terracotta
setblock 177 47 323 minecraft:dark_prismarine
fill 177 47 324 177 50 324 minecraft:blue_terracotta
setblock 177 47 363 minecraft:dark_prismarine
fill 178 47 323 178 50 323 minecraft:blue_terracotta
fill 178 47 363 178 50 363 minecraft:blue_terracotta
setblock 179 47 325 minecraft:light[level=12]
setblock 179 47 332 minecraft:light[level=12]
setblock 179 47 339 minecraft:light[level=12]
setblock 179 47 346 minecraft:light[level=12]
setblock 179 47 353 minecraft:light[level=12]
setblock 179 47 360 minecraft:light[level=12]
setblock 181 47 324 minecraft:dark_prismarine
fill 181 47 325 181 50 325 minecraft:blue_terracotta
setblock 182 47 323 minecraft:dark_prismarine
fill 182 47 324 182 50 324 minecraft:blue_terracotta
setblock 182 47 328 minecraft:dark_prismarine
setblock 182 47 329 minecraft:purple_concrete
setblock 182 47 348 minecraft:purple_concrete
setblock 182 47 363 minecraft:dark_prismarine
fill 142 48 323 145 48 323 minecraft:blue_terracotta
fill 142 48 325 142 49 325 minecraft:blue_terracotta
setblock 142 48 338 minecraft:purple_concrete
fill 142 48 344 142 49 344 minecraft:purple_concrete
fill 142 48 345 142 48 346 minecraft:blue_terracotta
setblock 142 48 347 minecraft:dark_prismarine
fill 142 48 348 142 48 351 minecraft:blue_terracotta
setblock 142 48 362 minecraft:dark_prismarine
fill 142 48 363 145 48 363 minecraft:blue_terracotta
setblock 146 48 323 minecraft:dark_prismarine
setblock 146 48 363 minecraft:dark_prismarine
fill 147 48 323 147 51 323 minecraft:blue_terracotta
fill 147 48 363 150 48 363 minecraft:blue_terracotta
fill 148 48 324 149 48 324 minecraft:blue_terracotta
fill 148 48 362 151 48 362 minecraft:blue_terracotta
setblock 150 48 324 minecraft:dark_prismarine
setblock 151 48 323 minecraft:dark_prismarine
fill 151 48 324 151 51 324 minecraft:blue_terracotta
setblock 151 48 363 minecraft:dark_prismarine
fill 152 48 323 152 51 323 minecraft:blue_terracotta
setblock 152 48 362 minecraft:dark_prismarine
fill 152 48 363 155 48 363 minecraft:blue_terracotta
setblock 156 48 323 minecraft:dark_prismarine
fill 157 48 323 157 51 323 minecraft:blue_terracotta
fill 164 48 323 165 48 323 minecraft:blue_terracotta
setblock 166 48 323 minecraft:dark_prismarine
fill 166 48 324 169 48 324 minecraft:blue_terracotta
fill 167 48 323 170 48 323 minecraft:blue_terracotta
setblock 167 48 363 minecraft:purple_concrete
setblock 168 48 325 minecraft:blue_terracotta
fill 168 48 363 170 48 363 minecraft:blue_terracotta
setblock 169 48 325 minecraft:dark_prismarine
setblock 170 48 324 minecraft:dark_prismarine
fill 170 48 325 172 48 326 minecraft:blue_terracotta
setblock 171 48 323 minecraft:dark_prismarine
fill 171 48 324 171 51 324 minecraft:blue_terracotta
setblock 171 48 363 minecraft:dark_prismarine
fill 172 48 323 172 51 323 minecraft:blue_terracotta
fill 172 48 363 172 51 363 minecraft:blue_terracotta
setblock 173 48 325 minecraft:blue_terracotta
setblock 173 48 326 minecraft:dark_prismarine
setblock 174 48 325 minecraft:dark_prismarine
fill 174 48 326 175 50 326 minecraft:blue_terracotta
setblock 175 48 324 minecraft:dark_prismarine
fill 175 48 325 175 51 325 minecraft:blue_terracotta
setblock 176 48 323 minecraft:dark_prismarine
fill 176 48 324 176 51 324 minecraft:blue_terracotta
setblock 176 48 363 minecraft:dark_prismarine
fill 177 48 323 177 51 323 minecraft:blue_terracotta
fill 177 48 363 177 51 363 minecraft:blue_terracotta
setblock 180 48 324 minecraft:dark_prismarine
setblock 181 48 323 minecraft:dark_prismarine
fill 181 48 324 181 51 324 minecraft:blue_terracotta
fill 181 48 326 181 49 326 minecraft:blue_terracotta
setblock 181 48 363 minecraft:dark_prismarine
fill 182 48 323 182 51 323 minecraft:blue_terracotta
setblock 182 48 327 minecraft:dark_prismarine
fill 182 48 328 182 51 328 minecraft:blue_terracotta
setblock 182 48 342 minecraft:purple_concrete
fill 182 48 363 182 51 363 minecraft:blue_terracotta
fill 142 49 323 144 49 323 minecraft:blue_terracotta
setblock 142 49 326 minecraft:dark_prismarine
setblock 142 49 345 minecraft:blue_terracotta
setblock 142 49 346 minecraft:dark_prismarine
fill 142 49 347 142 49 350 minecraft:blue_terracotta
setblock 142 49 351 minecraft:dark_prismarine
fill 142 49 352 142 50 354 minecraft:blue_terracotta
fill 142 49 362 142 51 363 minecraft:blue_terracotta
fill 143 49 347 143 49 349 minecraft:blue_terracotta
setblock 143 49 350 minecraft:dark_prismarine
fill 143 49 363 144 49 363 minecraft:blue_terracotta
setblock 145 49 323 minecraft:dark_prismarine
setblock 145 49 363 minecraft:dark_prismarine
fill 146 49 323 146 52 323 minecraft:blue_terracotta
fill 146 49 363 149 49 363 minecraft:blue_terracotta
fill 147 49 324 148 49 324 minecraft:blue_terracotta
fill 148 49 362 150 49 362 minecraft:blue_terracotta
setblock 149 49 324 minecraft:dark_prismarine
setblock 150 49 323 minecraft:dark_prismarine
fill 150 49 324 150 52 324 minecraft:blue_terracotta
setblock 150 49 363 minecraft:dark_prismarine
fill 151 49 323 151 52 323 minecraft:blue_terracotta
setblock 151 49 362 minecraft:dark_prismarine
fill 151 49 363 154 49 363 minecraft:blue_terracotta
setblock 154 49 324 minecraft:dark_prismarine
setblock 155 49 323 minecraft:dark_prismarine
setblock 155 49 363 minecraft:dark_prismarine
fill 156 49 323 156 52 323 minecraft:blue_terracotta
fill 161 49 327 161 50 327 minecraft:magenta_terracotta
fill 163 49 323 164 49 323 minecraft:blue_terracotta
setblock 165 49 323 minecraft:dark_prismarine
fill 165 49 324 168 49 324 minecraft:blue_terracotta
fill 166 49 323 169 49 323 minecraft:blue_terracotta
setblock 167 49 322 minecraft:light_blue_wool
schedule function dropper:buildpart/75_4 1t
