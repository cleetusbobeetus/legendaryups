fill 80 108 276 80 109 279 minecraft:iron_bars
setblock 82 108 276 minecraft:spruce_planks
fill 86 108 276 86 109 315 minecraft:iron_bars
setblock 86 108 316 minecraft:spruce_planks
setblock 87 108 296 minecraft:spruce_planks
setblock 88 108 277 minecraft:spruce_planks
setblock 88 108 284 minecraft:spruce_planks
setblock 88 108 291 minecraft:spruce_planks
setblock 88 108 298 minecraft:spruce_planks
setblock 88 108 305 minecraft:spruce_planks
setblock 88 108 312 minecraft:spruce_planks
setblock 89 108 310 minecraft:white_wool
fill 89 108 311 89 131 311 minecraft:blue_terracotta
fill 47 109 290 47 123 290 minecraft:blue_terracotta
fill 47 109 307 47 131 307 minecraft:blue_terracotta
fill 48 109 278 48 110 278 minecraft:spruce_planks
fill 48 109 285 48 110 285 minecraft:spruce_planks
fill 48 109 292 48 110 292 minecraft:spruce_planks
fill 48 109 299 48 110 299 minecraft:spruce_planks
fill 48 109 306 48 110 306 minecraft:spruce_planks
fill 48 109 313 48 110 313 minecraft:spruce_planks
fill 50 109 279 50 109 291 minecraft:iron_bars
fill 50 109 292 50 109 293 minecraft:white_concrete
fill 50 109 294 50 109 305 minecraft:iron_bars
fill 52 109 316 52 110 316 minecraft:spruce_planks
fill 53 109 276 53 110 276 minecraft:spruce_planks
fill 54 109 277 55 110 277 minecraft:iron_bars
fill 56 109 285 56 109 316 minecraft:iron_bars
fill 57 109 277 60 110 277 minecraft:iron_bars
fill 59 109 316 59 110 316 minecraft:spruce_planks
fill 60 109 276 60 110 276 minecraft:spruce_planks
setblock 64 109 275 minecraft:light_blue_wool
fill 66 109 316 66 110 316 minecraft:spruce_planks
fill 67 109 276 67 110 276 minecraft:spruce_planks
fill 68 109 276 68 109 279 minecraft:iron_bars
fill 73 109 316 73 110 316 minecraft:spruce_planks
fill 74 109 276 74 110 276 minecraft:spruce_planks
fill 74 109 277 74 109 278 minecraft:iron_bars
fill 80 109 280 80 109 315 minecraft:iron_bars
fill 80 109 316 80 110 316 minecraft:spruce_planks
fill 81 109 276 81 110 276 minecraft:spruce_planks
fill 87 109 316 87 110 316 minecraft:spruce_planks
fill 88 109 276 88 110 276 minecraft:spruce_planks
fill 88 109 283 88 110 283 minecraft:spruce_planks
fill 88 109 290 88 110 290 minecraft:spruce_planks
fill 88 109 297 88 110 297 minecraft:spruce_planks
fill 88 109 304 88 110 304 minecraft:spruce_planks
fill 88 109 311 88 110 311 minecraft:spruce_planks
fill 89 109 310 89 131 310 minecraft:blue_terracotta
fill 47 110 275 47 131 275 minecraft:blue_terracotta
setblock 47 110 276 minecraft:light_blue_wool
fill 48 110 276 48 110 277 minecraft:spruce_planks
fill 48 110 279 48 110 280 minecraft:spruce_planks
fill 48 110 282 48 110 284 minecraft:spruce_planks
fill 48 110 286 48 110 287 minecraft:spruce_planks
fill 48 110 289 48 110 291 minecraft:spruce_planks
fill 48 110 293 48 110 294 minecraft:spruce_planks
fill 48 110 296 48 110 298 minecraft:spruce_planks
fill 48 110 300 48 110 301 minecraft:spruce_planks
fill 48 110 303 48 110 305 minecraft:spruce_planks
fill 48 110 307 48 110 308 minecraft:spruce_planks
fill 48 110 310 48 110 312 minecraft:spruce_planks
fill 48 110 314 48 110 315 minecraft:spruce_planks
setblock 49 110 276 minecraft:spruce_planks
fill 49 110 316 51 110 316 minecraft:spruce_planks
setblock 50 110 278 minecraft:light[level=12]
setblock 50 110 285 minecraft:light[level=12]
setblock 50 110 292 minecraft:light[level=12]
setblock 50 110 299 minecraft:light[level=12]
fill 50 110 301 50 110 315 minecraft:iron_bars
fill 51 110 276 52 110 276 minecraft:spruce_planks
fill 53 110 316 54 110 316 minecraft:spruce_planks
fill 54 110 276 56 110 276 minecraft:spruce_planks
setblock 56 110 277 minecraft:iron_bars
fill 56 110 316 58 110 316 minecraft:spruce_planks
setblock 57 110 278 minecraft:light[level=12]
setblock 57 110 285 minecraft:light[level=12]
setblock 57 110 292 minecraft:light[level=12]
setblock 57 110 299 minecraft:light[level=12]
setblock 57 110 306 minecraft:light[level=12]
setblock 57 110 313 minecraft:light[level=12]
fill 58 110 276 59 110 276 minecraft:spruce_planks
fill 60 110 316 61 110 316 minecraft:spruce_planks
fill 61 110 276 63 110 276 minecraft:spruce_planks
fill 63 110 316 65 110 316 minecraft:spruce_planks
fill 64 110 275 64 131 275 minecraft:blue_terracotta
setblock 64 110 278 minecraft:light[level=12]
setblock 64 110 285 minecraft:light[level=12]
setblock 64 110 292 minecraft:light[level=12]
setblock 64 110 299 minecraft:light[level=12]
setblock 64 110 306 minecraft:light[level=12]
setblock 64 110 313 minecraft:light[level=12]
fill 65 110 276 66 110 276 minecraft:spruce_planks
fill 67 110 316 68 110 316 minecraft:spruce_planks
fill 68 110 276 70 110 276 minecraft:spruce_planks
fill 70 110 316 72 110 316 minecraft:spruce_planks
setblock 71 110 278 minecraft:light[level=12]
setblock 71 110 285 minecraft:light[level=12]
setblock 71 110 292 minecraft:light[level=12]
setblock 71 110 299 minecraft:light[level=12]
setblock 71 110 306 minecraft:light[level=12]
setblock 71 110 313 minecraft:light[level=12]
fill 72 110 276 73 110 276 minecraft:spruce_planks
fill 74 110 316 75 110 316 minecraft:spruce_planks
fill 75 110 276 77 110 276 minecraft:spruce_planks
fill 77 110 316 79 110 316 minecraft:spruce_planks
setblock 78 110 278 minecraft:light[level=12]
setblock 78 110 285 minecraft:light[level=12]
setblock 78 110 292 minecraft:light[level=12]
setblock 78 110 299 minecraft:light[level=12]
setblock 78 110 306 minecraft:light[level=12]
setblock 78 110 313 minecraft:light[level=12]
fill 79 110 276 80 110 276 minecraft:spruce_planks
fill 80 110 314 80 110 315 minecraft:iron_bars
fill 81 110 316 82 110 316 minecraft:spruce_planks
fill 82 110 276 84 110 276 minecraft:spruce_planks
fill 82 110 279 82 110 282 minecraft:dark_oak_planks
fill 83 110 278 84 110 278 minecraft:dark_oak_planks
setblock 84 110 283 minecraft:dark_oak_planks
fill 84 110 316 86 110 316 minecraft:spruce_planks
setblock 84 110 317 minecraft:white_wool
setblock 85 110 278 minecraft:light[level=12]
setblock 85 110 279 minecraft:dark_oak_planks
setblock 85 110 282 minecraft:dark_oak_planks
setblock 85 110 285 minecraft:light[level=12]
setblock 85 110 292 minecraft:light[level=12]
setblock 85 110 299 minecraft:light[level=12]
setblock 85 110 306 minecraft:light[level=12]
setblock 85 110 313 minecraft:light[level=12]
fill 86 110 276 87 110 276 minecraft:spruce_planks
fill 86 110 280 86 110 281 minecraft:dark_oak_planks
fill 88 110 277 88 110 279 minecraft:spruce_planks
fill 88 110 281 88 110 282 minecraft:spruce_planks
fill 88 110 284 88 110 286 minecraft:spruce_planks
fill 88 110 288 88 110 289 minecraft:spruce_planks
fill 88 110 291 88 110 293 minecraft:spruce_planks
fill 88 110 295 88 110 296 minecraft:spruce_planks
fill 88 110 298 88 110 300 minecraft:spruce_planks
fill 88 110 302 88 110 303 minecraft:spruce_planks
fill 88 110 305 88 110 307 minecraft:spruce_planks
fill 88 110 309 88 110 310 minecraft:spruce_planks
fill 88 110 312 88 110 314 minecraft:spruce_planks
setblock 88 110 316 minecraft:spruce_planks
fill 47 111 276 47 131 276 minecraft:blue_terracotta
setblock 48 111 280 minecraft:spruce_planks
setblock 48 111 287 minecraft:spruce_planks
setblock 48 111 294 minecraft:spruce_planks
setblock 48 111 301 minecraft:spruce_planks
setblock 48 111 308 minecraft:spruce_planks
setblock 48 111 315 minecraft:spruce_planks
setblock 51 111 276 minecraft:spruce_planks
setblock 54 111 316 minecraft:spruce_planks
setblock 57 111 275 minecraft:white_wool
setblock 58 111 276 minecraft:spruce_planks
setblock 61 111 316 minecraft:spruce_planks
setblock 65 111 276 minecraft:spruce_planks
setblock 66 111 317 minecraft:white_wool
setblock 68 111 316 minecraft:spruce_planks
setblock 72 111 276 minecraft:spruce_planks
setblock 75 111 316 minecraft:spruce_planks
setblock 79 111 276 minecraft:spruce_planks
setblock 82 111 316 minecraft:spruce_planks
fill 84 111 317 84 131 317 minecraft:blue_terracotta
setblock 86 111 276 minecraft:spruce_planks
setblock 88 111 281 minecraft:spruce_planks
setblock 88 111 288 minecraft:spruce_planks
setblock 88 111 295 minecraft:spruce_planks
setblock 88 111 302 minecraft:spruce_planks
setblock 88 111 309 minecraft:spruce_planks
setblock 89 111 309 minecraft:light_blue_wool
fill 48 112 280 56 118 280 minecraft:white_wool
fill 52 112 317 53 126 317 minecraft:blue_terracotta
setblock 54 112 317 minecraft:light_blue_wool
fill 55 112 317 56 129 317 minecraft:blue_terracotta
fill 57 112 275 57 129 275 minecraft:blue_terracotta
setblock 57 112 317 minecraft:white_wool
fill 66 112 317 66 113 317 minecraft:blue_terracotta
fill 70 112 275 77 114 275 minecraft:blue_terracotta
setblock 78 112 275 minecraft:light_blue_wool
fill 79 112 275 79 120 275 minecraft:blue_terracotta
fill 80 112 312 88 118 312 minecraft:white_wool
fill 89 112 309 89 127 309 minecraft:blue_terracotta
fill 47 113 280 47 119 280 minecraft:blue_terracotta
setblock 47 113 281 minecraft:white_wool
setblock 47 113 304 minecraft:white_wool
setblock 48 113 282 minecraft:spruce_planks
setblock 48 113 289 minecraft:spruce_planks
setblock 48 113 296 minecraft:spruce_planks
setblock 48 113 303 minecraft:spruce_planks
setblock 48 113 310 minecraft:spruce_planks
setblock 49 113 276 minecraft:spruce_planks
setblock 49 113 316 minecraft:spruce_planks
setblock 51 113 317 minecraft:white_wool
fill 54 113 317 54 131 317 minecraft:blue_terracotta
setblock 56 113 276 minecraft:spruce_planks
setblock 56 113 316 minecraft:spruce_planks
fill 57 113 317 57 131 317 minecraft:blue_terracotta
setblock 63 113 276 minecraft:spruce_planks
setblock 63 113 316 minecraft:spruce_planks
setblock 70 113 276 minecraft:spruce_planks
fill 70 113 282 70 122 282 minecraft:green_terracotta
setblock 70 113 316 minecraft:spruce_planks
setblock 77 113 276 minecraft:spruce_planks
setblock 77 113 316 minecraft:spruce_planks
fill 78 113 275 78 127 275 minecraft:blue_terracotta
setblock 84 113 276 minecraft:spruce_planks
setblock 84 113 316 minecraft:spruce_planks
setblock 88 113 279 minecraft:spruce_planks
setblock 88 113 286 minecraft:spruce_planks
setblock 88 113 293 minecraft:spruce_planks
setblock 88 113 300 minecraft:spruce_planks
setblock 88 113 307 minecraft:spruce_planks
setblock 88 113 314 minecraft:spruce_planks
setblock 89 113 291 minecraft:light_blue_wool
fill 89 113 292 89 119 292 minecraft:blue_terracotta
setblock 89 113 293 minecraft:white_wool
fill 47 114 281 47 131 281 minecraft:blue_terracotta
fill 47 114 304 47 132 304 minecraft:blue_terracotta
setblock 48 114 276 minecraft:spruce_planks
setblock 48 114 283 minecraft:spruce_planks
setblock 48 114 290 minecraft:spruce_planks
setblock 48 114 297 minecraft:spruce_planks
setblock 48 114 304 minecraft:spruce_planks
setblock 48 114 311 minecraft:spruce_planks
setblock 50 114 278 minecraft:light[level=15]
setblock 50 114 286 minecraft:light[level=15]
setblock 50 114 294 minecraft:light[level=15]
setblock 50 114 302 minecraft:light[level=15]
setblock 50 114 310 minecraft:light[level=15]
setblock 50 114 316 minecraft:spruce_planks
fill 51 114 317 51 127 317 minecraft:blue_terracotta
setblock 55 114 276 minecraft:spruce_planks
setblock 57 114 316 minecraft:spruce_planks
setblock 58 114 278 minecraft:light[level=15]
setblock 58 114 286 minecraft:light[level=15]
setblock 58 114 294 minecraft:light[level=15]
setblock 58 114 302 minecraft:light[level=15]
setblock 58 114 310 minecraft:light[level=15]
setblock 60 114 275 minecraft:light_blue_wool
fill 61 114 275 62 128 275 minecraft:blue_terracotta
setblock 62 114 276 minecraft:spruce_planks
setblock 64 114 316 minecraft:spruce_planks
setblock 66 114 278 minecraft:light[level=15]
setblock 66 114 286 minecraft:light[level=15]
setblock 66 114 294 minecraft:light[level=15]
setblock 66 114 302 minecraft:light[level=15]
setblock 66 114 310 minecraft:light[level=15]
setblock 66 114 317 minecraft:light_blue_wool
setblock 69 114 276 minecraft:spruce_planks
setblock 71 114 316 minecraft:spruce_planks
setblock 71 114 317 minecraft:light_blue_wool
setblock 74 114 278 minecraft:light[level=15]
setblock 74 114 286 minecraft:light[level=15]
setblock 74 114 294 minecraft:light[level=15]
setblock 74 114 302 minecraft:light[level=15]
setblock 74 114 310 minecraft:light[level=15]
setblock 76 114 276 minecraft:spruce_planks
setblock 78 114 316 minecraft:spruce_planks
setblock 82 114 278 minecraft:light[level=15]
setblock 82 114 286 minecraft:light[level=15]
setblock 82 114 294 minecraft:light[level=15]
setblock 82 114 302 minecraft:light[level=15]
setblock 82 114 310 minecraft:light[level=15]
setblock 83 114 276 minecraft:spruce_planks
setblock 85 114 316 minecraft:spruce_planks
setblock 88 114 278 minecraft:spruce_planks
setblock 88 114 285 minecraft:spruce_planks
setblock 88 114 292 minecraft:spruce_planks
setblock 88 114 299 minecraft:spruce_planks
setblock 88 114 306 minecraft:spruce_planks
setblock 88 114 313 minecraft:spruce_planks
fill 89 114 291 89 131 291 minecraft:blue_terracotta
fill 89 114 293 89 128 293 minecraft:blue_terracotta
setblock 48 115 277 minecraft:spruce_planks
setblock 48 115 284 minecraft:spruce_planks
setblock 48 115 291 minecraft:spruce_planks
setblock 48 115 298 minecraft:spruce_planks
setblock 48 115 305 minecraft:spruce_planks
setblock 48 115 312 minecraft:spruce_planks
setblock 48 115 317 minecraft:white_wool
setblock 51 115 316 minecraft:spruce_planks
setblock 54 115 276 minecraft:spruce_planks
setblock 58 115 316 minecraft:spruce_planks
fill 60 115 275 60 127 275 minecraft:blue_terracotta
setblock 61 115 276 minecraft:spruce_planks
setblock 65 115 316 minecraft:spruce_planks
fill 66 115 317 66 119 317 minecraft:blue_terracotta
setblock 68 115 276 minecraft:spruce_planks
fill 70 115 275 70 131 275 minecraft:blue_terracotta
setblock 71 115 275 minecraft:light_blue_wool
fill 71 115 317 71 131 317 minecraft:blue_terracotta
fill 72 115 275 77 124 275 minecraft:blue_terracotta
setblock 72 115 316 minecraft:spruce_planks
setblock 75 115 276 minecraft:spruce_planks
setblock 79 115 316 minecraft:spruce_planks
setblock 82 115 276 minecraft:spruce_planks
setblock 86 115 316 minecraft:spruce_planks
setblock 88 115 277 minecraft:spruce_planks
setblock 88 115 284 minecraft:spruce_planks
setblock 88 115 291 minecraft:spruce_planks
setblock 88 115 298 minecraft:spruce_planks
setblock 88 115 305 minecraft:spruce_planks
setblock 47 116 305 minecraft:white_wool
setblock 48 116 278 minecraft:spruce_planks
setblock 48 116 285 minecraft:spruce_planks
setblock 48 116 292 minecraft:spruce_planks
setblock 48 116 299 minecraft:spruce_planks
setblock 48 116 306 minecraft:spruce_planks
setblock 48 116 313 minecraft:spruce_planks
fill 48 116 317 48 128 317 minecraft:blue_terracotta
setblock 50 116 278 minecraft:light[level=12]
setblock 50 116 285 minecraft:light[level=12]
setblock 50 116 292 minecraft:light[level=12]
setblock 50 116 299 minecraft:light[level=12]
setblock 50 116 306 minecraft:light[level=12]
setblock 50 116 313 minecraft:light[level=12]
setblock 52 116 316 minecraft:spruce_planks
setblock 53 116 276 minecraft:spruce_planks
setblock 57 116 278 minecraft:light[level=12]
setblock 57 116 285 minecraft:light[level=12]
setblock 57 116 292 minecraft:light[level=12]
setblock 57 116 299 minecraft:light[level=12]
setblock 57 116 306 minecraft:light[level=12]
setblock 57 116 313 minecraft:light[level=12]
setblock 59 116 316 minecraft:spruce_planks
setblock 60 116 276 minecraft:spruce_planks
setblock 64 116 278 minecraft:light[level=12]
setblock 64 116 285 minecraft:light[level=12]
setblock 64 116 292 minecraft:light[level=12]
setblock 64 116 299 minecraft:light[level=12]
setblock 64 116 306 minecraft:light[level=12]
setblock 64 116 313 minecraft:light[level=12]
setblock 66 116 316 minecraft:spruce_planks
setblock 67 116 276 minecraft:spruce_planks
fill 71 116 275 71 131 275 minecraft:blue_terracotta
setblock 71 116 278 minecraft:light[level=12]
setblock 71 116 285 minecraft:light[level=12]
setblock 71 116 292 minecraft:light[level=12]
setblock 71 116 299 minecraft:light[level=12]
setblock 71 116 306 minecraft:light[level=12]
setblock 71 116 313 minecraft:light[level=12]
setblock 73 116 316 minecraft:spruce_planks
setblock 74 116 276 minecraft:spruce_planks
setblock 78 116 278 minecraft:light[level=12]
setblock 78 116 285 minecraft:light[level=12]
setblock 78 116 292 minecraft:light[level=12]
setblock 78 116 299 minecraft:light[level=12]
setblock 78 116 306 minecraft:light[level=12]
setblock 78 116 313 minecraft:light[level=12]
setblock 80 116 316 minecraft:spruce_planks
setblock 81 116 276 minecraft:spruce_planks
setblock 85 116 278 minecraft:light[level=12]
setblock 85 116 285 minecraft:light[level=12]
setblock 85 116 292 minecraft:light[level=12]
setblock 85 116 299 minecraft:light[level=12]
setblock 85 116 306 minecraft:light[level=12]
setblock 85 116 313 minecraft:light[level=12]
setblock 87 116 316 minecraft:spruce_planks
setblock 88 116 276 minecraft:spruce_planks
setblock 88 116 283 minecraft:spruce_planks
setblock 88 116 290 minecraft:spruce_planks
setblock 88 116 297 minecraft:spruce_planks
setblock 88 116 304 minecraft:spruce_planks
setblock 88 116 311 minecraft:spruce_planks
fill 89 116 302 89 131 305 minecraft:blue_terracotta
setblock 89 116 306 minecraft:light_blue_wool
fill 47 117 305 47 128 305 minecraft:blue_terracotta
setblock 48 117 279 minecraft:spruce_planks
setblock 48 117 286 minecraft:spruce_planks
setblock 48 117 293 minecraft:spruce_planks
setblock 48 117 300 minecraft:spruce_planks
setblock 48 117 307 minecraft:spruce_planks
setblock 48 117 314 minecraft:spruce_planks
setblock 52 117 276 minecraft:spruce_planks
setblock 53 117 316 minecraft:spruce_planks
setblock 59 117 276 minecraft:spruce_planks
setblock 60 117 316 minecraft:spruce_planks
setblock 66 117 276 minecraft:spruce_planks
setblock 67 117 316 minecraft:spruce_planks
setblock 73 117 276 minecraft:spruce_planks
setblock 74 117 316 minecraft:spruce_planks
setblock 80 117 276 minecraft:spruce_planks
setblock 81 117 316 minecraft:spruce_planks
setblock 87 117 276 minecraft:spruce_planks
setblock 88 117 282 minecraft:spruce_planks
setblock 88 117 289 minecraft:spruce_planks
setblock 88 117 296 minecraft:spruce_planks
setblock 88 117 303 minecraft:spruce_planks
setblock 88 117 310 minecraft:spruce_planks
setblock 88 117 316 minecraft:spruce_planks
setblock 89 117 285 minecraft:light_blue_wool
fill 89 117 306 89 131 306 minecraft:blue_terracotta
setblock 47 118 298 minecraft:light_blue_wool
setblock 47 118 303 minecraft:light_blue_wool
setblock 48 118 287 minecraft:spruce_planks
setblock 48 118 294 minecraft:spruce_planks
setblock 48 118 301 minecraft:spruce_planks
setblock 48 118 308 minecraft:spruce_planks
setblock 48 118 315 minecraft:spruce_planks
setblock 51 118 276 minecraft:spruce_planks
setblock 54 118 316 minecraft:spruce_planks
setblock 58 118 276 minecraft:spruce_planks
setblock 61 118 316 minecraft:spruce_planks
setblock 65 118 276 minecraft:spruce_planks
setblock 68 118 316 minecraft:spruce_planks
setblock 72 118 276 minecraft:spruce_planks
setblock 75 118 316 minecraft:spruce_planks
setblock 79 118 276 minecraft:spruce_planks
fill 82 118 279 82 118 282 minecraft:dark_oak_planks
setblock 82 118 316 minecraft:spruce_planks
fill 83 118 278 84 118 278 minecraft:dark_oak_planks
setblock 84 118 283 minecraft:dark_oak_planks
setblock 85 118 279 minecraft:dark_oak_planks
setblock 85 118 282 minecraft:dark_oak_planks
setblock 86 118 276 minecraft:spruce_planks
fill 86 118 280 86 118 281 minecraft:dark_oak_planks
setblock 88 118 281 minecraft:spruce_planks
setblock 88 118 288 minecraft:spruce_planks
setblock 88 118 295 minecraft:spruce_planks
setblock 88 118 302 minecraft:spruce_planks
setblock 88 118 309 minecraft:spruce_planks
fill 89 118 285 89 119 285 minecraft:blue_terracotta
setblock 47 119 286 minecraft:light_blue_wool
fill 47 119 298 47 127 299 minecraft:blue_terracotta
setblock 47 119 300 minecraft:light_blue_wool
fill 47 119 301 47 131 303 minecraft:blue_terracotta
fill 48 119 280 56 119 280 minecraft:spruce_log
setblock 75 119 317 minecraft:white_wool
fill 76 119 317 76 131 317 minecraft:blue_terracotta
fill 80 119 312 88 119 312 minecraft:spruce_log
setblock 47 120 280 minecraft:light_blue_wool
fill 47 120 286 47 128 286 minecraft:blue_terracotta
fill 47 120 300 47 128 300 minecraft:blue_terracotta
fill 48 120 276 48 120 280 minecraft:spruce_planks
fill 48 120 282 48 120 287 minecraft:spruce_planks
fill 48 120 289 48 120 294 minecraft:spruce_planks
fill 48 120 296 48 120 301 minecraft:spruce_planks
fill 48 120 303 48 120 308 minecraft:spruce_planks
fill 48 120 310 48 120 315 minecraft:spruce_planks
setblock 49 120 276 minecraft:spruce_planks
fill 49 120 316 54 120 316 minecraft:spruce_planks
fill 51 120 276 56 120 276 minecraft:spruce_planks
fill 51 120 280 53 135 280 minecraft:spruce_log
fill 56 120 316 61 120 316 minecraft:spruce_planks
fill 58 120 276 63 120 276 minecraft:spruce_planks
fill 63 120 316 68 120 316 minecraft:spruce_planks
fill 65 120 276 70 120 276 minecraft:spruce_planks
fill 66 120 317 66 121 317 minecraft:light_blue_wool
fill 70 120 316 75 120 316 minecraft:spruce_planks
setblock 70 120 317 minecraft:light_blue_wool
fill 72 120 276 77 120 276 minecraft:spruce_planks
fill 75 120 317 75 127 317 minecraft:blue_terracotta
fill 77 120 316 82 120 316 minecraft:spruce_planks
fill 79 120 276 84 120 276 minecraft:spruce_planks
setblock 81 120 275 minecraft:white_wool
fill 83 120 312 85 135 312 minecraft:spruce_log
fill 84 120 316 88 120 316 minecraft:spruce_planks
fill 86 120 276 88 120 276 minecraft:spruce_planks
fill 88 120 277 88 120 279 minecraft:spruce_planks
fill 88 120 281 88 120 286 minecraft:spruce_planks
fill 88 120 288 88 120 293 minecraft:spruce_planks
fill 88 120 295 88 120 300 minecraft:spruce_planks
fill 88 120 302 88 120 307 minecraft:spruce_planks
fill 88 120 309 88 120 314 minecraft:spruce_planks
setblock 89 120 285 minecraft:light_blue_wool
setblock 89 120 292 minecraft:white_wool
fill 47 121 280 47 127 280 minecraft:blue_terracotta
setblock 48 121 276 minecraft:spruce_planks
setblock 48 121 283 minecraft:spruce_planks
setblock 48 121 290 minecraft:spruce_planks
setblock 48 121 297 minecraft:spruce_planks
setblock 48 121 304 minecraft:spruce_planks
setblock 48 121 311 minecraft:spruce_planks
setblock 50 121 316 minecraft:spruce_planks
setblock 55 121 276 minecraft:spruce_planks
fill 55 121 280 56 121 280 minecraft:white_concrete
setblock 57 121 316 minecraft:spruce_planks
setblock 61 121 317 minecraft:light_blue_wool
setblock 62 121 276 minecraft:spruce_planks
setblock 64 121 316 minecraft:spruce_planks
setblock 69 121 276 minecraft:spruce_planks
fill 70 121 317 70 129 317 minecraft:blue_terracotta
setblock 71 121 316 minecraft:spruce_planks
setblock 76 121 276 minecraft:spruce_planks
setblock 78 121 316 minecraft:spruce_planks
setblock 79 121 275 minecraft:light_blue_wool
fill 81 121 275 81 132 275 minecraft:blue_terracotta
setblock 83 121 276 minecraft:spruce_planks
setblock 85 121 316 minecraft:spruce_planks
setblock 88 121 278 minecraft:spruce_planks
setblock 88 121 285 minecraft:spruce_planks
setblock 88 121 292 minecraft:spruce_planks
setblock 88 121 299 minecraft:spruce_planks
setblock 88 121 306 minecraft:spruce_planks
setblock 88 121 313 minecraft:spruce_planks
fill 89 121 285 89 127 285 minecraft:blue_terracotta
fill 89 121 292 89 124 292 minecraft:blue_terracotta
setblock 48 122 277 minecraft:spruce_planks
setblock 48 122 284 minecraft:spruce_planks
setblock 48 122 291 minecraft:spruce_planks
setblock 48 122 298 minecraft:spruce_planks
setblock 48 122 305 minecraft:spruce_planks
setblock 48 122 312 minecraft:spruce_planks
setblock 50 122 278 minecraft:light[level=15]
setblock 50 122 285 minecraft:light[level=12]
setblock 50 122 286 minecraft:light[level=15]
setblock 50 122 292 minecraft:light[level=12]
setblock 50 122 294 minecraft:light[level=15]
setblock 50 122 299 minecraft:light[level=12]
setblock 50 122 302 minecraft:light[level=15]
setblock 50 122 306 minecraft:light[level=12]
setblock 50 122 310 minecraft:light[level=15]
setblock 50 122 313 minecraft:light[level=12]
setblock 51 122 316 minecraft:spruce_planks
setblock 54 122 276 minecraft:spruce_planks
setblock 57 122 278 minecraft:light[level=12]
setblock 57 122 285 minecraft:light[level=12]
setblock 57 122 292 minecraft:light[level=12]
setblock 57 122 299 minecraft:light[level=12]
setblock 57 122 306 minecraft:light[level=12]
setblock 57 122 313 minecraft:light[level=12]
setblock 58 122 278 minecraft:light[level=15]
setblock 58 122 286 minecraft:light[level=15]
setblock 58 122 294 minecraft:light[level=15]
setblock 58 122 302 minecraft:light[level=15]
setblock 58 122 310 minecraft:light[level=15]
setblock 58 122 316 minecraft:spruce_planks
setblock 61 122 276 minecraft:spruce_planks
fill 61 122 317 61 131 317 minecraft:blue_terracotta
setblock 64 122 278 minecraft:light[level=12]
setblock 64 122 285 minecraft:light[level=12]
setblock 64 122 292 minecraft:light[level=12]
setblock 64 122 299 minecraft:light[level=12]
setblock 64 122 306 minecraft:light[level=12]
setblock 64 122 313 minecraft:light[level=12]
setblock 65 122 316 minecraft:spruce_planks
setblock 66 122 278 minecraft:light[level=15]
setblock 66 122 286 minecraft:light[level=15]
setblock 66 122 302 minecraft:light[level=15]
setblock 66 122 310 minecraft:light[level=15]
fill 66 122 317 66 131 317 minecraft:blue_terracotta
setblock 68 122 276 minecraft:spruce_planks
setblock 71 122 278 minecraft:light[level=12]
setblock 71 122 285 minecraft:light[level=12]
setblock 71 122 292 minecraft:light[level=12]
setblock 71 122 299 minecraft:light[level=12]
setblock 71 122 306 minecraft:light[level=12]
setblock 71 122 313 minecraft:light[level=12]
setblock 72 122 316 minecraft:spruce_planks
setblock 74 122 278 minecraft:light[level=15]
setblock 74 122 286 minecraft:light[level=15]
setblock 74 122 294 minecraft:light[level=15]
setblock 74 122 302 minecraft:light[level=15]
setblock 74 122 310 minecraft:light[level=15]
setblock 75 122 276 minecraft:spruce_planks
setblock 78 122 278 minecraft:light[level=12]
setblock 78 122 285 minecraft:light[level=12]
setblock 78 122 292 minecraft:light[level=12]
setblock 78 122 299 minecraft:light[level=12]
setblock 78 122 306 minecraft:light[level=12]
setblock 78 122 313 minecraft:light[level=12]
fill 79 122 275 79 131 275 minecraft:blue_terracotta
setblock 79 122 316 minecraft:spruce_planks
setblock 82 122 276 minecraft:spruce_planks
setblock 82 122 278 minecraft:light[level=15]
setblock 82 122 286 minecraft:light[level=15]
setblock 82 122 294 minecraft:light[level=15]
setblock 82 122 302 minecraft:light[level=15]
setblock 82 122 310 minecraft:light[level=15]
setblock 85 122 278 minecraft:light[level=12]
setblock 85 122 285 minecraft:light[level=12]
setblock 85 122 292 minecraft:light[level=12]
setblock 85 122 299 minecraft:light[level=12]
setblock 85 122 306 minecraft:light[level=12]
setblock 85 122 313 minecraft:light[level=12]
setblock 86 122 316 minecraft:spruce_planks
setblock 88 122 277 minecraft:spruce_planks
setblock 88 122 284 minecraft:spruce_planks
setblock 88 122 291 minecraft:spruce_planks
setblock 88 122 298 minecraft:spruce_planks
setblock 88 122 305 minecraft:spruce_planks
setblock 88 122 312 minecraft:spruce_planks
setblock 48 123 278 minecraft:spruce_planks
setblock 48 123 285 minecraft:spruce_planks
setblock 48 123 292 minecraft:spruce_planks
setblock 48 123 299 minecraft:spruce_planks
setblock 48 123 306 minecraft:spruce_planks
setblock 48 123 313 minecraft:spruce_planks
setblock 52 123 316 minecraft:spruce_planks
setblock 53 123 276 minecraft:spruce_planks
setblock 59 123 316 minecraft:spruce_planks
setblock 60 123 276 minecraft:spruce_planks
setblock 66 123 316 minecraft:spruce_planks
setblock 67 123 276 minecraft:spruce_planks
setblock 73 123 316 minecraft:spruce_planks
setblock 74 123 276 minecraft:spruce_planks
fill 78 123 317 81 131 317 minecraft:blue_terracotta
setblock 80 123 316 minecraft:spruce_planks
setblock 81 123 276 minecraft:spruce_planks
setblock 82 123 317 minecraft:white_wool
setblock 87 123 316 minecraft:spruce_planks
setblock 88 123 276 minecraft:spruce_planks
setblock 88 123 283 minecraft:spruce_planks
setblock 88 123 290 minecraft:spruce_planks
setblock 88 123 297 minecraft:spruce_planks
setblock 88 123 304 minecraft:spruce_planks
setblock 88 123 311 minecraft:spruce_planks
setblock 47 124 290 minecraft:light_blue_wool
setblock 48 124 279 minecraft:spruce_planks
setblock 48 124 286 minecraft:spruce_planks
setblock 48 124 293 minecraft:spruce_planks
setblock 48 124 300 minecraft:spruce_planks
setblock 48 124 307 minecraft:spruce_planks
setblock 48 124 314 minecraft:spruce_planks
setblock 52 124 276 minecraft:spruce_planks
setblock 53 124 316 minecraft:spruce_planks
setblock 59 124 276 minecraft:spruce_planks
setblock 60 124 316 minecraft:spruce_planks
setblock 66 124 276 minecraft:spruce_planks
setblock 67 124 316 minecraft:spruce_planks
setblock 73 124 276 minecraft:spruce_planks
setblock 74 124 316 minecraft:spruce_planks
setblock 80 124 276 minecraft:spruce_planks
setblock 81 124 316 minecraft:spruce_planks
fill 82 124 317 82 129 317 minecraft:blue_terracotta
setblock 87 124 276 minecraft:spruce_planks
setblock 88 124 282 minecraft:spruce_planks
setblock 88 124 289 minecraft:spruce_planks
setblock 88 124 296 minecraft:spruce_planks
setblock 88 124 303 minecraft:spruce_planks
setblock 88 124 310 minecraft:spruce_planks
setblock 88 124 316 minecraft:spruce_planks
fill 89 124 276 89 128 277 minecraft:blue_terracotta
setblock 89 124 278 minecraft:light_blue_wool
fill 89 124 313 89 127 313 minecraft:blue_terracotta
setblock 89 124 314 minecraft:white_wool
fill 47 125 290 47 128 290 minecraft:blue_terracotta
setblock 48 125 280 minecraft:spruce_planks
setblock 48 125 287 minecraft:spruce_planks
setblock 48 125 294 minecraft:spruce_planks
setblock 48 125 301 minecraft:spruce_planks
setblock 48 125 308 minecraft:spruce_planks
setblock 48 125 315 minecraft:spruce_planks
setblock 51 125 276 minecraft:spruce_planks
setblock 54 125 316 minecraft:spruce_planks
setblock 58 125 276 minecraft:spruce_planks
setblock 61 125 316 minecraft:spruce_planks
setblock 65 125 276 minecraft:spruce_planks
setblock 68 125 316 minecraft:spruce_planks
fill 72 125 275 73 128 275 minecraft:blue_terracotta
setblock 72 125 276 minecraft:spruce_planks
setblock 74 125 275 minecraft:light_blue_wool
fill 75 125 275 77 129 275 minecraft:blue_terracotta
setblock 75 125 316 minecraft:spruce_planks
setblock 79 125 276 minecraft:spruce_planks
setblock 82 125 316 minecraft:spruce_planks
setblock 86 125 276 minecraft:spruce_planks
setblock 88 125 281 minecraft:spruce_planks
setblock 88 125 288 minecraft:spruce_planks
setblock 88 125 295 minecraft:spruce_planks
setblock 88 125 302 minecraft:spruce_planks
setblock 88 125 309 minecraft:spruce_planks
fill 89 125 278 89 131 278 minecraft:blue_terracotta
setblock 89 125 292 minecraft:white_wool
fill 89 125 314 89 127 314 minecraft:blue_terracotta
setblock 62 126 317 minecraft:white_wool
fill 74 126 275 74 127 275 minecraft:blue_terracotta
fill 82 126 279 82 126 282 minecraft:dark_oak_planks
fill 83 126 278 84 126 278 minecraft:dark_oak_planks
setblock 84 126 283 minecraft:dark_oak_planks
setblock 85 126 279 minecraft:dark_oak_planks
setblock 85 126 282 minecraft:dark_oak_planks
fill 86 126 280 86 126 281 minecraft:dark_oak_planks
fill 89 126 292 89 131 292 minecraft:blue_terracotta
setblock 48 127 282 minecraft:spruce_planks
setblock 48 127 289 minecraft:spruce_planks
setblock 48 127 296 minecraft:spruce_planks
setblock 48 127 303 minecraft:spruce_planks
setblock 48 127 310 minecraft:spruce_planks
setblock 49 127 276 minecraft:spruce_planks
setblock 49 127 316 minecraft:spruce_planks
setblock 52 127 317 minecraft:white_wool
fill 53 127 317 53 131 317 minecraft:blue_terracotta
setblock 56 127 276 minecraft:spruce_planks
setblock 56 127 316 minecraft:spruce_planks
fill 62 127 317 62 131 317 minecraft:blue_terracotta
setblock 63 127 276 minecraft:spruce_planks
setblock 63 127 316 minecraft:spruce_planks
setblock 70 127 276 minecraft:spruce_planks
setblock 70 127 316 minecraft:spruce_planks
setblock 77 127 276 minecraft:spruce_planks
setblock 77 127 316 minecraft:spruce_planks
setblock 84 127 276 minecraft:spruce_planks
setblock 84 127 316 minecraft:spruce_planks
setblock 88 127 279 minecraft:spruce_planks
setblock 88 127 286 minecraft:spruce_planks
setblock 88 127 293 minecraft:spruce_planks
setblock 88 127 300 minecraft:spruce_planks
setblock 88 127 307 minecraft:spruce_planks
setblock 88 127 314 minecraft:spruce_planks
setblock 47 128 280 minecraft:blue_concrete
setblock 47 128 287 minecraft:blue_concrete
fill 47 128 298 47 131 298 minecraft:blue_terracotta
fill 47 128 299 47 130 299 minecraft:blue_concrete
fill 47 128 309 47 131 309 minecraft:blue_terracotta
setblock 47 128 310 minecraft:blue_concrete
setblock 47 128 311 minecraft:blue_terracotta
fill 47 128 312 47 129 312 minecraft:blue_concrete
setblock 47 128 315 minecraft:blue_concrete
setblock 48 128 276 minecraft:spruce_planks
setblock 48 128 283 minecraft:spruce_planks
setblock 48 128 290 minecraft:spruce_planks
setblock 48 128 297 minecraft:spruce_planks
setblock 48 128 304 minecraft:spruce_planks
setblock 48 128 311 minecraft:spruce_planks
setblock 50 128 278 minecraft:light[level=12]
setblock 50 128 285 minecraft:light[level=12]
setblock 50 128 292 minecraft:light[level=12]
setblock 50 128 299 minecraft:light[level=12]
setblock 50 128 306 minecraft:light[level=12]
setblock 50 128 313 minecraft:light[level=12]
setblock 50 128 316 minecraft:spruce_planks
setblock 51 128 317 minecraft:blue_concrete
fill 52 128 317 52 131 317 minecraft:blue_terracotta
setblock 54 128 275 minecraft:blue_concrete
fill 55 128 275 55 131 275 minecraft:blue_terracotta
setblock 55 128 276 minecraft:spruce_planks
fill 56 128 275 56 129 275 minecraft:blue_concrete
setblock 57 128 278 minecraft:light[level=12]
setblock 57 128 285 minecraft:light[level=12]
setblock 57 128 292 minecraft:light[level=12]
setblock 57 128 299 minecraft:light[level=12]
setblock 57 128 306 minecraft:light[level=12]
setblock 57 128 313 minecraft:light[level=12]
setblock 57 128 316 minecraft:spruce_planks
fill 59 128 275 60 128 275 minecraft:blue_concrete
setblock 62 128 276 minecraft:spruce_planks
fill 63 128 317 63 131 317 minecraft:blue_terracotta
setblock 64 128 278 minecraft:light[level=12]
setblock 64 128 285 minecraft:light[level=12]
setblock 64 128 292 minecraft:light[level=12]
setblock 64 128 299 minecraft:light[level=12]
setblock 64 128 306 minecraft:light[level=12]
setblock 64 128 313 minecraft:light[level=12]
setblock 64 128 316 minecraft:spruce_planks
setblock 64 128 317 minecraft:blue_concrete
fill 65 128 317 65 129 317 minecraft:blue_terracotta
fill 66 128 275 67 128 275 minecraft:blue_terracotta
setblock 68 128 275 minecraft:blue_concrete
setblock 69 128 276 minecraft:spruce_planks
setblock 71 128 278 minecraft:light[level=12]
setblock 71 128 285 minecraft:light[level=12]
setblock 71 128 292 minecraft:light[level=12]
setblock 71 128 299 minecraft:light[level=12]
setblock 71 128 306 minecraft:light[level=12]
setblock 71 128 313 minecraft:light[level=12]
setblock 71 128 316 minecraft:spruce_planks
setblock 74 128 275 minecraft:blue_concrete
setblock 75 128 317 minecraft:blue_concrete
setblock 76 128 276 minecraft:spruce_planks
setblock 78 128 275 minecraft:blue_concrete
setblock 78 128 278 minecraft:light[level=12]
setblock 78 128 285 minecraft:light[level=12]
setblock 78 128 292 minecraft:light[level=12]
setblock 78 128 299 minecraft:light[level=12]
setblock 78 128 306 minecraft:light[level=12]
setblock 78 128 313 minecraft:light[level=12]
setblock 78 128 316 minecraft:spruce_planks
setblock 83 128 276 minecraft:spruce_planks
fill 85 128 275 88 129 275 minecraft:blue_terracotta
setblock 85 128 278 minecraft:light[level=12]
setblock 85 128 285 minecraft:light[level=12]
setblock 85 128 292 minecraft:light[level=12]
setblock 85 128 299 minecraft:light[level=12]
setblock 85 128 306 minecraft:light[level=12]
setblock 85 128 313 minecraft:light[level=12]
setblock 85 128 316 minecraft:spruce_planks
setblock 88 128 278 minecraft:spruce_planks
setblock 88 128 285 minecraft:spruce_planks
setblock 88 128 292 minecraft:spruce_planks
setblock 88 128 299 minecraft:spruce_planks
setblock 88 128 306 minecraft:spruce_planks
setblock 88 128 313 minecraft:spruce_planks
setblock 89 128 275 minecraft:blue_concrete
setblock 89 128 283 minecraft:white_wool
fill 89 128 284 89 128 285 minecraft:blue_concrete
setblock 89 128 309 minecraft:blue_concrete
fill 89 128 313 89 128 314 minecraft:blue_concrete
fill 47 129 280 47 131 280 minecraft:blue_terracotta
setblock 47 129 283 minecraft:blue_concrete
fill 47 129 284 47 131 284 minecraft:blue_terracotta
setblock 47 129 286 minecraft:blue_concrete
fill 47 129 287 47 131 287 minecraft:blue_terracotta
setblock 47 129 290 minecraft:blue_concrete
setblock 47 129 294 minecraft:blue_concrete
fill 47 129 295 47 131 296 minecraft:blue_terracotta
setblock 47 129 300 minecraft:blue_concrete
setblock 47 129 305 minecraft:blue_concrete
fill 47 129 310 47 131 310 minecraft:blue_terracotta
setblock 47 129 311 minecraft:blue_concrete
fill 47 129 315 47 131 316 minecraft:blue_terracotta
fill 47 129 317 48 129 317 minecraft:blue_concrete
fill 48 129 277 48 130 277 minecraft:spruce_planks
fill 48 129 284 48 130 284 minecraft:spruce_planks
fill 48 129 291 48 130 291 minecraft:spruce_planks
fill 48 129 298 48 130 298 minecraft:spruce_planks
fill 48 129 305 48 130 305 minecraft:spruce_planks
fill 48 129 312 48 130 312 minecraft:spruce_planks
setblock 50 129 317 minecraft:blue_concrete
fill 51 129 316 51 130 316 minecraft:spruce_planks
fill 51 129 317 51 131 317 minecraft:blue_terracotta
fill 54 129 275 54 131 275 minecraft:blue_terracotta
fill 54 129 276 54 130 276 minecraft:spruce_planks
fill 58 129 316 58 130 316 minecraft:spruce_planks
fill 59 129 275 60 129 275 minecraft:blue_terracotta
setblock 61 129 275 minecraft:blue_concrete
fill 61 129 276 61 130 276 minecraft:spruce_planks
fill 62 129 275 62 131 275 minecraft:blue_terracotta
setblock 63 129 275 minecraft:light_blue_wool
fill 64 129 317 64 131 317 minecraft:blue_terracotta
fill 65 129 316 65 130 316 minecraft:spruce_planks
fill 66 129 275 66 131 275 minecraft:blue_terracotta
setblock 67 129 275 minecraft:blue_concrete
setblock 68 129 275 minecraft:blue_terracotta
fill 68 129 276 68 130 276 minecraft:spruce_planks
fill 72 129 275 72 131 275 minecraft:blue_terracotta
fill 72 129 316 72 130 316 minecraft:spruce_planks
setblock 73 129 275 minecraft:blue_concrete
fill 74 129 275 74 131 275 minecraft:blue_terracotta
fill 75 129 276 75 130 276 minecraft:spruce_planks
fill 75 129 317 75 131 317 minecraft:blue_terracotta
fill 78 129 275 78 132 275 minecraft:blue_terracotta
fill 79 129 316 79 130 316 minecraft:spruce_planks
fill 82 129 276 82 130 276 minecraft:spruce_planks
fill 86 129 316 86 130 316 minecraft:spruce_planks
fill 88 129 277 88 130 277 minecraft:spruce_planks
fill 88 129 284 88 130 284 minecraft:spruce_planks
fill 88 129 291 88 130 291 minecraft:spruce_planks
fill 88 129 298 88 130 298 minecraft:spruce_planks
fill 88 129 305 88 130 305 minecraft:spruce_planks
fill 88 129 312 88 130 312 minecraft:spruce_planks
fill 89 129 275 89 131 275 minecraft:blue_terracotta
setblock 89 129 276 minecraft:blue_concrete
fill 89 129 277 89 131 277 minecraft:blue_terracotta
setblock 89 129 283 minecraft:blue_concrete
fill 89 129 284 89 131 285 minecraft:blue_terracotta
fill 89 129 293 89 129 294 minecraft:white_wool
setblock 89 129 299 minecraft:light_blue_wool
fill 89 129 309 89 131 309 minecraft:blue_terracotta
fill 89 129 313 89 131 314 minecraft:blue_terracotta
fill 47 130 283 47 131 283 minecraft:blue_terracotta
setblock 47 130 285 minecraft:blue_concrete
fill 47 130 286 47 131 286 minecraft:blue_terracotta
fill 47 130 290 47 131 290 minecraft:blue_terracotta
fill 47 130 294 47 131 294 minecraft:blue_terracotta
fill 47 130 300 47 131 300 minecraft:blue_terracotta
fill 47 130 305 47 131 305 minecraft:blue_terracotta
fill 47 130 311 47 131 312 minecraft:blue_terracotta
setblock 47 130 314 minecraft:blue_concrete
fill 47 130 317 48 131 317 minecraft:blue_terracotta
fill 48 130 276 49 130 276 minecraft:spruce_planks
fill 48 130 278 48 130 280 minecraft:spruce_planks
fill 48 130 282 48 130 283 minecraft:spruce_planks
fill 48 130 285 48 130 287 minecraft:spruce_planks
fill 48 130 289 48 130 290 minecraft:spruce_planks
fill 48 130 292 48 130 294 minecraft:spruce_planks
fill 48 130 296 48 130 297 minecraft:spruce_planks
fill 48 130 299 48 130 301 minecraft:spruce_planks
fill 48 130 303 48 130 304 minecraft:spruce_planks
fill 48 130 306 48 130 308 minecraft:spruce_planks
fill 48 130 310 48 130 311 minecraft:spruce_planks
fill 48 130 313 48 130 315 minecraft:spruce_planks
fill 49 130 316 50 130 316 minecraft:spruce_planks
setblock 50 130 278 minecraft:light[level=15]
setblock 50 130 286 minecraft:light[level=15]
setblock 50 130 294 minecraft:light[level=15]
setblock 50 130 302 minecraft:light[level=15]
setblock 50 130 310 minecraft:light[level=15]
fill 50 130 317 50 132 317 minecraft:blue_terracotta
fill 51 130 276 53 130 276 minecraft:spruce_planks
fill 52 130 316 54 130 316 minecraft:spruce_planks
fill 55 130 276 56 130 276 minecraft:spruce_planks
setblock 55 130 317 minecraft:white_wool
fill 56 130 275 56 131 275 minecraft:blue_terracotta
fill 56 130 316 57 130 316 minecraft:spruce_planks
fill 56 130 317 56 132 317 minecraft:blue_terracotta
setblock 57 130 275 minecraft:blue_concrete
fill 58 130 276 60 130 276 minecraft:spruce_planks
setblock 58 130 278 minecraft:light[level=15]
setblock 58 130 286 minecraft:light[level=15]
setblock 58 130 294 minecraft:light[level=15]
setblock 58 130 302 minecraft:light[level=15]
setblock 58 130 310 minecraft:light[level=15]
setblock 59 130 275 minecraft:blue_concrete
fill 59 130 316 61 130 316 minecraft:spruce_planks
fill 60 130 275 61 131 275 minecraft:blue_terracotta
fill 62 130 276 63 130 276 minecraft:spruce_planks
fill 63 130 275 63 131 275 minecraft:blue_terracotta
fill 63 130 316 64 130 316 minecraft:spruce_planks
fill 65 130 276 67 130 276 minecraft:spruce_planks
setblock 65 130 317 minecraft:blue_concrete
setblock 66 130 278 minecraft:light[level=15]
setblock 66 130 286 minecraft:light[level=15]
setblock 66 130 302 minecraft:light[level=15]
setblock 66 130 310 minecraft:light[level=15]
fill 66 130 316 68 130 316 minecraft:spruce_planks
fill 67 130 275 67 131 275 minecraft:blue_terracotta
setblock 68 130 275 minecraft:blue_concrete
fill 69 130 276 70 130 276 minecraft:spruce_planks
fill 70 130 316 71 130 316 minecraft:spruce_planks
setblock 70 130 317 minecraft:blue_concrete
fill 72 130 276 74 130 276 minecraft:spruce_planks
fill 73 130 275 73 131 275 minecraft:blue_terracotta
fill 73 130 316 75 130 316 minecraft:spruce_planks
setblock 74 130 278 minecraft:light[level=15]
setblock 74 130 286 minecraft:light[level=15]
setblock 74 130 294 minecraft:light[level=15]
setblock 74 130 302 minecraft:light[level=15]
setblock 74 130 310 minecraft:light[level=15]
fill 75 130 275 75 131 275 minecraft:blue_terracotta
setblock 76 130 275 minecraft:light_blue_wool
fill 76 130 276 77 130 276 minecraft:spruce_planks
fill 77 130 275 77 131 275 minecraft:blue_terracotta
fill 77 130 316 78 130 316 minecraft:spruce_planks
setblock 77 130 317 minecraft:light_blue_wool
fill 79 130 276 81 130 276 minecraft:spruce_planks
fill 80 130 316 82 130 316 minecraft:spruce_planks
setblock 82 130 278 minecraft:light[level=15]
setblock 82 130 286 minecraft:light[level=15]
setblock 82 130 294 minecraft:light[level=15]
setblock 82 130 302 minecraft:light[level=15]
setblock 82 130 310 minecraft:light[level=15]
setblock 82 130 317 minecraft:light_blue_wool
fill 83 130 276 84 130 276 minecraft:spruce_planks
fill 84 130 316 85 130 316 minecraft:spruce_planks
fill 85 130 275 86 130 275 minecraft:blue_concrete
fill 86 130 276 88 130 276 minecraft:spruce_planks
fill 87 130 275 88 131 275 minecraft:blue_terracotta
fill 87 130 316 88 130 316 minecraft:spruce_planks
fill 88 130 278 88 130 279 minecraft:spruce_planks
fill 88 130 281 88 130 283 minecraft:spruce_planks
fill 88 130 285 88 130 286 minecraft:spruce_planks
fill 88 130 288 88 130 290 minecraft:spruce_planks
fill 88 130 292 88 130 293 minecraft:spruce_planks
fill 88 130 295 88 130 297 minecraft:spruce_planks
fill 88 130 299 88 130 300 minecraft:spruce_planks
fill 88 130 302 88 130 304 minecraft:spruce_planks
fill 88 130 306 88 130 307 minecraft:spruce_planks
fill 88 130 309 88 130 311 minecraft:spruce_planks
fill 88 130 313 88 130 314 minecraft:spruce_planks
fill 89 130 276 89 131 276 minecraft:blue_terracotta
setblock 89 130 280 minecraft:blue_concrete
setblock 89 130 282 minecraft:blue_concrete
fill 89 130 283 89 131 283 minecraft:blue_terracotta
setblock 89 130 293 minecraft:blue_concrete
fill 89 130 294 89 131 294 minecraft:blue_terracotta
setblock 89 130 296 minecraft:blue_concrete
fill 89 130 299 89 131 299 minecraft:blue_terracotta
setblock 89 130 312 minecraft:blue_concrete
setblock 89 130 315 minecraft:blue_concrete
setblock 47 131 285 minecraft:blue_terracotta
setblock 47 131 299 minecraft:blue_terracotta
setblock 47 131 314 minecraft:blue_terracotta
setblock 48 131 279 minecraft:spruce_planks
setblock 48 131 286 minecraft:spruce_planks
setblock 48 131 293 minecraft:spruce_planks
setblock 48 131 300 minecraft:spruce_planks
setblock 48 131 307 minecraft:spruce_planks
setblock 48 131 314 minecraft:spruce_planks
setblock 52 131 276 minecraft:spruce_planks
setblock 53 131 316 minecraft:spruce_planks
setblock 55 131 317 minecraft:blue_terracotta
setblock 57 131 275 minecraft:blue_terracotta
setblock 59 131 275 minecraft:blue_terracotta
setblock 59 131 276 minecraft:spruce_planks
setblock 60 131 316 minecraft:spruce_planks
setblock 65 131 317 minecraft:blue_terracotta
setblock 66 131 276 minecraft:spruce_planks
setblock 67 131 316 minecraft:spruce_planks
setblock 68 131 275 minecraft:blue_terracotta
setblock 70 131 317 minecraft:blue_terracotta
setblock 73 131 276 minecraft:spruce_planks
setblock 74 131 316 minecraft:spruce_planks
setblock 76 131 275 minecraft:blue_terracotta
setblock 77 131 317 minecraft:blue_terracotta
setblock 80 131 276 minecraft:spruce_planks
setblock 81 131 316 minecraft:spruce_planks
setblock 82 131 317 minecraft:blue_terracotta
fill 85 131 275 86 131 275 minecraft:blue_terracotta
setblock 87 131 276 minecraft:spruce_planks
setblock 88 131 282 minecraft:spruce_planks
setblock 88 131 289 minecraft:spruce_planks
setblock 88 131 296 minecraft:spruce_planks
setblock 88 131 303 minecraft:spruce_planks
setblock 88 131 310 minecraft:spruce_planks
setblock 88 131 316 minecraft:spruce_planks
setblock 89 131 280 minecraft:blue_terracotta
setblock 89 131 282 minecraft:blue_terracotta
setblock 89 131 293 minecraft:blue_terracotta
setblock 89 131 296 minecraft:blue_terracotta
setblock 89 131 312 minecraft:blue_terracotta
setblock 89 131 315 minecraft:blue_terracotta
fill 47 132 275 47 132 290 minecraft:blue_concrete
fill 47 132 292 47 132 300 minecraft:blue_concrete
setblock 47 132 301 minecraft:blue_terracotta
fill 47 132 302 47 133 303 minecraft:blue_concrete
fill 47 132 305 47 187 305 minecraft:blue_concrete
fill 47 132 307 47 132 317 minecraft:blue_concrete
fill 48 132 275 49 179 275 minecraft:blue_concrete
setblock 48 132 280 minecraft:spruce_planks
setblock 48 132 287 minecraft:spruce_planks
setblock 48 132 294 minecraft:spruce_planks
setblock 48 132 301 minecraft:spruce_planks
setblock 48 132 308 minecraft:spruce_planks
setblock 48 132 315 minecraft:spruce_planks
setblock 48 132 317 minecraft:blue_terracotta
fill 49 132 317 49 188 317 minecraft:blue_concrete
setblock 51 132 275 minecraft:blue_terracotta
setblock 51 132 276 minecraft:spruce_planks
fill 51 132 317 55 146 317 minecraft:blue_concrete
fill 52 132 275 57 133 275 minecraft:blue_concrete
setblock 54 132 316 minecraft:spruce_planks
fill 57 132 317 60 145 317 minecraft:blue_concrete
setblock 58 132 276 minecraft:spruce_planks
fill 59 132 275 64 132 275 minecraft:blue_concrete
setblock 61 132 316 minecraft:spruce_planks
setblock 61 132 317 minecraft:white_wool
fill 62 132 317 67 132 317 minecraft:blue_concrete
setblock 65 132 276 minecraft:spruce_planks
fill 66 132 275 77 132 275 minecraft:blue_concrete
setblock 68 132 316 minecraft:spruce_planks
setblock 68 132 317 minecraft:blue_terracotta
fill 69 132 317 84 132 317 minecraft:blue_concrete
setblock 72 132 276 minecraft:spruce_planks
setblock 75 132 316 minecraft:spruce_planks
fill 79 132 275 80 132 275 minecraft:blue_concrete
setblock 79 132 276 minecraft:spruce_planks
setblock 82 132 275 minecraft:blue_terracotta
setblock 82 132 316 minecraft:spruce_planks
fill 83 132 275 87 132 275 minecraft:blue_concrete
setblock 85 132 317 minecraft:blue_terracotta
setblock 86 132 276 minecraft:spruce_planks
fill 86 132 317 88 145 317 minecraft:blue_concrete
setblock 88 132 275 minecraft:blue_terracotta
setblock 88 132 281 minecraft:spruce_planks
setblock 88 132 288 minecraft:spruce_planks
setblock 88 132 295 minecraft:spruce_planks
setblock 88 132 302 minecraft:spruce_planks
setblock 88 132 309 minecraft:spruce_planks
fill 89 132 275 89 132 278 minecraft:blue_concrete
fill 89 132 280 89 132 283 minecraft:blue_concrete
setblock 89 132 284 minecraft:blue_terracotta
fill 89 132 285 89 132 300 minecraft:blue_concrete
fill 89 132 302 89 132 312 minecraft:blue_concrete
setblock 89 132 313 minecraft:blue_terracotta
fill 89 132 314 89 132 316 minecraft:blue_concrete
setblock 89 132 317 minecraft:blue_terracotta
fill 47 133 275 47 145 282 minecraft:blue_concrete
setblock 47 133 283 minecraft:blue_terracotta
fill 47 133 284 47 133 296 minecraft:blue_concrete
fill 47 133 297 47 134 297 minecraft:blue_terracotta
fill 47 133 298 47 151 301 minecraft:blue_concrete
fill 47 133 304 47 151 304 minecraft:blue_concrete
fill 47 133 306 47 159 307 minecraft:blue_concrete
setblock 47 133 308 minecraft:blue_terracotta
fill 47 133 309 47 138 316 minecraft:blue_concrete
setblock 47 133 317 minecraft:blue_terracotta
fill 48 133 317 48 136 317 minecraft:blue_concrete
fill 50 133 275 51 186 275 minecraft:blue_concrete
setblock 50 133 317 minecraft:blue_concrete
setblock 56 133 317 minecraft:blue_concrete
fill 58 133 275 58 169 275 minecraft:blue_concrete
setblock 59 133 275 minecraft:blue_terracotta
fill 60 133 275 73 133 275 minecraft:blue_concrete
fill 61 133 317 61 155 317 minecraft:blue_concrete
fill 62 133 317 62 134 317 minecraft:blue_terracotta
fill 63 133 317 64 179 317 minecraft:blue_concrete
setblock 65 133 317 minecraft:blue_terracotta
fill 66 133 317 70 149 317 minecraft:blue_concrete
setblock 71 133 317 minecraft:blue_terracotta
fill 72 133 317 77 133 317 minecraft:blue_concrete
setblock 74 133 275 minecraft:blue_terracotta
fill 75 133 275 78 133 275 minecraft:blue_concrete
setblock 78 133 317 minecraft:blue_terracotta
setblock 79 133 275 minecraft:blue_terracotta
fill 79 133 317 85 133 317 minecraft:blue_concrete
fill 80 133 275 86 133 275 minecraft:blue_concrete
setblock 87 133 275 minecraft:blue_terracotta
setblock 88 133 275 minecraft:blue_concrete
fill 89 133 275 89 133 276 minecraft:blue_terracotta
fill 89 133 277 89 137 282 minecraft:blue_concrete
setblock 89 133 283 minecraft:blue_terracotta
fill 89 133 284 89 141 288 minecraft:blue_concrete
setblock 89 133 289 minecraft:blue_terracotta
fill 89 133 290 89 150 296 minecraft:blue_concrete
setblock 89 133 297 minecraft:white_wool
fill 89 133 298 89 133 306 minecraft:blue_concrete
setblock 89 133 307 minecraft:blue_terracotta
fill 89 133 308 89 148 309 minecraft:blue_concrete
setblock 89 133 310 minecraft:blue_terracotta
fill 89 133 311 89 165 313 minecraft:blue_concrete
setblock 89 133 314 minecraft:blue_terracotta
fill 89 133 315 89 187 317 minecraft:blue_concrete
fill 47 134 283 47 186 285 minecraft:blue_concrete
setblock 47 134 286 minecraft:blue_terracotta
fill 47 134 287 47 154 290 minecraft:blue_concrete
fill 47 134 291 47 134 292 minecraft:blue_terracotta
fill 47 134 293 47 190 294 minecraft:blue_concrete
setblock 47 134 295 minecraft:blue_terracotta
fill 47 134 296 47 190 296 minecraft:blue_concrete
setblock 47 134 302 minecraft:blue_terracotta
fill 47 134 303 47 176 303 minecraft:blue_concrete
fill 47 134 308 47 165 308 minecraft:blue_concrete
fill 47 134 317 47 186 317 minecraft:blue_concrete
setblock 48 134 282 minecraft:spruce_planks
setblock 48 134 289 minecraft:spruce_planks
setblock 48 134 296 minecraft:spruce_planks
setblock 48 134 303 minecraft:spruce_planks
setblock 48 134 310 minecraft:spruce_planks
setblock 49 134 276 minecraft:spruce_planks
setblock 49 134 316 minecraft:spruce_planks
setblock 50 134 278 minecraft:light[level=12]
setblock 50 134 285 minecraft:light[level=12]
setblock 50 134 292 minecraft:light[level=12]
setblock 50 134 299 minecraft:light[level=12]
setblock 50 134 306 minecraft:light[level=12]
setblock 50 134 313 minecraft:light[level=12]
setblock 50 134 317 minecraft:blue_terracotta
fill 52 134 275 56 149 275 minecraft:blue_concrete
setblock 56 134 276 minecraft:spruce_planks
setblock 56 134 316 minecraft:spruce_planks
setblock 56 134 317 minecraft:blue_terracotta
setblock 57 134 275 minecraft:blue_terracotta
setblock 57 134 278 minecraft:light[level=12]
setblock 57 134 285 minecraft:light[level=12]
setblock 57 134 292 minecraft:light[level=12]
setblock 57 134 299 minecraft:light[level=12]
setblock 57 134 306 minecraft:light[level=12]
setblock 57 134 313 minecraft:light[level=12]
fill 59 134 275 68 143 275 minecraft:blue_concrete
setblock 63 134 276 minecraft:spruce_planks
setblock 63 134 316 minecraft:spruce_planks
setblock 64 134 278 minecraft:light[level=12]
setblock 64 134 285 minecraft:light[level=12]
setblock 64 134 292 minecraft:light[level=12]
setblock 64 134 299 minecraft:light[level=12]
setblock 64 134 306 minecraft:light[level=12]
setblock 64 134 313 minecraft:light[level=12]
fill 65 134 317 65 191 317 minecraft:blue_concrete
setblock 69 134 275 minecraft:blue_terracotta
fill 70 134 275 72 152 275 minecraft:blue_concrete
setblock 70 134 276 minecraft:spruce_planks
setblock 70 134 316 minecraft:spruce_planks
setblock 71 134 278 minecraft:light[level=12]
setblock 71 134 285 minecraft:light[level=12]
setblock 71 134 292 minecraft:light[level=12]
setblock 71 134 299 minecraft:light[level=12]
setblock 71 134 306 minecraft:light[level=12]
setblock 71 134 313 minecraft:light[level=12]
fill 71 134 317 75 138 317 minecraft:blue_concrete
setblock 73 134 275 minecraft:blue_terracotta
fill 74 134 275 77 143 275 minecraft:blue_concrete
setblock 76 134 317 minecraft:blue_terracotta
setblock 77 134 276 minecraft:spruce_planks
setblock 77 134 316 minecraft:spruce_planks
fill 77 134 317 78 143 317 minecraft:blue_concrete
setblock 78 134 275 minecraft:blue_terracotta
setblock 78 134 278 minecraft:light[level=12]
setblock 78 134 285 minecraft:light[level=12]
setblock 78 134 292 minecraft:light[level=12]
setblock 78 134 299 minecraft:light[level=12]
setblock 78 134 306 minecraft:light[level=12]
setblock 78 134 313 minecraft:light[level=12]
fill 79 134 275 80 165 275 minecraft:blue_concrete
setblock 79 134 317 minecraft:light_blue_wool
fill 80 134 317 85 138 317 minecraft:blue_concrete
fill 81 134 275 82 134 275 minecraft:blue_terracotta
fill 82 134 279 82 134 282 minecraft:dark_oak_planks
fill 83 134 275 87 141 275 minecraft:blue_concrete
fill 83 134 278 84 134 278 minecraft:dark_oak_planks
setblock 84 134 276 minecraft:spruce_planks
setblock 84 134 283 minecraft:dark_oak_planks
setblock 84 134 316 minecraft:spruce_planks
setblock 85 134 278 minecraft:light[level=12]
setblock 85 134 279 minecraft:dark_oak_planks
setblock 85 134 282 minecraft:dark_oak_planks
setblock 85 134 285 minecraft:light[level=12]
setblock 85 134 292 minecraft:light[level=12]
setblock 85 134 299 minecraft:light[level=12]
setblock 85 134 306 minecraft:light[level=12]
setblock 85 134 313 minecraft:light[level=12]
fill 86 134 280 86 134 281 minecraft:dark_oak_planks
setblock 88 134 275 minecraft:blue_terracotta
setblock 88 134 279 minecraft:spruce_planks
setblock 88 134 286 minecraft:spruce_planks
setblock 88 134 293 minecraft:spruce_planks
setblock 88 134 300 minecraft:spruce_planks
setblock 88 134 307 minecraft:spruce_planks
setblock 88 134 314 minecraft:spruce_planks
fill 89 134 275 89 187 276 minecraft:blue_concrete
fill 89 134 283 89 186 283 minecraft:blue_concrete
fill 89 134 289 89 190 289 minecraft:blue_concrete
fill 89 134 297 89 156 297 minecraft:blue_concrete
setblock 89 134 298 minecraft:blue_terracotta
fill 89 134 299 89 144 300 minecraft:blue_concrete
setblock 89 134 301 minecraft:blue_terracotta
fill 89 134 302 89 144 307 minecraft:blue_concrete
fill 89 134 310 89 186 310 minecraft:blue_concrete
fill 89 134 314 89 141 314 minecraft:blue_concrete
fill 47 135 286 47 174 286 minecraft:blue_concrete
fill 47 135 291 47 143 292 minecraft:blue_concrete
fill 47 135 295 47 183 295 minecraft:blue_concrete
fill 47 135 297 47 187 297 minecraft:blue_concrete
fill 47 135 302 47 187 302 minecraft:blue_concrete
setblock 48 135 276 minecraft:spruce_planks
setblock 48 135 283 minecraft:spruce_planks
setblock 48 135 290 minecraft:spruce_planks
setblock 48 135 297 minecraft:spruce_planks
setblock 48 135 304 minecraft:spruce_planks
setblock 48 135 311 minecraft:spruce_planks
setblock 50 135 316 minecraft:spruce_planks
fill 50 135 317 50 167 317 minecraft:blue_concrete
setblock 55 135 276 minecraft:spruce_planks
fill 56 135 317 56 141 317 minecraft:blue_concrete
fill 57 135 275 57 187 275 minecraft:blue_concrete
setblock 57 135 316 minecraft:spruce_planks
setblock 62 135 276 minecraft:spruce_planks
fill 62 135 317 62 188 317 minecraft:blue_concrete
setblock 64 135 316 minecraft:spruce_planks
fill 69 135 275 69 184 275 minecraft:blue_concrete
setblock 69 135 276 minecraft:spruce_planks
setblock 71 135 316 minecraft:spruce_planks
fill 73 135 275 73 190 275 minecraft:blue_concrete
setblock 76 135 276 minecraft:spruce_planks
fill 76 135 317 76 185 317 minecraft:blue_concrete
fill 78 135 275 78 168 275 minecraft:blue_concrete
setblock 78 135 316 minecraft:spruce_planks
fill 79 135 317 79 186 317 minecraft:blue_concrete
fill 81 135 275 82 188 275 minecraft:blue_concrete
setblock 83 135 276 minecraft:spruce_planks
setblock 85 135 316 minecraft:spruce_planks
fill 88 135 275 88 138 275 minecraft:blue_concrete
setblock 88 135 278 minecraft:spruce_planks
setblock 88 135 285 minecraft:spruce_planks
setblock 88 135 292 minecraft:spruce_planks
setblock 88 135 299 minecraft:spruce_planks
setblock 88 135 306 minecraft:spruce_planks
setblock 88 135 313 minecraft:spruce_planks
fill 89 135 298 89 186 298 minecraft:blue_concrete
fill 89 135 301 89 144 301 minecraft:blue_concrete
setblock 48 136 277 minecraft:spruce_planks
fill 48 136 280 56 142 280 minecraft:white_wool
setblock 48 136 284 minecraft:spruce_planks
setblock 48 136 291 minecraft:spruce_planks
setblock 48 136 298 minecraft:spruce_planks
setblock 48 136 305 minecraft:spruce_planks
setblock 48 136 312 minecraft:spruce_planks
setblock 51 136 316 minecraft:spruce_planks
setblock 54 136 276 minecraft:spruce_planks
setblock 58 136 316 minecraft:spruce_planks
setblock 61 136 276 minecraft:spruce_planks
fill 65 136 313 65 137 315 minecraft:iron_bars
setblock 65 136 316 minecraft:spruce_planks
setblock 68 136 276 minecraft:spruce_planks
setblock 72 136 316 minecraft:spruce_planks
setblock 75 136 276 minecraft:spruce_planks
setblock 79 136 316 minecraft:spruce_planks
fill 80 136 312 88 142 312 minecraft:white_wool
setblock 82 136 276 minecraft:spruce_planks
setblock 86 136 316 minecraft:spruce_planks
setblock 88 136 277 minecraft:spruce_planks
setblock 88 136 284 minecraft:spruce_planks
setblock 88 136 291 minecraft:spruce_planks
setblock 88 136 298 minecraft:spruce_planks
setblock 88 136 305 minecraft:spruce_planks
setblock 48 137 278 minecraft:spruce_planks
setblock 48 137 285 minecraft:spruce_planks
setblock 48 137 292 minecraft:spruce_planks
setblock 48 137 299 minecraft:spruce_planks
setblock 48 137 306 minecraft:spruce_planks
setblock 48 137 313 minecraft:spruce_planks
setblock 48 137 317 minecraft:white_wool
setblock 52 137 316 minecraft:spruce_planks
setblock 53 137 276 minecraft:spruce_planks
setblock 59 137 316 minecraft:spruce_planks
setblock 60 137 276 minecraft:spruce_planks
setblock 66 137 316 minecraft:spruce_planks
setblock 67 137 276 minecraft:spruce_planks
setblock 73 137 316 minecraft:spruce_planks
setblock 74 137 276 minecraft:spruce_planks
setblock 80 137 316 minecraft:spruce_planks
setblock 81 137 276 minecraft:spruce_planks
setblock 87 137 316 minecraft:spruce_planks
setblock 88 137 276 minecraft:spruce_planks
setblock 88 137 283 minecraft:spruce_planks
setblock 88 137 290 minecraft:spruce_planks
setblock 88 137 297 minecraft:spruce_planks
setblock 88 137 304 minecraft:spruce_planks
setblock 88 137 311 minecraft:spruce_planks
setblock 48 138 279 minecraft:spruce_planks
setblock 48 138 286 minecraft:spruce_planks
setblock 48 138 293 minecraft:spruce_planks
setblock 48 138 300 minecraft:spruce_planks
setblock 48 138 307 minecraft:spruce_planks
setblock 48 138 314 minecraft:spruce_planks
fill 48 138 317 48 143 317 minecraft:blue_concrete
setblock 50 138 278 minecraft:light[level=15]
setblock 50 138 286 minecraft:light[level=15]
setblock 50 138 294 minecraft:light[level=15]
setblock 50 138 302 minecraft:light[level=15]
setblock 50 138 310 minecraft:light[level=15]
setblock 52 138 276 minecraft:spruce_planks
setblock 53 138 316 minecraft:spruce_planks
setblock 58 138 278 minecraft:light[level=15]
setblock 58 138 286 minecraft:light[level=15]
setblock 58 138 294 minecraft:light[level=15]
setblock 58 138 302 minecraft:light[level=15]
setblock 58 138 310 minecraft:light[level=15]
setblock 59 138 276 minecraft:spruce_planks
setblock 60 138 316 minecraft:spruce_planks
setblock 66 138 276 minecraft:spruce_planks
setblock 66 138 278 minecraft:light[level=15]
setblock 66 138 286 minecraft:light[level=15]
setblock 66 138 302 minecraft:light[level=15]
setblock 66 138 310 minecraft:light[level=15]
setblock 67 138 316 minecraft:spruce_planks
setblock 73 138 276 minecraft:spruce_planks
setblock 74 138 278 minecraft:light[level=15]
setblock 74 138 286 minecraft:light[level=15]
setblock 74 138 294 minecraft:light[level=15]
setblock 74 138 302 minecraft:light[level=15]
setblock 74 138 310 minecraft:light[level=15]
setblock 74 138 316 minecraft:spruce_planks
setblock 80 138 276 minecraft:spruce_planks
setblock 81 138 316 minecraft:spruce_planks
setblock 82 138 278 minecraft:light[level=15]
setblock 82 138 286 minecraft:light[level=15]
setblock 82 138 294 minecraft:light[level=15]
setblock 82 138 302 minecraft:light[level=15]
setblock 82 138 310 minecraft:light[level=15]
setblock 87 138 276 minecraft:spruce_planks
setblock 88 138 282 minecraft:spruce_planks
setblock 88 138 289 minecraft:spruce_planks
setblock 88 138 296 minecraft:spruce_planks
setblock 88 138 303 minecraft:spruce_planks
setblock 88 138 310 minecraft:spruce_planks
setblock 88 138 316 minecraft:spruce_planks
fill 89 138 277 89 139 281 minecraft:blue_concrete
setblock 89 138 282 minecraft:light_blue_wool
setblock 47 139 309 minecraft:light_blue_wool
fill 47 139 310 47 147 316 minecraft:blue_concrete
fill 48 139 287 48 140 287 minecraft:spruce_planks
fill 48 139 294 48 140 294 minecraft:spruce_planks
fill 48 139 301 48 140 301 minecraft:spruce_planks
fill 48 139 308 48 140 308 minecraft:spruce_planks
fill 48 139 315 48 140 315 minecraft:spruce_planks
fill 51 139 276 51 140 276 minecraft:spruce_planks
fill 54 139 316 54 140 316 minecraft:spruce_planks
fill 58 139 276 58 140 276 minecraft:spruce_planks
fill 61 139 316 61 140 316 minecraft:spruce_planks
fill 63 139 313 63 140 315 minecraft:iron_bars
fill 65 139 276 65 140 276 minecraft:spruce_planks
fill 68 139 316 68 140 316 minecraft:spruce_planks
fill 71 139 317 72 190 317 minecraft:blue_concrete
fill 72 139 276 72 140 276 minecraft:spruce_planks
setblock 73 139 317 minecraft:light_blue_wool
fill 74 139 317 75 190 317 minecraft:blue_concrete
fill 75 139 316 75 140 316 minecraft:spruce_planks
fill 79 139 276 79 140 276 minecraft:spruce_planks
fill 80 139 317 83 149 317 minecraft:blue_concrete
fill 82 139 316 82 140 316 minecraft:spruce_planks
setblock 84 139 317 minecraft:white_wool
fill 85 139 317 85 190 317 minecraft:blue_concrete
fill 86 139 276 86 140 276 minecraft:spruce_planks
setblock 88 139 275 minecraft:white_wool
fill 88 139 281 88 140 281 minecraft:spruce_planks
fill 88 139 288 88 140 288 minecraft:spruce_planks
fill 88 139 295 88 140 295 minecraft:spruce_planks
fill 88 139 302 88 140 302 minecraft:spruce_planks
fill 88 139 309 88 140 309 minecraft:spruce_planks
fill 89 139 282 89 149 282 minecraft:blue_concrete
fill 47 140 309 47 187 309 minecraft:blue_concrete
fill 48 140 276 48 140 279 minecraft:spruce_planks
fill 48 140 282 48 140 286 minecraft:spruce_planks
fill 48 140 289 48 140 293 minecraft:spruce_planks
fill 48 140 296 48 140 300 minecraft:spruce_planks
fill 48 140 303 48 140 307 minecraft:spruce_planks
fill 48 140 310 48 140 314 minecraft:spruce_planks
fill 49 140 276 49 141 276 minecraft:spruce_planks
fill 49 140 316 53 140 316 minecraft:spruce_planks
setblock 50 140 278 minecraft:light[level=12]
setblock 50 140 285 minecraft:light[level=12]
setblock 50 140 292 minecraft:light[level=12]
setblock 50 140 299 minecraft:light[level=12]
setblock 50 140 306 minecraft:light[level=12]
setblock 50 140 313 minecraft:light[level=12]
fill 52 140 276 56 140 276 minecraft:spruce_planks
fill 56 140 316 60 140 316 minecraft:spruce_planks
setblock 57 140 278 minecraft:light[level=12]
setblock 57 140 285 minecraft:light[level=12]
setblock 57 140 292 minecraft:light[level=12]
setblock 57 140 299 minecraft:light[level=12]
setblock 57 140 306 minecraft:light[level=12]
setblock 57 140 313 minecraft:light[level=12]
fill 59 140 276 63 140 276 minecraft:spruce_planks
fill 63 140 316 67 140 316 minecraft:spruce_planks
setblock 64 140 278 minecraft:light[level=12]
setblock 64 140 285 minecraft:light[level=12]
setblock 64 140 292 minecraft:light[level=12]
setblock 64 140 299 minecraft:light[level=12]
setblock 64 140 306 minecraft:light[level=12]
setblock 64 140 313 minecraft:light[level=12]
fill 66 140 276 70 140 276 minecraft:spruce_planks
fill 70 140 316 74 140 316 minecraft:spruce_planks
setblock 71 140 278 minecraft:light[level=12]
setblock 71 140 285 minecraft:light[level=12]
setblock 71 140 292 minecraft:light[level=12]
setblock 71 140 299 minecraft:light[level=12]
setblock 71 140 306 minecraft:light[level=12]
setblock 71 140 313 minecraft:light[level=12]
fill 73 140 276 77 140 276 minecraft:spruce_planks
fill 73 140 317 73 191 317 minecraft:blue_concrete
fill 77 140 316 81 140 316 minecraft:spruce_planks
setblock 78 140 278 minecraft:light[level=12]
setblock 78 140 285 minecraft:light[level=12]
setblock 78 140 292 minecraft:light[level=12]
setblock 78 140 299 minecraft:light[level=12]
setblock 78 140 306 minecraft:light[level=12]
setblock 78 140 313 minecraft:light[level=12]
fill 80 140 276 84 140 276 minecraft:spruce_planks
fill 84 140 316 88 140 316 minecraft:spruce_planks
fill 84 140 317 84 190 317 minecraft:blue_concrete
setblock 85 140 278 minecraft:light[level=12]
setblock 85 140 285 minecraft:light[level=12]
setblock 85 140 292 minecraft:light[level=12]
setblock 85 140 299 minecraft:light[level=12]
setblock 85 140 306 minecraft:light[level=12]
setblock 85 140 313 minecraft:light[level=12]
fill 87 140 276 88 140 276 minecraft:spruce_planks
fill 88 140 275 88 148 275 minecraft:blue_concrete
fill 88 140 277 88 140 279 minecraft:spruce_planks
fill 88 140 282 88 140 286 minecraft:spruce_planks
fill 88 140 289 88 140 293 minecraft:spruce_planks
fill 88 140 296 88 140 300 minecraft:spruce_planks
fill 88 140 303 88 140 307 minecraft:spruce_planks
fill 88 140 310 88 140 311 minecraft:spruce_planks
fill 88 140 313 88 140 314 minecraft:spruce_planks
fill 89 140 277 89 189 277 minecraft:blue_concrete
setblock 89 140 278 minecraft:white_wool
fill 89 140 279 89 144 281 minecraft:blue_concrete
setblock 48 141 282 minecraft:spruce_planks
setblock 48 141 289 minecraft:spruce_planks
setblock 48 141 296 minecraft:spruce_planks
setblock 48 141 303 minecraft:spruce_planks
setblock 48 141 310 minecraft:spruce_planks
setblock 49 141 316 minecraft:spruce_planks
setblock 56 141 276 minecraft:spruce_planks
setblock 56 141 316 minecraft:spruce_planks
setblock 63 141 276 minecraft:spruce_planks
setblock 63 141 316 minecraft:spruce_planks
setblock 70 141 276 minecraft:spruce_planks
setblock 70 141 316 minecraft:spruce_planks
setblock 77 141 276 minecraft:spruce_planks
setblock 77 141 316 minecraft:spruce_planks
setblock 84 141 276 minecraft:spruce_planks
setblock 84 141 316 minecraft:spruce_planks
setblock 88 141 279 minecraft:spruce_planks
setblock 88 141 286 minecraft:spruce_planks
setblock 88 141 293 minecraft:spruce_planks
setblock 88 141 300 minecraft:spruce_planks
setblock 88 141 307 minecraft:spruce_planks
setblock 88 141 314 minecraft:spruce_planks
fill 89 141 278 89 190 278 minecraft:blue_concrete
setblock 48 142 276 minecraft:spruce_planks
setblock 48 142 283 minecraft:spruce_planks
setblock 48 142 290 minecraft:spruce_planks
setblock 48 142 297 minecraft:spruce_planks
setblock 48 142 304 minecraft:spruce_planks
setblock 48 142 311 minecraft:spruce_planks
setblock 50 142 316 minecraft:spruce_planks
setblock 55 142 276 minecraft:spruce_planks
setblock 56 142 317 minecraft:light_blue_wool
setblock 57 142 316 minecraft:spruce_planks
setblock 62 142 276 minecraft:spruce_planks
setblock 64 142 316 minecraft:spruce_planks
setblock 69 142 276 minecraft:spruce_planks
setblock 71 142 316 minecraft:spruce_planks
setblock 76 142 276 minecraft:spruce_planks
setblock 78 142 316 minecraft:spruce_planks
fill 82 142 279 82 142 282 minecraft:dark_oak_planks
fill 83 142 275 85 144 275 minecraft:blue_concrete
setblock 83 142 276 minecraft:spruce_planks
fill 83 142 278 84 142 278 minecraft:dark_oak_planks
setblock 84 142 283 minecraft:dark_oak_planks
setblock 85 142 279 minecraft:dark_oak_planks
setblock 85 142 282 minecraft:dark_oak_planks
setblock 85 142 316 minecraft:spruce_planks
setblock 86 142 275 minecraft:light_blue_wool
fill 86 142 280 86 142 281 minecraft:dark_oak_planks
fill 87 142 275 87 187 275 minecraft:blue_concrete
setblock 88 142 278 minecraft:spruce_planks
setblock 88 142 285 minecraft:spruce_planks
setblock 88 142 292 minecraft:spruce_planks
setblock 88 142 299 minecraft:spruce_planks
setblock 88 142 306 minecraft:spruce_planks
setblock 88 142 313 minecraft:spruce_planks
fill 89 142 284 89 187 286 minecraft:blue_concrete
setblock 89 142 287 minecraft:light_blue_wool
fill 89 142 288 89 160 288 minecraft:blue_concrete
setblock 89 142 314 minecraft:light_blue_wool
setblock 48 143 277 minecraft:spruce_planks
fill 48 143 280 56 143 280 minecraft:spruce_log
setblock 48 143 284 minecraft:spruce_planks
setblock 48 143 291 minecraft:spruce_planks
setblock 48 143 298 minecraft:spruce_planks
setblock 48 143 305 minecraft:spruce_planks
setblock 48 143 312 minecraft:spruce_planks
setblock 51 143 316 minecraft:spruce_planks
setblock 54 143 276 minecraft:spruce_planks
fill 56 143 317 56 171 317 minecraft:blue_concrete
setblock 58 143 316 minecraft:spruce_planks
setblock 61 143 276 minecraft:spruce_planks
setblock 65 143 316 minecraft:spruce_planks
setblock 68 143 276 minecraft:spruce_planks
setblock 72 143 316 minecraft:spruce_planks
setblock 75 143 276 minecraft:spruce_planks
setblock 79 143 316 minecraft:spruce_planks
fill 80 143 312 88 143 312 minecraft:spruce_log
setblock 82 143 276 minecraft:spruce_planks
fill 86 143 275 86 176 275 minecraft:blue_concrete
setblock 86 143 316 minecraft:spruce_planks
setblock 88 143 277 minecraft:spruce_planks
setblock 88 143 284 minecraft:spruce_planks
setblock 88 143 291 minecraft:spruce_planks
setblock 88 143 298 minecraft:spruce_planks
setblock 88 143 305 minecraft:spruce_planks
fill 89 143 287 89 191 287 minecraft:blue_concrete
fill 89 143 314 89 150 314 minecraft:blue_concrete
setblock 47 144 291 minecraft:light_blue_wool
fill 47 144 292 47 155 292 minecraft:blue_concrete
setblock 48 144 278 minecraft:spruce_planks
setblock 48 144 285 minecraft:spruce_planks
setblock 48 144 292 minecraft:spruce_planks
setblock 48 144 299 minecraft:spruce_planks
setblock 48 144 306 minecraft:spruce_planks
setblock 48 144 313 minecraft:spruce_planks
setblock 48 144 317 minecraft:white_wool
fill 51 144 280 53 155 280 minecraft:spruce_log
setblock 52 144 316 minecraft:spruce_planks
setblock 53 144 276 minecraft:spruce_planks
fill 59 144 275 61 148 275 minecraft:blue_concrete
setblock 59 144 316 minecraft:spruce_planks
setblock 60 144 276 minecraft:spruce_planks
fill 62 144 275 63 144 275 minecraft:light_blue_wool
fill 64 144 275 68 150 275 minecraft:blue_concrete
setblock 66 144 316 minecraft:spruce_planks
setblock 67 144 276 minecraft:spruce_planks
setblock 73 144 316 minecraft:spruce_planks
fill 74 144 275 75 161 275 minecraft:blue_concrete
setblock 74 144 276 minecraft:spruce_planks
setblock 76 144 275 minecraft:white_wool
fill 77 144 275 77 190 275 minecraft:blue_concrete
fill 77 144 317 77 180 317 minecraft:blue_concrete
setblock 78 144 317 minecraft:light_blue_wool
setblock 80 144 316 minecraft:spruce_planks
setblock 81 144 276 minecraft:spruce_planks
fill 83 144 312 85 155 312 minecraft:spruce_log
setblock 87 144 316 minecraft:spruce_planks
setblock 88 144 276 minecraft:spruce_planks
setblock 88 144 283 minecraft:spruce_planks
setblock 88 144 290 minecraft:spruce_planks
setblock 88 144 297 minecraft:spruce_planks
setblock 88 144 304 minecraft:spruce_planks
setblock 88 144 311 minecraft:spruce_planks
fill 47 145 291 47 190 291 minecraft:blue_concrete
setblock 48 145 279 minecraft:spruce_planks
setblock 48 145 286 minecraft:spruce_planks
setblock 48 145 293 minecraft:spruce_planks
setblock 48 145 300 minecraft:spruce_planks
setblock 48 145 307 minecraft:spruce_planks
setblock 48 145 314 minecraft:spruce_planks
fill 48 145 317 48 190 317 minecraft:blue_concrete
setblock 52 145 276 minecraft:spruce_planks
setblock 53 145 316 minecraft:spruce_planks
setblock 59 145 276 minecraft:spruce_planks
setblock 60 145 316 minecraft:spruce_planks
fill 62 145 275 63 164 275 minecraft:blue_concrete
setblock 66 145 276 minecraft:spruce_planks
setblock 67 145 316 minecraft:spruce_planks
setblock 73 145 276 minecraft:spruce_planks
setblock 74 145 316 minecraft:spruce_planks
setblock 76 145 275 minecraft:blue_concrete
fill 78 145 317 78 190 317 minecraft:blue_concrete
setblock 80 145 276 minecraft:spruce_planks
setblock 81 145 316 minecraft:spruce_planks
fill 83 145 275 83 187 275 minecraft:blue_concrete
setblock 84 145 275 minecraft:white_wool
fill 85 145 275 85 161 275 minecraft:blue_concrete
setblock 87 145 276 minecraft:spruce_planks
setblock 88 145 282 minecraft:spruce_planks
setblock 88 145 289 minecraft:spruce_planks
setblock 88 145 296 minecraft:spruce_planks
setblock 88 145 303 minecraft:spruce_planks
setblock 88 145 310 minecraft:spruce_planks
setblock 88 145 316 minecraft:spruce_planks
fill 89 145 279 89 190 280 minecraft:blue_concrete
setblock 89 145 281 minecraft:light_blue_wool
setblock 89 145 299 minecraft:white_wool
fill 89 145 300 89 186 300 minecraft:blue_concrete
setblock 89 145 301 minecraft:light_blue_wool
fill 89 145 302 89 181 302 minecraft:blue_concrete
setblock 89 145 303 minecraft:light_blue_wool
fill 89 145 304 89 157 307 minecraft:blue_concrete
fill 47 146 275 47 154 278 minecraft:blue_concrete
setblock 47 146 279 minecraft:light_blue_wool
fill 47 146 280 47 152 282 minecraft:blue_concrete
setblock 48 146 280 minecraft:spruce_planks
setblock 48 146 287 minecraft:spruce_planks
setblock 48 146 294 minecraft:spruce_planks
setblock 48 146 301 minecraft:spruce_planks
setblock 48 146 308 minecraft:spruce_planks
setblock 48 146 315 minecraft:spruce_planks
setblock 50 146 278 minecraft:light[level=15]
setblock 50 146 285 minecraft:light[level=12]
setblock 50 146 286 minecraft:light[level=15]
setblock 50 146 292 minecraft:light[level=12]
setblock 50 146 294 minecraft:light[level=15]
setblock 50 146 299 minecraft:light[level=12]
setblock 50 146 302 minecraft:light[level=15]
setblock 50 146 306 minecraft:light[level=12]
setblock 50 146 310 minecraft:light[level=15]
setblock 50 146 313 minecraft:light[level=12]
setblock 51 146 276 minecraft:spruce_planks
setblock 54 146 316 minecraft:spruce_planks
setblock 57 146 278 minecraft:light[level=12]
setblock 57 146 285 minecraft:light[level=12]
setblock 57 146 292 minecraft:light[level=12]
setblock 57 146 299 minecraft:light[level=12]
setblock 57 146 306 minecraft:light[level=12]
setblock 57 146 313 minecraft:light[level=12]
fill 57 146 317 58 146 317 minecraft:blue_concrete
setblock 58 146 276 minecraft:spruce_planks
setblock 58 146 278 minecraft:light[level=15]
setblock 58 146 286 minecraft:light[level=15]
setblock 58 146 294 minecraft:light[level=15]
setblock 58 146 302 minecraft:light[level=15]
setblock 58 146 310 minecraft:light[level=15]
setblock 59 146 317 minecraft:white_wool
fill 60 146 317 60 188 317 minecraft:blue_concrete
setblock 61 146 316 minecraft:spruce_planks
setblock 64 146 278 minecraft:light[level=12]
setblock 64 146 285 minecraft:light[level=12]
setblock 64 146 292 minecraft:light[level=12]
setblock 64 146 299 minecraft:light[level=12]
setblock 64 146 306 minecraft:light[level=12]
setblock 64 146 313 minecraft:light[level=12]
setblock 65 146 276 minecraft:spruce_planks
setblock 66 146 278 minecraft:light[level=15]
setblock 66 146 286 minecraft:light[level=15]
setblock 66 146 294 minecraft:light[level=15]
setblock 66 146 302 minecraft:light[level=15]
setblock 66 146 310 minecraft:light[level=15]
setblock 68 146 316 minecraft:spruce_planks
setblock 71 146 278 minecraft:light[level=12]
setblock 71 146 285 minecraft:light[level=12]
setblock 71 146 292 minecraft:light[level=12]
setblock 71 146 299 minecraft:light[level=12]
setblock 71 146 306 minecraft:light[level=12]
setblock 71 146 313 minecraft:light[level=12]
setblock 72 146 276 minecraft:spruce_planks
setblock 74 146 278 minecraft:light[level=15]
setblock 74 146 286 minecraft:light[level=15]
setblock 74 146 294 minecraft:light[level=15]
setblock 74 146 302 minecraft:light[level=15]
setblock 74 146 310 minecraft:light[level=15]
setblock 75 146 316 minecraft:spruce_planks
setblock 76 146 275 minecraft:light_blue_wool
setblock 78 146 278 minecraft:light[level=12]
setblock 78 146 285 minecraft:light[level=12]
setblock 78 146 292 minecraft:light[level=12]
setblock 78 146 299 minecraft:light[level=12]
setblock 78 146 306 minecraft:light[level=12]
setblock 78 146 313 minecraft:light[level=12]
setblock 79 146 276 minecraft:spruce_planks
setblock 82 146 278 minecraft:light[level=15]
setblock 82 146 286 minecraft:light[level=15]
setblock 82 146 294 minecraft:light[level=15]
setblock 82 146 302 minecraft:light[level=15]
setblock 82 146 310 minecraft:light[level=15]
setblock 82 146 316 minecraft:spruce_planks
fill 84 146 275 84 186 275 minecraft:blue_concrete
setblock 85 146 278 minecraft:light[level=12]
setblock 85 146 285 minecraft:light[level=12]
setblock 85 146 292 minecraft:light[level=12]
setblock 85 146 299 minecraft:light[level=12]
setblock 85 146 306 minecraft:light[level=12]
setblock 85 146 313 minecraft:light[level=12]
setblock 86 146 276 minecraft:spruce_planks
fill 86 146 317 87 173 317 minecraft:blue_concrete
setblock 88 146 281 minecraft:spruce_planks
setblock 88 146 288 minecraft:spruce_planks
setblock 88 146 295 minecraft:spruce_planks
setblock 88 146 302 minecraft:spruce_planks
setblock 88 146 309 minecraft:spruce_planks
setblock 88 146 317 minecraft:light_blue_wool
fill 89 146 281 89 182 281 minecraft:blue_concrete
fill 89 146 299 89 190 299 minecraft:blue_concrete
fill 89 146 301 89 155 301 minecraft:blue_concrete
fill 89 146 303 89 190 303 minecraft:blue_concrete
fill 47 147 279 47 190 279 minecraft:blue_concrete
fill 51 147 317 53 157 317 minecraft:blue_concrete
setblock 54 147 317 minecraft:light_blue_wool
fill 55 147 317 55 190 317 minecraft:blue_concrete
setblock 57 147 317 minecraft:white_wool
fill 58 147 317 59 186 317 minecraft:blue_concrete
fill 76 147 275 76 190 275 minecraft:blue_concrete
fill 88 147 317 88 186 317 minecraft:blue_concrete
fill 47 148 310 47 166 312 minecraft:blue_concrete
setblock 47 148 313 minecraft:white_wool
fill 47 148 314 47 178 316 minecraft:blue_concrete
setblock 48 148 282 minecraft:spruce_planks
setblock 48 148 289 minecraft:spruce_planks
setblock 48 148 296 minecraft:spruce_planks
setblock 48 148 303 minecraft:spruce_planks
setblock 48 148 310 minecraft:spruce_planks
setblock 49 148 276 minecraft:spruce_planks
setblock 49 148 316 minecraft:spruce_planks
fill 54 148 317 54 186 317 minecraft:blue_concrete
setblock 56 148 276 minecraft:spruce_planks
setblock 56 148 316 minecraft:spruce_planks
fill 57 148 317 57 190 317 minecraft:blue_concrete
setblock 63 148 276 minecraft:spruce_planks
setblock 63 148 316 minecraft:spruce_planks
setblock 70 148 276 minecraft:spruce_planks
setblock 70 148 316 minecraft:spruce_planks
setblock 77 148 276 minecraft:spruce_planks
setblock 77 148 316 minecraft:spruce_planks
setblock 84 148 276 minecraft:spruce_planks
setblock 84 148 316 minecraft:spruce_planks
setblock 88 148 279 minecraft:spruce_planks
setblock 88 148 286 minecraft:spruce_planks
setblock 88 148 293 minecraft:spruce_planks
setblock 88 148 300 minecraft:spruce_planks
setblock 88 148 307 minecraft:spruce_planks
setblock 88 148 314 minecraft:spruce_planks
fill 47 149 313 47 152 313 minecraft:blue_concrete
fill 48 149 276 48 150 276 minecraft:spruce_planks
fill 48 149 283 48 150 283 minecraft:spruce_planks
fill 48 149 290 48 150 290 minecraft:spruce_planks
fill 48 149 297 48 150 297 minecraft:spruce_planks
fill 48 149 304 48 150 304 minecraft:spruce_planks
fill 48 149 311 48 150 311 minecraft:spruce_planks
fill 50 149 316 50 150 316 minecraft:spruce_planks
fill 55 149 276 55 150 276 minecraft:spruce_planks
fill 57 149 316 57 150 316 minecraft:spruce_planks
fill 59 149 275 59 165 275 minecraft:blue_concrete
setblock 60 149 275 minecraft:light_blue_wool
fill 61 149 275 61 157 275 minecraft:blue_concrete
fill 62 149 276 62 150 276 minecraft:spruce_planks
fill 64 149 316 64 150 316 minecraft:spruce_planks
fill 69 149 276 69 150 276 minecraft:spruce_planks
fill 71 149 316 71 150 316 minecraft:spruce_planks
fill 76 149 276 76 150 276 minecraft:spruce_planks
fill 78 149 316 78 150 316 minecraft:spruce_planks
fill 82 149 279 82 150 282 minecraft:dark_oak_planks
fill 83 149 276 83 150 276 minecraft:spruce_planks
fill 85 149 277 85 150 278 minecraft:iron_bars
fill 85 149 279 85 150 279 minecraft:dark_oak_planks
fill 85 149 282 85 150 282 minecraft:dark_oak_planks
fill 85 149 316 85 150 316 minecraft:spruce_planks
fill 86 149 280 86 150 281 minecraft:dark_oak_planks
setblock 88 149 275 minecraft:white_wool
fill 88 149 278 88 150 278 minecraft:spruce_planks
fill 88 149 285 88 150 285 minecraft:spruce_planks
fill 88 149 292 88 150 292 minecraft:spruce_planks
fill 88 149 299 88 150 299 minecraft:spruce_planks
fill 88 149 306 88 150 306 minecraft:spruce_planks
fill 88 149 313 88 150 313 minecraft:spruce_planks
fill 89 149 308 89 188 308 minecraft:blue_concrete
setblock 89 149 309 minecraft:white_wool
fill 48 150 277 48 150 280 minecraft:spruce_planks
setblock 48 150 282 minecraft:spruce_planks
fill 48 150 284 48 150 287 minecraft:spruce_planks
setblock 48 150 289 minecraft:spruce_planks
fill 48 150 291 48 150 294 minecraft:spruce_planks
setblock 48 150 296 minecraft:spruce_planks
fill 48 150 298 48 150 301 minecraft:spruce_planks
setblock 48 150 303 minecraft:spruce_planks
fill 48 150 305 48 150 308 minecraft:spruce_planks
setblock 48 150 310 minecraft:spruce_planks
fill 48 150 312 48 150 315 minecraft:spruce_planks
setblock 49 150 276 minecraft:spruce_planks
setblock 49 150 316 minecraft:spruce_planks
fill 51 150 276 54 150 276 minecraft:spruce_planks
fill 51 150 316 54 150 316 minecraft:spruce_planks
fill 52 150 275 53 188 275 minecraft:blue_concrete
setblock 54 150 275 minecraft:light_blue_wool
fill 55 150 275 56 176 275 minecraft:blue_concrete
setblock 56 150 276 minecraft:spruce_planks
setblock 56 150 316 minecraft:spruce_planks
fill 58 150 276 61 150 276 minecraft:spruce_planks
fill 58 150 316 61 150 316 minecraft:spruce_planks
fill 60 150 275 60 164 275 minecraft:blue_concrete
setblock 63 150 276 minecraft:spruce_planks
setblock 63 150 316 minecraft:spruce_planks
fill 65 150 276 68 150 276 minecraft:spruce_planks
fill 65 150 316 68 150 316 minecraft:spruce_planks
fill 66 150 317 67 166 317 minecraft:blue_concrete
setblock 68 150 317 minecraft:white_wool
fill 69 150 317 70 190 317 minecraft:blue_concrete
setblock 70 150 276 minecraft:spruce_planks
setblock 70 150 316 minecraft:spruce_planks
fill 72 150 276 75 150 276 minecraft:spruce_planks
fill 72 150 316 75 150 316 minecraft:spruce_planks
setblock 77 150 276 minecraft:spruce_planks
setblock 77 150 316 minecraft:spruce_planks
fill 79 150 276 82 150 276 minecraft:spruce_planks
fill 79 150 316 82 150 316 minecraft:spruce_planks
fill 80 150 317 82 170 317 minecraft:blue_concrete
setblock 83 150 317 minecraft:white_wool
setblock 84 150 276 minecraft:spruce_planks
setblock 84 150 316 minecraft:spruce_planks
fill 86 150 276 88 150 276 minecraft:spruce_planks
fill 86 150 316 88 150 316 minecraft:spruce_planks
fill 88 150 275 88 191 275 minecraft:blue_concrete
setblock 88 150 277 minecraft:spruce_planks
setblock 88 150 279 minecraft:spruce_planks
fill 88 150 281 88 150 284 minecraft:spruce_planks
setblock 88 150 286 minecraft:spruce_planks
fill 88 150 288 88 150 291 minecraft:spruce_planks
setblock 88 150 293 minecraft:spruce_planks
fill 88 150 295 88 150 298 minecraft:spruce_planks
setblock 88 150 300 minecraft:spruce_planks
fill 88 150 302 88 150 305 minecraft:spruce_planks
setblock 88 150 307 minecraft:spruce_planks
fill 88 150 309 88 150 312 minecraft:spruce_planks
setblock 88 150 314 minecraft:spruce_planks
setblock 89 150 282 minecraft:white_wool
fill 89 150 309 89 156 309 minecraft:blue_concrete
fill 54 151 275 54 175 275 minecraft:blue_concrete
fill 64 151 275 67 158 275 minecraft:blue_concrete
setblock 68 151 275 minecraft:light_blue_wool
fill 68 151 317 68 165 317 minecraft:blue_concrete
fill 83 151 317 83 186 317 minecraft:blue_concrete
fill 89 151 282 89 164 282 minecraft:blue_concrete
fill 89 151 290 89 166 294 minecraft:blue_concrete
setblock 89 151 295 minecraft:white_wool
fill 89 151 296 89 190 296 minecraft:blue_concrete
setblock 89 151 314 minecraft:white_wool
fill 47 152 298 47 164 299 minecraft:blue_concrete
setblock 47 152 300 minecraft:light_blue_wool
fill 47 152 301 47 172 301 minecraft:blue_concrete
setblock 47 152 304 minecraft:white_wool
setblock 50 152 278 minecraft:light[level=12]
setblock 50 152 285 minecraft:light[level=12]
setblock 50 152 292 minecraft:light[level=12]
setblock 50 152 299 minecraft:light[level=12]
setblock 50 152 306 minecraft:light[level=12]
setblock 50 152 313 minecraft:light[level=12]
setblock 57 152 278 minecraft:light[level=12]
setblock 57 152 285 minecraft:light[level=12]
setblock 57 152 292 minecraft:light[level=12]
setblock 57 152 299 minecraft:light[level=12]
setblock 57 152 306 minecraft:light[level=12]
setblock 57 152 313 minecraft:light[level=12]
setblock 64 152 278 minecraft:light[level=12]
setblock 64 152 285 minecraft:light[level=12]
setblock 64 152 292 minecraft:light[level=12]
setblock 64 152 299 minecraft:light[level=12]
setblock 64 152 306 minecraft:light[level=12]
setblock 64 152 313 minecraft:light[level=12]
fill 68 152 275 68 186 275 minecraft:blue_concrete
setblock 71 152 278 minecraft:light[level=12]
setblock 71 152 285 minecraft:light[level=12]
setblock 71 152 292 minecraft:light[level=12]
setblock 71 152 299 minecraft:light[level=12]
setblock 71 152 306 minecraft:light[level=12]
setblock 71 152 313 minecraft:light[level=12]
setblock 78 152 278 minecraft:light[level=12]
setblock 78 152 285 minecraft:light[level=12]
setblock 78 152 292 minecraft:light[level=12]
setblock 78 152 299 minecraft:light[level=12]
setblock 78 152 306 minecraft:light[level=12]
setblock 78 152 313 minecraft:light[level=12]
setblock 85 152 278 minecraft:light[level=12]
setblock 85 152 285 minecraft:light[level=12]
setblock 85 152 292 minecraft:light[level=12]
setblock 85 152 299 minecraft:light[level=12]
setblock 85 152 306 minecraft:light[level=12]
setblock 85 152 313 minecraft:light[level=12]
fill 89 152 295 89 186 295 minecraft:blue_concrete
fill 89 152 314 89 169 314 minecraft:blue_concrete
fill 47 153 280 47 190 281 minecraft:blue_concrete
setblock 47 153 282 minecraft:light_blue_wool
fill 47 153 300 47 186 300 minecraft:blue_concrete
fill 47 153 304 47 170 304 minecraft:blue_concrete
setblock 47 153 313 minecraft:white_wool
fill 70 153 275 70 188 275 minecraft:blue_concrete
setblock 71 153 275 minecraft:light_blue_wool
fill 72 153 275 72 190 275 minecraft:blue_concrete
fill 47 154 282 47 167 282 minecraft:blue_concrete
fill 47 154 313 47 157 313 minecraft:blue_concrete
setblock 50 154 278 minecraft:light[level=15]
setblock 50 154 286 minecraft:light[level=15]
setblock 50 154 294 minecraft:light[level=15]
setblock 50 154 302 minecraft:light[level=15]
setblock 50 154 310 minecraft:light[level=15]
setblock 58 154 278 minecraft:light[level=15]
setblock 58 154 286 minecraft:light[level=15]
setblock 58 154 294 minecraft:light[level=15]
setblock 58 154 302 minecraft:light[level=15]
setblock 58 154 310 minecraft:light[level=15]
setblock 66 154 278 minecraft:light[level=15]
setblock 66 154 286 minecraft:light[level=15]
setblock 66 154 294 minecraft:light[level=15]
setblock 66 154 302 minecraft:light[level=15]
setblock 66 154 310 minecraft:light[level=15]
fill 71 154 275 71 169 275 minecraft:blue_concrete
setblock 74 154 278 minecraft:light[level=15]
setblock 74 154 286 minecraft:light[level=15]
setblock 74 154 294 minecraft:light[level=15]
setblock 74 154 302 minecraft:light[level=15]
setblock 74 154 310 minecraft:light[level=15]
setblock 82 154 278 minecraft:light[level=15]
setblock 82 154 286 minecraft:light[level=15]
setblock 82 154 294 minecraft:light[level=15]
setblock 82 154 302 minecraft:light[level=15]
setblock 82 154 310 minecraft:light[level=15]
fill 47 155 275 47 186 277 minecraft:blue_concrete
setblock 47 155 278 minecraft:white_wool
fill 47 155 287 47 188 289 minecraft:blue_concrete
setblock 47 155 290 minecraft:white_wool
fill 47 156 278 47 190 278 minecraft:blue_concrete
fill 47 156 290 47 187 290 minecraft:blue_concrete
setblock 47 156 292 minecraft:white_wool
fill 48 156 276 50 157 316 minecraft:spruce_planks
fill 51 156 276 51 157 316 minecraft:dark_oak_planks
fill 52 156 276 54 157 316 minecraft:spruce_planks
fill 55 156 276 55 157 316 minecraft:dark_oak_planks
fill 56 156 276 58 157 316 minecraft:spruce_planks
fill 59 156 276 59 157 316 minecraft:dark_oak_planks
fill 60 156 276 61 156 316 minecraft:spruce_planks
setblock 61 156 317 minecraft:light_blue_wool
fill 62 156 276 62 156 293 minecraft:spruce_planks
fill 62 156 295 62 156 316 minecraft:spruce_planks
fill 63 156 276 63 156 291 minecraft:dark_oak_planks
fill 63 156 297 63 156 316 minecraft:dark_oak_planks
fill 64 156 276 64 156 291 minecraft:spruce_planks
fill 64 156 297 64 156 316 minecraft:spruce_planks
fill 65 156 276 66 156 290 minecraft:spruce_planks
fill 65 156 298 66 156 316 minecraft:spruce_planks
setblock 66 156 291 minecraft:spruce_planks
setblock 66 156 297 minecraft:spruce_planks
fill 67 156 276 67 156 291 minecraft:dark_oak_planks
fill 67 156 297 67 156 316 minecraft:dark_oak_planks
fill 68 156 276 70 156 293 minecraft:spruce_planks
fill 68 156 295 70 156 316 minecraft:spruce_planks
fill 69 156 294 70 156 294 minecraft:spruce_planks
fill 71 156 276 71 157 316 minecraft:dark_oak_planks
fill 72 156 276 74 157 316 minecraft:spruce_planks
fill 75 156 276 75 157 316 minecraft:dark_oak_planks
fill 76 156 276 78 157 316 minecraft:spruce_planks
fill 79 156 276 79 157 316 minecraft:dark_oak_planks
fill 80 156 276 82 157 316 minecraft:spruce_planks
fill 83 156 276 83 157 316 minecraft:dark_oak_planks
fill 84 156 276 86 157 316 minecraft:spruce_planks
fill 87 156 276 87 157 316 minecraft:dark_oak_planks
fill 88 156 276 88 157 316 minecraft:spruce_planks
setblock 89 156 301 minecraft:white_wool
fill 47 157 292 47 190 292 minecraft:blue_concrete
fill 60 157 276 60 157 316 minecraft:spruce_planks
fill 61 157 276 61 157 292 minecraft:spruce_planks
fill 61 157 293 61 157 295 minecraft:gold_block
fill 61 157 296 61 157 316 minecraft:spruce_planks
fill 61 157 317 61 177 317 minecraft:blue_concrete
fill 62 157 276 62 157 290 minecraft:spruce_planks
fill 62 157 291 62 157 293 minecraft:gold_block
fill 62 157 295 62 157 297 minecraft:gold_block
fill 62 157 298 62 157 316 minecraft:spruce_planks
fill 63 157 276 63 157 290 minecraft:dark_oak_planks
fill 63 157 291 64 157 291 minecraft:gold_block
fill 63 157 297 64 157 297 minecraft:gold_block
fill 63 157 298 63 157 316 minecraft:dark_oak_planks
fill 64 157 276 66 157 289 minecraft:spruce_planks
fill 64 157 290 66 157 290 minecraft:gold_block
fill 64 157 298 66 157 298 minecraft:gold_block
fill 64 157 299 66 157 316 minecraft:spruce_planks
fill 66 157 291 68 157 291 minecraft:gold_block
fill 66 157 297 68 157 297 minecraft:gold_block
fill 67 157 276 67 157 290 minecraft:dark_oak_planks
fill 67 157 298 67 157 316 minecraft:dark_oak_planks
fill 68 157 276 70 157 290 minecraft:spruce_planks
fill 68 157 292 68 157 293 minecraft:gold_block
fill 68 157 295 68 157 296 minecraft:gold_block
fill 68 157 298 70 157 316 minecraft:spruce_planks
fill 69 157 291 70 157 292 minecraft:spruce_planks
fill 69 157 293 69 157 295 minecraft:gold_block
fill 69 157 296 70 157 297 minecraft:spruce_planks
fill 70 157 293 70 157 295 minecraft:spruce_planks
setblock 89 157 297 minecraft:light_blue_wool
fill 89 157 301 89 181 301 minecraft:blue_concrete
setblock 89 157 309 minecraft:white_wool
setblock 47 158 313 minecraft:white_wool
setblock 50 158 278 minecraft:light[level=12]
setblock 50 158 285 minecraft:light[level=12]
setblock 50 158 292 minecraft:light[level=12]
setblock 50 158 299 minecraft:light[level=12]
setblock 50 158 306 minecraft:light[level=12]
setblock 50 158 313 minecraft:light[level=12]
fill 51 158 280 51 159 280 minecraft:spruce_log
fill 51 158 317 51 190 317 minecraft:blue_concrete
fill 52 158 277 53 158 281 minecraft:black_concrete
fill 52 158 310 53 158 314 minecraft:black_concrete
setblock 52 158 317 minecraft:light_blue_wool
fill 53 158 317 53 190 317 minecraft:blue_concrete
setblock 57 158 278 minecraft:light[level=12]
setblock 57 158 285 minecraft:light[level=12]
setblock 57 158 292 minecraft:light[level=12]
setblock 57 158 299 minecraft:light[level=12]
setblock 57 158 306 minecraft:light[level=12]
setblock 57 158 313 minecraft:light[level=12]
fill 58 158 277 59 158 281 minecraft:black_concrete
fill 58 158 310 59 158 314 minecraft:black_concrete
setblock 61 158 275 minecraft:light_blue_wool
fill 64 158 277 65 158 281 minecraft:black_concrete
setblock 64 158 285 minecraft:light[level=12]
setblock 64 158 299 minecraft:light[level=12]
setblock 64 158 306 minecraft:light[level=12]
fill 64 158 310 65 158 314 minecraft:black_concrete
fill 70 158 277 71 158 281 minecraft:black_concrete
fill 70 158 310 71 158 314 minecraft:black_concrete
setblock 71 158 285 minecraft:light[level=12]
setblock 71 158 292 minecraft:light[level=12]
setblock 71 158 299 minecraft:light[level=12]
setblock 71 158 306 minecraft:light[level=12]
fill 76 158 277 77 158 281 minecraft:black_concrete
fill 76 158 310 77 158 314 minecraft:black_concrete
setblock 78 158 278 minecraft:light[level=12]
setblock 78 158 285 minecraft:light[level=12]
setblock 78 158 292 minecraft:light[level=12]
setblock 78 158 299 minecraft:light[level=12]
setblock 78 158 306 minecraft:light[level=12]
setblock 78 158 313 minecraft:light[level=12]
fill 82 158 277 83 158 281 minecraft:black_concrete
fill 82 158 310 83 158 314 minecraft:black_concrete
fill 84 158 311 84 159 313 minecraft:spruce_log
setblock 85 158 278 minecraft:light[level=12]
setblock 85 158 285 minecraft:light[level=12]
setblock 85 158 292 minecraft:light[level=12]
setblock 85 158 299 minecraft:light[level=12]
setblock 85 158 306 minecraft:light[level=12]
fill 85 158 312 85 159 312 minecraft:spruce_log
setblock 85 158 313 minecraft:light[level=12]
fill 86 158 306 86 158 307 minecraft:white_concrete
fill 89 158 297 89 182 297 minecraft:blue_concrete
fill 89 158 304 89 163 306 minecraft:blue_concrete
setblock 89 158 307 minecraft:white_wool
fill 89 158 309 89 190 309 minecraft:blue_concrete
fill 47 159 313 47 187 313 minecraft:blue_concrete
fill 52 159 279 52 159 281 minecraft:spruce_log
fill 52 159 317 52 178 317 minecraft:blue_concrete
setblock 53 159 280 minecraft:spruce_log
fill 61 159 275 61 164 275 minecraft:blue_concrete
setblock 64 159 275 minecraft:white_wool
fill 65 159 275 65 190 275 minecraft:blue_concrete
setblock 66 159 275 minecraft:light_blue_wool
fill 67 159 275 67 190 275 minecraft:blue_concrete
setblock 83 159 312 minecraft:spruce_log
fill 89 159 307 89 190 307 minecraft:blue_concrete
fill 47 160 306 47 190 306 minecraft:blue_concrete
setblock 47 160 307 minecraft:white_wool
fill 48 160 280 56 166 280 minecraft:white_wool
fill 52 160 279 52 277 279 minecraft:spruce_log
fill 52 160 281 52 277 281 minecraft:spruce_log
fill 64 160 275 64 173 275 minecraft:blue_concrete
fill 66 160 275 66 190 275 minecraft:blue_concrete
fill 80 160 312 88 162 312 minecraft:white_wool
fill 84 160 311 84 277 311 minecraft:spruce_log
fill 84 160 313 84 277 313 minecraft:spruce_log
setblock 47 161 307 minecraft:blue_concrete
fill 48 161 281 48 219 281 minecraft:spruce_planks
fill 48 161 288 48 219 288 minecraft:spruce_planks
fill 48 161 295 48 219 295 minecraft:spruce_planks
fill 48 161 302 48 219 302 minecraft:spruce_planks
fill 48 161 309 48 219 309 minecraft:spruce_planks
fill 48 161 316 48 219 316 minecraft:spruce_planks
fill 50 161 276 50 219 276 minecraft:spruce_planks
fill 55 161 316 55 219 316 minecraft:spruce_planks
fill 57 161 276 59 161 277 minecraft:spruce_planks
fill 57 161 314 59 161 316 minecraft:spruce_planks
fill 58 161 278 58 164 278 minecraft:spruce_planks
fill 58 161 313 58 164 313 minecraft:spruce_planks
fill 61 161 279 61 162 279 minecraft:iron_bars
fill 62 161 316 62 219 316 minecraft:spruce_planks
fill 64 161 276 64 219 276 minecraft:spruce_planks
fill 69 161 316 69 202 316 minecraft:spruce_planks
fill 71 161 276 71 219 276 minecraft:spruce_planks
fill 76 161 316 76 219 316 minecraft:spruce_planks
fill 78 161 276 78 219 276 minecraft:spruce_planks
fill 81 161 279 81 161 280 minecraft:dark_oak_planks
setblock 82 161 278 minecraft:dark_oak_planks
fill 82 161 279 84 215 280 minecraft:spruce_planks
setblock 82 161 281 minecraft:dark_oak_planks
fill 83 161 277 84 161 277 minecraft:dark_oak_planks
fill 83 161 278 84 219 278 minecraft:spruce_planks
fill 83 161 281 83 219 281 minecraft:spruce_planks
fill 83 161 316 88 162 316 minecraft:spruce_planks
fill 84 161 281 85 161 281 minecraft:dark_oak_planks
fill 84 161 308 88 162 310 minecraft:spruce_planks
fill 84 161 314 88 162 315 minecraft:spruce_planks
fill 85 161 276 85 219 276 minecraft:spruce_planks
setblock 85 161 278 minecraft:dark_oak_planks
fill 85 161 279 85 213 279 minecraft:spruce_planks
setblock 85 161 280 minecraft:dark_oak_planks
fill 85 161 311 88 162 311 minecraft:spruce_planks
fill 85 161 313 88 162 313 minecraft:spruce_planks
fill 88 161 280 88 219 280 minecraft:spruce_planks
fill 88 161 287 88 219 287 minecraft:spruce_planks
fill 88 161 294 88 219 294 minecraft:spruce_planks
fill 88 161 301 88 219 301 minecraft:spruce_planks
setblock 89 161 288 minecraft:white_wool
setblock 47 162 307 minecraft:light_blue_wool
setblock 48 162 282 minecraft:spruce_planks
setblock 48 162 289 minecraft:spruce_planks
setblock 48 162 296 minecraft:spruce_planks
setblock 48 162 303 minecraft:spruce_planks
setblock 48 162 310 minecraft:spruce_planks
setblock 49 162 276 minecraft:spruce_planks
setblock 49 162 316 minecraft:spruce_planks
setblock 50 162 278 minecraft:light[level=15]
setblock 50 162 286 minecraft:light[level=15]
setblock 50 162 294 minecraft:light[level=15]
setblock 50 162 302 minecraft:light[level=15]
setblock 50 162 310 minecraft:light[level=15]
fill 56 162 276 58 162 276 minecraft:spruce_planks
setblock 56 162 316 minecraft:spruce_planks
fill 57 162 277 57 162 278 minecraft:spruce_planks
fill 57 162 313 57 162 314 minecraft:spruce_planks
fill 58 162 277 59 162 277 minecraft:spruce_planks
fill 58 162 279 58 164 279 minecraft:spruce_planks
setblock 58 162 286 minecraft:light[level=15]
setblock 58 162 294 minecraft:light[level=15]
setblock 58 162 302 minecraft:light[level=15]
setblock 58 162 310 minecraft:light[level=15]
fill 58 162 312 58 164 312 minecraft:spruce_planks
fill 58 162 314 58 162 315 minecraft:spruce_planks
setblock 58 162 316 minecraft:dark_oak_planks
fill 59 162 278 59 164 278 minecraft:spruce_planks
fill 59 162 313 59 162 314 minecraft:spruce_planks
setblock 63 162 276 minecraft:spruce_planks
setblock 63 162 316 minecraft:spruce_planks
setblock 66 162 278 minecraft:light[level=15]
setblock 66 162 286 minecraft:light[level=15]
setblock 66 162 294 minecraft:light[level=15]
setblock 66 162 302 minecraft:light[level=15]
setblock 66 162 310 minecraft:light[level=15]
setblock 70 162 276 minecraft:spruce_planks
setblock 70 162 316 minecraft:spruce_planks
setblock 74 162 275 minecraft:white_wool
setblock 74 162 278 minecraft:light[level=15]
setblock 74 162 286 minecraft:light[level=15]
setblock 74 162 294 minecraft:light[level=15]
setblock 74 162 302 minecraft:light[level=15]
setblock 74 162 310 minecraft:light[level=15]
fill 75 162 275 75 190 275 minecraft:blue_concrete
setblock 77 162 276 minecraft:spruce_planks
setblock 77 162 316 minecraft:spruce_planks
setblock 82 162 278 minecraft:light[level=15]
setblock 82 162 286 minecraft:light[level=15]
setblock 82 162 294 minecraft:light[level=15]
setblock 82 162 302 minecraft:light[level=15]
setblock 82 162 310 minecraft:light[level=15]
setblock 84 162 276 minecraft:spruce_planks
setblock 85 162 275 minecraft:light_blue_wool
setblock 88 162 279 minecraft:spruce_planks
setblock 88 162 286 minecraft:spruce_planks
setblock 88 162 293 minecraft:spruce_planks
setblock 88 162 300 minecraft:spruce_planks
setblock 88 162 307 minecraft:spruce_planks
fill 89 162 288 89 167 288 minecraft:blue_concrete
fill 47 163 307 47 167 307 minecraft:blue_concrete
setblock 48 163 276 minecraft:spruce_planks
setblock 48 163 283 minecraft:spruce_planks
setblock 48 163 290 minecraft:spruce_planks
setblock 48 163 297 minecraft:spruce_planks
setblock 48 163 304 minecraft:spruce_planks
setblock 48 163 311 minecraft:spruce_planks
setblock 50 163 316 minecraft:spruce_planks
setblock 55 163 276 minecraft:spruce_planks
fill 57 163 276 57 219 276 minecraft:spruce_planks
fill 57 163 278 57 163 279 minecraft:spruce_planks
fill 57 163 312 57 163 313 minecraft:spruce_planks
setblock 57 163 316 minecraft:spruce_planks
fill 58 163 276 61 163 276 minecraft:dark_oak_planks
setblock 58 163 277 minecraft:spruce_planks
fill 58 163 280 58 164 280 minecraft:spruce_planks
fill 58 163 311 58 165 311 minecraft:spruce_planks
setblock 58 163 314 minecraft:spruce_planks
setblock 58 163 315 minecraft:dark_oak_planks
fill 59 163 277 64 163 277 minecraft:dark_oak_planks
fill 59 163 279 59 164 279 minecraft:spruce_planks
fill 59 163 312 59 163 313 minecraft:spruce_planks
fill 60 163 278 64 163 279 minecraft:dark_oak_planks
fill 62 163 276 62 164 276 minecraft:spruce_planks
setblock 63 163 276 minecraft:dark_oak_planks
setblock 64 163 316 minecraft:spruce_planks
setblock 69 163 276 minecraft:spruce_planks
setblock 71 163 316 minecraft:spruce_planks
fill 74 163 275 74 190 275 minecraft:blue_concrete
setblock 76 163 276 minecraft:spruce_planks
fill 78 163 277 78 164 278 minecraft:iron_bars
setblock 78 163 316 minecraft:spruce_planks
fill 80 163 312 83 166 312 minecraft:white_wool
setblock 83 163 276 minecraft:spruce_planks
fill 83 163 316 83 219 316 minecraft:spruce_planks
setblock 84 163 308 minecraft:shroomlight
fill 84 163 309 84 184 309 minecraft:spruce_planks
setblock 84 163 310 minecraft:shroomlight
setblock 84 163 312 minecraft:shroomlight
setblock 84 163 314 minecraft:shroomlight
fill 84 163 315 84 184 315 minecraft:spruce_planks
setblock 84 163 316 minecraft:shroomlight
fill 85 163 275 85 192 275 minecraft:blue_concrete
fill 85 163 308 85 184 308 minecraft:spruce_planks
setblock 85 163 309 minecraft:shroomlight
fill 85 163 310 85 184 310 minecraft:spruce_planks
setblock 85 163 311 minecraft:shroomlight
fill 85 163 312 85 166 312 minecraft:white_wool
setblock 85 163 313 minecraft:shroomlight
fill 85 163 314 85 184 314 minecraft:spruce_planks
setblock 85 163 315 minecraft:shroomlight
fill 85 163 316 85 184 316 minecraft:spruce_planks
setblock 86 163 308 minecraft:shroomlight
fill 86 163 309 86 184 309 minecraft:spruce_planks
setblock 86 163 310 minecraft:shroomlight
fill 86 163 311 86 184 311 minecraft:spruce_planks
setblock 86 163 312 minecraft:shroomlight
fill 86 163 313 86 184 313 minecraft:spruce_planks
setblock 86 163 314 minecraft:shroomlight
fill 86 163 315 86 184 315 minecraft:spruce_planks
setblock 86 163 316 minecraft:shroomlight
fill 87 163 308 87 184 308 minecraft:spruce_planks
setblock 87 163 309 minecraft:shroomlight
fill 87 163 310 87 184 310 minecraft:spruce_planks
setblock 87 163 311 minecraft:shroomlight
fill 87 163 312 87 166 312 minecraft:white_wool
setblock 87 163 313 minecraft:shroomlight
fill 87 163 314 87 184 314 minecraft:spruce_planks
setblock 87 163 315 minecraft:shroomlight
fill 87 163 316 87 184 316 minecraft:spruce_planks
setblock 88 163 278 minecraft:spruce_planks
setblock 88 163 285 minecraft:spruce_planks
setblock 88 163 292 minecraft:spruce_planks
setblock 88 163 299 minecraft:spruce_planks
setblock 88 163 306 minecraft:spruce_planks
setblock 88 163 308 minecraft:shroomlight
fill 88 163 309 88 184 309 minecraft:spruce_planks
setblock 88 163 310 minecraft:shroomlight
fill 88 163 311 88 184 311 minecraft:spruce_planks
setblock 88 163 312 minecraft:shroomlight
fill 88 163 313 88 184 313 minecraft:spruce_planks
setblock 88 163 314 minecraft:shroomlight
fill 88 163 315 88 219 315 minecraft:spruce_planks
setblock 88 163 316 minecraft:shroomlight
setblock 48 164 277 minecraft:spruce_planks
setblock 48 164 284 minecraft:spruce_planks
setblock 48 164 291 minecraft:spruce_planks
setblock 48 164 298 minecraft:spruce_planks
setblock 48 164 305 minecraft:spruce_planks
setblock 48 164 312 minecraft:spruce_planks
setblock 50 164 278 minecraft:light[level=12]
setblock 50 164 285 minecraft:light[level=12]
setblock 50 164 292 minecraft:light[level=12]
setblock 50 164 299 minecraft:light[level=12]
setblock 50 164 306 minecraft:light[level=12]
setblock 50 164 313 minecraft:light[level=12]
setblock 51 164 316 minecraft:spruce_planks
setblock 54 164 276 minecraft:spruce_planks
setblock 57 164 278 minecraft:light[level=12]
fill 57 164 279 57 164 281 minecraft:spruce_planks
setblock 57 164 285 minecraft:light[level=12]
setblock 57 164 292 minecraft:light[level=12]
setblock 57 164 299 minecraft:light[level=12]
setblock 57 164 306 minecraft:light[level=12]
fill 57 164 310 57 164 312 minecraft:spruce_planks
setblock 57 164 313 minecraft:light[level=12]
fill 58 164 276 61 164 276 minecraft:spruce_planks
setblock 58 164 277 minecraft:dark_oak_planks
fill 58 164 281 58 166 282 minecraft:spruce_planks
fill 58 164 309 58 166 310 minecraft:spruce_planks
setblock 58 164 314 minecraft:dark_oak_planks
setblock 58 164 316 minecraft:spruce_planks
fill 59 164 277 64 164 277 minecraft:spruce_planks
fill 59 164 280 59 164 281 minecraft:spruce_planks
fill 59 164 310 59 164 312 minecraft:spruce_planks
fill 60 164 278 64 164 279 minecraft:spruce_planks
setblock 63 164 276 minecraft:spruce_planks
setblock 64 164 285 minecraft:light[level=12]
setblock 64 164 292 minecraft:light[level=12]
setblock 64 164 299 minecraft:light[level=12]
setblock 64 164 306 minecraft:light[level=12]
setblock 64 164 313 minecraft:light[level=12]
setblock 65 164 316 minecraft:spruce_planks
setblock 68 164 276 minecraft:spruce_planks
setblock 71 164 278 minecraft:light[level=12]
setblock 71 164 285 minecraft:light[level=12]
setblock 71 164 292 minecraft:light[level=12]
setblock 71 164 299 minecraft:light[level=12]
setblock 71 164 306 minecraft:light[level=12]
setblock 71 164 313 minecraft:light[level=12]
setblock 72 164 316 minecraft:spruce_planks
setblock 75 164 276 minecraft:spruce_planks
setblock 78 164 285 minecraft:light[level=12]
setblock 78 164 292 minecraft:light[level=12]
setblock 78 164 299 minecraft:light[level=12]
setblock 78 164 306 minecraft:light[level=12]
setblock 78 164 313 minecraft:light[level=12]
setblock 79 164 316 minecraft:spruce_planks
setblock 82 164 276 minecraft:spruce_planks
fill 84 164 308 84 165 308 minecraft:spruce_planks
fill 84 164 310 84 165 310 minecraft:spruce_planks
fill 84 164 312 84 165 312 minecraft:white_wool
fill 84 164 314 84 165 314 minecraft:spruce_planks
fill 84 164 316 84 165 316 minecraft:spruce_planks
setblock 85 164 278 minecraft:light[level=12]
setblock 85 164 285 minecraft:light[level=12]
setblock 85 164 292 minecraft:light[level=12]
setblock 85 164 299 minecraft:light[level=12]
setblock 85 164 306 minecraft:light[level=12]
fill 85 164 309 85 165 309 minecraft:spruce_planks
fill 85 164 311 85 165 311 minecraft:spruce_planks
fill 85 164 313 85 165 313 minecraft:spruce_planks
fill 85 164 315 85 165 315 minecraft:spruce_planks
fill 86 164 308 86 165 308 minecraft:spruce_planks
fill 86 164 310 86 165 310 minecraft:spruce_planks
fill 86 164 312 86 165 312 minecraft:white_wool
fill 86 164 314 86 165 314 minecraft:spruce_planks
fill 86 164 316 86 165 316 minecraft:spruce_planks
fill 87 164 309 87 165 309 minecraft:spruce_planks
fill 87 164 311 87 165 311 minecraft:spruce_planks
fill 87 164 313 87 165 313 minecraft:spruce_planks
fill 87 164 315 87 165 315 minecraft:spruce_planks
setblock 88 164 277 minecraft:spruce_planks
setblock 88 164 284 minecraft:spruce_planks
setblock 88 164 291 minecraft:spruce_planks
setblock 88 164 298 minecraft:spruce_planks
setblock 88 164 305 minecraft:spruce_planks
fill 88 164 308 88 165 308 minecraft:spruce_planks
fill 88 164 310 88 165 310 minecraft:spruce_planks
fill 88 164 312 88 165 312 minecraft:white_wool
fill 88 164 314 88 165 314 minecraft:spruce_planks
fill 88 164 316 88 165 316 minecraft:spruce_planks
fill 89 164 304 89 190 305 minecraft:blue_concrete
setblock 89 164 306 minecraft:light_blue_wool
setblock 47 165 298 minecraft:white_wool
fill 47 165 299 47 174 299 minecraft:blue_concrete
setblock 48 165 278 minecraft:spruce_planks
setblock 48 165 285 minecraft:spruce_planks
setblock 48 165 292 minecraft:spruce_planks
setblock 48 165 299 minecraft:spruce_planks
setblock 48 165 306 minecraft:spruce_planks
setblock 48 165 313 minecraft:spruce_planks
setblock 52 165 316 minecraft:spruce_planks
setblock 53 165 276 minecraft:spruce_planks
fill 57 165 281 57 165 282 minecraft:spruce_planks
fill 57 165 309 57 165 310 minecraft:spruce_planks
fill 58 165 279 58 165 280 minecraft:dark_oak_planks
fill 58 165 283 58 167 283 minecraft:spruce_planks
fill 58 165 308 58 167 308 minecraft:spruce_planks
setblock 58 165 312 minecraft:dark_oak_planks
fill 59 165 279 59 167 279 minecraft:iron_bars
fill 59 165 281 59 165 282 minecraft:spruce_planks
fill 59 165 309 59 165 310 minecraft:spruce_planks
setblock 59 165 316 minecraft:spruce_planks
fill 60 165 275 62 168 275 minecraft:shroomlight
setblock 60 165 276 minecraft:spruce_planks
fill 60 165 279 64 165 279 minecraft:dark_oak_planks
fill 62 165 280 62 167 280 minecraft:shroomlight
fill 63 165 275 63 190 275 minecraft:blue_concrete
setblock 66 165 316 minecraft:spruce_planks
setblock 67 165 276 minecraft:spruce_planks
setblock 73 165 316 minecraft:spruce_planks
setblock 74 165 276 minecraft:spruce_planks
setblock 80 165 316 minecraft:spruce_planks
setblock 81 165 276 minecraft:spruce_planks
setblock 88 165 276 minecraft:spruce_planks
setblock 88 165 283 minecraft:spruce_planks
setblock 88 165 290 minecraft:spruce_planks
setblock 88 165 297 minecraft:spruce_planks
setblock 88 165 304 minecraft:spruce_planks
setblock 89 165 282 minecraft:light_blue_wool
fill 89 165 306 89 168 306 minecraft:blue_concrete
fill 47 166 298 47 190 298 minecraft:blue_concrete
setblock 47 166 308 minecraft:light_blue_wool
setblock 48 166 279 minecraft:spruce_planks
setblock 48 166 286 minecraft:spruce_planks
setblock 48 166 293 minecraft:spruce_planks
setblock 48 166 300 minecraft:spruce_planks
setblock 48 166 307 minecraft:spruce_planks
setblock 48 166 314 minecraft:spruce_planks
setblock 52 166 276 minecraft:spruce_planks
setblock 53 166 316 minecraft:spruce_planks
fill 57 166 282 57 166 284 minecraft:spruce_planks
fill 57 166 307 57 166 309 minecraft:spruce_planks
setblock 58 166 279 minecraft:spruce_planks
setblock 58 166 280 minecraft:dark_oak_planks
fill 58 166 284 58 167 285 minecraft:spruce_planks
fill 58 166 306 58 168 307 minecraft:spruce_planks
setblock 58 166 311 minecraft:dark_oak_planks
setblock 59 166 275 minecraft:white_wool
setblock 59 166 276 minecraft:spruce_planks
fill 59 166 282 59 166 284 minecraft:spruce_planks
fill 59 166 307 59 166 309 minecraft:spruce_planks
setblock 60 166 316 minecraft:spruce_planks
setblock 61 166 279 minecraft:spruce_planks
setblock 64 166 279 minecraft:spruce_planks
setblock 66 166 276 minecraft:spruce_planks
setblock 67 166 316 minecraft:spruce_planks
setblock 68 166 317 minecraft:white_wool
setblock 73 166 276 minecraft:spruce_planks
setblock 74 166 316 minecraft:spruce_planks
setblock 79 166 275 minecraft:white_wool
fill 80 166 275 80 186 275 minecraft:blue_concrete
setblock 80 166 276 minecraft:spruce_planks
setblock 81 166 316 minecraft:spruce_planks
setblock 84 166 308 minecraft:shroomlight
setblock 84 166 310 minecraft:shroomlight
setblock 84 166 312 minecraft:shroomlight
setblock 84 166 314 minecraft:shroomlight
setblock 84 166 316 minecraft:shroomlight
setblock 85 166 309 minecraft:shroomlight
setblock 85 166 311 minecraft:shroomlight
setblock 85 166 313 minecraft:shroomlight
setblock 85 166 315 minecraft:shroomlight
setblock 86 166 308 minecraft:shroomlight
setblock 86 166 310 minecraft:shroomlight
setblock 86 166 312 minecraft:shroomlight
setblock 86 166 314 minecraft:shroomlight
setblock 86 166 316 minecraft:shroomlight
setblock 87 166 276 minecraft:spruce_planks
setblock 87 166 309 minecraft:shroomlight
setblock 87 166 311 minecraft:shroomlight
setblock 87 166 313 minecraft:shroomlight
setblock 87 166 315 minecraft:shroomlight
setblock 88 166 282 minecraft:spruce_planks
setblock 88 166 289 minecraft:spruce_planks
setblock 88 166 296 minecraft:spruce_planks
setblock 88 166 303 minecraft:spruce_planks
setblock 88 166 308 minecraft:shroomlight
setblock 88 166 310 minecraft:shroomlight
setblock 88 166 312 minecraft:shroomlight
setblock 88 166 314 minecraft:shroomlight
setblock 88 166 316 minecraft:shroomlight
fill 89 166 282 89 187 282 minecraft:blue_concrete
fill 89 166 311 89 187 312 minecraft:blue_concrete
setblock 89 166 313 minecraft:light_blue_wool
fill 47 167 308 47 182 308 minecraft:blue_concrete
setblock 47 167 310 minecraft:light_blue_wool
fill 47 167 311 47 190 312 minecraft:blue_concrete
fill 48 167 280 56 167 280 minecraft:spruce_log
setblock 48 167 287 minecraft:spruce_planks
setblock 48 167 294 minecraft:spruce_planks
setblock 48 167 301 minecraft:spruce_planks
setblock 48 167 308 minecraft:spruce_planks
setblock 48 167 315 minecraft:spruce_planks
setblock 51 167 276 minecraft:spruce_planks
setblock 54 167 316 minecraft:spruce_planks
fill 55 167 313 55 168 315 minecraft:iron_bars
fill 57 167 284 57 167 286 minecraft:spruce_planks
fill 57 167 305 57 167 307 minecraft:spruce_planks
setblock 58 167 276 minecraft:spruce_planks
setblock 58 167 282 minecraft:dark_oak_planks
fill 58 167 286 58 169 287 minecraft:spruce_planks
fill 58 167 304 58 169 305 minecraft:spruce_planks
setblock 58 167 309 minecraft:dark_oak_planks
fill 59 167 275 59 169 275 minecraft:blue_concrete
fill 59 167 284 59 167 286 minecraft:spruce_planks
fill 59 167 305 59 167 307 minecraft:spruce_planks
setblock 61 167 316 minecraft:spruce_planks
setblock 65 167 276 minecraft:spruce_planks
setblock 66 167 317 minecraft:light_blue_wool
fill 67 167 317 68 187 317 minecraft:blue_concrete
setblock 68 167 316 minecraft:spruce_planks
fill 71 167 277 71 168 278 minecraft:iron_bars
setblock 72 167 276 minecraft:spruce_planks
setblock 75 167 316 minecraft:spruce_planks
fill 79 167 275 79 187 275 minecraft:blue_concrete
setblock 79 167 276 minecraft:spruce_planks
fill 80 167 312 88 167 312 minecraft:spruce_log
setblock 82 167 316 minecraft:spruce_planks
fill 84 167 308 84 168 308 minecraft:spruce_planks
fill 84 167 310 84 168 310 minecraft:spruce_planks
fill 84 167 314 84 168 314 minecraft:spruce_planks
fill 84 167 316 84 168 316 minecraft:spruce_planks
fill 85 167 309 85 168 309 minecraft:spruce_planks
fill 85 167 311 85 168 311 minecraft:spruce_planks
fill 85 167 313 85 168 313 minecraft:spruce_planks
fill 85 167 315 85 168 315 minecraft:spruce_planks
setblock 86 167 276 minecraft:spruce_planks
fill 86 167 308 86 168 308 minecraft:spruce_planks
schedule function dropper:buildpart/61_2 1t
