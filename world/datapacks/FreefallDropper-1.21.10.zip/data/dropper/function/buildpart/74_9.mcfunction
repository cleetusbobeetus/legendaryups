setblock 97 258 357 minecraft:light[level=15]
setblock 97 258 360 minecraft:light[level=12]
setblock 98 258 323 minecraft:stone
setblock 98 258 324 minecraft:stripped_spruce_log
fill 98 258 362 99 258 362 minecraft:stone
setblock 99 258 323 minecraft:stripped_spruce_log
fill 99 258 324 102 258 324 minecraft:stone
setblock 99 258 363 minecraft:stripped_spruce_log
fill 100 258 323 103 258 323 minecraft:stone
setblock 100 258 362 minecraft:stripped_spruce_log
fill 100 258 363 103 258 363 minecraft:stone
fill 101 258 362 104 258 362 minecraft:stone
setblock 103 258 324 minecraft:stripped_spruce_log
setblock 104 258 323 minecraft:stripped_spruce_log
setblock 104 258 324 minecraft:stone
setblock 104 258 325 minecraft:light[level=12]
setblock 104 258 332 minecraft:light[level=12]
setblock 104 258 339 minecraft:light[level=12]
setblock 104 258 346 minecraft:light[level=12]
setblock 104 258 353 minecraft:light[level=12]
setblock 104 258 360 minecraft:light[level=12]
setblock 104 258 363 minecraft:stripped_spruce_log
fill 105 258 323 106 258 323 minecraft:stone
setblock 105 258 325 minecraft:light[level=15]
setblock 105 258 341 minecraft:light[level=15]
setblock 105 258 349 minecraft:light[level=15]
setblock 105 258 357 minecraft:light[level=15]
setblock 105 258 362 minecraft:stripped_spruce_log
fill 105 258 363 107 258 363 minecraft:stone
setblock 111 258 325 minecraft:light[level=12]
setblock 111 258 332 minecraft:light[level=12]
setblock 111 258 339 minecraft:light[level=12]
setblock 111 258 346 minecraft:light[level=12]
setblock 111 258 353 minecraft:light[level=12]
setblock 111 258 360 minecraft:light[level=12]
setblock 113 258 325 minecraft:light[level=15]
setblock 113 258 333 minecraft:light[level=15]
setblock 113 258 341 minecraft:light[level=15]
setblock 113 258 349 minecraft:light[level=15]
fill 113 258 355 113 260 357 minecraft:cobbled_deepslate
fill 114 258 354 114 260 354 minecraft:cobbled_deepslate
fill 114 258 359 114 260 359 minecraft:cobbled_deepslate
fill 115 258 353 117 260 353 minecraft:cobbled_deepslate
setblock 118 258 325 minecraft:light[level=12]
setblock 118 258 332 minecraft:light[level=12]
setblock 118 258 339 minecraft:light[level=12]
setblock 118 258 346 minecraft:light[level=12]
setblock 118 258 353 minecraft:light[level=12]
setblock 118 258 360 minecraft:light[level=12]
fill 119 258 354 119 260 354 minecraft:cobbled_deepslate
fill 121 258 323 123 258 323 minecraft:stone
setblock 121 258 325 minecraft:light[level=15]
setblock 121 258 333 minecraft:light[level=15]
setblock 121 258 341 minecraft:light[level=15]
setblock 121 258 349 minecraft:light[level=15]
setblock 121 258 357 minecraft:light[level=15]
fill 122 258 364 122 308 364 minecraft:stone
setblock 125 258 325 minecraft:light[level=12]
setblock 125 258 332 minecraft:light[level=12]
setblock 125 258 339 minecraft:light[level=12]
setblock 125 258 346 minecraft:light[level=12]
setblock 125 258 353 minecraft:light[level=12]
setblock 125 258 360 minecraft:light[level=12]
fill 126 258 323 128 258 324 minecraft:raw_gold_block
setblock 129 258 325 minecraft:light[level=15]
setblock 129 258 333 minecraft:light[level=15]
setblock 129 258 341 minecraft:light[level=15]
setblock 129 258 349 minecraft:light[level=15]
setblock 129 258 357 minecraft:light[level=15]
setblock 132 258 325 minecraft:light[level=12]
setblock 132 258 332 minecraft:light[level=12]
fill 132 258 333 132 261 333 minecraft:iron_bars
setblock 132 258 339 minecraft:light[level=12]
setblock 132 258 346 minecraft:light[level=12]
setblock 132 258 353 minecraft:light[level=12]
setblock 132 258 360 minecraft:light[level=12]
fill 134 258 326 134 263 326 minecraft:raw_gold_block
setblock 134 258 327 minecraft:stone
setblock 134 258 328 minecraft:stripped_spruce_log
fill 134 258 329 134 258 332 minecraft:stone
setblock 134 258 333 minecraft:stripped_spruce_log
fill 134 258 334 135 259 335 minecraft:stone
fill 135 258 324 135 258 326 minecraft:stone
setblock 135 258 327 minecraft:stripped_spruce_log
fill 135 258 328 135 258 331 minecraft:stone
setblock 135 258 332 minecraft:stripped_spruce_log
fill 135 258 333 135 261 333 minecraft:stone
setblock 135 258 336 minecraft:stone
setblock 135 258 337 minecraft:stripped_spruce_log
fill 135 258 338 135 261 338 minecraft:stone
fill 135 258 350 135 258 351 minecraft:stone
setblock 135 258 352 minecraft:stripped_spruce_log
fill 135 258 353 135 259 354 minecraft:stone
setblock 136 258 337 minecraft:raw_iron_block
setblock 136 258 343 minecraft:raw_gold_block
fill 136 258 352 136 308 352 minecraft:stone
setblock 136 258 353 minecraft:raw_iron_block
fill 94 259 343 94 308 343 minecraft:stone
fill 94 259 354 94 308 356 minecraft:stone
setblock 94 259 357 minecraft:raw_gold_block
fill 95 259 323 95 259 325 minecraft:stone
setblock 95 259 326 minecraft:stripped_spruce_log
fill 95 259 327 95 259 330 minecraft:stone
setblock 95 259 331 minecraft:stripped_spruce_log
fill 95 259 332 95 259 335 minecraft:stone
setblock 95 259 336 minecraft:stripped_spruce_log
setblock 95 259 351 minecraft:stripped_spruce_log
fill 95 259 352 95 259 355 minecraft:stone
setblock 95 259 356 minecraft:stripped_spruce_log
fill 95 259 357 96 261 357 minecraft:stone
fill 95 259 359 95 259 360 minecraft:stone
fill 96 259 323 97 259 323 minecraft:stone
setblock 96 259 325 minecraft:stripped_spruce_log
fill 96 259 326 96 259 329 minecraft:stone
setblock 96 259 330 minecraft:stripped_spruce_log
fill 96 259 331 96 262 331 minecraft:stone
fill 96 259 353 96 259 354 minecraft:stone
setblock 96 259 355 minecraft:stripped_spruce_log
fill 96 259 356 96 262 356 minecraft:stone
fill 96 259 363 97 259 363 minecraft:stone
fill 97 259 324 97 261 324 minecraft:stripped_spruce_log
setblock 97 259 329 minecraft:stripped_spruce_log
setblock 97 259 330 minecraft:stone
setblock 98 259 323 minecraft:stripped_spruce_log
fill 98 259 324 101 259 324 minecraft:stone
setblock 98 259 362 minecraft:stone
setblock 98 259 363 minecraft:stripped_spruce_log
fill 99 259 323 102 259 323 minecraft:stone
setblock 99 259 362 minecraft:stripped_spruce_log
fill 99 259 363 102 259 363 minecraft:stone
fill 100 259 362 103 259 362 minecraft:stone
fill 102 259 324 102 261 324 minecraft:stripped_spruce_log
setblock 103 259 323 minecraft:stripped_spruce_log
setblock 103 259 363 minecraft:stripped_spruce_log
fill 104 259 323 105 259 323 minecraft:stone
setblock 104 259 362 minecraft:stripped_spruce_log
fill 104 259 363 106 259 363 minecraft:stone
fill 105 259 364 105 284 364 minecraft:stone
setblock 106 259 364 minecraft:raw_iron_block
fill 113 259 354 113 260 354 minecraft:cobbled_deepslate
fill 113 259 358 113 260 358 minecraft:cobbled_deepslate
fill 114 259 353 114 260 353 minecraft:cobbled_deepslate
fill 115 259 360 118 260 360 minecraft:cobbled_deepslate
fill 118 259 353 118 260 353 minecraft:cobbled_deepslate
fill 119 259 359 119 260 359 minecraft:cobbled_deepslate
fill 120 259 355 120 260 358 minecraft:cobbled_deepslate
setblock 129 259 322 minecraft:raw_iron_block
fill 132 259 325 133 262 327 minecraft:raw_gold_block
fill 134 259 324 134 259 325 minecraft:raw_gold_block
fill 134 259 327 134 262 327 minecraft:raw_gold_block
fill 134 259 328 134 259 331 minecraft:stone
setblock 134 259 332 minecraft:stripped_spruce_log
fill 134 259 333 134 262 333 minecraft:stone
fill 135 259 324 135 259 325 minecraft:stone
setblock 135 259 326 minecraft:stripped_spruce_log
fill 135 259 327 135 259 330 minecraft:stone
setblock 135 259 331 minecraft:stripped_spruce_log
fill 135 259 332 135 262 332 minecraft:stone
setblock 135 259 336 minecraft:stripped_spruce_log
fill 135 259 337 136 262 337 minecraft:stone
setblock 135 259 352 minecraft:stone
fill 136 259 343 136 291 343 minecraft:stone
fill 136 259 353 136 308 353 minecraft:stone
fill 94 260 322 95 297 322 minecraft:stone
fill 94 260 357 94 308 357 minecraft:stone
fill 95 260 323 95 260 324 minecraft:stone
setblock 95 260 325 minecraft:stripped_spruce_log
fill 95 260 326 95 260 329 minecraft:stone
setblock 95 260 330 minecraft:stripped_spruce_log
fill 95 260 331 95 260 334 minecraft:stone
setblock 95 260 335 minecraft:stripped_spruce_log
fill 95 260 336 95 263 336 minecraft:stone
fill 95 260 338 100 261 338 minecraft:stripped_spruce_log
fill 95 260 345 100 261 345 minecraft:stripped_spruce_log
fill 95 260 351 95 260 354 minecraft:stone
setblock 95 260 355 minecraft:stripped_spruce_log
fill 95 260 356 95 263 356 minecraft:stone
setblock 95 260 359 minecraft:stone
setblock 95 260 360 minecraft:stripped_spruce_log
fill 95 260 361 95 262 362 minecraft:stone
setblock 96 260 322 minecraft:diamond_block
setblock 96 260 323 minecraft:stone
fill 96 260 324 96 261 324 minecraft:stripped_spruce_log
fill 96 260 326 96 260 328 minecraft:stone
setblock 96 260 329 minecraft:stripped_spruce_log
fill 96 260 330 96 263 330 minecraft:stone
fill 96 260 332 96 260 333 minecraft:stone
setblock 96 260 334 minecraft:stripped_spruce_log
fill 96 260 352 98 260 352 minecraft:stripped_spruce_log
setblock 96 260 353 minecraft:stone
setblock 96 260 354 minecraft:stripped_spruce_log
fill 96 260 355 96 263 355 minecraft:stone
setblock 96 260 358 minecraft:stone
fill 96 260 359 97 260 359 minecraft:stripped_spruce_log
setblock 96 260 363 minecraft:stone
setblock 97 260 323 minecraft:stripped_spruce_log
fill 97 260 331 102 261 331 minecraft:stripped_spruce_log
setblock 97 260 363 minecraft:stripped_spruce_log
fill 98 260 323 100 260 324 minecraft:stone
setblock 98 260 362 minecraft:stripped_spruce_log
fill 98 260 363 101 260 363 minecraft:stone
fill 99 260 362 102 260 362 minecraft:stone
setblock 101 260 323 minecraft:stone
fill 101 260 324 101 261 324 minecraft:stripped_spruce_log
setblock 102 260 323 minecraft:stripped_spruce_log
setblock 102 260 363 minecraft:stripped_spruce_log
setblock 103 260 323 minecraft:stone
fill 103 260 324 134 261 324 minecraft:stripped_spruce_log
setblock 103 260 362 minecraft:stripped_spruce_log
fill 103 260 363 105 261 363 minecraft:stone
setblock 104 260 362 minecraft:stone
fill 106 260 364 106 308 364 minecraft:stone
fill 112 260 355 112 260 357 minecraft:cobbled_deepslate
setblock 113 260 359 minecraft:cobbled_deepslate
setblock 114 260 360 minecraft:cobbled_deepslate
fill 115 260 352 117 260 352 minecraft:cobbled_deepslate
setblock 115 260 364 minecraft:diamond_block
setblock 119 260 353 minecraft:cobbled_deepslate
setblock 119 260 360 minecraft:cobbled_deepslate
setblock 120 260 354 minecraft:cobbled_deepslate
setblock 120 260 359 minecraft:cobbled_deepslate
fill 129 260 322 129 284 322 minecraft:stone
fill 129 260 326 131 261 326 minecraft:raw_gold_block
fill 130 260 325 131 261 325 minecraft:raw_gold_block
fill 130 260 327 131 261 327 minecraft:raw_gold_block
fill 132 260 328 133 261 328 minecraft:raw_gold_block
fill 134 260 325 134 262 325 minecraft:raw_gold_block
fill 134 260 328 134 260 330 minecraft:stone
setblock 134 260 331 minecraft:stripped_spruce_log
fill 134 260 332 134 263 332 minecraft:stone
fill 134 260 334 134 260 335 minecraft:stone
setblock 134 260 336 minecraft:stripped_spruce_log
setblock 135 260 324 minecraft:stone
setblock 135 260 325 minecraft:stripped_spruce_log
fill 135 260 326 135 260 329 minecraft:stone
setblock 135 260 330 minecraft:stripped_spruce_log
fill 135 260 331 135 263 331 minecraft:stone
setblock 135 260 334 minecraft:stone
setblock 135 260 335 minecraft:stripped_spruce_log
fill 135 260 336 135 263 336 minecraft:stone
setblock 135 260 354 minecraft:stone
setblock 136 260 362 minecraft:gold_block
setblock 95 261 323 minecraft:stone
setblock 95 261 324 minecraft:stripped_spruce_log
fill 95 261 325 95 261 328 minecraft:stone
setblock 95 261 329 minecraft:stripped_spruce_log
fill 95 261 330 95 261 333 minecraft:stone
setblock 95 261 334 minecraft:stripped_spruce_log
fill 95 261 335 95 264 335 minecraft:stone
fill 95 261 337 95 262 337 minecraft:stone
fill 95 261 351 95 261 353 minecraft:stone
setblock 95 261 354 minecraft:stripped_spruce_log
fill 95 261 355 95 264 355 minecraft:stone
setblock 95 261 359 minecraft:stripped_spruce_log
fill 95 261 360 96 263 360 minecraft:stone
setblock 95 261 363 minecraft:stone
fill 96 261 322 96 308 322 minecraft:stone
setblock 96 261 323 minecraft:stripped_spruce_log
setblock 96 261 328 minecraft:stripped_spruce_log
fill 96 261 329 96 262 329 minecraft:stone
setblock 96 261 332 minecraft:stone
setblock 96 261 333 minecraft:stripped_spruce_log
fill 96 261 334 96 264 334 minecraft:stone
fill 96 261 349 96 262 352 minecraft:iron_bars
setblock 96 261 353 minecraft:stripped_spruce_log
fill 96 261 354 96 264 354 minecraft:stone
setblock 96 261 358 minecraft:stripped_spruce_log
fill 96 261 359 96 264 359 minecraft:stone
fill 96 261 361 96 261 362 minecraft:iron_bars
setblock 96 261 363 minecraft:stripped_spruce_log
fill 97 261 323 100 261 323 minecraft:stone
fill 97 261 352 134 261 352 minecraft:stripped_spruce_log
setblock 97 261 356 minecraft:stone
setblock 97 261 357 minecraft:stripped_spruce_log
fill 97 261 359 109 261 359 minecraft:stripped_spruce_log
setblock 97 261 362 minecraft:stripped_spruce_log
fill 97 261 363 100 261 363 minecraft:stone
fill 98 261 324 100 261 324 minecraft:stripped_spruce_log
fill 98 261 362 101 261 362 minecraft:stone
setblock 101 261 323 minecraft:stripped_spruce_log
fill 101 261 338 110 261 338 minecraft:stripped_spruce_log
fill 101 261 345 108 261 345 minecraft:stripped_spruce_log
setblock 101 261 363 minecraft:stripped_spruce_log
setblock 102 261 323 minecraft:stone
setblock 102 261 362 minecraft:stripped_spruce_log
fill 102 261 363 102 264 363 minecraft:stone
fill 103 261 331 133 261 331 minecraft:stripped_spruce_log
fill 103 261 362 103 264 362 minecraft:stone
fill 110 261 356 110 262 362 minecraft:iron_bars
fill 111 261 359 130 261 359 minecraft:stripped_spruce_log
fill 115 261 338 134 261 338 minecraft:stripped_spruce_log
fill 115 261 345 135 261 345 minecraft:stripped_spruce_log
fill 115 261 364 115 292 364 minecraft:stone
fill 116 261 356 117 261 357 minecraft:raw_gold_block
fill 127 261 326 128 262 326 minecraft:raw_gold_block
fill 128 261 325 129 261 325 minecraft:raw_gold_block
fill 128 261 327 129 261 327 minecraft:raw_gold_block
fill 131 261 349 131 262 351 minecraft:iron_bars
fill 131 261 353 131 261 363 minecraft:iron_bars
fill 134 261 328 134 262 328 minecraft:raw_gold_block
setblock 134 261 329 minecraft:stone
setblock 134 261 330 minecraft:stripped_spruce_log
fill 134 261 331 134 264 331 minecraft:stone
setblock 134 261 334 minecraft:stone
setblock 134 261 335 minecraft:stripped_spruce_log
fill 134 261 336 134 264 336 minecraft:stone
setblock 135 261 324 minecraft:raw_gold_block
fill 135 261 325 135 261 328 minecraft:stone
setblock 135 261 329 minecraft:stripped_spruce_log
fill 135 261 330 135 264 330 minecraft:stone
setblock 135 261 334 minecraft:stripped_spruce_log
fill 135 261 335 135 264 335 minecraft:stone
setblock 135 261 339 minecraft:stripped_spruce_log
setblock 135 261 354 minecraft:stripped_spruce_log
fill 135 261 355 135 263 356 minecraft:stone
fill 136 261 362 136 308 362 minecraft:stone
setblock 95 262 323 minecraft:stripped_spruce_log
fill 95 262 324 95 262 327 minecraft:stone
setblock 95 262 328 minecraft:stripped_spruce_log
fill 95 262 329 95 262 332 minecraft:stone
setblock 95 262 333 minecraft:stripped_spruce_log
fill 95 262 334 95 265 334 minecraft:stone
fill 95 262 351 95 262 352 minecraft:stone
setblock 95 262 353 minecraft:stripped_spruce_log
fill 95 262 354 95 265 354 minecraft:stone
setblock 95 262 357 minecraft:stone
setblock 95 262 358 minecraft:stripped_spruce_log
fill 95 262 359 95 265 359 minecraft:stone
setblock 95 262 363 minecraft:stripped_spruce_log
fill 96 262 323 99 262 323 minecraft:stone
fill 96 262 324 96 262 328 minecraft:iron_bars
setblock 96 262 332 minecraft:stripped_spruce_log
fill 96 262 333 96 265 333 minecraft:stone
fill 96 262 335 96 263 335 minecraft:stone
fill 96 262 336 96 262 348 minecraft:iron_bars
fill 96 262 353 96 265 353 minecraft:stone
setblock 96 262 357 minecraft:stripped_spruce_log
fill 96 262 358 97 264 358 minecraft:stone
setblock 96 262 361 minecraft:stone
setblock 96 262 362 minecraft:stripped_spruce_log
fill 96 262 363 99 262 363 minecraft:stone
setblock 97 262 355 minecraft:stone
setblock 97 262 356 minecraft:stripped_spruce_log
fill 97 262 357 97 265 357 minecraft:stone
fill 97 262 359 97 263 359 minecraft:stone
fill 97 262 362 100 262 362 minecraft:stone
fill 99 262 361 101 262 361 minecraft:stone
setblock 100 262 323 minecraft:stripped_spruce_log
setblock 100 262 363 minecraft:stripped_spruce_log
fill 101 262 323 101 265 323 minecraft:stone
setblock 101 262 362 minecraft:stripped_spruce_log
fill 101 262 363 101 265 363 minecraft:stone
fill 102 262 362 102 265 362 minecraft:stone
fill 103 262 323 103 263 326 minecraft:iron_bars
fill 103 262 363 104 262 363 minecraft:stone
setblock 105 262 363 minecraft:stripped_spruce_log
fill 110 262 323 110 262 340 minecraft:iron_bars
fill 110 262 347 110 262 355 minecraft:iron_bars
fill 116 262 356 116 263 357 minecraft:raw_gold_block
fill 117 262 323 117 262 363 minecraft:iron_bars
fill 124 262 323 124 263 326 minecraft:iron_bars
fill 125 262 359 134 262 359 minecraft:stripped_spruce_log
setblock 126 262 326 minecraft:raw_gold_block
fill 129 262 325 130 262 327 minecraft:raw_gold_block
fill 129 262 352 134 262 352 minecraft:stripped_spruce_log
setblock 130 262 322 minecraft:raw_iron_block
fill 131 262 323 131 262 348 minecraft:iron_bars
fill 131 262 353 131 262 354 minecraft:iron_bars
setblock 134 262 324 minecraft:raw_gold_block
setblock 134 262 329 minecraft:stripped_spruce_log
fill 134 262 330 134 265 330 minecraft:stone
setblock 134 262 334 minecraft:stripped_spruce_log
fill 134 262 335 134 265 335 minecraft:stone
fill 134 262 337 134 263 337 minecraft:stone
fill 135 262 324 135 262 327 minecraft:stone
setblock 135 262 328 minecraft:stripped_spruce_log
fill 135 262 329 135 265 329 minecraft:stone
setblock 135 262 333 minecraft:stripped_spruce_log
fill 135 262 334 135 265 334 minecraft:stone
setblock 135 262 338 minecraft:stripped_spruce_log
fill 135 262 339 135 265 339 minecraft:stone
fill 135 262 354 135 265 354 minecraft:stone
setblock 135 262 357 minecraft:stone
setblock 135 262 358 minecraft:stripped_spruce_log
fill 135 262 359 135 265 359 minecraft:stone
fill 94 263 359 94 296 360 minecraft:stone
setblock 94 263 361 minecraft:raw_iron_block
fill 95 263 323 95 263 326 minecraft:stone
setblock 95 263 327 minecraft:stripped_spruce_log
fill 95 263 328 95 263 331 minecraft:stone
setblock 95 263 332 minecraft:stripped_spruce_log
fill 95 263 333 95 266 333 minecraft:stone
setblock 95 263 337 minecraft:stripped_spruce_log
fill 95 263 338 95 266 338 minecraft:stone
setblock 95 263 351 minecraft:stone
setblock 95 263 352 minecraft:stripped_spruce_log
fill 95 263 353 95 266 353 minecraft:stone
setblock 95 263 357 minecraft:stripped_spruce_log
fill 95 263 358 95 266 358 minecraft:stone
setblock 95 263 361 minecraft:stone
setblock 95 263 362 minecraft:stripped_spruce_log
fill 95 263 363 98 263 363 minecraft:stone
fill 96 263 323 98 263 323 minecraft:stone
fill 96 263 324 96 263 325 minecraft:iron_bars
setblock 96 263 331 minecraft:stripped_spruce_log
fill 96 263 332 96 266 332 minecraft:stone
setblock 96 263 336 minecraft:stripped_spruce_log
setblock 96 263 356 minecraft:stripped_spruce_log
fill 96 263 357 96 266 357 minecraft:stone
setblock 96 263 361 minecraft:stripped_spruce_log
fill 96 263 362 99 263 362 minecraft:stone
setblock 97 263 354 minecraft:stone
setblock 97 263 355 minecraft:stripped_spruce_log
fill 97 263 356 97 266 356 minecraft:stone
setblock 97 263 360 minecraft:stripped_spruce_log
fill 97 263 361 100 263 361 minecraft:stone
setblock 99 263 323 minecraft:stripped_spruce_log
setblock 99 263 363 minecraft:stripped_spruce_log
fill 100 263 323 100 266 323 minecraft:stone
setblock 100 263 362 minecraft:stripped_spruce_log
fill 100 263 363 100 266 363 minecraft:stone
setblock 101 263 361 minecraft:stripped_spruce_log
fill 101 263 362 101 266 362 minecraft:stone
fill 103 263 327 103 263 361 minecraft:iron_bars
setblock 103 263 363 minecraft:stone
setblock 104 263 363 minecraft:stripped_spruce_log
fill 105 263 363 105 266 363 minecraft:stone
fill 107 263 322 107 298 322 minecraft:stone
setblock 108 263 322 minecraft:raw_gold_block
fill 110 263 323 110 263 326 minecraft:iron_bars
fill 117 263 323 117 263 330 minecraft:iron_bars
setblock 117 263 356 minecraft:raw_gold_block
fill 124 263 327 124 263 361 minecraft:iron_bars
fill 130 263 322 130 293 322 minecraft:stone
fill 131 263 323 131 263 325 minecraft:iron_bars
fill 134 263 329 134 266 329 minecraft:stone
setblock 134 263 333 minecraft:stripped_spruce_log
fill 134 263 334 134 266 334 minecraft:stone
fill 135 263 323 135 263 326 minecraft:stone
setblock 135 263 327 minecraft:stripped_spruce_log
fill 135 263 328 135 266 328 minecraft:stone
setblock 135 263 332 minecraft:stripped_spruce_log
fill 135 263 333 135 266 333 minecraft:stone
setblock 135 263 337 minecraft:stripped_spruce_log
fill 135 263 338 135 266 338 minecraft:stone
fill 135 263 340 135 264 340 minecraft:stone
setblock 135 263 357 minecraft:stripped_spruce_log
fill 135 263 358 135 266 358 minecraft:stone
fill 135 263 360 135 263 361 minecraft:stone
setblock 135 263 362 minecraft:stripped_spruce_log
fill 136 263 337 136 268 337 minecraft:stone
fill 94 264 361 94 277 361 minecraft:stone
fill 95 264 323 95 264 325 minecraft:stone
setblock 95 264 326 minecraft:stripped_spruce_log
fill 95 264 327 95 264 330 minecraft:stone
setblock 95 264 331 minecraft:stripped_spruce_log
fill 95 264 332 95 267 332 minecraft:stone
setblock 95 264 336 minecraft:stripped_spruce_log
fill 95 264 337 96 266 337 minecraft:stone
fill 95 264 339 95 264 340 minecraft:stone
setblock 95 264 351 minecraft:stripped_spruce_log
fill 95 264 352 96 266 352 minecraft:stone
setblock 95 264 356 minecraft:stripped_spruce_log
fill 95 264 357 95 267 357 minecraft:stone
setblock 95 264 360 minecraft:stone
setblock 95 264 361 minecraft:stripped_spruce_log
fill 95 264 362 97 264 363 minecraft:stone
fill 96 264 323 97 264 323 minecraft:stone
setblock 96 264 330 minecraft:stripped_spruce_log
fill 96 264 331 96 267 331 minecraft:stone
setblock 96 264 335 minecraft:stripped_spruce_log
fill 96 264 336 96 267 336 minecraft:stone
setblock 96 264 355 minecraft:stripped_spruce_log
fill 96 264 356 96 267 356 minecraft:stone
setblock 96 264 360 minecraft:stripped_spruce_log
fill 96 264 361 99 264 361 minecraft:stone
setblock 97 264 325 minecraft:light[level=12]
setblock 97 264 332 minecraft:light[level=12]
setblock 97 264 339 minecraft:light[level=12]
setblock 97 264 346 minecraft:light[level=12]
setblock 97 264 353 minecraft:light[level=12]
setblock 97 264 354 minecraft:stripped_spruce_log
fill 97 264 355 97 267 355 minecraft:stone
setblock 97 264 359 minecraft:stripped_spruce_log
fill 97 264 360 97 267 360 minecraft:stone
fill 98 264 322 103 267 322 minecraft:stone
setblock 98 264 323 minecraft:stripped_spruce_log
setblock 98 264 357 minecraft:stone
setblock 98 264 358 minecraft:stripped_spruce_log
fill 98 264 359 98 267 359 minecraft:stone
setblock 98 264 362 minecraft:stone
setblock 98 264 363 minecraft:stripped_spruce_log
fill 99 264 323 99 267 323 minecraft:stone
setblock 99 264 362 minecraft:stripped_spruce_log
fill 99 264 363 99 267 363 minecraft:stone
setblock 100 264 361 minecraft:stripped_spruce_log
fill 100 264 362 100 267 362 minecraft:stone
fill 101 264 361 102 266 361 minecraft:stone
setblock 101 264 364 minecraft:raw_gold_block
fill 102 264 332 103 264 337 minecraft:stripped_dark_oak_log
fill 102 264 364 102 308 364 minecraft:stone
fill 103 264 331 108 264 331 minecraft:stripped_dark_oak_log
fill 103 264 338 110 264 338 minecraft:stripped_dark_oak_log
fill 103 264 360 103 264 361 minecraft:iron_bars
setblock 103 264 363 minecraft:stripped_spruce_log
setblock 104 264 322 minecraft:diamond_block
setblock 104 264 325 minecraft:light[level=12]
fill 104 264 332 104 265 333 minecraft:stripped_dark_oak_log
fill 104 264 337 104 266 337 minecraft:stripped_dark_oak_log
fill 104 264 339 108 264 339 minecraft:stripped_dark_oak_log
setblock 104 264 346 minecraft:light[level=12]
setblock 104 264 353 minecraft:light[level=12]
setblock 104 264 360 minecraft:light[level=12]
fill 104 264 363 104 267 363 minecraft:stone
fill 105 264 332 109 264 332 minecraft:stripped_dark_oak_log
fill 108 264 322 108 284 322 minecraft:stone
fill 108 264 333 110 264 333 minecraft:stripped_dark_oak_log
fill 108 264 337 110 265 337 minecraft:stripped_dark_oak_log
fill 109 264 334 110 264 336 minecraft:stripped_dark_oak_log
fill 110 264 339 111 264 340 minecraft:stripped_dark_oak_log
setblock 111 264 325 minecraft:light[level=12]
setblock 111 264 332 minecraft:light[level=12]
fill 111 264 334 114 264 335 minecraft:stripped_dark_oak_log
setblock 111 264 346 minecraft:light[level=12]
setblock 111 264 353 minecraft:light[level=12]
setblock 111 264 360 minecraft:light[level=12]
fill 112 264 340 115 264 340 minecraft:stripped_dark_oak_log
fill 114 264 339 115 265 339 minecraft:stripped_dark_oak_log
setblock 115 264 322 minecraft:diamond_block
fill 115 264 335 115 264 338 minecraft:stripped_dark_oak_log
fill 116 264 336 116 264 338 minecraft:stripped_dark_oak_log
setblock 116 264 356 minecraft:raw_gold_block
fill 116 264 363 117 264 363 minecraft:stone
setblock 118 264 325 minecraft:light[level=12]
setblock 118 264 332 minecraft:light[level=12]
setblock 118 264 339 minecraft:light[level=12]
setblock 118 264 346 minecraft:light[level=12]
setblock 118 264 353 minecraft:light[level=12]
setblock 118 264 360 minecraft:light[level=12]
setblock 118 264 363 minecraft:stripped_spruce_log
fill 119 264 363 119 267 363 minecraft:stone
fill 124 264 355 124 264 362 minecraft:iron_bars
setblock 125 264 325 minecraft:light[level=12]
setblock 125 264 332 minecraft:light[level=12]
setblock 125 264 339 minecraft:light[level=12]
setblock 125 264 346 minecraft:light[level=12]
setblock 125 264 353 minecraft:light[level=12]
setblock 125 264 360 minecraft:light[level=12]
setblock 126 264 322 minecraft:raw_iron_block
setblock 132 264 325 minecraft:light[level=12]
setblock 132 264 332 minecraft:light[level=12]
setblock 132 264 339 minecraft:light[level=12]
setblock 132 264 346 minecraft:light[level=12]
setblock 132 264 353 minecraft:light[level=12]
setblock 132 264 360 minecraft:light[level=12]
setblock 134 264 322 minecraft:gold_block
fill 134 264 323 135 266 323 minecraft:stone
setblock 134 264 332 minecraft:stripped_spruce_log
fill 134 264 333 134 267 333 minecraft:stone
setblock 134 264 337 minecraft:stripped_spruce_log
fill 134 264 338 134 267 338 minecraft:stone
fill 134 264 363 135 266 363 minecraft:stone
fill 135 264 324 135 264 325 minecraft:stone
setblock 135 264 326 minecraft:stripped_spruce_log
fill 135 264 327 135 267 327 minecraft:stone
setblock 135 264 331 minecraft:stripped_spruce_log
fill 135 264 332 135 267 332 minecraft:stone
setblock 135 264 336 minecraft:stripped_spruce_log
fill 135 264 337 135 267 337 minecraft:stone
setblock 135 264 341 minecraft:stripped_spruce_log
fill 135 264 353 135 266 353 minecraft:stone
setblock 135 264 355 minecraft:stone
setblock 135 264 356 minecraft:stripped_spruce_log
fill 135 264 357 135 267 357 minecraft:stone
setblock 135 264 360 minecraft:stone
setblock 135 264 361 minecraft:stripped_spruce_log
fill 135 264 362 135 267 362 minecraft:stone
setblock 136 264 351 minecraft:raw_gold_block
setblock 94 265 338 minecraft:raw_gold_block
fill 94 265 339 95 265 339 minecraft:stone
fill 95 265 323 95 265 324 minecraft:stone
setblock 95 265 325 minecraft:stripped_spruce_log
fill 95 265 326 95 265 329 minecraft:stone
setblock 95 265 330 minecraft:stripped_spruce_log
fill 95 265 331 95 267 331 minecraft:stone
setblock 95 265 335 minecraft:stripped_spruce_log
fill 95 265 336 95 267 336 minecraft:stone
setblock 95 265 340 minecraft:stripped_spruce_log
fill 95 265 341 95 267 341 minecraft:stone
setblock 95 265 350 minecraft:stripped_spruce_log
fill 95 265 351 95 267 351 minecraft:stone
setblock 95 265 355 minecraft:stripped_spruce_log
fill 95 265 356 95 267 356 minecraft:stone
setblock 95 265 360 minecraft:stripped_spruce_log
fill 95 265 361 96 265 363 minecraft:stone
setblock 95 265 364 minecraft:raw_gold_block
setblock 96 265 323 minecraft:stone
fill 96 265 330 96 267 330 minecraft:stone
setblock 96 265 334 minecraft:stripped_spruce_log
fill 96 265 335 96 267 335 minecraft:stone
setblock 96 265 338 minecraft:stone
setblock 96 265 339 minecraft:stripped_spruce_log
setblock 96 265 354 minecraft:stripped_spruce_log
fill 96 265 355 96 267 355 minecraft:stone
setblock 96 265 358 minecraft:stone
setblock 96 265 359 minecraft:stripped_spruce_log
fill 96 265 360 96 267 360 minecraft:stone
setblock 97 265 323 minecraft:stripped_spruce_log
fill 97 265 354 97 267 354 minecraft:stone
setblock 97 265 358 minecraft:stripped_spruce_log
fill 97 265 359 97 267 359 minecraft:stone
fill 97 265 361 97 265 362 minecraft:stone
setblock 97 265 363 minecraft:stripped_spruce_log
fill 98 265 323 98 267 323 minecraft:stone
setblock 98 265 356 minecraft:stone
setblock 98 265 357 minecraft:stripped_spruce_log
fill 98 265 358 98 267 358 minecraft:stone
fill 98 265 360 98 265 361 minecraft:stone
setblock 98 265 362 minecraft:stripped_spruce_log
fill 98 265 363 98 267 363 minecraft:stone
setblock 99 265 360 minecraft:stone
setblock 99 265 361 minecraft:stripped_spruce_log
fill 99 265 362 99 267 362 minecraft:stone
setblock 100 265 360 minecraft:stripped_spruce_log
fill 100 265 361 100 267 361 minecraft:stone
fill 101 265 364 101 269 364 minecraft:stone
fill 102 265 334 103 265 336 minecraft:stripped_dark_oak_log
setblock 102 265 363 minecraft:stripped_spruce_log
fill 103 265 332 103 265 333 minecraft:stripped_dark_oak_log
setblock 103 265 337 minecraft:stripped_dark_oak_log
setblock 103 265 362 minecraft:stripped_spruce_log
fill 103 265 363 103 267 363 minecraft:stone
fill 104 265 322 104 286 322 minecraft:stone
fill 104 265 338 108 265 338 minecraft:stripped_dark_oak_log
fill 104 265 362 104 267 362 minecraft:stone
fill 105 265 331 107 265 332 minecraft:stripped_dark_oak_log
setblock 106 265 363 minecraft:stone
fill 108 265 332 108 265 333 minecraft:stripped_dark_oak_log
fill 109 265 333 109 265 336 minecraft:stripped_dark_oak_log
setblock 110 265 336 minecraft:stripped_dark_oak_log
fill 110 265 338 110 265 339 minecraft:stripped_dark_oak_log
fill 111 265 335 114 265 335 minecraft:stripped_dark_oak_log
fill 111 265 339 111 265 340 minecraft:stripped_dark_oak_log
fill 112 265 340 114 265 340 minecraft:stripped_dark_oak_log
fill 113 265 363 116 265 363 minecraft:stone
fill 115 265 322 115 278 322 minecraft:stone
fill 115 265 336 115 265 338 minecraft:stripped_dark_oak_log
fill 116 265 362 117 265 362 minecraft:stone
setblock 116 265 364 minecraft:raw_gold_block
setblock 117 265 363 minecraft:stripped_spruce_log
fill 118 265 363 118 267 363 minecraft:stone
fill 120 265 363 120 266 363 minecraft:stone
fill 124 265 322 124 287 322 minecraft:stone
setblock 125 265 322 minecraft:raw_iron_block
setblock 126 265 322 minecraft:diamond_block
fill 133 265 323 133 267 323 minecraft:stone
fill 133 265 333 133 265 336 minecraft:stone
fill 133 265 363 133 267 363 minecraft:stone
fill 134 265 322 134 308 322 minecraft:stone
fill 134 265 328 134 267 328 minecraft:stone
setblock 134 265 331 minecraft:stripped_spruce_log
fill 134 265 332 134 267 332 minecraft:stone
setblock 134 265 336 minecraft:stripped_spruce_log
fill 134 265 337 134 267 337 minecraft:stone
fill 134 265 339 134 265 340 minecraft:stone
fill 134 265 357 134 265 360 minecraft:stone
setblock 134 265 361 minecraft:stripped_spruce_log
setblock 135 265 324 minecraft:stone
setblock 135 265 325 minecraft:stripped_spruce_log
fill 135 265 326 135 267 326 minecraft:stone
setblock 135 265 330 minecraft:stripped_spruce_log
fill 135 265 331 135 267 331 minecraft:stone
setblock 135 265 335 minecraft:stripped_spruce_log
fill 135 265 336 135 267 336 minecraft:stone
setblock 135 265 340 minecraft:stripped_spruce_log
fill 135 265 341 135 267 342 minecraft:stone
setblock 135 265 355 minecraft:stripped_spruce_log
fill 135 265 356 135 267 356 minecraft:stone
setblock 135 265 360 minecraft:stripped_spruce_log
fill 135 265 361 135 267 361 minecraft:stone
fill 136 265 351 136 308 351 minecraft:stone
setblock 94 266 331 minecraft:raw_iron_block
setblock 94 266 334 minecraft:raw_iron_block
fill 94 266 338 94 283 339 minecraft:stone
setblock 95 266 323 minecraft:stone
setblock 95 266 324 minecraft:stripped_spruce_log
fill 95 266 325 95 266 328 minecraft:stone
setblock 95 266 329 minecraft:stripped_spruce_log
fill 95 266 330 95 267 330 minecraft:stone
setblock 95 266 334 minecraft:stripped_spruce_log
fill 95 266 335 95 267 335 minecraft:stone
setblock 95 266 339 minecraft:stripped_spruce_log
fill 95 266 340 96 267 340 minecraft:stone
fill 95 266 342 95 266 343 minecraft:stone
setblock 95 266 349 minecraft:stripped_spruce_log
fill 95 266 350 95 267 350 minecraft:stone
setblock 95 266 354 minecraft:stripped_spruce_log
fill 95 266 355 95 267 355 minecraft:stone
setblock 95 266 359 minecraft:stripped_spruce_log
fill 95 266 360 95 266 364 minecraft:stone
setblock 96 266 323 minecraft:stripped_spruce_log
fill 96 266 324 96 266 325 minecraft:stone
setblock 96 266 333 minecraft:stripped_spruce_log
fill 96 266 334 96 267 334 minecraft:stone
setblock 96 266 338 minecraft:stripped_spruce_log
fill 96 266 339 96 267 339 minecraft:stone
setblock 96 266 353 minecraft:stripped_spruce_log
fill 96 266 354 96 267 354 minecraft:stone
setblock 96 266 358 minecraft:stripped_spruce_log
fill 96 266 359 96 267 359 minecraft:stone
fill 96 266 361 96 266 362 minecraft:stone
setblock 96 266 363 minecraft:stripped_spruce_log
fill 97 266 323 97 267 324 minecraft:stone
setblock 97 266 325 minecraft:light[level=15]
setblock 97 266 333 minecraft:light[level=15]
setblock 97 266 341 minecraft:light[level=15]
setblock 97 266 349 minecraft:light[level=15]
fill 97 266 353 97 267 353 minecraft:stone
setblock 97 266 357 minecraft:stripped_spruce_log
fill 97 266 358 97 267 358 minecraft:stone
setblock 97 266 361 minecraft:stone
setblock 97 266 362 minecraft:stripped_spruce_log
fill 97 266 363 97 267 363 minecraft:stone
fill 98 266 324 98 267 324 minecraft:stone
setblock 98 266 356 minecraft:stripped_spruce_log
fill 98 266 357 98 267 357 minecraft:stone
setblock 98 266 360 minecraft:stone
setblock 98 266 361 minecraft:stripped_spruce_log
fill 98 266 362 98 267 362 minecraft:stone
setblock 99 266 360 minecraft:stripped_spruce_log
fill 99 266 361 99 267 361 minecraft:stone
fill 100 266 360 101 267 360 minecraft:stone
setblock 101 266 323 minecraft:stripped_spruce_log
setblock 101 266 363 minecraft:stripped_spruce_log
setblock 102 266 362 minecraft:stripped_spruce_log
fill 102 266 363 102 267 363 minecraft:stone
fill 103 266 334 103 266 336 minecraft:stripped_dark_oak_log
setblock 103 266 361 minecraft:stripped_spruce_log
fill 103 266 362 103 267 362 minecraft:stone
setblock 104 266 333 minecraft:stripped_dark_oak_log
setblock 105 266 325 minecraft:light[level=15]
fill 105 266 332 107 266 332 minecraft:stripped_dark_oak_log
fill 105 266 338 106 266 338 minecraft:stripped_dark_oak_log
setblock 105 266 341 minecraft:light[level=15]
setblock 105 266 349 minecraft:light[level=15]
setblock 105 266 357 minecraft:light[level=15]
fill 105 266 362 105 267 362 minecraft:stone
setblock 106 266 363 minecraft:stripped_spruce_log
fill 107 266 363 110 266 363 minecraft:stone
setblock 108 266 333 minecraft:stripped_dark_oak_log
setblock 108 266 337 minecraft:stripped_dark_oak_log
fill 109 266 334 109 266 335 minecraft:stripped_dark_oak_log
fill 110 266 337 110 266 338 minecraft:stripped_dark_oak_log
setblock 111 266 339 minecraft:stripped_dark_oak_log
setblock 111 266 363 minecraft:stripped_spruce_log
fill 112 266 335 113 266 335 minecraft:stripped_dark_oak_log
fill 112 266 363 115 266 363 minecraft:stone
setblock 113 266 325 minecraft:light[level=15]
setblock 113 266 333 minecraft:light[level=15]
setblock 113 266 341 minecraft:light[level=15]
setblock 113 266 349 minecraft:light[level=15]
setblock 113 266 357 minecraft:light[level=15]
fill 113 266 362 116 266 362 minecraft:stone
setblock 114 266 339 minecraft:stripped_dark_oak_log
setblock 115 266 337 minecraft:stripped_dark_oak_log
setblock 116 266 363 minecraft:stripped_spruce_log
fill 116 266 364 116 308 364 minecraft:stone
fill 117 266 323 119 267 323 minecraft:stone
setblock 117 266 362 minecraft:stripped_spruce_log
fill 117 266 363 117 267 363 minecraft:stone
fill 118 266 362 119 267 362 minecraft:stone
setblock 121 266 325 minecraft:light[level=15]
setblock 121 266 333 minecraft:light[level=15]
setblock 121 266 341 minecraft:light[level=15]
setblock 121 266 349 minecraft:light[level=15]
setblock 121 266 357 minecraft:light[level=15]
setblock 121 266 363 minecraft:stripped_spruce_log
fill 125 266 322 126 297 322 minecraft:stone
setblock 128 266 322 minecraft:raw_iron_block
setblock 129 266 325 minecraft:light[level=15]
setblock 129 266 333 minecraft:light[level=15]
setblock 129 266 341 minecraft:light[level=15]
setblock 129 266 349 minecraft:light[level=15]
setblock 129 266 357 minecraft:light[level=15]
setblock 131 266 323 minecraft:stripped_spruce_log
setblock 131 266 363 minecraft:stripped_spruce_log
fill 132 266 323 132 267 323 minecraft:stone
fill 132 266 363 132 267 363 minecraft:stone
fill 133 266 333 133 266 335 minecraft:stone
setblock 133 266 336 minecraft:stripped_spruce_log
fill 133 266 337 133 267 338 minecraft:stone
fill 133 266 362 134 266 362 minecraft:stone
setblock 134 266 324 minecraft:stone
setblock 134 266 325 minecraft:stripped_spruce_log
fill 134 266 326 134 267 327 minecraft:stone
setblock 134 266 330 minecraft:stripped_spruce_log
fill 134 266 331 134 267 331 minecraft:stone
setblock 134 266 335 minecraft:stripped_spruce_log
fill 134 266 336 134 267 336 minecraft:stone
setblock 134 266 339 minecraft:stone
setblock 134 266 340 minecraft:stripped_spruce_log
fill 134 266 341 134 267 341 minecraft:stone
fill 134 266 356 134 266 359 minecraft:stone
setblock 134 266 360 minecraft:stripped_spruce_log
fill 134 266 361 134 267 361 minecraft:stone
setblock 135 266 324 minecraft:stripped_spruce_log
fill 135 266 325 135 267 325 minecraft:stone
setblock 135 266 329 minecraft:stripped_spruce_log
fill 135 266 330 135 267 330 minecraft:stone
setblock 135 266 334 minecraft:stripped_spruce_log
fill 135 266 335 135 267 335 minecraft:stone
setblock 135 266 339 minecraft:stripped_spruce_log
fill 135 266 340 135 267 340 minecraft:stone
setblock 135 266 343 minecraft:stone
setblock 135 266 344 minecraft:stripped_spruce_log
fill 135 266 352 135 267 352 minecraft:stone
setblock 135 266 354 minecraft:stripped_spruce_log
fill 135 266 355 135 267 355 minecraft:stone
setblock 135 266 359 minecraft:stripped_spruce_log
fill 135 266 360 135 267 360 minecraft:stone
setblock 136 266 348 minecraft:diamond_block
fill 94 267 331 94 308 331 minecraft:stone
fill 94 267 334 95 267 334 minecraft:stone
setblock 95 267 323 minecraft:stripped_spruce_log
fill 95 267 324 95 267 327 minecraft:stone
setblock 95 267 328 minecraft:stripped_spruce_log
setblock 95 267 329 minecraft:stone
setblock 95 267 333 minecraft:stripped_spruce_log
setblock 95 267 337 minecraft:stone
setblock 95 267 338 minecraft:stripped_spruce_log
setblock 95 267 339 minecraft:stone
setblock 95 267 342 minecraft:stone
setblock 95 267 343 minecraft:stripped_spruce_log
fill 95 267 344 95 267 347 minecraft:stone
setblock 95 267 348 minecraft:stripped_spruce_log
setblock 95 267 349 minecraft:stone
setblock 95 267 352 minecraft:stone
setblock 95 267 353 minecraft:stripped_spruce_log
setblock 95 267 354 minecraft:stone
setblock 95 267 358 minecraft:stripped_spruce_log
fill 95 267 359 95 267 362 minecraft:stone
setblock 95 267 363 minecraft:stripped_spruce_log
fill 95 267 364 95 299 364 minecraft:stone
setblock 96 267 323 minecraft:stone
fill 96 267 324 96 270 324 minecraft:spruce_log
fill 96 267 325 96 267 326 minecraft:stone
setblock 96 267 332 minecraft:stripped_spruce_log
setblock 96 267 333 minecraft:stone
setblock 96 267 337 minecraft:stripped_spruce_log
setblock 96 267 338 minecraft:stone
setblock 96 267 341 minecraft:stone
setblock 96 267 342 minecraft:stripped_spruce_log
fill 96 267 343 96 270 343 minecraft:spruce_log
setblock 96 267 351 minecraft:stone
setblock 96 267 352 minecraft:stripped_spruce_log
setblock 96 267 353 minecraft:stone
setblock 96 267 357 minecraft:stripped_spruce_log
setblock 96 267 358 minecraft:stone
setblock 96 267 361 minecraft:stone
fill 96 267 362 96 270 362 minecraft:spruce_log
setblock 96 267 363 minecraft:stone
setblock 97 267 356 minecraft:stripped_spruce_log
setblock 97 267 357 minecraft:stone
setblock 97 267 361 minecraft:stripped_spruce_log
setblock 97 267 362 minecraft:stone
setblock 98 267 355 minecraft:stripped_spruce_log
setblock 98 267 356 minecraft:stone
setblock 98 267 360 minecraft:stripped_spruce_log
setblock 98 267 361 minecraft:stone
setblock 99 267 360 minecraft:stone
setblock 100 267 323 minecraft:stripped_spruce_log
setblock 100 267 363 minecraft:stripped_spruce_log
setblock 101 267 323 minecraft:stone
setblock 101 267 361 minecraft:stone
setblock 101 267 362 minecraft:stripped_spruce_log
setblock 101 267 363 minecraft:stone
setblock 102 267 361 minecraft:stripped_spruce_log
setblock 102 267 362 minecraft:stone
setblock 103 267 361 minecraft:stone
setblock 105 267 363 minecraft:stripped_spruce_log
setblock 106 267 362 minecraft:stripped_spruce_log
fill 106 267 363 109 267 363 minecraft:stone
setblock 110 267 362 minecraft:stone
setblock 110 267 363 minecraft:stripped_spruce_log
setblock 111 267 362 minecraft:stripped_spruce_log
fill 111 267 363 114 267 363 minecraft:stone
fill 112 267 362 114 267 362 minecraft:stone
fill 114 267 361 116 267 361 minecraft:stone
setblock 115 267 323 minecraft:stripped_spruce_log
fill 115 267 324 115 270 324 minecraft:spruce_log
fill 115 267 362 115 270 362 minecraft:spruce_log
setblock 115 267 363 minecraft:stripped_spruce_log
setblock 116 267 323 minecraft:stone
setblock 116 267 362 minecraft:stripped_spruce_log
setblock 116 267 363 minecraft:stone
setblock 117 267 361 minecraft:stripped_spruce_log
setblock 117 267 362 minecraft:stone
setblock 120 267 323 minecraft:stripped_spruce_log
setblock 120 267 362 minecraft:stone
setblock 120 267 363 minecraft:stripped_spruce_log
setblock 120 267 364 minecraft:diamond_block
setblock 121 267 323 minecraft:stone
fill 121 267 363 122 267 363 minecraft:stone
fill 128 267 322 128 301 322 minecraft:stone
setblock 129 267 323 minecraft:stone
setblock 130 267 323 minecraft:stripped_spruce_log
setblock 130 267 363 minecraft:stripped_spruce_log
setblock 131 267 323 minecraft:stone
setblock 131 267 363 minecraft:stone
fill 132 267 324 133 267 324 minecraft:stone
fill 132 267 362 133 267 362 minecraft:stone
fill 133 267 332 133 267 334 minecraft:stone
setblock 133 267 335 minecraft:stripped_spruce_log
setblock 133 267 336 minecraft:stone
setblock 133 267 339 minecraft:stone
setblock 134 267 323 minecraft:stone
fill 134 267 324 134 270 324 minecraft:spruce_log
setblock 134 267 325 minecraft:stone
setblock 134 267 329 minecraft:stripped_spruce_log
setblock 134 267 330 minecraft:stone
setblock 134 267 334 minecraft:stripped_spruce_log
setblock 134 267 335 minecraft:stone
setblock 134 267 339 minecraft:stripped_spruce_log
setblock 134 267 340 minecraft:stone
setblock 134 267 342 minecraft:stone
fill 134 267 343 134 270 343 minecraft:spruce_log
fill 134 267 355 134 267 358 minecraft:stone
setblock 134 267 359 minecraft:stripped_spruce_log
setblock 134 267 360 minecraft:stone
fill 134 267 362 134 270 362 minecraft:spruce_log
setblock 134 267 363 minecraft:stone
setblock 135 267 323 minecraft:stripped_spruce_log
setblock 135 267 324 minecraft:stone
setblock 135 267 328 minecraft:stripped_spruce_log
setblock 135 267 329 minecraft:stone
setblock 135 267 333 minecraft:stripped_spruce_log
setblock 135 267 334 minecraft:stone
setblock 135 267 338 minecraft:stripped_spruce_log
setblock 135 267 339 minecraft:stone
setblock 135 267 343 minecraft:stripped_spruce_log
fill 135 267 344 135 267 345 minecraft:stone
setblock 135 267 353 minecraft:stripped_spruce_log
setblock 135 267 354 minecraft:stone
setblock 135 267 358 minecraft:stripped_spruce_log
setblock 135 267 359 minecraft:stone
setblock 135 267 363 minecraft:stripped_spruce_log
fill 136 267 348 136 305 348 minecraft:stone
setblock 136 267 356 minecraft:raw_iron_block
fill 94 268 334 94 283 334 minecraft:stone
fill 98 268 322 100 290 322 minecraft:stone
setblock 101 268 322 minecraft:raw_gold_block
fill 102 268 322 103 305 322 minecraft:stone
fill 120 268 364 120 308 364 minecraft:stone
fill 136 268 356 136 293 356 minecraft:stone
setblock 94 269 326 minecraft:raw_iron_block
fill 101 269 322 101 308 322 minecraft:stone
fill 119 269 322 119 308 322 minecraft:stone
setblock 120 269 322 minecraft:raw_iron_block
fill 121 269 322 123 294 322 minecraft:stone
setblock 136 269 337 minecraft:gold_block
fill 94 270 326 94 308 326 minecraft:stone
fill 94 270 347 94 299 348 minecraft:stone
setblock 94 270 349 minecraft:raw_iron_block
fill 94 270 350 94 286 352 minecraft:stone
setblock 97 270 325 minecraft:light[level=12]
setblock 97 270 332 minecraft:light[level=12]
setblock 97 270 339 minecraft:light[level=12]
setblock 97 270 346 minecraft:light[level=12]
setblock 97 270 353 minecraft:light[level=12]
setblock 97 270 360 minecraft:light[level=12]
setblock 101 270 364 minecraft:raw_iron_block
setblock 104 270 325 minecraft:light[level=12]
setblock 104 270 332 minecraft:light[level=12]
setblock 104 270 339 minecraft:light[level=12]
setblock 104 270 346 minecraft:light[level=12]
setblock 104 270 353 minecraft:light[level=12]
setblock 104 270 360 minecraft:light[level=12]
setblock 111 270 325 minecraft:light[level=12]
setblock 111 270 332 minecraft:light[level=12]
setblock 111 270 339 minecraft:light[level=12]
setblock 111 270 346 minecraft:light[level=12]
setblock 111 270 353 minecraft:light[level=12]
setblock 111 270 360 minecraft:light[level=12]
setblock 118 270 322 minecraft:raw_iron_block
setblock 118 270 325 minecraft:light[level=12]
setblock 118 270 332 minecraft:light[level=12]
setblock 118 270 339 minecraft:light[level=12]
setblock 118 270 346 minecraft:light[level=12]
setblock 118 270 353 minecraft:light[level=12]
setblock 118 270 360 minecraft:light[level=12]
setblock 119 270 364 minecraft:raw_gold_block
fill 120 270 322 120 308 322 minecraft:stone
setblock 125 270 325 minecraft:light[level=12]
setblock 125 270 332 minecraft:light[level=12]
setblock 125 270 339 minecraft:light[level=12]
setblock 125 270 346 minecraft:light[level=12]
setblock 125 270 353 minecraft:light[level=12]
setblock 125 270 360 minecraft:light[level=12]
setblock 132 270 325 minecraft:light[level=12]
setblock 132 270 332 minecraft:light[level=12]
setblock 132 270 339 minecraft:light[level=12]
setblock 132 270 346 minecraft:light[level=12]
setblock 132 270 353 minecraft:light[level=12]
setblock 132 270 360 minecraft:light[level=12]
setblock 136 270 325 minecraft:diamond_block
fill 136 270 337 136 308 337 minecraft:stone
fill 94 271 349 94 308 349 minecraft:stone
setblock 96 271 324 minecraft:glowstone
setblock 96 271 343 minecraft:glowstone
setblock 96 271 362 minecraft:glowstone
fill 101 271 364 101 308 364 minecraft:stone
setblock 115 271 324 minecraft:glowstone
setblock 115 271 362 minecraft:glowstone
fill 118 271 322 118 283 322 minecraft:stone
fill 119 271 364 119 308 364 minecraft:stone
setblock 131 271 322 minecraft:raw_gold_block
fill 132 271 322 133 308 322 minecraft:stone
setblock 134 271 324 minecraft:glowstone
setblock 134 271 343 minecraft:glowstone
setblock 134 271 362 minecraft:glowstone
fill 136 271 325 136 308 325 minecraft:stone
fill 136 271 358 136 281 360 minecraft:stone
setblock 136 271 361 minecraft:diamond_block
fill 96 272 324 96 273 324 minecraft:spruce_log
setblock 96 272 343 minecraft:spruce_log
fill 96 272 362 96 273 362 minecraft:spruce_log
setblock 115 272 324 minecraft:spruce_log
setblock 115 272 362 minecraft:spruce_log
fill 131 272 322 131 308 322 minecraft:stone
setblock 132 272 364 minecraft:raw_gold_block
fill 134 272 324 134 273 324 minecraft:spruce_log
setblock 134 272 343 minecraft:spruce_log
fill 134 272 362 134 273 362 minecraft:spruce_log
setblock 136 272 361 minecraft:stone
fill 95 273 323 95 273 326 minecraft:spruce_planks
fill 95 273 327 108 273 359 minecraft:andesite
fill 95 273 360 95 273 363 minecraft:spruce_planks
fill 96 273 323 98 273 323 minecraft:spruce_planks
setblock 96 273 325 minecraft:spruce_planks
fill 96 273 326 134 273 326 minecraft:andesite
fill 96 273 360 134 273 360 minecraft:andesite
setblock 96 273 361 minecraft:spruce_planks
fill 96 273 363 98 273 363 minecraft:spruce_planks
setblock 97 273 324 minecraft:spruce_planks
fill 97 273 325 133 273 325 minecraft:andesite
fill 97 273 361 133 273 361 minecraft:andesite
setblock 97 273 362 minecraft:spruce_planks
fill 98 273 324 132 273 324 minecraft:andesite
fill 98 273 362 132 273 362 minecraft:andesite
fill 99 273 323 131 273 323 minecraft:andesite
fill 99 273 363 131 273 363 minecraft:andesite
fill 109 273 327 109 273 343 minecraft:andesite
fill 109 273 345 109 273 359 minecraft:andesite
fill 110 273 327 111 273 341 minecraft:andesite
fill 110 273 347 111 273 359 minecraft:andesite
fill 112 273 327 135 273 340 minecraft:andesite
fill 112 273 348 135 273 359 minecraft:andesite
fill 113 273 341 135 273 341 minecraft:andesite
fill 113 273 347 135 273 347 minecraft:andesite
fill 115 273 342 135 273 343 minecraft:andesite
fill 115 273 345 135 273 346 minecraft:andesite
fill 116 273 344 135 273 344 minecraft:andesite
fill 132 273 323 135 273 323 minecraft:spruce_planks
fill 132 273 363 135 273 363 minecraft:spruce_planks
fill 132 273 364 132 299 364 minecraft:stone
setblock 133 273 324 minecraft:spruce_planks
setblock 133 273 362 minecraft:spruce_planks
fill 134 273 325 135 273 325 minecraft:spruce_planks
fill 134 273 361 135 273 361 minecraft:spruce_planks
setblock 135 273 324 minecraft:spruce_planks
setblock 135 273 326 minecraft:spruce_planks
setblock 135 273 360 minecraft:spruce_planks
setblock 135 273 362 minecraft:spruce_planks
fill 136 273 327 136 308 327 minecraft:stone
setblock 136 273 328 minecraft:gold_block
setblock 136 273 361 minecraft:raw_gold_block
fill 95 274 328 95 274 358 minecraft:andesite
fill 96 274 327 96 275 327 minecraft:andesite
fill 96 274 328 108 274 358 minecraft:stone
fill 96 274 359 96 275 359 minecraft:andesite
setblock 97 274 325 minecraft:light[level=15]
fill 97 274 326 97 275 326 minecraft:andesite
fill 97 274 327 133 275 327 minecraft:stone
fill 97 274 359 133 275 359 minecraft:stone
fill 97 274 360 97 275 360 minecraft:andesite
fill 98 274 325 98 275 325 minecraft:andesite
fill 98 274 326 132 275 326 minecraft:stone
fill 98 274 360 132 275 360 minecraft:stone
fill 98 274 361 98 275 361 minecraft:andesite
fill 99 274 324 99 275 324 minecraft:andesite
fill 99 274 325 131 275 325 minecraft:stone
fill 99 274 361 131 275 361 minecraft:stone
fill 99 274 362 99 275 362 minecraft:andesite
fill 100 274 323 130 274 323 minecraft:andesite
fill 100 274 324 130 274 324 minecraft:stone
fill 100 274 362 130 274 362 minecraft:stone
fill 100 274 363 130 274 363 minecraft:andesite
setblock 104 274 364 minecraft:raw_gold_block
setblock 106 274 322 minecraft:raw_iron_block
fill 109 274 328 109 277 343 minecraft:stone
fill 109 274 345 109 277 358 minecraft:stone
fill 110 274 328 111 277 341 minecraft:stone
fill 110 274 347 111 277 358 minecraft:stone
fill 112 274 328 134 274 340 minecraft:stone
fill 112 274 348 134 274 358 minecraft:stone
fill 113 274 341 134 277 341 minecraft:stone
fill 113 274 347 134 277 347 minecraft:stone
fill 115 274 342 134 277 343 minecraft:stone
fill 115 274 345 134 277 346 minecraft:stone
fill 116 274 344 134 278 344 minecraft:stone
setblock 125 274 364 minecraft:raw_gold_block
fill 131 274 324 131 275 324 minecraft:andesite
fill 131 274 362 131 275 362 minecraft:andesite
fill 132 274 325 132 275 325 minecraft:andesite
fill 132 274 361 132 275 361 minecraft:andesite
fill 133 274 326 133 275 326 minecraft:andesite
fill 133 274 360 133 275 360 minecraft:andesite
fill 134 274 327 134 275 327 minecraft:andesite
fill 134 274 359 134 275 359 minecraft:andesite
fill 135 274 328 135 274 358 minecraft:andesite
fill 136 274 328 136 308 328 minecraft:stone
setblock 136 274 354 minecraft:gold_block
fill 136 274 361 136 308 361 minecraft:stone
fill 95 275 329 95 276 357 minecraft:andesite
fill 96 275 328 96 276 328 minecraft:andesite
fill 96 275 329 108 276 357 minecraft:stone
fill 96 275 358 96 276 358 minecraft:andesite
fill 97 275 328 108 276 328 minecraft:stone
fill 97 275 358 108 276 358 minecraft:stone
fill 100 275 324 100 276 324 minecraft:andesite
fill 100 275 362 100 276 362 minecraft:andesite
fill 101 275 323 129 276 323 minecraft:andesite
fill 101 275 324 129 276 324 minecraft:stone
fill 101 275 362 129 276 362 minecraft:stone
fill 101 275 363 129 276 363 minecraft:andesite
fill 104 275 364 104 308 364 minecraft:stone
fill 106 275 322 106 308 322 minecraft:stone
setblock 108 275 364 minecraft:gold_block
fill 109 275 364 109 308 364 minecraft:stone
fill 112 275 328 133 276 340 minecraft:stone
fill 112 275 348 133 276 358 minecraft:stone
fill 125 275 364 125 287 364 minecraft:stone
fill 130 275 324 130 276 324 minecraft:andesite
fill 130 275 362 130 276 362 minecraft:andesite
fill 134 275 328 134 276 328 minecraft:andesite
fill 134 275 329 134 276 340 minecraft:stone
fill 134 275 348 134 276 357 minecraft:stone
fill 134 275 358 134 276 358 minecraft:andesite
fill 135 275 329 135 276 357 minecraft:andesite
fill 136 275 354 136 308 354 minecraft:stone
setblock 94 276 329 minecraft:raw_gold_block
fill 94 276 330 94 300 330 minecraft:stone
setblock 97 276 325 minecraft:light[level=12]
setblock 97 276 327 minecraft:andesite
setblock 97 276 359 minecraft:andesite
setblock 97 276 360 minecraft:light[level=12]
fill 98 276 326 98 277 326 minecraft:andesite
fill 98 276 327 132 276 327 minecraft:stone
fill 98 276 359 132 276 359 minecraft:stone
fill 98 276 360 98 277 360 minecraft:andesite
setblock 99 276 325 minecraft:andesite
fill 99 276 326 131 276 326 minecraft:stone
fill 99 276 360 131 276 360 minecraft:stone
setblock 99 276 361 minecraft:andesite
fill 100 276 325 130 276 325 minecraft:stone
fill 100 276 361 130 276 361 minecraft:stone
fill 108 276 364 108 283 364 minecraft:stone
setblock 126 276 364 minecraft:raw_iron_block
fill 127 276 364 127 308 364 minecraft:stone
setblock 131 276 325 minecraft:andesite
setblock 131 276 361 minecraft:andesite
setblock 132 276 325 minecraft:light[level=12]
fill 132 276 326 132 277 326 minecraft:andesite
fill 132 276 360 132 277 360 minecraft:andesite
setblock 133 276 327 minecraft:andesite
setblock 133 276 359 minecraft:andesite
setblock 133 276 364 minecraft:gold_block
setblock 136 276 342 minecraft:gold_block
setblock 94 277 328 minecraft:diamond_block
fill 94 277 329 94 293 329 minecraft:stone
fill 95 277 330 95 277 356 minecraft:andesite
fill 96 277 329 96 278 329 minecraft:andesite
fill 96 277 330 108 277 356 minecraft:stone
fill 96 277 357 96 278 357 minecraft:andesite
fill 97 277 328 97 278 328 minecraft:andesite
fill 97 277 329 108 278 329 minecraft:stone
fill 97 277 357 108 278 357 minecraft:stone
fill 97 277 358 97 278 358 minecraft:andesite
fill 98 277 327 98 278 327 minecraft:andesite
fill 98 277 328 108 278 328 minecraft:stone
fill 98 277 358 108 278 358 minecraft:stone
fill 98 277 359 98 278 359 minecraft:andesite
fill 99 277 326 99 278 326 minecraft:andesite
fill 99 277 327 131 278 327 minecraft:stone
fill 99 277 359 131 278 359 minecraft:stone
fill 99 277 360 99 278 360 minecraft:andesite
fill 100 277 325 100 278 325 minecraft:andesite
fill 100 277 326 130 278 326 minecraft:stone
fill 100 277 360 130 278 360 minecraft:stone
fill 100 277 361 100 278 361 minecraft:andesite
fill 101 277 324 101 278 324 minecraft:andesite
fill 101 277 325 129 278 325 minecraft:stone
fill 101 277 361 129 278 361 minecraft:stone
fill 101 277 362 101 278 362 minecraft:andesite
fill 102 277 323 128 277 323 minecraft:andesite
fill 102 277 324 128 277 324 minecraft:stone
fill 102 277 362 128 277 362 minecraft:stone
fill 102 277 363 128 277 363 minecraft:andesite
fill 112 277 328 132 278 340 minecraft:stone
fill 112 277 348 132 278 358 minecraft:stone
fill 126 277 364 126 282 364 minecraft:stone
fill 129 277 324 129 278 324 minecraft:andesite
fill 129 277 362 129 278 362 minecraft:andesite
fill 130 277 325 130 278 325 minecraft:andesite
fill 130 277 361 130 278 361 minecraft:andesite
fill 131 277 326 131 278 326 minecraft:andesite
fill 131 277 360 131 278 360 minecraft:andesite
fill 132 277 327 132 278 327 minecraft:andesite
fill 132 277 359 132 278 359 minecraft:andesite
fill 133 277 328 133 278 328 minecraft:andesite
fill 133 277 329 133 278 340 minecraft:stone
fill 133 277 348 133 278 357 minecraft:stone
fill 133 277 358 133 278 358 minecraft:andesite
fill 133 277 364 133 308 364 minecraft:stone
fill 134 277 329 134 278 329 minecraft:andesite
fill 134 277 330 134 277 340 minecraft:stone
fill 134 277 348 134 277 356 minecraft:stone
fill 134 277 357 134 278 357 minecraft:andesite
fill 135 277 330 135 277 356 minecraft:andesite
fill 136 277 342 136 308 342 minecraft:stone
fill 94 278 328 94 308 328 minecraft:stone
setblock 94 278 361 minecraft:raw_gold_block
fill 95 278 331 95 278 355 minecraft:andesite
fill 96 278 330 96 279 330 minecraft:andesite
fill 96 278 331 108 278 355 minecraft:stone
fill 96 278 356 96 279 356 minecraft:andesite
fill 97 278 330 111 279 330 minecraft:stone
fill 97 278 356 111 279 356 minecraft:stone
fill 102 278 324 102 279 324 minecraft:andesite
fill 102 278 362 102 279 362 minecraft:andesite
fill 103 278 323 127 278 323 minecraft:andesite
fill 103 278 324 127 278 324 minecraft:stone
fill 103 278 362 127 278 362 minecraft:stone
fill 103 278 363 127 278 363 minecraft:andesite
setblock 105 278 322 minecraft:raw_gold_block
fill 109 278 328 111 287 329 minecraft:stone
fill 109 278 331 109 278 342 minecraft:stone
setblock 109 278 343 minecraft:cobbled_deepslate
setblock 109 278 345 minecraft:cobbled_deepslate
fill 109 278 346 109 278 355 minecraft:stone
fill 109 278 357 111 287 358 minecraft:stone
fill 110 278 331 110 278 341 minecraft:stone
fill 110 278 347 110 278 355 minecraft:stone
fill 111 278 331 111 278 340 minecraft:stone
setblock 111 278 341 minecraft:cobbled_deepslate
setblock 111 278 347 minecraft:cobbled_deepslate
fill 111 278 348 111 278 355 minecraft:stone
fill 113 278 341 114 278 341 minecraft:cobbled_deepslate
fill 113 278 347 114 278 347 minecraft:cobbled_deepslate
fill 115 278 341 134 278 341 minecraft:stone
fill 115 278 342 115 278 343 minecraft:cobbled_deepslate
fill 115 278 345 115 278 346 minecraft:cobbled_deepslate
fill 115 278 347 134 278 347 minecraft:stone
fill 116 278 342 134 278 343 minecraft:stone
fill 116 278 345 134 278 346 minecraft:stone
fill 128 278 324 128 279 324 minecraft:andesite
fill 128 278 362 128 279 362 minecraft:andesite
fill 134 278 330 134 279 330 minecraft:andesite
fill 134 278 331 134 278 340 minecraft:stone
fill 134 278 348 134 278 355 minecraft:stone
fill 134 278 356 134 279 356 minecraft:andesite
fill 135 278 331 135 278 355 minecraft:andesite
fill 94 279 323 103 279 323 minecraft:stone
setblock 94 279 324 minecraft:diamond_block
setblock 94 279 340 minecraft:gold_block
fill 94 279 341 94 293 342 minecraft:stone
fill 94 279 361 100 279 361 minecraft:stone
fill 95 279 324 95 279 331 minecraft:stone
fill 95 279 332 95 279 354 minecraft:andesite
fill 95 279 355 95 279 360 minecraft:stone
fill 95 279 362 101 279 363 minecraft:stone
fill 96 279 324 96 279 329 minecraft:stone
fill 96 279 331 96 280 331 minecraft:andesite
fill 96 279 332 107 279 354 minecraft:stone
fill 96 279 355 96 280 355 minecraft:andesite
fill 96 279 357 96 279 360 minecraft:stone
fill 97 279 324 97 279 328 minecraft:stone
setblock 97 279 329 minecraft:andesite
fill 97 279 331 133 280 331 minecraft:stone
fill 97 279 355 133 280 355 minecraft:stone
setblock 97 279 357 minecraft:andesite
fill 97 279 358 97 279 360 minecraft:stone
fill 98 279 324 98 279 327 minecraft:stone
setblock 98 279 328 minecraft:andesite
fill 98 279 329 108 279 329 minecraft:stone
fill 98 279 357 108 279 357 minecraft:stone
setblock 98 279 358 minecraft:andesite
fill 98 279 359 98 279 360 minecraft:stone
fill 99 279 324 99 279 326 minecraft:stone
fill 99 279 327 99 280 327 minecraft:andesite
fill 99 279 328 108 279 328 minecraft:stone
fill 99 279 358 108 279 358 minecraft:stone
fill 99 279 359 99 280 359 minecraft:andesite
setblock 99 279 360 minecraft:stone
fill 100 279 324 100 279 325 minecraft:stone
setblock 100 279 326 minecraft:andesite
fill 100 279 327 130 279 327 minecraft:stone
fill 100 279 359 130 279 359 minecraft:stone
setblock 100 279 360 minecraft:andesite
setblock 101 279 324 minecraft:stone
setblock 101 279 325 minecraft:andesite
fill 101 279 326 129 279 326 minecraft:stone
fill 101 279 360 129 279 360 minecraft:stone
setblock 101 279 361 minecraft:andesite
fill 102 279 325 128 279 325 minecraft:stone
fill 102 279 361 128 279 361 minecraft:stone
fill 102 279 363 103 279 363 minecraft:stone
fill 103 279 324 103 280 324 minecraft:andesite
fill 103 279 362 103 280 362 minecraft:andesite
fill 104 279 323 126 279 323 minecraft:andesite
fill 104 279 324 126 279 324 minecraft:stone
fill 104 279 362 126 279 362 minecraft:stone
fill 104 279 363 126 279 363 minecraft:andesite
fill 105 279 322 105 308 322 minecraft:stone
fill 108 279 332 108 279 342 minecraft:stone
fill 108 279 343 108 279 345 minecraft:glowstone
fill 108 279 346 108 279 354 minecraft:stone
fill 109 279 332 110 279 340 minecraft:stone
fill 109 279 341 109 279 343 minecraft:glowstone
fill 109 279 345 109 279 347 minecraft:glowstone
fill 109 279 348 110 279 354 minecraft:stone
fill 110 279 341 111 279 341 minecraft:glowstone
fill 110 279 347 111 279 347 minecraft:glowstone
fill 111 279 332 134 279 339 minecraft:stone
fill 111 279 340 113 279 340 minecraft:glowstone
fill 111 279 348 113 279 348 minecraft:glowstone
fill 111 279 349 134 279 354 minecraft:stone
fill 112 279 328 131 279 330 minecraft:stone
fill 112 279 356 131 279 358 minecraft:stone
fill 113 279 341 115 279 341 minecraft:glowstone
fill 113 279 347 115 279 347 minecraft:glowstone
setblock 114 279 340 minecraft:spruce_planks
setblock 114 279 348 minecraft:spruce_planks
setblock 115 279 322 minecraft:raw_gold_block
fill 115 279 340 134 279 340 minecraft:stone
fill 115 279 342 115 279 343 minecraft:glowstone
fill 115 279 345 115 279 346 minecraft:glowstone
fill 115 279 348 134 279 348 minecraft:stone
fill 116 279 341 134 279 341 minecraft:stone
setblock 116 279 342 minecraft:spruce_planks
fill 116 279 343 116 279 345 minecraft:glowstone
setblock 116 279 346 minecraft:spruce_planks
fill 116 279 347 134 279 347 minecraft:stone
fill 117 279 342 134 279 346 minecraft:stone
fill 127 279 323 135 279 323 minecraft:stone
fill 127 279 324 127 280 324 minecraft:andesite
fill 127 279 362 127 280 362 minecraft:andesite
fill 127 279 363 135 279 363 minecraft:stone
fill 129 279 324 135 279 324 minecraft:stone
setblock 129 279 325 minecraft:andesite
setblock 129 279 361 minecraft:andesite
fill 129 279 362 135 279 362 minecraft:stone
fill 130 279 325 135 279 325 minecraft:stone
setblock 130 279 326 minecraft:andesite
setblock 130 279 360 minecraft:andesite
fill 130 279 361 135 279 361 minecraft:stone
fill 131 279 326 135 279 326 minecraft:stone
fill 131 279 327 131 280 327 minecraft:andesite
fill 131 279 359 131 280 359 minecraft:andesite
fill 131 279 360 135 279 360 minecraft:stone
fill 132 279 327 135 279 327 minecraft:stone
setblock 132 279 328 minecraft:andesite
fill 132 279 329 132 279 330 minecraft:stone
fill 132 279 356 132 279 357 minecraft:stone
setblock 132 279 358 minecraft:andesite
fill 132 279 359 135 279 359 minecraft:stone
fill 133 279 328 135 279 328 minecraft:stone
setblock 133 279 329 minecraft:andesite
setblock 133 279 330 minecraft:stone
setblock 133 279 356 minecraft:stone
setblock 133 279 357 minecraft:andesite
fill 133 279 358 135 279 358 minecraft:stone
fill 134 279 329 135 279 329 minecraft:stone
fill 134 279 331 134 280 331 minecraft:andesite
fill 134 279 355 134 280 355 minecraft:andesite
fill 134 279 357 135 279 357 minecraft:stone
fill 135 279 330 135 279 331 minecraft:stone
fill 135 279 332 135 279 354 minecraft:andesite
fill 135 279 355 135 279 356 minecraft:stone
fill 94 280 323 94 296 324 minecraft:stone
fill 94 280 340 94 308 340 minecraft:stone
fill 94 280 361 94 288 361 minecraft:stone
fill 95 280 333 95 280 353 minecraft:andesite
fill 96 280 332 96 281 332 minecraft:andesite
fill 96 280 333 107 280 353 minecraft:stone
fill 96 280 354 96 281 354 minecraft:andesite
setblock 97 280 330 minecraft:andesite
fill 97 280 332 133 281 332 minecraft:stone
fill 97 280 354 133 281 354 minecraft:stone
setblock 97 280 356 minecraft:andesite
fill 98 280 329 98 281 329 minecraft:andesite
fill 98 280 330 132 280 330 minecraft:stone
fill 98 280 356 132 280 356 minecraft:stone
fill 98 280 357 98 281 357 minecraft:andesite
fill 99 280 328 99 281 328 minecraft:andesite
fill 99 280 329 108 281 329 minecraft:stone
fill 99 280 357 108 281 357 minecraft:stone
fill 99 280 358 99 281 358 minecraft:andesite
fill 100 280 327 100 281 327 minecraft:andesite
fill 100 280 328 108 281 328 minecraft:stone
fill 100 280 358 108 281 358 minecraft:stone
fill 100 280 359 100 281 359 minecraft:andesite
fill 101 280 326 101 281 326 minecraft:andesite
fill 101 280 327 129 281 327 minecraft:stone
fill 101 280 359 129 281 359 minecraft:stone
fill 101 280 360 101 281 360 minecraft:andesite
setblock 102 280 325 minecraft:andesite
fill 102 280 326 128 280 326 minecraft:stone
fill 102 280 360 128 280 360 minecraft:stone
setblock 102 280 361 minecraft:andesite
fill 103 280 325 127 280 325 minecraft:stone
fill 103 280 361 127 280 361 minecraft:stone
fill 104 280 324 104 281 324 minecraft:andesite
fill 104 280 362 104 281 362 minecraft:andesite
fill 105 280 323 125 280 323 minecraft:andesite
fill 105 280 324 125 280 324 minecraft:stone
fill 105 280 362 125 280 362 minecraft:stone
fill 105 280 363 125 280 363 minecraft:andesite
fill 108 280 333 108 280 341 minecraft:stone
fill 108 280 342 108 280 346 minecraft:cobbled_deepslate
fill 108 280 347 108 280 353 minecraft:stone
fill 109 280 333 109 280 340 minecraft:stone
setblock 109 280 341 minecraft:cobbled_deepslate
setblock 109 280 347 minecraft:cobbled_deepslate
fill 109 280 348 109 280 353 minecraft:stone
fill 110 280 333 110 280 339 minecraft:stone
setblock 110 280 340 minecraft:cobbled_deepslate
setblock 110 280 348 minecraft:cobbled_deepslate
fill 110 280 349 110 280 353 minecraft:stone
fill 111 280 333 134 280 338 minecraft:stone
fill 111 280 339 114 280 339 minecraft:cobbled_deepslate
fill 111 280 349 113 281 349 minecraft:cobbled_deepslate
fill 111 280 350 134 280 353 minecraft:stone
fill 112 280 328 130 281 329 minecraft:stone
fill 112 280 357 130 281 358 minecraft:stone
fill 114 280 348 115 280 348 minecraft:cobbled_deepslate
fill 114 280 349 134 280 349 minecraft:stone
fill 115 280 322 115 288 322 minecraft:stone
fill 115 280 339 134 280 339 minecraft:stone
fill 115 280 340 116 280 340 minecraft:cobbled_deepslate
fill 116 280 341 117 280 341 minecraft:cobbled_deepslate
setblock 116 280 347 minecraft:cobbled_deepslate
fill 116 280 348 134 280 348 minecraft:stone
fill 117 280 340 134 280 340 minecraft:stone
fill 117 280 342 117 280 346 minecraft:cobbled_deepslate
fill 117 280 347 134 280 347 minecraft:stone
fill 118 280 341 134 280 346 minecraft:stone
fill 126 280 324 126 281 324 minecraft:andesite
fill 126 280 362 126 281 362 minecraft:andesite
setblock 128 280 325 minecraft:andesite
setblock 128 280 361 minecraft:andesite
fill 129 280 326 129 281 326 minecraft:andesite
fill 129 280 360 129 281 360 minecraft:andesite
fill 130 280 327 130 281 327 minecraft:andesite
fill 130 280 359 130 281 359 minecraft:andesite
fill 131 280 328 131 281 328 minecraft:andesite
fill 131 280 329 131 281 329 minecraft:stone
fill 131 280 357 131 281 357 minecraft:stone
fill 131 280 358 131 281 358 minecraft:andesite
fill 132 280 329 132 281 329 minecraft:andesite
fill 132 280 357 132 281 357 minecraft:andesite
setblock 133 280 330 minecraft:andesite
setblock 133 280 356 minecraft:andesite
fill 134 280 332 134 281 332 minecraft:andesite
fill 134 280 354 134 281 354 minecraft:andesite
fill 135 280 333 135 280 353 minecraft:andesite
fill 95 281 334 95 281 352 minecraft:andesite
fill 96 281 333 96 282 333 minecraft:andesite
fill 96 281 334 106 281 352 minecraft:stone
fill 96 281 353 96 282 353 minecraft:andesite
setblock 97 281 331 minecraft:andesite
fill 97 281 333 133 282 333 minecraft:stone
fill 97 281 353 133 282 353 minecraft:stone
setblock 97 281 355 minecraft:andesite
fill 98 281 330 98 282 330 minecraft:andesite
fill 98 281 331 132 281 331 minecraft:stone
fill 98 281 355 132 281 355 minecraft:stone
fill 98 281 356 98 282 356 minecraft:andesite
fill 99 281 330 131 282 330 minecraft:stone
fill 99 281 356 131 282 356 minecraft:stone
fill 102 281 326 102 282 326 minecraft:andesite
fill 102 281 360 102 282 360 minecraft:andesite
setblock 103 281 325 minecraft:andesite
fill 103 281 326 127 281 326 minecraft:stone
fill 103 281 360 127 281 360 minecraft:stone
setblock 103 281 361 minecraft:andesite
fill 104 281 325 126 281 325 minecraft:stone
fill 104 281 361 126 281 361 minecraft:stone
fill 105 281 324 105 282 324 minecraft:andesite
fill 105 281 362 105 282 362 minecraft:andesite
fill 106 281 323 124 281 323 minecraft:andesite
fill 106 281 324 124 281 324 minecraft:stone
fill 106 281 362 124 281 362 minecraft:stone
fill 106 281 363 124 281 363 minecraft:andesite
fill 107 281 334 107 281 341 minecraft:stone
fill 107 281 342 107 281 346 minecraft:cobbled_deepslate
fill 107 281 347 107 281 352 minecraft:stone
fill 108 281 334 108 281 340 minecraft:stone
setblock 108 281 341 minecraft:cobbled_deepslate
setblock 108 281 347 minecraft:cobbled_deepslate
fill 108 281 348 108 281 352 minecraft:stone
fill 109 281 334 109 281 339 minecraft:stone
setblock 109 281 340 minecraft:cobbled_deepslate
setblock 109 281 348 minecraft:cobbled_deepslate
fill 109 281 349 109 281 352 minecraft:stone
fill 110 281 334 110 281 338 minecraft:stone
setblock 110 281 339 minecraft:cobbled_deepslate
setblock 110 281 349 minecraft:cobbled_deepslate
fill 110 281 350 134 281 352 minecraft:stone
fill 111 281 334 134 281 337 minecraft:stone
fill 111 281 338 114 281 338 minecraft:cobbled_deepslate
fill 114 281 349 115 281 349 minecraft:cobbled_deepslate
fill 115 281 338 134 281 338 minecraft:stone
fill 115 281 339 116 281 339 minecraft:cobbled_deepslate
fill 116 281 348 117 281 348 minecraft:cobbled_deepslate
fill 116 281 349 134 281 349 minecraft:stone
fill 117 281 339 134 281 339 minecraft:stone
setblock 117 281 340 minecraft:cobbled_deepslate
setblock 117 281 347 minecraft:cobbled_deepslate
fill 118 281 340 134 281 340 minecraft:stone
fill 118 281 341 118 281 346 minecraft:cobbled_deepslate
fill 118 281 347 134 281 348 minecraft:stone
fill 119 281 341 134 281 346 minecraft:stone
fill 123 281 364 123 282 364 minecraft:raw_gold_block
fill 125 281 324 125 282 324 minecraft:andesite
fill 125 281 362 125 282 362 minecraft:andesite
setblock 127 281 325 minecraft:andesite
setblock 127 281 361 minecraft:andesite
fill 128 281 326 128 282 326 minecraft:andesite
fill 128 281 360 128 282 360 minecraft:andesite
fill 132 281 330 132 282 330 minecraft:andesite
fill 132 281 356 132 282 356 minecraft:andesite
setblock 133 281 331 minecraft:andesite
setblock 133 281 355 minecraft:andesite
fill 134 281 333 134 282 333 minecraft:andesite
fill 134 281 353 134 282 353 minecraft:andesite
fill 135 281 334 135 281 352 minecraft:andesite
fill 95 282 335 95 282 351 minecraft:andesite
setblock 96 282 334 minecraft:andesite
fill 96 282 335 105 282 351 minecraft:stone
setblock 96 282 352 minecraft:andesite
setblock 97 282 325 minecraft:light[level=15]
setblock 97 282 332 minecraft:andesite
fill 97 282 334 133 282 334 minecraft:stone
fill 97 282 352 133 282 352 minecraft:stone
setblock 97 282 354 minecraft:andesite
setblock 97 282 357 minecraft:light[level=15]
setblock 97 282 360 minecraft:light[level=12]
fill 98 282 331 98 283 331 minecraft:andesite
fill 98 282 332 132 282 332 minecraft:stone
fill 98 282 354 132 282 354 minecraft:stone
fill 98 282 355 98 283 355 minecraft:andesite
setblock 99 282 329 minecraft:andesite
fill 99 282 331 131 283 331 minecraft:stone
fill 99 282 355 131 283 355 minecraft:stone
setblock 99 282 357 minecraft:andesite
setblock 100 282 328 minecraft:andesite
fill 100 282 329 108 282 329 minecraft:stone
fill 100 282 357 108 282 357 minecraft:stone
setblock 100 282 358 minecraft:andesite
setblock 101 282 327 minecraft:andesite
fill 101 282 328 108 282 328 minecraft:stone
fill 101 282 358 108 282 358 minecraft:stone
setblock 101 282 359 minecraft:andesite
fill 102 282 327 128 282 327 minecraft:stone
fill 102 282 359 128 282 359 minecraft:stone
fill 103 282 326 103 283 326 minecraft:andesite
fill 103 282 360 103 283 360 minecraft:andesite
setblock 104 282 325 minecraft:andesite
fill 104 282 326 126 282 326 minecraft:stone
fill 104 282 360 126 282 360 minecraft:stone
setblock 104 282 361 minecraft:andesite
fill 105 282 325 125 282 325 minecraft:stone
fill 105 282 361 125 282 361 minecraft:stone
setblock 106 282 324 minecraft:andesite
fill 106 282 335 106 282 342 minecraft:stone
fill 106 282 343 106 282 344 minecraft:spruce_planks
fill 106 282 345 106 282 351 minecraft:stone
setblock 106 282 362 minecraft:andesite
fill 107 282 323 123 282 323 minecraft:andesite
fill 107 282 324 123 282 324 minecraft:stone
fill 107 282 335 107 282 340 minecraft:stone
fill 107 282 341 107 282 342 minecraft:spruce_planks
fill 107 282 345 107 282 347 minecraft:spruce_planks
fill 107 282 348 107 283 351 minecraft:stone
fill 107 282 362 123 282 362 minecraft:stone
fill 107 282 363 123 282 363 minecraft:andesite
fill 108 282 335 108 282 339 minecraft:stone
setblock 108 282 340 minecraft:spruce_planks
setblock 108 282 348 minecraft:spruce_planks
fill 108 282 349 108 283 351 minecraft:stone
fill 109 282 335 109 282 338 minecraft:stone
setblock 109 282 339 minecraft:spruce_planks
fill 109 282 349 110 282 349 minecraft:spruce_planks
fill 109 282 350 110 282 351 minecraft:stone
fill 110 282 335 111 282 337 minecraft:stone
fill 110 282 338 111 282 338 minecraft:spruce_planks
setblock 111 282 339 minecraft:light[level=12]
setblock 111 282 346 minecraft:light[level=12]
fill 111 282 350 115 282 350 minecraft:spruce_planks
fill 111 282 351 134 282 351 minecraft:stone
fill 112 282 328 129 282 329 minecraft:stone
fill 112 282 335 134 282 336 minecraft:stone
fill 112 282 337 114 282 337 minecraft:spruce_planks
fill 112 282 357 129 282 358 minecraft:stone
setblock 113 282 341 minecraft:light[level=15]
setblock 113 282 349 minecraft:light[level=15]
fill 115 282 337 134 282 337 minecraft:stone
fill 115 282 338 117 282 338 minecraft:spruce_planks
fill 116 282 349 117 282 349 minecraft:spruce_planks
fill 116 282 350 134 282 350 minecraft:stone
fill 117 282 339 118 282 339 minecraft:spruce_planks
fill 118 282 338 134 282 338 minecraft:stone
fill 118 282 340 119 282 340 minecraft:spruce_planks
setblock 118 282 346 minecraft:light[level=12]
fill 118 282 347 118 282 348 minecraft:spruce_planks
fill 118 282 349 134 282 349 minecraft:stone
fill 119 282 339 134 282 339 minecraft:stone
fill 119 282 341 119 282 347 minecraft:spruce_planks
fill 119 282 348 134 282 348 minecraft:stone
fill 120 282 340 134 282 342 minecraft:stone
fill 120 282 343 120 282 344 minecraft:spruce_planks
fill 120 282 345 134 282 347 minecraft:stone
fill 121 282 343 134 282 344 minecraft:stone
setblock 124 282 324 minecraft:andesite
setblock 124 282 362 minecraft:andesite
setblock 126 282 325 minecraft:andesite
setblock 126 282 361 minecraft:andesite
fill 127 282 326 127 283 326 minecraft:andesite
fill 127 282 360 127 283 360 minecraft:andesite
setblock 129 282 325 minecraft:light[level=15]
setblock 129 282 327 minecraft:andesite
setblock 129 282 359 minecraft:andesite
setblock 130 282 328 minecraft:andesite
setblock 130 282 329 minecraft:stone
setblock 130 282 357 minecraft:stone
setblock 130 282 358 minecraft:andesite
setblock 131 282 329 minecraft:andesite
setblock 131 282 357 minecraft:andesite
setblock 132 282 325 minecraft:light[level=12]
fill 132 282 331 132 283 331 minecraft:andesite
fill 132 282 355 132 283 355 minecraft:andesite
setblock 132 282 360 minecraft:light[level=12]
setblock 133 282 332 minecraft:andesite
setblock 133 282 354 minecraft:andesite
setblock 134 282 334 minecraft:andesite
setblock 134 282 352 minecraft:andesite
fill 135 282 335 135 282 351 minecraft:andesite
fill 136 282 358 136 292 358 minecraft:stone
setblock 136 282 359 minecraft:gold_block
fill 136 282 360 136 308 360 minecraft:stone
fill 95 283 324 95 283 326 minecraft:stone
setblock 95 283 327 minecraft:stripped_spruce_log
fill 95 283 328 95 284 330 minecraft:stone
fill 95 283 337 95 283 349 minecraft:andesite
fill 95 283 350 95 283 351 minecraft:stone
setblock 95 283 352 minecraft:stripped_spruce_log
fill 95 283 353 95 283 356 minecraft:stone
setblock 95 283 357 minecraft:stripped_spruce_log
fill 95 283 358 95 283 360 minecraft:stone
setblock 95 283 363 minecraft:stone
fill 96 283 324 96 286 324 minecraft:spruce_log
fill 96 283 335 96 283 336 minecraft:andesite
fill 96 283 337 105 283 349 minecraft:stone
fill 96 283 350 96 283 351 minecraft:andesite
fill 96 283 352 96 283 355 minecraft:stone
fill 96 283 362 96 286 362 minecraft:spruce_log
fill 97 283 333 97 283 334 minecraft:andesite
fill 97 283 335 111 283 336 minecraft:stone
fill 97 283 350 106 283 351 minecraft:stone
fill 97 283 352 97 283 353 minecraft:andesite
fill 98 283 326 98 290 326 minecraft:cobbled_deepslate
fill 98 283 332 98 284 332 minecraft:andesite
fill 98 283 333 132 283 334 minecraft:stone
fill 98 283 352 132 283 353 minecraft:stone
fill 98 283 354 98 284 354 minecraft:andesite
setblock 99 283 330 minecraft:andesite
fill 99 283 332 131 284 332 minecraft:stone
fill 99 283 354 131 284 354 minecraft:stone
setblock 99 283 356 minecraft:andesite
setblock 100 283 329 minecraft:andesite
fill 100 283 330 130 283 330 minecraft:stone
fill 100 283 356 130 283 356 minecraft:stone
setblock 100 283 357 minecraft:andesite
setblock 101 283 328 minecraft:andesite
fill 101 283 329 108 283 329 minecraft:stone
fill 101 283 357 108 283 357 minecraft:stone
setblock 101 283 358 minecraft:andesite
fill 102 283 323 103 283 323 minecraft:stone
setblock 102 283 327 minecraft:andesite
fill 102 283 328 108 283 328 minecraft:stone
fill 102 283 358 108 283 358 minecraft:stone
setblock 102 283 359 minecraft:andesite
fill 103 283 327 127 283 327 minecraft:stone
fill 103 283 359 127 283 359 minecraft:stone
setblock 104 283 323 minecraft:stripped_spruce_log
fill 104 283 324 106 284 324 minecraft:stone
fill 104 283 326 104 284 326 minecraft:andesite
fill 104 283 360 104 284 360 minecraft:andesite
setblock 104 283 363 minecraft:stripped_spruce_log
fill 105 283 323 108 283 323 minecraft:stone
fill 105 283 325 106 283 325 minecraft:andesite
fill 105 283 326 125 283 326 minecraft:stone
fill 105 283 360 125 283 360 minecraft:stone
fill 105 283 361 106 283 361 minecraft:andesite
fill 105 283 363 108 283 363 minecraft:stone
fill 106 283 337 106 283 340 minecraft:stone
fill 106 283 341 106 283 346 minecraft:cobbled_deepslate
fill 106 283 347 106 283 349 minecraft:stone
fill 107 283 324 108 283 324 minecraft:andesite
fill 107 283 325 123 283 325 minecraft:stone
fill 107 283 337 107 283 339 minecraft:stone
setblock 107 283 340 minecraft:cobbled_deepslate
setblock 107 283 347 minecraft:cobbled_deepslate
fill 107 283 361 123 283 361 minecraft:stone
fill 107 283 362 108 283 362 minecraft:andesite
fill 108 283 337 108 283 338 minecraft:stone
setblock 108 283 339 minecraft:cobbled_deepslate
setblock 108 283 348 minecraft:cobbled_deepslate
fill 109 283 323 121 283 323 minecraft:andesite
fill 109 283 324 121 283 324 minecraft:stone
setblock 109 283 337 minecraft:stone
setblock 109 283 338 minecraft:cobbled_deepslate
setblock 109 283 349 minecraft:cobbled_deepslate
fill 109 283 350 109 283 351 minecraft:stone
fill 109 283 362 121 283 362 minecraft:stone
fill 109 283 363 121 283 363 minecraft:andesite
fill 110 283 337 111 283 337 minecraft:cobbled_deepslate
setblock 110 283 350 minecraft:cobbled_deepslate
setblock 110 283 351 minecraft:stone
fill 111 283 351 115 283 351 minecraft:cobbled_deepslate
fill 112 283 328 128 283 329 minecraft:stone
fill 112 283 335 133 283 335 minecraft:stone
fill 112 283 336 114 283 336 minecraft:cobbled_deepslate
fill 112 283 357 128 283 358 minecraft:stone
fill 115 283 336 133 283 336 minecraft:stone
fill 115 283 337 117 283 337 minecraft:cobbled_deepslate
fill 116 283 350 117 283 350 minecraft:cobbled_deepslate
fill 116 283 351 133 283 351 minecraft:stone
setblock 117 283 364 minecraft:raw_iron_block
fill 118 283 337 134 283 337 minecraft:stone
setblock 118 283 338 minecraft:cobbled_deepslate
setblock 118 283 349 minecraft:cobbled_deepslate
fill 118 283 350 133 283 350 minecraft:stone
fill 119 283 338 134 283 338 minecraft:stone
setblock 119 283 339 minecraft:cobbled_deepslate
setblock 119 283 348 minecraft:cobbled_deepslate
fill 119 283 349 134 283 349 minecraft:stone
fill 120 283 339 134 283 339 minecraft:stone
fill 120 283 340 120 283 342 minecraft:cobbled_deepslate
fill 120 283 345 120 283 347 minecraft:cobbled_deepslate
fill 120 283 348 134 283 348 minecraft:stone
fill 121 283 340 134 283 342 minecraft:stone
fill 121 283 343 121 283 344 minecraft:cobbled_deepslate
fill 121 283 345 134 283 347 minecraft:stone
fill 122 283 323 123 283 323 minecraft:stone
fill 122 283 324 123 283 324 minecraft:andesite
fill 122 283 343 134 283 344 minecraft:stone
fill 122 283 362 123 283 362 minecraft:andesite
fill 122 283 363 123 283 363 minecraft:stone
fill 123 283 364 123 290 364 minecraft:stone
setblock 124 283 323 minecraft:stripped_spruce_log
fill 124 283 324 127 283 324 minecraft:stone
fill 124 283 325 125 283 325 minecraft:andesite
fill 124 283 361 125 283 361 minecraft:andesite
setblock 124 283 363 minecraft:stripped_spruce_log
fill 125 283 323 128 283 323 minecraft:stone
setblock 125 283 362 minecraft:stripped_spruce_log
fill 125 283 363 128 283 363 minecraft:stone
setblock 126 283 325 minecraft:stone
fill 126 283 326 126 284 326 minecraft:andesite
fill 126 283 360 126 284 360 minecraft:andesite
fill 126 283 362 129 283 362 minecraft:stone
setblock 126 283 364 minecraft:gold_block
setblock 127 283 325 minecraft:stripped_spruce_log
fill 127 283 361 129 284 361 minecraft:raw_gold_block
setblock 128 283 324 minecraft:stripped_spruce_log
fill 128 283 325 130 283 326 minecraft:stone
setblock 128 283 327 minecraft:andesite
setblock 128 283 359 minecraft:andesite
fill 128 283 360 128 284 360 minecraft:raw_gold_block
setblock 129 283 323 minecraft:stripped_spruce_log
fill 129 283 324 132 283 324 minecraft:stone
setblock 129 283 328 minecraft:andesite
setblock 129 283 329 minecraft:stone
setblock 129 283 357 minecraft:stone
setblock 129 283 358 minecraft:andesite
setblock 129 283 363 minecraft:stripped_spruce_log
fill 130 283 323 133 283 323 minecraft:stone
setblock 130 283 329 minecraft:andesite
setblock 130 283 357 minecraft:andesite
setblock 130 283 362 minecraft:stripped_spruce_log
fill 130 283 363 133 283 363 minecraft:stone
setblock 131 283 325 minecraft:stone
setblock 131 283 326 minecraft:stripped_spruce_log
setblock 131 283 330 minecraft:andesite
setblock 131 283 356 minecraft:andesite
fill 131 283 362 133 284 362 minecraft:stone
setblock 132 283 325 minecraft:stripped_spruce_log
fill 132 283 332 132 284 332 minecraft:andesite
fill 132 283 354 132 284 354 minecraft:andesite
setblock 133 283 324 minecraft:stripped_spruce_log
fill 133 283 325 133 283 328 minecraft:stone
fill 133 283 333 133 283 334 minecraft:andesite
fill 133 283 352 133 283 353 minecraft:andesite
fill 133 283 354 133 284 355 minecraft:raw_gold_block
setblock 134 283 323 minecraft:stripped_spruce_log
fill 134 283 324 134 286 324 minecraft:spruce_log
fill 134 283 325 134 283 327 minecraft:stone
setblock 134 283 328 minecraft:stripped_spruce_log
fill 134 283 329 135 284 330 minecraft:stone
fill 134 283 335 134 283 336 minecraft:andesite
fill 134 283 350 134 283 351 minecraft:andesite
setblock 134 283 352 minecraft:stone
setblock 134 283 353 minecraft:stripped_spruce_log
fill 134 283 354 135 283 356 minecraft:stone
fill 134 283 362 134 286 362 minecraft:spruce_log
setblock 134 283 363 minecraft:stripped_spruce_log
fill 135 283 323 135 283 326 minecraft:stone
setblock 135 283 327 minecraft:stripped_spruce_log
fill 135 283 328 135 286 328 minecraft:stone
setblock 135 283 331 minecraft:stone
fill 135 283 337 135 283 349 minecraft:andesite
fill 135 283 350 135 283 351 minecraft:stone
setblock 135 283 352 minecraft:stripped_spruce_log
fill 135 283 353 135 286 353 minecraft:stone
setblock 135 283 357 minecraft:stripped_spruce_log
fill 135 283 358 135 283 361 minecraft:stone
setblock 135 283 362 minecraft:stripped_spruce_log
fill 135 283 363 135 285 363 minecraft:stone
fill 136 283 359 136 308 359 minecraft:stone
setblock 94 284 325 minecraft:diamond_block
setblock 94 284 334 minecraft:gold_block
setblock 94 284 338 minecraft:raw_gold_block
fill 94 284 339 94 308 339 minecraft:stone
setblock 95 284 325 minecraft:stone
setblock 95 284 326 minecraft:stripped_spruce_log
fill 95 284 327 95 285 327 minecraft:stone
fill 95 284 340 95 284 346 minecraft:andesite
fill 95 284 347 95 284 350 minecraft:stone
setblock 95 284 351 minecraft:stripped_spruce_log
fill 95 284 352 95 284 355 minecraft:stone
setblock 95 284 356 minecraft:stripped_spruce_log
fill 95 284 357 95 284 359 minecraft:stone
fill 96 284 336 96 284 339 minecraft:andesite
fill 96 284 340 104 284 346 minecraft:stone
fill 96 284 347 96 284 350 minecraft:andesite
fill 96 284 351 96 284 354 minecraft:stone
setblock 96 284 355 minecraft:stripped_spruce_log
fill 97 284 334 97 284 335 minecraft:andesite
fill 97 284 336 106 284 339 minecraft:stone
fill 97 284 347 105 284 350 minecraft:stone
fill 97 284 351 97 284 352 minecraft:andesite
setblock 98 284 333 minecraft:andesite
fill 98 284 334 112 284 335 minecraft:stone
fill 98 284 351 109 284 352 minecraft:stone
setblock 98 284 353 minecraft:andesite
setblock 99 284 331 minecraft:andesite
fill 99 284 333 131 284 333 minecraft:stone
fill 99 284 353 131 284 353 minecraft:stone
setblock 99 284 355 minecraft:andesite
setblock 100 284 330 minecraft:andesite
fill 100 284 331 130 284 331 minecraft:stone
fill 100 284 355 130 284 355 minecraft:stone
setblock 100 284 356 minecraft:andesite
setblock 101 284 329 minecraft:andesite
fill 101 284 330 129 284 330 minecraft:stone
fill 101 284 356 129 284 356 minecraft:stone
setblock 101 284 357 minecraft:andesite
setblock 102 284 323 minecraft:stone
setblock 102 284 328 minecraft:andesite
fill 102 284 329 108 284 329 minecraft:stone
fill 102 284 357 108 284 357 minecraft:stone
setblock 102 284 358 minecraft:andesite
setblock 103 284 323 minecraft:stripped_spruce_log
setblock 103 284 327 minecraft:andesite
fill 103 284 328 108 284 328 minecraft:stone
fill 103 284 358 108 284 358 minecraft:stone
setblock 103 284 359 minecraft:andesite
fill 104 284 323 107 284 323 minecraft:stone
fill 104 284 327 126 284 327 minecraft:stone
fill 104 284 359 126 284 359 minecraft:stone
setblock 105 284 326 minecraft:andesite
fill 105 284 340 105 284 342 minecraft:stone
fill 105 284 343 105 284 344 minecraft:cobbled_deepslate
fill 105 284 345 105 284 346 minecraft:stone
setblock 105 284 360 minecraft:andesite
fill 105 284 363 107 284 363 minecraft:stone
fill 106 284 325 107 284 325 minecraft:andesite
fill 106 284 326 124 284 326 minecraft:stone
fill 106 284 340 106 284 342 minecraft:cobbled_deepslate
fill 106 284 345 106 284 347 minecraft:cobbled_deepslate
fill 106 284 348 106 284 350 minecraft:stone
fill 106 284 360 124 284 360 minecraft:stone
fill 106 284 361 107 284 361 minecraft:andesite
setblock 107 284 324 minecraft:stripped_spruce_log
fill 107 284 336 107 284 338 minecraft:stone
setblock 107 284 339 minecraft:cobbled_deepslate
setblock 107 284 348 minecraft:cobbled_deepslate
fill 107 284 349 107 284 350 minecraft:stone
setblock 108 284 323 minecraft:stripped_spruce_log
fill 108 284 324 111 284 324 minecraft:andesite
fill 108 284 325 122 284 325 minecraft:stone
fill 108 284 336 108 284 337 minecraft:stone
setblock 108 284 338 minecraft:cobbled_deepslate
setblock 108 284 349 minecraft:cobbled_deepslate
setblock 108 284 350 minecraft:stone
fill 108 284 361 122 284 361 minecraft:stone
fill 108 284 362 111 284 362 minecraft:andesite
setblock 108 284 363 minecraft:stripped_spruce_log
setblock 108 284 364 minecraft:diamond_block
fill 109 284 323 111 285 323 minecraft:stone
setblock 109 284 336 minecraft:stone
setblock 109 284 337 minecraft:cobbled_deepslate
setblock 109 284 350 minecraft:cobbled_deepslate
setblock 109 284 363 minecraft:stone
fill 110 284 336 112 284 336 minecraft:cobbled_deepslate
fill 110 284 351 112 284 351 minecraft:cobbled_deepslate
fill 110 284 352 112 284 352 minecraft:stone
fill 112 284 323 118 284 323 minecraft:andesite
fill 112 284 324 118 284 324 minecraft:stone
fill 112 284 328 127 284 329 minecraft:stone
fill 112 284 357 127 284 358 minecraft:stone
fill 112 284 362 118 284 362 minecraft:stone
fill 112 284 363 118 284 363 minecraft:andesite
fill 113 284 334 132 284 334 minecraft:stone
fill 113 284 335 114 284 335 minecraft:cobbled_deepslate
fill 113 284 352 114 284 352 minecraft:cobbled_deepslate
fill 115 284 335 132 284 335 minecraft:stone
fill 115 284 336 117 284 336 minecraft:cobbled_deepslate
fill 115 284 351 117 284 351 minecraft:cobbled_deepslate
fill 115 284 352 132 284 352 minecraft:stone
fill 117 284 364 117 292 364 minecraft:stone
setblock 118 284 322 minecraft:diamond_block
fill 118 284 336 133 284 336 minecraft:stone
fill 118 284 337 119 284 337 minecraft:cobbled_deepslate
setblock 118 284 350 minecraft:cobbled_deepslate
fill 118 284 351 132 284 351 minecraft:stone
fill 119 284 323 122 284 323 minecraft:stone
fill 119 284 324 122 284 324 minecraft:andesite
fill 119 284 338 120 284 338 minecraft:cobbled_deepslate
fill 119 284 349 120 284 349 minecraft:cobbled_deepslate
fill 119 284 350 133 284 350 minecraft:stone
fill 119 284 362 122 284 362 minecraft:andesite
fill 120 284 337 133 284 337 minecraft:stone
setblock 120 284 339 minecraft:cobbled_deepslate
setblock 120 284 348 minecraft:cobbled_deepslate
fill 121 284 338 133 284 339 minecraft:stone
fill 121 284 340 121 284 342 minecraft:cobbled_deepslate
fill 121 284 345 121 284 347 minecraft:cobbled_deepslate
fill 121 284 348 133 284 349 minecraft:stone
fill 122 284 340 134 284 341 minecraft:stone
fill 122 284 342 122 284 345 minecraft:cobbled_deepslate
fill 122 284 346 133 284 347 minecraft:stone
setblock 122 284 363 minecraft:stone
setblock 123 284 323 minecraft:stripped_spruce_log
fill 123 284 324 126 284 324 minecraft:stone
fill 123 284 325 124 284 325 minecraft:andesite
fill 123 284 342 134 284 345 minecraft:stone
fill 123 284 361 124 284 361 minecraft:andesite
setblock 123 284 363 minecraft:stripped_spruce_log
fill 124 284 323 127 284 323 minecraft:stone
fill 124 284 363 127 284 363 minecraft:stone
setblock 125 284 325 minecraft:stone
setblock 125 284 326 minecraft:andesite
setblock 125 284 360 minecraft:andesite
fill 125 284 362 128 284 362 minecraft:stone
setblock 126 284 325 minecraft:stripped_spruce_log
fill 126 284 364 126 303 364 minecraft:stone
setblock 127 284 324 minecraft:stripped_spruce_log
fill 127 284 325 129 284 326 minecraft:stone
setblock 127 284 327 minecraft:andesite
setblock 127 284 359 minecraft:andesite
setblock 128 284 323 minecraft:stripped_spruce_log
fill 128 284 324 131 284 324 minecraft:stone
setblock 128 284 328 minecraft:andesite
setblock 128 284 329 minecraft:stone
setblock 128 284 357 minecraft:stone
setblock 128 284 358 minecraft:andesite
setblock 128 284 359 minecraft:raw_gold_block
setblock 128 284 363 minecraft:stripped_spruce_log
fill 129 284 323 132 284 323 minecraft:stone
setblock 129 284 329 minecraft:andesite
setblock 129 284 357 minecraft:andesite
setblock 129 284 362 minecraft:stripped_spruce_log
fill 129 284 363 132 284 363 minecraft:stone
setblock 130 284 325 minecraft:stone
setblock 130 284 326 minecraft:stripped_spruce_log
setblock 130 284 330 minecraft:andesite
setblock 130 284 356 minecraft:andesite
fill 130 284 362 130 287 362 minecraft:stone
setblock 131 284 325 minecraft:stripped_spruce_log
setblock 131 284 326 minecraft:stone
setblock 131 284 331 minecraft:andesite
setblock 131 284 355 minecraft:andesite
setblock 132 284 324 minecraft:stripped_spruce_log
fill 132 284 325 135 284 325 minecraft:stone
fill 132 284 327 132 290 327 minecraft:cobbled_deepslate
setblock 132 284 333 minecraft:andesite
setblock 132 284 353 minecraft:andesite
setblock 132 284 355 minecraft:raw_gold_block
setblock 133 284 323 minecraft:stripped_spruce_log
fill 133 284 324 133 285 324 minecraft:stone
fill 133 284 326 133 284 327 minecraft:stone
fill 133 284 334 133 284 335 minecraft:andesite
fill 133 284 351 133 284 352 minecraft:andesite
setblock 133 284 353 minecraft:raw_gold_block
setblock 133 284 363 minecraft:stripped_spruce_log
fill 134 284 323 135 285 323 minecraft:stone
setblock 134 284 326 minecraft:stone
setblock 134 284 327 minecraft:stripped_spruce_log
fill 134 284 328 134 285 328 minecraft:stone
fill 134 284 336 134 284 339 minecraft:andesite
setblock 134 284 346 minecraft:stone
fill 134 284 347 134 284 350 minecraft:andesite
setblock 134 284 351 minecraft:stone
setblock 134 284 352 minecraft:stripped_spruce_log
fill 134 284 353 134 284 356 minecraft:stone
setblock 134 284 357 minecraft:stripped_spruce_log
fill 134 284 363 134 286 363 minecraft:stone
setblock 135 284 322 minecraft:raw_iron_block
fill 135 284 324 135 285 324 minecraft:stone
setblock 135 284 326 minecraft:stripped_spruce_log
fill 135 284 327 135 286 327 minecraft:stone
setblock 135 284 331 minecraft:stripped_spruce_log
fill 135 284 340 135 284 346 minecraft:andesite
fill 135 284 347 135 284 350 minecraft:stone
setblock 135 284 351 minecraft:stripped_spruce_log
fill 135 284 352 135 287 352 minecraft:stone
fill 135 284 354 135 284 355 minecraft:stone
setblock 135 284 356 minecraft:stripped_spruce_log
fill 135 284 357 135 284 360 minecraft:stone
setblock 135 284 361 minecraft:stripped_spruce_log
fill 135 284 362 135 285 362 minecraft:stone
fill 136 284 322 136 308 322 minecraft:stone
fill 94 285 325 94 300 325 minecraft:stone
fill 94 285 334 94 308 334 minecraft:stone
setblock 94 285 338 minecraft:stone
fill 95 285 328 95 285 329 minecraft:stone
setblock 95 285 330 minecraft:stripped_spruce_log
setblock 95 285 331 minecraft:stone
setblock 95 285 344 minecraft:stone
setblock 95 285 345 minecraft:stripped_spruce_log
fill 95 285 346 95 285 349 minecraft:stone
setblock 95 285 350 minecraft:stripped_spruce_log
fill 95 285 351 95 285 354 minecraft:stone
setblock 95 285 355 minecraft:stripped_spruce_log
fill 95 285 356 95 286 358 minecraft:stone
fill 96 285 339 96 285 347 minecraft:andesite
setblock 96 285 348 minecraft:stone
setblock 96 285 349 minecraft:stripped_spruce_log
fill 96 285 350 96 285 353 minecraft:stone
setblock 96 285 354 minecraft:stripped_spruce_log
fill 96 285 355 96 288 355 minecraft:stone
fill 97 285 336 97 285 338 minecraft:andesite
fill 97 285 339 104 285 347 minecraft:stone
fill 97 285 348 97 285 350 minecraft:andesite
fill 97 285 351 97 285 352 minecraft:stone
fill 98 285 334 98 285 335 minecraft:andesite
fill 98 285 336 106 285 338 minecraft:stone
fill 98 285 348 105 285 350 minecraft:stone
fill 98 285 351 98 285 352 minecraft:andesite
fill 99 285 332 99 285 333 minecraft:andesite
fill 99 285 334 109 285 335 minecraft:stone
fill 99 285 351 108 285 352 minecraft:stone
fill 99 285 353 99 285 354 minecraft:andesite
setblock 100 285 331 minecraft:andesite
fill 100 285 332 130 285 333 minecraft:stone
fill 100 285 353 130 285 354 minecraft:stone
setblock 100 285 355 minecraft:andesite
setblock 101 285 330 minecraft:andesite
fill 101 285 331 129 285 331 minecraft:stone
fill 101 285 355 129 285 355 minecraft:stone
setblock 101 285 356 minecraft:andesite
setblock 102 285 323 minecraft:stripped_spruce_log
setblock 102 285 329 minecraft:andesite
fill 102 285 330 128 285 330 minecraft:stone
fill 102 285 356 128 285 356 minecraft:stone
setblock 102 285 357 minecraft:andesite
fill 103 285 323 106 285 323 minecraft:stone
setblock 103 285 328 minecraft:andesite
fill 103 285 329 108 285 329 minecraft:stone
fill 103 285 357 108 285 357 minecraft:stone
setblock 103 285 358 minecraft:andesite
fill 104 285 324 105 285 324 minecraft:stone
fill 104 285 327 105 285 327 minecraft:andesite
fill 104 285 328 108 285 328 minecraft:stone
fill 104 285 358 108 285 358 minecraft:stone
fill 104 285 359 105 285 359 minecraft:andesite
fill 105 285 339 105 285 340 minecraft:stone
fill 105 285 341 105 285 346 minecraft:spruce_planks
setblock 105 285 347 minecraft:stone
fill 105 285 363 106 285 363 minecraft:stone
setblock 105 285 364 minecraft:gold_block
setblock 106 285 324 minecraft:stripped_spruce_log
fill 106 285 325 107 285 325 minecraft:stone
fill 106 285 326 107 285 326 minecraft:andesite
fill 106 285 327 124 285 327 minecraft:stone
fill 106 285 339 106 285 340 minecraft:spruce_planks
fill 106 285 347 106 285 348 minecraft:spruce_planks
fill 106 285 349 106 285 350 minecraft:stone
fill 106 285 359 124 285 359 minecraft:stone
fill 106 285 360 107 285 360 minecraft:andesite
setblock 107 285 323 minecraft:stripped_spruce_log
fill 107 285 324 110 285 324 minecraft:stone
fill 107 285 336 107 285 337 minecraft:stone
setblock 107 285 338 minecraft:spruce_planks
setblock 107 285 349 minecraft:spruce_planks
setblock 107 285 350 minecraft:stone
setblock 107 285 363 minecraft:stripped_spruce_log
setblock 108 285 322 minecraft:raw_gold_block
fill 108 285 323 108 288 323 minecraft:stone
fill 108 285 325 110 285 325 minecraft:andesite
fill 108 285 326 122 285 326 minecraft:stone
setblock 108 285 336 minecraft:stone
setblock 108 285 337 minecraft:spruce_planks
setblock 108 285 350 minecraft:spruce_planks
fill 108 285 360 122 285 360 minecraft:stone
fill 108 285 361 110 285 361 minecraft:andesite
fill 108 285 363 108 285 364 minecraft:stone
setblock 109 285 336 minecraft:spruce_planks
fill 109 285 351 110 285 351 minecraft:spruce_planks
fill 109 285 352 110 285 352 minecraft:stone
fill 110 285 334 131 285 334 minecraft:stone
fill 110 285 335 117 285 335 minecraft:spruce_planks
fill 111 285 324 119 285 324 minecraft:andesite
fill 111 285 325 119 285 325 minecraft:stone
fill 111 285 352 117 285 352 minecraft:spruce_planks
fill 111 285 361 119 285 361 minecraft:stone
fill 111 285 362 119 285 362 minecraft:andesite
setblock 112 285 323 minecraft:stripped_spruce_log
fill 112 285 328 126 285 329 minecraft:stone
fill 112 285 357 126 285 358 minecraft:stone
fill 113 285 323 116 285 323 minecraft:stone
setblock 116 285 322 minecraft:gold_block
setblock 117 285 323 minecraft:stripped_spruce_log
fill 118 285 322 118 288 323 minecraft:stone
fill 118 285 335 131 285 335 minecraft:stone
fill 118 285 336 119 285 336 minecraft:spruce_planks
fill 118 285 351 119 285 351 minecraft:spruce_planks
fill 118 285 352 131 285 352 minecraft:stone
fill 119 285 323 121 285 323 minecraft:stone
fill 119 285 350 120 285 350 minecraft:spruce_planks
setblock 120 285 324 minecraft:stone
fill 120 285 325 122 285 325 minecraft:andesite
fill 120 285 336 132 285 336 minecraft:stone
setblock 120 285 337 minecraft:spruce_planks
fill 120 285 351 131 285 351 minecraft:stone
fill 120 285 361 122 285 361 minecraft:andesite
fill 120 285 362 120 286 362 minecraft:cobbled_deepslate
setblock 121 285 324 minecraft:stripped_spruce_log
fill 121 285 337 132 285 337 minecraft:stone
fill 121 285 338 121 285 339 minecraft:spruce_planks
fill 121 285 348 121 285 349 minecraft:spruce_planks
fill 121 285 350 132 285 350 minecraft:stone
setblock 122 285 323 minecraft:stripped_spruce_log
fill 122 285 324 125 285 324 minecraft:stone
fill 122 285 338 132 285 338 minecraft:stone
fill 122 285 339 122 285 341 minecraft:spruce_planks
fill 122 285 346 122 285 347 minecraft:spruce_planks
fill 122 285 348 132 285 349 minecraft:stone
setblock 122 285 363 minecraft:stripped_spruce_log
fill 123 285 323 126 285 323 minecraft:stone
fill 123 285 325 124 285 325 minecraft:stone
fill 123 285 326 124 285 326 minecraft:andesite
fill 123 285 339 133 285 341 minecraft:stone
fill 123 285 342 123 285 345 minecraft:spruce_planks
fill 123 285 346 133 285 347 minecraft:stone
fill 123 285 360 124 285 360 minecraft:andesite
fill 123 285 363 126 285 363 minecraft:stone
fill 124 285 342 133 285 345 minecraft:stone
fill 124 285 362 127 285 362 minecraft:stone
setblock 125 285 325 minecraft:stripped_spruce_log
fill 125 285 326 128 285 326 minecraft:stone
fill 125 285 327 126 285 327 minecraft:andesite
fill 125 285 359 126 285 359 minecraft:andesite
setblock 126 285 324 minecraft:stripped_spruce_log
fill 126 285 325 129 285 325 minecraft:stone
setblock 127 285 323 minecraft:stripped_spruce_log
fill 127 285 324 130 285 324 minecraft:stone
setblock 127 285 328 minecraft:andesite
setblock 127 285 329 minecraft:stone
setblock 127 285 357 minecraft:stone
setblock 127 285 358 minecraft:andesite
setblock 127 285 363 minecraft:stripped_spruce_log
fill 128 285 323 131 285 323 minecraft:stone
setblock 128 285 329 minecraft:andesite
setblock 128 285 357 minecraft:andesite
setblock 128 285 362 minecraft:stripped_spruce_log
fill 128 285 363 131 285 363 minecraft:stone
setblock 129 285 322 minecraft:gold_block
setblock 129 285 326 minecraft:stripped_spruce_log
setblock 129 285 330 minecraft:andesite
setblock 129 285 356 minecraft:andesite
fill 129 285 362 129 288 362 minecraft:stone
setblock 130 285 325 minecraft:stripped_spruce_log
setblock 130 285 331 minecraft:andesite
setblock 130 285 355 minecraft:andesite
setblock 131 285 324 minecraft:stripped_spruce_log
setblock 131 285 325 minecraft:stone
fill 131 285 332 131 285 333 minecraft:andesite
fill 131 285 353 131 285 354 minecraft:andesite
fill 131 285 362 132 285 362 minecraft:stone
setblock 132 285 323 minecraft:stripped_spruce_log
fill 132 285 324 132 286 324 minecraft:stone
fill 132 285 334 132 285 335 minecraft:andesite
fill 132 285 351 132 285 352 minecraft:andesite
setblock 132 285 363 minecraft:stripped_spruce_log
fill 133 285 323 133 286 323 minecraft:stone
fill 133 285 336 133 285 338 minecraft:andesite
fill 133 285 348 133 285 350 minecraft:andesite
setblock 133 285 352 minecraft:stripped_spruce_log
fill 133 285 363 133 287 363 minecraft:stone
setblock 134 285 325 minecraft:stone
setblock 134 285 326 minecraft:stripped_spruce_log
setblock 134 285 327 minecraft:stone
fill 134 285 329 135 285 329 minecraft:stone
fill 134 285 339 134 285 347 minecraft:andesite
fill 134 285 348 134 285 350 minecraft:stone
setblock 134 285 351 minecraft:stripped_spruce_log
fill 134 285 352 134 285 355 minecraft:stone
setblock 134 285 356 minecraft:stripped_spruce_log
fill 134 285 357 135 286 357 minecraft:stone
fill 135 285 322 135 308 322 minecraft:stone
setblock 135 285 325 minecraft:stripped_spruce_log
fill 135 285 326 135 286 326 minecraft:stone
setblock 135 285 330 minecraft:stripped_spruce_log
fill 135 285 331 135 286 331 minecraft:stone
fill 135 285 346 135 285 349 minecraft:stone
setblock 135 285 350 minecraft:stripped_spruce_log
fill 135 285 351 135 288 351 minecraft:stone
setblock 135 285 354 minecraft:stone
setblock 135 285 355 minecraft:stripped_spruce_log
fill 135 285 356 135 288 356 minecraft:stone
fill 135 285 358 135 285 359 minecraft:stone
setblock 135 285 360 minecraft:stripped_spruce_log
fill 135 285 361 135 286 361 minecraft:stone
setblock 94 286 338 minecraft:diamond_block
setblock 95 286 344 minecraft:stripped_spruce_log
fill 95 286 345 95 286 348 minecraft:stone
setblock 95 286 349 minecraft:stripped_spruce_log
fill 95 286 350 95 286 353 minecraft:stone
setblock 95 286 354 minecraft:stripped_spruce_log
fill 95 286 355 95 288 355 minecraft:stone
setblock 96 286 343 minecraft:spruce_log
setblock 96 286 347 minecraft:stone
setblock 96 286 348 minecraft:stripped_spruce_log
fill 96 286 349 96 286 352 minecraft:stone
setblock 96 286 353 minecraft:stripped_spruce_log
fill 96 286 354 96 288 354 minecraft:stone
fill 97 286 326 97 290 326 minecraft:cobbled_deepslate
fill 97 286 338 97 286 348 minecraft:andesite
fill 97 286 350 97 286 351 minecraft:stone
fill 98 286 325 98 290 325 minecraft:cobbled_deepslate
fill 98 286 327 98 290 327 minecraft:cobbled_deepslate
fill 98 286 335 98 286 337 minecraft:andesite
fill 98 286 338 103 286 348 minecraft:stone
fill 98 286 349 98 286 351 minecraft:andesite
fill 99 286 326 99 290 326 minecraft:cobbled_deepslate
setblock 99 286 334 minecraft:andesite
fill 99 286 335 106 286 337 minecraft:stone
fill 99 286 349 105 286 351 minecraft:stone
setblock 99 286 352 minecraft:andesite
fill 100 286 332 100 286 333 minecraft:andesite
fill 100 286 334 110 286 334 minecraft:stone
fill 100 286 352 108 286 352 minecraft:stone
fill 100 286 353 100 286 354 minecraft:andesite
setblock 101 286 331 minecraft:andesite
fill 101 286 332 129 286 333 minecraft:stone
fill 101 286 353 111 286 354 minecraft:stone
setblock 101 286 355 minecraft:andesite
setblock 102 286 330 minecraft:andesite
fill 102 286 331 128 286 331 minecraft:stone
fill 102 286 355 128 286 355 minecraft:stone
setblock 102 286 356 minecraft:andesite
fill 103 286 323 105 286 323 minecraft:stone
setblock 103 286 329 minecraft:andesite
fill 103 286 330 127 286 330 minecraft:stone
fill 103 286 356 127 286 356 minecraft:stone
setblock 103 286 357 minecraft:andesite
fill 104 286 328 105 286 328 minecraft:andesite
fill 104 286 329 108 286 329 minecraft:stone
fill 104 286 338 104 286 341 minecraft:stone
fill 104 286 342 104 287 344 minecraft:cobbled_deepslate
fill 104 286 345 104 286 348 minecraft:stone
fill 104 286 357 108 286 357 minecraft:stone
fill 104 286 358 105 286 358 minecraft:andesite
setblock 105 286 324 minecraft:stripped_spruce_log
setblock 105 286 338 minecraft:stone
fill 105 286 339 105 286 341 minecraft:cobbled_deepslate
fill 105 286 345 105 286 347 minecraft:cobbled_deepslate
setblock 105 286 348 minecraft:stone
fill 105 286 364 105 289 364 minecraft:stone
setblock 106 286 323 minecraft:stripped_spruce_log
fill 106 286 324 109 286 324 minecraft:stone
setblock 106 286 327 minecraft:andesite
fill 106 286 328 108 286 328 minecraft:stone
setblock 106 286 338 minecraft:cobbled_deepslate
fill 106 286 348 106 286 349 minecraft:cobbled_deepslate
fill 106 286 350 106 286 351 minecraft:stone
fill 106 286 358 108 286 358 minecraft:stone
setblock 106 286 359 minecraft:andesite
fill 107 286 323 107 288 323 minecraft:stone
fill 107 286 325 108 286 325 minecraft:stone
fill 107 286 326 109 286 326 minecraft:andesite
fill 107 286 327 123 286 327 minecraft:stone
fill 107 286 335 107 286 336 minecraft:stone
setblock 107 286 337 minecraft:cobbled_deepslate
setblock 107 286 350 minecraft:cobbled_deepslate
setblock 107 286 351 minecraft:stone
fill 107 286 359 123 286 359 minecraft:stone
fill 107 286 360 109 286 360 minecraft:andesite
fill 108 286 322 108 308 322 minecraft:stone
setblock 108 286 335 minecraft:stone
setblock 108 286 336 minecraft:cobbled_deepslate
fill 108 286 351 108 287 351 minecraft:cobbled_deepslate
fill 108 286 364 108 308 364 minecraft:stone
fill 109 286 323 110 286 323 minecraft:stone
fill 109 286 335 110 286 335 minecraft:cobbled_deepslate
fill 109 286 352 111 286 352 minecraft:cobbled_deepslate
setblock 110 286 324 minecraft:stripped_spruce_log
fill 110 286 325 120 286 325 minecraft:andesite
fill 110 286 326 120 286 326 minecraft:stone
fill 110 286 360 120 286 360 minecraft:stone
fill 110 286 361 120 286 361 minecraft:andesite
setblock 111 286 323 minecraft:stripped_spruce_log
setblock 111 286 324 minecraft:stone
fill 111 286 334 118 286 334 minecraft:cobbled_deepslate
fill 112 286 323 115 286 323 minecraft:stone
fill 112 286 328 124 286 329 minecraft:stone
fill 112 286 353 117 286 353 minecraft:cobbled_deepslate
fill 112 286 354 129 286 354 minecraft:stone
fill 112 286 357 124 286 358 minecraft:stone
setblock 115 286 324 minecraft:spruce_log
setblock 115 286 362 minecraft:spruce_log
fill 116 286 322 116 293 322 minecraft:stone
setblock 116 286 323 minecraft:stripped_spruce_log
setblock 117 286 323 minecraft:stone
fill 118 286 335 120 286 335 minecraft:cobbled_deepslate
fill 118 286 352 119 286 352 minecraft:cobbled_deepslate
fill 118 286 353 129 286 353 minecraft:stone
fill 118 286 362 119 286 362 minecraft:cobbled_deepslate
fill 119 286 323 119 286 324 minecraft:stone
fill 119 286 334 130 286 334 minecraft:stone
setblock 119 286 363 minecraft:cobbled_deepslate
setblock 120 286 323 minecraft:stone
setblock 120 286 324 minecraft:stripped_spruce_log
fill 120 286 336 121 286 336 minecraft:cobbled_deepslate
fill 120 286 348 120 286 349 minecraft:cobbled_deepslate
setblock 120 286 351 minecraft:cobbled_deepslate
fill 120 286 352 130 286 352 minecraft:stone
setblock 121 286 323 minecraft:stripped_spruce_log
fill 121 286 324 123 286 325 minecraft:stone
fill 121 286 326 123 286 326 minecraft:andesite
fill 121 286 335 131 286 335 minecraft:stone
fill 121 286 337 122 286 337 minecraft:cobbled_deepslate
fill 121 286 347 123 286 347 minecraft:cobbled_deepslate
fill 121 286 348 121 300 349 minecraft:stripped_spruce_log
setblock 121 286 350 minecraft:cobbled_deepslate
fill 121 286 351 131 286 351 minecraft:stone
fill 121 286 360 123 286 360 minecraft:andesite
setblock 121 286 361 minecraft:cobbled_deepslate
fill 122 286 323 125 286 323 minecraft:stone
fill 122 286 336 131 286 336 minecraft:stone
setblock 122 286 338 minecraft:cobbled_deepslate
fill 122 286 348 122 286 349 minecraft:cobbled_deepslate
fill 122 286 350 131 286 350 minecraft:stone
fill 122 286 363 125 286 363 minecraft:stone
fill 123 286 337 131 286 338 minecraft:stone
fill 123 286 339 123 286 341 minecraft:cobbled_deepslate
setblock 123 286 346 minecraft:cobbled_deepslate
setblock 123 286 348 minecraft:cobbled_deepslate
fill 123 286 349 131 286 349 minecraft:stone
setblock 124 286 324 minecraft:stone
setblock 124 286 325 minecraft:stripped_spruce_log
fill 124 286 326 127 286 326 minecraft:stone
setblock 124 286 327 minecraft:andesite
fill 124 286 339 132 286 340 minecraft:stone
fill 124 286 341 124 286 345 minecraft:cobbled_deepslate
fill 124 286 346 132 286 348 minecraft:stone
setblock 124 286 359 minecraft:andesite
fill 124 286 362 126 286 362 minecraft:stone
setblock 125 286 324 minecraft:stripped_spruce_log
fill 125 286 325 128 286 325 minecraft:stone
fill 125 286 328 126 286 328 minecraft:andesite
fill 125 286 329 126 286 329 minecraft:stone
fill 125 286 341 132 286 345 minecraft:stone
fill 125 286 357 126 286 357 minecraft:stone
fill 125 286 358 126 286 358 minecraft:andesite
setblock 126 286 323 minecraft:stripped_spruce_log
fill 126 286 324 129 286 324 minecraft:stone
setblock 126 286 363 minecraft:stripped_spruce_log
fill 127 286 323 130 286 323 minecraft:stone
setblock 127 286 329 minecraft:andesite
setblock 127 286 357 minecraft:andesite
setblock 127 286 362 minecraft:stripped_spruce_log
fill 127 286 363 130 286 363 minecraft:stone
setblock 128 286 326 minecraft:stripped_spruce_log
setblock 128 286 330 minecraft:andesite
setblock 128 286 356 minecraft:andesite
fill 128 286 362 128 288 362 minecraft:stone
fill 129 286 322 129 308 322 minecraft:stone
setblock 129 286 325 minecraft:stripped_spruce_log
setblock 129 286 331 minecraft:andesite
setblock 129 286 355 minecraft:andesite
setblock 130 286 324 minecraft:stripped_spruce_log
setblock 130 286 325 minecraft:stone
fill 130 286 332 130 286 333 minecraft:andesite
fill 130 286 353 130 286 354 minecraft:andesite
setblock 131 286 323 minecraft:stripped_spruce_log
setblock 131 286 324 minecraft:stone
setblock 131 286 334 minecraft:andesite
setblock 131 286 352 minecraft:andesite
setblock 131 286 362 minecraft:stone
setblock 131 286 363 minecraft:stripped_spruce_log
fill 132 286 323 132 287 323 minecraft:stone
fill 132 286 335 132 286 337 minecraft:andesite
setblock 132 286 338 minecraft:stone
fill 132 286 349 132 286 351 minecraft:andesite
fill 132 286 363 132 288 363 minecraft:stone
fill 133 286 338 133 286 348 minecraft:andesite
setblock 134 286 323 minecraft:stone
setblock 134 286 343 minecraft:spruce_log
setblock 134 286 349 minecraft:stone
setblock 134 286 350 minecraft:stripped_spruce_log
fill 134 286 351 134 286 354 minecraft:stone
setblock 134 286 355 minecraft:stripped_spruce_log
fill 134 286 356 134 288 356 minecraft:stone
fill 134 286 364 134 292 364 minecraft:stone
setblock 135 286 325 minecraft:stone
setblock 135 286 329 minecraft:stripped_spruce_log
setblock 135 286 330 minecraft:stone
fill 135 286 347 135 286 348 minecraft:stone
setblock 135 286 349 minecraft:stripped_spruce_log
fill 135 286 350 135 288 350 minecraft:stone
setblock 135 286 354 minecraft:stripped_spruce_log
fill 135 286 355 135 288 355 minecraft:stone
setblock 135 286 358 minecraft:stone
setblock 135 286 359 minecraft:stripped_spruce_log
fill 135 286 360 135 287 360 minecraft:stone
setblock 135 286 364 minecraft:gold_block
fill 136 286 364 136 308 364 minecraft:stone
fill 94 287 338 94 308 338 minecraft:stone
setblock 94 287 344 minecraft:raw_gold_block
fill 94 287 345 95 287 345 minecraft:stone
fill 94 287 350 96 287 351 minecraft:stone
setblock 94 287 352 minecraft:raw_gold_block
fill 95 287 346 95 287 347 minecraft:stone
setblock 95 287 348 minecraft:stripped_spruce_log
fill 95 287 349 96 288 349 minecraft:stone
setblock 95 287 352 minecraft:stone
setblock 95 287 353 minecraft:stripped_spruce_log
fill 95 287 354 95 288 354 minecraft:stone
fill 95 287 356 95 287 357 minecraft:stone
setblock 95 287 358 minecraft:stripped_spruce_log
setblock 96 287 324 minecraft:glowstone
setblock 96 287 343 minecraft:glowstone
setblock 96 287 348 minecraft:stone
setblock 96 287 352 minecraft:stripped_spruce_log
fill 96 287 353 96 288 353 minecraft:stone
setblock 96 287 362 minecraft:glowstone
fill 98 287 338 98 287 348 minecraft:andesite
fill 99 287 335 99 287 337 minecraft:andesite
fill 99 287 338 103 287 348 minecraft:stone
fill 99 287 349 99 287 351 minecraft:andesite
fill 100 287 334 100 287 335 minecraft:andesite
fill 100 287 336 105 287 337 minecraft:stone
fill 100 287 349 105 287 350 minecraft:stone
fill 100 287 351 100 287 352 minecraft:andesite
fill 101 287 332 101 287 333 minecraft:andesite
fill 101 287 334 107 287 335 minecraft:stone
fill 101 287 351 106 287 352 minecraft:stone
fill 101 287 353 101 287 354 minecraft:andesite
fill 102 287 331 102 287 332 minecraft:andesite
fill 102 287 333 110 287 333 minecraft:stone
fill 102 287 353 109 287 353 minecraft:stone
fill 102 287 354 102 287 355 minecraft:andesite
fill 103 287 323 104 287 323 minecraft:stone
fill 103 287 330 103 287 331 minecraft:andesite
fill 103 287 332 127 287 332 minecraft:stone
fill 103 287 354 112 287 354 minecraft:stone
fill 103 287 355 103 287 356 minecraft:andesite
setblock 104 287 322 minecraft:raw_gold_block
fill 104 287 329 104 287 330 minecraft:andesite
fill 104 287 331 126 287 331 minecraft:stone
fill 104 287 338 104 287 339 minecraft:stone
fill 104 287 340 104 287 341 minecraft:cobbled_deepslate
fill 104 287 345 104 287 346 minecraft:cobbled_deepslate
fill 104 287 347 104 287 348 minecraft:stone
fill 104 287 355 126 287 355 minecraft:stone
schedule function dropper:buildpart/74_10 1t
