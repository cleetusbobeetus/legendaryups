fill 448 79 306 453 80 306 minecraft:light_gray_concrete
fill 448 79 307 453 80 312 minecraft:glass
fill 448 79 313 453 80 313 minecraft:light_gray_concrete
fill 448 79 314 453 80 316 minecraft:glass
fill 454 79 276 454 80 277 minecraft:light_gray_concrete
fill 454 79 278 454 80 278 minecraft:pearlescent_froglight
fill 454 79 279 454 80 284 minecraft:light_gray_concrete
fill 454 79 285 454 80 285 minecraft:pearlescent_froglight
fill 454 79 286 454 80 291 minecraft:light_gray_concrete
fill 454 79 292 454 80 292 minecraft:pearlescent_froglight
fill 454 79 293 454 80 298 minecraft:light_gray_concrete
fill 454 79 299 454 80 299 minecraft:pearlescent_froglight
fill 454 79 300 454 80 305 minecraft:light_gray_concrete
fill 454 79 306 454 80 306 minecraft:pearlescent_froglight
fill 454 79 307 454 80 312 minecraft:light_gray_concrete
fill 454 79 313 454 80 313 minecraft:pearlescent_froglight
fill 454 79 314 454 80 316 minecraft:light_gray_concrete
fill 455 79 276 460 80 277 minecraft:glass
fill 455 79 278 460 80 278 minecraft:light_gray_concrete
fill 455 79 279 460 80 284 minecraft:glass
fill 455 79 285 460 80 285 minecraft:light_gray_concrete
fill 455 79 286 460 80 291 minecraft:glass
fill 455 79 292 460 80 292 minecraft:light_gray_concrete
fill 455 79 293 460 80 298 minecraft:glass
fill 455 79 299 460 80 299 minecraft:light_gray_concrete
fill 455 79 300 460 80 305 minecraft:glass
fill 455 79 306 460 80 306 minecraft:light_gray_concrete
fill 455 79 307 460 80 312 minecraft:glass
fill 455 79 313 460 80 313 minecraft:light_gray_concrete
fill 455 79 314 460 80 316 minecraft:glass
fill 461 79 276 461 80 277 minecraft:light_gray_concrete
fill 461 79 278 461 80 278 minecraft:pearlescent_froglight
fill 461 79 279 461 80 284 minecraft:light_gray_concrete
fill 461 79 285 461 80 285 minecraft:pearlescent_froglight
fill 461 79 286 461 80 291 minecraft:light_gray_concrete
fill 461 79 292 461 80 292 minecraft:pearlescent_froglight
fill 461 79 293 461 80 298 minecraft:light_gray_concrete
fill 461 79 299 461 80 299 minecraft:pearlescent_froglight
fill 461 79 300 461 80 305 minecraft:light_gray_concrete
fill 461 79 306 461 80 306 minecraft:pearlescent_froglight
fill 461 79 307 461 80 312 minecraft:light_gray_concrete
fill 461 79 313 461 80 313 minecraft:pearlescent_froglight
fill 461 79 314 461 80 316 minecraft:light_gray_concrete
fill 462 79 276 464 80 277 minecraft:glass
fill 462 79 278 464 80 278 minecraft:light_gray_concrete
fill 462 79 279 464 80 284 minecraft:glass
fill 462 79 285 464 80 285 minecraft:light_gray_concrete
fill 462 79 286 464 80 291 minecraft:glass
fill 462 79 292 464 80 292 minecraft:light_gray_concrete
fill 462 79 293 464 80 298 minecraft:glass
fill 462 79 299 464 80 299 minecraft:light_gray_concrete
fill 462 79 300 464 80 305 minecraft:glass
fill 462 79 306 464 80 306 minecraft:light_gray_concrete
fill 462 79 307 464 80 312 minecraft:glass
fill 462 79 313 464 80 313 minecraft:light_gray_concrete
fill 462 79 314 464 80 316 minecraft:glass
fill 427 80 293 430 80 298 minecraft:glass
fill 427 80 299 430 80 299 minecraft:light_gray_concrete
fill 427 80 300 430 80 305 minecraft:glass
fill 431 80 293 431 80 297 minecraft:glass
fill 431 80 298 431 80 300 minecraft:verdant_froglight
fill 431 80 301 431 80 305 minecraft:glass
fill 432 80 293 432 80 295 minecraft:glass
fill 432 80 296 432 80 298 minecraft:verdant_froglight
fill 432 80 300 432 80 302 minecraft:verdant_froglight
fill 432 80 303 432 80 305 minecraft:glass
fill 433 80 293 433 80 295 minecraft:light_gray_concrete
fill 433 80 296 434 80 296 minecraft:verdant_froglight
fill 433 80 302 434 80 302 minecraft:verdant_froglight
fill 433 80 303 433 80 305 minecraft:light_gray_concrete
fill 434 80 293 439 80 294 minecraft:glass
fill 434 80 295 436 80 295 minecraft:verdant_froglight
fill 434 80 303 436 80 303 minecraft:verdant_froglight
fill 434 80 304 439 80 305 minecraft:glass
fill 436 80 296 438 80 296 minecraft:verdant_froglight
fill 436 80 302 438 80 302 minecraft:verdant_froglight
fill 437 80 295 439 80 295 minecraft:glass
fill 437 80 303 439 80 303 minecraft:glass
fill 438 80 297 438 80 298 minecraft:verdant_froglight
fill 438 80 300 438 80 301 minecraft:verdant_froglight
fill 439 80 296 439 80 297 minecraft:glass
fill 439 80 298 439 80 300 minecraft:verdant_froglight
fill 439 80 301 439 80 302 minecraft:glass
fill 435 81 276 437 81 278 minecraft:black_concrete
fill 462 81 284 462 83 284 minecraft:black_concrete
fill 462 81 285 464 81 285 minecraft:gray_concrete
fill 462 81 286 462 83 286 minecraft:black_concrete
setblock 463 81 284 minecraft:gray_concrete
setblock 463 81 286 minecraft:gray_concrete
fill 464 81 284 464 83 284 minecraft:black_concrete
fill 464 81 286 464 83 286 minecraft:black_concrete
fill 435 82 276 435 82 278 minecraft:black_concrete
fill 436 82 276 437 82 276 minecraft:black_concrete
fill 436 82 277 436 84 277 minecraft:gray_concrete
fill 436 82 278 437 82 278 minecraft:black_concrete
setblock 437 82 277 minecraft:black_concrete
fill 462 82 285 462 83 285 minecraft:black_concrete
fill 463 82 284 463 83 284 minecraft:black_concrete
setblock 463 82 285 minecraft:gray_concrete
fill 463 82 286 463 83 286 minecraft:black_concrete
fill 464 82 285 464 83 285 minecraft:black_concrete
fill 435 83 276 435 85 276 minecraft:black_concrete
setblock 435 83 277 minecraft:gray_concrete
fill 435 83 278 435 85 278 minecraft:black_concrete
setblock 436 83 276 minecraft:gray_concrete
setblock 436 83 278 minecraft:gray_concrete
fill 437 83 276 437 85 276 minecraft:black_concrete
setblock 437 83 277 minecraft:gray_concrete
fill 437 83 278 437 85 278 minecraft:black_concrete
setblock 463 83 285 minecraft:black_concrete
fill 424 84 277 424 179 277 minecraft:iron_block
setblock 424 84 278 minecraft:gray_concrete
fill 424 84 287 424 179 287 minecraft:iron_block
setblock 424 84 288 minecraft:gray_concrete
fill 424 84 297 424 179 297 minecraft:iron_block
setblock 424 84 298 minecraft:gray_concrete
fill 424 84 307 424 179 307 minecraft:iron_block
setblock 424 84 308 minecraft:gray_concrete
fill 425 84 316 425 179 316 minecraft:iron_block
setblock 426 84 310 minecraft:black_concrete
fill 426 84 311 429 155 311 minecraft:gray_concrete
fill 426 84 312 426 84 313 minecraft:black_concrete
setblock 426 84 316 minecraft:gray_concrete
fill 427 84 309 429 84 309 minecraft:black_concrete
fill 427 84 310 428 155 310 minecraft:gray_concrete
fill 427 84 312 429 155 312 minecraft:gray_concrete
setblock 427 84 313 minecraft:black_concrete
fill 428 84 313 428 155 313 minecraft:gray_concrete
setblock 429 84 310 minecraft:black_concrete
setblock 429 84 313 minecraft:black_concrete
setblock 430 84 276 minecraft:gray_concrete
fill 430 84 311 430 84 312 minecraft:black_concrete
fill 431 84 276 431 179 276 minecraft:iron_block
setblock 434 84 280 minecraft:lime_concrete
fill 435 84 277 435 85 277 minecraft:black_concrete
fill 435 84 316 435 179 316 minecraft:iron_block
fill 436 84 276 436 85 276 minecraft:black_concrete
fill 436 84 278 436 85 278 minecraft:black_concrete
setblock 436 84 316 minecraft:gray_concrete
fill 437 84 277 437 85 277 minecraft:black_concrete
setblock 440 84 276 minecraft:gray_concrete
fill 441 84 276 441 179 276 minecraft:iron_block
fill 445 84 316 445 179 316 minecraft:iron_block
setblock 446 84 316 minecraft:gray_concrete
setblock 450 84 276 minecraft:gray_concrete
fill 451 84 276 451 179 276 minecraft:iron_block
fill 455 84 316 455 179 316 minecraft:iron_block
setblock 456 84 316 minecraft:gray_concrete
fill 458 84 278 458 84 279 minecraft:black_concrete
fill 458 84 280 461 130 280 minecraft:gray_concrete
setblock 458 84 281 minecraft:black_concrete
fill 459 84 278 460 130 279 minecraft:gray_concrete
fill 459 84 281 460 130 281 minecraft:gray_concrete
fill 459 84 282 460 84 282 minecraft:black_concrete
setblock 460 84 276 minecraft:gray_concrete
fill 461 84 276 461 179 276 minecraft:iron_block
setblock 461 84 278 minecraft:black_concrete
fill 461 84 279 461 150 279 minecraft:gray_concrete
setblock 461 84 281 minecraft:black_concrete
fill 461 84 283 464 84 283 minecraft:iron_block
fill 462 84 279 462 84 280 minecraft:black_concrete
setblock 464 84 282 minecraft:gray_concrete
setblock 464 84 292 minecraft:gray_concrete
fill 464 84 293 464 179 293 minecraft:iron_block
setblock 464 84 302 minecraft:gray_concrete
fill 464 84 303 464 179 303 minecraft:iron_block
setblock 464 84 312 minecraft:gray_concrete
fill 464 84 313 464 179 313 minecraft:iron_block
fill 423 85 281 423 85 284 minecraft:sea_lantern
fill 423 85 291 423 85 294 minecraft:sea_lantern
fill 423 85 301 423 85 304 minecraft:sea_lantern
fill 423 85 311 423 85 314 minecraft:sea_lantern
fill 426 85 275 429 85 275 minecraft:sea_lantern
setblock 426 85 278 minecraft:light[level=15]
setblock 426 85 285 minecraft:light[level=12]
setblock 426 85 286 minecraft:light[level=15]
setblock 426 85 292 minecraft:light[level=12]
setblock 426 85 294 minecraft:light[level=15]
setblock 426 85 299 minecraft:light[level=12]
setblock 426 85 302 minecraft:light[level=15]
setblock 426 85 306 minecraft:light[level=12]
setblock 426 85 310 minecraft:light[level=15]
setblock 426 85 313 minecraft:light[level=12]
fill 427 85 317 430 85 317 minecraft:sea_lantern
setblock 433 85 278 minecraft:light[level=12]
setblock 433 85 285 minecraft:light[level=12]
setblock 433 85 292 minecraft:light[level=12]
setblock 433 85 299 minecraft:light[level=12]
setblock 433 85 306 minecraft:light[level=12]
setblock 433 85 313 minecraft:light[level=12]
setblock 434 85 278 minecraft:light[level=15]
setblock 434 85 286 minecraft:light[level=15]
setblock 434 85 294 minecraft:light[level=15]
setblock 434 85 302 minecraft:light[level=15]
setblock 434 85 310 minecraft:light[level=15]
fill 436 85 275 439 85 275 minecraft:sea_lantern
setblock 436 85 277 minecraft:black_concrete
fill 437 85 317 440 85 317 minecraft:sea_lantern
setblock 440 85 278 minecraft:light[level=12]
setblock 440 85 285 minecraft:light[level=12]
setblock 440 85 292 minecraft:light[level=12]
setblock 440 85 299 minecraft:light[level=12]
setblock 440 85 306 minecraft:light[level=12]
setblock 440 85 313 minecraft:light[level=12]
setblock 442 85 278 minecraft:light[level=15]
setblock 442 85 286 minecraft:light[level=15]
setblock 442 85 294 minecraft:light[level=15]
setblock 442 85 302 minecraft:light[level=15]
setblock 442 85 310 minecraft:light[level=15]
fill 446 85 275 449 85 275 minecraft:sea_lantern
setblock 447 85 278 minecraft:light[level=12]
setblock 447 85 285 minecraft:light[level=12]
setblock 447 85 292 minecraft:light[level=12]
setblock 447 85 299 minecraft:light[level=12]
setblock 447 85 306 minecraft:light[level=12]
setblock 447 85 313 minecraft:light[level=12]
fill 447 85 317 450 85 317 minecraft:sea_lantern
setblock 450 85 278 minecraft:light[level=15]
setblock 450 85 286 minecraft:light[level=15]
setblock 450 85 294 minecraft:light[level=15]
setblock 450 85 302 minecraft:light[level=15]
setblock 450 85 310 minecraft:light[level=15]
setblock 454 85 278 minecraft:light[level=12]
setblock 454 85 285 minecraft:light[level=12]
setblock 454 85 292 minecraft:light[level=12]
setblock 454 85 299 minecraft:light[level=12]
setblock 454 85 306 minecraft:light[level=12]
setblock 454 85 313 minecraft:light[level=12]
fill 456 85 275 459 85 275 minecraft:sea_lantern
fill 457 85 317 460 85 317 minecraft:sea_lantern
setblock 458 85 278 minecraft:light[level=15]
setblock 458 85 286 minecraft:light[level=15]
setblock 458 85 294 minecraft:light[level=15]
setblock 458 85 302 minecraft:light[level=15]
setblock 458 85 310 minecraft:light[level=15]
setblock 461 85 278 minecraft:light[level=12]
setblock 461 85 285 minecraft:light[level=12]
setblock 461 85 292 minecraft:light[level=12]
setblock 461 85 299 minecraft:light[level=12]
setblock 461 85 306 minecraft:light[level=12]
setblock 461 85 313 minecraft:light[level=12]
fill 464 85 283 464 179 283 minecraft:iron_block
fill 465 85 276 465 85 279 minecraft:sea_lantern
fill 465 85 286 465 85 289 minecraft:sea_lantern
fill 465 85 296 465 85 299 minecraft:sea_lantern
fill 465 85 306 465 85 309 minecraft:sea_lantern
setblock 465 85 316 minecraft:sea_lantern
fill 423 86 281 423 93 284 minecraft:black_concrete
fill 423 86 291 423 93 294 minecraft:black_concrete
fill 423 86 301 423 93 304 minecraft:black_concrete
fill 423 86 311 423 93 314 minecraft:black_concrete
fill 426 86 275 429 93 275 minecraft:black_concrete
fill 427 86 317 430 93 317 minecraft:black_concrete
fill 436 86 275 439 93 275 minecraft:black_concrete
fill 437 86 317 440 93 317 minecraft:black_concrete
fill 446 86 275 449 93 275 minecraft:black_concrete
fill 447 86 317 450 93 317 minecraft:black_concrete
fill 456 86 275 459 93 275 minecraft:black_concrete
fill 457 86 317 460 93 317 minecraft:black_concrete
fill 465 86 276 465 93 279 minecraft:black_concrete
fill 465 86 286 465 93 289 minecraft:black_concrete
fill 465 86 296 465 93 299 minecraft:black_concrete
fill 465 86 306 465 93 309 minecraft:black_concrete
fill 465 86 316 465 93 316 minecraft:black_concrete
fill 429 89 304 430 90 304 minecraft:light_blue_concrete
fill 441 89 313 443 89 315 minecraft:black_concrete
setblock 424 90 278 minecraft:gray_concrete
fill 424 90 280 424 90 283 minecraft:gray_concrete
setblock 424 90 288 minecraft:gray_concrete
fill 424 90 290 424 90 293 minecraft:gray_concrete
setblock 424 90 298 minecraft:gray_concrete
fill 424 90 300 424 90 303 minecraft:gray_concrete
setblock 424 90 308 minecraft:gray_concrete
fill 424 90 310 424 90 313 minecraft:gray_concrete
fill 425 90 276 428 90 276 minecraft:gray_concrete
setblock 426 90 316 minecraft:gray_concrete
fill 428 90 316 431 90 316 minecraft:gray_concrete
setblock 430 90 276 minecraft:gray_concrete
fill 435 90 276 438 90 276 minecraft:gray_concrete
setblock 436 90 316 minecraft:gray_concrete
fill 438 90 316 441 90 316 minecraft:gray_concrete
setblock 440 90 276 minecraft:gray_concrete
fill 441 90 313 441 90 315 minecraft:black_concrete
fill 442 90 313 443 90 313 minecraft:black_concrete
fill 442 90 314 442 92 314 minecraft:gray_concrete
fill 442 90 315 443 90 315 minecraft:black_concrete
setblock 443 90 314 minecraft:black_concrete
fill 445 90 276 448 90 276 minecraft:gray_concrete
setblock 446 90 316 minecraft:gray_concrete
fill 448 90 316 451 90 316 minecraft:gray_concrete
setblock 450 90 276 minecraft:gray_concrete
fill 455 90 276 458 90 276 minecraft:gray_concrete
setblock 456 90 316 minecraft:gray_concrete
fill 458 90 316 461 90 316 minecraft:gray_concrete
setblock 460 90 276 minecraft:gray_concrete
fill 464 90 277 464 90 280 minecraft:gray_concrete
setblock 464 90 282 minecraft:gray_concrete
fill 464 90 287 464 90 290 minecraft:gray_concrete
setblock 464 90 292 minecraft:gray_concrete
fill 464 90 297 464 90 300 minecraft:gray_concrete
setblock 464 90 302 minecraft:gray_concrete
fill 464 90 307 464 90 310 minecraft:gray_concrete
setblock 464 90 312 minecraft:gray_concrete
setblock 426 91 278 minecraft:light[level=12]
setblock 426 91 285 minecraft:light[level=12]
setblock 426 91 292 minecraft:light[level=12]
setblock 426 91 299 minecraft:light[level=12]
setblock 426 91 306 minecraft:light[level=12]
setblock 426 91 313 minecraft:light[level=12]
setblock 433 91 278 minecraft:light[level=12]
setblock 433 91 285 minecraft:light[level=12]
setblock 433 91 292 minecraft:light[level=12]
setblock 433 91 299 minecraft:light[level=12]
setblock 433 91 306 minecraft:light[level=12]
setblock 433 91 313 minecraft:light[level=12]
setblock 440 91 278 minecraft:light[level=12]
setblock 440 91 285 minecraft:light[level=12]
setblock 440 91 292 minecraft:light[level=12]
setblock 440 91 299 minecraft:light[level=12]
setblock 440 91 306 minecraft:light[level=12]
setblock 440 91 313 minecraft:light[level=12]
fill 441 91 313 441 93 313 minecraft:black_concrete
setblock 441 91 314 minecraft:gray_concrete
fill 441 91 315 441 93 315 minecraft:black_concrete
setblock 442 91 313 minecraft:gray_concrete
setblock 442 91 315 minecraft:gray_concrete
fill 443 91 313 443 93 313 minecraft:black_concrete
setblock 443 91 314 minecraft:gray_concrete
fill 443 91 315 443 93 315 minecraft:black_concrete
setblock 447 91 278 minecraft:light[level=12]
setblock 447 91 285 minecraft:light[level=12]
setblock 447 91 292 minecraft:light[level=12]
setblock 447 91 299 minecraft:light[level=12]
setblock 447 91 306 minecraft:light[level=12]
setblock 447 91 313 minecraft:light[level=12]
setblock 454 91 278 minecraft:light[level=12]
setblock 454 91 285 minecraft:light[level=12]
setblock 454 91 292 minecraft:light[level=12]
setblock 454 91 299 minecraft:light[level=12]
setblock 454 91 306 minecraft:light[level=12]
setblock 454 91 313 minecraft:light[level=12]
setblock 461 91 278 minecraft:light[level=12]
setblock 461 91 285 minecraft:light[level=12]
setblock 461 91 292 minecraft:light[level=12]
setblock 461 91 299 minecraft:light[level=12]
setblock 461 91 306 minecraft:light[level=12]
setblock 461 91 313 minecraft:light[level=12]
setblock 426 92 310 minecraft:black_concrete
fill 426 92 312 426 92 313 minecraft:black_concrete
fill 427 92 309 429 92 309 minecraft:black_concrete
setblock 427 92 313 minecraft:black_concrete
setblock 429 92 310 minecraft:black_concrete
setblock 429 92 313 minecraft:black_concrete
fill 430 92 311 430 92 312 minecraft:black_concrete
fill 441 92 314 441 93 314 minecraft:black_concrete
fill 442 92 313 442 93 313 minecraft:black_concrete
fill 442 92 315 442 93 315 minecraft:black_concrete
fill 443 92 314 443 93 314 minecraft:black_concrete
fill 458 92 278 458 92 279 minecraft:black_concrete
setblock 458 92 281 minecraft:black_concrete
fill 459 92 282 460 92 282 minecraft:black_concrete
setblock 461 92 278 minecraft:black_concrete
setblock 461 92 281 minecraft:black_concrete
fill 462 92 279 462 92 280 minecraft:black_concrete
setblock 426 93 278 minecraft:light[level=15]
setblock 426 93 286 minecraft:light[level=15]
setblock 426 93 294 minecraft:light[level=15]
setblock 426 93 302 minecraft:light[level=15]
setblock 426 93 310 minecraft:light[level=15]
setblock 434 93 278 minecraft:light[level=15]
setblock 434 93 286 minecraft:light[level=15]
setblock 434 93 294 minecraft:light[level=15]
setblock 434 93 302 minecraft:light[level=15]
setblock 434 93 310 minecraft:light[level=15]
setblock 442 93 278 minecraft:light[level=15]
setblock 442 93 286 minecraft:light[level=15]
setblock 442 93 294 minecraft:light[level=15]
setblock 442 93 302 minecraft:light[level=15]
setblock 442 93 310 minecraft:light[level=15]
setblock 442 93 314 minecraft:black_concrete
setblock 450 93 278 minecraft:light[level=15]
setblock 450 93 286 minecraft:light[level=15]
setblock 450 93 294 minecraft:light[level=15]
setblock 450 93 302 minecraft:light[level=15]
setblock 450 93 310 minecraft:light[level=15]
setblock 458 93 278 minecraft:light[level=15]
setblock 458 93 286 minecraft:light[level=15]
setblock 458 93 294 minecraft:light[level=15]
setblock 458 93 302 minecraft:light[level=15]
setblock 458 93 310 minecraft:light[level=15]
fill 423 94 281 423 94 284 minecraft:sea_lantern
fill 423 94 291 423 94 294 minecraft:sea_lantern
fill 423 94 301 423 94 304 minecraft:sea_lantern
fill 423 94 311 423 94 314 minecraft:sea_lantern
fill 426 94 275 429 94 275 minecraft:sea_lantern
fill 427 94 317 430 94 317 minecraft:sea_lantern
fill 436 94 275 439 94 275 minecraft:sea_lantern
fill 437 94 317 440 94 317 minecraft:sea_lantern
fill 446 94 275 449 94 275 minecraft:sea_lantern
fill 447 94 317 450 94 317 minecraft:sea_lantern
fill 456 94 275 459 94 275 minecraft:sea_lantern
fill 457 94 317 460 94 317 minecraft:sea_lantern
fill 465 94 276 465 94 279 minecraft:sea_lantern
fill 465 94 286 465 94 289 minecraft:sea_lantern
fill 465 94 296 465 94 299 minecraft:sea_lantern
fill 465 94 306 465 94 309 minecraft:sea_lantern
setblock 465 94 316 minecraft:sea_lantern
fill 423 95 281 423 102 284 minecraft:black_concrete
fill 423 95 291 423 102 294 minecraft:black_concrete
fill 423 95 301 423 102 304 minecraft:black_concrete
fill 423 95 311 423 102 314 minecraft:black_concrete
fill 424 95 298 426 95 300 minecraft:black_concrete
fill 426 95 275 429 102 275 minecraft:black_concrete
fill 427 95 317 430 102 317 minecraft:black_concrete
fill 436 95 275 439 102 275 minecraft:black_concrete
fill 437 95 317 440 102 317 minecraft:black_concrete
fill 446 95 275 449 102 275 minecraft:black_concrete
fill 447 95 317 450 102 317 minecraft:black_concrete
fill 456 95 275 459 102 275 minecraft:black_concrete
fill 457 95 317 460 102 317 minecraft:black_concrete
fill 465 95 276 465 102 279 minecraft:black_concrete
fill 465 95 286 465 102 289 minecraft:black_concrete
fill 465 95 296 465 102 299 minecraft:black_concrete
fill 465 95 306 465 102 309 minecraft:black_concrete
fill 465 95 316 465 102 316 minecraft:black_concrete
setblock 424 96 278 minecraft:gray_concrete
setblock 424 96 288 minecraft:gray_concrete
fill 424 96 298 424 96 300 minecraft:black_concrete
setblock 424 96 308 minecraft:gray_concrete
fill 425 96 298 426 96 298 minecraft:black_concrete
fill 425 96 299 425 98 299 minecraft:gray_concrete
fill 425 96 300 426 96 300 minecraft:black_concrete
fill 426 96 292 427 97 297 minecraft:gray_concrete
setblock 426 96 299 minecraft:black_concrete
setblock 426 96 316 minecraft:gray_concrete
fill 427 96 289 428 97 291 minecraft:gray_concrete
fill 427 96 298 427 97 303 minecraft:gray_concrete
fill 428 96 287 429 97 288 minecraft:gray_concrete
fill 428 96 301 428 97 305 minecraft:gray_concrete
fill 429 96 286 430 97 286 minecraft:gray_concrete
fill 429 96 289 429 97 289 minecraft:gray_concrete
fill 429 96 303 429 97 306 minecraft:gray_concrete
setblock 430 96 276 minecraft:gray_concrete
fill 430 96 284 431 97 285 minecraft:gray_concrete
fill 430 96 287 430 97 287 minecraft:gray_concrete
fill 430 96 305 430 97 308 minecraft:gray_concrete
fill 431 96 283 433 97 283 minecraft:gray_concrete
fill 431 96 307 431 97 309 minecraft:gray_concrete
fill 432 96 282 435 97 282 minecraft:gray_concrete
fill 432 96 284 432 97 284 minecraft:gray_concrete
fill 432 96 308 432 97 310 minecraft:gray_concrete
fill 433 96 309 433 97 310 minecraft:gray_concrete
fill 434 96 281 437 97 281 minecraft:gray_concrete
fill 434 96 310 435 97 311 minecraft:gray_concrete
fill 435 96 280 439 97 280 minecraft:gray_concrete
fill 435 96 312 439 97 312 minecraft:gray_concrete
fill 436 96 311 437 97 311 minecraft:gray_concrete
setblock 436 96 316 minecraft:gray_concrete
fill 437 96 279 451 97 279 minecraft:gray_concrete
fill 437 96 313 451 97 313 minecraft:gray_concrete
setblock 440 96 276 minecraft:gray_concrete
fill 440 96 278 448 97 278 minecraft:gray_concrete
fill 440 96 314 448 97 314 minecraft:gray_concrete
setblock 446 96 316 minecraft:gray_concrete
fill 449 96 280 453 97 280 minecraft:gray_concrete
fill 449 96 312 453 97 312 minecraft:gray_concrete
setblock 450 96 276 minecraft:gray_concrete
fill 451 96 281 454 97 281 minecraft:gray_concrete
fill 451 96 311 454 97 311 minecraft:gray_concrete
fill 453 96 282 456 97 282 minecraft:gray_concrete
fill 453 96 310 456 97 310 minecraft:gray_concrete
fill 455 96 283 457 97 283 minecraft:gray_concrete
fill 455 96 309 457 97 309 minecraft:gray_concrete
fill 456 96 284 458 97 284 minecraft:gray_concrete
fill 456 96 308 458 97 308 minecraft:gray_concrete
setblock 456 96 316 minecraft:gray_concrete
fill 457 96 285 458 97 285 minecraft:gray_concrete
fill 457 96 307 458 97 307 minecraft:gray_concrete
fill 458 96 286 459 97 287 minecraft:gray_concrete
fill 458 96 305 459 97 306 minecraft:gray_concrete
fill 459 96 288 460 97 289 minecraft:gray_concrete
fill 459 96 303 460 97 304 minecraft:gray_concrete
setblock 460 96 276 minecraft:gray_concrete
fill 460 96 287 460 97 287 minecraft:gray_concrete
fill 460 96 290 461 97 291 minecraft:gray_concrete
fill 460 96 301 461 97 302 minecraft:gray_concrete
fill 460 96 305 460 97 305 minecraft:gray_concrete
fill 461 96 289 461 97 289 minecraft:gray_concrete
fill 461 96 292 462 97 300 minecraft:gray_concrete
fill 461 96 303 461 97 303 minecraft:gray_concrete
setblock 464 96 282 minecraft:gray_concrete
setblock 464 96 292 minecraft:gray_concrete
setblock 464 96 302 minecraft:gray_concrete
setblock 464 96 312 minecraft:gray_concrete
fill 424 97 298 424 99 298 minecraft:black_concrete
setblock 424 97 299 minecraft:gray_concrete
fill 424 97 300 424 99 300 minecraft:black_concrete
setblock 425 97 298 minecraft:gray_concrete
setblock 425 97 300 minecraft:gray_concrete
setblock 426 97 278 minecraft:light[level=12]
setblock 426 97 285 minecraft:light[level=12]
fill 426 97 298 426 99 298 minecraft:black_concrete
setblock 426 97 299 minecraft:gray_concrete
fill 426 97 300 426 99 300 minecraft:black_concrete
setblock 426 97 306 minecraft:light[level=12]
setblock 426 97 313 minecraft:light[level=12]
setblock 433 97 278 minecraft:light[level=12]
setblock 433 97 285 minecraft:light[level=12]
setblock 433 97 292 minecraft:light[level=12]
setblock 433 97 299 minecraft:light[level=12]
setblock 433 97 306 minecraft:light[level=12]
setblock 433 97 313 minecraft:light[level=12]
setblock 440 97 285 minecraft:light[level=12]
setblock 440 97 292 minecraft:light[level=12]
setblock 440 97 299 minecraft:light[level=12]
setblock 440 97 306 minecraft:light[level=12]
setblock 447 97 285 minecraft:light[level=12]
setblock 447 97 292 minecraft:light[level=12]
setblock 447 97 299 minecraft:light[level=12]
setblock 447 97 306 minecraft:light[level=12]
setblock 454 97 278 minecraft:light[level=12]
setblock 454 97 285 minecraft:light[level=12]
setblock 454 97 292 minecraft:light[level=12]
setblock 454 97 299 minecraft:light[level=12]
setblock 454 97 306 minecraft:light[level=12]
setblock 454 97 313 minecraft:light[level=12]
setblock 461 97 278 minecraft:light[level=12]
setblock 461 97 285 minecraft:light[level=12]
setblock 461 97 306 minecraft:light[level=12]
setblock 461 97 313 minecraft:light[level=12]
fill 424 98 299 424 99 299 minecraft:black_concrete
fill 425 98 298 425 99 298 minecraft:black_concrete
fill 425 98 300 425 99 300 minecraft:black_concrete
fill 426 98 299 426 99 299 minecraft:black_concrete
setblock 439 98 279 minecraft:sea_lantern
fill 440 98 278 448 98 278 minecraft:sea_lantern
fill 449 98 279 451 98 279 minecraft:sea_lantern
fill 452 98 280 453 98 280 minecraft:sea_lantern
setblock 454 98 281 minecraft:sea_lantern
fill 424 99 280 424 99 283 minecraft:gray_concrete
fill 424 99 290 424 99 293 minecraft:gray_concrete
fill 424 99 301 424 99 303 minecraft:gray_concrete
fill 424 99 310 424 99 313 minecraft:gray_concrete
fill 425 99 276 428 99 276 minecraft:gray_concrete
setblock 425 99 299 minecraft:black_concrete
fill 428 99 316 431 99 316 minecraft:gray_concrete
fill 435 99 276 438 99 276 minecraft:gray_concrete
fill 438 99 316 441 99 316 minecraft:gray_concrete
fill 445 99 276 448 99 276 minecraft:gray_concrete
fill 448 99 316 451 99 316 minecraft:gray_concrete
fill 455 99 276 458 99 276 minecraft:gray_concrete
fill 458 99 316 461 99 316 minecraft:gray_concrete
fill 464 99 277 464 99 280 minecraft:gray_concrete
fill 464 99 287 464 99 290 minecraft:gray_concrete
fill 464 99 297 464 99 300 minecraft:gray_concrete
fill 464 99 307 464 99 310 minecraft:gray_concrete
setblock 426 100 310 minecraft:black_concrete
fill 426 100 312 426 100 313 minecraft:black_concrete
fill 427 100 309 429 100 309 minecraft:black_concrete
setblock 427 100 313 minecraft:black_concrete
setblock 429 100 310 minecraft:black_concrete
setblock 429 100 313 minecraft:black_concrete
fill 430 100 311 430 100 312 minecraft:black_concrete
fill 458 100 278 458 100 279 minecraft:black_concrete
setblock 458 100 281 minecraft:black_concrete
fill 459 100 282 460 100 282 minecraft:black_concrete
setblock 461 100 278 minecraft:black_concrete
setblock 461 100 281 minecraft:black_concrete
fill 462 100 279 462 100 280 minecraft:black_concrete
setblock 426 101 278 minecraft:light[level=15]
setblock 426 101 286 minecraft:light[level=15]
setblock 426 101 294 minecraft:light[level=15]
setblock 426 101 302 minecraft:light[level=15]
setblock 426 101 310 minecraft:light[level=15]
setblock 434 101 278 minecraft:light[level=15]
setblock 434 101 286 minecraft:light[level=15]
setblock 434 101 294 minecraft:light[level=15]
setblock 434 101 302 minecraft:light[level=15]
setblock 434 101 310 minecraft:light[level=15]
setblock 442 101 278 minecraft:light[level=15]
setblock 442 101 286 minecraft:light[level=15]
setblock 442 101 294 minecraft:light[level=15]
setblock 442 101 302 minecraft:light[level=15]
setblock 442 101 310 minecraft:light[level=15]
setblock 450 101 278 minecraft:light[level=15]
setblock 450 101 286 minecraft:light[level=15]
setblock 450 101 294 minecraft:light[level=15]
setblock 450 101 302 minecraft:light[level=15]
setblock 450 101 310 minecraft:light[level=15]
setblock 458 101 278 minecraft:light[level=15]
setblock 458 101 286 minecraft:light[level=15]
setblock 458 101 294 minecraft:light[level=15]
setblock 458 101 302 minecraft:light[level=15]
setblock 458 101 310 minecraft:light[level=15]
setblock 424 102 278 minecraft:gray_concrete
setblock 424 102 288 minecraft:gray_concrete
setblock 424 102 298 minecraft:gray_concrete
setblock 424 102 308 minecraft:gray_concrete
setblock 426 102 316 minecraft:gray_concrete
setblock 430 102 276 minecraft:gray_concrete
fill 430 102 290 431 103 290 minecraft:lime_concrete
setblock 436 102 316 minecraft:gray_concrete
setblock 440 102 276 minecraft:gray_concrete
setblock 446 102 316 minecraft:gray_concrete
setblock 450 102 276 minecraft:gray_concrete
setblock 456 102 316 minecraft:gray_concrete
setblock 460 102 276 minecraft:gray_concrete
setblock 464 102 282 minecraft:gray_concrete
setblock 464 102 292 minecraft:gray_concrete
setblock 464 102 302 minecraft:gray_concrete
setblock 464 102 312 minecraft:gray_concrete
fill 423 103 281 423 103 284 minecraft:sea_lantern
fill 423 103 291 423 103 294 minecraft:sea_lantern
fill 423 103 301 423 103 304 minecraft:sea_lantern
fill 423 103 311 423 103 314 minecraft:sea_lantern
fill 426 103 275 429 103 275 minecraft:sea_lantern
setblock 426 103 278 minecraft:light[level=12]
setblock 426 103 285 minecraft:light[level=12]
setblock 426 103 292 minecraft:light[level=12]
setblock 426 103 299 minecraft:light[level=12]
setblock 426 103 306 minecraft:light[level=12]
setblock 426 103 313 minecraft:light[level=12]
fill 427 103 317 430 103 317 minecraft:sea_lantern
setblock 433 103 278 minecraft:light[level=12]
setblock 433 103 285 minecraft:light[level=12]
setblock 433 103 292 minecraft:light[level=12]
setblock 433 103 299 minecraft:light[level=12]
setblock 433 103 306 minecraft:light[level=12]
setblock 433 103 313 minecraft:light[level=12]
fill 436 103 275 439 103 275 minecraft:sea_lantern
fill 437 103 317 440 103 317 minecraft:sea_lantern
setblock 440 103 278 minecraft:light[level=12]
setblock 440 103 285 minecraft:light[level=12]
setblock 440 103 292 minecraft:light[level=12]
setblock 440 103 299 minecraft:light[level=12]
setblock 440 103 306 minecraft:light[level=12]
setblock 440 103 313 minecraft:light[level=12]
fill 446 103 275 449 103 275 minecraft:sea_lantern
setblock 447 103 278 minecraft:light[level=12]
setblock 447 103 285 minecraft:light[level=12]
setblock 447 103 292 minecraft:light[level=12]
setblock 447 103 299 minecraft:light[level=12]
setblock 447 103 306 minecraft:light[level=12]
setblock 447 103 313 minecraft:light[level=12]
fill 447 103 317 450 103 317 minecraft:sea_lantern
setblock 454 103 278 minecraft:light[level=12]
setblock 454 103 285 minecraft:light[level=12]
setblock 454 103 292 minecraft:light[level=12]
setblock 454 103 299 minecraft:light[level=12]
setblock 454 103 306 minecraft:light[level=12]
setblock 454 103 313 minecraft:light[level=12]
fill 456 103 275 459 103 275 minecraft:sea_lantern
fill 457 103 317 460 103 317 minecraft:sea_lantern
setblock 461 103 278 minecraft:light[level=12]
setblock 461 103 285 minecraft:light[level=12]
setblock 461 103 292 minecraft:light[level=12]
setblock 461 103 299 minecraft:light[level=12]
setblock 461 103 306 minecraft:light[level=12]
setblock 461 103 313 minecraft:light[level=12]
fill 465 103 276 465 103 279 minecraft:sea_lantern
fill 465 103 286 465 103 289 minecraft:sea_lantern
fill 465 103 296 465 103 299 minecraft:sea_lantern
fill 465 103 306 465 103 309 minecraft:sea_lantern
setblock 465 103 316 minecraft:sea_lantern
fill 423 104 281 423 111 284 minecraft:black_concrete
fill 423 104 291 423 111 294 minecraft:black_concrete
fill 423 104 301 423 111 304 minecraft:black_concrete
fill 423 104 311 423 111 314 minecraft:black_concrete
fill 426 104 275 429 111 275 minecraft:black_concrete
fill 427 104 317 430 111 317 minecraft:black_concrete
fill 436 104 275 439 111 275 minecraft:black_concrete
fill 437 104 317 440 111 317 minecraft:black_concrete
fill 446 104 275 449 111 275 minecraft:black_concrete
fill 447 104 317 450 111 317 minecraft:black_concrete
fill 456 104 275 459 111 275 minecraft:black_concrete
fill 457 104 317 460 111 317 minecraft:black_concrete
fill 465 104 276 465 111 279 minecraft:black_concrete
fill 465 104 286 465 111 289 minecraft:black_concrete
fill 465 104 296 465 111 299 minecraft:black_concrete
fill 465 104 306 465 111 309 minecraft:black_concrete
fill 465 104 316 465 111 316 minecraft:black_concrete
setblock 424 108 278 minecraft:gray_concrete
fill 424 108 280 424 108 283 minecraft:gray_concrete
setblock 424 108 288 minecraft:gray_concrete
fill 424 108 290 424 108 293 minecraft:gray_concrete
setblock 424 108 298 minecraft:gray_concrete
fill 424 108 300 424 108 303 minecraft:gray_concrete
setblock 424 108 308 minecraft:gray_concrete
fill 424 108 310 424 108 313 minecraft:gray_concrete
fill 425 108 276 428 108 276 minecraft:gray_concrete
setblock 426 108 310 minecraft:black_concrete
fill 426 108 312 426 108 313 minecraft:black_concrete
setblock 426 108 316 minecraft:gray_concrete
fill 427 108 309 429 108 309 minecraft:black_concrete
setblock 427 108 313 minecraft:black_concrete
fill 428 108 316 431 108 316 minecraft:gray_concrete
setblock 429 108 310 minecraft:black_concrete
setblock 429 108 313 minecraft:black_concrete
setblock 430 108 276 minecraft:gray_concrete
fill 430 108 311 430 108 312 minecraft:black_concrete
fill 435 108 276 438 108 276 minecraft:gray_concrete
setblock 436 108 316 minecraft:gray_concrete
fill 438 108 316 441 108 316 minecraft:gray_concrete
setblock 440 108 276 minecraft:gray_concrete
fill 445 108 276 448 108 276 minecraft:gray_concrete
setblock 446 108 316 minecraft:gray_concrete
fill 448 108 316 451 108 316 minecraft:gray_concrete
setblock 450 108 276 minecraft:gray_concrete
fill 455 108 276 458 108 276 minecraft:gray_concrete
setblock 456 108 316 minecraft:gray_concrete
fill 458 108 278 458 108 279 minecraft:black_concrete
setblock 458 108 281 minecraft:black_concrete
fill 458 108 316 461 108 316 minecraft:gray_concrete
fill 459 108 282 460 108 282 minecraft:black_concrete
setblock 460 108 276 minecraft:gray_concrete
setblock 461 108 278 minecraft:black_concrete
setblock 461 108 281 minecraft:black_concrete
fill 462 108 279 462 108 280 minecraft:black_concrete
fill 464 108 277 464 108 280 minecraft:gray_concrete
setblock 464 108 282 minecraft:gray_concrete
fill 464 108 287 464 108 290 minecraft:gray_concrete
setblock 464 108 292 minecraft:gray_concrete
fill 464 108 297 464 108 300 minecraft:gray_concrete
setblock 464 108 302 minecraft:gray_concrete
fill 464 108 307 464 108 310 minecraft:gray_concrete
setblock 464 108 312 minecraft:gray_concrete
setblock 426 109 278 minecraft:light[level=15]
setblock 426 109 285 minecraft:light[level=12]
setblock 426 109 286 minecraft:light[level=15]
setblock 426 109 292 minecraft:light[level=12]
setblock 426 109 294 minecraft:light[level=15]
setblock 426 109 299 minecraft:light[level=12]
setblock 426 109 302 minecraft:light[level=15]
setblock 426 109 306 minecraft:light[level=12]
setblock 426 109 310 minecraft:light[level=15]
setblock 426 109 313 minecraft:light[level=12]
setblock 433 109 278 minecraft:light[level=12]
setblock 433 109 285 minecraft:light[level=12]
setblock 433 109 292 minecraft:light[level=12]
setblock 433 109 299 minecraft:light[level=12]
setblock 433 109 306 minecraft:light[level=12]
setblock 433 109 313 minecraft:light[level=12]
setblock 434 109 278 minecraft:light[level=15]
setblock 434 109 286 minecraft:light[level=15]
setblock 434 109 294 minecraft:light[level=15]
setblock 434 109 302 minecraft:light[level=15]
setblock 434 109 310 minecraft:light[level=15]
setblock 440 109 278 minecraft:light[level=12]
setblock 440 109 285 minecraft:light[level=12]
setblock 440 109 292 minecraft:light[level=12]
setblock 440 109 299 minecraft:light[level=12]
setblock 440 109 306 minecraft:light[level=12]
setblock 440 109 313 minecraft:light[level=12]
setblock 442 109 278 minecraft:light[level=15]
setblock 442 109 286 minecraft:light[level=15]
setblock 442 109 294 minecraft:light[level=15]
setblock 442 109 302 minecraft:light[level=15]
setblock 442 109 310 minecraft:light[level=15]
setblock 447 109 278 minecraft:light[level=12]
setblock 447 109 285 minecraft:light[level=12]
setblock 447 109 292 minecraft:light[level=12]
setblock 447 109 299 minecraft:light[level=12]
setblock 447 109 306 minecraft:light[level=12]
setblock 447 109 313 minecraft:light[level=12]
setblock 450 109 278 minecraft:light[level=15]
setblock 450 109 286 minecraft:light[level=15]
setblock 450 109 294 minecraft:light[level=15]
setblock 450 109 302 minecraft:light[level=15]
setblock 450 109 310 minecraft:light[level=15]
setblock 454 109 278 minecraft:light[level=12]
setblock 454 109 285 minecraft:light[level=12]
setblock 454 109 292 minecraft:light[level=12]
setblock 454 109 299 minecraft:light[level=12]
setblock 454 109 306 minecraft:light[level=12]
setblock 454 109 313 minecraft:light[level=12]
setblock 458 109 278 minecraft:light[level=15]
setblock 458 109 286 minecraft:light[level=15]
setblock 458 109 294 minecraft:light[level=15]
setblock 458 109 302 minecraft:light[level=15]
setblock 458 109 310 minecraft:light[level=15]
setblock 461 109 278 minecraft:light[level=12]
setblock 461 109 285 minecraft:light[level=12]
setblock 461 109 292 minecraft:light[level=12]
setblock 461 109 299 minecraft:light[level=12]
setblock 461 109 306 minecraft:light[level=12]
setblock 461 109 313 minecraft:light[level=12]
fill 423 112 281 423 112 284 minecraft:sea_lantern
fill 423 112 291 423 112 294 minecraft:sea_lantern
fill 423 112 301 423 112 304 minecraft:sea_lantern
fill 423 112 311 423 112 314 minecraft:sea_lantern
fill 426 112 275 429 112 275 minecraft:sea_lantern
fill 427 112 317 430 112 317 minecraft:sea_lantern
fill 436 112 275 439 112 275 minecraft:sea_lantern
fill 437 112 317 440 112 317 minecraft:sea_lantern
fill 446 112 275 449 112 275 minecraft:sea_lantern
fill 447 112 317 450 112 317 minecraft:sea_lantern
fill 456 112 275 459 112 275 minecraft:sea_lantern
fill 457 112 317 460 112 317 minecraft:sea_lantern
fill 465 112 276 465 112 279 minecraft:sea_lantern
fill 465 112 286 465 112 289 minecraft:sea_lantern
fill 465 112 296 465 112 299 minecraft:sea_lantern
fill 465 112 306 465 112 309 minecraft:sea_lantern
setblock 465 112 316 minecraft:sea_lantern
fill 423 113 281 423 120 284 minecraft:black_concrete
fill 423 113 291 423 120 294 minecraft:black_concrete
fill 423 113 301 423 120 304 minecraft:black_concrete
fill 423 113 311 423 120 314 minecraft:black_concrete
fill 426 113 275 429 120 275 minecraft:black_concrete
fill 427 113 317 430 120 317 minecraft:black_concrete
fill 436 113 275 439 120 275 minecraft:black_concrete
fill 437 113 317 440 120 317 minecraft:black_concrete
fill 446 113 275 449 120 275 minecraft:black_concrete
fill 447 113 317 450 120 317 minecraft:black_concrete
fill 456 113 275 459 120 275 minecraft:black_concrete
fill 457 113 317 460 120 317 minecraft:black_concrete
fill 465 113 276 465 120 279 minecraft:black_concrete
fill 465 113 286 465 120 289 minecraft:black_concrete
fill 465 113 296 465 120 299 minecraft:black_concrete
fill 465 113 306 465 120 309 minecraft:black_concrete
fill 465 113 316 465 120 316 minecraft:black_concrete
setblock 424 114 278 minecraft:gray_concrete
setblock 424 114 288 minecraft:gray_concrete
setblock 424 114 298 minecraft:gray_concrete
setblock 424 114 308 minecraft:gray_concrete
setblock 426 114 316 minecraft:gray_concrete
setblock 430 114 276 minecraft:gray_concrete
setblock 436 114 316 minecraft:gray_concrete
setblock 440 114 276 minecraft:gray_concrete
setblock 446 114 316 minecraft:gray_concrete
setblock 450 114 276 minecraft:gray_concrete
setblock 456 114 316 minecraft:gray_concrete
setblock 460 114 276 minecraft:gray_concrete
setblock 464 114 282 minecraft:gray_concrete
setblock 464 114 292 minecraft:gray_concrete
setblock 464 114 302 minecraft:gray_concrete
setblock 464 114 312 minecraft:gray_concrete
setblock 426 115 278 minecraft:light[level=12]
setblock 426 115 285 minecraft:light[level=12]
setblock 426 115 292 minecraft:light[level=12]
setblock 426 115 299 minecraft:light[level=12]
setblock 426 115 306 minecraft:light[level=12]
setblock 426 115 313 minecraft:light[level=12]
setblock 433 115 278 minecraft:light[level=12]
setblock 433 115 285 minecraft:light[level=12]
setblock 433 115 292 minecraft:light[level=12]
setblock 433 115 299 minecraft:light[level=12]
setblock 433 115 306 minecraft:light[level=12]
setblock 433 115 313 minecraft:light[level=12]
setblock 440 115 278 minecraft:light[level=12]
setblock 440 115 285 minecraft:light[level=12]
setblock 440 115 292 minecraft:light[level=12]
setblock 440 115 299 minecraft:light[level=12]
setblock 440 115 306 minecraft:light[level=12]
setblock 440 115 313 minecraft:light[level=12]
setblock 447 115 278 minecraft:light[level=12]
setblock 447 115 285 minecraft:light[level=12]
setblock 447 115 292 minecraft:light[level=12]
setblock 447 115 299 minecraft:light[level=12]
setblock 447 115 306 minecraft:light[level=12]
setblock 447 115 313 minecraft:light[level=12]
setblock 454 115 278 minecraft:light[level=12]
setblock 454 115 285 minecraft:light[level=12]
setblock 454 115 292 minecraft:light[level=12]
setblock 454 115 299 minecraft:light[level=12]
setblock 454 115 306 minecraft:light[level=12]
setblock 454 115 313 minecraft:light[level=12]
setblock 461 115 278 minecraft:light[level=12]
setblock 461 115 285 minecraft:light[level=12]
setblock 461 115 292 minecraft:light[level=12]
setblock 461 115 299 minecraft:light[level=12]
setblock 461 115 306 minecraft:light[level=12]
setblock 461 115 313 minecraft:light[level=12]
setblock 426 116 310 minecraft:black_concrete
fill 426 116 312 426 116 313 minecraft:black_concrete
fill 427 116 309 429 116 309 minecraft:black_concrete
setblock 427 116 313 minecraft:black_concrete
setblock 429 116 310 minecraft:black_concrete
setblock 429 116 313 minecraft:black_concrete
fill 430 116 311 430 116 312 minecraft:black_concrete
fill 458 116 278 458 116 279 minecraft:black_concrete
setblock 458 116 281 minecraft:black_concrete
fill 459 116 282 460 116 282 minecraft:black_concrete
setblock 461 116 278 minecraft:black_concrete
setblock 461 116 281 minecraft:black_concrete
fill 462 116 279 462 116 280 minecraft:black_concrete
fill 424 117 280 424 117 283 minecraft:gray_concrete
fill 424 117 290 424 117 293 minecraft:gray_concrete
fill 424 117 300 424 117 303 minecraft:gray_concrete
fill 424 117 310 424 117 313 minecraft:gray_concrete
fill 425 117 276 428 117 276 minecraft:gray_concrete
setblock 426 117 278 minecraft:light[level=15]
setblock 426 117 286 minecraft:light[level=15]
setblock 426 117 294 minecraft:light[level=15]
setblock 426 117 302 minecraft:light[level=15]
setblock 426 117 310 minecraft:light[level=15]
fill 428 117 316 431 117 316 minecraft:gray_concrete
setblock 434 117 278 minecraft:light[level=15]
setblock 434 117 286 minecraft:light[level=15]
setblock 434 117 294 minecraft:light[level=15]
setblock 434 117 302 minecraft:light[level=15]
setblock 434 117 310 minecraft:light[level=15]
fill 435 117 276 438 117 276 minecraft:gray_concrete
fill 438 117 316 441 117 316 minecraft:gray_concrete
setblock 442 117 278 minecraft:light[level=15]
setblock 442 117 286 minecraft:light[level=15]
setblock 442 117 294 minecraft:light[level=15]
setblock 442 117 302 minecraft:light[level=15]
setblock 442 117 310 minecraft:light[level=15]
fill 445 117 276 448 117 276 minecraft:gray_concrete
fill 448 117 316 451 117 316 minecraft:gray_concrete
setblock 450 117 278 minecraft:light[level=15]
setblock 450 117 286 minecraft:light[level=15]
setblock 450 117 294 minecraft:light[level=15]
setblock 450 117 302 minecraft:light[level=15]
setblock 450 117 310 minecraft:light[level=15]
fill 455 117 276 458 117 276 minecraft:gray_concrete
setblock 458 117 278 minecraft:light[level=15]
setblock 458 117 286 minecraft:light[level=15]
setblock 458 117 294 minecraft:light[level=15]
setblock 458 117 302 minecraft:light[level=15]
setblock 458 117 310 minecraft:light[level=15]
fill 458 117 316 461 117 316 minecraft:gray_concrete
fill 464 117 277 464 117 280 minecraft:gray_concrete
fill 464 117 287 464 117 290 minecraft:gray_concrete
fill 464 117 297 464 117 300 minecraft:gray_concrete
fill 464 117 307 464 117 310 minecraft:gray_concrete
fill 462 118 300 464 118 302 minecraft:black_concrete
fill 461 119 305 463 120 305 minecraft:iron_block
fill 462 119 300 462 119 302 minecraft:black_concrete
fill 463 119 300 464 119 300 minecraft:black_concrete
fill 463 119 301 463 121 301 minecraft:gray_concrete
fill 463 119 302 464 119 302 minecraft:black_concrete
setblock 464 119 301 minecraft:black_concrete
setblock 424 120 278 minecraft:gray_concrete
setblock 424 120 288 minecraft:gray_concrete
setblock 424 120 298 minecraft:gray_concrete
setblock 424 120 308 minecraft:gray_concrete
setblock 426 120 316 minecraft:gray_concrete
setblock 430 120 276 minecraft:gray_concrete
setblock 436 120 316 minecraft:gray_concrete
setblock 440 120 276 minecraft:gray_concrete
fill 441 120 313 441 121 315 minecraft:iron_block
setblock 446 120 316 minecraft:gray_concrete
setblock 450 120 276 minecraft:gray_concrete
setblock 456 120 316 minecraft:gray_concrete
setblock 460 120 276 minecraft:gray_concrete
fill 462 120 300 462 122 300 minecraft:black_concrete
setblock 462 120 301 minecraft:gray_concrete
fill 462 120 302 462 122 302 minecraft:black_concrete
setblock 463 120 300 minecraft:gray_concrete
setblock 463 120 302 minecraft:gray_concrete
setblock 464 120 282 minecraft:gray_concrete
setblock 464 120 292 minecraft:gray_concrete
fill 464 120 300 464 122 300 minecraft:black_concrete
setblock 464 120 301 minecraft:gray_concrete
fill 464 120 302 464 122 302 minecraft:black_concrete
setblock 464 120 312 minecraft:gray_concrete
fill 423 121 281 423 121 284 minecraft:sea_lantern
fill 423 121 291 423 121 294 minecraft:sea_lantern
fill 423 121 301 423 121 304 minecraft:sea_lantern
fill 423 121 311 423 121 314 minecraft:sea_lantern
fill 426 121 275 429 121 275 minecraft:sea_lantern
setblock 426 121 278 minecraft:light[level=12]
setblock 426 121 285 minecraft:light[level=12]
setblock 426 121 292 minecraft:light[level=12]
setblock 426 121 299 minecraft:light[level=12]
setblock 426 121 306 minecraft:light[level=12]
setblock 426 121 313 minecraft:light[level=12]
fill 427 121 317 430 121 317 minecraft:sea_lantern
setblock 433 121 278 minecraft:light[level=12]
setblock 433 121 285 minecraft:light[level=12]
setblock 433 121 292 minecraft:light[level=12]
setblock 433 121 299 minecraft:light[level=12]
setblock 433 121 306 minecraft:light[level=12]
setblock 433 121 313 minecraft:light[level=12]
fill 436 121 275 439 121 275 minecraft:sea_lantern
fill 437 121 317 440 121 317 minecraft:sea_lantern
setblock 440 121 278 minecraft:light[level=12]
setblock 440 121 285 minecraft:light[level=12]
setblock 440 121 292 minecraft:light[level=12]
setblock 440 121 299 minecraft:light[level=12]
setblock 440 121 306 minecraft:light[level=12]
setblock 440 121 313 minecraft:light[level=12]
fill 446 121 275 449 121 275 minecraft:sea_lantern
setblock 447 121 278 minecraft:light[level=12]
setblock 447 121 285 minecraft:light[level=12]
setblock 447 121 292 minecraft:light[level=12]
setblock 447 121 299 minecraft:light[level=12]
setblock 447 121 306 minecraft:light[level=12]
setblock 447 121 313 minecraft:light[level=12]
fill 447 121 317 450 121 317 minecraft:sea_lantern
setblock 454 121 278 minecraft:light[level=12]
setblock 454 121 285 minecraft:light[level=12]
setblock 454 121 292 minecraft:light[level=12]
setblock 454 121 299 minecraft:light[level=12]
setblock 454 121 306 minecraft:light[level=12]
setblock 454 121 313 minecraft:light[level=12]
fill 456 121 275 459 121 275 minecraft:sea_lantern
fill 457 121 317 460 121 317 minecraft:sea_lantern
setblock 461 121 278 minecraft:light[level=12]
setblock 461 121 285 minecraft:light[level=12]
setblock 461 121 292 minecraft:light[level=12]
setblock 461 121 299 minecraft:light[level=12]
setblock 461 121 306 minecraft:light[level=12]
setblock 461 121 313 minecraft:light[level=12]
fill 462 121 301 462 122 301 minecraft:black_concrete
fill 463 121 300 463 122 300 minecraft:black_concrete
fill 463 121 302 463 122 302 minecraft:black_concrete
fill 464 121 301 464 122 301 minecraft:black_concrete
fill 465 121 276 465 121 279 minecraft:sea_lantern
fill 465 121 286 465 121 289 minecraft:sea_lantern
fill 465 121 296 465 121 299 minecraft:sea_lantern
fill 465 121 306 465 121 309 minecraft:sea_lantern
setblock 465 121 316 minecraft:sea_lantern
fill 423 122 281 423 129 284 minecraft:black_concrete
fill 423 122 291 423 129 294 minecraft:black_concrete
fill 423 122 301 423 129 304 minecraft:black_concrete
fill 423 122 311 423 129 314 minecraft:black_concrete
fill 426 122 275 429 129 275 minecraft:black_concrete
fill 427 122 317 430 129 317 minecraft:black_concrete
fill 436 122 275 439 129 275 minecraft:black_concrete
fill 437 122 317 440 129 317 minecraft:black_concrete
fill 446 122 275 449 129 275 minecraft:black_concrete
fill 447 122 317 450 129 317 minecraft:black_concrete
fill 456 122 275 459 129 275 minecraft:black_concrete
fill 457 122 317 460 129 317 minecraft:black_concrete
setblock 463 122 301 minecraft:black_concrete
fill 465 122 276 465 129 279 minecraft:black_concrete
fill 465 122 286 465 129 289 minecraft:black_concrete
fill 465 122 296 465 129 299 minecraft:black_concrete
fill 465 122 306 465 129 309 minecraft:black_concrete
fill 465 122 316 465 129 316 minecraft:black_concrete
fill 448 123 280 448 139 280 minecraft:magenta_concrete
fill 452 123 313 452 124 315 minecraft:iron_block
setblock 426 124 310 minecraft:black_concrete
fill 426 124 312 426 124 313 minecraft:black_concrete
fill 427 124 309 429 124 309 minecraft:black_concrete
setblock 427 124 313 minecraft:black_concrete
setblock 429 124 310 minecraft:black_concrete
setblock 429 124 313 minecraft:black_concrete
fill 430 124 311 430 124 312 minecraft:black_concrete
fill 445 124 278 447 138 282 minecraft:magenta_concrete
fill 446 124 277 450 138 277 minecraft:magenta_concrete
fill 446 124 283 450 138 283 minecraft:magenta_concrete
fill 448 124 278 451 138 279 minecraft:magenta_concrete
fill 448 124 281 451 138 282 minecraft:magenta_concrete
fill 449 124 280 451 138 280 minecraft:magenta_concrete
fill 458 124 278 458 124 279 minecraft:black_concrete
setblock 458 124 281 minecraft:black_concrete
fill 459 124 282 460 124 282 minecraft:black_concrete
setblock 461 124 278 minecraft:black_concrete
setblock 461 124 281 minecraft:black_concrete
fill 462 124 279 462 124 280 minecraft:black_concrete
setblock 426 125 278 minecraft:light[level=15]
setblock 426 125 286 minecraft:light[level=15]
setblock 426 125 294 minecraft:light[level=15]
setblock 426 125 302 minecraft:light[level=15]
setblock 426 125 310 minecraft:light[level=15]
setblock 434 125 278 minecraft:light[level=15]
setblock 434 125 286 minecraft:light[level=15]
setblock 434 125 294 minecraft:light[level=15]
setblock 434 125 302 minecraft:light[level=15]
setblock 434 125 310 minecraft:light[level=15]
setblock 442 125 278 minecraft:light[level=15]
setblock 442 125 286 minecraft:light[level=15]
setblock 442 125 294 minecraft:light[level=15]
setblock 442 125 302 minecraft:light[level=15]
setblock 442 125 310 minecraft:light[level=15]
fill 443 125 279 444 137 281 minecraft:magenta_concrete
fill 444 125 277 444 137 278 minecraft:magenta_concrete
fill 444 125 282 444 137 283 minecraft:magenta_concrete
fill 445 125 276 445 125 277 minecraft:magenta_concrete
fill 445 125 283 445 137 284 minecraft:magenta_concrete
fill 446 125 276 450 125 276 minecraft:magenta_concrete
fill 446 125 284 451 137 284 minecraft:magenta_concrete
fill 447 125 285 449 137 285 minecraft:magenta_concrete
setblock 450 125 286 minecraft:light[level=15]
setblock 450 125 294 minecraft:light[level=15]
setblock 450 125 302 minecraft:light[level=15]
setblock 450 125 310 minecraft:light[level=15]
fill 451 125 277 452 137 277 minecraft:magenta_concrete
fill 451 125 283 452 137 283 minecraft:magenta_concrete
fill 452 125 278 452 137 282 minecraft:magenta_concrete
fill 453 125 279 453 137 281 minecraft:magenta_concrete
setblock 458 125 278 minecraft:light[level=15]
setblock 458 125 286 minecraft:light[level=15]
setblock 458 125 294 minecraft:light[level=15]
setblock 458 125 302 minecraft:light[level=15]
setblock 458 125 310 minecraft:light[level=15]
setblock 424 126 278 minecraft:gray_concrete
fill 424 126 280 424 126 283 minecraft:gray_concrete
setblock 424 126 288 minecraft:gray_concrete
fill 424 126 290 424 126 293 minecraft:gray_concrete
setblock 424 126 298 minecraft:gray_concrete
fill 424 126 300 424 126 303 minecraft:gray_concrete
setblock 424 126 308 minecraft:gray_concrete
fill 424 126 310 424 126 313 minecraft:gray_concrete
fill 425 126 276 428 126 276 minecraft:gray_concrete
setblock 426 126 316 minecraft:gray_concrete
fill 428 126 316 431 126 316 minecraft:gray_concrete
setblock 430 126 276 minecraft:gray_concrete
fill 435 126 276 438 126 276 minecraft:gray_concrete
setblock 436 126 316 minecraft:gray_concrete
fill 438 126 316 441 126 316 minecraft:gray_concrete
setblock 440 126 276 minecraft:gray_concrete
fill 442 126 279 442 136 281 minecraft:magenta_concrete
fill 443 126 277 443 136 278 minecraft:magenta_concrete
fill 443 126 282 443 136 283 minecraft:magenta_concrete
fill 444 126 276 444 136 276 minecraft:magenta_concrete
fill 444 126 284 444 136 284 minecraft:magenta_concrete
fill 445 126 276 448 126 276 minecraft:gray_concrete
fill 445 126 277 445 137 277 minecraft:magenta_concrete
fill 445 126 285 446 136 285 minecraft:magenta_concrete
setblock 446 126 316 minecraft:gray_concrete
fill 447 126 286 449 136 286 minecraft:magenta_concrete
fill 448 126 316 451 126 316 minecraft:gray_concrete
fill 449 126 276 449 137 276 minecraft:magenta_concrete
setblock 450 126 276 minecraft:gray_concrete
fill 450 126 285 451 136 285 minecraft:magenta_concrete
fill 452 126 276 452 136 276 minecraft:magenta_concrete
fill 452 126 284 452 136 284 minecraft:magenta_concrete
fill 453 126 277 453 136 278 minecraft:magenta_concrete
fill 453 126 282 453 136 283 minecraft:magenta_concrete
fill 454 126 279 454 136 281 minecraft:magenta_concrete
fill 455 126 276 458 126 276 minecraft:gray_concrete
setblock 456 126 316 minecraft:gray_concrete
fill 458 126 316 461 126 316 minecraft:gray_concrete
setblock 460 126 276 minecraft:gray_concrete
fill 464 126 277 464 126 280 minecraft:gray_concrete
setblock 464 126 282 minecraft:gray_concrete
fill 464 126 287 464 126 290 minecraft:gray_concrete
setblock 464 126 292 minecraft:gray_concrete
fill 464 126 297 464 126 300 minecraft:gray_concrete
setblock 464 126 302 minecraft:gray_concrete
fill 464 126 307 464 126 310 minecraft:gray_concrete
setblock 464 126 312 minecraft:gray_concrete
setblock 426 127 278 minecraft:light[level=12]
setblock 426 127 285 minecraft:light[level=12]
setblock 426 127 292 minecraft:light[level=12]
setblock 426 127 299 minecraft:light[level=12]
setblock 426 127 306 minecraft:light[level=12]
setblock 426 127 313 minecraft:light[level=12]
setblock 433 127 278 minecraft:light[level=12]
setblock 433 127 285 minecraft:light[level=12]
setblock 433 127 292 minecraft:light[level=12]
setblock 433 127 299 minecraft:light[level=12]
setblock 433 127 306 minecraft:light[level=12]
setblock 433 127 313 minecraft:light[level=12]
setblock 440 127 278 minecraft:light[level=12]
setblock 440 127 285 minecraft:light[level=12]
setblock 440 127 292 minecraft:light[level=12]
setblock 440 127 299 minecraft:light[level=12]
setblock 440 127 306 minecraft:light[level=12]
setblock 440 127 313 minecraft:light[level=12]
fill 442 127 277 442 135 278 minecraft:magenta_concrete
fill 442 127 282 442 135 283 minecraft:magenta_concrete
fill 443 127 276 443 135 276 minecraft:magenta_concrete
fill 443 127 284 443 135 284 minecraft:magenta_concrete
fill 444 127 285 444 135 285 minecraft:magenta_concrete
fill 445 127 276 448 134 276 minecraft:magenta_concrete
fill 445 127 286 446 135 286 minecraft:magenta_concrete
setblock 447 127 292 minecraft:light[level=12]
setblock 447 127 299 minecraft:light[level=12]
setblock 447 127 306 minecraft:light[level=12]
setblock 447 127 313 minecraft:light[level=12]
fill 450 127 276 450 131 276 minecraft:magenta_concrete
fill 450 127 286 451 135 286 minecraft:magenta_concrete
fill 452 127 285 452 135 285 minecraft:magenta_concrete
fill 453 127 276 453 135 276 minecraft:magenta_concrete
fill 453 127 284 453 135 284 minecraft:magenta_concrete
fill 454 127 277 454 135 278 minecraft:magenta_concrete
fill 454 127 282 454 135 283 minecraft:magenta_concrete
setblock 454 127 285 minecraft:light[level=12]
setblock 454 127 292 minecraft:light[level=12]
setblock 454 127 299 minecraft:light[level=12]
setblock 454 127 306 minecraft:light[level=12]
setblock 454 127 313 minecraft:light[level=12]
fill 460 127 287 460 128 288 minecraft:lime_concrete
setblock 461 127 278 minecraft:light[level=12]
setblock 461 127 285 minecraft:light[level=12]
setblock 461 127 292 minecraft:light[level=12]
setblock 461 127 299 minecraft:light[level=12]
setblock 461 127 306 minecraft:light[level=12]
setblock 461 127 313 minecraft:light[level=12]
fill 441 128 278 441 134 282 minecraft:magenta_concrete
fill 442 128 276 442 134 276 minecraft:magenta_concrete
fill 442 128 284 442 134 284 minecraft:magenta_concrete
fill 443 128 285 443 134 285 minecraft:magenta_concrete
fill 444 128 286 444 134 286 minecraft:magenta_concrete
fill 446 128 287 450 134 287 minecraft:magenta_concrete
fill 452 128 286 452 134 286 minecraft:magenta_concrete
fill 453 128 285 453 134 285 minecraft:magenta_concrete
fill 454 128 276 454 134 276 minecraft:magenta_concrete
fill 454 128 284 454 134 284 minecraft:magenta_concrete
fill 455 128 278 455 134 282 minecraft:magenta_concrete
fill 441 129 277 441 133 277 minecraft:magenta_concrete
fill 441 129 283 441 133 283 minecraft:magenta_concrete
fill 445 129 287 445 133 287 minecraft:magenta_concrete
fill 451 129 287 451 133 287 minecraft:magenta_concrete
fill 455 129 277 455 133 277 minecraft:magenta_concrete
fill 455 129 283 455 133 283 minecraft:magenta_concrete
fill 423 130 281 423 130 284 minecraft:sea_lantern
fill 423 130 291 423 130 294 minecraft:sea_lantern
fill 423 130 301 423 130 304 minecraft:sea_lantern
fill 423 130 311 423 130 314 minecraft:sea_lantern
fill 426 130 275 429 130 275 minecraft:sea_lantern
fill 427 130 317 430 130 317 minecraft:sea_lantern
fill 436 130 275 439 130 275 minecraft:sea_lantern
fill 437 130 317 440 130 317 minecraft:sea_lantern
fill 442 130 285 442 132 285 minecraft:magenta_concrete
fill 443 130 286 443 132 286 minecraft:magenta_concrete
fill 446 130 275 449 130 275 minecraft:sea_lantern
fill 447 130 317 450 130 317 minecraft:sea_lantern
fill 453 130 286 453 132 286 minecraft:magenta_concrete
fill 454 130 285 454 132 285 minecraft:magenta_concrete
fill 456 130 275 459 130 275 minecraft:sea_lantern
fill 457 130 317 460 130 317 minecraft:sea_lantern
fill 465 130 276 465 130 279 minecraft:sea_lantern
fill 465 130 286 465 130 289 minecraft:sea_lantern
fill 465 130 296 465 130 299 minecraft:sea_lantern
fill 465 130 306 465 130 309 minecraft:sea_lantern
setblock 465 130 316 minecraft:sea_lantern
fill 423 131 281 423 138 284 minecraft:black_concrete
fill 423 131 291 423 138 294 minecraft:black_concrete
fill 423 131 301 423 138 304 minecraft:black_concrete
fill 423 131 311 423 138 314 minecraft:black_concrete
fill 426 131 275 429 138 275 minecraft:black_concrete
fill 427 131 317 430 138 317 minecraft:black_concrete
fill 436 131 275 439 138 275 minecraft:black_concrete
fill 437 131 278 438 131 282 minecraft:sea_lantern
fill 437 131 317 440 138 317 minecraft:black_concrete
fill 438 131 276 438 131 277 minecraft:sea_lantern
fill 438 131 283 438 131 285 minecraft:sea_lantern
setblock 439 131 276 minecraft:sea_lantern
fill 439 131 284 439 131 286 minecraft:sea_lantern
setblock 440 131 280 minecraft:magenta_concrete
fill 440 131 286 440 131 287 minecraft:sea_lantern
fill 441 131 287 441 131 288 minecraft:sea_lantern
fill 442 131 288 442 131 289 minecraft:sea_lantern
fill 443 131 289 444 131 290 minecraft:sea_lantern
fill 445 131 290 453 131 290 minecraft:sea_lantern
fill 446 131 275 449 138 275 minecraft:black_concrete
fill 446 131 291 450 131 291 minecraft:sea_lantern
fill 447 131 317 450 138 317 minecraft:black_concrete
setblock 448 131 288 minecraft:magenta_concrete
fill 452 131 289 454 131 289 minecraft:sea_lantern
fill 454 131 288 455 131 288 minecraft:sea_lantern
fill 455 131 287 456 131 287 minecraft:sea_lantern
fill 456 131 275 459 138 275 minecraft:black_concrete
setblock 456 131 280 minecraft:magenta_concrete
fill 456 131 286 457 131 286 minecraft:sea_lantern
fill 457 131 276 458 131 276 minecraft:sea_lantern
fill 457 131 284 458 131 285 minecraft:sea_lantern
fill 457 131 317 460 138 317 minecraft:black_concrete
fill 458 131 277 458 131 283 minecraft:sea_lantern
fill 459 131 278 459 131 282 minecraft:sea_lantern
fill 460 131 278 460 149 281 minecraft:gray_concrete
fill 461 131 280 461 155 280 minecraft:gray_concrete
fill 465 131 276 465 138 279 minecraft:black_concrete
fill 465 131 286 465 138 289 minecraft:black_concrete
fill 465 131 296 465 138 299 minecraft:black_concrete
fill 465 131 306 465 138 309 minecraft:black_concrete
fill 465 131 316 465 138 316 minecraft:black_concrete
setblock 424 132 278 minecraft:gray_concrete
setblock 424 132 288 minecraft:gray_concrete
fill 424 132 293 426 132 295 minecraft:black_concrete
setblock 424 132 298 minecraft:gray_concrete
setblock 424 132 308 minecraft:gray_concrete
setblock 426 132 310 minecraft:black_concrete
fill 426 132 312 426 132 313 minecraft:black_concrete
setblock 426 132 316 minecraft:gray_concrete
fill 427 132 309 429 132 309 minecraft:black_concrete
setblock 427 132 313 minecraft:black_concrete
setblock 429 132 310 minecraft:black_concrete
setblock 429 132 313 minecraft:black_concrete
setblock 430 132 276 minecraft:gray_concrete
fill 430 132 311 430 132 312 minecraft:black_concrete
setblock 436 132 316 minecraft:gray_concrete
setblock 440 132 276 minecraft:gray_concrete
setblock 446 132 316 minecraft:gray_concrete
setblock 450 132 276 minecraft:gray_concrete
setblock 456 132 316 minecraft:gray_concrete
fill 458 132 278 458 132 279 minecraft:black_concrete
fill 458 132 280 459 179 280 minecraft:gray_concrete
setblock 458 132 281 minecraft:black_concrete
fill 459 132 278 459 155 279 minecraft:gray_concrete
fill 459 132 281 459 179 281 minecraft:gray_concrete
fill 459 132 282 460 132 282 minecraft:black_concrete
setblock 460 132 276 minecraft:gray_concrete
setblock 461 132 278 minecraft:black_concrete
setblock 461 132 281 minecraft:black_concrete
fill 462 132 279 462 132 280 minecraft:black_concrete
setblock 464 132 282 minecraft:gray_concrete
setblock 464 132 292 minecraft:gray_concrete
setblock 464 132 302 minecraft:gray_concrete
setblock 464 132 312 minecraft:gray_concrete
fill 424 133 293 424 133 295 minecraft:black_concrete
fill 425 133 293 426 133 293 minecraft:black_concrete
fill 425 133 294 425 135 294 minecraft:gray_concrete
fill 425 133 295 426 133 295 minecraft:black_concrete
setblock 426 133 278 minecraft:light[level=15]
setblock 426 133 285 minecraft:light[level=12]
setblock 426 133 286 minecraft:light[level=15]
setblock 426 133 292 minecraft:light[level=12]
setblock 426 133 294 minecraft:black_concrete
setblock 426 133 299 minecraft:light[level=12]
setblock 426 133 302 minecraft:light[level=15]
setblock 426 133 306 minecraft:light[level=12]
setblock 426 133 310 minecraft:light[level=15]
setblock 426 133 313 minecraft:light[level=12]
setblock 433 133 278 minecraft:light[level=12]
setblock 433 133 285 minecraft:light[level=12]
setblock 433 133 292 minecraft:light[level=12]
setblock 433 133 299 minecraft:light[level=12]
setblock 433 133 306 minecraft:light[level=12]
setblock 433 133 313 minecraft:light[level=12]
setblock 434 133 278 minecraft:light[level=15]
setblock 434 133 286 minecraft:light[level=15]
setblock 434 133 294 minecraft:light[level=15]
setblock 434 133 302 minecraft:light[level=15]
setblock 434 133 310 minecraft:light[level=15]
setblock 440 133 278 minecraft:light[level=12]
setblock 440 133 285 minecraft:light[level=12]
setblock 440 133 292 minecraft:light[level=12]
setblock 440 133 299 minecraft:light[level=12]
setblock 440 133 306 minecraft:light[level=12]
setblock 440 133 313 minecraft:light[level=12]
setblock 442 133 286 minecraft:light[level=15]
setblock 442 133 294 minecraft:light[level=15]
setblock 442 133 302 minecraft:light[level=15]
setblock 442 133 310 minecraft:light[level=15]
setblock 447 133 292 minecraft:light[level=12]
setblock 447 133 299 minecraft:light[level=12]
setblock 447 133 306 minecraft:light[level=12]
setblock 447 133 313 minecraft:light[level=12]
fill 450 133 276 450 137 276 minecraft:magenta_concrete
setblock 450 133 294 minecraft:light[level=15]
setblock 450 133 302 minecraft:light[level=15]
setblock 450 133 310 minecraft:light[level=15]
setblock 454 133 285 minecraft:light[level=12]
setblock 454 133 292 minecraft:light[level=12]
setblock 454 133 299 minecraft:light[level=12]
setblock 454 133 306 minecraft:light[level=12]
setblock 454 133 313 minecraft:light[level=12]
setblock 458 133 278 minecraft:light[level=15]
setblock 458 133 286 minecraft:light[level=15]
setblock 458 133 294 minecraft:light[level=15]
setblock 458 133 302 minecraft:light[level=15]
setblock 458 133 310 minecraft:light[level=15]
setblock 461 133 278 minecraft:light[level=12]
setblock 461 133 285 minecraft:light[level=12]
setblock 461 133 292 minecraft:light[level=12]
setblock 461 133 299 minecraft:light[level=12]
setblock 461 133 306 minecraft:light[level=12]
setblock 461 133 313 minecraft:light[level=12]
fill 424 134 293 424 136 293 minecraft:black_concrete
setblock 424 134 294 minecraft:gray_concrete
fill 424 134 295 424 136 295 minecraft:black_concrete
setblock 425 134 293 minecraft:gray_concrete
setblock 425 134 295 minecraft:gray_concrete
fill 426 134 293 426 136 293 minecraft:black_concrete
setblock 426 134 294 minecraft:gray_concrete
fill 426 134 295 426 136 295 minecraft:black_concrete
fill 424 135 280 424 135 283 minecraft:gray_concrete
fill 424 135 290 424 135 292 minecraft:gray_concrete
fill 424 135 294 424 136 294 minecraft:black_concrete
fill 424 135 300 424 135 303 minecraft:gray_concrete
fill 424 135 310 424 135 313 minecraft:gray_concrete
fill 425 135 276 428 135 276 minecraft:gray_concrete
fill 425 135 293 425 136 293 minecraft:black_concrete
fill 425 135 295 425 136 295 minecraft:black_concrete
fill 426 135 294 426 136 294 minecraft:black_concrete
fill 428 135 316 431 135 316 minecraft:gray_concrete
fill 435 135 276 438 135 276 minecraft:gray_concrete
fill 438 135 316 441 135 316 minecraft:gray_concrete
fill 445 135 276 448 135 276 minecraft:gray_concrete
fill 448 135 316 451 135 316 minecraft:gray_concrete
fill 455 135 276 458 135 276 minecraft:gray_concrete
fill 458 135 316 461 135 316 minecraft:gray_concrete
fill 464 135 277 464 135 280 minecraft:gray_concrete
fill 464 135 287 464 135 290 minecraft:gray_concrete
fill 464 135 297 464 135 300 minecraft:gray_concrete
fill 464 135 307 464 135 310 minecraft:gray_concrete
setblock 425 136 294 minecraft:black_concrete
fill 445 136 276 448 137 276 minecraft:magenta_concrete
setblock 424 138 278 minecraft:gray_concrete
setblock 424 138 288 minecraft:gray_concrete
setblock 424 138 298 minecraft:gray_concrete
setblock 424 138 308 minecraft:gray_concrete
setblock 426 138 316 minecraft:gray_concrete
setblock 430 138 276 minecraft:gray_concrete
setblock 436 138 316 minecraft:gray_concrete
setblock 440 138 276 minecraft:gray_concrete
setblock 446 138 316 minecraft:gray_concrete
setblock 450 138 276 minecraft:gray_concrete
setblock 456 138 316 minecraft:gray_concrete
setblock 460 138 276 minecraft:gray_concrete
setblock 464 138 282 minecraft:gray_concrete
setblock 464 138 292 minecraft:gray_concrete
setblock 464 138 302 minecraft:gray_concrete
setblock 464 138 312 minecraft:gray_concrete
fill 423 139 281 423 139 284 minecraft:sea_lantern
fill 423 139 291 423 139 294 minecraft:sea_lantern
fill 423 139 301 423 139 304 minecraft:sea_lantern
fill 423 139 311 423 139 314 minecraft:sea_lantern
fill 426 139 275 429 139 275 minecraft:sea_lantern
setblock 426 139 278 minecraft:light[level=12]
setblock 426 139 285 minecraft:light[level=12]
setblock 426 139 292 minecraft:light[level=12]
setblock 426 139 299 minecraft:light[level=12]
setblock 426 139 306 minecraft:light[level=12]
setblock 426 139 313 minecraft:light[level=12]
fill 427 139 317 430 139 317 minecraft:sea_lantern
setblock 433 139 278 minecraft:light[level=12]
setblock 433 139 285 minecraft:light[level=12]
setblock 433 139 292 minecraft:light[level=12]
setblock 433 139 299 minecraft:light[level=12]
setblock 433 139 306 minecraft:light[level=12]
setblock 433 139 313 minecraft:light[level=12]
fill 436 139 275 439 139 275 minecraft:sea_lantern
fill 437 139 317 440 139 317 minecraft:sea_lantern
setblock 440 139 278 minecraft:light[level=12]
setblock 440 139 285 minecraft:light[level=12]
setblock 440 139 292 minecraft:light[level=12]
setblock 440 139 299 minecraft:light[level=12]
setblock 440 139 306 minecraft:light[level=12]
setblock 440 139 313 minecraft:light[level=12]
fill 446 139 275 449 139 275 minecraft:sea_lantern
setblock 447 139 278 minecraft:light[level=12]
setblock 447 139 285 minecraft:light[level=12]
setblock 447 139 292 minecraft:light[level=12]
setblock 447 139 299 minecraft:light[level=12]
setblock 447 139 306 minecraft:light[level=12]
setblock 447 139 313 minecraft:light[level=12]
fill 447 139 317 450 139 317 minecraft:sea_lantern
setblock 454 139 278 minecraft:light[level=12]
setblock 454 139 285 minecraft:light[level=12]
setblock 454 139 292 minecraft:light[level=12]
setblock 454 139 299 minecraft:light[level=12]
setblock 454 139 306 minecraft:light[level=12]
setblock 454 139 313 minecraft:light[level=12]
fill 456 139 275 459 139 275 minecraft:sea_lantern
fill 457 139 317 460 139 317 minecraft:sea_lantern
setblock 461 139 278 minecraft:light[level=12]
setblock 461 139 285 minecraft:light[level=12]
setblock 461 139 292 minecraft:light[level=12]
setblock 461 139 299 minecraft:light[level=12]
setblock 461 139 306 minecraft:light[level=12]
setblock 461 139 313 minecraft:light[level=12]
fill 465 139 276 465 139 279 minecraft:sea_lantern
fill 465 139 286 465 139 289 minecraft:sea_lantern
fill 465 139 296 465 139 299 minecraft:sea_lantern
fill 465 139 306 465 139 309 minecraft:sea_lantern
setblock 465 139 316 minecraft:sea_lantern
fill 423 140 281 423 147 284 minecraft:black_concrete
fill 423 140 291 423 147 294 minecraft:black_concrete
fill 423 140 301 423 147 304 minecraft:black_concrete
fill 423 140 311 423 147 314 minecraft:black_concrete
fill 426 140 275 429 147 275 minecraft:black_concrete
setblock 426 140 310 minecraft:black_concrete
fill 426 140 312 426 140 313 minecraft:black_concrete
fill 427 140 309 429 140 309 minecraft:black_concrete
setblock 427 140 313 minecraft:black_concrete
fill 427 140 317 430 147 317 minecraft:black_concrete
setblock 429 140 310 minecraft:black_concrete
setblock 429 140 313 minecraft:black_concrete
fill 430 140 311 430 140 312 minecraft:black_concrete
fill 436 140 275 439 147 275 minecraft:black_concrete
fill 437 140 317 440 147 317 minecraft:black_concrete
fill 446 140 275 449 147 275 minecraft:black_concrete
fill 447 140 317 450 147 317 minecraft:black_concrete
fill 456 140 275 459 147 275 minecraft:black_concrete
fill 457 140 317 460 147 317 minecraft:black_concrete
fill 458 140 278 458 140 279 minecraft:black_concrete
setblock 458 140 281 minecraft:black_concrete
fill 459 140 282 460 140 282 minecraft:black_concrete
setblock 461 140 278 minecraft:black_concrete
setblock 461 140 281 minecraft:black_concrete
fill 462 140 279 462 140 280 minecraft:black_concrete
fill 465 140 276 465 147 279 minecraft:black_concrete
fill 465 140 286 465 147 289 minecraft:black_concrete
fill 465 140 296 465 147 299 minecraft:black_concrete
fill 465 140 306 465 147 309 minecraft:black_concrete
fill 465 140 316 465 147 316 minecraft:black_concrete
setblock 426 141 278 minecraft:light[level=15]
setblock 426 141 286 minecraft:light[level=15]
setblock 426 141 294 minecraft:light[level=15]
setblock 426 141 302 minecraft:light[level=15]
setblock 426 141 310 minecraft:light[level=15]
setblock 434 141 278 minecraft:light[level=15]
setblock 434 141 286 minecraft:light[level=15]
setblock 434 141 294 minecraft:light[level=15]
setblock 434 141 302 minecraft:light[level=15]
setblock 434 141 310 minecraft:light[level=15]
setblock 442 141 278 minecraft:light[level=15]
setblock 442 141 286 minecraft:light[level=15]
setblock 442 141 294 minecraft:light[level=15]
setblock 442 141 302 minecraft:light[level=15]
setblock 442 141 310 minecraft:light[level=15]
setblock 450 141 278 minecraft:light[level=15]
setblock 450 141 286 minecraft:light[level=15]
setblock 450 141 294 minecraft:light[level=15]
setblock 450 141 302 minecraft:light[level=15]
setblock 450 141 310 minecraft:light[level=15]
setblock 458 141 278 minecraft:light[level=15]
setblock 458 141 286 minecraft:light[level=15]
setblock 458 141 294 minecraft:light[level=15]
setblock 458 141 302 minecraft:light[level=15]
setblock 458 141 310 minecraft:light[level=15]
setblock 424 144 278 minecraft:gray_concrete
fill 424 144 280 424 144 283 minecraft:gray_concrete
setblock 424 144 288 minecraft:gray_concrete
fill 424 144 290 424 144 293 minecraft:gray_concrete
setblock 424 144 298 minecraft:gray_concrete
fill 424 144 300 424 144 303 minecraft:gray_concrete
setblock 424 144 308 minecraft:gray_concrete
fill 424 144 310 424 144 313 minecraft:gray_concrete
fill 425 144 276 428 144 276 minecraft:gray_concrete
setblock 426 144 316 minecraft:gray_concrete
fill 428 144 316 431 144 316 minecraft:gray_concrete
setblock 430 144 276 minecraft:gray_concrete
fill 435 144 276 438 144 276 minecraft:gray_concrete
setblock 436 144 316 minecraft:gray_concrete
fill 438 144 316 441 144 316 minecraft:gray_concrete
setblock 440 144 276 minecraft:gray_concrete
fill 445 144 276 448 144 276 minecraft:gray_concrete
setblock 446 144 316 minecraft:gray_concrete
fill 448 144 316 451 144 316 minecraft:gray_concrete
setblock 450 144 276 minecraft:gray_concrete
fill 455 144 276 458 144 276 minecraft:gray_concrete
setblock 456 144 316 minecraft:gray_concrete
fill 458 144 316 461 144 316 minecraft:gray_concrete
setblock 460 144 276 minecraft:gray_concrete
fill 464 144 277 464 144 280 minecraft:gray_concrete
setblock 464 144 282 minecraft:gray_concrete
fill 464 144 287 464 144 290 minecraft:gray_concrete
setblock 464 144 292 minecraft:gray_concrete
fill 464 144 297 464 144 300 minecraft:gray_concrete
setblock 464 144 302 minecraft:gray_concrete
fill 464 144 307 464 144 310 minecraft:gray_concrete
setblock 464 144 312 minecraft:gray_concrete
setblock 426 145 278 minecraft:light[level=12]
setblock 426 145 285 minecraft:light[level=12]
setblock 426 145 292 minecraft:light[level=12]
setblock 426 145 299 minecraft:light[level=12]
setblock 426 145 306 minecraft:light[level=12]
setblock 426 145 313 minecraft:light[level=12]
setblock 433 145 278 minecraft:light[level=12]
setblock 433 145 285 minecraft:light[level=12]
setblock 433 145 292 minecraft:light[level=12]
setblock 433 145 299 minecraft:light[level=12]
setblock 433 145 306 minecraft:light[level=12]
setblock 433 145 313 minecraft:light[level=12]
setblock 440 145 278 minecraft:light[level=12]
setblock 440 145 285 minecraft:light[level=12]
setblock 440 145 292 minecraft:light[level=12]
setblock 440 145 299 minecraft:light[level=12]
setblock 440 145 306 minecraft:light[level=12]
setblock 440 145 313 minecraft:light[level=12]
setblock 447 145 278 minecraft:light[level=12]
setblock 447 145 285 minecraft:light[level=12]
setblock 447 145 292 minecraft:light[level=12]
setblock 447 145 299 minecraft:light[level=12]
setblock 447 145 306 minecraft:light[level=12]
setblock 447 145 313 minecraft:light[level=12]
setblock 454 145 278 minecraft:light[level=12]
setblock 454 145 285 minecraft:light[level=12]
setblock 454 145 292 minecraft:light[level=12]
setblock 454 145 299 minecraft:light[level=12]
setblock 454 145 306 minecraft:light[level=12]
setblock 454 145 313 minecraft:light[level=12]
setblock 461 145 278 minecraft:light[level=12]
setblock 461 145 285 minecraft:light[level=12]
setblock 461 145 292 minecraft:light[level=12]
setblock 461 145 299 minecraft:light[level=12]
setblock 461 145 306 minecraft:light[level=12]
setblock 461 145 313 minecraft:light[level=12]
fill 423 148 281 423 148 284 minecraft:sea_lantern
fill 423 148 291 423 148 294 minecraft:sea_lantern
fill 423 148 301 423 148 304 minecraft:sea_lantern
fill 423 148 311 423 148 314 minecraft:sea_lantern
fill 426 148 275 429 148 275 minecraft:sea_lantern
setblock 426 148 310 minecraft:black_concrete
fill 426 148 312 426 148 313 minecraft:black_concrete
fill 427 148 309 429 148 309 minecraft:black_concrete
setblock 427 148 313 minecraft:black_concrete
fill 427 148 317 430 148 317 minecraft:sea_lantern
setblock 429 148 310 minecraft:black_concrete
setblock 429 148 313 minecraft:black_concrete
fill 430 148 311 430 148 312 minecraft:black_concrete
fill 436 148 275 439 148 275 minecraft:sea_lantern
fill 436 148 311 436 149 311 minecraft:magenta_concrete
fill 437 148 317 440 148 317 minecraft:sea_lantern
fill 446 148 275 449 148 275 minecraft:sea_lantern
fill 447 148 317 450 148 317 minecraft:sea_lantern
fill 456 148 275 459 148 275 minecraft:sea_lantern
fill 457 148 317 460 148 317 minecraft:sea_lantern
fill 458 148 278 458 148 279 minecraft:black_concrete
setblock 458 148 281 minecraft:black_concrete
fill 459 148 282 460 148 282 minecraft:black_concrete
setblock 461 148 278 minecraft:black_concrete
setblock 461 148 281 minecraft:black_concrete
fill 462 148 279 462 148 280 minecraft:black_concrete
fill 465 148 276 465 148 279 minecraft:sea_lantern
fill 465 148 286 465 148 289 minecraft:sea_lantern
fill 465 148 296 465 148 299 minecraft:sea_lantern
fill 465 148 306 465 148 309 minecraft:sea_lantern
setblock 465 148 316 minecraft:sea_lantern
fill 423 149 281 423 156 284 minecraft:black_concrete
fill 423 149 291 423 156 294 minecraft:black_concrete
fill 423 149 301 423 156 304 minecraft:black_concrete
fill 423 149 311 423 156 314 minecraft:black_concrete
fill 426 149 275 429 156 275 minecraft:black_concrete
setblock 426 149 278 minecraft:light[level=15]
setblock 426 149 286 minecraft:light[level=15]
setblock 426 149 294 minecraft:light[level=15]
setblock 426 149 302 minecraft:light[level=15]
setblock 426 149 310 minecraft:light[level=15]
fill 427 149 317 430 156 317 minecraft:black_concrete
setblock 434 149 278 minecraft:light[level=15]
setblock 434 149 286 minecraft:light[level=15]
setblock 434 149 294 minecraft:light[level=15]
setblock 434 149 302 minecraft:light[level=15]
setblock 434 149 310 minecraft:light[level=15]
fill 436 149 275 439 156 275 minecraft:black_concrete
fill 437 149 317 440 156 317 minecraft:black_concrete
setblock 442 149 278 minecraft:light[level=15]
setblock 442 149 286 minecraft:light[level=15]
setblock 442 149 294 minecraft:light[level=15]
setblock 442 149 302 minecraft:light[level=15]
setblock 442 149 310 minecraft:light[level=15]
fill 446 149 275 449 156 275 minecraft:black_concrete
fill 447 149 317 450 156 317 minecraft:black_concrete
setblock 450 149 278 minecraft:light[level=15]
setblock 450 149 286 minecraft:light[level=15]
setblock 450 149 294 minecraft:light[level=15]
setblock 450 149 302 minecraft:light[level=15]
setblock 450 149 310 minecraft:light[level=15]
fill 456 149 275 459 156 275 minecraft:black_concrete
fill 457 149 317 460 156 317 minecraft:black_concrete
setblock 458 149 278 minecraft:light[level=15]
setblock 458 149 286 minecraft:light[level=15]
setblock 458 149 294 minecraft:light[level=15]
setblock 458 149 302 minecraft:light[level=15]
setblock 458 149 310 minecraft:light[level=15]
fill 465 149 276 465 156 279 minecraft:black_concrete
fill 465 149 286 465 156 289 minecraft:black_concrete
fill 465 149 296 465 156 299 minecraft:black_concrete
fill 465 149 306 465 156 309 minecraft:black_concrete
fill 465 149 316 465 156 316 minecraft:black_concrete
setblock 424 150 278 minecraft:gray_concrete
setblock 424 150 288 minecraft:gray_concrete
setblock 424 150 298 minecraft:gray_concrete
setblock 424 150 308 minecraft:gray_concrete
setblock 426 150 316 minecraft:gray_concrete
fill 427 150 296 427 151 296 minecraft:black_concrete
setblock 430 150 276 minecraft:gray_concrete
fill 436 150 277 436 164 277 minecraft:purple_wool
setblock 436 150 316 minecraft:gray_concrete
setblock 440 150 276 minecraft:gray_concrete
setblock 446 150 316 minecraft:gray_concrete
fill 449 150 279 449 151 279 minecraft:black_concrete
setblock 450 150 276 minecraft:gray_concrete
setblock 456 150 316 minecraft:gray_concrete
setblock 460 150 276 minecraft:gray_concrete
fill 460 150 278 460 179 278 minecraft:gray_concrete
fill 460 150 279 460 151 279 minecraft:black_concrete
fill 460 150 280 460 179 281 minecraft:gray_concrete
fill 460 150 292 460 151 292 minecraft:black_concrete
fill 460 150 299 460 151 299 minecraft:black_concrete
fill 460 150 303 460 151 303 minecraft:black_concrete
fill 460 150 312 460 151 312 minecraft:black_concrete
setblock 464 150 282 minecraft:gray_concrete
setblock 464 150 292 minecraft:gray_concrete
setblock 464 150 302 minecraft:gray_concrete
setblock 464 150 312 minecraft:gray_concrete
setblock 426 151 278 minecraft:light[level=12]
setblock 426 151 285 minecraft:light[level=12]
setblock 426 151 292 minecraft:light[level=12]
fill 426 151 296 426 152 296 minecraft:black_concrete
setblock 426 151 299 minecraft:light[level=12]
setblock 426 151 306 minecraft:light[level=12]
setblock 426 151 313 minecraft:light[level=12]
setblock 433 151 278 minecraft:light[level=12]
setblock 433 151 285 minecraft:light[level=12]
setblock 433 151 292 minecraft:light[level=12]
setblock 433 151 299 minecraft:light[level=12]
setblock 433 151 306 minecraft:light[level=12]
setblock 433 151 313 minecraft:light[level=12]
fill 434 151 277 435 154 277 minecraft:purple_wool
fill 437 151 277 438 154 277 minecraft:purple_wool
setblock 440 151 278 minecraft:light[level=12]
setblock 440 151 285 minecraft:light[level=12]
setblock 440 151 292 minecraft:light[level=12]
setblock 440 151 299 minecraft:light[level=12]
setblock 440 151 306 minecraft:light[level=12]
setblock 440 151 313 minecraft:light[level=12]
setblock 447 151 278 minecraft:light[level=12]
setblock 447 151 285 minecraft:light[level=12]
setblock 447 151 292 minecraft:light[level=12]
setblock 447 151 299 minecraft:light[level=12]
setblock 447 151 306 minecraft:light[level=12]
setblock 447 151 313 minecraft:light[level=12]
fill 449 151 278 449 152 278 minecraft:black_concrete
setblock 454 151 278 minecraft:light[level=12]
setblock 454 151 285 minecraft:light[level=12]
setblock 454 151 292 minecraft:light[level=12]
setblock 454 151 299 minecraft:light[level=12]
setblock 454 151 306 minecraft:light[level=12]
setblock 454 151 313 minecraft:light[level=12]
fill 460 151 313 460 152 313 minecraft:black_concrete
setblock 461 151 278 minecraft:light[level=12]
fill 461 151 279 461 152 279 minecraft:black_concrete
setblock 461 151 285 minecraft:light[level=12]
fill 461 151 288 462 152 289 minecraft:magenta_concrete
fill 461 151 292 461 152 292 minecraft:black_concrete
fill 461 151 299 461 152 299 minecraft:black_concrete
fill 461 151 303 461 152 303 minecraft:black_concrete
setblock 461 151 306 minecraft:light[level=12]
setblock 461 151 313 minecraft:light[level=12]
fill 425 152 296 425 153 296 minecraft:black_concrete
fill 449 152 277 449 153 277 minecraft:black_concrete
fill 460 152 279 460 155 279 minecraft:gray_concrete
fill 460 152 314 460 153 314 minecraft:black_concrete
fill 462 152 279 462 153 279 minecraft:black_concrete
fill 462 152 292 462 153 292 minecraft:black_concrete
fill 462 152 299 462 153 299 minecraft:black_concrete
fill 462 152 303 462 153 303 minecraft:black_concrete
fill 462 152 307 462 154 307 minecraft:purple_wool
fill 424 153 280 424 153 283 minecraft:gray_concrete
fill 424 153 290 424 153 293 minecraft:gray_concrete
fill 424 153 296 424 154 296 minecraft:black_concrete
fill 424 153 300 424 153 303 minecraft:gray_concrete
fill 424 153 310 424 153 313 minecraft:gray_concrete
fill 425 153 276 428 153 276 minecraft:gray_concrete
fill 428 153 316 431 153 316 minecraft:gray_concrete
fill 435 153 276 438 153 276 minecraft:gray_concrete
fill 438 153 316 441 153 316 minecraft:gray_concrete
fill 445 153 276 448 153 276 minecraft:gray_concrete
fill 448 153 316 451 153 316 minecraft:gray_concrete
fill 449 153 276 449 154 276 minecraft:black_concrete
fill 450 153 288 452 154 288 minecraft:light_blue_concrete
fill 451 153 287 451 154 287 minecraft:light_blue_concrete
fill 451 153 289 451 154 289 minecraft:light_blue_concrete
fill 455 153 276 458 153 276 minecraft:gray_concrete
fill 458 153 316 461 153 316 minecraft:gray_concrete
fill 460 153 315 460 154 315 minecraft:black_concrete
setblock 461 153 279 minecraft:gray_concrete
fill 462 153 305 462 154 306 minecraft:purple_wool
fill 462 153 308 462 154 309 minecraft:purple_wool
fill 463 153 279 463 154 279 minecraft:black_concrete
fill 463 153 292 463 154 292 minecraft:black_concrete
fill 463 153 299 463 154 299 minecraft:black_concrete
fill 463 153 303 463 154 303 minecraft:black_concrete
fill 464 153 277 464 153 280 minecraft:gray_concrete
fill 464 153 287 464 153 290 minecraft:gray_concrete
fill 464 153 297 464 153 300 minecraft:gray_concrete
fill 464 153 307 464 153 310 minecraft:gray_concrete
setblock 427 154 283 minecraft:sea_lantern
setblock 427 154 289 minecraft:sea_lantern
setblock 427 154 295 minecraft:sea_lantern
setblock 427 154 301 minecraft:sea_lantern
setblock 427 154 307 minecraft:sea_lantern
setblock 427 154 313 minecraft:sea_lantern
setblock 431 154 279 minecraft:sea_lantern
setblock 433 154 313 minecraft:sea_lantern
setblock 437 154 279 minecraft:sea_lantern
setblock 439 154 313 minecraft:sea_lantern
setblock 443 154 279 minecraft:sea_lantern
setblock 445 154 313 minecraft:sea_lantern
setblock 449 154 279 minecraft:sea_lantern
setblock 451 154 313 minecraft:sea_lantern
setblock 455 154 279 minecraft:sea_lantern
setblock 457 154 313 minecraft:sea_lantern
setblock 461 154 279 minecraft:sea_lantern
setblock 461 154 285 minecraft:sea_lantern
setblock 461 154 291 minecraft:sea_lantern
setblock 461 154 297 minecraft:sea_lantern
setblock 461 154 303 minecraft:sea_lantern
setblock 461 154 309 minecraft:sea_lantern
setblock 424 155 276 minecraft:gray_concrete
fill 424 155 278 424 155 279 minecraft:gray_concrete
fill 424 155 281 424 155 282 minecraft:gray_concrete
fill 424 155 284 424 155 285 minecraft:gray_concrete
fill 424 155 288 424 156 288 minecraft:gray_concrete
fill 424 155 290 424 155 291 minecraft:gray_concrete
fill 424 155 293 424 155 294 minecraft:gray_concrete
fill 424 155 296 425 155 296 minecraft:gray_concrete
fill 424 155 299 424 155 300 minecraft:gray_concrete
fill 424 155 302 424 155 303 minecraft:gray_concrete
fill 424 155 305 424 155 306 minecraft:gray_concrete
fill 424 155 308 424 155 309 minecraft:gray_concrete
fill 424 155 311 424 155 312 minecraft:gray_concrete
fill 424 155 314 424 155 315 minecraft:gray_concrete
fill 425 155 277 425 155 278 minecraft:gray_concrete
fill 425 155 280 425 155 281 minecraft:gray_concrete
fill 425 155 283 425 155 284 minecraft:gray_concrete
fill 425 155 286 425 155 287 minecraft:gray_concrete
fill 425 155 289 425 155 290 minecraft:gray_concrete
fill 425 155 292 425 155 293 minecraft:gray_concrete
fill 425 155 295 426 155 295 minecraft:gray_concrete
fill 425 155 298 425 155 299 minecraft:gray_concrete
fill 425 155 301 425 155 302 minecraft:gray_concrete
fill 425 155 304 425 155 305 minecraft:gray_concrete
fill 425 155 307 425 155 308 minecraft:gray_concrete
fill 425 155 310 425 155 311 minecraft:gray_concrete
fill 425 155 313 425 155 314 minecraft:gray_concrete
fill 426 155 276 426 155 277 minecraft:gray_concrete
fill 426 155 279 426 155 280 minecraft:gray_concrete
fill 426 155 282 426 155 283 minecraft:gray_concrete
fill 426 155 285 426 155 286 minecraft:gray_concrete
fill 426 155 288 426 155 289 minecraft:gray_concrete
fill 426 155 291 426 155 292 minecraft:gray_concrete
fill 426 155 294 427 155 294 minecraft:gray_concrete
fill 426 155 297 426 155 298 minecraft:gray_concrete
fill 426 155 300 426 155 301 minecraft:gray_concrete
fill 426 155 303 426 155 304 minecraft:gray_concrete
fill 426 155 306 426 155 307 minecraft:gray_concrete
fill 426 155 309 426 155 310 minecraft:gray_concrete
fill 426 155 312 426 155 313 minecraft:gray_concrete
fill 426 155 315 426 155 316 minecraft:gray_concrete
setblock 427 155 276 minecraft:gray_concrete
fill 427 155 278 427 155 279 minecraft:gray_concrete
fill 427 155 281 427 155 282 minecraft:gray_concrete
fill 427 155 284 427 155 285 minecraft:gray_concrete
fill 427 155 287 427 155 288 minecraft:gray_concrete
fill 427 155 290 427 155 291 minecraft:gray_concrete
setblock 427 155 293 minecraft:gray_concrete
fill 427 155 296 427 155 297 minecraft:gray_concrete
fill 427 155 299 427 155 300 minecraft:gray_concrete
fill 427 155 302 427 155 303 minecraft:gray_concrete
fill 427 155 305 427 155 306 minecraft:gray_concrete
fill 427 155 308 427 155 309 minecraft:gray_concrete
fill 427 155 314 427 155 315 minecraft:gray_concrete
fill 428 155 277 428 155 278 minecraft:gray_concrete
setblock 428 155 314 minecraft:gray_concrete
fill 428 155 316 429 155 316 minecraft:gray_concrete
fill 429 155 276 429 155 277 minecraft:gray_concrete
fill 429 155 279 430 155 279 minecraft:gray_concrete
setblock 429 155 313 minecraft:gray_concrete
fill 429 155 315 430 155 315 minecraft:gray_concrete
fill 430 155 276 430 156 276 minecraft:gray_concrete
fill 430 155 278 431 155 278 minecraft:gray_concrete
fill 430 155 314 431 155 314 minecraft:gray_concrete
fill 431 155 277 432 155 277 minecraft:gray_concrete
fill 431 155 313 432 155 313 minecraft:gray_concrete
fill 431 155 316 432 155 316 minecraft:gray_concrete
fill 432 155 276 433 155 276 minecraft:gray_concrete
fill 432 155 279 433 155 279 minecraft:gray_concrete
fill 432 155 315 433 155 315 minecraft:gray_concrete
fill 433 155 278 434 155 278 minecraft:gray_concrete
fill 433 155 314 434 155 314 minecraft:gray_concrete
fill 434 155 277 435 155 277 minecraft:gray_concrete
fill 434 155 313 435 155 313 minecraft:gray_concrete
setblock 434 155 316 minecraft:gray_concrete
fill 435 155 276 436 155 276 minecraft:gray_concrete
fill 435 155 278 435 156 278 minecraft:iron_block
fill 435 155 279 436 155 279 minecraft:gray_concrete
fill 435 155 315 436 155 315 minecraft:gray_concrete
fill 436 155 278 437 155 278 minecraft:gray_concrete
fill 436 155 314 437 155 314 minecraft:gray_concrete
fill 437 155 277 438 155 277 minecraft:gray_concrete
fill 437 155 313 438 155 313 minecraft:gray_concrete
fill 437 155 316 438 155 316 minecraft:gray_concrete
fill 438 155 276 439 155 276 minecraft:gray_concrete
fill 438 155 279 439 155 279 minecraft:gray_concrete
fill 438 155 315 439 155 315 minecraft:gray_concrete
fill 439 155 278 440 155 278 minecraft:gray_concrete
fill 439 155 314 440 155 314 minecraft:gray_concrete
fill 440 155 277 441 155 277 minecraft:gray_concrete
fill 440 155 313 441 155 313 minecraft:gray_concrete
fill 440 155 316 441 155 316 minecraft:gray_concrete
fill 441 155 279 442 155 279 minecraft:gray_concrete
fill 441 155 315 442 155 315 minecraft:gray_concrete
setblock 442 155 276 minecraft:gray_concrete
fill 442 155 278 443 155 278 minecraft:gray_concrete
fill 442 155 314 443 155 314 minecraft:gray_concrete
fill 443 155 277 444 155 277 minecraft:gray_concrete
fill 443 155 313 444 155 313 minecraft:gray_concrete
fill 443 155 316 444 155 316 minecraft:gray_concrete
fill 444 155 276 445 155 276 minecraft:gray_concrete
fill 444 155 279 445 155 279 minecraft:gray_concrete
fill 444 155 315 445 155 315 minecraft:gray_concrete
fill 445 155 278 446 155 278 minecraft:gray_concrete
fill 445 155 314 446 155 314 minecraft:gray_concrete
fill 446 155 277 447 155 277 minecraft:gray_concrete
fill 446 155 313 447 155 313 minecraft:gray_concrete
fill 446 155 316 447 155 316 minecraft:gray_concrete
fill 447 155 276 448 155 276 minecraft:gray_concrete
fill 447 155 279 448 155 279 minecraft:gray_concrete
fill 447 155 315 448 155 315 minecraft:gray_concrete
fill 448 155 278 449 155 278 minecraft:gray_concrete
fill 448 155 314 449 155 314 minecraft:gray_concrete
fill 449 155 277 450 155 277 minecraft:gray_concrete
fill 449 155 313 450 155 313 minecraft:gray_concrete
fill 449 155 316 450 155 316 minecraft:gray_concrete
fill 450 155 276 450 156 276 minecraft:gray_concrete
fill 450 155 279 451 155 279 minecraft:gray_concrete
fill 450 155 315 451 155 315 minecraft:gray_concrete
fill 451 155 278 452 155 278 minecraft:gray_concrete
fill 451 155 314 452 155 314 minecraft:gray_concrete
fill 452 155 277 453 155 277 minecraft:gray_concrete
fill 452 155 313 453 155 313 minecraft:gray_concrete
fill 452 155 316 453 155 316 minecraft:gray_concrete
fill 453 155 276 454 155 276 minecraft:gray_concrete
fill 453 155 279 454 155 279 minecraft:gray_concrete
fill 453 155 315 454 155 315 minecraft:gray_concrete
fill 454 155 278 455 155 278 minecraft:gray_concrete
fill 454 155 285 454 156 285 minecraft:lime_concrete
fill 454 155 314 455 155 314 minecraft:gray_concrete
fill 455 155 277 456 155 277 minecraft:gray_concrete
fill 455 155 313 456 155 313 minecraft:gray_concrete
fill 456 155 276 457 155 276 minecraft:gray_concrete
fill 456 155 279 457 155 279 minecraft:gray_concrete
fill 456 155 315 456 155 316 minecraft:gray_concrete
fill 457 155 278 458 155 278 minecraft:gray_concrete
fill 457 155 314 457 155 315 minecraft:gray_concrete
fill 458 155 277 459 155 277 minecraft:gray_concrete
fill 458 155 313 458 155 314 minecraft:gray_concrete
fill 458 155 316 459 155 316 minecraft:gray_concrete
fill 459 155 276 460 155 276 minecraft:gray_concrete
setblock 459 155 313 minecraft:gray_concrete
fill 459 155 315 460 155 315 minecraft:gray_concrete
fill 460 155 314 461 155 314 minecraft:gray_concrete
fill 461 155 277 461 155 279 minecraft:gray_concrete
setblock 461 155 281 minecraft:gray_concrete
fill 461 155 283 461 155 284 minecraft:gray_concrete
fill 461 155 286 461 155 287 minecraft:gray_concrete
fill 461 155 289 461 155 290 minecraft:gray_concrete
fill 461 155 292 461 155 293 minecraft:gray_concrete
fill 461 155 295 461 155 296 minecraft:gray_concrete
fill 461 155 298 461 155 299 minecraft:gray_concrete
fill 461 155 301 461 155 302 minecraft:gray_concrete
fill 461 155 304 461 155 305 minecraft:gray_concrete
fill 461 155 307 461 155 308 minecraft:gray_concrete
fill 461 155 310 461 155 311 minecraft:gray_concrete
fill 461 155 313 462 155 313 minecraft:gray_concrete
fill 461 155 316 462 155 316 minecraft:gray_concrete
fill 462 155 276 462 155 277 minecraft:gray_concrete
fill 462 155 279 462 155 280 minecraft:gray_concrete
fill 462 155 282 462 155 283 minecraft:gray_concrete
fill 462 155 285 462 155 286 minecraft:gray_concrete
fill 462 155 288 462 155 289 minecraft:gray_concrete
fill 462 155 291 462 155 292 minecraft:gray_concrete
fill 462 155 294 462 155 295 minecraft:gray_concrete
fill 462 155 297 462 155 298 minecraft:gray_concrete
fill 462 155 300 462 155 301 minecraft:gray_concrete
fill 462 155 303 462 155 304 minecraft:gray_concrete
fill 462 155 305 462 161 305 minecraft:purple_wool
fill 462 155 306 462 155 307 minecraft:gray_concrete
fill 462 155 308 462 161 308 minecraft:purple_wool
fill 462 155 309 462 155 310 minecraft:gray_concrete
fill 462 155 312 463 155 312 minecraft:gray_concrete
fill 462 155 315 463 155 315 minecraft:gray_concrete
setblock 463 155 276 minecraft:gray_concrete
fill 463 155 278 463 155 279 minecraft:gray_concrete
fill 463 155 281 463 155 282 minecraft:gray_concrete
fill 463 155 284 463 155 285 minecraft:gray_concrete
fill 463 155 287 463 155 288 minecraft:gray_concrete
fill 463 155 290 463 155 291 minecraft:gray_concrete
fill 463 155 293 463 155 294 minecraft:gray_concrete
fill 463 155 296 463 155 297 minecraft:gray_concrete
fill 463 155 299 463 155 300 minecraft:gray_concrete
fill 463 155 302 463 155 303 minecraft:gray_concrete
fill 463 155 305 463 155 306 minecraft:gray_concrete
fill 463 155 308 463 155 309 minecraft:gray_concrete
fill 463 155 311 464 155 311 minecraft:gray_concrete
fill 463 155 314 464 155 314 minecraft:gray_concrete
fill 464 155 277 464 155 278 minecraft:gray_concrete
fill 464 155 280 464 155 281 minecraft:gray_concrete
setblock 464 155 284 minecraft:gray_concrete
fill 464 155 286 464 155 287 minecraft:gray_concrete
fill 464 155 289 464 155 290 minecraft:gray_concrete
fill 464 155 292 464 156 292 minecraft:gray_concrete
fill 464 155 295 464 155 296 minecraft:gray_concrete
fill 464 155 298 464 155 299 minecraft:gray_concrete
fill 464 155 301 464 155 302 minecraft:gray_concrete
fill 464 155 304 464 155 305 minecraft:gray_concrete
fill 464 155 307 464 155 308 minecraft:gray_concrete
setblock 464 155 310 minecraft:gray_concrete
setblock 464 155 316 minecraft:gray_concrete
setblock 424 156 278 minecraft:gray_concrete
setblock 424 156 298 minecraft:gray_concrete
setblock 424 156 308 minecraft:gray_concrete
setblock 426 156 310 minecraft:black_concrete
fill 426 156 311 426 179 311 minecraft:gray_concrete
fill 426 156 312 426 156 313 minecraft:black_concrete
setblock 426 156 316 minecraft:gray_concrete
fill 427 156 279 427 156 313 minecraft:magenta_concrete
fill 428 156 279 461 156 279 minecraft:magenta_concrete
fill 428 156 309 429 156 309 minecraft:black_concrete
fill 428 156 310 428 179 312 minecraft:gray_concrete
fill 428 156 313 461 156 313 minecraft:magenta_concrete
setblock 429 156 310 minecraft:black_concrete
fill 429 156 311 429 179 312 minecraft:gray_concrete
fill 430 156 311 430 156 312 minecraft:black_concrete
fill 434 156 277 435 164 277 minecraft:purple_wool
setblock 435 156 276 minecraft:iron_block
setblock 436 156 316 minecraft:gray_concrete
fill 437 156 277 438 164 277 minecraft:purple_wool
setblock 440 156 276 minecraft:gray_concrete
setblock 446 156 316 minecraft:gray_concrete
setblock 456 156 316 minecraft:gray_concrete
setblock 458 156 278 minecraft:black_concrete
setblock 458 156 281 minecraft:black_concrete
fill 459 156 278 459 179 278 minecraft:gray_concrete
fill 459 156 282 460 156 282 minecraft:black_concrete
setblock 460 156 276 minecraft:gray_concrete
setblock 461 156 278 minecraft:black_concrete
fill 461 156 280 461 156 312 minecraft:magenta_concrete
fill 462 156 279 462 156 280 minecraft:black_concrete
fill 462 156 306 462 161 307 minecraft:purple_wool
fill 462 156 309 462 161 309 minecraft:purple_wool
setblock 464 156 282 minecraft:gray_concrete
setblock 464 156 302 minecraft:gray_concrete
setblock 464 156 312 minecraft:gray_concrete
fill 423 157 281 423 157 284 minecraft:sea_lantern
fill 423 157 291 423 157 294 minecraft:sea_lantern
fill 423 157 301 423 157 304 minecraft:sea_lantern
fill 423 157 311 423 157 314 minecraft:sea_lantern
fill 426 157 275 429 157 275 minecraft:sea_lantern
setblock 426 157 278 minecraft:light[level=15]
setblock 426 157 285 minecraft:light[level=12]
setblock 426 157 286 minecraft:light[level=15]
setblock 426 157 292 minecraft:light[level=12]
setblock 426 157 294 minecraft:light[level=15]
setblock 426 157 299 minecraft:light[level=12]
setblock 426 157 302 minecraft:light[level=15]
setblock 426 157 306 minecraft:light[level=12]
setblock 426 157 310 minecraft:light[level=15]
setblock 426 157 313 minecraft:light[level=12]
fill 427 157 310 427 179 312 minecraft:gray_concrete
fill 427 157 317 430 157 317 minecraft:sea_lantern
fill 428 157 313 428 179 313 minecraft:gray_concrete
setblock 433 157 278 minecraft:light[level=12]
setblock 433 157 285 minecraft:light[level=12]
setblock 433 157 292 minecraft:light[level=12]
setblock 433 157 299 minecraft:light[level=12]
setblock 433 157 306 minecraft:light[level=12]
setblock 433 157 313 minecraft:light[level=12]
setblock 434 157 278 minecraft:light[level=15]
setblock 434 157 286 minecraft:light[level=15]
setblock 434 157 294 minecraft:light[level=15]
setblock 434 157 302 minecraft:light[level=15]
setblock 434 157 310 minecraft:light[level=15]
fill 436 157 275 439 157 275 minecraft:sea_lantern
fill 437 157 317 440 157 317 minecraft:sea_lantern
setblock 440 157 278 minecraft:light[level=12]
setblock 440 157 285 minecraft:light[level=12]
setblock 440 157 292 minecraft:light[level=12]
setblock 440 157 299 minecraft:light[level=12]
setblock 440 157 306 minecraft:light[level=12]
setblock 440 157 313 minecraft:light[level=12]
setblock 442 157 278 minecraft:light[level=15]
setblock 442 157 286 minecraft:light[level=15]
setblock 442 157 294 minecraft:light[level=15]
setblock 442 157 302 minecraft:light[level=15]
setblock 442 157 310 minecraft:light[level=15]
fill 446 157 275 449 157 275 minecraft:sea_lantern
setblock 447 157 278 minecraft:light[level=12]
setblock 447 157 285 minecraft:light[level=12]
setblock 447 157 292 minecraft:light[level=12]
setblock 447 157 299 minecraft:light[level=12]
setblock 447 157 306 minecraft:light[level=12]
setblock 447 157 313 minecraft:light[level=12]
fill 447 157 317 450 157 317 minecraft:sea_lantern
setblock 450 157 278 minecraft:light[level=15]
setblock 450 157 286 minecraft:light[level=15]
setblock 450 157 294 minecraft:light[level=15]
setblock 450 157 302 minecraft:light[level=15]
setblock 450 157 310 minecraft:light[level=15]
setblock 454 157 278 minecraft:light[level=12]
setblock 454 157 285 minecraft:light[level=12]
setblock 454 157 292 minecraft:light[level=12]
setblock 454 157 299 minecraft:light[level=12]
setblock 454 157 306 minecraft:light[level=12]
setblock 454 157 313 minecraft:light[level=12]
fill 456 157 275 459 157 275 minecraft:sea_lantern
fill 457 157 317 460 157 317 minecraft:sea_lantern
setblock 458 157 278 minecraft:light[level=15]
setblock 458 157 286 minecraft:light[level=15]
setblock 458 157 294 minecraft:light[level=15]
setblock 458 157 302 minecraft:light[level=15]
setblock 458 157 310 minecraft:light[level=15]
fill 459 157 279 461 179 279 minecraft:gray_concrete
setblock 461 157 278 minecraft:light[level=12]
fill 461 157 280 461 179 280 minecraft:gray_concrete
setblock 461 157 285 minecraft:light[level=12]
setblock 461 157 292 minecraft:light[level=12]
setblock 461 157 299 minecraft:light[level=12]
setblock 461 157 306 minecraft:light[level=12]
setblock 461 157 313 minecraft:light[level=12]
fill 465 157 276 465 157 279 minecraft:sea_lantern
fill 465 157 286 465 157 289 minecraft:sea_lantern
fill 465 157 296 465 157 299 minecraft:sea_lantern
fill 465 157 306 465 157 309 minecraft:sea_lantern
setblock 465 157 316 minecraft:sea_lantern
fill 423 158 281 423 165 284 minecraft:black_concrete
fill 423 158 291 423 165 294 minecraft:black_concrete
fill 423 158 301 423 165 304 minecraft:black_concrete
fill 423 158 311 423 165 314 minecraft:black_concrete
fill 426 158 275 429 165 275 minecraft:black_concrete
fill 427 158 317 430 165 317 minecraft:black_concrete
fill 436 158 275 439 165 275 minecraft:black_concrete
fill 437 158 317 440 165 317 minecraft:black_concrete
fill 446 158 275 449 165 275 minecraft:black_concrete
fill 447 158 317 450 165 317 minecraft:black_concrete
fill 456 158 275 459 165 275 minecraft:black_concrete
fill 457 158 317 460 165 317 minecraft:black_concrete
fill 465 158 276 465 165 279 minecraft:black_concrete
fill 465 158 286 465 165 289 minecraft:black_concrete
fill 465 158 296 465 165 299 minecraft:black_concrete
fill 465 158 306 465 165 309 minecraft:black_concrete
fill 465 158 316 465 165 316 minecraft:black_concrete
fill 425 161 291 425 174 291 minecraft:purple_wool
setblock 424 162 278 minecraft:gray_concrete
fill 424 162 280 424 162 283 minecraft:gray_concrete
setblock 424 162 288 minecraft:gray_concrete
fill 424 162 290 424 162 293 minecraft:gray_concrete
setblock 424 162 298 minecraft:gray_concrete
fill 424 162 300 424 162 303 minecraft:gray_concrete
setblock 424 162 308 minecraft:gray_concrete
fill 424 162 310 424 162 313 minecraft:gray_concrete
fill 425 162 276 428 162 276 minecraft:gray_concrete
fill 425 162 289 425 174 290 minecraft:purple_wool
fill 425 162 292 425 174 293 minecraft:purple_wool
setblock 426 162 316 minecraft:gray_concrete
fill 428 162 316 431 162 316 minecraft:gray_concrete
setblock 430 162 276 minecraft:gray_concrete
fill 435 162 276 438 162 276 minecraft:gray_concrete
setblock 436 162 316 minecraft:gray_concrete
fill 438 162 316 441 162 316 minecraft:gray_concrete
setblock 440 162 276 minecraft:gray_concrete
fill 445 162 276 448 162 276 minecraft:gray_concrete
setblock 446 162 316 minecraft:gray_concrete
fill 448 162 316 451 162 316 minecraft:gray_concrete
setblock 450 162 276 minecraft:gray_concrete
fill 453 162 295 454 163 296 minecraft:magenta_concrete
fill 455 162 276 458 162 276 minecraft:gray_concrete
fill 455 162 295 455 163 295 minecraft:magenta_concrete
setblock 456 162 316 minecraft:gray_concrete
fill 458 162 316 461 162 316 minecraft:gray_concrete
setblock 460 162 276 minecraft:gray_concrete
fill 462 162 304 462 163 310 minecraft:iron_block
fill 464 162 277 464 162 280 minecraft:gray_concrete
setblock 464 162 282 minecraft:gray_concrete
fill 464 162 287 464 162 290 minecraft:gray_concrete
setblock 464 162 292 minecraft:gray_concrete
fill 464 162 297 464 162 300 minecraft:gray_concrete
setblock 464 162 302 minecraft:gray_concrete
fill 464 162 307 464 162 310 minecraft:gray_concrete
setblock 464 162 312 minecraft:gray_concrete
setblock 426 163 278 minecraft:light[level=12]
setblock 426 163 285 minecraft:light[level=12]
setblock 426 163 292 minecraft:light[level=12]
setblock 426 163 299 minecraft:light[level=12]
setblock 426 163 306 minecraft:light[level=12]
setblock 426 163 313 minecraft:light[level=12]
setblock 433 163 278 minecraft:light[level=12]
setblock 433 163 285 minecraft:light[level=12]
setblock 433 163 292 minecraft:light[level=12]
setblock 433 163 299 minecraft:light[level=12]
setblock 433 163 306 minecraft:light[level=12]
setblock 433 163 313 minecraft:light[level=12]
setblock 440 163 278 minecraft:light[level=12]
setblock 440 163 285 minecraft:light[level=12]
setblock 440 163 292 minecraft:light[level=12]
setblock 440 163 299 minecraft:light[level=12]
setblock 440 163 306 minecraft:light[level=12]
setblock 440 163 313 minecraft:light[level=12]
fill 445 163 276 445 164 278 minecraft:iron_block
setblock 447 163 278 minecraft:light[level=12]
setblock 447 163 285 minecraft:light[level=12]
setblock 447 163 292 minecraft:light[level=12]
setblock 447 163 299 minecraft:light[level=12]
setblock 447 163 306 minecraft:light[level=12]
setblock 447 163 313 minecraft:light[level=12]
setblock 454 163 278 minecraft:light[level=12]
setblock 454 163 285 minecraft:light[level=12]
setblock 454 163 292 minecraft:light[level=12]
setblock 454 163 299 minecraft:light[level=12]
setblock 454 163 306 minecraft:light[level=12]
setblock 454 163 313 minecraft:light[level=12]
setblock 461 163 278 minecraft:light[level=12]
setblock 461 163 285 minecraft:light[level=12]
setblock 461 163 292 minecraft:light[level=12]
setblock 461 163 299 minecraft:light[level=12]
setblock 461 163 306 minecraft:light[level=12]
setblock 461 163 313 minecraft:light[level=12]
setblock 426 164 310 minecraft:black_concrete
fill 426 164 312 426 164 313 minecraft:black_concrete
fill 427 164 309 429 164 309 minecraft:black_concrete
setblock 427 164 313 minecraft:black_concrete
setblock 429 164 310 minecraft:black_concrete
setblock 429 164 313 minecraft:black_concrete
fill 430 164 311 430 164 312 minecraft:black_concrete
fill 433 164 313 433 165 315 minecraft:iron_block
fill 458 164 278 458 164 279 minecraft:black_concrete
setblock 458 164 281 minecraft:black_concrete
fill 459 164 282 460 164 282 minecraft:black_concrete
setblock 461 164 278 minecraft:black_concrete
setblock 461 164 281 minecraft:black_concrete
fill 462 164 279 462 164 280 minecraft:black_concrete
setblock 426 165 278 minecraft:light[level=15]
setblock 426 165 286 minecraft:light[level=15]
setblock 426 165 294 minecraft:light[level=15]
setblock 426 165 302 minecraft:light[level=15]
setblock 426 165 310 minecraft:light[level=15]
fill 433 165 277 439 166 277 minecraft:iron_block
setblock 434 165 278 minecraft:light[level=15]
setblock 434 165 286 minecraft:light[level=15]
setblock 434 165 294 minecraft:light[level=15]
setblock 434 165 302 minecraft:light[level=15]
setblock 434 165 310 minecraft:light[level=15]
setblock 442 165 278 minecraft:light[level=15]
setblock 442 165 286 minecraft:light[level=15]
setblock 442 165 294 minecraft:light[level=15]
setblock 442 165 302 minecraft:light[level=15]
setblock 442 165 310 minecraft:light[level=15]
setblock 450 165 278 minecraft:light[level=15]
setblock 450 165 286 minecraft:light[level=15]
setblock 450 165 294 minecraft:light[level=15]
setblock 450 165 302 minecraft:light[level=15]
setblock 450 165 310 minecraft:light[level=15]
setblock 458 165 278 minecraft:light[level=15]
setblock 458 165 286 minecraft:light[level=15]
setblock 458 165 294 minecraft:light[level=15]
setblock 458 165 302 minecraft:light[level=15]
setblock 458 165 310 minecraft:light[level=15]
fill 423 166 281 423 166 284 minecraft:sea_lantern
fill 423 166 291 423 166 294 minecraft:sea_lantern
fill 423 166 301 423 166 304 minecraft:sea_lantern
fill 423 166 311 423 166 314 minecraft:sea_lantern
fill 426 166 275 429 166 275 minecraft:sea_lantern
fill 427 166 317 430 166 317 minecraft:sea_lantern
fill 436 166 275 439 166 275 minecraft:sea_lantern
fill 437 166 317 440 166 317 minecraft:sea_lantern
fill 446 166 275 449 166 275 minecraft:sea_lantern
fill 447 166 317 450 166 317 minecraft:sea_lantern
fill 456 166 275 459 166 275 minecraft:sea_lantern
fill 457 166 317 460 166 317 minecraft:sea_lantern
fill 465 166 276 465 166 279 minecraft:sea_lantern
fill 465 166 286 465 166 289 minecraft:sea_lantern
fill 465 166 296 465 166 299 minecraft:sea_lantern
fill 465 166 306 465 166 309 minecraft:sea_lantern
setblock 465 166 316 minecraft:sea_lantern
fill 423 167 281 423 174 284 minecraft:black_concrete
fill 423 167 291 423 174 294 minecraft:black_concrete
fill 423 167 301 423 174 304 minecraft:black_concrete
fill 423 167 311 423 174 314 minecraft:black_concrete
fill 426 167 275 429 174 275 minecraft:black_concrete
fill 427 167 317 430 174 317 minecraft:black_concrete
fill 436 167 275 439 174 275 minecraft:black_concrete
fill 437 167 317 440 174 317 minecraft:black_concrete
fill 446 167 275 449 174 275 minecraft:black_concrete
fill 447 167 317 450 174 317 minecraft:black_concrete
fill 456 167 275 459 174 275 minecraft:black_concrete
fill 457 167 317 460 174 317 minecraft:black_concrete
fill 465 167 276 465 174 279 minecraft:black_concrete
fill 465 167 286 465 174 289 minecraft:black_concrete
fill 465 167 296 465 174 299 minecraft:black_concrete
fill 465 167 306 465 174 309 minecraft:black_concrete
fill 465 167 316 465 174 316 minecraft:black_concrete
setblock 424 168 278 minecraft:gray_concrete
setblock 424 168 288 minecraft:gray_concrete
setblock 424 168 298 minecraft:gray_concrete
setblock 424 168 308 minecraft:gray_concrete
setblock 426 168 316 minecraft:gray_concrete
setblock 430 168 276 minecraft:gray_concrete
setblock 436 168 316 minecraft:gray_concrete
setblock 440 168 276 minecraft:gray_concrete
setblock 446 168 316 minecraft:gray_concrete
setblock 450 168 276 minecraft:gray_concrete
setblock 456 168 316 minecraft:gray_concrete
setblock 460 168 276 minecraft:gray_concrete
setblock 464 168 282 minecraft:gray_concrete
setblock 464 168 292 minecraft:gray_concrete
setblock 464 168 302 minecraft:gray_concrete
setblock 464 168 312 minecraft:gray_concrete
setblock 426 169 278 minecraft:light[level=12]
setblock 426 169 285 minecraft:light[level=12]
setblock 426 169 292 minecraft:light[level=12]
setblock 426 169 299 minecraft:light[level=12]
setblock 426 169 306 minecraft:light[level=12]
setblock 426 169 313 minecraft:light[level=12]
setblock 433 169 278 minecraft:light[level=12]
setblock 433 169 285 minecraft:light[level=12]
setblock 433 169 292 minecraft:light[level=12]
setblock 433 169 299 minecraft:light[level=12]
setblock 433 169 306 minecraft:light[level=12]
setblock 433 169 313 minecraft:light[level=12]
setblock 440 169 278 minecraft:light[level=12]
setblock 440 169 285 minecraft:light[level=12]
setblock 440 169 292 minecraft:light[level=12]
setblock 440 169 299 minecraft:light[level=12]
setblock 440 169 306 minecraft:light[level=12]
setblock 440 169 313 minecraft:light[level=12]
setblock 447 169 278 minecraft:light[level=12]
setblock 447 169 285 minecraft:light[level=12]
setblock 447 169 292 minecraft:light[level=12]
setblock 447 169 299 minecraft:light[level=12]
setblock 447 169 306 minecraft:light[level=12]
setblock 447 169 313 minecraft:light[level=12]
setblock 454 169 278 minecraft:light[level=12]
setblock 454 169 285 minecraft:light[level=12]
setblock 454 169 292 minecraft:light[level=12]
setblock 454 169 299 minecraft:light[level=12]
setblock 454 169 306 minecraft:light[level=12]
setblock 454 169 313 minecraft:light[level=12]
setblock 461 169 278 minecraft:light[level=12]
setblock 461 169 285 minecraft:light[level=12]
setblock 461 169 292 minecraft:light[level=12]
setblock 461 169 299 minecraft:light[level=12]
setblock 461 169 306 minecraft:light[level=12]
setblock 461 169 313 minecraft:light[level=12]
fill 454 170 302 454 171 302 minecraft:yellow_concrete
fill 424 171 280 424 171 283 minecraft:gray_concrete
fill 424 171 290 424 171 293 minecraft:gray_concrete
fill 424 171 300 424 171 303 minecraft:gray_concrete
fill 424 171 310 424 171 313 minecraft:gray_concrete
fill 425 171 276 428 171 276 minecraft:gray_concrete
fill 428 171 316 431 171 316 minecraft:gray_concrete
fill 435 171 276 438 171 276 minecraft:gray_concrete
fill 438 171 316 441 171 316 minecraft:gray_concrete
fill 445 171 276 448 171 276 minecraft:gray_concrete
fill 448 171 316 451 171 316 minecraft:gray_concrete
fill 455 171 276 458 171 276 minecraft:gray_concrete
fill 458 171 316 461 171 316 minecraft:gray_concrete
fill 464 171 277 464 171 280 minecraft:gray_concrete
fill 464 171 287 464 171 290 minecraft:gray_concrete
fill 464 171 297 464 171 300 minecraft:gray_concrete
fill 464 171 307 464 171 310 minecraft:gray_concrete
setblock 426 172 310 minecraft:black_concrete
fill 426 172 312 426 172 313 minecraft:black_concrete
fill 427 172 301 427 173 303 minecraft:light_blue_concrete
fill 427 172 309 429 172 309 minecraft:black_concrete
setblock 427 172 313 minecraft:black_concrete
fill 428 172 301 428 173 302 minecraft:light_blue_concrete
setblock 429 172 310 minecraft:black_concrete
setblock 429 172 313 minecraft:black_concrete
fill 430 172 311 430 172 312 minecraft:black_concrete
fill 458 172 278 458 172 279 minecraft:black_concrete
setblock 458 172 281 minecraft:black_concrete
fill 459 172 282 460 172 282 minecraft:black_concrete
setblock 461 172 278 minecraft:black_concrete
setblock 461 172 281 minecraft:black_concrete
fill 462 172 279 462 172 280 minecraft:black_concrete
setblock 426 173 278 minecraft:light[level=15]
setblock 426 173 286 minecraft:light[level=15]
setblock 426 173 294 minecraft:light[level=15]
setblock 426 173 302 minecraft:light[level=15]
setblock 426 173 310 minecraft:light[level=15]
setblock 434 173 278 minecraft:light[level=15]
setblock 434 173 286 minecraft:light[level=15]
setblock 434 173 294 minecraft:light[level=15]
setblock 434 173 302 minecraft:light[level=15]
setblock 434 173 310 minecraft:light[level=15]
setblock 442 173 278 minecraft:light[level=15]
setblock 442 173 286 minecraft:light[level=15]
setblock 442 173 294 minecraft:light[level=15]
setblock 442 173 302 minecraft:light[level=15]
setblock 442 173 310 minecraft:light[level=15]
setblock 450 173 278 minecraft:light[level=15]
setblock 450 173 286 minecraft:light[level=15]
setblock 450 173 294 minecraft:light[level=15]
setblock 450 173 302 minecraft:light[level=15]
setblock 450 173 310 minecraft:light[level=15]
setblock 458 173 278 minecraft:light[level=15]
setblock 458 173 286 minecraft:light[level=15]
setblock 458 173 294 minecraft:light[level=15]
setblock 458 173 302 minecraft:light[level=15]
setblock 458 173 310 minecraft:light[level=15]
setblock 424 174 278 minecraft:gray_concrete
setblock 424 174 288 minecraft:gray_concrete
setblock 424 174 298 minecraft:gray_concrete
setblock 424 174 308 minecraft:gray_concrete
setblock 426 174 316 minecraft:gray_concrete
setblock 430 174 276 minecraft:gray_concrete
setblock 436 174 316 minecraft:gray_concrete
setblock 440 174 276 minecraft:gray_concrete
setblock 446 174 316 minecraft:gray_concrete
setblock 450 174 276 minecraft:gray_concrete
setblock 456 174 316 minecraft:gray_concrete
setblock 460 174 276 minecraft:gray_concrete
setblock 464 174 282 minecraft:gray_concrete
setblock 464 174 292 minecraft:gray_concrete
setblock 464 174 302 minecraft:gray_concrete
setblock 464 174 312 minecraft:gray_concrete
fill 423 175 281 423 175 284 minecraft:sea_lantern
fill 423 175 291 423 175 294 minecraft:sea_lantern
fill 423 175 301 423 175 304 minecraft:sea_lantern
fill 423 175 311 423 175 314 minecraft:sea_lantern
fill 425 175 288 425 176 294 minecraft:iron_block
fill 426 175 275 429 175 275 minecraft:sea_lantern
setblock 426 175 278 minecraft:light[level=12]
setblock 426 175 285 minecraft:light[level=12]
setblock 426 175 292 minecraft:light[level=12]
setblock 426 175 299 minecraft:light[level=12]
setblock 426 175 306 minecraft:light[level=12]
setblock 426 175 313 minecraft:light[level=12]
fill 427 175 317 430 175 317 minecraft:sea_lantern
setblock 433 175 278 minecraft:light[level=12]
setblock 433 175 285 minecraft:light[level=12]
setblock 433 175 292 minecraft:light[level=12]
setblock 433 175 299 minecraft:light[level=12]
setblock 433 175 306 minecraft:light[level=12]
setblock 433 175 313 minecraft:light[level=12]
fill 436 175 275 439 175 275 minecraft:sea_lantern
fill 437 175 317 440 175 317 minecraft:sea_lantern
setblock 440 175 278 minecraft:light[level=12]
setblock 440 175 285 minecraft:light[level=12]
setblock 440 175 292 minecraft:light[level=12]
setblock 440 175 299 minecraft:light[level=12]
setblock 440 175 306 minecraft:light[level=12]
setblock 440 175 313 minecraft:light[level=12]
fill 446 175 275 449 175 275 minecraft:sea_lantern
setblock 447 175 278 minecraft:light[level=12]
setblock 447 175 285 minecraft:light[level=12]
setblock 447 175 292 minecraft:light[level=12]
setblock 447 175 299 minecraft:light[level=12]
setblock 447 175 306 minecraft:light[level=12]
setblock 447 175 313 minecraft:light[level=12]
fill 447 175 317 450 175 317 minecraft:sea_lantern
setblock 454 175 278 minecraft:light[level=12]
setblock 454 175 285 minecraft:light[level=12]
setblock 454 175 292 minecraft:light[level=12]
setblock 454 175 299 minecraft:light[level=12]
setblock 454 175 306 minecraft:light[level=12]
setblock 454 175 313 minecraft:light[level=12]
fill 456 175 275 459 175 275 minecraft:sea_lantern
fill 457 175 317 460 175 317 minecraft:sea_lantern
setblock 461 175 278 minecraft:light[level=12]
setblock 461 175 285 minecraft:light[level=12]
setblock 461 175 292 minecraft:light[level=12]
setblock 461 175 299 minecraft:light[level=12]
setblock 461 175 306 minecraft:light[level=12]
setblock 461 175 313 minecraft:light[level=12]
fill 465 175 276 465 175 279 minecraft:sea_lantern
fill 465 175 286 465 175 289 minecraft:sea_lantern
fill 465 175 296 465 175 299 minecraft:sea_lantern
fill 465 175 306 465 175 309 minecraft:sea_lantern
setblock 465 175 316 minecraft:sea_lantern
fill 423 176 281 423 192 284 minecraft:black_concrete
fill 423 176 291 423 192 294 minecraft:black_concrete
fill 423 176 301 423 192 304 minecraft:black_concrete
fill 423 176 311 423 192 314 minecraft:black_concrete
fill 426 176 275 429 192 275 minecraft:black_concrete
fill 427 176 317 430 192 317 minecraft:black_concrete
fill 436 176 275 439 192 275 minecraft:black_concrete
fill 437 176 317 440 192 317 minecraft:black_concrete
fill 446 176 275 449 192 275 minecraft:black_concrete
fill 447 176 317 450 192 317 minecraft:black_concrete
fill 456 176 275 459 192 275 minecraft:black_concrete
fill 457 176 317 460 192 317 minecraft:black_concrete
fill 465 176 276 465 192 279 minecraft:black_concrete
fill 465 176 286 465 192 289 minecraft:black_concrete
fill 465 176 296 465 192 299 minecraft:black_concrete
fill 465 176 306 465 192 309 minecraft:black_concrete
fill 465 176 316 465 192 316 minecraft:black_concrete
fill 425 178 313 425 179 315 minecraft:iron_block
fill 426 178 310 426 179 310 minecraft:magenta_concrete
fill 426 178 312 426 179 312 minecraft:magenta_concrete
fill 427 178 293 427 179 293 minecraft:light_blue_concrete
fill 427 178 309 428 179 309 minecraft:magenta_concrete
fill 427 178 313 427 179 313 minecraft:magenta_concrete
fill 429 178 310 429 179 310 minecraft:magenta_concrete
fill 429 178 313 429 179 313 minecraft:magenta_concrete
fill 430 178 311 430 179 311 minecraft:magenta_concrete
fill 458 178 278 458 179 279 minecraft:magenta_concrete
fill 458 178 281 458 179 281 minecraft:magenta_concrete
fill 460 178 282 460 179 282 minecraft:magenta_concrete
fill 461 178 278 461 179 278 minecraft:magenta_concrete
fill 461 178 281 461 179 281 minecraft:magenta_concrete
fill 462 178 279 462 179 280 minecraft:magenta_concrete
setblock 426 181 278 minecraft:light[level=15]
setblock 426 181 285 minecraft:light[level=12]
setblock 426 181 286 minecraft:light[level=15]
setblock 426 181 292 minecraft:light[level=12]
setblock 426 181 294 minecraft:light[level=15]
setblock 426 181 299 minecraft:light[level=12]
setblock 426 181 302 minecraft:light[level=15]
setblock 426 181 306 minecraft:light[level=12]
setblock 426 181 310 minecraft:light[level=15]
setblock 426 181 313 minecraft:light[level=12]
setblock 433 181 278 minecraft:light[level=12]
setblock 433 181 285 minecraft:light[level=12]
setblock 433 181 292 minecraft:light[level=12]
setblock 433 181 299 minecraft:light[level=12]
setblock 433 181 306 minecraft:light[level=12]
setblock 433 181 313 minecraft:light[level=12]
setblock 434 181 278 minecraft:light[level=15]
setblock 434 181 286 minecraft:light[level=15]
setblock 434 181 294 minecraft:light[level=15]
setblock 434 181 302 minecraft:light[level=15]
setblock 434 181 310 minecraft:light[level=15]
setblock 440 181 278 minecraft:light[level=12]
setblock 440 181 285 minecraft:light[level=12]
setblock 440 181 292 minecraft:light[level=12]
setblock 440 181 299 minecraft:light[level=12]
setblock 440 181 306 minecraft:light[level=12]
schedule function dropper:buildpart/69_2 1t
