fill 329 114 199 329 115 200 minecraft:bone_block
fill 329 114 201 329 119 202 minecraft:calcite
fill 329 114 211 329 114 212 minecraft:bone_block
fill 329 114 213 329 119 214 minecraft:calcite
fill 329 114 220 329 115 220 minecraft:bone_block
fill 329 114 221 329 119 222 minecraft:calcite
setblock 329 114 223 minecraft:bone_block
fill 330 114 182 332 114 182 minecraft:polished_basalt
fill 330 114 184 330 114 186 minecraft:polished_basalt
fill 330 114 188 330 114 190 minecraft:polished_basalt
fill 330 114 192 330 114 194 minecraft:polished_basalt
fill 330 114 196 330 114 198 minecraft:polished_basalt
fill 330 114 200 330 114 202 minecraft:polished_basalt
fill 330 114 204 330 114 206 minecraft:polished_basalt
fill 330 114 208 330 114 210 minecraft:polished_basalt
fill 330 114 212 330 114 214 minecraft:polished_basalt
fill 330 114 216 330 114 218 minecraft:polished_basalt
fill 330 114 220 330 114 222 minecraft:polished_basalt
fill 331 114 223 331 116 223 minecraft:calcite
fill 332 114 181 333 119 181 minecraft:calcite
fill 332 114 222 334 114 222 minecraft:polished_basalt
fill 334 114 181 335 114 181 minecraft:bone_block
fill 334 114 182 336 114 182 minecraft:polished_basalt
fill 336 114 222 338 114 222 minecraft:polished_basalt
fill 337 114 223 338 115 223 minecraft:bone_block
fill 338 114 182 340 114 182 minecraft:polished_basalt
fill 339 114 223 340 119 223 minecraft:calcite
fill 340 114 222 342 114 222 minecraft:polished_basalt
fill 342 114 182 344 114 182 minecraft:polished_basalt
fill 344 114 181 345 119 181 minecraft:calcite
fill 344 114 222 346 114 222 minecraft:polished_basalt
setblock 345 114 223 minecraft:calcite
fill 346 114 181 347 115 181 minecraft:bone_block
fill 346 114 182 348 114 182 minecraft:polished_basalt
fill 346 114 223 346 115 223 minecraft:bone_block
fill 348 114 222 350 114 222 minecraft:polished_basalt
fill 348 114 223 348 119 223 minecraft:calcite
fill 349 114 223 350 114 223 minecraft:bone_block
fill 350 114 182 352 114 182 minecraft:polished_basalt
fill 351 114 223 352 116 223 minecraft:calcite
fill 352 114 222 354 114 222 minecraft:polished_basalt
fill 353 114 181 353 119 181 minecraft:calcite
fill 354 114 181 355 114 181 minecraft:bone_block
fill 354 114 182 356 114 182 minecraft:polished_basalt
fill 356 114 181 356 119 181 minecraft:calcite
fill 356 114 222 358 114 222 minecraft:polished_basalt
fill 357 114 223 358 115 223 minecraft:bone_block
fill 358 114 181 358 115 181 minecraft:bone_block
fill 358 114 182 360 114 182 minecraft:polished_basalt
fill 359 114 223 360 119 223 minecraft:calcite
fill 360 114 222 362 114 222 minecraft:polished_basalt
setblock 361 114 223 minecraft:bone_block
fill 362 114 182 364 114 182 minecraft:polished_basalt
fill 362 114 223 362 117 223 minecraft:calcite
fill 364 114 181 365 119 181 minecraft:calcite
fill 364 114 222 366 114 222 minecraft:polished_basalt
fill 366 114 181 367 115 181 minecraft:bone_block
fill 366 114 182 368 114 182 minecraft:polished_basalt
fill 368 114 222 370 114 222 minecraft:polished_basalt
fill 369 114 223 370 114 223 minecraft:bone_block
fill 370 114 182 370 114 184 minecraft:polished_basalt
fill 370 114 186 370 114 188 minecraft:polished_basalt
fill 370 114 190 370 114 192 minecraft:polished_basalt
fill 370 114 194 370 114 196 minecraft:polished_basalt
fill 370 114 198 370 114 200 minecraft:polished_basalt
fill 370 114 202 370 114 204 minecraft:polished_basalt
fill 370 114 206 370 114 208 minecraft:polished_basalt
fill 370 114 210 370 114 212 minecraft:polished_basalt
fill 370 114 214 370 114 216 minecraft:polished_basalt
fill 370 114 218 370 114 220 minecraft:polished_basalt
fill 371 114 184 371 117 184 minecraft:calcite
setblock 371 114 185 minecraft:bone_block
fill 371 114 186 371 119 187 minecraft:calcite
fill 371 114 188 371 115 189 minecraft:bone_block
fill 371 114 194 371 119 195 minecraft:calcite
fill 371 114 196 371 114 197 minecraft:bone_block
fill 371 114 198 371 119 198 minecraft:calcite
fill 371 114 206 371 119 207 minecraft:calcite
fill 371 114 208 371 115 209 minecraft:bone_block
fill 371 114 215 371 119 215 minecraft:calcite
setblock 371 114 217 minecraft:bone_block
fill 371 114 218 371 119 219 minecraft:calcite
fill 371 114 220 371 115 220 minecraft:bone_block
fill 371 114 223 371 119 223 minecraft:calcite
setblock 329 115 187 minecraft:bone_block
fill 329 115 191 329 118 192 minecraft:calcite
setblock 329 115 208 minecraft:bone_block
setblock 329 115 211 minecraft:bone_block
fill 329 115 212 329 118 212 minecraft:calcite
setblock 329 115 219 minecraft:bone_block
fill 329 115 223 329 118 223 minecraft:calcite
fill 333 115 223 333 117 223 minecraft:calcite
fill 334 115 181 334 118 181 minecraft:calcite
setblock 334 115 223 minecraft:bone_block
setblock 335 115 181 minecraft:bone_block
setblock 338 115 181 minecraft:bone_block
setblock 345 115 223 minecraft:bone_block
setblock 349 115 223 minecraft:bone_block
fill 350 115 223 350 118 223 minecraft:calcite
fill 354 115 181 355 118 181 minecraft:calcite
setblock 359 115 181 minecraft:bone_block
fill 361 115 223 361 117 223 minecraft:calcite
setblock 366 115 223 minecraft:bone_block
setblock 369 115 223 minecraft:bone_block
setblock 370 115 181 minecraft:bone_block
fill 370 115 223 370 118 223 minecraft:calcite
fill 371 115 185 371 118 185 minecraft:calcite
fill 371 115 196 371 118 196 minecraft:calcite
setblock 371 115 197 minecraft:bone_block
fill 371 115 200 371 115 201 minecraft:bone_block
fill 371 115 217 371 118 217 minecraft:calcite
setblock 371 115 221 minecraft:bone_block
fill 329 116 185 329 117 186 minecraft:bone_block
fill 329 116 187 329 121 188 minecraft:calcite
setblock 329 116 189 minecraft:bone_block
fill 329 116 197 329 117 198 minecraft:bone_block
fill 329 116 199 329 121 200 minecraft:calcite
fill 329 116 206 329 117 206 minecraft:bone_block
fill 329 116 208 329 121 208 minecraft:calcite
fill 329 116 209 329 116 210 minecraft:bone_block
fill 329 116 211 329 121 211 minecraft:calcite
fill 329 116 217 329 117 218 minecraft:bone_block
fill 329 116 219 329 121 220 minecraft:calcite
fill 334 116 223 334 117 223 minecraft:calcite
fill 335 116 181 335 121 181 minecraft:calcite
fill 335 116 223 336 116 223 minecraft:bone_block
fill 336 116 181 337 116 181 minecraft:bone_block
fill 337 116 223 338 121 223 minecraft:calcite
fill 338 116 181 338 121 181 minecraft:calcite
fill 340 116 181 340 117 181 minecraft:bone_block
fill 343 116 223 344 117 223 minecraft:bone_block
fill 345 116 223 346 121 223 minecraft:calcite
fill 346 116 181 347 121 181 minecraft:calcite
setblock 347 116 223 minecraft:bone_block
fill 348 116 181 349 117 181 minecraft:bone_block
fill 349 116 223 349 118 223 minecraft:calcite
fill 355 116 223 356 117 223 minecraft:bone_block
setblock 357 116 181 minecraft:bone_block
fill 357 116 223 358 121 223 minecraft:calcite
fill 358 116 181 359 121 181 minecraft:calcite
fill 360 116 181 361 117 181 minecraft:bone_block
setblock 363 116 223 minecraft:calcite
fill 364 116 223 364 117 223 minecraft:bone_block
fill 366 116 181 367 121 181 minecraft:calcite
fill 366 116 223 366 121 223 minecraft:calcite
fill 367 116 223 368 116 223 minecraft:bone_block
fill 368 116 181 369 116 181 minecraft:bone_block
fill 369 116 223 369 121 223 minecraft:calcite
fill 370 116 181 370 121 181 minecraft:calcite
fill 371 116 188 371 121 189 minecraft:calcite
fill 371 116 190 371 117 191 minecraft:bone_block
fill 371 116 197 371 121 197 minecraft:calcite
setblock 371 116 199 minecraft:bone_block
fill 371 116 200 371 121 201 minecraft:calcite
fill 371 116 202 371 117 202 minecraft:bone_block
fill 371 116 208 371 121 209 minecraft:calcite
fill 371 116 210 371 116 211 minecraft:bone_block
fill 371 116 220 371 121 221 minecraft:calcite
fill 371 116 222 371 117 222 minecraft:bone_block
fill 329 117 189 329 120 189 minecraft:calcite
setblock 329 117 194 minecraft:bone_block
setblock 329 117 205 minecraft:bone_block
fill 329 117 209 329 120 210 minecraft:calcite
fill 331 117 223 332 117 223 minecraft:bone_block
setblock 335 117 223 minecraft:bone_block
fill 336 117 181 337 120 181 minecraft:calcite
fill 336 117 223 336 120 223 minecraft:calcite
setblock 341 117 181 minecraft:bone_block
fill 347 117 223 347 120 223 minecraft:calcite
fill 351 117 223 351 119 223 minecraft:calcite
setblock 352 117 181 minecraft:bone_block
setblock 352 117 223 minecraft:bone_block
fill 357 117 181 357 120 181 minecraft:calcite
setblock 363 117 223 minecraft:bone_block
fill 367 117 223 368 120 223 minecraft:calcite
fill 368 117 181 368 120 181 minecraft:calcite
setblock 369 117 181 minecraft:bone_block
fill 371 117 182 371 117 183 minecraft:bone_block
fill 371 117 199 371 120 199 minecraft:calcite
setblock 371 117 203 minecraft:bone_block
fill 371 117 210 371 120 210 minecraft:calcite
setblock 371 117 211 minecraft:bone_block
setblock 371 117 214 minecraft:bone_block
fill 329 118 183 329 119 184 minecraft:bone_block
fill 329 118 185 329 123 186 minecraft:calcite
fill 329 118 194 329 123 194 minecraft:calcite
fill 329 118 195 329 118 196 minecraft:bone_block
fill 329 118 197 329 123 198 minecraft:calcite
fill 329 118 203 329 119 204 minecraft:bone_block
fill 329 118 205 329 123 206 minecraft:calcite
setblock 329 118 207 minecraft:bone_block
fill 329 118 215 329 119 216 minecraft:bone_block
fill 329 118 217 329 123 218 minecraft:calcite
fill 330 118 181 331 119 181 minecraft:bone_block
fill 330 118 223 330 119 223 minecraft:bone_block
fill 331 118 223 332 119 223 minecraft:calcite
fill 333 118 223 334 118 223 minecraft:bone_block
fill 335 118 223 335 123 223 minecraft:calcite
setblock 339 118 181 minecraft:bone_block
fill 340 118 181 341 123 181 minecraft:calcite
fill 341 118 223 342 119 223 minecraft:bone_block
fill 342 118 181 343 119 181 minecraft:bone_block
fill 343 118 223 344 123 223 minecraft:calcite
fill 348 118 181 349 123 181 minecraft:calcite
fill 350 118 181 351 118 181 minecraft:bone_block
fill 352 118 181 352 123 181 minecraft:calcite
fill 352 118 223 352 119 223 minecraft:calcite
fill 353 118 223 354 118 223 minecraft:bone_block
fill 355 118 223 356 123 223 minecraft:calcite
fill 360 118 181 361 123 181 minecraft:calcite
fill 361 118 223 362 119 223 minecraft:bone_block
fill 362 118 181 363 119 181 minecraft:bone_block
fill 363 118 223 364 123 223 minecraft:calcite
setblock 365 118 223 minecraft:bone_block
fill 369 118 181 369 123 181 minecraft:calcite
setblock 371 118 181 minecraft:bone_block
fill 371 118 182 371 123 183 minecraft:calcite
fill 371 118 184 371 119 184 minecraft:bone_block
fill 371 118 190 371 123 191 minecraft:calcite
fill 371 118 192 371 118 193 minecraft:bone_block
fill 371 118 202 371 123 203 minecraft:calcite
fill 371 118 204 371 119 205 minecraft:bone_block
fill 371 118 211 371 123 211 minecraft:calcite
fill 371 118 212 371 118 213 minecraft:bone_block
fill 371 118 214 371 123 214 minecraft:calcite
fill 371 118 216 371 119 216 minecraft:bone_block
fill 371 118 222 371 123 222 minecraft:calcite
fill 329 119 191 329 119 192 minecraft:bone_block
setblock 329 119 195 minecraft:bone_block
fill 329 119 196 329 122 196 minecraft:calcite
fill 329 119 207 329 122 207 minecraft:calcite
setblock 329 119 212 minecraft:bone_block
setblock 329 119 223 minecraft:bone_block
fill 333 119 223 334 121 223 minecraft:calcite
setblock 334 119 181 minecraft:bone_block
fill 339 119 181 339 122 181 minecraft:calcite
fill 349 119 223 350 119 223 minecraft:bone_block
fill 350 119 181 350 122 181 minecraft:calcite
setblock 351 119 181 minecraft:bone_block
setblock 353 119 223 minecraft:bone_block
fill 354 119 181 355 119 181 minecraft:bone_block
fill 354 119 223 354 122 223 minecraft:calcite
fill 365 119 223 365 122 223 minecraft:calcite
setblock 370 119 223 minecraft:bone_block
fill 371 119 181 371 122 181 minecraft:calcite
setblock 371 119 185 minecraft:bone_block
fill 371 119 192 371 122 192 minecraft:calcite
setblock 371 119 193 minecraft:bone_block
setblock 371 119 196 minecraft:bone_block
fill 371 119 212 371 122 213 minecraft:calcite
setblock 371 119 217 minecraft:bone_block
fill 329 120 181 329 120 182 minecraft:bone_block
fill 329 120 183 329 125 184 minecraft:calcite
fill 329 120 190 329 121 190 minecraft:bone_block
fill 329 120 191 329 125 192 minecraft:calcite
setblock 329 120 193 minecraft:bone_block
fill 329 120 195 329 125 195 minecraft:calcite
fill 329 120 201 329 121 202 minecraft:bone_block
fill 329 120 203 329 125 204 minecraft:calcite
fill 329 120 212 329 125 212 minecraft:calcite
fill 329 120 213 329 120 214 minecraft:bone_block
fill 329 120 215 329 122 216 minecraft:calcite
fill 329 120 221 329 121 222 minecraft:bone_block
fill 329 120 223 330 125 223 minecraft:calcite
fill 330 120 181 331 125 181 minecraft:calcite
fill 330 120 182 332 120 182 minecraft:polished_basalt
fill 330 120 184 330 120 186 minecraft:polished_basalt
fill 330 120 188 330 120 190 minecraft:polished_basalt
fill 330 120 192 330 120 194 minecraft:polished_basalt
fill 330 120 196 330 120 198 minecraft:polished_basalt
fill 330 120 200 330 120 202 minecraft:polished_basalt
fill 330 120 204 330 120 206 minecraft:polished_basalt
fill 330 120 208 330 120 210 minecraft:polished_basalt
fill 330 120 212 330 120 214 minecraft:polished_basalt
fill 330 120 216 330 120 218 minecraft:polished_basalt
fill 330 120 220 330 120 222 minecraft:polished_basalt
setblock 331 120 223 minecraft:bone_block
fill 332 120 181 333 120 181 minecraft:bone_block
fill 332 120 222 334 120 222 minecraft:polished_basalt
fill 332 120 223 332 123 223 minecraft:calcite
fill 334 120 181 334 125 181 minecraft:calcite
fill 334 120 182 336 120 182 minecraft:polished_basalt
fill 336 120 222 338 120 222 minecraft:polished_basalt
fill 338 120 182 340 120 182 minecraft:polished_basalt
fill 339 120 223 340 121 223 minecraft:bone_block
fill 340 120 222 342 120 222 minecraft:polished_basalt
fill 341 120 223 342 125 223 minecraft:calcite
fill 342 120 181 343 125 181 minecraft:calcite
fill 342 120 182 344 120 182 minecraft:polished_basalt
fill 344 120 181 345 121 181 minecraft:bone_block
fill 344 120 222 346 120 222 minecraft:polished_basalt
fill 346 120 182 348 120 182 minecraft:polished_basalt
fill 348 120 222 350 120 222 minecraft:polished_basalt
fill 348 120 223 348 121 223 minecraft:bone_block
fill 349 120 223 350 121 223 minecraft:calcite
fill 350 120 182 352 120 182 minecraft:polished_basalt
fill 351 120 181 351 125 181 minecraft:calcite
fill 351 120 223 352 120 223 minecraft:bone_block
fill 352 120 222 354 120 222 minecraft:polished_basalt
setblock 353 120 181 minecraft:bone_block
fill 353 120 223 353 125 223 minecraft:calcite
fill 354 120 181 355 125 181 minecraft:calcite
fill 354 120 182 356 120 182 minecraft:polished_basalt
fill 356 120 181 356 121 181 minecraft:bone_block
fill 356 120 222 358 120 222 minecraft:polished_basalt
fill 358 120 182 360 120 182 minecraft:polished_basalt
fill 359 120 223 360 121 223 minecraft:bone_block
fill 360 120 222 362 120 222 minecraft:polished_basalt
fill 361 120 223 362 125 223 minecraft:calcite
fill 362 120 181 363 125 181 minecraft:calcite
fill 362 120 182 364 120 182 minecraft:polished_basalt
fill 364 120 181 365 120 181 minecraft:bone_block
fill 364 120 222 366 120 222 minecraft:polished_basalt
fill 366 120 182 368 120 182 minecraft:polished_basalt
fill 368 120 222 370 120 222 minecraft:polished_basalt
fill 370 120 182 370 120 184 minecraft:polished_basalt
fill 370 120 186 370 120 188 minecraft:polished_basalt
fill 370 120 190 370 120 192 minecraft:polished_basalt
fill 370 120 194 370 120 196 minecraft:polished_basalt
fill 370 120 198 370 120 200 minecraft:polished_basalt
fill 370 120 202 370 120 204 minecraft:polished_basalt
fill 370 120 206 370 120 208 minecraft:polished_basalt
fill 370 120 210 370 120 212 minecraft:polished_basalt
fill 370 120 214 370 120 216 minecraft:polished_basalt
fill 370 120 218 370 120 220 minecraft:polished_basalt
fill 370 120 223 370 125 223 minecraft:calcite
fill 371 120 184 371 125 185 minecraft:calcite
fill 371 120 186 371 121 187 minecraft:bone_block
fill 371 120 193 371 125 193 minecraft:calcite
fill 371 120 194 371 120 195 minecraft:bone_block
fill 371 120 196 371 125 196 minecraft:calcite
fill 371 120 198 371 121 198 minecraft:bone_block
fill 371 120 204 371 125 205 minecraft:calcite
fill 371 120 206 371 121 207 minecraft:bone_block
setblock 371 120 215 minecraft:bone_block
fill 371 120 216 371 125 217 minecraft:calcite
fill 371 120 218 371 121 219 minecraft:bone_block
fill 371 120 223 371 121 223 minecraft:bone_block
setblock 329 121 181 minecraft:bone_block
fill 329 121 182 329 124 182 minecraft:calcite
setblock 329 121 189 minecraft:bone_block
fill 329 121 193 329 124 193 minecraft:calcite
fill 329 121 209 329 121 210 minecraft:bone_block
setblock 329 121 213 minecraft:bone_block
fill 329 121 214 329 124 214 minecraft:calcite
fill 331 121 223 331 123 223 minecraft:calcite
fill 332 121 181 332 124 181 minecraft:calcite
setblock 332 121 184 minecraft:light[level=12]
setblock 332 121 192 minecraft:light[level=12]
setblock 332 121 200 minecraft:light[level=12]
setblock 332 121 208 minecraft:light[level=12]
setblock 332 121 216 minecraft:light[level=12]
setblock 333 121 181 minecraft:bone_block
fill 336 121 181 337 121 181 minecraft:bone_block
setblock 336 121 223 minecraft:bone_block
setblock 340 121 184 minecraft:light[level=12]
setblock 340 121 192 minecraft:light[level=12]
setblock 340 121 200 minecraft:light[level=12]
setblock 340 121 208 minecraft:light[level=12]
setblock 340 121 216 minecraft:light[level=12]
setblock 347 121 223 minecraft:bone_block
setblock 348 121 184 minecraft:light[level=12]
setblock 348 121 192 minecraft:light[level=12]
setblock 348 121 200 minecraft:light[level=12]
setblock 348 121 208 minecraft:light[level=12]
setblock 348 121 216 minecraft:light[level=12]
fill 351 121 223 352 123 223 minecraft:calcite
fill 353 121 181 353 124 181 minecraft:calcite
setblock 356 121 184 minecraft:light[level=12]
setblock 356 121 192 minecraft:light[level=12]
setblock 356 121 200 minecraft:light[level=12]
setblock 356 121 208 minecraft:light[level=12]
setblock 356 121 216 minecraft:light[level=12]
setblock 357 121 181 minecraft:bone_block
fill 364 121 181 364 124 181 minecraft:calcite
setblock 364 121 184 minecraft:light[level=12]
setblock 364 121 192 minecraft:light[level=12]
setblock 364 121 200 minecraft:light[level=12]
setblock 364 121 208 minecraft:light[level=12]
setblock 364 121 216 minecraft:light[level=12]
setblock 365 121 181 minecraft:bone_block
fill 367 121 223 368 121 223 minecraft:bone_block
setblock 368 121 181 minecraft:bone_block
fill 371 121 194 371 124 195 minecraft:calcite
setblock 371 121 199 minecraft:bone_block
setblock 371 121 210 minecraft:bone_block
fill 371 121 215 371 124 215 minecraft:calcite
fill 329 122 181 329 127 181 minecraft:calcite
fill 329 122 187 329 123 188 minecraft:bone_block
fill 329 122 189 329 127 190 minecraft:calcite
fill 329 122 199 329 122 200 minecraft:bone_block
fill 329 122 201 329 127 202 minecraft:calcite
fill 329 122 208 329 123 208 minecraft:bone_block
fill 329 122 209 329 127 210 minecraft:calcite
setblock 329 122 211 minecraft:bone_block
fill 329 122 213 329 124 213 minecraft:calcite
fill 329 122 219 329 123 220 minecraft:bone_block
fill 329 122 221 329 127 222 minecraft:calcite
fill 333 122 181 333 127 181 minecraft:calcite
setblock 333 122 223 minecraft:calcite
fill 334 122 223 334 123 223 minecraft:bone_block
setblock 335 122 181 minecraft:bone_block
fill 336 122 181 337 127 181 minecraft:calcite
fill 336 122 223 336 127 223 minecraft:calcite
fill 337 122 223 338 122 223 minecraft:bone_block
fill 338 122 181 338 123 181 minecraft:bone_block
fill 339 122 223 340 124 223 minecraft:calcite
fill 344 122 181 345 127 181 minecraft:calcite
fill 345 122 223 346 123 223 minecraft:bone_block
fill 346 122 181 347 122 181 minecraft:bone_block
fill 347 122 223 348 127 223 minecraft:calcite
setblock 349 122 223 minecraft:bone_block
fill 350 122 223 350 125 223 minecraft:calcite
fill 356 122 181 357 127 181 minecraft:calcite
fill 357 122 223 358 122 223 minecraft:bone_block
fill 358 122 181 359 123 181 minecraft:bone_block
fill 359 122 223 360 127 223 minecraft:calcite
fill 365 122 181 365 127 181 minecraft:calcite
fill 366 122 181 367 122 181 minecraft:bone_block
fill 366 122 223 366 123 223 minecraft:bone_block
fill 367 122 223 368 127 223 minecraft:calcite
fill 368 122 181 368 127 181 minecraft:calcite
setblock 369 122 223 minecraft:bone_block
fill 370 122 181 370 123 181 minecraft:bone_block
fill 371 122 186 371 127 187 minecraft:calcite
fill 371 122 188 371 123 189 minecraft:bone_block
setblock 371 122 197 minecraft:bone_block
fill 371 122 198 371 127 199 minecraft:calcite
fill 371 122 200 371 123 201 minecraft:bone_block
fill 371 122 206 371 127 207 minecraft:calcite
fill 371 122 208 371 122 209 minecraft:bone_block
fill 371 122 210 371 127 210 minecraft:calcite
fill 371 122 218 371 127 219 minecraft:calcite
fill 371 122 220 371 123 221 minecraft:bone_block
fill 371 122 223 371 127 223 minecraft:calcite
setblock 329 123 196 minecraft:bone_block
setblock 329 123 199 minecraft:bone_block
fill 329 123 200 329 126 200 minecraft:calcite
setblock 329 123 207 minecraft:bone_block
fill 329 123 211 329 126 211 minecraft:calcite
fill 329 123 215 329 125 215 minecraft:calcite
setblock 329 123 216 minecraft:bone_block
setblock 333 123 223 minecraft:bone_block
fill 335 123 181 335 126 181 minecraft:calcite
setblock 337 123 223 minecraft:bone_block
fill 338 123 223 338 126 223 minecraft:calcite
setblock 339 123 181 minecraft:bone_block
fill 346 123 181 346 126 181 minecraft:calcite
setblock 347 123 181 minecraft:bone_block
fill 349 123 223 349 125 223 minecraft:calcite
setblock 350 123 181 minecraft:bone_block
setblock 354 123 223 minecraft:bone_block
setblock 357 123 223 minecraft:bone_block
fill 358 123 223 358 126 223 minecraft:calcite
setblock 365 123 223 minecraft:bone_block
fill 366 123 181 367 126 181 minecraft:calcite
fill 369 123 223 369 126 223 minecraft:calcite
setblock 371 123 181 minecraft:bone_block
setblock 371 123 192 minecraft:bone_block
fill 371 123 197 371 126 197 minecraft:calcite
fill 371 123 208 371 126 208 minecraft:calcite
setblock 371 123 209 minecraft:bone_block
fill 371 123 212 371 123 213 minecraft:bone_block
fill 329 124 185 329 125 186 minecraft:bone_block
fill 329 124 187 329 129 188 minecraft:calcite
fill 329 124 194 329 125 194 minecraft:bone_block
fill 329 124 196 329 129 196 minecraft:calcite
fill 329 124 197 329 124 198 minecraft:bone_block
fill 329 124 199 329 129 199 minecraft:calcite
fill 329 124 205 329 125 206 minecraft:bone_block
fill 329 124 207 329 129 208 minecraft:calcite
fill 329 124 216 329 125 216 minecraft:calcite
fill 329 124 217 329 124 218 minecraft:bone_block
fill 329 124 219 329 129 220 minecraft:calcite
fill 331 124 223 332 125 223 minecraft:bone_block
fill 333 124 223 334 129 223 minecraft:calcite
setblock 335 124 223 minecraft:bone_block
fill 337 124 223 337 126 223 minecraft:calcite
fill 338 124 181 339 129 181 minecraft:calcite
fill 340 124 181 341 125 181 minecraft:bone_block
fill 343 124 223 344 125 223 minecraft:bone_block
fill 345 124 223 346 129 223 minecraft:calcite
fill 347 124 181 347 129 181 minecraft:calcite
fill 348 124 181 349 124 181 minecraft:bone_block
fill 350 124 181 350 129 181 minecraft:calcite
setblock 351 124 223 minecraft:calcite
fill 352 124 181 352 125 181 minecraft:bone_block
fill 352 124 223 352 125 223 minecraft:bone_block
fill 354 124 223 354 129 223 minecraft:calcite
fill 355 124 223 356 124 223 minecraft:bone_block
fill 357 124 223 357 129 223 minecraft:calcite
fill 358 124 181 359 129 181 minecraft:calcite
fill 360 124 181 361 125 181 minecraft:bone_block
fill 363 124 223 364 125 223 minecraft:bone_block
fill 365 124 223 366 129 223 minecraft:calcite
setblock 369 124 181 minecraft:bone_block
fill 370 124 181 371 129 181 minecraft:calcite
fill 371 124 182 371 125 183 minecraft:bone_block
fill 371 124 188 371 129 189 minecraft:calcite
fill 371 124 190 371 124 191 minecraft:bone_block
fill 371 124 192 371 129 192 minecraft:calcite
fill 371 124 200 371 129 201 minecraft:calcite
fill 371 124 202 371 125 203 minecraft:bone_block
fill 371 124 209 371 129 209 minecraft:calcite
setblock 371 124 211 minecraft:bone_block
fill 371 124 212 371 129 213 minecraft:calcite
fill 371 124 214 371 125 214 minecraft:bone_block
fill 371 124 220 371 129 221 minecraft:calcite
setblock 371 124 222 minecraft:bone_block
setblock 329 125 182 minecraft:bone_block
setblock 329 125 193 minecraft:bone_block
fill 329 125 197 329 128 198 minecraft:calcite
fill 329 125 213 329 125 214 minecraft:bone_block
setblock 329 125 217 minecraft:bone_block
fill 329 125 218 329 128 218 minecraft:calcite
setblock 332 125 181 minecraft:bone_block
fill 335 125 223 335 128 223 minecraft:calcite
fill 339 125 223 339 127 223 minecraft:calcite
setblock 340 125 223 minecraft:bone_block
fill 348 125 181 349 128 181 minecraft:calcite
setblock 351 125 223 minecraft:bone_block
setblock 353 125 181 minecraft:bone_block
fill 355 125 223 356 128 223 minecraft:calcite
setblock 364 125 181 minecraft:bone_block
fill 369 125 181 369 128 181 minecraft:calcite
fill 371 125 190 371 128 190 minecraft:calcite
setblock 371 125 191 minecraft:bone_block
fill 371 125 194 371 125 195 minecraft:bone_block
fill 371 125 211 371 128 211 minecraft:calcite
setblock 371 125 215 minecraft:bone_block
fill 371 125 222 371 128 222 minecraft:calcite
fill 329 126 182 329 131 182 minecraft:calcite
fill 329 126 183 329 126 184 minecraft:bone_block
fill 329 126 185 329 131 186 minecraft:calcite
fill 329 126 191 329 127 192 minecraft:bone_block
fill 329 126 193 329 131 194 minecraft:calcite
setblock 329 126 195 minecraft:bone_block
fill 329 126 203 329 127 204 minecraft:bone_block
fill 329 126 205 329 131 206 minecraft:calcite
fill 329 126 212 329 127 212 minecraft:bone_block
fill 329 126 213 329 127 214 minecraft:calcite
fill 329 126 215 329 126 216 minecraft:bone_block
fill 329 126 217 329 131 217 minecraft:calcite
fill 329 126 223 330 127 223 minecraft:bone_block
fill 330 126 181 331 126 181 minecraft:bone_block
fill 330 126 182 332 126 182 minecraft:polished_basalt
fill 330 126 184 330 126 186 minecraft:polished_basalt
fill 330 126 188 330 126 190 minecraft:polished_basalt
fill 330 126 192 330 126 194 minecraft:polished_basalt
fill 330 126 196 330 126 198 minecraft:polished_basalt
fill 330 126 200 330 126 202 minecraft:polished_basalt
fill 330 126 204 330 126 206 minecraft:polished_basalt
fill 330 126 208 330 126 210 minecraft:polished_basalt
fill 330 126 212 330 126 214 minecraft:polished_basalt
fill 330 126 216 330 126 218 minecraft:polished_basalt
fill 330 126 220 330 126 222 minecraft:polished_basalt
fill 331 126 223 332 131 223 minecraft:calcite
fill 332 126 181 332 131 181 minecraft:calcite
fill 332 126 222 334 126 222 minecraft:polished_basalt
fill 334 126 181 334 127 181 minecraft:bone_block
fill 334 126 182 336 126 182 minecraft:polished_basalt
fill 336 126 222 338 126 222 minecraft:polished_basalt
fill 338 126 182 340 126 182 minecraft:polished_basalt
fill 340 126 181 341 131 181 minecraft:calcite
fill 340 126 222 342 126 222 minecraft:polished_basalt
fill 340 126 223 340 127 223 minecraft:calcite
fill 341 126 223 342 126 223 minecraft:bone_block
fill 342 126 181 343 127 181 minecraft:bone_block
fill 342 126 182 344 126 182 minecraft:polished_basalt
fill 343 126 223 344 131 223 minecraft:calcite
fill 344 126 222 346 126 222 minecraft:polished_basalt
fill 346 126 182 348 126 182 minecraft:polished_basalt
fill 348 126 222 350 126 222 minecraft:polished_basalt
fill 349 126 223 350 127 223 minecraft:bone_block
fill 350 126 182 352 126 182 minecraft:polished_basalt
setblock 351 126 181 minecraft:bone_block
fill 351 126 223 352 131 223 minecraft:calcite
fill 352 126 181 353 131 181 minecraft:calcite
fill 352 126 222 354 126 222 minecraft:polished_basalt
setblock 353 126 223 minecraft:bone_block
fill 354 126 181 355 127 181 minecraft:bone_block
fill 354 126 182 356 126 182 minecraft:polished_basalt
fill 356 126 222 358 126 222 minecraft:polished_basalt
fill 358 126 182 360 126 182 minecraft:polished_basalt
fill 360 126 181 361 131 181 minecraft:calcite
fill 360 126 222 362 126 222 minecraft:polished_basalt
fill 361 126 223 362 127 223 minecraft:bone_block
fill 362 126 181 363 126 181 minecraft:bone_block
fill 362 126 182 364 126 182 minecraft:polished_basalt
fill 363 126 223 364 131 223 minecraft:calcite
fill 364 126 181 364 131 181 minecraft:calcite
fill 364 126 222 366 126 222 minecraft:polished_basalt
fill 366 126 182 368 126 182 minecraft:polished_basalt
fill 368 126 222 370 126 222 minecraft:polished_basalt
fill 370 126 182 370 126 184 minecraft:polished_basalt
fill 370 126 186 370 126 188 minecraft:polished_basalt
fill 370 126 190 370 126 192 minecraft:polished_basalt
fill 370 126 194 370 126 196 minecraft:polished_basalt
fill 370 126 198 370 126 200 minecraft:polished_basalt
fill 370 126 202 370 126 204 minecraft:polished_basalt
fill 370 126 206 370 126 208 minecraft:polished_basalt
fill 370 126 210 370 126 212 minecraft:polished_basalt
fill 370 126 214 370 126 216 minecraft:polished_basalt
fill 370 126 218 370 126 220 minecraft:polished_basalt
fill 370 126 223 370 127 223 minecraft:bone_block
fill 371 126 182 371 131 183 minecraft:calcite
fill 371 126 184 371 127 185 minecraft:bone_block
fill 371 126 191 371 131 191 minecraft:calcite
setblock 371 126 193 minecraft:bone_block
fill 371 126 194 371 131 195 minecraft:calcite
fill 371 126 196 371 127 196 minecraft:bone_block
fill 371 126 202 371 131 203 minecraft:calcite
fill 371 126 204 371 126 205 minecraft:bone_block
fill 371 126 214 371 131 215 minecraft:calcite
fill 371 126 216 371 127 217 minecraft:bone_block
setblock 329 127 183 minecraft:bone_block
fill 329 127 184 329 130 184 minecraft:calcite
fill 329 127 195 329 130 195 minecraft:calcite
setblock 329 127 200 minecraft:bone_block
setblock 329 127 211 minecraft:bone_block
fill 329 127 215 329 129 216 minecraft:calcite
fill 330 127 181 331 130 181 minecraft:calcite
setblock 335 127 181 minecraft:bone_block
fill 337 127 223 338 127 223 minecraft:bone_block
setblock 341 127 223 minecraft:bone_block
fill 342 127 223 342 130 223 minecraft:calcite
setblock 346 127 181 minecraft:bone_block
fill 351 127 181 351 130 181 minecraft:calcite
fill 353 127 223 353 130 223 minecraft:calcite
setblock 358 127 223 minecraft:bone_block
fill 362 127 181 362 130 181 minecraft:calcite
setblock 363 127 181 minecraft:bone_block
fill 366 127 181 367 127 181 minecraft:bone_block
setblock 369 127 223 minecraft:bone_block
fill 371 127 193 371 130 193 minecraft:calcite
setblock 371 127 197 minecraft:bone_block
fill 371 127 204 371 130 204 minecraft:calcite
setblock 371 127 205 minecraft:bone_block
setblock 371 127 208 minecraft:bone_block
setblock 329 128 181 minecraft:bone_block
fill 329 128 183 329 133 183 minecraft:calcite
fill 329 128 189 329 129 190 minecraft:bone_block
fill 329 128 191 329 133 192 minecraft:calcite
fill 329 128 200 329 133 200 minecraft:calcite
fill 329 128 201 329 128 202 minecraft:bone_block
fill 329 128 203 329 130 204 minecraft:calcite
fill 329 128 209 329 129 210 minecraft:bone_block
fill 329 128 211 329 133 212 minecraft:calcite
setblock 329 128 213 minecraft:bone_block
fill 329 128 214 329 131 214 minecraft:calcite
fill 329 128 221 329 129 222 minecraft:bone_block
fill 329 128 223 330 133 223 minecraft:calcite
setblock 333 128 181 minecraft:bone_block
fill 334 128 181 335 133 181 minecraft:calcite
fill 336 128 181 337 129 181 minecraft:bone_block
fill 336 128 223 336 129 223 minecraft:bone_block
fill 337 128 223 338 129 223 minecraft:calcite
fill 339 128 223 340 128 223 minecraft:bone_block
fill 341 128 223 341 133 223 minecraft:calcite
fill 342 128 181 343 133 181 minecraft:calcite
fill 344 128 181 345 128 181 minecraft:bone_block
fill 346 128 181 346 133 181 minecraft:calcite
fill 347 128 223 348 129 223 minecraft:bone_block
fill 349 128 223 350 133 223 minecraft:calcite
fill 354 128 181 355 133 181 minecraft:calcite
fill 356 128 181 357 129 181 minecraft:bone_block
fill 358 128 223 358 133 223 minecraft:calcite
fill 359 128 223 360 128 223 minecraft:bone_block
fill 361 128 223 362 133 223 minecraft:calcite
fill 363 128 181 363 133 181 minecraft:calcite
setblock 365 128 181 minecraft:bone_block
fill 366 128 181 367 133 181 minecraft:calcite
fill 367 128 223 368 129 223 minecraft:bone_block
fill 368 128 181 368 129 181 minecraft:bone_block
fill 369 128 223 370 133 223 minecraft:calcite
fill 371 128 184 371 133 185 minecraft:calcite
fill 371 128 186 371 128 187 minecraft:bone_block
fill 371 128 196 371 133 197 minecraft:calcite
fill 371 128 198 371 129 199 minecraft:bone_block
fill 371 128 205 371 133 205 minecraft:calcite
fill 371 128 206 371 128 207 minecraft:bone_block
fill 371 128 208 371 133 208 minecraft:calcite
fill 371 128 210 371 129 210 minecraft:bone_block
fill 371 128 216 371 133 217 minecraft:calcite
fill 371 128 218 371 129 219 minecraft:bone_block
setblock 371 128 223 minecraft:bone_block
fill 329 129 181 329 132 181 minecraft:calcite
fill 329 129 197 329 129 198 minecraft:bone_block
setblock 329 129 201 minecraft:bone_block
fill 329 129 202 329 132 202 minecraft:calcite
fill 329 129 213 329 131 213 minecraft:calcite
setblock 329 129 218 minecraft:bone_block
setblock 332 129 184 minecraft:light[level=12]
setblock 332 129 192 minecraft:light[level=12]
setblock 332 129 200 minecraft:light[level=12]
setblock 332 129 208 minecraft:light[level=12]
setblock 332 129 216 minecraft:light[level=12]
fill 333 129 181 333 132 181 minecraft:calcite
setblock 335 129 223 minecraft:bone_block
fill 339 129 223 340 131 223 minecraft:calcite
setblock 340 129 184 minecraft:light[level=12]
setblock 340 129 192 minecraft:light[level=12]
setblock 340 129 200 minecraft:light[level=12]
setblock 340 129 208 minecraft:light[level=12]
setblock 340 129 216 minecraft:light[level=12]
fill 344 129 181 344 132 181 minecraft:calcite
setblock 345 129 181 minecraft:bone_block
fill 348 129 181 349 129 181 minecraft:bone_block
setblock 348 129 184 minecraft:light[level=12]
setblock 348 129 192 minecraft:light[level=12]
setblock 348 129 200 minecraft:light[level=12]
setblock 348 129 208 minecraft:light[level=12]
setblock 348 129 216 minecraft:light[level=12]
fill 355 129 223 356 129 223 minecraft:bone_block
setblock 356 129 184 minecraft:light[level=12]
setblock 356 129 192 minecraft:light[level=12]
setblock 356 129 200 minecraft:light[level=12]
setblock 356 129 208 minecraft:light[level=12]
setblock 356 129 216 minecraft:light[level=12]
setblock 359 129 223 minecraft:bone_block
fill 360 129 223 360 132 223 minecraft:calcite
setblock 364 129 184 minecraft:light[level=12]
setblock 364 129 192 minecraft:light[level=12]
setblock 364 129 200 minecraft:light[level=12]
setblock 364 129 208 minecraft:light[level=12]
setblock 364 129 216 minecraft:light[level=12]
fill 365 129 181 365 132 181 minecraft:calcite
setblock 369 129 181 minecraft:bone_block
fill 371 129 186 371 132 186 minecraft:calcite
setblock 371 129 187 minecraft:bone_block
setblock 371 129 190 minecraft:bone_block
fill 371 129 206 371 132 207 minecraft:calcite
setblock 371 129 211 minecraft:bone_block
setblock 371 129 222 minecraft:bone_block
fill 371 129 223 371 132 223 minecraft:calcite
fill 329 130 187 329 130 188 minecraft:bone_block
fill 329 130 189 329 135 190 minecraft:calcite
fill 329 130 196 329 131 196 minecraft:bone_block
fill 329 130 197 329 135 198 minecraft:calcite
setblock 329 130 199 minecraft:bone_block
fill 329 130 201 329 132 201 minecraft:calcite
fill 329 130 207 329 131 208 minecraft:bone_block
fill 329 130 209 329 135 210 minecraft:calcite
setblock 329 130 215 minecraft:calcite
fill 329 130 216 329 131 216 minecraft:bone_block
fill 329 130 218 329 135 218 minecraft:calcite
fill 329 130 219 329 130 220 minecraft:bone_block
fill 329 130 221 329 132 222 minecraft:calcite
fill 333 130 223 334 131 223 minecraft:bone_block
fill 335 130 223 336 135 223 minecraft:calcite
fill 336 130 181 337 135 181 minecraft:calcite
setblock 337 130 223 minecraft:bone_block
fill 338 130 181 339 131 181 minecraft:bone_block
fill 338 130 223 338 133 223 minecraft:calcite
fill 345 130 181 345 135 181 minecraft:calcite
fill 345 130 223 346 130 223 minecraft:bone_block
setblock 347 130 181 minecraft:bone_block
fill 347 130 223 348 135 223 minecraft:calcite
fill 348 130 181 349 135 181 minecraft:calcite
fill 350 130 181 350 131 181 minecraft:bone_block
fill 354 130 223 354 131 223 minecraft:bone_block
fill 355 130 223 356 135 223 minecraft:calcite
fill 356 130 181 357 135 181 minecraft:calcite
setblock 357 130 223 minecraft:bone_block
fill 358 130 181 359 130 181 minecraft:bone_block
fill 359 130 223 359 135 223 minecraft:calcite
fill 365 130 223 366 131 223 minecraft:bone_block
fill 367 130 223 368 135 223 minecraft:calcite
fill 368 130 181 369 135 181 minecraft:calcite
fill 370 130 181 371 131 181 minecraft:bone_block
fill 371 130 187 371 135 187 minecraft:calcite
fill 371 130 188 371 130 189 minecraft:bone_block
fill 371 130 190 371 135 190 minecraft:calcite
fill 371 130 192 371 131 192 minecraft:bone_block
fill 371 130 198 371 135 199 minecraft:calcite
fill 371 130 200 371 131 201 minecraft:bone_block
setblock 371 130 209 minecraft:bone_block
fill 371 130 210 371 135 211 minecraft:calcite
fill 371 130 212 371 131 213 minecraft:bone_block
fill 371 130 218 371 135 219 minecraft:calcite
fill 371 130 220 371 130 221 minecraft:bone_block
fill 371 130 222 371 135 222 minecraft:calcite
setblock 329 131 184 minecraft:bone_block
setblock 329 131 187 minecraft:bone_block
fill 329 131 188 329 134 188 minecraft:calcite
setblock 329 131 195 minecraft:bone_block
fill 329 131 199 329 134 199 minecraft:calcite
fill 329 131 203 329 133 203 minecraft:calcite
setblock 329 131 204 minecraft:bone_block
setblock 329 131 215 minecraft:bone_block
setblock 329 131 219 minecraft:bone_block
fill 329 131 220 329 134 220 minecraft:calcite
fill 330 131 181 331 131 181 minecraft:bone_block
fill 337 131 223 337 133 223 minecraft:calcite
setblock 342 131 223 minecraft:bone_block
setblock 345 131 223 minecraft:bone_block
fill 346 131 223 346 134 223 minecraft:calcite
fill 347 131 181 347 134 181 minecraft:calcite
setblock 351 131 181 minecraft:bone_block
setblock 353 131 223 minecraft:bone_block
fill 357 131 223 357 134 223 minecraft:calcite
fill 358 131 181 358 134 181 minecraft:calcite
setblock 359 131 181 minecraft:bone_block
setblock 362 131 181 minecraft:bone_block
fill 371 131 188 371 134 189 minecraft:calcite
setblock 371 131 193 minecraft:bone_block
setblock 371 131 204 minecraft:bone_block
fill 371 131 209 371 134 209 minecraft:calcite
fill 371 131 220 371 134 220 minecraft:calcite
setblock 371 131 221 minecraft:bone_block
fill 329 132 182 329 133 182 minecraft:bone_block
fill 329 132 184 329 137 184 minecraft:calcite
fill 329 132 185 329 132 186 minecraft:bone_block
fill 329 132 187 329 137 187 minecraft:calcite
fill 329 132 193 329 133 194 minecraft:bone_block
fill 329 132 195 329 137 196 minecraft:calcite
fill 329 132 204 329 133 204 minecraft:calcite
fill 329 132 205 329 132 206 minecraft:bone_block
fill 329 132 207 329 137 208 minecraft:calcite
fill 329 132 213 329 133 214 minecraft:bone_block
fill 329 132 215 329 137 216 minecraft:calcite
setblock 329 132 217 minecraft:bone_block
fill 329 132 219 329 134 219 minecraft:calcite
fill 330 132 181 331 137 181 minecraft:calcite
fill 330 132 182 332 132 182 minecraft:polished_basalt
fill 330 132 184 330 132 186 minecraft:polished_basalt
fill 330 132 188 330 132 190 minecraft:polished_basalt
fill 330 132 192 330 132 194 minecraft:polished_basalt
fill 330 132 196 330 132 198 minecraft:polished_basalt
fill 330 132 200 330 132 202 minecraft:polished_basalt
fill 330 132 204 330 132 206 minecraft:polished_basalt
fill 330 132 208 330 132 210 minecraft:polished_basalt
fill 330 132 212 330 132 214 minecraft:polished_basalt
fill 330 132 216 330 132 218 minecraft:polished_basalt
fill 330 132 220 330 132 222 minecraft:polished_basalt
fill 331 132 223 332 133 223 minecraft:bone_block
fill 332 132 181 332 133 181 minecraft:bone_block
fill 332 132 222 334 132 222 minecraft:polished_basalt
fill 333 132 223 334 137 223 minecraft:calcite
fill 334 132 182 336 132 182 minecraft:polished_basalt
fill 336 132 222 338 132 222 minecraft:polished_basalt
fill 338 132 181 339 137 181 minecraft:calcite
fill 338 132 182 340 132 182 minecraft:polished_basalt
setblock 339 132 223 minecraft:calcite
fill 340 132 181 341 132 181 minecraft:bone_block
fill 340 132 222 342 132 222 minecraft:polished_basalt
fill 340 132 223 340 133 223 minecraft:bone_block
fill 342 132 182 344 132 182 minecraft:polished_basalt
fill 342 132 223 342 137 223 minecraft:calcite
fill 343 132 223 344 132 223 minecraft:bone_block
fill 344 132 222 346 132 222 minecraft:polished_basalt
fill 345 132 223 345 137 223 minecraft:calcite
fill 346 132 182 348 132 182 minecraft:polished_basalt
fill 348 132 222 350 132 222 minecraft:polished_basalt
fill 350 132 181 351 137 181 minecraft:calcite
fill 350 132 182 352 132 182 minecraft:polished_basalt
fill 351 132 223 352 133 223 minecraft:bone_block
fill 352 132 181 353 133 181 minecraft:bone_block
fill 352 132 222 354 132 222 minecraft:polished_basalt
fill 353 132 223 354 137 223 minecraft:calcite
fill 354 132 182 356 132 182 minecraft:polished_basalt
fill 356 132 222 358 132 222 minecraft:polished_basalt
fill 358 132 182 360 132 182 minecraft:polished_basalt
fill 359 132 181 359 137 181 minecraft:calcite
fill 360 132 181 361 132 181 minecraft:bone_block
fill 360 132 222 362 132 222 minecraft:polished_basalt
fill 362 132 181 362 137 181 minecraft:calcite
fill 362 132 182 364 132 182 minecraft:polished_basalt
fill 363 132 223 364 132 223 minecraft:bone_block
fill 364 132 181 364 133 181 minecraft:bone_block
fill 364 132 222 366 132 222 minecraft:polished_basalt
fill 365 132 223 366 137 223 minecraft:calcite
fill 366 132 182 368 132 182 minecraft:polished_basalt
fill 368 132 222 370 132 222 minecraft:polished_basalt
fill 370 132 181 371 137 181 minecraft:calcite
fill 370 132 182 370 132 184 minecraft:polished_basalt
fill 370 132 186 370 132 188 minecraft:polished_basalt
fill 370 132 190 370 132 192 minecraft:polished_basalt
fill 370 132 194 370 132 196 minecraft:polished_basalt
fill 370 132 198 370 132 200 minecraft:polished_basalt
fill 370 132 202 370 132 204 minecraft:polished_basalt
fill 370 132 206 370 132 208 minecraft:polished_basalt
fill 370 132 210 370 132 212 minecraft:polished_basalt
fill 370 132 214 370 132 216 minecraft:polished_basalt
fill 370 132 218 370 132 220 minecraft:polished_basalt
fill 371 132 182 371 133 183 minecraft:bone_block
setblock 371 132 191 minecraft:bone_block
fill 371 132 192 371 137 193 minecraft:calcite
fill 371 132 194 371 133 195 minecraft:bone_block
fill 371 132 200 371 137 201 minecraft:calcite
fill 371 132 202 371 132 203 minecraft:bone_block
fill 371 132 204 371 137 204 minecraft:calcite
fill 371 132 212 371 137 213 minecraft:calcite
fill 371 132 214 371 133 215 minecraft:bone_block
fill 371 132 221 371 137 221 minecraft:calcite
setblock 329 133 181 minecraft:bone_block
fill 329 133 185 329 136 186 minecraft:calcite
fill 329 133 201 329 133 202 minecraft:bone_block
setblock 329 133 205 minecraft:bone_block
fill 329 133 206 329 136 206 minecraft:calcite
fill 329 133 217 329 136 217 minecraft:calcite
fill 329 133 221 329 135 221 minecraft:calcite
setblock 329 133 222 minecraft:bone_block
setblock 333 133 181 minecraft:bone_block
setblock 339 133 223 minecraft:bone_block
fill 340 133 181 340 136 181 minecraft:calcite
setblock 341 133 181 minecraft:bone_block
fill 343 133 223 344 136 223 minecraft:calcite
setblock 344 133 181 minecraft:bone_block
fill 360 133 181 361 136 181 minecraft:calcite
setblock 360 133 223 minecraft:bone_block
setblock 363 133 223 minecraft:bone_block
fill 364 133 223 364 136 223 minecraft:calcite
setblock 365 133 181 minecraft:bone_block
setblock 371 133 186 minecraft:bone_block
fill 371 133 191 371 136 191 minecraft:calcite
fill 371 133 202 371 136 202 minecraft:calcite
setblock 371 133 203 minecraft:bone_block
fill 371 133 206 371 133 207 minecraft:bone_block
setblock 371 133 223 minecraft:bone_block
fill 329 134 181 329 139 182 minecraft:calcite
setblock 329 134 183 minecraft:bone_block
fill 329 134 191 329 135 192 minecraft:bone_block
fill 329 134 193 329 139 194 minecraft:calcite
fill 329 134 200 329 135 200 minecraft:bone_block
fill 329 134 201 329 135 202 minecraft:calcite
fill 329 134 203 329 134 204 minecraft:bone_block
fill 329 134 205 329 139 205 minecraft:calcite
fill 329 134 211 329 135 212 minecraft:bone_block
fill 329 134 213 329 139 214 minecraft:calcite
fill 329 134 222 329 135 222 minecraft:calcite
fill 329 134 223 330 134 223 minecraft:bone_block
fill 331 134 223 332 139 223 minecraft:calcite
fill 332 134 181 333 139 181 minecraft:calcite
fill 334 134 181 335 135 181 minecraft:bone_block
fill 337 134 223 338 135 223 minecraft:bone_block
fill 339 134 223 340 139 223 minecraft:calcite
fill 341 134 181 341 139 181 minecraft:calcite
setblock 341 134 223 minecraft:bone_block
fill 342 134 181 343 134 181 minecraft:bone_block
fill 344 134 181 344 139 181 minecraft:calcite
fill 346 134 181 346 135 181 minecraft:bone_block
fill 349 134 223 350 135 223 minecraft:bone_block
fill 351 134 223 352 139 223 minecraft:calcite
fill 352 134 181 353 139 181 minecraft:calcite
fill 354 134 181 355 135 181 minecraft:bone_block
fill 358 134 223 358 135 223 minecraft:bone_block
fill 360 134 223 360 139 223 minecraft:calcite
fill 361 134 223 362 134 223 minecraft:bone_block
setblock 363 134 181 minecraft:bone_block
fill 363 134 223 363 139 223 minecraft:calcite
fill 364 134 181 365 139 181 minecraft:calcite
fill 366 134 181 367 135 181 minecraft:bone_block
fill 369 134 223 370 135 223 minecraft:bone_block
fill 371 134 182 371 139 183 minecraft:calcite
fill 371 134 184 371 134 185 minecraft:bone_block
fill 371 134 186 371 139 186 minecraft:calcite
fill 371 134 194 371 139 195 minecraft:calcite
fill 371 134 196 371 135 197 minecraft:bone_block
fill 371 134 203 371 139 203 minecraft:calcite
setblock 371 134 205 minecraft:bone_block
fill 371 134 206 371 139 207 minecraft:calcite
fill 371 134 208 371 135 208 minecraft:bone_block
fill 371 134 214 371 139 215 minecraft:calcite
fill 371 134 216 371 134 217 minecraft:bone_block
fill 371 134 223 371 139 223 minecraft:calcite
fill 329 135 183 329 138 183 minecraft:calcite
setblock 329 135 188 minecraft:bone_block
setblock 329 135 199 minecraft:bone_block
fill 329 135 203 329 137 204 minecraft:calcite
fill 329 135 219 329 135 220 minecraft:bone_block
setblock 329 135 223 minecraft:bone_block
fill 330 135 223 330 138 223 minecraft:calcite
fill 341 135 223 341 138 223 minecraft:calcite
fill 342 135 181 343 138 181 minecraft:calcite
setblock 346 135 223 minecraft:bone_block
setblock 347 135 181 minecraft:bone_block
setblock 357 135 223 minecraft:bone_block
setblock 358 135 181 minecraft:bone_block
fill 361 135 223 362 138 223 minecraft:calcite
fill 363 135 181 363 138 181 minecraft:calcite
fill 371 135 184 371 138 184 minecraft:calcite
setblock 371 135 185 minecraft:bone_block
fill 371 135 188 371 135 189 minecraft:bone_block
fill 371 135 205 371 138 205 minecraft:calcite
setblock 371 135 209 minecraft:bone_block
fill 371 135 216 371 138 216 minecraft:calcite
setblock 371 135 217 minecraft:bone_block
setblock 371 135 220 minecraft:bone_block
fill 329 136 188 329 141 188 minecraft:calcite
fill 329 136 189 329 136 190 minecraft:bone_block
fill 329 136 191 329 138 192 minecraft:calcite
fill 329 136 197 329 137 198 minecraft:bone_block
fill 329 136 199 329 141 200 minecraft:calcite
setblock 329 136 201 minecraft:bone_block
fill 329 136 202 329 139 202 minecraft:calcite
fill 329 136 209 329 137 210 minecraft:bone_block
fill 329 136 211 329 141 212 minecraft:calcite
fill 329 136 218 329 137 218 minecraft:bone_block
fill 329 136 219 329 137 220 minecraft:calcite
fill 329 136 221 329 136 222 minecraft:bone_block
fill 329 136 223 329 141 223 minecraft:calcite
fill 334 136 181 335 141 181 minecraft:calcite
fill 335 136 223 336 137 223 minecraft:bone_block
fill 336 136 181 337 137 181 minecraft:bone_block
fill 337 136 223 338 141 223 minecraft:calcite
setblock 345 136 181 minecraft:bone_block
fill 346 136 181 347 141 181 minecraft:calcite
fill 346 136 223 346 141 223 minecraft:calcite
fill 347 136 223 348 136 223 minecraft:bone_block
fill 348 136 181 349 137 181 minecraft:bone_block
fill 349 136 223 350 141 223 minecraft:calcite
fill 354 136 181 355 141 181 minecraft:calcite
fill 355 136 223 356 137 223 minecraft:bone_block
fill 356 136 181 357 136 181 minecraft:bone_block
fill 357 136 223 358 141 223 minecraft:calcite
fill 358 136 181 358 141 181 minecraft:calcite
setblock 359 136 223 minecraft:bone_block
fill 366 136 181 367 141 181 minecraft:calcite
fill 367 136 223 368 137 223 minecraft:bone_block
fill 368 136 181 369 137 181 minecraft:bone_block
fill 369 136 223 370 141 223 minecraft:calcite
fill 371 136 185 371 141 185 minecraft:calcite
setblock 371 136 187 minecraft:bone_block
fill 371 136 188 371 141 189 minecraft:calcite
fill 371 136 190 371 137 190 minecraft:bone_block
fill 371 136 196 371 141 197 minecraft:calcite
fill 371 136 198 371 136 199 minecraft:bone_block
fill 371 136 208 371 141 209 minecraft:calcite
fill 371 136 210 371 137 211 minecraft:bone_block
fill 371 136 217 371 141 217 minecraft:calcite
fill 371 136 218 371 136 219 minecraft:bone_block
fill 371 136 220 371 141 220 minecraft:calcite
fill 371 136 222 371 137 222 minecraft:bone_block
fill 329 137 185 329 137 186 minecraft:bone_block
setblock 329 137 189 minecraft:bone_block
fill 329 137 190 329 140 190 minecraft:calcite
fill 329 137 201 329 139 201 minecraft:calcite
setblock 329 137 206 minecraft:bone_block
setblock 329 137 217 minecraft:bone_block
fill 329 137 221 329 139 222 minecraft:calcite
setblock 332 137 184 minecraft:light[level=12]
setblock 332 137 192 minecraft:light[level=12]
setblock 332 137 200 minecraft:light[level=12]
setblock 332 137 208 minecraft:light[level=12]
setblock 332 137 216 minecraft:light[level=12]
setblock 340 137 181 minecraft:bone_block
setblock 340 137 184 minecraft:light[level=12]
setblock 340 137 192 minecraft:light[level=12]
setblock 340 137 200 minecraft:light[level=12]
setblock 340 137 208 minecraft:light[level=12]
setblock 340 137 216 minecraft:light[level=12]
fill 343 137 223 344 137 223 minecraft:bone_block
fill 345 137 181 345 140 181 minecraft:calcite
setblock 347 137 223 minecraft:bone_block
setblock 348 137 184 minecraft:light[level=12]
setblock 348 137 192 minecraft:light[level=12]
setblock 348 137 200 minecraft:light[level=12]
setblock 348 137 208 minecraft:light[level=12]
setblock 348 137 216 minecraft:light[level=12]
fill 348 137 223 348 140 223 minecraft:calcite
fill 356 137 181 356 140 181 minecraft:calcite
setblock 356 137 184 minecraft:light[level=12]
setblock 356 137 192 minecraft:light[level=12]
setblock 356 137 200 minecraft:light[level=12]
setblock 356 137 208 minecraft:light[level=12]
setblock 356 137 216 minecraft:light[level=12]
setblock 357 137 181 minecraft:bone_block
fill 359 137 223 359 140 223 minecraft:calcite
fill 360 137 181 361 137 181 minecraft:bone_block
setblock 364 137 184 minecraft:light[level=12]
setblock 364 137 192 minecraft:light[level=12]
setblock 364 137 200 minecraft:light[level=12]
setblock 364 137 208 minecraft:light[level=12]
setblock 364 137 216 minecraft:light[level=12]
setblock 364 137 223 minecraft:bone_block
fill 371 137 187 371 140 187 minecraft:calcite
setblock 371 137 191 minecraft:bone_block
fill 371 137 198 371 140 198 minecraft:calcite
setblock 371 137 199 minecraft:bone_block
setblock 371 137 202 minecraft:bone_block
fill 371 137 218 371 140 219 minecraft:calcite
fill 329 138 184 329 139 184 minecraft:bone_block
fill 329 138 185 329 143 186 minecraft:calcite
setblock 329 138 187 minecraft:bone_block
fill 329 138 189 329 140 189 minecraft:calcite
fill 329 138 195 329 139 196 minecraft:bone_block
fill 329 138 197 329 143 198 minecraft:calcite
setblock 329 138 203 minecraft:calcite
fill 329 138 204 329 139 204 minecraft:bone_block
fill 329 138 206 329 143 206 minecraft:calcite
fill 329 138 207 329 138 208 minecraft:bone_block
fill 329 138 209 329 140 210 minecraft:calcite
fill 329 138 215 329 139 216 minecraft:bone_block
fill 329 138 217 329 143 218 minecraft:calcite
setblock 329 138 219 minecraft:bone_block
fill 329 138 220 329 141 220 minecraft:calcite
fill 330 138 181 331 139 181 minecraft:bone_block
fill 330 138 182 332 138 182 minecraft:polished_basalt
fill 330 138 184 330 138 186 minecraft:polished_basalt
fill 330 138 188 330 138 190 minecraft:polished_basalt
fill 330 138 192 330 138 194 minecraft:polished_basalt
fill 330 138 196 330 138 198 minecraft:polished_basalt
fill 330 138 200 330 138 202 minecraft:polished_basalt
fill 330 138 204 330 138 206 minecraft:polished_basalt
fill 330 138 208 330 138 210 minecraft:polished_basalt
fill 330 138 212 330 138 214 minecraft:polished_basalt
fill 330 138 216 330 138 218 minecraft:polished_basalt
fill 330 138 220 330 138 222 minecraft:polished_basalt
fill 332 138 222 334 138 222 minecraft:polished_basalt
fill 333 138 223 334 138 223 minecraft:bone_block
fill 334 138 182 336 138 182 minecraft:polished_basalt
fill 335 138 223 336 143 223 minecraft:calcite
fill 336 138 181 337 143 181 minecraft:calcite
fill 336 138 222 338 138 222 minecraft:polished_basalt
fill 338 138 181 339 138 181 minecraft:bone_block
fill 338 138 182 340 138 182 minecraft:polished_basalt
fill 340 138 181 340 143 181 minecraft:calcite
fill 340 138 222 342 138 222 minecraft:polished_basalt
fill 342 138 182 344 138 182 minecraft:polished_basalt
fill 342 138 223 342 139 223 minecraft:bone_block
fill 343 138 223 344 143 223 minecraft:calcite
fill 344 138 222 346 138 222 minecraft:polished_basalt
setblock 345 138 223 minecraft:bone_block
fill 346 138 182 348 138 182 minecraft:polished_basalt
fill 347 138 223 347 143 223 minecraft:calcite
fill 348 138 181 349 143 181 minecraft:calcite
fill 348 138 222 350 138 222 minecraft:polished_basalt
fill 350 138 181 351 139 181 minecraft:bone_block
fill 350 138 182 352 138 182 minecraft:polished_basalt
fill 352 138 222 354 138 222 minecraft:polished_basalt
fill 353 138 223 354 139 223 minecraft:bone_block
fill 354 138 182 356 138 182 minecraft:polished_basalt
fill 355 138 223 356 143 223 minecraft:calcite
fill 356 138 222 358 138 222 minecraft:polished_basalt
fill 357 138 181 357 143 181 minecraft:calcite
fill 358 138 182 360 138 182 minecraft:polished_basalt
setblock 359 138 181 minecraft:bone_block
fill 360 138 181 361 143 181 minecraft:calcite
fill 360 138 222 362 138 222 minecraft:polished_basalt
fill 362 138 181 362 139 181 minecraft:bone_block
fill 362 138 182 364 138 182 minecraft:polished_basalt
fill 364 138 222 366 138 222 minecraft:polished_basalt
fill 364 138 223 364 143 223 minecraft:calcite
fill 365 138 223 366 138 223 minecraft:bone_block
fill 366 138 182 368 138 182 minecraft:polished_basalt
fill 367 138 223 368 143 223 minecraft:calcite
fill 368 138 181 369 143 181 minecraft:calcite
fill 368 138 222 370 138 222 minecraft:polished_basalt
fill 370 138 181 371 138 181 minecraft:bone_block
fill 370 138 182 370 138 184 minecraft:polished_basalt
fill 370 138 186 370 138 188 minecraft:polished_basalt
fill 370 138 190 370 138 192 minecraft:polished_basalt
fill 370 138 194 370 138 196 minecraft:polished_basalt
fill 370 138 198 370 138 200 minecraft:polished_basalt
fill 370 138 202 370 138 204 minecraft:polished_basalt
fill 370 138 206 370 138 208 minecraft:polished_basalt
fill 370 138 210 370 138 212 minecraft:polished_basalt
fill 370 138 214 370 138 216 minecraft:polished_basalt
fill 370 138 218 370 138 220 minecraft:polished_basalt
fill 371 138 190 371 143 191 minecraft:calcite
fill 371 138 192 371 139 193 minecraft:bone_block
fill 371 138 199 371 143 199 minecraft:calcite
fill 371 138 200 371 138 201 minecraft:bone_block
fill 371 138 202 371 143 202 minecraft:calcite
fill 371 138 204 371 139 204 minecraft:bone_block
fill 371 138 210 371 143 211 minecraft:calcite
fill 371 138 212 371 139 213 minecraft:bone_block
setblock 371 138 221 minecraft:bone_block
fill 371 138 222 371 143 222 minecraft:calcite
setblock 329 139 183 minecraft:bone_block
fill 329 139 187 329 142 187 minecraft:calcite
fill 329 139 191 329 141 191 minecraft:calcite
setblock 329 139 192 minecraft:bone_block
setblock 329 139 203 minecraft:bone_block
setblock 329 139 207 minecraft:bone_block
fill 329 139 208 329 142 208 minecraft:calcite
fill 329 139 219 329 141 219 minecraft:calcite
setblock 330 139 223 minecraft:bone_block
setblock 333 139 223 minecraft:bone_block
fill 334 139 223 334 142 223 minecraft:calcite
fill 338 139 181 338 142 181 minecraft:calcite
setblock 339 139 181 minecraft:bone_block
setblock 341 139 223 minecraft:bone_block
fill 342 139 181 343 139 181 minecraft:bone_block
fill 345 139 223 345 142 223 minecraft:calcite
fill 359 139 181 359 142 181 minecraft:calcite
fill 361 139 223 362 139 223 minecraft:bone_block
setblock 363 139 181 minecraft:bone_block
setblock 365 139 223 minecraft:bone_block
fill 366 139 223 366 142 223 minecraft:calcite
fill 370 139 181 370 142 181 minecraft:calcite
setblock 371 139 181 minecraft:bone_block
setblock 371 139 184 minecraft:bone_block
fill 371 139 200 371 142 201 minecraft:calcite
setblock 371 139 205 minecraft:bone_block
setblock 371 139 216 minecraft:bone_block
fill 371 139 221 371 142 221 minecraft:calcite
fill 329 140 181 329 141 182 minecraft:bone_block
fill 329 140 183 329 145 184 minecraft:calcite
fill 329 140 192 329 141 192 minecraft:calcite
fill 329 140 193 329 140 194 minecraft:bone_block
fill 329 140 195 329 145 196 minecraft:calcite
fill 329 140 201 329 141 202 minecraft:bone_block
fill 329 140 203 329 145 204 minecraft:calcite
setblock 329 140 205 minecraft:bone_block
fill 329 140 207 329 142 207 minecraft:calcite
fill 329 140 213 329 141 214 minecraft:bone_block
fill 329 140 215 329 145 216 minecraft:calcite
setblock 329 140 221 minecraft:calcite
fill 329 140 222 329 141 222 minecraft:bone_block
fill 330 140 181 331 145 181 minecraft:calcite
fill 330 140 223 330 145 223 minecraft:calcite
fill 331 140 223 332 140 223 minecraft:bone_block
fill 332 140 181 333 141 181 minecraft:bone_block
fill 333 140 223 333 145 223 minecraft:calcite
fill 339 140 181 339 145 181 minecraft:calcite
fill 339 140 223 340 141 223 minecraft:bone_block
setblock 341 140 181 minecraft:bone_block
fill 341 140 223 342 145 223 minecraft:calcite
fill 342 140 181 343 145 181 minecraft:calcite
fill 344 140 181 344 141 181 minecraft:bone_block
fill 350 140 181 351 145 181 minecraft:calcite
fill 351 140 223 352 140 223 minecraft:bone_block
fill 352 140 181 353 140 181 minecraft:bone_block
fill 353 140 223 354 145 223 minecraft:calcite
fill 360 140 223 360 141 223 minecraft:bone_block
fill 361 140 223 362 145 223 minecraft:calcite
fill 362 140 181 363 145 181 minecraft:calcite
setblock 363 140 223 minecraft:bone_block
fill 364 140 181 365 141 181 minecraft:bone_block
fill 365 140 223 365 145 223 minecraft:calcite
fill 371 140 181 371 145 181 minecraft:calcite
fill 371 140 182 371 140 183 minecraft:bone_block
fill 371 140 184 371 145 184 minecraft:calcite
fill 371 140 186 371 141 186 minecraft:bone_block
fill 371 140 192 371 145 193 minecraft:calcite
fill 371 140 194 371 141 195 minecraft:bone_block
setblock 371 140 203 minecraft:bone_block
fill 371 140 204 371 145 205 minecraft:calcite
fill 371 140 206 371 141 207 minecraft:bone_block
fill 371 140 212 371 145 213 minecraft:calcite
fill 371 140 214 371 140 215 minecraft:bone_block
fill 371 140 216 371 145 216 minecraft:calcite
fill 371 140 223 371 141 223 minecraft:bone_block
fill 329 141 189 329 141 190 minecraft:bone_block
setblock 329 141 193 minecraft:bone_block
fill 329 141 194 329 144 194 minecraft:calcite
fill 329 141 205 329 144 205 minecraft:calcite
fill 329 141 209 329 143 209 minecraft:calcite
setblock 329 141 210 minecraft:bone_block
setblock 329 141 221 minecraft:bone_block
fill 331 141 223 332 144 223 minecraft:calcite
fill 341 141 181 341 144 181 minecraft:calcite
setblock 345 141 181 minecraft:bone_block
setblock 348 141 223 minecraft:bone_block
setblock 351 141 223 minecraft:bone_block
fill 352 141 181 352 144 181 minecraft:calcite
fill 352 141 223 352 144 223 minecraft:calcite
setblock 353 141 181 minecraft:bone_block
setblock 356 141 181 minecraft:bone_block
setblock 359 141 223 minecraft:bone_block
fill 363 141 223 363 144 223 minecraft:calcite
fill 371 141 182 371 144 183 minecraft:calcite
setblock 371 141 187 minecraft:bone_block
setblock 371 141 198 minecraft:bone_block
fill 371 141 203 371 144 203 minecraft:calcite
fill 371 141 214 371 144 214 minecraft:calcite
setblock 371 141 215 minecraft:bone_block
fill 371 141 218 371 141 219 minecraft:bone_block
fill 329 142 181 329 147 182 minecraft:calcite
fill 329 142 188 329 143 188 minecraft:bone_block
fill 329 142 189 329 143 190 minecraft:calcite
fill 329 142 191 329 142 192 minecraft:bone_block
fill 329 142 193 329 147 193 minecraft:calcite
fill 329 142 199 329 143 200 minecraft:bone_block
fill 329 142 201 329 147 202 minecraft:calcite
fill 329 142 210 329 143 210 minecraft:calcite
fill 329 142 211 329 142 212 minecraft:bone_block
fill 329 142 213 329 147 214 minecraft:calcite
fill 329 142 219 329 143 220 minecraft:bone_block
fill 329 142 221 329 147 222 minecraft:calcite
setblock 329 142 223 minecraft:bone_block
fill 332 142 181 333 147 181 minecraft:calcite
fill 334 142 181 335 142 181 minecraft:bone_block
fill 337 142 223 338 143 223 minecraft:bone_block
fill 339 142 223 340 147 223 minecraft:calcite
fill 344 142 181 345 147 181 minecraft:calcite
fill 346 142 181 347 143 181 minecraft:bone_block
fill 346 142 187 346 143 187 minecraft:calcite
fill 346 142 223 346 143 223 minecraft:bone_block
fill 348 142 223 348 147 223 minecraft:calcite
fill 349 142 223 350 142 223 minecraft:bone_block
fill 351 142 223 351 147 223 minecraft:calcite
fill 353 142 181 353 147 181 minecraft:calcite
fill 354 142 181 355 142 181 minecraft:bone_block
fill 356 142 181 356 147 181 minecraft:calcite
fill 357 142 223 358 143 223 minecraft:bone_block
fill 358 142 181 358 143 181 minecraft:bone_block
fill 359 142 223 360 147 223 minecraft:calcite
fill 364 142 181 365 147 181 minecraft:calcite
fill 366 142 181 367 143 181 minecraft:bone_block
fill 369 142 223 370 142 223 minecraft:bone_block
setblock 371 142 185 minecraft:bone_block
fill 371 142 186 371 147 187 minecraft:calcite
fill 371 142 188 371 143 189 minecraft:bone_block
fill 371 142 194 371 147 195 minecraft:calcite
fill 371 142 196 371 142 197 minecraft:bone_block
fill 371 142 198 371 147 198 minecraft:calcite
fill 371 142 206 371 147 207 minecraft:calcite
fill 371 142 208 371 143 209 minecraft:bone_block
fill 371 142 215 371 147 215 minecraft:calcite
setblock 371 142 217 minecraft:bone_block
fill 371 142 218 371 147 219 minecraft:calcite
fill 371 142 220 371 143 220 minecraft:bone_block
fill 371 142 223 371 147 223 minecraft:calcite
setblock 329 143 187 minecraft:bone_block
fill 329 143 191 329 145 192 minecraft:calcite
fill 329 143 207 329 143 208 minecraft:bone_block
setblock 329 143 211 minecraft:bone_block
fill 329 143 212 329 146 212 minecraft:calcite
fill 329 143 223 329 146 223 minecraft:calcite
fill 334 143 181 334 146 181 minecraft:calcite
setblock 334 143 223 minecraft:bone_block
setblock 335 143 181 minecraft:bone_block
setblock 338 143 181 minecraft:bone_block
setblock 345 143 223 minecraft:bone_block
fill 349 143 223 350 146 223 minecraft:calcite
fill 354 143 181 355 146 181 minecraft:calcite
setblock 359 143 181 minecraft:bone_block
setblock 366 143 223 minecraft:bone_block
setblock 369 143 223 minecraft:bone_block
setblock 370 143 181 minecraft:bone_block
fill 370 143 223 370 146 223 minecraft:calcite
fill 371 143 185 371 146 185 minecraft:calcite
fill 371 143 196 371 146 196 minecraft:calcite
setblock 371 143 197 minecraft:bone_block
fill 371 143 200 371 143 201 minecraft:bone_block
fill 371 143 217 371 146 217 minecraft:calcite
setblock 371 143 221 minecraft:bone_block
fill 329 144 185 329 145 186 minecraft:bone_block
fill 329 144 187 329 149 188 minecraft:calcite
setblock 329 144 189 minecraft:bone_block
fill 329 144 190 329 147 190 minecraft:calcite
fill 329 144 197 329 145 198 minecraft:bone_block
fill 329 144 199 329 149 200 minecraft:calcite
fill 329 144 206 329 145 206 minecraft:bone_block
fill 329 144 207 329 145 208 minecraft:calcite
fill 329 144 209 329 144 210 minecraft:bone_block
fill 329 144 211 329 149 211 minecraft:calcite
fill 329 144 217 329 145 218 minecraft:bone_block
fill 329 144 219 329 149 220 minecraft:calcite
fill 330 144 182 332 144 182 minecraft:polished_basalt
fill 330 144 184 330 144 186 minecraft:polished_basalt
fill 330 144 188 330 144 190 minecraft:polished_basalt
fill 330 144 192 330 144 194 minecraft:polished_basalt
fill 330 144 196 330 144 198 minecraft:polished_basalt
fill 330 144 200 330 144 202 minecraft:polished_basalt
fill 330 144 204 330 144 206 minecraft:polished_basalt
fill 330 144 208 330 144 210 minecraft:polished_basalt
fill 330 144 212 330 144 214 minecraft:polished_basalt
fill 330 144 216 330 144 218 minecraft:polished_basalt
fill 330 144 220 330 144 222 minecraft:polished_basalt
fill 332 144 222 334 144 222 minecraft:polished_basalt
fill 334 144 182 336 144 182 minecraft:polished_basalt
fill 334 144 223 334 149 223 minecraft:calcite
fill 335 144 181 335 149 181 minecraft:calcite
fill 335 144 223 336 144 223 minecraft:bone_block
fill 336 144 181 337 144 181 minecraft:bone_block
fill 336 144 222 338 144 222 minecraft:polished_basalt
fill 337 144 223 338 149 223 minecraft:calcite
fill 338 144 181 338 149 181 minecraft:calcite
fill 338 144 182 340 144 182 minecraft:polished_basalt
fill 340 144 181 340 145 181 minecraft:bone_block
fill 340 144 222 342 144 222 minecraft:polished_basalt
fill 342 144 182 344 144 182 minecraft:polished_basalt
fill 343 144 223 344 145 223 minecraft:bone_block
fill 344 144 222 346 144 222 minecraft:polished_basalt
fill 345 144 223 346 149 223 minecraft:calcite
fill 346 144 181 347 149 181 minecraft:calcite
fill 346 144 182 348 144 182 minecraft:polished_basalt
setblock 347 144 223 minecraft:bone_block
fill 348 144 181 349 145 181 minecraft:bone_block
fill 348 144 222 350 144 222 minecraft:polished_basalt
fill 350 144 182 352 144 182 minecraft:polished_basalt
fill 352 144 222 354 144 222 minecraft:polished_basalt
fill 354 144 182 356 144 182 minecraft:polished_basalt
fill 355 144 223 356 145 223 minecraft:bone_block
fill 356 144 222 358 144 222 minecraft:polished_basalt
setblock 357 144 181 minecraft:bone_block
fill 357 144 223 358 149 223 minecraft:calcite
fill 358 144 181 359 149 181 minecraft:calcite
fill 358 144 182 360 144 182 minecraft:polished_basalt
fill 360 144 181 361 145 181 minecraft:bone_block
fill 360 144 222 362 144 222 minecraft:polished_basalt
fill 362 144 182 364 144 182 minecraft:polished_basalt
fill 364 144 222 366 144 222 minecraft:polished_basalt
fill 364 144 223 364 145 223 minecraft:bone_block
fill 366 144 181 367 149 181 minecraft:calcite
fill 366 144 182 368 144 182 minecraft:polished_basalt
fill 366 144 223 366 149 223 minecraft:calcite
fill 367 144 223 368 144 223 minecraft:bone_block
fill 368 144 181 369 144 181 minecraft:bone_block
fill 368 144 222 370 144 222 minecraft:polished_basalt
fill 369 144 223 369 149 223 minecraft:calcite
fill 370 144 181 370 149 181 minecraft:calcite
fill 370 144 182 370 144 184 minecraft:polished_basalt
fill 370 144 186 370 144 188 minecraft:polished_basalt
fill 370 144 190 370 144 192 minecraft:polished_basalt
fill 370 144 194 370 144 196 minecraft:polished_basalt
fill 370 144 198 370 144 200 minecraft:polished_basalt
fill 370 144 202 370 144 204 minecraft:polished_basalt
fill 370 144 206 370 144 208 minecraft:polished_basalt
fill 370 144 210 370 144 212 minecraft:polished_basalt
fill 370 144 214 370 144 216 minecraft:polished_basalt
fill 370 144 218 370 144 220 minecraft:polished_basalt
fill 371 144 188 371 149 189 minecraft:calcite
fill 371 144 190 371 145 191 minecraft:bone_block
fill 371 144 197 371 149 197 minecraft:calcite
setblock 371 144 199 minecraft:bone_block
fill 371 144 200 371 149 201 minecraft:calcite
fill 371 144 202 371 145 202 minecraft:bone_block
fill 371 144 208 371 149 209 minecraft:calcite
fill 371 144 210 371 144 211 minecraft:bone_block
fill 371 144 220 371 149 221 minecraft:calcite
fill 371 144 222 371 145 222 minecraft:bone_block
fill 329 145 189 329 147 189 minecraft:calcite
setblock 329 145 194 minecraft:bone_block
setblock 329 145 205 minecraft:bone_block
fill 329 145 209 329 147 210 minecraft:calcite
fill 331 145 223 332 145 223 minecraft:bone_block
setblock 332 145 184 minecraft:light[level=12]
setblock 332 145 192 minecraft:light[level=12]
setblock 332 145 200 minecraft:light[level=12]
setblock 332 145 208 minecraft:light[level=12]
setblock 332 145 216 minecraft:light[level=12]
setblock 335 145 223 minecraft:bone_block
fill 336 145 181 337 148 181 minecraft:calcite
fill 336 145 223 336 148 223 minecraft:calcite
setblock 340 145 184 minecraft:light[level=12]
setblock 340 145 192 minecraft:light[level=12]
setblock 340 145 200 minecraft:light[level=12]
setblock 340 145 208 minecraft:light[level=12]
setblock 340 145 216 minecraft:light[level=12]
setblock 341 145 181 minecraft:bone_block
fill 347 145 223 347 148 223 minecraft:calcite
setblock 348 145 184 minecraft:light[level=12]
setblock 348 145 192 minecraft:light[level=12]
setblock 348 145 200 minecraft:light[level=12]
setblock 348 145 208 minecraft:light[level=12]
setblock 348 145 216 minecraft:light[level=12]
setblock 352 145 181 minecraft:bone_block
setblock 352 145 223 minecraft:bone_block
setblock 356 145 184 minecraft:light[level=12]
setblock 356 145 192 minecraft:light[level=12]
setblock 356 145 200 minecraft:light[level=12]
setblock 356 145 208 minecraft:light[level=12]
setblock 356 145 216 minecraft:light[level=12]
fill 357 145 181 357 148 181 minecraft:calcite
setblock 363 145 223 minecraft:bone_block
setblock 364 145 184 minecraft:light[level=12]
setblock 364 145 192 minecraft:light[level=12]
setblock 364 145 200 minecraft:light[level=12]
setblock 364 145 208 minecraft:light[level=12]
setblock 364 145 216 minecraft:light[level=12]
fill 367 145 223 368 148 223 minecraft:calcite
fill 368 145 181 368 148 181 minecraft:calcite
setblock 369 145 181 minecraft:bone_block
fill 371 145 182 371 145 183 minecraft:bone_block
fill 371 145 199 371 148 199 minecraft:calcite
setblock 371 145 203 minecraft:bone_block
fill 371 145 210 371 148 210 minecraft:calcite
setblock 371 145 211 minecraft:bone_block
setblock 371 145 214 minecraft:bone_block
fill 329 146 183 329 147 184 minecraft:bone_block
fill 329 146 185 329 151 186 minecraft:calcite
setblock 329 146 191 minecraft:calcite
fill 329 146 192 329 147 192 minecraft:bone_block
fill 329 146 194 329 151 194 minecraft:calcite
fill 329 146 195 329 146 196 minecraft:bone_block
fill 329 146 197 329 148 198 minecraft:calcite
fill 329 146 203 329 147 204 minecraft:bone_block
fill 329 146 205 329 151 206 minecraft:calcite
setblock 329 146 207 minecraft:bone_block
fill 329 146 208 329 149 208 minecraft:calcite
fill 329 146 215 329 146 216 minecraft:bone_block
fill 329 146 217 329 151 218 minecraft:calcite
fill 330 146 181 331 147 181 minecraft:bone_block
fill 330 146 223 330 147 223 minecraft:bone_block
fill 331 146 223 332 151 223 minecraft:calcite
setblock 333 146 223 minecraft:bone_block
fill 335 146 223 335 151 223 minecraft:calcite
setblock 339 146 181 minecraft:bone_block
fill 340 146 181 341 151 181 minecraft:calcite
fill 341 146 223 342 147 223 minecraft:bone_block
fill 342 146 181 343 147 181 minecraft:bone_block
fill 343 146 223 344 151 223 minecraft:calcite
fill 348 146 181 349 151 181 minecraft:calcite
fill 350 146 181 351 146 181 minecraft:bone_block
fill 352 146 181 352 151 181 minecraft:calcite
fill 352 146 223 352 151 223 minecraft:calcite
fill 353 146 223 354 146 223 minecraft:bone_block
fill 355 146 223 356 151 223 minecraft:calcite
fill 360 146 181 361 151 181 minecraft:calcite
fill 361 146 223 362 147 223 minecraft:bone_block
fill 362 146 181 363 147 181 minecraft:bone_block
fill 363 146 223 364 151 223 minecraft:calcite
setblock 365 146 223 minecraft:bone_block
fill 369 146 181 369 151 181 minecraft:calcite
setblock 371 146 181 minecraft:bone_block
fill 371 146 182 371 151 183 minecraft:calcite
fill 371 146 184 371 147 184 minecraft:bone_block
fill 371 146 190 371 151 191 minecraft:calcite
fill 371 146 192 371 146 193 minecraft:bone_block
fill 371 146 202 371 151 203 minecraft:calcite
fill 371 146 204 371 147 205 minecraft:bone_block
fill 371 146 211 371 151 211 minecraft:calcite
fill 371 146 212 371 146 213 minecraft:bone_block
fill 371 146 214 371 151 214 minecraft:calcite
fill 371 146 216 371 147 216 minecraft:bone_block
fill 371 146 222 371 151 222 minecraft:calcite
setblock 329 147 191 minecraft:bone_block
setblock 329 147 195 minecraft:bone_block
fill 329 147 196 329 150 196 minecraft:calcite
fill 329 147 207 329 149 207 minecraft:calcite
setblock 329 147 212 minecraft:bone_block
setblock 329 147 215 minecraft:bone_block
fill 329 147 216 329 150 216 minecraft:calcite
setblock 329 147 223 minecraft:bone_block
fill 333 147 223 333 150 223 minecraft:calcite
setblock 334 147 181 minecraft:bone_block
fill 339 147 181 339 150 181 minecraft:calcite
fill 349 147 223 350 147 223 minecraft:bone_block
fill 350 147 181 350 150 181 minecraft:calcite
setblock 351 147 181 minecraft:bone_block
setblock 353 147 223 minecraft:bone_block
fill 354 147 181 355 147 181 minecraft:bone_block
fill 354 147 223 354 150 223 minecraft:calcite
fill 365 147 223 365 150 223 minecraft:calcite
setblock 370 147 223 minecraft:bone_block
fill 371 147 181 371 150 181 minecraft:calcite
setblock 371 147 185 minecraft:bone_block
fill 371 147 192 371 150 192 minecraft:calcite
setblock 371 147 193 minecraft:bone_block
setblock 371 147 196 minecraft:bone_block
fill 371 147 212 371 150 213 minecraft:calcite
setblock 371 147 217 minecraft:bone_block
fill 329 148 181 329 148 182 minecraft:bone_block
fill 329 148 183 329 153 184 minecraft:calcite
fill 329 148 189 329 149 190 minecraft:bone_block
fill 329 148 191 329 153 192 minecraft:calcite
setblock 329 148 193 minecraft:bone_block
fill 329 148 195 329 150 195 minecraft:calcite
fill 329 148 201 329 149 202 minecraft:bone_block
fill 329 148 203 329 153 204 minecraft:calcite
setblock 329 148 209 minecraft:calcite
fill 329 148 210 329 149 210 minecraft:bone_block
fill 329 148 212 329 153 212 minecraft:calcite
fill 329 148 213 329 148 214 minecraft:bone_block
fill 329 148 215 329 153 215 minecraft:calcite
fill 329 148 221 329 149 222 minecraft:bone_block
fill 329 148 223 330 153 223 minecraft:calcite
fill 330 148 181 331 153 181 minecraft:calcite
fill 332 148 181 333 148 181 minecraft:bone_block
fill 334 148 181 334 153 181 minecraft:calcite
fill 339 148 223 340 148 223 minecraft:bone_block
fill 341 148 223 342 153 223 minecraft:calcite
fill 342 148 181 343 153 181 minecraft:calcite
fill 344 148 181 345 149 181 minecraft:bone_block
fill 348 148 223 348 149 223 minecraft:bone_block
fill 349 148 223 350 153 223 minecraft:calcite
fill 351 148 181 351 153 181 minecraft:calcite
setblock 351 148 223 minecraft:bone_block
setblock 353 148 181 minecraft:bone_block
fill 353 148 223 353 153 223 minecraft:calcite
fill 354 148 181 355 153 181 minecraft:calcite
fill 356 148 181 356 149 181 minecraft:bone_block
fill 359 148 223 360 149 223 minecraft:bone_block
fill 361 148 223 362 153 223 minecraft:calcite
fill 362 148 181 363 153 181 minecraft:calcite
fill 364 148 181 365 148 181 minecraft:bone_block
fill 370 148 223 370 153 223 minecraft:calcite
fill 371 148 184 371 153 185 minecraft:calcite
fill 371 148 186 371 149 187 minecraft:bone_block
fill 371 148 193 371 153 193 minecraft:calcite
fill 371 148 194 371 148 195 minecraft:bone_block
fill 371 148 196 371 153 196 minecraft:calcite
fill 371 148 198 371 149 198 minecraft:bone_block
fill 371 148 204 371 153 205 minecraft:calcite
fill 371 148 206 371 149 207 minecraft:bone_block
setblock 371 148 215 minecraft:bone_block
fill 371 148 216 371 153 217 minecraft:calcite
fill 371 148 218 371 149 219 minecraft:bone_block
fill 371 148 223 371 149 223 minecraft:bone_block
setblock 329 149 181 minecraft:bone_block
fill 329 149 182 329 152 182 minecraft:calcite
fill 329 149 193 329 152 193 minecraft:calcite
fill 329 149 197 329 151 197 minecraft:calcite
setblock 329 149 198 minecraft:bone_block
setblock 329 149 209 minecraft:bone_block
fill 329 149 213 329 152 214 minecraft:calcite
fill 332 149 181 332 152 181 minecraft:calcite
setblock 333 149 181 minecraft:bone_block
fill 336 149 181 337 149 181 minecraft:bone_block
setblock 336 149 223 minecraft:bone_block
setblock 339 149 223 minecraft:bone_block
fill 340 149 223 340 152 223 minecraft:calcite
setblock 347 149 223 minecraft:bone_block
fill 351 149 223 351 152 223 minecraft:calcite
fill 353 149 181 353 152 181 minecraft:calcite
setblock 357 149 181 minecraft:bone_block
fill 364 149 181 364 152 181 minecraft:calcite
setblock 365 149 181 minecraft:bone_block
fill 367 149 223 368 149 223 minecraft:bone_block
setblock 368 149 181 minecraft:bone_block
fill 371 149 194 371 152 195 minecraft:calcite
setblock 371 149 199 minecraft:bone_block
setblock 371 149 210 minecraft:bone_block
fill 371 149 215 371 152 215 minecraft:calcite
fill 329 150 181 329 155 181 minecraft:calcite
fill 329 150 187 329 151 188 minecraft:bone_block
fill 329 150 189 329 155 190 minecraft:calcite
fill 329 150 198 329 151 198 minecraft:calcite
fill 329 150 199 329 150 200 minecraft:bone_block
fill 329 150 201 329 155 202 minecraft:calcite
fill 329 150 207 329 151 208 minecraft:bone_block
fill 329 150 209 329 155 210 minecraft:calcite
setblock 329 150 211 minecraft:bone_block
fill 329 150 219 329 151 220 minecraft:bone_block
fill 329 150 221 329 155 222 minecraft:calcite
fill 330 150 182 332 150 182 minecraft:polished_basalt
fill 330 150 184 330 150 186 minecraft:polished_basalt
fill 330 150 188 330 150 190 minecraft:polished_basalt
fill 330 150 192 330 150 194 minecraft:polished_basalt
fill 330 150 196 330 150 198 minecraft:polished_basalt
fill 330 150 200 330 150 202 minecraft:polished_basalt
fill 330 150 204 330 150 206 minecraft:polished_basalt
fill 330 150 208 330 150 210 minecraft:polished_basalt
fill 330 150 212 330 150 214 minecraft:polished_basalt
fill 330 150 216 330 150 218 minecraft:polished_basalt
fill 330 150 220 330 150 222 minecraft:polished_basalt
fill 332 150 222 334 150 222 minecraft:polished_basalt
fill 333 150 181 333 155 181 minecraft:calcite
fill 334 150 182 336 150 182 minecraft:polished_basalt
fill 334 150 223 334 151 223 minecraft:bone_block
setblock 335 150 181 minecraft:bone_block
fill 336 150 181 337 155 181 minecraft:calcite
fill 336 150 222 338 150 222 minecraft:polished_basalt
fill 336 150 223 336 155 223 minecraft:calcite
fill 337 150 223 338 150 223 minecraft:bone_block
fill 338 150 181 338 151 181 minecraft:bone_block
fill 338 150 182 340 150 182 minecraft:polished_basalt
fill 339 150 223 339 155 223 minecraft:calcite
fill 340 150 222 342 150 222 minecraft:polished_basalt
fill 342 150 182 344 150 182 minecraft:polished_basalt
fill 344 150 181 345 155 181 minecraft:calcite
fill 344 150 222 346 150 222 minecraft:polished_basalt
fill 345 150 223 346 151 223 minecraft:bone_block
fill 346 150 181 347 150 181 minecraft:bone_block
fill 346 150 182 348 150 182 minecraft:polished_basalt
fill 347 150 223 348 155 223 minecraft:calcite
fill 348 150 222 350 150 222 minecraft:polished_basalt
fill 350 150 182 352 150 182 minecraft:polished_basalt
fill 352 150 222 354 150 222 minecraft:polished_basalt
fill 354 150 182 356 150 182 minecraft:polished_basalt
fill 356 150 181 357 155 181 minecraft:calcite
fill 356 150 222 358 150 222 minecraft:polished_basalt
fill 357 150 223 358 150 223 minecraft:bone_block
fill 358 150 181 359 151 181 minecraft:bone_block
fill 358 150 182 360 150 182 minecraft:polished_basalt
fill 359 150 223 360 155 223 minecraft:calcite
fill 360 150 222 362 150 222 minecraft:polished_basalt
fill 362 150 182 364 150 182 minecraft:polished_basalt
fill 364 150 222 366 150 222 minecraft:polished_basalt
fill 365 150 181 365 155 181 minecraft:calcite
fill 366 150 181 367 150 181 minecraft:bone_block
fill 366 150 182 368 150 182 minecraft:polished_basalt
fill 366 150 223 366 151 223 minecraft:bone_block
fill 367 150 223 368 155 223 minecraft:calcite
fill 368 150 181 368 155 181 minecraft:calcite
fill 368 150 222 370 150 222 minecraft:polished_basalt
setblock 369 150 223 minecraft:bone_block
fill 370 150 181 370 151 181 minecraft:bone_block
fill 370 150 182 370 150 184 minecraft:polished_basalt
fill 370 150 186 370 150 188 minecraft:polished_basalt
fill 370 150 190 370 150 192 minecraft:polished_basalt
fill 370 150 194 370 150 196 minecraft:polished_basalt
fill 370 150 198 370 150 200 minecraft:polished_basalt
fill 370 150 202 370 150 204 minecraft:polished_basalt
fill 370 150 206 370 150 208 minecraft:polished_basalt
fill 370 150 210 370 150 212 minecraft:polished_basalt
fill 370 150 214 370 150 216 minecraft:polished_basalt
fill 370 150 218 370 150 220 minecraft:polished_basalt
fill 371 150 186 371 155 187 minecraft:calcite
fill 371 150 188 371 151 189 minecraft:bone_block
setblock 371 150 197 minecraft:bone_block
fill 371 150 198 371 155 199 minecraft:calcite
fill 371 150 200 371 151 201 minecraft:bone_block
fill 371 150 206 371 155 207 minecraft:calcite
fill 371 150 208 371 150 209 minecraft:bone_block
fill 371 150 210 371 155 210 minecraft:calcite
fill 371 150 218 371 155 219 minecraft:calcite
fill 371 150 220 371 151 221 minecraft:bone_block
fill 371 150 223 371 155 223 minecraft:calcite
fill 329 151 195 329 151 196 minecraft:bone_block
setblock 329 151 199 minecraft:bone_block
fill 329 151 200 329 154 200 minecraft:calcite
fill 329 151 211 329 154 211 minecraft:calcite
setblock 329 151 216 minecraft:bone_block
setblock 333 151 223 minecraft:bone_block
fill 335 151 181 335 154 181 minecraft:calcite
fill 337 151 223 338 154 223 minecraft:calcite
setblock 339 151 181 minecraft:bone_block
fill 346 151 181 346 154 181 minecraft:calcite
setblock 347 151 181 minecraft:bone_block
setblock 350 151 181 minecraft:bone_block
setblock 354 151 223 minecraft:bone_block
setblock 357 151 223 minecraft:bone_block
fill 358 151 223 358 154 223 minecraft:calcite
setblock 365 151 223 minecraft:bone_block
fill 366 151 181 367 154 181 minecraft:calcite
fill 369 151 223 369 154 223 minecraft:calcite
setblock 371 151 181 minecraft:bone_block
setblock 371 151 192 minecraft:bone_block
fill 371 151 197 371 154 197 minecraft:calcite
fill 371 151 208 371 154 208 minecraft:calcite
setblock 371 151 209 minecraft:bone_block
fill 371 151 212 371 151 213 minecraft:bone_block
fill 329 152 185 329 153 186 minecraft:bone_block
fill 329 152 187 329 157 188 minecraft:calcite
fill 329 152 194 329 153 194 minecraft:bone_block
fill 329 152 195 329 153 196 minecraft:calcite
fill 329 152 197 329 152 198 minecraft:bone_block
fill 329 152 199 329 157 199 minecraft:calcite
fill 329 152 205 329 153 206 minecraft:bone_block
fill 329 152 207 329 157 208 minecraft:calcite
fill 329 152 216 329 157 216 minecraft:calcite
fill 329 152 217 329 152 218 minecraft:bone_block
fill 329 152 219 329 157 220 minecraft:calcite
fill 331 152 223 332 153 223 minecraft:bone_block
fill 333 152 223 334 157 223 minecraft:calcite
setblock 335 152 223 minecraft:bone_block
fill 338 152 181 339 157 181 minecraft:calcite
fill 340 152 181 341 153 181 minecraft:bone_block
fill 343 152 223 344 153 223 minecraft:bone_block
fill 345 152 223 346 157 223 minecraft:calcite
fill 347 152 181 347 157 181 minecraft:calcite
fill 348 152 181 349 152 181 minecraft:bone_block
fill 350 152 181 350 157 181 minecraft:calcite
fill 352 152 181 352 153 181 minecraft:bone_block
fill 352 152 223 352 153 223 minecraft:bone_block
fill 354 152 223 354 157 223 minecraft:calcite
fill 355 152 223 356 152 223 minecraft:bone_block
fill 357 152 223 357 157 223 minecraft:calcite
fill 358 152 181 359 157 181 minecraft:calcite
fill 360 152 181 361 153 181 minecraft:bone_block
fill 363 152 223 364 153 223 minecraft:bone_block
fill 365 152 223 366 157 223 minecraft:calcite
setblock 369 152 181 minecraft:bone_block
fill 370 152 181 371 157 181 minecraft:calcite
fill 371 152 182 371 153 183 minecraft:bone_block
fill 371 152 188 371 157 189 minecraft:calcite
fill 371 152 190 371 152 191 minecraft:bone_block
fill 371 152 192 371 157 192 minecraft:calcite
fill 371 152 200 371 157 201 minecraft:calcite
fill 371 152 202 371 153 203 minecraft:bone_block
fill 371 152 209 371 157 209 minecraft:calcite
setblock 371 152 211 minecraft:bone_block
fill 371 152 212 371 157 213 minecraft:calcite
fill 371 152 214 371 153 214 minecraft:bone_block
fill 371 152 220 371 157 221 minecraft:calcite
setblock 371 152 222 minecraft:bone_block
setblock 329 153 182 minecraft:bone_block
setblock 329 153 193 minecraft:bone_block
fill 329 153 197 329 155 198 minecraft:calcite
fill 329 153 213 329 153 214 minecraft:bone_block
setblock 329 153 217 minecraft:bone_block
fill 329 153 218 329 156 218 minecraft:calcite
setblock 332 153 181 minecraft:bone_block
setblock 332 153 184 minecraft:light[level=12]
setblock 332 153 192 minecraft:light[level=12]
setblock 332 153 200 minecraft:light[level=12]
setblock 332 153 208 minecraft:light[level=12]
setblock 332 153 216 minecraft:light[level=12]
fill 335 153 223 335 156 223 minecraft:calcite
setblock 340 153 184 minecraft:light[level=12]
setblock 340 153 192 minecraft:light[level=12]
setblock 340 153 200 minecraft:light[level=12]
setblock 340 153 208 minecraft:light[level=12]
setblock 340 153 216 minecraft:light[level=12]
setblock 340 153 223 minecraft:bone_block
fill 348 153 181 349 156 181 minecraft:calcite
setblock 348 153 184 minecraft:light[level=12]
setblock 348 153 192 minecraft:light[level=12]
setblock 348 153 200 minecraft:light[level=12]
setblock 348 153 208 minecraft:light[level=12]
setblock 348 153 216 minecraft:light[level=12]
setblock 351 153 223 minecraft:bone_block
setblock 353 153 181 minecraft:bone_block
fill 355 153 223 356 156 223 minecraft:calcite
setblock 356 153 184 minecraft:light[level=12]
setblock 356 153 192 minecraft:light[level=12]
setblock 356 153 200 minecraft:light[level=12]
setblock 356 153 208 minecraft:light[level=12]
setblock 356 153 216 minecraft:light[level=12]
setblock 364 153 181 minecraft:bone_block
setblock 364 153 184 minecraft:light[level=12]
setblock 364 153 192 minecraft:light[level=12]
setblock 364 153 200 minecraft:light[level=12]
setblock 364 153 208 minecraft:light[level=12]
setblock 364 153 216 minecraft:light[level=12]
fill 369 153 181 369 156 181 minecraft:calcite
fill 371 153 190 371 156 190 minecraft:calcite
setblock 371 153 191 minecraft:bone_block
fill 371 153 194 371 153 195 minecraft:bone_block
fill 371 153 211 371 156 211 minecraft:calcite
setblock 371 153 215 minecraft:bone_block
fill 371 153 222 371 156 222 minecraft:calcite
fill 329 154 182 329 159 182 minecraft:calcite
fill 329 154 183 329 154 184 minecraft:bone_block
fill 329 154 185 329 156 186 minecraft:calcite
fill 329 154 191 329 155 192 minecraft:bone_block
fill 329 154 193 329 159 194 minecraft:calcite
setblock 329 154 195 minecraft:bone_block
fill 329 154 196 329 157 196 minecraft:calcite
fill 329 154 203 329 154 204 minecraft:bone_block
fill 329 154 205 329 159 206 minecraft:calcite
fill 329 154 212 329 155 212 minecraft:bone_block
fill 329 154 213 329 159 214 minecraft:calcite
setblock 329 154 215 minecraft:bone_block
fill 329 154 217 329 159 217 minecraft:calcite
fill 329 154 223 330 155 223 minecraft:bone_block
fill 330 154 181 331 154 181 minecraft:bone_block
fill 331 154 223 332 159 223 minecraft:calcite
fill 332 154 181 332 159 181 minecraft:calcite
fill 334 154 181 334 155 181 minecraft:bone_block
fill 340 154 181 341 159 181 minecraft:calcite
fill 340 154 223 340 159 223 minecraft:calcite
fill 341 154 223 342 154 223 minecraft:bone_block
fill 342 154 181 343 155 181 minecraft:bone_block
fill 343 154 223 344 159 223 minecraft:calcite
fill 349 154 223 350 155 223 minecraft:bone_block
setblock 351 154 181 minecraft:bone_block
fill 351 154 223 352 159 223 minecraft:calcite
fill 352 154 181 353 159 181 minecraft:calcite
setblock 353 154 223 minecraft:bone_block
fill 354 154 181 355 155 181 minecraft:bone_block
fill 360 154 181 361 159 181 minecraft:calcite
fill 361 154 223 362 155 223 minecraft:bone_block
fill 362 154 181 363 154 181 minecraft:bone_block
fill 363 154 223 364 159 223 minecraft:calcite
fill 364 154 181 364 159 181 minecraft:calcite
fill 370 154 223 370 155 223 minecraft:bone_block
fill 371 154 182 371 159 183 minecraft:calcite
fill 371 154 184 371 155 185 minecraft:bone_block
fill 371 154 191 371 159 191 minecraft:calcite
setblock 371 154 193 minecraft:bone_block
fill 371 154 194 371 159 195 minecraft:calcite
fill 371 154 196 371 155 196 minecraft:bone_block
fill 371 154 202 371 159 203 minecraft:calcite
fill 371 154 204 371 154 205 minecraft:bone_block
fill 371 154 214 371 159 215 minecraft:calcite
fill 371 154 216 371 155 217 minecraft:bone_block
setblock 329 155 183 minecraft:bone_block
fill 329 155 184 329 158 184 minecraft:calcite
fill 329 155 195 329 157 195 minecraft:calcite
setblock 329 155 200 minecraft:bone_block
setblock 329 155 203 minecraft:bone_block
fill 329 155 204 329 158 204 minecraft:calcite
setblock 329 155 211 minecraft:bone_block
fill 329 155 215 329 158 215 minecraft:calcite
fill 330 155 181 331 157 181 minecraft:calcite
setblock 335 155 181 minecraft:bone_block
fill 337 155 223 338 155 223 minecraft:bone_block
setblock 341 155 223 minecraft:bone_block
fill 342 155 223 342 158 223 minecraft:calcite
setblock 346 155 181 minecraft:bone_block
fill 351 155 181 351 158 181 minecraft:calcite
fill 353 155 223 353 158 223 minecraft:calcite
setblock 358 155 223 minecraft:bone_block
fill 362 155 181 362 158 181 minecraft:calcite
setblock 363 155 181 minecraft:bone_block
fill 366 155 181 367 155 181 minecraft:bone_block
setblock 369 155 223 minecraft:bone_block
fill 371 155 193 371 158 193 minecraft:calcite
setblock 371 155 197 minecraft:bone_block
fill 371 155 204 371 158 204 minecraft:calcite
setblock 371 155 205 minecraft:bone_block
setblock 371 155 208 minecraft:bone_block
setblock 329 156 181 minecraft:bone_block
fill 329 156 183 329 158 183 minecraft:calcite
fill 329 156 189 329 157 190 minecraft:bone_block
fill 329 156 191 329 161 192 minecraft:calcite
setblock 329 156 197 minecraft:calcite
fill 329 156 198 329 157 198 minecraft:bone_block
fill 329 156 200 329 161 200 minecraft:calcite
fill 329 156 201 329 156 202 minecraft:bone_block
fill 329 156 203 329 161 203 minecraft:calcite
fill 329 156 209 329 157 210 minecraft:bone_block
fill 329 156 211 329 161 212 minecraft:calcite
fill 329 156 221 329 156 222 minecraft:bone_block
fill 329 156 223 330 161 223 minecraft:calcite
fill 330 156 182 332 156 182 minecraft:polished_basalt
fill 330 156 184 330 156 186 minecraft:polished_basalt
fill 330 156 188 330 156 190 minecraft:polished_basalt
fill 330 156 192 330 156 194 minecraft:polished_basalt
fill 330 156 196 330 156 198 minecraft:polished_basalt
fill 330 156 200 330 156 202 minecraft:polished_basalt
fill 330 156 204 330 156 206 minecraft:polished_basalt
fill 330 156 208 330 156 210 minecraft:polished_basalt
fill 330 156 212 330 156 214 minecraft:polished_basalt
fill 330 156 216 330 156 218 minecraft:polished_basalt
fill 330 156 220 330 156 222 minecraft:polished_basalt
fill 332 156 222 334 156 222 minecraft:polished_basalt
setblock 333 156 181 minecraft:bone_block
fill 334 156 181 335 161 181 minecraft:calcite
fill 334 156 182 336 156 182 minecraft:polished_basalt
fill 336 156 181 337 157 181 minecraft:bone_block
fill 336 156 222 338 156 222 minecraft:polished_basalt
fill 336 156 223 336 157 223 minecraft:bone_block
fill 337 156 223 338 161 223 minecraft:calcite
fill 338 156 182 340 156 182 minecraft:polished_basalt
setblock 339 156 223 minecraft:bone_block
fill 340 156 222 342 156 222 minecraft:polished_basalt
fill 341 156 223 341 161 223 minecraft:calcite
fill 342 156 181 343 161 181 minecraft:calcite
fill 342 156 182 344 156 182 minecraft:polished_basalt
fill 344 156 181 345 156 181 minecraft:bone_block
fill 344 156 222 346 156 222 minecraft:polished_basalt
fill 346 156 181 346 161 181 minecraft:calcite
fill 346 156 182 348 156 182 minecraft:polished_basalt
fill 347 156 223 348 157 223 minecraft:bone_block
fill 348 156 222 350 156 222 minecraft:polished_basalt
fill 349 156 223 350 161 223 minecraft:calcite
fill 350 156 182 352 156 182 minecraft:polished_basalt
fill 352 156 222 354 156 222 minecraft:polished_basalt
fill 354 156 181 355 161 181 minecraft:calcite
fill 354 156 182 356 156 182 minecraft:polished_basalt
fill 356 156 181 357 157 181 minecraft:bone_block
fill 356 156 222 358 156 222 minecraft:polished_basalt
fill 358 156 182 360 156 182 minecraft:polished_basalt
fill 358 156 223 358 161 223 minecraft:calcite
fill 359 156 223 360 156 223 minecraft:bone_block
fill 360 156 222 362 156 222 minecraft:polished_basalt
fill 361 156 223 362 161 223 minecraft:calcite
fill 362 156 182 364 156 182 minecraft:polished_basalt
fill 363 156 181 363 161 181 minecraft:calcite
fill 364 156 222 366 156 222 minecraft:polished_basalt
setblock 365 156 181 minecraft:bone_block
fill 366 156 181 367 161 181 minecraft:calcite
fill 366 156 182 368 156 182 minecraft:polished_basalt
fill 367 156 223 368 157 223 minecraft:bone_block
fill 368 156 181 368 157 181 minecraft:bone_block
fill 368 156 222 370 156 222 minecraft:polished_basalt
fill 369 156 223 370 161 223 minecraft:calcite
fill 370 156 182 370 156 184 minecraft:polished_basalt
fill 370 156 186 370 156 188 minecraft:polished_basalt
fill 370 156 190 370 156 192 minecraft:polished_basalt
fill 370 156 194 370 156 196 minecraft:polished_basalt
fill 370 156 198 370 156 200 minecraft:polished_basalt
fill 370 156 202 370 156 204 minecraft:polished_basalt
fill 370 156 206 370 156 208 minecraft:polished_basalt
fill 370 156 210 370 156 212 minecraft:polished_basalt
fill 370 156 214 370 156 216 minecraft:polished_basalt
fill 370 156 218 370 156 220 minecraft:polished_basalt
fill 371 156 184 371 161 185 minecraft:calcite
fill 371 156 186 371 156 187 minecraft:bone_block
fill 371 156 196 371 161 197 minecraft:calcite
fill 371 156 198 371 157 199 minecraft:bone_block
fill 371 156 205 371 161 205 minecraft:calcite
fill 371 156 206 371 156 207 minecraft:bone_block
fill 371 156 208 371 161 208 minecraft:calcite
fill 371 156 210 371 157 210 minecraft:bone_block
fill 371 156 216 371 161 217 minecraft:calcite
fill 371 156 218 371 157 219 minecraft:bone_block
setblock 371 156 223 minecraft:bone_block
fill 329 157 181 329 160 181 minecraft:calcite
fill 329 157 185 329 159 185 minecraft:calcite
setblock 329 157 186 minecraft:bone_block
setblock 329 157 197 minecraft:bone_block
fill 329 157 201 329 160 202 minecraft:calcite
setblock 329 157 218 minecraft:bone_block
setblock 329 157 221 minecraft:bone_block
fill 329 157 222 329 160 222 minecraft:calcite
fill 333 157 181 333 159 181 minecraft:calcite
setblock 335 157 223 minecraft:bone_block
fill 339 157 223 339 160 223 minecraft:calcite
fill 344 157 181 344 160 181 minecraft:calcite
setblock 345 157 181 minecraft:bone_block
fill 348 157 181 349 157 181 minecraft:bone_block
fill 355 157 223 356 157 223 minecraft:bone_block
setblock 359 157 223 minecraft:bone_block
fill 360 157 223 360 160 223 minecraft:calcite
fill 365 157 181 365 160 181 minecraft:calcite
setblock 369 157 181 minecraft:bone_block
fill 371 157 186 371 160 186 minecraft:calcite
setblock 371 157 187 minecraft:bone_block
setblock 371 157 190 minecraft:bone_block
fill 371 157 206 371 160 207 minecraft:calcite
setblock 371 157 211 minecraft:bone_block
setblock 371 157 222 minecraft:bone_block
fill 371 157 223 371 160 223 minecraft:calcite
fill 329 158 186 329 159 186 minecraft:calcite
fill 329 158 187 329 158 188 minecraft:bone_block
fill 329 158 189 329 163 190 minecraft:calcite
fill 329 158 195 329 159 196 minecraft:bone_block
fill 329 158 197 329 163 198 minecraft:calcite
setblock 329 158 199 minecraft:bone_block
fill 329 158 207 329 159 208 minecraft:bone_block
fill 329 158 209 329 163 210 minecraft:calcite
fill 329 158 216 329 159 216 minecraft:bone_block
fill 329 158 218 329 163 218 minecraft:calcite
fill 329 158 219 329 158 220 minecraft:bone_block
fill 329 158 221 329 163 221 minecraft:calcite
fill 330 158 181 330 159 181 minecraft:bone_block
setblock 331 158 181 minecraft:calcite
fill 333 158 223 334 159 223 minecraft:bone_block
fill 335 158 223 336 163 223 minecraft:calcite
fill 336 158 181 337 163 181 minecraft:calcite
fill 338 158 181 339 159 181 minecraft:bone_block
fill 345 158 181 345 163 181 minecraft:calcite
fill 345 158 223 346 158 223 minecraft:bone_block
setblock 347 158 181 minecraft:bone_block
fill 347 158 223 348 163 223 minecraft:calcite
fill 348 158 181 349 163 181 minecraft:calcite
fill 350 158 181 350 159 181 minecraft:bone_block
fill 354 158 223 354 159 223 minecraft:bone_block
fill 355 158 223 356 163 223 minecraft:calcite
fill 356 158 181 357 163 181 minecraft:calcite
setblock 357 158 223 minecraft:bone_block
fill 358 158 181 359 158 181 minecraft:bone_block
fill 359 158 223 359 163 223 minecraft:calcite
fill 365 158 223 366 159 223 minecraft:bone_block
fill 367 158 223 368 163 223 minecraft:calcite
fill 368 158 181 369 163 181 minecraft:calcite
fill 370 158 181 371 159 181 minecraft:bone_block
fill 371 158 187 371 163 187 minecraft:calcite
fill 371 158 188 371 158 189 minecraft:bone_block
fill 371 158 190 371 163 190 minecraft:calcite
fill 371 158 192 371 159 192 minecraft:bone_block
fill 371 158 198 371 163 199 minecraft:calcite
fill 371 158 200 371 159 201 minecraft:bone_block
setblock 371 158 209 minecraft:bone_block
fill 371 158 210 371 163 211 minecraft:calcite
fill 371 158 212 371 159 213 minecraft:bone_block
fill 371 158 218 371 163 219 minecraft:calcite
fill 371 158 220 371 158 221 minecraft:bone_block
fill 371 158 222 371 163 222 minecraft:calcite
fill 329 159 183 329 159 184 minecraft:bone_block
setblock 329 159 187 minecraft:bone_block
fill 329 159 188 329 162 188 minecraft:calcite
fill 329 159 199 329 162 199 minecraft:calcite
setblock 329 159 204 minecraft:bone_block
setblock 329 159 215 minecraft:bone_block
fill 329 159 219 329 162 220 minecraft:calcite
setblock 331 159 181 minecraft:bone_block
setblock 342 159 223 minecraft:bone_block
setblock 345 159 223 minecraft:bone_block
fill 346 159 223 346 162 223 minecraft:calcite
fill 347 159 181 347 162 181 minecraft:calcite
setblock 351 159 181 minecraft:bone_block
setblock 353 159 223 minecraft:bone_block
fill 357 159 223 357 162 223 minecraft:calcite
fill 358 159 181 358 162 181 minecraft:calcite
setblock 359 159 181 minecraft:bone_block
setblock 362 159 181 minecraft:bone_block
fill 371 159 188 371 162 189 minecraft:calcite
setblock 371 159 193 minecraft:bone_block
setblock 371 159 204 minecraft:bone_block
fill 371 159 209 371 162 209 minecraft:calcite
fill 371 159 220 371 162 220 minecraft:calcite
setblock 371 159 221 minecraft:bone_block
fill 329 160 182 329 161 182 minecraft:bone_block
fill 329 160 183 329 161 184 minecraft:calcite
fill 329 160 185 329 160 186 minecraft:bone_block
fill 329 160 187 329 177 187 minecraft:calcite
fill 329 160 193 329 161 194 minecraft:bone_block
fill 329 160 195 329 178 196 minecraft:calcite
fill 329 160 204 329 174 204 minecraft:calcite
fill 329 160 205 329 160 206 minecraft:bone_block
fill 329 160 207 329 177 208 minecraft:calcite
fill 329 160 213 329 161 214 minecraft:bone_block
fill 329 160 215 329 174 216 minecraft:calcite
setblock 329 160 217 minecraft:bone_block
fill 330 160 181 331 174 181 minecraft:calcite
fill 331 160 223 332 161 223 minecraft:bone_block
fill 332 160 181 333 161 181 minecraft:bone_block
fill 333 160 223 334 177 223 minecraft:calcite
fill 338 160 181 339 177 181 minecraft:calcite
fill 340 160 181 341 160 181 minecraft:bone_block
fill 340 160 223 340 161 223 minecraft:bone_block
fill 342 160 223 342 174 223 minecraft:calcite
fill 343 160 223 344 160 223 minecraft:bone_block
fill 345 160 223 345 177 223 minecraft:calcite
fill 350 160 181 351 174 181 minecraft:calcite
fill 351 160 223 352 161 223 minecraft:bone_block
fill 352 160 181 353 161 181 minecraft:bone_block
fill 353 160 223 354 174 223 minecraft:calcite
fill 359 160 181 359 177 181 minecraft:calcite
fill 360 160 181 361 160 181 minecraft:bone_block
fill 362 160 181 362 174 181 minecraft:calcite
fill 363 160 223 364 160 223 minecraft:bone_block
fill 364 160 181 364 161 181 minecraft:bone_block
fill 365 160 223 366 177 223 minecraft:calcite
fill 370 160 181 371 177 181 minecraft:calcite
fill 371 160 182 371 161 183 minecraft:bone_block
setblock 371 160 191 minecraft:bone_block
fill 371 160 192 371 174 193 minecraft:calcite
fill 371 160 194 371 161 195 minecraft:bone_block
fill 371 160 200 371 177 201 minecraft:calcite
fill 371 160 202 371 160 203 minecraft:bone_block
fill 371 160 204 371 174 204 minecraft:calcite
fill 371 160 212 371 178 213 minecraft:calcite
fill 371 160 214 371 161 215 minecraft:bone_block
fill 371 160 221 371 177 221 minecraft:calcite
setblock 329 161 181 minecraft:bone_block
fill 329 161 185 329 163 186 minecraft:calcite
fill 329 161 201 329 161 202 minecraft:bone_block
setblock 329 161 205 minecraft:bone_block
fill 329 161 206 329 179 206 minecraft:calcite
fill 329 161 217 329 179 217 minecraft:calcite
setblock 329 161 222 minecraft:bone_block
setblock 332 161 184 minecraft:light[level=12]
setblock 332 161 192 minecraft:light[level=12]
setblock 332 161 200 minecraft:light[level=12]
setblock 332 161 208 minecraft:light[level=12]
setblock 332 161 216 minecraft:light[level=12]
setblock 339 161 223 minecraft:bone_block
fill 340 161 181 340 179 181 minecraft:calcite
setblock 340 161 184 minecraft:light[level=12]
setblock 340 161 192 minecraft:light[level=12]
setblock 340 161 200 minecraft:light[level=12]
setblock 340 161 208 minecraft:light[level=12]
setblock 340 161 216 minecraft:light[level=12]
setblock 341 161 181 minecraft:bone_block
fill 343 161 223 344 179 223 minecraft:calcite
setblock 344 161 181 minecraft:bone_block
setblock 348 161 184 minecraft:light[level=12]
setblock 348 161 192 minecraft:light[level=12]
setblock 348 161 200 minecraft:light[level=12]
setblock 348 161 208 minecraft:light[level=12]
setblock 348 161 216 minecraft:light[level=12]
setblock 356 161 184 minecraft:light[level=12]
setblock 356 161 192 minecraft:light[level=12]
setblock 356 161 200 minecraft:light[level=12]
setblock 356 161 208 minecraft:light[level=12]
setblock 356 161 216 minecraft:light[level=12]
fill 360 161 181 361 179 181 minecraft:calcite
setblock 360 161 223 minecraft:bone_block
setblock 363 161 223 minecraft:bone_block
setblock 364 161 184 minecraft:light[level=12]
setblock 364 161 192 minecraft:light[level=12]
setblock 364 161 200 minecraft:light[level=12]
setblock 364 161 208 minecraft:light[level=12]
setblock 364 161 216 minecraft:light[level=12]
fill 364 161 223 364 179 223 minecraft:calcite
setblock 365 161 181 minecraft:bone_block
setblock 371 161 186 minecraft:bone_block
fill 371 161 191 371 179 191 minecraft:calcite
fill 371 161 202 371 179 202 minecraft:calcite
setblock 371 161 203 minecraft:bone_block
fill 371 161 206 371 161 207 minecraft:bone_block
setblock 371 161 223 minecraft:bone_block
fill 329 162 181 329 175 182 minecraft:calcite
setblock 329 162 183 minecraft:bone_block
fill 329 162 184 329 174 184 minecraft:calcite
fill 329 162 191 329 162 192 minecraft:bone_block
fill 329 162 193 329 175 194 minecraft:calcite
fill 329 162 200 329 163 200 minecraft:bone_block
fill 329 162 201 329 175 202 minecraft:calcite
setblock 329 162 203 minecraft:bone_block
fill 329 162 205 329 179 205 minecraft:calcite
fill 329 162 211 329 163 212 minecraft:bone_block
fill 329 162 213 329 175 214 minecraft:calcite
fill 329 162 222 329 175 222 minecraft:calcite
fill 329 162 223 330 162 223 minecraft:bone_block
fill 330 162 182 332 162 182 minecraft:polished_basalt
fill 330 162 184 330 162 186 minecraft:polished_basalt
fill 330 162 188 330 162 190 minecraft:polished_basalt
fill 330 162 192 330 162 194 minecraft:polished_basalt
fill 330 162 196 330 162 198 minecraft:polished_basalt
fill 330 162 200 330 162 202 minecraft:polished_basalt
fill 330 162 204 330 162 206 minecraft:polished_basalt
fill 330 162 208 330 162 210 minecraft:polished_basalt
fill 330 162 212 330 162 214 minecraft:polished_basalt
fill 330 162 216 330 162 218 minecraft:polished_basalt
fill 330 162 220 330 162 222 minecraft:polished_basalt
fill 331 162 223 332 179 223 minecraft:calcite
fill 332 162 181 333 175 181 minecraft:calcite
fill 332 162 222 334 162 222 minecraft:polished_basalt
fill 334 162 181 335 163 181 minecraft:bone_block
fill 334 162 182 336 162 182 minecraft:polished_basalt
fill 336 162 222 338 162 222 minecraft:polished_basalt
fill 337 162 223 338 163 223 minecraft:bone_block
fill 338 162 182 340 162 182 minecraft:polished_basalt
fill 339 162 223 340 175 223 minecraft:calcite
fill 340 162 222 342 162 222 minecraft:polished_basalt
fill 341 162 181 341 179 181 minecraft:calcite
setblock 341 162 223 minecraft:bone_block
fill 342 162 181 343 162 181 minecraft:bone_block
fill 342 162 182 344 162 182 minecraft:polished_basalt
fill 344 162 181 344 175 181 minecraft:calcite
fill 344 162 222 346 162 222 minecraft:polished_basalt
fill 346 162 181 346 163 181 minecraft:bone_block
fill 346 162 182 348 162 182 minecraft:polished_basalt
fill 348 162 222 350 162 222 minecraft:polished_basalt
fill 349 162 223 350 163 223 minecraft:bone_block
fill 350 162 182 352 162 182 minecraft:polished_basalt
fill 351 162 223 352 175 223 minecraft:calcite
fill 352 162 181 353 175 181 minecraft:calcite
fill 352 162 222 354 162 222 minecraft:polished_basalt
fill 354 162 181 355 163 181 minecraft:bone_block
fill 354 162 182 356 162 182 minecraft:polished_basalt
fill 356 162 222 358 162 222 minecraft:polished_basalt
fill 358 162 182 360 162 182 minecraft:polished_basalt
fill 358 162 223 358 163 223 minecraft:bone_block
fill 360 162 222 362 162 222 minecraft:polished_basalt
fill 360 162 223 360 175 223 minecraft:calcite
fill 361 162 223 362 162 223 minecraft:bone_block
fill 362 162 182 364 162 182 minecraft:polished_basalt
setblock 363 162 181 minecraft:bone_block
fill 363 162 223 363 179 223 minecraft:calcite
fill 364 162 181 365 175 181 minecraft:calcite
fill 364 162 222 366 162 222 minecraft:polished_basalt
fill 366 162 181 367 163 181 minecraft:bone_block
fill 366 162 182 368 162 182 minecraft:polished_basalt
fill 368 162 222 370 162 222 minecraft:polished_basalt
fill 369 162 223 370 163 223 minecraft:bone_block
fill 370 162 182 370 162 184 minecraft:polished_basalt
fill 370 162 186 370 162 188 minecraft:polished_basalt
fill 370 162 190 370 162 192 minecraft:polished_basalt
fill 370 162 194 370 162 196 minecraft:polished_basalt
fill 370 162 198 370 162 200 minecraft:polished_basalt
fill 370 162 202 370 162 204 minecraft:polished_basalt
fill 370 162 206 370 162 208 minecraft:polished_basalt
fill 370 162 210 370 162 212 minecraft:polished_basalt
fill 370 162 214 370 162 216 minecraft:polished_basalt
fill 370 162 218 370 162 220 minecraft:polished_basalt
fill 371 162 182 371 179 183 minecraft:calcite
fill 371 162 184 371 162 185 minecraft:bone_block
fill 371 162 186 371 175 186 minecraft:calcite
fill 371 162 194 371 175 195 minecraft:calcite
fill 371 162 196 371 163 197 minecraft:bone_block
fill 371 162 203 371 179 203 minecraft:calcite
setblock 371 162 205 minecraft:bone_block
fill 371 162 206 371 175 207 minecraft:calcite
fill 371 162 208 371 163 208 minecraft:bone_block
fill 371 162 214 371 175 215 minecraft:calcite
fill 371 162 216 371 162 217 minecraft:bone_block
fill 371 162 223 371 175 223 minecraft:calcite
fill 329 163 183 329 174 183 minecraft:calcite
setblock 329 163 188 minecraft:bone_block
setblock 329 163 191 minecraft:bone_block
fill 329 163 192 329 174 192 minecraft:calcite
setblock 329 163 199 minecraft:bone_block
fill 329 163 203 329 174 203 minecraft:calcite
fill 329 163 219 329 163 220 minecraft:bone_block
setblock 329 163 223 minecraft:bone_block
fill 330 163 223 330 174 223 minecraft:calcite
fill 341 163 223 341 174 223 minecraft:calcite
fill 342 163 181 343 174 181 minecraft:calcite
setblock 346 163 223 minecraft:bone_block
setblock 347 163 181 minecraft:bone_block
setblock 357 163 223 minecraft:bone_block
setblock 358 163 181 minecraft:bone_block
fill 361 163 223 362 174 223 minecraft:calcite
fill 363 163 181 363 174 181 minecraft:calcite
fill 371 163 184 371 174 184 minecraft:calcite
setblock 371 163 185 minecraft:bone_block
fill 371 163 188 371 163 189 minecraft:bone_block
fill 371 163 205 371 174 205 minecraft:calcite
setblock 371 163 209 minecraft:bone_block
fill 371 163 216 371 174 216 minecraft:calcite
setblock 371 163 217 minecraft:bone_block
setblock 371 163 220 minecraft:bone_block
fill 329 164 185 329 179 185 minecraft:calcite
setblock 329 164 186 minecraft:bone_block
fill 329 164 188 329 177 188 minecraft:calcite
fill 329 164 189 329 164 190 minecraft:bone_block
fill 329 164 191 329 174 191 minecraft:calcite
fill 329 164 197 329 164 198 minecraft:bone_block
fill 329 164 199 329 177 200 minecraft:calcite
fill 329 164 209 329 164 210 minecraft:bone_block
fill 329 164 211 329 174 212 minecraft:calcite
setblock 329 164 218 minecraft:bone_block
fill 329 164 219 329 177 220 minecraft:calcite
setblock 329 164 221 minecraft:bone_block
fill 329 164 223 329 174 223 minecraft:calcite
fill 334 164 181 335 174 181 minecraft:calcite
fill 335 164 223 336 164 223 minecraft:bone_block
fill 336 164 181 337 164 181 minecraft:bone_block
fill 337 164 223 338 177 223 minecraft:calcite
setblock 345 164 181 minecraft:bone_block
fill 346 164 181 347 177 181 minecraft:calcite
fill 346 164 223 346 177 223 minecraft:calcite
fill 347 164 223 348 164 223 minecraft:bone_block
fill 348 164 181 349 164 181 minecraft:bone_block
fill 349 164 223 350 174 223 minecraft:calcite
fill 354 164 181 355 174 181 minecraft:calcite
fill 355 164 223 356 164 223 minecraft:bone_block
fill 356 164 181 357 164 181 minecraft:bone_block
fill 357 164 223 358 177 223 minecraft:calcite
fill 358 164 181 358 177 181 minecraft:calcite
setblock 359 164 223 minecraft:bone_block
fill 366 164 181 367 177 181 minecraft:calcite
fill 367 164 223 368 164 223 minecraft:bone_block
fill 368 164 181 369 164 181 minecraft:bone_block
fill 369 164 223 370 174 223 minecraft:calcite
fill 371 164 185 371 174 185 minecraft:calcite
setblock 371 164 187 minecraft:bone_block
fill 371 164 188 371 177 189 minecraft:calcite
setblock 371 164 190 minecraft:bone_block
fill 371 164 196 371 174 197 minecraft:calcite
fill 371 164 198 371 164 199 minecraft:bone_block
fill 371 164 208 371 177 209 minecraft:calcite
fill 371 164 210 371 164 211 minecraft:bone_block
fill 371 164 217 371 174 217 minecraft:calcite
fill 371 164 218 371 164 219 minecraft:bone_block
fill 371 164 220 371 177 220 minecraft:calcite
setblock 371 164 222 minecraft:bone_block
fill 329 165 186 329 179 186 minecraft:calcite
fill 329 165 189 329 175 190 minecraft:calcite
fill 329 165 197 329 176 198 minecraft:calcite
fill 329 165 209 329 175 210 minecraft:calcite
fill 329 165 218 329 179 218 minecraft:calcite
fill 329 165 221 329 175 221 minecraft:calcite
fill 335 165 223 336 176 223 minecraft:calcite
fill 336 165 181 337 175 181 minecraft:calcite
fill 345 165 181 345 175 181 minecraft:calcite
fill 347 165 223 348 175 223 minecraft:calcite
fill 348 165 181 349 176 181 minecraft:calcite
fill 355 165 223 356 179 223 minecraft:calcite
fill 356 165 181 357 175 181 minecraft:calcite
fill 359 165 223 359 175 223 minecraft:calcite
fill 367 165 223 368 176 223 minecraft:calcite
fill 368 165 181 369 176 181 minecraft:calcite
fill 371 165 187 371 175 187 minecraft:calcite
fill 371 165 190 371 179 190 minecraft:calcite
fill 371 165 198 371 175 199 minecraft:calcite
fill 371 165 210 371 176 211 minecraft:calcite
fill 371 165 218 371 175 219 minecraft:calcite
fill 371 165 222 371 179 222 minecraft:calcite
setblock 332 169 184 minecraft:light[level=12]
setblock 332 169 192 minecraft:light[level=12]
setblock 332 169 200 minecraft:light[level=12]
setblock 332 169 208 minecraft:light[level=12]
setblock 332 169 216 minecraft:light[level=12]
setblock 340 169 184 minecraft:light[level=12]
setblock 340 169 192 minecraft:light[level=12]
setblock 340 169 200 minecraft:light[level=12]
setblock 340 169 208 minecraft:light[level=12]
setblock 340 169 216 minecraft:light[level=12]
setblock 348 169 184 minecraft:light[level=12]
setblock 348 169 192 minecraft:light[level=12]
setblock 348 169 200 minecraft:light[level=12]
setblock 348 169 208 minecraft:light[level=12]
setblock 348 169 216 minecraft:light[level=12]
setblock 356 169 184 minecraft:light[level=12]
setblock 356 169 192 minecraft:light[level=12]
setblock 356 169 200 minecraft:light[level=12]
setblock 356 169 208 minecraft:light[level=12]
setblock 356 169 216 minecraft:light[level=12]
setblock 364 169 184 minecraft:light[level=12]
setblock 364 169 192 minecraft:light[level=12]
setblock 364 169 200 minecraft:light[level=12]
setblock 364 169 208 minecraft:light[level=12]
setblock 364 169 216 minecraft:light[level=12]
fill 336 170 203 337 171 203 minecraft:bone_block
fill 337 170 200 338 171 202 minecraft:bone_block
fill 337 170 204 338 171 206 minecraft:bone_block
fill 338 170 199 339 171 199 minecraft:bone_block
fill 338 170 203 344 171 203 minecraft:calcite
fill 338 170 207 339 171 207 minecraft:bone_block
fill 339 170 198 341 171 198 minecraft:bone_block
fill 339 170 200 339 171 200 minecraft:bone_block
fill 339 170 201 345 171 202 minecraft:calcite
fill 339 170 204 345 171 205 minecraft:calcite
fill 339 170 206 339 171 206 minecraft:bone_block
fill 339 170 208 341 171 208 minecraft:bone_block
fill 340 170 197 342 171 197 minecraft:bone_block
fill 340 170 199 345 171 200 minecraft:calcite
fill 340 170 206 345 171 207 minecraft:calcite
fill 340 170 209 342 171 209 minecraft:bone_block
fill 341 170 196 345 171 196 minecraft:bone_block
fill 341 170 210 345 171 210 minecraft:bone_block
fill 342 170 198 349 171 198 minecraft:calcite
fill 342 170 208 349 171 208 minecraft:calcite
fill 343 170 195 357 171 195 minecraft:bone_block
fill 343 170 197 357 171 197 minecraft:calcite
fill 343 170 209 357 171 209 minecraft:calcite
fill 343 170 211 357 171 211 minecraft:bone_block
fill 345 170 203 346 170 203 minecraft:black_concrete
fill 346 170 194 354 171 194 minecraft:bone_block
fill 346 170 196 354 171 196 minecraft:calcite
fill 346 170 199 346 171 199 minecraft:calcite
fill 346 170 200 348 170 200 minecraft:black_concrete
fill 346 170 201 346 171 201 minecraft:smooth_basalt
fill 346 170 202 347 170 202 minecraft:black_concrete
fill 346 170 204 347 170 204 minecraft:black_concrete
fill 346 170 205 346 171 205 minecraft:smooth_basalt
fill 346 170 206 348 170 206 minecraft:black_concrete
fill 346 170 207 346 171 207 minecraft:calcite
fill 346 170 210 354 171 210 minecraft:calcite
fill 346 170 212 354 171 212 minecraft:bone_block
fill 347 170 199 347 171 199 minecraft:smooth_basalt
setblock 347 170 201 minecraft:black_concrete
setblock 347 170 205 minecraft:black_concrete
fill 347 170 207 347 171 207 minecraft:smooth_basalt
fill 348 170 199 349 170 199 minecraft:black_concrete
fill 348 170 207 349 170 207 minecraft:black_concrete
setblock 349 170 200 minecraft:smooth_basalt
setblock 349 170 206 minecraft:smooth_basalt
fill 350 170 198 350 170 199 minecraft:smooth_basalt
fill 350 170 207 350 170 208 minecraft:smooth_basalt
fill 351 170 198 358 171 198 minecraft:calcite
fill 351 170 199 352 170 199 minecraft:black_concrete
setblock 351 170 200 minecraft:smooth_basalt
setblock 351 170 206 minecraft:smooth_basalt
fill 351 170 207 352 170 207 minecraft:black_concrete
fill 351 170 208 358 171 208 minecraft:calcite
fill 352 170 200 354 170 200 minecraft:black_concrete
fill 352 170 206 354 170 206 minecraft:black_concrete
fill 353 170 199 353 171 199 minecraft:smooth_basalt
fill 353 170 201 353 170 202 minecraft:black_concrete
fill 353 170 204 353 170 205 minecraft:black_concrete
fill 353 170 207 353 171 207 minecraft:smooth_basalt
fill 354 170 199 360 171 199 minecraft:calcite
fill 354 170 201 354 171 201 minecraft:smooth_basalt
fill 354 170 202 354 170 204 minecraft:black_concrete
fill 354 170 205 354 171 205 minecraft:smooth_basalt
fill 354 170 207 360 171 207 minecraft:calcite
fill 355 170 196 359 171 196 minecraft:bone_block
fill 355 170 200 360 171 202 minecraft:calcite
fill 355 170 203 355 171 203 minecraft:black_concrete
fill 355 170 204 360 171 206 minecraft:calcite
fill 355 170 210 359 171 210 minecraft:bone_block
fill 356 170 203 362 171 203 minecraft:calcite
fill 358 170 197 360 171 197 minecraft:bone_block
fill 358 170 209 360 171 209 minecraft:bone_block
fill 359 170 198 361 171 198 minecraft:bone_block
fill 359 170 208 361 171 208 minecraft:bone_block
fill 361 170 199 362 171 200 minecraft:bone_block
fill 361 170 201 361 171 202 minecraft:calcite
fill 361 170 204 361 171 205 minecraft:calcite
fill 361 170 206 362 171 207 minecraft:bone_block
fill 362 170 201 363 171 202 minecraft:bone_block
fill 362 170 204 363 171 205 minecraft:bone_block
fill 363 170 200 363 171 200 minecraft:bone_block
fill 363 170 203 364 171 203 minecraft:bone_block
fill 363 170 206 363 171 206 minecraft:bone_block
fill 330 171 182 335 171 222 minecraft:smooth_basalt
fill 336 171 182 336 171 202 minecraft:smooth_basalt
fill 336 171 204 336 171 222 minecraft:smooth_basalt
fill 337 171 182 337 171 199 minecraft:smooth_basalt
fill 337 171 207 337 171 222 minecraft:smooth_basalt
fill 338 171 182 338 171 198 minecraft:smooth_basalt
fill 338 171 208 338 171 222 minecraft:smooth_basalt
fill 339 171 182 339 171 197 minecraft:smooth_basalt
fill 339 171 209 339 171 222 minecraft:smooth_basalt
fill 340 171 182 340 171 196 minecraft:smooth_basalt
fill 340 171 210 340 171 222 minecraft:smooth_basalt
fill 341 171 182 342 171 195 minecraft:smooth_basalt
fill 341 171 211 342 171 222 minecraft:smooth_basalt
fill 343 171 182 345 171 194 minecraft:smooth_basalt
fill 343 171 212 345 171 222 minecraft:smooth_basalt
setblock 345 171 203 minecraft:black_concrete
fill 346 171 182 370 171 193 minecraft:smooth_basalt
setblock 346 171 200 minecraft:black_concrete
fill 346 171 202 346 171 204 minecraft:ochre_froglight
setblock 346 171 206 minecraft:black_concrete
fill 346 171 213 370 171 222 minecraft:smooth_basalt
fill 347 171 200 347 171 202 minecraft:ochre_froglight
fill 347 171 204 347 171 206 minecraft:ochre_froglight
setblock 348 171 199 minecraft:black_concrete
fill 348 171 200 349 171 200 minecraft:ochre_froglight
fill 348 171 206 349 171 206 minecraft:ochre_froglight
setblock 348 171 207 minecraft:black_concrete
fill 349 171 199 351 171 199 minecraft:ochre_froglight
fill 349 171 207 351 171 207 minecraft:ochre_froglight
setblock 350 171 198 minecraft:smooth_basalt
setblock 350 171 208 minecraft:smooth_basalt
fill 351 171 200 353 171 200 minecraft:ochre_froglight
fill 351 171 206 353 171 206 minecraft:ochre_froglight
setblock 352 171 199 minecraft:black_concrete
setblock 352 171 207 minecraft:black_concrete
fill 353 171 201 353 171 202 minecraft:ochre_froglight
fill 353 171 204 353 171 205 minecraft:ochre_froglight
setblock 354 171 200 minecraft:black_concrete
fill 354 171 202 354 171 204 minecraft:ochre_froglight
setblock 354 171 206 minecraft:black_concrete
fill 355 171 194 370 171 194 minecraft:smooth_basalt
fill 355 171 212 370 171 212 minecraft:smooth_basalt
fill 358 171 195 370 171 195 minecraft:smooth_basalt
fill 358 171 211 370 171 211 minecraft:smooth_basalt
fill 360 171 196 370 171 196 minecraft:smooth_basalt
fill 360 171 210 370 171 210 minecraft:smooth_basalt
fill 361 171 197 370 171 197 minecraft:smooth_basalt
fill 361 171 209 370 171 209 minecraft:smooth_basalt
fill 362 171 198 370 171 198 minecraft:smooth_basalt
fill 362 171 208 370 171 208 minecraft:smooth_basalt
schedule function dropper:buildpart/43_4 1t
