fill 183 263 470 183 307 470 minecraft:purpur_block
fill 141 264 471 141 269 471 minecraft:purpur_block
setblock 141 264 484 minecraft:magenta_stained_glass
fill 141 264 487 141 269 487 minecraft:purpur_block
fill 141 264 503 141 269 503 minecraft:purpur_block
fill 145 264 463 145 269 463 minecraft:purpur_block
fill 155 264 505 155 269 505 minecraft:purpur_block
fill 161 264 463 161 269 463 minecraft:purpur_block
fill 170 264 505 171 266 505 minecraft:purpur_block
fill 177 264 463 177 269 463 minecraft:purpur_block
fill 180 264 505 180 307 505 minecraft:purpur_block
setblock 181 264 505 minecraft:white_concrete
fill 183 264 473 183 269 473 minecraft:purpur_block
fill 183 264 489 183 269 489 minecraft:purpur_block
fill 141 265 484 141 294 484 minecraft:purpur_block
fill 181 265 505 181 297 505 minecraft:purpur_block
setblock 183 265 492 minecraft:magenta_stained_glass
setblock 162 266 505 minecraft:magenta_stained_glass
setblock 172 266 505 minecraft:white_concrete
setblock 183 266 483 minecraft:white_concrete
fill 183 266 484 183 307 484 minecraft:purpur_block
fill 183 266 492 183 307 492 minecraft:purpur_block
fill 141 267 464 141 270 466 minecraft:purpur_block
setblock 141 267 467 minecraft:white_concrete
setblock 142 267 505 minecraft:pearlescent_froglight
fill 162 267 505 162 307 505 minecraft:purpur_block
fill 170 267 505 170 307 505 minecraft:purpur_block
setblock 171 267 505 minecraft:pearlescent_froglight
setblock 172 267 505 minecraft:purpur_block
setblock 175 267 505 minecraft:pearlescent_froglight
setblock 183 267 465 minecraft:pearlescent_froglight
fill 183 267 483 183 283 483 minecraft:purpur_block
setblock 183 267 494 minecraft:pearlescent_froglight
fill 141 268 467 141 282 467 minecraft:purpur_block
fill 142 268 505 142 307 505 minecraft:purpur_block
setblock 164 268 463 minecraft:pearlescent_froglight
fill 171 268 505 171 269 505 minecraft:purpur_block
setblock 172 268 505 minecraft:white_concrete
fill 175 268 505 175 269 505 minecraft:purpur_block
fill 183 268 465 183 307 465 minecraft:purpur_block
fill 183 268 494 183 307 494 minecraft:purpur_block
setblock 141 269 480 minecraft:magenta_stained_glass
fill 164 269 463 164 275 463 minecraft:purpur_block
fill 172 269 505 172 279 505 minecraft:purpur_block
fill 141 270 471 141 272 471 minecraft:magenta_concrete
fill 141 270 480 141 307 480 minecraft:purpur_block
fill 141 270 487 141 272 487 minecraft:magenta_concrete
setblock 141 270 494 minecraft:magenta_stained_glass
setblock 141 270 496 minecraft:white_concrete
fill 141 270 503 141 272 503 minecraft:magenta_concrete
setblock 144 270 466 minecraft:light[level=14]
setblock 144 270 474 minecraft:light[level=14]
setblock 144 270 482 minecraft:light[level=14]
setblock 144 270 490 minecraft:light[level=14]
setblock 144 270 498 minecraft:light[level=14]
fill 145 270 463 145 272 463 minecraft:magenta_concrete
fill 149 270 472 150 271 473 minecraft:obsidian
setblock 150 270 463 minecraft:white_concrete
setblock 152 270 466 minecraft:light[level=14]
setblock 152 270 474 minecraft:light[level=14]
setblock 152 270 482 minecraft:light[level=14]
setblock 152 270 490 minecraft:light[level=14]
setblock 152 270 498 minecraft:light[level=14]
setblock 154 270 463 minecraft:pearlescent_froglight
fill 155 270 505 155 272 505 minecraft:magenta_concrete
setblock 160 270 466 minecraft:light[level=14]
setblock 160 270 474 minecraft:light[level=14]
setblock 160 270 482 minecraft:light[level=14]
setblock 160 270 490 minecraft:light[level=14]
setblock 160 270 498 minecraft:light[level=14]
fill 161 270 463 161 272 463 minecraft:magenta_concrete
setblock 168 270 466 minecraft:light[level=14]
setblock 168 270 474 minecraft:light[level=14]
setblock 168 270 482 minecraft:light[level=14]
setblock 168 270 490 minecraft:light[level=14]
setblock 168 270 498 minecraft:light[level=14]
fill 171 270 505 171 272 505 minecraft:magenta_concrete
setblock 175 270 505 minecraft:magenta_stained_glass
setblock 176 270 466 minecraft:light[level=14]
setblock 176 270 474 minecraft:light[level=14]
setblock 176 270 482 minecraft:light[level=14]
setblock 176 270 490 minecraft:light[level=14]
setblock 176 270 498 minecraft:light[level=14]
fill 177 270 463 177 272 463 minecraft:magenta_concrete
fill 183 270 473 183 272 473 minecraft:magenta_concrete
fill 183 270 489 183 272 489 minecraft:magenta_concrete
fill 141 271 464 141 281 465 minecraft:purpur_block
setblock 141 271 466 minecraft:white_concrete
setblock 141 271 474 minecraft:white_concrete
setblock 141 271 488 minecraft:pearlescent_froglight
fill 141 271 494 141 307 494 minecraft:purpur_block
fill 141 271 496 141 306 496 minecraft:purpur_block
fill 150 271 463 150 291 463 minecraft:purpur_block
fill 154 271 463 154 307 463 minecraft:purpur_block
setblock 173 271 505 minecraft:white_concrete
fill 175 271 505 175 307 505 minecraft:purpur_block
setblock 183 271 466 minecraft:magenta_stained_glass
setblock 183 271 471 minecraft:pearlescent_froglight
fill 183 271 472 183 307 472 minecraft:purpur_block
setblock 183 271 474 minecraft:pearlescent_froglight
fill 141 272 466 141 307 466 minecraft:purpur_block
fill 141 272 474 141 307 474 minecraft:purpur_block
fill 141 272 488 141 307 488 minecraft:purpur_block
setblock 141 272 502 minecraft:magenta_stained_glass
fill 173 272 505 173 297 505 minecraft:purpur_block
fill 183 272 466 183 287 466 minecraft:purpur_block
fill 183 272 471 183 274 471 minecraft:purpur_block
fill 183 272 474 183 307 474 minecraft:purpur_block
fill 141 273 471 141 287 471 minecraft:purpur_block
fill 141 273 487 141 287 487 minecraft:purpur_block
fill 141 273 502 141 287 503 minecraft:purpur_block
fill 145 273 463 145 287 463 minecraft:purpur_block
setblock 151 273 505 minecraft:white_concrete
fill 155 273 505 155 287 505 minecraft:purpur_block
fill 161 273 463 161 287 463 minecraft:purpur_block
fill 171 273 505 171 287 505 minecraft:purpur_block
fill 177 273 463 177 287 463 minecraft:purpur_block
setblock 182 273 505 minecraft:magenta_stained_glass
fill 183 273 473 183 283 473 minecraft:purpur_block
setblock 183 273 486 minecraft:pearlescent_froglight
fill 183 273 489 183 282 489 minecraft:purpur_block
setblock 141 274 469 minecraft:pearlescent_froglight
setblock 142 274 463 minecraft:pearlescent_froglight
fill 151 274 505 151 307 505 minecraft:purpur_block
fill 182 274 505 182 286 505 minecraft:purpur_block
fill 183 274 486 183 275 486 minecraft:purpur_block
fill 141 275 469 141 279 469 minecraft:purpur_block
setblock 141 275 497 minecraft:white_concrete
fill 141 275 498 141 283 499 minecraft:purpur_block
setblock 141 275 504 minecraft:white_concrete
fill 141 275 505 141 307 505 minecraft:purpur_block
fill 142 275 463 142 307 463 minecraft:purpur_block
fill 183 275 468 183 277 468 minecraft:purpur_block
setblock 183 275 469 minecraft:pearlescent_froglight
setblock 183 275 471 minecraft:magenta_stained_glass
setblock 183 275 481 minecraft:white_concrete
fill 141 276 497 141 307 497 minecraft:purpur_block
fill 141 276 504 141 307 504 minecraft:purpur_block
setblock 144 276 505 minecraft:white_concrete
setblock 153 276 463 minecraft:magenta_stained_glass
setblock 164 276 463 minecraft:white_concrete
fill 183 276 469 183 307 469 minecraft:purpur_block
fill 183 276 471 183 307 471 minecraft:purpur_block
fill 183 276 481 183 307 481 minecraft:purpur_block
setblock 183 276 486 minecraft:white_concrete
setblock 141 277 478 minecraft:pearlescent_froglight
fill 144 277 505 144 307 505 minecraft:purpur_block
fill 153 277 463 153 307 463 minecraft:purpur_block
fill 164 277 463 164 307 463 minecraft:purpur_block
setblock 183 277 467 minecraft:white_concrete
fill 183 277 486 183 307 486 minecraft:purpur_block
fill 141 278 478 141 307 478 minecraft:purpur_block
setblock 141 278 483 minecraft:pearlescent_froglight
setblock 144 278 466 minecraft:light[level=14]
setblock 144 278 474 minecraft:light[level=14]
setblock 144 278 482 minecraft:light[level=14]
setblock 144 278 490 minecraft:light[level=14]
setblock 144 278 498 minecraft:light[level=14]
setblock 152 278 466 minecraft:light[level=14]
setblock 152 278 474 minecraft:light[level=14]
setblock 152 278 482 minecraft:light[level=14]
setblock 152 278 490 minecraft:light[level=14]
setblock 152 278 498 minecraft:light[level=14]
setblock 160 278 466 minecraft:light[level=14]
setblock 160 278 474 minecraft:light[level=14]
setblock 160 278 482 minecraft:light[level=14]
setblock 160 278 490 minecraft:light[level=14]
setblock 160 278 498 minecraft:light[level=14]
setblock 168 278 466 minecraft:light[level=14]
setblock 168 278 474 minecraft:light[level=14]
setblock 168 278 482 minecraft:light[level=14]
setblock 168 278 490 minecraft:light[level=14]
setblock 168 278 498 minecraft:light[level=14]
setblock 176 278 466 minecraft:light[level=14]
setblock 176 278 474 minecraft:light[level=14]
setblock 176 278 482 minecraft:light[level=14]
setblock 176 278 490 minecraft:light[level=14]
setblock 176 278 498 minecraft:light[level=14]
fill 183 278 467 183 307 467 minecraft:purpur_block
setblock 183 278 468 minecraft:pearlescent_froglight
setblock 183 278 500 minecraft:white_concrete
fill 141 279 483 141 291 483 minecraft:purpur_block
fill 142 279 464 153 280 464 minecraft:end_stone
fill 142 279 465 142 280 465 minecraft:black_concrete
fill 142 279 466 144 280 471 minecraft:end_stone
fill 142 279 472 142 280 472 minecraft:black_concrete
fill 142 279 473 143 280 478 minecraft:end_stone
fill 142 279 479 142 280 479 minecraft:black_concrete
fill 142 279 480 143 280 485 minecraft:end_stone
fill 142 279 486 142 280 486 minecraft:black_concrete
fill 142 279 487 143 280 492 minecraft:end_stone
fill 142 279 493 142 280 493 minecraft:black_concrete
fill 142 279 494 143 280 499 minecraft:end_stone
fill 142 279 500 142 280 500 minecraft:black_concrete
fill 142 279 501 143 280 504 minecraft:end_stone
fill 143 279 465 162 280 465 minecraft:end_stone
fill 143 279 472 146 280 472 minecraft:end_stone
fill 143 279 479 146 280 479 minecraft:end_stone
fill 143 279 486 146 280 486 minecraft:end_stone
fill 143 279 493 146 280 493 minecraft:end_stone
fill 143 279 500 146 280 500 minecraft:end_stone
fill 144 279 473 150 280 473 minecraft:end_stone
fill 144 279 474 144 280 474 minecraft:black_concrete
fill 144 279 475 144 280 478 minecraft:end_stone
fill 144 279 480 150 280 480 minecraft:end_stone
fill 144 279 481 144 280 481 minecraft:black_concrete
fill 144 279 482 144 280 485 minecraft:end_stone
fill 144 279 487 150 280 487 minecraft:end_stone
fill 144 279 488 144 280 488 minecraft:black_concrete
fill 144 279 489 144 280 492 minecraft:end_stone
fill 144 279 494 150 280 494 minecraft:end_stone
fill 144 279 495 144 280 495 minecraft:black_concrete
fill 144 279 496 144 280 499 minecraft:end_stone
fill 144 279 501 150 280 501 minecraft:end_stone
fill 144 279 502 144 280 502 minecraft:black_concrete
fill 144 279 503 147 280 504 minecraft:end_stone
fill 145 279 466 147 280 469 minecraft:end_stone
fill 145 279 470 145 280 470 minecraft:black_concrete
fill 145 279 471 153 280 471 minecraft:end_stone
fill 145 279 474 147 280 476 minecraft:end_stone
fill 145 279 477 145 280 477 minecraft:black_concrete
fill 145 279 478 153 280 478 minecraft:end_stone
fill 145 279 481 147 280 483 minecraft:end_stone
fill 145 279 484 145 280 484 minecraft:black_concrete
fill 145 279 485 153 280 485 minecraft:end_stone
fill 145 279 488 147 280 490 minecraft:end_stone
fill 145 279 491 145 280 491 minecraft:black_concrete
fill 145 279 492 153 280 492 minecraft:end_stone
fill 145 279 495 147 280 497 minecraft:end_stone
fill 145 279 498 145 280 498 minecraft:black_concrete
fill 145 279 499 153 280 499 minecraft:end_stone
fill 145 279 502 164 280 502 minecraft:end_stone
fill 146 279 470 149 280 470 minecraft:end_stone
fill 146 279 477 149 280 477 minecraft:end_stone
fill 146 279 484 149 280 484 minecraft:end_stone
fill 146 279 491 149 280 491 minecraft:end_stone
fill 146 279 498 149 280 498 minecraft:end_stone
fill 147 279 472 147 280 472 minecraft:black_concrete
fill 147 279 479 147 280 479 minecraft:black_concrete
fill 147 279 486 147 280 486 minecraft:black_concrete
fill 147 279 493 147 280 493 minecraft:black_concrete
fill 147 279 500 147 280 500 minecraft:black_concrete
fill 148 279 466 150 280 467 minecraft:end_stone
fill 148 279 468 148 280 468 minecraft:black_concrete
fill 148 279 469 156 280 469 minecraft:end_stone
fill 148 279 472 162 280 472 minecraft:end_stone
fill 148 279 474 159 280 474 minecraft:end_stone
fill 148 279 475 148 280 475 minecraft:black_concrete
fill 148 279 476 156 280 476 minecraft:end_stone
fill 148 279 479 162 279 479 minecraft:end_stone
fill 148 279 481 159 280 481 minecraft:end_stone
fill 148 279 482 148 280 482 minecraft:black_concrete
fill 148 279 483 156 280 483 minecraft:end_stone
fill 148 279 486 162 280 486 minecraft:end_stone
fill 148 279 488 159 280 488 minecraft:end_stone
fill 148 279 489 148 280 489 minecraft:black_concrete
fill 148 279 490 156 280 490 minecraft:end_stone
fill 148 279 493 162 280 493 minecraft:end_stone
fill 148 279 495 159 280 495 minecraft:end_stone
fill 148 279 496 148 280 496 minecraft:black_concrete
fill 148 279 497 156 280 497 minecraft:end_stone
fill 148 279 500 167 280 500 minecraft:end_stone
fill 148 279 503 148 280 503 minecraft:black_concrete
fill 148 279 504 161 280 504 minecraft:end_stone
fill 149 279 468 152 280 468 minecraft:end_stone
fill 149 279 475 152 280 475 minecraft:end_stone
fill 149 279 482 152 280 482 minecraft:end_stone
fill 149 279 489 152 280 489 minecraft:end_stone
fill 149 279 496 152 280 496 minecraft:end_stone
fill 149 279 503 152 280 503 minecraft:end_stone
fill 150 279 470 150 280 470 minecraft:black_concrete
fill 150 279 477 150 280 477 minecraft:black_concrete
fill 150 279 484 150 280 484 minecraft:black_concrete
fill 150 279 491 150 280 491 minecraft:black_concrete
fill 150 279 498 150 280 498 minecraft:black_concrete
fill 151 279 466 151 280 466 minecraft:black_concrete
fill 151 279 467 159 280 467 minecraft:end_stone
fill 151 279 470 165 280 470 minecraft:end_stone
fill 151 279 473 151 280 473 minecraft:black_concrete
fill 151 279 477 165 280 477 minecraft:end_stone
fill 151 279 480 151 280 480 minecraft:black_concrete
fill 151 279 484 165 279 484 minecraft:end_stone
fill 151 279 487 151 280 487 minecraft:black_concrete
fill 151 279 491 165 280 491 minecraft:end_stone
fill 151 279 494 151 280 494 minecraft:black_concrete
fill 151 279 498 170 280 498 minecraft:end_stone
fill 151 279 501 151 280 501 minecraft:black_concrete
fill 152 279 466 155 280 466 minecraft:end_stone
fill 152 279 473 155 280 473 minecraft:end_stone
fill 152 279 480 155 280 480 minecraft:end_stone
fill 152 279 487 155 280 487 minecraft:end_stone
fill 152 279 494 155 280 494 minecraft:end_stone
fill 152 279 501 155 280 501 minecraft:end_stone
fill 153 279 468 153 280 468 minecraft:black_concrete
fill 153 279 475 153 280 475 minecraft:black_concrete
fill 153 279 482 153 280 482 minecraft:black_concrete
fill 153 279 489 153 280 489 minecraft:black_concrete
fill 153 279 496 153 280 496 minecraft:black_concrete
fill 153 279 503 153 280 503 minecraft:black_concrete
fill 154 279 464 154 280 464 minecraft:black_concrete
fill 154 279 468 168 280 468 minecraft:end_stone
fill 154 279 471 154 280 471 minecraft:black_concrete
fill 154 279 475 168 280 475 minecraft:end_stone
fill 154 279 478 154 280 478 minecraft:black_concrete
fill 154 279 482 161 279 482 minecraft:end_stone
fill 154 279 485 154 280 485 minecraft:black_concrete
fill 154 279 489 168 280 489 minecraft:end_stone
fill 154 279 492 154 280 492 minecraft:black_concrete
fill 154 279 496 173 280 496 minecraft:end_stone
fill 154 279 499 154 280 499 minecraft:black_concrete
fill 154 279 503 173 280 503 minecraft:end_stone
fill 155 279 464 158 280 464 minecraft:end_stone
fill 155 279 471 158 280 471 minecraft:end_stone
fill 155 279 478 158 280 478 minecraft:end_stone
fill 155 279 485 158 280 485 minecraft:end_stone
fill 155 279 492 158 280 492 minecraft:end_stone
fill 155 279 499 158 280 499 minecraft:end_stone
fill 156 279 466 156 280 466 minecraft:black_concrete
fill 156 279 473 156 280 473 minecraft:black_concrete
fill 156 279 480 156 280 480 minecraft:black_concrete
fill 156 279 487 156 280 487 minecraft:black_concrete
fill 156 279 494 156 280 494 minecraft:black_concrete
fill 156 279 501 156 280 501 minecraft:black_concrete
fill 157 279 466 171 280 466 minecraft:end_stone
fill 157 279 469 157 280 469 minecraft:black_concrete
fill 157 279 473 171 280 473 minecraft:end_stone
fill 157 279 476 157 280 476 minecraft:black_concrete
fill 157 279 480 161 279 480 minecraft:end_stone
fill 157 279 483 157 280 483 minecraft:black_concrete
fill 157 279 487 171 280 487 minecraft:end_stone
fill 157 279 490 157 280 490 minecraft:black_concrete
fill 157 279 494 176 280 494 minecraft:end_stone
fill 157 279 497 157 280 497 minecraft:black_concrete
fill 157 279 501 176 280 501 minecraft:end_stone
fill 158 279 469 161 280 469 minecraft:end_stone
fill 158 279 476 161 280 476 minecraft:end_stone
fill 158 279 483 161 279 483 minecraft:end_stone
fill 158 279 490 161 280 490 minecraft:end_stone
fill 158 279 497 161 280 497 minecraft:end_stone
fill 159 279 464 159 280 464 minecraft:black_concrete
fill 159 279 471 159 280 471 minecraft:black_concrete
fill 159 279 478 159 280 478 minecraft:black_concrete
fill 159 279 485 159 280 485 minecraft:black_concrete
fill 159 279 492 159 280 492 minecraft:black_concrete
fill 159 279 499 159 280 499 minecraft:black_concrete
fill 160 279 464 174 280 464 minecraft:end_stone
fill 160 279 467 160 280 467 minecraft:black_concrete
fill 160 279 471 174 280 471 minecraft:end_stone
fill 160 279 474 160 280 474 minecraft:black_concrete
fill 160 279 478 174 279 478 minecraft:end_stone
setblock 160 279 481 minecraft:black_concrete
fill 160 279 485 174 280 485 minecraft:end_stone
fill 160 279 488 160 280 488 minecraft:black_concrete
fill 160 279 492 179 280 492 minecraft:end_stone
fill 160 279 495 160 280 495 minecraft:black_concrete
fill 160 279 499 179 280 499 minecraft:end_stone
fill 161 279 467 164 280 467 minecraft:end_stone
fill 161 279 474 164 280 474 minecraft:end_stone
fill 161 279 488 164 280 488 minecraft:end_stone
fill 161 279 495 164 280 495 minecraft:end_stone
fill 162 279 469 162 280 469 minecraft:black_concrete
fill 162 279 476 162 280 476 minecraft:black_concrete
setblock 162 279 483 minecraft:black_concrete
fill 162 279 490 162 280 490 minecraft:black_concrete
fill 162 279 497 162 280 497 minecraft:black_concrete
fill 162 279 504 162 280 504 minecraft:black_concrete
fill 163 279 465 163 280 465 minecraft:black_concrete
fill 163 279 469 177 280 469 minecraft:end_stone
fill 163 279 472 163 280 472 minecraft:black_concrete
fill 163 279 476 177 280 476 minecraft:end_stone
fill 163 279 486 163 280 486 minecraft:black_concrete
fill 163 279 490 182 280 490 minecraft:end_stone
fill 163 279 493 163 280 493 minecraft:black_concrete
fill 163 279 497 182 280 497 minecraft:end_stone
fill 163 279 504 182 280 504 minecraft:end_stone
fill 164 279 465 167 280 465 minecraft:end_stone
fill 164 279 472 167 280 472 minecraft:end_stone
fill 164 279 479 167 279 479 minecraft:end_stone
fill 164 279 483 177 279 483 minecraft:end_stone
fill 164 279 486 167 280 486 minecraft:end_stone
fill 164 279 493 167 280 493 minecraft:end_stone
fill 165 279 467 165 280 467 minecraft:black_concrete
fill 165 279 474 165 280 474 minecraft:black_concrete
fill 165 279 480 171 279 480 minecraft:end_stone
fill 165 279 482 168 279 482 minecraft:end_stone
fill 165 279 488 165 280 488 minecraft:black_concrete
fill 165 279 495 165 280 495 minecraft:black_concrete
fill 165 279 502 165 280 502 minecraft:black_concrete
fill 166 279 467 180 280 467 minecraft:end_stone
fill 166 279 470 166 280 470 minecraft:black_concrete
fill 166 279 474 180 280 474 minecraft:end_stone
fill 166 279 477 166 280 477 minecraft:black_concrete
fill 166 279 481 180 279 481 minecraft:end_stone
fill 166 279 484 166 280 484 minecraft:black_concrete
fill 166 279 488 182 280 488 minecraft:end_stone
fill 166 279 491 166 280 491 minecraft:black_concrete
fill 166 279 495 182 280 495 minecraft:end_stone
fill 166 279 502 182 280 502 minecraft:end_stone
fill 167 279 470 170 280 470 minecraft:end_stone
fill 167 279 477 170 280 477 minecraft:end_stone
fill 167 279 484 170 280 484 minecraft:end_stone
fill 167 279 491 170 280 491 minecraft:end_stone
fill 168 279 465 168 280 465 minecraft:black_concrete
fill 168 279 472 168 280 472 minecraft:black_concrete
fill 168 279 479 168 280 479 minecraft:black_concrete
fill 168 279 486 168 280 486 minecraft:black_concrete
fill 168 279 493 168 280 493 minecraft:black_concrete
fill 168 279 500 168 280 500 minecraft:black_concrete
fill 169 279 465 182 280 465 minecraft:end_stone
fill 169 279 468 169 280 468 minecraft:black_concrete
fill 169 279 472 182 280 472 minecraft:end_stone
fill 169 279 475 169 280 475 minecraft:black_concrete
fill 169 279 479 182 280 479 minecraft:end_stone
fill 169 279 482 169 280 482 minecraft:black_concrete
fill 169 279 486 182 280 486 minecraft:end_stone
fill 169 279 489 169 280 489 minecraft:black_concrete
fill 169 279 493 182 280 493 minecraft:end_stone
fill 169 279 500 182 280 500 minecraft:end_stone
fill 170 279 468 173 280 468 minecraft:end_stone
fill 170 279 475 173 280 475 minecraft:end_stone
fill 170 279 482 173 280 482 minecraft:end_stone
fill 170 279 489 173 280 489 minecraft:end_stone
fill 171 279 470 171 280 470 minecraft:black_concrete
fill 171 279 477 171 280 477 minecraft:black_concrete
fill 171 279 484 171 280 484 minecraft:black_concrete
fill 171 279 491 171 280 491 minecraft:black_concrete
fill 171 279 498 171 280 498 minecraft:black_concrete
fill 172 279 466 172 280 466 minecraft:black_concrete
fill 172 279 470 182 280 470 minecraft:end_stone
fill 172 279 473 172 280 473 minecraft:black_concrete
fill 172 279 477 182 280 477 minecraft:end_stone
fill 172 279 480 172 280 480 minecraft:black_concrete
fill 172 279 484 182 280 484 minecraft:end_stone
fill 172 279 487 172 280 487 minecraft:black_concrete
fill 172 279 491 182 280 491 minecraft:end_stone
fill 172 279 498 182 280 498 minecraft:end_stone
fill 173 279 466 176 280 466 minecraft:end_stone
fill 173 279 473 176 280 473 minecraft:end_stone
fill 173 279 480 176 280 480 minecraft:end_stone
fill 173 279 487 176 280 487 minecraft:end_stone
fill 174 279 468 174 280 468 minecraft:black_concrete
fill 174 279 475 174 280 475 minecraft:black_concrete
fill 174 279 482 174 280 482 minecraft:black_concrete
fill 174 279 489 174 280 489 minecraft:black_concrete
fill 174 279 496 174 280 496 minecraft:black_concrete
fill 174 279 503 174 280 503 minecraft:black_concrete
fill 175 279 464 175 280 464 minecraft:black_concrete
fill 175 279 468 182 280 468 minecraft:end_stone
fill 175 279 471 175 280 471 minecraft:black_concrete
fill 175 279 475 182 280 475 minecraft:end_stone
fill 175 279 478 175 280 478 minecraft:black_concrete
fill 175 279 482 182 280 482 minecraft:end_stone
fill 175 279 485 175 280 485 minecraft:black_concrete
fill 175 279 489 182 280 489 minecraft:end_stone
fill 175 279 496 182 280 496 minecraft:end_stone
fill 175 279 503 182 280 503 minecraft:end_stone
fill 176 279 464 179 280 464 minecraft:end_stone
fill 176 279 471 179 280 471 minecraft:end_stone
fill 176 279 478 179 280 478 minecraft:end_stone
fill 176 279 485 179 280 485 minecraft:end_stone
fill 177 279 466 177 280 466 minecraft:black_concrete
fill 177 279 473 177 280 473 minecraft:black_concrete
fill 177 279 480 177 280 480 minecraft:black_concrete
fill 177 279 487 177 280 487 minecraft:black_concrete
fill 177 279 494 177 280 494 minecraft:black_concrete
fill 177 279 501 177 280 501 minecraft:black_concrete
fill 178 279 466 182 280 466 minecraft:end_stone
fill 178 279 469 178 280 469 minecraft:black_concrete
fill 178 279 473 182 280 473 minecraft:end_stone
fill 178 279 476 178 280 476 minecraft:black_concrete
fill 178 279 480 182 280 480 minecraft:end_stone
fill 178 279 483 178 280 483 minecraft:black_concrete
fill 178 279 487 182 280 487 minecraft:end_stone
fill 178 279 494 182 280 494 minecraft:end_stone
fill 178 279 501 182 280 501 minecraft:end_stone
fill 179 279 469 182 280 469 minecraft:end_stone
fill 179 279 476 182 280 476 minecraft:end_stone
fill 179 279 483 182 280 483 minecraft:end_stone
fill 180 279 464 180 280 464 minecraft:black_concrete
fill 180 279 471 180 280 471 minecraft:black_concrete
fill 180 279 478 180 280 478 minecraft:black_concrete
fill 180 279 485 180 280 485 minecraft:black_concrete
fill 180 279 492 180 280 492 minecraft:black_concrete
fill 180 279 499 180 280 499 minecraft:black_concrete
fill 181 279 464 182 280 464 minecraft:end_stone
fill 181 279 467 181 280 467 minecraft:black_concrete
fill 181 279 471 182 280 471 minecraft:end_stone
fill 181 279 474 181 280 474 minecraft:black_concrete
fill 181 279 478 182 280 478 minecraft:end_stone
fill 181 279 481 181 280 481 minecraft:black_concrete
fill 181 279 485 182 280 485 minecraft:end_stone
fill 181 279 492 182 280 492 minecraft:end_stone
fill 181 279 499 182 280 499 minecraft:end_stone
fill 182 279 467 182 280 467 minecraft:end_stone
fill 182 279 474 182 280 474 minecraft:end_stone
fill 182 279 481 182 280 481 minecraft:end_stone
fill 183 279 468 183 287 468 minecraft:purpur_block
fill 183 279 500 183 307 500 minecraft:purpur_block
setblock 141 280 469 minecraft:white_concrete
fill 148 280 479 160 280 479 minecraft:end_stone
fill 151 280 484 161 280 484 minecraft:end_stone
fill 154 280 482 159 280 482 minecraft:end_stone
fill 157 280 480 159 280 480 minecraft:end_stone
fill 158 280 483 160 280 483 minecraft:end_stone
setblock 158 280 505 minecraft:magenta_stained_glass
fill 159 280 505 159 307 505 minecraft:purpur_block
fill 160 280 478 161 280 478 minecraft:end_stone
fill 160 280 480 160 280 482 minecraft:pearlescent_froglight
fill 161 280 479 161 280 480 minecraft:pearlescent_froglight
fill 161 280 482 161 280 483 minecraft:pearlescent_froglight
fill 162 280 478 162 280 479 minecraft:pearlescent_froglight
fill 162 280 483 162 280 484 minecraft:pearlescent_froglight
fill 163 280 478 164 280 478 minecraft:pearlescent_froglight
fill 163 280 484 164 280 484 minecraft:pearlescent_froglight
fill 164 280 479 165 280 479 minecraft:pearlescent_froglight
fill 164 280 483 165 280 483 minecraft:pearlescent_froglight
fill 165 280 478 174 280 478 minecraft:end_stone
fill 165 280 480 166 280 480 minecraft:pearlescent_froglight
fill 165 280 482 166 280 482 minecraft:pearlescent_froglight
setblock 165 280 484 minecraft:end_stone
fill 166 280 479 167 280 479 minecraft:end_stone
setblock 166 280 481 minecraft:pearlescent_froglight
fill 166 280 483 177 280 483 minecraft:end_stone
fill 167 280 480 168 280 482 minecraft:end_stone
fill 169 280 480 171 280 481 minecraft:end_stone
fill 172 280 481 180 280 481 minecraft:end_stone
setblock 172 280 505 minecraft:white_concrete
setblock 183 280 482 minecraft:pearlescent_froglight
fill 141 281 469 141 307 469 minecraft:purpur_block
fill 141 281 490 141 307 490 minecraft:purpur_block
setblock 141 281 491 minecraft:pearlescent_froglight
setblock 143 281 505 minecraft:magenta_stained_glass
fill 158 281 505 158 307 505 minecraft:purpur_block
fill 172 281 505 172 307 505 minecraft:purpur_block
fill 183 281 482 183 282 482 minecraft:purpur_block
setblock 183 281 487 minecraft:white_concrete
fill 183 281 488 183 289 488 minecraft:purpur_block
fill 141 282 464 141 283 464 minecraft:purpur_block
setblock 141 282 465 minecraft:white_concrete
fill 141 282 491 141 307 491 minecraft:purpur_block
fill 143 282 505 143 298 505 minecraft:purpur_block
setblock 156 282 463 minecraft:white_concrete
fill 183 282 487 183 292 487 minecraft:purpur_block
fill 141 283 465 141 307 465 minecraft:purpur_block
setblock 141 283 467 minecraft:white_concrete
setblock 147 283 505 minecraft:white_concrete
fill 156 283 463 156 300 463 minecraft:purpur_block
setblock 168 283 463 minecraft:pearlescent_froglight
fill 169 283 463 169 286 463 minecraft:purpur_block
setblock 183 283 482 minecraft:white_concrete
setblock 183 283 489 minecraft:white_concrete
setblock 183 283 497 minecraft:magenta_stained_glass
setblock 141 284 464 minecraft:pearlescent_froglight
fill 141 284 467 141 307 467 minecraft:purpur_block
setblock 141 284 498 minecraft:white_concrete
fill 141 284 499 141 306 499 minecraft:purpur_block
fill 147 284 505 147 307 505 minecraft:purpur_block
fill 152 284 480 152 284 481 minecraft:end_stone
fill 168 284 463 168 307 463 minecraft:purpur_block
setblock 183 284 473 minecraft:magenta_stained_glass
fill 183 284 482 183 307 482 minecraft:purpur_block
setblock 183 284 483 minecraft:white_concrete
fill 183 284 489 183 287 489 minecraft:purpur_block
fill 183 284 497 183 300 497 minecraft:purpur_block
fill 141 285 464 141 307 464 minecraft:purpur_block
setblock 141 285 492 minecraft:magenta_stained_glass
fill 141 285 498 141 307 498 minecraft:purpur_block
setblock 149 285 463 minecraft:pearlescent_froglight
setblock 181 285 463 minecraft:white_concrete
fill 183 285 473 183 287 473 minecraft:purpur_block
fill 183 285 483 183 307 483 minecraft:purpur_block
setblock 183 285 496 minecraft:pearlescent_froglight
setblock 141 286 477 minecraft:pearlescent_froglight
fill 141 286 492 141 307 492 minecraft:purpur_block
setblock 144 286 466 minecraft:light[level=14]
setblock 144 286 474 minecraft:light[level=14]
setblock 144 286 482 minecraft:light[level=14]
setblock 144 286 490 minecraft:light[level=14]
setblock 144 286 498 minecraft:light[level=14]
fill 149 286 463 149 307 463 minecraft:purpur_block
setblock 152 286 466 minecraft:light[level=14]
setblock 152 286 474 minecraft:light[level=14]
setblock 152 286 482 minecraft:light[level=14]
setblock 152 286 490 minecraft:light[level=14]
setblock 152 286 498 minecraft:light[level=14]
setblock 160 286 466 minecraft:light[level=14]
setblock 160 286 474 minecraft:light[level=14]
setblock 160 286 482 minecraft:light[level=14]
setblock 160 286 490 minecraft:light[level=14]
setblock 160 286 498 minecraft:light[level=14]
setblock 168 286 466 minecraft:light[level=14]
setblock 168 286 474 minecraft:light[level=14]
setblock 168 286 482 minecraft:light[level=14]
setblock 168 286 490 minecraft:light[level=14]
setblock 168 286 498 minecraft:light[level=14]
setblock 176 286 466 minecraft:light[level=14]
setblock 176 286 474 minecraft:light[level=14]
setblock 176 286 482 minecraft:light[level=14]
setblock 176 286 490 minecraft:light[level=14]
setblock 176 286 498 minecraft:light[level=14]
fill 181 286 463 181 297 463 minecraft:purpur_block
fill 183 286 496 183 307 496 minecraft:purpur_block
fill 141 287 477 141 307 477 minecraft:purpur_block
setblock 141 287 493 minecraft:magenta_stained_glass
fill 148 287 475 149 288 476 minecraft:obsidian
setblock 169 287 463 minecraft:magenta_stained_glass
setblock 171 287 463 minecraft:magenta_stained_glass
fill 172 287 463 172 307 463 minecraft:purpur_block
setblock 178 287 463 minecraft:white_concrete
setblock 182 287 505 minecraft:pearlescent_froglight
fill 141 288 471 141 290 471 minecraft:magenta_concrete
fill 141 288 487 141 290 487 minecraft:magenta_concrete
fill 141 288 493 141 307 493 minecraft:purpur_block
fill 141 288 502 141 307 502 minecraft:purpur_block
fill 141 288 503 141 290 503 minecraft:magenta_concrete
fill 145 288 463 145 290 463 minecraft:magenta_concrete
fill 155 288 505 155 290 505 minecraft:magenta_concrete
fill 161 288 463 161 290 463 minecraft:magenta_concrete
setblock 161 288 505 minecraft:magenta_stained_glass
setblock 166 288 463 minecraft:white_concrete
fill 169 288 463 169 307 463 minecraft:purpur_block
fill 171 288 463 171 305 463 minecraft:purpur_block
fill 171 288 505 171 290 505 minecraft:magenta_concrete
fill 177 288 463 177 290 463 minecraft:magenta_concrete
fill 178 288 463 178 307 463 minecraft:purpur_block
fill 182 288 505 182 307 505 minecraft:purpur_block
setblock 183 288 466 minecraft:magenta_stained_glass
setblock 183 288 468 minecraft:pearlescent_froglight
fill 183 288 473 183 290 473 minecraft:magenta_concrete
fill 183 288 489 183 290 489 minecraft:magenta_concrete
fill 150 289 490 150 291 490 minecraft:magenta_stained_glass
setblock 156 289 505 minecraft:magenta_stained_glass
fill 161 289 505 161 290 505 minecraft:purpur_block
fill 166 289 463 166 307 463 minecraft:purpur_block
fill 183 289 466 183 307 466 minecraft:purpur_block
fill 183 289 468 183 303 468 minecraft:purpur_block
setblock 141 290 472 minecraft:pearlescent_froglight
fill 156 290 505 156 296 505 minecraft:purpur_block
setblock 183 290 488 minecraft:white_concrete
setblock 183 290 495 minecraft:pearlescent_froglight
fill 141 291 471 141 296 472 minecraft:purpur_block
setblock 141 291 485 minecraft:magenta_stained_glass
fill 141 291 487 141 296 487 minecraft:purpur_block
fill 141 291 503 141 296 503 minecraft:purpur_block
fill 145 291 463 145 296 463 minecraft:purpur_block
fill 155 291 505 155 296 505 minecraft:purpur_block
fill 161 291 463 161 295 463 minecraft:purpur_block
setblock 161 291 505 minecraft:white_concrete
fill 171 291 505 171 296 505 minecraft:purpur_block
fill 177 291 463 177 296 463 minecraft:purpur_block
fill 183 291 473 183 296 473 minecraft:purpur_block
fill 183 291 488 183 296 489 minecraft:purpur_block
fill 183 291 495 183 307 495 minecraft:purpur_block
setblock 141 292 483 minecraft:magenta_stained_glass
fill 141 292 485 141 307 485 minecraft:purpur_block
setblock 148 292 505 minecraft:white_concrete
setblock 150 292 463 minecraft:magenta_stained_glass
fill 150 292 490 151 298 491 minecraft:purpur_block
fill 152 292 490 152 293 490 minecraft:obsidian
fill 161 292 495 162 293 496 minecraft:end_stone
fill 161 292 505 161 307 505 minecraft:purpur_block
setblock 182 292 463 minecraft:white_concrete
fill 141 293 483 141 307 483 minecraft:purpur_block
setblock 145 293 505 minecraft:pearlescent_froglight
fill 148 293 505 148 307 505 minecraft:purpur_block
fill 149 293 490 149 298 491 minecraft:purpur_block
fill 150 293 463 150 307 463 minecraft:purpur_block
fill 150 293 498 151 294 499 minecraft:end_stone
fill 182 293 463 182 302 463 minecraft:purpur_block
setblock 183 293 487 minecraft:magenta_stained_glass
setblock 183 293 504 minecraft:pearlescent_froglight
setblock 141 294 476 minecraft:white_concrete
setblock 144 294 466 minecraft:light[level=14]
setblock 144 294 474 minecraft:light[level=14]
setblock 144 294 482 minecraft:light[level=14]
setblock 144 294 490 minecraft:light[level=14]
setblock 144 294 498 minecraft:light[level=14]
fill 145 294 505 145 297 505 minecraft:purpur_block
fill 150 294 489 151 298 489 minecraft:purpur_block
fill 150 294 492 151 298 492 minecraft:purpur_block
setblock 152 294 466 minecraft:light[level=14]
setblock 152 294 474 minecraft:light[level=14]
setblock 152 294 482 minecraft:light[level=14]
fill 152 294 490 152 298 491 minecraft:purpur_block
setblock 152 294 498 minecraft:light[level=14]
setblock 160 294 466 minecraft:light[level=14]
setblock 160 294 474 minecraft:light[level=14]
setblock 160 294 482 minecraft:light[level=14]
setblock 160 294 490 minecraft:light[level=14]
setblock 160 294 498 minecraft:light[level=14]
setblock 168 294 466 minecraft:light[level=14]
setblock 168 294 474 minecraft:light[level=14]
setblock 168 294 482 minecraft:light[level=14]
setblock 168 294 490 minecraft:light[level=14]
setblock 168 294 498 minecraft:light[level=14]
setblock 176 294 466 minecraft:light[level=14]
setblock 176 294 474 minecraft:light[level=14]
setblock 176 294 482 minecraft:light[level=14]
setblock 176 294 490 minecraft:light[level=14]
setblock 176 294 498 minecraft:light[level=14]
fill 183 294 487 183 306 487 minecraft:purpur_block
fill 183 294 504 183 301 504 minecraft:purpur_block
fill 141 295 476 141 307 476 minecraft:purpur_block
setblock 141 295 484 minecraft:magenta_stained_glass
fill 148 295 490 148 298 490 minecraft:purpur_block
fill 149 295 489 149 298 489 minecraft:purpur_block
fill 149 295 492 149 298 492 minecraft:purpur_block
fill 152 295 489 152 298 489 minecraft:purpur_block
fill 152 295 492 152 298 492 minecraft:purpur_block
fill 154 295 473 154 296 473 minecraft:obsidian
setblock 166 295 505 minecraft:magenta_stained_glass
setblock 167 295 463 minecraft:white_concrete
setblock 183 295 498 minecraft:white_concrete
fill 141 296 484 141 299 484 minecraft:purpur_block
setblock 141 296 501 minecraft:white_concrete
fill 148 296 489 148 298 489 minecraft:purpur_block
fill 148 296 491 148 298 492 minecraft:purpur_block
fill 149 296 488 151 298 488 minecraft:purpur_block
fill 149 296 493 151 298 493 minecraft:purpur_block
fill 153 296 490 153 298 491 minecraft:purpur_block
setblock 161 296 463 minecraft:magenta_stained_glass
fill 166 296 505 166 306 505 minecraft:purpur_block
fill 167 296 463 167 307 463 minecraft:purpur_block
fill 170 296 490 170 297 490 minecraft:purpur_block
fill 183 296 498 183 304 498 minecraft:purpur_block
fill 141 297 471 141 299 471 minecraft:magenta_concrete
fill 141 297 472 141 300 472 minecraft:purpur_block
fill 141 297 487 141 299 487 minecraft:magenta_concrete
fill 141 297 501 141 307 501 minecraft:purpur_block
fill 141 297 503 141 299 503 minecraft:magenta_concrete
fill 145 297 463 145 299 463 minecraft:magenta_concrete
fill 152 297 488 152 298 488 minecraft:purpur_block
fill 152 297 493 152 298 493 minecraft:purpur_block
fill 153 297 489 153 298 489 minecraft:purpur_block
fill 153 297 492 153 298 492 minecraft:purpur_block
fill 155 297 505 155 299 505 minecraft:magenta_concrete
setblock 156 297 505 minecraft:magenta_stained_glass
fill 161 297 463 161 299 463 minecraft:magenta_concrete
fill 171 297 505 171 299 505 minecraft:magenta_concrete
fill 177 297 463 177 299 463 minecraft:magenta_concrete
setblock 179 297 463 minecraft:magenta_stained_glass
fill 183 297 473 183 299 473 minecraft:magenta_concrete
fill 183 297 488 183 307 488 minecraft:purpur_block
fill 183 297 489 183 299 489 minecraft:magenta_concrete
setblock 145 298 505 minecraft:pearlescent_froglight
fill 147 298 489 147 298 492 minecraft:purpur_block
setblock 148 298 488 minecraft:purpur_block
setblock 148 298 493 minecraft:purpur_block
fill 149 298 487 152 298 487 minecraft:purpur_block
fill 149 298 494 151 298 494 minecraft:purpur_block
setblock 153 298 488 minecraft:purpur_block
setblock 153 298 493 minecraft:purpur_block
fill 154 298 490 154 298 491 minecraft:purpur_block
fill 156 298 505 156 307 505 minecraft:purpur_block
setblock 160 298 463 minecraft:white_concrete
setblock 173 298 505 minecraft:white_concrete
fill 179 298 463 179 307 463 minecraft:purpur_block
setblock 181 298 463 minecraft:white_concrete
setblock 181 298 505 minecraft:pearlescent_froglight
setblock 143 299 505 minecraft:magenta_stained_glass
setblock 144 299 463 minecraft:white_concrete
fill 145 299 505 145 307 505 minecraft:purpur_block
fill 149 299 491 149 300 491 minecraft:end_stone_bricks
fill 150 299 489 150 300 489 minecraft:end_stone_bricks
fill 152 299 491 152 300 491 minecraft:end_stone_bricks
fill 159 299 493 160 300 494 minecraft:obsidian
fill 160 299 463 160 307 463 minecraft:purpur_block
fill 173 299 505 173 307 505 minecraft:purpur_block
fill 181 299 463 181 304 463 minecraft:purpur_block
fill 181 299 505 181 306 505 minecraft:purpur_block
fill 141 300 471 141 307 471 minecraft:purpur_block
setblock 141 300 484 minecraft:pearlescent_froglight
fill 141 300 487 141 307 487 minecraft:purpur_block
fill 141 300 503 141 307 503 minecraft:purpur_block
fill 143 300 505 143 307 505 minecraft:purpur_block
fill 144 300 463 145 307 463 minecraft:purpur_block
fill 155 300 505 155 307 505 minecraft:purpur_block
fill 161 300 463 161 307 463 minecraft:purpur_block
fill 171 300 505 171 307 505 minecraft:purpur_block
fill 177 300 463 177 307 463 minecraft:purpur_block
fill 183 300 473 183 307 473 minecraft:purpur_block
setblock 183 300 477 minecraft:magenta_stained_glass
setblock 183 300 478 minecraft:white_concrete
fill 183 300 489 183 307 489 minecraft:purpur_block
setblock 141 301 472 minecraft:white_concrete
fill 141 301 484 141 307 484 minecraft:purpur_block
setblock 156 301 463 minecraft:pearlescent_froglight
fill 183 301 477 183 306 478 minecraft:purpur_block
setblock 183 301 497 minecraft:pearlescent_froglight
fill 141 302 472 141 307 472 minecraft:purpur_block
setblock 144 302 466 minecraft:light[level=14]
setblock 144 302 474 minecraft:light[level=14]
setblock 144 302 482 minecraft:light[level=14]
setblock 144 302 490 minecraft:light[level=14]
setblock 144 302 498 minecraft:light[level=14]
setblock 148 302 463 minecraft:magenta_stained_glass
setblock 152 302 466 minecraft:light[level=14]
setblock 152 302 474 minecraft:light[level=14]
setblock 152 302 482 minecraft:light[level=14]
setblock 152 302 490 minecraft:light[level=14]
setblock 152 302 498 minecraft:light[level=14]
fill 156 302 463 156 307 463 minecraft:purpur_block
setblock 160 302 466 minecraft:light[level=14]
setblock 160 302 474 minecraft:light[level=14]
setblock 160 302 482 minecraft:light[level=14]
setblock 160 302 490 minecraft:light[level=14]
setblock 160 302 498 minecraft:light[level=14]
setblock 168 302 466 minecraft:light[level=14]
setblock 168 302 474 minecraft:light[level=14]
setblock 168 302 482 minecraft:light[level=14]
setblock 168 302 490 minecraft:light[level=14]
setblock 168 302 498 minecraft:light[level=14]
setblock 176 302 466 minecraft:light[level=14]
setblock 176 302 474 minecraft:light[level=14]
setblock 176 302 482 minecraft:light[level=14]
setblock 176 302 490 minecraft:light[level=14]
setblock 176 302 498 minecraft:light[level=14]
fill 183 302 497 183 303 497 minecraft:purpur_block
setblock 183 302 502 minecraft:white_concrete
fill 183 302 503 183 307 503 minecraft:purpur_block
setblock 183 302 504 minecraft:pearlescent_froglight
setblock 141 303 479 minecraft:magenta_stained_glass
setblock 148 303 463 minecraft:purpur_block
setblock 182 303 463 minecraft:pearlescent_froglight
setblock 183 303 502 minecraft:magenta_stained_glass
fill 183 303 504 183 307 504 minecraft:purpur_block
fill 141 304 479 141 307 479 minecraft:purpur_block
setblock 148 304 463 minecraft:pearlescent_froglight
setblock 167 304 505 minecraft:pearlescent_froglight
setblock 176 304 463 minecraft:pearlescent_froglight
fill 182 304 463 182 307 463 minecraft:purpur_block
setblock 183 304 468 minecraft:magenta_stained_glass
setblock 183 304 497 minecraft:white_concrete
fill 183 304 502 183 307 502 minecraft:purpur_block
fill 148 305 463 148 307 463 minecraft:purpur_block
fill 167 305 505 167 306 505 minecraft:purpur_block
fill 176 305 463 176 307 463 minecraft:purpur_block
setblock 181 305 463 minecraft:pearlescent_froglight
fill 183 305 468 183 307 468 minecraft:purpur_block
fill 183 305 497 183 307 497 minecraft:purpur_block
setblock 183 305 498 minecraft:magenta_stained_glass
setblock 152 306 505 minecraft:magenta_stained_glass
setblock 171 306 463 minecraft:white_concrete
fill 181 306 463 181 307 463 minecraft:purpur_block
setblock 183 306 476 minecraft:pearlescent_froglight
fill 183 306 498 183 307 498 minecraft:purpur_block
setblock 141 307 496 minecraft:white_concrete
setblock 141 307 499 minecraft:pearlescent_froglight
setblock 152 307 505 minecraft:purpur_block
setblock 162 307 463 minecraft:white_concrete
setblock 166 307 505 minecraft:white_concrete
setblock 167 307 505 minecraft:pearlescent_froglight
setblock 171 307 463 minecraft:purpur_block
setblock 181 307 505 minecraft:white_concrete
fill 183 307 476 183 307 477 minecraft:purpur_block
setblock 183 307 478 minecraft:white_concrete
setblock 183 307 487 minecraft:magenta_stained_glass
