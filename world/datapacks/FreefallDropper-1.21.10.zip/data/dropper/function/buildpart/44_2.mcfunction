setblock 379 -4 201 minecraft:stone_bricks
fill 379 -4 202 379 -2 202 minecraft:mossy_cobblestone
setblock 379 -4 206 minecraft:stone_bricks
fill 379 -4 207 379 -1 207 minecraft:mossy_cobblestone
setblock 379 -4 211 minecraft:stone_bricks
fill 379 -4 212 379 -1 212 minecraft:mossy_cobblestone
setblock 379 -4 221 minecraft:stone_bricks
fill 379 -4 222 379 -1 222 minecraft:mossy_cobblestone
setblock 380 -4 205 minecraft:stone_bricks
fill 380 -4 206 381 -3 206 minecraft:mossy_cobblestone
setblock 380 -4 210 minecraft:stone_bricks
fill 380 -4 221 380 -3 221 minecraft:mossy_cobblestone
setblock 381 -4 205 minecraft:mossy_cobblestone
setblock 382 -4 183 minecraft:stone_bricks
setblock 382 -4 184 minecraft:mossy_cobblestone
setblock 383 -4 182 minecraft:stone_bricks
fill 383 -4 183 383 -1 183 minecraft:mossy_cobblestone
setblock 383 -4 222 minecraft:stone_bricks
fill 384 -4 182 384 -1 182 minecraft:mossy_cobblestone
setblock 384 -4 184 minecraft:mossy_cobblestone
setblock 384 -4 221 minecraft:stone_bricks
fill 384 -4 222 384 -2 222 minecraft:mossy_cobblestone
setblock 385 -4 221 minecraft:mossy_cobblestone
setblock 387 -4 183 minecraft:stone_bricks
setblock 388 -4 182 minecraft:stone_bricks
setblock 388 -4 183 minecraft:mossy_cobblestone
setblock 388 -4 222 minecraft:stone_bricks
fill 389 -4 182 392 -4 182 minecraft:mossy_cobblestone
setblock 393 -4 182 minecraft:stone_bricks
fill 394 -4 182 394 -1 182 minecraft:mossy_cobblestone
setblock 397 -4 182 minecraft:mossy_cobblestone
setblock 397 -4 183 minecraft:stone_bricks
fill 397 -4 184 397 -1 184 minecraft:mossy_cobblestone
setblock 397 -4 222 minecraft:mossy_cobblestone
setblock 398 -4 182 minecraft:stone_bricks
fill 398 -4 183 398 -1 183 minecraft:mossy_cobblestone
setblock 398 -4 222 minecraft:stone_bricks
fill 399 -4 182 399 -1 182 minecraft:mossy_cobblestone
setblock 399 -4 185 minecraft:mossy_cobblestone
fill 399 -4 222 399 -1 222 minecraft:mossy_cobblestone
setblock 400 -4 185 minecraft:stone_bricks
setblock 401 -4 184 minecraft:stone_bricks
fill 401 -4 185 404 -4 185 minecraft:mossy_cobblestone
setblock 402 -4 183 minecraft:stone_bricks
fill 402 -4 184 402 -1 184 minecraft:mossy_cobblestone
setblock 403 -4 182 minecraft:stone_bricks
fill 403 -4 183 403 -1 183 minecraft:mossy_cobblestone
setblock 403 -4 186 minecraft:mossy_cobblestone
setblock 403 -4 222 minecraft:stone_bricks
fill 404 -4 182 404 -1 182 minecraft:mossy_cobblestone
setblock 404 -4 221 minecraft:stone_bricks
fill 404 -4 222 404 -1 222 minecraft:mossy_cobblestone
setblock 405 -4 185 minecraft:stone_bricks
fill 405 -4 221 405 -3 221 minecraft:mossy_cobblestone
setblock 406 -4 184 minecraft:stone_bricks
fill 406 -4 185 406 -2 185 minecraft:mossy_cobblestone
setblock 407 -4 183 minecraft:stone_bricks
fill 407 -4 184 407 -1 184 minecraft:mossy_cobblestone
setblock 408 -4 182 minecraft:stone_bricks
fill 408 -4 183 408 -1 183 minecraft:mossy_cobblestone
setblock 408 -4 222 minecraft:stone_bricks
fill 409 -4 182 409 -1 182 minecraft:mossy_cobblestone
setblock 409 -4 221 minecraft:stone_bricks
fill 409 -4 222 409 -2 222 minecraft:mossy_cobblestone
setblock 411 -4 184 minecraft:stone_bricks
setblock 412 -4 183 minecraft:stone_bricks
setblock 413 -4 182 minecraft:stone_bricks
fill 413 -4 183 413 -2 183 minecraft:mossy_cobblestone
setblock 413 -4 222 minecraft:stone_bricks
fill 414 -4 182 414 -1 182 minecraft:mossy_cobblestone
fill 414 -4 222 414 -1 222 minecraft:mossy_cobblestone
setblock 415 -4 221 minecraft:mossy_cobblestone
setblock 416 -4 184 minecraft:stone_bricks
fill 416 -4 185 416 -1 185 minecraft:mossy_cobblestone
setblock 417 -4 183 minecraft:stone_bricks
fill 417 -4 184 417 -1 184 minecraft:mossy_cobblestone
setblock 417 -4 188 minecraft:stone_bricks
setblock 417 -4 203 minecraft:stone_bricks
fill 417 -4 204 417 -1 204 minecraft:mossy_cobblestone
setblock 417 -4 208 minecraft:stone_bricks
fill 417 -4 209 417 -4 212 minecraft:mossy_cobblestone
setblock 417 -4 213 minecraft:stone_bricks
fill 417 -4 214 417 -1 214 minecraft:mossy_cobblestone
setblock 417 -4 218 minecraft:stone_bricks
fill 417 -4 219 417 -1 219 minecraft:mossy_cobblestone
setblock 377 -3 182 minecraft:stone_bricks
fill 377 -3 183 380 -3 183 minecraft:mossy_cobblestone
setblock 377 -3 187 minecraft:stone_bricks
fill 377 -3 188 377 0 188 minecraft:mossy_cobblestone
fill 377 -3 199 377 -3 201 minecraft:mossy_cobblestone
setblock 377 -3 202 minecraft:stone_bricks
fill 377 -3 203 377 -3 206 minecraft:mossy_cobblestone
setblock 377 -3 207 minecraft:stone_bricks
fill 377 -3 208 377 0 208 minecraft:mossy_cobblestone
setblock 377 -3 211 minecraft:mossy_cobblestone
setblock 377 -3 212 minecraft:stone_bricks
fill 377 -3 213 377 0 213 minecraft:mossy_cobblestone
setblock 377 -3 217 minecraft:stone_bricks
fill 377 -3 218 377 0 218 minecraft:mossy_cobblestone
setblock 377 -3 222 minecraft:stone_bricks
fill 378 -3 182 378 0 182 minecraft:mossy_cobblestone
setblock 378 -3 200 minecraft:mossy_cobblestone
setblock 378 -3 201 minecraft:stone_bricks
fill 378 -3 202 378 0 202 minecraft:mossy_cobblestone
setblock 378 -3 206 minecraft:stone_bricks
fill 378 -3 207 378 0 207 minecraft:mossy_cobblestone
setblock 378 -3 210 minecraft:mossy_cobblestone
setblock 378 -3 211 minecraft:stone_bricks
fill 378 -3 212 378 0 212 minecraft:mossy_cobblestone
setblock 378 -3 221 minecraft:stone_bricks
fill 378 -3 222 378 0 222 minecraft:mossy_cobblestone
setblock 379 -3 201 minecraft:mossy_cobblestone
setblock 379 -3 204 minecraft:mossy_cobblestone
setblock 379 -3 205 minecraft:stone_bricks
fill 379 -3 206 379 0 206 minecraft:mossy_cobblestone
setblock 379 -3 210 minecraft:stone_bricks
fill 379 -3 211 379 0 211 minecraft:mossy_cobblestone
setblock 379 -3 221 minecraft:mossy_cobblestone
setblock 380 -3 204 minecraft:stone_bricks
fill 380 -3 205 380 0 205 minecraft:mossy_cobblestone
setblock 380 -3 209 minecraft:stone_bricks
fill 380 -3 210 380 0 210 minecraft:mossy_cobblestone
setblock 381 -3 183 minecraft:stone_bricks
setblock 382 -3 182 minecraft:stone_bricks
fill 382 -3 183 382 -1 183 minecraft:mossy_cobblestone
setblock 382 -3 222 minecraft:stone_bricks
fill 383 -3 182 383 0 182 minecraft:mossy_cobblestone
setblock 383 -3 221 minecraft:stone_bricks
fill 383 -3 222 383 -1 222 minecraft:mossy_cobblestone
setblock 386 -3 183 minecraft:stone_bricks
setblock 387 -3 182 minecraft:stone_bricks
setblock 387 -3 183 minecraft:mossy_cobblestone
fill 388 -3 182 391 -3 182 minecraft:mossy_cobblestone
setblock 392 -3 182 minecraft:stone_bricks
fill 393 -3 182 393 -2 182 minecraft:mossy_cobblestone
setblock 395 -3 183 minecraft:mossy_cobblestone
setblock 396 -3 183 minecraft:stone_bricks
setblock 397 -3 182 minecraft:stone_bricks
fill 397 -3 183 397 0 183 minecraft:mossy_cobblestone
fill 398 -3 182 398 0 182 minecraft:mossy_cobblestone
fill 398 -3 222 398 -2 222 minecraft:mossy_cobblestone
setblock 399 -3 185 minecraft:stone_bricks
setblock 400 -3 184 minecraft:stone_bricks
fill 400 -3 185 403 -3 185 minecraft:mossy_cobblestone
setblock 401 -3 183 minecraft:stone_bricks
fill 401 -3 184 401 0 184 minecraft:mossy_cobblestone
setblock 402 -3 182 minecraft:stone_bricks
fill 402 -3 183 402 0 183 minecraft:mossy_cobblestone
setblock 402 -3 222 minecraft:stone_bricks
fill 403 -3 182 403 0 182 minecraft:mossy_cobblestone
setblock 403 -3 221 minecraft:stone_bricks
fill 403 -3 222 403 0 222 minecraft:mossy_cobblestone
setblock 404 -3 185 minecraft:stone_bricks
setblock 404 -3 221 minecraft:mossy_cobblestone
setblock 405 -3 184 minecraft:stone_bricks
fill 405 -3 185 405 -2 185 minecraft:mossy_cobblestone
setblock 406 -3 183 minecraft:stone_bricks
fill 406 -3 184 406 -1 184 minecraft:mossy_cobblestone
setblock 407 -3 182 minecraft:stone_bricks
fill 407 -3 183 407 0 183 minecraft:mossy_cobblestone
setblock 407 -3 222 minecraft:stone_bricks
fill 408 -3 182 408 0 182 minecraft:mossy_cobblestone
fill 408 -3 222 408 -1 222 minecraft:mossy_cobblestone
setblock 410 -3 184 minecraft:stone_bricks
setblock 411 -3 183 minecraft:stone_bricks
setblock 412 -3 182 minecraft:stone_bricks
fill 412 -3 183 412 -2 183 minecraft:mossy_cobblestone
setblock 412 -3 222 minecraft:stone_bricks
fill 413 -3 182 413 0 182 minecraft:mossy_cobblestone
fill 413 -3 222 413 -2 222 minecraft:mossy_cobblestone
setblock 416 -3 183 minecraft:stone_bricks
fill 416 -3 184 416 -1 184 minecraft:mossy_cobblestone
setblock 416 -3 207 minecraft:mossy_cobblestone
setblock 417 -3 182 minecraft:stone_bricks
fill 417 -3 183 417 0 183 minecraft:mossy_cobblestone
setblock 417 -3 187 minecraft:stone_bricks
fill 417 -3 188 417 -1 189 minecraft:mossy_cobblestone
setblock 417 -3 202 minecraft:stone_bricks
fill 417 -3 203 417 0 203 minecraft:mossy_cobblestone
setblock 417 -3 207 minecraft:stone_bricks
fill 417 -3 208 417 -3 211 minecraft:mossy_cobblestone
setblock 417 -3 212 minecraft:stone_bricks
fill 417 -3 213 417 0 213 minecraft:mossy_cobblestone
setblock 417 -3 217 minecraft:stone_bricks
fill 417 -3 218 417 0 218 minecraft:mossy_cobblestone
setblock 417 -3 222 minecraft:stone_bricks
fill 377 -2 182 377 0 183 minecraft:mossy_cobblestone
setblock 377 -2 186 minecraft:stone_bricks
fill 377 -2 187 377 1 187 minecraft:mossy_cobblestone
fill 377 -2 189 377 -1 189 minecraft:mossy_cobblestone
fill 377 -2 199 377 -2 200 minecraft:mossy_cobblestone
setblock 377 -2 201 minecraft:stone_bricks
fill 377 -2 202 377 -2 205 minecraft:mossy_cobblestone
setblock 377 -2 206 minecraft:stone_bricks
fill 377 -2 207 377 1 207 minecraft:mossy_cobblestone
setblock 377 -2 211 minecraft:stone_bricks
fill 377 -2 212 377 1 212 minecraft:mossy_cobblestone
setblock 377 -2 216 minecraft:stone_bricks
fill 377 -2 217 377 1 217 minecraft:mossy_cobblestone
setblock 377 -2 221 minecraft:stone_bricks
fill 377 -2 222 377 0 222 minecraft:mossy_cobblestone
setblock 378 -2 185 minecraft:stone_bricks
setblock 378 -2 186 minecraft:mossy_cobblestone
fill 378 -2 201 378 0 201 minecraft:mossy_cobblestone
setblock 378 -2 205 minecraft:stone_bricks
fill 378 -2 206 378 1 206 minecraft:mossy_cobblestone
setblock 378 -2 210 minecraft:stone_bricks
fill 378 -2 211 378 1 211 minecraft:mossy_cobblestone
setblock 378 -2 215 minecraft:stone_bricks
setblock 379 -2 183 minecraft:mossy_cobblestone
setblock 379 -2 204 minecraft:stone_bricks
fill 379 -2 205 379 1 205 minecraft:mossy_cobblestone
setblock 379 -2 208 minecraft:mossy_cobblestone
setblock 379 -2 209 minecraft:stone_bricks
fill 379 -2 210 379 1 210 minecraft:mossy_cobblestone
setblock 380 -2 183 minecraft:stone_bricks
fill 380 -2 204 380 -1 204 minecraft:mossy_cobblestone
fill 380 -2 206 380 -1 206 minecraft:mossy_cobblestone
setblock 380 -2 208 minecraft:stone_bricks
fill 380 -2 209 380 1 209 minecraft:mossy_cobblestone
setblock 381 -2 182 minecraft:stone_bricks
fill 381 -2 183 381 -1 183 minecraft:mossy_cobblestone
setblock 381 -2 222 minecraft:stone_bricks
fill 382 -2 182 382 0 182 minecraft:mossy_cobblestone
fill 382 -2 222 382 -1 222 minecraft:mossy_cobblestone
setblock 385 -2 183 minecraft:stone_bricks
setblock 386 -2 182 minecraft:stone_bricks
fill 387 -2 182 388 -2 182 minecraft:mossy_cobblestone
setblock 395 -2 183 minecraft:stone_bricks
setblock 396 -2 182 minecraft:stone_bricks
fill 396 -2 183 396 1 183 minecraft:mossy_cobblestone
fill 397 -2 182 397 1 182 minecraft:mossy_cobblestone
setblock 399 -2 184 minecraft:stone_bricks
fill 399 -2 185 402 -2 185 minecraft:mossy_cobblestone
setblock 400 -2 183 minecraft:stone_bricks
fill 400 -2 184 400 1 184 minecraft:mossy_cobblestone
setblock 401 -2 182 minecraft:stone_bricks
fill 401 -2 183 401 1 183 minecraft:mossy_cobblestone
setblock 401 -2 222 minecraft:stone_bricks
fill 402 -2 182 402 1 182 minecraft:mossy_cobblestone
fill 402 -2 222 402 1 222 minecraft:mossy_cobblestone
setblock 403 -2 185 minecraft:stone_bricks
setblock 404 -2 184 minecraft:stone_bricks
fill 404 -2 185 404 -1 185 minecraft:mossy_cobblestone
setblock 405 -2 183 minecraft:stone_bricks
fill 405 -2 184 405 0 184 minecraft:mossy_cobblestone
setblock 406 -2 182 minecraft:stone_bricks
fill 406 -2 183 406 1 183 minecraft:mossy_cobblestone
setblock 406 -2 222 minecraft:stone_bricks
fill 407 -2 182 407 1 182 minecraft:mossy_cobblestone
fill 407 -2 222 407 -1 222 minecraft:mossy_cobblestone
setblock 410 -2 183 minecraft:stone_bricks
setblock 411 -2 182 minecraft:stone_bricks
setblock 411 -2 183 minecraft:mossy_cobblestone
setblock 411 -2 222 minecraft:stone_bricks
fill 412 -2 182 412 0 182 minecraft:mossy_cobblestone
setblock 412 -2 222 minecraft:mossy_cobblestone
setblock 415 -2 183 minecraft:stone_bricks
setblock 416 -2 182 minecraft:stone_bricks
fill 416 -2 183 416 -1 183 minecraft:mossy_cobblestone
setblock 416 -2 207 minecraft:stone_bricks
fill 416 -2 208 417 -2 210 minecraft:mossy_cobblestone
setblock 416 -2 222 minecraft:stone_bricks
fill 417 -2 182 417 1 182 minecraft:mossy_cobblestone
setblock 417 -2 186 minecraft:stone_bricks
fill 417 -2 187 417 1 187 minecraft:mossy_cobblestone
setblock 417 -2 202 minecraft:mossy_cobblestone
setblock 417 -2 206 minecraft:stone_bricks
fill 417 -2 207 417 1 207 minecraft:mossy_cobblestone
setblock 417 -2 211 minecraft:stone_bricks
fill 417 -2 212 417 1 212 minecraft:mossy_cobblestone
setblock 417 -2 216 minecraft:stone_bricks
fill 417 -2 217 417 1 217 minecraft:mossy_cobblestone
setblock 417 -2 221 minecraft:stone_bricks
fill 417 -2 222 417 1 222 minecraft:mossy_cobblestone
setblock 377 -1 185 minecraft:stone_bricks
fill 377 -1 186 377 2 186 minecraft:mossy_cobblestone
setblock 377 -1 190 minecraft:stone_bricks
setblock 377 -1 200 minecraft:stone_bricks
fill 377 -1 201 377 -1 204 minecraft:mossy_cobblestone
setblock 377 -1 205 minecraft:stone_bricks
fill 377 -1 206 377 2 206 minecraft:mossy_cobblestone
setblock 377 -1 210 minecraft:stone_bricks
fill 377 -1 211 377 2 211 minecraft:mossy_cobblestone
setblock 377 -1 215 minecraft:stone_bricks
fill 377 -1 216 377 2 216 minecraft:mossy_cobblestone
setblock 377 -1 220 minecraft:stone_bricks
setblock 377 -1 221 minecraft:mossy_cobblestone
setblock 378 -1 204 minecraft:stone_bricks
fill 378 -1 205 378 2 205 minecraft:mossy_cobblestone
setblock 378 -1 209 minecraft:stone_bricks
fill 378 -1 210 378 2 210 minecraft:mossy_cobblestone
setblock 378 -1 214 minecraft:stone_bricks
fill 378 -1 215 378 2 215 minecraft:mossy_cobblestone
setblock 379 -1 203 minecraft:stone_bricks
fill 379 -1 204 379 2 204 minecraft:mossy_cobblestone
setblock 379 -1 208 minecraft:stone_bricks
fill 379 -1 209 379 2 209 minecraft:mossy_cobblestone
setblock 379 -1 213 minecraft:stone_bricks
setblock 380 -1 182 minecraft:stone_bricks
setblock 380 -1 183 minecraft:mossy_cobblestone
setblock 380 -1 207 minecraft:stone_bricks
fill 380 -1 208 380 2 208 minecraft:mossy_cobblestone
setblock 380 -1 222 minecraft:stone_bricks
fill 381 -1 182 381 1 182 minecraft:mossy_cobblestone
fill 381 -1 222 381 0 222 minecraft:mossy_cobblestone
setblock 385 -1 182 minecraft:stone_bricks
setblock 386 -1 182 minecraft:mossy_cobblestone
setblock 395 -1 182 minecraft:stone_bricks
setblock 395 -1 183 minecraft:mossy_cobblestone
fill 396 -1 182 396 2 182 minecraft:mossy_cobblestone
setblock 398 -1 184 minecraft:stone_bricks
setblock 399 -1 183 minecraft:stone_bricks
fill 399 -1 184 399 1 185 minecraft:mossy_cobblestone
setblock 400 -1 182 minecraft:stone_bricks
fill 400 -1 183 400 2 183 minecraft:mossy_cobblestone
fill 400 -1 185 401 -1 185 minecraft:mossy_cobblestone
setblock 400 -1 222 minecraft:stone_bricks
fill 401 -1 182 401 2 182 minecraft:mossy_cobblestone
fill 401 -1 222 401 2 222 minecraft:mossy_cobblestone
setblock 402 -1 185 minecraft:stone_bricks
setblock 403 -1 184 minecraft:stone_bricks
fill 403 -1 185 403 0 185 minecraft:mossy_cobblestone
setblock 404 -1 183 minecraft:stone_bricks
fill 404 -1 184 404 1 184 minecraft:mossy_cobblestone
setblock 405 -1 182 minecraft:stone_bricks
fill 405 -1 183 405 2 183 minecraft:mossy_cobblestone
setblock 405 -1 222 minecraft:stone_bricks
fill 406 -1 182 406 2 182 minecraft:mossy_cobblestone
fill 406 -1 222 406 0 222 minecraft:mossy_cobblestone
setblock 409 -1 183 minecraft:stone_bricks
setblock 410 -1 182 minecraft:stone_bricks
setblock 410 -1 183 minecraft:mossy_cobblestone
fill 411 -1 182 411 0 182 minecraft:mossy_cobblestone
setblock 415 -1 182 minecraft:stone_bricks
setblock 415 -1 222 minecraft:stone_bricks
fill 416 -1 182 416 2 182 minecraft:mossy_cobblestone
fill 416 -1 207 416 -1 210 minecraft:mossy_cobblestone
setblock 416 -1 211 minecraft:stone_bricks
fill 416 -1 222 416 2 222 minecraft:mossy_cobblestone
setblock 417 -1 185 minecraft:stone_bricks
fill 417 -1 186 417 2 186 minecraft:mossy_cobblestone
setblock 417 -1 205 minecraft:stone_bricks
fill 417 -1 206 417 2 206 minecraft:mossy_cobblestone
fill 417 -1 208 417 -1 209 minecraft:mossy_cobblestone
setblock 417 -1 210 minecraft:stone_bricks
fill 417 -1 211 417 2 211 minecraft:mossy_cobblestone
setblock 417 -1 215 minecraft:stone_bricks
fill 417 -1 216 417 2 216 minecraft:mossy_cobblestone
setblock 417 -1 220 minecraft:stone_bricks
fill 417 -1 221 417 2 221 minecraft:mossy_cobblestone
setblock 377 0 184 minecraft:stone_bricks
fill 377 0 185 377 3 185 minecraft:mossy_cobblestone
setblock 377 0 189 minecraft:stone_bricks
fill 377 0 190 377 2 191 minecraft:mossy_cobblestone
fill 377 0 200 377 0 203 minecraft:mossy_cobblestone
setblock 377 0 204 minecraft:stone_bricks
fill 377 0 205 377 3 205 minecraft:mossy_cobblestone
setblock 377 0 209 minecraft:stone_bricks
fill 377 0 210 377 3 210 minecraft:mossy_cobblestone
setblock 377 0 214 minecraft:stone_bricks
fill 377 0 215 377 3 215 minecraft:mossy_cobblestone
setblock 377 0 219 minecraft:stone_bricks
setblock 378 0 203 minecraft:stone_bricks
fill 378 0 204 378 3 204 minecraft:mossy_cobblestone
setblock 378 0 208 minecraft:stone_bricks
fill 378 0 209 378 3 209 minecraft:mossy_cobblestone
setblock 378 0 213 minecraft:stone_bricks
fill 378 0 214 378 3 214 minecraft:mossy_cobblestone
setblock 379 0 182 minecraft:stone_bricks
setblock 379 0 203 minecraft:mossy_cobblestone
setblock 379 0 207 minecraft:stone_bricks
fill 379 0 208 379 3 208 minecraft:mossy_cobblestone
setblock 379 0 212 minecraft:stone_bricks
fill 379 0 213 379 3 213 minecraft:mossy_cobblestone
setblock 379 0 222 minecraft:stone_bricks
fill 380 0 182 380 1 182 minecraft:mossy_cobblestone
setblock 380 0 206 minecraft:stone_bricks
fill 380 0 207 380 2 207 minecraft:mossy_cobblestone
setblock 380 0 222 minecraft:mossy_cobblestone
setblock 384 0 182 minecraft:stone_bricks
setblock 394 0 182 minecraft:stone_bricks
fill 395 0 182 395 3 182 minecraft:mossy_cobblestone
setblock 397 0 184 minecraft:stone_bricks
setblock 398 0 183 minecraft:stone_bricks
fill 398 0 184 398 3 184 minecraft:mossy_cobblestone
setblock 399 0 182 minecraft:stone_bricks
fill 399 0 183 399 3 183 minecraft:mossy_cobblestone
setblock 399 0 222 minecraft:stone_bricks
fill 400 0 182 400 3 182 minecraft:mossy_cobblestone
setblock 400 0 185 minecraft:mossy_cobblestone
fill 400 0 222 400 3 222 minecraft:mossy_cobblestone
setblock 401 0 185 minecraft:stone_bricks
setblock 402 0 184 minecraft:stone_bricks
fill 402 0 185 402 1 185 minecraft:mossy_cobblestone
setblock 403 0 183 minecraft:stone_bricks
fill 403 0 184 403 2 184 minecraft:mossy_cobblestone
setblock 404 0 182 minecraft:stone_bricks
fill 404 0 183 404 3 183 minecraft:mossy_cobblestone
setblock 404 0 222 minecraft:stone_bricks
fill 405 0 182 405 3 182 minecraft:mossy_cobblestone
setblock 405 0 222 minecraft:mossy_cobblestone
setblock 408 0 183 minecraft:stone_bricks
setblock 409 0 182 minecraft:stone_bricks
setblock 410 0 182 minecraft:mossy_cobblestone
setblock 414 0 182 minecraft:stone_bricks
fill 415 0 182 415 3 182 minecraft:mossy_cobblestone
fill 415 0 222 415 3 222 minecraft:mossy_cobblestone
fill 416 0 207 416 0 209 minecraft:mossy_cobblestone
setblock 416 0 210 minecraft:stone_bricks
fill 416 0 211 416 1 213 minecraft:mossy_cobblestone
setblock 417 0 184 minecraft:stone_bricks
fill 417 0 185 417 3 185 minecraft:mossy_cobblestone
setblock 417 0 188 minecraft:mossy_cobblestone
setblock 417 0 189 minecraft:stone_bricks
fill 417 0 190 417 3 190 minecraft:mossy_cobblestone
setblock 417 0 204 minecraft:stone_bricks
fill 417 0 205 417 3 205 minecraft:mossy_cobblestone
setblock 417 0 208 minecraft:mossy_cobblestone
setblock 417 0 209 minecraft:stone_bricks
fill 417 0 210 417 3 210 minecraft:mossy_cobblestone
setblock 417 0 214 minecraft:stone_bricks
fill 417 0 215 417 3 215 minecraft:mossy_cobblestone
setblock 417 0 219 minecraft:stone_bricks
fill 417 0 220 417 3 220 minecraft:mossy_cobblestone
setblock 377 1 183 minecraft:stone_bricks
fill 377 1 184 377 4 184 minecraft:mossy_cobblestone
setblock 377 1 188 minecraft:stone_bricks
fill 377 1 189 378 3 189 minecraft:mossy_cobblestone
setblock 377 1 192 minecraft:mossy_cobblestone
setblock 377 1 193 minecraft:stone_bricks
fill 377 1 200 377 1 202 minecraft:mossy_cobblestone
setblock 377 1 203 minecraft:stone_bricks
fill 377 1 204 377 4 204 minecraft:mossy_cobblestone
setblock 377 1 208 minecraft:stone_bricks
fill 377 1 209 377 4 209 minecraft:mossy_cobblestone
setblock 377 1 213 minecraft:stone_bricks
fill 377 1 214 377 4 214 minecraft:mossy_cobblestone
setblock 377 1 218 minecraft:stone_bricks
setblock 378 1 182 minecraft:stone_bricks
setblock 378 1 187 minecraft:stone_bricks
fill 378 1 188 378 4 188 minecraft:mossy_cobblestone
setblock 378 1 202 minecraft:stone_bricks
fill 378 1 203 378 4 203 minecraft:mossy_cobblestone
setblock 378 1 207 minecraft:stone_bricks
fill 378 1 208 378 4 208 minecraft:mossy_cobblestone
setblock 378 1 212 minecraft:stone_bricks
fill 378 1 213 378 4 213 minecraft:mossy_cobblestone
setblock 379 1 182 minecraft:mossy_cobblestone
setblock 379 1 184 minecraft:light[level=12]
setblock 379 1 192 minecraft:light[level=12]
setblock 379 1 200 minecraft:light[level=12]
setblock 379 1 206 minecraft:stone_bricks
fill 379 1 207 379 4 207 minecraft:mossy_cobblestone
setblock 379 1 211 minecraft:stone_bricks
fill 379 1 212 379 4 212 minecraft:mossy_cobblestone
setblock 379 1 216 minecraft:light[level=12]
setblock 380 1 206 minecraft:mossy_cobblestone
setblock 380 1 210 minecraft:stone_bricks
setblock 387 1 184 minecraft:light[level=12]
setblock 387 1 192 minecraft:light[level=12]
setblock 387 1 200 minecraft:light[level=12]
setblock 387 1 208 minecraft:light[level=12]
setblock 387 1 216 minecraft:light[level=12]
fill 394 1 182 394 4 182 minecraft:mossy_cobblestone
setblock 395 1 184 minecraft:light[level=12]
setblock 395 1 192 minecraft:light[level=12]
setblock 395 1 200 minecraft:light[level=12]
setblock 395 1 208 minecraft:light[level=12]
setblock 395 1 216 minecraft:light[level=12]
setblock 397 1 183 minecraft:stone_bricks
fill 397 1 184 397 4 184 minecraft:mossy_cobblestone
setblock 398 1 182 minecraft:stone_bricks
fill 398 1 183 398 4 183 minecraft:mossy_cobblestone
fill 399 1 182 399 4 182 minecraft:mossy_cobblestone
fill 399 1 222 399 4 222 minecraft:mossy_cobblestone
setblock 400 1 185 minecraft:stone_bricks
setblock 401 1 184 minecraft:stone_bricks
setblock 401 1 185 minecraft:mossy_cobblestone
setblock 402 1 183 minecraft:stone_bricks
fill 402 1 184 402 3 184 minecraft:mossy_cobblestone
setblock 403 1 182 minecraft:stone_bricks
fill 403 1 183 403 4 183 minecraft:mossy_cobblestone
setblock 403 1 192 minecraft:light[level=12]
setblock 403 1 200 minecraft:light[level=12]
setblock 403 1 208 minecraft:light[level=12]
setblock 403 1 216 minecraft:light[level=12]
setblock 403 1 222 minecraft:stone_bricks
fill 404 1 182 404 4 182 minecraft:mossy_cobblestone
setblock 404 1 222 minecraft:mossy_cobblestone
setblock 408 1 182 minecraft:stone_bricks
setblock 409 1 182 minecraft:mossy_cobblestone
setblock 411 1 184 minecraft:light[level=12]
setblock 411 1 192 minecraft:light[level=12]
setblock 411 1 200 minecraft:light[level=12]
setblock 411 1 208 minecraft:light[level=12]
setblock 411 1 216 minecraft:light[level=12]
setblock 414 1 182 minecraft:mossy_cobblestone
fill 416 1 207 416 1 208 minecraft:mossy_cobblestone
setblock 416 1 209 minecraft:stone_bricks
fill 416 1 210 416 4 210 minecraft:mossy_cobblestone
setblock 416 1 214 minecraft:stone_bricks
setblock 417 1 183 minecraft:stone_bricks
fill 417 1 184 417 4 184 minecraft:mossy_cobblestone
setblock 417 1 188 minecraft:stone_bricks
fill 417 1 189 417 4 189 minecraft:mossy_cobblestone
setblock 417 1 203 minecraft:stone_bricks
fill 417 1 204 417 4 204 minecraft:mossy_cobblestone
setblock 417 1 208 minecraft:stone_bricks
fill 417 1 209 417 4 209 minecraft:mossy_cobblestone
setblock 417 1 213 minecraft:stone_bricks
fill 417 1 214 417 4 214 minecraft:mossy_cobblestone
setblock 417 1 218 minecraft:stone_bricks
fill 417 1 219 417 4 219 minecraft:mossy_cobblestone
setblock 377 2 187 minecraft:stone_bricks
fill 377 2 188 377 5 188 minecraft:mossy_cobblestone
setblock 377 2 192 minecraft:stone_bricks
fill 377 2 193 377 2 196 minecraft:mossy_cobblestone
fill 377 2 198 377 2 201 minecraft:mossy_cobblestone
setblock 377 2 202 minecraft:stone_bricks
fill 377 2 203 377 5 203 minecraft:mossy_cobblestone
setblock 377 2 207 minecraft:stone_bricks
fill 377 2 208 377 5 208 minecraft:mossy_cobblestone
setblock 377 2 212 minecraft:stone_bricks
fill 377 2 213 377 5 213 minecraft:mossy_cobblestone
setblock 377 2 217 minecraft:stone_bricks
fill 377 2 218 377 4 219 minecraft:mossy_cobblestone
fill 378 2 187 378 5 187 minecraft:mossy_cobblestone
setblock 378 2 190 minecraft:mossy_cobblestone
setblock 378 2 191 minecraft:stone_bricks
fill 378 2 202 378 5 202 minecraft:mossy_cobblestone
setblock 378 2 206 minecraft:stone_bricks
fill 378 2 207 378 5 207 minecraft:mossy_cobblestone
setblock 378 2 211 minecraft:stone_bricks
fill 378 2 212 378 5 212 minecraft:mossy_cobblestone
setblock 378 2 216 minecraft:stone_bricks
fill 379 2 203 386 3 203 minecraft:stone_bricks
setblock 379 2 205 minecraft:stone_bricks
fill 379 2 206 379 5 206 minecraft:mossy_cobblestone
setblock 379 2 210 minecraft:stone_bricks
fill 379 2 211 379 5 211 minecraft:mossy_cobblestone
setblock 379 2 214 minecraft:mossy_cobblestone
fill 380 2 204 380 3 204 minecraft:stone_bricks
setblock 380 2 209 minecraft:stone_bricks
fill 380 2 210 380 5 210 minecraft:mossy_cobblestone
setblock 395 2 183 minecraft:mossy_cobblestone
setblock 396 2 183 minecraft:stone_bricks
setblock 397 2 182 minecraft:stone_bricks
fill 397 2 183 397 5 183 minecraft:mossy_cobblestone
fill 398 2 182 398 5 182 minecraft:mossy_cobblestone
setblock 399 2 184 minecraft:mossy_cobblestone
setblock 400 2 184 minecraft:stone_bricks
setblock 400 2 185 minecraft:mossy_cobblestone
setblock 401 2 183 minecraft:stone_bricks
fill 401 2 184 401 5 184 minecraft:mossy_cobblestone
setblock 402 2 182 minecraft:stone_bricks
fill 402 2 183 402 5 183 minecraft:mossy_cobblestone
setblock 402 2 222 minecraft:stone_bricks
fill 403 2 182 403 5 182 minecraft:mossy_cobblestone
fill 403 2 222 403 5 222 minecraft:mossy_cobblestone
setblock 407 2 182 minecraft:stone_bricks
fill 416 2 206 416 2 207 minecraft:mossy_cobblestone
setblock 416 2 208 minecraft:stone_bricks
fill 416 2 209 416 5 209 minecraft:mossy_cobblestone
fill 416 2 211 416 2 212 minecraft:mossy_cobblestone
setblock 416 2 213 minecraft:stone_bricks
fill 416 2 214 416 3 216 minecraft:mossy_cobblestone
setblock 417 2 182 minecraft:stone_bricks
fill 417 2 183 417 5 183 minecraft:mossy_cobblestone
setblock 417 2 187 minecraft:stone_bricks
fill 417 2 188 417 5 188 minecraft:mossy_cobblestone
setblock 417 2 191 minecraft:mossy_cobblestone
setblock 417 2 192 minecraft:stone_bricks
fill 417 2 203 417 5 203 minecraft:mossy_cobblestone
setblock 417 2 207 minecraft:stone_bricks
fill 417 2 208 417 5 208 minecraft:mossy_cobblestone
setblock 417 2 212 minecraft:stone_bricks
fill 417 2 213 417 5 213 minecraft:mossy_cobblestone
setblock 417 2 217 minecraft:stone_bricks
fill 417 2 218 417 5 218 minecraft:mossy_cobblestone
setblock 417 2 222 minecraft:stone_bricks
setblock 377 3 186 minecraft:stone_bricks
fill 377 3 187 377 6 187 minecraft:mossy_cobblestone
setblock 377 3 190 minecraft:mossy_cobblestone
setblock 377 3 191 minecraft:stone_bricks
fill 377 3 192 377 3 195 minecraft:mossy_cobblestone
setblock 377 3 196 minecraft:stone_bricks
fill 377 3 197 377 3 200 minecraft:mossy_cobblestone
setblock 377 3 201 minecraft:stone_bricks
fill 377 3 202 377 6 202 minecraft:mossy_cobblestone
setblock 377 3 206 minecraft:stone_bricks
fill 377 3 207 377 6 207 minecraft:mossy_cobblestone
setblock 377 3 211 minecraft:stone_bricks
fill 377 3 212 377 6 212 minecraft:mossy_cobblestone
setblock 377 3 216 minecraft:stone_bricks
fill 377 3 217 378 5 217 minecraft:mossy_cobblestone
setblock 377 3 220 minecraft:mossy_cobblestone
fill 378 3 186 378 6 186 minecraft:mossy_cobblestone
setblock 378 3 190 minecraft:stone_bricks
fill 378 3 191 378 3 194 minecraft:mossy_cobblestone
fill 378 3 201 378 6 201 minecraft:mossy_cobblestone
setblock 378 3 205 minecraft:stone_bricks
fill 378 3 206 378 6 206 minecraft:mossy_cobblestone
setblock 378 3 210 minecraft:stone_bricks
fill 378 3 211 378 6 211 minecraft:mossy_cobblestone
setblock 378 3 215 minecraft:stone_bricks
fill 378 3 216 378 6 216 minecraft:mossy_cobblestone
setblock 379 3 204 minecraft:stone_bricks
fill 379 3 205 379 6 205 minecraft:mossy_cobblestone
setblock 379 3 209 minecraft:stone_bricks
fill 379 3 210 379 6 210 minecraft:mossy_cobblestone
setblock 379 3 214 minecraft:stone_bricks
setblock 380 3 208 minecraft:stone_bricks
fill 380 3 209 380 5 209 minecraft:mossy_cobblestone
fill 380 3 211 380 4 211 minecraft:mossy_cobblestone
fill 381 3 204 384 3 204 minecraft:stone_bricks
fill 385 3 202 397 3 202 minecraft:stone_bricks
fill 387 3 203 395 4 203 minecraft:stone_bricks
setblock 395 3 183 minecraft:stone_bricks
setblock 396 3 182 minecraft:stone_bricks
fill 396 3 183 396 6 183 minecraft:mossy_cobblestone
fill 397 3 182 397 6 182 minecraft:mossy_cobblestone
setblock 399 3 184 minecraft:stone_bricks
setblock 400 3 183 minecraft:stone_bricks
fill 400 3 184 400 6 184 minecraft:mossy_cobblestone
fill 400 3 202 405 4 202 minecraft:stone_bricks
setblock 401 3 182 minecraft:stone_bricks
fill 401 3 183 401 6 183 minecraft:mossy_cobblestone
setblock 401 3 222 minecraft:stone_bricks
fill 402 3 182 402 6 182 minecraft:mossy_cobblestone
fill 402 3 222 402 6 222 minecraft:mossy_cobblestone
setblock 406 3 182 minecraft:stone_bricks
fill 414 3 222 414 4 222 minecraft:mossy_cobblestone
fill 415 3 210 415 3 212 minecraft:mossy_cobblestone
setblock 416 3 182 minecraft:stone_bricks
setblock 416 3 206 minecraft:mossy_cobblestone
setblock 416 3 207 minecraft:stone_bricks
fill 416 3 208 416 6 208 minecraft:mossy_cobblestone
setblock 416 3 211 minecraft:mossy_cobblestone
setblock 416 3 212 minecraft:stone_bricks
fill 416 3 213 416 6 213 minecraft:mossy_cobblestone
setblock 416 3 217 minecraft:stone_bricks
fill 416 3 218 416 6 218 minecraft:mossy_cobblestone
setblock 416 3 222 minecraft:stone_bricks
fill 417 3 182 417 6 182 minecraft:mossy_cobblestone
setblock 417 3 186 minecraft:stone_bricks
fill 417 3 187 417 6 187 minecraft:mossy_cobblestone
setblock 417 3 191 minecraft:stone_bricks
fill 417 3 192 417 5 193 minecraft:mossy_cobblestone
setblock 417 3 206 minecraft:stone_bricks
fill 417 3 207 417 6 207 minecraft:mossy_cobblestone
setblock 417 3 211 minecraft:stone_bricks
fill 417 3 212 417 6 212 minecraft:mossy_cobblestone
setblock 417 3 216 minecraft:stone_bricks
fill 417 3 217 417 6 217 minecraft:mossy_cobblestone
setblock 417 3 221 minecraft:stone_bricks
fill 417 3 222 417 6 222 minecraft:mossy_cobblestone
setblock 377 4 185 minecraft:stone_bricks
fill 377 4 186 377 7 186 minecraft:mossy_cobblestone
setblock 377 4 189 minecraft:mossy_cobblestone
setblock 377 4 190 minecraft:stone_bricks
fill 377 4 191 377 4 194 minecraft:mossy_cobblestone
setblock 377 4 195 minecraft:stone_bricks
fill 377 4 196 377 4 199 minecraft:mossy_cobblestone
setblock 377 4 200 minecraft:stone_bricks
fill 377 4 201 377 7 201 minecraft:mossy_cobblestone
setblock 377 4 205 minecraft:stone_bricks
fill 377 4 206 377 7 206 minecraft:mossy_cobblestone
setblock 377 4 210 minecraft:stone_bricks
fill 377 4 211 377 7 211 minecraft:mossy_cobblestone
setblock 377 4 215 minecraft:stone_bricks
fill 377 4 216 377 7 216 minecraft:mossy_cobblestone
setblock 377 4 220 minecraft:stone_bricks
fill 377 4 221 377 7 221 minecraft:mossy_cobblestone
setblock 378 4 189 minecraft:stone_bricks
fill 378 4 190 378 4 193 minecraft:mossy_cobblestone
setblock 378 4 194 minecraft:stone_bricks
fill 378 4 195 378 4 198 minecraft:mossy_cobblestone
setblock 378 4 199 minecraft:stone_bricks
fill 378 4 200 378 7 200 minecraft:mossy_cobblestone
setblock 378 4 204 minecraft:stone_bricks
fill 378 4 205 378 7 205 minecraft:mossy_cobblestone
setblock 378 4 209 minecraft:stone_bricks
fill 378 4 210 378 7 210 minecraft:mossy_cobblestone
setblock 378 4 214 minecraft:stone_bricks
fill 378 4 215 379 6 215 minecraft:mossy_cobblestone
fill 379 4 190 379 4 192 minecraft:mossy_cobblestone
fill 379 4 203 386 4 203 minecraft:spruce_planks
fill 379 4 204 379 5 204 minecraft:mossy_cobblestone
setblock 379 4 208 minecraft:stone_bricks
fill 379 4 209 379 7 209 minecraft:mossy_cobblestone
setblock 379 4 213 minecraft:stone_bricks
fill 379 4 214 379 7 214 minecraft:mossy_cobblestone
fill 391 4 202 397 4 202 minecraft:stone_bricks
fill 393 4 182 393 5 182 minecraft:mossy_cobblestone
setblock 395 4 182 minecraft:stone_bricks
fill 395 4 183 395 7 183 minecraft:mossy_cobblestone
fill 396 4 182 396 7 182 minecraft:mossy_cobblestone
fill 396 4 184 396 5 184 minecraft:mossy_cobblestone
setblock 398 4 184 minecraft:stone_bricks
fill 398 4 222 398 5 222 minecraft:mossy_cobblestone
setblock 399 4 183 minecraft:stone_bricks
fill 399 4 184 399 7 184 minecraft:mossy_cobblestone
setblock 400 4 182 minecraft:stone_bricks
fill 400 4 183 400 7 183 minecraft:mossy_cobblestone
setblock 400 4 222 minecraft:stone_bricks
fill 401 4 182 401 7 182 minecraft:mossy_cobblestone
fill 401 4 201 417 4 201 minecraft:stone_bricks
fill 401 4 222 401 7 222 minecraft:mossy_cobblestone
setblock 405 4 182 minecraft:stone_bricks
fill 406 4 202 414 4 202 minecraft:stone_bricks
fill 413 4 222 413 5 222 minecraft:mossy_cobblestone
setblock 415 4 182 minecraft:stone_bricks
fill 415 4 209 415 4 211 minecraft:mossy_cobblestone
setblock 415 4 212 minecraft:stone_bricks
fill 415 4 213 415 5 215 minecraft:mossy_cobblestone
setblock 415 4 222 minecraft:stone_bricks
fill 416 4 182 416 7 182 minecraft:mossy_cobblestone
fill 416 4 187 416 4 190 minecraft:mossy_cobblestone
setblock 416 4 206 minecraft:stone_bricks
fill 416 4 207 416 7 207 minecraft:mossy_cobblestone
setblock 416 4 211 minecraft:stone_bricks
fill 416 4 212 416 7 212 minecraft:mossy_cobblestone
fill 416 4 214 416 4 215 minecraft:mossy_cobblestone
setblock 416 4 216 minecraft:stone_bricks
fill 416 4 217 416 7 217 minecraft:mossy_cobblestone
fill 416 4 219 416 4 220 minecraft:mossy_cobblestone
fill 416 4 222 416 7 222 minecraft:mossy_cobblestone
setblock 417 4 185 minecraft:stone_bricks
fill 417 4 186 417 7 186 minecraft:mossy_cobblestone
setblock 417 4 190 minecraft:stone_bricks
fill 417 4 191 417 7 191 minecraft:mossy_cobblestone
setblock 417 4 194 minecraft:mossy_cobblestone
setblock 417 4 195 minecraft:stone_bricks
fill 417 4 202 417 6 202 minecraft:mossy_cobblestone
setblock 417 4 205 minecraft:stone_bricks
fill 417 4 206 417 7 206 minecraft:mossy_cobblestone
setblock 417 4 210 minecraft:stone_bricks
fill 417 4 211 417 7 211 minecraft:mossy_cobblestone
setblock 417 4 215 minecraft:stone_bricks
fill 417 4 216 417 7 216 minecraft:mossy_cobblestone
setblock 417 4 220 minecraft:stone_bricks
fill 417 4 221 417 7 221 minecraft:mossy_cobblestone
setblock 377 5 183 minecraft:mossy_cobblestone
setblock 377 5 184 minecraft:stone_bricks
fill 377 5 185 377 8 185 minecraft:mossy_cobblestone
setblock 377 5 189 minecraft:stone_bricks
fill 377 5 190 377 5 193 minecraft:mossy_cobblestone
setblock 377 5 194 minecraft:stone_bricks
fill 377 5 195 377 5 198 minecraft:mossy_cobblestone
setblock 377 5 199 minecraft:stone_bricks
fill 377 5 200 377 8 200 minecraft:mossy_cobblestone
setblock 377 5 204 minecraft:stone_bricks
fill 377 5 205 377 8 205 minecraft:mossy_cobblestone
setblock 377 5 209 minecraft:stone_bricks
fill 377 5 210 377 8 210 minecraft:mossy_cobblestone
setblock 377 5 214 minecraft:stone_bricks
fill 377 5 215 377 8 215 minecraft:mossy_cobblestone
setblock 377 5 218 minecraft:mossy_cobblestone
setblock 377 5 219 minecraft:stone_bricks
fill 377 5 220 377 8 220 minecraft:mossy_cobblestone
fill 377 5 222 377 6 222 minecraft:mossy_cobblestone
setblock 378 5 188 minecraft:stone_bricks
fill 378 5 189 378 5 192 minecraft:mossy_cobblestone
setblock 378 5 193 minecraft:stone_bricks
fill 378 5 194 378 5 197 minecraft:mossy_cobblestone
setblock 378 5 198 minecraft:stone_bricks
fill 378 5 199 378 8 199 minecraft:mossy_cobblestone
setblock 378 5 203 minecraft:stone_bricks
fill 378 5 204 378 8 204 minecraft:mossy_cobblestone
setblock 378 5 208 minecraft:stone_bricks
fill 378 5 209 378 8 209 minecraft:mossy_cobblestone
setblock 378 5 213 minecraft:stone_bricks
fill 378 5 214 378 8 214 minecraft:mossy_cobblestone
setblock 378 5 218 minecraft:stone_bricks
fill 379 5 189 379 5 191 minecraft:mossy_cobblestone
setblock 379 5 192 minecraft:stone_bricks
fill 379 5 193 379 6 195 minecraft:mossy_cobblestone
setblock 379 5 207 minecraft:stone_bricks
fill 379 5 208 379 8 208 minecraft:mossy_cobblestone
setblock 379 5 212 minecraft:stone_bricks
fill 379 5 213 379 8 213 minecraft:mossy_cobblestone
setblock 380 5 211 minecraft:stone_bricks
fill 393 5 202 397 5 202 minecraft:spruce_planks
setblock 394 5 182 minecraft:stone_bricks
fill 394 5 183 394 8 183 minecraft:mossy_cobblestone
fill 395 5 182 395 8 182 minecraft:mossy_cobblestone
fill 396 5 222 397 6 222 minecraft:mossy_cobblestone
setblock 397 5 184 minecraft:stone_bricks
setblock 398 5 183 minecraft:stone_bricks
fill 398 5 184 398 8 184 minecraft:mossy_cobblestone
setblock 399 5 182 minecraft:stone_bricks
fill 399 5 183 399 8 183 minecraft:mossy_cobblestone
setblock 399 5 222 minecraft:stone_bricks
fill 400 5 182 400 8 182 minecraft:mossy_cobblestone
fill 400 5 202 406 5 202 minecraft:spruce_planks
fill 400 5 222 400 8 222 minecraft:mossy_cobblestone
setblock 403 5 183 minecraft:stone_bricks
setblock 404 5 182 minecraft:stone_bricks
fill 405 5 182 405 6 182 minecraft:mossy_cobblestone
fill 409 5 201 416 5 201 minecraft:stone_bricks
fill 412 5 222 412 6 222 minecraft:mossy_cobblestone
setblock 414 5 222 minecraft:stone_bricks
fill 415 5 182 415 8 182 minecraft:mossy_cobblestone
fill 415 5 208 415 5 210 minecraft:mossy_cobblestone
setblock 415 5 211 minecraft:stone_bricks
fill 415 5 212 415 8 212 minecraft:mossy_cobblestone
setblock 415 5 216 minecraft:stone_bricks
fill 415 5 217 415 8 217 minecraft:mossy_cobblestone
setblock 415 5 221 minecraft:stone_bricks
fill 415 5 222 415 8 222 minecraft:mossy_cobblestone
fill 416 5 186 416 5 189 minecraft:mossy_cobblestone
setblock 416 5 190 minecraft:stone_bricks
fill 416 5 191 416 7 192 minecraft:mossy_cobblestone
setblock 416 5 205 minecraft:stone_bricks
fill 416 5 206 416 8 206 minecraft:mossy_cobblestone
setblock 416 5 210 minecraft:stone_bricks
fill 416 5 211 416 8 211 minecraft:mossy_cobblestone
setblock 416 5 214 minecraft:mossy_cobblestone
setblock 416 5 215 minecraft:stone_bricks
fill 416 5 216 416 8 216 minecraft:mossy_cobblestone
setblock 416 5 219 minecraft:mossy_cobblestone
setblock 416 5 220 minecraft:stone_bricks
fill 416 5 221 416 8 221 minecraft:mossy_cobblestone
setblock 417 5 184 minecraft:stone_bricks
fill 417 5 185 417 8 185 minecraft:mossy_cobblestone
setblock 417 5 189 minecraft:stone_bricks
fill 417 5 190 417 8 190 minecraft:mossy_cobblestone
setblock 417 5 194 minecraft:stone_bricks
fill 417 5 195 417 5 198 minecraft:mossy_cobblestone
setblock 417 5 199 minecraft:stone_bricks
fill 417 5 200 417 7 201 minecraft:mossy_cobblestone
setblock 417 5 204 minecraft:stone_bricks
fill 417 5 205 417 8 205 minecraft:mossy_cobblestone
setblock 417 5 209 minecraft:stone_bricks
fill 417 5 210 417 8 210 minecraft:mossy_cobblestone
setblock 417 5 214 minecraft:stone_bricks
fill 417 5 215 417 8 215 minecraft:mossy_cobblestone
setblock 417 5 219 minecraft:stone_bricks
fill 417 5 220 417 8 220 minecraft:mossy_cobblestone
setblock 377 6 183 minecraft:stone_bricks
fill 377 6 184 377 9 184 minecraft:mossy_cobblestone
setblock 377 6 188 minecraft:stone_bricks
fill 377 6 189 377 6 192 minecraft:mossy_cobblestone
setblock 377 6 193 minecraft:stone_bricks
fill 377 6 194 377 6 197 minecraft:mossy_cobblestone
setblock 377 6 198 minecraft:stone_bricks
fill 377 6 199 377 9 199 minecraft:mossy_cobblestone
setblock 377 6 203 minecraft:stone_bricks
fill 377 6 204 377 9 204 minecraft:mossy_cobblestone
setblock 377 6 208 minecraft:stone_bricks
fill 377 6 209 377 9 209 minecraft:mossy_cobblestone
setblock 377 6 213 minecraft:stone_bricks
fill 377 6 214 377 9 214 minecraft:mossy_cobblestone
setblock 377 6 217 minecraft:mossy_cobblestone
setblock 377 6 218 minecraft:stone_bricks
fill 377 6 219 378 8 219 minecraft:mossy_cobblestone
setblock 378 6 187 minecraft:stone_bricks
fill 378 6 188 378 6 191 minecraft:mossy_cobblestone
setblock 378 6 192 minecraft:stone_bricks
fill 378 6 193 378 6 196 minecraft:mossy_cobblestone
setblock 378 6 197 minecraft:stone_bricks
fill 378 6 198 378 9 198 minecraft:mossy_cobblestone
setblock 378 6 202 minecraft:stone_bricks
fill 378 6 203 378 9 203 minecraft:mossy_cobblestone
setblock 378 6 207 minecraft:stone_bricks
fill 378 6 208 378 9 208 minecraft:mossy_cobblestone
setblock 378 6 212 minecraft:stone_bricks
fill 378 6 213 378 9 213 minecraft:mossy_cobblestone
setblock 378 6 217 minecraft:stone_bricks
fill 378 6 218 378 9 218 minecraft:mossy_cobblestone
setblock 378 6 222 minecraft:stone_bricks
fill 379 6 189 379 6 190 minecraft:mossy_cobblestone
setblock 379 6 191 minecraft:stone_bricks
fill 379 6 192 379 9 192 minecraft:mossy_cobblestone
setblock 379 6 196 minecraft:stone_bricks
fill 379 6 197 379 9 197 minecraft:mossy_cobblestone
setblock 379 6 206 minecraft:stone_bricks
fill 379 6 207 379 8 207 minecraft:mossy_cobblestone
setblock 379 6 211 minecraft:stone_bricks
fill 379 6 212 379 9 212 minecraft:mossy_cobblestone
setblock 379 6 216 minecraft:stone_bricks
setblock 380 6 211 minecraft:mossy_cobblestone
setblock 392 6 182 minecraft:mossy_cobblestone
setblock 393 6 182 minecraft:stone_bricks
fill 393 6 183 393 9 183 minecraft:mossy_cobblestone
fill 394 6 182 394 9 182 minecraft:mossy_cobblestone
setblock 395 6 184 minecraft:mossy_cobblestone
fill 395 6 222 395 8 222 minecraft:mossy_cobblestone
setblock 396 6 184 minecraft:stone_bricks
setblock 397 6 183 minecraft:stone_bricks
fill 397 6 184 397 9 184 minecraft:mossy_cobblestone
setblock 398 6 182 minecraft:stone_bricks
fill 398 6 183 398 9 183 minecraft:mossy_cobblestone
setblock 398 6 222 minecraft:stone_bricks
fill 399 6 182 399 9 182 minecraft:mossy_cobblestone
setblock 399 6 221 minecraft:stone_bricks
fill 399 6 222 399 9 222 minecraft:mossy_cobblestone
setblock 402 6 183 minecraft:stone_bricks
setblock 403 6 182 minecraft:stone_bricks
setblock 403 6 222 minecraft:stone_bricks
fill 404 6 182 404 8 182 minecraft:mossy_cobblestone
fill 404 6 222 404 9 222 minecraft:mossy_cobblestone
fill 410 6 222 411 7 222 minecraft:mossy_cobblestone
fill 411 6 201 416 6 201 minecraft:spruce_planks
setblock 413 6 221 minecraft:mossy_cobblestone
setblock 413 6 222 minecraft:stone_bricks
fill 414 6 182 414 9 182 minecraft:mossy_cobblestone
setblock 414 6 211 minecraft:stone_bricks
fill 414 6 212 414 6 215 minecraft:mossy_cobblestone
setblock 414 6 221 minecraft:stone_bricks
fill 414 6 222 414 9 222 minecraft:mossy_cobblestone
fill 415 6 208 415 6 209 minecraft:mossy_cobblestone
setblock 415 6 210 minecraft:stone_bricks
fill 415 6 211 415 9 211 minecraft:mossy_cobblestone
fill 415 6 213 415 6 214 minecraft:mossy_cobblestone
setblock 415 6 215 minecraft:stone_bricks
fill 415 6 216 415 9 216 minecraft:mossy_cobblestone
fill 415 6 218 415 6 219 minecraft:mossy_cobblestone
fill 415 6 221 415 9 221 minecraft:mossy_cobblestone
fill 416 6 186 416 6 188 minecraft:mossy_cobblestone
setblock 416 6 189 minecraft:stone_bricks
fill 416 6 190 416 9 190 minecraft:mossy_cobblestone
setblock 416 6 193 minecraft:mossy_cobblestone
setblock 416 6 194 minecraft:stone_bricks
fill 416 6 195 417 8 195 minecraft:mossy_cobblestone
setblock 416 6 204 minecraft:stone_bricks
fill 416 6 205 416 9 205 minecraft:mossy_cobblestone
setblock 416 6 209 minecraft:stone_bricks
fill 416 6 210 416 9 210 minecraft:mossy_cobblestone
setblock 416 6 214 minecraft:stone_bricks
fill 416 6 215 416 9 215 minecraft:mossy_cobblestone
setblock 416 6 219 minecraft:stone_bricks
fill 416 6 220 416 9 220 minecraft:mossy_cobblestone
setblock 417 6 183 minecraft:stone_bricks
fill 417 6 184 417 9 184 minecraft:mossy_cobblestone
setblock 417 6 188 minecraft:stone_bricks
fill 417 6 189 417 9 189 minecraft:mossy_cobblestone
setblock 417 6 192 minecraft:mossy_cobblestone
setblock 417 6 193 minecraft:stone_bricks
fill 417 6 194 417 9 194 minecraft:mossy_cobblestone
fill 417 6 196 417 6 197 minecraft:mossy_cobblestone
setblock 417 6 198 minecraft:stone_bricks
fill 417 6 199 417 9 199 minecraft:mossy_cobblestone
setblock 417 6 203 minecraft:stone_bricks
fill 417 6 204 417 9 204 minecraft:mossy_cobblestone
setblock 417 6 208 minecraft:stone_bricks
fill 417 6 209 417 9 209 minecraft:mossy_cobblestone
setblock 417 6 213 minecraft:stone_bricks
fill 417 6 214 417 9 214 minecraft:mossy_cobblestone
setblock 417 6 218 minecraft:stone_bricks
fill 417 6 219 417 9 219 minecraft:mossy_cobblestone
fill 377 7 183 377 9 183 minecraft:mossy_cobblestone
setblock 377 7 187 minecraft:stone_bricks
fill 377 7 188 377 7 191 minecraft:mossy_cobblestone
setblock 377 7 192 minecraft:stone_bricks
fill 377 7 193 377 7 196 minecraft:mossy_cobblestone
setblock 377 7 197 minecraft:stone_bricks
fill 377 7 198 377 10 198 minecraft:mossy_cobblestone
setblock 377 7 202 minecraft:stone_bricks
fill 377 7 203 377 10 203 minecraft:mossy_cobblestone
setblock 377 7 207 minecraft:stone_bricks
fill 377 7 208 377 10 208 minecraft:mossy_cobblestone
setblock 377 7 212 minecraft:stone_bricks
fill 377 7 213 377 10 213 minecraft:mossy_cobblestone
setblock 377 7 217 minecraft:stone_bricks
fill 377 7 218 377 10 218 minecraft:mossy_cobblestone
setblock 377 7 222 minecraft:stone_bricks
setblock 378 7 186 minecraft:stone_bricks
fill 378 7 187 378 7 190 minecraft:mossy_cobblestone
setblock 378 7 191 minecraft:stone_bricks
fill 378 7 192 378 7 195 minecraft:mossy_cobblestone
setblock 378 7 196 minecraft:stone_bricks
fill 378 7 197 378 10 197 minecraft:mossy_cobblestone
setblock 378 7 201 minecraft:stone_bricks
fill 378 7 202 378 10 202 minecraft:mossy_cobblestone
setblock 378 7 206 minecraft:stone_bricks
fill 378 7 207 378 10 207 minecraft:mossy_cobblestone
setblock 378 7 211 minecraft:stone_bricks
fill 378 7 212 378 10 212 minecraft:mossy_cobblestone
setblock 378 7 215 minecraft:mossy_cobblestone
setblock 378 7 216 minecraft:stone_bricks
fill 378 7 217 379 9 217 minecraft:mossy_cobblestone
fill 378 7 222 379 9 222 minecraft:mossy_cobblestone
setblock 379 7 189 minecraft:mossy_cobblestone
setblock 379 7 190 minecraft:stone_bricks
fill 379 7 191 379 10 191 minecraft:mossy_cobblestone
fill 379 7 193 379 7 194 minecraft:mossy_cobblestone
setblock 379 7 195 minecraft:stone_bricks
fill 379 7 196 379 10 196 minecraft:mossy_cobblestone
fill 379 7 198 379 7 199 minecraft:mossy_cobblestone
setblock 379 7 205 minecraft:stone_bricks
fill 379 7 206 379 8 206 minecraft:mossy_cobblestone
setblock 379 7 210 minecraft:stone_bricks
fill 379 7 211 379 10 211 minecraft:mossy_cobblestone
setblock 379 7 215 minecraft:stone_bricks
fill 379 7 216 379 10 216 minecraft:mossy_cobblestone
setblock 391 7 182 minecraft:mossy_cobblestone
setblock 392 7 182 minecraft:stone_bricks
fill 393 7 182 393 10 182 minecraft:mossy_cobblestone
setblock 394 7 184 minecraft:mossy_cobblestone
fill 394 7 222 394 9 222 minecraft:mossy_cobblestone
setblock 395 7 184 minecraft:stone_bricks
setblock 396 7 183 minecraft:stone_bricks
fill 396 7 184 396 10 184 minecraft:mossy_cobblestone
fill 396 7 221 396 7 222 minecraft:mossy_cobblestone
setblock 397 7 182 minecraft:stone_bricks
fill 397 7 183 397 10 183 minecraft:mossy_cobblestone
setblock 397 7 221 minecraft:mossy_cobblestone
setblock 397 7 222 minecraft:stone_bricks
fill 398 7 182 398 10 182 minecraft:mossy_cobblestone
setblock 398 7 221 minecraft:stone_bricks
fill 398 7 222 398 10 222 minecraft:mossy_cobblestone
fill 399 7 221 401 8 221 minecraft:mossy_cobblestone
setblock 400 7 184 minecraft:stone_bricks
setblock 401 7 183 minecraft:stone_bricks
setblock 402 7 182 minecraft:stone_bricks
setblock 402 7 183 minecraft:mossy_cobblestone
setblock 402 7 222 minecraft:stone_bricks
fill 403 7 182 403 10 182 minecraft:mossy_cobblestone
fill 403 7 222 403 10 222 minecraft:mossy_cobblestone
fill 405 7 222 406 7 222 minecraft:mossy_cobblestone
setblock 407 7 222 minecraft:stone_bricks
fill 408 7 222 409 9 222 minecraft:mossy_cobblestone
setblock 412 7 221 minecraft:mossy_cobblestone
setblock 412 7 222 minecraft:stone_bricks
fill 413 7 182 413 10 182 minecraft:mossy_cobblestone
setblock 413 7 221 minecraft:stone_bricks
fill 413 7 222 413 10 222 minecraft:mossy_cobblestone
setblock 414 7 210 minecraft:stone_bricks
fill 414 7 211 414 7 214 minecraft:mossy_cobblestone
setblock 414 7 215 minecraft:stone_bricks
fill 414 7 216 414 9 217 minecraft:mossy_cobblestone
setblock 414 7 220 minecraft:stone_bricks
fill 414 7 221 414 10 221 minecraft:mossy_cobblestone
fill 415 7 207 415 7 208 minecraft:mossy_cobblestone
setblock 415 7 209 minecraft:stone_bricks
fill 415 7 210 415 10 210 minecraft:mossy_cobblestone
setblock 415 7 213 minecraft:mossy_cobblestone
setblock 415 7 214 minecraft:stone_bricks
fill 415 7 215 415 10 215 minecraft:mossy_cobblestone
setblock 415 7 218 minecraft:mossy_cobblestone
setblock 415 7 219 minecraft:stone_bricks
fill 415 7 220 415 10 220 minecraft:mossy_cobblestone
fill 416 7 186 416 7 187 minecraft:mossy_cobblestone
setblock 416 7 188 minecraft:stone_bricks
fill 416 7 189 416 10 189 minecraft:mossy_cobblestone
setblock 416 7 193 minecraft:stone_bricks
fill 416 7 194 416 10 194 minecraft:mossy_cobblestone
fill 416 7 196 416 7 197 minecraft:mossy_cobblestone
setblock 416 7 198 minecraft:stone_bricks
setblock 416 7 203 minecraft:stone_bricks
fill 416 7 204 416 10 204 minecraft:mossy_cobblestone
setblock 416 7 208 minecraft:stone_bricks
fill 416 7 209 416 10 209 minecraft:mossy_cobblestone
setblock 416 7 213 minecraft:stone_bricks
fill 416 7 214 416 10 214 minecraft:mossy_cobblestone
setblock 416 7 218 minecraft:stone_bricks
fill 416 7 219 416 10 219 minecraft:mossy_cobblestone
setblock 417 7 182 minecraft:stone_bricks
fill 417 7 183 417 10 183 minecraft:mossy_cobblestone
setblock 417 7 187 minecraft:stone_bricks
fill 417 7 188 417 10 188 minecraft:mossy_cobblestone
setblock 417 7 192 minecraft:stone_bricks
fill 417 7 193 417 10 193 minecraft:mossy_cobblestone
setblock 417 7 196 minecraft:mossy_cobblestone
setblock 417 7 197 minecraft:stone_bricks
fill 417 7 198 417 10 198 minecraft:mossy_cobblestone
setblock 417 7 202 minecraft:stone_bricks
fill 417 7 203 417 10 203 minecraft:mossy_cobblestone
setblock 417 7 207 minecraft:stone_bricks
fill 417 7 208 417 10 208 minecraft:mossy_cobblestone
setblock 417 7 212 minecraft:stone_bricks
fill 417 7 213 417 10 213 minecraft:mossy_cobblestone
setblock 417 7 217 minecraft:stone_bricks
fill 417 7 218 417 10 218 minecraft:mossy_cobblestone
setblock 417 7 222 minecraft:stone_bricks
fill 377 8 182 377 9 182 minecraft:mossy_cobblestone
setblock 377 8 186 minecraft:stone_bricks
fill 377 8 187 377 8 190 minecraft:mossy_cobblestone
setblock 377 8 191 minecraft:stone_bricks
fill 377 8 192 377 8 195 minecraft:mossy_cobblestone
setblock 377 8 196 minecraft:stone_bricks
fill 377 8 197 377 11 197 minecraft:mossy_cobblestone
setblock 377 8 201 minecraft:stone_bricks
fill 377 8 202 377 11 202 minecraft:mossy_cobblestone
setblock 377 8 206 minecraft:stone_bricks
fill 377 8 207 377 11 207 minecraft:mossy_cobblestone
setblock 377 8 211 minecraft:stone_bricks
fill 377 8 212 377 11 212 minecraft:mossy_cobblestone
setblock 377 8 216 minecraft:stone_bricks
fill 377 8 217 377 11 217 minecraft:mossy_cobblestone
setblock 377 8 221 minecraft:stone_bricks
fill 377 8 222 377 11 222 minecraft:mossy_cobblestone
fill 378 8 186 378 8 189 minecraft:mossy_cobblestone
setblock 378 8 190 minecraft:stone_bricks
fill 378 8 191 378 8 194 minecraft:mossy_cobblestone
setblock 378 8 195 minecraft:stone_bricks
fill 378 8 196 378 11 196 minecraft:mossy_cobblestone
setblock 378 8 200 minecraft:stone_bricks
fill 378 8 201 378 11 201 minecraft:mossy_cobblestone
setblock 378 8 205 minecraft:stone_bricks
fill 378 8 206 378 11 206 minecraft:mossy_cobblestone
setblock 378 8 210 minecraft:stone_bricks
fill 378 8 211 378 11 211 minecraft:mossy_cobblestone
setblock 378 8 215 minecraft:stone_bricks
fill 378 8 216 378 11 216 minecraft:mossy_cobblestone
setblock 378 8 220 minecraft:stone_bricks
setblock 379 8 189 minecraft:stone_bricks
fill 379 8 190 379 10 190 minecraft:mossy_cobblestone
setblock 379 8 193 minecraft:mossy_cobblestone
setblock 379 8 194 minecraft:stone_bricks
fill 379 8 195 379 11 195 minecraft:mossy_cobblestone
setblock 379 8 198 minecraft:mossy_cobblestone
setblock 379 8 199 minecraft:stone_bricks
fill 379 8 200 379 11 200 minecraft:mossy_cobblestone
setblock 379 8 209 minecraft:stone_bricks
fill 379 8 210 379 9 210 minecraft:mossy_cobblestone
setblock 379 8 214 minecraft:stone_bricks
fill 379 8 215 379 10 215 minecraft:mossy_cobblestone
setblock 380 8 193 minecraft:stone_bricks
fill 380 8 194 380 9 194 minecraft:mossy_cobblestone
setblock 391 8 182 minecraft:stone_bricks
fill 392 8 182 392 10 183 minecraft:mossy_cobblestone
fill 392 8 222 393 10 222 minecraft:mossy_cobblestone
setblock 394 8 184 minecraft:stone_bricks
fill 394 8 221 396 8 221 minecraft:mossy_cobblestone
setblock 395 8 183 minecraft:stone_bricks
fill 395 8 184 395 11 184 minecraft:mossy_cobblestone
setblock 396 8 182 minecraft:stone_bricks
fill 396 8 183 396 11 183 minecraft:mossy_cobblestone
setblock 396 8 222 minecraft:stone_bricks
fill 397 8 182 397 11 182 minecraft:mossy_cobblestone
setblock 397 8 221 minecraft:stone_bricks
fill 397 8 222 397 11 222 minecraft:mossy_cobblestone
fill 398 8 221 398 11 221 minecraft:mossy_cobblestone
setblock 399 8 184 minecraft:stone_bricks
setblock 400 8 183 minecraft:stone_bricks
setblock 401 8 182 minecraft:stone_bricks
fill 401 8 183 401 9 183 minecraft:mossy_cobblestone
setblock 401 8 222 minecraft:stone_bricks
fill 402 8 182 402 11 182 minecraft:mossy_cobblestone
setblock 402 8 221 minecraft:stone_bricks
fill 402 8 222 402 11 222 minecraft:mossy_cobblestone
setblock 405 8 222 minecraft:mossy_cobblestone
setblock 406 8 222 minecraft:stone_bricks
fill 407 8 222 407 11 222 minecraft:mossy_cobblestone
fill 410 8 221 410 8 222 minecraft:mossy_cobblestone
setblock 411 8 221 minecraft:mossy_cobblestone
setblock 411 8 222 minecraft:stone_bricks
fill 412 8 182 412 11 182 minecraft:mossy_cobblestone
setblock 412 8 220 minecraft:mossy_cobblestone
setblock 412 8 221 minecraft:stone_bricks
fill 412 8 222 412 11 222 minecraft:mossy_cobblestone
setblock 413 8 220 minecraft:stone_bricks
fill 413 8 221 413 11 221 minecraft:mossy_cobblestone
fill 414 8 210 414 8 213 minecraft:mossy_cobblestone
setblock 414 8 214 minecraft:stone_bricks
fill 414 8 215 414 11 215 minecraft:mossy_cobblestone
setblock 414 8 218 minecraft:mossy_cobblestone
fill 414 8 220 414 11 220 minecraft:mossy_cobblestone
fill 415 8 191 415 8 192 minecraft:mossy_cobblestone
setblock 415 8 193 minecraft:stone_bricks
fill 415 8 194 415 11 194 minecraft:mossy_cobblestone
setblock 415 8 207 minecraft:mossy_cobblestone
setblock 415 8 208 minecraft:stone_bricks
fill 415 8 209 415 11 209 minecraft:mossy_cobblestone
setblock 415 8 213 minecraft:stone_bricks
fill 415 8 214 415 11 214 minecraft:mossy_cobblestone
setblock 415 8 218 minecraft:stone_bricks
fill 415 8 219 415 11 219 minecraft:mossy_cobblestone
setblock 416 8 182 minecraft:stone_bricks
setblock 416 8 187 minecraft:stone_bricks
fill 416 8 188 416 10 188 minecraft:mossy_cobblestone
setblock 416 8 191 minecraft:mossy_cobblestone
setblock 416 8 192 minecraft:stone_bricks
fill 416 8 193 416 11 193 minecraft:mossy_cobblestone
setblock 416 8 196 minecraft:mossy_cobblestone
setblock 416 8 197 minecraft:stone_bricks
fill 416 8 198 416 8 201 minecraft:mossy_cobblestone
setblock 416 8 202 minecraft:stone_bricks
fill 416 8 203 416 11 203 minecraft:mossy_cobblestone
setblock 416 8 207 minecraft:stone_bricks
fill 416 8 208 416 11 208 minecraft:mossy_cobblestone
setblock 416 8 212 minecraft:stone_bricks
fill 416 8 213 416 11 213 minecraft:mossy_cobblestone
setblock 416 8 217 minecraft:stone_bricks
fill 416 8 218 416 11 218 minecraft:mossy_cobblestone
setblock 416 8 222 minecraft:stone_bricks
fill 417 8 182 417 10 182 minecraft:mossy_cobblestone
setblock 417 8 186 minecraft:stone_bricks
fill 417 8 187 417 11 187 minecraft:mossy_cobblestone
setblock 417 8 191 minecraft:stone_bricks
fill 417 8 192 417 11 192 minecraft:mossy_cobblestone
setblock 417 8 196 minecraft:stone_bricks
fill 417 8 197 417 11 197 minecraft:mossy_cobblestone
setblock 417 8 200 minecraft:mossy_cobblestone
setblock 417 8 201 minecraft:stone_bricks
fill 417 8 202 417 11 202 minecraft:mossy_cobblestone
setblock 417 8 206 minecraft:stone_bricks
fill 417 8 207 417 11 207 minecraft:mossy_cobblestone
setblock 417 8 211 minecraft:stone_bricks
fill 417 8 212 417 11 212 minecraft:mossy_cobblestone
setblock 417 8 216 minecraft:stone_bricks
fill 417 8 217 417 11 217 minecraft:mossy_cobblestone
setblock 417 8 221 minecraft:stone_bricks
fill 417 8 222 417 11 222 minecraft:mossy_cobblestone
setblock 377 9 185 minecraft:stone_bricks
fill 377 9 186 377 9 189 minecraft:mossy_cobblestone
setblock 377 9 190 minecraft:stone_bricks
fill 377 9 191 377 9 194 minecraft:mossy_cobblestone
setblock 377 9 195 minecraft:stone_bricks
fill 377 9 196 377 12 196 minecraft:mossy_cobblestone
setblock 377 9 200 minecraft:stone_bricks
fill 377 9 201 377 12 201 minecraft:mossy_cobblestone
setblock 377 9 205 minecraft:stone_bricks
fill 377 9 206 377 12 206 minecraft:mossy_cobblestone
setblock 377 9 210 minecraft:stone_bricks
fill 377 9 211 377 12 211 minecraft:mossy_cobblestone
setblock 377 9 215 minecraft:stone_bricks
fill 377 9 216 377 12 216 minecraft:mossy_cobblestone
setblock 377 9 219 minecraft:mossy_cobblestone
setblock 377 9 220 minecraft:stone_bricks
fill 377 9 221 377 12 221 minecraft:mossy_cobblestone
fill 378 9 187 378 9 188 minecraft:mossy_cobblestone
setblock 378 9 189 minecraft:stone_bricks
fill 378 9 190 378 9 193 minecraft:mossy_cobblestone
setblock 378 9 194 minecraft:stone_bricks
fill 378 9 195 378 12 195 minecraft:mossy_cobblestone
setblock 378 9 199 minecraft:stone_bricks
fill 378 9 200 378 12 200 minecraft:mossy_cobblestone
setblock 378 9 204 minecraft:stone_bricks
fill 378 9 205 378 11 205 minecraft:mossy_cobblestone
setblock 378 9 209 minecraft:stone_bricks
fill 378 9 210 378 12 210 minecraft:mossy_cobblestone
setblock 378 9 214 minecraft:stone_bricks
fill 378 9 215 378 12 215 minecraft:mossy_cobblestone
setblock 378 9 219 minecraft:stone_bricks
fill 378 9 220 378 11 220 minecraft:mossy_cobblestone
setblock 379 9 184 minecraft:light[level=12]
setblock 379 9 189 minecraft:mossy_cobblestone
setblock 379 9 193 minecraft:stone_bricks
fill 379 9 194 379 12 194 minecraft:mossy_cobblestone
setblock 379 9 198 minecraft:stone_bricks
fill 379 9 199 379 12 199 minecraft:mossy_cobblestone
setblock 379 9 201 minecraft:mossy_cobblestone
setblock 379 9 208 minecraft:stone_bricks
setblock 379 9 209 minecraft:mossy_cobblestone
setblock 379 9 213 minecraft:stone_bricks
fill 379 9 214 379 10 214 minecraft:mossy_cobblestone
setblock 380 9 193 minecraft:mossy_cobblestone
fill 380 9 195 380 10 195 minecraft:mossy_cobblestone
setblock 387 9 184 minecraft:light[level=12]
setblock 387 9 192 minecraft:light[level=12]
setblock 387 9 200 minecraft:light[level=12]
setblock 387 9 208 minecraft:light[level=12]
setblock 387 9 216 minecraft:light[level=12]
setblock 390 9 182 minecraft:stone_bricks
fill 391 9 182 391 12 182 minecraft:mossy_cobblestone
fill 391 9 222 391 12 222 minecraft:mossy_cobblestone
fill 393 9 221 395 9 221 minecraft:mossy_cobblestone
setblock 394 9 183 minecraft:stone_bricks
fill 394 9 184 394 11 184 minecraft:mossy_cobblestone
setblock 395 9 182 minecraft:stone_bricks
fill 395 9 183 395 12 183 minecraft:mossy_cobblestone
setblock 395 9 192 minecraft:light[level=12]
setblock 395 9 200 minecraft:light[level=12]
setblock 395 9 208 minecraft:light[level=12]
setblock 395 9 216 minecraft:light[level=12]
setblock 395 9 222 minecraft:stone_bricks
fill 396 9 182 396 12 182 minecraft:mossy_cobblestone
setblock 396 9 220 minecraft:mossy_cobblestone
setblock 396 9 221 minecraft:stone_bricks
fill 396 9 222 396 12 222 minecraft:mossy_cobblestone
setblock 397 9 220 minecraft:stone_bricks
fill 397 9 221 397 12 221 minecraft:mossy_cobblestone
setblock 398 9 184 minecraft:stone_bricks
fill 398 9 220 399 11 220 minecraft:mossy_cobblestone
setblock 399 9 183 minecraft:stone_bricks
fill 399 9 221 400 9 221 minecraft:mossy_cobblestone
setblock 400 9 182 minecraft:stone_bricks
fill 400 9 183 400 10 183 minecraft:mossy_cobblestone
setblock 400 9 222 minecraft:stone_bricks
fill 401 9 182 401 12 182 minecraft:mossy_cobblestone
setblock 401 9 221 minecraft:stone_bricks
fill 401 9 222 401 12 222 minecraft:mossy_cobblestone
fill 402 9 221 403 11 221 minecraft:mossy_cobblestone
setblock 403 9 184 minecraft:light[level=12]
setblock 403 9 192 minecraft:light[level=12]
setblock 403 9 200 minecraft:light[level=12]
setblock 403 9 208 minecraft:light[level=12]
setblock 403 9 216 minecraft:light[level=12]
setblock 405 9 222 minecraft:stone_bricks
fill 406 9 222 406 12 222 minecraft:mossy_cobblestone
fill 408 9 221 410 9 221 minecraft:mossy_cobblestone
setblock 410 9 222 minecraft:stone_bricks
fill 411 9 182 411 12 182 minecraft:mossy_cobblestone
setblock 411 9 184 minecraft:light[level=12]
setblock 411 9 192 minecraft:light[level=12]
setblock 411 9 200 minecraft:light[level=12]
setblock 411 9 208 minecraft:light[level=12]
setblock 411 9 216 minecraft:light[level=12]
setblock 411 9 220 minecraft:mossy_cobblestone
setblock 411 9 221 minecraft:stone_bricks
fill 411 9 222 411 12 222 minecraft:mossy_cobblestone
setblock 412 9 220 minecraft:stone_bricks
fill 412 9 221 412 12 221 minecraft:mossy_cobblestone
setblock 413 9 219 minecraft:stone_bricks
fill 413 9 220 413 12 220 minecraft:mossy_cobblestone
fill 414 9 210 414 9 212 minecraft:mossy_cobblestone
setblock 414 9 213 minecraft:stone_bricks
fill 414 9 214 414 12 214 minecraft:mossy_cobblestone
setblock 414 9 218 minecraft:stone_bricks
fill 414 9 219 414 12 219 minecraft:mossy_cobblestone
setblock 415 9 182 minecraft:stone_bricks
setblock 415 9 191 minecraft:mossy_cobblestone
setblock 415 9 192 minecraft:stone_bricks
fill 415 9 193 415 11 193 minecraft:mossy_cobblestone
fill 415 9 195 415 9 196 minecraft:mossy_cobblestone
setblock 415 9 207 minecraft:stone_bricks
fill 415 9 208 415 11 208 minecraft:mossy_cobblestone
setblock 415 9 212 minecraft:stone_bricks
fill 415 9 213 415 12 213 minecraft:mossy_cobblestone
setblock 415 9 217 minecraft:stone_bricks
fill 415 9 218 415 12 218 minecraft:mossy_cobblestone
setblock 415 9 222 minecraft:stone_bricks
fill 416 9 182 416 11 182 minecraft:mossy_cobblestone
setblock 416 9 187 minecraft:mossy_cobblestone
setblock 416 9 191 minecraft:stone_bricks
fill 416 9 192 416 12 192 minecraft:mossy_cobblestone
setblock 416 9 195 minecraft:mossy_cobblestone
setblock 416 9 196 minecraft:stone_bricks
fill 416 9 197 416 9 200 minecraft:mossy_cobblestone
setblock 416 9 201 minecraft:stone_bricks
fill 416 9 202 416 12 202 minecraft:mossy_cobblestone
setblock 416 9 206 minecraft:stone_bricks
fill 416 9 207 416 12 207 minecraft:mossy_cobblestone
setblock 416 9 211 minecraft:stone_bricks
fill 416 9 212 416 12 212 minecraft:mossy_cobblestone
setblock 416 9 216 minecraft:stone_bricks
fill 416 9 217 416 12 217 minecraft:mossy_cobblestone
setblock 416 9 221 minecraft:stone_bricks
fill 416 9 222 416 12 222 minecraft:mossy_cobblestone
setblock 417 9 185 minecraft:stone_bricks
fill 417 9 186 417 10 186 minecraft:mossy_cobblestone
setblock 417 9 190 minecraft:stone_bricks
fill 417 9 191 417 12 191 minecraft:mossy_cobblestone
setblock 417 9 195 minecraft:stone_bricks
fill 417 9 196 417 12 196 minecraft:mossy_cobblestone
setblock 417 9 200 minecraft:stone_bricks
fill 417 9 201 417 12 201 minecraft:mossy_cobblestone
setblock 417 9 205 minecraft:stone_bricks
fill 417 9 206 417 12 206 minecraft:mossy_cobblestone
setblock 417 9 210 minecraft:stone_bricks
fill 417 9 211 417 12 211 minecraft:mossy_cobblestone
setblock 417 9 215 minecraft:stone_bricks
fill 417 9 216 417 12 216 minecraft:mossy_cobblestone
setblock 417 9 220 minecraft:stone_bricks
fill 417 9 221 417 12 221 minecraft:mossy_cobblestone
setblock 377 10 184 minecraft:stone_bricks
fill 377 10 185 377 10 188 minecraft:mossy_cobblestone
setblock 377 10 189 minecraft:stone_bricks
fill 377 10 190 377 10 193 minecraft:mossy_cobblestone
setblock 377 10 194 minecraft:stone_bricks
fill 377 10 195 377 13 195 minecraft:mossy_cobblestone
setblock 377 10 199 minecraft:stone_bricks
fill 377 10 200 377 13 200 minecraft:mossy_cobblestone
setblock 377 10 204 minecraft:stone_bricks
fill 377 10 205 377 13 205 minecraft:mossy_cobblestone
setblock 377 10 209 minecraft:stone_bricks
fill 377 10 210 377 13 210 minecraft:mossy_cobblestone
setblock 377 10 214 minecraft:stone_bricks
fill 377 10 215 377 13 215 minecraft:mossy_cobblestone
setblock 377 10 219 minecraft:stone_bricks
fill 377 10 220 377 13 220 minecraft:mossy_cobblestone
setblock 378 10 188 minecraft:stone_bricks
fill 378 10 189 378 10 192 minecraft:mossy_cobblestone
setblock 378 10 193 minecraft:stone_bricks
fill 378 10 194 378 13 194 minecraft:mossy_cobblestone
setblock 378 10 198 minecraft:stone_bricks
fill 378 10 199 378 13 199 minecraft:mossy_cobblestone
setblock 378 10 203 minecraft:stone_bricks
fill 378 10 204 378 12 204 minecraft:mossy_cobblestone
setblock 378 10 208 minecraft:stone_bricks
fill 378 10 209 378 11 209 minecraft:mossy_cobblestone
setblock 378 10 213 minecraft:stone_bricks
fill 378 10 214 378 12 214 minecraft:mossy_cobblestone
setblock 378 10 217 minecraft:mossy_cobblestone
setblock 378 10 218 minecraft:stone_bricks
fill 378 10 219 378 12 219 minecraft:mossy_cobblestone
setblock 378 10 222 minecraft:mossy_cobblestone
setblock 379 10 192 minecraft:stone_bricks
fill 379 10 193 379 12 193 minecraft:mossy_cobblestone
setblock 379 10 197 minecraft:stone_bricks
fill 379 10 198 379 13 198 minecraft:mossy_cobblestone
setblock 379 10 212 minecraft:stone_bricks
setblock 379 10 213 minecraft:mossy_cobblestone
setblock 379 10 222 minecraft:stone_bricks
setblock 389 10 182 minecraft:stone_bricks
fill 390 10 182 390 13 182 minecraft:mossy_cobblestone
fill 390 10 222 390 13 222 minecraft:mossy_cobblestone
fill 391 10 183 391 11 183 minecraft:mossy_cobblestone
fill 392 10 221 394 10 221 minecraft:mossy_cobblestone
setblock 393 10 183 minecraft:stone_bricks
setblock 394 10 182 minecraft:stone_bricks
fill 394 10 183 394 13 183 minecraft:mossy_cobblestone
setblock 394 10 222 minecraft:stone_bricks
fill 395 10 182 395 13 182 minecraft:mossy_cobblestone
setblock 395 10 220 minecraft:mossy_cobblestone
setblock 395 10 221 minecraft:stone_bricks
fill 395 10 222 395 13 222 minecraft:mossy_cobblestone
setblock 396 10 220 minecraft:stone_bricks
fill 396 10 221 396 13 221 minecraft:mossy_cobblestone
setblock 397 10 184 minecraft:stone_bricks
fill 397 10 220 397 13 220 minecraft:mossy_cobblestone
setblock 398 10 183 minecraft:stone_bricks
setblock 399 10 182 minecraft:stone_bricks
fill 399 10 183 399 11 183 minecraft:mossy_cobblestone
setblock 399 10 221 minecraft:mossy_cobblestone
setblock 399 10 222 minecraft:stone_bricks
fill 400 10 182 400 13 182 minecraft:mossy_cobblestone
setblock 400 10 221 minecraft:stone_bricks
fill 400 10 222 400 13 222 minecraft:mossy_cobblestone
fill 401 10 221 401 13 221 minecraft:mossy_cobblestone
setblock 404 10 222 minecraft:stone_bricks
fill 405 10 222 405 13 222 minecraft:mossy_cobblestone
fill 407 10 221 409 10 221 minecraft:mossy_cobblestone
setblock 408 10 222 minecraft:mossy_cobblestone
setblock 409 10 222 minecraft:stone_bricks
setblock 410 10 220 minecraft:mossy_cobblestone
setblock 410 10 221 minecraft:stone_bricks
fill 410 10 222 410 13 222 minecraft:mossy_cobblestone
setblock 411 10 220 minecraft:stone_bricks
fill 411 10 221 411 13 221 minecraft:mossy_cobblestone
setblock 412 10 219 minecraft:stone_bricks
fill 412 10 220 412 13 220 minecraft:mossy_cobblestone
fill 413 10 215 413 10 216 minecraft:mossy_cobblestone
fill 413 10 219 413 13 219 minecraft:mossy_cobblestone
setblock 414 10 182 minecraft:stone_bricks
fill 414 10 210 414 10 211 minecraft:mossy_cobblestone
setblock 414 10 212 minecraft:stone_bricks
fill 414 10 213 414 12 213 minecraft:mossy_cobblestone
setblock 414 10 216 minecraft:mossy_cobblestone
setblock 414 10 217 minecraft:stone_bricks
fill 414 10 218 414 13 218 minecraft:mossy_cobblestone
setblock 414 10 222 minecraft:stone_bricks
fill 415 10 182 415 12 182 minecraft:mossy_cobblestone
setblock 415 10 192 minecraft:mossy_cobblestone
setblock 415 10 195 minecraft:mossy_cobblestone
setblock 415 10 196 minecraft:stone_bricks
fill 415 10 197 416 11 198 minecraft:mossy_cobblestone
setblock 415 10 207 minecraft:mossy_cobblestone
setblock 415 10 211 minecraft:stone_bricks
fill 415 10 212 415 13 212 minecraft:mossy_cobblestone
setblock 415 10 216 minecraft:stone_bricks
fill 415 10 217 415 13 217 minecraft:mossy_cobblestone
setblock 415 10 221 minecraft:stone_bricks
fill 415 10 222 415 13 222 minecraft:mossy_cobblestone
setblock 416 10 190 minecraft:stone_bricks
fill 416 10 191 416 12 191 minecraft:mossy_cobblestone
setblock 416 10 195 minecraft:stone_bricks
fill 416 10 196 416 13 196 minecraft:mossy_cobblestone
setblock 416 10 199 minecraft:mossy_cobblestone
setblock 416 10 200 minecraft:stone_bricks
fill 416 10 201 416 13 201 minecraft:mossy_cobblestone
setblock 416 10 205 minecraft:stone_bricks
fill 416 10 206 416 13 206 minecraft:mossy_cobblestone
setblock 416 10 210 minecraft:stone_bricks
fill 416 10 211 416 13 211 minecraft:mossy_cobblestone
setblock 416 10 215 minecraft:stone_bricks
fill 416 10 216 416 13 216 minecraft:mossy_cobblestone
setblock 416 10 220 minecraft:stone_bricks
fill 416 10 221 416 13 221 minecraft:mossy_cobblestone
setblock 417 10 184 minecraft:stone_bricks
setblock 417 10 185 minecraft:mossy_cobblestone
setblock 417 10 189 minecraft:stone_bricks
fill 417 10 190 417 13 190 minecraft:mossy_cobblestone
setblock 417 10 194 minecraft:stone_bricks
fill 417 10 195 417 13 195 minecraft:mossy_cobblestone
setblock 417 10 199 minecraft:stone_bricks
fill 417 10 200 417 13 200 minecraft:mossy_cobblestone
setblock 417 10 204 minecraft:stone_bricks
fill 417 10 205 417 13 205 minecraft:mossy_cobblestone
setblock 417 10 209 minecraft:stone_bricks
fill 417 10 210 417 13 210 minecraft:mossy_cobblestone
setblock 417 10 214 minecraft:stone_bricks
fill 417 10 215 417 13 215 minecraft:mossy_cobblestone
setblock 417 10 219 minecraft:stone_bricks
fill 417 10 220 417 13 220 minecraft:mossy_cobblestone
fill 377 11 185 377 11 187 minecraft:mossy_cobblestone
setblock 377 11 188 minecraft:stone_bricks
fill 377 11 189 377 11 192 minecraft:mossy_cobblestone
setblock 377 11 193 minecraft:stone_bricks
fill 377 11 194 377 14 194 minecraft:mossy_cobblestone
setblock 377 11 198 minecraft:stone_bricks
fill 377 11 199 377 14 199 minecraft:mossy_cobblestone
setblock 377 11 203 minecraft:stone_bricks
fill 377 11 204 377 14 204 minecraft:mossy_cobblestone
setblock 377 11 208 minecraft:stone_bricks
fill 377 11 209 377 14 209 minecraft:mossy_cobblestone
setblock 377 11 213 minecraft:stone_bricks
fill 377 11 214 377 14 214 minecraft:mossy_cobblestone
setblock 377 11 218 minecraft:stone_bricks
fill 377 11 219 377 14 219 minecraft:mossy_cobblestone
fill 378 11 189 378 11 191 minecraft:mossy_cobblestone
setblock 378 11 192 minecraft:stone_bricks
fill 378 11 193 378 14 193 minecraft:mossy_cobblestone
setblock 378 11 197 minecraft:stone_bricks
fill 378 11 198 378 14 198 minecraft:mossy_cobblestone
setblock 378 11 202 minecraft:stone_bricks
fill 378 11 203 378 13 203 minecraft:mossy_cobblestone
setblock 378 11 207 minecraft:stone_bricks
setblock 378 11 208 minecraft:mossy_cobblestone
setblock 378 11 212 minecraft:stone_bricks
fill 378 11 213 378 12 213 minecraft:mossy_cobblestone
setblock 378 11 217 minecraft:stone_bricks
fill 378 11 218 378 12 218 minecraft:mossy_cobblestone
setblock 378 11 222 minecraft:stone_bricks
setblock 379 11 191 minecraft:stone_bricks
fill 379 11 192 379 12 192 minecraft:mossy_cobblestone
setblock 379 11 196 minecraft:stone_bricks
fill 379 11 197 379 14 197 minecraft:mossy_cobblestone
fill 389 11 182 389 14 182 minecraft:mossy_cobblestone
fill 391 11 221 393 11 221 minecraft:mossy_cobblestone
setblock 392 11 182 minecraft:mossy_cobblestone
setblock 392 11 183 minecraft:stone_bricks
setblock 392 11 222 minecraft:mossy_cobblestone
setblock 393 11 182 minecraft:stone_bricks
fill 393 11 183 393 14 183 minecraft:mossy_cobblestone
setblock 393 11 222 minecraft:stone_bricks
fill 394 11 182 394 14 182 minecraft:mossy_cobblestone
setblock 394 11 220 minecraft:mossy_cobblestone
setblock 394 11 221 minecraft:stone_bricks
fill 394 11 222 394 14 222 minecraft:mossy_cobblestone
setblock 395 11 220 minecraft:stone_bricks
fill 395 11 221 395 14 221 minecraft:mossy_cobblestone
fill 396 11 220 396 14 220 minecraft:mossy_cobblestone
setblock 397 11 183 minecraft:stone_bricks
setblock 398 11 182 minecraft:stone_bricks
fill 398 11 183 398 12 183 minecraft:mossy_cobblestone
setblock 398 11 222 minecraft:stone_bricks
fill 399 11 182 399 14 182 minecraft:mossy_cobblestone
setblock 399 11 221 minecraft:stone_bricks
fill 399 11 222 399 14 222 minecraft:mossy_cobblestone
fill 400 11 221 400 14 221 minecraft:mossy_cobblestone
setblock 403 11 222 minecraft:stone_bricks
setblock 404 11 221 minecraft:stone_bricks
fill 404 11 222 404 14 222 minecraft:mossy_cobblestone
fill 405 11 221 408 11 221 minecraft:mossy_cobblestone
setblock 408 11 222 minecraft:stone_bricks
setblock 409 11 220 minecraft:mossy_cobblestone
setblock 409 11 221 minecraft:stone_bricks
fill 409 11 222 409 14 222 minecraft:mossy_cobblestone
setblock 410 11 220 minecraft:stone_bricks
fill 410 11 221 410 14 221 minecraft:mossy_cobblestone
setblock 411 11 219 minecraft:stone_bricks
fill 411 11 220 411 14 220 minecraft:mossy_cobblestone
fill 412 11 219 412 14 219 minecraft:mossy_cobblestone
setblock 413 11 182 minecraft:stone_bricks
setblock 413 11 216 minecraft:mossy_cobblestone
setblock 413 11 222 minecraft:stone_bricks
fill 414 11 182 414 13 182 minecraft:mossy_cobblestone
setblock 414 11 211 minecraft:stone_bricks
fill 414 11 212 414 12 212 minecraft:mossy_cobblestone
setblock 414 11 216 minecraft:stone_bricks
fill 414 11 217 414 14 217 minecraft:mossy_cobblestone
setblock 414 11 221 minecraft:stone_bricks
fill 414 11 222 414 14 222 minecraft:mossy_cobblestone
setblock 415 11 195 minecraft:stone_bricks
fill 415 11 196 415 13 196 minecraft:mossy_cobblestone
setblock 415 11 199 minecraft:mossy_cobblestone
setblock 415 11 210 minecraft:stone_bricks
fill 415 11 211 415 13 211 minecraft:mossy_cobblestone
setblock 415 11 215 minecraft:stone_bricks
fill 415 11 216 415 14 216 minecraft:mossy_cobblestone
setblock 415 11 220 minecraft:stone_bricks
fill 415 11 221 415 14 221 minecraft:mossy_cobblestone
setblock 416 11 190 minecraft:mossy_cobblestone
setblock 416 11 194 minecraft:stone_bricks
fill 416 11 195 416 14 195 minecraft:mossy_cobblestone
setblock 416 11 199 minecraft:stone_bricks
fill 416 11 200 416 14 200 minecraft:mossy_cobblestone
setblock 416 11 204 minecraft:stone_bricks
fill 416 11 205 416 14 205 minecraft:mossy_cobblestone
setblock 416 11 209 minecraft:stone_bricks
fill 416 11 210 416 14 210 minecraft:mossy_cobblestone
setblock 416 11 214 minecraft:stone_bricks
fill 416 11 215 416 14 215 minecraft:mossy_cobblestone
setblock 416 11 219 minecraft:stone_bricks
fill 416 11 220 416 14 220 minecraft:mossy_cobblestone
setblock 417 11 188 minecraft:stone_bricks
fill 417 11 189 417 12 189 minecraft:mossy_cobblestone
setblock 417 11 193 minecraft:stone_bricks
fill 417 11 194 417 14 194 minecraft:mossy_cobblestone
setblock 417 11 198 minecraft:stone_bricks
fill 417 11 199 417 14 199 minecraft:mossy_cobblestone
setblock 417 11 203 minecraft:stone_bricks
fill 417 11 204 417 14 204 minecraft:mossy_cobblestone
setblock 417 11 208 minecraft:stone_bricks
fill 417 11 209 417 14 209 minecraft:mossy_cobblestone
setblock 417 11 213 minecraft:stone_bricks
fill 417 11 214 417 14 214 minecraft:mossy_cobblestone
setblock 417 11 218 minecraft:stone_bricks
fill 417 11 219 417 14 219 minecraft:mossy_cobblestone
setblock 377 12 187 minecraft:stone_bricks
fill 377 12 188 377 12 191 minecraft:mossy_cobblestone
setblock 377 12 192 minecraft:stone_bricks
fill 377 12 193 377 15 193 minecraft:mossy_cobblestone
setblock 377 12 197 minecraft:stone_bricks
fill 377 12 198 377 15 198 minecraft:mossy_cobblestone
setblock 377 12 202 minecraft:stone_bricks
fill 377 12 203 377 15 203 minecraft:mossy_cobblestone
setblock 377 12 207 minecraft:stone_bricks
fill 377 12 208 377 14 208 minecraft:mossy_cobblestone
setblock 377 12 212 minecraft:stone_bricks
fill 377 12 213 377 14 213 minecraft:mossy_cobblestone
setblock 377 12 217 minecraft:stone_bricks
fill 377 12 218 377 15 218 minecraft:mossy_cobblestone
setblock 377 12 222 minecraft:stone_bricks
setblock 378 12 190 minecraft:mossy_cobblestone
setblock 378 12 191 minecraft:stone_bricks
fill 378 12 192 378 14 192 minecraft:mossy_cobblestone
setblock 378 12 196 minecraft:stone_bricks
fill 378 12 197 378 15 197 minecraft:mossy_cobblestone
setblock 378 12 201 minecraft:stone_bricks
fill 378 12 202 378 15 202 minecraft:mossy_cobblestone
setblock 378 12 211 minecraft:stone_bricks
setblock 378 12 212 minecraft:mossy_cobblestone
setblock 378 12 216 minecraft:stone_bricks
fill 378 12 217 378 13 217 minecraft:mossy_cobblestone
setblock 378 12 222 minecraft:mossy_cobblestone
setblock 379 12 195 minecraft:stone_bricks
fill 379 12 196 379 14 196 minecraft:mossy_cobblestone
fill 389 12 222 389 14 222 minecraft:mossy_cobblestone
setblock 391 12 183 minecraft:stone_bricks
fill 391 12 221 392 12 221 minecraft:mossy_cobblestone
setblock 392 12 182 minecraft:stone_bricks
fill 392 12 183 392 15 183 minecraft:mossy_cobblestone
setblock 392 12 222 minecraft:stone_bricks
fill 393 12 182 393 15 182 minecraft:mossy_cobblestone
setblock 393 12 220 minecraft:mossy_cobblestone
setblock 393 12 221 minecraft:stone_bricks
fill 393 12 222 393 15 222 minecraft:mossy_cobblestone
setblock 394 12 220 minecraft:stone_bricks
fill 394 12 221 394 15 221 minecraft:mossy_cobblestone
fill 395 12 220 395 15 220 minecraft:mossy_cobblestone
setblock 396 12 183 minecraft:stone_bricks
setblock 397 12 182 minecraft:stone_bricks
fill 397 12 183 397 13 183 minecraft:mossy_cobblestone
setblock 397 12 222 minecraft:stone_bricks
fill 398 12 182 398 15 182 minecraft:mossy_cobblestone
setblock 398 12 220 minecraft:mossy_cobblestone
setblock 398 12 221 minecraft:stone_bricks
fill 398 12 222 398 15 222 minecraft:mossy_cobblestone
setblock 399 12 220 minecraft:stone_bricks
fill 399 12 221 399 15 221 minecraft:mossy_cobblestone
setblock 402 12 221 minecraft:mossy_cobblestone
setblock 402 12 222 minecraft:stone_bricks
setblock 403 12 221 minecraft:stone_bricks
fill 403 12 222 403 15 222 minecraft:mossy_cobblestone
fill 404 12 221 407 12 221 minecraft:mossy_cobblestone
setblock 407 12 222 minecraft:stone_bricks
setblock 408 12 221 minecraft:stone_bricks
fill 408 12 222 408 15 222 minecraft:mossy_cobblestone
setblock 409 12 220 minecraft:stone_bricks
fill 409 12 221 409 15 221 minecraft:mossy_cobblestone
fill 410 12 220 410 15 220 minecraft:mossy_cobblestone
fill 411 12 219 411 15 219 minecraft:mossy_cobblestone
setblock 412 12 182 minecraft:stone_bricks
setblock 412 12 222 minecraft:stone_bricks
fill 413 12 182 413 15 182 minecraft:mossy_cobblestone
setblock 413 12 221 minecraft:stone_bricks
fill 413 12 222 413 15 222 minecraft:mossy_cobblestone
setblock 414 12 215 minecraft:stone_bricks
fill 414 12 216 414 14 216 minecraft:mossy_cobblestone
setblock 414 12 220 minecraft:stone_bricks
fill 414 12 221 414 15 221 minecraft:mossy_cobblestone
setblock 415 12 194 minecraft:stone_bricks
fill 415 12 195 415 13 195 minecraft:mossy_cobblestone
fill 415 12 197 415 12 198 minecraft:mossy_cobblestone
setblock 415 12 199 minecraft:stone_bricks
setblock 415 12 209 minecraft:stone_bricks
fill 415 12 210 415 13 210 minecraft:mossy_cobblestone
setblock 415 12 214 minecraft:stone_bricks
fill 415 12 215 415 15 215 minecraft:mossy_cobblestone
setblock 415 12 219 minecraft:stone_bricks
fill 415 12 220 415 15 220 minecraft:mossy_cobblestone
setblock 416 12 193 minecraft:stone_bricks
fill 416 12 194 416 14 194 minecraft:mossy_cobblestone
setblock 416 12 197 minecraft:mossy_cobblestone
setblock 416 12 198 minecraft:stone_bricks
fill 416 12 199 416 15 199 minecraft:mossy_cobblestone
setblock 416 12 203 minecraft:stone_bricks
fill 416 12 204 416 15 204 minecraft:mossy_cobblestone
setblock 416 12 208 minecraft:stone_bricks
fill 416 12 209 416 14 209 minecraft:mossy_cobblestone
setblock 416 12 213 minecraft:stone_bricks
fill 416 12 214 416 15 214 minecraft:mossy_cobblestone
setblock 416 12 218 minecraft:stone_bricks
fill 416 12 219 416 15 219 minecraft:mossy_cobblestone
setblock 417 12 192 minecraft:stone_bricks
fill 417 12 193 417 15 193 minecraft:mossy_cobblestone
setblock 417 12 197 minecraft:stone_bricks
fill 417 12 198 417 15 198 minecraft:mossy_cobblestone
setblock 417 12 202 minecraft:stone_bricks
fill 417 12 203 417 15 203 minecraft:mossy_cobblestone
setblock 417 12 207 minecraft:stone_bricks
fill 417 12 208 417 15 208 minecraft:mossy_cobblestone
setblock 417 12 212 minecraft:stone_bricks
fill 417 12 213 417 15 213 minecraft:mossy_cobblestone
setblock 417 12 217 minecraft:stone_bricks
fill 417 12 218 417 15 218 minecraft:mossy_cobblestone
setblock 417 12 222 minecraft:stone_bricks
fill 377 13 188 377 13 190 minecraft:mossy_cobblestone
setblock 377 13 191 minecraft:stone_bricks
fill 377 13 192 377 16 192 minecraft:mossy_cobblestone
setblock 377 13 196 minecraft:stone_bricks
fill 377 13 197 377 16 197 minecraft:mossy_cobblestone
setblock 377 13 201 minecraft:stone_bricks
fill 377 13 202 377 16 202 minecraft:mossy_cobblestone
setblock 377 13 206 minecraft:stone_bricks
fill 377 13 207 377 14 207 minecraft:mossy_cobblestone
setblock 377 13 211 minecraft:stone_bricks
fill 377 13 212 377 14 212 minecraft:mossy_cobblestone
setblock 377 13 216 minecraft:stone_bricks
fill 377 13 217 377 16 217 minecraft:mossy_cobblestone
setblock 377 13 221 minecraft:stone_bricks
fill 377 13 222 377 14 222 minecraft:mossy_cobblestone
setblock 378 13 191 minecraft:mossy_cobblestone
setblock 378 13 195 minecraft:stone_bricks
fill 378 13 196 378 16 196 minecraft:mossy_cobblestone
setblock 378 13 200 minecraft:stone_bricks
fill 378 13 201 378 16 201 minecraft:mossy_cobblestone
setblock 378 13 215 minecraft:stone_bricks
setblock 378 13 216 minecraft:mossy_cobblestone
setblock 379 13 194 minecraft:stone_bricks
setblock 379 13 195 minecraft:mossy_cobblestone
setblock 379 13 199 minecraft:stone_bricks
fill 388 13 182 388 15 182 minecraft:mossy_cobblestone
fill 390 13 221 391 13 221 minecraft:mossy_cobblestone
setblock 391 13 182 minecraft:stone_bricks
fill 391 13 183 391 16 183 minecraft:mossy_cobblestone
setblock 391 13 222 minecraft:stone_bricks
fill 392 13 182 392 16 182 minecraft:mossy_cobblestone
setblock 392 13 221 minecraft:stone_bricks
fill 392 13 222 392 16 222 minecraft:mossy_cobblestone
setblock 393 13 220 minecraft:stone_bricks
fill 393 13 221 393 16 221 minecraft:mossy_cobblestone
fill 394 13 220 394 16 220 minecraft:mossy_cobblestone
setblock 395 13 183 minecraft:stone_bricks
setblock 396 13 182 minecraft:stone_bricks
fill 396 13 183 396 16 183 minecraft:mossy_cobblestone
setblock 396 13 222 minecraft:stone_bricks
fill 397 13 182 397 16 182 minecraft:mossy_cobblestone
setblock 397 13 221 minecraft:stone_bricks
fill 397 13 222 397 16 222 minecraft:mossy_cobblestone
setblock 398 13 220 minecraft:stone_bricks
fill 398 13 221 398 16 221 minecraft:mossy_cobblestone
setblock 401 13 222 minecraft:stone_bricks
setblock 402 13 221 minecraft:stone_bricks
fill 402 13 222 402 16 222 minecraft:mossy_cobblestone
fill 403 13 221 406 13 221 minecraft:mossy_cobblestone
setblock 406 13 222 minecraft:stone_bricks
setblock 407 13 221 minecraft:stone_bricks
fill 407 13 222 407 16 222 minecraft:mossy_cobblestone
setblock 408 13 220 minecraft:stone_bricks
fill 408 13 221 408 16 221 minecraft:mossy_cobblestone
fill 409 13 220 409 16 220 minecraft:mossy_cobblestone
setblock 411 13 182 minecraft:stone_bricks
setblock 411 13 222 minecraft:stone_bricks
fill 412 13 182 412 16 182 minecraft:mossy_cobblestone
setblock 412 13 221 minecraft:stone_bricks
fill 412 13 222 412 16 222 minecraft:mossy_cobblestone
setblock 413 13 220 minecraft:stone_bricks
fill 413 13 221 413 16 221 minecraft:mossy_cobblestone
setblock 414 13 214 minecraft:stone_bricks
fill 414 13 215 414 14 215 minecraft:mossy_cobblestone
setblock 414 13 219 minecraft:stone_bricks
fill 414 13 220 414 16 220 minecraft:mossy_cobblestone
setblock 415 13 197 minecraft:mossy_cobblestone
setblock 415 13 198 minecraft:stone_bricks
fill 415 13 199 415 15 200 minecraft:mossy_cobblestone
setblock 415 13 213 minecraft:stone_bricks
fill 415 13 214 415 15 214 minecraft:mossy_cobblestone
setblock 415 13 218 minecraft:stone_bricks
fill 415 13 219 415 16 219 minecraft:mossy_cobblestone
setblock 416 13 192 minecraft:stone_bricks
fill 416 13 193 416 14 193 minecraft:mossy_cobblestone
setblock 416 13 197 minecraft:stone_bricks
fill 416 13 198 416 16 198 minecraft:mossy_cobblestone
setblock 416 13 202 minecraft:stone_bricks
fill 416 13 203 416 16 203 minecraft:mossy_cobblestone
setblock 416 13 207 minecraft:stone_bricks
fill 416 13 208 416 14 208 minecraft:mossy_cobblestone
setblock 416 13 212 minecraft:stone_bricks
fill 416 13 213 416 16 213 minecraft:mossy_cobblestone
setblock 416 13 217 minecraft:stone_bricks
fill 416 13 218 416 16 218 minecraft:mossy_cobblestone
setblock 416 13 222 minecraft:stone_bricks
setblock 417 13 191 minecraft:stone_bricks
fill 417 13 192 417 14 192 minecraft:mossy_cobblestone
setblock 417 13 196 minecraft:stone_bricks
fill 417 13 197 417 16 197 minecraft:mossy_cobblestone
setblock 417 13 201 minecraft:stone_bricks
fill 417 13 202 417 16 202 minecraft:mossy_cobblestone
setblock 417 13 206 minecraft:stone_bricks
fill 417 13 207 417 16 207 minecraft:mossy_cobblestone
setblock 417 13 211 minecraft:stone_bricks
fill 417 13 212 417 16 212 minecraft:mossy_cobblestone
setblock 417 13 216 minecraft:stone_bricks
fill 417 13 217 417 16 217 minecraft:mossy_cobblestone
setblock 417 13 221 minecraft:stone_bricks
fill 417 13 222 417 16 222 minecraft:mossy_cobblestone
setblock 377 14 189 minecraft:mossy_cobblestone
setblock 377 14 190 minecraft:stone_bricks
fill 377 14 191 377 16 191 minecraft:mossy_cobblestone
setblock 377 14 195 minecraft:stone_bricks
fill 377 14 196 377 17 196 minecraft:mossy_cobblestone
setblock 377 14 200 minecraft:stone_bricks
fill 377 14 201 377 17 201 minecraft:mossy_cobblestone
setblock 377 14 205 minecraft:stone_bricks
fill 377 14 206 377 15 206 minecraft:mossy_cobblestone
setblock 377 14 210 minecraft:stone_bricks
setblock 377 14 211 minecraft:mossy_cobblestone
setblock 377 14 215 minecraft:stone_bricks
fill 377 14 216 377 15 216 minecraft:mossy_cobblestone
setblock 377 14 220 minecraft:stone_bricks
fill 377 14 221 377 15 221 minecraft:mossy_cobblestone
setblock 378 14 194 minecraft:stone_bricks
fill 378 14 195 378 17 195 minecraft:mossy_cobblestone
setblock 378 14 199 minecraft:stone_bricks
fill 378 14 200 378 17 200 minecraft:mossy_cobblestone
setblock 379 14 198 minecraft:stone_bricks
fill 388 14 222 388 15 222 minecraft:mossy_cobblestone
setblock 390 14 182 minecraft:stone_bricks
fill 390 14 183 390 17 183 minecraft:mossy_cobblestone
setblock 390 14 221 minecraft:mossy_cobblestone
setblock 390 14 222 minecraft:stone_bricks
fill 391 14 182 391 17 182 minecraft:mossy_cobblestone
setblock 391 14 221 minecraft:stone_bricks
fill 391 14 222 391 17 222 minecraft:mossy_cobblestone
setblock 392 14 220 minecraft:stone_bricks
fill 392 14 221 392 17 221 minecraft:mossy_cobblestone
fill 393 14 220 393 17 220 minecraft:mossy_cobblestone
setblock 394 14 183 minecraft:stone_bricks
setblock 395 14 182 minecraft:stone_bricks
fill 395 14 183 395 17 183 minecraft:mossy_cobblestone
setblock 395 14 222 minecraft:stone_bricks
fill 396 14 182 396 17 182 minecraft:mossy_cobblestone
setblock 396 14 221 minecraft:stone_bricks
fill 396 14 222 396 17 222 minecraft:mossy_cobblestone
setblock 397 14 220 minecraft:stone_bricks
fill 397 14 221 397 17 221 minecraft:mossy_cobblestone
setblock 400 14 182 minecraft:stone_bricks
setblock 400 14 222 minecraft:stone_bricks
setblock 401 14 221 minecraft:stone_bricks
fill 401 14 222 401 17 222 minecraft:mossy_cobblestone
fill 402 14 221 405 14 221 minecraft:mossy_cobblestone
setblock 405 14 222 minecraft:stone_bricks
setblock 406 14 221 minecraft:stone_bricks
fill 406 14 222 406 17 222 minecraft:mossy_cobblestone
fill 407 14 221 407 17 221 minecraft:mossy_cobblestone
fill 408 14 220 408 17 220 minecraft:mossy_cobblestone
setblock 410 14 222 minecraft:stone_bricks
fill 411 14 182 411 17 182 minecraft:mossy_cobblestone
setblock 411 14 221 minecraft:stone_bricks
fill 411 14 222 411 17 222 minecraft:mossy_cobblestone
setblock 412 14 220 minecraft:stone_bricks
fill 412 14 221 412 17 221 minecraft:mossy_cobblestone
setblock 413 14 219 minecraft:stone_bricks
fill 413 14 220 413 17 220 minecraft:mossy_cobblestone
setblock 414 14 218 minecraft:stone_bricks
setblock 414 14 219 minecraft:mossy_cobblestone
setblock 415 14 197 minecraft:stone_bricks
fill 415 14 198 415 16 198 minecraft:mossy_cobblestone
setblock 415 14 212 minecraft:stone_bricks
setblock 415 14 213 minecraft:mossy_cobblestone
setblock 415 14 217 minecraft:stone_bricks
fill 415 14 218 415 16 218 minecraft:mossy_cobblestone
setblock 415 14 222 minecraft:stone_bricks
setblock 416 14 196 minecraft:stone_bricks
fill 416 14 197 416 17 197 minecraft:mossy_cobblestone
setblock 416 14 201 minecraft:stone_bricks
fill 416 14 202 416 17 202 minecraft:mossy_cobblestone
setblock 416 14 211 minecraft:stone_bricks
fill 416 14 212 416 15 212 minecraft:mossy_cobblestone
setblock 416 14 216 minecraft:stone_bricks
fill 416 14 217 416 17 217 minecraft:mossy_cobblestone
setblock 416 14 221 minecraft:stone_bricks
fill 416 14 222 416 17 222 minecraft:mossy_cobblestone
setblock 417 14 191 minecraft:mossy_cobblestone
setblock 417 14 195 minecraft:stone_bricks
fill 417 14 196 417 17 196 minecraft:mossy_cobblestone
setblock 417 14 200 minecraft:stone_bricks
fill 417 14 201 417 17 201 minecraft:mossy_cobblestone
setblock 417 14 205 minecraft:stone_bricks
fill 417 14 206 417 17 206 minecraft:mossy_cobblestone
setblock 417 14 210 minecraft:stone_bricks
fill 417 14 211 417 16 211 minecraft:mossy_cobblestone
setblock 417 14 215 minecraft:stone_bricks
fill 417 14 216 417 17 216 minecraft:mossy_cobblestone
setblock 417 14 220 minecraft:stone_bricks
fill 417 14 221 417 17 221 minecraft:mossy_cobblestone
setblock 377 15 190 minecraft:mossy_cobblestone
setblock 377 15 194 minecraft:stone_bricks
fill 377 15 195 377 18 195 minecraft:mossy_cobblestone
setblock 377 15 199 minecraft:stone_bricks
fill 377 15 200 377 18 200 minecraft:mossy_cobblestone
setblock 377 15 204 minecraft:stone_bricks
fill 377 15 205 377 18 205 minecraft:mossy_cobblestone
setblock 377 15 214 minecraft:stone_bricks
setblock 377 15 215 minecraft:mossy_cobblestone
setblock 377 15 219 minecraft:stone_bricks
fill 377 15 220 377 16 220 minecraft:mossy_cobblestone
setblock 378 15 193 minecraft:stone_bricks
fill 378 15 194 378 16 194 minecraft:mossy_cobblestone
setblock 378 15 198 minecraft:stone_bricks
fill 378 15 199 378 18 199 minecraft:mossy_cobblestone
fill 387 15 182 387 16 182 minecraft:mossy_cobblestone
fill 387 15 222 387 16 222 minecraft:mossy_cobblestone
setblock 389 15 182 minecraft:stone_bricks
setblock 389 15 221 minecraft:mossy_cobblestone
setblock 389 15 222 minecraft:stone_bricks
fill 390 15 182 390 18 182 minecraft:mossy_cobblestone
setblock 390 15 221 minecraft:stone_bricks
fill 390 15 222 390 18 222 minecraft:mossy_cobblestone
fill 391 15 221 391 18 221 minecraft:mossy_cobblestone
fill 392 15 220 392 18 220 minecraft:mossy_cobblestone
setblock 393 15 183 minecraft:stone_bricks
setblock 394 15 182 minecraft:stone_bricks
fill 394 15 183 394 18 183 minecraft:mossy_cobblestone
setblock 394 15 222 minecraft:stone_bricks
fill 395 15 182 395 18 182 minecraft:mossy_cobblestone
setblock 395 15 221 minecraft:stone_bricks
fill 395 15 222 395 18 222 minecraft:mossy_cobblestone
setblock 396 15 220 minecraft:stone_bricks
fill 396 15 221 396 18 221 minecraft:mossy_cobblestone
setblock 399 15 182 minecraft:stone_bricks
setblock 399 15 222 minecraft:stone_bricks
setblock 400 15 221 minecraft:stone_bricks
fill 400 15 222 400 18 222 minecraft:mossy_cobblestone
fill 401 15 221 404 15 221 minecraft:mossy_cobblestone
setblock 404 15 222 minecraft:stone_bricks
setblock 405 15 221 minecraft:stone_bricks
fill 405 15 222 405 18 222 minecraft:mossy_cobblestone
fill 406 15 221 406 18 221 minecraft:mossy_cobblestone
setblock 409 15 222 minecraft:stone_bricks
fill 410 15 182 410 18 182 minecraft:mossy_cobblestone
setblock 410 15 221 minecraft:stone_bricks
fill 410 15 222 410 18 222 minecraft:mossy_cobblestone
setblock 411 15 220 minecraft:stone_bricks
fill 411 15 221 411 18 221 minecraft:mossy_cobblestone
setblock 412 15 219 minecraft:stone_bricks
fill 412 15 220 412 18 220 minecraft:mossy_cobblestone
setblock 414 15 222 minecraft:stone_bricks
setblock 415 15 216 minecraft:stone_bricks
fill 415 15 217 415 16 217 minecraft:mossy_cobblestone
setblock 415 15 221 minecraft:stone_bricks
fill 415 15 222 415 18 222 minecraft:mossy_cobblestone
setblock 416 15 195 minecraft:stone_bricks
fill 416 15 196 416 18 196 minecraft:mossy_cobblestone
setblock 416 15 200 minecraft:stone_bricks
fill 416 15 201 416 18 201 minecraft:mossy_cobblestone
setblock 416 15 211 minecraft:mossy_cobblestone
setblock 416 15 215 minecraft:stone_bricks
fill 416 15 216 416 17 216 minecraft:mossy_cobblestone
setblock 416 15 220 minecraft:stone_bricks
fill 416 15 221 416 18 221 minecraft:mossy_cobblestone
setblock 417 15 194 minecraft:stone_bricks
fill 417 15 195 417 18 195 minecraft:mossy_cobblestone
setblock 417 15 199 minecraft:stone_bricks
fill 417 15 200 417 18 200 minecraft:mossy_cobblestone
setblock 417 15 204 minecraft:stone_bricks
fill 417 15 205 417 18 205 minecraft:mossy_cobblestone
setblock 417 15 209 minecraft:stone_bricks
fill 417 15 210 417 16 210 minecraft:mossy_cobblestone
setblock 417 15 214 minecraft:stone_bricks
fill 417 15 215 417 18 215 minecraft:mossy_cobblestone
setblock 417 15 219 minecraft:stone_bricks
fill 417 15 220 417 18 220 minecraft:mossy_cobblestone
setblock 377 16 193 minecraft:stone_bricks
fill 377 16 194 377 19 194 minecraft:mossy_cobblestone
setblock 377 16 198 minecraft:stone_bricks
fill 377 16 199 377 19 199 minecraft:mossy_cobblestone
setblock 377 16 203 minecraft:stone_bricks
fill 377 16 204 377 19 204 minecraft:mossy_cobblestone
setblock 377 16 218 minecraft:stone_bricks
setblock 377 16 219 minecraft:mossy_cobblestone
setblock 378 16 197 minecraft:stone_bricks
fill 378 16 198 378 19 198 minecraft:mossy_cobblestone
setblock 378 16 202 minecraft:stone_bricks
fill 386 16 182 386 17 182 minecraft:mossy_cobblestone
fill 386 16 222 386 17 222 minecraft:mossy_cobblestone
setblock 388 16 182 minecraft:stone_bricks
setblock 388 16 222 minecraft:stone_bricks
fill 389 16 182 389 18 183 minecraft:mossy_cobblestone
setblock 389 16 221 minecraft:stone_bricks
fill 389 16 222 389 19 222 minecraft:mossy_cobblestone
fill 390 16 221 390 19 221 minecraft:mossy_cobblestone
fill 391 16 220 391 19 220 minecraft:mossy_cobblestone
setblock 392 16 183 minecraft:stone_bricks
setblock 393 16 182 minecraft:stone_bricks
fill 393 16 183 393 19 183 minecraft:mossy_cobblestone
setblock 393 16 222 minecraft:stone_bricks
fill 394 16 182 394 19 182 minecraft:mossy_cobblestone
setblock 394 16 221 minecraft:stone_bricks
fill 394 16 222 394 19 222 minecraft:mossy_cobblestone
setblock 395 16 220 minecraft:stone_bricks
fill 395 16 221 395 19 221 minecraft:mossy_cobblestone
setblock 396 16 220 minecraft:mossy_cobblestone
setblock 398 16 182 minecraft:stone_bricks
setblock 398 16 222 minecraft:stone_bricks
fill 399 16 182 399 19 182 minecraft:mossy_cobblestone
setblock 399 16 221 minecraft:stone_bricks
fill 399 16 222 399 19 222 minecraft:mossy_cobblestone
fill 400 16 221 403 16 221 minecraft:mossy_cobblestone
setblock 403 16 222 minecraft:stone_bricks
setblock 404 16 221 minecraft:stone_bricks
fill 404 16 222 404 19 222 minecraft:mossy_cobblestone
fill 405 16 221 405 19 221 minecraft:mossy_cobblestone
fill 407 16 220 407 18 220 minecraft:mossy_cobblestone
setblock 408 16 222 minecraft:stone_bricks
fill 409 16 182 409 19 182 minecraft:mossy_cobblestone
setblock 409 16 221 minecraft:stone_bricks
fill 409 16 222 409 19 222 minecraft:mossy_cobblestone
setblock 410 16 220 minecraft:stone_bricks
fill 410 16 221 410 19 221 minecraft:mossy_cobblestone
fill 411 16 220 411 19 220 minecraft:mossy_cobblestone
setblock 413 16 182 minecraft:stone_bricks
setblock 413 16 222 minecraft:stone_bricks
setblock 414 16 221 minecraft:stone_bricks
fill 414 16 222 414 19 222 minecraft:mossy_cobblestone
setblock 415 16 199 minecraft:mossy_cobblestone
setblock 415 16 200 minecraft:stone_bricks
fill 415 16 201 415 19 201 minecraft:mossy_cobblestone
setblock 415 16 216 minecraft:mossy_cobblestone
setblock 415 16 220 minecraft:stone_bricks
fill 415 16 221 415 19 221 minecraft:mossy_cobblestone
setblock 416 16 195 minecraft:mossy_cobblestone
setblock 416 16 199 minecraft:stone_bricks
fill 416 16 200 416 19 200 minecraft:mossy_cobblestone
setblock 416 16 204 minecraft:stone_bricks
setblock 416 16 214 minecraft:stone_bricks
setblock 416 16 215 minecraft:mossy_cobblestone
setblock 416 16 219 minecraft:stone_bricks
fill 416 16 220 416 19 220 minecraft:mossy_cobblestone
setblock 417 16 193 minecraft:stone_bricks
fill 417 16 194 417 18 194 minecraft:mossy_cobblestone
setblock 417 16 198 minecraft:stone_bricks
fill 417 16 199 417 19 199 minecraft:mossy_cobblestone
setblock 417 16 203 minecraft:stone_bricks
fill 417 16 204 417 19 204 minecraft:mossy_cobblestone
setblock 417 16 208 minecraft:stone_bricks
setblock 417 16 209 minecraft:mossy_cobblestone
setblock 417 16 213 minecraft:stone_bricks
fill 417 16 214 417 17 214 minecraft:mossy_cobblestone
setblock 417 16 218 minecraft:stone_bricks
fill 417 16 219 417 19 219 minecraft:mossy_cobblestone
setblock 377 17 192 minecraft:stone_bricks
fill 377 17 193 377 20 193 minecraft:mossy_cobblestone
setblock 377 17 197 minecraft:stone_bricks
fill 377 17 198 377 20 198 minecraft:mossy_cobblestone
setblock 377 17 202 minecraft:stone_bricks
fill 377 17 203 377 20 203 minecraft:mossy_cobblestone
setblock 378 17 196 minecraft:stone_bricks
fill 378 17 197 378 20 197 minecraft:mossy_cobblestone
setblock 378 17 201 minecraft:stone_bricks
fill 378 17 202 378 20 202 minecraft:mossy_cobblestone
setblock 379 17 184 minecraft:light[level=12]
setblock 379 17 192 minecraft:light[level=12]
setblock 379 17 200 minecraft:light[level=12]
setblock 379 17 208 minecraft:light[level=12]
setblock 379 17 216 minecraft:light[level=12]
fill 385 17 182 385 18 182 minecraft:mossy_cobblestone
fill 385 17 222 385 18 222 minecraft:mossy_cobblestone
setblock 387 17 182 minecraft:stone_bricks
setblock 387 17 184 minecraft:light[level=12]
setblock 387 17 192 minecraft:light[level=12]
setblock 387 17 200 minecraft:light[level=12]
setblock 387 17 208 minecraft:light[level=12]
setblock 387 17 216 minecraft:light[level=12]
setblock 387 17 222 minecraft:stone_bricks
fill 388 17 182 388 19 183 minecraft:mossy_cobblestone
setblock 388 17 221 minecraft:stone_bricks
fill 388 17 222 388 20 222 minecraft:mossy_cobblestone
fill 389 17 221 389 20 221 minecraft:mossy_cobblestone
setblock 391 17 183 minecraft:stone_bricks
setblock 392 17 182 minecraft:stone_bricks
fill 392 17 183 392 20 183 minecraft:mossy_cobblestone
setblock 392 17 222 minecraft:stone_bricks
fill 393 17 182 393 20 182 minecraft:mossy_cobblestone
setblock 393 17 221 minecraft:stone_bricks
fill 393 17 222 393 20 222 minecraft:mossy_cobblestone
setblock 394 17 220 minecraft:stone_bricks
fill 394 17 221 394 20 221 minecraft:mossy_cobblestone
setblock 395 17 184 minecraft:light[level=12]
setblock 395 17 192 minecraft:light[level=12]
setblock 395 17 200 minecraft:light[level=12]
setblock 395 17 208 minecraft:light[level=12]
setblock 395 17 216 minecraft:light[level=12]
fill 395 17 220 395 20 220 minecraft:mossy_cobblestone
setblock 396 17 183 minecraft:stone_bricks
setblock 397 17 182 minecraft:stone_bricks
setblock 397 17 222 minecraft:stone_bricks
fill 398 17 182 398 20 182 minecraft:mossy_cobblestone
setblock 398 17 221 minecraft:stone_bricks
fill 398 17 222 398 20 222 minecraft:mossy_cobblestone
fill 399 17 221 402 17 221 minecraft:mossy_cobblestone
setblock 402 17 222 minecraft:stone_bricks
setblock 403 17 184 minecraft:light[level=12]
setblock 403 17 192 minecraft:light[level=12]
setblock 403 17 200 minecraft:light[level=12]
setblock 403 17 208 minecraft:light[level=12]
setblock 403 17 216 minecraft:light[level=12]
setblock 403 17 221 minecraft:stone_bricks
fill 403 17 222 403 20 222 minecraft:mossy_cobblestone
fill 404 17 221 404 20 221 minecraft:mossy_cobblestone
setblock 407 17 182 minecraft:stone_bricks
setblock 407 17 222 minecraft:stone_bricks
fill 408 17 182 408 20 182 minecraft:mossy_cobblestone
setblock 408 17 221 minecraft:stone_bricks
fill 408 17 222 408 20 222 minecraft:mossy_cobblestone
setblock 409 17 220 minecraft:stone_bricks
fill 409 17 221 409 20 221 minecraft:mossy_cobblestone
fill 410 17 220 410 20 220 minecraft:mossy_cobblestone
setblock 411 17 184 minecraft:light[level=12]
setblock 411 17 192 minecraft:light[level=12]
setblock 411 17 200 minecraft:light[level=12]
setblock 411 17 208 minecraft:light[level=12]
setblock 411 17 216 minecraft:light[level=12]
setblock 412 17 182 minecraft:stone_bricks
setblock 412 17 222 minecraft:stone_bricks
fill 413 17 182 414 19 182 minecraft:mossy_cobblestone
setblock 413 17 221 minecraft:stone_bricks
fill 413 17 222 413 20 222 minecraft:mossy_cobblestone
setblock 414 17 220 minecraft:stone_bricks
fill 414 17 221 414 20 221 minecraft:mossy_cobblestone
setblock 415 17 199 minecraft:stone_bricks
fill 415 17 200 415 20 200 minecraft:mossy_cobblestone
fill 415 17 202 415 18 202 minecraft:mossy_cobblestone
setblock 416 17 198 minecraft:stone_bricks
fill 416 17 199 416 20 199 minecraft:mossy_cobblestone
setblock 416 17 203 minecraft:stone_bricks
fill 416 17 204 416 19 205 minecraft:mossy_cobblestone
setblock 416 17 218 minecraft:stone_bricks
fill 416 17 219 416 18 219 minecraft:mossy_cobblestone
setblock 417 17 197 minecraft:stone_bricks
fill 417 17 198 417 20 198 minecraft:mossy_cobblestone
setblock 417 17 202 minecraft:stone_bricks
fill 417 17 203 417 20 203 minecraft:mossy_cobblestone
setblock 417 17 207 minecraft:stone_bricks
fill 417 17 208 417 20 208 minecraft:mossy_cobblestone
setblock 417 17 212 minecraft:stone_bricks
setblock 417 17 213 minecraft:mossy_cobblestone
setblock 417 17 217 minecraft:stone_bricks
fill 417 17 218 417 20 218 minecraft:mossy_cobblestone
setblock 417 17 222 minecraft:stone_bricks
setblock 377 18 192 minecraft:mossy_cobblestone
setblock 377 18 196 minecraft:stone_bricks
fill 377 18 197 377 21 197 minecraft:mossy_cobblestone
setblock 377 18 201 minecraft:stone_bricks
fill 377 18 202 377 21 202 minecraft:mossy_cobblestone
fill 378 18 196 378 19 196 minecraft:mossy_cobblestone
setblock 378 18 200 minecraft:stone_bricks
fill 378 18 201 378 21 201 minecraft:mossy_cobblestone
fill 383 18 182 384 19 182 minecraft:mossy_cobblestone
fill 384 18 222 384 19 222 minecraft:mossy_cobblestone
setblock 386 18 182 minecraft:stone_bricks
fill 386 18 183 387 20 183 minecraft:mossy_cobblestone
setblock 386 18 222 minecraft:stone_bricks
fill 387 18 182 387 21 182 minecraft:mossy_cobblestone
setblock 387 18 221 minecraft:stone_bricks
fill 387 18 222 387 21 222 minecraft:mossy_cobblestone
fill 388 18 221 388 21 221 minecraft:mossy_cobblestone
setblock 390 18 183 minecraft:stone_bricks
fill 390 18 184 392 19 184 minecraft:mossy_cobblestone
fill 390 18 220 390 20 220 minecraft:mossy_cobblestone
setblock 391 18 182 minecraft:stone_bricks
fill 391 18 183 391 21 183 minecraft:mossy_cobblestone
setblock 391 18 222 minecraft:stone_bricks
fill 392 18 182 392 21 182 minecraft:mossy_cobblestone
setblock 392 18 221 minecraft:stone_bricks
fill 392 18 222 392 21 222 minecraft:mossy_cobblestone
setblock 393 18 220 minecraft:stone_bricks
fill 393 18 221 393 21 221 minecraft:mossy_cobblestone
fill 394 18 220 394 21 220 minecraft:mossy_cobblestone
setblock 395 18 183 minecraft:stone_bricks
setblock 396 18 182 minecraft:stone_bricks
fill 396 18 183 396 21 183 minecraft:mossy_cobblestone
setblock 396 18 222 minecraft:stone_bricks
fill 397 18 182 397 21 182 minecraft:mossy_cobblestone
setblock 397 18 221 minecraft:stone_bricks
fill 397 18 222 397 21 222 minecraft:mossy_cobblestone
fill 398 18 221 401 18 221 minecraft:mossy_cobblestone
setblock 400 18 182 minecraft:mossy_cobblestone
setblock 401 18 222 minecraft:stone_bricks
setblock 402 18 221 minecraft:stone_bricks
fill 402 18 222 402 21 222 minecraft:mossy_cobblestone
fill 403 18 221 403 21 221 minecraft:mossy_cobblestone
setblock 405 18 182 minecraft:mossy_cobblestone
setblock 406 18 182 minecraft:stone_bricks
fill 406 18 220 406 19 220 minecraft:mossy_cobblestone
setblock 406 18 222 minecraft:stone_bricks
fill 407 18 182 407 21 182 minecraft:mossy_cobblestone
setblock 407 18 221 minecraft:stone_bricks
fill 407 18 222 407 21 222 minecraft:mossy_cobblestone
setblock 408 18 220 minecraft:stone_bricks
fill 408 18 221 408 21 221 minecraft:mossy_cobblestone
fill 409 18 220 409 21 220 minecraft:mossy_cobblestone
setblock 411 18 182 minecraft:stone_bricks
setblock 411 18 222 minecraft:stone_bricks
fill 412 18 182 412 21 182 minecraft:mossy_cobblestone
setblock 412 18 221 minecraft:stone_bricks
fill 412 18 222 412 21 222 minecraft:mossy_cobblestone
setblock 413 18 220 minecraft:stone_bricks
fill 413 18 221 413 21 221 minecraft:mossy_cobblestone
setblock 414 18 220 minecraft:mossy_cobblestone
fill 415 18 199 415 21 199 minecraft:mossy_cobblestone
setblock 415 18 203 minecraft:stone_bricks
setblock 416 18 197 minecraft:stone_bricks
fill 416 18 198 416 21 198 minecraft:mossy_cobblestone
setblock 416 18 202 minecraft:stone_bricks
fill 416 18 203 416 21 203 minecraft:mossy_cobblestone
setblock 416 18 206 minecraft:mossy_cobblestone
setblock 416 18 218 minecraft:mossy_cobblestone
setblock 416 18 222 minecraft:stone_bricks
setblock 417 18 196 minecraft:stone_bricks
fill 417 18 197 417 21 197 minecraft:mossy_cobblestone
setblock 417 18 201 minecraft:stone_bricks
fill 417 18 202 417 21 202 minecraft:mossy_cobblestone
setblock 417 18 206 minecraft:stone_bricks
fill 417 18 207 417 21 207 minecraft:mossy_cobblestone
setblock 417 18 216 minecraft:stone_bricks
fill 417 18 217 417 19 217 minecraft:mossy_cobblestone
setblock 417 18 221 minecraft:stone_bricks
fill 417 18 222 417 21 222 minecraft:mossy_cobblestone
fill 377 19 182 377 21 182 minecraft:mossy_cobblestone
setblock 377 19 195 minecraft:stone_bricks
fill 377 19 196 377 22 196 minecraft:mossy_cobblestone
setblock 377 19 200 minecraft:stone_bricks
fill 377 19 201 377 22 201 minecraft:mossy_cobblestone
setblock 377 19 205 minecraft:stone_bricks
fill 377 19 206 377 22 206 minecraft:mossy_cobblestone
setblock 378 19 199 minecraft:stone_bricks
fill 378 19 200 378 22 200 minecraft:mossy_cobblestone
fill 381 19 182 382 21 182 minecraft:mossy_cobblestone
fill 383 19 222 383 20 222 minecraft:mossy_cobblestone
setblock 385 19 182 minecraft:stone_bricks
fill 385 19 183 385 22 183 minecraft:mossy_cobblestone
setblock 385 19 222 minecraft:stone_bricks
fill 386 19 182 386 22 182 minecraft:mossy_cobblestone
setblock 386 19 221 minecraft:stone_bricks
fill 386 19 222 386 22 222 minecraft:mossy_cobblestone
fill 387 19 221 387 22 221 minecraft:mossy_cobblestone
setblock 388 19 184 minecraft:stone_bricks
setblock 389 19 182 minecraft:mossy_cobblestone
setblock 389 19 183 minecraft:stone_bricks
fill 389 19 184 389 22 184 minecraft:mossy_cobblestone
fill 389 19 220 389 21 220 minecraft:mossy_cobblestone
setblock 390 19 182 minecraft:stone_bricks
fill 390 19 183 390 22 183 minecraft:mossy_cobblestone
setblock 390 19 222 minecraft:stone_bricks
fill 391 19 182 391 22 182 minecraft:mossy_cobblestone
setblock 391 19 221 minecraft:stone_bricks
fill 391 19 222 391 22 222 minecraft:mossy_cobblestone
setblock 392 19 220 minecraft:stone_bricks
fill 392 19 221 392 22 221 minecraft:mossy_cobblestone
setblock 393 19 184 minecraft:stone_bricks
fill 393 19 220 393 22 220 minecraft:mossy_cobblestone
setblock 394 19 183 minecraft:stone_bricks
setblock 395 19 182 minecraft:stone_bricks
fill 395 19 183 395 22 183 minecraft:mossy_cobblestone
setblock 395 19 222 minecraft:stone_bricks
fill 396 19 182 396 22 182 minecraft:mossy_cobblestone
setblock 396 19 221 minecraft:stone_bricks
fill 396 19 222 396 22 222 minecraft:mossy_cobblestone
fill 397 19 221 400 19 221 minecraft:mossy_cobblestone
setblock 400 19 182 minecraft:stone_bricks
setblock 400 19 222 minecraft:stone_bricks
fill 401 19 182 404 19 182 minecraft:mossy_cobblestone
setblock 401 19 221 minecraft:stone_bricks
fill 401 19 222 401 22 222 minecraft:mossy_cobblestone
fill 402 19 221 402 22 221 minecraft:mossy_cobblestone
setblock 405 19 182 minecraft:stone_bricks
fill 405 19 220 405 20 220 minecraft:mossy_cobblestone
setblock 405 19 222 minecraft:stone_bricks
fill 406 19 182 406 22 182 minecraft:mossy_cobblestone
setblock 406 19 221 minecraft:stone_bricks
fill 406 19 222 406 22 222 minecraft:mossy_cobblestone
setblock 407 19 220 minecraft:stone_bricks
fill 407 19 221 407 22 221 minecraft:mossy_cobblestone
fill 408 19 220 408 22 220 minecraft:mossy_cobblestone
setblock 410 19 182 minecraft:stone_bricks
setblock 410 19 222 minecraft:stone_bricks
fill 411 19 182 411 22 182 minecraft:mossy_cobblestone
setblock 411 19 221 minecraft:stone_bricks
fill 411 19 222 411 22 222 minecraft:mossy_cobblestone
setblock 412 19 220 minecraft:stone_bricks
fill 412 19 221 412 22 221 minecraft:mossy_cobblestone
fill 413 19 220 413 21 220 minecraft:mossy_cobblestone
setblock 415 19 182 minecraft:stone_bricks
setblock 415 19 202 minecraft:stone_bricks
fill 415 19 203 415 21 204 minecraft:mossy_cobblestone
setblock 415 19 222 minecraft:stone_bricks
fill 416 19 197 416 22 197 minecraft:mossy_cobblestone
setblock 416 19 201 minecraft:stone_bricks
fill 416 19 202 416 22 202 minecraft:mossy_cobblestone
setblock 416 19 206 minecraft:stone_bricks
fill 416 19 222 416 22 222 minecraft:mossy_cobblestone
setblock 417 19 195 minecraft:stone_bricks
fill 417 19 196 417 22 196 minecraft:mossy_cobblestone
setblock 417 19 200 minecraft:stone_bricks
fill 417 19 201 417 22 201 minecraft:mossy_cobblestone
setblock 417 19 205 minecraft:stone_bricks
fill 417 19 206 417 22 206 minecraft:mossy_cobblestone
setblock 417 19 209 minecraft:mossy_cobblestone
setblock 417 19 216 minecraft:mossy_cobblestone
setblock 417 19 220 minecraft:stone_bricks
fill 417 19 221 417 22 221 minecraft:mossy_cobblestone
setblock 377 20 183 minecraft:mossy_cobblestone
setblock 377 20 184 minecraft:stone_bricks
setblock 377 20 194 minecraft:stone_bricks
fill 377 20 195 377 23 195 minecraft:mossy_cobblestone
setblock 377 20 199 minecraft:stone_bricks
fill 377 20 200 377 23 200 minecraft:mossy_cobblestone
setblock 377 20 204 minecraft:stone_bricks
fill 377 20 205 377 23 205 minecraft:mossy_cobblestone
setblock 378 20 182 minecraft:mossy_cobblestone
setblock 378 20 198 minecraft:stone_bricks
fill 378 20 199 378 23 199 minecraft:mossy_cobblestone
setblock 378 20 203 minecraft:stone_bricks
setblock 379 20 182 minecraft:stone_bricks
fill 380 20 182 380 23 182 minecraft:mossy_cobblestone
fill 382 20 222 382 21 222 minecraft:mossy_cobblestone
setblock 383 20 182 minecraft:mossy_cobblestone
setblock 383 20 183 minecraft:stone_bricks
setblock 384 20 182 minecraft:stone_bricks
fill 384 20 183 384 23 183 minecraft:mossy_cobblestone
setblock 384 20 222 minecraft:stone_bricks
fill 385 20 182 385 23 182 minecraft:mossy_cobblestone
setblock 385 20 221 minecraft:stone_bricks
fill 385 20 222 385 23 222 minecraft:mossy_cobblestone
setblock 386 20 184 minecraft:mossy_cobblestone
fill 386 20 221 386 23 221 minecraft:mossy_cobblestone
setblock 387 20 184 minecraft:stone_bricks
setblock 388 20 182 minecraft:mossy_cobblestone
setblock 388 20 183 minecraft:stone_bricks
fill 388 20 184 388 23 184 minecraft:mossy_cobblestone
fill 388 20 220 388 22 220 minecraft:mossy_cobblestone
setblock 389 20 182 minecraft:stone_bricks
fill 389 20 183 389 23 183 minecraft:mossy_cobblestone
setblock 389 20 222 minecraft:stone_bricks
fill 390 20 182 390 23 182 minecraft:mossy_cobblestone
fill 390 20 184 391 20 184 minecraft:mossy_cobblestone
setblock 390 20 221 minecraft:stone_bricks
fill 390 20 222 390 23 222 minecraft:mossy_cobblestone
setblock 391 20 220 minecraft:stone_bricks
fill 391 20 221 391 23 221 minecraft:mossy_cobblestone
setblock 392 20 184 minecraft:stone_bricks
fill 392 20 220 392 23 220 minecraft:mossy_cobblestone
setblock 393 20 183 minecraft:stone_bricks
fill 393 20 184 394 22 184 minecraft:mossy_cobblestone
setblock 394 20 182 minecraft:stone_bricks
fill 394 20 183 394 23 183 minecraft:mossy_cobblestone
setblock 394 20 222 minecraft:stone_bricks
fill 395 20 182 395 23 182 minecraft:mossy_cobblestone
setblock 395 20 221 minecraft:stone_bricks
fill 395 20 222 395 23 222 minecraft:mossy_cobblestone
fill 396 20 221 399 20 221 minecraft:mossy_cobblestone
setblock 397 20 183 minecraft:mossy_cobblestone
setblock 399 20 182 minecraft:stone_bricks
setblock 399 20 222 minecraft:stone_bricks
fill 400 20 182 403 20 182 minecraft:mossy_cobblestone
setblock 400 20 221 minecraft:stone_bricks
fill 400 20 222 400 23 222 minecraft:mossy_cobblestone
fill 401 20 221 401 23 221 minecraft:mossy_cobblestone
setblock 404 20 182 minecraft:stone_bricks
fill 404 20 220 404 21 220 minecraft:mossy_cobblestone
setblock 404 20 222 minecraft:stone_bricks
fill 405 20 182 405 23 182 minecraft:mossy_cobblestone
setblock 405 20 221 minecraft:stone_bricks
fill 405 20 222 405 23 222 minecraft:mossy_cobblestone
setblock 406 20 220 minecraft:stone_bricks
fill 406 20 221 406 23 221 minecraft:mossy_cobblestone
setblock 407 20 183 minecraft:mossy_cobblestone
fill 407 20 220 407 23 220 minecraft:mossy_cobblestone
setblock 408 20 183 minecraft:stone_bricks
setblock 409 20 182 minecraft:stone_bricks
fill 409 20 183 411 21 183 minecraft:mossy_cobblestone
setblock 409 20 222 minecraft:stone_bricks
fill 410 20 182 410 23 182 minecraft:mossy_cobblestone
setblock 410 20 221 minecraft:stone_bricks
fill 410 20 222 410 23 222 minecraft:mossy_cobblestone
setblock 411 20 220 minecraft:stone_bricks
fill 411 20 221 411 23 221 minecraft:mossy_cobblestone
fill 412 20 220 412 22 220 minecraft:mossy_cobblestone
setblock 413 20 182 minecraft:mossy_cobblestone
setblock 414 20 182 minecraft:stone_bricks
setblock 414 20 222 minecraft:stone_bricks
fill 415 20 182 416 22 182 minecraft:mossy_cobblestone
setblock 415 20 201 minecraft:stone_bricks
fill 415 20 202 415 23 202 minecraft:mossy_cobblestone
setblock 415 20 205 minecraft:mossy_cobblestone
setblock 415 20 221 minecraft:stone_bricks
fill 415 20 222 415 23 222 minecraft:mossy_cobblestone
setblock 416 20 200 minecraft:stone_bricks
fill 416 20 201 416 23 201 minecraft:mossy_cobblestone
setblock 416 20 204 minecraft:mossy_cobblestone
setblock 416 20 205 minecraft:stone_bricks
fill 416 20 206 416 22 207 minecraft:mossy_cobblestone
fill 417 20 195 417 23 195 minecraft:mossy_cobblestone
setblock 417 20 199 minecraft:stone_bricks
fill 417 20 200 417 23 200 minecraft:mossy_cobblestone
setblock 417 20 204 minecraft:stone_bricks
fill 417 20 205 417 23 205 minecraft:mossy_cobblestone
setblock 417 20 209 minecraft:stone_bricks
setblock 417 20 219 minecraft:stone_bricks
fill 417 20 220 417 21 220 minecraft:mossy_cobblestone
setblock 377 21 183 minecraft:stone_bricks
fill 377 21 184 377 22 186 minecraft:mossy_cobblestone
setblock 377 21 193 minecraft:stone_bricks
fill 377 21 194 377 24 194 minecraft:mossy_cobblestone
setblock 377 21 198 minecraft:stone_bricks
fill 377 21 199 377 24 199 minecraft:mossy_cobblestone
setblock 377 21 203 minecraft:stone_bricks
fill 377 21 204 378 23 204 minecraft:mossy_cobblestone
setblock 377 21 207 minecraft:mossy_cobblestone
setblock 378 21 182 minecraft:stone_bricks
setblock 378 21 197 minecraft:stone_bricks
fill 378 21 198 378 23 198 minecraft:mossy_cobblestone
setblock 378 21 202 minecraft:stone_bricks
fill 378 21 203 378 24 203 minecraft:mossy_cobblestone
fill 379 21 182 379 24 182 minecraft:mossy_cobblestone
fill 380 21 222 381 22 222 minecraft:mossy_cobblestone
setblock 381 21 183 minecraft:mossy_cobblestone
setblock 382 21 183 minecraft:stone_bricks
setblock 383 21 182 minecraft:stone_bricks
fill 383 21 183 383 24 183 minecraft:mossy_cobblestone
setblock 383 21 222 minecraft:stone_bricks
fill 384 21 182 384 24 182 minecraft:mossy_cobblestone
fill 384 21 184 385 21 184 minecraft:mossy_cobblestone
setblock 384 21 221 minecraft:stone_bricks
fill 384 21 222 384 24 222 minecraft:mossy_cobblestone
fill 385 21 221 385 24 221 minecraft:mossy_cobblestone
setblock 386 21 183 minecraft:mossy_cobblestone
setblock 386 21 184 minecraft:stone_bricks
setblock 387 21 183 minecraft:stone_bricks
fill 387 21 184 387 24 184 minecraft:mossy_cobblestone
fill 387 21 220 387 23 220 minecraft:mossy_cobblestone
setblock 388 21 182 minecraft:stone_bricks
fill 388 21 183 388 24 183 minecraft:mossy_cobblestone
fill 388 21 185 389 21 185 minecraft:mossy_cobblestone
setblock 388 21 222 minecraft:stone_bricks
fill 389 21 182 389 24 182 minecraft:mossy_cobblestone
setblock 389 21 221 minecraft:stone_bricks
fill 389 21 222 389 24 222 minecraft:mossy_cobblestone
setblock 390 21 184 minecraft:mossy_cobblestone
setblock 390 21 185 minecraft:stone_bricks
setblock 390 21 220 minecraft:stone_bricks
fill 390 21 221 390 24 221 minecraft:mossy_cobblestone
setblock 391 21 184 minecraft:stone_bricks
fill 391 21 220 391 24 220 minecraft:mossy_cobblestone
setblock 392 21 183 minecraft:stone_bricks
fill 392 21 184 392 24 184 minecraft:mossy_cobblestone
setblock 393 21 182 minecraft:stone_bricks
fill 393 21 183 393 24 183 minecraft:mossy_cobblestone
setblock 393 21 222 minecraft:stone_bricks
fill 394 21 182 394 24 182 minecraft:mossy_cobblestone
setblock 394 21 221 minecraft:stone_bricks
fill 394 21 222 394 24 222 minecraft:mossy_cobblestone
setblock 395 21 220 minecraft:stone_bricks
fill 395 21 221 398 21 221 minecraft:mossy_cobblestone
setblock 397 21 183 minecraft:stone_bricks
setblock 398 21 182 minecraft:stone_bricks
fill 398 21 183 398 24 183 minecraft:mossy_cobblestone
setblock 398 21 222 minecraft:stone_bricks
fill 399 21 182 402 21 182 minecraft:mossy_cobblestone
setblock 399 21 221 minecraft:stone_bricks
fill 399 21 222 399 24 222 minecraft:mossy_cobblestone
fill 400 21 221 400 24 221 minecraft:mossy_cobblestone
setblock 403 21 182 minecraft:stone_bricks
fill 403 21 220 403 22 220 minecraft:mossy_cobblestone
setblock 403 21 222 minecraft:stone_bricks
fill 404 21 182 404 23 183 minecraft:mossy_cobblestone
setblock 404 21 221 minecraft:stone_bricks
fill 404 21 222 404 24 222 minecraft:mossy_cobblestone
fill 405 21 183 406 21 183 minecraft:mossy_cobblestone
setblock 405 21 220 minecraft:stone_bricks
fill 405 21 221 405 24 221 minecraft:mossy_cobblestone
fill 406 21 220 406 24 220 minecraft:mossy_cobblestone
setblock 407 21 183 minecraft:stone_bricks
setblock 408 21 182 minecraft:stone_bricks
fill 408 21 183 408 24 183 minecraft:mossy_cobblestone
setblock 408 21 222 minecraft:stone_bricks
fill 409 21 182 409 24 182 minecraft:mossy_cobblestone
setblock 409 21 221 minecraft:stone_bricks
fill 409 21 222 409 24 222 minecraft:mossy_cobblestone
setblock 410 21 220 minecraft:stone_bricks
fill 410 21 221 410 24 221 minecraft:mossy_cobblestone
fill 411 21 220 411 23 220 minecraft:mossy_cobblestone
schedule function dropper:buildpart/44_3 1t
