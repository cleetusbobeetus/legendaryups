setblock 356 193 310 minecraft:light[level=15]
setblock 364 193 278 minecraft:light[level=15]
setblock 364 193 286 minecraft:light[level=15]
setblock 364 193 294 minecraft:light[level=15]
setblock 364 193 302 minecraft:light[level=15]
setblock 364 193 310 minecraft:light[level=15]
fill 329 194 300 329 202 300 minecraft:light_blue_terracotta
fill 338 194 287 338 198 287 minecraft:dirt
fill 338 194 289 338 198 289 minecraft:dirt
fill 341 194 288 341 198 288 minecraft:dirt
fill 366 194 295 367 195 296 minecraft:white_concrete
setblock 371 194 277 minecraft:white_wool
fill 371 194 289 371 218 290 minecraft:light_blue_terracotta
setblock 371 194 291 minecraft:white_wool
fill 337 195 288 337 198 288 minecraft:dirt
fill 338 195 286 340 198 286 minecraft:dirt
fill 339 195 290 340 198 290 minecraft:dirt
fill 341 195 287 341 198 287 minecraft:dirt
fill 341 195 289 341 198 289 minecraft:dirt
fill 362 195 286 362 196 286 minecraft:ochre_froglight
fill 371 195 277 371 218 277 minecraft:light_blue_terracotta
fill 371 195 291 371 218 291 minecraft:light_blue_terracotta
fill 337 196 287 337 198 287 minecraft:dirt
fill 337 196 289 337 198 289 minecraft:dirt
fill 338 196 290 338 198 290 minecraft:dirt
fill 341 196 286 341 198 286 minecraft:dirt
fill 341 196 290 341 198 290 minecraft:dirt
fill 342 196 288 342 198 288 minecraft:dirt
setblock 349 196 275 minecraft:white_wool
setblock 332 197 278 minecraft:light[level=12]
setblock 332 197 285 minecraft:light[level=12]
setblock 332 197 292 minecraft:light[level=12]
setblock 332 197 299 minecraft:light[level=12]
setblock 332 197 306 minecraft:light[level=12]
setblock 332 197 313 minecraft:light[level=12]
fill 337 197 286 337 198 286 minecraft:dirt
fill 337 197 290 337 198 290 minecraft:dirt
fill 338 197 285 340 198 285 minecraft:dirt
setblock 339 197 278 minecraft:light[level=12]
fill 339 197 291 340 198 291 minecraft:dirt
setblock 339 197 292 minecraft:light[level=12]
setblock 339 197 299 minecraft:light[level=12]
setblock 339 197 306 minecraft:light[level=12]
setblock 339 197 313 minecraft:light[level=12]
fill 342 197 287 342 198 287 minecraft:dirt
fill 342 197 289 342 198 289 minecraft:dirt
setblock 346 197 278 minecraft:light[level=12]
setblock 346 197 285 minecraft:light[level=12]
setblock 346 197 292 minecraft:light[level=12]
setblock 346 197 299 minecraft:light[level=12]
setblock 346 197 306 minecraft:light[level=12]
setblock 346 197 313 minecraft:light[level=12]
fill 349 197 275 349 218 275 minecraft:light_blue_terracotta
setblock 353 197 278 minecraft:light[level=12]
setblock 353 197 285 minecraft:light[level=12]
setblock 353 197 292 minecraft:light[level=12]
setblock 353 197 299 minecraft:light[level=12]
setblock 353 197 306 minecraft:light[level=12]
setblock 353 197 313 minecraft:light[level=12]
setblock 360 197 278 minecraft:light[level=12]
setblock 360 197 285 minecraft:light[level=12]
setblock 360 197 292 minecraft:light[level=12]
fill 360 197 294 361 198 294 minecraft:white_concrete
setblock 360 197 299 minecraft:light[level=12]
setblock 360 197 306 minecraft:light[level=12]
setblock 360 197 313 minecraft:light[level=12]
fill 362 197 286 362 205 286 minecraft:dirt
setblock 367 197 278 minecraft:light[level=12]
setblock 367 197 285 minecraft:light[level=12]
setblock 367 197 292 minecraft:light[level=12]
setblock 367 197 299 minecraft:light[level=12]
setblock 367 197 306 minecraft:light[level=12]
setblock 367 197 313 minecraft:light[level=12]
setblock 371 197 293 minecraft:white_wool
fill 336 198 287 336 198 289 minecraft:dirt
setblock 337 198 285 minecraft:dirt
setblock 338 198 291 minecraft:dirt
setblock 339 198 275 minecraft:white_wool
setblock 341 198 285 minecraft:dirt
setblock 341 198 291 minecraft:dirt
setblock 342 198 286 minecraft:dirt
setblock 342 198 290 minecraft:dirt
setblock 355 198 275 minecraft:white_wool
fill 371 198 293 371 218 293 minecraft:light_blue_terracotta
fill 371 198 314 371 205 315 minecraft:light_blue_terracotta
setblock 371 198 316 minecraft:white_wool
fill 339 199 275 339 216 275 minecraft:light_blue_terracotta
fill 339 199 288 339 202 288 minecraft:white_concrete
fill 355 199 275 355 218 275 minecraft:light_blue_terracotta
fill 361 199 286 361 205 287 minecraft:dirt
fill 362 199 287 362 205 287 minecraft:dirt
fill 363 199 305 364 200 305 minecraft:white_concrete
fill 364 199 304 364 200 304 minecraft:white_concrete
fill 364 199 306 364 200 306 minecraft:white_concrete
fill 371 199 316 371 218 316 minecraft:light_blue_terracotta
fill 361 200 285 362 205 285 minecraft:dirt
fill 363 200 286 363 205 287 minecraft:dirt
setblock 371 200 278 minecraft:white_wool
setblock 332 201 278 minecraft:light[level=15]
setblock 332 201 286 minecraft:light[level=15]
setblock 332 201 294 minecraft:light[level=15]
setblock 332 201 302 minecraft:light[level=15]
setblock 332 201 310 minecraft:light[level=15]
setblock 340 201 278 minecraft:light[level=15]
setblock 340 201 286 minecraft:light[level=15]
setblock 340 201 294 minecraft:light[level=15]
setblock 340 201 302 minecraft:light[level=15]
setblock 340 201 310 minecraft:light[level=15]
setblock 348 201 278 minecraft:light[level=15]
setblock 348 201 286 minecraft:light[level=15]
setblock 348 201 294 minecraft:light[level=15]
setblock 348 201 302 minecraft:light[level=15]
setblock 348 201 310 minecraft:light[level=15]
setblock 356 201 278 minecraft:light[level=15]
setblock 356 201 286 minecraft:light[level=15]
setblock 356 201 294 minecraft:light[level=15]
setblock 356 201 302 minecraft:light[level=15]
setblock 356 201 310 minecraft:light[level=15]
fill 360 201 286 360 205 287 minecraft:dirt
fill 361 201 288 362 205 288 minecraft:dirt
fill 363 201 285 363 205 285 minecraft:dirt
setblock 364 201 278 minecraft:light[level=15]
setblock 364 201 286 minecraft:light[level=15]
setblock 364 201 294 minecraft:light[level=15]
setblock 364 201 302 minecraft:light[level=15]
setblock 364 201 310 minecraft:light[level=15]
fill 371 201 278 371 214 278 minecraft:light_blue_terracotta
setblock 371 201 286 minecraft:white_wool
fill 338 202 287 338 204 289 minecraft:oak_leaves[persistent=true]
fill 339 202 286 340 204 287 minecraft:oak_leaves[persistent=true]
fill 339 202 289 340 204 289 minecraft:oak_leaves[persistent=true]
fill 340 202 288 341 204 288 minecraft:oak_leaves[persistent=true]
fill 341 202 287 341 204 287 minecraft:oak_leaves[persistent=true]
fill 348 202 306 349 203 306 minecraft:white_concrete
fill 360 202 285 360 205 285 minecraft:dirt
fill 360 202 288 360 205 288 minecraft:dirt
fill 361 202 284 362 205 284 minecraft:dirt
fill 363 202 288 363 205 288 minecraft:dirt
fill 364 202 286 364 205 287 minecraft:dirt
fill 365 202 294 365 203 294 minecraft:white_concrete
fill 371 202 286 371 218 286 minecraft:light_blue_terracotta
setblock 371 202 308 minecraft:white_wool
fill 371 202 309 371 218 310 minecraft:light_blue_terracotta
setblock 329 203 300 minecraft:white_wool
setblock 330 203 275 minecraft:white_wool
setblock 332 203 278 minecraft:light[level=12]
setblock 332 203 285 minecraft:light[level=12]
setblock 332 203 292 minecraft:light[level=12]
setblock 332 203 299 minecraft:light[level=12]
setblock 332 203 306 minecraft:light[level=12]
setblock 332 203 313 minecraft:light[level=12]
setblock 337 203 288 minecraft:oak_leaves[persistent=true]
setblock 338 203 286 minecraft:oak_leaves[persistent=true]
setblock 339 203 278 minecraft:light[level=12]
setblock 339 203 285 minecraft:light[level=12]
fill 339 203 288 339 204 288 minecraft:oak_leaves[persistent=true]
fill 339 203 290 340 203 290 minecraft:oak_leaves[persistent=true]
setblock 339 203 292 minecraft:light[level=12]
setblock 339 203 299 minecraft:light[level=12]
setblock 339 203 306 minecraft:light[level=12]
setblock 339 203 313 minecraft:light[level=12]
setblock 341 203 289 minecraft:oak_leaves[persistent=true]
setblock 346 203 278 minecraft:light[level=12]
setblock 346 203 285 minecraft:light[level=12]
setblock 346 203 292 minecraft:light[level=12]
setblock 346 203 299 minecraft:light[level=12]
setblock 346 203 306 minecraft:light[level=12]
setblock 346 203 313 minecraft:light[level=12]
setblock 353 203 278 minecraft:light[level=12]
setblock 353 203 285 minecraft:light[level=12]
setblock 353 203 292 minecraft:light[level=12]
setblock 353 203 299 minecraft:light[level=12]
setblock 353 203 306 minecraft:light[level=12]
setblock 353 203 313 minecraft:light[level=12]
fill 359 203 285 359 205 287 minecraft:dirt
setblock 360 203 278 minecraft:light[level=12]
fill 360 203 284 360 205 284 minecraft:dirt
setblock 360 203 292 minecraft:light[level=12]
setblock 360 203 299 minecraft:light[level=12]
setblock 360 203 306 minecraft:light[level=12]
setblock 360 203 313 minecraft:light[level=12]
fill 361 203 289 363 205 289 minecraft:dirt
fill 363 203 284 363 205 284 minecraft:dirt
fill 364 203 285 364 205 285 minecraft:dirt
fill 364 203 288 364 205 288 minecraft:dirt
setblock 367 203 278 minecraft:light[level=12]
setblock 367 203 285 minecraft:light[level=12]
setblock 367 203 292 minecraft:light[level=12]
setblock 367 203 299 minecraft:light[level=12]
setblock 367 203 306 minecraft:light[level=12]
setblock 367 203 313 minecraft:light[level=12]
fill 371 203 308 371 216 308 minecraft:light_blue_terracotta
fill 329 204 300 329 216 300 minecraft:light_blue_terracotta
fill 330 204 275 330 208 275 minecraft:light_blue_terracotta
fill 343 204 297 345 209 297 minecraft:packed_mud
fill 344 204 296 344 209 296 minecraft:packed_mud
fill 344 204 298 345 209 298 minecraft:packed_mud
fill 347 204 297 348 209 297 minecraft:packed_mud
fill 348 204 295 348 209 296 minecraft:packed_mud
fill 349 204 296 349 209 296 minecraft:packed_mud
fill 359 204 288 359 205 288 minecraft:dirt
fill 360 204 289 360 205 289 minecraft:dirt
fill 361 204 283 362 205 283 minecraft:dirt
fill 364 204 284 364 205 284 minecraft:dirt
fill 365 204 286 365 205 287 minecraft:dirt
fill 341 205 297 342 208 297 minecraft:packed_mud
fill 342 205 295 343 209 296 minecraft:packed_mud
fill 342 205 298 343 208 299 minecraft:packed_mud
fill 343 205 294 350 209 294 minecraft:packed_mud
fill 343 205 300 345 209 300 minecraft:packed_mud
fill 344 205 295 344 209 295 minecraft:packed_mud
fill 344 205 299 348 209 299 minecraft:packed_mud
fill 346 205 298 350 209 298 minecraft:packed_mud
fill 347 205 293 349 209 293 minecraft:packed_mud
fill 347 205 295 347 209 295 minecraft:packed_mud
fill 349 205 295 351 208 295 minecraft:packed_mud
fill 349 205 297 350 209 297 minecraft:packed_mud
fill 350 205 296 351 209 296 minecraft:packed_mud
fill 358 205 285 358 205 287 minecraft:dirt
setblock 359 205 284 minecraft:dirt
setblock 359 205 289 minecraft:dirt
setblock 360 205 283 minecraft:dirt
fill 361 205 290 363 205 290 minecraft:dirt
setblock 363 205 283 minecraft:dirt
setblock 364 205 289 minecraft:dirt
setblock 365 205 285 minecraft:dirt
setblock 365 205 288 minecraft:dirt
setblock 371 205 306 minecraft:white_wool
setblock 329 206 283 minecraft:white_wool
setblock 329 206 289 minecraft:white_wool
fill 329 206 290 329 218 290 minecraft:light_blue_terracotta
fill 341 206 294 341 208 296 minecraft:packed_mud
fill 341 206 298 341 207 299 minecraft:packed_mud
fill 342 206 293 342 211 294 minecraft:packed_mud
fill 342 206 300 342 208 300 minecraft:packed_mud
fill 343 206 293 346 209 293 minecraft:packed_mud
fill 344 206 292 349 208 292 minecraft:packed_mud
fill 344 206 301 347 208 301 minecraft:packed_mud
fill 346 206 300 349 209 300 minecraft:packed_mud
fill 349 206 299 350 209 299 minecraft:packed_mud
fill 350 206 293 350 208 293 minecraft:packed_mud
fill 351 206 294 351 208 294 minecraft:packed_mud
fill 351 206 297 351 209 298 minecraft:packed_mud
fill 371 206 306 371 218 306 minecraft:light_blue_terracotta
setblock 371 206 314 minecraft:white_wool
fill 371 206 315 371 219 315 minecraft:light_blue_terracotta
fill 329 207 283 329 218 283 minecraft:light_blue_terracotta
fill 329 207 289 329 215 289 minecraft:light_blue_terracotta
fill 331 207 275 331 218 275 minecraft:light_blue_terracotta
setblock 332 207 275 minecraft:white_wool
fill 340 207 295 340 208 295 minecraft:packed_mud
fill 341 207 293 341 209 293 minecraft:packed_mud
fill 342 207 292 343 209 292 minecraft:packed_mud
fill 343 207 301 343 208 301 minecraft:packed_mud
fill 344 207 291 347 209 291 minecraft:packed_mud
fill 346 207 302 346 208 302 minecraft:packed_mud
fill 348 207 301 349 209 301 minecraft:packed_mud
fill 350 207 300 350 209 300 minecraft:packed_mud
setblock 351 207 293 minecraft:packed_mud
fill 351 207 299 351 208 299 minecraft:packed_mud
fill 352 207 295 352 207 297 minecraft:packed_mud
fill 371 207 279 371 214 280 minecraft:light_blue_terracotta
setblock 371 207 281 minecraft:white_wool
fill 371 207 314 371 215 314 minecraft:light_blue_terracotta
fill 332 208 275 332 216 275 minecraft:light_blue_terracotta
setblock 340 208 294 minecraft:packed_mud
setblock 341 208 298 minecraft:packed_mud
fill 343 208 291 343 209 291 minecraft:packed_mud
setblock 345 208 302 minecraft:packed_mud
fill 347 208 302 348 208 302 minecraft:packed_mud
setblock 348 208 291 minecraft:packed_mud
setblock 352 208 297 minecraft:packed_mud
fill 371 208 281 371 218 281 minecraft:light_blue_terracotta
setblock 329 209 282 minecraft:white_wool
setblock 329 209 293 minecraft:white_wool
setblock 330 209 275 minecraft:white_wool
setblock 332 209 278 minecraft:light[level=15]
setblock 332 209 285 minecraft:light[level=12]
setblock 332 209 286 minecraft:light[level=15]
setblock 332 209 292 minecraft:light[level=12]
setblock 332 209 294 minecraft:light[level=15]
setblock 332 209 299 minecraft:light[level=12]
setblock 332 209 302 minecraft:light[level=15]
setblock 332 209 306 minecraft:light[level=12]
setblock 332 209 310 minecraft:light[level=15]
setblock 332 209 313 minecraft:light[level=12]
setblock 339 209 278 minecraft:light[level=12]
setblock 339 209 285 minecraft:light[level=12]
setblock 339 209 292 minecraft:light[level=12]
setblock 339 209 299 minecraft:light[level=12]
setblock 339 209 306 minecraft:light[level=12]
setblock 339 209 313 minecraft:light[level=12]
setblock 340 209 278 minecraft:light[level=15]
setblock 340 209 286 minecraft:light[level=15]
setblock 340 209 294 minecraft:light[level=15]
setblock 340 209 302 minecraft:light[level=15]
setblock 340 209 310 minecraft:light[level=15]
fill 341 209 294 341 209 295 minecraft:packed_mud
fill 342 209 297 342 209 298 minecraft:packed_mud
fill 343 209 298 343 209 299 minecraft:packed_mud
setblock 344 209 275 minecraft:white_wool
fill 344 209 292 348 209 292 minecraft:packed_mud
setblock 345 209 295 minecraft:packed_mud
fill 345 209 301 347 209 301 minecraft:packed_mud
setblock 346 209 278 minecraft:light[level=12]
setblock 346 209 285 minecraft:light[level=12]
setblock 346 209 306 minecraft:light[level=12]
setblock 346 209 313 minecraft:light[level=12]
setblock 348 209 278 minecraft:light[level=15]
setblock 348 209 286 minecraft:light[level=15]
setblock 348 209 302 minecraft:light[level=15]
setblock 348 209 310 minecraft:light[level=15]
fill 349 209 295 350 209 295 minecraft:packed_mud
setblock 353 209 278 minecraft:light[level=12]
setblock 353 209 285 minecraft:light[level=12]
setblock 353 209 292 minecraft:light[level=12]
setblock 353 209 299 minecraft:light[level=12]
setblock 353 209 306 minecraft:light[level=12]
setblock 353 209 313 minecraft:light[level=12]
setblock 356 209 278 minecraft:light[level=15]
setblock 356 209 286 minecraft:light[level=15]
setblock 356 209 294 minecraft:light[level=15]
setblock 356 209 302 minecraft:light[level=15]
setblock 356 209 310 minecraft:light[level=15]
setblock 360 209 278 minecraft:light[level=12]
setblock 360 209 285 minecraft:light[level=12]
setblock 360 209 292 minecraft:light[level=12]
setblock 360 209 299 minecraft:light[level=12]
setblock 360 209 306 minecraft:light[level=12]
setblock 360 209 313 minecraft:light[level=12]
setblock 364 209 278 minecraft:light[level=15]
setblock 364 209 286 minecraft:light[level=15]
setblock 364 209 294 minecraft:light[level=15]
setblock 364 209 302 minecraft:light[level=15]
setblock 364 209 310 minecraft:light[level=15]
setblock 367 209 278 minecraft:light[level=12]
setblock 367 209 285 minecraft:light[level=12]
setblock 367 209 292 minecraft:light[level=12]
setblock 367 209 299 minecraft:light[level=12]
setblock 367 209 306 minecraft:light[level=12]
setblock 367 209 313 minecraft:light[level=12]
setblock 371 209 301 minecraft:white_wool
fill 371 209 302 371 216 303 minecraft:light_blue_terracotta
setblock 329 210 278 minecraft:white_wool
fill 329 210 282 329 219 282 minecraft:light_blue_terracotta
fill 329 210 293 329 218 293 minecraft:light_blue_terracotta
fill 330 210 275 330 218 275 minecraft:light_blue_terracotta
fill 342 210 295 343 211 295 minecraft:packed_mud
fill 343 210 292 343 211 294 minecraft:packed_mud
fill 343 210 297 343 211 297 minecraft:packed_mud
fill 344 210 275 344 215 275 minecraft:light_blue_terracotta
fill 344 210 292 345 211 293 minecraft:packed_mud
fill 344 210 299 345 211 299 minecraft:packed_mud
fill 345 210 300 348 211 300 minecraft:packed_mud
fill 346 210 292 347 211 292 minecraft:packed_mud
fill 347 210 293 348 211 293 minecraft:packed_mud
fill 347 210 299 349 211 299 minecraft:packed_mud
fill 349 210 294 349 211 295 minecraft:packed_mud
fill 349 210 297 349 211 298 minecraft:packed_mud
setblock 355 210 317 minecraft:white_wool
fill 360 210 306 362 212 306 minecraft:packed_mud
fill 360 210 308 362 213 308 minecraft:packed_mud
fill 361 210 307 362 213 307 minecraft:packed_mud
setblock 364 210 275 minecraft:white_wool
setblock 371 210 287 minecraft:white_wool
fill 371 210 301 371 218 301 minecraft:light_blue_terracotta
fill 329 211 278 329 214 278 minecraft:light_blue_terracotta
fill 338 211 294 341 211 298 minecraft:packed_mud
fill 339 211 292 341 211 293 minecraft:packed_mud
fill 339 211 299 343 211 300 minecraft:packed_mud
fill 340 211 290 352 211 291 minecraft:packed_mud
fill 340 211 301 352 211 302 minecraft:packed_mud
fill 342 211 289 350 211 289 minecraft:packed_mud
setblock 342 211 292 minecraft:packed_mud
fill 342 211 296 342 211 298 minecraft:packed_mud
fill 342 211 303 350 211 303 minecraft:packed_mud
setblock 343 211 298 minecraft:packed_mud
fill 344 211 288 348 211 288 minecraft:packed_mud
setblock 344 211 300 minecraft:packed_mud
fill 344 211 304 348 211 304 minecraft:packed_mud
fill 348 211 292 353 211 292 minecraft:packed_mud
fill 349 211 293 353 211 293 minecraft:packed_mud
fill 349 211 300 353 211 300 minecraft:packed_mud
fill 350 211 294 353 211 299 minecraft:packed_mud
fill 354 211 294 354 211 298 minecraft:packed_mud
fill 355 211 317 355 218 317 minecraft:light_blue_terracotta
setblock 359 211 308 minecraft:packed_mud
fill 360 211 305 361 212 305 minecraft:packed_mud
fill 360 211 307 360 213 307 minecraft:packed_mud
fill 362 211 309 362 212 309 minecraft:packed_mud
fill 363 211 307 363 212 308 minecraft:packed_mud
fill 364 211 275 364 218 275 minecraft:light_blue_terracotta
fill 371 211 287 371 218 287 minecraft:light_blue_terracotta
fill 330 212 276 370 212 277 minecraft:white_stained_glass
fill 330 212 278 370 212 278 minecraft:white_wool
fill 330 212 279 370 212 280 minecraft:white_stained_glass
fill 330 212 281 370 212 281 minecraft:white_wool
fill 330 212 282 370 212 283 minecraft:white_stained_glass
fill 330 212 284 370 212 284 minecraft:white_wool
fill 330 212 285 370 212 286 minecraft:white_stained_glass
fill 330 212 287 370 212 287 minecraft:white_wool
fill 330 212 288 341 212 289 minecraft:white_stained_glass
fill 330 212 290 339 212 290 minecraft:white_wool
fill 330 212 291 338 212 292 minecraft:white_stained_glass
fill 330 212 293 338 212 293 minecraft:white_wool
fill 330 212 294 337 212 295 minecraft:white_stained_glass
fill 330 212 296 337 212 296 minecraft:white_wool
fill 330 212 297 337 212 298 minecraft:white_stained_glass
fill 330 212 299 338 212 299 minecraft:white_wool
fill 330 212 300 338 212 301 minecraft:white_stained_glass
fill 330 212 302 339 212 302 minecraft:white_wool
fill 330 212 303 341 212 304 minecraft:white_stained_glass
fill 330 212 305 359 212 305 minecraft:white_wool
fill 330 212 306 358 212 307 minecraft:white_stained_glass
fill 330 212 308 359 212 308 minecraft:white_wool
fill 330 212 309 360 212 310 minecraft:white_stained_glass
fill 330 212 311 370 212 311 minecraft:white_wool
fill 330 212 312 370 212 313 minecraft:white_stained_glass
fill 330 212 314 370 212 314 minecraft:white_wool
fill 330 212 315 370 212 316 minecraft:white_stained_glass
setblock 337 212 317 minecraft:white_wool
fill 338 212 294 341 212 298 minecraft:moss_block
setblock 339 212 291 minecraft:white_stained_glass
fill 339 212 292 342 212 293 minecraft:moss_block
fill 339 212 299 342 212 300 minecraft:moss_block
setblock 339 212 301 minecraft:white_stained_glass
fill 340 212 290 352 212 291 minecraft:moss_block
fill 340 212 301 352 212 302 minecraft:moss_block
fill 342 212 288 343 212 288 minecraft:white_stained_glass
fill 342 212 289 350 212 289 minecraft:moss_block
setblock 342 212 294 minecraft:moss_block
fill 342 212 295 342 212 297 minecraft:ochre_froglight
setblock 342 212 298 minecraft:moss_block
fill 342 212 303 350 212 303 minecraft:moss_block
fill 342 212 304 343 212 304 minecraft:white_stained_glass
fill 343 212 292 344 212 292 minecraft:moss_block
setblock 343 212 293 minecraft:ochre_froglight
fill 343 212 294 343 212 295 minecraft:sea_lantern
fill 343 212 297 343 212 298 minecraft:sea_lantern
setblock 343 212 299 minecraft:ochre_froglight
fill 343 212 300 344 212 300 minecraft:moss_block
fill 344 212 288 348 212 288 minecraft:moss_block
fill 344 212 293 345 212 293 minecraft:sea_lantern
fill 344 212 299 345 212 299 minecraft:sea_lantern
fill 344 212 304 348 212 304 minecraft:moss_block
fill 345 212 292 347 212 292 minecraft:ochre_froglight
fill 345 212 300 347 212 300 minecraft:ochre_froglight
fill 347 212 293 348 212 293 minecraft:sea_lantern
fill 347 212 299 348 212 299 minecraft:sea_lantern
fill 348 212 292 353 212 292 minecraft:moss_block
fill 348 212 300 353 212 300 minecraft:moss_block
fill 349 212 288 370 212 288 minecraft:white_stained_glass
setblock 349 212 293 minecraft:ochre_froglight
fill 349 212 294 349 212 295 minecraft:sea_lantern
fill 349 212 297 349 212 298 minecraft:sea_lantern
setblock 349 212 299 minecraft:ochre_froglight
fill 349 212 304 370 212 304 minecraft:white_stained_glass
fill 350 212 293 353 212 294 minecraft:moss_block
fill 350 212 295 350 212 297 minecraft:ochre_froglight
fill 350 212 298 353 212 299 minecraft:moss_block
fill 351 212 289 370 212 289 minecraft:white_stained_glass
fill 351 212 295 354 212 297 minecraft:moss_block
fill 351 212 303 370 212 303 minecraft:white_stained_glass
fill 353 212 290 370 212 290 minecraft:white_wool
fill 353 212 291 370 212 291 minecraft:white_stained_glass
fill 353 212 301 370 212 301 minecraft:white_stained_glass
fill 353 212 302 370 212 302 minecraft:white_wool
fill 354 212 292 370 212 292 minecraft:white_stained_glass
fill 354 212 293 370 212 293 minecraft:white_wool
setblock 354 212 294 minecraft:moss_block
setblock 354 212 298 minecraft:moss_block
fill 354 212 299 370 212 299 minecraft:white_wool
fill 354 212 300 370 212 300 minecraft:white_stained_glass
fill 355 212 294 370 212 295 minecraft:white_stained_glass
fill 355 212 296 370 212 296 minecraft:white_wool
fill 355 212 297 370 212 298 minecraft:white_stained_glass
setblock 358 212 317 minecraft:white_wool
fill 359 212 306 359 212 307 minecraft:packed_mud
setblock 361 212 309 minecraft:packed_mud
fill 361 212 310 370 212 310 minecraft:white_stained_glass
fill 362 212 305 370 212 305 minecraft:white_wool
fill 363 212 306 370 212 306 minecraft:white_stained_glass
fill 363 212 309 370 212 309 minecraft:white_stained_glass
fill 364 212 307 370 212 307 minecraft:white_stained_glass
fill 364 212 308 370 212 308 minecraft:white_wool
fill 337 213 317 337 218 317 minecraft:light_blue_terracotta
fill 339 213 289 341 214 304 minecraft:gray_concrete
fill 342 213 289 354 214 291 minecraft:gray_concrete
fill 342 213 302 354 214 304 minecraft:gray_concrete
fill 352 213 292 354 214 301 minecraft:gray_concrete
fill 358 213 317 358 218 317 minecraft:light_blue_terracotta
fill 359 213 306 359 214 306 minecraft:moss_block
setblock 359 213 307 minecraft:packed_mud
fill 359 213 308 359 214 308 minecraft:moss_block
fill 360 213 305 362 214 305 minecraft:moss_block
fill 360 213 306 361 213 306 minecraft:packed_mud
fill 360 213 309 362 213 309 minecraft:moss_block
fill 362 213 306 363 214 306 minecraft:moss_block
fill 363 213 307 363 214 308 minecraft:moss_block
setblock 329 214 284 minecraft:white_wool
fill 359 214 307 362 214 307 minecraft:moss_block
fill 360 214 306 361 214 306 minecraft:moss_block
fill 360 214 308 361 214 309 minecraft:moss_block
setblock 362 214 308 minecraft:moss_block
setblock 329 215 275 minecraft:light_blue_concrete
setblock 329 215 278 minecraft:light_blue_concrete
fill 329 215 284 329 216 284 minecraft:light_blue_terracotta
fill 329 215 305 329 216 305 minecraft:light_blue_concrete
setblock 329 215 312 minecraft:light_blue_concrete
fill 329 215 313 329 218 313 minecraft:light_blue_terracotta
setblock 332 215 278 minecraft:light[level=12]
setblock 332 215 285 minecraft:light[level=12]
setblock 332 215 292 minecraft:light[level=12]
setblock 332 215 299 minecraft:light[level=12]
setblock 332 215 306 minecraft:light[level=12]
setblock 332 215 313 minecraft:light[level=12]
setblock 332 215 317 minecraft:light_blue_concrete
setblock 335 215 275 minecraft:light_blue_concrete
fill 336 215 275 336 218 275 minecraft:light_blue_terracotta
setblock 336 215 317 minecraft:light_blue_concrete
setblock 337 215 275 minecraft:light_blue_concrete
setblock 339 215 278 minecraft:light[level=12]
setblock 339 215 285 minecraft:light[level=12]
fill 339 215 289 339 227 289 minecraft:gray_concrete
setblock 339 215 290 minecraft:sea_lantern
fill 339 215 291 354 228 291 minecraft:gray_concrete
setblock 339 215 292 minecraft:black_stained_glass
fill 339 215 293 341 228 293 minecraft:gray_concrete
setblock 339 215 294 minecraft:light_blue_stained_glass
fill 339 215 295 341 228 295 minecraft:gray_concrete
setblock 339 215 296 minecraft:light_blue_stained_glass
fill 339 215 297 341 228 297 minecraft:gray_concrete
setblock 339 215 298 minecraft:sea_lantern
fill 339 215 299 341 228 299 minecraft:gray_concrete
setblock 339 215 300 minecraft:light_blue_stained_glass
fill 339 215 301 341 228 301 minecraft:gray_concrete
setblock 339 215 302 minecraft:black_stained_glass
fill 339 215 303 339 228 304 minecraft:gray_concrete
setblock 339 215 306 minecraft:light[level=12]
setblock 339 215 313 minecraft:light[level=12]
setblock 340 215 289 minecraft:black_stained_glass
fill 340 215 290 353 228 290 minecraft:gray_concrete
fill 340 215 292 341 228 292 minecraft:gray_concrete
fill 340 215 294 341 228 294 minecraft:gray_concrete
fill 340 215 296 341 228 296 minecraft:gray_concrete
fill 340 215 298 341 228 298 minecraft:gray_concrete
fill 340 215 300 341 228 300 minecraft:gray_concrete
fill 340 215 302 353 228 303 minecraft:gray_concrete
setblock 340 215 304 minecraft:black_stained_glass
fill 341 215 289 341 227 289 minecraft:gray_concrete
fill 341 215 304 341 228 304 minecraft:gray_concrete
setblock 342 215 289 minecraft:light_blue_stained_glass
setblock 342 215 304 minecraft:black_stained_glass
fill 343 215 289 343 227 289 minecraft:gray_concrete
fill 343 215 304 343 228 304 minecraft:gray_concrete
setblock 344 215 289 minecraft:black_stained_glass
setblock 344 215 304 minecraft:sea_lantern
setblock 345 215 275 minecraft:light_blue_concrete
fill 345 215 289 345 227 289 minecraft:gray_concrete
fill 345 215 304 345 228 304 minecraft:gray_concrete
setblock 346 215 278 minecraft:light[level=12]
setblock 346 215 285 minecraft:light[level=12]
setblock 346 215 289 minecraft:light_blue_stained_glass
setblock 346 215 304 minecraft:light_blue_stained_glass
setblock 346 215 306 minecraft:light[level=12]
setblock 346 215 313 minecraft:light[level=12]
fill 347 215 289 347 227 289 minecraft:gray_concrete
fill 347 215 304 347 228 304 minecraft:gray_concrete
fill 347 215 317 348 215 317 minecraft:light_blue_concrete
setblock 348 215 289 minecraft:black_stained_glass
setblock 348 215 304 minecraft:black_stained_glass
fill 349 215 289 349 227 289 minecraft:gray_concrete
fill 349 215 304 349 228 304 minecraft:gray_concrete
fill 349 215 317 349 216 317 minecraft:light_blue_terracotta
setblock 350 215 289 minecraft:black_stained_glass
setblock 350 215 304 minecraft:sea_lantern
fill 351 215 289 351 227 289 minecraft:gray_concrete
fill 351 215 304 351 228 304 minecraft:gray_concrete
setblock 352 215 289 minecraft:light_blue_stained_glass
fill 352 215 292 353 228 301 minecraft:gray_concrete
setblock 352 215 304 minecraft:black_stained_glass
setblock 353 215 278 minecraft:light[level=12]
setblock 353 215 285 minecraft:light[level=12]
fill 353 215 289 354 227 289 minecraft:gray_concrete
fill 353 215 304 354 228 304 minecraft:gray_concrete
setblock 353 215 306 minecraft:light[level=12]
setblock 353 215 313 minecraft:light[level=12]
setblock 354 215 290 minecraft:sea_lantern
setblock 354 215 292 minecraft:black_stained_glass
fill 354 215 293 354 228 293 minecraft:gray_concrete
setblock 354 215 294 minecraft:light_blue_stained_glass
fill 354 215 295 354 228 295 minecraft:gray_concrete
setblock 354 215 296 minecraft:black_stained_glass
fill 354 215 297 354 228 297 minecraft:gray_concrete
setblock 354 215 298 minecraft:black_stained_glass
fill 354 215 299 354 228 299 minecraft:gray_concrete
setblock 354 215 300 minecraft:light_blue_stained_glass
fill 354 215 301 354 228 301 minecraft:gray_concrete
setblock 354 215 302 minecraft:black_stained_glass
fill 354 215 303 354 228 303 minecraft:gray_concrete
setblock 357 215 275 minecraft:light_blue_concrete
fill 358 215 275 359 215 275 minecraft:light_blue_terracotta
setblock 360 215 278 minecraft:light[level=12]
setblock 360 215 285 minecraft:light[level=12]
setblock 360 215 292 minecraft:light[level=12]
setblock 360 215 299 minecraft:light[level=12]
setblock 360 215 306 minecraft:light[level=12]
setblock 360 215 313 minecraft:light[level=12]
setblock 364 215 317 minecraft:light_blue_concrete
setblock 367 215 278 minecraft:light[level=12]
setblock 367 215 285 minecraft:light[level=12]
setblock 367 215 292 minecraft:light[level=12]
setblock 367 215 299 minecraft:light[level=12]
setblock 367 215 306 minecraft:light[level=12]
setblock 367 215 313 minecraft:light[level=12]
setblock 370 215 317 minecraft:light_blue_concrete
fill 371 215 278 371 216 278 minecraft:light_blue_concrete
fill 371 215 279 371 218 279 minecraft:light_blue_terracotta
setblock 371 215 280 minecraft:light_blue_concrete
setblock 371 215 282 minecraft:light_blue_concrete
setblock 371 215 295 minecraft:light_blue_concrete
setblock 371 215 296 minecraft:light_blue_terracotta
setblock 371 215 300 minecraft:light_blue_concrete
setblock 371 215 307 minecraft:light_blue_concrete
fill 329 216 275 329 218 275 minecraft:light_blue_terracotta
setblock 329 216 278 minecraft:light_blue_terracotta
setblock 329 216 281 minecraft:light_blue_concrete
setblock 329 216 289 minecraft:light_blue_concrete
fill 329 216 291 329 218 291 minecraft:light_blue_terracotta
setblock 329 216 292 minecraft:light_blue_concrete
fill 329 216 306 329 218 308 minecraft:light_blue_terracotta
fill 329 216 309 329 216 310 minecraft:light_blue_concrete
fill 329 216 312 329 218 312 minecraft:light_blue_terracotta
setblock 329 216 315 minecraft:light_blue_concrete
fill 329 216 316 329 218 317 minecraft:light_blue_terracotta
fill 330 216 317 330 218 317 minecraft:light_blue_terracotta
setblock 331 216 317 minecraft:light_blue_concrete
fill 332 216 317 332 218 317 minecraft:light_blue_terracotta
setblock 334 216 317 minecraft:light_blue_concrete
fill 335 216 275 335 218 275 minecraft:light_blue_terracotta
fill 336 216 317 336 218 317 minecraft:light_blue_terracotta
fill 337 216 275 337 218 275 minecraft:light_blue_terracotta
setblock 338 216 317 minecraft:light_blue_concrete
fill 339 216 290 339 217 290 minecraft:gray_concrete
fill 339 216 292 339 217 292 minecraft:gray_concrete
fill 339 216 294 339 217 294 minecraft:gray_concrete
fill 339 216 296 339 217 296 minecraft:gray_concrete
fill 339 216 298 339 217 298 minecraft:gray_concrete
fill 339 216 300 339 217 300 minecraft:gray_concrete
fill 339 216 302 339 217 302 minecraft:gray_concrete
fill 340 216 289 340 217 289 minecraft:gray_concrete
fill 340 216 304 340 217 304 minecraft:gray_concrete
setblock 341 216 317 minecraft:light_blue_concrete
fill 342 216 289 342 217 289 minecraft:gray_concrete
fill 342 216 304 342 217 304 minecraft:gray_concrete
fill 343 216 282 344 217 283 minecraft:white_wool
setblock 344 216 275 minecraft:light_blue_concrete
fill 344 216 289 344 217 289 minecraft:gray_concrete
fill 344 216 304 344 217 304 minecraft:gray_concrete
fill 345 216 275 345 218 275 minecraft:light_blue_terracotta
fill 346 216 289 346 217 289 minecraft:gray_concrete
fill 346 216 304 346 217 304 minecraft:gray_concrete
fill 347 216 317 348 218 317 minecraft:light_blue_terracotta
fill 348 216 289 348 217 289 minecraft:gray_concrete
fill 348 216 304 348 217 304 minecraft:gray_concrete
fill 350 216 289 350 217 289 minecraft:gray_concrete
fill 350 216 304 350 217 304 minecraft:gray_concrete
fill 352 216 278 354 216 279 minecraft:white_concrete
fill 352 216 289 352 217 289 minecraft:gray_concrete
fill 352 216 304 352 217 304 minecraft:gray_concrete
setblock 352 216 317 minecraft:light_blue_concrete
fill 354 216 290 354 217 290 minecraft:gray_concrete
fill 354 216 292 354 217 292 minecraft:gray_concrete
fill 354 216 294 354 217 294 minecraft:gray_concrete
fill 354 216 296 354 217 296 minecraft:gray_concrete
fill 354 216 298 354 217 298 minecraft:gray_concrete
fill 354 216 300 354 217 300 minecraft:gray_concrete
fill 354 216 302 354 217 302 minecraft:gray_concrete
fill 357 216 275 357 218 275 minecraft:light_blue_terracotta
fill 358 216 275 358 217 275 minecraft:light_blue_concrete
fill 358 216 287 366 218 289 minecraft:dirt
setblock 359 216 275 minecraft:light_blue_terracotta
fill 359 216 285 365 218 286 minecraft:dirt
fill 359 216 290 365 218 290 minecraft:dirt
setblock 360 216 275 minecraft:light_blue_concrete
fill 360 216 284 364 218 284 minecraft:dirt
fill 360 216 291 364 218 291 minecraft:dirt
fill 361 216 275 361 218 275 minecraft:light_blue_terracotta
fill 362 216 275 363 216 275 minecraft:light_blue_concrete
fill 362 216 292 362 218 292 minecraft:dirt
setblock 362 216 317 minecraft:light_blue_concrete
fill 364 216 317 364 218 317 minecraft:light_blue_terracotta
fill 366 216 286 366 218 286 minecraft:dirt
setblock 366 216 317 minecraft:white_wool
setblock 370 216 275 minecraft:light_blue_concrete
fill 370 216 317 370 218 317 minecraft:light_blue_terracotta
fill 371 216 276 371 217 276 minecraft:light_blue_concrete
fill 371 216 280 371 218 280 minecraft:light_blue_terracotta
setblock 371 216 282 minecraft:light_blue_terracotta
setblock 371 216 295 minecraft:light_blue_terracotta
setblock 371 216 296 minecraft:light_blue_concrete
fill 371 216 300 371 218 300 minecraft:light_blue_terracotta
fill 371 216 307 371 218 307 minecraft:light_blue_terracotta
fill 371 216 313 371 216 314 minecraft:light_blue_concrete
setblock 329 217 276 minecraft:light_blue_concrete
setblock 329 217 278 minecraft:light_blue_concrete
fill 329 217 281 329 218 281 minecraft:light_blue_terracotta
setblock 329 217 284 minecraft:white_wool
setblock 329 217 288 minecraft:light_blue_concrete
fill 329 217 289 329 218 289 minecraft:light_blue_terracotta
fill 329 217 292 329 218 292 minecraft:light_blue_terracotta
setblock 329 217 300 minecraft:light_blue_concrete
fill 329 217 301 329 218 302 minecraft:light_blue_terracotta
setblock 329 217 303 minecraft:light_blue_concrete
fill 329 217 304 329 218 305 minecraft:light_blue_terracotta
fill 329 217 309 329 218 310 minecraft:light_blue_terracotta
fill 329 217 315 329 218 315 minecraft:light_blue_terracotta
fill 331 217 317 331 218 317 minecraft:light_blue_terracotta
setblock 332 217 275 minecraft:light_blue_concrete
setblock 332 217 278 minecraft:light[level=15]
setblock 332 217 286 minecraft:light[level=15]
setblock 332 217 294 minecraft:light[level=15]
setblock 332 217 302 minecraft:light[level=15]
setblock 332 217 310 minecraft:light[level=15]
fill 334 217 317 334 220 317 minecraft:light_blue_terracotta
fill 337 217 306 337 218 306 minecraft:ochre_froglight
fill 338 217 317 338 218 317 minecraft:light_blue_terracotta
setblock 339 217 275 minecraft:light_blue_concrete
setblock 340 217 278 minecraft:light[level=15]
setblock 340 217 286 minecraft:light[level=15]
setblock 340 217 310 minecraft:light[level=15]
fill 341 217 317 341 218 317 minecraft:light_blue_terracotta
setblock 342 217 317 minecraft:light_blue_concrete
fill 344 217 275 344 218 275 minecraft:light_blue_terracotta
setblock 348 217 278 minecraft:light[level=15]
setblock 348 217 286 minecraft:light[level=15]
setblock 348 217 310 minecraft:light[level=15]
setblock 349 217 317 minecraft:white_wool
fill 352 217 317 352 218 317 minecraft:light_blue_terracotta
setblock 356 217 278 minecraft:light[level=15]
setblock 356 217 286 minecraft:light[level=15]
setblock 356 217 294 minecraft:light[level=15]
setblock 356 217 302 minecraft:light[level=15]
setblock 356 217 310 minecraft:light[level=15]
fill 358 217 286 358 218 286 minecraft:dirt
fill 358 217 290 358 218 290 minecraft:dirt
setblock 359 217 275 minecraft:light_blue_concrete
fill 359 217 291 359 218 291 minecraft:dirt
fill 360 217 275 360 219 275 minecraft:light_blue_terracotta
fill 360 217 292 361 218 292 minecraft:dirt
fill 361 217 283 363 218 283 minecraft:dirt
fill 362 217 275 363 218 275 minecraft:light_blue_terracotta
fill 362 217 317 362 218 317 minecraft:light_blue_terracotta
fill 363 217 292 364 218 292 minecraft:dirt
setblock 364 217 278 minecraft:light[level=15]
setblock 364 217 294 minecraft:light[level=15]
setblock 364 217 302 minecraft:light[level=15]
setblock 364 217 310 minecraft:light[level=15]
fill 365 217 284 365 218 284 minecraft:dirt
fill 365 217 291 365 218 291 minecraft:dirt
fill 366 217 285 366 218 285 minecraft:dirt
fill 366 217 290 366 218 290 minecraft:dirt
fill 366 217 317 366 218 317 minecraft:light_blue_terracotta
fill 370 217 275 370 218 275 minecraft:light_blue_terracotta
fill 371 217 278 371 218 278 minecraft:light_blue_terracotta
setblock 371 217 282 minecraft:white_wool
setblock 371 217 295 minecraft:light_blue_concrete
fill 371 217 296 371 218 296 minecraft:light_blue_terracotta
fill 371 217 302 371 218 302 minecraft:light_blue_terracotta
setblock 371 217 303 minecraft:light_blue_concrete
setblock 371 217 308 minecraft:white_wool
fill 371 217 313 371 219 314 minecraft:light_blue_terracotta
setblock 329 218 276 minecraft:light_blue_terracotta
fill 329 218 278 329 219 278 minecraft:light_blue_terracotta
setblock 329 218 284 minecraft:light_blue_terracotta
setblock 329 218 288 minecraft:light_blue_terracotta
setblock 329 218 298 minecraft:white_wool
setblock 329 218 300 minecraft:light_blue_terracotta
fill 329 218 303 329 219 303 minecraft:light_blue_terracotta
setblock 332 218 275 minecraft:light_blue_terracotta
setblock 339 218 275 minecraft:light_blue_terracotta
setblock 339 218 290 minecraft:sea_lantern
setblock 339 218 292 minecraft:light_blue_stained_glass
setblock 339 218 294 minecraft:black_stained_glass
setblock 339 218 296 minecraft:sea_lantern
setblock 339 218 298 minecraft:black_stained_glass
setblock 339 218 300 minecraft:sea_lantern
setblock 339 218 302 minecraft:black_stained_glass
setblock 340 218 289 minecraft:sea_lantern
setblock 340 218 304 minecraft:light_blue_stained_glass
setblock 342 218 289 minecraft:black_stained_glass
setblock 342 218 304 minecraft:black_stained_glass
setblock 342 218 317 minecraft:light_blue_terracotta
setblock 344 218 289 minecraft:light_blue_stained_glass
setblock 344 218 304 minecraft:black_stained_glass
setblock 346 218 289 minecraft:sea_lantern
setblock 346 218 304 minecraft:black_stained_glass
setblock 348 218 289 minecraft:light_blue_stained_glass
setblock 348 218 304 minecraft:light_blue_stained_glass
setblock 349 218 317 minecraft:light_blue_terracotta
setblock 350 218 289 minecraft:sea_lantern
setblock 350 218 304 minecraft:black_stained_glass
setblock 352 218 289 minecraft:black_stained_glass
setblock 352 218 304 minecraft:black_stained_glass
setblock 354 218 290 minecraft:black_stained_glass
setblock 354 218 292 minecraft:black_stained_glass
setblock 354 218 294 minecraft:light_blue_stained_glass
setblock 354 218 296 minecraft:sea_lantern
setblock 354 218 298 minecraft:light_blue_stained_glass
setblock 354 218 300 minecraft:black_stained_glass
setblock 354 218 302 minecraft:black_stained_glass
fill 357 218 287 357 218 289 minecraft:dirt
fill 358 218 275 359 218 275 minecraft:light_blue_terracotta
setblock 358 218 285 minecraft:dirt
setblock 358 218 291 minecraft:dirt
setblock 359 218 284 minecraft:dirt
setblock 359 218 292 minecraft:dirt
setblock 360 218 283 minecraft:dirt
setblock 362 218 293 minecraft:dirt
setblock 364 218 283 minecraft:dirt
setblock 365 218 292 minecraft:dirt
setblock 366 218 291 minecraft:dirt
fill 367 218 286 367 218 289 minecraft:dirt
setblock 371 218 276 minecraft:light_blue_terracotta
setblock 371 218 282 minecraft:light_blue_terracotta
setblock 371 218 295 minecraft:light_blue_terracotta
setblock 371 218 303 minecraft:light_blue_terracotta
setblock 371 218 308 minecraft:light_blue_terracotta
fill 329 219 275 329 220 277 minecraft:light_blue_concrete
fill 329 219 279 329 219 281 minecraft:light_blue_concrete
fill 329 219 283 329 219 293 minecraft:light_blue_concrete
fill 329 219 295 329 302 296 minecraft:light_blue_concrete
fill 329 219 298 329 239 302 minecraft:light_blue_concrete
fill 329 219 304 329 219 310 minecraft:light_blue_concrete
fill 329 219 312 329 223 317 minecraft:light_blue_concrete
fill 330 219 275 337 219 275 minecraft:light_blue_concrete
fill 330 219 317 332 219 317 minecraft:light_blue_concrete
fill 335 219 317 347 220 317 minecraft:light_blue_concrete
fill 337 219 306 337 229 306 minecraft:dirt
fill 339 219 275 359 219 275 minecraft:light_blue_concrete
fill 339 219 290 339 220 290 minecraft:gray_concrete
fill 339 219 292 339 220 292 minecraft:gray_concrete
fill 339 219 294 339 220 294 minecraft:gray_concrete
fill 339 219 296 339 220 296 minecraft:gray_concrete
fill 339 219 298 339 220 298 minecraft:gray_concrete
fill 339 219 300 339 220 300 minecraft:gray_concrete
fill 339 219 302 339 220 302 minecraft:gray_concrete
fill 340 219 289 340 220 289 minecraft:gray_concrete
fill 340 219 304 340 220 304 minecraft:gray_concrete
fill 342 219 289 342 220 289 minecraft:gray_concrete
fill 342 219 304 342 220 304 minecraft:gray_concrete
fill 344 219 289 344 220 289 minecraft:gray_concrete
fill 344 219 304 344 220 304 minecraft:gray_concrete
fill 346 219 289 346 220 289 minecraft:gray_concrete
fill 346 219 304 346 220 304 minecraft:gray_concrete
fill 348 219 289 348 220 289 minecraft:gray_concrete
fill 348 219 304 348 220 304 minecraft:gray_concrete
setblock 348 219 317 minecraft:light_blue_terracotta
fill 349 219 317 368 219 317 minecraft:light_blue_concrete
fill 350 219 289 350 220 289 minecraft:gray_concrete
fill 350 219 304 350 220 304 minecraft:gray_concrete
fill 352 219 289 352 220 289 minecraft:gray_concrete
fill 352 219 304 352 220 304 minecraft:gray_concrete
fill 354 219 290 354 220 290 minecraft:gray_concrete
fill 354 219 292 354 220 292 minecraft:gray_concrete
fill 354 219 294 354 220 294 minecraft:gray_concrete
fill 354 219 296 354 220 296 minecraft:gray_concrete
fill 354 219 298 354 220 298 minecraft:gray_concrete
fill 354 219 300 354 220 300 minecraft:gray_concrete
fill 354 219 302 354 220 302 minecraft:gray_concrete
fill 361 219 275 362 290 275 minecraft:light_blue_concrete
fill 362 219 288 362 222 288 minecraft:white_concrete
setblock 363 219 275 minecraft:light_blue_terracotta
fill 364 219 275 366 297 275 minecraft:light_blue_concrete
fill 368 219 275 371 219 275 minecraft:light_blue_concrete
fill 370 219 317 370 308 317 minecraft:light_blue_concrete
fill 371 219 276 371 219 284 minecraft:light_blue_concrete
fill 371 219 286 371 219 312 minecraft:light_blue_concrete
fill 371 219 316 371 266 316 minecraft:light_blue_concrete
fill 329 220 278 329 248 278 minecraft:light_blue_concrete
fill 329 220 279 329 221 279 minecraft:light_blue_terracotta
fill 329 220 280 329 220 282 minecraft:light_blue_concrete
setblock 329 220 283 minecraft:white_wool
fill 329 220 284 329 247 291 minecraft:light_blue_concrete
setblock 329 220 292 minecraft:light_blue_terracotta
fill 329 220 293 329 258 294 minecraft:light_blue_concrete
fill 329 220 297 329 232 297 minecraft:light_blue_concrete
fill 329 220 303 329 220 309 minecraft:light_blue_concrete
setblock 329 220 310 minecraft:light_blue_terracotta
fill 329 220 311 329 285 311 minecraft:light_blue_concrete
fill 330 220 275 333 234 275 minecraft:light_blue_concrete
fill 330 220 317 331 220 317 minecraft:light_blue_concrete
setblock 332 220 317 minecraft:light_blue_terracotta
setblock 334 220 275 minecraft:white_wool
fill 335 220 275 336 245 275 minecraft:light_blue_concrete
fill 336 220 306 336 229 306 minecraft:dirt
setblock 337 220 275 minecraft:light_blue_terracotta
fill 338 220 275 339 271 275 minecraft:light_blue_concrete
setblock 340 220 275 minecraft:light_blue_terracotta
fill 341 220 275 345 220 275 minecraft:light_blue_concrete
setblock 346 220 275 minecraft:light_blue_terracotta
fill 347 220 275 348 287 275 minecraft:light_blue_concrete
fill 348 220 317 351 222 317 minecraft:light_blue_concrete
fill 349 220 275 349 221 275 minecraft:light_blue_terracotta
fill 350 220 275 352 223 275 minecraft:light_blue_concrete
setblock 352 220 317 minecraft:light_blue_terracotta
fill 353 220 275 354 220 275 minecraft:light_blue_terracotta
fill 353 220 317 356 237 317 minecraft:light_blue_concrete
fill 355 220 275 357 224 275 minecraft:light_blue_concrete
setblock 357 220 317 minecraft:light_blue_terracotta
setblock 358 220 275 minecraft:light_blue_terracotta
fill 358 220 317 360 220 317 minecraft:light_blue_concrete
fill 359 220 275 360 244 275 minecraft:light_blue_concrete
setblock 361 220 317 minecraft:light_blue_terracotta
fill 362 220 317 368 220 317 minecraft:light_blue_concrete
fill 363 220 275 363 284 275 minecraft:light_blue_concrete
fill 368 220 275 369 308 275 minecraft:light_blue_concrete
setblock 370 220 275 minecraft:light_blue_terracotta
fill 371 220 275 371 237 281 minecraft:light_blue_concrete
fill 371 220 282 371 221 282 minecraft:light_blue_terracotta
fill 371 220 283 371 220 291 minecraft:light_blue_concrete
setblock 371 220 292 minecraft:light_blue_terracotta
fill 371 220 293 371 220 296 minecraft:light_blue_concrete
setblock 371 220 297 minecraft:light_blue_terracotta
fill 371 220 298 371 236 302 minecraft:light_blue_concrete
fill 371 220 303 371 220 304 minecraft:light_blue_terracotta
fill 371 220 305 371 220 315 minecraft:light_blue_concrete
fill 371 220 317 371 308 317 minecraft:light_blue_concrete
setblock 329 221 275 minecraft:light_blue_terracotta
fill 329 221 276 329 234 277 minecraft:light_blue_concrete
fill 329 221 280 329 223 280 minecraft:light_blue_concrete
setblock 329 221 281 minecraft:light_blue_terracotta
fill 329 221 282 329 308 283 minecraft:light_blue_concrete
fill 329 221 292 329 308 292 minecraft:light_blue_concrete
fill 329 221 303 329 308 303 minecraft:light_blue_concrete
setblock 329 221 304 minecraft:light_blue_terracotta
fill 329 221 305 329 225 310 minecraft:light_blue_concrete
setblock 330 221 317 minecraft:light_blue_terracotta
fill 331 221 317 343 221 317 minecraft:light_blue_concrete
setblock 332 221 278 minecraft:light[level=12]
setblock 332 221 285 minecraft:light[level=12]
setblock 332 221 292 minecraft:light[level=12]
setblock 332 221 299 minecraft:light[level=12]
setblock 332 221 306 minecraft:light[level=12]
setblock 332 221 313 minecraft:light[level=12]
fill 334 221 275 334 253 275 minecraft:light_blue_concrete
fill 336 221 307 337 229 307 minecraft:dirt
fill 337 221 275 337 253 275 minecraft:light_blue_concrete
fill 337 221 305 337 229 305 minecraft:dirt
setblock 339 221 278 minecraft:light[level=12]
setblock 339 221 285 minecraft:light[level=12]
setblock 339 221 290 minecraft:light_blue_stained_glass
setblock 339 221 292 minecraft:sea_lantern
setblock 339 221 294 minecraft:light_blue_stained_glass
setblock 339 221 296 minecraft:black_stained_glass
setblock 339 221 298 minecraft:light_blue_stained_glass
setblock 339 221 300 minecraft:black_stained_glass
setblock 339 221 302 minecraft:light_blue_stained_glass
setblock 339 221 306 minecraft:light[level=12]
setblock 339 221 313 minecraft:light[level=12]
fill 340 221 275 344 227 275 minecraft:light_blue_concrete
setblock 340 221 289 minecraft:black_stained_glass
setblock 340 221 304 minecraft:black_stained_glass
setblock 342 221 289 minecraft:light_blue_stained_glass
setblock 342 221 304 minecraft:black_stained_glass
setblock 344 221 289 minecraft:light_blue_stained_glass
setblock 344 221 304 minecraft:light_blue_stained_glass
setblock 344 221 317 minecraft:white_wool
setblock 345 221 275 minecraft:light_blue_terracotta
fill 345 221 317 345 236 317 minecraft:light_blue_concrete
fill 346 221 275 346 256 275 minecraft:light_blue_concrete
setblock 346 221 278 minecraft:light[level=12]
setblock 346 221 285 minecraft:light[level=12]
setblock 346 221 289 minecraft:black_stained_glass
setblock 346 221 304 minecraft:black_stained_glass
setblock 346 221 306 minecraft:light[level=12]
setblock 346 221 313 minecraft:light[level=12]
setblock 346 221 317 minecraft:light_blue_terracotta
fill 347 221 317 347 272 317 minecraft:light_blue_concrete
setblock 348 221 289 minecraft:black_stained_glass
setblock 348 221 304 minecraft:sea_lantern
setblock 350 221 289 minecraft:black_stained_glass
setblock 350 221 304 minecraft:sea_lantern
setblock 352 221 289 minecraft:black_stained_glass
setblock 352 221 304 minecraft:black_stained_glass
fill 352 221 317 352 233 317 minecraft:light_blue_concrete
fill 353 221 275 354 232 275 minecraft:light_blue_concrete
setblock 353 221 278 minecraft:light[level=12]
setblock 353 221 285 minecraft:light[level=12]
setblock 353 221 306 minecraft:light[level=12]
setblock 353 221 313 minecraft:light[level=12]
setblock 354 221 290 minecraft:black_stained_glass
setblock 354 221 292 minecraft:sea_lantern
setblock 354 221 294 minecraft:light_blue_stained_glass
setblock 354 221 296 minecraft:light_blue_stained_glass
setblock 354 221 298 minecraft:light_blue_stained_glass
setblock 354 221 300 minecraft:light_blue_stained_glass
setblock 354 221 302 minecraft:black_stained_glass
fill 357 221 317 357 284 317 minecraft:light_blue_concrete
fill 358 221 275 358 276 275 minecraft:light_blue_concrete
setblock 358 221 317 minecraft:light_blue_terracotta
fill 359 221 317 361 230 317 minecraft:light_blue_concrete
setblock 360 221 278 minecraft:light[level=12]
setblock 360 221 285 minecraft:light[level=12]
setblock 360 221 292 minecraft:light[level=12]
setblock 360 221 299 minecraft:light[level=12]
setblock 360 221 306 minecraft:light[level=12]
setblock 360 221 313 minecraft:light[level=12]
setblock 362 221 317 minecraft:light_blue_terracotta
fill 363 221 317 363 308 317 minecraft:light_blue_concrete
fill 364 221 317 365 221 317 minecraft:light_blue_terracotta
fill 366 221 317 368 227 317 minecraft:light_blue_concrete
fill 367 221 275 367 252 275 minecraft:light_blue_concrete
setblock 367 221 278 minecraft:light[level=12]
setblock 367 221 285 minecraft:light[level=12]
setblock 367 221 292 minecraft:light[level=12]
setblock 367 221 299 minecraft:light[level=12]
setblock 367 221 306 minecraft:light[level=12]
setblock 367 221 313 minecraft:light[level=12]
fill 370 221 275 370 299 275 minecraft:light_blue_concrete
fill 371 221 283 371 308 284 minecraft:light_blue_concrete
setblock 371 221 285 minecraft:light_blue_terracotta
fill 371 221 286 371 229 287 minecraft:light_blue_concrete
setblock 371 221 288 minecraft:white_wool
fill 371 221 289 371 225 294 minecraft:light_blue_concrete
setblock 371 221 295 minecraft:light_blue_terracotta
fill 371 221 296 371 255 297 minecraft:light_blue_concrete
fill 371 221 303 371 224 308 minecraft:light_blue_concrete
setblock 371 221 309 minecraft:light_blue_terracotta
fill 371 221 310 371 308 310 minecraft:light_blue_concrete
setblock 371 221 311 minecraft:white_wool
fill 371 221 312 371 231 315 minecraft:light_blue_concrete
fill 329 222 275 329 308 275 minecraft:light_blue_concrete
fill 329 222 279 329 223 279 minecraft:light_blue_concrete
fill 329 222 281 329 308 281 minecraft:light_blue_concrete
fill 329 222 304 329 256 304 minecraft:light_blue_concrete
fill 330 222 317 334 245 317 minecraft:light_blue_concrete
fill 335 222 306 335 229 306 minecraft:dirt
setblock 335 222 317 minecraft:white_wool
fill 336 222 305 336 229 305 minecraft:dirt
fill 336 222 317 344 263 317 minecraft:light_blue_concrete
fill 338 222 305 338 229 307 minecraft:dirt
fill 339 222 290 339 223 290 minecraft:gray_concrete
fill 339 222 292 339 223 292 minecraft:gray_concrete
fill 339 222 294 339 223 294 minecraft:gray_concrete
fill 339 222 296 339 223 296 minecraft:gray_concrete
fill 339 222 298 339 223 298 minecraft:gray_concrete
fill 339 222 300 339 223 300 minecraft:gray_concrete
fill 339 222 302 339 223 302 minecraft:gray_concrete
fill 340 222 289 340 223 289 minecraft:gray_concrete
fill 340 222 304 340 223 304 minecraft:gray_concrete
fill 342 222 289 342 223 289 minecraft:gray_concrete
fill 342 222 304 342 223 304 minecraft:gray_concrete
fill 344 222 289 344 223 289 minecraft:gray_concrete
fill 344 222 304 344 223 304 minecraft:gray_concrete
fill 345 222 275 345 257 275 minecraft:light_blue_concrete
fill 346 222 289 346 223 289 minecraft:gray_concrete
fill 346 222 304 346 223 304 minecraft:gray_concrete
fill 346 222 317 346 308 317 minecraft:light_blue_concrete
fill 348 222 289 348 223 289 minecraft:gray_concrete
fill 348 222 304 348 223 304 minecraft:gray_concrete
fill 349 222 275 349 308 275 minecraft:light_blue_concrete
fill 350 222 289 350 223 289 minecraft:gray_concrete
fill 350 222 304 350 223 304 minecraft:gray_concrete
fill 352 222 289 352 223 289 minecraft:gray_concrete
fill 352 222 304 352 223 304 minecraft:gray_concrete
fill 354 222 290 354 223 290 minecraft:gray_concrete
fill 354 222 292 354 223 292 minecraft:gray_concrete
fill 354 222 294 354 223 294 minecraft:gray_concrete
fill 354 222 296 354 223 296 minecraft:gray_concrete
fill 354 222 298 354 223 298 minecraft:gray_concrete
fill 354 222 300 354 223 300 minecraft:gray_concrete
fill 354 222 302 354 223 302 minecraft:gray_concrete
fill 358 222 317 358 284 317 minecraft:light_blue_concrete
fill 361 222 287 361 224 289 minecraft:oak_leaves[persistent=true]
fill 362 222 286 363 224 287 minecraft:oak_leaves[persistent=true]
fill 362 222 289 363 224 289 minecraft:oak_leaves[persistent=true]
fill 362 222 317 362 253 317 minecraft:light_blue_concrete
fill 363 222 288 364 224 288 minecraft:oak_leaves[persistent=true]
fill 364 222 317 365 308 317 minecraft:light_blue_concrete
fill 369 222 317 369 308 317 minecraft:light_blue_concrete
fill 371 222 282 371 254 282 minecraft:light_blue_concrete
fill 371 222 285 371 308 285 minecraft:light_blue_concrete
fill 371 222 288 371 255 288 minecraft:light_blue_concrete
fill 371 222 295 371 308 295 minecraft:light_blue_concrete
fill 371 222 309 371 308 309 minecraft:light_blue_concrete
fill 371 222 311 371 308 311 minecraft:light_blue_concrete
fill 335 223 305 335 229 305 minecraft:dirt
fill 335 223 307 335 229 307 minecraft:dirt
fill 335 223 317 335 308 317 minecraft:light_blue_concrete
fill 336 223 304 337 229 304 minecraft:dirt
fill 336 223 308 338 229 308 minecraft:dirt
fill 348 223 317 350 296 317 minecraft:light_blue_concrete
setblock 351 223 317 minecraft:white_wool
fill 360 223 287 360 223 288 minecraft:oak_leaves[persistent=true]
setblock 361 223 286 minecraft:oak_leaves[persistent=true]
fill 362 223 288 362 224 288 minecraft:oak_leaves[persistent=true]
setblock 362 223 290 minecraft:oak_leaves[persistent=true]
setblock 364 223 287 minecraft:oak_leaves[persistent=true]
setblock 364 223 289 minecraft:oak_leaves[persistent=true]
fill 329 224 279 329 224 280 minecraft:white_wool
fill 329 224 312 329 285 314 minecraft:light_blue_concrete
setblock 329 224 315 minecraft:white_wool
fill 329 224 316 329 250 317 minecraft:light_blue_concrete
fill 334 224 306 334 229 306 minecraft:dirt
fill 335 224 304 335 229 304 minecraft:dirt
fill 335 224 308 335 229 308 minecraft:dirt
fill 338 224 304 338 229 304 minecraft:dirt
setblock 339 224 290 minecraft:light_blue_stained_glass
setblock 339 224 292 minecraft:light_blue_stained_glass
setblock 339 224 294 minecraft:black_stained_glass
setblock 339 224 296 minecraft:black_stained_glass
setblock 339 224 298 minecraft:black_stained_glass
setblock 339 224 300 minecraft:sea_lantern
setblock 339 224 302 minecraft:black_stained_glass
fill 339 224 305 339 229 307 minecraft:dirt
setblock 340 224 289 minecraft:sea_lantern
setblock 340 224 304 minecraft:black_stained_glass
setblock 342 224 289 minecraft:sea_lantern
setblock 342 224 304 minecraft:black_stained_glass
setblock 344 224 289 minecraft:sea_lantern
setblock 344 224 304 minecraft:black_stained_glass
setblock 346 224 289 minecraft:light_blue_stained_glass
setblock 346 224 304 minecraft:black_stained_glass
setblock 348 224 289 minecraft:sea_lantern
setblock 348 224 304 minecraft:black_stained_glass
fill 350 224 275 350 231 275 minecraft:light_blue_concrete
setblock 350 224 289 minecraft:sea_lantern
setblock 350 224 304 minecraft:black_stained_glass
setblock 351 224 275 minecraft:white_wool
fill 351 224 317 351 275 317 minecraft:light_blue_concrete
fill 352 224 275 352 282 275 minecraft:light_blue_concrete
setblock 352 224 289 minecraft:black_stained_glass
setblock 352 224 304 minecraft:black_stained_glass
setblock 354 224 290 minecraft:black_stained_glass
setblock 354 224 292 minecraft:black_stained_glass
setblock 354 224 294 minecraft:black_stained_glass
setblock 354 224 296 minecraft:sea_lantern
setblock 354 224 298 minecraft:sea_lantern
setblock 354 224 300 minecraft:black_stained_glass
setblock 354 224 302 minecraft:sea_lantern
fill 329 225 279 329 287 280 minecraft:light_blue_concrete
fill 329 225 315 329 308 315 minecraft:light_blue_concrete
setblock 332 225 278 minecraft:light[level=15]
setblock 332 225 286 minecraft:light[level=15]
setblock 332 225 294 minecraft:light[level=15]
setblock 332 225 302 minecraft:light[level=15]
setblock 332 225 310 minecraft:light[level=15]
fill 334 225 305 334 229 305 minecraft:dirt
fill 334 225 307 334 229 308 minecraft:dirt
fill 336 225 303 337 229 303 minecraft:dirt
fill 336 225 309 338 229 309 minecraft:dirt
fill 339 225 290 339 228 290 minecraft:gray_concrete
fill 339 225 292 339 228 292 minecraft:gray_concrete
fill 339 225 294 339 228 294 minecraft:gray_concrete
fill 339 225 296 339 228 296 minecraft:gray_concrete
fill 339 225 298 339 228 298 minecraft:gray_concrete
fill 339 225 300 339 228 300 minecraft:gray_concrete
fill 339 225 302 339 228 302 minecraft:gray_concrete
fill 339 225 308 339 229 308 minecraft:dirt
setblock 340 225 278 minecraft:light[level=15]
setblock 340 225 286 minecraft:light[level=15]
fill 340 225 289 340 227 289 minecraft:gray_concrete
fill 340 225 304 340 228 304 minecraft:gray_concrete
setblock 340 225 310 minecraft:light[level=15]
fill 342 225 289 342 227 289 minecraft:gray_concrete
fill 342 225 304 342 228 304 minecraft:gray_concrete
fill 344 225 289 344 227 289 minecraft:gray_concrete
fill 344 225 304 344 228 304 minecraft:gray_concrete
fill 346 225 289 346 227 289 minecraft:gray_concrete
fill 346 225 304 346 228 304 minecraft:gray_concrete
setblock 348 225 278 minecraft:light[level=15]
setblock 348 225 286 minecraft:light[level=15]
fill 348 225 289 348 227 289 minecraft:gray_concrete
fill 348 225 304 348 228 304 minecraft:gray_concrete
setblock 348 225 310 minecraft:light[level=15]
fill 350 225 289 350 227 289 minecraft:gray_concrete
fill 350 225 304 350 228 304 minecraft:gray_concrete
fill 351 225 275 351 308 275 minecraft:light_blue_concrete
fill 352 225 289 352 227 289 minecraft:gray_concrete
fill 352 225 304 352 228 304 minecraft:gray_concrete
fill 354 225 290 354 228 290 minecraft:gray_concrete
fill 354 225 292 354 228 292 minecraft:gray_concrete
fill 354 225 294 354 228 294 minecraft:gray_concrete
fill 354 225 296 354 228 296 minecraft:gray_concrete
fill 354 225 298 354 228 298 minecraft:gray_concrete
fill 354 225 300 354 228 300 minecraft:gray_concrete
fill 354 225 302 354 228 302 minecraft:gray_concrete
fill 355 225 275 355 308 275 minecraft:light_blue_concrete
setblock 356 225 275 minecraft:white_wool
setblock 356 225 278 minecraft:light[level=15]
setblock 356 225 286 minecraft:light[level=15]
setblock 356 225 294 minecraft:light[level=15]
setblock 356 225 302 minecraft:light[level=15]
setblock 356 225 310 minecraft:light[level=15]
fill 357 225 275 357 308 275 minecraft:light_blue_concrete
setblock 364 225 278 minecraft:light[level=15]
setblock 364 225 286 minecraft:light[level=15]
setblock 364 225 294 minecraft:light[level=15]
setblock 364 225 302 minecraft:light[level=15]
setblock 364 225 310 minecraft:light[level=15]
fill 371 225 303 371 292 303 minecraft:light_blue_concrete
setblock 371 225 304 minecraft:white_wool
fill 371 225 305 371 248 308 minecraft:light_blue_concrete
fill 329 226 305 329 308 306 minecraft:light_blue_concrete
setblock 329 226 307 minecraft:white_wool
fill 329 226 308 329 308 310 minecraft:light_blue_concrete
fill 333 226 306 333 229 307 minecraft:dirt
fill 334 226 304 334 229 304 minecraft:dirt
fill 335 226 303 335 229 303 minecraft:dirt
fill 335 226 309 335 229 309 minecraft:dirt
fill 338 226 303 338 229 303 minecraft:dirt
fill 339 226 309 339 229 309 minecraft:dirt
fill 340 226 305 340 229 307 minecraft:dirt
fill 356 226 275 356 308 275 minecraft:light_blue_concrete
fill 371 226 289 371 229 292 minecraft:light_blue_concrete
setblock 371 226 293 minecraft:white_wool
fill 371 226 294 371 267 294 minecraft:light_blue_concrete
fill 371 226 304 371 243 304 minecraft:light_blue_concrete
fill 329 227 307 329 263 307 minecraft:light_blue_concrete
setblock 332 227 278 minecraft:light[level=12]
setblock 332 227 285 minecraft:light[level=12]
setblock 332 227 292 minecraft:light[level=12]
setblock 332 227 299 minecraft:light[level=12]
setblock 332 227 306 minecraft:light[level=12]
setblock 332 227 313 minecraft:light[level=12]
fill 333 227 304 333 229 305 minecraft:dirt
fill 333 227 308 333 229 308 minecraft:dirt
fill 334 227 303 334 229 303 minecraft:dirt
fill 334 227 309 334 229 309 minecraft:dirt
fill 335 227 310 338 229 310 minecraft:dirt
fill 336 227 302 337 229 302 minecraft:dirt
setblock 339 227 278 minecraft:light[level=12]
setblock 339 227 285 minecraft:light[level=12]
setblock 339 227 313 minecraft:light[level=12]
fill 340 227 308 340 229 308 minecraft:dirt
setblock 346 227 278 minecraft:light[level=12]
setblock 346 227 285 minecraft:light[level=12]
setblock 346 227 306 minecraft:light[level=12]
setblock 346 227 313 minecraft:light[level=12]
setblock 353 227 278 minecraft:light[level=12]
setblock 353 227 285 minecraft:light[level=12]
setblock 353 227 306 minecraft:light[level=12]
setblock 353 227 313 minecraft:light[level=12]
setblock 360 227 278 minecraft:light[level=12]
setblock 360 227 285 minecraft:light[level=12]
setblock 360 227 292 minecraft:light[level=12]
setblock 360 227 299 minecraft:light[level=12]
setblock 360 227 306 minecraft:light[level=12]
setblock 360 227 313 minecraft:light[level=12]
setblock 367 227 278 minecraft:light[level=12]
setblock 367 227 285 minecraft:light[level=12]
setblock 367 227 292 minecraft:light[level=12]
setblock 367 227 299 minecraft:light[level=12]
setblock 367 227 306 minecraft:light[level=12]
setblock 367 227 313 minecraft:light[level=12]
fill 371 227 293 371 295 293 minecraft:light_blue_concrete
fill 332 228 306 332 229 307 minecraft:dirt
fill 333 228 309 333 229 309 minecraft:dirt
fill 334 228 310 334 229 310 minecraft:dirt
fill 335 228 302 335 229 302 minecraft:dirt
fill 338 228 302 338 229 302 minecraft:dirt
fill 339 228 289 354 228 289 minecraft:yellow_concrete
fill 339 228 310 339 229 310 minecraft:dirt
fill 340 228 275 340 308 275 minecraft:light_blue_concrete
fill 340 228 309 340 229 309 minecraft:dirt
setblock 341 228 275 minecraft:white_wool
fill 341 228 305 341 229 308 minecraft:dirt
fill 342 228 275 344 249 275 minecraft:light_blue_concrete
fill 366 228 317 366 308 317 minecraft:light_blue_concrete
setblock 367 228 317 minecraft:white_wool
fill 368 228 317 368 240 317 minecraft:light_blue_concrete
fill 332 229 304 332 229 305 minecraft:dirt
setblock 332 229 308 minecraft:dirt
setblock 333 229 303 minecraft:dirt
setblock 334 229 302 minecraft:dirt
fill 335 229 311 338 229 311 minecraft:dirt
fill 336 229 301 337 229 301 minecraft:dirt
fill 339 229 302 339 229 304 minecraft:dirt
fill 340 229 303 340 229 304 minecraft:dirt
setblock 340 229 310 minecraft:dirt
fill 341 229 275 341 295 275 minecraft:light_blue_concrete
setblock 341 229 304 minecraft:dirt
setblock 341 229 309 minecraft:dirt
fill 367 229 317 367 272 317 minecraft:light_blue_concrete
fill 337 230 306 337 232 306 minecraft:white_concrete
fill 371 230 286 371 308 286 minecraft:light_blue_concrete
setblock 371 230 287 minecraft:white_wool
setblock 371 230 289 minecraft:white_wool
fill 371 230 290 371 232 292 minecraft:light_blue_concrete
fill 341 231 297 341 232 297 minecraft:white_wool
fill 345 231 308 348 233 309 minecraft:packed_mud
fill 346 231 307 346 234 307 minecraft:packed_mud
fill 346 231 310 346 233 310 minecraft:packed_mud
fill 359 231 317 360 240 317 minecraft:light_blue_concrete
setblock 361 231 317 minecraft:white_wool
fill 371 231 287 371 250 287 minecraft:light_blue_concrete
fill 371 231 289 371 308 289 minecraft:light_blue_concrete
fill 344 232 307 344 233 307 minecraft:white_wool
fill 344 232 308 344 233 308 minecraft:packed_mud
fill 345 232 307 345 233 307 minecraft:packed_mud
fill 345 232 310 345 233 310 minecraft:packed_mud
fill 347 232 307 348 233 307 minecraft:packed_mud
fill 347 232 310 347 234 310 minecraft:packed_mud
setblock 350 232 275 minecraft:white_wool
fill 361 232 317 361 236 317 minecraft:light_blue_concrete
fill 371 232 312 371 292 314 minecraft:light_blue_concrete
setblock 371 232 315 minecraft:white_wool
setblock 329 233 297 minecraft:white_wool
setblock 332 233 278 minecraft:light[level=15]
setblock 332 233 285 minecraft:light[level=12]
setblock 332 233 286 minecraft:light[level=15]
setblock 332 233 292 minecraft:light[level=12]
setblock 332 233 294 minecraft:light[level=15]
setblock 332 233 299 minecraft:light[level=12]
setblock 332 233 302 minecraft:light[level=15]
setblock 332 233 306 minecraft:light[level=12]
setblock 332 233 310 minecraft:light[level=15]
setblock 332 233 313 minecraft:light[level=12]
fill 335 233 306 338 235 307 minecraft:oak_leaves[persistent=true]
fill 336 233 305 338 235 305 minecraft:oak_leaves[persistent=true]
fill 336 233 308 337 235 308 minecraft:oak_leaves[persistent=true]
setblock 339 233 278 minecraft:light[level=12]
setblock 339 233 285 minecraft:light[level=12]
setblock 339 233 292 minecraft:light[level=12]
setblock 339 233 299 minecraft:light[level=12]
setblock 339 233 306 minecraft:light[level=12]
setblock 339 233 313 minecraft:light[level=12]
setblock 340 233 278 minecraft:light[level=15]
setblock 340 233 286 minecraft:light[level=15]
setblock 340 233 294 minecraft:light[level=15]
setblock 340 233 302 minecraft:light[level=15]
setblock 340 233 310 minecraft:light[level=15]
setblock 346 233 278 minecraft:light[level=12]
setblock 346 233 285 minecraft:light[level=12]
setblock 346 233 292 minecraft:light[level=12]
setblock 346 233 299 minecraft:light[level=12]
setblock 346 233 306 minecraft:light[level=12]
setblock 346 233 313 minecraft:light[level=12]
setblock 348 233 278 minecraft:light[level=15]
setblock 348 233 286 minecraft:light[level=15]
setblock 348 233 294 minecraft:light[level=15]
setblock 348 233 302 minecraft:light[level=15]
setblock 348 233 310 minecraft:light[level=15]
fill 350 233 275 350 308 275 minecraft:light_blue_concrete
setblock 353 233 275 minecraft:white_wool
setblock 353 233 278 minecraft:light[level=12]
setblock 353 233 285 minecraft:light[level=12]
setblock 353 233 292 minecraft:light[level=12]
setblock 353 233 299 minecraft:light[level=12]
setblock 353 233 306 minecraft:light[level=12]
setblock 353 233 313 minecraft:light[level=12]
fill 354 233 275 354 302 275 minecraft:light_blue_concrete
setblock 356 233 278 minecraft:light[level=15]
setblock 356 233 286 minecraft:light[level=15]
setblock 356 233 294 minecraft:light[level=15]
setblock 356 233 302 minecraft:light[level=15]
setblock 356 233 310 minecraft:light[level=15]
setblock 360 233 278 minecraft:light[level=12]
setblock 360 233 285 minecraft:light[level=12]
setblock 360 233 292 minecraft:light[level=12]
setblock 360 233 299 minecraft:light[level=12]
setblock 360 233 306 minecraft:light[level=12]
setblock 360 233 313 minecraft:light[level=12]
setblock 364 233 278 minecraft:light[level=15]
setblock 364 233 286 minecraft:light[level=15]
setblock 364 233 294 minecraft:light[level=15]
setblock 364 233 302 minecraft:light[level=15]
setblock 364 233 310 minecraft:light[level=15]
setblock 367 233 278 minecraft:light[level=12]
setblock 367 233 285 minecraft:light[level=12]
setblock 367 233 292 minecraft:light[level=12]
setblock 367 233 299 minecraft:light[level=12]
setblock 367 233 306 minecraft:light[level=12]
setblock 367 233 313 minecraft:light[level=12]
setblock 371 233 290 minecraft:white_wool
fill 371 233 291 371 234 292 minecraft:light_blue_concrete
fill 371 233 315 371 254 315 minecraft:light_blue_concrete
fill 329 234 297 329 308 297 minecraft:light_blue_concrete
setblock 335 234 305 minecraft:oak_leaves[persistent=true]
fill 336 234 304 337 234 304 minecraft:oak_leaves[persistent=true]
setblock 338 234 308 minecraft:oak_leaves[persistent=true]
setblock 339 234 306 minecraft:oak_leaves[persistent=true]
fill 344 234 308 344 234 309 minecraft:moss_block
fill 345 234 307 345 235 307 minecraft:moss_block
fill 345 234 308 347 234 309 minecraft:packed_mud
fill 345 234 310 346 235 310 minecraft:moss_block
fill 347 234 307 348 235 307 minecraft:moss_block
fill 348 234 308 348 234 310 minecraft:moss_block
setblock 352 234 317 minecraft:white_wool
fill 353 234 275 353 308 275 minecraft:light_blue_concrete
fill 371 234 290 371 273 290 minecraft:light_blue_concrete
setblock 329 235 276 minecraft:white_wool
fill 329 235 277 329 308 277 minecraft:light_blue_concrete
fill 330 235 275 331 249 275 minecraft:light_blue_concrete
setblock 332 235 275 minecraft:white_wool
fill 333 235 275 333 308 275 minecraft:light_blue_concrete
fill 344 235 288 344 236 288 minecraft:white_concrete
fill 345 235 308 348 235 309 minecraft:moss_block
setblock 346 235 307 minecraft:moss_block
setblock 346 235 311 minecraft:moss_block
setblock 347 235 310 minecraft:moss_block
fill 352 235 317 352 271 317 minecraft:light_blue_concrete
fill 359 235 299 359 236 300 minecraft:white_wool
fill 371 235 291 371 302 291 minecraft:light_blue_concrete
setblock 371 235 292 minecraft:white_wool
fill 329 236 276 329 308 276 minecraft:light_blue_concrete
fill 332 236 275 332 308 275 minecraft:light_blue_concrete
fill 335 236 293 335 237 293 minecraft:ochre_froglight
fill 371 236 292 371 270 292 minecraft:light_blue_concrete
setblock 345 237 317 minecraft:white_wool
setblock 361 237 317 minecraft:white_wool
setblock 371 237 298 minecraft:white_wool
fill 371 237 299 371 282 302 minecraft:light_blue_concrete
fill 335 238 293 335 244 293 minecraft:dirt
fill 344 238 286 344 239 286 minecraft:ochre_froglight
fill 345 238 317 345 253 317 minecraft:light_blue_concrete
fill 353 238 317 354 308 317 minecraft:light_blue_concrete
setblock 355 238 317 minecraft:white_wool
fill 356 238 317 356 248 317 minecraft:light_blue_concrete
fill 361 238 317 361 308 317 minecraft:light_blue_concrete
fill 371 238 275 371 264 277 minecraft:light_blue_concrete
setblock 371 238 278 minecraft:white_wool
fill 371 238 279 371 308 281 minecraft:light_blue_concrete
fill 371 238 298 371 308 298 minecraft:light_blue_concrete
setblock 332 239 278 minecraft:light[level=12]
setblock 332 239 285 minecraft:light[level=12]
setblock 332 239 292 minecraft:light[level=12]
setblock 332 239 299 minecraft:light[level=12]
setblock 332 239 306 minecraft:light[level=12]
setblock 332 239 313 minecraft:light[level=12]
fill 334 239 293 334 244 293 minecraft:dirt
fill 335 239 292 335 244 292 minecraft:dirt
setblock 339 239 278 minecraft:light[level=12]
setblock 339 239 285 minecraft:light[level=12]
setblock 339 239 292 minecraft:light[level=12]
setblock 339 239 299 minecraft:light[level=12]
setblock 339 239 306 minecraft:light[level=12]
setblock 339 239 313 minecraft:light[level=12]
setblock 346 239 278 minecraft:light[level=12]
setblock 346 239 285 minecraft:light[level=12]
setblock 346 239 292 minecraft:light[level=12]
setblock 346 239 299 minecraft:light[level=12]
setblock 346 239 306 minecraft:light[level=12]
setblock 346 239 313 minecraft:light[level=12]
setblock 353 239 278 minecraft:light[level=12]
setblock 353 239 285 minecraft:light[level=12]
setblock 353 239 292 minecraft:light[level=12]
setblock 353 239 299 minecraft:light[level=12]
setblock 353 239 306 minecraft:light[level=12]
setblock 353 239 313 minecraft:light[level=12]
fill 355 239 317 355 308 317 minecraft:light_blue_concrete
setblock 360 239 278 minecraft:light[level=12]
setblock 360 239 285 minecraft:light[level=12]
setblock 360 239 292 minecraft:light[level=12]
setblock 360 239 299 minecraft:light[level=12]
setblock 360 239 306 minecraft:light[level=12]
setblock 360 239 313 minecraft:light[level=12]
setblock 367 239 278 minecraft:light[level=12]
setblock 367 239 285 minecraft:light[level=12]
setblock 367 239 292 minecraft:light[level=12]
setblock 367 239 299 minecraft:light[level=12]
setblock 367 239 306 minecraft:light[level=12]
setblock 367 239 313 minecraft:light[level=12]
fill 371 239 278 371 308 278 minecraft:light_blue_concrete
fill 329 240 298 329 246 301 minecraft:light_blue_concrete
setblock 329 240 302 minecraft:white_wool
fill 334 240 292 334 244 292 minecraft:dirt
fill 335 240 294 335 244 294 minecraft:dirt
fill 336 240 292 336 244 293 minecraft:dirt
fill 344 240 286 344 248 286 minecraft:dirt
fill 329 241 302 329 308 302 minecraft:light_blue_concrete
setblock 332 241 278 minecraft:light[level=15]
setblock 332 241 286 minecraft:light[level=15]
setblock 332 241 294 minecraft:light[level=15]
setblock 332 241 302 minecraft:light[level=15]
setblock 332 241 310 minecraft:light[level=15]
fill 333 241 293 333 244 293 minecraft:dirt
fill 334 241 291 335 244 291 minecraft:dirt
fill 334 241 294 334 244 294 minecraft:dirt
fill 336 241 294 336 244 294 minecraft:dirt
setblock 340 241 278 minecraft:light[level=15]
setblock 340 241 286 minecraft:light[level=15]
setblock 340 241 294 minecraft:light[level=15]
setblock 340 241 302 minecraft:light[level=15]
setblock 340 241 310 minecraft:light[level=15]
fill 344 241 287 345 248 287 minecraft:dirt
fill 345 241 286 345 248 286 minecraft:dirt
setblock 348 241 278 minecraft:light[level=15]
setblock 348 241 286 minecraft:light[level=15]
setblock 348 241 294 minecraft:light[level=15]
setblock 348 241 302 minecraft:light[level=15]
setblock 348 241 310 minecraft:light[level=15]
setblock 356 241 278 minecraft:light[level=15]
setblock 356 241 286 minecraft:light[level=15]
setblock 356 241 294 minecraft:light[level=15]
setblock 356 241 302 minecraft:light[level=15]
setblock 356 241 310 minecraft:light[level=15]
fill 359 241 317 359 308 317 minecraft:light_blue_concrete
setblock 360 241 317 minecraft:white_wool
setblock 364 241 278 minecraft:light[level=15]
setblock 364 241 286 minecraft:light[level=15]
setblock 364 241 294 minecraft:light[level=15]
setblock 364 241 302 minecraft:light[level=15]
setblock 364 241 310 minecraft:light[level=15]
setblock 368 241 317 minecraft:white_wool
fill 333 242 292 333 244 292 minecraft:dirt
fill 333 242 294 333 244 294 minecraft:dirt
fill 335 242 295 335 244 295 minecraft:dirt
fill 336 242 291 336 244 291 minecraft:dirt
fill 337 242 292 337 244 293 minecraft:dirt
fill 343 242 286 343 248 286 minecraft:dirt
fill 344 242 285 345 248 285 minecraft:dirt
fill 360 242 317 360 271 317 minecraft:light_blue_concrete
fill 368 242 317 368 268 317 minecraft:light_blue_concrete
fill 333 243 291 333 244 291 minecraft:dirt
fill 334 243 290 335 244 290 minecraft:dirt
fill 334 243 295 334 244 295 minecraft:dirt
fill 336 243 295 336 244 295 minecraft:dirt
fill 337 243 291 337 244 291 minecraft:dirt
fill 337 243 294 337 244 294 minecraft:dirt
fill 343 243 285 343 248 285 minecraft:dirt
fill 343 243 287 343 248 287 minecraft:dirt
fill 344 243 288 345 248 288 minecraft:dirt
fill 346 243 286 346 248 287 minecraft:dirt
fill 332 244 292 332 244 294 minecraft:dirt
setblock 333 244 290 minecraft:dirt
setblock 333 244 295 minecraft:dirt
setblock 336 244 290 minecraft:dirt
setblock 337 244 295 minecraft:dirt
fill 338 244 292 338 244 293 minecraft:dirt
fill 342 244 286 342 248 286 minecraft:dirt
fill 343 244 288 343 248 288 minecraft:dirt
fill 343 244 309 345 246 311 minecraft:packed_mud
fill 344 244 284 345 248 284 minecraft:dirt
fill 346 244 285 346 248 285 minecraft:dirt
fill 346 244 288 346 248 288 minecraft:dirt
fill 346 244 310 346 246 310 minecraft:packed_mud
setblock 371 244 304 minecraft:white_wool
setblock 332 245 278 minecraft:light[level=12]
setblock 332 245 285 minecraft:light[level=12]
setblock 332 245 292 minecraft:light[level=12]
setblock 332 245 299 minecraft:light[level=12]
setblock 332 245 306 minecraft:light[level=12]
setblock 332 245 313 minecraft:light[level=12]
fill 335 245 293 335 247 293 minecraft:white_concrete
setblock 339 245 278 minecraft:light[level=12]
setblock 339 245 285 minecraft:light[level=12]
setblock 339 245 292 minecraft:light[level=12]
setblock 339 245 299 minecraft:light[level=12]
setblock 339 245 306 minecraft:light[level=12]
setblock 339 245 313 minecraft:light[level=12]
fill 342 245 285 342 248 285 minecraft:dirt
fill 342 245 287 342 248 288 minecraft:dirt
fill 343 245 284 343 248 284 minecraft:dirt
setblock 343 245 308 minecraft:packed_mud
fill 343 245 312 344 246 312 minecraft:packed_mud
fill 344 245 289 345 248 289 minecraft:dirt
setblock 346 245 278 minecraft:light[level=12]
fill 346 245 284 346 248 284 minecraft:dirt
setblock 346 245 292 minecraft:light[level=12]
setblock 346 245 299 minecraft:light[level=12]
setblock 346 245 306 minecraft:light[level=12]
fill 346 245 309 346 246 309 minecraft:packed_mud
fill 346 245 311 346 246 311 minecraft:packed_mud
setblock 346 245 313 minecraft:light[level=12]
fill 347 245 285 347 248 287 minecraft:dirt
setblock 353 245 278 minecraft:light[level=12]
setblock 353 245 285 minecraft:light[level=12]
setblock 353 245 292 minecraft:light[level=12]
setblock 353 245 299 minecraft:light[level=12]
setblock 353 245 306 minecraft:light[level=12]
setblock 353 245 313 minecraft:light[level=12]
fill 359 245 275 359 254 275 minecraft:light_blue_concrete
setblock 360 245 275 minecraft:white_wool
setblock 360 245 278 minecraft:light[level=12]
setblock 360 245 285 minecraft:light[level=12]
setblock 360 245 292 minecraft:light[level=12]
setblock 360 245 299 minecraft:light[level=12]
setblock 360 245 306 minecraft:light[level=12]
setblock 360 245 313 minecraft:light[level=12]
setblock 367 245 278 minecraft:light[level=12]
setblock 367 245 285 minecraft:light[level=12]
setblock 367 245 292 minecraft:light[level=12]
setblock 367 245 299 minecraft:light[level=12]
setblock 367 245 306 minecraft:light[level=12]
setblock 367 245 313 minecraft:light[level=12]
fill 371 245 304 371 308 304 minecraft:light_blue_concrete
setblock 330 246 317 minecraft:white_wool
fill 331 246 317 334 260 317 minecraft:light_blue_concrete
setblock 335 246 275 minecraft:white_wool
fill 336 246 275 336 308 275 minecraft:light_blue_concrete
fill 342 246 284 342 248 284 minecraft:dirt
fill 343 246 289 343 248 289 minecraft:dirt
fill 344 246 283 345 248 283 minecraft:dirt
setblock 344 246 308 minecraft:packed_mud
fill 346 246 289 346 248 289 minecraft:dirt
fill 347 246 288 347 248 288 minecraft:dirt
fill 360 246 275 360 308 275 minecraft:light_blue_concrete
fill 329 247 298 329 278 300 minecraft:light_blue_concrete
setblock 329 247 301 minecraft:white_wool
fill 330 247 317 330 260 317 minecraft:light_blue_concrete
fill 335 247 275 335 308 275 minecraft:light_blue_concrete
fill 341 247 285 341 248 288 minecraft:dirt
fill 342 247 289 342 248 289 minecraft:dirt
fill 342 247 310 342 247 311 minecraft:moss_block
fill 343 247 283 343 248 283 minecraft:dirt
fill 343 247 308 343 248 309 minecraft:moss_block
fill 343 247 310 345 247 311 minecraft:packed_mud
fill 343 247 312 345 248 312 minecraft:moss_block
fill 344 247 290 345 248 290 minecraft:dirt
fill 344 247 308 345 248 308 minecraft:moss_block
fill 344 247 309 345 247 309 minecraft:packed_mud
fill 346 247 283 346 248 283 minecraft:dirt
fill 346 247 309 346 248 311 minecraft:moss_block
fill 347 247 284 347 248 284 minecraft:dirt
fill 347 247 289 347 248 289 minecraft:dirt
fill 348 247 285 348 248 287 minecraft:dirt
fill 329 248 284 329 255 289 minecraft:light_blue_concrete
setblock 329 248 290 minecraft:white_wool
fill 329 248 291 329 308 291 minecraft:light_blue_concrete
fill 329 248 301 329 308 301 minecraft:light_blue_concrete
fill 333 248 292 336 250 293 minecraft:oak_leaves[persistent=true]
fill 334 248 291 335 250 291 minecraft:oak_leaves[persistent=true]
fill 334 248 294 336 250 294 minecraft:oak_leaves[persistent=true]
setblock 341 248 284 minecraft:dirt
setblock 341 248 289 minecraft:dirt
setblock 342 248 283 minecraft:dirt
fill 342 248 309 342 248 310 minecraft:moss_block
setblock 343 248 290 minecraft:dirt
fill 343 248 310 345 248 311 minecraft:moss_block
setblock 344 248 282 minecraft:dirt
fill 344 248 309 345 248 309 minecraft:moss_block
setblock 346 248 290 minecraft:dirt
setblock 347 248 283 minecraft:dirt
setblock 348 248 284 minecraft:dirt
setblock 348 248 288 minecraft:dirt
setblock 329 249 278 minecraft:white_wool
fill 329 249 290 329 308 290 minecraft:light_blue_concrete
setblock 332 249 278 minecraft:light[level=15]
setblock 332 249 286 minecraft:light[level=15]
setblock 332 249 294 minecraft:light[level=15]
setblock 332 249 302 minecraft:light[level=15]
setblock 332 249 310 minecraft:light[level=15]
setblock 333 249 294 minecraft:oak_leaves[persistent=true]
setblock 335 249 295 minecraft:oak_leaves[persistent=true]
setblock 336 249 291 minecraft:oak_leaves[persistent=true]
fill 337 249 292 337 249 293 minecraft:oak_leaves[persistent=true]
setblock 340 249 278 minecraft:light[level=15]
setblock 340 249 286 minecraft:light[level=15]
setblock 340 249 294 minecraft:light[level=15]
setblock 340 249 302 minecraft:light[level=15]
setblock 340 249 310 minecraft:light[level=15]
fill 344 249 286 344 251 286 minecraft:iron_block
setblock 348 249 278 minecraft:light[level=15]
setblock 348 249 286 minecraft:light[level=15]
setblock 348 249 294 minecraft:light[level=15]
setblock 348 249 302 minecraft:light[level=15]
setblock 348 249 310 minecraft:light[level=15]
setblock 356 249 278 minecraft:light[level=15]
setblock 356 249 286 minecraft:light[level=15]
setblock 356 249 294 minecraft:light[level=15]
setblock 356 249 302 minecraft:light[level=15]
setblock 356 249 310 minecraft:light[level=15]
setblock 356 249 317 minecraft:white_wool
setblock 364 249 278 minecraft:light[level=15]
setblock 364 249 286 minecraft:light[level=15]
setblock 364 249 294 minecraft:light[level=15]
setblock 364 249 302 minecraft:light[level=15]
setblock 364 249 310 minecraft:light[level=15]
setblock 371 249 305 minecraft:white_wool
fill 371 249 306 371 258 308 minecraft:light_blue_concrete
fill 329 250 278 329 308 278 minecraft:light_blue_concrete
setblock 330 250 275 minecraft:white_wool
fill 331 250 275 331 308 275 minecraft:light_blue_concrete
fill 342 250 275 343 299 275 minecraft:light_blue_concrete
setblock 344 250 275 minecraft:white_wool
fill 356 250 317 356 271 317 minecraft:light_blue_concrete
fill 371 250 305 371 308 305 minecraft:light_blue_concrete
setblock 329 251 316 minecraft:white_wool
fill 329 251 317 329 308 317 minecraft:light_blue_concrete
fill 330 251 275 330 308 275 minecraft:light_blue_concrete
setblock 332 251 278 minecraft:light[level=12]
setblock 332 251 285 minecraft:light[level=12]
setblock 332 251 292 minecraft:light[level=12]
setblock 332 251 299 minecraft:light[level=12]
setblock 332 251 306 minecraft:light[level=12]
setblock 332 251 313 minecraft:light[level=12]
setblock 339 251 278 minecraft:light[level=12]
setblock 339 251 285 minecraft:light[level=12]
setblock 339 251 292 minecraft:light[level=12]
setblock 339 251 299 minecraft:light[level=12]
setblock 339 251 306 minecraft:light[level=12]
setblock 339 251 313 minecraft:light[level=12]
fill 344 251 275 344 290 275 minecraft:light_blue_concrete
setblock 346 251 278 minecraft:light[level=12]
setblock 346 251 285 minecraft:light[level=12]
setblock 346 251 292 minecraft:light[level=12]
setblock 346 251 299 minecraft:light[level=12]
setblock 346 251 306 minecraft:light[level=12]
setblock 346 251 313 minecraft:light[level=12]
setblock 353 251 278 minecraft:light[level=12]
setblock 353 251 285 minecraft:light[level=12]
setblock 353 251 292 minecraft:light[level=12]
setblock 353 251 299 minecraft:light[level=12]
setblock 353 251 306 minecraft:light[level=12]
setblock 353 251 313 minecraft:light[level=12]
setblock 360 251 278 minecraft:light[level=12]
setblock 360 251 285 minecraft:light[level=12]
setblock 360 251 292 minecraft:light[level=12]
setblock 360 251 299 minecraft:light[level=12]
setblock 360 251 306 minecraft:light[level=12]
setblock 360 251 313 minecraft:light[level=12]
setblock 367 251 278 minecraft:light[level=12]
setblock 367 251 285 minecraft:light[level=12]
setblock 367 251 292 minecraft:light[level=12]
setblock 367 251 299 minecraft:light[level=12]
setblock 367 251 306 minecraft:light[level=12]
setblock 367 251 313 minecraft:light[level=12]
setblock 371 251 287 minecraft:white_wool
fill 329 252 316 329 258 316 minecraft:light_blue_concrete
fill 371 252 287 371 308 287 minecraft:light_blue_concrete
setblock 344 253 286 minecraft:ochre_froglight
fill 355 253 310 355 255 310 minecraft:white_wool
setblock 367 253 275 minecraft:white_wool
setblock 334 254 275 minecraft:white_wool
setblock 337 254 275 minecraft:white_wool
fill 338 254 295 338 255 295 minecraft:ochre_froglight
setblock 345 254 317 minecraft:white_wool
fill 353 254 309 354 255 312 minecraft:white_wool
fill 354 254 308 356 254 308 minecraft:white_wool
fill 355 254 309 357 254 309 minecraft:white_wool
fill 355 254 311 355 254 313 minecraft:white_wool
fill 356 254 310 356 255 312 minecraft:white_wool
fill 357 254 310 357 255 311 minecraft:white_wool
setblock 362 254 317 minecraft:white_wool
fill 367 254 275 367 263 275 minecraft:light_blue_concrete
fill 334 255 275 334 273 275 minecraft:light_blue_concrete
fill 337 255 275 337 274 275 minecraft:light_blue_concrete
fill 345 255 317 345 305 317 minecraft:light_blue_concrete
fill 352 255 310 352 255 311 minecraft:white_wool
fill 355 255 309 356 255 309 minecraft:white_wool
fill 355 255 311 355 255 312 minecraft:white_wool
setblock 357 255 312 minecraft:white_wool
setblock 359 255 275 minecraft:white_wool
fill 362 255 317 362 308 317 minecraft:light_blue_concrete
setblock 371 255 282 minecraft:white_wool
setblock 371 255 315 minecraft:white_wool
setblock 329 256 284 minecraft:white_wool
fill 329 256 285 329 265 289 minecraft:light_blue_concrete
fill 338 256 295 338 264 295 minecraft:dirt
fill 347 256 283 351 256 283 minecraft:white_wool
fill 348 256 281 351 256 282 minecraft:white_wool
fill 348 256 284 351 257 284 minecraft:white_wool
fill 349 256 285 351 256 285 minecraft:white_wool
setblock 356 256 310 minecraft:white_wool
fill 359 256 275 359 308 275 minecraft:light_blue_concrete
fill 371 256 282 371 308 282 minecraft:light_blue_concrete
fill 371 256 288 371 257 288 minecraft:white_wool
setblock 371 256 296 minecraft:white_wool
fill 371 256 297 371 308 297 minecraft:light_blue_concrete
fill 371 256 315 371 308 315 minecraft:light_blue_concrete
fill 329 257 284 329 273 284 minecraft:light_blue_concrete
setblock 329 257 304 minecraft:white_wool
setblock 332 257 278 minecraft:light[level=15]
setblock 332 257 285 minecraft:light[level=12]
setblock 332 257 286 minecraft:light[level=15]
setblock 332 257 292 minecraft:light[level=12]
setblock 332 257 294 minecraft:light[level=15]
setblock 332 257 299 minecraft:light[level=12]
setblock 332 257 302 minecraft:light[level=15]
setblock 332 257 306 minecraft:light[level=12]
setblock 332 257 310 minecraft:light[level=15]
setblock 332 257 313 minecraft:light[level=12]
setblock 339 257 278 minecraft:light[level=12]
setblock 339 257 285 minecraft:light[level=12]
setblock 339 257 292 minecraft:light[level=12]
setblock 339 257 299 minecraft:light[level=12]
setblock 339 257 306 minecraft:light[level=12]
setblock 339 257 313 minecraft:light[level=12]
setblock 340 257 278 minecraft:light[level=15]
setblock 340 257 286 minecraft:light[level=15]
setblock 340 257 294 minecraft:light[level=15]
setblock 340 257 302 minecraft:light[level=15]
setblock 340 257 310 minecraft:light[level=15]
setblock 346 257 275 minecraft:white_wool
setblock 346 257 278 minecraft:light[level=12]
setblock 346 257 285 minecraft:light[level=12]
setblock 346 257 292 minecraft:light[level=12]
setblock 346 257 299 minecraft:light[level=12]
setblock 346 257 306 minecraft:light[level=12]
setblock 346 257 313 minecraft:light[level=12]
setblock 348 257 278 minecraft:light[level=15]
fill 348 257 281 350 257 283 minecraft:white_wool
fill 348 257 285 350 257 285 minecraft:white_wool
setblock 348 257 286 minecraft:light[level=15]
setblock 348 257 294 minecraft:light[level=15]
setblock 348 257 302 minecraft:light[level=15]
setblock 348 257 310 minecraft:light[level=15]
fill 351 257 282 352 257 283 minecraft:white_wool
setblock 352 257 284 minecraft:white_wool
setblock 353 257 278 minecraft:light[level=12]
setblock 353 257 285 minecraft:light[level=12]
setblock 353 257 292 minecraft:light[level=12]
setblock 353 257 299 minecraft:light[level=12]
setblock 353 257 306 minecraft:light[level=12]
setblock 353 257 313 minecraft:light[level=12]
setblock 356 257 278 minecraft:light[level=15]
setblock 356 257 286 minecraft:light[level=15]
setblock 356 257 294 minecraft:light[level=15]
setblock 356 257 302 minecraft:light[level=15]
setblock 356 257 310 minecraft:light[level=15]
setblock 360 257 278 minecraft:light[level=12]
setblock 360 257 285 minecraft:light[level=12]
setblock 360 257 292 minecraft:light[level=12]
setblock 360 257 299 minecraft:light[level=12]
setblock 360 257 306 minecraft:light[level=12]
setblock 360 257 313 minecraft:light[level=12]
setblock 364 257 278 minecraft:light[level=15]
setblock 364 257 286 minecraft:light[level=15]
setblock 364 257 294 minecraft:light[level=15]
setblock 364 257 302 minecraft:light[level=15]
setblock 364 257 310 minecraft:light[level=15]
setblock 367 257 278 minecraft:light[level=12]
setblock 367 257 285 minecraft:light[level=12]
setblock 367 257 292 minecraft:light[level=12]
setblock 367 257 299 minecraft:light[level=12]
setblock 367 257 306 minecraft:light[level=12]
setblock 367 257 313 minecraft:light[level=12]
fill 371 257 296 371 308 296 minecraft:light_blue_concrete
fill 329 258 304 329 308 304 minecraft:light_blue_concrete
fill 337 258 295 337 264 295 minecraft:dirt
fill 338 258 296 338 264 296 minecraft:dirt
setblock 345 258 275 minecraft:white_wool
fill 346 258 275 346 308 275 minecraft:light_blue_concrete
setblock 349 258 283 minecraft:white_wool
fill 354 258 284 354 259 285 minecraft:white_concrete
fill 371 258 288 371 308 288 minecraft:light_blue_concrete
fill 329 259 293 329 308 293 minecraft:light_blue_concrete
setblock 329 259 294 minecraft:white_wool
setblock 329 259 316 minecraft:white_wool
fill 337 259 294 338 264 294 minecraft:dirt
fill 337 259 296 337 264 296 minecraft:dirt
fill 339 259 295 339 264 296 minecraft:dirt
fill 345 259 275 345 308 275 minecraft:light_blue_concrete
fill 371 259 306 371 308 307 minecraft:light_blue_concrete
setblock 371 259 308 minecraft:white_wool
fill 329 260 294 329 292 294 minecraft:light_blue_concrete
fill 329 260 316 329 308 316 minecraft:light_blue_concrete
fill 336 260 295 336 264 296 minecraft:dirt
fill 337 260 297 338 264 297 minecraft:dirt
fill 339 260 294 339 264 294 minecraft:dirt
fill 371 260 308 371 287 308 minecraft:light_blue_concrete
fill 330 261 317 331 261 317 minecraft:white_wool
fill 332 261 317 334 308 317 minecraft:light_blue_concrete
fill 336 261 294 336 264 294 minecraft:dirt
fill 337 261 293 338 264 293 minecraft:dirt
fill 339 261 297 339 264 297 minecraft:dirt
fill 340 261 295 340 264 296 minecraft:dirt
fill 330 262 317 331 271 317 minecraft:light_blue_concrete
fill 335 262 295 335 264 296 minecraft:dirt
fill 336 262 293 336 264 293 minecraft:dirt
fill 336 262 297 336 264 297 minecraft:dirt
fill 337 262 298 338 264 298 minecraft:dirt
fill 339 262 293 339 264 293 minecraft:dirt
fill 340 262 294 340 264 294 minecraft:dirt
fill 340 262 297 340 264 297 minecraft:dirt
setblock 332 263 278 minecraft:light[level=12]
setblock 332 263 285 minecraft:light[level=12]
setblock 332 263 292 minecraft:light[level=12]
fill 332 263 294 332 264 295 minecraft:white_concrete
setblock 332 263 299 minecraft:light[level=12]
setblock 332 263 306 minecraft:light[level=12]
setblock 332 263 313 minecraft:light[level=12]
fill 335 263 294 335 264 294 minecraft:dirt
fill 335 263 297 335 264 297 minecraft:dirt
fill 336 263 298 336 264 298 minecraft:dirt
fill 337 263 292 338 264 292 minecraft:dirt
setblock 339 263 278 minecraft:light[level=12]
setblock 339 263 285 minecraft:light[level=12]
setblock 339 263 292 minecraft:light[level=12]
fill 339 263 298 339 264 298 minecraft:dirt
setblock 339 263 299 minecraft:light[level=12]
setblock 339 263 306 minecraft:light[level=12]
setblock 339 263 313 minecraft:light[level=12]
fill 340 263 293 340 264 293 minecraft:dirt
fill 341 263 294 341 264 296 minecraft:dirt
setblock 346 263 278 minecraft:light[level=12]
setblock 346 263 285 minecraft:light[level=12]
setblock 346 263 292 minecraft:light[level=12]
setblock 346 263 299 minecraft:light[level=12]
setblock 346 263 306 minecraft:light[level=12]
setblock 346 263 313 minecraft:light[level=12]
setblock 353 263 278 minecraft:light[level=12]
setblock 353 263 285 minecraft:light[level=12]
setblock 353 263 292 minecraft:light[level=12]
setblock 353 263 299 minecraft:light[level=12]
setblock 353 263 306 minecraft:light[level=12]
setblock 353 263 313 minecraft:light[level=12]
setblock 360 263 278 minecraft:light[level=12]
setblock 360 263 285 minecraft:light[level=12]
setblock 360 263 292 minecraft:light[level=12]
setblock 360 263 299 minecraft:light[level=12]
setblock 360 263 306 minecraft:light[level=12]
setblock 360 263 313 minecraft:light[level=12]
setblock 367 263 278 minecraft:light[level=12]
setblock 367 263 285 minecraft:light[level=12]
setblock 367 263 292 minecraft:light[level=12]
setblock 367 263 299 minecraft:light[level=12]
setblock 367 263 306 minecraft:light[level=12]
setblock 367 263 313 minecraft:light[level=12]
setblock 329 264 307 minecraft:white_wool
setblock 334 264 295 minecraft:dirt
fill 334 264 303 335 265 304 minecraft:white_concrete
setblock 335 264 293 minecraft:dirt
setblock 336 264 292 minecraft:dirt
fill 336 264 304 336 265 304 minecraft:white_concrete
fill 336 264 317 342 273 317 minecraft:light_blue_concrete
fill 337 264 299 338 264 299 minecraft:dirt
setblock 339 264 292 minecraft:dirt
setblock 340 264 298 minecraft:dirt
setblock 341 264 293 minecraft:dirt
setblock 341 264 297 minecraft:dirt
setblock 343 264 317 minecraft:white_wool
fill 344 264 317 344 308 317 minecraft:light_blue_concrete
setblock 367 264 275 minecraft:white_wool
fill 329 265 307 329 308 307 minecraft:light_blue_concrete
setblock 332 265 278 minecraft:light[level=15]
setblock 332 265 286 minecraft:light[level=15]
setblock 332 265 294 minecraft:light[level=15]
setblock 332 265 302 minecraft:light[level=15]
setblock 332 265 310 minecraft:light[level=15]
fill 338 265 295 338 268 295 minecraft:white_concrete
setblock 340 265 278 minecraft:light[level=15]
fill 340 265 286 342 266 286 minecraft:white_wool
setblock 340 265 294 minecraft:light[level=15]
setblock 340 265 302 minecraft:light[level=15]
setblock 340 265 310 minecraft:light[level=15]
fill 341 265 287 342 266 287 minecraft:white_wool
fill 343 265 317 343 289 317 minecraft:light_blue_concrete
setblock 348 265 278 minecraft:light[level=15]
setblock 348 265 286 minecraft:light[level=15]
setblock 348 265 294 minecraft:light[level=15]
setblock 348 265 302 minecraft:light[level=15]
setblock 348 265 310 minecraft:light[level=15]
setblock 356 265 278 minecraft:light[level=15]
setblock 356 265 286 minecraft:light[level=15]
setblock 356 265 294 minecraft:light[level=15]
setblock 356 265 302 minecraft:light[level=15]
setblock 356 265 310 minecraft:light[level=15]
setblock 364 265 278 minecraft:light[level=15]
setblock 364 265 286 minecraft:light[level=15]
setblock 364 265 294 minecraft:light[level=15]
setblock 364 265 302 minecraft:light[level=15]
setblock 364 265 310 minecraft:light[level=15]
fill 367 265 275 367 283 275 minecraft:light_blue_concrete
fill 371 265 275 371 308 275 minecraft:light_blue_concrete
setblock 371 265 276 minecraft:white_wool
fill 371 265 277 371 308 277 minecraft:light_blue_concrete
fill 329 266 285 329 308 286 minecraft:light_blue_concrete
setblock 329 266 287 minecraft:white_wool
fill 329 266 288 329 308 289 minecraft:light_blue_concrete
fill 371 266 276 371 282 276 minecraft:light_blue_concrete
fill 329 267 287 329 272 287 minecraft:light_blue_concrete
setblock 371 267 316 minecraft:white_wool
fill 336 268 295 337 270 296 minecraft:oak_leaves[persistent=true]
fill 337 268 294 339 270 294 minecraft:oak_leaves[persistent=true]
fill 337 268 297 338 270 297 minecraft:oak_leaves[persistent=true]
fill 338 268 296 339 270 296 minecraft:oak_leaves[persistent=true]
fill 339 268 295 339 270 295 minecraft:oak_leaves[persistent=true]
setblock 371 268 294 minecraft:white_wool
fill 371 268 316 371 308 316 minecraft:light_blue_concrete
setblock 332 269 278 minecraft:light[level=12]
setblock 332 269 285 minecraft:light[level=12]
setblock 332 269 292 minecraft:light[level=12]
setblock 332 269 299 minecraft:light[level=12]
setblock 332 269 306 minecraft:light[level=12]
setblock 332 269 313 minecraft:light[level=12]
setblock 336 269 294 minecraft:oak_leaves[persistent=true]
setblock 338 269 293 minecraft:oak_leaves[persistent=true]
fill 338 269 295 338 270 295 minecraft:oak_leaves[persistent=true]
setblock 339 269 278 minecraft:light[level=12]
setblock 339 269 285 minecraft:light[level=12]
setblock 339 269 292 minecraft:light[level=12]
setblock 339 269 297 minecraft:oak_leaves[persistent=true]
setblock 339 269 299 minecraft:light[level=12]
setblock 339 269 306 minecraft:light[level=12]
setblock 339 269 313 minecraft:light[level=12]
fill 340 269 295 340 269 296 minecraft:oak_leaves[persistent=true]
setblock 346 269 278 minecraft:light[level=12]
setblock 346 269 285 minecraft:light[level=12]
setblock 346 269 292 minecraft:light[level=12]
setblock 346 269 299 minecraft:light[level=12]
setblock 346 269 306 minecraft:light[level=12]
setblock 346 269 313 minecraft:light[level=12]
setblock 353 269 278 minecraft:light[level=12]
setblock 353 269 285 minecraft:light[level=12]
setblock 353 269 292 minecraft:light[level=12]
setblock 353 269 299 minecraft:light[level=12]
setblock 353 269 306 minecraft:light[level=12]
setblock 353 269 313 minecraft:light[level=12]
setblock 360 269 278 minecraft:light[level=12]
setblock 360 269 285 minecraft:light[level=12]
setblock 360 269 292 minecraft:light[level=12]
setblock 360 269 299 minecraft:light[level=12]
setblock 360 269 306 minecraft:light[level=12]
setblock 360 269 313 minecraft:light[level=12]
setblock 367 269 278 minecraft:light[level=12]
setblock 367 269 285 minecraft:light[level=12]
setblock 367 269 292 minecraft:light[level=12]
setblock 367 269 299 minecraft:light[level=12]
setblock 367 269 306 minecraft:light[level=12]
setblock 367 269 313 minecraft:light[level=12]
setblock 368 269 317 minecraft:white_wool
fill 371 269 294 371 271 294 minecraft:light_blue_concrete
fill 343 270 300 344 271 301 minecraft:white_concrete
fill 368 270 317 368 284 317 minecraft:light_blue_concrete
setblock 371 271 292 minecraft:white_wool
setblock 330 272 317 minecraft:white_wool
fill 331 272 317 331 308 317 minecraft:light_blue_concrete
fill 338 272 275 338 290 275 minecraft:light_blue_concrete
setblock 339 272 275 minecraft:white_wool
setblock 352 272 317 minecraft:white_wool
setblock 356 272 317 minecraft:white_wool
setblock 360 272 317 minecraft:white_wool
fill 371 272 292 371 297 292 minecraft:light_blue_concrete
setblock 371 272 294 minecraft:white_wool
setblock 329 273 287 minecraft:white_wool
fill 330 273 317 330 308 317 minecraft:light_blue_concrete
setblock 332 273 278 minecraft:light[level=15]
setblock 332 273 286 minecraft:light[level=15]
setblock 332 273 294 minecraft:light[level=15]
setblock 332 273 302 minecraft:light[level=15]
setblock 332 273 310 minecraft:light[level=15]
fill 339 273 275 339 289 275 minecraft:light_blue_concrete
setblock 340 273 278 minecraft:light[level=15]
setblock 340 273 286 minecraft:light[level=15]
setblock 340 273 294 minecraft:light[level=15]
setblock 340 273 302 minecraft:light[level=15]
setblock 340 273 310 minecraft:light[level=15]
setblock 347 273 317 minecraft:white_wool
setblock 348 273 278 minecraft:light[level=15]
setblock 348 273 286 minecraft:light[level=15]
setblock 348 273 294 minecraft:light[level=15]
setblock 348 273 302 minecraft:light[level=15]
setblock 348 273 310 minecraft:light[level=15]
fill 352 273 317 352 308 317 minecraft:light_blue_concrete
setblock 356 273 278 minecraft:light[level=15]
setblock 356 273 286 minecraft:light[level=15]
setblock 356 273 294 minecraft:light[level=15]
setblock 356 273 302 minecraft:light[level=15]
setblock 356 273 310 minecraft:light[level=15]
fill 356 273 317 356 308 317 minecraft:light_blue_concrete
fill 360 273 317 360 308 317 minecraft:light_blue_concrete
setblock 364 273 278 minecraft:light[level=15]
setblock 364 273 286 minecraft:light[level=15]
setblock 364 273 294 minecraft:light[level=15]
setblock 364 273 302 minecraft:light[level=15]
setblock 364 273 310 minecraft:light[level=15]
setblock 367 273 317 minecraft:white_wool
fill 371 273 294 371 288 294 minecraft:light_blue_concrete
setblock 329 274 284 minecraft:white_wool
fill 329 274 287 329 308 287 minecraft:light_blue_concrete
setblock 334 274 275 minecraft:white_wool
fill 336 274 317 337 308 317 minecraft:light_blue_concrete
setblock 338 274 317 minecraft:white_wool
fill 339 274 317 342 288 317 minecraft:light_blue_concrete
fill 347 274 317 347 308 317 minecraft:light_blue_concrete
fill 367 274 317 367 295 317 minecraft:light_blue_concrete
setblock 371 274 290 minecraft:white_wool
fill 329 275 284 329 308 284 minecraft:light_blue_concrete
setblock 332 275 278 minecraft:light[level=12]
setblock 332 275 285 minecraft:light[level=12]
setblock 332 275 292 minecraft:light[level=12]
setblock 332 275 299 minecraft:light[level=12]
setblock 332 275 306 minecraft:light[level=12]
setblock 332 275 313 minecraft:light[level=12]
fill 334 275 275 334 308 275 minecraft:light_blue_concrete
setblock 337 275 275 minecraft:white_wool
fill 338 275 317 338 276 317 minecraft:light_blue_concrete
setblock 339 275 278 minecraft:light[level=12]
setblock 339 275 285 minecraft:light[level=12]
setblock 339 275 292 minecraft:light[level=12]
setblock 339 275 299 minecraft:light[level=12]
setblock 339 275 306 minecraft:light[level=12]
setblock 339 275 313 minecraft:light[level=12]
setblock 346 275 278 minecraft:light[level=12]
setblock 346 275 285 minecraft:light[level=12]
setblock 346 275 292 minecraft:light[level=12]
setblock 346 275 299 minecraft:light[level=12]
setblock 346 275 306 minecraft:light[level=12]
setblock 346 275 313 minecraft:light[level=12]
setblock 353 275 278 minecraft:light[level=12]
setblock 353 275 285 minecraft:light[level=12]
setblock 353 275 292 minecraft:light[level=12]
setblock 353 275 299 minecraft:light[level=12]
setblock 353 275 306 minecraft:light[level=12]
setblock 353 275 313 minecraft:light[level=12]
setblock 360 275 278 minecraft:light[level=12]
setblock 360 275 285 minecraft:light[level=12]
setblock 360 275 292 minecraft:light[level=12]
setblock 360 275 299 minecraft:light[level=12]
setblock 360 275 306 minecraft:light[level=12]
setblock 360 275 313 minecraft:light[level=12]
setblock 367 275 278 minecraft:light[level=12]
setblock 367 275 285 minecraft:light[level=12]
setblock 367 275 292 minecraft:light[level=12]
setblock 367 275 299 minecraft:light[level=12]
setblock 367 275 306 minecraft:light[level=12]
setblock 367 275 313 minecraft:light[level=12]
fill 371 275 290 371 281 290 minecraft:light_blue_concrete
fill 337 276 275 337 308 275 minecraft:light_blue_concrete
setblock 351 276 317 minecraft:white_wool
fill 330 277 276 330 279 283 minecraft:white_wool
fill 330 277 284 333 279 286 minecraft:light_gray_wool
fill 330 277 287 330 279 294 minecraft:white_wool
fill 330 277 295 333 279 296 minecraft:light_gray_wool
fill 330 277 297 330 279 304 minecraft:white_wool
fill 330 277 305 333 279 307 minecraft:light_gray_wool
fill 330 277 308 330 279 315 minecraft:white_wool
fill 330 277 316 333 279 316 minecraft:light_gray_wool
fill 331 277 276 332 279 276 minecraft:light_gray_wool
fill 331 277 277 335 279 283 minecraft:white_wool
fill 331 277 287 335 279 293 minecraft:white_wool
fill 331 277 294 333 279 294 minecraft:light_gray_wool
fill 331 277 297 332 279 297 minecraft:light_gray_wool
fill 331 277 298 335 279 304 minecraft:white_wool
fill 331 277 308 335 279 314 minecraft:white_wool
fill 331 277 315 333 279 315 minecraft:light_gray_wool
fill 333 277 276 342 279 276 minecraft:white_wool
fill 333 277 297 343 279 297 minecraft:white_wool
fill 334 277 284 342 279 286 minecraft:white_wool
fill 334 277 294 342 279 296 minecraft:white_wool
fill 334 277 305 342 279 307 minecraft:white_wool
fill 334 277 315 342 279 316 minecraft:white_wool
fill 336 277 277 337 279 278 minecraft:white_wool
fill 336 277 279 339 279 280 minecraft:light_gray_wool
fill 336 277 281 336 279 283 minecraft:white_wool
fill 336 277 287 336 279 289 minecraft:white_wool
fill 336 277 290 339 279 291 minecraft:light_gray_wool
fill 336 277 292 370 279 293 minecraft:white_wool
fill 336 277 298 337 279 299 minecraft:white_wool
fill 336 277 300 339 279 301 minecraft:light_gray_wool
fill 336 277 302 336 279 304 minecraft:white_wool
fill 336 277 308 336 279 310 minecraft:white_wool
fill 336 277 311 340 279 311 minecraft:light_gray_wool
fill 336 277 312 336 279 314 minecraft:white_wool
fill 337 277 281 339 279 281 minecraft:light_gray_wool
fill 337 277 282 370 279 283 minecraft:white_wool
fill 337 277 287 370 279 288 minecraft:white_wool
fill 337 277 289 339 279 289 minecraft:light_gray_wool
fill 337 277 302 339 279 302 minecraft:light_gray_wool
fill 337 277 303 370 279 304 minecraft:white_wool
fill 337 277 308 370 279 309 minecraft:white_wool
fill 337 277 310 339 279 310 minecraft:light_gray_wool
fill 337 277 312 339 279 312 minecraft:light_gray_wool
fill 337 277 313 370 279 314 minecraft:white_wool
fill 338 277 277 370 279 277 minecraft:white_wool
fill 338 277 278 338 279 278 minecraft:light_gray_wool
fill 338 277 298 345 278 298 minecraft:white_wool
fill 338 277 299 338 279 299 minecraft:light_gray_wool
setblock 338 277 317 minecraft:white_wool
fill 339 277 278 362 279 278 minecraft:white_wool
fill 339 277 299 346 278 299 minecraft:white_wool
fill 340 277 279 348 279 279 minecraft:white_wool
fill 340 277 280 340 279 280 minecraft:light_gray_wool
fill 340 277 281 348 279 281 minecraft:white_wool
fill 340 277 289 348 279 289 minecraft:white_wool
fill 340 277 290 340 279 290 minecraft:light_gray_wool
fill 340 277 291 348 279 291 minecraft:white_wool
fill 340 277 300 346 278 302 minecraft:white_wool
fill 340 277 310 348 279 310 minecraft:white_wool
fill 340 277 312 348 279 312 minecraft:white_wool
fill 341 277 280 348 279 280 minecraft:white_wool
fill 341 277 290 348 279 290 minecraft:white_wool
fill 341 277 311 348 279 311 minecraft:white_wool
fill 343 277 276 345 279 276 minecraft:light_gray_wool
fill 343 277 284 346 279 286 minecraft:light_gray_wool
fill 343 277 294 345 279 296 minecraft:light_gray_wool
fill 343 277 305 345 279 307 minecraft:light_gray_wool
fill 343 277 315 345 279 316 minecraft:light_gray_wool
fill 344 277 297 345 278 297 minecraft:light_gray_wool
fill 346 277 276 355 279 276 minecraft:white_wool
fill 346 277 294 355 278 294 minecraft:white_wool
fill 346 277 295 346 278 296 minecraft:light_gray_wool
fill 346 277 297 346 278 297 minecraft:white_wool
fill 346 277 305 346 279 306 minecraft:light_gray_wool
fill 346 277 307 354 279 307 minecraft:white_wool
fill 346 277 315 355 279 315 minecraft:white_wool
fill 346 277 316 346 279 316 minecraft:light_gray_wool
fill 347 277 284 354 279 286 minecraft:white_wool
fill 347 277 295 348 278 295 minecraft:white_wool
fill 347 277 301 348 278 302 minecraft:white_wool
fill 347 277 305 354 279 306 minecraft:white_wool
fill 347 277 316 354 279 316 minecraft:white_wool
fill 349 277 279 352 279 281 minecraft:light_gray_wool
fill 349 277 289 352 279 291 minecraft:light_gray_wool
fill 349 277 302 352 278 302 minecraft:light_gray_wool
fill 349 277 310 352 279 312 minecraft:light_gray_wool
fill 350 277 295 354 278 295 minecraft:white_wool
fill 350 277 301 352 278 301 minecraft:light_gray_wool
fill 351 277 317 351 308 317 minecraft:light_blue_concrete
fill 352 277 296 354 278 297 minecraft:white_wool
fill 352 277 299 362 278 299 minecraft:white_wool
fill 352 277 300 352 278 300 minecraft:light_gray_wool
fill 353 277 279 360 279 281 minecraft:white_wool
fill 353 277 289 360 279 291 minecraft:white_wool
fill 353 277 298 370 278 298 minecraft:white_wool
fill 353 277 300 360 279 302 minecraft:white_wool
fill 353 277 310 360 279 312 minecraft:white_wool
fill 355 277 284 358 279 286 minecraft:light_gray_wool
fill 355 277 295 358 279 296 minecraft:light_gray_wool
fill 355 277 297 355 279 297 minecraft:white_wool
fill 355 277 305 358 279 307 minecraft:light_gray_wool
fill 355 277 316 358 279 316 minecraft:light_gray_wool
fill 356 277 276 358 279 276 minecraft:light_gray_wool
fill 356 277 294 358 279 294 minecraft:light_gray_wool
fill 356 277 297 357 279 297 minecraft:light_gray_wool
fill 356 277 315 358 279 315 minecraft:light_gray_wool
setblock 358 277 275 minecraft:white_wool
fill 358 277 297 368 279 297 minecraft:white_wool
fill 359 277 276 368 279 276 minecraft:white_wool
fill 359 277 284 367 279 286 minecraft:white_wool
fill 359 277 294 367 279 296 minecraft:white_wool
fill 359 277 305 367 279 307 minecraft:white_wool
fill 359 277 315 367 279 316 minecraft:white_wool
fill 361 277 279 361 279 279 minecraft:white_wool
fill 361 277 280 365 279 280 minecraft:light_gray_wool
fill 361 277 281 361 279 281 minecraft:white_wool
fill 361 277 289 361 279 289 minecraft:white_wool
fill 361 277 290 365 279 290 minecraft:light_gray_wool
fill 361 277 291 361 279 291 minecraft:white_wool
fill 361 277 300 361 279 300 minecraft:white_wool
fill 361 277 301 365 279 301 minecraft:light_gray_wool
fill 361 277 302 361 279 302 minecraft:white_wool
fill 361 277 310 361 279 310 minecraft:white_wool
fill 361 277 311 365 279 311 minecraft:light_gray_wool
fill 361 277 312 361 279 312 minecraft:white_wool
fill 362 277 279 365 279 279 minecraft:light_gray_wool
fill 362 277 281 364 279 281 minecraft:light_gray_wool
fill 362 277 289 364 279 289 minecraft:light_gray_wool
fill 362 277 291 365 279 291 minecraft:light_gray_wool
fill 362 277 300 365 279 300 minecraft:light_gray_wool
fill 362 277 302 364 279 302 minecraft:light_gray_wool
fill 362 277 310 364 279 310 minecraft:light_gray_wool
fill 362 277 312 364 279 312 minecraft:light_gray_wool
fill 363 277 278 363 279 278 minecraft:light_gray_wool
fill 363 277 299 363 279 299 minecraft:light_gray_wool
fill 364 277 278 370 279 278 minecraft:white_wool
fill 364 277 299 370 279 299 minecraft:white_wool
fill 365 277 281 370 279 281 minecraft:white_wool
fill 365 277 289 370 279 289 minecraft:white_wool
fill 365 277 302 370 279 302 minecraft:white_wool
fill 365 277 310 370 279 310 minecraft:white_wool
fill 365 277 312 370 279 312 minecraft:white_wool
fill 366 277 279 370 279 280 minecraft:white_wool
fill 366 277 290 370 279 291 minecraft:white_wool
fill 366 277 300 370 279 301 minecraft:white_wool
fill 366 277 311 370 279 311 minecraft:white_wool
fill 368 277 284 370 279 286 minecraft:light_gray_wool
fill 368 277 294 370 279 296 minecraft:light_gray_wool
fill 368 277 305 370 279 307 minecraft:light_gray_wool
fill 368 277 315 370 279 316 minecraft:light_gray_wool
fill 369 277 276 370 279 276 minecraft:light_gray_wool
fill 369 277 297 370 279 297 minecraft:light_gray_wool
fill 338 278 317 338 308 317 minecraft:light_blue_concrete
fill 358 278 275 358 308 275 minecraft:light_blue_concrete
fill 329 279 298 329 308 298 minecraft:light_blue_concrete
setblock 329 279 299 minecraft:white_wool
fill 329 279 300 329 296 300 minecraft:light_blue_concrete
fill 338 279 298 344 279 298 minecraft:white_wool
fill 339 279 299 344 279 299 minecraft:white_wool
fill 340 279 300 345 279 302 minecraft:white_wool
setblock 344 279 297 minecraft:light_gray_wool
fill 345 279 297 345 279 299 minecraft:ochre_froglight
fill 346 279 294 347 279 294 minecraft:white_wool
fill 346 279 295 346 279 297 minecraft:ochre_froglight
fill 346 279 299 346 279 301 minecraft:ochre_froglight
fill 346 279 302 347 279 302 minecraft:white_wool
fill 347 279 295 348 279 295 minecraft:ochre_froglight
fill 347 279 301 348 279 301 minecraft:ochre_froglight
fill 348 279 294 350 279 294 minecraft:ochre_froglight
fill 348 279 302 350 279 302 minecraft:ochre_froglight
fill 350 279 295 352 279 295 minecraft:ochre_froglight
fill 350 279 301 352 279 301 minecraft:ochre_froglight
fill 351 279 294 355 279 294 minecraft:white_wool
fill 351 279 302 352 279 302 minecraft:light_gray_wool
fill 352 279 296 352 279 297 minecraft:ochre_froglight
fill 352 279 299 352 279 300 minecraft:ochre_froglight
fill 353 279 295 354 279 296 minecraft:white_wool
fill 353 279 297 353 279 299 minecraft:ochre_froglight
fill 354 279 297 354 279 299 minecraft:white_wool
fill 355 279 298 362 279 299 minecraft:white_wool
fill 363 279 298 370 279 298 minecraft:white_wool
fill 329 280 299 329 308 299 minecraft:light_blue_concrete
setblock 332 281 278 minecraft:light[level=15]
setblock 332 281 285 minecraft:light[level=12]
setblock 332 281 286 minecraft:light[level=15]
setblock 332 281 292 minecraft:light[level=12]
setblock 332 281 294 minecraft:light[level=15]
setblock 332 281 299 minecraft:light[level=12]
setblock 332 281 302 minecraft:light[level=15]
setblock 332 281 306 minecraft:light[level=12]
setblock 332 281 310 minecraft:light[level=15]
setblock 332 281 313 minecraft:light[level=12]
setblock 339 281 278 minecraft:light[level=12]
setblock 339 281 285 minecraft:light[level=12]
setblock 339 281 292 minecraft:light[level=12]
setblock 339 281 299 minecraft:light[level=12]
setblock 339 281 306 minecraft:light[level=12]
setblock 339 281 313 minecraft:light[level=12]
setblock 340 281 278 minecraft:light[level=15]
setblock 340 281 286 minecraft:light[level=15]
setblock 340 281 294 minecraft:light[level=15]
setblock 340 281 302 minecraft:light[level=15]
setblock 340 281 310 minecraft:light[level=15]
setblock 346 281 278 minecraft:light[level=12]
setblock 346 281 285 minecraft:light[level=12]
setblock 346 281 292 minecraft:light[level=12]
setblock 346 281 299 minecraft:light[level=12]
setblock 346 281 306 minecraft:light[level=12]
setblock 346 281 313 minecraft:light[level=12]
setblock 348 281 278 minecraft:light[level=15]
setblock 348 281 286 minecraft:light[level=15]
setblock 348 281 294 minecraft:light[level=15]
setblock 348 281 302 minecraft:light[level=15]
setblock 348 281 310 minecraft:light[level=15]
setblock 353 281 278 minecraft:light[level=12]
setblock 353 281 285 minecraft:light[level=12]
setblock 353 281 292 minecraft:light[level=12]
setblock 353 281 299 minecraft:light[level=12]
setblock 353 281 306 minecraft:light[level=12]
setblock 353 281 313 minecraft:light[level=12]
setblock 356 281 278 minecraft:light[level=15]
setblock 356 281 286 minecraft:light[level=15]
setblock 356 281 294 minecraft:light[level=15]
setblock 356 281 302 minecraft:light[level=15]
setblock 356 281 310 minecraft:light[level=15]
setblock 360 281 278 minecraft:light[level=12]
setblock 360 281 285 minecraft:light[level=12]
setblock 360 281 292 minecraft:light[level=12]
setblock 360 281 299 minecraft:light[level=12]
setblock 360 281 306 minecraft:light[level=12]
setblock 360 281 313 minecraft:light[level=12]
setblock 364 281 278 minecraft:light[level=15]
setblock 364 281 286 minecraft:light[level=15]
setblock 364 281 294 minecraft:light[level=15]
setblock 364 281 302 minecraft:light[level=15]
setblock 364 281 310 minecraft:light[level=15]
setblock 367 281 278 minecraft:light[level=12]
setblock 367 281 285 minecraft:light[level=12]
setblock 367 281 292 minecraft:light[level=12]
setblock 367 281 299 minecraft:light[level=12]
setblock 367 281 306 minecraft:light[level=12]
setblock 367 281 313 minecraft:light[level=12]
setblock 371 282 290 minecraft:white_wool
setblock 352 283 275 minecraft:white_wool
setblock 371 283 276 minecraft:white_wool
fill 371 283 290 371 308 290 minecraft:light_blue_concrete
fill 371 283 299 371 308 301 minecraft:light_blue_concrete
setblock 371 283 302 minecraft:white_wool
fill 338 284 302 338 285 302 minecraft:ochre_froglight
fill 348 284 308 348 285 310 minecraft:white_wool
fill 349 284 308 349 285 309 minecraft:white_wool
fill 352 284 275 352 308 275 minecraft:light_blue_concrete
setblock 367 284 275 minecraft:white_wool
fill 371 284 276 371 293 276 minecraft:light_blue_concrete
fill 371 284 302 371 291 302 minecraft:light_blue_concrete
fill 357 285 317 358 285 317 minecraft:white_wool
setblock 363 285 275 minecraft:white_wool
fill 367 285 275 367 308 275 minecraft:light_blue_concrete
setblock 368 285 317 minecraft:white_wool
setblock 329 286 311 minecraft:white_wool
fill 329 286 312 329 308 313 minecraft:light_blue_concrete
setblock 329 286 314 minecraft:white_wool
fill 338 286 302 338 293 302 minecraft:dirt
fill 347 286 285 348 287 286 minecraft:white_concrete
fill 357 286 317 358 308 317 minecraft:light_blue_concrete
fill 363 286 275 363 308 275 minecraft:light_blue_concrete
fill 368 286 317 368 308 317 minecraft:light_blue_concrete
fill 329 287 311 329 303 311 minecraft:light_blue_concrete
fill 329 287 314 329 302 314 minecraft:light_blue_concrete
setblock 332 287 278 minecraft:light[level=12]
setblock 332 287 285 minecraft:light[level=12]
setblock 332 287 292 minecraft:light[level=12]
setblock 332 287 299 minecraft:light[level=12]
setblock 332 287 306 minecraft:light[level=12]
setblock 332 287 313 minecraft:light[level=12]
fill 337 287 302 337 293 302 minecraft:dirt
fill 338 287 301 338 293 301 minecraft:dirt
setblock 339 287 278 minecraft:light[level=12]
setblock 339 287 285 minecraft:light[level=12]
setblock 339 287 292 minecraft:light[level=12]
setblock 339 287 299 minecraft:light[level=12]
setblock 339 287 306 minecraft:light[level=12]
setblock 339 287 313 minecraft:light[level=12]
setblock 346 287 278 minecraft:light[level=12]
setblock 346 287 285 minecraft:light[level=12]
setblock 346 287 292 minecraft:light[level=12]
setblock 346 287 299 minecraft:light[level=12]
setblock 346 287 306 minecraft:light[level=12]
setblock 346 287 313 minecraft:light[level=12]
setblock 353 287 278 minecraft:light[level=12]
setblock 353 287 285 minecraft:light[level=12]
setblock 353 287 292 minecraft:light[level=12]
setblock 353 287 299 minecraft:light[level=12]
setblock 353 287 306 minecraft:light[level=12]
setblock 353 287 313 minecraft:light[level=12]
setblock 360 287 278 minecraft:light[level=12]
setblock 360 287 285 minecraft:light[level=12]
setblock 360 287 292 minecraft:light[level=12]
setblock 360 287 299 minecraft:light[level=12]
setblock 360 287 306 minecraft:light[level=12]
setblock 360 287 313 minecraft:light[level=12]
setblock 367 287 278 minecraft:light[level=12]
setblock 367 287 285 minecraft:light[level=12]
setblock 367 287 292 minecraft:light[level=12]
setblock 367 287 299 minecraft:light[level=12]
setblock 367 287 306 minecraft:light[level=12]
setblock 367 287 313 minecraft:light[level=12]
fill 329 288 279 329 308 279 minecraft:light_blue_concrete
setblock 329 288 280 minecraft:white_wool
fill 337 288 301 337 293 301 minecraft:dirt
setblock 347 288 275 minecraft:white_wool
fill 348 288 275 348 308 275 minecraft:light_blue_concrete
setblock 371 288 308 minecraft:white_wool
fill 329 289 280 329 308 280 minecraft:light_blue_concrete
setblock 332 289 278 minecraft:light[level=15]
setblock 332 289 286 minecraft:light[level=15]
setblock 332 289 294 minecraft:light[level=15]
setblock 332 289 302 minecraft:light[level=15]
setblock 332 289 310 minecraft:light[level=15]
fill 336 289 302 336 293 302 minecraft:dirt
fill 337 289 300 338 293 300 minecraft:dirt
fill 337 289 303 338 293 303 minecraft:dirt
fill 339 289 301 339 293 302 minecraft:dirt
fill 339 289 317 340 292 317 minecraft:light_blue_concrete
setblock 340 289 278 minecraft:light[level=15]
setblock 340 289 286 minecraft:light[level=15]
setblock 340 289 294 minecraft:light[level=15]
setblock 340 289 302 minecraft:light[level=15]
setblock 340 289 310 minecraft:light[level=15]
setblock 341 289 317 minecraft:white_wool
fill 342 289 317 342 308 317 minecraft:light_blue_concrete
fill 347 289 275 347 308 275 minecraft:light_blue_concrete
setblock 348 289 278 minecraft:light[level=15]
setblock 348 289 286 minecraft:light[level=15]
setblock 348 289 294 minecraft:light[level=15]
setblock 348 289 302 minecraft:light[level=15]
setblock 348 289 310 minecraft:light[level=15]
setblock 356 289 278 minecraft:light[level=15]
setblock 356 289 286 minecraft:light[level=15]
setblock 356 289 294 minecraft:light[level=15]
setblock 356 289 302 minecraft:light[level=15]
setblock 356 289 310 minecraft:light[level=15]
setblock 364 289 278 minecraft:light[level=15]
setblock 364 289 286 minecraft:light[level=15]
setblock 364 289 294 minecraft:light[level=15]
setblock 364 289 302 minecraft:light[level=15]
setblock 364 289 310 minecraft:light[level=15]
setblock 371 289 294 minecraft:white_wool
fill 371 289 308 371 308 308 minecraft:light_blue_concrete
fill 336 290 301 336 293 301 minecraft:dirt
fill 336 290 303 336 293 303 minecraft:dirt
setblock 339 290 275 minecraft:white_wool
fill 339 290 300 339 293 300 minecraft:dirt
fill 339 290 303 339 293 303 minecraft:dirt
fill 341 290 317 341 308 317 minecraft:light_blue_concrete
setblock 343 290 317 minecraft:white_wool
fill 371 290 294 371 308 294 minecraft:light_blue_concrete
fill 336 291 300 336 293 300 minecraft:dirt
fill 337 291 304 339 293 304 minecraft:dirt
setblock 338 291 275 minecraft:white_wool
fill 338 291 299 338 293 299 minecraft:dirt
fill 339 291 275 339 308 275 minecraft:light_blue_concrete
fill 340 291 301 340 293 303 minecraft:dirt
fill 343 291 317 343 308 317 minecraft:light_blue_concrete
setblock 344 291 275 minecraft:white_wool
fill 361 291 275 361 308 275 minecraft:light_blue_concrete
setblock 362 291 275 minecraft:white_wool
fill 335 292 300 335 293 303 minecraft:dirt
fill 336 292 299 337 293 299 minecraft:dirt
fill 336 292 304 336 293 304 minecraft:dirt
fill 338 292 275 338 308 275 minecraft:light_blue_concrete
fill 339 292 299 339 293 299 minecraft:dirt
fill 340 292 300 340 293 300 minecraft:dirt
fill 344 292 275 344 308 275 minecraft:light_blue_concrete
fill 362 292 275 362 308 275 minecraft:light_blue_concrete
setblock 371 292 302 minecraft:white_wool
setblock 329 293 294 minecraft:white_wool
setblock 332 293 278 minecraft:light[level=12]
setblock 332 293 285 minecraft:light[level=12]
setblock 332 293 292 minecraft:light[level=12]
setblock 332 293 299 minecraft:light[level=12]
setblock 332 293 306 minecraft:light[level=12]
setblock 332 293 313 minecraft:light[level=12]
setblock 335 293 304 minecraft:dirt
fill 337 293 305 339 293 305 minecraft:dirt
setblock 338 293 298 minecraft:dirt
setblock 339 293 278 minecraft:light[level=12]
schedule function dropper:buildpart/67_3 1t
