setblock 384 252 314 minecraft:stripped_oak_log
fill 384 252 315 384 255 315 minecraft:red_terracotta
setblock 385 252 313 minecraft:stripped_oak_log
fill 385 252 314 385 255 314 minecraft:red_terracotta
setblock 386 252 276 minecraft:red_terracotta
setblock 386 252 277 minecraft:stripped_oak_log
setblock 386 252 313 minecraft:red_terracotta
setblock 387 252 276 minecraft:stripped_oak_log
fill 387 252 277 387 255 277 minecraft:red_terracotta
setblock 387 252 316 minecraft:stripped_oak_log
fill 388 252 276 388 255 276 minecraft:red_terracotta
setblock 388 252 315 minecraft:stripped_oak_log
fill 388 252 316 388 255 316 minecraft:red_terracotta
setblock 389 252 314 minecraft:stripped_oak_log
fill 389 252 315 389 255 315 minecraft:red_terracotta
setblock 390 252 277 minecraft:red_terracotta
setblock 390 252 314 minecraft:red_terracotta
setblock 392 252 276 minecraft:stripped_oak_log
setblock 392 252 316 minecraft:stripped_oak_log
fill 393 252 276 396 252 276 minecraft:red_terracotta
fill 393 252 316 393 254 316 minecraft:red_terracotta
setblock 397 252 276 minecraft:stripped_oak_log
setblock 397 252 316 minecraft:stripped_oak_log
fill 398 252 276 401 252 276 minecraft:red_terracotta
fill 398 252 316 401 252 316 minecraft:red_terracotta
setblock 401 252 277 minecraft:stripped_oak_log
setblock 402 252 276 minecraft:stripped_oak_log
fill 402 252 277 402 255 277 minecraft:red_terracotta
setblock 402 252 315 minecraft:red_terracotta
setblock 402 252 316 minecraft:stripped_oak_log
fill 403 252 276 403 255 276 minecraft:red_terracotta
fill 403 252 278 404 252 278 minecraft:red_terracotta
setblock 403 252 315 minecraft:stripped_oak_log
fill 403 252 316 403 255 316 minecraft:red_terracotta
fill 404 252 315 404 255 315 minecraft:red_terracotta
setblock 405 252 277 minecraft:red_terracotta
setblock 405 252 278 minecraft:stripped_oak_log
fill 405 252 314 408 252 314 minecraft:red_terracotta
setblock 406 252 277 minecraft:stripped_oak_log
fill 406 252 278 409 252 278 minecraft:red_terracotta
setblock 407 252 276 minecraft:stripped_oak_log
fill 407 252 277 407 255 277 minecraft:red_terracotta
fill 407 252 279 408 252 279 minecraft:red_terracotta
setblock 407 252 316 minecraft:stripped_oak_log
fill 408 252 276 408 255 276 minecraft:red_terracotta
setblock 408 252 315 minecraft:stripped_oak_log
fill 408 252 316 408 255 316 minecraft:red_terracotta
setblock 409 252 314 minecraft:stripped_oak_log
fill 409 252 315 409 255 315 minecraft:red_terracotta
setblock 410 252 278 minecraft:stripped_oak_log
fill 410 252 314 410 253 314 minecraft:red_terracotta
setblock 411 252 277 minecraft:stripped_oak_log
fill 411 252 278 411 255 278 minecraft:red_terracotta
setblock 412 252 276 minecraft:stripped_oak_log
fill 412 252 277 412 255 277 minecraft:red_terracotta
setblock 412 252 316 minecraft:stripped_oak_log
fill 413 252 276 413 255 276 minecraft:red_terracotta
setblock 413 252 315 minecraft:stripped_oak_log
fill 413 252 316 413 255 316 minecraft:red_terracotta
fill 414 252 315 414 255 315 minecraft:red_terracotta
setblock 416 252 277 minecraft:stripped_oak_log
fill 416 252 278 416 255 278 minecraft:red_terracotta
fill 416 252 313 416 253 313 minecraft:red_terracotta
setblock 417 252 276 minecraft:stripped_oak_log
fill 417 252 277 417 255 277 minecraft:red_terracotta
setblock 417 252 280 minecraft:red_terracotta
fill 417 252 294 417 252 295 minecraft:red_terracotta
setblock 417 252 311 minecraft:stripped_oak_log
fill 417 252 312 417 255 312 minecraft:red_terracotta
setblock 417 252 316 minecraft:stripped_oak_log
fill 418 252 276 418 255 316 minecraft:orange_terracotta
fill 377 253 276 380 253 276 minecraft:red_terracotta
fill 377 253 278 377 254 278 minecraft:red_terracotta
fill 377 253 293 377 253 294 minecraft:red_terracotta
setblock 377 253 295 minecraft:stripped_oak_log
fill 377 253 296 377 256 296 minecraft:red_terracotta
setblock 377 253 300 minecraft:stripped_oak_log
fill 377 253 301 377 255 302 minecraft:red_terracotta
setblock 377 253 310 minecraft:stripped_oak_log
fill 377 253 311 377 256 311 minecraft:red_terracotta
setblock 377 253 314 minecraft:red_terracotta
setblock 377 253 315 minecraft:stripped_oak_log
fill 377 253 316 377 256 316 minecraft:red_terracotta
setblock 378 253 314 minecraft:stripped_oak_log
fill 378 253 315 378 256 315 minecraft:red_terracotta
setblock 379 253 314 minecraft:red_terracotta
setblock 381 253 276 minecraft:stripped_oak_log
setblock 381 253 316 minecraft:stripped_oak_log
fill 382 253 276 384 253 277 minecraft:red_terracotta
setblock 382 253 315 minecraft:stripped_oak_log
fill 382 253 316 382 256 316 minecraft:red_terracotta
setblock 383 253 314 minecraft:stripped_oak_log
fill 383 253 315 383 256 315 minecraft:red_terracotta
fill 384 253 314 384 255 314 minecraft:red_terracotta
setblock 385 253 276 minecraft:red_terracotta
setblock 385 253 277 minecraft:stripped_oak_log
setblock 386 253 276 minecraft:stripped_oak_log
fill 386 253 277 386 256 277 minecraft:red_terracotta
setblock 386 253 316 minecraft:stripped_oak_log
fill 387 253 276 387 256 276 minecraft:red_terracotta
setblock 387 253 315 minecraft:stripped_oak_log
fill 387 253 316 387 256 316 minecraft:red_terracotta
setblock 388 253 314 minecraft:stripped_oak_log
fill 388 253 315 388 256 315 minecraft:red_terracotta
setblock 389 253 314 minecraft:red_terracotta
setblock 390 253 277 minecraft:stripped_oak_log
setblock 391 253 276 minecraft:stripped_oak_log
setblock 391 253 316 minecraft:stripped_oak_log
fill 392 253 276 395 253 276 minecraft:red_terracotta
setblock 392 253 315 minecraft:stripped_oak_log
fill 392 253 316 392 255 316 minecraft:red_terracotta
setblock 396 253 276 minecraft:stripped_oak_log
setblock 396 253 316 minecraft:stripped_oak_log
fill 397 253 276 400 253 276 minecraft:red_terracotta
fill 397 253 316 400 253 316 minecraft:red_terracotta
setblock 400 253 277 minecraft:stripped_oak_log
setblock 401 253 276 minecraft:stripped_oak_log
fill 401 253 277 401 256 277 minecraft:red_terracotta
setblock 401 253 316 minecraft:stripped_oak_log
fill 402 253 276 402 256 276 minecraft:red_terracotta
fill 402 253 278 403 253 278 minecraft:red_terracotta
setblock 402 253 315 minecraft:stripped_oak_log
fill 402 253 316 402 256 316 minecraft:red_terracotta
fill 403 253 315 403 256 315 minecraft:red_terracotta
setblock 404 253 278 minecraft:stripped_oak_log
setblock 405 253 277 minecraft:stripped_oak_log
fill 405 253 278 407 253 279 minecraft:red_terracotta
fill 405 253 314 407 253 314 minecraft:red_terracotta
setblock 406 253 276 minecraft:stripped_oak_log
fill 406 253 277 406 256 277 minecraft:red_terracotta
setblock 406 253 316 minecraft:stripped_oak_log
fill 407 253 276 407 256 276 minecraft:red_terracotta
setblock 407 253 315 minecraft:stripped_oak_log
fill 407 253 316 407 256 316 minecraft:red_terracotta
setblock 408 253 278 minecraft:red_terracotta
setblock 408 253 279 minecraft:stripped_oak_log
setblock 408 253 314 minecraft:stripped_oak_log
fill 408 253 315 408 256 315 minecraft:red_terracotta
setblock 409 253 278 minecraft:stripped_oak_log
fill 409 253 279 409 255 279 minecraft:red_terracotta
fill 409 253 314 409 254 314 minecraft:red_terracotta
setblock 410 253 277 minecraft:stripped_oak_log
fill 410 253 278 410 256 278 minecraft:red_terracotta
setblock 411 253 276 minecraft:stripped_oak_log
fill 411 253 277 411 256 277 minecraft:red_terracotta
setblock 411 253 316 minecraft:stripped_oak_log
fill 412 253 276 412 256 276 minecraft:red_terracotta
setblock 412 253 315 minecraft:stripped_oak_log
fill 412 253 316 412 256 316 minecraft:red_terracotta
setblock 413 253 278 minecraft:red_terracotta
fill 413 253 315 413 255 315 minecraft:red_terracotta
setblock 414 253 277 minecraft:red_terracotta
setblock 415 253 277 minecraft:stripped_oak_log
setblock 416 253 276 minecraft:stripped_oak_log
fill 416 253 277 416 256 277 minecraft:red_terracotta
setblock 416 253 316 minecraft:stripped_oak_log
fill 417 253 276 417 256 276 minecraft:red_terracotta
setblock 417 253 280 minecraft:stripped_oak_log
setblock 417 253 294 minecraft:red_terracotta
setblock 417 253 295 minecraft:stripped_oak_log
fill 417 253 296 417 254 296 minecraft:red_terracotta
fill 417 253 311 417 254 311 minecraft:red_terracotta
setblock 417 253 315 minecraft:stripped_oak_log
fill 417 253 316 417 256 316 minecraft:red_terracotta
fill 377 254 276 379 254 276 minecraft:red_terracotta
setblock 377 254 293 minecraft:red_terracotta
setblock 377 254 294 minecraft:stripped_oak_log
fill 377 254 295 377 257 295 minecraft:red_terracotta
fill 377 254 297 377 254 298 minecraft:red_terracotta
setblock 377 254 299 minecraft:stripped_oak_log
fill 377 254 300 378 256 300 minecraft:red_terracotta
setblock 377 254 303 minecraft:red_terracotta
setblock 377 254 304 minecraft:stripped_oak_log
setblock 377 254 309 minecraft:stripped_oak_log
fill 377 254 310 377 256 310 minecraft:red_terracotta
setblock 377 254 314 minecraft:stripped_oak_log
fill 377 254 315 377 257 315 minecraft:red_terracotta
fill 378 254 296 378 254 297 minecraft:red_terracotta
setblock 378 254 298 minecraft:stripped_oak_log
fill 378 254 299 378 257 299 minecraft:red_terracotta
setblock 378 254 313 minecraft:stripped_oak_log
fill 378 254 314 378 256 314 minecraft:red_terracotta
setblock 380 254 276 minecraft:stripped_oak_log
setblock 380 254 316 minecraft:stripped_oak_log
fill 381 254 276 383 254 277 minecraft:red_terracotta
setblock 381 254 315 minecraft:stripped_oak_log
fill 381 254 316 381 257 316 minecraft:red_terracotta
setblock 382 254 314 minecraft:stripped_oak_log
fill 382 254 315 382 257 315 minecraft:red_terracotta
fill 383 254 314 383 256 314 minecraft:red_terracotta
setblock 384 254 276 minecraft:red_terracotta
setblock 384 254 277 minecraft:stripped_oak_log
setblock 385 254 276 minecraft:stripped_oak_log
fill 385 254 277 385 257 277 minecraft:red_terracotta
setblock 385 254 316 minecraft:stripped_oak_log
fill 386 254 276 386 257 276 minecraft:red_terracotta
setblock 386 254 315 minecraft:stripped_oak_log
fill 386 254 316 386 257 316 minecraft:red_terracotta
setblock 387 254 314 minecraft:stripped_oak_log
fill 387 254 315 387 256 315 minecraft:red_terracotta
setblock 388 254 277 minecraft:red_terracotta
setblock 388 254 314 minecraft:red_terracotta
setblock 389 254 277 minecraft:stripped_oak_log
setblock 390 254 276 minecraft:stripped_oak_log
setblock 390 254 277 minecraft:red_terracotta
setblock 390 254 316 minecraft:stripped_oak_log
fill 391 254 276 394 254 276 minecraft:red_terracotta
setblock 391 254 315 minecraft:stripped_oak_log
fill 391 254 316 391 255 316 minecraft:red_terracotta
setblock 395 254 276 minecraft:stripped_oak_log
fill 396 254 276 399 254 276 minecraft:red_terracotta
fill 398 254 316 399 254 316 minecraft:red_terracotta
setblock 399 254 277 minecraft:stripped_oak_log
setblock 400 254 276 minecraft:stripped_oak_log
fill 400 254 277 400 257 277 minecraft:red_terracotta
setblock 400 254 316 minecraft:stripped_oak_log
fill 401 254 276 401 257 276 minecraft:red_terracotta
fill 401 254 278 402 254 278 minecraft:red_terracotta
fill 401 254 316 401 257 316 minecraft:red_terracotta
fill 402 254 315 402 256 315 minecraft:red_terracotta
setblock 403 254 278 minecraft:stripped_oak_log
setblock 404 254 277 minecraft:stripped_oak_log
fill 404 254 278 406 254 279 minecraft:red_terracotta
setblock 405 254 276 minecraft:stripped_oak_log
fill 405 254 277 405 257 277 minecraft:red_terracotta
setblock 405 254 316 minecraft:stripped_oak_log
fill 406 254 276 406 257 276 minecraft:red_terracotta
setblock 406 254 314 minecraft:red_terracotta
setblock 406 254 315 minecraft:stripped_oak_log
fill 406 254 316 406 257 316 minecraft:red_terracotta
setblock 407 254 278 minecraft:red_terracotta
setblock 407 254 279 minecraft:stripped_oak_log
setblock 407 254 314 minecraft:stripped_oak_log
fill 407 254 315 407 257 315 minecraft:red_terracotta
setblock 408 254 278 minecraft:stripped_oak_log
fill 408 254 279 408 256 279 minecraft:red_terracotta
setblock 408 254 314 minecraft:red_terracotta
setblock 409 254 277 minecraft:stripped_oak_log
fill 409 254 278 409 257 278 minecraft:red_terracotta
setblock 410 254 276 minecraft:stripped_oak_log
fill 410 254 277 410 257 277 minecraft:red_terracotta
setblock 410 254 316 minecraft:stripped_oak_log
fill 411 254 276 411 257 276 minecraft:red_terracotta
setblock 411 254 315 minecraft:stripped_oak_log
fill 411 254 316 411 257 316 minecraft:red_terracotta
fill 412 254 315 412 256 315 minecraft:red_terracotta
setblock 413 254 278 minecraft:stripped_oak_log
setblock 414 254 277 minecraft:stripped_oak_log
setblock 415 254 276 minecraft:stripped_oak_log
fill 415 254 277 415 257 277 minecraft:red_terracotta
setblock 415 254 316 minecraft:stripped_oak_log
fill 416 254 276 416 257 276 minecraft:red_terracotta
setblock 416 254 315 minecraft:stripped_oak_log
fill 416 254 316 416 257 316 minecraft:red_terracotta
setblock 417 254 278 minecraft:red_terracotta
setblock 417 254 279 minecraft:stripped_oak_log
fill 417 254 280 417 257 280 minecraft:red_terracotta
fill 417 254 297 417 255 297 minecraft:red_terracotta
setblock 417 254 314 minecraft:stripped_oak_log
fill 417 254 315 417 257 315 minecraft:red_terracotta
fill 377 255 276 378 255 276 minecraft:red_terracotta
setblock 377 255 278 minecraft:stripped_oak_log
fill 377 255 294 377 256 294 minecraft:red_terracotta
setblock 377 255 297 minecraft:red_terracotta
setblock 377 255 298 minecraft:stripped_oak_log
fill 377 255 299 377 258 299 minecraft:red_terracotta
setblock 377 255 303 minecraft:stripped_oak_log
fill 377 255 304 377 256 306 minecraft:red_terracotta
setblock 377 255 308 minecraft:stripped_oak_log
setblock 377 255 309 minecraft:red_terracotta
setblock 377 255 313 minecraft:stripped_oak_log
fill 377 255 314 377 258 314 minecraft:red_terracotta
setblock 378 255 296 minecraft:red_terracotta
setblock 378 255 297 minecraft:stripped_oak_log
fill 378 255 298 378 258 298 minecraft:red_terracotta
setblock 378 255 301 minecraft:red_terracotta
setblock 378 255 302 minecraft:stripped_oak_log
setblock 378 255 312 minecraft:stripped_oak_log
setblock 378 255 313 minecraft:red_terracotta
setblock 379 255 276 minecraft:stripped_oak_log
setblock 379 255 278 minecraft:light[level=15]
setblock 379 255 286 minecraft:light[level=15]
setblock 379 255 294 minecraft:light[level=15]
setblock 379 255 302 minecraft:light[level=15]
setblock 379 255 310 minecraft:light[level=15]
setblock 379 255 316 minecraft:stripped_oak_log
fill 380 255 276 382 255 277 minecraft:red_terracotta
setblock 380 255 315 minecraft:stripped_oak_log
fill 380 255 316 380 258 316 minecraft:red_terracotta
setblock 381 255 314 minecraft:stripped_oak_log
fill 381 255 315 381 258 315 minecraft:red_terracotta
setblock 382 255 314 minecraft:red_terracotta
setblock 383 255 276 minecraft:red_terracotta
setblock 383 255 277 minecraft:stripped_oak_log
setblock 384 255 276 minecraft:stripped_oak_log
fill 384 255 277 384 258 277 minecraft:red_terracotta
setblock 384 255 316 minecraft:stripped_oak_log
fill 385 255 276 385 258 276 minecraft:red_terracotta
setblock 385 255 315 minecraft:stripped_oak_log
fill 385 255 316 385 258 316 minecraft:red_terracotta
setblock 386 255 314 minecraft:stripped_oak_log
fill 386 255 315 386 257 315 minecraft:red_terracotta
setblock 387 255 278 minecraft:light[level=15]
setblock 387 255 286 minecraft:light[level=15]
setblock 387 255 294 minecraft:light[level=15]
setblock 387 255 302 minecraft:light[level=15]
setblock 387 255 310 minecraft:light[level=15]
setblock 388 255 277 minecraft:stripped_oak_log
setblock 389 255 276 minecraft:stripped_oak_log
fill 389 255 277 389 256 277 minecraft:red_terracotta
setblock 389 255 316 minecraft:stripped_oak_log
fill 390 255 276 393 255 276 minecraft:red_terracotta
fill 390 255 316 390 256 316 minecraft:red_terracotta
setblock 394 255 276 minecraft:stripped_oak_log
fill 395 255 276 398 255 276 minecraft:red_terracotta
setblock 395 255 278 minecraft:light[level=15]
setblock 395 255 286 minecraft:light[level=15]
setblock 395 255 294 minecraft:light[level=15]
setblock 395 255 302 minecraft:light[level=15]
setblock 395 255 310 minecraft:light[level=15]
setblock 398 255 277 minecraft:stripped_oak_log
setblock 398 255 316 minecraft:red_terracotta
setblock 399 255 276 minecraft:stripped_oak_log
fill 399 255 277 399 258 277 minecraft:red_terracotta
setblock 399 255 316 minecraft:stripped_oak_log
fill 400 255 276 400 258 276 minecraft:red_terracotta
fill 400 255 316 400 258 316 minecraft:red_terracotta
setblock 401 255 278 minecraft:red_terracotta
setblock 402 255 278 minecraft:stripped_oak_log
setblock 403 255 277 minecraft:stripped_oak_log
fill 403 255 278 405 255 279 minecraft:red_terracotta
setblock 403 255 286 minecraft:light[level=15]
setblock 403 255 294 minecraft:light[level=15]
setblock 403 255 302 minecraft:light[level=15]
setblock 403 255 310 minecraft:light[level=15]
setblock 404 255 276 minecraft:stripped_oak_log
fill 404 255 277 404 258 277 minecraft:red_terracotta
setblock 404 255 316 minecraft:stripped_oak_log
fill 405 255 276 405 258 276 minecraft:red_terracotta
setblock 405 255 315 minecraft:stripped_oak_log
fill 405 255 316 405 258 316 minecraft:red_terracotta
setblock 406 255 278 minecraft:red_terracotta
setblock 406 255 279 minecraft:stripped_oak_log
fill 406 255 315 406 258 315 minecraft:red_terracotta
setblock 407 255 278 minecraft:stripped_oak_log
fill 407 255 279 407 257 279 minecraft:red_terracotta
setblock 408 255 277 minecraft:stripped_oak_log
fill 408 255 278 408 258 278 minecraft:red_terracotta
setblock 409 255 276 minecraft:stripped_oak_log
fill 409 255 277 409 258 277 minecraft:red_terracotta
setblock 409 255 316 minecraft:stripped_oak_log
fill 410 255 276 410 258 276 minecraft:red_terracotta
setblock 410 255 315 minecraft:stripped_oak_log
fill 410 255 316 410 258 316 minecraft:red_terracotta
setblock 411 255 286 minecraft:light[level=15]
setblock 411 255 294 minecraft:light[level=15]
setblock 411 255 302 minecraft:light[level=15]
setblock 411 255 310 minecraft:light[level=15]
fill 411 255 315 411 256 315 minecraft:red_terracotta
setblock 412 255 278 minecraft:stripped_oak_log
setblock 413 255 277 minecraft:stripped_oak_log
setblock 414 255 276 minecraft:stripped_oak_log
fill 414 255 277 414 258 277 minecraft:red_terracotta
setblock 414 255 316 minecraft:stripped_oak_log
fill 415 255 276 415 258 276 minecraft:red_terracotta
setblock 415 255 315 minecraft:stripped_oak_log
fill 415 255 316 415 258 316 minecraft:red_terracotta
fill 416 255 315 416 256 315 minecraft:red_terracotta
setblock 417 255 278 minecraft:stripped_oak_log
fill 417 255 279 417 258 279 minecraft:red_terracotta
fill 417 255 281 417 256 281 minecraft:red_terracotta
setblock 417 255 298 minecraft:stripped_oak_log
setblock 417 255 313 minecraft:stripped_oak_log
fill 417 255 314 417 258 314 minecraft:red_terracotta
fill 376 256 275 376 259 317 minecraft:red_terracotta
fill 377 256 275 377 256 276 minecraft:red_terracotta
setblock 377 256 277 minecraft:stripped_oak_log
fill 377 256 278 377 259 278 minecraft:red_terracotta
setblock 377 256 297 minecraft:stripped_oak_log
fill 377 256 298 377 259 298 minecraft:red_terracotta
setblock 377 256 301 minecraft:red_terracotta
setblock 377 256 302 minecraft:stripped_oak_log
fill 377 256 303 378 258 303 minecraft:red_terracotta
setblock 377 256 312 minecraft:stripped_oak_log
fill 377 256 313 377 258 313 minecraft:red_terracotta
fill 377 256 317 418 259 317 minecraft:red_terracotta
fill 378 256 275 418 259 275 minecraft:red_terracotta
setblock 378 256 276 minecraft:stripped_oak_log
setblock 378 256 296 minecraft:stripped_oak_log
fill 378 256 297 378 259 297 minecraft:red_terracotta
setblock 378 256 301 minecraft:stripped_oak_log
fill 378 256 302 378 259 302 minecraft:red_terracotta
setblock 378 256 316 minecraft:stripped_oak_log
fill 379 256 276 382 256 276 minecraft:red_terracotta
fill 379 256 298 379 256 299 minecraft:red_terracotta
setblock 379 256 300 minecraft:stripped_oak_log
setblock 379 256 315 minecraft:stripped_oak_log
fill 379 256 316 379 259 316 minecraft:red_terracotta
fill 380 256 277 381 256 277 minecraft:red_terracotta
fill 380 256 315 380 258 315 minecraft:red_terracotta
setblock 382 256 277 minecraft:stripped_oak_log
setblock 383 256 276 minecraft:stripped_oak_log
fill 383 256 277 383 259 277 minecraft:red_terracotta
setblock 383 256 316 minecraft:stripped_oak_log
fill 384 256 276 384 259 276 minecraft:red_terracotta
setblock 384 256 315 minecraft:stripped_oak_log
fill 384 256 316 384 259 316 minecraft:red_terracotta
fill 385 256 315 385 257 315 minecraft:red_terracotta
setblock 387 256 277 minecraft:stripped_oak_log
setblock 388 256 276 minecraft:stripped_oak_log
setblock 388 256 277 minecraft:red_terracotta
setblock 388 256 316 minecraft:stripped_oak_log
fill 389 256 276 392 256 276 minecraft:red_terracotta
fill 389 256 316 389 257 316 minecraft:red_terracotta
setblock 393 256 276 minecraft:stripped_oak_log
fill 394 256 276 397 256 276 minecraft:red_terracotta
setblock 398 256 276 minecraft:stripped_oak_log
fill 398 256 277 398 259 277 minecraft:red_terracotta
fill 399 256 276 399 259 276 minecraft:red_terracotta
fill 399 256 316 399 257 316 minecraft:red_terracotta
setblock 400 256 278 minecraft:red_terracotta
setblock 401 256 278 minecraft:stripped_oak_log
setblock 402 256 277 minecraft:stripped_oak_log
fill 402 256 278 405 256 278 minecraft:red_terracotta
setblock 403 256 276 minecraft:stripped_oak_log
fill 403 256 277 403 259 277 minecraft:red_terracotta
fill 403 256 279 404 256 279 minecraft:red_terracotta
setblock 403 256 316 minecraft:stripped_oak_log
fill 404 256 276 404 259 276 minecraft:red_terracotta
setblock 404 256 315 minecraft:stripped_oak_log
fill 404 256 316 404 259 316 minecraft:red_terracotta
setblock 405 256 279 minecraft:stripped_oak_log
fill 405 256 315 405 258 315 minecraft:red_terracotta
setblock 406 256 278 minecraft:stripped_oak_log
fill 406 256 279 406 258 279 minecraft:red_terracotta
setblock 407 256 277 minecraft:stripped_oak_log
fill 407 256 278 407 259 278 minecraft:red_terracotta
setblock 408 256 276 minecraft:stripped_oak_log
fill 408 256 277 408 259 277 minecraft:red_terracotta
setblock 408 256 316 minecraft:stripped_oak_log
fill 409 256 276 409 259 276 minecraft:red_terracotta
setblock 409 256 315 minecraft:stripped_oak_log
fill 409 256 316 409 259 316 minecraft:red_terracotta
setblock 410 256 315 minecraft:red_terracotta
setblock 411 256 278 minecraft:stripped_oak_log
setblock 412 256 277 minecraft:stripped_oak_log
setblock 413 256 276 minecraft:stripped_oak_log
fill 413 256 277 413 258 277 minecraft:red_terracotta
setblock 413 256 316 minecraft:stripped_oak_log
fill 414 256 276 414 259 276 minecraft:red_terracotta
fill 414 256 316 414 259 316 minecraft:red_terracotta
setblock 416 256 278 minecraft:stripped_oak_log
setblock 417 256 277 minecraft:stripped_oak_log
fill 417 256 278 418 259 278 minecraft:red_terracotta
fill 417 256 298 418 256 299 minecraft:red_terracotta
setblock 417 256 312 minecraft:stripped_oak_log
fill 417 256 313 418 257 313 minecraft:red_terracotta
fill 418 256 276 418 259 277 minecraft:red_terracotta
fill 418 256 279 418 259 297 minecraft:red_terracotta
fill 418 256 300 418 259 312 minecraft:red_terracotta
fill 418 256 314 418 259 316 minecraft:red_terracotta
fill 377 257 275 377 259 275 minecraft:red_terracotta
setblock 377 257 276 minecraft:stripped_oak_log
fill 377 257 277 377 260 277 minecraft:red_terracotta
setblock 377 257 296 minecraft:stripped_oak_log
fill 377 257 297 377 260 297 minecraft:red_terracotta
setblock 377 257 300 minecraft:red_terracotta
setblock 377 257 301 minecraft:stripped_oak_log
fill 377 257 302 377 260 302 minecraft:red_terracotta
fill 377 257 304 377 257 305 minecraft:red_terracotta
setblock 377 257 306 minecraft:stripped_oak_log
fill 377 257 307 377 260 307 minecraft:red_terracotta
setblock 377 257 311 minecraft:stripped_oak_log
setblock 377 257 312 minecraft:red_terracotta
setblock 377 257 316 minecraft:stripped_oak_log
fill 378 257 276 381 257 276 minecraft:red_terracotta
fill 378 257 296 378 258 296 minecraft:red_terracotta
setblock 378 257 300 minecraft:stripped_oak_log
fill 378 257 301 379 259 301 minecraft:red_terracotta
setblock 378 257 304 minecraft:red_terracotta
setblock 378 257 315 minecraft:stripped_oak_log
fill 378 257 316 378 260 316 minecraft:red_terracotta
setblock 379 257 278 minecraft:light[level=12]
setblock 379 257 285 minecraft:light[level=12]
setblock 379 257 292 minecraft:light[level=12]
setblock 379 257 298 minecraft:red_terracotta
setblock 379 257 299 minecraft:stripped_oak_log
fill 379 257 300 379 260 300 minecraft:red_terracotta
setblock 379 257 306 minecraft:light[level=12]
setblock 379 257 313 minecraft:light[level=12]
setblock 379 257 315 minecraft:red_terracotta
setblock 380 257 277 minecraft:red_terracotta
setblock 381 257 277 minecraft:stripped_oak_log
setblock 382 257 276 minecraft:stripped_oak_log
fill 382 257 277 382 260 277 minecraft:red_terracotta
setblock 382 257 316 minecraft:stripped_oak_log
fill 383 257 276 383 260 276 minecraft:red_terracotta
setblock 383 257 315 minecraft:stripped_oak_log
fill 383 257 316 383 260 316 minecraft:red_terracotta
fill 384 257 315 384 258 315 minecraft:red_terracotta
setblock 386 257 277 minecraft:stripped_oak_log
setblock 386 257 278 minecraft:light[level=12]
setblock 386 257 285 minecraft:light[level=12]
setblock 386 257 292 minecraft:light[level=12]
setblock 386 257 299 minecraft:light[level=12]
setblock 386 257 306 minecraft:light[level=12]
setblock 386 257 313 minecraft:light[level=12]
setblock 387 257 276 minecraft:stripped_oak_log
setblock 387 257 277 minecraft:red_terracotta
setblock 387 257 316 minecraft:stripped_oak_log
fill 388 257 276 391 257 276 minecraft:red_terracotta
setblock 388 257 316 minecraft:red_terracotta
setblock 393 257 278 minecraft:light[level=12]
setblock 393 257 285 minecraft:light[level=12]
setblock 393 257 292 minecraft:light[level=12]
setblock 393 257 299 minecraft:light[level=12]
setblock 393 257 306 minecraft:light[level=12]
setblock 393 257 313 minecraft:light[level=12]
fill 395 257 276 396 257 276 minecraft:red_terracotta
setblock 397 257 276 minecraft:stripped_oak_log
fill 398 257 276 398 260 276 minecraft:red_terracotta
setblock 400 257 278 minecraft:stripped_oak_log
setblock 400 257 285 minecraft:light[level=12]
setblock 400 257 292 minecraft:light[level=12]
setblock 400 257 299 minecraft:light[level=12]
setblock 400 257 306 minecraft:light[level=12]
setblock 400 257 313 minecraft:light[level=12]
setblock 401 257 277 minecraft:stripped_oak_log
fill 401 257 278 404 257 278 minecraft:red_terracotta
setblock 402 257 276 minecraft:stripped_oak_log
fill 402 257 277 402 260 277 minecraft:red_terracotta
fill 402 257 279 403 257 279 minecraft:red_terracotta
setblock 402 257 316 minecraft:stripped_oak_log
fill 403 257 276 403 260 276 minecraft:red_terracotta
setblock 403 257 315 minecraft:stripped_oak_log
fill 403 257 316 403 260 316 minecraft:red_terracotta
setblock 404 257 279 minecraft:stripped_oak_log
setblock 404 257 315 minecraft:red_terracotta
setblock 405 257 278 minecraft:stripped_oak_log
fill 405 257 279 405 260 279 minecraft:red_terracotta
setblock 406 257 277 minecraft:stripped_oak_log
fill 406 257 278 406 260 278 minecraft:red_terracotta
setblock 407 257 276 minecraft:stripped_oak_log
fill 407 257 277 407 260 277 minecraft:red_terracotta
setblock 407 257 285 minecraft:light[level=12]
setblock 407 257 292 minecraft:light[level=12]
setblock 407 257 299 minecraft:light[level=12]
setblock 407 257 306 minecraft:light[level=12]
setblock 407 257 313 minecraft:light[level=12]
setblock 407 257 316 minecraft:stripped_oak_log
fill 408 257 276 408 260 276 minecraft:red_terracotta
setblock 408 257 315 minecraft:stripped_oak_log
fill 408 257 316 408 260 316 minecraft:red_terracotta
setblock 409 257 315 minecraft:red_terracotta
setblock 410 257 278 minecraft:stripped_oak_log
setblock 411 257 277 minecraft:stripped_oak_log
setblock 412 257 276 minecraft:stripped_oak_log
fill 412 257 277 412 259 277 minecraft:red_terracotta
setblock 412 257 316 minecraft:stripped_oak_log
fill 413 257 276 413 260 276 minecraft:red_terracotta
fill 413 257 316 413 259 316 minecraft:red_terracotta
setblock 414 257 278 minecraft:light[level=12]
setblock 414 257 285 minecraft:light[level=12]
setblock 414 257 292 minecraft:light[level=12]
setblock 414 257 299 minecraft:light[level=12]
setblock 414 257 306 minecraft:light[level=12]
setblock 414 257 313 minecraft:light[level=12]
setblock 416 257 277 minecraft:stripped_oak_log
setblock 416 257 278 minecraft:red_terracotta
setblock 417 257 276 minecraft:stripped_oak_log
fill 417 257 277 417 260 277 minecraft:red_terracotta
setblock 417 257 281 minecraft:stripped_oak_log
fill 417 257 299 417 257 300 minecraft:red_terracotta
setblock 417 257 316 minecraft:stripped_oak_log
fill 418 257 298 418 259 299 minecraft:red_terracotta
fill 377 258 276 380 258 276 minecraft:red_terracotta
setblock 377 258 295 minecraft:stripped_oak_log
fill 377 258 296 377 261 296 minecraft:red_terracotta
setblock 377 258 300 minecraft:stripped_oak_log
fill 377 258 301 377 261 301 minecraft:red_terracotta
setblock 377 258 304 minecraft:red_terracotta
setblock 377 258 305 minecraft:stripped_oak_log
fill 377 258 306 377 261 306 minecraft:red_terracotta
setblock 377 258 315 minecraft:stripped_oak_log
fill 377 258 316 377 261 316 minecraft:red_terracotta
setblock 378 258 299 minecraft:stripped_oak_log
fill 378 258 300 378 261 300 minecraft:red_terracotta
setblock 378 258 304 minecraft:stripped_oak_log
fill 378 258 305 378 261 305 minecraft:red_terracotta
setblock 379 258 298 minecraft:stripped_oak_log
fill 379 258 299 379 261 299 minecraft:red_terracotta
setblock 379 258 302 minecraft:red_terracotta
setblock 381 258 276 minecraft:stripped_oak_log
fill 381 258 277 381 259 277 minecraft:red_terracotta
setblock 381 258 316 minecraft:stripped_oak_log
fill 382 258 276 382 261 276 minecraft:red_terracotta
setblock 382 258 315 minecraft:stripped_oak_log
fill 382 258 316 382 261 316 minecraft:red_terracotta
setblock 383 258 315 minecraft:red_terracotta
setblock 385 258 277 minecraft:stripped_oak_log
setblock 386 258 276 minecraft:stripped_oak_log
setblock 386 258 277 minecraft:red_terracotta
setblock 386 258 316 minecraft:stripped_oak_log
fill 387 258 276 389 258 276 minecraft:red_terracotta
setblock 387 258 316 minecraft:red_terracotta
setblock 395 258 276 minecraft:red_terracotta
setblock 396 258 276 minecraft:stripped_oak_log
fill 397 258 276 397 261 276 minecraft:red_terracotta
setblock 399 258 278 minecraft:stripped_oak_log
setblock 400 258 277 minecraft:stripped_oak_log
fill 400 258 278 403 258 278 minecraft:red_terracotta
setblock 401 258 276 minecraft:stripped_oak_log
fill 401 258 277 401 261 277 minecraft:red_terracotta
setblock 401 258 316 minecraft:stripped_oak_log
fill 402 258 276 402 261 276 minecraft:red_terracotta
setblock 402 258 279 minecraft:red_terracotta
fill 402 258 316 402 261 316 minecraft:red_terracotta
setblock 403 258 279 minecraft:stripped_oak_log
setblock 404 258 278 minecraft:stripped_oak_log
fill 404 258 279 404 261 279 minecraft:red_terracotta
setblock 405 258 277 minecraft:stripped_oak_log
fill 405 258 278 405 261 278 minecraft:red_terracotta
setblock 406 258 276 minecraft:stripped_oak_log
fill 406 258 277 406 261 277 minecraft:red_terracotta
setblock 406 258 316 minecraft:stripped_oak_log
fill 407 258 276 407 261 276 minecraft:red_terracotta
fill 407 258 316 407 261 316 minecraft:red_terracotta
setblock 409 258 278 minecraft:stripped_oak_log
setblock 410 258 277 minecraft:stripped_oak_log
setblock 411 258 276 minecraft:stripped_oak_log
fill 411 258 277 411 260 277 minecraft:red_terracotta
setblock 411 258 316 minecraft:stripped_oak_log
fill 412 258 276 412 261 276 minecraft:red_terracotta
fill 412 258 316 412 259 316 minecraft:red_terracotta
setblock 415 258 277 minecraft:stripped_oak_log
setblock 416 258 276 minecraft:stripped_oak_log
setblock 416 258 277 minecraft:red_terracotta
setblock 416 258 316 minecraft:stripped_oak_log
fill 417 258 276 417 261 276 minecraft:red_terracotta
setblock 417 258 280 minecraft:stripped_oak_log
fill 417 258 281 417 261 281 minecraft:red_terracotta
setblock 417 258 299 minecraft:red_terracotta
setblock 417 258 300 minecraft:stripped_oak_log
fill 417 258 301 417 260 302 minecraft:red_terracotta
setblock 417 258 315 minecraft:stripped_oak_log
fill 417 258 316 417 261 316 minecraft:red_terracotta
fill 418 258 313 418 259 313 minecraft:red_terracotta
fill 377 259 276 379 259 276 minecraft:red_terracotta
setblock 377 259 295 minecraft:red_terracotta
setblock 377 259 299 minecraft:stripped_oak_log
fill 377 259 300 377 262 300 minecraft:red_terracotta
setblock 377 259 303 minecraft:red_terracotta
setblock 377 259 304 minecraft:stripped_oak_log
fill 377 259 305 377 262 305 minecraft:red_terracotta
setblock 377 259 308 minecraft:red_terracotta
setblock 377 259 315 minecraft:red_terracotta
setblock 378 259 298 minecraft:stripped_oak_log
fill 378 259 299 378 262 299 minecraft:red_terracotta
setblock 378 259 303 minecraft:stripped_oak_log
fill 378 259 304 378 262 304 minecraft:red_terracotta
fill 379 259 298 379 262 298 minecraft:red_terracotta
setblock 379 259 302 minecraft:stripped_oak_log
fill 379 259 303 379 262 303 minecraft:red_terracotta
setblock 380 259 276 minecraft:stripped_oak_log
setblock 380 259 316 minecraft:stripped_oak_log
fill 381 259 276 381 262 276 minecraft:red_terracotta
fill 381 259 316 381 262 316 minecraft:red_terracotta
setblock 384 259 277 minecraft:stripped_oak_log
setblock 385 259 276 minecraft:stripped_oak_log
setblock 385 259 316 minecraft:stripped_oak_log
fill 386 259 276 388 259 276 minecraft:red_terracotta
setblock 386 259 316 minecraft:red_terracotta
fill 396 259 276 396 262 276 minecraft:red_terracotta
fill 397 259 277 397 260 277 minecraft:red_terracotta
setblock 399 259 277 minecraft:stripped_oak_log
fill 399 259 278 402 259 278 minecraft:red_terracotta
setblock 400 259 276 minecraft:stripped_oak_log
fill 400 259 277 400 262 277 minecraft:red_terracotta
setblock 400 259 316 minecraft:stripped_oak_log
fill 401 259 276 401 262 276 minecraft:red_terracotta
fill 401 259 316 401 262 316 minecraft:red_terracotta
setblock 402 259 279 minecraft:stripped_oak_log
setblock 403 259 278 minecraft:stripped_oak_log
fill 403 259 279 403 262 279 minecraft:red_terracotta
setblock 404 259 277 minecraft:stripped_oak_log
fill 404 259 278 404 262 278 minecraft:red_terracotta
setblock 405 259 276 minecraft:stripped_oak_log
fill 405 259 277 405 262 277 minecraft:red_terracotta
setblock 405 259 316 minecraft:stripped_oak_log
fill 406 259 276 406 262 276 minecraft:red_terracotta
fill 406 259 316 406 262 316 minecraft:red_terracotta
setblock 408 259 278 minecraft:stripped_oak_log
setblock 409 259 277 minecraft:stripped_oak_log
setblock 409 259 278 minecraft:red_terracotta
setblock 410 259 276 minecraft:stripped_oak_log
fill 410 259 277 410 261 277 minecraft:red_terracotta
setblock 410 259 316 minecraft:stripped_oak_log
fill 411 259 276 411 262 276 minecraft:red_terracotta
setblock 411 259 316 minecraft:red_terracotta
setblock 415 259 276 minecraft:stripped_oak_log
setblock 415 259 316 minecraft:stripped_oak_log
fill 416 259 276 416 262 276 minecraft:red_terracotta
fill 416 259 316 416 262 316 minecraft:red_terracotta
setblock 417 259 279 minecraft:stripped_oak_log
fill 417 259 280 417 262 280 minecraft:red_terracotta
setblock 417 259 299 minecraft:stripped_oak_log
fill 417 259 300 417 262 300 minecraft:red_terracotta
setblock 417 259 303 minecraft:red_terracotta
setblock 417 259 304 minecraft:stripped_oak_log
setblock 417 259 314 minecraft:stripped_oak_log
fill 417 259 315 417 262 315 minecraft:red_terracotta
fill 376 260 275 376 263 317 minecraft:yellow_terracotta
fill 377 260 275 418 263 275 minecraft:yellow_terracotta
setblock 377 260 278 minecraft:stripped_oak_log
fill 377 260 279 377 263 279 minecraft:red_terracotta
setblock 377 260 298 minecraft:stripped_oak_log
fill 377 260 299 377 263 299 minecraft:red_terracotta
setblock 377 260 303 minecraft:stripped_oak_log
fill 377 260 304 377 263 304 minecraft:red_terracotta
setblock 377 260 308 minecraft:stripped_oak_log
fill 377 260 309 377 263 309 minecraft:red_terracotta
fill 377 260 317 418 263 317 minecraft:yellow_terracotta
setblock 378 260 276 minecraft:red_terracotta
setblock 378 260 297 minecraft:stripped_oak_log
fill 378 260 298 378 263 298 minecraft:red_terracotta
setblock 378 260 301 minecraft:red_terracotta
setblock 378 260 302 minecraft:stripped_oak_log
fill 378 260 303 378 263 303 minecraft:red_terracotta
setblock 378 260 306 minecraft:red_terracotta
setblock 378 260 307 minecraft:stripped_oak_log
setblock 379 260 276 minecraft:stripped_oak_log
setblock 379 260 301 minecraft:stripped_oak_log
fill 379 260 302 379 263 302 minecraft:red_terracotta
fill 379 260 304 379 261 304 minecraft:red_terracotta
setblock 379 260 316 minecraft:stripped_oak_log
fill 380 260 276 380 263 276 minecraft:red_terracotta
fill 380 260 316 380 263 316 minecraft:red_terracotta
setblock 384 260 276 minecraft:stripped_oak_log
setblock 384 260 316 minecraft:stripped_oak_log
fill 385 260 276 386 260 276 minecraft:red_terracotta
setblock 398 260 277 minecraft:stripped_oak_log
setblock 399 260 276 minecraft:stripped_oak_log
fill 399 260 277 399 262 278 minecraft:red_terracotta
fill 400 260 276 400 263 276 minecraft:red_terracotta
fill 400 260 278 401 260 278 minecraft:red_terracotta
fill 400 260 316 400 263 316 minecraft:red_terracotta
setblock 401 260 279 minecraft:stripped_oak_log
setblock 402 260 278 minecraft:stripped_oak_log
fill 402 260 279 402 263 279 minecraft:red_terracotta
setblock 403 260 277 minecraft:stripped_oak_log
fill 403 260 278 403 263 278 minecraft:red_terracotta
setblock 404 260 276 minecraft:stripped_oak_log
fill 404 260 277 404 263 277 minecraft:red_terracotta
setblock 404 260 316 minecraft:stripped_oak_log
fill 405 260 276 405 263 276 minecraft:red_terracotta
fill 405 260 316 405 263 316 minecraft:red_terracotta
setblock 407 260 278 minecraft:stripped_oak_log
setblock 408 260 277 minecraft:stripped_oak_log
setblock 408 260 278 minecraft:red_terracotta
setblock 409 260 276 minecraft:stripped_oak_log
fill 409 260 277 409 262 277 minecraft:red_terracotta
setblock 409 260 316 minecraft:stripped_oak_log
fill 410 260 276 410 263 276 minecraft:red_terracotta
setblock 414 260 276 minecraft:stripped_oak_log
fill 415 260 276 415 263 276 minecraft:red_terracotta
fill 415 260 316 415 263 316 minecraft:red_terracotta
setblock 417 260 278 minecraft:stripped_oak_log
fill 417 260 279 417 263 279 minecraft:red_terracotta
fill 417 260 299 417 263 299 minecraft:red_terracotta
setblock 417 260 303 minecraft:stripped_oak_log
fill 417 260 304 417 261 306 minecraft:red_terracotta
fill 417 260 314 417 263 314 minecraft:red_terracotta
fill 418 260 276 418 263 316 minecraft:yellow_terracotta
setblock 377 261 277 minecraft:stripped_oak_log
fill 377 261 278 377 264 278 minecraft:red_terracotta
fill 377 261 280 377 261 281 minecraft:red_terracotta
fill 377 261 295 377 262 295 minecraft:red_terracotta
setblock 377 261 297 minecraft:stripped_oak_log
fill 377 261 298 377 264 298 minecraft:red_terracotta
setblock 377 261 302 minecraft:stripped_oak_log
fill 377 261 303 377 264 303 minecraft:red_terracotta
setblock 377 261 307 minecraft:stripped_oak_log
fill 377 261 308 378 263 308 minecraft:red_terracotta
fill 377 261 310 377 262 310 minecraft:red_terracotta
setblock 378 261 276 minecraft:stripped_oak_log
fill 378 261 297 378 264 297 minecraft:red_terracotta
setblock 378 261 301 minecraft:stripped_oak_log
fill 378 261 302 378 264 302 minecraft:red_terracotta
setblock 378 261 306 minecraft:stripped_oak_log
fill 378 261 307 378 264 307 minecraft:red_terracotta
setblock 378 261 316 minecraft:stripped_oak_log
fill 379 261 276 379 264 276 minecraft:red_terracotta
setblock 379 261 300 minecraft:stripped_oak_log
fill 379 261 301 380 263 301 minecraft:red_terracotta
setblock 379 261 305 minecraft:stripped_oak_log
fill 379 261 306 379 264 306 minecraft:red_terracotta
fill 379 261 316 379 264 316 minecraft:red_terracotta
fill 380 261 300 380 264 300 minecraft:red_terracotta
fill 380 261 302 380 261 303 minecraft:red_terracotta
setblock 383 261 276 minecraft:stripped_oak_log
setblock 383 261 316 minecraft:stripped_oak_log
fill 384 261 276 385 261 276 minecraft:red_terracotta
fill 395 261 276 395 263 276 minecraft:red_terracotta
setblock 397 261 277 minecraft:stripped_oak_log
setblock 398 261 276 minecraft:stripped_oak_log
fill 398 261 277 398 263 278 minecraft:red_terracotta
fill 399 261 276 399 264 276 minecraft:red_terracotta
setblock 400 261 278 minecraft:red_terracotta
setblock 401 261 278 minecraft:stripped_oak_log
fill 401 261 279 401 264 279 minecraft:red_terracotta
setblock 402 261 277 minecraft:stripped_oak_log
fill 402 261 278 402 264 278 minecraft:red_terracotta
setblock 403 261 276 minecraft:stripped_oak_log
fill 403 261 277 403 264 277 minecraft:red_terracotta
setblock 403 261 316 minecraft:stripped_oak_log
fill 404 261 276 404 264 276 minecraft:red_terracotta
fill 404 261 316 404 264 316 minecraft:red_terracotta
setblock 406 261 278 minecraft:stripped_oak_log
setblock 407 261 277 minecraft:stripped_oak_log
setblock 407 261 278 minecraft:red_terracotta
setblock 408 261 276 minecraft:stripped_oak_log
fill 408 261 277 408 264 277 minecraft:red_terracotta
fill 409 261 276 409 264 276 minecraft:red_terracotta
fill 409 261 292 417 262 292 minecraft:stripped_oak_log
setblock 413 261 276 minecraft:stripped_oak_log
fill 414 261 276 414 264 276 minecraft:red_terracotta
setblock 417 261 277 minecraft:stripped_oak_log
fill 417 261 278 417 264 278 minecraft:red_terracotta
setblock 417 261 282 minecraft:stripped_oak_log
fill 417 261 298 417 264 298 minecraft:red_terracotta
setblock 417 261 301 minecraft:red_terracotta
setblock 417 261 302 minecraft:stripped_oak_log
fill 417 261 303 417 264 303 minecraft:red_terracotta
setblock 417 261 307 minecraft:stripped_oak_log
fill 417 261 308 417 263 309 minecraft:red_terracotta
fill 417 261 313 417 264 313 minecraft:red_terracotta
fill 377 262 277 377 265 277 minecraft:red_terracotta
setblock 377 262 280 minecraft:red_terracotta
setblock 377 262 281 minecraft:stripped_oak_log
fill 377 262 282 377 264 283 minecraft:red_terracotta
setblock 377 262 296 minecraft:stripped_oak_log
fill 377 262 297 377 265 297 minecraft:red_terracotta
setblock 377 262 301 minecraft:stripped_oak_log
fill 377 262 302 377 265 302 minecraft:red_terracotta
setblock 377 262 306 minecraft:stripped_oak_log
fill 377 262 307 377 265 307 minecraft:red_terracotta
setblock 377 262 311 minecraft:stripped_oak_log
fill 377 262 312 377 265 312 minecraft:red_terracotta
setblock 377 262 316 minecraft:stripped_oak_log
fill 378 262 276 378 265 276 minecraft:red_terracotta
fill 378 262 296 378 265 296 minecraft:red_terracotta
setblock 378 262 300 minecraft:stripped_oak_log
fill 378 262 301 378 265 301 minecraft:red_terracotta
setblock 378 262 305 minecraft:stripped_oak_log
fill 378 262 306 378 265 306 minecraft:red_terracotta
setblock 378 262 309 minecraft:red_terracotta
fill 378 262 316 378 265 316 minecraft:red_terracotta
setblock 379 262 299 minecraft:stripped_oak_log
fill 379 262 300 379 265 300 minecraft:red_terracotta
setblock 379 262 304 minecraft:stripped_oak_log
fill 379 262 305 379 265 305 minecraft:red_terracotta
fill 379 262 307 379 263 307 minecraft:red_terracotta
setblock 380 262 302 minecraft:red_terracotta
setblock 380 262 303 minecraft:stripped_oak_log
fill 380 262 304 380 265 304 minecraft:red_terracotta
setblock 382 262 276 minecraft:stripped_oak_log
setblock 382 262 316 minecraft:stripped_oak_log
fill 383 262 276 384 263 276 minecraft:red_terracotta
fill 389 262 290 395 263 290 minecraft:stripped_oak_log
fill 390 262 291 414 262 291 minecraft:stripped_oak_log
setblock 396 262 277 minecraft:stripped_oak_log
setblock 397 262 276 minecraft:stripped_oak_log
fill 397 262 277 397 265 277 minecraft:red_terracotta
fill 398 262 276 398 265 276 minecraft:red_terracotta
setblock 400 262 278 minecraft:stripped_oak_log
fill 400 262 279 400 265 279 minecraft:red_terracotta
fill 400 262 292 408 262 292 minecraft:stripped_oak_log
setblock 401 262 277 minecraft:stripped_oak_log
fill 401 262 278 401 265 278 minecraft:red_terracotta
setblock 402 262 276 minecraft:stripped_oak_log
fill 402 262 277 402 265 277 minecraft:red_terracotta
setblock 402 262 316 minecraft:stripped_oak_log
fill 403 262 276 403 265 276 minecraft:red_terracotta
fill 403 262 316 403 265 316 minecraft:red_terracotta
setblock 404 262 279 minecraft:stripped_oak_log
setblock 405 262 278 minecraft:stripped_oak_log
setblock 406 262 277 minecraft:stripped_oak_log
fill 406 262 278 406 264 278 minecraft:red_terracotta
setblock 407 262 276 minecraft:stripped_oak_log
fill 407 262 277 407 265 277 minecraft:red_terracotta
setblock 407 262 316 minecraft:stripped_oak_log
fill 408 262 276 408 265 276 minecraft:red_terracotta
setblock 412 262 276 minecraft:stripped_oak_log
fill 413 262 276 413 265 276 minecraft:red_terracotta
fill 416 262 303 416 264 304 minecraft:red_terracotta
setblock 417 262 276 minecraft:stripped_oak_log
fill 417 262 277 417 265 277 minecraft:red_terracotta
setblock 417 262 281 minecraft:stripped_oak_log
fill 417 262 282 417 264 283 minecraft:red_terracotta
setblock 417 262 301 minecraft:stripped_oak_log
fill 417 262 302 417 265 302 minecraft:red_terracotta
fill 417 262 304 417 262 305 minecraft:red_terracotta
setblock 417 262 306 minecraft:stripped_oak_log
fill 417 262 307 417 265 307 minecraft:red_terracotta
setblock 417 262 310 minecraft:red_terracotta
setblock 417 262 311 minecraft:stripped_oak_log
fill 417 262 312 417 265 312 minecraft:red_terracotta
setblock 417 262 316 minecraft:stripped_oak_log
fill 377 263 276 377 266 276 minecraft:red_terracotta
setblock 377 263 280 minecraft:stripped_oak_log
fill 377 263 281 378 265 281 minecraft:red_terracotta
setblock 377 263 284 minecraft:red_terracotta
setblock 377 263 285 minecraft:stripped_oak_log
fill 377 263 286 377 266 286 minecraft:red_terracotta
fill 377 263 289 380 263 290 minecraft:stripped_oak_log
setblock 377 263 294 minecraft:red_terracotta
setblock 377 263 295 minecraft:stripped_oak_log
fill 377 263 296 377 266 296 minecraft:red_terracotta
setblock 377 263 300 minecraft:stripped_oak_log
fill 377 263 301 377 266 301 minecraft:red_terracotta
setblock 377 263 305 minecraft:stripped_oak_log
fill 377 263 306 377 266 306 minecraft:red_terracotta
setblock 377 263 310 minecraft:stripped_oak_log
fill 377 263 311 377 266 311 minecraft:red_terracotta
fill 377 263 313 377 263 314 minecraft:red_terracotta
setblock 377 263 315 minecraft:stripped_oak_log
fill 377 263 316 377 266 316 minecraft:red_terracotta
fill 378 263 280 378 266 280 minecraft:red_terracotta
fill 378 263 282 378 263 283 minecraft:red_terracotta
setblock 378 263 299 minecraft:stripped_oak_log
fill 378 263 300 378 266 300 minecraft:red_terracotta
setblock 378 263 304 minecraft:stripped_oak_log
fill 378 263 305 378 266 305 minecraft:red_terracotta
setblock 378 263 309 minecraft:stripped_oak_log
fill 378 263 310 378 266 310 minecraft:red_terracotta
setblock 379 263 278 minecraft:light[level=15]
setblock 379 263 285 minecraft:light[level=12]
setblock 379 263 286 minecraft:light[level=15]
setblock 379 263 292 minecraft:light[level=12]
setblock 379 263 294 minecraft:light[level=15]
setblock 379 263 297 minecraft:red_terracotta
setblock 379 263 298 minecraft:stripped_oak_log
fill 379 263 299 380 265 299 minecraft:red_terracotta
setblock 379 263 303 minecraft:stripped_oak_log
fill 379 263 304 379 266 304 minecraft:red_terracotta
setblock 379 263 308 minecraft:stripped_oak_log
setblock 379 263 310 minecraft:light[level=15]
setblock 379 263 313 minecraft:light[level=12]
setblock 380 263 302 minecraft:stripped_oak_log
fill 380 263 303 380 266 303 minecraft:red_terracotta
fill 380 263 305 380 264 305 minecraft:red_terracotta
setblock 381 263 276 minecraft:stripped_oak_log
fill 381 263 290 388 263 290 minecraft:stripped_oak_log
setblock 381 263 316 minecraft:stripped_oak_log
fill 382 263 276 382 266 276 minecraft:red_terracotta
fill 382 263 291 405 263 291 minecraft:stripped_oak_log
setblock 382 263 316 minecraft:red_terracotta
setblock 386 263 278 minecraft:light[level=12]
setblock 386 263 285 minecraft:light[level=12]
setblock 386 263 292 minecraft:light[level=12]
setblock 386 263 299 minecraft:light[level=12]
setblock 386 263 306 minecraft:light[level=12]
setblock 386 263 313 minecraft:light[level=12]
setblock 387 263 278 minecraft:light[level=15]
setblock 387 263 286 minecraft:light[level=15]
setblock 387 263 294 minecraft:light[level=15]
setblock 387 263 302 minecraft:light[level=15]
setblock 387 263 310 minecraft:light[level=15]
setblock 393 263 278 minecraft:light[level=12]
setblock 393 263 285 minecraft:light[level=12]
setblock 393 263 292 minecraft:light[level=12]
setblock 393 263 299 minecraft:light[level=12]
setblock 393 263 306 minecraft:light[level=12]
setblock 393 263 313 minecraft:light[level=12]
setblock 395 263 278 minecraft:light[level=15]
setblock 395 263 286 minecraft:light[level=15]
setblock 395 263 294 minecraft:light[level=15]
setblock 395 263 302 minecraft:light[level=15]
setblock 395 263 310 minecraft:light[level=15]
setblock 396 263 276 minecraft:stripped_oak_log
fill 396 263 277 396 266 277 minecraft:red_terracotta
setblock 396 263 290 minecraft:stripped_oak_log
fill 397 263 276 397 266 276 minecraft:red_terracotta
fill 397 263 278 397 264 278 minecraft:red_terracotta
setblock 399 263 277 minecraft:red_terracotta
setblock 399 263 278 minecraft:stripped_oak_log
fill 399 263 279 399 266 279 minecraft:red_terracotta
fill 399 263 316 399 264 316 minecraft:red_terracotta
setblock 400 263 277 minecraft:stripped_oak_log
fill 400 263 278 400 266 278 minecraft:red_terracotta
setblock 400 263 285 minecraft:light[level=12]
setblock 400 263 292 minecraft:light[level=12]
setblock 400 263 299 minecraft:light[level=12]
setblock 400 263 306 minecraft:light[level=12]
setblock 400 263 313 minecraft:light[level=12]
setblock 401 263 276 minecraft:stripped_oak_log
fill 401 263 277 401 266 277 minecraft:red_terracotta
setblock 401 263 316 minecraft:stripped_oak_log
fill 402 263 276 402 266 276 minecraft:red_terracotta
fill 402 263 316 402 266 316 minecraft:red_terracotta
setblock 403 263 279 minecraft:stripped_oak_log
setblock 403 263 286 minecraft:light[level=15]
setblock 403 263 294 minecraft:light[level=15]
setblock 403 263 302 minecraft:light[level=15]
setblock 403 263 310 minecraft:light[level=15]
setblock 404 263 278 minecraft:stripped_oak_log
setblock 404 263 279 minecraft:red_terracotta
setblock 405 263 277 minecraft:stripped_oak_log
fill 405 263 278 405 265 278 minecraft:red_terracotta
setblock 406 263 276 minecraft:stripped_oak_log
fill 406 263 277 406 266 277 minecraft:red_terracotta
setblock 406 263 316 minecraft:stripped_oak_log
fill 407 263 276 407 266 276 minecraft:red_terracotta
setblock 407 263 278 minecraft:light[level=12]
setblock 407 263 285 minecraft:light[level=12]
setblock 407 263 292 minecraft:light[level=12]
setblock 407 263 299 minecraft:light[level=12]
setblock 407 263 306 minecraft:light[level=12]
setblock 407 263 313 minecraft:light[level=12]
fill 408 263 292 417 263 292 minecraft:orange_terracotta
setblock 411 263 276 minecraft:stripped_oak_log
setblock 411 263 278 minecraft:light[level=15]
setblock 411 263 286 minecraft:light[level=15]
setblock 411 263 294 minecraft:light[level=15]
setblock 411 263 302 minecraft:light[level=15]
setblock 411 263 310 minecraft:light[level=15]
fill 412 263 276 412 266 276 minecraft:red_terracotta
setblock 414 263 278 minecraft:light[level=12]
setblock 414 263 285 minecraft:light[level=12]
setblock 414 263 299 minecraft:light[level=12]
setblock 414 263 306 minecraft:light[level=12]
setblock 414 263 313 minecraft:light[level=12]
setblock 416 263 276 minecraft:stripped_oak_log
fill 416 263 278 416 263 280 minecraft:red_terracotta
setblock 416 263 301 minecraft:stripped_oak_log
fill 416 263 302 416 266 302 minecraft:red_terracotta
setblock 416 263 305 minecraft:red_terracotta
setblock 416 263 306 minecraft:stripped_oak_log
fill 416 263 307 416 265 308 minecraft:red_terracotta
setblock 416 263 316 minecraft:stripped_oak_log
fill 417 263 276 417 266 276 minecraft:red_terracotta
setblock 417 263 280 minecraft:stripped_oak_log
fill 417 263 281 417 266 281 minecraft:red_terracotta
setblock 417 263 284 minecraft:red_terracotta
setblock 417 263 285 minecraft:stripped_oak_log
fill 417 263 297 417 265 297 minecraft:red_terracotta
setblock 417 263 300 minecraft:stripped_oak_log
fill 417 263 301 417 266 301 minecraft:red_terracotta
setblock 417 263 304 minecraft:red_terracotta
setblock 417 263 305 minecraft:stripped_oak_log
fill 417 263 306 417 266 306 minecraft:red_terracotta
setblock 417 263 310 minecraft:stripped_oak_log
fill 417 263 311 417 266 311 minecraft:red_terracotta
setblock 417 263 315 minecraft:stripped_oak_log
fill 417 263 316 417 266 316 minecraft:red_terracotta
fill 376 264 275 376 267 317 minecraft:white_terracotta
fill 377 264 275 418 267 275 minecraft:white_terracotta
setblock 377 264 279 minecraft:stripped_oak_log
fill 377 264 280 377 267 280 minecraft:red_terracotta
setblock 377 264 284 minecraft:stripped_oak_log
fill 377 264 285 378 266 285 minecraft:red_terracotta
fill 377 264 287 377 264 288 minecraft:red_terracotta
fill 377 264 289 378 264 289 minecraft:stripped_oak_log
fill 377 264 290 377 264 293 minecraft:red_terracotta
setblock 377 264 294 minecraft:stripped_oak_log
fill 377 264 295 378 266 295 minecraft:red_terracotta
setblock 377 264 299 minecraft:stripped_oak_log
fill 377 264 300 377 267 300 minecraft:red_terracotta
setblock 377 264 304 minecraft:stripped_oak_log
fill 377 264 305 377 267 305 minecraft:red_terracotta
setblock 377 264 308 minecraft:red_terracotta
setblock 377 264 309 minecraft:stripped_oak_log
fill 377 264 310 377 267 310 minecraft:red_terracotta
setblock 377 264 313 minecraft:red_terracotta
setblock 377 264 314 minecraft:stripped_oak_log
fill 377 264 315 377 267 315 minecraft:red_terracotta
fill 377 264 317 418 267 317 minecraft:white_terracotta
fill 378 264 279 378 267 279 minecraft:red_terracotta
setblock 378 264 282 minecraft:red_terracotta
setblock 378 264 283 minecraft:stripped_oak_log
fill 378 264 284 378 267 284 minecraft:red_terracotta
fill 378 264 286 378 265 286 minecraft:red_terracotta
fill 378 264 290 385 264 290 minecraft:stripped_oak_log
setblock 378 264 298 minecraft:stripped_oak_log
fill 378 264 299 378 267 299 minecraft:red_terracotta
setblock 378 264 303 minecraft:stripped_oak_log
fill 378 264 304 378 267 304 minecraft:red_terracotta
setblock 378 264 308 minecraft:stripped_oak_log
fill 378 264 309 379 266 309 minecraft:red_terracotta
fill 378 264 311 378 264 312 minecraft:red_terracotta
setblock 379 264 297 minecraft:stripped_oak_log
fill 379 264 298 379 267 298 minecraft:red_terracotta
setblock 379 264 301 minecraft:red_terracotta
setblock 379 264 302 minecraft:stripped_oak_log
fill 379 264 303 379 267 303 minecraft:red_terracotta
setblock 379 264 307 minecraft:stripped_oak_log
fill 379 264 308 379 267 308 minecraft:red_terracotta
setblock 380 264 276 minecraft:stripped_oak_log
setblock 380 264 301 minecraft:stripped_oak_log
fill 380 264 302 380 267 302 minecraft:red_terracotta
setblock 380 264 306 minecraft:stripped_oak_log
fill 380 264 307 380 267 307 minecraft:red_terracotta
setblock 380 264 316 minecraft:stripped_oak_log
fill 381 264 276 381 267 276 minecraft:red_terracotta
fill 381 264 316 381 267 316 minecraft:red_terracotta
fill 383 264 276 383 265 276 minecraft:red_terracotta
fill 386 264 290 389 264 290 minecraft:orange_terracotta
fill 390 264 291 403 264 291 minecraft:orange_terracotta
setblock 394 264 276 minecraft:red_terracotta
setblock 395 264 276 minecraft:stripped_oak_log
fill 395 264 277 395 267 277 minecraft:red_terracotta
fill 396 264 276 396 267 276 minecraft:red_terracotta
fill 396 264 278 396 265 278 minecraft:red_terracotta
setblock 398 264 277 minecraft:red_terracotta
setblock 398 264 278 minecraft:stripped_oak_log
fill 398 264 279 398 267 279 minecraft:red_terracotta
fill 398 264 316 398 265 316 minecraft:red_terracotta
setblock 399 264 277 minecraft:stripped_oak_log
fill 399 264 278 399 267 278 minecraft:red_terracotta
setblock 400 264 276 minecraft:stripped_oak_log
fill 400 264 277 400 267 277 minecraft:red_terracotta
setblock 400 264 316 minecraft:stripped_oak_log
fill 401 264 276 401 267 276 minecraft:red_terracotta
fill 401 264 316 401 267 316 minecraft:red_terracotta
setblock 402 264 279 minecraft:stripped_oak_log
setblock 403 264 278 minecraft:stripped_oak_log
fill 403 264 279 403 265 279 minecraft:red_terracotta
setblock 404 264 277 minecraft:stripped_oak_log
fill 404 264 278 404 266 278 minecraft:red_terracotta
setblock 405 264 276 minecraft:stripped_oak_log
fill 405 264 277 405 267 277 minecraft:red_terracotta
setblock 405 264 316 minecraft:stripped_oak_log
fill 406 264 276 406 267 276 minecraft:red_terracotta
fill 406 264 316 406 267 316 minecraft:red_terracotta
setblock 410 264 276 minecraft:stripped_oak_log
fill 411 264 276 411 267 276 minecraft:red_terracotta
fill 414 264 281 415 265 281 minecraft:iron_bars
setblock 414 264 316 minecraft:red_terracotta
setblock 415 264 276 minecraft:stripped_oak_log
setblock 415 264 316 minecraft:stripped_oak_log
fill 416 264 276 416 267 276 minecraft:red_terracotta
fill 416 264 278 416 264 279 minecraft:red_terracotta
setblock 416 264 280 minecraft:stripped_oak_log
fill 416 264 281 416 266 282 minecraft:red_terracotta
setblock 416 264 300 minecraft:stripped_oak_log
fill 416 264 301 416 267 301 minecraft:red_terracotta
setblock 416 264 305 minecraft:stripped_oak_log
fill 416 264 306 416 267 306 minecraft:red_terracotta
setblock 416 264 309 minecraft:red_terracotta
setblock 416 264 310 minecraft:stripped_oak_log
fill 416 264 311 416 267 311 minecraft:red_terracotta
fill 416 264 316 416 267 316 minecraft:red_terracotta
setblock 417 264 279 minecraft:stripped_oak_log
fill 417 264 280 417 267 280 minecraft:red_terracotta
setblock 417 264 284 minecraft:stripped_oak_log
fill 417 264 285 417 266 286 minecraft:red_terracotta
setblock 417 264 299 minecraft:stripped_oak_log
fill 417 264 300 417 267 300 minecraft:red_terracotta
setblock 417 264 304 minecraft:stripped_oak_log
fill 417 264 305 417 267 305 minecraft:red_terracotta
setblock 417 264 308 minecraft:red_terracotta
setblock 417 264 309 minecraft:stripped_oak_log
fill 417 264 310 417 267 310 minecraft:red_terracotta
setblock 417 264 314 minecraft:stripped_oak_log
fill 417 264 315 417 267 315 minecraft:red_terracotta
fill 418 264 276 418 267 316 minecraft:white_terracotta
setblock 377 265 278 minecraft:stripped_oak_log
fill 377 265 279 377 268 279 minecraft:red_terracotta
setblock 377 265 282 minecraft:red_terracotta
setblock 377 265 283 minecraft:stripped_oak_log
fill 377 265 284 377 268 284 minecraft:red_terracotta
setblock 377 265 287 minecraft:red_terracotta
setblock 377 265 288 minecraft:stripped_oak_log
fill 377 265 289 377 265 292 minecraft:red_terracotta
setblock 377 265 293 minecraft:stripped_oak_log
fill 377 265 294 378 267 294 minecraft:red_terracotta
setblock 377 265 298 minecraft:stripped_oak_log
fill 377 265 299 377 268 299 minecraft:red_terracotta
setblock 377 265 303 minecraft:stripped_oak_log
fill 377 265 304 377 268 304 minecraft:red_terracotta
setblock 377 265 308 minecraft:stripped_oak_log
fill 377 265 309 377 268 309 minecraft:red_terracotta
setblock 377 265 313 minecraft:stripped_oak_log
fill 377 265 314 377 268 314 minecraft:red_terracotta
fill 378 265 278 378 267 278 minecraft:red_terracotta
setblock 378 265 282 minecraft:stripped_oak_log
fill 378 265 283 379 267 283 minecraft:red_terracotta
setblock 378 265 287 minecraft:stripped_oak_log
fill 378 265 288 378 265 291 minecraft:red_terracotta
setblock 378 265 292 minecraft:stripped_oak_log
fill 378 265 293 378 268 293 minecraft:red_terracotta
setblock 378 265 297 minecraft:stripped_oak_log
fill 378 265 298 378 268 298 minecraft:red_terracotta
setblock 378 265 302 minecraft:stripped_oak_log
fill 378 265 303 378 268 303 minecraft:red_terracotta
setblock 378 265 307 minecraft:stripped_oak_log
fill 378 265 308 378 268 308 minecraft:red_terracotta
setblock 378 265 311 minecraft:red_terracotta
setblock 378 265 312 minecraft:stripped_oak_log
fill 378 265 313 378 268 313 minecraft:red_terracotta
setblock 379 265 276 minecraft:stripped_oak_log
fill 379 265 282 379 268 282 minecraft:red_terracotta
fill 379 265 284 379 265 285 minecraft:red_terracotta
setblock 379 265 286 minecraft:stripped_oak_log
fill 379 265 290 384 265 290 minecraft:orange_terracotta
setblock 379 265 296 minecraft:stripped_oak_log
fill 379 265 297 379 268 297 minecraft:red_terracotta
setblock 379 265 301 minecraft:stripped_oak_log
fill 379 265 302 379 268 302 minecraft:red_terracotta
setblock 379 265 306 minecraft:stripped_oak_log
fill 379 265 307 379 268 307 minecraft:red_terracotta
setblock 379 265 310 minecraft:red_terracotta
setblock 379 265 316 minecraft:stripped_oak_log
fill 380 265 276 380 268 276 minecraft:red_terracotta
setblock 380 265 300 minecraft:stripped_oak_log
fill 380 265 301 380 268 301 minecraft:red_terracotta
setblock 380 265 305 minecraft:stripped_oak_log
fill 380 265 306 380 268 306 minecraft:red_terracotta
fill 380 265 316 380 268 316 minecraft:red_terracotta
setblock 393 265 276 minecraft:red_terracotta
setblock 394 265 276 minecraft:stripped_oak_log
fill 395 265 276 395 268 276 minecraft:red_terracotta
setblock 397 265 278 minecraft:stripped_oak_log
fill 397 265 279 397 268 279 minecraft:red_terracotta
setblock 398 265 277 minecraft:stripped_oak_log
fill 398 265 278 398 268 278 minecraft:red_terracotta
setblock 399 265 276 minecraft:stripped_oak_log
fill 399 265 277 399 268 277 minecraft:red_terracotta
setblock 399 265 316 minecraft:stripped_oak_log
fill 400 265 276 400 268 276 minecraft:red_terracotta
fill 400 265 316 400 268 316 minecraft:red_terracotta
setblock 401 265 279 minecraft:stripped_oak_log
setblock 402 265 278 minecraft:stripped_oak_log
fill 402 265 279 402 266 279 minecraft:red_terracotta
setblock 403 265 277 minecraft:stripped_oak_log
fill 403 265 278 403 267 278 minecraft:red_terracotta
setblock 404 265 276 minecraft:stripped_oak_log
fill 404 265 277 404 268 277 minecraft:red_terracotta
setblock 404 265 316 minecraft:stripped_oak_log
fill 405 265 276 405 268 276 minecraft:red_terracotta
fill 405 265 316 405 268 316 minecraft:red_terracotta
setblock 409 265 276 minecraft:stripped_oak_log
fill 410 265 276 410 267 276 minecraft:red_terracotta
setblock 413 265 316 minecraft:red_terracotta
setblock 414 265 276 minecraft:stripped_oak_log
setblock 414 265 316 minecraft:stripped_oak_log
fill 415 265 276 415 268 276 minecraft:red_terracotta
fill 415 265 303 415 265 304 minecraft:red_terracotta
setblock 415 265 305 minecraft:stripped_oak_log
fill 415 265 306 415 266 308 minecraft:red_terracotta
fill 415 265 316 415 268 316 minecraft:red_terracotta
fill 416 265 277 416 265 278 minecraft:red_terracotta
setblock 416 265 279 minecraft:stripped_oak_log
fill 416 265 280 416 268 280 minecraft:red_terracotta
setblock 416 265 283 minecraft:red_terracotta
setblock 416 265 284 minecraft:stripped_oak_log
setblock 416 265 299 minecraft:stripped_oak_log
fill 416 265 300 416 268 300 minecraft:red_terracotta
setblock 416 265 303 minecraft:red_terracotta
setblock 416 265 304 minecraft:stripped_oak_log
fill 416 265 305 416 268 305 minecraft:red_terracotta
setblock 416 265 309 minecraft:stripped_oak_log
fill 416 265 310 416 268 310 minecraft:red_terracotta
fill 416 265 312 416 265 313 minecraft:red_terracotta
setblock 416 265 314 minecraft:stripped_oak_log
fill 416 265 315 416 268 315 minecraft:red_terracotta
setblock 417 265 278 minecraft:stripped_oak_log
fill 417 265 279 417 268 279 minecraft:red_terracotta
setblock 417 265 282 minecraft:red_terracotta
setblock 417 265 283 minecraft:stripped_oak_log
fill 417 265 284 417 268 284 minecraft:red_terracotta
setblock 417 265 287 minecraft:red_terracotta
setblock 417 265 288 minecraft:stripped_oak_log
fill 417 265 296 417 266 296 minecraft:red_terracotta
setblock 417 265 298 minecraft:stripped_oak_log
fill 417 265 299 417 268 299 minecraft:red_terracotta
setblock 417 265 303 minecraft:stripped_oak_log
fill 417 265 304 417 268 304 minecraft:red_terracotta
setblock 417 265 308 minecraft:stripped_oak_log
fill 417 265 309 417 268 309 minecraft:red_terracotta
setblock 417 265 313 minecraft:stripped_oak_log
fill 417 265 314 417 268 314 minecraft:red_terracotta
setblock 377 266 277 minecraft:stripped_oak_log
fill 377 266 278 377 269 278 minecraft:red_terracotta
setblock 377 266 281 minecraft:red_terracotta
setblock 377 266 282 minecraft:stripped_oak_log
fill 377 266 283 377 269 283 minecraft:red_terracotta
setblock 377 266 287 minecraft:stripped_oak_log
fill 377 266 288 377 266 291 minecraft:red_terracotta
setblock 377 266 292 minecraft:stripped_oak_log
fill 377 266 293 377 269 293 minecraft:red_terracotta
setblock 377 266 297 minecraft:stripped_oak_log
fill 377 266 298 377 269 298 minecraft:red_terracotta
setblock 377 266 302 minecraft:stripped_oak_log
fill 377 266 303 377 269 303 minecraft:red_terracotta
setblock 377 266 307 minecraft:stripped_oak_log
fill 377 266 308 377 269 308 minecraft:red_terracotta
setblock 377 266 312 minecraft:stripped_oak_log
fill 377 266 313 377 269 313 minecraft:red_terracotta
setblock 378 266 276 minecraft:stripped_oak_log
setblock 378 266 281 minecraft:stripped_oak_log
fill 378 266 282 378 269 282 minecraft:red_terracotta
setblock 378 266 286 minecraft:stripped_oak_log
fill 378 266 287 378 266 290 minecraft:red_terracotta
setblock 378 266 291 minecraft:stripped_oak_log
fill 378 266 292 378 269 292 minecraft:red_terracotta
setblock 378 266 296 minecraft:stripped_oak_log
fill 378 266 297 378 269 297 minecraft:red_terracotta
setblock 378 266 301 minecraft:stripped_oak_log
fill 378 266 302 378 269 302 minecraft:red_terracotta
setblock 378 266 306 minecraft:stripped_oak_log
fill 378 266 307 378 269 307 minecraft:red_terracotta
setblock 378 266 311 minecraft:stripped_oak_log
fill 378 266 312 378 269 312 minecraft:red_terracotta
fill 378 266 314 378 267 314 minecraft:red_terracotta
setblock 378 266 316 minecraft:stripped_oak_log
fill 379 266 276 379 268 276 minecraft:red_terracotta
fill 379 266 281 379 267 281 minecraft:red_terracotta
setblock 379 266 284 minecraft:red_terracotta
setblock 379 266 285 minecraft:stripped_oak_log
fill 379 266 286 379 266 289 minecraft:red_terracotta
fill 379 266 296 379 268 296 minecraft:red_terracotta
setblock 379 266 299 minecraft:red_terracotta
setblock 379 266 300 minecraft:stripped_oak_log
fill 379 266 301 379 269 301 minecraft:red_terracotta
setblock 379 266 305 minecraft:stripped_oak_log
fill 379 266 306 379 269 306 minecraft:red_terracotta
setblock 379 266 310 minecraft:stripped_oak_log
fill 379 266 311 379 269 311 minecraft:red_terracotta
fill 379 266 316 379 269 316 minecraft:red_terracotta
setblock 380 266 299 minecraft:stripped_oak_log
fill 380 266 300 380 267 300 minecraft:red_terracotta
setblock 380 266 304 minecraft:stripped_oak_log
fill 380 266 305 380 269 305 minecraft:red_terracotta
setblock 380 266 308 minecraft:red_terracotta
setblock 393 266 276 minecraft:stripped_oak_log
fill 394 266 276 394 268 277 minecraft:red_terracotta
setblock 395 266 278 minecraft:red_terracotta
setblock 396 266 278 minecraft:stripped_oak_log
setblock 397 266 277 minecraft:stripped_oak_log
fill 397 266 278 397 269 278 minecraft:red_terracotta
setblock 397 266 316 minecraft:red_terracotta
setblock 398 266 276 minecraft:stripped_oak_log
fill 398 266 277 398 269 277 minecraft:red_terracotta
setblock 398 266 316 minecraft:stripped_oak_log
fill 399 266 276 399 269 276 minecraft:red_terracotta
fill 399 266 316 399 269 316 minecraft:red_terracotta
setblock 400 266 279 minecraft:stripped_oak_log
setblock 401 266 278 minecraft:stripped_oak_log
fill 401 266 279 401 267 279 minecraft:red_terracotta
setblock 402 266 277 minecraft:stripped_oak_log
fill 402 266 278 402 268 278 minecraft:red_terracotta
setblock 403 266 276 minecraft:stripped_oak_log
fill 403 266 277 403 269 277 minecraft:red_terracotta
setblock 403 266 316 minecraft:stripped_oak_log
fill 404 266 276 404 269 276 minecraft:red_terracotta
fill 404 266 316 404 269 316 minecraft:red_terracotta
setblock 407 266 316 minecraft:red_terracotta
setblock 408 266 276 minecraft:stripped_oak_log
fill 409 266 276 409 267 276 minecraft:red_terracotta
fill 411 266 316 412 266 316 minecraft:red_terracotta
setblock 413 266 276 minecraft:stripped_oak_log
setblock 413 266 316 minecraft:stripped_oak_log
fill 414 266 276 414 269 276 minecraft:red_terracotta
fill 414 266 316 414 269 316 minecraft:red_terracotta
fill 415 266 302 415 266 303 minecraft:red_terracotta
setblock 415 266 304 minecraft:stripped_oak_log
fill 415 266 305 415 269 305 minecraft:red_terracotta
setblock 415 266 309 minecraft:stripped_oak_log
fill 415 266 310 415 269 310 minecraft:red_terracotta
fill 415 266 315 415 269 315 minecraft:red_terracotta
setblock 416 266 277 minecraft:red_terracotta
setblock 416 266 278 minecraft:stripped_oak_log
fill 416 266 279 416 268 279 minecraft:red_terracotta
setblock 416 266 283 minecraft:stripped_oak_log
fill 416 266 284 416 267 286 minecraft:red_terracotta
fill 416 266 299 416 269 299 minecraft:red_terracotta
setblock 416 266 303 minecraft:stripped_oak_log
fill 416 266 304 416 269 304 minecraft:red_terracotta
setblock 416 266 307 minecraft:red_terracotta
setblock 416 266 308 minecraft:stripped_oak_log
fill 416 266 309 416 269 309 minecraft:red_terracotta
setblock 416 266 312 minecraft:red_terracotta
setblock 416 266 313 minecraft:stripped_oak_log
fill 416 266 314 416 269 314 minecraft:red_terracotta
setblock 417 266 277 minecraft:stripped_oak_log
fill 417 266 278 417 269 278 minecraft:red_terracotta
setblock 417 266 282 minecraft:stripped_oak_log
fill 417 266 283 417 269 283 minecraft:red_terracotta
setblock 417 266 287 minecraft:stripped_oak_log
fill 417 266 288 417 266 291 minecraft:red_terracotta
fill 417 266 294 417 267 295 minecraft:red_terracotta
setblock 417 266 297 minecraft:stripped_oak_log
fill 417 266 298 417 269 298 minecraft:red_terracotta
setblock 417 266 302 minecraft:stripped_oak_log
fill 417 266 303 417 269 303 minecraft:red_terracotta
setblock 417 266 307 minecraft:stripped_oak_log
fill 417 266 308 417 269 308 minecraft:red_terracotta
setblock 417 266 312 minecraft:stripped_oak_log
fill 417 266 313 417 269 313 minecraft:red_terracotta
setblock 377 267 276 minecraft:stripped_oak_log
fill 377 267 277 377 269 277 minecraft:red_terracotta
setblock 377 267 281 minecraft:stripped_oak_log
fill 377 267 282 377 270 282 minecraft:red_terracotta
setblock 377 267 285 minecraft:red_terracotta
setblock 377 267 286 minecraft:stripped_oak_log
fill 377 267 287 377 267 290 minecraft:red_terracotta
setblock 377 267 291 minecraft:stripped_oak_log
fill 377 267 292 377 270 292 minecraft:red_terracotta
setblock 377 267 295 minecraft:red_terracotta
setblock 377 267 296 minecraft:stripped_oak_log
fill 377 267 297 377 270 297 minecraft:red_terracotta
setblock 377 267 301 minecraft:stripped_oak_log
fill 377 267 302 377 270 302 minecraft:red_terracotta
setblock 377 267 306 minecraft:stripped_oak_log
fill 377 267 307 377 270 307 minecraft:red_terracotta
setblock 377 267 311 minecraft:stripped_oak_log
fill 377 267 312 377 270 312 minecraft:red_terracotta
setblock 377 267 316 minecraft:stripped_oak_log
fill 378 267 276 378 269 276 minecraft:red_terracotta
setblock 378 267 280 minecraft:stripped_oak_log
fill 378 267 281 378 270 281 minecraft:red_terracotta
setblock 378 267 285 minecraft:stripped_oak_log
fill 378 267 286 378 267 289 minecraft:red_terracotta
setblock 378 267 290 minecraft:stripped_oak_log
fill 378 267 291 379 269 291 minecraft:red_terracotta
setblock 378 267 295 minecraft:stripped_oak_log
fill 378 267 296 378 270 296 minecraft:red_terracotta
setblock 378 267 300 minecraft:stripped_oak_log
fill 378 267 301 378 270 301 minecraft:red_terracotta
setblock 378 267 305 minecraft:stripped_oak_log
fill 378 267 306 378 270 306 minecraft:red_terracotta
setblock 378 267 309 minecraft:red_terracotta
setblock 378 267 310 minecraft:stripped_oak_log
fill 378 267 311 378 270 311 minecraft:red_terracotta
fill 378 267 316 378 270 316 minecraft:red_terracotta
setblock 379 267 284 minecraft:stripped_oak_log
fill 379 267 285 379 267 288 minecraft:red_terracotta
setblock 379 267 289 minecraft:stripped_oak_log
fill 379 267 290 379 270 290 minecraft:red_terracotta
fill 379 267 295 379 268 295 minecraft:red_terracotta
setblock 379 267 299 minecraft:stripped_oak_log
fill 379 267 300 379 270 300 minecraft:red_terracotta
setblock 379 267 304 minecraft:stripped_oak_log
fill 379 267 305 379 270 305 minecraft:red_terracotta
setblock 379 267 309 minecraft:stripped_oak_log
fill 379 267 310 379 270 310 minecraft:red_terracotta
setblock 380 267 303 minecraft:stripped_oak_log
fill 380 267 304 380 269 304 minecraft:red_terracotta
setblock 380 267 308 minecraft:stripped_oak_log
setblock 392 267 276 minecraft:stripped_oak_log
fill 393 267 276 393 270 276 minecraft:red_terracotta
setblock 395 267 278 minecraft:stripped_oak_log
setblock 396 267 277 minecraft:stripped_oak_log
fill 396 267 278 396 270 278 minecraft:red_terracotta
setblock 396 267 316 minecraft:red_terracotta
setblock 397 267 276 minecraft:stripped_oak_log
fill 397 267 277 397 270 277 minecraft:red_terracotta
setblock 397 267 316 minecraft:stripped_oak_log
fill 398 267 276 398 270 276 minecraft:red_terracotta
fill 398 267 316 398 270 316 minecraft:red_terracotta
setblock 399 267 279 minecraft:stripped_oak_log
fill 399 267 315 401 268 315 minecraft:red_terracotta
setblock 400 267 278 minecraft:stripped_oak_log
fill 400 267 279 400 268 279 minecraft:red_terracotta
setblock 401 267 277 minecraft:stripped_oak_log
fill 401 267 278 401 269 278 minecraft:red_terracotta
setblock 402 267 276 minecraft:stripped_oak_log
fill 402 267 277 402 270 277 minecraft:red_terracotta
setblock 402 267 316 minecraft:stripped_oak_log
fill 403 267 276 403 270 276 minecraft:red_terracotta
fill 403 267 316 403 270 316 minecraft:red_terracotta
setblock 407 267 276 minecraft:stripped_oak_log
setblock 407 267 316 minecraft:stripped_oak_log
setblock 408 267 276 minecraft:red_terracotta
fill 410 267 316 411 267 316 minecraft:red_terracotta
setblock 412 267 276 minecraft:stripped_oak_log
setblock 412 267 316 minecraft:stripped_oak_log
fill 413 267 276 413 270 276 minecraft:red_terracotta
fill 413 267 316 413 270 316 minecraft:red_terracotta
fill 414 267 315 414 270 315 minecraft:red_terracotta
setblock 415 267 302 minecraft:red_terracotta
setblock 415 267 303 minecraft:stripped_oak_log
fill 415 267 304 415 270 304 minecraft:red_terracotta
fill 415 267 306 415 267 307 minecraft:red_terracotta
setblock 415 267 308 minecraft:stripped_oak_log
fill 415 267 309 415 270 309 minecraft:red_terracotta
fill 415 267 311 415 267 312 minecraft:red_terracotta
setblock 416 267 277 minecraft:stripped_oak_log
fill 416 267 278 416 268 278 minecraft:red_terracotta
setblock 416 267 281 minecraft:red_terracotta
setblock 416 267 282 minecraft:stripped_oak_log
fill 416 267 283 416 270 283 minecraft:red_terracotta
setblock 416 267 287 minecraft:stripped_oak_log
fill 416 267 288 417 269 288 minecraft:red_terracotta
setblock 416 267 302 minecraft:stripped_oak_log
fill 416 267 303 416 270 303 minecraft:red_terracotta
setblock 416 267 307 minecraft:stripped_oak_log
fill 416 267 308 416 270 308 minecraft:red_terracotta
setblock 416 267 312 minecraft:stripped_oak_log
fill 416 267 313 416 270 313 minecraft:red_terracotta
setblock 417 267 276 minecraft:stripped_oak_log
fill 417 267 277 417 270 277 minecraft:red_terracotta
setblock 417 267 281 minecraft:stripped_oak_log
fill 417 267 282 417 270 282 minecraft:red_terracotta
setblock 417 267 285 minecraft:red_terracotta
setblock 417 267 286 minecraft:stripped_oak_log
fill 417 267 287 417 270 287 minecraft:red_terracotta
fill 417 267 289 417 267 290 minecraft:red_terracotta
setblock 417 267 291 minecraft:stripped_oak_log
fill 417 267 292 417 269 293 minecraft:red_terracotta
setblock 417 267 296 minecraft:stripped_oak_log
fill 417 267 297 417 270 297 minecraft:red_terracotta
setblock 417 267 301 minecraft:stripped_oak_log
fill 417 267 302 417 270 302 minecraft:red_terracotta
setblock 417 267 306 minecraft:stripped_oak_log
fill 417 267 307 417 270 307 minecraft:red_terracotta
setblock 417 267 311 minecraft:stripped_oak_log
fill 417 267 312 417 270 312 minecraft:red_terracotta
setblock 417 267 316 minecraft:stripped_oak_log
fill 376 268 275 376 271 317 minecraft:terracotta
fill 377 268 275 418 271 275 minecraft:terracotta
fill 377 268 276 377 269 276 minecraft:red_terracotta
setblock 377 268 280 minecraft:stripped_oak_log
fill 377 268 281 377 271 281 minecraft:red_terracotta
setblock 377 268 285 minecraft:stripped_oak_log
fill 377 268 286 377 268 289 minecraft:red_terracotta
setblock 377 268 290 minecraft:stripped_oak_log
fill 377 268 291 377 271 291 minecraft:red_terracotta
setblock 377 268 294 minecraft:red_terracotta
setblock 377 268 295 minecraft:stripped_oak_log
fill 377 268 296 377 271 296 minecraft:red_terracotta
setblock 377 268 300 minecraft:stripped_oak_log
fill 377 268 301 377 271 301 minecraft:red_terracotta
setblock 377 268 305 minecraft:stripped_oak_log
fill 377 268 306 377 271 306 minecraft:red_terracotta
setblock 377 268 310 minecraft:stripped_oak_log
fill 377 268 311 377 271 311 minecraft:red_terracotta
setblock 377 268 315 minecraft:stripped_oak_log
fill 377 268 316 377 271 316 minecraft:red_terracotta
fill 377 268 317 418 271 317 minecraft:terracotta
setblock 378 268 279 minecraft:stripped_oak_log
fill 378 268 280 378 269 280 minecraft:red_terracotta
setblock 378 268 283 minecraft:red_terracotta
setblock 378 268 284 minecraft:stripped_oak_log
fill 378 268 285 378 268 288 minecraft:red_terracotta
setblock 378 268 289 minecraft:stripped_oak_log
fill 378 268 290 378 271 290 minecraft:red_terracotta
setblock 378 268 294 minecraft:stripped_oak_log
fill 378 268 295 378 271 295 minecraft:red_terracotta
setblock 378 268 299 minecraft:stripped_oak_log
fill 378 268 300 378 271 300 minecraft:red_terracotta
setblock 378 268 304 minecraft:stripped_oak_log
fill 378 268 305 378 271 305 minecraft:red_terracotta
setblock 378 268 309 minecraft:stripped_oak_log
fill 378 268 310 378 271 310 minecraft:red_terracotta
setblock 378 268 314 minecraft:stripped_oak_log
setblock 379 268 283 minecraft:stripped_oak_log
fill 379 268 284 379 268 287 minecraft:red_terracotta
setblock 379 268 288 minecraft:stripped_oak_log
fill 379 268 289 379 271 289 minecraft:red_terracotta
setblock 379 268 292 minecraft:red_terracotta
setblock 379 268 293 minecraft:stripped_oak_log
fill 379 268 294 379 269 294 minecraft:red_terracotta
setblock 379 268 298 minecraft:stripped_oak_log
fill 379 268 299 379 269 299 minecraft:red_terracotta
setblock 379 268 303 minecraft:stripped_oak_log
fill 379 268 304 379 271 304 minecraft:red_terracotta
setblock 379 268 308 minecraft:stripped_oak_log
fill 379 268 309 379 271 309 minecraft:red_terracotta
setblock 380 268 286 minecraft:red_terracotta
setblock 380 268 302 minecraft:stripped_oak_log
fill 380 268 303 380 269 303 minecraft:red_terracotta
setblock 380 268 307 minecraft:stripped_oak_log
fill 380 268 308 380 269 308 minecraft:red_terracotta
fill 391 268 306 393 268 306 minecraft:orange_terracotta
fill 392 268 276 392 271 276 minecraft:red_terracotta
fill 392 268 304 393 268 305 minecraft:orange_terracotta
fill 392 268 307 393 268 309 minecraft:orange_terracotta
fill 393 268 303 400 268 303 minecraft:orange_terracotta
fill 393 268 310 399 268 310 minecraft:orange_terracotta
fill 394 268 302 398 268 302 minecraft:orange_terracotta
fill 394 268 304 394 270 304 minecraft:orange_terracotta
fill 394 268 309 395 270 309 minecraft:orange_terracotta
fill 394 268 311 398 268 311 minecraft:orange_terracotta
setblock 395 268 277 minecraft:stripped_oak_log
fill 395 268 278 395 269 278 minecraft:red_terracotta
setblock 395 268 316 minecraft:red_terracotta
setblock 396 268 276 minecraft:stripped_oak_log
fill 396 268 277 396 271 277 minecraft:red_terracotta
setblock 396 268 316 minecraft:stripped_oak_log
fill 397 268 276 397 271 276 minecraft:red_terracotta
fill 397 268 316 397 271 316 minecraft:red_terracotta
setblock 398 268 279 minecraft:stripped_oak_log
fill 398 268 304 400 268 304 minecraft:orange_terracotta
fill 398 268 309 400 268 309 minecraft:orange_terracotta
fill 398 268 315 398 271 315 minecraft:red_terracotta
setblock 399 268 278 minecraft:stripped_oak_log
setblock 399 268 279 minecraft:red_terracotta
fill 399 268 305 401 268 308 minecraft:orange_terracotta
setblock 400 268 277 minecraft:stripped_oak_log
fill 400 268 278 400 269 278 minecraft:red_terracotta
setblock 401 268 276 minecraft:stripped_oak_log
fill 401 268 277 401 270 277 minecraft:red_terracotta
setblock 401 268 316 minecraft:stripped_oak_log
fill 402 268 276 402 271 276 minecraft:red_terracotta
setblock 402 268 315 minecraft:stripped_oak_log
fill 402 268 316 402 271 316 minecraft:red_terracotta
setblock 406 268 276 minecraft:stripped_oak_log
setblock 406 268 316 minecraft:stripped_oak_log
setblock 407 268 276 minecraft:red_terracotta
fill 407 268 316 410 268 316 minecraft:red_terracotta
setblock 411 268 316 minecraft:stripped_oak_log
setblock 412 268 276 minecraft:red_terracotta
fill 412 268 316 412 271 316 minecraft:red_terracotta
fill 413 268 315 413 271 315 minecraft:red_terracotta
fill 414 268 306 414 268 307 minecraft:red_terracotta
setblock 414 268 308 minecraft:stripped_oak_log
fill 414 268 309 414 271 309 minecraft:red_terracotta
setblock 415 268 302 minecraft:stripped_oak_log
fill 415 268 303 415 271 303 minecraft:red_terracotta
setblock 415 268 306 minecraft:red_terracotta
setblock 415 268 307 minecraft:stripped_oak_log
fill 415 268 308 415 271 308 minecraft:red_terracotta
setblock 415 268 311 minecraft:red_terracotta
setblock 415 268 312 minecraft:stripped_oak_log
fill 415 268 313 415 271 313 minecraft:red_terracotta
setblock 416 268 276 minecraft:stripped_oak_log
setblock 416 268 281 minecraft:stripped_oak_log
fill 416 268 282 416 270 282 minecraft:red_terracotta
fill 416 268 284 416 268 285 minecraft:red_terracotta
setblock 416 268 286 minecraft:stripped_oak_log
fill 416 268 287 416 271 287 minecraft:red_terracotta
fill 416 268 289 417 268 289 minecraft:red_terracotta
fill 416 268 298 416 269 298 minecraft:red_terracotta
setblock 416 268 301 minecraft:stripped_oak_log
fill 416 268 302 416 271 302 minecraft:red_terracotta
setblock 416 268 306 minecraft:stripped_oak_log
fill 416 268 307 416 271 307 minecraft:red_terracotta
setblock 416 268 311 minecraft:stripped_oak_log
fill 416 268 312 416 271 312 minecraft:red_terracotta
setblock 416 268 316 minecraft:stripped_oak_log
fill 417 268 276 417 271 276 minecraft:red_terracotta
setblock 417 268 280 minecraft:stripped_oak_log
fill 417 268 281 417 271 281 minecraft:red_terracotta
setblock 417 268 285 minecraft:stripped_oak_log
fill 417 268 286 417 271 286 minecraft:red_terracotta
setblock 417 268 290 minecraft:stripped_oak_log
fill 417 268 291 417 271 291 minecraft:red_terracotta
setblock 417 268 294 minecraft:red_terracotta
setblock 417 268 295 minecraft:stripped_oak_log
fill 417 268 296 417 271 296 minecraft:red_terracotta
setblock 417 268 300 minecraft:stripped_oak_log
fill 417 268 301 417 271 301 minecraft:red_terracotta
setblock 417 268 305 minecraft:stripped_oak_log
fill 417 268 306 417 271 306 minecraft:red_terracotta
setblock 417 268 310 minecraft:stripped_oak_log
fill 417 268 311 417 271 311 minecraft:red_terracotta
setblock 417 268 315 minecraft:stripped_oak_log
fill 417 268 316 417 271 316 minecraft:red_terracotta
fill 418 268 276 418 271 316 minecraft:terracotta
setblock 377 269 279 minecraft:stripped_oak_log
fill 377 269 280 377 271 280 minecraft:red_terracotta
setblock 377 269 284 minecraft:stripped_oak_log
fill 377 269 285 377 269 288 minecraft:red_terracotta
setblock 377 269 289 minecraft:stripped_oak_log
fill 377 269 290 377 271 290 minecraft:red_terracotta
setblock 377 269 294 minecraft:stripped_oak_log
fill 377 269 295 377 271 295 minecraft:red_terracotta
setblock 377 269 299 minecraft:stripped_oak_log
fill 377 269 300 377 271 300 minecraft:red_terracotta
setblock 377 269 304 minecraft:stripped_oak_log
fill 377 269 305 377 271 305 minecraft:red_terracotta
setblock 377 269 309 minecraft:stripped_oak_log
fill 377 269 310 377 271 310 minecraft:red_terracotta
setblock 377 269 314 minecraft:stripped_oak_log
fill 377 269 315 377 271 315 minecraft:red_terracotta
setblock 378 269 283 minecraft:stripped_oak_log
fill 378 269 284 378 269 287 minecraft:red_terracotta
setblock 378 269 288 minecraft:stripped_oak_log
fill 378 269 289 378 271 289 minecraft:red_terracotta
setblock 378 269 293 minecraft:stripped_oak_log
fill 378 269 294 378 271 294 minecraft:red_terracotta
setblock 378 269 298 minecraft:stripped_oak_log
fill 378 269 299 378 271 299 minecraft:red_terracotta
setblock 378 269 303 minecraft:stripped_oak_log
fill 378 269 304 378 271 304 minecraft:red_terracotta
setblock 378 269 308 minecraft:stripped_oak_log
fill 378 269 309 378 271 309 minecraft:red_terracotta
setblock 378 269 313 minecraft:stripped_oak_log
fill 378 269 314 378 271 314 minecraft:red_terracotta
setblock 379 269 278 minecraft:light[level=12]
setblock 379 269 282 minecraft:stripped_oak_log
fill 379 269 283 379 269 286 minecraft:red_terracotta
setblock 379 269 287 minecraft:stripped_oak_log
fill 379 269 288 379 271 288 minecraft:red_terracotta
setblock 379 269 292 minecraft:stripped_oak_log
fill 379 269 293 379 271 293 minecraft:red_terracotta
setblock 379 269 297 minecraft:stripped_oak_log
setblock 379 269 298 minecraft:red_terracotta
setblock 379 269 302 minecraft:stripped_oak_log
fill 379 269 303 379 271 303 minecraft:red_terracotta
setblock 379 269 307 minecraft:stripped_oak_log
fill 379 269 308 379 271 308 minecraft:red_terracotta
setblock 379 269 313 minecraft:light[level=12]
setblock 380 269 287 minecraft:red_terracotta
setblock 380 269 306 minecraft:stripped_oak_log
setblock 380 269 307 minecraft:red_terracotta
setblock 380 269 316 minecraft:stripped_oak_log
setblock 386 269 278 minecraft:light[level=12]
setblock 386 269 285 minecraft:light[level=12]
setblock 386 269 292 minecraft:light[level=12]
setblock 386 269 299 minecraft:light[level=12]
setblock 386 269 306 minecraft:light[level=12]
setblock 386 269 313 minecraft:light[level=12]
fill 392 269 306 393 269 307 minecraft:orange_terracotta
setblock 393 269 278 minecraft:light[level=12]
setblock 393 269 285 minecraft:light[level=12]
setblock 393 269 292 minecraft:light[level=12]
setblock 393 269 299 minecraft:light[level=12]
fill 393 269 304 393 269 305 minecraft:orange_terracotta
fill 393 269 308 393 269 309 minecraft:orange_terracotta
setblock 393 269 313 minecraft:light[level=12]
setblock 394 269 276 minecraft:red_terracotta
setblock 394 269 277 minecraft:stripped_oak_log
fill 394 269 303 398 269 303 minecraft:orange_terracotta
fill 394 269 310 398 269 310 minecraft:orange_terracotta
setblock 394 269 316 minecraft:red_terracotta
setblock 395 269 276 minecraft:stripped_oak_log
fill 395 269 277 395 271 277 minecraft:red_terracotta
setblock 395 269 316 minecraft:stripped_oak_log
fill 396 269 276 396 271 276 minecraft:red_terracotta
fill 396 269 316 396 271 316 minecraft:red_terracotta
fill 397 269 315 397 271 315 minecraft:red_terracotta
setblock 398 269 278 minecraft:stripped_oak_log
fill 398 269 304 399 269 304 minecraft:orange_terracotta
fill 398 269 309 399 269 309 minecraft:orange_terracotta
setblock 399 269 277 minecraft:stripped_oak_log
fill 399 269 278 399 270 278 minecraft:red_terracotta
fill 399 269 305 400 269 308 minecraft:orange_terracotta
fill 399 269 315 400 269 315 minecraft:red_terracotta
setblock 400 269 276 minecraft:stripped_oak_log
fill 400 269 277 400 271 277 minecraft:red_terracotta
setblock 400 269 285 minecraft:light[level=12]
setblock 400 269 292 minecraft:light[level=12]
setblock 400 269 299 minecraft:light[level=12]
setblock 400 269 313 minecraft:light[level=12]
setblock 400 269 316 minecraft:stripped_oak_log
fill 401 269 276 401 271 276 minecraft:red_terracotta
setblock 401 269 315 minecraft:stripped_oak_log
fill 401 269 316 401 271 316 minecraft:red_terracotta
setblock 405 269 276 minecraft:stripped_oak_log
setblock 405 269 316 minecraft:stripped_oak_log
setblock 406 269 276 minecraft:red_terracotta
fill 406 269 316 409 269 316 minecraft:red_terracotta
setblock 407 269 278 minecraft:light[level=12]
setblock 407 269 285 minecraft:light[level=12]
setblock 407 269 292 minecraft:light[level=12]
setblock 407 269 299 minecraft:light[level=12]
setblock 407 269 306 minecraft:light[level=12]
setblock 407 269 313 minecraft:light[level=12]
setblock 410 269 316 minecraft:stripped_oak_log
fill 411 269 316 411 271 316 minecraft:red_terracotta
fill 412 269 315 412 271 315 minecraft:red_terracotta
setblock 414 269 278 minecraft:light[level=12]
setblock 414 269 285 minecraft:light[level=12]
setblock 414 269 292 minecraft:light[level=12]
setblock 414 269 299 minecraft:light[level=12]
fill 414 269 305 414 269 306 minecraft:red_terracotta
setblock 414 269 307 minecraft:stripped_oak_log
fill 414 269 308 414 271 308 minecraft:red_terracotta
fill 414 269 310 414 270 310 minecraft:red_terracotta
setblock 414 269 313 minecraft:light[level=12]
setblock 415 269 276 minecraft:stripped_oak_log
fill 415 269 302 415 270 302 minecraft:red_terracotta
setblock 415 269 306 minecraft:stripped_oak_log
fill 415 269 307 415 271 307 minecraft:red_terracotta
setblock 415 269 311 minecraft:stripped_oak_log
fill 415 269 312 415 271 312 minecraft:red_terracotta
fill 415 269 314 415 270 314 minecraft:red_terracotta
setblock 415 269 316 minecraft:stripped_oak_log
fill 416 269 276 416 271 276 minecraft:red_terracotta
setblock 416 269 280 minecraft:stripped_oak_log
fill 416 269 281 416 270 281 minecraft:red_terracotta
setblock 416 269 284 minecraft:red_terracotta
setblock 416 269 285 minecraft:stripped_oak_log
fill 416 269 286 416 271 286 minecraft:red_terracotta
setblock 416 269 289 minecraft:red_terracotta
setblock 416 269 290 minecraft:stripped_oak_log
fill 416 269 291 416 271 291 minecraft:red_terracotta
setblock 416 269 300 minecraft:stripped_oak_log
fill 416 269 301 416 271 301 minecraft:red_terracotta
setblock 416 269 305 minecraft:stripped_oak_log
fill 416 269 306 416 271 306 minecraft:red_terracotta
setblock 416 269 310 minecraft:stripped_oak_log
fill 416 269 311 416 271 311 minecraft:red_terracotta
setblock 416 269 315 minecraft:stripped_oak_log
fill 416 269 316 416 271 316 minecraft:red_terracotta
setblock 417 269 279 minecraft:stripped_oak_log
fill 417 269 280 417 271 280 minecraft:red_terracotta
setblock 417 269 284 minecraft:stripped_oak_log
fill 417 269 285 417 271 285 minecraft:red_terracotta
setblock 417 269 289 minecraft:stripped_oak_log
fill 417 269 290 417 271 290 minecraft:red_terracotta
setblock 417 269 294 minecraft:stripped_oak_log
fill 417 269 295 417 271 295 minecraft:red_terracotta
setblock 417 269 299 minecraft:stripped_oak_log
fill 417 269 300 417 271 300 minecraft:red_terracotta
setblock 417 269 304 minecraft:stripped_oak_log
fill 417 269 305 417 271 305 minecraft:red_terracotta
setblock 417 269 309 minecraft:stripped_oak_log
fill 417 269 310 417 271 310 minecraft:red_terracotta
setblock 417 269 314 minecraft:stripped_oak_log
fill 417 269 315 417 271 315 minecraft:red_terracotta
setblock 377 270 278 minecraft:stripped_oak_log
fill 377 270 279 377 271 279 minecraft:red_terracotta
setblock 377 270 283 minecraft:stripped_oak_log
fill 377 270 284 377 270 287 minecraft:red_terracotta
setblock 377 270 288 minecraft:stripped_oak_log
fill 377 270 289 377 271 289 minecraft:red_terracotta
setblock 377 270 293 minecraft:stripped_oak_log
fill 377 270 294 377 271 294 minecraft:red_terracotta
setblock 377 270 298 minecraft:stripped_oak_log
fill 377 270 299 377 271 299 minecraft:red_terracotta
setblock 377 270 303 minecraft:stripped_oak_log
fill 377 270 304 377 271 304 minecraft:red_terracotta
setblock 377 270 308 minecraft:stripped_oak_log
fill 377 270 309 377 271 309 minecraft:red_terracotta
setblock 377 270 313 minecraft:stripped_oak_log
fill 377 270 314 377 271 314 minecraft:red_terracotta
setblock 378 270 282 minecraft:stripped_oak_log
fill 378 270 283 378 270 286 minecraft:red_terracotta
setblock 378 270 287 minecraft:stripped_oak_log
fill 378 270 288 378 271 288 minecraft:red_terracotta
setblock 378 270 291 minecraft:red_terracotta
setblock 378 270 292 minecraft:stripped_oak_log
fill 378 270 293 378 271 293 minecraft:red_terracotta
setblock 378 270 297 minecraft:stripped_oak_log
fill 378 270 298 378 271 298 minecraft:red_terracotta
setblock 378 270 302 minecraft:stripped_oak_log
fill 378 270 303 378 271 303 minecraft:red_terracotta
setblock 378 270 307 minecraft:stripped_oak_log
fill 378 270 308 378 271 308 minecraft:red_terracotta
setblock 378 270 312 minecraft:stripped_oak_log
fill 378 270 313 378 271 313 minecraft:red_terracotta
fill 379 270 283 379 270 285 minecraft:red_terracotta
setblock 379 270 286 minecraft:stripped_oak_log
fill 379 270 287 379 271 287 minecraft:red_terracotta
setblock 379 270 291 minecraft:stripped_oak_log
fill 379 270 292 379 271 292 minecraft:red_terracotta
setblock 379 270 301 minecraft:stripped_oak_log
setblock 379 270 302 minecraft:red_terracotta
setblock 379 270 306 minecraft:stripped_oak_log
fill 379 270 307 379 271 307 minecraft:red_terracotta
setblock 379 270 311 minecraft:stripped_oak_log
setblock 379 270 316 minecraft:stripped_oak_log
fill 393 270 305 393 270 308 minecraft:orange_terracotta
setblock 394 270 276 minecraft:stripped_oak_log
fill 394 270 277 394 271 277 minecraft:red_terracotta
setblock 394 270 316 minecraft:stripped_oak_log
fill 395 270 276 395 271 276 minecraft:red_terracotta
fill 395 270 316 395 271 316 minecraft:red_terracotta
fill 396 270 303 397 270 303 minecraft:orange_terracotta
fill 396 270 315 396 271 315 minecraft:red_terracotta
setblock 397 270 278 minecraft:stripped_oak_log
setblock 398 270 277 minecraft:stripped_oak_log
setblock 398 270 278 minecraft:red_terracotta
setblock 398 270 304 minecraft:orange_terracotta
setblock 398 270 309 minecraft:orange_terracotta
setblock 399 270 276 minecraft:stripped_oak_log
fill 399 270 277 399 271 277 minecraft:red_terracotta
fill 399 270 305 399 270 308 minecraft:orange_terracotta
setblock 399 270 315 minecraft:red_terracotta
setblock 399 270 316 minecraft:stripped_oak_log
fill 400 270 276 400 271 276 minecraft:red_terracotta
setblock 400 270 315 minecraft:stripped_oak_log
fill 400 270 316 400 271 316 minecraft:red_terracotta
fill 401 270 315 401 271 315 minecraft:red_terracotta
setblock 404 270 276 minecraft:stripped_oak_log
setblock 404 270 316 minecraft:stripped_oak_log
fill 405 270 316 408 270 316 minecraft:red_terracotta
setblock 409 270 316 minecraft:stripped_oak_log
fill 410 270 316 410 271 316 minecraft:red_terracotta
setblock 414 270 276 minecraft:stripped_oak_log
setblock 414 270 306 minecraft:stripped_oak_log
fill 414 270 307 414 271 307 minecraft:red_terracotta
setblock 414 270 311 minecraft:stripped_oak_log
fill 414 270 314 414 271 314 minecraft:red_terracotta
setblock 414 270 316 minecraft:stripped_oak_log
fill 415 270 276 415 271 276 minecraft:red_terracotta
setblock 415 270 305 minecraft:stripped_oak_log
fill 415 270 306 415 271 306 minecraft:red_terracotta
setblock 415 270 310 minecraft:stripped_oak_log
fill 415 270 311 415 271 311 minecraft:red_terracotta
setblock 415 270 315 minecraft:stripped_oak_log
fill 415 270 316 415 271 316 minecraft:red_terracotta
setblock 416 270 284 minecraft:stripped_oak_log
fill 416 270 285 416 271 285 minecraft:red_terracotta
setblock 416 270 288 minecraft:red_terracotta
setblock 416 270 289 minecraft:stripped_oak_log
fill 416 270 290 416 271 290 minecraft:red_terracotta
fill 416 270 292 417 270 292 minecraft:red_terracotta
setblock 416 270 299 minecraft:stripped_oak_log
fill 416 270 300 416 271 300 minecraft:red_terracotta
setblock 416 270 304 minecraft:stripped_oak_log
fill 416 270 305 416 271 305 minecraft:red_terracotta
setblock 416 270 309 minecraft:stripped_oak_log
fill 416 270 310 416 271 310 minecraft:red_terracotta
setblock 416 270 314 minecraft:stripped_oak_log
fill 416 270 315 416 271 315 minecraft:red_terracotta
setblock 417 270 278 minecraft:stripped_oak_log
fill 417 270 279 417 271 279 minecraft:red_terracotta
setblock 417 270 283 minecraft:stripped_oak_log
fill 417 270 284 417 271 284 minecraft:red_terracotta
setblock 417 270 288 minecraft:stripped_oak_log
fill 417 270 289 417 271 289 minecraft:red_terracotta
setblock 417 270 293 minecraft:stripped_oak_log
fill 417 270 294 417 271 294 minecraft:red_terracotta
setblock 417 270 298 minecraft:stripped_oak_log
fill 417 270 299 417 271 299 minecraft:red_terracotta
setblock 417 270 303 minecraft:stripped_oak_log
fill 417 270 304 417 271 304 minecraft:red_terracotta
setblock 417 270 308 minecraft:stripped_oak_log
fill 417 270 309 417 271 309 minecraft:red_terracotta
setblock 417 270 313 minecraft:stripped_oak_log
fill 417 270 314 417 271 314 minecraft:red_terracotta
setblock 377 271 282 minecraft:stripped_oak_log
fill 377 271 283 377 271 286 minecraft:red_terracotta
setblock 377 271 287 minecraft:stripped_oak_log
setblock 377 271 288 minecraft:red_terracotta
setblock 377 271 292 minecraft:stripped_oak_log
setblock 377 271 293 minecraft:red_terracotta
setblock 377 271 297 minecraft:stripped_oak_log
setblock 377 271 298 minecraft:red_terracotta
setblock 377 271 302 minecraft:stripped_oak_log
setblock 377 271 303 minecraft:red_terracotta
setblock 377 271 307 minecraft:stripped_oak_log
setblock 377 271 308 minecraft:red_terracotta
setblock 377 271 312 minecraft:stripped_oak_log
setblock 377 271 313 minecraft:red_terracotta
fill 378 271 282 378 271 285 minecraft:red_terracotta
setblock 378 271 286 minecraft:stripped_oak_log
setblock 378 271 287 minecraft:red_terracotta
setblock 378 271 291 minecraft:stripped_oak_log
setblock 378 271 292 minecraft:red_terracotta
setblock 378 271 296 minecraft:stripped_oak_log
setblock 378 271 297 minecraft:red_terracotta
setblock 378 271 301 minecraft:stripped_oak_log
setblock 378 271 302 minecraft:red_terracotta
setblock 378 271 306 minecraft:stripped_oak_log
setblock 378 271 307 minecraft:red_terracotta
setblock 378 271 311 minecraft:stripped_oak_log
setblock 378 271 312 minecraft:red_terracotta
setblock 378 271 316 minecraft:stripped_oak_log
setblock 379 271 278 minecraft:light[level=15]
setblock 379 271 284 minecraft:red_terracotta
setblock 379 271 285 minecraft:stripped_oak_log
setblock 379 271 286 minecraft:red_terracotta
setblock 379 271 290 minecraft:stripped_oak_log
setblock 379 271 291 minecraft:red_terracotta
setblock 379 271 294 minecraft:light[level=15]
setblock 379 271 302 minecraft:light[level=15]
setblock 379 271 305 minecraft:stripped_oak_log
setblock 379 271 306 minecraft:red_terracotta
setblock 379 271 310 minecraft:stripped_oak_log
setblock 387 271 278 minecraft:light[level=15]
setblock 387 271 286 minecraft:light[level=15]
setblock 387 271 294 minecraft:light[level=15]
setblock 387 271 302 minecraft:light[level=15]
setblock 387 271 310 minecraft:light[level=15]
setblock 393 271 276 minecraft:stripped_oak_log
setblock 393 271 316 minecraft:stripped_oak_log
setblock 394 271 276 minecraft:red_terracotta
setblock 394 271 316 minecraft:red_terracotta
setblock 395 271 278 minecraft:light[level=15]
setblock 395 271 286 minecraft:light[level=15]
setblock 395 271 302 minecraft:light[level=15]
setblock 395 271 310 minecraft:light[level=15]
setblock 397 271 277 minecraft:stripped_oak_log
setblock 398 271 276 minecraft:stripped_oak_log
setblock 398 271 277 minecraft:red_terracotta
setblock 398 271 316 minecraft:stripped_oak_log
setblock 399 271 276 minecraft:red_terracotta
setblock 399 271 315 minecraft:stripped_oak_log
setblock 399 271 316 minecraft:red_terracotta
setblock 400 271 315 minecraft:red_terracotta
setblock 403 271 276 minecraft:stripped_oak_log
setblock 403 271 278 minecraft:light[level=15]
setblock 403 271 286 minecraft:light[level=15]
setblock 403 271 294 minecraft:light[level=15]
setblock 403 271 302 minecraft:light[level=15]
setblock 403 271 310 minecraft:light[level=15]
setblock 403 271 316 minecraft:stripped_oak_log
fill 404 271 316 405 271 316 minecraft:red_terracotta
setblock 408 271 316 minecraft:stripped_oak_log
setblock 409 271 316 minecraft:red_terracotta
setblock 411 271 278 minecraft:light[level=15]
setblock 411 271 286 minecraft:light[level=15]
setblock 411 271 294 minecraft:light[level=15]
setblock 411 271 302 minecraft:light[level=15]
setblock 411 271 310 minecraft:light[level=15]
setblock 411 271 315 minecraft:red_terracotta
setblock 413 271 314 minecraft:red_terracotta
setblock 413 271 316 minecraft:stripped_oak_log
setblock 414 271 306 minecraft:red_terracotta
setblock 414 271 310 minecraft:stripped_oak_log
setblock 414 271 311 minecraft:red_terracotta
setblock 414 271 315 minecraft:stripped_oak_log
setblock 414 271 316 minecraft:red_terracotta
setblock 415 271 304 minecraft:stripped_oak_log
setblock 415 271 305 minecraft:red_terracotta
setblock 415 271 309 minecraft:stripped_oak_log
setblock 415 271 310 minecraft:red_terracotta
setblock 415 271 314 minecraft:stripped_oak_log
setblock 415 271 315 minecraft:red_terracotta
setblock 416 271 283 minecraft:stripped_oak_log
setblock 416 271 284 minecraft:red_terracotta
setblock 416 271 288 minecraft:stripped_oak_log
setblock 416 271 289 minecraft:red_terracotta
setblock 416 271 292 minecraft:red_terracotta
setblock 416 271 299 minecraft:red_terracotta
setblock 416 271 303 minecraft:stripped_oak_log
setblock 416 271 304 minecraft:red_terracotta
setblock 416 271 308 minecraft:stripped_oak_log
setblock 416 271 309 minecraft:red_terracotta
setblock 416 271 313 minecraft:stripped_oak_log
setblock 416 271 314 minecraft:red_terracotta
setblock 417 271 278 minecraft:red_terracotta
setblock 417 271 282 minecraft:stripped_oak_log
setblock 417 271 283 minecraft:red_terracotta
setblock 417 271 287 minecraft:stripped_oak_log
setblock 417 271 288 minecraft:red_terracotta
setblock 417 271 292 minecraft:stripped_oak_log
setblock 417 271 293 minecraft:red_terracotta
setblock 417 271 297 minecraft:stripped_oak_log
setblock 417 271 298 minecraft:red_terracotta
setblock 417 271 302 minecraft:stripped_oak_log
setblock 417 271 303 minecraft:red_terracotta
setblock 417 271 307 minecraft:stripped_oak_log
setblock 417 271 308 minecraft:red_terracotta
setblock 417 271 312 minecraft:stripped_oak_log
setblock 417 271 313 minecraft:red_terracotta
fill 376 272 275 376 275 317 minecraft:brown_terracotta
fill 377 272 275 418 275 275 minecraft:brown_terracotta
fill 377 272 317 418 275 317 minecraft:brown_terracotta
fill 418 272 276 418 275 316 minecraft:brown_terracotta
setblock 379 275 278 minecraft:light[level=12]
setblock 379 275 285 minecraft:light[level=12]
setblock 379 275 292 minecraft:light[level=12]
setblock 379 275 299 minecraft:light[level=12]
setblock 379 275 306 minecraft:light[level=12]
setblock 379 275 313 minecraft:light[level=12]
setblock 386 275 278 minecraft:light[level=12]
setblock 386 275 285 minecraft:light[level=12]
setblock 386 275 292 minecraft:light[level=12]
setblock 386 275 299 minecraft:light[level=12]
setblock 386 275 306 minecraft:light[level=12]
setblock 386 275 313 minecraft:light[level=12]
setblock 393 275 278 minecraft:light[level=12]
setblock 393 275 285 minecraft:light[level=12]
setblock 393 275 292 minecraft:light[level=12]
setblock 393 275 299 minecraft:light[level=12]
setblock 393 275 306 minecraft:light[level=12]
setblock 393 275 313 minecraft:light[level=12]
setblock 400 275 278 minecraft:light[level=12]
setblock 400 275 285 minecraft:light[level=12]
setblock 400 275 292 minecraft:light[level=12]
setblock 400 275 299 minecraft:light[level=12]
setblock 400 275 306 minecraft:light[level=12]
setblock 400 275 313 minecraft:light[level=12]
setblock 407 275 278 minecraft:light[level=12]
setblock 407 275 285 minecraft:light[level=12]
setblock 407 275 292 minecraft:light[level=12]
setblock 407 275 299 minecraft:light[level=12]
setblock 407 275 306 minecraft:light[level=12]
setblock 407 275 313 minecraft:light[level=12]
setblock 414 275 278 minecraft:light[level=12]
setblock 414 275 285 minecraft:light[level=12]
setblock 414 275 292 minecraft:light[level=12]
setblock 414 275 299 minecraft:light[level=12]
setblock 414 275 306 minecraft:light[level=12]
setblock 414 275 313 minecraft:light[level=12]
fill 376 276 275 376 279 317 minecraft:light_gray_terracotta
fill 377 276 275 418 279 275 minecraft:light_gray_terracotta
fill 377 276 317 418 279 317 minecraft:light_gray_terracotta
fill 418 276 276 418 279 316 minecraft:light_gray_terracotta
fill 377 277 284 391 277 308 minecraft:terracotta
fill 378 277 282 416 277 283 minecraft:terracotta
fill 378 277 309 416 277 310 minecraft:terracotta
fill 379 277 281 415 277 281 minecraft:terracotta
fill 379 277 311 415 277 311 minecraft:terracotta
fill 380 277 280 414 277 280 minecraft:terracotta
fill 380 277 312 414 277 312 minecraft:terracotta
fill 381 277 279 413 277 279 minecraft:terracotta
fill 381 277 313 413 277 313 minecraft:terracotta
fill 382 277 278 412 277 278 minecraft:terracotta
fill 382 277 314 412 277 314 minecraft:terracotta
fill 383 277 277 411 277 277 minecraft:terracotta
fill 383 277 315 411 277 315 minecraft:terracotta
fill 385 277 276 409 277 276 minecraft:terracotta
fill 385 277 316 409 277 316 minecraft:terracotta
fill 392 277 284 392 277 294 minecraft:terracotta
fill 392 277 296 392 277 308 minecraft:terracotta
fill 393 277 284 394 277 292 minecraft:terracotta
fill 393 277 298 394 277 308 minecraft:terracotta
fill 395 277 284 417 277 291 minecraft:terracotta
fill 395 277 299 417 277 308 minecraft:terracotta
fill 396 277 292 417 277 292 minecraft:terracotta
fill 396 277 298 417 277 298 minecraft:terracotta
fill 398 277 293 417 277 294 minecraft:terracotta
fill 398 277 296 417 277 297 minecraft:terracotta
fill 399 277 295 417 277 295 minecraft:terracotta
fill 377 278 285 377 279 307 minecraft:terracotta
fill 378 278 283 378 279 284 minecraft:terracotta
fill 378 278 285 391 278 307 minecraft:red_terracotta
fill 378 278 308 378 279 309 minecraft:terracotta
fill 379 278 282 379 279 282 minecraft:terracotta
fill 379 278 283 415 278 284 minecraft:red_terracotta
fill 379 278 308 415 278 309 minecraft:red_terracotta
fill 379 278 310 379 279 310 minecraft:terracotta
fill 380 278 281 380 279 281 minecraft:terracotta
fill 380 278 282 414 278 282 minecraft:red_terracotta
fill 380 278 310 414 278 310 minecraft:red_terracotta
fill 380 278 311 380 279 311 minecraft:terracotta
fill 381 278 280 381 279 280 minecraft:terracotta
fill 381 278 281 413 278 281 minecraft:red_terracotta
fill 381 278 311 413 278 311 minecraft:red_terracotta
fill 381 278 312 381 279 312 minecraft:terracotta
fill 382 278 279 382 279 279 minecraft:terracotta
fill 382 278 280 412 278 280 minecraft:red_terracotta
fill 382 278 312 412 278 312 minecraft:red_terracotta
fill 382 278 313 382 279 313 minecraft:terracotta
fill 383 278 278 383 279 278 minecraft:terracotta
fill 383 278 279 411 278 279 minecraft:red_terracotta
fill 383 278 313 411 278 313 minecraft:red_terracotta
fill 383 278 314 383 279 314 minecraft:terracotta
fill 384 278 277 385 279 277 minecraft:terracotta
fill 384 278 278 410 278 278 minecraft:red_terracotta
fill 384 278 314 410 278 314 minecraft:red_terracotta
fill 384 278 315 385 279 315 minecraft:terracotta
fill 386 278 276 408 279 276 minecraft:terracotta
fill 386 278 277 408 278 277 minecraft:red_terracotta
fill 386 278 315 408 278 315 minecraft:red_terracotta
fill 386 278 316 408 279 316 minecraft:terracotta
fill 392 278 285 392 278 293 minecraft:red_terracotta
setblock 392 278 294 minecraft:orange_terracotta
setblock 392 278 296 minecraft:orange_terracotta
fill 392 278 297 392 278 307 minecraft:red_terracotta
fill 393 278 285 393 278 292 minecraft:red_terracotta
fill 393 278 298 394 278 298 minecraft:orange_terracotta
fill 393 278 299 416 278 307 minecraft:red_terracotta
fill 394 278 285 416 278 291 minecraft:red_terracotta
setblock 394 278 292 minecraft:orange_terracotta
fill 396 278 292 397 278 292 minecraft:orange_terracotta
fill 396 278 298 397 278 298 minecraft:orange_terracotta
fill 398 278 292 416 278 292 minecraft:red_terracotta
fill 398 278 293 398 278 294 minecraft:orange_terracotta
fill 398 278 296 398 278 297 minecraft:orange_terracotta
fill 398 278 298 416 278 298 minecraft:red_terracotta
fill 399 278 293 416 278 297 minecraft:red_terracotta
fill 409 278 277 410 279 277 minecraft:terracotta
fill 409 278 315 410 279 315 minecraft:terracotta
fill 411 278 278 411 279 278 minecraft:terracotta
fill 411 278 314 411 279 314 minecraft:terracotta
fill 412 278 279 412 279 279 minecraft:terracotta
fill 412 278 313 412 279 313 minecraft:terracotta
fill 413 278 280 413 279 280 minecraft:terracotta
fill 413 278 312 413 279 312 minecraft:terracotta
fill 414 278 281 414 279 281 minecraft:terracotta
fill 414 278 311 414 279 311 minecraft:terracotta
fill 415 278 282 415 279 282 minecraft:terracotta
fill 415 278 310 415 279 310 minecraft:terracotta
fill 416 278 283 416 279 284 minecraft:terracotta
fill 416 278 308 416 279 309 minecraft:terracotta
fill 417 278 285 417 279 307 minecraft:terracotta
fill 377 279 276 377 279 284 minecraft:terracotta
fill 377 279 308 377 279 316 minecraft:terracotta
fill 378 279 276 378 279 282 minecraft:terracotta
fill 378 279 285 378 280 285 minecraft:terracotta
fill 378 279 286 390 279 306 minecraft:red_terracotta
fill 378 279 307 378 280 307 minecraft:terracotta
fill 378 279 310 378 279 316 minecraft:terracotta
fill 379 279 276 379 279 281 minecraft:terracotta
setblock 379 279 283 minecraft:terracotta
fill 379 279 284 415 279 285 minecraft:red_terracotta
fill 379 279 307 415 279 308 minecraft:red_terracotta
setblock 379 279 309 minecraft:terracotta
fill 379 279 311 379 279 316 minecraft:terracotta
fill 380 279 276 380 279 280 minecraft:terracotta
fill 380 279 282 380 280 282 minecraft:terracotta
fill 380 279 283 414 279 283 minecraft:red_terracotta
fill 380 279 309 414 279 309 minecraft:red_terracotta
fill 380 279 310 380 280 310 minecraft:terracotta
fill 380 279 312 380 279 316 minecraft:terracotta
fill 381 279 276 381 279 279 minecraft:terracotta
fill 381 279 281 381 280 281 minecraft:terracotta
fill 381 279 282 413 280 282 minecraft:red_terracotta
fill 381 279 310 413 280 310 minecraft:red_terracotta
fill 381 279 311 381 280 311 minecraft:terracotta
fill 381 279 313 381 279 316 minecraft:terracotta
fill 382 279 276 382 279 278 minecraft:terracotta
fill 382 279 280 382 280 280 minecraft:terracotta
fill 382 279 281 412 280 281 minecraft:red_terracotta
fill 382 279 311 412 280 311 minecraft:red_terracotta
fill 382 279 312 382 280 312 minecraft:terracotta
fill 382 279 314 382 279 316 minecraft:terracotta
fill 383 279 276 383 279 277 minecraft:terracotta
fill 383 279 279 383 280 279 minecraft:terracotta
fill 383 279 280 411 280 280 minecraft:red_terracotta
fill 383 279 312 411 280 312 minecraft:red_terracotta
fill 383 279 313 383 280 313 minecraft:terracotta
fill 383 279 315 383 279 316 minecraft:terracotta
fill 384 279 276 385 279 276 minecraft:terracotta
setblock 384 279 278 minecraft:terracotta
fill 384 279 279 410 279 279 minecraft:red_terracotta
fill 384 279 313 410 279 313 minecraft:red_terracotta
setblock 384 279 314 minecraft:terracotta
fill 384 279 316 385 279 316 minecraft:terracotta
fill 385 279 278 409 279 278 minecraft:red_terracotta
fill 385 279 314 409 279 314 minecraft:red_terracotta
fill 386 279 277 386 280 277 minecraft:terracotta
fill 386 279 315 386 280 315 minecraft:terracotta
fill 387 279 277 407 279 277 minecraft:red_terracotta
fill 387 279 315 407 279 315 minecraft:red_terracotta
fill 391 279 286 391 279 293 minecraft:red_terracotta
fill 391 279 294 391 279 296 minecraft:shroomlight
fill 391 279 297 391 279 306 minecraft:red_terracotta
fill 392 279 286 393 279 291 minecraft:red_terracotta
fill 392 279 292 392 279 294 minecraft:shroomlight
fill 392 279 296 392 279 298 minecraft:shroomlight
fill 392 279 299 392 279 306 minecraft:red_terracotta
fill 393 279 292 394 279 292 minecraft:shroomlight
fill 393 279 298 394 279 298 minecraft:shroomlight
setblock 393 279 299 minecraft:yellow_terracotta
fill 393 279 300 416 279 306 minecraft:red_terracotta
fill 394 279 286 416 279 290 minecraft:red_terracotta
fill 394 279 291 396 279 291 minecraft:shroomlight
fill 394 279 299 396 279 299 minecraft:shroomlight
fill 396 279 292 398 279 292 minecraft:shroomlight
fill 396 279 298 398 279 298 minecraft:shroomlight
setblock 397 279 291 minecraft:yellow_terracotta
setblock 397 279 299 minecraft:yellow_terracotta
fill 398 279 291 416 279 291 minecraft:red_terracotta
fill 398 279 293 398 279 294 minecraft:shroomlight
fill 398 279 296 398 279 297 minecraft:shroomlight
fill 398 279 299 416 279 299 minecraft:red_terracotta
fill 399 279 292 416 279 292 minecraft:red_terracotta
setblock 399 279 293 minecraft:yellow_terracotta
fill 399 279 294 399 279 296 minecraft:shroomlight
setblock 399 279 297 minecraft:yellow_terracotta
fill 399 279 298 416 279 298 minecraft:red_terracotta
fill 400 279 293 416 279 297 minecraft:red_terracotta
fill 408 279 277 408 280 277 minecraft:terracotta
fill 408 279 315 408 280 315 minecraft:terracotta
fill 409 279 276 417 279 276 minecraft:terracotta
fill 409 279 316 417 279 316 minecraft:terracotta
setblock 410 279 278 minecraft:terracotta
setblock 410 279 314 minecraft:terracotta
fill 411 279 277 417 279 277 minecraft:terracotta
fill 411 279 279 411 280 279 minecraft:terracotta
fill 411 279 313 411 280 313 minecraft:terracotta
fill 411 279 315 417 279 315 minecraft:terracotta
fill 412 279 278 417 279 278 minecraft:terracotta
fill 412 279 280 412 280 280 minecraft:terracotta
fill 412 279 312 412 280 312 minecraft:terracotta
fill 412 279 314 417 279 314 minecraft:terracotta
fill 413 279 279 417 279 279 minecraft:terracotta
fill 413 279 281 413 280 281 minecraft:terracotta
fill 413 279 311 413 280 311 minecraft:terracotta
fill 413 279 313 417 279 313 minecraft:terracotta
fill 414 279 280 417 279 280 minecraft:terracotta
fill 414 279 282 414 280 282 minecraft:terracotta
fill 414 279 310 414 280 310 minecraft:terracotta
fill 414 279 312 417 279 312 minecraft:terracotta
fill 415 279 281 417 279 281 minecraft:terracotta
setblock 415 279 283 minecraft:terracotta
setblock 415 279 309 minecraft:terracotta
fill 415 279 311 417 279 311 minecraft:terracotta
fill 416 279 282 417 279 282 minecraft:terracotta
fill 416 279 285 416 280 285 minecraft:terracotta
fill 416 279 307 416 280 307 minecraft:terracotta
fill 416 279 310 417 279 310 minecraft:terracotta
fill 417 279 283 417 279 284 minecraft:terracotta
fill 417 279 308 417 279 309 minecraft:terracotta
fill 376 280 275 376 283 317 minecraft:orange_terracotta
fill 377 280 275 418 283 275 minecraft:orange_terracotta
fill 377 280 287 377 280 305 minecraft:terracotta
fill 377 280 317 418 283 317 minecraft:orange_terracotta
fill 378 280 286 378 281 286 minecraft:terracotta
fill 378 280 287 389 280 305 minecraft:red_terracotta
fill 378 280 306 378 281 306 minecraft:terracotta
setblock 379 280 284 minecraft:terracotta
fill 379 280 285 415 280 286 minecraft:red_terracotta
fill 379 280 306 415 280 307 minecraft:red_terracotta
setblock 379 280 308 minecraft:terracotta
fill 380 280 283 380 281 283 minecraft:terracotta
fill 380 280 284 414 280 284 minecraft:red_terracotta
fill 380 280 308 414 280 308 minecraft:red_terracotta
fill 380 280 309 380 281 309 minecraft:terracotta
fill 381 280 283 413 281 283 minecraft:red_terracotta
fill 381 280 309 413 281 309 minecraft:red_terracotta
fill 384 280 279 384 281 279 minecraft:terracotta
fill 384 280 313 384 281 313 minecraft:terracotta
setblock 385 280 278 minecraft:terracotta
fill 385 280 279 409 280 279 minecraft:red_terracotta
fill 385 280 313 409 280 313 minecraft:red_terracotta
setblock 385 280 314 minecraft:terracotta
fill 386 280 278 408 280 278 minecraft:red_terracotta
fill 386 280 314 408 280 314 minecraft:red_terracotta
fill 387 280 277 387 281 277 minecraft:terracotta
fill 387 280 315 387 281 315 minecraft:terracotta
fill 388 280 276 406 280 276 minecraft:terracotta
fill 388 280 277 406 280 277 minecraft:red_terracotta
fill 388 280 315 406 280 315 minecraft:red_terracotta
fill 388 280 316 406 280 316 minecraft:terracotta
fill 390 280 287 390 280 293 minecraft:red_terracotta
fill 390 280 294 390 281 296 minecraft:orange_terracotta
fill 390 280 297 390 280 305 minecraft:red_terracotta
fill 391 280 287 391 280 292 minecraft:red_terracotta
setblock 391 280 293 minecraft:orange_terracotta
fill 391 280 297 391 280 298 minecraft:orange_terracotta
fill 391 280 299 391 280 305 minecraft:red_terracotta
fill 392 280 287 392 280 291 minecraft:red_terracotta
setblock 392 280 292 minecraft:orange_terracotta
setblock 392 280 299 minecraft:orange_terracotta
fill 392 280 300 392 280 305 minecraft:red_terracotta
fill 393 280 287 393 280 290 minecraft:red_terracotta
setblock 393 280 291 minecraft:orange_terracotta
fill 393 280 300 398 280 300 minecraft:orange_terracotta
fill 393 280 301 416 280 305 minecraft:red_terracotta
fill 394 280 287 416 280 289 minecraft:red_terracotta
fill 394 280 290 397 280 290 minecraft:orange_terracotta
fill 398 280 290 416 280 290 minecraft:red_terracotta
setblock 398 280 291 minecraft:orange_terracotta
fill 398 280 299 399 280 299 minecraft:orange_terracotta
fill 399 280 291 416 280 291 minecraft:red_terracotta
setblock 399 280 292 minecraft:orange_terracotta
fill 399 280 298 400 280 298 minecraft:orange_terracotta
fill 399 280 300 416 280 300 minecraft:red_terracotta
fill 400 280 292 416 280 292 minecraft:red_terracotta
fill 400 280 293 400 280 297 minecraft:orange_terracotta
fill 400 280 299 416 280 299 minecraft:red_terracotta
fill 401 280 293 416 280 298 minecraft:red_terracotta
fill 407 280 277 407 281 277 minecraft:terracotta
fill 407 280 315 407 281 315 minecraft:terracotta
setblock 409 280 278 minecraft:terracotta
setblock 409 280 314 minecraft:terracotta
fill 410 280 279 410 281 279 minecraft:terracotta
fill 410 280 313 410 281 313 minecraft:terracotta
fill 414 280 283 414 281 283 minecraft:terracotta
fill 414 280 309 414 281 309 minecraft:terracotta
setblock 415 280 284 minecraft:terracotta
setblock 415 280 308 minecraft:terracotta
fill 416 280 286 416 281 286 minecraft:terracotta
fill 416 280 306 416 281 306 minecraft:terracotta
fill 417 280 287 417 280 305 minecraft:terracotta
fill 418 280 276 418 283 316 minecraft:orange_terracotta
fill 377 281 288 377 281 304 minecraft:terracotta
setblock 378 281 287 minecraft:terracotta
fill 378 281 288 389 281 304 minecraft:red_terracotta
setblock 378 281 305 minecraft:terracotta
setblock 379 281 278 minecraft:light[level=12]
setblock 379 281 285 minecraft:terracotta
fill 379 281 286 415 281 287 minecraft:red_terracotta
fill 379 281 305 415 281 306 minecraft:red_terracotta
setblock 379 281 307 minecraft:terracotta
setblock 379 281 313 minecraft:light[level=12]
fill 380 281 284 380 282 284 minecraft:terracotta
fill 380 281 285 414 281 285 minecraft:red_terracotta
fill 380 281 307 414 281 307 minecraft:red_terracotta
fill 380 281 308 380 282 308 minecraft:terracotta
setblock 381 281 282 minecraft:terracotta
fill 381 281 284 413 282 284 minecraft:red_terracotta
fill 381 281 308 413 282 308 minecraft:red_terracotta
setblock 381 281 310 minecraft:terracotta
setblock 382 281 281 minecraft:terracotta
fill 382 281 282 412 281 282 minecraft:red_terracotta
fill 382 281 310 412 281 310 minecraft:red_terracotta
setblock 382 281 311 minecraft:terracotta
setblock 383 281 280 minecraft:terracotta
fill 383 281 281 411 281 281 minecraft:red_terracotta
fill 383 281 311 411 281 311 minecraft:red_terracotta
setblock 383 281 312 minecraft:terracotta
fill 384 281 280 410 281 280 minecraft:red_terracotta
fill 384 281 312 410 281 312 minecraft:red_terracotta
fill 385 281 279 385 282 279 minecraft:terracotta
fill 385 281 313 385 282 313 minecraft:terracotta
setblock 386 281 278 minecraft:terracotta
fill 386 281 279 408 281 279 minecraft:red_terracotta
fill 386 281 313 408 281 313 minecraft:red_terracotta
setblock 386 281 314 minecraft:terracotta
fill 387 281 278 407 281 278 minecraft:red_terracotta
fill 387 281 314 407 281 314 minecraft:red_terracotta
setblock 388 281 277 minecraft:terracotta
setblock 388 281 315 minecraft:terracotta
fill 389 281 276 405 281 276 minecraft:terracotta
fill 389 281 277 405 281 277 minecraft:red_terracotta
fill 389 281 315 405 281 315 minecraft:red_terracotta
fill 389 281 316 405 281 316 minecraft:terracotta
fill 390 281 288 390 281 292 minecraft:red_terracotta
setblock 390 281 293 minecraft:orange_terracotta
fill 390 281 297 390 281 298 minecraft:orange_terracotta
fill 390 281 299 390 281 304 minecraft:red_terracotta
fill 391 281 288 391 281 291 minecraft:red_terracotta
setblock 391 281 292 minecraft:orange_terracotta
setblock 391 281 299 minecraft:orange_terracotta
fill 391 281 300 391 281 304 minecraft:red_terracotta
fill 392 281 288 392 281 290 minecraft:red_terracotta
setblock 392 281 291 minecraft:orange_terracotta
setblock 392 281 300 minecraft:orange_terracotta
fill 392 281 301 392 281 304 minecraft:red_terracotta
fill 393 281 288 394 281 289 minecraft:red_terracotta
fill 393 281 290 394 281 290 minecraft:orange_terracotta
setblock 393 281 292 minecraft:light[level=12]
setblock 393 281 299 minecraft:light[level=12]
fill 393 281 301 398 281 301 minecraft:orange_terracotta
fill 393 281 302 416 281 304 minecraft:red_terracotta
fill 395 281 288 416 281 288 minecraft:red_terracotta
fill 395 281 289 396 281 289 minecraft:orange_terracotta
fill 397 281 289 416 281 289 minecraft:red_terracotta
fill 397 281 290 398 281 290 minecraft:orange_terracotta
fill 399 281 290 416 281 290 minecraft:red_terracotta
fill 399 281 291 400 281 291 minecraft:orange_terracotta
setblock 399 281 300 minecraft:orange_terracotta
fill 399 281 301 416 281 301 minecraft:red_terracotta
fill 400 281 292 401 281 292 minecraft:orange_terracotta
setblock 400 281 299 minecraft:orange_terracotta
fill 400 281 300 416 281 300 minecraft:red_terracotta
fill 401 281 291 416 281 291 minecraft:red_terracotta
fill 401 281 293 401 281 298 minecraft:orange_terracotta
fill 401 281 299 416 281 299 minecraft:red_terracotta
fill 402 281 292 416 281 298 minecraft:red_terracotta
setblock 406 281 277 minecraft:terracotta
setblock 406 281 315 minecraft:terracotta
setblock 408 281 278 minecraft:terracotta
setblock 408 281 314 minecraft:terracotta
fill 409 281 279 409 282 279 minecraft:terracotta
fill 409 281 313 409 282 313 minecraft:terracotta
setblock 411 281 280 minecraft:terracotta
setblock 411 281 312 minecraft:terracotta
setblock 412 281 281 minecraft:terracotta
setblock 412 281 311 minecraft:terracotta
setblock 413 281 282 minecraft:terracotta
setblock 413 281 310 minecraft:terracotta
setblock 414 281 278 minecraft:light[level=12]
fill 414 281 284 414 282 284 minecraft:terracotta
fill 414 281 308 414 282 308 minecraft:terracotta
setblock 414 281 313 minecraft:light[level=12]
setblock 415 281 285 minecraft:terracotta
setblock 415 281 307 minecraft:terracotta
setblock 416 281 287 minecraft:terracotta
setblock 416 281 305 minecraft:terracotta
fill 417 281 288 417 281 304 minecraft:terracotta
fill 377 282 290 377 282 302 minecraft:terracotta
fill 378 282 288 378 282 289 minecraft:terracotta
fill 378 282 290 388 282 302 minecraft:red_terracotta
fill 378 282 303 378 282 304 minecraft:terracotta
fill 379 282 286 379 282 287 minecraft:terracotta
fill 379 282 288 392 282 289 minecraft:red_terracotta
fill 379 282 303 415 282 304 minecraft:red_terracotta
fill 379 282 305 379 282 306 minecraft:terracotta
fill 380 282 285 380 283 285 minecraft:terracotta
fill 380 282 286 414 282 287 minecraft:red_terracotta
fill 380 282 305 414 282 306 minecraft:red_terracotta
fill 380 282 307 380 283 307 minecraft:terracotta
setblock 381 282 283 minecraft:terracotta
fill 381 282 285 413 283 285 minecraft:red_terracotta
fill 381 282 307 413 283 307 minecraft:red_terracotta
setblock 381 282 309 minecraft:terracotta
setblock 382 282 282 minecraft:terracotta
fill 382 282 283 412 282 283 minecraft:red_terracotta
fill 382 282 309 412 282 309 minecraft:red_terracotta
setblock 382 282 310 minecraft:terracotta
setblock 383 282 281 minecraft:terracotta
fill 383 282 282 411 282 282 minecraft:red_terracotta
fill 383 282 310 411 282 310 minecraft:red_terracotta
setblock 383 282 311 minecraft:terracotta
setblock 384 282 280 minecraft:terracotta
fill 384 282 281 410 282 281 minecraft:red_terracotta
fill 384 282 311 410 282 311 minecraft:red_terracotta
setblock 384 282 312 minecraft:terracotta
fill 385 282 280 409 282 280 minecraft:red_terracotta
fill 385 282 312 409 282 312 minecraft:red_terracotta
fill 386 282 279 386 283 279 minecraft:terracotta
fill 386 282 313 386 283 313 minecraft:terracotta
fill 387 282 278 388 282 278 minecraft:terracotta
fill 387 282 279 407 282 279 minecraft:red_terracotta
fill 387 282 313 407 282 313 minecraft:red_terracotta
fill 387 282 314 388 282 314 minecraft:terracotta
fill 389 282 277 390 282 277 minecraft:terracotta
fill 389 282 278 405 282 278 minecraft:red_terracotta
fill 389 282 290 389 282 292 minecraft:red_terracotta
fill 389 282 293 389 282 297 minecraft:yellow_terracotta
fill 389 282 298 389 282 302 minecraft:red_terracotta
fill 389 282 314 405 282 314 minecraft:red_terracotta
fill 389 282 315 390 282 315 minecraft:terracotta
fill 390 282 290 390 282 291 minecraft:red_terracotta
setblock 390 282 292 minecraft:yellow_terracotta
fill 390 282 298 390 282 299 minecraft:yellow_terracotta
fill 390 282 300 390 282 302 minecraft:red_terracotta
schedule function dropper:buildpart/68_10 1t
