fill 508 52 458 509 53 458 minecraft:orange_concrete
fill 509 52 416 510 53 416 minecraft:orange_concrete
fill 510 52 458 511 57 458 minecraft:blackstone
fill 512 52 420 512 57 420 minecraft:blackstone
fill 512 52 421 512 52 422 minecraft:orange_concrete
fill 512 52 423 512 57 423 minecraft:blackstone
fill 512 52 425 512 53 425 minecraft:orange_concrete
fill 512 52 431 512 57 432 minecraft:blackstone
fill 512 52 433 512 53 434 minecraft:orange_concrete
setblock 512 52 442 minecraft:orange_concrete
fill 512 52 443 512 57 444 minecraft:blackstone
fill 512 52 445 512 53 446 minecraft:orange_concrete
fill 512 52 451 512 57 452 minecraft:blackstone
fill 512 52 453 512 52 454 minecraft:orange_concrete
fill 512 52 455 512 57 455 minecraft:blackstone
fill 470 53 420 470 53 421 minecraft:orange_concrete
setblock 470 53 424 minecraft:orange_concrete
fill 470 53 425 470 56 425 minecraft:blackstone
fill 470 53 436 470 56 436 minecraft:blackstone
setblock 470 53 441 minecraft:orange_concrete
setblock 470 53 452 minecraft:orange_concrete
fill 470 53 456 470 56 457 minecraft:blackstone
setblock 481 53 416 minecraft:orange_concrete
fill 482 53 416 482 55 416 minecraft:blackstone
setblock 485 53 458 minecraft:orange_concrete
fill 486 53 416 486 56 416 minecraft:blackstone
setblock 488 53 458 minecraft:orange_concrete
fill 489 53 458 489 56 458 minecraft:blackstone
setblock 496 53 458 minecraft:orange_concrete
fill 497 53 416 497 56 416 minecraft:blackstone
setblock 498 53 416 minecraft:orange_concrete
fill 500 53 458 500 56 458 minecraft:blackstone
fill 501 53 416 502 53 416 minecraft:orange_concrete
fill 512 53 421 512 56 422 minecraft:blackstone
setblock 512 53 426 minecraft:orange_concrete
setblock 512 53 437 minecraft:orange_concrete
fill 512 53 442 512 56 442 minecraft:blackstone
fill 512 53 453 512 56 453 minecraft:blackstone
setblock 512 53 454 minecraft:orange_concrete
setblock 512 53 457 minecraft:orange_concrete
fill 470 54 419 470 55 419 minecraft:orange_concrete
fill 470 54 420 470 59 421 minecraft:blackstone
setblock 470 54 422 minecraft:orange_concrete
fill 470 54 424 470 59 424 minecraft:blackstone
fill 470 54 430 470 55 431 minecraft:orange_concrete
fill 470 54 432 470 59 433 minecraft:blackstone
fill 470 54 441 470 59 441 minecraft:blackstone
fill 470 54 442 470 54 443 minecraft:orange_concrete
fill 470 54 444 470 59 445 minecraft:blackstone
fill 470 54 450 470 55 451 minecraft:orange_concrete
fill 470 54 452 470 59 453 minecraft:blackstone
setblock 470 54 454 minecraft:orange_concrete
fill 471 54 416 472 55 416 minecraft:orange_concrete
fill 471 54 417 473 54 417 minecraft:red_nether_bricks
fill 471 54 419 471 54 421 minecraft:red_nether_bricks
fill 471 54 423 471 54 425 minecraft:red_nether_bricks
fill 471 54 427 471 54 429 minecraft:red_nether_bricks
fill 471 54 431 471 54 433 minecraft:red_nether_bricks
fill 471 54 435 471 54 437 minecraft:red_nether_bricks
fill 471 54 439 471 54 441 minecraft:red_nether_bricks
fill 471 54 443 471 54 445 minecraft:red_nether_bricks
fill 471 54 447 471 54 449 minecraft:red_nether_bricks
fill 471 54 451 471 54 453 minecraft:red_nether_bricks
fill 471 54 455 471 54 457 minecraft:red_nether_bricks
fill 473 54 457 475 54 457 minecraft:red_nether_bricks
fill 474 54 458 475 55 458 minecraft:orange_concrete
fill 475 54 417 477 54 417 minecraft:red_nether_bricks
fill 476 54 458 477 59 458 minecraft:blackstone
fill 477 54 416 478 59 416 minecraft:blackstone
fill 477 54 457 479 54 457 minecraft:red_nether_bricks
fill 479 54 416 480 54 416 minecraft:orange_concrete
fill 479 54 417 481 54 417 minecraft:red_nether_bricks
fill 481 54 416 481 55 416 minecraft:blackstone
fill 481 54 457 483 54 457 minecraft:red_nether_bricks
fill 483 54 417 485 54 417 minecraft:red_nether_bricks
fill 483 54 458 483 55 458 minecraft:orange_concrete
fill 485 54 457 487 54 457 minecraft:red_nether_bricks
fill 485 54 458 485 59 458 minecraft:blackstone
fill 486 54 458 487 54 458 minecraft:orange_concrete
fill 487 54 417 489 54 417 minecraft:red_nether_bricks
fill 488 54 458 488 59 458 minecraft:blackstone
fill 489 54 416 490 59 416 minecraft:blackstone
fill 489 54 457 491 54 457 minecraft:red_nether_bricks
fill 491 54 416 492 55 416 minecraft:orange_concrete
fill 491 54 417 493 54 417 minecraft:red_nether_bricks
fill 493 54 457 495 54 457 minecraft:red_nether_bricks
fill 494 54 458 495 55 458 minecraft:orange_concrete
fill 495 54 417 497 54 417 minecraft:red_nether_bricks
fill 496 54 458 497 59 458 minecraft:blackstone
fill 497 54 457 499 54 457 minecraft:red_nether_bricks
fill 498 54 416 498 59 416 minecraft:blackstone
fill 499 54 416 500 54 416 minecraft:orange_concrete
fill 499 54 417 501 54 417 minecraft:red_nether_bricks
fill 501 54 416 502 55 416 minecraft:blackstone
fill 501 54 457 503 54 457 minecraft:red_nether_bricks
fill 503 54 416 503 55 416 minecraft:orange_concrete
fill 503 54 417 505 54 417 minecraft:red_nether_bricks
fill 505 54 457 507 54 457 minecraft:red_nether_bricks
fill 506 54 458 507 54 458 minecraft:orange_concrete
fill 507 54 417 509 54 417 minecraft:red_nether_bricks
fill 508 54 458 509 59 458 minecraft:blackstone
fill 509 54 416 510 59 416 minecraft:blackstone
fill 509 54 457 511 54 457 minecraft:red_nether_bricks
fill 511 54 416 512 55 416 minecraft:orange_concrete
fill 511 54 417 511 54 419 minecraft:red_nether_bricks
fill 511 54 421 511 54 423 minecraft:red_nether_bricks
fill 511 54 425 511 54 427 minecraft:red_nether_bricks
fill 511 54 429 511 54 431 minecraft:red_nether_bricks
fill 511 54 433 511 54 435 minecraft:red_nether_bricks
fill 511 54 437 511 54 439 minecraft:red_nether_bricks
fill 511 54 441 511 54 443 minecraft:red_nether_bricks
fill 511 54 445 511 54 447 minecraft:red_nether_bricks
fill 511 54 449 511 54 451 minecraft:red_nether_bricks
fill 511 54 453 511 54 455 minecraft:red_nether_bricks
setblock 512 54 424 minecraft:orange_concrete
fill 512 54 425 512 59 426 minecraft:blackstone
fill 512 54 427 512 55 428 minecraft:orange_concrete
fill 512 54 433 512 59 434 minecraft:blackstone
fill 512 54 435 512 54 436 minecraft:orange_concrete
fill 512 54 437 512 59 437 minecraft:blackstone
fill 512 54 445 512 59 446 minecraft:blackstone
fill 512 54 447 512 55 448 minecraft:orange_concrete
fill 512 54 454 512 59 454 minecraft:blackstone
setblock 512 54 456 minecraft:orange_concrete
fill 512 54 457 512 59 457 minecraft:blackstone
setblock 470 55 418 minecraft:orange_concrete
fill 470 55 422 470 58 422 minecraft:blackstone
fill 470 55 438 470 55 439 minecraft:orange_concrete
setblock 470 55 442 minecraft:orange_concrete
fill 470 55 443 470 58 443 minecraft:blackstone
fill 470 55 454 470 58 454 minecraft:blackstone
setblock 471 55 458 minecraft:orange_concrete
fill 479 55 416 479 58 416 minecraft:blackstone
setblock 480 55 416 minecraft:orange_concrete
setblock 482 55 458 minecraft:orange_concrete
fill 483 55 416 484 55 416 minecraft:orange_concrete
fill 486 55 458 487 58 458 minecraft:blackstone
fill 499 55 416 500 57 416 minecraft:blackstone
setblock 503 55 458 minecraft:orange_concrete
setblock 504 55 416 minecraft:orange_concrete
setblock 506 55 458 minecraft:orange_concrete
fill 507 55 458 507 58 458 minecraft:blackstone
setblock 512 55 419 minecraft:orange_concrete
fill 512 55 424 512 58 424 minecraft:blackstone
fill 512 55 435 512 58 435 minecraft:blackstone
setblock 512 55 436 minecraft:orange_concrete
fill 512 55 439 512 55 440 minecraft:orange_concrete
fill 512 55 456 512 58 456 minecraft:blackstone
fill 470 56 416 470 57 417 minecraft:orange_concrete
fill 470 56 418 470 60 419 minecraft:blackstone
fill 470 56 428 470 56 429 minecraft:orange_concrete
fill 470 56 430 470 59 431 minecraft:blackstone
fill 470 56 437 470 57 437 minecraft:orange_concrete
fill 470 56 438 470 60 439 minecraft:blackstone
setblock 470 56 440 minecraft:orange_concrete
fill 470 56 442 470 61 442 minecraft:blackstone
fill 470 56 448 470 57 449 minecraft:orange_concrete
fill 470 56 450 470 61 451 minecraft:blackstone
fill 471 56 416 472 61 416 minecraft:blackstone
fill 471 56 458 471 61 458 minecraft:blackstone
fill 472 56 458 473 56 458 minecraft:orange_concrete
fill 473 56 416 474 57 416 minecraft:orange_concrete
setblock 473 56 419 minecraft:light[level=14]
setblock 473 56 427 minecraft:light[level=14]
setblock 473 56 435 minecraft:light[level=14]
setblock 473 56 443 minecraft:light[level=14]
setblock 473 56 451 minecraft:light[level=14]
fill 474 56 458 475 61 458 minecraft:blackstone
fill 480 56 416 480 61 416 minecraft:blackstone
fill 480 56 458 481 57 458 minecraft:orange_concrete
fill 481 56 416 482 56 416 minecraft:orange_concrete
setblock 481 56 419 minecraft:light[level=14]
setblock 481 56 427 minecraft:light[level=14]
setblock 481 56 435 minecraft:light[level=14]
setblock 481 56 443 minecraft:light[level=14]
setblock 481 56 451 minecraft:light[level=14]
fill 482 56 458 483 61 458 minecraft:blackstone
fill 483 56 416 484 57 416 minecraft:blackstone
setblock 484 56 458 minecraft:orange_concrete
fill 485 56 416 485 57 416 minecraft:orange_concrete
setblock 489 56 419 minecraft:light[level=14]
setblock 489 56 427 minecraft:light[level=14]
setblock 489 56 435 minecraft:light[level=14]
setblock 489 56 443 minecraft:light[level=14]
setblock 489 56 451 minecraft:light[level=14]
fill 491 56 416 492 61 416 minecraft:blackstone
fill 492 56 458 493 57 458 minecraft:orange_concrete
fill 493 56 416 494 57 416 minecraft:orange_concrete
fill 494 56 458 495 61 458 minecraft:blackstone
setblock 497 56 419 minecraft:light[level=14]
setblock 497 56 427 minecraft:light[level=14]
setblock 497 56 435 minecraft:light[level=14]
setblock 497 56 443 minecraft:light[level=14]
setblock 497 56 451 minecraft:light[level=14]
fill 501 56 416 501 59 416 minecraft:blackstone
fill 501 56 458 501 57 458 minecraft:orange_concrete
setblock 502 56 416 minecraft:orange_concrete
fill 503 56 416 504 61 416 minecraft:blackstone
fill 503 56 458 503 61 458 minecraft:blackstone
fill 504 56 458 505 56 458 minecraft:orange_concrete
fill 505 56 416 506 57 416 minecraft:orange_concrete
setblock 505 56 419 minecraft:light[level=14]
setblock 505 56 427 minecraft:light[level=14]
setblock 505 56 435 minecraft:light[level=14]
setblock 505 56 443 minecraft:light[level=14]
setblock 505 56 451 minecraft:light[level=14]
fill 506 56 458 506 61 458 minecraft:blackstone
fill 511 56 416 512 58 416 minecraft:blackstone
fill 512 56 417 512 56 418 minecraft:orange_concrete
fill 512 56 419 512 61 419 minecraft:blackstone
fill 512 56 427 512 60 428 minecraft:blackstone
fill 512 56 429 512 57 430 minecraft:orange_concrete
fill 512 56 436 512 61 436 minecraft:blackstone
setblock 512 56 438 minecraft:orange_concrete
fill 512 56 439 512 59 440 minecraft:blackstone
fill 512 56 441 512 57 441 minecraft:orange_concrete
fill 512 56 447 512 60 448 minecraft:blackstone
fill 512 56 449 512 56 450 minecraft:orange_concrete
fill 512 56 458 512 57 458 minecraft:orange_concrete
setblock 470 57 425 minecraft:orange_concrete
setblock 470 57 428 minecraft:orange_concrete
fill 470 57 429 470 60 429 minecraft:blackstone
setblock 470 57 436 minecraft:orange_concrete
fill 470 57 440 470 60 440 minecraft:blackstone
fill 470 57 456 470 57 457 minecraft:orange_concrete
setblock 472 57 458 minecraft:orange_concrete
fill 473 57 458 473 60 458 minecraft:blackstone
fill 481 57 416 482 59 416 minecraft:blackstone
fill 484 57 458 484 60 458 minecraft:blackstone
setblock 486 57 416 minecraft:orange_concrete
setblock 489 57 458 minecraft:orange_concrete
setblock 497 57 416 minecraft:orange_concrete
setblock 500 57 458 minecraft:orange_concrete
fill 502 57 416 502 59 416 minecraft:blackstone
fill 504 57 458 505 60 458 minecraft:blackstone
fill 512 57 417 512 60 417 minecraft:blackstone
setblock 512 57 418 minecraft:orange_concrete
fill 512 57 421 512 57 422 minecraft:orange_concrete
fill 512 57 438 512 60 438 minecraft:blackstone
setblock 512 57 442 minecraft:orange_concrete
fill 512 57 449 512 60 449 minecraft:blackstone
setblock 512 57 450 minecraft:orange_concrete
setblock 512 57 453 minecraft:orange_concrete
fill 470 58 416 470 60 417 minecraft:blackstone
fill 470 58 423 470 59 423 minecraft:orange_concrete
fill 470 58 425 470 63 425 minecraft:blackstone
fill 470 58 426 470 58 427 minecraft:orange_concrete
fill 470 58 428 470 63 428 minecraft:blackstone
fill 470 58 434 470 59 435 minecraft:orange_concrete
fill 470 58 436 470 59 437 minecraft:blackstone
fill 470 58 446 470 58 447 minecraft:orange_concrete
fill 470 58 448 470 60 449 minecraft:blackstone
fill 470 58 455 470 59 455 minecraft:orange_concrete
fill 470 58 456 470 60 457 minecraft:blackstone
setblock 470 58 458 minecraft:orange_concrete
fill 472 58 458 472 63 458 minecraft:blackstone
fill 473 58 416 474 61 416 minecraft:blackstone
fill 475 58 416 476 58 416 minecraft:orange_concrete
fill 478 58 458 479 59 458 minecraft:orange_concrete
fill 480 58 458 481 63 458 minecraft:blackstone
fill 483 58 416 483 61 416 minecraft:blackstone
setblock 484 58 416 minecraft:orange_concrete
fill 485 58 416 486 59 416 minecraft:blackstone
fill 487 58 416 488 59 416 minecraft:orange_concrete
fill 489 58 458 489 63 458 minecraft:blackstone
fill 490 58 458 491 58 458 minecraft:orange_concrete
fill 492 58 458 493 63 458 minecraft:blackstone
fill 493 58 416 494 59 416 minecraft:blackstone
fill 495 58 416 496 58 416 minecraft:orange_concrete
fill 497 58 416 497 63 416 minecraft:blackstone
fill 498 58 458 499 59 458 minecraft:orange_concrete
fill 499 58 416 499 59 416 minecraft:orange_concrete
setblock 500 58 416 minecraft:blackstone
fill 500 58 458 501 63 458 minecraft:blackstone
setblock 502 58 458 minecraft:orange_concrete
fill 505 58 416 506 63 416 minecraft:blackstone
fill 507 58 416 508 59 416 minecraft:orange_concrete
fill 510 58 458 511 59 458 minecraft:orange_concrete
fill 512 58 418 512 60 418 minecraft:blackstone
setblock 512 58 420 minecraft:orange_concrete
fill 512 58 421 512 63 422 minecraft:blackstone
fill 512 58 423 512 59 423 minecraft:orange_concrete
fill 512 58 429 512 63 430 minecraft:blackstone
fill 512 58 431 512 58 432 minecraft:orange_concrete
fill 512 58 441 512 63 442 minecraft:blackstone
fill 512 58 443 512 59 444 minecraft:orange_concrete
fill 512 58 450 512 63 450 minecraft:blackstone
fill 512 58 451 512 58 452 minecraft:orange_concrete
fill 512 58 453 512 63 453 minecraft:blackstone
fill 512 58 455 512 59 455 minecraft:orange_concrete
fill 512 58 458 512 60 458 minecraft:blackstone
setblock 470 59 422 minecraft:orange_concrete
fill 470 59 426 470 62 427 minecraft:blackstone
setblock 470 59 443 minecraft:orange_concrete
setblock 470 59 446 minecraft:orange_concrete
fill 470 59 447 470 62 447 minecraft:blackstone
setblock 470 59 454 minecraft:orange_concrete
fill 470 59 458 470 62 458 minecraft:blackstone
fill 475 59 416 475 62 416 minecraft:blackstone
setblock 476 59 416 minecraft:orange_concrete
setblock 479 59 416 minecraft:orange_concrete
fill 484 59 416 484 60 416 minecraft:blackstone
fill 486 59 458 487 59 458 minecraft:orange_concrete
setblock 490 59 458 minecraft:orange_concrete
fill 491 59 458 491 61 458 minecraft:blackstone
fill 495 59 416 495 62 416 minecraft:blackstone
setblock 496 59 416 minecraft:orange_concrete
setblock 500 59 416 minecraft:orange_concrete
setblock 502 59 458 minecraft:blackstone
setblock 507 59 458 minecraft:orange_concrete
setblock 511 59 416 minecraft:orange_concrete
fill 512 59 416 512 61 416 minecraft:blackstone
setblock 512 59 420 minecraft:blackstone
setblock 512 59 424 minecraft:orange_concrete
fill 512 59 431 512 62 431 minecraft:blackstone
setblock 512 59 432 minecraft:orange_concrete
setblock 512 59 435 minecraft:orange_concrete
fill 512 59 451 512 62 452 minecraft:blackstone
setblock 512 59 456 minecraft:orange_concrete
fill 470 60 420 470 61 421 minecraft:orange_concrete
fill 470 60 422 470 63 423 minecraft:blackstone
setblock 470 60 424 minecraft:orange_concrete
fill 470 60 430 470 61 430 minecraft:blackstone
fill 470 60 431 471 60 431 minecraft:red_nether_bricks
fill 470 60 432 470 61 433 minecraft:orange_concrete
fill 470 60 434 470 61 436 minecraft:blackstone
fill 470 60 437 471 60 437 minecraft:red_nether_bricks
fill 470 60 441 470 61 441 minecraft:orange_concrete
fill 470 60 443 471 60 443 minecraft:red_nether_bricks
fill 470 60 444 470 60 445 minecraft:orange_concrete
setblock 470 60 446 minecraft:red_nether_bricks
fill 470 60 452 470 61 453 minecraft:orange_concrete
fill 470 60 454 470 63 455 minecraft:blackstone
fill 471 60 417 473 60 417 minecraft:red_nether_bricks
fill 471 60 419 471 60 421 minecraft:red_nether_bricks
fill 471 60 423 471 60 425 minecraft:red_nether_bricks
fill 471 60 427 471 60 429 minecraft:red_nether_bricks
fill 471 60 432 471 60 433 minecraft:red_nether_bricks
fill 471 60 435 471 60 436 minecraft:red_nether_bricks
fill 471 60 439 471 60 441 minecraft:red_nether_bricks
fill 471 60 444 471 60 445 minecraft:red_nether_bricks
fill 471 60 447 471 60 449 minecraft:red_nether_bricks
fill 471 60 451 471 60 453 minecraft:red_nether_bricks
fill 471 60 455 471 60 457 minecraft:red_nether_bricks
fill 473 60 457 475 60 457 minecraft:red_nether_bricks
fill 475 60 417 477 60 417 minecraft:red_nether_bricks
fill 476 60 416 476 64 416 minecraft:blackstone
fill 476 60 458 477 60 458 minecraft:orange_concrete
fill 477 60 416 478 60 416 minecraft:orange_concrete
fill 477 60 457 479 60 457 minecraft:red_nether_bricks
fill 478 60 458 479 60 458 minecraft:blackstone
fill 479 60 416 479 63 416 minecraft:blackstone
fill 479 60 417 481 60 417 minecraft:red_nether_bricks
fill 481 60 416 481 61 416 minecraft:orange_concrete
fill 481 60 457 483 60 457 minecraft:red_nether_bricks
setblock 482 60 416 minecraft:blackstone
fill 483 60 417 485 60 417 minecraft:red_nether_bricks
fill 485 60 416 485 63 416 minecraft:blackstone
fill 485 60 457 487 60 457 minecraft:red_nether_bricks
fill 485 60 458 485 61 458 minecraft:orange_concrete
setblock 486 60 416 minecraft:red_nether_bricks
fill 486 60 458 487 63 458 minecraft:blackstone
fill 487 60 416 488 63 416 minecraft:blackstone
fill 487 60 417 489 60 417 minecraft:red_nether_bricks
setblock 488 60 458 minecraft:orange_concrete
fill 489 60 416 490 61 416 minecraft:orange_concrete
fill 489 60 457 491 60 457 minecraft:red_nether_bricks
setblock 490 60 458 minecraft:blackstone
fill 491 60 417 493 60 417 minecraft:red_nether_bricks
setblock 493 60 416 minecraft:blackstone
fill 493 60 457 495 60 457 minecraft:red_nether_bricks
setblock 494 60 416 minecraft:red_nether_bricks
fill 495 60 417 497 60 417 minecraft:red_nether_bricks
fill 496 60 416 496 62 416 minecraft:blackstone
fill 496 60 458 497 61 458 minecraft:orange_concrete
fill 497 60 457 499 60 457 minecraft:red_nether_bricks
setblock 498 60 416 minecraft:orange_concrete
fill 498 60 458 499 63 458 minecraft:blackstone
fill 499 60 416 499 63 416 minecraft:blackstone
fill 499 60 417 501 60 417 minecraft:red_nether_bricks
setblock 500 60 416 minecraft:red_nether_bricks
fill 501 60 416 502 61 416 minecraft:orange_concrete
fill 501 60 457 503 60 457 minecraft:red_nether_bricks
fill 502 60 458 502 61 458 minecraft:red_nether_bricks
fill 503 60 417 505 60 417 minecraft:red_nether_bricks
fill 505 60 457 507 60 457 minecraft:red_nether_bricks
fill 507 60 416 508 63 416 minecraft:blackstone
fill 507 60 417 509 60 417 minecraft:red_nether_bricks
setblock 507 60 458 minecraft:red_nether_bricks
fill 508 60 458 509 60 458 minecraft:orange_concrete
fill 509 60 416 510 60 416 minecraft:orange_concrete
fill 509 60 457 511 60 457 minecraft:red_nether_bricks
fill 510 60 458 511 63 458 minecraft:blackstone
fill 511 60 416 511 61 416 minecraft:blackstone
fill 511 60 417 511 60 419 minecraft:red_nether_bricks
fill 511 60 421 511 60 423 minecraft:red_nether_bricks
fill 511 60 425 511 60 427 minecraft:red_nether_bricks
fill 511 60 429 511 60 431 minecraft:red_nether_bricks
fill 511 60 433 511 60 435 minecraft:red_nether_bricks
fill 511 60 437 511 60 439 minecraft:red_nether_bricks
fill 511 60 441 511 60 443 minecraft:red_nether_bricks
fill 511 60 445 511 60 447 minecraft:red_nether_bricks
fill 511 60 449 511 60 451 minecraft:red_nether_bricks
fill 511 60 453 511 60 455 minecraft:red_nether_bricks
setblock 512 60 420 minecraft:red_nether_bricks
fill 512 60 423 512 63 424 minecraft:blackstone
fill 512 60 425 512 61 426 minecraft:orange_concrete
fill 512 60 432 512 63 432 minecraft:blackstone
fill 512 60 433 512 60 434 minecraft:orange_concrete
fill 512 60 435 512 63 435 minecraft:blackstone
fill 512 60 437 512 61 437 minecraft:orange_concrete
fill 512 60 439 512 61 439 minecraft:blackstone
setblock 512 60 440 minecraft:red_nether_bricks
fill 512 60 443 512 63 444 minecraft:blackstone
fill 512 60 445 512 61 446 minecraft:orange_concrete
setblock 512 60 454 minecraft:orange_concrete
fill 512 60 455 512 60 456 minecraft:red_nether_bricks
fill 512 60 457 512 61 457 minecraft:orange_concrete
fill 470 61 416 470 61 417 minecraft:red_nether_bricks
setblock 470 61 418 minecraft:blackstone
setblock 470 61 419 minecraft:red_nether_bricks
fill 470 61 424 470 63 424 minecraft:blackstone
setblock 470 61 429 minecraft:orange_concrete
setblock 470 61 431 minecraft:blackstone
fill 470 61 437 470 61 438 minecraft:blackstone
setblock 470 61 439 minecraft:red_nether_bricks
setblock 470 61 440 minecraft:orange_concrete
fill 470 61 443 470 63 446 minecraft:blackstone
setblock 470 61 448 minecraft:blackstone
setblock 470 61 449 minecraft:red_nether_bricks
fill 470 61 456 470 62 456 minecraft:red_nether_bricks
fill 470 61 457 470 63 457 minecraft:blackstone
setblock 473 61 458 minecraft:orange_concrete
setblock 476 61 458 minecraft:orange_concrete
fill 477 61 416 478 61 416 minecraft:blackstone
fill 477 61 458 478 61 458 minecraft:blackstone
setblock 479 61 458 minecraft:red_nether_bricks
setblock 482 61 416 minecraft:orange_concrete
setblock 484 61 416 minecraft:red_nether_bricks
setblock 484 61 458 minecraft:orange_concrete
fill 486 61 416 486 63 416 minecraft:blackstone
fill 488 61 458 488 63 458 minecraft:blackstone
setblock 490 61 458 minecraft:red_nether_bricks
setblock 493 61 416 minecraft:orange_concrete
fill 494 61 416 494 63 416 minecraft:blackstone
fill 498 61 416 498 63 416 minecraft:blackstone
fill 500 61 416 500 63 416 minecraft:blackstone
fill 504 61 458 505 61 458 minecraft:orange_concrete
fill 507 61 458 507 63 458 minecraft:blackstone
setblock 508 61 458 minecraft:orange_concrete
fill 509 61 416 509 63 416 minecraft:blackstone
fill 509 61 458 509 63 458 minecraft:blackstone
setblock 510 61 416 minecraft:orange_concrete
fill 512 61 417 512 61 418 minecraft:orange_concrete
fill 512 61 420 512 62 420 minecraft:blackstone
setblock 512 61 427 minecraft:blackstone
setblock 512 61 428 minecraft:red_nether_bricks
setblock 512 61 433 minecraft:red_nether_bricks
fill 512 61 434 512 63 434 minecraft:blackstone
setblock 512 61 438 minecraft:orange_concrete
setblock 512 61 440 minecraft:blackstone
fill 512 61 447 512 61 448 minecraft:red_nether_bricks
setblock 512 61 449 minecraft:orange_concrete
fill 512 61 454 512 63 456 minecraft:blackstone
setblock 512 61 458 minecraft:red_nether_bricks
fill 470 62 416 470 63 417 minecraft:blackstone
fill 470 62 418 470 63 419 minecraft:orange_concrete
fill 470 62 420 470 63 421 minecraft:blackstone
fill 470 62 429 470 63 429 minecraft:blackstone
fill 470 62 430 470 62 431 minecraft:orange_concrete
fill 470 62 432 470 63 434 minecraft:blackstone
setblock 470 62 435 minecraft:red_nether_bricks
fill 470 62 436 470 63 437 minecraft:blackstone
fill 470 62 438 470 63 439 minecraft:orange_concrete
fill 470 62 440 470 63 441 minecraft:blackstone
setblock 470 62 442 minecraft:orange_concrete
setblock 470 62 448 minecraft:red_nether_bricks
fill 470 62 449 470 63 449 minecraft:blackstone
fill 470 62 450 470 63 451 minecraft:orange_concrete
setblock 470 62 452 minecraft:red_nether_bricks
fill 470 62 453 470 63 453 minecraft:blackstone
fill 471 62 416 472 63 416 minecraft:orange_concrete
fill 471 62 458 471 63 458 minecraft:orange_concrete
fill 473 62 416 473 63 416 minecraft:blackstone
fill 473 62 458 473 63 458 minecraft:blackstone
setblock 474 62 416 minecraft:red_nether_bricks
fill 474 62 458 475 62 458 minecraft:orange_concrete
fill 476 62 458 477 63 458 minecraft:blackstone
fill 477 62 416 478 62 416 minecraft:red_nether_bricks
setblock 478 62 458 minecraft:red_nether_bricks
fill 479 62 458 479 63 458 minecraft:blackstone
setblock 480 62 416 minecraft:orange_concrete
fill 481 62 416 481 63 416 minecraft:blackstone
setblock 482 62 416 minecraft:red_nether_bricks
fill 482 62 458 483 63 458 minecraft:orange_concrete
fill 483 62 416 484 63 416 minecraft:orange_concrete
fill 484 62 458 485 63 458 minecraft:blackstone
fill 489 62 416 490 63 416 minecraft:blackstone
fill 490 62 458 490 64 458 minecraft:blackstone
fill 491 62 416 492 62 416 minecraft:orange_concrete
setblock 491 62 458 minecraft:red_nether_bricks
fill 493 62 416 493 63 416 minecraft:blackstone
fill 494 62 458 495 62 458 minecraft:orange_concrete
fill 496 62 458 497 63 458 minecraft:blackstone
fill 501 62 416 502 63 416 minecraft:blackstone
setblock 502 62 458 minecraft:blackstone
fill 503 62 416 504 63 416 minecraft:orange_concrete
fill 503 62 458 503 63 458 minecraft:orange_concrete
fill 504 62 458 505 63 458 minecraft:blackstone
setblock 506 62 458 minecraft:orange_concrete
setblock 508 62 458 minecraft:red_nether_bricks
fill 510 62 416 510 63 416 minecraft:blackstone
fill 511 62 416 512 62 416 minecraft:orange_concrete
fill 512 62 417 512 63 417 minecraft:blackstone
setblock 512 62 418 minecraft:red_nether_bricks
fill 512 62 419 512 63 419 minecraft:orange_concrete
fill 512 62 425 512 63 426 minecraft:blackstone
fill 512 62 427 512 63 428 minecraft:orange_concrete
fill 512 62 433 512 63 433 minecraft:blackstone
setblock 512 62 436 minecraft:orange_concrete
fill 512 62 437 512 63 438 minecraft:blackstone
fill 512 62 439 512 63 440 minecraft:orange_concrete
fill 512 62 445 512 63 446 minecraft:blackstone
fill 512 62 447 512 62 448 minecraft:orange_concrete
fill 512 62 449 512 63 449 minecraft:blackstone
fill 512 62 457 512 63 458 minecraft:blackstone
fill 470 63 426 470 63 427 minecraft:orange_concrete
setblock 470 63 430 minecraft:orange_concrete
setblock 470 63 431 minecraft:blackstone
fill 470 63 435 470 64 435 minecraft:blackstone
setblock 470 63 442 minecraft:blackstone
setblock 470 63 447 minecraft:orange_concrete
setblock 470 63 448 minecraft:blackstone
setblock 470 63 452 minecraft:blackstone
setblock 470 63 456 minecraft:blackstone
setblock 470 63 458 minecraft:orange_concrete
setblock 474 63 416 minecraft:blackstone
fill 474 63 458 475 63 458 minecraft:blackstone
setblock 475 63 416 minecraft:orange_concrete
fill 476 63 429 479 126 432 minecraft:red_nether_bricks
fill 477 63 416 478 63 416 minecraft:blackstone
fill 477 63 428 478 126 428 minecraft:red_nether_bricks
setblock 478 63 458 minecraft:blackstone
setblock 480 63 416 minecraft:blackstone
fill 480 63 430 480 126 431 minecraft:red_nether_bricks
setblock 482 63 416 minecraft:blackstone
fill 491 63 416 491 64 416 minecraft:blackstone
setblock 491 63 458 minecraft:orange_concrete
setblock 492 63 416 minecraft:orange_concrete
setblock 494 63 458 minecraft:orange_concrete
fill 495 63 416 496 63 416 minecraft:orange_concrete
setblock 495 63 458 minecraft:blackstone
setblock 502 63 458 minecraft:orange_concrete
fill 506 63 458 506 64 458 minecraft:blackstone
setblock 508 63 458 minecraft:blackstone
fill 511 63 416 512 63 416 minecraft:blackstone
setblock 512 63 418 minecraft:blackstone
setblock 512 63 420 minecraft:orange_concrete
setblock 512 63 431 minecraft:orange_concrete
setblock 512 63 436 minecraft:blackstone
setblock 512 63 447 minecraft:blackstone
setblock 512 63 448 minecraft:orange_concrete
fill 512 63 451 512 63 452 minecraft:orange_concrete
fill 470 64 416 470 64 417 minecraft:orange_concrete
fill 470 64 418 470 64 422 minecraft:red_nether_bricks
setblock 470 64 423 minecraft:blackstone
setblock 470 64 424 minecraft:red_nether_bricks
fill 470 64 425 470 65 425 minecraft:orange_concrete
setblock 470 64 426 minecraft:blackstone
fill 470 64 427 470 69 427 minecraft:red_nether_bricks
setblock 470 64 428 minecraft:orange_concrete
fill 470 64 429 470 64 433 minecraft:red_nether_bricks
setblock 470 64 434 minecraft:blackstone
fill 470 64 436 470 65 437 minecraft:orange_concrete
fill 470 64 438 470 64 443 minecraft:red_nether_bricks
setblock 470 64 444 minecraft:blackstone
fill 470 64 445 470 64 447 minecraft:red_nether_bricks
fill 470 64 448 470 64 449 minecraft:orange_concrete
fill 470 64 450 470 64 455 minecraft:red_nether_bricks
fill 470 64 456 470 65 457 minecraft:orange_concrete
fill 470 64 458 471 69 458 minecraft:red_nether_bricks
fill 471 64 416 472 69 416 minecraft:red_nether_bricks
setblock 472 64 458 minecraft:orange_concrete
fill 473 64 416 474 64 416 minecraft:orange_concrete
setblock 473 64 419 minecraft:light[level=14]
setblock 473 64 427 minecraft:light[level=14]
setblock 473 64 435 minecraft:light[level=14]
setblock 473 64 443 minecraft:light[level=14]
setblock 473 64 451 minecraft:light[level=14]
fill 473 64 458 479 64 458 minecraft:red_nether_bricks
setblock 475 64 416 minecraft:red_nether_bricks
fill 475 64 429 475 65 432 minecraft:blackstone
fill 476 64 428 476 65 428 minecraft:blackstone
fill 476 64 433 480 65 433 minecraft:blackstone
setblock 477 64 416 minecraft:blackstone
fill 477 64 427 478 65 427 minecraft:blackstone
fill 478 64 416 484 64 416 minecraft:red_nether_bricks
fill 479 64 428 480 65 428 minecraft:blackstone
fill 480 64 429 480 65 429 minecraft:blackstone
fill 480 64 432 480 65 432 minecraft:blackstone
fill 480 64 458 481 65 458 minecraft:orange_concrete
setblock 481 64 419 minecraft:light[level=14]
setblock 481 64 427 minecraft:light[level=14]
fill 481 64 430 481 65 431 minecraft:blackstone
setblock 481 64 435 minecraft:light[level=14]
setblock 481 64 443 minecraft:light[level=14]
setblock 481 64 451 minecraft:light[level=14]
fill 482 64 458 482 69 458 minecraft:red_nether_bricks
fill 483 64 458 484 64 458 minecraft:blackstone
fill 485 64 416 486 65 416 minecraft:orange_concrete
fill 485 64 458 488 64 458 minecraft:red_nether_bricks
fill 487 64 416 490 64 416 minecraft:red_nether_bricks
setblock 489 64 419 minecraft:light[level=14]
setblock 489 64 427 minecraft:light[level=14]
setblock 489 64 435 minecraft:light[level=14]
setblock 489 64 443 minecraft:light[level=14]
setblock 489 64 451 minecraft:light[level=14]
fill 489 64 458 489 65 458 minecraft:orange_concrete
setblock 491 64 458 minecraft:red_nether_bricks
fill 492 64 416 492 69 416 minecraft:red_nether_bricks
fill 492 64 458 493 64 458 minecraft:orange_concrete
fill 493 64 416 494 64 416 minecraft:orange_concrete
fill 494 64 458 498 65 458 minecraft:red_nether_bricks
fill 495 64 416 496 65 416 minecraft:red_nether_bricks
fill 497 64 416 497 65 416 minecraft:orange_concrete
setblock 497 64 419 minecraft:light[level=14]
setblock 497 64 427 minecraft:light[level=14]
setblock 497 64 435 minecraft:light[level=14]
setblock 497 64 443 minecraft:light[level=14]
setblock 497 64 451 minecraft:light[level=14]
fill 498 64 416 504 64 416 minecraft:red_nether_bricks
setblock 499 64 458 minecraft:blackstone
fill 500 64 458 501 65 458 minecraft:orange_concrete
setblock 502 64 458 minecraft:blackstone
fill 503 64 458 505 64 458 minecraft:red_nether_bricks
fill 505 64 416 506 65 416 minecraft:orange_concrete
setblock 505 64 419 minecraft:light[level=14]
setblock 505 64 427 minecraft:light[level=14]
setblock 505 64 435 minecraft:light[level=14]
setblock 505 64 443 minecraft:light[level=14]
setblock 505 64 451 minecraft:light[level=14]
fill 507 64 416 512 64 416 minecraft:red_nether_bricks
fill 507 64 458 511 64 458 minecraft:red_nether_bricks
fill 512 64 417 512 67 417 minecraft:red_nether_bricks
setblock 512 64 418 minecraft:orange_concrete
fill 512 64 419 512 69 420 minecraft:red_nether_bricks
fill 512 64 421 512 65 422 minecraft:orange_concrete
fill 512 64 423 512 64 428 minecraft:red_nether_bricks
fill 512 64 429 512 64 430 minecraft:orange_concrete
fill 512 64 431 512 64 437 minecraft:red_nether_bricks
fill 512 64 438 512 65 438 minecraft:blackstone
fill 512 64 439 512 69 440 minecraft:red_nether_bricks
fill 512 64 441 512 65 442 minecraft:orange_concrete
fill 512 64 443 512 65 449 minecraft:red_nether_bricks
setblock 512 64 450 minecraft:orange_concrete
fill 512 64 451 512 65 452 minecraft:red_nether_bricks
fill 512 64 453 512 65 453 minecraft:orange_concrete
fill 512 64 454 512 64 455 minecraft:red_nether_bricks
fill 512 64 456 512 65 456 minecraft:blackstone
fill 512 64 457 512 67 457 minecraft:red_nether_bricks
fill 512 64 458 512 65 458 minecraft:orange_concrete
setblock 470 65 416 minecraft:orange_concrete
setblock 470 65 417 minecraft:blackstone
setblock 470 65 418 minecraft:red_nether_bricks
setblock 470 65 419 minecraft:blackstone
fill 470 65 420 470 67 420 minecraft:red_nether_bricks
setblock 470 65 421 minecraft:blackstone
fill 470 65 422 470 65 423 minecraft:red_nether_bricks
setblock 470 65 424 minecraft:orange_concrete
fill 470 65 426 470 69 426 minecraft:red_nether_bricks
fill 470 65 428 470 68 428 minecraft:red_nether_bricks
setblock 470 65 429 minecraft:blackstone
fill 470 65 430 470 65 435 minecraft:red_nether_bricks
fill 470 65 438 470 69 439 minecraft:red_nether_bricks
setblock 470 65 440 minecraft:blackstone
fill 470 65 441 470 65 443 minecraft:red_nether_bricks
fill 470 65 444 470 65 445 minecraft:orange_concrete
fill 470 65 446 470 65 447 minecraft:red_nether_bricks
setblock 470 65 448 minecraft:orange_concrete
fill 470 65 449 470 68 449 minecraft:red_nether_bricks
fill 470 65 450 470 65 451 minecraft:blackstone
fill 470 65 452 470 67 452 minecraft:red_nether_bricks
setblock 470 65 453 minecraft:blackstone
fill 470 65 454 470 65 455 minecraft:red_nether_bricks
setblock 472 65 458 minecraft:blackstone
fill 473 65 416 473 68 416 minecraft:red_nether_bricks
fill 473 65 458 475 66 458 minecraft:red_nether_bricks
setblock 474 65 416 minecraft:orange_concrete
fill 474 65 428 474 65 432 minecraft:blackstone
setblock 475 65 416 minecraft:blackstone
fill 475 65 427 475 65 428 minecraft:blackstone
setblock 475 65 433 minecraft:blackstone
setblock 476 65 416 minecraft:red_nether_bricks
setblock 476 65 427 minecraft:blackstone
fill 476 65 434 480 65 434 minecraft:blackstone
setblock 476 65 458 minecraft:blackstone
fill 477 65 416 478 65 416 minecraft:orange_concrete
fill 477 65 426 478 65 426 minecraft:blackstone
setblock 477 65 458 minecraft:orange_concrete
fill 478 65 458 479 65 458 minecraft:red_nether_bricks
setblock 479 65 416 minecraft:red_nether_bricks
fill 479 65 427 480 65 427 minecraft:blackstone
setblock 480 65 416 minecraft:blackstone
fill 481 65 416 481 67 416 minecraft:red_nether_bricks
fill 481 65 428 481 65 429 minecraft:blackstone
fill 481 65 432 481 65 433 minecraft:blackstone
setblock 482 65 416 minecraft:blackstone
fill 482 65 429 482 65 431 minecraft:blackstone
fill 483 65 416 484 65 416 minecraft:red_nether_bricks
fill 483 65 458 484 67 458 minecraft:red_nether_bricks
setblock 485 65 458 minecraft:blackstone
fill 486 65 458 487 65 458 minecraft:red_nether_bricks
fill 487 65 416 489 65 416 minecraft:red_nether_bricks
setblock 488 65 458 minecraft:orange_concrete
setblock 490 65 416 minecraft:blackstone
setblock 490 65 458 minecraft:red_nether_bricks
fill 491 65 416 491 66 416 minecraft:red_nether_bricks
setblock 491 65 458 minecraft:blackstone
fill 492 65 458 493 65 458 minecraft:red_nether_bricks
fill 493 65 416 494 67 416 minecraft:red_nether_bricks
setblock 498 65 416 minecraft:orange_concrete
setblock 499 65 416 minecraft:red_nether_bricks
setblock 499 65 458 minecraft:red_nether_bricks
setblock 500 65 416 minecraft:blackstone
fill 501 65 416 504 65 416 minecraft:red_nether_bricks
fill 502 65 458 502 69 458 minecraft:red_nether_bricks
setblock 503 65 458 minecraft:blackstone
fill 504 65 458 508 65 458 minecraft:red_nether_bricks
setblock 507 65 416 minecraft:blackstone
setblock 508 65 416 minecraft:red_nether_bricks
setblock 509 65 416 minecraft:orange_concrete
setblock 509 65 458 minecraft:orange_concrete
fill 510 65 416 512 65 416 minecraft:red_nether_bricks
fill 510 65 458 511 65 458 minecraft:red_nether_bricks
fill 512 65 418 512 67 418 minecraft:red_nether_bricks
fill 512 65 423 512 65 427 minecraft:red_nether_bricks
setblock 512 65 428 minecraft:blackstone
fill 512 65 429 512 68 429 minecraft:red_nether_bricks
setblock 512 65 430 minecraft:orange_concrete
fill 512 65 431 512 65 432 minecraft:red_nether_bricks
fill 512 65 433 512 65 434 minecraft:orange_concrete
fill 512 65 435 512 65 437 minecraft:red_nether_bricks
fill 512 65 450 512 68 450 minecraft:red_nether_bricks
setblock 512 65 454 minecraft:orange_concrete
setblock 512 65 455 minecraft:red_nether_bricks
setblock 470 66 416 minecraft:blackstone
fill 470 66 417 473 66 417 minecraft:red_nether_bricks
setblock 470 66 418 minecraft:blackstone
fill 470 66 419 471 66 419 minecraft:red_nether_bricks
fill 470 66 421 471 66 421 minecraft:red_nether_bricks
fill 470 66 422 470 67 423 minecraft:orange_concrete
fill 470 66 424 471 66 424 minecraft:red_nether_bricks
setblock 470 66 425 minecraft:blackstone
fill 470 66 429 471 66 429 minecraft:red_nether_bricks
setblock 470 66 430 minecraft:blackstone
fill 470 66 431 471 66 433 minecraft:red_nether_bricks
fill 470 66 434 470 66 435 minecraft:orange_concrete
fill 470 66 436 471 66 437 minecraft:red_nether_bricks
fill 470 66 440 470 66 442 minecraft:red_nether_bricks
fill 470 66 443 470 67 443 minecraft:orange_concrete
fill 470 66 444 471 66 445 minecraft:red_nether_bricks
setblock 470 66 446 minecraft:orange_concrete
fill 470 66 447 471 66 448 minecraft:red_nether_bricks
fill 470 66 450 470 69 451 minecraft:red_nether_bricks
fill 470 66 453 471 66 453 minecraft:red_nether_bricks
fill 470 66 454 470 67 455 minecraft:orange_concrete
fill 470 66 456 471 66 457 minecraft:red_nether_bricks
setblock 471 66 420 minecraft:red_nether_bricks
setblock 471 66 423 minecraft:red_nether_bricks
setblock 471 66 425 minecraft:red_nether_bricks
fill 471 66 427 471 66 428 minecraft:red_nether_bricks
setblock 471 66 435 minecraft:red_nether_bricks
fill 471 66 439 471 66 441 minecraft:red_nether_bricks
setblock 471 66 443 minecraft:red_nether_bricks
setblock 471 66 449 minecraft:red_nether_bricks
fill 471 66 451 471 66 452 minecraft:red_nether_bricks
setblock 471 66 455 minecraft:red_nether_bricks
fill 472 66 458 472 68 458 minecraft:red_nether_bricks
fill 473 66 457 475 66 457 minecraft:red_nether_bricks
fill 474 66 416 475 69 416 minecraft:red_nether_bricks
fill 475 66 417 477 66 417 minecraft:red_nether_bricks
setblock 476 66 416 minecraft:orange_concrete
fill 476 66 458 477 67 458 minecraft:red_nether_bricks
fill 477 66 416 477 71 416 minecraft:red_nether_bricks
fill 477 66 457 479 66 457 minecraft:red_nether_bricks
setblock 478 66 416 minecraft:blackstone
fill 478 66 458 479 66 458 minecraft:orange_concrete
fill 479 66 416 479 67 416 minecraft:orange_concrete
fill 479 66 417 481 66 417 minecraft:red_nether_bricks
setblock 480 66 416 minecraft:red_nether_bricks
fill 480 66 458 481 71 458 minecraft:red_nether_bricks
fill 481 66 457 483 66 457 minecraft:red_nether_bricks
fill 482 66 416 482 67 416 minecraft:red_nether_bricks
fill 483 66 416 485 66 416 minecraft:blackstone
fill 483 66 417 485 66 417 minecraft:red_nether_bricks
fill 485 66 457 485 66 458 minecraft:red_nether_bricks
fill 486 66 416 486 71 416 minecraft:red_nether_bricks
fill 486 66 457 487 66 457 minecraft:red_nether_bricks
fill 486 66 458 487 67 458 minecraft:orange_concrete
fill 487 66 416 488 66 416 minecraft:orange_concrete
fill 487 66 417 489 66 417 minecraft:red_nether_bricks
fill 488 66 458 489 71 458 minecraft:red_nether_bricks
fill 489 66 416 490 67 416 minecraft:red_nether_bricks
fill 489 66 457 491 66 457 minecraft:red_nether_bricks
setblock 490 66 458 minecraft:orange_concrete
fill 491 66 417 493 66 417 minecraft:red_nether_bricks
fill 491 66 458 491 69 458 minecraft:red_nether_bricks
fill 492 66 458 493 66 458 minecraft:blackstone
fill 493 66 457 495 66 457 minecraft:red_nether_bricks
fill 494 66 458 497 66 458 minecraft:red_nether_bricks
fill 495 66 416 495 66 417 minecraft:red_nether_bricks
setblock 496 66 416 minecraft:orange_concrete
fill 496 66 417 497 66 417 minecraft:red_nether_bricks
setblock 497 66 416 minecraft:blackstone
fill 497 66 457 499 66 457 minecraft:red_nether_bricks
fill 498 66 416 498 71 416 minecraft:red_nether_bricks
fill 498 66 458 499 67 458 minecraft:orange_concrete
fill 499 66 416 500 67 416 minecraft:orange_concrete
fill 499 66 417 501 66 417 minecraft:red_nether_bricks
fill 500 66 458 501 71 458 minecraft:red_nether_bricks
fill 501 66 416 503 67 416 minecraft:red_nether_bricks
fill 501 66 457 503 66 457 minecraft:red_nether_bricks
fill 503 66 417 505 66 417 minecraft:red_nether_bricks
fill 503 66 458 505 67 458 minecraft:red_nether_bricks
setblock 504 66 416 minecraft:blackstone
fill 505 66 416 506 68 416 minecraft:red_nether_bricks
fill 505 66 457 507 66 457 minecraft:red_nether_bricks
setblock 506 66 458 minecraft:blackstone
fill 507 66 416 508 66 416 minecraft:orange_concrete
fill 507 66 417 509 66 417 minecraft:red_nether_bricks
fill 507 66 458 507 67 458 minecraft:orange_concrete
fill 508 66 458 509 67 458 minecraft:red_nether_bricks
fill 509 66 416 510 67 416 minecraft:red_nether_bricks
fill 509 66 457 511 66 457 minecraft:red_nether_bricks
fill 510 66 458 511 66 458 minecraft:orange_concrete
fill 511 66 416 511 67 416 minecraft:orange_concrete
fill 511 66 417 511 66 419 minecraft:red_nether_bricks
fill 511 66 421 511 66 423 minecraft:red_nether_bricks
fill 511 66 425 512 66 427 minecraft:red_nether_bricks
fill 511 66 429 511 66 431 minecraft:red_nether_bricks
fill 511 66 433 511 66 435 minecraft:red_nether_bricks
fill 511 66 437 511 66 439 minecraft:red_nether_bricks
fill 511 66 441 511 66 443 minecraft:red_nether_bricks
fill 511 66 445 512 66 447 minecraft:red_nether_bricks
fill 511 66 449 511 66 451 minecraft:red_nether_bricks
fill 511 66 453 511 66 455 minecraft:red_nether_bricks
setblock 512 66 416 minecraft:red_nether_bricks
fill 512 66 421 512 71 422 minecraft:red_nether_bricks
fill 512 66 423 512 67 424 minecraft:orange_concrete
fill 512 66 428 512 69 428 minecraft:red_nether_bricks
fill 512 66 430 512 68 430 minecraft:red_nether_bricks
setblock 512 66 431 minecraft:blackstone
setblock 512 66 432 minecraft:orange_concrete
fill 512 66 433 512 71 434 minecraft:red_nether_bricks
fill 512 66 435 512 67 435 minecraft:orange_concrete
setblock 512 66 436 minecraft:red_nether_bricks
setblock 512 66 437 minecraft:blackstone
fill 512 66 438 512 67 438 minecraft:red_nether_bricks
setblock 512 66 441 minecraft:blackstone
fill 512 66 442 512 71 442 minecraft:red_nether_bricks
fill 512 66 443 512 66 444 minecraft:orange_concrete
fill 512 66 448 512 67 449 minecraft:red_nether_bricks
fill 512 66 451 512 69 451 minecraft:red_nether_bricks
setblock 512 66 452 minecraft:blackstone
fill 512 66 453 512 71 454 minecraft:red_nether_bricks
fill 512 66 455 512 67 456 minecraft:orange_concrete
fill 512 66 458 512 71 458 minecraft:red_nether_bricks
fill 470 67 416 470 68 419 minecraft:red_nether_bricks
setblock 470 67 421 minecraft:red_nether_bricks
fill 470 67 424 470 71 425 minecraft:red_nether_bricks
fill 470 67 429 470 67 430 minecraft:red_nether_bricks
setblock 470 67 431 minecraft:orange_concrete
fill 470 67 432 470 67 433 minecraft:red_nether_bricks
setblock 470 67 434 minecraft:orange_concrete
fill 470 67 435 470 70 437 minecraft:red_nether_bricks
fill 470 67 440 470 67 441 minecraft:red_nether_bricks
setblock 470 67 442 minecraft:orange_concrete
fill 470 67 444 470 69 448 minecraft:red_nether_bricks
setblock 470 67 453 minecraft:red_nether_bricks
fill 470 67 456 470 71 457 minecraft:red_nether_bricks
setblock 473 67 458 minecraft:red_nether_bricks
fill 474 67 458 475 67 458 minecraft:orange_concrete
fill 476 67 416 476 70 416 minecraft:red_nether_bricks
fill 478 67 416 478 71 416 minecraft:red_nether_bricks
setblock 478 67 458 minecraft:orange_concrete
fill 479 67 458 479 70 458 minecraft:red_nether_bricks
setblock 480 67 416 minecraft:orange_concrete
fill 483 67 416 485 69 416 minecraft:red_nether_bricks
setblock 485 67 458 minecraft:red_nether_bricks
fill 487 67 416 487 70 416 minecraft:red_nether_bricks
setblock 488 67 416 minecraft:orange_concrete
fill 490 67 458 490 70 458 minecraft:red_nether_bricks
setblock 491 67 416 minecraft:orange_concrete
fill 492 67 458 494 68 458 minecraft:red_nether_bricks
fill 495 67 416 497 69 416 minecraft:red_nether_bricks
setblock 495 67 458 minecraft:orange_concrete
fill 496 67 458 497 67 458 minecraft:red_nether_bricks
fill 504 67 416 504 69 416 minecraft:red_nether_bricks
setblock 506 67 458 minecraft:orange_concrete
fill 507 67 416 507 70 416 minecraft:red_nether_bricks
setblock 508 67 416 minecraft:orange_concrete
fill 510 67 458 511 70 458 minecraft:red_nether_bricks
setblock 512 67 416 minecraft:orange_concrete
fill 512 67 425 512 67 426 minecraft:red_nether_bricks
setblock 512 67 427 minecraft:orange_concrete
fill 512 67 431 512 69 432 minecraft:red_nether_bricks
setblock 512 67 436 minecraft:orange_concrete
setblock 512 67 437 minecraft:red_nether_bricks
fill 512 67 441 512 71 441 minecraft:red_nether_bricks
fill 512 67 443 512 70 443 minecraft:red_nether_bricks
setblock 512 67 444 minecraft:orange_concrete
fill 512 67 445 512 67 446 minecraft:red_nether_bricks
setblock 512 67 447 minecraft:orange_concrete
fill 512 67 452 512 69 452 minecraft:red_nether_bricks
fill 470 68 420 470 69 421 minecraft:orange_concrete
fill 470 68 422 470 73 423 minecraft:red_nether_bricks
fill 470 68 429 470 69 429 minecraft:orange_concrete
fill 470 68 430 470 69 431 minecraft:red_nether_bricks
fill 470 68 432 470 68 433 minecraft:orange_concrete
fill 470 68 434 470 73 434 minecraft:red_nether_bricks
fill 470 68 440 470 69 441 minecraft:orange_concrete
fill 470 68 442 470 73 443 minecraft:red_nether_bricks
fill 470 68 452 470 68 453 minecraft:orange_concrete
fill 470 68 454 470 73 455 minecraft:red_nether_bricks
fill 473 68 458 473 69 458 minecraft:orange_concrete
fill 474 68 458 475 73 458 minecraft:red_nether_bricks
setblock 476 68 458 minecraft:orange_concrete
fill 477 68 458 478 71 458 minecraft:red_nether_bricks
fill 479 68 416 480 73 416 minecraft:red_nether_bricks
fill 481 68 416 482 69 416 minecraft:orange_concrete
fill 483 68 458 483 69 458 minecraft:red_nether_bricks
fill 484 68 458 485 69 458 minecraft:orange_concrete
fill 486 68 458 487 73 458 minecraft:red_nether_bricks
fill 488 68 416 488 73 416 minecraft:red_nether_bricks
fill 489 68 416 490 68 416 minecraft:orange_concrete
fill 491 68 416 491 73 416 minecraft:red_nether_bricks
fill 493 68 416 493 69 416 minecraft:orange_concrete
setblock 494 68 416 minecraft:red_nether_bricks
fill 495 68 458 495 73 458 minecraft:red_nether_bricks
fill 496 68 458 497 68 458 minecraft:orange_concrete
fill 498 68 458 499 73 458 minecraft:red_nether_bricks
fill 499 68 416 500 73 416 minecraft:red_nether_bricks
fill 501 68 416 502 69 416 minecraft:orange_concrete
fill 503 68 416 503 69 416 minecraft:red_nether_bricks
fill 503 68 458 503 69 458 minecraft:red_nether_bricks
fill 504 68 458 505 69 458 minecraft:orange_concrete
fill 506 68 458 507 73 458 minecraft:red_nether_bricks
fill 508 68 416 509 70 416 minecraft:red_nether_bricks
setblock 508 68 458 minecraft:orange_concrete
fill 509 68 458 509 71 458 minecraft:red_nether_bricks
setblock 510 68 416 minecraft:orange_concrete
fill 511 68 416 512 73 416 minecraft:red_nether_bricks
fill 512 68 417 512 69 418 minecraft:orange_concrete
fill 512 68 423 512 73 424 minecraft:red_nether_bricks
fill 512 68 425 512 68 426 minecraft:orange_concrete
fill 512 68 427 512 69 427 minecraft:red_nether_bricks
fill 512 68 435 512 73 436 minecraft:red_nether_bricks
fill 512 68 437 512 69 438 minecraft:orange_concrete
fill 512 68 444 512 73 444 minecraft:red_nether_bricks
fill 512 68 445 512 68 446 minecraft:orange_concrete
fill 512 68 447 512 69 448 minecraft:red_nether_bricks
fill 512 68 449 512 69 449 minecraft:orange_concrete
fill 512 68 455 512 73 456 minecraft:red_nether_bricks
fill 512 68 457 512 69 457 minecraft:orange_concrete
fill 470 69 416 470 71 416 minecraft:red_nether_bricks
setblock 470 69 417 minecraft:orange_concrete
fill 470 69 418 470 69 419 minecraft:red_nether_bricks
setblock 470 69 428 minecraft:orange_concrete
fill 470 69 432 470 72 433 minecraft:red_nether_bricks
setblock 470 69 449 minecraft:orange_concrete
setblock 470 69 452 minecraft:orange_concrete
fill 470 69 453 470 72 453 minecraft:red_nether_bricks
setblock 472 69 458 minecraft:orange_concrete
setblock 473 69 416 minecraft:orange_concrete
fill 476 69 458 476 72 458 minecraft:red_nether_bricks
fill 489 69 416 490 72 416 minecraft:red_nether_bricks
fill 492 69 458 493 69 458 minecraft:orange_concrete
setblock 494 69 416 minecraft:orange_concrete
setblock 494 69 458 minecraft:red_nether_bricks
setblock 496 69 458 minecraft:orange_concrete
fill 497 69 458 497 72 458 minecraft:red_nether_bricks
setblock 505 69 416 minecraft:orange_concrete
fill 506 69 416 506 71 416 minecraft:red_nether_bricks
fill 508 69 458 508 72 458 minecraft:red_nether_bricks
fill 510 69 416 510 72 416 minecraft:red_nether_bricks
fill 512 69 425 512 72 425 minecraft:red_nether_bricks
setblock 512 69 426 minecraft:orange_concrete
fill 512 69 429 512 69 430 minecraft:orange_concrete
fill 512 69 445 512 72 446 minecraft:red_nether_bricks
setblock 512 69 450 minecraft:orange_concrete
fill 470 70 417 470 75 417 minecraft:red_nether_bricks
fill 470 70 418 470 70 419 minecraft:orange_concrete
fill 470 70 420 470 75 421 minecraft:red_nether_bricks
fill 470 70 426 470 71 427 minecraft:orange_concrete
fill 470 70 428 470 75 429 minecraft:red_nether_bricks
setblock 470 70 430 minecraft:orange_concrete
fill 470 70 431 470 73 431 minecraft:red_nether_bricks
fill 470 70 438 470 71 439 minecraft:orange_concrete
fill 470 70 440 470 75 441 minecraft:red_nether_bricks
fill 470 70 444 470 70 446 minecraft:red_nether_bricks
fill 470 70 447 470 71 447 minecraft:orange_concrete
fill 470 70 448 470 71 449 minecraft:red_nether_bricks
fill 470 70 450 470 70 451 minecraft:orange_concrete
fill 470 70 452 470 75 452 minecraft:red_nether_bricks
fill 470 70 458 471 71 458 minecraft:orange_concrete
fill 471 70 416 472 70 416 minecraft:orange_concrete
fill 472 70 458 473 75 458 minecraft:red_nether_bricks
fill 473 70 416 474 71 416 minecraft:red_nether_bricks
fill 475 70 416 475 71 416 minecraft:orange_concrete
fill 481 70 416 482 75 416 minecraft:red_nether_bricks
fill 482 70 458 483 70 458 minecraft:orange_concrete
fill 483 70 416 484 71 416 minecraft:orange_concrete
fill 484 70 458 485 75 458 minecraft:red_nether_bricks
fill 485 70 416 485 71 416 minecraft:red_nether_bricks
fill 491 70 458 491 71 458 minecraft:orange_concrete
setblock 492 70 416 minecraft:orange_concrete
fill 492 70 458 493 75 458 minecraft:red_nether_bricks
fill 493 70 416 494 75 416 minecraft:red_nether_bricks
setblock 494 70 458 minecraft:orange_concrete
fill 495 70 416 496 71 416 minecraft:orange_concrete
fill 496 70 458 496 75 458 minecraft:red_nether_bricks
fill 497 70 416 497 71 416 minecraft:red_nether_bricks
fill 501 70 416 502 75 416 minecraft:red_nether_bricks
fill 502 70 458 503 71 458 minecraft:orange_concrete
fill 503 70 416 504 70 416 minecraft:orange_concrete
fill 504 70 458 505 75 458 minecraft:red_nether_bricks
fill 505 70 416 505 71 416 minecraft:red_nether_bricks
fill 512 70 417 512 75 418 minecraft:red_nether_bricks
fill 512 70 419 512 71 420 minecraft:orange_concrete
fill 512 70 426 512 75 426 minecraft:red_nether_bricks
fill 512 70 427 512 70 428 minecraft:orange_concrete
fill 512 70 429 512 71 430 minecraft:red_nether_bricks
fill 512 70 431 512 71 431 minecraft:orange_concrete
setblock 512 70 432 minecraft:red_nether_bricks
fill 512 70 437 512 75 438 minecraft:red_nether_bricks
fill 512 70 439 512 71 440 minecraft:orange_concrete
fill 512 70 447 512 73 447 minecraft:red_nether_bricks
setblock 512 70 448 minecraft:orange_concrete
fill 512 70 449 512 75 450 minecraft:red_nether_bricks
fill 512 70 451 512 71 452 minecraft:orange_concrete
fill 512 70 457 512 75 457 minecraft:red_nether_bricks
setblock 470 71 418 minecraft:orange_concrete
fill 470 71 419 470 74 419 minecraft:red_nether_bricks
fill 470 71 430 470 74 430 minecraft:red_nether_bricks
setblock 470 71 435 minecraft:orange_concrete
fill 470 71 436 470 71 437 minecraft:red_nether_bricks
fill 470 71 444 470 71 445 minecraft:red_nether_bricks
setblock 470 71 446 minecraft:orange_concrete
fill 470 71 450 470 74 451 minecraft:red_nether_bricks
fill 471 71 416 472 74 416 minecraft:red_nether_bricks
setblock 476 71 416 minecraft:orange_concrete
setblock 479 71 458 minecraft:orange_concrete
setblock 482 71 458 minecraft:orange_concrete
fill 483 71 458 483 74 458 minecraft:red_nether_bricks
setblock 487 71 416 minecraft:orange_concrete
setblock 490 71 458 minecraft:orange_concrete
fill 492 71 416 492 74 416 minecraft:red_nether_bricks
fill 494 71 458 494 74 458 minecraft:red_nether_bricks
fill 503 71 416 503 74 416 minecraft:red_nether_bricks
setblock 504 71 416 minecraft:orange_concrete
fill 507 71 416 508 71 416 minecraft:orange_concrete
setblock 509 71 416 minecraft:red_nether_bricks
fill 510 71 458 511 71 458 minecraft:orange_concrete
fill 512 71 427 512 73 428 minecraft:red_nether_bricks
setblock 512 71 432 minecraft:orange_concrete
setblock 512 71 443 minecraft:orange_concrete
fill 512 71 448 512 74 448 minecraft:red_nether_bricks
setblock 470 72 416 minecraft:orange_concrete
fill 470 72 418 470 77 418 minecraft:red_nether_bricks
fill 470 72 424 470 73 425 minecraft:orange_concrete
fill 470 72 426 470 77 427 minecraft:red_nether_bricks
fill 470 72 435 471 72 435 minecraft:red_nether_bricks
fill 470 72 436 470 72 437 minecraft:orange_concrete
fill 470 72 438 470 77 439 minecraft:red_nether_bricks
fill 470 72 444 470 73 445 minecraft:orange_concrete
fill 470 72 446 470 77 447 minecraft:red_nether_bricks
setblock 470 72 448 minecraft:orange_concrete
fill 470 72 449 471 72 449 minecraft:red_nether_bricks
fill 470 72 456 470 73 457 minecraft:orange_concrete
fill 470 72 458 471 77 458 minecraft:red_nether_bricks
fill 471 72 417 473 72 417 minecraft:red_nether_bricks
fill 471 72 419 471 72 421 minecraft:red_nether_bricks
fill 471 72 423 471 72 425 minecraft:red_nether_bricks
fill 471 72 427 471 72 429 minecraft:red_nether_bricks
fill 471 72 431 471 72 433 minecraft:red_nether_bricks
fill 471 72 436 471 72 437 minecraft:red_nether_bricks
fill 471 72 439 471 72 441 minecraft:red_nether_bricks
fill 471 72 443 471 72 445 minecraft:red_nether_bricks
fill 471 72 447 471 72 448 minecraft:red_nether_bricks
fill 471 72 451 471 72 453 minecraft:red_nether_bricks
fill 471 72 455 471 72 457 minecraft:red_nether_bricks
fill 473 72 416 473 75 416 minecraft:red_nether_bricks
setblock 473 72 419 minecraft:light[level=14]
setblock 473 72 427 minecraft:light[level=14]
setblock 473 72 435 minecraft:light[level=14]
setblock 473 72 443 minecraft:light[level=14]
setblock 473 72 451 minecraft:light[level=14]
fill 473 72 457 475 72 457 minecraft:red_nether_bricks
setblock 474 72 416 minecraft:orange_concrete
fill 475 72 416 476 72 417 minecraft:red_nether_bricks
fill 477 72 416 478 73 416 minecraft:orange_concrete
setblock 477 72 417 minecraft:red_nether_bricks
fill 477 72 457 479 72 457 minecraft:red_nether_bricks
fill 477 72 458 477 73 458 minecraft:orange_concrete
fill 478 72 458 479 73 458 minecraft:red_nether_bricks
fill 479 72 417 481 72 417 minecraft:red_nether_bricks
fill 480 72 458 481 72 458 minecraft:orange_concrete
setblock 481 72 419 minecraft:light[level=14]
setblock 481 72 427 minecraft:light[level=14]
setblock 481 72 435 minecraft:light[level=14]
setblock 481 72 443 minecraft:light[level=14]
setblock 481 72 451 minecraft:light[level=14]
fill 481 72 457 483 72 457 minecraft:red_nether_bricks
fill 482 72 458 482 77 458 minecraft:red_nether_bricks
fill 483 72 416 484 72 417 minecraft:red_nether_bricks
fill 485 72 416 486 72 416 minecraft:orange_concrete
setblock 485 72 417 minecraft:red_nether_bricks
fill 485 72 457 487 72 457 minecraft:red_nether_bricks
fill 487 72 416 487 72 417 minecraft:red_nether_bricks
fill 488 72 417 489 72 417 minecraft:red_nether_bricks
fill 488 72 458 489 73 458 minecraft:orange_concrete
setblock 489 72 419 minecraft:light[level=14]
setblock 489 72 427 minecraft:light[level=14]
setblock 489 72 435 minecraft:light[level=14]
setblock 489 72 443 minecraft:light[level=14]
setblock 489 72 451 minecraft:light[level=14]
fill 489 72 457 491 72 457 minecraft:red_nether_bricks
fill 490 72 458 491 77 458 minecraft:red_nether_bricks
fill 491 72 417 493 72 417 minecraft:red_nether_bricks
fill 493 72 457 495 72 457 minecraft:red_nether_bricks
fill 495 72 416 496 72 417 minecraft:red_nether_bricks
fill 497 72 416 498 73 416 minecraft:orange_concrete
setblock 497 72 417 minecraft:red_nether_bricks
setblock 497 72 419 minecraft:light[level=14]
setblock 497 72 427 minecraft:light[level=14]
setblock 497 72 435 minecraft:light[level=14]
setblock 497 72 443 minecraft:light[level=14]
setblock 497 72 451 minecraft:light[level=14]
fill 497 72 457 499 72 457 minecraft:red_nether_bricks
fill 499 72 417 501 72 417 minecraft:red_nether_bricks
fill 500 72 458 501 72 458 minecraft:orange_concrete
fill 501 72 457 503 72 457 minecraft:red_nether_bricks
fill 502 72 458 503 77 458 minecraft:red_nether_bricks
fill 503 72 417 505 72 417 minecraft:red_nether_bricks
fill 504 72 416 504 77 416 minecraft:red_nether_bricks
fill 505 72 416 506 72 416 minecraft:orange_concrete
setblock 505 72 419 minecraft:light[level=14]
setblock 505 72 427 minecraft:light[level=14]
setblock 505 72 435 minecraft:light[level=14]
setblock 505 72 443 minecraft:light[level=14]
setblock 505 72 451 minecraft:light[level=14]
fill 505 72 457 507 72 457 minecraft:red_nether_bricks
fill 507 72 416 508 72 417 minecraft:red_nether_bricks
fill 509 72 416 509 73 416 minecraft:orange_concrete
setblock 509 72 417 minecraft:red_nether_bricks
fill 509 72 457 511 72 457 minecraft:red_nether_bricks
fill 509 72 458 509 73 458 minecraft:orange_concrete
fill 510 72 458 511 77 458 minecraft:red_nether_bricks
fill 511 72 417 511 72 419 minecraft:red_nether_bricks
fill 511 72 421 511 72 423 minecraft:red_nether_bricks
fill 511 72 425 511 72 427 minecraft:red_nether_bricks
fill 511 72 429 511 72 431 minecraft:red_nether_bricks
fill 511 72 433 511 72 435 minecraft:red_nether_bricks
fill 511 72 437 511 72 439 minecraft:red_nether_bricks
fill 511 72 441 511 72 443 minecraft:red_nether_bricks
fill 511 72 445 511 72 447 minecraft:red_nether_bricks
fill 511 72 449 511 72 451 minecraft:red_nether_bricks
fill 511 72 453 511 72 455 minecraft:red_nether_bricks
fill 512 72 419 512 77 420 minecraft:red_nether_bricks
fill 512 72 421 512 73 422 minecraft:orange_concrete
fill 512 72 429 512 75 429 minecraft:red_nether_bricks
setblock 512 72 430 minecraft:orange_concrete
fill 512 72 431 512 77 432 minecraft:red_nether_bricks
fill 512 72 433 512 73 434 minecraft:orange_concrete
fill 512 72 439 512 74 440 minecraft:red_nether_bricks
fill 512 72 441 512 72 442 minecraft:orange_concrete
fill 512 72 443 512 77 443 minecraft:red_nether_bricks
fill 512 72 451 512 77 452 minecraft:red_nether_bricks
fill 512 72 453 512 73 454 minecraft:orange_concrete
setblock 512 72 458 minecraft:orange_concrete
fill 470 73 416 470 76 416 minecraft:red_nether_bricks
fill 470 73 432 470 73 433 minecraft:orange_concrete
fill 470 73 435 470 77 435 minecraft:red_nether_bricks
setblock 470 73 436 minecraft:orange_concrete
fill 470 73 437 470 76 437 minecraft:red_nether_bricks
fill 470 73 448 470 75 449 minecraft:red_nether_bricks
setblock 470 73 453 minecraft:orange_concrete
fill 474 73 416 476 76 416 minecraft:red_nether_bricks
setblock 476 73 458 minecraft:orange_concrete
fill 480 73 458 481 76 458 minecraft:red_nether_bricks
fill 483 73 416 485 76 416 minecraft:red_nether_bricks
setblock 486 73 416 minecraft:orange_concrete
fill 487 73 416 487 77 416 minecraft:red_nether_bricks
fill 489 73 416 490 73 416 minecraft:orange_concrete
fill 495 73 416 496 77 416 minecraft:red_nether_bricks
setblock 497 73 458 minecraft:orange_concrete
fill 500 73 432 500 74 433 minecraft:shroomlight
setblock 500 73 458 minecraft:orange_concrete
fill 501 73 458 501 76 458 minecraft:red_nether_bricks
fill 505 73 416 508 73 416 minecraft:red_nether_bricks
fill 505 73 442 506 74 443 minecraft:netherrack
setblock 508 73 458 minecraft:orange_concrete
setblock 510 73 416 minecraft:orange_concrete
setblock 512 73 425 minecraft:orange_concrete
fill 512 73 430 512 75 430 minecraft:red_nether_bricks
fill 512 73 441 512 76 441 minecraft:red_nether_bricks
setblock 512 73 442 minecraft:orange_concrete
fill 512 73 445 512 73 446 minecraft:orange_concrete
fill 512 73 458 512 76 458 minecraft:red_nether_bricks
fill 470 74 422 470 74 423 minecraft:orange_concrete
fill 470 74 424 470 79 425 minecraft:red_nether_bricks
fill 470 74 431 470 75 431 minecraft:orange_concrete
fill 470 74 432 470 79 433 minecraft:red_nether_bricks
setblock 470 74 434 minecraft:orange_concrete
fill 470 74 436 470 79 436 minecraft:red_nether_bricks
fill 470 74 442 470 75 443 minecraft:orange_concrete
fill 470 74 444 470 79 445 minecraft:red_nether_bricks
fill 470 74 453 470 79 453 minecraft:red_nether_bricks
fill 470 74 454 470 74 455 minecraft:orange_concrete
fill 470 74 456 470 79 457 minecraft:red_nether_bricks
fill 474 74 458 475 75 458 minecraft:orange_concrete
fill 476 74 458 477 79 458 minecraft:red_nether_bricks
fill 477 74 416 478 79 416 minecraft:red_nether_bricks
setblock 478 74 458 minecraft:orange_concrete
fill 479 74 416 480 75 416 minecraft:orange_concrete
fill 479 74 458 479 77 458 minecraft:red_nether_bricks
fill 486 74 416 486 79 416 minecraft:red_nether_bricks
fill 486 74 458 487 75 458 minecraft:orange_concrete
setblock 488 74 416 minecraft:orange_concrete
fill 488 74 458 489 79 458 minecraft:red_nether_bricks
fill 489 74 416 490 79 416 minecraft:red_nether_bricks
fill 491 74 416 491 75 416 minecraft:orange_concrete
fill 495 74 458 495 75 458 minecraft:orange_concrete
fill 497 74 416 498 79 416 minecraft:red_nether_bricks
fill 497 74 458 497 79 458 minecraft:red_nether_bricks
fill 498 74 458 499 74 458 minecraft:orange_concrete
fill 499 74 416 500 74 416 minecraft:orange_concrete
fill 500 74 458 500 79 458 minecraft:red_nether_bricks
fill 505 74 416 507 75 416 minecraft:red_nether_bricks
fill 506 74 458 507 75 458 minecraft:orange_concrete
setblock 508 74 416 minecraft:orange_concrete
fill 508 74 458 509 79 458 minecraft:red_nether_bricks
fill 509 74 416 510 79 416 minecraft:red_nether_bricks
fill 511 74 416 512 75 416 minecraft:orange_concrete
fill 512 74 421 512 76 422 minecraft:red_nether_bricks
fill 512 74 423 512 74 424 minecraft:orange_concrete
fill 512 74 425 512 79 425 minecraft:red_nether_bricks
fill 512 74 427 512 75 427 minecraft:orange_concrete
setblock 512 74 428 minecraft:red_nether_bricks
fill 512 74 433 512 79 434 minecraft:red_nether_bricks
fill 512 74 435 512 75 436 minecraft:orange_concrete
fill 512 74 442 512 76 442 minecraft:red_nether_bricks
setblock 512 74 444 minecraft:orange_concrete
fill 512 74 445 512 79 446 minecraft:red_nether_bricks
fill 512 74 447 512 75 447 minecraft:orange_concrete
fill 512 74 453 512 79 454 minecraft:red_nether_bricks
fill 512 74 455 512 74 456 minecraft:orange_concrete
setblock 470 75 419 minecraft:orange_concrete
setblock 470 75 422 minecraft:orange_concrete
fill 470 75 423 470 78 423 minecraft:red_nether_bricks
setblock 470 75 430 minecraft:orange_concrete
fill 470 75 434 470 78 434 minecraft:red_nether_bricks
fill 470 75 450 470 75 451 minecraft:orange_concrete
setblock 470 75 454 minecraft:orange_concrete
fill 470 75 455 470 78 455 minecraft:red_nether_bricks
fill 471 75 416 472 75 416 minecraft:orange_concrete
fill 478 75 458 478 78 458 minecraft:red_nether_bricks
setblock 483 75 458 minecraft:orange_concrete
fill 488 75 416 488 78 416 minecraft:red_nether_bricks
setblock 492 75 416 minecraft:orange_concrete
setblock 494 75 458 minecraft:orange_concrete
fill 498 75 458 499 78 458 minecraft:red_nether_bricks
fill 499 75 416 499 78 416 minecraft:red_nether_bricks
setblock 500 75 416 minecraft:orange_concrete
setblock 503 75 416 minecraft:orange_concrete
fill 508 75 416 508 77 416 minecraft:red_nether_bricks
fill 512 75 423 512 78 423 minecraft:red_nether_bricks
setblock 512 75 424 minecraft:orange_concrete
setblock 512 75 428 minecraft:orange_concrete
setblock 512 75 439 minecraft:orange_concrete
fill 512 75 440 512 77 440 minecraft:red_nether_bricks
fill 512 75 444 512 78 444 minecraft:red_nether_bricks
setblock 512 75 448 minecraft:orange_concrete
fill 512 75 455 512 78 455 minecraft:red_nether_bricks
setblock 512 75 456 minecraft:orange_concrete
fill 470 76 417 470 77 417 minecraft:orange_concrete
fill 470 76 419 470 81 419 minecraft:red_nether_bricks
fill 470 76 420 470 76 421 minecraft:orange_concrete
fill 470 76 422 470 81 422 minecraft:red_nether_bricks
fill 470 76 428 470 77 429 minecraft:orange_concrete
fill 470 76 430 470 81 431 minecraft:red_nether_bricks
fill 470 76 440 470 76 441 minecraft:orange_concrete
fill 470 76 442 470 81 443 minecraft:red_nether_bricks
setblock 470 76 448 minecraft:red_nether_bricks
fill 470 76 449 470 77 449 minecraft:orange_concrete
fill 470 76 450 470 81 451 minecraft:red_nether_bricks
setblock 470 76 452 minecraft:orange_concrete
fill 470 76 454 470 81 454 minecraft:red_nether_bricks
fill 471 76 416 472 81 416 minecraft:red_nether_bricks
fill 472 76 458 473 77 458 minecraft:orange_concrete
fill 473 76 416 473 77 416 minecraft:orange_concrete
fill 474 76 458 475 81 458 minecraft:red_nether_bricks
fill 479 76 416 480 81 416 minecraft:red_nether_bricks
fill 481 76 416 482 76 416 minecraft:orange_concrete
fill 483 76 458 483 81 458 minecraft:red_nether_bricks
fill 484 76 458 485 76 458 minecraft:orange_concrete
fill 486 76 458 487 81 458 minecraft:red_nether_bricks
fill 491 76 416 492 81 416 minecraft:red_nether_bricks
fill 492 76 458 493 77 458 minecraft:orange_concrete
fill 493 76 416 494 77 416 minecraft:orange_concrete
fill 494 76 458 495 81 458 minecraft:red_nether_bricks
setblock 496 76 458 minecraft:orange_concrete
fill 500 76 416 500 81 416 minecraft:red_nether_bricks
fill 501 76 416 502 76 416 minecraft:orange_concrete
fill 503 76 416 503 81 416 minecraft:red_nether_bricks
fill 504 76 458 505 77 458 minecraft:orange_concrete
fill 505 76 416 505 77 416 minecraft:orange_concrete
fill 506 76 416 507 76 416 minecraft:red_nether_bricks
fill 506 76 458 507 81 458 minecraft:red_nether_bricks
fill 511 76 416 512 81 416 minecraft:red_nether_bricks
fill 512 76 417 512 77 418 minecraft:orange_concrete
fill 512 76 424 512 78 424 minecraft:red_nether_bricks
setblock 512 76 426 minecraft:orange_concrete
fill 512 76 427 512 81 428 minecraft:red_nether_bricks
fill 512 76 429 512 77 430 minecraft:orange_concrete
fill 512 76 435 512 81 436 minecraft:red_nether_bricks
fill 512 76 437 512 76 438 minecraft:orange_concrete
fill 512 76 439 512 77 439 minecraft:red_nether_bricks
fill 512 76 447 512 81 448 minecraft:red_nether_bricks
fill 512 76 449 512 77 450 minecraft:orange_concrete
fill 512 76 456 512 81 456 minecraft:red_nether_bricks
setblock 512 76 457 minecraft:orange_concrete
setblock 470 77 416 minecraft:orange_concrete
fill 470 77 420 470 80 421 minecraft:red_nether_bricks
setblock 470 77 437 minecraft:orange_concrete
setblock 470 77 440 minecraft:orange_concrete
fill 470 77 441 470 80 441 minecraft:red_nether_bricks
setblock 470 77 448 minecraft:orange_concrete
fill 470 77 452 470 80 452 minecraft:red_nether_bricks
setblock 474 77 416 minecraft:orange_concrete
fill 475 77 416 476 77 416 minecraft:red_nether_bricks
fill 480 77 458 481 77 458 minecraft:orange_concrete
fill 481 77 416 481 80 416 minecraft:red_nether_bricks
setblock 482 77 416 minecraft:orange_concrete
fill 483 77 416 484 77 416 minecraft:red_nether_bricks
setblock 484 77 458 minecraft:orange_concrete
setblock 485 77 416 minecraft:orange_concrete
fill 485 77 458 485 80 458 minecraft:red_nether_bricks
fill 496 77 458 496 80 458 minecraft:red_nether_bricks
fill 501 77 416 502 80 416 minecraft:red_nether_bricks
setblock 501 77 458 minecraft:orange_concrete
setblock 506 77 416 minecraft:orange_concrete
setblock 507 77 416 minecraft:red_nether_bricks
setblock 512 77 421 minecraft:orange_concrete
fill 512 77 422 512 79 422 minecraft:red_nether_bricks
fill 512 77 426 512 80 426 minecraft:red_nether_bricks
fill 512 77 437 512 80 437 minecraft:red_nether_bricks
setblock 512 77 438 minecraft:orange_concrete
fill 512 77 441 512 77 442 minecraft:orange_concrete
fill 512 77 457 512 80 457 minecraft:red_nether_bricks
setblock 512 77 458 minecraft:orange_concrete
fill 470 78 416 470 83 417 minecraft:red_nether_bricks
setblock 470 78 418 minecraft:orange_concrete
fill 470 78 426 470 79 427 minecraft:orange_concrete
fill 470 78 428 471 78 429 minecraft:red_nether_bricks
fill 470 78 435 470 79 435 minecraft:orange_concrete
fill 470 78 437 471 78 437 minecraft:red_nether_bricks
fill 470 78 438 470 78 439 minecraft:orange_concrete
fill 470 78 440 471 78 440 minecraft:red_nether_bricks
fill 470 78 446 470 79 447 minecraft:orange_concrete
fill 470 78 448 471 78 449 minecraft:red_nether_bricks
fill 470 78 458 471 78 458 minecraft:orange_concrete
fill 471 78 417 473 78 417 minecraft:red_nether_bricks
fill 471 78 419 471 78 421 minecraft:red_nether_bricks
fill 471 78 423 471 78 425 minecraft:red_nether_bricks
setblock 471 78 427 minecraft:red_nether_bricks
fill 471 78 431 471 78 433 minecraft:red_nether_bricks
fill 471 78 435 471 78 436 minecraft:red_nether_bricks
setblock 471 78 439 minecraft:red_nether_bricks
setblock 471 78 441 minecraft:red_nether_bricks
fill 471 78 443 471 78 445 minecraft:red_nether_bricks
setblock 471 78 447 minecraft:red_nether_bricks
fill 471 78 451 471 78 453 minecraft:red_nether_bricks
fill 471 78 455 471 78 457 minecraft:red_nether_bricks
fill 472 78 458 473 83 458 minecraft:red_nether_bricks
fill 473 78 416 474 83 416 minecraft:red_nether_bricks
fill 473 78 457 475 78 457 minecraft:red_nether_bricks
fill 475 78 416 476 79 416 minecraft:orange_concrete
fill 475 78 417 477 78 417 minecraft:red_nether_bricks
fill 477 78 457 479 78 457 minecraft:red_nether_bricks
fill 479 78 417 481 78 417 minecraft:red_nether_bricks
fill 479 78 458 479 79 458 minecraft:orange_concrete
fill 480 78 458 481 83 458 minecraft:red_nether_bricks
fill 481 78 457 483 78 457 minecraft:red_nether_bricks
fill 482 78 416 482 83 416 minecraft:red_nether_bricks
setblock 482 78 458 minecraft:orange_concrete
fill 483 78 416 484 78 416 minecraft:orange_concrete
fill 483 78 417 485 78 417 minecraft:red_nether_bricks
fill 484 78 458 484 83 458 minecraft:red_nether_bricks
fill 485 78 416 485 83 416 minecraft:red_nether_bricks
fill 485 78 457 487 78 457 minecraft:red_nether_bricks
fill 487 78 416 487 79 416 minecraft:orange_concrete
fill 487 78 417 489 78 417 minecraft:red_nether_bricks
fill 489 78 457 491 78 457 minecraft:red_nether_bricks
fill 490 78 458 491 79 458 minecraft:orange_concrete
fill 491 78 417 493 78 417 minecraft:red_nether_bricks
fill 492 78 458 493 83 458 minecraft:red_nether_bricks
fill 493 78 416 494 83 416 minecraft:red_nether_bricks
fill 493 78 457 495 78 457 minecraft:red_nether_bricks
fill 495 78 416 496 79 416 minecraft:orange_concrete
fill 495 78 417 497 78 417 minecraft:red_nether_bricks
fill 497 78 457 499 78 457 minecraft:red_nether_bricks
fill 499 78 417 501 78 417 minecraft:red_nether_bricks
fill 501 78 457 501 78 458 minecraft:red_nether_bricks
fill 502 78 457 503 78 457 minecraft:red_nether_bricks
fill 502 78 458 503 78 458 minecraft:orange_concrete
fill 503 78 417 505 78 417 minecraft:red_nether_bricks
setblock 504 78 416 minecraft:orange_concrete
fill 504 78 458 505 83 458 minecraft:red_nether_bricks
fill 505 78 416 506 83 416 minecraft:red_nether_bricks
fill 505 78 457 507 78 457 minecraft:red_nether_bricks
fill 507 78 416 508 79 416 minecraft:orange_concrete
fill 507 78 417 509 78 417 minecraft:red_nether_bricks
fill 509 78 457 511 78 457 minecraft:red_nether_bricks
fill 510 78 458 511 79 458 minecraft:orange_concrete
fill 511 78 417 511 78 419 minecraft:red_nether_bricks
fill 511 78 421 511 78 423 minecraft:red_nether_bricks
fill 511 78 425 511 78 427 minecraft:red_nether_bricks
fill 511 78 429 511 78 431 minecraft:red_nether_bricks
fill 511 78 433 511 78 435 minecraft:red_nether_bricks
fill 511 78 437 511 78 439 minecraft:red_nether_bricks
fill 511 78 441 511 78 443 minecraft:red_nether_bricks
fill 511 78 445 511 78 447 minecraft:red_nether_bricks
fill 511 78 449 511 78 451 minecraft:red_nether_bricks
fill 511 78 453 511 78 455 minecraft:red_nether_bricks
fill 512 78 417 512 83 418 minecraft:red_nether_bricks
fill 512 78 419 512 78 420 minecraft:orange_concrete
fill 512 78 421 512 79 421 minecraft:red_nether_bricks
fill 512 78 429 512 83 430 minecraft:red_nether_bricks
fill 512 78 431 512 79 432 minecraft:orange_concrete
fill 512 78 438 512 83 438 minecraft:red_nether_bricks
fill 512 78 439 512 78 440 minecraft:orange_concrete
fill 512 78 441 512 79 442 minecraft:red_nether_bricks
fill 512 78 443 512 79 443 minecraft:orange_concrete
fill 512 78 449 512 83 450 minecraft:red_nether_bricks
fill 512 78 451 512 79 452 minecraft:orange_concrete
fill 512 78 458 512 83 458 minecraft:red_nether_bricks
fill 470 79 418 470 82 418 minecraft:red_nether_bricks
setblock 470 79 423 minecraft:orange_concrete
fill 470 79 428 470 83 429 minecraft:red_nether_bricks
setblock 470 79 434 minecraft:orange_concrete
fill 470 79 437 470 82 440 minecraft:red_nether_bricks
fill 470 79 448 470 83 449 minecraft:red_nether_bricks
setblock 470 79 455 minecraft:orange_concrete
setblock 470 79 458 minecraft:orange_concrete
fill 471 79 458 471 82 458 minecraft:red_nether_bricks
setblock 478 79 458 minecraft:orange_concrete
fill 482 79 458 482 82 458 minecraft:red_nether_bricks
fill 483 79 416 484 82 416 minecraft:red_nether_bricks
setblock 488 79 416 minecraft:orange_concrete
fill 498 79 458 499 79 458 minecraft:orange_concrete
setblock 499 79 416 minecraft:orange_concrete
fill 501 79 458 501 83 458 minecraft:red_nether_bricks
setblock 502 79 458 minecraft:orange_concrete
fill 503 79 458 503 82 458 minecraft:red_nether_bricks
fill 504 79 416 504 82 416 minecraft:red_nether_bricks
fill 512 79 419 512 82 419 minecraft:red_nether_bricks
setblock 512 79 420 minecraft:orange_concrete
fill 512 79 423 512 79 424 minecraft:orange_concrete
fill 512 79 439 512 81 440 minecraft:red_nether_bricks
setblock 512 79 444 minecraft:orange_concrete
setblock 512 79 455 minecraft:orange_concrete
fill 470 80 423 470 85 423 minecraft:red_nether_bricks
fill 470 80 424 470 80 425 minecraft:orange_concrete
fill 470 80 426 470 85 427 minecraft:red_nether_bricks
fill 470 80 432 470 81 433 minecraft:orange_concrete
fill 470 80 434 470 85 435 minecraft:red_nether_bricks
setblock 470 80 436 minecraft:orange_concrete
fill 470 80 444 470 81 445 minecraft:orange_concrete
fill 470 80 446 470 85 447 minecraft:red_nether_bricks
fill 470 80 453 470 81 453 minecraft:orange_concrete
fill 470 80 455 470 85 455 minecraft:red_nether_bricks
fill 470 80 456 470 80 457 minecraft:orange_concrete
fill 470 80 458 470 85 458 minecraft:red_nether_bricks
setblock 473 80 419 minecraft:light[level=14]
setblock 473 80 427 minecraft:light[level=14]
setblock 473 80 435 minecraft:light[level=14]
setblock 473 80 443 minecraft:light[level=14]
setblock 473 80 451 minecraft:light[level=14]
fill 475 80 416 476 85 416 minecraft:red_nether_bricks
fill 476 80 458 477 81 458 minecraft:orange_concrete
fill 477 80 416 478 81 416 minecraft:orange_concrete
fill 478 80 458 479 85 458 minecraft:red_nether_bricks
setblock 481 80 419 minecraft:light[level=14]
setblock 481 80 427 minecraft:light[level=14]
setblock 481 80 435 minecraft:light[level=14]
setblock 481 80 443 minecraft:light[level=14]
setblock 481 80 451 minecraft:light[level=14]
setblock 486 80 416 minecraft:orange_concrete
fill 487 80 416 488 85 416 minecraft:red_nether_bricks
fill 488 80 458 489 80 458 minecraft:orange_concrete
fill 489 80 416 490 81 416 minecraft:orange_concrete
setblock 489 80 419 minecraft:light[level=14]
setblock 489 80 427 minecraft:light[level=14]
setblock 489 80 435 minecraft:light[level=14]
setblock 489 80 443 minecraft:light[level=14]
setblock 489 80 451 minecraft:light[level=14]
fill 490 80 458 491 85 458 minecraft:red_nether_bricks
fill 495 80 416 496 85 416 minecraft:red_nether_bricks
fill 497 80 416 498 80 416 minecraft:orange_concrete
setblock 497 80 419 minecraft:light[level=14]
setblock 497 80 427 minecraft:light[level=14]
setblock 497 80 435 minecraft:light[level=14]
setblock 497 80 443 minecraft:light[level=14]
setblock 497 80 451 minecraft:light[level=14]
fill 497 80 458 497 81 458 minecraft:orange_concrete
fill 498 80 458 499 85 458 minecraft:red_nether_bricks
fill 499 80 416 499 85 416 minecraft:red_nether_bricks
setblock 500 80 458 minecraft:orange_concrete
fill 502 80 458 502 85 458 minecraft:red_nether_bricks
setblock 505 80 419 minecraft:light[level=14]
setblock 505 80 427 minecraft:light[level=14]
setblock 505 80 435 minecraft:light[level=14]
setblock 505 80 443 minecraft:light[level=14]
setblock 505 80 451 minecraft:light[level=14]
fill 507 80 416 508 85 416 minecraft:red_nether_bricks
fill 508 80 458 509 81 458 minecraft:orange_concrete
fill 509 80 416 510 81 416 minecraft:orange_concrete
fill 510 80 458 511 85 458 minecraft:red_nether_bricks
fill 512 80 420 512 85 420 minecraft:red_nether_bricks
fill 512 80 421 512 80 422 minecraft:orange_concrete
fill 512 80 423 512 81 424 minecraft:red_nether_bricks
fill 512 80 425 512 81 425 minecraft:orange_concrete
fill 512 80 431 512 85 432 minecraft:red_nether_bricks
fill 512 80 433 512 81 434 minecraft:orange_concrete
fill 512 80 441 512 83 441 minecraft:red_nether_bricks
setblock 512 80 442 minecraft:orange_concrete
fill 512 80 443 512 85 444 minecraft:red_nether_bricks
fill 512 80 445 512 81 446 minecraft:orange_concrete
fill 512 80 451 512 82 452 minecraft:red_nether_bricks
fill 512 80 453 512 80 454 minecraft:orange_concrete
fill 512 80 455 512 85 455 minecraft:red_nether_bricks
fill 470 81 420 470 81 421 minecraft:orange_concrete
setblock 470 81 424 minecraft:orange_concrete
fill 470 81 425 470 84 425 minecraft:red_nether_bricks
fill 470 81 436 470 84 436 minecraft:red_nether_bricks
setblock 470 81 441 minecraft:orange_concrete
setblock 470 81 452 minecraft:orange_concrete
fill 470 81 456 470 84 457 minecraft:red_nether_bricks
setblock 481 81 416 minecraft:orange_concrete
setblock 485 81 458 minecraft:orange_concrete
fill 486 81 416 486 84 416 minecraft:red_nether_bricks
setblock 488 81 458 minecraft:orange_concrete
fill 489 81 458 489 84 458 minecraft:red_nether_bricks
setblock 496 81 458 minecraft:orange_concrete
fill 497 81 416 497 84 416 minecraft:red_nether_bricks
setblock 498 81 416 minecraft:orange_concrete
fill 500 81 458 500 84 458 minecraft:red_nether_bricks
fill 501 81 416 502 81 416 minecraft:orange_concrete
fill 512 81 421 512 83 422 minecraft:red_nether_bricks
setblock 512 81 426 minecraft:orange_concrete
setblock 512 81 437 minecraft:orange_concrete
fill 512 81 442 512 83 442 minecraft:red_nether_bricks
fill 512 81 453 512 84 453 minecraft:red_nether_bricks
setblock 512 81 454 minecraft:orange_concrete
setblock 512 81 457 minecraft:orange_concrete
fill 470 82 419 470 83 419 minecraft:orange_concrete
fill 470 82 420 470 87 421 minecraft:red_nether_bricks
setblock 470 82 422 minecraft:orange_concrete
fill 470 82 424 470 87 424 minecraft:red_nether_bricks
fill 470 82 430 470 83 431 minecraft:orange_concrete
fill 470 82 432 470 87 433 minecraft:red_nether_bricks
fill 470 82 441 470 87 441 minecraft:red_nether_bricks
fill 470 82 442 470 82 443 minecraft:orange_concrete
fill 470 82 444 470 87 445 minecraft:red_nether_bricks
fill 470 82 450 470 83 451 minecraft:orange_concrete
fill 470 82 452 470 87 453 minecraft:red_nether_bricks
setblock 470 82 454 minecraft:orange_concrete
fill 471 82 416 472 83 416 minecraft:orange_concrete
fill 474 82 458 475 83 458 minecraft:orange_concrete
fill 476 82 458 477 87 458 minecraft:red_nether_bricks
fill 477 82 416 478 87 416 minecraft:red_nether_bricks
fill 479 82 416 480 82 416 minecraft:orange_concrete
fill 481 82 416 481 87 416 minecraft:red_nether_bricks
fill 483 82 458 483 83 458 minecraft:orange_concrete
fill 485 82 458 485 87 458 minecraft:red_nether_bricks
fill 486 82 458 487 82 458 minecraft:orange_concrete
fill 488 82 458 488 87 458 minecraft:red_nether_bricks
fill 489 82 416 490 87 416 minecraft:red_nether_bricks
fill 491 82 416 492 83 416 minecraft:orange_concrete
fill 494 82 458 495 83 458 minecraft:orange_concrete
fill 496 82 458 497 87 458 minecraft:red_nether_bricks
fill 498 82 416 498 87 416 minecraft:red_nether_bricks
setblock 500 82 416 minecraft:orange_concrete
fill 501 82 416 502 87 416 minecraft:red_nether_bricks
fill 503 82 416 503 83 416 minecraft:orange_concrete
fill 506 82 458 507 82 458 minecraft:orange_concrete
fill 508 82 458 509 87 458 minecraft:red_nether_bricks
fill 509 82 416 510 87 416 minecraft:red_nether_bricks
fill 511 82 416 512 82 416 minecraft:orange_concrete
fill 512 82 423 512 85 423 minecraft:red_nether_bricks
setblock 512 82 424 minecraft:orange_concrete
fill 512 82 425 512 87 426 minecraft:red_nether_bricks
fill 512 82 427 512 83 428 minecraft:orange_concrete
fill 512 82 433 512 84 434 minecraft:red_nether_bricks
fill 512 82 435 512 82 436 minecraft:orange_concrete
fill 512 82 437 512 87 437 minecraft:red_nether_bricks
fill 512 82 439 512 83 439 minecraft:orange_concrete
setblock 512 82 440 minecraft:red_nether_bricks
fill 512 82 445 512 87 446 minecraft:red_nether_bricks
fill 512 82 447 512 83 448 minecraft:orange_concrete
fill 512 82 454 512 84 454 minecraft:red_nether_bricks
setblock 512 82 456 minecraft:orange_concrete
fill 512 82 457 512 87 457 minecraft:red_nether_bricks
setblock 470 83 418 minecraft:orange_concrete
fill 470 83 422 470 86 422 minecraft:red_nether_bricks
setblock 470 83 437 minecraft:red_nether_bricks
fill 470 83 438 470 83 439 minecraft:orange_concrete
setblock 470 83 440 minecraft:red_nether_bricks
setblock 470 83 442 minecraft:orange_concrete
fill 470 83 443 470 86 443 minecraft:red_nether_bricks
fill 470 83 454 470 86 454 minecraft:red_nether_bricks
setblock 471 83 458 minecraft:orange_concrete
fill 479 83 416 479 86 416 minecraft:red_nether_bricks
setblock 480 83 416 minecraft:orange_concrete
setblock 482 83 458 minecraft:orange_concrete
fill 483 83 416 484 83 416 minecraft:orange_concrete
fill 486 83 458 487 86 458 minecraft:red_nether_bricks
fill 488 83 422 488 84 422 minecraft:netherrack
fill 500 83 416 500 86 416 minecraft:red_nether_bricks
setblock 503 83 458 minecraft:orange_concrete
setblock 504 83 416 minecraft:orange_concrete
setblock 506 83 458 minecraft:orange_concrete
fill 507 83 458 507 86 458 minecraft:red_nether_bricks
fill 511 83 416 511 86 416 minecraft:red_nether_bricks
setblock 512 83 416 minecraft:orange_concrete
setblock 512 83 419 minecraft:orange_concrete
fill 512 83 424 512 85 424 minecraft:red_nether_bricks
fill 512 83 435 512 86 435 minecraft:red_nether_bricks
setblock 512 83 436 minecraft:orange_concrete
setblock 512 83 440 minecraft:orange_concrete
setblock 512 83 451 minecraft:orange_concrete
fill 512 83 452 512 85 452 minecraft:red_nether_bricks
fill 512 83 456 512 86 456 minecraft:red_nether_bricks
fill 470 84 416 470 85 417 minecraft:orange_concrete
fill 470 84 418 470 89 419 minecraft:red_nether_bricks
fill 470 84 428 470 84 429 minecraft:orange_concrete
fill 470 84 430 470 89 431 minecraft:red_nether_bricks
fill 470 84 437 470 85 437 minecraft:orange_concrete
fill 470 84 438 470 89 439 minecraft:red_nether_bricks
setblock 470 84 440 minecraft:orange_concrete
fill 470 84 442 470 89 442 minecraft:red_nether_bricks
fill 470 84 448 470 85 449 minecraft:orange_concrete
fill 470 84 450 470 89 451 minecraft:red_nether_bricks
fill 471 84 416 472 84 417 minecraft:red_nether_bricks
fill 471 84 419 471 84 421 minecraft:red_nether_bricks
fill 471 84 423 471 84 425 minecraft:red_nether_bricks
fill 471 84 427 471 84 429 minecraft:red_nether_bricks
fill 471 84 431 471 84 433 minecraft:red_nether_bricks
fill 471 84 435 471 84 437 minecraft:red_nether_bricks
fill 471 84 439 471 84 441 minecraft:red_nether_bricks
fill 471 84 443 471 84 445 minecraft:red_nether_bricks
fill 471 84 447 471 84 449 minecraft:red_nether_bricks
fill 471 84 451 471 84 453 minecraft:red_nether_bricks
fill 471 84 455 471 84 458 minecraft:red_nether_bricks
fill 472 84 458 473 84 458 minecraft:orange_concrete
fill 473 84 416 474 85 416 minecraft:orange_concrete
setblock 473 84 417 minecraft:red_nether_bricks
fill 473 84 457 475 84 457 minecraft:red_nether_bricks
fill 474 84 458 475 89 458 minecraft:red_nether_bricks
fill 475 84 417 477 84 417 minecraft:red_nether_bricks
fill 477 84 457 479 84 457 minecraft:red_nether_bricks
fill 479 84 417 481 84 417 minecraft:red_nether_bricks
fill 480 84 416 480 89 416 minecraft:red_nether_bricks
fill 480 84 458 481 85 458 minecraft:orange_concrete
fill 481 84 457 483 84 457 minecraft:red_nether_bricks
setblock 482 84 416 minecraft:orange_concrete
fill 482 84 458 483 89 458 minecraft:red_nether_bricks
fill 483 84 416 484 84 417 minecraft:red_nether_bricks
setblock 484 84 458 minecraft:orange_concrete
fill 485 84 416 485 85 416 minecraft:orange_concrete
setblock 485 84 417 minecraft:red_nether_bricks
fill 485 84 457 487 84 457 minecraft:red_nether_bricks
fill 487 84 417 489 84 417 minecraft:red_nether_bricks
fill 489 84 457 491 84 457 minecraft:red_nether_bricks
fill 491 84 416 492 84 417 minecraft:red_nether_bricks
fill 492 84 458 493 85 458 minecraft:orange_concrete
fill 493 84 416 494 84 416 minecraft:orange_concrete
setblock 493 84 417 minecraft:red_nether_bricks
fill 493 84 457 495 84 457 minecraft:red_nether_bricks
fill 494 84 458 495 89 458 minecraft:red_nether_bricks
fill 495 84 417 497 84 417 minecraft:red_nether_bricks
fill 497 84 457 499 84 457 minecraft:red_nether_bricks
fill 499 84 417 501 84 417 minecraft:red_nether_bricks
fill 501 84 457 503 84 457 minecraft:red_nether_bricks
fill 501 84 458 501 85 458 minecraft:orange_concrete
fill 503 84 416 504 84 417 minecraft:red_nether_bricks
fill 503 84 458 503 89 458 minecraft:red_nether_bricks
fill 504 84 458 505 84 458 minecraft:orange_concrete
fill 505 84 416 506 85 416 minecraft:orange_concrete
setblock 505 84 417 minecraft:red_nether_bricks
fill 505 84 457 507 84 457 minecraft:red_nether_bricks
fill 506 84 458 506 89 458 minecraft:red_nether_bricks
fill 507 84 417 509 84 417 minecraft:red_nether_bricks
fill 509 84 457 511 84 457 minecraft:red_nether_bricks
fill 511 84 417 511 84 419 minecraft:red_nether_bricks
fill 511 84 421 511 84 423 minecraft:red_nether_bricks
fill 511 84 425 511 84 427 minecraft:red_nether_bricks
fill 511 84 429 511 84 431 minecraft:red_nether_bricks
fill 511 84 433 511 84 435 minecraft:red_nether_bricks
fill 511 84 437 511 84 439 minecraft:red_nether_bricks
fill 511 84 441 511 84 443 minecraft:red_nether_bricks
fill 511 84 445 511 84 447 minecraft:red_nether_bricks
fill 511 84 449 511 84 451 minecraft:red_nether_bricks
fill 511 84 453 511 84 455 minecraft:red_nether_bricks
fill 512 84 416 512 89 416 minecraft:red_nether_bricks
fill 512 84 417 512 84 418 minecraft:orange_concrete
fill 512 84 419 512 89 419 minecraft:red_nether_bricks
fill 512 84 421 512 85 421 minecraft:orange_concrete
setblock 512 84 422 minecraft:red_nether_bricks
fill 512 84 427 512 89 428 minecraft:red_nether_bricks
fill 512 84 429 512 85 430 minecraft:orange_concrete
fill 512 84 436 512 86 436 minecraft:red_nether_bricks
setblock 512 84 438 minecraft:orange_concrete
fill 512 84 439 512 89 440 minecraft:red_nether_bricks
fill 512 84 441 512 85 442 minecraft:orange_concrete
fill 512 84 447 512 89 448 minecraft:red_nether_bricks
fill 512 84 449 512 84 450 minecraft:orange_concrete
fill 512 84 451 512 85 451 minecraft:red_nether_bricks
fill 512 84 458 512 85 458 minecraft:orange_concrete
setblock 470 85 425 minecraft:orange_concrete
setblock 470 85 428 minecraft:orange_concrete
fill 470 85 429 470 88 429 minecraft:red_nether_bricks
setblock 470 85 436 minecraft:orange_concrete
fill 470 85 440 470 88 440 minecraft:red_nether_bricks
fill 470 85 456 470 85 457 minecraft:orange_concrete
fill 471 85 416 472 89 416 minecraft:red_nether_bricks
fill 471 85 458 471 89 458 minecraft:red_nether_bricks
setblock 472 85 458 minecraft:orange_concrete
fill 473 85 458 473 88 458 minecraft:red_nether_bricks
fill 482 85 416 484 88 416 minecraft:red_nether_bricks
fill 484 85 458 484 88 458 minecraft:red_nether_bricks
setblock 486 85 416 minecraft:orange_concrete
setblock 489 85 458 minecraft:orange_concrete
fill 491 85 416 493 88 416 minecraft:red_nether_bricks
setblock 494 85 416 minecraft:orange_concrete
setblock 497 85 416 minecraft:orange_concrete
setblock 500 85 458 minecraft:orange_concrete
fill 503 85 416 504 89 416 minecraft:red_nether_bricks
fill 504 85 458 505 88 458 minecraft:red_nether_bricks
fill 512 85 417 512 88 418 minecraft:red_nether_bricks
setblock 512 85 422 minecraft:orange_concrete
setblock 512 85 433 minecraft:orange_concrete
fill 512 85 434 512 87 434 minecraft:red_nether_bricks
fill 512 85 438 512 88 438 minecraft:red_nether_bricks
fill 512 85 449 512 88 449 minecraft:red_nether_bricks
setblock 512 85 450 minecraft:orange_concrete
fill 512 85 453 512 85 454 minecraft:orange_concrete
fill 470 86 416 470 91 417 minecraft:red_nether_bricks
fill 470 86 423 470 87 423 minecraft:orange_concrete
fill 470 86 425 470 91 425 minecraft:red_nether_bricks
fill 470 86 426 470 86 427 minecraft:orange_concrete
fill 470 86 428 470 91 428 minecraft:red_nether_bricks
fill 470 86 434 470 87 435 minecraft:orange_concrete
fill 470 86 436 470 91 437 minecraft:red_nether_bricks
fill 470 86 446 470 86 447 minecraft:orange_concrete
fill 470 86 448 470 91 449 minecraft:red_nether_bricks
fill 470 86 455 470 87 455 minecraft:orange_concrete
fill 470 86 456 470 91 457 minecraft:red_nether_bricks
setblock 470 86 458 minecraft:orange_concrete
fill 472 86 458 472 91 458 minecraft:red_nether_bricks
fill 473 86 416 474 91 416 minecraft:red_nether_bricks
fill 475 86 416 476 86 416 minecraft:orange_concrete
fill 478 86 458 479 87 458 minecraft:orange_concrete
fill 480 86 458 481 91 458 minecraft:red_nether_bricks
fill 485 86 416 486 91 416 minecraft:red_nether_bricks
fill 487 86 416 488 87 416 minecraft:orange_concrete
fill 489 86 458 489 91 458 minecraft:red_nether_bricks
fill 490 86 458 491 86 458 minecraft:orange_concrete
fill 492 86 458 493 91 458 minecraft:red_nether_bricks
fill 494 86 416 494 91 416 minecraft:red_nether_bricks
fill 495 86 416 496 86 416 minecraft:orange_concrete
fill 497 86 416 497 91 416 minecraft:red_nether_bricks
fill 498 86 458 499 87 458 minecraft:orange_concrete
fill 499 86 416 499 87 416 minecraft:orange_concrete
fill 500 86 458 501 91 458 minecraft:red_nether_bricks
setblock 502 86 458 minecraft:orange_concrete
fill 505 86 416 506 91 416 minecraft:red_nether_bricks
fill 507 86 416 508 87 416 minecraft:orange_concrete
fill 510 86 458 511 87 458 minecraft:orange_concrete
setblock 512 86 420 minecraft:orange_concrete
fill 512 86 421 512 91 422 minecraft:red_nether_bricks
fill 512 86 423 512 87 424 minecraft:orange_concrete
fill 512 86 429 512 91 430 minecraft:red_nether_bricks
fill 512 86 431 512 86 432 minecraft:orange_concrete
fill 512 86 433 512 87 433 minecraft:red_nether_bricks
fill 512 86 441 512 91 442 minecraft:red_nether_bricks
fill 512 86 443 512 87 444 minecraft:orange_concrete
fill 512 86 450 512 91 450 minecraft:red_nether_bricks
fill 512 86 451 512 86 452 minecraft:orange_concrete
fill 512 86 453 512 87 454 minecraft:red_nether_bricks
fill 512 86 455 512 87 455 minecraft:orange_concrete
fill 512 86 458 512 91 458 minecraft:red_nether_bricks
setblock 470 87 422 minecraft:orange_concrete
fill 470 87 426 470 90 427 minecraft:red_nether_bricks
setblock 470 87 443 minecraft:orange_concrete
setblock 470 87 446 minecraft:orange_concrete
fill 470 87 447 470 90 447 minecraft:red_nether_bricks
setblock 470 87 454 minecraft:orange_concrete
fill 470 87 458 470 90 458 minecraft:red_nether_bricks
fill 475 87 416 475 90 416 minecraft:red_nether_bricks
setblock 476 87 416 minecraft:orange_concrete
setblock 479 87 416 minecraft:orange_concrete
fill 486 87 458 487 87 458 minecraft:orange_concrete
setblock 490 87 458 minecraft:orange_concrete
fill 491 87 458 491 90 458 minecraft:red_nether_bricks
fill 495 87 416 496 90 416 minecraft:red_nether_bricks
setblock 500 87 416 minecraft:orange_concrete
fill 502 87 458 502 90 458 minecraft:red_nether_bricks
setblock 507 87 458 minecraft:orange_concrete
setblock 511 87 416 minecraft:orange_concrete
fill 512 87 420 512 90 420 minecraft:red_nether_bricks
fill 512 87 431 512 90 431 minecraft:red_nether_bricks
setblock 512 87 432 minecraft:orange_concrete
fill 512 87 435 512 87 436 minecraft:orange_concrete
fill 512 87 451 512 89 452 minecraft:red_nether_bricks
setblock 512 87 456 minecraft:orange_concrete
fill 470 88 420 470 89 421 minecraft:orange_concrete
fill 470 88 422 470 93 423 minecraft:red_nether_bricks
setblock 470 88 424 minecraft:orange_concrete
fill 470 88 432 470 89 433 minecraft:orange_concrete
fill 470 88 434 470 93 435 minecraft:red_nether_bricks
fill 470 88 441 470 89 441 minecraft:orange_concrete
fill 470 88 443 470 93 443 minecraft:red_nether_bricks
fill 470 88 444 470 88 445 minecraft:orange_concrete
fill 470 88 446 470 93 446 minecraft:red_nether_bricks
fill 470 88 452 470 89 453 minecraft:orange_concrete
fill 470 88 454 470 93 455 minecraft:red_nether_bricks
setblock 473 88 419 minecraft:light[level=14]
setblock 473 88 427 minecraft:light[level=14]
setblock 473 88 435 minecraft:light[level=14]
setblock 473 88 443 minecraft:light[level=14]
setblock 473 88 451 minecraft:light[level=14]
fill 476 88 416 476 93 416 minecraft:red_nether_bricks
fill 476 88 458 477 88 458 minecraft:orange_concrete
fill 477 88 416 478 88 416 minecraft:orange_concrete
fill 478 88 458 479 93 458 minecraft:red_nether_bricks
fill 479 88 416 479 93 416 minecraft:red_nether_bricks
fill 481 88 416 481 89 416 minecraft:orange_concrete
setblock 481 88 419 minecraft:light[level=14]
setblock 481 88 427 minecraft:light[level=14]
setblock 481 88 435 minecraft:light[level=14]
setblock 481 88 443 minecraft:light[level=14]
setblock 481 88 451 minecraft:light[level=14]
fill 485 88 458 485 89 458 minecraft:orange_concrete
fill 486 88 458 487 93 458 minecraft:red_nether_bricks
fill 487 88 416 488 93 416 minecraft:red_nether_bricks
setblock 488 88 458 minecraft:orange_concrete
fill 489 88 416 490 89 416 minecraft:orange_concrete
setblock 489 88 419 minecraft:light[level=14]
setblock 489 88 427 minecraft:light[level=14]
setblock 489 88 435 minecraft:light[level=14]
setblock 489 88 443 minecraft:light[level=14]
setblock 489 88 451 minecraft:light[level=14]
fill 490 88 458 490 93 458 minecraft:red_nether_bricks
fill 496 88 458 497 89 458 minecraft:orange_concrete
setblock 497 88 419 minecraft:light[level=14]
setblock 497 88 427 minecraft:light[level=14]
setblock 497 88 435 minecraft:light[level=14]
setblock 497 88 443 minecraft:light[level=14]
setblock 497 88 451 minecraft:light[level=14]
setblock 498 88 416 minecraft:orange_concrete
fill 498 88 458 499 93 458 minecraft:red_nether_bricks
fill 499 88 416 500 93 416 minecraft:red_nether_bricks
fill 501 88 416 502 89 416 minecraft:orange_concrete
setblock 505 88 419 minecraft:light[level=14]
setblock 505 88 427 minecraft:light[level=14]
setblock 505 88 435 minecraft:light[level=14]
setblock 505 88 443 minecraft:light[level=14]
setblock 505 88 451 minecraft:light[level=14]
fill 507 88 416 508 93 416 minecraft:red_nether_bricks
fill 507 88 458 507 93 458 minecraft:red_nether_bricks
fill 508 88 458 509 88 458 minecraft:orange_concrete
fill 509 88 416 510 88 416 minecraft:orange_concrete
fill 510 88 458 511 90 458 minecraft:red_nether_bricks
fill 511 88 416 511 93 416 minecraft:red_nether_bricks
fill 512 88 423 512 93 424 minecraft:red_nether_bricks
fill 512 88 425 512 89 426 minecraft:orange_concrete
fill 512 88 432 512 93 432 minecraft:red_nether_bricks
fill 512 88 433 512 88 434 minecraft:orange_concrete
fill 512 88 435 512 89 436 minecraft:red_nether_bricks
fill 512 88 437 512 89 437 minecraft:orange_concrete
fill 512 88 443 512 93 444 minecraft:red_nether_bricks
fill 512 88 445 512 89 446 minecraft:orange_concrete
fill 512 88 453 512 91 453 minecraft:red_nether_bricks
setblock 512 88 454 minecraft:orange_concrete
fill 512 88 455 512 93 456 minecraft:red_nether_bricks
fill 512 88 457 512 89 457 minecraft:orange_concrete
fill 470 89 424 470 92 424 minecraft:red_nether_bricks
setblock 470 89 429 minecraft:orange_concrete
setblock 470 89 440 minecraft:orange_concrete
fill 470 89 444 470 92 445 minecraft:red_nether_bricks
setblock 473 89 458 minecraft:orange_concrete
setblock 476 89 458 minecraft:orange_concrete
fill 477 89 416 478 92 416 minecraft:red_nether_bricks
fill 477 89 458 477 92 458 minecraft:red_nether_bricks
setblock 482 89 416 minecraft:orange_concrete
fill 483 89 416 484 89 416 minecraft:red_nether_bricks
setblock 484 89 458 minecraft:orange_concrete
fill 488 89 458 488 92 458 minecraft:red_nether_bricks
fill 491 89 416 492 89 416 minecraft:red_nether_bricks
setblock 493 89 416 minecraft:orange_concrete
fill 498 89 416 498 92 416 minecraft:red_nether_bricks
fill 504 89 458 505 89 458 minecraft:orange_concrete
fill 506 89 449 508 90 449 minecraft:magma_block
setblock 508 89 458 minecraft:orange_concrete
fill 509 89 416 509 92 416 minecraft:red_nether_bricks
fill 509 89 458 509 92 458 minecraft:red_nether_bricks
setblock 510 89 416 minecraft:orange_concrete
fill 512 89 417 512 89 418 minecraft:orange_concrete
fill 512 89 433 512 91 434 minecraft:red_nether_bricks
setblock 512 89 438 minecraft:orange_concrete
setblock 512 89 449 minecraft:orange_concrete
fill 512 89 454 512 91 454 minecraft:red_nether_bricks
fill 470 90 418 470 91 419 minecraft:orange_concrete
fill 470 90 420 471 90 421 minecraft:red_nether_bricks
fill 470 90 429 471 90 429 minecraft:red_nether_bricks
fill 470 90 430 470 90 431 minecraft:orange_concrete
fill 470 90 432 471 90 433 minecraft:red_nether_bricks
fill 470 90 438 470 91 439 minecraft:orange_concrete
fill 470 90 440 471 90 441 minecraft:red_nether_bricks
setblock 470 90 442 minecraft:orange_concrete
fill 470 90 450 470 91 451 minecraft:orange_concrete
fill 470 90 452 471 90 453 minecraft:red_nether_bricks
fill 471 90 416 472 91 416 minecraft:orange_concrete
fill 471 90 417 473 90 417 minecraft:red_nether_bricks
setblock 471 90 419 minecraft:red_nether_bricks
fill 471 90 423 471 90 425 minecraft:red_nether_bricks
fill 471 90 427 471 90 428 minecraft:red_nether_bricks
setblock 471 90 431 minecraft:red_nether_bricks
fill 471 90 435 471 90 437 minecraft:red_nether_bricks
setblock 471 90 439 minecraft:red_nether_bricks
fill 471 90 443 471 90 445 minecraft:red_nether_bricks
fill 471 90 447 471 90 449 minecraft:red_nether_bricks
setblock 471 90 451 minecraft:red_nether_bricks
fill 471 90 455 471 90 457 minecraft:red_nether_bricks
fill 471 90 458 471 91 458 minecraft:orange_concrete
fill 473 90 457 473 90 458 minecraft:red_nether_bricks
fill 474 90 457 475 90 457 minecraft:red_nether_bricks
fill 474 90 458 475 90 458 minecraft:orange_concrete
fill 475 90 417 477 90 417 minecraft:red_nether_bricks
fill 476 90 458 476 95 458 minecraft:red_nether_bricks
fill 477 90 457 479 90 457 minecraft:red_nether_bricks
fill 479 90 417 481 90 417 minecraft:red_nether_bricks
setblock 480 90 416 minecraft:orange_concrete
fill 481 90 416 482 95 416 minecraft:red_nether_bricks
fill 481 90 457 483 90 457 minecraft:red_nether_bricks
fill 482 90 458 483 91 458 minecraft:orange_concrete
fill 483 90 416 484 91 416 minecraft:orange_concrete
fill 483 90 417 485 90 417 minecraft:red_nether_bricks
fill 484 90 458 485 95 458 minecraft:red_nether_bricks
fill 485 90 457 487 90 457 minecraft:red_nether_bricks
fill 487 90 417 489 90 417 minecraft:red_nether_bricks
fill 489 90 416 490 95 416 minecraft:red_nether_bricks
fill 489 90 457 491 90 457 minecraft:red_nether_bricks
fill 491 90 416 492 90 416 minecraft:orange_concrete
fill 491 90 417 493 90 417 minecraft:red_nether_bricks
fill 493 90 416 493 95 416 minecraft:red_nether_bricks
fill 493 90 457 495 90 457 minecraft:red_nether_bricks
fill 494 90 458 495 90 458 minecraft:orange_concrete
fill 495 90 417 497 90 417 minecraft:red_nether_bricks
fill 496 90 458 497 95 458 minecraft:red_nether_bricks
fill 497 90 457 499 90 457 minecraft:red_nether_bricks
fill 499 90 417 501 90 417 minecraft:red_nether_bricks
fill 501 90 416 502 95 416 minecraft:red_nether_bricks
fill 501 90 457 503 90 457 minecraft:red_nether_bricks
fill 502 90 442 503 91 443 minecraft:magma_block
fill 503 90 416 504 91 416 minecraft:orange_concrete
fill 503 90 417 505 90 417 minecraft:red_nether_bricks
fill 503 90 458 503 91 458 minecraft:orange_concrete
fill 504 90 458 505 95 458 minecraft:red_nether_bricks
fill 505 90 457 507 90 457 minecraft:red_nether_bricks
setblock 506 90 458 minecraft:orange_concrete
fill 507 90 417 509 90 417 minecraft:red_nether_bricks
fill 507 90 448 511 90 448 minecraft:magma_block
fill 507 90 450 510 90 450 minecraft:magma_block
fill 508 90 458 508 92 458 minecraft:red_nether_bricks
fill 509 90 449 510 93 449 minecraft:magma_block
fill 509 90 457 512 90 457 minecraft:red_nether_bricks
fill 510 90 416 510 95 416 minecraft:red_nether_bricks
fill 511 90 417 511 90 419 minecraft:red_nether_bricks
fill 511 90 421 511 90 423 minecraft:red_nether_bricks
fill 511 90 425 511 90 427 minecraft:red_nether_bricks
fill 511 90 429 511 90 431 minecraft:red_nether_bricks
fill 511 90 433 511 90 435 minecraft:red_nether_bricks
fill 511 90 437 511 90 439 minecraft:red_nether_bricks
fill 511 90 441 511 90 443 minecraft:red_nether_bricks
fill 511 90 445 511 90 447 minecraft:red_nether_bricks
fill 511 90 449 511 90 451 minecraft:red_nether_bricks
fill 511 90 453 511 90 455 minecraft:red_nether_bricks
setblock 512 90 416 minecraft:orange_concrete
fill 512 90 417 512 95 418 minecraft:red_nether_bricks
fill 512 90 419 512 91 419 minecraft:orange_concrete
fill 512 90 425 512 95 426 minecraft:red_nether_bricks
fill 512 90 427 512 90 428 minecraft:orange_concrete
fill 512 90 435 512 93 435 minecraft:red_nether_bricks
setblock 512 90 436 minecraft:orange_concrete
fill 512 90 437 512 95 438 minecraft:red_nether_bricks
fill 512 90 439 512 91 440 minecraft:orange_concrete
fill 512 90 445 512 92 446 minecraft:red_nether_bricks
fill 512 90 447 512 90 448 minecraft:orange_concrete
fill 512 90 449 512 95 449 minecraft:red_nether_bricks
fill 512 90 451 512 91 451 minecraft:orange_concrete
setblock 512 90 452 minecraft:red_nether_bricks
fill 470 91 420 470 95 421 minecraft:red_nether_bricks
fill 470 91 426 470 91 427 minecraft:orange_concrete
fill 470 91 429 470 95 429 minecraft:red_nether_bricks
setblock 470 91 430 minecraft:orange_concrete
fill 470 91 431 470 94 433 minecraft:red_nether_bricks
fill 470 91 440 470 94 442 minecraft:red_nether_bricks
setblock 470 91 447 minecraft:orange_concrete
fill 470 91 452 470 95 453 minecraft:red_nether_bricks
setblock 470 91 458 minecraft:orange_concrete
fill 473 91 458 475 94 458 minecraft:red_nether_bricks
setblock 475 91 416 minecraft:orange_concrete
fill 480 91 416 480 94 416 minecraft:red_nether_bricks
fill 491 91 416 491 94 416 minecraft:red_nether_bricks
setblock 491 91 458 minecraft:orange_concrete
setblock 492 91 416 minecraft:orange_concrete
setblock 494 91 458 minecraft:orange_concrete
fill 495 91 416 496 91 416 minecraft:orange_concrete
fill 495 91 458 495 94 458 minecraft:red_nether_bricks
fill 496 91 419 496 92 420 minecraft:magma_block
setblock 502 91 458 minecraft:orange_concrete
fill 506 91 458 506 94 458 minecraft:red_nether_bricks
fill 507 91 449 508 91 449 minecraft:magma_block
fill 508 91 448 511 92 448 minecraft:magma_block
fill 508 91 450 511 92 450 minecraft:magma_block
fill 509 91 447 511 92 447 minecraft:magma_block
fill 509 91 451 511 92 451 minecraft:magma_block
fill 510 91 458 510 93 458 minecraft:red_nether_bricks
fill 511 91 449 511 93 449 minecraft:magma_block
setblock 511 91 458 minecraft:orange_concrete
fill 512 91 416 512 94 416 minecraft:red_nether_bricks
setblock 512 91 420 minecraft:orange_concrete
fill 512 91 427 512 94 427 minecraft:red_nether_bricks
setblock 512 91 428 minecraft:orange_concrete
setblock 512 91 431 minecraft:orange_concrete
fill 512 91 436 512 93 436 minecraft:red_nether_bricks
fill 512 91 447 512 94 447 minecraft:red_nether_bricks
setblock 512 91 448 minecraft:orange_concrete
setblock 512 91 452 minecraft:orange_concrete
fill 512 91 457 512 95 457 minecraft:red_nether_bricks
fill 470 92 416 470 92 417 minecraft:orange_concrete
fill 470 92 418 470 97 419 minecraft:red_nether_bricks
fill 470 92 425 470 93 425 minecraft:orange_concrete
fill 470 92 426 470 97 427 minecraft:red_nether_bricks
setblock 470 92 428 minecraft:orange_concrete
fill 470 92 430 470 97 430 minecraft:red_nether_bricks
fill 470 92 436 470 93 437 minecraft:orange_concrete
fill 470 92 438 470 97 439 minecraft:red_nether_bricks
fill 470 92 447 470 97 447 minecraft:red_nether_bricks
fill 470 92 448 470 92 449 minecraft:orange_concrete
fill 470 92 450 470 97 451 minecraft:red_nether_bricks
fill 470 92 456 470 93 457 minecraft:orange_concrete
fill 470 92 458 471 97 458 minecraft:red_nether_bricks
fill 471 92 416 472 97 416 minecraft:red_nether_bricks
setblock 472 92 458 minecraft:orange_concrete
fill 473 92 416 474 92 416 minecraft:orange_concrete
fill 475 92 416 475 97 416 minecraft:red_nether_bricks
fill 480 92 458 481 93 458 minecraft:orange_concrete
fill 482 92 458 483 97 458 minecraft:red_nether_bricks
fill 483 92 416 484 97 416 minecraft:red_nether_bricks
fill 485 92 416 486 93 416 minecraft:orange_concrete
fill 489 92 458 489 93 458 minecraft:orange_concrete
fill 491 92 458 491 97 458 minecraft:red_nether_bricks
fill 492 92 416 492 97 416 minecraft:red_nether_bricks
fill 492 92 458 493 92 458 minecraft:orange_concrete
setblock 494 92 416 minecraft:orange_concrete
fill 494 92 458 494 97 458 minecraft:red_nether_bricks
fill 495 92 416 496 97 416 minecraft:red_nether_bricks
fill 497 92 416 497 93 416 minecraft:orange_concrete
fill 500 92 458 501 93 458 minecraft:orange_concrete
fill 502 92 458 503 97 458 minecraft:red_nether_bricks
fill 503 92 416 504 97 416 minecraft:red_nether_bricks
fill 505 92 416 506 92 416 minecraft:orange_concrete
setblock 508 92 449 minecraft:magma_block
fill 511 92 458 511 93 458 minecraft:red_nether_bricks
fill 512 92 419 512 97 420 minecraft:red_nether_bricks
fill 512 92 421 512 93 422 minecraft:orange_concrete
fill 512 92 428 512 97 428 minecraft:red_nether_bricks
fill 512 92 429 512 92 430 minecraft:orange_concrete
fill 512 92 431 512 97 431 minecraft:red_nether_bricks
fill 512 92 433 512 93 433 minecraft:orange_concrete
setblock 512 92 434 minecraft:red_nether_bricks
fill 512 92 439 512 97 440 minecraft:red_nether_bricks
fill 512 92 441 512 93 442 minecraft:orange_concrete
fill 512 92 448 512 94 448 minecraft:red_nether_bricks
setblock 512 92 450 minecraft:orange_concrete
fill 512 92 451 512 97 452 minecraft:red_nether_bricks
fill 512 92 453 512 93 454 minecraft:orange_concrete
fill 512 92 458 512 93 458 minecraft:orange_concrete
setblock 470 93 416 minecraft:orange_concrete
fill 470 93 417 470 96 417 minecraft:red_nether_bricks
setblock 470 93 424 minecraft:orange_concrete
fill 470 93 428 470 96 428 minecraft:red_nether_bricks
fill 470 93 444 470 93 445 minecraft:orange_concrete
setblock 470 93 448 minecraft:orange_concrete
fill 470 93 449 470 96 449 minecraft:red_nether_bricks
fill 472 93 458 472 96 458 minecraft:red_nether_bricks
fill 473 93 416 473 96 416 minecraft:red_nether_bricks
setblock 474 93 416 minecraft:orange_concrete
fill 477 93 416 478 93 416 minecraft:orange_concrete
setblock 477 93 458 minecraft:orange_concrete
setblock 488 93 458 minecraft:orange_concrete
fill 492 93 458 493 96 458 minecraft:red_nether_bricks
fill 494 93 416 494 96 416 minecraft:red_nether_bricks
setblock 498 93 416 minecraft:orange_concrete
fill 505 93 416 505 96 416 minecraft:red_nether_bricks
setblock 506 93 416 minecraft:orange_concrete
fill 508 93 458 509 93 458 minecraft:orange_concrete
setblock 509 93 416 minecraft:orange_concrete
fill 509 93 448 511 93 448 minecraft:magma_block
fill 509 93 450 511 93 450 minecraft:magma_block
fill 512 93 429 512 96 430 minecraft:red_nether_bricks
setblock 512 93 434 minecraft:orange_concrete
setblock 512 93 445 minecraft:orange_concrete
fill 512 93 446 512 95 446 minecraft:red_nether_bricks
fill 512 93 450 512 96 450 minecraft:red_nether_bricks
fill 470 94 416 470 99 416 minecraft:red_nether_bricks
fill 470 94 422 470 95 423 minecraft:orange_concrete
fill 470 94 424 470 99 425 minecraft:red_nether_bricks
fill 470 94 434 470 94 435 minecraft:orange_concrete
fill 470 94 436 470 99 437 minecraft:red_nether_bricks
fill 470 94 443 470 95 443 minecraft:orange_concrete
fill 470 94 444 470 99 445 minecraft:red_nether_bricks
setblock 470 94 446 minecraft:orange_concrete
fill 470 94 448 470 99 448 minecraft:red_nether_bricks
fill 470 94 454 470 95 455 minecraft:orange_concrete
fill 470 94 456 470 99 457 minecraft:red_nether_bricks
fill 474 94 416 474 99 416 minecraft:red_nether_bricks
setblock 476 94 416 minecraft:orange_concrete
fill 477 94 416 478 99 416 minecraft:red_nether_bricks
fill 477 94 458 477 99 458 minecraft:red_nether_bricks
fill 478 94 458 479 94 458 minecraft:orange_concrete
fill 479 94 416 479 95 416 minecraft:orange_concrete
fill 480 94 458 481 99 458 minecraft:red_nether_bricks
fill 485 94 416 486 99 416 minecraft:red_nether_bricks
fill 486 94 458 487 95 458 minecraft:orange_concrete
fill 487 94 416 488 94 416 minecraft:orange_concrete
fill 488 94 458 489 99 458 minecraft:red_nether_bricks
setblock 490 94 458 minecraft:orange_concrete
fill 497 94 416 498 99 416 minecraft:red_nether_bricks
fill 498 94 458 499 95 458 minecraft:orange_concrete
fill 499 94 416 500 95 416 minecraft:orange_concrete
fill 500 94 458 501 99 458 minecraft:red_nether_bricks
fill 506 94 416 506 99 416 minecraft:red_nether_bricks
fill 507 94 416 508 94 416 minecraft:orange_concrete
fill 507 94 458 507 95 458 minecraft:orange_concrete
fill 508 94 458 509 95 458 minecraft:red_nether_bricks
fill 509 94 416 509 99 416 minecraft:red_nether_bricks
fill 510 94 458 511 94 458 minecraft:orange_concrete
fill 511 94 416 511 95 416 minecraft:orange_concrete
fill 512 94 421 512 99 422 minecraft:red_nether_bricks
fill 512 94 423 512 95 424 minecraft:orange_concrete
setblock 512 94 432 minecraft:orange_concrete
fill 512 94 433 512 99 434 minecraft:red_nether_bricks
fill 512 94 435 512 95 436 minecraft:orange_concrete
fill 512 94 441 512 99 442 minecraft:red_nether_bricks
fill 512 94 443 512 94 444 minecraft:orange_concrete
fill 512 94 445 512 95 445 minecraft:red_nether_bricks
fill 512 94 453 512 99 454 minecraft:red_nether_bricks
fill 512 94 455 512 95 456 minecraft:orange_concrete
fill 512 94 458 512 99 458 minecraft:red_nether_bricks
setblock 470 95 431 minecraft:orange_concrete
fill 470 95 432 470 95 433 minecraft:red_nether_bricks
setblock 470 95 434 minecraft:orange_concrete
fill 470 95 435 470 98 435 minecraft:red_nether_bricks
fill 470 95 440 470 95 441 minecraft:red_nether_bricks
setblock 470 95 442 minecraft:orange_concrete
fill 470 95 446 470 98 446 minecraft:red_nether_bricks
setblock 473 95 458 minecraft:red_nether_bricks
fill 474 95 458 475 95 458 minecraft:orange_concrete
fill 476 95 416 476 98 416 minecraft:red_nether_bricks
setblock 478 95 458 minecraft:orange_concrete
fill 479 95 458 479 98 458 minecraft:red_nether_bricks
setblock 480 95 416 minecraft:orange_concrete
fill 487 95 416 487 98 416 minecraft:red_nether_bricks
setblock 488 95 416 minecraft:orange_concrete
fill 490 95 458 490 98 458 minecraft:red_nether_bricks
setblock 491 95 416 minecraft:orange_concrete
setblock 495 95 458 minecraft:orange_concrete
setblock 506 95 458 minecraft:orange_concrete
fill 507 95 416 508 98 416 minecraft:red_nether_bricks
fill 510 95 458 511 97 458 minecraft:red_nether_bricks
setblock 512 95 416 minecraft:orange_concrete
setblock 512 95 427 minecraft:orange_concrete
fill 512 95 432 512 98 432 minecraft:red_nether_bricks
fill 512 95 443 512 98 443 minecraft:red_nether_bricks
setblock 512 95 444 minecraft:orange_concrete
fill 512 95 447 512 95 448 minecraft:orange_concrete
fill 470 96 420 470 97 421 minecraft:orange_concrete
fill 470 96 422 470 101 423 minecraft:red_nether_bricks
fill 470 96 429 470 97 429 minecraft:orange_concrete
fill 470 96 431 471 96 431 minecraft:red_nether_bricks
fill 470 96 432 470 96 433 minecraft:orange_concrete
fill 470 96 434 470 101 434 minecraft:red_nether_bricks
fill 470 96 440 470 97 441 minecraft:orange_concrete
fill 470 96 442 470 101 443 minecraft:red_nether_bricks
fill 470 96 452 470 96 453 minecraft:orange_concrete
fill 470 96 454 470 101 455 minecraft:red_nether_bricks
fill 471 96 417 473 96 417 minecraft:red_nether_bricks
fill 471 96 419 471 96 421 minecraft:red_nether_bricks
fill 471 96 423 471 96 425 minecraft:red_nether_bricks
fill 471 96 427 471 96 429 minecraft:red_nether_bricks
fill 471 96 432 471 96 433 minecraft:red_nether_bricks
fill 471 96 435 471 96 437 minecraft:red_nether_bricks
fill 471 96 439 471 96 441 minecraft:red_nether_bricks
fill 471 96 443 471 96 445 minecraft:red_nether_bricks
fill 471 96 447 471 96 449 minecraft:red_nether_bricks
fill 471 96 451 471 96 453 minecraft:red_nether_bricks
fill 471 96 455 471 96 457 minecraft:red_nether_bricks
setblock 473 96 419 minecraft:light[level=14]
setblock 473 96 427 minecraft:light[level=14]
setblock 473 96 435 minecraft:light[level=14]
setblock 473 96 443 minecraft:light[level=14]
setblock 473 96 451 minecraft:light[level=14]
fill 473 96 457 475 96 457 minecraft:red_nether_bricks
fill 473 96 458 473 97 458 minecraft:orange_concrete
fill 474 96 458 475 101 458 minecraft:red_nether_bricks
fill 475 96 417 477 96 417 minecraft:red_nether_bricks
setblock 476 96 458 minecraft:orange_concrete
fill 477 96 457 479 96 457 minecraft:red_nether_bricks
fill 478 96 458 478 101 458 minecraft:red_nether_bricks
fill 479 96 416 480 96 417 minecraft:red_nether_bricks
fill 481 96 416 482 97 416 minecraft:orange_concrete
setblock 481 96 417 minecraft:red_nether_bricks
setblock 481 96 419 minecraft:light[level=14]
setblock 481 96 427 minecraft:light[level=14]
setblock 481 96 435 minecraft:light[level=14]
setblock 481 96 443 minecraft:light[level=14]
setblock 481 96 451 minecraft:light[level=14]
fill 481 96 457 483 96 457 minecraft:red_nether_bricks
fill 483 96 417 485 96 417 minecraft:red_nether_bricks
fill 484 96 458 485 97 458 minecraft:orange_concrete
fill 485 96 457 487 96 457 minecraft:red_nether_bricks
fill 486 96 458 487 101 458 minecraft:red_nether_bricks
fill 487 96 417 489 96 417 minecraft:red_nether_bricks
fill 488 96 416 488 101 416 minecraft:red_nether_bricks
fill 489 96 416 490 96 416 minecraft:orange_concrete
setblock 489 96 419 minecraft:light[level=14]
setblock 489 96 427 minecraft:light[level=14]
setblock 489 96 435 minecraft:light[level=14]
setblock 489 96 443 minecraft:light[level=14]
setblock 489 96 451 minecraft:light[level=14]
fill 489 96 457 491 96 457 minecraft:red_nether_bricks
fill 491 96 416 491 96 417 minecraft:red_nether_bricks
fill 492 96 417 493 96 417 minecraft:red_nether_bricks
fill 493 96 416 493 97 416 minecraft:orange_concrete
fill 493 96 457 495 96 457 minecraft:red_nether_bricks
fill 495 96 417 497 96 417 minecraft:red_nether_bricks
fill 495 96 458 495 101 458 minecraft:red_nether_bricks
fill 496 96 458 497 96 458 minecraft:orange_concrete
setblock 497 96 419 minecraft:light[level=14]
setblock 497 96 427 minecraft:light[level=14]
setblock 497 96 435 minecraft:light[level=14]
setblock 497 96 443 minecraft:light[level=14]
setblock 497 96 451 minecraft:light[level=14]
fill 497 96 457 499 96 457 minecraft:red_nether_bricks
fill 498 96 458 499 98 458 minecraft:red_nether_bricks
fill 499 96 416 500 96 417 minecraft:red_nether_bricks
fill 501 96 416 502 97 416 minecraft:orange_concrete
setblock 501 96 417 minecraft:red_nether_bricks
fill 501 96 457 503 96 457 minecraft:red_nether_bricks
fill 503 96 417 505 96 417 minecraft:red_nether_bricks
fill 504 96 458 505 97 458 minecraft:orange_concrete
setblock 505 96 419 minecraft:light[level=14]
setblock 505 96 427 minecraft:light[level=14]
setblock 505 96 435 minecraft:light[level=14]
setblock 505 96 443 minecraft:light[level=14]
setblock 505 96 451 minecraft:light[level=14]
fill 505 96 457 507 96 457 minecraft:red_nether_bricks
fill 506 96 458 507 101 458 minecraft:red_nether_bricks
fill 507 96 417 509 96 417 minecraft:red_nether_bricks
setblock 508 96 458 minecraft:orange_concrete
fill 509 96 457 509 96 458 minecraft:red_nether_bricks
setblock 510 96 416 minecraft:orange_concrete
fill 510 96 457 511 96 457 minecraft:red_nether_bricks
fill 511 96 416 511 96 419 minecraft:red_nether_bricks
fill 511 96 421 511 96 423 minecraft:red_nether_bricks
fill 511 96 425 511 96 427 minecraft:red_nether_bricks
fill 511 96 429 511 96 431 minecraft:red_nether_bricks
fill 511 96 433 511 96 435 minecraft:red_nether_bricks
fill 511 96 437 511 96 439 minecraft:red_nether_bricks
fill 511 96 441 511 96 443 minecraft:red_nether_bricks
fill 511 96 445 511 96 447 minecraft:red_nether_bricks
fill 511 96 449 511 96 451 minecraft:red_nether_bricks
fill 511 96 453 511 96 455 minecraft:red_nether_bricks
fill 512 96 416 512 101 416 minecraft:red_nether_bricks
fill 512 96 417 512 97 418 minecraft:orange_concrete
fill 512 96 423 512 101 424 minecraft:red_nether_bricks
fill 512 96 425 512 96 426 minecraft:orange_concrete
fill 512 96 427 512 101 427 minecraft:red_nether_bricks
fill 512 96 435 512 101 436 minecraft:red_nether_bricks
fill 512 96 437 512 97 438 minecraft:orange_concrete
fill 512 96 444 512 101 444 minecraft:red_nether_bricks
fill 512 96 445 512 96 446 minecraft:orange_concrete
fill 512 96 447 512 97 448 minecraft:red_nether_bricks
fill 512 96 449 512 97 449 minecraft:orange_concrete
fill 512 96 455 512 101 456 minecraft:red_nether_bricks
fill 512 96 457 512 97 457 minecraft:orange_concrete
setblock 470 97 417 minecraft:orange_concrete
setblock 470 97 428 minecraft:orange_concrete
fill 470 97 431 470 100 433 minecraft:red_nether_bricks
setblock 470 97 449 minecraft:orange_concrete
setblock 470 97 452 minecraft:orange_concrete
fill 470 97 453 470 100 453 minecraft:red_nether_bricks
setblock 472 97 458 minecraft:orange_concrete
setblock 473 97 416 minecraft:orange_concrete
fill 476 97 458 476 100 458 minecraft:red_nether_bricks
fill 479 97 416 480 101 416 minecraft:red_nether_bricks
fill 489 97 416 491 100 416 minecraft:red_nether_bricks
fill 492 97 458 493 97 458 minecraft:orange_concrete
setblock 494 97 416 minecraft:orange_concrete
setblock 496 97 458 minecraft:orange_concrete
fill 497 97 458 497 100 458 minecraft:red_nether_bricks
fill 499 97 416 500 101 416 minecraft:red_nether_bricks
setblock 505 97 416 minecraft:orange_concrete
fill 508 97 458 509 99 458 minecraft:red_nether_bricks
fill 510 97 416 511 100 416 minecraft:red_nether_bricks
fill 512 97 425 512 100 425 minecraft:red_nether_bricks
setblock 512 97 426 minecraft:orange_concrete
fill 512 97 429 512 97 430 minecraft:orange_concrete
fill 512 97 445 512 99 446 minecraft:red_nether_bricks
setblock 512 97 450 minecraft:orange_concrete
fill 470 98 417 470 103 417 minecraft:red_nether_bricks
fill 470 98 418 470 98 419 minecraft:orange_concrete
fill 470 98 420 470 103 421 minecraft:red_nether_bricks
fill 470 98 426 470 99 427 minecraft:orange_concrete
fill 470 98 428 470 103 429 minecraft:red_nether_bricks
setblock 470 98 430 minecraft:orange_concrete
fill 470 98 438 470 99 439 minecraft:orange_concrete
fill 470 98 440 470 103 441 minecraft:red_nether_bricks
fill 470 98 447 470 99 447 minecraft:orange_concrete
fill 470 98 449 470 103 449 minecraft:red_nether_bricks
fill 470 98 450 470 98 451 minecraft:orange_concrete
fill 470 98 452 470 103 452 minecraft:red_nether_bricks
fill 470 98 458 471 99 458 minecraft:orange_concrete
fill 471 98 416 472 98 416 minecraft:orange_concrete
fill 472 98 458 473 103 458 minecraft:red_nether_bricks
fill 473 98 416 473 103 416 minecraft:red_nether_bricks
fill 475 98 416 475 99 416 minecraft:orange_concrete
fill 481 98 416 482 103 416 minecraft:red_nether_bricks
fill 482 98 458 483 98 458 minecraft:orange_concrete
fill 483 98 416 484 99 416 minecraft:orange_concrete
fill 484 98 458 485 103 458 minecraft:red_nether_bricks
fill 491 98 458 491 99 458 minecraft:orange_concrete
setblock 492 98 416 minecraft:orange_concrete
fill 492 98 458 493 103 458 minecraft:red_nether_bricks
fill 493 98 416 494 103 416 minecraft:red_nether_bricks
setblock 494 98 458 minecraft:orange_concrete
fill 495 98 416 496 99 416 minecraft:orange_concrete
fill 496 98 458 496 100 458 minecraft:red_nether_bricks
fill 501 98 416 502 103 416 minecraft:red_nether_bricks
fill 502 98 458 503 99 458 minecraft:orange_concrete
fill 503 98 416 504 98 416 minecraft:orange_concrete
fill 504 98 458 505 103 458 minecraft:red_nether_bricks
fill 505 98 416 505 103 416 minecraft:red_nether_bricks
setblock 510 98 458 minecraft:red_nether_bricks
fill 511 98 458 511 99 458 minecraft:orange_concrete
fill 512 98 417 512 103 418 minecraft:red_nether_bricks
fill 512 98 419 512 99 420 minecraft:orange_concrete
fill 512 98 426 512 103 426 minecraft:red_nether_bricks
setblock 512 98 428 minecraft:orange_concrete
fill 512 98 429 512 103 430 minecraft:red_nether_bricks
fill 512 98 431 512 99 431 minecraft:orange_concrete
fill 512 98 437 512 103 438 minecraft:red_nether_bricks
fill 512 98 439 512 98 440 minecraft:orange_concrete
fill 512 98 447 512 101 447 minecraft:red_nether_bricks
setblock 512 98 448 minecraft:orange_concrete
fill 512 98 449 512 103 450 minecraft:red_nether_bricks
fill 512 98 451 512 99 452 minecraft:orange_concrete
fill 512 98 457 512 100 457 minecraft:red_nether_bricks
setblock 470 99 418 minecraft:orange_concrete
fill 470 99 419 470 102 419 minecraft:red_nether_bricks
fill 470 99 430 470 102 430 minecraft:red_nether_bricks
setblock 470 99 435 minecraft:orange_concrete
setblock 470 99 446 minecraft:orange_concrete
fill 470 99 450 470 102 451 minecraft:red_nether_bricks
fill 471 99 416 472 102 416 minecraft:red_nether_bricks
setblock 476 99 416 minecraft:orange_concrete
setblock 479 99 458 minecraft:orange_concrete
setblock 482 99 458 minecraft:orange_concrete
fill 483 99 458 483 102 458 minecraft:red_nether_bricks
setblock 487 99 416 minecraft:orange_concrete
setblock 490 99 458 minecraft:orange_concrete
fill 492 99 416 492 102 416 minecraft:red_nether_bricks
fill 494 99 458 494 102 458 minecraft:red_nether_bricks
fill 498 99 458 498 101 458 minecraft:red_nether_bricks
setblock 499 99 458 minecraft:orange_concrete
fill 503 99 416 503 102 416 minecraft:red_nether_bricks
setblock 504 99 416 minecraft:orange_concrete
fill 507 99 416 508 99 416 minecraft:orange_concrete
setblock 510 99 458 minecraft:orange_concrete
fill 512 99 428 512 102 428 minecraft:red_nether_bricks
setblock 512 99 432 minecraft:orange_concrete
fill 512 99 439 512 102 439 minecraft:red_nether_bricks
setblock 512 99 440 minecraft:orange_concrete
setblock 512 99 443 minecraft:orange_concrete
fill 512 99 448 512 101 448 minecraft:red_nether_bricks
setblock 470 100 416 minecraft:orange_concrete
fill 470 100 418 470 105 418 minecraft:red_nether_bricks
fill 470 100 424 470 101 425 minecraft:orange_concrete
fill 470 100 426 470 105 427 minecraft:red_nether_bricks
fill 470 100 435 470 105 435 minecraft:red_nether_bricks
fill 470 100 436 470 100 437 minecraft:orange_concrete
fill 470 100 438 470 105 439 minecraft:red_nether_bricks
fill 470 100 444 470 101 445 minecraft:orange_concrete
fill 470 100 446 470 105 447 minecraft:red_nether_bricks
setblock 470 100 448 minecraft:orange_concrete
fill 470 100 456 470 101 457 minecraft:orange_concrete
fill 470 100 458 471 105 458 minecraft:red_nether_bricks
setblock 474 100 416 minecraft:orange_concrete
fill 475 100 416 476 105 416 minecraft:red_nether_bricks
fill 477 100 416 478 101 416 minecraft:orange_concrete
fill 477 100 458 477 101 458 minecraft:orange_concrete
fill 479 100 458 479 105 458 minecraft:red_nether_bricks
fill 480 100 458 481 100 458 minecraft:orange_concrete
fill 482 100 458 482 105 458 minecraft:red_nether_bricks
fill 483 100 416 484 105 416 minecraft:red_nether_bricks
fill 485 100 416 486 100 416 minecraft:orange_concrete
fill 487 100 416 487 105 416 minecraft:red_nether_bricks
fill 488 100 458 489 101 458 minecraft:orange_concrete
fill 490 100 458 491 105 458 minecraft:red_nether_bricks
fill 495 100 416 496 105 416 minecraft:red_nether_bricks
fill 497 100 416 498 101 416 minecraft:orange_concrete
fill 499 100 458 499 101 458 minecraft:red_nether_bricks
fill 500 100 458 501 100 458 minecraft:orange_concrete
fill 502 100 458 503 105 458 minecraft:red_nether_bricks
fill 504 100 416 504 105 416 minecraft:red_nether_bricks
setblock 506 100 416 minecraft:orange_concrete
fill 507 100 416 508 105 416 minecraft:red_nether_bricks
fill 508 100 458 509 101 458 minecraft:orange_concrete
fill 509 100 416 509 101 416 minecraft:orange_concrete
fill 510 100 458 511 105 458 minecraft:red_nether_bricks
fill 512 100 419 512 105 420 minecraft:red_nether_bricks
fill 512 100 421 512 100 422 minecraft:orange_concrete
fill 512 100 431 512 105 432 minecraft:red_nether_bricks
fill 512 100 433 512 101 434 minecraft:orange_concrete
fill 512 100 440 512 105 440 minecraft:red_nether_bricks
fill 512 100 441 512 100 442 minecraft:orange_concrete
fill 512 100 443 512 105 443 minecraft:red_nether_bricks
fill 512 100 445 512 101 445 minecraft:orange_concrete
setblock 512 100 446 minecraft:red_nether_bricks
fill 512 100 451 512 105 452 minecraft:red_nether_bricks
fill 512 100 453 512 101 454 minecraft:orange_concrete
setblock 512 100 458 minecraft:orange_concrete
fill 470 101 416 470 104 416 minecraft:red_nether_bricks
setblock 470 101 431 minecraft:red_nether_bricks
fill 470 101 432 470 101 433 minecraft:orange_concrete
setblock 470 101 436 minecraft:orange_concrete
fill 470 101 437 470 104 437 minecraft:red_nether_bricks
fill 470 101 448 470 104 448 minecraft:red_nether_bricks
setblock 470 101 453 minecraft:orange_concrete
fill 474 101 416 474 104 416 minecraft:red_nether_bricks
setblock 476 101 458 minecraft:orange_concrete
fill 480 101 458 481 104 458 minecraft:red_nether_bricks
fill 485 101 416 485 104 416 minecraft:red_nether_bricks
setblock 486 101 416 minecraft:orange_concrete
fill 489 101 416 490 101 416 minecraft:orange_concrete
setblock 491 101 416 minecraft:red_nether_bricks
fill 496 101 458 497 101 458 minecraft:orange_concrete
setblock 500 101 458 minecraft:orange_concrete
fill 501 101 458 501 104 458 minecraft:red_nether_bricks
fill 506 101 416 506 104 416 minecraft:red_nether_bricks
setblock 510 101 416 minecraft:orange_concrete
setblock 511 101 416 minecraft:red_nether_bricks
fill 512 101 421 512 104 421 minecraft:red_nether_bricks
setblock 512 101 422 minecraft:orange_concrete
setblock 512 101 425 minecraft:orange_concrete
fill 512 101 441 512 104 442 minecraft:red_nether_bricks
setblock 512 101 446 minecraft:orange_concrete
setblock 512 101 457 minecraft:orange_concrete
fill 512 101 458 512 104 458 minecraft:red_nether_bricks
fill 470 102 422 470 102 423 minecraft:orange_concrete
fill 470 102 424 471 102 425 minecraft:red_nether_bricks
fill 470 102 431 470 103 431 minecraft:orange_concrete
fill 470 102 432 471 102 433 minecraft:red_nether_bricks
setblock 470 102 434 minecraft:orange_concrete
fill 470 102 436 471 102 436 minecraft:red_nether_bricks
fill 470 102 442 470 103 443 minecraft:orange_concrete
fill 470 102 444 471 102 445 minecraft:red_nether_bricks
fill 470 102 453 471 102 453 minecraft:red_nether_bricks
fill 470 102 454 470 102 455 minecraft:orange_concrete
fill 470 102 456 471 102 457 minecraft:red_nether_bricks
fill 471 102 417 473 102 417 minecraft:red_nether_bricks
fill 471 102 419 471 102 421 minecraft:red_nether_bricks
setblock 471 102 423 minecraft:red_nether_bricks
fill 471 102 427 471 102 429 minecraft:red_nether_bricks
setblock 471 102 431 minecraft:red_nether_bricks
schedule function dropper:buildpart/106_3 1t
