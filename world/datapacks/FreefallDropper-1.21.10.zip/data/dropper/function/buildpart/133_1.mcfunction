setblock 84 7 572 minecraft:calcite
setblock 84 7 573 minecraft:cobbled_deepslate
setblock 84 7 597 minecraft:calcite
fill 84 7 598 84 10 598 minecraft:cobbled_deepslate
fill 85 7 565 85 9 565 minecraft:light_blue_stained_glass
setblock 85 7 566 minecraft:calcite
setblock 85 7 567 minecraft:cobbled_deepslate
setblock 85 7 571 minecraft:calcite
fill 85 7 572 85 9 572 minecraft:cobbled_deepslate
fill 85 7 597 85 10 597 minecraft:cobbled_deepslate
fill 86 7 562 86 74 563 minecraft:calcite
setblock 86 7 565 minecraft:calcite
fill 86 7 566 86 8 566 minecraft:cobbled_deepslate
setblock 86 7 570 minecraft:calcite
fill 86 7 571 86 10 571 minecraft:cobbled_deepslate
setblock 86 7 575 minecraft:calcite
fill 86 7 576 86 8 576 minecraft:cobbled_deepslate
setblock 87 7 559 minecraft:calcite
fill 87 7 560 87 8 560 minecraft:cobbled_deepslate
setblock 87 7 564 minecraft:calcite
fill 87 7 565 87 9 565 minecraft:cobbled_deepslate
setblock 87 7 569 minecraft:calcite
fill 87 7 570 87 10 570 minecraft:cobbled_deepslate
setblock 87 7 574 minecraft:calcite
fill 87 7 575 87 10 575 minecraft:cobbled_deepslate
setblock 87 7 590 minecraft:cobbled_deepslate
setblock 87 7 594 minecraft:calcite
fill 87 7 595 87 9 595 minecraft:cobbled_deepslate
setblock 88 7 558 minecraft:calcite
fill 88 7 559 88 10 559 minecraft:cobbled_deepslate
setblock 88 7 563 minecraft:calcite
fill 88 7 564 88 10 564 minecraft:cobbled_deepslate
setblock 88 7 568 minecraft:calcite
fill 88 7 569 88 10 569 minecraft:cobbled_deepslate
setblock 88 7 573 minecraft:calcite
fill 88 7 574 88 10 574 minecraft:cobbled_deepslate
setblock 88 7 578 minecraft:calcite
setblock 88 7 579 minecraft:cobbled_deepslate
setblock 88 7 588 minecraft:calcite
setblock 88 7 589 minecraft:cobbled_deepslate
setblock 88 7 593 minecraft:calcite
fill 88 7 594 88 10 594 minecraft:cobbled_deepslate
setblock 88 7 598 minecraft:calcite
fill 48 8 558 48 8 561 minecraft:cobbled_deepslate
setblock 48 8 562 minecraft:calcite
setblock 48 8 563 minecraft:cobbled_deepslate
setblock 48 8 567 minecraft:calcite
fill 48 8 568 48 9 568 minecraft:cobbled_deepslate
setblock 48 8 572 minecraft:calcite
fill 48 8 573 48 10 573 minecraft:cobbled_deepslate
setblock 48 8 588 minecraft:cobbled_deepslate
setblock 48 8 592 minecraft:calcite
fill 48 8 593 48 11 593 minecraft:cobbled_deepslate
setblock 48 8 597 minecraft:calcite
fill 48 8 598 51 8 598 minecraft:cobbled_deepslate
setblock 49 8 591 minecraft:calcite
fill 49 8 592 49 9 592 minecraft:cobbled_deepslate
setblock 49 8 596 minecraft:calcite
fill 49 8 597 52 8 597 minecraft:cobbled_deepslate
setblock 50 8 560 minecraft:light[level=14]
setblock 50 8 568 minecraft:light[level=14]
setblock 50 8 576 minecraft:light[level=14]
setblock 50 8 584 minecraft:light[level=14]
setblock 50 8 592 minecraft:light[level=14]
setblock 52 8 598 minecraft:calcite
setblock 53 8 597 minecraft:calcite
fill 53 8 598 56 8 598 minecraft:cobbled_deepslate
fill 54 8 597 57 8 597 minecraft:cobbled_deepslate
fill 55 8 596 58 8 596 minecraft:cobbled_deepslate
setblock 57 8 558 minecraft:calcite
setblock 57 8 598 minecraft:calcite
fill 58 8 558 58 11 558 minecraft:cobbled_deepslate
setblock 58 8 560 minecraft:light[level=14]
setblock 58 8 568 minecraft:light[level=14]
setblock 58 8 576 minecraft:light[level=14]
setblock 58 8 584 minecraft:light[level=14]
setblock 58 8 592 minecraft:light[level=14]
fill 58 8 595 59 8 595 minecraft:cobbled_deepslate
setblock 58 8 597 minecraft:calcite
fill 58 8 598 58 11 598 minecraft:cobbled_deepslate
setblock 59 8 596 minecraft:calcite
fill 59 8 597 59 11 597 minecraft:cobbled_deepslate
setblock 60 8 595 minecraft:calcite
fill 60 8 596 60 11 596 minecraft:cobbled_deepslate
fill 61 8 595 61 11 595 minecraft:cobbled_deepslate
setblock 62 8 558 minecraft:calcite
setblock 62 8 598 minecraft:calcite
fill 63 8 558 63 11 558 minecraft:cobbled_deepslate
setblock 63 8 597 minecraft:calcite
fill 63 8 598 63 11 598 minecraft:cobbled_deepslate
setblock 64 8 596 minecraft:calcite
fill 64 8 597 64 11 597 minecraft:cobbled_deepslate
setblock 65 8 595 minecraft:calcite
fill 65 8 596 65 10 596 minecraft:cobbled_deepslate
setblock 66 8 560 minecraft:light[level=14]
setblock 66 8 568 minecraft:light[level=14]
setblock 66 8 576 minecraft:light[level=14]
setblock 66 8 584 minecraft:light[level=14]
setblock 66 8 592 minecraft:light[level=14]
setblock 67 8 598 minecraft:calcite
setblock 68 8 597 minecraft:calcite
fill 68 8 598 68 10 598 minecraft:cobbled_deepslate
setblock 72 8 595 minecraft:light_blue_stained_glass
fill 73 8 594 73 10 594 minecraft:light_blue_stained_glass
setblock 74 8 560 minecraft:light[level=14]
setblock 74 8 568 minecraft:light[level=14]
setblock 74 8 576 minecraft:light[level=14]
setblock 74 8 584 minecraft:light[level=14]
setblock 74 8 592 minecraft:light[level=14]
fill 75 8 594 75 10 594 minecraft:light_blue_stained_glass
setblock 76 8 595 minecraft:light_blue_stained_glass
setblock 77 8 598 minecraft:calcite
fill 78 8 558 78 11 558 minecraft:cobbled_deepslate
fill 78 8 598 81 8 598 minecraft:cobbled_deepslate
fill 80 8 597 82 8 597 minecraft:cobbled_deepslate
setblock 81 8 559 minecraft:calcite
setblock 82 8 558 minecraft:calcite
fill 82 8 559 82 11 559 minecraft:cobbled_deepslate
setblock 82 8 560 minecraft:light[level=14]
setblock 82 8 568 minecraft:light[level=14]
setblock 82 8 576 minecraft:light[level=14]
setblock 82 8 584 minecraft:light[level=14]
setblock 82 8 592 minecraft:light[level=14]
setblock 82 8 598 minecraft:calcite
fill 83 8 558 83 11 558 minecraft:cobbled_deepslate
fill 83 8 566 85 8 566 minecraft:light_blue_stained_glass
setblock 83 8 597 minecraft:calcite
fill 83 8 598 83 11 598 minecraft:cobbled_deepslate
setblock 84 8 565 minecraft:light_blue_stained_glass
fill 84 8 567 85 8 567 minecraft:light_blue_stained_glass
fill 84 8 597 84 11 597 minecraft:cobbled_deepslate
setblock 85 8 570 minecraft:calcite
fill 85 8 571 85 9 571 minecraft:cobbled_deepslate
setblock 85 8 574 minecraft:cobbled_deepslate
setblock 86 8 559 minecraft:calcite
fill 86 8 564 86 9 564 minecraft:light_blue_stained_glass
setblock 86 8 565 minecraft:cobbled_deepslate
setblock 86 8 569 minecraft:calcite
fill 86 8 570 86 10 570 minecraft:cobbled_deepslate
setblock 86 8 574 minecraft:calcite
fill 86 8 575 86 9 575 minecraft:cobbled_deepslate
setblock 87 8 558 minecraft:calcite
fill 87 8 559 87 9 559 minecraft:cobbled_deepslate
setblock 87 8 563 minecraft:calcite
setblock 87 8 564 minecraft:cobbled_deepslate
setblock 87 8 568 minecraft:calcite
fill 87 8 569 87 10 569 minecraft:cobbled_deepslate
setblock 87 8 573 minecraft:calcite
fill 87 8 574 87 11 574 minecraft:cobbled_deepslate
setblock 87 8 593 minecraft:calcite
fill 87 8 594 87 9 594 minecraft:cobbled_deepslate
setblock 87 8 598 minecraft:calcite
fill 88 8 558 88 11 558 minecraft:cobbled_deepslate
setblock 88 8 562 minecraft:calcite
fill 88 8 563 88 10 563 minecraft:cobbled_deepslate
setblock 88 8 567 minecraft:calcite
fill 88 8 568 88 11 568 minecraft:cobbled_deepslate
setblock 88 8 572 minecraft:calcite
fill 88 8 573 88 11 573 minecraft:cobbled_deepslate
setblock 88 8 577 minecraft:calcite
fill 88 8 578 88 9 578 minecraft:cobbled_deepslate
setblock 88 8 592 minecraft:calcite
fill 88 8 593 88 10 593 minecraft:cobbled_deepslate
setblock 88 8 597 minecraft:calcite
fill 88 8 598 88 11 598 minecraft:cobbled_deepslate
fill 48 9 558 48 9 560 minecraft:cobbled_deepslate
setblock 48 9 567 minecraft:cobbled_deepslate
setblock 48 9 571 minecraft:calcite
fill 48 9 572 48 10 572 minecraft:cobbled_deepslate
setblock 48 9 591 minecraft:calcite
fill 48 9 592 48 11 592 minecraft:cobbled_deepslate
setblock 48 9 596 minecraft:calcite
fill 48 9 597 50 9 598 minecraft:cobbled_deepslate
setblock 49 9 595 minecraft:calcite
fill 49 9 596 49 12 596 minecraft:cobbled_deepslate
setblock 51 9 597 minecraft:cobbled_deepslate
setblock 51 9 598 minecraft:calcite
setblock 52 9 597 minecraft:calcite
fill 52 9 598 55 9 598 minecraft:cobbled_deepslate
fill 53 9 597 56 9 597 minecraft:cobbled_deepslate
fill 55 9 596 57 9 596 minecraft:cobbled_deepslate
setblock 56 9 558 minecraft:calcite
setblock 56 9 598 minecraft:calcite
fill 57 9 558 57 12 558 minecraft:cobbled_deepslate
setblock 57 9 597 minecraft:calcite
fill 57 9 598 57 12 598 minecraft:cobbled_deepslate
setblock 58 9 595 minecraft:cobbled_deepslate
setblock 58 9 596 minecraft:calcite
fill 58 9 597 58 12 597 minecraft:cobbled_deepslate
setblock 59 9 595 minecraft:calcite
fill 59 9 596 59 12 596 minecraft:cobbled_deepslate
fill 60 9 595 60 11 595 minecraft:cobbled_deepslate
setblock 61 9 558 minecraft:calcite
setblock 61 9 598 minecraft:calcite
fill 62 9 558 62 12 558 minecraft:cobbled_deepslate
setblock 62 9 597 minecraft:calcite
fill 62 9 598 62 12 598 minecraft:cobbled_deepslate
setblock 63 9 596 minecraft:calcite
fill 63 9 597 63 12 597 minecraft:cobbled_deepslate
setblock 64 9 595 minecraft:calcite
fill 64 9 596 64 11 596 minecraft:cobbled_deepslate
setblock 66 9 598 minecraft:calcite
setblock 67 9 597 minecraft:calcite
fill 67 9 598 67 12 598 minecraft:cobbled_deepslate
fill 73 9 593 75 10 593 minecraft:light_blue_stained_glass
fill 76 9 594 76 10 594 minecraft:deepslate
fill 77 9 593 77 10 593 minecraft:deepslate
fill 77 9 595 77 10 595 minecraft:deepslate
fill 77 9 598 80 9 598 minecraft:cobbled_deepslate
fill 78 9 594 78 10 594 minecraft:deepslate
fill 79 9 597 81 9 597 minecraft:cobbled_deepslate
setblock 81 9 558 minecraft:calcite
fill 81 9 559 81 12 559 minecraft:cobbled_deepslate
setblock 81 9 598 minecraft:calcite
fill 82 9 558 82 12 558 minecraft:cobbled_deepslate
setblock 82 9 597 minecraft:calcite
fill 82 9 598 82 12 598 minecraft:cobbled_deepslate
fill 83 9 597 83 12 597 minecraft:cobbled_deepslate
fill 84 9 566 86 9 566 minecraft:light_blue_stained_glass
setblock 85 9 559 minecraft:calcite
setblock 85 9 567 minecraft:light_blue_stained_glass
setblock 85 9 570 minecraft:cobbled_deepslate
setblock 86 9 558 minecraft:calcite
fill 86 9 559 86 11 559 minecraft:cobbled_deepslate
fill 86 9 565 86 10 565 minecraft:light_blue_stained_glass
setblock 86 9 568 minecraft:calcite
setblock 86 9 569 minecraft:cobbled_deepslate
setblock 86 9 573 minecraft:calcite
fill 86 9 574 86 10 574 minecraft:cobbled_deepslate
setblock 86 9 598 minecraft:calcite
fill 87 9 558 87 12 558 minecraft:cobbled_deepslate
fill 87 9 564 87 10 564 minecraft:light_blue_stained_glass
setblock 87 9 567 minecraft:calcite
fill 87 9 568 87 10 568 minecraft:cobbled_deepslate
setblock 87 9 572 minecraft:calcite
fill 87 9 573 87 11 573 minecraft:cobbled_deepslate
setblock 87 9 577 minecraft:calcite
setblock 87 9 597 minecraft:calcite
fill 87 9 598 87 12 598 minecraft:cobbled_deepslate
setblock 88 9 561 minecraft:calcite
fill 88 9 562 88 10 562 minecraft:cobbled_deepslate
setblock 88 9 566 minecraft:calcite
fill 88 9 567 88 10 567 minecraft:cobbled_deepslate
setblock 88 9 571 minecraft:calcite
fill 88 9 572 88 12 572 minecraft:cobbled_deepslate
setblock 88 9 576 minecraft:calcite
fill 88 9 577 88 10 577 minecraft:cobbled_deepslate
setblock 88 9 591 minecraft:calcite
setblock 88 9 592 minecraft:cobbled_deepslate
setblock 88 9 596 minecraft:calcite
fill 88 9 597 88 12 597 minecraft:cobbled_deepslate
fill 48 10 558 48 10 559 minecraft:cobbled_deepslate
setblock 48 10 591 minecraft:cobbled_deepslate
setblock 48 10 595 minecraft:calcite
fill 48 10 596 48 11 598 minecraft:cobbled_deepslate
setblock 49 10 594 minecraft:calcite
fill 49 10 595 49 11 595 minecraft:cobbled_deepslate
fill 49 10 597 49 10 598 minecraft:cobbled_deepslate
setblock 50 10 558 minecraft:calcite
setblock 50 10 597 minecraft:cobbled_deepslate
setblock 50 10 598 minecraft:calcite
setblock 51 10 597 minecraft:calcite
fill 51 10 598 54 10 598 minecraft:cobbled_deepslate
fill 52 10 597 55 10 597 minecraft:cobbled_deepslate
fill 55 10 596 56 10 596 minecraft:cobbled_deepslate
setblock 55 10 598 minecraft:calcite
fill 56 10 558 56 13 558 minecraft:cobbled_deepslate
setblock 56 10 597 minecraft:calcite
fill 56 10 598 56 13 598 minecraft:cobbled_deepslate
setblock 57 10 596 minecraft:calcite
fill 57 10 597 57 13 597 minecraft:cobbled_deepslate
setblock 58 10 595 minecraft:calcite
fill 58 10 596 58 13 596 minecraft:cobbled_deepslate
fill 59 10 595 59 11 595 minecraft:cobbled_deepslate
setblock 60 10 558 minecraft:calcite
setblock 60 10 598 minecraft:calcite
fill 61 10 558 61 13 558 minecraft:cobbled_deepslate
setblock 61 10 597 minecraft:calcite
fill 61 10 598 61 13 598 minecraft:cobbled_deepslate
setblock 62 10 596 minecraft:calcite
fill 62 10 597 62 13 597 minecraft:cobbled_deepslate
setblock 63 10 595 minecraft:calcite
fill 63 10 596 63 12 596 minecraft:cobbled_deepslate
setblock 65 10 598 minecraft:calcite
setblock 66 10 597 minecraft:calcite
fill 66 10 598 66 13 598 minecraft:cobbled_deepslate
fill 74 10 592 74 11 592 minecraft:light_blue_stained_glass
setblock 75 10 596 minecraft:light_blue_stained_glass
fill 77 10 558 77 12 558 minecraft:cobbled_deepslate
fill 77 10 598 79 10 598 minecraft:cobbled_deepslate
fill 79 10 597 80 10 597 minecraft:cobbled_deepslate
setblock 80 10 558 minecraft:calcite
fill 80 10 559 80 13 559 minecraft:cobbled_deepslate
setblock 80 10 598 minecraft:calcite
fill 81 10 558 81 13 558 minecraft:cobbled_deepslate
setblock 81 10 597 minecraft:calcite
fill 81 10 598 81 13 598 minecraft:cobbled_deepslate
fill 82 10 597 82 13 597 minecraft:cobbled_deepslate
setblock 84 10 559 minecraft:calcite
fill 84 10 583 86 32 586 minecraft:calcite
setblock 85 10 558 minecraft:calcite
fill 85 10 559 85 13 559 minecraft:cobbled_deepslate
fill 85 10 566 87 10 566 minecraft:light_blue_stained_glass
setblock 85 10 598 minecraft:calcite
fill 86 10 558 86 13 558 minecraft:cobbled_deepslate
fill 86 10 567 87 10 567 minecraft:light_blue_stained_glass
setblock 86 10 572 minecraft:calcite
setblock 86 10 573 minecraft:cobbled_deepslate
setblock 86 10 597 minecraft:calcite
fill 86 10 598 86 13 598 minecraft:cobbled_deepslate
setblock 87 10 565 minecraft:light_blue_stained_glass
setblock 87 10 571 minecraft:calcite
fill 87 10 572 87 11 572 minecraft:cobbled_deepslate
setblock 87 10 576 minecraft:calcite
fill 87 10 584 87 28 585 minecraft:calcite
setblock 87 10 596 minecraft:calcite
setblock 87 10 597 minecraft:cobbled_deepslate
setblock 88 10 560 minecraft:calcite
setblock 88 10 561 minecraft:cobbled_deepslate
setblock 88 10 565 minecraft:calcite
setblock 88 10 566 minecraft:cobbled_deepslate
setblock 88 10 570 minecraft:calcite
fill 88 10 571 88 11 571 minecraft:cobbled_deepslate
setblock 88 10 575 minecraft:calcite
fill 88 10 576 88 11 576 minecraft:cobbled_deepslate
setblock 88 10 595 minecraft:calcite
fill 88 10 596 88 13 596 minecraft:cobbled_deepslate
setblock 48 11 558 minecraft:cobbled_deepslate
setblock 48 11 559 minecraft:calcite
setblock 48 11 594 minecraft:calcite
fill 48 11 595 48 14 595 minecraft:cobbled_deepslate
setblock 49 11 558 minecraft:calcite
setblock 49 11 594 minecraft:cobbled_deepslate
setblock 49 11 597 minecraft:cobbled_deepslate
setblock 49 11 598 minecraft:calcite
setblock 50 11 597 minecraft:calcite
fill 50 11 598 53 11 598 minecraft:cobbled_deepslate
fill 51 11 597 54 11 597 minecraft:cobbled_deepslate
setblock 54 11 598 minecraft:calcite
fill 55 11 558 55 14 558 minecraft:cobbled_deepslate
setblock 55 11 596 minecraft:cobbled_deepslate
setblock 55 11 597 minecraft:calcite
fill 55 11 598 55 14 598 minecraft:cobbled_deepslate
setblock 56 11 596 minecraft:calcite
fill 56 11 597 56 14 597 minecraft:cobbled_deepslate
fill 57 11 596 57 14 596 minecraft:cobbled_deepslate
setblock 59 11 558 minecraft:calcite
setblock 59 11 598 minecraft:calcite
fill 60 11 558 60 14 558 minecraft:cobbled_deepslate
setblock 60 11 597 minecraft:calcite
fill 60 11 598 60 14 598 minecraft:cobbled_deepslate
setblock 61 11 596 minecraft:calcite
fill 61 11 597 61 14 597 minecraft:cobbled_deepslate
fill 62 11 596 62 13 596 minecraft:cobbled_deepslate
setblock 64 11 598 minecraft:calcite
setblock 65 11 597 minecraft:calcite
fill 65 11 598 65 14 598 minecraft:cobbled_deepslate
setblock 66 11 597 minecraft:cobbled_deepslate
setblock 74 11 591 minecraft:light_blue_stained_glass
setblock 74 11 593 minecraft:light_blue_stained_glass
fill 76 11 598 78 11 598 minecraft:cobbled_deepslate
setblock 79 11 558 minecraft:calcite
fill 79 11 559 79 14 559 minecraft:cobbled_deepslate
setblock 79 11 597 minecraft:cobbled_deepslate
setblock 79 11 598 minecraft:calcite
fill 80 11 558 80 14 558 minecraft:cobbled_deepslate
setblock 80 11 597 minecraft:calcite
fill 80 11 598 80 14 598 minecraft:cobbled_deepslate
fill 81 11 597 81 14 597 minecraft:cobbled_deepslate
setblock 83 11 559 minecraft:calcite
fill 83 11 583 83 12 586 minecraft:deepslate
setblock 84 11 558 minecraft:calcite
fill 84 11 559 84 14 559 minecraft:cobbled_deepslate
fill 84 11 582 86 12 582 minecraft:deepslate
fill 84 11 587 87 12 587 minecraft:deepslate
setblock 84 11 598 minecraft:calcite
fill 85 11 558 85 14 558 minecraft:cobbled_deepslate
setblock 85 11 597 minecraft:calcite
fill 85 11 598 85 14 598 minecraft:cobbled_deepslate
setblock 86 11 597 minecraft:cobbled_deepslate
setblock 87 11 566 minecraft:light_blue_stained_glass
setblock 87 11 571 minecraft:cobbled_deepslate
fill 87 11 583 87 12 583 minecraft:deepslate
fill 87 11 586 87 12 586 minecraft:deepslate
setblock 88 11 559 minecraft:calcite
fill 88 11 560 88 14 560 minecraft:cobbled_deepslate
setblock 88 11 569 minecraft:calcite
setblock 88 11 570 minecraft:cobbled_deepslate
setblock 88 11 574 minecraft:calcite
fill 88 11 575 88 12 575 minecraft:cobbled_deepslate
fill 88 11 584 88 12 585 minecraft:deepslate
setblock 88 11 594 minecraft:calcite
fill 88 11 595 88 12 595 minecraft:cobbled_deepslate
setblock 48 12 558 minecraft:calcite
setblock 48 12 593 minecraft:calcite
fill 48 12 594 48 15 594 minecraft:cobbled_deepslate
fill 48 12 596 48 12 597 minecraft:cobbled_deepslate
setblock 48 12 598 minecraft:calcite
fill 49 12 558 49 15 558 minecraft:cobbled_deepslate
setblock 49 12 597 minecraft:calcite
fill 49 12 598 52 12 598 minecraft:cobbled_deepslate
fill 50 12 597 53 12 597 minecraft:cobbled_deepslate
setblock 53 12 598 minecraft:calcite
setblock 54 12 597 minecraft:calcite
fill 54 12 598 54 15 598 minecraft:cobbled_deepslate
setblock 55 12 596 minecraft:calcite
fill 55 12 597 55 15 597 minecraft:cobbled_deepslate
fill 56 12 596 56 15 596 minecraft:cobbled_deepslate
setblock 58 12 558 minecraft:calcite
setblock 58 12 598 minecraft:calcite
fill 59 12 558 59 15 558 minecraft:cobbled_deepslate
setblock 59 12 597 minecraft:calcite
fill 59 12 598 59 15 598 minecraft:cobbled_deepslate
setblock 60 12 596 minecraft:calcite
fill 60 12 597 60 15 597 minecraft:cobbled_deepslate
fill 61 12 596 61 14 596 minecraft:cobbled_deepslate
setblock 63 12 558 minecraft:calcite
setblock 63 12 598 minecraft:calcite
setblock 64 12 597 minecraft:calcite
fill 64 12 598 64 15 598 minecraft:cobbled_deepslate
setblock 65 12 597 minecraft:cobbled_deepslate
fill 76 12 558 76 13 558 minecraft:cobbled_deepslate
fill 76 12 598 77 12 598 minecraft:cobbled_deepslate
setblock 78 12 558 minecraft:calcite
setblock 78 12 598 minecraft:calcite
fill 79 12 558 79 15 558 minecraft:cobbled_deepslate
setblock 79 12 597 minecraft:calcite
fill 79 12 598 79 15 598 minecraft:cobbled_deepslate
fill 80 12 597 80 15 597 minecraft:cobbled_deepslate
setblock 82 12 559 minecraft:calcite
fill 82 12 583 82 12 586 minecraft:deepslate
setblock 83 12 558 minecraft:calcite
fill 83 12 559 83 15 559 minecraft:cobbled_deepslate
setblock 83 12 582 minecraft:deepslate
setblock 83 12 587 minecraft:deepslate
setblock 83 12 598 minecraft:calcite
fill 84 12 558 84 15 558 minecraft:cobbled_deepslate
fill 84 12 581 86 12 581 minecraft:deepslate
fill 84 12 588 87 12 588 minecraft:deepslate
setblock 84 12 597 minecraft:calcite
fill 84 12 598 84 15 598 minecraft:cobbled_deepslate
setblock 85 12 597 minecraft:cobbled_deepslate
fill 87 12 582 88 12 582 minecraft:deepslate
setblock 88 12 558 minecraft:calcite
fill 88 12 559 88 15 559 minecraft:cobbled_deepslate
setblock 88 12 573 minecraft:calcite
setblock 88 12 574 minecraft:cobbled_deepslate
setblock 88 12 583 minecraft:deepslate
fill 88 12 586 88 12 587 minecraft:deepslate
setblock 88 12 598 minecraft:calcite
fill 48 13 558 48 16 558 minecraft:cobbled_deepslate
setblock 48 13 593 minecraft:cobbled_deepslate
setblock 48 13 596 minecraft:cobbled_deepslate
setblock 48 13 597 minecraft:calcite
fill 48 13 598 51 13 598 minecraft:cobbled_deepslate
setblock 49 13 596 minecraft:calcite
fill 49 13 597 52 13 597 minecraft:cobbled_deepslate
setblock 52 13 598 minecraft:calcite
fill 53 13 558 54 15 558 minecraft:cobbled_deepslate
setblock 53 13 597 minecraft:calcite
fill 53 13 598 53 16 598 minecraft:cobbled_deepslate
fill 54 13 597 54 16 597 minecraft:cobbled_deepslate
fill 55 13 596 55 16 596 minecraft:cobbled_deepslate
setblock 57 13 558 minecraft:calcite
setblock 57 13 598 minecraft:calcite
fill 58 13 558 58 16 558 minecraft:cobbled_deepslate
setblock 58 13 597 minecraft:calcite
fill 58 13 598 58 16 598 minecraft:cobbled_deepslate
setblock 59 13 596 minecraft:calcite
fill 59 13 597 59 16 597 minecraft:cobbled_deepslate
fill 60 13 596 60 16 596 minecraft:cobbled_deepslate
setblock 62 13 558 minecraft:calcite
setblock 62 13 598 minecraft:calcite
fill 63 13 558 63 16 558 minecraft:cobbled_deepslate
setblock 63 13 597 minecraft:calcite
fill 63 13 598 63 16 598 minecraft:cobbled_deepslate
setblock 64 13 597 minecraft:cobbled_deepslate
fill 75 13 558 75 14 558 minecraft:cobbled_deepslate
fill 75 13 598 76 13 598 minecraft:cobbled_deepslate
setblock 77 13 558 minecraft:calcite
setblock 77 13 598 minecraft:calcite
fill 78 13 558 78 15 559 minecraft:cobbled_deepslate
setblock 78 13 597 minecraft:calcite
fill 78 13 598 78 16 598 minecraft:cobbled_deepslate
fill 79 13 597 79 16 597 minecraft:cobbled_deepslate
setblock 81 13 559 minecraft:calcite
setblock 82 13 558 minecraft:calcite
fill 82 13 559 82 16 559 minecraft:cobbled_deepslate
setblock 82 13 598 minecraft:calcite
fill 83 13 558 83 16 558 minecraft:cobbled_deepslate
setblock 83 13 597 minecraft:calcite
fill 83 13 598 83 16 598 minecraft:cobbled_deepslate
setblock 84 13 597 minecraft:cobbled_deepslate
setblock 87 13 558 minecraft:calcite
setblock 87 13 598 minecraft:calcite
fill 88 13 558 88 16 558 minecraft:cobbled_deepslate
setblock 88 13 597 minecraft:calcite
fill 88 13 598 88 16 598 minecraft:cobbled_deepslate
setblock 48 14 596 minecraft:calcite
fill 48 14 597 50 14 598 minecraft:cobbled_deepslate
setblock 50 14 558 minecraft:cobbled_deepslate
setblock 51 14 558 minecraft:calcite
setblock 51 14 597 minecraft:cobbled_deepslate
setblock 51 14 598 minecraft:calcite
fill 52 14 558 52 17 558 minecraft:cobbled_deepslate
setblock 52 14 597 minecraft:calcite
fill 52 14 598 52 17 598 minecraft:cobbled_deepslate
fill 53 14 597 53 17 597 minecraft:cobbled_deepslate
setblock 56 14 558 minecraft:calcite
setblock 56 14 598 minecraft:calcite
fill 57 14 558 57 17 558 minecraft:cobbled_deepslate
setblock 57 14 597 minecraft:calcite
fill 57 14 598 57 17 598 minecraft:cobbled_deepslate
setblock 58 14 596 minecraft:calcite
fill 58 14 597 58 17 597 minecraft:cobbled_deepslate
fill 59 14 596 59 17 596 minecraft:cobbled_deepslate
setblock 61 14 558 minecraft:calcite
setblock 61 14 598 minecraft:calcite
fill 62 14 558 62 17 558 minecraft:cobbled_deepslate
setblock 62 14 597 minecraft:calcite
fill 62 14 598 62 17 598 minecraft:cobbled_deepslate
fill 63 14 593 63 14 596 minecraft:light_blue_stained_glass
fill 63 14 597 63 15 597 minecraft:cobbled_deepslate
fill 74 14 558 74 15 558 minecraft:cobbled_deepslate
setblock 75 14 598 minecraft:cobbled_deepslate
setblock 76 14 558 minecraft:calcite
fill 76 14 559 77 16 559 minecraft:cobbled_deepslate
setblock 76 14 598 minecraft:calcite
fill 77 14 558 77 17 558 minecraft:cobbled_deepslate
fill 77 14 598 77 17 598 minecraft:cobbled_deepslate
fill 78 14 597 78 17 597 minecraft:cobbled_deepslate
setblock 80 14 559 minecraft:calcite
setblock 81 14 558 minecraft:calcite
fill 81 14 559 81 17 559 minecraft:cobbled_deepslate
setblock 81 14 598 minecraft:calcite
fill 82 14 558 82 17 558 minecraft:cobbled_deepslate
setblock 82 14 597 minecraft:calcite
fill 82 14 598 82 17 598 minecraft:cobbled_deepslate
fill 83 14 597 83 17 597 minecraft:cobbled_deepslate
setblock 85 14 559 minecraft:calcite
setblock 86 14 558 minecraft:calcite
fill 86 14 559 86 17 559 minecraft:cobbled_deepslate
setblock 86 14 598 minecraft:calcite
fill 87 14 558 87 17 558 minecraft:cobbled_deepslate
fill 87 14 598 87 17 598 minecraft:cobbled_deepslate
setblock 88 14 596 minecraft:calcite
fill 88 14 597 88 17 597 minecraft:cobbled_deepslate
setblock 48 15 559 minecraft:cobbled_deepslate
setblock 48 15 595 minecraft:calcite
fill 48 15 596 48 16 598 minecraft:cobbled_deepslate
fill 49 15 597 49 15 598 minecraft:cobbled_deepslate
setblock 50 15 558 minecraft:calcite
setblock 50 15 597 minecraft:cobbled_deepslate
setblock 50 15 598 minecraft:calcite
fill 51 15 558 51 18 558 minecraft:cobbled_deepslate
setblock 51 15 597 minecraft:calcite
fill 51 15 598 51 18 598 minecraft:cobbled_deepslate
fill 52 15 597 52 18 597 minecraft:cobbled_deepslate
fill 54 15 596 54 17 596 minecraft:cobbled_deepslate
setblock 55 15 558 minecraft:calcite
setblock 55 15 598 minecraft:calcite
fill 56 15 558 56 18 558 minecraft:cobbled_deepslate
setblock 56 15 597 minecraft:calcite
fill 56 15 598 56 18 598 minecraft:cobbled_deepslate
fill 57 15 559 58 15 559 minecraft:cobbled_deepslate
setblock 57 15 596 minecraft:calcite
fill 57 15 597 57 18 597 minecraft:cobbled_deepslate
fill 58 15 596 58 18 596 minecraft:cobbled_deepslate
setblock 60 15 558 minecraft:calcite
setblock 60 15 598 minecraft:calcite
fill 61 15 558 61 18 558 minecraft:cobbled_deepslate
setblock 61 15 597 minecraft:calcite
fill 61 15 598 61 18 598 minecraft:cobbled_deepslate
fill 62 15 594 64 15 596 minecraft:light_blue_stained_glass
fill 62 15 597 62 17 597 minecraft:cobbled_deepslate
fill 64 15 597 64 18 597 minecraft:light_blue_stained_glass
setblock 65 15 598 minecraft:calcite
fill 73 15 558 73 16 558 minecraft:cobbled_deepslate
setblock 74 15 598 minecraft:cobbled_deepslate
setblock 75 15 558 minecraft:calcite
fill 75 15 559 75 18 559 minecraft:cobbled_deepslate
setblock 75 15 598 minecraft:calcite
fill 76 15 558 76 18 558 minecraft:cobbled_deepslate
fill 76 15 598 76 18 598 minecraft:cobbled_deepslate
fill 77 15 597 77 18 597 minecraft:cobbled_deepslate
setblock 78 15 560 minecraft:calcite
setblock 79 15 559 minecraft:calcite
fill 79 15 560 82 15 560 minecraft:cobbled_deepslate
setblock 80 15 558 minecraft:calcite
fill 80 15 559 80 18 559 minecraft:cobbled_deepslate
setblock 80 15 598 minecraft:calcite
fill 81 15 558 81 18 558 minecraft:cobbled_deepslate
setblock 81 15 597 minecraft:calcite
fill 81 15 598 81 18 598 minecraft:cobbled_deepslate
fill 82 15 597 82 18 597 minecraft:cobbled_deepslate
setblock 84 15 559 minecraft:calcite
setblock 85 15 558 minecraft:calcite
fill 85 15 559 85 18 559 minecraft:cobbled_deepslate
setblock 85 15 598 minecraft:calcite
fill 86 15 558 86 18 558 minecraft:cobbled_deepslate
fill 86 15 598 86 18 598 minecraft:cobbled_deepslate
fill 87 15 559 87 16 559 minecraft:cobbled_deepslate
setblock 88 15 560 minecraft:calcite
fill 88 15 561 88 18 561 minecraft:cobbled_deepslate
fill 88 15 596 88 18 596 minecraft:cobbled_deepslate
setblock 48 16 559 minecraft:calcite
fill 48 16 560 48 19 560 minecraft:cobbled_deepslate
setblock 48 16 594 minecraft:calcite
fill 48 16 595 48 19 595 minecraft:cobbled_deepslate
setblock 49 16 558 minecraft:calcite
setblock 49 16 597 minecraft:cobbled_deepslate
setblock 49 16 598 minecraft:calcite
fill 50 16 558 50 19 558 minecraft:cobbled_deepslate
setblock 50 16 560 minecraft:light[level=14]
setblock 50 16 568 minecraft:light[level=14]
setblock 50 16 576 minecraft:light[level=14]
setblock 50 16 584 minecraft:light[level=14]
setblock 50 16 592 minecraft:light[level=14]
setblock 50 16 597 minecraft:calcite
fill 50 16 598 50 19 598 minecraft:cobbled_deepslate
fill 51 16 597 51 19 597 minecraft:cobbled_deepslate
setblock 53 16 558 minecraft:cobbled_deepslate
setblock 54 16 558 minecraft:calcite
fill 54 16 559 57 16 559 minecraft:cobbled_deepslate
setblock 54 16 598 minecraft:calcite
fill 55 16 558 55 19 558 minecraft:cobbled_deepslate
setblock 55 16 597 minecraft:calcite
fill 55 16 598 55 19 598 minecraft:cobbled_deepslate
setblock 56 16 596 minecraft:calcite
fill 56 16 597 56 19 597 minecraft:cobbled_deepslate
fill 57 16 596 57 19 596 minecraft:cobbled_deepslate
setblock 58 16 559 minecraft:calcite
setblock 58 16 560 minecraft:light[level=14]
setblock 58 16 568 minecraft:light[level=14]
setblock 58 16 576 minecraft:light[level=14]
setblock 58 16 584 minecraft:light[level=14]
setblock 58 16 592 minecraft:light[level=14]
setblock 59 16 558 minecraft:calcite
fill 59 16 559 60 18 559 minecraft:cobbled_deepslate
setblock 59 16 598 minecraft:calcite
fill 60 16 558 60 19 558 minecraft:cobbled_deepslate
setblock 60 16 597 minecraft:calcite
fill 60 16 598 60 19 598 minecraft:cobbled_deepslate
fill 61 16 596 65 17 596 minecraft:light_blue_stained_glass
fill 61 16 597 61 19 597 minecraft:cobbled_deepslate
fill 62 16 595 64 17 595 minecraft:light_blue_stained_glass
setblock 63 16 594 minecraft:light_blue_stained_glass
fill 63 16 597 63 18 597 minecraft:light_blue_stained_glass
setblock 64 16 558 minecraft:calcite
setblock 64 16 598 minecraft:calcite
fill 65 16 597 65 17 597 minecraft:light_blue_stained_glass
setblock 65 16 598 minecraft:cobbled_deepslate
setblock 66 16 560 minecraft:light[level=14]
setblock 66 16 568 minecraft:light[level=14]
setblock 66 16 576 minecraft:light[level=14]
setblock 66 16 584 minecraft:light[level=14]
setblock 66 16 592 minecraft:light[level=14]
fill 71 16 558 72 17 558 minecraft:cobbled_deepslate
setblock 73 16 598 minecraft:cobbled_deepslate
setblock 74 16 558 minecraft:calcite
fill 74 16 559 74 19 559 minecraft:cobbled_deepslate
setblock 74 16 560 minecraft:light[level=14]
setblock 74 16 568 minecraft:light[level=14]
setblock 74 16 576 minecraft:light[level=14]
setblock 74 16 584 minecraft:light[level=14]
setblock 74 16 592 minecraft:light[level=14]
setblock 74 16 598 minecraft:calcite
fill 75 16 558 75 19 558 minecraft:cobbled_deepslate
fill 75 16 598 75 19 598 minecraft:cobbled_deepslate
setblock 76 16 560 minecraft:cobbled_deepslate
fill 76 16 597 76 19 597 minecraft:cobbled_deepslate
setblock 77 16 560 minecraft:calcite
setblock 78 16 558 minecraft:cobbled_deepslate
setblock 78 16 559 minecraft:calcite
fill 78 16 560 81 16 560 minecraft:cobbled_deepslate
setblock 79 16 558 minecraft:calcite
fill 79 16 559 79 19 559 minecraft:cobbled_deepslate
setblock 79 16 598 minecraft:calcite
fill 80 16 558 80 19 558 minecraft:cobbled_deepslate
setblock 80 16 597 minecraft:calcite
fill 80 16 598 80 19 598 minecraft:cobbled_deepslate
fill 81 16 597 81 19 597 minecraft:cobbled_deepslate
setblock 82 16 560 minecraft:calcite
setblock 82 16 568 minecraft:light[level=14]
setblock 82 16 576 minecraft:light[level=14]
setblock 82 16 584 minecraft:light[level=14]
setblock 82 16 592 minecraft:light[level=14]
setblock 83 16 559 minecraft:calcite
fill 83 16 560 83 19 560 minecraft:cobbled_deepslate
setblock 84 16 558 minecraft:calcite
fill 84 16 559 84 19 559 minecraft:cobbled_deepslate
setblock 84 16 598 minecraft:calcite
fill 85 16 558 85 19 558 minecraft:cobbled_deepslate
fill 85 16 598 85 19 598 minecraft:cobbled_deepslate
setblock 87 16 560 minecraft:calcite
setblock 88 16 559 minecraft:calcite
fill 88 16 560 88 19 560 minecraft:cobbled_deepslate
fill 88 16 562 88 17 562 minecraft:cobbled_deepslate
setblock 48 17 558 minecraft:calcite
fill 48 17 559 48 20 559 minecraft:cobbled_deepslate
fill 48 17 594 48 20 594 minecraft:cobbled_deepslate
fill 48 17 596 48 17 597 minecraft:cobbled_deepslate
setblock 48 17 598 minecraft:calcite
fill 49 17 558 49 20 558 minecraft:cobbled_deepslate
setblock 49 17 596 minecraft:cobbled_deepslate
setblock 49 17 597 minecraft:calcite
fill 49 17 598 49 20 598 minecraft:cobbled_deepslate
fill 50 17 597 50 20 597 minecraft:cobbled_deepslate
setblock 52 17 559 minecraft:calcite
setblock 53 17 558 minecraft:calcite
fill 53 17 559 56 17 559 minecraft:cobbled_deepslate
fill 53 17 596 53 18 596 minecraft:cobbled_deepslate
setblock 53 17 598 minecraft:calcite
fill 54 17 558 54 20 558 minecraft:cobbled_deepslate
setblock 54 17 597 minecraft:calcite
fill 54 17 598 54 20 598 minecraft:cobbled_deepslate
setblock 55 17 596 minecraft:calcite
fill 55 17 597 55 20 597 minecraft:cobbled_deepslate
fill 56 17 596 56 20 596 minecraft:cobbled_deepslate
setblock 57 17 559 minecraft:calcite
setblock 58 17 558 minecraft:calcite
fill 58 17 559 58 20 559 minecraft:cobbled_deepslate
setblock 58 17 598 minecraft:calcite
fill 59 17 558 59 20 558 minecraft:cobbled_deepslate
setblock 59 17 597 minecraft:calcite
fill 59 17 598 59 20 598 minecraft:cobbled_deepslate
fill 60 17 597 60 20 597 minecraft:cobbled_deepslate
setblock 61 17 559 minecraft:cobbled_deepslate
setblock 63 17 558 minecraft:calcite
setblock 63 17 598 minecraft:calcite
fill 64 17 558 64 20 558 minecraft:cobbled_deepslate
fill 64 17 598 64 18 598 minecraft:cobbled_deepslate
setblock 65 17 598 minecraft:light_blue_stained_glass
fill 70 17 558 70 19 558 minecraft:cobbled_deepslate
setblock 72 17 559 minecraft:calcite
setblock 72 17 598 minecraft:cobbled_deepslate
setblock 73 17 558 minecraft:calcite
fill 73 17 559 73 20 559 minecraft:cobbled_deepslate
setblock 73 17 598 minecraft:calcite
fill 74 17 558 74 20 558 minecraft:cobbled_deepslate
fill 74 17 598 74 20 598 minecraft:cobbled_deepslate
setblock 75 17 560 minecraft:cobbled_deepslate
setblock 76 17 559 minecraft:cobbled_deepslate
setblock 76 17 560 minecraft:calcite
setblock 77 17 559 minecraft:calcite
fill 77 17 560 80 17 560 minecraft:cobbled_deepslate
setblock 78 17 558 minecraft:calcite
fill 78 17 559 78 20 559 minecraft:cobbled_deepslate
fill 78 17 561 79 17 561 minecraft:cobbled_deepslate
setblock 78 17 598 minecraft:calcite
fill 79 17 558 79 20 558 minecraft:cobbled_deepslate
setblock 79 17 597 minecraft:calcite
fill 79 17 598 79 20 598 minecraft:cobbled_deepslate
fill 80 17 597 80 20 597 minecraft:cobbled_deepslate
setblock 81 17 560 minecraft:calcite
setblock 82 17 559 minecraft:calcite
fill 82 17 560 82 20 560 minecraft:cobbled_deepslate
setblock 83 17 558 minecraft:calcite
fill 83 17 559 83 20 559 minecraft:cobbled_deepslate
setblock 83 17 598 minecraft:calcite
fill 84 17 558 84 20 558 minecraft:cobbled_deepslate
fill 84 17 560 84 18 560 minecraft:cobbled_deepslate
fill 84 17 561 85 74 562 minecraft:calcite
fill 84 17 598 84 20 598 minecraft:cobbled_deepslate
fill 85 17 560 85 18 560 minecraft:calcite
setblock 87 17 559 minecraft:calcite
fill 87 17 560 87 19 561 minecraft:cobbled_deepslate
setblock 88 17 558 minecraft:calcite
fill 88 17 559 88 20 559 minecraft:cobbled_deepslate
setblock 88 17 563 minecraft:calcite
setblock 88 17 598 minecraft:calcite
fill 48 18 558 48 21 558 minecraft:cobbled_deepslate
setblock 48 18 561 minecraft:cobbled_deepslate
fill 48 18 578 48 18 581 minecraft:cobbled_deepslate
setblock 48 18 582 minecraft:calcite
fill 48 18 583 48 20 584 minecraft:cobbled_deepslate
fill 48 18 593 48 21 593 minecraft:cobbled_deepslate
setblock 48 18 596 minecraft:cobbled_deepslate
setblock 48 18 597 minecraft:calcite
fill 48 18 598 48 21 598 minecraft:cobbled_deepslate
fill 49 18 559 50 18 559 minecraft:cobbled_deepslate
setblock 49 18 596 minecraft:calcite
fill 49 18 597 49 21 597 minecraft:cobbled_deepslate
setblock 51 18 559 minecraft:calcite
setblock 52 18 558 minecraft:calcite
fill 52 18 559 55 18 559 minecraft:cobbled_deepslate
setblock 52 18 598 minecraft:calcite
fill 53 18 558 53 21 558 minecraft:cobbled_deepslate
setblock 53 18 597 minecraft:calcite
fill 53 18 598 53 21 598 minecraft:cobbled_deepslate
setblock 54 18 596 minecraft:calcite
fill 54 18 597 54 21 597 minecraft:cobbled_deepslate
fill 55 18 596 55 21 596 minecraft:cobbled_deepslate
setblock 56 18 559 minecraft:calcite
setblock 57 18 558 minecraft:calcite
fill 57 18 559 57 21 559 minecraft:cobbled_deepslate
setblock 57 18 598 minecraft:calcite
fill 58 18 558 58 21 558 minecraft:cobbled_deepslate
setblock 58 18 597 minecraft:calcite
fill 58 18 598 58 21 598 minecraft:cobbled_deepslate
setblock 59 18 596 minecraft:calcite
fill 59 18 597 59 21 597 minecraft:cobbled_deepslate
setblock 61 18 559 minecraft:calcite
setblock 62 18 558 minecraft:calcite
fill 62 18 596 62 18 597 minecraft:light_blue_stained_glass
setblock 62 18 598 minecraft:calcite
fill 63 18 558 63 21 558 minecraft:cobbled_deepslate
fill 63 18 596 64 18 596 minecraft:light_blue_stained_glass
fill 63 18 598 63 19 598 minecraft:cobbled_deepslate
fill 65 18 558 65 19 558 minecraft:cobbled_deepslate
fill 68 18 558 69 20 558 minecraft:cobbled_deepslate
setblock 71 18 558 minecraft:cobbled_deepslate
setblock 71 18 559 minecraft:calcite
setblock 71 18 598 minecraft:cobbled_deepslate
setblock 72 18 558 minecraft:calcite
fill 72 18 559 72 21 559 minecraft:cobbled_deepslate
setblock 72 18 598 minecraft:calcite
fill 73 18 558 73 21 558 minecraft:cobbled_deepslate
fill 73 18 560 74 18 560 minecraft:cobbled_deepslate
fill 73 18 598 73 21 598 minecraft:cobbled_deepslate
setblock 75 18 560 minecraft:calcite
fill 75 18 597 75 20 597 minecraft:cobbled_deepslate
setblock 76 18 559 minecraft:calcite
fill 76 18 560 78 18 561 minecraft:cobbled_deepslate
setblock 77 18 558 minecraft:calcite
fill 77 18 559 77 21 559 minecraft:cobbled_deepslate
setblock 77 18 598 minecraft:calcite
fill 78 18 558 78 21 558 minecraft:cobbled_deepslate
setblock 78 18 597 minecraft:calcite
fill 78 18 598 78 21 598 minecraft:cobbled_deepslate
setblock 79 18 560 minecraft:cobbled_deepslate
setblock 79 18 561 minecraft:calcite
fill 79 18 597 79 21 597 minecraft:cobbled_deepslate
setblock 80 18 560 minecraft:calcite
fill 80 18 561 81 20 561 minecraft:cobbled_deepslate
setblock 81 18 559 minecraft:calcite
fill 81 18 560 81 21 560 minecraft:cobbled_deepslate
setblock 82 18 558 minecraft:calcite
fill 82 18 559 82 21 559 minecraft:cobbled_deepslate
setblock 82 18 598 minecraft:calcite
fill 83 18 558 83 21 558 minecraft:cobbled_deepslate
fill 83 18 598 83 21 598 minecraft:cobbled_deepslate
setblock 86 18 559 minecraft:calcite
setblock 87 18 558 minecraft:calcite
fill 87 18 559 87 21 559 minecraft:cobbled_deepslate
setblock 87 18 562 minecraft:cobbled_deepslate
setblock 87 18 598 minecraft:calcite
fill 88 18 558 88 21 558 minecraft:cobbled_deepslate
setblock 88 18 562 minecraft:calcite
fill 88 18 563 88 20 564 minecraft:cobbled_deepslate
setblock 88 18 597 minecraft:calcite
fill 88 18 598 88 21 598 minecraft:cobbled_deepslate
setblock 48 19 561 minecraft:calcite
fill 48 19 562 48 22 562 minecraft:cobbled_deepslate
fill 48 19 578 48 19 580 minecraft:cobbled_deepslate
setblock 48 19 581 minecraft:calcite
fill 48 19 582 49 21 582 minecraft:cobbled_deepslate
setblock 48 19 585 minecraft:cobbled_deepslate
setblock 48 19 586 minecraft:calcite
fill 48 19 587 48 21 588 minecraft:cobbled_deepslate
fill 48 19 592 48 22 592 minecraft:cobbled_deepslate
setblock 48 19 596 minecraft:calcite
fill 48 19 597 48 22 597 minecraft:cobbled_deepslate
setblock 49 19 559 minecraft:cobbled_deepslate
setblock 49 19 560 minecraft:calcite
setblock 49 19 580 minecraft:calcite
fill 49 19 581 49 22 581 minecraft:cobbled_deepslate
fill 49 19 583 49 19 584 minecraft:cobbled_deepslate
fill 49 19 596 49 21 596 minecraft:cobbled_deepslate
setblock 50 19 559 minecraft:calcite
setblock 51 19 558 minecraft:calcite
fill 51 19 559 54 19 559 minecraft:cobbled_deepslate
setblock 51 19 598 minecraft:calcite
fill 52 19 558 52 22 558 minecraft:cobbled_deepslate
setblock 52 19 596 minecraft:cobbled_deepslate
setblock 52 19 597 minecraft:calcite
fill 52 19 598 52 22 598 minecraft:cobbled_deepslate
setblock 53 19 596 minecraft:calcite
fill 53 19 597 53 22 597 minecraft:cobbled_deepslate
fill 54 19 596 54 21 596 minecraft:cobbled_deepslate
setblock 55 19 559 minecraft:calcite
fill 55 19 560 57 20 560 minecraft:cobbled_deepslate
setblock 56 19 558 minecraft:calcite
fill 56 19 559 56 22 559 minecraft:cobbled_deepslate
setblock 56 19 598 minecraft:calcite
fill 57 19 558 57 22 558 minecraft:cobbled_deepslate
setblock 57 19 597 minecraft:calcite
fill 57 19 598 57 22 598 minecraft:cobbled_deepslate
setblock 58 19 596 minecraft:calcite
fill 58 19 597 58 21 597 minecraft:cobbled_deepslate
setblock 59 19 559 minecraft:cobbled_deepslate
setblock 60 19 559 minecraft:calcite
setblock 61 19 558 minecraft:calcite
fill 61 19 559 61 20 559 minecraft:cobbled_deepslate
setblock 61 19 598 minecraft:calcite
fill 62 19 558 62 22 558 minecraft:cobbled_deepslate
fill 62 19 598 62 20 598 minecraft:cobbled_deepslate
setblock 66 19 558 minecraft:calcite
fill 67 19 558 67 22 558 minecraft:cobbled_deepslate
setblock 70 19 559 minecraft:calcite
setblock 71 19 558 minecraft:calcite
fill 71 19 559 71 22 559 minecraft:cobbled_deepslate
setblock 71 19 598 minecraft:calcite
fill 72 19 558 72 22 558 minecraft:cobbled_deepslate
fill 72 19 560 73 19 560 minecraft:cobbled_deepslate
fill 72 19 598 72 22 598 minecraft:cobbled_deepslate
setblock 74 19 560 minecraft:calcite
fill 74 19 561 77 19 561 minecraft:cobbled_deepslate
setblock 75 19 559 minecraft:calcite
fill 75 19 560 78 19 560 minecraft:cobbled_deepslate
setblock 76 19 558 minecraft:calcite
fill 76 19 559 76 22 559 minecraft:cobbled_deepslate
setblock 76 19 598 minecraft:calcite
fill 77 19 558 77 22 558 minecraft:cobbled_deepslate
setblock 77 19 597 minecraft:calcite
fill 77 19 598 77 22 598 minecraft:cobbled_deepslate
setblock 78 19 561 minecraft:calcite
fill 78 19 597 78 21 597 minecraft:cobbled_deepslate
setblock 79 19 560 minecraft:calcite
fill 79 19 561 79 22 561 minecraft:cobbled_deepslate
setblock 80 19 559 minecraft:calcite
fill 80 19 560 80 22 560 minecraft:cobbled_deepslate
setblock 81 19 558 minecraft:calcite
fill 81 19 559 81 22 559 minecraft:cobbled_deepslate
setblock 81 19 598 minecraft:calcite
fill 82 19 558 82 22 558 minecraft:cobbled_deepslate
setblock 82 19 597 minecraft:calcite
fill 82 19 598 82 22 598 minecraft:cobbled_deepslate
setblock 84 19 560 minecraft:calcite
setblock 85 19 559 minecraft:calcite
fill 85 19 560 86 21 560 minecraft:cobbled_deepslate
setblock 86 19 558 minecraft:calcite
fill 86 19 559 86 22 559 minecraft:cobbled_deepslate
fill 86 19 561 86 74 561 minecraft:calcite
setblock 86 19 598 minecraft:calcite
fill 87 19 558 87 22 558 minecraft:cobbled_deepslate
setblock 87 19 562 minecraft:calcite
fill 87 19 598 87 22 598 minecraft:cobbled_deepslate
setblock 88 19 561 minecraft:calcite
fill 88 19 562 88 22 562 minecraft:cobbled_deepslate
setblock 88 19 565 minecraft:cobbled_deepslate
setblock 88 19 580 minecraft:cobbled_deepslate
setblock 88 19 595 minecraft:cobbled_deepslate
setblock 88 19 596 minecraft:calcite
fill 88 19 597 88 22 597 minecraft:cobbled_deepslate
setblock 48 20 560 minecraft:calcite
fill 48 20 561 49 22 561 minecraft:cobbled_deepslate
fill 48 20 563 48 21 563 minecraft:cobbled_deepslate
fill 48 20 577 48 20 579 minecraft:cobbled_deepslate
setblock 48 20 580 minecraft:calcite
fill 48 20 581 48 23 581 minecraft:cobbled_deepslate
setblock 48 20 585 minecraft:calcite
fill 48 20 586 49 22 586 minecraft:cobbled_deepslate
setblock 48 20 589 minecraft:cobbled_deepslate
setblock 48 20 590 minecraft:calcite
fill 48 20 591 48 23 591 minecraft:cobbled_deepslate
setblock 48 20 595 minecraft:calcite
fill 48 20 596 48 23 596 minecraft:cobbled_deepslate
setblock 49 20 559 minecraft:calcite
fill 49 20 560 49 23 560 minecraft:cobbled_deepslate
setblock 49 20 579 minecraft:calcite
fill 49 20 580 49 23 580 minecraft:cobbled_deepslate
setblock 49 20 583 minecraft:cobbled_deepslate
setblock 49 20 584 minecraft:calcite
fill 49 20 585 49 23 585 minecraft:cobbled_deepslate
fill 49 20 587 49 21 587 minecraft:cobbled_deepslate
setblock 50 20 558 minecraft:calcite
fill 50 20 559 53 20 559 minecraft:cobbled_deepslate
setblock 50 20 582 minecraft:cobbled_deepslate
setblock 50 20 583 minecraft:calcite
setblock 50 20 598 minecraft:calcite
fill 51 20 558 51 23 558 minecraft:cobbled_deepslate
setblock 51 20 597 minecraft:calcite
fill 51 20 598 51 23 598 minecraft:cobbled_deepslate
setblock 52 20 596 minecraft:calcite
fill 52 20 597 52 23 597 minecraft:cobbled_deepslate
setblock 53 20 560 minecraft:calcite
fill 53 20 596 53 21 596 minecraft:cobbled_deepslate
setblock 54 20 559 minecraft:calcite
fill 54 20 560 54 22 560 minecraft:cobbled_deepslate
setblock 55 20 558 minecraft:calcite
fill 55 20 559 55 23 559 minecraft:cobbled_deepslate
setblock 55 20 598 minecraft:calcite
fill 56 20 558 56 23 558 minecraft:cobbled_deepslate
setblock 56 20 597 minecraft:calcite
fill 56 20 598 56 23 598 minecraft:cobbled_deepslate
setblock 57 20 596 minecraft:calcite
fill 57 20 597 57 22 597 minecraft:cobbled_deepslate
setblock 59 20 559 minecraft:calcite
setblock 60 20 558 minecraft:calcite
fill 60 20 559 60 21 559 minecraft:cobbled_deepslate
setblock 60 20 598 minecraft:calcite
fill 61 20 558 61 22 558 minecraft:cobbled_deepslate
fill 61 20 598 61 21 598 minecraft:cobbled_deepslate
setblock 65 20 558 minecraft:calcite
fill 66 20 558 66 22 558 minecraft:cobbled_deepslate
setblock 69 20 559 minecraft:calcite
setblock 70 20 558 minecraft:calcite
fill 70 20 559 70 23 559 minecraft:cobbled_deepslate
fill 71 20 558 71 23 558 minecraft:cobbled_deepslate
fill 71 20 560 72 20 560 minecraft:cobbled_deepslate
fill 71 20 598 71 22 598 minecraft:cobbled_deepslate
setblock 73 20 560 minecraft:calcite
fill 73 20 561 76 20 561 minecraft:cobbled_deepslate
setblock 74 20 559 minecraft:calcite
fill 74 20 560 77 20 560 minecraft:cobbled_deepslate
setblock 75 20 558 minecraft:calcite
fill 75 20 559 75 23 559 minecraft:cobbled_deepslate
setblock 75 20 598 minecraft:calcite
fill 76 20 558 76 23 558 minecraft:cobbled_deepslate
setblock 76 20 597 minecraft:calcite
fill 76 20 598 76 23 598 minecraft:cobbled_deepslate
setblock 77 20 561 minecraft:calcite
fill 77 20 597 77 21 597 minecraft:cobbled_deepslate
setblock 78 20 560 minecraft:calcite
fill 78 20 561 78 23 561 minecraft:cobbled_deepslate
setblock 79 20 559 minecraft:calcite
fill 79 20 560 79 23 560 minecraft:cobbled_deepslate
setblock 80 20 558 minecraft:calcite
fill 80 20 559 80 23 559 minecraft:cobbled_deepslate
setblock 80 20 598 minecraft:calcite
fill 81 20 558 81 23 558 minecraft:cobbled_deepslate
setblock 81 20 597 minecraft:calcite
fill 81 20 598 81 23 598 minecraft:cobbled_deepslate
setblock 83 20 560 minecraft:calcite
setblock 84 20 559 minecraft:calcite
fill 84 20 560 84 22 560 minecraft:cobbled_deepslate
setblock 85 20 558 minecraft:calcite
fill 85 20 559 85 23 559 minecraft:cobbled_deepslate
setblock 85 20 598 minecraft:calcite
fill 86 20 558 86 23 558 minecraft:cobbled_deepslate
fill 86 20 598 86 23 598 minecraft:cobbled_deepslate
setblock 87 20 560 minecraft:cobbled_deepslate
setblock 87 20 561 minecraft:calcite
fill 87 20 562 87 22 563 minecraft:cobbled_deepslate
setblock 88 20 560 minecraft:calcite
fill 88 20 561 88 23 561 minecraft:cobbled_deepslate
setblock 88 20 565 minecraft:calcite
setblock 88 20 579 minecraft:cobbled_deepslate
setblock 88 20 580 minecraft:calcite
fill 88 20 581 88 20 584 minecraft:cobbled_deepslate
setblock 88 20 595 minecraft:calcite
fill 88 20 596 88 23 596 minecraft:cobbled_deepslate
setblock 48 21 559 minecraft:calcite
fill 48 21 560 48 24 560 minecraft:cobbled_deepslate
setblock 48 21 564 minecraft:calcite
setblock 48 21 578 minecraft:cobbled_deepslate
setblock 48 21 579 minecraft:calcite
fill 48 21 580 48 24 580 minecraft:cobbled_deepslate
setblock 48 21 583 minecraft:cobbled_deepslate
setblock 48 21 584 minecraft:calcite
fill 48 21 585 48 24 585 minecraft:cobbled_deepslate
setblock 48 21 589 minecraft:calcite
fill 48 21 590 48 24 590 minecraft:cobbled_deepslate
setblock 48 21 594 minecraft:calcite
fill 48 21 595 48 24 595 minecraft:cobbled_deepslate
setblock 49 21 558 minecraft:calcite
fill 49 21 559 52 21 559 minecraft:cobbled_deepslate
fill 49 21 579 49 23 579 minecraft:cobbled_deepslate
setblock 49 21 583 minecraft:calcite
fill 49 21 584 50 23 584 minecraft:cobbled_deepslate
setblock 49 21 588 minecraft:calcite
fill 49 21 589 49 24 589 minecraft:cobbled_deepslate
setblock 49 21 598 minecraft:calcite
fill 50 21 558 50 24 558 minecraft:cobbled_deepslate
fill 50 21 580 50 21 581 minecraft:cobbled_deepslate
setblock 50 21 582 minecraft:calcite
fill 50 21 583 50 24 583 minecraft:cobbled_deepslate
fill 50 21 585 50 21 586 minecraft:cobbled_deepslate
setblock 50 21 597 minecraft:calcite
fill 50 21 598 50 24 598 minecraft:cobbled_deepslate
fill 51 21 597 51 24 597 minecraft:cobbled_deepslate
setblock 53 21 559 minecraft:calcite
fill 53 21 560 53 22 560 minecraft:cobbled_deepslate
setblock 54 21 558 minecraft:calcite
fill 54 21 559 54 24 559 minecraft:cobbled_deepslate
setblock 54 21 598 minecraft:calcite
fill 55 21 558 55 24 558 minecraft:cobbled_deepslate
fill 55 21 560 56 21 560 minecraft:cobbled_deepslate
setblock 55 21 597 minecraft:calcite
fill 55 21 598 55 24 598 minecraft:cobbled_deepslate
fill 56 21 597 56 23 597 minecraft:cobbled_deepslate
setblock 57 21 560 minecraft:calcite
setblock 58 21 559 minecraft:calcite
setblock 59 21 558 minecraft:calcite
fill 59 21 559 59 22 559 minecraft:cobbled_deepslate
setblock 59 21 598 minecraft:calcite
fill 60 21 558 60 23 558 minecraft:cobbled_deepslate
fill 60 21 598 60 22 598 minecraft:cobbled_deepslate
setblock 64 21 558 minecraft:calcite
setblock 65 21 558 minecraft:cobbled_deepslate
setblock 68 21 558 minecraft:cobbled_deepslate
setblock 69 21 558 minecraft:calcite
fill 69 21 559 69 24 559 minecraft:cobbled_deepslate
fill 70 21 558 70 24 558 minecraft:cobbled_deepslate
fill 70 21 560 71 21 560 minecraft:cobbled_deepslate
setblock 72 21 560 minecraft:calcite
fill 72 21 561 75 21 561 minecraft:cobbled_deepslate
setblock 73 21 559 minecraft:calcite
fill 73 21 560 76 21 560 minecraft:cobbled_deepslate
setblock 74 21 558 minecraft:calcite
fill 74 21 559 74 24 559 minecraft:cobbled_deepslate
setblock 74 21 598 minecraft:calcite
fill 75 21 558 75 24 558 minecraft:cobbled_deepslate
setblock 75 21 597 minecraft:calcite
fill 75 21 598 75 24 598 minecraft:cobbled_deepslate
setblock 76 21 561 minecraft:calcite
fill 76 21 562 77 22 562 minecraft:cobbled_deepslate
setblock 76 21 597 minecraft:cobbled_deepslate
setblock 77 21 560 minecraft:calcite
fill 77 21 561 77 24 561 minecraft:cobbled_deepslate
setblock 78 21 559 minecraft:calcite
fill 78 21 560 78 24 560 minecraft:cobbled_deepslate
setblock 79 21 558 minecraft:calcite
fill 79 21 559 79 24 559 minecraft:cobbled_deepslate
setblock 79 21 598 minecraft:calcite
fill 80 21 558 80 24 558 minecraft:cobbled_deepslate
setblock 80 21 561 minecraft:cobbled_deepslate
fill 80 21 598 80 23 598 minecraft:cobbled_deepslate
setblock 81 21 561 minecraft:calcite
setblock 82 21 560 minecraft:calcite
setblock 83 21 559 minecraft:calcite
fill 83 21 560 83 22 560 minecraft:cobbled_deepslate
setblock 84 21 558 minecraft:calcite
fill 84 21 559 84 24 559 minecraft:cobbled_deepslate
setblock 84 21 598 minecraft:calcite
fill 85 21 558 85 24 558 minecraft:cobbled_deepslate
fill 85 21 598 85 23 598 minecraft:cobbled_deepslate
setblock 87 21 560 minecraft:calcite
fill 87 21 561 87 24 561 minecraft:cobbled_deepslate
setblock 88 21 559 minecraft:calcite
fill 88 21 560 88 24 560 minecraft:cobbled_deepslate
setblock 88 21 563 minecraft:cobbled_deepslate
setblock 88 21 564 minecraft:calcite
fill 88 21 565 88 23 566 minecraft:cobbled_deepslate
fill 88 21 580 88 21 583 minecraft:cobbled_deepslate
setblock 88 21 584 minecraft:calcite
fill 88 21 585 88 23 586 minecraft:cobbled_deepslate
fill 88 21 595 88 23 595 minecraft:cobbled_deepslate
setblock 48 22 558 minecraft:calcite
fill 48 22 559 51 22 559 minecraft:cobbled_deepslate
setblock 48 22 563 minecraft:calcite
fill 48 22 564 48 25 564 minecraft:cobbled_deepslate
setblock 48 22 578 minecraft:calcite
fill 48 22 579 48 25 579 minecraft:cobbled_deepslate
setblock 48 22 582 minecraft:cobbled_deepslate
setblock 48 22 583 minecraft:calcite
fill 48 22 584 48 25 584 minecraft:cobbled_deepslate
setblock 48 22 587 minecraft:cobbled_deepslate
setblock 48 22 588 minecraft:calcite
fill 48 22 589 48 25 589 minecraft:cobbled_deepslate
setblock 48 22 593 minecraft:calcite
fill 48 22 594 48 25 594 minecraft:cobbled_deepslate
setblock 48 22 598 minecraft:calcite
fill 49 22 558 49 25 558 minecraft:cobbled_deepslate
setblock 49 22 562 minecraft:calcite
setblock 49 22 582 minecraft:calcite
fill 49 22 583 49 25 583 minecraft:cobbled_deepslate
setblock 49 22 587 minecraft:calcite
fill 49 22 588 50 24 588 minecraft:cobbled_deepslate
fill 49 22 590 49 23 590 minecraft:cobbled_deepslate
setblock 49 22 597 minecraft:calcite
fill 49 22 598 49 25 598 minecraft:cobbled_deepslate
setblock 50 22 580 minecraft:cobbled_deepslate
setblock 50 22 581 minecraft:calcite
fill 50 22 582 51 23 582 minecraft:cobbled_deepslate
setblock 50 22 585 minecraft:cobbled_deepslate
setblock 50 22 586 minecraft:calcite
fill 50 22 587 50 25 587 minecraft:cobbled_deepslate
fill 50 22 597 50 23 597 minecraft:cobbled_deepslate
fill 51 22 583 51 22 584 minecraft:cobbled_deepslate
setblock 51 22 585 minecraft:calcite
setblock 52 22 559 minecraft:calcite
setblock 53 22 558 minecraft:calcite
fill 53 22 559 53 24 559 minecraft:cobbled_deepslate
setblock 53 22 598 minecraft:calcite
fill 54 22 558 54 25 558 minecraft:cobbled_deepslate
setblock 54 22 597 minecraft:calcite
fill 54 22 598 54 25 598 minecraft:cobbled_deepslate
setblock 55 22 560 minecraft:cobbled_deepslate
fill 55 22 597 55 23 597 minecraft:cobbled_deepslate
setblock 56 22 560 minecraft:calcite
setblock 57 22 559 minecraft:calcite
setblock 58 22 558 minecraft:calcite
fill 58 22 559 58 23 559 minecraft:cobbled_deepslate
setblock 58 22 598 minecraft:calcite
fill 59 22 558 59 23 558 minecraft:cobbled_deepslate
setblock 59 22 598 minecraft:cobbled_deepslate
setblock 68 22 558 minecraft:calcite
setblock 68 22 559 minecraft:cobbled_deepslate
fill 69 22 558 69 25 558 minecraft:cobbled_deepslate
setblock 70 22 560 minecraft:cobbled_deepslate
setblock 71 22 560 minecraft:calcite
setblock 72 22 559 minecraft:calcite
fill 72 22 560 74 22 561 minecraft:cobbled_deepslate
setblock 73 22 558 minecraft:calcite
fill 73 22 559 73 25 559 minecraft:cobbled_deepslate
setblock 73 22 598 minecraft:calcite
fill 74 22 558 74 25 558 minecraft:cobbled_deepslate
fill 74 22 598 74 25 598 minecraft:cobbled_deepslate
setblock 75 22 560 minecraft:cobbled_deepslate
setblock 75 22 561 minecraft:calcite
fill 75 22 562 75 23 562 minecraft:cobbled_deepslate
setblock 76 22 560 minecraft:calcite
fill 76 22 561 76 25 561 minecraft:cobbled_deepslate
setblock 77 22 559 minecraft:calcite
fill 77 22 560 77 25 560 minecraft:cobbled_deepslate
setblock 78 22 558 minecraft:calcite
fill 78 22 559 78 25 559 minecraft:cobbled_deepslate
fill 78 22 592 78 23 592 minecraft:light_blue_stained_glass
setblock 78 22 598 minecraft:calcite
fill 79 22 558 79 25 558 minecraft:cobbled_deepslate
fill 79 22 598 79 24 598 minecraft:cobbled_deepslate
setblock 80 22 561 minecraft:calcite
setblock 81 22 560 minecraft:calcite
setblock 82 22 559 minecraft:calcite
fill 82 22 560 82 23 560 minecraft:cobbled_deepslate
setblock 83 22 558 minecraft:calcite
fill 83 22 559 83 24 559 minecraft:cobbled_deepslate
setblock 83 22 598 minecraft:calcite
fill 84 22 558 84 25 558 minecraft:cobbled_deepslate
fill 84 22 598 84 23 598 minecraft:cobbled_deepslate
fill 85 22 560 86 73 560 minecraft:calcite
setblock 87 22 559 minecraft:calcite
fill 87 22 560 87 25 560 minecraft:cobbled_deepslate
setblock 87 22 564 minecraft:calcite
setblock 88 22 558 minecraft:calcite
fill 88 22 559 88 25 559 minecraft:cobbled_deepslate
setblock 88 22 563 minecraft:calcite
fill 88 22 564 88 25 564 minecraft:cobbled_deepslate
fill 88 22 580 88 22 582 minecraft:cobbled_deepslate
setblock 88 22 583 minecraft:calcite
fill 88 22 584 88 25 584 minecraft:cobbled_deepslate
setblock 88 22 587 minecraft:cobbled_deepslate
setblock 88 22 588 minecraft:calcite
setblock 88 22 598 minecraft:calcite
fill 48 23 558 48 25 559 minecraft:cobbled_deepslate
setblock 48 23 561 minecraft:cobbled_deepslate
setblock 48 23 562 minecraft:calcite
fill 48 23 563 48 26 563 minecraft:cobbled_deepslate
fill 48 23 565 48 24 565 minecraft:cobbled_deepslate
setblock 48 23 578 minecraft:cobbled_deepslate
setblock 48 23 582 minecraft:calcite
fill 48 23 583 48 26 583 minecraft:cobbled_deepslate
setblock 48 23 586 minecraft:cobbled_deepslate
setblock 48 23 587 minecraft:calcite
fill 48 23 588 48 26 588 minecraft:cobbled_deepslate
setblock 48 23 592 minecraft:calcite
fill 48 23 593 48 26 593 minecraft:cobbled_deepslate
setblock 48 23 597 minecraft:calcite
fill 48 23 598 48 26 598 minecraft:cobbled_deepslate
fill 49 23 559 50 23 559 minecraft:cobbled_deepslate
setblock 49 23 561 minecraft:calcite
setblock 49 23 562 minecraft:cobbled_deepslate
setblock 49 23 581 minecraft:calcite
fill 49 23 582 49 26 582 minecraft:cobbled_deepslate
setblock 49 23 586 minecraft:calcite
fill 49 23 587 49 26 587 minecraft:cobbled_deepslate
setblock 49 23 591 minecraft:calcite
fill 50 23 581 50 25 581 minecraft:cobbled_deepslate
setblock 50 23 585 minecraft:calcite
fill 50 23 586 51 25 586 minecraft:cobbled_deepslate
setblock 50 23 589 minecraft:cobbled_deepslate
setblock 51 23 559 minecraft:calcite
setblock 51 23 583 minecraft:cobbled_deepslate
setblock 51 23 584 minecraft:calcite
fill 51 23 585 51 26 585 minecraft:cobbled_deepslate
setblock 52 23 558 minecraft:calcite
fill 52 23 559 52 24 559 minecraft:cobbled_deepslate
setblock 52 23 598 minecraft:calcite
fill 53 23 558 53 26 558 minecraft:cobbled_deepslate
setblock 53 23 597 minecraft:calcite
fill 53 23 598 53 26 598 minecraft:cobbled_deepslate
fill 54 23 597 54 24 597 minecraft:cobbled_deepslate
setblock 56 23 559 minecraft:calcite
setblock 57 23 558 minecraft:calcite
setblock 57 23 559 minecraft:cobbled_deepslate
setblock 57 23 598 minecraft:calcite
fill 58 23 558 58 24 558 minecraft:cobbled_deepslate
setblock 58 23 598 minecraft:cobbled_deepslate
setblock 67 23 558 minecraft:calcite
fill 68 23 558 68 26 558 minecraft:cobbled_deepslate
setblock 70 23 560 minecraft:calcite
setblock 71 23 559 minecraft:calcite
fill 71 23 560 74 23 560 minecraft:cobbled_deepslate
setblock 72 23 558 minecraft:calcite
fill 72 23 559 72 26 559 minecraft:cobbled_deepslate
fill 72 23 561 73 23 561 minecraft:cobbled_deepslate
setblock 72 23 598 minecraft:calcite
fill 73 23 558 73 26 558 minecraft:cobbled_deepslate
fill 73 23 598 73 25 598 minecraft:cobbled_deepslate
setblock 74 23 561 minecraft:calcite
setblock 75 23 560 minecraft:calcite
fill 75 23 561 75 25 561 minecraft:cobbled_deepslate
setblock 76 23 559 minecraft:calcite
fill 76 23 560 76 26 560 minecraft:cobbled_deepslate
setblock 77 23 558 minecraft:calcite
fill 77 23 559 77 26 559 minecraft:cobbled_deepslate
setblock 77 23 598 minecraft:calcite
fill 78 23 558 78 26 558 minecraft:cobbled_deepslate
fill 78 23 598 78 24 598 minecraft:cobbled_deepslate
setblock 79 23 561 minecraft:calcite
setblock 80 23 560 minecraft:calcite
setblock 81 23 559 minecraft:calcite
setblock 81 23 560 minecraft:cobbled_deepslate
setblock 82 23 558 minecraft:calcite
fill 82 23 559 82 24 559 minecraft:cobbled_deepslate
setblock 82 23 598 minecraft:calcite
fill 83 23 558 83 26 558 minecraft:cobbled_deepslate
setblock 83 23 598 minecraft:cobbled_deepslate
fill 84 23 560 84 74 560 minecraft:calcite
setblock 86 23 559 minecraft:calcite
fill 86 23 568 88 27 570 minecraft:light_blue_stained_glass
setblock 87 23 558 minecraft:calcite
fill 87 23 559 87 25 559 minecraft:cobbled_deepslate
setblock 87 23 562 minecraft:cobbled_deepslate
setblock 87 23 563 minecraft:calcite
fill 87 23 564 87 24 564 minecraft:cobbled_deepslate
setblock 87 23 598 minecraft:calcite
fill 88 23 558 88 26 558 minecraft:cobbled_deepslate
setblock 88 23 562 minecraft:calcite
fill 88 23 563 88 26 563 minecraft:cobbled_deepslate
setblock 88 23 581 minecraft:cobbled_deepslate
setblock 88 23 582 minecraft:calcite
fill 88 23 583 88 26 583 minecraft:cobbled_deepslate
setblock 88 23 587 minecraft:calcite
fill 88 23 588 88 25 589 minecraft:cobbled_deepslate
setblock 88 23 597 minecraft:calcite
fill 88 23 598 88 26 598 minecraft:cobbled_deepslate
setblock 48 24 561 minecraft:calcite
fill 48 24 562 48 27 562 minecraft:cobbled_deepslate
setblock 48 24 581 minecraft:calcite
fill 48 24 582 48 27 582 minecraft:cobbled_deepslate
setblock 48 24 586 minecraft:calcite
fill 48 24 587 48 27 587 minecraft:cobbled_deepslate
setblock 48 24 591 minecraft:calcite
fill 48 24 592 49 26 592 minecraft:cobbled_deepslate
setblock 48 24 596 minecraft:calcite
fill 48 24 597 48 26 597 minecraft:cobbled_deepslate
fill 49 24 572 49 30 572 minecraft:calcite
setblock 49 24 580 minecraft:calcite
fill 49 24 581 49 27 581 minecraft:cobbled_deepslate
setblock 49 24 584 minecraft:cobbled_deepslate
setblock 49 24 585 minecraft:calcite
fill 49 24 586 49 27 586 minecraft:cobbled_deepslate
setblock 49 24 590 minecraft:calcite
fill 49 24 591 49 27 591 minecraft:cobbled_deepslate
setblock 50 24 559 minecraft:calcite
setblock 50 24 560 minecraft:light[level=14]
setblock 50 24 568 minecraft:light[level=14]
setblock 50 24 576 minecraft:light[level=14]
fill 50 24 582 50 25 582 minecraft:cobbled_deepslate
setblock 50 24 584 minecraft:calcite
fill 50 24 585 50 27 585 minecraft:cobbled_deepslate
setblock 50 24 589 minecraft:calcite
setblock 50 24 592 minecraft:light[level=14]
setblock 51 24 558 minecraft:calcite
setblock 51 24 559 minecraft:cobbled_deepslate
setblock 51 24 583 minecraft:calcite
fill 51 24 584 51 27 584 minecraft:cobbled_deepslate
setblock 51 24 587 minecraft:cobbled_deepslate
setblock 51 24 598 minecraft:calcite
fill 52 24 558 52 26 558 minecraft:cobbled_deepslate
setblock 52 24 597 minecraft:calcite
fill 52 24 598 52 27 598 minecraft:cobbled_deepslate
setblock 53 24 597 minecraft:cobbled_deepslate
setblock 55 24 559 minecraft:calcite
setblock 56 24 558 minecraft:calcite
setblock 56 24 559 minecraft:cobbled_deepslate
setblock 56 24 598 minecraft:calcite
setblock 57 24 558 minecraft:cobbled_deepslate
setblock 57 24 598 minecraft:cobbled_deepslate
setblock 58 24 560 minecraft:light[level=14]
setblock 58 24 568 minecraft:light[level=14]
setblock 58 24 576 minecraft:light[level=14]
setblock 58 24 584 minecraft:light[level=14]
setblock 58 24 592 minecraft:light[level=14]
setblock 66 24 560 minecraft:light[level=14]
setblock 66 24 568 minecraft:light[level=14]
setblock 66 24 576 minecraft:light[level=14]
setblock 66 24 584 minecraft:light[level=14]
setblock 66 24 592 minecraft:light[level=14]
setblock 70 24 559 minecraft:calcite
fill 70 24 560 73 24 560 minecraft:cobbled_deepslate
setblock 71 24 558 minecraft:calcite
fill 71 24 559 71 27 559 minecraft:cobbled_deepslate
fill 72 24 558 72 27 558 minecraft:cobbled_deepslate
setblock 72 24 561 minecraft:cobbled_deepslate
setblock 72 24 598 minecraft:cobbled_deepslate
setblock 73 24 561 minecraft:calcite
setblock 74 24 560 minecraft:calcite
fill 74 24 561 74 26 561 minecraft:cobbled_deepslate
setblock 74 24 568 minecraft:light[level=14]
setblock 74 24 576 minecraft:light[level=14]
setblock 74 24 584 minecraft:light[level=14]
setblock 74 24 592 minecraft:light[level=14]
setblock 75 24 559 minecraft:calcite
fill 75 24 560 75 27 560 minecraft:cobbled_deepslate
setblock 76 24 558 minecraft:calcite
fill 76 24 559 76 27 559 minecraft:cobbled_deepslate
setblock 76 24 598 minecraft:calcite
fill 77 24 558 77 27 558 minecraft:cobbled_deepslate
fill 77 24 598 77 25 598 minecraft:cobbled_deepslate
setblock 78 24 561 minecraft:calcite
fill 78 24 592 78 31 592 minecraft:deepslate
setblock 79 24 560 minecraft:calcite
setblock 80 24 559 minecraft:calcite
setblock 80 24 560 minecraft:cobbled_deepslate
setblock 81 24 558 minecraft:calcite
fill 81 24 559 81 25 559 minecraft:cobbled_deepslate
fill 82 24 558 82 26 558 minecraft:cobbled_deepslate
setblock 82 24 560 minecraft:light[level=14]
setblock 82 24 568 minecraft:light[level=14]
setblock 82 24 576 minecraft:light[level=14]
setblock 82 24 584 minecraft:light[level=14]
setblock 82 24 592 minecraft:light[level=14]
fill 84 24 569 85 28 569 minecraft:light_blue_stained_glass
setblock 85 24 559 minecraft:calcite
fill 85 24 568 85 28 568 minecraft:light_blue_stained_glass
fill 85 24 570 85 28 570 minecraft:light_blue_stained_glass
setblock 86 24 558 minecraft:calcite
setblock 86 24 559 minecraft:cobbled_deepslate
fill 86 24 567 87 27 567 minecraft:light_blue_stained_glass
fill 86 24 571 88 27 571 minecraft:light_blue_stained_glass
setblock 86 24 598 minecraft:calcite
fill 87 24 558 87 27 558 minecraft:cobbled_deepslate
setblock 87 24 562 minecraft:calcite
fill 87 24 563 87 26 563 minecraft:cobbled_deepslate
fill 87 24 598 87 25 598 minecraft:cobbled_deepslate
setblock 88 24 561 minecraft:calcite
fill 88 24 562 88 27 562 minecraft:cobbled_deepslate
setblock 88 24 565 minecraft:cobbled_deepslate
setblock 88 24 566 minecraft:calcite
fill 88 24 567 88 27 567 minecraft:cobbled_deepslate
setblock 88 24 581 minecraft:calcite
fill 88 24 582 88 27 582 minecraft:cobbled_deepslate
setblock 88 24 585 minecraft:cobbled_deepslate
setblock 88 24 586 minecraft:calcite
fill 88 24 587 88 27 587 minecraft:cobbled_deepslate
setblock 88 24 590 minecraft:cobbled_deepslate
setblock 88 24 591 minecraft:calcite
setblock 88 24 596 minecraft:calcite
fill 88 24 597 88 27 597 minecraft:cobbled_deepslate
setblock 48 25 560 minecraft:calcite
fill 48 25 561 48 28 561 minecraft:cobbled_deepslate
setblock 48 25 565 minecraft:calcite
setblock 48 25 580 minecraft:calcite
fill 48 25 581 48 28 581 minecraft:cobbled_deepslate
setblock 48 25 585 minecraft:calcite
fill 48 25 586 48 28 586 minecraft:cobbled_deepslate
setblock 48 25 590 minecraft:calcite
fill 48 25 591 48 28 591 minecraft:cobbled_deepslate
setblock 48 25 595 minecraft:calcite
fill 48 25 596 48 28 596 minecraft:cobbled_deepslate
fill 49 25 580 49 26 580 minecraft:cobbled_deepslate
setblock 49 25 584 minecraft:calcite
fill 49 25 585 49 28 585 minecraft:cobbled_deepslate
setblock 49 25 588 minecraft:cobbled_deepslate
setblock 49 25 589 minecraft:calcite
fill 49 25 590 50 27 590 minecraft:cobbled_deepslate
setblock 50 25 558 minecraft:calcite
setblock 50 25 583 minecraft:calcite
fill 50 25 584 50 28 584 minecraft:cobbled_deepslate
setblock 50 25 588 minecraft:calcite
fill 50 25 589 50 28 589 minecraft:cobbled_deepslate
setblock 50 25 598 minecraft:calcite
fill 51 25 558 51 26 558 minecraft:cobbled_deepslate
setblock 51 25 583 minecraft:cobbled_deepslate
setblock 51 25 587 minecraft:calcite
fill 51 25 598 51 28 598 minecraft:cobbled_deepslate
setblock 55 25 558 minecraft:calcite
setblock 55 25 598 minecraft:calcite
setblock 56 25 558 minecraft:cobbled_deepslate
setblock 69 25 559 minecraft:calcite
setblock 70 25 558 minecraft:calcite
fill 70 25 559 70 25 560 minecraft:cobbled_deepslate
fill 71 25 558 71 28 558 minecraft:cobbled_deepslate
fill 71 25 560 72 25 560 minecraft:cobbled_deepslate
setblock 72 25 561 minecraft:calcite
setblock 73 25 560 minecraft:calcite
fill 73 25 561 73 26 561 minecraft:cobbled_deepslate
setblock 74 25 559 minecraft:calcite
fill 74 25 560 74 28 560 minecraft:cobbled_deepslate
setblock 75 25 558 minecraft:calcite
fill 75 25 559 75 28 559 minecraft:cobbled_deepslate
setblock 75 25 598 minecraft:calcite
fill 76 25 558 76 28 558 minecraft:cobbled_deepslate
setblock 76 25 598 minecraft:cobbled_deepslate
fill 77 25 592 77 31 592 minecraft:deepslate
setblock 78 25 560 minecraft:calcite
setblock 79 25 559 minecraft:calcite
setblock 79 25 560 minecraft:cobbled_deepslate
setblock 80 25 558 minecraft:calcite
setblock 80 25 559 minecraft:cobbled_deepslate
fill 81 25 558 81 26 558 minecraft:cobbled_deepslate
fill 83 25 568 83 27 570 minecraft:light_blue_stained_glass
fill 84 25 568 84 27 568 minecraft:light_blue_stained_glass
fill 84 25 570 84 27 570 minecraft:light_blue_stained_glass
setblock 85 25 558 minecraft:calcite
fill 85 25 567 85 27 567 minecraft:light_blue_stained_glass
fill 85 25 571 85 27 571 minecraft:light_blue_stained_glass
fill 86 25 558 86 27 558 minecraft:cobbled_deepslate
setblock 87 25 561 minecraft:calcite
fill 87 25 562 87 26 562 minecraft:cobbled_deepslate
fill 87 25 566 87 26 566 minecraft:light_blue_stained_glass
fill 87 25 572 87 26 572 minecraft:light_blue_stained_glass
setblock 88 25 560 minecraft:calcite
fill 88 25 561 88 28 561 minecraft:cobbled_deepslate
setblock 88 25 565 minecraft:calcite
fill 88 25 566 88 28 566 minecraft:cobbled_deepslate
setblock 88 25 585 minecraft:calcite
fill 88 25 586 88 28 586 minecraft:cobbled_deepslate
setblock 88 25 590 minecraft:calcite
fill 88 25 591 88 26 593 minecraft:cobbled_deepslate
fill 88 25 596 88 28 596 minecraft:cobbled_deepslate
setblock 48 26 560 minecraft:cobbled_deepslate
setblock 48 26 564 minecraft:calcite
fill 48 26 565 48 28 566 minecraft:cobbled_deepslate
setblock 48 26 579 minecraft:calcite
fill 48 26 580 48 29 580 minecraft:cobbled_deepslate
setblock 48 26 584 minecraft:calcite
fill 48 26 585 48 29 585 minecraft:cobbled_deepslate
setblock 48 26 589 minecraft:calcite
fill 48 26 590 48 29 590 minecraft:cobbled_deepslate
setblock 48 26 594 minecraft:calcite
fill 48 26 595 48 29 595 minecraft:cobbled_deepslate
setblock 49 26 583 minecraft:calcite
fill 49 26 584 49 29 584 minecraft:cobbled_deepslate
setblock 49 26 588 minecraft:calcite
fill 49 26 589 49 29 589 minecraft:cobbled_deepslate
setblock 49 26 598 minecraft:calcite
setblock 50 26 558 minecraft:cobbled_deepslate
setblock 50 26 582 minecraft:calcite
fill 50 26 583 50 29 583 minecraft:cobbled_deepslate
setblock 50 26 586 minecraft:cobbled_deepslate
setblock 50 26 587 minecraft:calcite
fill 50 26 588 51 28 588 minecraft:cobbled_deepslate
fill 50 26 598 50 29 598 minecraft:cobbled_deepslate
setblock 51 26 586 minecraft:calcite
fill 51 26 587 51 29 587 minecraft:cobbled_deepslate
setblock 54 26 558 minecraft:calcite
setblock 54 26 598 minecraft:calcite
setblock 69 26 558 minecraft:calcite
fill 69 26 559 70 26 559 minecraft:cobbled_deepslate
fill 70 26 558 70 29 558 minecraft:cobbled_deepslate
setblock 71 26 560 minecraft:cobbled_deepslate
setblock 72 26 560 minecraft:calcite
setblock 73 26 559 minecraft:calcite
fill 73 26 560 73 28 560 minecraft:cobbled_deepslate
setblock 74 26 558 minecraft:calcite
fill 74 26 559 74 29 559 minecraft:cobbled_deepslate
fill 75 26 558 75 29 558 minecraft:cobbled_deepslate
setblock 77 26 560 minecraft:calcite
fill 77 26 591 78 31 591 minecraft:deepslate
setblock 78 26 559 minecraft:calcite
fill 78 26 593 78 31 593 minecraft:deepslate
setblock 79 26 558 minecraft:calcite
setblock 79 26 559 minecraft:cobbled_deepslate
fill 80 26 558 80 27 558 minecraft:cobbled_deepslate
fill 82 26 569 82 27 569 minecraft:light_blue_stained_glass
setblock 84 26 558 minecraft:calcite
setblock 84 26 567 minecraft:light_blue_stained_glass
setblock 84 26 571 minecraft:light_blue_stained_glass
setblock 85 26 558 minecraft:cobbled_deepslate
setblock 87 26 561 minecraft:cobbled_deepslate
fill 87 26 583 87 28 583 minecraft:deepslate
setblock 88 26 559 minecraft:calcite
fill 88 26 560 88 29 560 minecraft:cobbled_deepslate
setblock 88 26 564 minecraft:calcite
fill 88 26 565 88 29 565 minecraft:cobbled_deepslate
setblock 88 26 584 minecraft:calcite
fill 88 26 585 88 29 585 minecraft:cobbled_deepslate
setblock 88 26 588 minecraft:cobbled_deepslate
setblock 88 26 589 minecraft:calcite
fill 88 26 590 88 29 590 minecraft:cobbled_deepslate
setblock 88 26 594 minecraft:calcite
fill 88 26 595 88 29 595 minecraft:cobbled_deepslate
setblock 48 27 563 minecraft:calcite
fill 48 27 564 48 30 564 minecraft:cobbled_deepslate
setblock 48 27 567 minecraft:cobbled_deepslate
fill 48 27 579 48 30 579 minecraft:cobbled_deepslate
setblock 48 27 583 minecraft:calcite
fill 48 27 584 48 30 584 minecraft:cobbled_deepslate
setblock 48 27 588 minecraft:calcite
fill 48 27 589 48 30 589 minecraft:cobbled_deepslate
setblock 48 27 592 minecraft:cobbled_deepslate
setblock 48 27 593 minecraft:calcite
fill 48 27 594 48 30 594 minecraft:cobbled_deepslate
setblock 49 27 582 minecraft:calcite
fill 49 27 583 49 30 583 minecraft:cobbled_deepslate
setblock 49 27 587 minecraft:calcite
fill 49 27 588 49 30 588 minecraft:cobbled_deepslate
setblock 49 27 592 minecraft:calcite
fill 49 27 593 49 30 593 minecraft:cobbled_deepslate
fill 49 27 598 49 30 598 minecraft:cobbled_deepslate
fill 50 27 582 50 30 582 minecraft:cobbled_deepslate
setblock 50 27 586 minecraft:calcite
fill 50 27 587 50 30 587 minecraft:cobbled_deepslate
setblock 50 27 591 minecraft:calcite
setblock 51 27 585 minecraft:calcite
fill 51 27 586 51 30 586 minecraft:cobbled_deepslate
fill 57 27 596 59 32 598 minecraft:light_blue_stained_glass
setblock 68 27 558 minecraft:calcite
fill 69 27 558 69 30 558 minecraft:cobbled_deepslate
fill 70 27 559 70 28 559 minecraft:cobbled_deepslate
setblock 71 27 560 minecraft:calcite
setblock 72 27 559 minecraft:calcite
fill 72 27 560 72 28 560 minecraft:cobbled_deepslate
setblock 73 27 558 minecraft:calcite
fill 73 27 559 73 30 559 minecraft:cobbled_deepslate
fill 74 27 558 74 30 558 minecraft:cobbled_deepslate
fill 76 27 592 76 31 592 minecraft:deepslate
setblock 77 27 559 minecraft:calcite
fill 77 27 593 77 31 593 minecraft:deepslate
setblock 78 27 558 minecraft:calcite
setblock 78 27 559 minecraft:cobbled_deepslate
setblock 79 27 558 minecraft:cobbled_deepslate
fill 79 27 592 79 31 592 minecraft:deepslate
setblock 88 27 558 minecraft:calcite
fill 88 27 559 88 30 559 minecraft:cobbled_deepslate
setblock 88 27 563 minecraft:calcite
fill 88 27 564 88 30 564 minecraft:cobbled_deepslate
setblock 88 27 583 minecraft:calcite
fill 88 27 584 88 30 584 minecraft:cobbled_deepslate
setblock 88 27 588 minecraft:calcite
fill 88 27 589 88 30 589 minecraft:cobbled_deepslate
fill 88 27 591 88 27 592 minecraft:cobbled_deepslate
setblock 88 27 593 minecraft:calcite
fill 88 27 594 88 30 594 minecraft:cobbled_deepslate
setblock 88 27 598 minecraft:calcite
setblock 48 28 562 minecraft:calcite
fill 48 28 563 48 31 563 minecraft:cobbled_deepslate
setblock 48 28 567 minecraft:calcite
fill 48 28 568 48 30 569 minecraft:cobbled_deepslate
setblock 48 28 582 minecraft:calcite
fill 48 28 583 48 31 583 minecraft:cobbled_deepslate
setblock 48 28 587 minecraft:calcite
fill 48 28 588 48 31 588 minecraft:cobbled_deepslate
setblock 48 28 592 minecraft:calcite
fill 48 28 593 48 31 593 minecraft:cobbled_deepslate
setblock 48 28 597 minecraft:calcite
setblock 49 28 581 minecraft:calcite
fill 49 28 582 49 31 582 minecraft:cobbled_deepslate
setblock 49 28 586 minecraft:calcite
fill 49 28 587 49 31 587 minecraft:cobbled_deepslate
setblock 49 28 590 minecraft:cobbled_deepslate
setblock 49 28 591 minecraft:calcite
fill 49 28 592 49 31 592 minecraft:cobbled_deepslate
fill 49 28 594 49 29 594 minecraft:cobbled_deepslate
setblock 50 28 585 minecraft:calcite
fill 50 28 586 50 31 586 minecraft:cobbled_deepslate
setblock 50 28 590 minecraft:calcite
fill 50 28 591 50 31 591 minecraft:cobbled_deepslate
fill 51 28 585 51 31 585 minecraft:cobbled_deepslate
setblock 51 28 589 minecraft:calcite
fill 56 28 596 56 31 598 minecraft:light_blue_stained_glass
fill 57 28 595 59 31 595 minecraft:light_blue_stained_glass
fill 58 28 594 58 31 594 minecraft:light_blue_stained_glass
fill 60 28 596 60 31 598 minecraft:light_blue_stained_glass
fill 68 28 558 68 31 558 minecraft:cobbled_deepslate
setblock 71 28 559 minecraft:calcite
setblock 72 28 558 minecraft:calcite
fill 72 28 559 72 31 559 minecraft:cobbled_deepslate
fill 73 28 558 73 31 558 minecraft:cobbled_deepslate
setblock 76 28 559 minecraft:calcite
fill 76 28 591 76 31 591 minecraft:deepslate
fill 76 28 593 76 31 593 minecraft:deepslate
setblock 77 28 558 minecraft:calcite
fill 77 28 590 78 31 590 minecraft:deepslate
setblock 78 28 558 minecraft:cobbled_deepslate
fill 79 28 591 79 31 591 minecraft:deepslate
fill 79 28 593 79 31 593 minecraft:deepslate
fill 86 28 568 87 28 570 minecraft:light_blue_stained_glass
setblock 87 28 558 minecraft:calcite
fill 87 28 586 87 28 587 minecraft:cobbled_deepslate
setblock 87 28 588 minecraft:calcite
fill 87 28 589 87 29 591 minecraft:cobbled_deepslate
setblock 87 28 598 minecraft:calcite
fill 88 28 558 88 31 558 minecraft:cobbled_deepslate
setblock 88 28 562 minecraft:calcite
fill 88 28 563 88 31 563 minecraft:cobbled_deepslate
setblock 88 28 567 minecraft:calcite
fill 88 28 568 88 31 568 minecraft:cobbled_deepslate
fill 88 28 569 88 28 570 minecraft:light_blue_stained_glass
setblock 88 28 582 minecraft:calcite
fill 88 28 583 88 31 583 minecraft:cobbled_deepslate
setblock 88 28 587 minecraft:calcite
fill 88 28 588 88 31 588 minecraft:cobbled_deepslate
setblock 88 28 591 minecraft:cobbled_deepslate
setblock 88 28 592 minecraft:calcite
fill 88 28 593 88 31 593 minecraft:cobbled_deepslate
setblock 88 28 597 minecraft:calcite
fill 88 28 598 88 31 598 minecraft:cobbled_deepslate
fill 48 29 562 48 32 562 minecraft:cobbled_deepslate
setblock 48 29 565 minecraft:cobbled_deepslate
setblock 48 29 566 minecraft:calcite
fill 48 29 567 49 31 567 minecraft:cobbled_deepslate
setblock 48 29 570 minecraft:cobbled_deepslate
fill 48 29 571 48 29 572 minecraft:calcite
setblock 48 29 581 minecraft:calcite
fill 48 29 582 48 32 582 minecraft:cobbled_deepslate
setblock 48 29 586 minecraft:calcite
fill 48 29 587 48 32 587 minecraft:cobbled_deepslate
setblock 48 29 591 minecraft:calcite
fill 48 29 592 48 32 592 minecraft:cobbled_deepslate
setblock 48 29 596 minecraft:calcite
fill 48 29 597 48 31 598 minecraft:cobbled_deepslate
setblock 49 29 565 minecraft:calcite
fill 49 29 566 49 32 566 minecraft:cobbled_deepslate
setblock 49 29 571 minecraft:calcite
fill 49 29 573 49 31 573 minecraft:calcite
setblock 49 29 580 minecraft:calcite
fill 49 29 581 49 32 581 minecraft:cobbled_deepslate
setblock 49 29 585 minecraft:calcite
fill 49 29 586 49 32 586 minecraft:cobbled_deepslate
setblock 49 29 590 minecraft:calcite
fill 49 29 591 49 32 591 minecraft:cobbled_deepslate
setblock 49 29 595 minecraft:calcite
fill 50 29 572 50 31 572 minecraft:calcite
setblock 50 29 584 minecraft:calcite
fill 50 29 585 50 32 585 minecraft:cobbled_deepslate
setblock 50 29 588 minecraft:cobbled_deepslate
setblock 50 29 589 minecraft:calcite
fill 50 29 590 50 32 590 minecraft:cobbled_deepslate
fill 50 29 592 50 30 592 minecraft:cobbled_deepslate
setblock 51 29 588 minecraft:calcite
fill 51 29 589 51 32 589 minecraft:cobbled_deepslate
setblock 51 29 598 minecraft:calcite
fill 55 29 597 55 30 597 minecraft:light_blue_stained_glass
fill 56 29 595 56 31 595 minecraft:light_blue_stained_glass
fill 57 29 594 57 31 594 minecraft:light_blue_stained_glass
fill 58 29 593 58 31 593 minecraft:light_blue_stained_glass
fill 59 29 594 59 31 594 minecraft:light_blue_stained_glass
fill 60 29 595 60 31 595 minecraft:light_blue_stained_glass
fill 61 29 597 61 30 597 minecraft:light_blue_stained_glass
setblock 69 29 559 minecraft:cobbled_deepslate
setblock 70 29 559 minecraft:calcite
setblock 71 29 558 minecraft:calcite
fill 71 29 559 71 32 559 minecraft:cobbled_deepslate
fill 72 29 558 72 32 558 minecraft:cobbled_deepslate
setblock 75 29 559 minecraft:calcite
setblock 76 29 558 minecraft:calcite
fill 76 29 590 76 31 590 minecraft:deepslate
fill 77 29 558 77 32 558 minecraft:cobbled_deepslate
fill 77 29 594 79 31 594 minecraft:deepslate
fill 79 29 590 79 31 590 minecraft:deepslate
fill 80 29 591 80 31 592 minecraft:deepslate
fill 87 29 558 87 32 558 minecraft:cobbled_deepslate
fill 87 29 584 87 30 584 minecraft:calcite
fill 87 29 585 87 29 586 minecraft:cobbled_deepslate
setblock 87 29 587 minecraft:calcite
fill 87 29 588 87 32 588 minecraft:cobbled_deepslate
setblock 87 29 592 minecraft:calcite
fill 87 29 593 87 32 593 minecraft:cobbled_deepslate
fill 87 29 598 87 32 598 minecraft:cobbled_deepslate
setblock 88 29 561 minecraft:calcite
fill 88 29 562 88 32 562 minecraft:cobbled_deepslate
setblock 88 29 566 minecraft:calcite
fill 88 29 567 88 32 567 minecraft:cobbled_deepslate
fill 88 29 569 88 30 569 minecraft:cobbled_deepslate
fill 88 29 582 88 32 582 minecraft:cobbled_deepslate
setblock 88 29 586 minecraft:calcite
fill 88 29 587 88 32 587 minecraft:cobbled_deepslate
setblock 88 29 591 minecraft:calcite
fill 88 29 592 88 32 592 minecraft:cobbled_deepslate
setblock 88 29 596 minecraft:calcite
fill 88 29 597 88 32 597 minecraft:cobbled_deepslate
fill 48 30 561 48 33 561 minecraft:cobbled_deepslate
setblock 48 30 565 minecraft:calcite
fill 48 30 566 48 33 566 minecraft:cobbled_deepslate
setblock 48 30 570 minecraft:calcite
fill 48 30 571 48 30 574 minecraft:cobbled_deepslate
setblock 48 30 575 minecraft:calcite
fill 48 30 576 48 31 578 minecraft:cobbled_deepslate
setblock 48 30 580 minecraft:calcite
fill 48 30 581 48 33 581 minecraft:cobbled_deepslate
setblock 48 30 585 minecraft:calcite
fill 48 30 586 48 33 586 minecraft:cobbled_deepslate
setblock 48 30 590 minecraft:calcite
fill 48 30 591 48 33 591 minecraft:cobbled_deepslate
setblock 48 30 595 minecraft:calcite
fill 48 30 596 48 33 596 minecraft:cobbled_deepslate
setblock 49 30 564 minecraft:calcite
fill 49 30 565 49 33 565 minecraft:cobbled_deepslate
setblock 49 30 568 minecraft:cobbled_deepslate
setblock 49 30 569 minecraft:calcite
fill 49 30 570 49 32 571 minecraft:cobbled_deepslate
fill 49 30 580 49 33 580 minecraft:cobbled_deepslate
setblock 49 30 584 minecraft:calcite
fill 49 30 585 49 33 585 minecraft:cobbled_deepslate
setblock 49 30 589 minecraft:calcite
fill 49 30 590 49 33 590 minecraft:cobbled_deepslate
setblock 49 30 594 minecraft:calcite
fill 49 30 595 49 33 595 minecraft:cobbled_deepslate
setblock 50 30 583 minecraft:calcite
fill 50 30 584 50 33 584 minecraft:cobbled_deepslate
setblock 50 30 588 minecraft:calcite
fill 50 30 589 50 33 589 minecraft:cobbled_deepslate
setblock 50 30 593 minecraft:calcite
setblock 50 30 598 minecraft:calcite
setblock 51 30 587 minecraft:calcite
fill 51 30 588 51 33 588 minecraft:cobbled_deepslate
fill 51 30 590 51 31 590 minecraft:cobbled_deepslate
fill 51 30 598 51 33 598 minecraft:cobbled_deepslate
setblock 57 30 593 minecraft:light_blue_stained_glass
setblock 58 30 592 minecraft:light_blue_stained_glass
setblock 59 30 593 minecraft:light_blue_stained_glass
fill 67 30 558 67 32 558 minecraft:cobbled_deepslate
setblock 69 30 559 minecraft:calcite
setblock 70 30 558 minecraft:calcite
fill 70 30 559 70 33 559 minecraft:cobbled_deepslate
fill 71 30 558 71 33 558 minecraft:cobbled_deepslate
setblock 74 30 559 minecraft:calcite
setblock 75 30 558 minecraft:calcite
fill 75 30 591 75 31 593 minecraft:deepslate
fill 76 30 558 76 33 558 minecraft:cobbled_deepslate
fill 76 30 594 76 31 594 minecraft:deepslate
fill 77 30 589 78 31 589 minecraft:deepslate
fill 80 30 593 80 31 593 minecraft:deepslate
setblock 85 30 598 minecraft:calcite
fill 86 30 598 86 33 598 minecraft:cobbled_deepslate
fill 87 30 564 87 30 565 minecraft:cobbled_deepslate
setblock 87 30 566 minecraft:calcite
setblock 87 30 585 minecraft:cobbled_deepslate
setblock 87 30 586 minecraft:calcite
fill 87 30 587 87 33 587 minecraft:cobbled_deepslate
fill 87 30 589 87 30 590 minecraft:cobbled_deepslate
setblock 87 30 591 minecraft:calcite
fill 87 30 592 87 33 592 minecraft:cobbled_deepslate
fill 87 30 594 87 30 595 minecraft:cobbled_deepslate
setblock 87 30 596 minecraft:calcite
setblock 88 30 560 minecraft:calcite
fill 88 30 561 88 33 561 minecraft:cobbled_deepslate
setblock 88 30 565 minecraft:calcite
fill 88 30 566 88 33 566 minecraft:cobbled_deepslate
setblock 88 30 570 minecraft:calcite
fill 88 30 571 88 33 571 minecraft:cobbled_deepslate
setblock 88 30 585 minecraft:calcite
fill 88 30 586 88 33 586 minecraft:cobbled_deepslate
setblock 88 30 590 minecraft:calcite
fill 88 30 591 88 33 591 minecraft:cobbled_deepslate
setblock 88 30 595 minecraft:calcite
fill 88 30 596 88 33 596 minecraft:cobbled_deepslate
setblock 48 31 564 minecraft:calcite
fill 48 31 565 48 34 565 minecraft:cobbled_deepslate
setblock 48 31 568 minecraft:cobbled_deepslate
setblock 48 31 569 minecraft:calcite
fill 48 31 570 48 31 573 minecraft:cobbled_deepslate
setblock 48 31 574 minecraft:calcite
fill 48 31 575 48 34 575 minecraft:cobbled_deepslate
setblock 48 31 579 minecraft:calcite
fill 48 31 580 48 34 580 minecraft:cobbled_deepslate
setblock 48 31 584 minecraft:calcite
fill 48 31 585 48 34 585 minecraft:cobbled_deepslate
setblock 48 31 589 minecraft:calcite
fill 48 31 590 48 34 590 minecraft:cobbled_deepslate
setblock 48 31 594 minecraft:calcite
fill 48 31 595 48 34 595 minecraft:cobbled_deepslate
fill 49 31 564 49 34 564 minecraft:cobbled_deepslate
setblock 49 31 568 minecraft:calcite
fill 49 31 569 50 33 569 minecraft:cobbled_deepslate
setblock 49 31 572 minecraft:cobbled_deepslate
fill 49 31 574 49 34 574 minecraft:cobbled_deepslate
fill 49 31 579 49 34 579 minecraft:cobbled_deepslate
setblock 49 31 583 minecraft:calcite
fill 49 31 584 49 34 584 minecraft:cobbled_deepslate
setblock 49 31 588 minecraft:calcite
fill 49 31 589 49 34 589 minecraft:cobbled_deepslate
setblock 49 31 593 minecraft:calcite
fill 49 31 594 50 33 594 minecraft:cobbled_deepslate
fill 49 31 596 49 32 596 minecraft:cobbled_deepslate
setblock 49 31 598 minecraft:calcite
fill 50 31 571 50 32 571 minecraft:calcite
setblock 50 31 573 minecraft:calcite
setblock 50 31 582 minecraft:calcite
fill 50 31 583 50 34 583 minecraft:cobbled_deepslate
setblock 50 31 587 minecraft:calcite
fill 50 31 588 50 34 588 minecraft:cobbled_deepslate
setblock 50 31 592 minecraft:calcite
fill 50 31 593 50 34 593 minecraft:cobbled_deepslate
fill 50 31 598 50 34 598 minecraft:cobbled_deepslate
setblock 51 31 586 minecraft:calcite
fill 51 31 587 51 34 587 minecraft:cobbled_deepslate
setblock 51 31 591 minecraft:calcite
fill 52 31 598 52 32 598 minecraft:cobbled_deepslate
setblock 68 31 559 minecraft:calcite
setblock 69 31 558 minecraft:calcite
fill 69 31 559 69 34 559 minecraft:cobbled_deepslate
fill 70 31 558 70 34 558 minecraft:cobbled_deepslate
fill 70 31 598 73 31 598 minecraft:cobbled_deepslate
setblock 73 31 559 minecraft:calcite
setblock 74 31 558 minecraft:calcite
fill 74 31 559 74 33 559 minecraft:cobbled_deepslate
setblock 74 31 598 minecraft:calcite
fill 75 31 558 75 34 558 minecraft:cobbled_deepslate
setblock 75 31 590 minecraft:deepslate
setblock 75 31 594 minecraft:deepslate
setblock 76 31 589 minecraft:deepslate
fill 77 31 595 79 31 595 minecraft:deepslate
setblock 79 31 589 minecraft:deepslate
setblock 80 31 590 minecraft:deepslate
setblock 80 31 594 minecraft:deepslate
setblock 81 31 592 minecraft:deepslate
fill 82 31 561 82 40 561 minecraft:deepslate
setblock 84 31 598 minecraft:calcite
fill 85 31 598 85 34 598 minecraft:cobbled_deepslate
fill 86 31 558 86 33 558 minecraft:cobbled_deepslate
fill 86 31 588 86 31 590 minecraft:cobbled_deepslate
setblock 86 31 591 minecraft:calcite
fill 86 31 592 86 33 593 minecraft:cobbled_deepslate
fill 86 31 597 87 33 597 minecraft:cobbled_deepslate
fill 87 31 563 87 31 564 minecraft:cobbled_deepslate
setblock 87 31 565 minecraft:calcite
fill 87 31 566 87 32 568 minecraft:cobbled_deepslate
setblock 87 31 584 minecraft:cobbled_deepslate
setblock 87 31 585 minecraft:calcite
fill 87 31 586 87 34 586 minecraft:cobbled_deepslate
setblock 87 31 589 minecraft:cobbled_deepslate
setblock 87 31 590 minecraft:calcite
fill 87 31 591 87 34 591 minecraft:cobbled_deepslate
setblock 87 31 594 minecraft:cobbled_deepslate
setblock 87 31 595 minecraft:calcite
fill 87 31 596 87 34 596 minecraft:cobbled_deepslate
setblock 88 31 559 minecraft:calcite
fill 88 31 560 88 34 560 minecraft:cobbled_deepslate
setblock 88 31 564 minecraft:calcite
fill 88 31 565 88 34 565 minecraft:cobbled_deepslate
setblock 88 31 569 minecraft:calcite
fill 88 31 570 88 34 570 minecraft:cobbled_deepslate
fill 88 31 572 88 31 573 minecraft:cobbled_deepslate
fill 88 31 581 88 33 581 minecraft:cobbled_deepslate
setblock 88 31 584 minecraft:calcite
fill 88 31 585 88 34 585 minecraft:cobbled_deepslate
setblock 88 31 589 minecraft:calcite
fill 88 31 590 88 34 590 minecraft:cobbled_deepslate
setblock 88 31 594 minecraft:calcite
fill 88 31 595 88 34 595 minecraft:cobbled_deepslate
setblock 48 32 563 minecraft:calcite
fill 48 32 564 48 35 564 minecraft:cobbled_deepslate
setblock 48 32 567 minecraft:cobbled_deepslate
setblock 48 32 568 minecraft:calcite
fill 48 32 569 48 32 572 minecraft:cobbled_deepslate
setblock 48 32 573 minecraft:calcite
fill 48 32 574 48 35 574 minecraft:cobbled_deepslate
fill 48 32 576 48 32 577 minecraft:cobbled_deepslate
setblock 48 32 578 minecraft:calcite
fill 48 32 579 48 35 579 minecraft:cobbled_deepslate
setblock 48 32 583 minecraft:calcite
fill 48 32 584 48 35 584 minecraft:cobbled_deepslate
setblock 48 32 588 minecraft:calcite
fill 48 32 589 48 35 589 minecraft:cobbled_deepslate
setblock 48 32 593 minecraft:calcite
fill 48 32 594 48 35 594 minecraft:cobbled_deepslate
setblock 48 32 597 minecraft:cobbled_deepslate
setblock 48 32 598 minecraft:calcite
setblock 49 32 567 minecraft:calcite
fill 49 32 568 50 34 568 minecraft:cobbled_deepslate
setblock 49 32 572 minecraft:calcite
fill 49 32 573 50 34 573 minecraft:cobbled_deepslate
fill 49 32 575 49 32 576 minecraft:cobbled_deepslate
setblock 49 32 577 minecraft:calcite
fill 49 32 578 49 35 578 minecraft:cobbled_deepslate
setblock 49 32 582 minecraft:calcite
fill 49 32 583 49 35 583 minecraft:cobbled_deepslate
setblock 49 32 587 minecraft:calcite
fill 49 32 588 49 35 588 minecraft:cobbled_deepslate
setblock 49 32 592 minecraft:calcite
fill 49 32 593 49 35 593 minecraft:cobbled_deepslate
setblock 49 32 597 minecraft:calcite
fill 49 32 598 49 35 598 minecraft:cobbled_deepslate
setblock 50 32 560 minecraft:light[level=14]
fill 50 32 567 50 35 567 minecraft:cobbled_deepslate
setblock 50 32 570 minecraft:cobbled_deepslate
fill 50 32 572 50 35 572 minecraft:cobbled_deepslate
setblock 50 32 576 minecraft:light[level=14]
fill 50 32 582 50 35 582 minecraft:cobbled_deepslate
setblock 50 32 586 minecraft:calcite
fill 50 32 587 50 35 587 minecraft:cobbled_deepslate
setblock 50 32 591 minecraft:calcite
fill 50 32 592 51 34 592 minecraft:cobbled_deepslate
setblock 50 32 595 minecraft:cobbled_deepslate
fill 50 32 597 50 35 597 minecraft:cobbled_deepslate
setblock 51 32 585 minecraft:calcite
fill 51 32 586 51 33 586 minecraft:cobbled_deepslate
setblock 51 32 590 minecraft:calcite
fill 51 32 591 51 35 591 minecraft:cobbled_deepslate
setblock 58 32 560 minecraft:light[level=14]
setblock 58 32 568 minecraft:light[level=14]
setblock 58 32 576 minecraft:light[level=14]
setblock 58 32 584 minecraft:light[level=14]
setblock 58 32 592 minecraft:light[level=14]
setblock 58 32 595 minecraft:light_blue_stained_glass
fill 66 32 558 66 33 558 minecraft:cobbled_deepslate
setblock 66 32 560 minecraft:light[level=14]
setblock 66 32 568 minecraft:light[level=14]
setblock 66 32 576 minecraft:light[level=14]
setblock 66 32 584 minecraft:light[level=14]
setblock 66 32 592 minecraft:light[level=14]
setblock 67 32 559 minecraft:calcite
setblock 68 32 558 minecraft:calcite
fill 68 32 559 68 35 559 minecraft:cobbled_deepslate
setblock 68 32 598 minecraft:calcite
fill 69 32 558 69 35 558 minecraft:cobbled_deepslate
fill 69 32 598 72 32 598 minecraft:cobbled_deepslate
setblock 70 32 560 minecraft:cobbled_deepslate
setblock 72 32 559 minecraft:calcite
setblock 73 32 558 minecraft:calcite
fill 73 32 559 73 35 559 minecraft:cobbled_deepslate
setblock 73 32 598 minecraft:calcite
fill 74 32 558 74 35 558 minecraft:cobbled_deepslate
setblock 74 32 560 minecraft:light[level=14]
setblock 74 32 568 minecraft:light[level=14]
setblock 74 32 576 minecraft:light[level=14]
setblock 74 32 584 minecraft:light[level=14]
setblock 74 32 592 minecraft:light[level=14]
fill 74 32 598 75 34 598 minecraft:cobbled_deepslate
fill 77 32 591 78 32 593 minecraft:light_blue_stained_glass
setblock 82 32 560 minecraft:light[level=14]
setblock 82 32 568 minecraft:light[level=14]
setblock 82 32 576 minecraft:light[level=14]
setblock 82 32 584 minecraft:light[level=14]
setblock 82 32 592 minecraft:light[level=14]
setblock 82 32 598 minecraft:cobbled_deepslate
setblock 83 32 598 minecraft:calcite
fill 84 32 558 85 34 558 minecraft:cobbled_deepslate
fill 84 32 598 84 35 598 minecraft:cobbled_deepslate
fill 85 32 597 85 35 597 minecraft:cobbled_deepslate
fill 86 32 587 86 32 589 minecraft:cobbled_deepslate
setblock 86 32 590 minecraft:calcite
fill 86 32 591 86 35 591 minecraft:cobbled_deepslate
setblock 86 32 594 minecraft:cobbled_deepslate
setblock 86 32 595 minecraft:calcite
setblock 87 32 563 minecraft:cobbled_deepslate
setblock 87 32 564 minecraft:calcite
fill 87 32 565 87 35 565 minecraft:cobbled_deepslate
setblock 87 32 569 minecraft:calcite
fill 87 32 570 87 34 571 minecraft:cobbled_deepslate
setblock 87 32 584 minecraft:calcite
fill 87 32 585 87 35 585 minecraft:cobbled_deepslate
setblock 87 32 589 minecraft:calcite
fill 87 32 590 87 35 590 minecraft:cobbled_deepslate
setblock 87 32 594 minecraft:calcite
fill 87 32 595 87 35 595 minecraft:cobbled_deepslate
setblock 88 32 558 minecraft:calcite
fill 88 32 559 88 35 559 minecraft:cobbled_deepslate
setblock 88 32 563 minecraft:calcite
fill 88 32 564 88 35 564 minecraft:cobbled_deepslate
setblock 88 32 568 minecraft:calcite
fill 88 32 569 88 35 569 minecraft:cobbled_deepslate
setblock 88 32 572 minecraft:cobbled_deepslate
setblock 88 32 573 minecraft:calcite
fill 88 32 574 88 33 576 minecraft:cobbled_deepslate
fill 88 32 579 88 34 580 minecraft:cobbled_deepslate
setblock 88 32 583 minecraft:calcite
fill 88 32 584 88 35 584 minecraft:cobbled_deepslate
setblock 88 32 588 minecraft:calcite
fill 88 32 589 88 35 589 minecraft:cobbled_deepslate
setblock 88 32 593 minecraft:calcite
fill 88 32 594 88 35 594 minecraft:cobbled_deepslate
setblock 88 32 598 minecraft:calcite
fill 48 33 560 48 34 560 minecraft:cobbled_deepslate
setblock 48 33 562 minecraft:calcite
fill 48 33 563 48 36 563 minecraft:cobbled_deepslate
setblock 48 33 567 minecraft:calcite
fill 48 33 568 48 33 571 minecraft:cobbled_deepslate
setblock 48 33 572 minecraft:calcite
fill 48 33 573 48 36 573 minecraft:cobbled_deepslate
setblock 48 33 576 minecraft:cobbled_deepslate
setblock 48 33 577 minecraft:calcite
fill 48 33 578 48 36 578 minecraft:cobbled_deepslate
setblock 48 33 582 minecraft:calcite
fill 48 33 583 48 36 583 minecraft:cobbled_deepslate
setblock 48 33 587 minecraft:calcite
fill 48 33 588 48 36 588 minecraft:cobbled_deepslate
setblock 48 33 592 minecraft:calcite
fill 48 33 593 48 36 593 minecraft:cobbled_deepslate
setblock 48 33 597 minecraft:calcite
fill 48 33 598 48 36 598 minecraft:cobbled_deepslate
setblock 49 33 566 minecraft:calcite
fill 49 33 567 49 36 567 minecraft:cobbled_deepslate
setblock 49 33 570 minecraft:cobbled_deepslate
setblock 49 33 571 minecraft:calcite
fill 49 33 572 49 36 572 minecraft:cobbled_deepslate
setblock 49 33 575 minecraft:cobbled_deepslate
setblock 49 33 576 minecraft:calcite
fill 49 33 577 49 36 577 minecraft:cobbled_deepslate
setblock 49 33 581 minecraft:calcite
fill 49 33 582 49 36 582 minecraft:cobbled_deepslate
setblock 49 33 586 minecraft:calcite
fill 49 33 587 49 36 587 minecraft:cobbled_deepslate
setblock 49 33 591 minecraft:calcite
fill 49 33 592 49 36 592 minecraft:cobbled_deepslate
setblock 49 33 596 minecraft:calcite
fill 49 33 597 49 36 597 minecraft:cobbled_deepslate
setblock 50 33 566 minecraft:cobbled_deepslate
setblock 50 33 570 minecraft:calcite
fill 50 33 571 50 36 571 minecraft:cobbled_deepslate
setblock 50 33 574 minecraft:cobbled_deepslate
setblock 50 33 575 minecraft:calcite
fill 50 33 581 50 34 581 minecraft:cobbled_deepslate
setblock 50 33 585 minecraft:calcite
fill 50 33 586 50 36 586 minecraft:cobbled_deepslate
setblock 50 33 590 minecraft:calcite
fill 50 33 591 50 36 591 minecraft:cobbled_deepslate
setblock 50 33 595 minecraft:calcite
setblock 51 33 589 minecraft:calcite
fill 51 33 590 51 35 590 minecraft:cobbled_deepslate
fill 51 33 597 51 34 597 minecraft:cobbled_deepslate
setblock 52 33 598 minecraft:calcite
fill 65 33 558 65 34 558 minecraft:cobbled_deepslate
setblock 66 33 559 minecraft:calcite
setblock 66 33 598 minecraft:cobbled_deepslate
setblock 67 33 558 minecraft:calcite
fill 67 33 559 67 36 559 minecraft:cobbled_deepslate
setblock 67 33 598 minecraft:calcite
fill 68 33 558 68 36 558 minecraft:cobbled_deepslate
fill 68 33 598 71 33 598 minecraft:cobbled_deepslate
setblock 69 33 560 minecraft:cobbled_deepslate
fill 69 33 597 72 33 597 minecraft:cobbled_deepslate
setblock 70 33 560 minecraft:calcite
setblock 71 33 559 minecraft:calcite
setblock 72 33 558 minecraft:calcite
fill 72 33 559 72 36 559 minecraft:cobbled_deepslate
setblock 72 33 598 minecraft:calcite
fill 73 33 558 73 36 558 minecraft:cobbled_deepslate
fill 73 33 598 73 36 598 minecraft:cobbled_deepslate
setblock 76 33 598 minecraft:cobbled_deepslate
setblock 77 33 558 minecraft:calcite
fill 77 33 592 78 34 592 minecraft:light_blue_stained_glass
setblock 77 33 598 minecraft:calcite
setblock 78 33 591 minecraft:light_blue_stained_glass
fill 78 33 598 81 33 598 minecraft:cobbled_deepslate
setblock 82 33 598 minecraft:calcite
fill 83 33 558 83 36 558 minecraft:cobbled_deepslate
setblock 83 33 597 minecraft:calcite
fill 83 33 598 83 36 598 minecraft:cobbled_deepslate
fill 84 33 583 85 48 586 minecraft:calcite
fill 84 33 597 84 36 597 minecraft:cobbled_deepslate
fill 85 33 591 85 35 592 minecraft:cobbled_deepslate
fill 85 33 596 86 35 596 minecraft:cobbled_deepslate
fill 86 33 583 86 45 585 minecraft:calcite
fill 86 33 586 86 33 588 minecraft:cobbled_deepslate
setblock 86 33 589 minecraft:calcite
fill 86 33 590 86 36 590 minecraft:cobbled_deepslate
setblock 86 33 594 minecraft:calcite
fill 86 33 595 86 36 595 minecraft:cobbled_deepslate
setblock 87 33 558 minecraft:calcite
setblock 87 33 563 minecraft:calcite
fill 87 33 564 87 35 564 minecraft:cobbled_deepslate
fill 87 33 566 87 33 567 minecraft:cobbled_deepslate
setblock 87 33 568 minecraft:calcite
fill 87 33 569 87 36 569 minecraft:cobbled_deepslate
setblock 87 33 572 minecraft:cobbled_deepslate
setblock 87 33 573 minecraft:calcite
setblock 87 33 583 minecraft:calcite
fill 87 33 584 87 36 584 minecraft:cobbled_deepslate
setblock 87 33 588 minecraft:calcite
fill 87 33 589 87 36 589 minecraft:cobbled_deepslate
setblock 87 33 593 minecraft:calcite
fill 87 33 594 87 36 594 minecraft:cobbled_deepslate
setblock 87 33 598 minecraft:calcite
fill 88 33 558 88 36 558 minecraft:cobbled_deepslate
setblock 88 33 562 minecraft:calcite
fill 88 33 563 88 36 563 minecraft:cobbled_deepslate
setblock 88 33 567 minecraft:calcite
fill 88 33 568 88 36 568 minecraft:cobbled_deepslate
setblock 88 33 572 minecraft:calcite
fill 88 33 573 88 36 573 minecraft:cobbled_deepslate
setblock 88 33 577 minecraft:calcite
fill 88 33 578 88 36 578 minecraft:cobbled_deepslate
setblock 88 33 582 minecraft:calcite
fill 88 33 583 88 36 583 minecraft:cobbled_deepslate
setblock 88 33 587 minecraft:calcite
fill 88 33 588 88 36 588 minecraft:cobbled_deepslate
setblock 88 33 592 minecraft:calcite
fill 88 33 593 88 36 593 minecraft:cobbled_deepslate
setblock 88 33 597 minecraft:calcite
fill 88 33 598 88 36 598 minecraft:cobbled_deepslate
fill 48 34 558 48 35 559 minecraft:cobbled_deepslate
setblock 48 34 561 minecraft:calcite
fill 48 34 562 48 36 562 minecraft:cobbled_deepslate
setblock 48 34 566 minecraft:calcite
fill 48 34 567 48 34 570 minecraft:cobbled_deepslate
setblock 48 34 571 minecraft:calcite
fill 48 34 572 48 37 572 minecraft:cobbled_deepslate
setblock 48 34 576 minecraft:calcite
fill 48 34 577 48 37 577 minecraft:cobbled_deepslate
setblock 48 34 581 minecraft:calcite
fill 48 34 582 48 37 582 minecraft:cobbled_deepslate
setblock 48 34 586 minecraft:calcite
fill 48 34 587 48 37 587 minecraft:cobbled_deepslate
setblock 48 34 591 minecraft:calcite
fill 48 34 592 48 37 592 minecraft:cobbled_deepslate
setblock 48 34 596 minecraft:calcite
fill 48 34 597 48 37 597 minecraft:cobbled_deepslate
fill 49 34 558 49 35 558 minecraft:cobbled_deepslate
setblock 49 34 565 minecraft:calcite
fill 49 34 566 49 37 566 minecraft:cobbled_deepslate
setblock 49 34 569 minecraft:cobbled_deepslate
setblock 49 34 570 minecraft:calcite
fill 49 34 571 49 37 571 minecraft:cobbled_deepslate
setblock 49 34 575 minecraft:calcite
fill 49 34 576 50 36 576 minecraft:cobbled_deepslate
setblock 49 34 580 minecraft:calcite
fill 49 34 581 49 37 581 minecraft:cobbled_deepslate
setblock 49 34 585 minecraft:calcite
fill 49 34 586 49 37 586 minecraft:cobbled_deepslate
setblock 49 34 590 minecraft:calcite
fill 49 34 591 49 37 591 minecraft:cobbled_deepslate
setblock 49 34 594 minecraft:cobbled_deepslate
setblock 49 34 595 minecraft:calcite
fill 49 34 596 50 36 596 minecraft:cobbled_deepslate
setblock 50 34 569 minecraft:calcite
fill 50 34 570 50 37 570 minecraft:cobbled_deepslate
setblock 50 34 574 minecraft:calcite
fill 50 34 575 50 37 575 minecraft:cobbled_deepslate
fill 50 34 577 50 34 578 minecraft:cobbled_deepslate
setblock 50 34 584 minecraft:calcite
fill 50 34 585 50 36 585 minecraft:cobbled_deepslate
setblock 50 34 589 minecraft:calcite
fill 50 34 590 50 37 590 minecraft:cobbled_deepslate
setblock 50 34 594 minecraft:calcite
fill 50 34 595 50 37 595 minecraft:cobbled_deepslate
setblock 51 34 588 minecraft:calcite
fill 51 34 589 51 35 589 minecraft:cobbled_deepslate
setblock 51 34 598 minecraft:calcite
fill 52 34 598 52 37 598 minecraft:cobbled_deepslate
fill 64 34 558 64 35 558 minecraft:cobbled_deepslate
setblock 65 34 598 minecraft:cobbled_deepslate
setblock 66 34 558 minecraft:calcite
fill 66 34 559 66 37 559 minecraft:cobbled_deepslate
setblock 66 34 598 minecraft:calcite
fill 67 34 558 67 37 558 minecraft:cobbled_deepslate
setblock 67 34 597 minecraft:calcite
fill 67 34 598 70 34 598 minecraft:cobbled_deepslate
setblock 68 34 560 minecraft:cobbled_deepslate
fill 68 34 597 71 34 597 minecraft:cobbled_deepslate
setblock 69 34 560 minecraft:calcite
setblock 70 34 559 minecraft:calcite
fill 70 34 560 70 35 560 minecraft:cobbled_deepslate
setblock 71 34 558 minecraft:calcite
fill 71 34 559 71 37 559 minecraft:cobbled_deepslate
setblock 71 34 598 minecraft:calcite
fill 72 34 558 72 37 558 minecraft:cobbled_deepslate
setblock 72 34 597 minecraft:calcite
fill 72 34 598 72 37 598 minecraft:cobbled_deepslate
fill 73 34 597 74 36 597 minecraft:cobbled_deepslate
setblock 76 34 558 minecraft:calcite
setblock 76 34 598 minecraft:calcite
fill 77 34 558 77 37 558 minecraft:cobbled_deepslate
fill 77 34 598 80 34 598 minecraft:cobbled_deepslate
setblock 81 34 597 minecraft:cobbled_deepslate
setblock 81 34 598 minecraft:calcite
fill 82 34 558 82 37 558 minecraft:cobbled_deepslate
setblock 82 34 597 minecraft:calcite
fill 82 34 598 82 37 598 minecraft:cobbled_deepslate
setblock 83 34 596 minecraft:calcite
fill 83 34 597 83 37 597 minecraft:cobbled_deepslate
fill 84 34 596 84 37 596 minecraft:cobbled_deepslate
setblock 85 34 589 minecraft:calcite
fill 85 34 590 85 37 590 minecraft:cobbled_deepslate
setblock 85 34 593 minecraft:cobbled_deepslate
setblock 85 34 594 minecraft:calcite
fill 85 34 595 85 37 595 minecraft:cobbled_deepslate
setblock 86 34 558 minecraft:calcite
fill 86 34 586 86 34 587 minecraft:cobbled_deepslate
setblock 86 34 588 minecraft:calcite
fill 86 34 589 86 37 589 minecraft:cobbled_deepslate
setblock 86 34 592 minecraft:cobbled_deepslate
setblock 86 34 593 minecraft:calcite
fill 86 34 594 86 37 594 minecraft:cobbled_deepslate
setblock 86 34 597 minecraft:cobbled_deepslate
setblock 86 34 598 minecraft:calcite
fill 87 34 558 87 37 558 minecraft:cobbled_deepslate
setblock 87 34 563 minecraft:cobbled_deepslate
setblock 87 34 566 minecraft:cobbled_deepslate
setblock 87 34 567 minecraft:calcite
fill 87 34 568 87 37 568 minecraft:cobbled_deepslate
setblock 87 34 572 minecraft:calcite
fill 87 34 573 87 35 575 minecraft:cobbled_deepslate
setblock 87 34 582 minecraft:calcite
fill 87 34 583 87 37 583 minecraft:cobbled_deepslate
setblock 87 34 587 minecraft:calcite
fill 87 34 588 87 37 588 minecraft:cobbled_deepslate
setblock 87 34 592 minecraft:calcite
fill 87 34 593 87 37 593 minecraft:cobbled_deepslate
setblock 87 34 597 minecraft:calcite
fill 87 34 598 87 37 598 minecraft:cobbled_deepslate
setblock 88 34 561 minecraft:calcite
fill 88 34 562 88 37 562 minecraft:cobbled_deepslate
setblock 88 34 566 minecraft:calcite
fill 88 34 567 88 37 567 minecraft:cobbled_deepslate
setblock 88 34 571 minecraft:calcite
fill 88 34 572 88 37 572 minecraft:cobbled_deepslate
fill 88 34 574 88 34 575 minecraft:cobbled_deepslate
setblock 88 34 576 minecraft:calcite
fill 88 34 577 88 37 577 minecraft:cobbled_deepslate
setblock 88 34 581 minecraft:calcite
fill 88 34 582 88 37 582 minecraft:cobbled_deepslate
setblock 88 34 586 minecraft:calcite
fill 88 34 587 88 37 587 minecraft:cobbled_deepslate
setblock 88 34 591 minecraft:calcite
fill 88 34 592 88 37 592 minecraft:cobbled_deepslate
setblock 88 34 596 minecraft:calcite
fill 88 34 597 88 37 597 minecraft:cobbled_deepslate
setblock 48 35 560 minecraft:calcite
fill 48 35 561 48 36 561 minecraft:cobbled_deepslate
setblock 48 35 565 minecraft:calcite
fill 48 35 566 48 35 569 minecraft:cobbled_deepslate
setblock 48 35 570 minecraft:calcite
fill 48 35 571 48 38 571 minecraft:cobbled_deepslate
setblock 48 35 575 minecraft:calcite
fill 48 35 576 48 38 576 minecraft:cobbled_deepslate
setblock 48 35 580 minecraft:calcite
fill 48 35 581 48 38 581 minecraft:cobbled_deepslate
setblock 48 35 585 minecraft:calcite
fill 48 35 586 48 38 586 minecraft:cobbled_deepslate
setblock 48 35 590 minecraft:calcite
fill 48 35 591 48 38 591 minecraft:cobbled_deepslate
setblock 48 35 595 minecraft:calcite
fill 48 35 596 48 38 596 minecraft:cobbled_deepslate
setblock 49 35 564 minecraft:calcite
fill 49 35 565 49 36 565 minecraft:cobbled_deepslate
setblock 49 35 568 minecraft:cobbled_deepslate
setblock 49 35 569 minecraft:calcite
fill 49 35 570 49 38 570 minecraft:cobbled_deepslate
setblock 49 35 573 minecraft:cobbled_deepslate
setblock 49 35 574 minecraft:calcite
fill 49 35 575 49 38 575 minecraft:cobbled_deepslate
setblock 49 35 579 minecraft:calcite
fill 49 35 580 49 38 580 minecraft:cobbled_deepslate
setblock 49 35 584 minecraft:calcite
fill 49 35 585 49 38 585 minecraft:cobbled_deepslate
setblock 49 35 589 minecraft:calcite
fill 49 35 590 49 38 590 minecraft:cobbled_deepslate
setblock 49 35 594 minecraft:calcite
fill 49 35 595 49 38 595 minecraft:cobbled_deepslate
setblock 50 35 568 minecraft:calcite
fill 50 35 569 50 37 569 minecraft:cobbled_deepslate
setblock 50 35 573 minecraft:calcite
fill 50 35 574 50 38 574 minecraft:cobbled_deepslate
setblock 50 35 577 minecraft:cobbled_deepslate
setblock 50 35 578 minecraft:calcite
fill 50 35 579 50 36 579 minecraft:cobbled_deepslate
setblock 50 35 583 minecraft:calcite
setblock 50 35 584 minecraft:cobbled_deepslate
setblock 50 35 588 minecraft:calcite
fill 50 35 589 50 37 589 minecraft:cobbled_deepslate
setblock 50 35 592 minecraft:cobbled_deepslate
setblock 50 35 593 minecraft:calcite
fill 50 35 594 50 38 594 minecraft:cobbled_deepslate
setblock 50 35 598 minecraft:calcite
setblock 51 35 571 minecraft:cobbled_deepslate
setblock 51 35 572 minecraft:calcite
setblock 51 35 592 minecraft:calcite
setblock 51 35 597 minecraft:calcite
fill 51 35 598 51 38 598 minecraft:cobbled_deepslate
fill 63 35 558 63 36 558 minecraft:cobbled_deepslate
fill 63 35 598 64 35 598 minecraft:cobbled_deepslate
setblock 65 35 558 minecraft:calcite
fill 65 35 559 65 38 559 minecraft:cobbled_deepslate
setblock 65 35 597 minecraft:cobbled_deepslate
setblock 65 35 598 minecraft:calcite
fill 66 35 558 66 38 558 minecraft:cobbled_deepslate
setblock 66 35 597 minecraft:calcite
fill 66 35 598 69 35 598 minecraft:cobbled_deepslate
fill 67 35 597 70 35 597 minecraft:cobbled_deepslate
setblock 68 35 560 minecraft:calcite
fill 68 35 596 70 36 596 minecraft:cobbled_deepslate
setblock 69 35 559 minecraft:calcite
fill 69 35 560 69 36 560 minecraft:cobbled_deepslate
setblock 70 35 558 minecraft:calcite
fill 70 35 559 70 38 559 minecraft:cobbled_deepslate
setblock 70 35 598 minecraft:calcite
fill 71 35 558 71 38 558 minecraft:cobbled_deepslate
setblock 71 35 597 minecraft:calcite
fill 71 35 598 71 38 598 minecraft:cobbled_deepslate
fill 72 35 597 72 38 597 minecraft:cobbled_deepslate
setblock 74 35 598 minecraft:cobbled_deepslate
setblock 75 35 558 minecraft:calcite
setblock 75 35 597 minecraft:cobbled_deepslate
setblock 75 35 598 minecraft:calcite
fill 76 35 558 76 38 558 minecraft:cobbled_deepslate
fill 76 35 598 79 35 598 minecraft:cobbled_deepslate
fill 78 35 558 78 36 558 minecraft:cobbled_deepslate
setblock 78 35 592 minecraft:light_blue_stained_glass
fill 79 35 597 80 35 597 minecraft:cobbled_deepslate
setblock 80 35 558 minecraft:calcite
setblock 80 35 598 minecraft:calcite
fill 81 35 558 81 38 558 minecraft:cobbled_deepslate
setblock 81 35 597 minecraft:calcite
fill 81 35 598 81 38 598 minecraft:cobbled_deepslate
setblock 82 35 596 minecraft:calcite
fill 82 35 597 82 38 597 minecraft:cobbled_deepslate
fill 83 35 596 83 38 596 minecraft:cobbled_deepslate
setblock 84 35 558 minecraft:cobbled_deepslate
fill 84 35 595 84 38 595 minecraft:cobbled_deepslate
setblock 85 35 558 minecraft:calcite
fill 85 35 589 85 37 589 minecraft:cobbled_deepslate
setblock 85 35 593 minecraft:calcite
fill 85 35 594 85 38 594 minecraft:cobbled_deepslate
setblock 85 35 598 minecraft:calcite
fill 86 35 558 86 38 558 minecraft:cobbled_deepslate
setblock 86 35 586 minecraft:cobbled_deepslate
setblock 86 35 587 minecraft:calcite
fill 86 35 588 86 38 588 minecraft:cobbled_deepslate
setblock 86 35 592 minecraft:calcite
fill 86 35 593 86 38 593 minecraft:cobbled_deepslate
setblock 86 35 597 minecraft:calcite
fill 86 35 598 86 38 598 minecraft:cobbled_deepslate
setblock 87 35 566 minecraft:calcite
fill 87 35 567 87 37 567 minecraft:cobbled_deepslate
setblock 87 35 570 minecraft:cobbled_deepslate
setblock 87 35 571 minecraft:calcite
fill 87 35 572 87 38 572 minecraft:cobbled_deepslate
setblock 87 35 576 minecraft:calcite
fill 87 35 577 87 38 577 minecraft:cobbled_deepslate
fill 87 35 582 87 38 582 minecraft:cobbled_deepslate
setblock 87 35 586 minecraft:calcite
fill 87 35 587 87 38 587 minecraft:cobbled_deepslate
setblock 87 35 591 minecraft:calcite
fill 87 35 592 87 38 592 minecraft:cobbled_deepslate
setblock 87 35 596 minecraft:calcite
fill 87 35 597 87 38 597 minecraft:cobbled_deepslate
setblock 88 35 560 minecraft:calcite
fill 88 35 561 88 37 561 minecraft:cobbled_deepslate
setblock 88 35 565 minecraft:calcite
fill 88 35 566 88 38 566 minecraft:cobbled_deepslate
setblock 88 35 570 minecraft:calcite
fill 88 35 571 88 38 571 minecraft:cobbled_deepslate
setblock 88 35 574 minecraft:cobbled_deepslate
setblock 88 35 575 minecraft:calcite
fill 88 35 576 88 38 576 minecraft:cobbled_deepslate
setblock 88 35 579 minecraft:cobbled_deepslate
setblock 88 35 580 minecraft:calcite
fill 88 35 581 88 38 581 minecraft:cobbled_deepslate
setblock 88 35 585 minecraft:calcite
fill 88 35 586 88 38 586 minecraft:cobbled_deepslate
setblock 88 35 590 minecraft:calcite
fill 88 35 591 88 38 591 minecraft:cobbled_deepslate
setblock 88 35 595 minecraft:calcite
fill 88 35 596 88 38 596 minecraft:cobbled_deepslate
setblock 48 36 558 minecraft:cobbled_deepslate
setblock 48 36 559 minecraft:calcite
setblock 48 36 564 minecraft:calcite
fill 48 36 565 48 36 568 minecraft:cobbled_deepslate
setblock 48 36 569 minecraft:calcite
fill 48 36 570 48 39 570 minecraft:cobbled_deepslate
setblock 48 36 574 minecraft:calcite
fill 48 36 575 48 39 575 minecraft:cobbled_deepslate
setblock 48 36 579 minecraft:calcite
fill 48 36 580 48 39 580 minecraft:cobbled_deepslate
setblock 48 36 584 minecraft:calcite
fill 48 36 585 48 39 585 minecraft:cobbled_deepslate
setblock 48 36 589 minecraft:calcite
fill 48 36 590 48 39 590 minecraft:cobbled_deepslate
setblock 48 36 594 minecraft:calcite
fill 48 36 595 48 39 595 minecraft:cobbled_deepslate
setblock 49 36 558 minecraft:calcite
setblock 49 36 568 minecraft:calcite
fill 49 36 569 49 39 569 minecraft:cobbled_deepslate
setblock 49 36 573 minecraft:calcite
fill 49 36 574 49 39 574 minecraft:cobbled_deepslate
setblock 49 36 578 minecraft:calcite
fill 49 36 579 49 39 579 minecraft:cobbled_deepslate
setblock 49 36 583 minecraft:calcite
fill 49 36 584 49 38 584 minecraft:cobbled_deepslate
setblock 49 36 588 minecraft:calcite
fill 49 36 589 49 39 589 minecraft:cobbled_deepslate
setblock 49 36 593 minecraft:calcite
fill 49 36 594 49 39 594 minecraft:cobbled_deepslate
setblock 49 36 598 minecraft:calcite
setblock 50 36 568 minecraft:cobbled_deepslate
setblock 50 36 572 minecraft:calcite
fill 50 36 573 50 39 573 minecraft:cobbled_deepslate
setblock 50 36 577 minecraft:calcite
fill 50 36 578 50 38 578 minecraft:cobbled_deepslate
setblock 50 36 587 minecraft:calcite
fill 50 36 588 50 37 588 minecraft:cobbled_deepslate
setblock 50 36 592 minecraft:calcite
fill 50 36 593 50 38 593 minecraft:cobbled_deepslate
setblock 50 36 597 minecraft:calcite
fill 50 36 598 50 39 598 minecraft:cobbled_deepslate
setblock 51 36 572 minecraft:cobbled_deepslate
fill 51 36 597 51 37 597 minecraft:cobbled_deepslate
fill 62 36 558 62 37 558 minecraft:cobbled_deepslate
fill 62 36 598 63 36 598 minecraft:cobbled_deepslate
setblock 64 36 558 minecraft:calcite
fill 64 36 559 64 39 559 minecraft:cobbled_deepslate
setblock 64 36 597 minecraft:cobbled_deepslate
setblock 64 36 598 minecraft:calcite
fill 65 36 558 65 39 558 minecraft:cobbled_deepslate
setblock 65 36 597 minecraft:calcite
fill 65 36 598 68 36 598 minecraft:cobbled_deepslate
fill 66 36 597 69 36 597 minecraft:cobbled_deepslate
fill 67 36 596 67 39 596 minecraft:cobbled_deepslate
setblock 68 36 559 minecraft:calcite
setblock 68 36 560 minecraft:cobbled_deepslate
setblock 69 36 558 minecraft:calcite
fill 69 36 559 69 39 559 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_2 1t
