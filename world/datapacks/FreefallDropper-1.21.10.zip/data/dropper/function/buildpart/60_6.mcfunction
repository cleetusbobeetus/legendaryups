fill 39 280 313 41 280 313 minecraft:blackstone
setblock 39 280 314 minecraft:cobbled_deepslate
fill 40 280 278 41 281 278 minecraft:blackstone
setblock 40 280 279 minecraft:cobbled_deepslate
fill 40 280 282 41 281 282 minecraft:blackstone
setblock 40 280 283 minecraft:cobbled_deepslate
fill 40 280 286 41 281 286 minecraft:blackstone
setblock 40 280 287 minecraft:cobbled_deepslate
fill 40 280 290 41 281 290 minecraft:blackstone
setblock 40 280 291 minecraft:cobbled_deepslate
fill 40 280 294 41 281 294 minecraft:blackstone
setblock 40 280 295 minecraft:cobbled_deepslate
fill 40 280 298 41 281 298 minecraft:blackstone
setblock 40 280 299 minecraft:cobbled_deepslate
fill 40 280 302 41 281 302 minecraft:blackstone
setblock 40 280 303 minecraft:cobbled_deepslate
fill 40 280 306 41 281 306 minecraft:blackstone
setblock 40 280 307 minecraft:cobbled_deepslate
fill 40 280 310 41 281 310 minecraft:blackstone
setblock 40 280 311 minecraft:cobbled_deepslate
fill 40 280 314 41 281 314 minecraft:blackstone
setblock 40 280 315 minecraft:cobbled_deepslate
setblock 41 280 276 minecraft:cobbled_deepslate
fill 41 280 279 41 282 279 minecraft:blackstone
setblock 41 280 280 minecraft:cobbled_deepslate
fill 41 280 283 41 282 283 minecraft:blackstone
setblock 41 280 284 minecraft:cobbled_deepslate
fill 41 280 287 41 282 287 minecraft:blackstone
setblock 41 280 288 minecraft:cobbled_deepslate
fill 41 280 291 41 282 291 minecraft:blackstone
setblock 41 280 292 minecraft:cobbled_deepslate
fill 41 280 295 41 282 295 minecraft:blackstone
setblock 41 280 296 minecraft:cobbled_deepslate
fill 41 280 299 41 282 299 minecraft:blackstone
setblock 41 280 300 minecraft:cobbled_deepslate
fill 41 280 303 41 282 303 minecraft:blackstone
setblock 41 280 304 minecraft:cobbled_deepslate
fill 41 280 307 41 282 307 minecraft:blackstone
setblock 41 280 308 minecraft:cobbled_deepslate
fill 41 280 311 41 282 311 minecraft:blackstone
setblock 41 280 312 minecraft:cobbled_deepslate
fill 41 280 315 41 282 315 minecraft:blackstone
setblock 41 280 316 minecraft:cobbled_deepslate
fill 0 281 296 0 285 296 minecraft:deepslate_tiles
fill 1 281 276 3 281 276 minecraft:blackstone
setblock 1 281 277 minecraft:cobbled_deepslate
fill 1 281 278 1 281 280 minecraft:blackstone
setblock 1 281 281 minecraft:cobbled_deepslate
fill 1 281 282 1 281 284 minecraft:blackstone
setblock 1 281 285 minecraft:cobbled_deepslate
fill 1 281 286 1 281 288 minecraft:blackstone
setblock 1 281 289 minecraft:cobbled_deepslate
fill 1 281 290 1 281 292 minecraft:blackstone
setblock 1 281 293 minecraft:cobbled_deepslate
fill 1 281 294 1 281 296 minecraft:blackstone
setblock 1 281 297 minecraft:cobbled_deepslate
fill 1 281 298 1 281 300 minecraft:blackstone
setblock 1 281 301 minecraft:cobbled_deepslate
fill 1 281 302 1 281 304 minecraft:blackstone
setblock 1 281 305 minecraft:cobbled_deepslate
fill 1 281 306 1 281 308 minecraft:blackstone
setblock 1 281 309 minecraft:cobbled_deepslate
fill 1 281 310 1 281 312 minecraft:blackstone
setblock 1 281 313 minecraft:cobbled_deepslate
fill 1 281 314 1 281 316 minecraft:blackstone
fill 2 281 277 4 281 277 minecraft:blackstone
setblock 2 281 278 minecraft:cobbled_deepslate
fill 2 281 279 2 281 281 minecraft:blackstone
setblock 2 281 282 minecraft:cobbled_deepslate
fill 2 281 283 2 281 285 minecraft:blackstone
setblock 2 281 286 minecraft:cobbled_deepslate
fill 2 281 287 2 281 289 minecraft:blackstone
setblock 2 281 290 minecraft:cobbled_deepslate
fill 2 281 291 2 281 293 minecraft:blackstone
setblock 2 281 294 minecraft:cobbled_deepslate
fill 2 281 295 2 281 297 minecraft:blackstone
setblock 2 281 298 minecraft:cobbled_deepslate
fill 2 281 299 2 281 301 minecraft:blackstone
setblock 2 281 302 minecraft:cobbled_deepslate
fill 2 281 303 2 281 305 minecraft:blackstone
setblock 2 281 306 minecraft:cobbled_deepslate
fill 2 281 307 2 281 309 minecraft:blackstone
setblock 2 281 310 minecraft:cobbled_deepslate
fill 2 281 311 2 281 313 minecraft:blackstone
setblock 2 281 314 minecraft:cobbled_deepslate
fill 2 281 315 2 281 316 minecraft:blackstone
fill 3 281 278 5 281 278 minecraft:blackstone
setblock 3 281 279 minecraft:cobbled_deepslate
fill 3 281 280 3 281 282 minecraft:blackstone
setblock 3 281 283 minecraft:cobbled_deepslate
fill 3 281 284 3 281 286 minecraft:blackstone
setblock 3 281 287 minecraft:cobbled_deepslate
fill 3 281 288 3 281 290 minecraft:blackstone
setblock 3 281 291 minecraft:cobbled_deepslate
fill 3 281 292 3 281 294 minecraft:blackstone
setblock 3 281 295 minecraft:cobbled_deepslate
fill 3 281 296 3 281 298 minecraft:blackstone
setblock 3 281 299 minecraft:cobbled_deepslate
fill 3 281 300 3 281 302 minecraft:blackstone
setblock 3 281 303 minecraft:cobbled_deepslate
fill 3 281 304 3 281 306 minecraft:blackstone
setblock 3 281 307 minecraft:cobbled_deepslate
fill 3 281 308 3 281 310 minecraft:blackstone
setblock 3 281 311 minecraft:cobbled_deepslate
fill 3 281 312 3 281 314 minecraft:blackstone
setblock 3 281 315 minecraft:cobbled_deepslate
setblock 3 281 316 minecraft:blackstone
setblock 4 281 276 minecraft:cobbled_deepslate
fill 4 281 279 6 281 279 minecraft:blackstone
setblock 4 281 280 minecraft:cobbled_deepslate
fill 4 281 281 4 281 283 minecraft:blackstone
setblock 4 281 284 minecraft:cobbled_deepslate
fill 4 281 285 4 281 287 minecraft:blackstone
setblock 4 281 288 minecraft:cobbled_deepslate
fill 4 281 289 4 281 291 minecraft:blackstone
setblock 4 281 292 minecraft:cobbled_deepslate
fill 4 281 293 4 281 295 minecraft:blackstone
setblock 4 281 296 minecraft:cobbled_deepslate
fill 4 281 297 4 281 299 minecraft:blackstone
setblock 4 281 300 minecraft:cobbled_deepslate
fill 4 281 301 4 281 303 minecraft:blackstone
setblock 4 281 304 minecraft:cobbled_deepslate
fill 4 281 305 4 281 307 minecraft:blackstone
setblock 4 281 308 minecraft:cobbled_deepslate
fill 4 281 309 4 281 311 minecraft:blackstone
setblock 4 281 312 minecraft:cobbled_deepslate
fill 4 281 313 4 281 315 minecraft:blackstone
setblock 4 281 316 minecraft:cobbled_deepslate
fill 5 281 276 7 281 276 minecraft:blackstone
setblock 5 281 277 minecraft:cobbled_deepslate
fill 5 281 280 7 281 280 minecraft:blackstone
setblock 5 281 281 minecraft:cobbled_deepslate
fill 5 281 282 5 281 284 minecraft:blackstone
setblock 5 281 285 minecraft:cobbled_deepslate
fill 5 281 286 5 281 288 minecraft:blackstone
setblock 5 281 289 minecraft:cobbled_deepslate
fill 5 281 290 5 281 292 minecraft:blackstone
setblock 5 281 293 minecraft:cobbled_deepslate
fill 5 281 294 5 281 296 minecraft:blackstone
setblock 5 281 297 minecraft:cobbled_deepslate
fill 5 281 298 5 281 300 minecraft:blackstone
setblock 5 281 301 minecraft:cobbled_deepslate
fill 5 281 302 5 281 304 minecraft:blackstone
setblock 5 281 305 minecraft:cobbled_deepslate
fill 5 281 306 5 281 308 minecraft:blackstone
setblock 5 281 309 minecraft:cobbled_deepslate
fill 5 281 310 5 281 312 minecraft:blackstone
setblock 5 281 313 minecraft:cobbled_deepslate
fill 5 281 314 5 281 316 minecraft:blackstone
fill 6 281 277 8 281 277 minecraft:blackstone
setblock 6 281 278 minecraft:cobbled_deepslate
fill 6 281 281 8 281 281 minecraft:blackstone
setblock 6 281 282 minecraft:cobbled_deepslate
fill 6 281 283 6 281 285 minecraft:blackstone
setblock 6 281 286 minecraft:cobbled_deepslate
fill 6 281 287 6 281 289 minecraft:blackstone
setblock 6 281 290 minecraft:cobbled_deepslate
fill 6 281 291 6 281 293 minecraft:blackstone
setblock 6 281 294 minecraft:cobbled_deepslate
fill 6 281 295 6 281 297 minecraft:blackstone
setblock 6 281 298 minecraft:cobbled_deepslate
fill 6 281 299 6 281 301 minecraft:blackstone
setblock 6 281 302 minecraft:cobbled_deepslate
fill 6 281 303 6 281 305 minecraft:blackstone
setblock 6 281 306 minecraft:cobbled_deepslate
fill 6 281 307 6 281 309 minecraft:blackstone
setblock 6 281 310 minecraft:cobbled_deepslate
fill 6 281 311 6 281 313 minecraft:blackstone
setblock 6 281 314 minecraft:cobbled_deepslate
fill 6 281 315 6 281 316 minecraft:blackstone
fill 7 281 278 9 281 278 minecraft:blackstone
setblock 7 281 279 minecraft:cobbled_deepslate
fill 7 281 282 9 281 282 minecraft:blackstone
setblock 7 281 283 minecraft:cobbled_deepslate
fill 7 281 284 7 281 286 minecraft:blackstone
setblock 7 281 287 minecraft:cobbled_deepslate
fill 7 281 288 7 281 290 minecraft:blackstone
setblock 7 281 291 minecraft:cobbled_deepslate
fill 7 281 292 7 281 294 minecraft:blackstone
setblock 7 281 295 minecraft:cobbled_deepslate
fill 7 281 296 7 281 298 minecraft:blackstone
setblock 7 281 299 minecraft:cobbled_deepslate
fill 7 281 300 7 281 302 minecraft:blackstone
setblock 7 281 303 minecraft:cobbled_deepslate
fill 7 281 304 7 281 306 minecraft:blackstone
setblock 7 281 307 minecraft:cobbled_deepslate
fill 7 281 308 7 281 310 minecraft:blackstone
setblock 7 281 311 minecraft:cobbled_deepslate
fill 7 281 312 7 281 314 minecraft:blackstone
setblock 7 281 315 minecraft:cobbled_deepslate
setblock 7 281 316 minecraft:blackstone
setblock 8 281 276 minecraft:cobbled_deepslate
fill 8 281 279 10 281 279 minecraft:blackstone
setblock 8 281 280 minecraft:cobbled_deepslate
fill 8 281 283 10 281 283 minecraft:blackstone
setblock 8 281 284 minecraft:cobbled_deepslate
fill 8 281 285 8 281 287 minecraft:blackstone
setblock 8 281 288 minecraft:cobbled_deepslate
fill 8 281 289 8 281 291 minecraft:blackstone
setblock 8 281 292 minecraft:cobbled_deepslate
fill 8 281 293 8 281 295 minecraft:blackstone
setblock 8 281 296 minecraft:cobbled_deepslate
fill 8 281 297 8 281 299 minecraft:blackstone
setblock 8 281 300 minecraft:cobbled_deepslate
fill 8 281 301 8 281 303 minecraft:blackstone
setblock 8 281 304 minecraft:cobbled_deepslate
fill 8 281 305 8 281 307 minecraft:blackstone
setblock 8 281 308 minecraft:cobbled_deepslate
fill 8 281 309 8 281 311 minecraft:blackstone
setblock 8 281 312 minecraft:cobbled_deepslate
fill 8 281 313 8 281 315 minecraft:blackstone
setblock 8 281 316 minecraft:cobbled_deepslate
fill 9 281 276 11 281 276 minecraft:blackstone
setblock 9 281 277 minecraft:cobbled_deepslate
fill 9 281 280 11 281 280 minecraft:blackstone
setblock 9 281 281 minecraft:cobbled_deepslate
fill 9 281 284 11 281 284 minecraft:blackstone
setblock 9 281 285 minecraft:cobbled_deepslate
fill 9 281 286 9 281 288 minecraft:blackstone
setblock 9 281 289 minecraft:cobbled_deepslate
fill 9 281 290 9 281 292 minecraft:blackstone
setblock 9 281 293 minecraft:cobbled_deepslate
fill 9 281 294 9 281 296 minecraft:blackstone
setblock 9 281 297 minecraft:cobbled_deepslate
fill 9 281 298 9 281 300 minecraft:blackstone
setblock 9 281 301 minecraft:cobbled_deepslate
fill 9 281 302 9 281 304 minecraft:blackstone
setblock 9 281 305 minecraft:cobbled_deepslate
fill 9 281 306 9 281 308 minecraft:blackstone
setblock 9 281 309 minecraft:cobbled_deepslate
fill 9 281 310 9 281 312 minecraft:blackstone
setblock 9 281 313 minecraft:cobbled_deepslate
fill 9 281 314 9 281 316 minecraft:blackstone
fill 10 281 277 12 281 277 minecraft:blackstone
setblock 10 281 278 minecraft:cobbled_deepslate
fill 10 281 281 12 281 281 minecraft:blackstone
setblock 10 281 282 minecraft:cobbled_deepslate
fill 10 281 285 12 281 285 minecraft:blackstone
setblock 10 281 286 minecraft:cobbled_deepslate
fill 10 281 287 10 281 289 minecraft:blackstone
setblock 10 281 290 minecraft:cobbled_deepslate
fill 10 281 291 10 281 293 minecraft:blackstone
setblock 10 281 294 minecraft:cobbled_deepslate
fill 10 281 295 10 281 297 minecraft:blackstone
setblock 10 281 298 minecraft:cobbled_deepslate
fill 10 281 299 10 281 301 minecraft:blackstone
setblock 10 281 302 minecraft:cobbled_deepslate
fill 10 281 303 10 281 305 minecraft:blackstone
setblock 10 281 306 minecraft:cobbled_deepslate
fill 10 281 307 10 281 309 minecraft:blackstone
setblock 10 281 310 minecraft:cobbled_deepslate
fill 10 281 311 10 281 313 minecraft:blackstone
setblock 10 281 314 minecraft:cobbled_deepslate
fill 10 281 315 10 281 316 minecraft:blackstone
fill 11 281 278 13 281 278 minecraft:blackstone
setblock 11 281 279 minecraft:cobbled_deepslate
fill 11 281 282 13 281 282 minecraft:blackstone
setblock 11 281 283 minecraft:cobbled_deepslate
fill 11 281 286 13 281 286 minecraft:blackstone
setblock 11 281 287 minecraft:cobbled_deepslate
fill 11 281 288 11 281 290 minecraft:blackstone
setblock 11 281 291 minecraft:cobbled_deepslate
fill 11 281 292 11 281 294 minecraft:blackstone
setblock 11 281 295 minecraft:cobbled_deepslate
fill 11 281 296 11 281 298 minecraft:blackstone
setblock 11 281 299 minecraft:cobbled_deepslate
fill 11 281 300 11 281 302 minecraft:blackstone
setblock 11 281 303 minecraft:cobbled_deepslate
fill 11 281 304 11 281 306 minecraft:blackstone
setblock 11 281 307 minecraft:cobbled_deepslate
fill 11 281 308 11 281 310 minecraft:blackstone
setblock 11 281 311 minecraft:cobbled_deepslate
fill 11 281 312 11 281 314 minecraft:blackstone
setblock 11 281 315 minecraft:cobbled_deepslate
setblock 11 281 316 minecraft:blackstone
setblock 12 281 276 minecraft:cobbled_deepslate
fill 12 281 279 14 281 279 minecraft:blackstone
setblock 12 281 280 minecraft:cobbled_deepslate
fill 12 281 283 14 281 283 minecraft:blackstone
setblock 12 281 284 minecraft:cobbled_deepslate
fill 12 281 287 14 281 287 minecraft:blackstone
setblock 12 281 288 minecraft:cobbled_deepslate
fill 12 281 289 12 281 291 minecraft:blackstone
setblock 12 281 292 minecraft:cobbled_deepslate
fill 12 281 293 12 281 295 minecraft:blackstone
setblock 12 281 296 minecraft:cobbled_deepslate
fill 12 281 297 12 281 299 minecraft:blackstone
setblock 12 281 300 minecraft:cobbled_deepslate
fill 12 281 301 12 281 303 minecraft:blackstone
setblock 12 281 304 minecraft:cobbled_deepslate
fill 12 281 305 12 281 307 minecraft:blackstone
setblock 12 281 308 minecraft:cobbled_deepslate
fill 12 281 309 12 281 311 minecraft:blackstone
setblock 12 281 312 minecraft:cobbled_deepslate
fill 12 281 313 12 281 315 minecraft:blackstone
setblock 12 281 316 minecraft:cobbled_deepslate
fill 13 281 276 15 281 276 minecraft:blackstone
setblock 13 281 277 minecraft:cobbled_deepslate
fill 13 281 280 15 281 280 minecraft:blackstone
setblock 13 281 281 minecraft:cobbled_deepslate
fill 13 281 284 15 281 284 minecraft:blackstone
setblock 13 281 285 minecraft:cobbled_deepslate
fill 13 281 288 15 281 288 minecraft:blackstone
setblock 13 281 289 minecraft:cobbled_deepslate
fill 13 281 290 13 281 292 minecraft:blackstone
setblock 13 281 293 minecraft:cobbled_deepslate
fill 13 281 294 13 281 296 minecraft:blackstone
setblock 13 281 297 minecraft:cobbled_deepslate
fill 13 281 298 13 281 300 minecraft:blackstone
setblock 13 281 301 minecraft:cobbled_deepslate
fill 13 281 302 13 281 304 minecraft:blackstone
setblock 13 281 305 minecraft:cobbled_deepslate
fill 13 281 306 13 281 308 minecraft:blackstone
setblock 13 281 309 minecraft:cobbled_deepslate
fill 13 281 310 13 281 312 minecraft:blackstone
setblock 13 281 313 minecraft:cobbled_deepslate
fill 13 281 314 13 281 316 minecraft:blackstone
fill 14 281 277 16 281 277 minecraft:blackstone
setblock 14 281 278 minecraft:cobbled_deepslate
fill 14 281 281 16 281 281 minecraft:blackstone
setblock 14 281 282 minecraft:cobbled_deepslate
fill 14 281 285 16 281 285 minecraft:blackstone
setblock 14 281 286 minecraft:cobbled_deepslate
fill 14 281 289 16 281 289 minecraft:blackstone
setblock 14 281 290 minecraft:cobbled_deepslate
fill 14 281 291 14 281 293 minecraft:blackstone
setblock 14 281 294 minecraft:cobbled_deepslate
fill 14 281 295 14 281 297 minecraft:blackstone
setblock 14 281 298 minecraft:cobbled_deepslate
fill 14 281 299 14 281 301 minecraft:blackstone
setblock 14 281 302 minecraft:cobbled_deepslate
fill 14 281 303 14 281 305 minecraft:blackstone
setblock 14 281 306 minecraft:cobbled_deepslate
fill 14 281 307 14 281 309 minecraft:blackstone
setblock 14 281 310 minecraft:cobbled_deepslate
fill 14 281 311 14 281 313 minecraft:blackstone
setblock 14 281 314 minecraft:cobbled_deepslate
fill 14 281 315 14 281 316 minecraft:blackstone
fill 15 281 278 17 281 278 minecraft:blackstone
setblock 15 281 279 minecraft:cobbled_deepslate
fill 15 281 282 17 281 282 minecraft:blackstone
setblock 15 281 283 minecraft:cobbled_deepslate
fill 15 281 286 17 281 286 minecraft:blackstone
setblock 15 281 287 minecraft:cobbled_deepslate
fill 15 281 290 17 281 290 minecraft:blackstone
setblock 15 281 291 minecraft:cobbled_deepslate
fill 15 281 292 15 281 294 minecraft:blackstone
setblock 15 281 295 minecraft:cobbled_deepslate
fill 15 281 296 15 281 298 minecraft:blackstone
setblock 15 281 299 minecraft:cobbled_deepslate
fill 15 281 300 15 281 302 minecraft:blackstone
setblock 15 281 303 minecraft:cobbled_deepslate
fill 15 281 304 15 281 306 minecraft:blackstone
setblock 15 281 307 minecraft:cobbled_deepslate
fill 15 281 308 15 281 310 minecraft:blackstone
setblock 15 281 311 minecraft:cobbled_deepslate
fill 15 281 312 15 281 314 minecraft:blackstone
setblock 15 281 315 minecraft:cobbled_deepslate
setblock 15 281 316 minecraft:blackstone
setblock 16 281 276 minecraft:cobbled_deepslate
fill 16 281 279 18 281 279 minecraft:blackstone
setblock 16 281 280 minecraft:cobbled_deepslate
fill 16 281 283 18 281 283 minecraft:blackstone
setblock 16 281 284 minecraft:cobbled_deepslate
fill 16 281 287 18 281 287 minecraft:blackstone
setblock 16 281 288 minecraft:cobbled_deepslate
fill 16 281 291 18 281 291 minecraft:blackstone
setblock 16 281 292 minecraft:cobbled_deepslate
fill 16 281 293 16 281 295 minecraft:blackstone
setblock 16 281 296 minecraft:cobbled_deepslate
fill 16 281 297 16 281 299 minecraft:blackstone
setblock 16 281 300 minecraft:cobbled_deepslate
fill 16 281 301 16 281 303 minecraft:blackstone
setblock 16 281 304 minecraft:cobbled_deepslate
fill 16 281 305 16 281 307 minecraft:blackstone
setblock 16 281 308 minecraft:cobbled_deepslate
fill 16 281 309 16 281 311 minecraft:blackstone
setblock 16 281 312 minecraft:cobbled_deepslate
fill 16 281 313 16 281 315 minecraft:blackstone
setblock 16 281 316 minecraft:cobbled_deepslate
fill 17 281 276 19 281 276 minecraft:blackstone
setblock 17 281 277 minecraft:cobbled_deepslate
fill 17 281 280 19 281 280 minecraft:blackstone
setblock 17 281 281 minecraft:cobbled_deepslate
fill 17 281 284 19 281 284 minecraft:blackstone
setblock 17 281 285 minecraft:cobbled_deepslate
fill 17 281 288 19 281 288 minecraft:blackstone
setblock 17 281 289 minecraft:cobbled_deepslate
fill 17 281 292 17 282 292 minecraft:blackstone
setblock 17 281 293 minecraft:cobbled_deepslate
setblock 17 281 294 minecraft:blackstone
fill 17 281 296 17 282 296 minecraft:blackstone
setblock 17 281 297 minecraft:cobbled_deepslate
fill 17 281 298 17 281 300 minecraft:blackstone
setblock 17 281 301 minecraft:cobbled_deepslate
fill 17 281 302 17 281 304 minecraft:blackstone
setblock 17 281 305 minecraft:cobbled_deepslate
fill 17 281 306 17 281 308 minecraft:blackstone
setblock 17 281 309 minecraft:cobbled_deepslate
fill 17 281 310 17 281 312 minecraft:blackstone
setblock 17 281 313 minecraft:cobbled_deepslate
fill 17 281 314 17 281 316 minecraft:blackstone
fill 18 281 277 20 281 277 minecraft:blackstone
setblock 18 281 278 minecraft:cobbled_deepslate
fill 18 281 281 20 281 281 minecraft:blackstone
setblock 18 281 282 minecraft:cobbled_deepslate
fill 18 281 285 20 281 285 minecraft:blackstone
setblock 18 281 286 minecraft:cobbled_deepslate
fill 18 281 289 20 281 289 minecraft:blackstone
setblock 18 281 290 minecraft:cobbled_deepslate
setblock 18 281 298 minecraft:cobbled_deepslate
fill 18 281 299 18 281 301 minecraft:blackstone
setblock 18 281 302 minecraft:cobbled_deepslate
fill 18 281 303 18 281 305 minecraft:blackstone
setblock 18 281 306 minecraft:cobbled_deepslate
fill 18 281 307 18 281 309 minecraft:blackstone
setblock 18 281 310 minecraft:cobbled_deepslate
fill 18 281 311 18 281 313 minecraft:blackstone
setblock 18 281 314 minecraft:cobbled_deepslate
fill 18 281 315 18 281 316 minecraft:blackstone
fill 19 281 278 21 281 278 minecraft:blackstone
setblock 19 281 279 minecraft:cobbled_deepslate
fill 19 281 282 21 281 282 minecraft:blackstone
setblock 19 281 283 minecraft:cobbled_deepslate
fill 19 281 286 21 281 286 minecraft:blackstone
setblock 19 281 287 minecraft:cobbled_deepslate
fill 19 281 290 21 281 290 minecraft:blackstone
setblock 19 281 291 minecraft:cobbled_deepslate
fill 19 281 298 19 282 298 minecraft:blackstone
setblock 19 281 299 minecraft:cobbled_deepslate
fill 19 281 300 19 281 302 minecraft:blackstone
setblock 19 281 303 minecraft:cobbled_deepslate
fill 19 281 304 19 281 306 minecraft:blackstone
setblock 19 281 307 minecraft:cobbled_deepslate
fill 19 281 308 19 281 310 minecraft:blackstone
setblock 19 281 311 minecraft:cobbled_deepslate
fill 19 281 312 19 281 314 minecraft:blackstone
setblock 19 281 315 minecraft:cobbled_deepslate
setblock 19 281 316 minecraft:blackstone
setblock 20 281 276 minecraft:cobbled_deepslate
fill 20 281 279 22 281 279 minecraft:blackstone
setblock 20 281 280 minecraft:cobbled_deepslate
fill 20 281 283 22 281 283 minecraft:blackstone
setblock 20 281 284 minecraft:cobbled_deepslate
fill 20 281 287 22 281 287 minecraft:blackstone
setblock 20 281 288 minecraft:cobbled_deepslate
fill 20 281 291 22 281 291 minecraft:blackstone
fill 20 281 299 22 281 299 minecraft:blackstone
setblock 20 281 300 minecraft:cobbled_deepslate
fill 20 281 301 20 281 303 minecraft:blackstone
setblock 20 281 304 minecraft:cobbled_deepslate
fill 20 281 305 20 281 307 minecraft:blackstone
setblock 20 281 308 minecraft:cobbled_deepslate
fill 20 281 309 20 281 311 minecraft:blackstone
setblock 20 281 312 minecraft:cobbled_deepslate
fill 20 281 313 20 281 315 minecraft:blackstone
setblock 20 281 316 minecraft:cobbled_deepslate
fill 21 281 276 23 281 276 minecraft:blackstone
setblock 21 281 277 minecraft:cobbled_deepslate
fill 21 281 280 23 281 280 minecraft:blackstone
setblock 21 281 281 minecraft:cobbled_deepslate
fill 21 281 284 23 281 284 minecraft:blackstone
setblock 21 281 285 minecraft:cobbled_deepslate
fill 21 281 288 23 281 288 minecraft:blackstone
setblock 21 281 289 minecraft:cobbled_deepslate
fill 21 281 292 23 281 292 minecraft:blackstone
setblock 21 281 298 minecraft:blackstone
fill 21 281 300 23 281 300 minecraft:blackstone
setblock 21 281 301 minecraft:cobbled_deepslate
fill 21 281 302 21 281 304 minecraft:blackstone
setblock 21 281 305 minecraft:cobbled_deepslate
fill 21 281 306 21 281 308 minecraft:blackstone
setblock 21 281 309 minecraft:cobbled_deepslate
fill 21 281 310 21 281 312 minecraft:blackstone
setblock 21 281 313 minecraft:cobbled_deepslate
fill 21 281 314 21 281 316 minecraft:blackstone
fill 22 281 277 24 281 277 minecraft:blackstone
setblock 22 281 278 minecraft:cobbled_deepslate
fill 22 281 281 24 281 281 minecraft:blackstone
setblock 22 281 282 minecraft:cobbled_deepslate
fill 22 281 285 24 281 285 minecraft:blackstone
setblock 22 281 286 minecraft:cobbled_deepslate
fill 22 281 289 24 281 289 minecraft:blackstone
setblock 22 281 290 minecraft:cobbled_deepslate
setblock 22 281 298 minecraft:cobbled_deepslate
fill 22 281 301 24 281 301 minecraft:blackstone
setblock 22 281 302 minecraft:cobbled_deepslate
fill 22 281 303 22 281 305 minecraft:blackstone
setblock 22 281 306 minecraft:cobbled_deepslate
fill 22 281 307 22 281 309 minecraft:blackstone
setblock 22 281 310 minecraft:cobbled_deepslate
fill 22 281 311 22 281 313 minecraft:blackstone
setblock 22 281 314 minecraft:cobbled_deepslate
fill 22 281 315 22 281 316 minecraft:blackstone
fill 23 281 278 25 281 278 minecraft:blackstone
setblock 23 281 279 minecraft:cobbled_deepslate
fill 23 281 282 25 281 282 minecraft:blackstone
setblock 23 281 283 minecraft:cobbled_deepslate
fill 23 281 286 25 281 286 minecraft:blackstone
setblock 23 281 287 minecraft:cobbled_deepslate
fill 23 281 290 25 281 290 minecraft:blackstone
setblock 23 281 291 minecraft:cobbled_deepslate
fill 23 281 293 24 281 294 minecraft:blackstone
fill 23 281 296 23 281 298 minecraft:blackstone
setblock 23 281 299 minecraft:cobbled_deepslate
fill 23 281 302 25 281 302 minecraft:blackstone
setblock 23 281 303 minecraft:cobbled_deepslate
fill 23 281 304 23 281 306 minecraft:blackstone
setblock 23 281 307 minecraft:cobbled_deepslate
fill 23 281 308 23 281 310 minecraft:blackstone
setblock 23 281 311 minecraft:cobbled_deepslate
fill 23 281 312 23 281 314 minecraft:blackstone
setblock 23 281 315 minecraft:cobbled_deepslate
setblock 23 281 316 minecraft:blackstone
setblock 24 281 276 minecraft:cobbled_deepslate
fill 24 281 279 26 281 279 minecraft:blackstone
setblock 24 281 280 minecraft:cobbled_deepslate
fill 24 281 283 26 281 283 minecraft:blackstone
setblock 24 281 284 minecraft:cobbled_deepslate
fill 24 281 287 26 281 287 minecraft:blackstone
setblock 24 281 288 minecraft:cobbled_deepslate
fill 24 281 291 26 281 291 minecraft:blackstone
setblock 24 281 292 minecraft:cobbled_deepslate
fill 24 281 295 26 281 295 minecraft:blackstone
setblock 24 281 296 minecraft:cobbled_deepslate
fill 24 281 297 24 281 299 minecraft:blackstone
setblock 24 281 300 minecraft:cobbled_deepslate
fill 24 281 303 26 281 303 minecraft:blackstone
setblock 24 281 304 minecraft:cobbled_deepslate
fill 24 281 305 24 281 307 minecraft:blackstone
setblock 24 281 308 minecraft:cobbled_deepslate
fill 24 281 309 24 281 311 minecraft:blackstone
setblock 24 281 312 minecraft:cobbled_deepslate
fill 24 281 313 24 281 315 minecraft:blackstone
setblock 24 281 316 minecraft:cobbled_deepslate
fill 25 281 276 27 281 276 minecraft:blackstone
setblock 25 281 277 minecraft:cobbled_deepslate
fill 25 281 280 27 281 280 minecraft:blackstone
setblock 25 281 281 minecraft:cobbled_deepslate
fill 25 281 284 27 281 284 minecraft:blackstone
setblock 25 281 285 minecraft:cobbled_deepslate
fill 25 281 288 27 281 288 minecraft:blackstone
setblock 25 281 289 minecraft:cobbled_deepslate
fill 25 281 292 27 281 292 minecraft:blackstone
setblock 25 281 293 minecraft:cobbled_deepslate
setblock 25 281 294 minecraft:blackstone
fill 25 281 296 27 281 296 minecraft:blackstone
setblock 25 281 297 minecraft:cobbled_deepslate
fill 25 281 298 25 281 300 minecraft:blackstone
setblock 25 281 301 minecraft:cobbled_deepslate
fill 25 281 304 27 281 304 minecraft:blackstone
setblock 25 281 305 minecraft:cobbled_deepslate
fill 25 281 306 25 281 308 minecraft:blackstone
setblock 25 281 309 minecraft:cobbled_deepslate
fill 25 281 310 25 281 312 minecraft:blackstone
setblock 25 281 313 minecraft:cobbled_deepslate
fill 25 281 314 25 281 316 minecraft:blackstone
fill 26 281 277 28 281 277 minecraft:blackstone
setblock 26 281 278 minecraft:cobbled_deepslate
fill 26 281 281 28 281 281 minecraft:blackstone
setblock 26 281 282 minecraft:cobbled_deepslate
fill 26 281 285 28 281 285 minecraft:blackstone
setblock 26 281 286 minecraft:cobbled_deepslate
fill 26 281 289 28 281 289 minecraft:blackstone
setblock 26 281 290 minecraft:cobbled_deepslate
fill 26 281 293 28 281 293 minecraft:blackstone
setblock 26 281 294 minecraft:cobbled_deepslate
fill 26 281 297 28 281 297 minecraft:blackstone
setblock 26 281 298 minecraft:cobbled_deepslate
fill 26 281 299 26 281 301 minecraft:blackstone
setblock 26 281 302 minecraft:cobbled_deepslate
fill 26 281 305 28 281 305 minecraft:blackstone
setblock 26 281 306 minecraft:cobbled_deepslate
fill 26 281 307 26 281 309 minecraft:blackstone
setblock 26 281 310 minecraft:cobbled_deepslate
fill 26 281 311 26 281 313 minecraft:blackstone
setblock 26 281 314 minecraft:cobbled_deepslate
fill 26 281 315 26 281 316 minecraft:blackstone
fill 27 281 278 29 281 278 minecraft:blackstone
setblock 27 281 279 minecraft:cobbled_deepslate
fill 27 281 282 29 281 282 minecraft:blackstone
setblock 27 281 283 minecraft:cobbled_deepslate
fill 27 281 286 29 281 286 minecraft:blackstone
setblock 27 281 287 minecraft:cobbled_deepslate
fill 27 281 290 29 281 290 minecraft:blackstone
setblock 27 281 291 minecraft:cobbled_deepslate
fill 27 281 294 29 281 294 minecraft:blackstone
setblock 27 281 295 minecraft:cobbled_deepslate
fill 27 281 298 29 281 298 minecraft:blackstone
setblock 27 281 299 minecraft:cobbled_deepslate
fill 27 281 300 27 281 302 minecraft:blackstone
setblock 27 281 303 minecraft:cobbled_deepslate
fill 27 281 306 29 281 306 minecraft:blackstone
setblock 27 281 307 minecraft:cobbled_deepslate
fill 27 281 308 27 281 310 minecraft:blackstone
setblock 27 281 311 minecraft:cobbled_deepslate
fill 27 281 312 27 281 314 minecraft:blackstone
setblock 27 281 315 minecraft:cobbled_deepslate
setblock 27 281 316 minecraft:blackstone
setblock 28 281 276 minecraft:cobbled_deepslate
fill 28 281 279 30 281 279 minecraft:blackstone
setblock 28 281 280 minecraft:cobbled_deepslate
fill 28 281 283 30 281 283 minecraft:blackstone
setblock 28 281 284 minecraft:cobbled_deepslate
fill 28 281 287 30 281 287 minecraft:blackstone
setblock 28 281 288 minecraft:cobbled_deepslate
fill 28 281 291 30 281 291 minecraft:blackstone
setblock 28 281 292 minecraft:cobbled_deepslate
fill 28 281 295 30 281 295 minecraft:blackstone
setblock 28 281 296 minecraft:cobbled_deepslate
fill 28 281 299 30 281 299 minecraft:blackstone
setblock 28 281 300 minecraft:cobbled_deepslate
fill 28 281 301 28 281 303 minecraft:blackstone
setblock 28 281 304 minecraft:cobbled_deepslate
fill 28 281 307 30 281 307 minecraft:blackstone
setblock 28 281 308 minecraft:cobbled_deepslate
fill 28 281 309 28 281 311 minecraft:blackstone
setblock 28 281 312 minecraft:cobbled_deepslate
fill 28 281 313 28 281 315 minecraft:blackstone
setblock 28 281 316 minecraft:cobbled_deepslate
fill 29 281 276 31 281 276 minecraft:blackstone
setblock 29 281 277 minecraft:cobbled_deepslate
fill 29 281 280 31 281 280 minecraft:blackstone
setblock 29 281 281 minecraft:cobbled_deepslate
fill 29 281 284 31 281 284 minecraft:blackstone
setblock 29 281 285 minecraft:cobbled_deepslate
fill 29 281 288 31 281 288 minecraft:blackstone
setblock 29 281 289 minecraft:cobbled_deepslate
fill 29 281 292 31 281 292 minecraft:blackstone
setblock 29 281 293 minecraft:cobbled_deepslate
fill 29 281 296 31 281 296 minecraft:blackstone
setblock 29 281 297 minecraft:cobbled_deepslate
fill 29 281 300 31 281 300 minecraft:blackstone
setblock 29 281 301 minecraft:cobbled_deepslate
fill 29 281 302 29 281 304 minecraft:blackstone
setblock 29 281 305 minecraft:cobbled_deepslate
fill 29 281 308 31 281 308 minecraft:blackstone
setblock 29 281 309 minecraft:cobbled_deepslate
fill 29 281 310 29 281 312 minecraft:blackstone
setblock 29 281 313 minecraft:cobbled_deepslate
fill 29 281 314 29 281 316 minecraft:blackstone
fill 30 281 277 32 281 277 minecraft:blackstone
setblock 30 281 278 minecraft:cobbled_deepslate
fill 30 281 281 32 281 281 minecraft:blackstone
setblock 30 281 282 minecraft:cobbled_deepslate
fill 30 281 285 32 281 285 minecraft:blackstone
setblock 30 281 286 minecraft:cobbled_deepslate
fill 30 281 289 32 281 289 minecraft:blackstone
setblock 30 281 290 minecraft:cobbled_deepslate
fill 30 281 293 32 281 293 minecraft:blackstone
setblock 30 281 294 minecraft:cobbled_deepslate
fill 30 281 297 32 281 297 minecraft:blackstone
setblock 30 281 298 minecraft:cobbled_deepslate
fill 30 281 301 32 281 301 minecraft:blackstone
setblock 30 281 302 minecraft:cobbled_deepslate
fill 30 281 303 30 281 305 minecraft:blackstone
setblock 30 281 306 minecraft:cobbled_deepslate
fill 30 281 309 32 281 309 minecraft:blackstone
setblock 30 281 310 minecraft:cobbled_deepslate
fill 30 281 311 30 281 313 minecraft:blackstone
setblock 30 281 314 minecraft:cobbled_deepslate
fill 30 281 315 30 281 316 minecraft:blackstone
fill 31 281 278 33 281 278 minecraft:blackstone
setblock 31 281 279 minecraft:cobbled_deepslate
fill 31 281 282 33 281 282 minecraft:blackstone
setblock 31 281 283 minecraft:cobbled_deepslate
fill 31 281 286 33 281 286 minecraft:blackstone
setblock 31 281 287 minecraft:cobbled_deepslate
fill 31 281 290 33 281 290 minecraft:blackstone
setblock 31 281 291 minecraft:cobbled_deepslate
fill 31 281 294 33 281 294 minecraft:blackstone
setblock 31 281 295 minecraft:cobbled_deepslate
fill 31 281 298 33 281 298 minecraft:blackstone
setblock 31 281 299 minecraft:cobbled_deepslate
fill 31 281 302 33 281 302 minecraft:blackstone
setblock 31 281 303 minecraft:cobbled_deepslate
fill 31 281 304 31 281 306 minecraft:blackstone
setblock 31 281 307 minecraft:cobbled_deepslate
fill 31 281 310 33 281 310 minecraft:blackstone
setblock 31 281 311 minecraft:cobbled_deepslate
fill 31 281 312 31 281 314 minecraft:blackstone
setblock 31 281 315 minecraft:cobbled_deepslate
setblock 31 281 316 minecraft:blackstone
setblock 32 281 276 minecraft:cobbled_deepslate
fill 32 281 279 34 281 279 minecraft:blackstone
setblock 32 281 280 minecraft:cobbled_deepslate
fill 32 281 283 34 281 283 minecraft:blackstone
setblock 32 281 284 minecraft:cobbled_deepslate
fill 32 281 287 34 281 287 minecraft:blackstone
setblock 32 281 288 minecraft:cobbled_deepslate
fill 32 281 291 34 281 291 minecraft:blackstone
setblock 32 281 292 minecraft:cobbled_deepslate
fill 32 281 295 34 281 295 minecraft:blackstone
setblock 32 281 296 minecraft:cobbled_deepslate
fill 32 281 299 34 281 299 minecraft:blackstone
setblock 32 281 300 minecraft:cobbled_deepslate
fill 32 281 303 34 281 303 minecraft:blackstone
setblock 32 281 304 minecraft:cobbled_deepslate
fill 32 281 305 32 281 307 minecraft:blackstone
setblock 32 281 308 minecraft:cobbled_deepslate
fill 32 281 311 34 281 311 minecraft:blackstone
setblock 32 281 312 minecraft:cobbled_deepslate
fill 32 281 313 32 281 315 minecraft:blackstone
setblock 32 281 316 minecraft:cobbled_deepslate
fill 33 281 276 35 281 276 minecraft:blackstone
setblock 33 281 277 minecraft:cobbled_deepslate
fill 33 281 280 35 281 280 minecraft:blackstone
setblock 33 281 281 minecraft:cobbled_deepslate
fill 33 281 284 35 281 284 minecraft:blackstone
setblock 33 281 285 minecraft:cobbled_deepslate
fill 33 281 288 35 281 288 minecraft:blackstone
setblock 33 281 289 minecraft:cobbled_deepslate
fill 33 281 292 35 281 292 minecraft:blackstone
setblock 33 281 293 minecraft:cobbled_deepslate
fill 33 281 296 35 281 296 minecraft:blackstone
setblock 33 281 297 minecraft:cobbled_deepslate
fill 33 281 300 35 281 300 minecraft:blackstone
setblock 33 281 301 minecraft:cobbled_deepslate
fill 33 281 304 35 281 304 minecraft:blackstone
setblock 33 281 305 minecraft:cobbled_deepslate
fill 33 281 306 33 281 308 minecraft:blackstone
setblock 33 281 309 minecraft:cobbled_deepslate
fill 33 281 312 35 281 312 minecraft:blackstone
setblock 33 281 313 minecraft:cobbled_deepslate
fill 33 281 314 33 281 316 minecraft:blackstone
fill 34 281 277 36 281 277 minecraft:blackstone
setblock 34 281 278 minecraft:cobbled_deepslate
fill 34 281 281 36 281 281 minecraft:blackstone
setblock 34 281 282 minecraft:cobbled_deepslate
fill 34 281 285 36 281 285 minecraft:blackstone
setblock 34 281 286 minecraft:cobbled_deepslate
fill 34 281 289 36 281 289 minecraft:blackstone
setblock 34 281 290 minecraft:cobbled_deepslate
fill 34 281 293 36 281 293 minecraft:blackstone
setblock 34 281 294 minecraft:cobbled_deepslate
fill 34 281 297 36 281 297 minecraft:blackstone
setblock 34 281 298 minecraft:cobbled_deepslate
fill 34 281 301 36 281 301 minecraft:blackstone
setblock 34 281 302 minecraft:cobbled_deepslate
fill 34 281 305 36 281 305 minecraft:blackstone
setblock 34 281 306 minecraft:cobbled_deepslate
fill 34 281 307 34 281 309 minecraft:blackstone
setblock 34 281 310 minecraft:cobbled_deepslate
fill 34 281 313 36 281 313 minecraft:blackstone
setblock 34 281 314 minecraft:cobbled_deepslate
fill 34 281 315 34 281 316 minecraft:blackstone
fill 35 281 278 37 281 278 minecraft:blackstone
setblock 35 281 279 minecraft:cobbled_deepslate
fill 35 281 282 37 281 282 minecraft:blackstone
setblock 35 281 283 minecraft:cobbled_deepslate
fill 35 281 286 37 281 286 minecraft:blackstone
setblock 35 281 287 minecraft:cobbled_deepslate
fill 35 281 290 37 281 290 minecraft:blackstone
setblock 35 281 291 minecraft:cobbled_deepslate
fill 35 281 294 37 281 294 minecraft:blackstone
setblock 35 281 295 minecraft:cobbled_deepslate
fill 35 281 298 37 281 298 minecraft:blackstone
setblock 35 281 299 minecraft:cobbled_deepslate
fill 35 281 302 37 281 302 minecraft:blackstone
setblock 35 281 303 minecraft:cobbled_deepslate
fill 35 281 306 37 281 306 minecraft:blackstone
setblock 35 281 307 minecraft:cobbled_deepslate
fill 35 281 308 35 281 310 minecraft:blackstone
setblock 35 281 311 minecraft:cobbled_deepslate
fill 35 281 314 37 281 314 minecraft:blackstone
setblock 35 281 315 minecraft:cobbled_deepslate
setblock 35 281 316 minecraft:blackstone
setblock 36 281 276 minecraft:cobbled_deepslate
fill 36 281 279 38 281 279 minecraft:blackstone
setblock 36 281 280 minecraft:cobbled_deepslate
fill 36 281 283 38 281 283 minecraft:blackstone
setblock 36 281 284 minecraft:cobbled_deepslate
fill 36 281 287 38 281 287 minecraft:blackstone
setblock 36 281 288 minecraft:cobbled_deepslate
fill 36 281 291 38 281 291 minecraft:blackstone
setblock 36 281 292 minecraft:cobbled_deepslate
fill 36 281 295 38 281 295 minecraft:blackstone
setblock 36 281 296 minecraft:cobbled_deepslate
fill 36 281 299 38 281 299 minecraft:blackstone
setblock 36 281 300 minecraft:cobbled_deepslate
fill 36 281 303 38 281 303 minecraft:blackstone
setblock 36 281 304 minecraft:cobbled_deepslate
fill 36 281 307 38 281 307 minecraft:blackstone
setblock 36 281 308 minecraft:cobbled_deepslate
fill 36 281 309 36 281 311 minecraft:blackstone
setblock 36 281 312 minecraft:cobbled_deepslate
fill 36 281 315 38 281 315 minecraft:blackstone
setblock 36 281 316 minecraft:cobbled_deepslate
fill 37 281 276 39 281 276 minecraft:blackstone
setblock 37 281 277 minecraft:cobbled_deepslate
fill 37 281 280 39 281 280 minecraft:blackstone
setblock 37 281 281 minecraft:cobbled_deepslate
fill 37 281 284 39 281 284 minecraft:blackstone
setblock 37 281 285 minecraft:cobbled_deepslate
fill 37 281 288 39 281 288 minecraft:blackstone
setblock 37 281 289 minecraft:cobbled_deepslate
fill 37 281 292 39 281 292 minecraft:blackstone
setblock 37 281 293 minecraft:cobbled_deepslate
fill 37 281 296 39 281 296 minecraft:blackstone
setblock 37 281 297 minecraft:cobbled_deepslate
fill 37 281 300 39 281 300 minecraft:blackstone
setblock 37 281 301 minecraft:cobbled_deepslate
fill 37 281 304 39 281 304 minecraft:blackstone
setblock 37 281 305 minecraft:cobbled_deepslate
fill 37 281 308 39 281 308 minecraft:blackstone
setblock 37 281 309 minecraft:cobbled_deepslate
fill 37 281 310 37 281 312 minecraft:blackstone
setblock 37 281 313 minecraft:cobbled_deepslate
fill 37 281 316 39 281 316 minecraft:blackstone
fill 38 281 277 40 281 277 minecraft:blackstone
setblock 38 281 278 minecraft:cobbled_deepslate
fill 38 281 281 40 281 281 minecraft:blackstone
setblock 38 281 282 minecraft:cobbled_deepslate
fill 38 281 285 40 281 285 minecraft:blackstone
setblock 38 281 286 minecraft:cobbled_deepslate
fill 38 281 289 40 281 289 minecraft:blackstone
setblock 38 281 290 minecraft:cobbled_deepslate
fill 38 281 293 40 281 293 minecraft:blackstone
setblock 38 281 294 minecraft:cobbled_deepslate
fill 38 281 297 40 281 297 minecraft:blackstone
setblock 38 281 298 minecraft:cobbled_deepslate
fill 38 281 301 40 281 301 minecraft:blackstone
setblock 38 281 302 minecraft:cobbled_deepslate
fill 38 281 305 40 281 305 minecraft:blackstone
setblock 38 281 306 minecraft:cobbled_deepslate
fill 38 281 309 40 281 309 minecraft:blackstone
setblock 38 281 310 minecraft:cobbled_deepslate
fill 38 281 311 38 281 313 minecraft:blackstone
setblock 38 281 314 minecraft:cobbled_deepslate
fill 39 281 278 39 283 278 minecraft:blackstone
setblock 39 281 279 minecraft:cobbled_deepslate
fill 39 281 282 39 283 282 minecraft:blackstone
setblock 39 281 283 minecraft:cobbled_deepslate
fill 39 281 286 39 283 286 minecraft:blackstone
setblock 39 281 287 minecraft:cobbled_deepslate
fill 39 281 290 39 283 290 minecraft:blackstone
setblock 39 281 291 minecraft:cobbled_deepslate
fill 39 281 294 39 283 294 minecraft:blackstone
setblock 39 281 295 minecraft:cobbled_deepslate
fill 39 281 298 39 283 298 minecraft:blackstone
setblock 39 281 299 minecraft:cobbled_deepslate
fill 39 281 302 39 283 302 minecraft:blackstone
setblock 39 281 303 minecraft:cobbled_deepslate
fill 39 281 306 39 283 306 minecraft:blackstone
setblock 39 281 307 minecraft:cobbled_deepslate
fill 39 281 310 39 283 310 minecraft:blackstone
setblock 39 281 311 minecraft:cobbled_deepslate
fill 39 281 312 39 281 314 minecraft:blackstone
setblock 39 281 315 minecraft:cobbled_deepslate
setblock 40 281 276 minecraft:cobbled_deepslate
fill 40 281 279 40 283 279 minecraft:blackstone
setblock 40 281 280 minecraft:cobbled_deepslate
fill 40 281 283 40 283 283 minecraft:blackstone
setblock 40 281 284 minecraft:cobbled_deepslate
fill 40 281 287 40 283 287 minecraft:blackstone
setblock 40 281 288 minecraft:cobbled_deepslate
fill 40 281 291 40 283 291 minecraft:blackstone
setblock 40 281 292 minecraft:cobbled_deepslate
fill 40 281 295 40 283 295 minecraft:blackstone
setblock 40 281 296 minecraft:cobbled_deepslate
fill 40 281 299 40 283 299 minecraft:blackstone
setblock 40 281 300 minecraft:cobbled_deepslate
fill 40 281 303 40 283 303 minecraft:blackstone
setblock 40 281 304 minecraft:cobbled_deepslate
fill 40 281 307 40 283 307 minecraft:blackstone
setblock 40 281 308 minecraft:cobbled_deepslate
fill 40 281 311 40 283 311 minecraft:blackstone
setblock 40 281 312 minecraft:cobbled_deepslate
setblock 40 281 313 minecraft:blackstone
fill 40 281 315 40 283 315 minecraft:blackstone
setblock 40 281 316 minecraft:cobbled_deepslate
fill 41 281 276 41 283 276 minecraft:blackstone
setblock 41 281 277 minecraft:cobbled_deepslate
fill 41 281 280 41 283 280 minecraft:blackstone
setblock 41 281 281 minecraft:cobbled_deepslate
fill 41 281 284 41 283 284 minecraft:blackstone
setblock 41 281 285 minecraft:cobbled_deepslate
fill 41 281 288 41 283 288 minecraft:blackstone
setblock 41 281 289 minecraft:cobbled_deepslate
fill 41 281 292 41 283 292 minecraft:blackstone
setblock 41 281 293 minecraft:cobbled_deepslate
fill 41 281 296 41 283 296 minecraft:blackstone
setblock 41 281 297 minecraft:cobbled_deepslate
fill 41 281 300 41 283 300 minecraft:blackstone
setblock 41 281 301 minecraft:cobbled_deepslate
fill 41 281 304 41 283 304 minecraft:blackstone
setblock 41 281 305 minecraft:cobbled_deepslate
fill 41 281 308 41 283 308 minecraft:blackstone
setblock 41 281 309 minecraft:cobbled_deepslate
fill 41 281 312 41 283 312 minecraft:blackstone
setblock 41 281 313 minecraft:cobbled_deepslate
fill 41 281 316 41 283 316 minecraft:blackstone
fill 1 282 276 2 282 277 minecraft:blackstone
setblock 1 282 278 minecraft:cobbled_deepslate
fill 1 282 279 1 282 281 minecraft:blackstone
setblock 1 282 282 minecraft:cobbled_deepslate
fill 1 282 283 1 282 285 minecraft:blackstone
setblock 1 282 286 minecraft:cobbled_deepslate
fill 1 282 287 1 282 289 minecraft:blackstone
setblock 1 282 290 minecraft:cobbled_deepslate
fill 1 282 291 1 282 293 minecraft:blackstone
setblock 1 282 294 minecraft:cobbled_deepslate
fill 1 282 295 1 282 297 minecraft:blackstone
setblock 1 282 298 minecraft:cobbled_deepslate
fill 1 282 299 1 282 301 minecraft:blackstone
setblock 1 282 302 minecraft:cobbled_deepslate
fill 1 282 303 1 282 305 minecraft:blackstone
setblock 1 282 306 minecraft:cobbled_deepslate
fill 1 282 307 1 282 309 minecraft:blackstone
setblock 1 282 310 minecraft:cobbled_deepslate
fill 1 282 311 1 282 313 minecraft:blackstone
setblock 1 282 314 minecraft:cobbled_deepslate
fill 1 282 315 1 282 316 minecraft:blackstone
fill 2 282 278 4 282 278 minecraft:blackstone
setblock 2 282 279 minecraft:cobbled_deepslate
fill 2 282 280 2 282 282 minecraft:blackstone
setblock 2 282 283 minecraft:cobbled_deepslate
fill 2 282 284 2 282 286 minecraft:blackstone
setblock 2 282 287 minecraft:cobbled_deepslate
fill 2 282 288 2 282 290 minecraft:blackstone
setblock 2 282 291 minecraft:cobbled_deepslate
fill 2 282 292 2 282 294 minecraft:blackstone
setblock 2 282 295 minecraft:cobbled_deepslate
fill 2 282 296 2 282 298 minecraft:blackstone
setblock 2 282 299 minecraft:cobbled_deepslate
fill 2 282 300 2 282 302 minecraft:blackstone
setblock 2 282 303 minecraft:cobbled_deepslate
fill 2 282 304 2 282 306 minecraft:blackstone
setblock 2 282 307 minecraft:cobbled_deepslate
fill 2 282 308 2 282 310 minecraft:blackstone
setblock 2 282 311 minecraft:cobbled_deepslate
fill 2 282 312 2 282 314 minecraft:blackstone
setblock 2 282 315 minecraft:cobbled_deepslate
setblock 2 282 316 minecraft:blackstone
setblock 3 282 276 minecraft:cobbled_deepslate
setblock 3 282 277 minecraft:blackstone
fill 3 282 279 5 282 279 minecraft:blackstone
setblock 3 282 280 minecraft:cobbled_deepslate
fill 3 282 281 3 282 283 minecraft:blackstone
setblock 3 282 284 minecraft:cobbled_deepslate
fill 3 282 285 3 282 287 minecraft:blackstone
setblock 3 282 288 minecraft:cobbled_deepslate
fill 3 282 289 3 282 291 minecraft:blackstone
setblock 3 282 292 minecraft:cobbled_deepslate
fill 3 282 293 3 282 295 minecraft:blackstone
setblock 3 282 296 minecraft:cobbled_deepslate
fill 3 282 297 3 282 299 minecraft:blackstone
setblock 3 282 300 minecraft:cobbled_deepslate
fill 3 282 301 3 282 303 minecraft:blackstone
setblock 3 282 304 minecraft:cobbled_deepslate
fill 3 282 305 3 282 307 minecraft:blackstone
setblock 3 282 308 minecraft:cobbled_deepslate
fill 3 282 309 3 282 311 minecraft:blackstone
setblock 3 282 312 minecraft:cobbled_deepslate
fill 3 282 313 3 282 315 minecraft:blackstone
setblock 3 282 316 minecraft:cobbled_deepslate
fill 4 282 276 6 282 276 minecraft:blackstone
setblock 4 282 277 minecraft:cobbled_deepslate
fill 4 282 280 6 282 280 minecraft:blackstone
setblock 4 282 281 minecraft:cobbled_deepslate
fill 4 282 282 4 282 284 minecraft:blackstone
setblock 4 282 285 minecraft:cobbled_deepslate
fill 4 282 286 4 282 288 minecraft:blackstone
setblock 4 282 289 minecraft:cobbled_deepslate
fill 4 282 290 4 282 292 minecraft:blackstone
setblock 4 282 293 minecraft:cobbled_deepslate
fill 4 282 294 4 282 296 minecraft:blackstone
setblock 4 282 297 minecraft:cobbled_deepslate
fill 4 282 298 4 282 300 minecraft:blackstone
setblock 4 282 301 minecraft:cobbled_deepslate
fill 4 282 302 4 282 304 minecraft:blackstone
setblock 4 282 305 minecraft:cobbled_deepslate
fill 4 282 306 4 282 308 minecraft:blackstone
setblock 4 282 309 minecraft:cobbled_deepslate
fill 4 282 310 4 282 312 minecraft:blackstone
setblock 4 282 313 minecraft:cobbled_deepslate
fill 4 282 314 4 282 316 minecraft:blackstone
fill 5 282 277 7 282 277 minecraft:blackstone
setblock 5 282 278 minecraft:cobbled_deepslate
fill 5 282 281 7 282 281 minecraft:blackstone
setblock 5 282 282 minecraft:cobbled_deepslate
fill 5 282 283 5 282 285 minecraft:blackstone
setblock 5 282 286 minecraft:cobbled_deepslate
fill 5 282 287 5 282 289 minecraft:blackstone
setblock 5 282 290 minecraft:cobbled_deepslate
fill 5 282 291 5 282 293 minecraft:blackstone
setblock 5 282 294 minecraft:cobbled_deepslate
fill 5 282 295 5 282 297 minecraft:blackstone
setblock 5 282 298 minecraft:cobbled_deepslate
fill 5 282 299 5 282 301 minecraft:blackstone
setblock 5 282 302 minecraft:cobbled_deepslate
fill 5 282 303 5 282 305 minecraft:blackstone
setblock 5 282 306 minecraft:cobbled_deepslate
fill 5 282 307 5 282 309 minecraft:blackstone
setblock 5 282 310 minecraft:cobbled_deepslate
fill 5 282 311 5 282 313 minecraft:blackstone
setblock 5 282 314 minecraft:cobbled_deepslate
fill 5 282 315 5 282 316 minecraft:blackstone
fill 6 282 278 8 282 278 minecraft:blackstone
setblock 6 282 279 minecraft:cobbled_deepslate
fill 6 282 282 8 282 282 minecraft:blackstone
setblock 6 282 283 minecraft:cobbled_deepslate
fill 6 282 284 6 282 286 minecraft:blackstone
setblock 6 282 287 minecraft:cobbled_deepslate
fill 6 282 288 6 282 290 minecraft:blackstone
setblock 6 282 291 minecraft:cobbled_deepslate
fill 6 282 292 6 282 294 minecraft:blackstone
setblock 6 282 295 minecraft:cobbled_deepslate
fill 6 282 296 6 282 298 minecraft:blackstone
setblock 6 282 299 minecraft:cobbled_deepslate
fill 6 282 300 6 282 302 minecraft:blackstone
setblock 6 282 303 minecraft:cobbled_deepslate
fill 6 282 304 6 282 306 minecraft:blackstone
setblock 6 282 307 minecraft:cobbled_deepslate
fill 6 282 308 6 282 310 minecraft:blackstone
setblock 6 282 311 minecraft:cobbled_deepslate
fill 6 282 312 6 282 314 minecraft:blackstone
setblock 6 282 315 minecraft:cobbled_deepslate
setblock 6 282 316 minecraft:blackstone
setblock 7 282 276 minecraft:cobbled_deepslate
fill 7 282 279 9 282 279 minecraft:blackstone
setblock 7 282 280 minecraft:cobbled_deepslate
fill 7 282 283 9 282 283 minecraft:blackstone
setblock 7 282 284 minecraft:cobbled_deepslate
fill 7 282 285 7 282 287 minecraft:blackstone
setblock 7 282 288 minecraft:cobbled_deepslate
fill 7 282 289 7 282 291 minecraft:blackstone
setblock 7 282 292 minecraft:cobbled_deepslate
fill 7 282 293 7 282 295 minecraft:blackstone
setblock 7 282 296 minecraft:cobbled_deepslate
fill 7 282 297 7 282 299 minecraft:blackstone
setblock 7 282 300 minecraft:cobbled_deepslate
fill 7 282 301 7 282 303 minecraft:blackstone
setblock 7 282 304 minecraft:cobbled_deepslate
fill 7 282 305 7 282 307 minecraft:blackstone
setblock 7 282 308 minecraft:cobbled_deepslate
fill 7 282 309 7 282 311 minecraft:blackstone
setblock 7 282 312 minecraft:cobbled_deepslate
fill 7 282 313 7 282 315 minecraft:blackstone
setblock 7 282 316 minecraft:cobbled_deepslate
fill 8 282 276 10 282 276 minecraft:blackstone
setblock 8 282 277 minecraft:cobbled_deepslate
fill 8 282 280 10 282 280 minecraft:blackstone
setblock 8 282 281 minecraft:cobbled_deepslate
fill 8 282 284 10 282 284 minecraft:blackstone
setblock 8 282 285 minecraft:cobbled_deepslate
fill 8 282 286 8 282 288 minecraft:blackstone
setblock 8 282 289 minecraft:cobbled_deepslate
fill 8 282 290 8 282 292 minecraft:blackstone
setblock 8 282 293 minecraft:cobbled_deepslate
fill 8 282 294 8 282 296 minecraft:blackstone
setblock 8 282 297 minecraft:cobbled_deepslate
fill 8 282 298 8 282 300 minecraft:blackstone
setblock 8 282 301 minecraft:cobbled_deepslate
fill 8 282 302 8 282 304 minecraft:blackstone
setblock 8 282 305 minecraft:cobbled_deepslate
fill 8 282 306 8 282 308 minecraft:blackstone
setblock 8 282 309 minecraft:cobbled_deepslate
fill 8 282 310 8 282 312 minecraft:blackstone
setblock 8 282 313 minecraft:cobbled_deepslate
fill 8 282 314 8 282 316 minecraft:blackstone
fill 9 282 277 11 282 277 minecraft:blackstone
setblock 9 282 278 minecraft:cobbled_deepslate
fill 9 282 281 11 282 281 minecraft:blackstone
setblock 9 282 282 minecraft:cobbled_deepslate
fill 9 282 285 11 282 285 minecraft:blackstone
setblock 9 282 286 minecraft:cobbled_deepslate
fill 9 282 287 9 282 289 minecraft:blackstone
setblock 9 282 290 minecraft:cobbled_deepslate
fill 9 282 291 9 282 293 minecraft:blackstone
setblock 9 282 294 minecraft:cobbled_deepslate
fill 9 282 295 9 282 297 minecraft:blackstone
setblock 9 282 298 minecraft:cobbled_deepslate
fill 9 282 299 9 282 301 minecraft:blackstone
setblock 9 282 302 minecraft:cobbled_deepslate
fill 9 282 303 9 282 305 minecraft:blackstone
setblock 9 282 306 minecraft:cobbled_deepslate
fill 9 282 307 9 282 309 minecraft:blackstone
setblock 9 282 310 minecraft:cobbled_deepslate
fill 9 282 311 9 282 313 minecraft:blackstone
setblock 9 282 314 minecraft:cobbled_deepslate
fill 9 282 315 9 282 316 minecraft:blackstone
fill 10 282 278 12 282 278 minecraft:blackstone
setblock 10 282 279 minecraft:cobbled_deepslate
fill 10 282 282 12 282 282 minecraft:blackstone
setblock 10 282 283 minecraft:cobbled_deepslate
fill 10 282 286 12 282 286 minecraft:blackstone
setblock 10 282 287 minecraft:cobbled_deepslate
fill 10 282 288 10 282 290 minecraft:blackstone
setblock 10 282 291 minecraft:cobbled_deepslate
fill 10 282 292 10 282 294 minecraft:blackstone
setblock 10 282 295 minecraft:cobbled_deepslate
fill 10 282 296 10 282 298 minecraft:blackstone
setblock 10 282 299 minecraft:cobbled_deepslate
fill 10 282 300 10 282 302 minecraft:blackstone
setblock 10 282 303 minecraft:cobbled_deepslate
fill 10 282 304 10 282 306 minecraft:blackstone
setblock 10 282 307 minecraft:cobbled_deepslate
fill 10 282 308 10 282 310 minecraft:blackstone
setblock 10 282 311 minecraft:cobbled_deepslate
fill 10 282 312 10 282 314 minecraft:blackstone
setblock 10 282 315 minecraft:cobbled_deepslate
setblock 10 282 316 minecraft:blackstone
setblock 11 282 276 minecraft:cobbled_deepslate
fill 11 282 279 13 282 279 minecraft:blackstone
setblock 11 282 280 minecraft:cobbled_deepslate
fill 11 282 283 13 282 283 minecraft:blackstone
setblock 11 282 284 minecraft:cobbled_deepslate
fill 11 282 287 13 282 287 minecraft:blackstone
setblock 11 282 288 minecraft:cobbled_deepslate
fill 11 282 289 11 282 291 minecraft:blackstone
setblock 11 282 292 minecraft:cobbled_deepslate
fill 11 282 293 11 282 295 minecraft:blackstone
setblock 11 282 296 minecraft:cobbled_deepslate
fill 11 282 297 11 282 299 minecraft:blackstone
setblock 11 282 300 minecraft:cobbled_deepslate
fill 11 282 301 11 282 303 minecraft:blackstone
setblock 11 282 304 minecraft:cobbled_deepslate
fill 11 282 305 11 282 307 minecraft:blackstone
setblock 11 282 308 minecraft:cobbled_deepslate
fill 11 282 309 11 282 311 minecraft:blackstone
setblock 11 282 312 minecraft:cobbled_deepslate
fill 11 282 313 11 282 315 minecraft:blackstone
setblock 11 282 316 minecraft:cobbled_deepslate
fill 12 282 276 14 282 276 minecraft:blackstone
setblock 12 282 277 minecraft:cobbled_deepslate
fill 12 282 280 14 282 280 minecraft:blackstone
setblock 12 282 281 minecraft:cobbled_deepslate
fill 12 282 284 14 282 284 minecraft:blackstone
setblock 12 282 285 minecraft:cobbled_deepslate
fill 12 282 288 14 282 288 minecraft:blackstone
setblock 12 282 289 minecraft:cobbled_deepslate
fill 12 282 290 12 282 292 minecraft:blackstone
setblock 12 282 293 minecraft:cobbled_deepslate
fill 12 282 294 12 282 296 minecraft:blackstone
setblock 12 282 297 minecraft:cobbled_deepslate
fill 12 282 298 12 282 300 minecraft:blackstone
setblock 12 282 301 minecraft:cobbled_deepslate
fill 12 282 302 12 282 304 minecraft:blackstone
setblock 12 282 305 minecraft:cobbled_deepslate
fill 12 282 306 12 282 308 minecraft:blackstone
setblock 12 282 309 minecraft:cobbled_deepslate
fill 12 282 310 12 282 312 minecraft:blackstone
setblock 12 282 313 minecraft:cobbled_deepslate
fill 12 282 314 12 282 316 minecraft:blackstone
fill 13 282 277 15 282 277 minecraft:blackstone
setblock 13 282 278 minecraft:cobbled_deepslate
fill 13 282 281 15 282 281 minecraft:blackstone
setblock 13 282 282 minecraft:cobbled_deepslate
fill 13 282 285 15 282 285 minecraft:blackstone
setblock 13 282 286 minecraft:cobbled_deepslate
fill 13 282 289 15 282 289 minecraft:blackstone
setblock 13 282 290 minecraft:cobbled_deepslate
fill 13 282 291 13 282 293 minecraft:blackstone
setblock 13 282 294 minecraft:cobbled_deepslate
fill 13 282 295 13 282 297 minecraft:blackstone
setblock 13 282 298 minecraft:cobbled_deepslate
fill 13 282 299 13 282 301 minecraft:blackstone
setblock 13 282 302 minecraft:cobbled_deepslate
fill 13 282 303 13 282 305 minecraft:blackstone
setblock 13 282 306 minecraft:cobbled_deepslate
fill 13 282 307 13 282 309 minecraft:blackstone
setblock 13 282 310 minecraft:cobbled_deepslate
fill 13 282 311 13 282 313 minecraft:blackstone
setblock 13 282 314 minecraft:cobbled_deepslate
fill 13 282 315 13 282 316 minecraft:blackstone
fill 14 282 278 16 282 278 minecraft:blackstone
setblock 14 282 279 minecraft:cobbled_deepslate
fill 14 282 282 16 282 282 minecraft:blackstone
setblock 14 282 283 minecraft:cobbled_deepslate
fill 14 282 286 16 282 286 minecraft:blackstone
setblock 14 282 287 minecraft:cobbled_deepslate
fill 14 282 290 16 282 290 minecraft:blackstone
setblock 14 282 291 minecraft:cobbled_deepslate
fill 14 282 292 14 282 294 minecraft:blackstone
setblock 14 282 295 minecraft:cobbled_deepslate
fill 14 282 296 14 282 298 minecraft:blackstone
setblock 14 282 299 minecraft:cobbled_deepslate
fill 14 282 300 14 282 302 minecraft:blackstone
setblock 14 282 303 minecraft:cobbled_deepslate
fill 14 282 304 14 282 306 minecraft:blackstone
setblock 14 282 307 minecraft:cobbled_deepslate
fill 14 282 308 14 282 310 minecraft:blackstone
setblock 14 282 311 minecraft:cobbled_deepslate
fill 14 282 312 14 282 314 minecraft:blackstone
setblock 14 282 315 minecraft:cobbled_deepslate
setblock 14 282 316 minecraft:blackstone
setblock 15 282 276 minecraft:cobbled_deepslate
fill 15 282 279 17 282 279 minecraft:blackstone
setblock 15 282 280 minecraft:cobbled_deepslate
fill 15 282 283 17 282 283 minecraft:blackstone
setblock 15 282 284 minecraft:cobbled_deepslate
fill 15 282 287 17 282 287 minecraft:blackstone
setblock 15 282 288 minecraft:cobbled_deepslate
fill 15 282 291 17 282 291 minecraft:blackstone
setblock 15 282 292 minecraft:cobbled_deepslate
fill 15 282 293 15 282 295 minecraft:blackstone
setblock 15 282 296 minecraft:cobbled_deepslate
fill 15 282 297 15 282 299 minecraft:blackstone
setblock 15 282 300 minecraft:cobbled_deepslate
fill 15 282 301 15 282 303 minecraft:blackstone
setblock 15 282 304 minecraft:cobbled_deepslate
fill 15 282 305 15 282 307 minecraft:blackstone
setblock 15 282 308 minecraft:cobbled_deepslate
fill 15 282 309 15 282 311 minecraft:blackstone
setblock 15 282 312 minecraft:cobbled_deepslate
fill 15 282 313 15 282 315 minecraft:blackstone
setblock 15 282 316 minecraft:cobbled_deepslate
fill 16 282 276 18 282 276 minecraft:blackstone
setblock 16 282 277 minecraft:cobbled_deepslate
fill 16 282 280 18 282 280 minecraft:blackstone
setblock 16 282 281 minecraft:cobbled_deepslate
fill 16 282 284 18 282 284 minecraft:blackstone
setblock 16 282 285 minecraft:cobbled_deepslate
fill 16 282 288 18 282 288 minecraft:blackstone
setblock 16 282 289 minecraft:cobbled_deepslate
fill 16 282 292 16 283 292 minecraft:blackstone
setblock 16 282 293 minecraft:cobbled_deepslate
fill 16 282 294 16 282 296 minecraft:blackstone
setblock 16 282 297 minecraft:cobbled_deepslate
fill 16 282 298 16 282 300 minecraft:blackstone
setblock 16 282 301 minecraft:cobbled_deepslate
fill 16 282 302 16 282 304 minecraft:blackstone
setblock 16 282 305 minecraft:cobbled_deepslate
fill 16 282 306 16 282 308 minecraft:blackstone
setblock 16 282 309 minecraft:cobbled_deepslate
fill 16 282 310 16 282 312 minecraft:blackstone
setblock 16 282 313 minecraft:cobbled_deepslate
fill 16 282 314 16 282 316 minecraft:blackstone
fill 17 282 277 19 282 277 minecraft:blackstone
setblock 17 282 278 minecraft:cobbled_deepslate
fill 17 282 281 19 282 281 minecraft:blackstone
setblock 17 282 282 minecraft:cobbled_deepslate
fill 17 282 285 19 282 285 minecraft:blackstone
setblock 17 282 286 minecraft:cobbled_deepslate
fill 17 282 289 19 282 289 minecraft:blackstone
setblock 17 282 290 minecraft:cobbled_deepslate
setblock 17 282 293 minecraft:blackstone
setblock 17 282 294 minecraft:cobbled_deepslate
setblock 17 282 297 minecraft:blackstone
setblock 17 282 298 minecraft:cobbled_deepslate
fill 17 282 299 17 282 301 minecraft:blackstone
setblock 17 282 302 minecraft:cobbled_deepslate
fill 17 282 303 17 282 305 minecraft:blackstone
setblock 17 282 306 minecraft:cobbled_deepslate
fill 17 282 307 17 282 309 minecraft:blackstone
setblock 17 282 310 minecraft:cobbled_deepslate
fill 17 282 311 17 282 313 minecraft:blackstone
setblock 17 282 314 minecraft:cobbled_deepslate
fill 17 282 315 17 282 316 minecraft:blackstone
fill 18 282 278 20 282 278 minecraft:blackstone
setblock 18 282 279 minecraft:cobbled_deepslate
fill 18 282 282 20 282 282 minecraft:blackstone
setblock 18 282 283 minecraft:cobbled_deepslate
fill 18 282 286 20 282 286 minecraft:blackstone
setblock 18 282 287 minecraft:cobbled_deepslate
fill 18 282 290 20 282 290 minecraft:blackstone
setblock 18 282 291 minecraft:cobbled_deepslate
setblock 18 282 292 minecraft:blackstone
setblock 18 282 298 minecraft:blackstone
setblock 18 282 299 minecraft:cobbled_deepslate
fill 18 282 300 18 282 302 minecraft:blackstone
setblock 18 282 303 minecraft:cobbled_deepslate
fill 18 282 304 18 282 306 minecraft:blackstone
setblock 18 282 307 minecraft:cobbled_deepslate
fill 18 282 308 18 282 310 minecraft:blackstone
setblock 18 282 311 minecraft:cobbled_deepslate
fill 18 282 312 18 282 314 minecraft:blackstone
setblock 18 282 315 minecraft:cobbled_deepslate
setblock 18 282 316 minecraft:blackstone
setblock 19 282 276 minecraft:cobbled_deepslate
fill 19 282 279 21 282 279 minecraft:blackstone
setblock 19 282 280 minecraft:cobbled_deepslate
fill 19 282 283 21 282 283 minecraft:blackstone
setblock 19 282 284 minecraft:cobbled_deepslate
fill 19 282 287 21 282 287 minecraft:blackstone
setblock 19 282 288 minecraft:cobbled_deepslate
fill 19 282 291 21 282 291 minecraft:blackstone
setblock 19 282 292 minecraft:cobbled_deepslate
fill 19 282 299 21 282 299 minecraft:blackstone
setblock 19 282 300 minecraft:cobbled_deepslate
fill 19 282 301 19 282 303 minecraft:blackstone
setblock 19 282 304 minecraft:cobbled_deepslate
fill 19 282 305 19 282 307 minecraft:blackstone
setblock 19 282 308 minecraft:cobbled_deepslate
fill 19 282 309 19 282 311 minecraft:blackstone
setblock 19 282 312 minecraft:cobbled_deepslate
fill 19 282 313 19 282 315 minecraft:blackstone
setblock 19 282 316 minecraft:cobbled_deepslate
fill 20 282 276 22 282 276 minecraft:blackstone
setblock 20 282 277 minecraft:cobbled_deepslate
fill 20 282 280 22 282 280 minecraft:blackstone
setblock 20 282 281 minecraft:cobbled_deepslate
fill 20 282 284 22 282 284 minecraft:blackstone
setblock 20 282 285 minecraft:cobbled_deepslate
fill 20 282 288 22 282 288 minecraft:blackstone
setblock 20 282 289 minecraft:cobbled_deepslate
fill 20 282 300 22 282 300 minecraft:blackstone
setblock 20 282 301 minecraft:cobbled_deepslate
fill 20 282 302 20 282 304 minecraft:blackstone
setblock 20 282 305 minecraft:cobbled_deepslate
fill 20 282 306 20 282 308 minecraft:blackstone
setblock 20 282 309 minecraft:cobbled_deepslate
fill 20 282 310 20 282 312 minecraft:blackstone
setblock 20 282 313 minecraft:cobbled_deepslate
fill 20 282 314 20 282 316 minecraft:blackstone
fill 21 282 277 23 282 277 minecraft:blackstone
setblock 21 282 278 minecraft:cobbled_deepslate
fill 21 282 281 23 282 281 minecraft:blackstone
setblock 21 282 282 minecraft:cobbled_deepslate
fill 21 282 285 23 282 285 minecraft:blackstone
setblock 21 282 286 minecraft:cobbled_deepslate
fill 21 282 289 23 282 289 minecraft:blackstone
setblock 21 282 290 minecraft:cobbled_deepslate
fill 21 282 292 22 282 292 minecraft:blackstone
setblock 21 282 298 minecraft:cobbled_deepslate
fill 21 282 301 23 282 301 minecraft:blackstone
setblock 21 282 302 minecraft:cobbled_deepslate
fill 21 282 303 21 282 305 minecraft:blackstone
setblock 21 282 306 minecraft:cobbled_deepslate
fill 21 282 307 21 282 309 minecraft:blackstone
setblock 21 282 310 minecraft:cobbled_deepslate
fill 21 282 311 21 282 313 minecraft:blackstone
setblock 21 282 314 minecraft:cobbled_deepslate
fill 21 282 315 21 282 316 minecraft:blackstone
fill 22 282 278 24 282 278 minecraft:blackstone
setblock 22 282 279 minecraft:cobbled_deepslate
fill 22 282 282 24 282 282 minecraft:blackstone
setblock 22 282 283 minecraft:cobbled_deepslate
fill 22 282 286 24 282 286 minecraft:blackstone
setblock 22 282 287 minecraft:cobbled_deepslate
fill 22 282 290 24 282 290 minecraft:blackstone
setblock 22 282 291 minecraft:cobbled_deepslate
fill 22 282 298 24 282 298 minecraft:blackstone
setblock 22 282 299 minecraft:cobbled_deepslate
fill 22 282 302 24 282 302 minecraft:blackstone
setblock 22 282 303 minecraft:cobbled_deepslate
fill 22 282 304 22 282 306 minecraft:blackstone
setblock 22 282 307 minecraft:cobbled_deepslate
fill 22 282 308 22 282 310 minecraft:blackstone
setblock 22 282 311 minecraft:cobbled_deepslate
fill 22 282 312 22 282 314 minecraft:blackstone
setblock 22 282 315 minecraft:cobbled_deepslate
setblock 22 282 316 minecraft:blackstone
setblock 23 282 276 minecraft:cobbled_deepslate
fill 23 282 279 25 282 279 minecraft:blackstone
setblock 23 282 280 minecraft:cobbled_deepslate
fill 23 282 283 25 282 283 minecraft:blackstone
setblock 23 282 284 minecraft:cobbled_deepslate
fill 23 282 287 25 282 287 minecraft:blackstone
setblock 23 282 288 minecraft:cobbled_deepslate
fill 23 282 291 25 282 291 minecraft:blackstone
setblock 23 282 292 minecraft:cobbled_deepslate
fill 23 282 293 23 282 294 minecraft:blackstone
setblock 23 282 296 minecraft:cobbled_deepslate
setblock 23 282 297 minecraft:blackstone
fill 23 282 299 25 282 299 minecraft:blackstone
setblock 23 282 300 minecraft:cobbled_deepslate
fill 23 282 303 25 282 303 minecraft:blackstone
setblock 23 282 304 minecraft:cobbled_deepslate
fill 23 282 305 23 282 307 minecraft:blackstone
setblock 23 282 308 minecraft:cobbled_deepslate
fill 23 282 309 23 282 311 minecraft:blackstone
setblock 23 282 312 minecraft:cobbled_deepslate
fill 23 282 313 23 282 315 minecraft:blackstone
setblock 23 282 316 minecraft:cobbled_deepslate
fill 24 282 276 26 282 276 minecraft:blackstone
setblock 24 282 277 minecraft:cobbled_deepslate
fill 24 282 280 26 282 280 minecraft:blackstone
setblock 24 282 281 minecraft:cobbled_deepslate
fill 24 282 284 26 282 284 minecraft:blackstone
setblock 24 282 285 minecraft:cobbled_deepslate
fill 24 282 288 26 282 288 minecraft:blackstone
setblock 24 282 289 minecraft:cobbled_deepslate
fill 24 282 292 26 282 292 minecraft:blackstone
setblock 24 282 293 minecraft:cobbled_deepslate
fill 24 282 294 24 282 296 minecraft:blackstone
setblock 24 282 297 minecraft:cobbled_deepslate
fill 24 282 300 26 282 300 minecraft:blackstone
setblock 24 282 301 minecraft:cobbled_deepslate
fill 24 282 304 26 282 304 minecraft:blackstone
setblock 24 282 305 minecraft:cobbled_deepslate
fill 24 282 306 24 282 308 minecraft:blackstone
setblock 24 282 309 minecraft:cobbled_deepslate
fill 24 282 310 24 282 312 minecraft:blackstone
setblock 24 282 313 minecraft:cobbled_deepslate
fill 24 282 314 24 282 316 minecraft:blackstone
fill 25 282 277 27 282 277 minecraft:blackstone
setblock 25 282 278 minecraft:cobbled_deepslate
fill 25 282 281 27 282 281 minecraft:blackstone
setblock 25 282 282 minecraft:cobbled_deepslate
fill 25 282 285 27 282 285 minecraft:blackstone
setblock 25 282 286 minecraft:cobbled_deepslate
fill 25 282 289 27 282 289 minecraft:blackstone
setblock 25 282 290 minecraft:cobbled_deepslate
fill 25 282 293 27 282 293 minecraft:blackstone
setblock 25 282 294 minecraft:cobbled_deepslate
fill 25 282 295 25 282 297 minecraft:blackstone
setblock 25 282 298 minecraft:cobbled_deepslate
fill 25 282 301 27 282 301 minecraft:blackstone
setblock 25 282 302 minecraft:cobbled_deepslate
fill 25 282 305 27 282 305 minecraft:blackstone
setblock 25 282 306 minecraft:cobbled_deepslate
fill 25 282 307 25 282 309 minecraft:blackstone
setblock 25 282 310 minecraft:cobbled_deepslate
fill 25 282 311 25 282 313 minecraft:blackstone
setblock 25 282 314 minecraft:cobbled_deepslate
fill 25 282 315 25 282 316 minecraft:blackstone
fill 26 282 278 28 282 278 minecraft:blackstone
setblock 26 282 279 minecraft:cobbled_deepslate
fill 26 282 282 28 282 282 minecraft:blackstone
setblock 26 282 283 minecraft:cobbled_deepslate
fill 26 282 286 28 282 286 minecraft:blackstone
setblock 26 282 287 minecraft:cobbled_deepslate
fill 26 282 290 28 282 290 minecraft:blackstone
setblock 26 282 291 minecraft:cobbled_deepslate
fill 26 282 294 28 282 294 minecraft:blackstone
setblock 26 282 295 minecraft:cobbled_deepslate
fill 26 282 296 26 282 298 minecraft:blackstone
setblock 26 282 299 minecraft:cobbled_deepslate
fill 26 282 302 28 282 302 minecraft:blackstone
setblock 26 282 303 minecraft:cobbled_deepslate
fill 26 282 306 28 282 306 minecraft:blackstone
setblock 26 282 307 minecraft:cobbled_deepslate
fill 26 282 308 26 282 310 minecraft:blackstone
setblock 26 282 311 minecraft:cobbled_deepslate
fill 26 282 312 26 282 314 minecraft:blackstone
setblock 26 282 315 minecraft:cobbled_deepslate
setblock 26 282 316 minecraft:blackstone
setblock 27 282 276 minecraft:cobbled_deepslate
fill 27 282 279 29 282 279 minecraft:blackstone
setblock 27 282 280 minecraft:cobbled_deepslate
fill 27 282 283 29 282 283 minecraft:blackstone
setblock 27 282 284 minecraft:cobbled_deepslate
fill 27 282 287 29 282 287 minecraft:blackstone
setblock 27 282 288 minecraft:cobbled_deepslate
fill 27 282 291 29 282 291 minecraft:blackstone
setblock 27 282 292 minecraft:cobbled_deepslate
fill 27 282 295 29 282 295 minecraft:blackstone
setblock 27 282 296 minecraft:cobbled_deepslate
fill 27 282 297 27 282 299 minecraft:blackstone
setblock 27 282 300 minecraft:cobbled_deepslate
fill 27 282 303 29 282 303 minecraft:blackstone
setblock 27 282 304 minecraft:cobbled_deepslate
fill 27 282 307 29 282 307 minecraft:blackstone
setblock 27 282 308 minecraft:cobbled_deepslate
fill 27 282 309 27 282 311 minecraft:blackstone
setblock 27 282 312 minecraft:cobbled_deepslate
fill 27 282 313 27 282 315 minecraft:blackstone
setblock 27 282 316 minecraft:cobbled_deepslate
fill 28 282 276 30 282 276 minecraft:blackstone
setblock 28 282 277 minecraft:cobbled_deepslate
fill 28 282 280 30 282 280 minecraft:blackstone
setblock 28 282 281 minecraft:cobbled_deepslate
fill 28 282 284 30 282 284 minecraft:blackstone
setblock 28 282 285 minecraft:cobbled_deepslate
fill 28 282 288 30 282 288 minecraft:blackstone
setblock 28 282 289 minecraft:cobbled_deepslate
fill 28 282 292 30 282 292 minecraft:blackstone
setblock 28 282 293 minecraft:cobbled_deepslate
fill 28 282 296 30 282 296 minecraft:blackstone
setblock 28 282 297 minecraft:cobbled_deepslate
fill 28 282 298 28 282 300 minecraft:blackstone
setblock 28 282 301 minecraft:cobbled_deepslate
fill 28 282 304 30 282 304 minecraft:blackstone
setblock 28 282 305 minecraft:cobbled_deepslate
fill 28 282 308 30 282 308 minecraft:blackstone
setblock 28 282 309 minecraft:cobbled_deepslate
fill 28 282 310 28 282 312 minecraft:blackstone
setblock 28 282 313 minecraft:cobbled_deepslate
fill 28 282 314 28 282 316 minecraft:blackstone
fill 29 282 277 31 282 277 minecraft:blackstone
setblock 29 282 278 minecraft:cobbled_deepslate
fill 29 282 281 31 282 281 minecraft:blackstone
setblock 29 282 282 minecraft:cobbled_deepslate
fill 29 282 285 31 282 285 minecraft:blackstone
setblock 29 282 286 minecraft:cobbled_deepslate
fill 29 282 289 31 282 289 minecraft:blackstone
setblock 29 282 290 minecraft:cobbled_deepslate
fill 29 282 293 31 282 293 minecraft:blackstone
setblock 29 282 294 minecraft:cobbled_deepslate
fill 29 282 297 31 282 297 minecraft:blackstone
setblock 29 282 298 minecraft:cobbled_deepslate
fill 29 282 299 29 282 301 minecraft:blackstone
setblock 29 282 302 minecraft:cobbled_deepslate
fill 29 282 305 31 282 305 minecraft:blackstone
setblock 29 282 306 minecraft:cobbled_deepslate
fill 29 282 309 31 282 309 minecraft:blackstone
setblock 29 282 310 minecraft:cobbled_deepslate
fill 29 282 311 29 282 313 minecraft:blackstone
setblock 29 282 314 minecraft:cobbled_deepslate
fill 29 282 315 29 282 316 minecraft:blackstone
fill 30 282 278 32 282 278 minecraft:blackstone
setblock 30 282 279 minecraft:cobbled_deepslate
fill 30 282 282 32 282 282 minecraft:blackstone
setblock 30 282 283 minecraft:cobbled_deepslate
fill 30 282 286 32 282 286 minecraft:blackstone
setblock 30 282 287 minecraft:cobbled_deepslate
fill 30 282 290 32 282 290 minecraft:blackstone
setblock 30 282 291 minecraft:cobbled_deepslate
fill 30 282 294 32 282 294 minecraft:blackstone
setblock 30 282 295 minecraft:cobbled_deepslate
fill 30 282 298 32 282 298 minecraft:blackstone
setblock 30 282 299 minecraft:cobbled_deepslate
fill 30 282 300 30 282 302 minecraft:blackstone
setblock 30 282 303 minecraft:cobbled_deepslate
fill 30 282 306 32 282 306 minecraft:blackstone
setblock 30 282 307 minecraft:cobbled_deepslate
fill 30 282 310 32 282 310 minecraft:blackstone
setblock 30 282 311 minecraft:cobbled_deepslate
fill 30 282 312 30 282 314 minecraft:blackstone
setblock 30 282 315 minecraft:cobbled_deepslate
setblock 30 282 316 minecraft:blackstone
setblock 31 282 276 minecraft:cobbled_deepslate
fill 31 282 279 33 282 279 minecraft:blackstone
setblock 31 282 280 minecraft:cobbled_deepslate
fill 31 282 283 33 282 283 minecraft:blackstone
setblock 31 282 284 minecraft:cobbled_deepslate
fill 31 282 287 33 282 287 minecraft:blackstone
setblock 31 282 288 minecraft:cobbled_deepslate
fill 31 282 291 33 282 291 minecraft:blackstone
setblock 31 282 292 minecraft:cobbled_deepslate
fill 31 282 295 33 282 295 minecraft:blackstone
setblock 31 282 296 minecraft:cobbled_deepslate
fill 31 282 299 33 282 299 minecraft:blackstone
setblock 31 282 300 minecraft:cobbled_deepslate
fill 31 282 301 31 282 303 minecraft:blackstone
setblock 31 282 304 minecraft:cobbled_deepslate
fill 31 282 307 33 282 307 minecraft:blackstone
setblock 31 282 308 minecraft:cobbled_deepslate
fill 31 282 311 33 282 311 minecraft:blackstone
setblock 31 282 312 minecraft:cobbled_deepslate
fill 31 282 313 31 282 315 minecraft:blackstone
setblock 31 282 316 minecraft:cobbled_deepslate
fill 32 282 276 34 282 276 minecraft:blackstone
setblock 32 282 277 minecraft:cobbled_deepslate
fill 32 282 280 34 282 280 minecraft:blackstone
setblock 32 282 281 minecraft:cobbled_deepslate
fill 32 282 284 34 282 284 minecraft:blackstone
setblock 32 282 285 minecraft:cobbled_deepslate
fill 32 282 288 34 282 288 minecraft:blackstone
setblock 32 282 289 minecraft:cobbled_deepslate
fill 32 282 292 34 282 292 minecraft:blackstone
setblock 32 282 293 minecraft:cobbled_deepslate
fill 32 282 296 34 282 296 minecraft:blackstone
setblock 32 282 297 minecraft:cobbled_deepslate
fill 32 282 300 34 282 300 minecraft:blackstone
setblock 32 282 301 minecraft:cobbled_deepslate
fill 32 282 302 32 282 304 minecraft:blackstone
setblock 32 282 305 minecraft:cobbled_deepslate
fill 32 282 308 34 282 308 minecraft:blackstone
setblock 32 282 309 minecraft:cobbled_deepslate
fill 32 282 312 34 282 312 minecraft:blackstone
setblock 32 282 313 minecraft:cobbled_deepslate
fill 32 282 314 32 282 316 minecraft:blackstone
fill 33 282 277 35 282 277 minecraft:blackstone
setblock 33 282 278 minecraft:cobbled_deepslate
fill 33 282 281 35 282 281 minecraft:blackstone
setblock 33 282 282 minecraft:cobbled_deepslate
fill 33 282 285 35 282 285 minecraft:blackstone
setblock 33 282 286 minecraft:cobbled_deepslate
fill 33 282 289 35 282 289 minecraft:blackstone
setblock 33 282 290 minecraft:cobbled_deepslate
fill 33 282 293 35 282 293 minecraft:blackstone
setblock 33 282 294 minecraft:cobbled_deepslate
fill 33 282 297 35 282 297 minecraft:blackstone
setblock 33 282 298 minecraft:cobbled_deepslate
fill 33 282 301 35 282 301 minecraft:blackstone
setblock 33 282 302 minecraft:cobbled_deepslate
fill 33 282 303 33 282 305 minecraft:blackstone
setblock 33 282 306 minecraft:cobbled_deepslate
fill 33 282 309 35 282 309 minecraft:blackstone
setblock 33 282 310 minecraft:cobbled_deepslate
fill 33 282 313 35 282 313 minecraft:blackstone
setblock 33 282 314 minecraft:cobbled_deepslate
fill 33 282 315 33 282 316 minecraft:blackstone
fill 34 282 278 36 282 278 minecraft:blackstone
setblock 34 282 279 minecraft:cobbled_deepslate
fill 34 282 282 36 282 282 minecraft:blackstone
setblock 34 282 283 minecraft:cobbled_deepslate
fill 34 282 286 36 282 286 minecraft:blackstone
setblock 34 282 287 minecraft:cobbled_deepslate
fill 34 282 290 36 282 290 minecraft:blackstone
setblock 34 282 291 minecraft:cobbled_deepslate
fill 34 282 294 36 282 294 minecraft:blackstone
setblock 34 282 295 minecraft:cobbled_deepslate
fill 34 282 298 36 282 298 minecraft:blackstone
setblock 34 282 299 minecraft:cobbled_deepslate
fill 34 282 302 36 282 302 minecraft:blackstone
setblock 34 282 303 minecraft:cobbled_deepslate
fill 34 282 304 34 282 306 minecraft:blackstone
setblock 34 282 307 minecraft:cobbled_deepslate
fill 34 282 310 36 282 310 minecraft:blackstone
setblock 34 282 311 minecraft:cobbled_deepslate
fill 34 282 314 36 282 314 minecraft:blackstone
setblock 34 282 315 minecraft:cobbled_deepslate
setblock 34 282 316 minecraft:blackstone
setblock 35 282 276 minecraft:cobbled_deepslate
fill 35 282 279 37 282 279 minecraft:blackstone
setblock 35 282 280 minecraft:cobbled_deepslate
fill 35 282 283 37 282 283 minecraft:blackstone
setblock 35 282 284 minecraft:cobbled_deepslate
fill 35 282 287 37 282 287 minecraft:blackstone
setblock 35 282 288 minecraft:cobbled_deepslate
fill 35 282 291 37 282 291 minecraft:blackstone
setblock 35 282 292 minecraft:cobbled_deepslate
fill 35 282 295 37 282 295 minecraft:blackstone
setblock 35 282 296 minecraft:cobbled_deepslate
fill 35 282 299 37 282 299 minecraft:blackstone
setblock 35 282 300 minecraft:cobbled_deepslate
fill 35 282 303 37 282 303 minecraft:blackstone
setblock 35 282 304 minecraft:cobbled_deepslate
fill 35 282 305 35 282 307 minecraft:blackstone
setblock 35 282 308 minecraft:cobbled_deepslate
fill 35 282 311 37 282 311 minecraft:blackstone
setblock 35 282 312 minecraft:cobbled_deepslate
fill 35 282 315 37 282 315 minecraft:blackstone
setblock 35 282 316 minecraft:cobbled_deepslate
fill 36 282 276 38 282 276 minecraft:blackstone
setblock 36 282 277 minecraft:cobbled_deepslate
fill 36 282 280 38 282 280 minecraft:blackstone
setblock 36 282 281 minecraft:cobbled_deepslate
fill 36 282 284 38 282 284 minecraft:blackstone
setblock 36 282 285 minecraft:cobbled_deepslate
fill 36 282 288 38 282 288 minecraft:blackstone
setblock 36 282 289 minecraft:cobbled_deepslate
fill 36 282 292 38 282 292 minecraft:blackstone
setblock 36 282 293 minecraft:cobbled_deepslate
fill 36 282 296 38 282 296 minecraft:blackstone
setblock 36 282 297 minecraft:cobbled_deepslate
fill 36 282 300 38 282 300 minecraft:blackstone
setblock 36 282 301 minecraft:cobbled_deepslate
fill 36 282 304 38 282 304 minecraft:blackstone
setblock 36 282 305 minecraft:cobbled_deepslate
fill 36 282 306 36 282 308 minecraft:blackstone
setblock 36 282 309 minecraft:cobbled_deepslate
fill 36 282 312 38 282 312 minecraft:blackstone
setblock 36 282 313 minecraft:cobbled_deepslate
fill 36 282 316 38 282 316 minecraft:blackstone
fill 37 282 277 39 282 277 minecraft:blackstone
setblock 37 282 278 minecraft:cobbled_deepslate
fill 37 282 281 39 282 281 minecraft:blackstone
setblock 37 282 282 minecraft:cobbled_deepslate
fill 37 282 285 39 282 285 minecraft:blackstone
setblock 37 282 286 minecraft:cobbled_deepslate
fill 37 282 289 39 282 289 minecraft:blackstone
setblock 37 282 290 minecraft:cobbled_deepslate
fill 37 282 293 39 282 293 minecraft:blackstone
setblock 37 282 294 minecraft:cobbled_deepslate
fill 37 282 297 39 282 297 minecraft:blackstone
setblock 37 282 298 minecraft:cobbled_deepslate
fill 37 282 301 39 282 301 minecraft:blackstone
setblock 37 282 302 minecraft:cobbled_deepslate
fill 37 282 305 39 282 305 minecraft:blackstone
setblock 37 282 306 minecraft:cobbled_deepslate
fill 37 282 307 37 282 309 minecraft:blackstone
setblock 37 282 310 minecraft:cobbled_deepslate
fill 37 282 313 39 282 313 minecraft:blackstone
setblock 37 282 314 minecraft:cobbled_deepslate
fill 38 282 278 38 283 278 minecraft:blackstone
setblock 38 282 279 minecraft:cobbled_deepslate
fill 38 282 282 38 283 282 minecraft:blackstone
setblock 38 282 283 minecraft:cobbled_deepslate
fill 38 282 286 38 283 286 minecraft:blackstone
setblock 38 282 287 minecraft:cobbled_deepslate
fill 38 282 290 38 283 290 minecraft:blackstone
setblock 38 282 291 minecraft:cobbled_deepslate
fill 38 282 294 38 283 294 minecraft:blackstone
setblock 38 282 295 minecraft:cobbled_deepslate
fill 38 282 298 38 283 298 minecraft:blackstone
setblock 38 282 299 minecraft:cobbled_deepslate
fill 38 282 302 38 283 302 minecraft:blackstone
setblock 38 282 303 minecraft:cobbled_deepslate
fill 38 282 306 38 283 306 minecraft:blackstone
setblock 38 282 307 minecraft:cobbled_deepslate
fill 38 282 308 38 282 310 minecraft:blackstone
setblock 38 282 311 minecraft:cobbled_deepslate
fill 38 282 314 40 282 314 minecraft:blackstone
setblock 38 282 315 minecraft:cobbled_deepslate
setblock 39 282 276 minecraft:cobbled_deepslate
fill 39 282 279 39 283 279 minecraft:blackstone
setblock 39 282 280 minecraft:cobbled_deepslate
fill 39 282 283 39 283 283 minecraft:blackstone
setblock 39 282 284 minecraft:cobbled_deepslate
fill 39 282 287 39 283 287 minecraft:blackstone
setblock 39 282 288 minecraft:cobbled_deepslate
fill 39 282 291 39 283 291 minecraft:blackstone
setblock 39 282 292 minecraft:cobbled_deepslate
fill 39 282 295 39 283 295 minecraft:blackstone
setblock 39 282 296 minecraft:cobbled_deepslate
fill 39 282 299 39 283 299 minecraft:blackstone
setblock 39 282 300 minecraft:cobbled_deepslate
fill 39 282 303 39 283 303 minecraft:blackstone
setblock 39 282 304 minecraft:cobbled_deepslate
fill 39 282 307 39 283 307 minecraft:blackstone
setblock 39 282 308 minecraft:cobbled_deepslate
setblock 39 282 309 minecraft:blackstone
fill 39 282 311 39 283 311 minecraft:blackstone
setblock 39 282 312 minecraft:cobbled_deepslate
fill 39 282 315 39 283 315 minecraft:blackstone
setblock 39 282 316 minecraft:cobbled_deepslate
fill 40 282 276 40 283 276 minecraft:blackstone
setblock 40 282 277 minecraft:cobbled_deepslate
setblock 40 282 278 minecraft:blackstone
fill 40 282 280 40 283 280 minecraft:blackstone
setblock 40 282 281 minecraft:cobbled_deepslate
setblock 40 282 282 minecraft:blackstone
fill 40 282 284 40 283 284 minecraft:blackstone
setblock 40 282 285 minecraft:cobbled_deepslate
setblock 40 282 286 minecraft:blackstone
fill 40 282 288 40 283 288 minecraft:blackstone
setblock 40 282 289 minecraft:cobbled_deepslate
setblock 40 282 290 minecraft:blackstone
fill 40 282 292 40 283 292 minecraft:blackstone
setblock 40 282 293 minecraft:cobbled_deepslate
setblock 40 282 294 minecraft:blackstone
fill 40 282 296 40 283 296 minecraft:blackstone
setblock 40 282 297 minecraft:cobbled_deepslate
setblock 40 282 298 minecraft:blackstone
fill 40 282 300 40 283 300 minecraft:blackstone
setblock 40 282 301 minecraft:cobbled_deepslate
setblock 40 282 302 minecraft:blackstone
fill 40 282 304 40 283 304 minecraft:blackstone
setblock 40 282 305 minecraft:cobbled_deepslate
setblock 40 282 306 minecraft:blackstone
fill 40 282 308 40 283 308 minecraft:blackstone
setblock 40 282 309 minecraft:cobbled_deepslate
setblock 40 282 310 minecraft:blackstone
fill 40 282 312 40 283 312 minecraft:blackstone
setblock 40 282 313 minecraft:cobbled_deepslate
fill 40 282 316 40 283 316 minecraft:blackstone
fill 41 282 277 41 283 277 minecraft:blackstone
setblock 41 282 278 minecraft:cobbled_deepslate
fill 41 282 281 41 283 281 minecraft:blackstone
setblock 41 282 282 minecraft:cobbled_deepslate
fill 41 282 285 41 283 285 minecraft:blackstone
setblock 41 282 286 minecraft:cobbled_deepslate
fill 41 282 289 41 283 289 minecraft:blackstone
setblock 41 282 290 minecraft:cobbled_deepslate
fill 41 282 293 41 283 293 minecraft:blackstone
setblock 41 282 294 minecraft:cobbled_deepslate
fill 41 282 297 41 283 297 minecraft:blackstone
setblock 41 282 298 minecraft:cobbled_deepslate
fill 41 282 301 41 283 301 minecraft:blackstone
setblock 41 282 302 minecraft:cobbled_deepslate
fill 41 282 305 41 283 305 minecraft:blackstone
setblock 41 282 306 minecraft:cobbled_deepslate
fill 41 282 309 41 283 309 minecraft:blackstone
setblock 41 282 310 minecraft:cobbled_deepslate
fill 41 282 313 41 283 313 minecraft:blackstone
setblock 41 282 314 minecraft:cobbled_deepslate
setblock 42 282 301 minecraft:crying_obsidian
fill 42 282 302 42 308 302 minecraft:deepslate_tiles
setblock 1 283 275 minecraft:crying_obsidian
fill 1 283 276 1 283 278 minecraft:blackstone
setblock 1 283 279 minecraft:cobbled_deepslate
fill 1 283 280 1 283 282 minecraft:blackstone
setblock 1 283 283 minecraft:cobbled_deepslate
fill 1 283 284 1 283 286 minecraft:blackstone
setblock 1 283 287 minecraft:cobbled_deepslate
fill 1 283 288 1 283 290 minecraft:blackstone
setblock 1 283 291 minecraft:cobbled_deepslate
fill 1 283 292 1 283 294 minecraft:blackstone
setblock 1 283 295 minecraft:cobbled_deepslate
fill 1 283 296 1 283 298 minecraft:blackstone
setblock 1 283 299 minecraft:cobbled_deepslate
fill 1 283 300 1 283 302 minecraft:blackstone
setblock 1 283 303 minecraft:cobbled_deepslate
fill 1 283 304 1 283 306 minecraft:blackstone
setblock 1 283 307 minecraft:cobbled_deepslate
fill 1 283 308 1 283 310 minecraft:blackstone
setblock 1 283 311 minecraft:cobbled_deepslate
fill 1 283 312 1 283 314 minecraft:blackstone
setblock 1 283 315 minecraft:cobbled_deepslate
setblock 1 283 316 minecraft:blackstone
fill 2 283 275 3 308 275 minecraft:deepslate_tiles
setblock 2 283 276 minecraft:cobbled_deepslate
fill 2 283 277 2 283 279 minecraft:blackstone
setblock 2 283 280 minecraft:cobbled_deepslate
fill 2 283 281 2 283 283 minecraft:blackstone
setblock 2 283 284 minecraft:cobbled_deepslate
fill 2 283 285 2 283 287 minecraft:blackstone
setblock 2 283 288 minecraft:cobbled_deepslate
fill 2 283 289 2 283 291 minecraft:blackstone
setblock 2 283 292 minecraft:cobbled_deepslate
fill 2 283 293 2 283 295 minecraft:blackstone
setblock 2 283 296 minecraft:cobbled_deepslate
fill 2 283 297 2 283 299 minecraft:blackstone
setblock 2 283 300 minecraft:cobbled_deepslate
fill 2 283 301 2 283 303 minecraft:blackstone
setblock 2 283 304 minecraft:cobbled_deepslate
fill 2 283 305 2 283 307 minecraft:blackstone
setblock 2 283 308 minecraft:cobbled_deepslate
fill 2 283 309 2 283 311 minecraft:blackstone
setblock 2 283 312 minecraft:cobbled_deepslate
fill 2 283 313 2 283 315 minecraft:blackstone
setblock 2 283 316 minecraft:cobbled_deepslate
fill 3 283 276 5 283 276 minecraft:blackstone
setblock 3 283 277 minecraft:cobbled_deepslate
fill 3 283 278 3 283 280 minecraft:blackstone
setblock 3 283 281 minecraft:cobbled_deepslate
fill 3 283 282 3 283 284 minecraft:blackstone
setblock 3 283 285 minecraft:cobbled_deepslate
fill 3 283 286 3 283 288 minecraft:blackstone
setblock 3 283 289 minecraft:cobbled_deepslate
fill 3 283 290 3 283 292 minecraft:blackstone
setblock 3 283 293 minecraft:cobbled_deepslate
fill 3 283 294 3 283 296 minecraft:blackstone
setblock 3 283 297 minecraft:cobbled_deepslate
fill 3 283 298 3 283 300 minecraft:blackstone
setblock 3 283 301 minecraft:cobbled_deepslate
fill 3 283 302 3 283 304 minecraft:blackstone
setblock 3 283 305 minecraft:cobbled_deepslate
fill 3 283 306 3 283 308 minecraft:blackstone
setblock 3 283 309 minecraft:cobbled_deepslate
fill 3 283 310 3 283 312 minecraft:blackstone
setblock 3 283 313 minecraft:cobbled_deepslate
fill 3 283 314 3 283 316 minecraft:blackstone
fill 4 283 277 6 283 277 minecraft:blackstone
setblock 4 283 278 minecraft:cobbled_deepslate
fill 4 283 279 4 283 281 minecraft:blackstone
setblock 4 283 282 minecraft:cobbled_deepslate
fill 4 283 283 4 283 285 minecraft:blackstone
setblock 4 283 286 minecraft:cobbled_deepslate
fill 4 283 287 4 283 289 minecraft:blackstone
setblock 4 283 290 minecraft:cobbled_deepslate
fill 4 283 291 4 283 293 minecraft:blackstone
setblock 4 283 294 minecraft:cobbled_deepslate
fill 4 283 295 4 283 297 minecraft:blackstone
setblock 4 283 298 minecraft:cobbled_deepslate
fill 4 283 299 4 283 301 minecraft:blackstone
setblock 4 283 302 minecraft:cobbled_deepslate
fill 4 283 303 4 283 305 minecraft:blackstone
setblock 4 283 306 minecraft:cobbled_deepslate
fill 4 283 307 4 283 309 minecraft:blackstone
setblock 4 283 310 minecraft:cobbled_deepslate
fill 4 283 311 4 283 313 minecraft:blackstone
setblock 4 283 314 minecraft:cobbled_deepslate
fill 4 283 315 4 283 316 minecraft:blackstone
fill 5 283 278 7 283 278 minecraft:blackstone
setblock 5 283 279 minecraft:cobbled_deepslate
fill 5 283 280 5 283 282 minecraft:blackstone
setblock 5 283 283 minecraft:cobbled_deepslate
fill 5 283 284 5 283 286 minecraft:blackstone
setblock 5 283 287 minecraft:cobbled_deepslate
fill 5 283 288 5 283 290 minecraft:blackstone
setblock 5 283 291 minecraft:cobbled_deepslate
fill 5 283 292 5 283 294 minecraft:blackstone
setblock 5 283 295 minecraft:cobbled_deepslate
fill 5 283 296 5 283 298 minecraft:blackstone
setblock 5 283 299 minecraft:cobbled_deepslate
fill 5 283 300 5 283 302 minecraft:blackstone
setblock 5 283 303 minecraft:cobbled_deepslate
fill 5 283 304 5 283 306 minecraft:blackstone
setblock 5 283 307 minecraft:cobbled_deepslate
fill 5 283 308 5 283 310 minecraft:blackstone
setblock 5 283 311 minecraft:cobbled_deepslate
fill 5 283 312 5 283 314 minecraft:blackstone
setblock 5 283 315 minecraft:cobbled_deepslate
setblock 5 283 316 minecraft:blackstone
setblock 6 283 276 minecraft:cobbled_deepslate
fill 6 283 279 8 283 279 minecraft:blackstone
setblock 6 283 280 minecraft:cobbled_deepslate
fill 6 283 281 6 283 283 minecraft:blackstone
setblock 6 283 284 minecraft:cobbled_deepslate
fill 6 283 285 6 283 287 minecraft:blackstone
setblock 6 283 288 minecraft:cobbled_deepslate
fill 6 283 289 6 283 291 minecraft:blackstone
setblock 6 283 292 minecraft:cobbled_deepslate
fill 6 283 293 6 283 295 minecraft:blackstone
setblock 6 283 296 minecraft:cobbled_deepslate
fill 6 283 297 6 283 299 minecraft:blackstone
setblock 6 283 300 minecraft:cobbled_deepslate
fill 6 283 301 6 283 303 minecraft:blackstone
setblock 6 283 304 minecraft:cobbled_deepslate
fill 6 283 305 6 283 307 minecraft:blackstone
setblock 6 283 308 minecraft:cobbled_deepslate
fill 6 283 309 6 283 311 minecraft:blackstone
setblock 6 283 312 minecraft:cobbled_deepslate
fill 6 283 313 6 283 315 minecraft:blackstone
setblock 6 283 316 minecraft:cobbled_deepslate
fill 7 283 276 9 283 276 minecraft:blackstone
setblock 7 283 277 minecraft:cobbled_deepslate
fill 7 283 280 9 283 280 minecraft:blackstone
setblock 7 283 281 minecraft:cobbled_deepslate
fill 7 283 282 7 283 284 minecraft:blackstone
setblock 7 283 285 minecraft:cobbled_deepslate
fill 7 283 286 7 283 288 minecraft:blackstone
setblock 7 283 289 minecraft:cobbled_deepslate
fill 7 283 290 7 283 292 minecraft:blackstone
setblock 7 283 293 minecraft:cobbled_deepslate
fill 7 283 294 7 283 296 minecraft:blackstone
setblock 7 283 297 minecraft:cobbled_deepslate
fill 7 283 298 7 283 300 minecraft:blackstone
setblock 7 283 301 minecraft:cobbled_deepslate
fill 7 283 302 7 283 304 minecraft:blackstone
setblock 7 283 305 minecraft:cobbled_deepslate
fill 7 283 306 7 283 308 minecraft:blackstone
setblock 7 283 309 minecraft:cobbled_deepslate
fill 7 283 310 7 283 312 minecraft:blackstone
setblock 7 283 313 minecraft:cobbled_deepslate
fill 7 283 314 7 283 316 minecraft:blackstone
fill 8 283 277 10 283 277 minecraft:blackstone
setblock 8 283 278 minecraft:cobbled_deepslate
fill 8 283 281 10 283 281 minecraft:blackstone
setblock 8 283 282 minecraft:cobbled_deepslate
fill 8 283 283 8 283 285 minecraft:blackstone
setblock 8 283 286 minecraft:cobbled_deepslate
fill 8 283 287 8 283 289 minecraft:blackstone
setblock 8 283 290 minecraft:cobbled_deepslate
fill 8 283 291 8 283 293 minecraft:blackstone
setblock 8 283 294 minecraft:cobbled_deepslate
fill 8 283 295 8 283 297 minecraft:blackstone
setblock 8 283 298 minecraft:cobbled_deepslate
fill 8 283 299 8 283 301 minecraft:blackstone
setblock 8 283 302 minecraft:cobbled_deepslate
fill 8 283 303 8 283 305 minecraft:blackstone
setblock 8 283 306 minecraft:cobbled_deepslate
fill 8 283 307 8 283 309 minecraft:blackstone
setblock 8 283 310 minecraft:cobbled_deepslate
fill 8 283 311 8 283 313 minecraft:blackstone
setblock 8 283 314 minecraft:cobbled_deepslate
fill 8 283 315 8 283 316 minecraft:blackstone
fill 9 283 278 11 283 278 minecraft:blackstone
setblock 9 283 279 minecraft:cobbled_deepslate
fill 9 283 282 11 283 282 minecraft:blackstone
setblock 9 283 283 minecraft:cobbled_deepslate
fill 9 283 284 9 283 286 minecraft:blackstone
setblock 9 283 287 minecraft:cobbled_deepslate
fill 9 283 288 9 283 290 minecraft:blackstone
setblock 9 283 291 minecraft:cobbled_deepslate
fill 9 283 292 9 283 294 minecraft:blackstone
setblock 9 283 295 minecraft:cobbled_deepslate
fill 9 283 296 9 283 298 minecraft:blackstone
setblock 9 283 299 minecraft:cobbled_deepslate
fill 9 283 300 9 283 302 minecraft:blackstone
setblock 9 283 303 minecraft:cobbled_deepslate
fill 9 283 304 9 283 306 minecraft:blackstone
setblock 9 283 307 minecraft:cobbled_deepslate
fill 9 283 308 9 283 310 minecraft:blackstone
setblock 9 283 311 minecraft:cobbled_deepslate
fill 9 283 312 9 283 314 minecraft:blackstone
setblock 9 283 315 minecraft:cobbled_deepslate
setblock 9 283 316 minecraft:blackstone
setblock 10 283 276 minecraft:cobbled_deepslate
fill 10 283 279 12 283 279 minecraft:blackstone
setblock 10 283 280 minecraft:cobbled_deepslate
fill 10 283 283 12 283 283 minecraft:blackstone
setblock 10 283 284 minecraft:cobbled_deepslate
fill 10 283 285 10 283 287 minecraft:blackstone
setblock 10 283 288 minecraft:cobbled_deepslate
fill 10 283 289 10 283 291 minecraft:blackstone
setblock 10 283 292 minecraft:cobbled_deepslate
fill 10 283 293 10 283 295 minecraft:blackstone
setblock 10 283 296 minecraft:cobbled_deepslate
fill 10 283 297 10 283 299 minecraft:blackstone
setblock 10 283 300 minecraft:cobbled_deepslate
fill 10 283 301 10 283 303 minecraft:blackstone
setblock 10 283 304 minecraft:cobbled_deepslate
fill 10 283 305 10 283 307 minecraft:blackstone
setblock 10 283 308 minecraft:cobbled_deepslate
fill 10 283 309 10 283 311 minecraft:blackstone
setblock 10 283 312 minecraft:cobbled_deepslate
fill 10 283 313 10 283 315 minecraft:blackstone
setblock 10 283 316 minecraft:cobbled_deepslate
setblock 11 283 275 minecraft:amethyst_block
fill 11 283 276 13 283 276 minecraft:blackstone
setblock 11 283 277 minecraft:cobbled_deepslate
fill 11 283 280 13 283 280 minecraft:blackstone
setblock 11 283 281 minecraft:cobbled_deepslate
fill 11 283 284 13 283 284 minecraft:blackstone
setblock 11 283 285 minecraft:cobbled_deepslate
fill 11 283 286 11 283 288 minecraft:blackstone
setblock 11 283 289 minecraft:cobbled_deepslate
fill 11 283 290 11 283 292 minecraft:blackstone
setblock 11 283 293 minecraft:cobbled_deepslate
fill 11 283 294 11 283 296 minecraft:blackstone
setblock 11 283 297 minecraft:cobbled_deepslate
fill 11 283 298 11 283 300 minecraft:blackstone
setblock 11 283 301 minecraft:cobbled_deepslate
fill 11 283 302 11 283 304 minecraft:blackstone
setblock 11 283 305 minecraft:cobbled_deepslate
fill 11 283 306 11 283 308 minecraft:blackstone
setblock 11 283 309 minecraft:cobbled_deepslate
fill 11 283 310 11 283 312 minecraft:blackstone
setblock 11 283 313 minecraft:cobbled_deepslate
fill 11 283 314 11 283 316 minecraft:blackstone
fill 12 283 277 14 283 277 minecraft:blackstone
setblock 12 283 278 minecraft:cobbled_deepslate
fill 12 283 281 14 283 281 minecraft:blackstone
setblock 12 283 282 minecraft:cobbled_deepslate
fill 12 283 285 14 283 285 minecraft:blackstone
setblock 12 283 286 minecraft:cobbled_deepslate
fill 12 283 287 12 283 289 minecraft:blackstone
setblock 12 283 290 minecraft:cobbled_deepslate
fill 12 283 291 12 283 293 minecraft:blackstone
setblock 12 283 294 minecraft:cobbled_deepslate
fill 12 283 295 12 283 297 minecraft:blackstone
setblock 12 283 298 minecraft:cobbled_deepslate
fill 12 283 299 12 283 301 minecraft:blackstone
setblock 12 283 302 minecraft:cobbled_deepslate
fill 12 283 303 12 283 305 minecraft:blackstone
setblock 12 283 306 minecraft:cobbled_deepslate
fill 12 283 307 12 283 309 minecraft:blackstone
setblock 12 283 310 minecraft:cobbled_deepslate
fill 12 283 311 12 283 313 minecraft:blackstone
setblock 12 283 314 minecraft:cobbled_deepslate
fill 12 283 315 12 283 316 minecraft:blackstone
fill 13 283 278 15 283 278 minecraft:blackstone
setblock 13 283 279 minecraft:cobbled_deepslate
fill 13 283 282 15 283 282 minecraft:blackstone
setblock 13 283 283 minecraft:cobbled_deepslate
fill 13 283 286 15 283 286 minecraft:blackstone
setblock 13 283 287 minecraft:cobbled_deepslate
fill 13 283 288 13 283 290 minecraft:blackstone
setblock 13 283 291 minecraft:cobbled_deepslate
fill 13 283 292 13 283 294 minecraft:blackstone
setblock 13 283 295 minecraft:cobbled_deepslate
fill 13 283 296 13 283 298 minecraft:blackstone
setblock 13 283 299 minecraft:cobbled_deepslate
fill 13 283 300 13 283 302 minecraft:blackstone
setblock 13 283 303 minecraft:cobbled_deepslate
fill 13 283 304 13 283 306 minecraft:blackstone
setblock 13 283 307 minecraft:cobbled_deepslate
fill 13 283 308 13 283 310 minecraft:blackstone
setblock 13 283 311 minecraft:cobbled_deepslate
fill 13 283 312 13 283 314 minecraft:blackstone
setblock 13 283 315 minecraft:cobbled_deepslate
setblock 13 283 316 minecraft:blackstone
setblock 14 283 276 minecraft:cobbled_deepslate
fill 14 283 279 16 283 279 minecraft:blackstone
setblock 14 283 280 minecraft:cobbled_deepslate
fill 14 283 283 16 283 283 minecraft:blackstone
setblock 14 283 284 minecraft:cobbled_deepslate
fill 14 283 287 16 283 287 minecraft:blackstone
setblock 14 283 288 minecraft:cobbled_deepslate
fill 14 283 289 14 283 291 minecraft:blackstone
setblock 14 283 292 minecraft:cobbled_deepslate
fill 14 283 293 14 283 295 minecraft:blackstone
setblock 14 283 296 minecraft:cobbled_deepslate
fill 14 283 297 14 283 299 minecraft:blackstone
setblock 14 283 300 minecraft:cobbled_deepslate
fill 14 283 301 14 283 303 minecraft:blackstone
setblock 14 283 304 minecraft:cobbled_deepslate
fill 14 283 305 14 283 307 minecraft:blackstone
setblock 14 283 308 minecraft:cobbled_deepslate
fill 14 283 309 14 283 311 minecraft:blackstone
setblock 14 283 312 minecraft:cobbled_deepslate
fill 14 283 313 14 283 315 minecraft:blackstone
setblock 14 283 316 minecraft:cobbled_deepslate
fill 15 283 276 17 283 276 minecraft:blackstone
setblock 15 283 277 minecraft:cobbled_deepslate
fill 15 283 280 17 283 280 minecraft:blackstone
setblock 15 283 281 minecraft:cobbled_deepslate
fill 15 283 284 17 283 284 minecraft:blackstone
setblock 15 283 285 minecraft:cobbled_deepslate
fill 15 283 288 17 283 288 minecraft:blackstone
setblock 15 283 289 minecraft:cobbled_deepslate
fill 15 283 290 15 283 292 minecraft:blackstone
setblock 15 283 293 minecraft:cobbled_deepslate
fill 15 283 294 15 283 296 minecraft:blackstone
setblock 15 283 297 minecraft:cobbled_deepslate
fill 15 283 298 15 283 300 minecraft:blackstone
setblock 15 283 301 minecraft:cobbled_deepslate
fill 15 283 302 15 283 304 minecraft:blackstone
setblock 15 283 305 minecraft:cobbled_deepslate
fill 15 283 306 15 283 308 minecraft:blackstone
setblock 15 283 309 minecraft:cobbled_deepslate
fill 15 283 310 15 283 312 minecraft:blackstone
setblock 15 283 313 minecraft:cobbled_deepslate
fill 15 283 314 15 283 316 minecraft:blackstone
fill 16 283 277 18 283 277 minecraft:blackstone
setblock 16 283 278 minecraft:cobbled_deepslate
fill 16 283 281 18 283 281 minecraft:blackstone
setblock 16 283 282 minecraft:cobbled_deepslate
fill 16 283 285 18 283 285 minecraft:blackstone
setblock 16 283 286 minecraft:cobbled_deepslate
fill 16 283 289 18 283 289 minecraft:blackstone
setblock 16 283 290 minecraft:cobbled_deepslate
setblock 16 283 291 minecraft:blackstone
setblock 16 283 293 minecraft:blackstone
fill 16 283 294 16 283 296 minecraft:magma_block
setblock 16 283 297 minecraft:blackstone
setblock 16 283 298 minecraft:cobbled_deepslate
fill 16 283 299 16 283 301 minecraft:blackstone
setblock 16 283 302 minecraft:cobbled_deepslate
fill 16 283 303 16 283 305 minecraft:blackstone
setblock 16 283 306 minecraft:cobbled_deepslate
fill 16 283 307 16 283 309 minecraft:blackstone
setblock 16 283 310 minecraft:cobbled_deepslate
fill 16 283 311 16 283 313 minecraft:blackstone
setblock 16 283 314 minecraft:cobbled_deepslate
fill 16 283 315 16 283 316 minecraft:blackstone
setblock 17 283 275 minecraft:amethyst_block
fill 17 283 278 19 283 278 minecraft:blackstone
setblock 17 283 279 minecraft:cobbled_deepslate
fill 17 283 282 19 283 282 minecraft:blackstone
setblock 17 283 283 minecraft:cobbled_deepslate
fill 17 283 286 19 283 286 minecraft:blackstone
setblock 17 283 287 minecraft:cobbled_deepslate
fill 17 283 290 19 283 290 minecraft:blackstone
setblock 17 283 291 minecraft:cobbled_deepslate
fill 17 283 292 17 283 294 minecraft:magma_block
fill 17 283 296 17 283 298 minecraft:magma_block
setblock 17 283 299 minecraft:cobbled_deepslate
fill 17 283 300 17 283 302 minecraft:blackstone
setblock 17 283 303 minecraft:cobbled_deepslate
fill 17 283 304 17 283 306 minecraft:blackstone
setblock 17 283 307 minecraft:cobbled_deepslate
fill 17 283 308 17 283 310 minecraft:blackstone
setblock 17 283 311 minecraft:cobbled_deepslate
fill 17 283 312 17 283 314 minecraft:blackstone
setblock 17 283 315 minecraft:cobbled_deepslate
setblock 17 283 316 minecraft:blackstone
setblock 18 283 276 minecraft:cobbled_deepslate
fill 18 283 279 20 283 279 minecraft:blackstone
setblock 18 283 280 minecraft:cobbled_deepslate
fill 18 283 283 20 283 283 minecraft:blackstone
setblock 18 283 284 minecraft:cobbled_deepslate
fill 18 283 287 20 283 287 minecraft:blackstone
setblock 18 283 288 minecraft:cobbled_deepslate
setblock 18 283 291 minecraft:blackstone
fill 18 283 292 19 283 292 minecraft:magma_block
fill 18 283 298 19 283 298 minecraft:magma_block
setblock 18 283 299 minecraft:blackstone
setblock 18 283 300 minecraft:cobbled_deepslate
fill 18 283 301 18 283 303 minecraft:blackstone
setblock 18 283 304 minecraft:cobbled_deepslate
fill 18 283 305 18 283 307 minecraft:blackstone
setblock 18 283 308 minecraft:cobbled_deepslate
fill 18 283 309 18 283 311 minecraft:blackstone
setblock 18 283 312 minecraft:cobbled_deepslate
fill 18 283 313 18 283 315 minecraft:blackstone
setblock 18 283 316 minecraft:cobbled_deepslate
fill 19 283 276 21 283 276 minecraft:blackstone
setblock 19 283 277 minecraft:cobbled_deepslate
fill 19 283 280 21 283 280 minecraft:blackstone
setblock 19 283 281 minecraft:cobbled_deepslate
fill 19 283 284 21 283 284 minecraft:blackstone
setblock 19 283 285 minecraft:cobbled_deepslate
fill 19 283 288 21 283 288 minecraft:blackstone
setblock 19 283 289 minecraft:cobbled_deepslate
fill 19 283 291 21 283 291 minecraft:magma_block
fill 19 283 299 21 283 299 minecraft:magma_block
fill 19 283 300 21 283 300 minecraft:blackstone
setblock 19 283 301 minecraft:cobbled_deepslate
fill 19 283 302 19 283 304 minecraft:blackstone
setblock 19 283 305 minecraft:cobbled_deepslate
fill 19 283 306 19 283 308 minecraft:blackstone
setblock 19 283 309 minecraft:cobbled_deepslate
fill 19 283 310 19 283 312 minecraft:blackstone
setblock 19 283 313 minecraft:cobbled_deepslate
fill 19 283 314 19 283 316 minecraft:blackstone
fill 20 283 277 22 283 277 minecraft:blackstone
setblock 20 283 278 minecraft:cobbled_deepslate
fill 20 283 281 22 283 281 minecraft:blackstone
setblock 20 283 282 minecraft:cobbled_deepslate
fill 20 283 285 22 283 285 minecraft:blackstone
setblock 20 283 286 minecraft:cobbled_deepslate
fill 20 283 289 22 283 289 minecraft:blackstone
setblock 20 283 290 minecraft:cobbled_deepslate
fill 20 283 301 22 283 301 minecraft:blackstone
setblock 20 283 302 minecraft:cobbled_deepslate
fill 20 283 303 20 283 305 minecraft:blackstone
setblock 20 283 306 minecraft:cobbled_deepslate
fill 20 283 307 20 283 309 minecraft:blackstone
setblock 20 283 310 minecraft:cobbled_deepslate
fill 20 283 311 20 283 313 minecraft:blackstone
setblock 20 283 314 minecraft:cobbled_deepslate
fill 20 283 315 20 283 316 minecraft:blackstone
fill 21 283 278 23 283 278 minecraft:blackstone
setblock 21 283 279 minecraft:cobbled_deepslate
fill 21 283 282 23 283 282 minecraft:blackstone
setblock 21 283 283 minecraft:cobbled_deepslate
fill 21 283 286 23 283 286 minecraft:blackstone
setblock 21 283 287 minecraft:cobbled_deepslate
fill 21 283 290 23 283 290 minecraft:blackstone
fill 21 283 292 23 283 292 minecraft:magma_block
fill 21 283 298 23 283 298 minecraft:magma_block
fill 21 283 302 23 283 302 minecraft:blackstone
setblock 21 283 303 minecraft:cobbled_deepslate
fill 21 283 304 21 283 306 minecraft:blackstone
setblock 21 283 307 minecraft:cobbled_deepslate
fill 21 283 308 21 283 310 minecraft:blackstone
setblock 21 283 311 minecraft:cobbled_deepslate
fill 21 283 312 21 283 314 minecraft:blackstone
setblock 21 283 315 minecraft:cobbled_deepslate
setblock 21 283 316 minecraft:blackstone
setblock 22 283 276 minecraft:cobbled_deepslate
fill 22 283 279 24 283 279 minecraft:blackstone
setblock 22 283 280 minecraft:cobbled_deepslate
fill 22 283 283 24 283 283 minecraft:blackstone
setblock 22 283 284 minecraft:cobbled_deepslate
fill 22 283 287 24 283 287 minecraft:blackstone
setblock 22 283 288 minecraft:cobbled_deepslate
fill 22 283 291 24 283 291 minecraft:blackstone
fill 22 283 299 24 283 299 minecraft:blackstone
setblock 22 283 300 minecraft:cobbled_deepslate
fill 22 283 303 24 283 303 minecraft:blackstone
setblock 22 283 304 minecraft:cobbled_deepslate
fill 22 283 305 22 283 307 minecraft:blackstone
setblock 22 283 308 minecraft:cobbled_deepslate
fill 22 283 309 22 283 311 minecraft:blackstone
setblock 22 283 312 minecraft:cobbled_deepslate
fill 22 283 313 22 283 315 minecraft:blackstone
setblock 22 283 316 minecraft:cobbled_deepslate
fill 23 283 276 25 283 276 minecraft:blackstone
setblock 23 283 277 minecraft:cobbled_deepslate
fill 23 283 280 25 283 280 minecraft:blackstone
setblock 23 283 281 minecraft:cobbled_deepslate
fill 23 283 284 25 283 284 minecraft:blackstone
setblock 23 283 285 minecraft:cobbled_deepslate
fill 23 283 288 25 283 288 minecraft:blackstone
setblock 23 283 289 minecraft:cobbled_deepslate
fill 23 283 293 23 283 294 minecraft:magma_block
fill 23 283 296 23 283 297 minecraft:magma_block
fill 23 283 300 25 283 300 minecraft:blackstone
setblock 23 283 301 minecraft:cobbled_deepslate
fill 23 283 304 25 283 304 minecraft:blackstone
setblock 23 283 305 minecraft:cobbled_deepslate
fill 23 283 306 23 283 308 minecraft:blackstone
setblock 23 283 309 minecraft:cobbled_deepslate
fill 23 283 310 23 283 312 minecraft:blackstone
setblock 23 283 313 minecraft:cobbled_deepslate
fill 23 283 314 23 283 316 minecraft:blackstone
fill 24 283 277 26 283 277 minecraft:blackstone
setblock 24 283 278 minecraft:cobbled_deepslate
fill 24 283 281 26 283 281 minecraft:blackstone
setblock 24 283 282 minecraft:cobbled_deepslate
fill 24 283 285 26 283 285 minecraft:blackstone
setblock 24 283 286 minecraft:cobbled_deepslate
fill 24 283 289 26 283 289 minecraft:blackstone
setblock 24 283 290 minecraft:cobbled_deepslate
fill 24 283 292 25 283 293 minecraft:blackstone
fill 24 283 294 24 283 296 minecraft:magma_block
fill 24 283 297 26 283 297 minecraft:blackstone
setblock 24 283 298 minecraft:cobbled_deepslate
fill 24 283 301 26 283 301 minecraft:blackstone
setblock 24 283 302 minecraft:cobbled_deepslate
fill 24 283 305 26 283 305 minecraft:blackstone
setblock 24 283 306 minecraft:cobbled_deepslate
fill 24 283 307 24 283 309 minecraft:blackstone
setblock 24 283 310 minecraft:cobbled_deepslate
fill 24 283 311 24 283 313 minecraft:blackstone
setblock 24 283 314 minecraft:cobbled_deepslate
fill 24 283 315 24 283 316 minecraft:blackstone
fill 25 283 278 27 283 278 minecraft:blackstone
setblock 25 283 279 minecraft:cobbled_deepslate
fill 25 283 282 27 283 282 minecraft:blackstone
setblock 25 283 283 minecraft:cobbled_deepslate
fill 25 283 286 27 283 286 minecraft:blackstone
setblock 25 283 287 minecraft:cobbled_deepslate
fill 25 283 290 27 283 290 minecraft:blackstone
setblock 25 283 291 minecraft:cobbled_deepslate
fill 25 283 294 27 283 294 minecraft:blackstone
setblock 25 283 295 minecraft:cobbled_deepslate
setblock 25 283 296 minecraft:blackstone
fill 25 283 298 27 283 298 minecraft:blackstone
setblock 25 283 299 minecraft:cobbled_deepslate
fill 25 283 302 27 283 302 minecraft:blackstone
setblock 25 283 303 minecraft:cobbled_deepslate
fill 25 283 306 27 283 306 minecraft:blackstone
setblock 25 283 307 minecraft:cobbled_deepslate
fill 25 283 308 25 283 310 minecraft:blackstone
setblock 25 283 311 minecraft:cobbled_deepslate
fill 25 283 312 25 283 314 minecraft:blackstone
setblock 25 283 315 minecraft:cobbled_deepslate
setblock 25 283 316 minecraft:blackstone
setblock 26 283 276 minecraft:cobbled_deepslate
fill 26 283 279 28 283 279 minecraft:blackstone
setblock 26 283 280 minecraft:cobbled_deepslate
fill 26 283 283 28 283 283 minecraft:blackstone
setblock 26 283 284 minecraft:cobbled_deepslate
fill 26 283 287 28 283 287 minecraft:blackstone
setblock 26 283 288 minecraft:cobbled_deepslate
fill 26 283 291 28 283 291 minecraft:blackstone
setblock 26 283 292 minecraft:cobbled_deepslate
setblock 26 283 293 minecraft:blackstone
fill 26 283 295 28 283 295 minecraft:blackstone
setblock 26 283 296 minecraft:cobbled_deepslate
fill 26 283 299 28 283 299 minecraft:blackstone
setblock 26 283 300 minecraft:cobbled_deepslate
fill 26 283 303 28 283 303 minecraft:blackstone
setblock 26 283 304 minecraft:cobbled_deepslate
fill 26 283 307 28 283 307 minecraft:blackstone
setblock 26 283 308 minecraft:cobbled_deepslate
fill 26 283 309 26 283 311 minecraft:blackstone
setblock 26 283 312 minecraft:cobbled_deepslate
fill 26 283 313 26 283 315 minecraft:blackstone
setblock 26 283 316 minecraft:cobbled_deepslate
fill 27 283 276 29 283 276 minecraft:blackstone
setblock 27 283 277 minecraft:cobbled_deepslate
fill 27 283 280 29 283 280 minecraft:blackstone
setblock 27 283 281 minecraft:cobbled_deepslate
fill 27 283 284 29 283 284 minecraft:blackstone
setblock 27 283 285 minecraft:cobbled_deepslate
fill 27 283 288 29 283 288 minecraft:blackstone
setblock 27 283 289 minecraft:cobbled_deepslate
fill 27 283 292 29 283 292 minecraft:blackstone
setblock 27 283 293 minecraft:cobbled_deepslate
fill 27 283 296 29 283 296 minecraft:blackstone
setblock 27 283 297 minecraft:cobbled_deepslate
fill 27 283 300 29 283 300 minecraft:blackstone
setblock 27 283 301 minecraft:cobbled_deepslate
fill 27 283 304 29 283 304 minecraft:blackstone
setblock 27 283 305 minecraft:cobbled_deepslate
fill 27 283 308 29 283 308 minecraft:blackstone
setblock 27 283 309 minecraft:cobbled_deepslate
fill 27 283 310 27 283 312 minecraft:blackstone
setblock 27 283 313 minecraft:cobbled_deepslate
fill 27 283 314 27 283 316 minecraft:blackstone
fill 28 283 277 30 283 277 minecraft:blackstone
setblock 28 283 278 minecraft:cobbled_deepslate
fill 28 283 281 30 283 281 minecraft:blackstone
setblock 28 283 282 minecraft:cobbled_deepslate
fill 28 283 285 30 283 285 minecraft:blackstone
setblock 28 283 286 minecraft:cobbled_deepslate
fill 28 283 289 30 283 289 minecraft:blackstone
setblock 28 283 290 minecraft:cobbled_deepslate
fill 28 283 293 30 283 293 minecraft:blackstone
setblock 28 283 294 minecraft:cobbled_deepslate
fill 28 283 297 30 283 297 minecraft:blackstone
setblock 28 283 298 minecraft:cobbled_deepslate
fill 28 283 301 30 283 301 minecraft:blackstone
setblock 28 283 302 minecraft:cobbled_deepslate
fill 28 283 305 30 283 305 minecraft:blackstone
setblock 28 283 306 minecraft:cobbled_deepslate
fill 28 283 309 30 283 309 minecraft:blackstone
setblock 28 283 310 minecraft:cobbled_deepslate
fill 28 283 311 28 283 313 minecraft:blackstone
setblock 28 283 314 minecraft:cobbled_deepslate
fill 28 283 315 28 283 316 minecraft:blackstone
fill 29 283 278 31 283 278 minecraft:blackstone
setblock 29 283 279 minecraft:cobbled_deepslate
fill 29 283 282 31 283 282 minecraft:blackstone
setblock 29 283 283 minecraft:cobbled_deepslate
fill 29 283 286 31 283 286 minecraft:blackstone
setblock 29 283 287 minecraft:cobbled_deepslate
fill 29 283 290 31 283 290 minecraft:blackstone
setblock 29 283 291 minecraft:cobbled_deepslate
fill 29 283 294 31 283 294 minecraft:blackstone
setblock 29 283 295 minecraft:cobbled_deepslate
fill 29 283 298 31 283 298 minecraft:blackstone
setblock 29 283 299 minecraft:cobbled_deepslate
fill 29 283 302 31 283 302 minecraft:blackstone
setblock 29 283 303 minecraft:cobbled_deepslate
fill 29 283 306 31 283 306 minecraft:blackstone
setblock 29 283 307 minecraft:cobbled_deepslate
fill 29 283 310 31 283 310 minecraft:blackstone
setblock 29 283 311 minecraft:cobbled_deepslate
fill 29 283 312 29 283 314 minecraft:blackstone
setblock 29 283 315 minecraft:cobbled_deepslate
setblock 29 283 316 minecraft:blackstone
setblock 30 283 276 minecraft:cobbled_deepslate
fill 30 283 279 32 283 279 minecraft:blackstone
setblock 30 283 280 minecraft:cobbled_deepslate
fill 30 283 283 32 283 283 minecraft:blackstone
setblock 30 283 284 minecraft:cobbled_deepslate
fill 30 283 287 32 283 287 minecraft:blackstone
setblock 30 283 288 minecraft:cobbled_deepslate
fill 30 283 291 32 283 291 minecraft:blackstone
setblock 30 283 292 minecraft:cobbled_deepslate
fill 30 283 295 32 283 295 minecraft:blackstone
setblock 30 283 296 minecraft:cobbled_deepslate
fill 30 283 299 32 283 299 minecraft:blackstone
setblock 30 283 300 minecraft:cobbled_deepslate
fill 30 283 303 32 283 303 minecraft:blackstone
setblock 30 283 304 minecraft:cobbled_deepslate
fill 30 283 307 32 283 307 minecraft:blackstone
setblock 30 283 308 minecraft:cobbled_deepslate
fill 30 283 311 32 283 311 minecraft:blackstone
setblock 30 283 312 minecraft:cobbled_deepslate
fill 30 283 313 30 283 315 minecraft:blackstone
setblock 30 283 316 minecraft:cobbled_deepslate
fill 31 283 276 33 283 276 minecraft:blackstone
setblock 31 283 277 minecraft:cobbled_deepslate
fill 31 283 280 33 283 280 minecraft:blackstone
setblock 31 283 281 minecraft:cobbled_deepslate
fill 31 283 284 33 283 284 minecraft:blackstone
setblock 31 283 285 minecraft:cobbled_deepslate
fill 31 283 288 33 283 288 minecraft:blackstone
setblock 31 283 289 minecraft:cobbled_deepslate
fill 31 283 292 33 283 292 minecraft:blackstone
setblock 31 283 293 minecraft:cobbled_deepslate
fill 31 283 296 33 283 296 minecraft:blackstone
setblock 31 283 297 minecraft:cobbled_deepslate
fill 31 283 300 33 283 300 minecraft:blackstone
setblock 31 283 301 minecraft:cobbled_deepslate
fill 31 283 304 33 283 304 minecraft:blackstone
setblock 31 283 305 minecraft:cobbled_deepslate
fill 31 283 308 33 283 308 minecraft:blackstone
setblock 31 283 309 minecraft:cobbled_deepslate
fill 31 283 312 33 283 312 minecraft:blackstone
setblock 31 283 313 minecraft:cobbled_deepslate
fill 31 283 314 31 283 316 minecraft:blackstone
fill 32 283 277 34 283 277 minecraft:blackstone
setblock 32 283 278 minecraft:cobbled_deepslate
fill 32 283 281 34 283 281 minecraft:blackstone
setblock 32 283 282 minecraft:cobbled_deepslate
fill 32 283 285 34 283 285 minecraft:blackstone
setblock 32 283 286 minecraft:cobbled_deepslate
fill 32 283 289 34 283 289 minecraft:blackstone
setblock 32 283 290 minecraft:cobbled_deepslate
fill 32 283 293 34 283 293 minecraft:blackstone
setblock 32 283 294 minecraft:cobbled_deepslate
fill 32 283 297 34 283 297 minecraft:blackstone
setblock 32 283 298 minecraft:cobbled_deepslate
fill 32 283 301 34 283 301 minecraft:blackstone
setblock 32 283 302 minecraft:cobbled_deepslate
fill 32 283 305 34 283 305 minecraft:blackstone
setblock 32 283 306 minecraft:cobbled_deepslate
fill 32 283 309 34 283 309 minecraft:blackstone
setblock 32 283 310 minecraft:cobbled_deepslate
fill 32 283 313 34 283 313 minecraft:blackstone
setblock 32 283 314 minecraft:cobbled_deepslate
fill 32 283 315 32 283 316 minecraft:blackstone
fill 33 283 278 35 283 278 minecraft:blackstone
setblock 33 283 279 minecraft:cobbled_deepslate
fill 33 283 282 35 283 282 minecraft:blackstone
setblock 33 283 283 minecraft:cobbled_deepslate
fill 33 283 286 35 283 286 minecraft:blackstone
setblock 33 283 287 minecraft:cobbled_deepslate
fill 33 283 290 35 283 290 minecraft:blackstone
setblock 33 283 291 minecraft:cobbled_deepslate
fill 33 283 294 35 283 294 minecraft:blackstone
setblock 33 283 295 minecraft:cobbled_deepslate
fill 33 283 298 35 283 298 minecraft:blackstone
setblock 33 283 299 minecraft:cobbled_deepslate
fill 33 283 302 35 283 302 minecraft:blackstone
setblock 33 283 303 minecraft:cobbled_deepslate
fill 33 283 306 35 283 306 minecraft:blackstone
setblock 33 283 307 minecraft:cobbled_deepslate
fill 33 283 310 35 283 310 minecraft:blackstone
setblock 33 283 311 minecraft:cobbled_deepslate
fill 33 283 314 35 283 314 minecraft:blackstone
setblock 33 283 315 minecraft:cobbled_deepslate
setblock 33 283 316 minecraft:blackstone
setblock 34 283 276 minecraft:cobbled_deepslate
fill 34 283 279 36 283 279 minecraft:blackstone
setblock 34 283 280 minecraft:cobbled_deepslate
fill 34 283 283 36 283 283 minecraft:blackstone
setblock 34 283 284 minecraft:cobbled_deepslate
fill 34 283 287 36 283 287 minecraft:blackstone
setblock 34 283 288 minecraft:cobbled_deepslate
fill 34 283 291 36 283 291 minecraft:blackstone
setblock 34 283 292 minecraft:cobbled_deepslate
fill 34 283 295 36 283 295 minecraft:blackstone
setblock 34 283 296 minecraft:cobbled_deepslate
fill 34 283 299 36 283 299 minecraft:blackstone
setblock 34 283 300 minecraft:cobbled_deepslate
fill 34 283 303 36 283 303 minecraft:blackstone
setblock 34 283 304 minecraft:cobbled_deepslate
fill 34 283 307 36 283 307 minecraft:blackstone
setblock 34 283 308 minecraft:cobbled_deepslate
fill 34 283 311 36 283 311 minecraft:blackstone
setblock 34 283 312 minecraft:cobbled_deepslate
fill 34 283 315 36 283 315 minecraft:blackstone
setblock 34 283 316 minecraft:cobbled_deepslate
fill 35 283 276 37 283 276 minecraft:blackstone
setblock 35 283 277 minecraft:cobbled_deepslate
fill 35 283 280 37 283 280 minecraft:blackstone
setblock 35 283 281 minecraft:cobbled_deepslate
fill 35 283 284 37 283 284 minecraft:blackstone
setblock 35 283 285 minecraft:cobbled_deepslate
fill 35 283 288 37 283 288 minecraft:blackstone
setblock 35 283 289 minecraft:cobbled_deepslate
fill 35 283 292 37 283 292 minecraft:blackstone
setblock 35 283 293 minecraft:cobbled_deepslate
fill 35 283 296 37 283 296 minecraft:blackstone
setblock 35 283 297 minecraft:cobbled_deepslate
fill 35 283 300 37 283 300 minecraft:blackstone
setblock 35 283 301 minecraft:cobbled_deepslate
fill 35 283 304 37 283 304 minecraft:blackstone
setblock 35 283 305 minecraft:cobbled_deepslate
fill 35 283 308 37 283 308 minecraft:blackstone
setblock 35 283 309 minecraft:cobbled_deepslate
fill 35 283 312 37 283 312 minecraft:blackstone
setblock 35 283 313 minecraft:cobbled_deepslate
fill 35 283 316 37 283 316 minecraft:blackstone
fill 36 283 277 38 283 277 minecraft:blackstone
setblock 36 283 278 minecraft:cobbled_deepslate
fill 36 283 281 38 283 281 minecraft:blackstone
setblock 36 283 282 minecraft:cobbled_deepslate
fill 36 283 285 38 283 285 minecraft:blackstone
setblock 36 283 286 minecraft:cobbled_deepslate
fill 36 283 289 38 283 289 minecraft:blackstone
setblock 36 283 290 minecraft:cobbled_deepslate
fill 36 283 293 38 283 293 minecraft:blackstone
setblock 36 283 294 minecraft:cobbled_deepslate
fill 36 283 297 38 283 297 minecraft:blackstone
setblock 36 283 298 minecraft:cobbled_deepslate
fill 36 283 301 38 283 301 minecraft:blackstone
setblock 36 283 302 minecraft:cobbled_deepslate
fill 36 283 305 38 283 305 minecraft:blackstone
setblock 36 283 306 minecraft:cobbled_deepslate
fill 36 283 309 38 283 309 minecraft:blackstone
setblock 36 283 310 minecraft:cobbled_deepslate
fill 36 283 313 38 283 313 minecraft:blackstone
setblock 36 283 314 minecraft:cobbled_deepslate
setblock 37 283 278 minecraft:blackstone
schedule function dropper:buildpart/60_7 1t
