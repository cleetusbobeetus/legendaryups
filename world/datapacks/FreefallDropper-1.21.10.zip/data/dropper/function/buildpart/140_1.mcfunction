setblock 400 70 599 minecraft:purple_concrete
fill 401 70 557 402 71 557 minecraft:purple_concrete
fill 402 70 599 402 75 599 minecraft:black_concrete
fill 407 70 557 408 75 557 minecraft:black_concrete
fill 408 70 599 409 71 599 minecraft:purple_concrete
fill 409 70 557 410 70 557 minecraft:purple_concrete
fill 410 70 599 411 75 599 minecraft:black_concrete
fill 411 70 557 411 71 557 minecraft:black_concrete
fill 418 70 558 418 75 559 minecraft:black_concrete
fill 418 70 560 418 71 561 minecraft:purple_concrete
fill 418 70 567 418 75 567 minecraft:black_concrete
fill 418 70 568 418 70 569 minecraft:purple_concrete
fill 418 70 570 418 71 571 minecraft:black_concrete
fill 418 70 572 418 71 572 minecraft:purple_concrete
fill 418 70 578 418 75 579 minecraft:black_concrete
fill 418 70 580 418 71 581 minecraft:purple_concrete
setblock 418 70 589 minecraft:purple_concrete
fill 418 70 590 418 75 591 minecraft:black_concrete
fill 418 70 592 418 71 593 minecraft:purple_concrete
fill 418 70 598 418 75 598 minecraft:black_concrete
setblock 376 71 559 minecraft:purple_concrete
fill 376 71 560 376 74 560 minecraft:black_concrete
fill 376 71 571 376 74 571 minecraft:black_concrete
setblock 376 71 576 minecraft:purple_concrete
setblock 376 71 587 minecraft:purple_concrete
fill 376 71 591 376 74 592 minecraft:black_concrete
fill 377 71 557 378 74 557 minecraft:black_concrete
setblock 382 71 557 minecraft:purple_concrete
setblock 385 71 599 minecraft:purple_concrete
setblock 388 71 599 minecraft:purple_concrete
fill 389 71 599 389 74 599 minecraft:black_concrete
setblock 393 71 557 minecraft:purple_concrete
fill 396 71 565 396 72 565 minecraft:amethyst_block
setblock 396 71 599 minecraft:purple_concrete
fill 398 71 557 398 74 557 minecraft:black_concrete
fill 400 71 599 400 74 599 minecraft:black_concrete
fill 409 71 557 409 74 557 minecraft:black_concrete
setblock 410 71 557 minecraft:purple_concrete
fill 413 71 557 414 71 557 minecraft:purple_concrete
fill 416 71 599 417 71 599 minecraft:purple_concrete
fill 418 71 568 418 73 569 minecraft:black_concrete
setblock 418 71 573 minecraft:purple_concrete
setblock 418 71 584 minecraft:purple_concrete
fill 418 71 589 418 74 589 minecraft:black_concrete
setblock 376 72 557 minecraft:purple_concrete
fill 376 72 559 376 77 559 minecraft:black_concrete
fill 376 72 565 376 73 566 minecraft:purple_concrete
fill 376 72 567 376 77 568 minecraft:black_concrete
fill 376 72 576 376 77 576 minecraft:black_concrete
fill 376 72 577 376 72 578 minecraft:purple_concrete
fill 376 72 579 376 77 580 minecraft:black_concrete
fill 376 72 585 376 73 586 minecraft:purple_concrete
fill 376 72 587 376 77 588 minecraft:black_concrete
setblock 376 72 589 minecraft:purple_concrete
fill 376 72 597 376 73 598 minecraft:purple_concrete
fill 376 72 599 377 77 599 minecraft:black_concrete
fill 377 72 558 379 72 558 minecraft:obsidian
fill 377 72 560 377 72 562 minecraft:obsidian
fill 377 72 564 377 72 566 minecraft:obsidian
fill 377 72 568 377 72 570 minecraft:obsidian
fill 377 72 572 377 72 574 minecraft:obsidian
fill 377 72 576 377 72 578 minecraft:obsidian
fill 377 72 580 377 72 582 minecraft:obsidian
fill 377 72 584 377 72 586 minecraft:obsidian
fill 377 72 588 377 72 590 minecraft:obsidian
fill 377 72 592 377 72 594 minecraft:obsidian
fill 377 72 596 377 72 598 minecraft:obsidian
fill 379 72 598 381 72 598 minecraft:obsidian
setblock 380 72 557 minecraft:purple_concrete
fill 381 72 557 382 77 557 minecraft:black_concrete
fill 381 72 558 383 72 558 minecraft:obsidian
fill 383 72 557 384 73 557 minecraft:purple_concrete
fill 383 72 598 385 72 598 minecraft:obsidian
fill 383 72 599 383 73 599 minecraft:purple_concrete
fill 385 72 558 387 72 558 minecraft:obsidian
fill 385 72 599 385 77 599 minecraft:black_concrete
fill 386 72 599 387 72 599 minecraft:purple_concrete
fill 387 72 598 389 72 598 minecraft:obsidian
fill 388 72 599 388 77 599 minecraft:black_concrete
fill 389 72 557 390 77 557 minecraft:black_concrete
fill 389 72 558 391 72 558 minecraft:obsidian
fill 391 72 557 392 72 557 minecraft:purple_concrete
fill 391 72 598 393 72 598 minecraft:obsidian
fill 393 72 557 393 77 557 minecraft:black_concrete
fill 393 72 558 395 72 558 minecraft:obsidian
fill 393 72 592 393 81 592 minecraft:obsidian
fill 394 72 599 395 73 599 minecraft:purple_concrete
fill 395 72 598 397 72 598 minecraft:obsidian
fill 396 72 599 397 77 599 minecraft:black_concrete
fill 397 72 558 399 72 558 minecraft:obsidian
fill 399 72 598 401 72 598 minecraft:obsidian
fill 401 72 557 402 77 557 minecraft:black_concrete
fill 401 72 558 403 72 558 minecraft:obsidian
fill 403 72 557 404 73 557 minecraft:purple_concrete
fill 403 72 598 405 72 598 minecraft:obsidian
fill 405 72 558 407 72 558 minecraft:obsidian
fill 406 72 599 407 72 599 minecraft:purple_concrete
fill 407 72 598 409 72 598 minecraft:obsidian
fill 408 72 599 409 77 599 minecraft:black_concrete
fill 409 72 558 411 72 558 minecraft:obsidian
fill 410 72 557 410 77 557 minecraft:black_concrete
fill 411 72 557 412 72 557 minecraft:purple_concrete
fill 411 72 598 413 72 598 minecraft:obsidian
fill 413 72 557 414 73 557 minecraft:black_concrete
fill 413 72 558 415 72 558 minecraft:obsidian
fill 415 72 557 415 73 557 minecraft:purple_concrete
fill 415 72 598 417 72 598 minecraft:obsidian
fill 415 72 599 415 73 599 minecraft:purple_concrete
fill 416 72 599 417 77 599 minecraft:black_concrete
fill 417 72 558 417 72 560 minecraft:obsidian
fill 417 72 562 417 72 564 minecraft:obsidian
fill 417 72 566 417 72 568 minecraft:obsidian
fill 417 72 570 417 72 572 minecraft:obsidian
fill 417 72 574 417 72 576 minecraft:obsidian
fill 417 72 578 417 72 580 minecraft:obsidian
fill 417 72 582 417 72 584 minecraft:obsidian
fill 417 72 586 417 72 588 minecraft:obsidian
fill 417 72 590 417 72 592 minecraft:obsidian
fill 417 72 594 417 72 596 minecraft:obsidian
fill 418 72 560 418 77 561 minecraft:black_concrete
fill 418 72 562 418 73 563 minecraft:purple_concrete
fill 418 72 570 418 75 570 minecraft:black_concrete
setblock 418 72 571 minecraft:purple_concrete
fill 418 72 572 418 77 573 minecraft:black_concrete
fill 418 72 574 418 73 575 minecraft:purple_concrete
fill 418 72 580 418 74 581 minecraft:black_concrete
fill 418 72 582 418 72 583 minecraft:purple_concrete
fill 418 72 584 418 77 584 minecraft:black_concrete
fill 418 72 592 418 77 593 minecraft:black_concrete
fill 418 72 594 418 73 595 minecraft:purple_concrete
setblock 418 72 599 minecraft:purple_concrete
fill 376 73 557 376 76 557 minecraft:black_concrete
fill 376 73 573 376 73 574 minecraft:purple_concrete
setblock 376 73 577 minecraft:purple_concrete
fill 376 73 578 376 76 578 minecraft:black_concrete
fill 376 73 589 376 76 589 minecraft:black_concrete
setblock 376 73 594 minecraft:purple_concrete
fill 380 73 557 380 76 557 minecraft:black_concrete
setblock 382 73 599 minecraft:purple_concrete
fill 386 73 599 387 76 599 minecraft:black_concrete
fill 391 73 557 391 76 557 minecraft:black_concrete
setblock 392 73 557 minecraft:purple_concrete
fill 393 73 593 393 81 593 minecraft:obsidian
fill 395 73 557 396 73 557 minecraft:purple_concrete
fill 396 73 565 396 80 565 minecraft:obsidian
setblock 403 73 599 minecraft:purple_concrete
setblock 406 73 599 minecraft:purple_concrete
fill 407 73 599 407 76 599 minecraft:black_concrete
fill 411 73 557 412 75 557 minecraft:black_concrete
setblock 414 73 599 minecraft:purple_concrete
setblock 416 73 557 minecraft:purple_concrete
setblock 418 73 566 minecraft:purple_concrete
fill 418 73 571 418 75 571 minecraft:black_concrete
fill 418 73 582 418 76 582 minecraft:black_concrete
setblock 418 73 583 minecraft:purple_concrete
fill 418 73 586 418 73 587 minecraft:purple_concrete
fill 418 73 599 418 76 599 minecraft:black_concrete
fill 376 74 563 376 74 564 minecraft:purple_concrete
fill 376 74 565 376 79 566 minecraft:black_concrete
fill 376 74 572 376 75 572 minecraft:purple_concrete
fill 376 74 573 376 79 574 minecraft:black_concrete
setblock 376 74 575 minecraft:purple_concrete
fill 376 74 577 376 79 577 minecraft:black_concrete
fill 376 74 583 376 75 584 minecraft:purple_concrete
fill 376 74 585 376 79 586 minecraft:black_concrete
fill 376 74 594 376 79 594 minecraft:black_concrete
fill 376 74 595 376 74 596 minecraft:purple_concrete
fill 376 74 597 376 79 598 minecraft:black_concrete
fill 380 74 599 381 75 599 minecraft:purple_concrete
fill 382 74 599 383 79 599 minecraft:black_concrete
fill 383 74 557 384 79 557 minecraft:black_concrete
setblock 384 74 599 minecraft:purple_concrete
fill 385 74 557 386 75 557 minecraft:purple_concrete
fill 392 74 557 392 79 557 minecraft:black_concrete
fill 392 74 592 392 81 593 minecraft:obsidian
fill 392 74 599 393 75 599 minecraft:purple_concrete
setblock 394 74 557 minecraft:purple_concrete
fill 394 74 592 394 81 593 minecraft:obsidian
fill 394 74 599 395 79 599 minecraft:black_concrete
fill 395 74 557 396 79 557 minecraft:black_concrete
fill 397 74 557 397 75 557 minecraft:purple_concrete
fill 401 74 599 401 75 599 minecraft:purple_concrete
fill 403 74 557 404 79 557 minecraft:black_concrete
fill 403 74 599 403 79 599 minecraft:black_concrete
fill 404 74 599 405 74 599 minecraft:purple_concrete
fill 405 74 557 406 74 557 minecraft:purple_concrete
fill 406 74 599 406 79 599 minecraft:black_concrete
fill 412 74 599 413 75 599 minecraft:purple_concrete
fill 413 74 557 413 77 557 minecraft:black_concrete
setblock 414 74 557 minecraft:purple_concrete
fill 414 74 599 415 79 599 minecraft:black_concrete
fill 415 74 557 416 79 557 minecraft:black_concrete
fill 417 74 557 418 75 557 minecraft:purple_concrete
fill 418 74 562 418 76 563 minecraft:black_concrete
fill 418 74 564 418 74 565 minecraft:purple_concrete
fill 418 74 566 418 79 566 minecraft:black_concrete
fill 418 74 568 418 75 568 minecraft:purple_concrete
setblock 418 74 569 minecraft:black_concrete
fill 418 74 574 418 79 575 minecraft:black_concrete
fill 418 74 576 418 75 577 minecraft:purple_concrete
fill 418 74 583 418 76 583 minecraft:black_concrete
setblock 418 74 585 minecraft:purple_concrete
fill 418 74 586 418 79 587 minecraft:black_concrete
fill 418 74 588 418 75 588 minecraft:purple_concrete
fill 418 74 594 418 79 595 minecraft:black_concrete
fill 418 74 596 418 74 597 minecraft:purple_concrete
setblock 376 75 560 minecraft:purple_concrete
setblock 376 75 563 minecraft:purple_concrete
fill 376 75 564 376 78 564 minecraft:black_concrete
setblock 376 75 571 minecraft:purple_concrete
fill 376 75 575 376 78 575 minecraft:black_concrete
fill 376 75 591 376 75 592 minecraft:purple_concrete
setblock 376 75 595 minecraft:purple_concrete
fill 376 75 596 376 78 596 minecraft:black_concrete
fill 377 75 557 378 75 557 minecraft:purple_concrete
fill 384 75 599 384 78 599 minecraft:black_concrete
setblock 389 75 599 minecraft:purple_concrete
fill 392 75 591 394 81 591 minecraft:obsidian
fill 393 75 594 393 81 594 minecraft:obsidian
fill 394 75 557 394 78 557 minecraft:black_concrete
fill 395 75 565 395 80 565 minecraft:obsidian
fill 396 75 564 396 80 564 minecraft:obsidian
fill 396 75 566 396 80 566 minecraft:obsidian
fill 397 75 565 397 80 565 minecraft:obsidian
setblock 398 75 557 minecraft:purple_concrete
setblock 400 75 599 minecraft:purple_concrete
fill 404 75 599 405 78 599 minecraft:black_concrete
fill 405 75 557 405 78 557 minecraft:black_concrete
setblock 406 75 557 minecraft:purple_concrete
setblock 409 75 557 minecraft:purple_concrete
fill 414 75 557 414 77 557 minecraft:black_concrete
fill 418 75 564 418 78 564 minecraft:black_concrete
setblock 418 75 565 minecraft:purple_concrete
setblock 418 75 569 minecraft:purple_concrete
setblock 418 75 580 minecraft:purple_concrete
fill 418 75 581 418 77 581 minecraft:black_concrete
fill 418 75 585 418 78 585 minecraft:black_concrete
setblock 418 75 589 minecraft:purple_concrete
fill 418 75 596 418 78 596 minecraft:black_concrete
setblock 418 75 597 minecraft:purple_concrete
fill 376 76 558 376 77 558 minecraft:purple_concrete
fill 376 76 560 376 81 560 minecraft:black_concrete
fill 376 76 561 376 76 562 minecraft:purple_concrete
fill 376 76 563 376 81 563 minecraft:black_concrete
fill 376 76 569 376 77 570 minecraft:purple_concrete
fill 376 76 571 376 81 572 minecraft:black_concrete
fill 376 76 581 376 76 582 minecraft:purple_concrete
fill 376 76 583 376 81 584 minecraft:black_concrete
fill 376 76 590 376 77 590 minecraft:purple_concrete
fill 376 76 591 376 81 592 minecraft:black_concrete
setblock 376 76 593 minecraft:purple_concrete
fill 376 76 595 376 81 595 minecraft:black_concrete
fill 377 76 557 378 81 557 minecraft:black_concrete
fill 378 76 599 379 77 599 minecraft:purple_concrete
fill 379 76 557 379 77 557 minecraft:purple_concrete
fill 380 76 599 381 81 599 minecraft:black_concrete
fill 385 76 557 386 81 557 minecraft:black_concrete
fill 387 76 557 388 76 557 minecraft:purple_concrete
fill 389 76 599 389 81 599 minecraft:black_concrete
fill 390 76 599 391 76 599 minecraft:purple_concrete
fill 391 76 592 391 81 593 minecraft:obsidian
fill 392 76 594 392 81 594 minecraft:obsidian
fill 392 76 599 393 81 599 minecraft:black_concrete
fill 394 76 594 394 81 594 minecraft:obsidian
fill 395 76 564 395 80 564 minecraft:obsidian
fill 395 76 566 395 80 566 minecraft:obsidian
fill 395 76 592 395 81 593 minecraft:obsidian
fill 397 76 557 398 81 557 minecraft:black_concrete
fill 397 76 564 397 80 564 minecraft:obsidian
fill 397 76 566 397 80 566 minecraft:obsidian
fill 398 76 599 399 77 599 minecraft:purple_concrete
fill 399 76 557 400 77 557 minecraft:purple_concrete
fill 400 76 599 401 81 599 minecraft:black_concrete
setblock 402 76 599 minecraft:purple_concrete
fill 406 76 557 406 81 557 minecraft:black_concrete
fill 407 76 557 408 76 557 minecraft:purple_concrete
fill 409 76 557 409 81 557 minecraft:black_concrete
fill 410 76 599 411 77 599 minecraft:purple_concrete
fill 411 76 557 411 77 557 minecraft:purple_concrete
setblock 412 76 557 minecraft:black_concrete
fill 412 76 599 413 81 599 minecraft:black_concrete
fill 417 76 557 418 81 557 minecraft:black_concrete
fill 418 76 558 418 77 559 minecraft:purple_concrete
fill 418 76 565 418 78 565 minecraft:black_concrete
setblock 418 76 567 minecraft:purple_concrete
fill 418 76 568 418 81 569 minecraft:black_concrete
fill 418 76 570 418 77 571 minecraft:purple_concrete
fill 418 76 576 418 81 577 minecraft:black_concrete
fill 418 76 578 418 76 579 minecraft:purple_concrete
fill 418 76 580 418 77 580 minecraft:black_concrete
fill 418 76 588 418 81 589 minecraft:black_concrete
fill 418 76 590 418 77 591 minecraft:purple_concrete
fill 418 76 597 418 81 597 minecraft:black_concrete
setblock 418 76 598 minecraft:purple_concrete
setblock 376 77 557 minecraft:purple_concrete
fill 376 77 561 376 80 562 minecraft:black_concrete
setblock 376 77 578 minecraft:purple_concrete
setblock 376 77 581 minecraft:purple_concrete
fill 376 77 582 376 80 582 minecraft:black_concrete
setblock 376 77 589 minecraft:purple_concrete
fill 376 77 593 376 80 593 minecraft:black_concrete
setblock 379 77 560 minecraft:light[level=12]
setblock 379 77 568 minecraft:light[level=12]
setblock 379 77 576 minecraft:light[level=12]
setblock 379 77 584 minecraft:light[level=12]
setblock 379 77 592 minecraft:light[level=12]
setblock 380 77 557 minecraft:purple_concrete
fill 386 77 599 387 77 599 minecraft:purple_concrete
fill 387 77 557 387 80 557 minecraft:black_concrete
setblock 387 77 560 minecraft:light[level=12]
setblock 387 77 568 minecraft:light[level=12]
setblock 387 77 576 minecraft:light[level=12]
setblock 387 77 584 minecraft:light[level=12]
setblock 387 77 592 minecraft:light[level=12]
setblock 388 77 557 minecraft:purple_concrete
setblock 390 77 599 minecraft:purple_concrete
setblock 391 77 557 minecraft:purple_concrete
fill 391 77 591 391 81 591 minecraft:obsidian
fill 391 77 594 391 81 594 minecraft:obsidian
fill 391 77 599 391 80 599 minecraft:black_concrete
fill 392 77 590 394 81 590 minecraft:obsidian
fill 393 77 595 393 81 595 minecraft:obsidian
fill 394 77 565 394 80 566 minecraft:obsidian
setblock 395 77 560 minecraft:light[level=12]
fill 395 77 567 396 80 567 minecraft:obsidian
setblock 395 77 568 minecraft:light[level=12]
setblock 395 77 576 minecraft:light[level=12]
setblock 395 77 584 minecraft:light[level=12]
fill 395 77 591 395 81 591 minecraft:obsidian
fill 395 77 594 395 81 594 minecraft:obsidian
fill 396 77 563 396 80 563 minecraft:obsidian
fill 398 77 565 398 80 565 minecraft:obsidian
fill 402 77 599 402 80 599 minecraft:black_concrete
setblock 403 77 560 minecraft:light[level=12]
setblock 403 77 568 minecraft:light[level=12]
setblock 403 77 576 minecraft:light[level=12]
setblock 403 77 584 minecraft:light[level=12]
setblock 403 77 592 minecraft:light[level=12]
fill 405 77 568 406 78 569 minecraft:obsidian
fill 406 77 570 406 78 570 minecraft:obsidian
fill 407 77 557 408 80 557 minecraft:black_concrete
setblock 407 77 599 minecraft:purple_concrete
setblock 411 77 560 minecraft:light[level=12]
setblock 411 77 568 minecraft:light[level=12]
setblock 411 77 576 minecraft:light[level=12]
setblock 411 77 584 minecraft:light[level=12]
setblock 411 77 592 minecraft:light[level=12]
setblock 412 77 557 minecraft:purple_concrete
setblock 418 77 562 minecraft:purple_concrete
fill 418 77 563 418 79 563 minecraft:black_concrete
fill 418 77 567 418 80 567 minecraft:black_concrete
fill 418 77 578 418 80 578 minecraft:black_concrete
setblock 418 77 579 minecraft:purple_concrete
fill 418 77 582 418 77 583 minecraft:purple_concrete
fill 418 77 598 418 80 598 minecraft:black_concrete
setblock 418 77 599 minecraft:purple_concrete
fill 376 78 557 376 83 558 minecraft:black_concrete
setblock 376 78 559 minecraft:purple_concrete
fill 376 78 567 376 79 568 minecraft:purple_concrete
fill 376 78 569 376 83 570 minecraft:black_concrete
fill 376 78 576 376 79 576 minecraft:purple_concrete
fill 376 78 578 376 83 578 minecraft:black_concrete
fill 376 78 579 376 78 580 minecraft:purple_concrete
fill 376 78 581 376 83 581 minecraft:black_concrete
fill 376 78 587 376 79 588 minecraft:purple_concrete
fill 376 78 589 376 83 590 minecraft:black_concrete
fill 376 78 599 377 78 599 minecraft:purple_concrete
fill 377 78 558 379 78 558 minecraft:obsidian
fill 377 78 560 377 78 562 minecraft:obsidian
fill 377 78 564 377 78 566 minecraft:obsidian
fill 377 78 568 377 78 570 minecraft:obsidian
fill 377 78 572 377 78 574 minecraft:obsidian
fill 377 78 576 377 78 578 minecraft:obsidian
fill 377 78 580 377 78 582 minecraft:obsidian
fill 377 78 584 377 78 586 minecraft:obsidian
fill 377 78 588 377 78 590 minecraft:obsidian
fill 377 78 592 377 78 594 minecraft:obsidian
fill 377 78 596 377 78 598 minecraft:obsidian
fill 378 78 599 379 83 599 minecraft:black_concrete
fill 379 78 557 380 83 557 minecraft:black_concrete
fill 379 78 598 381 78 598 minecraft:obsidian
fill 381 78 557 382 79 557 minecraft:purple_concrete
fill 381 78 558 383 78 558 minecraft:obsidian
fill 383 78 598 385 78 598 minecraft:obsidian
fill 385 78 558 387 78 558 minecraft:obsidian
fill 385 78 599 385 79 599 minecraft:purple_concrete
fill 386 78 599 387 83 599 minecraft:black_concrete
fill 387 78 598 389 78 598 minecraft:obsidian
fill 388 78 557 388 83 557 minecraft:black_concrete
setblock 388 78 599 minecraft:purple_concrete
fill 389 78 557 390 78 557 minecraft:purple_concrete
fill 389 78 558 391 78 558 minecraft:obsidian
fill 390 78 592 390 81 593 minecraft:obsidian
fill 390 78 599 390 83 599 minecraft:black_concrete
fill 391 78 557 391 83 557 minecraft:black_concrete
fill 391 78 590 391 81 590 minecraft:obsidian
fill 391 78 598 393 78 598 minecraft:obsidian
fill 392 78 595 392 81 595 minecraft:obsidian
fill 393 78 557 393 79 557 minecraft:purple_concrete
fill 393 78 558 395 78 558 minecraft:obsidian
fill 394 78 564 394 80 564 minecraft:obsidian
fill 394 78 595 394 81 595 minecraft:obsidian
fill 395 78 563 395 80 563 minecraft:obsidian
fill 395 78 590 395 81 590 minecraft:obsidian
fill 395 78 598 397 78 598 minecraft:obsidian
fill 396 78 592 396 81 593 minecraft:obsidian
fill 396 78 599 397 79 599 minecraft:purple_concrete
fill 397 78 558 399 78 558 minecraft:obsidian
fill 397 78 563 397 80 563 minecraft:obsidian
fill 397 78 567 397 80 567 minecraft:obsidian
fill 398 78 564 398 80 564 minecraft:obsidian
fill 398 78 566 398 80 566 minecraft:obsidian
fill 398 78 599 399 83 599 minecraft:black_concrete
fill 399 78 557 400 83 557 minecraft:black_concrete
fill 399 78 598 401 78 598 minecraft:obsidian
fill 401 78 557 402 79 557 minecraft:purple_concrete
fill 401 78 558 403 78 558 minecraft:obsidian
fill 403 78 598 405 78 598 minecraft:obsidian
fill 405 78 558 407 78 558 minecraft:obsidian
fill 407 78 598 409 78 598 minecraft:obsidian
fill 407 78 599 407 83 599 minecraft:black_concrete
fill 408 78 599 409 78 599 minecraft:purple_concrete
fill 409 78 558 411 78 558 minecraft:obsidian
setblock 410 78 557 minecraft:purple_concrete
fill 410 78 599 411 83 599 minecraft:black_concrete
fill 411 78 557 412 83 557 minecraft:black_concrete
fill 411 78 598 413 78 598 minecraft:obsidian
fill 413 78 557 414 79 557 minecraft:purple_concrete
fill 413 78 558 415 78 558 minecraft:obsidian
fill 415 78 598 417 78 598 minecraft:obsidian
fill 416 78 599 417 79 599 minecraft:purple_concrete
fill 417 78 558 417 78 560 minecraft:obsidian
fill 417 78 562 417 78 564 minecraft:obsidian
fill 417 78 566 417 78 568 minecraft:obsidian
fill 417 78 570 417 78 572 minecraft:obsidian
fill 417 78 574 417 78 576 minecraft:obsidian
fill 417 78 578 417 78 580 minecraft:obsidian
fill 417 78 582 417 78 584 minecraft:obsidian
fill 417 78 586 417 78 588 minecraft:obsidian
fill 417 78 590 417 78 592 minecraft:obsidian
fill 417 78 594 417 78 596 minecraft:obsidian
fill 418 78 558 418 83 559 minecraft:black_concrete
fill 418 78 560 418 78 561 minecraft:purple_concrete
fill 418 78 562 418 79 562 minecraft:black_concrete
fill 418 78 570 418 83 571 minecraft:black_concrete
fill 418 78 572 418 79 573 minecraft:purple_concrete
fill 418 78 579 418 83 579 minecraft:black_concrete
fill 418 78 580 418 78 581 minecraft:purple_concrete
fill 418 78 582 418 79 583 minecraft:black_concrete
fill 418 78 584 418 79 584 minecraft:purple_concrete
fill 418 78 590 418 83 591 minecraft:black_concrete
fill 418 78 592 418 79 593 minecraft:purple_concrete
fill 418 78 599 418 83 599 minecraft:black_concrete
fill 376 79 559 376 82 559 minecraft:black_concrete
setblock 376 79 564 minecraft:purple_concrete
setblock 376 79 575 minecraft:purple_concrete
fill 376 79 579 376 82 580 minecraft:black_concrete
setblock 376 79 596 minecraft:purple_concrete
setblock 376 79 599 minecraft:purple_concrete
fill 377 79 599 377 82 599 minecraft:black_concrete
setblock 384 79 599 minecraft:purple_concrete
fill 388 79 599 388 82 599 minecraft:black_concrete
fill 389 79 557 390 82 557 minecraft:black_concrete
fill 390 79 591 390 81 591 minecraft:obsidian
fill 390 79 594 390 81 594 minecraft:obsidian
fill 391 79 595 391 81 595 minecraft:obsidian
fill 392 79 589 394 81 589 minecraft:obsidian
fill 393 79 565 393 80 566 minecraft:obsidian
fill 393 79 596 393 81 596 minecraft:obsidian
setblock 394 79 557 minecraft:purple_concrete
fill 394 79 563 394 80 563 minecraft:obsidian
fill 394 79 567 394 80 567 minecraft:obsidian
fill 395 79 568 397 80 568 minecraft:obsidian
fill 395 79 595 395 81 595 minecraft:obsidian
fill 396 79 562 396 80 562 minecraft:obsidian
fill 396 79 591 396 81 591 minecraft:obsidian
fill 396 79 594 396 81 594 minecraft:obsidian
fill 398 79 563 398 80 563 minecraft:obsidian
fill 398 79 567 398 80 567 minecraft:obsidian
fill 399 79 565 399 80 565 minecraft:obsidian
fill 404 79 599 405 79 599 minecraft:purple_concrete
setblock 405 79 557 minecraft:purple_concrete
setblock 408 79 599 minecraft:purple_concrete
fill 409 79 599 409 82 599 minecraft:black_concrete
fill 410 79 557 410 82 557 minecraft:black_concrete
fill 418 79 560 418 82 560 minecraft:black_concrete
setblock 418 79 561 minecraft:purple_concrete
fill 418 79 564 418 79 565 minecraft:purple_concrete
fill 418 79 580 418 81 581 minecraft:black_concrete
setblock 418 79 585 minecraft:purple_concrete
setblock 418 79 596 minecraft:purple_concrete
fill 376 80 564 376 85 564 minecraft:black_concrete
fill 376 80 565 376 80 566 minecraft:purple_concrete
fill 376 80 567 376 85 568 minecraft:black_concrete
fill 376 80 573 376 81 574 minecraft:purple_concrete
fill 376 80 575 376 85 576 minecraft:black_concrete
setblock 376 80 577 minecraft:purple_concrete
fill 376 80 585 376 81 586 minecraft:purple_concrete
fill 376 80 587 376 85 588 minecraft:black_concrete
fill 376 80 594 376 81 594 minecraft:purple_concrete
fill 376 80 596 376 85 596 minecraft:black_concrete
fill 376 80 597 376 80 598 minecraft:purple_concrete
fill 376 80 599 376 85 599 minecraft:black_concrete
fill 381 80 557 382 85 557 minecraft:black_concrete
fill 382 80 599 383 81 599 minecraft:purple_concrete
fill 383 80 557 384 81 557 minecraft:purple_concrete
fill 384 80 599 385 85 599 minecraft:black_concrete
fill 389 80 592 389 81 593 minecraft:obsidian
fill 390 80 590 390 81 590 minecraft:obsidian
fill 390 80 595 390 81 595 minecraft:obsidian
fill 391 80 589 391 81 589 minecraft:obsidian
fill 391 80 596 392 81 596 minecraft:obsidian
setblock 392 80 557 minecraft:purple_concrete
fill 393 80 557 394 85 557 minecraft:black_concrete
setblock 393 80 564 minecraft:obsidian
setblock 393 80 567 minecraft:obsidian
setblock 394 80 568 minecraft:obsidian
fill 394 80 596 395 81 596 minecraft:obsidian
fill 394 80 599 395 80 599 minecraft:purple_concrete
fill 395 80 557 396 81 557 minecraft:purple_concrete
setblock 395 80 562 minecraft:obsidian
fill 395 80 589 395 81 589 minecraft:obsidian
fill 396 80 590 396 81 590 minecraft:obsidian
fill 396 80 595 396 81 595 minecraft:obsidian
fill 396 80 599 397 85 599 minecraft:black_concrete
setblock 397 80 562 minecraft:obsidian
fill 397 80 592 397 81 593 minecraft:obsidian
setblock 398 80 568 minecraft:obsidian
setblock 399 80 564 minecraft:obsidian
setblock 399 80 566 minecraft:obsidian
fill 401 80 557 402 85 557 minecraft:black_concrete
fill 403 80 557 404 80 557 minecraft:purple_concrete
fill 403 80 599 403 81 599 minecraft:purple_concrete
fill 404 80 599 405 85 599 minecraft:black_concrete
fill 405 80 557 405 85 557 minecraft:black_concrete
setblock 406 80 599 minecraft:purple_concrete
fill 408 80 599 408 85 599 minecraft:black_concrete
fill 413 80 557 414 85 557 minecraft:black_concrete
fill 414 80 599 415 81 599 minecraft:purple_concrete
fill 415 80 557 416 81 557 minecraft:purple_concrete
fill 416 80 599 417 85 599 minecraft:black_concrete
fill 418 80 561 418 85 561 minecraft:black_concrete
fill 418 80 562 418 80 563 minecraft:purple_concrete
fill 418 80 564 418 81 565 minecraft:black_concrete
fill 418 80 566 418 81 566 minecraft:purple_concrete
fill 418 80 572 418 85 573 minecraft:black_concrete
fill 418 80 574 418 81 575 minecraft:purple_concrete
fill 418 80 582 418 83 582 minecraft:black_concrete
setblock 418 80 583 minecraft:purple_concrete
fill 418 80 584 418 85 585 minecraft:black_concrete
fill 418 80 586 418 81 587 minecraft:purple_concrete
fill 418 80 592 418 82 593 minecraft:black_concrete
fill 418 80 594 418 80 595 minecraft:purple_concrete
fill 418 80 596 418 85 596 minecraft:black_concrete
fill 376 81 561 376 81 562 minecraft:purple_concrete
setblock 376 81 565 minecraft:purple_concrete
fill 376 81 566 376 84 566 minecraft:black_concrete
fill 376 81 577 376 84 577 minecraft:black_concrete
setblock 376 81 582 minecraft:purple_concrete
setblock 376 81 593 minecraft:purple_concrete
fill 376 81 597 376 84 598 minecraft:black_concrete
setblock 387 81 557 minecraft:purple_concrete
setblock 389 81 591 minecraft:obsidian
setblock 389 81 594 minecraft:obsidian
setblock 390 81 589 minecraft:obsidian
setblock 391 81 599 minecraft:purple_concrete
fill 392 81 557 392 84 557 minecraft:black_concrete
fill 392 81 588 394 81 588 minecraft:obsidian
setblock 393 81 597 minecraft:obsidian
setblock 394 81 599 minecraft:purple_concrete
fill 395 81 565 397 81 565 minecraft:amethyst_block
fill 395 81 599 395 84 599 minecraft:black_concrete
setblock 396 81 564 minecraft:amethyst_block
fill 396 81 566 396 82 566 minecraft:amethyst_block
setblock 396 81 589 minecraft:obsidian
setblock 397 81 591 minecraft:obsidian
setblock 397 81 594 minecraft:obsidian
setblock 402 81 599 minecraft:purple_concrete
fill 403 81 557 403 84 557 minecraft:black_concrete
setblock 404 81 557 minecraft:purple_concrete
fill 406 81 599 406 84 599 minecraft:black_concrete
fill 407 81 557 408 81 557 minecraft:purple_concrete
fill 418 81 562 418 83 563 minecraft:black_concrete
setblock 418 81 567 minecraft:purple_concrete
setblock 418 81 578 minecraft:purple_concrete
fill 418 81 583 418 83 583 minecraft:black_concrete
fill 418 81 594 418 84 594 minecraft:black_concrete
setblock 418 81 595 minecraft:purple_concrete
setblock 418 81 598 minecraft:purple_concrete
fill 376 82 560 376 83 560 minecraft:purple_concrete
fill 376 82 561 376 87 562 minecraft:black_concrete
setblock 376 82 563 minecraft:purple_concrete
fill 376 82 565 376 87 565 minecraft:black_concrete
fill 376 82 571 376 83 572 minecraft:purple_concrete
fill 376 82 573 376 87 574 minecraft:black_concrete
fill 376 82 582 376 87 582 minecraft:black_concrete
fill 376 82 583 376 82 584 minecraft:purple_concrete
fill 376 82 585 376 87 586 minecraft:black_concrete
fill 376 82 591 376 83 592 minecraft:purple_concrete
fill 376 82 593 376 87 594 minecraft:black_concrete
setblock 376 82 595 minecraft:purple_concrete
fill 377 82 557 378 83 557 minecraft:purple_concrete
fill 380 82 599 381 83 599 minecraft:purple_concrete
fill 382 82 599 383 87 599 minecraft:black_concrete
fill 383 82 557 384 87 557 minecraft:black_concrete
fill 385 82 557 386 82 557 minecraft:purple_concrete
fill 387 82 557 387 87 557 minecraft:black_concrete
fill 389 82 599 389 83 599 minecraft:purple_concrete
fill 391 82 599 391 87 599 minecraft:black_concrete
fill 392 82 592 394 82 593 minecraft:amethyst_block
fill 392 82 599 393 82 599 minecraft:purple_concrete
fill 394 82 599 394 87 599 minecraft:black_concrete
fill 395 82 557 396 87 557 minecraft:black_concrete
fill 395 82 565 396 82 565 minecraft:amethyst_block
fill 397 82 557 398 83 557 minecraft:purple_concrete
fill 400 82 599 401 83 599 minecraft:purple_concrete
fill 402 82 599 403 87 599 minecraft:black_concrete
fill 404 82 557 404 87 557 minecraft:black_concrete
setblock 406 82 557 minecraft:purple_concrete
fill 407 82 557 408 87 557 minecraft:black_concrete
fill 409 82 557 409 83 557 minecraft:purple_concrete
fill 412 82 599 413 82 599 minecraft:purple_concrete
fill 413 82 577 413 83 577 minecraft:amethyst_block
fill 414 82 599 415 87 599 minecraft:black_concrete
fill 415 82 557 416 87 557 minecraft:black_concrete
fill 417 82 557 418 82 557 minecraft:purple_concrete
fill 418 82 564 418 85 564 minecraft:black_concrete
setblock 418 82 565 minecraft:purple_concrete
fill 418 82 566 418 87 567 minecraft:black_concrete
fill 418 82 568 418 83 569 minecraft:purple_concrete
fill 418 82 574 418 84 575 minecraft:black_concrete
fill 418 82 576 418 82 577 minecraft:purple_concrete
fill 418 82 578 418 87 578 minecraft:black_concrete
fill 418 82 580 418 83 580 minecraft:purple_concrete
setblock 418 82 581 minecraft:black_concrete
fill 418 82 586 418 87 587 minecraft:black_concrete
fill 418 82 588 418 83 589 minecraft:purple_concrete
fill 418 82 595 418 84 595 minecraft:black_concrete
setblock 418 82 597 minecraft:purple_concrete
fill 418 82 598 418 87 598 minecraft:black_concrete
setblock 376 83 559 minecraft:purple_concrete
fill 376 83 563 376 86 563 minecraft:black_concrete
fill 376 83 579 376 83 580 minecraft:purple_concrete
setblock 376 83 583 minecraft:purple_concrete
fill 376 83 584 376 86 584 minecraft:black_concrete
fill 376 83 595 376 86 595 minecraft:black_concrete
setblock 377 83 599 minecraft:purple_concrete
fill 385 83 557 385 86 557 minecraft:black_concrete
setblock 386 83 557 minecraft:purple_concrete
setblock 388 83 599 minecraft:purple_concrete
fill 389 83 557 390 83 557 minecraft:purple_concrete
fill 392 83 566 392 84 566 minecraft:amethyst_block
fill 392 83 599 393 86 599 minecraft:black_concrete
fill 393 83 592 393 84 593 minecraft:amethyst_block
fill 396 83 565 396 85 565 minecraft:amethyst_block
fill 406 83 557 406 86 557 minecraft:black_concrete
setblock 409 83 599 minecraft:purple_concrete
setblock 410 83 557 minecraft:purple_concrete
setblock 412 83 599 minecraft:purple_concrete
fill 413 83 599 413 86 599 minecraft:black_concrete
fill 417 83 557 417 86 557 minecraft:black_concrete
setblock 418 83 557 minecraft:purple_concrete
setblock 418 83 560 minecraft:purple_concrete
fill 418 83 565 418 85 565 minecraft:black_concrete
fill 418 83 576 418 86 576 minecraft:black_concrete
setblock 418 83 577 minecraft:purple_concrete
setblock 418 83 581 minecraft:purple_concrete
setblock 418 83 592 minecraft:purple_concrete
fill 418 83 593 418 85 593 minecraft:black_concrete
fill 418 83 597 418 86 597 minecraft:black_concrete
fill 376 84 557 376 85 558 minecraft:purple_concrete
fill 376 84 559 376 89 560 minecraft:black_concrete
fill 376 84 569 376 84 570 minecraft:purple_concrete
fill 376 84 571 376 89 572 minecraft:black_concrete
fill 376 84 578 376 85 578 minecraft:purple_concrete
fill 376 84 579 376 89 580 minecraft:black_concrete
setblock 376 84 581 minecraft:purple_concrete
fill 376 84 583 376 89 583 minecraft:black_concrete
fill 376 84 589 376 85 590 minecraft:purple_concrete
fill 376 84 591 376 89 592 minecraft:black_concrete
fill 377 84 557 378 89 557 minecraft:black_concrete
fill 377 84 558 379 84 558 minecraft:obsidian
fill 377 84 560 377 84 562 minecraft:obsidian
fill 377 84 564 377 84 566 minecraft:obsidian
fill 377 84 568 377 84 570 minecraft:obsidian
fill 377 84 572 377 84 574 minecraft:obsidian
fill 377 84 576 377 84 578 minecraft:obsidian
fill 377 84 580 377 84 582 minecraft:obsidian
fill 377 84 584 377 84 586 minecraft:obsidian
fill 377 84 588 377 84 590 minecraft:obsidian
fill 377 84 592 377 84 594 minecraft:obsidian
fill 377 84 596 377 84 598 minecraft:obsidian
fill 377 84 599 377 89 599 minecraft:black_concrete
fill 378 84 599 379 84 599 minecraft:purple_concrete
fill 379 84 557 380 85 557 minecraft:purple_concrete
fill 379 84 598 381 84 598 minecraft:obsidian
fill 380 84 599 381 89 599 minecraft:black_concrete
fill 381 84 558 383 84 558 minecraft:obsidian
fill 383 84 598 385 84 598 minecraft:obsidian
fill 385 84 558 387 84 558 minecraft:obsidian
fill 386 84 557 386 89 557 minecraft:black_concrete
fill 386 84 599 387 85 599 minecraft:purple_concrete
fill 387 84 598 389 84 598 minecraft:obsidian
setblock 388 84 557 minecraft:purple_concrete
fill 388 84 599 389 89 599 minecraft:black_concrete
fill 389 84 557 390 89 557 minecraft:black_concrete
fill 389 84 558 391 84 558 minecraft:obsidian
setblock 390 84 599 minecraft:purple_concrete
fill 391 84 557 391 85 557 minecraft:purple_concrete
fill 391 84 598 393 84 598 minecraft:obsidian
fill 393 84 558 395 84 558 minecraft:obsidian
fill 395 84 598 397 84 598 minecraft:obsidian
fill 397 84 557 398 89 557 minecraft:black_concrete
fill 397 84 558 399 84 558 minecraft:obsidian
fill 398 84 599 399 85 599 minecraft:purple_concrete
fill 399 84 557 400 84 557 minecraft:purple_concrete
fill 399 84 598 401 84 598 minecraft:obsidian
fill 400 84 599 401 89 599 minecraft:black_concrete
fill 401 84 558 403 84 558 minecraft:obsidian
fill 403 84 598 405 84 598 minecraft:obsidian
fill 405 84 558 407 84 558 minecraft:obsidian
fill 407 84 598 409 84 598 minecraft:obsidian
fill 407 84 599 407 85 599 minecraft:purple_concrete
fill 409 84 557 410 89 557 minecraft:black_concrete
fill 409 84 558 411 84 558 minecraft:obsidian
fill 409 84 599 409 89 599 minecraft:black_concrete
fill 410 84 599 411 84 599 minecraft:purple_concrete
fill 411 84 557 412 85 557 minecraft:purple_concrete
fill 411 84 598 413 84 598 minecraft:obsidian
fill 412 84 599 412 89 599 minecraft:black_concrete
fill 413 84 558 415 84 558 minecraft:obsidian
fill 415 84 598 417 84 598 minecraft:obsidian
fill 417 84 558 417 84 560 minecraft:obsidian
fill 417 84 562 417 84 564 minecraft:obsidian
fill 417 84 566 417 84 568 minecraft:obsidian
fill 417 84 570 417 84 572 minecraft:obsidian
fill 417 84 574 417 84 576 minecraft:obsidian
fill 417 84 578 417 84 580 minecraft:obsidian
fill 417 84 582 417 84 584 minecraft:obsidian
fill 417 84 586 417 84 588 minecraft:obsidian
fill 417 84 590 417 84 592 minecraft:obsidian
fill 417 84 594 417 84 596 minecraft:obsidian
fill 418 84 557 418 89 557 minecraft:black_concrete
fill 418 84 558 418 84 559 minecraft:purple_concrete
fill 418 84 560 418 89 560 minecraft:black_concrete
fill 418 84 562 418 85 562 minecraft:purple_concrete
setblock 418 84 563 minecraft:black_concrete
fill 418 84 568 418 89 569 minecraft:black_concrete
fill 418 84 570 418 85 571 minecraft:purple_concrete
fill 418 84 577 418 86 577 minecraft:black_concrete
setblock 418 84 579 minecraft:purple_concrete
fill 418 84 580 418 89 581 minecraft:black_concrete
fill 418 84 582 418 85 583 minecraft:purple_concrete
fill 418 84 588 418 89 589 minecraft:black_concrete
fill 418 84 590 418 84 591 minecraft:purple_concrete
fill 418 84 592 418 85 592 minecraft:black_concrete
fill 418 84 599 418 85 599 minecraft:purple_concrete
setblock 376 85 566 minecraft:purple_concrete
setblock 376 85 569 minecraft:purple_concrete
fill 376 85 570 376 88 570 minecraft:black_concrete
setblock 376 85 577 minecraft:purple_concrete
fill 376 85 581 376 88 581 minecraft:black_concrete
fill 376 85 597 376 85 598 minecraft:purple_concrete
setblock 378 85 599 minecraft:purple_concrete
setblock 379 85 560 minecraft:light[level=12]
setblock 379 85 568 minecraft:light[level=12]
setblock 379 85 576 minecraft:light[level=12]
setblock 379 85 584 minecraft:light[level=12]
setblock 379 85 592 minecraft:light[level=12]
fill 379 85 599 379 88 599 minecraft:black_concrete
setblock 387 85 560 minecraft:light[level=12]
setblock 387 85 568 minecraft:light[level=12]
setblock 387 85 576 minecraft:light[level=12]
setblock 387 85 584 minecraft:light[level=12]
setblock 387 85 592 minecraft:light[level=12]
fill 388 85 557 388 88 557 minecraft:black_concrete
fill 390 85 599 390 88 599 minecraft:black_concrete
setblock 392 85 557 minecraft:purple_concrete
fill 392 85 566 392 94 566 minecraft:obsidian
setblock 393 85 592 minecraft:amethyst_block
setblock 395 85 560 minecraft:light[level=12]
setblock 395 85 568 minecraft:light[level=12]
setblock 395 85 576 minecraft:light[level=12]
setblock 395 85 584 minecraft:light[level=12]
setblock 395 85 592 minecraft:light[level=12]
setblock 395 85 599 minecraft:purple_concrete
fill 399 85 557 399 88 557 minecraft:black_concrete
setblock 400 85 557 minecraft:purple_concrete
setblock 403 85 557 minecraft:purple_concrete
setblock 403 85 560 minecraft:light[level=12]
setblock 403 85 568 minecraft:light[level=12]
setblock 403 85 576 minecraft:light[level=12]
setblock 403 85 584 minecraft:light[level=12]
setblock 403 85 592 minecraft:light[level=12]
setblock 406 85 599 minecraft:purple_concrete
fill 410 85 599 411 88 599 minecraft:black_concrete
setblock 411 85 560 minecraft:light[level=12]
setblock 411 85 568 minecraft:light[level=12]
setblock 411 85 576 minecraft:light[level=12]
setblock 411 85 584 minecraft:light[level=12]
setblock 411 85 592 minecraft:light[level=12]
fill 418 85 558 418 88 559 minecraft:black_concrete
setblock 418 85 563 minecraft:purple_concrete
setblock 418 85 574 minecraft:purple_concrete
fill 418 85 575 418 87 575 minecraft:black_concrete
fill 418 85 579 418 88 579 minecraft:black_concrete
fill 418 85 590 418 88 590 minecraft:black_concrete
setblock 418 85 591 minecraft:purple_concrete
fill 418 85 594 418 85 595 minecraft:purple_concrete
fill 376 86 557 376 91 558 minecraft:black_concrete
fill 376 86 564 376 87 564 minecraft:purple_concrete
fill 376 86 566 376 91 566 minecraft:black_concrete
fill 376 86 567 376 86 568 minecraft:purple_concrete
fill 376 86 569 376 91 569 minecraft:black_concrete
fill 376 86 575 376 87 576 minecraft:purple_concrete
fill 376 86 577 376 91 578 minecraft:black_concrete
fill 376 86 587 376 86 588 minecraft:purple_concrete
fill 376 86 589 376 91 590 minecraft:black_concrete
fill 376 86 596 376 87 596 minecraft:purple_concrete
fill 376 86 597 376 91 598 minecraft:black_concrete
setblock 376 86 599 minecraft:purple_concrete
fill 378 86 599 378 91 599 minecraft:black_concrete
fill 379 86 557 380 91 557 minecraft:black_concrete
fill 381 86 557 382 86 557 minecraft:purple_concrete
fill 384 86 599 385 87 599 minecraft:purple_concrete
fill 386 86 599 387 91 599 minecraft:black_concrete
fill 391 86 557 392 91 557 minecraft:black_concrete
fill 391 86 566 391 94 566 minecraft:obsidian
fill 392 86 565 392 94 565 minecraft:obsidian
fill 393 86 557 394 87 557 minecraft:purple_concrete
fill 395 86 599 395 91 599 minecraft:black_concrete
fill 396 86 599 397 86 599 minecraft:purple_concrete
fill 398 86 599 399 91 599 minecraft:black_concrete
fill 400 86 557 400 91 557 minecraft:black_concrete
fill 401 86 557 402 86 557 minecraft:purple_concrete
fill 403 86 557 403 91 557 minecraft:black_concrete
fill 404 86 599 405 87 599 minecraft:purple_concrete
fill 405 86 557 405 87 557 minecraft:purple_concrete
fill 406 86 599 407 91 599 minecraft:black_concrete
setblock 408 86 599 minecraft:purple_concrete
fill 411 86 557 412 91 557 minecraft:black_concrete
fill 413 86 557 414 87 557 minecraft:purple_concrete
fill 416 86 599 417 87 599 minecraft:purple_concrete
setblock 418 86 561 minecraft:purple_concrete
fill 418 86 562 418 91 563 minecraft:black_concrete
fill 418 86 564 418 87 565 minecraft:purple_concrete
fill 418 86 570 418 91 571 minecraft:black_concrete
fill 418 86 572 418 86 573 minecraft:purple_concrete
fill 418 86 574 418 87 574 minecraft:black_concrete
fill 418 86 582 418 91 583 minecraft:black_concrete
fill 418 86 584 418 87 585 minecraft:purple_concrete
fill 418 86 591 418 91 591 minecraft:black_concrete
fill 418 86 592 418 86 593 minecraft:purple_concrete
fill 418 86 594 418 87 595 minecraft:black_concrete
fill 418 86 596 418 87 596 minecraft:purple_concrete
fill 418 86 599 418 91 599 minecraft:black_concrete
setblock 376 87 563 minecraft:purple_concrete
fill 376 87 567 376 90 568 minecraft:black_concrete
setblock 376 87 584 minecraft:purple_concrete
setblock 376 87 587 minecraft:purple_concrete
fill 376 87 588 376 90 588 minecraft:black_concrete
setblock 376 87 595 minecraft:purple_concrete
fill 376 87 599 376 90 599 minecraft:black_concrete
fill 381 87 557 381 90 557 minecraft:black_concrete
setblock 382 87 557 minecraft:purple_concrete
setblock 385 87 557 minecraft:purple_concrete
fill 391 87 565 391 94 565 minecraft:obsidian
fill 392 87 599 393 87 599 minecraft:purple_concrete
setblock 396 87 599 minecraft:purple_concrete
fill 397 87 599 397 90 599 minecraft:black_concrete
fill 401 87 557 402 90 557 minecraft:black_concrete
setblock 406 87 557 minecraft:purple_concrete
fill 408 87 599 408 90 599 minecraft:black_concrete
setblock 413 87 599 minecraft:purple_concrete
setblock 417 87 557 minecraft:purple_concrete
fill 418 87 561 418 90 561 minecraft:black_concrete
fill 418 87 572 418 90 572 minecraft:black_concrete
setblock 418 87 573 minecraft:purple_concrete
fill 418 87 576 418 87 577 minecraft:purple_concrete
fill 418 87 592 418 89 593 minecraft:black_concrete
setblock 418 87 597 minecraft:purple_concrete
fill 376 88 561 376 89 562 minecraft:purple_concrete
fill 376 88 563 376 93 564 minecraft:black_concrete
setblock 376 88 565 minecraft:purple_concrete
fill 376 88 573 376 89 574 minecraft:purple_concrete
fill 376 88 575 376 93 576 minecraft:black_concrete
fill 376 88 582 376 89 582 minecraft:purple_concrete
fill 376 88 584 376 93 584 minecraft:black_concrete
fill 376 88 585 376 88 586 minecraft:purple_concrete
fill 376 88 587 376 93 587 minecraft:black_concrete
fill 376 88 593 376 89 594 minecraft:purple_concrete
fill 376 88 595 376 93 596 minecraft:black_concrete
fill 382 88 557 382 93 557 minecraft:black_concrete
fill 382 88 599 383 88 599 minecraft:purple_concrete
fill 383 88 557 384 88 557 minecraft:purple_concrete
fill 384 88 599 385 93 599 minecraft:black_concrete
fill 385 88 557 385 93 557 minecraft:black_concrete
fill 387 88 557 387 89 557 minecraft:purple_concrete
fill 390 88 565 390 94 566 minecraft:obsidian
fill 391 88 564 392 94 564 minecraft:obsidian
fill 391 88 567 392 94 567 minecraft:obsidian
fill 391 88 599 391 89 599 minecraft:purple_concrete
fill 392 88 599 393 93 599 minecraft:black_concrete
fill 393 88 557 394 93 557 minecraft:black_concrete
fill 393 88 565 393 94 566 minecraft:obsidian
setblock 394 88 599 minecraft:purple_concrete
fill 395 88 557 396 89 557 minecraft:purple_concrete
fill 396 88 599 396 93 599 minecraft:black_concrete
fill 402 88 599 403 89 599 minecraft:purple_concrete
setblock 404 88 557 minecraft:purple_concrete
fill 404 88 599 405 93 599 minecraft:black_concrete
fill 405 88 557 406 93 557 minecraft:black_concrete
fill 407 88 557 408 89 557 minecraft:purple_concrete
fill 413 88 557 414 93 557 minecraft:black_concrete
fill 413 88 599 413 93 599 minecraft:black_concrete
fill 414 88 599 415 88 599 minecraft:purple_concrete
fill 415 88 557 416 88 557 minecraft:purple_concrete
fill 416 88 599 417 90 599 minecraft:black_concrete
fill 417 88 557 417 93 557 minecraft:black_concrete
fill 418 88 564 418 93 565 minecraft:black_concrete
fill 418 88 566 418 89 567 minecraft:purple_concrete
fill 418 88 573 418 93 573 minecraft:black_concrete
fill 418 88 574 418 88 575 minecraft:purple_concrete
fill 418 88 576 418 89 577 minecraft:black_concrete
fill 418 88 578 418 89 578 minecraft:purple_concrete
fill 418 88 584 418 93 585 minecraft:black_concrete
fill 418 88 586 418 89 587 minecraft:purple_concrete
fill 418 88 594 418 91 594 minecraft:black_concrete
setblock 418 88 595 minecraft:purple_concrete
fill 418 88 596 418 93 597 minecraft:black_concrete
fill 418 88 598 418 89 598 minecraft:purple_concrete
fill 376 89 565 376 92 565 minecraft:black_concrete
setblock 376 89 570 minecraft:purple_concrete
setblock 376 89 581 minecraft:purple_concrete
fill 376 89 585 376 92 586 minecraft:black_concrete
setblock 379 89 599 minecraft:purple_concrete
setblock 382 89 599 minecraft:purple_concrete
fill 383 89 557 384 92 557 minecraft:black_concrete
fill 383 89 599 383 92 599 minecraft:black_concrete
setblock 388 89 557 minecraft:purple_concrete
fill 390 89 567 390 94 567 minecraft:obsidian
setblock 390 89 599 minecraft:purple_concrete
fill 393 89 564 393 94 564 minecraft:obsidian
fill 393 89 567 393 94 567 minecraft:obsidian
fill 394 89 599 394 92 599 minecraft:black_concrete
setblock 399 89 557 minecraft:purple_concrete
fill 404 89 557 404 92 557 minecraft:black_concrete
fill 410 89 599 411 89 599 minecraft:purple_concrete
setblock 414 89 599 minecraft:purple_concrete
fill 415 89 557 415 92 557 minecraft:black_concrete
fill 415 89 599 415 92 599 minecraft:black_concrete
setblock 416 89 557 minecraft:purple_concrete
fill 418 89 558 418 89 559 minecraft:purple_concrete
fill 418 89 574 418 91 575 minecraft:black_concrete
setblock 418 89 579 minecraft:purple_concrete
setblock 418 89 590 minecraft:purple_concrete
fill 418 89 595 418 91 595 minecraft:black_concrete
fill 376 90 559 376 91 560 minecraft:purple_concrete
fill 376 90 561 376 95 562 minecraft:black_concrete
fill 376 90 570 376 95 570 minecraft:black_concrete
fill 376 90 571 376 90 572 minecraft:purple_concrete
fill 376 90 573 376 95 574 minecraft:black_concrete
fill 376 90 579 376 91 580 minecraft:purple_concrete
fill 376 90 581 376 95 582 minecraft:black_concrete
setblock 376 90 583 minecraft:purple_concrete
fill 376 90 591 376 91 592 minecraft:purple_concrete
fill 376 90 593 376 95 594 minecraft:black_concrete
fill 377 90 557 378 91 557 minecraft:purple_concrete
fill 377 90 558 379 90 558 minecraft:obsidian
fill 377 90 560 377 90 562 minecraft:obsidian
fill 377 90 564 377 90 566 minecraft:obsidian
fill 377 90 568 377 90 570 minecraft:obsidian
fill 377 90 572 377 90 574 minecraft:obsidian
fill 377 90 576 377 90 578 minecraft:obsidian
fill 377 90 580 377 90 582 minecraft:obsidian
fill 377 90 584 377 90 586 minecraft:obsidian
fill 377 90 588 377 90 590 minecraft:obsidian
fill 377 90 592 377 90 594 minecraft:obsidian
fill 377 90 596 377 90 598 minecraft:obsidian
fill 377 90 599 377 91 599 minecraft:purple_concrete
fill 379 90 598 381 90 598 minecraft:obsidian
fill 379 90 599 379 95 599 minecraft:black_concrete
fill 380 90 599 381 90 599 minecraft:purple_concrete
fill 381 90 558 383 90 558 minecraft:obsidian
fill 382 90 599 382 95 599 minecraft:black_concrete
fill 383 90 598 385 90 598 minecraft:obsidian
fill 385 90 558 387 90 558 minecraft:obsidian
setblock 386 90 557 minecraft:purple_concrete
fill 387 90 557 388 95 557 minecraft:black_concrete
fill 387 90 598 389 90 598 minecraft:obsidian
fill 388 90 599 389 91 599 minecraft:purple_concrete
fill 389 90 557 390 91 557 minecraft:purple_concrete
fill 389 90 558 391 90 558 minecraft:obsidian
fill 389 90 565 389 94 566 minecraft:obsidian
fill 390 90 564 390 94 564 minecraft:obsidian
fill 390 90 568 393 94 568 minecraft:obsidian
fill 390 90 599 391 95 599 minecraft:black_concrete
fill 391 90 563 392 94 563 minecraft:obsidian
fill 391 90 598 393 90 598 minecraft:obsidian
fill 393 90 558 395 90 558 minecraft:obsidian
fill 394 90 565 394 94 567 minecraft:obsidian
fill 395 90 557 396 95 557 minecraft:black_concrete
fill 395 90 598 397 90 598 minecraft:obsidian
fill 397 90 557 398 90 557 minecraft:purple_concrete
fill 397 90 558 399 90 558 minecraft:obsidian
fill 399 90 557 399 95 557 minecraft:black_concrete
fill 399 90 598 401 90 598 minecraft:obsidian
fill 400 90 599 401 90 599 minecraft:purple_concrete
fill 401 90 558 403 90 558 minecraft:obsidian
fill 402 90 599 403 95 599 minecraft:black_concrete
fill 403 90 598 405 90 598 minecraft:obsidian
fill 405 90 558 407 90 558 minecraft:obsidian
fill 407 90 557 408 95 557 minecraft:black_concrete
fill 407 90 598 409 90 598 minecraft:obsidian
fill 409 90 557 410 91 557 minecraft:purple_concrete
fill 409 90 558 411 90 558 minecraft:obsidian
fill 409 90 599 409 91 599 minecraft:purple_concrete
fill 410 90 599 411 95 599 minecraft:black_concrete
fill 411 90 598 413 90 598 minecraft:obsidian
setblock 412 90 599 minecraft:purple_concrete
fill 413 90 558 415 90 558 minecraft:obsidian
fill 414 90 599 414 92 599 minecraft:black_concrete
fill 415 90 598 417 90 598 minecraft:obsidian
fill 416 90 557 416 95 557 minecraft:black_concrete
fill 417 90 558 417 90 560 minecraft:obsidian
fill 417 90 562 417 90 564 minecraft:obsidian
fill 417 90 566 417 90 568 minecraft:obsidian
fill 417 90 570 417 90 572 minecraft:obsidian
fill 417 90 574 417 90 576 minecraft:obsidian
fill 417 90 578 417 90 580 minecraft:obsidian
fill 417 90 582 417 90 584 minecraft:obsidian
fill 417 90 586 417 90 588 minecraft:obsidian
fill 417 90 590 417 90 592 minecraft:obsidian
fill 417 90 594 417 90 596 minecraft:obsidian
setblock 418 90 557 minecraft:purple_concrete
fill 418 90 558 418 95 559 minecraft:black_concrete
fill 418 90 560 418 91 560 minecraft:purple_concrete
fill 418 90 566 418 95 567 minecraft:black_concrete
fill 418 90 568 418 90 569 minecraft:purple_concrete
fill 418 90 576 418 93 576 minecraft:black_concrete
setblock 418 90 577 minecraft:purple_concrete
fill 418 90 578 418 95 579 minecraft:black_concrete
fill 418 90 580 418 91 581 minecraft:purple_concrete
fill 418 90 586 418 92 587 minecraft:black_concrete
fill 418 90 588 418 90 589 minecraft:purple_concrete
fill 418 90 590 418 95 590 minecraft:black_concrete
fill 418 90 592 418 91 592 minecraft:purple_concrete
setblock 418 90 593 minecraft:black_concrete
fill 418 90 598 418 95 598 minecraft:black_concrete
fill 376 91 567 376 91 568 minecraft:purple_concrete
setblock 376 91 571 minecraft:purple_concrete
fill 376 91 572 376 94 572 minecraft:black_concrete
fill 376 91 583 376 94 583 minecraft:black_concrete
setblock 376 91 588 minecraft:purple_concrete
setblock 376 91 599 minecraft:purple_concrete
fill 380 91 599 381 94 599 minecraft:black_concrete
setblock 381 91 557 minecraft:purple_concrete
fill 386 91 557 386 94 557 minecraft:black_concrete
fill 389 91 564 389 94 564 minecraft:obsidian
fill 389 91 567 389 94 567 minecraft:obsidian
fill 390 91 563 390 94 563 minecraft:obsidian
fill 391 91 586 391 92 586 minecraft:amethyst_block
fill 393 91 563 393 94 563 minecraft:obsidian
fill 394 91 564 394 94 564 minecraft:obsidian
fill 397 91 557 397 94 557 minecraft:black_concrete
setblock 397 91 599 minecraft:purple_concrete
setblock 398 91 557 minecraft:purple_concrete
setblock 400 91 599 minecraft:purple_concrete
fill 401 91 557 402 91 557 minecraft:purple_concrete
fill 401 91 599 401 94 599 minecraft:black_concrete
setblock 408 91 599 minecraft:purple_concrete
fill 412 91 599 412 94 599 minecraft:black_concrete
fill 416 91 599 416 93 599 minecraft:black_concrete
setblock 417 91 599 minecraft:purple_concrete
fill 418 91 557 418 94 557 minecraft:black_concrete
setblock 418 91 561 minecraft:purple_concrete
fill 418 91 568 418 94 568 minecraft:black_concrete
setblock 418 91 569 minecraft:purple_concrete
setblock 418 91 572 minecraft:purple_concrete
fill 418 91 577 418 93 577 minecraft:black_concrete
fill 418 91 588 418 94 588 minecraft:black_concrete
setblock 418 91 589 minecraft:purple_concrete
setblock 418 91 593 minecraft:purple_concrete
fill 376 92 557 376 92 558 minecraft:purple_concrete
fill 376 92 559 376 97 560 minecraft:black_concrete
fill 376 92 566 376 93 566 minecraft:purple_concrete
fill 376 92 567 376 97 568 minecraft:black_concrete
setblock 376 92 569 minecraft:purple_concrete
fill 376 92 571 376 97 571 minecraft:black_concrete
fill 376 92 577 376 93 578 minecraft:purple_concrete
fill 376 92 579 376 97 580 minecraft:black_concrete
fill 376 92 588 376 97 588 minecraft:black_concrete
fill 376 92 589 376 92 590 minecraft:purple_concrete
fill 376 92 591 376 97 592 minecraft:black_concrete
fill 376 92 597 376 93 598 minecraft:purple_concrete
fill 376 92 599 377 97 599 minecraft:black_concrete
fill 377 92 557 378 97 557 minecraft:black_concrete
setblock 378 92 599 minecraft:purple_concrete
fill 379 92 557 380 92 557 minecraft:purple_concrete
fill 381 92 557 381 97 557 minecraft:black_concrete
fill 386 92 599 387 93 599 minecraft:purple_concrete
fill 388 92 565 388 94 566 minecraft:obsidian
fill 388 92 599 389 97 599 minecraft:black_concrete
fill 389 92 557 390 97 557 minecraft:black_concrete
fill 389 92 563 389 94 563 minecraft:obsidian
fill 389 92 568 389 94 568 minecraft:obsidian
fill 390 92 569 393 94 569 minecraft:obsidian
fill 391 92 557 392 93 557 minecraft:purple_concrete
fill 392 92 562 392 94 562 minecraft:obsidian
fill 394 92 563 394 94 563 minecraft:obsidian
fill 394 92 568 394 94 568 minecraft:obsidian
fill 395 92 565 395 94 567 minecraft:obsidian
fill 395 92 599 395 93 599 minecraft:purple_concrete
fill 397 92 599 397 97 599 minecraft:black_concrete
fill 398 92 557 398 97 557 minecraft:black_concrete
fill 398 92 599 399 92 599 minecraft:purple_concrete
setblock 400 92 557 minecraft:purple_concrete
fill 400 92 599 400 97 599 minecraft:black_concrete
fill 401 92 557 402 97 557 minecraft:black_concrete
fill 403 92 557 403 93 557 minecraft:purple_concrete
fill 406 92 599 407 93 599 minecraft:purple_concrete
fill 408 92 599 409 97 599 minecraft:black_concrete
fill 409 92 557 410 97 557 minecraft:black_concrete
fill 411 92 557 412 92 557 minecraft:purple_concrete
fill 417 92 599 417 93 599 minecraft:black_concrete
fill 418 92 560 418 97 561 minecraft:black_concrete
fill 418 92 562 418 93 563 minecraft:purple_concrete
fill 418 92 569 418 97 569 minecraft:black_concrete
fill 418 92 570 418 92 571 minecraft:purple_concrete
fill 418 92 572 418 97 572 minecraft:black_concrete
fill 418 92 574 418 93 574 minecraft:purple_concrete
setblock 418 92 575 minecraft:black_concrete
fill 418 92 580 418 97 581 minecraft:black_concrete
fill 418 92 582 418 93 583 minecraft:purple_concrete
fill 418 92 589 418 94 589 minecraft:black_concrete
setblock 418 92 591 minecraft:purple_concrete
fill 418 92 592 418 97 593 minecraft:black_concrete
fill 418 92 594 418 93 595 minecraft:purple_concrete
fill 418 92 599 418 93 599 minecraft:purple_concrete
setblock 376 93 557 minecraft:purple_concrete
fill 376 93 558 376 96 558 minecraft:black_concrete
setblock 376 93 565 minecraft:purple_concrete
fill 376 93 569 376 96 569 minecraft:black_concrete
fill 376 93 585 376 93 586 minecraft:purple_concrete
setblock 376 93 589 minecraft:purple_concrete
fill 376 93 590 376 96 590 minecraft:black_concrete
fill 378 93 599 378 96 599 minecraft:black_concrete
fill 379 93 557 379 96 557 minecraft:black_concrete
setblock 379 93 560 minecraft:light[level=12]
setblock 379 93 568 minecraft:light[level=12]
setblock 379 93 576 minecraft:light[level=12]
setblock 379 93 584 minecraft:light[level=12]
setblock 379 93 592 minecraft:light[level=12]
setblock 380 93 557 minecraft:purple_concrete
fill 383 93 557 384 93 557 minecraft:purple_concrete
setblock 383 93 599 minecraft:purple_concrete
setblock 387 93 560 minecraft:light[level=12]
setblock 387 93 568 minecraft:light[level=12]
setblock 387 93 576 minecraft:light[level=12]
setblock 387 93 584 minecraft:light[level=12]
setblock 387 93 592 minecraft:light[level=12]
fill 388 93 564 388 94 564 minecraft:obsidian
fill 388 93 567 388 94 567 minecraft:obsidian
fill 389 93 569 389 94 569 minecraft:obsidian
fill 390 93 562 391 94 562 minecraft:obsidian
fill 393 93 562 393 94 562 minecraft:obsidian
fill 394 93 569 394 94 569 minecraft:obsidian
setblock 394 93 599 minecraft:purple_concrete
setblock 395 93 560 minecraft:light[level=12]
fill 395 93 564 395 94 564 minecraft:obsidian
fill 395 93 568 395 94 568 minecraft:obsidian
setblock 395 93 576 minecraft:light[level=12]
setblock 395 93 584 minecraft:light[level=12]
setblock 395 93 592 minecraft:light[level=12]
fill 398 93 599 399 96 599 minecraft:black_concrete
fill 400 93 557 400 96 557 minecraft:black_concrete
setblock 403 93 560 minecraft:light[level=12]
setblock 403 93 568 minecraft:light[level=12]
setblock 403 93 576 minecraft:light[level=12]
setblock 403 93 584 minecraft:light[level=12]
setblock 403 93 592 minecraft:light[level=12]
setblock 404 93 557 minecraft:purple_concrete
fill 411 93 557 411 96 557 minecraft:black_concrete
setblock 411 93 560 minecraft:light[level=12]
setblock 411 93 568 minecraft:light[level=12]
setblock 411 93 576 minecraft:light[level=12]
setblock 411 93 584 minecraft:light[level=12]
setblock 411 93 592 minecraft:light[level=12]
setblock 412 93 557 minecraft:purple_concrete
fill 414 93 599 415 93 599 minecraft:purple_concrete
setblock 415 93 557 minecraft:purple_concrete
fill 418 93 570 418 96 571 minecraft:black_concrete
setblock 418 93 575 minecraft:purple_concrete
setblock 418 93 586 minecraft:purple_concrete
fill 418 93 587 418 95 587 minecraft:black_concrete
fill 418 93 591 418 96 591 minecraft:black_concrete
fill 376 94 557 376 111 557 minecraft:black_concrete
fill 376 94 563 376 95 564 minecraft:purple_concrete
fill 376 94 565 376 108 566 minecraft:black_concrete
fill 376 94 575 376 94 576 minecraft:purple_concrete
fill 376 94 577 376 111 578 minecraft:black_concrete
fill 376 94 584 376 95 584 minecraft:purple_concrete
fill 376 94 585 376 108 586 minecraft:black_concrete
setblock 376 94 587 minecraft:purple_concrete
fill 376 94 589 376 111 589 minecraft:black_concrete
fill 376 94 595 376 95 596 minecraft:purple_concrete
fill 376 94 597 376 112 598 minecraft:black_concrete
fill 380 94 557 380 111 557 minecraft:black_concrete
setblock 382 94 557 minecraft:purple_concrete
fill 383 94 557 384 108 557 minecraft:black_concrete
fill 383 94 599 383 108 599 minecraft:black_concrete
fill 384 94 599 385 94 599 minecraft:purple_concrete
fill 385 94 557 385 95 557 minecraft:purple_concrete
fill 386 94 599 387 111 599 minecraft:black_concrete
fill 387 94 565 387 94 566 minecraft:obsidian
setblock 388 94 563 minecraft:obsidian
setblock 388 94 568 minecraft:obsidian
setblock 389 94 562 minecraft:obsidian
fill 390 94 570 393 94 570 minecraft:obsidian
fill 391 94 557 392 111 557 minecraft:black_concrete
fill 392 94 599 393 95 599 minecraft:purple_concrete
fill 393 94 557 394 94 557 minecraft:purple_concrete
setblock 394 94 562 minecraft:obsidian
fill 394 94 599 395 108 599 minecraft:black_concrete
setblock 395 94 563 minecraft:obsidian
setblock 395 94 569 minecraft:obsidian
fill 396 94 564 396 94 567 minecraft:obsidian
setblock 396 94 599 minecraft:purple_concrete
fill 403 94 557 404 108 557 minecraft:black_concrete
fill 404 94 599 405 95 599 minecraft:purple_concrete
fill 405 94 557 406 95 557 minecraft:purple_concrete
fill 406 94 599 407 111 599 minecraft:black_concrete
fill 412 94 557 412 111 557 minecraft:black_concrete
fill 413 94 557 414 94 557 minecraft:purple_concrete
fill 413 94 599 413 95 599 minecraft:purple_concrete
fill 414 94 599 415 95 599 minecraft:black_concrete
fill 415 94 557 415 108 557 minecraft:black_concrete
fill 416 94 599 417 94 599 minecraft:purple_concrete
fill 417 94 557 417 95 557 minecraft:purple_concrete
fill 418 94 562 418 111 563 minecraft:black_concrete
fill 418 94 564 418 95 565 minecraft:purple_concrete
setblock 418 94 573 minecraft:purple_concrete
fill 418 94 574 418 108 575 minecraft:black_concrete
fill 418 94 576 418 95 577 minecraft:purple_concrete
fill 418 94 582 418 111 583 minecraft:black_concrete
fill 418 94 584 418 94 585 minecraft:purple_concrete
fill 418 94 586 418 95 586 minecraft:black_concrete
fill 418 94 594 418 112 595 minecraft:black_concrete
fill 418 94 596 418 95 597 minecraft:purple_concrete
fill 418 94 599 418 111 599 minecraft:black_concrete
setblock 376 95 572 minecraft:purple_concrete
setblock 376 95 575 minecraft:purple_concrete
fill 376 95 576 376 113 576 minecraft:black_concrete
setblock 376 95 583 minecraft:purple_concrete
fill 376 95 587 376 113 587 minecraft:black_concrete
fill 380 95 599 381 95 599 minecraft:purple_concrete
fill 382 95 557 382 113 557 minecraft:black_concrete
setblock 384 95 599 minecraft:purple_concrete
fill 385 95 599 385 113 599 minecraft:black_concrete
setblock 386 95 557 minecraft:purple_concrete
fill 391 95 565 392 96 566 minecraft:amethyst_block
fill 393 95 557 393 113 557 minecraft:black_concrete
setblock 394 95 557 minecraft:purple_concrete
fill 396 95 599 396 112 599 minecraft:black_concrete
setblock 397 95 557 minecraft:purple_concrete
setblock 401 95 599 minecraft:purple_concrete
setblock 412 95 599 minecraft:purple_concrete
fill 413 95 557 414 111 557 minecraft:black_concrete
fill 416 95 599 417 97 599 minecraft:black_concrete
setblock 418 95 557 minecraft:purple_concrete
setblock 418 95 568 minecraft:purple_concrete
fill 418 95 573 418 112 573 minecraft:black_concrete
fill 418 95 584 418 113 584 minecraft:black_concrete
setblock 418 95 585 minecraft:purple_concrete
fill 418 95 588 418 95 589 minecraft:purple_concrete
fill 376 96 561 376 97 562 minecraft:purple_concrete
fill 376 96 563 376 109 564 minecraft:black_concrete
fill 376 96 570 376 97 570 minecraft:purple_concrete
fill 376 96 572 376 109 572 minecraft:black_concrete
fill 376 96 573 376 96 574 minecraft:purple_concrete
fill 376 96 575 376 113 575 minecraft:black_concrete
fill 376 96 581 376 97 582 minecraft:purple_concrete
fill 376 96 583 376 109 584 minecraft:black_concrete
fill 376 96 593 376 96 594 minecraft:purple_concrete
fill 376 96 595 376 109 596 minecraft:black_concrete
fill 377 96 558 379 96 558 minecraft:obsidian
fill 377 96 560 377 96 562 minecraft:obsidian
fill 377 96 564 377 96 566 minecraft:obsidian
fill 377 96 568 377 96 570 minecraft:obsidian
fill 377 96 572 377 96 574 minecraft:obsidian
fill 377 96 576 377 96 578 minecraft:obsidian
fill 377 96 580 377 96 582 minecraft:obsidian
fill 377 96 584 377 96 586 minecraft:obsidian
fill 377 96 588 377 96 590 minecraft:obsidian
fill 377 96 592 377 96 594 minecraft:obsidian
fill 377 96 596 377 96 598 minecraft:obsidian
fill 379 96 598 381 96 598 minecraft:obsidian
fill 379 96 599 379 97 599 minecraft:purple_concrete
fill 380 96 599 381 109 599 minecraft:black_concrete
fill 381 96 558 383 96 558 minecraft:obsidian
setblock 382 96 599 minecraft:purple_concrete
fill 383 96 598 385 96 598 minecraft:obsidian
fill 384 96 599 384 113 599 minecraft:black_concrete
fill 385 96 557 386 109 557 minecraft:black_concrete
fill 385 96 558 387 96 558 minecraft:obsidian
fill 387 96 557 388 97 557 minecraft:purple_concrete
fill 387 96 598 389 96 598 minecraft:obsidian
fill 389 96 558 391 96 558 minecraft:obsidian
fill 390 96 599 391 97 599 minecraft:purple_concrete
fill 391 96 598 393 96 598 minecraft:obsidian
fill 392 96 599 393 109 599 minecraft:black_concrete
fill 393 96 558 395 96 558 minecraft:obsidian
fill 394 96 557 394 112 557 minecraft:black_concrete
fill 395 96 557 396 96 557 minecraft:purple_concrete
fill 395 96 598 397 96 598 minecraft:obsidian
fill 397 96 557 397 109 557 minecraft:black_concrete
fill 397 96 558 399 96 558 minecraft:obsidian
fill 399 96 557 399 97 557 minecraft:purple_concrete
fill 399 96 598 401 96 598 minecraft:obsidian
fill 401 96 558 403 96 558 minecraft:obsidian
fill 401 96 599 401 109 599 minecraft:black_concrete
fill 402 96 599 403 96 599 minecraft:purple_concrete
fill 403 96 598 405 96 598 minecraft:obsidian
fill 404 96 599 405 111 599 minecraft:black_concrete
fill 405 96 557 406 109 557 minecraft:black_concrete
fill 405 96 558 407 96 558 minecraft:obsidian
fill 407 96 557 408 97 557 minecraft:purple_concrete
fill 407 96 598 409 96 598 minecraft:obsidian
fill 409 96 558 411 96 558 minecraft:obsidian
fill 410 96 599 411 97 599 minecraft:purple_concrete
fill 411 96 598 413 96 598 minecraft:obsidian
fill 412 96 599 413 109 599 minecraft:black_concrete
fill 413 96 558 415 96 558 minecraft:obsidian
setblock 414 96 599 minecraft:purple_concrete
fill 415 96 598 417 96 598 minecraft:obsidian
fill 415 96 599 415 108 599 minecraft:black_concrete
setblock 416 96 557 minecraft:purple_concrete
fill 417 96 557 418 109 557 minecraft:black_concrete
fill 417 96 558 417 96 560 minecraft:obsidian
fill 417 96 562 417 96 564 minecraft:obsidian
fill 417 96 566 417 96 568 minecraft:obsidian
fill 417 96 570 417 96 572 minecraft:obsidian
fill 417 96 574 417 96 576 minecraft:obsidian
fill 417 96 578 417 96 580 minecraft:obsidian
fill 417 96 582 417 96 584 minecraft:obsidian
fill 417 96 586 417 96 588 minecraft:obsidian
fill 417 96 590 417 96 592 minecraft:obsidian
fill 417 96 594 417 96 596 minecraft:obsidian
fill 418 96 558 418 97 559 minecraft:purple_concrete
fill 418 96 564 418 112 565 minecraft:black_concrete
fill 418 96 566 418 96 567 minecraft:purple_concrete
fill 418 96 568 418 109 568 minecraft:black_concrete
fill 418 96 576 418 109 577 minecraft:black_concrete
fill 418 96 578 418 97 579 minecraft:purple_concrete
fill 418 96 585 418 113 585 minecraft:black_concrete
fill 418 96 586 418 96 587 minecraft:purple_concrete
fill 418 96 588 418 97 589 minecraft:black_concrete
fill 418 96 590 418 97 590 minecraft:purple_concrete
fill 418 96 596 418 109 597 minecraft:black_concrete
fill 418 96 598 418 97 598 minecraft:purple_concrete
setblock 376 97 558 minecraft:purple_concrete
setblock 376 97 569 minecraft:purple_concrete
fill 376 97 573 376 108 574 minecraft:black_concrete
setblock 376 97 590 minecraft:purple_concrete
setblock 376 97 593 minecraft:purple_concrete
fill 376 97 594 376 108 594 minecraft:black_concrete
setblock 378 97 599 minecraft:purple_concrete
setblock 379 97 557 minecraft:purple_concrete
fill 382 97 599 382 108 599 minecraft:black_concrete
fill 391 97 566 392 97 566 minecraft:amethyst_block
fill 395 97 557 396 108 557 minecraft:black_concrete
fill 398 97 599 399 97 599 minecraft:purple_concrete
setblock 400 97 557 minecraft:purple_concrete
setblock 402 97 599 minecraft:purple_concrete
fill 403 97 599 403 108 599 minecraft:black_concrete
setblock 411 97 557 minecraft:purple_concrete
fill 414 97 599 414 108 599 minecraft:black_concrete
fill 416 97 557 416 108 557 minecraft:black_concrete
fill 418 97 566 418 108 566 minecraft:black_concrete
setblock 418 97 567 minecraft:purple_concrete
fill 418 97 570 418 97 571 minecraft:purple_concrete
fill 418 97 586 418 108 587 minecraft:black_concrete
setblock 418 97 591 minecraft:purple_concrete
fill 376 98 558 376 111 558 minecraft:black_concrete
fill 376 98 559 376 98 560 minecraft:purple_concrete
fill 376 98 561 376 108 562 minecraft:black_concrete
fill 376 98 567 376 98 568 minecraft:purple_concrete
fill 376 98 569 376 111 570 minecraft:black_concrete
setblock 376 98 571 minecraft:purple_concrete
fill 376 98 579 376 98 580 minecraft:purple_concrete
fill 376 98 581 376 108 582 minecraft:black_concrete
setblock 376 98 588 minecraft:purple_concrete
fill 376 98 590 376 111 590 minecraft:black_concrete
fill 376 98 591 376 98 592 minecraft:purple_concrete
fill 376 98 593 376 108 593 minecraft:black_concrete
fill 376 98 599 377 98 599 minecraft:purple_concrete
fill 377 98 557 378 98 557 minecraft:purple_concrete
fill 378 98 599 379 111 599 minecraft:black_concrete
fill 379 98 557 379 111 557 minecraft:black_concrete
setblock 381 98 557 minecraft:purple_concrete
fill 387 98 557 388 108 557 minecraft:black_concrete
fill 388 98 599 389 98 599 minecraft:purple_concrete
fill 389 98 557 390 98 557 minecraft:purple_concrete
fill 390 98 599 391 108 599 minecraft:black_concrete
setblock 392 98 566 minecraft:amethyst_block
setblock 397 98 599 minecraft:purple_concrete
setblock 398 98 557 minecraft:purple_concrete
fill 398 98 599 399 111 599 minecraft:black_concrete
fill 399 98 557 400 111 557 minecraft:black_concrete
setblock 400 98 599 minecraft:purple_concrete
fill 401 98 557 402 98 557 minecraft:purple_concrete
fill 402 98 599 402 108 599 minecraft:black_concrete
fill 407 98 557 408 108 557 minecraft:black_concrete
fill 408 98 599 409 98 599 minecraft:purple_concrete
fill 409 98 557 410 98 557 minecraft:purple_concrete
fill 410 98 599 411 108 599 minecraft:black_concrete
fill 411 98 557 411 111 557 minecraft:black_concrete
fill 416 98 599 416 112 599 minecraft:black_concrete
setblock 417 98 599 minecraft:purple_concrete
fill 418 98 558 418 111 559 minecraft:black_concrete
fill 418 98 560 418 98 561 minecraft:purple_concrete
fill 418 98 567 418 108 567 minecraft:black_concrete
setblock 418 98 569 minecraft:purple_concrete
fill 418 98 570 418 111 571 minecraft:black_concrete
setblock 418 98 572 minecraft:purple_concrete
fill 418 98 578 418 108 579 minecraft:black_concrete
fill 418 98 580 418 98 581 minecraft:purple_concrete
fill 418 98 588 418 109 588 minecraft:black_concrete
setblock 418 98 589 minecraft:purple_concrete
fill 418 98 590 418 111 591 minecraft:black_concrete
fill 418 98 592 418 98 593 minecraft:purple_concrete
fill 418 98 598 418 108 598 minecraft:black_concrete
fill 376 99 559 376 109 560 minecraft:black_concrete
fill 376 99 567 376 113 568 minecraft:black_concrete
fill 376 99 571 376 109 571 minecraft:black_concrete
fill 376 99 579 376 110 580 minecraft:black_concrete
fill 376 99 588 376 113 588 minecraft:black_concrete
fill 376 99 591 376 109 592 minecraft:black_concrete
fill 376 99 599 377 110 599 minecraft:black_concrete
fill 377 99 557 378 109 557 minecraft:black_concrete
fill 381 99 557 381 113 557 minecraft:black_concrete
fill 388 99 599 389 109 599 minecraft:black_concrete
fill 389 99 557 390 110 557 minecraft:black_concrete
fill 395 99 576 396 99 577 minecraft:crying_obsidian
setblock 396 99 575 minecraft:crying_obsidian
fill 396 99 578 398 99 578 minecraft:crying_obsidian
fill 397 99 577 399 99 577 minecraft:crying_obsidian
fill 397 99 599 397 113 599 minecraft:black_concrete
fill 398 99 557 398 109 557 minecraft:black_concrete
setblock 399 99 576 minecraft:crying_obsidian
fill 400 99 599 400 109 599 minecraft:black_concrete
fill 401 99 557 402 113 557 minecraft:black_concrete
fill 408 99 599 409 110 599 minecraft:black_concrete
fill 409 99 557 410 109 557 minecraft:black_concrete
fill 417 99 599 417 112 599 minecraft:black_concrete
fill 418 99 560 418 110 561 minecraft:black_concrete
fill 418 99 569 418 109 569 minecraft:black_concrete
fill 418 99 572 418 113 572 minecraft:black_concrete
fill 418 99 580 418 109 581 minecraft:black_concrete
fill 418 99 589 418 109 589 minecraft:black_concrete
fill 418 99 592 418 110 593 minecraft:black_concrete
fill 394 100 574 394 100 579 minecraft:crying_obsidian
fill 395 100 574 395 100 575 minecraft:crying_obsidian
fill 395 100 576 396 102 577 minecraft:magenta_concrete
fill 395 100 578 395 100 579 minecraft:crying_obsidian
fill 396 100 573 398 100 574 minecraft:crying_obsidian
fill 396 100 575 396 102 575 minecraft:magenta_concrete
fill 396 100 578 398 104 578 minecraft:magenta_concrete
fill 396 100 579 398 100 580 minecraft:crying_obsidian
fill 397 100 577 399 104 577 minecraft:magenta_concrete
fill 399 100 574 400 100 575 minecraft:crying_obsidian
fill 399 100 576 399 104 576 minecraft:magenta_concrete
fill 399 100 578 400 100 579 minecraft:crying_obsidian
fill 400 100 576 400 100 577 minecraft:crying_obsidian
setblock 379 101 560 minecraft:light[level=12]
setblock 379 101 568 minecraft:light[level=12]
setblock 379 101 576 minecraft:light[level=12]
setblock 379 101 584 minecraft:light[level=12]
setblock 379 101 592 minecraft:light[level=12]
setblock 387 101 560 minecraft:light[level=12]
setblock 387 101 568 minecraft:light[level=12]
setblock 387 101 576 minecraft:light[level=12]
setblock 387 101 584 minecraft:light[level=12]
setblock 387 101 592 minecraft:light[level=12]
fill 393 101 574 393 101 579 minecraft:crying_obsidian
fill 394 101 573 395 101 573 minecraft:crying_obsidian
fill 394 101 574 394 102 579 minecraft:magenta_concrete
fill 394 101 580 395 101 580 minecraft:crying_obsidian
setblock 395 101 560 minecraft:light[level=12]
setblock 395 101 568 minecraft:light[level=12]
fill 395 101 574 395 104 575 minecraft:magenta_concrete
fill 395 101 578 395 102 579 minecraft:magenta_concrete
setblock 395 101 584 minecraft:light[level=12]
setblock 395 101 592 minecraft:light[level=12]
fill 396 101 572 398 102 572 minecraft:crying_obsidian
fill 396 101 573 398 102 574 minecraft:magenta_concrete
fill 396 101 579 398 104 580 minecraft:magenta_concrete
fill 396 101 581 398 102 581 minecraft:crying_obsidian
fill 399 101 573 400 101 573 minecraft:crying_obsidian
fill 399 101 574 400 104 574 minecraft:magenta_concrete
fill 399 101 578 400 108 579 minecraft:magenta_concrete
fill 399 101 580 400 101 580 minecraft:crying_obsidian
fill 400 101 575 400 108 577 minecraft:magenta_concrete
fill 401 101 574 401 101 579 minecraft:crying_obsidian
setblock 403 101 560 minecraft:light[level=12]
setblock 403 101 568 minecraft:light[level=12]
setblock 403 101 576 minecraft:light[level=12]
setblock 403 101 584 minecraft:light[level=12]
setblock 403 101 592 minecraft:light[level=12]
setblock 411 101 560 minecraft:light[level=12]
setblock 411 101 568 minecraft:light[level=12]
setblock 411 101 576 minecraft:light[level=12]
setblock 411 101 584 minecraft:light[level=12]
setblock 411 101 592 minecraft:light[level=12]
fill 392 102 575 392 107 578 minecraft:crying_obsidian
fill 393 102 573 393 102 574 minecraft:crying_obsidian
fill 393 102 575 393 102 578 minecraft:magenta_concrete
fill 393 102 579 393 102 580 minecraft:crying_obsidian
fill 394 102 572 395 102 572 minecraft:crying_obsidian
fill 394 102 573 395 104 573 minecraft:magenta_concrete
fill 394 102 580 395 102 580 minecraft:magenta_concrete
fill 394 102 581 395 103 581 minecraft:crying_obsidian
fill 399 102 572 400 102 572 minecraft:crying_obsidian
fill 399 102 573 400 104 573 minecraft:magenta_concrete
fill 399 102 580 400 107 580 minecraft:magenta_concrete
fill 399 102 581 400 103 581 minecraft:crying_obsidian
fill 401 102 573 401 102 574 minecraft:crying_obsidian
fill 401 102 575 401 107 578 minecraft:magenta_concrete
fill 401 102 579 401 102 580 minecraft:crying_obsidian
fill 402 102 575 402 107 578 minecraft:crying_obsidian
fill 392 103 574 392 106 574 minecraft:crying_obsidian
fill 392 103 579 392 106 579 minecraft:crying_obsidian
fill 393 103 570 395 103 572 minecraft:redstone_block
fill 393 103 573 393 107 573 minecraft:crying_obsidian
fill 393 103 574 394 104 577 minecraft:magenta_concrete
fill 393 103 578 395 103 580 minecraft:redstone_block
fill 395 103 576 395 104 577 minecraft:magenta_concrete
fill 396 103 571 398 106 571 minecraft:crying_obsidian
fill 396 103 572 398 104 573 minecraft:magenta_concrete
fill 396 103 577 396 104 577 minecraft:magenta_concrete
fill 396 103 581 398 104 581 minecraft:magenta_concrete
fill 396 103 582 398 106 582 minecraft:crying_obsidian
fill 399 103 570 401 103 572 minecraft:redstone_block
fill 401 103 573 401 107 573 minecraft:crying_obsidian
fill 401 103 574 401 106 574 minecraft:magenta_concrete
fill 401 103 579 401 106 579 minecraft:magenta_concrete
fill 401 103 580 401 107 580 minecraft:crying_obsidian
fill 402 103 574 402 106 574 minecraft:crying_obsidian
fill 402 103 579 402 106 579 minecraft:crying_obsidian
fill 394 104 581 394 107 581 minecraft:crying_obsidian
setblock 395 104 581 minecraft:magenta_concrete
fill 395 104 582 395 105 582 minecraft:crying_obsidian
setblock 399 104 575 minecraft:magenta_concrete
fill 399 104 581 399 105 581 minecraft:magenta_concrete
fill 399 104 582 399 105 582 minecraft:crying_obsidian
fill 400 104 581 400 107 581 minecraft:crying_obsidian
fill 377 105 558 391 105 598 minecraft:obsidian
fill 392 105 558 417 105 568 minecraft:obsidian
fill 392 105 569 392 105 573 minecraft:crying_obsidian
fill 392 105 580 392 105 581 minecraft:crying_obsidian
fill 392 105 582 394 105 598 minecraft:obsidian
fill 393 105 569 396 105 569 minecraft:crying_obsidian
fill 393 105 570 395 105 572 minecraft:obsidian
fill 393 105 574 394 106 576 minecraft:magenta_concrete
fill 393 105 577 399 105 577 minecraft:crying_obsidian
fill 393 105 578 395 105 580 minecraft:obsidian
setblock 393 105 581 minecraft:crying_obsidian
fill 394 105 573 400 105 573 minecraft:crying_obsidian
fill 395 105 574 395 105 576 minecraft:crying_obsidian
fill 395 105 581 396 105 581 minecraft:crying_obsidian
fill 395 105 583 417 105 598 minecraft:obsidian
setblock 396 105 570 minecraft:crying_obsidian
setblock 396 105 572 minecraft:crying_obsidian
fill 396 105 578 396 105 580 minecraft:crying_obsidian
fill 397 105 569 397 105 570 minecraft:obsidian
fill 397 105 572 397 106 572 minecraft:magenta_concrete
fill 397 105 578 398 106 581 minecraft:magenta_concrete
fill 398 105 569 398 105 570 minecraft:crying_obsidian
setblock 398 105 572 minecraft:crying_obsidian
fill 399 105 569 402 105 569 minecraft:crying_obsidian
fill 399 105 570 401 105 572 minecraft:obsidian
fill 399 105 574 399 105 576 minecraft:crying_obsidian
fill 400 105 574 400 108 574 minecraft:magenta_concrete
fill 400 105 582 417 105 582 minecraft:obsidian
fill 401 105 581 417 105 581 minecraft:obsidian
fill 402 105 570 402 105 573 minecraft:crying_obsidian
fill 402 105 580 417 105 580 minecraft:obsidian
fill 403 105 569 417 105 579 minecraft:obsidian
fill 393 106 577 396 106 579 minecraft:magenta_concrete
fill 393 106 580 393 107 580 minecraft:crying_obsidian
fill 394 106 572 395 107 572 minecraft:crying_obsidian
fill 394 106 573 400 107 573 minecraft:magenta_concrete
fill 394 106 580 396 107 580 minecraft:magenta_concrete
fill 395 106 574 395 108 576 minecraft:magenta_concrete
fill 395 106 581 395 107 581 minecraft:crying_obsidian
setblock 396 106 572 minecraft:magenta_concrete
setblock 396 106 581 minecraft:magenta_concrete
fill 397 106 577 399 109 577 minecraft:magenta_concrete
setblock 398 106 572 minecraft:magenta_concrete
fill 399 106 572 400 107 572 minecraft:crying_obsidian
fill 399 106 574 399 108 574 minecraft:magenta_concrete
fill 399 106 581 399 107 581 minecraft:crying_obsidian
fill 393 107 574 393 108 574 minecraft:crying_obsidian
fill 393 107 575 394 107 578 minecraft:magenta_concrete
fill 393 107 579 393 108 579 minecraft:crying_obsidian
fill 394 107 574 394 108 574 minecraft:magenta_concrete
fill 394 107 579 398 108 579 minecraft:magenta_concrete
fill 395 107 577 396 108 578 minecraft:magenta_concrete
fill 396 107 572 398 108 572 minecraft:crying_obsidian
fill 396 107 581 398 108 581 minecraft:crying_obsidian
fill 397 107 578 398 109 578 minecraft:magenta_concrete
fill 397 107 580 398 108 580 minecraft:magenta_concrete
fill 401 107 574 401 108 574 minecraft:crying_obsidian
fill 401 107 579 401 108 579 minecraft:crying_obsidian
fill 393 108 575 393 108 578 minecraft:crying_obsidian
fill 394 108 573 395 108 573 minecraft:crying_obsidian
fill 394 108 575 394 108 578 minecraft:magenta_concrete
fill 394 108 580 395 108 580 minecraft:crying_obsidian
fill 396 108 573 396 108 576 minecraft:magenta_concrete
setblock 396 108 580 minecraft:magenta_concrete
fill 397 108 573 398 108 574 minecraft:magenta_concrete
fill 399 108 573 400 108 573 minecraft:crying_obsidian
fill 399 108 580 400 108 580 minecraft:crying_obsidian
fill 401 108 575 401 108 578 minecraft:crying_obsidian
fill 376 109 561 376 109 562 minecraft:purple_concrete
setblock 376 109 565 minecraft:purple_concrete
fill 376 109 566 376 112 566 minecraft:black_concrete
fill 376 109 573 376 109 574 minecraft:purple_concrete
fill 376 109 581 376 111 581 minecraft:black_concrete
setblock 376 109 582 minecraft:purple_concrete
fill 376 109 585 376 109 586 minecraft:purple_concrete
fill 376 109 593 376 109 594 minecraft:purple_concrete
setblock 379 109 560 minecraft:light[level=12]
setblock 379 109 568 minecraft:light[level=12]
setblock 379 109 576 minecraft:light[level=12]
setblock 379 109 584 minecraft:light[level=12]
setblock 379 109 592 minecraft:light[level=12]
fill 382 109 599 383 109 599 minecraft:purple_concrete
fill 383 109 557 384 109 557 minecraft:purple_concrete
setblock 387 109 557 minecraft:purple_concrete
setblock 387 109 560 minecraft:light[level=12]
setblock 387 109 568 minecraft:light[level=12]
setblock 387 109 576 minecraft:light[level=12]
setblock 387 109 584 minecraft:light[level=12]
setblock 387 109 592 minecraft:light[level=12]
fill 388 109 557 388 111 557 minecraft:black_concrete
fill 390 109 599 391 109 599 minecraft:purple_concrete
fill 394 109 574 394 109 579 minecraft:crying_obsidian
fill 394 109 587 394 109 588 minecraft:amethyst_block
setblock 394 109 599 minecraft:purple_concrete
fill 395 109 557 396 109 557 minecraft:purple_concrete
setblock 395 109 560 minecraft:light[level=12]
setblock 395 109 568 minecraft:light[level=12]
fill 395 109 574 395 109 575 minecraft:crying_obsidian
fill 395 109 576 396 109 577 minecraft:magenta_concrete
fill 395 109 578 395 109 579 minecraft:crying_obsidian
setblock 395 109 584 minecraft:light[level=12]
setblock 395 109 592 minecraft:light[level=12]
fill 395 109 599 395 112 599 minecraft:black_concrete
fill 396 109 573 398 109 574 minecraft:crying_obsidian
setblock 396 109 575 minecraft:magenta_concrete
setblock 396 109 578 minecraft:magenta_concrete
fill 396 109 579 398 109 580 minecraft:crying_obsidian
fill 399 109 574 400 109 574 minecraft:crying_obsidian
fill 399 109 578 400 109 579 minecraft:crying_obsidian
fill 400 109 575 400 109 577 minecraft:crying_obsidian
fill 402 109 599 403 109 599 minecraft:purple_concrete
fill 403 109 557 403 112 557 minecraft:black_concrete
setblock 403 109 560 minecraft:light[level=12]
setblock 403 109 568 minecraft:light[level=12]
setblock 403 109 576 minecraft:light[level=12]
setblock 403 109 584 minecraft:light[level=12]
setblock 403 109 592 minecraft:light[level=12]
setblock 404 109 557 minecraft:purple_concrete
fill 407 109 557 408 109 557 minecraft:purple_concrete
fill 407 109 569 412 111 569 minecraft:black_concrete
fill 408 109 567 411 111 568 minecraft:black_concrete
fill 408 109 570 412 111 571 minecraft:black_concrete
fill 409 109 572 411 110 572 minecraft:black_concrete
fill 410 109 599 410 111 599 minecraft:black_concrete
setblock 411 109 560 minecraft:light[level=12]
setblock 411 109 576 minecraft:light[level=12]
setblock 411 109 584 minecraft:light[level=12]
setblock 411 109 592 minecraft:light[level=12]
setblock 411 109 599 minecraft:purple_concrete
fill 412 109 568 412 111 568 minecraft:black_concrete
fill 414 109 599 415 109 599 minecraft:purple_concrete
fill 415 109 557 416 109 557 minecraft:purple_concrete
fill 418 109 566 418 109 567 minecraft:purple_concrete
fill 418 109 574 418 112 574 minecraft:black_concrete
setblock 418 109 575 minecraft:purple_concrete
setblock 418 109 578 minecraft:purple_concrete
fill 418 109 579 418 111 579 minecraft:black_concrete
fill 418 109 586 418 109 587 minecraft:purple_concrete
setblock 418 109 598 minecraft:purple_concrete
setblock 376 110 559 minecraft:black_concrete
fill 376 110 560 376 111 560 minecraft:purple_concrete
fill 376 110 561 376 111 562 minecraft:black_concrete
setblock 376 110 563 minecraft:purple_concrete
fill 376 110 564 376 112 565 minecraft:black_concrete
fill 376 110 571 376 111 572 minecraft:purple_concrete
fill 376 110 573 376 111 574 minecraft:black_concrete
fill 376 110 582 376 115 582 minecraft:black_concrete
fill 376 110 583 376 110 584 minecraft:purple_concrete
fill 376 110 585 376 113 586 minecraft:black_concrete
fill 376 110 591 376 111 592 minecraft:purple_concrete
fill 376 110 593 376 111 594 minecraft:black_concrete
setblock 376 110 595 minecraft:purple_concrete
fill 376 110 596 376 113 596 minecraft:black_concrete
fill 377 110 557 378 111 557 minecraft:purple_concrete
fill 380 110 599 381 111 599 minecraft:purple_concrete
fill 382 110 599 383 115 599 minecraft:black_concrete
fill 383 110 557 384 111 557 minecraft:black_concrete
fill 385 110 557 386 110 557 minecraft:purple_concrete
fill 387 110 557 387 115 557 minecraft:black_concrete
setblock 388 110 599 minecraft:black_concrete
fill 389 110 599 389 111 599 minecraft:purple_concrete
fill 390 110 599 391 111 599 minecraft:black_concrete
fill 392 110 599 393 110 599 minecraft:purple_concrete
fill 394 110 599 394 115 599 minecraft:black_concrete
fill 395 110 557 396 113 557 minecraft:black_concrete
fill 395 110 576 396 110 577 minecraft:crying_obsidian
setblock 396 110 575 minecraft:crying_obsidian
fill 396 110 578 398 110 578 minecraft:crying_obsidian
fill 397 110 557 398 111 557 minecraft:purple_concrete
fill 397 110 577 399 110 577 minecraft:crying_obsidian
fill 400 110 599 401 111 599 minecraft:purple_concrete
fill 402 110 599 403 115 599 minecraft:black_concrete
fill 404 110 557 405 112 557 minecraft:black_concrete
setblock 406 110 557 minecraft:purple_concrete
fill 407 110 557 408 112 557 minecraft:black_concrete
fill 407 110 567 407 110 568 minecraft:black_concrete
fill 407 110 570 407 112 570 minecraft:black_concrete
fill 408 110 566 410 111 566 minecraft:black_concrete
fill 409 110 557 409 111 557 minecraft:purple_concrete
setblock 410 110 557 minecraft:black_concrete
fill 411 110 599 411 111 599 minecraft:black_concrete
fill 412 110 599 413 110 599 minecraft:purple_concrete
fill 414 110 599 415 115 599 minecraft:black_concrete
fill 415 110 557 416 115 557 minecraft:black_concrete
fill 417 110 557 418 110 557 minecraft:purple_concrete
fill 418 110 566 418 111 567 minecraft:black_concrete
fill 418 110 568 418 111 569 minecraft:purple_concrete
fill 418 110 575 418 113 575 minecraft:black_concrete
fill 418 110 576 418 110 577 minecraft:purple_concrete
fill 418 110 578 418 115 578 minecraft:black_concrete
fill 418 110 580 418 111 580 minecraft:purple_concrete
setblock 418 110 581 minecraft:black_concrete
fill 418 110 586 418 111 587 minecraft:black_concrete
fill 418 110 588 418 111 589 minecraft:purple_concrete
fill 418 110 596 418 113 596 minecraft:black_concrete
setblock 418 110 597 minecraft:purple_concrete
fill 418 110 598 418 115 598 minecraft:black_concrete
setblock 376 111 559 minecraft:purple_concrete
fill 376 111 563 376 114 563 minecraft:black_concrete
fill 376 111 579 376 111 580 minecraft:purple_concrete
setblock 376 111 583 minecraft:purple_concrete
setblock 376 111 584 minecraft:black_concrete
setblock 376 111 595 minecraft:black_concrete
fill 376 111 599 376 113 599 minecraft:black_concrete
setblock 377 111 599 minecraft:purple_concrete
fill 385 111 557 385 114 557 minecraft:black_concrete
setblock 386 111 557 minecraft:purple_concrete
setblock 388 111 599 minecraft:purple_concrete
fill 389 111 557 390 111 557 minecraft:purple_concrete
fill 392 111 599 393 111 599 minecraft:black_concrete
fill 406 111 557 406 114 557 minecraft:black_concrete
fill 406 111 566 406 111 568 minecraft:black_concrete
fill 407 111 565 408 111 565 minecraft:black_concrete
fill 407 111 566 407 116 567 minecraft:purple_concrete
setblock 407 111 568 minecraft:black_concrete
fill 408 111 599 409 111 599 minecraft:purple_concrete
setblock 410 111 557 minecraft:purple_concrete
setblock 410 111 572 minecraft:black_concrete
setblock 412 111 599 minecraft:purple_concrete
fill 413 111 599 413 114 599 minecraft:black_concrete
fill 417 111 557 417 114 557 minecraft:black_concrete
setblock 418 111 557 minecraft:purple_concrete
setblock 418 111 560 minecraft:purple_concrete
fill 418 111 561 418 113 561 minecraft:black_concrete
fill 418 111 576 418 113 577 minecraft:black_concrete
setblock 418 111 581 minecraft:purple_concrete
setblock 418 111 592 minecraft:purple_concrete
fill 418 111 593 418 113 593 minecraft:black_concrete
fill 418 111 597 418 114 597 minecraft:black_concrete
fill 376 112 557 376 113 558 minecraft:purple_concrete
fill 376 112 559 376 112 560 minecraft:black_concrete
setblock 376 112 561 minecraft:purple_terracotta
fill 376 112 562 376 115 562 minecraft:black_concrete
fill 376 112 569 376 112 570 minecraft:purple_concrete
fill 376 112 571 376 115 573 minecraft:black_concrete
setblock 376 112 574 minecraft:purple_terracotta
setblock 376 112 577 minecraft:black_concrete
fill 376 112 578 376 113 578 minecraft:purple_concrete
fill 376 112 579 376 115 580 minecraft:black_concrete
setblock 376 112 581 minecraft:purple_concrete
fill 376 112 583 376 115 583 minecraft:black_concrete
setblock 376 112 584 minecraft:purple_terracotta
fill 376 112 589 376 113 590 minecraft:purple_concrete
setblock 376 112 591 minecraft:purple_terracotta
fill 376 112 592 376 113 592 minecraft:black_concrete
fill 376 112 593 376 112 595 minecraft:purple_terracotta
fill 377 112 557 378 115 557 minecraft:black_concrete
fill 377 112 599 377 115 599 minecraft:black_concrete
fill 378 112 599 379 112 599 minecraft:purple_concrete
fill 379 112 557 380 113 557 minecraft:purple_concrete
fill 380 112 599 380 113 599 minecraft:purple_terracotta
fill 381 112 599 381 114 599 minecraft:black_concrete
fill 383 112 557 383 115 557 minecraft:black_concrete
setblock 384 112 557 minecraft:purple_terracotta
fill 386 112 557 386 115 557 minecraft:black_concrete
fill 386 112 599 387 113 599 minecraft:purple_concrete
setblock 388 112 557 minecraft:purple_concrete
fill 388 112 599 389 113 599 minecraft:black_concrete
fill 389 112 557 390 112 557 minecraft:black_concrete
setblock 390 112 599 minecraft:purple_concrete
fill 391 112 557 391 113 557 minecraft:purple_concrete
fill 391 112 599 391 115 599 minecraft:black_concrete
setblock 392 112 557 minecraft:black_concrete
setblock 392 112 599 minecraft:purple_terracotta
fill 393 112 599 393 113 599 minecraft:black_concrete
fill 397 112 557 398 115 557 minecraft:black_concrete
fill 398 112 599 399 113 599 minecraft:purple_concrete
fill 399 112 557 400 112 557 minecraft:purple_concrete
fill 400 112 599 401 115 599 minecraft:black_concrete
setblock 404 112 599 minecraft:purple_terracotta
fill 405 112 565 406 117 567 minecraft:purple_concrete
fill 405 112 599 405 113 599 minecraft:black_concrete
fill 406 112 568 408 115 568 minecraft:purple_concrete
fill 406 112 569 411 112 569 minecraft:black_concrete
setblock 406 112 599 minecraft:purple_terracotta
fill 407 112 564 407 117 565 minecraft:purple_concrete
fill 407 112 599 407 113 599 minecraft:purple_concrete
fill 408 112 565 408 116 567 minecraft:purple_concrete
fill 408 112 570 411 112 570 minecraft:black_concrete
fill 408 112 599 409 113 599 minecraft:black_concrete
setblock 409 112 557 minecraft:purple_terracotta
setblock 409 112 565 minecraft:black_concrete
fill 409 112 566 409 115 567 minecraft:purple_concrete
fill 409 112 568 411 112 568 minecraft:black_concrete
fill 409 112 571 410 112 571 minecraft:black_concrete
fill 410 112 557 410 115 557 minecraft:black_concrete
fill 410 112 566 410 114 567 minecraft:black_concrete
fill 410 112 599 411 112 599 minecraft:purple_concrete
fill 411 112 557 412 113 557 minecraft:purple_concrete
setblock 411 112 567 minecraft:black_concrete
fill 412 112 599 412 115 599 minecraft:black_concrete
fill 413 112 557 413 113 557 minecraft:black_concrete
setblock 414 112 557 minecraft:purple_terracotta
fill 418 112 557 418 115 557 minecraft:black_concrete
fill 418 112 558 418 112 559 minecraft:purple_concrete
fill 418 112 560 418 116 560 minecraft:black_concrete
fill 418 112 562 418 113 562 minecraft:purple_concrete
setblock 418 112 563 minecraft:black_concrete
setblock 418 112 566 minecraft:purple_terracotta
fill 418 112 567 418 115 569 minecraft:black_concrete
fill 418 112 570 418 113 571 minecraft:purple_concrete
setblock 418 112 579 minecraft:purple_concrete
fill 418 112 580 418 115 581 minecraft:black_concrete
fill 418 112 582 418 113 583 minecraft:purple_concrete
setblock 418 112 586 minecraft:purple_terracotta
fill 418 112 587 418 113 588 minecraft:black_concrete
setblock 418 112 589 minecraft:purple_terracotta
fill 418 112 590 418 112 591 minecraft:purple_concrete
setblock 418 112 592 minecraft:black_concrete
fill 418 112 599 418 113 599 minecraft:purple_concrete
setblock 376 113 559 minecraft:purple_terracotta
fill 376 113 560 376 115 561 minecraft:black_concrete
setblock 376 113 564 minecraft:black_concrete
setblock 376 113 565 minecraft:purple_terracotta
setblock 376 113 566 minecraft:purple_concrete
setblock 376 113 569 minecraft:purple_concrete
setblock 376 113 570 minecraft:purple_terracotta
fill 376 113 574 376 115 574 minecraft:black_concrete
setblock 376 113 577 minecraft:purple_concrete
fill 376 113 581 376 115 581 minecraft:black_concrete
fill 376 113 584 376 114 584 minecraft:black_concrete
fill 376 113 591 376 115 591 minecraft:black_concrete
fill 376 113 593 376 114 595 minecraft:black_concrete
fill 376 113 597 376 113 598 minecraft:purple_concrete
setblock 378 113 599 minecraft:purple_concrete
fill 379 113 599 379 115 599 minecraft:black_concrete
fill 384 113 557 384 115 557 minecraft:black_concrete
fill 388 113 557 389 115 557 minecraft:black_concrete
setblock 390 113 557 minecraft:purple_terracotta
fill 390 113 599 390 115 599 minecraft:black_concrete
setblock 392 113 557 minecraft:purple_concrete
setblock 392 113 599 minecraft:black_concrete
setblock 394 113 557 minecraft:purple_terracotta
setblock 395 113 599 minecraft:purple_concrete
setblock 396 113 599 minecraft:purple_terracotta
fill 399 113 557 399 115 557 minecraft:black_concrete
setblock 400 113 557 minecraft:purple_concrete
setblock 403 113 557 minecraft:purple_concrete
fill 404 113 557 404 115 557 minecraft:black_concrete
fill 404 113 565 404 119 566 minecraft:purple_concrete
setblock 404 113 599 minecraft:black_concrete
setblock 405 113 557 minecraft:purple_terracotta
fill 405 113 564 406 118 564 minecraft:purple_concrete
fill 405 113 568 405 115 568 minecraft:purple_concrete
fill 406 113 569 410 113 569 minecraft:black_concrete
setblock 406 113 599 minecraft:purple_concrete
fill 407 113 557 407 115 557 minecraft:black_concrete
setblock 408 113 557 minecraft:purple_terracotta
fill 408 113 564 408 115 564 minecraft:purple_concrete
fill 408 113 570 410 113 570 minecraft:black_concrete
setblock 409 113 557 minecraft:black_concrete
fill 409 113 565 409 115 565 minecraft:purple_concrete
fill 409 113 568 409 114 568 minecraft:purple_concrete
fill 410 113 568 410 114 568 minecraft:black_concrete
fill 410 113 599 411 115 599 minecraft:black_concrete
setblock 414 113 557 minecraft:black_concrete
fill 416 113 599 417 113 599 minecraft:purple_terracotta
fill 418 113 558 418 115 559 minecraft:black_concrete
setblock 418 113 563 minecraft:purple_concrete
setblock 418 113 564 minecraft:black_concrete
setblock 418 113 565 minecraft:purple_terracotta
fill 418 113 566 418 115 566 minecraft:black_concrete
setblock 418 113 573 minecraft:purple_terracotta
setblock 418 113 574 minecraft:purple_concrete
fill 418 113 579 418 116 579 minecraft:black_concrete
fill 418 113 586 418 115 586 minecraft:black_concrete
fill 418 113 589 418 115 590 minecraft:black_concrete
setblock 418 113 591 minecraft:purple_concrete
setblock 418 113 592 minecraft:purple_terracotta
fill 418 113 594 418 113 595 minecraft:purple_concrete
setblock 376 114 557 minecraft:purple_terracotta
fill 376 114 558 376 115 559 minecraft:black_concrete
fill 376 114 564 376 115 564 minecraft:purple_concrete
fill 376 114 565 376 115 566 minecraft:black_concrete
fill 376 114 567 376 114 568 minecraft:purple_concrete
setblock 376 114 569 minecraft:purple_terracotta
fill 376 114 570 376 116 570 minecraft:black_concrete
fill 376 114 575 376 115 576 minecraft:purple_concrete
fill 376 114 577 376 115 578 minecraft:black_concrete
fill 376 114 585 376 115 585 minecraft:black_concrete
setblock 376 114 586 minecraft:purple_terracotta
fill 376 114 587 376 114 588 minecraft:purple_concrete
fill 376 114 589 376 115 590 minecraft:black_concrete
setblock 376 114 592 minecraft:purple_terracotta
fill 376 114 596 376 115 596 minecraft:purple_concrete
fill 376 114 597 376 115 598 minecraft:black_concrete
setblock 376 114 599 minecraft:purple_concrete
fill 377 114 558 379 114 558 minecraft:obsidian
fill 377 114 560 377 114 562 minecraft:obsidian
fill 377 114 564 377 114 566 minecraft:obsidian
fill 377 114 568 377 114 570 minecraft:obsidian
fill 377 114 572 377 114 574 minecraft:obsidian
fill 377 114 576 377 114 578 minecraft:obsidian
fill 377 114 580 377 114 582 minecraft:obsidian
fill 377 114 584 377 114 586 minecraft:obsidian
fill 377 114 588 377 114 590 minecraft:obsidian
fill 377 114 592 377 114 594 minecraft:obsidian
fill 377 114 596 377 114 598 minecraft:obsidian
fill 378 114 599 378 116 599 minecraft:black_concrete
setblock 379 114 557 minecraft:purple_terracotta
fill 379 114 598 381 114 598 minecraft:obsidian
fill 380 114 557 380 115 557 minecraft:black_concrete
fill 380 114 599 380 115 599 minecraft:black_concrete
fill 381 114 557 382 114 557 minecraft:purple_concrete
fill 381 114 558 383 114 558 minecraft:obsidian
fill 383 114 598 385 114 598 minecraft:obsidian
fill 384 114 599 385 115 599 minecraft:purple_concrete
fill 385 114 558 387 114 558 minecraft:obsidian
fill 386 114 599 388 115 599 minecraft:black_concrete
fill 387 114 598 389 114 598 minecraft:obsidian
fill 389 114 558 391 114 558 minecraft:obsidian
setblock 389 114 599 minecraft:purple_terracotta
fill 390 114 557 392 115 557 minecraft:black_concrete
fill 391 114 598 393 114 598 minecraft:obsidian
setblock 392 114 599 minecraft:purple_terracotta
fill 393 114 557 394 115 557 minecraft:purple_concrete
fill 393 114 558 395 114 558 minecraft:obsidian
fill 393 114 599 393 115 599 minecraft:purple_concrete
setblock 395 114 557 minecraft:purple_terracotta
fill 395 114 598 397 114 598 minecraft:obsidian
fill 395 114 599 395 115 599 minecraft:black_concrete
fill 396 114 557 396 115 557 minecraft:black_concrete
fill 396 114 599 397 114 599 minecraft:purple_concrete
fill 397 114 558 399 114 558 minecraft:obsidian
fill 398 114 599 399 115 599 minecraft:black_concrete
fill 399 114 598 401 114 598 minecraft:obsidian
fill 400 114 557 400 115 557 minecraft:black_concrete
fill 401 114 557 402 114 557 minecraft:purple_concrete
fill 401 114 558 403 114 558 minecraft:obsidian
fill 403 114 557 403 115 557 minecraft:black_concrete
fill 403 114 564 403 120 565 minecraft:purple_concrete
fill 403 114 598 405 114 598 minecraft:obsidian
fill 404 114 563 404 120 564 minecraft:purple_concrete
fill 404 114 567 404 117 567 minecraft:purple_concrete
fill 404 114 599 405 115 599 minecraft:purple_concrete
fill 405 114 557 405 115 557 minecraft:purple_concrete
fill 405 114 558 407 114 558 minecraft:obsidian
fill 405 114 563 406 118 563 minecraft:purple_concrete
fill 406 114 599 407 115 599 minecraft:black_concrete
fill 407 114 569 409 114 569 minecraft:black_concrete
fill 407 114 598 409 114 598 minecraft:obsidian
fill 408 114 557 408 115 557 minecraft:black_concrete
setblock 408 114 599 minecraft:purple_concrete
setblock 409 114 557 minecraft:purple_terracotta
fill 409 114 558 411 114 558 minecraft:obsidian
fill 409 114 599 409 116 599 minecraft:black_concrete
fill 411 114 557 412 115 557 minecraft:black_concrete
fill 411 114 598 413 114 598 minecraft:obsidian
fill 413 114 557 414 115 557 minecraft:purple_concrete
fill 413 114 558 415 114 558 minecraft:obsidian
fill 415 114 598 417 114 598 minecraft:obsidian
fill 416 114 599 417 114 599 minecraft:purple_concrete
fill 417 114 558 417 114 560 minecraft:obsidian
fill 417 114 562 417 114 564 minecraft:obsidian
fill 417 114 566 417 114 568 minecraft:obsidian
fill 417 114 570 417 114 572 minecraft:obsidian
fill 417 114 574 417 114 576 minecraft:obsidian
fill 417 114 578 417 114 580 minecraft:obsidian
fill 417 114 582 417 114 584 minecraft:obsidian
fill 417 114 586 417 114 588 minecraft:obsidian
fill 417 114 590 417 114 592 minecraft:obsidian
fill 417 114 594 417 114 596 minecraft:obsidian
setblock 418 114 561 minecraft:purple_concrete
fill 418 114 562 418 115 563 minecraft:black_concrete
fill 418 114 564 418 115 565 minecraft:purple_concrete
fill 418 114 570 418 115 571 minecraft:black_concrete
fill 418 114 572 418 114 573 minecraft:purple_concrete
fill 418 114 574 418 115 574 minecraft:black_concrete
setblock 418 114 575 minecraft:purple_terracotta
setblock 418 114 576 minecraft:black_concrete
setblock 418 114 577 minecraft:purple_terracotta
fill 418 114 582 418 115 583 minecraft:black_concrete
fill 418 114 584 418 115 585 minecraft:purple_concrete
setblock 418 114 587 minecraft:purple_terracotta
fill 418 114 588 418 115 588 minecraft:black_concrete
fill 418 114 591 418 115 592 minecraft:black_concrete
setblock 418 114 593 minecraft:purple_concrete
fill 418 114 594 418 115 595 minecraft:black_concrete
fill 418 114 596 418 115 596 minecraft:purple_concrete
setblock 418 114 599 minecraft:purple_terracotta
setblock 376 115 557 minecraft:black_concrete
setblock 376 115 563 minecraft:purple_concrete
fill 376 115 567 376 115 569 minecraft:black_concrete
setblock 376 115 584 minecraft:purple_concrete
setblock 376 115 586 minecraft:black_concrete
setblock 376 115 587 minecraft:purple_concrete
setblock 376 115 588 minecraft:black_concrete
fill 376 115 592 376 115 594 minecraft:black_concrete
setblock 376 115 595 minecraft:purple_concrete
setblock 376 115 599 minecraft:black_concrete
fill 379 115 557 379 117 557 minecraft:black_concrete
setblock 381 115 557 minecraft:black_concrete
setblock 381 115 599 minecraft:purple_concrete
setblock 382 115 557 minecraft:purple_concrete
setblock 385 115 557 minecraft:purple_concrete
setblock 389 115 599 minecraft:black_concrete
setblock 392 115 599 minecraft:purple_concrete
setblock 395 115 557 minecraft:black_concrete
setblock 396 115 599 minecraft:purple_concrete
setblock 397 115 599 minecraft:black_concrete
fill 401 115 557 402 115 557 minecraft:black_concrete
fill 402 115 564 402 121 565 minecraft:purple_concrete
fill 403 115 563 403 121 563 minecraft:purple_concrete
fill 403 115 566 403 119 566 minecraft:purple_concrete
setblock 406 115 557 minecraft:purple_concrete
fill 407 115 563 407 116 563 minecraft:purple_concrete
setblock 408 115 599 minecraft:black_concrete
setblock 409 115 557 minecraft:black_concrete
setblock 413 115 599 minecraft:purple_concrete
setblock 416 115 599 minecraft:purple_concrete
setblock 417 115 557 minecraft:purple_concrete
fill 417 115 599 418 115 599 minecraft:black_concrete
setblock 418 115 561 minecraft:black_concrete
setblock 418 115 572 minecraft:black_concrete
setblock 418 115 573 minecraft:purple_concrete
setblock 418 115 575 minecraft:black_concrete
fill 418 115 576 418 115 577 minecraft:purple_concrete
setblock 418 115 587 minecraft:black_concrete
setblock 418 115 593 minecraft:black_concrete
setblock 418 115 597 minecraft:purple_concrete
fill 376 116 557 376 116 560 minecraft:purple_terracotta
fill 376 116 561 376 117 562 minecraft:purple_concrete
fill 376 116 563 376 121 564 minecraft:purple_terracotta
setblock 376 116 565 minecraft:purple_concrete
fill 376 116 566 376 118 569 minecraft:purple_terracotta
fill 376 116 571 376 117 572 minecraft:purple_terracotta
fill 376 116 573 376 117 574 minecraft:purple_concrete
fill 376 116 575 376 116 581 minecraft:purple_terracotta
fill 376 116 582 376 117 582 minecraft:purple_concrete
fill 376 116 583 376 117 584 minecraft:purple_terracotta
fill 376 116 585 376 116 586 minecraft:purple_concrete
fill 376 116 587 376 117 592 minecraft:purple_terracotta
fill 376 116 593 376 117 594 minecraft:purple_concrete
fill 376 116 595 376 116 599 minecraft:purple_terracotta
fill 377 116 557 378 117 557 minecraft:purple_terracotta
fill 377 116 599 377 117 599 minecraft:purple_terracotta
fill 379 116 599 381 116 599 minecraft:purple_terracotta
fill 380 116 557 381 116 557 minecraft:purple_terracotta
setblock 382 116 557 minecraft:black_concrete
fill 382 116 599 383 116 599 minecraft:purple_concrete
fill 383 116 557 384 116 557 minecraft:purple_concrete
fill 384 116 599 389 117 599 minecraft:purple_terracotta
fill 385 116 557 386 117 557 minecraft:purple_terracotta
fill 387 116 557 387 117 557 minecraft:purple_concrete
fill 388 116 557 394 116 557 minecraft:purple_terracotta
fill 390 116 599 391 117 599 minecraft:purple_concrete
fill 392 116 599 393 116 599 minecraft:purple_terracotta
setblock 394 116 599 minecraft:purple_concrete
fill 395 116 557 396 117 557 minecraft:purple_concrete
fill 395 116 599 401 116 599 minecraft:purple_terracotta
fill 397 116 557 403 116 557 minecraft:purple_terracotta
fill 401 116 563 401 120 564 minecraft:purple_concrete
fill 402 116 562 402 122 563 minecraft:purple_concrete
fill 402 116 566 402 119 566 minecraft:purple_concrete
fill 402 116 599 403 117 599 minecraft:purple_concrete
fill 403 116 562 405 118 562 minecraft:purple_concrete
setblock 404 116 557 minecraft:purple_concrete
fill 404 116 599 408 117 599 minecraft:purple_terracotta
setblock 405 116 557 minecraft:black_concrete
fill 406 116 557 406 121 557 minecraft:purple_terracotta
setblock 406 116 568 minecraft:purple_concrete
fill 407 116 557 408 117 557 minecraft:purple_concrete
fill 409 116 557 414 116 557 minecraft:purple_terracotta
setblock 410 116 599 minecraft:purple_terracotta
fill 411 116 599 411 117 599 minecraft:purple_concrete
fill 412 116 599 413 117 599 minecraft:purple_terracotta
fill 414 116 599 415 116 599 minecraft:purple_concrete
fill 415 116 557 416 116 557 minecraft:purple_concrete
fill 416 116 599 418 116 599 minecraft:purple_terracotta
fill 417 116 557 418 117 557 minecraft:purple_terracotta
fill 418 116 558 418 116 559 minecraft:purple_terracotta
fill 418 116 561 418 116 565 minecraft:purple_terracotta
fill 418 116 566 418 117 567 minecraft:purple_concrete
fill 418 116 568 418 117 574 minecraft:purple_terracotta
setblock 418 116 575 minecraft:purple_concrete
fill 418 116 576 418 121 577 minecraft:purple_terracotta
fill 418 116 578 418 117 578 minecraft:purple_concrete
fill 418 116 580 418 117 582 minecraft:purple_terracotta
setblock 418 116 583 minecraft:black_concrete
fill 418 116 584 418 121 585 minecraft:purple_terracotta
fill 418 116 586 418 116 587 minecraft:purple_concrete
fill 418 116 588 418 116 597 minecraft:purple_terracotta
fill 418 116 598 418 117 598 minecraft:purple_concrete
fill 376 117 557 376 117 558 minecraft:black_concrete
fill 376 117 559 376 117 560 minecraft:purple_terracotta
fill 376 117 565 376 120 565 minecraft:purple_terracotta
setblock 376 117 570 minecraft:purple_concrete
fill 376 117 575 376 121 576 minecraft:purple_terracotta
fill 376 117 577 376 118 577 minecraft:black_concrete
fill 376 117 578 376 117 580 minecraft:purple_terracotta
setblock 376 117 581 minecraft:purple_concrete
fill 376 117 585 376 117 586 minecraft:purple_terracotta
fill 376 117 595 376 121 595 minecraft:purple_terracotta
setblock 376 117 596 minecraft:black_concrete
fill 376 117 597 376 117 598 minecraft:purple_terracotta
setblock 376 117 599 minecraft:black_concrete
fill 378 117 599 379 117 599 minecraft:purple_concrete
setblock 379 117 560 minecraft:light[level=12]
setblock 379 117 568 minecraft:light[level=12]
setblock 379 117 576 minecraft:light[level=12]
setblock 379 117 584 minecraft:light[level=12]
setblock 379 117 592 minecraft:light[level=12]
fill 380 117 557 380 119 557 minecraft:purple_terracotta
fill 380 117 599 381 117 599 minecraft:purple_terracotta
setblock 381 117 557 minecraft:black_concrete
setblock 382 117 557 minecraft:purple_terracotta
setblock 382 117 599 minecraft:purple_concrete
setblock 383 117 557 minecraft:black_concrete
fill 383 117 599 383 120 599 minecraft:purple_terracotta
fill 384 117 557 384 120 557 minecraft:purple_terracotta
setblock 387 117 560 minecraft:light[level=12]
setblock 387 117 568 minecraft:light[level=12]
setblock 387 117 576 minecraft:light[level=12]
setblock 387 117 584 minecraft:light[level=12]
setblock 387 117 592 minecraft:light[level=12]
setblock 388 117 557 minecraft:purple_concrete
setblock 389 117 557 minecraft:purple_terracotta
setblock 390 117 557 minecraft:black_concrete
fill 391 117 557 394 119 557 minecraft:purple_terracotta
setblock 392 117 599 minecraft:purple_terracotta
setblock 393 117 599 minecraft:black_concrete
fill 394 117 599 398 118 599 minecraft:purple_terracotta
setblock 395 117 560 minecraft:light[level=12]
setblock 395 117 568 minecraft:light[level=12]
setblock 395 117 576 minecraft:light[level=12]
setblock 395 117 584 minecraft:light[level=12]
setblock 395 117 592 minecraft:light[level=12]
setblock 397 117 557 minecraft:purple_terracotta
setblock 398 117 557 minecraft:black_concrete
setblock 399 117 557 minecraft:purple_concrete
setblock 399 117 599 minecraft:purple_concrete
fill 400 117 557 405 118 557 minecraft:purple_terracotta
fill 400 117 563 400 119 564 minecraft:purple_concrete
fill 400 117 599 401 117 599 minecraft:purple_terracotta
fill 401 117 562 401 120 562 minecraft:purple_concrete
fill 401 117 565 401 122 565 minecraft:purple_concrete
setblock 403 117 560 minecraft:light[level=12]
setblock 403 117 568 minecraft:light[level=12]
setblock 403 117 576 minecraft:light[level=12]
setblock 403 117 584 minecraft:light[level=12]
setblock 403 117 592 minecraft:light[level=12]
setblock 407 117 566 minecraft:purple_concrete
fill 407 117 567 407 120 567 minecraft:amethyst_block
fill 409 117 557 410 117 557 minecraft:black_concrete
setblock 409 117 599 minecraft:purple_terracotta
setblock 410 117 599 minecraft:purple_concrete
fill 411 117 557 412 119 557 minecraft:purple_terracotta
setblock 411 117 560 minecraft:light[level=12]
setblock 411 117 568 minecraft:light[level=12]
setblock 411 117 576 minecraft:light[level=12]
setblock 411 117 584 minecraft:light[level=12]
setblock 411 117 592 minecraft:light[level=12]
setblock 413 117 557 minecraft:black_concrete
fill 414 117 557 415 120 557 minecraft:purple_terracotta
fill 414 117 599 417 117 599 minecraft:purple_terracotta
setblock 416 117 557 minecraft:purple_concrete
fill 418 117 558 418 117 559 minecraft:purple_concrete
fill 418 117 560 418 117 561 minecraft:purple_terracotta
setblock 418 117 562 minecraft:black_concrete
fill 418 117 563 418 119 565 minecraft:purple_terracotta
fill 418 117 575 418 120 575 minecraft:purple_terracotta
setblock 418 117 579 minecraft:purple_concrete
fill 418 117 583 418 119 583 minecraft:purple_terracotta
fill 418 117 586 418 120 586 minecraft:purple_terracotta
setblock 418 117 587 minecraft:purple_concrete
fill 418 117 588 418 117 589 minecraft:purple_terracotta
setblock 418 117 590 minecraft:purple_concrete
fill 418 117 591 418 117 592 minecraft:purple_terracotta
setblock 418 117 593 minecraft:black_concrete
fill 418 117 594 418 119 597 minecraft:purple_terracotta
setblock 418 117 599 minecraft:black_concrete
fill 376 118 557 376 119 558 minecraft:purple_terracotta
fill 376 118 559 376 119 560 minecraft:purple_concrete
fill 376 118 561 376 123 562 minecraft:purple_terracotta
setblock 376 118 570 minecraft:black_concrete
fill 376 118 571 376 118 572 minecraft:purple_concrete
fill 376 118 573 376 123 574 minecraft:purple_terracotta
fill 376 118 578 376 119 578 minecraft:purple_terracotta
fill 376 118 579 376 119 580 minecraft:purple_concrete
fill 376 118 581 376 123 582 minecraft:purple_terracotta
setblock 376 118 583 minecraft:purple_concrete
fill 376 118 584 376 120 585 minecraft:purple_terracotta
setblock 376 118 586 minecraft:black_concrete
fill 376 118 587 376 118 590 minecraft:purple_terracotta
fill 376 118 591 376 119 592 minecraft:purple_concrete
fill 376 118 593 376 123 594 minecraft:purple_terracotta
fill 376 118 596 376 121 596 minecraft:purple_terracotta
setblock 376 118 597 minecraft:black_concrete
fill 376 118 598 376 118 599 minecraft:purple_terracotta
fill 377 118 557 378 119 557 minecraft:purple_concrete
fill 377 118 599 377 119 599 minecraft:purple_concrete
fill 378 118 599 379 119 599 minecraft:purple_terracotta
fill 379 118 557 379 119 557 minecraft:purple_terracotta
fill 380 118 599 381 118 599 minecraft:purple_concrete
setblock 381 118 557 minecraft:purple_terracotta
setblock 382 118 557 minecraft:black_concrete
fill 382 118 599 382 123 599 minecraft:purple_terracotta
fill 383 118 557 383 120 557 minecraft:purple_terracotta
fill 384 118 599 387 119 599 minecraft:purple_terracotta
fill 385 118 557 385 121 557 minecraft:purple_terracotta
setblock 386 118 557 minecraft:purple_concrete
fill 387 118 557 388 123 557 minecraft:purple_terracotta
fill 388 118 599 389 119 599 minecraft:purple_concrete
fill 389 118 557 390 119 557 minecraft:purple_concrete
setblock 390 118 599 minecraft:black_concrete
fill 391 118 599 391 123 599 minecraft:purple_terracotta
setblock 392 118 599 minecraft:black_concrete
fill 393 118 599 393 121 599 minecraft:purple_terracotta
fill 395 118 557 396 118 557 minecraft:black_concrete
fill 397 118 557 398 118 557 minecraft:purple_concrete
fill 399 118 557 399 123 557 minecraft:purple_terracotta
fill 399 118 563 399 119 564 minecraft:purple_concrete
fill 399 118 599 399 119 599 minecraft:purple_terracotta
fill 400 118 562 400 119 562 minecraft:purple_concrete
fill 400 118 565 400 121 565 minecraft:purple_concrete
fill 400 118 599 401 118 599 minecraft:purple_concrete
fill 401 118 561 403 119 561 minecraft:purple_concrete
fill 402 118 599 407 119 599 minecraft:purple_terracotta
fill 405 118 565 406 118 566 minecraft:purple_concrete
fill 407 118 557 408 123 557 minecraft:purple_terracotta
fill 407 118 566 407 120 566 minecraft:amethyst_block
fill 408 118 599 409 119 599 minecraft:purple_concrete
fill 409 118 557 410 119 557 minecraft:purple_concrete
fill 410 118 599 411 123 599 minecraft:purple_terracotta
setblock 412 118 599 minecraft:purple_concrete
fill 413 118 557 413 121 557 minecraft:purple_terracotta
setblock 413 118 599 minecraft:black_concrete
fill 414 118 599 414 120 599 minecraft:purple_terracotta
setblock 415 118 599 minecraft:black_concrete
fill 416 118 557 417 121 557 minecraft:purple_terracotta
fill 416 118 599 418 118 599 minecraft:purple_terracotta
setblock 418 118 557 minecraft:purple_concrete
fill 418 118 558 418 123 558 minecraft:purple_terracotta
setblock 418 118 559 minecraft:black_concrete
fill 418 118 560 418 119 560 minecraft:purple_concrete
fill 418 118 561 418 118 562 minecraft:purple_terracotta
fill 418 118 566 418 123 566 minecraft:purple_terracotta
setblock 418 118 567 minecraft:black_concrete
fill 418 118 568 418 118 569 minecraft:purple_concrete
fill 418 118 570 418 119 570 minecraft:purple_terracotta
fill 418 118 571 418 118 572 minecraft:black_concrete
fill 418 118 573 418 119 574 minecraft:purple_terracotta
fill 418 118 578 418 123 579 minecraft:purple_terracotta
fill 418 118 580 418 119 581 minecraft:purple_concrete
setblock 418 118 582 minecraft:black_concrete
fill 418 118 587 418 123 587 minecraft:purple_terracotta
fill 418 118 588 418 118 589 minecraft:purple_concrete
fill 418 118 590 418 119 591 minecraft:purple_terracotta
fill 418 118 592 418 119 592 minecraft:purple_concrete
setblock 418 118 593 minecraft:purple_terracotta
fill 418 118 598 418 123 598 minecraft:purple_terracotta
setblock 376 119 566 minecraft:purple_terracotta
fill 376 119 567 376 119 568 minecraft:purple_concrete
fill 376 119 569 376 119 570 minecraft:purple_terracotta
setblock 376 119 571 minecraft:purple_concrete
fill 376 119 572 376 122 572 minecraft:purple_terracotta
setblock 376 119 577 minecraft:purple_terracotta
fill 376 119 583 376 122 583 minecraft:purple_terracotta
fill 376 119 586 376 120 587 minecraft:purple_terracotta
setblock 376 119 588 minecraft:purple_concrete
fill 376 119 589 376 119 590 minecraft:purple_terracotta
fill 376 119 597 376 119 598 minecraft:purple_terracotta
setblock 376 119 599 minecraft:purple_concrete
fill 380 119 599 381 121 599 minecraft:purple_terracotta
setblock 381 119 557 minecraft:purple_concrete
fill 382 119 557 382 121 557 minecraft:purple_terracotta
fill 386 119 557 386 122 557 minecraft:purple_terracotta
fill 390 119 599 390 123 599 minecraft:purple_terracotta
fill 392 119 599 392 121 599 minecraft:purple_terracotta
fill 394 119 599 395 119 599 minecraft:purple_terracotta
fill 395 119 557 397 122 557 minecraft:purple_terracotta
fill 396 119 599 397 119 599 minecraft:purple_concrete
setblock 398 119 557 minecraft:purple_concrete
fill 398 119 562 398 119 564 minecraft:purple_concrete
setblock 398 119 599 minecraft:purple_terracotta
fill 399 119 561 399 119 562 minecraft:purple_concrete
fill 399 119 565 399 120 565 minecraft:purple_concrete
setblock 400 119 557 minecraft:purple_terracotta
fill 400 119 561 400 120 561 minecraft:purple_concrete
setblock 400 119 599 minecraft:purple_concrete
fill 401 119 557 402 119 557 minecraft:purple_concrete
fill 401 119 566 401 120 566 minecraft:purple_concrete
fill 401 119 599 401 122 599 minecraft:purple_terracotta
fill 403 119 557 405 119 557 minecraft:purple_terracotta
fill 403 119 562 404 120 562 minecraft:purple_concrete
fill 405 119 563 405 119 565 minecraft:purple_concrete
fill 412 119 599 413 121 599 minecraft:purple_terracotta
fill 415 119 599 416 120 599 minecraft:purple_terracotta
setblock 417 119 599 minecraft:purple_concrete
fill 418 119 557 418 122 557 minecraft:purple_terracotta
fill 418 119 559 418 123 559 minecraft:purple_terracotta
setblock 418 119 561 minecraft:purple_concrete
setblock 418 119 562 minecraft:purple_terracotta
fill 418 119 567 418 122 568 minecraft:purple_terracotta
setblock 418 119 569 minecraft:purple_concrete
setblock 418 119 571 minecraft:purple_terracotta
setblock 418 119 572 minecraft:purple_concrete
setblock 418 119 582 minecraft:purple_terracotta
fill 418 119 588 418 122 589 minecraft:purple_terracotta
setblock 418 119 593 minecraft:purple_concrete
setblock 418 119 599 minecraft:purple_terracotta
fill 376 120 557 376 120 558 minecraft:purple_concrete
fill 376 120 559 376 125 560 minecraft:purple_terracotta
fill 376 120 566 376 121 566 minecraft:purple_concrete
fill 376 120 567 376 125 568 minecraft:purple_terracotta
setblock 376 120 569 minecraft:purple_concrete
fill 376 120 570 376 123 571 minecraft:purple_terracotta
fill 376 120 577 376 121 578 minecraft:purple_concrete
fill 376 120 579 376 125 580 minecraft:purple_terracotta
fill 376 120 588 376 125 588 minecraft:purple_terracotta
fill 376 120 589 376 120 590 minecraft:purple_concrete
fill 376 120 591 376 122 592 minecraft:purple_terracotta
fill 376 120 597 376 121 598 minecraft:purple_concrete
fill 376 120 599 377 125 599 minecraft:purple_terracotta
fill 377 120 557 378 125 557 minecraft:purple_terracotta
fill 377 120 558 379 120 558 minecraft:obsidian
fill 377 120 560 377 120 562 minecraft:obsidian
fill 377 120 564 377 120 566 minecraft:obsidian
fill 377 120 568 377 120 570 minecraft:obsidian
fill 377 120 572 377 120 574 minecraft:obsidian
fill 377 120 576 377 120 578 minecraft:obsidian
fill 377 120 580 377 120 582 minecraft:obsidian
fill 377 120 584 377 120 586 minecraft:obsidian
fill 377 120 588 377 120 590 minecraft:obsidian
fill 377 120 592 377 120 594 minecraft:obsidian
fill 377 120 596 377 120 598 minecraft:obsidian
setblock 378 120 599 minecraft:purple_concrete
fill 379 120 557 380 120 557 minecraft:purple_concrete
fill 379 120 598 381 120 598 minecraft:obsidian
fill 379 120 599 379 123 599 minecraft:purple_terracotta
fill 381 120 557 381 125 557 minecraft:purple_terracotta
fill 381 120 558 383 120 558 minecraft:obsidian
fill 383 120 598 385 120 598 minecraft:obsidian
fill 384 120 599 385 121 599 minecraft:purple_terracotta
fill 385 120 558 387 120 558 minecraft:obsidian
fill 386 120 599 387 121 599 minecraft:purple_concrete
fill 387 120 598 389 120 598 minecraft:obsidian
fill 388 120 599 389 125 599 minecraft:purple_terracotta
fill 389 120 557 390 125 557 minecraft:purple_terracotta
fill 389 120 558 391 120 558 minecraft:obsidian
fill 391 120 557 392 121 557 minecraft:purple_concrete
fill 391 120 598 393 120 598 minecraft:obsidian
fill 393 120 557 394 121 557 minecraft:purple_terracotta
fill 393 120 558 395 120 558 minecraft:obsidian
setblock 394 120 599 minecraft:purple_terracotta
fill 395 120 598 397 120 598 minecraft:obsidian
fill 395 120 599 395 121 599 minecraft:purple_concrete
fill 396 120 599 397 121 599 minecraft:purple_terracotta
fill 397 120 558 399 120 558 minecraft:obsidian
fill 397 120 562 400 124 563 minecraft:black_concrete
fill 398 120 557 398 125 557 minecraft:purple_terracotta
fill 398 120 561 399 124 561 minecraft:black_concrete
fill 398 120 564 400 123 564 minecraft:black_concrete
fill 398 120 599 399 120 599 minecraft:purple_concrete
fill 399 120 598 401 120 598 minecraft:obsidian
setblock 400 120 557 minecraft:purple_concrete
fill 400 120 599 400 125 599 minecraft:purple_terracotta
fill 401 120 557 402 125 557 minecraft:purple_terracotta
fill 401 120 558 403 120 558 minecraft:obsidian
fill 401 120 561 402 121 561 minecraft:purple_concrete
fill 402 120 599 405 121 599 minecraft:purple_terracotta
fill 403 120 557 403 121 557 minecraft:purple_concrete
fill 403 120 566 404 121 566 minecraft:obsidian
fill 403 120 598 405 120 598 minecraft:obsidian
fill 404 120 557 405 120 557 minecraft:purple_terracotta
setblock 404 120 565 minecraft:purple_concrete
fill 405 120 558 407 120 558 minecraft:obsidian
fill 406 120 599 407 121 599 minecraft:purple_concrete
fill 407 120 598 409 120 598 minecraft:obsidian
fill 408 120 599 409 125 599 minecraft:purple_terracotta
fill 409 120 557 410 125 557 minecraft:purple_terracotta
fill 409 120 558 411 120 558 minecraft:obsidian
fill 411 120 557 412 120 557 minecraft:purple_concrete
fill 411 120 598 413 120 598 minecraft:obsidian
fill 413 120 558 415 120 558 minecraft:obsidian
fill 415 120 598 417 120 598 minecraft:obsidian
fill 417 120 558 417 120 560 minecraft:obsidian
fill 417 120 562 417 120 564 minecraft:obsidian
fill 417 120 566 417 120 568 minecraft:obsidian
fill 417 120 570 417 120 572 minecraft:obsidian
fill 417 120 574 417 120 576 minecraft:obsidian
fill 417 120 578 417 120 580 minecraft:obsidian
fill 417 120 582 417 120 584 minecraft:obsidian
fill 417 120 586 417 120 588 minecraft:obsidian
fill 417 120 590 417 120 592 minecraft:obsidian
fill 417 120 594 417 120 596 minecraft:obsidian
fill 417 120 599 417 125 599 minecraft:purple_terracotta
fill 418 120 560 418 125 561 minecraft:purple_terracotta
fill 418 120 562 418 121 563 minecraft:purple_concrete
fill 418 120 564 418 121 565 minecraft:purple_terracotta
fill 418 120 569 418 125 569 minecraft:purple_terracotta
fill 418 120 570 418 120 571 minecraft:purple_concrete
fill 418 120 572 418 121 573 minecraft:purple_terracotta
fill 418 120 574 418 121 574 minecraft:purple_concrete
fill 418 120 580 418 125 581 minecraft:purple_terracotta
fill 418 120 582 418 121 583 minecraft:purple_concrete
fill 418 120 590 418 123 590 minecraft:purple_terracotta
setblock 418 120 591 minecraft:purple_concrete
fill 418 120 592 418 125 593 minecraft:purple_terracotta
fill 418 120 594 418 121 595 minecraft:purple_concrete
fill 418 120 596 418 121 597 minecraft:purple_terracotta
fill 418 120 599 418 121 599 minecraft:purple_concrete
setblock 376 121 557 minecraft:purple_concrete
fill 376 121 558 376 124 558 minecraft:purple_terracotta
setblock 376 121 565 minecraft:purple_concrete
fill 376 121 569 376 124 569 minecraft:purple_terracotta
setblock 376 121 584 minecraft:purple_terracotta
fill 376 121 585 376 121 586 minecraft:purple_concrete
setblock 376 121 587 minecraft:purple_terracotta
setblock 376 121 589 minecraft:purple_concrete
fill 376 121 590 376 124 590 minecraft:purple_terracotta
fill 378 121 599 378 123 599 minecraft:purple_terracotta
fill 379 121 557 379 124 557 minecraft:purple_terracotta
setblock 380 121 557 minecraft:purple_concrete
fill 383 121 557 384 121 557 minecraft:purple_concrete
setblock 383 121 599 minecraft:purple_concrete
fill 384 121 573 385 122 574 minecraft:obsidian
setblock 394 121 599 minecraft:purple_concrete
fill 396 121 562 396 124 564 minecraft:black_concrete
fill 396 121 592 396 122 592 minecraft:amethyst_block
fill 397 121 561 397 126 561 minecraft:black_concrete
fill 397 121 564 397 126 564 minecraft:black_concrete
fill 398 121 560 399 122 560 minecraft:black_concrete
fill 398 121 565 399 123 565 minecraft:black_concrete
fill 398 121 599 399 123 599 minecraft:purple_terracotta
fill 400 121 557 400 124 557 minecraft:purple_terracotta
fill 400 121 561 400 123 561 minecraft:black_concrete
fill 401 121 562 401 123 563 minecraft:black_concrete
setblock 401 121 564 minecraft:purple_concrete
setblock 403 121 562 minecraft:purple_concrete
setblock 403 121 564 minecraft:purple_concrete
fill 403 121 565 404 121 565 minecraft:obsidian
setblock 404 121 557 minecraft:purple_concrete
setblock 405 121 557 minecraft:purple_terracotta
fill 411 121 557 411 124 557 minecraft:purple_terracotta
setblock 412 121 557 minecraft:purple_concrete
setblock 414 121 557 minecraft:purple_terracotta
fill 414 121 599 415 121 599 minecraft:purple_concrete
setblock 415 121 557 minecraft:purple_concrete
setblock 416 121 599 minecraft:purple_terracotta
fill 418 121 570 418 124 571 minecraft:purple_terracotta
setblock 418 121 575 minecraft:purple_concrete
setblock 418 121 586 minecraft:purple_concrete
fill 418 121 591 418 124 591 minecraft:purple_terracotta
schedule function dropper:buildpart/140_2 1t
