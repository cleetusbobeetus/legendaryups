setblock 370 208 478 minecraft:red_nether_bricks
fill 370 208 479 370 211 479 minecraft:pink_terracotta
setblock 370 208 483 minecraft:red_nether_bricks
fill 370 208 484 370 211 484 minecraft:pink_terracotta
setblock 370 208 488 minecraft:red_nether_bricks
fill 370 208 489 370 211 489 minecraft:pink_terracotta
setblock 370 208 494 minecraft:pink_terracotta
setblock 370 208 498 minecraft:red_nether_bricks
fill 370 208 499 370 211 499 minecraft:pink_terracotta
setblock 370 208 503 minecraft:red_nether_bricks
fill 370 208 504 370 211 504 minecraft:pink_terracotta
fill 330 209 464 332 209 464 minecraft:pink_terracotta
setblock 330 209 466 minecraft:pink_terracotta
setblock 330 209 467 minecraft:red_nether_bricks
fill 330 209 468 330 212 468 minecraft:pink_terracotta
setblock 330 209 472 minecraft:red_nether_bricks
fill 330 209 473 330 212 473 minecraft:pink_terracotta
setblock 330 209 477 minecraft:red_nether_bricks
fill 330 209 478 330 212 478 minecraft:pink_terracotta
setblock 330 209 482 minecraft:red_nether_bricks
fill 330 209 483 330 212 483 minecraft:pink_terracotta
setblock 330 209 487 minecraft:white_concrete
setblock 330 209 497 minecraft:red_nether_bricks
fill 330 209 498 330 209 501 minecraft:pink_terracotta
setblock 330 209 502 minecraft:red_nether_bricks
fill 330 209 503 332 209 504 minecraft:pink_terracotta
setblock 331 209 465 minecraft:pink_terracotta
setblock 331 209 466 minecraft:red_nether_bricks
fill 331 209 467 331 212 467 minecraft:pink_terracotta
setblock 331 209 471 minecraft:red_nether_bricks
fill 331 209 472 331 211 472 minecraft:pink_terracotta
setblock 331 209 476 minecraft:red_nether_bricks
fill 331 209 477 331 212 477 minecraft:pink_terracotta
setblock 331 209 481 minecraft:red_nether_bricks
fill 331 209 482 331 212 482 minecraft:pink_terracotta
fill 331 209 499 331 209 500 minecraft:pink_terracotta
setblock 331 209 501 minecraft:red_nether_bricks
fill 331 209 502 334 209 502 minecraft:pink_terracotta
setblock 332 209 465 minecraft:red_nether_bricks
setblock 332 209 466 minecraft:light[level=12]
setblock 332 209 475 minecraft:red_nether_bricks
fill 332 209 476 332 210 476 minecraft:pink_terracotta
setblock 332 209 479 minecraft:pink_terracotta
setblock 332 209 480 minecraft:red_nether_bricks
fill 332 209 481 332 212 481 minecraft:pink_terracotta
setblock 332 209 490 minecraft:light[level=12]
setblock 332 209 498 minecraft:light[level=12]
setblock 333 209 464 minecraft:red_nether_bricks
fill 333 209 465 333 211 466 minecraft:pink_terracotta
setblock 333 209 503 minecraft:pink_terracotta
setblock 333 209 504 minecraft:red_nether_bricks
fill 334 209 464 334 212 464 minecraft:pink_terracotta
setblock 334 209 503 minecraft:red_nether_bricks
fill 334 209 504 334 212 504 minecraft:pink_terracotta
setblock 335 209 502 minecraft:red_nether_bricks
fill 335 209 503 335 212 503 minecraft:pink_terracotta
setblock 336 209 466 minecraft:red_nether_bricks
fill 336 209 502 336 212 502 minecraft:pink_terracotta
setblock 337 209 465 minecraft:red_nether_bricks
setblock 337 209 466 minecraft:pink_terracotta
setblock 338 209 464 minecraft:red_nether_bricks
fill 338 209 465 338 212 465 minecraft:pink_terracotta
setblock 338 209 504 minecraft:red_nether_bricks
fill 339 209 464 339 212 464 minecraft:pink_terracotta
setblock 339 209 503 minecraft:red_nether_bricks
fill 339 209 504 339 212 504 minecraft:pink_terracotta
setblock 340 209 466 minecraft:light[level=12]
setblock 340 209 474 minecraft:light[level=12]
setblock 340 209 482 minecraft:light[level=12]
setblock 340 209 490 minecraft:light[level=12]
setblock 340 209 498 minecraft:light[level=12]
setblock 340 209 502 minecraft:red_nether_bricks
fill 340 209 503 340 212 503 minecraft:pink_terracotta
fill 341 209 502 341 210 502 minecraft:pink_terracotta
setblock 343 209 464 minecraft:red_nether_bricks
setblock 343 209 504 minecraft:red_nether_bricks
fill 344 209 464 344 212 464 minecraft:pink_terracotta
setblock 344 209 503 minecraft:red_nether_bricks
fill 344 209 504 347 209 504 minecraft:pink_terracotta
fill 345 209 503 348 209 503 minecraft:pink_terracotta
setblock 347 209 464 minecraft:pink_terracotta
fill 347 209 502 349 209 502 minecraft:pink_terracotta
setblock 348 209 464 minecraft:red_nether_bricks
setblock 348 209 466 minecraft:light[level=12]
setblock 348 209 474 minecraft:light[level=12]
setblock 348 209 482 minecraft:light[level=12]
setblock 348 209 490 minecraft:light[level=12]
setblock 348 209 498 minecraft:light[level=12]
setblock 348 209 504 minecraft:red_nether_bricks
fill 349 209 464 352 209 464 minecraft:pink_terracotta
setblock 349 209 503 minecraft:red_nether_bricks
fill 349 209 504 349 212 504 minecraft:pink_terracotta
setblock 350 209 502 minecraft:red_nether_bricks
fill 350 209 503 350 212 503 minecraft:pink_terracotta
setblock 351 209 501 minecraft:red_nether_bricks
fill 351 209 502 351 212 502 minecraft:pink_terracotta
fill 352 209 501 352 211 501 minecraft:pink_terracotta
setblock 353 209 464 minecraft:red_nether_bricks
setblock 353 209 504 minecraft:red_nether_bricks
fill 354 209 464 354 212 464 minecraft:pink_terracotta
setblock 354 209 503 minecraft:red_nether_bricks
fill 354 209 504 354 212 504 minecraft:pink_terracotta
setblock 355 209 502 minecraft:red_nether_bricks
fill 355 209 503 355 212 503 minecraft:pink_terracotta
setblock 356 209 466 minecraft:light[level=12]
setblock 356 209 474 minecraft:light[level=12]
setblock 356 209 482 minecraft:light[level=12]
setblock 356 209 490 minecraft:light[level=12]
setblock 356 209 498 minecraft:light[level=12]
setblock 356 209 501 minecraft:red_nether_bricks
fill 356 209 502 356 212 502 minecraft:pink_terracotta
setblock 357 209 501 minecraft:pink_terracotta
setblock 358 209 464 minecraft:red_nether_bricks
setblock 358 209 504 minecraft:red_nether_bricks
setblock 359 209 464 minecraft:pink_terracotta
setblock 359 209 503 minecraft:red_nether_bricks
fill 359 209 504 359 212 504 minecraft:pink_terracotta
setblock 360 209 502 minecraft:red_nether_bricks
fill 360 209 503 360 210 503 minecraft:pink_terracotta
setblock 363 209 504 minecraft:red_nether_bricks
setblock 364 209 466 minecraft:light[level=12]
setblock 364 209 474 minecraft:light[level=12]
setblock 364 209 482 minecraft:light[level=12]
setblock 364 209 490 minecraft:light[level=12]
setblock 364 209 498 minecraft:light[level=12]
setblock 368 209 464 minecraft:white_concrete
setblock 368 209 479 minecraft:red_nether_bricks
fill 368 209 480 368 211 480 minecraft:pink_terracotta
fill 368 209 482 369 209 482 minecraft:pink_terracotta
setblock 369 209 478 minecraft:red_nether_bricks
fill 369 209 479 369 212 479 minecraft:pink_terracotta
setblock 369 209 483 minecraft:red_nether_bricks
fill 369 209 484 369 212 484 minecraft:pink_terracotta
fill 369 209 504 369 212 504 minecraft:pink_terracotta
setblock 370 209 472 minecraft:red_nether_bricks
fill 370 209 473 370 212 473 minecraft:pink_terracotta
setblock 370 209 477 minecraft:red_nether_bricks
fill 370 209 478 370 212 478 minecraft:pink_terracotta
setblock 370 209 482 minecraft:red_nether_bricks
fill 370 209 483 370 212 483 minecraft:pink_terracotta
setblock 370 209 487 minecraft:red_nether_bricks
fill 370 209 488 370 212 488 minecraft:pink_terracotta
setblock 370 209 497 minecraft:red_nether_bricks
fill 370 209 498 370 210 498 minecraft:pink_terracotta
setblock 370 209 501 minecraft:pink_terracotta
setblock 370 209 502 minecraft:red_nether_bricks
fill 370 209 503 370 212 503 minecraft:pink_terracotta
fill 330 210 464 331 210 464 minecraft:pink_terracotta
setblock 330 210 466 minecraft:red_nether_bricks
fill 330 210 467 330 213 467 minecraft:pink_terracotta
setblock 330 210 471 minecraft:red_nether_bricks
fill 330 210 472 330 213 472 minecraft:pink_terracotta
setblock 330 210 476 minecraft:red_nether_bricks
fill 330 210 477 330 213 477 minecraft:pink_terracotta
setblock 330 210 481 minecraft:red_nether_bricks
fill 330 210 482 330 213 482 minecraft:pink_terracotta
setblock 330 210 486 minecraft:red_nether_bricks
setblock 330 210 493 minecraft:white_concrete
fill 330 210 498 330 210 500 minecraft:pink_terracotta
setblock 330 210 501 minecraft:red_nether_bricks
fill 330 210 502 331 210 504 minecraft:pink_terracotta
setblock 331 210 465 minecraft:red_nether_bricks
fill 331 210 466 331 213 466 minecraft:pink_terracotta
setblock 331 210 470 minecraft:red_nether_bricks
fill 331 210 471 331 211 471 minecraft:pink_terracotta
setblock 331 210 475 minecraft:red_nether_bricks
fill 331 210 476 331 213 476 minecraft:pink_terracotta
setblock 331 210 480 minecraft:red_nether_bricks
fill 331 210 481 331 213 481 minecraft:pink_terracotta
setblock 331 210 500 minecraft:red_nether_bricks
fill 331 210 501 331 213 501 minecraft:pink_terracotta
setblock 332 210 464 minecraft:red_nether_bricks
fill 332 210 465 332 213 465 minecraft:pink_terracotta
setblock 332 210 475 minecraft:pink_terracotta
setblock 332 210 479 minecraft:red_nether_bricks
fill 332 210 480 332 212 480 minecraft:pink_terracotta
fill 332 210 502 332 210 503 minecraft:pink_terracotta
setblock 332 210 504 minecraft:red_nether_bricks
fill 333 210 464 333 213 464 minecraft:pink_terracotta
setblock 333 210 502 minecraft:pink_terracotta
setblock 333 210 503 minecraft:red_nether_bricks
fill 333 210 504 333 213 504 minecraft:pink_terracotta
setblock 334 210 502 minecraft:red_nether_bricks
fill 334 210 503 334 213 503 minecraft:pink_terracotta
setblock 335 210 466 minecraft:red_nether_bricks
fill 335 210 502 335 213 502 minecraft:pink_terracotta
setblock 336 210 465 minecraft:red_nether_bricks
fill 336 210 466 336 211 466 minecraft:pink_terracotta
setblock 337 210 464 minecraft:red_nether_bricks
fill 337 210 465 337 213 465 minecraft:pink_terracotta
setblock 337 210 504 minecraft:red_nether_bricks
fill 338 210 464 338 213 464 minecraft:pink_terracotta
setblock 338 210 503 minecraft:red_nether_bricks
fill 338 210 504 338 213 504 minecraft:pink_terracotta
setblock 339 210 502 minecraft:red_nether_bricks
fill 339 210 503 339 213 503 minecraft:pink_terracotta
setblock 340 210 502 minecraft:pink_terracotta
setblock 342 210 464 minecraft:red_nether_bricks
setblock 342 210 504 minecraft:red_nether_bricks
fill 343 210 464 343 213 464 minecraft:pink_terracotta
setblock 343 210 503 minecraft:red_nether_bricks
fill 343 210 504 346 210 504 minecraft:pink_terracotta
fill 344 210 503 347 210 503 minecraft:pink_terracotta
setblock 347 210 464 minecraft:red_nether_bricks
setblock 347 210 504 minecraft:red_nether_bricks
fill 348 210 464 351 210 464 minecraft:pink_terracotta
setblock 348 210 502 minecraft:pink_terracotta
setblock 348 210 503 minecraft:red_nether_bricks
fill 348 210 504 348 213 504 minecraft:pink_terracotta
setblock 349 210 502 minecraft:red_nether_bricks
fill 349 210 503 349 213 503 minecraft:pink_terracotta
fill 350 210 502 350 213 502 minecraft:pink_terracotta
setblock 351 210 501 minecraft:pink_terracotta
setblock 352 210 464 minecraft:red_nether_bricks
setblock 352 210 504 minecraft:red_nether_bricks
fill 353 210 464 353 213 464 minecraft:pink_terracotta
setblock 353 210 503 minecraft:red_nether_bricks
fill 353 210 504 353 213 504 minecraft:pink_terracotta
setblock 354 210 502 minecraft:red_nether_bricks
fill 354 210 503 354 213 503 minecraft:pink_terracotta
setblock 355 210 501 minecraft:red_nether_bricks
fill 355 210 502 355 213 502 minecraft:pink_terracotta
setblock 356 210 501 minecraft:pink_terracotta
setblock 357 210 464 minecraft:red_nether_bricks
setblock 357 210 504 minecraft:red_nether_bricks
fill 358 210 464 358 211 464 minecraft:pink_terracotta
setblock 358 210 503 minecraft:red_nether_bricks
fill 358 210 504 358 213 504 minecraft:pink_terracotta
setblock 359 210 502 minecraft:red_nether_bricks
fill 359 210 503 359 211 503 minecraft:pink_terracotta
setblock 362 210 464 minecraft:white_concrete
setblock 362 210 504 minecraft:red_nether_bricks
setblock 363 210 504 minecraft:white_concrete
setblock 368 210 479 minecraft:pink_terracotta
setblock 368 210 482 minecraft:pink_terracotta
setblock 369 210 477 minecraft:red_nether_bricks
fill 369 210 478 369 213 478 minecraft:pink_terracotta
setblock 369 210 482 minecraft:red_nether_bricks
fill 369 210 483 369 213 483 minecraft:pink_terracotta
fill 370 210 464 370 210 465 minecraft:pink_terracotta
setblock 370 210 471 minecraft:red_nether_bricks
fill 370 210 472 370 213 472 minecraft:pink_terracotta
setblock 370 210 476 minecraft:red_nether_bricks
fill 370 210 477 370 213 477 minecraft:pink_terracotta
setblock 370 210 481 minecraft:red_nether_bricks
fill 370 210 482 370 213 482 minecraft:pink_terracotta
setblock 370 210 486 minecraft:red_nether_bricks
fill 370 210 487 370 213 487 minecraft:pink_terracotta
setblock 370 210 501 minecraft:red_nether_bricks
fill 370 210 502 370 213 502 minecraft:pink_terracotta
setblock 330 211 464 minecraft:pink_terracotta
setblock 330 211 465 minecraft:red_nether_bricks
fill 330 211 466 330 214 466 minecraft:pink_terracotta
setblock 330 211 470 minecraft:red_nether_bricks
fill 330 211 471 330 214 471 minecraft:pink_terracotta
setblock 330 211 475 minecraft:red_nether_bricks
fill 330 211 476 330 214 476 minecraft:pink_terracotta
setblock 330 211 480 minecraft:red_nether_bricks
fill 330 211 481 330 214 481 minecraft:pink_terracotta
setblock 330 211 484 minecraft:pink_terracotta
setblock 330 211 485 minecraft:red_nether_bricks
fill 330 211 486 330 214 486 minecraft:pink_terracotta
setblock 330 211 499 minecraft:pink_terracotta
setblock 330 211 500 minecraft:red_nether_bricks
fill 330 211 501 330 211 504 minecraft:pink_terracotta
setblock 331 211 464 minecraft:red_nether_bricks
fill 331 211 465 331 214 465 minecraft:pink_terracotta
setblock 331 211 469 minecraft:red_nether_bricks
fill 331 211 470 331 214 470 minecraft:pink_terracotta
setblock 331 211 474 minecraft:red_nether_bricks
fill 331 211 475 331 212 475 minecraft:pink_terracotta
setblock 331 211 479 minecraft:red_nether_bricks
fill 331 211 480 331 214 480 minecraft:pink_terracotta
setblock 331 211 484 minecraft:red_nether_bricks
setblock 331 211 500 minecraft:pink_terracotta
fill 331 211 502 331 211 503 minecraft:pink_terracotta
setblock 331 211 504 minecraft:red_nether_bricks
fill 332 211 464 332 214 464 minecraft:pink_terracotta
setblock 332 211 478 minecraft:red_nether_bricks
setblock 332 211 479 minecraft:pink_terracotta
setblock 332 211 502 minecraft:pink_terracotta
setblock 332 211 503 minecraft:red_nether_bricks
fill 332 211 504 332 214 504 minecraft:pink_terracotta
setblock 333 211 502 minecraft:red_nether_bricks
fill 333 211 503 333 214 503 minecraft:pink_terracotta
setblock 334 211 466 minecraft:red_nether_bricks
fill 334 211 502 334 213 502 minecraft:pink_terracotta
setblock 335 211 465 minecraft:red_nether_bricks
fill 335 211 466 335 214 466 minecraft:pink_terracotta
setblock 336 211 464 minecraft:red_nether_bricks
fill 336 211 465 336 214 465 minecraft:pink_terracotta
setblock 336 211 504 minecraft:red_nether_bricks
fill 337 211 464 337 214 464 minecraft:pink_terracotta
setblock 337 211 503 minecraft:red_nether_bricks
fill 337 211 504 337 214 504 minecraft:pink_terracotta
setblock 338 211 502 minecraft:red_nether_bricks
fill 338 211 503 338 214 503 minecraft:pink_terracotta
setblock 339 211 502 minecraft:pink_terracotta
setblock 341 211 464 minecraft:red_nether_bricks
setblock 341 211 504 minecraft:red_nether_bricks
fill 342 211 464 342 214 464 minecraft:pink_terracotta
setblock 342 211 503 minecraft:red_nether_bricks
fill 342 211 504 345 211 504 minecraft:pink_terracotta
fill 343 211 503 346 211 503 minecraft:pink_terracotta
setblock 346 211 464 minecraft:red_nether_bricks
setblock 346 211 504 minecraft:red_nether_bricks
fill 347 211 464 350 211 464 minecraft:pink_terracotta
setblock 347 211 503 minecraft:red_nether_bricks
fill 347 211 504 347 214 504 minecraft:pink_terracotta
setblock 348 211 502 minecraft:red_nether_bricks
fill 348 211 503 348 214 503 minecraft:pink_terracotta
fill 349 211 502 349 214 502 minecraft:pink_terracotta
setblock 351 211 464 minecraft:red_nether_bricks
setblock 351 211 504 minecraft:red_nether_bricks
fill 352 211 464 352 214 464 minecraft:pink_terracotta
setblock 352 211 503 minecraft:red_nether_bricks
fill 352 211 504 352 214 504 minecraft:pink_terracotta
setblock 353 211 502 minecraft:red_nether_bricks
fill 353 211 503 353 214 503 minecraft:pink_terracotta
setblock 354 211 501 minecraft:red_nether_bricks
fill 354 211 502 354 214 502 minecraft:pink_terracotta
setblock 355 211 501 minecraft:pink_terracotta
setblock 356 211 464 minecraft:red_nether_bricks
setblock 356 211 504 minecraft:red_nether_bricks
fill 357 211 464 357 214 464 minecraft:pink_terracotta
setblock 357 211 503 minecraft:red_nether_bricks
fill 357 211 504 357 214 504 minecraft:pink_terracotta
fill 358 211 503 358 212 503 minecraft:pink_terracotta
setblock 361 211 504 minecraft:red_nether_bricks
setblock 368 211 482 minecraft:red_nether_bricks
fill 369 211 464 370 211 464 minecraft:pink_terracotta
setblock 369 211 476 minecraft:red_nether_bricks
fill 369 211 477 369 214 477 minecraft:pink_terracotta
setblock 369 211 481 minecraft:red_nether_bricks
fill 369 211 482 369 214 482 minecraft:pink_terracotta
setblock 369 211 486 minecraft:red_nether_bricks
setblock 370 211 465 minecraft:red_nether_bricks
fill 370 211 466 370 213 467 minecraft:pink_terracotta
setblock 370 211 469 minecraft:white_concrete
fill 370 211 471 370 214 471 minecraft:pink_terracotta
setblock 370 211 475 minecraft:red_nether_bricks
fill 370 211 476 370 214 476 minecraft:pink_terracotta
setblock 370 211 480 minecraft:red_nether_bricks
fill 370 211 481 370 214 481 minecraft:pink_terracotta
setblock 370 211 485 minecraft:red_nether_bricks
fill 370 211 486 370 214 486 minecraft:pink_terracotta
setblock 370 211 494 minecraft:white_concrete
setblock 370 211 500 minecraft:red_nether_bricks
fill 370 211 501 370 214 501 minecraft:pink_terracotta
fill 329 212 463 329 212 466 minecraft:pink_terracotta
setblock 329 212 467 minecraft:red_terracotta
fill 329 212 468 329 215 468 minecraft:pink_terracotta
setblock 329 212 473 minecraft:red_terracotta
fill 329 212 474 329 215 474 minecraft:pink_terracotta
setblock 329 212 475 minecraft:red_terracotta
setblock 329 212 476 minecraft:pink_terracotta
fill 329 212 478 329 212 479 minecraft:pink_terracotta
fill 329 212 480 329 213 480 minecraft:red_terracotta
fill 329 212 481 329 213 487 minecraft:pink_terracotta
setblock 329 212 495 minecraft:red_terracotta
fill 329 212 496 329 215 500 minecraft:pink_terracotta
setblock 330 212 464 minecraft:red_nether_bricks
fill 330 212 465 330 215 465 minecraft:pink_terracotta
setblock 330 212 469 minecraft:red_nether_bricks
fill 330 212 470 330 215 470 minecraft:pink_terracotta
setblock 330 212 474 minecraft:red_nether_bricks
fill 330 212 475 330 215 475 minecraft:pink_terracotta
setblock 330 212 479 minecraft:red_nether_bricks
fill 330 212 480 330 215 480 minecraft:pink_terracotta
setblock 330 212 484 minecraft:red_nether_bricks
fill 330 212 485 331 214 485 minecraft:pink_terracotta
fill 330 212 487 330 213 487 minecraft:pink_terracotta
setblock 330 212 499 minecraft:red_nether_bricks
fill 330 212 500 330 212 503 minecraft:pink_terracotta
setblock 330 212 504 minecraft:red_nether_bricks
fill 331 212 464 331 215 464 minecraft:pink_terracotta
setblock 331 212 468 minecraft:red_nether_bricks
fill 331 212 469 331 215 469 minecraft:pink_terracotta
setblock 331 212 474 minecraft:pink_terracotta
setblock 331 212 478 minecraft:red_nether_bricks
fill 331 212 479 331 215 479 minecraft:pink_terracotta
setblock 331 212 483 minecraft:red_nether_bricks
fill 331 212 484 331 215 484 minecraft:pink_terracotta
setblock 331 212 502 minecraft:pink_terracotta
setblock 331 212 503 minecraft:red_nether_bricks
fill 331 212 504 331 215 504 minecraft:pink_terracotta
setblock 332 212 466 minecraft:pink_terracotta
fill 332 212 503 332 215 503 minecraft:pink_terracotta
fill 333 212 463 336 215 463 minecraft:pink_terracotta
setblock 333 212 465 minecraft:pink_terracotta
setblock 333 212 466 minecraft:red_nether_bricks
fill 333 212 502 333 213 502 minecraft:pink_terracotta
setblock 334 212 465 minecraft:red_nether_bricks
fill 334 212 466 334 215 466 minecraft:pink_terracotta
setblock 335 212 464 minecraft:red_nether_bricks
fill 335 212 465 335 215 465 minecraft:pink_terracotta
setblock 335 212 504 minecraft:red_nether_bricks
fill 336 212 464 336 215 464 minecraft:pink_terracotta
setblock 336 212 503 minecraft:red_nether_bricks
fill 336 212 504 336 215 504 minecraft:pink_terracotta
setblock 337 212 463 minecraft:red_terracotta
setblock 337 212 502 minecraft:red_nether_bricks
fill 337 212 503 337 215 503 minecraft:pink_terracotta
setblock 339 212 465 minecraft:red_nether_bricks
setblock 340 212 464 minecraft:red_nether_bricks
setblock 340 212 504 minecraft:red_nether_bricks
fill 341 212 464 341 215 464 minecraft:pink_terracotta
setblock 341 212 503 minecraft:red_nether_bricks
fill 341 212 504 344 212 504 minecraft:pink_terracotta
fill 342 212 503 345 212 503 minecraft:pink_terracotta
setblock 342 212 505 minecraft:red_terracotta
setblock 345 212 464 minecraft:red_nether_bricks
setblock 345 212 504 minecraft:red_nether_bricks
fill 346 212 464 349 212 464 minecraft:pink_terracotta
setblock 346 212 503 minecraft:red_nether_bricks
fill 346 212 504 346 215 504 minecraft:pink_terracotta
setblock 347 212 463 minecraft:red_terracotta
fill 347 212 503 347 215 503 minecraft:pink_terracotta
fill 348 212 463 350 215 463 minecraft:pink_terracotta
setblock 350 212 464 minecraft:red_nether_bricks
setblock 350 212 504 minecraft:red_nether_bricks
fill 351 212 464 351 215 464 minecraft:pink_terracotta
setblock 351 212 503 minecraft:red_nether_bricks
fill 351 212 504 351 215 504 minecraft:pink_terracotta
setblock 352 212 463 minecraft:red_terracotta
setblock 352 212 502 minecraft:red_nether_bricks
fill 352 212 503 352 215 503 minecraft:pink_terracotta
fill 352 212 505 355 213 505 minecraft:pink_terracotta
fill 353 212 463 356 212 463 minecraft:pink_terracotta
fill 353 212 502 353 215 502 minecraft:pink_terracotta
setblock 355 212 464 minecraft:red_nether_bricks
setblock 355 212 504 minecraft:red_nether_bricks
fill 356 212 464 356 215 464 minecraft:pink_terracotta
setblock 356 212 503 minecraft:red_nether_bricks
fill 356 212 504 356 215 504 minecraft:pink_terracotta
setblock 356 212 505 minecraft:red_terracotta
fill 357 212 503 357 213 503 minecraft:pink_terracotta
setblock 360 212 504 minecraft:red_nether_bricks
fill 361 212 463 362 215 463 minecraft:pink_terracotta
setblock 363 212 463 minecraft:red_terracotta
fill 364 212 463 364 215 463 minecraft:pink_terracotta
fill 366 212 463 370 215 463 minecraft:pink_terracotta
setblock 368 212 481 minecraft:red_nether_bricks
fill 368 212 482 368 215 482 minecraft:pink_terracotta
setblock 369 212 464 minecraft:pink_terracotta
setblock 369 212 476 minecraft:pink_terracotta
setblock 369 212 480 minecraft:red_nether_bricks
fill 369 212 481 369 215 481 minecraft:pink_terracotta
setblock 369 212 485 minecraft:red_nether_bricks
fill 369 212 486 369 215 486 minecraft:pink_terracotta
setblock 370 212 464 minecraft:red_nether_bricks
fill 370 212 465 370 215 465 minecraft:pink_terracotta
setblock 370 212 468 minecraft:pink_terracotta
setblock 370 212 469 minecraft:red_nether_bricks
fill 370 212 470 370 215 470 minecraft:pink_terracotta
setblock 370 212 474 minecraft:red_nether_bricks
fill 370 212 475 370 215 475 minecraft:pink_terracotta
setblock 370 212 479 minecraft:red_nether_bricks
fill 370 212 480 370 215 480 minecraft:pink_terracotta
setblock 370 212 484 minecraft:red_nether_bricks
fill 370 212 485 371 215 485 minecraft:pink_terracotta
setblock 370 212 489 minecraft:red_nether_bricks
setblock 370 212 500 minecraft:pink_terracotta
setblock 370 212 504 minecraft:red_nether_bricks
fill 371 212 463 371 213 463 minecraft:red_terracotta
fill 371 212 469 371 212 470 minecraft:red_terracotta
fill 371 212 473 371 213 474 minecraft:pink_terracotta
fill 371 212 475 371 213 475 minecraft:red_terracotta
fill 371 212 477 371 215 477 minecraft:pink_terracotta
fill 371 212 478 371 212 479 minecraft:red_terracotta
fill 371 212 483 371 217 483 minecraft:pink_terracotta
fill 371 212 484 371 213 484 minecraft:red_terracotta
fill 371 212 486 371 215 487 minecraft:pink_terracotta
fill 371 212 492 371 213 492 minecraft:pink_terracotta
setblock 371 212 493 minecraft:red_terracotta
fill 371 212 494 371 213 496 minecraft:pink_terracotta
fill 371 212 505 371 213 505 minecraft:red_terracotta
fill 329 213 463 329 213 464 minecraft:pink_terracotta
setblock 329 213 465 minecraft:red_terracotta
fill 329 213 466 329 213 467 minecraft:pink_terracotta
fill 329 213 470 329 214 470 minecraft:red_terracotta
fill 329 213 471 329 215 473 minecraft:pink_terracotta
fill 329 213 475 329 215 475 minecraft:pink_terracotta
setblock 329 213 476 minecraft:red_terracotta
setblock 329 213 478 minecraft:red_terracotta
fill 329 213 479 330 215 479 minecraft:pink_terracotta
setblock 329 213 494 minecraft:red_terracotta
fill 329 213 495 329 215 495 minecraft:pink_terracotta
fill 330 213 464 330 216 464 minecraft:pink_terracotta
setblock 330 213 468 minecraft:red_nether_bricks
fill 330 213 469 330 216 469 minecraft:pink_terracotta
setblock 330 213 473 minecraft:red_nether_bricks
fill 330 213 474 330 216 474 minecraft:pink_terracotta
setblock 330 213 478 minecraft:red_nether_bricks
setblock 330 213 483 minecraft:red_nether_bricks
fill 330 213 484 330 216 484 minecraft:pink_terracotta
fill 330 213 499 330 213 502 minecraft:pink_terracotta
setblock 330 213 503 minecraft:red_nether_bricks
fill 330 213 504 330 215 505 minecraft:pink_terracotta
setblock 331 213 467 minecraft:red_nether_bricks
fill 331 213 468 331 216 468 minecraft:pink_terracotta
setblock 331 213 477 minecraft:red_nether_bricks
fill 331 213 478 331 215 478 minecraft:pink_terracotta
setblock 331 213 482 minecraft:red_nether_bricks
fill 331 213 483 331 216 483 minecraft:pink_terracotta
setblock 331 213 502 minecraft:red_nether_bricks
fill 331 213 503 331 216 503 minecraft:pink_terracotta
fill 331 213 505 333 215 505 minecraft:pink_terracotta
setblock 332 213 466 minecraft:red_nether_bricks
fill 332 213 467 332 216 467 minecraft:pink_terracotta
setblock 333 213 465 minecraft:red_nether_bricks
fill 333 213 466 333 216 466 minecraft:pink_terracotta
setblock 334 213 464 minecraft:red_nether_bricks
fill 334 213 465 334 216 465 minecraft:pink_terracotta
setblock 334 213 504 minecraft:red_nether_bricks
setblock 334 213 505 minecraft:red_terracotta
fill 335 213 464 335 216 464 minecraft:pink_terracotta
setblock 335 213 503 minecraft:red_nether_bricks
fill 335 213 504 335 215 505 minecraft:pink_terracotta
setblock 336 213 502 minecraft:red_nether_bricks
fill 336 213 503 336 216 503 minecraft:pink_terracotta
fill 337 213 463 337 215 463 minecraft:pink_terracotta
setblock 338 213 465 minecraft:red_nether_bricks
fill 338 213 505 338 216 505 minecraft:pink_terracotta
setblock 339 213 464 minecraft:red_nether_bricks
setblock 339 213 504 minecraft:red_nether_bricks
setblock 339 213 505 minecraft:red_terracotta
fill 340 213 464 340 216 464 minecraft:pink_terracotta
setblock 340 213 503 minecraft:red_nether_bricks
fill 340 213 504 342 214 505 minecraft:pink_terracotta
fill 341 213 503 344 213 503 minecraft:pink_terracotta
setblock 343 213 504 minecraft:pink_terracotta
setblock 344 213 464 minecraft:red_nether_bricks
setblock 344 213 504 minecraft:red_nether_bricks
fill 345 213 464 348 213 464 minecraft:pink_terracotta
setblock 345 213 503 minecraft:red_nether_bricks
fill 345 213 504 345 216 504 minecraft:pink_terracotta
fill 346 213 503 346 216 503 minecraft:pink_terracotta
fill 347 213 463 347 215 463 minecraft:pink_terracotta
setblock 349 213 464 minecraft:red_nether_bricks
setblock 349 213 504 minecraft:red_nether_bricks
fill 350 213 464 350 216 464 minecraft:pink_terracotta
setblock 350 213 503 minecraft:red_nether_bricks
fill 350 213 504 350 216 504 minecraft:pink_terracotta
setblock 351 213 502 minecraft:red_nether_bricks
fill 351 213 503 351 216 503 minecraft:pink_terracotta
fill 352 213 463 355 213 463 minecraft:pink_terracotta
fill 352 213 502 352 216 502 minecraft:pink_terracotta
setblock 354 213 464 minecraft:red_nether_bricks
setblock 354 213 504 minecraft:red_nether_bricks
fill 355 213 464 355 216 464 minecraft:pink_terracotta
setblock 355 213 503 minecraft:red_nether_bricks
fill 355 213 504 355 216 504 minecraft:pink_terracotta
setblock 356 213 463 minecraft:red_terracotta
fill 356 213 503 356 215 503 minecraft:pink_terracotta
fill 356 213 505 356 215 505 minecraft:pink_terracotta
setblock 359 213 504 minecraft:red_nether_bricks
fill 363 213 463 363 215 463 minecraft:pink_terracotta
setblock 363 213 464 minecraft:white_concrete
setblock 368 213 464 minecraft:pink_terracotta
setblock 369 213 464 minecraft:red_nether_bricks
setblock 369 213 479 minecraft:red_nether_bricks
fill 369 213 480 369 216 480 minecraft:pink_terracotta
setblock 369 213 484 minecraft:red_nether_bricks
fill 369 213 485 369 216 485 minecraft:pink_terracotta
fill 369 213 487 369 214 487 minecraft:pink_terracotta
setblock 369 213 504 minecraft:red_nether_bricks
fill 370 213 464 370 216 464 minecraft:pink_terracotta
setblock 370 213 468 minecraft:red_nether_bricks
fill 370 213 469 371 215 469 minecraft:pink_terracotta
setblock 370 213 473 minecraft:red_nether_bricks
fill 370 213 474 370 216 474 minecraft:pink_terracotta
setblock 370 213 478 minecraft:red_nether_bricks
fill 370 213 479 370 216 479 minecraft:pink_terracotta
setblock 370 213 483 minecraft:red_nether_bricks
fill 370 213 484 370 216 484 minecraft:pink_terracotta
setblock 370 213 488 minecraft:red_nether_bricks
fill 370 213 489 370 216 489 minecraft:pink_terracotta
setblock 370 213 503 minecraft:red_nether_bricks
fill 370 213 504 370 216 504 minecraft:pink_terracotta
fill 371 213 470 371 216 470 minecraft:pink_terracotta
setblock 371 213 472 minecraft:red_terracotta
fill 371 213 478 371 215 478 minecraft:pink_terracotta
setblock 371 213 479 minecraft:red_terracotta
fill 371 213 493 371 215 493 minecraft:pink_terracotta
fill 371 213 500 371 215 500 minecraft:pink_terracotta
setblock 371 213 501 minecraft:red_terracotta
fill 371 213 502 371 215 503 minecraft:pink_terracotta
setblock 371 213 504 minecraft:red_terracotta
setblock 329 214 463 minecraft:red_terracotta
fill 329 214 464 329 215 466 minecraft:pink_terracotta
setblock 329 214 467 minecraft:red_terracotta
fill 329 214 476 329 215 476 minecraft:pink_terracotta
fill 329 214 478 330 215 478 minecraft:pink_terracotta
fill 329 214 480 329 215 485 minecraft:pink_terracotta
setblock 329 214 486 minecraft:red_terracotta
fill 329 214 487 329 215 487 minecraft:pink_terracotta
fill 329 214 494 329 215 494 minecraft:pink_terracotta
fill 329 214 502 329 215 502 minecraft:pink_terracotta
fill 329 214 503 329 214 504 minecraft:red_terracotta
fill 329 214 505 329 216 505 minecraft:pink_terracotta
setblock 330 214 467 minecraft:red_nether_bricks
fill 330 214 468 330 217 468 minecraft:pink_terracotta
setblock 330 214 472 minecraft:red_nether_bricks
fill 330 214 473 330 217 473 minecraft:pink_terracotta
setblock 330 214 477 minecraft:red_nether_bricks
setblock 330 214 482 minecraft:red_nether_bricks
fill 330 214 483 330 217 483 minecraft:pink_terracotta
setblock 330 214 487 minecraft:red_nether_bricks
fill 330 214 488 330 217 488 minecraft:pink_terracotta
setblock 330 214 492 minecraft:white_concrete
fill 330 214 499 330 214 501 minecraft:pink_terracotta
setblock 330 214 502 minecraft:red_nether_bricks
fill 330 214 503 330 217 503 minecraft:pink_terracotta
setblock 331 214 466 minecraft:red_nether_bricks
fill 331 214 467 331 217 467 minecraft:pink_terracotta
setblock 331 214 471 minecraft:red_nether_bricks
setblock 331 214 477 minecraft:pink_terracotta
setblock 331 214 481 minecraft:red_nether_bricks
fill 331 214 482 331 217 482 minecraft:pink_terracotta
setblock 331 214 501 minecraft:red_nether_bricks
fill 331 214 502 331 217 502 minecraft:pink_terracotta
setblock 332 214 465 minecraft:red_nether_bricks
fill 332 214 466 332 217 466 minecraft:pink_terracotta
setblock 333 214 464 minecraft:red_nether_bricks
fill 333 214 465 333 217 465 minecraft:pink_terracotta
setblock 333 214 504 minecraft:red_nether_bricks
fill 334 214 464 334 217 464 minecraft:pink_terracotta
setblock 334 214 503 minecraft:red_nether_bricks
fill 334 214 504 334 215 505 minecraft:pink_terracotta
fill 335 214 503 335 217 503 minecraft:pink_terracotta
setblock 337 214 465 minecraft:red_nether_bricks
setblock 338 214 464 minecraft:red_nether_bricks
fill 338 214 465 338 217 465 minecraft:pink_terracotta
setblock 338 214 504 minecraft:red_nether_bricks
fill 339 214 464 339 217 464 minecraft:pink_terracotta
setblock 339 214 503 minecraft:red_nether_bricks
fill 339 214 504 339 215 505 minecraft:pink_terracotta
fill 340 214 463 341 215 463 minecraft:pink_terracotta
fill 340 214 503 341 214 503 minecraft:pink_terracotta
setblock 342 214 463 minecraft:red_terracotta
fill 343 214 463 343 215 463 minecraft:pink_terracotta
setblock 343 214 464 minecraft:red_nether_bricks
setblock 343 214 504 minecraft:red_nether_bricks
fill 344 214 464 347 214 464 minecraft:pink_terracotta
setblock 344 214 503 minecraft:red_nether_bricks
fill 344 214 504 344 217 504 minecraft:pink_terracotta
fill 345 214 503 345 217 503 minecraft:pink_terracotta
fill 346 214 505 346 215 505 minecraft:pink_terracotta
setblock 347 214 505 minecraft:red_terracotta
setblock 348 214 464 minecraft:red_nether_bricks
setblock 348 214 504 minecraft:red_nether_bricks
fill 348 214 505 350 215 505 minecraft:pink_terracotta
fill 349 214 464 349 217 464 minecraft:pink_terracotta
setblock 349 214 503 minecraft:red_nether_bricks
fill 349 214 504 349 217 504 minecraft:pink_terracotta
setblock 350 214 502 minecraft:red_nether_bricks
fill 350 214 503 350 217 503 minecraft:pink_terracotta
fill 351 214 502 351 217 502 minecraft:pink_terracotta
setblock 352 214 463 minecraft:red_terracotta
fill 352 214 505 353 215 505 minecraft:pink_terracotta
fill 353 214 463 356 215 463 minecraft:pink_terracotta
setblock 353 214 464 minecraft:red_nether_bricks
setblock 353 214 504 minecraft:red_nether_bricks
fill 354 214 464 354 217 464 minecraft:pink_terracotta
setblock 354 214 503 minecraft:red_nether_bricks
fill 354 214 504 354 217 504 minecraft:pink_terracotta
setblock 354 214 505 minecraft:red_terracotta
fill 355 214 503 355 217 503 minecraft:pink_terracotta
fill 355 214 505 355 217 505 minecraft:pink_terracotta
setblock 358 214 504 minecraft:red_nether_bricks
setblock 359 214 504 minecraft:pink_terracotta
setblock 362 214 504 minecraft:white_concrete
fill 364 214 505 366 215 505 minecraft:pink_terracotta
setblock 367 214 464 minecraft:pink_terracotta
setblock 367 214 505 minecraft:red_terracotta
setblock 368 214 464 minecraft:red_nether_bricks
setblock 368 214 483 minecraft:pink_terracotta
setblock 368 214 504 minecraft:red_nether_bricks
fill 368 214 505 368 215 505 minecraft:pink_terracotta
fill 369 214 464 369 216 465 minecraft:pink_terracotta
setblock 369 214 478 minecraft:red_nether_bricks
fill 369 214 479 369 217 479 minecraft:pink_terracotta
setblock 369 214 483 minecraft:red_nether_bricks
fill 369 214 484 369 217 484 minecraft:pink_terracotta
fill 369 214 504 369 217 504 minecraft:pink_terracotta
setblock 370 214 466 minecraft:pink_terracotta
setblock 370 214 467 minecraft:red_nether_bricks
fill 370 214 468 370 217 468 minecraft:pink_terracotta
setblock 370 214 472 minecraft:red_nether_bricks
fill 370 214 473 371 215 473 minecraft:pink_terracotta
setblock 370 214 477 minecraft:red_nether_bricks
fill 370 214 478 370 217 478 minecraft:pink_terracotta
setblock 370 214 482 minecraft:red_nether_bricks
fill 370 214 483 370 217 483 minecraft:pink_terracotta
setblock 370 214 487 minecraft:red_nether_bricks
fill 370 214 488 370 217 488 minecraft:pink_terracotta
fill 370 214 490 370 215 490 minecraft:pink_terracotta
setblock 370 214 495 minecraft:white_concrete
setblock 370 214 502 minecraft:red_nether_bricks
fill 370 214 503 370 217 503 minecraft:pink_terracotta
fill 371 214 463 371 215 463 minecraft:pink_terracotta
fill 371 214 472 371 215 472 minecraft:pink_terracotta
setblock 371 214 474 minecraft:red_terracotta
fill 371 214 475 371 215 475 minecraft:pink_terracotta
fill 371 214 479 371 215 479 minecraft:pink_terracotta
fill 371 214 484 371 215 484 minecraft:pink_terracotta
setblock 371 214 492 minecraft:red_terracotta
fill 371 214 494 371 215 494 minecraft:pink_terracotta
setblock 371 214 495 minecraft:red_terracotta
fill 371 214 496 371 215 496 minecraft:pink_terracotta
fill 371 214 501 371 215 501 minecraft:pink_terracotta
fill 371 214 504 371 215 505 minecraft:pink_terracotta
setblock 329 215 463 minecraft:pink_terracotta
fill 329 215 467 330 216 467 minecraft:pink_terracotta
setblock 329 215 470 minecraft:pink_terracotta
setblock 329 215 486 minecraft:pink_terracotta
fill 329 215 503 329 215 504 minecraft:pink_terracotta
setblock 330 215 466 minecraft:red_nether_bricks
setblock 330 215 471 minecraft:red_nether_bricks
fill 330 215 472 330 218 472 minecraft:pink_terracotta
setblock 330 215 476 minecraft:red_nether_bricks
fill 330 215 477 330 218 477 minecraft:pink_terracotta
setblock 330 215 481 minecraft:red_nether_bricks
fill 330 215 482 330 218 482 minecraft:pink_terracotta
setblock 330 215 485 minecraft:pink_terracotta
setblock 330 215 486 minecraft:red_nether_bricks
fill 330 215 487 330 218 487 minecraft:pink_terracotta
fill 330 215 489 330 216 489 minecraft:pink_terracotta
setblock 330 215 498 minecraft:white_concrete
fill 330 215 499 330 215 500 minecraft:pink_terracotta
setblock 330 215 501 minecraft:red_nether_bricks
fill 330 215 502 330 218 502 minecraft:pink_terracotta
setblock 331 215 465 minecraft:red_nether_bricks
fill 331 215 466 331 218 466 minecraft:pink_terracotta
setblock 331 215 470 minecraft:red_nether_bricks
fill 331 215 471 331 218 471 minecraft:pink_terracotta
setblock 331 215 480 minecraft:red_nether_bricks
fill 331 215 481 331 218 481 minecraft:pink_terracotta
setblock 331 215 485 minecraft:red_nether_bricks
fill 331 215 486 331 218 486 minecraft:pink_terracotta
fill 331 215 501 331 218 501 minecraft:pink_terracotta
setblock 332 215 464 minecraft:red_nether_bricks
fill 332 215 465 332 218 465 minecraft:pink_terracotta
setblock 332 215 468 minecraft:pink_terracotta
setblock 332 215 504 minecraft:red_nether_bricks
fill 333 215 464 333 218 464 minecraft:pink_terracotta
setblock 333 215 503 minecraft:red_nether_bricks
fill 333 215 504 333 218 504 minecraft:pink_terracotta
fill 334 215 503 334 218 503 minecraft:pink_terracotta
setblock 335 215 466 minecraft:red_nether_bricks
setblock 336 215 465 minecraft:red_nether_bricks
setblock 337 215 464 minecraft:red_nether_bricks
fill 337 215 465 337 218 465 minecraft:pink_terracotta
setblock 337 215 504 minecraft:red_nether_bricks
fill 338 215 464 338 218 464 minecraft:pink_terracotta
setblock 338 215 503 minecraft:red_nether_bricks
fill 338 215 504 338 218 504 minecraft:pink_terracotta
fill 339 215 503 340 215 503 minecraft:pink_terracotta
fill 340 215 504 341 215 505 minecraft:pink_terracotta
setblock 342 215 463 minecraft:pink_terracotta
setblock 342 215 464 minecraft:red_nether_bricks
setblock 342 215 504 minecraft:red_nether_bricks
setblock 342 215 505 minecraft:pink_terracotta
fill 343 215 464 346 215 464 minecraft:pink_terracotta
fill 343 215 504 343 218 504 minecraft:pink_terracotta
fill 344 215 503 344 218 503 minecraft:pink_terracotta
setblock 347 215 464 minecraft:red_nether_bricks
setblock 347 215 504 minecraft:red_nether_bricks
setblock 347 215 505 minecraft:pink_terracotta
fill 348 215 464 348 218 464 minecraft:pink_terracotta
setblock 348 215 503 minecraft:red_nether_bricks
fill 348 215 504 348 218 504 minecraft:pink_terracotta
setblock 349 215 502 minecraft:red_nether_bricks
fill 349 215 503 349 218 503 minecraft:pink_terracotta
setblock 350 215 465 minecraft:pink_terracotta
fill 350 215 502 350 218 502 minecraft:pink_terracotta
setblock 351 215 465 minecraft:red_nether_bricks
setblock 352 215 463 minecraft:pink_terracotta
setblock 352 215 464 minecraft:red_nether_bricks
fill 352 215 465 352 218 465 minecraft:pink_terracotta
setblock 352 215 504 minecraft:red_nether_bricks
fill 353 215 464 353 218 464 minecraft:pink_terracotta
setblock 353 215 503 minecraft:red_nether_bricks
fill 353 215 504 353 218 504 minecraft:pink_terracotta
fill 354 215 503 354 218 503 minecraft:pink_terracotta
setblock 354 215 505 minecraft:pink_terracotta
setblock 357 215 464 minecraft:red_nether_bricks
setblock 357 215 504 minecraft:red_nether_bricks
fill 358 215 504 358 216 504 minecraft:pink_terracotta
setblock 366 215 464 minecraft:pink_terracotta
setblock 367 215 464 minecraft:red_nether_bricks
setblock 367 215 505 minecraft:pink_terracotta
fill 368 215 464 368 217 465 minecraft:pink_terracotta
fill 368 215 481 368 216 481 minecraft:pink_terracotta
setblock 368 215 483 minecraft:red_nether_bricks
fill 368 215 484 368 217 485 minecraft:pink_terracotta
fill 368 215 504 368 218 504 minecraft:pink_terracotta
setblock 369 215 466 minecraft:pink_terracotta
setblock 369 215 467 minecraft:red_nether_bricks
fill 369 215 468 369 218 468 minecraft:pink_terracotta
setblock 369 215 476 minecraft:pink_terracotta
setblock 369 215 477 minecraft:red_nether_bricks
fill 369 215 478 369 218 478 minecraft:pink_terracotta
setblock 369 215 482 minecraft:red_nether_bricks
fill 369 215 483 369 218 483 minecraft:pink_terracotta
setblock 369 215 487 minecraft:red_nether_bricks
fill 369 215 488 369 218 488 minecraft:pink_terracotta
setblock 370 215 466 minecraft:red_nether_bricks
fill 370 215 467 370 218 467 minecraft:pink_terracotta
setblock 370 215 471 minecraft:red_nether_bricks
fill 370 215 472 370 218 472 minecraft:pink_terracotta
setblock 370 215 476 minecraft:red_nether_bricks
fill 370 215 477 370 218 477 minecraft:pink_terracotta
setblock 370 215 481 minecraft:red_nether_bricks
fill 370 215 482 370 218 482 minecraft:pink_terracotta
setblock 370 215 486 minecraft:red_nether_bricks
fill 370 215 487 370 218 487 minecraft:pink_terracotta
setblock 370 215 491 minecraft:red_nether_bricks
setblock 370 215 501 minecraft:red_nether_bricks
fill 370 215 502 370 218 502 minecraft:pink_terracotta
setblock 371 215 474 minecraft:pink_terracotta
setblock 371 215 492 minecraft:pink_terracotta
setblock 371 215 495 minecraft:pink_terracotta
fill 329 216 463 329 216 466 minecraft:red_terracotta
fill 329 216 468 329 216 472 minecraft:red_terracotta
setblock 329 216 473 minecraft:pink_terracotta
fill 329 216 474 329 216 484 minecraft:red_terracotta
setblock 329 216 485 minecraft:pink_terracotta
fill 329 216 486 329 216 497 minecraft:red_terracotta
setblock 329 216 498 minecraft:pink_terracotta
fill 329 216 499 329 217 504 minecraft:red_terracotta
fill 330 216 463 371 216 463 minecraft:red_terracotta
setblock 330 216 465 minecraft:red_nether_bricks
fill 330 216 466 330 219 466 minecraft:pink_terracotta
setblock 330 216 470 minecraft:red_nether_bricks
fill 330 216 471 330 219 471 minecraft:pink_terracotta
setblock 330 216 475 minecraft:red_nether_bricks
fill 330 216 476 330 219 476 minecraft:pink_terracotta
fill 330 216 478 330 216 479 minecraft:pink_terracotta
setblock 330 216 480 minecraft:red_nether_bricks
fill 330 216 481 330 219 481 minecraft:pink_terracotta
setblock 330 216 485 minecraft:red_nether_bricks
fill 330 216 486 330 219 486 minecraft:pink_terracotta
setblock 330 216 490 minecraft:red_nether_bricks
setblock 330 216 499 minecraft:pink_terracotta
setblock 330 216 500 minecraft:red_nether_bricks
fill 330 216 501 330 219 501 minecraft:pink_terracotta
setblock 330 216 504 minecraft:pink_terracotta
fill 330 216 505 337 216 505 minecraft:red_terracotta
setblock 331 216 464 minecraft:red_nether_bricks
fill 331 216 465 331 219 465 minecraft:pink_terracotta
setblock 331 216 469 minecraft:red_nether_bricks
fill 331 216 470 331 219 470 minecraft:pink_terracotta
fill 331 216 472 331 217 472 minecraft:pink_terracotta
setblock 331 216 479 minecraft:red_nether_bricks
fill 331 216 480 331 218 480 minecraft:pink_terracotta
setblock 331 216 484 minecraft:red_nether_bricks
fill 331 216 485 331 219 485 minecraft:pink_terracotta
fill 331 216 487 331 217 487 minecraft:pink_terracotta
setblock 331 216 504 minecraft:red_nether_bricks
fill 332 216 464 332 219 464 minecraft:pink_terracotta
setblock 332 216 468 minecraft:red_nether_bricks
fill 332 216 469 332 219 469 minecraft:pink_terracotta
fill 332 216 483 332 219 483 minecraft:white_concrete
setblock 332 216 503 minecraft:red_nether_bricks
fill 332 216 504 332 219 504 minecraft:pink_terracotta
fill 333 216 503 333 219 503 minecraft:pink_terracotta
setblock 334 216 466 minecraft:red_nether_bricks
fill 334 216 504 335 216 504 minecraft:pink_terracotta
setblock 335 216 465 minecraft:red_nether_bricks
fill 335 216 466 335 219 466 minecraft:pink_terracotta
setblock 336 216 464 minecraft:red_nether_bricks
fill 336 216 465 336 219 465 minecraft:pink_terracotta
setblock 336 216 504 minecraft:red_nether_bricks
fill 337 216 464 337 219 464 minecraft:pink_terracotta
setblock 337 216 503 minecraft:red_nether_bricks
fill 337 216 504 337 219 504 minecraft:pink_terracotta
fill 338 216 503 339 217 503 minecraft:pink_terracotta
setblock 339 216 465 minecraft:pink_terracotta
fill 339 216 504 340 216 504 minecraft:pink_terracotta
fill 339 216 505 339 307 505 minecraft:red_terracotta
setblock 340 216 505 minecraft:pink_terracotta
setblock 341 216 464 minecraft:red_nether_bricks
setblock 341 216 504 minecraft:red_nether_bricks
fill 341 216 505 347 216 505 minecraft:red_terracotta
fill 342 216 464 345 216 464 minecraft:pink_terracotta
fill 342 216 504 342 219 504 minecraft:pink_terracotta
fill 343 216 503 343 219 503 minecraft:pink_terracotta
setblock 346 216 464 minecraft:red_nether_bricks
setblock 346 216 504 minecraft:red_nether_bricks
fill 347 216 464 347 219 464 minecraft:pink_terracotta
setblock 347 216 503 minecraft:red_nether_bricks
fill 347 216 504 347 219 504 minecraft:pink_terracotta
fill 348 216 465 349 216 465 minecraft:pink_terracotta
fill 348 216 503 348 219 503 minecraft:pink_terracotta
setblock 348 216 505 minecraft:pink_terracotta
fill 349 216 502 349 219 502 minecraft:pink_terracotta
fill 349 216 505 354 216 505 minecraft:red_terracotta
setblock 350 216 465 minecraft:red_nether_bricks
setblock 351 216 464 minecraft:red_nether_bricks
fill 351 216 465 351 219 465 minecraft:pink_terracotta
setblock 351 216 504 minecraft:red_nether_bricks
fill 352 216 464 352 219 464 minecraft:pink_terracotta
setblock 352 216 503 minecraft:red_nether_bricks
fill 352 216 504 352 219 504 minecraft:pink_terracotta
fill 353 216 465 353 217 465 minecraft:pink_terracotta
fill 353 216 503 353 219 503 minecraft:pink_terracotta
setblock 356 216 464 minecraft:red_nether_bricks
setblock 356 216 504 minecraft:red_nether_bricks
fill 356 216 505 371 217 505 minecraft:red_terracotta
fill 357 216 464 357 219 464 minecraft:pink_terracotta
fill 357 216 504 357 218 504 minecraft:pink_terracotta
setblock 364 216 464 minecraft:white_concrete
setblock 365 216 464 minecraft:pink_terracotta
setblock 366 216 464 minecraft:red_nether_bricks
fill 367 216 464 367 218 465 minecraft:pink_terracotta
fill 367 216 504 367 219 504 minecraft:pink_terracotta
setblock 368 216 482 minecraft:red_nether_bricks
fill 368 216 483 368 219 483 minecraft:pink_terracotta
setblock 368 216 486 minecraft:pink_terracotta
setblock 369 216 466 minecraft:red_nether_bricks
fill 369 216 467 369 219 467 minecraft:pink_terracotta
fill 369 216 469 369 216 470 minecraft:pink_terracotta
setblock 369 216 471 minecraft:red_nether_bricks
fill 369 216 472 369 219 472 minecraft:pink_terracotta
setblock 369 216 475 minecraft:pink_terracotta
setblock 369 216 476 minecraft:red_nether_bricks
fill 369 216 477 369 219 477 minecraft:pink_terracotta
setblock 369 216 481 minecraft:red_nether_bricks
fill 369 216 482 369 219 482 minecraft:pink_terracotta
setblock 369 216 486 minecraft:red_nether_bricks
fill 369 216 487 369 219 487 minecraft:pink_terracotta
fill 369 216 489 369 217 489 minecraft:pink_terracotta
setblock 370 216 465 minecraft:red_nether_bricks
fill 370 216 466 370 219 466 minecraft:pink_terracotta
setblock 370 216 469 minecraft:pink_terracotta
setblock 370 216 470 minecraft:red_nether_bricks
fill 370 216 471 370 219 471 minecraft:pink_terracotta
fill 370 216 473 370 217 473 minecraft:pink_terracotta
setblock 370 216 475 minecraft:red_nether_bricks
fill 370 216 476 370 219 476 minecraft:pink_terracotta
setblock 370 216 480 minecraft:red_nether_bricks
fill 370 216 481 370 219 481 minecraft:pink_terracotta
setblock 370 216 485 minecraft:red_nether_bricks
fill 370 216 486 370 219 486 minecraft:pink_terracotta
setblock 370 216 490 minecraft:red_nether_bricks
fill 370 216 491 370 219 491 minecraft:pink_terracotta
fill 370 216 501 370 219 501 minecraft:pink_terracotta
setblock 371 216 464 minecraft:pink_terracotta
fill 371 216 465 371 217 469 minecraft:red_terracotta
fill 371 216 471 371 216 482 minecraft:red_terracotta
fill 371 216 484 371 216 498 minecraft:red_terracotta
setblock 371 216 499 minecraft:pink_terracotta
fill 371 216 500 371 307 504 minecraft:red_terracotta
fill 329 217 463 329 307 464 minecraft:red_terracotta
fill 329 217 465 330 217 465 minecraft:pink_terracotta
fill 329 217 466 329 217 468 minecraft:red_terracotta
setblock 329 217 469 minecraft:pink_terracotta
fill 329 217 470 329 307 470 minecraft:red_terracotta
setblock 329 217 471 minecraft:pink_terracotta
fill 329 217 472 329 217 479 minecraft:red_terracotta
fill 329 217 480 330 217 480 minecraft:pink_terracotta
fill 329 217 481 329 307 481 minecraft:red_terracotta
setblock 329 217 482 minecraft:pink_terracotta
fill 329 217 483 329 307 485 minecraft:red_terracotta
setblock 329 217 486 minecraft:pink_terracotta
fill 329 217 487 329 217 498 minecraft:red_terracotta
fill 329 217 505 329 307 505 minecraft:red_terracotta
fill 330 217 463 330 307 463 minecraft:red_terracotta
setblock 330 217 464 minecraft:red_nether_bricks
fill 330 217 467 330 218 467 minecraft:pink_terracotta
setblock 330 217 469 minecraft:red_nether_bricks
fill 330 217 470 330 220 470 minecraft:pink_terracotta
setblock 330 217 474 minecraft:red_nether_bricks
fill 330 217 475 330 220 475 minecraft:pink_terracotta
setblock 330 217 478 minecraft:pink_terracotta
setblock 330 217 479 minecraft:red_nether_bricks
setblock 330 217 484 minecraft:red_nether_bricks
fill 330 217 485 330 220 485 minecraft:pink_terracotta
setblock 330 217 489 minecraft:red_nether_bricks
fill 330 217 490 330 218 492 minecraft:pink_terracotta
setblock 330 217 498 minecraft:pink_terracotta
setblock 330 217 499 minecraft:red_nether_bricks
fill 330 217 500 330 220 500 minecraft:pink_terracotta
setblock 330 217 504 minecraft:red_nether_bricks
setblock 330 217 505 minecraft:pink_terracotta
fill 331 217 463 331 217 464 minecraft:pink_terracotta
setblock 331 217 468 minecraft:red_nether_bricks
fill 331 217 469 331 220 469 minecraft:pink_terracotta
setblock 331 217 473 minecraft:red_nether_bricks
setblock 331 217 483 minecraft:red_nether_bricks
fill 331 217 484 331 220 484 minecraft:pink_terracotta
setblock 331 217 488 minecraft:red_nether_bricks
fill 331 217 489 331 220 489 minecraft:pink_terracotta
setblock 331 217 503 minecraft:red_nether_bricks
fill 331 217 504 331 220 504 minecraft:pink_terracotta
fill 331 217 505 334 307 505 minecraft:red_terracotta
setblock 332 217 463 minecraft:pink_terracotta
setblock 332 217 467 minecraft:red_nether_bricks
fill 332 217 468 332 220 468 minecraft:pink_terracotta
fill 332 217 470 332 218 470 minecraft:pink_terracotta
setblock 332 217 474 minecraft:light[level=12]
fill 332 217 482 332 220 482 minecraft:white_concrete
fill 332 217 484 332 218 484 minecraft:white_concrete
setblock 332 217 490 minecraft:light[level=12]
setblock 332 217 498 minecraft:light[level=12]
fill 332 217 503 332 220 503 minecraft:pink_terracotta
fill 333 217 463 345 217 463 minecraft:red_terracotta
setblock 333 217 466 minecraft:red_nether_bricks
fill 333 217 483 333 218 483 minecraft:red_concrete
setblock 334 217 465 minecraft:red_nether_bricks
fill 334 217 466 334 220 466 minecraft:pink_terracotta
setblock 334 217 504 minecraft:pink_terracotta
setblock 335 217 464 minecraft:red_nether_bricks
fill 335 217 465 335 220 465 minecraft:pink_terracotta
setblock 335 217 504 minecraft:red_nether_bricks
fill 335 217 505 335 218 505 minecraft:pink_terracotta
fill 336 217 464 336 220 464 minecraft:pink_terracotta
fill 336 217 466 336 218 466 minecraft:pink_terracotta
setblock 336 217 503 minecraft:red_nether_bricks
fill 336 217 504 336 220 504 minecraft:pink_terracotta
fill 336 217 505 338 307 505 minecraft:red_terracotta
fill 337 217 503 337 220 503 minecraft:pink_terracotta
setblock 339 217 465 minecraft:red_nether_bricks
setblock 339 217 504 minecraft:pink_terracotta
setblock 340 217 464 minecraft:red_nether_bricks
setblock 340 217 466 minecraft:light[level=12]
setblock 340 217 474 minecraft:light[level=12]
setblock 340 217 482 minecraft:light[level=12]
setblock 340 217 490 minecraft:light[level=12]
setblock 340 217 498 minecraft:light[level=12]
setblock 340 217 504 minecraft:red_nether_bricks
fill 340 217 505 341 307 505 minecraft:red_terracotta
fill 341 217 464 344 217 464 minecraft:pink_terracotta
fill 341 217 504 341 220 504 minecraft:pink_terracotta
setblock 342 217 505 minecraft:pink_terracotta
fill 343 217 505 344 307 505 minecraft:red_terracotta
setblock 345 217 464 minecraft:red_nether_bricks
setblock 345 217 504 minecraft:red_nether_bricks
setblock 345 217 505 minecraft:pink_terracotta
fill 346 217 463 346 217 465 minecraft:pink_terracotta
setblock 346 217 503 minecraft:red_nether_bricks
fill 346 217 504 346 220 504 minecraft:pink_terracotta
fill 346 217 505 353 307 505 minecraft:red_terracotta
fill 347 217 463 361 217 463 minecraft:red_terracotta
fill 347 217 465 348 217 465 minecraft:pink_terracotta
fill 347 217 503 347 220 503 minecraft:pink_terracotta
setblock 348 217 466 minecraft:light[level=12]
setblock 348 217 474 minecraft:light[level=12]
setblock 348 217 482 minecraft:light[level=12]
setblock 348 217 490 minecraft:light[level=12]
setblock 348 217 498 minecraft:light[level=12]
fill 348 217 502 348 220 502 minecraft:pink_terracotta
setblock 349 217 465 minecraft:red_nether_bricks
setblock 350 217 464 minecraft:red_nether_bricks
fill 350 217 465 350 220 465 minecraft:pink_terracotta
setblock 350 217 504 minecraft:red_nether_bricks
fill 351 217 464 351 220 464 minecraft:pink_terracotta
setblock 351 217 503 minecraft:red_nether_bricks
fill 351 217 504 351 220 504 minecraft:pink_terracotta
fill 352 217 503 352 220 503 minecraft:pink_terracotta
setblock 354 217 465 minecraft:red_nether_bricks
setblock 354 217 505 minecraft:pink_terracotta
setblock 355 217 464 minecraft:red_nether_bricks
setblock 355 217 504 minecraft:red_nether_bricks
fill 356 217 464 356 220 464 minecraft:pink_terracotta
setblock 356 217 466 minecraft:light[level=12]
setblock 356 217 474 minecraft:light[level=12]
setblock 356 217 482 minecraft:light[level=12]
setblock 356 217 490 minecraft:light[level=12]
setblock 356 217 498 minecraft:light[level=12]
fill 356 217 504 356 219 504 minecraft:pink_terracotta
setblock 358 217 464 minecraft:white_concrete
setblock 361 217 504 minecraft:white_concrete
setblock 362 217 463 minecraft:pink_terracotta
fill 363 217 463 365 217 463 minecraft:red_terracotta
fill 363 217 464 364 217 464 minecraft:pink_terracotta
setblock 364 217 466 minecraft:light[level=12]
setblock 364 217 474 minecraft:light[level=12]
setblock 364 217 482 minecraft:light[level=12]
setblock 364 217 490 minecraft:light[level=12]
setblock 364 217 498 minecraft:light[level=12]
setblock 365 217 464 minecraft:red_nether_bricks
fill 366 217 463 366 217 465 minecraft:pink_terracotta
fill 366 217 504 366 220 504 minecraft:pink_terracotta
fill 367 217 463 369 307 463 minecraft:red_terracotta
setblock 368 217 466 minecraft:red_nether_bricks
fill 368 217 467 368 219 468 minecraft:pink_terracotta
setblock 368 217 480 minecraft:pink_terracotta
setblock 368 217 481 minecraft:red_nether_bricks
fill 368 217 482 368 220 482 minecraft:pink_terracotta
setblock 368 217 486 minecraft:red_nether_bricks
fill 368 217 487 368 220 487 minecraft:pink_terracotta
setblock 369 217 464 minecraft:pink_terracotta
setblock 369 217 465 minecraft:red_nether_bricks
fill 369 217 466 369 220 466 minecraft:pink_terracotta
setblock 369 217 469 minecraft:pink_terracotta
setblock 369 217 470 minecraft:red_nether_bricks
fill 369 217 471 369 220 471 minecraft:pink_terracotta
fill 369 217 473 369 217 474 minecraft:pink_terracotta
setblock 369 217 475 minecraft:red_nether_bricks
fill 369 217 476 369 220 476 minecraft:pink_terracotta
setblock 369 217 480 minecraft:red_nether_bricks
fill 369 217 481 369 220 481 minecraft:pink_terracotta
setblock 369 217 485 minecraft:red_nether_bricks
fill 369 217 486 369 220 486 minecraft:pink_terracotta
setblock 369 217 490 minecraft:red_nether_bricks
setblock 370 217 463 minecraft:pink_terracotta
setblock 370 217 464 minecraft:red_nether_bricks
fill 370 217 465 370 220 465 minecraft:pink_terracotta
setblock 370 217 469 minecraft:red_nether_bricks
fill 370 217 470 370 220 470 minecraft:pink_terracotta
setblock 370 217 474 minecraft:red_nether_bricks
fill 370 217 475 371 218 475 minecraft:pink_terracotta
setblock 370 217 479 minecraft:red_nether_bricks
fill 370 217 480 370 220 480 minecraft:pink_terracotta
setblock 370 217 484 minecraft:red_nether_bricks
fill 370 217 485 370 220 485 minecraft:pink_terracotta
setblock 370 217 489 minecraft:red_nether_bricks
fill 370 217 490 370 220 490 minecraft:pink_terracotta
fill 370 217 492 370 217 493 minecraft:pink_terracotta
setblock 370 217 496 minecraft:white_concrete
setblock 370 217 504 minecraft:red_nether_bricks
fill 371 217 463 371 307 464 minecraft:red_terracotta
fill 371 217 470 371 307 471 minecraft:red_terracotta
setblock 371 217 472 minecraft:pink_terracotta
fill 371 217 473 371 307 473 minecraft:red_terracotta
setblock 371 217 474 minecraft:pink_terracotta
fill 371 217 476 371 217 477 minecraft:red_terracotta
fill 371 217 478 371 217 479 minecraft:pink_terracotta
fill 371 217 480 371 307 482 minecraft:red_terracotta
fill 371 217 484 371 307 486 minecraft:red_terracotta
setblock 371 217 487 minecraft:pink_terracotta
fill 371 217 488 371 307 492 minecraft:red_terracotta
fill 371 217 493 371 218 493 minecraft:pink_terracotta
fill 371 217 494 371 307 499 minecraft:red_terracotta
fill 329 218 465 329 307 467 minecraft:red_terracotta
setblock 329 218 468 minecraft:pink_terracotta
fill 329 218 469 329 307 469 minecraft:red_terracotta
fill 329 218 471 329 307 475 minecraft:red_terracotta
setblock 329 218 476 minecraft:pink_terracotta
fill 329 218 477 329 307 480 minecraft:red_terracotta
fill 329 218 482 329 307 482 minecraft:red_terracotta
fill 329 218 486 329 307 493 minecraft:red_terracotta
fill 329 218 494 330 218 494 minecraft:pink_terracotta
fill 329 218 495 329 307 496 minecraft:red_terracotta
fill 329 218 497 330 218 497 minecraft:pink_terracotta
fill 329 218 498 329 307 498 minecraft:red_terracotta
fill 329 218 499 330 218 499 minecraft:pink_terracotta
fill 329 218 500 329 307 504 minecraft:red_terracotta
fill 330 218 464 330 220 465 minecraft:pink_terracotta
setblock 330 218 468 minecraft:red_nether_bricks
fill 330 218 469 330 221 469 minecraft:pink_terracotta
setblock 330 218 473 minecraft:red_nether_bricks
fill 330 218 474 331 220 474 minecraft:pink_terracotta
setblock 330 218 478 minecraft:red_nether_bricks
fill 330 218 479 330 220 480 minecraft:pink_terracotta
setblock 330 218 483 minecraft:red_nether_bricks
fill 330 218 484 330 221 484 minecraft:pink_terracotta
setblock 330 218 488 minecraft:red_nether_bricks
fill 330 218 489 330 221 489 minecraft:pink_terracotta
setblock 330 218 493 minecraft:red_nether_bricks
fill 330 218 495 330 219 496 minecraft:pink_terracotta
setblock 330 218 498 minecraft:red_nether_bricks
setblock 330 218 503 minecraft:red_nether_bricks
fill 330 218 504 330 221 504 minecraft:pink_terracotta
fill 330 218 505 330 307 505 minecraft:red_terracotta
fill 331 218 463 344 307 463 minecraft:red_terracotta
fill 331 218 464 331 220 464 minecraft:pink_terracotta
setblock 331 218 467 minecraft:red_nether_bricks
fill 331 218 468 331 221 468 minecraft:pink_terracotta
setblock 331 218 472 minecraft:red_nether_bricks
fill 331 218 473 331 221 473 minecraft:pink_terracotta
setblock 331 218 482 minecraft:red_nether_bricks
fill 331 218 483 331 220 483 minecraft:pink_terracotta
setblock 331 218 487 minecraft:red_nether_bricks
fill 331 218 488 331 221 488 minecraft:pink_terracotta
fill 331 218 490 331 219 490 minecraft:pink_terracotta
fill 331 218 500 331 219 500 minecraft:pink_terracotta
setblock 331 218 502 minecraft:red_nether_bricks
fill 331 218 503 331 221 503 minecraft:pink_terracotta
setblock 332 218 466 minecraft:red_nether_bricks
fill 332 218 467 333 220 467 minecraft:pink_terracotta
fill 332 218 481 332 221 481 minecraft:white_concrete
setblock 333 218 465 minecraft:red_nether_bricks
fill 333 218 466 333 221 466 minecraft:pink_terracotta
setblock 334 218 464 minecraft:red_nether_bricks
fill 334 218 465 334 221 465 minecraft:pink_terracotta
setblock 334 218 504 minecraft:red_nether_bricks
fill 335 218 464 335 221 464 minecraft:pink_terracotta
setblock 335 218 503 minecraft:red_nether_bricks
fill 335 218 504 335 221 504 minecraft:pink_terracotta
fill 336 218 503 336 220 503 minecraft:pink_terracotta
setblock 338 218 465 minecraft:red_nether_bricks
fill 338 218 503 338 219 503 minecraft:pink_terracotta
setblock 339 218 464 minecraft:red_nether_bricks
fill 339 218 465 340 220 465 minecraft:pink_terracotta
setblock 339 218 504 minecraft:red_nether_bricks
fill 340 218 464 343 218 464 minecraft:pink_terracotta
fill 340 218 504 340 221 504 minecraft:pink_terracotta
fill 342 218 503 342 220 503 minecraft:pink_terracotta
fill 342 218 505 342 307 505 minecraft:red_terracotta
setblock 344 218 464 minecraft:red_nether_bricks
fill 344 218 465 347 218 465 minecraft:pink_terracotta
setblock 344 218 504 minecraft:red_nether_bricks
fill 345 218 463 345 218 464 minecraft:pink_terracotta
setblock 345 218 503 minecraft:red_nether_bricks
fill 345 218 504 345 221 504 minecraft:pink_terracotta
fill 345 218 505 345 307 505 minecraft:red_terracotta
fill 346 218 463 357 307 463 minecraft:red_terracotta
fill 346 218 464 346 220 464 minecraft:pink_terracotta
fill 346 218 503 346 221 503 minecraft:pink_terracotta
setblock 348 218 465 minecraft:red_nether_bricks
setblock 349 218 464 minecraft:red_nether_bricks
fill 349 218 465 349 221 465 minecraft:pink_terracotta
setblock 349 218 504 minecraft:red_nether_bricks
fill 350 218 464 350 221 464 minecraft:pink_terracotta
setblock 350 218 503 minecraft:red_nether_bricks
fill 350 218 504 350 221 504 minecraft:pink_terracotta
setblock 351 218 502 minecraft:red_nether_bricks
fill 351 218 503 351 221 503 minecraft:pink_terracotta
setblock 353 218 465 minecraft:red_nether_bricks
setblock 354 218 464 minecraft:red_nether_bricks
fill 354 218 465 354 221 465 minecraft:pink_terracotta
setblock 354 218 504 minecraft:red_nether_bricks
fill 354 218 505 358 307 505 minecraft:red_terracotta
fill 355 218 464 355 221 464 minecraft:pink_terracotta
fill 355 218 504 355 220 504 minecraft:pink_terracotta
fill 358 218 463 358 218 464 minecraft:pink_terracotta
fill 359 218 463 364 307 463 minecraft:red_terracotta
setblock 359 218 505 minecraft:pink_terracotta
fill 360 218 505 368 307 505 minecraft:red_terracotta
fill 362 218 464 363 218 464 minecraft:pink_terracotta
setblock 364 218 464 minecraft:red_nether_bricks
fill 365 218 463 365 218 465 minecraft:pink_terracotta
fill 366 218 463 366 307 463 minecraft:red_terracotta
fill 366 218 464 366 219 465 minecraft:pink_terracotta
setblock 367 218 466 minecraft:red_nether_bricks
setblock 368 218 464 minecraft:pink_terracotta
setblock 368 218 465 minecraft:red_nether_bricks
fill 368 218 466 368 221 466 minecraft:pink_terracotta
setblock 368 218 469 minecraft:pink_terracotta
setblock 368 218 470 minecraft:red_nether_bricks
fill 368 218 471 368 221 471 minecraft:pink_terracotta
setblock 368 218 480 minecraft:red_nether_bricks
fill 368 218 481 368 221 481 minecraft:pink_terracotta
setblock 368 218 484 minecraft:pink_terracotta
setblock 368 218 485 minecraft:red_nether_bricks
fill 368 218 486 368 221 486 minecraft:pink_terracotta
fill 368 218 488 368 218 489 minecraft:pink_terracotta
setblock 369 218 464 minecraft:red_nether_bricks
fill 369 218 465 369 221 465 minecraft:pink_terracotta
setblock 369 218 469 minecraft:red_nether_bricks
fill 369 218 470 369 221 470 minecraft:pink_terracotta
setblock 369 218 473 minecraft:pink_terracotta
setblock 369 218 474 minecraft:red_nether_bricks
fill 369 218 475 369 221 475 minecraft:pink_terracotta
setblock 369 218 479 minecraft:red_nether_bricks
fill 369 218 480 369 221 480 minecraft:pink_terracotta
setblock 369 218 484 minecraft:red_nether_bricks
fill 369 218 485 369 221 485 minecraft:pink_terracotta
setblock 369 218 489 minecraft:red_nether_bricks
fill 369 218 490 369 220 491 minecraft:pink_terracotta
setblock 369 218 504 minecraft:red_nether_bricks
fill 369 218 505 371 218 505 minecraft:pink_terracotta
fill 370 218 463 370 307 463 minecraft:red_terracotta
fill 370 218 464 370 221 464 minecraft:pink_terracotta
setblock 370 218 468 minecraft:red_nether_bricks
fill 370 218 469 370 221 469 minecraft:pink_terracotta
setblock 370 218 473 minecraft:red_nether_bricks
fill 370 218 474 370 221 474 minecraft:pink_terracotta
setblock 370 218 478 minecraft:red_nether_bricks
fill 370 218 479 370 221 479 minecraft:pink_terracotta
setblock 370 218 483 minecraft:red_nether_bricks
fill 370 218 484 370 221 484 minecraft:pink_terracotta
setblock 370 218 488 minecraft:red_nether_bricks
fill 370 218 489 370 221 489 minecraft:pink_terracotta
setblock 370 218 492 minecraft:pink_terracotta
setblock 370 218 493 minecraft:red_nether_bricks
fill 370 218 494 370 221 494 minecraft:pink_terracotta
fill 370 218 500 370 220 500 minecraft:pink_terracotta
setblock 370 218 503 minecraft:red_nether_bricks
fill 370 218 504 370 221 504 minecraft:pink_terracotta
setblock 371 218 465 minecraft:pink_terracotta
fill 371 218 466 371 307 469 minecraft:red_terracotta
fill 371 218 472 371 307 472 minecraft:red_terracotta
fill 371 218 474 371 307 474 minecraft:red_terracotta
fill 371 218 476 371 307 476 minecraft:red_terracotta
fill 371 218 477 371 218 478 minecraft:pink_terracotta
fill 371 218 479 371 307 479 minecraft:red_terracotta
fill 371 218 483 371 307 483 minecraft:red_terracotta
fill 371 218 487 371 307 487 minecraft:red_terracotta
fill 329 219 468 329 307 468 minecraft:red_terracotta
fill 329 219 476 329 307 476 minecraft:red_terracotta
fill 329 219 494 329 307 494 minecraft:red_terracotta
fill 329 219 497 329 307 497 minecraft:red_terracotta
fill 329 219 499 329 307 499 minecraft:red_terracotta
setblock 330 219 467 minecraft:red_nether_bricks
fill 330 219 468 330 222 468 minecraft:pink_terracotta
setblock 330 219 472 minecraft:red_nether_bricks
fill 330 219 473 330 222 473 minecraft:pink_terracotta
setblock 330 219 477 minecraft:red_nether_bricks
fill 330 219 478 330 222 478 minecraft:pink_terracotta
setblock 330 219 482 minecraft:red_nether_bricks
fill 330 219 483 330 222 483 minecraft:pink_terracotta
setblock 330 219 487 minecraft:red_nether_bricks
fill 330 219 488 330 222 488 minecraft:pink_terracotta
fill 330 219 490 330 219 491 minecraft:pink_terracotta
setblock 330 219 492 minecraft:red_nether_bricks
fill 330 219 493 330 221 494 minecraft:pink_terracotta
setblock 330 219 497 minecraft:red_nether_bricks
fill 330 219 498 330 221 499 minecraft:pink_terracotta
setblock 330 219 502 minecraft:red_nether_bricks
fill 330 219 503 330 222 503 minecraft:pink_terracotta
setblock 331 219 466 minecraft:red_nether_bricks
fill 331 219 467 331 222 467 minecraft:pink_terracotta
setblock 331 219 471 minecraft:red_nether_bricks
fill 331 219 472 331 222 472 minecraft:pink_terracotta
fill 331 219 479 331 220 480 minecraft:white_concrete
setblock 331 219 481 minecraft:red_nether_bricks
fill 331 219 482 331 220 482 minecraft:pink_terracotta
setblock 331 219 486 minecraft:red_nether_bricks
fill 331 219 487 331 222 487 minecraft:pink_terracotta
setblock 331 219 491 minecraft:red_nether_bricks
fill 331 219 492 331 222 492 minecraft:pink_terracotta
setblock 331 219 501 minecraft:red_nether_bricks
fill 331 219 502 331 222 502 minecraft:pink_terracotta
setblock 332 219 465 minecraft:red_nether_bricks
fill 332 219 466 332 222 466 minecraft:pink_terracotta
setblock 332 219 470 minecraft:red_nether_bricks
fill 332 219 471 332 222 471 minecraft:pink_terracotta
fill 332 219 480 332 220 480 minecraft:white_concrete
setblock 333 219 464 minecraft:red_nether_bricks
fill 333 219 465 333 222 465 minecraft:pink_terracotta
setblock 333 219 468 minecraft:pink_terracotta
fill 333 219 481 333 220 481 minecraft:red_concrete
setblock 333 219 504 minecraft:red_nether_bricks
fill 334 219 464 334 222 464 minecraft:pink_terracotta
setblock 334 219 503 minecraft:red_nether_bricks
fill 334 219 504 334 222 504 minecraft:pink_terracotta
fill 335 219 503 335 221 503 minecraft:pink_terracotta
fill 335 219 505 335 307 505 minecraft:red_terracotta
setblock 336 219 466 minecraft:red_nether_bricks
setblock 337 219 465 minecraft:red_nether_bricks
setblock 338 219 464 minecraft:red_nether_bricks
fill 338 219 465 338 222 465 minecraft:pink_terracotta
setblock 338 219 504 minecraft:red_nether_bricks
fill 339 219 464 342 219 464 minecraft:pink_terracotta
fill 339 219 504 339 222 504 minecraft:pink_terracotta
setblock 341 219 465 minecraft:pink_terracotta
setblock 342 219 465 minecraft:red_nether_bricks
setblock 343 219 464 minecraft:red_nether_bricks
fill 343 219 465 346 219 465 minecraft:pink_terracotta
setblock 343 219 504 minecraft:red_nether_bricks
fill 344 219 464 345 221 464 minecraft:pink_terracotta
setblock 344 219 503 minecraft:red_nether_bricks
fill 344 219 504 344 222 504 minecraft:pink_terracotta
fill 345 219 463 345 307 463 minecraft:red_terracotta
fill 345 219 503 345 222 503 minecraft:pink_terracotta
setblock 347 219 465 minecraft:red_nether_bricks
fill 347 219 502 347 220 502 minecraft:pink_terracotta
setblock 348 219 464 minecraft:red_nether_bricks
fill 348 219 465 348 221 466 minecraft:pink_terracotta
setblock 348 219 504 minecraft:red_nether_bricks
fill 349 219 464 349 222 464 minecraft:pink_terracotta
fill 349 219 466 350 219 466 minecraft:pink_terracotta
setblock 349 219 503 minecraft:red_nether_bricks
fill 349 219 504 349 222 504 minecraft:pink_terracotta
setblock 350 219 502 minecraft:red_nether_bricks
fill 350 219 503 350 222 503 minecraft:pink_terracotta
setblock 352 219 465 minecraft:red_nether_bricks
setblock 353 219 464 minecraft:red_nether_bricks
fill 353 219 465 353 221 465 minecraft:pink_terracotta
setblock 353 219 504 minecraft:red_nether_bricks
fill 354 219 464 354 222 464 minecraft:pink_terracotta
fill 354 219 504 354 221 504 minecraft:pink_terracotta
fill 358 219 463 358 307 463 minecraft:red_terracotta
setblock 358 219 464 minecraft:red_nether_bricks
fill 359 219 464 362 219 464 minecraft:pink_terracotta
fill 359 219 505 359 307 505 minecraft:red_terracotta
fill 361 219 503 361 224 503 minecraft:white_concrete
setblock 363 219 464 minecraft:red_nether_bricks
fill 363 219 465 365 220 465 minecraft:pink_terracotta
fill 364 219 464 365 221 464 minecraft:pink_terracotta
fill 365 219 463 365 307 463 minecraft:red_terracotta
setblock 365 219 466 minecraft:pink_terracotta
fill 365 219 504 365 221 504 minecraft:pink_terracotta
setblock 366 219 466 minecraft:red_nether_bricks
setblock 367 219 464 minecraft:pink_terracotta
setblock 367 219 465 minecraft:red_nether_bricks
fill 367 219 466 367 222 466 minecraft:pink_terracotta
setblock 368 219 464 minecraft:red_nether_bricks
fill 368 219 465 368 222 465 minecraft:pink_terracotta
setblock 368 219 469 minecraft:red_nether_bricks
fill 368 219 470 368 222 470 minecraft:pink_terracotta
fill 368 219 472 368 219 473 minecraft:pink_terracotta
setblock 368 219 474 minecraft:red_nether_bricks
setblock 368 219 479 minecraft:red_nether_bricks
fill 368 219 480 368 221 480 minecraft:pink_terracotta
setblock 368 219 484 minecraft:red_nether_bricks
fill 368 219 485 368 222 485 minecraft:pink_terracotta
setblock 368 219 488 minecraft:pink_terracotta
setblock 368 219 489 minecraft:red_nether_bricks
fill 368 219 490 368 222 490 minecraft:pink_terracotta
setblock 368 219 504 minecraft:red_nether_bricks
fill 369 219 464 369 222 464 minecraft:pink_terracotta
setblock 369 219 468 minecraft:red_nether_bricks
fill 369 219 469 369 222 469 minecraft:pink_terracotta
setblock 369 219 473 minecraft:red_nether_bricks
fill 369 219 474 369 222 474 minecraft:pink_terracotta
setblock 369 219 478 minecraft:red_nether_bricks
fill 369 219 479 369 222 479 minecraft:pink_terracotta
setblock 369 219 483 minecraft:red_nether_bricks
fill 369 219 484 369 222 484 minecraft:pink_terracotta
setblock 369 219 488 minecraft:red_nether_bricks
fill 369 219 489 369 222 489 minecraft:pink_terracotta
setblock 369 219 492 minecraft:pink_terracotta
setblock 369 219 503 minecraft:red_nether_bricks
fill 369 219 504 369 222 504 minecraft:pink_terracotta
fill 369 219 505 371 307 505 minecraft:red_terracotta
setblock 370 219 467 minecraft:red_nether_bricks
fill 370 219 468 370 222 468 minecraft:pink_terracotta
setblock 370 219 472 minecraft:red_nether_bricks
fill 370 219 473 370 222 473 minecraft:pink_terracotta
fill 370 219 475 370 220 475 minecraft:pink_terracotta
setblock 370 219 477 minecraft:red_nether_bricks
fill 370 219 478 370 222 478 minecraft:pink_terracotta
setblock 370 219 482 minecraft:red_nether_bricks
fill 370 219 483 370 222 483 minecraft:pink_terracotta
setblock 370 219 487 minecraft:red_nether_bricks
fill 370 219 488 370 222 488 minecraft:pink_terracotta
setblock 370 219 492 minecraft:red_nether_bricks
fill 370 219 493 370 222 493 minecraft:pink_terracotta
fill 370 219 495 370 219 496 minecraft:pink_terracotta
setblock 370 219 502 minecraft:red_nether_bricks
fill 370 219 503 370 222 503 minecraft:pink_terracotta
fill 371 219 465 371 307 465 minecraft:red_terracotta
fill 371 219 475 371 307 475 minecraft:red_terracotta
fill 371 219 477 371 307 478 minecraft:red_terracotta
fill 371 219 493 371 307 493 minecraft:red_terracotta
setblock 330 220 466 minecraft:red_nether_bricks
fill 330 220 467 330 223 467 minecraft:pink_terracotta
setblock 330 220 471 minecraft:red_nether_bricks
fill 330 220 472 330 223 472 minecraft:pink_terracotta
setblock 330 220 476 minecraft:red_nether_bricks
fill 330 220 477 330 223 477 minecraft:pink_terracotta
setblock 330 220 481 minecraft:red_nether_bricks
fill 330 220 482 330 223 482 minecraft:pink_terracotta
setblock 330 220 486 minecraft:red_nether_bricks
fill 330 220 487 330 223 487 minecraft:pink_terracotta
setblock 330 220 490 minecraft:pink_terracotta
setblock 330 220 491 minecraft:red_nether_bricks
fill 330 220 492 330 223 492 minecraft:pink_terracotta
setblock 330 220 495 minecraft:pink_terracotta
setblock 330 220 496 minecraft:red_nether_bricks
fill 330 220 497 330 223 497 minecraft:pink_terracotta
setblock 330 220 501 minecraft:red_nether_bricks
fill 330 220 502 330 223 502 minecraft:pink_terracotta
setblock 331 220 465 minecraft:red_nether_bricks
fill 331 220 466 331 223 466 minecraft:pink_terracotta
setblock 331 220 470 minecraft:red_nether_bricks
fill 331 220 471 331 223 471 minecraft:pink_terracotta
setblock 331 220 475 minecraft:red_nether_bricks
fill 331 220 481 331 221 481 minecraft:white_concrete
setblock 331 220 485 minecraft:red_nether_bricks
fill 331 220 486 331 222 486 minecraft:pink_terracotta
setblock 331 220 490 minecraft:red_nether_bricks
fill 331 220 491 331 223 491 minecraft:pink_terracotta
fill 331 220 493 331 220 494 minecraft:pink_terracotta
setblock 331 220 500 minecraft:red_nether_bricks
fill 331 220 501 331 222 501 minecraft:pink_terracotta
setblock 332 220 464 minecraft:red_nether_bricks
fill 332 220 465 332 223 465 minecraft:pink_terracotta
setblock 332 220 469 minecraft:red_nether_bricks
fill 332 220 470 332 223 470 minecraft:pink_terracotta
setblock 332 220 504 minecraft:red_nether_bricks
fill 333 220 464 333 223 464 minecraft:pink_terracotta
setblock 333 220 468 minecraft:red_nether_bricks
setblock 333 220 503 minecraft:red_nether_bricks
fill 333 220 504 333 223 504 minecraft:pink_terracotta
fill 334 220 503 334 222 503 minecraft:pink_terracotta
setblock 335 220 466 minecraft:red_nether_bricks
setblock 336 220 465 minecraft:red_nether_bricks
setblock 336 220 466 minecraft:pink_terracotta
setblock 337 220 464 minecraft:red_nether_bricks
fill 337 220 465 337 222 465 minecraft:pink_terracotta
setblock 337 220 504 minecraft:red_nether_bricks
fill 338 220 464 341 220 464 minecraft:pink_terracotta
fill 338 220 504 338 223 504 minecraft:pink_terracotta
setblock 341 220 465 minecraft:red_nether_bricks
setblock 342 220 464 minecraft:red_nether_bricks
fill 342 220 465 345 220 465 minecraft:pink_terracotta
setblock 342 220 504 minecraft:red_nether_bricks
fill 343 220 464 343 223 464 minecraft:pink_terracotta
setblock 343 220 503 minecraft:red_nether_bricks
fill 343 220 504 343 223 504 minecraft:pink_terracotta
fill 344 220 503 344 223 503 minecraft:pink_terracotta
setblock 346 220 465 minecraft:red_nether_bricks
setblock 347 220 464 minecraft:red_nether_bricks
fill 347 220 465 347 222 466 minecraft:pink_terracotta
setblock 347 220 504 minecraft:red_nether_bricks
fill 348 220 464 348 223 464 minecraft:pink_terracotta
setblock 348 220 503 minecraft:red_nether_bricks
fill 348 220 504 348 223 504 minecraft:pink_terracotta
setblock 349 220 466 minecraft:pink_terracotta
setblock 349 220 502 minecraft:red_nether_bricks
fill 349 220 503 349 223 503 minecraft:pink_terracotta
setblock 350 220 466 minecraft:red_nether_bricks
setblock 351 220 465 minecraft:red_nether_bricks
setblock 351 220 466 minecraft:pink_terracotta
setblock 352 220 464 minecraft:red_nether_bricks
fill 352 220 465 352 222 465 minecraft:pink_terracotta
setblock 352 220 504 minecraft:red_nether_bricks
fill 353 220 464 353 223 464 minecraft:pink_terracotta
setblock 353 220 503 minecraft:red_nether_bricks
fill 353 220 504 353 222 504 minecraft:pink_terracotta
setblock 357 220 464 minecraft:red_nether_bricks
fill 358 220 464 361 220 464 minecraft:pink_terracotta
fill 359 220 503 360 223 503 minecraft:white_concrete
fill 360 220 502 362 223 502 minecraft:white_concrete
fill 360 220 504 362 223 504 minecraft:white_concrete
fill 361 220 501 361 223 501 minecraft:white_concrete
setblock 362 220 464 minecraft:red_nether_bricks
fill 362 220 503 363 223 503 minecraft:white_concrete
fill 363 220 464 363 223 464 minecraft:pink_terracotta
setblock 364 220 466 minecraft:pink_terracotta
setblock 365 220 466 minecraft:red_nether_bricks
setblock 366 220 464 minecraft:pink_terracotta
setblock 366 220 465 minecraft:red_nether_bricks
fill 366 220 466 366 222 467 minecraft:pink_terracotta
setblock 367 220 464 minecraft:red_nether_bricks
fill 367 220 465 367 223 465 minecraft:pink_terracotta
fill 367 220 467 367 220 468 minecraft:pink_terracotta
setblock 367 220 469 minecraft:red_nether_bricks
fill 367 220 470 367 223 470 minecraft:pink_terracotta
setblock 367 220 504 minecraft:red_nether_bricks
fill 368 220 464 368 223 464 minecraft:pink_terracotta
setblock 368 220 467 minecraft:pink_terracotta
setblock 368 220 468 minecraft:red_nether_bricks
fill 368 220 469 368 223 469 minecraft:pink_terracotta
setblock 368 220 472 minecraft:pink_terracotta
setblock 368 220 473 minecraft:red_nether_bricks
fill 368 220 474 368 221 476 minecraft:pink_terracotta
fill 368 220 479 368 221 479 minecraft:pink_terracotta
setblock 368 220 483 minecraft:red_nether_bricks
fill 368 220 484 368 222 484 minecraft:pink_terracotta
setblock 368 220 488 minecraft:red_nether_bricks
fill 368 220 489 368 223 489 minecraft:pink_terracotta
fill 368 220 491 368 221 491 minecraft:pink_terracotta
fill 368 220 504 368 223 504 minecraft:pink_terracotta
setblock 369 220 467 minecraft:red_nether_bricks
fill 369 220 468 369 223 468 minecraft:pink_terracotta
setblock 369 220 472 minecraft:red_nether_bricks
fill 369 220 473 369 223 473 minecraft:pink_terracotta
setblock 369 220 477 minecraft:red_nether_bricks
fill 369 220 478 369 223 478 minecraft:pink_terracotta
setblock 369 220 482 minecraft:red_nether_bricks
fill 369 220 483 369 223 483 minecraft:pink_terracotta
setblock 369 220 487 minecraft:red_nether_bricks
fill 369 220 488 369 223 488 minecraft:pink_terracotta
setblock 369 220 492 minecraft:red_nether_bricks
fill 369 220 493 369 223 493 minecraft:pink_terracotta
fill 369 220 503 369 221 503 minecraft:pink_terracotta
setblock 370 220 466 minecraft:red_nether_bricks
fill 370 220 467 370 223 467 minecraft:pink_terracotta
setblock 370 220 471 minecraft:red_nether_bricks
fill 370 220 472 370 223 472 minecraft:pink_terracotta
setblock 370 220 476 minecraft:red_nether_bricks
fill 370 220 477 370 223 477 minecraft:pink_terracotta
setblock 370 220 481 minecraft:red_nether_bricks
fill 370 220 482 370 223 482 minecraft:pink_terracotta
setblock 370 220 486 minecraft:red_nether_bricks
fill 370 220 487 370 223 487 minecraft:pink_terracotta
setblock 370 220 491 minecraft:red_nether_bricks
fill 370 220 492 370 223 492 minecraft:pink_terracotta
setblock 370 220 495 minecraft:pink_terracotta
setblock 370 220 496 minecraft:red_nether_bricks
fill 370 220 497 370 221 499 minecraft:pink_terracotta
setblock 370 220 501 minecraft:red_nether_bricks
fill 370 220 502 370 223 502 minecraft:pink_terracotta
setblock 330 221 464 minecraft:pink_terracotta
setblock 330 221 465 minecraft:red_nether_bricks
fill 330 221 466 330 224 466 minecraft:pink_terracotta
setblock 330 221 470 minecraft:red_nether_bricks
fill 330 221 471 330 224 471 minecraft:pink_terracotta
setblock 330 221 474 minecraft:pink_terracotta
setblock 330 221 475 minecraft:red_nether_bricks
fill 330 221 476 330 224 476 minecraft:pink_terracotta
setblock 330 221 479 minecraft:pink_terracotta
setblock 330 221 480 minecraft:red_nether_bricks
fill 330 221 481 330 222 481 minecraft:pink_terracotta
setblock 330 221 485 minecraft:red_nether_bricks
fill 330 221 486 330 224 486 minecraft:pink_terracotta
setblock 330 221 490 minecraft:red_nether_bricks
fill 330 221 491 330 224 491 minecraft:pink_terracotta
setblock 330 221 495 minecraft:red_nether_bricks
fill 330 221 496 330 224 496 minecraft:pink_terracotta
setblock 330 221 500 minecraft:red_nether_bricks
fill 330 221 501 330 224 501 minecraft:pink_terracotta
setblock 331 221 464 minecraft:red_nether_bricks
fill 331 221 465 331 224 465 minecraft:pink_terracotta
setblock 331 221 469 minecraft:red_nether_bricks
fill 331 221 470 331 224 470 minecraft:pink_terracotta
setblock 331 221 474 minecraft:red_nether_bricks
setblock 331 221 475 minecraft:pink_terracotta
setblock 331 221 480 minecraft:white_concrete
setblock 331 221 482 minecraft:white_concrete
setblock 331 221 484 minecraft:red_nether_bricks
fill 331 221 485 331 222 485 minecraft:pink_terracotta
setblock 331 221 489 minecraft:red_nether_bricks
fill 331 221 490 331 224 490 minecraft:pink_terracotta
setblock 331 221 493 minecraft:pink_terracotta
setblock 331 221 494 minecraft:red_nether_bricks
fill 331 221 495 331 224 495 minecraft:pink_terracotta
setblock 331 221 500 minecraft:pink_terracotta
setblock 331 221 504 minecraft:red_nether_bricks
fill 332 221 464 332 224 464 minecraft:pink_terracotta
setblock 332 221 467 minecraft:pink_terracotta
setblock 332 221 468 minecraft:red_nether_bricks
fill 332 221 469 332 224 469 minecraft:pink_terracotta
setblock 332 221 503 minecraft:red_nether_bricks
fill 332 221 504 332 224 504 minecraft:pink_terracotta
setblock 333 221 467 minecraft:red_nether_bricks
fill 333 221 503 333 222 503 minecraft:pink_terracotta
setblock 334 221 466 minecraft:red_nether_bricks
setblock 335 221 465 minecraft:red_nether_bricks
setblock 335 221 466 minecraft:pink_terracotta
setblock 336 221 464 minecraft:red_nether_bricks
fill 336 221 465 336 223 465 minecraft:pink_terracotta
setblock 336 221 504 minecraft:red_nether_bricks
fill 337 221 464 340 221 464 minecraft:pink_terracotta
fill 337 221 504 337 223 504 minecraft:pink_terracotta
setblock 339 221 465 minecraft:pink_terracotta
setblock 340 221 465 minecraft:red_nether_bricks
setblock 341 221 464 minecraft:red_nether_bricks
fill 341 221 465 344 221 465 minecraft:pink_terracotta
setblock 341 221 504 minecraft:red_nether_bricks
fill 342 221 464 342 224 464 minecraft:pink_terracotta
setblock 342 221 503 minecraft:red_nether_bricks
fill 342 221 504 342 224 504 minecraft:pink_terracotta
fill 343 221 503 343 223 503 minecraft:pink_terracotta
setblock 345 221 465 minecraft:red_nether_bricks
setblock 346 221 464 minecraft:red_nether_bricks
fill 346 221 465 346 222 466 minecraft:pink_terracotta
setblock 346 221 504 minecraft:red_nether_bricks
fill 347 221 464 347 224 464 minecraft:pink_terracotta
setblock 347 221 503 minecraft:red_nether_bricks
fill 347 221 504 347 224 504 minecraft:pink_terracotta
fill 348 221 503 348 223 503 minecraft:pink_terracotta
setblock 349 221 466 minecraft:red_nether_bricks
setblock 350 221 465 minecraft:red_nether_bricks
setblock 350 221 466 minecraft:pink_terracotta
setblock 351 221 464 minecraft:red_nether_bricks
fill 351 221 465 351 223 465 minecraft:pink_terracotta
setblock 351 221 504 minecraft:red_nether_bricks
fill 352 221 464 352 223 464 minecraft:pink_terracotta
setblock 352 221 503 minecraft:red_nether_bricks
fill 352 221 504 352 223 504 minecraft:pink_terracotta
setblock 356 221 464 minecraft:red_nether_bricks
setblock 357 221 464 minecraft:pink_terracotta
fill 359 221 464 360 221 464 minecraft:pink_terracotta
fill 359 221 502 359 222 502 minecraft:white_concrete
fill 359 221 504 359 222 504 minecraft:white_concrete
fill 360 221 501 360 222 501 minecraft:white_concrete
setblock 361 221 464 minecraft:red_nether_bricks
fill 362 221 464 362 223 465 minecraft:pink_terracotta
fill 362 221 501 362 222 501 minecraft:white_concrete
fill 363 221 465 364 221 465 minecraft:pink_terracotta
fill 363 221 502 363 222 502 minecraft:white_concrete
fill 363 221 504 363 222 504 minecraft:white_concrete
setblock 364 221 466 minecraft:red_nether_bricks
setblock 365 221 465 minecraft:red_nether_bricks
fill 365 221 466 365 224 466 minecraft:pink_terracotta
setblock 366 221 464 minecraft:red_nether_bricks
fill 366 221 465 366 224 465 minecraft:pink_terracotta
setblock 366 221 504 minecraft:red_nether_bricks
fill 367 221 464 367 224 464 minecraft:pink_terracotta
setblock 367 221 467 minecraft:pink_terracotta
setblock 367 221 468 minecraft:red_nether_bricks
fill 367 221 469 367 224 469 minecraft:pink_terracotta
fill 367 221 471 367 221 472 minecraft:pink_terracotta
fill 367 221 504 367 224 504 minecraft:pink_terracotta
setblock 368 221 467 minecraft:red_nether_bricks
fill 368 221 468 368 224 468 minecraft:pink_terracotta
setblock 368 221 472 minecraft:red_nether_bricks
fill 368 221 473 368 224 473 minecraft:pink_terracotta
setblock 368 221 477 minecraft:red_nether_bricks
setblock 368 221 478 minecraft:pink_terracotta
setblock 368 221 482 minecraft:red_nether_bricks
fill 368 221 483 368 222 483 minecraft:pink_terracotta
setblock 368 221 487 minecraft:red_nether_bricks
fill 368 221 488 368 224 488 minecraft:pink_terracotta
setblock 369 221 466 minecraft:red_nether_bricks
fill 369 221 467 369 224 467 minecraft:pink_terracotta
setblock 369 221 471 minecraft:red_nether_bricks
fill 369 221 472 369 224 472 minecraft:pink_terracotta
setblock 369 221 476 minecraft:red_nether_bricks
fill 369 221 477 369 224 477 minecraft:pink_terracotta
setblock 369 221 481 minecraft:red_nether_bricks
fill 369 221 482 369 223 482 minecraft:pink_terracotta
setblock 369 221 486 minecraft:red_nether_bricks
fill 369 221 487 369 224 487 minecraft:pink_terracotta
setblock 369 221 490 minecraft:pink_terracotta
setblock 369 221 491 minecraft:red_nether_bricks
fill 369 221 492 369 224 492 minecraft:pink_terracotta
fill 369 221 494 369 222 494 minecraft:pink_terracotta
setblock 370 221 465 minecraft:red_nether_bricks
fill 370 221 466 370 224 466 minecraft:pink_terracotta
setblock 370 221 470 minecraft:red_nether_bricks
fill 370 221 471 370 224 471 minecraft:pink_terracotta
setblock 370 221 475 minecraft:red_nether_bricks
fill 370 221 476 370 224 476 minecraft:pink_terracotta
setblock 370 221 480 minecraft:red_nether_bricks
fill 370 221 481 370 224 481 minecraft:pink_terracotta
setblock 370 221 485 minecraft:red_nether_bricks
fill 370 221 486 370 224 486 minecraft:pink_terracotta
setblock 370 221 490 minecraft:red_nether_bricks
fill 370 221 491 370 224 491 minecraft:pink_terracotta
setblock 370 221 495 minecraft:red_nether_bricks
fill 370 221 496 370 224 496 minecraft:pink_terracotta
setblock 370 221 500 minecraft:red_nether_bricks
fill 370 221 501 370 223 501 minecraft:pink_terracotta
setblock 330 222 464 minecraft:red_nether_bricks
fill 330 222 465 330 225 465 minecraft:pink_terracotta
setblock 330 222 469 minecraft:red_nether_bricks
fill 330 222 470 330 225 470 minecraft:pink_terracotta
setblock 330 222 474 minecraft:red_nether_bricks
fill 330 222 475 330 225 475 minecraft:pink_terracotta
setblock 330 222 479 minecraft:red_nether_bricks
setblock 330 222 480 minecraft:pink_terracotta
setblock 330 222 484 minecraft:red_nether_bricks
fill 330 222 485 330 224 485 minecraft:pink_terracotta
setblock 330 222 489 minecraft:red_nether_bricks
fill 330 222 490 330 225 490 minecraft:pink_terracotta
setblock 330 222 493 minecraft:pink_terracotta
setblock 330 222 494 minecraft:red_nether_bricks
fill 330 222 495 330 225 495 minecraft:pink_terracotta
setblock 330 222 498 minecraft:pink_terracotta
setblock 330 222 499 minecraft:red_nether_bricks
fill 330 222 500 330 225 500 minecraft:pink_terracotta
setblock 330 222 504 minecraft:red_nether_bricks
fill 331 222 464 331 225 464 minecraft:pink_terracotta
setblock 331 222 468 minecraft:red_nether_bricks
fill 331 222 469 331 225 469 minecraft:pink_terracotta
setblock 331 222 473 minecraft:red_nether_bricks
fill 331 222 474 331 223 474 minecraft:pink_terracotta
setblock 331 222 488 minecraft:red_nether_bricks
fill 331 222 489 331 224 489 minecraft:pink_terracotta
setblock 331 222 493 minecraft:red_nether_bricks
fill 331 222 494 331 225 494 minecraft:pink_terracotta
fill 331 222 496 331 223 496 minecraft:pink_terracotta
setblock 331 222 503 minecraft:red_nether_bricks
fill 331 222 504 331 225 504 minecraft:pink_terracotta
setblock 332 222 467 minecraft:red_nether_bricks
fill 332 222 468 332 224 468 minecraft:pink_terracotta
fill 332 222 503 332 223 503 minecraft:pink_terracotta
setblock 333 222 466 minecraft:red_nether_bricks
setblock 334 222 465 minecraft:red_nether_bricks
setblock 334 222 466 minecraft:pink_terracotta
setblock 335 222 464 minecraft:red_nether_bricks
fill 335 222 465 335 223 465 minecraft:pink_terracotta
setblock 335 222 504 minecraft:red_nether_bricks
fill 336 222 464 339 222 464 minecraft:pink_terracotta
fill 336 222 504 336 224 504 minecraft:pink_terracotta
setblock 340 222 464 minecraft:red_nether_bricks
setblock 340 222 504 minecraft:red_nether_bricks
fill 341 222 464 341 222 465 minecraft:pink_terracotta
fill 341 222 504 341 225 504 minecraft:pink_terracotta
fill 342 222 465 343 222 465 minecraft:pink_terracotta
setblock 344 222 464 minecraft:pink_terracotta
setblock 344 222 465 minecraft:red_nether_bricks
setblock 345 222 464 minecraft:red_nether_bricks
fill 345 222 465 345 224 465 minecraft:pink_terracotta
setblock 345 222 504 minecraft:red_nether_bricks
fill 346 222 464 346 225 464 minecraft:pink_terracotta
setblock 346 222 503 minecraft:red_nether_bricks
fill 346 222 504 346 225 504 minecraft:pink_terracotta
fill 347 222 503 347 224 503 minecraft:pink_terracotta
setblock 348 222 465 minecraft:pink_terracotta
setblock 348 222 466 minecraft:red_nether_bricks
setblock 349 222 465 minecraft:red_nether_bricks
setblock 349 222 466 minecraft:pink_terracotta
setblock 350 222 464 minecraft:red_nether_bricks
fill 350 222 465 350 223 465 minecraft:pink_terracotta
setblock 350 222 504 minecraft:red_nether_bricks
fill 351 222 464 351 224 464 minecraft:pink_terracotta
fill 351 222 504 351 223 504 minecraft:pink_terracotta
setblock 355 222 464 minecraft:red_nether_bricks
setblock 360 222 464 minecraft:red_nether_bricks
fill 361 222 464 361 224 464 minecraft:pink_terracotta
setblock 361 222 500 minecraft:black_concrete
setblock 363 222 465 minecraft:pink_terracotta
setblock 363 222 466 minecraft:red_nether_bricks
setblock 364 222 464 minecraft:pink_terracotta
setblock 364 222 465 minecraft:red_nether_bricks
fill 364 222 466 364 225 466 minecraft:pink_terracotta
setblock 365 222 464 minecraft:red_nether_bricks
fill 365 222 465 365 225 465 minecraft:pink_terracotta
fill 365 222 467 365 223 467 minecraft:pink_terracotta
setblock 365 222 504 minecraft:red_nether_bricks
fill 366 222 464 366 225 464 minecraft:pink_terracotta
fill 366 222 504 366 224 504 minecraft:pink_terracotta
setblock 367 222 467 minecraft:red_nether_bricks
fill 367 222 468 367 225 468 minecraft:pink_terracotta
setblock 367 222 471 minecraft:pink_terracotta
setblock 367 222 472 minecraft:red_nether_bricks
fill 367 222 473 367 225 473 minecraft:pink_terracotta
setblock 368 222 466 minecraft:red_nether_bricks
fill 368 222 467 368 225 467 minecraft:pink_terracotta
setblock 368 222 471 minecraft:red_nether_bricks
fill 368 222 472 368 225 472 minecraft:pink_terracotta
fill 368 222 474 368 222 475 minecraft:pink_terracotta
setblock 368 222 476 minecraft:red_nether_bricks
fill 368 222 477 368 223 477 minecraft:pink_terracotta
setblock 368 222 482 minecraft:pink_terracotta
setblock 368 222 486 minecraft:red_nether_bricks
fill 368 222 487 368 223 487 minecraft:pink_terracotta
setblock 368 222 491 minecraft:red_nether_bricks
fill 368 222 492 368 223 492 minecraft:pink_terracotta
setblock 369 222 465 minecraft:red_nether_bricks
fill 369 222 466 369 225 466 minecraft:pink_terracotta
setblock 369 222 470 minecraft:red_nether_bricks
fill 369 222 471 369 225 471 minecraft:pink_terracotta
setblock 369 222 475 minecraft:red_nether_bricks
fill 369 222 476 369 225 476 minecraft:pink_terracotta
setblock 369 222 480 minecraft:red_nether_bricks
fill 369 222 481 369 223 481 minecraft:pink_terracotta
setblock 369 222 485 minecraft:red_nether_bricks
fill 369 222 486 369 224 486 minecraft:pink_terracotta
setblock 369 222 490 minecraft:red_nether_bricks
fill 369 222 491 369 225 491 minecraft:pink_terracotta
setblock 370 222 464 minecraft:red_nether_bricks
fill 370 222 465 370 225 465 minecraft:pink_terracotta
setblock 370 222 469 minecraft:red_nether_bricks
fill 370 222 470 370 225 470 minecraft:pink_terracotta
setblock 370 222 474 minecraft:red_nether_bricks
fill 370 222 475 370 225 475 minecraft:pink_terracotta
setblock 370 222 479 minecraft:red_nether_bricks
fill 370 222 480 370 225 480 minecraft:pink_terracotta
setblock 370 222 484 minecraft:red_nether_bricks
fill 370 222 485 370 225 485 minecraft:pink_terracotta
setblock 370 222 489 minecraft:red_nether_bricks
fill 370 222 490 370 225 490 minecraft:pink_terracotta
setblock 370 222 494 minecraft:red_nether_bricks
fill 370 222 495 370 225 495 minecraft:pink_terracotta
fill 370 222 497 370 222 498 minecraft:pink_terracotta
setblock 370 222 499 minecraft:red_nether_bricks
setblock 370 222 500 minecraft:pink_terracotta
setblock 370 222 504 minecraft:red_nether_bricks
fill 330 223 464 330 226 464 minecraft:pink_terracotta
setblock 330 223 468 minecraft:red_nether_bricks
fill 330 223 469 330 226 469 minecraft:pink_terracotta
setblock 330 223 473 minecraft:red_nether_bricks
fill 330 223 474 330 226 474 minecraft:pink_terracotta
setblock 330 223 478 minecraft:red_nether_bricks
setblock 330 223 483 minecraft:red_nether_bricks
setblock 330 223 484 minecraft:pink_terracotta
setblock 330 223 488 minecraft:red_nether_bricks
fill 330 223 489 330 226 489 minecraft:pink_terracotta
setblock 330 223 493 minecraft:red_nether_bricks
fill 330 223 494 330 226 494 minecraft:pink_terracotta
setblock 330 223 498 minecraft:red_nether_bricks
fill 330 223 499 330 226 499 minecraft:pink_terracotta
setblock 330 223 503 minecraft:red_nether_bricks
fill 330 223 504 330 226 504 minecraft:pink_terracotta
setblock 331 223 467 minecraft:red_nether_bricks
fill 331 223 468 331 226 468 minecraft:pink_terracotta
setblock 331 223 472 minecraft:red_nether_bricks
fill 331 223 473 331 225 473 minecraft:pink_terracotta
setblock 331 223 487 minecraft:red_nether_bricks
setblock 331 223 488 minecraft:pink_terracotta
setblock 331 223 492 minecraft:red_nether_bricks
fill 331 223 493 331 226 493 minecraft:pink_terracotta
setblock 331 223 502 minecraft:red_nether_bricks
setblock 331 223 503 minecraft:pink_terracotta
setblock 332 223 466 minecraft:red_nether_bricks
fill 332 223 467 332 224 467 minecraft:pink_terracotta
setblock 333 223 465 minecraft:red_nether_bricks
setblock 333 223 466 minecraft:pink_terracotta
setblock 334 223 464 minecraft:red_nether_bricks
fill 334 223 465 334 224 465 minecraft:pink_terracotta
setblock 334 223 504 minecraft:red_nether_bricks
fill 335 223 464 338 223 464 minecraft:pink_terracotta
fill 335 223 504 335 224 504 minecraft:pink_terracotta
setblock 339 223 464 minecraft:red_nether_bricks
setblock 339 223 504 minecraft:red_nether_bricks
fill 340 223 464 341 224 464 minecraft:pink_terracotta
fill 340 223 504 340 224 504 minecraft:pink_terracotta
setblock 343 223 465 minecraft:red_nether_bricks
setblock 344 223 464 minecraft:red_nether_bricks
fill 344 223 465 344 224 465 minecraft:pink_terracotta
setblock 344 223 504 minecraft:red_nether_bricks
fill 345 223 464 345 226 464 minecraft:pink_terracotta
setblock 345 223 503 minecraft:red_nether_bricks
fill 345 223 504 345 226 504 minecraft:pink_terracotta
fill 346 223 465 347 223 465 minecraft:pink_terracotta
fill 346 223 503 346 224 503 minecraft:pink_terracotta
setblock 348 223 465 minecraft:red_nether_bricks
setblock 349 223 464 minecraft:red_nether_bricks
fill 349 223 465 349 224 465 minecraft:pink_terracotta
setblock 349 223 504 minecraft:red_nether_bricks
fill 350 223 464 350 224 464 minecraft:pink_terracotta
fill 350 223 504 350 224 504 minecraft:pink_terracotta
setblock 353 223 504 minecraft:white_concrete
setblock 363 223 465 minecraft:red_nether_bricks
setblock 363 223 466 minecraft:pink_terracotta
setblock 364 223 464 minecraft:red_nether_bricks
fill 364 223 465 364 226 465 minecraft:pink_terracotta
fill 365 223 464 365 226 464 minecraft:pink_terracotta
setblock 365 223 504 minecraft:pink_terracotta
setblock 366 223 466 minecraft:pink_terracotta
setblock 366 223 467 minecraft:red_nether_bricks
setblock 367 223 466 minecraft:red_nether_bricks
fill 367 223 467 367 225 467 minecraft:pink_terracotta
setblock 367 223 471 minecraft:red_nether_bricks
fill 367 223 472 367 226 472 minecraft:pink_terracotta
setblock 368 223 465 minecraft:red_nether_bricks
fill 368 223 466 368 226 466 minecraft:pink_terracotta
setblock 368 223 470 minecraft:red_nether_bricks
fill 368 223 471 368 226 471 minecraft:pink_terracotta
setblock 368 223 474 minecraft:pink_terracotta
setblock 368 223 475 minecraft:red_nether_bricks
fill 368 223 476 368 225 476 minecraft:pink_terracotta
setblock 368 223 485 minecraft:red_nether_bricks
setblock 368 223 486 minecraft:pink_terracotta
setblock 368 223 490 minecraft:red_nether_bricks
fill 368 223 491 368 224 491 minecraft:pink_terracotta
setblock 369 223 464 minecraft:red_nether_bricks
fill 369 223 465 369 226 465 minecraft:pink_terracotta
setblock 369 223 469 minecraft:red_nether_bricks
fill 369 223 470 369 226 470 minecraft:pink_terracotta
setblock 369 223 474 minecraft:red_nether_bricks
fill 369 223 475 369 226 475 minecraft:pink_terracotta
setblock 369 223 479 minecraft:red_nether_bricks
setblock 369 223 480 minecraft:pink_terracotta
setblock 369 223 484 minecraft:red_nether_bricks
fill 369 223 485 369 224 485 minecraft:pink_terracotta
setblock 369 223 489 minecraft:red_nether_bricks
fill 369 223 490 369 225 490 minecraft:pink_terracotta
setblock 369 223 494 minecraft:red_nether_bricks
setblock 369 223 504 minecraft:red_nether_bricks
fill 370 223 464 370 226 464 minecraft:pink_terracotta
setblock 370 223 468 minecraft:red_nether_bricks
fill 370 223 469 370 226 469 minecraft:pink_terracotta
setblock 370 223 473 minecraft:red_nether_bricks
fill 370 223 474 370 226 474 minecraft:pink_terracotta
setblock 370 223 478 minecraft:red_nether_bricks
fill 370 223 479 370 226 479 minecraft:pink_terracotta
setblock 370 223 483 minecraft:red_nether_bricks
fill 370 223 484 370 225 484 minecraft:pink_terracotta
setblock 370 223 488 minecraft:red_nether_bricks
fill 370 223 489 370 226 489 minecraft:pink_terracotta
setblock 370 223 493 minecraft:red_nether_bricks
fill 370 223 494 370 226 494 minecraft:pink_terracotta
setblock 370 223 497 minecraft:pink_terracotta
setblock 370 223 498 minecraft:red_nether_bricks
setblock 370 223 503 minecraft:red_nether_bricks
fill 370 223 504 370 225 504 minecraft:pink_terracotta
setblock 330 224 467 minecraft:red_nether_bricks
fill 330 224 468 330 227 468 minecraft:pink_terracotta
setblock 330 224 472 minecraft:red_nether_bricks
fill 330 224 473 330 227 473 minecraft:pink_terracotta
setblock 330 224 477 minecraft:red_nether_bricks
setblock 330 224 487 minecraft:red_nether_bricks
fill 330 224 488 330 226 488 minecraft:pink_terracotta
setblock 330 224 492 minecraft:red_nether_bricks
fill 330 224 493 330 227 493 minecraft:pink_terracotta
setblock 330 224 497 minecraft:red_nether_bricks
fill 330 224 498 330 227 498 minecraft:pink_terracotta
setblock 330 224 502 minecraft:red_nether_bricks
fill 330 224 503 330 227 503 minecraft:pink_terracotta
setblock 331 224 466 minecraft:red_nether_bricks
fill 331 224 467 331 226 467 minecraft:pink_terracotta
setblock 331 224 471 minecraft:red_nether_bricks
fill 331 224 472 331 226 472 minecraft:pink_terracotta
setblock 331 224 491 minecraft:red_nether_bricks
fill 331 224 492 331 225 492 minecraft:pink_terracotta
setblock 331 224 496 minecraft:red_nether_bricks
setblock 332 224 465 minecraft:red_nether_bricks
setblock 332 224 466 minecraft:pink_terracotta
setblock 333 224 464 minecraft:red_nether_bricks
setblock 333 224 465 minecraft:pink_terracotta
setblock 333 224 504 minecraft:red_nether_bricks
fill 334 224 464 337 224 464 minecraft:pink_terracotta
setblock 334 224 504 minecraft:pink_terracotta
setblock 338 224 464 minecraft:red_nether_bricks
setblock 339 224 464 minecraft:pink_terracotta
setblock 339 224 504 minecraft:pink_terracotta
setblock 343 224 464 minecraft:red_nether_bricks
setblock 343 224 504 minecraft:red_nether_bricks
fill 344 224 464 344 226 464 minecraft:pink_terracotta
fill 344 224 504 344 227 504 minecraft:pink_terracotta
setblock 345 224 503 minecraft:pink_terracotta
setblock 346 224 465 minecraft:pink_terracotta
setblock 347 224 465 minecraft:red_nether_bricks
setblock 348 224 464 minecraft:red_nether_bricks
setblock 348 224 465 minecraft:pink_terracotta
setblock 348 224 504 minecraft:red_nether_bricks
fill 349 224 464 349 225 464 minecraft:pink_terracotta
fill 349 224 504 349 225 504 minecraft:pink_terracotta
setblock 359 224 504 minecraft:white_concrete
setblock 360 224 464 minecraft:white_concrete
setblock 362 224 464 minecraft:pink_terracotta
setblock 362 224 465 minecraft:red_nether_bricks
setblock 363 224 464 minecraft:red_nether_bricks
fill 363 224 465 363 227 465 minecraft:pink_terracotta
fill 364 224 464 364 227 464 minecraft:pink_terracotta
setblock 365 224 467 minecraft:red_nether_bricks
setblock 366 224 466 minecraft:red_nether_bricks
fill 366 224 467 366 225 467 minecraft:pink_terracotta
setblock 367 224 465 minecraft:red_nether_bricks
fill 367 224 466 367 227 466 minecraft:pink_terracotta
setblock 367 224 470 minecraft:red_nether_bricks
fill 367 224 471 367 227 471 minecraft:pink_terracotta
setblock 367 224 474 minecraft:pink_terracotta
setblock 368 224 464 minecraft:red_nether_bricks
fill 368 224 465 368 227 465 minecraft:pink_terracotta
setblock 368 224 469 minecraft:red_nether_bricks
fill 368 224 470 368 227 470 minecraft:pink_terracotta
setblock 368 224 474 minecraft:red_nether_bricks
fill 368 224 475 368 227 475 minecraft:pink_terracotta
setblock 368 224 489 minecraft:red_nether_bricks
setblock 368 224 490 minecraft:pink_terracotta
setblock 368 224 504 minecraft:red_nether_bricks
fill 369 224 464 369 227 464 minecraft:pink_terracotta
setblock 369 224 468 minecraft:red_nether_bricks
fill 369 224 469 369 227 469 minecraft:pink_terracotta
setblock 369 224 473 minecraft:red_nether_bricks
fill 369 224 474 369 227 474 minecraft:pink_terracotta
setblock 369 224 478 minecraft:red_nether_bricks
setblock 369 224 479 minecraft:pink_terracotta
setblock 369 224 483 minecraft:red_nether_bricks
setblock 369 224 484 minecraft:pink_terracotta
setblock 369 224 488 minecraft:red_nether_bricks
fill 369 224 489 369 225 489 minecraft:pink_terracotta
setblock 369 224 493 minecraft:red_nether_bricks
fill 369 224 494 369 225 494 minecraft:pink_terracotta
fill 369 224 504 369 225 504 minecraft:pink_terracotta
setblock 370 224 467 minecraft:red_nether_bricks
fill 370 224 468 370 227 468 minecraft:pink_terracotta
setblock 370 224 472 minecraft:red_nether_bricks
fill 370 224 473 370 227 473 minecraft:pink_terracotta
setblock 370 224 477 minecraft:red_nether_bricks
fill 370 224 478 370 227 478 minecraft:pink_terracotta
setblock 370 224 482 minecraft:red_nether_bricks
fill 370 224 483 370 225 483 minecraft:pink_terracotta
setblock 370 224 487 minecraft:red_nether_bricks
fill 370 224 488 370 226 488 minecraft:pink_terracotta
setblock 370 224 492 minecraft:red_nether_bricks
fill 370 224 493 370 227 493 minecraft:pink_terracotta
setblock 370 224 497 minecraft:red_nether_bricks
setblock 370 224 498 minecraft:pink_terracotta
setblock 370 224 503 minecraft:pink_terracotta
setblock 330 225 466 minecraft:red_nether_bricks
fill 330 225 467 330 228 467 minecraft:pink_terracotta
setblock 330 225 471 minecraft:red_nether_bricks
fill 330 225 472 330 228 472 minecraft:pink_terracotta
setblock 330 225 476 minecraft:red_nether_bricks
setblock 330 225 487 minecraft:pink_terracotta
setblock 330 225 491 minecraft:red_nether_bricks
fill 330 225 492 330 228 492 minecraft:pink_terracotta
setblock 330 225 496 minecraft:red_nether_bricks
fill 330 225 497 330 228 497 minecraft:pink_terracotta
setblock 330 225 501 minecraft:red_nether_bricks
fill 330 225 502 330 228 502 minecraft:pink_terracotta
setblock 331 225 465 minecraft:red_nether_bricks
fill 331 225 466 331 226 466 minecraft:pink_terracotta
setblock 331 225 470 minecraft:red_nether_bricks
fill 331 225 471 331 226 471 minecraft:pink_terracotta
setblock 331 225 491 minecraft:pink_terracotta
setblock 331 225 495 minecraft:red_nether_bricks
setblock 332 225 464 minecraft:red_nether_bricks
setblock 332 225 465 minecraft:pink_terracotta
setblock 332 225 466 minecraft:light[level=12]
setblock 332 225 474 minecraft:light[level=12]
setblock 332 225 482 minecraft:light[level=12]
setblock 332 225 490 minecraft:light[level=12]
setblock 332 225 498 minecraft:light[level=12]
setblock 332 225 504 minecraft:red_nether_bricks
fill 333 225 464 334 225 464 minecraft:pink_terracotta
setblock 333 225 504 minecraft:pink_terracotta
setblock 340 225 466 minecraft:light[level=12]
setblock 340 225 474 minecraft:light[level=12]
setblock 340 225 482 minecraft:light[level=12]
setblock 340 225 490 minecraft:light[level=12]
setblock 340 225 498 minecraft:light[level=12]
setblock 342 225 464 minecraft:red_nether_bricks
setblock 342 225 504 minecraft:red_nether_bricks
setblock 343 225 464 minecraft:pink_terracotta
fill 343 225 504 343 228 504 minecraft:pink_terracotta
setblock 347 225 464 minecraft:red_nether_bricks
setblock 347 225 504 minecraft:red_nether_bricks
setblock 348 225 464 minecraft:pink_terracotta
setblock 348 225 466 minecraft:light[level=12]
setblock 348 225 474 minecraft:light[level=12]
setblock 348 225 482 minecraft:light[level=12]
setblock 348 225 490 minecraft:light[level=12]
setblock 348 225 498 minecraft:light[level=12]
setblock 348 225 504 minecraft:pink_terracotta
setblock 354 225 464 minecraft:white_concrete
setblock 356 225 466 minecraft:light[level=12]
setblock 356 225 474 minecraft:light[level=12]
setblock 356 225 482 minecraft:light[level=12]
setblock 356 225 490 minecraft:light[level=12]
setblock 356 225 498 minecraft:light[level=12]
setblock 362 225 464 minecraft:red_nether_bricks
fill 363 225 464 363 228 464 minecraft:pink_terracotta
setblock 364 225 474 minecraft:light[level=12]
setblock 364 225 482 minecraft:light[level=12]
setblock 364 225 490 minecraft:light[level=12]
setblock 364 225 498 minecraft:light[level=12]
setblock 365 225 466 minecraft:red_nether_bricks
setblock 365 225 504 minecraft:white_concrete
setblock 366 225 465 minecraft:red_nether_bricks
fill 366 225 466 366 227 466 minecraft:pink_terracotta
setblock 367 225 464 minecraft:red_nether_bricks
fill 367 225 465 367 228 465 minecraft:pink_terracotta
setblock 367 225 469 minecraft:red_nether_bricks
fill 367 225 470 367 228 470 minecraft:pink_terracotta
setblock 367 225 504 minecraft:red_nether_bricks
fill 368 225 464 368 228 464 minecraft:pink_terracotta
setblock 368 225 468 minecraft:red_nether_bricks
fill 368 225 469 368 228 469 minecraft:pink_terracotta
setblock 368 225 473 minecraft:red_nether_bricks
fill 368 225 474 368 228 474 minecraft:pink_terracotta
setblock 368 225 504 minecraft:pink_terracotta
setblock 369 225 467 minecraft:red_nether_bricks
fill 369 225 468 369 228 468 minecraft:pink_terracotta
setblock 369 225 472 minecraft:red_nether_bricks
fill 369 225 473 369 228 473 minecraft:pink_terracotta
setblock 369 225 477 minecraft:red_nether_bricks
setblock 369 225 478 minecraft:pink_terracotta
setblock 369 225 487 minecraft:red_nether_bricks
setblock 369 225 488 minecraft:pink_terracotta
setblock 369 225 492 minecraft:red_nether_bricks
fill 369 225 493 369 226 493 minecraft:pink_terracotta
setblock 370 225 466 minecraft:red_nether_bricks
fill 370 225 467 370 228 467 minecraft:pink_terracotta
setblock 370 225 471 minecraft:red_nether_bricks
fill 370 225 472 370 228 472 minecraft:pink_terracotta
setblock 370 225 476 minecraft:red_nether_bricks
fill 370 225 477 370 228 477 minecraft:pink_terracotta
setblock 370 225 481 minecraft:red_nether_bricks
setblock 370 225 486 minecraft:red_nether_bricks
fill 370 225 487 370 226 487 minecraft:pink_terracotta
setblock 370 225 491 minecraft:red_nether_bricks
fill 370 225 492 370 228 492 minecraft:pink_terracotta
setblock 370 225 496 minecraft:red_nether_bricks
fill 370 225 497 370 226 497 minecraft:pink_terracotta
setblock 330 226 465 minecraft:red_nether_bricks
fill 330 226 466 330 228 466 minecraft:pink_terracotta
setblock 330 226 470 minecraft:red_nether_bricks
fill 330 226 471 330 229 471 minecraft:pink_terracotta
setblock 330 226 475 minecraft:red_nether_bricks
setblock 330 226 482 minecraft:white_concrete
setblock 330 226 490 minecraft:red_nether_bricks
fill 330 226 491 330 229 491 minecraft:pink_terracotta
setblock 330 226 495 minecraft:red_nether_bricks
fill 330 226 496 330 229 496 minecraft:pink_terracotta
setblock 330 226 500 minecraft:red_nether_bricks
fill 330 226 501 330 229 501 minecraft:pink_terracotta
setblock 331 226 464 minecraft:red_nether_bricks
setblock 331 226 465 minecraft:pink_terracotta
setblock 331 226 469 minecraft:red_nether_bricks
setblock 331 226 470 minecraft:pink_terracotta
setblock 331 226 494 minecraft:red_nether_bricks
setblock 331 226 504 minecraft:red_nether_bricks
setblock 332 226 464 minecraft:pink_terracotta
fill 333 226 504 333 227 504 minecraft:white_concrete
fill 342 226 504 342 227 504 minecraft:pink_terracotta
setblock 346 226 464 minecraft:red_nether_bricks
setblock 346 226 504 minecraft:red_nether_bricks
setblock 347 226 464 minecraft:pink_terracotta
setblock 347 226 504 minecraft:pink_terracotta
setblock 348 226 464 minecraft:white_concrete
setblock 352 226 504 minecraft:white_concrete
fill 362 226 464 362 229 464 minecraft:pink_terracotta
setblock 364 226 466 minecraft:red_nether_bricks
setblock 365 226 465 minecraft:red_nether_bricks
fill 365 226 466 365 227 466 minecraft:pink_terracotta
setblock 366 226 464 minecraft:red_nether_bricks
fill 366 226 465 366 229 465 minecraft:pink_terracotta
fill 367 226 464 367 229 464 minecraft:pink_terracotta
setblock 367 226 468 minecraft:red_nether_bricks
fill 367 226 469 367 227 469 minecraft:pink_terracotta
setblock 367 226 473 minecraft:red_nether_bricks
setblock 368 226 467 minecraft:red_nether_bricks
fill 368 226 468 368 229 468 minecraft:pink_terracotta
setblock 368 226 472 minecraft:red_nether_bricks
fill 368 226 473 368 229 473 minecraft:pink_terracotta
setblock 369 226 466 minecraft:red_nether_bricks
fill 369 226 467 369 229 467 minecraft:pink_terracotta
setblock 369 226 471 minecraft:red_nether_bricks
fill 369 226 472 369 229 472 minecraft:pink_terracotta
setblock 369 226 476 minecraft:red_nether_bricks
fill 369 226 477 369 227 477 minecraft:pink_terracotta
setblock 369 226 491 minecraft:red_nether_bricks
setblock 369 226 492 minecraft:pink_terracotta
setblock 370 226 465 minecraft:red_nether_bricks
fill 370 226 466 370 229 466 minecraft:pink_terracotta
setblock 370 226 470 minecraft:red_nether_bricks
fill 370 226 471 370 229 471 minecraft:pink_terracotta
setblock 370 226 475 minecraft:red_nether_bricks
fill 370 226 476 370 229 476 minecraft:pink_terracotta
setblock 370 226 486 minecraft:white_concrete
setblock 370 226 490 minecraft:red_nether_bricks
fill 370 226 491 370 227 491 minecraft:pink_terracotta
setblock 370 226 495 minecraft:red_nether_bricks
fill 370 226 496 370 229 496 minecraft:pink_terracotta
setblock 330 227 464 minecraft:red_nether_bricks
fill 330 227 465 330 228 465 minecraft:pink_terracotta
setblock 330 227 469 minecraft:red_nether_bricks
fill 330 227 470 330 230 470 minecraft:pink_terracotta
setblock 330 227 474 minecraft:red_nether_bricks
fill 330 227 475 330 228 475 minecraft:pink_terracotta
setblock 330 227 488 minecraft:white_concrete
setblock 330 227 490 minecraft:pink_terracotta
setblock 330 227 494 minecraft:red_nether_bricks
fill 330 227 495 330 230 495 minecraft:pink_terracotta
setblock 330 227 499 minecraft:red_nether_bricks
fill 330 227 500 330 230 500 minecraft:pink_terracotta
setblock 330 227 504 minecraft:red_nether_bricks
setblock 331 227 464 minecraft:pink_terracotta
setblock 339 227 504 minecraft:white_concrete
setblock 342 227 464 minecraft:white_concrete
setblock 345 227 504 minecraft:red_nether_bricks
setblock 346 227 504 minecraft:pink_terracotta
fill 348 227 474 349 228 475 minecraft:pink_concrete
fill 354 227 492 354 227 494 minecraft:white_concrete
fill 355 227 492 357 227 492 minecraft:white_concrete
fill 355 227 495 356 227 495 minecraft:white_concrete
fill 356 227 497 356 227 500 minecraft:white_concrete
fill 357 227 493 357 228 494 minecraft:white_concrete
fill 357 227 496 357 227 497 minecraft:white_concrete
fill 357 227 500 360 227 500 minecraft:white_concrete
fill 358 227 496 360 227 496 minecraft:white_concrete
fill 358 227 501 359 227 501 minecraft:white_concrete
setblock 358 227 504 minecraft:white_concrete
fill 360 227 497 360 228 499 minecraft:white_concrete
setblock 361 227 464 minecraft:white_concrete
fill 361 227 498 361 227 499 minecraft:white_concrete
setblock 364 227 465 minecraft:red_nether_bricks
setblock 365 227 464 minecraft:red_nether_bricks
fill 365 227 465 365 230 465 minecraft:pink_terracotta
fill 366 227 464 366 230 464 minecraft:pink_terracotta
setblock 367 227 472 minecraft:red_nether_bricks
fill 367 227 473 367 228 473 minecraft:pink_terracotta
setblock 368 227 466 minecraft:red_nether_bricks
fill 368 227 467 368 228 467 minecraft:pink_terracotta
setblock 368 227 471 minecraft:red_nether_bricks
fill 368 227 472 368 230 472 minecraft:pink_terracotta
setblock 369 227 465 minecraft:red_nether_bricks
fill 369 227 466 369 229 466 minecraft:pink_terracotta
setblock 369 227 470 minecraft:red_nether_bricks
fill 369 227 471 369 230 471 minecraft:pink_terracotta
setblock 369 227 475 minecraft:red_nether_bricks
fill 369 227 476 369 230 476 minecraft:pink_terracotta
setblock 370 227 464 minecraft:red_nether_bricks
fill 370 227 465 370 230 465 minecraft:pink_terracotta
setblock 370 227 469 minecraft:red_nether_bricks
fill 370 227 470 370 230 470 minecraft:pink_terracotta
setblock 370 227 474 minecraft:red_nether_bricks
fill 370 227 475 370 230 475 minecraft:pink_terracotta
setblock 370 227 480 minecraft:white_concrete
setblock 370 227 490 minecraft:pink_terracotta
setblock 370 227 494 minecraft:red_nether_bricks
fill 370 227 495 370 230 495 minecraft:pink_terracotta
setblock 370 227 499 minecraft:white_concrete
setblock 330 228 464 minecraft:pink_terracotta
setblock 330 228 468 minecraft:red_nether_bricks
fill 330 228 469 330 230 469 minecraft:pink_terracotta
setblock 330 228 473 minecraft:red_nether_bricks
fill 330 228 474 330 230 474 minecraft:pink_terracotta
setblock 330 228 493 minecraft:red_nether_bricks
fill 330 228 494 330 230 494 minecraft:pink_terracotta
setblock 330 228 498 minecraft:red_nether_bricks
fill 330 228 499 330 230 499 minecraft:pink_terracotta
setblock 336 228 464 minecraft:white_concrete
setblock 344 228 504 minecraft:red_nether_bricks
setblock 345 228 504 minecraft:pink_terracotta
setblock 354 228 493 minecraft:white_concrete
setblock 355 228 464 minecraft:white_concrete
fill 355 228 492 356 229 492 minecraft:white_concrete
fill 356 228 498 356 228 499 minecraft:white_concrete
fill 357 228 497 357 229 497 minecraft:white_concrete
fill 357 228 500 359 228 500 minecraft:white_concrete
fill 358 228 496 359 228 496 minecraft:white_concrete
setblock 364 228 464 minecraft:red_nether_bricks
fill 364 228 465 364 230 465 minecraft:pink_terracotta
setblock 364 228 504 minecraft:white_concrete
fill 365 228 464 365 230 464 minecraft:pink_terracotta
setblock 367 228 471 minecraft:red_nether_bricks
fill 367 228 472 367 229 472 minecraft:pink_terracotta
setblock 368 228 465 minecraft:red_nether_bricks
setblock 368 228 470 minecraft:red_nether_bricks
fill 368 228 471 368 230 471 minecraft:pink_terracotta
setblock 368 228 475 minecraft:red_nether_bricks
setblock 369 228 464 minecraft:red_nether_bricks
setblock 369 228 465 minecraft:pink_terracotta
setblock 369 228 469 minecraft:red_nether_bricks
fill 369 228 470 369 230 470 minecraft:pink_terracotta
setblock 369 228 474 minecraft:red_nether_bricks
fill 369 228 475 369 230 475 minecraft:pink_terracotta
fill 370 228 464 370 230 464 minecraft:pink_terracotta
setblock 370 228 468 minecraft:red_nether_bricks
fill 370 228 469 370 230 469 minecraft:pink_terracotta
setblock 370 228 473 minecraft:red_nether_bricks
fill 370 228 474 370 230 474 minecraft:pink_terracotta
setblock 370 228 478 minecraft:red_nether_bricks
setblock 370 228 493 minecraft:red_nether_bricks
fill 370 228 494 370 230 494 minecraft:pink_terracotta
setblock 330 229 467 minecraft:red_nether_bricks
setblock 330 229 468 minecraft:pink_terracotta
setblock 330 229 472 minecraft:red_nether_bricks
fill 330 229 473 330 230 473 minecraft:pink_terracotta
setblock 330 229 481 minecraft:white_concrete
setblock 330 229 492 minecraft:red_nether_bricks
fill 330 229 493 330 230 493 minecraft:pink_terracotta
setblock 330 229 497 minecraft:red_nether_bricks
fill 330 229 498 330 230 498 minecraft:pink_terracotta
setblock 330 229 502 minecraft:red_nether_bricks
setblock 342 229 504 minecraft:pink_terracotta
setblock 343 229 504 minecraft:red_nether_bricks
fill 344 229 504 344 230 504 minecraft:pink_terracotta
setblock 349 229 464 minecraft:white_concrete
setblock 351 229 504 minecraft:white_concrete
fill 358 229 500 359 229 500 minecraft:white_concrete
fill 360 229 498 360 229 499 minecraft:white_concrete
setblock 363 229 464 minecraft:red_nether_bricks
fill 364 229 464 364 230 464 minecraft:pink_terracotta
setblock 367 229 465 minecraft:red_nether_bricks
setblock 368 229 464 minecraft:red_nether_bricks
setblock 368 229 465 minecraft:pink_terracotta
setblock 368 229 469 minecraft:red_nether_bricks
fill 368 229 470 368 230 470 minecraft:pink_terracotta
setblock 368 229 474 minecraft:red_nether_bricks
fill 368 229 475 368 230 475 minecraft:pink_terracotta
fill 369 229 464 369 230 464 minecraft:pink_terracotta
setblock 369 229 468 minecraft:red_nether_bricks
fill 369 229 469 369 230 469 minecraft:pink_terracotta
setblock 369 229 473 minecraft:red_nether_bricks
fill 369 229 474 369 230 474 minecraft:pink_terracotta
setblock 370 229 467 minecraft:red_nether_bricks
fill 370 229 468 370 230 468 minecraft:pink_terracotta
setblock 370 229 472 minecraft:red_nether_bricks
fill 370 229 473 370 230 473 minecraft:pink_terracotta
setblock 370 229 477 minecraft:red_nether_bricks
setblock 370 229 487 minecraft:white_concrete
setblock 370 229 493 minecraft:pink_terracotta
setblock 370 229 497 minecraft:red_nether_bricks
setblock 370 229 504 minecraft:white_concrete
setblock 330 230 471 minecraft:red_nether_bricks
setblock 330 230 472 minecraft:pink_terracotta
setblock 330 230 487 minecraft:white_concrete
setblock 330 230 492 minecraft:pink_terracotta
setblock 330 230 496 minecraft:red_nether_bricks
fill 330 230 497 331 230 497 minecraft:pink_terracotta
setblock 330 230 501 minecraft:red_nether_bricks
fill 330 230 502 330 230 503 minecraft:pink_terracotta
setblock 331 230 496 minecraft:pink_terracotta
setblock 332 230 504 minecraft:white_concrete
fill 340 230 504 341 230 504 minecraft:pink_terracotta
setblock 342 230 504 minecraft:red_nether_bricks
setblock 343 230 464 minecraft:white_concrete
setblock 343 230 504 minecraft:pink_terracotta
setblock 345 230 504 minecraft:pink_terracotta
setblock 357 230 504 minecraft:white_concrete
setblock 361 230 464 minecraft:pink_terracotta
setblock 362 230 464 minecraft:red_nether_bricks
fill 363 230 464 363 230 465 minecraft:pink_terracotta
setblock 366 230 465 minecraft:red_nether_bricks
setblock 367 230 464 minecraft:red_nether_bricks
setblock 367 230 465 minecraft:pink_terracotta
setblock 368 230 464 minecraft:pink_terracotta
setblock 368 230 469 minecraft:pink_terracotta
setblock 368 230 473 minecraft:red_nether_bricks
setblock 368 230 474 minecraft:pink_terracotta
setblock 369 230 467 minecraft:red_nether_bricks
setblock 369 230 468 minecraft:pink_terracotta
setblock 369 230 472 minecraft:red_nether_bricks
setblock 369 230 473 minecraft:pink_terracotta
setblock 370 230 466 minecraft:red_nether_bricks
setblock 370 230 467 minecraft:pink_terracotta
setblock 370 230 471 minecraft:red_nether_bricks
setblock 370 230 472 minecraft:pink_terracotta
setblock 370 230 476 minecraft:red_nether_bricks
fill 370 230 477 370 230 478 minecraft:pink_terracotta
setblock 370 230 481 minecraft:white_concrete
setblock 370 230 496 minecraft:red_nether_bricks
fill 370 230 497 370 230 498 minecraft:pink_terracotta
setblock 332 233 466 minecraft:light[level=12]
setblock 332 233 474 minecraft:light[level=12]
setblock 332 233 482 minecraft:light[level=12]
setblock 332 233 490 minecraft:light[level=12]
setblock 332 233 498 minecraft:light[level=12]
setblock 340 233 466 minecraft:light[level=12]
setblock 340 233 474 minecraft:light[level=12]
setblock 340 233 482 minecraft:light[level=12]
setblock 340 233 490 minecraft:light[level=12]
setblock 340 233 498 minecraft:light[level=12]
setblock 348 233 466 minecraft:light[level=12]
setblock 348 233 474 minecraft:light[level=12]
setblock 348 233 482 minecraft:light[level=12]
setblock 348 233 490 minecraft:light[level=12]
setblock 348 233 498 minecraft:light[level=12]
setblock 356 233 466 minecraft:light[level=12]
setblock 356 233 474 minecraft:light[level=12]
setblock 356 233 482 minecraft:light[level=12]
setblock 356 233 490 minecraft:light[level=12]
setblock 356 233 498 minecraft:light[level=12]
setblock 364 233 466 minecraft:light[level=12]
setblock 364 233 474 minecraft:light[level=12]
setblock 364 233 482 minecraft:light[level=12]
setblock 364 233 490 minecraft:light[level=12]
setblock 364 233 498 minecraft:light[level=12]
fill 332 236 483 333 237 483 minecraft:red_terracotta
fill 333 236 480 334 237 482 minecraft:red_terracotta
fill 333 236 484 334 237 486 minecraft:red_terracotta
fill 334 236 478 335 237 479 minecraft:red_terracotta
fill 334 236 483 342 237 483 minecraft:white_concrete
fill 334 236 487 335 237 488 minecraft:red_terracotta
fill 335 236 477 337 237 477 minecraft:red_terracotta
fill 335 236 480 342 237 482 minecraft:white_concrete
fill 335 236 484 342 237 486 minecraft:white_concrete
fill 335 236 489 337 237 489 minecraft:red_terracotta
fill 336 236 476 339 237 476 minecraft:red_terracotta
fill 336 236 478 336 237 478 minecraft:red_terracotta
fill 336 236 479 344 237 479 minecraft:white_concrete
fill 336 236 487 344 237 487 minecraft:white_concrete
fill 336 236 488 336 237 488 minecraft:red_terracotta
fill 336 236 490 339 237 490 minecraft:red_terracotta
fill 337 236 475 341 237 475 minecraft:red_terracotta
fill 337 236 478 345 237 478 minecraft:white_concrete
fill 337 236 488 345 237 488 minecraft:white_concrete
fill 337 236 491 341 237 491 minecraft:red_terracotta
fill 338 236 477 343 237 477 minecraft:white_concrete
fill 338 236 489 343 237 489 minecraft:white_concrete
fill 339 236 474 345 237 474 minecraft:red_terracotta
fill 339 236 492 345 237 492 minecraft:red_terracotta
fill 340 236 476 358 237 476 minecraft:white_concrete
fill 340 236 490 358 237 490 minecraft:white_concrete
fill 342 236 473 356 237 473 minecraft:red_terracotta
fill 342 236 475 356 237 475 minecraft:white_concrete
fill 342 236 491 356 237 491 minecraft:white_concrete
fill 342 236 493 356 237 493 minecraft:red_terracotta
fill 343 236 480 343 237 481 minecraft:white_concrete
fill 343 236 482 344 237 482 minecraft:orange_concrete
fill 343 236 483 345 237 483 minecraft:red_concrete
fill 343 236 484 344 237 484 minecraft:orange_concrete
fill 343 236 485 343 237 486 minecraft:white_concrete
fill 344 236 477 344 237 477 minecraft:red_concrete
fill 344 236 480 344 237 480 minecraft:orange_concrete
fill 344 236 481 344 237 481 minecraft:red_concrete
fill 344 236 485 344 237 485 minecraft:red_concrete
fill 344 236 486 344 237 486 minecraft:orange_concrete
fill 344 236 489 344 237 489 minecraft:red_concrete
fill 345 236 477 347 237 477 minecraft:white_concrete
fill 345 236 479 345 237 480 minecraft:red_concrete
fill 345 236 481 345 237 481 minecraft:orange_concrete
fill 345 236 482 346 236 482 minecraft:red_concrete
fill 345 236 484 346 236 484 minecraft:red_concrete
fill 345 236 485 345 237 485 minecraft:orange_concrete
fill 345 236 486 345 237 487 minecraft:red_concrete
fill 345 236 489 347 237 489 minecraft:white_concrete
fill 346 236 472 352 237 472 minecraft:red_terracotta
fill 346 236 474 352 237 474 minecraft:white_concrete
fill 346 236 478 346 237 478 minecraft:red_concrete
fill 346 236 479 346 237 479 minecraft:orange_concrete
fill 346 236 480 346 237 481 minecraft:red_concrete
setblock 346 236 483 minecraft:black_concrete
fill 346 236 485 346 237 486 minecraft:red_concrete
fill 346 236 487 346 237 487 minecraft:orange_concrete
fill 346 236 488 346 237 488 minecraft:red_concrete
fill 346 236 492 352 237 492 minecraft:white_concrete
fill 346 236 494 352 237 494 minecraft:red_terracotta
fill 347 236 478 347 237 478 minecraft:orange_concrete
fill 347 236 479 347 237 480 minecraft:red_concrete
fill 347 236 481 347 236 482 minecraft:black_concrete
fill 347 236 484 347 236 485 minecraft:black_concrete
fill 347 236 486 347 237 487 minecraft:red_concrete
fill 347 236 488 347 237 488 minecraft:orange_concrete
fill 348 236 477 348 237 479 minecraft:red_concrete
setblock 348 236 480 minecraft:orange_concrete
setblock 348 236 481 minecraft:black_concrete
setblock 348 236 485 minecraft:black_concrete
setblock 348 236 486 minecraft:orange_concrete
fill 348 236 487 348 237 489 minecraft:red_concrete
fill 349 236 477 349 237 479 minecraft:orange_concrete
setblock 349 236 480 minecraft:black_concrete
setblock 349 236 486 minecraft:black_concrete
fill 349 236 487 349 237 489 minecraft:orange_concrete
fill 350 236 477 350 237 479 minecraft:red_concrete
setblock 350 236 480 minecraft:orange_concrete
fill 350 236 481 351 236 481 minecraft:black_concrete
fill 350 236 485 351 236 485 minecraft:black_concrete
setblock 350 236 486 minecraft:orange_concrete
fill 350 236 487 350 237 489 minecraft:red_concrete
fill 351 236 477 353 237 477 minecraft:white_concrete
fill 351 236 478 351 237 478 minecraft:orange_concrete
schedule function dropper:buildpart/115_7 1t
