fill 310 65 241 310 67 243 minecraft:blackstone
fill 310 65 244 310 67 244 minecraft:polished_blackstone
fill 310 65 247 312 67 247 minecraft:blackstone
fill 310 65 248 310 67 248 minecraft:polished_blackstone
fill 310 65 251 313 65 251 minecraft:blackstone
fill 310 65 252 310 67 252 minecraft:polished_blackstone
fill 310 65 255 323 65 255 minecraft:blackstone
setblock 311 65 228 minecraft:netherrack
fill 311 65 234 323 65 234 minecraft:blackstone
fill 311 65 240 323 65 240 minecraft:blackstone
fill 311 65 241 311 67 241 minecraft:polished_blackstone
fill 311 65 242 311 67 244 minecraft:blackstone
fill 311 65 245 311 67 245 minecraft:polished_blackstone
fill 311 65 246 312 67 246 minecraft:magma_block
fill 311 65 248 323 65 248 minecraft:blackstone
fill 311 65 249 311 67 249 minecraft:polished_blackstone
fill 311 65 252 313 65 252 minecraft:blackstone
fill 311 65 253 311 67 253 minecraft:polished_blackstone
fill 312 65 228 319 87 228 minecraft:basalt
fill 312 65 241 323 65 241 minecraft:blackstone
fill 312 65 242 312 67 242 minecraft:polished_blackstone
fill 312 65 243 312 67 245 minecraft:blackstone
fill 312 65 249 323 65 249 minecraft:blackstone
fill 312 65 250 312 67 250 minecraft:polished_blackstone
fill 312 65 253 323 65 253 minecraft:blackstone
fill 313 65 235 323 65 237 minecraft:blackstone
fill 313 65 242 323 65 242 minecraft:blackstone
fill 313 65 243 313 67 243 minecraft:polished_blackstone
fill 313 65 244 323 65 244 minecraft:blackstone
fill 313 65 245 313 67 245 minecraft:magma_block
fill 313 65 246 323 65 246 minecraft:blackstone
fill 313 65 247 313 67 247 minecraft:polished_blackstone
fill 313 65 250 313 67 250 minecraft:blackstone
fill 314 65 243 323 65 243 minecraft:blackstone
fill 314 65 245 323 65 245 minecraft:blackstone
fill 314 65 247 323 65 247 minecraft:blackstone
fill 316 65 250 323 65 250 minecraft:blackstone
fill 317 65 251 323 65 252 minecraft:blackstone
fill 320 65 228 320 66 228 minecraft:netherrack
setblock 321 65 270 minecraft:netherrack
fill 322 65 270 323 65 270 minecraft:basalt
fill 324 65 236 324 141 236 minecraft:basalt
setblock 324 65 237 minecraft:netherrack
fill 324 65 238 324 65 252 minecraft:basalt
setblock 324 65 253 minecraft:netherrack
fill 324 65 254 324 65 259 minecraft:basalt
setblock 324 65 260 minecraft:netherrack
fill 324 65 261 324 124 264 minecraft:basalt
setblock 282 66 228 minecraft:netherrack
fill 282 66 229 282 82 230 minecraft:basalt
setblock 282 66 231 minecraft:netherrack
fill 282 66 232 282 104 237 minecraft:basalt
setblock 282 66 238 minecraft:netherrack
fill 282 66 239 282 80 242 minecraft:basalt
setblock 282 66 244 minecraft:netherrack
fill 282 66 245 282 86 247 minecraft:basalt
fill 282 66 249 282 173 249 minecraft:basalt
fill 282 66 254 282 98 254 minecraft:basalt
fill 282 66 257 282 70 258 minecraft:basalt
fill 282 66 259 282 66 260 minecraft:netherrack
fill 282 66 261 282 141 262 minecraft:basalt
setblock 282 66 263 minecraft:netherrack
fill 282 66 264 282 165 264 minecraft:basalt
fill 282 66 265 282 66 266 minecraft:netherrack
fill 282 66 267 282 136 267 minecraft:basalt
setblock 282 66 268 minecraft:netherrack
fill 282 66 269 282 169 270 minecraft:basalt
fill 285 66 228 286 173 228 minecraft:basalt
fill 289 66 228 289 127 228 minecraft:basalt
fill 293 66 242 293 67 242 minecraft:blackstone
fill 293 66 250 294 67 250 minecraft:blackstone
fill 294 66 270 296 114 270 minecraft:basalt
fill 295 66 239 295 67 240 minecraft:blackstone
fill 297 66 237 298 67 237 minecraft:blackstone
setblock 297 66 270 minecraft:netherrack
fill 299 66 256 301 67 256 minecraft:blackstone
fill 299 66 270 301 117 270 minecraft:basalt
setblock 302 66 270 minecraft:netherrack
fill 303 66 235 303 67 235 minecraft:blackstone
fill 303 66 270 305 97 270 minecraft:basalt
fill 304 66 255 304 67 256 minecraft:blackstone
fill 305 66 256 305 67 256 minecraft:blackstone
fill 307 66 236 307 67 236 minecraft:blackstone
fill 307 66 256 307 67 256 minecraft:blackstone
fill 309 66 238 310 67 238 minecraft:blackstone
fill 309 66 254 310 67 254 minecraft:blackstone
fill 310 66 239 311 67 239 minecraft:blackstone
fill 310 66 251 312 67 251 minecraft:blackstone
fill 311 66 228 311 169 228 minecraft:basalt
fill 311 66 240 312 67 240 minecraft:blackstone
fill 311 66 248 313 67 248 minecraft:blackstone
fill 311 66 252 312 67 252 minecraft:blackstone
fill 312 66 241 312 67 241 minecraft:blackstone
fill 312 66 249 313 67 249 minecraft:blackstone
fill 313 66 242 313 67 242 minecraft:blackstone
fill 313 66 244 313 67 244 minecraft:blackstone
fill 313 66 246 314 67 246 minecraft:blackstone
fill 321 66 228 322 87 228 minecraft:basalt
fill 321 66 270 322 88 270 minecraft:basalt
setblock 323 66 228 minecraft:netherrack
setblock 323 66 270 minecraft:shroomlight
fill 324 66 228 324 75 229 minecraft:basalt
setblock 324 66 230 minecraft:netherrack
fill 324 66 231 324 88 233 minecraft:basalt
setblock 324 66 234 minecraft:netherrack
fill 324 66 235 324 149 235 minecraft:basalt
fill 324 66 237 324 112 238 minecraft:basalt
setblock 324 66 239 minecraft:netherrack
fill 324 66 240 324 67 255 minecraft:basalt
setblock 324 66 256 minecraft:netherrack
fill 324 66 257 324 114 260 minecraft:basalt
fill 282 67 228 282 170 228 minecraft:basalt
fill 282 67 231 282 91 231 minecraft:basalt
fill 282 67 238 282 105 238 minecraft:basalt
fill 282 67 244 282 173 244 minecraft:basalt
fill 282 67 259 282 86 260 minecraft:basalt
fill 282 67 263 282 141 263 minecraft:basalt
fill 282 67 265 282 170 266 minecraft:basalt
fill 282 67 268 282 122 268 minecraft:basalt
setblock 285 67 231 minecraft:light[level=12]
setblock 285 67 239 minecraft:light[level=12]
setblock 285 67 247 minecraft:light[level=12]
setblock 285 67 255 minecraft:light[level=12]
setblock 285 67 263 minecraft:light[level=12]
setblock 293 67 231 minecraft:light[level=12]
setblock 293 67 239 minecraft:light[level=12]
setblock 293 67 255 minecraft:light[level=12]
setblock 293 67 263 minecraft:light[level=12]
fill 297 67 270 298 87 270 minecraft:basalt
fill 299 67 244 299 67 248 minecraft:shroomlight
fill 300 67 243 300 67 244 minecraft:shroomlight
fill 300 67 248 300 67 249 minecraft:shroomlight
setblock 301 67 231 minecraft:light[level=12]
fill 301 67 242 301 67 243 minecraft:shroomlight
fill 301 67 249 301 67 250 minecraft:shroomlight
fill 301 67 251 301 67 255 minecraft:magma_block
setblock 301 67 263 minecraft:light[level=12]
fill 302 67 242 305 67 242 minecraft:shroomlight
fill 302 67 250 305 67 250 minecraft:shroomlight
fill 302 67 251 303 67 251 minecraft:blackstone
fill 302 67 270 302 145 270 minecraft:basalt
fill 303 67 228 307 77 228 minecraft:basalt
fill 305 67 243 306 67 243 minecraft:shroomlight
fill 305 67 249 306 67 249 minecraft:shroomlight
setblock 306 67 242 minecraft:blackstone
fill 306 67 244 307 67 244 minecraft:shroomlight
fill 306 67 248 307 67 248 minecraft:shroomlight
fill 307 67 243 308 67 243 minecraft:blackstone
fill 307 67 245 307 67 247 minecraft:shroomlight
setblock 308 67 228 minecraft:crying_obsidian
fill 308 67 244 309 67 244 minecraft:blackstone
fill 308 67 247 309 67 247 minecraft:magma_block
fill 308 67 248 309 67 248 minecraft:blackstone
fill 309 67 228 310 87 228 minecraft:basalt
setblock 309 67 231 minecraft:light[level=12]
setblock 309 67 263 minecraft:light[level=12]
setblock 317 67 231 minecraft:light[level=12]
setblock 317 67 239 minecraft:light[level=12]
setblock 317 67 247 minecraft:light[level=12]
setblock 317 67 255 minecraft:light[level=12]
setblock 317 67 263 minecraft:light[level=12]
fill 320 67 228 320 70 228 minecraft:basalt
fill 323 67 228 323 81 228 minecraft:basalt
fill 323 67 270 323 71 270 minecraft:basalt
fill 324 67 230 324 131 230 minecraft:basalt
fill 324 67 234 324 173 234 minecraft:basalt
fill 324 67 239 324 173 239 minecraft:basalt
fill 324 67 256 324 117 256 minecraft:basalt
fill 308 68 228 308 173 228 minecraft:basalt
fill 324 68 240 324 73 248 minecraft:basalt
setblock 324 68 249 minecraft:magma_block
fill 324 68 250 324 73 251 minecraft:basalt
setblock 324 68 252 minecraft:magma_block
fill 324 68 253 324 93 255 minecraft:basalt
setblock 285 69 231 minecraft:light[level=12]
setblock 285 69 238 minecraft:light[level=12]
setblock 285 69 245 minecraft:light[level=12]
setblock 285 69 252 minecraft:light[level=12]
setblock 285 69 259 minecraft:light[level=12]
setblock 285 69 266 minecraft:light[level=12]
setblock 292 69 231 minecraft:light[level=12]
setblock 292 69 238 minecraft:light[level=12]
setblock 292 69 245 minecraft:light[level=12]
setblock 292 69 252 minecraft:light[level=12]
setblock 292 69 259 minecraft:light[level=12]
setblock 292 69 266 minecraft:light[level=12]
fill 299 69 228 299 173 228 minecraft:basalt
setblock 299 69 231 minecraft:light[level=12]
setblock 299 69 238 minecraft:light[level=12]
setblock 299 69 245 minecraft:light[level=12]
setblock 299 69 252 minecraft:light[level=12]
setblock 299 69 259 minecraft:light[level=12]
setblock 299 69 266 minecraft:light[level=12]
setblock 300 69 228 minecraft:magma_block
fill 301 69 228 302 84 228 minecraft:basalt
setblock 306 69 231 minecraft:light[level=12]
setblock 306 69 238 minecraft:light[level=12]
setblock 306 69 252 minecraft:light[level=12]
setblock 306 69 259 minecraft:light[level=12]
setblock 306 69 266 minecraft:light[level=12]
setblock 313 69 231 minecraft:light[level=12]
setblock 313 69 238 minecraft:light[level=12]
setblock 313 69 245 minecraft:light[level=12]
setblock 313 69 252 minecraft:light[level=12]
setblock 313 69 259 minecraft:light[level=12]
setblock 313 69 266 minecraft:light[level=12]
setblock 320 69 231 minecraft:light[level=12]
setblock 320 69 238 minecraft:light[level=12]
setblock 320 69 245 minecraft:light[level=12]
setblock 320 69 252 minecraft:light[level=12]
setblock 320 69 259 minecraft:light[level=12]
setblock 320 69 266 minecraft:light[level=12]
fill 324 69 249 324 174 249 minecraft:basalt
fill 324 69 252 324 173 252 minecraft:basalt
fill 300 70 228 300 85 228 minecraft:basalt
fill 282 71 257 282 173 257 minecraft:basalt
setblock 282 71 258 minecraft:crying_obsidian
fill 294 71 233 295 71 234 minecraft:magma_block
fill 300 71 259 301 72 260 minecraft:basalt
fill 318 71 245 320 72 247 minecraft:blackstone
setblock 320 71 228 minecraft:shroomlight
fill 282 72 258 282 89 258 minecraft:basalt
fill 283 72 229 286 72 269 minecraft:blackstone
fill 287 72 229 323 72 232 minecraft:blackstone
fill 287 72 266 323 72 269 minecraft:blackstone
setblock 317 72 246 minecraft:blackstone
fill 319 72 244 323 72 244 minecraft:blackstone
fill 319 72 248 323 72 248 minecraft:blackstone
fill 320 72 228 320 82 228 minecraft:basalt
fill 320 72 233 323 72 243 minecraft:blackstone
fill 320 72 249 323 72 265 minecraft:blackstone
fill 321 72 245 323 72 247 minecraft:blackstone
setblock 323 72 270 minecraft:magma_block
setblock 282 73 255 minecraft:shroomlight
fill 282 73 256 282 173 256 minecraft:basalt
fill 283 73 229 285 73 269 minecraft:magma_block
fill 286 73 229 323 73 231 minecraft:magma_block
fill 286 73 267 323 73 269 minecraft:magma_block
setblock 293 73 228 minecraft:magma_block
fill 294 73 228 297 106 228 minecraft:basalt
fill 321 73 232 323 73 266 minecraft:magma_block
fill 323 73 270 323 173 270 minecraft:basalt
setblock 282 74 255 minecraft:basalt
fill 283 74 229 284 74 269 minecraft:shroomlight
fill 285 74 229 323 74 230 minecraft:shroomlight
fill 285 74 231 285 75 231 minecraft:light[level=12]
setblock 285 74 239 minecraft:light[level=12]
setblock 285 74 247 minecraft:light[level=12]
setblock 285 74 255 minecraft:light[level=12]
setblock 285 74 263 minecraft:light[level=12]
fill 285 74 268 323 74 269 minecraft:shroomlight
fill 293 74 228 293 108 228 minecraft:basalt
setblock 293 74 231 minecraft:light[level=12]
setblock 293 74 239 minecraft:light[level=12]
setblock 293 74 247 minecraft:light[level=12]
setblock 293 74 255 minecraft:light[level=12]
setblock 293 74 263 minecraft:light[level=12]
setblock 301 74 231 minecraft:light[level=12]
setblock 301 74 239 minecraft:light[level=12]
setblock 301 74 247 minecraft:light[level=12]
setblock 301 74 255 minecraft:light[level=12]
setblock 301 74 263 minecraft:light[level=12]
setblock 309 74 231 minecraft:light[level=12]
setblock 309 74 239 minecraft:light[level=12]
setblock 309 74 247 minecraft:light[level=12]
setblock 309 74 255 minecraft:light[level=12]
setblock 309 74 263 minecraft:light[level=12]
setblock 317 74 231 minecraft:light[level=12]
setblock 317 74 239 minecraft:light[level=12]
setblock 317 74 247 minecraft:light[level=12]
setblock 317 74 255 minecraft:light[level=12]
setblock 317 74 263 minecraft:light[level=12]
fill 322 74 231 323 74 267 minecraft:shroomlight
fill 324 74 240 324 169 242 minecraft:basalt
setblock 324 74 243 minecraft:crying_obsidian
fill 324 74 244 324 74 248 minecraft:basalt
setblock 324 74 250 minecraft:magma_block
fill 324 74 251 324 173 251 minecraft:basalt
setblock 282 75 255 minecraft:crying_obsidian
setblock 285 75 238 minecraft:light[level=12]
setblock 285 75 245 minecraft:light[level=12]
setblock 285 75 252 minecraft:light[level=12]
setblock 285 75 259 minecraft:light[level=12]
setblock 285 75 266 minecraft:light[level=12]
setblock 292 75 231 minecraft:light[level=12]
setblock 292 75 238 minecraft:light[level=12]
setblock 292 75 245 minecraft:light[level=12]
setblock 292 75 252 minecraft:light[level=12]
setblock 292 75 259 minecraft:light[level=12]
setblock 292 75 266 minecraft:light[level=12]
setblock 299 75 231 minecraft:light[level=12]
setblock 299 75 238 minecraft:light[level=12]
setblock 299 75 245 minecraft:light[level=12]
setblock 299 75 252 minecraft:light[level=12]
setblock 299 75 259 minecraft:light[level=12]
setblock 299 75 266 minecraft:light[level=12]
setblock 306 75 231 minecraft:light[level=12]
setblock 306 75 238 minecraft:light[level=12]
setblock 306 75 245 minecraft:light[level=12]
setblock 306 75 252 minecraft:light[level=12]
setblock 306 75 259 minecraft:light[level=12]
setblock 306 75 266 minecraft:light[level=12]
setblock 313 75 231 minecraft:light[level=12]
setblock 313 75 238 minecraft:light[level=12]
setblock 313 75 245 minecraft:light[level=12]
setblock 313 75 252 minecraft:light[level=12]
setblock 313 75 259 minecraft:light[level=12]
setblock 313 75 266 minecraft:light[level=12]
setblock 320 75 231 minecraft:light[level=12]
setblock 320 75 238 minecraft:light[level=12]
setblock 320 75 245 minecraft:light[level=12]
setblock 320 75 252 minecraft:light[level=12]
setblock 320 75 259 minecraft:light[level=12]
setblock 320 75 266 minecraft:light[level=12]
fill 324 75 243 324 99 246 minecraft:basalt
setblock 324 75 247 minecraft:shroomlight
fill 324 75 248 324 173 248 minecraft:basalt
fill 324 75 250 324 157 250 minecraft:basalt
fill 282 76 255 282 141 255 minecraft:basalt
fill 324 76 228 324 173 228 minecraft:basalt
setblock 324 76 229 minecraft:magma_block
fill 324 76 247 324 153 247 minecraft:basalt
fill 324 77 229 324 169 229 minecraft:basalt
fill 303 78 228 304 141 228 minecraft:basalt
setblock 305 78 228 minecraft:crying_obsidian
fill 306 78 228 307 93 228 minecraft:basalt
fill 288 79 270 292 100 270 minecraft:basalt
fill 290 79 256 290 80 256 minecraft:basalt
setblock 293 79 270 minecraft:crying_obsidian
fill 305 79 228 305 146 228 minecraft:basalt
fill 289 80 255 289 81 256 minecraft:basalt
fill 290 80 255 290 84 255 minecraft:basalt
fill 290 80 257 290 85 257 minecraft:basalt
setblock 290 80 258 minecraft:magma_block
fill 291 80 256 291 85 256 minecraft:basalt
setblock 291 80 257 minecraft:magma_block
fill 291 80 258 291 85 258 minecraft:basalt
setblock 292 80 256 minecraft:magma_block
fill 292 80 257 292 84 257 minecraft:basalt
fill 293 80 270 293 173 270 minecraft:basalt
fill 306 80 270 315 80 270 minecraft:basalt
setblock 316 80 270 minecraft:shroomlight
fill 317 80 270 320 102 270 minecraft:basalt
fill 282 81 239 282 170 241 minecraft:basalt
setblock 282 81 242 minecraft:crying_obsidian
setblock 285 81 231 minecraft:light[level=12]
fill 285 81 238 285 81 239 minecraft:light[level=12]
setblock 285 81 245 minecraft:light[level=12]
setblock 285 81 247 minecraft:light[level=12]
setblock 285 81 252 minecraft:light[level=12]
setblock 285 81 255 minecraft:light[level=12]
setblock 285 81 259 minecraft:light[level=12]
setblock 285 81 263 minecraft:light[level=12]
setblock 285 81 266 minecraft:light[level=12]
fill 288 81 255 288 81 257 minecraft:basalt
setblock 289 81 257 minecraft:magma_block
fill 289 81 258 290 82 258 minecraft:basalt
setblock 290 81 256 minecraft:magma_block
fill 290 81 259 291 81 259 minecraft:basalt
setblock 291 81 255 minecraft:magma_block
fill 291 81 257 291 82 257 minecraft:basalt
fill 292 81 231 293 81 231 minecraft:light[level=12]
setblock 292 81 238 minecraft:light[level=12]
setblock 292 81 245 minecraft:light[level=12]
setblock 292 81 252 minecraft:light[level=12]
fill 292 81 255 293 82 256 minecraft:basalt
setblock 292 81 258 minecraft:basalt
setblock 292 81 259 minecraft:light[level=12]
setblock 292 81 266 minecraft:light[level=12]
setblock 293 81 239 minecraft:light[level=12]
setblock 293 81 247 minecraft:light[level=12]
setblock 293 81 263 minecraft:light[level=12]
setblock 299 81 231 minecraft:light[level=12]
setblock 299 81 238 minecraft:light[level=12]
setblock 299 81 245 minecraft:light[level=12]
setblock 299 81 252 minecraft:light[level=12]
setblock 299 81 259 minecraft:light[level=12]
setblock 299 81 266 minecraft:light[level=12]
setblock 301 81 231 minecraft:light[level=12]
setblock 301 81 239 minecraft:light[level=12]
setblock 301 81 247 minecraft:light[level=12]
setblock 301 81 255 minecraft:light[level=12]
setblock 301 81 263 minecraft:light[level=12]
setblock 306 81 231 minecraft:light[level=12]
setblock 306 81 238 minecraft:light[level=12]
setblock 306 81 245 minecraft:light[level=12]
setblock 306 81 252 minecraft:light[level=12]
setblock 306 81 259 minecraft:light[level=12]
setblock 306 81 266 minecraft:light[level=12]
fill 306 81 270 312 87 270 minecraft:basalt
setblock 309 81 231 minecraft:light[level=12]
setblock 309 81 239 minecraft:light[level=12]
setblock 309 81 247 minecraft:light[level=12]
setblock 309 81 255 minecraft:light[level=12]
setblock 309 81 263 minecraft:light[level=12]
setblock 313 81 231 minecraft:light[level=12]
setblock 313 81 238 minecraft:light[level=12]
setblock 313 81 245 minecraft:light[level=12]
setblock 313 81 252 minecraft:light[level=12]
setblock 313 81 259 minecraft:light[level=12]
setblock 313 81 266 minecraft:light[level=12]
setblock 313 81 270 minecraft:crying_obsidian
fill 314 81 270 316 124 270 minecraft:basalt
setblock 317 81 231 minecraft:light[level=12]
setblock 317 81 239 minecraft:light[level=12]
setblock 317 81 247 minecraft:light[level=12]
setblock 317 81 255 minecraft:light[level=12]
setblock 317 81 263 minecraft:light[level=12]
setblock 320 81 231 minecraft:light[level=12]
setblock 320 81 238 minecraft:light[level=12]
setblock 320 81 245 minecraft:light[level=12]
setblock 320 81 252 minecraft:light[level=12]
setblock 320 81 259 minecraft:light[level=12]
setblock 320 81 266 minecraft:light[level=12]
fill 282 82 242 282 170 242 minecraft:basalt
setblock 288 82 255 minecraft:basalt
setblock 288 82 256 minecraft:magma_block
fill 288 82 257 288 83 258 minecraft:basalt
setblock 289 82 255 minecraft:magma_block
fill 289 82 256 289 83 257 minecraft:basalt
fill 289 82 259 290 82 259 minecraft:basalt
setblock 290 82 254 minecraft:magma_block
fill 290 82 256 290 83 256 minecraft:basalt
fill 291 82 254 291 83 255 minecraft:basalt
setblock 291 82 259 minecraft:magma_block
fill 292 82 254 292 83 254 minecraft:basalt
setblock 292 82 258 minecraft:magma_block
fill 292 82 259 292 84 259 minecraft:basalt
fill 313 82 270 313 91 270 minecraft:basalt
fill 314 82 240 316 82 241 minecraft:blackstone
fill 316 82 237 317 83 238 minecraft:basalt
setblock 323 82 228 minecraft:shroomlight
fill 282 83 229 282 106 229 minecraft:basalt
setblock 282 83 230 minecraft:magma_block
fill 288 83 256 288 84 256 minecraft:basalt
setblock 289 83 255 minecraft:basalt
fill 289 83 258 289 85 258 minecraft:basalt
setblock 289 83 259 minecraft:magma_block
fill 290 83 254 290 84 254 minecraft:basalt
setblock 290 83 258 minecraft:magma_block
fill 290 83 259 291 84 259 minecraft:basalt
setblock 291 83 257 minecraft:magma_block
fill 292 83 255 292 85 255 minecraft:basalt
setblock 292 83 256 minecraft:magma_block
fill 292 83 258 292 84 258 minecraft:basalt
setblock 293 83 254 minecraft:basalt
setblock 293 83 255 minecraft:magma_block
setblock 293 83 256 minecraft:basalt
setblock 312 83 242 minecraft:magma_block
setblock 313 83 241 minecraft:magma_block
fill 313 83 242 315 84 242 minecraft:basalt
setblock 314 83 240 minecraft:blackstone
fill 314 83 241 315 84 241 minecraft:basalt
fill 314 83 243 314 86 243 minecraft:basalt
fill 315 83 239 316 83 239 minecraft:blackstone
setblock 315 83 240 minecraft:magma_block
fill 316 83 240 316 83 242 minecraft:blackstone
fill 317 83 240 318 83 241 minecraft:blackstone
setblock 320 83 228 minecraft:shroomlight
fill 323 83 228 323 173 228 minecraft:basalt
fill 282 84 230 282 141 230 minecraft:basalt
setblock 288 84 257 minecraft:basalt
setblock 288 84 258 minecraft:magma_block
setblock 289 84 256 minecraft:basalt
setblock 289 84 257 minecraft:magma_block
setblock 290 84 256 minecraft:magma_block
setblock 290 84 258 minecraft:basalt
fill 291 84 254 291 85 254 minecraft:basalt
setblock 291 84 255 minecraft:magma_block
fill 291 84 257 291 85 257 minecraft:basalt
setblock 292 84 254 minecraft:magma_block
setblock 292 84 256 minecraft:basalt
setblock 312 84 240 minecraft:magma_block
fill 312 84 241 312 85 243 minecraft:basalt
fill 313 84 240 313 85 241 minecraft:basalt
fill 313 84 243 313 84 244 minecraft:basalt
fill 315 84 240 316 84 240 minecraft:blackstone
setblock 315 84 243 minecraft:magma_block
fill 316 84 239 317 84 239 minecraft:blackstone
fill 316 84 241 316 85 241 minecraft:blackstone
setblock 316 84 242 minecraft:magma_block
fill 317 84 240 317 84 241 minecraft:magma_block
setblock 317 84 242 minecraft:blackstone
fill 318 84 240 319 84 241 minecraft:blackstone
fill 320 84 228 320 102 228 minecraft:basalt
setblock 289 85 257 minecraft:basalt
setblock 291 85 255 minecraft:basalt
setblock 292 85 258 minecraft:magma_block
setblock 301 85 228 minecraft:magma_block
fill 302 85 228 302 148 228 minecraft:basalt
fill 313 85 242 313 86 242 minecraft:basalt
setblock 313 85 243 minecraft:magma_block
setblock 313 85 244 minecraft:basalt
fill 314 85 240 314 85 241 minecraft:basalt
setblock 314 85 242 minecraft:magma_block
setblock 315 85 241 minecraft:magma_block
fill 315 85 242 315 85 243 minecraft:basalt
fill 316 85 240 317 85 240 minecraft:blackstone
setblock 317 85 241 minecraft:blackstone
fill 318 85 239 319 85 239 minecraft:blackstone
fill 318 85 240 319 85 241 minecraft:magma_block
fill 318 85 242 319 85 242 minecraft:blackstone
fill 320 85 240 321 85 241 minecraft:blackstone
setblock 300 86 228 minecraft:magma_block
fill 301 86 228 301 170 228 minecraft:basalt
setblock 313 86 241 minecraft:magma_block
setblock 314 86 240 minecraft:magma_block
fill 314 86 241 314 86 242 minecraft:basalt
fill 318 86 240 319 86 241 minecraft:blackstone
fill 320 86 239 321 86 239 minecraft:blackstone
fill 320 86 240 320 86 241 minecraft:magma_block
fill 320 86 242 321 86 242 minecraft:blackstone
fill 321 86 240 322 86 241 minecraft:blackstone
fill 282 87 245 282 171 246 minecraft:basalt
setblock 282 87 247 minecraft:magma_block
setblock 282 87 259 minecraft:crying_obsidian
fill 282 87 260 282 94 260 minecraft:basalt
fill 285 87 231 285 88 231 minecraft:light[level=12]
setblock 285 87 238 minecraft:light[level=12]
setblock 285 87 245 minecraft:light[level=12]
setblock 285 87 252 minecraft:light[level=12]
setblock 285 87 259 minecraft:light[level=12]
setblock 285 87 266 minecraft:light[level=12]
setblock 292 87 231 minecraft:light[level=12]
setblock 292 87 238 minecraft:light[level=12]
setblock 292 87 245 minecraft:light[level=12]
setblock 292 87 252 minecraft:light[level=12]
setblock 292 87 259 minecraft:light[level=12]
setblock 292 87 266 minecraft:light[level=12]
setblock 299 87 231 minecraft:light[level=12]
setblock 299 87 238 minecraft:light[level=12]
setblock 299 87 245 minecraft:light[level=12]
setblock 299 87 252 minecraft:light[level=12]
setblock 299 87 259 minecraft:light[level=12]
setblock 299 87 266 minecraft:light[level=12]
fill 300 87 228 300 173 228 minecraft:basalt
setblock 306 87 231 minecraft:light[level=12]
setblock 306 87 238 minecraft:light[level=12]
setblock 306 87 245 minecraft:light[level=12]
setblock 306 87 252 minecraft:light[level=12]
setblock 306 87 259 minecraft:light[level=12]
setblock 306 87 266 minecraft:light[level=12]
setblock 313 87 231 minecraft:light[level=12]
setblock 313 87 238 minecraft:light[level=12]
setblock 313 87 245 minecraft:light[level=12]
setblock 313 87 252 minecraft:light[level=12]
setblock 313 87 259 minecraft:light[level=12]
setblock 313 87 266 minecraft:light[level=12]
fill 319 87 240 321 87 241 minecraft:blackstone
setblock 320 87 231 minecraft:light[level=12]
setblock 320 87 238 minecraft:light[level=12]
setblock 320 87 245 minecraft:light[level=12]
setblock 320 87 252 minecraft:light[level=12]
setblock 320 87 259 minecraft:light[level=12]
setblock 320 87 266 minecraft:light[level=12]
fill 321 87 239 322 87 239 minecraft:blackstone
fill 321 87 242 322 87 242 minecraft:blackstone
fill 322 87 240 322 87 241 minecraft:magma_block
fill 323 87 240 323 88 241 minecraft:blackstone
fill 282 88 247 282 95 247 minecraft:basalt
fill 282 88 259 282 173 259 minecraft:basalt
setblock 285 88 239 minecraft:light[level=12]
setblock 285 88 247 minecraft:light[level=12]
setblock 285 88 255 minecraft:light[level=12]
setblock 285 88 263 minecraft:light[level=12]
setblock 293 88 231 minecraft:light[level=12]
setblock 293 88 239 minecraft:light[level=12]
setblock 293 88 247 minecraft:light[level=12]
setblock 293 88 255 minecraft:light[level=12]
setblock 293 88 263 minecraft:light[level=12]
fill 297 88 270 297 119 270 minecraft:basalt
setblock 298 88 270 minecraft:crying_obsidian
setblock 301 88 231 minecraft:light[level=12]
setblock 301 88 239 minecraft:light[level=12]
setblock 301 88 247 minecraft:light[level=12]
setblock 301 88 255 minecraft:light[level=12]
setblock 301 88 263 minecraft:light[level=12]
fill 306 88 270 311 105 270 minecraft:basalt
setblock 309 88 228 minecraft:crying_obsidian
setblock 309 88 231 minecraft:light[level=12]
setblock 309 88 239 minecraft:light[level=12]
setblock 309 88 247 minecraft:light[level=12]
setblock 309 88 255 minecraft:light[level=12]
setblock 309 88 263 minecraft:light[level=12]
fill 310 88 228 310 130 228 minecraft:basalt
fill 312 88 228 314 112 228 minecraft:basalt
setblock 312 88 270 minecraft:shroomlight
setblock 315 88 228 minecraft:magma_block
fill 316 88 228 319 98 228 minecraft:basalt
setblock 317 88 231 minecraft:light[level=12]
setblock 317 88 239 minecraft:light[level=12]
setblock 317 88 247 minecraft:light[level=12]
setblock 317 88 255 minecraft:light[level=12]
setblock 317 88 263 minecraft:light[level=12]
setblock 321 88 228 minecraft:magma_block
fill 321 88 240 322 88 241 minecraft:blackstone
fill 322 88 228 322 173 228 minecraft:basalt
setblock 288 89 246 minecraft:basalt
fill 298 89 270 298 165 270 minecraft:basalt
fill 309 89 228 309 169 228 minecraft:basalt
fill 312 89 270 312 96 270 minecraft:basalt
fill 315 89 228 315 130 228 minecraft:basalt
fill 321 89 228 321 170 228 minecraft:basalt
setblock 321 89 270 minecraft:magma_block
fill 322 89 270 322 169 270 minecraft:basalt
fill 324 89 231 324 105 232 minecraft:basalt
setblock 324 89 233 minecraft:magma_block
setblock 282 90 258 minecraft:magma_block
fill 287 90 245 288 90 245 minecraft:basalt
fill 288 90 244 289 90 244 minecraft:basalt
setblock 288 90 246 minecraft:magma_block
setblock 289 90 245 minecraft:magma_block
fill 289 90 246 290 91 246 minecraft:basalt
fill 290 90 245 290 93 245 minecraft:basalt
fill 321 90 270 321 170 270 minecraft:basalt
fill 324 90 233 324 111 233 minecraft:basalt
fill 282 91 258 282 170 258 minecraft:basalt
fill 283 91 229 286 91 269 minecraft:blackstone
setblock 285 91 270 minecraft:magma_block
fill 286 91 270 286 173 270 minecraft:basalt
fill 287 91 229 323 91 232 minecraft:blackstone
fill 287 91 244 287 92 244 minecraft:basalt
setblock 287 91 245 minecraft:magma_block
fill 287 91 246 288 92 246 minecraft:basalt
fill 287 91 266 323 91 269 minecraft:blackstone
setblock 288 91 244 minecraft:magma_block
fill 288 91 245 289 92 245 minecraft:basalt
fill 288 91 247 290 91 247 minecraft:basalt
fill 289 91 244 290 92 244 minecraft:basalt
fill 291 91 245 291 91 246 minecraft:basalt
fill 320 91 233 323 91 265 minecraft:blackstone
fill 282 92 231 323 92 231 minecraft:magma_block
fill 283 92 229 323 92 230 minecraft:magma_block
fill 283 92 232 285 92 269 minecraft:magma_block
fill 285 92 270 285 96 270 minecraft:basalt
fill 286 92 267 323 92 269 minecraft:magma_block
setblock 287 92 245 minecraft:basalt
fill 288 92 244 288 93 244 minecraft:basalt
fill 288 92 247 288 93 247 minecraft:basalt
fill 289 92 246 289 93 246 minecraft:basalt
setblock 289 92 247 minecraft:magma_block
setblock 290 92 246 minecraft:magma_block
setblock 291 92 245 minecraft:magma_block
setblock 313 92 270 minecraft:magma_block
fill 321 92 232 323 92 266 minecraft:magma_block
fill 282 93 231 282 174 231 minecraft:basalt
fill 283 93 229 284 93 269 minecraft:shroomlight
fill 285 93 229 323 93 230 minecraft:shroomlight
setblock 285 93 231 minecraft:light[level=12]
setblock 285 93 238 minecraft:light[level=12]
setblock 285 93 245 minecraft:light[level=12]
setblock 285 93 252 minecraft:light[level=12]
setblock 285 93 259 minecraft:light[level=12]
setblock 285 93 266 minecraft:light[level=12]
fill 285 93 268 323 93 269 minecraft:shroomlight
setblock 288 93 245 minecraft:basalt
setblock 288 93 246 minecraft:magma_block
setblock 289 93 244 minecraft:basalt
setblock 289 93 245 minecraft:magma_block
setblock 289 93 247 minecraft:basalt
setblock 290 93 244 minecraft:magma_block
setblock 292 93 231 minecraft:light[level=12]
setblock 292 93 238 minecraft:light[level=12]
setblock 292 93 245 minecraft:light[level=12]
setblock 292 93 252 minecraft:light[level=12]
setblock 292 93 259 minecraft:light[level=12]
setblock 292 93 266 minecraft:light[level=12]
setblock 299 93 231 minecraft:light[level=12]
setblock 299 93 238 minecraft:light[level=12]
setblock 299 93 245 minecraft:light[level=12]
setblock 299 93 252 minecraft:light[level=12]
setblock 299 93 259 minecraft:light[level=12]
setblock 299 93 266 minecraft:light[level=12]
setblock 306 93 231 minecraft:light[level=12]
setblock 306 93 238 minecraft:light[level=12]
setblock 306 93 245 minecraft:light[level=12]
setblock 306 93 252 minecraft:light[level=12]
setblock 306 93 259 minecraft:light[level=12]
setblock 306 93 266 minecraft:light[level=12]
setblock 313 93 231 minecraft:light[level=12]
setblock 313 93 238 minecraft:light[level=12]
setblock 313 93 245 minecraft:light[level=12]
setblock 313 93 252 minecraft:light[level=12]
setblock 313 93 259 minecraft:light[level=12]
setblock 313 93 266 minecraft:light[level=12]
fill 313 93 270 313 173 270 minecraft:basalt
setblock 320 93 231 minecraft:light[level=12]
setblock 320 93 238 minecraft:light[level=12]
setblock 320 93 245 minecraft:light[level=12]
setblock 320 93 252 minecraft:light[level=12]
setblock 320 93 259 minecraft:light[level=12]
setblock 320 93 266 minecraft:light[level=12]
fill 322 93 231 323 93 267 minecraft:shroomlight
setblock 287 94 270 minecraft:shroomlight
fill 289 94 265 293 109 266 minecraft:basalt
fill 290 94 264 292 169 264 minecraft:basalt
fill 290 94 267 292 109 267 minecraft:basalt
setblock 306 94 228 minecraft:magma_block
fill 307 94 228 307 173 228 minecraft:basalt
fill 324 94 253 324 139 254 minecraft:basalt
setblock 324 94 255 minecraft:shroomlight
setblock 282 95 260 minecraft:magma_block
setblock 285 95 231 minecraft:light[level=12]
setblock 285 95 239 minecraft:light[level=12]
setblock 285 95 247 minecraft:light[level=12]
setblock 285 95 255 minecraft:light[level=12]
setblock 285 95 263 minecraft:light[level=12]
fill 287 95 270 287 173 270 minecraft:basalt
fill 288 95 265 288 96 265 minecraft:blackstone
fill 289 95 263 289 96 264 minecraft:blackstone
fill 289 95 267 289 96 267 minecraft:blackstone
fill 290 95 263 293 96 263 minecraft:blackstone
fill 290 95 268 292 96 268 minecraft:blackstone
setblock 293 95 231 minecraft:light[level=12]
setblock 293 95 239 minecraft:light[level=12]
setblock 293 95 247 minecraft:light[level=12]
setblock 293 95 255 minecraft:light[level=12]
fill 293 95 264 293 96 264 minecraft:blackstone
fill 293 95 267 293 96 267 minecraft:blackstone
fill 294 95 265 294 96 266 minecraft:blackstone
setblock 301 95 231 minecraft:light[level=12]
setblock 301 95 239 minecraft:light[level=12]
setblock 301 95 247 minecraft:light[level=12]
setblock 301 95 255 minecraft:light[level=12]
setblock 301 95 263 minecraft:light[level=12]
fill 306 95 228 306 169 228 minecraft:basalt
setblock 309 95 231 minecraft:light[level=12]
setblock 309 95 239 minecraft:light[level=12]
setblock 309 95 247 minecraft:light[level=12]
setblock 309 95 255 minecraft:light[level=12]
setblock 309 95 263 minecraft:light[level=12]
setblock 317 95 231 minecraft:light[level=12]
setblock 317 95 239 minecraft:light[level=12]
setblock 317 95 247 minecraft:light[level=12]
setblock 317 95 255 minecraft:light[level=12]
setblock 317 95 263 minecraft:light[level=12]
fill 324 95 255 324 173 255 minecraft:basalt
setblock 282 96 247 minecraft:magma_block
fill 282 96 260 282 173 260 minecraft:basalt
fill 288 96 263 288 96 264 minecraft:blackstone
fill 288 96 266 288 96 267 minecraft:blackstone
fill 289 96 262 293 96 262 minecraft:blackstone
setblock 289 96 268 minecraft:blackstone
fill 290 96 269 292 96 269 minecraft:blackstone
fill 293 96 268 294 96 268 minecraft:blackstone
fill 294 96 263 294 96 264 minecraft:blackstone
setblock 294 96 267 minecraft:blackstone
fill 295 96 265 295 96 266 minecraft:blackstone
fill 282 97 247 282 109 247 minecraft:basalt
setblock 285 97 270 minecraft:magma_block
setblock 312 97 270 minecraft:crying_obsidian
fill 285 98 270 285 111 270 minecraft:basalt
fill 303 98 270 304 149 270 minecraft:basalt
setblock 305 98 270 minecraft:magma_block
fill 312 98 270 312 173 270 minecraft:basalt
setblock 282 99 254 minecraft:shroomlight
setblock 285 99 231 minecraft:light[level=12]
setblock 285 99 238 minecraft:light[level=12]
setblock 285 99 245 minecraft:light[level=12]
setblock 285 99 252 minecraft:light[level=12]
setblock 285 99 259 minecraft:light[level=12]
setblock 285 99 266 minecraft:light[level=12]
setblock 292 99 231 minecraft:light[level=12]
setblock 292 99 238 minecraft:light[level=12]
setblock 292 99 245 minecraft:light[level=12]
setblock 292 99 252 minecraft:light[level=12]
setblock 292 99 259 minecraft:light[level=12]
fill 293 99 233 293 109 233 minecraft:basalt
setblock 299 99 231 minecraft:light[level=12]
setblock 299 99 238 minecraft:light[level=12]
setblock 299 99 245 minecraft:light[level=12]
setblock 299 99 252 minecraft:light[level=12]
setblock 299 99 259 minecraft:light[level=12]
setblock 299 99 266 minecraft:light[level=12]
fill 305 99 270 305 100 270 minecraft:basalt
setblock 306 99 231 minecraft:light[level=12]
setblock 306 99 238 minecraft:light[level=12]
setblock 306 99 245 minecraft:light[level=12]
setblock 306 99 252 minecraft:light[level=12]
setblock 306 99 259 minecraft:light[level=12]
setblock 306 99 266 minecraft:light[level=12]
setblock 313 99 231 minecraft:light[level=12]
setblock 313 99 238 minecraft:light[level=12]
setblock 313 99 245 minecraft:light[level=12]
setblock 313 99 252 minecraft:light[level=12]
setblock 313 99 259 minecraft:light[level=12]
setblock 313 99 266 minecraft:light[level=12]
setblock 316 99 228 minecraft:crying_obsidian
fill 317 99 228 319 117 228 minecraft:basalt
setblock 320 99 231 minecraft:light[level=12]
setblock 320 99 238 minecraft:light[level=12]
setblock 320 99 245 minecraft:light[level=12]
setblock 320 99 252 minecraft:light[level=12]
setblock 320 99 259 minecraft:light[level=12]
setblock 320 99 266 minecraft:light[level=12]
fill 282 100 254 282 136 254 minecraft:basalt
fill 308 100 255 308 101 257 minecraft:basalt
fill 309 100 256 309 101 257 minecraft:basalt
fill 310 100 265 310 101 265 minecraft:magma_block
fill 316 100 228 316 109 228 minecraft:basalt
setblock 324 100 243 minecraft:magma_block
fill 324 100 244 324 122 246 minecraft:basalt
fill 288 101 270 289 173 270 minecraft:basalt
setblock 290 101 270 minecraft:magma_block
fill 291 101 270 292 139 270 minecraft:basalt
fill 305 101 241 305 102 241 minecraft:basalt
setblock 305 101 270 minecraft:crying_obsidian
fill 324 101 243 324 102 243 minecraft:basalt
setblock 285 102 231 minecraft:light[level=12]
setblock 285 102 239 minecraft:light[level=12]
setblock 285 102 247 minecraft:light[level=12]
setblock 285 102 255 minecraft:light[level=12]
setblock 285 102 263 minecraft:light[level=12]
fill 290 102 270 290 173 270 minecraft:basalt
setblock 293 102 231 minecraft:light[level=12]
setblock 293 102 239 minecraft:light[level=12]
setblock 293 102 247 minecraft:light[level=12]
setblock 293 102 255 minecraft:light[level=12]
setblock 293 102 263 minecraft:light[level=12]
setblock 301 102 231 minecraft:light[level=12]
setblock 301 102 239 minecraft:light[level=12]
setblock 301 102 247 minecraft:light[level=12]
setblock 301 102 255 minecraft:light[level=12]
setblock 301 102 263 minecraft:light[level=12]
fill 305 102 270 305 141 270 minecraft:basalt
setblock 309 102 231 minecraft:light[level=12]
setblock 309 102 239 minecraft:light[level=12]
setblock 309 102 247 minecraft:light[level=12]
setblock 309 102 255 minecraft:light[level=12]
setblock 309 102 263 minecraft:light[level=12]
setblock 317 102 231 minecraft:light[level=12]
setblock 317 102 239 minecraft:light[level=12]
setblock 317 102 247 minecraft:light[level=12]
setblock 317 102 255 minecraft:light[level=12]
setblock 317 102 263 minecraft:light[level=12]
fill 317 103 270 317 170 270 minecraft:basalt
setblock 318 103 270 minecraft:magma_block
fill 319 103 270 320 128 270 minecraft:basalt
setblock 320 103 228 minecraft:magma_block
setblock 324 103 243 minecraft:shroomlight
fill 292 104 233 292 109 233 minecraft:basalt
fill 293 104 232 293 109 232 minecraft:basalt
fill 293 104 234 293 109 234 minecraft:basalt
fill 294 104 233 294 109 233 minecraft:basalt
fill 318 104 270 318 173 270 minecraft:basalt
fill 320 104 228 320 173 228 minecraft:basalt
fill 324 104 243 324 173 243 minecraft:basalt
fill 282 105 232 282 149 234 minecraft:basalt
setblock 282 105 235 minecraft:magma_block
fill 282 105 236 282 169 237 minecraft:basalt
setblock 285 105 231 minecraft:light[level=12]
setblock 285 105 238 minecraft:light[level=12]
setblock 285 105 245 minecraft:light[level=12]
setblock 285 105 252 minecraft:light[level=12]
setblock 285 105 259 minecraft:light[level=12]
setblock 285 105 266 minecraft:light[level=12]
setblock 292 105 231 minecraft:light[level=12]
setblock 292 105 238 minecraft:light[level=12]
setblock 292 105 245 minecraft:light[level=12]
setblock 292 105 252 minecraft:light[level=12]
setblock 292 105 259 minecraft:light[level=12]
setblock 299 105 231 minecraft:light[level=12]
setblock 299 105 238 minecraft:light[level=12]
setblock 299 105 245 minecraft:light[level=12]
setblock 299 105 252 minecraft:light[level=12]
setblock 299 105 259 minecraft:light[level=12]
setblock 299 105 266 minecraft:light[level=12]
setblock 306 105 231 minecraft:light[level=12]
setblock 306 105 238 minecraft:light[level=12]
setblock 306 105 245 minecraft:light[level=12]
setblock 306 105 252 minecraft:light[level=12]
setblock 306 105 259 minecraft:light[level=12]
setblock 306 105 266 minecraft:light[level=12]
setblock 313 105 231 minecraft:light[level=12]
setblock 313 105 238 minecraft:light[level=12]
setblock 313 105 245 minecraft:light[level=12]
setblock 313 105 252 minecraft:light[level=12]
setblock 313 105 259 minecraft:light[level=12]
setblock 313 105 266 minecraft:light[level=12]
setblock 320 105 231 minecraft:light[level=12]
setblock 320 105 238 minecraft:light[level=12]
setblock 320 105 245 minecraft:light[level=12]
setblock 320 105 252 minecraft:light[level=12]
setblock 320 105 259 minecraft:light[level=12]
setblock 320 105 266 minecraft:light[level=12]
fill 282 106 235 282 173 235 minecraft:basalt
setblock 282 106 238 minecraft:crying_obsidian
fill 306 106 270 306 171 270 minecraft:basalt
setblock 307 106 270 minecraft:shroomlight
setblock 308 106 270 minecraft:crying_obsidian
fill 309 106 270 311 125 270 minecraft:basalt
setblock 324 106 231 minecraft:crying_obsidian
fill 324 106 232 324 117 232 minecraft:basalt
setblock 282 107 229 minecraft:magma_block
fill 282 107 238 282 173 238 minecraft:basalt
fill 292 107 232 292 109 232 minecraft:basalt
fill 292 107 234 292 109 234 minecraft:basalt
setblock 294 107 228 minecraft:shroomlight
fill 294 107 232 294 109 232 minecraft:basalt
fill 294 107 234 294 109 234 minecraft:basalt
fill 295 107 228 297 167 228 minecraft:basalt
fill 307 107 270 308 173 270 minecraft:basalt
fill 324 107 231 324 173 231 minecraft:basalt
setblock 282 108 229 minecraft:basalt
setblock 294 108 228 minecraft:magma_block
setblock 282 109 229 minecraft:crying_obsidian
setblock 285 109 231 minecraft:light[level=12]
setblock 285 109 239 minecraft:light[level=12]
setblock 285 109 247 minecraft:light[level=12]
setblock 285 109 255 minecraft:light[level=12]
setblock 285 109 263 minecraft:light[level=12]
fill 293 109 228 293 110 228 minecraft:magma_block
setblock 293 109 231 minecraft:light[level=12]
setblock 293 109 239 minecraft:light[level=12]
setblock 293 109 247 minecraft:light[level=12]
setblock 293 109 255 minecraft:light[level=12]
setblock 293 109 263 minecraft:light[level=12]
fill 294 109 228 294 114 228 minecraft:basalt
setblock 301 109 231 minecraft:light[level=12]
setblock 301 109 239 minecraft:light[level=12]
setblock 301 109 247 minecraft:light[level=12]
setblock 301 109 255 minecraft:light[level=12]
setblock 301 109 263 minecraft:light[level=12]
setblock 309 109 231 minecraft:light[level=12]
setblock 309 109 239 minecraft:light[level=12]
setblock 309 109 247 minecraft:light[level=12]
setblock 309 109 255 minecraft:light[level=12]
setblock 309 109 263 minecraft:light[level=12]
setblock 317 109 231 minecraft:light[level=12]
setblock 317 109 239 minecraft:light[level=12]
setblock 317 109 247 minecraft:light[level=12]
setblock 317 109 255 minecraft:light[level=12]
setblock 317 109 263 minecraft:light[level=12]
fill 324 109 265 324 125 267 minecraft:basalt
setblock 324 109 268 minecraft:shroomlight
fill 324 109 269 324 109 270 minecraft:basalt
fill 282 110 229 282 160 229 minecraft:basalt
setblock 282 110 247 minecraft:shroomlight
fill 283 110 229 286 110 269 minecraft:blackstone
fill 287 110 229 323 110 232 minecraft:blackstone
fill 287 110 266 323 110 269 minecraft:blackstone
fill 289 110 265 293 169 265 minecraft:basalt
setblock 316 110 228 minecraft:magma_block
fill 320 110 233 323 110 265 minecraft:blackstone
fill 324 110 268 324 173 268 minecraft:basalt
setblock 324 110 269 minecraft:crying_obsidian
fill 324 110 270 324 170 270 minecraft:basalt
fill 282 111 247 282 169 247 minecraft:basalt
fill 283 111 229 285 111 269 minecraft:magma_block
fill 286 111 229 323 111 231 minecraft:magma_block
fill 286 111 267 323 111 269 minecraft:magma_block
fill 289 111 266 293 128 266 minecraft:basalt
setblock 292 111 238 minecraft:light[level=12]
setblock 292 111 245 minecraft:light[level=12]
setblock 292 111 252 minecraft:light[level=12]
setblock 292 111 259 minecraft:light[level=12]
setblock 293 111 228 minecraft:shroomlight
setblock 299 111 238 minecraft:light[level=12]
setblock 299 111 245 minecraft:light[level=12]
setblock 299 111 252 minecraft:light[level=12]
setblock 299 111 259 minecraft:light[level=12]
setblock 299 111 266 minecraft:light[level=12]
setblock 306 111 238 minecraft:light[level=12]
setblock 306 111 245 minecraft:light[level=12]
setblock 306 111 252 minecraft:light[level=12]
setblock 306 111 259 minecraft:light[level=12]
setblock 306 111 266 minecraft:light[level=12]
setblock 313 111 238 minecraft:light[level=12]
setblock 313 111 245 minecraft:light[level=12]
setblock 313 111 252 minecraft:light[level=12]
setblock 313 111 259 minecraft:light[level=12]
setblock 313 111 266 minecraft:light[level=12]
fill 316 111 228 316 159 228 minecraft:basalt
setblock 320 111 238 minecraft:light[level=12]
setblock 320 111 245 minecraft:light[level=12]
setblock 320 111 252 minecraft:light[level=12]
setblock 320 111 259 minecraft:light[level=12]
setblock 320 111 266 minecraft:light[level=12]
fill 321 111 232 323 111 266 minecraft:magma_block
setblock 324 111 269 minecraft:basalt
fill 283 112 229 284 112 269 minecraft:shroomlight
fill 285 112 229 323 112 230 minecraft:shroomlight
fill 285 112 268 285 112 270 minecraft:shroomlight
fill 286 112 268 323 112 269 minecraft:shroomlight
fill 290 112 267 292 128 267 minecraft:basalt
fill 293 112 228 293 114 228 minecraft:magma_block
fill 322 112 231 323 112 267 minecraft:shroomlight
setblock 324 112 233 minecraft:magma_block
setblock 324 112 269 minecraft:magma_block
fill 285 113 270 285 151 270 minecraft:basalt
setblock 312 113 228 minecraft:shroomlight
fill 313 113 228 314 169 228 minecraft:basalt
fill 324 113 233 324 160 233 minecraft:basalt
fill 324 113 237 324 115 237 minecraft:basalt
setblock 324 113 238 minecraft:crying_obsidian
fill 324 113 269 324 174 269 minecraft:basalt
fill 312 114 228 312 173 228 minecraft:basalt
fill 324 114 238 324 172 238 minecraft:basalt
setblock 293 115 228 minecraft:basalt
setblock 294 115 228 minecraft:shroomlight
fill 294 115 270 294 145 270 minecraft:basalt
setblock 295 115 270 minecraft:crying_obsidian
fill 296 115 254 297 116 255 minecraft:magma_block
fill 296 115 270 296 171 270 minecraft:basalt
fill 324 115 257 324 169 259 minecraft:basalt
setblock 324 115 260 minecraft:shroomlight
setblock 282 116 250 minecraft:magma_block
fill 282 116 251 282 153 253 minecraft:basalt
fill 285 116 231 285 117 231 minecraft:light[level=12]
setblock 285 116 239 minecraft:light[level=12]
setblock 285 116 247 minecraft:light[level=12]
setblock 285 116 255 minecraft:light[level=12]
setblock 285 116 263 minecraft:light[level=12]
fill 293 116 228 293 117 228 minecraft:magma_block
setblock 293 116 231 minecraft:light[level=12]
setblock 293 116 239 minecraft:light[level=12]
setblock 293 116 247 minecraft:light[level=12]
setblock 293 116 255 minecraft:light[level=12]
setblock 293 116 263 minecraft:light[level=12]
fill 294 116 228 294 127 228 minecraft:basalt
fill 295 116 270 295 120 270 minecraft:basalt
setblock 301 116 231 minecraft:light[level=12]
setblock 301 116 239 minecraft:light[level=12]
setblock 301 116 247 minecraft:light[level=12]
setblock 301 116 255 minecraft:light[level=12]
setblock 301 116 263 minecraft:light[level=12]
setblock 309 116 231 minecraft:light[level=12]
setblock 309 116 239 minecraft:light[level=12]
setblock 309 116 247 minecraft:light[level=12]
setblock 309 116 255 minecraft:light[level=12]
setblock 309 116 263 minecraft:light[level=12]
setblock 317 116 231 minecraft:light[level=12]
setblock 317 116 239 minecraft:light[level=12]
setblock 317 116 247 minecraft:light[level=12]
setblock 317 116 255 minecraft:light[level=12]
setblock 317 116 263 minecraft:light[level=12]
setblock 324 116 237 minecraft:magma_block
fill 324 116 260 324 169 260 minecraft:basalt
fill 282 117 250 282 119 250 minecraft:basalt
setblock 285 117 238 minecraft:light[level=12]
setblock 285 117 245 minecraft:light[level=12]
setblock 285 117 252 minecraft:light[level=12]
setblock 285 117 259 minecraft:light[level=12]
setblock 285 117 266 minecraft:light[level=12]
setblock 292 117 231 minecraft:light[level=12]
setblock 292 117 238 minecraft:light[level=12]
setblock 292 117 245 minecraft:light[level=12]
setblock 292 117 252 minecraft:light[level=12]
setblock 292 117 259 minecraft:light[level=12]
setblock 299 117 231 minecraft:light[level=12]
setblock 299 117 238 minecraft:light[level=12]
setblock 299 117 245 minecraft:light[level=12]
setblock 299 117 252 minecraft:light[level=12]
setblock 299 117 259 minecraft:light[level=12]
setblock 299 117 266 minecraft:light[level=12]
setblock 306 117 231 minecraft:light[level=12]
setblock 306 117 238 minecraft:light[level=12]
setblock 306 117 245 minecraft:light[level=12]
setblock 306 117 252 minecraft:light[level=12]
setblock 306 117 259 minecraft:light[level=12]
setblock 306 117 266 minecraft:light[level=12]
setblock 313 117 231 minecraft:light[level=12]
setblock 313 117 238 minecraft:light[level=12]
setblock 313 117 245 minecraft:light[level=12]
setblock 313 117 252 minecraft:light[level=12]
setblock 313 117 259 minecraft:light[level=12]
setblock 313 117 266 minecraft:light[level=12]
setblock 320 117 231 minecraft:light[level=12]
setblock 320 117 238 minecraft:light[level=12]
setblock 320 117 245 minecraft:light[level=12]
setblock 320 117 252 minecraft:light[level=12]
setblock 320 117 259 minecraft:light[level=12]
setblock 320 117 266 minecraft:light[level=12]
fill 324 117 237 324 173 237 minecraft:basalt
setblock 292 118 228 minecraft:magma_block
fill 293 118 228 293 173 228 minecraft:basalt
fill 299 118 270 300 145 270 minecraft:basalt
setblock 301 118 270 minecraft:shroomlight
setblock 317 118 228 minecraft:crying_obsidian
fill 318 118 228 319 138 228 minecraft:basalt
setblock 324 118 232 minecraft:shroomlight
setblock 324 118 256 minecraft:shroomlight
setblock 292 119 228 minecraft:shroomlight
fill 301 119 270 301 143 270 minecraft:basalt
fill 317 119 228 317 173 228 minecraft:basalt
fill 324 119 232 324 173 232 minecraft:basalt
fill 324 119 256 324 173 256 minecraft:basalt
setblock 282 120 250 minecraft:magma_block
setblock 290 120 228 minecraft:magma_block
fill 292 120 228 292 171 228 minecraft:basalt
setblock 297 120 270 minecraft:magma_block
fill 282 121 250 282 173 250 minecraft:basalt
fill 287 121 228 287 173 228 minecraft:basalt
setblock 288 121 228 minecraft:crying_obsidian
fill 290 121 228 290 128 228 minecraft:basalt
setblock 295 121 270 minecraft:shroomlight
fill 297 121 270 297 166 270 minecraft:basalt
fill 288 122 228 288 173 228 minecraft:basalt
fill 295 122 270 295 173 270 minecraft:basalt
setblock 282 123 268 minecraft:magma_block
setblock 285 123 231 minecraft:light[level=12]
fill 285 123 238 285 123 239 minecraft:light[level=12]
setblock 285 123 245 minecraft:light[level=12]
setblock 285 123 247 minecraft:light[level=12]
setblock 285 123 252 minecraft:light[level=12]
setblock 285 123 255 minecraft:light[level=12]
setblock 285 123 259 minecraft:light[level=12]
setblock 285 123 263 minecraft:light[level=12]
setblock 285 123 266 minecraft:light[level=12]
fill 292 123 231 293 123 231 minecraft:light[level=12]
setblock 292 123 238 minecraft:light[level=12]
fill 292 123 245 293 124 246 minecraft:basalt
setblock 292 123 252 minecraft:light[level=12]
setblock 292 123 259 minecraft:light[level=12]
setblock 293 123 239 minecraft:light[level=12]
setblock 293 123 247 minecraft:light[level=12]
setblock 293 123 255 minecraft:light[level=12]
setblock 293 123 263 minecraft:light[level=12]
setblock 299 123 231 minecraft:light[level=12]
setblock 299 123 238 minecraft:light[level=12]
setblock 299 123 245 minecraft:light[level=12]
setblock 299 123 252 minecraft:light[level=12]
setblock 299 123 259 minecraft:light[level=12]
setblock 299 123 266 minecraft:light[level=12]
setblock 301 123 231 minecraft:light[level=12]
setblock 301 123 239 minecraft:light[level=12]
setblock 301 123 247 minecraft:light[level=12]
setblock 301 123 255 minecraft:light[level=12]
setblock 301 123 263 minecraft:light[level=12]
setblock 306 123 231 minecraft:light[level=12]
setblock 306 123 238 minecraft:light[level=12]
setblock 306 123 245 minecraft:light[level=12]
setblock 306 123 252 minecraft:light[level=12]
setblock 306 123 259 minecraft:light[level=12]
setblock 306 123 266 minecraft:light[level=12]
setblock 309 123 231 minecraft:light[level=12]
setblock 309 123 239 minecraft:light[level=12]
setblock 309 123 247 minecraft:light[level=12]
setblock 309 123 255 minecraft:light[level=12]
setblock 309 123 263 minecraft:light[level=12]
setblock 313 123 231 minecraft:light[level=12]
setblock 313 123 238 minecraft:light[level=12]
setblock 313 123 245 minecraft:light[level=12]
setblock 313 123 252 minecraft:light[level=12]
setblock 313 123 259 minecraft:light[level=12]
setblock 313 123 266 minecraft:light[level=12]
setblock 317 123 231 minecraft:light[level=12]
setblock 317 123 239 minecraft:light[level=12]
setblock 317 123 247 minecraft:light[level=12]
setblock 317 123 255 minecraft:light[level=12]
setblock 317 123 263 minecraft:light[level=12]
setblock 320 123 231 minecraft:light[level=12]
setblock 320 123 238 minecraft:light[level=12]
setblock 320 123 245 minecraft:light[level=12]
setblock 320 123 252 minecraft:light[level=12]
setblock 320 123 259 minecraft:light[level=12]
setblock 320 123 266 minecraft:light[level=12]
fill 324 123 244 324 134 245 minecraft:basalt
setblock 324 123 246 minecraft:magma_block
fill 282 124 268 282 145 268 minecraft:basalt
fill 324 124 246 324 173 246 minecraft:basalt
fill 314 125 270 315 133 270 minecraft:basalt
setblock 316 125 270 minecraft:crying_obsidian
fill 324 125 261 324 170 261 minecraft:basalt
setblock 324 125 262 minecraft:magma_block
fill 324 125 263 324 130 264 minecraft:basalt
fill 309 126 270 310 150 270 minecraft:basalt
setblock 311 126 270 minecraft:magma_block
fill 316 126 270 316 173 270 minecraft:basalt
fill 324 126 262 324 160 262 minecraft:basalt
setblock 324 126 265 minecraft:crying_obsidian
fill 324 126 266 324 173 267 minecraft:basalt
fill 311 127 270 311 173 270 minecraft:basalt
fill 324 127 265 324 173 265 minecraft:basalt
setblock 289 128 228 minecraft:magma_block
setblock 294 128 228 minecraft:magma_block
fill 283 129 229 286 129 269 minecraft:blackstone
fill 287 129 229 323 129 232 minecraft:blackstone
fill 287 129 266 323 129 269 minecraft:blackstone
fill 289 129 228 289 174 228 minecraft:basalt
setblock 290 129 228 minecraft:magma_block
setblock 292 129 238 minecraft:light[level=12]
setblock 292 129 245 minecraft:light[level=12]
setblock 292 129 252 minecraft:light[level=12]
setblock 292 129 259 minecraft:light[level=12]
fill 294 129 228 294 173 228 minecraft:basalt
setblock 299 129 238 minecraft:light[level=12]
setblock 299 129 245 minecraft:light[level=12]
setblock 299 129 252 minecraft:light[level=12]
setblock 299 129 259 minecraft:light[level=12]
setblock 306 129 238 minecraft:light[level=12]
setblock 306 129 245 minecraft:light[level=12]
setblock 306 129 252 minecraft:light[level=12]
setblock 306 129 259 minecraft:light[level=12]
setblock 313 129 238 minecraft:light[level=12]
setblock 313 129 245 minecraft:light[level=12]
setblock 313 129 252 minecraft:light[level=12]
setblock 313 129 259 minecraft:light[level=12]
fill 319 129 270 319 173 270 minecraft:basalt
fill 320 129 233 323 129 265 minecraft:blackstone
setblock 320 129 270 minecraft:magma_block
fill 283 130 229 285 130 269 minecraft:magma_block
fill 286 130 229 323 130 231 minecraft:magma_block
fill 286 130 267 323 130 269 minecraft:magma_block
fill 289 130 266 293 147 266 minecraft:basalt
fill 290 130 228 290 173 228 minecraft:basalt
setblock 293 130 239 minecraft:light[level=12]
setblock 293 130 247 minecraft:light[level=12]
setblock 293 130 255 minecraft:light[level=12]
setblock 293 130 263 minecraft:light[level=12]
setblock 301 130 239 minecraft:light[level=12]
setblock 301 130 247 minecraft:light[level=12]
setblock 301 130 255 minecraft:light[level=12]
setblock 301 130 263 minecraft:light[level=12]
setblock 309 130 239 minecraft:light[level=12]
setblock 309 130 247 minecraft:light[level=12]
setblock 309 130 255 minecraft:light[level=12]
setblock 309 130 263 minecraft:light[level=12]
setblock 317 130 239 minecraft:light[level=12]
setblock 317 130 247 minecraft:light[level=12]
setblock 317 130 255 minecraft:light[level=12]
setblock 317 130 263 minecraft:light[level=12]
fill 320 130 270 320 144 270 minecraft:basalt
fill 321 130 232 323 130 266 minecraft:magma_block
fill 283 131 229 284 131 269 minecraft:shroomlight
fill 285 131 229 323 131 230 minecraft:shroomlight
fill 285 131 268 323 131 269 minecraft:shroomlight
fill 290 131 267 292 147 267 minecraft:basalt
setblock 310 131 228 minecraft:shroomlight
setblock 315 131 228 minecraft:magma_block
fill 322 131 231 323 131 267 minecraft:shroomlight
setblock 324 131 263 minecraft:magma_block
fill 324 131 264 324 171 264 minecraft:basalt
fill 310 132 228 310 171 228 minecraft:basalt
fill 315 132 228 315 140 228 minecraft:basalt
setblock 324 132 230 minecraft:magma_block
fill 324 132 263 324 173 263 minecraft:basalt
fill 321 133 262 321 137 262 minecraft:blackstone
fill 324 133 230 324 170 230 minecraft:basalt
setblock 314 134 270 minecraft:magma_block
fill 315 134 270 315 173 270 minecraft:basalt
setblock 285 135 231 minecraft:light[level=12]
setblock 285 135 238 minecraft:light[level=12]
setblock 285 135 245 minecraft:light[level=12]
setblock 285 135 252 minecraft:light[level=12]
setblock 285 135 259 minecraft:light[level=12]
setblock 285 135 266 minecraft:light[level=12]
setblock 292 135 231 minecraft:light[level=12]
setblock 292 135 238 minecraft:light[level=12]
setblock 292 135 245 minecraft:light[level=12]
setblock 292 135 252 minecraft:light[level=12]
setblock 292 135 259 minecraft:light[level=12]
setblock 299 135 231 minecraft:light[level=12]
setblock 299 135 238 minecraft:light[level=12]
setblock 299 135 245 minecraft:light[level=12]
setblock 299 135 252 minecraft:light[level=12]
setblock 299 135 259 minecraft:light[level=12]
setblock 299 135 266 minecraft:light[level=12]
setblock 306 135 231 minecraft:light[level=12]
setblock 306 135 238 minecraft:light[level=12]
setblock 306 135 245 minecraft:light[level=12]
setblock 306 135 252 minecraft:light[level=12]
setblock 306 135 259 minecraft:light[level=12]
setblock 306 135 266 minecraft:light[level=12]
setblock 313 135 231 minecraft:light[level=12]
setblock 313 135 238 minecraft:light[level=12]
setblock 313 135 245 minecraft:light[level=12]
setblock 313 135 252 minecraft:light[level=12]
setblock 313 135 259 minecraft:light[level=12]
setblock 313 135 266 minecraft:light[level=12]
fill 314 135 270 314 173 270 minecraft:basalt
setblock 320 135 231 minecraft:light[level=12]
setblock 320 135 238 minecraft:light[level=12]
setblock 320 135 245 minecraft:light[level=12]
setblock 320 135 252 minecraft:light[level=12]
setblock 320 135 259 minecraft:light[level=12]
fill 320 135 262 320 137 262 minecraft:blackstone
setblock 320 135 266 minecraft:light[level=12]
fill 321 135 261 321 137 261 minecraft:blackstone
fill 321 135 263 321 137 263 minecraft:blackstone
fill 322 135 262 322 137 262 minecraft:blackstone
fill 324 135 244 324 164 244 minecraft:basalt
setblock 324 135 245 minecraft:shroomlight
setblock 283 136 270 minecraft:magma_block
fill 284 136 270 284 173 270 minecraft:basalt
fill 324 136 245 324 173 245 minecraft:basalt
setblock 282 137 254 minecraft:magma_block
setblock 282 137 267 minecraft:magma_block
fill 283 137 270 283 164 270 minecraft:basalt
setblock 285 137 231 minecraft:light[level=12]
setblock 285 137 239 minecraft:light[level=12]
setblock 285 137 247 minecraft:light[level=12]
setblock 285 137 255 minecraft:light[level=12]
setblock 285 137 263 minecraft:light[level=12]
setblock 293 137 231 minecraft:light[level=12]
setblock 293 137 239 minecraft:light[level=12]
setblock 293 137 247 minecraft:light[level=12]
setblock 293 137 255 minecraft:light[level=12]
setblock 293 137 263 minecraft:light[level=12]
setblock 301 137 231 minecraft:light[level=12]
setblock 301 137 239 minecraft:light[level=12]
setblock 301 137 247 minecraft:light[level=12]
setblock 301 137 255 minecraft:light[level=12]
setblock 301 137 263 minecraft:light[level=12]
setblock 309 137 231 minecraft:light[level=12]
setblock 309 137 239 minecraft:light[level=12]
setblock 309 137 247 minecraft:light[level=12]
setblock 309 137 255 minecraft:light[level=12]
setblock 309 137 263 minecraft:light[level=12]
fill 315 137 256 315 141 256 minecraft:basalt
setblock 315 137 257 minecraft:magma_block
fill 316 137 255 316 142 255 minecraft:basalt
setblock 316 137 256 minecraft:magma_block
setblock 317 137 231 minecraft:light[level=12]
setblock 317 137 239 minecraft:light[level=12]
setblock 317 137 247 minecraft:light[level=12]
setblock 317 137 255 minecraft:light[level=12]
fill 317 137 256 317 142 256 minecraft:basalt
setblock 317 137 263 minecraft:light[level=12]
setblock 320 137 261 minecraft:blackstone
setblock 320 137 263 minecraft:blackstone
setblock 322 137 261 minecraft:blackstone
setblock 322 137 263 minecraft:blackstone
fill 282 138 254 282 170 254 minecraft:basalt
fill 282 138 267 282 173 267 minecraft:basalt
setblock 314 138 256 minecraft:magma_block
fill 314 138 257 318 138 257 minecraft:basalt
fill 315 138 254 315 141 254 minecraft:basalt
setblock 315 138 255 minecraft:magma_block
fill 315 138 258 317 138 258 minecraft:basalt
fill 316 138 239 316 139 240 minecraft:blackstone
setblock 316 138 254 minecraft:magma_block
fill 316 138 256 316 139 256 minecraft:basalt
fill 317 138 254 317 139 255 minecraft:basalt
fill 318 138 255 318 138 256 minecraft:basalt
fill 314 139 255 314 139 257 minecraft:basalt
fill 315 139 255 315 140 255 minecraft:basalt
fill 315 139 257 315 139 258 minecraft:basalt
fill 316 139 254 316 140 254 minecraft:basalt
fill 316 139 257 316 142 257 minecraft:basalt
setblock 316 139 258 minecraft:magma_block
fill 316 139 259 316 141 259 minecraft:basalt
setblock 317 139 257 minecraft:magma_block
fill 317 139 258 317 141 258 minecraft:basalt
setblock 318 139 228 minecraft:magma_block
fill 318 139 254 318 139 255 minecraft:basalt
setblock 318 139 256 minecraft:magma_block
fill 318 139 257 318 140 257 minecraft:basalt
fill 319 139 228 319 146 228 minecraft:basalt
setblock 291 140 270 minecraft:magma_block
fill 292 140 270 292 173 270 minecraft:basalt
fill 314 140 254 314 140 256 minecraft:basalt
setblock 315 140 257 minecraft:magma_block
fill 315 140 258 316 141 258 minecraft:basalt
setblock 316 140 256 minecraft:magma_block
fill 317 140 254 317 141 254 minecraft:basalt
setblock 317 140 255 minecraft:magma_block
fill 317 140 257 317 141 257 minecraft:basalt
setblock 317 140 259 minecraft:basalt
fill 318 140 228 318 141 228 minecraft:basalt
setblock 318 140 254 minecraft:magma_block
fill 318 140 255 318 141 256 minecraft:basalt
setblock 324 140 253 minecraft:shroomlight
fill 324 140 254 324 154 254 minecraft:basalt
setblock 285 141 231 minecraft:light[level=12]
setblock 285 141 238 minecraft:light[level=12]
setblock 285 141 245 minecraft:light[level=12]
setblock 285 141 252 minecraft:light[level=12]
setblock 285 141 259 minecraft:light[level=12]
setblock 285 141 266 minecraft:light[level=12]
fill 291 141 270 291 173 270 minecraft:basalt
setblock 292 141 231 minecraft:light[level=12]
setblock 292 141 238 minecraft:light[level=12]
setblock 292 141 245 minecraft:light[level=12]
setblock 292 141 252 minecraft:light[level=12]
setblock 292 141 259 minecraft:light[level=12]
setblock 299 141 231 minecraft:light[level=12]
setblock 299 141 238 minecraft:light[level=12]
setblock 299 141 245 minecraft:light[level=12]
setblock 299 141 252 minecraft:light[level=12]
setblock 299 141 259 minecraft:light[level=12]
setblock 299 141 266 minecraft:light[level=12]
setblock 306 141 231 minecraft:light[level=12]
setblock 306 141 238 minecraft:light[level=12]
setblock 306 141 245 minecraft:light[level=12]
setblock 306 141 252 minecraft:light[level=12]
setblock 306 141 259 minecraft:light[level=12]
setblock 306 141 266 minecraft:light[level=12]
setblock 313 141 231 minecraft:light[level=12]
setblock 313 141 238 minecraft:light[level=12]
setblock 313 141 245 minecraft:light[level=12]
setblock 313 141 252 minecraft:light[level=12]
setblock 313 141 259 minecraft:light[level=12]
setblock 313 141 266 minecraft:light[level=12]
setblock 314 141 255 minecraft:basalt
setblock 314 141 256 minecraft:magma_block
setblock 315 141 228 minecraft:magma_block
setblock 315 141 255 minecraft:magma_block
setblock 315 141 257 minecraft:basalt
setblock 316 141 254 minecraft:magma_block
fill 316 141 256 316 142 256 minecraft:basalt
setblock 317 141 255 minecraft:basalt
setblock 320 141 231 minecraft:light[level=12]
setblock 320 141 238 minecraft:light[level=12]
setblock 320 141 245 minecraft:light[level=12]
setblock 320 141 252 minecraft:light[level=12]
setblock 320 141 259 minecraft:light[level=12]
setblock 320 141 266 minecraft:light[level=12]
fill 324 141 253 324 173 253 minecraft:basalt
setblock 282 142 230 minecraft:magma_block
setblock 282 142 255 minecraft:shroomlight
setblock 282 142 261 minecraft:magma_block
fill 282 142 262 282 174 262 minecraft:basalt
setblock 282 142 263 minecraft:magma_block
fill 303 142 228 303 145 228 minecraft:basalt
setblock 304 142 228 minecraft:magma_block
setblock 305 142 270 minecraft:magma_block
fill 315 142 228 315 170 228 minecraft:basalt
setblock 317 142 257 minecraft:magma_block
setblock 318 142 228 minecraft:crying_obsidian
setblock 324 142 236 minecraft:magma_block
fill 282 143 230 282 170 230 minecraft:basalt
fill 282 143 255 282 173 255 minecraft:basalt
fill 282 143 261 282 173 261 minecraft:basalt
fill 282 143 263 282 156 263 minecraft:basalt
setblock 304 143 228 minecraft:shroomlight
fill 305 143 270 305 173 270 minecraft:basalt
fill 318 143 228 318 169 228 minecraft:basalt
fill 324 143 236 324 166 236 minecraft:basalt
setblock 285 144 231 minecraft:light[level=12]
setblock 285 144 239 minecraft:light[level=12]
setblock 285 144 247 minecraft:light[level=12]
setblock 285 144 255 minecraft:light[level=12]
setblock 285 144 263 minecraft:light[level=12]
setblock 293 144 231 minecraft:light[level=12]
setblock 293 144 239 minecraft:light[level=12]
setblock 293 144 247 minecraft:light[level=12]
setblock 293 144 255 minecraft:light[level=12]
setblock 293 144 263 minecraft:light[level=12]
setblock 301 144 231 minecraft:light[level=12]
setblock 301 144 239 minecraft:light[level=12]
setblock 301 144 247 minecraft:light[level=12]
setblock 301 144 255 minecraft:light[level=12]
setblock 301 144 263 minecraft:light[level=12]
setblock 301 144 270 minecraft:magma_block
fill 304 144 228 304 145 228 minecraft:magma_block
setblock 309 144 231 minecraft:light[level=12]
setblock 309 144 239 minecraft:light[level=12]
setblock 309 144 247 minecraft:light[level=12]
setblock 309 144 255 minecraft:light[level=12]
setblock 309 144 263 minecraft:light[level=12]
setblock 317 144 231 minecraft:light[level=12]
setblock 317 144 239 minecraft:light[level=12]
setblock 317 144 247 minecraft:light[level=12]
setblock 317 144 255 minecraft:light[level=12]
setblock 317 144 263 minecraft:light[level=12]
fill 301 145 270 301 169 270 minecraft:basalt
setblock 320 145 270 minecraft:magma_block
setblock 282 146 268 minecraft:crying_obsidian
setblock 294 146 270 minecraft:magma_block
setblock 299 146 270 minecraft:magma_block
fill 300 146 270 300 169 270 minecraft:basalt
setblock 302 146 270 minecraft:shroomlight
setblock 303 146 228 minecraft:magma_block
fill 304 146 228 304 152 228 minecraft:basalt
fill 320 146 270 320 173 270 minecraft:basalt
fill 282 147 268 282 173 268 minecraft:basalt
setblock 285 147 231 minecraft:light[level=12]
setblock 285 147 238 minecraft:light[level=12]
setblock 285 147 245 minecraft:light[level=12]
setblock 285 147 252 minecraft:light[level=12]
setblock 285 147 259 minecraft:light[level=12]
setblock 285 147 266 minecraft:light[level=12]
setblock 291 147 228 minecraft:magma_block
setblock 292 147 231 minecraft:light[level=12]
setblock 292 147 238 minecraft:light[level=12]
setblock 292 147 245 minecraft:light[level=12]
setblock 292 147 252 minecraft:light[level=12]
setblock 292 147 259 minecraft:light[level=12]
fill 294 147 270 294 173 270 minecraft:basalt
setblock 299 147 231 minecraft:light[level=12]
setblock 299 147 238 minecraft:light[level=12]
setblock 299 147 245 minecraft:light[level=12]
setblock 299 147 252 minecraft:light[level=12]
setblock 299 147 259 minecraft:light[level=12]
setblock 299 147 266 minecraft:light[level=12]
fill 299 147 270 299 173 270 minecraft:basalt
fill 300 147 235 302 148 235 minecraft:magma_block
fill 301 147 234 302 148 234 minecraft:magma_block
fill 301 147 236 301 148 236 minecraft:magma_block
fill 302 147 270 302 173 270 minecraft:basalt
setblock 303 147 228 minecraft:shroomlight
setblock 305 147 228 minecraft:crying_obsidian
setblock 306 147 231 minecraft:light[level=12]
setblock 306 147 238 minecraft:light[level=12]
setblock 306 147 245 minecraft:light[level=12]
setblock 306 147 252 minecraft:light[level=12]
setblock 306 147 259 minecraft:light[level=12]
setblock 306 147 266 minecraft:light[level=12]
setblock 313 147 231 minecraft:light[level=12]
setblock 313 147 238 minecraft:light[level=12]
setblock 313 147 245 minecraft:light[level=12]
setblock 313 147 252 minecraft:light[level=12]
setblock 313 147 259 minecraft:light[level=12]
setblock 313 147 266 minecraft:light[level=12]
setblock 319 147 228 minecraft:magma_block
setblock 320 147 231 minecraft:light[level=12]
setblock 320 147 238 minecraft:light[level=12]
setblock 320 147 245 minecraft:light[level=12]
setblock 320 147 252 minecraft:light[level=12]
setblock 320 147 259 minecraft:light[level=12]
setblock 320 147 266 minecraft:light[level=12]
fill 283 148 229 286 148 269 minecraft:blackstone
fill 287 148 229 323 148 232 minecraft:blackstone
fill 287 148 266 323 148 269 minecraft:blackstone
fill 291 148 228 291 171 228 minecraft:basalt
setblock 303 148 228 minecraft:magma_block
fill 305 148 228 305 157 228 minecraft:basalt
fill 319 148 228 319 173 228 minecraft:basalt
fill 320 148 233 323 148 265 minecraft:blackstone
fill 283 149 229 285 149 269 minecraft:magma_block
fill 286 149 229 323 149 231 minecraft:magma_block
fill 286 149 267 323 149 269 minecraft:magma_block
fill 289 149 266 293 166 266 minecraft:basalt
fill 302 149 228 302 150 228 minecraft:magma_block
fill 303 149 228 303 150 228 minecraft:basalt
fill 321 149 232 323 149 266 minecraft:magma_block
fill 282 150 232 284 150 232 minecraft:shroomlight
fill 282 150 233 282 173 234 minecraft:basalt
fill 283 150 229 284 150 231 minecraft:shroomlight
fill 283 150 233 284 150 269 minecraft:shroomlight
fill 285 150 229 323 150 230 minecraft:shroomlight
fill 285 150 268 323 150 269 minecraft:shroomlight
fill 290 150 267 292 166 267 minecraft:basalt
fill 303 150 270 303 173 270 minecraft:basalt
setblock 304 150 270 minecraft:crying_obsidian
fill 322 150 231 323 150 267 minecraft:shroomlight
setblock 324 150 235 minecraft:shroomlight
fill 282 151 232 282 171 232 minecraft:basalt
setblock 285 151 231 minecraft:light[level=12]
setblock 285 151 239 minecraft:light[level=12]
setblock 285 151 247 minecraft:light[level=12]
setblock 285 151 255 minecraft:light[level=12]
setblock 285 151 263 minecraft:light[level=12]
setblock 293 151 231 minecraft:light[level=12]
setblock 293 151 239 minecraft:light[level=12]
setblock 293 151 247 minecraft:light[level=12]
setblock 293 151 255 minecraft:light[level=12]
setblock 293 151 263 minecraft:light[level=12]
setblock 301 151 231 minecraft:light[level=12]
setblock 301 151 239 minecraft:light[level=12]
setblock 301 151 247 minecraft:light[level=12]
setblock 301 151 255 minecraft:light[level=12]
setblock 301 151 263 minecraft:light[level=12]
fill 302 151 228 302 173 228 minecraft:basalt
setblock 303 151 228 minecraft:shroomlight
fill 304 151 270 304 173 270 minecraft:basalt
setblock 309 151 231 minecraft:light[level=12]
setblock 309 151 239 minecraft:light[level=12]
setblock 309 151 247 minecraft:light[level=12]
setblock 309 151 255 minecraft:light[level=12]
setblock 309 151 263 minecraft:light[level=12]
setblock 309 151 270 minecraft:magma_block
fill 310 151 270 310 173 270 minecraft:basalt
setblock 317 151 231 minecraft:light[level=12]
setblock 317 151 239 minecraft:light[level=12]
setblock 317 151 247 minecraft:light[level=12]
setblock 317 151 255 minecraft:light[level=12]
setblock 317 151 263 minecraft:light[level=12]
fill 324 151 235 324 153 235 minecraft:basalt
setblock 285 152 270 minecraft:magma_block
setblock 303 152 228 minecraft:magma_block
fill 309 152 270 309 176 270 minecraft:basalt
setblock 285 153 231 minecraft:light[level=12]
setblock 285 153 238 minecraft:light[level=12]
setblock 285 153 245 minecraft:light[level=12]
setblock 285 153 252 minecraft:light[level=12]
setblock 285 153 259 minecraft:light[level=12]
setblock 285 153 266 minecraft:light[level=12]
fill 285 153 270 285 173 270 minecraft:basalt
setblock 292 153 231 minecraft:light[level=12]
setblock 292 153 238 minecraft:light[level=12]
setblock 292 153 245 minecraft:light[level=12]
setblock 292 153 252 minecraft:light[level=12]
setblock 292 153 259 minecraft:light[level=12]
setblock 299 153 231 minecraft:light[level=12]
setblock 299 153 238 minecraft:light[level=12]
setblock 299 153 245 minecraft:light[level=12]
setblock 299 153 252 minecraft:light[level=12]
setblock 299 153 259 minecraft:light[level=12]
setblock 299 153 266 minecraft:light[level=12]
fill 303 153 228 303 174 228 minecraft:basalt
fill 304 153 228 304 154 228 minecraft:magma_block
setblock 306 153 231 minecraft:light[level=12]
setblock 306 153 238 minecraft:light[level=12]
setblock 306 153 245 minecraft:light[level=12]
setblock 306 153 252 minecraft:light[level=12]
setblock 306 153 259 minecraft:light[level=12]
setblock 306 153 266 minecraft:light[level=12]
setblock 313 153 231 minecraft:light[level=12]
setblock 313 153 238 minecraft:light[level=12]
setblock 313 153 245 minecraft:light[level=12]
setblock 313 153 252 minecraft:light[level=12]
setblock 313 153 259 minecraft:light[level=12]
setblock 313 153 266 minecraft:light[level=12]
setblock 320 153 231 minecraft:light[level=12]
setblock 320 153 238 minecraft:light[level=12]
setblock 320 153 245 minecraft:light[level=12]
setblock 320 153 252 minecraft:light[level=12]
setblock 320 153 259 minecraft:light[level=12]
setblock 320 153 266 minecraft:light[level=12]
fill 282 154 251 282 166 251 minecraft:basalt
setblock 282 154 252 minecraft:magma_block
fill 282 154 253 282 173 253 minecraft:basalt
setblock 324 154 235 minecraft:crying_obsidian
setblock 324 154 247 minecraft:crying_obsidian
fill 282 155 252 282 173 252 minecraft:basalt
setblock 304 155 228 minecraft:shroomlight
fill 324 155 235 324 173 235 minecraft:basalt
fill 324 155 247 324 174 247 minecraft:basalt
setblock 324 155 254 minecraft:magma_block
fill 304 156 228 304 157 228 minecraft:magma_block
fill 324 156 254 324 171 254 minecraft:basalt
setblock 282 157 263 minecraft:magma_block
fill 282 158 263 282 173 263 minecraft:basalt
fill 285 158 231 285 159 231 minecraft:light[level=12]
setblock 285 158 239 minecraft:light[level=12]
setblock 285 158 247 minecraft:light[level=12]
setblock 285 158 255 minecraft:light[level=12]
setblock 285 158 263 minecraft:light[level=12]
setblock 293 158 231 minecraft:light[level=12]
setblock 293 158 239 minecraft:light[level=12]
setblock 293 158 247 minecraft:light[level=12]
setblock 293 158 255 minecraft:light[level=12]
setblock 293 158 263 minecraft:light[level=12]
setblock 301 158 231 minecraft:light[level=12]
setblock 301 158 239 minecraft:light[level=12]
setblock 301 158 247 minecraft:light[level=12]
setblock 301 158 255 minecraft:light[level=12]
setblock 301 158 263 minecraft:light[level=12]
fill 304 158 228 304 160 228 minecraft:basalt
setblock 305 158 228 minecraft:magma_block
setblock 309 158 231 minecraft:light[level=12]
setblock 309 158 239 minecraft:light[level=12]
setblock 309 158 247 minecraft:light[level=12]
setblock 309 158 255 minecraft:light[level=12]
setblock 309 158 263 minecraft:light[level=12]
setblock 317 158 231 minecraft:light[level=12]
setblock 317 158 239 minecraft:light[level=12]
setblock 317 158 247 minecraft:light[level=12]
setblock 317 158 255 minecraft:light[level=12]
setblock 317 158 263 minecraft:light[level=12]
setblock 324 158 250 minecraft:shroomlight
setblock 285 159 238 minecraft:light[level=12]
setblock 285 159 245 minecraft:light[level=12]
setblock 285 159 252 minecraft:light[level=12]
setblock 285 159 259 minecraft:light[level=12]
setblock 285 159 266 minecraft:light[level=12]
setblock 292 159 231 minecraft:light[level=12]
setblock 292 159 238 minecraft:light[level=12]
setblock 292 159 245 minecraft:light[level=12]
setblock 292 159 252 minecraft:light[level=12]
setblock 292 159 259 minecraft:light[level=12]
setblock 299 159 231 minecraft:light[level=12]
setblock 299 159 238 minecraft:light[level=12]
setblock 299 159 245 minecraft:light[level=12]
setblock 299 159 252 minecraft:light[level=12]
setblock 299 159 259 minecraft:light[level=12]
setblock 299 159 266 minecraft:light[level=12]
setblock 305 159 228 minecraft:shroomlight
setblock 306 159 231 minecraft:light[level=12]
setblock 306 159 238 minecraft:light[level=12]
setblock 306 159 245 minecraft:light[level=12]
setblock 306 159 252 minecraft:light[level=12]
setblock 306 159 259 minecraft:light[level=12]
setblock 306 159 266 minecraft:light[level=12]
setblock 313 159 231 minecraft:light[level=12]
setblock 313 159 238 minecraft:light[level=12]
setblock 313 159 245 minecraft:light[level=12]
setblock 313 159 252 minecraft:light[level=12]
setblock 313 159 259 minecraft:light[level=12]
setblock 313 159 266 minecraft:light[level=12]
setblock 320 159 231 minecraft:light[level=12]
setblock 320 159 238 minecraft:light[level=12]
setblock 320 159 245 minecraft:light[level=12]
setblock 320 159 252 minecraft:light[level=12]
setblock 320 159 259 minecraft:light[level=12]
setblock 320 159 266 minecraft:light[level=12]
fill 324 159 250 324 173 250 minecraft:basalt
setblock 305 160 228 minecraft:magma_block
setblock 316 160 228 minecraft:magma_block
setblock 282 161 229 minecraft:crying_obsidian
fill 304 161 228 304 162 228 minecraft:magma_block
setblock 305 161 228 minecraft:shroomlight
fill 316 161 228 316 174 228 minecraft:basalt
setblock 324 161 233 minecraft:magma_block
setblock 324 161 262 minecraft:magma_block
fill 282 162 229 282 168 229 minecraft:basalt
fill 305 162 228 305 173 228 minecraft:basalt
fill 324 162 233 324 173 233 minecraft:basalt
fill 324 162 262 324 171 262 minecraft:basalt
setblock 304 163 228 minecraft:shroomlight
fill 304 164 228 304 170 228 minecraft:basalt
setblock 283 165 270 minecraft:shroomlight
setblock 285 165 231 minecraft:light[level=12]
fill 285 165 238 285 165 239 minecraft:light[level=12]
setblock 285 165 245 minecraft:light[level=12]
setblock 285 165 247 minecraft:light[level=12]
setblock 285 165 252 minecraft:light[level=12]
setblock 285 165 255 minecraft:light[level=12]
setblock 285 165 259 minecraft:light[level=12]
setblock 285 165 263 minecraft:light[level=12]
setblock 285 165 266 minecraft:light[level=12]
fill 292 165 231 293 165 231 minecraft:light[level=12]
setblock 292 165 238 minecraft:light[level=12]
setblock 292 165 245 minecraft:light[level=12]
setblock 292 165 252 minecraft:light[level=12]
setblock 292 165 259 minecraft:light[level=12]
setblock 293 165 239 minecraft:light[level=12]
setblock 293 165 247 minecraft:light[level=12]
setblock 293 165 255 minecraft:light[level=12]
setblock 293 165 263 minecraft:light[level=12]
setblock 299 165 231 minecraft:light[level=12]
setblock 299 165 238 minecraft:light[level=12]
setblock 299 165 245 minecraft:light[level=12]
setblock 299 165 252 minecraft:light[level=12]
setblock 299 165 259 minecraft:light[level=12]
setblock 299 165 266 minecraft:light[level=12]
setblock 301 165 231 minecraft:light[level=12]
setblock 301 165 239 minecraft:light[level=12]
setblock 301 165 247 minecraft:light[level=12]
setblock 301 165 255 minecraft:light[level=12]
setblock 301 165 263 minecraft:light[level=12]
setblock 306 165 231 minecraft:light[level=12]
setblock 306 165 238 minecraft:light[level=12]
setblock 306 165 245 minecraft:light[level=12]
setblock 306 165 252 minecraft:light[level=12]
setblock 306 165 259 minecraft:light[level=12]
setblock 306 165 266 minecraft:light[level=12]
setblock 309 165 231 minecraft:light[level=12]
setblock 309 165 239 minecraft:light[level=12]
setblock 309 165 247 minecraft:light[level=12]
setblock 309 165 255 minecraft:light[level=12]
setblock 309 165 263 minecraft:light[level=12]
setblock 313 165 231 minecraft:light[level=12]
setblock 313 165 238 minecraft:light[level=12]
setblock 313 165 245 minecraft:light[level=12]
setblock 313 165 252 minecraft:light[level=12]
setblock 313 165 259 minecraft:light[level=12]
setblock 313 165 266 minecraft:light[level=12]
setblock 317 165 231 minecraft:light[level=12]
setblock 317 165 239 minecraft:light[level=12]
setblock 317 165 247 minecraft:light[level=12]
setblock 317 165 255 minecraft:light[level=12]
setblock 317 165 263 minecraft:light[level=12]
setblock 320 165 231 minecraft:light[level=12]
setblock 320 165 238 minecraft:light[level=12]
setblock 320 165 245 minecraft:light[level=12]
setblock 320 165 252 minecraft:light[level=12]
setblock 320 165 259 minecraft:light[level=12]
setblock 320 165 266 minecraft:light[level=12]
setblock 324 165 244 minecraft:crying_obsidian
setblock 282 166 264 minecraft:shroomlight
fill 283 166 270 283 174 270 minecraft:basalt
fill 287 166 265 288 166 266 minecraft:orange_concrete
fill 288 166 263 289 166 264 minecraft:orange_concrete
fill 288 166 267 289 166 268 minecraft:orange_concrete
fill 289 166 262 293 166 262 minecraft:orange_concrete
fill 289 166 269 293 166 269 minecraft:orange_concrete
fill 290 166 263 294 166 263 minecraft:orange_concrete
fill 290 166 268 294 166 268 minecraft:orange_concrete
fill 293 166 264 295 166 264 minecraft:orange_concrete
fill 293 166 267 294 166 267 minecraft:orange_concrete
fill 294 166 265 295 166 266 minecraft:orange_concrete
setblock 298 166 270 minecraft:magma_block
fill 324 166 244 324 171 244 minecraft:basalt
setblock 282 167 251 minecraft:shroomlight
fill 282 167 264 282 171 264 minecraft:basalt
fill 283 167 229 286 167 269 minecraft:blackstone
fill 287 167 229 323 167 232 minecraft:blackstone
fill 287 167 266 323 167 269 minecraft:blackstone
fill 288 167 264 288 167 265 minecraft:orange_concrete
fill 289 167 263 289 167 264 minecraft:orange_concrete
fill 290 167 262 292 167 263 minecraft:orange_concrete
fill 293 167 263 293 167 264 minecraft:orange_concrete
fill 294 167 264 294 167 265 minecraft:orange_concrete
fill 297 167 270 298 167 270 minecraft:shroomlight
fill 320 167 233 323 167 265 minecraft:blackstone
setblock 324 167 236 minecraft:magma_block
fill 282 168 251 282 169 251 minecraft:basalt
fill 283 168 229 285 168 269 minecraft:magma_block
fill 286 168 229 323 168 231 minecraft:magma_block
fill 286 168 267 323 168 269 minecraft:magma_block
setblock 289 168 264 minecraft:orange_concrete
fill 289 168 266 293 169 266 minecraft:basalt
fill 290 168 263 292 168 263 minecraft:orange_concrete
setblock 293 168 264 minecraft:orange_concrete
setblock 295 168 228 minecraft:magma_block
fill 296 168 228 297 170 228 minecraft:basalt
setblock 297 168 270 minecraft:shroomlight
fill 298 168 270 298 171 270 minecraft:basalt
fill 321 168 232 323 168 266 minecraft:magma_block
fill 324 168 236 324 169 236 minecraft:basalt
setblock 282 169 229 minecraft:magma_block
fill 283 169 229 284 169 269 minecraft:shroomlight
fill 285 169 229 323 169 230 minecraft:shroomlight
fill 285 169 268 323 169 269 minecraft:shroomlight
fill 290 169 267 292 169 267 minecraft:basalt
fill 295 169 228 295 173 228 minecraft:basalt
fill 297 169 270 297 173 270 minecraft:basalt
fill 322 169 231 323 169 267 minecraft:shroomlight
setblock 282 170 229 minecraft:blackstone
setblock 282 170 236 minecraft:blackstone
fill 282 170 237 282 174 237 minecraft:basalt
setblock 282 170 247 minecraft:blackstone
setblock 282 170 251 minecraft:blackstone
fill 282 170 269 282 170 270 minecraft:blackstone
fill 300 170 270 301 170 270 minecraft:blackstone
setblock 306 170 228 minecraft:blackstone
setblock 309 170 228 minecraft:shroomlight
setblock 311 170 228 minecraft:blackstone
setblock 313 170 228 minecraft:blackstone
fill 314 170 228 314 173 228 minecraft:basalt
setblock 318 170 228 minecraft:magma_block
setblock 322 170 270 minecraft:blackstone
setblock 324 170 229 minecraft:blackstone
setblock 324 170 236 minecraft:blackstone
setblock 324 170 240 minecraft:blackstone
fill 324 170 241 324 170 242 minecraft:basalt
fill 324 170 257 324 173 257 minecraft:basalt
setblock 324 170 258 minecraft:blackstone
fill 324 170 259 324 173 259 minecraft:basalt
setblock 324 170 260 minecraft:magma_block
setblock 282 171 228 minecraft:blackstone
setblock 282 171 229 minecraft:basalt
setblock 282 171 230 minecraft:blackstone
fill 282 171 236 282 173 236 minecraft:basalt
fill 282 171 239 282 173 239 minecraft:basalt
fill 282 171 240 282 171 242 minecraft:blackstone
fill 282 171 247 282 173 247 minecraft:basalt
fill 282 171 251 282 174 251 minecraft:basalt
setblock 282 171 254 minecraft:blackstone
setblock 282 171 258 minecraft:blackstone
setblock 282 171 265 minecraft:basalt
setblock 282 171 266 minecraft:blackstone
fill 282 171 269 282 173 270 minecraft:basalt
fill 283 171 228 283 173 228 minecraft:basalt
setblock 284 171 228 minecraft:blackstone
fill 285 171 231 285 172 231 minecraft:light[level=12]
setblock 285 171 238 minecraft:light[level=12]
setblock 285 171 245 minecraft:light[level=12]
setblock 285 171 252 minecraft:light[level=12]
setblock 285 171 259 minecraft:light[level=12]
setblock 285 171 266 minecraft:light[level=12]
setblock 292 171 231 minecraft:light[level=12]
setblock 292 171 238 minecraft:light[level=12]
setblock 292 171 245 minecraft:light[level=12]
setblock 292 171 252 minecraft:light[level=12]
setblock 292 171 259 minecraft:light[level=12]
setblock 292 171 266 minecraft:light[level=12]
setblock 296 171 228 minecraft:blackstone
fill 297 171 228 297 173 228 minecraft:basalt
fill 298 171 249 301 173 249 minecraft:basalt
setblock 299 171 231 minecraft:light[level=12]
setblock 299 171 238 minecraft:light[level=12]
setblock 299 171 245 minecraft:light[level=12]
fill 299 171 248 300 176 248 minecraft:basalt
fill 299 171 250 301 173 250 minecraft:basalt
setblock 299 171 252 minecraft:light[level=12]
fill 299 171 253 302 173 254 minecraft:basalt
setblock 299 171 259 minecraft:light[level=12]
setblock 299 171 266 minecraft:light[level=12]
fill 300 171 252 301 173 252 minecraft:basalt
fill 300 171 255 301 176 255 minecraft:basalt
fill 300 171 270 301 173 270 minecraft:basalt
setblock 301 171 228 minecraft:blackstone
fill 303 171 250 306 173 250 minecraft:basalt
setblock 304 171 228 minecraft:blackstone
fill 304 171 249 306 173 249 minecraft:basalt
fill 304 171 251 305 173 252 minecraft:basalt
fill 306 171 228 306 174 228 minecraft:basalt
setblock 306 171 231 minecraft:light[level=12]
setblock 306 171 238 minecraft:light[level=12]
setblock 306 171 245 minecraft:light[level=12]
fill 306 171 251 306 176 251 minecraft:basalt
setblock 306 171 252 minecraft:light[level=12]
setblock 306 171 259 minecraft:light[level=12]
setblock 306 171 266 minecraft:light[level=12]
fill 309 171 228 309 173 228 minecraft:basalt
fill 311 171 228 311 173 228 minecraft:basalt
setblock 313 171 228 minecraft:basalt
setblock 313 171 231 minecraft:light[level=12]
setblock 313 171 238 minecraft:light[level=12]
setblock 313 171 245 minecraft:light[level=12]
setblock 313 171 252 minecraft:light[level=12]
setblock 313 171 259 minecraft:light[level=12]
setblock 313 171 266 minecraft:light[level=12]
setblock 315 171 228 minecraft:blackstone
setblock 317 171 270 minecraft:blackstone
fill 318 171 228 318 173 228 minecraft:basalt
setblock 320 171 231 minecraft:light[level=12]
setblock 320 171 238 minecraft:light[level=12]
setblock 320 171 245 minecraft:light[level=12]
setblock 320 171 252 minecraft:light[level=12]
setblock 320 171 259 minecraft:light[level=12]
setblock 320 171 266 minecraft:light[level=12]
setblock 321 171 228 minecraft:blackstone
fill 321 171 270 321 172 270 minecraft:blackstone
fill 322 171 270 322 173 270 minecraft:basalt
fill 324 171 229 324 174 229 minecraft:basalt
setblock 324 171 230 minecraft:blackstone
fill 324 171 236 324 173 236 minecraft:basalt
fill 324 171 240 324 173 240 minecraft:basalt
setblock 324 171 241 minecraft:shroomlight
setblock 324 171 242 minecraft:blackstone
fill 324 171 258 324 174 258 minecraft:basalt
setblock 324 171 260 minecraft:basalt
setblock 324 171 261 minecraft:blackstone
setblock 324 171 270 minecraft:blackstone
fill 282 172 228 282 175 228 minecraft:basalt
setblock 282 172 229 minecraft:blackstone
fill 282 172 230 282 173 230 minecraft:basalt
setblock 282 172 232 minecraft:blackstone
fill 282 172 240 282 173 242 minecraft:basalt
fill 282 172 245 282 173 245 minecraft:basalt
setblock 282 172 246 minecraft:blackstone
fill 282 172 254 282 173 254 minecraft:basalt
fill 282 172 258 282 173 258 minecraft:basalt
fill 282 172 264 282 172 265 minecraft:blackstone
fill 282 172 266 282 173 266 minecraft:basalt
fill 284 172 228 284 173 228 minecraft:basalt
setblock 285 172 239 minecraft:light[level=12]
setblock 285 172 247 minecraft:light[level=12]
setblock 285 172 255 minecraft:light[level=12]
setblock 285 172 263 minecraft:light[level=12]
fill 291 172 228 292 172 228 minecraft:blackstone
setblock 293 172 231 minecraft:light[level=12]
setblock 293 172 239 minecraft:light[level=12]
setblock 293 172 247 minecraft:light[level=12]
setblock 293 172 255 minecraft:light[level=12]
setblock 293 172 263 minecraft:light[level=12]
fill 295 172 248 297 176 254 minecraft:basalt
fill 296 172 228 296 173 228 minecraft:basalt
fill 296 172 246 307 176 247 minecraft:basalt
fill 296 172 255 299 176 256 minecraft:basalt
setblock 296 172 270 minecraft:blackstone
fill 297 172 245 306 176 245 minecraft:basalt
fill 297 172 257 305 176 257 minecraft:basalt
fill 298 172 248 298 176 248 minecraft:basalt
fill 298 172 250 298 176 254 minecraft:basalt
fill 298 172 258 303 176 258 minecraft:basalt
setblock 298 172 270 minecraft:blackstone
fill 299 172 244 304 176 244 minecraft:basalt
fill 299 172 251 299 173 252 minecraft:basalt
fill 300 172 251 300 173 251 minecraft:basalt
fill 300 172 256 307 176 256 minecraft:basalt
fill 301 172 228 301 174 228 minecraft:basalt
setblock 301 172 231 minecraft:light[level=12]
setblock 301 172 239 minecraft:light[level=12]
fill 301 172 248 309 173 248 minecraft:basalt
setblock 301 172 263 minecraft:light[level=12]
fill 302 172 249 303 173 249 minecraft:basalt
fill 302 172 255 308 176 255 minecraft:basalt
fill 303 172 252 303 173 254 minecraft:basalt
fill 304 172 228 304 173 228 minecraft:basalt
fill 304 172 253 309 173 254 minecraft:basalt
fill 306 172 252 310 176 252 minecraft:basalt
setblock 306 172 270 minecraft:blackstone
fill 307 172 249 309 176 251 minecraft:basalt
fill 308 172 247 308 176 247 minecraft:basalt
setblock 309 172 231 minecraft:light[level=12]
setblock 309 172 239 minecraft:light[level=12]
setblock 309 172 247 minecraft:light[level=12]
setblock 309 172 255 minecraft:light[level=12]
setblock 309 172 263 minecraft:light[level=12]
setblock 310 172 228 minecraft:blackstone
fill 310 172 250 310 176 251 minecraft:basalt
setblock 313 172 228 minecraft:blackstone
fill 315 172 228 315 173 228 minecraft:basalt
setblock 317 172 231 minecraft:light[level=12]
setblock 317 172 239 minecraft:light[level=12]
setblock 317 172 247 minecraft:light[level=12]
setblock 317 172 255 minecraft:light[level=12]
setblock 317 172 263 minecraft:light[level=12]
fill 317 172 270 317 173 270 minecraft:basalt
fill 321 172 228 321 173 228 minecraft:basalt
fill 324 172 230 324 173 230 minecraft:basalt
fill 324 172 241 324 173 242 minecraft:basalt
setblock 324 172 244 minecraft:blackstone
setblock 324 172 254 minecraft:blackstone
setblock 324 172 260 minecraft:blackstone
fill 324 172 261 324 173 261 minecraft:basalt
setblock 324 172 262 minecraft:blackstone
setblock 324 172 264 minecraft:crying_obsidian
fill 324 172 270 324 173 270 minecraft:basalt
setblock 282 173 229 minecraft:basalt
setblock 282 173 232 minecraft:basalt
setblock 282 173 246 minecraft:basalt
fill 282 173 264 282 173 265 minecraft:basalt
fill 291 173 228 292 173 228 minecraft:basalt
fill 293 173 249 294 175 254 minecraft:basalt
fill 294 173 247 294 176 248 minecraft:basalt
fill 294 173 255 295 175 256 minecraft:basalt
fill 295 173 245 295 176 247 minecraft:basalt
fill 295 173 257 296 176 257 minecraft:basalt
fill 296 173 244 296 176 245 minecraft:basalt
fill 296 173 258 297 176 258 minecraft:basalt
setblock 296 173 270 minecraft:basalt
fill 297 173 243 298 176 244 minecraft:basalt
fill 297 173 259 307 176 259 minecraft:basalt
setblock 298 173 270 minecraft:basalt
fill 299 173 242 305 176 243 minecraft:basalt
fill 300 173 260 305 176 260 minecraft:basalt
fill 304 173 258 308 176 258 minecraft:basalt
fill 305 173 244 308 176 244 minecraft:basalt
fill 306 173 243 307 176 243 minecraft:basalt
fill 306 173 257 309 176 257 minecraft:basalt
setblock 306 173 270 minecraft:basalt
fill 307 173 245 309 176 245 minecraft:basalt
fill 308 173 246 309 176 246 minecraft:basalt
fill 308 173 256 310 175 256 minecraft:basalt
fill 309 173 247 310 176 247 minecraft:basalt
fill 309 173 255 310 176 255 minecraft:basalt
setblock 310 173 228 minecraft:basalt
fill 310 173 248 310 176 249 minecraft:basalt
fill 310 173 253 311 175 254 minecraft:basalt
fill 311 173 249 311 176 252 minecraft:basalt
setblock 313 173 228 minecraft:basalt
setblock 321 173 270 minecraft:basalt
setblock 324 173 238 minecraft:crying_obsidian
setblock 324 173 244 minecraft:basalt
fill 324 173 254 324 175 254 minecraft:basalt
setblock 324 173 260 minecraft:basalt
setblock 324 173 262 minecraft:basalt
setblock 324 173 264 minecraft:basalt
fill 282 174 229 282 199 230 minecraft:blackstone
fill 282 174 232 282 182 236 minecraft:blackstone
fill 282 174 238 282 174 250 minecraft:blackstone
fill 282 174 252 282 174 261 minecraft:blackstone
fill 282 174 263 282 174 270 minecraft:blackstone
fill 283 174 228 288 179 228 minecraft:blackstone
fill 284 174 270 308 174 270 minecraft:blackstone
fill 290 174 228 300 174 228 minecraft:blackstone
fill 292 174 250 292 175 253 minecraft:basalt
fill 293 174 247 293 175 248 minecraft:basalt
fill 293 174 255 293 175 255 minecraft:basalt
fill 294 174 246 294 176 246 minecraft:basalt
fill 294 174 257 294 175 257 minecraft:basalt
fill 295 174 244 295 175 244 minecraft:basalt
fill 295 174 258 295 175 258 minecraft:basalt
fill 296 174 243 296 175 243 minecraft:basalt
fill 296 174 259 296 175 259 minecraft:basalt
fill 297 174 242 298 175 242 minecraft:basalt
fill 298 174 249 299 176 249 minecraft:basalt
fill 298 174 260 299 175 260 minecraft:basalt
fill 299 174 241 305 175 241 minecraft:basalt
fill 299 174 253 299 176 254 minecraft:basalt
fill 300 174 254 300 176 254 minecraft:basalt
fill 300 174 261 305 175 261 minecraft:basalt
setblock 302 174 228 minecraft:blackstone
fill 304 174 228 305 174 228 minecraft:blackstone
fill 304 174 248 309 176 248 minecraft:basalt
fill 304 174 254 309 176 254 minecraft:basalt
fill 305 174 249 306 176 249 minecraft:basalt
fill 305 174 253 309 176 253 minecraft:basalt
fill 306 174 242 307 175 242 minecraft:basalt
fill 306 174 250 306 176 250 minecraft:basalt
fill 306 174 260 307 175 260 minecraft:basalt
fill 307 174 228 315 174 228 minecraft:blackstone
fill 308 174 243 308 175 243 minecraft:basalt
fill 308 174 259 309 174 259 minecraft:basalt
fill 309 174 244 309 175 244 minecraft:basalt
fill 309 174 258 310 174 258 minecraft:basalt
fill 310 174 245 310 175 246 minecraft:basalt
fill 310 174 257 310 175 257 minecraft:basalt
fill 310 174 270 324 174 270 minecraft:blackstone
fill 311 174 247 311 175 248 minecraft:basalt
fill 311 174 255 311 175 256 minecraft:basalt
fill 312 174 250 312 175 253 minecraft:basalt
fill 317 174 228 324 174 228 minecraft:blackstone
fill 324 174 230 324 174 246 minecraft:blackstone
fill 324 174 248 324 259 248 minecraft:blackstone
fill 324 174 250 324 174 253 minecraft:blackstone
fill 324 174 255 324 175 257 minecraft:blackstone
fill 324 174 259 324 174 268 minecraft:blackstone
fill 282 175 231 282 283 231 minecraft:blackstone
fill 282 175 237 282 234 238 minecraft:blackstone
fill 282 175 239 282 175 240 minecraft:basalt
fill 282 175 241 282 175 253 minecraft:blackstone
setblock 282 175 254 minecraft:magma_block
fill 282 175 255 282 175 269 minecraft:blackstone
setblock 282 175 270 minecraft:basalt
fill 283 175 270 283 283 270 minecraft:blackstone
setblock 284 175 270 minecraft:basalt
fill 285 175 270 290 175 270 minecraft:blackstone
fill 289 175 228 297 189 228 minecraft:blackstone
setblock 291 175 270 minecraft:basalt
fill 292 175 270 295 189 270 minecraft:blackstone
setblock 294 175 245 minecraft:basalt
setblock 296 175 270 minecraft:basalt
fill 297 175 270 306 175 270 minecraft:blackstone
setblock 298 175 228 minecraft:basalt
fill 299 175 228 301 179 228 minecraft:blackstone
setblock 302 175 228 minecraft:basalt
fill 303 175 228 303 194 228 minecraft:blackstone
setblock 304 175 228 minecraft:basalt
fill 305 175 228 307 194 228 minecraft:blackstone
setblock 307 175 270 minecraft:basalt
setblock 308 175 228 minecraft:basalt
setblock 308 175 259 minecraft:basalt
fill 308 175 270 308 283 270 minecraft:blackstone
fill 309 175 228 310 205 228 minecraft:blackstone
setblock 309 175 258 minecraft:basalt
fill 310 175 270 312 229 270 minecraft:blackstone
fill 311 175 228 311 176 228 minecraft:basalt
fill 312 175 228 318 175 228 minecraft:blackstone
setblock 313 175 270 minecraft:basalt
fill 314 175 270 324 192 270 minecraft:blackstone
setblock 319 175 228 minecraft:basalt
fill 320 175 228 320 192 228 minecraft:blackstone
setblock 321 175 228 minecraft:basalt
fill 322 175 228 324 175 228 minecraft:blackstone
fill 324 175 229 324 181 236 minecraft:blackstone
setblock 324 175 237 minecraft:basalt
fill 324 175 238 324 228 238 minecraft:blackstone
setblock 324 175 239 minecraft:basalt
fill 324 175 240 324 191 241 minecraft:blackstone
setblock 324 175 242 minecraft:basalt
fill 324 175 243 324 180 247 minecraft:blackstone
fill 324 175 249 324 214 249 minecraft:blackstone
fill 324 175 250 324 175 251 minecraft:basalt
fill 324 175 252 324 204 253 minecraft:blackstone
fill 324 175 258 324 201 260 minecraft:blackstone
setblock 324 175 261 minecraft:basalt
fill 324 175 262 324 233 265 minecraft:blackstone
fill 324 175 266 324 175 267 minecraft:basalt
fill 324 175 268 324 188 269 minecraft:blackstone
fill 282 176 228 282 283 228 minecraft:blackstone
fill 282 176 239 282 192 241 minecraft:blackstone
setblock 282 176 242 minecraft:basalt
fill 282 176 243 282 178 249 minecraft:blackstone
setblock 282 176 250 minecraft:basalt
fill 282 176 251 282 178 252 minecraft:blackstone
setblock 282 176 253 minecraft:basalt
fill 282 176 254 282 181 255 minecraft:blackstone
fill 282 176 256 282 176 258 minecraft:basalt
fill 282 176 259 282 180 270 minecraft:blackstone
fill 284 176 270 287 204 270 minecraft:blackstone
setblock 288 176 270 minecraft:basalt
fill 289 176 270 291 214 270 minecraft:blackstone
fill 293 176 248 293 176 253 minecraft:basalt
fill 294 176 249 294 176 255 minecraft:basalt
fill 295 176 255 295 176 256 minecraft:basalt
fill 296 176 270 297 222 270 minecraft:blackstone
fill 298 176 228 298 248 228 minecraft:blackstone
setblock 298 176 270 minecraft:basalt
setblock 299 176 260 minecraft:basalt
fill 299 176 270 307 181 270 minecraft:blackstone
fill 302 176 228 302 198 228 minecraft:blackstone
fill 304 176 228 304 274 228 minecraft:blackstone
fill 308 176 228 308 283 228 minecraft:blackstone
fill 308 176 256 309 176 256 minecraft:basalt
setblock 310 176 246 minecraft:basalt
fill 310 176 253 310 176 254 minecraft:basalt
setblock 311 176 248 minecraft:basalt
setblock 311 176 253 minecraft:basalt
fill 312 176 228 314 193 228 minecraft:blackstone
fill 313 176 270 313 283 270 minecraft:blackstone
setblock 315 176 228 minecraft:basalt
fill 316 176 228 316 283 228 minecraft:blackstone
setblock 317 176 228 minecraft:basalt
fill 318 176 228 319 180 228 minecraft:blackstone
fill 321 176 228 322 283 228 minecraft:blackstone
setblock 323 176 228 minecraft:basalt
fill 324 176 228 324 283 228 minecraft:blackstone
fill 324 176 237 324 181 237 minecraft:blackstone
fill 324 176 239 324 283 239 minecraft:blackstone
fill 324 176 242 324 255 242 minecraft:blackstone
fill 324 176 250 324 262 251 minecraft:blackstone
fill 324 176 254 324 213 254 minecraft:blackstone
fill 324 176 255 324 176 256 minecraft:basalt
fill 324 176 257 324 187 257 minecraft:blackstone
fill 324 176 261 324 283 261 minecraft:blackstone
fill 324 176 266 324 182 267 minecraft:blackstone
fill 282 177 242 282 192 242 minecraft:blackstone
fill 282 177 250 282 278 250 minecraft:blackstone
fill 282 177 253 282 249 253 minecraft:blackstone
fill 282 177 256 282 283 258 minecraft:blackstone
setblock 285 177 231 minecraft:light[level=12]
setblock 285 177 238 minecraft:light[level=12]
setblock 285 177 245 minecraft:light[level=12]
setblock 285 177 252 minecraft:light[level=12]
setblock 285 177 259 minecraft:light[level=12]
setblock 285 177 266 minecraft:light[level=12]
fill 288 177 270 288 186 270 minecraft:blackstone
setblock 292 177 231 minecraft:light[level=12]
setblock 292 177 238 minecraft:light[level=12]
setblock 292 177 245 minecraft:light[level=12]
fill 292 177 248 292 177 254 minecraft:magma_block
setblock 292 177 259 minecraft:light[level=12]
setblock 292 177 266 minecraft:light[level=12]
fill 293 177 246 293 177 248 minecraft:magma_block
fill 293 177 254 293 177 256 minecraft:magma_block
fill 294 177 245 294 177 246 minecraft:magma_block
fill 294 177 256 294 177 257 minecraft:magma_block
setblock 295 177 244 minecraft:magma_block
fill 295 177 247 295 177 249 minecraft:blackstone
fill 295 177 250 297 177 252 minecraft:magma_block
setblock 295 177 253 minecraft:blackstone
setblock 295 177 258 minecraft:magma_block
fill 296 177 243 297 177 243 minecraft:magma_block
fill 296 177 246 296 177 247 minecraft:blackstone
fill 296 177 248 297 177 249 minecraft:magma_block
fill 296 177 253 297 177 254 minecraft:magma_block
setblock 296 177 255 minecraft:blackstone
fill 296 177 259 297 177 259 minecraft:magma_block
fill 297 177 242 299 177 242 minecraft:magma_block
fill 297 177 245 298 177 245 minecraft:blackstone
fill 297 177 246 299 177 247 minecraft:magma_block
fill 297 177 255 299 177 256 minecraft:magma_block
fill 297 177 260 299 177 260 minecraft:magma_block
fill 298 177 248 298 178 248 minecraft:magma_block
fill 298 177 249 299 177 249 minecraft:ochre_froglight
fill 298 177 250 298 177 252 minecraft:shroomlight
fill 298 177 253 299 177 253 minecraft:ochre_froglight
fill 298 177 254 298 178 254 minecraft:magma_block
setblock 298 177 257 minecraft:blackstone
fill 298 177 270 298 283 270 minecraft:blackstone
setblock 299 177 231 minecraft:light[level=12]
setblock 299 177 238 minecraft:light[level=12]
fill 299 177 241 305 177 241 minecraft:magma_block
fill 299 177 245 305 177 245 minecraft:magma_block
setblock 299 177 248 minecraft:shroomlight
setblock 299 177 254 minecraft:shroomlight
fill 299 177 257 305 177 257 minecraft:magma_block
fill 299 177 258 300 177 258 minecraft:blackstone
setblock 299 177 259 minecraft:light[level=12]
fill 299 177 261 305 177 261 minecraft:magma_block
setblock 299 177 266 minecraft:light[level=12]
setblock 300 177 244 minecraft:blackstone
fill 300 177 246 307 177 246 minecraft:magma_block
fill 300 177 247 300 177 248 minecraft:ochre_froglight
fill 300 177 254 300 177 255 minecraft:ochre_froglight
fill 300 177 256 307 177 256 minecraft:magma_block
fill 301 177 244 303 178 244 minecraft:magma_block
fill 301 177 247 303 177 247 minecraft:shroomlight
fill 301 177 255 303 177 255 minecraft:shroomlight
fill 301 177 258 303 178 258 minecraft:magma_block
setblock 304 177 244 minecraft:blackstone
fill 304 177 247 304 177 248 minecraft:ochre_froglight
fill 304 177 254 304 177 255 minecraft:ochre_froglight
setblock 304 177 258 minecraft:blackstone
fill 305 177 242 307 177 242 minecraft:magma_block
fill 305 177 247 307 177 247 minecraft:magma_block
setblock 305 177 248 minecraft:shroomlight
fill 305 177 249 306 177 249 minecraft:ochre_froglight
fill 305 177 253 306 177 253 minecraft:ochre_froglight
setblock 305 177 254 minecraft:shroomlight
fill 305 177 255 307 177 255 minecraft:magma_block
fill 305 177 260 307 177 260 minecraft:magma_block
setblock 306 177 231 minecraft:light[level=12]
setblock 306 177 238 minecraft:light[level=12]
setblock 306 177 245 minecraft:blackstone
fill 306 177 248 308 177 248 minecraft:magma_block
fill 306 177 250 306 177 252 minecraft:shroomlight
fill 306 177 254 308 177 254 minecraft:magma_block
setblock 306 177 257 minecraft:blackstone
setblock 306 177 259 minecraft:light[level=12]
setblock 306 177 266 minecraft:light[level=12]
fill 307 177 243 308 177 243 minecraft:magma_block
fill 307 177 249 308 177 253 minecraft:magma_block
fill 307 177 259 308 177 259 minecraft:magma_block
fill 308 177 246 308 177 247 minecraft:blackstone
setblock 308 177 255 minecraft:blackstone
setblock 309 177 244 minecraft:magma_block
fill 309 177 248 309 177 249 minecraft:blackstone
fill 309 177 250 309 178 252 minecraft:magma_block
setblock 309 177 253 minecraft:blackstone
setblock 309 177 258 minecraft:magma_block
fill 309 177 270 309 209 270 minecraft:blackstone
fill 310 177 245 310 177 246 minecraft:magma_block
fill 310 177 256 310 177 257 minecraft:magma_block
fill 311 177 228 311 283 228 minecraft:blackstone
fill 311 177 246 311 177 248 minecraft:magma_block
fill 311 177 254 311 177 256 minecraft:magma_block
fill 312 177 248 312 177 254 minecraft:magma_block
setblock 313 177 231 minecraft:light[level=12]
setblock 313 177 238 minecraft:light[level=12]
setblock 313 177 245 minecraft:light[level=12]
setblock 313 177 252 minecraft:light[level=12]
setblock 313 177 259 minecraft:light[level=12]
setblock 313 177 266 minecraft:light[level=12]
fill 315 177 228 315 199 228 minecraft:blackstone
fill 317 177 228 317 283 228 minecraft:blackstone
setblock 320 177 231 minecraft:light[level=12]
setblock 320 177 238 minecraft:light[level=12]
setblock 320 177 245 minecraft:light[level=12]
setblock 320 177 252 minecraft:light[level=12]
setblock 320 177 259 minecraft:light[level=12]
setblock 320 177 266 minecraft:light[level=12]
fill 323 177 228 323 283 228 minecraft:blackstone
fill 324 177 255 324 233 256 minecraft:blackstone
fill 283 178 235 284 178 267 minecraft:basalt
fill 284 178 234 287 178 234 minecraft:basalt
setblock 284 178 268 minecraft:basalt
fill 285 178 233 290 178 233 minecraft:basalt
setblock 285 178 235 minecraft:magma_block
fill 285 178 236 287 180 237 minecraft:basalt
setblock 285 178 238 minecraft:magma_block
fill 285 178 239 287 182 240 minecraft:basalt
setblock 285 178 241 minecraft:magma_block
fill 285 178 242 287 183 243 minecraft:basalt
setblock 285 178 244 minecraft:magma_block
fill 285 178 245 286 186 246 minecraft:basalt
setblock 285 178 247 minecraft:magma_block
fill 285 178 248 285 186 249 minecraft:basalt
setblock 285 178 250 minecraft:magma_block
fill 285 178 251 285 187 252 minecraft:basalt
setblock 285 178 253 minecraft:magma_block
fill 285 178 254 286 186 255 minecraft:basalt
setblock 285 178 256 minecraft:magma_block
fill 285 178 257 286 185 258 minecraft:basalt
setblock 285 178 259 minecraft:magma_block
fill 285 178 260 287 183 261 minecraft:basalt
setblock 285 178 262 minecraft:magma_block
fill 285 178 263 287 182 264 minecraft:basalt
setblock 285 178 265 minecraft:magma_block
fill 285 178 266 287 179 267 minecraft:basalt
setblock 285 178 268 minecraft:magma_block
fill 285 178 269 290 178 269 minecraft:basalt
fill 286 178 232 293 178 232 minecraft:basalt
fill 286 178 235 293 179 235 minecraft:basalt
fill 286 178 238 292 183 238 minecraft:basalt
fill 286 178 241 289 185 241 minecraft:basalt
fill 286 178 244 287 186 244 minecraft:basalt
fill 286 178 247 286 187 248 minecraft:basalt
fill 286 178 256 286 187 256 minecraft:basalt
fill 286 178 259 287 186 259 minecraft:basalt
fill 286 178 262 290 178 262 minecraft:basalt
fill 286 178 265 293 182 265 minecraft:basalt
fill 286 178 268 293 179 268 minecraft:basalt
setblock 287 178 231 minecraft:basalt
fill 287 178 258 287 187 258 minecraft:basalt
setblock 288 178 231 minecraft:magma_block
setblock 288 178 234 minecraft:magma_block
fill 288 178 236 290 182 236 minecraft:basalt
setblock 288 178 237 minecraft:magma_block
fill 288 178 239 290 185 239 minecraft:basalt
setblock 288 178 240 minecraft:magma_block
fill 288 178 242 288 187 242 minecraft:basalt
fill 288 178 260 288 187 260 minecraft:basalt
setblock 288 178 261 minecraft:magma_block
fill 288 178 263 290 185 263 minecraft:basalt
setblock 288 178 264 minecraft:magma_block
fill 288 178 266 290 182 266 minecraft:basalt
setblock 288 178 267 minecraft:magma_block
fill 289 178 230 290 178 231 minecraft:basalt
fill 289 178 234 296 181 234 minecraft:basalt
fill 289 178 237 293 184 237 minecraft:basalt
fill 289 178 240 290 187 240 minecraft:basalt
fill 289 178 261 289 187 261 minecraft:basalt
fill 289 178 264 292 185 264 minecraft:basalt
fill 289 178 267 296 183 267 minecraft:basalt
fill 290 178 229 293 178 229 minecraft:basalt
setblock 291 178 230 minecraft:magma_block
fill 291 178 231 296 180 231 minecraft:basalt
setblock 291 178 233 minecraft:magma_block
setblock 291 178 236 minecraft:magma_block
setblock 291 178 239 minecraft:magma_block
setblock 291 178 263 minecraft:magma_block
setblock 291 178 266 minecraft:magma_block
setblock 291 178 269 minecraft:magma_block
fill 292 178 230 299 179 230 minecraft:basalt
fill 292 178 233 299 183 233 minecraft:basalt
fill 292 178 236 295 186 236 minecraft:basalt
fill 292 178 266 295 186 266 minecraft:basalt
fill 292 178 269 299 183 269 minecraft:basalt
setblock 294 178 229 minecraft:magma_block
setblock 294 178 232 minecraft:magma_block
setblock 294 178 235 minecraft:magma_block
setblock 294 178 268 minecraft:magma_block
fill 295 178 229 302 179 229 minecraft:basalt
fill 295 178 232 302 183 232 minecraft:basalt
fill 295 178 235 299 178 235 minecraft:basalt
fill 295 178 250 295 178 252 minecraft:magma_block
fill 295 178 268 302 185 268 minecraft:basalt
setblock 296 178 248 minecraft:magma_block
fill 296 178 249 296 178 253 minecraft:shroomlight
setblock 296 178 254 minecraft:magma_block
setblock 297 178 231 minecraft:magma_block
setblock 297 178 234 minecraft:magma_block
setblock 297 178 246 minecraft:magma_block
fill 297 178 247 297 178 249 minecraft:shroomlight
fill 297 178 250 297 178 252 minecraft:magma_block
fill 297 178 253 297 178 255 minecraft:shroomlight
setblock 297 178 256 minecraft:magma_block
setblock 297 178 267 minecraft:magma_block
fill 298 178 231 305 182 231 minecraft:basalt
fill 298 178 234 305 186 234 minecraft:basalt
fill 298 178 246 298 178 247 minecraft:shroomlight
setblock 298 178 250 minecraft:basalt
fill 298 178 255 298 178 256 minecraft:shroomlight
fill 298 178 267 299 187 267 minecraft:basalt
setblock 299 178 245 minecraft:magma_block
fill 299 178 246 300 178 246 minecraft:shroomlight
setblock 299 178 247 minecraft:magma_block
setblock 299 178 249 minecraft:basalt
setblock 299 178 253 minecraft:basalt
setblock 299 178 255 minecraft:magma_block
fill 299 178 256 300 178 256 minecraft:shroomlight
setblock 299 178 257 minecraft:magma_block
setblock 300 178 230 minecraft:magma_block
setblock 300 178 233 minecraft:magma_block
fill 300 178 245 304 178 245 minecraft:shroomlight
fill 300 178 257 304 178 257 minecraft:shroomlight
setblock 300 178 269 minecraft:magma_block
fill 301 178 230 308 181 230 minecraft:basalt
fill 301 178 233 308 184 233 minecraft:basalt
fill 301 178 246 303 178 246 minecraft:magma_block
fill 301 178 256 303 178 256 minecraft:magma_block
fill 301 178 269 308 184 269 minecraft:basalt
setblock 303 178 229 minecraft:magma_block
setblock 303 178 232 minecraft:magma_block
setblock 303 178 268 minecraft:magma_block
fill 304 178 229 311 179 229 minecraft:basalt
fill 304 178 232 311 182 232 minecraft:basalt
fill 304 178 246 306 178 246 minecraft:shroomlight
fill 304 178 256 306 178 256 minecraft:shroomlight
fill 304 178 268 311 184 268 minecraft:basalt
fill 305 178 235 311 184 235 minecraft:basalt
setblock 305 178 245 minecraft:magma_block
setblock 305 178 247 minecraft:magma_block
setblock 305 178 255 minecraft:magma_block
setblock 305 178 257 minecraft:magma_block
fill 305 178 267 305 188 267 minecraft:basalt
setblock 306 178 231 minecraft:magma_block
setblock 306 178 234 minecraft:magma_block
fill 306 178 247 307 178 247 minecraft:shroomlight
setblock 306 178 248 minecraft:magma_block
setblock 306 178 254 minecraft:magma_block
fill 306 178 255 307 178 255 minecraft:shroomlight
setblock 306 178 267 minecraft:magma_block
fill 307 178 231 314 179 231 minecraft:basalt
fill 307 178 234 314 182 234 minecraft:basalt
setblock 307 178 246 minecraft:magma_block
fill 307 178 248 307 178 249 minecraft:shroomlight
fill 307 178 250 307 178 252 minecraft:magma_block
fill 307 178 253 307 178 254 minecraft:shroomlight
setblock 307 178 256 minecraft:magma_block
fill 307 178 267 314 183 267 minecraft:basalt
setblock 308 178 248 minecraft:magma_block
fill 308 178 249 308 178 253 minecraft:shroomlight
setblock 308 178 254 minecraft:magma_block
setblock 309 178 230 minecraft:magma_block
setblock 309 178 233 minecraft:magma_block
setblock 309 178 236 minecraft:magma_block
setblock 309 178 266 minecraft:magma_block
setblock 309 178 269 minecraft:magma_block
fill 310 178 230 315 178 230 minecraft:basalt
fill 310 178 233 317 179 233 minecraft:basalt
fill 310 178 236 317 182 236 minecraft:basalt
fill 310 178 266 317 182 266 minecraft:basalt
fill 310 178 269 317 179 269 minecraft:basalt
fill 311 178 237 314 184 237 minecraft:basalt
fill 311 178 265 311 187 265 minecraft:basalt
setblock 312 178 229 minecraft:magma_block
setblock 312 178 232 minecraft:magma_block
setblock 312 178 235 minecraft:magma_block
setblock 312 178 238 minecraft:magma_block
fill 312 178 264 314 186 264 minecraft:basalt
setblock 312 178 265 minecraft:magma_block
setblock 312 178 268 minecraft:magma_block
fill 313 178 229 314 178 229 minecraft:basalt
fill 313 178 232 318 178 232 minecraft:basalt
fill 313 178 235 320 179 235 minecraft:basalt
fill 313 178 238 317 183 239 minecraft:basalt
fill 313 178 263 317 184 263 minecraft:basalt
fill 313 178 265 320 180 265 minecraft:basalt
fill 313 178 268 320 178 268 minecraft:basalt
fill 314 178 240 314 188 240 minecraft:basalt
fill 314 178 262 320 182 262 minecraft:basalt
setblock 315 178 231 minecraft:magma_block
setblock 315 178 234 minecraft:magma_block
setblock 315 178 237 minecraft:magma_block
setblock 315 178 240 minecraft:magma_block
fill 315 178 241 320 183 241 minecraft:basalt
setblock 315 178 261 minecraft:magma_block
setblock 315 178 264 minecraft:magma_block
setblock 315 178 267 minecraft:magma_block
fill 316 178 231 317 178 231 minecraft:basalt
fill 316 178 234 320 178 234 minecraft:basalt
fill 316 178 237 322 178 237 minecraft:basalt
fill 316 178 240 323 179 240 minecraft:basalt
fill 316 178 242 317 186 242 minecraft:basalt
fill 316 178 260 317 186 261 minecraft:basalt
fill 316 178 264 323 178 264 minecraft:basalt
fill 316 178 267 321 178 267 minecraft:basalt
fill 317 178 243 320 184 244 minecraft:basalt
fill 317 178 258 320 184 259 minecraft:basalt
setblock 318 178 233 minecraft:magma_block
schedule function dropper:buildpart/54_2 1t
