fill 460 297 316 461 297 316 minecraft:gray_concrete
fill 464 297 279 464 297 280 minecraft:gray_concrete
fill 464 297 287 464 297 288 minecraft:gray_concrete
setblock 464 297 297 minecraft:gray_concrete
setblock 464 297 300 minecraft:gray_concrete
setblock 464 297 309 minecraft:gray_concrete
fill 424 298 281 424 300 281 minecraft:black_concrete
setblock 424 298 282 minecraft:gray_concrete
fill 424 298 283 424 300 283 minecraft:black_concrete
setblock 425 298 281 minecraft:gray_concrete
setblock 425 298 283 minecraft:gray_concrete
fill 426 298 281 426 300 281 minecraft:black_concrete
setblock 426 298 282 minecraft:gray_concrete
fill 426 298 283 426 300 283 minecraft:black_concrete
fill 424 299 282 424 300 282 minecraft:black_concrete
fill 425 299 281 425 300 281 minecraft:black_concrete
fill 425 299 283 425 300 283 minecraft:black_concrete
fill 426 299 282 426 300 282 minecraft:black_concrete
setblock 424 300 278 minecraft:gray_concrete
setblock 424 300 288 minecraft:gray_concrete
setblock 424 300 298 minecraft:gray_concrete
setblock 424 300 308 minecraft:gray_concrete
setblock 425 300 282 minecraft:black_concrete
setblock 426 300 316 minecraft:gray_concrete
setblock 430 300 276 minecraft:gray_concrete
setblock 436 300 316 minecraft:gray_concrete
setblock 440 300 276 minecraft:gray_concrete
setblock 446 300 316 minecraft:gray_concrete
setblock 450 300 276 minecraft:gray_concrete
setblock 456 300 316 minecraft:gray_concrete
setblock 460 300 276 minecraft:gray_concrete
setblock 464 300 282 minecraft:gray_concrete
setblock 464 300 292 minecraft:gray_concrete
setblock 464 300 302 minecraft:gray_concrete
setblock 464 300 312 minecraft:gray_concrete
setblock 426 301 278 minecraft:light[level=15]
setblock 426 301 285 minecraft:light[level=12]
setblock 426 301 286 minecraft:light[level=15]
setblock 426 301 292 minecraft:light[level=12]
setblock 426 301 294 minecraft:light[level=15]
setblock 426 301 299 minecraft:light[level=12]
setblock 426 301 302 minecraft:light[level=15]
setblock 426 301 306 minecraft:light[level=12]
setblock 426 301 310 minecraft:light[level=15]
setblock 426 301 313 minecraft:light[level=12]
setblock 433 301 278 minecraft:light[level=12]
setblock 433 301 285 minecraft:light[level=12]
setblock 433 301 292 minecraft:light[level=12]
setblock 433 301 299 minecraft:light[level=12]
setblock 433 301 306 minecraft:light[level=12]
setblock 433 301 313 minecraft:light[level=12]
setblock 434 301 278 minecraft:light[level=15]
setblock 434 301 286 minecraft:light[level=15]
setblock 434 301 294 minecraft:light[level=15]
setblock 434 301 302 minecraft:light[level=15]
setblock 434 301 310 minecraft:light[level=15]
setblock 440 301 278 minecraft:light[level=12]
setblock 440 301 285 minecraft:light[level=12]
setblock 440 301 292 minecraft:light[level=12]
setblock 440 301 299 minecraft:light[level=12]
setblock 440 301 306 minecraft:light[level=12]
setblock 440 301 313 minecraft:light[level=12]
setblock 442 301 278 minecraft:light[level=15]
setblock 442 301 286 minecraft:light[level=15]
setblock 442 301 294 minecraft:light[level=15]
setblock 442 301 302 minecraft:light[level=15]
setblock 442 301 310 minecraft:light[level=15]
setblock 447 301 278 minecraft:light[level=12]
setblock 447 301 285 minecraft:light[level=12]
setblock 447 301 292 minecraft:light[level=12]
setblock 447 301 299 minecraft:light[level=12]
setblock 447 301 306 minecraft:light[level=12]
setblock 447 301 313 minecraft:light[level=12]
setblock 450 301 278 minecraft:light[level=15]
setblock 450 301 286 minecraft:light[level=15]
setblock 450 301 294 minecraft:light[level=15]
setblock 450 301 302 minecraft:light[level=15]
setblock 450 301 310 minecraft:light[level=15]
setblock 454 301 278 minecraft:light[level=12]
setblock 454 301 285 minecraft:light[level=12]
setblock 454 301 292 minecraft:light[level=12]
setblock 454 301 299 minecraft:light[level=12]
setblock 454 301 306 minecraft:light[level=12]
setblock 454 301 313 minecraft:light[level=12]
setblock 458 301 278 minecraft:light[level=15]
setblock 458 301 286 minecraft:light[level=15]
setblock 458 301 294 minecraft:light[level=15]
setblock 458 301 302 minecraft:light[level=15]
setblock 458 301 310 minecraft:light[level=15]
setblock 461 301 278 minecraft:light[level=12]
setblock 461 301 285 minecraft:light[level=12]
setblock 461 301 292 minecraft:light[level=12]
setblock 461 301 299 minecraft:light[level=12]
setblock 461 301 306 minecraft:light[level=12]
setblock 461 301 313 minecraft:light[level=12]
