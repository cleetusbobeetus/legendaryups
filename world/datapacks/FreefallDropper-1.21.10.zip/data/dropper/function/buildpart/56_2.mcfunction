setblock 398 195 264 minecraft:bone_block
setblock 399 195 249 minecraft:bone_block
setblock 399 195 263 minecraft:bone_block
setblock 400 195 250 minecraft:bone_block
setblock 400 195 262 minecraft:bone_block
fill 401 195 251 401 195 252 minecraft:bone_block
fill 401 195 260 401 195 261 minecraft:bone_block
fill 402 195 253 402 195 259 minecraft:bone_block
fill 403 195 253 416 200 253 minecraft:brown_terracotta
fill 403 195 259 416 200 259 minecraft:brown_terracotta
fill 418 195 260 418 200 261 minecraft:green_terracotta
fill 418 195 262 418 195 263 minecraft:oak_leaves[persistent=true]
fill 418 195 264 418 229 264 minecraft:green_terracotta
setblock 418 195 266 minecraft:jungle_leaves[persistent=true]
fill 376 196 258 376 229 259 minecraft:green_terracotta
setblock 376 196 260 minecraft:jungle_leaves[persistent=true]
fill 376 196 261 376 218 261 minecraft:green_terracotta
fill 380 196 253 380 198 259 minecraft:brown_concrete
fill 381 196 251 381 196 252 minecraft:brown_concrete
fill 381 196 260 381 196 261 minecraft:brown_concrete
fill 381 196 270 381 204 270 minecraft:green_terracotta
fill 382 196 230 382 200 248 minecraft:brown_terracotta
fill 382 196 249 382 196 250 minecraft:brown_concrete
fill 382 196 262 382 196 263 minecraft:brown_concrete
fill 382 196 264 382 200 268 minecraft:brown_terracotta
fill 383 196 230 383 200 247 minecraft:brown_terracotta
fill 383 196 248 383 198 248 minecraft:brown_concrete
fill 383 196 264 383 198 264 minecraft:brown_concrete
fill 383 196 265 383 200 268 minecraft:brown_terracotta
fill 384 196 230 384 200 246 minecraft:brown_terracotta
fill 384 196 247 385 196 247 minecraft:brown_concrete
fill 384 196 265 385 196 265 minecraft:brown_concrete
fill 384 196 266 384 200 268 minecraft:brown_terracotta
fill 385 196 228 386 203 228 minecraft:green_terracotta
fill 386 196 246 387 196 246 minecraft:brown_concrete
fill 386 196 266 387 196 266 minecraft:brown_concrete
fill 388 196 245 394 198 245 minecraft:brown_concrete
fill 388 196 264 388 198 264 minecraft:dirt
fill 388 196 267 394 198 267 minecraft:brown_concrete
fill 389 196 261 390 198 261 minecraft:dirt
fill 391 196 264 391 198 264 minecraft:dirt
fill 395 196 246 396 196 246 minecraft:brown_concrete
fill 395 196 266 396 196 266 minecraft:brown_concrete
fill 397 196 247 398 196 247 minecraft:brown_concrete
fill 397 196 265 398 196 265 minecraft:brown_concrete
fill 399 196 247 416 200 247 minecraft:brown_terracotta
fill 399 196 248 399 198 248 minecraft:brown_concrete
fill 399 196 264 399 198 264 minecraft:brown_concrete
fill 399 196 265 416 200 265 minecraft:brown_terracotta
fill 399 196 270 402 198 270 minecraft:green_terracotta
fill 400 196 248 416 200 248 minecraft:brown_terracotta
fill 400 196 249 400 196 250 minecraft:brown_concrete
fill 400 196 262 400 196 263 minecraft:brown_concrete
fill 400 196 264 416 200 264 minecraft:brown_terracotta
fill 401 196 249 416 200 249 minecraft:brown_terracotta
fill 401 196 251 401 196 252 minecraft:brown_concrete
fill 401 196 260 401 196 261 minecraft:brown_concrete
fill 401 196 263 416 200 263 minecraft:brown_terracotta
fill 402 196 253 402 198 259 minecraft:brown_concrete
setblock 403 196 270 minecraft:jungle_leaves[persistent=true]
fill 404 196 270 404 227 270 minecraft:green_terracotta
fill 418 196 262 418 205 263 minecraft:green_terracotta
fill 418 196 266 418 201 266 minecraft:green_terracotta
setblock 376 197 231 minecraft:jungle_leaves[persistent=true]
fill 376 197 260 376 225 260 minecraft:green_terracotta
fill 380 197 230 380 199 251 minecraft:brown_terracotta
fill 380 197 252 380 198 252 minecraft:brown_concrete
fill 380 197 260 380 198 260 minecraft:brown_concrete
fill 380 197 261 380 199 268 minecraft:brown_terracotta
fill 381 197 230 381 200 249 minecraft:brown_terracotta
fill 381 197 250 381 198 251 minecraft:brown_concrete
fill 381 197 261 381 198 262 minecraft:brown_concrete
fill 381 197 263 381 200 268 minecraft:brown_terracotta
fill 382 197 249 382 198 249 minecraft:brown_concrete
fill 382 197 263 382 198 263 minecraft:brown_concrete
fill 384 197 247 384 198 247 minecraft:brown_concrete
fill 384 197 265 384 198 265 minecraft:brown_concrete
fill 385 197 230 385 202 245 minecraft:brown_terracotta
fill 385 197 246 386 198 246 minecraft:brown_concrete
fill 385 197 266 386 198 266 minecraft:brown_concrete
fill 385 197 267 385 202 268 minecraft:brown_terracotta
fill 387 197 230 387 202 244 minecraft:brown_terracotta
fill 387 197 245 387 198 245 minecraft:brown_concrete
fill 387 197 262 387 198 263 minecraft:dirt
fill 387 197 267 387 198 267 minecraft:brown_concrete
fill 387 197 268 387 202 268 minecraft:brown_terracotta
fill 388 197 261 388 198 261 minecraft:dirt
fill 389 197 265 390 198 265 minecraft:dirt
fill 391 197 261 391 198 261 minecraft:dirt
setblock 392 197 228 minecraft:green_concrete
fill 392 197 263 392 198 263 minecraft:dirt
fill 395 197 245 395 198 245 minecraft:brown_concrete
fill 395 197 267 395 198 267 minecraft:brown_concrete
fill 396 197 245 416 199 245 minecraft:brown_terracotta
fill 396 197 246 397 198 246 minecraft:brown_concrete
fill 396 197 266 397 198 266 minecraft:brown_concrete
fill 396 197 267 416 199 267 minecraft:brown_terracotta
fill 398 197 246 416 200 246 minecraft:brown_terracotta
fill 398 197 247 398 198 247 minecraft:brown_concrete
fill 398 197 265 398 198 265 minecraft:brown_concrete
fill 398 197 266 416 200 266 minecraft:brown_terracotta
fill 400 197 249 400 198 249 minecraft:brown_concrete
fill 400 197 263 400 198 263 minecraft:brown_concrete
fill 401 197 250 401 198 251 minecraft:brown_concrete
fill 401 197 261 401 198 262 minecraft:brown_concrete
fill 402 197 250 416 202 250 minecraft:brown_terracotta
fill 402 197 252 402 198 252 minecraft:brown_concrete
fill 402 197 260 402 198 260 minecraft:brown_concrete
fill 402 197 262 416 202 262 minecraft:brown_terracotta
fill 403 197 252 416 202 252 minecraft:brown_terracotta
fill 403 197 260 416 202 260 minecraft:brown_terracotta
fill 403 197 270 403 200 270 minecraft:green_terracotta
fill 407 197 270 407 203 270 minecraft:green_terracotta
setblock 408 197 270 minecraft:mossy_cobblestone
setblock 418 197 258 minecraft:green_concrete
setblock 376 198 231 minecraft:green_terracotta
setblock 386 198 252 minecraft:light[level=12]
setblock 386 198 259 minecraft:light[level=12]
setblock 387 198 247 minecraft:light[level=15]
setblock 387 198 255 minecraft:light[level=15]
setblock 387 198 261 minecraft:dirt
setblock 387 198 264 minecraft:dirt
setblock 388 198 265 minecraft:dirt
fill 389 198 260 390 198 260 minecraft:dirt
setblock 391 198 265 minecraft:dirt
fill 392 198 228 392 222 228 minecraft:green_terracotta
setblock 392 198 262 minecraft:dirt
setblock 392 198 264 minecraft:dirt
setblock 393 198 252 minecraft:light[level=12]
setblock 393 198 259 minecraft:light[level=12]
setblock 393 198 266 minecraft:light[level=12]
setblock 395 198 247 minecraft:light[level=15]
setblock 395 198 263 minecraft:light[level=15]
setblock 400 198 252 minecraft:light[level=12]
setblock 400 198 259 minecraft:light[level=12]
fill 408 198 270 408 204 270 minecraft:green_terracotta
fill 418 198 258 418 205 258 minecraft:green_terracotta
setblock 376 199 231 minecraft:mossy_cobblestone
fill 378 199 230 378 204 268 minecraft:brown_terracotta
fill 379 199 230 379 199 254 minecraft:brown_terracotta
fill 379 199 255 379 199 257 minecraft:bone_block
fill 379 199 258 379 199 268 minecraft:brown_terracotta
fill 380 199 252 380 199 254 minecraft:bone_block
fill 380 199 258 380 199 260 minecraft:bone_block
fill 381 199 250 381 199 251 minecraft:bone_block
fill 381 199 261 381 199 262 minecraft:bone_block
setblock 382 199 249 minecraft:bone_block
setblock 382 199 263 minecraft:bone_block
setblock 383 199 248 minecraft:bone_block
setblock 383 199 264 minecraft:bone_block
setblock 384 199 247 minecraft:bone_block
setblock 384 199 265 minecraft:bone_block
fill 385 199 246 386 199 246 minecraft:bone_block
fill 385 199 266 386 199 266 minecraft:bone_block
fill 387 199 245 389 199 245 minecraft:bone_block
fill 387 199 267 389 199 267 minecraft:bone_block
fill 389 199 263 389 201 263 minecraft:jungle_log
fill 390 199 230 416 204 243 minecraft:brown_terracotta
fill 390 199 244 392 199 244 minecraft:bone_block
fill 390 199 268 392 199 268 minecraft:bone_block
fill 393 199 244 416 199 244 minecraft:brown_terracotta
fill 393 199 245 395 199 245 minecraft:bone_block
fill 393 199 267 395 199 267 minecraft:bone_block
fill 393 199 268 416 199 268 minecraft:brown_terracotta
fill 396 199 246 397 199 246 minecraft:bone_block
fill 396 199 266 397 199 266 minecraft:bone_block
setblock 398 199 247 minecraft:bone_block
setblock 398 199 265 minecraft:bone_block
setblock 399 199 248 minecraft:bone_block
setblock 399 199 264 minecraft:bone_block
setblock 399 199 270 minecraft:moss_block
setblock 400 199 249 minecraft:bone_block
setblock 400 199 263 minecraft:bone_block
fill 400 199 270 402 225 270 minecraft:green_terracotta
fill 401 199 250 401 199 251 minecraft:bone_block
fill 401 199 261 401 199 262 minecraft:bone_block
fill 402 199 252 402 199 254 minecraft:bone_block
fill 402 199 258 402 199 260 minecraft:bone_block
fill 403 199 255 403 199 257 minecraft:bone_block
fill 404 199 255 416 204 257 minecraft:brown_terracotta
setblock 418 199 231 minecraft:mossy_cobblestone
setblock 418 199 259 minecraft:mossy_cobblestone
fill 376 200 231 376 217 231 minecraft:green_terracotta
setblock 376 200 247 minecraft:moss_block
fill 379 200 230 379 200 253 minecraft:brown_terracotta
fill 379 200 254 379 202 258 minecraft:brown_concrete
fill 379 200 259 379 200 268 minecraft:brown_terracotta
setblock 380 200 228 minecraft:jungle_leaves[persistent=true]
fill 380 200 230 380 202 250 minecraft:brown_terracotta
fill 380 200 251 380 200 253 minecraft:brown_concrete
fill 380 200 259 380 200 261 minecraft:brown_concrete
fill 380 200 262 380 202 268 minecraft:brown_terracotta
fill 381 200 250 381 202 250 minecraft:brown_concrete
fill 381 200 262 381 202 262 minecraft:brown_concrete
setblock 382 200 249 minecraft:brown_concrete
setblock 382 200 263 minecraft:brown_concrete
setblock 383 200 248 minecraft:brown_concrete
setblock 383 200 264 minecraft:brown_concrete
setblock 384 200 247 minecraft:brown_concrete
setblock 384 200 265 minecraft:brown_concrete
fill 385 200 246 385 202 246 minecraft:brown_concrete
fill 385 200 266 385 202 266 minecraft:brown_concrete
fill 386 200 230 386 204 244 minecraft:brown_terracotta
fill 386 200 245 388 200 245 minecraft:brown_concrete
fill 386 200 267 388 200 267 minecraft:brown_concrete
fill 386 200 268 386 204 268 minecraft:brown_terracotta
fill 389 200 230 389 205 243 minecraft:brown_terracotta
fill 389 200 244 393 202 244 minecraft:brown_concrete
fill 389 200 268 393 202 268 minecraft:brown_concrete
fill 394 200 244 416 200 244 minecraft:brown_terracotta
fill 394 200 245 396 200 245 minecraft:brown_concrete
fill 394 200 267 396 200 267 minecraft:brown_concrete
fill 394 200 268 416 200 268 minecraft:brown_terracotta
fill 397 200 245 416 202 245 minecraft:brown_terracotta
fill 397 200 246 397 202 246 minecraft:brown_concrete
fill 397 200 266 397 202 266 minecraft:brown_concrete
fill 397 200 267 416 202 267 minecraft:brown_terracotta
setblock 398 200 247 minecraft:brown_concrete
setblock 398 200 265 minecraft:brown_concrete
setblock 399 200 248 minecraft:brown_concrete
setblock 399 200 264 minecraft:brown_concrete
fill 399 200 270 399 226 270 minecraft:green_terracotta
setblock 400 200 249 minecraft:brown_concrete
setblock 400 200 263 minecraft:brown_concrete
fill 401 200 250 401 202 250 minecraft:brown_concrete
fill 401 200 262 401 202 262 minecraft:brown_concrete
fill 402 200 251 402 200 253 minecraft:brown_concrete
fill 402 200 259 402 200 261 minecraft:brown_concrete
fill 403 200 251 416 204 251 minecraft:brown_terracotta
fill 403 200 254 403 202 258 minecraft:brown_concrete
fill 403 200 261 416 204 261 minecraft:brown_terracotta
setblock 404 200 228 minecraft:green_concrete
fill 404 200 254 416 205 254 minecraft:brown_terracotta
fill 404 200 258 416 205 258 minecraft:brown_terracotta
setblock 417 200 228 minecraft:jungle_leaves[persistent=true]
fill 418 200 231 418 223 231 minecraft:green_terracotta
fill 418 200 259 418 204 259 minecraft:green_terracotta
fill 376 201 247 376 226 247 minecraft:green_terracotta
fill 379 201 230 379 202 252 minecraft:brown_terracotta
fill 379 201 253 379 202 253 minecraft:brown_concrete
fill 379 201 259 379 202 259 minecraft:brown_concrete
fill 379 201 260 379 202 268 minecraft:brown_terracotta
fill 380 201 228 380 204 228 minecraft:green_terracotta
fill 380 201 251 380 202 252 minecraft:brown_concrete
fill 380 201 260 380 202 261 minecraft:brown_concrete
fill 381 201 230 381 204 248 minecraft:brown_terracotta
fill 381 201 249 381 202 249 minecraft:brown_concrete
fill 381 201 263 381 202 263 minecraft:brown_concrete
fill 381 201 264 381 204 268 minecraft:brown_terracotta
fill 382 201 230 382 204 247 minecraft:brown_terracotta
fill 382 201 248 382 202 248 minecraft:brown_concrete
fill 382 201 264 382 202 264 minecraft:brown_concrete
fill 382 201 265 382 204 268 minecraft:brown_terracotta
fill 383 201 230 383 204 246 minecraft:brown_terracotta
fill 383 201 247 383 202 247 minecraft:brown_concrete
fill 383 201 265 383 202 265 minecraft:brown_concrete
fill 383 201 266 383 204 268 minecraft:brown_terracotta
fill 384 201 230 384 205 245 minecraft:brown_terracotta
fill 384 201 246 384 202 246 minecraft:brown_concrete
fill 384 201 266 384 202 266 minecraft:brown_concrete
fill 384 201 267 384 205 268 minecraft:brown_terracotta
fill 386 201 245 387 202 245 minecraft:brown_concrete
fill 386 201 267 387 202 267 minecraft:brown_concrete
fill 388 201 230 388 206 243 minecraft:brown_terracotta
fill 388 201 244 388 202 244 minecraft:brown_concrete
fill 388 201 268 388 202 268 minecraft:brown_concrete
fill 394 201 244 394 202 244 minecraft:brown_concrete
fill 394 201 268 394 202 268 minecraft:brown_concrete
fill 395 201 244 416 202 244 minecraft:brown_terracotta
fill 395 201 245 396 202 245 minecraft:brown_concrete
fill 395 201 267 396 202 267 minecraft:brown_concrete
fill 395 201 268 416 202 268 minecraft:brown_terracotta
setblock 398 201 228 minecraft:jungle_leaves[persistent=true]
fill 398 201 246 398 202 246 minecraft:brown_concrete
fill 398 201 266 398 202 266 minecraft:brown_concrete
fill 399 201 246 416 204 246 minecraft:brown_terracotta
fill 399 201 247 399 202 247 minecraft:brown_concrete
fill 399 201 265 399 202 265 minecraft:brown_concrete
fill 399 201 266 416 204 266 minecraft:brown_terracotta
fill 400 201 247 416 204 247 minecraft:brown_terracotta
fill 400 201 248 400 202 248 minecraft:brown_concrete
fill 400 201 264 400 202 264 minecraft:brown_concrete
fill 400 201 265 416 204 265 minecraft:brown_terracotta
fill 401 201 248 416 204 248 minecraft:brown_terracotta
fill 401 201 249 401 202 249 minecraft:brown_concrete
fill 401 201 263 401 202 263 minecraft:brown_concrete
fill 401 201 264 416 204 264 minecraft:brown_terracotta
fill 402 201 249 416 205 249 minecraft:brown_terracotta
fill 402 201 251 402 202 252 minecraft:brown_concrete
fill 402 201 260 402 202 261 minecraft:brown_concrete
fill 402 201 263 416 205 263 minecraft:brown_terracotta
fill 403 201 253 403 202 253 minecraft:brown_concrete
fill 403 201 259 403 202 259 minecraft:brown_concrete
setblock 403 201 270 minecraft:jungle_leaves[persistent=true]
fill 404 201 228 404 229 228 minecraft:green_terracotta
fill 404 201 253 416 206 253 minecraft:brown_terracotta
fill 404 201 259 416 206 259 minecraft:brown_terracotta
setblock 409 201 270 minecraft:green_concrete
fill 417 201 228 417 204 228 minecraft:green_terracotta
fill 418 201 251 418 229 251 minecraft:green_terracotta
setblock 418 201 252 minecraft:green_concrete
fill 418 201 253 418 228 253 minecraft:green_terracotta
setblock 418 201 260 minecraft:green_concrete
fill 418 201 261 418 204 261 minecraft:green_terracotta
fill 388 202 262 390 204 264 minecraft:jungle_leaves[persistent=true]
fill 389 202 261 390 204 261 minecraft:jungle_leaves[persistent=true]
fill 391 202 262 391 204 263 minecraft:jungle_leaves[persistent=true]
fill 398 202 228 398 225 228 minecraft:green_terracotta
fill 403 202 270 403 225 270 minecraft:green_terracotta
fill 409 202 270 409 204 270 minecraft:green_terracotta
fill 418 202 252 418 227 252 minecraft:green_terracotta
fill 418 202 260 418 203 260 minecraft:green_terracotta
setblock 418 202 266 minecraft:moss_block
fill 379 203 230 379 204 251 minecraft:brown_terracotta
fill 379 203 252 379 203 260 minecraft:bone_block
fill 379 203 261 379 204 268 minecraft:brown_terracotta
fill 380 203 230 380 205 249 minecraft:brown_terracotta
fill 380 203 250 380 203 251 minecraft:bone_block
fill 380 203 261 380 203 262 minecraft:bone_block
fill 380 203 263 380 205 268 minecraft:brown_terracotta
setblock 381 203 249 minecraft:bone_block
setblock 381 203 263 minecraft:bone_block
setblock 382 203 248 minecraft:bone_block
setblock 382 203 264 minecraft:bone_block
setblock 383 203 247 minecraft:bone_block
setblock 383 203 265 minecraft:bone_block
setblock 384 203 246 minecraft:bone_block
setblock 384 203 266 minecraft:bone_block
fill 385 203 230 385 207 244 minecraft:brown_terracotta
fill 385 203 245 386 203 245 minecraft:bone_block
fill 385 203 267 386 203 267 minecraft:bone_block
fill 385 203 268 385 207 268 minecraft:brown_terracotta
fill 387 203 230 387 208 243 minecraft:brown_terracotta
fill 387 203 244 395 203 244 minecraft:bone_block
fill 387 203 268 395 203 268 minecraft:bone_block
setblock 388 203 261 minecraft:jungle_leaves[persistent=true]
fill 389 203 265 390 203 265 minecraft:jungle_leaves[persistent=true]
setblock 391 203 261 minecraft:jungle_leaves[persistent=true]
setblock 391 203 264 minecraft:jungle_leaves[persistent=true]
fill 396 203 244 416 204 244 minecraft:brown_terracotta
fill 396 203 245 397 203 245 minecraft:bone_block
fill 396 203 267 397 203 267 minecraft:bone_block
fill 396 203 268 416 204 268 minecraft:brown_terracotta
fill 398 203 245 416 205 245 minecraft:brown_terracotta
setblock 398 203 246 minecraft:bone_block
setblock 398 203 266 minecraft:bone_block
fill 398 203 267 416 205 267 minecraft:brown_terracotta
setblock 399 203 247 minecraft:bone_block
setblock 399 203 265 minecraft:bone_block
setblock 400 203 248 minecraft:bone_block
setblock 400 203 264 minecraft:bone_block
setblock 401 203 249 minecraft:bone_block
setblock 401 203 263 minecraft:bone_block
fill 402 203 250 402 203 251 minecraft:bone_block
fill 402 203 261 402 203 262 minecraft:bone_block
fill 403 203 250 416 207 250 minecraft:brown_terracotta
fill 403 203 252 403 203 260 minecraft:bone_block
fill 403 203 262 416 207 262 minecraft:brown_terracotta
fill 404 203 252 416 208 252 minecraft:brown_terracotta
fill 404 203 260 416 208 260 minecraft:brown_terracotta
setblock 418 203 234 minecraft:moss_block
fill 418 203 235 418 217 235 minecraft:green_terracotta
setblock 418 203 245 minecraft:jungle_leaves[persistent=true]
fill 418 203 266 418 217 266 minecraft:green_terracotta
fill 379 204 252 379 204 260 minecraft:brown_concrete
fill 380 204 250 380 204 251 minecraft:brown_concrete
fill 380 204 261 380 204 262 minecraft:brown_concrete
fill 381 204 249 381 205 249 minecraft:brown_concrete
fill 381 204 263 381 205 263 minecraft:brown_concrete
setblock 382 204 248 minecraft:brown_concrete
setblock 382 204 264 minecraft:brown_concrete
setblock 383 204 247 minecraft:brown_concrete
setblock 383 204 265 minecraft:brown_concrete
fill 384 204 246 384 205 246 minecraft:brown_concrete
fill 384 204 266 384 205 266 minecraft:brown_concrete
fill 385 204 228 385 211 228 minecraft:green_terracotta
fill 385 204 245 386 204 245 minecraft:brown_concrete
fill 385 204 267 386 204 267 minecraft:brown_concrete
setblock 386 204 228 minecraft:green_concrete
setblock 386 204 252 minecraft:light[level=12]
setblock 386 204 259 minecraft:light[level=12]
setblock 386 204 266 minecraft:light[level=12]
fill 387 204 244 395 204 244 minecraft:brown_concrete
fill 387 204 268 395 204 268 minecraft:brown_concrete
setblock 393 204 245 minecraft:light[level=12]
setblock 393 204 252 minecraft:light[level=12]
setblock 393 204 259 minecraft:light[level=12]
setblock 393 204 266 minecraft:light[level=12]
fill 396 204 245 397 204 245 minecraft:brown_concrete
fill 396 204 267 397 204 267 minecraft:brown_concrete
fill 398 204 246 398 205 246 minecraft:brown_concrete
fill 398 204 266 398 205 266 minecraft:brown_concrete
setblock 399 204 247 minecraft:brown_concrete
setblock 399 204 265 minecraft:brown_concrete
setblock 400 204 248 minecraft:brown_concrete
setblock 400 204 252 minecraft:light[level=12]
setblock 400 204 259 minecraft:light[level=12]
setblock 400 204 264 minecraft:brown_concrete
fill 401 204 249 401 205 249 minecraft:brown_concrete
fill 401 204 263 401 205 263 minecraft:brown_concrete
fill 402 204 250 402 204 251 minecraft:brown_concrete
fill 402 204 261 402 204 262 minecraft:brown_concrete
fill 403 204 252 403 204 260 minecraft:brown_concrete
setblock 405 204 228 minecraft:moss_block
fill 407 204 270 407 208 270 minecraft:oak_leaves[persistent=true]
fill 418 204 234 418 217 234 minecraft:green_terracotta
fill 418 204 245 418 216 245 minecraft:green_terracotta
fill 418 204 260 418 209 260 minecraft:jungle_leaves[persistent=true]
setblock 376 205 253 minecraft:jungle_leaves[persistent=true]
setblock 376 205 266 minecraft:jungle_log
fill 378 205 228 378 229 228 minecraft:green_terracotta
fill 378 205 230 378 205 254 minecraft:brown_terracotta
fill 378 205 255 378 206 257 minecraft:brown_concrete
fill 378 205 258 378 205 268 minecraft:brown_terracotta
fill 379 205 228 380 205 228 minecraft:jungle_log
fill 379 205 230 379 207 250 minecraft:brown_terracotta
fill 379 205 251 379 205 254 minecraft:brown_concrete
setblock 379 205 255 minecraft:light[level=15]
fill 379 205 258 379 205 261 minecraft:brown_concrete
fill 379 205 262 379 207 268 minecraft:brown_terracotta
fill 380 205 250 380 206 250 minecraft:brown_concrete
fill 380 205 262 380 206 262 minecraft:brown_concrete
fill 380 205 270 381 206 270 minecraft:jungle_log
fill 381 205 230 381 209 247 minecraft:brown_terracotta
fill 381 205 248 381 206 248 minecraft:brown_concrete
fill 381 205 264 381 206 264 minecraft:brown_concrete
fill 381 205 265 381 209 268 minecraft:brown_terracotta
fill 382 205 230 382 209 246 minecraft:brown_terracotta
fill 382 205 247 382 206 247 minecraft:brown_concrete
fill 382 205 264 382 226 264 minecraft:jungle_log
fill 382 205 265 382 206 265 minecraft:brown_concrete
fill 382 205 266 382 209 268 minecraft:brown_terracotta
fill 383 205 230 383 209 245 minecraft:brown_terracotta
fill 383 205 246 383 206 246 minecraft:brown_concrete
fill 383 205 265 383 226 265 minecraft:jungle_log
fill 383 205 266 383 206 266 minecraft:brown_concrete
fill 383 205 267 383 209 268 minecraft:brown_terracotta
fill 385 205 245 385 206 245 minecraft:brown_concrete
fill 385 205 267 385 206 267 minecraft:brown_concrete
fill 386 205 228 386 213 228 minecraft:green_terracotta
fill 386 205 230 386 210 243 minecraft:brown_terracotta
fill 386 205 244 389 205 244 minecraft:brown_concrete
fill 386 205 268 389 205 268 minecraft:brown_concrete
setblock 387 205 247 minecraft:light[level=15]
setblock 387 205 255 minecraft:light[level=15]
setblock 387 205 263 minecraft:light[level=15]
fill 390 205 230 416 210 242 minecraft:brown_terracotta
fill 390 205 243 392 206 243 minecraft:brown_concrete
fill 393 205 243 416 205 243 minecraft:brown_terracotta
fill 393 205 244 396 205 244 minecraft:brown_concrete
fill 393 205 268 396 205 268 minecraft:brown_concrete
setblock 395 205 247 minecraft:light[level=15]
setblock 395 205 263 minecraft:light[level=15]
fill 397 205 244 416 207 244 minecraft:brown_terracotta
fill 397 205 245 397 206 245 minecraft:brown_concrete
fill 397 205 267 397 206 267 minecraft:brown_concrete
fill 397 205 268 416 207 268 minecraft:brown_terracotta
fill 399 205 246 399 206 246 minecraft:brown_concrete
fill 399 205 266 399 206 266 minecraft:brown_concrete
fill 400 205 246 416 209 246 minecraft:brown_terracotta
fill 400 205 247 400 206 247 minecraft:brown_concrete
fill 400 205 265 400 206 265 minecraft:brown_concrete
fill 400 205 266 416 209 266 minecraft:brown_terracotta
fill 401 205 247 416 209 247 minecraft:brown_terracotta
fill 401 205 248 401 206 248 minecraft:brown_concrete
fill 401 205 264 401 206 264 minecraft:brown_concrete
fill 401 205 265 416 209 265 minecraft:brown_terracotta
fill 402 205 248 416 209 248 minecraft:brown_terracotta
fill 402 205 250 402 206 250 minecraft:brown_concrete
fill 402 205 262 402 206 262 minecraft:brown_concrete
fill 402 205 264 416 209 264 minecraft:brown_terracotta
fill 403 205 251 403 205 254 minecraft:brown_concrete
setblock 403 205 255 minecraft:light[level=15]
fill 403 205 258 403 205 261 minecraft:brown_concrete
fill 404 205 251 416 210 251 minecraft:brown_terracotta
fill 404 205 255 404 206 257 minecraft:brown_concrete
fill 404 205 261 416 210 261 minecraft:brown_terracotta
fill 405 205 228 405 212 228 minecraft:green_terracotta
fill 405 205 255 416 210 257 minecraft:brown_terracotta
fill 408 205 270 409 208 270 minecraft:oak_leaves[persistent=true]
setblock 410 205 228 minecraft:jungle_leaves[persistent=true]
fill 414 205 228 414 229 228 minecraft:green_terracotta
fill 415 205 228 416 205 228 minecraft:jungle_log
fill 417 205 228 418 208 228 minecraft:jungle_leaves[persistent=true]
fill 418 205 247 418 229 247 minecraft:green_terracotta
setblock 418 205 248 minecraft:moss_block
fill 418 205 249 418 226 249 minecraft:green_terracotta
fill 418 205 259 418 208 259 minecraft:jungle_leaves[persistent=true]
fill 418 205 261 418 208 261 minecraft:jungle_leaves[persistent=true]
setblock 418 205 268 minecraft:jungle_log
setblock 376 206 235 minecraft:moss_block
fill 376 206 253 376 215 253 minecraft:green_terracotta
setblock 376 206 264 minecraft:moss_block
fill 376 206 265 376 229 265 minecraft:green_terracotta
setblock 376 206 266 minecraft:azalea_leaves[persistent=true]
setblock 376 206 267 minecraft:jungle_log
fill 376 206 268 376 225 268 minecraft:green_terracotta
fill 376 206 270 377 212 270 minecraft:green_terracotta
fill 378 206 230 378 206 253 minecraft:brown_terracotta
setblock 378 206 254 minecraft:brown_concrete
setblock 378 206 258 minecraft:brown_concrete
fill 378 206 259 378 206 268 minecraft:brown_terracotta
setblock 378 206 270 minecraft:mossy_cobblestone
setblock 379 206 228 minecraft:jungle_log
fill 379 206 251 379 206 253 minecraft:brown_concrete
fill 379 206 259 379 206 261 minecraft:brown_concrete
setblock 380 206 228 minecraft:jungle_leaves[persistent=true]
fill 380 206 230 380 209 248 minecraft:brown_terracotta
setblock 380 206 249 minecraft:brown_concrete
setblock 380 206 263 minecraft:brown_concrete
fill 380 206 264 380 209 268 minecraft:brown_terracotta
fill 381 206 263 381 226 263 minecraft:jungle_log
setblock 382 206 270 minecraft:jungle_log
fill 384 206 230 384 211 244 minecraft:brown_terracotta
setblock 384 206 245 minecraft:brown_concrete
setblock 384 206 267 minecraft:brown_concrete
fill 384 206 268 384 211 268 minecraft:brown_terracotta
fill 386 206 244 388 206 244 minecraft:brown_concrete
fill 386 206 268 388 206 268 minecraft:brown_concrete
fill 389 206 230 389 211 242 minecraft:brown_terracotta
setblock 389 206 243 minecraft:brown_concrete
setblock 393 206 243 minecraft:brown_concrete
fill 394 206 243 416 206 243 minecraft:brown_terracotta
fill 394 206 244 396 206 244 minecraft:brown_concrete
fill 394 206 268 396 206 268 minecraft:brown_concrete
setblock 398 206 245 minecraft:brown_concrete
setblock 398 206 267 minecraft:brown_concrete
fill 399 206 245 416 209 245 minecraft:brown_terracotta
fill 399 206 267 416 209 267 minecraft:brown_terracotta
setblock 402 206 249 minecraft:brown_concrete
setblock 402 206 263 minecraft:brown_concrete
fill 403 206 249 416 211 249 minecraft:brown_terracotta
fill 403 206 251 403 206 253 minecraft:brown_concrete
fill 403 206 259 403 206 261 minecraft:brown_concrete
fill 403 206 263 416 211 263 minecraft:brown_terracotta
setblock 404 206 254 minecraft:brown_concrete
setblock 404 206 258 minecraft:brown_concrete
fill 405 206 254 416 211 254 minecraft:brown_terracotta
fill 405 206 258 416 211 258 minecraft:brown_terracotta
fill 406 206 270 406 208 270 minecraft:oak_leaves[persistent=true]
fill 410 206 228 410 211 228 minecraft:green_terracotta
fill 410 206 270 410 207 270 minecraft:oak_leaves[persistent=true]
fill 411 206 270 411 226 270 minecraft:green_terracotta
setblock 415 206 228 minecraft:jungle_log
setblock 416 206 228 minecraft:jungle_leaves[persistent=true]
fill 418 206 248 418 207 248 minecraft:green_terracotta
fill 418 206 258 418 208 258 minecraft:jungle_leaves[persistent=true]
fill 418 206 262 418 208 262 minecraft:jungle_leaves[persistent=true]
setblock 418 206 263 minecraft:green_terracotta
fill 418 206 268 418 207 270 minecraft:jungle_leaves[persistent=true]
fill 376 207 235 376 229 235 minecraft:green_terracotta
fill 376 207 264 376 231 264 minecraft:green_terracotta
fill 376 207 266 376 229 266 minecraft:green_terracotta
setblock 376 207 267 minecraft:azalea_leaves[persistent=true]
fill 378 207 230 378 208 252 minecraft:brown_terracotta
fill 378 207 253 378 207 259 minecraft:bone_block
fill 378 207 260 378 208 268 minecraft:brown_terracotta
fill 378 207 269 387 210 269 minecraft:brown_concrete
fill 378 207 270 378 225 270 minecraft:green_terracotta
fill 379 207 228 380 229 228 minecraft:green_terracotta
fill 379 207 251 379 207 252 minecraft:bone_block
fill 379 207 260 379 207 261 minecraft:bone_block
fill 380 207 249 380 207 250 minecraft:bone_block
fill 380 207 262 380 207 263 minecraft:bone_block
fill 380 207 270 382 225 270 minecraft:green_terracotta
setblock 381 207 248 minecraft:bone_block
setblock 381 207 264 minecraft:bone_block
setblock 382 207 247 minecraft:bone_block
setblock 382 207 265 minecraft:bone_block
setblock 383 207 246 minecraft:bone_block
setblock 383 207 266 minecraft:bone_block
fill 384 207 245 385 207 245 minecraft:bone_block
fill 384 207 267 385 207 267 minecraft:bone_block
fill 386 207 244 387 207 244 minecraft:bone_block
fill 386 207 268 387 207 268 minecraft:bone_block
fill 388 207 230 388 212 242 minecraft:brown_terracotta
fill 388 207 243 394 207 243 minecraft:bone_block
fill 388 207 269 394 207 269 minecraft:bone_block
fill 395 207 243 416 208 243 minecraft:brown_terracotta
fill 395 207 244 396 207 244 minecraft:bone_block
fill 395 207 268 396 207 268 minecraft:bone_block
fill 395 207 269 417 210 269 minecraft:brown_concrete
fill 397 207 245 398 207 245 minecraft:bone_block
fill 397 207 267 398 207 267 minecraft:bone_block
setblock 399 207 246 minecraft:bone_block
setblock 399 207 266 minecraft:bone_block
setblock 400 207 247 minecraft:bone_block
setblock 400 207 265 minecraft:bone_block
setblock 401 207 248 minecraft:bone_block
setblock 401 207 264 minecraft:bone_block
fill 402 207 249 402 207 250 minecraft:bone_block
fill 402 207 262 402 207 263 minecraft:bone_block
fill 403 207 251 403 207 252 minecraft:bone_block
fill 403 207 260 403 207 261 minecraft:bone_block
fill 404 207 253 404 207 259 minecraft:bone_block
fill 405 207 253 416 212 253 minecraft:brown_terracotta
fill 405 207 259 416 212 259 minecraft:brown_terracotta
fill 415 207 228 416 210 228 minecraft:green_terracotta
setblock 418 207 263 minecraft:jungle_leaves[persistent=true]
fill 376 208 267 376 229 267 minecraft:green_terracotta
fill 378 208 253 378 210 259 minecraft:brown_concrete
fill 379 208 230 379 211 249 minecraft:brown_terracotta
fill 379 208 250 379 208 252 minecraft:brown_concrete
fill 379 208 260 379 208 262 minecraft:brown_concrete
fill 379 208 263 379 211 268 minecraft:brown_terracotta
fill 380 208 249 380 210 249 minecraft:brown_concrete
fill 380 208 263 380 210 263 minecraft:brown_concrete
fill 381 208 248 381 209 248 minecraft:brown_concrete
fill 381 208 264 381 209 264 minecraft:brown_concrete
fill 382 208 247 382 209 247 minecraft:brown_concrete
fill 382 208 265 382 209 265 minecraft:brown_concrete
fill 383 208 246 383 209 246 minecraft:brown_concrete
fill 383 208 266 383 209 266 minecraft:brown_concrete
fill 384 208 245 384 210 245 minecraft:brown_concrete
fill 384 208 267 384 210 267 minecraft:brown_concrete
fill 385 208 230 385 213 243 minecraft:brown_terracotta
fill 385 208 244 387 208 244 minecraft:brown_concrete
fill 385 208 268 387 208 268 minecraft:brown_concrete
fill 388 208 243 394 210 243 minecraft:brown_concrete
fill 388 208 269 394 210 269 minecraft:brown_concrete
fill 395 208 244 397 208 244 minecraft:brown_concrete
fill 395 208 268 397 208 268 minecraft:brown_concrete
setblock 396 208 228 minecraft:mossy_cobblestone
fill 398 208 244 416 211 244 minecraft:brown_terracotta
fill 398 208 245 398 210 245 minecraft:brown_concrete
fill 398 208 267 398 210 267 minecraft:brown_concrete
fill 398 208 268 416 211 268 minecraft:brown_terracotta
fill 399 208 246 399 209 246 minecraft:brown_concrete
fill 399 208 266 399 209 266 minecraft:brown_concrete
fill 400 208 247 400 209 247 minecraft:brown_concrete
fill 400 208 265 400 209 265 minecraft:brown_concrete
fill 401 208 248 401 209 248 minecraft:brown_concrete
fill 401 208 264 401 209 264 minecraft:brown_concrete
fill 402 208 249 402 210 249 minecraft:brown_concrete
fill 402 208 263 402 210 263 minecraft:brown_concrete
fill 403 208 250 403 208 252 minecraft:brown_concrete
fill 403 208 260 403 208 262 minecraft:brown_concrete
fill 404 208 250 416 213 250 minecraft:brown_terracotta
fill 404 208 253 404 210 259 minecraft:brown_concrete
fill 404 208 262 416 213 262 minecraft:brown_terracotta
fill 410 208 270 410 217 270 minecraft:green_terracotta
setblock 418 208 248 minecraft:mossy_cobblestone
setblock 418 208 250 minecraft:green_concrete
fill 418 208 263 418 227 263 minecraft:green_terracotta
fill 418 208 268 418 225 270 minecraft:green_terracotta
fill 378 209 230 378 210 251 minecraft:brown_terracotta
fill 378 209 252 378 210 252 minecraft:brown_concrete
fill 378 209 260 378 210 260 minecraft:brown_concrete
fill 378 209 261 378 210 268 minecraft:brown_terracotta
fill 379 209 250 379 210 251 minecraft:brown_concrete
fill 379 209 261 379 210 262 minecraft:brown_concrete
fill 385 209 244 386 210 244 minecraft:brown_concrete
fill 385 209 268 386 210 268 minecraft:brown_concrete
fill 387 209 230 387 214 242 minecraft:brown_terracotta
fill 387 209 243 387 210 243 minecraft:brown_concrete
setblock 392 209 270 minecraft:green_concrete
fill 395 209 243 395 210 243 minecraft:brown_concrete
fill 396 209 228 396 223 228 minecraft:green_terracotta
fill 396 209 243 416 210 243 minecraft:brown_terracotta
fill 396 209 244 397 210 244 minecraft:brown_concrete
fill 396 209 268 397 210 268 minecraft:brown_concrete
fill 403 209 250 403 210 251 minecraft:brown_concrete
fill 403 209 261 403 210 262 minecraft:brown_concrete
fill 404 209 252 404 210 252 minecraft:brown_concrete
fill 404 209 260 404 210 260 minecraft:brown_concrete
fill 405 209 252 416 214 252 minecraft:brown_terracotta
fill 405 209 260 416 214 260 minecraft:brown_terracotta
fill 406 209 270 409 216 270 minecraft:green_terracotta
fill 417 209 228 418 229 228 minecraft:green_terracotta
fill 418 209 248 418 225 248 minecraft:green_terracotta
fill 418 209 250 418 229 250 minecraft:green_terracotta
fill 418 209 258 418 218 259 minecraft:green_terracotta
fill 418 209 261 418 224 262 minecraft:green_terracotta
setblock 376 210 244 minecraft:jungle_leaves[persistent=true]
setblock 376 210 254 minecraft:jungle_leaves[persistent=true]
setblock 379 210 252 minecraft:light[level=12]
setblock 379 210 259 minecraft:light[level=12]
fill 380 210 230 380 213 247 minecraft:brown_terracotta
setblock 380 210 248 minecraft:brown_concrete
setblock 380 210 264 minecraft:brown_concrete
fill 380 210 265 380 213 268 minecraft:brown_terracotta
fill 381 210 230 381 213 246 minecraft:brown_terracotta
setblock 381 210 247 minecraft:brown_concrete
fill 381 210 264 381 226 264 minecraft:jungle_log
setblock 381 210 265 minecraft:brown_concrete
fill 381 210 266 381 213 268 minecraft:brown_terracotta
fill 382 210 230 382 213 245 minecraft:brown_terracotta
setblock 382 210 246 minecraft:brown_concrete
fill 382 210 265 382 226 265 minecraft:jungle_log
setblock 382 210 266 minecraft:brown_concrete
fill 382 210 267 382 213 268 minecraft:brown_terracotta
fill 383 210 230 383 214 244 minecraft:brown_terracotta
setblock 383 210 245 minecraft:brown_concrete
fill 383 210 266 383 226 266 minecraft:jungle_log
setblock 383 210 267 minecraft:brown_concrete
fill 383 210 268 383 214 268 minecraft:brown_terracotta
setblock 386 210 245 minecraft:light[level=12]
setblock 386 210 252 minecraft:light[level=12]
setblock 386 210 259 minecraft:light[level=12]
setblock 386 210 266 minecraft:light[level=12]
fill 392 210 270 392 229 270 minecraft:green_terracotta
setblock 393 210 245 minecraft:light[level=12]
setblock 393 210 252 minecraft:light[level=12]
setblock 393 210 259 minecraft:light[level=12]
setblock 393 210 266 minecraft:light[level=12]
setblock 396 210 270 minecraft:moss_block
setblock 399 210 245 minecraft:brown_concrete
setblock 399 210 267 minecraft:brown_concrete
fill 400 210 245 416 213 245 minecraft:brown_terracotta
setblock 400 210 246 minecraft:brown_concrete
setblock 400 210 252 minecraft:light[level=12]
setblock 400 210 259 minecraft:light[level=12]
setblock 400 210 266 minecraft:brown_concrete
fill 400 210 267 416 213 267 minecraft:brown_terracotta
fill 401 210 246 416 213 246 minecraft:brown_terracotta
setblock 401 210 247 minecraft:brown_concrete
setblock 401 210 265 minecraft:brown_concrete
fill 401 210 266 416 213 266 minecraft:brown_terracotta
fill 402 210 247 416 213 247 minecraft:brown_terracotta
setblock 402 210 248 minecraft:brown_concrete
setblock 402 210 264 minecraft:brown_concrete
fill 402 210 265 416 213 265 minecraft:brown_terracotta
fill 403 210 248 416 214 248 minecraft:brown_terracotta
fill 403 210 264 416 214 264 minecraft:brown_terracotta
fill 418 210 254 418 220 254 minecraft:green_terracotta
setblock 418 210 255 minecraft:moss_block
fill 418 210 260 418 217 260 minecraft:green_terracotta
fill 376 211 244 376 229 244 minecraft:green_terracotta
fill 376 211 254 376 229 254 minecraft:green_terracotta
fill 377 211 229 377 214 255 minecraft:brown_concrete
setblock 377 211 256 minecraft:bone_block
fill 377 211 257 377 214 269 minecraft:brown_concrete
fill 378 211 230 378 213 250 minecraft:brown_terracotta
fill 378 211 251 378 211 255 minecraft:bone_block
fill 378 211 257 378 211 261 minecraft:bone_block
fill 378 211 262 378 213 268 minecraft:brown_terracotta
fill 378 211 269 385 214 269 minecraft:brown_concrete
setblock 379 211 250 minecraft:bone_block
setblock 379 211 262 minecraft:bone_block
fill 380 211 248 380 211 249 minecraft:bone_block
fill 380 211 263 380 211 264 minecraft:bone_block
setblock 381 211 247 minecraft:bone_block
setblock 381 211 265 minecraft:bone_block
setblock 382 211 246 minecraft:bone_block
setblock 382 211 266 minecraft:bone_block
fill 383 211 245 384 211 245 minecraft:bone_block
fill 383 211 267 384 211 267 minecraft:bone_block
setblock 385 211 244 minecraft:bone_block
setblock 385 211 268 minecraft:bone_block
fill 386 211 230 386 216 242 minecraft:brown_terracotta
fill 386 211 243 390 211 243 minecraft:bone_block
fill 386 211 269 390 211 269 minecraft:bone_block
setblock 387 211 228 minecraft:jungle_leaves[persistent=true]
fill 390 211 230 390 211 242 minecraft:brown_terracotta
fill 391 211 230 416 217 241 minecraft:brown_terracotta
setblock 391 211 242 minecraft:bone_block
fill 392 211 242 416 211 242 minecraft:brown_terracotta
fill 392 211 243 396 211 243 minecraft:bone_block
fill 392 211 269 396 211 269 minecraft:bone_block
setblock 393 211 228 minecraft:moss_block
fill 396 211 270 396 229 270 minecraft:green_terracotta
fill 397 211 243 416 213 243 minecraft:brown_terracotta
setblock 397 211 244 minecraft:bone_block
setblock 397 211 268 minecraft:bone_block
fill 397 211 269 417 214 269 minecraft:brown_concrete
fill 398 211 245 399 211 245 minecraft:bone_block
fill 398 211 267 399 211 267 minecraft:bone_block
setblock 400 211 246 minecraft:bone_block
setblock 400 211 266 minecraft:bone_block
setblock 401 211 247 minecraft:bone_block
setblock 401 211 265 minecraft:bone_block
fill 402 211 248 402 211 249 minecraft:bone_block
fill 402 211 263 402 211 264 minecraft:bone_block
setblock 403 211 250 minecraft:bone_block
setblock 403 211 262 minecraft:bone_block
fill 404 211 251 404 211 255 minecraft:bone_block
fill 404 211 257 404 211 261 minecraft:bone_block
fill 405 211 251 416 216 251 minecraft:brown_terracotta
fill 405 211 255 416 211 255 minecraft:brown_terracotta
setblock 405 211 256 minecraft:bone_block
fill 405 211 257 416 211 257 minecraft:brown_terracotta
fill 405 211 261 416 216 261 minecraft:brown_terracotta
fill 406 211 256 416 217 256 minecraft:brown_terracotta
fill 415 211 228 415 230 228 minecraft:green_terracotta
setblock 416 211 228 minecraft:green_concrete
setblock 418 211 237 minecraft:moss_block
fill 418 211 238 418 217 238 minecraft:green_terracotta
fill 418 211 255 418 228 255 minecraft:green_terracotta
setblock 418 211 265 minecraft:mossy_cobblestone
fill 377 212 256 377 214 256 minecraft:brown_concrete
fill 378 212 251 378 212 253 minecraft:brown_concrete
fill 378 212 259 378 212 261 minecraft:brown_concrete
fill 379 212 230 379 214 248 minecraft:brown_terracotta
fill 379 212 249 379 213 250 minecraft:brown_concrete
setblock 379 212 255 minecraft:light[level=15]
fill 379 212 262 379 213 263 minecraft:brown_concrete
fill 379 212 264 379 214 268 minecraft:brown_terracotta
fill 380 212 248 380 214 248 minecraft:brown_concrete
fill 380 212 263 380 226 263 minecraft:jungle_log
fill 380 212 264 380 214 264 minecraft:brown_concrete
fill 381 212 247 381 213 247 minecraft:brown_concrete
fill 381 212 265 381 213 265 minecraft:brown_concrete
fill 382 212 246 382 213 246 minecraft:brown_concrete
fill 382 212 266 382 213 266 minecraft:brown_concrete
fill 383 212 245 383 214 245 minecraft:brown_concrete
fill 383 212 267 383 214 267 minecraft:brown_concrete
fill 384 212 230 384 216 243 minecraft:brown_terracotta
fill 384 212 244 385 213 244 minecraft:brown_concrete
fill 384 212 268 385 213 268 minecraft:brown_concrete
setblock 385 212 228 minecraft:jungle_leaves[persistent=true]
fill 386 212 243 388 212 243 minecraft:brown_concrete
fill 386 212 269 388 212 269 minecraft:brown_concrete
fill 387 212 228 387 218 228 minecraft:green_terracotta
setblock 387 212 247 minecraft:light[level=15]
setblock 387 212 255 minecraft:light[level=15]
setblock 387 212 263 minecraft:light[level=15]
fill 389 212 230 390 217 241 minecraft:brown_terracotta
fill 389 212 242 393 214 242 minecraft:brown_concrete
fill 393 212 228 393 230 228 minecraft:green_terracotta
fill 394 212 242 416 212 242 minecraft:brown_terracotta
fill 394 212 243 396 212 243 minecraft:brown_concrete
fill 394 212 269 396 212 269 minecraft:brown_concrete
setblock 395 212 247 minecraft:light[level=15]
setblock 395 212 263 minecraft:light[level=15]
fill 397 212 244 398 213 244 minecraft:brown_concrete
fill 397 212 268 398 213 268 minecraft:brown_concrete
fill 399 212 244 416 214 244 minecraft:brown_terracotta
fill 399 212 245 399 214 245 minecraft:brown_concrete
fill 399 212 267 399 214 267 minecraft:brown_concrete
fill 399 212 268 416 214 268 minecraft:brown_terracotta
fill 400 212 246 400 213 246 minecraft:brown_concrete
fill 400 212 266 400 213 266 minecraft:brown_concrete
fill 401 212 247 401 213 247 minecraft:brown_concrete
fill 401 212 265 401 213 265 minecraft:brown_concrete
fill 402 212 248 402 214 248 minecraft:brown_concrete
fill 402 212 264 402 214 264 minecraft:brown_concrete
fill 403 212 249 403 213 250 minecraft:brown_concrete
setblock 403 212 255 minecraft:light[level=15]
fill 403 212 262 403 213 263 minecraft:brown_concrete
fill 404 212 249 416 216 249 minecraft:brown_terracotta
fill 404 212 251 404 212 253 minecraft:brown_concrete
fill 404 212 259 404 212 261 minecraft:brown_concrete
fill 404 212 263 416 216 263 minecraft:brown_terracotta
fill 405 212 254 405 214 258 minecraft:brown_concrete
setblock 405 212 270 minecraft:moss_block
fill 406 212 254 416 217 255 minecraft:brown_terracotta
fill 406 212 257 416 217 258 minecraft:brown_terracotta
setblock 410 212 228 minecraft:green_concrete
fill 416 212 228 416 221 228 minecraft:green_terracotta
setblock 418 212 229 minecraft:moss_block
fill 418 212 237 418 217 237 minecraft:green_terracotta
fill 418 212 265 418 225 265 minecraft:green_terracotta
fill 376 213 270 376 225 270 minecraft:green_terracotta
setblock 377 213 270 minecraft:moss_block
fill 378 213 251 378 214 252 minecraft:brown_concrete
fill 378 213 260 378 214 261 minecraft:brown_concrete
fill 385 213 228 385 229 228 minecraft:green_terracotta
fill 386 213 243 387 214 243 minecraft:brown_concrete
fill 386 213 269 387 214 269 minecraft:brown_concrete
fill 388 213 230 388 219 241 minecraft:brown_terracotta
fill 388 213 242 388 214 242 minecraft:brown_concrete
fill 394 213 242 394 214 242 minecraft:brown_concrete
fill 395 213 242 416 214 242 minecraft:brown_terracotta
fill 395 213 243 396 214 243 minecraft:brown_concrete
fill 395 213 269 396 214 269 minecraft:brown_concrete
fill 404 213 251 404 214 252 minecraft:brown_concrete
fill 404 213 260 404 214 261 minecraft:brown_concrete
setblock 405 213 228 minecraft:mossy_cobblestone
fill 405 213 253 405 214 253 minecraft:brown_concrete
fill 405 213 259 405 214 259 minecraft:brown_concrete
fill 405 213 270 405 229 270 minecraft:green_terracotta
fill 406 213 253 416 219 253 minecraft:brown_terracotta
fill 406 213 259 416 219 259 minecraft:brown_terracotta
fill 410 213 228 410 229 228 minecraft:green_terracotta
fill 418 213 229 418 225 229 minecraft:green_terracotta
setblock 418 213 239 minecraft:green_concrete
fill 377 214 270 377 229 270 minecraft:green_terracotta
fill 378 214 230 378 216 249 minecraft:brown_terracotta
setblock 378 214 250 minecraft:brown_concrete
setblock 378 214 262 minecraft:brown_concrete
fill 378 214 263 378 216 268 minecraft:brown_terracotta
setblock 379 214 249 minecraft:brown_concrete
setblock 379 214 263 minecraft:brown_concrete
fill 380 214 230 380 218 246 minecraft:brown_terracotta
setblock 380 214 247 minecraft:brown_concrete
setblock 380 214 265 minecraft:brown_concrete
fill 380 214 266 380 218 268 minecraft:brown_terracotta
fill 381 214 230 381 218 245 minecraft:brown_terracotta
setblock 381 214 246 minecraft:brown_concrete
fill 381 214 265 381 226 265 minecraft:jungle_log
setblock 381 214 266 minecraft:brown_concrete
fill 381 214 267 381 218 268 minecraft:brown_terracotta
fill 382 214 230 382 218 244 minecraft:brown_terracotta
setblock 382 214 245 minecraft:brown_concrete
fill 382 214 266 382 226 266 minecraft:jungle_log
setblock 382 214 267 minecraft:brown_concrete
fill 382 214 268 382 218 268 minecraft:brown_terracotta
setblock 384 214 244 minecraft:brown_concrete
setblock 384 214 268 minecraft:brown_concrete
fill 385 214 230 385 219 242 minecraft:brown_terracotta
setblock 385 214 243 minecraft:brown_concrete
setblock 386 214 228 minecraft:mossy_cobblestone
setblock 391 214 228 minecraft:moss_block
setblock 393 214 270 minecraft:green_concrete
setblock 397 214 243 minecraft:brown_concrete
fill 398 214 243 416 216 243 minecraft:brown_terracotta
setblock 398 214 244 minecraft:brown_concrete
setblock 398 214 268 minecraft:brown_concrete
setblock 400 214 245 minecraft:brown_concrete
setblock 400 214 267 minecraft:brown_concrete
fill 401 214 245 416 218 245 minecraft:brown_terracotta
setblock 401 214 246 minecraft:brown_concrete
setblock 401 214 266 minecraft:brown_concrete
fill 401 214 267 416 218 267 minecraft:brown_terracotta
fill 402 214 246 416 218 246 minecraft:brown_terracotta
setblock 402 214 247 minecraft:brown_concrete
setblock 402 214 265 minecraft:brown_concrete
fill 402 214 266 416 218 266 minecraft:brown_terracotta
fill 403 214 247 416 218 247 minecraft:brown_terracotta
setblock 403 214 249 minecraft:brown_concrete
setblock 403 214 263 minecraft:brown_concrete
fill 403 214 265 416 218 265 minecraft:brown_terracotta
setblock 404 214 250 minecraft:brown_concrete
setblock 404 214 262 minecraft:brown_concrete
fill 405 214 228 405 229 228 minecraft:green_terracotta
fill 405 214 250 416 219 250 minecraft:brown_terracotta
fill 405 214 262 416 219 262 minecraft:brown_terracotta
fill 418 214 239 418 229 239 minecraft:green_terracotta
fill 377 215 229 377 218 251 minecraft:brown_concrete
fill 377 215 252 377 215 260 minecraft:bone_block
fill 377 215 261 377 218 269 minecraft:brown_concrete
fill 378 215 250 378 215 251 minecraft:bone_block
fill 378 215 261 378 215 262 minecraft:bone_block
fill 378 215 269 384 218 269 minecraft:brown_concrete
fill 379 215 230 379 218 247 minecraft:brown_terracotta
fill 379 215 248 379 215 249 minecraft:bone_block
fill 379 215 263 379 215 264 minecraft:bone_block
fill 379 215 265 379 218 268 minecraft:brown_terracotta
setblock 380 215 247 minecraft:bone_block
fill 380 215 264 380 226 264 minecraft:jungle_log
setblock 380 215 265 minecraft:bone_block
setblock 381 215 246 minecraft:bone_block
setblock 381 215 266 minecraft:bone_block
setblock 382 215 245 minecraft:bone_block
setblock 382 215 267 minecraft:bone_block
fill 383 215 230 383 219 243 minecraft:brown_terracotta
fill 383 215 244 384 215 244 minecraft:bone_block
fill 383 215 267 383 226 267 minecraft:jungle_log
fill 383 215 268 384 215 268 minecraft:bone_block
fill 385 215 243 386 215 243 minecraft:bone_block
fill 385 215 269 386 215 269 minecraft:bone_block
fill 386 215 228 386 217 228 minecraft:green_terracotta
fill 387 215 230 387 220 241 minecraft:brown_terracotta
fill 387 215 242 395 215 242 minecraft:bone_block
fill 391 215 228 391 225 228 minecraft:green_terracotta
fill 393 215 270 393 229 270 minecraft:green_terracotta
fill 396 215 242 416 216 242 minecraft:brown_terracotta
fill 396 215 243 397 215 243 minecraft:bone_block
fill 396 215 269 397 215 269 minecraft:bone_block
fill 398 215 244 399 215 244 minecraft:bone_block
fill 398 215 268 399 215 268 minecraft:bone_block
fill 398 215 269 417 218 269 minecraft:brown_concrete
fill 400 215 244 416 218 244 minecraft:brown_terracotta
setblock 400 215 245 minecraft:bone_block
setblock 400 215 267 minecraft:bone_block
fill 400 215 268 416 218 268 minecraft:brown_terracotta
setblock 401 215 246 minecraft:bone_block
setblock 401 215 266 minecraft:bone_block
setblock 402 215 247 minecraft:bone_block
setblock 402 215 265 minecraft:bone_block
fill 403 215 248 403 215 249 minecraft:bone_block
fill 403 215 263 403 215 264 minecraft:bone_block
fill 404 215 248 416 219 248 minecraft:brown_terracotta
fill 404 215 250 404 215 251 minecraft:bone_block
fill 404 215 261 404 215 262 minecraft:bone_block
fill 404 215 264 416 219 264 minecraft:brown_terracotta
fill 405 215 252 405 215 260 minecraft:bone_block
fill 406 215 252 416 220 252 minecraft:brown_terracotta
fill 406 215 260 416 220 260 minecraft:brown_terracotta
setblock 376 216 248 minecraft:mossy_cobblestone
setblock 376 216 253 minecraft:mossy_cobblestone
fill 377 216 252 377 217 260 minecraft:brown_concrete
fill 378 216 250 378 216 251 minecraft:brown_concrete
fill 378 216 261 378 216 262 minecraft:brown_concrete
fill 379 216 248 379 216 249 minecraft:brown_concrete
setblock 379 216 252 minecraft:light[level=12]
setblock 379 216 259 minecraft:light[level=12]
fill 379 216 263 379 216 264 minecraft:brown_concrete
fill 380 216 247 380 218 247 minecraft:brown_concrete
fill 380 216 265 380 218 265 minecraft:brown_concrete
fill 381 216 246 381 218 246 minecraft:brown_concrete
fill 381 216 266 381 218 266 minecraft:brown_concrete
fill 382 216 245 382 218 245 minecraft:brown_concrete
fill 382 216 267 382 218 267 minecraft:brown_concrete
fill 383 216 244 384 216 244 minecraft:brown_concrete
fill 383 216 268 384 216 268 minecraft:brown_concrete
fill 385 216 243 386 216 243 minecraft:brown_concrete
fill 385 216 269 386 216 269 minecraft:brown_concrete
setblock 386 216 245 minecraft:light[level=12]
setblock 386 216 252 minecraft:light[level=12]
setblock 386 216 259 minecraft:light[level=12]
setblock 386 216 266 minecraft:light[level=12]
fill 387 216 242 395 217 242 minecraft:brown_concrete
setblock 391 216 270 minecraft:jungle_leaves[persistent=true]
setblock 393 216 245 minecraft:light[level=12]
setblock 393 216 252 minecraft:light[level=12]
setblock 393 216 259 minecraft:light[level=12]
setblock 393 216 266 minecraft:light[level=12]
fill 396 216 243 397 216 243 minecraft:brown_concrete
fill 396 216 269 397 216 269 minecraft:brown_concrete
fill 398 216 244 399 216 244 minecraft:brown_concrete
fill 398 216 268 399 216 268 minecraft:brown_concrete
setblock 398 216 270 minecraft:green_concrete
fill 400 216 245 400 218 245 minecraft:brown_concrete
setblock 400 216 252 minecraft:light[level=12]
setblock 400 216 259 minecraft:light[level=12]
setblock 400 216 266 minecraft:light[level=12]
fill 400 216 267 400 218 267 minecraft:brown_concrete
fill 401 216 246 401 218 246 minecraft:brown_concrete
fill 401 216 266 401 218 266 minecraft:brown_concrete
fill 402 216 247 402 218 247 minecraft:brown_concrete
fill 402 216 265 402 218 265 minecraft:brown_concrete
fill 403 216 248 403 216 249 minecraft:brown_concrete
fill 403 216 263 403 216 264 minecraft:brown_concrete
fill 404 216 250 404 216 251 minecraft:brown_concrete
fill 404 216 261 404 216 262 minecraft:brown_concrete
fill 405 216 252 405 217 260 minecraft:brown_concrete
setblock 418 216 256 minecraft:moss_block
fill 376 217 248 376 229 248 minecraft:green_terracotta
fill 376 217 253 376 229 253 minecraft:green_terracotta
fill 378 217 230 378 219 248 minecraft:brown_terracotta
fill 378 217 249 378 218 250 minecraft:brown_concrete
fill 378 217 262 378 218 263 minecraft:brown_concrete
fill 378 217 264 378 219 268 minecraft:brown_terracotta
fill 379 217 248 379 218 248 minecraft:brown_concrete
fill 379 217 263 379 226 263 minecraft:jungle_log
fill 379 217 264 379 218 264 minecraft:brown_concrete
fill 383 217 244 383 218 244 minecraft:brown_concrete
fill 383 217 268 383 218 268 minecraft:brown_concrete
fill 384 217 230 384 222 242 minecraft:brown_terracotta
fill 384 217 243 385 218 243 minecraft:brown_concrete
fill 384 217 260 384 222 260 minecraft:jungle_leaves[persistent=true]
fill 385 217 264 387 221 264 minecraft:oak_leaves[persistent=true]
fill 385 217 269 385 218 269 minecraft:brown_concrete
fill 386 217 230 386 222 241 minecraft:brown_terracotta
fill 386 217 242 386 218 242 minecraft:brown_concrete
fill 387 217 262 387 221 263 minecraft:oak_leaves[persistent=true]
fill 391 217 270 391 229 270 minecraft:green_terracotta
fill 396 217 242 396 218 242 minecraft:brown_concrete
fill 397 217 242 416 219 242 minecraft:brown_terracotta
fill 397 217 243 398 218 243 minecraft:brown_concrete
fill 397 217 269 397 218 269 minecraft:brown_concrete
fill 398 217 270 398 229 270 minecraft:green_terracotta
fill 399 217 243 416 219 243 minecraft:brown_terracotta
fill 399 217 244 399 218 244 minecraft:brown_concrete
fill 399 217 268 399 218 268 minecraft:brown_concrete
fill 403 217 248 403 218 248 minecraft:brown_concrete
fill 403 217 264 403 218 264 minecraft:brown_concrete
fill 404 217 249 404 218 250 minecraft:brown_concrete
fill 404 217 262 404 218 263 minecraft:brown_concrete
fill 405 217 249 416 222 249 minecraft:brown_terracotta
fill 405 217 251 405 218 251 minecraft:brown_concrete
fill 405 217 261 405 218 261 minecraft:brown_concrete
fill 405 217 263 416 222 263 minecraft:brown_terracotta
fill 406 217 251 416 222 251 minecraft:brown_terracotta
fill 406 217 261 416 222 261 minecraft:brown_terracotta
fill 406 217 270 407 217 270 minecraft:green_terracotta
fill 408 217 270 408 221 270 minecraft:jungle_leaves[persistent=true]
setblock 409 217 270 minecraft:green_terracotta
setblock 418 217 245 minecraft:green_concrete
fill 418 217 256 418 229 256 minecraft:green_terracotta
fill 376 218 231 376 219 231 minecraft:jungle_log
setblock 376 218 241 minecraft:jungle_leaves[persistent=true]
setblock 376 218 262 minecraft:jungle_leaves[persistent=true]
fill 377 218 252 377 218 254 minecraft:brown_concrete
fill 377 218 258 377 218 260 minecraft:brown_concrete
fill 382 218 260 383 221 261 minecraft:jungle_leaves[persistent=true]
fill 382 218 262 382 219 263 minecraft:jungle_log
fill 383 218 259 385 221 259 minecraft:jungle_leaves[persistent=true]
fill 383 218 262 384 220 262 minecraft:jungle_leaves[persistent=true]
fill 383 218 264 384 218 264 minecraft:jungle_log
fill 383 218 270 386 220 270 minecraft:oak_leaves[persistent=true]
fill 384 218 261 385 221 261 minecraft:jungle_leaves[persistent=true]
fill 384 218 265 384 219 265 minecraft:jungle_log
fill 385 218 260 385 222 260 minecraft:jungle_leaves[persistent=true]
fill 385 218 265 388 220 265 minecraft:oak_leaves[persistent=true]
setblock 386 218 228 minecraft:moss_block
fill 386 218 262 386 221 263 minecraft:oak_leaves[persistent=true]
fill 387 218 242 389 218 242 minecraft:brown_concrete
fill 388 218 262 388 220 264 minecraft:oak_leaves[persistent=true]
setblock 388 218 270 minecraft:jungle_leaves[persistent=true]
fill 389 218 230 389 218 241 minecraft:brown_terracotta
fill 390 218 230 416 222 240 minecraft:brown_terracotta
fill 390 218 241 392 218 241 minecraft:brown_concrete
fill 393 218 241 416 218 241 minecraft:brown_terracotta
fill 393 218 242 395 218 242 minecraft:brown_concrete
fill 405 218 252 405 218 254 minecraft:brown_concrete
fill 405 218 258 405 218 260 minecraft:brown_concrete
fill 406 218 254 416 218 254 minecraft:brown_terracotta
fill 406 218 255 406 218 257 minecraft:brown_concrete
fill 406 218 258 416 218 258 minecraft:brown_terracotta
fill 406 218 270 407 221 270 minecraft:jungle_leaves[persistent=true]
fill 407 218 255 416 222 257 minecraft:brown_terracotta
fill 409 218 270 410 220 270 minecraft:jungle_leaves[persistent=true]
fill 418 218 234 418 218 235 minecraft:jungle_log
fill 418 218 236 418 218 238 minecraft:jungle_leaves[persistent=true]
fill 418 218 245 418 230 245 minecraft:green_terracotta
fill 418 218 260 418 220 260 minecraft:oak_leaves[persistent=true]
fill 418 218 266 418 219 267 minecraft:jungle_log
fill 376 219 241 376 229 241 minecraft:green_terracotta
setblock 376 219 261 minecraft:moss_block
fill 376 219 262 376 226 262 minecraft:green_terracotta
fill 377 219 229 377 223 250 minecraft:brown_concrete
fill 377 219 251 377 219 253 minecraft:bone_block
fill 377 219 259 377 219 261 minecraft:bone_block
fill 377 219 262 377 223 269 minecraft:brown_concrete
fill 378 219 249 378 219 250 minecraft:bone_block
fill 378 219 262 378 219 263 minecraft:bone_block
fill 378 219 269 383 223 269 minecraft:brown_concrete
fill 379 219 230 379 222 246 minecraft:brown_terracotta
fill 379 219 247 379 219 248 minecraft:bone_block
setblock 379 219 255 minecraft:light[level=15]
fill 379 219 264 379 219 265 minecraft:bone_block
fill 379 219 266 379 222 268 minecraft:brown_terracotta
fill 380 219 230 380 222 245 minecraft:brown_terracotta
setblock 380 219 246 minecraft:bone_block
fill 380 219 265 380 226 265 minecraft:jungle_log
setblock 380 219 266 minecraft:bone_block
fill 380 219 267 380 222 268 minecraft:brown_terracotta
fill 381 219 230 381 222 244 minecraft:brown_terracotta
setblock 381 219 245 minecraft:bone_block
fill 381 219 266 381 226 266 minecraft:jungle_log
setblock 381 219 267 minecraft:bone_block
fill 381 219 268 381 222 268 minecraft:brown_terracotta
fill 382 219 230 382 222 243 minecraft:brown_terracotta
fill 382 219 244 383 219 244 minecraft:bone_block
fill 382 219 259 382 221 259 minecraft:jungle_leaves[persistent=true]
fill 382 219 267 382 226 267 minecraft:jungle_log
fill 382 219 268 383 219 268 minecraft:bone_block
fill 383 219 258 385 220 258 minecraft:jungle_leaves[persistent=true]
fill 384 219 243 385 219 243 minecraft:bone_block
fill 384 219 263 385 220 263 minecraft:oak_leaves[persistent=true]
setblock 384 219 264 minecraft:jungle_log
fill 384 219 269 385 219 269 minecraft:bone_block
fill 385 219 262 385 221 262 minecraft:oak_leaves[persistent=true]
fill 386 219 228 386 229 228 minecraft:green_terracotta
fill 386 219 242 388 219 242 minecraft:bone_block
fill 386 219 260 386 220 261 minecraft:jungle_leaves[persistent=true]
fill 386 219 266 386 220 266 minecraft:oak_leaves[persistent=true]
fill 387 219 228 388 220 228 minecraft:azalea_leaves[persistent=true]
setblock 387 219 247 minecraft:light[level=15]
setblock 387 219 255 minecraft:light[level=15]
fill 388 219 270 388 229 270 minecraft:green_terracotta
fill 389 219 230 389 222 240 minecraft:brown_terracotta
fill 389 219 241 393 219 241 minecraft:bone_block
fill 389 219 262 389 219 264 minecraft:oak_leaves[persistent=true]
fill 394 219 241 416 219 241 minecraft:brown_terracotta
fill 394 219 242 396 219 242 minecraft:bone_block
setblock 395 219 247 minecraft:light[level=15]
setblock 395 219 263 minecraft:light[level=15]
fill 397 219 243 398 219 243 minecraft:bone_block
fill 397 219 269 398 219 269 minecraft:bone_block
fill 399 219 244 400 219 244 minecraft:bone_block
fill 399 219 268 400 219 268 minecraft:bone_block
fill 399 219 269 417 223 269 minecraft:brown_concrete
fill 401 219 244 416 222 244 minecraft:brown_terracotta
setblock 401 219 245 minecraft:bone_block
setblock 401 219 267 minecraft:bone_block
fill 401 219 268 416 222 268 minecraft:brown_terracotta
fill 402 219 245 416 222 245 minecraft:brown_terracotta
setblock 402 219 246 minecraft:bone_block
setblock 402 219 266 minecraft:bone_block
fill 402 219 267 416 222 267 minecraft:brown_terracotta
fill 403 219 246 416 222 246 minecraft:brown_terracotta
fill 403 219 247 403 219 248 minecraft:bone_block
setblock 403 219 255 minecraft:light[level=15]
setblock 403 219 263 minecraft:light[level=15]
fill 403 219 264 403 219 265 minecraft:bone_block
fill 403 219 266 416 222 266 minecraft:brown_terracotta
fill 404 219 247 416 222 247 minecraft:brown_terracotta
fill 404 219 249 404 219 250 minecraft:bone_block
fill 404 219 262 404 219 263 minecraft:bone_block
fill 404 219 265 416 222 265 minecraft:brown_terracotta
fill 405 219 251 405 219 253 minecraft:bone_block
fill 405 219 259 405 219 261 minecraft:bone_block
setblock 406 219 228 minecraft:mossy_cobblestone
fill 406 219 254 406 219 258 minecraft:bone_block
fill 407 219 254 416 222 254 minecraft:brown_terracotta
fill 407 219 258 416 222 258 minecraft:brown_terracotta
setblock 418 219 234 minecraft:jungle_log
fill 418 219 235 418 220 236 minecraft:azalea_leaves[persistent=true]
fill 418 219 237 418 221 238 minecraft:jungle_leaves[persistent=true]
setblock 418 219 242 minecraft:green_concrete
fill 418 219 258 418 229 258 minecraft:green_terracotta
fill 418 219 259 418 221 259 minecraft:oak_leaves[persistent=true]
fill 376 220 231 376 229 231 minecraft:green_terracotta
fill 376 220 261 376 229 261 minecraft:green_terracotta
fill 377 220 251 377 220 252 minecraft:brown_concrete
fill 377 220 260 377 220 261 minecraft:brown_concrete
fill 378 220 230 378 222 247 minecraft:brown_terracotta
fill 378 220 248 378 222 249 minecraft:brown_concrete
fill 378 220 263 378 222 264 minecraft:brown_concrete
fill 378 220 265 378 222 268 minecraft:brown_terracotta
fill 379 220 247 379 223 247 minecraft:brown_concrete
fill 379 220 264 379 226 264 minecraft:jungle_log
fill 379 220 265 379 223 265 minecraft:brown_concrete
fill 380 220 246 380 222 246 minecraft:brown_concrete
fill 380 220 266 380 222 266 minecraft:brown_concrete
fill 381 220 245 381 222 245 minecraft:brown_concrete
fill 381 220 267 381 222 267 minecraft:brown_concrete
fill 382 220 244 382 223 244 minecraft:brown_concrete
fill 382 220 268 382 223 268 minecraft:brown_concrete
fill 383 220 230 383 222 242 minecraft:brown_terracotta
fill 383 220 243 384 222 243 minecraft:brown_concrete
fill 384 220 269 384 222 269 minecraft:brown_concrete
fill 385 220 230 385 222 241 minecraft:brown_terracotta
fill 385 220 242 387 220 242 minecraft:brown_concrete
fill 385 220 269 385 221 269 minecraft:oak_leaves[persistent=true]
setblock 387 220 266 minecraft:oak_leaves[persistent=true]
fill 388 220 230 388 222 240 minecraft:brown_terracotta
fill 388 220 241 394 223 241 minecraft:brown_concrete
fill 389 220 263 389 220 264 minecraft:oak_leaves[persistent=true]
fill 395 220 241 416 220 241 minecraft:brown_terracotta
fill 395 220 242 397 220 242 minecraft:brown_concrete
fill 398 220 242 416 222 242 minecraft:brown_terracotta
fill 398 220 243 399 222 243 minecraft:brown_concrete
fill 398 220 269 398 222 269 minecraft:brown_concrete
fill 400 220 243 416 222 243 minecraft:brown_terracotta
fill 400 220 244 400 223 244 minecraft:brown_concrete
fill 400 220 268 400 223 268 minecraft:brown_concrete
fill 401 220 245 401 222 245 minecraft:brown_concrete
fill 401 220 267 401 222 267 minecraft:brown_concrete
fill 402 220 246 402 222 246 minecraft:brown_concrete
fill 402 220 266 402 222 266 minecraft:brown_concrete
fill 403 220 247 403 223 247 minecraft:brown_concrete
fill 403 220 265 403 223 265 minecraft:brown_concrete
fill 404 220 248 404 222 249 minecraft:brown_concrete
fill 404 220 263 404 222 264 minecraft:brown_concrete
fill 405 220 248 416 222 248 minecraft:brown_terracotta
fill 405 220 250 405 220 252 minecraft:brown_concrete
fill 405 220 260 405 220 262 minecraft:brown_concrete
fill 405 220 264 416 222 264 minecraft:brown_terracotta
fill 406 220 228 406 229 228 minecraft:green_terracotta
fill 406 220 250 416 222 250 minecraft:brown_terracotta
fill 406 220 253 406 223 259 minecraft:brown_concrete
fill 406 220 262 416 222 262 minecraft:brown_terracotta
fill 407 220 253 416 222 253 minecraft:brown_terracotta
fill 407 220 259 416 222 259 minecraft:brown_terracotta
setblock 418 220 234 minecraft:jungle_leaves[persistent=true]
fill 418 220 242 418 229 242 minecraft:green_terracotta
fill 418 220 266 418 225 267 minecraft:green_terracotta
setblock 376 221 230 minecraft:jungle_leaves[persistent=true]
setblock 376 221 238 minecraft:mossy_cobblestone
fill 377 221 251 377 222 251 minecraft:brown_concrete
fill 377 221 261 377 222 261 minecraft:brown_concrete
fill 383 221 270 383 228 270 minecraft:green_terracotta
setblock 384 221 262 minecraft:jungle_leaves[persistent=true]
fill 384 221 270 386 221 270 minecraft:oak_leaves[persistent=true]
fill 385 221 242 386 222 242 minecraft:brown_concrete
setblock 385 221 263 minecraft:oak_leaves[persistent=true]
setblock 386 221 260 minecraft:jungle_leaves[persistent=true]
fill 386 221 265 388 221 265 minecraft:oak_leaves[persistent=true]
fill 387 221 228 388 225 228 minecraft:green_terracotta
fill 387 221 230 387 222 240 minecraft:brown_terracotta
fill 387 221 241 387 223 241 minecraft:brown_concrete
fill 388 221 263 388 221 264 minecraft:oak_leaves[persistent=true]
fill 395 221 241 395 223 241 minecraft:brown_concrete
fill 396 221 241 416 222 241 minecraft:brown_terracotta
fill 396 221 242 397 222 242 minecraft:brown_concrete
fill 405 221 250 405 222 251 minecraft:brown_concrete
fill 405 221 261 405 222 262 minecraft:brown_concrete
fill 406 221 252 406 223 252 minecraft:brown_concrete
fill 406 221 260 406 223 260 minecraft:brown_concrete
fill 407 221 252 416 222 252 minecraft:brown_terracotta
fill 407 221 260 416 222 260 minecraft:brown_terracotta
setblock 409 221 270 minecraft:jungle_leaves[persistent=true]
fill 410 221 270 410 225 270 minecraft:green_terracotta
fill 418 221 234 418 226 234 minecraft:green_terracotta
setblock 418 221 235 minecraft:jungle_leaves[persistent=true]
setblock 418 221 236 minecraft:azalea_leaves[persistent=true]
setblock 418 221 254 minecraft:jungle_leaves[persistent=true]
setblock 418 221 260 minecraft:green_terracotta
fill 376 222 230 376 229 230 minecraft:green_terracotta
fill 376 222 238 376 229 238 minecraft:green_terracotta
setblock 379 222 252 minecraft:light[level=12]
setblock 379 222 259 minecraft:light[level=12]
setblock 383 222 260 minecraft:jungle_leaves[persistent=true]
fill 384 222 270 386 224 270 minecraft:green_terracotta
setblock 386 222 245 minecraft:light[level=12]
setblock 386 222 252 minecraft:light[level=12]
setblock 386 222 259 minecraft:light[level=12]
fill 386 222 264 387 222 264 minecraft:oak_leaves[persistent=true]
setblock 386 222 266 minecraft:light[level=12]
setblock 393 222 245 minecraft:light[level=12]
setblock 393 222 252 minecraft:light[level=12]
setblock 393 222 259 minecraft:light[level=12]
setblock 393 222 266 minecraft:light[level=12]
fill 399 222 267 399 226 267 minecraft:jungle_leaves[persistent=true]
setblock 400 222 245 minecraft:light[level=12]
setblock 400 222 252 minecraft:light[level=12]
setblock 400 222 259 minecraft:light[level=12]
setblock 400 222 266 minecraft:light[level=12]
fill 406 222 270 406 225 270 minecraft:green_terracotta
setblock 407 222 270 minecraft:jungle_leaves[persistent=true]
fill 408 222 270 409 225 270 minecraft:green_terracotta
setblock 416 222 228 minecraft:mossy_cobblestone
fill 418 222 235 418 222 238 minecraft:green_terracotta
setblock 418 222 246 minecraft:green_concrete
fill 418 222 254 418 229 254 minecraft:green_terracotta
fill 418 222 259 418 225 259 minecraft:green_terracotta
setblock 418 222 260 minecraft:moss_block
fill 378 223 230 378 223 248 minecraft:brown_concrete
fill 378 223 264 378 223 268 minecraft:brown_concrete
fill 379 223 230 379 223 246 minecraft:brown_concrete
fill 379 223 266 379 223 268 minecraft:brown_concrete
fill 380 223 230 380 223 245 minecraft:brown_concrete
fill 380 223 266 380 226 266 minecraft:jungle_log
fill 380 223 267 380 223 268 minecraft:brown_concrete
fill 381 223 230 381 223 244 minecraft:brown_concrete
fill 381 223 267 381 226 267 minecraft:jungle_log
setblock 381 223 268 minecraft:brown_concrete
fill 382 223 230 383 223 243 minecraft:brown_concrete
fill 384 223 230 385 223 242 minecraft:brown_concrete
fill 386 223 230 386 223 241 minecraft:brown_concrete
fill 387 223 230 416 223 240 minecraft:brown_concrete
setblock 389 223 228 minecraft:moss_block
setblock 392 223 228 minecraft:jungle_leaves[persistent=true]
fill 396 223 241 416 223 241 minecraft:brown_concrete
fill 397 223 242 416 223 242 minecraft:brown_concrete
fill 399 223 243 416 223 243 minecraft:brown_concrete
fill 401 223 244 416 223 244 minecraft:brown_concrete
fill 401 223 268 416 223 268 minecraft:brown_concrete
fill 402 223 245 416 223 245 minecraft:brown_concrete
fill 402 223 267 416 223 267 minecraft:brown_concrete
fill 403 223 246 416 223 246 minecraft:brown_concrete
fill 403 223 266 416 223 266 minecraft:brown_concrete
fill 404 223 247 416 223 248 minecraft:brown_concrete
fill 404 223 264 416 223 265 minecraft:brown_concrete
fill 405 223 249 416 223 250 minecraft:brown_concrete
fill 405 223 262 416 223 263 minecraft:brown_concrete
fill 406 223 251 416 223 251 minecraft:brown_concrete
fill 406 223 261 416 223 261 minecraft:brown_concrete
fill 407 223 252 416 223 260 minecraft:brown_concrete
fill 407 223 270 407 229 270 minecraft:green_terracotta
fill 416 223 228 416 225 228 minecraft:green_terracotta
fill 418 223 235 418 226 237 minecraft:green_terracotta
setblock 418 223 238 minecraft:moss_block
fill 418 223 246 418 229 246 minecraft:green_terracotta
fill 418 223 260 418 229 260 minecraft:green_terracotta
fill 377 224 231 383 226 233 minecraft:jungle_log
setblock 377 224 263 minecraft:moss_block
fill 377 224 265 379 226 267 minecraft:jungle_log
fill 378 224 230 382 226 230 minecraft:jungle_log
fill 378 224 234 382 226 234 minecraft:jungle_log
fill 378 224 264 378 226 264 minecraft:jungle_log
fill 378 224 268 382 226 268 minecraft:jungle_log
fill 379 224 229 381 226 229 minecraft:jungle_log
fill 379 224 235 381 226 235 minecraft:jungle_log
fill 379 224 269 381 226 269 minecraft:jungle_log
fill 380 224 267 380 226 267 minecraft:jungle_log
fill 387 224 246 389 224 246 minecraft:green_terracotta
setblock 387 224 247 minecraft:lime_terracotta
fill 387 224 248 387 224 250 minecraft:green_terracotta
fill 388 224 242 389 239 243 minecraft:green_terracotta
setblock 388 224 244 minecraft:lime_terracotta
fill 388 224 245 388 241 245 minecraft:green_terracotta
fill 388 224 247 390 227 247 minecraft:green_terracotta
setblock 388 224 248 minecraft:lime_terracotta
fill 388 224 249 388 240 251 minecraft:green_terracotta
setblock 388 224 252 minecraft:lime_terracotta
fill 388 224 253 388 241 254 minecraft:green_terracotta
fill 389 224 228 389 229 228 minecraft:green_terracotta
setblock 389 224 241 minecraft:lime_terracotta
fill 389 224 244 391 238 244 minecraft:green_terracotta
setblock 389 224 245 minecraft:lime_terracotta
fill 389 224 248 391 229 248 minecraft:green_terracotta
setblock 389 224 249 minecraft:lime_terracotta
fill 389 224 250 389 232 252 minecraft:green_terracotta
setblock 389 224 253 minecraft:lime_terracotta
fill 389 224 254 389 233 255 minecraft:green_terracotta
fill 390 224 239 404 224 239 minecraft:brown_terracotta
fill 390 224 240 391 241 241 minecraft:green_terracotta
setblock 390 224 242 minecraft:lime_terracotta
fill 390 224 243 390 240 243 minecraft:green_terracotta
fill 390 224 245 392 235 245 minecraft:green_terracotta
setblock 390 224 246 minecraft:lime_terracotta
fill 390 224 249 392 230 249 minecraft:green_terracotta
setblock 390 224 250 minecraft:lime_terracotta
fill 390 224 251 390 229 253 minecraft:green_terracotta
setblock 390 224 254 minecraft:lime_terracotta
fill 390 224 255 390 228 257 minecraft:green_terracotta
setblock 390 224 270 minecraft:mossy_cobblestone
fill 391 224 238 403 224 238 minecraft:brown_terracotta
fill 391 224 242 393 237 242 minecraft:green_terracotta
setblock 391 224 243 minecraft:lime_terracotta
fill 391 224 246 393 233 246 minecraft:green_terracotta
setblock 391 224 247 minecraft:lime_terracotta
fill 391 224 250 393 228 250 minecraft:green_terracotta
setblock 391 224 251 minecraft:lime_terracotta
fill 391 224 252 391 226 254 minecraft:green_terracotta
setblock 391 224 255 minecraft:lime_terracotta
fill 391 224 256 391 226 258 minecraft:green_terracotta
fill 392 224 228 392 227 228 minecraft:green_terracotta
fill 392 224 237 402 224 237 minecraft:brown_terracotta
setblock 392 224 240 minecraft:lime_terracotta
fill 392 224 241 392 240 241 minecraft:green_terracotta
fill 392 224 243 394 235 243 minecraft:green_terracotta
setblock 392 224 244 minecraft:lime_terracotta
fill 392 224 247 394 227 247 minecraft:green_terracotta
setblock 392 224 248 minecraft:lime_terracotta
fill 392 224 251 394 227 251 minecraft:green_terracotta
setblock 392 224 252 minecraft:lime_terracotta
fill 392 224 253 392 225 254 minecraft:green_terracotta
fill 392 224 258 392 225 259 minecraft:green_terracotta
fill 393 224 240 395 237 240 minecraft:green_terracotta
setblock 393 224 241 minecraft:lime_terracotta
fill 393 224 244 395 234 244 minecraft:green_terracotta
setblock 393 224 245 minecraft:lime_terracotta
fill 393 224 248 395 229 248 minecraft:green_terracotta
setblock 393 224 249 minecraft:lime_terracotta
fill 393 224 252 395 225 252 minecraft:green_terracotta
setblock 393 224 253 minecraft:lime_terracotta
fill 393 224 259 393 225 259 minecraft:green_terracotta
fill 394 224 236 400 224 236 minecraft:brown_terracotta
fill 394 224 241 396 236 241 minecraft:green_terracotta
setblock 394 224 242 minecraft:lime_terracotta
fill 394 224 245 396 233 245 minecraft:green_terracotta
setblock 394 224 246 minecraft:lime_terracotta
fill 394 224 249 396 229 249 minecraft:green_terracotta
setblock 394 224 250 minecraft:lime_terracotta
fill 394 224 260 395 226 260 minecraft:green_terracotta
fill 395 224 242 397 235 242 minecraft:green_terracotta
setblock 395 224 243 minecraft:lime_terracotta
fill 395 224 246 397 232 246 minecraft:green_terracotta
setblock 395 224 247 minecraft:lime_terracotta
fill 395 224 250 397 227 250 minecraft:green_terracotta
setblock 395 224 251 minecraft:lime_terracotta
setblock 396 224 228 minecraft:green_concrete
setblock 396 224 240 minecraft:lime_terracotta
fill 396 224 243 398 235 243 minecraft:green_terracotta
setblock 396 224 244 minecraft:lime_terracotta
fill 396 224 247 398 227 247 minecraft:green_terracotta
setblock 396 224 248 minecraft:lime_terracotta
fill 396 224 251 398 226 251 minecraft:green_terracotta
setblock 396 224 252 minecraft:lime_terracotta
setblock 396 224 260 minecraft:lime_terracotta
fill 397 224 240 399 237 240 minecraft:green_terracotta
setblock 397 224 241 minecraft:lime_terracotta
fill 397 224 244 399 234 244 minecraft:green_terracotta
setblock 397 224 245 minecraft:lime_terracotta
fill 397 224 248 399 229 248 minecraft:green_terracotta
setblock 397 224 249 minecraft:lime_terracotta
fill 397 224 252 399 226 252 minecraft:green_terracotta
setblock 397 224 253 minecraft:lime_terracotta
fill 397 224 259 398 225 260 minecraft:green_terracotta
fill 398 224 241 400 236 241 minecraft:green_terracotta
setblock 398 224 242 minecraft:lime_terracotta
fill 398 224 245 400 234 245 minecraft:green_terracotta
setblock 398 224 246 minecraft:lime_terracotta
fill 398 224 249 400 230 249 minecraft:green_terracotta
setblock 398 224 250 minecraft:lime_terracotta
fill 398 224 253 400 226 253 minecraft:green_terracotta
setblock 398 224 254 minecraft:lime_terracotta
setblock 398 224 258 minecraft:lime_terracotta
fill 399 224 242 401 236 242 minecraft:green_terracotta
setblock 399 224 243 minecraft:lime_terracotta
fill 399 224 246 401 233 246 minecraft:green_terracotta
setblock 399 224 247 minecraft:lime_terracotta
fill 399 224 250 401 229 250 minecraft:green_terracotta
setblock 399 224 251 minecraft:lime_terracotta
fill 399 224 254 401 226 254 minecraft:green_terracotta
setblock 399 224 255 minecraft:lime_terracotta
fill 399 224 256 399 226 258 minecraft:green_terracotta
setblock 399 224 259 minecraft:lime_terracotta
fill 399 224 260 399 233 260 minecraft:green_terracotta
setblock 400 224 240 minecraft:lime_terracotta
fill 400 224 243 402 235 243 minecraft:green_terracotta
setblock 400 224 244 minecraft:lime_terracotta
fill 400 224 247 402 227 247 minecraft:green_terracotta
setblock 400 224 248 minecraft:lime_terracotta
fill 400 224 251 402 230 251 minecraft:green_terracotta
setblock 400 224 252 minecraft:lime_terracotta
fill 400 224 255 402 227 255 minecraft:green_terracotta
setblock 400 224 256 minecraft:lime_terracotta
fill 400 224 257 400 227 259 minecraft:green_terracotta
setblock 400 224 260 minecraft:lime_terracotta
fill 401 224 240 403 240 240 minecraft:green_terracotta
setblock 401 224 241 minecraft:lime_terracotta
fill 401 224 244 403 236 244 minecraft:green_terracotta
setblock 401 224 245 minecraft:lime_terracotta
fill 401 224 248 403 229 248 minecraft:green_terracotta
setblock 401 224 249 minecraft:lime_terracotta
fill 401 224 252 403 230 252 minecraft:green_terracotta
setblock 401 224 253 minecraft:lime_terracotta
fill 401 224 256 403 227 256 minecraft:green_terracotta
setblock 401 224 257 minecraft:lime_terracotta
fill 401 224 258 401 233 259 minecraft:green_terracotta
fill 402 224 241 404 240 241 minecraft:green_terracotta
setblock 402 224 242 minecraft:lime_terracotta
fill 402 224 245 404 237 245 minecraft:green_terracotta
setblock 402 224 246 minecraft:lime_terracotta
fill 402 224 249 404 231 249 minecraft:green_terracotta
setblock 402 224 250 minecraft:lime_terracotta
fill 402 224 253 404 232 253 minecraft:green_terracotta
setblock 402 224 254 minecraft:lime_terracotta
fill 402 224 257 404 233 257 minecraft:green_terracotta
setblock 402 224 258 minecraft:lime_terracotta
fill 402 224 259 402 240 259 minecraft:green_terracotta
fill 403 224 242 405 241 242 minecraft:green_terracotta
setblock 403 224 243 minecraft:lime_terracotta
fill 403 224 246 405 237 246 minecraft:green_terracotta
setblock 403 224 247 minecraft:lime_terracotta
fill 403 224 250 405 232 250 minecraft:green_terracotta
setblock 403 224 251 minecraft:lime_terracotta
fill 403 224 254 405 234 254 minecraft:green_terracotta
setblock 403 224 255 minecraft:lime_terracotta
fill 403 224 258 403 240 258 minecraft:green_terracotta
setblock 404 224 240 minecraft:lime_terracotta
fill 404 224 243 406 240 243 minecraft:green_terracotta
setblock 404 224 244 minecraft:lime_terracotta
fill 404 224 247 406 227 247 minecraft:green_terracotta
setblock 404 224 248 minecraft:lime_terracotta
fill 404 224 251 406 234 251 minecraft:green_terracotta
setblock 404 224 252 minecraft:lime_terracotta
fill 404 224 255 405 233 255 minecraft:green_terracotta
setblock 404 224 256 minecraft:lime_terracotta
setblock 405 224 241 minecraft:lime_terracotta
fill 405 224 244 406 241 244 minecraft:green_terracotta
setblock 405 224 245 minecraft:lime_terracotta
fill 405 224 248 407 240 248 minecraft:green_terracotta
setblock 405 224 249 minecraft:lime_terracotta
fill 405 224 252 406 239 252 minecraft:green_terracotta
setblock 405 224 253 minecraft:lime_terracotta
setblock 406 224 242 minecraft:lime_terracotta
fill 406 224 245 406 240 245 minecraft:green_terracotta
setblock 406 224 246 minecraft:lime_terracotta
fill 406 224 249 407 241 249 minecraft:green_terracotta
setblock 406 224 250 minecraft:lime_terracotta
fill 406 224 253 406 233 253 minecraft:green_terracotta
setblock 406 224 254 minecraft:lime_terracotta
setblock 407 224 246 minecraft:green_terracotta
setblock 407 224 247 minecraft:lime_terracotta
setblock 407 224 250 minecraft:green_terracotta
fill 411 224 231 417 226 233 minecraft:jungle_log
fill 411 224 265 417 226 267 minecraft:jungle_log
fill 412 224 230 416 226 230 minecraft:jungle_log
fill 412 224 234 416 226 234 minecraft:jungle_log
fill 412 224 264 416 226 264 minecraft:jungle_log
fill 412 224 268 416 226 268 minecraft:jungle_log
fill 413 224 229 415 226 229 minecraft:jungle_log
fill 413 224 235 415 226 235 minecraft:jungle_log
fill 413 224 263 415 226 263 minecraft:jungle_log
fill 413 224 269 415 226 269 minecraft:jungle_log
fill 416 224 257 416 226 257 minecraft:moss_block
setblock 418 224 231 minecraft:moss_block
fill 418 224 238 418 227 238 minecraft:green_terracotta
setblock 418 224 241 minecraft:jungle_leaves[persistent=true]
fill 384 225 270 385 229 270 minecraft:green_terracotta
fill 386 225 248 388 225 248 minecraft:green_terracotta
setblock 386 225 270 minecraft:mossy_cobblestone
fill 387 225 243 387 232 245 minecraft:green_terracotta
setblock 387 225 246 minecraft:lime_terracotta
fill 387 225 247 387 239 247 minecraft:green_terracotta
fill 387 225 249 387 241 249 minecraft:green_terracotta
setblock 387 225 250 minecraft:lime_terracotta
fill 387 225 251 387 225 253 minecraft:green_terracotta
fill 388 225 240 388 232 241 minecraft:green_terracotta
fill 388 225 244 388 241 244 minecraft:green_terracotta
fill 388 225 246 390 237 246 minecraft:green_terracotta
fill 388 225 252 388 241 252 minecraft:green_terracotta
setblock 388 225 255 minecraft:lime_terracotta
fill 388 225 256 388 236 256 minecraft:green_terracotta
setblock 389 225 239 minecraft:brown_terracotta
setblock 389 225 240 minecraft:lime_terracotta
fill 389 225 241 389 241 241 minecraft:green_terracotta
fill 389 225 245 389 240 245 minecraft:green_terracotta
fill 389 225 249 389 231 249 minecraft:green_terracotta
fill 389 225 253 389 234 253 minecraft:green_terracotta
setblock 389 225 256 minecraft:lime_terracotta
fill 389 225 257 389 233 257 minecraft:green_terracotta
setblock 390 225 238 minecraft:brown_terracotta
fill 390 225 239 404 232 239 minecraft:green_terracotta
fill 390 225 242 390 241 242 minecraft:green_terracotta
fill 390 225 250 390 232 250 minecraft:green_terracotta
fill 390 225 254 390 228 254 minecraft:green_terracotta
fill 390 225 258 390 232 258 minecraft:green_terracotta
fill 390 225 270 390 230 270 minecraft:green_terracotta
setblock 391 225 237 minecraft:brown_terracotta
fill 391 225 238 403 231 238 minecraft:green_terracotta
fill 391 225 243 391 239 243 minecraft:green_terracotta
fill 391 225 247 391 234 247 minecraft:green_terracotta
fill 391 225 251 391 229 251 minecraft:green_terracotta
fill 391 225 255 391 226 255 minecraft:green_terracotta
fill 391 225 259 391 239 259 minecraft:green_terracotta
fill 392 225 236 393 225 236 minecraft:brown_terracotta
fill 392 225 237 402 231 237 minecraft:green_terracotta
fill 392 225 240 392 241 240 minecraft:green_terracotta
fill 392 225 244 392 236 244 minecraft:green_terracotta
fill 392 225 248 392 229 248 minecraft:green_terracotta
fill 392 225 252 392 227 252 minecraft:green_terracotta
fill 392 225 260 392 233 260 minecraft:green_terracotta
fill 393 225 241 393 237 241 minecraft:green_terracotta
fill 393 225 245 393 234 245 minecraft:green_terracotta
fill 393 225 249 393 229 249 minecraft:green_terracotta
setblock 393 225 253 minecraft:green_terracotta
setblock 393 225 260 minecraft:lime_terracotta
fill 394 225 235 400 225 235 minecraft:brown_terracotta
fill 394 225 236 400 230 236 minecraft:green_terracotta
fill 394 225 242 394 236 242 minecraft:green_terracotta
fill 394 225 246 394 232 246 minecraft:green_terracotta
fill 394 225 250 394 228 250 minecraft:green_terracotta
setblock 394 225 261 minecraft:lime_terracotta
fill 395 225 243 395 235 243 minecraft:green_terracotta
fill 395 225 247 395 227 247 minecraft:green_terracotta
fill 395 225 251 395 226 251 minecraft:green_terracotta
fill 395 225 261 397 230 261 minecraft:green_terracotta
fill 396 225 228 396 230 228 minecraft:green_terracotta
fill 396 225 240 396 237 240 minecraft:green_terracotta
fill 396 225 244 396 234 244 minecraft:green_terracotta
fill 396 225 248 396 230 248 minecraft:green_terracotta
setblock 396 225 252 minecraft:green_terracotta
fill 396 225 260 396 226 260 minecraft:green_terracotta
fill 397 225 241 397 235 241 minecraft:green_terracotta
fill 397 225 245 397 233 245 minecraft:green_terracotta
fill 397 225 249 397 229 249 minecraft:green_terracotta
setblock 397 225 253 minecraft:green_terracotta
fill 398 225 242 398 235 242 minecraft:green_terracotta
fill 398 225 246 398 233 246 minecraft:green_terracotta
fill 398 225 250 398 229 250 minecraft:green_terracotta
setblock 398 225 254 minecraft:green_terracotta
setblock 398 225 258 minecraft:green_terracotta
setblock 398 225 261 minecraft:lime_terracotta
fill 399 225 243 399 236 243 minecraft:green_terracotta
fill 399 225 247 399 232 247 minecraft:green_terracotta
fill 399 225 251 399 229 251 minecraft:green_terracotta
fill 399 225 255 399 226 255 minecraft:green_terracotta
fill 399 225 259 399 229 259 minecraft:green_terracotta
fill 399 225 261 400 238 261 minecraft:green_terracotta
fill 400 225 240 400 238 240 minecraft:green_terracotta
fill 400 225 244 400 236 244 minecraft:green_terracotta
fill 400 225 248 400 232 248 minecraft:green_terracotta
fill 400 225 252 400 229 252 minecraft:green_terracotta
fill 400 225 256 400 227 256 minecraft:green_terracotta
fill 400 225 260 400 237 260 minecraft:green_terracotta
fill 401 225 236 402 225 236 minecraft:brown_terracotta
fill 401 225 241 401 237 241 minecraft:green_terracotta
fill 401 225 245 401 236 245 minecraft:green_terracotta
fill 401 225 249 401 231 249 minecraft:green_terracotta
fill 401 225 253 401 230 253 minecraft:green_terracotta
fill 401 225 257 401 231 257 minecraft:green_terracotta
setblock 401 225 260 minecraft:lime_terracotta
fill 402 225 242 402 238 242 minecraft:green_terracotta
fill 402 225 246 402 236 246 minecraft:green_terracotta
fill 402 225 250 402 233 250 minecraft:green_terracotta
fill 402 225 254 402 232 254 minecraft:green_terracotta
fill 402 225 258 402 237 258 minecraft:green_terracotta
fill 402 225 260 402 240 260 minecraft:green_terracotta
setblock 403 225 237 minecraft:brown_terracotta
fill 403 225 243 403 240 243 minecraft:green_terracotta
fill 403 225 247 403 237 247 minecraft:green_terracotta
fill 403 225 251 403 235 251 minecraft:green_terracotta
fill 403 225 255 403 235 255 minecraft:green_terracotta
fill 403 225 259 403 239 259 minecraft:green_terracotta
setblock 404 225 238 minecraft:brown_terracotta
fill 404 225 240 404 241 240 minecraft:green_terracotta
fill 404 225 244 404 240 244 minecraft:green_terracotta
fill 404 225 248 404 229 248 minecraft:green_terracotta
fill 404 225 252 404 235 252 minecraft:green_terracotta
fill 404 225 256 404 227 256 minecraft:green_terracotta
fill 404 225 258 404 236 258 minecraft:green_terracotta
setblock 405 225 239 minecraft:brown_terracotta
setblock 405 225 240 minecraft:lime_terracotta
fill 405 225 241 405 241 241 minecraft:green_terracotta
fill 405 225 245 405 241 245 minecraft:green_terracotta
fill 405 225 249 405 239 249 minecraft:green_terracotta
fill 405 225 253 405 240 253 minecraft:green_terracotta
setblock 405 225 256 minecraft:lime_terracotta
fill 405 225 257 405 232 257 minecraft:green_terracotta
setblock 406 225 240 minecraft:green_terracotta
setblock 406 225 241 minecraft:lime_terracotta
fill 406 225 242 406 239 242 minecraft:green_terracotta
fill 406 225 246 406 242 246 minecraft:green_terracotta
fill 406 225 250 406 242 250 minecraft:green_terracotta
fill 406 225 254 406 225 256 minecraft:green_terracotta
fill 407 225 243 407 239 245 minecraft:green_terracotta
setblock 407 225 246 minecraft:lime_terracotta
fill 407 225 247 407 239 247 minecraft:green_terracotta
setblock 407 225 250 minecraft:lime_terracotta
fill 407 225 251 407 225 253 minecraft:green_terracotta
fill 408 225 248 408 239 248 minecraft:green_terracotta
fill 418 225 231 418 227 231 minecraft:green_terracotta
fill 418 225 241 418 229 241 minecraft:green_terracotta
fill 418 225 261 418 226 261 minecraft:green_terracotta
setblock 418 225 262 minecraft:green_concrete
setblock 376 226 236 minecraft:lime_terracotta
setblock 376 226 255 minecraft:lime_terracotta
fill 376 226 260 376 227 260 minecraft:lime_terracotta
setblock 376 226 268 minecraft:lime_terracotta
setblock 376 226 270 minecraft:lime_terracotta
setblock 378 226 270 minecraft:green_concrete
setblock 379 226 239 minecraft:light[level=15]
setblock 379 226 247 minecraft:light[level=15]
setblock 379 226 255 minecraft:light[level=15]
fill 380 226 270 380 227 270 minecraft:green_terracotta
setblock 381 226 270 minecraft:lime_terracotta
fill 382 226 270 382 227 270 minecraft:green_terracotta
setblock 386 226 244 minecraft:lime_terracotta
fill 386 226 245 386 227 247 minecraft:green_terracotta
setblock 386 226 248 minecraft:lime_terracotta
fill 386 226 249 386 226 251 minecraft:green_terracotta
setblock 386 226 252 minecraft:lime_terracotta
fill 386 226 270 386 229 270 minecraft:green_terracotta
setblock 387 226 228 minecraft:green_concrete
setblock 387 226 231 minecraft:light[level=15]
setblock 387 226 239 minecraft:light[level=15]
setblock 387 226 241 minecraft:lime_terracotta
fill 387 226 242 387 239 242 minecraft:green_terracotta
fill 387 226 246 387 240 246 minecraft:green_terracotta
fill 387 226 248 388 241 248 minecraft:green_terracotta
fill 387 226 250 387 239 252 minecraft:green_terracotta
setblock 387 226 253 minecraft:lime_terracotta
fill 387 226 254 387 234 255 minecraft:green_terracotta
setblock 387 226 263 minecraft:light[level=15]
fill 388 226 228 388 229 228 minecraft:green_terracotta
fill 388 226 239 388 227 239 minecraft:brown_terracotta
fill 388 226 255 388 240 255 minecraft:green_terracotta
setblock 388 226 257 minecraft:green_terracotta
setblock 389 226 238 minecraft:brown_terracotta
fill 389 226 239 389 239 240 minecraft:green_terracotta
fill 389 226 256 389 227 256 minecraft:green_terracotta
fill 389 226 258 389 232 258 minecraft:green_terracotta
setblock 390 226 237 minecraft:brown_terracotta
fill 390 226 238 390 239 238 minecraft:green_terracotta
fill 390 226 259 390 238 259 minecraft:green_terracotta
setblock 391 226 228 minecraft:lime_terracotta
setblock 391 226 236 minecraft:brown_terracotta
fill 391 226 237 391 239 237 minecraft:green_terracotta
fill 391 226 260 391 232 260 minecraft:green_terracotta
fill 392 226 235 393 226 235 minecraft:brown_terracotta
fill 392 226 236 393 230 236 minecraft:green_terracotta
setblock 392 226 253 minecraft:green_terracotta
setblock 392 226 254 minecraft:red_terracotta
setblock 392 226 258 minecraft:red_terracotta
setblock 392 226 259 minecraft:green_terracotta
fill 392 226 261 394 231 261 minecraft:green_terracotta
fill 393 226 252 394 226 252 minecraft:green_terracotta
setblock 393 226 253 minecraft:red_terracotta
setblock 393 226 259 minecraft:red_terracotta
setblock 393 226 260 minecraft:green_terracotta
setblock 394 226 228 minecraft:moss_block
fill 394 226 234 400 226 234 minecraft:brown_terracotta
fill 394 226 235 400 229 235 minecraft:green_terracotta
fill 394 226 262 395 230 262 minecraft:green_terracotta
setblock 394 226 270 minecraft:lime_terracotta
fill 395 226 228 395 229 228 minecraft:green_terracotta
setblock 395 226 231 minecraft:light[level=15]
fill 395 226 252 396 226 252 minecraft:red_terracotta
setblock 395 226 263 minecraft:light[level=15]
setblock 396 226 262 minecraft:lime_terracotta
setblock 397 226 253 minecraft:red_terracotta
setblock 397 226 259 minecraft:red_terracotta
fill 397 226 260 398 226 260 minecraft:green_terracotta
fill 397 226 262 399 232 262 minecraft:green_terracotta
setblock 398 226 228 minecraft:lime_terracotta
setblock 398 226 254 minecraft:red_terracotta
setblock 398 226 258 minecraft:red_terracotta
setblock 398 226 259 minecraft:green_terracotta
fill 398 226 261 398 234 261 minecraft:green_terracotta
setblock 400 226 262 minecraft:lime_terracotta
setblock 400 226 270 minecraft:lime_terracotta
fill 401 226 235 402 226 235 minecraft:brown_terracotta
fill 401 226 236 402 230 236 minecraft:green_terracotta
fill 401 226 260 401 234 261 minecraft:green_terracotta
fill 401 226 270 402 226 270 minecraft:green_terracotta
fill 402 226 261 402 239 261 minecraft:green_terracotta
setblock 403 226 231 minecraft:light[level=15]
setblock 403 226 236 minecraft:brown_terracotta
fill 403 226 237 403 231 237 minecraft:green_terracotta
fill 403 226 260 403 232 260 minecraft:green_terracotta
setblock 403 226 263 minecraft:light[level=15]
setblock 403 226 270 minecraft:lime_terracotta
setblock 404 226 237 minecraft:brown_terracotta
fill 404 226 238 404 239 238 minecraft:green_terracotta
fill 404 226 259 404 236 259 minecraft:green_terracotta
setblock 405 226 238 minecraft:brown_terracotta
fill 405 226 239 405 239 240 minecraft:green_terracotta
fill 405 226 256 405 232 256 minecraft:green_terracotta
fill 405 226 258 405 233 258 minecraft:green_terracotta
fill 406 226 239 406 227 239 minecraft:brown_terracotta
setblock 406 226 240 minecraft:lime_terracotta
fill 406 226 241 406 240 241 minecraft:green_terracotta
fill 406 226 254 407 231 255 minecraft:green_terracotta
setblock 406 226 256 minecraft:lime_terracotta
fill 406 226 257 406 232 257 minecraft:green_terracotta
setblock 406 226 270 minecraft:lime_terracotta
setblock 407 226 241 minecraft:lime_terracotta
fill 407 226 242 407 233 242 minecraft:green_terracotta
fill 407 226 246 407 240 246 minecraft:green_terracotta
fill 407 226 250 407 232 252 minecraft:green_terracotta
setblock 407 226 253 minecraft:lime_terracotta
fill 408 226 244 408 226 245 minecraft:green_terracotta
setblock 408 226 246 minecraft:lime_terracotta
fill 408 226 247 408 233 247 minecraft:green_terracotta
fill 408 226 249 408 238 249 minecraft:green_terracotta
setblock 408 226 250 minecraft:lime_terracotta
fill 408 226 251 408 232 252 minecraft:green_terracotta
fill 408 226 270 408 229 270 minecraft:green_terracotta
fill 409 226 270 410 226 270 minecraft:lime_terracotta
setblock 411 226 239 minecraft:light[level=15]
setblock 411 226 247 minecraft:light[level=15]
setblock 411 226 255 minecraft:light[level=15]
setblock 411 226 263 minecraft:light[level=15]
setblock 416 226 228 minecraft:lime_terracotta
fill 418 226 229 418 226 230 minecraft:lime_terracotta
setblock 418 226 240 minecraft:lime_terracotta
setblock 418 226 248 minecraft:lime_terracotta
setblock 418 226 259 minecraft:lime_terracotta
fill 418 226 262 418 229 262 minecraft:green_terracotta
setblock 418 226 265 minecraft:lime_terracotta
fill 418 226 266 418 227 266 minecraft:green_terracotta
fill 418 226 267 418 226 268 minecraft:lime_terracotta
fill 418 226 269 418 226 270 minecraft:green_terracotta
fill 376 227 228 376 228 228 minecraft:lime_terracotta
fill 376 227 229 376 229 229 minecraft:green_terracotta
setblock 376 227 236 minecraft:green_terracotta
setblock 376 227 237 minecraft:lime_terracotta
setblock 376 227 247 minecraft:lime_terracotta
fill 376 227 250 376 227 252 minecraft:lime_terracotta
fill 376 227 255 376 229 255 minecraft:green_terracotta
setblock 376 227 257 minecraft:lime_terracotta
setblock 376 227 262 minecraft:lime_terracotta
fill 376 227 268 376 228 268 minecraft:green_terracotta
fill 376 227 270 376 231 270 minecraft:green_terracotta
fill 377 227 229 384 228 269 minecraft:oak_leaves[persistent=true]
fill 378 227 270 378 229 270 minecraft:green_terracotta
fill 381 227 270 381 229 270 minecraft:green_terracotta
fill 385 227 229 385 227 245 minecraft:oak_leaves[persistent=true]
setblock 385 227 246 minecraft:lime_terracotta
fill 385 227 247 385 227 249 minecraft:green_terracotta
setblock 385 227 250 minecraft:lime_terracotta
fill 385 227 251 385 227 269 minecraft:oak_leaves[persistent=true]
fill 386 227 229 386 227 241 minecraft:oak_leaves[persistent=true]
setblock 386 227 242 minecraft:green_terracotta
setblock 386 227 243 minecraft:lime_terracotta
fill 386 227 244 386 232 244 minecraft:green_terracotta
fill 386 227 248 386 229 250 minecraft:green_terracotta
setblock 386 227 251 minecraft:lime_terracotta
fill 386 227 252 386 227 254 minecraft:green_terracotta
fill 386 227 255 386 227 269 minecraft:oak_leaves[persistent=true]
fill 387 227 228 387 229 228 minecraft:green_terracotta
fill 387 227 229 387 227 239 minecraft:oak_leaves[persistent=true]
setblock 387 227 240 minecraft:lime_terracotta
fill 387 227 241 387 237 241 minecraft:green_terracotta
fill 387 227 253 387 240 253 minecraft:green_terracotta
setblock 387 227 256 minecraft:lime_terracotta
fill 387 227 257 387 227 269 minecraft:oak_leaves[persistent=true]
fill 388 227 229 388 227 237 minecraft:oak_leaves[persistent=true]
fill 388 227 238 388 228 238 minecraft:brown_terracotta
setblock 388 227 257 minecraft:lime_terracotta
fill 388 227 258 388 232 258 minecraft:green_terracotta
fill 388 227 259 388 227 269 minecraft:oak_leaves[persistent=true]
fill 389 227 229 389 227 236 minecraft:oak_leaves[persistent=true]
setblock 389 227 237 minecraft:brown_terracotta
fill 389 227 238 389 238 238 minecraft:green_terracotta
fill 389 227 259 389 231 259 minecraft:green_terracotta
fill 389 227 260 389 227 269 minecraft:oak_leaves[persistent=true]
fill 390 227 229 390 227 235 minecraft:oak_leaves[persistent=true]
setblock 390 227 236 minecraft:brown_terracotta
fill 390 227 237 390 238 237 minecraft:green_terracotta
fill 390 227 260 390 232 260 minecraft:green_terracotta
fill 390 227 261 390 227 269 minecraft:oak_leaves[persistent=true]
fill 391 227 228 391 229 228 minecraft:green_terracotta
fill 391 227 229 391 227 234 minecraft:oak_leaves[persistent=true]
setblock 391 227 235 minecraft:brown_terracotta
fill 391 227 236 391 238 236 minecraft:green_terracotta
fill 391 227 252 391 227 253 minecraft:green_terracotta
fill 391 227 254 392 227 254 minecraft:smooth_sandstone
fill 391 227 255 391 227 257 minecraft:ochre_froglight
fill 391 227 258 392 227 258 minecraft:smooth_sandstone
fill 391 227 261 391 232 261 minecraft:green_terracotta
fill 391 227 262 391 227 269 minecraft:oak_leaves[persistent=true]
fill 392 227 229 394 227 233 minecraft:oak_leaves[persistent=true]
fill 392 227 234 394 227 234 minecraft:brown_terracotta
fill 392 227 235 393 229 235 minecraft:green_terracotta
setblock 392 227 253 minecraft:ochre_froglight
setblock 392 227 259 minecraft:ochre_froglight
fill 392 227 262 392 230 262 minecraft:green_terracotta
fill 392 227 263 394 227 269 minecraft:oak_leaves[persistent=true]
fill 393 227 252 393 227 253 minecraft:smooth_sandstone
fill 393 227 259 393 227 260 minecraft:smooth_sandstone
setblock 393 227 262 minecraft:lime_terracotta
fill 394 227 228 394 229 228 minecraft:green_terracotta
fill 394 227 252 396 227 252 minecraft:ochre_froglight
fill 394 227 260 396 227 260 minecraft:ochre_froglight
fill 394 227 270 394 229 270 minecraft:green_terracotta
fill 395 227 229 417 228 232 minecraft:oak_leaves[persistent=true]
fill 395 227 233 399 228 233 minecraft:brown_terracotta
fill 395 227 234 399 228 234 minecraft:green_terracotta
fill 395 227 251 396 227 251 minecraft:red_terracotta
fill 395 227 263 397 227 263 minecraft:green_terracotta
fill 395 227 264 417 227 269 minecraft:oak_leaves[persistent=true]
fill 396 227 262 396 233 262 minecraft:green_terracotta
fill 397 227 251 398 227 251 minecraft:green_terracotta
fill 397 227 252 397 227 253 minecraft:smooth_sandstone
fill 397 227 259 397 227 260 minecraft:smooth_sandstone
fill 398 227 228 398 229 228 minecraft:green_terracotta
fill 398 227 252 399 227 252 minecraft:green_terracotta
setblock 398 227 253 minecraft:ochre_froglight
fill 398 227 254 399 227 254 minecraft:smooth_sandstone
fill 398 227 258 399 227 258 minecraft:smooth_sandstone
setblock 398 227 259 minecraft:ochre_froglight
fill 398 227 260 398 229 260 minecraft:green_terracotta
setblock 398 227 263 minecraft:lime_terracotta
fill 399 227 253 400 227 253 minecraft:green_terracotta
fill 399 227 255 399 227 257 minecraft:ochre_froglight
setblock 399 227 263 minecraft:green_terracotta
setblock 399 227 270 minecraft:lime_terracotta
fill 400 227 233 417 227 233 minecraft:oak_leaves[persistent=true]
fill 400 227 234 402 227 234 minecraft:brown_terracotta
fill 400 227 254 401 227 254 minecraft:green_terracotta
fill 400 227 262 400 233 262 minecraft:green_terracotta
fill 400 227 263 417 227 263 minecraft:oak_leaves[persistent=true]
fill 400 227 270 401 229 270 minecraft:green_terracotta
fill 401 227 235 402 229 235 minecraft:green_terracotta
setblock 401 227 262 minecraft:lime_terracotta
setblock 402 227 228 minecraft:lime_terracotta
setblock 402 227 262 minecraft:green_terracotta
setblock 402 227 270 minecraft:lime_terracotta
fill 403 227 234 417 227 234 minecraft:oak_leaves[persistent=true]
setblock 403 227 235 minecraft:brown_terracotta
fill 403 227 236 403 230 236 minecraft:green_terracotta
fill 403 227 261 403 232 261 minecraft:green_terracotta
fill 403 227 262 417 227 262 minecraft:oak_leaves[persistent=true]
fill 403 227 270 403 229 270 minecraft:green_terracotta
fill 404 227 235 417 227 235 minecraft:oak_leaves[persistent=true]
setblock 404 227 236 minecraft:brown_terracotta
fill 404 227 237 404 238 237 minecraft:green_terracotta
fill 404 227 260 404 232 260 minecraft:green_terracotta
fill 404 227 261 417 227 261 minecraft:oak_leaves[persistent=true]
fill 405 227 236 417 227 236 minecraft:oak_leaves[persistent=true]
setblock 405 227 237 minecraft:brown_terracotta
fill 405 227 238 405 238 238 minecraft:green_terracotta
fill 405 227 259 405 237 259 minecraft:green_terracotta
fill 405 227 260 417 227 260 minecraft:oak_leaves[persistent=true]
fill 406 227 237 417 227 237 minecraft:oak_leaves[persistent=true]
fill 406 227 238 406 228 238 minecraft:brown_terracotta
fill 406 227 240 406 232 240 minecraft:green_terracotta
fill 406 227 256 406 231 256 minecraft:green_terracotta
setblock 406 227 258 minecraft:green_terracotta
fill 406 227 259 417 227 259 minecraft:oak_leaves[persistent=true]
fill 406 227 270 406 230 270 minecraft:green_terracotta
fill 407 227 238 417 227 239 minecraft:oak_leaves[persistent=true]
setblock 407 227 240 minecraft:lime_terracotta
fill 407 227 241 407 237 241 minecraft:green_terracotta
fill 407 227 253 407 232 253 minecraft:green_terracotta
setblock 407 227 256 minecraft:lime_terracotta
fill 407 227 257 417 227 258 minecraft:oak_leaves[persistent=true]
fill 408 227 240 417 227 241 minecraft:oak_leaves[persistent=true]
fill 408 227 242 408 233 244 minecraft:green_terracotta
setblock 408 227 245 minecraft:lime_terracotta
fill 408 227 246 408 239 246 minecraft:green_terracotta
fill 408 227 250 408 239 250 minecraft:green_terracotta
setblock 408 227 253 minecraft:lime_terracotta
fill 408 227 254 408 231 254 minecraft:green_terracotta
fill 408 227 255 417 227 256 minecraft:oak_leaves[persistent=true]
fill 409 227 242 417 227 245 minecraft:oak_leaves[persistent=true]
setblock 409 227 246 minecraft:lime_terracotta
fill 409 227 247 409 227 249 minecraft:green_terracotta
setblock 409 227 250 minecraft:lime_terracotta
fill 409 227 251 417 227 254 minecraft:oak_leaves[persistent=true]
fill 409 227 270 410 229 270 minecraft:green_terracotta
fill 410 227 246 417 228 250 minecraft:oak_leaves[persistent=true]
setblock 411 227 270 minecraft:lime_terracotta
setblock 416 227 228 minecraft:green_terracotta
fill 418 227 229 418 229 230 minecraft:green_terracotta
setblock 418 227 234 minecraft:lime_terracotta
fill 418 227 235 418 229 235 minecraft:green_terracotta
fill 418 227 236 418 228 236 minecraft:lime_terracotta
fill 418 227 237 418 229 237 minecraft:green_terracotta
fill 418 227 240 418 229 240 minecraft:green_terracotta
fill 418 227 248 418 229 248 minecraft:green_terracotta
setblock 418 227 249 minecraft:lime_terracotta
fill 418 227 259 418 229 259 minecraft:green_terracotta
setblock 418 227 261 minecraft:lime_terracotta
fill 418 227 265 418 229 265 minecraft:green_terracotta
fill 418 227 267 418 229 269 minecraft:green_terracotta
setblock 418 227 270 minecraft:lime_terracotta
setblock 376 228 232 minecraft:lime_terracotta
setblock 376 228 236 minecraft:lime_terracotta
fill 376 228 237 376 229 237 minecraft:green_terracotta
setblock 376 228 245 minecraft:lime_terracotta
setblock 376 228 247 minecraft:green_terracotta
fill 376 228 250 376 229 252 minecraft:green_terracotta
fill 376 228 257 376 229 257 minecraft:green_terracotta
fill 376 228 260 376 230 260 minecraft:green_terracotta
setblock 376 228 262 minecraft:jungle_leaves[persistent=true]
setblock 380 228 270 minecraft:lime_terracotta
setblock 382 228 270 minecraft:lime_terracotta
setblock 384 228 228 minecraft:lime_terracotta
fill 385 228 229 385 228 242 minecraft:oak_leaves[persistent=true]
fill 385 228 243 385 228 244 minecraft:green_terracotta
setblock 385 228 245 minecraft:lime_terracotta
fill 385 228 246 385 232 248 minecraft:green_terracotta
setblock 385 228 249 minecraft:lime_terracotta
fill 385 228 250 385 228 252 minecraft:green_terracotta
setblock 385 228 253 minecraft:lime_terracotta
fill 385 228 254 385 228 269 minecraft:oak_leaves[persistent=true]
fill 386 228 229 386 228 240 minecraft:oak_leaves[persistent=true]
setblock 386 228 241 minecraft:green_terracotta
setblock 386 228 242 minecraft:lime_terracotta
fill 386 228 243 386 238 243 minecraft:green_terracotta
fill 386 228 245 386 231 246 minecraft:green_terracotta
fill 386 228 247 386 229 247 minecraft:bone_block
fill 386 228 251 386 234 253 minecraft:green_terracotta
setblock 386 228 254 minecraft:lime_terracotta
fill 386 228 255 386 233 255 minecraft:green_terracotta
fill 386 228 256 386 234 256 minecraft:bone_block
fill 386 228 257 386 228 264 minecraft:oak_leaves[persistent=true]
fill 386 228 265 386 229 265 minecraft:bone_block
fill 386 228 266 417 228 269 minecraft:oak_leaves[persistent=true]
fill 387 228 229 387 228 238 minecraft:oak_leaves[persistent=true]
fill 387 228 239 387 229 239 minecraft:brown_terracotta
fill 387 228 240 387 232 240 minecraft:green_terracotta
fill 387 228 256 387 233 257 minecraft:green_terracotta
fill 387 228 258 387 228 265 minecraft:oak_leaves[persistent=true]
fill 388 228 229 388 229 236 minecraft:oak_leaves[persistent=true]
fill 388 228 237 388 230 237 minecraft:brown_terracotta
fill 388 228 239 388 232 239 minecraft:green_terracotta
fill 388 228 247 388 241 247 minecraft:green_terracotta
fill 388 228 257 388 233 257 minecraft:green_terracotta
setblock 388 228 259 minecraft:green_terracotta
fill 388 228 260 388 229 265 minecraft:oak_leaves[persistent=true]
fill 389 228 229 389 229 235 minecraft:oak_leaves[persistent=true]
fill 389 228 236 389 229 236 minecraft:brown_terracotta
fill 389 228 237 389 233 237 minecraft:green_terracotta
fill 389 228 247 389 229 247 minecraft:bone_block
fill 389 228 256 389 234 256 minecraft:bone_block
setblock 389 228 260 minecraft:green_terracotta
fill 389 228 261 389 229 264 minecraft:oak_leaves[persistent=true]
fill 389 228 265 389 229 265 minecraft:bone_block
fill 390 228 229 390 229 234 minecraft:oak_leaves[persistent=true]
fill 390 228 235 390 229 235 minecraft:brown_terracotta
fill 390 228 236 390 237 236 minecraft:green_terracotta
fill 390 228 247 390 236 247 minecraft:green_terracotta
setblock 390 228 261 minecraft:green_terracotta
fill 390 228 262 390 229 265 minecraft:oak_leaves[persistent=true]
fill 391 228 229 392 228 233 minecraft:oak_leaves[persistent=true]
fill 391 228 234 392 228 234 minecraft:brown_terracotta
fill 391 228 235 391 237 235 minecraft:green_terracotta
setblock 391 228 252 minecraft:green_terracotta
fill 391 228 253 391 228 258 minecraft:pink_terracotta
setblock 391 228 262 minecraft:green_terracotta
fill 391 228 263 391 229 265 minecraft:oak_leaves[persistent=true]
setblock 392 228 228 minecraft:lime_terracotta
fill 392 228 247 392 229 247 minecraft:bone_block
setblock 392 228 251 minecraft:green_terracotta
setblock 392 228 252 minecraft:pink_terracotta
setblock 392 228 259 minecraft:pink_terracotta
fill 392 228 263 392 228 264 minecraft:oak_leaves[persistent=true]
fill 392 228 265 392 229 265 minecraft:bone_block
fill 393 228 229 394 229 232 minecraft:oak_leaves[persistent=true]
fill 393 228 233 394 229 233 minecraft:brown_terracotta
fill 393 228 234 394 229 234 minecraft:green_terracotta
fill 393 228 247 394 231 247 minecraft:green_terracotta
fill 393 228 251 394 228 251 minecraft:pink_terracotta
setblock 393 228 252 minecraft:light[level=12]
setblock 393 228 259 minecraft:light[level=12]
fill 393 228 260 397 228 260 minecraft:pink_terracotta
fill 393 228 262 393 229 263 minecraft:green_terracotta
fill 393 228 264 394 229 265 minecraft:oak_leaves[persistent=true]
fill 394 228 263 394 231 263 minecraft:green_terracotta
fill 395 228 247 395 229 247 minecraft:bone_block
setblock 395 228 250 minecraft:pink_terracotta
setblock 395 228 263 minecraft:lime_terracotta
fill 395 228 264 417 228 264 minecraft:oak_leaves[persistent=true]
fill 395 228 265 395 229 265 minecraft:bone_block
fill 396 228 247 397 231 247 minecraft:green_terracotta
fill 396 228 250 397 228 250 minecraft:green_terracotta
fill 396 228 251 397 228 251 minecraft:pink_terracotta
fill 396 228 263 398 231 263 minecraft:green_terracotta
fill 396 228 265 397 229 265 minecraft:oak_leaves[persistent=true]
fill 398 228 247 398 229 247 minecraft:bone_block
setblock 398 228 251 minecraft:green_terracotta
setblock 398 228 252 minecraft:pink_terracotta
setblock 398 228 259 minecraft:pink_terracotta
fill 398 228 265 398 229 265 minecraft:bone_block
setblock 399 228 252 minecraft:green_terracotta
setblock 399 228 253 minecraft:pink_terracotta
setblock 399 228 258 minecraft:pink_terracotta
setblock 399 228 263 minecraft:lime_terracotta
fill 399 228 265 400 230 265 minecraft:oak_leaves[persistent=true]
fill 399 228 270 399 229 270 minecraft:green_terracotta
fill 400 228 233 401 229 233 minecraft:brown_terracotta
fill 400 228 234 401 229 234 minecraft:green_terracotta
fill 400 228 247 400 233 247 minecraft:green_terracotta
setblock 400 228 253 minecraft:green_terracotta
fill 400 228 254 400 228 257 minecraft:pink_terracotta
fill 400 228 258 400 229 259 minecraft:green_terracotta
fill 400 228 263 401 228 263 minecraft:green_terracotta
fill 401 228 247 401 229 247 minecraft:bone_block
fill 401 228 254 401 229 255 minecraft:green_terracotta
fill 401 228 256 401 234 256 minecraft:bone_block
fill 401 228 262 401 232 262 minecraft:green_terracotta
fill 401 228 265 401 229 265 minecraft:bone_block
fill 402 228 228 402 229 228 minecraft:green_terracotta
fill 402 228 233 417 228 233 minecraft:oak_leaves[persistent=true]
fill 402 228 234 403 228 234 minecraft:brown_terracotta
fill 402 228 247 402 235 247 minecraft:green_terracotta
fill 402 228 255 402 232 256 minecraft:green_terracotta
setblock 402 228 262 minecraft:lime_terracotta
fill 402 228 263 417 228 263 minecraft:oak_leaves[persistent=true]
fill 402 228 265 403 230 265 minecraft:oak_leaves[persistent=true]
fill 402 228 270 402 229 270 minecraft:green_terracotta
setblock 403 228 228 minecraft:lime_terracotta
fill 403 228 235 403 237 235 minecraft:green_terracotta
fill 403 228 256 403 236 256 minecraft:green_terracotta
setblock 403 228 262 minecraft:green_terracotta
fill 404 228 234 417 229 234 minecraft:oak_leaves[persistent=true]
fill 404 228 235 404 229 235 minecraft:brown_terracotta
fill 404 228 236 404 237 236 minecraft:green_terracotta
fill 404 228 247 404 229 247 minecraft:bone_block
fill 404 228 256 404 235 256 minecraft:bone_block
fill 404 228 261 404 231 261 minecraft:green_terracotta
fill 404 228 262 417 228 262 minecraft:oak_leaves[persistent=true]
fill 404 228 265 404 229 265 minecraft:bone_block
setblock 404 228 270 minecraft:lime_terracotta
fill 405 228 235 417 229 235 minecraft:oak_leaves[persistent=true]
fill 405 228 236 405 229 236 minecraft:brown_terracotta
fill 405 228 237 405 237 237 minecraft:green_terracotta
fill 405 228 247 406 240 247 minecraft:green_terracotta
setblock 405 228 260 minecraft:green_terracotta
fill 405 228 261 417 229 261 minecraft:oak_leaves[persistent=true]
fill 405 228 265 417 228 265 minecraft:oak_leaves[persistent=true]
fill 406 228 236 417 229 236 minecraft:oak_leaves[persistent=true]
fill 406 228 237 406 230 237 minecraft:brown_terracotta
fill 406 228 239 406 232 239 minecraft:green_terracotta
setblock 406 228 258 minecraft:lime_terracotta
fill 406 228 259 406 233 259 minecraft:green_terracotta
fill 406 228 260 417 229 260 minecraft:oak_leaves[persistent=true]
fill 407 228 237 417 228 238 minecraft:oak_leaves[persistent=true]
fill 407 228 239 407 229 239 minecraft:brown_terracotta
fill 407 228 240 407 238 240 minecraft:green_terracotta
fill 407 228 256 407 231 257 minecraft:green_terracotta
fill 407 228 258 417 228 259 minecraft:oak_leaves[persistent=true]
fill 408 228 239 417 228 240 minecraft:oak_leaves[persistent=true]
fill 408 228 241 408 232 241 minecraft:green_terracotta
fill 408 228 245 408 233 245 minecraft:green_terracotta
fill 408 228 253 408 232 253 minecraft:green_terracotta
setblock 408 228 255 minecraft:green_terracotta
fill 408 228 256 417 228 257 minecraft:oak_leaves[persistent=true]
fill 409 228 241 417 228 242 minecraft:oak_leaves[persistent=true]
fill 409 228 243 409 228 244 minecraft:green_terracotta
setblock 409 228 245 minecraft:lime_terracotta
fill 409 228 246 409 232 248 minecraft:green_terracotta
setblock 409 228 249 minecraft:lime_terracotta
fill 409 228 250 409 228 252 minecraft:green_terracotta
setblock 409 228 253 minecraft:lime_terracotta
fill 409 228 254 417 228 255 minecraft:oak_leaves[persistent=true]
fill 410 228 243 417 228 245 minecraft:oak_leaves[persistent=true]
fill 410 228 251 417 229 253 minecraft:oak_leaves[persistent=true]
fill 411 228 270 411 230 270 minecraft:green_terracotta
setblock 414 228 270 minecraft:lime_terracotta
setblock 416 228 228 minecraft:lime_terracotta
setblock 418 228 231 minecraft:lime_terracotta
fill 418 228 234 418 229 234 minecraft:green_terracotta
setblock 418 228 238 minecraft:lime_terracotta
fill 418 228 249 418 229 249 minecraft:green_terracotta
setblock 418 228 252 minecraft:lime_terracotta
fill 418 228 261 418 229 261 minecraft:green_terracotta
setblock 418 228 263 minecraft:lime_terracotta
setblock 418 228 266 minecraft:green_concrete
fill 418 228 270 418 230 270 minecraft:green_terracotta
setblock 376 229 228 minecraft:green_terracotta
setblock 376 229 232 minecraft:green_terracotta
setblock 376 229 236 minecraft:green_terracotta
setblock 376 229 245 minecraft:green_terracotta
setblock 376 229 247 minecraft:moss_block
setblock 376 229 262 minecraft:green_terracotta
setblock 376 229 268 minecraft:moss_block
fill 377 229 229 380 230 269 minecraft:oak_leaves[persistent=true]
setblock 380 229 270 minecraft:green_terracotta
fill 381 229 229 381 230 249 minecraft:oak_leaves[persistent=true]
fill 381 229 250 381 230 250 minecraft:jungle_leaves[persistent=true]
fill 381 229 251 381 230 269 minecraft:oak_leaves[persistent=true]
fill 382 229 229 383 229 243 minecraft:oak_leaves[persistent=true]
fill 382 229 244 382 230 244 minecraft:azalea_leaves[persistent=true]
fill 382 229 245 383 229 255 minecraft:oak_leaves[persistent=true]
fill 382 229 256 382 230 256 minecraft:jungle_leaves[persistent=true]
fill 382 229 257 385 229 269 minecraft:oak_leaves[persistent=true]
setblock 382 229 270 minecraft:green_terracotta
fill 383 229 244 384 229 244 minecraft:oak_leaves[persistent=true]
fill 383 229 256 385 229 256 minecraft:oak_leaves[persistent=true]
setblock 383 229 270 minecraft:moss_block
setblock 384 229 228 minecraft:green_terracotta
fill 384 229 229 387 230 236 minecraft:oak_leaves[persistent=true]
fill 384 229 237 384 230 237 minecraft:azalea_leaves[persistent=true]
fill 384 229 238 384 229 243 minecraft:oak_leaves[persistent=true]
fill 384 229 245 384 229 247 minecraft:oak_leaves[persistent=true]
fill 384 229 248 384 231 248 minecraft:green_terracotta
fill 384 229 249 384 229 255 minecraft:oak_leaves[persistent=true]
fill 385 229 237 385 229 241 minecraft:oak_leaves[persistent=true]
fill 385 229 242 385 229 243 minecraft:green_terracotta
setblock 385 229 244 minecraft:lime_terracotta
fill 385 229 245 385 231 245 minecraft:green_terracotta
fill 385 229 249 385 231 251 minecraft:green_terracotta
setblock 385 229 252 minecraft:lime_terracotta
fill 385 229 253 385 230 254 minecraft:green_terracotta
setblock 385 229 255 minecraft:oak_leaves[persistent=true]
fill 386 229 237 386 229 239 minecraft:oak_leaves[persistent=true]
setblock 386 229 240 minecraft:green_terracotta
setblock 386 229 241 minecraft:lime_terracotta
fill 386 229 242 386 232 242 minecraft:green_terracotta
fill 386 229 254 386 236 254 minecraft:green_terracotta
fill 386 229 257 386 229 261 minecraft:oak_leaves[persistent=true]
fill 386 229 262 386 230 262 minecraft:green_concrete
fill 386 229 263 387 229 264 minecraft:oak_leaves[persistent=true]
fill 386 229 266 394 230 269 minecraft:oak_leaves[persistent=true]
fill 387 229 237 387 230 237 minecraft:oak_leaves[persistent=true]
fill 387 229 238 387 232 238 minecraft:brown_terracotta
setblock 387 229 258 minecraft:lime_terracotta
fill 387 229 259 387 229 262 minecraft:oak_leaves[persistent=true]
fill 387 229 265 387 230 265 minecraft:oak_leaves[persistent=true]
fill 388 229 238 388 233 238 minecraft:green_terracotta
setblock 388 229 259 minecraft:lime_terracotta
setblock 389 229 260 minecraft:lime_terracotta
fill 390 229 254 390 230 256 minecraft:red_terracotta
fill 390 229 257 390 235 257 minecraft:green_terracotta
setblock 390 229 261 minecraft:lime_terracotta
fill 391 229 229 391 230 233 minecraft:oak_leaves[persistent=true]
fill 391 229 234 391 230 234 minecraft:brown_terracotta
fill 391 229 250 392 229 250 minecraft:green_terracotta
fill 391 229 252 391 229 253 minecraft:red_terracotta
fill 391 229 257 391 230 258 minecraft:red_terracotta
setblock 391 229 262 minecraft:lime_terracotta
setblock 392 229 228 minecraft:green_terracotta
fill 392 229 229 392 230 232 minecraft:oak_leaves[persistent=true]
fill 392 229 233 392 236 233 minecraft:brown_terracotta
fill 392 229 234 392 230 234 minecraft:green_concrete
setblock 392 229 251 minecraft:red_terracotta
fill 392 229 259 392 230 259 minecraft:red_terracotta
setblock 392 229 263 minecraft:lime_terracotta
setblock 392 229 264 minecraft:jungle_leaves[persistent=true]
fill 393 229 250 397 229 250 minecraft:red_terracotta
fill 393 229 260 397 230 260 minecraft:red_terracotta
fill 395 229 229 417 230 231 minecraft:oak_leaves[persistent=true]
fill 395 229 232 399 236 232 minecraft:brown_terracotta
fill 395 229 233 395 229 234 minecraft:green_terracotta
fill 395 229 263 395 229 264 minecraft:green_terracotta
fill 395 229 266 395 231 266 minecraft:jungle_leaves[persistent=true]
fill 395 229 267 417 230 269 minecraft:oak_leaves[persistent=true]
fill 396 229 233 396 230 234 minecraft:jungle_leaves[persistent=true]
fill 396 229 264 396 231 264 minecraft:green_terracotta
fill 396 229 266 417 229 266 minecraft:oak_leaves[persistent=true]
fill 397 229 233 399 229 234 minecraft:green_terracotta
setblock 397 229 264 minecraft:lime_terracotta
setblock 398 229 251 minecraft:red_terracotta
setblock 398 229 259 minecraft:red_terracotta
fill 398 229 264 399 229 264 minecraft:green_terracotta
setblock 399 229 252 minecraft:red_terracotta
setblock 399 229 258 minecraft:red_terracotta
fill 399 229 263 399 232 263 minecraft:green_terracotta
fill 400 229 232 417 229 232 minecraft:oak_leaves[persistent=true]
fill 400 229 253 400 229 257 minecraft:red_terracotta
setblock 400 229 263 minecraft:lime_terracotta
fill 400 229 264 417 229 264 minecraft:oak_leaves[persistent=true]
fill 401 229 263 402 229 263 minecraft:green_terracotta
fill 402 229 233 402 236 233 minecraft:brown_terracotta
fill 402 229 234 402 230 234 minecraft:jungle_leaves[persistent=true]
fill 402 229 262 402 238 262 minecraft:green_terracotta
setblock 403 229 228 minecraft:green_terracotta
fill 403 229 233 417 230 233 minecraft:oak_leaves[persistent=true]
fill 403 229 234 403 230 234 minecraft:brown_terracotta
setblock 403 229 262 minecraft:lime_terracotta
fill 403 229 263 417 229 263 minecraft:oak_leaves[persistent=true]
fill 404 229 262 408 229 262 minecraft:oak_leaves[persistent=true]
setblock 404 229 270 minecraft:green_terracotta
setblock 405 229 260 minecraft:lime_terracotta
fill 405 229 265 405 230 265 minecraft:azalea_leaves[persistent=true]
fill 406 229 238 406 236 238 minecraft:green_terracotta
fill 406 229 258 406 232 258 minecraft:green_terracotta
fill 406 229 265 417 230 265 minecraft:oak_leaves[persistent=true]
fill 407 229 237 417 230 237 minecraft:oak_leaves[persistent=true]
fill 407 229 238 407 236 238 minecraft:brown_terracotta
setblock 407 229 258 minecraft:lime_terracotta
fill 407 229 259 417 230 259 minecraft:oak_leaves[persistent=true]
fill 408 229 238 409 229 239 minecraft:oak_leaves[persistent=true]
fill 408 229 240 408 231 240 minecraft:green_terracotta
setblock 408 229 255 minecraft:lime_terracotta
fill 408 229 256 408 231 256 minecraft:green_terracotta
fill 408 229 257 417 229 258 minecraft:oak_leaves[persistent=true]
fill 409 229 240 417 229 241 minecraft:oak_leaves[persistent=true]
fill 409 229 242 409 229 243 minecraft:green_terracotta
setblock 409 229 244 minecraft:lime_terracotta
fill 409 229 245 409 232 245 minecraft:green_terracotta
fill 409 229 249 409 232 251 minecraft:green_terracotta
setblock 409 229 252 minecraft:lime_terracotta
fill 409 229 253 409 230 254 minecraft:green_terracotta
fill 409 229 255 411 229 256 minecraft:oak_leaves[persistent=true]
fill 409 229 262 409 230 262 minecraft:jungle_leaves[persistent=true]
fill 410 229 238 410 231 238 minecraft:jungle_leaves[persistent=true]
fill 410 229 239 417 229 239 minecraft:oak_leaves[persistent=true]
fill 410 229 242 412 229 247 minecraft:oak_leaves[persistent=true]
setblock 410 229 248 minecraft:green_terracotta
fill 410 229 249 417 229 250 minecraft:oak_leaves[persistent=true]
fill 410 229 254 417 229 254 minecraft:oak_leaves[persistent=true]
fill 410 229 262 417 230 262 minecraft:oak_leaves[persistent=true]
fill 411 229 238 417 229 238 minecraft:oak_leaves[persistent=true]
fill 411 229 248 412 229 248 minecraft:oak_leaves[persistent=true]
fill 412 229 255 412 230 255 minecraft:green_concrete
fill 412 229 256 417 230 256 minecraft:oak_leaves[persistent=true]
fill 413 229 242 417 230 242 minecraft:oak_leaves[persistent=true]
fill 413 229 243 413 230 243 minecraft:green_concrete
fill 413 229 244 417 229 247 minecraft:oak_leaves[persistent=true]
fill 413 229 248 413 230 248 minecraft:azalea_leaves[persistent=true]
fill 413 229 255 417 230 255 minecraft:oak_leaves[persistent=true]
fill 414 229 243 417 230 243 minecraft:oak_leaves[persistent=true]
fill 414 229 248 417 230 248 minecraft:oak_leaves[persistent=true]
setblock 414 229 270 minecraft:green_terracotta
setblock 416 229 228 minecraft:green_terracotta
setblock 418 229 231 minecraft:green_terracotta
setblock 418 229 236 minecraft:green_terracotta
setblock 418 229 238 minecraft:green_terracotta
setblock 418 229 252 minecraft:green_terracotta
setblock 418 229 253 minecraft:jungle_leaves[persistent=true]
setblock 418 229 255 minecraft:jungle_leaves[persistent=true]
setblock 418 229 263 minecraft:green_terracotta
fill 418 229 266 418 230 266 minecraft:green_terracotta
fill 376 230 228 376 230 259 minecraft:lime_terracotta
fill 376 230 261 376 245 263 minecraft:lime_terracotta
fill 376 230 265 376 230 269 minecraft:lime_terracotta
fill 377 230 228 378 243 228 minecraft:lime_terracotta
setblock 377 230 270 minecraft:jungle_leaves[persistent=true]
fill 378 230 270 389 231 270 minecraft:lime_terracotta
setblock 379 230 228 minecraft:green_terracotta
fill 380 230 228 392 230 228 minecraft:lime_terracotta
fill 382 230 229 382 230 243 minecraft:oak_leaves[persistent=true]
fill 382 230 245 383 231 245 minecraft:azalea_leaves[persistent=true]
fill 382 230 246 383 230 248 minecraft:oak_leaves[persistent=true]
fill 382 230 249 382 231 250 minecraft:jungle_leaves[persistent=true]
fill 382 230 251 382 230 255 minecraft:oak_leaves[persistent=true]
fill 382 230 257 382 230 269 minecraft:oak_leaves[persistent=true]
fill 383 230 229 383 230 237 minecraft:oak_leaves[persistent=true]
setblock 383 230 238 minecraft:jungle_leaves[persistent=true]
fill 383 230 239 383 230 242 minecraft:oak_leaves[persistent=true]
fill 383 230 243 383 231 244 minecraft:azalea_leaves[persistent=true]
fill 383 230 249 383 230 254 minecraft:oak_leaves[persistent=true]
fill 383 230 255 383 231 256 minecraft:jungle_leaves[persistent=true]
setblock 383 230 257 minecraft:azalea_leaves[persistent=true]
fill 383 230 258 385 230 269 minecraft:oak_leaves[persistent=true]
fill 384 230 238 384 231 238 minecraft:azalea_leaves[persistent=true]
setblock 384 230 239 minecraft:jungle_leaves[persistent=true]
fill 384 230 240 384 230 244 minecraft:oak_leaves[persistent=true]
setblock 384 230 245 minecraft:green_terracotta
setblock 384 230 246 minecraft:lime_terracotta
fill 384 230 247 384 231 247 minecraft:green_terracotta
setblock 384 230 249 minecraft:green_terracotta
setblock 384 230 250 minecraft:lime_terracotta
fill 384 230 251 384 232 251 minecraft:green_terracotta
fill 384 230 252 384 230 257 minecraft:oak_leaves[persistent=true]
fill 385 230 237 385 231 237 minecraft:azalea_leaves[persistent=true]
setblock 385 230 238 minecraft:jungle_leaves[persistent=true]
fill 385 230 239 385 230 240 minecraft:oak_leaves[persistent=true]
fill 385 230 241 385 230 242 minecraft:green_terracotta
setblock 385 230 243 minecraft:lime_terracotta
fill 385 230 244 385 231 244 minecraft:green_terracotta
fill 385 230 252 385 232 252 minecraft:green_terracotta
setblock 385 230 255 minecraft:lime_terracotta
fill 385 230 256 385 230 257 minecraft:oak_leaves[persistent=true]
fill 386 230 237 386 230 238 minecraft:oak_leaves[persistent=true]
setblock 386 230 239 minecraft:brown_terracotta
setblock 386 230 240 minecraft:lime_terracotta
fill 386 230 241 386 236 241 minecraft:green_terracotta
fill 386 230 247 386 233 247 minecraft:green_terracotta
fill 386 230 248 386 231 248 minecraft:bone_block
fill 386 230 249 386 231 250 minecraft:green_terracotta
fill 386 230 257 386 232 257 minecraft:green_terracotta
fill 386 230 258 386 230 260 minecraft:oak_leaves[persistent=true]
fill 386 230 261 387 231 261 minecraft:green_concrete
fill 386 230 263 390 230 263 minecraft:oak_leaves[persistent=true]
fill 386 230 264 386 231 264 minecraft:bone_block
setblock 386 230 265 minecraft:oak_leaves[persistent=true]
fill 387 230 239 387 231 239 minecraft:green_terracotta
fill 387 230 258 387 232 258 minecraft:green_terracotta
fill 387 230 259 387 230 260 minecraft:oak_leaves[persistent=true]
setblock 387 230 262 minecraft:azalea_leaves[persistent=true]
fill 387 230 264 388 230 264 minecraft:oak_leaves[persistent=true]
fill 388 230 229 388 230 235 minecraft:oak_leaves[persistent=true]
fill 388 230 236 388 235 236 minecraft:brown_terracotta
fill 388 230 259 388 230 260 minecraft:green_terracotta
fill 388 230 261 388 230 262 minecraft:oak_leaves[persistent=true]
fill 388 230 265 394 230 265 minecraft:oak_leaves[persistent=true]
fill 389 230 229 389 230 234 minecraft:oak_leaves[persistent=true]
fill 389 230 235 389 235 235 minecraft:brown_terracotta
fill 389 230 236 389 235 236 minecraft:green_terracotta
fill 389 230 247 389 238 247 minecraft:green_terracotta
fill 389 230 248 389 231 248 minecraft:bone_block
fill 389 230 260 389 230 261 minecraft:green_terracotta
setblock 389 230 262 minecraft:oak_leaves[persistent=true]
fill 389 230 264 389 231 264 minecraft:bone_block
fill 390 230 229 390 230 233 minecraft:oak_leaves[persistent=true]
fill 390 230 234 390 235 234 minecraft:brown_terracotta
fill 390 230 235 390 235 235 minecraft:green_terracotta
fill 390 230 248 391 233 248 minecraft:green_terracotta
fill 390 230 251 390 230 252 minecraft:green_terracotta
setblock 390 230 253 minecraft:red_terracotta
fill 390 230 261 390 230 262 minecraft:green_terracotta
setblock 390 230 264 minecraft:oak_leaves[persistent=true]
setblock 391 230 250 minecraft:green_terracotta
fill 391 230 251 391 230 252 minecraft:red_terracotta
setblock 391 230 262 minecraft:green_terracotta
fill 391 230 263 391 230 264 minecraft:green_concrete
fill 391 230 270 405 230 270 minecraft:lime_terracotta
fill 392 230 235 392 231 235 minecraft:green_concrete
fill 392 230 247 392 233 247 minecraft:green_terracotta
fill 392 230 248 392 231 248 minecraft:bone_block
setblock 392 230 250 minecraft:red_terracotta
fill 392 230 256 392 234 256 minecraft:bone_block
fill 392 230 263 392 231 263 minecraft:jungle_leaves[persistent=true]
fill 392 230 264 392 231 264 minecraft:bone_block
fill 393 230 229 393 230 232 minecraft:oak_leaves[persistent=true]
setblock 393 230 233 minecraft:brown_terracotta
fill 393 230 234 393 230 235 minecraft:azalea_leaves[persistent=true]
fill 393 230 248 394 230 248 minecraft:green_terracotta
fill 393 230 249 397 230 249 minecraft:red_terracotta
setblock 393 230 262 minecraft:green_terracotta
setblock 393 230 263 minecraft:azalea_leaves[persistent=true]
setblock 393 230 264 minecraft:oak_leaves[persistent=true]
fill 394 230 228 395 240 228 minecraft:lime_terracotta
fill 394 230 229 394 230 231 minecraft:oak_leaves[persistent=true]
fill 394 230 232 394 235 232 minecraft:brown_terracotta
fill 394 230 233 394 230 235 minecraft:green_terracotta
setblock 394 230 264 minecraft:lime_terracotta
fill 395 230 233 395 236 233 minecraft:green_terracotta
fill 395 230 234 395 231 235 minecraft:jungle_leaves[persistent=true]
fill 395 230 247 395 231 247 minecraft:green_terracotta
fill 395 230 248 395 231 248 minecraft:bone_block
fill 395 230 256 395 234 256 minecraft:bone_block
fill 395 230 263 395 231 263 minecraft:green_terracotta
fill 395 230 264 395 231 264 minecraft:bone_block
fill 395 230 265 395 231 265 minecraft:jungle_leaves[persistent=true]
fill 396 230 235 400 230 235 minecraft:green_terracotta
fill 396 230 265 396 231 266 minecraft:azalea_leaves[persistent=true]
fill 397 230 228 406 230 228 minecraft:lime_terracotta
fill 397 230 233 400 235 233 minecraft:green_terracotta
fill 397 230 234 397 231 234 minecraft:jungle_leaves[persistent=true]
setblock 397 230 248 minecraft:green_terracotta
setblock 397 230 264 minecraft:green_terracotta
fill 397 230 265 398 230 266 minecraft:oak_leaves[persistent=true]
fill 398 230 234 400 230 234 minecraft:green_terracotta
fill 398 230 247 398 232 247 minecraft:green_terracotta
fill 398 230 248 398 231 248 minecraft:bone_block
fill 398 230 250 399 230 250 minecraft:red_terracotta
fill 398 230 256 398 234 256 minecraft:bone_block
setblock 398 230 260 minecraft:red_terracotta
fill 398 230 264 398 231 264 minecraft:bone_block
fill 399 230 248 399 231 248 minecraft:green_terracotta
setblock 399 230 251 minecraft:red_terracotta
setblock 399 230 259 minecraft:red_terracotta
fill 399 230 264 400 230 264 minecraft:green_terracotta
fill 399 230 266 417 230 266 minecraft:oak_leaves[persistent=true]
fill 400 230 232 400 235 232 minecraft:brown_terracotta
fill 400 230 250 401 230 250 minecraft:green_terracotta
fill 400 230 252 400 230 253 minecraft:red_terracotta
fill 400 230 256 400 230 258 minecraft:red_terracotta
fill 400 230 259 400 233 259 minecraft:green_terracotta
fill 400 230 263 400 236 263 minecraft:green_terracotta
fill 401 230 232 417 230 232 minecraft:oak_leaves[persistent=true]
setblock 401 230 233 minecraft:brown_terracotta
fill 401 230 234 401 231 234 minecraft:jungle_leaves[persistent=true]
fill 401 230 235 401 232 235 minecraft:green_concrete
fill 401 230 247 401 234 247 minecraft:green_terracotta
fill 401 230 248 401 231 248 minecraft:bone_block
fill 401 230 254 401 230 255 minecraft:red_terracotta
setblock 401 230 263 minecraft:lime_terracotta
fill 401 230 264 401 231 264 minecraft:bone_block
setblock 401 230 265 minecraft:oak_leaves[persistent=true]
fill 402 230 235 402 231 235 minecraft:jungle_leaves[persistent=true]
fill 402 230 248 403 235 248 minecraft:green_terracotta
setblock 402 230 263 minecraft:green_terracotta
fill 402 230 264 403 230 264 minecraft:oak_leaves[persistent=true]
fill 403 230 262 403 232 262 minecraft:green_terracotta
fill 403 230 263 404 230 263 minecraft:oak_leaves[persistent=true]
fill 404 230 234 404 235 234 minecraft:brown_terracotta
fill 404 230 235 404 235 235 minecraft:green_terracotta
fill 404 230 247 404 238 247 minecraft:green_terracotta
fill 404 230 248 404 231 248 minecraft:bone_block
setblock 404 230 262 minecraft:lime_terracotta
fill 404 230 264 404 231 264 minecraft:bone_block
setblock 404 230 265 minecraft:green_concrete
fill 405 230 234 417 230 234 minecraft:oak_leaves[persistent=true]
fill 405 230 235 405 235 235 minecraft:brown_terracotta
fill 405 230 236 405 235 236 minecraft:green_terracotta
fill 405 230 260 405 231 261 minecraft:green_terracotta
fill 405 230 262 407 230 262 minecraft:oak_leaves[persistent=true]
fill 405 230 263 405 231 264 minecraft:azalea_leaves[persistent=true]
fill 406 230 235 417 230 235 minecraft:oak_leaves[persistent=true]
fill 406 230 236 406 235 236 minecraft:brown_terracotta
setblock 406 230 260 minecraft:lime_terracotta
fill 406 230 261 407 230 261 minecraft:oak_leaves[persistent=true]
fill 406 230 263 417 230 264 minecraft:oak_leaves[persistent=true]
schedule function dropper:buildpart/56_3 1t
