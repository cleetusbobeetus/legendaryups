setblock 148 296 275 minecraft:white_concrete
setblock 148 296 276 minecraft:snow_block
fill 148 296 277 148 299 277 minecraft:packed_ice
fill 148 296 279 149 296 279 minecraft:packed_ice
setblock 148 296 316 minecraft:snow_block
fill 149 296 276 152 296 276 minecraft:packed_ice
setblock 149 296 315 minecraft:snow_block
fill 149 296 316 152 296 316 minecraft:packed_ice
setblock 150 296 279 minecraft:snow_block
fill 150 296 315 153 296 315 minecraft:packed_ice
setblock 151 296 278 minecraft:snow_block
fill 151 296 279 151 298 279 minecraft:packed_ice
setblock 152 296 277 minecraft:snow_block
fill 152 296 278 152 299 278 minecraft:packed_ice
setblock 152 296 286 minecraft:light[level=15]
setblock 152 296 294 minecraft:light[level=15]
setblock 152 296 302 minecraft:light[level=15]
setblock 152 296 310 minecraft:light[level=15]
setblock 153 296 276 minecraft:snow_block
fill 153 296 277 153 299 277 minecraft:packed_ice
setblock 153 296 316 minecraft:snow_block
fill 154 296 276 157 296 276 minecraft:packed_ice
setblock 154 296 315 minecraft:snow_block
fill 154 296 316 157 296 316 minecraft:packed_ice
fill 155 296 315 157 296 315 minecraft:packed_ice
setblock 156 296 278 minecraft:snow_block
setblock 157 296 277 minecraft:snow_block
setblock 158 296 276 minecraft:snow_block
fill 158 296 277 159 296 277 minecraft:packed_ice
setblock 158 296 316 minecraft:snow_block
fill 159 296 276 162 296 276 minecraft:packed_ice
fill 159 296 316 162 296 316 minecraft:packed_ice
setblock 160 296 278 minecraft:light[level=15]
setblock 160 296 286 minecraft:light[level=15]
setblock 160 296 294 minecraft:light[level=15]
setblock 160 296 302 minecraft:light[level=15]
setblock 160 296 310 minecraft:light[level=15]
setblock 163 296 276 minecraft:snow_block
setblock 163 296 316 minecraft:snow_block
fill 164 296 276 164 299 276 minecraft:packed_ice
setblock 164 296 315 minecraft:blue_ice
fill 164 296 316 167 296 316 minecraft:packed_ice
fill 164 296 317 164 308 317 minecraft:snow_block
fill 165 296 315 168 296 315 minecraft:packed_ice
setblock 167 296 277 minecraft:snow_block
setblock 168 296 276 minecraft:snow_block
fill 168 296 277 168 298 277 minecraft:packed_ice
setblock 168 296 278 minecraft:light[level=15]
setblock 168 296 286 minecraft:light[level=15]
setblock 168 296 294 minecraft:light[level=15]
setblock 168 296 302 minecraft:light[level=15]
setblock 168 296 310 minecraft:light[level=15]
setblock 168 296 316 minecraft:snow_block
fill 169 296 276 169 299 276 minecraft:packed_ice
setblock 169 296 315 minecraft:snow_block
fill 169 296 316 169 299 316 minecraft:packed_ice
fill 170 296 315 170 297 315 minecraft:packed_ice
setblock 171 296 277 minecraft:packed_ice
setblock 172 296 277 minecraft:snow_block
setblock 173 296 276 minecraft:snow_block
fill 173 296 277 173 297 277 minecraft:packed_ice
setblock 173 296 316 minecraft:snow_block
fill 174 296 276 174 298 276 minecraft:packed_ice
fill 174 296 316 174 297 316 minecraft:packed_ice
setblock 176 296 278 minecraft:light[level=15]
setblock 176 296 286 minecraft:light[level=15]
setblock 176 296 294 minecraft:light[level=15]
setblock 176 296 302 minecraft:light[level=15]
setblock 176 296 310 minecraft:light[level=15]
setblock 181 296 298 minecraft:snow_block
fill 181 296 299 181 297 299 minecraft:packed_ice
setblock 182 296 277 minecraft:snow_block
fill 182 296 278 182 299 278 minecraft:packed_ice
setblock 182 296 282 minecraft:snow_block
setblock 182 296 292 minecraft:snow_block
fill 182 296 293 182 297 293 minecraft:packed_ice
fill 182 296 297 183 296 297 minecraft:snow_block
fill 182 296 298 182 299 298 minecraft:packed_ice
setblock 182 296 302 minecraft:snow_block
fill 182 296 303 182 299 303 minecraft:packed_ice
fill 183 296 310 183 296 311 minecraft:white_concrete
setblock 141 297 283 minecraft:white_concrete
fill 141 297 284 141 308 284 minecraft:snow_block
setblock 141 297 285 minecraft:white_concrete
setblock 142 297 276 minecraft:snow_block
fill 142 297 277 142 300 277 minecraft:packed_ice
setblock 142 297 281 minecraft:snow_block
fill 142 297 282 142 300 282 minecraft:packed_ice
setblock 142 297 296 minecraft:snow_block
setblock 142 297 297 minecraft:packed_ice
setblock 142 297 301 minecraft:snow_block
fill 143 297 276 143 300 276 minecraft:packed_ice
setblock 143 297 280 minecraft:snow_block
fill 143 297 281 144 299 281 minecraft:packed_ice
setblock 144 297 279 minecraft:snow_block
fill 144 297 280 144 300 280 minecraft:packed_ice
setblock 145 297 278 minecraft:snow_block
fill 145 297 316 146 297 316 minecraft:packed_ice
setblock 146 297 277 minecraft:snow_block
fill 146 297 278 146 300 278 minecraft:packed_ice
setblock 147 297 276 minecraft:snow_block
fill 147 297 277 147 300 277 minecraft:packed_ice
setblock 147 297 316 minecraft:snow_block
fill 148 297 275 148 300 275 minecraft:snow_block
fill 148 297 276 151 297 276 minecraft:packed_ice
setblock 148 297 279 minecraft:packed_ice
setblock 148 297 315 minecraft:snow_block
fill 148 297 316 151 297 316 minecraft:packed_ice
setblock 149 297 279 minecraft:snow_block
fill 149 297 315 152 297 315 minecraft:packed_ice
setblock 150 297 278 minecraft:snow_block
fill 150 297 279 150 299 279 minecraft:packed_ice
setblock 151 297 277 minecraft:snow_block
fill 151 297 278 151 300 278 minecraft:packed_ice
setblock 152 297 276 minecraft:snow_block
fill 152 297 277 152 300 277 minecraft:packed_ice
setblock 152 297 316 minecraft:snow_block
fill 153 297 276 156 297 276 minecraft:packed_ice
setblock 153 297 315 minecraft:snow_block
fill 153 297 316 156 297 316 minecraft:packed_ice
setblock 154 297 315 minecraft:packed_ice
setblock 155 297 278 minecraft:snow_block
setblock 156 297 277 minecraft:snow_block
setblock 157 297 276 minecraft:snow_block
fill 157 297 277 158 297 277 minecraft:packed_ice
fill 157 297 314 157 299 314 minecraft:packed_ice
setblock 157 297 316 minecraft:snow_block
fill 158 297 276 161 297 276 minecraft:packed_ice
fill 158 297 313 158 299 313 minecraft:packed_ice
fill 158 297 315 158 298 316 minecraft:packed_ice
fill 159 297 314 159 299 314 minecraft:packed_ice
fill 159 297 316 161 297 316 minecraft:packed_ice
setblock 162 297 276 minecraft:snow_block
setblock 162 297 316 minecraft:snow_block
fill 163 297 276 163 298 276 minecraft:packed_ice
fill 163 297 316 166 297 316 minecraft:packed_ice
setblock 166 297 277 minecraft:snow_block
fill 166 297 315 167 297 315 minecraft:packed_ice
setblock 167 297 276 minecraft:snow_block
fill 167 297 277 167 298 277 minecraft:packed_ice
fill 167 297 316 167 297 317 minecraft:snow_block
fill 168 297 276 168 300 276 minecraft:packed_ice
setblock 168 297 315 minecraft:snow_block
fill 168 297 316 168 300 316 minecraft:packed_ice
fill 168 297 317 169 308 317 minecraft:snow_block
setblock 169 297 315 minecraft:packed_ice
setblock 170 297 317 minecraft:light_blue_concrete
setblock 171 297 277 minecraft:snow_block
fill 171 297 317 171 308 317 minecraft:snow_block
setblock 172 297 276 minecraft:snow_block
setblock 172 297 277 minecraft:packed_ice
setblock 172 297 316 minecraft:snow_block
fill 173 297 276 173 298 276 minecraft:packed_ice
fill 173 297 316 173 298 316 minecraft:packed_ice
setblock 181 297 297 minecraft:snow_block
setblock 181 297 298 minecraft:packed_ice
setblock 182 297 277 minecraft:packed_ice
setblock 182 297 281 minecraft:snow_block
fill 182 297 282 182 299 283 minecraft:packed_ice
setblock 182 297 296 minecraft:snow_block
fill 182 297 297 182 300 297 minecraft:packed_ice
setblock 182 297 301 minecraft:snow_block
fill 182 297 302 182 300 302 minecraft:packed_ice
fill 183 297 297 183 308 297 minecraft:snow_block
fill 183 297 310 183 308 311 minecraft:snow_block
fill 141 298 283 141 308 283 minecraft:snow_block
fill 141 298 285 142 298 285 minecraft:snow_block
fill 142 298 276 142 300 276 minecraft:packed_ice
setblock 142 298 280 minecraft:snow_block
fill 142 298 281 142 300 281 minecraft:packed_ice
setblock 142 298 284 minecraft:packed_ice
fill 142 298 286 142 300 286 minecraft:packed_ice
setblock 143 298 278 minecraft:packed_ice
setblock 143 298 279 minecraft:snow_block
fill 143 298 280 143 300 280 minecraft:packed_ice
setblock 143 298 284 minecraft:snow_block
fill 143 298 308 143 299 308 minecraft:packed_ice
setblock 144 298 278 minecraft:snow_block
fill 144 298 279 144 300 279 minecraft:packed_ice
fill 144 298 307 144 299 307 minecraft:packed_ice
fill 144 298 309 144 299 309 minecraft:packed_ice
setblock 145 298 277 minecraft:snow_block
fill 145 298 278 145 300 278 minecraft:packed_ice
fill 145 298 308 145 299 308 minecraft:packed_ice
setblock 145 298 316 minecraft:packed_ice
setblock 146 298 276 minecraft:snow_block
fill 146 298 277 146 300 277 minecraft:packed_ice
setblock 146 298 316 minecraft:snow_block
fill 147 298 276 150 298 276 minecraft:packed_ice
fill 147 298 316 150 298 316 minecraft:packed_ice
setblock 148 298 279 minecraft:snow_block
setblock 149 298 278 minecraft:snow_block
fill 149 298 279 149 300 279 minecraft:packed_ice
fill 149 298 315 151 298 315 minecraft:packed_ice
setblock 150 298 277 minecraft:snow_block
fill 150 298 278 150 300 278 minecraft:packed_ice
setblock 151 298 276 minecraft:snow_block
fill 151 298 277 151 300 277 minecraft:packed_ice
setblock 151 298 316 minecraft:snow_block
fill 152 298 276 155 298 276 minecraft:packed_ice
setblock 152 298 315 minecraft:snow_block
fill 152 298 316 155 298 316 minecraft:packed_ice
setblock 154 298 275 minecraft:white_concrete
setblock 154 298 278 minecraft:snow_block
fill 155 298 275 157 303 275 minecraft:snow_block
setblock 155 298 277 minecraft:snow_block
setblock 156 298 276 minecraft:snow_block
setblock 156 298 277 minecraft:packed_ice
setblock 156 298 316 minecraft:snow_block
fill 157 298 276 160 298 276 minecraft:packed_ice
setblock 157 298 316 minecraft:packed_ice
setblock 161 298 276 minecraft:snow_block
setblock 162 298 276 minecraft:packed_ice
fill 162 298 316 165 298 316 minecraft:packed_ice
setblock 165 298 275 minecraft:light_blue_concrete
setblock 166 298 276 minecraft:snow_block
setblock 166 298 316 minecraft:snow_block
fill 167 298 276 167 300 276 minecraft:packed_ice
fill 167 298 316 167 300 316 minecraft:packed_ice
fill 167 298 317 167 300 317 minecraft:snow_block
setblock 168 298 315 minecraft:packed_ice
setblock 169 298 277 minecraft:packed_ice
setblock 170 298 277 minecraft:snow_block
fill 170 298 317 170 308 317 minecraft:snow_block
setblock 171 298 275 minecraft:white_concrete
setblock 171 298 276 minecraft:snow_block
setblock 171 298 277 minecraft:packed_ice
setblock 171 298 316 minecraft:snow_block
fill 172 298 275 172 308 275 minecraft:snow_block
fill 172 298 276 172 299 276 minecraft:packed_ice
setblock 172 298 316 minecraft:packed_ice
setblock 182 298 280 minecraft:snow_block
fill 182 298 281 182 300 281 minecraft:packed_ice
setblock 182 298 284 minecraft:packed_ice
setblock 182 298 295 minecraft:snow_block
fill 182 298 296 182 300 296 minecraft:packed_ice
setblock 182 298 300 minecraft:snow_block
fill 182 298 301 182 300 301 minecraft:packed_ice
fill 183 298 293 183 308 293 minecraft:snow_block
setblock 183 298 294 minecraft:white_concrete
fill 141 299 285 141 308 285 minecraft:snow_block
setblock 142 299 279 minecraft:snow_block
fill 142 299 280 142 300 280 minecraft:packed_ice
setblock 142 299 283 minecraft:packed_ice
setblock 142 299 284 minecraft:snow_block
fill 142 299 285 142 300 285 minecraft:packed_ice
setblock 143 299 278 minecraft:snow_block
fill 143 299 279 143 300 279 minecraft:packed_ice
setblock 143 299 283 minecraft:snow_block
fill 143 299 284 143 300 284 minecraft:packed_ice
setblock 144 299 277 minecraft:snow_block
fill 144 299 278 144 300 278 minecraft:packed_ice
setblock 144 299 282 minecraft:snow_block
setblock 145 299 276 minecraft:snow_block
fill 145 299 277 145 300 277 minecraft:packed_ice
fill 146 299 276 149 299 276 minecraft:packed_ice
fill 146 299 316 149 299 316 minecraft:packed_ice
setblock 147 299 278 minecraft:packed_ice
setblock 147 299 279 minecraft:snow_block
setblock 148 299 278 minecraft:snow_block
fill 148 299 279 148 300 279 minecraft:packed_ice
setblock 149 299 277 minecraft:snow_block
fill 149 299 278 149 300 278 minecraft:packed_ice
setblock 150 299 276 minecraft:snow_block
fill 150 299 277 150 300 277 minecraft:packed_ice
setblock 150 299 316 minecraft:snow_block
fill 151 299 276 154 299 276 minecraft:packed_ice
fill 151 299 316 154 299 316 minecraft:packed_ice
setblock 153 299 278 minecraft:snow_block
fill 154 299 275 154 308 275 minecraft:snow_block
setblock 154 299 277 minecraft:snow_block
setblock 155 299 276 minecraft:snow_block
setblock 155 299 277 minecraft:packed_ice
setblock 155 299 316 minecraft:snow_block
fill 156 299 276 157 299 276 minecraft:packed_ice
setblock 156 299 316 minecraft:packed_ice
setblock 157 299 313 minecraft:packed_ice
fill 157 299 315 159 299 315 minecraft:packed_ice
setblock 159 299 313 minecraft:packed_ice
fill 163 299 316 164 299 316 minecraft:packed_ice
fill 165 299 275 165 299 276 minecraft:snow_block
setblock 165 299 316 minecraft:snow_block
fill 166 299 276 166 300 276 minecraft:packed_ice
fill 166 299 316 166 300 316 minecraft:packed_ice
setblock 170 299 276 minecraft:snow_block
setblock 170 299 316 minecraft:snow_block
fill 171 299 275 171 308 275 minecraft:snow_block
fill 171 299 276 171 300 276 minecraft:packed_ice
setblock 171 299 316 minecraft:packed_ice
setblock 182 299 279 minecraft:snow_block
fill 182 299 280 182 300 280 minecraft:packed_ice
setblock 182 299 284 minecraft:snow_block
fill 182 299 285 182 300 285 minecraft:packed_ice
setblock 182 299 295 minecraft:packed_ice
setblock 182 299 299 minecraft:snow_block
fill 182 299 300 182 300 300 minecraft:packed_ice
setblock 182 299 304 minecraft:snow_block
fill 183 299 294 183 308 294 minecraft:snow_block
setblock 141 300 295 minecraft:light_blue_concrete
setblock 142 300 278 minecraft:snow_block
setblock 142 300 279 minecraft:packed_ice
setblock 142 300 283 minecraft:snow_block
setblock 142 300 284 minecraft:packed_ice
setblock 142 300 287 minecraft:packed_ice
setblock 143 300 277 minecraft:snow_block
setblock 143 300 278 minecraft:packed_ice
setblock 143 300 281 minecraft:packed_ice
setblock 143 300 282 minecraft:snow_block
fill 143 300 283 144 300 283 minecraft:packed_ice
setblock 143 300 285 minecraft:packed_ice
setblock 144 300 276 minecraft:snow_block
setblock 144 300 277 minecraft:packed_ice
setblock 144 300 281 minecraft:snow_block
setblock 144 300 282 minecraft:packed_ice
setblock 144 300 285 minecraft:light[level=12]
setblock 144 300 292 minecraft:light[level=12]
setblock 144 300 299 minecraft:light[level=12]
setblock 144 300 306 minecraft:light[level=12]
setblock 144 300 313 minecraft:light[level=12]
fill 145 300 276 148 300 276 minecraft:packed_ice
fill 145 300 316 148 300 316 minecraft:packed_ice
setblock 147 300 278 minecraft:snow_block
setblock 147 300 279 minecraft:packed_ice
setblock 148 300 277 minecraft:snow_block
setblock 148 300 278 minecraft:packed_ice
setblock 149 300 276 minecraft:snow_block
setblock 149 300 277 minecraft:packed_ice
setblock 149 300 316 minecraft:snow_block
fill 150 300 276 153 300 276 minecraft:packed_ice
fill 150 300 316 153 300 316 minecraft:packed_ice
setblock 151 300 285 minecraft:light[level=12]
setblock 151 300 292 minecraft:light[level=12]
setblock 151 300 299 minecraft:light[level=12]
setblock 151 300 306 minecraft:light[level=12]
setblock 151 300 313 minecraft:light[level=12]
setblock 152 300 278 minecraft:snow_block
setblock 153 300 277 minecraft:snow_block
setblock 154 300 276 minecraft:snow_block
setblock 154 300 277 minecraft:packed_ice
setblock 154 300 316 minecraft:snow_block
fill 155 300 276 156 300 276 minecraft:packed_ice
setblock 158 300 278 minecraft:light[level=12]
setblock 158 300 285 minecraft:light[level=12]
setblock 158 300 292 minecraft:light[level=12]
setblock 158 300 299 minecraft:light[level=12]
setblock 158 300 306 minecraft:light[level=12]
setblock 158 300 313 minecraft:light[level=12]
setblock 164 300 316 minecraft:snow_block
fill 165 300 275 165 308 275 minecraft:snow_block
setblock 165 300 276 minecraft:packed_ice
setblock 165 300 278 minecraft:light[level=12]
setblock 165 300 285 minecraft:light[level=12]
setblock 165 300 292 minecraft:light[level=12]
setblock 165 300 299 minecraft:light[level=12]
setblock 165 300 306 minecraft:light[level=12]
setblock 165 300 313 minecraft:light[level=12]
setblock 165 300 316 minecraft:packed_ice
setblock 169 300 276 minecraft:snow_block
setblock 169 300 316 minecraft:snow_block
setblock 170 300 276 minecraft:packed_ice
setblock 170 300 316 minecraft:packed_ice
setblock 172 300 278 minecraft:light[level=12]
setblock 172 300 285 minecraft:light[level=12]
setblock 172 300 292 minecraft:light[level=12]
setblock 172 300 299 minecraft:light[level=12]
setblock 172 300 306 minecraft:light[level=12]
setblock 172 300 313 minecraft:light[level=12]
setblock 179 300 278 minecraft:light[level=12]
setblock 179 300 285 minecraft:light[level=12]
setblock 179 300 292 minecraft:light[level=12]
setblock 179 300 299 minecraft:light[level=12]
setblock 179 300 306 minecraft:light[level=12]
setblock 179 300 313 minecraft:light[level=12]
setblock 182 300 278 minecraft:snow_block
setblock 182 300 279 minecraft:packed_ice
setblock 182 300 282 minecraft:packed_ice
setblock 182 300 283 minecraft:snow_block
setblock 182 300 284 minecraft:packed_ice
fill 182 300 286 182 300 287 minecraft:packed_ice
setblock 182 300 298 minecraft:snow_block
setblock 182 300 299 minecraft:packed_ice
setblock 182 300 303 minecraft:snow_block
setblock 182 300 304 minecraft:packed_ice
fill 141 301 295 141 308 295 minecraft:snow_block
setblock 141 301 297 minecraft:white_concrete
setblock 148 301 275 minecraft:light_blue_concrete
setblock 165 301 317 minecraft:white_concrete
setblock 167 301 317 minecraft:white_concrete
fill 141 302 297 141 308 297 minecraft:snow_block
fill 148 302 275 148 308 275 minecraft:snow_block
setblock 161 302 317 minecraft:light_blue_concrete
fill 165 302 317 165 308 317 minecraft:snow_block
fill 167 302 317 167 308 317 minecraft:snow_block
setblock 181 302 317 minecraft:white_concrete
setblock 141 303 294 minecraft:light_blue_concrete
setblock 153 303 275 minecraft:white_concrete
fill 161 303 317 161 308 317 minecraft:snow_block
fill 181 303 317 181 308 317 minecraft:snow_block
fill 141 304 294 141 308 294 minecraft:snow_block
fill 153 304 275 153 308 275 minecraft:snow_block
fill 155 304 275 155 308 275 minecraft:snow_block
setblock 156 304 275 minecraft:white_concrete
fill 157 304 275 157 308 275 minecraft:snow_block
fill 162 304 317 162 308 317 minecraft:snow_block
setblock 163 304 317 minecraft:light_blue_concrete
fill 156 305 275 156 308 275 minecraft:snow_block
fill 163 305 317 163 308 317 minecraft:snow_block
setblock 183 305 316 minecraft:light_blue_concrete
fill 183 306 281 183 308 282 minecraft:snow_block
setblock 183 306 283 minecraft:light_blue_concrete
setblock 183 306 285 minecraft:light_blue_concrete
fill 183 306 316 183 308 316 minecraft:snow_block
setblock 141 307 300 minecraft:light_blue_concrete
setblock 142 307 317 minecraft:light_blue_concrete
setblock 183 307 276 minecraft:light_blue_concrete
fill 183 307 283 183 308 283 minecraft:snow_block
fill 183 307 285 183 308 285 minecraft:snow_block
setblock 183 307 292 minecraft:light_blue_concrete
setblock 141 308 300 minecraft:snow_block
setblock 142 308 317 minecraft:snow_block
setblock 161 308 275 minecraft:white_concrete
setblock 182 308 275 minecraft:white_concrete
setblock 183 308 276 minecraft:snow_block
setblock 183 308 292 minecraft:snow_block
