fill 523 150 537 525 150 537 minecraft:blackstone
fill 524 150 524 526 150 528 minecraft:blackstone
fill 524 150 530 525 150 530 minecraft:blackstone
fill 524 150 536 525 150 536 minecraft:blackstone
setblock 525 150 535 minecraft:blackstone
fill 526 150 523 530 150 523 minecraft:blackstone
fill 527 150 524 527 150 526 minecraft:blackstone
fill 527 150 542 528 150 542 minecraft:blackstone
setblock 528 150 513 minecraft:light[level=14]
fill 528 150 524 528 150 525 minecraft:blackstone
setblock 528 150 529 minecraft:light[level=14]
setblock 528 150 537 minecraft:light[level=14]
fill 531 150 544 531 150 547 minecraft:shroomlight
fill 532 150 521 533 150 521 minecraft:blackstone
fill 532 150 545 533 150 547 minecraft:blackstone
fill 533 150 510 533 170 510 minecraft:black_concrete
fill 534 150 546 535 150 547 minecraft:blackstone
setblock 536 150 513 minecraft:light[level=14]
setblock 536 150 521 minecraft:light[level=14]
setblock 536 150 529 minecraft:light[level=14]
setblock 536 150 537 minecraft:light[level=14]
setblock 536 150 545 minecraft:light[level=14]
fill 537 150 546 541 150 546 minecraft:blackstone
fill 541 150 542 541 154 544 minecraft:blackstone
fill 542 150 542 544 154 543 minecraft:blackstone
fill 542 150 545 542 154 545 minecraft:blackstone
fill 543 150 521 544 150 521 minecraft:blackstone
setblock 544 150 510 minecraft:magma_block
setblock 544 150 513 minecraft:light[level=14]
setblock 544 150 529 minecraft:light[level=14]
setblock 544 150 537 minecraft:light[level=14]
fill 545 150 519 545 150 522 minecraft:shroomlight
fill 546 150 543 550 150 543 minecraft:blackstone
fill 548 150 524 549 150 525 minecraft:blackstone
fill 548 150 541 556 150 541 minecraft:blackstone
fill 549 150 540 556 150 540 minecraft:blackstone
fill 550 150 525 556 150 525 minecraft:blackstone
fill 550 150 527 554 150 528 minecraft:blackstone
fill 550 150 538 557 150 539 minecraft:blackstone
fill 551 150 529 551 150 531 minecraft:blackstone
fill 551 150 533 553 150 535 minecraft:blackstone
setblock 552 150 513 minecraft:light[level=14]
fill 552 150 529 552 150 530 minecraft:blackstone
fill 553 150 529 553 151 529 minecraft:blackstone
fill 554 150 533 557 151 534 minecraft:blackstone
fill 559 150 520 559 152 520 minecraft:black_concrete
fill 559 150 537 559 157 537 minecraft:black_concrete
fill 517 151 525 517 154 525 minecraft:black_concrete
setblock 517 151 539 minecraft:shroomlight
fill 517 151 540 517 179 540 minecraft:black_concrete
setblock 517 151 544 minecraft:magma_block
fill 517 151 545 517 176 545 minecraft:black_concrete
fill 518 151 533 522 151 533 minecraft:blackstone
fill 520 151 532 522 151 532 minecraft:blackstone
fill 520 151 541 525 151 541 minecraft:blackstone
setblock 521 151 510 minecraft:white_concrete
fill 521 151 531 522 151 531 minecraft:blackstone
fill 521 151 540 524 151 540 minecraft:blackstone
setblock 522 151 510 minecraft:magma_block
fill 522 151 521 530 151 522 minecraft:blackstone
fill 522 151 538 523 151 539 minecraft:blackstone
fill 523 151 520 530 151 520 minecraft:blackstone
setblock 523 151 537 minecraft:blackstone
fill 524 151 519 531 151 519 minecraft:blackstone
fill 524 151 524 524 151 526 minecraft:blackstone
fill 525 151 524 525 151 525 minecraft:blackstone
fill 525 151 544 527 151 544 minecraft:blackstone
setblock 526 151 523 minecraft:blackstone
setblock 526 151 543 minecraft:blackstone
fill 526 151 545 528 151 549 minecraft:blackstone
fill 529 151 546 530 151 549 minecraft:blackstone
fill 531 151 518 535 151 518 minecraft:blackstone
fill 531 151 521 531 157 521 minecraft:blackstone
setblock 531 151 547 minecraft:shroomlight
fill 531 151 548 535 151 549 minecraft:blackstone
fill 536 151 549 537 151 549 minecraft:blackstone
fill 541 151 518 550 151 518 minecraft:blackstone
fill 541 151 545 541 154 545 minecraft:blackstone
fill 541 151 548 545 151 548 minecraft:blackstone
fill 542 151 541 544 154 541 minecraft:blackstone
fill 542 151 544 545 154 544 minecraft:blackstone
fill 543 151 545 544 154 545 minecraft:blackstone
fill 544 151 510 544 177 510 minecraft:black_concrete
setblock 545 151 519 minecraft:shroomlight
fill 545 151 542 545 154 543 minecraft:blackstone
setblock 545 151 547 minecraft:blackstone
fill 546 151 519 550 151 520 minecraft:blackstone
fill 546 151 546 553 151 546 minecraft:blackstone
setblock 547 151 552 minecraft:magma_block
fill 548 151 521 550 151 521 minecraft:blackstone
fill 548 151 545 554 151 545 minecraft:blackstone
setblock 549 151 510 minecraft:magma_block
fill 549 151 522 550 151 522 minecraft:blackstone
fill 549 151 544 554 151 544 minecraft:blackstone
fill 550 151 510 552 179 510 minecraft:black_concrete
setblock 550 151 523 minecraft:blackstone
setblock 550 151 543 minecraft:blackstone
fill 551 151 525 556 151 525 minecraft:blackstone
fill 551 151 541 555 151 542 minecraft:blackstone
fill 552 151 526 555 151 526 minecraft:blackstone
fill 552 151 540 556 151 540 minecraft:blackstone
fill 553 151 527 554 151 528 minecraft:blackstone
setblock 553 151 536 minecraft:blackstone
fill 553 151 538 557 151 539 minecraft:blackstone
fill 554 151 531 557 151 532 minecraft:blackstone
setblock 556 151 541 minecraft:blackstone
fill 517 152 539 517 179 539 minecraft:black_concrete
fill 517 152 544 517 179 544 minecraft:black_concrete
fill 521 152 510 522 153 510 minecraft:black_concrete
fill 528 152 520 530 157 522 minecraft:blackstone
fill 529 152 519 530 157 519 minecraft:blackstone
fill 529 152 523 530 157 523 minecraft:blackstone
fill 531 152 520 531 157 520 minecraft:blackstone
fill 531 152 522 531 157 522 minecraft:blackstone
fill 532 152 552 544 152 552 minecraft:black_concrete
fill 538 152 510 539 163 510 minecraft:black_concrete
setblock 540 152 510 minecraft:white_concrete
fill 540 152 542 540 154 544 minecraft:blackstone
fill 541 152 541 541 154 541 minecraft:blackstone
fill 542 152 546 543 154 546 minecraft:blackstone
fill 545 152 545 545 154 545 minecraft:blackstone
fill 547 152 552 547 153 552 minecraft:black_concrete
fill 549 152 510 549 179 510 minecraft:black_concrete
setblock 559 152 536 minecraft:shroomlight
setblock 517 153 514 minecraft:shroomlight
fill 526 153 531 526 154 531 minecraft:blue_concrete
fill 527 153 520 527 157 522 minecraft:blackstone
fill 528 153 519 528 157 519 minecraft:blackstone
fill 528 153 523 528 157 523 minecraft:blackstone
fill 531 153 519 531 157 519 minecraft:blackstone
fill 531 153 523 531 157 523 minecraft:blackstone
fill 532 153 520 532 157 522 minecraft:blackstone
fill 532 153 552 534 155 552 minecraft:black_concrete
setblock 535 153 552 minecraft:magma_block
fill 536 153 552 544 155 552 minecraft:black_concrete
fill 540 153 510 540 164 510 minecraft:black_concrete
fill 540 153 541 540 154 541 minecraft:blackstone
fill 540 153 545 540 154 545 minecraft:blackstone
fill 541 153 546 541 154 546 minecraft:blackstone
fill 542 153 540 544 154 540 minecraft:blackstone
fill 544 153 546 544 154 546 minecraft:blackstone
fill 545 153 541 545 154 541 minecraft:blackstone
fill 546 153 542 546 154 544 minecraft:blackstone
fill 547 153 542 548 154 543 minecraft:blackstone
setblock 559 153 511 minecraft:shroomlight
setblock 559 153 520 minecraft:white_concrete
setblock 559 153 532 minecraft:magma_block
setblock 559 153 536 minecraft:black_concrete
fill 517 154 514 517 159 514 minecraft:black_concrete
fill 517 154 518 517 155 518 minecraft:orange_concrete
fill 517 154 530 517 179 530 minecraft:black_concrete
setblock 517 154 531 minecraft:shroomlight
fill 517 154 534 517 155 534 minecraft:orange_concrete
fill 517 154 550 517 155 550 minecraft:orange_concrete
fill 521 154 510 521 155 510 minecraft:orange_concrete
fill 522 154 510 522 179 510 minecraft:black_concrete
fill 527 154 519 527 157 519 minecraft:blackstone
fill 527 154 523 527 157 523 minecraft:blackstone
fill 529 154 518 530 157 518 minecraft:blackstone
fill 529 154 524 530 157 524 minecraft:blackstone
fill 531 154 552 531 155 552 minecraft:orange_concrete
fill 532 154 523 532 157 523 minecraft:blackstone
fill 535 154 552 535 176 552 minecraft:black_concrete
fill 537 154 510 537 155 510 minecraft:orange_concrete
fill 539 154 542 539 154 544 minecraft:blackstone
setblock 540 154 546 minecraft:blackstone
setblock 541 154 540 minecraft:blackstone
fill 542 154 547 543 154 547 minecraft:blackstone
setblock 545 154 540 minecraft:blackstone
setblock 545 154 546 minecraft:blackstone
setblock 546 154 541 minecraft:blackstone
setblock 546 154 545 minecraft:blackstone
fill 547 154 552 547 155 552 minecraft:orange_concrete
fill 553 154 510 553 155 510 minecraft:orange_concrete
fill 559 154 511 559 179 511 minecraft:black_concrete
fill 559 154 520 559 155 520 minecraft:orange_concrete
fill 559 154 532 559 176 532 minecraft:black_concrete
fill 559 154 536 559 155 536 minecraft:orange_concrete
setblock 559 154 544 minecraft:white_concrete
setblock 517 155 525 minecraft:magma_block
setblock 517 155 531 minecraft:magma_block
setblock 517 155 538 minecraft:shroomlight
fill 526 155 520 526 157 522 minecraft:blackstone
fill 528 155 518 528 157 518 minecraft:blackstone
fill 528 155 524 528 157 524 minecraft:blackstone
fill 531 155 518 531 157 518 minecraft:blackstone
fill 531 155 524 531 157 524 minecraft:blackstone
fill 532 155 519 532 157 519 minecraft:blackstone
fill 533 155 520 533 157 522 minecraft:blackstone
fill 542 155 543 543 155 544 minecraft:magma_block
setblock 543 155 542 minecraft:magma_block
setblock 544 155 543 minecraft:magma_block
fill 559 155 544 559 179 544 minecraft:black_concrete
fill 517 156 518 517 161 518 minecraft:black_concrete
fill 517 156 525 517 179 525 minecraft:black_concrete
fill 517 156 531 517 175 531 minecraft:black_concrete
setblock 517 156 533 minecraft:white_concrete
fill 517 156 534 517 161 534 minecraft:black_concrete
setblock 517 156 538 minecraft:black_concrete
setblock 517 156 550 minecraft:black_concrete
setblock 519 156 510 minecraft:shroomlight
fill 521 156 510 521 161 510 minecraft:black_concrete
fill 526 156 519 526 157 519 minecraft:blackstone
fill 526 156 523 526 157 523 minecraft:blackstone
fill 527 156 518 527 157 518 minecraft:blackstone
fill 527 156 524 527 157 524 minecraft:blackstone
fill 529 156 517 530 157 517 minecraft:blackstone
fill 529 156 525 530 157 525 minecraft:blackstone
fill 531 156 552 531 161 552 minecraft:black_concrete
fill 532 156 518 532 157 518 minecraft:blackstone
fill 532 156 524 532 157 524 minecraft:blackstone
setblock 532 156 552 minecraft:white_concrete
fill 533 156 519 533 157 519 minecraft:blackstone
fill 533 156 523 533 157 523 minecraft:blackstone
fill 533 156 552 534 179 552 minecraft:black_concrete
fill 536 156 552 543 158 552 minecraft:black_concrete
fill 537 156 510 537 161 510 minecraft:black_concrete
fill 542 156 543 543 157 543 minecraft:magma_block
setblock 543 156 544 minecraft:magma_block
setblock 544 156 552 minecraft:magma_block
fill 547 156 532 548 157 533 minecraft:blackstone
fill 547 156 552 547 161 552 minecraft:black_concrete
fill 553 156 510 553 161 510 minecraft:black_concrete
fill 559 156 520 559 160 520 minecraft:black_concrete
fill 559 156 536 559 161 536 minecraft:black_concrete
fill 517 157 533 517 179 533 minecraft:black_concrete
setblock 517 157 538 minecraft:magma_block
setblock 517 157 543 minecraft:white_concrete
setblock 517 157 550 minecraft:magma_block
fill 519 157 510 519 179 510 minecraft:black_concrete
fill 525 157 520 525 157 522 minecraft:blackstone
setblock 526 157 518 minecraft:blackstone
setblock 526 157 524 minecraft:blackstone
fill 527 157 525 528 157 525 minecraft:blackstone
setblock 528 157 517 minecraft:blackstone
setblock 531 157 517 minecraft:blackstone
setblock 531 157 525 minecraft:blackstone
fill 532 157 552 532 179 552 minecraft:black_concrete
setblock 533 157 518 minecraft:blackstone
setblock 533 157 524 minecraft:blackstone
fill 534 157 520 534 157 522 minecraft:blackstone
fill 544 157 552 544 160 552 minecraft:black_concrete
setblock 559 157 550 minecraft:shroomlight
fill 517 158 538 517 170 538 minecraft:black_concrete
fill 517 158 543 517 160 543 minecraft:black_concrete
fill 517 158 550 517 161 550 minecraft:black_concrete
setblock 520 158 513 minecraft:light[level=14]
setblock 520 158 521 minecraft:light[level=14]
setblock 520 158 529 minecraft:light[level=14]
setblock 520 158 537 minecraft:light[level=14]
setblock 520 158 545 minecraft:light[level=14]
setblock 528 158 513 minecraft:light[level=14]
setblock 528 158 521 minecraft:light[level=14]
setblock 528 158 529 minecraft:light[level=14]
setblock 528 158 537 minecraft:light[level=14]
setblock 528 158 545 minecraft:light[level=14]
fill 529 158 520 530 158 522 minecraft:magma_block
setblock 536 158 513 minecraft:light[level=14]
setblock 536 158 521 minecraft:light[level=14]
setblock 536 158 529 minecraft:light[level=14]
setblock 536 158 537 minecraft:light[level=14]
setblock 536 158 545 minecraft:light[level=14]
setblock 543 158 543 minecraft:magma_block
setblock 544 158 513 minecraft:light[level=14]
setblock 544 158 521 minecraft:light[level=14]
setblock 544 158 529 minecraft:light[level=14]
setblock 544 158 537 minecraft:light[level=14]
setblock 544 158 545 minecraft:light[level=14]
setblock 552 158 513 minecraft:light[level=14]
setblock 552 158 521 minecraft:light[level=14]
setblock 552 158 529 minecraft:light[level=14]
setblock 552 158 537 minecraft:light[level=14]
setblock 552 158 545 minecraft:light[level=14]
setblock 559 158 524 minecraft:magma_block
fill 559 158 525 559 179 525 minecraft:black_concrete
setblock 559 158 537 minecraft:magma_block
fill 559 158 550 559 177 550 minecraft:black_concrete
setblock 517 159 527 minecraft:shroomlight
fill 517 159 528 517 179 528 minecraft:black_concrete
setblock 517 159 542 minecraft:shroomlight
fill 518 159 552 519 177 552 minecraft:black_concrete
setblock 520 159 552 minecraft:white_concrete
fill 529 159 521 530 160 521 minecraft:magma_block
fill 536 159 552 539 166 552 minecraft:black_concrete
setblock 540 159 552 minecraft:shroomlight
fill 541 159 552 543 175 552 minecraft:black_concrete
fill 559 159 524 559 179 524 minecraft:black_concrete
fill 559 159 537 559 177 537 minecraft:black_concrete
setblock 517 160 514 minecraft:magma_block
fill 517 160 527 517 171 527 minecraft:black_concrete
fill 517 160 542 517 177 542 minecraft:black_concrete
fill 520 160 552 520 179 552 minecraft:black_concrete
setblock 521 160 552 minecraft:white_concrete
fill 540 160 552 540 179 552 minecraft:black_concrete
fill 517 161 514 517 175 514 minecraft:black_concrete
setblock 517 161 523 minecraft:magma_block
setblock 517 161 536 minecraft:shroomlight
setblock 517 161 543 minecraft:white_concrete
fill 521 161 552 521 179 552 minecraft:black_concrete
setblock 528 161 552 minecraft:white_concrete
setblock 529 161 521 minecraft:magma_block
fill 534 161 523 535 162 524 minecraft:blue_concrete
setblock 544 161 552 minecraft:magma_block
setblock 559 161 520 minecraft:magma_block
setblock 559 161 527 minecraft:shroomlight
setblock 559 161 543 minecraft:white_concrete
fill 517 162 518 517 164 518 minecraft:orange_concrete
fill 517 162 523 517 180 523 minecraft:black_concrete
setblock 517 162 526 minecraft:magma_block
fill 517 162 534 517 164 534 minecraft:orange_concrete
fill 517 162 536 517 177 536 minecraft:black_concrete
fill 517 162 543 517 179 543 minecraft:black_concrete
fill 517 162 550 517 164 550 minecraft:orange_concrete
fill 521 162 510 521 164 510 minecraft:orange_concrete
fill 528 162 552 528 174 552 minecraft:black_concrete
fill 531 162 552 531 164 552 minecraft:orange_concrete
fill 537 162 510 537 164 510 minecraft:orange_concrete
fill 544 162 552 544 179 552 minecraft:black_concrete
fill 547 162 552 547 164 552 minecraft:orange_concrete
fill 553 162 510 553 164 510 minecraft:orange_concrete
fill 559 162 520 559 164 520 minecraft:orange_concrete
fill 559 162 527 559 179 527 minecraft:black_concrete
fill 559 162 536 559 164 536 minecraft:orange_concrete
fill 559 162 543 559 177 543 minecraft:black_concrete
setblock 517 163 522 minecraft:magma_block
setblock 517 163 526 minecraft:black_concrete
fill 521 163 524 521 164 526 minecraft:red_terracotta
fill 522 163 524 522 164 525 minecraft:red_terracotta
setblock 517 164 521 minecraft:magma_block
fill 517 164 522 517 179 522 minecraft:black_concrete
setblock 517 164 526 minecraft:white_concrete
fill 530 164 528 530 165 528 minecraft:magma_block
fill 538 164 510 538 181 510 minecraft:black_concrete
setblock 539 164 510 minecraft:shroomlight
fill 517 165 518 517 170 518 minecraft:black_concrete
fill 517 165 521 517 179 521 minecraft:black_concrete
fill 517 165 526 517 175 526 minecraft:black_concrete
fill 517 165 534 517 170 534 minecraft:black_concrete
fill 517 165 550 517 170 550 minecraft:black_concrete
fill 521 165 510 521 170 510 minecraft:black_concrete
fill 531 165 552 531 170 552 minecraft:black_concrete
fill 537 165 510 537 170 510 minecraft:black_concrete
fill 539 165 510 539 175 510 minecraft:black_concrete
setblock 540 165 510 minecraft:white_concrete
fill 547 165 552 547 170 552 minecraft:black_concrete
setblock 553 165 510 minecraft:shroomlight
setblock 554 165 552 minecraft:white_concrete
fill 559 165 520 559 170 520 minecraft:black_concrete
fill 559 165 536 559 170 536 minecraft:black_concrete
setblock 520 166 513 minecraft:light[level=14]
setblock 520 166 521 minecraft:light[level=14]
setblock 520 166 529 minecraft:light[level=14]
setblock 520 166 537 minecraft:light[level=14]
setblock 520 166 545 minecraft:light[level=14]
setblock 524 166 552 minecraft:white_concrete
setblock 528 166 513 minecraft:light[level=14]
setblock 528 166 521 minecraft:light[level=14]
setblock 528 166 529 minecraft:light[level=14]
setblock 528 166 537 minecraft:light[level=14]
setblock 528 166 545 minecraft:light[level=14]
setblock 536 166 513 minecraft:light[level=14]
setblock 536 166 521 minecraft:light[level=14]
setblock 536 166 529 minecraft:light[level=14]
setblock 536 166 537 minecraft:light[level=14]
setblock 536 166 545 minecraft:light[level=14]
fill 540 166 510 540 179 510 minecraft:black_concrete
setblock 544 166 513 minecraft:light[level=14]
setblock 544 166 521 minecraft:light[level=14]
setblock 544 166 529 minecraft:light[level=14]
setblock 544 166 537 minecraft:light[level=14]
setblock 544 166 545 minecraft:light[level=14]
setblock 552 166 513 minecraft:light[level=14]
setblock 552 166 521 minecraft:light[level=14]
setblock 552 166 529 minecraft:light[level=14]
setblock 552 166 537 minecraft:light[level=14]
setblock 552 166 545 minecraft:light[level=14]
fill 553 166 510 553 170 510 minecraft:black_concrete
fill 554 166 552 554 167 552 minecraft:black_concrete
setblock 559 166 548 minecraft:shroomlight
fill 559 166 549 559 169 549 minecraft:black_concrete
setblock 517 167 515 minecraft:shroomlight
setblock 517 167 532 minecraft:shroomlight
fill 524 167 552 524 175 552 minecraft:black_concrete
setblock 536 167 552 minecraft:magma_block
fill 537 167 552 539 177 552 minecraft:black_concrete
fill 542 167 547 542 168 547 minecraft:magma_block
setblock 548 167 510 minecraft:magma_block
fill 554 167 527 554 168 527 minecraft:magma_block
fill 559 167 548 559 177 548 minecraft:black_concrete
fill 517 168 515 517 179 515 minecraft:black_concrete
fill 517 168 532 517 179 532 minecraft:black_concrete
setblock 517 168 548 minecraft:magma_block
fill 517 168 549 517 177 549 minecraft:black_concrete
fill 536 168 552 536 169 552 minecraft:black_concrete
fill 541 168 539 542 169 539 minecraft:blackstone
fill 548 168 510 548 179 510 minecraft:black_concrete
setblock 554 168 552 minecraft:shroomlight
setblock 559 168 545 minecraft:magma_block
fill 517 169 548 517 177 548 minecraft:black_concrete
fill 542 169 547 542 177 548 minecraft:blackstone
setblock 548 169 552 minecraft:magma_block
fill 554 169 527 555 179 527 minecraft:blackstone
fill 554 169 552 554 179 552 minecraft:black_concrete
fill 559 169 545 559 179 545 minecraft:black_concrete
setblock 536 170 552 minecraft:white_concrete
setblock 545 170 510 minecraft:white_concrete
fill 546 170 510 546 179 510 minecraft:black_concrete
fill 548 170 552 548 176 552 minecraft:black_concrete
setblock 559 170 546 minecraft:magma_block
setblock 559 170 549 minecraft:shroomlight
fill 517 171 518 517 173 518 minecraft:orange_concrete
fill 517 171 534 517 173 534 minecraft:orange_concrete
setblock 517 171 538 minecraft:shroomlight
setblock 517 171 546 minecraft:white_concrete
fill 517 171 550 517 173 550 minecraft:orange_concrete
fill 521 171 510 521 173 510 minecraft:orange_concrete
setblock 527 171 510 minecraft:shroomlight
fill 531 171 552 531 173 552 minecraft:orange_concrete
setblock 533 171 510 minecraft:magma_block
fill 536 171 552 536 179 552 minecraft:black_concrete
fill 537 171 510 537 173 510 minecraft:orange_concrete
fill 541 171 547 541 177 548 minecraft:blackstone
fill 543 171 547 543 177 548 minecraft:blackstone
fill 545 171 510 545 177 510 minecraft:black_concrete
fill 547 171 552 547 173 552 minecraft:orange_concrete
fill 553 171 510 553 173 510 minecraft:orange_concrete
fill 554 171 526 555 179 526 minecraft:blackstone
fill 554 171 528 555 179 528 minecraft:blackstone
setblock 557 171 510 minecraft:magma_block
setblock 559 171 512 minecraft:white_concrete
fill 559 171 520 559 173 520 minecraft:orange_concrete
fill 559 171 536 559 173 536 minecraft:orange_concrete
fill 559 171 546 559 175 546 minecraft:black_concrete
fill 559 171 549 559 179 549 minecraft:black_concrete
setblock 517 172 527 minecraft:shroomlight
fill 517 172 538 517 177 538 minecraft:black_concrete
fill 517 172 546 517 179 546 minecraft:black_concrete
fill 527 172 510 527 179 510 minecraft:black_concrete
fill 533 172 510 533 179 510 minecraft:black_concrete
fill 541 172 546 542 177 546 minecraft:blackstone
fill 541 172 549 542 177 549 minecraft:blackstone
fill 553 172 526 553 179 528 minecraft:blackstone
fill 554 172 521 554 173 521 minecraft:blackstone
fill 554 172 525 554 179 525 minecraft:blackstone
fill 556 172 526 556 179 528 minecraft:blackstone
fill 557 172 510 557 179 510 minecraft:black_concrete
fill 559 172 512 559 179 512 minecraft:black_concrete
setblock 559 172 521 minecraft:white_concrete
setblock 517 173 517 minecraft:white_concrete
fill 517 173 527 517 179 527 minecraft:black_concrete
setblock 517 173 535 minecraft:shroomlight
fill 529 173 543 530 174 544 minecraft:blackstone
fill 540 173 547 540 177 548 minecraft:blackstone
setblock 543 173 510 minecraft:white_concrete
fill 543 173 546 543 177 546 minecraft:blackstone
fill 543 173 549 543 177 549 minecraft:blackstone
fill 544 173 547 544 177 548 minecraft:blackstone
fill 553 173 525 553 179 525 minecraft:blackstone
fill 554 173 529 555 179 529 minecraft:blackstone
fill 555 173 525 556 179 525 minecraft:blackstone
fill 555 173 552 555 176 552 minecraft:black_concrete
fill 556 173 552 557 173 552 minecraft:magma_block
fill 559 173 521 559 175 521 minecraft:black_concrete
fill 517 174 517 517 179 518 minecraft:black_concrete
fill 517 174 534 517 179 535 minecraft:black_concrete
fill 517 174 550 517 177 550 minecraft:black_concrete
setblock 520 174 513 minecraft:light[level=14]
setblock 520 174 521 minecraft:light[level=14]
setblock 520 174 529 minecraft:light[level=14]
setblock 520 174 537 minecraft:light[level=14]
setblock 520 174 545 minecraft:light[level=14]
fill 521 174 510 521 179 510 minecraft:black_concrete
setblock 528 174 513 minecraft:light[level=14]
setblock 528 174 521 minecraft:light[level=14]
setblock 528 174 529 minecraft:light[level=14]
setblock 528 174 537 minecraft:light[level=14]
setblock 528 174 545 minecraft:light[level=14]
fill 531 174 552 531 179 552 minecraft:black_concrete
setblock 536 174 513 minecraft:light[level=14]
setblock 536 174 521 minecraft:light[level=14]
setblock 536 174 529 minecraft:light[level=14]
setblock 536 174 537 minecraft:light[level=14]
setblock 536 174 545 minecraft:light[level=14]
fill 537 174 510 537 179 510 minecraft:black_concrete
fill 540 174 546 540 177 546 minecraft:blackstone
fill 540 174 549 540 177 549 minecraft:blackstone
fill 541 174 545 543 177 545 minecraft:blackstone
fill 541 174 550 542 177 550 minecraft:blackstone
fill 543 174 510 543 176 510 minecraft:black_concrete
setblock 544 174 513 minecraft:light[level=14]
setblock 544 174 521 minecraft:light[level=14]
setblock 544 174 529 minecraft:light[level=14]
setblock 544 174 537 minecraft:light[level=14]
setblock 544 174 545 minecraft:light[level=14]
fill 544 174 546 544 177 546 minecraft:blackstone
fill 544 174 549 544 177 549 minecraft:blackstone
fill 547 174 552 547 179 552 minecraft:black_concrete
setblock 552 174 513 minecraft:light[level=14]
setblock 552 174 521 minecraft:light[level=14]
fill 552 174 526 552 179 528 minecraft:blackstone
setblock 552 174 529 minecraft:light[level=14]
setblock 552 174 537 minecraft:light[level=14]
setblock 552 174 545 minecraft:light[level=14]
fill 553 174 510 553 179 510 minecraft:black_concrete
fill 553 174 529 553 179 529 minecraft:blackstone
fill 554 174 524 555 179 524 minecraft:blackstone
fill 556 174 529 556 179 529 minecraft:blackstone
fill 556 174 552 557 179 552 minecraft:black_concrete
fill 557 174 526 557 179 528 minecraft:blackstone
fill 559 174 520 559 179 520 minecraft:black_concrete
fill 559 174 536 559 176 536 minecraft:black_concrete
fill 523 175 510 523 179 510 minecraft:black_concrete
setblock 524 175 510 minecraft:shroomlight
fill 525 175 510 525 179 510 minecraft:black_concrete
setblock 526 175 510 minecraft:shroomlight
setblock 528 175 552 minecraft:magma_block
fill 539 175 546 539 177 549 minecraft:blackstone
fill 540 175 545 540 177 545 minecraft:blackstone
fill 540 175 550 540 177 550 minecraft:blackstone
fill 543 175 550 543 177 550 minecraft:blackstone
fill 545 175 527 546 176 529 minecraft:blue_concrete
fill 545 175 547 545 177 548 minecraft:blackstone
fill 552 175 525 552 179 525 minecraft:blackstone
fill 552 175 529 552 179 529 minecraft:blackstone
fill 553 175 524 553 179 524 minecraft:blackstone
fill 554 175 530 555 179 530 minecraft:blackstone
fill 556 175 524 556 179 524 minecraft:blackstone
fill 557 175 525 557 179 525 minecraft:blackstone
fill 557 175 529 557 179 529 minecraft:blackstone
setblock 559 175 535 minecraft:magma_block
setblock 517 176 514 minecraft:blue_concrete
setblock 517 176 526 minecraft:blue_concrete
setblock 517 176 531 minecraft:blue_concrete
setblock 517 176 547 minecraft:blue_concrete
setblock 517 176 552 minecraft:blue_concrete
fill 524 176 510 524 179 510 minecraft:black_concrete
setblock 524 176 552 minecraft:blue_concrete
fill 526 176 510 526 179 510 minecraft:black_concrete
setblock 527 176 552 minecraft:blue_concrete
setblock 528 176 552 minecraft:white_concrete
setblock 535 176 510 minecraft:shroomlight
setblock 539 176 510 minecraft:blue_concrete
fill 539 176 545 539 177 545 minecraft:blackstone
fill 541 176 544 543 177 544 minecraft:blackstone
fill 541 176 551 542 177 551 minecraft:blackstone
fill 541 176 552 541 179 552 minecraft:black_concrete
setblock 542 176 552 minecraft:magma_block
fill 543 176 552 543 180 552 minecraft:black_concrete
fill 544 176 545 544 177 545 minecraft:blackstone
fill 544 176 550 544 177 550 minecraft:blackstone
fill 545 176 546 545 177 546 minecraft:blackstone
fill 545 176 549 545 177 549 minecraft:blackstone
fill 545 176 552 545 180 552 minecraft:black_concrete
setblock 546 176 552 minecraft:blue_concrete
fill 551 176 526 551 179 528 minecraft:blackstone
fill 552 176 524 552 179 524 minecraft:blackstone
fill 553 176 530 553 179 530 minecraft:blackstone
fill 554 176 523 555 179 523 minecraft:blackstone
setblock 555 176 510 minecraft:magma_block
fill 556 176 530 556 179 530 minecraft:blackstone
fill 557 176 524 557 179 524 minecraft:blackstone
fill 558 176 526 558 179 528 minecraft:blackstone
setblock 559 176 514 minecraft:blue_concrete
setblock 559 176 521 minecraft:blue_concrete
setblock 559 176 528 minecraft:blue_concrete
fill 559 176 533 559 176 534 minecraft:blue_concrete
setblock 559 176 535 minecraft:black_concrete
setblock 559 176 546 minecraft:white_concrete
setblock 559 176 552 minecraft:blue_concrete
setblock 517 177 510 minecraft:blue_concrete
setblock 517 177 511 minecraft:magma_block
fill 517 177 514 517 179 514 minecraft:black_concrete
fill 517 177 519 517 180 519 minecraft:black_concrete
setblock 517 177 520 minecraft:blue_concrete
fill 517 177 526 517 179 526 minecraft:black_concrete
fill 517 177 531 517 179 531 minecraft:black_concrete
setblock 517 177 545 minecraft:blue_concrete
fill 517 177 547 517 179 547 minecraft:black_concrete
fill 517 177 551 517 178 551 minecraft:blue_concrete
fill 517 177 552 517 179 552 minecraft:black_concrete
fill 520 177 532 521 178 533 minecraft:magma_block
fill 522 177 533 522 178 533 minecraft:magma_block
fill 524 177 552 524 179 552 minecraft:black_concrete
setblock 526 177 552 minecraft:blue_concrete
fill 527 177 552 528 179 552 minecraft:black_concrete
setblock 530 177 510 minecraft:blue_concrete
setblock 532 177 510 minecraft:blue_concrete
setblock 535 177 510 minecraft:blue_concrete
setblock 535 177 552 minecraft:blue_concrete
fill 538 177 546 538 177 549 minecraft:blackstone
fill 539 177 510 539 179 510 minecraft:black_concrete
setblock 539 177 550 minecraft:blackstone
setblock 540 177 544 minecraft:blackstone
setblock 540 177 551 minecraft:blackstone
fill 542 177 552 542 179 552 minecraft:black_concrete
setblock 543 177 510 minecraft:blue_concrete
fill 543 177 551 544 177 551 minecraft:blackstone
setblock 544 177 544 minecraft:blackstone
setblock 545 177 545 minecraft:blackstone
setblock 545 177 550 minecraft:blackstone
fill 546 177 552 546 179 552 minecraft:black_concrete
fill 548 177 552 549 177 552 minecraft:blue_concrete
fill 551 177 525 551 179 525 minecraft:blackstone
fill 551 177 529 551 179 529 minecraft:blackstone
fill 552 177 530 552 179 530 minecraft:blackstone
fill 553 177 523 553 179 523 minecraft:blackstone
fill 553 177 531 556 179 531 minecraft:blackstone
fill 555 177 510 555 179 510 minecraft:black_concrete
setblock 555 177 552 minecraft:blue_concrete
fill 556 177 523 556 179 523 minecraft:blackstone
fill 557 177 530 557 179 530 minecraft:blackstone
fill 558 177 525 558 179 525 minecraft:blackstone
fill 558 177 529 558 179 529 minecraft:blackstone
fill 559 177 514 559 179 514 minecraft:black_concrete
setblock 559 177 517 minecraft:blue_concrete
fill 559 177 521 559 179 521 minecraft:black_concrete
fill 559 177 528 559 179 528 minecraft:black_concrete
fill 559 177 531 559 177 532 minecraft:blue_concrete
fill 559 177 533 559 179 534 minecraft:black_concrete
fill 559 177 535 559 177 536 minecraft:blue_concrete
setblock 559 177 546 minecraft:blue_concrete
setblock 559 177 552 minecraft:black_concrete
fill 517 178 510 517 179 511 minecraft:black_concrete
fill 517 178 520 517 179 520 minecraft:black_concrete
setblock 517 178 536 minecraft:blue_concrete
setblock 517 178 538 minecraft:shroomlight
setblock 517 178 542 minecraft:blue_concrete
fill 517 178 545 517 179 545 minecraft:black_concrete
fill 517 178 548 517 178 550 minecraft:blue_concrete
setblock 518 178 552 minecraft:blue_concrete
fill 519 178 552 519 179 552 minecraft:black_concrete
setblock 522 178 552 minecraft:magma_block
fill 526 178 552 526 180 552 minecraft:black_concrete
fill 530 178 510 530 179 510 minecraft:black_concrete
fill 532 178 510 532 179 510 minecraft:black_concrete
fill 535 178 510 535 179 510 minecraft:black_concrete
fill 535 178 552 535 179 552 minecraft:black_concrete
fill 537 178 552 538 179 552 minecraft:black_concrete
setblock 539 178 552 minecraft:shroomlight
fill 541 178 547 542 179 548 minecraft:magma_block
setblock 542 178 510 minecraft:blue_concrete
fill 543 178 510 543 179 510 minecraft:black_concrete
setblock 543 178 547 minecraft:magma_block
setblock 544 178 510 minecraft:magma_block
setblock 545 178 510 minecraft:blue_concrete
setblock 547 178 510 minecraft:blue_concrete
fill 548 178 552 549 179 552 minecraft:black_concrete
fill 550 178 525 550 179 528 minecraft:blackstone
setblock 550 178 552 minecraft:magma_block
fill 551 178 524 551 179 524 minecraft:blackstone
fill 551 178 530 551 179 530 minecraft:blackstone
fill 552 178 523 552 179 523 minecraft:blackstone
fill 552 178 531 552 179 531 minecraft:blackstone
fill 554 178 522 554 179 522 minecraft:blackstone
fill 555 178 552 555 179 552 minecraft:black_concrete
fill 557 178 523 557 179 523 minecraft:blackstone
fill 557 178 531 557 179 531 minecraft:blackstone
fill 558 178 524 558 179 524 minecraft:blackstone
fill 558 178 530 558 179 530 minecraft:blackstone
setblock 559 178 510 minecraft:blue_concrete
setblock 559 178 516 minecraft:blue_concrete
fill 559 178 517 559 179 517 minecraft:black_concrete
setblock 559 178 522 minecraft:blue_concrete
fill 559 178 523 559 179 523 minecraft:black_concrete
setblock 559 178 526 minecraft:blue_concrete
setblock 559 178 530 minecraft:blue_concrete
fill 559 178 531 559 179 532 minecraft:black_concrete
fill 559 178 535 559 179 536 minecraft:black_concrete
setblock 559 178 537 minecraft:blue_concrete
setblock 559 178 543 minecraft:blue_concrete
fill 559 178 546 559 179 546 minecraft:black_concrete
setblock 559 178 548 minecraft:blue_concrete
setblock 559 178 550 minecraft:blue_concrete
setblock 559 178 552 minecraft:blue_concrete
setblock 517 179 536 minecraft:black_concrete
fill 517 179 538 517 180 538 minecraft:black_concrete
setblock 517 179 542 minecraft:black_concrete
fill 517 179 548 517 179 551 minecraft:black_concrete
setblock 518 179 552 minecraft:black_concrete
setblock 522 179 552 minecraft:black_concrete
setblock 539 179 552 minecraft:black_concrete
setblock 542 179 510 minecraft:black_concrete
fill 544 179 510 545 179 510 minecraft:black_concrete
setblock 547 179 510 minecraft:black_concrete
setblock 550 179 524 minecraft:blackstone
setblock 550 179 529 minecraft:blackstone
setblock 550 179 552 minecraft:black_concrete
setblock 551 179 523 minecraft:blackstone
setblock 553 179 522 minecraft:blackstone
fill 553 179 532 556 179 532 minecraft:blackstone
fill 555 179 522 556 179 522 minecraft:blackstone
setblock 558 179 523 minecraft:blackstone
setblock 559 179 510 minecraft:black_concrete
setblock 559 179 516 minecraft:black_concrete
fill 559 179 522 559 180 522 minecraft:black_concrete
setblock 559 179 526 minecraft:black_concrete
fill 559 179 530 559 180 530 minecraft:black_concrete
setblock 559 179 537 minecraft:black_concrete
setblock 559 179 543 minecraft:black_concrete
setblock 559 179 548 minecraft:black_concrete
setblock 559 179 550 minecraft:black_concrete
setblock 559 179 552 minecraft:black_concrete
fill 517 180 510 517 182 517 minecraft:blue_concrete
fill 517 180 518 517 182 518 minecraft:orange_concrete
fill 517 180 520 517 180 522 minecraft:blue_concrete
fill 517 180 525 517 181 533 minecraft:blue_concrete
fill 517 180 534 517 182 534 minecraft:orange_concrete
fill 517 180 535 517 184 537 minecraft:blue_concrete
fill 517 180 539 517 180 549 minecraft:blue_concrete
fill 517 180 550 517 182 550 minecraft:orange_concrete
fill 517 180 551 517 191 552 minecraft:blue_concrete
fill 518 180 510 520 180 510 minecraft:blue_concrete
fill 518 180 552 525 181 552 minecraft:blue_concrete
fill 521 180 510 521 182 510 minecraft:orange_concrete
fill 522 180 510 536 180 510 minecraft:blue_concrete
fill 527 180 552 528 217 552 minecraft:blue_concrete
setblock 529 180 552 minecraft:black_concrete
fill 530 180 552 530 192 552 minecraft:blue_concrete
fill 531 180 552 531 182 552 minecraft:orange_concrete
fill 532 180 552 542 180 552 minecraft:blue_concrete
fill 537 180 510 537 182 510 minecraft:orange_concrete
fill 539 180 510 543 180 510 minecraft:blue_concrete
fill 542 180 547 542 180 548 minecraft:magma_block
setblock 544 180 510 minecraft:shroomlight
fill 544 180 552 544 239 552 minecraft:blue_concrete
fill 545 180 510 549 180 510 minecraft:blue_concrete
fill 546 180 552 546 190 552 minecraft:blue_concrete
fill 547 180 552 547 182 552 minecraft:orange_concrete
fill 548 180 552 555 180 552 minecraft:blue_concrete
setblock 550 180 510 minecraft:black_concrete
fill 551 180 510 552 188 510 minecraft:blue_concrete
fill 551 180 528 552 181 528 minecraft:blackstone
fill 553 180 510 553 182 510 minecraft:orange_concrete
fill 554 180 510 559 180 510 minecraft:blue_concrete
fill 554 180 526 555 180 528 minecraft:magma_block
setblock 556 180 552 minecraft:black_concrete
fill 557 180 552 559 180 552 minecraft:blue_concrete
fill 559 180 511 559 180 517 minecraft:blue_concrete
fill 559 180 519 559 195 519 minecraft:blue_concrete
fill 559 180 520 559 182 520 minecraft:orange_concrete
setblock 559 180 521 minecraft:blue_concrete
fill 559 180 523 559 180 528 minecraft:blue_concrete
fill 559 180 531 559 216 532 minecraft:blue_concrete
setblock 559 180 533 minecraft:black_concrete
fill 559 180 534 559 191 535 minecraft:blue_concrete
fill 559 180 536 559 182 536 minecraft:orange_concrete
fill 559 180 537 559 180 544 minecraft:blue_concrete
setblock 559 180 545 minecraft:white_concrete
fill 559 180 546 559 180 551 minecraft:blue_concrete
setblock 517 181 519 minecraft:white_concrete
fill 517 181 520 517 208 520 minecraft:blue_concrete
fill 517 181 521 517 181 522 minecraft:black_concrete
fill 517 181 523 517 199 524 minecraft:blue_concrete
fill 517 181 538 517 184 540 minecraft:blue_concrete
setblock 517 181 541 minecraft:black_concrete
fill 517 181 542 517 183 548 minecraft:blue_concrete
setblock 517 181 549 minecraft:black_concrete
fill 518 181 510 519 181 510 minecraft:black_concrete
fill 520 181 510 520 243 510 minecraft:blue_concrete
fill 522 181 510 522 198 510 minecraft:blue_concrete
setblock 523 181 510 minecraft:black_concrete
setblock 524 181 510 minecraft:shroomlight
fill 525 181 510 533 182 510 minecraft:blue_concrete
fill 526 181 552 526 197 552 minecraft:blue_concrete
fill 529 181 552 529 183 552 minecraft:blue_concrete
fill 532 181 552 538 181 552 minecraft:blue_concrete
setblock 534 181 510 minecraft:black_concrete
fill 535 181 510 535 211 510 minecraft:blue_concrete
setblock 536 181 510 minecraft:black_concrete
setblock 539 181 510 minecraft:shroomlight
setblock 539 181 552 minecraft:black_concrete
fill 540 181 510 544 181 510 minecraft:blue_concrete
fill 540 181 552 543 181 552 minecraft:blue_concrete
setblock 542 181 547 minecraft:magma_block
setblock 545 181 510 minecraft:black_concrete
setblock 545 181 552 minecraft:blue_concrete
fill 546 181 510 550 181 510 minecraft:blue_concrete
fill 548 181 552 550 185 552 minecraft:blue_concrete
fill 551 181 552 551 182 552 minecraft:black_concrete
fill 552 181 552 556 191 552 minecraft:blue_concrete
fill 554 181 510 555 198 510 minecraft:blue_concrete
fill 554 181 526 555 181 527 minecraft:magma_block
setblock 556 181 510 minecraft:black_concrete
fill 557 181 510 559 192 510 minecraft:blue_concrete
setblock 557 181 552 minecraft:black_concrete
fill 558 181 552 559 240 552 minecraft:blue_concrete
fill 559 181 511 559 221 511 minecraft:blue_concrete
setblock 559 181 512 minecraft:black_concrete
fill 559 181 513 559 181 518 minecraft:blue_concrete
setblock 559 181 521 minecraft:black_concrete
fill 559 181 522 559 219 525 minecraft:blue_concrete
fill 559 181 526 559 181 528 minecraft:black_concrete
fill 559 181 529 559 198 530 minecraft:blue_concrete
fill 559 181 533 559 243 533 minecraft:blue_concrete
fill 559 181 537 559 192 540 minecraft:blue_concrete
setblock 559 181 541 minecraft:black_concrete
fill 559 181 542 559 197 546 minecraft:blue_concrete
setblock 559 181 547 minecraft:magma_block
setblock 559 181 548 minecraft:black_concrete
fill 559 181 549 559 186 551 minecraft:blue_concrete
fill 517 182 519 517 218 519 minecraft:blue_concrete
fill 517 182 521 517 199 522 minecraft:blue_concrete
fill 517 182 525 517 195 529 minecraft:blue_concrete
setblock 517 182 530 minecraft:black_concrete
fill 517 182 531 517 206 533 minecraft:blue_concrete
fill 517 182 541 517 240 541 minecraft:blue_concrete
fill 517 182 549 517 183 549 minecraft:blue_concrete
fill 518 182 510 518 185 510 minecraft:blue_concrete
fill 518 182 552 519 243 552 minecraft:blue_concrete
setblock 519 182 510 minecraft:black_concrete
setblock 520 182 513 minecraft:light[level=14]
setblock 520 182 521 minecraft:light[level=14]
setblock 520 182 529 minecraft:light[level=14]
setblock 520 182 537 minecraft:light[level=14]
setblock 520 182 545 minecraft:light[level=14]
fill 520 182 552 522 182 552 minecraft:black_concrete
fill 523 182 510 524 196 510 minecraft:blue_concrete
fill 523 182 552 525 194 552 minecraft:blue_concrete
setblock 528 182 513 minecraft:light[level=14]
setblock 528 182 521 minecraft:light[level=14]
setblock 528 182 529 minecraft:light[level=14]
setblock 528 182 537 minecraft:light[level=14]
setblock 528 182 545 minecraft:light[level=14]
fill 532 182 552 532 186 552 minecraft:blue_concrete
setblock 533 182 552 minecraft:black_concrete
fill 534 182 510 534 243 510 minecraft:blue_concrete
fill 534 182 552 536 185 552 minecraft:blue_concrete
fill 536 182 510 536 207 510 minecraft:blue_concrete
setblock 536 182 513 minecraft:light[level=14]
setblock 536 182 521 minecraft:light[level=14]
setblock 536 182 529 minecraft:light[level=14]
setblock 536 182 537 minecraft:light[level=14]
setblock 536 182 545 minecraft:light[level=14]
setblock 537 182 552 minecraft:black_concrete
fill 538 182 510 540 199 510 minecraft:blue_concrete
fill 538 182 552 540 187 552 minecraft:blue_concrete
fill 541 182 510 542 182 510 minecraft:black_concrete
setblock 541 182 552 minecraft:shroomlight
fill 542 182 552 543 224 552 minecraft:blue_concrete
fill 543 182 510 546 215 510 minecraft:blue_concrete
setblock 544 182 513 minecraft:light[level=14]
setblock 544 182 521 minecraft:light[level=14]
setblock 544 182 529 minecraft:light[level=14]
setblock 544 182 537 minecraft:light[level=14]
setblock 544 182 545 minecraft:light[level=14]
setblock 545 182 552 minecraft:black_concrete
setblock 547 182 510 minecraft:black_concrete
fill 548 182 510 550 199 510 minecraft:blue_concrete
setblock 552 182 513 minecraft:light[level=14]
setblock 552 182 521 minecraft:light[level=14]
setblock 552 182 529 minecraft:light[level=14]
setblock 552 182 537 minecraft:light[level=14]
setblock 552 182 545 minecraft:light[level=14]
fill 554 182 527 555 183 527 minecraft:magma_block
fill 556 182 510 556 243 510 minecraft:blue_concrete
fill 557 182 552 557 193 552 minecraft:blue_concrete
fill 559 182 512 559 204 514 minecraft:blue_concrete
fill 559 182 515 559 182 516 minecraft:black_concrete
fill 559 182 517 559 183 518 minecraft:blue_concrete
fill 559 182 521 559 238 521 minecraft:blue_concrete
fill 559 182 526 559 207 528 minecraft:blue_concrete
fill 559 182 541 559 243 541 minecraft:blue_concrete
fill 559 182 547 559 187 548 minecraft:blue_concrete
fill 517 183 510 517 240 510 minecraft:blue_concrete
setblock 517 183 511 minecraft:white_concrete
fill 517 183 512 517 188 518 minecraft:blue_concrete
fill 517 183 530 517 220 530 minecraft:blue_concrete
fill 517 183 534 517 188 534 minecraft:blue_concrete
fill 517 183 550 517 188 550 minecraft:blue_concrete
fill 519 183 510 519 222 510 minecraft:blue_concrete
fill 520 183 552 522 185 552 minecraft:blue_concrete
setblock 521 183 510 minecraft:blue_concrete
fill 525 183 510 528 198 510 minecraft:blue_concrete
setblock 529 183 510 minecraft:magma_block
fill 530 183 510 532 208 510 minecraft:blue_concrete
fill 531 183 552 531 188 552 minecraft:blue_concrete
setblock 533 183 510 minecraft:white_concrete
fill 533 183 552 533 243 552 minecraft:blue_concrete
fill 537 183 510 537 188 510 minecraft:blue_concrete
fill 537 183 552 537 240 552 minecraft:blue_concrete
fill 541 183 510 542 197 510 minecraft:blue_concrete
fill 541 183 552 541 241 552 minecraft:blue_concrete
fill 545 183 552 545 236 552 minecraft:blue_concrete
fill 547 183 510 547 243 510 minecraft:blue_concrete
fill 547 183 552 547 188 552 minecraft:blue_concrete
setblock 551 183 552 minecraft:shroomlight
fill 553 183 510 553 188 510 minecraft:blue_concrete
fill 559 183 515 559 191 516 minecraft:blue_concrete
fill 559 183 520 559 188 520 minecraft:blue_concrete
fill 559 183 536 559 188 536 minecraft:blue_concrete
setblock 517 184 511 minecraft:blue_concrete
fill 517 184 542 517 216 542 minecraft:blue_concrete
setblock 517 184 543 minecraft:shroomlight
fill 517 184 544 517 206 545 minecraft:blue_concrete
setblock 517 184 546 minecraft:magma_block
fill 517 184 547 517 192 548 minecraft:blue_concrete
setblock 517 184 549 minecraft:magma_block
setblock 521 184 510 minecraft:white_concrete
fill 524 184 520 525 185 521 minecraft:blackstone
fill 529 184 510 529 199 510 minecraft:blue_concrete
setblock 529 184 552 minecraft:white_concrete
fill 533 184 510 533 220 510 minecraft:blue_concrete
fill 551 184 552 551 199 552 minecraft:blue_concrete
setblock 559 184 517 minecraft:white_concrete
fill 559 184 518 559 210 518 minecraft:blue_concrete
setblock 517 185 511 minecraft:magma_block
setblock 517 185 535 minecraft:magma_block
fill 517 185 536 517 194 537 minecraft:blue_concrete
setblock 517 185 538 minecraft:magma_block
fill 517 185 539 517 191 540 minecraft:blue_concrete
fill 517 185 543 517 193 543 minecraft:blue_concrete
fill 517 185 546 517 243 546 minecraft:blue_concrete
fill 517 185 549 517 205 549 minecraft:blue_concrete
fill 521 185 510 521 188 510 minecraft:blue_concrete
fill 529 185 552 529 225 552 minecraft:blue_concrete
fill 549 185 539 552 189 539 minecraft:yellow_concrete
fill 550 185 538 552 189 538 minecraft:yellow_concrete
fill 550 185 540 552 189 540 minecraft:yellow_concrete
fill 559 185 517 559 191 517 minecraft:blue_concrete
fill 517 186 511 517 243 511 minecraft:blue_concrete
fill 517 186 535 517 228 535 minecraft:blue_concrete
fill 517 186 538 517 243 538 minecraft:blue_concrete
setblock 518 186 510 minecraft:white_concrete
fill 520 186 552 520 231 552 minecraft:blue_concrete
setblock 521 186 552 minecraft:magma_block
fill 522 186 552 522 207 552 minecraft:blue_concrete
fill 534 186 538 534 187 539 minecraft:blue_concrete
setblock 534 186 552 minecraft:white_concrete
fill 535 186 552 536 243 552 minecraft:blue_concrete
fill 548 186 538 548 189 540 minecraft:yellow_concrete
setblock 548 186 552 minecraft:shroomlight
fill 549 186 537 549 189 538 minecraft:yellow_concrete
fill 549 186 540 549 189 541 minecraft:yellow_concrete
fill 549 186 552 550 203 552 minecraft:blue_concrete
fill 550 186 537 553 189 537 minecraft:yellow_concrete
fill 550 186 541 551 189 542 minecraft:yellow_concrete
fill 551 186 536 551 189 536 minecraft:yellow_concrete
fill 552 186 541 553 189 541 minecraft:yellow_concrete
fill 553 186 538 553 189 540 minecraft:yellow_concrete
fill 518 187 510 518 232 510 minecraft:blue_concrete
fill 521 187 552 521 210 552 minecraft:blue_concrete
setblock 532 187 552 minecraft:white_concrete
fill 534 187 552 534 194 552 minecraft:blue_concrete
fill 548 187 537 548 189 537 minecraft:yellow_concrete
fill 548 187 541 548 189 541 minecraft:yellow_concrete
fill 548 187 552 548 196 552 minecraft:blue_concrete
fill 549 187 536 550 189 536 minecraft:yellow_concrete
fill 549 187 542 549 189 542 minecraft:yellow_concrete
fill 552 187 536 552 189 536 minecraft:yellow_concrete
fill 552 187 542 553 189 542 minecraft:yellow_concrete
fill 554 187 538 554 189 540 minecraft:yellow_concrete
fill 559 187 549 559 204 550 minecraft:blue_concrete
setblock 559 187 551 minecraft:white_concrete
fill 523 188 529 523 189 529 minecraft:red_terracotta
fill 532 188 552 532 228 552 minecraft:blue_concrete
fill 535 188 532 536 188 534 minecraft:light_blue_concrete
fill 536 188 531 539 188 531 minecraft:light_blue_concrete
fill 537 188 532 540 188 533 minecraft:light_blue_concrete
fill 538 188 534 539 188 535 minecraft:light_blue_concrete
setblock 538 188 552 minecraft:shroomlight
fill 539 188 552 540 243 552 minecraft:blue_concrete
setblock 540 188 534 minecraft:light_blue_concrete
fill 547 188 538 547 189 540 minecraft:yellow_concrete
fill 551 188 543 551 189 543 minecraft:yellow_concrete
fill 553 188 536 553 189 536 minecraft:yellow_concrete
fill 554 188 537 554 189 537 minecraft:yellow_concrete
fill 554 188 541 554 189 541 minecraft:yellow_concrete
fill 559 188 547 559 203 547 minecraft:blue_concrete
setblock 559 188 548 minecraft:magma_block
fill 559 188 551 559 194 551 minecraft:blue_concrete
fill 517 189 512 517 193 517 minecraft:blue_concrete
setblock 517 189 518 minecraft:orange_concrete
setblock 517 189 534 minecraft:orange_concrete
setblock 517 189 550 minecraft:orange_concrete
setblock 521 189 510 minecraft:orange_concrete
setblock 531 189 552 minecraft:orange_concrete
fill 533 189 532 534 189 534 minecraft:light_blue_concrete
fill 534 189 530 535 189 531 minecraft:light_blue_concrete
fill 534 189 535 535 189 536 minecraft:light_blue_concrete
fill 535 189 532 536 193 534 minecraft:blue_concrete
fill 536 189 529 539 189 530 minecraft:light_blue_concrete
fill 536 189 531 539 193 531 minecraft:blue_concrete
fill 536 189 536 536 189 537 minecraft:light_blue_concrete
setblock 537 189 510 minecraft:orange_concrete
fill 537 189 532 540 193 533 minecraft:blue_concrete
fill 537 189 537 539 189 537 minecraft:light_blue_concrete
fill 538 189 534 539 189 535 minecraft:blue_concrete
fill 538 189 536 541 189 536 minecraft:light_blue_concrete
fill 538 189 552 538 219 552 minecraft:blue_concrete
fill 540 189 530 541 189 531 minecraft:light_blue_concrete
fill 540 189 534 540 202 534 minecraft:blue_concrete
fill 540 189 535 541 189 535 minecraft:light_blue_concrete
fill 541 189 532 542 189 534 minecraft:light_blue_concrete
setblock 547 189 552 minecraft:orange_concrete
setblock 551 189 510 minecraft:shroomlight
fill 552 189 510 552 191 510 minecraft:blue_concrete
setblock 553 189 510 minecraft:orange_concrete
setblock 559 189 520 minecraft:orange_concrete
setblock 559 189 536 minecraft:orange_concrete
fill 559 189 548 559 219 548 minecraft:blue_concrete
fill 517 190 518 517 199 518 minecraft:blue_concrete
fill 517 190 534 517 199 534 minecraft:blue_concrete
fill 517 190 550 517 199 550 minecraft:blue_concrete
setblock 520 190 513 minecraft:light[level=14]
setblock 520 190 521 minecraft:light[level=14]
setblock 520 190 529 minecraft:light[level=14]
setblock 520 190 537 minecraft:light[level=14]
setblock 520 190 545 minecraft:light[level=14]
fill 521 190 510 521 199 510 minecraft:blue_concrete
setblock 528 190 513 minecraft:light[level=14]
setblock 528 190 521 minecraft:light[level=14]
setblock 528 190 529 minecraft:light[level=14]
setblock 528 190 537 minecraft:light[level=14]
setblock 528 190 545 minecraft:light[level=14]
fill 531 190 552 531 199 552 minecraft:blue_concrete
fill 532 190 532 532 190 534 minecraft:light_blue_concrete
fill 533 190 530 533 190 531 minecraft:light_blue_concrete
fill 533 190 532 534 193 534 minecraft:blue_concrete
fill 533 190 535 533 190 536 minecraft:light_blue_concrete
fill 534 190 529 535 190 529 minecraft:light_blue_concrete
fill 534 190 530 535 193 531 minecraft:blue_concrete
fill 534 190 535 535 195 536 minecraft:blue_concrete
fill 534 190 537 535 190 537 minecraft:light_blue_concrete
fill 535 190 528 540 190 528 minecraft:light_blue_concrete
fill 535 190 538 540 190 538 minecraft:light_blue_concrete
setblock 536 190 513 minecraft:light[level=14]
setblock 536 190 521 minecraft:light[level=14]
fill 536 190 529 539 193 530 minecraft:blue_concrete
fill 536 190 536 536 193 537 minecraft:blue_concrete
setblock 536 190 545 minecraft:light[level=14]
setblock 537 190 510 minecraft:blue_concrete
fill 537 190 537 539 195 537 minecraft:blue_concrete
fill 538 190 534 539 193 534 minecraft:blue_concrete
fill 538 190 536 541 193 536 minecraft:blue_concrete
fill 539 190 535 541 195 535 minecraft:blue_concrete
fill 540 190 529 541 190 529 minecraft:light_blue_concrete
fill 540 190 530 541 193 531 minecraft:blue_concrete
fill 540 190 537 541 190 537 minecraft:light_blue_concrete
fill 541 190 532 542 193 534 minecraft:blue_concrete
fill 542 190 530 542 190 531 minecraft:light_blue_concrete
fill 542 190 535 542 190 536 minecraft:light_blue_concrete
fill 543 190 532 543 190 534 minecraft:light_blue_concrete
setblock 544 190 513 minecraft:light[level=14]
setblock 544 190 521 minecraft:light[level=14]
setblock 544 190 529 minecraft:light[level=14]
setblock 544 190 537 minecraft:light[level=14]
setblock 544 190 545 minecraft:light[level=14]
fill 547 190 552 547 199 552 minecraft:blue_concrete
fill 551 190 510 551 240 510 minecraft:blue_concrete
setblock 552 190 513 minecraft:light[level=14]
setblock 552 190 521 minecraft:light[level=14]
setblock 552 190 529 minecraft:light[level=14]
setblock 552 190 537 minecraft:light[level=14]
setblock 552 190 545 minecraft:light[level=14]
fill 553 190 510 553 199 510 minecraft:blue_concrete
fill 559 190 520 559 199 520 minecraft:blue_concrete
fill 559 190 536 559 194 536 minecraft:blue_concrete
fill 531 191 532 531 192 534 minecraft:light_blue_concrete
fill 532 191 530 532 191 531 minecraft:light_blue_concrete
fill 532 191 532 532 193 534 minecraft:blue_concrete
fill 532 191 535 532 191 536 minecraft:light_blue_concrete
setblock 533 191 529 minecraft:light_blue_concrete
fill 533 191 530 533 193 531 minecraft:blue_concrete
fill 533 191 535 533 200 536 minecraft:blue_concrete
setblock 533 191 537 minecraft:light_blue_concrete
setblock 534 191 528 minecraft:light_blue_concrete
fill 534 191 529 535 200 529 minecraft:blue_concrete
fill 534 191 537 535 195 537 minecraft:blue_concrete
setblock 534 191 538 minecraft:light_blue_concrete
fill 535 191 527 540 191 527 minecraft:light_blue_concrete
fill 535 191 528 540 200 528 minecraft:blue_concrete
fill 535 191 538 540 193 538 minecraft:blue_concrete
fill 535 191 539 540 191 539 minecraft:light_blue_concrete
setblock 537 191 510 minecraft:white_concrete
fill 540 191 529 541 195 529 minecraft:blue_concrete
fill 540 191 537 541 193 537 minecraft:blue_concrete
setblock 541 191 528 minecraft:light_blue_concrete
setblock 541 191 538 minecraft:light_blue_concrete
setblock 542 191 529 minecraft:light_blue_concrete
fill 542 191 530 542 195 531 minecraft:blue_concrete
fill 542 191 535 542 195 536 minecraft:blue_concrete
setblock 542 191 537 minecraft:light_blue_concrete
fill 543 191 530 543 191 531 minecraft:light_blue_concrete
fill 543 191 532 543 200 534 minecraft:blue_concrete
fill 543 191 535 543 191 536 minecraft:light_blue_concrete
fill 544 191 532 544 192 534 minecraft:light_blue_concrete
setblock 546 191 552 minecraft:magma_block
setblock 517 192 539 minecraft:shroomlight
fill 517 192 540 517 212 540 minecraft:blue_concrete
setblock 517 192 551 minecraft:white_concrete
fill 517 192 552 517 240 552 minecraft:blue_concrete
fill 531 192 530 531 193 531 minecraft:light_blue_concrete
fill 531 192 535 531 193 536 minecraft:light_blue_concrete
fill 532 192 529 532 193 529 minecraft:light_blue_concrete
fill 532 192 530 532 193 531 minecraft:blue_concrete
fill 532 192 535 532 199 536 minecraft:blue_concrete
fill 532 192 537 532 193 537 minecraft:light_blue_concrete
setblock 533 192 528 minecraft:light_blue_concrete
fill 533 192 529 533 199 529 minecraft:blue_concrete
fill 533 192 537 533 199 537 minecraft:blue_concrete
setblock 533 192 538 minecraft:light_blue_concrete
fill 534 192 527 535 192 527 minecraft:light_blue_concrete
fill 534 192 528 534 199 528 minecraft:blue_concrete
fill 534 192 538 534 195 538 minecraft:blue_concrete
fill 534 192 539 535 192 539 minecraft:light_blue_concrete
fill 536 192 526 539 196 526 minecraft:light_blue_concrete
fill 536 192 527 539 198 527 minecraft:blue_concrete
fill 536 192 539 539 193 539 minecraft:blue_concrete
fill 536 192 540 539 193 540 minecraft:light_blue_concrete
fill 537 192 510 537 199 510 minecraft:blue_concrete
fill 540 192 527 541 192 527 minecraft:light_blue_concrete
fill 540 192 539 541 192 539 minecraft:light_blue_concrete
fill 541 192 528 541 199 528 minecraft:blue_concrete
fill 541 192 538 541 193 538 minecraft:blue_concrete
setblock 542 192 528 minecraft:light_blue_concrete
fill 542 192 529 542 195 529 minecraft:blue_concrete
fill 542 192 537 542 193 537 minecraft:blue_concrete
setblock 542 192 538 minecraft:light_blue_concrete
fill 543 192 529 543 193 529 minecraft:light_blue_concrete
fill 543 192 530 543 199 531 minecraft:blue_concrete
fill 543 192 535 543 195 536 minecraft:blue_concrete
fill 543 192 537 543 193 537 minecraft:light_blue_concrete
fill 544 192 530 544 193 531 minecraft:light_blue_concrete
fill 544 192 535 544 193 536 minecraft:light_blue_concrete
fill 546 192 552 546 202 552 minecraft:blue_concrete
setblock 552 192 510 minecraft:magma_block
fill 552 192 552 555 204 552 minecraft:blue_concrete
setblock 556 192 552 minecraft:shroomlight
fill 559 192 515 559 218 515 minecraft:blue_concrete
fill 559 192 516 559 192 517 minecraft:white_concrete
fill 559 192 534 559 239 534 minecraft:blue_concrete
setblock 559 192 535 minecraft:white_concrete
fill 517 193 539 517 243 539 minecraft:blue_concrete
fill 517 193 547 517 243 547 minecraft:blue_concrete
setblock 517 193 548 minecraft:white_concrete
fill 517 193 551 517 229 551 minecraft:blue_concrete
fill 530 193 532 530 198 534 minecraft:light_blue_concrete
setblock 530 193 552 minecraft:shroomlight
fill 531 193 532 531 195 534 minecraft:blue_concrete
fill 532 193 528 532 198 528 minecraft:light_blue_concrete
fill 532 193 538 532 198 538 minecraft:light_blue_concrete
fill 533 193 527 534 193 527 minecraft:light_blue_concrete
fill 533 193 528 533 198 528 minecraft:blue_concrete
fill 533 193 538 533 198 538 minecraft:blue_concrete
fill 533 193 539 534 193 539 minecraft:light_blue_concrete
fill 535 193 526 535 198 526 minecraft:light_blue_concrete
fill 535 193 527 535 198 527 minecraft:blue_concrete
setblock 535 193 539 minecraft:blue_concrete
setblock 535 193 540 minecraft:light_blue_concrete
fill 540 193 526 540 196 526 minecraft:light_blue_concrete
fill 540 193 527 540 198 527 minecraft:blue_concrete
setblock 540 193 539 minecraft:blue_concrete
fill 540 193 540 540 195 540 minecraft:light_blue_concrete
fill 541 193 527 542 193 527 minecraft:light_blue_concrete
fill 541 193 539 542 193 539 minecraft:light_blue_concrete
fill 542 193 528 542 198 528 minecraft:blue_concrete
setblock 542 193 538 minecraft:blue_concrete
fill 543 193 528 543 198 528 minecraft:light_blue_concrete
fill 543 193 538 543 195 538 minecraft:light_blue_concrete
fill 544 193 532 544 198 534 minecraft:blue_concrete
fill 545 193 532 545 198 534 minecraft:light_blue_concrete
fill 552 193 510 552 200 510 minecraft:blue_concrete
fill 556 193 552 556 195 552 minecraft:blue_concrete
setblock 557 193 510 minecraft:magma_block
fill 558 193 510 559 205 510 minecraft:blue_concrete
fill 559 193 516 559 195 517 minecraft:blue_concrete
fill 559 193 535 559 243 535 minecraft:blue_concrete
setblock 559 193 537 minecraft:magma_block
fill 559 193 538 559 193 540 minecraft:blue_concrete
fill 517 194 512 517 217 513 minecraft:blue_concrete
setblock 517 194 514 minecraft:white_concrete
fill 517 194 515 517 205 516 minecraft:blue_concrete
setblock 517 194 517 minecraft:magma_block
setblock 517 194 543 minecraft:magma_block
fill 517 194 548 517 219 548 minecraft:blue_concrete
fill 530 194 531 530 197 531 minecraft:light_blue_concrete
fill 530 194 535 530 197 535 minecraft:light_blue_concrete
fill 530 194 552 530 241 552 minecraft:blue_concrete
fill 531 194 529 531 195 530 minecraft:light_blue_concrete
fill 531 194 531 531 195 531 minecraft:blue_concrete
fill 531 194 535 531 196 535 minecraft:blue_concrete
fill 531 194 536 531 197 537 minecraft:light_blue_concrete
fill 532 194 529 532 195 530 minecraft:blue_concrete
fill 532 194 531 534 194 533 minecraft:redstone_block
fill 532 194 534 535 195 534 minecraft:blue_concrete
fill 532 194 537 532 197 537 minecraft:blue_concrete
fill 533 194 527 533 198 527 minecraft:light_blue_concrete
fill 533 194 530 538 195 530 minecraft:blue_concrete
fill 533 194 539 533 198 539 minecraft:light_blue_concrete
fill 534 194 526 534 196 526 minecraft:light_blue_concrete
fill 534 194 527 534 197 527 minecraft:blue_concrete
fill 534 194 539 534 195 539 minecraft:blue_concrete
fill 534 194 540 534 195 540 minecraft:light_blue_concrete
fill 535 194 531 538 195 533 minecraft:blue_concrete
fill 535 194 538 539 195 538 minecraft:blue_concrete
fill 535 194 539 537 194 541 minecraft:redstone_block
fill 536 194 529 539 195 529 minecraft:blue_concrete
fill 536 194 537 536 195 537 minecraft:blue_concrete
fill 538 194 539 539 195 539 minecraft:blue_concrete
fill 538 194 540 539 195 540 minecraft:light_blue_concrete
fill 539 194 530 541 194 532 minecraft:redstone_block
fill 539 194 533 539 195 534 minecraft:blue_concrete
fill 539 194 536 541 195 536 minecraft:blue_concrete
fill 540 194 533 542 195 533 minecraft:blue_concrete
fill 540 194 537 542 194 539 minecraft:redstone_block
fill 541 194 526 541 197 526 minecraft:light_blue_concrete
fill 541 194 527 541 197 527 minecraft:blue_concrete
fill 541 194 534 542 201 534 minecraft:blue_concrete
fill 541 194 540 541 195 540 minecraft:light_blue_concrete
fill 542 194 527 542 198 527 minecraft:light_blue_concrete
fill 542 194 532 542 195 532 minecraft:blue_concrete
fill 543 194 529 543 197 529 minecraft:blue_concrete
fill 543 194 537 543 195 537 minecraft:blue_concrete
fill 544 194 529 544 197 530 minecraft:light_blue_concrete
fill 544 194 531 544 197 531 minecraft:blue_concrete
fill 544 194 535 544 197 535 minecraft:blue_concrete
fill 544 194 536 544 197 537 minecraft:light_blue_concrete
fill 545 194 531 545 197 531 minecraft:light_blue_concrete
fill 545 194 535 545 197 535 minecraft:light_blue_concrete
fill 557 194 510 557 239 510 minecraft:blue_concrete
setblock 557 194 552 minecraft:white_concrete
fill 559 194 537 559 195 538 minecraft:blue_concrete
setblock 559 194 539 minecraft:magma_block
fill 559 194 540 559 239 540 minecraft:blue_concrete
fill 517 195 514 517 221 514 minecraft:blue_concrete
fill 517 195 517 517 233 517 minecraft:blue_concrete
setblock 517 195 536 minecraft:magma_block
fill 517 195 537 517 243 537 minecraft:blue_concrete
fill 517 195 543 517 196 543 minecraft:blue_concrete
fill 523 195 552 523 233 552 minecraft:blue_concrete
setblock 524 195 552 minecraft:shroomlight
fill 525 195 552 525 204 552 minecraft:blue_concrete
setblock 534 195 552 minecraft:magma_block
fill 557 195 552 557 229 552 minecraft:blue_concrete
setblock 559 195 536 minecraft:white_concrete
fill 559 195 539 559 210 539 minecraft:blue_concrete
setblock 559 195 551 minecraft:shroomlight
setblock 517 196 525 minecraft:shroomlight
fill 517 196 526 517 197 529 minecraft:blue_concrete
fill 517 196 536 517 231 536 minecraft:blue_concrete
fill 518 196 511 529 196 551 minecraft:black_concrete
fill 524 196 552 524 224 552 minecraft:blue_concrete
fill 530 196 511 530 196 530 minecraft:black_concrete
fill 530 196 536 530 196 551 minecraft:black_concrete
fill 531 196 511 531 196 528 minecraft:black_concrete
fill 531 196 529 531 197 529 minecraft:light_blue_concrete
fill 531 196 530 531 196 534 minecraft:shroomlight
fill 531 196 538 531 196 551 minecraft:black_concrete
fill 532 196 511 532 196 527 minecraft:black_concrete
fill 532 196 529 532 197 529 minecraft:blue_concrete
fill 532 196 530 535 196 530 minecraft:shroomlight
fill 532 196 531 534 196 533 minecraft:black_concrete
fill 532 196 534 534 196 534 minecraft:shroomlight
fill 532 196 539 532 196 551 minecraft:black_concrete
fill 533 196 511 533 196 526 minecraft:black_concrete
fill 533 196 540 533 196 551 minecraft:black_concrete
fill 534 196 511 558 196 525 minecraft:black_concrete
fill 534 196 535 534 196 537 minecraft:blue_concrete
fill 534 196 538 534 196 542 minecraft:shroomlight
fill 534 196 543 558 196 551 minecraft:black_concrete
fill 534 196 552 534 243 552 minecraft:blue_concrete
fill 535 196 531 535 196 533 minecraft:shroomlight
fill 535 196 534 535 196 536 minecraft:ochre_froglight
fill 535 196 537 535 196 538 minecraft:shroomlight
fill 535 196 539 537 196 541 minecraft:black_concrete
fill 535 196 542 538 196 542 minecraft:shroomlight
fill 536 196 529 537 201 532 minecraft:blue_concrete
fill 536 196 533 538 196 533 minecraft:ochre_froglight
fill 536 196 537 538 196 537 minecraft:ochre_froglight
fill 536 196 538 539 196 538 minecraft:shroomlight
fill 538 196 529 538 196 532 minecraft:shroomlight
fill 538 196 539 538 196 541 minecraft:shroomlight
fill 539 196 529 542 196 529 minecraft:shroomlight
fill 539 196 530 541 196 532 minecraft:black_concrete
fill 539 196 533 542 196 533 minecraft:shroomlight
fill 539 196 534 539 196 536 minecraft:ochre_froglight
setblock 539 196 537 minecraft:shroomlight
fill 539 196 539 539 196 540 minecraft:shroomlight
fill 539 196 541 558 196 542 minecraft:black_concrete
fill 540 196 535 543 196 535 minecraft:blue_concrete
fill 540 196 536 543 196 536 minecraft:shroomlight
fill 540 196 537 542 196 539 minecraft:black_concrete
fill 540 196 540 543 196 540 minecraft:shroomlight
fill 542 196 526 558 196 526 minecraft:black_concrete
fill 542 196 530 542 196 532 minecraft:shroomlight
fill 543 196 527 558 196 527 minecraft:black_concrete
fill 543 196 537 543 196 539 minecraft:shroomlight
fill 544 196 528 558 196 528 minecraft:black_concrete
fill 544 196 538 558 196 540 minecraft:black_concrete
fill 545 196 529 558 196 530 minecraft:black_concrete
fill 545 196 536 558 196 537 minecraft:black_concrete
fill 546 196 531 558 196 535 minecraft:black_concrete
setblock 556 196 552 minecraft:white_concrete
fill 559 196 516 559 240 516 minecraft:blue_concrete
setblock 559 196 517 minecraft:magma_block
setblock 559 196 519 minecraft:white_concrete
setblock 559 196 536 minecraft:magma_block
setblock 559 196 537 minecraft:white_concrete
fill 559 196 538 559 243 538 minecraft:blue_concrete
fill 559 196 551 559 243 551 minecraft:blue_concrete
fill 517 197 525 517 243 525 minecraft:blue_concrete
setblock 517 197 543 minecraft:white_concrete
fill 523 197 510 523 200 510 minecraft:blue_concrete
setblock 524 197 510 minecraft:shroomlight
fill 528 197 526 528 198 526 minecraft:bone_block
fill 528 197 535 528 203 535 minecraft:bone_block
fill 528 197 544 528 198 544 minecraft:bone_block
fill 531 197 526 531 198 526 minecraft:bone_block
fill 531 197 530 531 199 530 minecraft:light_blue_concrete
fill 531 197 531 535 197 534 minecraft:blue_concrete
fill 531 197 535 531 203 535 minecraft:bone_block
fill 531 197 544 531 198 544 minecraft:bone_block
fill 532 197 530 535 199 530 minecraft:blue_concrete
fill 534 197 526 534 198 526 minecraft:bone_block
fill 534 197 535 534 203 535 minecraft:bone_block
fill 534 197 536 535 197 539 minecraft:blue_concrete
fill 534 197 540 541 197 540 minecraft:light_blue_concrete
fill 534 197 544 534 198 544 minecraft:bone_block
fill 535 197 535 535 201 535 minecraft:blue_concrete
fill 536 197 526 536 199 526 minecraft:light_blue_concrete
fill 536 197 533 542 201 533 minecraft:blue_concrete
fill 536 197 537 541 197 539 minecraft:blue_concrete
fill 537 197 526 537 198 526 minecraft:bone_block
fill 537 197 544 537 198 544 minecraft:bone_block
fill 538 197 526 539 199 526 minecraft:light_blue_concrete
fill 538 197 529 542 199 532 minecraft:blue_concrete
fill 539 197 534 539 201 536 minecraft:blue_concrete
fill 540 197 526 540 198 526 minecraft:bone_block
fill 540 197 535 540 203 535 minecraft:bone_block
fill 540 197 536 543 199 536 minecraft:blue_concrete
fill 540 197 544 540 198 544 minecraft:bone_block
fill 541 197 535 542 200 535 minecraft:blue_concrete
fill 542 197 537 542 198 538 minecraft:blue_concrete
fill 542 197 539 542 198 539 minecraft:light_blue_concrete
fill 543 197 526 543 198 526 minecraft:bone_block
fill 543 197 535 543 203 535 minecraft:bone_block
setblock 543 197 537 minecraft:blue_concrete
fill 543 197 538 543 198 538 minecraft:light_blue_concrete
fill 543 197 544 543 198 544 minecraft:bone_block
fill 546 197 526 546 198 526 minecraft:bone_block
fill 546 197 535 546 203 535 minecraft:bone_block
fill 546 197 544 546 198 544 minecraft:bone_block
setblock 548 197 552 minecraft:magma_block
fill 556 197 552 556 204 552 minecraft:blue_concrete
fill 559 197 517 559 243 517 minecraft:blue_concrete
fill 559 197 519 559 214 519 minecraft:blue_concrete
fill 559 197 536 559 198 537 minecraft:blue_concrete
fill 517 198 526 517 241 527 minecraft:blue_concrete
setblock 517 198 528 minecraft:shroomlight
fill 517 198 529 517 243 529 minecraft:blue_concrete
fill 517 198 543 517 243 543 minecraft:blue_concrete
setblock 520 198 513 minecraft:light[level=14]
setblock 520 198 521 minecraft:light[level=14]
setblock 520 198 529 minecraft:light[level=14]
setblock 520 198 537 minecraft:light[level=14]
setblock 520 198 545 minecraft:light[level=14]
fill 524 198 510 524 214 510 minecraft:blue_concrete
setblock 526 198 552 minecraft:white_concrete
setblock 528 198 513 minecraft:light[level=14]
setblock 528 198 521 minecraft:light[level=14]
setblock 528 198 529 minecraft:light[level=14]
setblock 528 198 537 minecraft:light[level=14]
setblock 528 198 545 minecraft:light[level=14]
fill 531 198 531 531 199 531 minecraft:light_blue_concrete
fill 531 198 532 535 198 534 minecraft:blue_concrete
fill 531 198 536 531 199 536 minecraft:light_blue_concrete
fill 532 198 529 532 199 529 minecraft:light_blue_concrete
fill 532 198 531 535 199 531 minecraft:blue_concrete
fill 532 198 537 532 199 537 minecraft:light_blue_concrete
setblock 534 198 527 minecraft:light_blue_concrete
fill 534 198 536 535 199 538 minecraft:blue_concrete
fill 534 198 539 534 199 539 minecraft:light_blue_concrete
fill 535 198 539 540 198 539 minecraft:blue_concrete
fill 535 198 540 540 198 540 minecraft:light_blue_concrete
setblock 536 198 513 minecraft:light[level=14]
setblock 536 198 521 minecraft:light[level=14]
fill 536 198 537 541 199 538 minecraft:blue_concrete
setblock 536 198 545 minecraft:light[level=14]
setblock 541 198 510 minecraft:magma_block
fill 541 198 527 541 199 527 minecraft:light_blue_concrete
fill 541 198 539 541 199 539 minecraft:light_blue_concrete
fill 542 198 510 542 232 510 minecraft:blue_concrete
fill 543 198 529 543 199 529 minecraft:light_blue_concrete
fill 543 198 537 543 199 537 minecraft:light_blue_concrete
setblock 544 198 513 minecraft:light[level=14]
setblock 544 198 521 minecraft:light[level=14]
setblock 544 198 529 minecraft:light[level=14]
fill 544 198 530 544 199 531 minecraft:light_blue_concrete
fill 544 198 535 544 199 536 minecraft:light_blue_concrete
setblock 544 198 537 minecraft:light[level=14]
setblock 544 198 545 minecraft:light[level=14]
fill 548 198 552 548 241 552 minecraft:blue_concrete
setblock 552 198 513 minecraft:light[level=14]
setblock 552 198 521 minecraft:light[level=14]
setblock 552 198 529 minecraft:light[level=14]
setblock 552 198 537 minecraft:light[level=14]
setblock 552 198 545 minecraft:light[level=14]
fill 559 198 542 559 209 542 minecraft:blue_concrete
setblock 559 198 543 minecraft:magma_block
fill 559 198 544 559 198 546 minecraft:blue_concrete
setblock 517 199 528 minecraft:blue_concrete
setblock 522 199 510 minecraft:shroomlight
fill 525 199 510 525 243 510 minecraft:blue_concrete
setblock 526 199 510 minecraft:shroomlight
fill 526 199 552 526 229 552 minecraft:blue_concrete
fill 527 199 510 528 207 510 minecraft:blue_concrete
fill 528 199 527 528 200 527 minecraft:bone_block
fill 528 199 543 528 200 543 minecraft:bone_block
fill 531 199 527 531 200 527 minecraft:bone_block
fill 531 199 532 531 200 534 minecraft:light_blue_concrete
fill 531 199 543 531 200 543 minecraft:bone_block
fill 532 199 532 535 200 534 minecraft:blue_concrete
setblock 533 199 528 minecraft:light_blue_concrete
setblock 533 199 538 minecraft:light_blue_concrete
fill 534 199 527 534 200 527 minecraft:bone_block
fill 534 199 543 534 200 543 minecraft:bone_block
fill 535 199 527 535 200 527 minecraft:light_blue_concrete
fill 535 199 539 535 200 539 minecraft:light_blue_concrete
setblock 536 199 527 minecraft:blue_concrete
fill 536 199 534 536 202 534 minecraft:blue_concrete
fill 536 199 536 536 201 536 minecraft:blue_concrete
fill 536 199 539 539 199 539 minecraft:blue_concrete
fill 536 199 540 539 199 540 minecraft:light_blue_concrete
setblock 537 199 526 minecraft:light_blue_concrete
fill 537 199 527 537 200 527 minecraft:bone_block
fill 537 199 543 537 200 543 minecraft:bone_block
fill 538 199 527 539 199 527 minecraft:blue_concrete
fill 538 199 534 538 201 534 minecraft:blue_concrete
fill 538 199 536 538 201 536 minecraft:blue_concrete
fill 540 199 527 540 200 527 minecraft:bone_block
fill 540 199 539 540 200 539 minecraft:light_blue_concrete
fill 540 199 543 540 200 543 minecraft:bone_block
fill 541 199 510 541 218 510 minecraft:blue_concrete
setblock 542 199 528 minecraft:light_blue_concrete
setblock 542 199 537 minecraft:blue_concrete
setblock 542 199 538 minecraft:light_blue_concrete
fill 543 199 527 543 200 527 minecraft:bone_block
fill 543 199 543 543 200 543 minecraft:bone_block
fill 544 199 532 544 200 534 minecraft:light_blue_concrete
fill 546 199 527 546 200 527 minecraft:bone_block
fill 546 199 543 546 200 543 minecraft:bone_block
setblock 554 199 510 minecraft:shroomlight
fill 555 199 510 555 204 510 minecraft:blue_concrete
fill 559 199 529 559 216 529 minecraft:blue_concrete
setblock 559 199 530 minecraft:white_concrete
setblock 559 199 536 minecraft:white_concrete
fill 559 199 537 559 215 537 minecraft:blue_concrete
setblock 559 199 543 minecraft:white_concrete
fill 559 199 544 559 215 545 minecraft:blue_concrete
setblock 559 199 546 minecraft:white_concrete
setblock 517 200 518 minecraft:orange_concrete
fill 517 200 521 517 210 521 minecraft:blue_concrete
setblock 517 200 522 minecraft:magma_block
setblock 517 200 523 minecraft:shroomlight
fill 517 200 524 517 209 524 minecraft:blue_concrete
setblock 517 200 528 minecraft:white_concrete
setblock 517 200 534 minecraft:orange_concrete
setblock 517 200 550 minecraft:orange_concrete
setblock 521 200 510 minecraft:orange_concrete
fill 522 200 510 522 240 510 minecraft:blue_concrete
fill 526 200 510 526 209 510 minecraft:blue_concrete
setblock 529 200 510 minecraft:magma_block
setblock 531 200 552 minecraft:orange_concrete
fill 532 200 530 532 200 531 minecraft:light_blue_concrete
fill 532 200 535 532 200 536 minecraft:light_blue_concrete
setblock 533 200 529 minecraft:light_blue_concrete
fill 533 200 530 535 200 531 minecraft:blue_concrete
setblock 533 200 537 minecraft:light_blue_concrete
setblock 534 200 528 minecraft:light_blue_concrete
fill 534 200 536 535 200 537 minecraft:blue_concrete
setblock 534 200 538 minecraft:light_blue_concrete
fill 535 200 538 540 200 538 minecraft:blue_concrete
setblock 536 200 527 minecraft:light_blue_concrete
fill 536 200 537 541 200 537 minecraft:blue_concrete
fill 536 200 539 539 200 539 minecraft:light_blue_concrete
setblock 537 200 510 minecraft:orange_concrete
setblock 538 200 510 minecraft:magma_block
fill 538 200 527 539 200 527 minecraft:light_blue_concrete
fill 538 200 529 541 200 532 minecraft:blue_concrete
fill 539 200 510 540 202 510 minecraft:blue_concrete
fill 540 200 536 542 200 536 minecraft:blue_concrete
setblock 541 200 528 minecraft:light_blue_concrete
setblock 541 200 538 minecraft:light_blue_concrete
setblock 542 200 529 minecraft:light_blue_concrete
fill 542 200 530 542 200 532 minecraft:blue_concrete
setblock 542 200 537 minecraft:light_blue_concrete
fill 543 200 530 543 200 531 minecraft:light_blue_concrete
setblock 543 200 536 minecraft:light_blue_concrete
setblock 547 200 527 minecraft:red_terracotta
setblock 547 200 552 minecraft:orange_concrete
setblock 548 200 510 minecraft:magma_block
fill 549 200 510 550 206 510 minecraft:blue_concrete
setblock 551 200 552 minecraft:shroomlight
setblock 553 200 510 minecraft:orange_concrete
fill 554 200 510 554 243 510 minecraft:blue_concrete
setblock 559 200 520 minecraft:orange_concrete
fill 559 200 530 559 243 530 minecraft:blue_concrete
setblock 559 200 536 minecraft:orange_concrete
fill 559 200 543 559 243 543 minecraft:blue_concrete
fill 559 200 546 559 203 546 minecraft:blue_concrete
fill 517 201 518 517 206 518 minecraft:blue_concrete
fill 517 201 522 517 220 523 minecraft:blue_concrete
fill 517 201 528 517 206 528 minecraft:blue_concrete
fill 517 201 534 517 206 534 minecraft:blue_concrete
fill 517 201 550 517 206 550 minecraft:blue_concrete
fill 521 201 510 521 204 510 minecraft:blue_concrete
setblock 523 201 510 minecraft:magma_block
fill 528 201 528 528 202 528 minecraft:bone_block
fill 528 201 542 528 202 542 minecraft:bone_block
setblock 529 201 510 minecraft:blue_concrete
fill 531 201 528 531 202 528 minecraft:bone_block
fill 531 201 542 531 202 542 minecraft:bone_block
fill 531 201 552 531 206 552 minecraft:blue_concrete
fill 532 201 532 532 201 534 minecraft:light_blue_concrete
fill 533 201 530 533 201 531 minecraft:light_blue_concrete
fill 533 201 532 535 201 534 minecraft:blue_concrete
fill 533 201 535 533 201 536 minecraft:light_blue_concrete
fill 534 201 528 534 202 528 minecraft:bone_block
fill 534 201 529 535 201 529 minecraft:light_blue_concrete
fill 534 201 530 535 201 531 minecraft:blue_concrete
fill 534 201 536 535 201 536 minecraft:blue_concrete
fill 534 201 537 535 201 537 minecraft:light_blue_concrete
fill 534 201 542 534 202 542 minecraft:bone_block
fill 535 201 528 536 201 528 minecraft:light_blue_concrete
fill 535 201 538 540 201 538 minecraft:light_blue_concrete
fill 536 201 537 539 201 537 minecraft:blue_concrete
fill 537 201 510 538 205 510 minecraft:blue_concrete
fill 537 201 528 537 202 528 minecraft:bone_block
fill 537 201 542 537 202 542 minecraft:bone_block
fill 538 201 528 539 201 528 minecraft:light_blue_concrete
fill 538 201 529 539 201 532 minecraft:blue_concrete
fill 540 201 528 540 202 528 minecraft:bone_block
fill 540 201 529 541 201 529 minecraft:light_blue_concrete
fill 540 201 530 541 201 532 minecraft:blue_concrete
fill 540 201 536 541 201 536 minecraft:blue_concrete
fill 540 201 537 541 201 537 minecraft:light_blue_concrete
fill 540 201 542 540 202 542 minecraft:bone_block
setblock 541 201 535 minecraft:blue_concrete
fill 542 201 530 542 201 531 minecraft:light_blue_concrete
setblock 542 201 532 minecraft:blue_concrete
fill 542 201 535 542 201 536 minecraft:light_blue_concrete
fill 543 201 528 543 202 528 minecraft:bone_block
fill 543 201 532 543 201 534 minecraft:light_blue_concrete
fill 543 201 542 543 202 542 minecraft:bone_block
fill 546 201 528 546 202 528 minecraft:bone_block
fill 546 201 542 546 202 542 minecraft:bone_block
fill 547 201 552 547 206 552 minecraft:blue_concrete
fill 548 201 510 548 239 510 minecraft:blue_concrete
fill 548 201 535 550 208 536 minecraft:bone_block
fill 550 201 534 552 208 534 minecraft:bone_block
fill 551 201 533 552 208 533 minecraft:bone_block
fill 551 201 535 552 208 535 minecraft:bone_block
fill 551 201 552 551 213 552 minecraft:blue_concrete
setblock 552 201 510 minecraft:white_concrete
fill 553 201 510 553 206 510 minecraft:blue_concrete
fill 559 201 520 559 206 520 minecraft:blue_concrete
fill 559 201 536 559 206 536 minecraft:blue_concrete
fill 523 202 510 523 229 510 minecraft:blue_concrete
fill 528 202 529 528 204 529 minecraft:bone_block
fill 528 202 541 528 204 541 minecraft:bone_block
setblock 529 202 510 minecraft:white_concrete
fill 531 202 529 531 204 529 minecraft:bone_block
fill 531 202 541 531 204 541 minecraft:bone_block
fill 533 202 532 534 202 534 minecraft:light_blue_concrete
fill 534 202 529 534 204 529 minecraft:bone_block
fill 534 202 530 535 202 531 minecraft:light_blue_concrete
fill 534 202 536 536 202 536 minecraft:light_blue_concrete
fill 534 202 541 534 204 541 minecraft:bone_block
fill 535 202 532 535 202 534 minecraft:blue_concrete
setblock 535 202 535 minecraft:light_blue_concrete
fill 536 202 529 536 202 530 minecraft:light_blue_concrete
fill 536 202 531 539 202 533 minecraft:blue_concrete
fill 536 202 537 539 202 537 minecraft:light_blue_concrete
fill 537 202 529 537 204 529 minecraft:bone_block
fill 537 202 530 541 202 530 minecraft:light_blue_concrete
fill 537 202 541 537 204 541 minecraft:bone_block
fill 538 202 529 539 202 529 minecraft:light_blue_concrete
fill 538 202 536 541 202 536 minecraft:light_blue_concrete
fill 539 202 534 539 202 535 minecraft:blue_concrete
fill 540 202 529 540 204 529 minecraft:bone_block
fill 540 202 531 541 202 531 minecraft:light_blue_concrete
fill 540 202 532 540 202 533 minecraft:blue_concrete
fill 540 202 541 540 204 541 minecraft:bone_block
fill 541 202 532 541 202 535 minecraft:light_blue_concrete
fill 542 202 532 542 202 534 minecraft:light_blue_concrete
fill 543 202 529 543 204 529 minecraft:bone_block
fill 543 202 541 543 204 541 minecraft:bone_block
fill 546 202 529 546 204 529 minecraft:bone_block
fill 546 202 541 546 204 541 minecraft:bone_block
fill 547 202 535 547 207 535 minecraft:bone_block
fill 548 202 534 549 207 534 minecraft:bone_block
fill 548 202 537 552 206 537 minecraft:bone_block
fill 550 202 533 550 207 533 minecraft:bone_block
fill 551 202 536 553 206 536 minecraft:bone_block
fill 552 202 510 552 210 510 minecraft:blue_concrete
fill 553 202 534 553 206 535 minecraft:bone_block
fill 528 203 534 528 206 534 minecraft:bone_block
fill 528 203 536 528 206 536 minecraft:bone_block
fill 529 203 510 529 243 510 minecraft:blue_concrete
fill 531 203 534 531 206 534 minecraft:bone_block
fill 531 203 536 531 206 536 minecraft:bone_block
fill 534 203 534 534 206 534 minecraft:bone_block
fill 534 203 536 534 206 536 minecraft:bone_block
fill 535 203 532 536 203 534 minecraft:light_blue_concrete
fill 536 203 531 539 203 531 minecraft:light_blue_concrete
fill 537 203 532 540 203 533 minecraft:light_blue_concrete
fill 539 203 510 539 243 510 minecraft:blue_concrete
fill 539 203 534 539 203 535 minecraft:light_blue_concrete
setblock 540 203 510 minecraft:magma_block
fill 540 203 534 540 206 534 minecraft:bone_block
fill 540 203 536 540 206 536 minecraft:bone_block
fill 543 203 534 543 206 534 minecraft:bone_block
fill 543 203 536 543 206 536 minecraft:bone_block
fill 546 203 534 547 206 534 minecraft:bone_block
fill 546 203 536 547 206 536 minecraft:bone_block
setblock 546 203 552 minecraft:white_concrete
fill 547 203 533 549 206 533 minecraft:bone_block
fill 548 203 532 551 206 532 minecraft:bone_block
fill 549 203 538 552 206 538 minecraft:bone_block
fill 553 203 537 553 205 537 minecraft:bone_block
fill 528 204 530 528 205 530 minecraft:bone_block
fill 528 204 540 528 205 540 minecraft:bone_block
fill 531 204 530 531 205 530 minecraft:bone_block
fill 531 204 540 531 205 540 minecraft:bone_block
fill 534 204 530 534 205 530 minecraft:bone_block
fill 534 204 540 534 205 540 minecraft:bone_block
fill 537 204 530 537 205 530 minecraft:bone_block
fill 537 204 540 537 205 540 minecraft:bone_block
fill 540 204 510 540 243 510 minecraft:blue_concrete
fill 540 204 530 540 205 530 minecraft:bone_block
fill 540 204 540 540 205 540 minecraft:bone_block
fill 543 204 530 543 205 530 minecraft:bone_block
fill 543 204 540 543 205 540 minecraft:bone_block
fill 546 204 530 546 205 530 minecraft:bone_block
fill 546 204 540 546 205 540 minecraft:bone_block
fill 546 204 552 546 243 552 minecraft:blue_concrete
fill 547 204 532 547 206 532 minecraft:bone_block
fill 548 204 531 550 205 531 minecraft:bone_block
fill 548 204 538 548 206 538 minecraft:bone_block
setblock 549 204 552 minecraft:white_concrete
fill 550 204 539 552 205 539 minecraft:bone_block
fill 550 204 552 550 228 552 minecraft:blue_concrete
fill 553 204 538 553 205 538 minecraft:bone_block
setblock 559 204 546 minecraft:white_concrete
setblock 559 204 547 minecraft:shroomlight
setblock 521 205 510 minecraft:shroomlight
setblock 525 205 552 minecraft:white_concrete
fill 528 205 531 528 206 531 minecraft:bone_block
fill 528 205 539 528 206 539 minecraft:bone_block
fill 531 205 531 531 206 531 minecraft:bone_block
fill 531 205 539 531 206 539 minecraft:bone_block
fill 534 205 531 534 206 531 minecraft:bone_block
fill 534 205 539 534 206 539 minecraft:bone_block
fill 535 205 514 537 206 514 minecraft:blackstone
fill 536 205 513 536 206 513 minecraft:blackstone
fill 536 205 515 536 206 515 minecraft:blackstone
fill 537 205 531 537 206 531 minecraft:bone_block
fill 537 205 539 537 206 539 minecraft:bone_block
fill 540 205 531 540 206 531 minecraft:bone_block
fill 540 205 539 540 206 539 minecraft:bone_block
fill 543 205 531 543 206 531 minecraft:bone_block
fill 543 205 539 543 206 539 minecraft:bone_block
fill 546 205 531 546 206 531 minecraft:bone_block
fill 546 205 539 546 206 539 minecraft:bone_block
fill 549 205 552 549 219 552 minecraft:blue_concrete
fill 552 205 552 554 210 552 minecraft:blue_concrete
setblock 555 205 510 minecraft:white_concrete
setblock 555 205 552 minecraft:magma_block
setblock 556 205 552 minecraft:white_concrete
fill 559 205 512 559 239 512 minecraft:blue_concrete
setblock 559 205 513 minecraft:white_concrete
fill 559 205 514 559 234 514 minecraft:blue_concrete
fill 559 205 546 559 208 547 minecraft:blue_concrete
setblock 559 205 549 minecraft:white_concrete
fill 559 205 550 559 239 550 minecraft:blue_concrete
fill 517 206 515 517 243 515 minecraft:blue_concrete
setblock 517 206 516 minecraft:white_concrete
setblock 517 206 549 minecraft:magma_block
setblock 520 206 513 minecraft:light[level=14]
setblock 520 206 521 minecraft:light[level=14]
setblock 520 206 529 minecraft:light[level=14]
setblock 520 206 537 minecraft:light[level=14]
setblock 520 206 545 minecraft:light[level=14]
setblock 521 206 510 minecraft:blue_concrete
fill 525 206 552 525 240 552 minecraft:blue_concrete
fill 526 206 535 535 207 535 minecraft:bone_block
setblock 528 206 513 minecraft:light[level=14]
setblock 528 206 521 minecraft:light[level=14]
setblock 528 206 529 minecraft:light[level=14]
fill 528 206 532 528 206 533 minecraft:bone_block
fill 528 206 537 528 206 538 minecraft:bone_block
setblock 528 206 545 minecraft:light[level=14]
fill 531 206 532 531 206 533 minecraft:bone_block
fill 531 206 537 531 206 538 minecraft:bone_block
fill 534 206 532 534 206 533 minecraft:bone_block
fill 534 206 537 534 206 538 minecraft:bone_block
setblock 536 206 521 minecraft:light[level=14]
setblock 536 206 529 minecraft:light[level=14]
setblock 536 206 537 minecraft:light[level=14]
setblock 536 206 545 minecraft:light[level=14]
setblock 537 206 510 minecraft:white_concrete
fill 537 206 532 537 206 533 minecraft:bone_block
fill 537 206 537 537 206 538 minecraft:bone_block
fill 538 206 510 538 218 510 minecraft:blue_concrete
fill 539 206 535 546 207 535 minecraft:bone_block
fill 540 206 532 540 206 533 minecraft:bone_block
fill 540 206 537 540 206 538 minecraft:bone_block
fill 543 206 532 543 206 533 minecraft:bone_block
fill 543 206 537 543 206 538 minecraft:bone_block
setblock 544 206 513 minecraft:light[level=14]
setblock 544 206 521 minecraft:light[level=14]
setblock 544 206 529 minecraft:light[level=14]
setblock 544 206 537 minecraft:light[level=14]
setblock 544 206 545 minecraft:light[level=14]
fill 546 206 532 546 206 533 minecraft:bone_block
fill 546 206 537 546 206 538 minecraft:bone_block
fill 547 206 537 547 207 537 minecraft:bone_block
fill 549 206 531 550 206 531 minecraft:bone_block
fill 550 206 526 552 207 526 minecraft:blackstone
fill 551 206 525 551 207 525 minecraft:blackstone
fill 551 206 527 551 207 527 minecraft:blackstone
setblock 552 206 513 minecraft:light[level=14]
setblock 552 206 521 minecraft:light[level=14]
setblock 552 206 529 minecraft:light[level=14]
setblock 552 206 545 minecraft:light[level=14]
fill 555 206 510 555 239 510 minecraft:blue_concrete
fill 555 206 552 556 225 552 minecraft:blue_concrete
setblock 558 206 510 minecraft:magma_block
fill 559 206 510 559 243 510 minecraft:blue_concrete
fill 559 206 513 559 219 513 minecraft:blue_concrete
fill 559 206 549 559 213 549 minecraft:blue_concrete
fill 517 207 516 517 238 516 minecraft:blue_concrete
fill 517 207 518 517 209 518 minecraft:orange_concrete
setblock 517 207 528 minecraft:shroomlight
fill 517 207 531 517 226 532 minecraft:blue_concrete
setblock 517 207 533 minecraft:magma_block
fill 517 207 534 517 209 534 minecraft:orange_concrete
fill 517 207 544 517 243 544 minecraft:blue_concrete
setblock 517 207 545 minecraft:magma_block
fill 517 207 549 517 224 549 minecraft:blue_concrete
fill 517 207 550 517 209 550 minecraft:orange_concrete
fill 521 207 510 521 209 510 minecraft:orange_concrete
fill 531 207 552 531 209 552 minecraft:orange_concrete
setblock 536 207 535 minecraft:bone_block
fill 537 207 510 537 209 510 minecraft:orange_concrete
fill 543 207 518 543 208 518 minecraft:blackstone
setblock 547 207 534 minecraft:bone_block
setblock 547 207 536 minecraft:bone_block
fill 547 207 552 547 209 552 minecraft:orange_concrete
fill 548 207 533 549 207 533 minecraft:bone_block
fill 548 207 537 550 207 537 minecraft:bone_block
fill 549 207 510 549 243 510 minecraft:blue_concrete
fill 549 207 532 551 207 532 minecraft:bone_block
setblock 549 207 538 minecraft:bone_block
setblock 550 207 510 minecraft:white_concrete
fill 551 207 536 552 207 536 minecraft:bone_block
fill 553 207 510 553 209 510 minecraft:orange_concrete
setblock 553 207 534 minecraft:bone_block
fill 558 207 510 558 242 510 minecraft:blue_concrete
fill 559 207 520 559 209 520 minecraft:orange_concrete
fill 559 207 536 559 209 536 minecraft:orange_concrete
fill 517 208 528 517 226 528 minecraft:blue_concrete
fill 517 208 533 517 213 533 minecraft:blue_concrete
fill 517 208 545 517 212 545 minecraft:blue_concrete
setblock 522 208 552 minecraft:white_concrete
setblock 527 208 510 minecraft:magma_block
fill 528 208 510 528 244 510 minecraft:blue_concrete
setblock 536 208 510 minecraft:white_concrete
fill 548 208 537 549 208 537 minecraft:bone_block
fill 550 208 510 550 232 510 minecraft:blue_concrete
fill 559 208 526 559 243 527 minecraft:blue_concrete
setblock 559 208 528 minecraft:white_concrete
setblock 517 209 520 minecraft:white_concrete
fill 522 209 552 522 220 552 minecraft:blue_concrete
fill 527 209 510 527 225 510 minecraft:blue_concrete
setblock 530 209 510 minecraft:shroomlight
fill 531 209 510 532 212 510 minecraft:blue_concrete
fill 536 209 510 536 243 510 minecraft:blue_concrete
fill 559 209 528 559 216 528 minecraft:blue_concrete
fill 559 209 546 559 241 546 minecraft:blue_concrete
setblock 559 209 547 minecraft:shroomlight
fill 517 210 518 517 215 518 minecraft:blue_concrete
fill 517 210 520 517 219 520 minecraft:blue_concrete
setblock 517 210 524 minecraft:magma_block
fill 517 210 534 517 212 534 minecraft:blue_concrete
fill 517 210 550 517 215 550 minecraft:blue_concrete
fill 521 210 510 521 215 510 minecraft:blue_concrete
setblock 526 210 510 minecraft:shroomlight
fill 530 210 510 530 243 510 minecraft:blue_concrete
fill 530 210 528 530 211 529 minecraft:blue_concrete
fill 531 210 552 531 215 552 minecraft:blue_concrete
fill 537 210 510 537 215 510 minecraft:blue_concrete
fill 547 210 552 547 215 552 minecraft:blue_concrete
setblock 553 210 510 minecraft:blue_concrete
fill 559 210 520 559 215 520 minecraft:blue_concrete
fill 559 210 536 559 215 536 minecraft:blue_concrete
setblock 559 210 542 minecraft:shroomlight
fill 559 210 547 559 237 547 minecraft:blue_concrete
setblock 517 211 521 minecraft:shroomlight
fill 517 211 524 517 216 524 minecraft:blue_concrete
setblock 521 211 552 minecraft:magma_block
fill 526 211 510 526 215 510 minecraft:blue_concrete
setblock 552 211 510 minecraft:shroomlight
fill 552 211 552 552 214 552 minecraft:blue_concrete
setblock 553 211 510 minecraft:white_concrete
setblock 553 211 552 minecraft:white_concrete
setblock 554 211 552 minecraft:blue_concrete
fill 559 211 518 559 212 518 minecraft:magma_block
setblock 559 211 539 minecraft:white_concrete
fill 559 211 542 559 243 542 minecraft:blue_concrete
fill 517 212 521 517 232 521 minecraft:blue_concrete
fill 521 212 552 521 243 552 minecraft:blue_concrete
setblock 535 212 510 minecraft:shroomlight
fill 552 212 510 553 215 510 minecraft:blue_concrete
fill 553 212 552 553 240 552 minecraft:blue_concrete
setblock 554 212 552 minecraft:shroomlight
fill 559 212 539 559 214 539 minecraft:blue_concrete
setblock 517 213 534 minecraft:magma_block
setblock 517 213 540 minecraft:white_concrete
setblock 517 213 545 minecraft:shroomlight
setblock 531 213 510 minecraft:white_concrete
setblock 532 213 510 minecraft:blue_concrete
fill 535 213 510 535 240 510 minecraft:blue_concrete
fill 554 213 552 554 215 552 minecraft:blue_concrete
fill 559 213 518 559 220 518 minecraft:blue_concrete
setblock 517 214 533 minecraft:shroomlight
fill 517 214 534 517 215 534 minecraft:blue_concrete
fill 517 214 540 517 217 540 minecraft:blue_concrete
fill 517 214 545 517 226 545 minecraft:blue_concrete
setblock 520 214 513 minecraft:light[level=14]
setblock 520 214 521 minecraft:light[level=14]
setblock 520 214 529 minecraft:light[level=14]
setblock 520 214 537 minecraft:light[level=14]
setblock 520 214 545 minecraft:light[level=14]
setblock 528 214 513 minecraft:light[level=14]
setblock 528 214 521 minecraft:light[level=14]
setblock 528 214 529 minecraft:light[level=14]
setblock 528 214 537 minecraft:light[level=14]
setblock 528 214 545 minecraft:light[level=14]
fill 531 214 510 531 243 510 minecraft:blue_concrete
setblock 532 214 510 minecraft:shroomlight
setblock 536 214 513 minecraft:light[level=14]
setblock 536 214 521 minecraft:light[level=14]
setblock 536 214 529 minecraft:light[level=14]
setblock 536 214 537 minecraft:light[level=14]
setblock 536 214 545 minecraft:light[level=14]
setblock 544 214 513 minecraft:light[level=14]
setblock 544 214 521 minecraft:light[level=14]
setblock 544 214 529 minecraft:light[level=14]
setblock 544 214 537 minecraft:light[level=14]
setblock 544 214 545 minecraft:light[level=14]
setblock 551 214 552 minecraft:white_concrete
setblock 552 214 513 minecraft:light[level=14]
setblock 552 214 521 minecraft:light[level=14]
setblock 552 214 529 minecraft:light[level=14]
setblock 552 214 537 minecraft:light[level=14]
setblock 552 214 545 minecraft:light[level=14]
setblock 559 214 549 minecraft:shroomlight
fill 517 215 533 517 243 533 minecraft:blue_concrete
setblock 524 215 510 minecraft:shroomlight
fill 532 215 510 532 243 510 minecraft:blue_concrete
fill 551 215 552 551 243 552 minecraft:blue_concrete
setblock 552 215 552 minecraft:magma_block
setblock 559 215 519 minecraft:white_concrete
setblock 559 215 539 minecraft:shroomlight
fill 559 215 549 559 243 549 minecraft:blue_concrete
fill 517 216 518 517 218 518 minecraft:orange_concrete
fill 517 216 534 517 218 534 minecraft:orange_concrete
fill 517 216 550 517 218 550 minecraft:orange_concrete
fill 521 216 510 521 218 510 minecraft:orange_concrete
fill 524 216 510 524 240 510 minecraft:blue_concrete
setblock 526 216 510 minecraft:magma_block
fill 531 216 552 531 218 552 minecraft:orange_concrete
fill 537 216 510 537 218 510 minecraft:orange_concrete
fill 543 216 510 543 243 510 minecraft:blue_concrete
setblock 544 216 510 minecraft:magma_block
fill 545 216 510 546 216 510 minecraft:blue_concrete
fill 547 216 552 547 218 552 minecraft:orange_concrete
fill 552 216 510 552 243 510 minecraft:blue_concrete
fill 552 216 552 552 239 552 minecraft:blue_concrete
fill 553 216 510 553 218 510 minecraft:orange_concrete
setblock 554 216 552 minecraft:magma_block
fill 559 216 519 559 221 519 minecraft:blue_concrete
fill 559 216 520 559 218 520 minecraft:orange_concrete
fill 559 216 536 559 218 536 minecraft:orange_concrete
setblock 559 216 537 minecraft:magma_block
fill 559 216 539 559 232 539 minecraft:blue_concrete
fill 559 216 544 559 243 544 minecraft:blue_concrete
setblock 559 216 545 minecraft:magma_block
setblock 517 217 524 minecraft:magma_block
setblock 517 217 542 minecraft:shroomlight
fill 526 217 510 526 226 510 minecraft:blue_concrete
fill 544 217 510 544 243 510 minecraft:blue_concrete
setblock 545 217 510 minecraft:white_concrete
fill 546 217 510 546 218 510 minecraft:blue_concrete
fill 554 217 552 554 243 552 minecraft:blue_concrete
setblock 559 217 528 minecraft:white_concrete
setblock 559 217 529 minecraft:magma_block
setblock 559 217 531 minecraft:magma_block
fill 559 217 532 559 243 532 minecraft:blue_concrete
fill 559 217 537 559 227 537 minecraft:blue_concrete
fill 559 217 545 559 229 545 minecraft:blue_concrete
fill 517 218 512 517 221 512 minecraft:blue_concrete
setblock 517 218 513 minecraft:shroomlight
fill 517 218 524 517 219 524 minecraft:blue_concrete
setblock 517 218 540 minecraft:shroomlight
setblock 517 218 542 minecraft:blue_concrete
setblock 527 218 552 minecraft:shroomlight
fill 528 218 552 528 243 552 minecraft:blue_concrete
fill 545 218 510 545 240 510 minecraft:blue_concrete
fill 559 218 528 559 243 529 minecraft:blue_concrete
fill 559 218 531 559 243 531 minecraft:blue_concrete
fill 517 219 513 517 243 513 minecraft:blue_concrete
fill 517 219 518 517 224 518 minecraft:blue_concrete
setblock 517 219 519 minecraft:magma_block
fill 517 219 534 517 224 534 minecraft:blue_concrete
fill 517 219 540 517 237 540 minecraft:blue_concrete
setblock 517 219 542 minecraft:white_concrete
fill 517 219 550 517 224 550 minecraft:blue_concrete
fill 521 219 510 521 224 510 minecraft:blue_concrete
fill 527 219 552 527 243 552 minecraft:blue_concrete
fill 531 219 552 531 224 552 minecraft:blue_concrete
fill 537 219 510 537 224 510 minecraft:blue_concrete
setblock 538 219 510 minecraft:white_concrete
setblock 541 219 510 minecraft:shroomlight
setblock 546 219 510 minecraft:magma_block
fill 547 219 552 547 224 552 minecraft:blue_concrete
fill 553 219 510 553 224 510 minecraft:blue_concrete
setblock 559 219 515 minecraft:shroomlight
fill 559 219 520 559 224 520 minecraft:blue_concrete
fill 559 219 536 559 224 536 minecraft:blue_concrete
fill 517 220 519 517 236 519 minecraft:blue_concrete
setblock 517 220 520 minecraft:magma_block
setblock 517 220 524 minecraft:white_concrete
fill 517 220 542 517 243 542 minecraft:blue_concrete
setblock 517 220 548 minecraft:shroomlight
fill 538 220 510 538 243 510 minecraft:blue_concrete
setblock 538 220 552 minecraft:white_concrete
fill 541 220 510 541 235 510 minecraft:blue_concrete
fill 546 220 510 546 243 510 minecraft:blue_concrete
setblock 549 220 552 minecraft:white_concrete
setblock 559 220 513 minecraft:white_concrete
fill 559 220 515 559 239 515 minecraft:blue_concrete
fill 559 220 522 559 243 522 minecraft:blue_concrete
setblock 559 220 523 minecraft:magma_block
fill 559 220 524 559 240 525 minecraft:blue_concrete
setblock 559 220 548 minecraft:white_concrete
fill 517 221 520 517 239 520 minecraft:blue_concrete
fill 517 221 522 517 223 522 minecraft:blue_concrete
setblock 517 221 523 minecraft:shroomlight
fill 517 221 524 517 225 524 minecraft:blue_concrete
setblock 517 221 530 minecraft:white_concrete
fill 517 221 548 517 238 548 minecraft:blue_concrete
setblock 522 221 552 minecraft:shroomlight
fill 528 221 528 528 222 528 minecraft:blue_concrete
setblock 533 221 510 minecraft:magma_block
fill 538 221 552 538 243 552 minecraft:blue_concrete
fill 540 221 520 542 222 520 minecraft:blackstone
fill 541 221 519 541 222 519 minecraft:blackstone
fill 541 221 521 541 222 521 minecraft:blackstone
fill 549 221 552 549 240 552 minecraft:blue_concrete
fill 559 221 513 559 244 513 minecraft:blue_concrete
setblock 559 221 518 minecraft:shroomlight
fill 559 221 523 559 243 523 minecraft:blue_concrete
fill 559 221 548 559 243 548 minecraft:blue_concrete
setblock 517 222 512 minecraft:shroomlight
setblock 517 222 514 minecraft:white_concrete
fill 517 222 523 517 240 523 minecraft:blue_concrete
fill 517 222 530 517 237 530 minecraft:blue_concrete
setblock 520 222 513 minecraft:light[level=14]
setblock 520 222 521 minecraft:light[level=14]
setblock 520 222 529 minecraft:light[level=14]
setblock 520 222 537 minecraft:light[level=14]
setblock 520 222 545 minecraft:light[level=14]
fill 522 222 552 522 233 552 minecraft:blue_concrete
setblock 528 222 513 minecraft:light[level=14]
setblock 528 222 521 minecraft:light[level=14]
setblock 528 222 529 minecraft:light[level=14]
setblock 528 222 537 minecraft:light[level=14]
setblock 528 222 545 minecraft:light[level=14]
fill 533 222 510 533 242 510 minecraft:blue_concrete
setblock 536 222 513 minecraft:light[level=14]
setblock 536 222 521 minecraft:light[level=14]
setblock 536 222 529 minecraft:light[level=14]
setblock 536 222 537 minecraft:light[level=14]
setblock 536 222 545 minecraft:light[level=14]
setblock 544 222 513 minecraft:light[level=14]
setblock 544 222 521 minecraft:light[level=14]
setblock 544 222 529 minecraft:light[level=14]
setblock 544 222 537 minecraft:light[level=14]
setblock 544 222 545 minecraft:light[level=14]
setblock 552 222 513 minecraft:light[level=14]
setblock 552 222 521 minecraft:light[level=14]
setblock 552 222 529 minecraft:light[level=14]
setblock 552 222 537 minecraft:light[level=14]
setblock 552 222 545 minecraft:light[level=14]
setblock 559 222 511 minecraft:white_concrete
fill 559 222 518 559 235 518 minecraft:blue_concrete
setblock 559 222 519 minecraft:white_concrete
fill 517 223 512 517 231 512 minecraft:blue_concrete
fill 517 223 514 517 244 514 minecraft:blue_concrete
setblock 519 223 510 minecraft:shroomlight
fill 524 223 541 525 224 542 minecraft:red_terracotta
fill 559 223 511 559 241 511 minecraft:blue_concrete
fill 559 223 519 559 243 519 minecraft:blue_concrete
setblock 517 224 522 minecraft:white_concrete
fill 519 224 510 519 240 510 minecraft:blue_concrete
fill 517 225 518 517 227 518 minecraft:orange_concrete
fill 517 225 522 517 243 522 minecraft:blue_concrete
fill 517 225 534 517 227 534 minecraft:orange_concrete
setblock 517 225 549 minecraft:white_concrete
fill 517 225 550 517 227 550 minecraft:orange_concrete
fill 521 225 510 521 227 510 minecraft:orange_concrete
setblock 524 225 552 minecraft:white_concrete
fill 531 225 552 531 227 552 minecraft:orange_concrete
fill 537 225 510 537 227 510 minecraft:orange_concrete
setblock 542 225 552 minecraft:shroomlight
fill 543 225 552 543 239 552 minecraft:blue_concrete
fill 547 225 552 547 227 552 minecraft:orange_concrete
fill 553 225 510 553 227 510 minecraft:orange_concrete
fill 559 225 520 559 227 520 minecraft:orange_concrete
fill 559 225 536 559 227 536 minecraft:orange_concrete
setblock 517 226 524 minecraft:white_concrete
fill 517 226 549 517 231 549 minecraft:blue_concrete
fill 524 226 552 524 243 552 minecraft:blue_concrete
setblock 527 226 510 minecraft:white_concrete
setblock 529 226 552 minecraft:magma_block
fill 535 226 546 536 227 547 minecraft:red_terracotta
fill 542 226 552 542 237 552 minecraft:blue_concrete
fill 555 226 552 555 240 552 minecraft:blue_concrete
setblock 556 226 552 minecraft:white_concrete
fill 517 227 524 517 243 524 minecraft:blue_concrete
setblock 517 227 528 minecraft:magma_block
setblock 517 227 531 minecraft:white_concrete
fill 517 227 532 517 243 532 minecraft:blue_concrete
setblock 517 227 545 minecraft:white_concrete
setblock 526 227 510 minecraft:white_concrete
fill 527 227 510 527 243 510 minecraft:blue_concrete
fill 529 227 552 529 240 552 minecraft:blue_concrete
fill 546 227 517 550 232 519 minecraft:yellow_concrete
fill 547 227 516 549 232 516 minecraft:yellow_concrete
fill 547 227 520 549 232 520 minecraft:yellow_concrete
fill 556 227 552 556 239 552 minecraft:blue_concrete
fill 517 228 518 517 233 518 minecraft:blue_concrete
fill 517 228 528 517 240 528 minecraft:blue_concrete
fill 517 228 531 517 241 531 minecraft:blue_concrete
fill 517 228 534 517 233 534 minecraft:blue_concrete
fill 517 228 545 517 237 545 minecraft:blue_concrete
fill 517 228 550 517 229 550 minecraft:blue_concrete
fill 521 228 510 521 233 510 minecraft:blue_concrete
fill 526 228 510 526 241 510 minecraft:blue_concrete
fill 531 228 552 531 233 552 minecraft:blue_concrete
fill 537 228 510 537 233 510 minecraft:blue_concrete
fill 545 228 517 545 231 519 minecraft:yellow_concrete
fill 546 228 516 546 231 516 minecraft:yellow_concrete
fill 546 228 520 546 231 520 minecraft:yellow_concrete
fill 547 228 521 548 231 521 minecraft:yellow_concrete
fill 547 228 552 547 233 552 minecraft:blue_concrete
fill 548 228 515 548 231 515 minecraft:yellow_concrete
fill 550 228 516 550 231 516 minecraft:yellow_concrete
fill 550 228 520 550 231 520 minecraft:yellow_concrete
fill 551 228 518 551 231 518 minecraft:yellow_concrete
fill 553 228 510 553 233 510 minecraft:blue_concrete
fill 559 228 520 559 233 520 minecraft:blue_concrete
fill 559 228 536 559 233 536 minecraft:blue_concrete
setblock 559 228 537 minecraft:shroomlight
setblock 517 229 535 minecraft:magma_block
setblock 532 229 552 minecraft:magma_block
fill 547 229 515 547 230 515 minecraft:yellow_concrete
fill 549 229 515 549 230 515 minecraft:yellow_concrete
fill 549 229 521 549 230 521 minecraft:yellow_concrete
setblock 550 229 552 minecraft:white_concrete
fill 551 229 517 551 230 517 minecraft:yellow_concrete
fill 551 229 519 551 230 519 minecraft:yellow_concrete
fill 559 229 537 559 241 537 minecraft:blue_concrete
fill 517 230 535 517 241 535 minecraft:blue_concrete
setblock 517 230 550 minecraft:magma_block
setblock 517 230 551 minecraft:white_concrete
setblock 520 230 513 minecraft:light[level=14]
setblock 520 230 521 minecraft:light[level=14]
setblock 520 230 529 minecraft:light[level=14]
setblock 520 230 537 minecraft:light[level=14]
setblock 520 230 545 minecraft:light[level=14]
setblock 523 230 510 minecraft:shroomlight
setblock 526 230 552 minecraft:magma_block
setblock 528 230 513 minecraft:light[level=14]
setblock 528 230 521 minecraft:light[level=14]
setblock 528 230 529 minecraft:light[level=14]
setblock 528 230 537 minecraft:light[level=14]
setblock 528 230 545 minecraft:light[level=14]
fill 532 230 552 532 231 552 minecraft:blue_concrete
setblock 536 230 513 minecraft:light[level=14]
setblock 536 230 521 minecraft:light[level=14]
setblock 536 230 529 minecraft:light[level=14]
setblock 536 230 537 minecraft:light[level=14]
setblock 536 230 545 minecraft:light[level=14]
setblock 544 230 513 minecraft:light[level=14]
setblock 544 230 521 minecraft:light[level=14]
setblock 544 230 529 minecraft:light[level=14]
setblock 544 230 537 minecraft:light[level=14]
setblock 544 230 545 minecraft:light[level=14]
fill 550 230 552 550 233 552 minecraft:blue_concrete
setblock 552 230 513 minecraft:light[level=14]
setblock 552 230 521 minecraft:light[level=14]
setblock 552 230 529 minecraft:light[level=14]
setblock 552 230 537 minecraft:light[level=14]
setblock 552 230 545 minecraft:light[level=14]
setblock 557 230 552 minecraft:white_concrete
setblock 559 230 545 minecraft:shroomlight
fill 517 231 550 517 233 551 minecraft:blue_concrete
fill 523 231 510 523 234 510 minecraft:blue_concrete
fill 526 231 552 526 240 552 minecraft:blue_concrete
fill 557 231 552 557 243 552 minecraft:blue_concrete
fill 559 231 545 559 243 545 minecraft:blue_concrete
setblock 517 232 512 minecraft:white_concrete
setblock 517 232 536 minecraft:white_concrete
setblock 517 232 549 minecraft:shroomlight
setblock 520 232 552 minecraft:shroomlight
setblock 532 232 552 minecraft:shroomlight
fill 517 233 512 517 237 512 minecraft:blue_concrete
setblock 517 233 521 minecraft:shroomlight
fill 517 233 536 517 243 536 minecraft:blue_concrete
fill 517 233 549 517 243 549 minecraft:blue_concrete
setblock 518 233 510 minecraft:shroomlight
fill 520 233 552 520 243 552 minecraft:blue_concrete
fill 532 233 552 532 239 552 minecraft:blue_concrete
setblock 542 233 510 minecraft:magma_block
setblock 550 233 510 minecraft:white_concrete
setblock 559 233 539 minecraft:shroomlight
setblock 517 234 517 minecraft:shroomlight
fill 517 234 518 517 236 518 minecraft:orange_concrete
fill 517 234 521 517 244 521 minecraft:blue_concrete
fill 517 234 534 517 236 534 minecraft:orange_concrete
fill 517 234 550 517 236 550 minecraft:orange_concrete
fill 517 234 551 517 243 551 minecraft:blue_concrete
fill 518 234 510 518 243 510 minecraft:blue_concrete
fill 521 234 510 521 236 510 minecraft:orange_concrete
fill 522 234 552 523 234 552 minecraft:shroomlight
fill 531 234 552 531 236 552 minecraft:orange_concrete
fill 537 234 510 537 236 510 minecraft:orange_concrete
fill 542 234 510 542 240 510 minecraft:blue_concrete
fill 547 234 552 547 236 552 minecraft:orange_concrete
fill 550 234 510 550 243 510 minecraft:blue_concrete
setblock 550 234 552 minecraft:shroomlight
fill 553 234 510 553 236 510 minecraft:orange_concrete
fill 559 234 520 559 236 520 minecraft:orange_concrete
fill 559 234 536 559 236 536 minecraft:orange_concrete
fill 559 234 539 559 240 539 minecraft:blue_concrete
fill 517 235 517 517 243 517 minecraft:blue_concrete
fill 522 235 552 523 243 552 minecraft:blue_concrete
setblock 523 235 510 minecraft:white_concrete
fill 550 235 552 550 242 552 minecraft:blue_concrete
setblock 559 235 514 minecraft:white_concrete
fill 523 236 510 523 239 510 minecraft:blue_concrete
setblock 541 236 510 minecraft:magma_block
fill 559 236 514 559 243 514 minecraft:blue_concrete
setblock 559 236 518 minecraft:white_concrete
fill 517 237 518 517 239 518 minecraft:blue_concrete
setblock 517 237 519 minecraft:white_concrete
setblock 517 237 534 minecraft:shroomlight
fill 517 237 550 517 243 550 minecraft:blue_concrete
fill 521 237 510 521 240 510 minecraft:blue_concrete
fill 531 237 552 531 241 552 minecraft:blue_concrete
fill 537 237 510 537 243 510 minecraft:blue_concrete
fill 541 237 510 541 240 510 minecraft:blue_concrete
setblock 545 237 552 minecraft:shroomlight
fill 547 237 552 547 241 552 minecraft:blue_concrete
fill 553 237 510 553 243 510 minecraft:blue_concrete
fill 559 237 518 559 238 518 minecraft:blue_concrete
fill 559 237 520 559 243 520 minecraft:blue_concrete
fill 559 237 536 559 238 536 minecraft:blue_concrete
setblock 517 238 512 minecraft:shroomlight
fill 517 238 519 517 240 519 minecraft:blue_concrete
setblock 517 238 530 minecraft:shroomlight
fill 517 238 534 517 241 534 minecraft:blue_concrete
setblock 517 238 540 minecraft:white_concrete
setblock 517 238 545 minecraft:white_concrete
setblock 520 238 513 minecraft:light[level=14]
setblock 520 238 521 minecraft:light[level=14]
setblock 520 238 529 minecraft:light[level=14]
setblock 520 238 537 minecraft:light[level=14]
setblock 520 238 545 minecraft:light[level=14]
setblock 528 238 513 minecraft:light[level=14]
setblock 528 238 521 minecraft:light[level=14]
setblock 528 238 529 minecraft:light[level=14]
setblock 528 238 537 minecraft:light[level=14]
setblock 528 238 545 minecraft:light[level=14]
setblock 536 238 513 minecraft:light[level=14]
setblock 536 238 521 minecraft:light[level=14]
setblock 536 238 529 minecraft:light[level=14]
setblock 536 238 537 minecraft:light[level=14]
setblock 536 238 545 minecraft:light[level=14]
setblock 542 238 552 minecraft:white_concrete
setblock 544 238 513 minecraft:light[level=14]
setblock 544 238 521 minecraft:light[level=14]
setblock 544 238 529 minecraft:light[level=14]
setblock 544 238 537 minecraft:light[level=14]
setblock 544 238 545 minecraft:light[level=14]
fill 545 238 552 545 243 552 minecraft:blue_concrete
setblock 552 238 513 minecraft:light[level=14]
setblock 552 238 521 minecraft:light[level=14]
setblock 552 238 529 minecraft:light[level=14]
setblock 552 238 537 minecraft:light[level=14]
setblock 552 238 545 minecraft:light[level=14]
setblock 559 238 547 minecraft:white_concrete
fill 517 239 512 517 243 512 minecraft:blue_concrete
setblock 517 239 516 minecraft:white_concrete
fill 517 239 530 517 240 530 minecraft:blue_concrete
setblock 517 239 540 minecraft:blue_concrete
fill 517 239 545 517 243 545 minecraft:blue_concrete
setblock 517 239 548 minecraft:shroomlight
fill 542 239 552 542 241 552 minecraft:blue_concrete
setblock 559 239 518 minecraft:shroomlight
setblock 559 239 521 minecraft:magma_block
setblock 559 239 536 minecraft:magma_block
fill 559 239 547 559 243 547 minecraft:blue_concrete
fill 517 240 516 517 243 516 minecraft:blue_concrete
setblock 517 240 518 minecraft:black_concrete
setblock 517 240 520 minecraft:black_concrete
setblock 517 240 540 minecraft:black_concrete
fill 517 240 548 517 244 548 minecraft:blue_concrete
setblock 523 240 510 minecraft:black_concrete
fill 532 240 552 532 241 552 minecraft:black_concrete
setblock 543 240 552 minecraft:shroomlight
setblock 544 240 552 minecraft:black_concrete
setblock 548 240 510 minecraft:black_concrete
setblock 552 240 552 minecraft:black_concrete
fill 555 240 510 555 241 510 minecraft:black_concrete
setblock 556 240 552 minecraft:black_concrete
setblock 557 240 510 minecraft:black_concrete
fill 559 240 512 559 241 512 minecraft:black_concrete
setblock 559 240 515 minecraft:black_concrete
setblock 559 240 518 minecraft:magma_block
fill 559 240 521 559 243 521 minecraft:blue_concrete
setblock 559 240 534 minecraft:black_concrete
fill 559 240 536 559 243 536 minecraft:blue_concrete
setblock 559 240 540 minecraft:black_concrete
setblock 559 240 550 minecraft:black_concrete
setblock 517 241 510 minecraft:black_concrete
fill 517 241 518 517 243 518 minecraft:blue_concrete
fill 517 241 519 517 242 519 minecraft:black_concrete
fill 517 241 520 517 243 520 minecraft:blue_concrete
setblock 517 241 523 minecraft:black_concrete
setblock 517 241 528 minecraft:magma_block
setblock 517 241 530 minecraft:black_concrete
fill 517 241 540 517 243 540 minecraft:blue_concrete
setblock 517 241 541 minecraft:black_concrete
setblock 517 241 552 minecraft:black_concrete
fill 519 241 510 519 242 510 minecraft:white_concrete
fill 521 241 510 522 241 510 minecraft:black_concrete
fill 523 241 510 523 243 510 minecraft:blue_concrete
setblock 524 241 510 minecraft:black_concrete
fill 525 241 552 526 241 552 minecraft:black_concrete
setblock 529 241 552 minecraft:black_concrete
setblock 535 241 510 minecraft:black_concrete
fill 535 241 529 537 241 531 minecraft:redstone_block
fill 535 241 537 537 241 539 minecraft:redstone_block
setblock 537 241 552 minecraft:black_concrete
setblock 541 241 510 minecraft:black_concrete
fill 541 241 537 543 241 539 minecraft:redstone_block
setblock 542 241 510 minecraft:white_concrete
fill 542 241 530 544 241 532 minecraft:redstone_block
fill 543 241 552 544 243 552 minecraft:blue_concrete
setblock 545 241 510 minecraft:black_concrete
fill 548 241 510 548 242 510 minecraft:blue_concrete
setblock 549 241 552 minecraft:black_concrete
setblock 551 241 510 minecraft:black_concrete
fill 552 241 552 552 243 552 minecraft:blue_concrete
setblock 553 241 552 minecraft:black_concrete
setblock 555 241 552 minecraft:magma_block
fill 556 241 552 556 243 552 minecraft:blue_concrete
fill 557 241 510 557 244 510 minecraft:blue_concrete
setblock 558 241 552 minecraft:black_concrete
setblock 559 241 515 minecraft:blue_concrete
setblock 559 241 516 minecraft:black_concrete
fill 559 241 518 559 243 518 minecraft:blue_concrete
setblock 559 241 524 minecraft:shroomlight
fill 559 241 525 559 243 525 minecraft:blue_concrete
fill 559 241 534 559 243 534 minecraft:blue_concrete
setblock 559 241 539 minecraft:white_concrete
fill 559 241 540 559 243 540 minecraft:blue_concrete
fill 559 241 550 559 244 550 minecraft:blue_concrete
fill 559 241 552 559 243 552 minecraft:blue_concrete
fill 517 242 510 517 243 510 minecraft:blue_concrete
fill 517 242 523 517 243 523 minecraft:blue_concrete
fill 517 242 526 517 242 527 minecraft:black_concrete
fill 517 242 528 517 243 528 minecraft:blue_concrete
fill 517 242 530 517 243 530 minecraft:blue_concrete
fill 517 242 531 523 242 531 minecraft:black_concrete
setblock 517 242 534 minecraft:black_concrete
setblock 517 242 535 minecraft:shroomlight
fill 517 242 541 517 243 541 minecraft:blue_concrete
fill 517 242 552 517 243 552 minecraft:blue_concrete
fill 518 242 511 519 243 512 minecraft:black_concrete
fill 518 242 513 518 243 513 minecraft:gray_concrete
fill 518 242 514 518 243 519 minecraft:black_concrete
fill 518 242 520 518 243 520 minecraft:gray_concrete
fill 518 242 521 518 243 526 minecraft:black_concrete
fill 518 242 527 518 243 527 minecraft:gray_concrete
fill 518 242 528 518 243 530 minecraft:black_concrete
fill 518 242 532 519 243 533 minecraft:black_concrete
fill 518 242 534 518 243 534 minecraft:gray_concrete
fill 518 242 535 518 243 540 minecraft:black_concrete
fill 518 242 541 518 243 541 minecraft:gray_concrete
fill 518 242 542 518 243 547 minecraft:black_concrete
fill 518 242 548 518 243 548 minecraft:gray_concrete
fill 518 242 549 518 243 551 minecraft:black_concrete
fill 519 242 513 520 243 515 minecraft:black_concrete
fill 519 242 516 519 243 516 minecraft:gray_concrete
fill 519 242 517 519 243 522 minecraft:black_concrete
fill 519 242 523 519 243 523 minecraft:gray_concrete
fill 519 242 524 519 243 529 minecraft:black_concrete
fill 519 242 530 519 243 530 minecraft:gray_concrete
fill 519 242 534 520 243 536 minecraft:black_concrete
fill 519 242 537 519 243 537 minecraft:gray_concrete
fill 519 242 538 519 243 543 minecraft:black_concrete
fill 519 242 544 519 243 544 minecraft:gray_concrete
fill 519 242 545 519 243 550 minecraft:black_concrete
fill 519 242 551 519 243 551 minecraft:gray_concrete
fill 520 242 511 521 243 511 minecraft:black_concrete
fill 520 242 512 520 243 512 minecraft:gray_concrete
fill 520 242 516 521 243 518 minecraft:black_concrete
fill 520 242 519 520 243 519 minecraft:gray_concrete
fill 520 242 520 520 243 525 minecraft:black_concrete
fill 520 242 526 520 243 526 minecraft:gray_concrete
fill 520 242 527 520 243 530 minecraft:black_concrete
fill 520 242 532 521 243 532 minecraft:black_concrete
fill 520 242 533 520 243 533 minecraft:gray_concrete
fill 520 242 537 521 243 539 minecraft:black_concrete
fill 520 242 540 520 243 540 minecraft:gray_concrete
fill 520 242 541 520 243 546 minecraft:black_concrete
fill 520 242 547 520 243 547 minecraft:gray_concrete
fill 520 242 548 520 243 551 minecraft:black_concrete
fill 521 242 510 522 243 510 minecraft:blue_concrete
fill 521 242 512 522 243 514 minecraft:black_concrete
fill 521 242 515 521 243 515 minecraft:gray_concrete
fill 521 242 519 522 243 521 minecraft:black_concrete
fill 521 242 522 521 243 522 minecraft:gray_concrete
fill 521 242 523 521 243 528 minecraft:black_concrete
fill 521 242 529 521 243 529 minecraft:gray_concrete
fill 521 242 530 525 243 530 minecraft:black_concrete
fill 521 242 533 522 243 535 minecraft:black_concrete
fill 521 242 536 521 243 536 minecraft:gray_concrete
fill 521 242 540 522 243 542 minecraft:black_concrete
fill 521 242 543 521 243 543 minecraft:gray_concrete
fill 521 242 544 521 243 549 minecraft:black_concrete
fill 521 242 550 521 243 550 minecraft:gray_concrete
fill 521 242 551 525 243 551 minecraft:black_concrete
fill 522 242 511 522 243 511 minecraft:gray_concrete
fill 522 242 515 523 243 517 minecraft:black_concrete
fill 522 242 518 522 243 518 minecraft:gray_concrete
fill 522 242 522 523 243 524 minecraft:black_concrete
fill 522 242 525 522 243 525 minecraft:gray_concrete
fill 522 242 526 522 243 529 minecraft:black_concrete
fill 522 242 532 522 243 532 minecraft:gray_concrete
fill 522 242 536 523 243 538 minecraft:black_concrete
fill 522 242 539 522 243 539 minecraft:gray_concrete
fill 522 242 543 523 243 545 minecraft:black_concrete
fill 522 242 546 522 243 546 minecraft:gray_concrete
fill 522 242 547 522 243 550 minecraft:black_concrete
fill 523 242 511 524 243 513 minecraft:black_concrete
fill 523 242 514 523 243 514 minecraft:gray_concrete
fill 523 242 518 524 243 520 minecraft:black_concrete
fill 523 242 521 523 243 521 minecraft:gray_concrete
fill 523 242 525 524 243 527 minecraft:black_concrete
fill 523 242 528 523 243 528 minecraft:gray_concrete
fill 523 242 529 527 243 529 minecraft:black_concrete
fill 523 242 532 524 243 534 minecraft:black_concrete
fill 523 242 535 523 243 535 minecraft:gray_concrete
fill 523 242 539 524 243 541 minecraft:black_concrete
fill 523 242 542 523 243 542 minecraft:gray_concrete
fill 523 242 546 524 243 548 minecraft:black_concrete
fill 523 242 549 523 243 549 minecraft:gray_concrete
fill 523 242 550 527 243 550 minecraft:black_concrete
fill 524 242 510 524 243 510 minecraft:blue_concrete
fill 524 242 514 525 243 516 minecraft:black_concrete
fill 524 242 517 524 243 517 minecraft:gray_concrete
fill 524 242 521 525 243 523 minecraft:black_concrete
fill 524 242 524 524 243 524 minecraft:gray_concrete
fill 524 242 528 529 243 528 minecraft:black_concrete
fill 524 242 531 524 243 531 minecraft:gray_concrete
fill 524 242 535 525 243 537 minecraft:black_concrete
fill 524 242 538 524 243 538 minecraft:gray_concrete
fill 524 242 542 525 243 544 minecraft:black_concrete
fill 524 242 545 524 243 545 minecraft:gray_concrete
fill 524 242 549 529 243 549 minecraft:black_concrete
fill 525 242 511 526 243 512 minecraft:black_concrete
fill 525 242 513 525 243 513 minecraft:gray_concrete
fill 525 242 517 526 243 519 minecraft:black_concrete
fill 525 242 520 525 243 520 minecraft:gray_concrete
fill 525 242 524 526 243 526 minecraft:black_concrete
fill 525 242 527 525 243 527 minecraft:gray_concrete
fill 525 242 531 526 243 533 minecraft:black_concrete
fill 525 242 534 525 243 534 minecraft:gray_concrete
fill 525 242 538 526 243 540 minecraft:black_concrete
fill 525 242 541 525 243 541 minecraft:gray_concrete
fill 525 242 545 526 243 547 minecraft:black_concrete
fill 525 242 548 525 243 548 minecraft:gray_concrete
fill 525 242 552 526 243 552 minecraft:blue_concrete
setblock 526 242 510 minecraft:black_concrete
fill 526 242 513 527 243 515 minecraft:black_concrete
fill 526 242 516 526 243 516 minecraft:gray_concrete
fill 526 242 520 527 243 522 minecraft:black_concrete
fill 526 242 523 526 243 523 minecraft:gray_concrete
fill 526 242 527 531 243 527 minecraft:black_concrete
fill 526 242 530 526 243 530 minecraft:gray_concrete
fill 526 242 534 527 243 536 minecraft:black_concrete
fill 526 242 537 526 243 537 minecraft:gray_concrete
fill 526 242 541 527 243 543 minecraft:black_concrete
fill 526 242 544 526 243 544 minecraft:gray_concrete
fill 526 242 548 531 243 548 minecraft:black_concrete
fill 526 242 551 526 243 551 minecraft:gray_concrete
fill 527 242 511 528 243 511 minecraft:black_concrete
fill 527 242 512 527 243 512 minecraft:gray_concrete
fill 527 242 516 528 243 518 minecraft:black_concrete
fill 527 242 519 527 243 519 minecraft:gray_concrete
fill 527 242 523 528 243 525 minecraft:black_concrete
fill 527 242 526 527 243 526 minecraft:gray_concrete
fill 527 242 530 528 243 532 minecraft:black_concrete
fill 527 242 533 527 243 533 minecraft:gray_concrete
fill 527 242 537 528 243 539 minecraft:black_concrete
fill 527 242 540 527 243 540 minecraft:gray_concrete
fill 527 242 544 528 243 546 minecraft:black_concrete
fill 527 242 547 527 243 547 minecraft:gray_concrete
fill 527 242 551 532 243 551 minecraft:black_concrete
fill 528 242 512 529 243 514 minecraft:black_concrete
fill 528 242 515 528 243 515 minecraft:gray_concrete
fill 528 242 519 529 243 521 minecraft:black_concrete
fill 528 242 522 528 243 522 minecraft:gray_concrete
fill 528 242 526 533 243 526 minecraft:black_concrete
fill 528 242 529 528 243 529 minecraft:gray_concrete
fill 528 242 533 529 243 535 minecraft:black_concrete
fill 528 242 536 528 243 536 minecraft:gray_concrete
fill 528 242 540 529 243 542 minecraft:black_concrete
fill 528 242 543 528 243 543 minecraft:gray_concrete
fill 528 242 547 533 243 547 minecraft:black_concrete
fill 528 242 550 528 243 550 minecraft:gray_concrete
fill 529 242 511 529 243 511 minecraft:gray_concrete
fill 529 242 515 530 243 517 minecraft:black_concrete
fill 529 242 518 529 243 518 minecraft:gray_concrete
fill 529 242 522 530 243 524 minecraft:black_concrete
fill 529 242 525 529 243 525 minecraft:gray_concrete
fill 529 242 529 530 243 531 minecraft:black_concrete
fill 529 242 532 529 243 532 minecraft:gray_concrete
fill 529 242 536 530 243 538 minecraft:black_concrete
fill 529 242 539 529 243 539 minecraft:gray_concrete
fill 529 242 543 530 243 545 minecraft:black_concrete
fill 529 242 546 529 243 546 minecraft:gray_concrete
fill 529 242 550 534 243 550 minecraft:black_concrete
fill 529 242 552 529 243 552 minecraft:blue_concrete
fill 530 242 511 531 243 513 minecraft:black_concrete
fill 530 242 514 530 243 514 minecraft:gray_concrete
fill 530 242 518 531 243 520 minecraft:black_concrete
fill 530 242 521 530 243 521 minecraft:gray_concrete
fill 530 242 525 535 243 525 minecraft:black_concrete
fill 530 242 528 530 243 528 minecraft:gray_concrete
fill 530 242 532 531 243 534 minecraft:black_concrete
fill 530 242 535 530 243 535 minecraft:gray_concrete
fill 530 242 539 531 243 541 minecraft:black_concrete
fill 530 242 542 530 243 542 minecraft:gray_concrete
fill 530 242 546 535 243 546 minecraft:black_concrete
fill 530 242 549 530 243 549 minecraft:gray_concrete
fill 530 242 552 531 242 552 minecraft:black_concrete
fill 531 242 514 532 243 516 minecraft:black_concrete
fill 531 242 517 531 243 517 minecraft:gray_concrete
fill 531 242 521 532 243 523 minecraft:black_concrete
fill 531 242 524 531 243 524 minecraft:gray_concrete
fill 531 242 528 532 243 530 minecraft:black_concrete
fill 531 242 531 531 243 531 minecraft:gray_concrete
fill 531 242 535 532 243 537 minecraft:black_concrete
fill 531 242 538 531 243 538 minecraft:gray_concrete
fill 531 242 542 532 243 544 minecraft:black_concrete
fill 531 242 545 531 243 545 minecraft:gray_concrete
fill 531 242 549 536 243 549 minecraft:black_concrete
fill 532 242 511 533 243 512 minecraft:black_concrete
fill 532 242 513 532 243 513 minecraft:gray_concrete
fill 532 242 517 533 243 519 minecraft:black_concrete
fill 532 242 520 532 243 520 minecraft:gray_concrete
fill 532 242 524 537 243 524 minecraft:black_concrete
fill 532 242 527 532 243 527 minecraft:gray_concrete
fill 532 242 531 533 243 533 minecraft:black_concrete
fill 532 242 534 532 243 534 minecraft:gray_concrete
fill 532 242 538 533 243 540 minecraft:black_concrete
fill 532 242 541 532 243 541 minecraft:gray_concrete
fill 532 242 545 537 243 545 minecraft:black_concrete
fill 532 242 548 532 243 548 minecraft:gray_concrete
fill 532 242 552 532 243 552 minecraft:blue_concrete
fill 533 242 513 534 243 515 minecraft:black_concrete
fill 533 242 516 533 243 516 minecraft:gray_concrete
fill 533 242 520 534 243 522 minecraft:black_concrete
fill 533 242 523 533 243 523 minecraft:gray_concrete
fill 533 242 527 534 242 529 minecraft:black_concrete
fill 533 242 530 533 243 530 minecraft:gray_concrete
fill 533 242 534 534 242 536 minecraft:black_concrete
fill 533 242 537 533 243 537 minecraft:gray_concrete
fill 533 242 541 534 243 543 minecraft:black_concrete
fill 533 242 544 533 243 544 minecraft:gray_concrete
fill 533 242 548 538 243 548 minecraft:black_concrete
fill 533 242 551 533 243 551 minecraft:gray_concrete
fill 534 242 511 535 243 511 minecraft:black_concrete
schedule function dropper:buildpart/131_2 1t
