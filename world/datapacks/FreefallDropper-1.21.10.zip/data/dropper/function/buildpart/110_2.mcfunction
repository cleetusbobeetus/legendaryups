fill 127 217 484 127 224 485 minecraft:basalt
setblock 127 217 486 minecraft:magma_block
fill 127 217 487 127 225 488 minecraft:basalt
setblock 127 217 489 minecraft:magma_block
fill 127 217 490 128 223 490 minecraft:basalt
fill 127 217 500 128 217 500 minecraft:basalt
setblock 127 217 501 minecraft:magma_block
fill 128 217 476 129 218 476 minecraft:basalt
fill 128 217 484 128 223 484 minecraft:basalt
fill 128 217 487 128 224 487 minecraft:basalt
setblock 129 217 475 minecraft:basalt
setblock 130 217 476 minecraft:magma_block
fill 130 217 480 132 217 480 minecraft:basalt
fill 130 217 497 131 217 497 minecraft:basalt
setblock 131 217 478 minecraft:basalt
fill 131 217 481 132 218 481 minecraft:basalt
fill 131 217 493 132 218 493 minecraft:basalt
setblock 131 217 496 minecraft:basalt
setblock 133 217 481 minecraft:magma_block
fill 133 217 487 134 217 488 minecraft:basalt
setblock 133 217 493 minecraft:magma_block
setblock 134 217 486 minecraft:basalt
fill 135 217 485 135 273 486 minecraft:deepslate_bricks
setblock 99 218 484 minecraft:basalt
setblock 99 218 485 minecraft:magma_block
fill 99 218 486 99 218 487 minecraft:basalt
setblock 99 218 488 minecraft:magma_block
fill 99 218 489 99 218 490 minecraft:basalt
fill 100 218 483 101 219 483 minecraft:basalt
fill 100 218 486 101 219 486 minecraft:basalt
fill 100 218 489 101 219 489 minecraft:basalt
fill 101 218 495 102 218 495 minecraft:basalt
setblock 102 218 477 minecraft:basalt
setblock 102 218 478 minecraft:magma_block
setblock 102 218 496 minecraft:magma_block
fill 102 218 497 105 218 497 minecraft:basalt
fill 103 218 464 103 219 464 minecraft:deepslate_bricks
fill 103 218 466 103 219 466 minecraft:deepslate_bricks
fill 103 218 468 103 219 468 minecraft:deepslate_bricks
fill 103 218 476 106 218 476 minecraft:basalt
fill 103 218 498 105 218 498 minecraft:basalt
fill 104 218 465 104 219 465 minecraft:deepslate_bricks
fill 104 218 467 104 219 467 minecraft:deepslate_bricks
fill 104 218 469 104 219 469 minecraft:deepslate_bricks
fill 104 218 486 104 224 486 minecraft:basalt
fill 104 218 489 104 224 489 minecraft:basalt
fill 105 218 464 105 219 464 minecraft:deepslate_bricks
fill 105 218 466 105 219 466 minecraft:deepslate_bricks
fill 105 218 468 105 219 468 minecraft:deepslate_bricks
setblock 105 218 474 minecraft:magma_block
setblock 105 218 486 minecraft:magma_block
setblock 105 218 489 minecraft:magma_block
fill 105 218 500 108 218 500 minecraft:basalt
fill 106 218 465 106 219 465 minecraft:deepslate_bricks
fill 106 218 467 106 219 467 minecraft:deepslate_bricks
fill 106 218 469 106 219 469 minecraft:deepslate_bricks
fill 106 218 473 108 218 473 minecraft:basalt
fill 106 218 481 107 224 481 minecraft:basalt
fill 106 218 483 106 225 484 minecraft:basalt
fill 106 218 490 106 225 491 minecraft:basalt
fill 106 218 493 107 224 493 minecraft:basalt
fill 107 218 464 107 219 464 minecraft:deepslate_bricks
fill 107 218 466 107 219 466 minecraft:deepslate_bricks
fill 107 218 468 107 219 468 minecraft:deepslate_bricks
fill 108 218 465 108 219 465 minecraft:deepslate_bricks
fill 108 218 467 108 219 467 minecraft:deepslate_bricks
fill 108 218 469 108 219 469 minecraft:deepslate_bricks
fill 108 218 472 111 218 472 minecraft:basalt
fill 108 218 480 108 225 480 minecraft:basalt
setblock 108 218 494 minecraft:magma_block
fill 108 218 502 111 218 502 minecraft:basalt
fill 109 218 464 109 219 464 minecraft:deepslate_bricks
fill 109 218 466 109 219 466 minecraft:deepslate_bricks
fill 109 218 468 109 219 468 minecraft:deepslate_bricks
fill 109 218 479 109 225 479 minecraft:basalt
fill 109 218 495 109 225 495 minecraft:basalt
fill 110 218 465 110 219 465 minecraft:deepslate_bricks
fill 110 218 467 110 219 467 minecraft:deepslate_bricks
fill 110 218 469 110 219 469 minecraft:deepslate_bricks
fill 110 218 471 111 218 471 minecraft:basalt
fill 110 218 478 110 224 478 minecraft:basalt
fill 110 218 496 110 224 496 minecraft:basalt
fill 111 218 464 111 219 464 minecraft:deepslate_bricks
fill 111 218 466 111 219 466 minecraft:deepslate_bricks
fill 111 218 468 111 219 468 minecraft:deepslate_bricks
fill 112 218 465 112 219 465 minecraft:deepslate_bricks
fill 112 218 467 112 219 467 minecraft:deepslate_bricks
fill 112 218 469 115 219 469 minecraft:deepslate_bricks
fill 112 218 476 113 224 477 minecraft:basalt
fill 112 218 497 113 218 497 minecraft:basalt
fill 113 218 464 113 219 464 minecraft:deepslate_bricks
fill 113 218 466 113 219 466 minecraft:deepslate_bricks
fill 113 218 468 113 219 468 minecraft:deepslate_bricks
fill 113 218 470 116 218 470 minecraft:basalt
fill 113 218 498 113 224 498 minecraft:basalt
setblock 113 218 504 minecraft:basalt
fill 114 218 465 114 219 465 minecraft:deepslate_bricks
fill 114 218 467 114 219 467 minecraft:deepslate_bricks
fill 114 218 476 116 224 476 minecraft:basalt
setblock 114 218 498 minecraft:magma_block
setblock 114 218 504 minecraft:magma_block
fill 115 218 464 115 219 464 minecraft:deepslate_bricks
fill 115 218 466 115 219 466 minecraft:deepslate_bricks
fill 115 218 468 115 219 468 minecraft:deepslate_bricks
fill 115 218 498 118 225 498 minecraft:basalt
fill 116 218 471 122 218 471 minecraft:basalt
fill 116 218 504 119 218 504 minecraft:basalt
setblock 117 218 470 minecraft:magma_block
setblock 117 218 476 minecraft:magma_block
fill 118 218 476 119 224 476 minecraft:basalt
setblock 119 218 470 minecraft:basalt
fill 119 218 477 120 218 477 minecraft:basalt
fill 119 218 497 121 225 497 minecraft:basalt
fill 119 218 503 122 218 503 minecraft:basalt
fill 120 218 504 123 219 504 minecraft:deepslate_bricks
fill 121 218 473 125 218 473 minecraft:basalt
fill 122 218 472 124 218 472 minecraft:basalt
fill 122 218 478 122 225 478 minecraft:basalt
fill 122 218 496 122 225 496 minecraft:basalt
fill 122 218 502 124 218 502 minecraft:basalt
fill 123 218 479 123 225 479 minecraft:basalt
setblock 123 218 495 minecraft:magma_block
fill 123 218 503 124 219 503 minecraft:deepslate_bricks
fill 124 218 480 124 225 480 minecraft:basalt
fill 124 218 494 124 225 494 minecraft:basalt
fill 125 218 474 127 218 475 minecraft:basalt
fill 125 218 481 125 225 481 minecraft:basalt
fill 125 218 493 125 225 493 minecraft:basalt
fill 125 218 499 128 218 499 minecraft:basalt
fill 125 218 502 126 219 502 minecraft:deepslate_bricks
fill 125 218 504 125 219 504 minecraft:deepslate_bricks
setblock 126 218 473 minecraft:magma_block
setblock 126 218 482 minecraft:magma_block
fill 126 218 483 126 225 484 minecraft:basalt
fill 126 218 490 126 225 490 minecraft:basalt
setblock 126 218 491 minecraft:magma_block
fill 126 218 498 129 218 498 minecraft:basalt
fill 126 218 503 126 219 503 minecraft:deepslate_bricks
fill 127 218 477 130 218 477 minecraft:basalt
fill 127 218 482 127 224 483 minecraft:basalt
fill 127 218 486 127 225 486 minecraft:basalt
fill 127 218 489 127 225 489 minecraft:basalt
setblock 127 218 500 minecraft:basalt
setblock 128 218 475 minecraft:basalt
fill 128 218 479 131 218 479 minecraft:basalt
fill 129 218 494 131 218 495 minecraft:basalt
fill 130 218 480 131 219 480 minecraft:basalt
fill 130 218 482 132 218 482 minecraft:basalt
fill 130 218 492 131 219 492 minecraft:basalt
setblock 130 218 497 minecraft:basalt
fill 131 218 483 131 220 491 minecraft:basalt
setblock 132 218 483 minecraft:magma_block
fill 132 218 484 132 219 491 minecraft:basalt
setblock 132 218 492 minecraft:magma_block
fill 133 218 484 133 218 485 minecraft:basalt
fill 133 218 487 133 218 488 minecraft:basalt
setblock 133 218 490 minecraft:basalt
setblock 101 219 480 minecraft:magma_block
fill 101 219 481 102 219 481 minecraft:basalt
setblock 101 219 492 minecraft:magma_block
fill 101 219 493 102 219 493 minecraft:basalt
fill 102 219 479 103 219 480 minecraft:basalt
setblock 102 219 495 minecraft:basalt
fill 103 219 497 105 219 497 minecraft:basalt
setblock 104 219 476 minecraft:magma_block
fill 104 219 498 105 219 498 minecraft:basalt
fill 105 219 475 106 219 476 minecraft:basalt
fill 105 219 486 106 219 486 minecraft:basalt
fill 105 219 489 106 225 489 minecraft:basalt
fill 105 219 499 107 219 499 minecraft:basalt
fill 106 219 485 106 226 485 minecraft:basalt
fill 106 219 487 106 225 488 minecraft:basalt
fill 106 219 500 108 219 500 minecraft:basalt
fill 107 219 475 107 220 475 minecraft:basalt
fill 107 219 482 107 226 483 minecraft:basalt
fill 107 219 491 107 226 492 minecraft:basalt
setblock 108 219 473 minecraft:basalt
fill 108 219 481 108 226 481 minecraft:basalt
fill 108 219 493 108 225 494 minecraft:basalt
fill 108 219 501 110 219 501 minecraft:basalt
fill 109 219 472 111 219 472 minecraft:basalt
fill 109 219 480 109 225 480 minecraft:basalt
fill 109 219 494 109 226 494 minecraft:basalt
fill 109 219 502 111 219 502 minecraft:basalt
fill 110 219 479 110 226 479 minecraft:basalt
setblock 110 219 495 minecraft:magma_block
fill 111 219 478 112 219 478 minecraft:basalt
fill 111 219 496 112 219 496 minecraft:basalt
fill 112 219 497 112 225 497 minecraft:basalt
setblock 112 219 503 minecraft:basalt
setblock 113 219 497 minecraft:magma_block
setblock 113 219 503 minecraft:magma_block
fill 113 219 504 119 219 504 minecraft:deepslate_bricks
fill 114 219 477 118 219 477 minecraft:basalt
fill 114 219 497 114 225 498 minecraft:basalt
fill 114 219 503 117 219 503 minecraft:basalt
fill 115 219 497 118 226 497 minecraft:basalt
fill 116 219 471 118 219 471 minecraft:basalt
fill 117 219 476 117 225 476 minecraft:basalt
setblock 119 219 471 minecraft:magma_block
setblock 119 219 477 minecraft:magma_block
fill 119 219 503 120 219 503 minecraft:basalt
setblock 120 219 471 minecraft:basalt
fill 120 219 477 120 225 478 minecraft:basalt
fill 120 219 496 121 226 496 minecraft:basalt
fill 121 219 473 124 219 473 minecraft:basalt
fill 121 219 478 121 226 478 minecraft:basalt
fill 121 219 503 122 219 503 minecraft:deepslate_bricks
fill 122 219 472 123 219 472 minecraft:basalt
setblock 122 219 479 minecraft:magma_block
fill 122 219 495 123 225 495 minecraft:basalt
fill 122 219 502 123 219 502 minecraft:basalt
fill 123 219 480 123 226 480 minecraft:basalt
fill 123 219 494 123 226 494 minecraft:basalt
fill 124 219 481 124 225 481 minecraft:basalt
fill 124 219 493 124 225 493 minecraft:basalt
fill 124 219 502 124 230 502 minecraft:deepslate_bricks
fill 125 219 474 126 219 475 minecraft:basalt
fill 125 219 482 125 226 483 minecraft:basalt
fill 125 219 491 125 226 492 minecraft:basalt
fill 125 219 499 126 219 500 minecraft:basalt
fill 125 219 501 126 219 501 minecraft:deepslate_bricks
fill 126 219 482 126 225 482 minecraft:basalt
fill 126 219 485 126 226 489 minecraft:basalt
fill 126 219 491 126 225 491 minecraft:basalt
fill 126 219 498 127 220 498 minecraft:basalt
setblock 127 219 475 minecraft:basalt
fill 127 219 477 129 219 477 minecraft:basalt
setblock 127 219 499 minecraft:basalt
setblock 128 219 476 minecraft:basalt
fill 128 219 479 130 219 479 minecraft:basalt
setblock 128 219 498 minecraft:magma_block
fill 129 219 494 130 219 495 minecraft:basalt
fill 130 219 482 130 220 482 minecraft:basalt
setblock 131 219 481 minecraft:basalt
setblock 131 219 482 minecraft:magma_block
setblock 131 219 493 minecraft:basalt
setblock 131 219 494 minecraft:magma_block
setblock 132 219 483 minecraft:basalt
fill 96 220 473 96 225 475 minecraft:deepslate_bricks
fill 96 220 485 96 225 487 minecraft:deepslate_bricks
fill 96 220 497 96 225 499 minecraft:deepslate_bricks
fill 101 220 483 101 220 484 minecraft:basalt
fill 101 220 486 101 220 487 minecraft:basalt
fill 101 220 489 101 220 490 minecraft:basalt
fill 102 220 480 102 220 482 minecraft:basalt
fill 102 220 493 102 220 494 minecraft:basalt
fill 102 220 503 104 225 503 minecraft:deepslate_bricks
setblock 103 220 464 minecraft:sea_lantern
setblock 103 220 466 minecraft:sea_lantern
setblock 103 220 468 minecraft:sea_lantern
fill 103 220 479 103 220 480 minecraft:basalt
fill 103 220 494 103 221 494 minecraft:basalt
setblock 104 220 465 minecraft:sea_lantern
setblock 104 220 467 minecraft:sea_lantern
setblock 104 220 469 minecraft:sea_lantern
fill 104 220 477 105 220 477 minecraft:basalt
fill 104 220 497 106 220 497 minecraft:basalt
setblock 105 220 464 minecraft:sea_lantern
setblock 105 220 466 minecraft:sea_lantern
setblock 105 220 468 minecraft:sea_lantern
fill 105 220 476 106 220 476 minecraft:basalt
fill 105 220 486 105 225 486 minecraft:basalt
setblock 105 220 498 minecraft:basalt
setblock 106 220 465 minecraft:sea_lantern
setblock 106 220 467 minecraft:sea_lantern
setblock 106 220 469 minecraft:sea_lantern
setblock 106 220 475 minecraft:basalt
setblock 106 220 486 minecraft:magma_block
setblock 106 220 498 minecraft:magma_block
fill 106 220 499 107 220 499 minecraft:basalt
setblock 107 220 464 minecraft:sea_lantern
setblock 107 220 466 minecraft:sea_lantern
setblock 107 220 468 minecraft:sea_lantern
fill 107 220 484 107 226 485 minecraft:basalt
fill 107 220 489 107 226 490 minecraft:basalt
setblock 108 220 465 minecraft:sea_lantern
setblock 108 220 467 minecraft:sea_lantern
setblock 108 220 469 minecraft:sea_lantern
fill 108 220 474 109 220 474 minecraft:basalt
fill 108 220 482 108 226 482 minecraft:basalt
fill 108 220 492 108 226 492 minecraft:basalt
setblock 108 220 500 minecraft:basalt
setblock 109 220 464 minecraft:sea_lantern
setblock 109 220 466 minecraft:sea_lantern
setblock 109 220 468 minecraft:sea_lantern
setblock 109 220 473 minecraft:magma_block
fill 109 220 481 109 226 481 minecraft:basalt
fill 109 220 493 109 226 493 minecraft:basalt
fill 109 220 501 110 220 501 minecraft:basalt
setblock 110 220 465 minecraft:sea_lantern
setblock 110 220 467 minecraft:sea_lantern
setblock 110 220 469 minecraft:sea_lantern
fill 110 220 480 110 226 480 minecraft:basalt
fill 110 220 494 110 226 495 minecraft:basalt
setblock 111 220 464 minecraft:sea_lantern
setblock 111 220 466 minecraft:sea_lantern
setblock 111 220 468 minecraft:sea_lantern
fill 111 220 478 111 226 479 minecraft:basalt
fill 111 220 495 111 226 496 minecraft:basalt
setblock 112 220 465 minecraft:sea_lantern
setblock 112 220 467 minecraft:sea_lantern
setblock 112 220 469 minecraft:sea_lantern
setblock 112 220 472 minecraft:magma_block
fill 112 220 473 113 221 473 minecraft:basalt
setblock 112 220 478 minecraft:magma_block
setblock 112 220 496 minecraft:magma_block
fill 112 220 501 114 221 501 minecraft:basalt
setblock 112 220 502 minecraft:magma_block
setblock 113 220 464 minecraft:sea_lantern
setblock 113 220 466 minecraft:sea_lantern
setblock 113 220 468 minecraft:sea_lantern
fill 113 220 469 113 229 469 minecraft:deepslate_bricks
setblock 113 220 472 minecraft:basalt
fill 113 220 478 114 226 478 minecraft:basalt
fill 113 220 496 113 225 497 minecraft:basalt
fill 113 220 502 114 220 502 minecraft:basalt
fill 113 220 504 114 273 504 minecraft:deepslate_bricks
setblock 114 220 465 minecraft:sea_lantern
setblock 114 220 467 minecraft:sea_lantern
setblock 114 220 469 minecraft:sea_lantern
fill 114 220 477 114 226 477 minecraft:basalt
fill 114 220 496 114 226 496 minecraft:basalt
setblock 114 220 503 minecraft:sea_lantern
setblock 115 220 464 minecraft:sea_lantern
setblock 115 220 466 minecraft:sea_lantern
setblock 115 220 468 minecraft:sea_lantern
fill 115 220 469 115 229 469 minecraft:deepslate_bricks
setblock 115 220 477 minecraft:magma_block
fill 115 220 503 115 230 503 minecraft:deepslate_bricks
setblock 115 220 504 minecraft:sea_lantern
fill 116 220 477 119 225 477 minecraft:basalt
setblock 116 220 503 minecraft:sea_lantern
fill 116 220 504 116 230 504 minecraft:deepslate_bricks
fill 117 220 503 117 230 503 minecraft:deepslate_bricks
setblock 117 220 504 minecraft:sea_lantern
fill 118 220 465 120 225 465 minecraft:deepslate_bricks
fill 118 220 478 119 226 478 minecraft:basalt
fill 118 220 496 119 226 496 minecraft:basalt
fill 118 220 501 118 220 502 minecraft:basalt
setblock 118 220 503 minecraft:sea_lantern
fill 118 220 504 118 224 504 minecraft:deepslate_bricks
fill 119 220 503 119 230 503 minecraft:deepslate_bricks
setblock 119 220 504 minecraft:sea_lantern
setblock 120 220 502 minecraft:basalt
setblock 120 220 503 minecraft:sea_lantern
fill 120 220 504 120 224 504 minecraft:deepslate_bricks
fill 121 220 473 123 220 473 minecraft:basalt
fill 121 220 479 122 225 479 minecraft:basalt
fill 121 220 495 121 226 495 minecraft:basalt
setblock 121 220 502 minecraft:sea_lantern
fill 121 220 503 121 230 503 minecraft:deepslate_bricks
setblock 121 220 504 minecraft:sea_lantern
fill 122 220 480 122 226 480 minecraft:basalt
fill 122 220 494 122 226 494 minecraft:basalt
fill 122 220 502 122 230 502 minecraft:deepslate_bricks
setblock 122 220 503 minecraft:sea_lantern
fill 122 220 504 122 224 504 minecraft:deepslate_bricks
fill 123 220 481 123 226 481 minecraft:basalt
fill 123 220 493 123 226 493 minecraft:basalt
setblock 123 220 502 minecraft:sea_lantern
fill 123 220 503 123 230 503 minecraft:deepslate_bricks
setblock 123 220 504 minecraft:sea_lantern
setblock 124 220 474 minecraft:magma_block
fill 124 220 475 126 220 475 minecraft:basalt
fill 124 220 482 124 226 482 minecraft:basalt
setblock 124 220 492 minecraft:magma_block
fill 124 220 499 124 220 500 minecraft:basalt
setblock 124 220 501 minecraft:sea_lantern
setblock 124 220 503 minecraft:sea_lantern
fill 125 220 484 125 226 485 minecraft:basalt
fill 125 220 489 125 226 490 minecraft:basalt
fill 125 220 499 126 220 499 minecraft:basalt
setblock 125 220 500 minecraft:sea_lantern
fill 125 220 501 125 230 501 minecraft:deepslate_bricks
setblock 125 220 502 minecraft:sea_lantern
setblock 125 220 504 minecraft:sea_lantern
fill 126 220 497 126 221 497 minecraft:basalt
fill 126 220 500 126 230 500 minecraft:deepslate_bricks
setblock 126 220 501 minecraft:sea_lantern
fill 126 220 502 126 230 502 minecraft:deepslate_bricks
setblock 126 220 503 minecraft:sea_lantern
setblock 127 220 476 minecraft:magma_block
fill 127 220 477 128 220 477 minecraft:basalt
setblock 127 220 497 minecraft:magma_block
fill 127 220 503 128 225 503 minecraft:deepslate_bricks
fill 128 220 478 128 220 479 minecraft:basalt
fill 128 220 496 128 220 497 minecraft:basalt
setblock 129 220 479 minecraft:basalt
fill 129 220 481 129 221 481 minecraft:basalt
fill 129 220 493 129 220 495 minecraft:basalt
fill 130 220 465 132 225 465 minecraft:deepslate_bricks
setblock 130 220 480 minecraft:basalt
setblock 130 220 481 minecraft:magma_block
setblock 130 220 492 minecraft:basalt
setblock 130 220 493 minecraft:magma_block
setblock 130 220 494 minecraft:basalt
fill 134 220 473 134 225 475 minecraft:deepslate_bricks
fill 134 220 485 134 225 487 minecraft:deepslate_bricks
fill 134 220 497 134 225 499 minecraft:deepslate_bricks
setblock 97 221 466 minecraft:light[level=11]
setblock 97 221 474 minecraft:light[level=11]
setblock 97 221 482 minecraft:light[level=11]
setblock 97 221 490 minecraft:light[level=11]
setblock 97 221 498 minecraft:light[level=11]
setblock 102 221 483 minecraft:magma_block
setblock 102 221 486 minecraft:magma_block
fill 102 221 487 102 221 488 minecraft:basalt
setblock 102 221 489 minecraft:magma_block
fill 103 221 464 103 222 464 minecraft:deepslate_bricks
fill 103 221 466 103 222 466 minecraft:deepslate_bricks
fill 103 221 468 103 222 468 minecraft:deepslate_bricks
setblock 103 221 480 minecraft:basalt
fill 103 221 492 103 222 492 minecraft:basalt
fill 104 221 465 104 222 465 minecraft:deepslate_bricks
fill 104 221 467 104 222 467 minecraft:deepslate_bricks
fill 104 221 469 104 222 469 minecraft:deepslate_bricks
fill 105 221 464 105 222 464 minecraft:deepslate_bricks
fill 105 221 466 105 222 466 minecraft:deepslate_bricks
fill 105 221 468 105 222 468 minecraft:deepslate_bricks
setblock 105 221 474 minecraft:light[level=11]
setblock 105 221 498 minecraft:light[level=11]
fill 106 221 465 106 222 465 minecraft:deepslate_bricks
fill 106 221 467 106 222 467 minecraft:deepslate_bricks
fill 106 221 469 106 222 469 minecraft:deepslate_bricks
fill 106 221 486 107 226 486 minecraft:basalt
setblock 106 221 497 minecraft:basalt
fill 107 221 464 107 222 464 minecraft:deepslate_bricks
fill 107 221 466 107 222 466 minecraft:deepslate_bricks
fill 107 221 468 107 222 468 minecraft:deepslate_bricks
fill 107 221 487 107 226 488 minecraft:basalt
fill 108 221 465 108 222 465 minecraft:deepslate_bricks
fill 108 221 467 108 222 467 minecraft:deepslate_bricks
fill 108 221 469 108 222 469 minecraft:deepslate_bricks
setblock 108 221 475 minecraft:magma_block
fill 108 221 476 108 222 476 minecraft:basalt
fill 108 221 483 108 226 483 minecraft:basalt
setblock 108 221 484 minecraft:magma_block
setblock 108 221 490 minecraft:magma_block
fill 108 221 491 108 226 491 minecraft:basalt
fill 108 221 498 108 222 498 minecraft:basalt
setblock 108 221 499 minecraft:magma_block
fill 109 221 464 109 222 464 minecraft:deepslate_bricks
fill 109 221 466 109 222 466 minecraft:deepslate_bricks
fill 109 221 468 109 222 468 minecraft:deepslate_bricks
setblock 109 221 474 minecraft:basalt
fill 109 221 482 109 226 482 minecraft:basalt
fill 109 221 492 109 225 492 minecraft:basalt
fill 110 221 465 110 222 465 minecraft:deepslate_bricks
fill 110 221 467 110 222 467 minecraft:deepslate_bricks
fill 110 221 469 110 222 469 minecraft:deepslate_bricks
fill 110 221 481 110 226 481 minecraft:basalt
fill 110 221 493 110 226 493 minecraft:basalt
fill 111 221 464 111 222 464 minecraft:deepslate_bricks
fill 111 221 466 111 222 466 minecraft:deepslate_bricks
fill 111 221 468 111 222 468 minecraft:deepslate_bricks
setblock 111 221 474 minecraft:magma_block
setblock 111 221 480 minecraft:magma_block
fill 111 221 494 111 226 494 minecraft:basalt
fill 111 221 500 111 222 500 minecraft:basalt
fill 112 221 465 112 222 465 minecraft:deepslate_bricks
fill 112 221 467 112 222 467 minecraft:deepslate_bricks
fill 112 221 469 112 222 469 minecraft:deepslate_bricks
fill 112 221 478 112 225 479 minecraft:basalt
fill 112 221 495 112 226 496 minecraft:basalt
fill 113 221 464 113 222 464 minecraft:deepslate_bricks
fill 113 221 466 113 222 466 minecraft:deepslate_bricks
fill 113 221 468 113 222 468 minecraft:deepslate_bricks
fill 113 221 479 113 226 479 minecraft:basalt
setblock 113 221 482 minecraft:light[level=11]
setblock 113 221 490 minecraft:light[level=11]
fill 113 221 495 113 226 495 minecraft:basalt
fill 114 221 465 114 222 465 minecraft:deepslate_bricks
fill 114 221 467 114 222 467 minecraft:deepslate_bricks
fill 114 221 469 114 222 469 minecraft:deepslate_bricks
setblock 114 221 473 minecraft:magma_block
fill 114 221 502 114 222 503 minecraft:deepslate_bricks
fill 115 221 464 115 222 464 minecraft:deepslate_bricks
fill 115 221 466 115 222 466 minecraft:deepslate_bricks
fill 115 221 468 115 222 468 minecraft:deepslate_bricks
fill 115 221 473 118 221 473 minecraft:basalt
fill 115 221 477 115 225 478 minecraft:basalt
fill 115 221 496 116 225 496 minecraft:basalt
fill 115 221 502 121 222 502 minecraft:deepslate_bricks
fill 115 221 504 115 222 504 minecraft:deepslate_bricks
fill 116 221 478 116 226 478 minecraft:basalt
fill 116 221 503 116 222 503 minecraft:deepslate_bricks
setblock 117 221 478 minecraft:magma_block
setblock 117 221 496 minecraft:magma_block
fill 117 221 501 119 221 501 minecraft:basalt
fill 117 221 504 117 222 504 minecraft:deepslate_bricks
fill 118 221 503 118 222 503 minecraft:deepslate_bricks
fill 119 221 479 120 221 479 minecraft:basalt
fill 119 221 495 119 226 495 minecraft:basalt
fill 119 221 504 119 222 504 minecraft:deepslate_bricks
setblock 120 221 495 minecraft:magma_block
fill 120 221 500 120 222 500 minecraft:basalt
setblock 120 221 501 minecraft:magma_block
fill 120 221 503 120 222 503 minecraft:deepslate_bricks
setblock 121 221 466 minecraft:light[level=11]
fill 121 221 480 121 226 480 minecraft:basalt
setblock 121 221 482 minecraft:light[level=11]
setblock 121 221 490 minecraft:light[level=11]
fill 121 221 494 121 225 494 minecraft:basalt
fill 121 221 501 124 222 501 minecraft:deepslate_bricks
fill 121 221 504 121 222 504 minecraft:deepslate_bricks
setblock 122 221 481 minecraft:basalt
setblock 122 221 493 minecraft:basalt
fill 122 221 503 122 222 503 minecraft:deepslate_bricks
setblock 123 221 482 minecraft:magma_block
fill 123 221 492 124 226 492 minecraft:basalt
fill 123 221 499 124 221 499 minecraft:basalt
setblock 123 221 500 minecraft:magma_block
fill 123 221 502 123 222 502 minecraft:deepslate_bricks
fill 123 221 504 123 222 504 minecraft:deepslate_bricks
setblock 124 221 475 minecraft:basalt
fill 124 221 483 124 225 484 minecraft:basalt
fill 124 221 490 124 225 491 minecraft:basalt
fill 124 221 500 125 222 500 minecraft:deepslate_bricks
fill 124 221 503 124 222 503 minecraft:deepslate_bricks
fill 125 221 486 125 226 488 minecraft:basalt
fill 125 221 499 126 222 499 minecraft:deepslate_bricks
fill 125 221 502 125 222 502 minecraft:deepslate_bricks
fill 125 221 504 125 222 504 minecraft:deepslate_bricks
fill 126 221 498 126 230 498 minecraft:deepslate_bricks
fill 126 221 501 126 222 501 minecraft:deepslate_bricks
fill 126 221 503 126 222 503 minecraft:deepslate_bricks
fill 128 221 479 128 221 480 minecraft:basalt
setblock 129 221 466 minecraft:light[level=11]
setblock 129 221 474 minecraft:light[level=11]
setblock 129 221 480 minecraft:magma_block
fill 129 221 491 129 222 491 minecraft:basalt
setblock 129 221 492 minecraft:magma_block
fill 129 221 493 129 221 494 minecraft:basalt
setblock 129 221 498 minecraft:light[level=11]
fill 99 222 464 99 223 464 minecraft:cyan_concrete
setblock 104 222 481 minecraft:magma_block
fill 104 222 482 104 223 482 minecraft:basalt
fill 104 222 492 104 223 492 minecraft:basalt
setblock 104 222 493 minecraft:magma_block
setblock 107 222 477 minecraft:magma_block
fill 108 222 484 108 226 490 minecraft:basalt
fill 109 222 483 109 225 483 minecraft:basalt
fill 109 222 491 109 226 491 minecraft:basalt
fill 109 222 499 110 222 499 minecraft:basalt
setblock 111 222 474 minecraft:basalt
fill 111 222 480 112 226 480 minecraft:basalt
fill 112 222 494 112 225 494 minecraft:basalt
fill 114 222 474 115 222 474 minecraft:basalt
fill 114 222 479 118 222 479 minecraft:basalt
fill 114 222 495 115 226 495 minecraft:basalt
fill 114 222 501 120 222 501 minecraft:deepslate_bricks
setblock 116 222 474 minecraft:magma_block
setblock 116 222 495 minecraft:magma_block
fill 116 222 500 118 222 500 minecraft:basalt
fill 117 222 478 117 226 478 minecraft:basalt
fill 117 222 495 117 226 496 minecraft:basalt
fill 118 222 495 118 225 495 minecraft:basalt
setblock 119 222 479 minecraft:magma_block
setblock 119 222 500 minecraft:magma_block
setblock 120 222 474 minecraft:basalt
fill 120 222 479 120 226 480 minecraft:basalt
fill 120 222 494 120 226 495 minecraft:basalt
fill 121 222 475 121 223 475 minecraft:basalt
fill 121 222 499 121 223 499 minecraft:basalt
setblock 122 222 475 minecraft:magma_block
setblock 122 222 481 minecraft:magma_block
setblock 122 222 493 minecraft:magma_block
setblock 122 222 499 minecraft:magma_block
fill 122 222 500 123 222 500 minecraft:deepslate_bricks
fill 123 222 482 123 226 483 minecraft:basalt
fill 123 222 491 123 226 491 minecraft:basalt
setblock 123 222 499 minecraft:basalt
fill 124 222 485 124 222 489 minecraft:basalt
setblock 124 222 499 minecraft:deepslate_bricks
setblock 125 222 477 minecraft:magma_block
setblock 125 222 498 minecraft:deepslate_bricks
fill 127 222 494 127 223 494 minecraft:basalt
setblock 128 222 480 minecraft:basalt
setblock 128 222 494 minecraft:magma_block
setblock 129 222 492 minecraft:basalt
fill 99 223 465 99 223 467 minecraft:cyan_concrete
setblock 103 223 464 minecraft:sea_lantern
setblock 103 223 466 minecraft:sea_lantern
setblock 103 223 468 minecraft:sea_lantern
setblock 103 223 486 minecraft:magma_block
setblock 104 223 465 minecraft:sea_lantern
setblock 104 223 467 minecraft:sea_lantern
setblock 104 223 469 minecraft:sea_lantern
setblock 104 223 483 minecraft:basalt
setblock 105 223 464 minecraft:sea_lantern
setblock 105 223 466 minecraft:sea_lantern
setblock 105 223 468 minecraft:sea_lantern
setblock 106 223 465 minecraft:sea_lantern
setblock 106 223 467 minecraft:sea_lantern
setblock 106 223 469 minecraft:sea_lantern
setblock 106 223 479 minecraft:magma_block
setblock 106 223 480 minecraft:basalt
setblock 106 223 494 minecraft:magma_block
setblock 106 223 495 minecraft:basalt
setblock 107 223 464 minecraft:sea_lantern
setblock 107 223 466 minecraft:sea_lantern
setblock 107 223 468 minecraft:sea_lantern
setblock 108 223 465 minecraft:sea_lantern
setblock 108 223 467 minecraft:sea_lantern
setblock 108 223 469 minecraft:sea_lantern
setblock 109 223 464 minecraft:sea_lantern
setblock 109 223 466 minecraft:sea_lantern
setblock 109 223 468 minecraft:sea_lantern
setblock 109 223 484 minecraft:magma_block
fill 109 223 485 109 226 485 minecraft:basalt
fill 109 223 489 109 225 489 minecraft:basalt
setblock 109 223 490 minecraft:magma_block
setblock 110 223 465 minecraft:sea_lantern
setblock 110 223 467 minecraft:sea_lantern
setblock 110 223 469 minecraft:sea_lantern
fill 110 223 482 110 226 483 minecraft:basalt
fill 110 223 491 110 226 492 minecraft:basalt
setblock 111 223 464 minecraft:sea_lantern
setblock 111 223 466 minecraft:sea_lantern
setblock 111 223 468 minecraft:sea_lantern
fill 111 223 475 117 223 475 minecraft:basalt
fill 111 223 481 112 226 481 minecraft:basalt
fill 111 223 493 112 226 493 minecraft:basalt
setblock 112 223 465 minecraft:sea_lantern
setblock 112 223 467 minecraft:sea_lantern
setblock 112 223 469 minecraft:sea_lantern
setblock 113 223 464 minecraft:sea_lantern
setblock 113 223 466 minecraft:sea_lantern
setblock 113 223 468 minecraft:sea_lantern
fill 113 223 480 114 226 480 minecraft:basalt
fill 113 223 494 114 226 494 minecraft:basalt
setblock 114 223 465 minecraft:sea_lantern
setblock 114 223 467 minecraft:sea_lantern
setblock 114 223 469 minecraft:sea_lantern
fill 114 223 479 114 226 479 minecraft:basalt
fill 114 223 499 117 223 499 minecraft:basalt
fill 114 223 500 114 230 500 minecraft:deepslate_bricks
setblock 114 223 501 minecraft:sea_lantern
fill 114 223 502 114 230 502 minecraft:deepslate_bricks
setblock 114 223 503 minecraft:sea_lantern
setblock 115 223 464 minecraft:sea_lantern
setblock 115 223 466 minecraft:sea_lantern
setblock 115 223 468 minecraft:sea_lantern
fill 115 223 474 116 223 474 minecraft:basalt
setblock 115 223 479 minecraft:magma_block
setblock 115 223 500 minecraft:magma_block
fill 115 223 501 115 230 501 minecraft:deepslate_bricks
setblock 115 223 502 minecraft:sea_lantern
setblock 115 223 504 minecraft:sea_lantern
fill 116 223 479 119 226 479 minecraft:basalt
fill 116 223 495 116 226 495 minecraft:basalt
fill 116 223 500 117 223 500 minecraft:basalt
setblock 116 223 501 minecraft:sea_lantern
fill 116 223 502 116 230 502 minecraft:deepslate_bricks
setblock 116 223 503 minecraft:sea_lantern
fill 117 223 501 117 230 501 minecraft:deepslate_bricks
setblock 117 223 502 minecraft:sea_lantern
setblock 117 223 504 minecraft:sea_lantern
setblock 118 223 475 minecraft:magma_block
fill 118 223 480 119 225 480 minecraft:basalt
fill 118 223 494 119 226 494 minecraft:basalt
setblock 118 223 499 minecraft:magma_block
fill 118 223 500 118 230 500 minecraft:deepslate_bricks
setblock 118 223 501 minecraft:sea_lantern
fill 118 223 502 118 230 502 minecraft:deepslate_bricks
setblock 118 223 503 minecraft:sea_lantern
setblock 119 223 500 minecraft:sea_lantern
fill 119 223 501 119 230 501 minecraft:deepslate_bricks
setblock 119 223 502 minecraft:sea_lantern
setblock 119 223 504 minecraft:sea_lantern
fill 120 223 481 122 226 481 minecraft:basalt
fill 120 223 493 122 226 493 minecraft:basalt
fill 120 223 500 120 230 500 minecraft:deepslate_bricks
setblock 120 223 501 minecraft:sea_lantern
fill 120 223 502 120 230 502 minecraft:deepslate_bricks
setblock 120 223 503 minecraft:sea_lantern
setblock 121 223 500 minecraft:sea_lantern
fill 121 223 501 121 230 501 minecraft:deepslate_bricks
setblock 121 223 502 minecraft:sea_lantern
setblock 121 223 504 minecraft:sea_lantern
fill 122 223 482 122 226 483 minecraft:basalt
fill 122 223 491 122 226 492 minecraft:basalt
setblock 122 223 499 minecraft:sea_lantern
fill 122 223 500 122 230 500 minecraft:deepslate_bricks
setblock 122 223 501 minecraft:sea_lantern
setblock 122 223 503 minecraft:sea_lantern
fill 123 223 484 123 226 485 minecraft:basalt
fill 123 223 489 123 226 490 minecraft:basalt
setblock 123 223 497 minecraft:basalt
fill 123 223 499 123 230 499 minecraft:deepslate_bricks
setblock 123 223 500 minecraft:sea_lantern
fill 123 223 501 123 230 501 minecraft:deepslate_bricks
setblock 123 223 502 minecraft:sea_lantern
setblock 123 223 504 minecraft:sea_lantern
fill 124 223 485 124 225 487 minecraft:basalt
setblock 124 223 488 minecraft:magma_block
fill 124 223 489 124 226 489 minecraft:basalt
setblock 124 223 497 minecraft:magma_block
fill 124 223 498 124 230 498 minecraft:deepslate_bricks
setblock 124 223 499 minecraft:sea_lantern
fill 124 223 500 124 230 500 minecraft:deepslate_bricks
setblock 124 223 501 minecraft:sea_lantern
setblock 124 223 503 minecraft:sea_lantern
setblock 125 223 498 minecraft:sea_lantern
fill 125 223 499 125 230 499 minecraft:deepslate_bricks
setblock 125 223 500 minecraft:sea_lantern
setblock 125 223 502 minecraft:sea_lantern
setblock 125 223 504 minecraft:sea_lantern
setblock 126 223 499 minecraft:sea_lantern
setblock 126 223 501 minecraft:sea_lantern
setblock 126 223 503 minecraft:sea_lantern
setblock 127 223 481 minecraft:magma_block
setblock 127 223 493 minecraft:magma_block
setblock 128 223 482 minecraft:basalt
setblock 128 223 492 minecraft:basalt
fill 99 224 466 99 224 469 minecraft:cyan_concrete
setblock 103 224 464 minecraft:deepslate_bricks
fill 103 224 466 103 225 466 minecraft:deepslate_bricks
fill 103 224 468 103 225 468 minecraft:deepslate_bricks
fill 104 224 465 104 225 465 minecraft:deepslate_bricks
fill 104 224 467 104 225 467 minecraft:deepslate_bricks
fill 104 224 469 104 225 469 minecraft:deepslate_bricks
fill 105 224 464 105 225 464 minecraft:deepslate_bricks
fill 105 224 466 105 225 466 minecraft:deepslate_bricks
fill 105 224 468 105 225 468 minecraft:deepslate_bricks
fill 105 224 482 105 224 483 minecraft:basalt
setblock 105 224 484 minecraft:magma_block
fill 105 224 485 105 225 485 minecraft:basalt
setblock 105 224 490 minecraft:magma_block
fill 105 224 491 105 224 492 minecraft:basalt
fill 106 224 465 106 225 465 minecraft:deepslate_bricks
fill 106 224 467 106 225 467 minecraft:deepslate_bricks
fill 106 224 469 106 225 469 minecraft:deepslate_bricks
fill 107 224 464 107 225 464 minecraft:deepslate_bricks
fill 107 224 466 107 225 466 minecraft:deepslate_bricks
fill 107 224 468 107 225 468 minecraft:deepslate_bricks
fill 108 224 465 108 225 465 minecraft:deepslate_bricks
fill 108 224 467 108 225 467 minecraft:deepslate_bricks
fill 108 224 469 108 225 469 minecraft:deepslate_bricks
setblock 108 224 478 minecraft:basalt
setblock 108 224 495 minecraft:magma_block
fill 109 224 464 109 225 464 minecraft:deepslate_bricks
fill 109 224 466 109 225 466 minecraft:deepslate_bricks
fill 109 224 468 109 225 468 minecraft:deepslate_bricks
fill 109 224 484 110 224 484 minecraft:basalt
fill 109 224 486 109 225 488 minecraft:basalt
fill 109 224 490 110 224 490 minecraft:basalt
fill 110 224 465 110 225 465 minecraft:deepslate_bricks
fill 110 224 467 110 225 467 minecraft:deepslate_bricks
fill 110 224 469 110 225 469 minecraft:deepslate_bricks
setblock 111 224 464 minecraft:deepslate_bricks
fill 111 224 466 111 225 466 minecraft:deepslate_bricks
fill 111 224 468 111 225 468 minecraft:deepslate_bricks
setblock 111 224 476 minecraft:magma_block
fill 111 224 477 111 225 477 minecraft:basalt
setblock 111 224 482 minecraft:magma_block
fill 111 224 492 111 226 492 minecraft:basalt
fill 112 224 465 112 225 465 minecraft:deepslate_bricks
fill 112 224 467 112 225 467 minecraft:deepslate_bricks
fill 112 224 469 112 225 469 minecraft:deepslate_bricks
setblock 113 224 464 minecraft:deepslate_bricks
fill 113 224 466 113 225 466 minecraft:deepslate_bricks
fill 113 224 468 113 225 468 minecraft:deepslate_bricks
fill 113 224 481 113 226 481 minecraft:basalt
fill 113 224 493 113 226 493 minecraft:basalt
fill 114 224 465 114 225 465 minecraft:deepslate_bricks
fill 114 224 467 114 225 467 minecraft:deepslate_bricks
fill 114 224 469 114 225 469 minecraft:deepslate_bricks
setblock 114 224 475 minecraft:magma_block
setblock 114 224 499 minecraft:magma_block
fill 114 224 501 114 225 501 minecraft:deepslate_bricks
fill 114 224 503 114 225 503 minecraft:deepslate_bricks
setblock 115 224 464 minecraft:deepslate_bricks
fill 115 224 466 115 225 466 minecraft:deepslate_bricks
fill 115 224 468 115 225 468 minecraft:deepslate_bricks
fill 115 224 475 118 224 475 minecraft:basalt
fill 115 224 479 115 226 480 minecraft:basalt
fill 115 224 494 117 226 494 minecraft:basalt
fill 115 224 499 118 224 499 minecraft:basalt
fill 115 224 500 117 225 500 minecraft:deepslate_bricks
fill 115 224 502 115 225 502 minecraft:deepslate_bricks
fill 115 224 504 115 225 504 minecraft:deepslate_bricks
fill 116 224 480 116 226 480 minecraft:basalt
fill 116 224 501 116 225 501 minecraft:deepslate_bricks
fill 116 224 503 116 225 503 minecraft:deepslate_bricks
setblock 117 224 480 minecraft:magma_block
fill 117 224 502 117 225 502 minecraft:deepslate_bricks
fill 117 224 504 117 225 504 minecraft:deepslate_bricks
fill 118 224 501 118 225 501 minecraft:deepslate_bricks
fill 118 224 503 118 225 503 minecraft:deepslate_bricks
setblock 119 224 481 minecraft:basalt
setblock 119 224 493 minecraft:basalt
fill 119 224 498 120 224 498 minecraft:basalt
fill 119 224 499 119 225 500 minecraft:deepslate_bricks
fill 119 224 502 119 225 502 minecraft:deepslate_bricks
setblock 119 224 504 minecraft:deepslate_bricks
setblock 120 224 476 minecraft:magma_block
fill 120 224 499 122 225 499 minecraft:deepslate_bricks
fill 120 224 501 120 225 501 minecraft:deepslate_bricks
fill 120 224 503 120 225 503 minecraft:deepslate_bricks
fill 121 224 482 121 225 482 minecraft:basalt
fill 121 224 492 121 226 492 minecraft:basalt
fill 121 224 500 121 225 500 minecraft:deepslate_bricks
fill 121 224 502 121 225 502 minecraft:deepslate_bricks
setblock 121 224 504 minecraft:deepslate_bricks
fill 122 224 484 122 226 484 minecraft:basalt
fill 122 224 490 122 226 490 minecraft:basalt
fill 122 224 498 123 225 498 minecraft:deepslate_bricks
fill 122 224 501 122 225 501 minecraft:deepslate_bricks
fill 122 224 503 122 225 503 minecraft:deepslate_bricks
setblock 123 224 478 minecraft:magma_block
fill 123 224 486 123 226 486 minecraft:basalt
setblock 123 224 487 minecraft:magma_block
fill 123 224 488 124 226 488 minecraft:basalt
setblock 123 224 496 minecraft:magma_block
fill 123 224 500 123 225 500 minecraft:deepslate_bricks
fill 123 224 502 123 225 502 minecraft:deepslate_bricks
setblock 123 224 504 minecraft:deepslate_bricks
fill 124 224 499 124 225 499 minecraft:deepslate_bricks
fill 124 224 501 124 225 501 minecraft:deepslate_bricks
fill 124 224 503 124 225 503 minecraft:deepslate_bricks
setblock 125 224 495 minecraft:basalt
fill 125 224 498 125 225 498 minecraft:deepslate_bricks
fill 125 224 500 125 225 500 minecraft:deepslate_bricks
fill 125 224 502 125 225 502 minecraft:deepslate_bricks
fill 125 224 504 125 225 504 minecraft:deepslate_bricks
setblock 126 224 481 minecraft:basalt
fill 126 224 499 126 225 499 minecraft:deepslate_bricks
fill 126 224 501 126 225 501 minecraft:deepslate_bricks
fill 126 224 503 126 225 503 minecraft:deepslate_bricks
setblock 127 224 490 minecraft:basalt
fill 95 225 467 95 225 472 minecraft:sculk
fill 95 225 479 95 225 484 minecraft:sculk
fill 95 225 491 95 225 496 minecraft:sculk
fill 95 225 503 95 225 504 minecraft:sculk
fill 96 225 504 99 225 504 minecraft:sculk
fill 99 225 464 104 225 464 minecraft:sculk
fill 99 225 468 99 225 469 minecraft:cyan_concrete
fill 106 225 504 111 225 504 minecraft:sculk
setblock 107 225 481 minecraft:basalt
setblock 107 225 493 minecraft:basalt
fill 109 225 484 109 226 484 minecraft:basalt
fill 109 225 490 109 226 490 minecraft:basalt
setblock 110 225 478 minecraft:magma_block
setblock 110 225 484 minecraft:magma_block
fill 110 225 485 110 225 486 minecraft:basalt
fill 110 225 487 110 226 487 minecraft:magma_block
fill 110 225 488 110 225 489 minecraft:basalt
setblock 110 225 490 minecraft:magma_block
setblock 110 225 496 minecraft:magma_block
fill 111 225 464 116 225 464 minecraft:sculk
fill 111 225 482 111 226 483 minecraft:basalt
fill 111 225 491 111 226 491 minecraft:basalt
setblock 112 225 477 minecraft:basalt
setblock 112 225 482 minecraft:basalt
fill 112 225 492 112 226 492 minecraft:basalt
setblock 113 225 477 minecraft:magma_block
fill 114 225 476 115 225 476 minecraft:basalt
fill 114 225 481 118 225 481 minecraft:basalt
fill 114 225 493 118 225 493 minecraft:basalt
fill 114 225 499 118 225 499 minecraft:deepslate_bricks
setblock 116 225 476 minecraft:magma_block
fill 117 225 480 117 226 480 minecraft:basalt
setblock 118 225 476 minecraft:basalt
fill 118 225 504 123 225 504 minecraft:sculk
setblock 119 225 481 minecraft:magma_block
setblock 119 225 493 minecraft:magma_block
fill 119 225 498 121 225 498 minecraft:deepslate_bricks
fill 120 225 482 120 226 482 minecraft:basalt
fill 120 225 492 120 226 492 minecraft:basalt
setblock 121 225 477 minecraft:basalt
fill 121 225 483 121 226 483 minecraft:basalt
setblock 121 225 491 minecraft:basalt
fill 122 225 485 122 226 485 minecraft:basalt
fill 122 225 486 122 226 486 minecraft:magma_block
fill 122 225 487 122 225 488 minecraft:basalt
setblock 122 225 489 minecraft:magma_block
fill 123 225 464 128 225 464 minecraft:sculk
fill 123 225 487 123 226 487 minecraft:basalt
setblock 127 225 485 minecraft:basalt
fill 130 225 504 135 225 504 minecraft:sculk
fill 135 225 464 135 225 469 minecraft:sculk
fill 135 225 476 135 225 481 minecraft:sculk
fill 135 225 488 135 225 493 minecraft:sculk
fill 135 225 500 135 225 503 minecraft:sculk
fill 94 226 467 94 307 468 minecraft:deepslate_tiles
fill 94 226 469 94 231 472 minecraft:sea_lantern
fill 94 226 473 94 307 473 minecraft:deepslate_tiles
fill 94 226 476 94 307 480 minecraft:deepslate_tiles
fill 94 226 481 94 231 484 minecraft:sea_lantern
fill 94 226 485 94 307 485 minecraft:deepslate_tiles
fill 94 226 493 94 231 496 minecraft:sea_lantern
fill 94 226 497 94 307 497 minecraft:deepslate_tiles
fill 94 226 505 97 231 505 minecraft:sea_lantern
fill 95 226 463 100 307 463 minecraft:deepslate_tiles
fill 101 226 463 104 231 463 minecraft:sea_lantern
setblock 103 226 464 minecraft:sea_lantern
setblock 103 226 466 minecraft:sea_lantern
setblock 103 226 468 minecraft:sea_lantern
fill 104 226 464 104 229 464 minecraft:deepslate_bricks
setblock 104 226 465 minecraft:sea_lantern
setblock 104 226 467 minecraft:sea_lantern
setblock 104 226 469 minecraft:sea_lantern
fill 105 226 463 107 307 463 minecraft:deepslate_tiles
setblock 105 226 464 minecraft:sea_lantern
setblock 105 226 466 minecraft:sea_lantern
setblock 105 226 468 minecraft:sea_lantern
setblock 106 226 465 minecraft:sea_lantern
setblock 106 226 467 minecraft:sea_lantern
setblock 106 226 469 minecraft:sea_lantern
setblock 106 226 487 minecraft:magma_block
fill 106 226 488 106 226 489 minecraft:basalt
fill 106 226 505 109 231 505 minecraft:sea_lantern
setblock 107 226 464 minecraft:sea_lantern
setblock 107 226 466 minecraft:sea_lantern
setblock 107 226 468 minecraft:sea_lantern
setblock 108 226 465 minecraft:sea_lantern
setblock 108 226 467 minecraft:sea_lantern
setblock 108 226 469 minecraft:sea_lantern
setblock 108 226 493 minecraft:basalt
setblock 109 226 464 minecraft:sea_lantern
setblock 109 226 466 minecraft:sea_lantern
setblock 109 226 468 minecraft:sea_lantern
setblock 109 226 480 minecraft:magma_block
setblock 109 226 483 minecraft:magma_block
fill 109 226 486 111 226 486 minecraft:magma_block
fill 109 226 487 109 226 488 minecraft:basalt
setblock 109 226 489 minecraft:magma_block
setblock 109 226 492 minecraft:magma_block
fill 110 226 463 112 307 463 minecraft:deepslate_tiles
setblock 110 226 465 minecraft:sea_lantern
setblock 110 226 467 minecraft:sea_lantern
setblock 110 226 469 minecraft:sea_lantern
fill 110 226 484 110 226 485 minecraft:basalt
fill 110 226 488 111 226 488 minecraft:magma_block
fill 110 226 489 110 226 490 minecraft:basalt
setblock 111 226 464 minecraft:sea_lantern
setblock 111 226 466 minecraft:sea_lantern
setblock 111 226 468 minecraft:sea_lantern
fill 111 226 484 111 226 485 minecraft:magma_block
fill 111 226 489 111 226 490 minecraft:magma_block
fill 112 226 464 112 229 464 minecraft:deepslate_bricks
setblock 112 226 465 minecraft:sea_lantern
setblock 112 226 467 minecraft:sea_lantern
setblock 112 226 469 minecraft:sea_lantern
setblock 112 226 478 minecraft:basalt
setblock 112 226 479 minecraft:magma_block
fill 112 226 482 112 226 483 minecraft:magma_block
setblock 112 226 491 minecraft:magma_block
setblock 112 226 494 minecraft:magma_block
fill 113 226 463 113 226 464 minecraft:sea_lantern
setblock 113 226 466 minecraft:sea_lantern
setblock 113 226 468 minecraft:sea_lantern
fill 113 226 482 115 226 482 minecraft:magma_block
fill 113 226 492 115 226 492 minecraft:magma_block
setblock 113 226 496 minecraft:basalt
fill 113 226 505 117 307 505 minecraft:deepslate_tiles
fill 114 226 463 116 231 463 minecraft:sea_lantern
fill 114 226 464 114 229 464 minecraft:deepslate_bricks
setblock 114 226 465 minecraft:sea_lantern
setblock 114 226 467 minecraft:sea_lantern
setblock 114 226 469 minecraft:sea_lantern
setblock 114 226 481 minecraft:basalt
setblock 114 226 493 minecraft:basalt
setblock 114 226 497 minecraft:basalt
fill 114 226 498 114 230 498 minecraft:deepslate_bricks
setblock 114 226 499 minecraft:sea_lantern
setblock 114 226 501 minecraft:sea_lantern
setblock 114 226 503 minecraft:sea_lantern
setblock 115 226 464 minecraft:sea_lantern
setblock 115 226 466 minecraft:sea_lantern
setblock 115 226 468 minecraft:sea_lantern
fill 115 226 477 117 226 477 minecraft:basalt
setblock 115 226 478 minecraft:magma_block
fill 115 226 481 117 226 481 minecraft:magma_block
fill 115 226 493 117 226 493 minecraft:magma_block
setblock 115 226 496 minecraft:magma_block
setblock 115 226 498 minecraft:sea_lantern
fill 115 226 499 115 230 499 minecraft:deepslate_bricks
setblock 115 226 500 minecraft:sea_lantern
setblock 115 226 502 minecraft:sea_lantern
setblock 115 226 504 minecraft:sea_lantern
setblock 116 226 496 minecraft:basalt
fill 116 226 498 116 230 498 minecraft:deepslate_bricks
setblock 116 226 499 minecraft:sea_lantern
fill 116 226 500 116 230 500 minecraft:deepslate_bricks
setblock 116 226 501 minecraft:sea_lantern
setblock 116 226 503 minecraft:sea_lantern
fill 117 226 482 119 226 482 minecraft:magma_block
fill 117 226 492 119 226 492 minecraft:magma_block
setblock 117 226 498 minecraft:sea_lantern
fill 117 226 499 117 230 499 minecraft:deepslate_bricks
setblock 117 226 500 minecraft:sea_lantern
setblock 117 226 502 minecraft:sea_lantern
setblock 117 226 504 minecraft:sea_lantern
setblock 118 226 477 minecraft:magma_block
setblock 118 226 480 minecraft:magma_block
fill 118 226 481 119 226 481 minecraft:basalt
fill 118 226 493 119 226 493 minecraft:basalt
setblock 118 226 495 minecraft:magma_block
fill 118 226 498 118 230 498 minecraft:deepslate_bricks
setblock 118 226 499 minecraft:sea_lantern
setblock 118 226 501 minecraft:sea_lantern
setblock 118 226 503 minecraft:sea_lantern
fill 118 226 504 118 230 504 minecraft:deepslate_bricks
fill 118 226 505 121 231 505 minecraft:sea_lantern
setblock 119 226 480 minecraft:basalt
setblock 119 226 498 minecraft:sea_lantern
fill 119 226 499 119 230 499 minecraft:deepslate_bricks
setblock 119 226 500 minecraft:sea_lantern
setblock 119 226 502 minecraft:sea_lantern
setblock 119 226 504 minecraft:sea_lantern
setblock 120 226 478 minecraft:basalt
setblock 120 226 483 minecraft:magma_block
fill 120 226 491 121 226 491 minecraft:magma_block
fill 120 226 498 120 230 498 minecraft:deepslate_bricks
setblock 120 226 499 minecraft:sea_lantern
setblock 120 226 501 minecraft:sea_lantern
setblock 120 226 503 minecraft:sea_lantern
fill 120 226 504 120 230 504 minecraft:deepslate_bricks
setblock 121 226 479 minecraft:magma_block
setblock 121 226 482 minecraft:magma_block
fill 121 226 484 121 226 486 minecraft:magma_block
fill 121 226 488 121 226 490 minecraft:magma_block
setblock 121 226 494 minecraft:magma_block
setblock 121 226 498 minecraft:sea_lantern
fill 121 226 499 121 230 499 minecraft:deepslate_bricks
setblock 121 226 500 minecraft:sea_lantern
setblock 121 226 502 minecraft:sea_lantern
setblock 121 226 504 minecraft:sea_lantern
fill 122 226 463 124 307 463 minecraft:deepslate_tiles
setblock 122 226 479 minecraft:basalt
fill 122 226 487 122 226 488 minecraft:magma_block
setblock 122 226 489 minecraft:basalt
setblock 122 226 495 minecraft:basalt
fill 122 226 498 122 230 498 minecraft:deepslate_bricks
setblock 122 226 499 minecraft:sea_lantern
setblock 122 226 501 minecraft:sea_lantern
setblock 122 226 503 minecraft:sea_lantern
fill 122 226 504 122 230 504 minecraft:deepslate_bricks
fill 122 226 505 122 307 505 minecraft:deepslate_tiles
setblock 123 226 498 minecraft:sea_lantern
setblock 123 226 500 minecraft:sea_lantern
setblock 123 226 502 minecraft:sea_lantern
setblock 123 226 504 minecraft:sea_lantern
setblock 124 226 481 minecraft:magma_block
setblock 124 226 483 minecraft:basalt
setblock 124 226 484 minecraft:magma_block
fill 124 226 485 124 226 486 minecraft:basalt
setblock 124 226 487 minecraft:magma_block
setblock 124 226 490 minecraft:magma_block
setblock 124 226 491 minecraft:basalt
setblock 124 226 493 minecraft:magma_block
setblock 124 226 499 minecraft:sea_lantern
setblock 124 226 501 minecraft:sea_lantern
setblock 124 226 503 minecraft:sea_lantern
fill 125 226 463 128 231 463 minecraft:sea_lantern
setblock 125 226 498 minecraft:sea_lantern
setblock 125 226 500 minecraft:sea_lantern
setblock 125 226 502 minecraft:sea_lantern
setblock 125 226 504 minecraft:sea_lantern
setblock 126 226 499 minecraft:sea_lantern
setblock 126 226 501 minecraft:sea_lantern
setblock 126 226 503 minecraft:sea_lantern
fill 129 226 463 129 307 463 minecraft:deepslate_tiles
fill 130 226 505 133 231 505 minecraft:sea_lantern
fill 136 226 464 136 231 467 minecraft:sea_lantern
fill 136 226 468 136 307 471 minecraft:deepslate_tiles
fill 136 226 475 136 307 475 minecraft:deepslate_tiles
fill 136 226 476 136 231 479 minecraft:sea_lantern
fill 136 226 480 136 307 487 minecraft:deepslate_tiles
fill 136 226 488 136 231 491 minecraft:sea_lantern
fill 136 226 492 136 307 493 minecraft:deepslate_tiles
fill 136 226 495 136 307 499 minecraft:deepslate_tiles
fill 136 226 500 136 231 503 minecraft:sea_lantern
fill 103 227 464 103 229 464 minecraft:deepslate_bricks
fill 103 227 466 103 229 466 minecraft:deepslate_bricks
fill 103 227 468 103 229 468 minecraft:deepslate_bricks
fill 104 227 465 104 229 465 minecraft:deepslate_bricks
fill 104 227 467 104 229 467 minecraft:deepslate_bricks
fill 104 227 469 104 229 469 minecraft:deepslate_bricks
fill 105 227 464 105 229 464 minecraft:deepslate_bricks
fill 105 227 466 105 229 466 minecraft:deepslate_bricks
fill 105 227 468 105 229 468 minecraft:deepslate_bricks
fill 106 227 465 106 229 465 minecraft:deepslate_bricks
fill 106 227 467 106 229 467 minecraft:deepslate_bricks
fill 106 227 469 106 229 469 minecraft:deepslate_bricks
fill 107 227 464 107 273 464 minecraft:deepslate_bricks
fill 107 227 466 107 229 466 minecraft:deepslate_bricks
fill 107 227 468 107 229 468 minecraft:deepslate_bricks
fill 108 227 465 108 229 465 minecraft:deepslate_bricks
fill 108 227 467 108 229 467 minecraft:deepslate_bricks
fill 108 227 469 108 229 469 minecraft:deepslate_bricks
fill 109 227 464 109 273 464 minecraft:deepslate_bricks
fill 109 227 466 109 229 466 minecraft:deepslate_bricks
fill 109 227 468 109 229 468 minecraft:deepslate_bricks
fill 110 227 465 110 229 465 minecraft:deepslate_bricks
fill 110 227 467 110 229 467 minecraft:deepslate_bricks
fill 110 227 469 110 229 469 minecraft:deepslate_bricks
fill 111 227 464 111 229 464 minecraft:deepslate_bricks
fill 111 227 466 111 229 466 minecraft:deepslate_bricks
fill 111 227 468 111 229 468 minecraft:deepslate_bricks
fill 112 227 465 112 229 465 minecraft:deepslate_bricks
fill 112 227 467 112 229 467 minecraft:deepslate_bricks
fill 112 227 469 112 229 469 minecraft:deepslate_bricks
fill 113 227 463 113 231 463 minecraft:sea_lantern
fill 113 227 464 113 229 464 minecraft:deepslate_bricks
fill 113 227 466 113 229 466 minecraft:deepslate_bricks
fill 113 227 468 113 229 468 minecraft:deepslate_bricks
fill 114 227 465 114 229 465 minecraft:deepslate_bricks
fill 114 227 467 114 229 467 minecraft:deepslate_bricks
fill 114 227 469 114 229 469 minecraft:deepslate_bricks
fill 114 227 499 114 228 499 minecraft:deepslate_bricks
fill 114 227 501 114 228 501 minecraft:deepslate_bricks
fill 114 227 503 114 228 503 minecraft:deepslate_bricks
fill 115 227 464 115 229 464 minecraft:deepslate_bricks
fill 115 227 466 115 229 466 minecraft:deepslate_bricks
fill 115 227 468 115 229 468 minecraft:deepslate_bricks
fill 115 227 498 115 228 498 minecraft:deepslate_bricks
fill 115 227 500 115 228 500 minecraft:deepslate_bricks
fill 115 227 502 115 228 502 minecraft:deepslate_bricks
fill 115 227 504 115 228 504 minecraft:deepslate_bricks
fill 116 227 499 116 228 499 minecraft:deepslate_bricks
fill 116 227 501 116 228 501 minecraft:deepslate_bricks
fill 116 227 503 116 228 503 minecraft:deepslate_bricks
fill 117 227 498 117 228 498 minecraft:deepslate_bricks
fill 117 227 500 117 228 500 minecraft:deepslate_bricks
fill 117 227 502 117 228 502 minecraft:deepslate_bricks
fill 117 227 504 117 228 504 minecraft:deepslate_bricks
fill 118 227 499 118 228 499 minecraft:deepslate_bricks
fill 118 227 501 118 228 501 minecraft:deepslate_bricks
fill 118 227 503 118 228 503 minecraft:deepslate_bricks
fill 119 227 498 119 228 498 minecraft:deepslate_bricks
fill 119 227 500 119 228 500 minecraft:deepslate_bricks
fill 119 227 502 119 228 502 minecraft:deepslate_bricks
fill 119 227 504 119 228 504 minecraft:deepslate_bricks
fill 120 227 499 120 228 499 minecraft:deepslate_bricks
fill 120 227 501 120 228 501 minecraft:deepslate_bricks
fill 120 227 503 120 228 503 minecraft:deepslate_bricks
fill 121 227 498 121 228 498 minecraft:deepslate_bricks
fill 121 227 500 121 228 500 minecraft:deepslate_bricks
fill 121 227 502 121 228 502 minecraft:deepslate_bricks
fill 121 227 504 121 228 504 minecraft:deepslate_bricks
fill 122 227 499 122 228 499 minecraft:deepslate_bricks
fill 122 227 501 122 228 501 minecraft:deepslate_bricks
fill 122 227 503 122 228 503 minecraft:deepslate_bricks
fill 123 227 498 123 228 498 minecraft:deepslate_bricks
fill 123 227 500 123 228 500 minecraft:deepslate_bricks
fill 123 227 502 123 228 502 minecraft:deepslate_bricks
fill 123 227 504 123 228 504 minecraft:deepslate_bricks
fill 124 227 499 124 228 499 minecraft:deepslate_bricks
fill 124 227 501 124 228 501 minecraft:deepslate_bricks
fill 124 227 503 124 228 503 minecraft:deepslate_bricks
fill 125 227 498 125 228 498 minecraft:deepslate_bricks
fill 125 227 500 125 228 500 minecraft:deepslate_bricks
fill 125 227 502 125 228 502 minecraft:deepslate_bricks
fill 125 227 504 125 228 504 minecraft:deepslate_bricks
fill 126 227 499 126 228 499 minecraft:deepslate_bricks
fill 126 227 501 126 228 501 minecraft:deepslate_bricks
fill 126 227 503 126 228 503 minecraft:deepslate_bricks
setblock 97 229 466 minecraft:light[level=11]
setblock 97 229 474 minecraft:light[level=11]
setblock 97 229 482 minecraft:light[level=11]
setblock 97 229 490 minecraft:light[level=11]
setblock 97 229 498 minecraft:light[level=11]
setblock 105 229 474 minecraft:light[level=11]
setblock 105 229 482 minecraft:light[level=11]
setblock 105 229 490 minecraft:light[level=11]
setblock 105 229 498 minecraft:light[level=11]
setblock 113 229 474 minecraft:light[level=11]
setblock 113 229 482 minecraft:light[level=11]
setblock 113 229 490 minecraft:light[level=11]
setblock 113 229 498 minecraft:light[level=11]
setblock 114 229 499 minecraft:sea_lantern
setblock 114 229 501 minecraft:sea_lantern
setblock 114 229 503 minecraft:sea_lantern
setblock 115 229 498 minecraft:sea_lantern
setblock 115 229 500 minecraft:sea_lantern
setblock 115 229 502 minecraft:sea_lantern
setblock 115 229 504 minecraft:sea_lantern
setblock 116 229 499 minecraft:sea_lantern
setblock 116 229 501 minecraft:sea_lantern
setblock 116 229 503 minecraft:sea_lantern
setblock 117 229 498 minecraft:sea_lantern
setblock 117 229 500 minecraft:sea_lantern
setblock 117 229 502 minecraft:sea_lantern
setblock 117 229 504 minecraft:sea_lantern
setblock 118 229 499 minecraft:sea_lantern
setblock 118 229 501 minecraft:sea_lantern
setblock 118 229 503 minecraft:sea_lantern
setblock 119 229 498 minecraft:sea_lantern
setblock 119 229 500 minecraft:sea_lantern
setblock 119 229 502 minecraft:sea_lantern
setblock 119 229 504 minecraft:sea_lantern
setblock 120 229 499 minecraft:sea_lantern
setblock 120 229 501 minecraft:sea_lantern
setblock 120 229 503 minecraft:sea_lantern
setblock 121 229 466 minecraft:light[level=11]
setblock 121 229 474 minecraft:light[level=11]
setblock 121 229 482 minecraft:light[level=11]
setblock 121 229 490 minecraft:light[level=11]
setblock 121 229 498 minecraft:sea_lantern
setblock 121 229 500 minecraft:sea_lantern
setblock 121 229 502 minecraft:sea_lantern
setblock 121 229 504 minecraft:sea_lantern
setblock 122 229 499 minecraft:sea_lantern
setblock 122 229 501 minecraft:sea_lantern
setblock 122 229 503 minecraft:sea_lantern
setblock 123 229 498 minecraft:sea_lantern
setblock 123 229 500 minecraft:sea_lantern
setblock 123 229 502 minecraft:sea_lantern
setblock 123 229 504 minecraft:sea_lantern
setblock 124 229 499 minecraft:sea_lantern
setblock 124 229 501 minecraft:sea_lantern
setblock 124 229 503 minecraft:sea_lantern
setblock 125 229 498 minecraft:sea_lantern
setblock 125 229 500 minecraft:sea_lantern
setblock 125 229 502 minecraft:sea_lantern
setblock 125 229 504 minecraft:sea_lantern
setblock 126 229 499 minecraft:sea_lantern
setblock 126 229 501 minecraft:sea_lantern
setblock 126 229 503 minecraft:sea_lantern
setblock 129 229 466 minecraft:light[level=11]
setblock 129 229 474 minecraft:light[level=11]
setblock 129 229 482 minecraft:light[level=11]
setblock 129 229 490 minecraft:light[level=11]
setblock 129 229 498 minecraft:light[level=11]
fill 104 230 465 114 230 468 minecraft:cyan_concrete
setblock 114 230 499 minecraft:deepslate_bricks
setblock 114 230 501 minecraft:deepslate_bricks
setblock 114 230 503 minecraft:deepslate_bricks
setblock 115 230 498 minecraft:deepslate_bricks
setblock 115 230 500 minecraft:deepslate_bricks
setblock 115 230 502 minecraft:deepslate_bricks
fill 115 230 504 115 273 504 minecraft:deepslate_bricks
setblock 116 230 499 minecraft:deepslate_bricks
setblock 116 230 501 minecraft:deepslate_bricks
setblock 116 230 503 minecraft:deepslate_bricks
setblock 117 230 498 minecraft:deepslate_bricks
setblock 117 230 500 minecraft:deepslate_bricks
setblock 117 230 502 minecraft:deepslate_bricks
setblock 117 230 504 minecraft:deepslate_bricks
setblock 118 230 499 minecraft:deepslate_bricks
setblock 118 230 501 minecraft:deepslate_bricks
setblock 118 230 503 minecraft:deepslate_bricks
setblock 119 230 498 minecraft:deepslate_bricks
setblock 119 230 500 minecraft:deepslate_bricks
setblock 119 230 502 minecraft:deepslate_bricks
setblock 119 230 504 minecraft:deepslate_bricks
setblock 120 230 499 minecraft:deepslate_bricks
setblock 120 230 501 minecraft:deepslate_bricks
setblock 120 230 503 minecraft:deepslate_bricks
setblock 121 230 498 minecraft:deepslate_bricks
setblock 121 230 500 minecraft:deepslate_bricks
setblock 121 230 502 minecraft:deepslate_bricks
setblock 121 230 504 minecraft:deepslate_bricks
setblock 122 230 499 minecraft:deepslate_bricks
setblock 122 230 501 minecraft:deepslate_bricks
setblock 122 230 503 minecraft:deepslate_bricks
setblock 123 230 498 minecraft:deepslate_bricks
setblock 123 230 500 minecraft:deepslate_bricks
setblock 123 230 502 minecraft:deepslate_bricks
setblock 123 230 504 minecraft:deepslate_bricks
setblock 124 230 499 minecraft:deepslate_bricks
setblock 124 230 501 minecraft:deepslate_bricks
setblock 124 230 503 minecraft:deepslate_bricks
setblock 125 230 498 minecraft:deepslate_bricks
setblock 125 230 500 minecraft:deepslate_bricks
setblock 125 230 502 minecraft:deepslate_bricks
fill 125 230 504 125 273 504 minecraft:deepslate_bricks
setblock 126 230 499 minecraft:deepslate_bricks
setblock 126 230 501 minecraft:deepslate_bricks
setblock 126 230 503 minecraft:deepslate_bricks
fill 133 230 489 135 233 491 minecraft:cyan_stained_glass
fill 105 231 466 113 231 467 minecraft:cyan_concrete
fill 115 231 499 125 231 503 minecraft:cyan_concrete
fill 131 231 490 132 233 490 minecraft:cyan_stained_glass
fill 132 231 489 132 233 489 minecraft:cyan_stained_glass
fill 132 231 491 132 233 491 minecraft:cyan_stained_glass
fill 134 231 488 134 232 488 minecraft:cyan_stained_glass
fill 134 231 492 134 232 492 minecraft:cyan_stained_glass
fill 94 232 469 94 245 469 minecraft:deepslate_tiles
fill 94 232 470 94 232 471 minecraft:sea_lantern
fill 94 232 472 94 245 472 minecraft:deepslate_tiles
fill 94 232 481 94 245 481 minecraft:deepslate_tiles
fill 94 232 482 94 232 483 minecraft:sea_lantern
fill 94 232 484 94 245 484 minecraft:deepslate_tiles
fill 94 232 493 94 245 493 minecraft:deepslate_tiles
fill 94 232 494 94 232 495 minecraft:sea_lantern
fill 94 232 496 94 245 496 minecraft:deepslate_tiles
fill 94 232 505 94 245 505 minecraft:deepslate_tiles
fill 95 232 505 96 232 505 minecraft:sea_lantern
fill 97 232 505 97 245 505 minecraft:deepslate_tiles
fill 101 232 463 101 245 463 minecraft:deepslate_tiles
fill 102 232 463 103 232 463 minecraft:sea_lantern
fill 104 232 463 104 245 463 minecraft:deepslate_tiles
fill 106 232 466 112 232 467 minecraft:cyan_concrete
fill 106 232 505 106 245 505 minecraft:deepslate_tiles
fill 107 232 505 108 232 505 minecraft:sea_lantern
fill 109 232 505 109 245 505 minecraft:deepslate_tiles
fill 113 232 463 113 245 463 minecraft:deepslate_tiles
fill 114 232 463 115 232 463 minecraft:sea_lantern
fill 114 232 464 114 233 464 minecraft:cyan_concrete
fill 116 232 463 116 245 463 minecraft:deepslate_tiles
fill 116 232 500 124 232 502 minecraft:cyan_concrete
fill 118 232 505 118 245 505 minecraft:deepslate_tiles
fill 119 232 505 120 232 505 minecraft:sea_lantern
fill 121 232 505 121 245 505 minecraft:deepslate_tiles
fill 125 232 463 125 245 463 minecraft:deepslate_tiles
fill 126 232 463 127 232 463 minecraft:sea_lantern
fill 128 232 463 128 245 463 minecraft:deepslate_tiles
fill 129 232 490 130 234 490 minecraft:cyan_stained_glass
fill 130 232 489 131 233 489 minecraft:cyan_stained_glass
fill 130 232 491 131 233 491 minecraft:cyan_stained_glass
fill 130 232 505 130 245 505 minecraft:deepslate_tiles
fill 131 232 505 132 232 505 minecraft:sea_lantern
fill 133 232 505 133 245 505 minecraft:deepslate_tiles
fill 136 232 464 136 245 464 minecraft:deepslate_tiles
fill 136 232 465 136 232 466 minecraft:sea_lantern
fill 136 232 467 136 245 467 minecraft:deepslate_tiles
fill 136 232 476 136 245 476 minecraft:deepslate_tiles
fill 136 232 477 136 232 478 minecraft:sea_lantern
fill 136 232 479 136 245 479 minecraft:deepslate_tiles
fill 136 232 488 136 245 488 minecraft:deepslate_tiles
fill 136 232 489 136 232 490 minecraft:sea_lantern
fill 136 232 491 136 245 491 minecraft:deepslate_tiles
fill 136 232 500 136 245 500 minecraft:deepslate_tiles
fill 136 232 501 136 232 502 minecraft:sea_lantern
fill 136 232 503 136 245 503 minecraft:deepslate_tiles
fill 94 233 470 94 245 471 minecraft:deepslate_tiles
fill 94 233 482 94 245 483 minecraft:deepslate_tiles
fill 94 233 494 94 245 495 minecraft:deepslate_tiles
fill 95 233 505 96 245 505 minecraft:deepslate_tiles
fill 102 233 463 103 245 463 minecraft:deepslate_tiles
fill 107 233 465 111 233 468 minecraft:cyan_concrete
fill 107 233 505 108 245 505 minecraft:deepslate_tiles
fill 114 233 463 115 245 463 minecraft:deepslate_tiles
fill 114 233 465 114 233 467 minecraft:cyan_concrete
fill 117 233 501 123 233 501 minecraft:cyan_concrete
fill 119 233 505 120 245 505 minecraft:deepslate_tiles
fill 126 233 463 127 245 463 minecraft:deepslate_tiles
fill 128 233 490 128 234 490 minecraft:cyan_stained_glass
setblock 129 233 489 minecraft:cyan_stained_glass
setblock 129 233 491 minecraft:cyan_stained_glass
fill 131 233 505 132 245 505 minecraft:deepslate_tiles
fill 136 233 465 136 245 466 minecraft:deepslate_tiles
fill 136 233 477 136 245 478 minecraft:deepslate_tiles
fill 136 233 489 136 245 490 minecraft:deepslate_tiles
fill 136 233 501 136 245 502 minecraft:deepslate_tiles
fill 114 234 466 114 234 469 minecraft:cyan_concrete
fill 118 234 500 122 234 502 minecraft:cyan_concrete
setblock 127 234 490 minecraft:cyan_stained_glass
setblock 131 234 490 minecraft:cyan_stained_glass
setblock 114 235 469 minecraft:cyan_concrete
setblock 97 237 466 minecraft:light[level=11]
setblock 97 237 474 minecraft:light[level=11]
setblock 97 237 482 minecraft:light[level=11]
setblock 97 237 490 minecraft:light[level=11]
setblock 97 237 498 minecraft:light[level=11]
setblock 105 237 466 minecraft:light[level=11]
setblock 105 237 474 minecraft:light[level=11]
setblock 105 237 482 minecraft:light[level=11]
setblock 105 237 490 minecraft:light[level=11]
setblock 105 237 498 minecraft:light[level=11]
setblock 113 237 466 minecraft:light[level=11]
setblock 113 237 474 minecraft:light[level=11]
setblock 113 237 482 minecraft:light[level=11]
setblock 113 237 490 minecraft:light[level=11]
setblock 113 237 498 minecraft:light[level=11]
setblock 121 237 466 minecraft:light[level=11]
setblock 121 237 474 minecraft:light[level=11]
setblock 121 237 482 minecraft:light[level=11]
setblock 121 237 490 minecraft:light[level=11]
setblock 121 237 498 minecraft:light[level=11]
setblock 129 237 466 minecraft:light[level=11]
setblock 129 237 474 minecraft:light[level=11]
setblock 129 237 482 minecraft:light[level=11]
setblock 129 237 490 minecraft:light[level=11]
setblock 129 237 498 minecraft:light[level=11]
fill 96 240 473 96 245 475 minecraft:deepslate_bricks
fill 96 240 485 96 245 487 minecraft:deepslate_bricks
fill 96 240 497 96 245 499 minecraft:deepslate_bricks
fill 102 240 503 104 245 503 minecraft:deepslate_bricks
fill 106 240 465 108 245 465 minecraft:deepslate_bricks
fill 114 240 503 116 245 503 minecraft:deepslate_bricks
fill 118 240 465 120 245 465 minecraft:deepslate_bricks
fill 126 240 503 128 245 503 minecraft:deepslate_bricks
fill 130 240 465 132 245 465 minecraft:deepslate_bricks
fill 134 240 473 134 245 475 minecraft:deepslate_bricks
fill 134 240 485 134 245 487 minecraft:deepslate_bricks
fill 134 240 497 134 245 499 minecraft:deepslate_bricks
fill 109 244 465 109 245 466 minecraft:cyan_concrete
fill 113 244 501 113 255 501 minecraft:reinforced_deepslate
fill 95 245 467 95 245 472 minecraft:sculk
fill 95 245 479 95 245 484 minecraft:sculk
fill 95 245 491 95 245 496 minecraft:sculk
fill 95 245 503 95 245 504 minecraft:sculk
fill 96 245 504 99 245 504 minecraft:sculk
setblock 97 245 466 minecraft:light[level=11]
setblock 97 245 474 minecraft:light[level=11]
setblock 97 245 482 minecraft:light[level=11]
setblock 97 245 490 minecraft:light[level=11]
setblock 97 245 498 minecraft:light[level=11]
fill 99 245 464 104 245 464 minecraft:sculk
setblock 105 245 466 minecraft:light[level=11]
setblock 105 245 474 minecraft:light[level=11]
setblock 105 245 482 minecraft:light[level=11]
setblock 105 245 490 minecraft:light[level=11]
setblock 105 245 498 minecraft:light[level=11]
fill 106 245 504 111 245 504 minecraft:sculk
fill 109 245 467 109 246 467 minecraft:cyan_concrete
fill 111 245 464 116 245 464 minecraft:sculk
setblock 113 245 466 minecraft:light[level=11]
setblock 113 245 474 minecraft:light[level=11]
setblock 113 245 482 minecraft:light[level=11]
setblock 113 245 490 minecraft:light[level=11]
setblock 113 245 498 minecraft:light[level=11]
fill 118 245 504 123 245 504 minecraft:sculk
setblock 121 245 466 minecraft:light[level=11]
setblock 121 245 474 minecraft:light[level=11]
setblock 121 245 482 minecraft:light[level=11]
setblock 121 245 490 minecraft:light[level=11]
setblock 121 245 498 minecraft:light[level=11]
fill 123 245 464 128 245 464 minecraft:sculk
setblock 129 245 466 minecraft:light[level=11]
setblock 129 245 474 minecraft:light[level=11]
setblock 129 245 482 minecraft:light[level=11]
setblock 129 245 490 minecraft:light[level=11]
setblock 129 245 498 minecraft:light[level=11]
fill 130 245 504 135 245 504 minecraft:sculk
fill 135 245 464 135 245 469 minecraft:sculk
fill 135 245 476 135 245 481 minecraft:sculk
fill 135 245 488 135 245 493 minecraft:sculk
fill 135 245 500 135 245 503 minecraft:sculk
fill 94 246 469 94 251 472 minecraft:sea_lantern
fill 94 246 481 94 251 484 minecraft:sea_lantern
fill 94 246 493 94 251 496 minecraft:sea_lantern
fill 94 246 505 97 251 505 minecraft:sea_lantern
fill 101 246 463 104 251 463 minecraft:sea_lantern
fill 106 246 505 109 251 505 minecraft:sea_lantern
fill 109 246 468 109 247 468 minecraft:cyan_concrete
fill 113 246 463 116 251 463 minecraft:sea_lantern
fill 118 246 505 121 251 505 minecraft:sea_lantern
fill 125 246 463 128 251 463 minecraft:sea_lantern
fill 130 246 505 133 251 505 minecraft:sea_lantern
fill 136 246 464 136 251 467 minecraft:sea_lantern
fill 136 246 476 136 251 479 minecraft:sea_lantern
fill 136 246 488 136 251 491 minecraft:sea_lantern
fill 136 246 500 136 251 503 minecraft:sea_lantern
setblock 109 247 469 minecraft:cyan_concrete
fill 119 248 465 121 250 465 minecraft:cyan_stained_glass
fill 119 249 466 121 250 466 minecraft:cyan_stained_glass
fill 120 250 467 120 251 467 minecraft:cyan_stained_glass
setblock 120 251 466 minecraft:cyan_stained_glass
fill 120 251 468 120 252 468 minecraft:cyan_stained_glass
fill 94 252 469 94 265 469 minecraft:deepslate_tiles
fill 94 252 470 94 252 471 minecraft:sea_lantern
fill 94 252 472 94 265 472 minecraft:deepslate_tiles
fill 94 252 481 94 265 481 minecraft:deepslate_tiles
fill 94 252 482 94 252 483 minecraft:sea_lantern
fill 94 252 484 94 265 484 minecraft:deepslate_tiles
fill 94 252 493 94 265 493 minecraft:deepslate_tiles
fill 94 252 494 94 252 495 minecraft:sea_lantern
fill 94 252 496 94 265 496 minecraft:deepslate_tiles
fill 94 252 505 94 265 505 minecraft:deepslate_tiles
fill 95 252 505 96 252 505 minecraft:sea_lantern
fill 97 252 505 97 265 505 minecraft:deepslate_tiles
fill 101 252 463 101 265 463 minecraft:deepslate_tiles
fill 102 252 463 103 252 463 minecraft:sea_lantern
fill 104 252 463 104 265 463 minecraft:deepslate_tiles
fill 106 252 505 106 265 505 minecraft:deepslate_tiles
fill 107 252 505 108 252 505 minecraft:sea_lantern
fill 109 252 505 109 265 505 minecraft:deepslate_tiles
fill 113 252 463 113 265 463 minecraft:deepslate_tiles
fill 114 252 463 115 252 463 minecraft:sea_lantern
fill 116 252 463 116 265 463 minecraft:deepslate_tiles
fill 118 252 505 118 265 505 minecraft:deepslate_tiles
fill 119 252 505 120 252 505 minecraft:sea_lantern
fill 121 252 505 121 265 505 minecraft:deepslate_tiles
fill 125 252 463 125 265 463 minecraft:deepslate_tiles
fill 126 252 463 127 252 463 minecraft:sea_lantern
fill 128 252 463 128 265 463 minecraft:deepslate_tiles
fill 130 252 505 130 265 505 minecraft:deepslate_tiles
fill 131 252 505 132 252 505 minecraft:sea_lantern
fill 133 252 505 133 265 505 minecraft:deepslate_tiles
fill 136 252 464 136 265 464 minecraft:deepslate_tiles
fill 136 252 465 136 252 466 minecraft:sea_lantern
fill 136 252 467 136 265 467 minecraft:deepslate_tiles
fill 136 252 476 136 265 476 minecraft:deepslate_tiles
fill 136 252 477 136 252 478 minecraft:sea_lantern
fill 136 252 479 136 265 479 minecraft:deepslate_tiles
fill 136 252 488 136 265 488 minecraft:deepslate_tiles
fill 136 252 489 136 252 490 minecraft:sea_lantern
fill 136 252 491 136 265 491 minecraft:deepslate_tiles
fill 136 252 500 136 265 500 minecraft:deepslate_tiles
fill 136 252 501 136 252 502 minecraft:sea_lantern
fill 136 252 503 136 265 503 minecraft:deepslate_tiles
fill 94 253 470 94 265 471 minecraft:deepslate_tiles
fill 94 253 482 94 265 483 minecraft:deepslate_tiles
fill 94 253 494 94 265 495 minecraft:deepslate_tiles
fill 95 253 505 96 265 505 minecraft:deepslate_tiles
setblock 97 253 466 minecraft:light[level=11]
setblock 97 253 474 minecraft:light[level=11]
setblock 97 253 482 minecraft:light[level=11]
setblock 97 253 490 minecraft:light[level=11]
setblock 97 253 498 minecraft:light[level=11]
fill 102 253 463 103 265 463 minecraft:deepslate_tiles
setblock 105 253 466 minecraft:light[level=11]
setblock 105 253 474 minecraft:light[level=11]
setblock 105 253 482 minecraft:light[level=11]
setblock 105 253 490 minecraft:light[level=11]
setblock 105 253 498 minecraft:light[level=11]
fill 107 253 505 108 265 505 minecraft:deepslate_tiles
setblock 113 253 466 minecraft:light[level=11]
setblock 113 253 474 minecraft:light[level=11]
setblock 113 253 482 minecraft:light[level=11]
setblock 113 253 490 minecraft:light[level=11]
setblock 113 253 498 minecraft:light[level=11]
fill 114 253 463 115 265 463 minecraft:deepslate_tiles
fill 119 253 505 120 265 505 minecraft:deepslate_tiles
setblock 121 253 466 minecraft:light[level=11]
setblock 121 253 474 minecraft:light[level=11]
setblock 121 253 482 minecraft:light[level=11]
setblock 121 253 490 minecraft:light[level=11]
setblock 121 253 498 minecraft:light[level=11]
fill 126 253 463 127 265 463 minecraft:deepslate_tiles
setblock 129 253 466 minecraft:light[level=11]
setblock 129 253 474 minecraft:light[level=11]
setblock 129 253 482 minecraft:light[level=11]
setblock 129 253 490 minecraft:light[level=11]
setblock 129 253 498 minecraft:light[level=11]
fill 131 253 505 132 265 505 minecraft:deepslate_tiles
fill 136 253 465 136 265 466 minecraft:deepslate_tiles
fill 136 253 477 136 265 478 minecraft:deepslate_tiles
fill 136 253 489 136 265 490 minecraft:deepslate_tiles
fill 136 253 501 136 265 502 minecraft:deepslate_tiles
fill 95 254 472 95 255 472 minecraft:cyan_concrete
fill 96 255 472 97 256 472 minecraft:cyan_concrete
fill 98 256 472 98 257 472 minecraft:cyan_concrete
fill 99 257 472 100 258 472 minecraft:cyan_concrete
fill 96 260 473 96 265 475 minecraft:deepslate_bricks
fill 96 260 485 96 265 487 minecraft:deepslate_bricks
fill 96 260 497 96 265 499 minecraft:deepslate_bricks
fill 102 260 503 104 265 503 minecraft:deepslate_bricks
fill 106 260 465 108 265 465 minecraft:deepslate_bricks
fill 114 260 503 116 265 503 minecraft:deepslate_bricks
fill 118 260 465 120 265 465 minecraft:deepslate_bricks
fill 126 260 503 128 265 503 minecraft:deepslate_bricks
fill 130 260 465 132 265 465 minecraft:deepslate_bricks
fill 134 260 473 134 265 475 minecraft:deepslate_bricks
fill 134 260 485 134 265 487 minecraft:deepslate_bricks
fill 134 260 497 134 265 499 minecraft:deepslate_bricks
setblock 97 261 466 minecraft:light[level=11]
setblock 97 261 474 minecraft:light[level=11]
setblock 97 261 482 minecraft:light[level=11]
setblock 97 261 490 minecraft:light[level=11]
setblock 97 261 498 minecraft:light[level=11]
setblock 105 261 466 minecraft:light[level=11]
setblock 105 261 474 minecraft:light[level=11]
setblock 105 261 482 minecraft:light[level=11]
setblock 105 261 490 minecraft:light[level=11]
setblock 105 261 498 minecraft:light[level=11]
setblock 113 261 466 minecraft:light[level=11]
setblock 113 261 474 minecraft:light[level=11]
setblock 113 261 482 minecraft:light[level=11]
setblock 113 261 490 minecraft:light[level=11]
setblock 113 261 498 minecraft:light[level=11]
setblock 121 261 466 minecraft:light[level=11]
setblock 121 261 474 minecraft:light[level=11]
setblock 121 261 482 minecraft:light[level=11]
setblock 121 261 490 minecraft:light[level=11]
setblock 121 261 498 minecraft:light[level=11]
setblock 129 261 466 minecraft:light[level=11]
setblock 129 261 474 minecraft:light[level=11]
setblock 129 261 482 minecraft:light[level=11]
setblock 129 261 490 minecraft:light[level=11]
setblock 129 261 498 minecraft:light[level=11]
fill 95 265 467 95 265 472 minecraft:sculk
fill 95 265 479 95 265 484 minecraft:sculk
fill 95 265 491 95 265 496 minecraft:sculk
fill 95 265 503 95 265 504 minecraft:sculk
fill 96 265 504 99 265 504 minecraft:sculk
fill 99 265 464 104 265 464 minecraft:sculk
fill 106 265 504 111 265 504 minecraft:sculk
fill 111 265 464 116 265 464 minecraft:sculk
fill 118 265 504 123 265 504 minecraft:sculk
fill 123 265 464 128 265 464 minecraft:sculk
fill 130 265 504 135 265 504 minecraft:sculk
fill 135 265 464 135 265 469 minecraft:sculk
fill 135 265 476 135 265 481 minecraft:sculk
fill 135 265 488 135 265 493 minecraft:sculk
fill 135 265 500 135 265 503 minecraft:sculk
fill 94 266 469 94 271 472 minecraft:sea_lantern
fill 94 266 481 94 271 484 minecraft:sea_lantern
fill 94 266 493 94 271 496 minecraft:sea_lantern
fill 94 266 505 97 271 505 minecraft:sea_lantern
fill 101 266 463 104 271 463 minecraft:sea_lantern
fill 106 266 505 109 271 505 minecraft:sea_lantern
fill 113 266 463 116 271 463 minecraft:sea_lantern
fill 118 266 505 121 271 505 minecraft:sea_lantern
fill 125 266 463 128 271 463 minecraft:sea_lantern
fill 130 266 505 133 271 505 minecraft:sea_lantern
fill 136 266 464 136 271 467 minecraft:sea_lantern
fill 136 266 476 136 271 479 minecraft:sea_lantern
fill 136 266 488 136 271 491 minecraft:sea_lantern
fill 136 266 500 136 271 503 minecraft:sea_lantern
setblock 97 269 466 minecraft:light[level=11]
setblock 97 269 474 minecraft:light[level=11]
setblock 97 269 482 minecraft:light[level=11]
setblock 97 269 490 minecraft:light[level=11]
setblock 97 269 498 minecraft:light[level=11]
setblock 105 269 466 minecraft:light[level=11]
setblock 105 269 474 minecraft:light[level=11]
setblock 105 269 482 minecraft:light[level=11]
setblock 105 269 490 minecraft:light[level=11]
setblock 105 269 498 minecraft:light[level=11]
setblock 113 269 466 minecraft:light[level=11]
setblock 113 269 474 minecraft:light[level=11]
setblock 113 269 482 minecraft:light[level=11]
setblock 113 269 490 minecraft:light[level=11]
setblock 113 269 498 minecraft:light[level=11]
setblock 121 269 466 minecraft:light[level=11]
setblock 121 269 474 minecraft:light[level=11]
setblock 121 269 482 minecraft:light[level=11]
setblock 121 269 490 minecraft:light[level=11]
setblock 121 269 498 minecraft:light[level=11]
setblock 129 269 466 minecraft:light[level=11]
setblock 129 269 474 minecraft:light[level=11]
setblock 129 269 482 minecraft:light[level=11]
setblock 129 269 490 minecraft:light[level=11]
setblock 129 269 498 minecraft:light[level=11]
fill 94 272 469 94 285 469 minecraft:deepslate_tiles
fill 94 272 470 94 272 471 minecraft:sea_lantern
fill 94 272 472 94 285 472 minecraft:deepslate_tiles
fill 94 272 481 94 285 481 minecraft:deepslate_tiles
fill 94 272 482 94 272 483 minecraft:sea_lantern
fill 94 272 484 94 285 484 minecraft:deepslate_tiles
fill 94 272 493 94 285 493 minecraft:deepslate_tiles
fill 94 272 494 94 272 495 minecraft:sea_lantern
fill 94 272 496 94 285 496 minecraft:deepslate_tiles
fill 94 272 505 94 285 505 minecraft:deepslate_tiles
fill 95 272 505 96 272 505 minecraft:sea_lantern
fill 97 272 505 97 285 505 minecraft:deepslate_tiles
fill 101 272 463 101 285 463 minecraft:deepslate_tiles
fill 102 272 463 103 272 463 minecraft:sea_lantern
fill 104 272 463 104 285 463 minecraft:deepslate_tiles
fill 106 272 505 106 285 505 minecraft:deepslate_tiles
fill 107 272 505 108 272 505 minecraft:sea_lantern
fill 109 272 505 109 285 505 minecraft:deepslate_tiles
fill 113 272 463 113 285 463 minecraft:deepslate_tiles
fill 114 272 463 115 272 463 minecraft:sea_lantern
fill 116 272 463 116 285 463 minecraft:deepslate_tiles
fill 118 272 505 118 285 505 minecraft:deepslate_tiles
fill 119 272 505 120 272 505 minecraft:sea_lantern
fill 121 272 505 121 285 505 minecraft:deepslate_tiles
fill 125 272 463 125 285 463 minecraft:deepslate_tiles
fill 126 272 463 127 272 463 minecraft:sea_lantern
fill 128 272 463 128 285 463 minecraft:deepslate_tiles
fill 130 272 505 130 285 505 minecraft:deepslate_tiles
fill 131 272 505 132 272 505 minecraft:sea_lantern
fill 133 272 505 133 285 505 minecraft:deepslate_tiles
fill 136 272 464 136 285 464 minecraft:deepslate_tiles
fill 136 272 465 136 272 466 minecraft:sea_lantern
fill 136 272 467 136 285 467 minecraft:deepslate_tiles
fill 136 272 476 136 285 476 minecraft:deepslate_tiles
fill 136 272 477 136 272 478 minecraft:sea_lantern
fill 136 272 479 136 285 479 minecraft:deepslate_tiles
fill 136 272 488 136 285 488 minecraft:deepslate_tiles
fill 136 272 489 136 272 490 minecraft:sea_lantern
fill 136 272 491 136 285 491 minecraft:deepslate_tiles
fill 136 272 500 136 285 500 minecraft:deepslate_tiles
fill 136 272 501 136 272 502 minecraft:sea_lantern
fill 136 272 503 136 285 503 minecraft:deepslate_tiles
fill 94 273 470 94 285 471 minecraft:deepslate_tiles
fill 94 273 482 94 285 483 minecraft:deepslate_tiles
fill 94 273 494 94 285 495 minecraft:deepslate_tiles
fill 95 273 505 96 285 505 minecraft:deepslate_tiles
fill 102 273 463 103 285 463 minecraft:deepslate_tiles
fill 107 273 505 108 285 505 minecraft:deepslate_tiles
fill 114 273 463 115 285 463 minecraft:deepslate_tiles
fill 119 273 505 120 285 505 minecraft:deepslate_tiles
fill 126 273 463 127 285 463 minecraft:deepslate_tiles
fill 131 273 505 132 285 505 minecraft:deepslate_tiles
fill 136 273 465 136 285 466 minecraft:deepslate_tiles
fill 136 273 477 136 285 478 minecraft:deepslate_tiles
fill 136 273 489 136 285 490 minecraft:deepslate_tiles
fill 136 273 501 136 285 502 minecraft:deepslate_tiles
setblock 97 277 466 minecraft:light[level=11]
setblock 97 277 474 minecraft:light[level=11]
setblock 97 277 482 minecraft:light[level=11]
setblock 97 277 490 minecraft:light[level=11]
setblock 97 277 498 minecraft:light[level=11]
setblock 105 277 466 minecraft:light[level=11]
setblock 105 277 474 minecraft:light[level=11]
setblock 105 277 482 minecraft:light[level=11]
setblock 105 277 490 minecraft:light[level=11]
setblock 105 277 498 minecraft:light[level=11]
setblock 113 277 466 minecraft:light[level=11]
setblock 113 277 474 minecraft:light[level=11]
setblock 113 277 482 minecraft:light[level=11]
setblock 113 277 490 minecraft:light[level=11]
setblock 113 277 498 minecraft:light[level=11]
setblock 121 277 466 minecraft:light[level=11]
setblock 121 277 474 minecraft:light[level=11]
setblock 121 277 482 minecraft:light[level=11]
setblock 121 277 490 minecraft:light[level=11]
setblock 121 277 498 minecraft:light[level=11]
setblock 129 277 466 minecraft:light[level=11]
setblock 129 277 474 minecraft:light[level=11]
setblock 129 277 482 minecraft:light[level=11]
setblock 129 277 490 minecraft:light[level=11]
setblock 129 277 498 minecraft:light[level=11]
fill 103 279 476 104 279 496 minecraft:reinforced_deepslate
fill 105 279 476 123 279 477 minecraft:reinforced_deepslate
fill 105 279 478 110 279 494 minecraft:sculk
fill 105 279 495 123 279 496 minecraft:reinforced_deepslate
fill 111 279 478 111 279 485 minecraft:sculk
fill 111 279 487 111 279 494 minecraft:sculk
fill 112 279 478 112 279 484 minecraft:sculk
fill 112 279 488 112 279 494 minecraft:sculk
fill 113 279 478 121 279 483 minecraft:sculk
fill 113 279 489 121 279 494 minecraft:sculk
fill 114 279 484 121 279 484 minecraft:sculk
fill 114 279 488 121 279 488 minecraft:sculk
fill 115 279 485 121 279 485 minecraft:sculk
fill 115 279 487 121 279 487 minecraft:sculk
fill 116 279 486 121 279 486 minecraft:sculk
fill 122 279 478 123 279 494 minecraft:reinforced_deepslate
fill 95 280 464 102 280 504 minecraft:deepslate_tiles
fill 103 280 464 135 280 475 minecraft:deepslate_tiles
fill 103 280 476 103 280 477 minecraft:reinforced_deepslate
setblock 103 280 478 minecraft:sea_lantern
fill 103 280 479 103 280 481 minecraft:reinforced_deepslate
setblock 103 280 482 minecraft:sea_lantern
fill 103 280 483 103 280 485 minecraft:reinforced_deepslate
setblock 103 280 486 minecraft:sea_lantern
fill 103 280 487 103 280 489 minecraft:reinforced_deepslate
setblock 103 280 490 minecraft:sea_lantern
fill 103 280 491 103 280 493 minecraft:reinforced_deepslate
setblock 103 280 494 minecraft:sea_lantern
fill 103 280 495 104 280 496 minecraft:reinforced_deepslate
fill 103 280 497 135 280 504 minecraft:deepslate_tiles
fill 104 280 476 104 284 476 minecraft:reinforced_deepslate
setblock 104 280 477 minecraft:sea_lantern
fill 104 280 478 104 280 480 minecraft:reinforced_deepslate
setblock 104 280 481 minecraft:sea_lantern
fill 104 280 482 104 280 484 minecraft:reinforced_deepslate
setblock 104 280 485 minecraft:sea_lantern
fill 104 280 486 104 280 488 minecraft:reinforced_deepslate
setblock 104 280 489 minecraft:sea_lantern
fill 104 280 490 104 280 492 minecraft:reinforced_deepslate
setblock 104 280 493 minecraft:sea_lantern
fill 104 280 494 104 284 494 minecraft:reinforced_deepslate
setblock 105 280 476 minecraft:sea_lantern
fill 105 280 477 107 280 477 minecraft:reinforced_deepslate
fill 105 280 478 109 280 494 minecraft:sculk
fill 105 280 495 105 284 495 minecraft:reinforced_deepslate
setblock 105 280 496 minecraft:sea_lantern
fill 106 280 476 108 280 476 minecraft:reinforced_deepslate
setblock 106 280 495 minecraft:sea_lantern
fill 106 280 496 108 280 496 minecraft:reinforced_deepslate
fill 107 280 495 109 280 495 minecraft:reinforced_deepslate
setblock 108 280 477 minecraft:sea_lantern
setblock 109 280 476 minecraft:sea_lantern
fill 109 280 477 111 280 477 minecraft:reinforced_deepslate
setblock 109 280 496 minecraft:sea_lantern
fill 110 280 476 112 280 476 minecraft:reinforced_deepslate
fill 110 280 478 110 280 484 minecraft:sculk
fill 110 280 485 110 280 487 minecraft:sea_lantern
fill 110 280 488 110 280 494 minecraft:sculk
setblock 110 280 495 minecraft:sea_lantern
fill 110 280 496 112 280 496 minecraft:reinforced_deepslate
fill 111 280 478 111 280 483 minecraft:sculk
fill 111 280 484 111 280 485 minecraft:sea_lantern
fill 111 280 487 111 280 488 minecraft:sea_lantern
fill 111 280 489 111 280 494 minecraft:sculk
fill 111 280 495 113 280 495 minecraft:reinforced_deepslate
setblock 112 280 477 minecraft:sea_lantern
fill 112 280 478 121 280 482 minecraft:sculk
fill 112 280 483 112 280 484 minecraft:sea_lantern
fill 112 280 488 112 280 489 minecraft:sea_lantern
fill 112 280 490 121 280 494 minecraft:sculk
setblock 113 280 476 minecraft:sea_lantern
fill 113 280 477 115 280 477 minecraft:reinforced_deepslate
fill 113 280 483 114 280 483 minecraft:sea_lantern
fill 113 280 489 114 280 489 minecraft:sea_lantern
setblock 113 280 496 minecraft:sea_lantern
fill 114 280 476 116 280 476 minecraft:reinforced_deepslate
fill 114 280 484 115 280 484 minecraft:sea_lantern
fill 114 280 488 115 280 488 minecraft:sea_lantern
setblock 114 280 495 minecraft:sea_lantern
fill 114 280 496 116 280 496 minecraft:reinforced_deepslate
fill 115 280 483 121 280 483 minecraft:sculk
fill 115 280 485 116 280 485 minecraft:sea_lantern
fill 115 280 487 116 280 487 minecraft:sea_lantern
fill 115 280 489 121 280 489 minecraft:sculk
fill 115 280 495 117 280 495 minecraft:reinforced_deepslate
setblock 116 280 477 minecraft:sea_lantern
fill 116 280 484 121 280 484 minecraft:sculk
setblock 116 280 486 minecraft:sea_lantern
fill 116 280 488 121 280 488 minecraft:sculk
setblock 117 280 476 minecraft:sea_lantern
fill 117 280 477 119 280 477 minecraft:reinforced_deepslate
fill 117 280 485 121 280 487 minecraft:sculk
setblock 117 280 496 minecraft:sea_lantern
fill 118 280 476 120 280 476 minecraft:reinforced_deepslate
setblock 118 280 495 minecraft:sea_lantern
fill 118 280 496 120 280 496 minecraft:reinforced_deepslate
fill 119 280 495 121 280 495 minecraft:reinforced_deepslate
setblock 120 280 477 minecraft:sea_lantern
setblock 121 280 476 minecraft:sea_lantern
fill 121 280 477 123 284 477 minecraft:reinforced_deepslate
setblock 121 280 496 minecraft:sea_lantern
fill 122 280 476 123 280 476 minecraft:reinforced_deepslate
fill 122 280 478 122 284 478 minecraft:reinforced_deepslate
setblock 122 280 479 minecraft:sea_lantern
fill 122 280 480 122 280 482 minecraft:reinforced_deepslate
setblock 122 280 483 minecraft:sea_lantern
fill 122 280 484 122 280 486 minecraft:reinforced_deepslate
setblock 122 280 487 minecraft:sea_lantern
fill 122 280 488 122 280 490 minecraft:reinforced_deepslate
setblock 122 280 491 minecraft:sea_lantern
fill 122 280 492 122 280 494 minecraft:reinforced_deepslate
setblock 122 280 495 minecraft:sea_lantern
fill 122 280 496 123 280 496 minecraft:reinforced_deepslate
setblock 123 280 478 minecraft:sea_lantern
fill 123 280 479 123 280 481 minecraft:reinforced_deepslate
setblock 123 280 482 minecraft:sea_lantern
fill 123 280 483 123 280 485 minecraft:reinforced_deepslate
setblock 123 280 486 minecraft:sea_lantern
fill 123 280 487 123 280 489 minecraft:reinforced_deepslate
setblock 123 280 490 minecraft:sea_lantern
fill 123 280 491 123 280 493 minecraft:reinforced_deepslate
setblock 123 280 494 minecraft:sea_lantern
fill 123 280 495 123 284 495 minecraft:reinforced_deepslate
fill 124 280 476 135 280 496 minecraft:deepslate_tiles
fill 103 281 477 105 284 477 minecraft:reinforced_deepslate
fill 103 281 495 104 284 495 minecraft:reinforced_deepslate
fill 104 281 478 104 284 478 minecraft:reinforced_deepslate
fill 104 281 496 104 284 496 minecraft:reinforced_deepslate
fill 121 281 495 122 284 495 minecraft:reinforced_deepslate
fill 122 281 476 122 284 476 minecraft:reinforced_deepslate
fill 122 281 494 122 284 494 minecraft:reinforced_deepslate
fill 122 281 496 122 284 496 minecraft:reinforced_deepslate
fill 95 284 464 97 300 464 minecraft:deepslate_bricks
fill 95 284 474 95 300 476 minecraft:deepslate_bricks
fill 95 284 481 102 284 489 minecraft:deepslate_bricks
fill 95 284 498 95 300 500 minecraft:deepslate_bricks
fill 96 284 473 96 285 475 minecraft:deepslate_bricks
fill 96 284 497 96 285 499 minecraft:deepslate_bricks
fill 101 284 494 102 285 504 minecraft:deepslate_bricks
fill 103 284 494 103 285 494 minecraft:deepslate_bricks
fill 103 284 496 103 285 504 minecraft:deepslate_bricks
fill 104 284 497 111 284 504 minecraft:deepslate_bricks
fill 105 284 494 111 285 494 minecraft:deepslate_bricks
fill 105 284 496 111 285 496 minecraft:deepslate_bricks
fill 106 284 465 108 285 465 minecraft:deepslate_bricks
fill 106 284 495 111 285 495 minecraft:deepslate_bricks
fill 107 284 464 109 300 464 minecraft:deepslate_bricks
fill 111 284 468 111 285 469 minecraft:cyan_concrete
fill 113 284 504 127 284 504 minecraft:deepslate_bricks
fill 114 284 503 128 285 503 minecraft:deepslate_bricks
fill 115 284 498 125 285 502 minecraft:deepslate_bricks
fill 118 284 465 120 285 465 minecraft:deepslate_bricks
fill 119 284 464 121 300 464 minecraft:deepslate_bricks
fill 129 284 487 130 285 489 minecraft:deepslate_bricks
fill 130 284 465 132 285 465 minecraft:deepslate_bricks
fill 131 284 464 133 300 464 minecraft:deepslate_bricks
fill 131 284 487 131 287 488 minecraft:deepslate_bricks
fill 134 284 473 134 285 475 minecraft:deepslate_bricks
fill 134 284 485 134 285 487 minecraft:deepslate_bricks
fill 134 284 497 134 285 499 minecraft:deepslate_bricks
fill 135 284 472 135 300 474 minecraft:deepslate_bricks
fill 135 284 484 135 300 486 minecraft:deepslate_bricks
fill 135 284 496 135 300 498 minecraft:deepslate_bricks
fill 95 285 467 95 285 472 minecraft:sculk
fill 95 285 479 95 285 484 minecraft:sculk
fill 95 285 485 102 285 489 minecraft:deepslate_bricks
fill 95 285 491 95 285 496 minecraft:sculk
fill 95 285 503 95 285 504 minecraft:sculk
fill 96 285 481 102 285 484 minecraft:deepslate_bricks
fill 96 285 504 99 285 504 minecraft:sculk
setblock 97 285 466 minecraft:light[level=11]
setblock 97 285 474 minecraft:light[level=11]
setblock 97 285 490 minecraft:light[level=11]
setblock 97 285 498 minecraft:light[level=11]
fill 99 285 464 104 285 464 minecraft:sculk
fill 103 285 495 105 285 495 minecraft:deepslate_bricks
fill 104 285 494 104 298 494 minecraft:deepslate_bricks
fill 104 285 496 104 285 504 minecraft:deepslate_bricks
setblock 105 285 466 minecraft:light[level=11]
setblock 105 285 474 minecraft:light[level=11]
setblock 105 285 482 minecraft:light[level=11]
setblock 105 285 490 minecraft:light[level=11]
fill 105 285 497 105 285 504 minecraft:deepslate_bricks
fill 106 285 497 111 285 503 minecraft:deepslate_bricks
fill 106 285 504 111 285 504 minecraft:sculk
fill 111 285 464 116 285 464 minecraft:sculk
fill 111 285 467 111 286 467 minecraft:cyan_concrete
setblock 113 285 466 minecraft:light[level=11]
setblock 113 285 474 minecraft:light[level=11]
setblock 113 285 482 minecraft:light[level=11]
setblock 113 285 490 minecraft:light[level=11]
setblock 113 285 498 minecraft:light[level=11]
fill 113 285 504 117 285 504 minecraft:deepslate_bricks
fill 118 285 504 123 285 504 minecraft:sculk
setblock 121 285 466 minecraft:light[level=11]
setblock 121 285 474 minecraft:light[level=11]
setblock 121 285 482 minecraft:light[level=11]
setblock 121 285 490 minecraft:light[level=11]
fill 123 285 464 128 285 464 minecraft:sculk
fill 124 285 504 127 285 504 minecraft:deepslate_bricks
fill 125 285 486 128 300 488 minecraft:deepslate_bricks
fill 126 285 489 127 300 489 minecraft:deepslate_bricks
fill 128 285 489 128 287 489 minecraft:sculk
setblock 129 285 466 minecraft:light[level=11]
setblock 129 285 474 minecraft:light[level=11]
setblock 129 285 482 minecraft:light[level=11]
fill 129 285 486 130 287 486 minecraft:sculk
setblock 129 285 490 minecraft:light[level=11]
setblock 129 285 498 minecraft:light[level=11]
fill 130 285 504 135 285 504 minecraft:sculk
fill 131 285 489 131 286 489 minecraft:sculk
fill 135 285 464 135 285 469 minecraft:sculk
fill 135 285 476 135 285 481 minecraft:sculk
fill 135 285 488 135 285 493 minecraft:sculk
fill 135 285 500 135 285 503 minecraft:sculk
fill 94 286 469 94 291 472 minecraft:sea_lantern
fill 94 286 481 94 291 484 minecraft:sea_lantern
fill 94 286 493 94 291 496 minecraft:sea_lantern
fill 94 286 505 97 291 505 minecraft:sea_lantern
fill 95 286 481 95 300 481 minecraft:deepslate_bricks
setblock 95 286 482 minecraft:sea_lantern
fill 95 286 483 95 300 483 minecraft:deepslate_bricks
setblock 95 286 484 minecraft:sea_lantern
fill 95 286 485 95 291 485 minecraft:deepslate_bricks
setblock 95 286 486 minecraft:sea_lantern
fill 95 286 487 95 300 487 minecraft:deepslate_bricks
setblock 95 286 488 minecraft:sea_lantern
fill 95 286 489 95 300 489 minecraft:deepslate_bricks
setblock 96 286 481 minecraft:sea_lantern
fill 96 286 482 96 300 482 minecraft:deepslate_bricks
setblock 96 286 483 minecraft:sea_lantern
fill 96 286 484 96 300 484 minecraft:deepslate_bricks
setblock 96 286 485 minecraft:sea_lantern
fill 96 286 486 96 300 486 minecraft:deepslate_bricks
setblock 96 286 487 minecraft:sea_lantern
fill 96 286 488 96 300 488 minecraft:deepslate_bricks
setblock 96 286 489 minecraft:sea_lantern
fill 97 286 481 97 300 481 minecraft:deepslate_bricks
setblock 97 286 482 minecraft:sea_lantern
fill 97 286 483 97 300 483 minecraft:deepslate_bricks
setblock 97 286 484 minecraft:sea_lantern
fill 97 286 485 97 291 485 minecraft:deepslate_bricks
setblock 97 286 486 minecraft:sea_lantern
fill 97 286 487 97 300 487 minecraft:deepslate_bricks
setblock 97 286 488 minecraft:sea_lantern
fill 97 286 489 97 300 489 minecraft:deepslate_bricks
setblock 98 286 481 minecraft:sea_lantern
fill 98 286 482 98 300 482 minecraft:deepslate_bricks
setblock 98 286 483 minecraft:sea_lantern
fill 98 286 484 98 300 484 minecraft:deepslate_bricks
setblock 98 286 485 minecraft:sea_lantern
fill 98 286 486 98 300 486 minecraft:deepslate_bricks
setblock 98 286 487 minecraft:sea_lantern
fill 98 286 488 98 300 488 minecraft:deepslate_bricks
setblock 98 286 489 minecraft:sea_lantern
fill 99 286 481 99 300 481 minecraft:deepslate_bricks
setblock 99 286 482 minecraft:sea_lantern
fill 99 286 483 99 300 483 minecraft:deepslate_bricks
setblock 99 286 484 minecraft:sea_lantern
fill 99 286 485 99 290 485 minecraft:deepslate_bricks
setblock 99 286 486 minecraft:sea_lantern
fill 99 286 487 99 300 487 minecraft:deepslate_bricks
setblock 99 286 488 minecraft:sea_lantern
fill 99 286 489 99 300 489 minecraft:deepslate_bricks
setblock 100 286 481 minecraft:sea_lantern
fill 100 286 482 100 300 482 minecraft:deepslate_bricks
setblock 100 286 483 minecraft:sea_lantern
fill 100 286 484 100 300 484 minecraft:deepslate_bricks
setblock 100 286 485 minecraft:sea_lantern
fill 100 286 486 100 300 486 minecraft:deepslate_bricks
setblock 100 286 487 minecraft:sea_lantern
fill 100 286 488 100 300 488 minecraft:deepslate_bricks
setblock 100 286 489 minecraft:sea_lantern
fill 101 286 463 104 291 463 minecraft:sea_lantern
fill 101 286 481 101 300 481 minecraft:deepslate_bricks
setblock 101 286 482 minecraft:sea_lantern
fill 101 286 483 101 300 483 minecraft:deepslate_bricks
setblock 101 286 484 minecraft:sea_lantern
fill 101 286 485 101 300 485 minecraft:deepslate_bricks
setblock 101 286 486 minecraft:sea_lantern
fill 101 286 487 101 300 487 minecraft:deepslate_bricks
setblock 101 286 488 minecraft:sea_lantern
fill 101 286 489 101 300 489 minecraft:deepslate_bricks
setblock 101 286 494 minecraft:sea_lantern
fill 101 286 495 101 298 495 minecraft:deepslate_bricks
setblock 101 286 496 minecraft:sea_lantern
fill 101 286 497 101 298 497 minecraft:deepslate_bricks
setblock 101 286 498 minecraft:sea_lantern
fill 101 286 499 101 298 499 minecraft:deepslate_bricks
setblock 101 286 500 minecraft:sea_lantern
fill 101 286 501 101 298 501 minecraft:deepslate_bricks
setblock 101 286 502 minecraft:sea_lantern
fill 101 286 503 101 298 503 minecraft:deepslate_bricks
setblock 101 286 504 minecraft:sea_lantern
setblock 102 286 481 minecraft:sea_lantern
fill 102 286 482 102 300 482 minecraft:deepslate_bricks
setblock 102 286 483 minecraft:sea_lantern
fill 102 286 484 102 300 484 minecraft:deepslate_bricks
setblock 102 286 485 minecraft:sea_lantern
fill 102 286 486 102 300 486 minecraft:deepslate_bricks
setblock 102 286 487 minecraft:sea_lantern
fill 102 286 488 102 300 488 minecraft:deepslate_bricks
setblock 102 286 489 minecraft:sea_lantern
fill 102 286 494 102 298 494 minecraft:deepslate_bricks
setblock 102 286 495 minecraft:sea_lantern
fill 102 286 496 102 298 496 minecraft:deepslate_bricks
setblock 102 286 497 minecraft:sea_lantern
fill 102 286 498 102 298 498 minecraft:deepslate_bricks
setblock 102 286 499 minecraft:sea_lantern
fill 102 286 500 102 298 500 minecraft:deepslate_bricks
setblock 102 286 501 minecraft:sea_lantern
fill 102 286 502 102 298 502 minecraft:deepslate_bricks
setblock 102 286 503 minecraft:sea_lantern
fill 102 286 504 102 300 504 minecraft:deepslate_bricks
setblock 103 286 494 minecraft:sea_lantern
fill 103 286 495 103 298 495 minecraft:deepslate_bricks
setblock 103 286 496 minecraft:sea_lantern
fill 103 286 497 103 298 497 minecraft:deepslate_bricks
setblock 103 286 498 minecraft:sea_lantern
fill 103 286 499 103 298 499 minecraft:deepslate_bricks
setblock 103 286 500 minecraft:sea_lantern
fill 103 286 501 103 298 501 minecraft:deepslate_bricks
setblock 103 286 502 minecraft:sea_lantern
fill 103 286 503 103 298 503 minecraft:deepslate_bricks
setblock 103 286 504 minecraft:sea_lantern
setblock 104 286 495 minecraft:sea_lantern
fill 104 286 496 104 298 496 minecraft:deepslate_bricks
setblock 104 286 497 minecraft:sea_lantern
fill 104 286 498 104 298 498 minecraft:deepslate_bricks
setblock 104 286 499 minecraft:sea_lantern
fill 104 286 500 104 298 500 minecraft:deepslate_bricks
setblock 104 286 501 minecraft:sea_lantern
fill 104 286 502 104 298 502 minecraft:deepslate_bricks
setblock 104 286 503 minecraft:sea_lantern
fill 104 286 504 104 298 504 minecraft:deepslate_bricks
setblock 105 286 494 minecraft:sea_lantern
fill 105 286 495 105 298 495 minecraft:deepslate_bricks
setblock 105 286 496 minecraft:sea_lantern
fill 105 286 497 105 298 497 minecraft:deepslate_bricks
setblock 105 286 498 minecraft:sea_lantern
fill 105 286 499 105 298 499 minecraft:deepslate_bricks
setblock 105 286 500 minecraft:sea_lantern
fill 105 286 501 105 298 501 minecraft:deepslate_bricks
setblock 105 286 502 minecraft:sea_lantern
fill 105 286 503 105 298 503 minecraft:deepslate_bricks
setblock 105 286 504 minecraft:sea_lantern
fill 106 286 494 106 298 494 minecraft:deepslate_bricks
setblock 106 286 495 minecraft:sea_lantern
fill 106 286 496 106 298 496 minecraft:deepslate_bricks
setblock 106 286 497 minecraft:sea_lantern
fill 106 286 498 106 298 498 minecraft:deepslate_bricks
setblock 106 286 499 minecraft:sea_lantern
fill 106 286 500 106 298 500 minecraft:deepslate_bricks
setblock 106 286 501 minecraft:sea_lantern
fill 106 286 502 106 298 502 minecraft:deepslate_bricks
setblock 106 286 503 minecraft:sea_lantern
fill 106 286 504 106 298 504 minecraft:deepslate_bricks
fill 106 286 505 109 291 505 minecraft:sea_lantern
setblock 107 286 494 minecraft:sea_lantern
fill 107 286 495 107 298 495 minecraft:deepslate_bricks
setblock 107 286 496 minecraft:sea_lantern
fill 107 286 497 107 298 497 minecraft:deepslate_bricks
setblock 107 286 498 minecraft:sea_lantern
fill 107 286 499 107 298 499 minecraft:deepslate_bricks
setblock 107 286 500 minecraft:sea_lantern
fill 107 286 501 107 298 501 minecraft:deepslate_bricks
setblock 107 286 502 minecraft:sea_lantern
fill 107 286 503 107 298 503 minecraft:deepslate_bricks
setblock 107 286 504 minecraft:sea_lantern
fill 108 286 494 108 298 494 minecraft:deepslate_bricks
setblock 108 286 495 minecraft:sea_lantern
fill 108 286 496 108 298 496 minecraft:deepslate_bricks
setblock 108 286 497 minecraft:sea_lantern
fill 108 286 498 108 298 498 minecraft:deepslate_bricks
setblock 108 286 499 minecraft:sea_lantern
fill 108 286 500 108 298 500 minecraft:deepslate_bricks
setblock 108 286 501 minecraft:sea_lantern
fill 108 286 502 108 298 502 minecraft:deepslate_bricks
setblock 108 286 503 minecraft:sea_lantern
fill 108 286 504 108 298 504 minecraft:deepslate_bricks
setblock 109 286 494 minecraft:sea_lantern
fill 109 286 495 109 298 495 minecraft:deepslate_bricks
setblock 109 286 496 minecraft:sea_lantern
fill 109 286 497 109 298 497 minecraft:deepslate_bricks
setblock 109 286 498 minecraft:sea_lantern
fill 109 286 499 109 298 499 minecraft:deepslate_bricks
setblock 109 286 500 minecraft:sea_lantern
fill 109 286 501 109 298 501 minecraft:deepslate_bricks
setblock 109 286 502 minecraft:sea_lantern
fill 109 286 503 109 298 503 minecraft:deepslate_bricks
setblock 109 286 504 minecraft:sea_lantern
fill 110 286 494 110 298 494 minecraft:deepslate_bricks
setblock 110 286 495 minecraft:sea_lantern
fill 110 286 496 110 298 496 minecraft:deepslate_bricks
setblock 110 286 497 minecraft:sea_lantern
fill 110 286 498 110 298 498 minecraft:deepslate_bricks
setblock 110 286 499 minecraft:sea_lantern
fill 110 286 500 110 298 500 minecraft:deepslate_bricks
setblock 110 286 501 minecraft:sea_lantern
fill 110 286 502 110 298 502 minecraft:deepslate_bricks
setblock 110 286 503 minecraft:sea_lantern
fill 110 286 504 110 298 504 minecraft:deepslate_bricks
fill 111 286 465 111 287 466 minecraft:cyan_concrete
setblock 111 286 494 minecraft:sea_lantern
fill 111 286 495 111 298 495 minecraft:deepslate_bricks
setblock 111 286 496 minecraft:sea_lantern
fill 111 286 497 111 298 497 minecraft:deepslate_bricks
setblock 111 286 498 minecraft:sea_lantern
fill 111 286 499 111 298 499 minecraft:deepslate_bricks
setblock 111 286 500 minecraft:sea_lantern
fill 111 286 501 111 298 501 minecraft:deepslate_bricks
setblock 111 286 502 minecraft:sea_lantern
fill 111 286 503 111 298 503 minecraft:deepslate_bricks
setblock 111 286 504 minecraft:sea_lantern
fill 113 286 463 116 291 463 minecraft:sea_lantern
fill 113 286 504 114 300 504 minecraft:deepslate_bricks
setblock 115 286 498 minecraft:sea_lantern
fill 115 286 499 115 300 499 minecraft:deepslate_bricks
setblock 115 286 500 minecraft:sea_lantern
fill 115 286 501 115 300 501 minecraft:deepslate_bricks
setblock 115 286 502 minecraft:sea_lantern
fill 115 286 503 115 300 503 minecraft:deepslate_bricks
setblock 115 286 504 minecraft:sea_lantern
fill 116 286 498 116 300 498 minecraft:deepslate_bricks
setblock 116 286 499 minecraft:sea_lantern
fill 116 286 500 116 300 500 minecraft:deepslate_bricks
setblock 116 286 501 minecraft:sea_lantern
fill 116 286 502 116 300 502 minecraft:deepslate_bricks
setblock 116 286 503 minecraft:sea_lantern
fill 116 286 504 116 300 504 minecraft:deepslate_bricks
setblock 117 286 498 minecraft:sea_lantern
fill 117 286 499 117 300 499 minecraft:deepslate_bricks
setblock 117 286 500 minecraft:sea_lantern
fill 117 286 501 117 300 501 minecraft:deepslate_bricks
setblock 117 286 502 minecraft:sea_lantern
fill 117 286 503 117 300 503 minecraft:deepslate_bricks
setblock 117 286 504 minecraft:sea_lantern
fill 118 286 498 118 300 498 minecraft:deepslate_bricks
setblock 118 286 499 minecraft:sea_lantern
fill 118 286 500 118 300 500 minecraft:deepslate_bricks
setblock 118 286 501 minecraft:sea_lantern
fill 118 286 502 118 300 502 minecraft:deepslate_bricks
setblock 118 286 503 minecraft:sea_lantern
fill 118 286 504 118 300 504 minecraft:deepslate_bricks
fill 118 286 505 121 291 505 minecraft:sea_lantern
setblock 119 286 498 minecraft:sea_lantern
fill 119 286 499 119 300 499 minecraft:deepslate_bricks
setblock 119 286 500 minecraft:sea_lantern
fill 119 286 501 119 300 501 minecraft:deepslate_bricks
setblock 119 286 502 minecraft:sea_lantern
fill 119 286 503 119 300 503 minecraft:deepslate_bricks
setblock 119 286 504 minecraft:sea_lantern
fill 120 286 498 120 300 498 minecraft:deepslate_bricks
setblock 120 286 499 minecraft:sea_lantern
fill 120 286 500 120 300 500 minecraft:deepslate_bricks
setblock 120 286 501 minecraft:sea_lantern
fill 120 286 502 120 300 502 minecraft:deepslate_bricks
setblock 120 286 503 minecraft:sea_lantern
fill 120 286 504 120 300 504 minecraft:deepslate_bricks
setblock 121 286 498 minecraft:sea_lantern
fill 121 286 499 121 300 499 minecraft:deepslate_bricks
setblock 121 286 500 minecraft:sea_lantern
fill 121 286 501 121 300 501 minecraft:deepslate_bricks
setblock 121 286 502 minecraft:sea_lantern
fill 121 286 503 121 300 503 minecraft:deepslate_bricks
setblock 121 286 504 minecraft:sea_lantern
fill 122 286 498 122 300 498 minecraft:deepslate_bricks
setblock 122 286 499 minecraft:sea_lantern
fill 122 286 500 122 300 500 minecraft:deepslate_bricks
setblock 122 286 501 minecraft:sea_lantern
fill 122 286 502 122 300 502 minecraft:deepslate_bricks
setblock 122 286 503 minecraft:sea_lantern
fill 122 286 504 122 300 504 minecraft:deepslate_bricks
setblock 123 286 498 minecraft:sea_lantern
fill 123 286 499 123 300 499 minecraft:deepslate_bricks
setblock 123 286 500 minecraft:sea_lantern
fill 123 286 501 123 300 501 minecraft:deepslate_bricks
setblock 123 286 502 minecraft:sea_lantern
fill 123 286 503 123 300 503 minecraft:deepslate_bricks
setblock 123 286 504 minecraft:sea_lantern
fill 124 286 486 124 287 488 minecraft:sculk
fill 124 286 498 124 300 498 minecraft:deepslate_bricks
setblock 124 286 499 minecraft:sea_lantern
fill 124 286 500 124 300 500 minecraft:deepslate_bricks
setblock 124 286 501 minecraft:sea_lantern
fill 124 286 502 124 300 502 minecraft:deepslate_bricks
setblock 124 286 503 minecraft:sea_lantern
fill 124 286 504 124 300 504 minecraft:deepslate_bricks
fill 125 286 463 128 291 463 minecraft:sea_lantern
fill 125 286 485 128 287 485 minecraft:sculk
fill 125 286 489 125 287 489 minecraft:sculk
setblock 125 286 498 minecraft:sea_lantern
fill 125 286 499 125 300 499 minecraft:deepslate_bricks
setblock 125 286 500 minecraft:sea_lantern
fill 125 286 501 125 300 501 minecraft:deepslate_bricks
setblock 125 286 502 minecraft:sea_lantern
fill 125 286 503 125 300 503 minecraft:deepslate_bricks
setblock 125 286 504 minecraft:sea_lantern
fill 126 286 504 127 300 504 minecraft:deepslate_bricks
fill 129 286 487 129 287 488 minecraft:sculk
fill 129 286 489 130 286 489 minecraft:deepslate_bricks
fill 129 286 490 131 286 490 minecraft:sculk
setblock 130 286 485 minecraft:sculk
fill 130 286 487 130 286 488 minecraft:deepslate_bricks
fill 130 286 505 133 291 505 minecraft:sea_lantern
setblock 131 286 486 minecraft:sculk
fill 132 286 487 132 286 489 minecraft:sculk
fill 136 286 464 136 291 467 minecraft:sea_lantern
fill 136 286 476 136 291 479 minecraft:sea_lantern
fill 136 286 488 136 291 491 minecraft:sea_lantern
fill 136 286 500 136 291 503 minecraft:sea_lantern
fill 95 287 482 95 288 482 minecraft:deepslate_bricks
fill 95 287 484 95 288 484 minecraft:deepslate_bricks
fill 95 287 486 95 288 486 minecraft:deepslate_bricks
fill 95 287 488 95 288 488 minecraft:deepslate_bricks
fill 96 287 481 96 288 481 minecraft:deepslate_bricks
fill 96 287 483 96 288 483 minecraft:deepslate_bricks
fill 96 287 485 96 288 485 minecraft:deepslate_bricks
fill 96 287 487 96 288 487 minecraft:deepslate_bricks
fill 96 287 489 96 288 489 minecraft:deepslate_bricks
fill 97 287 482 97 288 482 minecraft:deepslate_bricks
fill 97 287 484 97 288 484 minecraft:deepslate_bricks
fill 97 287 486 97 288 486 minecraft:deepslate_bricks
fill 97 287 488 97 288 488 minecraft:deepslate_bricks
fill 98 287 481 98 288 481 minecraft:deepslate_bricks
fill 98 287 483 98 288 483 minecraft:deepslate_bricks
fill 98 287 485 98 288 485 minecraft:deepslate_bricks
fill 98 287 487 98 288 487 minecraft:deepslate_bricks
fill 98 287 489 98 288 489 minecraft:deepslate_bricks
fill 99 287 482 99 288 482 minecraft:deepslate_bricks
fill 99 287 484 99 288 484 minecraft:deepslate_bricks
fill 99 287 486 99 288 486 minecraft:deepslate_bricks
fill 99 287 488 99 288 488 minecraft:deepslate_bricks
fill 100 287 481 100 288 481 minecraft:deepslate_bricks
fill 100 287 483 100 288 483 minecraft:deepslate_bricks
fill 100 287 485 100 288 485 minecraft:deepslate_bricks
fill 100 287 487 100 288 487 minecraft:deepslate_bricks
fill 100 287 489 100 288 489 minecraft:deepslate_bricks
fill 101 287 482 101 288 482 minecraft:deepslate_bricks
fill 101 287 484 101 288 484 minecraft:deepslate_bricks
fill 101 287 486 101 288 486 minecraft:deepslate_bricks
fill 101 287 488 101 288 488 minecraft:deepslate_bricks
fill 101 287 494 101 288 494 minecraft:deepslate_bricks
fill 101 287 496 101 288 496 minecraft:deepslate_bricks
fill 101 287 498 101 288 498 minecraft:deepslate_bricks
fill 101 287 500 101 288 500 minecraft:deepslate_bricks
fill 101 287 502 101 288 502 minecraft:deepslate_bricks
fill 101 287 504 101 288 504 minecraft:deepslate_bricks
fill 102 287 481 102 288 481 minecraft:deepslate_bricks
fill 102 287 483 102 288 483 minecraft:deepslate_bricks
fill 102 287 485 102 288 485 minecraft:deepslate_bricks
fill 102 287 487 102 288 487 minecraft:deepslate_bricks
fill 102 287 489 102 288 489 minecraft:deepslate_bricks
fill 102 287 495 102 288 495 minecraft:deepslate_bricks
fill 102 287 497 102 288 497 minecraft:deepslate_bricks
fill 102 287 499 102 288 499 minecraft:deepslate_bricks
fill 102 287 501 102 288 501 minecraft:deepslate_bricks
fill 102 287 503 102 288 503 minecraft:deepslate_bricks
fill 103 287 494 103 288 494 minecraft:deepslate_bricks
fill 103 287 496 103 288 496 minecraft:deepslate_bricks
fill 103 287 498 103 288 498 minecraft:deepslate_bricks
fill 103 287 500 103 288 500 minecraft:deepslate_bricks
fill 103 287 502 103 288 502 minecraft:deepslate_bricks
fill 103 287 504 103 288 504 minecraft:deepslate_bricks
fill 104 287 495 104 288 495 minecraft:deepslate_bricks
fill 104 287 497 104 288 497 minecraft:deepslate_bricks
fill 104 287 499 104 288 499 minecraft:deepslate_bricks
fill 104 287 501 104 288 501 minecraft:deepslate_bricks
fill 104 287 503 104 288 503 minecraft:deepslate_bricks
fill 105 287 494 105 288 494 minecraft:deepslate_bricks
fill 105 287 496 105 288 496 minecraft:deepslate_bricks
fill 105 287 498 105 288 498 minecraft:deepslate_bricks
fill 105 287 500 105 288 500 minecraft:deepslate_bricks
fill 105 287 502 105 288 502 minecraft:deepslate_bricks
fill 105 287 504 105 288 504 minecraft:deepslate_bricks
fill 106 287 495 106 288 495 minecraft:deepslate_bricks
fill 106 287 497 106 288 497 minecraft:deepslate_bricks
fill 106 287 499 106 288 499 minecraft:deepslate_bricks
fill 106 287 501 106 288 501 minecraft:deepslate_bricks
fill 106 287 503 106 288 503 minecraft:deepslate_bricks
fill 107 287 494 107 288 494 minecraft:deepslate_bricks
fill 107 287 496 107 288 496 minecraft:deepslate_bricks
fill 107 287 498 107 288 498 minecraft:deepslate_bricks
fill 107 287 500 107 288 500 minecraft:deepslate_bricks
fill 107 287 502 107 288 502 minecraft:deepslate_bricks
fill 107 287 504 107 288 504 minecraft:deepslate_bricks
fill 108 287 495 108 288 495 minecraft:deepslate_bricks
fill 108 287 497 108 288 497 minecraft:deepslate_bricks
fill 108 287 499 108 288 499 minecraft:deepslate_bricks
fill 108 287 501 108 288 501 minecraft:deepslate_bricks
fill 108 287 503 108 288 503 minecraft:deepslate_bricks
fill 109 287 494 109 288 494 minecraft:deepslate_bricks
fill 109 287 496 109 288 496 minecraft:deepslate_bricks
fill 109 287 498 109 288 498 minecraft:deepslate_bricks
fill 109 287 500 109 288 500 minecraft:deepslate_bricks
fill 109 287 502 109 288 502 minecraft:deepslate_bricks
fill 109 287 504 109 288 504 minecraft:deepslate_bricks
fill 110 287 495 110 288 495 minecraft:deepslate_bricks
fill 110 287 497 110 288 497 minecraft:deepslate_bricks
fill 110 287 499 110 288 499 minecraft:deepslate_bricks
fill 110 287 501 110 288 501 minecraft:deepslate_bricks
fill 110 287 503 110 288 503 minecraft:deepslate_bricks
fill 111 287 464 111 288 464 minecraft:cyan_concrete
fill 111 287 494 111 288 494 minecraft:deepslate_bricks
fill 111 287 496 111 288 496 minecraft:deepslate_bricks
fill 111 287 498 111 288 498 minecraft:deepslate_bricks
fill 111 287 500 111 288 500 minecraft:deepslate_bricks
fill 111 287 502 111 288 502 minecraft:deepslate_bricks
fill 111 287 504 111 288 504 minecraft:deepslate_bricks
fill 115 287 498 115 288 498 minecraft:deepslate_bricks
fill 115 287 500 115 288 500 minecraft:deepslate_bricks
fill 115 287 502 115 288 502 minecraft:deepslate_bricks
fill 115 287 504 115 288 504 minecraft:deepslate_bricks
fill 116 287 499 116 288 499 minecraft:deepslate_bricks
fill 116 287 501 116 288 501 minecraft:deepslate_bricks
fill 116 287 503 116 288 503 minecraft:deepslate_bricks
fill 117 287 498 117 288 498 minecraft:deepslate_bricks
fill 117 287 500 117 288 500 minecraft:deepslate_bricks
fill 117 287 502 117 288 502 minecraft:deepslate_bricks
fill 117 287 504 117 288 504 minecraft:deepslate_bricks
fill 118 287 499 118 288 499 minecraft:deepslate_bricks
fill 118 287 501 118 288 501 minecraft:deepslate_bricks
fill 118 287 503 118 288 503 minecraft:deepslate_bricks
fill 119 287 498 119 288 498 minecraft:deepslate_bricks
fill 119 287 500 119 288 500 minecraft:deepslate_bricks
fill 119 287 502 119 288 502 minecraft:deepslate_bricks
fill 119 287 504 119 288 504 minecraft:deepslate_bricks
fill 120 287 499 120 288 499 minecraft:deepslate_bricks
fill 120 287 501 120 288 501 minecraft:deepslate_bricks
fill 120 287 503 120 288 503 minecraft:deepslate_bricks
fill 121 287 498 121 288 498 minecraft:deepslate_bricks
fill 121 287 500 121 288 500 minecraft:deepslate_bricks
fill 121 287 502 121 288 502 minecraft:deepslate_bricks
fill 121 287 504 121 288 504 minecraft:deepslate_bricks
fill 122 287 499 122 288 499 minecraft:deepslate_bricks
fill 122 287 501 122 288 501 minecraft:deepslate_bricks
fill 122 287 503 122 288 503 minecraft:deepslate_bricks
fill 123 287 486 123 287 488 minecraft:sculk
fill 123 287 498 123 288 498 minecraft:deepslate_bricks
fill 123 287 500 123 288 500 minecraft:deepslate_bricks
fill 123 287 502 123 288 502 minecraft:deepslate_bricks
fill 123 287 504 123 288 504 minecraft:deepslate_bricks
setblock 124 287 485 minecraft:sculk
setblock 124 287 489 minecraft:sculk
fill 124 287 499 124 288 499 minecraft:deepslate_bricks
fill 124 287 501 124 288 501 minecraft:deepslate_bricks
fill 124 287 503 124 288 503 minecraft:deepslate_bricks
fill 125 287 484 128 287 484 minecraft:sculk
fill 125 287 490 128 287 490 minecraft:sculk
fill 125 287 498 125 288 498 minecraft:deepslate_bricks
fill 125 287 500 125 288 500 minecraft:deepslate_bricks
fill 125 287 502 125 288 502 minecraft:deepslate_bricks
fill 125 287 504 125 288 504 minecraft:deepslate_bricks
fill 128 287 491 131 300 491 minecraft:deepslate_bricks
setblock 129 287 485 minecraft:sculk
setblock 129 287 489 minecraft:sculk
fill 129 287 490 131 296 490 minecraft:deepslate_bricks
fill 129 287 492 130 300 492 minecraft:deepslate_bricks
fill 130 287 487 130 287 488 minecraft:sculk
fill 130 287 489 131 300 489 minecraft:deepslate_bricks
fill 101 288 464 103 289 465 minecraft:cyan_stained_glass
fill 102 288 466 102 290 466 minecraft:cyan_stained_glass
fill 126 288 490 126 289 490 minecraft:sculk
fill 127 288 490 128 296 490 minecraft:deepslate_bricks
fill 127 288 491 127 289 492 minecraft:sculk
fill 128 288 489 129 296 489 minecraft:deepslate_bricks
fill 128 288 492 128 289 492 minecraft:sculk
fill 129 288 487 131 289 487 minecraft:sculk
fill 129 288 488 131 296 488 minecraft:deepslate_bricks
fill 129 288 493 130 289 493 minecraft:sculk
fill 131 288 492 131 289 492 minecraft:sculk
fill 132 288 488 132 289 491 minecraft:sculk
setblock 95 289 482 minecraft:sea_lantern
setblock 95 289 484 minecraft:sea_lantern
setblock 95 289 486 minecraft:sea_lantern
setblock 95 289 488 minecraft:sea_lantern
setblock 96 289 481 minecraft:sea_lantern
setblock 96 289 483 minecraft:sea_lantern
setblock 96 289 485 minecraft:sea_lantern
setblock 96 289 487 minecraft:sea_lantern
setblock 96 289 489 minecraft:sea_lantern
setblock 97 289 482 minecraft:sea_lantern
setblock 97 289 484 minecraft:sea_lantern
setblock 97 289 486 minecraft:sea_lantern
setblock 97 289 488 minecraft:sea_lantern
setblock 98 289 481 minecraft:sea_lantern
setblock 98 289 483 minecraft:sea_lantern
setblock 98 289 485 minecraft:sea_lantern
setblock 98 289 487 minecraft:sea_lantern
setblock 98 289 489 minecraft:sea_lantern
setblock 99 289 482 minecraft:sea_lantern
setblock 99 289 484 minecraft:sea_lantern
setblock 99 289 486 minecraft:sea_lantern
setblock 99 289 488 minecraft:sea_lantern
setblock 100 289 481 minecraft:sea_lantern
setblock 100 289 483 minecraft:sea_lantern
setblock 100 289 485 minecraft:sea_lantern
setblock 100 289 487 minecraft:sea_lantern
setblock 100 289 489 minecraft:sea_lantern
setblock 101 289 466 minecraft:cyan_stained_glass
setblock 101 289 482 minecraft:sea_lantern
setblock 101 289 484 minecraft:sea_lantern
setblock 101 289 486 minecraft:sea_lantern
setblock 101 289 488 minecraft:sea_lantern
setblock 101 289 494 minecraft:sea_lantern
setblock 101 289 496 minecraft:sea_lantern
setblock 101 289 498 minecraft:sea_lantern
setblock 101 289 500 minecraft:sea_lantern
setblock 101 289 502 minecraft:sea_lantern
setblock 101 289 504 minecraft:sea_lantern
fill 102 289 467 102 290 468 minecraft:cyan_stained_glass
setblock 102 289 481 minecraft:sea_lantern
setblock 102 289 483 minecraft:sea_lantern
setblock 102 289 485 minecraft:sea_lantern
setblock 102 289 487 minecraft:sea_lantern
setblock 102 289 489 minecraft:sea_lantern
setblock 102 289 495 minecraft:sea_lantern
setblock 102 289 497 minecraft:sea_lantern
setblock 102 289 499 minecraft:sea_lantern
setblock 102 289 501 minecraft:sea_lantern
setblock 102 289 503 minecraft:sea_lantern
setblock 103 289 466 minecraft:cyan_stained_glass
setblock 103 289 494 minecraft:sea_lantern
setblock 103 289 496 minecraft:sea_lantern
setblock 103 289 498 minecraft:sea_lantern
setblock 103 289 500 minecraft:sea_lantern
setblock 103 289 502 minecraft:sea_lantern
setblock 103 289 504 minecraft:sea_lantern
setblock 104 289 495 minecraft:sea_lantern
setblock 104 289 497 minecraft:sea_lantern
setblock 104 289 499 minecraft:sea_lantern
setblock 104 289 501 minecraft:sea_lantern
setblock 104 289 503 minecraft:sea_lantern
setblock 105 289 494 minecraft:sea_lantern
setblock 105 289 496 minecraft:sea_lantern
setblock 105 289 498 minecraft:sea_lantern
setblock 105 289 500 minecraft:sea_lantern
setblock 105 289 502 minecraft:sea_lantern
setblock 105 289 504 minecraft:sea_lantern
setblock 106 289 495 minecraft:sea_lantern
setblock 106 289 497 minecraft:sea_lantern
setblock 106 289 499 minecraft:sea_lantern
setblock 106 289 501 minecraft:sea_lantern
setblock 106 289 503 minecraft:sea_lantern
setblock 107 289 494 minecraft:sea_lantern
setblock 107 289 496 minecraft:sea_lantern
setblock 107 289 498 minecraft:sea_lantern
setblock 107 289 500 minecraft:sea_lantern
setblock 107 289 502 minecraft:sea_lantern
setblock 107 289 504 minecraft:sea_lantern
setblock 108 289 495 minecraft:sea_lantern
setblock 108 289 497 minecraft:sea_lantern
setblock 108 289 499 minecraft:sea_lantern
setblock 108 289 501 minecraft:sea_lantern
setblock 108 289 503 minecraft:sea_lantern
setblock 109 289 494 minecraft:sea_lantern
setblock 109 289 496 minecraft:sea_lantern
setblock 109 289 498 minecraft:sea_lantern
setblock 109 289 500 minecraft:sea_lantern
setblock 109 289 502 minecraft:sea_lantern
setblock 109 289 504 minecraft:sea_lantern
setblock 110 289 495 minecraft:sea_lantern
setblock 110 289 497 minecraft:sea_lantern
setblock 110 289 499 minecraft:sea_lantern
setblock 110 289 501 minecraft:sea_lantern
setblock 110 289 503 minecraft:sea_lantern
setblock 111 289 494 minecraft:sea_lantern
setblock 111 289 496 minecraft:sea_lantern
setblock 111 289 498 minecraft:sea_lantern
setblock 111 289 500 minecraft:sea_lantern
setblock 111 289 502 minecraft:sea_lantern
setblock 111 289 504 minecraft:sea_lantern
setblock 115 289 498 minecraft:sea_lantern
setblock 115 289 500 minecraft:sea_lantern
setblock 115 289 502 minecraft:sea_lantern
setblock 115 289 504 minecraft:sea_lantern
setblock 116 289 499 minecraft:sea_lantern
setblock 116 289 501 minecraft:sea_lantern
setblock 116 289 503 minecraft:sea_lantern
setblock 117 289 498 minecraft:sea_lantern
setblock 117 289 500 minecraft:sea_lantern
setblock 117 289 502 minecraft:sea_lantern
setblock 117 289 504 minecraft:sea_lantern
setblock 118 289 499 minecraft:sea_lantern
setblock 118 289 501 minecraft:sea_lantern
setblock 118 289 503 minecraft:sea_lantern
setblock 119 289 498 minecraft:sea_lantern
schedule function dropper:buildpart/110_3 1t
