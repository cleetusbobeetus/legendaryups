fill 135 165 341 135 168 341 minecraft:stone
setblock 135 165 345 minecraft:stripped_spruce_log
fill 135 165 346 135 168 346 minecraft:stone
setblock 135 165 350 minecraft:stripped_spruce_log
fill 135 165 351 135 168 351 minecraft:stone
setblock 135 165 355 minecraft:stripped_spruce_log
fill 135 165 356 135 168 356 minecraft:stone
setblock 135 165 360 minecraft:stripped_spruce_log
fill 135 165 361 135 167 361 minecraft:stone
fill 136 165 331 136 174 331 minecraft:deepslate
setblock 136 165 342 minecraft:raw_gold_block
setblock 136 165 358 minecraft:raw_gold_block
fill 136 165 359 136 171 360 minecraft:deepslate
setblock 95 166 323 minecraft:stone
setblock 95 166 324 minecraft:stripped_spruce_log
fill 95 166 325 95 166 328 minecraft:stone
setblock 95 166 329 minecraft:stripped_spruce_log
fill 95 166 330 95 166 333 minecraft:stone
setblock 95 166 334 minecraft:stripped_spruce_log
fill 95 166 335 95 166 338 minecraft:stone
setblock 95 166 339 minecraft:stripped_spruce_log
fill 95 166 340 95 166 343 minecraft:stone
setblock 95 166 344 minecraft:stripped_spruce_log
fill 95 166 345 95 166 348 minecraft:stone
setblock 95 166 349 minecraft:stripped_spruce_log
fill 95 166 350 95 169 350 minecraft:stone
setblock 95 166 353 minecraft:stone
setblock 95 166 354 minecraft:stripped_spruce_log
fill 95 166 355 95 169 355 minecraft:stone
setblock 96 166 323 minecraft:stripped_spruce_log
fill 96 166 324 96 166 327 minecraft:stone
setblock 96 166 328 minecraft:stripped_spruce_log
fill 96 166 329 96 169 329 minecraft:stone
setblock 96 166 333 minecraft:stripped_spruce_log
fill 96 166 334 96 166 337 minecraft:stone
setblock 96 166 338 minecraft:stripped_spruce_log
fill 96 166 339 96 166 340 minecraft:stone
setblock 96 166 342 minecraft:stone
setblock 96 166 343 minecraft:stripped_spruce_log
fill 96 166 344 96 166 347 minecraft:stone
setblock 96 166 348 minecraft:stripped_spruce_log
fill 96 166 349 96 168 349 minecraft:stone
setblock 96 166 353 minecraft:stripped_spruce_log
fill 96 166 354 96 167 354 minecraft:stone
fill 97 166 323 100 166 323 minecraft:stone
setblock 97 166 327 minecraft:stripped_spruce_log
fill 97 166 328 97 167 328 minecraft:stone
setblock 97 166 332 minecraft:stripped_spruce_log
fill 97 166 333 97 168 334 minecraft:stone
setblock 101 166 323 minecraft:stripped_spruce_log
fill 102 166 323 105 166 323 minecraft:stone
fill 103 166 324 104 166 324 minecraft:stone
setblock 105 166 324 minecraft:stripped_spruce_log
fill 105 166 325 105 168 325 minecraft:stone
setblock 106 166 323 minecraft:stripped_spruce_log
fill 106 166 324 109 166 324 minecraft:stone
fill 107 166 323 110 166 323 minecraft:stone
setblock 107 166 326 minecraft:stone
fill 107 166 363 110 166 363 minecraft:stone
setblock 108 166 326 minecraft:stripped_spruce_log
setblock 109 166 325 minecraft:stripped_spruce_log
fill 109 166 326 109 168 326 minecraft:stone
fill 109 166 362 111 166 362 minecraft:stone
setblock 110 166 324 minecraft:stripped_spruce_log
fill 110 166 325 110 169 325 minecraft:stone
setblock 111 166 323 minecraft:stripped_spruce_log
fill 111 166 324 114 166 324 minecraft:stone
fill 111 166 327 111 166 328 minecraft:stripped_spruce_log
fill 111 166 329 113 167 331 minecraft:iron_block
setblock 111 166 363 minecraft:stripped_spruce_log
fill 112 166 323 115 166 323 minecraft:stone
fill 112 166 333 112 166 336 minecraft:stripped_dark_oak_log
setblock 112 166 362 minecraft:stripped_spruce_log
fill 112 166 363 115 166 363 minecraft:stone
setblock 113 166 326 minecraft:stripped_spruce_log
fill 113 166 343 113 166 345 minecraft:stripped_dark_oak_log
fill 113 166 362 113 169 362 minecraft:stone
setblock 114 166 325 minecraft:stripped_spruce_log
setblock 114 166 326 minecraft:stone
fill 114 166 347 114 166 351 minecraft:stripped_dark_oak_log
setblock 115 166 324 minecraft:stripped_spruce_log
fill 115 166 325 115 167 325 minecraft:stone
setblock 116 166 323 minecraft:stripped_spruce_log
fill 116 166 324 116 167 324 minecraft:stone
setblock 116 166 363 minecraft:stripped_spruce_log
fill 117 166 323 117 168 323 minecraft:stone
fill 117 166 363 117 169 363 minecraft:stone
fill 119 166 322 121 170 322 minecraft:deepslate
setblock 120 166 323 minecraft:stone
setblock 120 166 363 minecraft:stone
setblock 122 166 322 minecraft:raw_gold_block
fill 124 166 363 125 166 363 minecraft:stone
setblock 126 166 323 minecraft:stripped_spruce_log
setblock 126 166 363 minecraft:stripped_spruce_log
fill 127 166 323 130 166 323 minecraft:stone
fill 127 166 325 127 177 325 minecraft:iron_bars
fill 127 166 363 130 166 363 minecraft:stone
setblock 128 166 322 minecraft:raw_gold_block
setblock 129 166 322 minecraft:deepslate
setblock 129 166 347 minecraft:raw_gold_block
fill 129 166 362 129 168 362 minecraft:stone
setblock 130 166 324 minecraft:stripped_spruce_log
setblock 131 166 323 minecraft:stripped_spruce_log
setblock 131 166 324 minecraft:stone
fill 131 166 349 131 167 349 minecraft:stone
setblock 131 166 353 minecraft:stripped_spruce_log
setblock 131 166 363 minecraft:stripped_spruce_log
fill 132 166 323 132 168 323 minecraft:stone
setblock 132 166 346 minecraft:stone
setblock 132 166 347 minecraft:stripped_spruce_log
fill 132 166 348 132 169 348 minecraft:stone
setblock 132 166 351 minecraft:stone
setblock 132 166 352 minecraft:stripped_spruce_log
fill 132 166 353 132 169 353 minecraft:stone
fill 132 166 363 132 169 363 minecraft:stone
setblock 133 166 324 minecraft:stone
fill 133 166 328 133 166 330 minecraft:stone
setblock 133 166 331 minecraft:stripped_spruce_log
fill 133 166 332 133 168 333 minecraft:stone
setblock 133 166 346 minecraft:stripped_spruce_log
fill 133 166 347 133 169 347 minecraft:stone
setblock 133 166 351 minecraft:stripped_spruce_log
fill 133 166 352 133 169 352 minecraft:stone
setblock 133 166 355 minecraft:stone
setblock 133 166 356 minecraft:stripped_spruce_log
fill 133 166 357 133 169 357 minecraft:stone
setblock 134 166 325 minecraft:stripped_spruce_log
fill 134 166 326 134 166 329 minecraft:stone
setblock 134 166 330 minecraft:stripped_spruce_log
fill 134 166 331 134 169 331 minecraft:stone
fill 134 166 333 134 166 334 minecraft:stone
setblock 134 166 335 minecraft:stripped_spruce_log
fill 134 166 336 134 166 339 minecraft:stone
setblock 134 166 340 minecraft:stripped_spruce_log
fill 134 166 341 134 169 341 minecraft:stone
setblock 134 166 345 minecraft:stripped_spruce_log
fill 134 166 346 134 169 346 minecraft:stone
setblock 134 166 350 minecraft:stripped_spruce_log
fill 134 166 351 134 169 351 minecraft:stone
setblock 134 166 355 minecraft:stripped_spruce_log
fill 134 166 356 134 169 356 minecraft:stone
setblock 134 166 359 minecraft:stone
setblock 135 166 324 minecraft:stripped_spruce_log
fill 135 166 325 135 166 328 minecraft:stone
setblock 135 166 329 minecraft:stripped_spruce_log
fill 135 166 330 135 169 330 minecraft:stone
setblock 135 166 333 minecraft:stone
setblock 135 166 334 minecraft:stripped_spruce_log
fill 135 166 335 135 169 335 minecraft:stone
setblock 135 166 339 minecraft:stripped_spruce_log
fill 135 166 340 135 169 340 minecraft:stone
setblock 135 166 344 minecraft:stripped_spruce_log
fill 135 166 345 135 169 345 minecraft:stone
setblock 135 166 349 minecraft:stripped_spruce_log
fill 135 166 350 135 169 350 minecraft:stone
setblock 135 166 354 minecraft:stripped_spruce_log
fill 135 166 355 135 169 355 minecraft:stone
setblock 135 166 359 minecraft:stripped_spruce_log
fill 135 166 360 135 168 360 minecraft:stone
fill 136 166 342 136 171 342 minecraft:deepslate
fill 136 166 358 136 172 358 minecraft:deepslate
setblock 94 167 329 minecraft:gold_block
setblock 95 167 323 minecraft:stripped_spruce_log
fill 95 167 324 95 167 327 minecraft:stone
setblock 95 167 328 minecraft:stripped_spruce_log
fill 95 167 329 95 167 332 minecraft:stone
setblock 95 167 333 minecraft:stripped_spruce_log
fill 95 167 334 95 167 337 minecraft:stone
setblock 95 167 338 minecraft:stripped_spruce_log
fill 95 167 339 95 167 342 minecraft:stone
setblock 95 167 343 minecraft:stripped_spruce_log
fill 95 167 344 95 167 347 minecraft:stone
setblock 95 167 348 minecraft:stripped_spruce_log
fill 95 167 349 95 170 349 minecraft:stone
setblock 95 167 353 minecraft:stripped_spruce_log
fill 95 167 354 95 170 354 minecraft:stone
setblock 95 167 358 minecraft:stripped_spruce_log
fill 96 167 323 98 167 323 minecraft:stone
fill 96 167 325 96 167 326 minecraft:stone
setblock 96 167 327 minecraft:stripped_spruce_log
fill 96 167 328 96 170 328 minecraft:stone
setblock 96 167 331 minecraft:stone
setblock 96 167 332 minecraft:stripped_spruce_log
fill 96 167 333 96 167 336 minecraft:stone
setblock 96 167 337 minecraft:stripped_spruce_log
fill 96 167 338 96 167 339 minecraft:stone
fill 96 167 345 96 167 346 minecraft:stone
setblock 96 167 347 minecraft:stripped_spruce_log
fill 96 167 348 96 168 348 minecraft:stone
setblock 96 167 352 minecraft:stripped_spruce_log
fill 96 167 353 96 168 353 minecraft:stone
setblock 97 167 331 minecraft:stripped_spruce_log
fill 97 167 332 97 170 332 minecraft:stone
setblock 100 167 323 minecraft:stripped_spruce_log
fill 101 167 323 104 167 323 minecraft:stone
setblock 103 167 324 minecraft:stone
setblock 104 167 324 minecraft:stripped_spruce_log
setblock 105 167 323 minecraft:stripped_spruce_log
fill 105 167 324 108 167 324 minecraft:stone
fill 106 167 323 109 167 323 minecraft:stone
fill 106 167 363 109 167 363 minecraft:stone
setblock 107 167 326 minecraft:stripped_spruce_log
setblock 108 167 325 minecraft:stripped_spruce_log
fill 108 167 326 108 168 326 minecraft:stone
fill 108 167 362 110 167 362 minecraft:stone
setblock 109 167 324 minecraft:stripped_spruce_log
fill 109 167 325 109 170 325 minecraft:stone
setblock 110 167 323 minecraft:stripped_spruce_log
fill 110 167 324 113 167 324 minecraft:stone
setblock 110 167 363 minecraft:stripped_spruce_log
fill 111 167 323 114 167 323 minecraft:stone
fill 111 167 327 111 167 328 minecraft:stripped_dark_oak_log
setblock 111 167 362 minecraft:stripped_spruce_log
fill 111 167 363 114 167 363 minecraft:stone
setblock 112 167 326 minecraft:stripped_spruce_log
fill 112 167 362 112 170 362 minecraft:stone
setblock 113 167 325 minecraft:stripped_spruce_log
setblock 113 167 326 minecraft:stone
setblock 114 167 324 minecraft:stripped_spruce_log
fill 114 167 325 114 168 325 minecraft:stone
setblock 115 167 323 minecraft:stripped_spruce_log
fill 115 167 324 115 168 324 minecraft:stone
setblock 115 167 363 minecraft:stripped_spruce_log
fill 116 167 323 116 169 323 minecraft:stone
setblock 116 167 362 minecraft:stripped_spruce_log
fill 116 167 363 116 170 363 minecraft:stone
setblock 120 167 363 minecraft:stripped_spruce_log
fill 122 167 322 122 170 322 minecraft:deepslate
fill 123 167 363 124 167 363 minecraft:stone
setblock 125 167 363 minecraft:stripped_spruce_log
fill 126 167 323 129 167 323 minecraft:stone
fill 126 167 363 129 167 363 minecraft:stone
fill 128 167 322 128 174 322 minecraft:deepslate
fill 128 167 362 128 169 362 minecraft:stone
setblock 129 167 322 minecraft:diamond_block
setblock 130 167 323 minecraft:stripped_spruce_log
setblock 130 167 362 minecraft:stone
setblock 130 167 363 minecraft:stripped_spruce_log
fill 131 167 323 131 169 323 minecraft:stone
fill 131 167 350 131 167 351 minecraft:stone
setblock 131 167 352 minecraft:stripped_spruce_log
fill 131 167 353 131 168 354 minecraft:stone
setblock 131 167 362 minecraft:stripped_spruce_log
fill 131 167 363 131 170 363 minecraft:stone
setblock 132 167 346 minecraft:stripped_spruce_log
fill 132 167 347 132 168 347 minecraft:stone
setblock 132 167 351 minecraft:stripped_spruce_log
fill 132 167 352 132 170 352 minecraft:stone
setblock 132 167 356 minecraft:stripped_spruce_log
fill 133 167 328 133 167 329 minecraft:stone
setblock 133 167 330 minecraft:stripped_spruce_log
fill 133 167 331 133 169 331 minecraft:stone
setblock 133 167 334 minecraft:stone
setblock 133 167 335 minecraft:stripped_spruce_log
setblock 133 167 345 minecraft:stripped_spruce_log
fill 133 167 346 133 169 346 minecraft:stone
setblock 133 167 350 minecraft:stripped_spruce_log
fill 133 167 351 133 170 351 minecraft:stone
setblock 133 167 355 minecraft:stripped_spruce_log
fill 133 167 356 133 170 356 minecraft:stone
setblock 134 167 322 minecraft:raw_iron_block
setblock 134 167 323 minecraft:stone
fill 134 167 326 134 167 328 minecraft:stone
setblock 134 167 329 minecraft:stripped_spruce_log
fill 134 167 330 134 170 330 minecraft:stone
setblock 134 167 333 minecraft:stone
setblock 134 167 334 minecraft:stripped_spruce_log
fill 134 167 335 134 167 338 minecraft:stone
setblock 134 167 339 minecraft:stripped_spruce_log
fill 134 167 340 134 170 340 minecraft:stone
setblock 134 167 344 minecraft:stripped_spruce_log
fill 134 167 345 134 170 345 minecraft:stone
setblock 134 167 349 minecraft:stripped_spruce_log
fill 134 167 350 134 170 350 minecraft:stone
setblock 134 167 354 minecraft:stripped_spruce_log
fill 134 167 355 134 170 355 minecraft:stone
setblock 134 167 358 minecraft:stone
setblock 134 167 359 minecraft:stripped_spruce_log
fill 135 167 324 135 167 327 minecraft:stone
setblock 135 167 328 minecraft:stripped_spruce_log
fill 135 167 329 135 170 329 minecraft:stone
setblock 135 167 333 minecraft:stripped_spruce_log
fill 135 167 334 135 170 334 minecraft:stone
setblock 135 167 338 minecraft:stripped_spruce_log
fill 135 167 339 135 170 339 minecraft:stone
setblock 135 167 343 minecraft:stripped_spruce_log
fill 135 167 344 135 170 344 minecraft:stone
setblock 135 167 348 minecraft:stripped_spruce_log
fill 135 167 349 135 170 349 minecraft:stone
setblock 135 167 353 minecraft:stripped_spruce_log
fill 135 167 354 135 170 354 minecraft:stone
setblock 135 167 358 minecraft:stripped_spruce_log
fill 135 167 359 135 170 359 minecraft:stone
fill 94 168 329 94 170 329 minecraft:deepslate
setblock 94 168 345 minecraft:raw_gold_block
setblock 94 168 361 minecraft:diamond_block
setblock 94 168 362 minecraft:raw_gold_block
fill 95 168 323 95 168 326 minecraft:stone
setblock 95 168 327 minecraft:stripped_spruce_log
fill 95 168 328 95 168 331 minecraft:stone
setblock 95 168 332 minecraft:stripped_spruce_log
fill 95 168 333 95 168 336 minecraft:stone
setblock 95 168 337 minecraft:stripped_spruce_log
fill 95 168 338 95 168 341 minecraft:stone
setblock 95 168 342 minecraft:stripped_spruce_log
fill 95 168 343 95 168 346 minecraft:stone
setblock 95 168 347 minecraft:stripped_spruce_log
fill 95 168 348 95 170 348 minecraft:stone
setblock 95 168 352 minecraft:stripped_spruce_log
fill 95 168 353 95 171 353 minecraft:stone
setblock 95 168 357 minecraft:stripped_spruce_log
setblock 96 168 323 minecraft:stone
setblock 96 168 326 minecraft:stripped_spruce_log
fill 96 168 327 96 169 327 minecraft:stone
setblock 96 168 331 minecraft:stripped_spruce_log
fill 96 168 332 96 168 335 minecraft:stone
setblock 96 168 336 minecraft:stripped_spruce_log
fill 96 168 337 96 169 338 minecraft:stone
setblock 96 168 351 minecraft:stripped_spruce_log
setblock 96 168 352 minecraft:stone
setblock 97 168 325 minecraft:light[level=12]
setblock 97 168 330 minecraft:stripped_spruce_log
fill 97 168 331 97 169 331 minecraft:stone
setblock 97 168 339 minecraft:light[level=12]
setblock 97 168 346 minecraft:light[level=12]
setblock 97 168 353 minecraft:light[level=12]
setblock 97 168 360 minecraft:light[level=12]
fill 101 168 323 103 168 323 minecraft:stone
setblock 104 168 323 minecraft:stripped_spruce_log
fill 104 168 324 107 168 324 minecraft:stone
setblock 104 168 325 minecraft:light[level=12]
setblock 104 168 332 minecraft:light[level=12]
setblock 104 168 339 minecraft:light[level=12]
setblock 104 168 346 minecraft:light[level=12]
setblock 104 168 353 minecraft:light[level=12]
setblock 104 168 360 minecraft:light[level=12]
fill 105 168 323 108 168 323 minecraft:stone
fill 105 168 363 108 168 363 minecraft:stone
setblock 107 168 325 minecraft:stripped_spruce_log
setblock 107 168 326 minecraft:stone
setblock 108 168 324 minecraft:stripped_spruce_log
fill 108 168 325 108 170 325 minecraft:stone
fill 108 168 362 109 168 362 minecraft:stone
setblock 109 168 323 minecraft:stripped_spruce_log
fill 109 168 324 112 168 324 minecraft:stone
setblock 109 168 363 minecraft:stripped_spruce_log
fill 110 168 323 113 168 323 minecraft:stone
setblock 110 168 362 minecraft:stripped_spruce_log
fill 110 168 363 113 168 363 minecraft:stone
fill 111 168 322 111 175 322 minecraft:deepslate
setblock 111 168 326 minecraft:stripped_spruce_log
fill 111 168 329 113 168 331 minecraft:raw_gold_block
setblock 111 168 332 minecraft:light[level=12]
setblock 111 168 339 minecraft:light[level=12]
setblock 111 168 346 minecraft:light[level=12]
setblock 111 168 353 minecraft:light[level=12]
setblock 111 168 360 minecraft:light[level=12]
fill 111 168 362 111 171 362 minecraft:stone
setblock 112 168 322 minecraft:raw_iron_block
setblock 112 168 325 minecraft:stripped_spruce_log
fill 113 168 322 114 172 322 minecraft:deepslate
setblock 113 168 324 minecraft:stripped_spruce_log
setblock 113 168 325 minecraft:stone
setblock 114 168 323 minecraft:stripped_spruce_log
fill 114 168 324 114 169 324 minecraft:stone
setblock 114 168 363 minecraft:stripped_spruce_log
fill 115 168 323 115 170 323 minecraft:stone
setblock 115 168 362 minecraft:stripped_spruce_log
fill 115 168 363 115 171 363 minecraft:stone
setblock 118 168 325 minecraft:light[level=12]
setblock 118 168 332 minecraft:light[level=12]
setblock 118 168 339 minecraft:light[level=12]
setblock 118 168 346 minecraft:light[level=12]
setblock 118 168 353 minecraft:light[level=12]
setblock 118 168 360 minecraft:light[level=12]
setblock 119 168 363 minecraft:stripped_spruce_log
setblock 123 168 363 minecraft:stone
setblock 123 168 364 minecraft:raw_gold_block
setblock 124 168 363 minecraft:stripped_spruce_log
setblock 125 168 325 minecraft:light[level=12]
setblock 125 168 332 minecraft:light[level=12]
setblock 125 168 339 minecraft:light[level=12]
setblock 125 168 346 minecraft:light[level=12]
setblock 125 168 353 minecraft:light[level=12]
setblock 125 168 360 minecraft:light[level=12]
fill 125 168 363 128 168 363 minecraft:stone
fill 127 168 323 128 168 323 minecraft:stone
fill 127 168 362 127 170 362 minecraft:stone
fill 129 168 322 129 174 322 minecraft:deepslate
setblock 129 168 323 minecraft:stripped_spruce_log
setblock 129 168 363 minecraft:stripped_spruce_log
fill 130 168 323 130 169 323 minecraft:stone
setblock 130 168 362 minecraft:stripped_spruce_log
fill 130 168 363 130 171 363 minecraft:stone
setblock 131 168 350 minecraft:stone
setblock 131 168 351 minecraft:stripped_spruce_log
fill 131 168 352 131 169 352 minecraft:stone
setblock 132 168 325 minecraft:light[level=12]
setblock 132 168 332 minecraft:light[level=12]
setblock 132 168 339 minecraft:light[level=12]
setblock 132 168 346 minecraft:light[level=12]
setblock 132 168 350 minecraft:stripped_spruce_log
fill 132 168 351 132 170 351 minecraft:stone
setblock 132 168 354 minecraft:stone
setblock 132 168 355 minecraft:stripped_spruce_log
fill 132 168 356 132 169 356 minecraft:stone
setblock 132 168 360 minecraft:light[level=12]
setblock 133 168 329 minecraft:stripped_spruce_log
fill 133 168 330 133 169 330 minecraft:stone
setblock 133 168 334 minecraft:stripped_spruce_log
fill 133 168 335 134 169 336 minecraft:stone
setblock 133 168 344 minecraft:stripped_spruce_log
setblock 133 168 345 minecraft:stone
setblock 133 168 349 minecraft:stripped_spruce_log
fill 133 168 350 133 170 350 minecraft:stone
setblock 133 168 354 minecraft:stripped_spruce_log
fill 133 168 355 133 171 355 minecraft:stone
fill 134 168 322 134 174 322 minecraft:deepslate
setblock 134 168 327 minecraft:stone
setblock 134 168 328 minecraft:stripped_spruce_log
fill 134 168 329 134 170 329 minecraft:stone
setblock 134 168 333 minecraft:stripped_spruce_log
fill 134 168 334 134 171 334 minecraft:stone
setblock 134 168 337 minecraft:stone
setblock 134 168 338 minecraft:stripped_spruce_log
fill 134 168 339 134 171 339 minecraft:stone
setblock 134 168 343 minecraft:stripped_spruce_log
fill 134 168 344 134 169 344 minecraft:stone
setblock 134 168 348 minecraft:stripped_spruce_log
fill 134 168 349 134 171 349 minecraft:stone
setblock 134 168 353 minecraft:stripped_spruce_log
fill 134 168 354 134 171 354 minecraft:stone
setblock 134 168 358 minecraft:stripped_spruce_log
setblock 134 168 359 minecraft:stone
fill 135 168 325 135 168 326 minecraft:stone
setblock 135 168 327 minecraft:stripped_spruce_log
fill 135 168 328 135 170 328 minecraft:stone
setblock 135 168 332 minecraft:stripped_spruce_log
fill 135 168 333 135 171 333 minecraft:stone
setblock 135 168 337 minecraft:stripped_spruce_log
fill 135 168 338 135 171 338 minecraft:stone
setblock 135 168 342 minecraft:stripped_spruce_log
fill 135 168 343 135 171 343 minecraft:stone
setblock 135 168 347 minecraft:stripped_spruce_log
fill 135 168 348 135 171 348 minecraft:stone
setblock 135 168 352 minecraft:stripped_spruce_log
fill 135 168 353 135 171 353 minecraft:stone
setblock 135 168 357 minecraft:stripped_spruce_log
fill 135 168 358 135 171 358 minecraft:stone
fill 94 169 345 94 174 345 minecraft:deepslate
fill 94 169 361 94 174 362 minecraft:deepslate
fill 95 169 324 95 169 325 minecraft:stone
setblock 95 169 326 minecraft:stripped_spruce_log
fill 95 169 327 95 169 330 minecraft:stone
setblock 95 169 331 minecraft:stripped_spruce_log
fill 95 169 332 95 169 335 minecraft:stone
setblock 95 169 336 minecraft:stripped_spruce_log
fill 95 169 337 95 169 340 minecraft:stone
setblock 95 169 341 minecraft:stripped_spruce_log
fill 95 169 342 95 169 345 minecraft:stone
setblock 95 169 346 minecraft:stripped_spruce_log
setblock 95 169 347 minecraft:stone
setblock 95 169 351 minecraft:stripped_spruce_log
fill 95 169 352 95 171 352 minecraft:stone
setblock 95 169 356 minecraft:stripped_spruce_log
fill 95 169 357 95 170 357 minecraft:stone
setblock 96 169 330 minecraft:stripped_spruce_log
fill 96 169 331 96 169 334 minecraft:stone
setblock 96 169 335 minecraft:stripped_spruce_log
fill 96 169 336 96 172 336 minecraft:stone
setblock 97 169 330 minecraft:stone
setblock 97 169 333 minecraft:stone
setblock 97 169 334 minecraft:stripped_spruce_log
setblock 102 169 323 minecraft:stone
setblock 103 169 323 minecraft:stripped_spruce_log
fill 104 169 323 106 169 324 minecraft:stone
fill 105 169 363 107 169 363 minecraft:stone
setblock 106 169 322 minecraft:raw_iron_block
setblock 106 169 325 minecraft:stripped_spruce_log
setblock 107 169 323 minecraft:stone
setblock 107 169 324 minecraft:stripped_spruce_log
fill 107 169 325 107 170 325 minecraft:stone
fill 107 169 362 108 169 362 minecraft:stone
setblock 108 169 323 minecraft:stripped_spruce_log
fill 108 169 324 111 169 324 minecraft:stone
setblock 108 169 363 minecraft:stripped_spruce_log
fill 109 169 323 112 169 323 minecraft:stone
setblock 109 169 362 minecraft:stripped_spruce_log
fill 109 169 363 112 169 363 minecraft:stone
fill 110 169 362 110 172 362 minecraft:stone
setblock 111 169 325 minecraft:stripped_spruce_log
fill 112 169 322 112 174 322 minecraft:deepslate
setblock 112 169 324 minecraft:stripped_spruce_log
setblock 112 169 325 minecraft:stone
setblock 113 169 323 minecraft:stripped_spruce_log
fill 113 169 324 113 170 324 minecraft:stone
setblock 113 169 363 minecraft:stripped_spruce_log
fill 114 169 323 114 170 323 minecraft:stone
setblock 114 169 362 minecraft:stripped_spruce_log
fill 114 169 363 114 172 363 minecraft:stone
setblock 118 169 363 minecraft:stripped_spruce_log
setblock 123 169 363 minecraft:stripped_spruce_log
fill 123 169 364 123 172 364 minecraft:deepslate
fill 124 169 363 127 169 363 minecraft:stone
setblock 128 169 323 minecraft:stripped_spruce_log
setblock 128 169 363 minecraft:stripped_spruce_log
setblock 129 169 323 minecraft:stone
setblock 129 169 362 minecraft:stripped_spruce_log
fill 129 169 363 129 172 363 minecraft:stone
setblock 130 169 362 minecraft:stone
setblock 132 169 349 minecraft:stripped_spruce_log
fill 132 169 350 132 170 350 minecraft:stone
setblock 132 169 354 minecraft:stripped_spruce_log
fill 132 169 355 132 170 355 minecraft:stone
setblock 132 169 364 minecraft:diamond_block
setblock 133 169 332 minecraft:stone
setblock 133 169 333 minecraft:stripped_spruce_log
fill 133 169 334 133 171 334 minecraft:stone
setblock 133 169 348 minecraft:stripped_spruce_log
fill 133 169 349 133 170 349 minecraft:stone
setblock 133 169 353 minecraft:stripped_spruce_log
fill 133 169 354 133 171 354 minecraft:stone
setblock 134 169 328 minecraft:stone
setblock 134 169 332 minecraft:stripped_spruce_log
fill 134 169 333 134 172 333 minecraft:stone
setblock 134 169 337 minecraft:stripped_spruce_log
fill 134 169 338 134 172 338 minecraft:stone
setblock 134 169 342 minecraft:stripped_spruce_log
setblock 134 169 343 minecraft:stone
setblock 134 169 347 minecraft:stripped_spruce_log
fill 134 169 348 134 171 348 minecraft:stone
setblock 134 169 352 minecraft:stripped_spruce_log
fill 134 169 353 134 172 353 minecraft:stone
setblock 134 169 357 minecraft:stripped_spruce_log
fill 134 169 358 134 170 358 minecraft:stone
setblock 135 169 326 minecraft:stripped_spruce_log
fill 135 169 327 135 170 327 minecraft:stone
setblock 135 169 331 minecraft:stripped_spruce_log
fill 135 169 332 135 172 332 minecraft:stone
setblock 135 169 336 minecraft:stripped_spruce_log
fill 135 169 337 135 172 337 minecraft:stone
setblock 135 169 341 minecraft:stripped_spruce_log
fill 135 169 342 135 172 342 minecraft:stone
setblock 135 169 346 minecraft:stripped_spruce_log
fill 135 169 347 135 171 347 minecraft:stone
setblock 135 169 351 minecraft:stripped_spruce_log
fill 135 169 352 135 172 352 minecraft:stone
setblock 135 169 356 minecraft:stripped_spruce_log
fill 135 169 357 135 172 357 minecraft:stone
setblock 95 170 325 minecraft:stripped_spruce_log
fill 95 170 326 95 170 329 minecraft:stone
setblock 95 170 330 minecraft:stripped_spruce_log
fill 95 170 331 95 170 334 minecraft:stone
setblock 95 170 335 minecraft:stripped_spruce_log
fill 95 170 336 95 170 339 minecraft:stone
setblock 95 170 340 minecraft:stripped_spruce_log
fill 95 170 341 95 170 342 minecraft:stone
setblock 95 170 350 minecraft:stripped_spruce_log
setblock 95 170 351 minecraft:stone
setblock 95 170 355 minecraft:stripped_spruce_log
setblock 95 170 356 minecraft:stone
setblock 96 170 329 minecraft:stripped_spruce_log
fill 96 170 330 96 170 333 minecraft:stone
setblock 96 170 334 minecraft:stripped_spruce_log
fill 96 170 335 96 173 335 minecraft:stone
fill 96 170 337 96 171 337 minecraft:stone
setblock 97 170 325 minecraft:light[level=15]
setblock 97 170 333 minecraft:stripped_spruce_log
setblock 97 170 341 minecraft:light[level=15]
setblock 97 170 349 minecraft:light[level=15]
setblock 97 170 357 minecraft:light[level=15]
setblock 102 170 323 minecraft:stripped_spruce_log
fill 103 170 323 106 170 323 minecraft:stone
fill 104 170 324 105 170 324 minecraft:stone
setblock 105 170 322 minecraft:gold_block
setblock 105 170 325 minecraft:light[level=15]
setblock 105 170 333 minecraft:light[level=15]
setblock 105 170 341 minecraft:light[level=15]
setblock 105 170 349 minecraft:light[level=15]
setblock 105 170 357 minecraft:light[level=15]
fill 105 170 363 106 170 363 minecraft:stone
fill 106 170 322 106 174 322 minecraft:deepslate
setblock 106 170 324 minecraft:stripped_spruce_log
setblock 107 170 323 minecraft:stripped_spruce_log
fill 107 170 324 110 170 324 minecraft:stone
setblock 107 170 362 minecraft:stone
setblock 107 170 363 minecraft:stripped_spruce_log
fill 108 170 323 111 170 323 minecraft:stone
setblock 108 170 362 minecraft:stripped_spruce_log
fill 108 170 363 111 170 363 minecraft:stone
fill 109 170 362 109 173 362 minecraft:stone
setblock 110 170 325 minecraft:stripped_spruce_log
setblock 111 170 324 minecraft:stripped_spruce_log
setblock 112 170 323 minecraft:stripped_spruce_log
setblock 112 170 324 minecraft:stone
setblock 112 170 363 minecraft:stripped_spruce_log
fill 113 170 323 113 171 323 minecraft:stone
setblock 113 170 325 minecraft:light[level=15]
setblock 113 170 333 minecraft:light[level=15]
setblock 113 170 341 minecraft:light[level=15]
setblock 113 170 349 minecraft:light[level=15]
setblock 113 170 357 minecraft:light[level=15]
setblock 113 170 362 minecraft:stripped_spruce_log
fill 113 170 363 113 173 363 minecraft:stone
setblock 114 170 362 minecraft:stone
setblock 117 170 363 minecraft:stripped_spruce_log
setblock 121 170 325 minecraft:light[level=15]
setblock 121 170 333 minecraft:light[level=15]
setblock 121 170 341 minecraft:light[level=15]
setblock 121 170 349 minecraft:light[level=15]
setblock 121 170 357 minecraft:light[level=15]
fill 124 170 363 126 170 363 minecraft:stone
setblock 127 170 363 minecraft:stripped_spruce_log
setblock 128 170 362 minecraft:stripped_spruce_log
fill 128 170 363 128 173 363 minecraft:stone
setblock 129 170 325 minecraft:light[level=15]
setblock 129 170 333 minecraft:light[level=15]
setblock 129 170 341 minecraft:light[level=15]
setblock 129 170 349 minecraft:light[level=15]
setblock 129 170 357 minecraft:light[level=15]
setblock 132 170 353 minecraft:stripped_spruce_log
setblock 132 170 354 minecraft:stone
setblock 132 170 364 minecraft:deepslate
setblock 133 170 332 minecraft:stripped_spruce_log
setblock 133 170 333 minecraft:stone
fill 133 170 335 133 170 336 minecraft:stone
setblock 133 170 348 minecraft:stone
setblock 133 170 352 minecraft:stripped_spruce_log
fill 133 170 353 133 171 353 minecraft:stone
setblock 134 170 331 minecraft:stripped_spruce_log
fill 134 170 332 134 172 332 minecraft:stone
setblock 134 170 335 minecraft:stone
setblock 134 170 336 minecraft:stripped_spruce_log
fill 134 170 337 134 173 337 minecraft:stone
setblock 134 170 346 minecraft:stripped_spruce_log
setblock 134 170 347 minecraft:stone
setblock 134 170 351 minecraft:stripped_spruce_log
fill 134 170 352 134 172 352 minecraft:stone
setblock 134 170 356 minecraft:stripped_spruce_log
fill 134 170 357 134 171 357 minecraft:stone
setblock 135 170 330 minecraft:stripped_spruce_log
fill 135 170 331 135 173 331 minecraft:stone
setblock 135 170 335 minecraft:stripped_spruce_log
fill 135 170 336 135 173 336 minecraft:stone
setblock 135 170 340 minecraft:stripped_spruce_log
fill 135 170 341 135 173 341 minecraft:stone
setblock 135 170 345 minecraft:stripped_spruce_log
fill 135 170 346 135 171 346 minecraft:stone
setblock 135 170 350 minecraft:stripped_spruce_log
fill 135 170 351 135 172 351 minecraft:stone
setblock 135 170 355 minecraft:stripped_spruce_log
fill 135 170 356 135 173 356 minecraft:stone
setblock 94 171 324 minecraft:andesite
setblock 94 171 329 minecraft:raw_gold_block
setblock 94 171 337 minecraft:andesite
setblock 94 171 341 minecraft:andesite
fill 94 171 353 94 172 353 minecraft:andesite
fill 95 171 326 95 171 328 minecraft:stone
setblock 95 171 329 minecraft:stripped_spruce_log
fill 95 171 330 95 171 333 minecraft:stone
setblock 95 171 334 minecraft:stripped_spruce_log
fill 95 171 335 95 171 338 minecraft:stone
setblock 95 171 339 minecraft:stripped_spruce_log
fill 95 171 340 95 172 340 minecraft:stone
setblock 95 171 354 minecraft:stripped_spruce_log
setblock 95 171 355 minecraft:stone
fill 96 171 324 96 174 324 minecraft:spruce_log
fill 96 171 329 96 171 332 minecraft:stone
setblock 96 171 333 minecraft:stripped_spruce_log
fill 96 171 334 96 174 334 minecraft:stone
fill 96 171 343 96 174 343 minecraft:spruce_log
fill 96 171 362 96 174 362 minecraft:spruce_log
setblock 99 171 322 minecraft:andesite
fill 103 171 323 105 171 323 minecraft:stone
fill 104 171 363 105 171 363 minecraft:stone
fill 105 171 322 105 174 322 minecraft:deepslate
setblock 105 171 324 minecraft:stripped_spruce_log
setblock 106 171 323 minecraft:stripped_spruce_log
fill 106 171 324 109 171 324 minecraft:stone
setblock 106 171 362 minecraft:stone
setblock 106 171 363 minecraft:stripped_spruce_log
fill 107 171 323 110 171 323 minecraft:stone
setblock 107 171 362 minecraft:stripped_spruce_log
fill 107 171 363 110 171 363 minecraft:stone
setblock 107 171 364 minecraft:andesite
fill 108 171 362 108 174 362 minecraft:stone
setblock 109 171 322 minecraft:andesite
setblock 110 171 324 minecraft:stripped_spruce_log
setblock 111 171 323 minecraft:stripped_spruce_log
setblock 111 171 324 minecraft:stone
setblock 111 171 363 minecraft:stripped_spruce_log
fill 112 171 323 112 172 323 minecraft:stone
setblock 112 171 362 minecraft:stripped_spruce_log
fill 112 171 363 112 174 363 minecraft:stone
setblock 113 171 362 minecraft:stone
fill 115 171 324 115 174 324 minecraft:spruce_log
fill 115 171 362 115 174 362 minecraft:spruce_log
setblock 116 171 363 minecraft:stripped_spruce_log
setblock 116 171 364 minecraft:andesite
setblock 117 171 322 minecraft:andesite
fill 119 171 322 120 174 322 minecraft:deepslate
fill 121 171 322 122 171 322 minecraft:andesite
fill 124 171 363 125 171 363 minecraft:stone
setblock 124 171 364 minecraft:andesite
setblock 126 171 363 minecraft:stripped_spruce_log
fill 127 171 363 127 174 363 minecraft:stone
fill 131 171 364 132 171 364 minecraft:andesite
setblock 133 171 335 minecraft:stone
setblock 133 171 351 minecraft:stripped_spruce_log
setblock 133 171 352 minecraft:stone
fill 134 171 324 134 174 324 minecraft:spruce_log
setblock 134 171 330 minecraft:stripped_spruce_log
setblock 134 171 331 minecraft:stone
setblock 134 171 335 minecraft:stripped_spruce_log
fill 134 171 336 134 174 336 minecraft:stone
fill 134 171 343 134 174 343 minecraft:spruce_log
setblock 134 171 350 minecraft:stripped_spruce_log
fill 134 171 351 134 172 351 minecraft:stone
setblock 134 171 355 minecraft:stripped_spruce_log
fill 134 171 356 134 172 356 minecraft:stone
fill 134 171 362 134 174 362 minecraft:spruce_log
setblock 135 171 329 minecraft:stripped_spruce_log
fill 135 171 330 135 172 330 minecraft:stone
setblock 135 171 334 minecraft:stripped_spruce_log
fill 135 171 335 135 174 335 minecraft:stone
setblock 135 171 339 minecraft:stripped_spruce_log
fill 135 171 340 135 174 340 minecraft:stone
setblock 135 171 344 minecraft:stripped_spruce_log
setblock 135 171 345 minecraft:stone
setblock 135 171 349 minecraft:stripped_spruce_log
fill 135 171 350 135 172 350 minecraft:stone
setblock 135 171 354 minecraft:stripped_spruce_log
fill 135 171 355 135 173 355 minecraft:stone
setblock 136 171 325 minecraft:andesite
setblock 136 171 330 minecraft:raw_gold_block
setblock 136 171 337 minecraft:diamond_block
fill 136 171 338 136 171 340 minecraft:andesite
setblock 136 171 357 minecraft:andesite
fill 94 172 324 94 173 324 minecraft:deepslate
setblock 94 172 329 minecraft:andesite
fill 94 172 337 94 174 337 minecraft:deepslate
fill 94 172 341 94 174 341 minecraft:deepslate
setblock 95 172 328 minecraft:stripped_spruce_log
fill 95 172 329 95 172 332 minecraft:stone
setblock 95 172 333 minecraft:stripped_spruce_log
fill 95 172 334 95 172 337 minecraft:stone
setblock 95 172 338 minecraft:stripped_spruce_log
fill 95 172 339 95 175 339 minecraft:stone
setblock 96 172 331 minecraft:stone
setblock 96 172 332 minecraft:stripped_spruce_log
fill 96 172 333 96 173 333 minecraft:stone
fill 99 172 322 99 174 322 minecraft:deepslate
fill 103 172 323 104 172 323 minecraft:stone
setblock 104 172 363 minecraft:stone
fill 104 172 364 104 174 364 minecraft:deepslate
setblock 105 172 323 minecraft:stripped_spruce_log
fill 105 172 324 108 172 324 minecraft:stone
setblock 105 172 363 minecraft:stripped_spruce_log
setblock 105 172 364 minecraft:andesite
fill 106 172 323 109 172 323 minecraft:stone
setblock 106 172 362 minecraft:stripped_spruce_log
fill 106 172 363 109 172 363 minecraft:stone
fill 107 172 362 107 175 362 minecraft:stone
fill 107 172 364 107 174 364 minecraft:deepslate
fill 109 172 322 109 175 322 minecraft:deepslate
setblock 109 172 324 minecraft:stripped_spruce_log
setblock 110 172 323 minecraft:stripped_spruce_log
setblock 110 172 324 minecraft:stone
setblock 110 172 363 minecraft:stripped_spruce_log
fill 111 172 323 111 174 323 minecraft:stone
setblock 111 172 362 minecraft:stripped_spruce_log
fill 111 172 363 111 175 363 minecraft:stone
fill 112 172 362 112 175 362 minecraft:stone
setblock 112 172 364 minecraft:andesite
setblock 115 172 363 minecraft:stripped_spruce_log
fill 116 172 364 116 174 364 minecraft:deepslate
fill 117 172 322 117 174 322 minecraft:deepslate
fill 118 172 364 120 172 364 minecraft:andesite
fill 121 172 322 122 172 322 minecraft:deepslate
setblock 124 172 363 minecraft:stone
setblock 124 172 364 minecraft:deepslate
setblock 125 172 363 minecraft:stripped_spruce_log
fill 126 172 363 126 175 363 minecraft:stone
setblock 127 172 364 minecraft:andesite
setblock 129 172 364 minecraft:andesite
setblock 130 172 322 minecraft:andesite
setblock 130 172 363 minecraft:stripped_spruce_log
setblock 131 172 364 minecraft:andesite
fill 132 172 364 132 174 364 minecraft:deepslate
setblock 134 172 334 minecraft:stripped_spruce_log
fill 134 172 335 134 175 335 minecraft:stone
setblock 134 172 339 minecraft:stripped_spruce_log
setblock 134 172 354 minecraft:stripped_spruce_log
setblock 134 172 355 minecraft:stone
setblock 135 172 333 minecraft:stripped_spruce_log
fill 135 172 334 135 175 334 minecraft:stone
setblock 135 172 338 minecraft:stripped_spruce_log
fill 135 172 339 135 175 339 minecraft:stone
setblock 135 172 349 minecraft:stone
setblock 135 172 353 minecraft:stripped_spruce_log
fill 135 172 354 135 173 354 minecraft:stone
setblock 135 172 358 minecraft:stripped_spruce_log
fill 136 172 325 136 174 325 minecraft:deepslate
fill 136 172 330 136 174 330 minecraft:deepslate
fill 136 172 337 136 174 340 minecraft:deepslate
setblock 136 172 342 minecraft:andesite
fill 136 172 348 136 174 348 minecraft:deepslate
fill 136 172 349 136 172 350 minecraft:andesite
fill 136 172 357 136 174 357 minecraft:deepslate
fill 136 172 359 136 173 359 minecraft:andesite
fill 136 172 360 136 174 360 minecraft:deepslate
fill 136 172 362 136 174 363 minecraft:deepslate
fill 136 172 364 136 173 364 minecraft:andesite
fill 94 173 329 94 174 329 minecraft:deepslate
setblock 94 173 334 minecraft:andesite
fill 94 173 335 94 174 335 minecraft:deepslate
setblock 94 173 342 minecraft:andesite
fill 94 173 353 94 174 353 minecraft:deepslate
fill 95 173 329 95 173 331 minecraft:stone
setblock 95 173 332 minecraft:stripped_spruce_log
fill 95 173 333 95 173 336 minecraft:stone
setblock 95 173 337 minecraft:stripped_spruce_log
fill 95 173 338 95 176 338 minecraft:stone
setblock 96 173 332 minecraft:stone
setblock 96 173 336 minecraft:stripped_spruce_log
setblock 100 173 322 minecraft:raw_gold_block
setblock 101 173 364 minecraft:andesite
setblock 103 173 323 minecraft:stone
setblock 103 173 363 minecraft:stone
setblock 104 173 323 minecraft:stripped_spruce_log
setblock 104 173 363 minecraft:stripped_spruce_log
fill 105 173 323 108 173 323 minecraft:stone
setblock 105 173 362 minecraft:stripped_spruce_log
fill 105 173 363 108 173 363 minecraft:stone
fill 105 173 364 105 174 364 minecraft:deepslate
fill 106 173 324 107 173 324 minecraft:stone
fill 106 173 362 106 176 362 minecraft:stone
setblock 107 173 322 minecraft:raw_gold_block
setblock 108 173 324 minecraft:stripped_spruce_log
setblock 108 173 364 minecraft:andesite
setblock 109 173 323 minecraft:stripped_spruce_log
setblock 109 173 363 minecraft:stripped_spruce_log
fill 110 173 323 110 176 323 minecraft:stone
setblock 110 173 362 minecraft:stripped_spruce_log
fill 110 173 363 110 176 363 minecraft:stone
fill 111 173 362 111 176 362 minecraft:stone
fill 112 173 364 112 175 364 minecraft:deepslate
setblock 113 173 322 minecraft:andesite
fill 114 173 322 114 175 322 minecraft:deepslate
setblock 114 173 363 minecraft:stripped_spruce_log
setblock 115 173 322 minecraft:andesite
setblock 115 173 364 minecraft:andesite
setblock 118 173 364 minecraft:andesite
fill 119 173 364 120 174 364 minecraft:deepslate
fill 121 173 322 121 174 322 minecraft:deepslate
setblock 122 173 322 minecraft:andesite
fill 122 173 364 124 173 364 minecraft:andesite
setblock 123 173 363 minecraft:stone
setblock 124 173 363 minecraft:stripped_spruce_log
fill 125 173 363 125 176 363 minecraft:stone
fill 127 173 364 127 175 364 minecraft:deepslate
setblock 129 173 363 minecraft:stripped_spruce_log
fill 129 173 364 129 174 364 minecraft:deepslate
fill 130 173 322 130 174 322 minecraft:deepslate
fill 131 173 364 131 175 364 minecraft:deepslate
setblock 133 173 364 minecraft:raw_gold_block
setblock 134 173 333 minecraft:stripped_spruce_log
fill 134 173 334 134 174 334 minecraft:stone
setblock 134 173 338 minecraft:stripped_spruce_log
setblock 135 173 332 minecraft:stripped_spruce_log
fill 135 173 333 135 176 333 minecraft:stone
setblock 135 173 337 minecraft:stripped_spruce_log
fill 135 173 338 135 176 338 minecraft:stone
setblock 135 173 352 minecraft:stripped_spruce_log
setblock 135 173 353 minecraft:stone
setblock 136 173 333 minecraft:andesite
fill 136 173 342 136 174 342 minecraft:deepslate
setblock 136 173 343 minecraft:andesite
fill 136 173 349 136 174 350 minecraft:deepslate
setblock 136 173 353 minecraft:andesite
setblock 136 173 355 minecraft:andesite
setblock 136 173 358 minecraft:andesite
setblock 94 174 324 minecraft:raw_iron_block
setblock 94 174 334 minecraft:deepslate
setblock 94 174 342 minecraft:deepslate
setblock 95 174 330 minecraft:stone
setblock 95 174 331 minecraft:stripped_spruce_log
fill 95 174 332 95 174 335 minecraft:stone
setblock 95 174 336 minecraft:stripped_spruce_log
fill 95 174 337 95 176 337 minecraft:stone
setblock 96 174 335 minecraft:stripped_spruce_log
setblock 97 174 325 minecraft:light[level=12]
setblock 97 174 332 minecraft:light[level=12]
setblock 97 174 339 minecraft:light[level=12]
setblock 97 174 346 minecraft:light[level=12]
setblock 97 174 353 minecraft:light[level=12]
setblock 97 174 360 minecraft:light[level=12]
setblock 100 174 322 minecraft:deepslate
setblock 101 174 364 minecraft:deepslate
setblock 102 174 323 minecraft:stone
setblock 102 174 363 minecraft:stone
setblock 102 174 364 minecraft:gold_block
setblock 103 174 323 minecraft:stripped_spruce_log
setblock 103 174 363 minecraft:stripped_spruce_log
fill 104 174 323 107 174 323 minecraft:stone
setblock 104 174 325 minecraft:light[level=12]
setblock 104 174 332 minecraft:light[level=12]
setblock 104 174 339 minecraft:light[level=12]
setblock 104 174 346 minecraft:light[level=12]
setblock 104 174 353 minecraft:light[level=12]
setblock 104 174 360 minecraft:light[level=12]
setblock 104 174 362 minecraft:stripped_spruce_log
fill 104 174 363 107 174 363 minecraft:stone
fill 105 174 362 105 176 362 minecraft:stone
setblock 106 174 324 minecraft:stone
setblock 107 174 322 minecraft:deepslate
setblock 107 174 324 minecraft:stripped_spruce_log
fill 107 174 361 109 174 361 minecraft:stone
setblock 108 174 323 minecraft:stripped_spruce_log
setblock 108 174 363 minecraft:stripped_spruce_log
setblock 108 174 364 minecraft:deepslate
fill 109 174 323 109 176 323 minecraft:stone
setblock 109 174 362 minecraft:stripped_spruce_log
fill 109 174 363 109 176 363 minecraft:stone
fill 110 174 362 110 176 362 minecraft:stone
setblock 111 174 325 minecraft:light[level=12]
setblock 111 174 332 minecraft:light[level=12]
setblock 111 174 339 minecraft:light[level=12]
setblock 111 174 346 minecraft:light[level=12]
setblock 111 174 353 minecraft:light[level=12]
setblock 111 174 360 minecraft:light[level=12]
setblock 113 174 322 minecraft:deepslate
setblock 113 174 363 minecraft:stripped_spruce_log
fill 114 174 363 114 176 363 minecraft:stone
setblock 115 174 322 minecraft:deepslate
setblock 115 174 364 minecraft:deepslate
setblock 118 174 325 minecraft:light[level=12]
setblock 118 174 332 minecraft:light[level=12]
setblock 118 174 339 minecraft:light[level=12]
setblock 118 174 346 minecraft:light[level=12]
setblock 118 174 353 minecraft:light[level=12]
setblock 118 174 360 minecraft:light[level=12]
setblock 118 174 364 minecraft:deepslate
setblock 122 174 322 minecraft:deepslate
setblock 122 174 363 minecraft:stone
fill 122 174 364 124 174 364 minecraft:deepslate
setblock 123 174 363 minecraft:stripped_spruce_log
fill 124 174 363 124 176 363 minecraft:stone
setblock 125 174 325 minecraft:light[level=12]
setblock 125 174 332 minecraft:light[level=12]
setblock 125 174 339 minecraft:light[level=12]
setblock 125 174 346 minecraft:light[level=12]
setblock 125 174 353 minecraft:light[level=12]
setblock 125 174 360 minecraft:light[level=12]
fill 125 174 362 127 175 362 minecraft:stone
setblock 128 174 363 minecraft:stripped_spruce_log
fill 129 174 363 129 176 363 minecraft:stone
setblock 132 174 325 minecraft:light[level=12]
setblock 132 174 332 minecraft:light[level=12]
setblock 132 174 339 minecraft:light[level=12]
setblock 132 174 346 minecraft:light[level=12]
setblock 132 174 353 minecraft:light[level=12]
setblock 132 174 360 minecraft:light[level=12]
setblock 133 174 364 minecraft:deepslate
setblock 134 174 337 minecraft:stripped_spruce_log
fill 134 174 338 134 176 338 minecraft:stone
setblock 135 174 331 minecraft:stripped_spruce_log
fill 135 174 332 135 176 332 minecraft:stone
setblock 135 174 336 minecraft:stripped_spruce_log
fill 135 174 337 135 176 337 minecraft:stone
setblock 135 174 341 minecraft:stripped_spruce_log
setblock 136 174 333 minecraft:deepslate
setblock 136 174 343 minecraft:deepslate
setblock 136 174 353 minecraft:deepslate
setblock 136 174 355 minecraft:deepslate
fill 136 174 358 136 174 359 minecraft:deepslate
setblock 136 174 364 minecraft:deepslate
fill 94 175 323 94 180 323 minecraft:andesite
setblock 94 175 324 minecraft:deepslate
fill 94 175 325 94 175 348 minecraft:andesite
fill 94 175 350 94 176 350 minecraft:andesite
fill 94 175 352 94 175 359 minecraft:andesite
fill 94 175 361 94 175 364 minecraft:andesite
fill 95 175 322 95 176 322 minecraft:andesite
setblock 95 175 330 minecraft:stripped_spruce_log
fill 95 175 331 95 175 334 minecraft:stone
setblock 95 175 335 minecraft:stripped_spruce_log
fill 95 175 336 95 176 336 minecraft:stone
fill 95 175 364 95 176 364 minecraft:deepslate
setblock 96 175 322 minecraft:diamond_block
setblock 96 175 324 minecraft:glowstone
setblock 96 175 343 minecraft:glowstone
setblock 96 175 362 minecraft:glowstone
fill 96 175 364 96 219 364 minecraft:andesite
fill 97 175 322 108 175 322 minecraft:andesite
fill 98 175 364 101 207 364 minecraft:andesite
setblock 101 175 323 minecraft:stone
setblock 101 175 363 minecraft:stone
setblock 102 175 323 minecraft:stripped_spruce_log
setblock 102 175 363 minecraft:stripped_spruce_log
fill 102 175 364 102 176 364 minecraft:deepslate
fill 103 175 323 106 175 323 minecraft:stone
setblock 103 175 362 minecraft:stripped_spruce_log
fill 103 175 363 106 175 363 minecraft:stone
fill 103 175 364 108 175 364 minecraft:andesite
fill 104 175 362 104 176 362 minecraft:stone
setblock 105 175 324 minecraft:stone
fill 105 175 361 108 175 361 minecraft:stone
setblock 106 175 324 minecraft:stripped_spruce_log
setblock 107 175 323 minecraft:stripped_spruce_log
fill 107 175 324 107 176 324 minecraft:stone
setblock 107 175 363 minecraft:stripped_spruce_log
fill 108 175 323 108 176 323 minecraft:stone
setblock 108 175 362 minecraft:stripped_spruce_log
fill 108 175 363 108 176 363 minecraft:stone
setblock 109 175 361 minecraft:stripped_spruce_log
fill 109 175 362 109 176 362 minecraft:stone
fill 110 175 322 110 202 322 minecraft:andesite
fill 110 175 361 110 178 361 minecraft:stone
fill 110 175 364 111 184 364 minecraft:andesite
fill 112 175 322 113 200 322 minecraft:andesite
setblock 112 175 363 minecraft:stripped_spruce_log
fill 113 175 363 113 176 363 minecraft:stone
fill 113 175 364 119 176 364 minecraft:andesite
fill 115 175 322 122 177 322 minecraft:andesite
setblock 115 175 324 minecraft:glowstone
setblock 115 175 362 minecraft:glowstone
fill 115 175 363 115 176 363 minecraft:stone
fill 120 175 363 121 175 363 minecraft:stone
setblock 120 175 364 minecraft:deepslate
fill 121 175 364 126 179 364 minecraft:andesite
setblock 122 175 363 minecraft:stripped_spruce_log
setblock 123 175 362 minecraft:stripped_spruce_log
fill 123 175 363 123 176 363 minecraft:stone
fill 124 175 322 135 175 322 minecraft:andesite
fill 124 175 362 124 176 362 minecraft:stone
setblock 127 175 363 minecraft:stripped_spruce_log
fill 128 175 363 128 176 363 minecraft:stone
fill 128 175 364 130 175 364 minecraft:andesite
fill 132 175 364 136 175 364 minecraft:andesite
setblock 134 175 324 minecraft:glowstone
setblock 134 175 336 minecraft:stripped_spruce_log
fill 134 175 337 134 176 337 minecraft:stone
fill 134 175 339 134 176 339 minecraft:stone
setblock 134 175 343 minecraft:glowstone
setblock 134 175 362 minecraft:glowstone
setblock 135 175 335 minecraft:stripped_spruce_log
fill 135 175 336 135 176 336 minecraft:stone
setblock 135 175 340 minecraft:stripped_spruce_log
fill 135 175 341 135 176 341 minecraft:stone
fill 136 175 323 136 175 336 minecraft:andesite
setblock 136 175 337 minecraft:deepslate
fill 136 175 338 136 175 362 minecraft:andesite
setblock 136 175 363 minecraft:deepslate
setblock 94 176 322 minecraft:andesite
fill 94 176 324 94 176 329 minecraft:andesite
fill 94 176 330 94 176 331 minecraft:deepslate
fill 94 176 332 94 176 349 minecraft:andesite
fill 94 176 351 94 212 353 minecraft:andesite
fill 94 176 354 94 177 354 minecraft:deepslate
fill 94 176 355 94 239 355 minecraft:andesite
setblock 94 176 356 minecraft:deepslate
fill 94 176 357 94 182 361 minecraft:andesite
fill 94 176 362 94 176 363 minecraft:deepslate
setblock 94 176 364 minecraft:andesite
fill 95 176 331 95 176 333 minecraft:stone
setblock 95 176 334 minecraft:stripped_spruce_log
setblock 95 176 335 minecraft:stone
setblock 95 176 339 minecraft:stripped_spruce_log
setblock 95 176 340 minecraft:stone
fill 96 176 322 98 176 322 minecraft:andesite
fill 96 176 324 96 177 324 minecraft:spruce_log
fill 96 176 343 96 177 343 minecraft:spruce_log
fill 96 176 362 96 177 362 minecraft:spruce_log
fill 97 176 364 97 241 364 minecraft:andesite
setblock 99 176 322 minecraft:deepslate
fill 100 176 322 104 176 322 minecraft:andesite
setblock 100 176 323 minecraft:stone
setblock 100 176 363 minecraft:stone
setblock 101 176 323 minecraft:stripped_spruce_log
setblock 101 176 363 minecraft:stripped_spruce_log
fill 102 176 323 105 176 323 minecraft:stone
setblock 102 176 362 minecraft:stripped_spruce_log
fill 102 176 363 105 176 363 minecraft:stone
setblock 103 176 362 minecraft:stone
fill 103 176 364 106 177 364 minecraft:andesite
setblock 104 176 324 minecraft:stone
fill 104 176 361 107 176 361 minecraft:stone
setblock 105 176 322 minecraft:raw_gold_block
setblock 105 176 324 minecraft:stripped_spruce_log
fill 106 176 322 108 238 322 minecraft:andesite
setblock 106 176 323 minecraft:stripped_spruce_log
setblock 106 176 324 minecraft:stone
setblock 106 176 363 minecraft:stripped_spruce_log
setblock 107 176 323 minecraft:stone
setblock 107 176 362 minecraft:stripped_spruce_log
setblock 107 176 363 minecraft:stone
setblock 107 176 364 minecraft:raw_iron_block
setblock 108 176 361 minecraft:stripped_spruce_log
setblock 108 176 362 minecraft:stone
fill 108 176 364 109 203 364 minecraft:andesite
setblock 109 176 322 minecraft:gold_block
fill 109 176 361 109 179 361 minecraft:stone
fill 111 176 322 111 207 322 minecraft:andesite
setblock 111 176 363 minecraft:stripped_spruce_log
setblock 112 176 362 minecraft:stripped_spruce_log
setblock 112 176 363 minecraft:stone
fill 112 176 364 112 199 364 minecraft:andesite
setblock 113 176 362 minecraft:stone
fill 114 176 322 114 238 322 minecraft:andesite
fill 115 176 324 115 177 324 minecraft:spruce_log
fill 115 176 362 115 177 362 minecraft:spruce_log
setblock 116 176 363 minecraft:stripped_spruce_log
fill 117 176 363 120 176 363 minecraft:stone
fill 120 176 364 120 216 364 minecraft:andesite
setblock 121 176 362 minecraft:stone
setblock 121 176 363 minecraft:stripped_spruce_log
setblock 122 176 362 minecraft:stripped_spruce_log
setblock 122 176 363 minecraft:stone
fill 123 176 322 127 176 322 minecraft:andesite
setblock 123 176 362 minecraft:stone
fill 125 176 361 125 176 362 minecraft:stone
setblock 126 176 362 minecraft:stone
setblock 126 176 363 minecraft:stripped_spruce_log
setblock 127 176 362 minecraft:stripped_spruce_log
setblock 127 176 363 minecraft:stone
fill 127 176 364 127 241 364 minecraft:andesite
setblock 128 176 322 minecraft:raw_gold_block
setblock 128 176 362 minecraft:stone
setblock 128 176 364 minecraft:deepslate
fill 129 176 322 130 180 322 minecraft:andesite
fill 129 176 364 131 219 364 minecraft:andesite
setblock 131 176 322 minecraft:gold_block
fill 132 176 322 136 176 322 minecraft:andesite
setblock 132 176 364 minecraft:deepslate
fill 133 176 364 136 176 364 minecraft:andesite
fill 134 176 324 134 177 324 minecraft:spruce_log
setblock 134 176 335 minecraft:stripped_spruce_log
setblock 134 176 336 minecraft:stone
fill 134 176 343 134 177 343 minecraft:spruce_log
fill 134 176 362 134 177 362 minecraft:spruce_log
setblock 135 176 334 minecraft:stripped_spruce_log
setblock 135 176 335 minecraft:stone
setblock 135 176 339 minecraft:stripped_spruce_log
setblock 135 176 340 minecraft:stone
setblock 135 176 342 minecraft:stone
fill 136 176 323 136 176 326 minecraft:andesite
setblock 136 176 327 minecraft:deepslate
fill 136 176 328 136 181 335 minecraft:andesite
fill 136 176 336 136 177 336 minecraft:deepslate
fill 136 176 337 136 177 341 minecraft:andesite
setblock 136 176 342 minecraft:deepslate
fill 136 176 343 136 183 347 minecraft:andesite
setblock 136 176 348 minecraft:deepslate
fill 136 176 349 136 176 350 minecraft:andesite
fill 136 176 351 136 176 352 minecraft:deepslate
setblock 136 176 353 minecraft:gold_block
fill 136 176 354 136 241 354 minecraft:andesite
setblock 136 176 355 minecraft:deepslate
fill 136 176 356 136 185 363 minecraft:andesite
fill 94 177 322 98 177 322 minecraft:deepslate
fill 94 177 324 94 209 324 minecraft:andesite
setblock 94 177 325 minecraft:deepslate
fill 94 177 326 94 185 329 minecraft:andesite
setblock 94 177 330 minecraft:deepslate
fill 94 177 331 94 177 346 minecraft:andesite
setblock 94 177 347 minecraft:deepslate
fill 94 177 348 94 241 349 minecraft:andesite
setblock 94 177 350 minecraft:deepslate
setblock 94 177 356 minecraft:raw_iron_block
fill 94 177 362 94 196 363 minecraft:andesite
setblock 94 177 364 minecraft:deepslate
fill 95 177 323 95 177 363 minecraft:spruce_planks
fill 95 177 364 95 221 364 minecraft:andesite
fill 96 177 323 135 177 323 minecraft:spruce_planks
fill 96 177 325 96 177 342 minecraft:spruce_planks
fill 96 177 344 96 177 361 minecraft:spruce_planks
fill 96 177 363 135 177 363 minecraft:spruce_planks
fill 97 177 324 114 177 324 minecraft:spruce_planks
fill 97 177 362 114 177 362 minecraft:spruce_planks
fill 99 177 322 101 186 322 minecraft:andesite
setblock 102 177 322 minecraft:raw_gold_block
setblock 102 177 361 minecraft:stripped_spruce_log
fill 102 177 364 102 218 364 minecraft:andesite
fill 103 177 322 105 183 322 minecraft:andesite
fill 103 177 361 106 177 361 minecraft:stone
fill 106 177 360 107 177 360 minecraft:stone
setblock 107 177 361 minecraft:stripped_spruce_log
fill 107 177 364 107 211 364 minecraft:andesite
fill 108 177 361 108 180 361 minecraft:stone
fill 109 177 322 109 241 322 minecraft:andesite
setblock 111 177 361 minecraft:stone
fill 113 177 364 114 191 364 minecraft:andesite
setblock 115 177 364 minecraft:deepslate
fill 116 177 324 133 177 324 minecraft:spruce_planks
fill 116 177 362 133 177 362 minecraft:spruce_planks
fill 116 177 364 119 234 364 minecraft:andesite
setblock 122 177 361 minecraft:stripped_spruce_log
fill 123 177 322 124 218 322 minecraft:andesite
fill 123 177 361 126 177 361 minecraft:stone
setblock 125 177 322 minecraft:deepslate
fill 126 177 322 126 212 322 minecraft:andesite
setblock 127 177 322 minecraft:deepslate
fill 128 177 322 128 193 322 minecraft:andesite
fill 128 177 364 128 239 364 minecraft:andesite
fill 131 177 322 132 177 322 minecraft:deepslate
fill 132 177 364 132 221 364 minecraft:andesite
fill 133 177 322 136 201 322 minecraft:andesite
setblock 133 177 364 minecraft:deepslate
fill 134 177 325 135 177 342 minecraft:spruce_planks
fill 134 177 344 135 177 361 minecraft:spruce_planks
fill 134 177 364 135 191 364 minecraft:andesite
setblock 135 177 324 minecraft:spruce_planks
setblock 135 177 343 minecraft:spruce_planks
setblock 135 177 362 minecraft:spruce_planks
setblock 136 177 323 minecraft:raw_iron_block
setblock 136 177 324 minecraft:deepslate
fill 136 177 325 136 185 327 minecraft:andesite
fill 136 177 342 136 241 342 minecraft:andesite
fill 136 177 348 136 202 349 minecraft:andesite
setblock 136 177 350 minecraft:gold_block
fill 136 177 351 136 241 351 minecraft:andesite
setblock 136 177 352 minecraft:deepslate
fill 136 177 353 136 241 353 minecraft:andesite
fill 136 177 355 136 198 355 minecraft:andesite
setblock 136 177 364 minecraft:deepslate
fill 94 178 322 98 195 322 minecraft:andesite
fill 94 178 325 94 241 325 minecraft:andesite
fill 94 178 330 94 182 345 minecraft:andesite
setblock 94 178 346 minecraft:diamond_block
fill 94 178 347 94 199 347 minecraft:andesite
fill 94 178 350 94 194 350 minecraft:andesite
fill 94 178 354 94 241 354 minecraft:andesite
fill 94 178 356 94 209 356 minecraft:andesite
fill 94 178 364 94 237 364 minecraft:andesite
setblock 95 178 331 minecraft:stone
setblock 95 178 332 minecraft:stripped_spruce_log
fill 95 178 333 95 178 336 minecraft:stone
setblock 95 178 337 minecraft:stripped_spruce_log
fill 95 178 338 95 178 341 minecraft:stone
fill 96 178 323 98 178 323 minecraft:stone
setblock 96 178 335 minecraft:stone
setblock 96 178 336 minecraft:stripped_spruce_log
fill 96 178 337 96 180 338 minecraft:stone
setblock 97 178 325 minecraft:light[level=15]
setblock 97 178 333 minecraft:light[level=15]
setblock 97 178 341 minecraft:light[level=15]
setblock 97 178 349 minecraft:light[level=15]
setblock 97 178 357 minecraft:light[level=15]
fill 97 178 363 98 178 363 minecraft:stone
setblock 99 178 323 minecraft:stripped_spruce_log
setblock 99 178 362 minecraft:stone
setblock 99 178 363 minecraft:stripped_spruce_log
fill 100 178 323 102 178 324 minecraft:stone
setblock 100 178 362 minecraft:stripped_spruce_log
fill 100 178 363 103 178 363 minecraft:stone
setblock 101 178 361 minecraft:stripped_spruce_log
fill 101 178 362 104 178 362 minecraft:stone
fill 102 178 322 102 210 322 minecraft:andesite
fill 102 178 361 105 178 361 minecraft:stone
setblock 103 178 323 minecraft:stone
setblock 103 178 324 minecraft:stripped_spruce_log
setblock 103 178 364 minecraft:raw_iron_block
setblock 104 178 323 minecraft:stripped_spruce_log
fill 104 178 324 107 178 324 minecraft:stone
fill 104 178 360 106 178 360 minecraft:stone
setblock 104 178 363 minecraft:stripped_spruce_log
fill 104 178 364 106 233 364 minecraft:andesite
fill 105 178 323 108 178 323 minecraft:stone
setblock 105 178 325 minecraft:light[level=15]
setblock 105 178 333 minecraft:light[level=15]
setblock 105 178 341 minecraft:light[level=15]
setblock 105 178 349 minecraft:light[level=15]
setblock 105 178 357 minecraft:light[level=15]
setblock 105 178 362 minecraft:stripped_spruce_log
fill 105 178 363 108 178 363 minecraft:stone
setblock 106 178 361 minecraft:stripped_spruce_log
fill 106 178 362 109 178 362 minecraft:stone
setblock 107 178 360 minecraft:stripped_spruce_log
fill 107 178 361 107 181 361 minecraft:stone
setblock 108 178 324 minecraft:stripped_spruce_log
fill 108 178 360 108 181 360 minecraft:stone
setblock 109 178 323 minecraft:stripped_spruce_log
setblock 109 178 363 minecraft:stripped_spruce_log
fill 110 178 323 111 180 323 minecraft:stone
setblock 110 178 362 minecraft:stripped_spruce_log
fill 110 178 363 113 178 363 minecraft:stone
setblock 111 178 361 minecraft:stripped_spruce_log
fill 111 178 362 114 178 362 minecraft:stone
setblock 113 178 325 minecraft:light[level=15]
setblock 113 178 333 minecraft:light[level=15]
setblock 113 178 341 minecraft:light[level=15]
setblock 113 178 349 minecraft:light[level=15]
setblock 113 178 357 minecraft:light[level=15]
setblock 114 178 363 minecraft:stripped_spruce_log
fill 115 178 322 115 192 322 minecraft:andesite
setblock 115 178 362 minecraft:stripped_spruce_log
fill 115 178 363 118 178 363 minecraft:stone
fill 115 178 364 115 237 364 minecraft:andesite
setblock 116 178 322 minecraft:gold_block
fill 116 178 362 119 178 362 minecraft:stone
fill 117 178 322 122 180 322 minecraft:andesite
setblock 119 178 363 minecraft:stripped_spruce_log
setblock 120 178 361 minecraft:stone
setblock 120 178 362 minecraft:stripped_spruce_log
fill 120 178 363 123 178 363 minecraft:stone
setblock 121 178 325 minecraft:light[level=15]
setblock 121 178 333 minecraft:light[level=15]
setblock 121 178 341 minecraft:light[level=15]
setblock 121 178 349 minecraft:light[level=15]
setblock 121 178 357 minecraft:light[level=15]
setblock 121 178 361 minecraft:stripped_spruce_log
fill 121 178 362 124 178 362 minecraft:stone
fill 122 178 361 125 178 361 minecraft:stone
setblock 123 178 323 minecraft:stone
setblock 124 178 323 minecraft:stripped_spruce_log
setblock 124 178 363 minecraft:stripped_spruce_log
fill 125 178 322 125 242 322 minecraft:andesite
fill 125 178 323 126 180 323 minecraft:stone
setblock 125 178 362 minecraft:stripped_spruce_log
fill 125 178 363 128 178 363 minecraft:stone
setblock 126 178 361 minecraft:stripped_spruce_log
fill 126 178 362 128 179 362 minecraft:stone
fill 127 178 322 127 239 322 minecraft:andesite
fill 127 178 361 127 180 361 minecraft:stone
setblock 129 178 325 minecraft:light[level=15]
setblock 129 178 333 minecraft:light[level=15]
setblock 129 178 341 minecraft:light[level=15]
setblock 129 178 349 minecraft:light[level=15]
setblock 129 178 357 minecraft:light[level=15]
setblock 129 178 363 minecraft:stripped_spruce_log
fill 130 178 363 130 181 363 minecraft:stone
fill 131 178 322 132 212 322 minecraft:andesite
fill 133 178 364 133 210 364 minecraft:andesite
fill 134 178 335 134 178 337 minecraft:stone
setblock 134 178 338 minecraft:stripped_spruce_log
fill 134 178 339 135 178 341 minecraft:stone
setblock 135 178 332 minecraft:stripped_spruce_log
fill 135 178 333 135 178 336 minecraft:stone
setblock 135 178 337 minecraft:stripped_spruce_log
fill 135 178 338 135 181 338 minecraft:stone
setblock 135 178 342 minecraft:stripped_spruce_log
fill 135 178 343 135 180 344 minecraft:stone
fill 136 178 323 136 191 324 minecraft:andesite
fill 136 178 336 136 203 339 minecraft:andesite
setblock 136 178 340 minecraft:raw_iron_block
fill 136 178 341 136 181 341 minecraft:andesite
fill 136 178 350 136 223 350 minecraft:andesite
fill 136 178 352 136 241 352 minecraft:andesite
fill 136 178 364 136 241 364 minecraft:andesite
fill 94 179 346 94 241 346 minecraft:andesite
fill 95 179 323 95 180 324 minecraft:stone
setblock 95 179 331 minecraft:stripped_spruce_log
fill 95 179 332 95 179 335 minecraft:stone
setblock 95 179 336 minecraft:stripped_spruce_log
fill 95 179 337 95 179 340 minecraft:stone
setblock 95 179 341 minecraft:stripped_spruce_log
fill 95 179 342 95 182 342 minecraft:stone
fill 95 179 359 95 179 360 minecraft:stone
setblock 95 179 361 minecraft:stripped_spruce_log
fill 95 179 362 95 181 363 minecraft:stone
fill 96 179 323 97 179 323 minecraft:stone
setblock 96 179 335 minecraft:stripped_spruce_log
fill 96 179 336 96 182 336 minecraft:stone
setblock 96 179 339 minecraft:stone
fill 96 179 363 97 179 363 minecraft:stone
setblock 98 179 323 minecraft:stripped_spruce_log
fill 98 179 324 101 179 324 minecraft:stone
setblock 98 179 362 minecraft:stone
setblock 98 179 363 minecraft:stripped_spruce_log
fill 99 179 323 102 179 323 minecraft:stone
setblock 99 179 362 minecraft:stripped_spruce_log
fill 99 179 363 102 179 363 minecraft:stone
setblock 100 179 361 minecraft:stripped_spruce_log
fill 100 179 362 103 179 362 minecraft:stone
fill 101 179 361 104 179 361 minecraft:stone
setblock 102 179 324 minecraft:stripped_spruce_log
fill 102 179 360 105 179 360 minecraft:stone
setblock 103 179 323 minecraft:stripped_spruce_log
fill 103 179 324 104 180 325 minecraft:stone
setblock 103 179 363 minecraft:stripped_spruce_log
fill 103 179 364 103 194 364 minecraft:andesite
fill 104 179 323 107 179 323 minecraft:stone
setblock 104 179 362 minecraft:stripped_spruce_log
fill 104 179 363 107 179 363 minecraft:stone
fill 105 179 324 106 179 324 minecraft:stone
setblock 105 179 361 minecraft:stripped_spruce_log
fill 105 179 362 108 179 362 minecraft:stone
setblock 106 179 360 minecraft:stripped_spruce_log
fill 106 179 361 106 182 361 minecraft:stone
setblock 107 179 324 minecraft:stripped_spruce_log
fill 107 179 360 107 182 360 minecraft:stone
setblock 108 179 323 minecraft:stripped_spruce_log
fill 108 179 324 108 182 324 minecraft:stone
setblock 108 179 363 minecraft:stripped_spruce_log
fill 109 179 323 109 182 323 minecraft:stone
setblock 109 179 362 minecraft:stripped_spruce_log
fill 109 179 363 112 179 363 minecraft:stone
setblock 110 179 361 minecraft:stripped_spruce_log
fill 110 179 362 113 179 362 minecraft:stone
fill 111 179 361 112 181 361 minecraft:stone
setblock 113 179 363 minecraft:stripped_spruce_log
setblock 114 179 362 minecraft:stripped_spruce_log
fill 114 179 363 117 179 363 minecraft:stone
fill 115 179 362 118 179 362 minecraft:stone
fill 116 179 322 116 189 322 minecraft:andesite
fill 118 179 361 119 179 361 minecraft:stone
setblock 118 179 363 minecraft:stripped_spruce_log
setblock 119 179 362 minecraft:stripped_spruce_log
fill 119 179 363 122 179 363 minecraft:stone
setblock 120 179 361 minecraft:stripped_spruce_log
fill 120 179 362 123 179 362 minecraft:stone
fill 121 179 323 122 179 323 minecraft:stone
fill 121 179 361 124 179 361 minecraft:stone
fill 122 179 360 124 180 360 minecraft:stone
setblock 123 179 323 minecraft:stripped_spruce_log
setblock 123 179 363 minecraft:stripped_spruce_log
fill 124 179 323 124 182 323 minecraft:stone
setblock 124 179 362 minecraft:stripped_spruce_log
fill 124 179 363 127 179 363 minecraft:stone
setblock 125 179 361 minecraft:stripped_spruce_log
fill 125 179 362 125 182 362 minecraft:stone
fill 126 179 361 126 182 361 minecraft:stone
setblock 127 179 323 minecraft:stone
setblock 128 179 323 minecraft:stripped_spruce_log
setblock 128 179 363 minecraft:stripped_spruce_log
setblock 129 179 362 minecraft:stripped_spruce_log
fill 129 179 363 129 182 363 minecraft:stone
fill 131 179 363 131 180 363 minecraft:stone
setblock 133 179 338 minecraft:stripped_spruce_log
fill 133 179 339 135 180 339 minecraft:stone
fill 134 179 335 134 179 336 minecraft:stone
setblock 134 179 337 minecraft:stripped_spruce_log
fill 134 179 338 134 182 338 minecraft:stone
fill 134 179 340 134 179 341 minecraft:stone
setblock 134 179 342 minecraft:stripped_spruce_log
fill 135 179 332 135 179 335 minecraft:stone
setblock 135 179 336 minecraft:stripped_spruce_log
fill 135 179 337 135 182 337 minecraft:stone
setblock 135 179 340 minecraft:stone
setblock 135 179 341 minecraft:stripped_spruce_log
fill 135 179 342 135 182 342 minecraft:stone
setblock 135 179 345 minecraft:stone
fill 136 179 340 136 241 340 minecraft:andesite
setblock 95 180 325 minecraft:stripped_spruce_log
fill 95 180 326 95 180 329 minecraft:stone
setblock 95 180 330 minecraft:stripped_spruce_log
fill 95 180 331 95 180 334 minecraft:stone
setblock 95 180 335 minecraft:stripped_spruce_log
fill 95 180 336 95 180 339 minecraft:stone
setblock 95 180 340 minecraft:stripped_spruce_log
fill 95 180 341 95 183 341 minecraft:stone
fill 95 180 343 95 181 343 minecraft:stone
setblock 95 180 359 minecraft:stone
setblock 95 180 360 minecraft:stripped_spruce_log
fill 95 180 361 95 183 361 minecraft:stone
setblock 96 180 323 minecraft:stone
fill 96 180 335 96 181 335 minecraft:stone
setblock 96 180 339 minecraft:stripped_spruce_log
fill 96 180 340 96 183 340 minecraft:stone
fill 96 180 362 96 180 363 minecraft:stone
setblock 97 180 323 minecraft:stripped_spruce_log
fill 97 180 324 100 180 324 minecraft:stone
setblock 97 180 325 minecraft:light[level=12]
setblock 97 180 332 minecraft:light[level=12]
setblock 97 180 339 minecraft:light[level=12]
setblock 97 180 346 minecraft:light[level=12]
setblock 97 180 353 minecraft:light[level=12]
setblock 97 180 360 minecraft:light[level=12]
setblock 97 180 362 minecraft:stone
setblock 97 180 363 minecraft:stripped_spruce_log
fill 98 180 323 101 180 323 minecraft:stone
setblock 98 180 362 minecraft:stripped_spruce_log
fill 98 180 363 101 180 363 minecraft:stone
setblock 99 180 361 minecraft:stripped_spruce_log
fill 99 180 362 102 180 362 minecraft:stone
fill 100 180 361 103 180 361 minecraft:stone
setblock 101 180 324 minecraft:stripped_spruce_log
fill 101 180 325 102 182 325 minecraft:stone
fill 101 180 360 104 180 360 minecraft:stone
setblock 102 180 323 minecraft:stripped_spruce_log
fill 102 180 324 102 183 324 minecraft:stone
setblock 102 180 363 minecraft:stripped_spruce_log
fill 103 180 323 106 180 323 minecraft:stone
setblock 103 180 362 minecraft:stripped_spruce_log
fill 103 180 363 106 180 363 minecraft:stone
setblock 104 180 332 minecraft:light[level=12]
setblock 104 180 339 minecraft:light[level=12]
setblock 104 180 346 minecraft:light[level=12]
setblock 104 180 353 minecraft:light[level=12]
setblock 104 180 361 minecraft:stripped_spruce_log
fill 104 180 362 107 180 362 minecraft:stone
setblock 105 180 324 minecraft:stone
setblock 105 180 325 minecraft:stripped_spruce_log
setblock 105 180 360 minecraft:stripped_spruce_log
fill 105 180 361 105 183 361 minecraft:stone
setblock 106 180 324 minecraft:stripped_spruce_log
fill 106 180 360 106 183 360 minecraft:stone
setblock 107 180 323 minecraft:stripped_spruce_log
fill 107 180 324 107 183 324 minecraft:stone
setblock 107 180 363 minecraft:stripped_spruce_log
fill 108 180 323 108 183 323 minecraft:stone
setblock 108 180 362 minecraft:stripped_spruce_log
fill 108 180 363 111 180 363 minecraft:stone
setblock 109 180 361 minecraft:stripped_spruce_log
fill 109 180 362 112 180 362 minecraft:stone
fill 110 180 361 110 183 361 minecraft:stone
setblock 111 180 325 minecraft:light[level=12]
setblock 111 180 332 minecraft:light[level=12]
setblock 111 180 339 minecraft:light[level=12]
setblock 111 180 346 minecraft:light[level=12]
setblock 111 180 353 minecraft:light[level=12]
setblock 111 180 360 minecraft:light[level=12]
setblock 112 180 323 minecraft:stripped_spruce_log
setblock 112 180 363 minecraft:stripped_spruce_log
setblock 113 180 361 minecraft:stone
setblock 113 180 362 minecraft:stripped_spruce_log
fill 113 180 363 116 180 363 minecraft:stone
fill 114 180 362 117 180 362 minecraft:stone
fill 115 180 361 118 180 361 minecraft:stone
setblock 117 180 363 minecraft:stripped_spruce_log
fill 118 180 323 121 180 323 minecraft:stone
setblock 118 180 325 minecraft:light[level=12]
setblock 118 180 332 minecraft:light[level=12]
setblock 118 180 339 minecraft:light[level=12]
setblock 118 180 346 minecraft:light[level=12]
setblock 118 180 353 minecraft:light[level=12]
setblock 118 180 360 minecraft:light[level=12]
setblock 118 180 362 minecraft:stripped_spruce_log
fill 118 180 363 121 180 363 minecraft:stone
setblock 119 180 361 minecraft:stripped_spruce_log
fill 119 180 362 122 180 362 minecraft:stone
fill 120 180 361 123 180 361 minecraft:stone
fill 121 180 360 121 182 360 minecraft:stone
setblock 121 180 364 minecraft:diamond_block
setblock 122 180 323 minecraft:stripped_spruce_log
setblock 122 180 363 minecraft:stripped_spruce_log
fill 122 180 364 126 185 364 minecraft:andesite
fill 123 180 323 123 183 323 minecraft:stone
setblock 123 180 362 minecraft:stripped_spruce_log
fill 123 180 363 126 180 363 minecraft:stone
setblock 124 180 361 minecraft:stripped_spruce_log
fill 124 180 362 124 183 362 minecraft:stone
setblock 125 180 325 minecraft:light[level=12]
setblock 125 180 332 minecraft:light[level=12]
setblock 125 180 339 minecraft:light[level=12]
setblock 125 180 346 minecraft:light[level=12]
setblock 125 180 353 minecraft:light[level=12]
setblock 125 180 360 minecraft:light[level=12]
fill 125 180 361 125 183 361 minecraft:stone
fill 126 180 362 127 180 362 minecraft:stone
setblock 127 180 323 minecraft:stripped_spruce_log
setblock 127 180 363 minecraft:stripped_spruce_log
fill 128 180 323 129 182 323 minecraft:stone
setblock 128 180 362 minecraft:stripped_spruce_log
fill 128 180 363 128 183 363 minecraft:stone
fill 129 180 362 129 181 362 minecraft:stone
setblock 132 180 325 minecraft:light[level=12]
setblock 132 180 332 minecraft:light[level=12]
setblock 132 180 339 minecraft:light[level=12]
setblock 132 180 346 minecraft:light[level=12]
setblock 132 180 353 minecraft:light[level=12]
setblock 132 180 360 minecraft:light[level=12]
fill 133 180 338 133 181 338 minecraft:stone
fill 133 180 340 134 180 340 minecraft:stone
fill 133 180 352 135 183 352 minecraft:raw_gold_block
setblock 134 180 335 minecraft:stone
setblock 134 180 336 minecraft:stripped_spruce_log
fill 134 180 337 134 183 337 minecraft:stone
setblock 134 180 341 minecraft:stripped_spruce_log
fill 134 180 342 134 182 343 minecraft:stone
fill 134 180 351 134 183 351 minecraft:raw_gold_block
fill 134 180 353 134 183 353 minecraft:raw_gold_block
fill 135 180 332 135 180 334 minecraft:stone
setblock 135 180 335 minecraft:stripped_spruce_log
fill 135 180 336 135 183 336 minecraft:stone
setblock 135 180 340 minecraft:stripped_spruce_log
fill 135 180 341 135 183 341 minecraft:stone
setblock 135 180 345 minecraft:stripped_spruce_log
setblock 94 181 323 minecraft:gold_block
setblock 95 181 323 minecraft:stone
setblock 95 181 324 minecraft:stripped_spruce_log
fill 95 181 325 95 181 328 minecraft:stone
setblock 95 181 329 minecraft:stripped_spruce_log
fill 95 181 330 95 181 333 minecraft:stone
setblock 95 181 334 minecraft:stripped_spruce_log
fill 95 181 335 95 181 338 minecraft:stone
setblock 95 181 339 minecraft:stripped_spruce_log
fill 95 181 340 95 184 340 minecraft:stone
setblock 95 181 344 minecraft:stripped_spruce_log
setblock 95 181 358 minecraft:stone
setblock 95 181 359 minecraft:stripped_spruce_log
fill 95 181 360 96 183 360 minecraft:stone
setblock 96 181 323 minecraft:stripped_spruce_log
fill 96 181 324 96 183 325 minecraft:stone
setblock 96 181 337 minecraft:stone
setblock 96 181 338 minecraft:stripped_spruce_log
fill 96 181 339 96 184 339 minecraft:stone
fill 96 181 341 96 182 341 minecraft:stone
fill 96 181 361 96 181 362 minecraft:stone
setblock 96 181 363 minecraft:stripped_spruce_log
fill 97 181 323 99 181 324 minecraft:stone
fill 97 181 337 97 182 337 minecraft:iron_bars
setblock 97 181 362 minecraft:stripped_spruce_log
fill 97 181 363 100 181 363 minecraft:stone
setblock 98 181 361 minecraft:stripped_spruce_log
fill 98 181 362 101 181 362 minecraft:stone
setblock 99 181 325 minecraft:stripped_spruce_log
fill 99 181 361 102 181 361 minecraft:stone
setblock 100 181 323 minecraft:stone
setblock 100 181 324 minecraft:stripped_spruce_log
fill 100 181 325 100 184 325 minecraft:stone
setblock 101 181 323 minecraft:stripped_spruce_log
fill 101 181 324 101 184 324 minecraft:stone
fill 101 181 360 103 181 360 minecraft:stone
setblock 101 181 363 minecraft:stripped_spruce_log
fill 102 181 323 105 181 323 minecraft:stone
setblock 102 181 362 minecraft:stripped_spruce_log
fill 102 181 363 105 181 363 minecraft:stone
fill 103 181 324 103 181 325 minecraft:stone
setblock 103 181 361 minecraft:stripped_spruce_log
fill 103 181 362 106 181 362 minecraft:stone
setblock 104 181 324 minecraft:stone
setblock 104 181 325 minecraft:stripped_spruce_log
setblock 104 181 360 minecraft:stripped_spruce_log
fill 104 181 361 104 184 361 minecraft:stone
setblock 105 181 324 minecraft:stripped_spruce_log
fill 105 181 325 105 184 325 minecraft:stone
fill 105 181 360 105 183 360 minecraft:stone
setblock 106 181 323 minecraft:stripped_spruce_log
fill 106 181 324 106 184 324 minecraft:stone
setblock 106 181 363 minecraft:stripped_spruce_log
fill 107 181 323 107 184 323 minecraft:stone
setblock 107 181 362 minecraft:stripped_spruce_log
fill 107 181 363 110 181 363 minecraft:stone
setblock 108 181 361 minecraft:stripped_spruce_log
fill 108 181 362 111 181 362 minecraft:stone
fill 109 181 361 109 183 361 minecraft:stone
setblock 110 181 323 minecraft:stone
setblock 111 181 323 minecraft:stripped_spruce_log
setblock 111 181 363 minecraft:stripped_spruce_log
fill 112 181 323 113 183 323 minecraft:stone
setblock 112 181 362 minecraft:stripped_spruce_log
fill 112 181 363 115 181 363 minecraft:stone
setblock 113 181 361 minecraft:stripped_spruce_log
fill 113 181 362 116 181 362 minecraft:stone
fill 114 181 361 117 181 361 minecraft:stone
setblock 116 181 323 minecraft:stripped_spruce_log
setblock 116 181 363 minecraft:stripped_spruce_log
fill 117 181 322 118 224 322 minecraft:andesite
fill 117 181 323 120 181 323 minecraft:stone
setblock 117 181 362 minecraft:stripped_spruce_log
fill 117 181 363 120 181 363 minecraft:stone
setblock 118 181 361 minecraft:stripped_spruce_log
fill 118 181 362 121 181 362 minecraft:stone
setblock 119 181 322 minecraft:raw_gold_block
fill 119 181 361 122 181 361 minecraft:stone
fill 120 181 322 122 203 322 minecraft:andesite
setblock 120 181 360 minecraft:stone
setblock 121 181 323 minecraft:stripped_spruce_log
setblock 121 181 363 minecraft:stripped_spruce_log
fill 121 181 364 121 241 364 minecraft:andesite
fill 122 181 323 122 184 323 minecraft:stone
fill 122 181 360 123 181 360 minecraft:stone
setblock 122 181 362 minecraft:stripped_spruce_log
fill 122 181 363 125 181 363 minecraft:stone
fill 123 181 324 124 181 324 minecraft:stone
setblock 123 181 361 minecraft:stripped_spruce_log
fill 123 181 362 123 184 362 minecraft:stone
fill 124 181 361 124 183 361 minecraft:stone
setblock 125 181 323 minecraft:stone
setblock 126 181 323 minecraft:stripped_spruce_log
setblock 126 181 362 minecraft:stone
setblock 126 181 363 minecraft:stripped_spruce_log
fill 127 181 323 127 184 323 minecraft:stone
setblock 127 181 362 minecraft:stripped_spruce_log
fill 127 181 363 127 184 363 minecraft:stone
fill 128 181 362 128 182 362 minecraft:stone
fill 129 181 322 129 182 322 minecraft:andesite
setblock 130 181 322 minecraft:raw_gold_block
setblock 130 181 323 minecraft:stone
setblock 131 181 363 minecraft:stripped_spruce_log
fill 132 181 351 132 183 353 minecraft:raw_gold_block
fill 132 181 363 132 182 363 minecraft:stone
fill 133 181 339 133 181 340 minecraft:stone
setblock 133 181 341 minecraft:stripped_spruce_log
fill 133 181 351 133 183 351 minecraft:raw_gold_block
fill 133 181 353 133 183 353 minecraft:raw_gold_block
fill 134 181 323 135 181 323 minecraft:stone
setblock 134 181 335 minecraft:stripped_spruce_log
fill 134 181 336 134 183 336 minecraft:stone
setblock 134 181 339 minecraft:stone
setblock 134 181 340 minecraft:stripped_spruce_log
fill 134 181 341 134 184 341 minecraft:stone
setblock 134 181 344 minecraft:stone
fill 134 181 363 135 181 363 minecraft:stone
setblock 135 181 324 minecraft:stripped_spruce_log
fill 135 181 331 135 181 333 minecraft:stone
setblock 135 181 334 minecraft:stripped_spruce_log
fill 135 181 335 135 184 335 minecraft:stone
setblock 135 181 339 minecraft:stripped_spruce_log
fill 135 181 340 135 184 340 minecraft:stone
setblock 135 181 343 minecraft:stone
setblock 135 181 344 minecraft:stripped_spruce_log
fill 135 181 345 135 183 346 minecraft:stone
fill 135 181 351 135 182 351 minecraft:raw_gold_block
fill 135 181 353 135 182 353 minecraft:raw_gold_block
fill 135 181 360 135 182 362 minecraft:stone
fill 94 182 323 94 191 323 minecraft:andesite
setblock 95 182 323 minecraft:stripped_spruce_log
fill 95 182 324 95 182 327 minecraft:stone
setblock 95 182 328 minecraft:stripped_spruce_log
fill 95 182 329 95 182 332 minecraft:stone
setblock 95 182 333 minecraft:stripped_spruce_log
fill 95 182 334 95 182 337 minecraft:stone
setblock 95 182 338 minecraft:stripped_spruce_log
fill 95 182 339 95 185 339 minecraft:stone
setblock 95 182 343 minecraft:stripped_spruce_log
fill 95 182 344 95 185 344 minecraft:stone
setblock 95 182 358 minecraft:stripped_spruce_log
fill 95 182 359 95 185 359 minecraft:stone
setblock 95 182 362 minecraft:stone
setblock 95 182 363 minecraft:stripped_spruce_log
fill 96 182 323 99 182 323 minecraft:stone
setblock 96 182 326 minecraft:stone
setblock 96 182 327 minecraft:stripped_spruce_log
setblock 96 182 337 minecraft:stripped_spruce_log
fill 96 182 338 96 183 338 minecraft:stone
setblock 96 182 342 minecraft:stripped_spruce_log
setblock 96 182 361 minecraft:stone
setblock 96 182 362 minecraft:stripped_spruce_log
fill 96 182 363 99 182 363 minecraft:stone
fill 97 182 324 98 182 324 minecraft:stone
setblock 97 182 361 minecraft:stripped_spruce_log
fill 97 182 362 100 182 362 minecraft:stone
setblock 98 182 325 minecraft:stripped_spruce_log
fill 98 182 361 101 182 361 minecraft:stone
setblock 99 182 324 minecraft:stripped_spruce_log
fill 99 182 325 99 185 325 minecraft:stone
setblock 100 182 323 minecraft:stripped_spruce_log
fill 100 182 324 100 185 324 minecraft:stone
fill 100 182 360 102 182 360 minecraft:stone
setblock 100 182 363 minecraft:stripped_spruce_log
fill 101 182 323 104 182 323 minecraft:stone
setblock 101 182 362 minecraft:stripped_spruce_log
fill 101 182 363 104 182 363 minecraft:stone
setblock 102 182 361 minecraft:stripped_spruce_log
fill 102 182 362 105 182 362 minecraft:stone
setblock 103 182 324 minecraft:stone
setblock 103 182 325 minecraft:stripped_spruce_log
setblock 103 182 360 minecraft:stripped_spruce_log
fill 103 182 361 103 185 361 minecraft:stone
setblock 104 182 324 minecraft:stripped_spruce_log
fill 104 182 325 104 185 325 minecraft:stone
fill 104 182 360 104 184 360 minecraft:stone
setblock 105 182 323 minecraft:stripped_spruce_log
fill 105 182 324 105 185 324 minecraft:stone
setblock 105 182 363 minecraft:stripped_spruce_log
fill 106 182 323 106 185 323 minecraft:stone
setblock 106 182 362 minecraft:stripped_spruce_log
fill 106 182 363 109 182 363 minecraft:stone
setblock 107 182 361 minecraft:stripped_spruce_log
fill 107 182 362 110 182 362 minecraft:stone
fill 108 182 361 108 184 361 minecraft:stone
setblock 110 182 323 minecraft:stripped_spruce_log
setblock 110 182 363 minecraft:stripped_spruce_log
fill 111 182 323 111 185 323 minecraft:stone
setblock 111 182 361 minecraft:stone
setblock 111 182 362 minecraft:stripped_spruce_log
fill 111 182 363 114 182 363 minecraft:stone
setblock 112 182 361 minecraft:stripped_spruce_log
fill 112 182 362 115 182 362 minecraft:stone
fill 113 182 361 116 182 361 minecraft:stone
setblock 114 182 323 minecraft:stone
setblock 115 182 323 minecraft:stripped_spruce_log
setblock 115 182 363 minecraft:stripped_spruce_log
fill 116 182 323 119 182 323 minecraft:stone
setblock 116 182 362 minecraft:stripped_spruce_log
fill 116 182 363 119 182 363 minecraft:stone
setblock 117 182 361 minecraft:stripped_spruce_log
fill 117 182 362 120 182 362 minecraft:stone
fill 118 182 361 121 182 361 minecraft:stone
fill 119 182 322 119 241 322 minecraft:andesite
setblock 120 182 323 minecraft:stripped_spruce_log
setblock 120 182 363 minecraft:stripped_spruce_log
fill 121 182 323 121 184 324 minecraft:stone
setblock 121 182 362 minecraft:stripped_spruce_log
fill 121 182 363 124 182 363 minecraft:stone
fill 122 182 324 123 182 324 minecraft:stone
setblock 122 182 360 minecraft:stone
setblock 122 182 361 minecraft:stripped_spruce_log
fill 122 182 362 122 185 362 minecraft:stone
fill 123 182 361 123 184 361 minecraft:stone
setblock 124 182 324 minecraft:stripped_spruce_log
setblock 125 182 323 minecraft:stripped_spruce_log
fill 125 182 324 125 185 324 minecraft:stone
setblock 125 182 363 minecraft:stripped_spruce_log
fill 126 182 323 126 185 323 minecraft:stone
setblock 126 182 362 minecraft:stripped_spruce_log
fill 126 182 363 126 185 363 minecraft:stone
fill 127 182 362 127 183 362 minecraft:stone
fill 130 182 322 130 210 322 minecraft:andesite
setblock 130 182 323 minecraft:stripped_spruce_log
fill 130 182 352 131 183 352 minecraft:raw_gold_block
setblock 130 182 363 minecraft:stripped_spruce_log
fill 131 182 323 134 182 323 minecraft:stone
fill 131 182 351 131 183 351 minecraft:raw_gold_block
fill 131 182 353 131 183 353 minecraft:raw_gold_block
fill 131 182 363 131 183 363 minecraft:stone
setblock 133 182 339 minecraft:stone
setblock 133 182 340 minecraft:stripped_spruce_log
setblock 133 182 341 minecraft:stone
fill 133 182 363 134 182 363 minecraft:stone
setblock 134 182 335 minecraft:stone
setblock 134 182 339 minecraft:stripped_spruce_log
fill 134 182 340 134 185 340 minecraft:stone
setblock 134 182 344 minecraft:stripped_spruce_log
setblock 135 182 323 minecraft:stripped_spruce_log
fill 135 182 324 135 182 327 minecraft:stone
setblock 135 182 328 minecraft:stripped_spruce_log
fill 135 182 330 135 182 332 minecraft:stone
setblock 135 182 333 minecraft:stripped_spruce_log
fill 135 182 334 135 185 334 minecraft:stone
setblock 135 182 338 minecraft:stripped_spruce_log
fill 135 182 339 135 185 339 minecraft:stone
setblock 135 182 343 minecraft:stripped_spruce_log
fill 135 182 344 135 185 344 minecraft:stone
setblock 135 182 347 minecraft:stone
setblock 135 182 363 minecraft:stripped_spruce_log
fill 136 182 328 136 183 333 minecraft:andesite
setblock 136 182 334 minecraft:raw_gold_block
fill 136 182 335 136 241 335 minecraft:andesite
setblock 136 182 341 minecraft:raw_iron_block
fill 94 183 330 94 183 341 minecraft:andesite
setblock 94 183 342 minecraft:raw_gold_block
fill 94 183 343 94 207 345 minecraft:andesite
setblock 94 183 357 minecraft:gold_block
fill 94 183 358 94 189 361 minecraft:andesite
fill 95 183 323 95 183 326 minecraft:stone
setblock 95 183 327 minecraft:stripped_spruce_log
fill 95 183 328 95 183 331 minecraft:stone
setblock 95 183 332 minecraft:stripped_spruce_log
fill 95 183 333 95 183 336 minecraft:stone
setblock 95 183 337 minecraft:stripped_spruce_log
fill 95 183 338 95 186 338 minecraft:stone
setblock 95 183 342 minecraft:stripped_spruce_log
fill 95 183 343 96 184 343 minecraft:stone
fill 95 183 345 95 184 345 minecraft:stone
setblock 95 183 362 minecraft:stripped_spruce_log
fill 95 183 363 98 183 363 minecraft:stone
fill 96 183 323 98 183 323 minecraft:stone
setblock 96 183 326 minecraft:stripped_spruce_log
fill 96 183 327 96 185 328 minecraft:stone
setblock 96 183 337 minecraft:stone
setblock 96 183 341 minecraft:stripped_spruce_log
fill 96 183 342 96 185 342 minecraft:stone
setblock 96 183 361 minecraft:stripped_spruce_log
fill 96 183 362 99 183 362 minecraft:stone
setblock 97 183 324 minecraft:stone
setblock 97 183 325 minecraft:stripped_spruce_log
fill 97 183 361 100 183 361 minecraft:stone
setblock 98 183 324 minecraft:stripped_spruce_log
fill 98 183 325 98 186 325 minecraft:stone
setblock 99 183 323 minecraft:stripped_spruce_log
fill 99 183 324 99 186 324 minecraft:stone
setblock 99 183 363 minecraft:stripped_spruce_log
fill 100 183 323 103 183 323 minecraft:stone
fill 100 183 360 101 183 360 minecraft:stone
setblock 100 183 362 minecraft:stripped_spruce_log
fill 100 183 363 103 183 363 minecraft:stone
setblock 101 183 325 minecraft:stone
setblock 101 183 361 minecraft:stripped_spruce_log
fill 101 183 362 104 183 362 minecraft:stone
setblock 102 183 325 minecraft:stripped_spruce_log
setblock 102 183 360 minecraft:stripped_spruce_log
fill 102 183 361 102 186 361 minecraft:stone
setblock 103 183 324 minecraft:stripped_spruce_log
fill 103 183 325 103 186 325 minecraft:stone
fill 103 183 360 103 184 360 minecraft:stone
setblock 104 183 323 minecraft:stripped_spruce_log
fill 104 183 324 104 186 324 minecraft:stone
setblock 104 183 363 minecraft:stripped_spruce_log
fill 105 183 323 105 186 323 minecraft:stone
setblock 105 183 362 minecraft:stripped_spruce_log
fill 105 183 363 108 183 363 minecraft:stone
setblock 106 183 361 minecraft:stripped_spruce_log
fill 106 183 362 109 183 362 minecraft:stone
fill 107 183 361 107 184 361 minecraft:stone
setblock 108 183 324 minecraft:stripped_spruce_log
setblock 109 183 323 minecraft:stripped_spruce_log
setblock 109 183 363 minecraft:stripped_spruce_log
fill 110 183 323 110 186 323 minecraft:stone
setblock 110 183 362 minecraft:stripped_spruce_log
fill 110 183 363 113 183 363 minecraft:stone
fill 111 183 362 114 183 362 minecraft:stone
setblock 114 183 323 minecraft:stripped_spruce_log
setblock 114 183 363 minecraft:stripped_spruce_log
fill 115 183 323 118 183 323 minecraft:stone
setblock 115 183 362 minecraft:stripped_spruce_log
fill 115 183 363 118 183 363 minecraft:stone
setblock 116 183 361 minecraft:stripped_spruce_log
fill 116 183 362 119 183 362 minecraft:stone
fill 117 183 361 120 183 361 minecraft:stone
setblock 119 183 323 minecraft:stripped_spruce_log
fill 119 183 324 120 185 324 minecraft:stone
setblock 119 183 363 minecraft:stripped_spruce_log
fill 120 183 323 120 186 323 minecraft:stone
setblock 120 183 362 minecraft:stripped_spruce_log
fill 120 183 363 123 183 363 minecraft:stone
setblock 121 183 361 minecraft:stripped_spruce_log
fill 121 183 362 121 186 362 minecraft:stone
setblock 122 183 324 minecraft:stone
fill 122 183 361 122 184 361 minecraft:stone
setblock 123 183 324 minecraft:stripped_spruce_log
setblock 124 183 323 minecraft:stripped_spruce_log
fill 124 183 324 124 186 324 minecraft:stone
setblock 124 183 363 minecraft:stripped_spruce_log
fill 125 183 323 125 186 323 minecraft:stone
setblock 125 183 362 minecraft:stripped_spruce_log
fill 125 183 363 125 186 363 minecraft:stone
setblock 126 183 324 minecraft:stone
fill 126 183 362 126 184 362 minecraft:stone
setblock 128 183 323 minecraft:stone
setblock 129 183 322 minecraft:gold_block
setblock 129 183 323 minecraft:stripped_spruce_log
fill 129 183 352 129 184 352 minecraft:raw_gold_block
setblock 129 183 363 minecraft:stripped_spruce_log
fill 130 183 323 133 183 323 minecraft:stone
setblock 130 183 351 minecraft:raw_gold_block
setblock 130 183 353 minecraft:raw_gold_block
setblock 130 183 363 minecraft:stone
setblock 133 183 363 minecraft:stone
setblock 134 183 323 minecraft:stripped_spruce_log
setblock 134 183 338 minecraft:stripped_spruce_log
fill 134 183 339 134 185 339 minecraft:stone
setblock 134 183 342 minecraft:stone
setblock 134 183 343 minecraft:stripped_spruce_log
fill 134 183 344 134 185 345 minecraft:stone
setblock 134 183 363 minecraft:stripped_spruce_log
fill 135 183 323 135 183 326 minecraft:stone
setblock 135 183 327 minecraft:stripped_spruce_log
fill 135 183 328 135 183 331 minecraft:stone
setblock 135 183 332 minecraft:stripped_spruce_log
fill 135 183 333 135 186 333 minecraft:stone
setblock 135 183 337 minecraft:stripped_spruce_log
fill 135 183 338 135 186 338 minecraft:stone
setblock 135 183 342 minecraft:stripped_spruce_log
fill 135 183 343 135 186 343 minecraft:stone
setblock 135 183 347 minecraft:stripped_spruce_log
setblock 135 183 361 minecraft:stone
setblock 135 183 362 minecraft:stripped_spruce_log
fill 135 183 363 135 186 363 minecraft:stone
fill 136 183 334 136 203 334 minecraft:andesite
fill 136 183 341 136 184 341 minecraft:andesite
fill 94 184 330 94 184 340 minecraft:andesite
setblock 94 184 341 minecraft:raw_iron_block
fill 94 184 342 94 213 342 minecraft:andesite
fill 94 184 357 94 239 357 minecraft:andesite
fill 95 184 323 95 184 325 minecraft:stone
setblock 95 184 326 minecraft:stripped_spruce_log
fill 95 184 327 95 184 330 minecraft:stone
setblock 95 184 331 minecraft:stripped_spruce_log
fill 95 184 332 95 184 335 minecraft:stone
setblock 95 184 336 minecraft:stripped_spruce_log
fill 95 184 337 95 185 337 minecraft:stone
setblock 95 184 341 minecraft:stripped_spruce_log
fill 95 184 342 95 187 342 minecraft:stone
setblock 95 184 360 minecraft:stone
setblock 95 184 361 minecraft:stripped_spruce_log
fill 95 184 362 97 184 363 minecraft:stone
fill 96 184 323 96 184 324 minecraft:stone
setblock 96 184 325 minecraft:stripped_spruce_log
fill 96 184 326 97 186 326 minecraft:stone
setblock 96 184 340 minecraft:stripped_spruce_log
setblock 96 184 341 minecraft:stone
setblock 96 184 360 minecraft:stripped_spruce_log
fill 96 184 361 99 184 361 minecraft:stone
setblock 97 184 323 minecraft:stone
setblock 97 184 324 minecraft:stripped_spruce_log
fill 97 184 325 97 187 325 minecraft:stone
setblock 98 184 323 minecraft:stripped_spruce_log
fill 98 184 324 98 187 324 minecraft:stone
setblock 98 184 362 minecraft:stone
setblock 98 184 363 minecraft:stripped_spruce_log
fill 99 184 323 102 184 323 minecraft:stone
setblock 99 184 362 minecraft:stripped_spruce_log
fill 99 184 363 102 184 363 minecraft:stone
setblock 100 184 361 minecraft:stripped_spruce_log
fill 100 184 362 103 184 362 minecraft:stone
setblock 101 184 325 minecraft:stripped_spruce_log
setblock 101 184 360 minecraft:stripped_spruce_log
fill 101 184 361 101 187 361 minecraft:stone
setblock 102 184 324 minecraft:stripped_spruce_log
fill 102 184 325 102 187 325 minecraft:stone
setblock 102 184 360 minecraft:stone
setblock 103 184 322 minecraft:gold_block
setblock 103 184 323 minecraft:stripped_spruce_log
fill 103 184 324 103 187 324 minecraft:stone
setblock 103 184 363 minecraft:stripped_spruce_log
fill 104 184 322 105 224 322 minecraft:andesite
fill 104 184 323 104 187 323 minecraft:stone
setblock 104 184 362 minecraft:stripped_spruce_log
fill 104 184 363 107 184 363 minecraft:stone
setblock 105 184 361 minecraft:stripped_spruce_log
fill 105 184 362 108 184 362 minecraft:stone
fill 106 184 361 106 185 361 minecraft:stone
setblock 107 184 324 minecraft:stripped_spruce_log
setblock 108 184 323 minecraft:stripped_spruce_log
setblock 108 184 324 minecraft:stone
setblock 108 184 363 minecraft:stripped_spruce_log
fill 109 184 323 109 187 323 minecraft:stone
setblock 109 184 362 minecraft:stripped_spruce_log
fill 109 184 363 112 184 363 minecraft:stone
fill 110 184 362 113 184 362 minecraft:stone
setblock 112 184 323 minecraft:stone
setblock 113 184 323 minecraft:stripped_spruce_log
setblock 113 184 363 minecraft:stripped_spruce_log
fill 114 184 323 117 184 323 minecraft:stone
setblock 114 184 362 minecraft:stripped_spruce_log
fill 114 184 363 117 184 363 minecraft:stone
fill 115 184 362 118 184 362 minecraft:stone
fill 117 184 361 119 184 361 minecraft:stone
setblock 118 184 323 minecraft:stripped_spruce_log
setblock 118 184 363 minecraft:stripped_spruce_log
fill 119 184 323 119 187 323 minecraft:stone
setblock 119 184 362 minecraft:stripped_spruce_log
fill 119 184 363 122 184 363 minecraft:stone
setblock 120 184 361 minecraft:stripped_spruce_log
fill 120 184 362 120 187 362 minecraft:stone
fill 121 184 361 121 185 361 minecraft:stone
setblock 122 184 324 minecraft:stripped_spruce_log
setblock 123 184 323 minecraft:stripped_spruce_log
fill 123 184 324 123 187 324 minecraft:stone
setblock 123 184 363 minecraft:stripped_spruce_log
fill 124 184 323 124 187 323 minecraft:stone
setblock 124 184 362 minecraft:stripped_spruce_log
fill 124 184 363 124 187 363 minecraft:stone
fill 125 184 362 125 185 362 minecraft:stone
setblock 128 184 323 minecraft:stripped_spruce_log
setblock 128 184 352 minecraft:raw_gold_block
setblock 128 184 363 minecraft:stripped_spruce_log
fill 129 184 322 129 241 322 minecraft:andesite
fill 129 184 323 132 184 323 minecraft:stone
setblock 129 184 363 minecraft:stone
setblock 130 184 352 minecraft:raw_gold_block
setblock 133 184 323 minecraft:stripped_spruce_log
fill 134 184 323 135 186 323 minecraft:stone
setblock 134 184 337 minecraft:stripped_spruce_log
fill 134 184 338 134 185 338 minecraft:stone
setblock 134 184 342 minecraft:stripped_spruce_log
fill 134 184 343 134 186 343 minecraft:stone
fill 134 184 363 134 185 363 minecraft:stone
fill 135 184 324 135 184 325 minecraft:stone
setblock 135 184 326 minecraft:stripped_spruce_log
fill 135 184 327 135 184 330 minecraft:stone
setblock 135 184 331 minecraft:stripped_spruce_log
fill 135 184 332 135 187 332 minecraft:stone
setblock 135 184 336 minecraft:stripped_spruce_log
fill 135 184 337 135 187 337 minecraft:stone
setblock 135 184 341 minecraft:stripped_spruce_log
fill 135 184 342 135 187 342 minecraft:stone
setblock 135 184 345 minecraft:stone
setblock 135 184 346 minecraft:stripped_spruce_log
fill 135 184 347 135 187 347 minecraft:stone
setblock 135 184 361 minecraft:stripped_spruce_log
fill 135 184 362 135 185 362 minecraft:stone
setblock 136 184 328 minecraft:raw_gold_block
fill 136 184 329 136 184 333 minecraft:andesite
fill 136 184 343 136 225 343 minecraft:andesite
setblock 136 184 344 minecraft:gold_block
fill 136 184 345 136 189 347 minecraft:andesite
fill 94 185 330 94 187 339 minecraft:andesite
setblock 94 185 340 minecraft:raw_gold_block
fill 94 185 341 94 217 341 minecraft:andesite
fill 95 185 323 95 185 324 minecraft:stone
setblock 95 185 325 minecraft:stripped_spruce_log
fill 95 185 326 95 185 329 minecraft:stone
setblock 95 185 330 minecraft:stripped_spruce_log
fill 95 185 331 95 188 331 minecraft:stone
setblock 95 185 336 minecraft:stone
setblock 95 185 340 minecraft:stripped_spruce_log
fill 95 185 341 95 187 341 minecraft:stone
fill 95 185 343 95 186 343 minecraft:stone
setblock 95 185 345 minecraft:stripped_spruce_log
fill 95 185 346 95 188 346 minecraft:stone
setblock 95 185 360 minecraft:stripped_spruce_log
fill 95 185 361 96 185 363 minecraft:stone
setblock 96 185 323 minecraft:stone
setblock 96 185 324 minecraft:stripped_spruce_log
fill 96 185 325 96 188 325 minecraft:stone
setblock 96 185 360 minecraft:stone
setblock 97 185 323 minecraft:stripped_spruce_log
fill 97 185 324 97 188 324 minecraft:stone
setblock 97 185 362 minecraft:stone
setblock 97 185 363 minecraft:stripped_spruce_log
fill 98 185 323 101 185 323 minecraft:stone
setblock 98 185 361 minecraft:stone
setblock 98 185 362 minecraft:stripped_spruce_log
fill 98 185 363 101 185 363 minecraft:stone
setblock 99 185 361 minecraft:stripped_spruce_log
fill 99 185 362 102 185 362 minecraft:stone
setblock 100 185 325 minecraft:stripped_spruce_log
fill 100 185 361 100 187 361 minecraft:stone
setblock 101 185 324 minecraft:stripped_spruce_log
fill 101 185 325 101 188 325 minecraft:stone
setblock 102 185 323 minecraft:stripped_spruce_log
fill 102 185 324 102 188 324 minecraft:stone
setblock 102 185 363 minecraft:stripped_spruce_log
fill 103 185 322 103 198 322 minecraft:andesite
fill 103 185 323 103 188 323 minecraft:stone
setblock 103 185 362 minecraft:stripped_spruce_log
fill 103 185 363 106 185 363 minecraft:stone
setblock 104 185 361 minecraft:stripped_spruce_log
fill 104 185 362 107 185 362 minecraft:stone
setblock 105 185 361 minecraft:stone
setblock 106 185 324 minecraft:stripped_spruce_log
setblock 107 185 323 minecraft:stripped_spruce_log
setblock 107 185 324 minecraft:stone
setblock 107 185 363 minecraft:stripped_spruce_log
fill 108 185 323 108 187 323 minecraft:stone
setblock 108 185 362 minecraft:stripped_spruce_log
fill 108 185 363 111 185 363 minecraft:stone
fill 109 185 362 112 185 362 minecraft:stone
setblock 110 185 364 minecraft:gold_block
fill 111 185 364 111 189 364 minecraft:andesite
setblock 112 185 323 minecraft:stripped_spruce_log
setblock 112 185 363 minecraft:stripped_spruce_log
fill 113 185 323 116 185 323 minecraft:stone
setblock 113 185 362 minecraft:stripped_spruce_log
fill 113 185 363 116 185 363 minecraft:stone
fill 114 185 362 117 185 362 minecraft:stone
setblock 117 185 323 minecraft:stripped_spruce_log
setblock 117 185 363 minecraft:stripped_spruce_log
fill 118 185 323 118 187 324 minecraft:stone
setblock 118 185 361 minecraft:stone
setblock 118 185 362 minecraft:stripped_spruce_log
fill 118 185 363 121 185 363 minecraft:stone
setblock 119 185 361 minecraft:stripped_spruce_log
fill 119 185 362 119 187 362 minecraft:stone
setblock 120 185 361 minecraft:stone
setblock 121 185 323 minecraft:stone
setblock 121 185 324 minecraft:stripped_spruce_log
setblock 122 185 323 minecraft:stripped_spruce_log
fill 122 185 324 122 188 324 minecraft:stone
setblock 122 185 363 minecraft:stripped_spruce_log
fill 123 185 323 123 188 323 minecraft:stone
setblock 123 185 362 minecraft:stripped_spruce_log
fill 123 185 363 123 188 363 minecraft:stone
setblock 124 185 362 minecraft:stone
setblock 127 185 323 minecraft:stripped_spruce_log
setblock 127 185 363 minecraft:stripped_spruce_log
fill 128 185 323 131 185 323 minecraft:stone
setblock 132 185 323 minecraft:stripped_spruce_log
fill 133 185 323 133 188 323 minecraft:stone
fill 134 185 324 135 185 324 minecraft:stone
setblock 134 185 341 minecraft:stripped_spruce_log
fill 134 185 342 134 187 342 minecraft:stone
setblock 135 185 325 minecraft:stripped_spruce_log
fill 135 185 326 135 185 329 minecraft:stone
setblock 135 185 330 minecraft:stripped_spruce_log
fill 135 185 331 135 188 331 minecraft:stone
setblock 135 185 335 minecraft:stripped_spruce_log
fill 135 185 336 135 188 336 minecraft:stone
setblock 135 185 340 minecraft:stripped_spruce_log
fill 135 185 341 135 188 341 minecraft:stone
setblock 135 185 345 minecraft:stripped_spruce_log
fill 135 185 346 135 188 346 minecraft:stone
fill 136 185 328 136 216 328 minecraft:andesite
setblock 136 185 329 minecraft:raw_iron_block
fill 136 185 330 136 186 333 minecraft:andesite
setblock 136 185 341 minecraft:diamond_block
fill 136 185 344 136 190 344 minecraft:andesite
fill 94 186 326 94 198 328 minecraft:andesite
setblock 94 186 329 minecraft:diamond_block
fill 94 186 340 94 187 340 minecraft:andesite
setblock 95 186 323 minecraft:stone
setblock 95 186 324 minecraft:stripped_spruce_log
fill 95 186 325 95 186 328 minecraft:stone
setblock 95 186 329 minecraft:stripped_spruce_log
fill 95 186 330 95 189 330 minecraft:stone
setblock 95 186 339 minecraft:stripped_spruce_log
fill 95 186 340 95 187 340 minecraft:stone
setblock 95 186 344 minecraft:stripped_spruce_log
fill 95 186 345 95 189 345 minecraft:stone
fill 95 186 360 95 186 363 minecraft:stone
setblock 96 186 323 minecraft:stripped_spruce_log
setblock 96 186 324 minecraft:stone
setblock 96 186 327 minecraft:stone
setblock 96 186 328 minecraft:stripped_spruce_log
fill 96 186 329 96 189 329 minecraft:stone
fill 96 186 361 96 186 362 minecraft:stone
setblock 96 186 363 minecraft:stripped_spruce_log
fill 97 186 323 100 186 323 minecraft:stone
setblock 97 186 327 minecraft:stripped_spruce_log
setblock 97 186 332 minecraft:light[level=12]
setblock 97 186 333 minecraft:light[level=15]
setblock 97 186 339 minecraft:light[level=12]
setblock 97 186 341 minecraft:light[level=15]
setblock 97 186 346 minecraft:light[level=12]
setblock 97 186 349 minecraft:light[level=15]
setblock 97 186 353 minecraft:light[level=12]
setblock 97 186 357 minecraft:light[level=15]
setblock 97 186 360 minecraft:light[level=12]
setblock 97 186 362 minecraft:stripped_spruce_log
fill 97 186 363 100 186 363 minecraft:stone
setblock 98 186 361 minecraft:stripped_spruce_log
fill 98 186 362 101 186 362 minecraft:stone
setblock 99 186 325 minecraft:stripped_spruce_log
fill 99 186 361 99 187 361 minecraft:stone
setblock 100 186 324 minecraft:stripped_spruce_log
fill 100 186 325 100 189 325 minecraft:stone
setblock 101 186 323 minecraft:stripped_spruce_log
fill 101 186 324 101 189 324 minecraft:stone
setblock 101 186 363 minecraft:stripped_spruce_log
fill 102 186 323 102 189 323 minecraft:stone
setblock 102 186 362 minecraft:stripped_spruce_log
fill 102 186 363 105 186 363 minecraft:stone
setblock 103 186 361 minecraft:stripped_spruce_log
fill 103 186 362 106 186 362 minecraft:stone
setblock 104 186 325 minecraft:light[level=12]
setblock 104 186 332 minecraft:light[level=12]
setblock 104 186 339 minecraft:light[level=12]
setblock 104 186 346 minecraft:light[level=12]
setblock 104 186 353 minecraft:light[level=12]
setblock 104 186 360 minecraft:light[level=12]
setblock 104 186 361 minecraft:stone
setblock 105 186 324 minecraft:stripped_spruce_log
setblock 105 186 325 minecraft:light[level=15]
setblock 105 186 333 minecraft:light[level=15]
setblock 105 186 341 minecraft:light[level=15]
setblock 105 186 349 minecraft:light[level=15]
setblock 105 186 357 minecraft:light[level=15]
setblock 106 186 323 minecraft:stripped_spruce_log
setblock 106 186 324 minecraft:stone
setblock 106 186 363 minecraft:stripped_spruce_log
fill 107 186 323 107 189 323 minecraft:stone
setblock 107 186 362 minecraft:stripped_spruce_log
fill 107 186 363 110 186 363 minecraft:stone
fill 108 186 362 109 186 362 minecraft:stone
fill 110 186 364 110 208 364 minecraft:andesite
setblock 111 186 323 minecraft:stripped_spruce_log
setblock 111 186 325 minecraft:light[level=12]
setblock 111 186 332 minecraft:light[level=12]
setblock 111 186 339 minecraft:light[level=12]
setblock 111 186 346 minecraft:light[level=12]
setblock 111 186 353 minecraft:light[level=12]
setblock 111 186 360 minecraft:light[level=12]
setblock 111 186 363 minecraft:stripped_spruce_log
fill 112 186 363 115 186 363 minecraft:stone
fill 113 186 323 115 186 323 minecraft:stone
setblock 113 186 325 minecraft:light[level=15]
setblock 113 186 333 minecraft:light[level=15]
setblock 113 186 341 minecraft:light[level=15]
setblock 113 186 349 minecraft:light[level=15]
setblock 113 186 357 minecraft:light[level=15]
fill 114 186 362 116 186 362 minecraft:stone
setblock 116 186 323 minecraft:stripped_spruce_log
setblock 116 186 363 minecraft:stripped_spruce_log
fill 117 186 323 117 189 323 minecraft:stone
setblock 117 186 362 minecraft:stripped_spruce_log
fill 117 186 363 120 186 363 minecraft:stone
setblock 118 186 325 minecraft:light[level=12]
setblock 118 186 332 minecraft:light[level=12]
setblock 118 186 339 minecraft:light[level=12]
setblock 118 186 346 minecraft:light[level=12]
setblock 118 186 353 minecraft:light[level=12]
setblock 118 186 360 minecraft:light[level=12]
fill 118 186 362 118 187 362 minecraft:stone
setblock 119 186 324 minecraft:stone
setblock 120 186 324 minecraft:stripped_spruce_log
setblock 121 186 323 minecraft:stripped_spruce_log
fill 121 186 324 121 189 324 minecraft:stone
setblock 121 186 325 minecraft:light[level=15]
setblock 121 186 333 minecraft:light[level=15]
setblock 121 186 341 minecraft:light[level=15]
setblock 121 186 349 minecraft:light[level=15]
setblock 121 186 357 minecraft:light[level=15]
setblock 121 186 363 minecraft:stripped_spruce_log
fill 122 186 323 122 189 323 minecraft:stone
setblock 122 186 362 minecraft:stripped_spruce_log
fill 122 186 363 122 189 363 minecraft:stone
fill 122 186 364 124 239 364 minecraft:andesite
setblock 123 186 362 minecraft:stone
setblock 125 186 325 minecraft:light[level=12]
setblock 125 186 332 minecraft:light[level=12]
setblock 125 186 339 minecraft:light[level=12]
setblock 125 186 346 minecraft:light[level=12]
setblock 125 186 353 minecraft:light[level=12]
setblock 125 186 360 minecraft:light[level=12]
setblock 125 186 364 minecraft:raw_gold_block
setblock 126 186 323 minecraft:stripped_spruce_log
setblock 126 186 363 minecraft:stripped_spruce_log
fill 126 186 364 126 237 364 minecraft:andesite
fill 127 186 323 130 186 323 minecraft:stone
setblock 129 186 325 minecraft:light[level=15]
setblock 129 186 333 minecraft:light[level=15]
setblock 129 186 341 minecraft:light[level=15]
setblock 129 186 349 minecraft:light[level=15]
setblock 129 186 357 minecraft:light[level=15]
setblock 131 186 323 minecraft:stripped_spruce_log
fill 132 186 323 132 189 323 minecraft:stone
setblock 132 186 325 minecraft:light[level=12]
setblock 132 186 332 minecraft:light[level=12]
setblock 132 186 339 minecraft:light[level=12]
setblock 132 186 346 minecraft:light[level=12]
setblock 132 186 353 minecraft:light[level=12]
setblock 132 186 360 minecraft:light[level=12]
setblock 134 186 324 minecraft:stone
setblock 134 186 325 minecraft:stripped_spruce_log
setblock 134 186 340 minecraft:stripped_spruce_log
setblock 134 186 341 minecraft:stone
setblock 134 186 344 minecraft:stone
setblock 135 186 324 minecraft:stripped_spruce_log
fill 135 186 325 135 186 328 minecraft:stone
setblock 135 186 329 minecraft:stripped_spruce_log
fill 135 186 330 135 189 330 minecraft:stone
setblock 135 186 334 minecraft:stripped_spruce_log
fill 135 186 335 135 189 335 minecraft:stone
setblock 135 186 339 minecraft:stripped_spruce_log
fill 135 186 340 135 189 340 minecraft:stone
setblock 135 186 344 minecraft:stripped_spruce_log
fill 135 186 345 135 189 345 minecraft:stone
setblock 135 186 348 minecraft:stone
fill 136 186 325 136 239 325 minecraft:andesite
setblock 136 186 326 minecraft:raw_iron_block
fill 136 186 327 136 237 327 minecraft:andesite
fill 136 186 329 136 194 329 minecraft:andesite
fill 136 186 341 136 222 341 minecraft:andesite
fill 136 186 356 136 189 362 minecraft:andesite
setblock 136 186 363 minecraft:raw_gold_block
fill 94 187 329 94 188 329 minecraft:andesite
setblock 95 187 323 minecraft:stripped_spruce_log
fill 95 187 324 95 187 327 minecraft:stone
setblock 95 187 328 minecraft:stripped_spruce_log
fill 95 187 329 95 190 329 minecraft:stone
setblock 95 187 343 minecraft:stripped_spruce_log
fill 95 187 344 95 190 344 minecraft:stone
setblock 95 187 347 minecraft:stone
fill 95 187 360 95 187 362 minecraft:stone
setblock 95 187 363 minecraft:stripped_spruce_log
fill 96 187 323 99 187 323 minecraft:stone
fill 96 187 324 96 190 324 minecraft:spruce_log
setblock 96 187 326 minecraft:stone
setblock 96 187 327 minecraft:stripped_spruce_log
fill 96 187 328 96 190 328 minecraft:stone
fill 96 187 343 96 190 343 minecraft:spruce_log
setblock 96 187 361 minecraft:stone
fill 96 187 362 96 190 362 minecraft:spruce_log
fill 96 187 363 99 187 363 minecraft:stone
setblock 97 187 326 minecraft:stripped_spruce_log
fill 97 187 327 97 190 327 minecraft:stone
fill 97 187 362 100 187 362 minecraft:stone
setblock 98 187 325 minecraft:stripped_spruce_log
setblock 99 187 322 minecraft:raw_gold_block
setblock 99 187 324 minecraft:stripped_spruce_log
fill 99 187 325 99 190 325 minecraft:stone
fill 100 187 322 101 238 322 minecraft:andesite
setblock 100 187 323 minecraft:stripped_spruce_log
fill 100 187 324 100 190 324 minecraft:stone
setblock 100 187 363 minecraft:stripped_spruce_log
fill 101 187 323 101 190 323 minecraft:stone
setblock 101 187 362 minecraft:stripped_spruce_log
fill 101 187 363 104 187 363 minecraft:stone
setblock 102 187 361 minecraft:stripped_spruce_log
fill 102 187 362 105 187 362 minecraft:stone
setblock 103 187 325 minecraft:stripped_spruce_log
setblock 104 187 324 minecraft:stripped_spruce_log
setblock 105 187 323 minecraft:stripped_spruce_log
fill 105 187 324 105 188 324 minecraft:stone
setblock 105 187 363 minecraft:stripped_spruce_log
fill 106 187 323 106 190 323 minecraft:stone
setblock 106 187 362 minecraft:stripped_spruce_log
fill 106 187 363 109 187 363 minecraft:stone
setblock 107 187 362 minecraft:stone
setblock 110 187 363 minecraft:stripped_spruce_log
fill 111 187 363 114 187 363 minecraft:stone
fill 112 187 329 114 188 331 minecraft:iron_block
setblock 114 187 323 minecraft:stone
setblock 115 187 323 minecraft:stripped_spruce_log
fill 115 187 324 115 190 324 minecraft:spruce_log
fill 115 187 362 115 190 362 minecraft:spruce_log
setblock 115 187 363 minecraft:stripped_spruce_log
fill 116 187 323 116 190 323 minecraft:stone
setblock 116 187 362 minecraft:stripped_spruce_log
fill 116 187 363 119 187 363 minecraft:stone
setblock 117 187 362 minecraft:stone
setblock 119 187 324 minecraft:stripped_spruce_log
setblock 120 187 323 minecraft:stripped_spruce_log
fill 120 187 324 120 190 324 minecraft:stone
setblock 120 187 363 minecraft:stripped_spruce_log
fill 121 187 323 121 190 323 minecraft:stone
setblock 121 187 362 minecraft:stripped_spruce_log
fill 121 187 363 121 190 363 minecraft:stone
setblock 125 187 323 minecraft:stripped_spruce_log
fill 125 187 364 125 241 364 minecraft:andesite
fill 126 187 323 127 187 323 minecraft:stone
setblock 130 187 323 minecraft:stripped_spruce_log
fill 131 187 323 131 190 323 minecraft:stone
setblock 134 187 323 minecraft:stone
fill 134 187 324 134 190 324 minecraft:spruce_log
fill 134 187 325 135 187 327 minecraft:stone
fill 134 187 343 134 190 343 minecraft:spruce_log
setblock 134 187 344 minecraft:stripped_spruce_log
fill 134 187 362 134 190 362 minecraft:spruce_log
setblock 135 187 323 minecraft:stripped_spruce_log
fill 135 187 324 135 190 324 minecraft:stone
setblock 135 187 328 minecraft:stripped_spruce_log
fill 135 187 329 135 190 329 minecraft:stone
setblock 135 187 333 minecraft:stripped_spruce_log
fill 135 187 334 135 190 334 minecraft:stone
setblock 135 187 338 minecraft:stripped_spruce_log
fill 135 187 339 135 190 339 minecraft:stone
setblock 135 187 343 minecraft:stripped_spruce_log
fill 135 187 344 135 190 344 minecraft:stone
setblock 135 187 348 minecraft:stripped_spruce_log
setblock 135 187 363 minecraft:stripped_spruce_log
fill 136 187 326 136 241 326 minecraft:andesite
fill 136 187 330 136 241 330 minecraft:andesite
setblock 136 187 331 minecraft:raw_gold_block
fill 136 187 332 136 214 333 minecraft:andesite
fill 136 187 363 136 241 363 minecraft:andesite
fill 94 188 330 94 191 338 minecraft:andesite
fill 94 188 339 94 188 340 minecraft:diamond_block
fill 95 188 323 95 188 326 minecraft:stone
setblock 95 188 327 minecraft:stripped_spruce_log
fill 95 188 328 95 191 328 minecraft:stone
setblock 95 188 342 minecraft:stripped_spruce_log
fill 95 188 343 95 191 343 minecraft:stone
setblock 95 188 347 minecraft:stripped_spruce_log
fill 95 188 348 95 191 348 minecraft:stone
fill 95 188 360 95 188 361 minecraft:stone
setblock 95 188 362 minecraft:stripped_spruce_log
fill 95 188 363 98 188 363 minecraft:stone
fill 96 188 323 98 188 323 minecraft:stone
setblock 96 188 326 minecraft:stripped_spruce_log
fill 96 188 327 96 191 327 minecraft:stone
setblock 96 188 361 minecraft:stripped_spruce_log
setblock 97 188 325 minecraft:stripped_spruce_log
fill 97 188 326 97 191 326 minecraft:stone
fill 97 188 362 99 188 362 minecraft:stone
setblock 98 188 324 minecraft:stripped_spruce_log
fill 98 188 325 98 191 325 minecraft:stone
fill 99 188 322 99 195 322 minecraft:andesite
setblock 99 188 323 minecraft:stripped_spruce_log
fill 99 188 324 99 191 324 minecraft:stone
fill 99 188 326 99 196 326 minecraft:cobbled_deepslate
setblock 99 188 363 minecraft:stripped_spruce_log
fill 100 188 323 100 191 323 minecraft:stone
setblock 100 188 362 minecraft:stripped_spruce_log
fill 100 188 363 103 188 363 minecraft:stone
fill 101 188 362 104 188 362 minecraft:stone
setblock 102 188 325 minecraft:stripped_spruce_log
setblock 103 188 324 minecraft:stripped_spruce_log
setblock 104 188 323 minecraft:stripped_spruce_log
fill 104 188 324 104 189 324 minecraft:stone
setblock 104 188 363 minecraft:stripped_spruce_log
fill 105 188 323 105 191 323 minecraft:stone
setblock 105 188 362 minecraft:stripped_spruce_log
fill 105 188 363 108 188 363 minecraft:stone
setblock 109 188 363 minecraft:stripped_spruce_log
fill 110 188 363 113 188 363 minecraft:stone
setblock 114 188 323 minecraft:stripped_spruce_log
setblock 114 188 363 minecraft:stripped_spruce_log
fill 115 188 323 115 191 323 minecraft:stone
fill 115 188 363 118 188 363 minecraft:stone
setblock 118 188 323 minecraft:stone
setblock 118 188 324 minecraft:stripped_spruce_log
setblock 119 188 323 minecraft:stripped_spruce_log
fill 119 188 324 119 191 324 minecraft:stone
setblock 119 188 363 minecraft:stripped_spruce_log
fill 120 188 323 120 191 323 minecraft:stone
fill 120 188 363 120 191 363 minecraft:stone
setblock 124 188 323 minecraft:stripped_spruce_log
fill 125 188 323 126 188 323 minecraft:stone
setblock 133 188 324 minecraft:stripped_spruce_log
setblock 134 188 323 minecraft:stripped_spruce_log
fill 134 188 325 134 188 327 minecraft:stone
setblock 134 188 328 minecraft:stripped_spruce_log
fill 135 188 323 135 191 323 minecraft:stone
fill 135 188 325 135 188 326 minecraft:stone
setblock 135 188 327 minecraft:stripped_spruce_log
fill 135 188 328 135 191 328 minecraft:stone
setblock 135 188 332 minecraft:stripped_spruce_log
fill 135 188 333 135 191 333 minecraft:stone
setblock 135 188 337 minecraft:stripped_spruce_log
fill 135 188 338 135 191 338 minecraft:stone
setblock 135 188 342 minecraft:stripped_spruce_log
fill 135 188 343 135 191 343 minecraft:stone
setblock 135 188 347 minecraft:stripped_spruce_log
fill 135 188 348 135 191 348 minecraft:stone
fill 135 188 363 135 191 363 minecraft:stone
fill 136 188 331 136 242 331 minecraft:andesite
setblock 94 189 329 minecraft:raw_iron_block
fill 94 189 339 94 241 340 minecraft:andesite
fill 95 189 323 95 189 325 minecraft:stone
setblock 95 189 326 minecraft:stripped_spruce_log
fill 95 189 327 95 192 327 minecraft:stone
setblock 95 189 331 minecraft:stripped_spruce_log
fill 95 189 332 95 192 332 minecraft:stone
setblock 95 189 342 minecraft:stone
schedule function dropper:buildpart/74_6 1t
