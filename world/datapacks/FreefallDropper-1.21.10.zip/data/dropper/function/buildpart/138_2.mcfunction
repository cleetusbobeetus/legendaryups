fill 293 278 557 293 307 557 minecraft:purple_stained_glass
fill 311 278 599 311 299 599 minecraft:purple_stained_glass
fill 324 278 564 324 282 564 minecraft:purple_stained_glass
fill 324 278 567 324 287 567 minecraft:purple_stained_glass
fill 324 278 597 324 307 597 minecraft:purple_stained_glass
setblock 282 279 583 minecraft:light_blue_stained_glass
fill 297 279 570 307 279 575 minecraft:amethyst_block
fill 297 279 583 307 279 588 minecraft:amethyst_block
fill 298 279 567 304 280 569 minecraft:amethyst_block
fill 298 279 576 305 279 577 minecraft:amethyst_block
fill 298 279 581 305 279 582 minecraft:amethyst_block
fill 298 279 589 304 280 591 minecraft:amethyst_block
fill 299 279 566 299 280 566 minecraft:amethyst_block
fill 299 279 578 304 279 578 minecraft:amethyst_block
fill 299 279 580 304 279 580 minecraft:amethyst_block
fill 299 279 592 299 280 592 minecraft:amethyst_block
fill 300 279 579 303 279 579 minecraft:amethyst_block
fill 305 279 568 305 280 569 minecraft:amethyst_block
fill 305 279 589 305 280 590 minecraft:amethyst_block
fill 306 279 569 307 280 569 minecraft:amethyst_block
fill 306 279 576 318 279 576 minecraft:amethyst_block
fill 306 279 582 318 279 582 minecraft:amethyst_block
fill 306 279 589 307 280 589 minecraft:amethyst_block
fill 307 279 577 319 279 577 minecraft:amethyst_block
fill 307 279 581 319 279 581 minecraft:amethyst_block
fill 308 279 571 308 279 575 minecraft:amethyst_block
fill 308 279 578 320 279 578 minecraft:amethyst_block
fill 308 279 580 320 279 580 minecraft:amethyst_block
fill 308 279 583 308 279 587 minecraft:amethyst_block
fill 309 279 572 309 279 575 minecraft:amethyst_block
fill 309 279 579 321 279 579 minecraft:amethyst_block
fill 309 279 583 309 279 586 minecraft:amethyst_block
fill 310 279 573 313 279 575 minecraft:amethyst_block
fill 310 279 583 313 279 585 minecraft:amethyst_block
fill 314 279 574 316 280 575 minecraft:amethyst_block
fill 314 279 583 316 280 584 minecraft:amethyst_block
fill 317 279 575 317 280 575 minecraft:amethyst_block
fill 317 279 583 317 280 583 minecraft:amethyst_block
fill 324 279 594 324 279 595 minecraft:sea_lantern
setblock 282 280 570 minecraft:white_concrete
fill 282 280 583 296 280 583 minecraft:purple_stained_glass
fill 283 280 558 296 280 582 minecraft:purple_stained_glass
fill 283 280 584 296 280 598 minecraft:purple_stained_glass
fill 297 280 558 297 280 569 minecraft:purple_stained_glass
fill 297 280 570 299 280 575 minecraft:amethyst_block
fill 297 280 576 297 280 582 minecraft:purple_stained_glass
fill 297 280 583 299 280 588 minecraft:amethyst_block
fill 297 280 589 297 280 598 minecraft:purple_stained_glass
fill 298 280 558 298 280 566 minecraft:purple_stained_glass
fill 298 280 576 299 280 577 minecraft:amethyst_block
fill 298 280 578 298 280 580 minecraft:purple_stained_glass
fill 298 280 581 299 280 582 minecraft:amethyst_block
fill 298 280 592 298 280 598 minecraft:purple_stained_glass
fill 299 280 558 323 280 565 minecraft:purple_stained_glass
fill 299 280 578 300 280 578 minecraft:amethyst_block
setblock 299 280 579 minecraft:purple_stained_glass
fill 299 280 580 300 280 580 minecraft:amethyst_block
fill 299 280 593 323 280 598 minecraft:purple_stained_glass
fill 300 280 566 323 280 566 minecraft:purple_stained_glass
fill 300 280 570 300 280 571 minecraft:amethyst_block
fill 300 280 572 302 280 577 minecraft:purple_stained_glass
fill 300 280 579 301 280 579 minecraft:amethyst_block
fill 300 280 581 302 280 586 minecraft:purple_stained_glass
fill 300 280 587 300 280 588 minecraft:amethyst_block
fill 300 280 592 323 280 592 minecraft:purple_stained_glass
fill 301 280 570 302 280 571 minecraft:purple_stained_glass
fill 301 280 578 302 280 578 minecraft:purple_stained_glass
fill 301 280 580 302 280 580 minecraft:purple_stained_glass
fill 301 280 587 302 280 588 minecraft:purple_stained_glass
fill 302 280 579 303 280 579 minecraft:sea_lantern
fill 303 280 570 307 280 570 minecraft:amethyst_block
fill 303 280 571 303 280 576 minecraft:purple_stained_glass
fill 303 280 577 304 280 578 minecraft:sea_lantern
fill 303 280 580 304 280 581 minecraft:sea_lantern
fill 303 280 582 303 280 587 minecraft:purple_stained_glass
fill 303 280 588 307 280 588 minecraft:amethyst_block
fill 304 280 571 305 280 575 minecraft:purple_stained_glass
fill 304 280 576 308 280 576 minecraft:sea_lantern
fill 304 280 582 308 280 582 minecraft:sea_lantern
fill 304 280 583 305 280 587 minecraft:purple_stained_glass
fill 305 280 567 323 280 567 minecraft:purple_stained_glass
setblock 305 280 577 minecraft:sea_lantern
setblock 305 280 581 minecraft:sea_lantern
fill 305 280 591 323 280 591 minecraft:purple_stained_glass
fill 306 280 568 323 280 568 minecraft:purple_stained_glass
fill 306 280 571 308 280 571 minecraft:amethyst_block
fill 306 280 572 306 280 574 minecraft:purple_stained_glass
setblock 306 280 575 minecraft:sea_lantern
setblock 306 280 583 minecraft:sea_lantern
fill 306 280 584 306 280 586 minecraft:purple_stained_glass
fill 306 280 587 308 280 587 minecraft:amethyst_block
fill 306 280 590 323 280 590 minecraft:purple_stained_glass
fill 307 280 572 309 280 572 minecraft:amethyst_block
fill 307 280 573 307 280 575 minecraft:purple_stained_glass
fill 307 280 577 309 280 577 minecraft:sea_lantern
fill 307 280 581 309 280 581 minecraft:sea_lantern
fill 307 280 583 307 280 585 minecraft:purple_stained_glass
fill 307 280 586 309 280 586 minecraft:amethyst_block
fill 308 280 569 323 280 570 minecraft:purple_stained_glass
fill 308 280 573 313 280 573 minecraft:amethyst_block
fill 308 280 574 308 280 575 minecraft:purple_stained_glass
fill 308 280 578 309 280 578 minecraft:sea_lantern
fill 308 280 580 309 280 580 minecraft:sea_lantern
fill 308 280 583 308 280 584 minecraft:purple_stained_glass
fill 308 280 585 313 280 585 minecraft:amethyst_block
fill 308 280 588 323 280 589 minecraft:purple_stained_glass
fill 309 280 571 323 280 571 minecraft:purple_stained_glass
fill 309 280 574 313 280 574 minecraft:amethyst_block
fill 309 280 575 312 280 576 minecraft:purple_stained_glass
fill 309 280 579 310 280 579 minecraft:sea_lantern
fill 309 280 582 312 280 583 minecraft:purple_stained_glass
fill 309 280 584 313 280 584 minecraft:amethyst_block
fill 309 280 587 323 280 587 minecraft:purple_stained_glass
fill 310 280 572 323 280 572 minecraft:purple_stained_glass
fill 310 280 577 315 280 578 minecraft:purple_stained_glass
fill 310 280 580 315 280 581 minecraft:purple_stained_glass
fill 310 280 586 323 280 586 minecraft:purple_stained_glass
fill 311 280 579 316 280 579 minecraft:purple_stained_glass
setblock 313 280 575 minecraft:amethyst_block
setblock 313 280 576 minecraft:purple_stained_glass
setblock 313 280 582 minecraft:purple_stained_glass
setblock 313 280 583 minecraft:amethyst_block
fill 314 280 573 323 280 573 minecraft:purple_stained_glass
fill 314 280 576 318 280 576 minecraft:amethyst_block
fill 314 280 582 318 280 582 minecraft:amethyst_block
fill 314 280 585 323 280 585 minecraft:purple_stained_glass
fill 316 280 577 319 280 578 minecraft:amethyst_block
fill 316 280 580 319 280 581 minecraft:amethyst_block
fill 317 280 574 323 280 574 minecraft:purple_stained_glass
fill 317 280 579 321 280 579 minecraft:amethyst_block
fill 317 280 584 323 280 584 minecraft:purple_stained_glass
fill 318 280 575 323 280 575 minecraft:purple_stained_glass
fill 318 280 583 323 280 583 minecraft:purple_stained_glass
fill 319 280 576 323 280 576 minecraft:purple_stained_glass
fill 319 280 582 323 280 582 minecraft:purple_stained_glass
fill 320 280 577 323 280 577 minecraft:purple_stained_glass
setblock 320 280 578 minecraft:amethyst_block
setblock 320 280 580 minecraft:amethyst_block
fill 320 280 581 323 280 581 minecraft:purple_stained_glass
fill 321 280 578 323 280 578 minecraft:purple_stained_glass
fill 321 280 580 323 280 580 minecraft:purple_stained_glass
fill 322 280 579 323 280 579 minecraft:purple_stained_glass
setblock 323 280 599 minecraft:sea_lantern
setblock 324 280 566 minecraft:white_concrete
fill 324 280 594 324 288 595 minecraft:purple_stained_glass
setblock 282 281 570 minecraft:sea_lantern
fill 282 281 583 282 307 583 minecraft:purple_stained_glass
setblock 291 281 557 minecraft:white_concrete
fill 323 281 599 323 307 599 minecraft:purple_stained_glass
fill 324 281 566 324 307 566 minecraft:purple_stained_glass
setblock 324 281 584 minecraft:sea_lantern
fill 282 282 570 282 287 570 minecraft:purple_stained_glass
fill 291 282 557 291 305 557 minecraft:purple_stained_glass
setblock 294 282 557 minecraft:light_blue_stained_glass
fill 324 282 584 324 287 584 minecraft:purple_stained_glass
setblock 324 282 589 minecraft:white_concrete
fill 324 282 590 324 307 590 minecraft:purple_stained_glass
setblock 282 283 560 minecraft:sea_lantern
setblock 282 283 563 minecraft:sea_lantern
setblock 282 283 596 minecraft:light_blue_stained_glass
fill 294 283 557 294 286 557 minecraft:purple_stained_glass
setblock 297 283 599 minecraft:white_concrete
setblock 305 283 557 minecraft:sea_lantern
setblock 321 283 557 minecraft:light_blue_stained_glass
setblock 324 283 558 minecraft:white_concrete
setblock 324 283 564 minecraft:sea_lantern
fill 324 283 589 324 307 589 minecraft:purple_stained_glass
setblock 324 283 593 minecraft:light_blue_stained_glass
fill 282 284 560 282 307 560 minecraft:purple_stained_glass
fill 282 284 563 282 303 563 minecraft:purple_stained_glass
fill 282 284 596 282 307 596 minecraft:purple_stained_glass
fill 297 284 599 297 297 599 minecraft:purple_stained_glass
setblock 302 284 599 minecraft:light_blue_stained_glass
fill 305 284 557 305 307 557 minecraft:purple_stained_glass
fill 318 284 586 323 284 586 minecraft:light_blue_stained_glass
fill 319 284 585 323 284 585 minecraft:light_blue_stained_glass
fill 319 284 587 323 284 587 minecraft:light_blue_stained_glass
fill 321 284 557 321 307 557 minecraft:purple_stained_glass
fill 324 284 558 324 300 558 minecraft:purple_stained_glass
fill 324 284 564 324 307 564 minecraft:purple_stained_glass
fill 324 284 593 324 285 593 minecraft:purple_stained_glass
fill 302 285 599 302 307 599 minecraft:purple_stained_glass
fill 320 285 586 323 285 586 minecraft:light_blue_stained_glass
fill 321 285 585 323 285 585 minecraft:light_blue_stained_glass
fill 321 285 587 323 285 587 minecraft:light_blue_stained_glass
setblock 322 286 586 minecraft:light_blue_stained_glass
setblock 324 286 593 minecraft:light_blue_stained_glass
setblock 294 287 557 minecraft:white_concrete
fill 308 287 597 310 290 597 minecraft:light_blue_stained_glass
fill 309 287 596 309 290 596 minecraft:light_blue_stained_glass
fill 309 287 598 309 290 598 minecraft:light_blue_stained_glass
setblock 324 287 569 minecraft:sea_lantern
fill 324 287 593 324 307 593 minecraft:purple_stained_glass
setblock 324 287 598 minecraft:sea_lantern
fill 282 288 565 282 290 565 minecraft:magenta_stained_glass
setblock 282 288 570 minecraft:light_blue_stained_glass
fill 282 288 581 282 290 581 minecraft:magenta_stained_glass
fill 282 288 597 282 290 597 minecraft:magenta_stained_glass
setblock 285 288 560 minecraft:light[level=14]
setblock 285 288 568 minecraft:light[level=14]
setblock 285 288 576 minecraft:light[level=14]
setblock 285 288 584 minecraft:light[level=14]
setblock 285 288 592 minecraft:light[level=14]
fill 286 288 557 286 290 557 minecraft:magenta_stained_glass
setblock 293 288 560 minecraft:light[level=14]
setblock 293 288 568 minecraft:light[level=14]
setblock 293 288 576 minecraft:light[level=14]
setblock 293 288 584 minecraft:light[level=14]
setblock 293 288 592 minecraft:light[level=14]
fill 294 288 557 294 307 557 minecraft:purple_stained_glass
fill 296 288 599 296 290 599 minecraft:magenta_stained_glass
setblock 301 288 560 minecraft:light[level=14]
setblock 301 288 568 minecraft:light[level=14]
setblock 301 288 576 minecraft:light[level=14]
setblock 301 288 584 minecraft:light[level=14]
setblock 301 288 592 minecraft:light[level=14]
fill 302 288 557 302 290 557 minecraft:magenta_stained_glass
fill 308 288 595 308 290 596 minecraft:light_blue_stained_glass
fill 308 288 598 308 289 598 minecraft:light_blue_stained_glass
setblock 309 288 560 minecraft:light[level=14]
setblock 309 288 568 minecraft:light[level=14]
setblock 309 288 576 minecraft:light[level=14]
setblock 309 288 584 minecraft:light[level=14]
setblock 309 288 592 minecraft:light[level=14]
fill 309 288 595 310 290 595 minecraft:light_blue_stained_glass
fill 310 288 596 310 290 596 minecraft:light_blue_stained_glass
fill 310 288 598 310 289 598 minecraft:light_blue_stained_glass
fill 312 288 599 312 290 599 minecraft:magenta_stained_glass
setblock 317 288 560 minecraft:light[level=14]
setblock 317 288 568 minecraft:light[level=14]
setblock 317 288 576 minecraft:light[level=14]
setblock 317 288 584 minecraft:light[level=14]
setblock 317 288 592 minecraft:light[level=14]
fill 318 288 557 318 290 557 minecraft:magenta_stained_glass
setblock 319 288 599 minecraft:light_blue_stained_glass
fill 324 288 567 324 290 567 minecraft:magenta_stained_glass
setblock 324 288 569 minecraft:white_concrete
fill 324 288 583 324 290 583 minecraft:magenta_stained_glass
setblock 324 288 584 minecraft:sea_lantern
setblock 324 288 598 minecraft:purple_stained_glass
fill 282 289 570 282 307 570 minecraft:purple_stained_glass
setblock 284 289 557 minecraft:white_concrete
fill 291 289 589 291 290 589 minecraft:light_blue_stained_glass
fill 308 289 594 310 290 594 minecraft:light_blue_stained_glass
fill 309 289 593 309 291 593 minecraft:light_blue_stained_glass
fill 319 289 599 319 307 599 minecraft:purple_stained_glass
fill 324 289 569 324 307 569 minecraft:purple_stained_glass
fill 324 289 584 324 307 584 minecraft:purple_stained_glass
fill 324 289 594 324 292 594 minecraft:purple_stained_glass
setblock 324 289 595 minecraft:white_concrete
setblock 324 289 598 minecraft:light_blue_stained_glass
setblock 282 290 574 minecraft:sea_lantern
fill 284 290 557 284 300 557 minecraft:purple_stained_glass
fill 285 290 597 287 295 597 minecraft:light_blue_stained_glass
fill 286 290 596 286 295 596 minecraft:light_blue_stained_glass
fill 286 290 598 286 295 598 minecraft:light_blue_stained_glass
setblock 298 290 599 minecraft:white_concrete
fill 299 290 599 299 307 599 minecraft:purple_stained_glass
setblock 308 290 593 minecraft:light_blue_stained_glass
fill 309 290 592 309 291 592 minecraft:light_blue_stained_glass
setblock 310 290 593 minecraft:light_blue_stained_glass
setblock 312 290 557 minecraft:sea_lantern
setblock 316 290 557 minecraft:sea_lantern
fill 316 290 586 316 291 586 minecraft:light_blue_stained_glass
setblock 319 290 557 minecraft:light_blue_stained_glass
setblock 324 290 595 minecraft:sea_lantern
fill 324 290 598 324 299 598 minecraft:purple_stained_glass
fill 282 291 565 282 296 565 minecraft:purple_stained_glass
fill 282 291 574 282 307 574 minecraft:purple_stained_glass
fill 282 291 581 282 296 581 minecraft:purple_stained_glass
fill 282 291 597 282 296 597 minecraft:purple_stained_glass
fill 284 291 596 284 294 598 minecraft:light_blue_stained_glass
fill 285 291 595 285 295 596 minecraft:light_blue_stained_glass
fill 285 291 598 285 294 598 minecraft:light_blue_stained_glass
setblock 286 291 557 minecraft:purple_stained_glass
fill 286 291 595 287 295 595 minecraft:light_blue_stained_glass
fill 287 291 596 288 294 596 minecraft:light_blue_stained_glass
fill 287 291 598 288 294 598 minecraft:light_blue_stained_glass
fill 288 291 597 288 294 597 minecraft:light_blue_stained_glass
fill 296 291 599 296 296 599 minecraft:purple_stained_glass
fill 298 291 599 298 305 599 minecraft:purple_stained_glass
fill 302 291 557 302 296 557 minecraft:purple_stained_glass
setblock 309 291 591 minecraft:light_blue_stained_glass
fill 312 291 557 312 292 557 minecraft:purple_stained_glass
fill 312 291 599 312 296 599 minecraft:purple_stained_glass
fill 316 291 557 316 292 557 minecraft:purple_stained_glass
fill 318 291 557 319 296 557 minecraft:purple_stained_glass
fill 324 291 567 324 296 567 minecraft:purple_stained_glass
fill 324 291 583 324 296 583 minecraft:purple_stained_glass
fill 324 291 595 324 307 595 minecraft:purple_stained_glass
setblock 282 292 566 minecraft:white_concrete
fill 282 292 567 282 307 567 minecraft:purple_stained_glass
setblock 286 292 557 minecraft:white_concrete
fill 286 292 594 286 295 594 minecraft:light_blue_stained_glass
setblock 310 292 599 minecraft:light_blue_stained_glass
fill 316 292 586 317 299 586 minecraft:amethyst_block
fill 282 293 566 282 307 566 minecraft:purple_stained_glass
setblock 284 293 595 minecraft:light_blue_stained_glass
setblock 285 293 557 minecraft:light_blue_stained_glass
fill 285 293 594 285 295 594 minecraft:light_blue_stained_glass
fill 286 293 557 286 296 557 minecraft:purple_stained_glass
fill 287 293 594 287 295 594 minecraft:light_blue_stained_glass
setblock 288 293 595 minecraft:light_blue_stained_glass
fill 300 293 570 300 294 571 minecraft:magenta_stained_glass
fill 310 293 599 310 307 599 minecraft:purple_stained_glass
setblock 312 293 557 minecraft:light_blue_stained_glass
setblock 316 293 557 minecraft:sea_lantern
setblock 324 293 594 minecraft:light_blue_stained_glass
fill 285 294 557 285 307 557 minecraft:purple_stained_glass
fill 285 294 593 287 295 593 minecraft:light_blue_stained_glass
setblock 301 294 557 minecraft:white_concrete
fill 312 294 557 312 297 557 minecraft:purple_stained_glass
fill 316 294 557 316 307 557 minecraft:purple_stained_glass
fill 316 294 585 317 299 585 minecraft:amethyst_block
fill 316 294 587 317 299 587 minecraft:amethyst_block
fill 324 294 570 324 307 570 minecraft:purple_stained_glass
setblock 324 294 571 minecraft:sea_lantern
fill 324 294 594 324 307 594 minecraft:purple_stained_glass
setblock 282 295 571 minecraft:sea_lantern
setblock 286 295 592 minecraft:light_blue_stained_glass
setblock 287 295 596 minecraft:light_blue_stained_glass
setblock 290 295 599 minecraft:light_blue_stained_glass
setblock 300 295 557 minecraft:sea_lantern
fill 301 295 557 301 307 557 minecraft:purple_stained_glass
fill 315 295 586 315 299 587 minecraft:amethyst_block
fill 318 295 586 318 299 586 minecraft:amethyst_block
fill 324 295 571 324 304 571 minecraft:purple_stained_glass
setblock 324 295 586 minecraft:white_concrete
fill 324 295 587 324 306 587 minecraft:purple_stained_glass
fill 282 296 571 282 301 571 minecraft:purple_stained_glass
setblock 285 296 560 minecraft:light[level=14]
setblock 285 296 568 minecraft:light[level=14]
setblock 285 296 576 minecraft:light[level=14]
setblock 285 296 584 minecraft:light[level=14]
setblock 285 296 592 minecraft:light[level=14]
fill 290 296 599 290 307 599 minecraft:purple_stained_glass
setblock 293 296 560 minecraft:light[level=14]
setblock 293 296 568 minecraft:light[level=14]
setblock 293 296 576 minecraft:light[level=14]
setblock 293 296 584 minecraft:light[level=14]
setblock 293 296 592 minecraft:light[level=14]
fill 300 296 557 300 307 557 minecraft:purple_stained_glass
setblock 301 296 560 minecraft:light[level=14]
setblock 301 296 568 minecraft:light[level=14]
setblock 301 296 576 minecraft:light[level=14]
setblock 301 296 584 minecraft:light[level=14]
setblock 301 296 592 minecraft:light[level=14]
setblock 309 296 560 minecraft:light[level=14]
setblock 309 296 568 minecraft:light[level=14]
setblock 309 296 576 minecraft:light[level=14]
setblock 309 296 584 minecraft:light[level=14]
setblock 309 296 592 minecraft:light[level=14]
fill 314 296 573 315 297 573 minecraft:light_blue_stained_glass
fill 315 296 585 315 299 585 minecraft:amethyst_block
fill 316 296 584 317 299 584 minecraft:amethyst_block
fill 316 296 588 317 299 588 minecraft:amethyst_block
setblock 317 296 560 minecraft:light[level=14]
setblock 317 296 568 minecraft:light[level=14]
setblock 317 296 576 minecraft:light[level=14]
setblock 317 296 592 minecraft:light[level=14]
fill 318 296 585 318 299 585 minecraft:amethyst_block
fill 318 296 587 318 299 587 minecraft:amethyst_block
setblock 324 296 578 minecraft:light_blue_stained_glass
fill 324 296 586 324 301 586 minecraft:purple_stained_glass
fill 282 297 558 282 307 558 minecraft:purple_stained_glass
fill 282 297 559 282 298 559 minecraft:white_concrete
fill 282 297 565 282 299 565 minecraft:magenta_stained_glass
fill 282 297 581 282 299 581 minecraft:magenta_stained_glass
setblock 282 297 592 minecraft:light_blue_stained_glass
fill 282 297 593 282 307 593 minecraft:purple_stained_glass
fill 282 297 597 282 299 597 minecraft:magenta_stained_glass
fill 286 297 557 286 299 557 minecraft:magenta_stained_glass
fill 291 297 585 291 298 586 minecraft:magenta_stained_glass
fill 296 297 599 296 299 599 minecraft:magenta_stained_glass
fill 302 297 557 302 299 557 minecraft:magenta_stained_glass
fill 302 297 587 302 298 587 minecraft:magenta_stained_glass
fill 312 297 599 312 299 599 minecraft:magenta_stained_glass
fill 314 297 585 314 299 587 minecraft:amethyst_block
fill 315 297 584 315 299 584 minecraft:amethyst_block
fill 315 297 588 315 299 588 minecraft:amethyst_block
fill 318 297 557 318 299 557 minecraft:magenta_stained_glass
fill 318 297 584 318 299 584 minecraft:amethyst_block
fill 318 297 588 318 299 588 minecraft:amethyst_block
fill 319 297 557 319 307 557 minecraft:purple_stained_glass
fill 319 297 586 319 299 586 minecraft:amethyst_block
fill 324 297 567 324 299 567 minecraft:magenta_stained_glass
fill 324 297 578 324 307 578 minecraft:purple_stained_glass
fill 324 297 583 324 299 583 minecraft:magenta_stained_glass
fill 282 298 592 282 307 592 minecraft:purple_stained_glass
setblock 284 298 599 minecraft:white_concrete
setblock 297 298 599 minecraft:sea_lantern
setblock 304 298 599 minecraft:white_concrete
setblock 312 298 557 minecraft:light_blue_stained_glass
fill 316 298 583 317 299 583 minecraft:amethyst_block
fill 316 298 589 317 299 589 minecraft:amethyst_block
fill 319 298 585 319 299 585 minecraft:amethyst_block
fill 319 298 587 319 299 587 minecraft:amethyst_block
setblock 324 298 580 minecraft:sea_lantern
fill 282 299 559 282 307 559 minecraft:purple_stained_glass
fill 284 299 599 284 307 599 minecraft:purple_stained_glass
setblock 285 299 599 minecraft:light_blue_stained_glass
fill 297 299 599 297 307 599 minecraft:purple_stained_glass
fill 304 299 599 304 307 599 minecraft:purple_stained_glass
setblock 312 299 557 minecraft:purple_stained_glass
fill 313 299 586 313 299 587 minecraft:amethyst_block
setblock 314 299 584 minecraft:amethyst_block
setblock 314 299 588 minecraft:amethyst_block
setblock 315 299 583 minecraft:amethyst_block
setblock 315 299 589 minecraft:amethyst_block
setblock 315 299 599 minecraft:sea_lantern
setblock 318 299 583 minecraft:amethyst_block
setblock 318 299 589 minecraft:amethyst_block
setblock 319 299 584 minecraft:amethyst_block
setblock 319 299 588 minecraft:amethyst_block
fill 324 299 580 324 307 580 minecraft:purple_stained_glass
setblock 282 300 562 minecraft:sea_lantern
fill 282 300 565 282 304 565 minecraft:purple_stained_glass
fill 282 300 581 282 307 581 minecraft:purple_stained_glass
fill 282 300 597 282 307 597 minecraft:purple_stained_glass
fill 285 300 599 285 307 599 minecraft:purple_stained_glass
fill 286 300 557 286 307 557 minecraft:purple_stained_glass
fill 296 300 599 296 307 599 minecraft:purple_stained_glass
setblock 302 300 557 minecraft:purple_stained_glass
setblock 311 300 599 minecraft:sea_lantern
setblock 312 300 557 minecraft:sea_lantern
fill 312 300 599 312 307 599 minecraft:purple_stained_glass
fill 315 300 599 315 301 599 minecraft:purple_stained_glass
fill 316 300 585 317 300 587 minecraft:light_blue_stained_glass
setblock 317 300 557 minecraft:white_concrete
fill 318 300 557 318 307 557 minecraft:purple_stained_glass
fill 324 300 567 324 307 567 minecraft:purple_stained_glass
fill 324 300 583 324 307 583 minecraft:purple_stained_glass
setblock 324 300 598 minecraft:sea_lantern
fill 282 301 562 282 307 562 minecraft:purple_stained_glass
setblock 284 301 557 minecraft:light_blue_stained_glass
setblock 302 301 557 minecraft:sea_lantern
fill 311 301 599 311 307 599 minecraft:purple_stained_glass
fill 312 301 557 312 307 557 minecraft:purple_stained_glass
setblock 317 301 557 minecraft:purple_stained_glass
setblock 324 301 558 minecraft:white_concrete
fill 324 301 598 324 307 598 minecraft:purple_stained_glass
setblock 282 302 571 minecraft:sea_lantern
fill 282 302 584 282 307 584 minecraft:purple_stained_glass
setblock 282 302 585 minecraft:white_concrete
fill 284 302 557 284 307 557 minecraft:purple_stained_glass
setblock 299 302 557 minecraft:sea_lantern
fill 302 302 557 302 307 557 minecraft:purple_stained_glass
setblock 315 302 599 minecraft:light_blue_stained_glass
setblock 317 302 557 minecraft:white_concrete
fill 324 302 558 324 307 558 minecraft:purple_stained_glass
setblock 324 302 586 minecraft:white_concrete
setblock 324 302 591 minecraft:sea_lantern
fill 282 303 571 282 307 571 minecraft:purple_stained_glass
fill 282 303 585 282 307 585 minecraft:purple_stained_glass
fill 299 303 557 299 307 557 minecraft:purple_stained_glass
fill 315 303 599 315 307 599 minecraft:purple_stained_glass
fill 317 303 557 317 307 557 minecraft:purple_stained_glass
fill 324 303 586 324 307 586 minecraft:purple_stained_glass
fill 324 303 591 324 307 591 minecraft:purple_stained_glass
setblock 282 304 563 minecraft:white_concrete
setblock 308 304 557 minecraft:sea_lantern
setblock 322 304 557 minecraft:light_blue_stained_glass
fill 282 305 563 282 307 563 minecraft:purple_stained_glass
setblock 282 305 565 minecraft:sea_lantern
fill 308 305 557 308 307 557 minecraft:purple_stained_glass
fill 322 305 557 322 307 557 minecraft:purple_stained_glass
setblock 324 305 571 minecraft:sea_lantern
fill 282 306 565 282 307 565 minecraft:purple_stained_glass
setblock 291 306 557 minecraft:light_blue_stained_glass
setblock 298 306 599 minecraft:white_concrete
fill 307 306 599 307 307 599 minecraft:purple_stained_glass
setblock 308 306 599 minecraft:white_concrete
setblock 324 306 559 minecraft:light_blue_stained_glass
fill 324 306 571 324 307 571 minecraft:purple_stained_glass
setblock 291 307 557 minecraft:purple_stained_glass
setblock 298 307 599 minecraft:purple_stained_glass
setblock 308 307 599 minecraft:purple_stained_glass
setblock 324 307 559 minecraft:purple_stained_glass
setblock 324 307 587 minecraft:light_blue_stained_glass
