setblock 7 296 364 minecraft:yellow_concrete
fill 8 296 323 8 297 323 minecraft:honeycomb_block
setblock 8 296 359 minecraft:brown_terracotta
setblock 8 296 361 minecraft:brown_terracotta
fill 8 296 363 8 298 363 minecraft:honeycomb_block
setblock 10 296 359 minecraft:brown_terracotta
setblock 10 296 361 minecraft:brown_terracotta
fill 11 296 326 11 298 326 minecraft:brown_terracotta
fill 12 296 325 12 298 325 minecraft:brown_terracotta
fill 12 296 327 12 298 327 minecraft:brown_terracotta
fill 13 296 326 13 298 326 minecraft:brown_terracotta
setblock 15 296 323 minecraft:honey_block
setblock 21 296 323 minecraft:honeycomb_block
setblock 22 296 323 minecraft:yellow_terracotta
fill 22 296 364 22 308 364 minecraft:honeycomb_block
fill 23 296 323 25 296 324 minecraft:honeycomb_block
setblock 24 296 325 minecraft:honeycomb_block
fill 24 296 363 26 296 363 minecraft:honeycomb_block
setblock 25 296 325 minecraft:yellow_terracotta
setblock 26 296 323 minecraft:honeycomb_block
setblock 26 296 324 minecraft:yellow_terracotta
fill 26 296 325 26 298 325 minecraft:honeycomb_block
setblock 27 296 323 minecraft:yellow_terracotta
fill 27 296 324 27 299 324 minecraft:honeycomb_block
setblock 27 296 362 minecraft:honeycomb_block
setblock 27 296 363 minecraft:yellow_terracotta
fill 28 296 323 28 299 323 minecraft:honeycomb_block
setblock 28 296 362 minecraft:yellow_terracotta
fill 28 296 363 28 299 363 minecraft:honeycomb_block
setblock 29 296 326 minecraft:yellow_terracotta
fill 29 296 362 29 299 362 minecraft:honeycomb_block
setblock 30 296 325 minecraft:yellow_terracotta
setblock 30 296 326 minecraft:honeycomb_block
setblock 31 296 324 minecraft:yellow_terracotta
fill 31 296 325 31 297 325 minecraft:honeycomb_block
setblock 32 296 323 minecraft:yellow_terracotta
fill 32 296 324 32 297 324 minecraft:honeycomb_block
setblock 32 296 363 minecraft:yellow_terracotta
fill 33 296 323 33 298 323 minecraft:honeycomb_block
fill 33 296 363 33 299 363 minecraft:honeycomb_block
setblock 36 296 363 minecraft:honeycomb_block
setblock 37 296 323 minecraft:yellow_terracotta
setblock 37 296 363 minecraft:yellow_terracotta
fill 38 296 363 38 299 363 minecraft:honeycomb_block
setblock 40 296 323 minecraft:honey_block
fill 40 296 351 40 298 351 minecraft:honeycomb_block
fill 40 296 353 40 296 354 minecraft:honeycomb_block
setblock 40 296 355 minecraft:yellow_terracotta
fill 40 296 356 40 299 356 minecraft:honeycomb_block
fill 40 296 358 40 296 359 minecraft:honeycomb_block
setblock 40 296 364 minecraft:yellow_terracotta
setblock 41 296 325 minecraft:honeycomb_block
setblock 41 296 329 minecraft:yellow_terracotta
fill 41 296 330 41 299 330 minecraft:honeycomb_block
setblock 41 296 334 minecraft:yellow_terracotta
setblock 41 296 341 minecraft:honey_block
setblock 41 296 349 minecraft:yellow_terracotta
fill 41 296 350 41 299 350 minecraft:honeycomb_block
setblock 41 296 354 minecraft:yellow_terracotta
fill 41 296 355 41 299 355 minecraft:honeycomb_block
setblock 41 296 358 minecraft:honeycomb_block
setblock 41 296 359 minecraft:yellow_terracotta
fill 41 296 360 41 299 360 minecraft:honeycomb_block
setblock 42 296 345 minecraft:honeycomb_block
setblock 1 297 326 minecraft:honey_block
fill 1 297 329 1 298 329 minecraft:honeycomb_block
setblock 1 297 333 minecraft:yellow_terracotta
fill 1 297 334 1 300 334 minecraft:honeycomb_block
setblock 1 297 338 minecraft:yellow_terracotta
fill 1 297 339 1 299 340 minecraft:honeycomb_block
setblock 1 297 343 minecraft:yellow_terracotta
fill 1 297 344 1 300 344 minecraft:honeycomb_block
setblock 1 297 348 minecraft:yellow_terracotta
fill 1 297 349 1 300 349 minecraft:honeycomb_block
setblock 1 297 353 minecraft:yellow_terracotta
fill 1 297 354 1 300 354 minecraft:honeycomb_block
setblock 1 297 357 minecraft:honeycomb_block
setblock 1 297 358 minecraft:yellow_terracotta
fill 1 297 359 1 300 359 minecraft:honeycomb_block
setblock 2 297 331 minecraft:honeycomb_block
setblock 2 297 332 minecraft:yellow_terracotta
fill 2 297 333 2 300 333 minecraft:honeycomb_block
fill 2 297 335 2 297 336 minecraft:honeycomb_block
setblock 2 297 347 minecraft:yellow_terracotta
fill 2 297 348 2 300 348 minecraft:honeycomb_block
setblock 2 297 352 minecraft:yellow_terracotta
fill 2 297 353 2 300 353 minecraft:honeycomb_block
setblock 2 297 356 minecraft:honeycomb_block
setblock 2 297 357 minecraft:yellow_terracotta
fill 2 297 358 2 300 358 minecraft:honeycomb_block
fill 2 297 363 2 300 363 minecraft:honeycomb_block
setblock 3 297 325 minecraft:light[level=12]
setblock 3 297 332 minecraft:light[level=12]
setblock 3 297 339 minecraft:light[level=12]
setblock 3 297 346 minecraft:light[level=12]
fill 3 297 349 3 297 350 minecraft:honeycomb_block
setblock 3 297 351 minecraft:yellow_terracotta
fill 3 297 352 3 300 352 minecraft:honeycomb_block
setblock 3 297 356 minecraft:yellow_terracotta
fill 3 297 357 3 300 357 minecraft:honeycomb_block
setblock 3 297 360 minecraft:light[level=12]
setblock 4 297 350 minecraft:yellow_terracotta
fill 4 297 351 4 298 351 minecraft:honeycomb_block
setblock 4 297 355 minecraft:yellow_terracotta
fill 4 297 356 4 299 356 minecraft:honeycomb_block
setblock 6 297 322 minecraft:orange_terracotta
setblock 6 297 323 minecraft:yellow_terracotta
setblock 6 297 363 minecraft:yellow_terracotta
setblock 7 297 323 minecraft:honeycomb_block
fill 7 297 363 7 300 364 minecraft:honeycomb_block
setblock 9 297 323 minecraft:honey_block
setblock 10 297 325 minecraft:light[level=12]
setblock 10 297 332 minecraft:light[level=12]
setblock 10 297 339 minecraft:light[level=12]
setblock 10 297 346 minecraft:light[level=12]
setblock 10 297 353 minecraft:light[level=12]
setblock 10 297 360 minecraft:light[level=12]
setblock 17 297 325 minecraft:light[level=12]
setblock 17 297 332 minecraft:light[level=12]
setblock 17 297 339 minecraft:light[level=12]
setblock 17 297 346 minecraft:light[level=12]
setblock 17 297 353 minecraft:light[level=12]
setblock 17 297 360 minecraft:light[level=12]
setblock 21 297 323 minecraft:yellow_terracotta
fill 22 297 323 25 297 323 minecraft:honeycomb_block
fill 23 297 324 24 297 324 minecraft:honeycomb_block
setblock 24 297 325 minecraft:yellow_terracotta
setblock 24 297 332 minecraft:light[level=12]
setblock 24 297 339 minecraft:light[level=12]
setblock 24 297 346 minecraft:light[level=12]
setblock 24 297 353 minecraft:light[level=12]
setblock 24 297 360 minecraft:light[level=12]
fill 24 297 363 25 297 363 minecraft:honeycomb_block
setblock 25 297 324 minecraft:yellow_terracotta
fill 25 297 325 25 298 325 minecraft:honeycomb_block
setblock 26 297 323 minecraft:yellow_terracotta
fill 26 297 324 26 300 324 minecraft:honeycomb_block
setblock 26 297 362 minecraft:honeycomb_block
setblock 26 297 363 minecraft:yellow_terracotta
fill 27 297 323 27 300 323 minecraft:honeycomb_block
fill 27 297 357 27 297 361 minecraft:honey_block
setblock 27 297 362 minecraft:yellow_terracotta
fill 27 297 363 27 300 363 minecraft:honeycomb_block
fill 28 297 356 28 297 358 minecraft:honey_block
fill 28 297 360 28 298 361 minecraft:honey_block
fill 28 297 362 28 300 362 minecraft:honeycomb_block
setblock 29 297 325 minecraft:yellow_terracotta
fill 29 297 356 31 297 357 minecraft:honey_block
fill 29 297 361 32 297 361 minecraft:honey_block
setblock 30 297 324 minecraft:yellow_terracotta
setblock 30 297 325 minecraft:honeycomb_block
setblock 31 297 323 minecraft:yellow_terracotta
fill 31 297 324 31 298 324 minecraft:honeycomb_block
setblock 31 297 332 minecraft:light[level=12]
setblock 31 297 339 minecraft:light[level=12]
setblock 31 297 346 minecraft:light[level=12]
setblock 31 297 353 minecraft:light[level=12]
setblock 31 297 363 minecraft:yellow_terracotta
fill 32 297 323 32 299 323 minecraft:honeycomb_block
fill 32 297 357 32 297 360 minecraft:honey_block
setblock 32 297 362 minecraft:yellow_terracotta
fill 32 297 363 32 300 363 minecraft:honeycomb_block
setblock 33 297 359 minecraft:honey_block
fill 34 297 342 35 297 346 minecraft:honey_block
fill 35 297 341 40 297 341 minecraft:honey_block
fill 35 297 347 40 297 347 minecraft:honey_block
fill 36 297 340 39 297 340 minecraft:honey_block
fill 36 297 342 36 299 342 minecraft:honey_block
fill 36 297 346 36 299 346 minecraft:honey_block
fill 36 297 348 39 297 348 minecraft:honey_block
setblock 36 297 363 minecraft:yellow_terracotta
fill 37 297 363 37 298 363 minecraft:honeycomb_block
setblock 38 297 325 minecraft:light[level=12]
setblock 38 297 332 minecraft:light[level=12]
setblock 38 297 339 minecraft:light[level=12]
setblock 38 297 353 minecraft:light[level=12]
setblock 38 297 360 minecraft:light[level=12]
fill 39 297 342 41 297 342 minecraft:honey_block
fill 39 297 346 41 297 346 minecraft:honey_block
fill 40 297 343 41 298 345 minecraft:honey_block
setblock 40 297 353 minecraft:honeycomb_block
setblock 40 297 354 minecraft:yellow_terracotta
fill 40 297 355 40 300 355 minecraft:honeycomb_block
setblock 40 297 358 minecraft:honeycomb_block
setblock 40 297 359 minecraft:yellow_terracotta
fill 40 297 360 40 300 360 minecraft:honeycomb_block
fill 40 297 364 40 308 364 minecraft:honeycomb_block
setblock 41 297 328 minecraft:yellow_terracotta
fill 41 297 329 41 298 329 minecraft:honeycomb_block
setblock 41 297 333 minecraft:yellow_terracotta
fill 41 297 334 41 299 335 minecraft:honeycomb_block
setblock 41 297 348 minecraft:yellow_terracotta
fill 41 297 349 41 300 349 minecraft:honeycomb_block
setblock 41 297 353 minecraft:yellow_terracotta
fill 41 297 354 41 300 354 minecraft:honeycomb_block
setblock 41 297 358 minecraft:yellow_terracotta
fill 41 297 359 41 300 359 minecraft:honeycomb_block
setblock 41 297 362 minecraft:honeycomb_block
setblock 41 297 363 minecraft:yellow_terracotta
setblock 42 297 345 minecraft:yellow_concrete
setblock 1 298 332 minecraft:yellow_terracotta
fill 1 298 333 1 300 333 minecraft:honeycomb_block
fill 1 298 335 1 298 336 minecraft:honeycomb_block
setblock 1 298 337 minecraft:yellow_terracotta
fill 1 298 338 2 300 338 minecraft:honeycomb_block
setblock 1 298 341 minecraft:honeycomb_block
setblock 1 298 342 minecraft:yellow_terracotta
fill 1 298 343 1 300 343 minecraft:honeycomb_block
setblock 1 298 347 minecraft:yellow_terracotta
fill 1 298 348 1 300 348 minecraft:honeycomb_block
setblock 1 298 352 minecraft:yellow_terracotta
fill 1 298 353 1 300 353 minecraft:honeycomb_block
setblock 1 298 357 minecraft:yellow_terracotta
fill 1 298 358 1 300 358 minecraft:honeycomb_block
setblock 1 298 362 minecraft:yellow_terracotta
setblock 2 298 331 minecraft:yellow_terracotta
fill 2 298 332 2 300 332 minecraft:honeycomb_block
setblock 2 298 335 minecraft:honeycomb_block
setblock 2 298 336 minecraft:yellow_terracotta
fill 2 298 337 2 300 337 minecraft:honeycomb_block
setblock 2 298 346 minecraft:yellow_terracotta
fill 2 298 347 2 300 347 minecraft:honeycomb_block
setblock 2 298 351 minecraft:yellow_terracotta
fill 2 298 352 2 300 352 minecraft:honeycomb_block
setblock 2 298 356 minecraft:yellow_terracotta
fill 2 298 357 2 300 357 minecraft:honeycomb_block
setblock 3 298 323 minecraft:honey_block
setblock 3 298 349 minecraft:honeycomb_block
setblock 3 298 350 minecraft:yellow_terracotta
fill 3 298 351 3 300 351 minecraft:honeycomb_block
setblock 3 298 355 minecraft:yellow_terracotta
fill 3 298 356 3 300 356 minecraft:honeycomb_block
setblock 3 298 359 minecraft:honeycomb_block
setblock 4 298 354 minecraft:yellow_terracotta
fill 4 298 355 4 300 355 minecraft:honeycomb_block
setblock 5 298 363 minecraft:yellow_terracotta
fill 6 298 322 6 302 322 minecraft:honeycomb_block
fill 6 298 363 6 300 363 minecraft:honeycomb_block
setblock 11 298 325 minecraft:brown_terracotta
setblock 11 298 327 minecraft:brown_terracotta
setblock 13 298 325 minecraft:brown_terracotta
setblock 13 298 327 minecraft:brown_terracotta
setblock 14 298 363 minecraft:honey_block
fill 21 298 323 24 298 323 minecraft:honeycomb_block
setblock 23 298 324 minecraft:honeycomb_block
fill 23 298 363 24 298 363 minecraft:honeycomb_block
setblock 24 298 324 minecraft:yellow_terracotta
setblock 25 298 323 minecraft:yellow_terracotta
fill 25 298 324 25 300 324 minecraft:honeycomb_block
setblock 25 298 363 minecraft:yellow_terracotta
fill 26 298 323 26 300 323 minecraft:honeycomb_block
setblock 26 298 362 minecraft:yellow_terracotta
fill 26 298 363 26 300 363 minecraft:honeycomb_block
fill 27 298 358 27 298 360 minecraft:honey_block
fill 27 298 362 27 300 362 minecraft:honeycomb_block
setblock 28 298 325 minecraft:yellow_terracotta
fill 28 298 357 28 298 358 minecraft:honey_block
setblock 29 298 324 minecraft:yellow_terracotta
setblock 29 298 325 minecraft:honeycomb_block
fill 29 298 357 31 298 357 minecraft:honey_block
fill 29 298 361 31 298 361 minecraft:honey_block
setblock 30 298 323 minecraft:yellow_terracotta
fill 30 298 324 30 299 324 minecraft:honeycomb_block
setblock 30 298 363 minecraft:yellow_terracotta
fill 31 298 323 31 300 323 minecraft:honeycomb_block
setblock 31 298 362 minecraft:yellow_terracotta
fill 31 298 363 31 300 363 minecraft:honeycomb_block
fill 32 298 358 32 298 360 minecraft:honey_block
fill 34 298 344 35 298 344 minecraft:honey_block
fill 35 298 342 35 298 343 minecraft:honey_block
fill 35 298 345 35 298 346 minecraft:honey_block
setblock 35 298 363 minecraft:yellow_terracotta
fill 36 298 341 39 298 341 minecraft:honey_block
fill 36 298 347 39 298 347 minecraft:honey_block
setblock 36 298 363 minecraft:honeycomb_block
fill 39 298 342 40 298 342 minecraft:honey_block
fill 39 298 346 40 298 346 minecraft:honey_block
setblock 39 298 363 minecraft:honeycomb_block
setblock 40 298 353 minecraft:yellow_terracotta
fill 40 298 354 40 300 354 minecraft:honeycomb_block
setblock 40 298 358 minecraft:yellow_terracotta
fill 40 298 359 40 300 359 minecraft:honeycomb_block
fill 40 298 361 40 299 361 minecraft:honeycomb_block
setblock 40 298 363 minecraft:yellow_terracotta
setblock 41 298 328 minecraft:honeycomb_block
setblock 41 298 332 minecraft:yellow_terracotta
fill 41 298 333 41 300 333 minecraft:honeycomb_block
setblock 41 298 336 minecraft:honeycomb_block
fill 41 298 348 41 299 348 minecraft:honeycomb_block
setblock 41 298 352 minecraft:yellow_terracotta
fill 41 298 353 41 300 353 minecraft:honeycomb_block
setblock 41 298 357 minecraft:yellow_terracotta
fill 41 298 358 41 300 358 minecraft:honeycomb_block
setblock 41 298 362 minecraft:yellow_terracotta
fill 41 298 363 41 300 363 minecraft:honeycomb_block
fill 42 298 345 42 308 345 minecraft:honeycomb_block
setblock 0 299 354 minecraft:orange_terracotta
fill 0 299 360 1 299 360 minecraft:honeycomb_block
setblock 1 299 331 minecraft:yellow_terracotta
fill 1 299 332 1 300 332 minecraft:honeycomb_block
setblock 1 299 335 minecraft:honeycomb_block
setblock 1 299 336 minecraft:yellow_terracotta
fill 1 299 337 1 300 337 minecraft:honeycomb_block
setblock 1 299 341 minecraft:yellow_terracotta
fill 1 299 342 1 300 342 minecraft:honeycomb_block
setblock 1 299 346 minecraft:yellow_terracotta
fill 1 299 347 1 300 347 minecraft:honeycomb_block
setblock 1 299 351 minecraft:yellow_terracotta
fill 1 299 352 1 300 352 minecraft:honeycomb_block
setblock 1 299 356 minecraft:yellow_terracotta
fill 1 299 357 1 300 357 minecraft:honeycomb_block
setblock 1 299 361 minecraft:yellow_terracotta
fill 1 299 362 1 300 362 minecraft:honeycomb_block
setblock 1 299 363 minecraft:honey_block
setblock 2 299 335 minecraft:yellow_terracotta
fill 2 299 336 3 300 336 minecraft:honeycomb_block
setblock 2 299 339 minecraft:honeycomb_block
setblock 2 299 340 minecraft:yellow_terracotta
setblock 2 299 346 minecraft:honeycomb_block
setblock 2 299 350 minecraft:yellow_terracotta
fill 2 299 351 2 300 351 minecraft:honeycomb_block
setblock 2 299 355 minecraft:yellow_terracotta
fill 2 299 356 2 300 356 minecraft:honeycomb_block
setblock 2 299 360 minecraft:yellow_terracotta
fill 2 299 361 2 300 361 minecraft:honeycomb_block
setblock 3 299 334 minecraft:yellow_terracotta
fill 3 299 335 3 300 335 minecraft:honeycomb_block
setblock 3 299 349 minecraft:yellow_terracotta
fill 3 299 350 3 300 350 minecraft:honeycomb_block
setblock 3 299 354 minecraft:yellow_terracotta
fill 3 299 355 3 300 355 minecraft:honeycomb_block
setblock 3 299 359 minecraft:yellow_terracotta
setblock 4 299 353 minecraft:yellow_terracotta
setblock 4 299 354 minecraft:honeycomb_block
setblock 4 299 363 minecraft:yellow_terracotta
fill 5 299 363 5 300 363 minecraft:honeycomb_block
setblock 7 299 322 minecraft:yellow_terracotta
setblock 20 299 363 minecraft:honey_block
fill 21 299 323 23 299 323 minecraft:honeycomb_block
setblock 23 299 324 minecraft:yellow_terracotta
setblock 23 299 363 minecraft:honeycomb_block
setblock 24 299 323 minecraft:yellow_terracotta
fill 24 299 324 24 300 324 minecraft:honeycomb_block
setblock 24 299 363 minecraft:yellow_terracotta
fill 25 299 323 25 300 323 minecraft:honeycomb_block
setblock 25 299 362 minecraft:yellow_terracotta
fill 25 299 363 25 300 363 minecraft:honeycomb_block
fill 26 299 362 26 300 362 minecraft:honeycomb_block
setblock 28 299 324 minecraft:yellow_terracotta
setblock 28 299 358 minecraft:honey_block
setblock 28 299 360 minecraft:honey_block
setblock 29 299 323 minecraft:yellow_terracotta
setblock 29 299 324 minecraft:honeycomb_block
fill 29 299 357 30 299 357 minecraft:honey_block
fill 29 299 361 30 299 361 minecraft:honey_block
setblock 29 299 363 minecraft:yellow_terracotta
fill 30 299 323 30 300 323 minecraft:honeycomb_block
setblock 30 299 362 minecraft:yellow_terracotta
fill 30 299 363 30 300 363 minecraft:honeycomb_block
setblock 31 299 362 minecraft:honeycomb_block
setblock 34 299 363 minecraft:yellow_terracotta
fill 35 299 343 35 299 345 minecraft:honey_block
setblock 35 299 363 minecraft:honeycomb_block
setblock 38 299 341 minecraft:honey_block
setblock 39 299 342 minecraft:honey_block
setblock 39 299 346 minecraft:honey_block
setblock 39 299 363 minecraft:yellow_terracotta
fill 40 299 343 40 299 345 minecraft:honey_block
setblock 40 299 352 minecraft:yellow_terracotta
fill 40 299 353 40 300 353 minecraft:honeycomb_block
setblock 40 299 357 minecraft:yellow_terracotta
fill 40 299 358 40 300 358 minecraft:honeycomb_block
fill 40 299 363 40 300 363 minecraft:honeycomb_block
setblock 41 299 323 minecraft:honey_block
setblock 41 299 331 minecraft:yellow_terracotta
fill 41 299 332 41 300 332 minecraft:honeycomb_block
setblock 41 299 336 minecraft:yellow_terracotta
fill 41 299 337 41 300 337 minecraft:honeycomb_block
setblock 41 299 351 minecraft:yellow_terracotta
fill 41 299 352 41 300 352 minecraft:honeycomb_block
setblock 41 299 356 minecraft:yellow_terracotta
fill 41 299 357 41 300 357 minecraft:honeycomb_block
setblock 41 299 361 minecraft:yellow_terracotta
fill 41 299 362 41 300 362 minecraft:honeycomb_block
setblock 42 299 326 minecraft:yellow_terracotta
fill 0 300 354 0 308 354 minecraft:honeycomb_block
fill 0 300 360 0 308 360 minecraft:honeycomb_block
setblock 1 300 325 minecraft:honey_block
setblock 1 300 330 minecraft:yellow_terracotta
setblock 1 300 331 minecraft:honeycomb_block
setblock 1 300 335 minecraft:yellow_terracotta
setblock 1 300 336 minecraft:honeycomb_block
setblock 1 300 339 minecraft:honeycomb_block
setblock 1 300 340 minecraft:yellow_terracotta
fill 1 300 341 2 300 341 minecraft:honeycomb_block
setblock 1 300 345 minecraft:yellow_terracotta
setblock 1 300 346 minecraft:honeycomb_block
setblock 1 300 350 minecraft:yellow_terracotta
setblock 1 300 351 minecraft:honeycomb_block
setblock 1 300 355 minecraft:yellow_terracotta
setblock 1 300 356 minecraft:honeycomb_block
setblock 1 300 360 minecraft:yellow_terracotta
setblock 1 300 361 minecraft:honeycomb_block
setblock 1 300 363 minecraft:honeycomb_block
setblock 2 300 334 minecraft:yellow_terracotta
setblock 2 300 335 minecraft:honeycomb_block
setblock 2 300 339 minecraft:yellow_terracotta
setblock 2 300 340 minecraft:honeycomb_block
setblock 2 300 349 minecraft:yellow_terracotta
setblock 2 300 350 minecraft:honeycomb_block
setblock 2 300 354 minecraft:yellow_terracotta
setblock 2 300 355 minecraft:honeycomb_block
setblock 2 300 359 minecraft:yellow_terracotta
setblock 2 300 360 minecraft:honeycomb_block
setblock 3 300 334 minecraft:honeycomb_block
setblock 3 300 337 minecraft:honeycomb_block
setblock 3 300 338 minecraft:yellow_terracotta
setblock 3 300 353 minecraft:yellow_terracotta
setblock 3 300 354 minecraft:honeycomb_block
setblock 3 300 358 minecraft:yellow_terracotta
setblock 3 300 359 minecraft:honeycomb_block
setblock 3 300 363 minecraft:yellow_terracotta
setblock 4 300 363 minecraft:honeycomb_block
fill 7 300 322 7 308 322 minecraft:honeycomb_block
setblock 16 300 323 minecraft:honey_block
fill 21 300 323 22 300 323 minecraft:honeycomb_block
setblock 22 300 363 minecraft:honeycomb_block
setblock 23 300 323 minecraft:yellow_terracotta
setblock 23 300 324 minecraft:honeycomb_block
setblock 23 300 363 minecraft:yellow_terracotta
setblock 24 300 323 minecraft:honeycomb_block
setblock 24 300 362 minecraft:yellow_terracotta
setblock 24 300 363 minecraft:honeycomb_block
setblock 25 300 362 minecraft:honeycomb_block
setblock 27 300 324 minecraft:yellow_terracotta
setblock 28 300 323 minecraft:yellow_terracotta
setblock 28 300 324 minecraft:honeycomb_block
setblock 28 300 363 minecraft:yellow_terracotta
setblock 29 300 323 minecraft:honeycomb_block
setblock 29 300 362 minecraft:yellow_terracotta
setblock 29 300 363 minecraft:honeycomb_block
setblock 30 300 362 minecraft:honeycomb_block
setblock 33 300 322 minecraft:orange_terracotta
setblock 33 300 363 minecraft:yellow_terracotta
setblock 34 300 363 minecraft:honeycomb_block
setblock 35 300 323 minecraft:honey_block
setblock 37 300 363 minecraft:honeycomb_block
setblock 38 300 363 minecraft:yellow_terracotta
setblock 39 300 363 minecraft:honeycomb_block
setblock 40 300 352 minecraft:honeycomb_block
setblock 40 300 356 minecraft:yellow_terracotta
setblock 40 300 357 minecraft:honeycomb_block
setblock 40 300 361 minecraft:yellow_terracotta
setblock 41 300 331 minecraft:honeycomb_block
setblock 41 300 334 minecraft:honeycomb_block
setblock 41 300 335 minecraft:yellow_terracotta
setblock 41 300 336 minecraft:honeycomb_block
setblock 41 300 338 minecraft:honeycomb_block
setblock 41 300 342 minecraft:honey_block
setblock 41 300 350 minecraft:yellow_terracotta
setblock 41 300 351 minecraft:honeycomb_block
setblock 41 300 355 minecraft:yellow_terracotta
setblock 41 300 356 minecraft:honeycomb_block
setblock 41 300 360 minecraft:yellow_terracotta
setblock 41 300 361 minecraft:honeycomb_block
fill 42 300 326 42 308 326 minecraft:honeycomb_block
setblock 6 301 364 minecraft:yellow_terracotta
fill 7 301 364 7 308 364 minecraft:honeycomb_block
setblock 18 301 364 minecraft:orange_terracotta
fill 33 301 322 33 308 322 minecraft:honeycomb_block
fill 6 302 364 6 308 364 minecraft:honeycomb_block
fill 18 302 364 18 308 364 minecraft:honeycomb_block
setblock 3 303 325 minecraft:light[level=15]
setblock 3 303 332 minecraft:light[level=12]
setblock 3 303 333 minecraft:light[level=15]
setblock 3 303 339 minecraft:light[level=12]
setblock 3 303 341 minecraft:light[level=15]
setblock 3 303 346 minecraft:light[level=12]
setblock 3 303 349 minecraft:light[level=15]
setblock 3 303 353 minecraft:light[level=12]
setblock 3 303 357 minecraft:light[level=15]
setblock 3 303 360 minecraft:light[level=12]
setblock 6 303 322 minecraft:yellow_concrete
setblock 10 303 325 minecraft:light[level=12]
setblock 10 303 332 minecraft:light[level=12]
setblock 10 303 339 minecraft:light[level=12]
setblock 10 303 346 minecraft:light[level=12]
setblock 10 303 353 minecraft:light[level=12]
setblock 10 303 360 minecraft:light[level=12]
setblock 11 303 325 minecraft:light[level=15]
setblock 11 303 333 minecraft:light[level=15]
setblock 11 303 341 minecraft:light[level=15]
setblock 11 303 349 minecraft:light[level=15]
setblock 11 303 357 minecraft:light[level=15]
setblock 17 303 325 minecraft:light[level=12]
setblock 17 303 332 minecraft:light[level=12]
setblock 17 303 339 minecraft:light[level=12]
setblock 17 303 346 minecraft:light[level=12]
setblock 17 303 353 minecraft:light[level=12]
setblock 17 303 360 minecraft:light[level=12]
setblock 19 303 325 minecraft:light[level=15]
setblock 19 303 333 minecraft:light[level=15]
setblock 19 303 341 minecraft:light[level=15]
setblock 19 303 349 minecraft:light[level=15]
setblock 19 303 357 minecraft:light[level=15]
setblock 24 303 325 minecraft:light[level=12]
setblock 24 303 332 minecraft:light[level=12]
setblock 24 303 339 minecraft:light[level=12]
setblock 24 303 346 minecraft:light[level=12]
setblock 24 303 353 minecraft:light[level=12]
setblock 24 303 360 minecraft:light[level=12]
setblock 27 303 325 minecraft:light[level=15]
setblock 27 303 333 minecraft:light[level=15]
setblock 27 303 341 minecraft:light[level=15]
setblock 27 303 349 minecraft:light[level=15]
setblock 27 303 357 minecraft:light[level=15]
setblock 31 303 325 minecraft:light[level=12]
setblock 31 303 332 minecraft:light[level=12]
setblock 31 303 339 minecraft:light[level=12]
setblock 31 303 346 minecraft:light[level=12]
setblock 31 303 353 minecraft:light[level=12]
setblock 31 303 360 minecraft:light[level=12]
setblock 35 303 325 minecraft:light[level=15]
setblock 35 303 333 minecraft:light[level=15]
setblock 35 303 341 minecraft:light[level=15]
setblock 35 303 349 minecraft:light[level=15]
setblock 35 303 357 minecraft:light[level=15]
setblock 38 303 325 minecraft:light[level=12]
setblock 38 303 332 minecraft:light[level=12]
setblock 38 303 339 minecraft:light[level=12]
setblock 38 303 346 minecraft:light[level=12]
setblock 38 303 353 minecraft:light[level=12]
setblock 38 303 360 minecraft:light[level=12]
fill 6 304 322 6 308 322 minecraft:honeycomb_block
setblock 42 304 338 minecraft:orange_terracotta
setblock 0 305 361 minecraft:yellow_terracotta
fill 42 305 338 42 308 338 minecraft:honeycomb_block
setblock 0 306 339 minecraft:yellow_terracotta
fill 0 306 361 0 308 361 minecraft:honeycomb_block
setblock 13 306 322 minecraft:orange_terracotta
fill 0 307 339 0 308 339 minecraft:honeycomb_block
fill 13 307 322 13 308 322 minecraft:honeycomb_block
setblock 0 308 331 minecraft:yellow_concrete
setblock 0 308 356 minecraft:yellow_terracotta
setblock 3 308 322 minecraft:yellow_terracotta
setblock 27 308 364 minecraft:yellow_concrete
setblock 39 308 322 minecraft:orange_terracotta
