fill 472 221 268 472 225 269 minecraft:white_concrete
setblock 473 221 233 minecraft:red_concrete
setblock 473 221 269 minecraft:red_concrete
setblock 474 221 229 minecraft:white_concrete
fill 474 221 230 475 224 230 minecraft:red_concrete
setblock 474 221 265 minecraft:white_concrete
fill 474 221 266 475 224 266 minecraft:red_concrete
fill 508 221 232 508 225 233 minecraft:white_concrete
fill 508 221 268 508 225 269 minecraft:white_concrete
setblock 509 221 233 minecraft:red_concrete
setblock 509 221 269 minecraft:red_concrete
setblock 510 221 229 minecraft:white_concrete
fill 510 221 230 511 224 230 minecraft:red_concrete
setblock 510 221 265 minecraft:white_concrete
fill 510 221 266 511 224 266 minecraft:red_concrete
fill 473 222 229 473 226 230 minecraft:red_concrete
fill 473 222 232 473 226 233 minecraft:white_concrete
fill 473 222 265 473 226 266 minecraft:red_concrete
fill 473 222 268 473 226 269 minecraft:white_concrete
fill 474 222 229 474 225 229 minecraft:red_concrete
fill 474 222 265 474 225 265 minecraft:red_concrete
fill 483 222 231 483 225 235 minecraft:magenta_concrete
fill 484 222 231 484 225 232 minecraft:magenta_concrete
fill 484 222 233 484 223 233 minecraft:white_concrete
fill 484 222 234 484 225 235 minecraft:magenta_concrete
fill 485 222 231 487 225 231 minecraft:magenta_concrete
fill 485 222 235 487 225 235 minecraft:magenta_concrete
fill 486 222 232 487 225 232 minecraft:magenta_concrete
fill 486 222 234 487 225 234 minecraft:magenta_concrete
fill 487 222 233 487 225 233 minecraft:magenta_concrete
fill 509 222 229 509 226 230 minecraft:red_concrete
fill 509 222 232 509 226 233 minecraft:white_concrete
fill 509 222 265 509 226 266 minecraft:red_concrete
fill 509 222 268 509 226 269 minecraft:white_concrete
fill 510 222 229 510 225 229 minecraft:red_concrete
fill 510 222 265 510 225 265 minecraft:red_concrete
fill 472 223 229 472 227 229 minecraft:red_concrete
setblock 472 223 230 minecraft:white_concrete
fill 472 223 265 472 227 265 minecraft:red_concrete
setblock 472 223 266 minecraft:white_concrete
fill 474 223 232 474 227 233 minecraft:white_concrete
fill 474 223 268 474 227 269 minecraft:white_concrete
setblock 475 223 232 minecraft:red_concrete
setblock 475 223 268 minecraft:red_concrete
fill 482 223 231 482 224 235 minecraft:magenta_concrete
fill 483 223 230 487 224 230 minecraft:magenta_concrete
fill 483 223 236 487 224 236 minecraft:magenta_concrete
fill 488 223 231 488 224 235 minecraft:magenta_concrete
fill 508 223 229 508 227 229 minecraft:red_concrete
setblock 508 223 230 minecraft:white_concrete
fill 508 223 265 508 227 265 minecraft:red_concrete
setblock 508 223 266 minecraft:white_concrete
fill 510 223 232 510 227 233 minecraft:white_concrete
fill 510 223 268 510 227 269 minecraft:white_concrete
setblock 511 223 232 minecraft:red_concrete
setblock 511 223 268 minecraft:red_concrete
fill 471 224 230 472 227 230 minecraft:red_concrete
fill 471 224 266 472 227 266 minecraft:red_concrete
setblock 473 224 239 minecraft:light[level=15]
setblock 473 224 247 minecraft:light[level=15]
setblock 473 224 255 minecraft:light[level=15]
setblock 473 224 263 minecraft:light[level=15]
fill 475 224 232 475 228 232 minecraft:white_concrete
fill 475 224 268 475 228 268 minecraft:white_concrete
setblock 481 224 231 minecraft:light[level=15]
setblock 481 224 239 minecraft:light[level=15]
setblock 481 224 247 minecraft:light[level=15]
setblock 481 224 255 minecraft:light[level=15]
setblock 481 224 263 minecraft:light[level=15]
fill 484 224 233 486 225 233 minecraft:magenta_concrete
fill 485 224 232 485 225 232 minecraft:magenta_concrete
fill 485 224 234 485 225 234 minecraft:magenta_concrete
setblock 489 224 231 minecraft:light[level=15]
setblock 489 224 239 minecraft:light[level=15]
setblock 489 224 247 minecraft:light[level=15]
setblock 489 224 255 minecraft:light[level=15]
setblock 489 224 263 minecraft:light[level=15]
setblock 497 224 231 minecraft:light[level=15]
setblock 497 224 239 minecraft:light[level=15]
setblock 497 224 247 minecraft:light[level=15]
setblock 497 224 255 minecraft:light[level=15]
setblock 497 224 263 minecraft:light[level=15]
setblock 505 224 231 minecraft:light[level=15]
setblock 505 224 239 minecraft:light[level=15]
setblock 505 224 247 minecraft:light[level=15]
setblock 505 224 255 minecraft:light[level=15]
setblock 505 224 263 minecraft:light[level=15]
fill 507 224 230 508 227 230 minecraft:red_concrete
fill 507 224 266 508 227 266 minecraft:red_concrete
fill 511 224 232 511 228 232 minecraft:white_concrete
fill 511 224 268 511 228 268 minecraft:white_concrete
fill 471 225 231 472 229 231 minecraft:red_concrete
setblock 471 225 232 minecraft:white_concrete
fill 471 225 267 472 229 267 minecraft:red_concrete
setblock 471 225 268 minecraft:white_concrete
fill 473 225 231 475 229 231 minecraft:white_concrete
fill 473 225 267 475 229 267 minecraft:white_concrete
setblock 474 225 230 minecraft:red_concrete
setblock 474 225 266 minecraft:red_concrete
fill 475 225 230 475 230 230 minecraft:white_concrete
fill 475 225 266 475 230 266 minecraft:white_concrete
fill 482 225 233 482 264 234 minecraft:white_concrete
fill 494 225 263 494 226 263 minecraft:pink_concrete
fill 507 225 231 508 229 231 minecraft:red_concrete
setblock 507 225 232 minecraft:white_concrete
fill 507 225 267 508 229 267 minecraft:red_concrete
setblock 507 225 268 minecraft:white_concrete
fill 509 225 231 511 229 231 minecraft:white_concrete
fill 509 225 267 511 229 267 minecraft:white_concrete
setblock 510 225 230 minecraft:red_concrete
setblock 510 225 266 minecraft:red_concrete
fill 511 225 230 511 230 230 minecraft:white_concrete
fill 511 225 266 511 230 266 minecraft:white_concrete
fill 471 226 232 472 229 232 minecraft:red_concrete
fill 471 226 268 472 229 268 minecraft:red_concrete
setblock 472 226 233 minecraft:white_concrete
setblock 472 226 269 minecraft:white_concrete
setblock 473 226 238 minecraft:light[level=12]
setblock 473 226 245 minecraft:light[level=12]
setblock 473 226 252 minecraft:light[level=12]
setblock 473 226 259 minecraft:light[level=12]
fill 474 226 229 474 230 230 minecraft:white_concrete
fill 474 226 265 474 230 266 minecraft:white_concrete
setblock 480 226 231 minecraft:light[level=12]
setblock 480 226 238 minecraft:light[level=12]
setblock 480 226 245 minecraft:light[level=12]
setblock 480 226 252 minecraft:light[level=12]
setblock 480 226 259 minecraft:light[level=12]
setblock 480 226 266 minecraft:light[level=12]
fill 483 226 232 483 264 235 minecraft:white_concrete
fill 484 226 233 484 264 235 minecraft:white_concrete
setblock 487 226 231 minecraft:light[level=12]
setblock 487 226 238 minecraft:light[level=12]
setblock 487 226 245 minecraft:light[level=12]
setblock 487 226 259 minecraft:light[level=12]
setblock 487 226 266 minecraft:light[level=12]
setblock 494 226 231 minecraft:light[level=12]
setblock 494 226 238 minecraft:light[level=12]
setblock 494 226 245 minecraft:light[level=12]
setblock 494 226 252 minecraft:light[level=12]
setblock 494 226 259 minecraft:light[level=12]
setblock 494 226 266 minecraft:light[level=12]
setblock 501 226 231 minecraft:light[level=12]
setblock 501 226 238 minecraft:light[level=12]
setblock 501 226 245 minecraft:light[level=12]
setblock 501 226 252 minecraft:light[level=12]
setblock 501 226 259 minecraft:light[level=12]
setblock 501 226 266 minecraft:light[level=12]
fill 507 226 232 508 229 232 minecraft:red_concrete
fill 507 226 268 508 229 268 minecraft:red_concrete
setblock 508 226 233 minecraft:white_concrete
setblock 508 226 238 minecraft:light[level=12]
setblock 508 226 245 minecraft:light[level=12]
setblock 508 226 252 minecraft:light[level=12]
setblock 508 226 259 minecraft:light[level=12]
setblock 508 226 269 minecraft:white_concrete
fill 510 226 229 510 230 230 minecraft:white_concrete
fill 510 226 265 510 230 266 minecraft:white_concrete
fill 472 227 233 473 230 233 minecraft:red_concrete
fill 472 227 269 473 230 269 minecraft:red_concrete
fill 473 227 229 473 230 230 minecraft:white_concrete
fill 473 227 232 473 230 232 minecraft:red_concrete
fill 473 227 265 473 230 266 minecraft:white_concrete
fill 473 227 268 473 230 268 minecraft:red_concrete
fill 508 227 233 509 230 233 minecraft:red_concrete
fill 508 227 269 509 230 269 minecraft:red_concrete
fill 509 227 229 509 230 230 minecraft:white_concrete
fill 509 227 232 509 230 232 minecraft:red_concrete
fill 509 227 265 509 230 266 minecraft:white_concrete
fill 509 227 268 509 230 268 minecraft:red_concrete
setblock 471 228 230 minecraft:red_concrete
setblock 471 228 266 minecraft:red_concrete
fill 472 228 229 472 230 230 minecraft:white_concrete
fill 472 228 265 472 230 266 minecraft:white_concrete
setblock 474 228 232 minecraft:white_concrete
fill 474 228 233 474 232 233 minecraft:red_concrete
setblock 474 228 268 minecraft:white_concrete
fill 474 228 269 474 230 269 minecraft:red_concrete
setblock 507 228 230 minecraft:red_concrete
setblock 507 228 266 minecraft:red_concrete
fill 508 228 229 508 230 230 minecraft:white_concrete
fill 508 228 265 508 232 266 minecraft:white_concrete
setblock 510 228 232 minecraft:white_concrete
fill 510 228 233 510 230 233 minecraft:red_concrete
setblock 510 228 268 minecraft:white_concrete
fill 510 228 269 510 230 269 minecraft:red_concrete
fill 471 229 230 471 230 230 minecraft:white_concrete
fill 471 229 266 471 230 266 minecraft:white_concrete
fill 474 229 232 475 232 232 minecraft:red_concrete
fill 474 229 268 475 230 268 minecraft:red_concrete
fill 492 229 257 493 230 258 minecraft:lime_concrete
fill 493 229 256 493 230 256 minecraft:lime_concrete
fill 497 229 241 498 230 241 minecraft:yellow_concrete
fill 507 229 230 507 230 230 minecraft:white_concrete
fill 507 229 266 507 233 266 minecraft:white_concrete
fill 510 229 232 511 230 232 minecraft:red_concrete
fill 510 229 268 511 230 268 minecraft:red_concrete
fill 471 230 231 471 230 232 minecraft:white_concrete
fill 471 230 267 471 230 268 minecraft:white_concrete
setblock 472 230 231 minecraft:white_concrete
setblock 472 230 232 minecraft:red_concrete
setblock 472 230 267 minecraft:white_concrete
setblock 472 230 268 minecraft:red_concrete
fill 473 230 231 475 230 231 minecraft:red_concrete
fill 473 230 267 475 230 267 minecraft:red_concrete
fill 507 230 231 507 230 232 minecraft:white_concrete
fill 507 230 267 507 230 268 minecraft:white_concrete
setblock 508 230 231 minecraft:white_concrete
setblock 508 230 232 minecraft:red_concrete
setblock 508 230 267 minecraft:white_concrete
setblock 508 230 268 minecraft:red_concrete
fill 509 230 231 511 230 231 minecraft:red_concrete
fill 509 230 267 511 230 267 minecraft:red_concrete
fill 471 231 229 473 231 269 minecraft:black_concrete
fill 474 231 229 511 231 231 minecraft:black_concrete
setblock 474 231 265 minecraft:white_concrete
fill 474 231 266 475 234 266 minecraft:red_concrete
fill 474 231 267 511 231 269 minecraft:black_concrete
setblock 481 231 239 minecraft:light[level=15]
setblock 481 231 247 minecraft:light[level=15]
setblock 481 231 255 minecraft:light[level=15]
setblock 481 231 263 minecraft:light[level=15]
setblock 489 231 239 minecraft:light[level=15]
setblock 489 231 247 minecraft:light[level=15]
setblock 489 231 255 minecraft:light[level=15]
setblock 489 231 263 minecraft:light[level=15]
setblock 497 231 239 minecraft:light[level=15]
setblock 497 231 247 minecraft:light[level=15]
setblock 497 231 255 minecraft:light[level=15]
setblock 497 231 263 minecraft:light[level=15]
setblock 505 231 239 minecraft:light[level=15]
setblock 505 231 247 minecraft:light[level=15]
setblock 505 231 255 minecraft:light[level=15]
setblock 505 231 263 minecraft:light[level=15]
fill 507 231 232 508 235 232 minecraft:white_concrete
fill 508 231 233 508 236 233 minecraft:white_concrete
fill 509 231 232 511 231 266 minecraft:black_concrete
fill 471 232 229 473 232 269 minecraft:gray_concrete
fill 474 232 229 511 232 231 minecraft:gray_concrete
fill 474 232 265 474 235 265 minecraft:red_concrete
fill 474 232 267 511 232 269 minecraft:gray_concrete
setblock 480 232 238 minecraft:light[level=12]
setblock 480 232 245 minecraft:light[level=12]
setblock 480 232 252 minecraft:light[level=12]
setblock 480 232 259 minecraft:light[level=12]
setblock 480 232 266 minecraft:light[level=12]
setblock 487 232 238 minecraft:light[level=12]
setblock 487 232 245 minecraft:light[level=12]
setblock 487 232 259 minecraft:light[level=12]
setblock 487 232 266 minecraft:light[level=12]
setblock 494 232 238 minecraft:light[level=12]
setblock 494 232 245 minecraft:light[level=12]
setblock 494 232 252 minecraft:light[level=12]
setblock 494 232 259 minecraft:light[level=12]
setblock 494 232 266 minecraft:light[level=12]
setblock 501 232 238 minecraft:light[level=12]
setblock 501 232 245 minecraft:light[level=12]
setblock 501 232 252 minecraft:light[level=12]
setblock 501 232 259 minecraft:light[level=12]
setblock 501 232 266 minecraft:light[level=12]
setblock 508 232 238 minecraft:light[level=12]
setblock 508 232 245 minecraft:light[level=12]
setblock 508 232 252 minecraft:light[level=12]
setblock 508 232 259 minecraft:light[level=12]
fill 509 232 232 511 232 266 minecraft:gray_concrete
fill 471 233 230 472 233 232 minecraft:white_concrete
setblock 471 233 256 minecraft:yellow_concrete
fill 471 233 266 472 233 268 minecraft:white_concrete
fill 472 233 229 474 235 229 minecraft:red_concrete
setblock 472 233 233 minecraft:yellow_concrete
fill 472 233 265 473 236 265 minecraft:red_concrete
fill 472 233 269 474 236 269 minecraft:white_concrete
fill 473 233 230 475 234 231 minecraft:red_concrete
fill 473 233 232 474 236 233 minecraft:white_concrete
setblock 473 233 248 minecraft:magenta_concrete
fill 473 233 266 473 234 267 minecraft:red_concrete
fill 473 233 268 474 236 268 minecraft:white_concrete
fill 474 233 267 475 234 267 minecraft:red_concrete
setblock 475 233 232 minecraft:red_concrete
setblock 475 233 268 minecraft:red_concrete
setblock 477 233 231 minecraft:light_blue_concrete
fill 481 233 269 481 234 269 minecraft:brown_concrete
setblock 482 233 267 minecraft:red_concrete
setblock 487 233 267 minecraft:lime_concrete
setblock 493 233 269 minecraft:lime_concrete
setblock 496 233 229 minecraft:white_concrete
fill 506 233 231 506 234 231 minecraft:brown_concrete
fill 507 233 230 508 233 231 minecraft:white_concrete
fill 507 233 267 508 234 268 minecraft:white_concrete
fill 508 233 229 510 235 229 minecraft:red_concrete
fill 508 233 265 510 235 265 minecraft:red_concrete
setblock 508 233 266 minecraft:white_concrete
fill 508 233 269 510 236 269 minecraft:white_concrete
fill 509 233 230 511 234 231 minecraft:red_concrete
fill 509 233 232 510 236 233 minecraft:white_concrete
setblock 509 233 236 minecraft:white_concrete
setblock 509 233 239 minecraft:yellow_concrete
setblock 509 233 242 minecraft:yellow_concrete
setblock 509 233 246 minecraft:lime_concrete
fill 509 233 266 511 234 267 minecraft:red_concrete
fill 509 233 268 510 236 268 minecraft:white_concrete
fill 510 233 247 510 234 247 minecraft:brown_concrete
setblock 511 233 232 minecraft:red_concrete
fill 511 233 265 511 234 265 minecraft:brown_concrete
setblock 511 233 268 minecraft:red_concrete
fill 471 234 230 472 237 230 minecraft:red_concrete
fill 471 234 231 472 234 232 minecraft:white_concrete
fill 471 234 266 472 237 266 minecraft:red_concrete
fill 471 234 267 472 234 268 minecraft:white_concrete
fill 472 234 233 472 236 233 minecraft:white_concrete
fill 475 234 232 475 238 232 minecraft:white_concrete
fill 475 234 268 475 238 268 minecraft:white_concrete
fill 497 234 262 501 235 266 minecraft:brown_terracotta
fill 499 234 267 499 234 268 minecraft:brown_terracotta
fill 507 234 230 508 237 230 minecraft:red_concrete
fill 507 234 231 508 234 231 minecraft:white_concrete
fill 507 234 266 508 237 266 minecraft:red_concrete
fill 511 234 232 511 238 232 minecraft:white_concrete
fill 511 234 268 511 238 268 minecraft:white_concrete
fill 471 235 231 472 239 231 minecraft:red_concrete
fill 471 235 232 472 235 232 minecraft:white_concrete
fill 471 235 267 472 239 267 minecraft:red_concrete
fill 471 235 268 472 235 268 minecraft:white_concrete
fill 473 235 230 474 235 230 minecraft:red_concrete
fill 473 235 231 475 239 231 minecraft:white_concrete
fill 473 235 266 474 235 266 minecraft:red_concrete
fill 473 235 267 475 239 267 minecraft:white_concrete
fill 475 235 230 475 240 230 minecraft:white_concrete
fill 475 235 266 475 240 266 minecraft:white_concrete
fill 507 235 231 508 239 231 minecraft:red_concrete
fill 507 235 267 508 239 267 minecraft:red_concrete
fill 507 235 268 508 235 268 minecraft:white_concrete
fill 509 235 230 510 235 230 minecraft:red_concrete
fill 509 235 231 511 239 231 minecraft:white_concrete
fill 509 235 266 510 235 266 minecraft:red_concrete
fill 509 235 267 511 239 267 minecraft:white_concrete
fill 511 235 230 511 240 230 minecraft:white_concrete
fill 511 235 266 511 240 266 minecraft:white_concrete
fill 471 236 232 472 239 232 minecraft:red_concrete
fill 471 236 237 477 236 237 minecraft:brown_terracotta
fill 471 236 268 472 239 268 minecraft:red_concrete
fill 472 236 229 473 236 229 minecraft:red_concrete
setblock 473 236 230 minecraft:red_concrete
fill 473 236 235 477 237 236 minecraft:brown_terracotta
fill 473 236 238 477 237 239 minecraft:brown_terracotta
setblock 473 236 266 minecraft:red_concrete
fill 474 236 229 474 240 230 minecraft:white_concrete
fill 474 236 265 474 240 266 minecraft:white_concrete
fill 493 236 231 497 237 235 minecraft:brown_terracotta
fill 495 236 229 495 236 230 minecraft:brown_terracotta
fill 498 236 264 500 242 264 minecraft:white_concrete
fill 499 236 263 499 242 263 minecraft:white_concrete
fill 499 236 265 499 242 265 minecraft:white_concrete
fill 507 236 232 508 239 232 minecraft:red_concrete
fill 507 236 268 508 239 268 minecraft:red_concrete
fill 508 236 229 509 236 229 minecraft:red_concrete
fill 508 236 265 509 236 265 minecraft:red_concrete
setblock 509 236 230 minecraft:red_concrete
setblock 509 236 266 minecraft:red_concrete
fill 510 236 229 510 240 230 minecraft:white_concrete
fill 510 236 265 510 240 266 minecraft:white_concrete
setblock 472 237 229 minecraft:red_concrete
fill 472 237 233 473 240 233 minecraft:red_concrete
setblock 472 237 265 minecraft:red_concrete
fill 472 237 269 473 240 269 minecraft:red_concrete
fill 473 237 229 473 241 230 minecraft:white_concrete
fill 473 237 232 473 241 232 minecraft:red_concrete
fill 473 237 237 477 237 237 minecraft:brown_terracotta
fill 473 237 265 473 241 266 minecraft:white_concrete
fill 473 237 268 473 241 268 minecraft:red_concrete
fill 474 237 232 474 237 233 minecraft:white_concrete
fill 474 237 268 474 237 269 minecraft:white_concrete
setblock 508 237 229 minecraft:red_concrete
fill 508 237 233 509 240 233 minecraft:red_concrete
setblock 508 237 265 minecraft:red_concrete
fill 508 237 269 509 240 269 minecraft:red_concrete
fill 509 237 229 509 241 230 minecraft:white_concrete
fill 509 237 232 509 241 232 minecraft:red_concrete
fill 509 237 265 509 241 266 minecraft:white_concrete
fill 509 237 268 509 241 268 minecraft:red_concrete
fill 510 237 232 510 237 233 minecraft:white_concrete
fill 510 237 268 510 237 269 minecraft:white_concrete
setblock 471 238 230 minecraft:red_concrete
setblock 471 238 266 minecraft:red_concrete
fill 472 238 229 472 242 230 minecraft:white_concrete
fill 472 238 265 472 242 266 minecraft:white_concrete
setblock 473 238 238 minecraft:light[level=12]
setblock 473 238 239 minecraft:light[level=15]
setblock 473 238 245 minecraft:light[level=12]
setblock 473 238 247 minecraft:light[level=15]
setblock 473 238 252 minecraft:light[level=12]
setblock 473 238 255 minecraft:light[level=15]
setblock 473 238 259 minecraft:light[level=12]
setblock 473 238 263 minecraft:light[level=15]
setblock 474 238 232 minecraft:white_concrete
fill 474 238 233 474 242 233 minecraft:red_concrete
fill 474 238 237 476 244 237 minecraft:white_concrete
setblock 474 238 268 minecraft:white_concrete
fill 474 238 269 474 242 269 minecraft:red_concrete
fill 475 238 236 475 244 236 minecraft:white_concrete
fill 475 238 238 475 244 238 minecraft:white_concrete
setblock 480 238 231 minecraft:light[level=12]
setblock 480 238 238 minecraft:light[level=12]
setblock 480 238 245 minecraft:light[level=12]
setblock 480 238 252 minecraft:light[level=12]
setblock 480 238 259 minecraft:light[level=12]
setblock 480 238 266 minecraft:light[level=12]
setblock 481 238 231 minecraft:light[level=15]
setblock 481 238 239 minecraft:light[level=15]
setblock 481 238 247 minecraft:light[level=15]
setblock 481 238 255 minecraft:light[level=15]
setblock 481 238 263 minecraft:light[level=15]
setblock 487 238 231 minecraft:light[level=12]
setblock 487 238 238 minecraft:light[level=12]
setblock 487 238 245 minecraft:light[level=12]
setblock 487 238 252 minecraft:light[level=12]
setblock 487 238 259 minecraft:light[level=12]
setblock 487 238 266 minecraft:light[level=12]
setblock 489 238 231 minecraft:light[level=15]
setblock 489 238 239 minecraft:light[level=15]
setblock 489 238 247 minecraft:light[level=15]
setblock 489 238 255 minecraft:light[level=15]
setblock 489 238 263 minecraft:light[level=15]
setblock 494 238 231 minecraft:light[level=12]
fill 494 238 233 496 244 233 minecraft:white_concrete
setblock 494 238 238 minecraft:light[level=12]
setblock 494 238 245 minecraft:light[level=12]
setblock 494 238 252 minecraft:light[level=12]
setblock 494 238 259 minecraft:light[level=12]
setblock 494 238 266 minecraft:light[level=12]
fill 495 238 232 495 244 232 minecraft:white_concrete
fill 495 238 234 495 244 234 minecraft:white_concrete
setblock 497 238 231 minecraft:light[level=15]
setblock 497 238 239 minecraft:light[level=15]
setblock 497 238 247 minecraft:light[level=15]
setblock 497 238 255 minecraft:light[level=15]
setblock 497 238 263 minecraft:light[level=15]
setblock 501 238 231 minecraft:light[level=12]
setblock 501 238 238 minecraft:light[level=12]
setblock 501 238 245 minecraft:light[level=12]
setblock 501 238 252 minecraft:light[level=12]
setblock 501 238 259 minecraft:light[level=12]
setblock 501 238 266 minecraft:light[level=12]
setblock 505 238 231 minecraft:light[level=15]
setblock 505 238 239 minecraft:light[level=15]
setblock 505 238 247 minecraft:light[level=15]
setblock 505 238 255 minecraft:light[level=15]
setblock 505 238 263 minecraft:light[level=15]
setblock 507 238 230 minecraft:red_concrete
setblock 507 238 266 minecraft:red_concrete
fill 508 238 229 508 242 230 minecraft:white_concrete
setblock 508 238 238 minecraft:light[level=12]
setblock 508 238 245 minecraft:light[level=12]
setblock 508 238 252 minecraft:light[level=12]
setblock 508 238 259 minecraft:light[level=12]
fill 508 238 265 508 242 266 minecraft:white_concrete
setblock 510 238 232 minecraft:white_concrete
fill 510 238 233 510 242 233 minecraft:red_concrete
setblock 510 238 268 minecraft:white_concrete
fill 510 238 269 510 242 269 minecraft:red_concrete
fill 471 239 230 471 243 230 minecraft:white_concrete
fill 471 239 266 471 243 266 minecraft:white_concrete
fill 474 239 232 475 242 232 minecraft:red_concrete
fill 474 239 268 475 242 268 minecraft:red_concrete
fill 490 239 258 490 240 258 minecraft:yellow_concrete
fill 507 239 230 507 243 230 minecraft:white_concrete
fill 507 239 266 507 243 266 minecraft:white_concrete
fill 510 239 232 511 242 232 minecraft:red_concrete
fill 510 239 268 511 242 268 minecraft:red_concrete
fill 471 240 231 471 244 232 minecraft:white_concrete
fill 471 240 267 471 244 268 minecraft:white_concrete
fill 472 240 231 472 244 231 minecraft:white_concrete
setblock 472 240 232 minecraft:red_concrete
fill 472 240 267 472 244 267 minecraft:white_concrete
setblock 472 240 268 minecraft:red_concrete
fill 473 240 231 475 244 231 minecraft:red_concrete
fill 473 240 267 475 244 267 minecraft:red_concrete
fill 507 240 231 507 244 232 minecraft:white_concrete
fill 507 240 267 507 244 268 minecraft:white_concrete
fill 508 240 231 508 244 231 minecraft:white_concrete
setblock 508 240 232 minecraft:red_concrete
fill 508 240 267 508 244 267 minecraft:white_concrete
setblock 508 240 268 minecraft:red_concrete
fill 509 240 231 511 242 231 minecraft:red_concrete
fill 509 240 267 511 244 267 minecraft:red_concrete
fill 472 241 232 472 245 233 minecraft:white_concrete
fill 472 241 268 472 245 269 minecraft:white_concrete
setblock 473 241 233 minecraft:red_concrete
fill 473 241 247 475 242 247 minecraft:lime_concrete
setblock 473 241 269 minecraft:red_concrete
setblock 474 241 229 minecraft:white_concrete
fill 474 241 230 475 244 230 minecraft:red_concrete
fill 474 241 246 474 242 246 minecraft:lime_concrete
fill 474 241 248 474 242 248 minecraft:lime_concrete
setblock 474 241 265 minecraft:white_concrete
fill 474 241 266 475 244 266 minecraft:red_concrete
fill 497 241 262 497 244 266 minecraft:magenta_concrete
fill 498 241 262 498 244 263 minecraft:magenta_concrete
fill 498 241 265 498 244 266 minecraft:magenta_concrete
fill 499 241 262 501 244 262 minecraft:magenta_concrete
fill 499 241 266 501 244 266 minecraft:magenta_concrete
fill 500 241 263 501 244 263 minecraft:magenta_concrete
fill 500 241 265 501 244 265 minecraft:magenta_concrete
fill 501 241 264 501 244 264 minecraft:magenta_concrete
fill 508 241 232 508 245 233 minecraft:white_concrete
fill 508 241 268 508 245 269 minecraft:white_concrete
setblock 509 241 233 minecraft:red_concrete
setblock 509 241 269 minecraft:red_concrete
setblock 510 241 229 minecraft:white_concrete
fill 510 241 230 511 244 230 minecraft:red_concrete
setblock 510 241 265 minecraft:white_concrete
fill 510 241 266 511 244 266 minecraft:red_concrete
fill 473 242 229 473 246 230 minecraft:red_concrete
fill 473 242 232 473 246 233 minecraft:white_concrete
fill 473 242 265 473 246 266 minecraft:red_concrete
fill 473 242 268 473 246 269 minecraft:white_concrete
fill 474 242 229 474 245 229 minecraft:red_concrete
fill 474 242 265 474 245 265 minecraft:red_concrete
fill 496 242 262 496 243 266 minecraft:magenta_concrete
fill 497 242 261 501 243 261 minecraft:magenta_concrete
fill 497 242 267 501 243 267 minecraft:magenta_concrete
fill 502 242 262 502 243 266 minecraft:magenta_concrete
fill 509 242 229 509 246 230 minecraft:red_concrete
fill 509 242 232 509 246 233 minecraft:white_concrete
fill 509 242 265 509 246 266 minecraft:red_concrete
fill 509 242 268 509 246 269 minecraft:white_concrete
fill 510 242 229 510 245 229 minecraft:red_concrete
fill 510 242 265 510 245 265 minecraft:red_concrete
fill 472 243 229 472 247 229 minecraft:red_concrete
setblock 472 243 230 minecraft:white_concrete
fill 472 243 265 472 247 265 minecraft:red_concrete
setblock 472 243 266 minecraft:white_concrete
fill 473 243 235 473 246 239 minecraft:magenta_concrete
fill 474 243 232 474 247 233 minecraft:white_concrete
fill 474 243 235 474 246 236 minecraft:magenta_concrete
fill 474 243 238 474 246 239 minecraft:magenta_concrete
fill 474 243 268 474 247 269 minecraft:white_concrete
setblock 475 243 232 minecraft:red_concrete
fill 475 243 235 477 246 235 minecraft:magenta_concrete
fill 475 243 239 477 246 239 minecraft:magenta_concrete
setblock 475 243 268 minecraft:red_concrete
fill 476 243 236 477 246 236 minecraft:magenta_concrete
fill 476 243 238 477 246 238 minecraft:magenta_concrete
fill 477 243 237 477 246 237 minecraft:magenta_concrete
fill 493 243 231 493 246 235 minecraft:magenta_concrete
fill 494 243 231 494 246 232 minecraft:magenta_concrete
fill 494 243 234 494 246 235 minecraft:magenta_concrete
fill 495 243 231 497 246 231 minecraft:magenta_concrete
fill 495 243 235 497 246 235 minecraft:magenta_concrete
fill 496 243 232 497 246 232 minecraft:magenta_concrete
fill 496 243 234 497 246 234 minecraft:magenta_concrete
fill 497 243 233 497 246 233 minecraft:magenta_concrete
fill 498 243 264 500 244 264 minecraft:magenta_concrete
fill 499 243 263 499 244 263 minecraft:magenta_concrete
fill 499 243 265 499 244 265 minecraft:magenta_concrete
fill 508 243 229 508 247 229 minecraft:red_concrete
setblock 508 243 230 minecraft:white_concrete
fill 508 243 265 508 247 265 minecraft:red_concrete
setblock 508 243 266 minecraft:white_concrete
fill 509 243 231 510 244 231 minecraft:red_concrete
fill 510 243 232 510 247 233 minecraft:white_concrete
fill 510 243 268 510 247 269 minecraft:white_concrete
fill 511 243 231 511 246 231 minecraft:brown_concrete
setblock 511 243 232 minecraft:red_concrete
setblock 511 243 268 minecraft:red_concrete
fill 471 244 230 472 247 230 minecraft:red_concrete
fill 471 244 266 472 247 266 minecraft:red_concrete
fill 472 244 235 472 245 239 minecraft:magenta_concrete
fill 473 244 234 477 245 234 minecraft:magenta_concrete
fill 473 244 240 477 245 240 minecraft:magenta_concrete
setblock 473 244 245 minecraft:light[level=12]
setblock 473 244 252 minecraft:light[level=12]
setblock 473 244 259 minecraft:light[level=12]
fill 475 244 232 475 248 232 minecraft:white_concrete
fill 475 244 268 475 248 268 minecraft:white_concrete
fill 478 244 235 478 245 239 minecraft:magenta_concrete
setblock 480 244 231 minecraft:light[level=12]
setblock 480 244 238 minecraft:light[level=12]
setblock 480 244 245 minecraft:light[level=12]
setblock 480 244 252 minecraft:light[level=12]
setblock 480 244 259 minecraft:light[level=12]
setblock 480 244 266 minecraft:light[level=12]
setblock 487 244 231 minecraft:light[level=12]
setblock 487 244 238 minecraft:light[level=12]
setblock 487 244 245 minecraft:light[level=12]
setblock 487 244 252 minecraft:light[level=12]
setblock 487 244 259 minecraft:light[level=12]
setblock 487 244 266 minecraft:light[level=12]
fill 492 244 231 492 245 235 minecraft:magenta_concrete
fill 493 244 230 497 245 230 minecraft:magenta_concrete
fill 493 244 236 497 245 236 minecraft:magenta_concrete
setblock 494 244 238 minecraft:light[level=12]
setblock 494 244 245 minecraft:light[level=12]
setblock 494 244 252 minecraft:light[level=12]
setblock 494 244 259 minecraft:light[level=12]
setblock 494 244 266 minecraft:light[level=12]
fill 498 244 231 498 245 235 minecraft:magenta_concrete
setblock 501 244 231 minecraft:light[level=12]
setblock 501 244 238 minecraft:light[level=12]
setblock 501 244 245 minecraft:light[level=12]
fill 501 244 247 502 245 248 minecraft:magenta_concrete
setblock 501 244 252 minecraft:light[level=12]
setblock 501 244 259 minecraft:light[level=12]
fill 502 244 245 502 245 246 minecraft:magenta_concrete
fill 502 244 249 503 245 249 minecraft:magenta_concrete
fill 503 244 245 505 245 245 minecraft:magenta_concrete
fill 503 244 250 505 245 250 minecraft:magenta_concrete
fill 505 244 249 506 245 249 minecraft:magenta_concrete
fill 506 244 246 506 245 248 minecraft:magenta_concrete
fill 507 244 230 508 247 230 minecraft:red_concrete
fill 507 244 266 508 247 266 minecraft:red_concrete
setblock 508 244 238 minecraft:light[level=12]
setblock 508 244 245 minecraft:light[level=12]
setblock 508 244 252 minecraft:light[level=12]
setblock 508 244 259 minecraft:light[level=12]
fill 511 244 232 511 248 232 minecraft:white_concrete
fill 511 244 268 511 248 268 minecraft:white_concrete
fill 471 245 231 472 249 231 minecraft:red_concrete
setblock 471 245 232 minecraft:white_concrete
fill 471 245 267 472 249 267 minecraft:red_concrete
setblock 471 245 268 minecraft:white_concrete
fill 473 245 231 475 249 231 minecraft:white_concrete
setblock 473 245 247 minecraft:light[level=15]
setblock 473 245 255 minecraft:light[level=15]
setblock 473 245 263 minecraft:light[level=15]
fill 473 245 267 475 249 267 minecraft:white_concrete
setblock 474 245 230 minecraft:red_concrete
fill 474 245 237 476 246 237 minecraft:magenta_concrete
setblock 474 245 266 minecraft:red_concrete
fill 475 245 230 475 250 230 minecraft:white_concrete
fill 475 245 236 475 246 236 minecraft:magenta_concrete
fill 475 245 238 475 246 238 minecraft:magenta_concrete
fill 475 245 266 475 250 266 minecraft:white_concrete
setblock 481 245 231 minecraft:light[level=15]
setblock 481 245 239 minecraft:light[level=15]
setblock 481 245 247 minecraft:light[level=15]
setblock 481 245 255 minecraft:light[level=15]
setblock 481 245 263 minecraft:light[level=15]
setblock 489 245 231 minecraft:light[level=15]
setblock 489 245 239 minecraft:light[level=15]
setblock 489 245 247 minecraft:light[level=15]
setblock 489 245 255 minecraft:light[level=15]
setblock 489 245 263 minecraft:light[level=15]
fill 494 245 233 496 246 233 minecraft:magenta_concrete
fill 495 245 232 495 246 232 minecraft:magenta_concrete
fill 495 245 234 495 246 234 minecraft:magenta_concrete
setblock 497 245 239 minecraft:light[level=15]
setblock 497 245 247 minecraft:light[level=15]
setblock 497 245 255 minecraft:light[level=15]
setblock 497 245 263 minecraft:light[level=15]
setblock 505 245 231 minecraft:light[level=15]
setblock 505 245 239 minecraft:light[level=15]
setblock 505 245 247 minecraft:light[level=15]
setblock 505 245 255 minecraft:light[level=15]
setblock 505 245 263 minecraft:light[level=15]
fill 507 245 231 508 249 231 minecraft:red_concrete
setblock 507 245 232 minecraft:white_concrete
fill 507 245 267 508 249 267 minecraft:red_concrete
setblock 507 245 268 minecraft:white_concrete
fill 509 245 231 510 249 231 minecraft:white_concrete
fill 509 245 267 511 249 267 minecraft:white_concrete
setblock 510 245 230 minecraft:red_concrete
setblock 510 245 266 minecraft:red_concrete
fill 511 245 230 511 250 230 minecraft:white_concrete
fill 511 245 266 511 250 266 minecraft:white_concrete
fill 471 246 232 472 249 232 minecraft:red_concrete
fill 471 246 268 472 249 268 minecraft:red_concrete
setblock 472 246 233 minecraft:white_concrete
setblock 472 246 269 minecraft:white_concrete
fill 474 246 229 474 250 230 minecraft:white_concrete
fill 474 246 265 474 250 266 minecraft:white_concrete
fill 507 246 232 508 249 232 minecraft:red_concrete
fill 507 246 268 508 249 268 minecraft:red_concrete
setblock 508 246 233 minecraft:white_concrete
setblock 508 246 269 minecraft:white_concrete
fill 510 246 229 510 250 230 minecraft:white_concrete
fill 510 246 265 510 250 266 minecraft:white_concrete
fill 472 247 233 473 250 233 minecraft:red_concrete
fill 472 247 269 473 250 269 minecraft:red_concrete
fill 473 247 229 473 251 230 minecraft:white_concrete
fill 473 247 232 473 251 232 minecraft:red_concrete
fill 473 247 265 473 251 266 minecraft:white_concrete
fill 473 247 268 473 251 268 minecraft:red_concrete
fill 508 247 233 509 250 233 minecraft:red_concrete
fill 508 247 269 509 250 269 minecraft:red_concrete
fill 509 247 229 509 251 230 minecraft:white_concrete
fill 509 247 232 509 251 232 minecraft:red_concrete
fill 509 247 265 509 251 266 minecraft:white_concrete
fill 509 247 268 509 251 268 minecraft:red_concrete
fill 511 247 231 511 249 231 minecraft:white_concrete
setblock 471 248 230 minecraft:red_concrete
setblock 471 248 266 minecraft:red_concrete
fill 472 248 229 472 251 230 minecraft:white_concrete
fill 472 248 265 472 251 266 minecraft:white_concrete
setblock 474 248 232 minecraft:white_concrete
fill 474 248 233 474 252 233 minecraft:red_concrete
setblock 474 248 268 minecraft:white_concrete
fill 474 248 269 474 251 269 minecraft:red_concrete
fill 482 248 254 482 249 255 minecraft:light_blue_concrete
setblock 507 248 230 minecraft:red_concrete
setblock 507 248 266 minecraft:red_concrete
fill 508 248 229 508 251 230 minecraft:white_concrete
fill 508 248 265 508 252 266 minecraft:white_concrete
setblock 510 248 232 minecraft:white_concrete
fill 510 248 233 510 251 233 minecraft:red_concrete
setblock 510 248 268 minecraft:white_concrete
fill 510 248 269 510 251 269 minecraft:red_concrete
fill 471 249 230 471 251 230 minecraft:white_concrete
fill 471 249 266 471 251 266 minecraft:white_concrete
fill 474 249 232 475 252 232 minecraft:red_concrete
fill 474 249 268 475 251 268 minecraft:red_concrete
fill 507 249 230 507 251 230 minecraft:white_concrete
fill 507 249 266 507 253 266 minecraft:white_concrete
fill 510 249 232 511 251 232 minecraft:red_concrete
fill 510 249 268 511 251 268 minecraft:red_concrete
fill 471 250 231 471 251 232 minecraft:white_concrete
fill 471 250 267 471 251 268 minecraft:white_concrete
fill 472 250 231 472 251 231 minecraft:white_concrete
setblock 472 250 232 minecraft:red_concrete
fill 472 250 267 472 251 267 minecraft:white_concrete
setblock 472 250 268 minecraft:red_concrete
fill 473 250 231 475 251 231 minecraft:red_concrete
setblock 473 250 238 minecraft:light[level=12]
setblock 473 250 245 minecraft:light[level=12]
setblock 473 250 252 minecraft:light[level=12]
setblock 473 250 259 minecraft:light[level=12]
fill 473 250 267 475 251 267 minecraft:red_concrete
setblock 480 250 231 minecraft:light[level=12]
setblock 480 250 238 minecraft:light[level=12]
setblock 480 250 245 minecraft:light[level=12]
setblock 480 250 252 minecraft:light[level=12]
setblock 480 250 259 minecraft:light[level=12]
setblock 480 250 266 minecraft:light[level=12]
setblock 487 250 231 minecraft:light[level=12]
setblock 487 250 238 minecraft:light[level=12]
setblock 487 250 245 minecraft:light[level=12]
setblock 487 250 252 minecraft:light[level=12]
setblock 487 250 259 minecraft:light[level=12]
setblock 487 250 266 minecraft:light[level=12]
setblock 494 250 231 minecraft:light[level=12]
setblock 494 250 238 minecraft:light[level=12]
setblock 494 250 245 minecraft:light[level=12]
setblock 494 250 252 minecraft:light[level=12]
setblock 494 250 259 minecraft:light[level=12]
setblock 494 250 266 minecraft:light[level=12]
setblock 501 250 231 minecraft:light[level=12]
setblock 501 250 238 minecraft:light[level=12]
setblock 501 250 245 minecraft:light[level=12]
setblock 501 250 252 minecraft:light[level=12]
setblock 501 250 259 minecraft:light[level=12]
setblock 501 250 266 minecraft:light[level=12]
fill 507 250 231 507 251 232 minecraft:white_concrete
fill 507 250 267 507 251 268 minecraft:white_concrete
fill 508 250 231 508 251 231 minecraft:white_concrete
setblock 508 250 232 minecraft:red_concrete
setblock 508 250 238 minecraft:light[level=12]
setblock 508 250 245 minecraft:light[level=12]
setblock 508 250 252 minecraft:light[level=12]
setblock 508 250 259 minecraft:light[level=12]
fill 508 250 267 508 251 267 minecraft:white_concrete
setblock 508 250 268 minecraft:red_concrete
fill 509 250 231 511 251 231 minecraft:red_concrete
fill 509 250 267 511 251 267 minecraft:red_concrete
fill 472 251 232 472 251 233 minecraft:white_concrete
fill 472 251 268 472 251 269 minecraft:white_concrete
setblock 473 251 233 minecraft:red_concrete
setblock 473 251 269 minecraft:red_concrete
setblock 474 251 229 minecraft:white_concrete
fill 474 251 230 475 251 230 minecraft:red_concrete
setblock 474 251 265 minecraft:white_concrete
fill 474 251 266 475 254 266 minecraft:red_concrete
fill 508 251 232 508 255 233 minecraft:white_concrete
fill 508 251 268 508 251 269 minecraft:white_concrete
setblock 509 251 233 minecraft:red_concrete
setblock 509 251 269 minecraft:red_concrete
setblock 510 251 229 minecraft:white_concrete
fill 510 251 230 511 251 230 minecraft:red_concrete
setblock 510 251 265 minecraft:white_concrete
fill 510 251 266 511 251 266 minecraft:red_concrete
fill 471 252 229 473 252 269 minecraft:black_concrete
fill 474 252 229 511 252 231 minecraft:black_concrete
fill 474 252 265 474 255 265 minecraft:red_concrete
fill 474 252 267 511 252 269 minecraft:black_concrete
setblock 481 252 239 minecraft:light[level=15]
setblock 481 252 247 minecraft:light[level=15]
setblock 481 252 255 minecraft:light[level=15]
setblock 481 252 263 minecraft:light[level=15]
setblock 489 252 239 minecraft:light[level=15]
setblock 489 252 247 minecraft:light[level=15]
setblock 489 252 255 minecraft:light[level=15]
setblock 489 252 263 minecraft:light[level=15]
fill 494 252 238 494 253 238 minecraft:light_blue_concrete
setblock 497 252 239 minecraft:light[level=15]
setblock 497 252 247 minecraft:light[level=15]
setblock 497 252 255 minecraft:light[level=15]
setblock 497 252 263 minecraft:light[level=15]
setblock 505 252 239 minecraft:light[level=15]
setblock 505 252 247 minecraft:light[level=15]
setblock 505 252 255 minecraft:light[level=15]
setblock 505 252 263 minecraft:light[level=15]
fill 507 252 232 507 255 232 minecraft:white_concrete
fill 509 252 232 511 252 266 minecraft:black_concrete
fill 471 253 229 473 253 269 minecraft:gray_concrete
fill 474 253 229 511 253 231 minecraft:gray_concrete
fill 474 253 232 474 257 233 minecraft:white_concrete
fill 474 253 267 511 253 269 minecraft:gray_concrete
setblock 475 253 232 minecraft:red_concrete
fill 508 253 265 508 255 265 minecraft:red_concrete
setblock 508 253 266 minecraft:white_concrete
fill 509 253 232 511 253 266 minecraft:gray_concrete
fill 471 254 230 475 254 230 minecraft:red_concrete
fill 471 254 231 472 254 232 minecraft:white_concrete
setblock 471 254 253 minecraft:light_blue_concrete
setblock 471 254 254 minecraft:magenta_concrete
fill 471 254 266 473 256 266 minecraft:red_concrete
fill 471 254 267 472 254 268 minecraft:white_concrete
fill 472 254 229 474 255 229 minecraft:red_concrete
fill 472 254 233 473 256 233 minecraft:white_concrete
fill 472 254 265 473 255 265 minecraft:red_concrete
fill 472 254 269 474 256 269 minecraft:white_concrete
fill 473 254 231 475 254 231 minecraft:red_concrete
fill 473 254 232 473 256 232 minecraft:white_concrete
setblock 473 254 258 minecraft:orange_concrete
fill 473 254 267 475 254 267 minecraft:red_concrete
fill 473 254 268 475 256 268 minecraft:white_concrete
fill 475 254 232 475 258 232 minecraft:white_concrete
setblock 475 254 269 minecraft:lime_concrete
setblock 477 254 268 minecraft:lime_concrete
setblock 478 254 229 minecraft:yellow_concrete
fill 478 254 267 478 255 267 minecraft:brown_concrete
setblock 487 254 267 minecraft:magenta_concrete
setblock 491 254 268 minecraft:red_concrete
fill 494 254 267 494 255 267 minecraft:brown_concrete
setblock 498 254 269 minecraft:light_blue_concrete
setblock 502 254 230 minecraft:yellow_concrete
setblock 506 254 267 minecraft:orange_concrete
setblock 506 254 269 minecraft:yellow_concrete
fill 507 254 230 511 254 230 minecraft:red_concrete
fill 507 254 231 508 254 231 minecraft:white_concrete
fill 507 254 266 511 254 266 minecraft:red_concrete
fill 507 254 267 508 254 268 minecraft:white_concrete
fill 508 254 229 510 255 229 minecraft:red_concrete
fill 508 254 269 510 256 269 minecraft:white_concrete
fill 509 254 231 511 254 231 minecraft:red_concrete
fill 509 254 232 510 256 233 minecraft:white_concrete
fill 509 254 265 510 255 265 minecraft:red_concrete
fill 509 254 267 511 254 267 minecraft:red_concrete
fill 509 254 268 511 256 268 minecraft:white_concrete
fill 510 254 263 510 255 263 minecraft:brown_concrete
fill 511 254 232 511 258 232 minecraft:white_concrete
setblock 511 254 239 minecraft:white_concrete
fill 470 255 264 511 258 264 minecraft:brown_terracotta
fill 470 255 265 470 255 266 minecraft:white_concrete
fill 471 255 230 472 257 231 minecraft:red_concrete
fill 471 255 232 472 255 232 minecraft:white_concrete
fill 471 255 267 472 259 267 minecraft:red_concrete
fill 471 255 268 472 255 268 minecraft:white_concrete
fill 473 255 230 474 255 230 minecraft:red_concrete
fill 473 255 231 475 259 231 minecraft:white_concrete
fill 473 255 267 475 259 267 minecraft:white_concrete
setblock 474 255 266 minecraft:red_concrete
fill 475 255 230 475 260 230 minecraft:white_concrete
fill 475 255 266 475 260 266 minecraft:white_concrete
fill 507 255 230 508 257 231 minecraft:red_concrete
fill 507 255 266 508 257 267 minecraft:red_concrete
fill 507 255 268 508 255 268 minecraft:white_concrete
fill 509 255 230 510 255 230 minecraft:red_concrete
fill 509 255 231 511 259 231 minecraft:white_concrete
fill 509 255 266 510 255 266 minecraft:red_concrete
fill 509 255 267 511 259 267 minecraft:white_concrete
fill 511 255 230 511 260 230 minecraft:white_concrete
fill 511 255 266 511 260 266 minecraft:white_concrete
fill 470 256 261 470 308 262 minecraft:lime_terracotta
fill 470 256 263 511 257 263 minecraft:brown_terracotta
fill 470 256 265 511 257 265 minecraft:brown_terracotta
fill 470 256 266 470 308 266 minecraft:white_concrete
fill 471 256 232 472 259 232 minecraft:red_concrete
fill 471 256 268 472 259 268 minecraft:red_concrete
fill 472 256 229 473 256 229 minecraft:red_concrete
setblock 473 256 230 minecraft:red_concrete
setblock 473 256 238 minecraft:light[level=12]
setblock 473 256 245 minecraft:light[level=12]
setblock 473 256 252 minecraft:light[level=12]
setblock 473 256 259 minecraft:light[level=12]
fill 474 256 229 474 260 230 minecraft:white_concrete
fill 474 256 266 474 260 266 minecraft:white_concrete
setblock 480 256 231 minecraft:light[level=12]
setblock 480 256 238 minecraft:light[level=12]
setblock 480 256 245 minecraft:light[level=12]
setblock 480 256 252 minecraft:light[level=12]
setblock 480 256 259 minecraft:light[level=12]
setblock 480 256 266 minecraft:light[level=12]
setblock 487 256 231 minecraft:light[level=12]
setblock 487 256 238 minecraft:light[level=12]
setblock 487 256 245 minecraft:light[level=12]
setblock 487 256 252 minecraft:light[level=12]
setblock 487 256 259 minecraft:light[level=12]
setblock 487 256 266 minecraft:light[level=12]
setblock 494 256 231 minecraft:light[level=12]
setblock 494 256 238 minecraft:light[level=12]
setblock 494 256 245 minecraft:light[level=12]
setblock 494 256 252 minecraft:light[level=12]
setblock 494 256 259 minecraft:light[level=12]
setblock 494 256 266 minecraft:light[level=12]
setblock 501 256 231 minecraft:light[level=12]
setblock 501 256 238 minecraft:light[level=12]
setblock 501 256 245 minecraft:light[level=12]
setblock 501 256 252 minecraft:light[level=12]
setblock 501 256 259 minecraft:light[level=12]
setblock 501 256 266 minecraft:light[level=12]
fill 507 256 232 508 259 232 minecraft:red_concrete
fill 507 256 268 508 259 268 minecraft:red_concrete
fill 508 256 229 509 256 229 minecraft:red_concrete
setblock 508 256 233 minecraft:white_concrete
setblock 508 256 238 minecraft:light[level=12]
setblock 508 256 245 minecraft:light[level=12]
setblock 508 256 252 minecraft:light[level=12]
setblock 508 256 259 minecraft:light[level=12]
setblock 509 256 230 minecraft:red_concrete
setblock 509 256 266 minecraft:red_concrete
fill 510 256 229 510 260 230 minecraft:white_concrete
fill 510 256 266 510 260 266 minecraft:white_concrete
fill 512 256 264 512 257 264 minecraft:brown_terracotta
fill 512 256 265 512 308 266 minecraft:white_concrete
fill 471 257 252 471 266 252 minecraft:brown_concrete
fill 471 257 266 472 257 266 minecraft:red_concrete
setblock 472 257 229 minecraft:red_concrete
fill 472 257 233 473 260 233 minecraft:red_concrete
fill 472 257 269 473 260 269 minecraft:red_concrete
fill 473 257 229 473 261 230 minecraft:white_concrete
fill 473 257 232 473 261 232 minecraft:red_concrete
fill 473 257 266 473 261 266 minecraft:white_concrete
fill 473 257 268 473 261 268 minecraft:red_concrete
fill 474 257 268 474 257 269 minecraft:white_concrete
fill 475 257 268 475 258 268 minecraft:white_concrete
setblock 508 257 229 minecraft:red_concrete
fill 508 257 233 509 260 233 minecraft:red_concrete
fill 508 257 269 509 260 269 minecraft:red_concrete
fill 509 257 229 509 261 230 minecraft:white_concrete
fill 509 257 232 509 261 232 minecraft:red_concrete
fill 509 257 266 509 261 266 minecraft:white_concrete
fill 509 257 268 509 261 268 minecraft:red_concrete
fill 510 257 232 510 257 233 minecraft:white_concrete
fill 510 257 268 510 257 269 minecraft:white_concrete
fill 511 257 268 511 258 268 minecraft:white_concrete
fill 470 258 263 470 308 263 minecraft:lime_terracotta
fill 470 258 265 470 308 265 minecraft:white_concrete
fill 471 258 230 471 258 231 minecraft:red_concrete
setblock 471 258 266 minecraft:red_concrete
fill 472 258 229 472 262 230 minecraft:white_concrete
fill 472 258 231 472 259 231 minecraft:red_concrete
fill 472 258 265 472 262 266 minecraft:white_concrete
fill 473 258 265 474 261 265 minecraft:white_concrete
setblock 474 258 232 minecraft:white_concrete
fill 474 258 233 474 262 233 minecraft:red_concrete
setblock 474 258 268 minecraft:white_concrete
fill 474 258 269 474 262 269 minecraft:red_concrete
fill 499 258 232 500 259 233 minecraft:light_blue_concrete
fill 507 258 230 507 258 231 minecraft:red_concrete
fill 507 258 266 507 258 267 minecraft:red_concrete
fill 508 258 229 508 262 230 minecraft:white_concrete
fill 508 258 231 508 259 231 minecraft:red_concrete
fill 508 258 265 508 262 266 minecraft:white_concrete
fill 508 258 267 508 259 267 minecraft:red_concrete
fill 509 258 265 510 261 265 minecraft:white_concrete
setblock 510 258 232 minecraft:white_concrete
fill 510 258 233 510 262 233 minecraft:red_concrete
setblock 510 258 268 minecraft:white_concrete
fill 510 258 269 510 262 269 minecraft:red_concrete
fill 512 258 264 512 308 264 minecraft:white_concrete
fill 470 259 264 470 308 264 minecraft:white_concrete
fill 471 259 230 471 263 230 minecraft:white_concrete
setblock 471 259 231 minecraft:red_concrete
fill 471 259 266 471 263 266 minecraft:white_concrete
setblock 473 259 239 minecraft:light[level=15]
setblock 473 259 247 minecraft:light[level=15]
setblock 473 259 255 minecraft:light[level=15]
setblock 473 259 263 minecraft:light[level=15]
fill 474 259 232 475 262 232 minecraft:red_concrete
fill 474 259 268 475 262 268 minecraft:red_concrete
setblock 481 259 231 minecraft:light[level=15]
setblock 481 259 239 minecraft:light[level=15]
setblock 481 259 247 minecraft:light[level=15]
setblock 481 259 255 minecraft:light[level=15]
setblock 481 259 263 minecraft:light[level=15]
setblock 489 259 231 minecraft:light[level=15]
setblock 489 259 239 minecraft:light[level=15]
setblock 489 259 247 minecraft:light[level=15]
setblock 489 259 255 minecraft:light[level=15]
setblock 489 259 263 minecraft:light[level=15]
setblock 497 259 231 minecraft:light[level=15]
setblock 497 259 239 minecraft:light[level=15]
setblock 497 259 247 minecraft:light[level=15]
setblock 497 259 255 minecraft:light[level=15]
setblock 497 259 263 minecraft:light[level=15]
setblock 505 259 231 minecraft:light[level=15]
setblock 505 259 239 minecraft:light[level=15]
setblock 505 259 247 minecraft:light[level=15]
setblock 505 259 255 minecraft:light[level=15]
setblock 505 259 263 minecraft:light[level=15]
fill 506 259 228 506 262 269 minecraft:brown_terracotta
fill 507 259 228 508 259 228 minecraft:white_concrete
setblock 507 259 230 minecraft:white_concrete
setblock 507 259 231 minecraft:red_concrete
setblock 507 259 266 minecraft:white_concrete
setblock 507 259 267 minecraft:red_concrete
fill 510 259 232 511 262 232 minecraft:red_concrete
fill 510 259 268 511 262 268 minecraft:red_concrete
fill 471 260 231 471 264 232 minecraft:white_concrete
fill 471 260 267 471 264 268 minecraft:white_concrete
fill 472 260 231 472 264 231 minecraft:white_concrete
setblock 472 260 232 minecraft:red_concrete
fill 472 260 267 472 264 267 minecraft:white_concrete
setblock 472 260 268 minecraft:red_concrete
fill 473 260 231 475 264 231 minecraft:red_concrete
fill 473 260 267 475 264 267 minecraft:red_concrete
fill 503 260 228 504 308 228 minecraft:lime_terracotta
fill 505 260 228 505 261 269 minecraft:brown_terracotta
fill 506 260 270 506 261 270 minecraft:brown_terracotta
fill 507 260 228 507 261 269 minecraft:brown_terracotta
fill 507 260 270 508 308 270 minecraft:white_concrete
fill 508 260 228 508 308 228 minecraft:white_concrete
fill 508 260 231 508 264 231 minecraft:white_concrete
setblock 508 260 232 minecraft:red_concrete
fill 508 260 267 508 264 267 minecraft:white_concrete
setblock 508 260 268 minecraft:red_concrete
fill 509 260 231 511 264 231 minecraft:red_concrete
fill 509 260 267 511 264 267 minecraft:red_concrete
fill 472 261 232 472 265 233 minecraft:white_concrete
fill 472 261 268 472 265 269 minecraft:white_concrete
setblock 473 261 233 minecraft:red_concrete
setblock 473 261 269 minecraft:red_concrete
setblock 474 261 229 minecraft:white_concrete
fill 474 261 230 475 264 230 minecraft:red_concrete
fill 474 261 266 475 264 266 minecraft:red_concrete
fill 480 261 233 481 261 234 minecraft:magenta_concrete
fill 481 261 232 482 262 232 minecraft:magenta_concrete
fill 481 261 235 482 261 236 minecraft:magenta_concrete
fill 482 261 231 485 261 231 minecraft:magenta_concrete
fill 483 261 236 483 261 237 minecraft:magenta_concrete
fill 484 261 232 486 261 232 minecraft:magenta_concrete
fill 484 261 236 485 261 236 minecraft:magenta_concrete
fill 485 261 233 486 261 235 minecraft:magenta_concrete
fill 496 261 263 496 262 264 minecraft:light_blue_concrete
fill 508 261 232 508 265 233 minecraft:white_concrete
fill 508 261 268 508 265 269 minecraft:white_concrete
setblock 509 261 233 minecraft:red_concrete
setblock 509 261 269 minecraft:red_concrete
setblock 510 261 229 minecraft:white_concrete
fill 510 261 230 511 264 230 minecraft:red_concrete
fill 510 261 266 511 264 266 minecraft:red_concrete
fill 473 262 229 473 266 230 minecraft:red_concrete
fill 473 262 232 473 266 233 minecraft:white_concrete
setblock 473 262 238 minecraft:light[level=12]
setblock 473 262 245 minecraft:light[level=12]
setblock 473 262 252 minecraft:light[level=12]
setblock 473 262 259 minecraft:light[level=12]
fill 473 262 265 473 266 266 minecraft:red_concrete
fill 473 262 268 473 266 269 minecraft:white_concrete
fill 474 262 229 474 265 229 minecraft:red_concrete
fill 474 262 265 474 265 265 minecraft:red_concrete
setblock 480 262 231 minecraft:light[level=12]
setblock 480 262 238 minecraft:light[level=12]
setblock 480 262 245 minecraft:light[level=12]
setblock 480 262 252 minecraft:light[level=12]
setblock 480 262 259 minecraft:light[level=12]
setblock 480 262 266 minecraft:light[level=12]
fill 481 262 233 481 262 235 minecraft:magenta_concrete
fill 482 262 235 482 262 236 minecraft:magenta_concrete
fill 483 262 231 484 262 231 minecraft:magenta_concrete
fill 483 262 236 484 262 236 minecraft:magenta_concrete
fill 484 262 232 485 262 232 minecraft:magenta_concrete
fill 485 262 233 485 263 235 minecraft:magenta_concrete
fill 486 262 233 486 262 234 minecraft:magenta_concrete
setblock 487 262 231 minecraft:light[level=12]
setblock 487 262 238 minecraft:light[level=12]
setblock 487 262 245 minecraft:light[level=12]
setblock 487 262 252 minecraft:light[level=12]
setblock 487 262 259 minecraft:light[level=12]
setblock 487 262 266 minecraft:light[level=12]
setblock 494 262 231 minecraft:light[level=12]
setblock 494 262 238 minecraft:light[level=12]
setblock 494 262 245 minecraft:light[level=12]
setblock 494 262 252 minecraft:light[level=12]
setblock 494 262 259 minecraft:light[level=12]
setblock 494 262 266 minecraft:light[level=12]
setblock 501 262 231 minecraft:light[level=12]
setblock 501 262 238 minecraft:light[level=12]
setblock 501 262 245 minecraft:light[level=12]
setblock 501 262 252 minecraft:light[level=12]
setblock 501 262 259 minecraft:light[level=12]
setblock 501 262 266 minecraft:light[level=12]
fill 505 262 228 505 308 228 minecraft:lime_terracotta
fill 506 262 270 506 308 270 minecraft:white_concrete
fill 507 262 228 507 308 228 minecraft:white_concrete
fill 507 262 230 507 263 232 minecraft:white_concrete
fill 507 262 266 507 263 268 minecraft:white_concrete
setblock 508 262 238 minecraft:light[level=12]
setblock 508 262 245 minecraft:light[level=12]
setblock 508 262 252 minecraft:light[level=12]
setblock 508 262 259 minecraft:light[level=12]
fill 509 262 229 509 266 230 minecraft:red_concrete
fill 509 262 232 509 266 233 minecraft:white_concrete
fill 509 262 265 509 266 266 minecraft:red_concrete
fill 509 262 268 509 266 269 minecraft:white_concrete
fill 510 262 229 510 265 229 minecraft:red_concrete
fill 510 262 265 510 265 265 minecraft:red_concrete
fill 472 263 229 472 267 229 minecraft:red_concrete
setblock 472 263 230 minecraft:white_concrete
fill 472 263 265 472 267 265 minecraft:red_concrete
setblock 472 263 266 minecraft:white_concrete
fill 474 263 232 474 267 233 minecraft:white_concrete
fill 474 263 268 474 267 269 minecraft:white_concrete
setblock 475 263 232 minecraft:red_concrete
setblock 475 263 268 minecraft:red_concrete
setblock 481 263 234 minecraft:magenta_concrete
setblock 482 263 232 minecraft:magenta_concrete
setblock 482 263 235 minecraft:magenta_concrete
setblock 484 263 232 minecraft:magenta_concrete
fill 495 263 242 497 264 242 minecraft:light_blue_concrete
fill 496 263 241 497 264 241 minecraft:light_blue_concrete
fill 496 263 243 496 264 243 minecraft:light_blue_concrete
fill 506 263 228 506 308 228 minecraft:white_concrete
fill 508 263 229 508 267 229 minecraft:red_concrete
setblock 508 263 230 minecraft:white_concrete
fill 508 263 265 508 267 265 minecraft:red_concrete
setblock 508 263 266 minecraft:white_concrete
fill 510 263 232 510 267 233 minecraft:white_concrete
fill 510 263 268 510 267 269 minecraft:white_concrete
setblock 511 263 232 minecraft:red_concrete
setblock 511 263 268 minecraft:red_concrete
fill 471 264 230 472 267 230 minecraft:red_concrete
fill 471 264 266 472 267 266 minecraft:red_concrete
fill 475 264 232 475 268 232 minecraft:white_concrete
fill 475 264 268 475 268 268 minecraft:white_concrete
fill 507 264 230 508 267 230 minecraft:red_concrete
fill 507 264 231 507 264 232 minecraft:white_concrete
fill 507 264 266 508 267 266 minecraft:red_concrete
fill 507 264 267 507 264 268 minecraft:white_concrete
fill 511 264 232 511 268 232 minecraft:white_concrete
fill 511 264 268 511 268 268 minecraft:white_concrete
fill 471 265 231 472 269 231 minecraft:red_concrete
setblock 471 265 232 minecraft:white_concrete
fill 471 265 250 471 272 250 minecraft:brown_terracotta
fill 471 265 267 472 269 267 minecraft:red_concrete
setblock 471 265 268 minecraft:white_concrete
fill 473 265 231 475 269 231 minecraft:white_concrete
fill 473 265 267 475 269 267 minecraft:white_concrete
setblock 474 265 230 minecraft:red_concrete
setblock 474 265 266 minecraft:red_concrete
fill 475 265 230 475 270 230 minecraft:white_concrete
fill 475 265 266 475 270 266 minecraft:white_concrete
fill 507 265 231 508 269 231 minecraft:red_concrete
setblock 507 265 232 minecraft:white_concrete
fill 507 265 267 508 269 267 minecraft:red_concrete
setblock 507 265 268 minecraft:white_concrete
fill 509 265 231 511 269 231 minecraft:white_concrete
fill 509 265 267 511 269 267 minecraft:white_concrete
setblock 510 265 230 minecraft:red_concrete
setblock 510 265 266 minecraft:red_concrete
fill 511 265 230 511 270 230 minecraft:white_concrete
fill 511 265 266 511 270 266 minecraft:white_concrete
fill 471 266 232 472 269 232 minecraft:red_concrete
fill 471 266 268 472 269 268 minecraft:red_concrete
setblock 472 266 233 minecraft:white_concrete
setblock 472 266 269 minecraft:white_concrete
setblock 473 266 239 minecraft:light[level=15]
setblock 473 266 247 minecraft:light[level=15]
setblock 473 266 255 minecraft:light[level=15]
setblock 473 266 263 minecraft:light[level=15]
fill 474 266 229 474 270 230 minecraft:white_concrete
fill 474 266 265 474 270 266 minecraft:white_concrete
setblock 481 266 231 minecraft:light[level=15]
setblock 481 266 239 minecraft:light[level=15]
setblock 481 266 247 minecraft:light[level=15]
setblock 481 266 255 minecraft:light[level=15]
setblock 481 266 263 minecraft:light[level=15]
setblock 489 266 231 minecraft:light[level=15]
setblock 489 266 239 minecraft:light[level=15]
setblock 489 266 247 minecraft:light[level=15]
setblock 489 266 255 minecraft:light[level=15]
setblock 489 266 263 minecraft:light[level=15]
setblock 497 266 231 minecraft:light[level=15]
setblock 497 266 239 minecraft:light[level=15]
setblock 497 266 247 minecraft:light[level=15]
setblock 497 266 255 minecraft:light[level=15]
setblock 497 266 263 minecraft:light[level=15]
setblock 505 266 231 minecraft:light[level=15]
setblock 505 266 239 minecraft:light[level=15]
setblock 505 266 247 minecraft:light[level=15]
setblock 505 266 255 minecraft:light[level=15]
setblock 505 266 263 minecraft:light[level=15]
fill 507 266 232 508 269 232 minecraft:red_concrete
fill 507 266 268 508 269 268 minecraft:red_concrete
setblock 508 266 233 minecraft:white_concrete
setblock 508 266 269 minecraft:white_concrete
fill 510 266 229 510 270 230 minecraft:white_concrete
fill 510 266 265 510 270 266 minecraft:white_concrete
fill 472 267 233 473 270 233 minecraft:red_concrete
fill 472 267 269 473 270 269 minecraft:red_concrete
fill 473 267 229 473 271 230 minecraft:white_concrete
fill 473 267 232 473 271 232 minecraft:red_concrete
fill 473 267 265 473 271 266 minecraft:white_concrete
fill 473 267 268 473 271 268 minecraft:red_concrete
fill 480 267 248 485 267 254 minecraft:yellow_terracotta
fill 481 267 246 487 267 247 minecraft:yellow_terracotta
fill 481 267 255 487 267 256 minecraft:yellow_terracotta
fill 482 267 245 498 267 245 minecraft:yellow_terracotta
fill 482 267 257 498 267 257 minecraft:yellow_terracotta
fill 483 267 244 497 267 244 minecraft:yellow_terracotta
fill 483 267 258 497 267 258 minecraft:yellow_terracotta
fill 484 267 243 496 267 243 minecraft:yellow_terracotta
fill 484 267 259 496 267 259 minecraft:yellow_terracotta
fill 485 267 242 495 267 242 minecraft:yellow_terracotta
fill 485 267 260 495 267 260 minecraft:yellow_terracotta
setblock 486 267 248 minecraft:yellow_terracotta
setblock 486 267 254 minecraft:yellow_terracotta
fill 487 267 241 493 267 241 minecraft:yellow_terracotta
fill 487 267 261 493 267 261 minecraft:yellow_terracotta
fill 488 267 246 499 267 246 minecraft:yellow_terracotta
fill 488 267 256 499 267 256 minecraft:yellow_terracotta
fill 493 267 247 499 267 247 minecraft:yellow_terracotta
fill 493 267 255 499 267 255 minecraft:yellow_terracotta
fill 494 267 248 500 267 248 minecraft:yellow_terracotta
fill 494 267 254 500 267 254 minecraft:yellow_terracotta
fill 495 267 249 500 267 253 minecraft:yellow_terracotta
fill 508 267 233 509 270 233 minecraft:red_concrete
fill 508 267 269 509 270 269 minecraft:red_concrete
fill 509 267 229 509 271 230 minecraft:white_concrete
fill 509 267 232 509 271 232 minecraft:red_concrete
fill 509 267 265 509 271 266 minecraft:white_concrete
fill 509 267 268 509 271 268 minecraft:red_concrete
setblock 471 268 230 minecraft:red_concrete
setblock 471 268 266 minecraft:red_concrete
fill 472 268 229 472 272 230 minecraft:white_concrete
fill 472 268 265 472 272 266 minecraft:white_concrete
setblock 473 268 238 minecraft:light[level=12]
setblock 473 268 245 minecraft:light[level=12]
setblock 473 268 252 minecraft:light[level=12]
setblock 473 268 259 minecraft:light[level=12]
setblock 474 268 232 minecraft:white_concrete
fill 474 268 233 474 272 233 minecraft:red_concrete
setblock 474 268 268 minecraft:white_concrete
fill 474 268 269 474 272 269 minecraft:red_concrete
fill 479 268 248 485 269 254 minecraft:orange_terracotta
setblock 480 268 231 minecraft:light[level=12]
setblock 480 268 238 minecraft:light[level=12]
setblock 480 268 245 minecraft:light[level=12]
fill 480 268 246 489 269 247 minecraft:orange_terracotta
fill 480 268 255 489 269 256 minecraft:orange_terracotta
setblock 480 268 259 minecraft:light[level=12]
setblock 480 268 266 minecraft:light[level=12]
fill 481 268 244 499 269 245 minecraft:orange_terracotta
fill 481 268 257 499 269 258 minecraft:orange_terracotta
fill 482 268 243 498 269 243 minecraft:orange_terracotta
fill 482 268 259 498 269 259 minecraft:orange_terracotta
fill 483 268 242 497 269 242 minecraft:orange_terracotta
fill 483 268 260 497 269 260 minecraft:orange_terracotta
fill 485 268 241 495 269 241 minecraft:orange_terracotta
fill 485 268 261 495 269 261 minecraft:orange_terracotta
fill 486 268 248 486 269 250 minecraft:orange_terracotta
fill 486 268 252 486 269 254 minecraft:orange_terracotta
setblock 487 268 231 minecraft:light[level=12]
setblock 487 268 238 minecraft:light[level=12]
fill 487 268 240 493 269 240 minecraft:orange_terracotta
fill 487 268 248 487 270 248 minecraft:orange_terracotta
setblock 487 268 252 minecraft:light[level=12]
fill 487 268 254 487 269 254 minecraft:orange_terracotta
fill 487 268 262 493 269 262 minecraft:orange_terracotta
setblock 487 268 266 minecraft:light[level=12]
fill 490 268 246 500 269 246 minecraft:orange_terracotta
fill 490 268 256 500 269 256 minecraft:orange_terracotta
fill 491 268 247 500 269 247 minecraft:orange_terracotta
fill 491 268 255 500 269 255 minecraft:orange_terracotta
fill 493 268 248 501 269 248 minecraft:orange_terracotta
fill 493 268 254 501 269 254 minecraft:orange_terracotta
setblock 494 268 231 minecraft:light[level=12]
setblock 494 268 238 minecraft:light[level=12]
fill 494 268 249 501 269 250 minecraft:orange_terracotta
fill 494 268 252 501 269 253 minecraft:orange_terracotta
setblock 494 268 266 minecraft:light[level=12]
fill 495 268 251 501 269 251 minecraft:orange_terracotta
setblock 501 268 231 minecraft:light[level=12]
setblock 501 268 238 minecraft:light[level=12]
setblock 501 268 245 minecraft:light[level=12]
setblock 501 268 259 minecraft:light[level=12]
setblock 501 268 266 minecraft:light[level=12]
setblock 507 268 230 minecraft:red_concrete
setblock 507 268 266 minecraft:red_concrete
fill 508 268 229 508 272 230 minecraft:white_concrete
setblock 508 268 238 minecraft:light[level=12]
setblock 508 268 245 minecraft:light[level=12]
setblock 508 268 252 minecraft:light[level=12]
setblock 508 268 259 minecraft:light[level=12]
fill 508 268 265 508 272 266 minecraft:white_concrete
setblock 510 268 232 minecraft:white_concrete
fill 510 268 233 510 272 233 minecraft:red_concrete
setblock 510 268 268 minecraft:white_concrete
fill 510 268 269 510 272 269 minecraft:red_concrete
fill 471 269 230 471 272 230 minecraft:white_concrete
fill 471 269 266 471 272 266 minecraft:white_concrete
fill 474 269 232 475 272 232 minecraft:red_concrete
fill 474 269 268 475 272 268 minecraft:red_concrete
fill 475 269 229 475 282 229 minecraft:brown_terracotta
setblock 479 269 247 minecraft:orange_terracotta
fill 479 269 255 479 270 255 minecraft:orange_terracotta
fill 480 269 245 480 270 245 minecraft:orange_terracotta
setblock 480 269 257 minecraft:orange_terracotta
setblock 484 269 241 minecraft:orange_terracotta
fill 484 269 261 484 270 261 minecraft:orange_terracotta
setblock 486 269 240 minecraft:orange_terracotta
setblock 486 269 251 minecraft:orange_terracotta
fill 486 269 262 486 270 262 minecraft:orange_terracotta
fill 487 269 249 487 270 249 minecraft:orange_terracotta
setblock 487 269 253 minecraft:orange_terracotta
setblock 488 269 248 minecraft:orange_terracotta
fill 488 269 254 488 270 254 minecraft:orange_terracotta
fill 490 269 247 490 270 247 minecraft:orange_terracotta
setblock 490 269 255 minecraft:orange_terracotta
setblock 492 269 248 minecraft:orange_terracotta
fill 492 269 254 492 270 254 minecraft:orange_terracotta
fill 493 269 249 493 270 249 minecraft:orange_terracotta
setblock 493 269 253 minecraft:orange_terracotta
setblock 494 269 240 minecraft:orange_terracotta
setblock 494 269 251 minecraft:orange_terracotta
fill 494 269 262 494 270 262 minecraft:orange_terracotta
setblock 496 269 241 minecraft:orange_terracotta
fill 496 269 261 496 270 261 minecraft:orange_terracotta
fill 500 269 245 500 270 245 minecraft:orange_terracotta
setblock 500 269 257 minecraft:orange_terracotta
setblock 501 269 247 minecraft:orange_terracotta
fill 501 269 255 501 270 255 minecraft:orange_terracotta
fill 507 269 230 507 272 230 minecraft:white_concrete
fill 507 269 266 507 273 266 minecraft:white_concrete
fill 510 269 232 511 272 232 minecraft:red_concrete
fill 510 269 268 511 272 268 minecraft:red_concrete
fill 471 270 231 471 272 232 minecraft:white_concrete
fill 471 270 267 471 272 268 minecraft:white_concrete
fill 472 270 231 472 272 231 minecraft:white_concrete
setblock 472 270 232 minecraft:red_concrete
fill 472 270 267 472 272 267 minecraft:white_concrete
setblock 472 270 268 minecraft:red_concrete
fill 473 270 231 475 272 231 minecraft:red_concrete
fill 473 270 267 475 272 267 minecraft:red_concrete
fill 478 270 249 486 270 251 minecraft:pink_concrete
fill 478 270 252 485 270 253 minecraft:orange_terracotta
fill 479 270 246 480 271 248 minecraft:pink_concrete
fill 479 270 254 483 270 254 minecraft:orange_terracotta
fill 479 270 256 486 270 256 minecraft:pink_concrete
fill 480 270 244 484 270 244 minecraft:orange_terracotta
fill 480 270 255 481 270 255 minecraft:orange_terracotta
fill 480 270 257 484 271 258 minecraft:pink_concrete
fill 481 270 243 483 270 243 minecraft:orange_terracotta
fill 481 270 245 484 270 246 minecraft:orange_terracotta
fill 481 270 247 482 274 248 minecraft:pink_concrete
fill 481 270 259 483 271 259 minecraft:pink_concrete
setblock 482 270 242 minecraft:orange_terracotta
fill 482 270 255 486 273 255 minecraft:pink_concrete
fill 482 270 260 483 271 260 minecraft:pink_concrete
fill 483 270 241 487 271 242 minecraft:pink_concrete
fill 483 270 247 486 270 247 minecraft:orange_terracotta
fill 483 270 248 484 273 248 minecraft:pink_concrete
setblock 483 270 261 minecraft:orange_terracotta
fill 484 270 243 488 273 243 minecraft:pink_concrete
fill 484 270 254 487 273 254 minecraft:pink_concrete
fill 484 270 259 487 270 260 minecraft:orange_terracotta
fill 485 270 240 487 271 240 minecraft:pink_concrete
fill 485 270 244 488 273 245 minecraft:pink_concrete
setblock 485 270 246 minecraft:orange_terracotta
fill 485 270 248 486 270 248 minecraft:orange_terracotta
fill 485 270 257 485 274 257 minecraft:pink_concrete
fill 485 270 258 488 270 258 minecraft:orange_terracotta
fill 485 270 261 485 270 262 minecraft:orange_terracotta
fill 486 270 246 488 273 246 minecraft:pink_concrete
setblock 486 270 252 minecraft:orange_terracotta
fill 486 270 253 487 272 253 minecraft:pink_concrete
fill 486 270 257 488 270 257 minecraft:orange_terracotta
fill 486 270 261 487 270 261 minecraft:orange_terracotta
fill 487 270 247 489 273 247 minecraft:pink_concrete
fill 487 270 255 488 270 256 minecraft:orange_terracotta
setblock 487 270 262 minecraft:orange_terracotta
fill 488 270 239 492 270 241 minecraft:orange_terracotta
fill 488 270 242 488 274 242 minecraft:pink_concrete
fill 488 270 248 488 272 248 minecraft:pink_concrete
fill 488 270 259 492 271 263 minecraft:pink_concrete
fill 489 270 242 491 270 246 minecraft:orange_terracotta
fill 489 270 255 491 272 258 minecraft:pink_concrete
fill 491 270 247 493 272 247 minecraft:pink_concrete
fill 492 270 242 494 274 246 minecraft:pink_concrete
fill 492 270 248 492 272 248 minecraft:pink_concrete
fill 492 270 255 493 270 258 minecraft:orange_terracotta
fill 493 270 240 495 270 241 minecraft:pink_concrete
fill 493 270 248 495 270 248 minecraft:orange_terracotta
fill 493 270 253 494 272 254 minecraft:pink_concrete
fill 493 270 259 493 270 262 minecraft:orange_terracotta
fill 494 270 247 497 270 247 minecraft:orange_terracotta
fill 494 270 249 502 271 251 minecraft:pink_concrete
fill 494 270 252 502 270 252 minecraft:orange_terracotta
fill 494 270 255 498 273 256 minecraft:pink_concrete
fill 494 270 257 494 270 261 minecraft:orange_terracotta
fill 495 270 242 495 274 245 minecraft:pink_concrete
fill 495 270 246 499 270 246 minecraft:orange_terracotta
fill 495 270 253 502 270 253 minecraft:orange_terracotta
fill 495 270 254 496 273 254 minecraft:pink_concrete
fill 495 270 257 500 272 257 minecraft:pink_concrete
fill 495 270 258 495 270 262 minecraft:orange_terracotta
fill 496 270 241 496 272 243 minecraft:pink_concrete
fill 496 270 244 499 270 245 minecraft:orange_terracotta
fill 496 270 248 501 272 248 minecraft:pink_concrete
fill 496 270 258 500 271 258 minecraft:pink_concrete
fill 496 270 259 496 270 260 minecraft:orange_terracotta
fill 497 270 241 497 270 242 minecraft:pink_concrete
fill 497 270 243 499 270 243 minecraft:orange_terracotta
fill 497 270 254 501 270 254 minecraft:orange_terracotta
fill 497 270 259 498 271 260 minecraft:pink_concrete
setblock 497 270 261 minecraft:orange_terracotta
setblock 498 270 242 minecraft:orange_terracotta
fill 498 270 247 501 272 247 minecraft:pink_concrete
fill 499 270 255 500 270 255 minecraft:orange_terracotta
fill 499 270 256 501 271 256 minecraft:pink_concrete
fill 499 270 259 499 271 259 minecraft:pink_concrete
setblock 500 270 244 minecraft:orange_terracotta
fill 500 270 246 501 270 246 minecraft:pink_concrete
fill 507 270 231 507 272 232 minecraft:white_concrete
fill 507 270 267 507 272 268 minecraft:white_concrete
fill 508 270 231 508 272 231 minecraft:white_concrete
setblock 508 270 232 minecraft:red_concrete
fill 508 270 267 508 272 267 minecraft:white_concrete
setblock 508 270 268 minecraft:red_concrete
fill 509 270 231 511 272 231 minecraft:red_concrete
fill 509 270 267 511 272 267 minecraft:red_concrete
setblock 471 271 229 minecraft:pink_wool
fill 471 271 233 471 271 234 minecraft:pink_wool
setblock 471 271 235 minecraft:white_wool
fill 471 271 236 471 271 238 minecraft:pink_wool
setblock 471 271 239 minecraft:white_wool
fill 471 271 240 471 271 242 minecraft:pink_wool
setblock 471 271 243 minecraft:white_wool
fill 471 271 244 471 271 246 minecraft:pink_wool
setblock 471 271 247 minecraft:white_wool
fill 471 271 248 472 271 249 minecraft:pink_wool
setblock 471 271 251 minecraft:white_wool
fill 471 271 252 471 271 254 minecraft:pink_wool
setblock 471 271 255 minecraft:white_wool
fill 471 271 256 471 271 258 minecraft:pink_wool
setblock 471 271 259 minecraft:white_wool
fill 471 271 260 471 271 262 minecraft:pink_wool
setblock 471 271 263 minecraft:white_wool
fill 471 271 264 471 271 265 minecraft:pink_wool
setblock 471 271 269 minecraft:pink_wool
fill 472 271 232 472 272 233 minecraft:white_concrete
setblock 472 271 234 minecraft:white_wool
fill 472 271 235 472 271 237 minecraft:pink_wool
setblock 472 271 238 minecraft:white_wool
fill 472 271 239 472 271 241 minecraft:pink_wool
setblock 472 271 242 minecraft:white_wool
fill 472 271 243 472 271 245 minecraft:pink_wool
setblock 472 271 246 minecraft:white_wool
fill 472 271 247 474 271 247 minecraft:pink_wool
setblock 472 271 250 minecraft:white_wool
fill 472 271 251 472 271 253 minecraft:pink_wool
setblock 472 271 254 minecraft:white_wool
fill 472 271 255 472 271 257 minecraft:pink_wool
setblock 472 271 258 minecraft:white_wool
fill 472 271 259 472 271 261 minecraft:pink_wool
setblock 472 271 262 minecraft:white_wool
fill 472 271 263 473 271 264 minecraft:pink_wool
fill 472 271 268 472 272 269 minecraft:white_concrete
setblock 473 271 233 minecraft:red_concrete
fill 473 271 234 473 271 236 minecraft:pink_wool
setblock 473 271 237 minecraft:white_wool
fill 473 271 238 473 271 240 minecraft:pink_wool
setblock 473 271 241 minecraft:white_wool
fill 473 271 242 473 271 244 minecraft:pink_wool
setblock 473 271 245 minecraft:white_wool
fill 473 271 246 475 271 246 minecraft:pink_wool
setblock 473 271 248 minecraft:pink_wool
setblock 473 271 249 minecraft:white_wool
fill 473 271 250 473 271 252 minecraft:pink_wool
setblock 473 271 253 minecraft:white_wool
fill 473 271 254 473 271 256 minecraft:pink_wool
setblock 473 271 257 minecraft:white_wool
fill 473 271 258 473 271 260 minecraft:pink_wool
setblock 473 271 261 minecraft:white_wool
fill 473 271 262 475 271 262 minecraft:pink_wool
setblock 473 271 269 minecraft:red_concrete
setblock 474 271 229 minecraft:white_concrete
fill 474 271 230 475 272 230 minecraft:red_concrete
fill 474 271 234 474 271 235 minecraft:pink_wool
setblock 474 271 236 minecraft:white_wool
fill 474 271 237 474 271 239 minecraft:pink_wool
setblock 474 271 240 minecraft:white_wool
fill 474 271 241 474 271 243 minecraft:pink_wool
setblock 474 271 244 minecraft:white_wool
fill 474 271 245 476 271 245 minecraft:pink_wool
setblock 474 271 248 minecraft:white_wool
fill 474 271 249 474 271 251 minecraft:pink_wool
setblock 474 271 252 minecraft:white_wool
fill 474 271 253 474 271 255 minecraft:pink_wool
setblock 474 271 256 minecraft:white_wool
fill 474 271 257 474 271 259 minecraft:pink_wool
setblock 474 271 260 minecraft:white_wool
fill 474 271 261 476 271 261 minecraft:pink_wool
setblock 474 271 263 minecraft:pink_wool
setblock 474 271 264 minecraft:white_wool
setblock 474 271 265 minecraft:white_concrete
fill 474 271 266 475 274 266 minecraft:red_concrete
fill 475 271 233 475 271 234 minecraft:pink_wool
setblock 475 271 235 minecraft:white_wool
fill 475 271 236 475 271 238 minecraft:pink_wool
setblock 475 271 239 minecraft:white_wool
fill 475 271 240 475 271 242 minecraft:pink_wool
setblock 475 271 243 minecraft:white_wool
fill 475 271 244 477 271 244 minecraft:pink_wool
setblock 475 271 247 minecraft:white_wool
fill 475 271 248 475 271 250 minecraft:pink_wool
setblock 475 271 251 minecraft:white_wool
fill 475 271 252 475 271 254 minecraft:pink_wool
setblock 475 271 255 minecraft:white_wool
fill 475 271 256 475 271 258 minecraft:pink_wool
setblock 475 271 259 minecraft:white_wool
fill 475 271 260 477 271 260 minecraft:pink_wool
setblock 475 271 263 minecraft:white_wool
fill 475 271 264 476 271 265 minecraft:pink_wool
fill 475 271 269 476 271 269 minecraft:pink_wool
setblock 476 271 229 minecraft:pink_wool
setblock 476 271 230 minecraft:white_wool
fill 476 271 231 476 271 233 minecraft:pink_wool
setblock 476 271 234 minecraft:white_wool
fill 476 271 235 476 271 237 minecraft:pink_wool
setblock 476 271 238 minecraft:white_wool
fill 476 271 239 476 271 241 minecraft:pink_wool
setblock 476 271 242 minecraft:white_wool
fill 476 271 243 478 271 243 minecraft:pink_wool
setblock 476 271 246 minecraft:white_wool
fill 476 271 247 476 271 249 minecraft:pink_wool
setblock 476 271 250 minecraft:white_wool
fill 476 271 251 476 271 253 minecraft:pink_wool
setblock 476 271 254 minecraft:white_wool
fill 476 271 255 476 271 257 minecraft:pink_wool
setblock 476 271 258 minecraft:white_wool
fill 476 271 259 478 271 259 minecraft:pink_wool
setblock 476 271 262 minecraft:white_wool
fill 476 271 263 478 271 263 minecraft:pink_wool
setblock 476 271 266 minecraft:white_wool
fill 476 271 267 477 271 268 minecraft:pink_wool
setblock 477 271 229 minecraft:white_wool
fill 477 271 230 477 271 232 minecraft:pink_wool
setblock 477 271 233 minecraft:white_wool
fill 477 271 234 477 271 236 minecraft:pink_wool
setblock 477 271 237 minecraft:white_wool
fill 477 271 238 477 271 240 minecraft:pink_wool
setblock 477 271 241 minecraft:white_wool
fill 477 271 242 479 271 242 minecraft:pink_wool
setblock 477 271 245 minecraft:white_wool
fill 477 271 246 477 271 248 minecraft:pink_wool
setblock 477 271 249 minecraft:white_wool
fill 477 271 250 477 271 252 minecraft:pink_wool
setblock 477 271 253 minecraft:white_wool
fill 477 271 254 477 271 256 minecraft:pink_wool
setblock 477 271 257 minecraft:white_wool
fill 477 271 258 479 271 258 minecraft:pink_wool
setblock 477 271 261 minecraft:white_wool
fill 477 271 262 479 271 262 minecraft:pink_wool
setblock 477 271 264 minecraft:pink_wool
setblock 477 271 265 minecraft:white_wool
fill 477 271 266 479 271 266 minecraft:pink_wool
setblock 477 271 269 minecraft:white_wool
fill 478 271 229 478 271 231 minecraft:pink_wool
setblock 478 271 232 minecraft:white_wool
fill 478 271 233 478 271 235 minecraft:pink_wool
setblock 478 271 236 minecraft:white_wool
fill 478 271 237 478 271 239 minecraft:pink_wool
setblock 478 271 240 minecraft:white_wool
fill 478 271 241 480 271 241 minecraft:pink_wool
setblock 478 271 244 minecraft:white_wool
fill 478 271 245 478 271 247 minecraft:pink_wool
setblock 478 271 248 minecraft:white_wool
fill 478 271 249 487 271 249 minecraft:pink_concrete
setblock 478 271 250 minecraft:light_blue_concrete
fill 478 271 251 485 271 253 minecraft:pink_concrete
fill 478 271 254 478 271 255 minecraft:pink_wool
setblock 478 271 256 minecraft:white_wool
fill 478 271 257 479 271 257 minecraft:pink_wool
setblock 478 271 260 minecraft:white_wool
fill 478 271 261 480 271 261 minecraft:pink_wool
setblock 478 271 264 minecraft:white_wool
fill 478 271 265 480 271 265 minecraft:pink_wool
setblock 478 271 267 minecraft:pink_wool
setblock 478 271 268 minecraft:white_wool
fill 478 271 269 480 271 269 minecraft:pink_wool
fill 479 271 229 479 271 230 minecraft:pink_wool
setblock 479 271 231 minecraft:white_wool
fill 479 271 232 479 271 234 minecraft:pink_wool
setblock 479 271 235 minecraft:white_wool
fill 479 271 236 479 271 238 minecraft:pink_wool
setblock 479 271 239 minecraft:white_wool
fill 479 271 240 481 271 240 minecraft:pink_wool
setblock 479 271 243 minecraft:white_wool
fill 479 271 244 479 271 245 minecraft:pink_wool
fill 479 271 250 486 273 250 minecraft:pink_concrete
fill 479 271 254 481 272 255 minecraft:pink_concrete
setblock 479 271 256 minecraft:yellow_concrete
setblock 479 271 259 minecraft:white_wool
fill 479 271 260 481 271 260 minecraft:pink_wool
setblock 479 271 263 minecraft:white_wool
fill 479 271 264 481 271 264 minecraft:pink_wool
setblock 479 271 267 minecraft:white_wool
fill 479 271 268 481 271 268 minecraft:pink_wool
setblock 480 271 229 minecraft:pink_wool
setblock 480 271 230 minecraft:white_wool
fill 480 271 231 480 271 233 minecraft:pink_wool
setblock 480 271 234 minecraft:white_wool
fill 480 271 235 480 271 237 minecraft:pink_wool
setblock 480 271 238 minecraft:white_wool
fill 480 271 239 482 271 239 minecraft:pink_wool
setblock 480 271 242 minecraft:white_wool
setblock 480 271 243 minecraft:pink_wool
fill 480 271 244 484 271 245 minecraft:pink_concrete
fill 480 271 256 488 273 256 minecraft:pink_concrete
setblock 480 271 259 minecraft:pink_wool
setblock 480 271 262 minecraft:white_wool
fill 480 271 263 482 271 263 minecraft:pink_wool
setblock 480 271 266 minecraft:white_wool
fill 480 271 267 482 271 267 minecraft:pink_wool
setblock 481 271 229 minecraft:white_wool
fill 481 271 230 481 271 232 minecraft:pink_wool
setblock 481 271 233 minecraft:white_wool
fill 481 271 234 481 271 236 minecraft:pink_wool
setblock 481 271 237 minecraft:white_wool
fill 481 271 238 483 271 238 minecraft:pink_wool
setblock 481 271 241 minecraft:white_wool
setblock 481 271 242 minecraft:pink_wool
fill 481 271 243 483 271 243 minecraft:pink_concrete
fill 481 271 246 485 274 246 minecraft:pink_concrete
setblock 481 271 261 minecraft:white_wool
fill 481 271 262 483 271 262 minecraft:pink_wool
setblock 481 271 265 minecraft:white_wool
fill 481 271 266 483 271 266 minecraft:pink_wool
setblock 481 271 269 minecraft:white_wool
fill 482 271 229 482 271 231 minecraft:pink_wool
setblock 482 271 232 minecraft:white_wool
fill 482 271 233 482 271 235 minecraft:pink_wool
setblock 482 271 236 minecraft:white_wool
fill 482 271 237 484 271 237 minecraft:pink_wool
setblock 482 271 240 minecraft:white_wool
setblock 482 271 241 minecraft:pink_wool
setblock 482 271 242 minecraft:pink_concrete
fill 482 271 254 483 273 254 minecraft:pink_concrete
setblock 482 271 261 minecraft:pink_wool
setblock 482 271 264 minecraft:white_wool
fill 482 271 265 484 271 265 minecraft:pink_wool
setblock 482 271 268 minecraft:white_wool
fill 482 271 269 484 271 269 minecraft:pink_wool
fill 483 271 229 483 271 230 minecraft:pink_wool
setblock 483 271 231 minecraft:white_wool
fill 483 271 232 483 271 234 minecraft:pink_wool
setblock 483 271 235 minecraft:white_wool
fill 483 271 236 485 271 236 minecraft:pink_wool
setblock 483 271 239 minecraft:white_wool
fill 483 271 240 484 271 240 minecraft:pink_wool
fill 483 271 247 486 273 247 minecraft:pink_concrete
fill 483 271 261 487 271 261 minecraft:pink_concrete
setblock 483 271 263 minecraft:white_wool
fill 483 271 264 485 271 264 minecraft:pink_wool
setblock 483 271 267 minecraft:white_wool
fill 483 271 268 485 271 268 minecraft:pink_wool
setblock 484 271 229 minecraft:pink_wool
setblock 484 271 230 minecraft:white_wool
fill 484 271 231 484 271 233 minecraft:pink_wool
setblock 484 271 234 minecraft:white_wool
fill 484 271 235 486 271 235 minecraft:pink_wool
setblock 484 271 238 minecraft:white_wool
fill 484 271 239 486 271 239 minecraft:pink_wool
fill 484 271 259 487 272 260 minecraft:pink_concrete
setblock 484 271 262 minecraft:white_wool
fill 484 271 263 486 271 263 minecraft:pink_wool
setblock 484 271 266 minecraft:white_wool
fill 484 271 267 486 271 267 minecraft:pink_wool
setblock 485 271 229 minecraft:white_wool
fill 485 271 230 485 271 232 minecraft:pink_wool
setblock 485 271 233 minecraft:white_wool
fill 485 271 234 487 271 234 minecraft:pink_wool
setblock 485 271 237 minecraft:white_wool
fill 485 271 238 487 271 238 minecraft:pink_wool
fill 485 271 248 487 273 248 minecraft:pink_concrete
fill 485 271 258 488 274 258 minecraft:pink_concrete
fill 485 271 262 487 271 262 minecraft:pink_concrete
setblock 485 271 265 minecraft:white_wool
fill 485 271 266 487 271 266 minecraft:pink_wool
setblock 485 271 269 minecraft:white_wool
fill 486 271 229 486 271 231 minecraft:pink_wool
setblock 486 271 232 minecraft:white_wool
fill 486 271 233 488 271 233 minecraft:pink_wool
setblock 486 271 236 minecraft:white_wool
fill 486 271 237 488 271 237 minecraft:pink_wool
fill 486 271 251 486 272 252 minecraft:pink_concrete
fill 486 271 257 488 273 257 minecraft:pink_concrete
setblock 486 271 264 minecraft:white_wool
fill 486 271 265 488 271 265 minecraft:pink_wool
setblock 486 271 268 minecraft:white_wool
fill 486 271 269 488 271 269 minecraft:pink_wool
fill 487 271 229 487 271 230 minecraft:pink_wool
setblock 487 271 231 minecraft:white_wool
fill 487 271 232 489 271 232 minecraft:pink_wool
setblock 487 271 235 minecraft:white_wool
fill 487 271 236 489 271 236 minecraft:pink_wool
setblock 487 271 239 minecraft:white_wool
setblock 487 271 250 minecraft:pink_wool
setblock 487 271 252 minecraft:pink_wool
fill 487 271 255 488 273 255 minecraft:pink_concrete
setblock 487 271 263 minecraft:white_wool
fill 487 271 264 489 271 264 minecraft:pink_wool
setblock 487 271 267 minecraft:white_wool
fill 487 271 268 489 271 268 minecraft:pink_wool
setblock 488 271 229 minecraft:pink_wool
setblock 488 271 230 minecraft:white_wool
fill 488 271 231 490 271 231 minecraft:pink_wool
setblock 488 271 234 minecraft:white_wool
fill 488 271 235 490 271 235 minecraft:pink_wool
setblock 488 271 238 minecraft:white_wool
fill 488 271 239 488 271 241 minecraft:pink_concrete
fill 488 271 254 488 272 254 minecraft:pink_concrete
setblock 488 271 266 minecraft:white_wool
fill 488 271 267 490 271 267 minecraft:pink_wool
setblock 489 271 229 minecraft:white_wool
fill 489 271 230 491 271 230 minecraft:pink_wool
setblock 489 271 233 minecraft:white_wool
fill 489 271 234 491 271 234 minecraft:pink_wool
setblock 489 271 237 minecraft:white_wool
fill 489 271 238 491 271 238 minecraft:pink_wool
setblock 489 271 239 minecraft:red_concrete
fill 489 271 240 491 272 246 minecraft:pink_concrete
setblock 489 271 248 minecraft:pink_wool
setblock 489 271 254 minecraft:pink_wool
setblock 489 271 265 minecraft:white_wool
fill 489 271 266 491 271 266 minecraft:pink_wool
setblock 489 271 269 minecraft:white_wool
fill 490 271 229 492 271 229 minecraft:pink_wool
setblock 490 271 232 minecraft:white_wool
fill 490 271 233 492 271 233 minecraft:pink_wool
setblock 490 271 236 minecraft:white_wool
fill 490 271 237 492 271 237 minecraft:pink_wool
setblock 490 271 239 minecraft:white_concrete
setblock 490 271 247 minecraft:pink_concrete
setblock 490 271 264 minecraft:white_wool
fill 490 271 265 492 271 265 minecraft:pink_wool
setblock 490 271 268 minecraft:white_wool
fill 490 271 269 492 271 269 minecraft:pink_wool
setblock 491 271 231 minecraft:white_wool
fill 491 271 232 493 271 232 minecraft:pink_wool
setblock 491 271 235 minecraft:white_wool
fill 491 271 236 493 271 236 minecraft:pink_wool
fill 491 271 239 492 271 239 minecraft:pink_concrete
setblock 491 271 248 minecraft:pink_wool
setblock 491 271 254 minecraft:pink_wool
fill 491 271 264 493 271 264 minecraft:pink_wool
setblock 491 271 267 minecraft:white_wool
fill 491 271 268 493 271 268 minecraft:pink_wool
setblock 492 271 230 minecraft:white_wool
fill 492 271 231 494 271 231 minecraft:pink_wool
setblock 492 271 234 minecraft:white_wool
fill 492 271 235 494 271 235 minecraft:pink_wool
setblock 492 271 238 minecraft:white_wool
fill 492 271 240 494 272 241 minecraft:pink_concrete
fill 492 271 254 492 272 258 minecraft:pink_concrete
setblock 492 271 266 minecraft:white_wool
fill 492 271 267 494 271 267 minecraft:pink_wool
setblock 493 271 229 minecraft:white_wool
fill 493 271 230 495 271 230 minecraft:pink_wool
setblock 493 271 233 minecraft:white_wool
fill 493 271 234 495 271 234 minecraft:pink_wool
setblock 493 271 237 minecraft:white_wool
fill 493 271 238 494 271 239 minecraft:pink_wool
fill 493 271 248 493 272 249 minecraft:pink_concrete
setblock 493 271 250 minecraft:pink_wool
setblock 493 271 252 minecraft:pink_wool
fill 493 271 255 493 273 262 minecraft:pink_concrete
fill 493 271 263 494 271 263 minecraft:pink_wool
setblock 493 271 265 minecraft:white_wool
fill 493 271 266 495 271 266 minecraft:pink_wool
setblock 493 271 269 minecraft:white_wool
fill 494 271 229 496 271 229 minecraft:pink_wool
setblock 494 271 232 minecraft:white_wool
fill 494 271 233 496 271 233 minecraft:pink_wool
setblock 494 271 236 minecraft:white_wool
fill 494 271 237 496 271 237 minecraft:pink_wool
fill 494 271 247 495 273 248 minecraft:pink_concrete
fill 494 271 252 502 271 252 minecraft:pink_concrete
fill 494 271 257 494 272 262 minecraft:pink_concrete
setblock 494 271 264 minecraft:white_wool
fill 494 271 265 496 271 265 minecraft:pink_wool
setblock 494 271 268 minecraft:white_wool
fill 494 271 269 496 271 269 minecraft:pink_wool
setblock 495 271 231 minecraft:white_wool
fill 495 271 232 497 271 232 minecraft:pink_wool
setblock 495 271 235 minecraft:white_wool
fill 495 271 236 497 271 236 minecraft:pink_wool
setblock 495 271 238 minecraft:pink_wool
setblock 495 271 239 minecraft:white_wool
setblock 495 271 240 minecraft:magenta_concrete
fill 495 271 241 495 273 241 minecraft:pink_concrete
fill 495 271 246 500 273 246 minecraft:pink_concrete
fill 495 271 253 502 271 253 minecraft:pink_concrete
fill 495 271 258 495 271 262 minecraft:pink_concrete
setblock 495 271 263 minecraft:white_wool
fill 495 271 264 497 271 264 minecraft:pink_wool
setblock 495 271 267 minecraft:white_wool
fill 495 271 268 497 271 268 minecraft:pink_wool
setblock 496 271 230 minecraft:white_wool
fill 496 271 231 498 271 231 minecraft:pink_wool
setblock 496 271 234 minecraft:white_wool
fill 496 271 235 498 271 235 minecraft:pink_wool
setblock 496 271 238 minecraft:white_wool
fill 496 271 239 497 271 240 minecraft:pink_wool
fill 496 271 244 500 271 245 minecraft:pink_concrete
fill 496 271 247 497 274 247 minecraft:pink_concrete
fill 496 271 259 496 272 261 minecraft:pink_concrete
setblock 496 271 262 minecraft:white_wool
fill 496 271 263 498 271 263 minecraft:pink_wool
setblock 496 271 266 minecraft:white_wool
fill 496 271 267 498 271 267 minecraft:pink_wool
setblock 497 271 229 minecraft:white_wool
fill 497 271 230 499 271 230 minecraft:pink_wool
setblock 497 271 233 minecraft:white_wool
fill 497 271 234 499 271 234 minecraft:pink_wool
setblock 497 271 237 minecraft:white_wool
fill 497 271 238 499 271 238 minecraft:pink_wool
setblock 497 271 241 minecraft:lime_concrete
fill 497 271 242 497 272 243 minecraft:pink_concrete
fill 497 271 254 501 273 254 minecraft:pink_concrete
setblock 497 271 261 minecraft:pink_concrete
fill 497 271 262 499 271 262 minecraft:pink_wool
setblock 497 271 265 minecraft:white_wool
fill 497 271 266 499 271 266 minecraft:pink_wool
setblock 497 271 269 minecraft:white_wool
fill 498 271 229 500 271 229 minecraft:pink_wool
setblock 498 271 232 minecraft:white_wool
fill 498 271 233 500 271 233 minecraft:pink_wool
setblock 498 271 236 minecraft:white_wool
fill 498 271 237 500 271 237 minecraft:pink_wool
setblock 498 271 239 minecraft:pink_wool
setblock 498 271 240 minecraft:white_wool
fill 498 271 241 500 271 241 minecraft:pink_wool
setblock 498 271 242 minecraft:light_blue_concrete
fill 498 271 243 499 271 243 minecraft:pink_concrete
fill 498 271 261 500 271 261 minecraft:pink_wool
setblock 498 271 264 minecraft:white_wool
fill 498 271 265 500 271 265 minecraft:pink_wool
setblock 498 271 268 minecraft:white_wool
fill 498 271 269 500 271 269 minecraft:pink_wool
setblock 499 271 231 minecraft:white_wool
fill 499 271 232 501 271 232 minecraft:pink_wool
setblock 499 271 235 minecraft:white_wool
fill 499 271 236 501 271 236 minecraft:pink_wool
setblock 499 271 239 minecraft:white_wool
fill 499 271 240 501 271 240 minecraft:pink_wool
setblock 499 271 242 minecraft:pink_wool
fill 499 271 255 501 272 255 minecraft:pink_concrete
fill 499 271 260 501 271 260 minecraft:pink_wool
setblock 499 271 263 minecraft:white_wool
fill 499 271 264 501 271 264 minecraft:pink_wool
setblock 499 271 267 minecraft:white_wool
fill 499 271 268 501 271 268 minecraft:pink_wool
setblock 500 271 230 minecraft:white_wool
fill 500 271 231 502 271 231 minecraft:pink_wool
setblock 500 271 234 minecraft:white_wool
fill 500 271 235 502 271 235 minecraft:pink_wool
setblock 500 271 238 minecraft:white_wool
fill 500 271 239 502 271 239 minecraft:pink_wool
setblock 500 271 242 minecraft:white_wool
fill 500 271 243 502 271 243 minecraft:pink_wool
fill 500 271 259 502 271 259 minecraft:pink_wool
setblock 500 271 262 minecraft:white_wool
fill 500 271 263 502 271 263 minecraft:pink_wool
setblock 500 271 266 minecraft:white_wool
fill 500 271 267 502 271 267 minecraft:pink_wool
setblock 501 271 229 minecraft:white_wool
fill 501 271 230 503 271 230 minecraft:pink_wool
setblock 501 271 233 minecraft:white_wool
fill 501 271 234 503 271 234 minecraft:pink_wool
setblock 501 271 237 minecraft:white_wool
fill 501 271 238 503 271 238 minecraft:pink_wool
setblock 501 271 241 minecraft:white_wool
fill 501 271 242 503 271 242 minecraft:pink_wool
setblock 501 271 244 minecraft:pink_wool
setblock 501 271 245 minecraft:white_wool
setblock 501 271 246 minecraft:orange_concrete
setblock 501 271 257 minecraft:white_wool
fill 501 271 258 503 271 258 minecraft:pink_wool
setblock 501 271 261 minecraft:white_wool
fill 501 271 262 503 271 262 minecraft:pink_wool
setblock 501 271 265 minecraft:white_wool
fill 501 271 266 503 271 266 minecraft:pink_wool
setblock 501 271 269 minecraft:white_wool
fill 502 271 229 504 271 229 minecraft:pink_wool
setblock 502 271 232 minecraft:white_wool
fill 502 271 233 504 271 233 minecraft:pink_wool
setblock 502 271 236 minecraft:white_wool
fill 502 271 237 504 271 237 minecraft:pink_wool
setblock 502 271 240 minecraft:white_wool
fill 502 271 241 504 271 241 minecraft:pink_wool
setblock 502 271 244 minecraft:white_wool
fill 502 271 245 502 271 247 minecraft:pink_wool
setblock 502 271 248 minecraft:white_wool
fill 502 271 254 502 271 255 minecraft:pink_wool
setblock 502 271 256 minecraft:white_wool
fill 502 271 257 504 271 257 minecraft:pink_wool
setblock 502 271 260 minecraft:white_wool
fill 502 271 261 504 271 261 minecraft:pink_wool
setblock 502 271 264 minecraft:white_wool
fill 502 271 265 504 271 265 minecraft:pink_wool
setblock 502 271 268 minecraft:white_wool
fill 502 271 269 504 271 269 minecraft:pink_wool
setblock 503 271 231 minecraft:white_wool
fill 503 271 232 505 271 232 minecraft:pink_wool
setblock 503 271 235 minecraft:white_wool
fill 503 271 236 505 271 236 minecraft:pink_wool
setblock 503 271 239 minecraft:white_wool
fill 503 271 240 505 271 240 minecraft:pink_wool
setblock 503 271 243 minecraft:white_wool
fill 503 271 244 503 271 246 minecraft:pink_wool
setblock 503 271 247 minecraft:white_wool
fill 503 271 248 503 271 250 minecraft:pink_wool
setblock 503 271 251 minecraft:white_wool
fill 503 271 252 503 271 254 minecraft:pink_wool
setblock 503 271 255 minecraft:white_wool
fill 503 271 256 505 271 256 minecraft:pink_wool
setblock 503 271 259 minecraft:white_wool
fill 503 271 260 505 271 260 minecraft:pink_wool
setblock 503 271 263 minecraft:white_wool
fill 503 271 264 505 271 264 minecraft:pink_wool
setblock 503 271 267 minecraft:white_wool
fill 503 271 268 505 271 268 minecraft:pink_wool
setblock 504 271 230 minecraft:white_wool
fill 504 271 231 506 271 231 minecraft:pink_wool
setblock 504 271 234 minecraft:white_wool
fill 504 271 235 506 271 235 minecraft:pink_wool
setblock 504 271 238 minecraft:white_wool
fill 504 271 239 506 271 239 minecraft:pink_wool
setblock 504 271 242 minecraft:white_wool
fill 504 271 243 504 271 245 minecraft:pink_wool
setblock 504 271 246 minecraft:white_wool
fill 504 271 247 504 271 249 minecraft:pink_wool
setblock 504 271 250 minecraft:white_wool
fill 504 271 251 504 271 253 minecraft:pink_wool
setblock 504 271 254 minecraft:white_wool
fill 504 271 255 506 271 255 minecraft:pink_wool
setblock 504 271 258 minecraft:white_wool
fill 504 271 259 506 271 259 minecraft:pink_wool
setblock 504 271 262 minecraft:white_wool
fill 504 271 263 506 271 263 minecraft:pink_wool
setblock 504 271 266 minecraft:white_wool
fill 504 271 267 506 271 267 minecraft:pink_wool
setblock 505 271 229 minecraft:white_wool
fill 505 271 230 506 271 230 minecraft:pink_wool
setblock 505 271 233 minecraft:white_wool
fill 505 271 234 507 271 234 minecraft:pink_wool
setblock 505 271 237 minecraft:white_wool
fill 505 271 238 507 271 238 minecraft:pink_wool
setblock 505 271 241 minecraft:white_wool
fill 505 271 242 505 271 244 minecraft:pink_wool
setblock 505 271 245 minecraft:white_wool
fill 505 271 246 505 271 248 minecraft:pink_wool
setblock 505 271 249 minecraft:white_wool
fill 505 271 250 505 271 252 minecraft:pink_wool
setblock 505 271 253 minecraft:white_wool
fill 505 271 254 507 271 254 minecraft:pink_wool
setblock 505 271 257 minecraft:white_wool
fill 505 271 258 507 271 258 minecraft:pink_wool
setblock 505 271 261 minecraft:white_wool
fill 505 271 262 507 271 262 minecraft:pink_wool
setblock 505 271 265 minecraft:white_wool
fill 505 271 266 506 271 266 minecraft:pink_wool
setblock 505 271 269 minecraft:white_wool
fill 506 271 229 507 271 229 minecraft:pink_wool
setblock 506 271 232 minecraft:white_wool
fill 506 271 233 507 271 233 minecraft:pink_wool
setblock 506 271 236 minecraft:white_wool
fill 506 271 237 508 271 237 minecraft:pink_wool
setblock 506 271 240 minecraft:white_wool
fill 506 271 241 506 271 243 minecraft:pink_wool
setblock 506 271 244 minecraft:white_wool
fill 506 271 245 506 271 247 minecraft:pink_wool
setblock 506 271 248 minecraft:white_wool
fill 506 271 249 506 271 251 minecraft:pink_wool
setblock 506 271 252 minecraft:white_wool
fill 506 271 253 508 271 253 minecraft:pink_wool
setblock 506 271 256 minecraft:white_wool
fill 506 271 257 508 271 257 minecraft:pink_wool
setblock 506 271 260 minecraft:white_wool
fill 506 271 261 508 271 261 minecraft:pink_wool
setblock 506 271 264 minecraft:white_wool
fill 506 271 265 507 271 265 minecraft:pink_wool
setblock 506 271 268 minecraft:white_wool
fill 506 271 269 507 271 269 minecraft:pink_wool
setblock 507 271 235 minecraft:white_wool
fill 507 271 236 509 271 236 minecraft:pink_wool
setblock 507 271 239 minecraft:white_wool
fill 507 271 240 507 271 242 minecraft:pink_wool
setblock 507 271 243 minecraft:white_wool
fill 507 271 244 507 271 246 minecraft:pink_wool
setblock 507 271 247 minecraft:white_wool
fill 507 271 248 507 271 250 minecraft:pink_wool
setblock 507 271 251 minecraft:white_wool
fill 507 271 252 509 271 252 minecraft:pink_wool
setblock 507 271 255 minecraft:white_wool
fill 507 271 256 509 271 256 minecraft:pink_wool
setblock 507 271 259 minecraft:white_wool
fill 507 271 260 509 271 260 minecraft:pink_wool
setblock 507 271 263 minecraft:white_wool
fill 507 271 264 509 271 264 minecraft:pink_wool
fill 508 271 232 508 275 233 minecraft:white_concrete
setblock 508 271 234 minecraft:white_wool
fill 508 271 235 510 271 235 minecraft:pink_wool
setblock 508 271 238 minecraft:white_wool
fill 508 271 239 508 271 241 minecraft:pink_wool
setblock 508 271 242 minecraft:white_wool
fill 508 271 243 508 271 245 minecraft:pink_wool
setblock 508 271 246 minecraft:white_wool
fill 508 271 247 508 271 249 minecraft:pink_wool
setblock 508 271 250 minecraft:white_wool
fill 508 271 251 510 271 251 minecraft:pink_wool
setblock 508 271 254 minecraft:white_wool
fill 508 271 255 510 271 255 minecraft:pink_wool
setblock 508 271 258 minecraft:white_wool
fill 508 271 259 510 271 259 minecraft:pink_wool
setblock 508 271 262 minecraft:white_wool
fill 508 271 263 510 271 263 minecraft:pink_wool
fill 508 271 268 508 272 269 minecraft:white_concrete
setblock 509 271 233 minecraft:red_concrete
fill 509 271 234 511 271 234 minecraft:pink_wool
setblock 509 271 237 minecraft:white_wool
fill 509 271 238 509 271 240 minecraft:pink_wool
setblock 509 271 241 minecraft:white_wool
fill 509 271 242 509 271 244 minecraft:pink_wool
setblock 509 271 245 minecraft:white_wool
fill 509 271 246 509 271 248 minecraft:pink_wool
setblock 509 271 249 minecraft:white_wool
fill 509 271 250 511 271 250 minecraft:pink_wool
setblock 509 271 253 minecraft:white_wool
fill 509 271 254 511 271 254 minecraft:pink_wool
setblock 509 271 257 minecraft:white_wool
fill 509 271 258 511 271 258 minecraft:pink_wool
setblock 509 271 261 minecraft:white_wool
fill 509 271 262 511 271 262 minecraft:pink_wool
setblock 509 271 269 minecraft:red_concrete
setblock 510 271 229 minecraft:white_concrete
fill 510 271 230 511 272 230 minecraft:red_concrete
setblock 510 271 236 minecraft:white_wool
fill 510 271 237 510 271 239 minecraft:pink_wool
setblock 510 271 240 minecraft:white_wool
fill 510 271 241 510 271 243 minecraft:pink_wool
setblock 510 271 244 minecraft:white_wool
fill 510 271 245 510 271 247 minecraft:pink_wool
setblock 510 271 248 minecraft:white_wool
fill 510 271 249 511 271 249 minecraft:pink_wool
setblock 510 271 252 minecraft:white_wool
fill 510 271 253 511 271 253 minecraft:pink_wool
setblock 510 271 256 minecraft:white_wool
fill 510 271 257 511 271 257 minecraft:pink_wool
setblock 510 271 260 minecraft:white_wool
fill 510 271 261 511 271 261 minecraft:pink_wool
setblock 510 271 264 minecraft:white_wool
setblock 510 271 265 minecraft:white_concrete
fill 510 271 266 511 272 266 minecraft:red_concrete
setblock 511 271 229 minecraft:pink_wool
setblock 511 271 233 minecraft:pink_wool
setblock 511 271 235 minecraft:white_wool
fill 511 271 236 511 271 238 minecraft:pink_wool
setblock 511 271 239 minecraft:white_wool
fill 511 271 240 511 271 242 minecraft:pink_wool
setblock 511 271 243 minecraft:white_wool
fill 511 271 244 511 271 246 minecraft:pink_wool
setblock 511 271 247 minecraft:white_wool
setblock 511 271 248 minecraft:pink_wool
setblock 511 271 251 minecraft:white_wool
setblock 511 271 252 minecraft:pink_wool
setblock 511 271 255 minecraft:white_wool
setblock 511 271 256 minecraft:pink_wool
setblock 511 271 259 minecraft:white_wool
setblock 511 271 260 minecraft:pink_wool
setblock 511 271 263 minecraft:white_wool
fill 511 271 264 511 271 265 minecraft:pink_wool
setblock 511 271 269 minecraft:pink_wool
fill 473 272 229 473 272 230 minecraft:red_concrete
fill 473 272 232 473 272 233 minecraft:white_concrete
fill 473 272 265 473 272 266 minecraft:red_concrete
fill 473 272 268 473 272 269 minecraft:white_concrete
setblock 474 272 229 minecraft:red_concrete
fill 474 272 265 474 275 265 minecraft:red_concrete
fill 479 272 247 480 272 249 minecraft:pink_concrete
fill 479 272 251 485 272 253 minecraft:pink_concrete
fill 480 272 245 480 272 246 minecraft:pink_concrete
fill 480 272 257 484 272 257 minecraft:pink_concrete
fill 481 272 244 484 272 245 minecraft:pink_concrete
fill 481 272 249 487 272 249 minecraft:pink_concrete
fill 481 272 258 484 273 258 minecraft:pink_concrete
fill 482 272 243 483 273 243 minecraft:pink_concrete
fill 482 272 259 483 273 259 minecraft:pink_concrete
fill 483 272 242 487 273 242 minecraft:pink_concrete
setblock 483 272 260 minecraft:pink_concrete
fill 484 272 241 488 272 241 minecraft:pink_concrete
fill 484 272 261 492 272 261 minecraft:pink_concrete
setblock 486 272 240 minecraft:orange_concrete
fill 486 272 262 492 272 262 minecraft:pink_concrete
fill 487 272 240 488 272 240 minecraft:pink_concrete
fill 488 272 259 492 273 260 minecraft:pink_concrete
setblock 490 272 247 minecraft:white_concrete
fill 494 272 249 501 272 252 minecraft:pink_concrete
fill 495 272 253 501 272 253 minecraft:pink_concrete
fill 495 272 258 495 273 261 minecraft:pink_concrete
fill 496 272 244 499 272 245 minecraft:pink_concrete
fill 496 272 258 499 273 258 minecraft:pink_concrete
fill 497 272 259 497 272 260 minecraft:pink_concrete
fill 498 272 243 498 273 243 minecraft:pink_concrete
fill 498 272 259 498 273 259 minecraft:pink_concrete
fill 499 272 256 500 273 256 minecraft:pink_concrete
setblock 500 272 245 minecraft:pink_concrete
fill 509 272 229 509 272 230 minecraft:red_concrete
fill 509 272 232 509 272 233 minecraft:white_concrete
fill 509 272 265 509 272 266 minecraft:red_concrete
fill 509 272 268 509 272 269 minecraft:white_concrete
setblock 510 272 229 minecraft:red_concrete
setblock 510 272 265 minecraft:red_concrete
fill 471 273 229 473 273 269 minecraft:black_concrete
fill 474 273 229 474 273 231 minecraft:black_concrete
fill 474 273 232 474 277 233 minecraft:white_concrete
fill 474 273 267 511 273 269 minecraft:black_concrete
fill 475 273 230 511 273 231 minecraft:black_concrete
setblock 475 273 232 minecraft:red_concrete
fill 476 273 229 511 273 229 minecraft:black_concrete
fill 479 273 248 480 273 249 minecraft:pink_concrete
fill 479 273 251 485 273 251 minecraft:pink_concrete
setblock 479 273 252 minecraft:orange_concrete
fill 479 273 253 481 273 254 minecraft:pink_concrete
fill 480 273 246 480 273 247 minecraft:pink_concrete
fill 480 273 252 486 273 252 minecraft:pink_concrete
setblock 480 273 255 minecraft:red_concrete
setblock 481 273 239 minecraft:light[level=15]
fill 481 273 244 481 273 245 minecraft:pink_concrete
fill 481 273 249 485 273 249 minecraft:pink_concrete
fill 481 273 255 481 274 255 minecraft:pink_concrete
fill 481 273 257 484 273 257 minecraft:pink_concrete
setblock 481 273 263 minecraft:light[level=15]
setblock 482 273 244 minecraft:yellow_concrete
fill 482 273 245 484 274 245 minecraft:pink_concrete
fill 482 273 253 486 273 253 minecraft:pink_concrete
fill 483 273 244 484 274 244 minecraft:pink_concrete
setblock 483 273 260 minecraft:magenta_concrete
fill 484 273 259 487 274 259 minecraft:pink_concrete
setblock 484 273 260 minecraft:light_blue_concrete
fill 485 273 241 494 273 241 minecraft:pink_concrete
fill 485 273 260 487 273 261 minecraft:pink_concrete
setblock 486 273 249 minecraft:orange_concrete
setblock 487 273 240 minecraft:orange_concrete
setblock 487 273 262 minecraft:red_concrete
setblock 488 273 240 minecraft:pink_concrete
fill 488 273 261 489 273 262 minecraft:pink_concrete
setblock 489 273 239 minecraft:light[level=15]
setblock 489 273 240 minecraft:lime_concrete
fill 489 273 242 491 273 246 minecraft:pink_concrete
setblock 489 273 255 minecraft:light_blue_concrete
fill 489 273 256 492 273 258 minecraft:pink_concrete
setblock 489 273 263 minecraft:light[level=15]
fill 490 273 240 493 273 240 minecraft:pink_concrete
fill 490 273 261 492 273 261 minecraft:pink_concrete
setblock 490 273 262 minecraft:yellow_concrete
setblock 491 273 247 minecraft:pink_concrete
fill 491 273 255 492 273 255 minecraft:pink_concrete
fill 491 273 262 492 273 262 minecraft:pink_concrete
setblock 492 273 247 minecraft:white_concrete
fill 493 273 247 493 274 247 minecraft:pink_concrete
setblock 493 273 248 minecraft:white_concrete
fill 493 273 254 494 273 254 minecraft:pink_concrete
fill 494 273 249 501 273 249 minecraft:pink_concrete
setblock 494 273 250 minecraft:yellow_concrete
fill 494 273 252 501 273 252 minecraft:pink_concrete
setblock 494 273 253 minecraft:lime_concrete
fill 494 273 257 494 273 261 minecraft:pink_concrete
fill 495 273 250 501 273 251 minecraft:pink_concrete
fill 495 273 253 500 274 253 minecraft:pink_concrete
fill 495 273 257 499 273 257 minecraft:pink_concrete
setblock 496 273 242 minecraft:light_blue_concrete
fill 496 273 243 496 273 245 minecraft:pink_concrete
fill 496 273 248 500 274 248 minecraft:pink_concrete
fill 496 273 259 496 274 259 minecraft:pink_concrete
setblock 496 273 260 minecraft:light_blue_concrete
setblock 497 273 239 minecraft:light[level=15]
setblock 497 273 242 minecraft:pink_concrete
setblock 497 273 243 minecraft:light_blue_concrete
fill 497 273 244 498 273 245 minecraft:pink_concrete
setblock 497 273 259 minecraft:light_blue_concrete
setblock 497 273 260 minecraft:pink_concrete
setblock 497 273 263 minecraft:light[level=15]
fill 498 273 247 500 273 247 minecraft:pink_concrete
setblock 499 273 244 minecraft:red_concrete
setblock 499 273 245 minecraft:pink_concrete
fill 499 273 255 499 274 255 minecraft:pink_concrete
setblock 500 273 255 minecraft:magenta_concrete
setblock 501 273 248 minecraft:magenta_concrete
setblock 501 273 253 minecraft:lime_concrete
setblock 505 273 239 minecraft:light[level=15]
setblock 505 273 247 minecraft:light[level=15]
setblock 505 273 255 minecraft:light[level=15]
setblock 505 273 263 minecraft:light[level=15]
fill 507 273 232 507 275 232 minecraft:white_concrete
fill 508 273 265 508 277 265 minecraft:red_concrete
setblock 508 273 266 minecraft:white_concrete
fill 509 273 232 511 273 266 minecraft:black_concrete
fill 471 274 229 473 274 269 minecraft:gray_concrete
fill 474 274 229 474 274 231 minecraft:gray_concrete
fill 474 274 267 511 274 269 minecraft:gray_concrete
fill 475 274 230 511 274 231 minecraft:gray_concrete
fill 475 274 232 475 278 232 minecraft:white_concrete
fill 476 274 229 511 274 229 minecraft:gray_concrete
setblock 480 274 238 minecraft:light[level=12]
setblock 480 274 245 minecraft:light[level=12]
setblock 480 274 248 minecraft:light_blue_concrete
fill 480 274 249 481 274 252 minecraft:pink_concrete
fill 480 274 253 480 274 254 minecraft:orange_concrete
setblock 480 274 259 minecraft:light[level=12]
setblock 480 274 266 minecraft:light[level=12]
fill 481 274 253 482 274 253 minecraft:pink_concrete
setblock 481 274 254 minecraft:orange_concrete
fill 481 274 256 482 274 256 minecraft:pink_concrete
fill 482 274 249 482 274 251 minecraft:pink_concrete
setblock 482 274 252 minecraft:magenta_concrete
fill 482 274 254 482 274 255 minecraft:pink_concrete
setblock 482 274 257 minecraft:pink_concrete
fill 483 274 247 484 274 247 minecraft:pink_concrete
setblock 483 274 248 minecraft:red_concrete
setblock 483 274 249 minecraft:orange_concrete
fill 483 274 250 484 274 252 minecraft:pink_concrete
setblock 483 274 253 minecraft:light_blue_concrete
setblock 483 274 254 minecraft:orange_concrete
setblock 483 274 255 minecraft:white_concrete
setblock 483 274 256 minecraft:magenta_concrete
setblock 483 274 257 minecraft:red_concrete
fill 483 274 258 484 274 258 minecraft:pink_concrete
fill 484 274 243 485 274 243 minecraft:pink_concrete
fill 484 274 248 484 274 249 minecraft:pink_concrete
fill 484 274 253 484 274 256 minecraft:pink_concrete
setblock 484 274 257 minecraft:orange_concrete
fill 485 274 242 487 274 242 minecraft:pink_concrete
setblock 485 274 244 minecraft:pink_concrete
setblock 485 274 245 minecraft:magenta_concrete
setblock 485 274 247 minecraft:light_blue_concrete
fill 485 274 248 486 274 248 minecraft:pink_concrete
setblock 485 274 249 minecraft:magenta_concrete
setblock 485 274 250 minecraft:pink_concrete
setblock 485 274 251 minecraft:red_concrete
fill 485 274 252 485 274 255 minecraft:pink_concrete
setblock 485 274 256 minecraft:magenta_concrete
fill 485 274 260 487 274 260 minecraft:pink_concrete
fill 486 274 243 486 274 244 minecraft:lime_concrete
fill 486 274 245 486 274 246 minecraft:pink_concrete
setblock 486 274 247 minecraft:orange_concrete
fill 486 274 254 486 274 256 minecraft:pink_concrete
setblock 486 274 257 minecraft:magenta_concrete
setblock 487 274 238 minecraft:light[level=12]
fill 487 274 241 493 274 241 minecraft:pink_concrete
fill 487 274 243 487 274 245 minecraft:pink_concrete
setblock 487 274 246 minecraft:orange_concrete
setblock 487 274 247 minecraft:pink_concrete
setblock 487 274 252 minecraft:light[level=12]
setblock 487 274 255 minecraft:light_blue_concrete
fill 487 274 256 488 274 257 minecraft:pink_concrete
fill 487 274 261 489 274 261 minecraft:pink_concrete
setblock 487 274 266 minecraft:light[level=12]
setblock 488 274 243 minecraft:orange_concrete
fill 488 274 244 489 274 246 minecraft:pink_concrete
fill 488 274 259 491 274 259 minecraft:pink_concrete
setblock 488 274 260 minecraft:red_concrete
fill 489 274 242 491 274 243 minecraft:pink_concrete
fill 489 274 256 494 274 256 minecraft:pink_concrete
setblock 489 274 257 minecraft:lime_concrete
fill 489 274 258 490 274 258 minecraft:pink_concrete
fill 489 274 260 495 274 260 minecraft:pink_concrete
setblock 490 274 244 minecraft:white_concrete
fill 490 274 245 491 274 246 minecraft:pink_concrete
setblock 490 274 257 minecraft:red_concrete
setblock 490 274 261 minecraft:magenta_concrete
setblock 491 274 244 minecraft:orange_concrete
fill 491 274 257 498 274 257 minecraft:pink_concrete
setblock 491 274 258 minecraft:lime_concrete
setblock 491 274 261 minecraft:pink_concrete
fill 492 274 258 493 274 258 minecraft:pink_concrete
setblock 492 274 259 minecraft:magenta_concrete
setblock 492 274 261 minecraft:red_concrete
setblock 493 274 255 minecraft:pink_concrete
setblock 493 274 259 minecraft:pink_concrete
setblock 493 274 261 minecraft:pink_concrete
setblock 494 274 238 minecraft:light[level=12]
fill 494 274 247 494 274 248 minecraft:pink_concrete
setblock 494 274 252 minecraft:light[level=12]
setblock 494 274 254 minecraft:pink_concrete
setblock 494 274 255 minecraft:light_blue_concrete
fill 494 274 258 494 274 259 minecraft:red_concrete
setblock 494 274 266 minecraft:light[level=12]
setblock 495 274 246 minecraft:lime_concrete
setblock 495 274 247 minecraft:pink_concrete
setblock 495 274 248 minecraft:orange_concrete
setblock 495 274 249 minecraft:yellow_concrete
fill 495 274 250 496 274 250 minecraft:pink_concrete
setblock 495 274 251 minecraft:yellow_concrete
fill 495 274 252 500 274 252 minecraft:pink_concrete
setblock 495 274 254 minecraft:light_blue_concrete
fill 495 274 255 496 274 255 minecraft:pink_concrete
setblock 495 274 256 minecraft:red_concrete
fill 495 274 258 497 274 258 minecraft:pink_concrete
setblock 495 274 259 minecraft:red_concrete
setblock 496 274 243 minecraft:pink_concrete
fill 496 274 244 497 274 244 minecraft:white_concrete
fill 496 274 245 496 274 246 minecraft:pink_concrete
setblock 496 274 249 minecraft:white_concrete
setblock 496 274 251 minecraft:lime_concrete
setblock 496 274 254 minecraft:pink_concrete
fill 496 274 256 499 274 256 minecraft:pink_concrete
setblock 497 274 245 minecraft:white_concrete
fill 497 274 246 499 274 246 minecraft:pink_concrete
fill 497 274 249 498 274 249 minecraft:pink_concrete
setblock 497 274 250 minecraft:white_concrete
fill 497 274 251 500 274 251 minecraft:pink_concrete
setblock 497 274 254 minecraft:red_concrete
setblock 497 274 255 minecraft:white_concrete
setblock 498 274 245 minecraft:pink_concrete
setblock 498 274 247 minecraft:pink_concrete
setblock 498 274 250 minecraft:pink_concrete
fill 498 274 254 498 274 255 minecraft:pink_concrete
setblock 499 274 247 minecraft:lime_concrete
setblock 499 274 249 minecraft:lime_concrete
setblock 499 274 250 minecraft:red_concrete
fill 499 274 254 500 274 254 minecraft:pink_concrete
fill 500 274 249 500 274 250 minecraft:yellow_concrete
setblock 501 274 238 minecraft:light[level=12]
setblock 501 274 245 minecraft:light[level=12]
setblock 501 274 252 minecraft:light[level=12]
setblock 501 274 259 minecraft:light[level=12]
setblock 501 274 266 minecraft:light[level=12]
fill 507 274 266 508 277 266 minecraft:red_concrete
setblock 508 274 238 minecraft:light[level=12]
setblock 508 274 245 minecraft:light[level=12]
setblock 508 274 252 minecraft:light[level=12]
setblock 508 274 259 minecraft:light[level=12]
fill 509 274 232 511 274 266 minecraft:gray_concrete
fill 471 275 230 472 277 231 minecraft:red_concrete
fill 471 275 232 473 275 232 minecraft:white_concrete
fill 471 275 242 471 276 242 minecraft:brown_concrete
fill 471 275 266 472 277 267 minecraft:red_concrete
fill 471 275 268 475 275 268 minecraft:white_concrete
fill 472 275 229 474 275 229 minecraft:red_concrete
fill 472 275 233 473 276 233 minecraft:white_concrete
fill 472 275 251 472 276 251 minecraft:brown_concrete
fill 472 275 265 473 276 265 minecraft:red_concrete
fill 472 275 269 474 276 269 minecraft:white_concrete
fill 473 275 230 474 275 230 minecraft:red_concrete
fill 473 275 231 475 279 231 minecraft:white_concrete
setblock 473 275 251 minecraft:light_blue_concrete
fill 473 275 266 474 275 266 minecraft:red_concrete
fill 473 275 267 475 279 267 minecraft:white_concrete
fill 475 275 230 475 280 230 minecraft:white_concrete
fill 475 275 266 475 280 266 minecraft:white_concrete
setblock 483 275 231 minecraft:orange_concrete
fill 486 275 232 486 275 234 minecraft:yellow_concrete
fill 486 275 236 486 276 236 minecraft:yellow_concrete
setblock 487 275 229 minecraft:white_concrete
fill 487 275 233 487 275 234 minecraft:yellow_concrete
setblock 491 275 230 minecraft:light_blue_concrete
setblock 494 275 230 minecraft:yellow_concrete
fill 494 275 238 498 300 239 minecraft:white_concrete
fill 495 275 237 497 300 237 minecraft:white_concrete
fill 495 275 240 497 300 240 minecraft:white_concrete
fill 501 275 230 501 276 230 minecraft:brown_concrete
fill 505 275 229 505 276 229 minecraft:brown_concrete
fill 507 275 230 508 277 231 minecraft:red_concrete
fill 507 275 267 508 279 267 minecraft:red_concrete
fill 507 275 268 511 275 268 minecraft:white_concrete
fill 508 275 229 510 275 229 minecraft:red_concrete
fill 508 275 269 510 276 269 minecraft:white_concrete
fill 509 275 230 510 275 230 minecraft:red_concrete
fill 509 275 231 510 276 233 minecraft:white_concrete
fill 509 275 237 509 276 237 minecraft:brown_concrete
setblock 509 275 239 minecraft:magenta_concrete
setblock 509 275 243 minecraft:light_blue_concrete
fill 509 275 261 509 276 261 minecraft:brown_concrete
fill 509 275 265 510 275 266 minecraft:red_concrete
fill 509 275 267 511 279 267 minecraft:white_concrete
setblock 510 275 235 minecraft:light_blue_concrete
setblock 510 275 248 minecraft:yellow_concrete
fill 511 275 230 511 278 232 minecraft:white_concrete
setblock 511 275 251 minecraft:orange_concrete
fill 511 275 266 511 280 266 minecraft:white_concrete
fill 471 276 232 472 279 232 minecraft:red_concrete
fill 471 276 268 472 279 268 minecraft:red_concrete
fill 472 276 229 473 276 229 minecraft:red_concrete
setblock 473 276 230 minecraft:red_concrete
setblock 473 276 232 minecraft:white_concrete
setblock 473 276 266 minecraft:red_concrete
fill 473 276 268 475 276 268 minecraft:white_concrete
fill 474 276 229 474 280 230 minecraft:white_concrete
fill 474 276 265 474 280 266 minecraft:white_concrete
fill 493 276 238 493 277 239 minecraft:brown_terracotta
fill 494 276 237 494 277 237 minecraft:brown_terracotta
fill 494 276 240 494 277 240 minecraft:brown_terracotta
fill 495 276 236 498 277 236 minecraft:brown_terracotta
fill 495 276 241 498 277 241 minecraft:brown_terracotta
fill 498 276 237 499 277 237 minecraft:brown_terracotta
fill 498 276 240 499 277 240 minecraft:brown_terracotta
fill 499 276 238 499 277 239 minecraft:brown_terracotta
fill 507 276 232 508 279 232 minecraft:red_concrete
fill 507 276 268 508 279 268 minecraft:red_concrete
fill 508 276 229 509 276 229 minecraft:red_concrete
setblock 508 276 233 minecraft:white_concrete
setblock 509 276 230 minecraft:red_concrete
fill 509 276 265 509 276 266 minecraft:red_concrete
fill 509 276 268 511 276 268 minecraft:white_concrete
fill 510 276 229 510 280 230 minecraft:white_concrete
fill 510 276 265 510 280 266 minecraft:white_concrete
setblock 472 277 229 minecraft:red_concrete
fill 472 277 233 473 280 233 minecraft:red_concrete
setblock 472 277 265 minecraft:red_concrete
fill 472 277 269 473 280 269 minecraft:red_concrete
fill 473 277 229 473 281 230 minecraft:white_concrete
fill 473 277 232 473 281 232 minecraft:red_concrete
fill 473 277 265 473 281 266 minecraft:white_concrete
fill 473 277 268 473 281 268 minecraft:red_concrete
fill 474 277 268 474 277 269 minecraft:white_concrete
fill 475 277 268 475 278 268 minecraft:white_concrete
fill 492 277 238 492 277 239 minecraft:brown_terracotta
fill 493 277 236 493 277 237 minecraft:brown_terracotta
fill 493 277 240 493 277 241 minecraft:brown_terracotta
fill 494 277 235 494 277 236 minecraft:brown_terracotta
fill 494 277 241 494 277 242 minecraft:brown_terracotta
fill 495 277 235 498 277 235 minecraft:brown_terracotta
fill 495 277 242 498 277 242 minecraft:brown_terracotta
setblock 499 277 236 minecraft:brown_terracotta
setblock 499 277 241 minecraft:brown_terracotta
fill 500 277 237 500 277 240 minecraft:brown_terracotta
setblock 508 277 229 minecraft:red_concrete
fill 508 277 233 509 280 233 minecraft:red_concrete
fill 508 277 269 509 280 269 minecraft:red_concrete
fill 509 277 229 509 279 231 minecraft:white_concrete
fill 509 277 232 509 281 232 minecraft:red_concrete
fill 509 277 265 509 281 266 minecraft:white_concrete
fill 509 277 268 509 281 268 minecraft:red_concrete
fill 510 277 231 510 277 233 minecraft:white_concrete
fill 510 277 268 510 277 269 minecraft:white_concrete
fill 511 277 268 511 278 268 minecraft:white_concrete
fill 471 278 230 471 278 231 minecraft:red_concrete
fill 471 278 266 471 278 267 minecraft:red_concrete
fill 472 278 229 472 282 230 minecraft:white_concrete
fill 472 278 231 472 279 231 minecraft:red_concrete
fill 472 278 265 472 282 266 minecraft:white_concrete
fill 472 278 267 472 279 267 minecraft:red_concrete
setblock 474 278 232 minecraft:white_concrete
fill 474 278 233 474 282 233 minecraft:red_concrete
setblock 474 278 268 minecraft:white_concrete
fill 474 278 269 474 282 269 minecraft:red_concrete
fill 477 278 241 477 279 241 minecraft:light_blue_concrete
fill 492 278 264 494 279 264 minecraft:yellow_concrete
fill 493 278 263 494 279 263 minecraft:yellow_concrete
fill 507 278 230 507 278 231 minecraft:red_concrete
setblock 507 278 266 minecraft:red_concrete
fill 508 278 229 508 282 230 minecraft:white_concrete
fill 508 278 231 508 279 231 minecraft:red_concrete
fill 508 278 265 508 282 266 minecraft:white_concrete
fill 510 278 231 510 278 232 minecraft:white_concrete
fill 510 278 233 510 282 233 minecraft:red_concrete
setblock 510 278 268 minecraft:white_concrete
fill 510 278 269 510 282 269 minecraft:red_concrete
fill 471 279 230 471 283 230 minecraft:white_concrete
setblock 471 279 231 minecraft:red_concrete
fill 471 279 266 471 283 266 minecraft:white_concrete
setblock 471 279 267 minecraft:red_concrete
fill 474 279 232 475 282 232 minecraft:red_concrete
fill 474 279 268 475 282 268 minecraft:red_concrete
fill 500 279 250 500 280 250 minecraft:yellow_concrete
fill 507 279 230 507 283 230 minecraft:white_concrete
setblock 507 279 231 minecraft:red_concrete
fill 507 279 266 507 283 266 minecraft:white_concrete
fill 510 279 231 511 279 231 minecraft:white_concrete
fill 510 279 232 511 282 232 minecraft:red_concrete
fill 510 279 268 511 282 268 minecraft:red_concrete
fill 511 279 230 511 280 230 minecraft:white_concrete
fill 511 279 261 511 290 261 minecraft:brown_concrete
fill 471 280 231 471 284 232 minecraft:white_concrete
fill 471 280 267 471 284 268 minecraft:white_concrete
fill 472 280 231 472 284 231 minecraft:white_concrete
setblock 472 280 232 minecraft:red_concrete
fill 472 280 267 472 284 267 minecraft:white_concrete
setblock 472 280 268 minecraft:red_concrete
fill 473 280 231 475 284 231 minecraft:red_concrete
fill 473 280 234 477 293 234 minecraft:white_concrete
setblock 473 280 238 minecraft:light[level=12]
setblock 473 280 239 minecraft:light[level=15]
setblock 473 280 245 minecraft:light[level=12]
setblock 473 280 247 minecraft:light[level=15]
setblock 473 280 252 minecraft:light[level=12]
setblock 473 280 255 minecraft:light[level=15]
schedule function dropper:buildpart/58_4 1t
