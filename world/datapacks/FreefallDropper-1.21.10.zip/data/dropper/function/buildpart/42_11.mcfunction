setblock 321 268 198 minecraft:polished_blackstone
fill 321 268 199 321 270 199 minecraft:red_nether_bricks
setblock 321 268 203 minecraft:polished_blackstone
fill 321 268 204 321 270 204 minecraft:red_nether_bricks
setblock 322 268 182 minecraft:polished_blackstone
fill 322 268 183 322 270 184 minecraft:red_nether_bricks
setblock 322 268 192 minecraft:polished_blackstone
fill 322 268 193 322 270 193 minecraft:red_nether_bricks
setblock 322 268 197 minecraft:polished_blackstone
fill 322 268 198 322 270 198 minecraft:red_nether_bricks
setblock 322 268 202 minecraft:polished_blackstone
fill 322 268 203 322 270 203 minecraft:red_nether_bricks
setblock 322 268 222 minecraft:polished_blackstone
fill 323 268 182 323 270 182 minecraft:red_nether_bricks
setblock 323 268 186 minecraft:polished_blackstone
fill 323 268 187 323 270 187 minecraft:red_nether_bricks
setblock 323 268 191 minecraft:polished_blackstone
fill 323 268 192 323 270 192 minecraft:red_nether_bricks
setblock 323 268 196 minecraft:polished_blackstone
fill 323 268 197 323 270 197 minecraft:red_nether_bricks
setblock 323 268 201 minecraft:polished_blackstone
fill 323 268 202 323 270 202 minecraft:red_nether_bricks
setblock 323 268 206 minecraft:polished_blackstone
fill 323 268 207 323 270 207 minecraft:red_nether_bricks
fill 323 268 209 323 269 209 minecraft:red_nether_bricks
fill 323 268 217 323 269 217 minecraft:red_nether_bricks
setblock 323 268 221 minecraft:polished_blackstone
fill 323 268 222 323 270 222 minecraft:red_nether_bricks
setblock 283 269 185 minecraft:polished_blackstone
fill 283 269 186 283 270 186 minecraft:red_nether_bricks
setblock 283 269 190 minecraft:polished_blackstone
fill 283 269 191 283 270 191 minecraft:red_nether_bricks
setblock 283 269 195 minecraft:polished_blackstone
fill 283 269 196 283 270 196 minecraft:red_nether_bricks
setblock 283 269 200 minecraft:polished_blackstone
fill 283 269 201 283 270 201 minecraft:red_nether_bricks
setblock 283 269 205 minecraft:polished_blackstone
fill 283 269 206 283 270 207 minecraft:red_nether_bricks
fill 283 269 217 283 269 219 minecraft:red_nether_bricks
setblock 283 269 220 minecraft:polished_blackstone
fill 283 269 221 283 270 221 minecraft:red_nether_bricks
setblock 284 269 184 minecraft:polished_blackstone
fill 284 269 185 284 270 185 minecraft:red_nether_bricks
setblock 284 269 189 minecraft:polished_blackstone
setblock 284 269 194 minecraft:polished_blackstone
setblock 284 269 195 minecraft:red_nether_bricks
setblock 284 269 199 minecraft:polished_blackstone
fill 284 269 200 284 270 200 minecraft:red_nether_bricks
setblock 284 269 219 minecraft:polished_blackstone
fill 284 269 220 284 270 220 minecraft:red_nether_bricks
setblock 285 269 183 minecraft:polished_blackstone
fill 285 269 184 285 270 184 minecraft:red_nether_bricks
setblock 286 269 182 minecraft:polished_blackstone
fill 286 269 183 286 270 183 minecraft:red_nether_bricks
setblock 286 269 222 minecraft:polished_blackstone
fill 287 269 182 287 270 182 minecraft:red_nether_bricks
setblock 287 269 221 minecraft:polished_blackstone
fill 287 269 222 290 269 222 minecraft:red_nether_bricks
fill 288 269 221 288 270 221 minecraft:red_nether_bricks
setblock 291 269 182 minecraft:polished_blackstone
setblock 291 269 222 minecraft:polished_blackstone
fill 292 269 182 292 270 182 minecraft:red_nether_bricks
fill 292 269 222 292 270 222 minecraft:red_nether_bricks
setblock 296 269 182 minecraft:polished_blackstone
setblock 296 269 222 minecraft:polished_blackstone
fill 297 269 182 297 270 182 minecraft:red_nether_bricks
setblock 297 269 221 minecraft:polished_blackstone
fill 297 269 222 297 270 222 minecraft:red_nether_bricks
setblock 298 269 220 minecraft:polished_blackstone
fill 298 269 221 298 270 221 minecraft:red_nether_bricks
setblock 299 269 183 minecraft:red_nether_bricks
fill 299 269 220 299 270 220 minecraft:red_nether_bricks
setblock 300 269 183 minecraft:polished_blackstone
setblock 301 269 182 minecraft:polished_blackstone
fill 301 269 183 303 270 183 minecraft:red_nether_bricks
setblock 301 269 222 minecraft:polished_blackstone
fill 302 269 182 302 270 182 minecraft:red_nether_bricks
setblock 302 269 221 minecraft:polished_blackstone
fill 302 269 222 302 270 222 minecraft:red_nether_bricks
setblock 303 269 220 minecraft:polished_blackstone
fill 303 269 221 303 270 221 minecraft:red_nether_bricks
fill 304 269 220 304 270 220 minecraft:red_nether_bricks
setblock 306 269 182 minecraft:polished_blackstone
setblock 306 269 222 minecraft:polished_blackstone
fill 307 269 182 307 270 182 minecraft:red_nether_bricks
setblock 307 269 221 minecraft:polished_blackstone
fill 307 269 222 307 270 222 minecraft:red_nether_bricks
setblock 308 269 221 minecraft:red_nether_bricks
fill 318 269 182 318 270 182 minecraft:red_nether_bricks
fill 318 269 222 318 270 222 minecraft:red_nether_bricks
setblock 321 269 182 minecraft:polished_blackstone
fill 321 269 183 321 270 183 minecraft:red_nether_bricks
setblock 321 269 197 minecraft:polished_blackstone
fill 321 269 198 321 270 198 minecraft:red_nether_bricks
setblock 321 269 202 minecraft:polished_blackstone
fill 321 269 203 321 270 203 minecraft:red_nether_bricks
setblock 321 269 222 minecraft:polished_blackstone
fill 322 269 182 322 270 182 minecraft:red_nether_bricks
setblock 322 269 185 minecraft:red_nether_bricks
setblock 322 269 186 minecraft:polished_blackstone
fill 322 269 187 322 270 187 minecraft:red_nether_bricks
setblock 322 269 191 minecraft:polished_blackstone
fill 322 269 192 322 270 192 minecraft:red_nether_bricks
setblock 322 269 196 minecraft:polished_blackstone
fill 322 269 197 322 270 197 minecraft:red_nether_bricks
setblock 322 269 201 minecraft:polished_blackstone
fill 322 269 202 322 270 202 minecraft:red_nether_bricks
setblock 322 269 206 minecraft:polished_blackstone
fill 322 269 207 322 270 207 minecraft:red_nether_bricks
setblock 322 269 221 minecraft:polished_blackstone
fill 322 269 222 322 270 222 minecraft:red_nether_bricks
setblock 323 269 185 minecraft:polished_blackstone
fill 323 269 186 323 270 186 minecraft:red_nether_bricks
setblock 323 269 190 minecraft:polished_blackstone
fill 323 269 191 323 270 191 minecraft:red_nether_bricks
setblock 323 269 195 minecraft:polished_blackstone
fill 323 269 196 323 270 196 minecraft:red_nether_bricks
setblock 323 269 200 minecraft:polished_blackstone
fill 323 269 201 323 270 201 minecraft:red_nether_bricks
setblock 323 269 205 minecraft:polished_blackstone
fill 323 269 206 323 270 206 minecraft:red_nether_bricks
setblock 323 269 220 minecraft:polished_blackstone
fill 323 269 221 323 270 221 minecraft:red_nether_bricks
setblock 283 270 184 minecraft:polished_blackstone
setblock 283 270 185 minecraft:red_nether_bricks
setblock 283 270 189 minecraft:polished_blackstone
setblock 283 270 190 minecraft:red_nether_bricks
setblock 283 270 194 minecraft:polished_blackstone
setblock 283 270 195 minecraft:red_nether_bricks
setblock 283 270 199 minecraft:polished_blackstone
setblock 283 270 200 minecraft:red_nether_bricks
setblock 283 270 204 minecraft:polished_blackstone
setblock 283 270 205 minecraft:red_nether_bricks
fill 283 270 217 283 270 218 minecraft:red_nether_bricks
setblock 283 270 219 minecraft:polished_blackstone
setblock 283 270 220 minecraft:red_nether_bricks
setblock 284 270 183 minecraft:polished_blackstone
setblock 284 270 184 minecraft:red_nether_bricks
setblock 284 270 188 minecraft:polished_blackstone
setblock 284 270 189 minecraft:red_nether_bricks
setblock 284 270 198 minecraft:polished_blackstone
setblock 284 270 199 minecraft:red_nether_bricks
setblock 284 270 203 minecraft:polished_blackstone
setblock 284 270 204 minecraft:red_nether_bricks
setblock 284 270 219 minecraft:red_nether_bricks
setblock 285 270 182 minecraft:polished_blackstone
setblock 285 270 183 minecraft:red_nether_bricks
setblock 285 270 185 minecraft:red_nether_bricks
setblock 285 270 222 minecraft:polished_blackstone
setblock 286 270 182 minecraft:red_nether_bricks
setblock 286 270 184 minecraft:red_nether_bricks
setblock 286 270 221 minecraft:polished_blackstone
fill 286 270 222 289 270 222 minecraft:red_nether_bricks
setblock 287 270 221 minecraft:red_nether_bricks
setblock 289 270 183 minecraft:polished_blackstone
setblock 290 270 182 minecraft:polished_blackstone
setblock 290 270 183 minecraft:red_nether_bricks
setblock 290 270 222 minecraft:polished_blackstone
setblock 291 270 182 minecraft:red_nether_bricks
setblock 291 270 222 minecraft:red_nether_bricks
setblock 293 270 221 minecraft:red_nether_bricks
setblock 295 270 182 minecraft:polished_blackstone
setblock 295 270 222 minecraft:polished_blackstone
setblock 296 270 182 minecraft:red_nether_bricks
setblock 296 270 221 minecraft:polished_blackstone
setblock 296 270 222 minecraft:red_nether_bricks
fill 297 270 183 298 270 183 minecraft:red_nether_bricks
setblock 297 270 221 minecraft:red_nether_bricks
setblock 298 270 220 minecraft:red_nether_bricks
setblock 299 270 183 minecraft:polished_blackstone
setblock 300 270 182 minecraft:polished_blackstone
setblock 300 270 183 minecraft:red_nether_bricks
setblock 300 270 222 minecraft:polished_blackstone
setblock 301 270 182 minecraft:red_nether_bricks
setblock 301 270 221 minecraft:polished_blackstone
setblock 301 270 222 minecraft:red_nether_bricks
setblock 302 270 220 minecraft:polished_blackstone
setblock 302 270 221 minecraft:red_nether_bricks
setblock 303 270 220 minecraft:red_nether_bricks
setblock 304 270 183 minecraft:polished_blackstone
setblock 305 270 182 minecraft:polished_blackstone
setblock 305 270 222 minecraft:polished_blackstone
setblock 306 270 182 minecraft:red_nether_bricks
setblock 306 270 221 minecraft:polished_blackstone
setblock 306 270 222 minecraft:red_nether_bricks
setblock 307 270 221 minecraft:red_nether_bricks
setblock 310 270 222 minecraft:polished_blackstone
setblock 317 270 182 minecraft:red_nether_bricks
setblock 317 270 222 minecraft:red_nether_bricks
setblock 319 270 183 minecraft:polished_blackstone
setblock 320 270 182 minecraft:polished_blackstone
setblock 320 270 183 minecraft:red_nether_bricks
fill 320 270 200 320 270 201 minecraft:red_nether_bricks
setblock 320 270 202 minecraft:polished_blackstone
setblock 320 270 222 minecraft:polished_blackstone
setblock 321 270 182 minecraft:red_nether_bricks
setblock 321 270 196 minecraft:polished_blackstone
setblock 321 270 197 minecraft:red_nether_bricks
setblock 321 270 201 minecraft:polished_blackstone
setblock 321 270 202 minecraft:red_nether_bricks
setblock 321 270 205 minecraft:red_nether_bricks
setblock 321 270 221 minecraft:polished_blackstone
setblock 321 270 222 minecraft:red_nether_bricks
setblock 322 270 185 minecraft:polished_blackstone
setblock 322 270 186 minecraft:red_nether_bricks
fill 322 270 188 322 270 189 minecraft:red_nether_bricks
setblock 322 270 190 minecraft:polished_blackstone
setblock 322 270 191 minecraft:red_nether_bricks
setblock 322 270 195 minecraft:polished_blackstone
setblock 322 270 196 minecraft:red_nether_bricks
setblock 322 270 200 minecraft:polished_blackstone
setblock 322 270 201 minecraft:red_nether_bricks
setblock 322 270 205 minecraft:polished_blackstone
setblock 322 270 206 minecraft:red_nether_bricks
setblock 322 270 221 minecraft:red_nether_bricks
setblock 323 270 184 minecraft:polished_blackstone
setblock 323 270 185 minecraft:red_nether_bricks
setblock 323 270 189 minecraft:polished_blackstone
setblock 323 270 190 minecraft:red_nether_bricks
setblock 323 270 194 minecraft:polished_blackstone
setblock 323 270 195 minecraft:red_nether_bricks
setblock 323 270 199 minecraft:polished_blackstone
setblock 323 270 200 minecraft:red_nether_bricks
setblock 323 270 204 minecraft:polished_blackstone
setblock 323 270 205 minecraft:red_nether_bricks
setblock 323 270 209 minecraft:polished_blackstone
setblock 323 270 210 minecraft:red_nether_bricks
setblock 323 270 219 minecraft:polished_blackstone
setblock 323 270 220 minecraft:red_nether_bricks
fill 283 276 202 297 278 202 minecraft:blackstone
fill 284 276 197 298 278 201 minecraft:blackstone
fill 284 276 203 298 278 207 minecraft:blackstone
setblock 285 276 184 minecraft:light[level=14]
setblock 285 276 192 minecraft:light[level=14]
fill 285 276 194 317 278 196 minecraft:blackstone
fill 285 276 208 317 278 210 minecraft:blackstone
setblock 285 276 216 minecraft:light[level=14]
fill 286 276 193 316 278 193 minecraft:blackstone
fill 286 276 211 316 278 211 minecraft:blackstone
fill 287 276 191 315 278 192 minecraft:blackstone
fill 287 276 212 315 278 213 minecraft:blackstone
fill 288 276 190 314 278 190 minecraft:blackstone
fill 288 276 214 314 278 214 minecraft:blackstone
fill 289 276 189 313 278 189 minecraft:blackstone
fill 289 276 215 313 278 215 minecraft:blackstone
fill 290 276 188 312 278 188 minecraft:blackstone
fill 290 276 216 312 278 216 minecraft:blackstone
fill 292 276 187 310 278 187 minecraft:blackstone
fill 292 276 217 310 278 217 minecraft:blackstone
setblock 293 276 184 minecraft:light[level=14]
fill 293 276 186 309 278 186 minecraft:blackstone
fill 293 276 218 309 278 218 minecraft:blackstone
fill 296 276 185 306 278 185 minecraft:blackstone
fill 296 276 219 306 278 219 minecraft:blackstone
fill 299 276 197 300 278 199 minecraft:blackstone
fill 299 276 205 300 278 207 minecraft:blackstone
fill 301 276 184 301 285 184 minecraft:blackstone
fill 301 276 197 318 278 198 minecraft:blackstone
fill 301 276 206 318 278 207 minecraft:blackstone
fill 301 276 220 301 285 220 minecraft:blackstone
fill 302 276 199 318 278 199 minecraft:blackstone
fill 302 276 205 318 278 205 minecraft:blackstone
fill 304 276 200 318 278 201 minecraft:blackstone
fill 304 276 203 318 278 204 minecraft:blackstone
fill 305 276 202 319 278 202 minecraft:blackstone
setblock 309 276 184 minecraft:light[level=14]
setblock 317 276 184 minecraft:light[level=14]
setblock 317 276 192 minecraft:light[level=14]
setblock 317 276 216 minecraft:light[level=14]
fill 283 279 182 283 279 222 minecraft:blackstone
fill 284 279 182 286 279 198 minecraft:blackstone
fill 284 279 199 285 285 199 minecraft:shroomlight
fill 284 279 200 284 279 222 minecraft:blackstone
fill 285 279 200 285 285 205 minecraft:blackstone
fill 285 279 206 285 285 206 minecraft:shroomlight
fill 285 279 207 287 279 222 minecraft:blackstone
fill 286 279 199 286 285 204 minecraft:blackstone
fill 286 279 205 286 285 205 minecraft:shroomlight
fill 286 279 206 291 283 206 minecraft:blackstone
fill 287 279 182 291 279 191 minecraft:blackstone
fill 287 279 192 288 285 192 minecraft:shroomlight
fill 287 279 193 291 283 197 minecraft:blackstone
fill 287 279 198 288 284 198 minecraft:shroomlight
fill 287 279 199 288 284 203 minecraft:blackstone
fill 287 279 204 287 284 204 minecraft:shroomlight
fill 287 279 205 292 282 205 minecraft:blackstone
fill 288 279 204 296 280 204 minecraft:blackstone
fill 288 279 207 288 284 213 minecraft:blackstone
fill 288 279 214 288 285 214 minecraft:shroomlight
fill 288 279 215 293 279 222 minecraft:blackstone
fill 289 279 192 298 282 192 minecraft:blackstone
fill 289 279 198 293 281 202 minecraft:blackstone
fill 289 279 203 289 283 203 minecraft:shroomlight
fill 289 279 207 289 284 210 minecraft:blackstone
fill 289 279 211 289 285 211 minecraft:shroomlight
fill 289 279 212 293 284 214 minecraft:blackstone
fill 290 279 203 296 280 203 minecraft:blackstone
fill 290 279 207 290 283 208 minecraft:blackstone
fill 290 279 209 290 284 209 minecraft:shroomlight
fill 290 279 210 301 281 211 minecraft:blackstone
fill 291 279 207 291 283 207 minecraft:shroomlight
fill 291 279 208 323 279 209 minecraft:blackstone
fill 292 279 182 299 279 186 minecraft:blackstone
fill 292 279 187 293 285 187 minecraft:shroomlight
fill 292 279 188 295 283 191 minecraft:blackstone
fill 292 279 193 293 283 193 minecraft:shroomlight
fill 292 279 194 294 282 197 minecraft:blackstone
fill 292 279 206 292 282 206 minecraft:shroomlight
fill 292 279 207 300 280 207 minecraft:blackstone
fill 293 279 205 293 282 205 minecraft:shroomlight
fill 293 279 206 298 280 206 minecraft:blackstone
fill 294 279 187 323 279 187 minecraft:blackstone
fill 294 279 193 312 282 193 minecraft:blackstone
fill 294 279 198 294 281 200 minecraft:blackstone
fill 294 279 201 294 281 201 minecraft:shroomlight
fill 294 279 202 296 280 202 minecraft:blackstone
fill 294 279 205 297 280 205 minecraft:blackstone
fill 294 279 212 294 283 216 minecraft:shroomlight
fill 294 279 217 300 279 222 minecraft:blackstone
fill 295 279 194 295 282 194 minecraft:shroomlight
fill 295 279 195 300 280 197 minecraft:blackstone
fill 295 279 198 295 281 198 minecraft:shroomlight
fill 295 279 199 296 280 201 minecraft:blackstone
fill 295 279 212 298 282 216 minecraft:blackstone
fill 296 279 188 301 284 188 minecraft:blackstone
fill 296 279 189 296 284 189 minecraft:shroomlight
fill 296 279 190 296 283 191 minecraft:blackstone
fill 296 279 194 299 281 194 minecraft:blackstone
fill 296 279 198 298 280 198 minecraft:blackstone
fill 297 279 189 307 284 189 minecraft:blackstone
fill 297 279 190 297 283 190 minecraft:shroomlight
fill 297 279 191 297 283 191 minecraft:blackstone
fill 297 279 199 297 280 199 minecraft:blackstone
fill 297 279 200 297 280 200 minecraft:magma_block
fill 297 279 201 297 279 203 minecraft:shroomlight
fill 297 279 204 297 280 204 minecraft:magma_block
fill 298 279 190 302 283 190 minecraft:blackstone
fill 298 279 191 298 283 191 minecraft:shroomlight
fill 298 279 199 298 279 201 minecraft:shroomlight
fill 298 279 203 298 279 205 minecraft:shroomlight
fill 299 279 191 302 283 191 minecraft:blackstone
fill 299 279 192 299 282 192 minecraft:shroomlight
fill 299 279 198 299 280 198 minecraft:magma_block
fill 299 279 199 300 279 199 minecraft:shroomlight
fill 299 279 205 300 279 205 minecraft:shroomlight
fill 299 279 206 299 280 206 minecraft:magma_block
fill 299 279 212 302 282 212 minecraft:blackstone
fill 299 279 213 299 283 214 minecraft:shroomlight
fill 299 279 215 299 284 216 minecraft:blackstone
fill 300 279 182 300 279 184 minecraft:blackstone
fill 300 279 185 300 285 185 minecraft:shroomlight
fill 300 279 186 300 285 186 minecraft:blackstone
fill 300 279 192 307 282 192 minecraft:blackstone
fill 300 279 194 300 281 194 minecraft:shroomlight
fill 300 279 198 302 279 198 minecraft:shroomlight
fill 300 279 206 302 279 206 minecraft:shroomlight
fill 300 279 213 303 283 215 minecraft:blackstone
fill 300 279 216 300 284 216 minecraft:shroomlight
fill 301 279 182 323 279 183 minecraft:blackstone
fill 301 279 185 323 279 185 minecraft:blackstone
fill 301 279 186 301 285 186 minecraft:shroomlight
fill 301 279 194 311 280 196 minecraft:blackstone
fill 301 279 197 301 280 197 minecraft:shroomlight
fill 301 279 207 301 280 207 minecraft:shroomlight
fill 301 279 216 308 284 217 minecraft:blackstone
fill 301 279 218 301 285 218 minecraft:shroomlight
fill 301 279 219 301 285 219 minecraft:blackstone
fill 301 279 221 323 279 222 minecraft:blackstone
fill 302 279 184 323 279 184 minecraft:blackstone
fill 302 279 186 323 279 186 minecraft:blackstone
fill 302 279 188 302 284 188 minecraft:shroomlight
fill 302 279 197 310 280 197 minecraft:blackstone
fill 302 279 199 304 279 199 minecraft:shroomlight
fill 302 279 205 304 279 205 minecraft:shroomlight
fill 302 279 207 323 279 207 minecraft:blackstone
fill 302 279 210 302 281 210 minecraft:shroomlight
fill 302 279 211 308 282 211 minecraft:blackstone
fill 302 279 218 323 279 218 minecraft:blackstone
fill 302 279 219 302 285 219 minecraft:shroomlight
fill 302 279 220 323 279 220 minecraft:blackstone
fill 303 279 188 307 284 188 minecraft:blackstone
fill 303 279 190 303 283 191 minecraft:shroomlight
fill 303 279 198 303 280 198 minecraft:magma_block
fill 303 279 206 303 280 206 minecraft:magma_block
fill 303 279 210 306 281 210 minecraft:blackstone
fill 303 279 212 303 282 212 minecraft:shroomlight
fill 303 279 219 323 279 219 minecraft:blackstone
fill 304 279 190 307 283 191 minecraft:blackstone
fill 304 279 198 309 280 198 minecraft:blackstone
fill 304 279 200 304 279 201 minecraft:shroomlight
fill 304 279 203 304 279 204 minecraft:shroomlight
fill 304 279 206 306 280 206 minecraft:blackstone
fill 304 279 212 313 282 212 minecraft:blackstone
fill 304 279 213 304 283 213 minecraft:shroomlight
fill 304 279 214 304 283 215 minecraft:blackstone
fill 305 279 199 308 280 199 minecraft:blackstone
fill 305 279 200 305 280 200 minecraft:magma_block
fill 305 279 201 305 279 203 minecraft:shroomlight
fill 305 279 204 305 280 204 minecraft:magma_block
fill 305 279 205 316 280 205 minecraft:blackstone
fill 305 279 213 323 279 213 minecraft:blackstone
fill 305 279 214 305 283 214 minecraft:shroomlight
fill 305 279 215 305 284 215 minecraft:blackstone
fill 306 279 200 307 280 204 minecraft:blackstone
fill 306 279 214 323 279 214 minecraft:blackstone
fill 306 279 215 306 284 215 minecraft:shroomlight
fill 307 279 206 307 281 206 minecraft:shroomlight
fill 307 279 210 307 282 210 minecraft:shroomlight
fill 307 279 215 323 279 215 minecraft:blackstone
fill 308 279 188 308 283 192 minecraft:shroomlight
fill 308 279 200 312 281 202 minecraft:blackstone
fill 308 279 203 308 281 203 minecraft:shroomlight
fill 308 279 204 323 279 204 minecraft:blackstone
fill 308 279 206 313 281 206 minecraft:blackstone
fill 308 279 210 323 279 210 minecraft:blackstone
fill 309 279 188 313 279 192 minecraft:blackstone
fill 309 279 199 309 282 199 minecraft:shroomlight
fill 309 279 203 323 279 203 minecraft:blackstone
fill 309 279 211 310 283 211 minecraft:shroomlight
fill 309 279 216 323 279 216 minecraft:blackstone
fill 309 279 217 310 285 217 minecraft:shroomlight
fill 310 279 198 310 282 198 minecraft:shroomlight
fill 310 279 199 315 282 199 minecraft:blackstone
fill 311 279 197 311 283 197 minecraft:shroomlight
fill 311 279 198 316 283 198 minecraft:blackstone
fill 311 279 211 323 279 211 minecraft:blackstone
fill 311 279 217 323 279 217 minecraft:blackstone
fill 312 279 194 323 279 194 minecraft:blackstone
fill 312 279 195 312 284 195 minecraft:shroomlight
fill 312 279 196 323 279 197 minecraft:blackstone
fill 313 279 193 313 285 193 minecraft:shroomlight
fill 313 279 195 323 279 195 minecraft:blackstone
fill 313 279 200 314 283 200 minecraft:blackstone
fill 313 279 201 313 283 201 minecraft:shroomlight
fill 313 279 202 323 279 202 minecraft:blackstone
fill 314 279 188 323 279 189 minecraft:blackstone
fill 314 279 190 314 285 190 minecraft:shroomlight
fill 314 279 191 323 279 193 minecraft:blackstone
fill 314 279 201 323 279 201 minecraft:blackstone
fill 314 279 206 315 284 206 minecraft:shroomlight
fill 314 279 212 315 285 212 minecraft:shroomlight
fill 315 279 190 323 279 190 minecraft:blackstone
fill 315 279 200 315 284 200 minecraft:shroomlight
fill 316 279 199 316 285 199 minecraft:shroomlight
fill 316 279 200 323 279 200 minecraft:blackstone
fill 316 279 206 323 279 206 minecraft:blackstone
fill 316 279 212 323 279 212 minecraft:blackstone
fill 317 279 198 317 285 198 minecraft:shroomlight
fill 317 279 199 323 279 199 minecraft:blackstone
fill 317 279 205 318 285 205 minecraft:shroomlight
fill 318 279 198 323 279 198 minecraft:blackstone
fill 319 279 205 323 279 205 minecraft:blackstone
fill 283 280 202 284 285 202 minecraft:blackstone
fill 284 280 197 286 285 198 minecraft:blackstone
fill 284 280 200 284 285 201 minecraft:blackstone
fill 284 280 203 284 285 207 minecraft:blackstone
fill 285 280 194 286 285 196 minecraft:blackstone
fill 285 280 207 287 284 210 minecraft:blackstone
fill 286 280 193 286 285 193 minecraft:blackstone
fill 286 280 211 287 285 211 minecraft:blackstone
fill 287 280 191 291 284 191 minecraft:blackstone
fill 287 280 212 287 285 213 minecraft:blackstone
fill 288 280 190 291 285 190 minecraft:blackstone
fill 289 280 189 291 285 189 minecraft:blackstone
fill 289 280 215 293 285 215 minecraft:blackstone
fill 290 280 188 291 285 188 minecraft:blackstone
fill 290 280 216 293 285 216 minecraft:blackstone
fill 291 280 208 317 280 209 minecraft:blackstone
fill 292 280 217 300 285 217 minecraft:blackstone
fill 293 280 186 299 285 186 minecraft:blackstone
fill 293 280 218 300 285 218 minecraft:blackstone
fill 294 280 187 310 285 187 minecraft:blackstone
fill 296 280 185 299 285 185 minecraft:blackstone
fill 296 280 219 300 285 219 minecraft:blackstone
setblock 297 280 201 minecraft:magma_block
setblock 297 280 203 minecraft:magma_block
setblock 298 280 199 minecraft:magma_block
setblock 298 280 205 minecraft:magma_block
setblock 300 280 198 minecraft:magma_block
setblock 300 280 206 minecraft:magma_block
fill 301 280 185 306 285 185 minecraft:blackstone
fill 302 280 186 309 285 186 minecraft:blackstone
setblock 302 280 198 minecraft:magma_block
setblock 302 280 206 minecraft:magma_block
fill 302 280 207 318 280 207 minecraft:blackstone
fill 302 280 218 309 285 218 minecraft:blackstone
fill 303 280 219 306 285 219 minecraft:blackstone
setblock 304 280 199 minecraft:magma_block
setblock 304 280 205 minecraft:magma_block
setblock 305 280 201 minecraft:magma_block
setblock 305 280 203 minecraft:magma_block
fill 305 280 213 315 283 213 minecraft:blackstone
fill 306 280 214 314 284 214 minecraft:blackstone
fill 307 280 215 313 284 215 minecraft:blackstone
fill 308 280 204 318 281 204 minecraft:blackstone
fill 308 280 210 317 283 210 minecraft:blackstone
fill 309 280 188 312 284 192 minecraft:blackstone
fill 309 280 203 318 281 203 minecraft:blackstone
fill 309 280 216 312 285 216 minecraft:blackstone
fill 311 280 211 316 284 211 minecraft:blackstone
fill 312 280 194 317 284 194 minecraft:blackstone
fill 312 280 196 317 283 197 minecraft:blackstone
fill 313 280 189 313 285 192 minecraft:blackstone
fill 313 280 195 317 284 195 minecraft:blackstone
fill 313 280 202 319 283 202 minecraft:blackstone
fill 314 280 191 315 285 193 minecraft:blackstone
fill 314 280 201 318 284 201 minecraft:blackstone
fill 316 280 193 316 285 193 minecraft:blackstone
fill 316 280 200 318 285 200 minecraft:blackstone
fill 316 280 206 318 285 206 minecraft:blackstone
fill 317 280 199 318 285 199 minecraft:blackstone
fill 318 280 197 318 285 198 minecraft:blackstone
fill 288 281 204 295 281 204 minecraft:blackstone
fill 290 281 203 294 281 203 minecraft:blackstone
fill 291 281 208 299 281 209 minecraft:blackstone
fill 292 281 207 297 281 207 minecraft:blackstone
fill 293 281 206 296 281 206 minecraft:blackstone
setblock 294 281 202 minecraft:blackstone
fill 294 281 205 295 281 205 minecraft:blackstone
fill 295 281 195 297 281 197 minecraft:blackstone
fill 295 281 199 295 281 200 minecraft:blackstone
setblock 296 281 198 minecraft:blackstone
fill 298 281 195 299 281 196 minecraft:blackstone
fill 300 281 195 311 281 195 minecraft:blackstone
fill 300 281 209 317 281 209 minecraft:blackstone
fill 301 281 194 311 281 194 minecraft:blackstone
fill 303 281 196 311 281 196 minecraft:blackstone
fill 303 281 208 317 281 208 minecraft:blackstone
fill 305 281 197 310 281 197 minecraft:blackstone
fill 305 281 207 318 281 207 minecraft:blackstone
fill 306 281 198 309 281 198 minecraft:blackstone
setblock 306 281 206 minecraft:blackstone
fill 307 281 199 307 281 200 minecraft:blackstone
fill 307 281 204 307 281 205 minecraft:blackstone
setblock 308 281 199 minecraft:blackstone
fill 308 281 205 316 281 205 minecraft:blackstone
fill 288 282 204 292 282 204 minecraft:blackstone
fill 289 282 198 292 282 202 minecraft:blackstone
fill 290 282 203 292 282 203 minecraft:blackstone
fill 290 282 210 298 282 211 minecraft:blackstone
fill 291 282 208 295 282 209 minecraft:blackstone
fill 292 282 207 294 282 207 minecraft:blackstone
fill 293 282 198 293 282 199 minecraft:blackstone
setblock 293 282 206 minecraft:blackstone
fill 295 282 195 295 282 196 minecraft:blackstone
fill 296 282 194 296 282 195 minecraft:blackstone
setblock 296 282 209 minecraft:blackstone
fill 297 282 194 298 282 194 minecraft:blackstone
fill 299 282 211 301 282 211 minecraft:blackstone
fill 304 282 194 311 282 194 minecraft:blackstone
fill 304 282 210 306 282 210 minecraft:blackstone
fill 306 282 195 311 282 195 minecraft:blackstone
fill 306 282 209 317 282 209 minecraft:blackstone
fill 307 282 196 311 282 196 minecraft:blackstone
fill 307 282 208 317 282 208 minecraft:blackstone
fill 308 282 197 310 282 197 minecraft:blackstone
fill 308 282 207 318 282 207 minecraft:blackstone
setblock 309 282 198 minecraft:blackstone
fill 309 282 205 313 282 206 minecraft:blackstone
fill 310 282 200 312 282 204 minecraft:blackstone
fill 313 282 203 318 283 204 minecraft:blackstone
fill 314 282 205 316 284 205 minecraft:blackstone
setblock 283 283 186 minecraft:polished_blackstone
fill 283 283 187 283 283 190 minecraft:red_nether_bricks
setblock 283 283 211 minecraft:polished_blackstone
fill 283 283 212 283 284 214 minecraft:red_nether_bricks
fill 287 283 205 290 283 205 minecraft:blackstone
fill 288 283 204 290 283 204 minecraft:blackstone
fill 289 283 192 297 283 192 minecraft:blackstone
fill 289 283 198 290 283 202 minecraft:blackstone
setblock 290 283 203 minecraft:blackstone
fill 290 283 210 294 283 211 minecraft:blackstone
setblock 291 283 198 minecraft:blackstone
fill 291 283 208 292 283 209 minecraft:blackstone
setblock 291 283 222 minecraft:red_nether_bricks
fill 292 283 194 292 283 196 minecraft:blackstone
setblock 292 283 222 minecraft:polished_blackstone
fill 293 283 194 293 283 195 minecraft:blackstone
setblock 293 283 209 minecraft:blackstone
fill 293 283 222 296 283 222 minecraft:red_nether_bricks
fill 294 283 193 294 283 194 minecraft:blackstone
setblock 295 283 193 minecraft:blackstone
fill 295 283 211 295 283 216 minecraft:blackstone
fill 296 283 212 297 283 216 minecraft:blackstone
setblock 297 283 222 minecraft:polished_blackstone
fill 298 283 213 298 283 216 minecraft:blackstone
fill 305 283 192 307 283 192 minecraft:blackstone
fill 305 283 212 313 283 212 minecraft:blackstone
fill 307 283 193 312 283 193 minecraft:blackstone
fill 307 283 211 308 283 211 minecraft:blackstone
fill 308 283 194 311 283 194 minecraft:blackstone
fill 309 283 195 311 283 195 minecraft:blackstone
fill 309 283 209 317 283 209 minecraft:blackstone
fill 310 283 196 311 283 196 minecraft:blackstone
fill 310 283 208 317 283 208 minecraft:blackstone
fill 311 283 206 313 283 207 minecraft:blackstone
fill 312 283 199 312 283 205 minecraft:blackstone
fill 313 283 182 316 283 182 minecraft:red_nether_bricks
fill 313 283 199 315 283 199 minecraft:blackstone
setblock 313 283 205 minecraft:blackstone
fill 314 283 207 318 284 207 minecraft:blackstone
fill 314 283 219 316 300 219 minecraft:gilded_blackstone
setblock 315 283 183 minecraft:red_nether_bricks
fill 315 283 218 315 300 218 minecraft:gilded_blackstone
fill 315 283 220 315 300 220 minecraft:gilded_blackstone
setblock 316 283 183 minecraft:polished_blackstone
setblock 317 283 182 minecraft:polished_blackstone
fill 317 283 183 318 283 183 minecraft:red_nether_bricks
fill 318 283 182 321 283 182 minecraft:red_nether_bricks
fill 321 283 189 323 283 189 minecraft:red_nether_bricks
setblock 322 283 186 minecraft:red_nether_bricks
setblock 322 283 187 minecraft:polished_blackstone
fill 322 283 188 323 285 188 minecraft:red_nether_bricks
fill 322 283 190 322 283 191 minecraft:red_nether_bricks
setblock 322 283 192 minecraft:polished_blackstone
fill 323 283 184 323 283 185 minecraft:red_nether_bricks
setblock 323 283 186 minecraft:polished_blackstone
fill 323 283 187 323 286 187 minecraft:red_nether_bricks
setblock 323 283 190 minecraft:red_nether_bricks
setblock 323 283 191 minecraft:polished_blackstone
fill 323 283 192 323 285 193 minecraft:red_nether_bricks
fill 283 284 188 283 284 189 minecraft:red_nether_bricks
fill 283 284 211 283 287 211 minecraft:red_nether_bricks
setblock 283 284 215 minecraft:polished_blackstone
fill 283 284 216 283 287 216 minecraft:red_nether_bricks
setblock 285 284 184 minecraft:light[level=14]
setblock 285 284 192 minecraft:light[level=14]
setblock 285 284 216 minecraft:light[level=14]
fill 286 284 206 288 284 206 minecraft:blackstone
fill 287 284 193 289 284 197 minecraft:blackstone
fill 287 284 205 288 284 205 minecraft:blackstone
setblock 288 284 204 minecraft:blackstone
fill 289 284 192 293 284 192 minecraft:blackstone
fill 290 284 193 290 284 195 minecraft:blackstone
fill 290 284 210 291 284 211 minecraft:blackstone
setblock 290 284 222 minecraft:red_nether_bricks
fill 291 284 193 291 284 194 minecraft:blackstone
setblock 291 284 222 minecraft:polished_blackstone
fill 292 284 188 294 284 191 minecraft:blackstone
fill 292 284 222 295 284 222 minecraft:red_nether_bricks
setblock 293 284 184 minecraft:light[level=14]
setblock 293 284 200 minecraft:light[level=14]
setblock 293 284 208 minecraft:light[level=14]
fill 294 284 213 294 284 216 minecraft:shroomlight
fill 295 284 188 295 284 190 minecraft:blackstone
fill 295 284 214 296 284 216 minecraft:blackstone
setblock 296 284 190 minecraft:blackstone
setblock 296 284 222 minecraft:polished_blackstone
fill 297 284 215 298 284 216 minecraft:blackstone
fill 300 284 215 304 284 215 minecraft:blackstone
setblock 301 284 192 minecraft:light[level=14]
setblock 301 284 200 minecraft:light[level=14]
setblock 301 284 208 minecraft:light[level=14]
fill 306 284 190 307 284 190 minecraft:blackstone
fill 308 284 188 308 284 191 minecraft:shroomlight
fill 308 284 213 315 284 213 minecraft:blackstone
setblock 309 284 184 minecraft:light[level=14]
setblock 309 284 200 minecraft:light[level=14]
setblock 309 284 208 minecraft:light[level=14]
fill 309 284 212 313 284 212 minecraft:blackstone
fill 311 284 193 311 284 194 minecraft:blackstone
fill 311 284 210 317 284 210 minecraft:blackstone
setblock 312 284 193 minecraft:blackstone
fill 312 284 209 317 284 209 minecraft:blackstone
fill 313 284 182 315 284 182 minecraft:red_nether_bricks
fill 313 284 196 317 284 197 minecraft:blackstone
fill 313 284 207 313 284 208 minecraft:blackstone
fill 314 284 198 314 284 200 minecraft:blackstone
fill 314 284 202 318 284 204 minecraft:blackstone
fill 314 284 208 317 284 208 minecraft:blackstone
setblock 315 284 183 minecraft:polished_blackstone
fill 315 284 198 315 284 199 minecraft:blackstone
setblock 316 284 182 minecraft:polished_blackstone
fill 316 284 183 317 286 183 minecraft:red_nether_bricks
fill 316 284 198 316 285 198 minecraft:blackstone
fill 317 284 182 320 284 182 minecraft:red_nether_bricks
setblock 317 284 184 minecraft:light[level=14]
setblock 317 284 192 minecraft:light[level=14]
setblock 317 284 216 minecraft:light[level=14]
fill 319 284 202 319 285 202 minecraft:blackstone
fill 322 284 187 322 285 187 minecraft:red_nether_bricks
fill 322 284 189 322 284 190 minecraft:red_nether_bricks
setblock 322 284 191 minecraft:polished_blackstone
fill 322 284 192 322 287 192 minecraft:red_nether_bricks
setblock 323 284 184 minecraft:red_nether_bricks
setblock 323 284 185 minecraft:polished_blackstone
fill 323 284 186 323 287 186 minecraft:red_nether_bricks
setblock 323 284 189 minecraft:red_nether_bricks
setblock 323 284 190 minecraft:polished_blackstone
fill 323 284 191 323 287 191 minecraft:red_nether_bricks
setblock 323 284 194 minecraft:red_nether_bricks
fill 283 285 212 283 285 213 minecraft:red_nether_bricks
setblock 283 285 214 minecraft:polished_blackstone
fill 283 285 215 283 288 215 minecraft:red_nether_bricks
fill 283 285 217 283 285 218 minecraft:red_nether_bricks
fill 285 285 207 286 285 210 minecraft:blackstone
setblock 286 285 206 minecraft:blackstone
fill 287 285 191 290 285 191 minecraft:blackstone
fill 287 285 193 287 285 196 minecraft:blackstone
fill 287 285 208 287 285 210 minecraft:blackstone
fill 288 285 193 288 285 194 minecraft:blackstone
fill 288 285 210 288 285 213 minecraft:blackstone
fill 288 285 222 289 285 222 minecraft:red_nether_bricks
fill 289 285 192 289 285 193 minecraft:blackstone
fill 289 285 212 289 285 214 minecraft:blackstone
fill 290 285 213 290 285 214 minecraft:blackstone
setblock 290 285 222 minecraft:polished_blackstone
fill 291 285 214 292 285 214 minecraft:blackstone
setblock 291 285 221 minecraft:polished_blackstone
fill 291 285 222 294 285 222 minecraft:red_nether_bricks
fill 292 285 188 292 285 190 minecraft:blackstone
fill 292 285 221 294 286 221 minecraft:red_nether_bricks
fill 293 285 188 293 285 189 minecraft:blackstone
fill 294 285 188 295 285 188 minecraft:blackstone
setblock 294 285 216 minecraft:shroomlight
setblock 295 285 216 minecraft:blackstone
setblock 295 285 222 minecraft:polished_blackstone
fill 296 285 222 296 288 222 minecraft:red_nether_bricks
fill 301 285 217 308 285 217 minecraft:blackstone
setblock 307 285 188 minecraft:blackstone
fill 307 285 216 308 285 216 minecraft:blackstone
setblock 308 285 188 minecraft:shroomlight
fill 309 285 188 312 285 189 minecraft:blackstone
fill 309 285 215 313 285 215 minecraft:blackstone
fill 310 285 190 312 285 190 minecraft:blackstone
fill 310 285 214 314 285 214 minecraft:blackstone
fill 312 285 182 314 285 182 minecraft:red_nether_bricks
setblock 312 285 191 minecraft:blackstone
fill 312 285 213 315 285 213 minecraft:blackstone
fill 313 285 211 313 285 212 minecraft:blackstone
setblock 314 285 183 minecraft:polished_blackstone
fill 314 285 194 317 285 194 minecraft:blackstone
fill 314 285 210 316 285 211 minecraft:blackstone
setblock 314 285 218 minecraft:polished_blackstone
setblock 314 285 220 minecraft:polished_blackstone
setblock 315 285 182 minecraft:polished_blackstone
fill 315 285 183 315 288 183 minecraft:red_nether_bricks
fill 315 285 195 317 285 196 minecraft:blackstone
fill 315 285 208 317 285 209 minecraft:blackstone
fill 316 285 182 319 285 182 minecraft:red_nether_bricks
fill 316 285 197 317 285 197 minecraft:blackstone
fill 316 285 201 316 285 205 minecraft:blackstone
fill 316 285 207 318 285 207 minecraft:blackstone
setblock 316 285 218 minecraft:polished_blackstone
setblock 316 285 220 minecraft:polished_blackstone
fill 317 285 201 318 285 204 minecraft:blackstone
setblock 317 285 210 minecraft:blackstone
setblock 320 285 182 minecraft:polished_blackstone
setblock 322 285 189 minecraft:red_nether_bricks
setblock 322 285 190 minecraft:polished_blackstone
fill 322 285 191 322 288 191 minecraft:red_nether_bricks
fill 323 285 185 323 288 185 minecraft:red_nether_bricks
setblock 323 285 189 minecraft:polished_blackstone
fill 323 285 190 323 288 190 minecraft:red_nether_bricks
setblock 323 285 194 minecraft:polished_blackstone
fill 283 286 210 283 288 210 minecraft:red_nether_bricks
setblock 283 286 212 minecraft:red_nether_bricks
setblock 283 286 213 minecraft:polished_blackstone
fill 283 286 214 284 288 214 minecraft:red_nether_bricks
setblock 283 286 217 minecraft:red_nether_bricks
setblock 283 286 218 minecraft:polished_blackstone
fill 283 286 219 283 288 220 minecraft:red_nether_bricks
fill 284 286 213 284 289 213 minecraft:red_nether_bricks
fill 284 286 215 284 286 216 minecraft:red_nether_bricks
fill 286 286 222 288 286 222 minecraft:red_nether_bricks
setblock 289 286 221 minecraft:red_nether_bricks
setblock 289 286 222 minecraft:polished_blackstone
setblock 290 286 221 minecraft:polished_blackstone
fill 290 286 222 293 286 222 minecraft:red_nether_bricks
fill 291 286 221 291 289 221 minecraft:red_nether_bricks
setblock 294 286 222 minecraft:polished_blackstone
setblock 295 286 221 minecraft:polished_blackstone
fill 295 286 222 295 289 222 minecraft:red_nether_bricks
fill 297 286 222 297 287 222 minecraft:red_nether_bricks
fill 311 286 182 313 286 182 minecraft:red_nether_bricks
setblock 313 286 183 minecraft:polished_blackstone
setblock 314 286 182 minecraft:polished_blackstone
fill 314 286 183 314 289 183 minecraft:red_nether_bricks
setblock 314 286 222 minecraft:polished_blackstone
fill 315 286 182 318 286 182 minecraft:red_nether_bricks
fill 315 286 222 315 289 222 minecraft:red_nether_bricks
setblock 319 286 182 minecraft:polished_blackstone
fill 320 286 182 320 289 182 minecraft:red_nether_bricks
setblock 322 286 188 minecraft:red_nether_bricks
setblock 322 286 189 minecraft:polished_blackstone
fill 322 286 190 322 289 190 minecraft:red_nether_bricks
setblock 322 286 193 minecraft:red_nether_bricks
setblock 323 286 188 minecraft:polished_blackstone
fill 323 286 189 323 289 189 minecraft:red_nether_bricks
setblock 323 286 192 minecraft:red_nether_bricks
setblock 323 286 193 minecraft:polished_blackstone
fill 323 286 194 323 288 195 minecraft:red_nether_bricks
setblock 283 287 191 minecraft:red_nether_bricks
setblock 283 287 192 minecraft:polished_blackstone
setblock 283 287 212 minecraft:polished_blackstone
fill 283 287 213 283 290 213 minecraft:red_nether_bricks
setblock 283 287 217 minecraft:polished_blackstone
fill 283 287 218 284 289 218 minecraft:red_nether_bricks
setblock 283 287 221 minecraft:red_nether_bricks
setblock 283 287 222 minecraft:polished_blackstone
fill 284 287 212 284 290 212 minecraft:red_nether_bricks
setblock 284 287 215 minecraft:red_nether_bricks
setblock 284 287 216 minecraft:polished_blackstone
fill 284 287 217 284 290 217 minecraft:red_nether_bricks
fill 284 287 219 284 288 219 minecraft:red_nether_bricks
fill 284 287 222 287 287 222 minecraft:red_nether_bricks
fill 287 287 221 288 287 221 minecraft:red_nether_bricks
setblock 288 287 222 minecraft:polished_blackstone
setblock 289 287 220 minecraft:red_nether_bricks
setblock 289 287 221 minecraft:polished_blackstone
fill 289 287 222 292 287 222 minecraft:red_nether_bricks
setblock 290 287 220 minecraft:polished_blackstone
fill 290 287 221 290 290 221 minecraft:red_nether_bricks
fill 291 287 182 292 287 182 minecraft:red_nether_bricks
fill 291 287 220 294 287 220 minecraft:red_nether_bricks
fill 292 287 221 293 287 221 minecraft:red_nether_bricks
setblock 293 287 182 minecraft:polished_blackstone
setblock 293 287 222 minecraft:polished_blackstone
setblock 294 287 221 minecraft:polished_blackstone
fill 294 287 222 294 290 222 minecraft:red_nether_bricks
fill 295 287 221 296 289 221 minecraft:red_nether_bricks
fill 310 287 182 312 287 182 minecraft:red_nether_bricks
setblock 312 287 183 minecraft:polished_blackstone
setblock 312 287 222 minecraft:red_nether_bricks
setblock 313 287 182 minecraft:polished_blackstone
fill 313 287 183 313 290 183 minecraft:red_nether_bricks
setblock 313 287 222 minecraft:polished_blackstone
fill 314 287 182 317 287 182 minecraft:red_nether_bricks
fill 314 287 222 314 290 222 minecraft:red_nether_bricks
setblock 316 287 183 minecraft:red_nether_bricks
fill 316 287 222 317 287 222 minecraft:red_nether_bricks
setblock 317 287 183 minecraft:polished_blackstone
setblock 318 287 182 minecraft:polished_blackstone
fill 319 287 182 319 290 182 minecraft:red_nether_bricks
fill 322 287 189 322 288 189 minecraft:red_nether_bricks
setblock 322 287 193 minecraft:polished_blackstone
setblock 323 287 187 minecraft:polished_blackstone
fill 323 287 188 323 290 188 minecraft:red_nether_bricks
setblock 323 287 192 minecraft:polished_blackstone
fill 323 287 193 323 290 193 minecraft:red_nether_bricks
setblock 323 287 196 minecraft:red_nether_bricks
fill 323 287 213 323 287 216 minecraft:red_nether_bricks
setblock 323 287 217 minecraft:polished_blackstone
fill 323 287 218 323 290 218 minecraft:red_nether_bricks
setblock 283 288 191 minecraft:polished_blackstone
fill 283 288 192 283 289 194 minecraft:red_nether_bricks
setblock 283 288 211 minecraft:polished_blackstone
fill 283 288 212 283 291 212 minecraft:red_nether_bricks
setblock 283 288 216 minecraft:polished_blackstone
fill 283 288 217 283 291 217 minecraft:red_nether_bricks
setblock 283 288 221 minecraft:polished_blackstone
fill 283 288 222 286 288 222 minecraft:red_nether_bricks
setblock 284 288 215 minecraft:polished_blackstone
fill 284 288 216 285 290 216 minecraft:red_nether_bricks
setblock 284 288 220 minecraft:polished_blackstone
setblock 285 288 214 minecraft:polished_blackstone
fill 285 288 215 285 291 215 minecraft:red_nether_bricks
fill 285 288 217 285 288 218 minecraft:red_nether_bricks
fill 285 288 221 287 288 221 minecraft:red_nether_bricks
fill 287 288 220 288 288 220 minecraft:red_nether_bricks
setblock 287 288 222 minecraft:polished_blackstone
setblock 288 288 221 minecraft:polished_blackstone
fill 288 288 222 291 288 222 minecraft:red_nether_bricks
fill 289 288 182 291 288 182 minecraft:red_nether_bricks
setblock 289 288 220 minecraft:polished_blackstone
fill 289 288 221 289 291 221 minecraft:red_nether_bricks
setblock 290 288 219 minecraft:polished_blackstone
fill 290 288 220 293 288 220 minecraft:red_nether_bricks
fill 291 288 219 293 289 219 minecraft:red_nether_bricks
setblock 292 288 182 minecraft:polished_blackstone
setblock 292 288 221 minecraft:red_nether_bricks
setblock 292 288 222 minecraft:polished_blackstone
fill 293 288 182 293 291 182 minecraft:red_nether_bricks
setblock 293 288 221 minecraft:polished_blackstone
fill 293 288 222 293 291 222 minecraft:red_nether_bricks
setblock 294 288 220 minecraft:polished_blackstone
fill 294 288 221 294 291 221 minecraft:red_nether_bricks
fill 295 288 220 295 290 220 minecraft:red_nether_bricks
setblock 297 288 222 minecraft:polished_blackstone
fill 309 288 182 311 288 182 minecraft:red_nether_bricks
fill 310 288 222 311 288 222 minecraft:red_nether_bricks
setblock 311 288 183 minecraft:polished_blackstone
setblock 312 288 182 minecraft:polished_blackstone
fill 312 288 183 312 291 183 minecraft:red_nether_bricks
setblock 312 288 222 minecraft:polished_blackstone
fill 313 288 182 316 288 182 minecraft:red_nether_bricks
setblock 313 288 221 minecraft:polished_blackstone
fill 313 288 222 313 291 222 minecraft:red_nether_bricks
fill 314 288 221 314 291 221 minecraft:red_nether_bricks
setblock 316 288 183 minecraft:polished_blackstone
setblock 316 288 222 minecraft:red_nether_bricks
setblock 317 288 182 minecraft:polished_blackstone
fill 317 288 183 317 289 183 minecraft:red_nether_bricks
setblock 317 288 222 minecraft:polished_blackstone
fill 318 288 182 318 291 182 minecraft:red_nether_bricks
fill 318 288 222 319 290 222 minecraft:red_nether_bricks
setblock 321 288 182 minecraft:red_nether_bricks
setblock 322 288 192 minecraft:polished_blackstone
fill 322 288 193 322 290 194 minecraft:red_nether_bricks
setblock 323 288 186 minecraft:polished_blackstone
fill 323 288 187 323 290 187 minecraft:red_nether_bricks
setblock 323 288 191 minecraft:polished_blackstone
fill 323 288 192 323 291 192 minecraft:red_nether_bricks
setblock 323 288 196 minecraft:polished_blackstone
fill 323 288 213 323 288 215 minecraft:red_nether_bricks
setblock 323 288 216 minecraft:polished_blackstone
fill 323 288 217 323 291 217 minecraft:red_nether_bricks
fill 323 288 219 323 288 220 minecraft:red_nether_bricks
setblock 323 288 221 minecraft:polished_blackstone
setblock 283 289 191 minecraft:red_nether_bricks
setblock 283 289 195 minecraft:polished_blackstone
setblock 283 289 210 minecraft:polished_blackstone
fill 283 289 211 284 290 211 minecraft:red_nether_bricks
setblock 283 289 214 minecraft:red_nether_bricks
setblock 283 289 215 minecraft:polished_blackstone
fill 283 289 216 283 292 216 minecraft:red_nether_bricks
setblock 283 289 219 minecraft:red_nether_bricks
setblock 283 289 220 minecraft:polished_blackstone
fill 283 289 221 285 289 222 minecraft:red_nether_bricks
setblock 284 289 214 minecraft:polished_blackstone
fill 284 289 215 284 292 215 minecraft:red_nether_bricks
setblock 284 289 219 minecraft:polished_blackstone
fill 284 289 220 284 292 220 minecraft:red_nether_bricks
setblock 285 289 213 minecraft:polished_blackstone
fill 285 289 214 285 292 214 minecraft:red_nether_bricks
setblock 285 289 217 minecraft:red_nether_bricks
setblock 285 289 218 minecraft:polished_blackstone
fill 285 289 219 285 292 219 minecraft:red_nether_bricks
fill 286 289 215 286 289 216 minecraft:red_nether_bricks
fill 286 289 220 286 289 221 minecraft:red_nether_bricks
setblock 286 289 222 minecraft:polished_blackstone
setblock 287 289 220 minecraft:red_nether_bricks
setblock 287 289 221 minecraft:polished_blackstone
fill 287 289 222 290 289 222 minecraft:red_nether_bricks
fill 288 289 182 290 289 182 minecraft:red_nether_bricks
setblock 288 289 219 minecraft:red_nether_bricks
setblock 288 289 220 minecraft:polished_blackstone
fill 288 289 221 288 292 221 minecraft:red_nether_bricks
setblock 289 289 219 minecraft:polished_blackstone
fill 289 289 220 292 289 220 minecraft:red_nether_bricks
fill 290 289 219 290 292 219 minecraft:red_nether_bricks
setblock 291 289 182 minecraft:polished_blackstone
setblock 291 289 222 minecraft:polished_blackstone
fill 292 289 182 292 292 182 minecraft:red_nether_bricks
setblock 292 289 221 minecraft:polished_blackstone
fill 292 289 222 292 292 222 minecraft:red_nether_bricks
setblock 293 289 220 minecraft:polished_blackstone
fill 293 289 221 293 292 221 minecraft:red_nether_bricks
fill 294 289 220 294 292 220 minecraft:red_nether_bricks
setblock 296 289 222 minecraft:polished_blackstone
fill 297 289 222 297 291 222 minecraft:red_nether_bricks
fill 308 289 182 310 289 182 minecraft:red_nether_bricks
fill 308 289 222 310 289 222 minecraft:red_nether_bricks
setblock 310 289 183 minecraft:polished_blackstone
setblock 311 289 182 minecraft:polished_blackstone
fill 311 289 183 311 292 183 minecraft:red_nether_bricks
setblock 311 289 221 minecraft:red_nether_bricks
setblock 311 289 222 minecraft:polished_blackstone
fill 312 289 182 315 289 182 minecraft:red_nether_bricks
setblock 312 289 221 minecraft:polished_blackstone
fill 312 289 222 312 292 222 minecraft:red_nether_bricks
fill 313 289 221 313 292 221 minecraft:red_nether_bricks
setblock 315 289 183 minecraft:polished_blackstone
fill 315 289 221 316 289 221 minecraft:red_nether_bricks
setblock 316 289 182 minecraft:polished_blackstone
fill 316 289 183 316 291 183 minecraft:red_nether_bricks
setblock 316 289 222 minecraft:polished_blackstone
fill 317 289 182 317 292 182 minecraft:red_nether_bricks
fill 317 289 222 317 292 222 minecraft:red_nether_bricks
setblock 320 289 222 minecraft:red_nether_bricks
setblock 321 289 182 minecraft:polished_blackstone
setblock 321 289 222 minecraft:polished_blackstone
fill 322 289 182 323 291 182 minecraft:red_nether_bricks
setblock 322 289 191 minecraft:polished_blackstone
fill 322 289 192 322 290 192 minecraft:red_nether_bricks
fill 322 289 222 323 291 222 minecraft:red_nether_bricks
fill 323 289 183 323 289 184 minecraft:red_nether_bricks
setblock 323 289 185 minecraft:polished_blackstone
fill 323 289 186 323 290 186 minecraft:red_nether_bricks
setblock 323 289 190 minecraft:polished_blackstone
fill 323 289 191 323 292 191 minecraft:red_nether_bricks
setblock 323 289 194 minecraft:red_nether_bricks
setblock 323 289 195 minecraft:polished_blackstone
fill 323 289 196 323 291 197 minecraft:red_nether_bricks
fill 323 289 213 323 289 214 minecraft:red_nether_bricks
setblock 323 289 215 minecraft:polished_blackstone
fill 323 289 216 323 292 216 minecraft:red_nether_bricks
setblock 323 289 219 minecraft:red_nether_bricks
setblock 323 289 220 minecraft:polished_blackstone
fill 323 289 221 323 292 221 minecraft:red_nether_bricks
fill 283 290 192 283 290 193 minecraft:red_nether_bricks
setblock 283 290 194 minecraft:polished_blackstone
fill 283 290 195 283 292 196 minecraft:red_nether_bricks
fill 283 290 210 283 292 210 minecraft:red_nether_bricks
setblock 283 290 214 minecraft:polished_blackstone
fill 283 290 215 283 293 215 minecraft:red_nether_bricks
setblock 283 290 218 minecraft:red_nether_bricks
setblock 283 290 219 minecraft:polished_blackstone
fill 283 290 220 283 291 222 minecraft:red_nether_bricks
setblock 284 290 213 minecraft:polished_blackstone
fill 284 290 214 284 293 214 minecraft:red_nether_bricks
setblock 284 290 218 minecraft:polished_blackstone
fill 284 290 219 284 293 219 minecraft:red_nether_bricks
fill 284 290 221 284 290 222 minecraft:red_nether_bricks
fill 285 290 213 285 292 213 minecraft:red_nether_bricks
setblock 285 290 217 minecraft:polished_blackstone
fill 285 290 218 286 292 218 minecraft:red_nether_bricks
fill 285 290 220 285 290 221 minecraft:red_nether_bricks
setblock 285 290 222 minecraft:polished_blackstone
setblock 286 290 215 minecraft:red_nether_bricks
setblock 286 290 216 minecraft:polished_blackstone
fill 286 290 217 286 293 217 minecraft:red_nether_bricks
setblock 286 290 220 minecraft:red_nether_bricks
setblock 286 290 221 minecraft:polished_blackstone
fill 286 290 222 289 290 222 minecraft:red_nether_bricks
fill 287 290 182 289 290 182 minecraft:red_nether_bricks
setblock 287 290 219 minecraft:red_nether_bricks
setblock 287 290 220 minecraft:polished_blackstone
fill 287 290 221 287 293 221 minecraft:red_nether_bricks
setblock 288 290 219 minecraft:polished_blackstone
fill 288 290 220 291 290 220 minecraft:red_nether_bricks
fill 289 290 219 289 293 219 minecraft:red_nether_bricks
setblock 290 290 182 minecraft:polished_blackstone
fill 290 290 218 290 291 218 minecraft:red_nether_bricks
setblock 290 290 222 minecraft:polished_blackstone
fill 291 290 182 291 293 182 minecraft:red_nether_bricks
fill 291 290 219 292 290 219 minecraft:red_nether_bricks
setblock 291 290 221 minecraft:polished_blackstone
fill 291 290 222 291 293 222 minecraft:red_nether_bricks
setblock 292 290 220 minecraft:polished_blackstone
fill 292 290 221 292 293 221 minecraft:red_nether_bricks
setblock 293 290 219 minecraft:polished_blackstone
fill 293 290 220 293 293 220 minecraft:red_nether_bricks
setblock 295 290 221 minecraft:red_nether_bricks
setblock 295 290 222 minecraft:polished_blackstone
setblock 296 290 221 minecraft:polished_blackstone
fill 296 290 222 296 293 222 minecraft:red_nether_bricks
fill 307 290 182 309 290 182 minecraft:red_nether_bricks
fill 307 290 222 309 290 222 minecraft:red_nether_bricks
setblock 309 290 183 minecraft:polished_blackstone
fill 309 290 221 310 290 221 minecraft:red_nether_bricks
setblock 310 290 182 minecraft:polished_blackstone
fill 310 290 183 310 293 183 minecraft:red_nether_bricks
setblock 310 290 222 minecraft:polished_blackstone
fill 311 290 182 314 290 182 minecraft:red_nether_bricks
setblock 311 290 221 minecraft:polished_blackstone
fill 311 290 222 311 293 222 minecraft:red_nether_bricks
fill 312 290 221 312 293 221 minecraft:red_nether_bricks
setblock 314 290 183 minecraft:polished_blackstone
setblock 315 290 182 minecraft:polished_blackstone
fill 315 290 183 315 292 183 minecraft:red_nether_bricks
setblock 315 290 217 minecraft:shroomlight
setblock 315 290 221 minecraft:red_nether_bricks
setblock 315 290 222 minecraft:polished_blackstone
fill 316 290 182 316 293 182 minecraft:red_nether_bricks
setblock 316 290 221 minecraft:polished_blackstone
fill 316 290 222 316 293 222 minecraft:red_nether_bricks
fill 317 290 221 317 292 221 minecraft:red_nether_bricks
setblock 320 290 182 minecraft:polished_blackstone
setblock 320 290 222 minecraft:polished_blackstone
fill 321 290 182 321 293 182 minecraft:red_nether_bricks
fill 321 290 222 321 293 222 minecraft:red_nether_bricks
fill 322 290 217 322 290 219 minecraft:red_nether_bricks
setblock 323 290 183 minecraft:red_nether_bricks
setblock 323 290 184 minecraft:polished_blackstone
setblock 323 290 189 minecraft:polished_blackstone
fill 323 290 190 323 292 190 minecraft:red_nether_bricks
setblock 323 290 194 minecraft:polished_blackstone
fill 323 290 195 323 293 195 minecraft:red_nether_bricks
setblock 323 290 213 minecraft:red_nether_bricks
setblock 323 290 214 minecraft:polished_blackstone
fill 323 290 215 323 293 215 minecraft:red_nether_bricks
setblock 323 290 219 minecraft:polished_blackstone
fill 323 290 220 323 293 220 minecraft:red_nether_bricks
setblock 283 291 193 minecraft:polished_blackstone
fill 283 291 194 283 292 194 minecraft:red_nether_bricks
setblock 283 291 197 minecraft:red_nether_bricks
setblock 283 291 198 minecraft:polished_blackstone
fill 283 291 211 283 292 211 minecraft:red_nether_bricks
setblock 283 291 213 minecraft:polished_blackstone
fill 283 291 214 283 294 214 minecraft:red_nether_bricks
setblock 283 291 218 minecraft:polished_blackstone
fill 283 291 219 283 294 219 minecraft:red_nether_bricks
setblock 284 291 212 minecraft:polished_blackstone
fill 284 291 213 284 294 213 minecraft:red_nether_bricks
setblock 284 291 216 minecraft:red_nether_bricks
setblock 284 291 217 minecraft:polished_blackstone
fill 284 291 218 284 294 218 minecraft:red_nether_bricks
setblock 284 291 221 minecraft:red_nether_bricks
setblock 284 291 222 minecraft:polished_blackstone
setblock 285 291 216 minecraft:polished_blackstone
fill 285 291 217 285 294 217 minecraft:red_nether_bricks
setblock 285 291 220 minecraft:red_nether_bricks
setblock 285 291 221 minecraft:polished_blackstone
fill 285 291 222 288 291 222 minecraft:red_nether_bricks
fill 286 291 182 288 291 182 minecraft:red_nether_bricks
setblock 286 291 215 minecraft:polished_blackstone
fill 286 291 216 286 293 216 minecraft:red_nether_bricks
setblock 286 291 219 minecraft:red_nether_bricks
setblock 286 291 220 minecraft:polished_blackstone
fill 286 291 221 286 294 221 minecraft:red_nether_bricks
setblock 287 291 219 minecraft:polished_blackstone
fill 287 291 220 290 291 220 minecraft:red_nether_bricks
fill 288 291 219 288 294 219 minecraft:red_nether_bricks
setblock 289 291 182 minecraft:polished_blackstone
setblock 289 291 222 minecraft:polished_blackstone
fill 290 291 182 290 294 182 minecraft:red_nether_bricks
setblock 290 291 221 minecraft:polished_blackstone
fill 290 291 222 290 294 222 minecraft:red_nether_bricks
setblock 291 291 219 minecraft:red_nether_bricks
setblock 291 291 220 minecraft:polished_blackstone
fill 291 291 221 291 294 221 minecraft:red_nether_bricks
setblock 292 291 219 minecraft:polished_blackstone
fill 292 291 220 292 294 220 minecraft:red_nether_bricks
setblock 293 291 219 minecraft:red_nether_bricks
setblock 294 291 222 minecraft:polished_blackstone
setblock 295 291 221 minecraft:polished_blackstone
fill 295 291 222 295 294 222 minecraft:red_nether_bricks
setblock 296 291 221 minecraft:red_nether_bricks
fill 306 291 222 308 291 222 minecraft:red_nether_bricks
fill 307 291 182 308 291 182 minecraft:red_nether_bricks
fill 308 291 221 309 291 221 minecraft:red_nether_bricks
setblock 309 291 182 minecraft:polished_blackstone
fill 309 291 183 309 294 183 minecraft:red_nether_bricks
setblock 309 291 222 minecraft:polished_blackstone
fill 310 291 182 313 291 182 minecraft:red_nether_bricks
setblock 310 291 221 minecraft:polished_blackstone
fill 310 291 222 310 294 222 minecraft:red_nether_bricks
fill 311 291 221 311 294 221 minecraft:red_nether_bricks
setblock 313 291 183 minecraft:polished_blackstone
setblock 314 291 182 minecraft:polished_blackstone
fill 314 291 183 314 294 183 minecraft:red_nether_bricks
setblock 314 291 222 minecraft:polished_blackstone
fill 315 291 182 315 294 182 minecraft:red_nether_bricks
setblock 315 291 221 minecraft:polished_blackstone
fill 315 291 222 315 294 222 minecraft:red_nether_bricks
fill 316 291 221 316 293 221 minecraft:red_nether_bricks
setblock 318 291 222 minecraft:red_nether_bricks
setblock 319 291 182 minecraft:polished_blackstone
setblock 319 291 222 minecraft:polished_blackstone
fill 320 291 182 320 294 182 minecraft:red_nether_bricks
fill 320 291 222 320 294 222 minecraft:red_nether_bricks
fill 322 291 217 322 291 218 minecraft:red_nether_bricks
setblock 322 291 219 minecraft:polished_blackstone
fill 322 291 220 322 293 221 minecraft:red_nether_bricks
setblock 323 291 183 minecraft:polished_blackstone
setblock 323 291 188 minecraft:polished_blackstone
setblock 323 291 189 minecraft:red_nether_bricks
setblock 323 291 193 minecraft:polished_blackstone
fill 323 291 194 323 293 194 minecraft:red_nether_bricks
setblock 323 291 198 minecraft:polished_blackstone
setblock 323 291 213 minecraft:polished_blackstone
fill 323 291 214 323 294 214 minecraft:red_nether_bricks
setblock 323 291 218 minecraft:polished_blackstone
fill 323 291 219 323 294 219 minecraft:red_nether_bricks
setblock 283 292 197 minecraft:polished_blackstone
fill 283 292 198 283 294 199 minecraft:red_nether_bricks
setblock 283 292 212 minecraft:polished_blackstone
fill 283 292 213 283 295 213 minecraft:red_nether_bricks
setblock 283 292 217 minecraft:polished_blackstone
fill 283 292 218 283 295 218 minecraft:red_nether_bricks
fill 283 292 220 283 292 221 minecraft:red_nether_bricks
setblock 283 292 222 minecraft:polished_blackstone
fill 284 292 212 284 293 212 minecraft:red_nether_bricks
setblock 284 292 216 minecraft:polished_blackstone
fill 284 292 217 284 295 217 minecraft:red_nether_bricks
setblock 284 292 221 minecraft:polished_blackstone
fill 284 292 222 287 292 222 minecraft:red_nether_bricks
setblock 285 292 184 minecraft:light[level=14]
setblock 285 292 192 minecraft:light[level=14]
setblock 285 292 200 minecraft:light[level=14]
setblock 285 292 208 minecraft:light[level=14]
setblock 285 292 215 minecraft:polished_blackstone
fill 285 292 216 285 295 216 minecraft:red_nether_bricks
setblock 285 292 220 minecraft:polished_blackstone
fill 285 292 221 285 295 221 minecraft:red_nether_bricks
fill 286 292 182 287 292 182 minecraft:red_nether_bricks
setblock 286 292 215 minecraft:red_nether_bricks
setblock 286 292 219 minecraft:polished_blackstone
fill 286 292 220 289 292 220 minecraft:red_nether_bricks
fill 287 292 219 287 295 219 minecraft:red_nether_bricks
setblock 288 292 182 minecraft:polished_blackstone
setblock 288 292 222 minecraft:polished_blackstone
fill 289 292 182 289 295 182 minecraft:red_nether_bricks
setblock 289 292 221 minecraft:polished_blackstone
fill 289 292 222 289 295 222 minecraft:red_nether_bricks
setblock 290 292 220 minecraft:polished_blackstone
fill 290 292 221 290 295 221 minecraft:red_nether_bricks
setblock 291 292 219 minecraft:polished_blackstone
fill 291 292 220 291 295 220 minecraft:red_nether_bricks
setblock 292 292 219 minecraft:red_nether_bricks
setblock 293 292 184 minecraft:light[level=14]
setblock 293 292 192 minecraft:light[level=14]
setblock 293 292 200 minecraft:light[level=14]
setblock 293 292 208 minecraft:light[level=14]
setblock 293 292 216 minecraft:light[level=14]
setblock 293 292 222 minecraft:polished_blackstone
setblock 294 292 221 minecraft:polished_blackstone
fill 294 292 222 294 295 222 minecraft:red_nether_bricks
setblock 295 292 221 minecraft:red_nether_bricks
setblock 301 292 184 minecraft:light[level=14]
setblock 301 292 192 minecraft:light[level=14]
setblock 301 292 200 minecraft:light[level=14]
setblock 301 292 208 minecraft:light[level=14]
setblock 301 292 216 minecraft:light[level=14]
fill 305 292 222 307 292 222 minecraft:red_nether_bricks
fill 306 292 182 307 292 182 minecraft:red_nether_bricks
fill 307 292 221 308 292 221 minecraft:red_nether_bricks
setblock 308 292 182 minecraft:polished_blackstone
fill 308 292 183 308 295 183 minecraft:red_nether_bricks
setblock 308 292 222 minecraft:polished_blackstone
fill 309 292 182 312 292 182 minecraft:red_nether_bricks
setblock 309 292 184 minecraft:light[level=14]
setblock 309 292 192 minecraft:light[level=14]
setblock 309 292 200 minecraft:light[level=14]
setblock 309 292 208 minecraft:light[level=14]
setblock 309 292 216 minecraft:light[level=14]
setblock 309 292 221 minecraft:polished_blackstone
fill 309 292 222 309 295 222 minecraft:red_nether_bricks
fill 310 292 221 310 295 221 minecraft:red_nether_bricks
setblock 312 292 183 minecraft:polished_blackstone
setblock 313 292 182 minecraft:polished_blackstone
fill 313 292 183 313 295 183 minecraft:red_nether_bricks
setblock 313 292 222 minecraft:polished_blackstone
fill 314 292 182 314 295 182 minecraft:red_nether_bricks
setblock 314 292 221 minecraft:polished_blackstone
fill 314 292 222 314 295 222 minecraft:red_nether_bricks
fill 315 292 221 315 294 221 minecraft:red_nether_bricks
setblock 317 292 184 minecraft:light[level=14]
setblock 317 292 192 minecraft:light[level=14]
setblock 317 292 200 minecraft:light[level=14]
setblock 317 292 208 minecraft:light[level=14]
setblock 317 292 216 minecraft:light[level=14]
setblock 318 292 182 minecraft:polished_blackstone
setblock 318 292 222 minecraft:polished_blackstone
fill 319 292 182 319 295 182 minecraft:red_nether_bricks
fill 319 292 222 319 295 222 minecraft:red_nether_bricks
fill 321 292 221 321 294 221 minecraft:red_nether_bricks
setblock 322 292 182 minecraft:red_nether_bricks
setblock 322 292 217 minecraft:red_nether_bricks
setblock 322 292 218 minecraft:polished_blackstone
fill 322 292 219 322 295 219 minecraft:red_nether_bricks
setblock 322 292 222 minecraft:red_nether_bricks
setblock 323 292 182 minecraft:polished_blackstone
fill 323 292 183 323 295 183 minecraft:red_nether_bricks
setblock 323 292 192 minecraft:polished_blackstone
fill 323 292 193 323 293 193 minecraft:red_nether_bricks
setblock 323 292 196 minecraft:red_nether_bricks
setblock 323 292 197 minecraft:polished_blackstone
fill 323 292 198 323 294 198 minecraft:red_nether_bricks
setblock 323 292 213 minecraft:red_nether_bricks
setblock 323 292 217 minecraft:polished_blackstone
fill 323 292 218 323 295 218 minecraft:red_nether_bricks
setblock 323 292 222 minecraft:polished_blackstone
setblock 283 293 195 minecraft:red_nether_bricks
setblock 283 293 196 minecraft:polished_blackstone
fill 283 293 197 283 296 197 minecraft:red_nether_bricks
setblock 283 293 200 minecraft:red_nether_bricks
setblock 283 293 211 minecraft:polished_blackstone
fill 283 293 212 283 296 212 minecraft:red_nether_bricks
setblock 283 293 216 minecraft:polished_blackstone
fill 283 293 217 283 296 217 minecraft:red_nether_bricks
setblock 283 293 220 minecraft:red_nether_bricks
setblock 283 293 221 minecraft:polished_blackstone
fill 283 293 222 286 293 222 minecraft:red_nether_bricks
setblock 284 293 215 minecraft:polished_blackstone
fill 284 293 216 284 296 216 minecraft:red_nether_bricks
setblock 284 293 220 minecraft:polished_blackstone
fill 284 293 221 284 296 221 minecraft:red_nether_bricks
fill 285 293 182 286 293 182 minecraft:red_nether_bricks
setblock 285 293 214 minecraft:polished_blackstone
fill 285 293 215 285 295 215 minecraft:red_nether_bricks
setblock 285 293 218 minecraft:red_nether_bricks
setblock 285 293 219 minecraft:polished_blackstone
fill 285 293 220 288 293 220 minecraft:red_nether_bricks
setblock 286 293 218 minecraft:polished_blackstone
fill 286 293 219 286 294 219 minecraft:red_nether_bricks
setblock 287 293 182 minecraft:polished_blackstone
setblock 287 293 222 minecraft:polished_blackstone
fill 288 293 182 288 296 182 minecraft:red_nether_bricks
setblock 288 293 221 minecraft:polished_blackstone
fill 288 293 222 288 296 222 minecraft:red_nether_bricks
setblock 289 293 220 minecraft:polished_blackstone
fill 289 293 221 289 296 221 minecraft:red_nether_bricks
setblock 290 293 219 minecraft:polished_blackstone
fill 290 293 220 290 296 220 minecraft:red_nether_bricks
setblock 291 293 219 minecraft:red_nether_bricks
setblock 292 293 182 minecraft:polished_blackstone
setblock 292 293 222 minecraft:polished_blackstone
setblock 293 293 221 minecraft:polished_blackstone
fill 293 293 222 293 296 222 minecraft:red_nether_bricks
fill 294 293 221 294 294 221 minecraft:red_nether_bricks
fill 305 293 182 306 293 182 minecraft:red_nether_bricks
fill 305 293 222 306 293 222 minecraft:red_nether_bricks
setblock 307 293 182 minecraft:polished_blackstone
setblock 307 293 221 minecraft:red_nether_bricks
setblock 307 293 222 minecraft:polished_blackstone
fill 308 293 182 311 293 182 minecraft:red_nether_bricks
setblock 308 293 221 minecraft:polished_blackstone
fill 308 293 222 308 296 222 minecraft:red_nether_bricks
fill 309 293 221 309 296 221 minecraft:red_nether_bricks
setblock 311 293 183 minecraft:polished_blackstone
setblock 312 293 182 minecraft:polished_blackstone
fill 312 293 183 312 296 183 minecraft:red_nether_bricks
setblock 312 293 222 minecraft:polished_blackstone
fill 313 293 182 313 296 182 minecraft:red_nether_bricks
setblock 313 293 221 minecraft:polished_blackstone
fill 313 293 222 313 296 222 minecraft:red_nether_bricks
setblock 314 293 218 minecraft:polished_blackstone
setblock 314 293 220 minecraft:polished_blackstone
fill 314 293 221 314 295 221 minecraft:red_nether_bricks
setblock 316 293 218 minecraft:polished_blackstone
setblock 316 293 220 minecraft:polished_blackstone
setblock 317 293 182 minecraft:polished_blackstone
setblock 317 293 222 minecraft:polished_blackstone
fill 318 293 182 318 296 182 minecraft:red_nether_bricks
fill 318 293 222 318 296 222 minecraft:red_nether_bricks
setblock 322 293 182 minecraft:polished_blackstone
setblock 322 293 217 minecraft:polished_blackstone
fill 322 293 218 322 296 218 minecraft:red_nether_bricks
setblock 322 293 222 minecraft:polished_blackstone
fill 323 293 182 323 296 182 minecraft:red_nether_bricks
setblock 323 293 196 minecraft:polished_blackstone
fill 323 293 197 323 294 197 minecraft:red_nether_bricks
setblock 323 293 216 minecraft:polished_blackstone
fill 323 293 217 323 296 217 minecraft:red_nether_bricks
setblock 323 293 221 minecraft:polished_blackstone
fill 323 293 222 323 296 222 minecraft:red_nether_bricks
fill 283 294 196 283 295 196 minecraft:red_nether_bricks
setblock 283 294 200 minecraft:polished_blackstone
fill 283 294 201 283 297 201 minecraft:red_nether_bricks
fill 283 294 211 283 297 211 minecraft:red_nether_bricks
setblock 283 294 215 minecraft:polished_blackstone
fill 283 294 216 283 297 216 minecraft:red_nether_bricks
setblock 283 294 220 minecraft:polished_blackstone
fill 283 294 221 283 296 222 minecraft:red_nether_bricks
setblock 284 294 214 minecraft:polished_blackstone
fill 284 294 215 284 297 215 minecraft:red_nether_bricks
setblock 284 294 219 minecraft:polished_blackstone
fill 284 294 220 287 294 220 minecraft:red_nether_bricks
fill 284 294 222 285 294 222 minecraft:red_nether_bricks
setblock 285 294 182 minecraft:red_nether_bricks
setblock 285 294 218 minecraft:polished_blackstone
fill 285 294 219 285 297 219 minecraft:red_nether_bricks
setblock 286 294 182 minecraft:polished_blackstone
setblock 286 294 217 minecraft:polished_blackstone
setblock 286 294 218 minecraft:red_nether_bricks
setblock 286 294 222 minecraft:polished_blackstone
fill 287 294 182 287 297 182 minecraft:red_nether_bricks
setblock 287 294 221 minecraft:polished_blackstone
fill 287 294 222 287 297 222 minecraft:red_nether_bricks
setblock 288 294 220 minecraft:polished_blackstone
fill 288 294 221 288 297 221 minecraft:red_nether_bricks
setblock 289 294 219 minecraft:polished_blackstone
fill 289 294 220 289 297 220 minecraft:red_nether_bricks
setblock 290 294 219 minecraft:red_nether_bricks
setblock 291 294 182 minecraft:polished_blackstone
setblock 291 294 222 minecraft:polished_blackstone
setblock 292 294 221 minecraft:polished_blackstone
fill 292 294 222 292 297 222 minecraft:red_nether_bricks
fill 293 294 221 293 295 221 minecraft:red_nether_bricks
fill 304 294 222 305 294 222 minecraft:red_nether_bricks
setblock 305 294 182 minecraft:red_nether_bricks
setblock 306 294 182 minecraft:polished_blackstone
setblock 306 294 222 minecraft:polished_blackstone
fill 307 294 182 307 296 183 minecraft:red_nether_bricks
setblock 307 294 221 minecraft:polished_blackstone
fill 307 294 222 307 297 222 minecraft:red_nether_bricks
fill 308 294 182 310 294 182 minecraft:red_nether_bricks
fill 308 294 221 308 297 221 minecraft:red_nether_bricks
setblock 310 294 183 minecraft:polished_blackstone
setblock 311 294 182 minecraft:polished_blackstone
fill 311 294 183 311 297 183 minecraft:red_nether_bricks
setblock 311 294 222 minecraft:polished_blackstone
fill 312 294 182 312 297 182 minecraft:red_nether_bricks
setblock 312 294 221 minecraft:polished_blackstone
fill 312 294 222 312 297 222 minecraft:red_nether_bricks
fill 313 294 221 313 296 221 minecraft:red_nether_bricks
setblock 316 294 182 minecraft:polished_blackstone
setblock 316 294 222 minecraft:polished_blackstone
fill 317 294 182 317 297 182 minecraft:red_nether_bricks
fill 317 294 222 317 297 222 minecraft:red_nether_bricks
setblock 321 294 182 minecraft:polished_blackstone
setblock 321 294 222 minecraft:polished_blackstone
fill 322 294 182 322 297 182 minecraft:red_nether_bricks
setblock 322 294 220 minecraft:red_nether_bricks
setblock 322 294 221 minecraft:polished_blackstone
fill 322 294 222 322 297 222 minecraft:red_nether_bricks
setblock 323 294 195 minecraft:polished_blackstone
setblock 323 294 196 minecraft:red_nether_bricks
setblock 323 294 215 minecraft:polished_blackstone
fill 323 294 216 323 297 216 minecraft:red_nether_bricks
setblock 323 294 220 minecraft:polished_blackstone
fill 323 294 221 323 297 221 minecraft:red_nether_bricks
setblock 283 295 198 minecraft:red_nether_bricks
setblock 283 295 199 minecraft:polished_blackstone
fill 283 295 200 283 298 200 minecraft:red_nether_bricks
fill 283 295 202 283 295 203 minecraft:red_nether_bricks
setblock 283 295 214 minecraft:polished_blackstone
fill 283 295 215 283 298 215 minecraft:red_nether_bricks
setblock 283 295 219 minecraft:polished_blackstone
fill 283 295 220 286 295 220 minecraft:red_nether_bricks
setblock 284 295 182 minecraft:red_nether_bricks
setblock 284 295 213 minecraft:polished_blackstone
fill 284 295 214 284 298 214 minecraft:red_nether_bricks
setblock 284 295 218 minecraft:polished_blackstone
fill 284 295 219 284 298 219 minecraft:red_nether_bricks
setblock 284 295 222 minecraft:red_nether_bricks
setblock 285 295 182 minecraft:polished_blackstone
setblock 285 295 217 minecraft:polished_blackstone
fill 285 295 218 285 298 218 minecraft:red_nether_bricks
setblock 285 295 222 minecraft:polished_blackstone
fill 286 295 182 286 298 182 minecraft:red_nether_bricks
setblock 286 295 221 minecraft:polished_blackstone
fill 286 295 222 286 298 222 minecraft:red_nether_bricks
setblock 287 295 220 minecraft:polished_blackstone
fill 287 295 221 287 298 221 minecraft:red_nether_bricks
setblock 288 295 219 minecraft:polished_blackstone
fill 288 295 220 288 298 220 minecraft:red_nether_bricks
setblock 290 295 182 minecraft:polished_blackstone
setblock 290 295 222 minecraft:polished_blackstone
setblock 291 295 221 minecraft:polished_blackstone
fill 291 295 222 291 298 222 minecraft:red_nether_bricks
fill 292 295 221 292 296 221 minecraft:red_nether_bricks
setblock 304 295 182 minecraft:red_nether_bricks
setblock 304 295 222 minecraft:red_nether_bricks
setblock 305 295 182 minecraft:polished_blackstone
setblock 305 295 222 minecraft:polished_blackstone
fill 306 295 182 306 298 182 minecraft:red_nether_bricks
setblock 306 295 221 minecraft:polished_blackstone
fill 306 295 222 306 298 222 minecraft:red_nether_bricks
fill 307 295 221 307 298 221 minecraft:red_nether_bricks
fill 308 295 182 309 295 182 minecraft:red_nether_bricks
setblock 309 295 183 minecraft:polished_blackstone
setblock 310 295 182 minecraft:polished_blackstone
fill 310 295 183 310 298 183 minecraft:red_nether_bricks
setblock 310 295 222 minecraft:polished_blackstone
fill 311 295 182 311 298 182 minecraft:red_nether_bricks
setblock 311 295 221 minecraft:polished_blackstone
fill 311 295 222 311 298 222 minecraft:red_nether_bricks
fill 312 295 221 312 298 221 minecraft:red_nether_bricks
setblock 315 295 182 minecraft:polished_blackstone
setblock 315 295 222 minecraft:polished_blackstone
fill 316 295 182 316 298 182 minecraft:red_nether_bricks
fill 316 295 222 316 298 222 minecraft:red_nether_bricks
setblock 320 295 182 minecraft:polished_blackstone
setblock 320 295 222 minecraft:polished_blackstone
fill 321 295 182 321 298 182 minecraft:red_nether_bricks
setblock 321 295 221 minecraft:polished_blackstone
fill 321 295 222 321 298 222 minecraft:red_nether_bricks
setblock 322 295 220 minecraft:polished_blackstone
fill 322 295 221 322 298 221 minecraft:red_nether_bricks
fill 323 295 215 323 298 215 minecraft:red_nether_bricks
setblock 323 295 219 minecraft:polished_blackstone
fill 323 295 220 323 298 220 minecraft:red_nether_bricks
setblock 283 296 182 minecraft:red_nether_bricks
setblock 283 296 198 minecraft:polished_blackstone
fill 283 296 199 284 298 199 minecraft:red_nether_bricks
setblock 283 296 202 minecraft:red_nether_bricks
setblock 283 296 203 minecraft:polished_blackstone
fill 283 296 204 283 298 205 minecraft:red_nether_bricks
setblock 283 296 213 minecraft:polished_blackstone
fill 283 296 214 283 299 214 minecraft:red_nether_bricks
setblock 283 296 218 minecraft:polished_blackstone
fill 283 296 219 283 298 220 minecraft:red_nether_bricks
setblock 284 296 182 minecraft:polished_blackstone
fill 284 296 200 284 296 201 minecraft:red_nether_bricks
setblock 284 296 202 minecraft:polished_blackstone
setblock 284 296 217 minecraft:polished_blackstone
fill 284 296 218 284 299 218 minecraft:red_nether_bricks
fill 284 296 220 285 296 220 minecraft:red_nether_bricks
setblock 284 296 222 minecraft:polished_blackstone
fill 285 296 182 285 299 182 minecraft:red_nether_bricks
setblock 285 296 216 minecraft:polished_blackstone
fill 285 296 217 285 298 217 minecraft:red_nether_bricks
setblock 285 296 221 minecraft:polished_blackstone
fill 285 296 222 285 299 222 minecraft:red_nether_bricks
setblock 286 296 220 minecraft:polished_blackstone
fill 286 296 221 286 299 221 minecraft:red_nether_bricks
fill 287 296 220 287 299 220 minecraft:red_nether_bricks
setblock 289 296 182 minecraft:polished_blackstone
setblock 289 296 222 minecraft:polished_blackstone
fill 290 296 182 290 299 182 minecraft:red_nether_bricks
setblock 290 296 221 minecraft:polished_blackstone
fill 290 296 222 290 299 222 minecraft:red_nether_bricks
fill 291 296 221 291 298 221 minecraft:red_nether_bricks
setblock 294 296 222 minecraft:polished_blackstone
setblock 303 296 182 minecraft:red_nether_bricks
setblock 303 296 222 minecraft:red_nether_bricks
setblock 304 296 182 minecraft:polished_blackstone
setblock 304 296 222 minecraft:polished_blackstone
fill 305 296 182 305 299 182 minecraft:red_nether_bricks
fill 305 296 222 305 299 222 minecraft:red_nether_bricks
fill 306 296 183 306 297 183 minecraft:red_nether_bricks
fill 306 296 221 306 299 221 minecraft:red_nether_bricks
setblock 308 296 182 minecraft:red_nether_bricks
setblock 308 296 183 minecraft:polished_blackstone
setblock 309 296 182 minecraft:polished_blackstone
fill 309 296 183 309 299 183 minecraft:red_nether_bricks
setblock 309 296 222 minecraft:polished_blackstone
fill 310 296 182 310 299 182 minecraft:red_nether_bricks
setblock 310 296 221 minecraft:polished_blackstone
fill 310 296 222 310 299 222 minecraft:red_nether_bricks
fill 311 296 221 311 299 221 minecraft:red_nether_bricks
setblock 313 296 183 minecraft:polished_blackstone
setblock 314 296 182 minecraft:polished_blackstone
setblock 314 296 222 minecraft:polished_blackstone
fill 315 296 182 315 299 182 minecraft:red_nether_bricks
fill 315 296 222 315 299 222 minecraft:red_nether_bricks
setblock 319 296 182 minecraft:polished_blackstone
setblock 319 296 222 minecraft:polished_blackstone
fill 320 296 182 320 299 182 minecraft:red_nether_bricks
setblock 320 296 221 minecraft:polished_blackstone
fill 320 296 222 320 299 222 minecraft:red_nether_bricks
fill 321 296 221 321 299 221 minecraft:red_nether_bricks
setblock 322 296 219 minecraft:polished_blackstone
fill 322 296 220 322 299 220 minecraft:red_nether_bricks
setblock 323 296 183 minecraft:polished_blackstone
fill 323 296 184 323 299 184 minecraft:red_nether_bricks
setblock 323 296 218 minecraft:polished_blackstone
fill 323 296 219 323 299 219 minecraft:red_nether_bricks
setblock 283 297 182 minecraft:polished_blackstone
setblock 283 297 197 minecraft:polished_blackstone
fill 283 297 198 284 299 198 minecraft:red_nether_bricks
setblock 283 297 202 minecraft:polished_blackstone
fill 283 297 203 284 299 203 minecraft:red_nether_bricks
setblock 283 297 206 minecraft:red_nether_bricks
setblock 283 297 207 minecraft:polished_blackstone
fill 283 297 208 283 298 210 minecraft:red_nether_bricks
setblock 283 297 212 minecraft:polished_blackstone
fill 283 297 213 283 300 213 minecraft:red_nether_bricks
setblock 283 297 217 minecraft:polished_blackstone
fill 283 297 218 283 300 218 minecraft:red_nether_bricks
setblock 283 297 221 minecraft:red_nether_bricks
setblock 283 297 222 minecraft:polished_blackstone
fill 284 297 182 284 300 182 minecraft:red_nether_bricks
setblock 284 297 200 minecraft:red_nether_bricks
setblock 284 297 201 minecraft:polished_blackstone
fill 284 297 202 284 300 202 minecraft:red_nether_bricks
fill 284 297 204 284 297 205 minecraft:red_nether_bricks
setblock 284 297 216 minecraft:polished_blackstone
fill 284 297 217 284 300 217 minecraft:red_nether_bricks
setblock 284 297 220 minecraft:red_nether_bricks
setblock 284 297 221 minecraft:polished_blackstone
fill 284 297 222 284 300 222 minecraft:red_nether_bricks
setblock 285 297 220 minecraft:polished_blackstone
fill 285 297 221 285 300 221 minecraft:red_nether_bricks
fill 286 297 220 286 300 220 minecraft:red_nether_bricks
setblock 288 297 182 minecraft:polished_blackstone
setblock 288 297 222 minecraft:polished_blackstone
fill 289 297 182 289 300 182 minecraft:red_nether_bricks
setblock 289 297 221 minecraft:polished_blackstone
fill 289 297 222 289 300 222 minecraft:red_nether_bricks
fill 290 297 221 290 300 221 minecraft:red_nether_bricks
setblock 293 297 222 minecraft:polished_blackstone
setblock 303 297 182 minecraft:polished_blackstone
setblock 303 297 222 minecraft:polished_blackstone
fill 304 297 182 304 300 182 minecraft:red_nether_bricks
fill 304 297 222 304 300 222 minecraft:red_nether_bricks
fill 305 297 183 305 298 183 minecraft:red_nether_bricks
setblock 307 297 182 minecraft:red_nether_bricks
setblock 307 297 183 minecraft:polished_blackstone
setblock 308 297 182 minecraft:polished_blackstone
fill 308 297 183 308 300 183 minecraft:red_nether_bricks
setblock 308 297 222 minecraft:polished_blackstone
fill 309 297 182 309 300 182 minecraft:red_nether_bricks
fill 309 297 220 311 299 220 minecraft:magma_block
setblock 309 297 221 minecraft:polished_blackstone
fill 309 297 222 309 300 222 minecraft:red_nether_bricks
fill 310 297 216 310 297 219 minecraft:magma_block
fill 310 297 221 310 300 221 minecraft:red_nether_bricks
setblock 312 297 183 minecraft:polished_blackstone
setblock 313 297 182 minecraft:polished_blackstone
fill 313 297 183 313 300 183 minecraft:red_nether_bricks
setblock 313 297 222 minecraft:polished_blackstone
fill 314 297 182 314 300 182 minecraft:red_nether_bricks
fill 314 297 222 314 300 222 minecraft:red_nether_bricks
setblock 318 297 182 minecraft:polished_blackstone
setblock 318 297 222 minecraft:polished_blackstone
fill 319 297 182 319 300 182 minecraft:red_nether_bricks
fill 319 297 222 319 300 222 minecraft:red_nether_bricks
fill 320 297 221 320 300 221 minecraft:red_nether_bricks
setblock 322 297 218 minecraft:polished_blackstone
fill 322 297 219 322 300 219 minecraft:red_nether_bricks
setblock 323 297 182 minecraft:polished_blackstone
fill 323 297 183 323 300 183 minecraft:red_nether_bricks
fill 323 297 199 323 297 201 minecraft:red_nether_bricks
setblock 323 297 217 minecraft:polished_blackstone
fill 323 297 218 323 300 218 minecraft:red_nether_bricks
setblock 323 297 222 minecraft:polished_blackstone
fill 283 298 182 283 300 183 minecraft:red_nether_bricks
setblock 283 298 196 minecraft:polished_blackstone
fill 283 298 197 283 300 197 minecraft:red_nether_bricks
setblock 283 298 201 minecraft:polished_blackstone
fill 283 298 202 283 300 202 minecraft:red_nether_bricks
setblock 283 298 206 minecraft:polished_blackstone
fill 283 298 207 284 300 207 minecraft:red_nether_bricks
setblock 283 298 211 minecraft:polished_blackstone
fill 283 298 212 283 300 212 minecraft:red_nether_bricks
setblock 283 298 216 minecraft:polished_blackstone
fill 283 298 217 283 300 217 minecraft:red_nether_bricks
setblock 283 298 221 minecraft:polished_blackstone
fill 283 298 222 283 300 222 minecraft:red_nether_bricks
setblock 284 298 200 minecraft:polished_blackstone
fill 284 298 201 285 300 201 minecraft:red_nether_bricks
setblock 284 298 204 minecraft:red_nether_bricks
setblock 284 298 205 minecraft:polished_blackstone
fill 284 298 206 284 300 206 minecraft:red_nether_bricks
setblock 284 298 215 minecraft:polished_blackstone
fill 284 298 216 284 300 216 minecraft:red_nether_bricks
setblock 284 298 220 minecraft:polished_blackstone
fill 284 298 221 284 300 221 minecraft:red_nether_bricks
fill 285 298 200 285 300 200 minecraft:red_nether_bricks
fill 285 298 202 285 298 203 minecraft:red_nether_bricks
setblock 285 298 204 minecraft:polished_blackstone
setblock 285 298 219 minecraft:polished_blackstone
fill 285 298 220 285 300 220 minecraft:red_nether_bricks
setblock 287 298 182 minecraft:polished_blackstone
setblock 287 298 222 minecraft:polished_blackstone
fill 288 298 182 288 300 182 minecraft:red_nether_bricks
setblock 288 298 221 minecraft:polished_blackstone
fill 288 298 222 288 300 222 minecraft:red_nether_bricks
fill 289 298 221 289 300 221 minecraft:red_nether_bricks
setblock 292 298 222 minecraft:polished_blackstone
setblock 293 298 222 minecraft:red_nether_bricks
setblock 301 298 182 minecraft:red_nether_bricks
setblock 302 298 182 minecraft:polished_blackstone
setblock 302 298 222 minecraft:polished_blackstone
fill 303 298 182 303 300 182 minecraft:red_nether_bricks
fill 303 298 222 303 300 222 minecraft:red_nether_bricks
fill 304 298 183 304 299 183 minecraft:red_nether_bricks
fill 305 298 221 305 300 221 minecraft:red_nether_bricks
setblock 306 298 183 minecraft:polished_blackstone
setblock 307 298 182 minecraft:polished_blackstone
fill 307 298 183 307 300 183 minecraft:red_nether_bricks
setblock 307 298 222 minecraft:polished_blackstone
fill 308 298 182 308 300 182 minecraft:red_nether_bricks
fill 308 298 184 308 299 184 minecraft:red_nether_bricks
setblock 308 298 221 minecraft:polished_blackstone
fill 308 298 222 308 300 222 minecraft:red_nether_bricks
fill 309 298 218 311 298 219 minecraft:magma_block
fill 309 298 221 309 300 221 minecraft:red_nether_bricks
setblock 310 298 217 minecraft:magma_block
setblock 311 298 183 minecraft:polished_blackstone
setblock 312 298 182 minecraft:polished_blackstone
fill 312 298 183 312 300 183 minecraft:red_nether_bricks
setblock 312 298 222 minecraft:polished_blackstone
fill 313 298 182 313 300 182 minecraft:red_nether_bricks
fill 313 298 222 313 300 222 minecraft:red_nether_bricks
setblock 317 298 182 minecraft:polished_blackstone
setblock 317 298 222 minecraft:polished_blackstone
fill 318 298 182 318 300 182 minecraft:red_nether_bricks
fill 318 298 222 318 300 222 minecraft:red_nether_bricks
fill 319 298 221 319 300 221 minecraft:red_nether_bricks
setblock 322 298 182 minecraft:polished_blackstone
fill 322 298 218 322 300 218 minecraft:red_nether_bricks
setblock 322 298 222 minecraft:polished_blackstone
fill 323 298 182 323 300 182 minecraft:red_nether_bricks
setblock 323 298 185 minecraft:red_nether_bricks
fill 323 298 198 323 298 200 minecraft:red_nether_bricks
setblock 323 298 201 minecraft:polished_blackstone
fill 323 298 202 323 299 204 minecraft:red_nether_bricks
fill 323 298 214 323 299 214 minecraft:red_nether_bricks
setblock 323 298 216 minecraft:polished_blackstone
fill 323 298 217 323 300 217 minecraft:red_nether_bricks
setblock 323 298 221 minecraft:polished_blackstone
fill 323 298 222 323 300 222 minecraft:red_nether_bricks
setblock 283 299 184 minecraft:red_nether_bricks
fill 283 299 196 283 300 196 minecraft:red_nether_bricks
setblock 283 299 199 minecraft:red_nether_bricks
setblock 283 299 200 minecraft:polished_blackstone
fill 283 299 201 283 300 201 minecraft:red_nether_bricks
setblock 283 299 204 minecraft:red_nether_bricks
setblock 283 299 205 minecraft:polished_blackstone
fill 283 299 206 283 300 206 minecraft:red_nether_bricks
fill 283 299 208 283 299 209 minecraft:red_nether_bricks
setblock 283 299 210 minecraft:polished_blackstone
fill 283 299 211 284 300 211 minecraft:red_nether_bricks
setblock 283 299 215 minecraft:polished_blackstone
fill 283 299 216 283 300 216 minecraft:red_nether_bricks
setblock 283 299 219 minecraft:red_nether_bricks
setblock 283 299 220 minecraft:polished_blackstone
fill 283 299 221 283 300 221 minecraft:red_nether_bricks
setblock 284 299 199 minecraft:polished_blackstone
fill 284 299 200 284 300 200 minecraft:red_nether_bricks
setblock 284 299 204 minecraft:polished_blackstone
fill 284 299 205 285 300 205 minecraft:red_nether_bricks
setblock 284 299 208 minecraft:red_nether_bricks
setblock 284 299 209 minecraft:polished_blackstone
fill 284 299 210 284 300 210 minecraft:red_nether_bricks
fill 284 299 212 284 299 213 minecraft:red_nether_bricks
setblock 284 299 214 minecraft:polished_blackstone
fill 284 299 215 284 300 215 minecraft:red_nether_bricks
setblock 284 299 219 minecraft:polished_blackstone
fill 284 299 220 284 300 220 minecraft:red_nether_bricks
fill 285 299 199 285 300 199 minecraft:red_nether_bricks
setblock 285 299 202 minecraft:red_nether_bricks
setblock 285 299 203 minecraft:polished_blackstone
fill 285 299 204 285 300 204 minecraft:red_nether_bricks
fill 285 299 206 285 300 206 minecraft:red_nether_bricks
setblock 285 299 218 minecraft:polished_blackstone
fill 285 299 219 285 300 219 minecraft:red_nether_bricks
setblock 286 299 182 minecraft:polished_blackstone
setblock 286 299 222 minecraft:polished_blackstone
fill 287 299 182 287 300 182 minecraft:red_nether_bricks
setblock 287 299 221 minecraft:polished_blackstone
fill 287 299 222 287 300 222 minecraft:red_nether_bricks
setblock 288 299 220 minecraft:polished_blackstone
fill 288 299 221 288 300 221 minecraft:red_nether_bricks
setblock 291 299 182 minecraft:polished_blackstone
setblock 291 299 222 minecraft:polished_blackstone
fill 292 299 222 292 300 222 minecraft:red_nether_bricks
setblock 300 299 182 minecraft:red_nether_bricks
setblock 301 299 182 minecraft:polished_blackstone
setblock 301 299 222 minecraft:polished_blackstone
fill 302 299 182 302 300 183 minecraft:red_nether_bricks
fill 302 299 222 302 300 222 minecraft:red_nether_bricks
fill 303 299 183 303 300 183 minecraft:red_nether_bricks
fill 304 299 221 304 300 221 minecraft:red_nether_bricks
setblock 305 299 183 minecraft:polished_blackstone
fill 305 299 184 307 300 184 minecraft:red_nether_bricks
setblock 306 299 182 minecraft:polished_blackstone
fill 306 299 183 306 300 183 minecraft:red_nether_bricks
setblock 306 299 222 minecraft:polished_blackstone
fill 307 299 182 307 300 182 minecraft:red_nether_bricks
setblock 307 299 221 minecraft:polished_blackstone
fill 307 299 222 307 300 222 minecraft:red_nether_bricks
fill 308 299 221 308 300 221 minecraft:red_nether_bricks
setblock 309 299 184 minecraft:polished_blackstone
setblock 310 299 183 minecraft:polished_blackstone
fill 310 299 184 310 300 184 minecraft:red_nether_bricks
setblock 310 299 219 minecraft:magma_block
setblock 311 299 182 minecraft:polished_blackstone
fill 311 299 183 311 300 183 minecraft:red_nether_bricks
setblock 311 299 222 minecraft:polished_blackstone
fill 312 299 182 312 300 182 minecraft:red_nether_bricks
setblock 312 299 221 minecraft:polished_blackstone
fill 312 299 222 312 300 222 minecraft:red_nether_bricks
setblock 314 299 183 minecraft:red_nether_bricks
setblock 316 299 182 minecraft:polished_blackstone
setblock 316 299 222 minecraft:polished_blackstone
fill 317 299 182 317 300 182 minecraft:red_nether_bricks
fill 317 299 222 317 300 222 minecraft:red_nether_bricks
setblock 321 299 182 minecraft:polished_blackstone
fill 321 299 183 322 300 183 minecraft:red_nether_bricks
setblock 321 299 222 minecraft:polished_blackstone
fill 322 299 182 322 300 182 minecraft:red_nether_bricks
setblock 322 299 221 minecraft:polished_blackstone
fill 322 299 222 322 300 222 minecraft:red_nether_bricks
setblock 323 299 185 minecraft:polished_blackstone
fill 323 299 186 323 300 186 minecraft:red_nether_bricks
fill 323 299 198 323 299 199 minecraft:red_nether_bricks
setblock 323 299 200 minecraft:polished_blackstone
fill 323 299 201 323 300 201 minecraft:red_nether_bricks
setblock 323 299 205 minecraft:polished_blackstone
fill 323 299 206 323 300 207 minecraft:red_nether_bricks
fill 323 299 213 323 300 213 minecraft:red_nether_bricks
setblock 323 299 215 minecraft:polished_blackstone
fill 323 299 216 323 300 216 minecraft:red_nether_bricks
setblock 323 299 220 minecraft:polished_blackstone
fill 323 299 221 323 300 221 minecraft:red_nether_bricks
setblock 283 300 184 minecraft:polished_blackstone
fill 283 300 185 283 300 186 minecraft:red_nether_bricks
setblock 283 300 198 minecraft:red_nether_bricks
setblock 283 300 199 minecraft:polished_blackstone
setblock 283 300 200 minecraft:red_nether_bricks
setblock 283 300 203 minecraft:red_nether_bricks
setblock 283 300 204 minecraft:polished_blackstone
setblock 283 300 205 minecraft:red_nether_bricks
setblock 283 300 208 minecraft:red_nether_bricks
setblock 283 300 209 minecraft:polished_blackstone
setblock 283 300 210 minecraft:red_nether_bricks
setblock 283 300 214 minecraft:polished_blackstone
setblock 283 300 215 minecraft:red_nether_bricks
setblock 283 300 219 minecraft:polished_blackstone
setblock 283 300 220 minecraft:red_nether_bricks
setblock 284 300 183 minecraft:polished_blackstone
setblock 284 300 197 minecraft:red_nether_bricks
setblock 284 300 198 minecraft:polished_blackstone
setblock 284 300 199 minecraft:red_nether_bricks
setblock 284 300 203 minecraft:polished_blackstone
setblock 284 300 204 minecraft:red_nether_bricks
setblock 284 300 208 minecraft:polished_blackstone
fill 284 300 209 285 300 209 minecraft:red_nether_bricks
setblock 284 300 212 minecraft:red_nether_bricks
setblock 284 300 213 minecraft:polished_blackstone
setblock 284 300 214 minecraft:red_nether_bricks
setblock 284 300 218 minecraft:polished_blackstone
setblock 284 300 219 minecraft:red_nether_bricks
setblock 285 300 182 minecraft:polished_blackstone
fill 285 300 183 287 300 183 minecraft:red_nether_bricks
setblock 285 300 184 minecraft:light[level=14]
setblock 285 300 192 minecraft:light[level=14]
setblock 285 300 202 minecraft:polished_blackstone
fill 285 300 203 286 300 203 minecraft:red_nether_bricks
setblock 285 300 207 minecraft:polished_blackstone
setblock 285 300 208 minecraft:red_nether_bricks
setblock 285 300 216 minecraft:light[level=14]
setblock 285 300 218 minecraft:red_nether_bricks
setblock 285 300 222 minecraft:polished_blackstone
setblock 286 300 182 minecraft:red_nether_bricks
setblock 286 300 201 minecraft:polished_blackstone
setblock 286 300 202 minecraft:red_nether_bricks
fill 286 300 204 286 300 205 minecraft:red_nether_bricks
setblock 286 300 221 minecraft:polished_blackstone
setblock 286 300 222 minecraft:red_nether_bricks
setblock 287 300 220 minecraft:polished_blackstone
setblock 287 300 221 minecraft:red_nether_bricks
setblock 290 300 182 minecraft:polished_blackstone
setblock 290 300 222 minecraft:polished_blackstone
setblock 291 300 182 minecraft:red_nether_bricks
setblock 291 300 222 minecraft:red_nether_bricks
setblock 293 300 184 minecraft:light[level=14]
setblock 293 300 192 minecraft:light[level=14]
setblock 293 300 200 minecraft:light[level=14]
setblock 293 300 208 minecraft:light[level=14]
setblock 293 300 216 minecraft:light[level=14]
setblock 299 300 182 minecraft:red_nether_bricks
setblock 300 300 182 minecraft:polished_blackstone
setblock 300 300 222 minecraft:polished_blackstone
fill 301 300 182 301 300 183 minecraft:red_nether_bricks
setblock 301 300 184 minecraft:light[level=14]
setblock 301 300 192 minecraft:light[level=14]
setblock 301 300 200 minecraft:light[level=14]
setblock 301 300 208 minecraft:light[level=14]
setblock 301 300 216 minecraft:light[level=14]
setblock 301 300 222 minecraft:red_nether_bricks
setblock 303 300 184 minecraft:polished_blackstone
setblock 304 300 183 minecraft:polished_blackstone
setblock 304 300 184 minecraft:red_nether_bricks
setblock 305 300 182 minecraft:polished_blackstone
setblock 305 300 183 minecraft:red_nether_bricks
setblock 305 300 222 minecraft:polished_blackstone
setblock 306 300 182 minecraft:red_nether_bricks
setblock 306 300 221 minecraft:polished_blackstone
setblock 306 300 222 minecraft:red_nether_bricks
setblock 307 300 221 minecraft:red_nether_bricks
setblock 308 300 184 minecraft:polished_blackstone
setblock 309 300 183 minecraft:polished_blackstone
setblock 309 300 184 minecraft:red_nether_bricks
setblock 309 300 192 minecraft:light[level=14]
setblock 309 300 200 minecraft:light[level=14]
setblock 309 300 208 minecraft:light[level=14]
setblock 309 300 216 minecraft:light[level=14]
setblock 310 300 182 minecraft:polished_blackstone
setblock 310 300 183 minecraft:red_nether_bricks
setblock 310 300 220 minecraft:magma_block
setblock 310 300 222 minecraft:polished_blackstone
setblock 311 300 182 minecraft:red_nether_bricks
setblock 311 300 184 minecraft:red_nether_bricks
setblock 311 300 221 minecraft:polished_blackstone
setblock 311 300 222 minecraft:red_nether_bricks
setblock 312 300 221 minecraft:red_nether_bricks
setblock 314 300 183 minecraft:polished_blackstone
setblock 315 300 182 minecraft:polished_blackstone
fill 315 300 183 318 300 183 minecraft:red_nether_bricks
setblock 315 300 222 minecraft:polished_blackstone
setblock 316 300 182 minecraft:red_nether_bricks
setblock 316 300 222 minecraft:red_nether_bricks
setblock 317 300 184 minecraft:light[level=14]
setblock 317 300 192 minecraft:light[level=14]
setblock 317 300 200 minecraft:light[level=14]
setblock 317 300 208 minecraft:light[level=14]
setblock 317 300 216 minecraft:light[level=14]
setblock 318 300 221 minecraft:red_nether_bricks
setblock 319 300 183 minecraft:polished_blackstone
setblock 320 300 182 minecraft:polished_blackstone
setblock 320 300 183 minecraft:red_nether_bricks
setblock 320 300 222 minecraft:polished_blackstone
setblock 321 300 182 minecraft:red_nether_bricks
setblock 321 300 221 minecraft:polished_blackstone
setblock 321 300 222 minecraft:red_nether_bricks
setblock 322 300 184 minecraft:red_nether_bricks
setblock 322 300 185 minecraft:polished_blackstone
setblock 322 300 217 minecraft:red_nether_bricks
setblock 322 300 220 minecraft:polished_blackstone
setblock 322 300 221 minecraft:red_nether_bricks
setblock 323 300 184 minecraft:polished_blackstone
setblock 323 300 185 minecraft:red_nether_bricks
setblock 323 300 187 minecraft:red_nether_bricks
fill 323 300 197 323 300 198 minecraft:red_nether_bricks
setblock 323 300 199 minecraft:polished_blackstone
setblock 323 300 200 minecraft:red_nether_bricks
fill 323 300 202 323 300 203 minecraft:red_nether_bricks
setblock 323 300 204 minecraft:polished_blackstone
setblock 323 300 205 minecraft:red_nether_bricks
setblock 323 300 208 minecraft:red_nether_bricks
setblock 323 300 209 minecraft:polished_blackstone
fill 323 300 210 323 300 212 minecraft:red_nether_bricks
setblock 323 300 214 minecraft:polished_blackstone
setblock 323 300 215 minecraft:red_nether_bricks
setblock 323 300 219 minecraft:polished_blackstone
setblock 323 300 220 minecraft:red_nether_bricks
