setblock 413 220 314 minecraft:shroomlight
fill 414 220 302 414 237 302 minecraft:stripped_oak_log
setblock 414 220 303 minecraft:shroomlight
fill 414 220 304 414 237 304 minecraft:stripped_oak_log
setblock 414 220 305 minecraft:shroomlight
fill 414 220 306 414 237 306 minecraft:stripped_oak_log
setblock 414 220 307 minecraft:shroomlight
fill 414 220 308 414 237 308 minecraft:stripped_oak_log
setblock 414 220 309 minecraft:shroomlight
fill 414 220 310 414 237 310 minecraft:stripped_oak_log
setblock 414 220 311 minecraft:shroomlight
fill 414 220 312 414 237 312 minecraft:stripped_oak_log
setblock 414 220 313 minecraft:shroomlight
fill 414 220 314 414 237 314 minecraft:stripped_oak_log
setblock 415 220 302 minecraft:shroomlight
fill 415 220 303 415 234 303 minecraft:stripped_oak_log
setblock 415 220 304 minecraft:shroomlight
fill 415 220 305 415 235 305 minecraft:stripped_oak_log
setblock 415 220 306 minecraft:shroomlight
fill 415 220 307 415 236 307 minecraft:stripped_oak_log
setblock 415 220 308 minecraft:shroomlight
fill 415 220 309 415 237 309 minecraft:stripped_oak_log
setblock 415 220 310 minecraft:shroomlight
fill 415 220 311 415 237 311 minecraft:stripped_oak_log
setblock 415 220 312 minecraft:shroomlight
fill 415 220 313 415 237 313 minecraft:stripped_oak_log
setblock 415 220 314 minecraft:shroomlight
fill 416 220 290 416 220 293 minecraft:red_terracotta
setblock 416 220 294 minecraft:stripped_oak_log
fill 416 220 295 417 220 297 minecraft:red_terracotta
fill 416 220 302 416 224 302 minecraft:stripped_oak_log
setblock 416 220 303 minecraft:shroomlight
fill 416 220 304 416 231 304 minecraft:stripped_oak_log
setblock 416 220 305 minecraft:shroomlight
fill 416 220 306 416 233 306 minecraft:stripped_oak_log
setblock 416 220 307 minecraft:shroomlight
fill 416 220 308 416 234 308 minecraft:stripped_oak_log
setblock 416 220 309 minecraft:shroomlight
fill 416 220 310 416 236 310 minecraft:stripped_oak_log
setblock 416 220 311 minecraft:shroomlight
fill 416 220 312 416 237 312 minecraft:stripped_oak_log
setblock 416 220 313 minecraft:shroomlight
fill 416 220 314 416 237 314 minecraft:stripped_oak_log
setblock 417 220 287 minecraft:red_terracotta
setblock 417 220 288 minecraft:stripped_oak_log
fill 417 220 289 417 220 292 minecraft:red_terracotta
setblock 417 220 293 minecraft:stripped_oak_log
fill 417 220 294 417 223 294 minecraft:red_terracotta
setblock 417 220 298 minecraft:stripped_oak_log
fill 417 220 299 417 222 300 minecraft:red_terracotta
setblock 417 220 302 minecraft:shroomlight
fill 417 220 303 417 222 303 minecraft:stripped_oak_log
setblock 417 220 304 minecraft:shroomlight
fill 417 220 305 417 224 305 minecraft:stripped_oak_log
setblock 417 220 306 minecraft:shroomlight
fill 417 220 307 417 231 307 minecraft:stripped_oak_log
setblock 417 220 308 minecraft:shroomlight
fill 417 220 309 417 234 309 minecraft:stripped_oak_log
setblock 417 220 310 minecraft:shroomlight
fill 417 220 311 417 234 311 minecraft:stripped_oak_log
setblock 417 220 312 minecraft:shroomlight
setblock 417 220 313 minecraft:stripped_oak_log
setblock 417 220 314 minecraft:shroomlight
fill 418 220 276 418 223 316 minecraft:light_gray_terracotta
setblock 377 221 276 minecraft:red_terracotta
setblock 377 221 277 minecraft:stripped_oak_log
fill 377 221 278 377 221 281 minecraft:red_terracotta
setblock 377 221 282 minecraft:stripped_oak_log
fill 377 221 283 377 221 286 minecraft:red_terracotta
setblock 377 221 287 minecraft:stripped_oak_log
fill 377 221 288 377 221 291 minecraft:red_terracotta
setblock 377 221 292 minecraft:stripped_oak_log
fill 377 221 293 377 224 293 minecraft:red_terracotta
fill 377 221 295 377 221 296 minecraft:red_terracotta
setblock 377 221 297 minecraft:stripped_oak_log
fill 377 221 298 377 223 299 minecraft:red_terracotta
fill 377 221 313 377 224 313 minecraft:red_terracotta
setblock 378 221 276 minecraft:stripped_oak_log
fill 378 221 277 378 222 279 minecraft:red_terracotta
setblock 378 221 281 minecraft:stripped_oak_log
setblock 378 221 283 minecraft:stripped_oak_log
setblock 378 221 286 minecraft:stripped_oak_log
fill 378 221 287 378 221 290 minecraft:red_terracotta
setblock 378 221 291 minecraft:stripped_oak_log
fill 378 221 292 378 224 292 minecraft:red_terracotta
setblock 378 221 296 minecraft:stripped_oak_log
fill 378 221 297 378 224 297 minecraft:red_terracotta
setblock 378 221 315 minecraft:red_terracotta
setblock 378 221 316 minecraft:stripped_oak_log
fill 379 221 276 379 222 276 minecraft:red_terracotta
setblock 379 221 278 minecraft:stripped_oak_log
fill 379 221 280 379 222 280 minecraft:stripped_oak_log
fill 379 221 282 379 222 282 minecraft:stripped_oak_log
fill 379 221 284 379 222 284 minecraft:stripped_oak_log
setblock 379 221 285 minecraft:light[level=12]
fill 379 221 288 382 231 288 minecraft:stripped_oak_log
setblock 379 221 289 minecraft:red_terracotta
setblock 379 221 290 minecraft:stripped_oak_log
fill 379 221 291 379 224 291 minecraft:red_terracotta
setblock 379 221 294 minecraft:red_terracotta
fill 379 221 295 382 221 295 minecraft:stripped_oak_log
setblock 379 221 299 minecraft:light[level=12]
setblock 379 221 306 minecraft:light[level=12]
setblock 379 221 313 minecraft:light[level=12]
setblock 379 221 315 minecraft:stripped_oak_log
fill 379 221 316 382 221 316 minecraft:red_terracotta
fill 380 221 277 380 221 278 minecraft:red_terracotta
fill 380 221 279 380 222 279 minecraft:stripped_oak_log
fill 380 221 281 380 222 281 minecraft:stripped_oak_log
fill 380 221 283 380 222 283 minecraft:stripped_oak_log
fill 380 221 289 382 231 289 minecraft:stripped_oak_log
fill 380 221 291 382 231 291 minecraft:stripped_oak_log
fill 380 221 294 382 231 294 minecraft:stripped_oak_log
fill 380 221 315 383 221 315 minecraft:red_terracotta
fill 381 221 276 381 222 276 minecraft:red_terracotta
setblock 381 221 278 minecraft:stripped_oak_log
fill 381 221 280 381 222 280 minecraft:stripped_oak_log
fill 381 221 282 381 222 282 minecraft:stripped_oak_log
fill 381 221 284 381 222 284 minecraft:stripped_oak_log
fill 381 221 314 384 221 314 minecraft:red_terracotta
setblock 382 221 277 minecraft:stripped_oak_log
fill 382 221 278 383 222 278 minecraft:red_terracotta
fill 382 221 279 382 222 279 minecraft:stripped_oak_log
fill 382 221 281 382 222 281 minecraft:stripped_oak_log
fill 382 221 283 382 222 283 minecraft:stripped_oak_log
setblock 383 221 276 minecraft:stripped_oak_log
fill 383 221 277 384 222 277 minecraft:red_terracotta
fill 383 221 280 383 222 280 minecraft:stripped_oak_log
fill 383 221 282 383 222 282 minecraft:stripped_oak_log
fill 383 221 284 383 222 284 minecraft:stripped_oak_log
setblock 383 221 316 minecraft:stripped_oak_log
fill 384 221 276 385 222 276 minecraft:red_terracotta
fill 384 221 279 384 222 279 minecraft:stripped_oak_log
fill 384 221 281 384 222 281 minecraft:stripped_oak_log
fill 384 221 283 384 222 283 minecraft:stripped_oak_log
setblock 384 221 315 minecraft:stripped_oak_log
fill 384 221 316 387 221 316 minecraft:red_terracotta
setblock 385 221 278 minecraft:red_terracotta
fill 385 221 280 385 222 280 minecraft:stripped_oak_log
fill 385 221 282 385 222 282 minecraft:stripped_oak_log
fill 385 221 284 385 222 284 minecraft:stripped_oak_log
setblock 385 221 314 minecraft:stripped_oak_log
fill 385 221 315 388 221 315 minecraft:red_terracotta
setblock 386 221 277 minecraft:red_terracotta
fill 386 221 278 386 221 279 minecraft:stripped_oak_log
fill 386 221 281 386 222 281 minecraft:stripped_oak_log
fill 386 221 283 386 222 283 minecraft:stripped_oak_log
setblock 386 221 285 minecraft:light[level=12]
setblock 386 221 292 minecraft:light[level=12]
setblock 386 221 299 minecraft:light[level=12]
setblock 386 221 306 minecraft:light[level=12]
setblock 386 221 313 minecraft:light[level=12]
fill 386 221 314 386 224 314 minecraft:red_terracotta
setblock 387 221 276 minecraft:red_terracotta
setblock 387 221 277 minecraft:stripped_oak_log
fill 387 221 278 387 222 278 minecraft:red_terracotta
fill 387 221 280 387 222 280 minecraft:stripped_oak_log
fill 387 221 282 387 222 282 minecraft:stripped_oak_log
fill 387 221 284 387 222 284 minecraft:stripped_oak_log
fill 387 221 292 387 223 292 minecraft:bone_block
fill 387 221 304 387 223 304 minecraft:bone_block
setblock 388 221 276 minecraft:stripped_oak_log
fill 388 221 277 388 222 277 minecraft:red_terracotta
fill 388 221 279 388 222 279 minecraft:stripped_oak_log
fill 388 221 281 388 222 281 minecraft:stripped_oak_log
fill 388 221 283 388 222 283 minecraft:stripped_oak_log
setblock 388 221 316 minecraft:stripped_oak_log
fill 389 221 276 392 221 276 minecraft:red_terracotta
fill 389 221 278 389 222 278 minecraft:stripped_oak_log
fill 389 221 280 389 222 280 minecraft:stripped_oak_log
fill 389 221 282 389 222 282 minecraft:stripped_oak_log
fill 389 221 284 389 222 284 minecraft:stripped_oak_log
setblock 389 221 315 minecraft:stripped_oak_log
fill 389 221 316 392 221 316 minecraft:red_terracotta
fill 390 221 277 391 221 277 minecraft:red_terracotta
fill 390 221 279 390 222 279 minecraft:stripped_oak_log
fill 390 221 281 390 222 281 minecraft:stripped_oak_log
fill 390 221 283 390 222 283 minecraft:stripped_oak_log
fill 390 221 292 390 223 292 minecraft:bone_block
fill 390 221 304 390 223 304 minecraft:bone_block
setblock 390 221 314 minecraft:stripped_oak_log
fill 390 221 315 393 221 315 minecraft:red_terracotta
setblock 393 221 276 minecraft:stripped_oak_log
setblock 393 221 278 minecraft:light[level=12]
setblock 393 221 285 minecraft:light[level=12]
fill 393 221 292 393 223 292 minecraft:bone_block
setblock 393 221 299 minecraft:light[level=12]
fill 393 221 304 393 223 304 minecraft:bone_block
setblock 393 221 306 minecraft:light[level=12]
setblock 393 221 313 minecraft:light[level=12]
setblock 393 221 316 minecraft:stripped_oak_log
fill 394 221 276 397 221 276 minecraft:red_terracotta
setblock 394 221 315 minecraft:stripped_oak_log
fill 394 221 316 397 221 316 minecraft:red_terracotta
fill 395 221 315 398 221 315 minecraft:red_terracotta
fill 396 221 292 396 223 292 minecraft:bone_block
fill 396 221 304 396 223 304 minecraft:bone_block
fill 396 221 314 399 221 314 minecraft:red_terracotta
setblock 398 221 276 minecraft:stripped_oak_log
setblock 398 221 316 minecraft:stripped_oak_log
fill 399 221 276 399 224 276 minecraft:red_terracotta
fill 399 221 292 399 223 292 minecraft:bone_block
fill 399 221 304 399 223 304 minecraft:bone_block
setblock 399 221 315 minecraft:stripped_oak_log
fill 399 221 316 402 221 316 minecraft:red_terracotta
fill 400 221 277 401 221 277 minecraft:red_terracotta
fill 400 221 279 400 222 279 minecraft:stripped_oak_log
fill 400 221 281 400 222 281 minecraft:stripped_oak_log
setblock 400 221 285 minecraft:light[level=12]
setblock 400 221 292 minecraft:light[level=12]
setblock 400 221 299 minecraft:light[level=12]
setblock 400 221 306 minecraft:light[level=12]
setblock 400 221 313 minecraft:red_terracotta
setblock 400 221 314 minecraft:stripped_oak_log
fill 400 221 315 403 221 315 minecraft:red_terracotta
fill 401 221 276 401 222 276 minecraft:red_terracotta
fill 401 221 278 401 222 278 minecraft:stripped_oak_log
fill 401 221 280 401 222 280 minecraft:stripped_oak_log
fill 401 221 282 401 222 282 minecraft:stripped_oak_log
setblock 401 221 313 minecraft:stripped_oak_log
fill 401 221 314 404 221 314 minecraft:red_terracotta
setblock 402 221 277 minecraft:stripped_oak_log
fill 402 221 279 402 222 279 minecraft:stripped_oak_log
fill 402 221 281 402 222 281 minecraft:stripped_oak_log
fill 402 221 292 402 223 292 minecraft:bone_block
fill 402 221 304 402 223 304 minecraft:bone_block
fill 402 221 313 402 224 313 minecraft:red_terracotta
setblock 403 221 276 minecraft:stripped_oak_log
fill 403 221 277 405 222 277 minecraft:red_terracotta
fill 403 221 278 403 222 278 minecraft:stripped_oak_log
fill 403 221 280 403 222 280 minecraft:stripped_oak_log
fill 403 221 282 403 222 282 minecraft:stripped_oak_log
setblock 403 221 316 minecraft:stripped_oak_log
fill 404 221 276 405 222 276 minecraft:red_terracotta
fill 404 221 279 404 222 279 minecraft:stripped_oak_log
fill 404 221 281 404 222 281 minecraft:stripped_oak_log
fill 404 221 313 405 221 313 minecraft:red_terracotta
setblock 404 221 315 minecraft:stripped_oak_log
fill 404 221 316 407 221 316 minecraft:red_terracotta
fill 405 221 278 405 222 278 minecraft:stripped_oak_log
fill 405 221 280 405 222 280 minecraft:stripped_oak_log
fill 405 221 282 405 222 282 minecraft:stripped_oak_log
fill 405 221 292 405 223 292 minecraft:bone_block
fill 405 221 304 405 223 304 minecraft:bone_block
setblock 405 221 314 minecraft:stripped_oak_log
fill 405 221 315 408 221 315 minecraft:red_terracotta
fill 406 221 277 406 222 277 minecraft:stripped_oak_log
fill 406 221 279 406 222 279 minecraft:stripped_oak_log
fill 406 221 281 406 222 281 minecraft:stripped_oak_log
fill 406 221 297 408 225 297 minecraft:bone_block
setblock 406 221 313 minecraft:stripped_oak_log
fill 406 221 314 406 224 314 minecraft:red_terracotta
setblock 407 221 276 minecraft:red_terracotta
fill 407 221 278 407 222 278 minecraft:stripped_oak_log
fill 407 221 280 407 222 280 minecraft:stripped_oak_log
fill 407 221 282 407 222 282 minecraft:stripped_oak_log
setblock 407 221 285 minecraft:light[level=12]
setblock 407 221 292 minecraft:light[level=12]
fill 407 221 296 411 225 296 minecraft:bone_block
fill 407 221 298 407 225 301 minecraft:bone_block
setblock 407 221 306 minecraft:light[level=12]
setblock 407 221 313 minecraft:light[level=12]
fill 408 221 276 408 221 277 minecraft:stripped_oak_log
fill 408 221 279 408 222 279 minecraft:stripped_oak_log
fill 408 221 281 408 222 281 minecraft:stripped_oak_log
fill 408 221 300 408 225 301 minecraft:bone_block
setblock 408 221 316 minecraft:stripped_oak_log
fill 409 221 276 409 222 276 minecraft:red_terracotta
fill 409 221 278 409 222 278 minecraft:stripped_oak_log
fill 409 221 280 409 222 280 minecraft:stripped_oak_log
fill 409 221 282 409 222 282 minecraft:stripped_oak_log
fill 409 221 301 409 226 301 minecraft:bone_block
setblock 409 221 315 minecraft:stripped_oak_log
fill 409 221 316 409 224 316 minecraft:red_terracotta
fill 410 221 277 410 222 277 minecraft:stripped_oak_log
fill 410 221 279 410 222 279 minecraft:stripped_oak_log
fill 410 221 281 410 222 281 minecraft:stripped_oak_log
fill 410 221 300 411 227 300 minecraft:bone_block
fill 410 221 315 410 222 315 minecraft:red_terracotta
fill 411 221 276 411 222 276 minecraft:stripped_oak_log
fill 411 221 278 411 222 278 minecraft:stripped_oak_log
fill 411 221 280 411 222 280 minecraft:stripped_oak_log
fill 411 221 282 411 222 282 minecraft:stripped_oak_log
fill 411 221 297 412 225 297 minecraft:bone_block
fill 411 221 302 411 222 302 minecraft:stripped_oak_log
fill 411 221 304 411 222 304 minecraft:stripped_oak_log
fill 411 221 306 411 222 306 minecraft:stripped_oak_log
fill 411 221 308 411 222 308 minecraft:stripped_oak_log
fill 411 221 310 411 222 310 minecraft:stripped_oak_log
fill 411 221 312 411 222 312 minecraft:stripped_oak_log
fill 411 221 314 411 222 314 minecraft:stripped_oak_log
fill 412 221 277 412 222 277 minecraft:stripped_oak_log
fill 412 221 279 412 222 279 minecraft:stripped_oak_log
fill 412 221 281 412 222 281 minecraft:stripped_oak_log
fill 412 221 298 412 226 299 minecraft:bone_block
fill 412 221 303 412 222 303 minecraft:stripped_oak_log
fill 412 221 305 412 222 305 minecraft:stripped_oak_log
fill 412 221 307 412 222 307 minecraft:stripped_oak_log
fill 412 221 309 412 222 309 minecraft:stripped_oak_log
fill 412 221 311 412 222 311 minecraft:stripped_oak_log
fill 412 221 313 412 222 313 minecraft:stripped_oak_log
fill 413 221 302 413 222 302 minecraft:stripped_oak_log
fill 413 221 304 413 222 304 minecraft:stripped_oak_log
fill 413 221 306 413 222 306 minecraft:stripped_oak_log
fill 413 221 308 413 222 308 minecraft:stripped_oak_log
fill 413 221 310 413 222 310 minecraft:stripped_oak_log
fill 413 221 312 413 222 312 minecraft:stripped_oak_log
fill 413 221 314 413 222 314 minecraft:stripped_oak_log
setblock 413 221 316 minecraft:stripped_oak_log
setblock 414 221 278 minecraft:light[level=12]
setblock 414 221 285 minecraft:light[level=12]
setblock 414 221 292 minecraft:light[level=12]
setblock 414 221 299 minecraft:light[level=12]
fill 414 221 303 414 222 303 minecraft:stripped_oak_log
fill 414 221 305 414 222 305 minecraft:stripped_oak_log
fill 414 221 307 414 222 307 minecraft:stripped_oak_log
fill 414 221 309 414 222 309 minecraft:stripped_oak_log
fill 414 221 311 414 222 311 minecraft:stripped_oak_log
fill 414 221 313 414 222 313 minecraft:stripped_oak_log
fill 415 221 302 415 222 302 minecraft:stripped_oak_log
fill 415 221 304 415 222 304 minecraft:stripped_oak_log
fill 415 221 306 415 222 306 minecraft:stripped_oak_log
fill 415 221 308 415 222 308 minecraft:stripped_oak_log
fill 415 221 310 415 222 310 minecraft:stripped_oak_log
fill 415 221 312 415 222 312 minecraft:stripped_oak_log
fill 415 221 314 415 222 314 minecraft:stripped_oak_log
fill 416 221 290 416 221 292 minecraft:red_terracotta
setblock 416 221 293 minecraft:stripped_oak_log
fill 416 221 294 416 221 297 minecraft:red_terracotta
setblock 416 221 298 minecraft:stripped_oak_log
fill 416 221 303 416 222 303 minecraft:stripped_oak_log
fill 416 221 305 416 222 305 minecraft:stripped_oak_log
fill 416 221 307 416 222 307 minecraft:stripped_oak_log
fill 416 221 309 416 222 309 minecraft:stripped_oak_log
fill 416 221 311 416 222 311 minecraft:stripped_oak_log
fill 416 221 313 416 222 313 minecraft:stripped_oak_log
fill 416 221 316 417 221 316 minecraft:red_terracotta
setblock 417 221 286 minecraft:red_terracotta
setblock 417 221 287 minecraft:stripped_oak_log
fill 417 221 288 417 221 291 minecraft:red_terracotta
setblock 417 221 292 minecraft:stripped_oak_log
fill 417 221 293 417 224 293 minecraft:red_terracotta
fill 417 221 295 417 221 296 minecraft:red_terracotta
setblock 417 221 297 minecraft:stripped_oak_log
fill 417 221 298 417 224 298 minecraft:red_terracotta
setblock 417 221 301 minecraft:red_terracotta
setblock 417 221 302 minecraft:stripped_oak_log
fill 417 221 304 417 222 304 minecraft:stripped_oak_log
fill 417 221 306 417 222 306 minecraft:stripped_oak_log
fill 417 221 308 417 222 308 minecraft:stripped_oak_log
fill 417 221 310 417 222 310 minecraft:stripped_oak_log
setblock 417 221 312 minecraft:stripped_oak_log
fill 417 221 313 417 222 315 minecraft:red_terracotta
setblock 377 222 276 minecraft:stripped_oak_log
fill 377 222 277 377 222 280 minecraft:red_terracotta
setblock 377 222 281 minecraft:stripped_oak_log
fill 377 222 282 377 222 285 minecraft:red_terracotta
setblock 377 222 286 minecraft:stripped_oak_log
fill 377 222 287 377 222 290 minecraft:red_terracotta
setblock 377 222 291 minecraft:stripped_oak_log
fill 377 222 292 377 225 292 minecraft:red_terracotta
setblock 377 222 295 minecraft:red_terracotta
setblock 377 222 296 minecraft:stripped_oak_log
fill 377 222 297 377 225 297 minecraft:red_terracotta
setblock 377 222 300 minecraft:red_terracotta
fill 377 222 312 377 225 312 minecraft:red_terracotta
fill 377 222 314 377 222 315 minecraft:red_terracotta
setblock 377 222 316 minecraft:stripped_oak_log
fill 378 222 276 378 225 276 minecraft:red_terracotta
fill 378 222 281 378 222 284 minecraft:red_terracotta
setblock 378 222 285 minecraft:stripped_oak_log
fill 378 222 286 378 222 289 minecraft:red_terracotta
setblock 378 222 290 minecraft:stripped_oak_log
fill 378 222 291 378 225 291 minecraft:red_terracotta
setblock 378 222 294 minecraft:red_terracotta
setblock 378 222 295 minecraft:stripped_oak_log
fill 378 222 296 379 224 296 minecraft:red_terracotta
fill 378 222 298 378 223 298 minecraft:red_terracotta
setblock 378 222 314 minecraft:red_terracotta
setblock 378 222 315 minecraft:stripped_oak_log
fill 378 222 316 381 222 316 minecraft:red_terracotta
setblock 379 222 278 minecraft:red_terracotta
setblock 379 222 289 minecraft:stripped_oak_log
fill 379 222 290 379 224 290 minecraft:red_terracotta
setblock 379 222 294 minecraft:stripped_oak_log
fill 379 222 295 379 225 295 minecraft:red_terracotta
fill 379 222 315 382 222 315 minecraft:red_terracotta
setblock 380 222 277 minecraft:red_terracotta
setblock 380 222 278 minecraft:stripped_oak_log
fill 380 222 295 382 231 296 minecraft:stripped_oak_log
fill 380 222 314 383 222 314 minecraft:red_terracotta
setblock 381 222 277 minecraft:stripped_oak_log
setblock 381 222 278 minecraft:red_terracotta
setblock 382 222 276 minecraft:stripped_oak_log
setblock 382 222 277 minecraft:red_terracotta
setblock 382 222 316 minecraft:stripped_oak_log
setblock 383 222 276 minecraft:red_terracotta
setblock 383 222 315 minecraft:stripped_oak_log
fill 383 222 316 386 222 316 minecraft:red_terracotta
setblock 384 222 314 minecraft:stripped_oak_log
fill 384 222 315 387 222 315 minecraft:red_terracotta
setblock 385 222 278 minecraft:stripped_oak_log
fill 385 222 314 385 225 314 minecraft:red_terracotta
setblock 386 222 277 minecraft:stripped_oak_log
fill 386 222 278 386 225 278 minecraft:red_terracotta
fill 386 222 279 387 222 279 minecraft:stripped_oak_log
setblock 387 222 276 minecraft:stripped_oak_log
fill 387 222 277 387 225 277 minecraft:red_terracotta
fill 387 222 297 387 225 297 minecraft:bone_block
fill 387 222 299 387 225 299 minecraft:bone_block
setblock 387 222 316 minecraft:stripped_oak_log
fill 388 222 276 391 222 276 minecraft:red_terracotta
fill 388 222 278 388 223 278 minecraft:red_terracotta
setblock 388 222 314 minecraft:red_terracotta
setblock 388 222 315 minecraft:stripped_oak_log
fill 388 222 316 391 222 316 minecraft:red_terracotta
setblock 389 222 314 minecraft:stripped_oak_log
fill 389 222 315 392 222 315 minecraft:red_terracotta
setblock 390 222 277 minecraft:red_terracotta
fill 390 222 297 390 225 297 minecraft:bone_block
fill 390 222 299 390 225 299 minecraft:bone_block
setblock 390 222 314 minecraft:red_terracotta
setblock 391 222 277 minecraft:stripped_oak_log
setblock 392 222 276 minecraft:stripped_oak_log
fill 392 222 277 392 225 277 minecraft:red_terracotta
setblock 392 222 316 minecraft:stripped_oak_log
fill 393 222 276 396 222 276 minecraft:red_terracotta
fill 393 222 297 393 225 297 minecraft:bone_block
fill 393 222 299 393 225 299 minecraft:bone_block
setblock 393 222 315 minecraft:stripped_oak_log
fill 393 222 316 396 222 316 minecraft:red_terracotta
fill 394 222 315 397 222 315 minecraft:red_terracotta
fill 395 222 314 398 222 314 minecraft:red_terracotta
setblock 397 222 276 minecraft:stripped_oak_log
fill 397 222 277 400 222 277 minecraft:red_terracotta
setblock 397 222 316 minecraft:stripped_oak_log
fill 398 222 276 398 225 276 minecraft:red_terracotta
setblock 398 222 315 minecraft:stripped_oak_log
fill 398 222 316 401 222 316 minecraft:red_terracotta
fill 399 222 297 399 225 297 minecraft:bone_block
fill 399 222 299 399 225 299 minecraft:bone_block
setblock 399 222 313 minecraft:red_terracotta
setblock 399 222 314 minecraft:stripped_oak_log
fill 399 222 315 402 222 315 minecraft:red_terracotta
setblock 400 222 313 minecraft:stripped_oak_log
fill 400 222 314 403 222 314 minecraft:red_terracotta
setblock 401 222 277 minecraft:stripped_oak_log
fill 401 222 313 401 224 313 minecraft:red_terracotta
setblock 402 222 276 minecraft:stripped_oak_log
setblock 402 222 277 minecraft:red_terracotta
fill 402 222 297 402 225 297 minecraft:bone_block
fill 402 222 299 402 225 299 minecraft:bone_block
setblock 402 222 316 minecraft:stripped_oak_log
setblock 403 222 276 minecraft:red_terracotta
setblock 403 222 315 minecraft:stripped_oak_log
fill 403 222 316 406 222 316 minecraft:red_terracotta
setblock 404 222 313 minecraft:red_terracotta
setblock 404 222 314 minecraft:stripped_oak_log
fill 404 222 315 407 222 315 minecraft:red_terracotta
fill 405 222 297 405 225 297 minecraft:bone_block
fill 405 222 299 406 225 299 minecraft:bone_block
setblock 405 222 313 minecraft:stripped_oak_log
fill 405 222 314 405 225 314 minecraft:red_terracotta
fill 406 222 296 406 225 296 minecraft:bone_block
fill 406 222 298 406 226 298 minecraft:bone_block
fill 406 222 300 406 224 301 minecraft:bone_block
setblock 407 222 276 minecraft:stripped_oak_log
fill 407 222 295 411 225 295 minecraft:bone_block
setblock 407 222 316 minecraft:stripped_oak_log
fill 408 222 276 408 225 276 minecraft:red_terracotta
setblock 408 222 277 minecraft:stripped_oak_log
setblock 408 222 315 minecraft:stripped_oak_log
fill 408 222 316 408 225 316 minecraft:red_terracotta
fill 409 222 315 409 223 315 minecraft:red_terracotta
fill 410 222 276 410 223 276 minecraft:red_terracotta
fill 410 222 301 410 226 301 minecraft:bone_block
setblock 411 222 316 minecraft:red_terracotta
fill 412 222 296 412 225 296 minecraft:bone_block
setblock 412 222 316 minecraft:stripped_oak_log
fill 413 222 316 416 222 316 minecraft:red_terracotta
setblock 415 222 293 minecraft:stripped_oak_log
fill 415 222 294 416 222 296 minecraft:red_terracotta
setblock 416 222 276 minecraft:red_terracotta
fill 416 222 289 416 222 291 minecraft:red_terracotta
setblock 416 222 292 minecraft:stripped_oak_log
fill 416 222 293 416 225 293 minecraft:red_terracotta
setblock 416 222 297 minecraft:stripped_oak_log
fill 416 222 298 416 223 300 minecraft:red_terracotta
setblock 417 222 276 minecraft:stripped_oak_log
fill 417 222 277 417 223 279 minecraft:red_terracotta
setblock 417 222 285 minecraft:red_terracotta
setblock 417 222 286 minecraft:stripped_oak_log
fill 417 222 287 417 222 290 minecraft:red_terracotta
setblock 417 222 291 minecraft:stripped_oak_log
fill 417 222 292 417 225 292 minecraft:red_terracotta
setblock 417 222 295 minecraft:red_terracotta
setblock 417 222 296 minecraft:stripped_oak_log
fill 417 222 297 417 225 297 minecraft:red_terracotta
setblock 417 222 301 minecraft:stripped_oak_log
setblock 417 222 302 minecraft:red_terracotta
setblock 417 222 312 minecraft:red_terracotta
setblock 417 222 316 minecraft:stripped_oak_log
fill 377 223 276 377 223 279 minecraft:red_terracotta
setblock 377 223 280 minecraft:stripped_oak_log
fill 377 223 281 377 223 284 minecraft:red_terracotta
setblock 377 223 285 minecraft:stripped_oak_log
fill 377 223 286 377 223 289 minecraft:red_terracotta
setblock 377 223 290 minecraft:stripped_oak_log
fill 377 223 291 377 226 291 minecraft:red_terracotta
setblock 377 223 295 minecraft:stripped_oak_log
fill 377 223 296 377 226 296 minecraft:red_terracotta
setblock 377 223 300 minecraft:stripped_oak_log
fill 377 223 301 377 226 301 minecraft:red_terracotta
setblock 377 223 314 minecraft:red_terracotta
setblock 377 223 315 minecraft:stripped_oak_log
fill 377 223 316 380 223 316 minecraft:red_terracotta
setblock 378 223 277 minecraft:shroomlight
setblock 378 223 278 minecraft:red_terracotta
setblock 378 223 279 minecraft:shroomlight
fill 378 223 280 378 226 280 minecraft:red_terracotta
setblock 378 223 281 minecraft:shroomlight
fill 378 223 282 378 224 282 minecraft:red_terracotta
setblock 378 223 283 minecraft:shroomlight
setblock 378 223 284 minecraft:stripped_oak_log
fill 378 223 285 378 223 288 minecraft:red_terracotta
setblock 378 223 289 minecraft:stripped_oak_log
fill 378 223 290 378 226 290 minecraft:red_terracotta
setblock 378 223 293 minecraft:red_terracotta
setblock 378 223 294 minecraft:stripped_oak_log
fill 378 223 295 378 226 295 minecraft:red_terracotta
setblock 378 223 299 minecraft:stripped_oak_log
setblock 378 223 314 minecraft:stripped_oak_log
fill 378 223 315 381 223 315 minecraft:red_terracotta
setblock 379 223 276 minecraft:shroomlight
setblock 379 223 278 minecraft:shroomlight
fill 379 223 279 379 226 279 minecraft:red_terracotta
setblock 379 223 280 minecraft:shroomlight
fill 379 223 281 379 224 281 minecraft:red_terracotta
setblock 379 223 282 minecraft:shroomlight
setblock 379 223 284 minecraft:shroomlight
setblock 379 223 286 minecraft:light[level=15]
setblock 379 223 289 minecraft:red_terracotta
setblock 379 223 293 minecraft:stripped_oak_log
fill 379 223 294 379 226 294 minecraft:red_terracotta
setblock 379 223 297 minecraft:red_terracotta
setblock 379 223 302 minecraft:light[level=15]
setblock 379 223 310 minecraft:light[level=15]
setblock 380 223 277 minecraft:shroomlight
fill 380 223 278 380 226 278 minecraft:red_terracotta
setblock 380 223 279 minecraft:shroomlight
setblock 380 223 281 minecraft:shroomlight
setblock 380 223 283 minecraft:shroomlight
fill 380 223 314 382 223 314 minecraft:red_terracotta
setblock 381 223 276 minecraft:shroomlight
fill 381 223 277 381 226 277 minecraft:red_terracotta
setblock 381 223 278 minecraft:shroomlight
fill 381 223 279 381 224 279 minecraft:red_terracotta
setblock 381 223 280 minecraft:shroomlight
setblock 381 223 282 minecraft:shroomlight
setblock 381 223 284 minecraft:shroomlight
setblock 381 223 316 minecraft:stripped_oak_log
fill 382 223 276 382 226 276 minecraft:red_terracotta
setblock 382 223 277 minecraft:shroomlight
fill 382 223 278 382 224 278 minecraft:red_terracotta
setblock 382 223 279 minecraft:shroomlight
setblock 382 223 281 minecraft:shroomlight
setblock 382 223 283 minecraft:shroomlight
setblock 382 223 315 minecraft:stripped_oak_log
fill 382 223 316 385 223 316 minecraft:red_terracotta
setblock 383 223 276 minecraft:shroomlight
fill 383 223 277 383 224 277 minecraft:red_terracotta
setblock 383 223 278 minecraft:shroomlight
setblock 383 223 280 minecraft:shroomlight
setblock 383 223 282 minecraft:shroomlight
setblock 383 223 284 minecraft:shroomlight
setblock 383 223 314 minecraft:stripped_oak_log
fill 383 223 315 386 223 315 minecraft:red_terracotta
fill 384 223 276 384 224 276 minecraft:red_terracotta
setblock 384 223 277 minecraft:shroomlight
setblock 384 223 278 minecraft:stripped_oak_log
setblock 384 223 279 minecraft:shroomlight
setblock 384 223 281 minecraft:shroomlight
setblock 384 223 283 minecraft:shroomlight
fill 384 223 314 384 225 314 minecraft:red_terracotta
setblock 385 223 276 minecraft:shroomlight
setblock 385 223 277 minecraft:stripped_oak_log
setblock 385 223 278 minecraft:shroomlight
setblock 385 223 280 minecraft:shroomlight
setblock 385 223 282 minecraft:shroomlight
setblock 385 223 284 minecraft:shroomlight
setblock 386 223 276 minecraft:stripped_oak_log
setblock 386 223 277 minecraft:shroomlight
setblock 386 223 279 minecraft:shroomlight
setblock 386 223 281 minecraft:shroomlight
setblock 386 223 283 minecraft:shroomlight
setblock 386 223 316 minecraft:stripped_oak_log
setblock 387 223 276 minecraft:shroomlight
setblock 387 223 278 minecraft:shroomlight
fill 387 223 279 387 242 279 minecraft:stripped_oak_log
setblock 387 223 280 minecraft:shroomlight
setblock 387 223 282 minecraft:shroomlight
setblock 387 223 284 minecraft:shroomlight
setblock 387 223 286 minecraft:light[level=15]
fill 387 223 293 387 224 293 minecraft:bone_block
setblock 387 223 294 minecraft:light[level=15]
setblock 387 223 302 minecraft:light[level=15]
fill 387 223 303 387 224 303 minecraft:bone_block
setblock 387 223 310 minecraft:light[level=15]
setblock 387 223 315 minecraft:stripped_oak_log
fill 387 223 316 390 223 316 minecraft:red_terracotta
fill 388 223 276 388 225 276 minecraft:red_terracotta
setblock 388 223 277 minecraft:shroomlight
setblock 388 223 279 minecraft:shroomlight
setblock 388 223 281 minecraft:shroomlight
setblock 388 223 283 minecraft:shroomlight
setblock 388 223 314 minecraft:stripped_oak_log
fill 388 223 315 391 223 315 minecraft:red_terracotta
setblock 389 223 276 minecraft:shroomlight
setblock 389 223 278 minecraft:shroomlight
setblock 389 223 280 minecraft:shroomlight
setblock 389 223 282 minecraft:shroomlight
setblock 389 223 284 minecraft:shroomlight
setblock 389 223 314 minecraft:red_terracotta
setblock 390 223 276 minecraft:red_terracotta
setblock 390 223 277 minecraft:shroomlight
setblock 390 223 279 minecraft:shroomlight
setblock 390 223 281 minecraft:shroomlight
setblock 390 223 283 minecraft:shroomlight
fill 390 223 293 390 224 293 minecraft:bone_block
fill 390 223 303 390 224 303 minecraft:bone_block
setblock 391 223 276 minecraft:stripped_oak_log
fill 391 223 277 391 226 277 minecraft:red_terracotta
setblock 391 223 316 minecraft:stripped_oak_log
fill 392 223 276 395 223 276 minecraft:red_terracotta
setblock 392 223 315 minecraft:stripped_oak_log
fill 392 223 316 395 223 316 minecraft:red_terracotta
fill 393 223 277 394 223 277 minecraft:red_terracotta
fill 393 223 293 393 224 293 minecraft:bone_block
fill 393 223 303 393 224 303 minecraft:bone_block
fill 393 223 315 396 223 315 minecraft:red_terracotta
setblock 395 223 277 minecraft:stripped_oak_log
setblock 395 223 278 minecraft:light[level=15]
setblock 395 223 286 minecraft:light[level=15]
setblock 395 223 294 minecraft:light[level=15]
setblock 395 223 302 minecraft:light[level=15]
setblock 395 223 310 minecraft:light[level=15]
fill 395 223 314 397 223 314 minecraft:red_terracotta
setblock 396 223 276 minecraft:stripped_oak_log
fill 396 223 277 399 223 277 minecraft:red_terracotta
fill 396 223 293 396 224 293 minecraft:bone_block
fill 396 223 303 396 224 303 minecraft:bone_block
setblock 396 223 316 minecraft:stripped_oak_log
fill 397 223 276 397 226 276 minecraft:red_terracotta
setblock 397 223 315 minecraft:stripped_oak_log
fill 397 223 316 400 223 316 minecraft:red_terracotta
setblock 398 223 314 minecraft:stripped_oak_log
fill 398 223 315 401 223 315 minecraft:red_terracotta
fill 399 223 293 399 224 293 minecraft:bone_block
fill 399 223 303 399 224 303 minecraft:bone_block
setblock 399 223 313 minecraft:stripped_oak_log
fill 399 223 314 402 223 314 minecraft:red_terracotta
setblock 400 223 277 minecraft:shroomlight
setblock 400 223 279 minecraft:shroomlight
setblock 400 223 281 minecraft:shroomlight
fill 400 223 313 400 224 313 minecraft:red_terracotta
setblock 401 223 276 minecraft:shroomlight
fill 401 223 277 401 226 277 minecraft:red_terracotta
setblock 401 223 278 minecraft:shroomlight
setblock 401 223 280 minecraft:shroomlight
setblock 401 223 282 minecraft:shroomlight
setblock 401 223 316 minecraft:stripped_oak_log
fill 402 223 276 402 226 276 minecraft:red_terracotta
setblock 402 223 277 minecraft:shroomlight
setblock 402 223 279 minecraft:shroomlight
setblock 402 223 281 minecraft:shroomlight
fill 402 223 293 402 224 293 minecraft:bone_block
fill 402 223 303 402 224 303 minecraft:bone_block
setblock 402 223 315 minecraft:stripped_oak_log
fill 402 223 316 405 223 316 minecraft:red_terracotta
setblock 403 223 276 minecraft:shroomlight
fill 403 223 277 403 224 277 minecraft:red_terracotta
setblock 403 223 278 minecraft:shroomlight
setblock 403 223 280 minecraft:shroomlight
setblock 403 223 282 minecraft:shroomlight
setblock 403 223 286 minecraft:light[level=15]
setblock 403 223 294 minecraft:light[level=15]
setblock 403 223 302 minecraft:light[level=15]
setblock 403 223 310 minecraft:light[level=15]
setblock 403 223 314 minecraft:stripped_oak_log
fill 403 223 315 406 223 315 minecraft:red_terracotta
fill 404 223 276 404 224 276 minecraft:red_terracotta
setblock 404 223 277 minecraft:shroomlight
setblock 404 223 279 minecraft:shroomlight
setblock 404 223 281 minecraft:shroomlight
setblock 404 223 313 minecraft:stripped_oak_log
fill 404 223 314 404 225 314 minecraft:red_terracotta
setblock 405 223 276 minecraft:shroomlight
setblock 405 223 277 minecraft:stripped_oak_log
setblock 405 223 278 minecraft:shroomlight
setblock 405 223 280 minecraft:shroomlight
setblock 405 223 282 minecraft:shroomlight
fill 405 223 293 405 224 293 minecraft:bone_block
fill 405 223 303 405 224 303 minecraft:bone_block
setblock 406 223 276 minecraft:stripped_oak_log
setblock 406 223 277 minecraft:shroomlight
setblock 406 223 279 minecraft:shroomlight
setblock 406 223 281 minecraft:shroomlight
setblock 406 223 295 minecraft:bone_block
setblock 406 223 316 minecraft:stripped_oak_log
setblock 407 223 276 minecraft:shroomlight
setblock 407 223 278 minecraft:shroomlight
setblock 407 223 280 minecraft:shroomlight
setblock 407 223 282 minecraft:shroomlight
fill 407 223 302 408 223 302 minecraft:bone_block
setblock 407 223 315 minecraft:stripped_oak_log
fill 407 223 316 407 226 316 minecraft:red_terracotta
setblock 408 223 277 minecraft:shroomlight
setblock 408 223 279 minecraft:shroomlight
setblock 408 223 281 minecraft:shroomlight
fill 408 223 294 410 224 294 minecraft:bone_block
fill 408 223 315 408 224 315 minecraft:red_terracotta
setblock 409 223 276 minecraft:shroomlight
setblock 409 223 278 minecraft:shroomlight
setblock 409 223 280 minecraft:shroomlight
setblock 409 223 282 minecraft:shroomlight
setblock 410 223 277 minecraft:shroomlight
setblock 410 223 279 minecraft:shroomlight
setblock 410 223 281 minecraft:shroomlight
setblock 411 223 276 minecraft:shroomlight
setblock 411 223 278 minecraft:shroomlight
setblock 411 223 280 minecraft:shroomlight
setblock 411 223 282 minecraft:shroomlight
setblock 411 223 286 minecraft:light[level=15]
setblock 411 223 294 minecraft:light[level=15]
setblock 411 223 302 minecraft:shroomlight
setblock 411 223 304 minecraft:shroomlight
setblock 411 223 306 minecraft:shroomlight
setblock 411 223 308 minecraft:shroomlight
setblock 411 223 310 minecraft:shroomlight
setblock 411 223 312 minecraft:shroomlight
setblock 411 223 314 minecraft:shroomlight
setblock 411 223 316 minecraft:stripped_oak_log
setblock 412 223 277 minecraft:shroomlight
setblock 412 223 279 minecraft:shroomlight
setblock 412 223 281 minecraft:shroomlight
setblock 412 223 303 minecraft:shroomlight
setblock 412 223 305 minecraft:shroomlight
setblock 412 223 307 minecraft:shroomlight
setblock 412 223 309 minecraft:shroomlight
setblock 412 223 311 minecraft:shroomlight
setblock 412 223 313 minecraft:shroomlight
fill 412 223 316 415 223 316 minecraft:red_terracotta
setblock 413 223 302 minecraft:shroomlight
setblock 413 223 304 minecraft:shroomlight
setblock 413 223 306 minecraft:shroomlight
setblock 413 223 308 minecraft:shroomlight
setblock 413 223 310 minecraft:shroomlight
setblock 413 223 312 minecraft:shroomlight
setblock 413 223 314 minecraft:shroomlight
fill 414 223 276 415 223 276 minecraft:red_terracotta
setblock 414 223 303 minecraft:shroomlight
setblock 414 223 305 minecraft:shroomlight
setblock 414 223 307 minecraft:shroomlight
setblock 414 223 309 minecraft:shroomlight
setblock 414 223 311 minecraft:shroomlight
setblock 414 223 313 minecraft:shroomlight
fill 415 223 293 415 223 296 minecraft:red_terracotta
setblock 415 223 297 minecraft:stripped_oak_log
fill 415 223 298 415 226 298 minecraft:red_terracotta
setblock 415 223 302 minecraft:shroomlight
setblock 415 223 304 minecraft:shroomlight
setblock 415 223 306 minecraft:shroomlight
setblock 415 223 308 minecraft:shroomlight
setblock 415 223 310 minecraft:shroomlight
setblock 415 223 312 minecraft:shroomlight
setblock 415 223 314 minecraft:shroomlight
setblock 416 223 276 minecraft:stripped_oak_log
fill 416 223 289 416 223 290 minecraft:red_terracotta
setblock 416 223 291 minecraft:stripped_oak_log
fill 416 223 292 416 226 292 minecraft:red_terracotta
fill 416 223 294 416 223 295 minecraft:red_terracotta
setblock 416 223 296 minecraft:stripped_oak_log
fill 416 223 297 416 226 297 minecraft:red_terracotta
setblock 416 223 301 minecraft:stripped_oak_log
setblock 416 223 303 minecraft:shroomlight
setblock 416 223 305 minecraft:shroomlight
setblock 416 223 307 minecraft:shroomlight
setblock 416 223 309 minecraft:shroomlight
setblock 416 223 311 minecraft:shroomlight
setblock 416 223 313 minecraft:shroomlight
setblock 416 223 316 minecraft:stripped_oak_log
fill 417 223 276 417 226 276 minecraft:red_terracotta
setblock 417 223 280 minecraft:stripped_oak_log
fill 417 223 281 417 223 284 minecraft:red_terracotta
setblock 417 223 285 minecraft:stripped_oak_log
fill 417 223 286 417 223 289 minecraft:red_terracotta
setblock 417 223 290 minecraft:stripped_oak_log
fill 417 223 291 417 226 291 minecraft:red_terracotta
setblock 417 223 295 minecraft:stripped_oak_log
fill 417 223 296 417 226 296 minecraft:red_terracotta
setblock 417 223 299 minecraft:red_terracotta
setblock 417 223 300 minecraft:stripped_oak_log
fill 417 223 301 417 226 301 minecraft:red_terracotta
setblock 417 223 302 minecraft:shroomlight
fill 417 223 303 417 224 303 minecraft:red_terracotta
setblock 417 223 304 minecraft:shroomlight
setblock 417 223 306 minecraft:shroomlight
setblock 417 223 308 minecraft:shroomlight
setblock 417 223 310 minecraft:shroomlight
setblock 417 223 312 minecraft:shroomlight
fill 417 223 313 417 224 313 minecraft:red_terracotta
setblock 417 223 314 minecraft:shroomlight
setblock 417 223 315 minecraft:stripped_oak_log
fill 417 223 316 417 226 316 minecraft:red_terracotta
fill 376 224 275 376 227 317 minecraft:orange_terracotta
fill 377 224 275 418 227 275 minecraft:orange_terracotta
fill 377 224 276 377 224 278 minecraft:red_terracotta
setblock 377 224 279 minecraft:stripped_oak_log
fill 377 224 280 377 224 283 minecraft:red_terracotta
setblock 377 224 284 minecraft:stripped_oak_log
fill 377 224 285 377 224 288 minecraft:red_terracotta
setblock 377 224 289 minecraft:stripped_oak_log
fill 377 224 290 377 227 290 minecraft:red_terracotta
setblock 377 224 294 minecraft:stripped_oak_log
fill 377 224 295 377 227 295 minecraft:red_terracotta
setblock 377 224 298 minecraft:red_terracotta
setblock 377 224 299 minecraft:stripped_oak_log
fill 377 224 300 378 226 300 minecraft:red_terracotta
fill 377 224 302 377 225 302 minecraft:red_terracotta
setblock 377 224 314 minecraft:stripped_oak_log
fill 377 224 315 379 224 316 minecraft:red_terracotta
fill 377 224 317 418 227 317 minecraft:orange_terracotta
setblock 378 224 277 minecraft:red_terracotta
setblock 378 224 278 minecraft:stripped_oak_log
fill 378 224 279 378 225 279 minecraft:red_terracotta
fill 378 224 281 378 225 281 minecraft:red_terracotta
setblock 378 224 283 minecraft:stripped_oak_log
fill 378 224 284 378 224 287 minecraft:red_terracotta
setblock 378 224 288 minecraft:stripped_oak_log
fill 378 224 289 378 227 289 minecraft:red_terracotta
setblock 378 224 293 minecraft:stripped_oak_log
fill 378 224 294 378 227 294 minecraft:red_terracotta
setblock 378 224 298 minecraft:stripped_oak_log
fill 378 224 299 378 227 299 minecraft:red_terracotta
setblock 378 224 313 minecraft:stripped_oak_log
fill 378 224 314 378 227 314 minecraft:red_terracotta
setblock 379 224 276 minecraft:red_terracotta
setblock 379 224 277 minecraft:stripped_oak_log
fill 379 224 278 379 225 278 minecraft:red_terracotta
fill 379 224 280 380 224 280 minecraft:red_terracotta
setblock 379 224 282 minecraft:stripped_oak_log
fill 379 224 283 379 227 283 minecraft:red_terracotta
fill 379 224 284 379 225 284 minecraft:stripped_oak_log
fill 379 224 289 379 231 289 minecraft:stripped_oak_log
setblock 379 224 292 minecraft:stripped_oak_log
fill 379 224 293 379 226 293 minecraft:red_terracotta
setblock 379 224 297 minecraft:stripped_oak_log
fill 379 224 298 379 226 298 minecraft:red_terracotta
setblock 380 224 276 minecraft:stripped_oak_log
fill 380 224 277 380 225 277 minecraft:red_terracotta
fill 380 224 279 380 225 279 minecraft:red_terracotta
setblock 380 224 281 minecraft:stripped_oak_log
fill 380 224 283 380 225 283 minecraft:stripped_oak_log
fill 380 224 314 380 224 315 minecraft:red_terracotta
setblock 380 224 316 minecraft:stripped_oak_log
fill 381 224 276 381 225 276 minecraft:red_terracotta
fill 381 224 278 381 225 278 minecraft:red_terracotta
fill 381 224 280 381 225 280 minecraft:stripped_oak_log
fill 381 224 282 381 225 282 minecraft:stripped_oak_log
fill 381 224 284 381 225 284 minecraft:stripped_oak_log
setblock 381 224 314 minecraft:red_terracotta
setblock 381 224 315 minecraft:stripped_oak_log
fill 381 224 316 384 224 316 minecraft:red_terracotta
fill 382 224 277 382 225 277 minecraft:red_terracotta
setblock 382 224 279 minecraft:stripped_oak_log
fill 382 224 281 382 225 281 minecraft:stripped_oak_log
fill 382 224 283 382 225 283 minecraft:stripped_oak_log
setblock 382 224 314 minecraft:stripped_oak_log
fill 382 224 315 385 224 315 minecraft:red_terracotta
fill 383 224 276 383 225 276 minecraft:red_terracotta
setblock 383 224 278 minecraft:stripped_oak_log
fill 383 224 279 384 225 279 minecraft:red_terracotta
fill 383 224 280 383 225 280 minecraft:stripped_oak_log
fill 383 224 282 383 225 282 minecraft:stripped_oak_log
fill 383 224 284 383 225 284 minecraft:stripped_oak_log
fill 383 224 314 383 226 314 minecraft:red_terracotta
setblock 384 224 277 minecraft:stripped_oak_log
fill 384 224 278 385 225 278 minecraft:red_terracotta
fill 384 224 281 384 225 281 minecraft:stripped_oak_log
fill 384 224 283 384 225 283 minecraft:stripped_oak_log
setblock 385 224 276 minecraft:stripped_oak_log
fill 385 224 277 386 225 277 minecraft:red_terracotta
fill 385 224 280 385 225 280 minecraft:stripped_oak_log
fill 385 224 282 385 225 282 minecraft:stripped_oak_log
fill 385 224 284 385 225 284 minecraft:stripped_oak_log
setblock 385 224 316 minecraft:stripped_oak_log
fill 386 224 276 387 225 276 minecraft:red_terracotta
fill 386 224 279 386 225 279 minecraft:stripped_oak_log
fill 386 224 281 386 225 281 minecraft:stripped_oak_log
fill 386 224 283 386 225 283 minecraft:stripped_oak_log
setblock 386 224 315 minecraft:stripped_oak_log
fill 386 224 316 389 224 316 minecraft:red_terracotta
setblock 387 224 278 minecraft:red_terracotta
fill 387 224 280 387 225 280 minecraft:stripped_oak_log
fill 387 224 282 387 225 282 minecraft:stripped_oak_log
fill 387 224 284 387 225 284 minecraft:stripped_oak_log
fill 387 224 294 387 225 294 minecraft:bone_block
fill 387 224 302 387 225 302 minecraft:bone_block
setblock 387 224 314 minecraft:stripped_oak_log
fill 387 224 315 390 224 315 minecraft:red_terracotta
setblock 388 224 277 minecraft:red_terracotta
fill 388 224 278 388 224 279 minecraft:stripped_oak_log
fill 388 224 281 388 225 281 minecraft:stripped_oak_log
fill 388 224 283 388 225 283 minecraft:stripped_oak_log
setblock 388 224 314 minecraft:red_terracotta
setblock 389 224 276 minecraft:red_terracotta
fill 389 224 277 389 224 278 minecraft:stripped_oak_log
fill 389 224 280 389 225 280 minecraft:stripped_oak_log
fill 389 224 282 389 225 282 minecraft:stripped_oak_log
fill 389 224 284 389 225 284 minecraft:stripped_oak_log
setblock 390 224 276 minecraft:stripped_oak_log
fill 390 224 277 390 225 277 minecraft:red_terracotta
fill 390 224 279 390 225 279 minecraft:stripped_oak_log
fill 390 224 281 390 225 281 minecraft:stripped_oak_log
fill 390 224 283 390 225 283 minecraft:stripped_oak_log
fill 390 224 294 390 225 294 minecraft:bone_block
fill 390 224 302 390 225 302 minecraft:bone_block
setblock 390 224 316 minecraft:stripped_oak_log
fill 391 224 276 394 224 276 minecraft:red_terracotta
setblock 391 224 315 minecraft:stripped_oak_log
fill 391 224 316 394 224 316 minecraft:red_terracotta
fill 392 224 315 395 224 315 minecraft:red_terracotta
setblock 393 224 277 minecraft:red_terracotta
fill 393 224 294 393 225 294 minecraft:bone_block
fill 393 224 302 393 225 302 minecraft:bone_block
setblock 394 224 277 minecraft:stripped_oak_log
setblock 395 224 276 minecraft:stripped_oak_log
fill 395 224 277 398 224 277 minecraft:red_terracotta
fill 395 224 314 396 224 314 minecraft:red_terracotta
setblock 395 224 316 minecraft:stripped_oak_log
fill 396 224 276 396 227 276 minecraft:red_terracotta
fill 396 224 294 396 225 294 minecraft:bone_block
fill 396 224 302 396 225 302 minecraft:bone_block
setblock 396 224 315 minecraft:stripped_oak_log
fill 396 224 316 399 224 316 minecraft:red_terracotta
setblock 397 224 314 minecraft:stripped_oak_log
fill 397 224 315 400 224 315 minecraft:red_terracotta
fill 398 224 314 401 224 314 minecraft:red_terracotta
setblock 399 224 277 minecraft:stripped_oak_log
fill 399 224 294 399 225 294 minecraft:bone_block
fill 399 224 302 399 225 302 minecraft:bone_block
setblock 399 224 313 minecraft:red_terracotta
setblock 400 224 276 minecraft:stripped_oak_log
fill 400 224 277 400 225 277 minecraft:red_terracotta
fill 400 224 279 400 225 279 minecraft:stripped_oak_log
fill 400 224 281 400 225 281 minecraft:stripped_oak_log
setblock 400 224 316 minecraft:stripped_oak_log
fill 401 224 276 401 225 276 minecraft:red_terracotta
fill 401 224 278 401 225 278 minecraft:stripped_oak_log
fill 401 224 280 401 225 280 minecraft:stripped_oak_log
fill 401 224 282 401 225 282 minecraft:stripped_oak_log
setblock 401 224 315 minecraft:stripped_oak_log
fill 401 224 316 404 224 316 minecraft:red_terracotta
fill 402 224 277 402 225 277 minecraft:red_terracotta
fill 402 224 279 402 225 279 minecraft:stripped_oak_log
fill 402 224 281 402 225 281 minecraft:stripped_oak_log
fill 402 224 294 402 225 294 minecraft:bone_block
fill 402 224 302 402 225 302 minecraft:bone_block
setblock 402 224 314 minecraft:stripped_oak_log
fill 402 224 315 405 224 315 minecraft:red_terracotta
fill 403 224 276 403 225 276 minecraft:red_terracotta
fill 403 224 278 403 225 278 minecraft:stripped_oak_log
fill 403 224 280 403 225 280 minecraft:stripped_oak_log
fill 403 224 282 403 225 282 minecraft:stripped_oak_log
setblock 403 224 313 minecraft:stripped_oak_log
fill 403 224 314 403 226 314 minecraft:red_terracotta
setblock 404 224 277 minecraft:stripped_oak_log
fill 404 224 279 404 225 279 minecraft:stripped_oak_log
fill 404 224 281 404 225 281 minecraft:stripped_oak_log
setblock 405 224 276 minecraft:stripped_oak_log
fill 405 224 277 406 225 277 minecraft:red_terracotta
fill 405 224 278 405 225 278 minecraft:stripped_oak_log
fill 405 224 280 405 225 280 minecraft:stripped_oak_log
fill 405 224 282 405 225 282 minecraft:stripped_oak_log
fill 405 224 294 405 225 294 minecraft:bone_block
fill 405 224 298 405 226 298 minecraft:bone_block
fill 405 224 302 405 225 302 minecraft:bone_block
setblock 405 224 316 minecraft:stripped_oak_log
fill 406 224 276 407 225 276 minecraft:red_terracotta
fill 406 224 279 406 225 279 minecraft:stripped_oak_log
fill 406 224 281 406 225 281 minecraft:stripped_oak_log
setblock 406 224 315 minecraft:stripped_oak_log
fill 406 224 316 406 227 316 minecraft:red_terracotta
fill 407 224 278 407 225 278 minecraft:stripped_oak_log
fill 407 224 280 407 225 280 minecraft:stripped_oak_log
fill 407 224 282 407 225 282 minecraft:stripped_oak_log
fill 407 224 315 407 225 315 minecraft:red_terracotta
fill 408 224 277 408 225 277 minecraft:stripped_oak_log
fill 408 224 279 408 225 279 minecraft:stripped_oak_log
fill 408 224 281 408 225 281 minecraft:stripped_oak_log
setblock 408 224 302 minecraft:bone_block
setblock 409 224 276 minecraft:red_terracotta
fill 409 224 278 409 225 278 minecraft:stripped_oak_log
fill 409 224 280 409 225 280 minecraft:stripped_oak_log
fill 409 224 282 409 225 282 minecraft:stripped_oak_log
fill 410 224 276 410 224 277 minecraft:stripped_oak_log
fill 410 224 279 410 225 279 minecraft:stripped_oak_log
fill 410 224 281 410 225 281 minecraft:stripped_oak_log
setblock 410 224 316 minecraft:stripped_oak_log
fill 411 224 276 414 224 276 minecraft:red_terracotta
fill 411 224 278 411 225 278 minecraft:green_concrete
fill 411 224 280 411 225 280 minecraft:stripped_oak_log
fill 411 224 282 411 225 282 minecraft:stripped_oak_log
fill 411 224 302 411 225 302 minecraft:stripped_oak_log
fill 411 224 304 411 225 304 minecraft:stripped_oak_log
fill 411 224 306 411 225 306 minecraft:stripped_oak_log
fill 411 224 308 411 225 308 minecraft:stripped_oak_log
fill 411 224 310 411 225 310 minecraft:stripped_oak_log
fill 411 224 312 411 225 312 minecraft:stripped_oak_log
fill 411 224 314 411 225 314 minecraft:stripped_oak_log
fill 411 224 316 414 224 316 minecraft:red_terracotta
fill 412 224 277 412 225 277 minecraft:stripped_oak_log
fill 412 224 279 412 225 279 minecraft:stripped_oak_log
fill 412 224 281 412 225 281 minecraft:stripped_oak_log
fill 412 224 303 412 225 303 minecraft:stripped_oak_log
fill 412 224 305 412 225 305 minecraft:stripped_oak_log
fill 412 224 307 412 225 307 minecraft:stripped_oak_log
fill 412 224 309 412 225 309 minecraft:stripped_oak_log
fill 412 224 311 412 225 311 minecraft:stripped_oak_log
fill 412 224 313 412 225 313 minecraft:stripped_oak_log
fill 413 224 302 413 225 302 minecraft:stripped_oak_log
fill 413 224 304 413 225 304 minecraft:stripped_oak_log
fill 413 224 306 413 225 306 minecraft:stripped_oak_log
fill 413 224 308 413 225 308 minecraft:stripped_oak_log
fill 413 224 310 413 225 310 minecraft:stripped_oak_log
fill 413 224 312 413 225 312 minecraft:stripped_oak_log
fill 413 224 314 413 225 314 minecraft:stripped_oak_log
fill 414 224 303 414 225 303 minecraft:stripped_oak_log
fill 414 224 305 414 225 305 minecraft:stripped_oak_log
fill 414 224 307 414 225 307 minecraft:stripped_oak_log
fill 414 224 309 414 225 309 minecraft:stripped_oak_log
fill 414 224 311 414 225 311 minecraft:stripped_oak_log
fill 414 224 313 414 225 313 minecraft:stripped_oak_log
setblock 415 224 276 minecraft:stripped_oak_log
fill 415 224 293 415 224 295 minecraft:red_terracotta
setblock 415 224 296 minecraft:stripped_oak_log
fill 415 224 297 415 227 297 minecraft:red_terracotta
fill 415 224 302 415 225 302 minecraft:stripped_oak_log
fill 415 224 304 415 225 304 minecraft:stripped_oak_log
fill 415 224 306 415 225 306 minecraft:stripped_oak_log
fill 415 224 308 415 225 308 minecraft:stripped_oak_log
fill 415 224 310 415 225 310 minecraft:stripped_oak_log
fill 415 224 312 415 225 312 minecraft:stripped_oak_log
fill 415 224 314 415 225 314 minecraft:stripped_oak_log
setblock 415 224 316 minecraft:stripped_oak_log
fill 416 224 276 416 226 277 minecraft:red_terracotta
setblock 416 224 289 minecraft:red_terracotta
setblock 416 224 290 minecraft:stripped_oak_log
fill 416 224 291 416 227 291 minecraft:red_terracotta
setblock 416 224 294 minecraft:red_terracotta
setblock 416 224 295 minecraft:stripped_oak_log
fill 416 224 296 416 227 296 minecraft:red_terracotta
fill 416 224 298 416 224 299 minecraft:red_terracotta
setblock 416 224 300 minecraft:stripped_oak_log
fill 416 224 301 416 227 301 minecraft:red_terracotta
fill 416 224 303 416 225 303 minecraft:stripped_oak_log
fill 416 224 305 416 225 305 minecraft:stripped_oak_log
fill 416 224 307 416 225 307 minecraft:stripped_oak_log
fill 416 224 309 416 225 309 minecraft:stripped_oak_log
fill 416 224 311 416 225 311 minecraft:stripped_oak_log
fill 416 224 313 416 225 313 minecraft:stripped_oak_log
fill 416 224 316 416 227 316 minecraft:red_terracotta
fill 417 224 277 417 224 278 minecraft:red_terracotta
setblock 417 224 279 minecraft:stripped_oak_log
fill 417 224 280 417 224 283 minecraft:red_terracotta
setblock 417 224 284 minecraft:stripped_oak_log
fill 417 224 285 417 224 288 minecraft:red_terracotta
setblock 417 224 289 minecraft:stripped_oak_log
fill 417 224 290 417 227 290 minecraft:red_terracotta
setblock 417 224 294 minecraft:stripped_oak_log
fill 417 224 295 417 227 295 minecraft:red_terracotta
setblock 417 224 299 minecraft:stripped_oak_log
fill 417 224 300 417 227 300 minecraft:red_terracotta
fill 417 224 302 417 225 302 minecraft:red_terracotta
setblock 417 224 304 minecraft:stripped_oak_log
fill 417 224 306 417 225 306 minecraft:stripped_oak_log
fill 417 224 308 417 225 308 minecraft:stripped_oak_log
fill 417 224 310 417 225 310 minecraft:stripped_oak_log
fill 417 224 312 417 225 312 minecraft:stripped_oak_log
setblock 417 224 314 minecraft:stripped_oak_log
fill 417 224 315 417 227 315 minecraft:red_terracotta
fill 418 224 276 418 227 316 minecraft:orange_terracotta
fill 377 225 276 377 225 277 minecraft:red_terracotta
setblock 377 225 278 minecraft:stripped_oak_log
fill 377 225 279 377 225 282 minecraft:red_terracotta
setblock 377 225 283 minecraft:stripped_oak_log
fill 377 225 284 377 225 287 minecraft:red_terracotta
setblock 377 225 288 minecraft:stripped_oak_log
fill 377 225 289 377 228 289 minecraft:red_terracotta
setblock 377 225 293 minecraft:stripped_oak_log
fill 377 225 294 377 228 294 minecraft:red_terracotta
setblock 377 225 298 minecraft:stripped_oak_log
fill 377 225 299 377 228 299 minecraft:red_terracotta
setblock 377 225 303 minecraft:stripped_oak_log
setblock 377 225 313 minecraft:stripped_oak_log
fill 377 225 314 377 226 316 minecraft:red_terracotta
setblock 378 225 277 minecraft:stripped_oak_log
fill 378 225 278 378 228 278 minecraft:red_terracotta
setblock 378 225 282 minecraft:stripped_oak_log
fill 378 225 283 378 225 286 minecraft:red_terracotta
setblock 378 225 287 minecraft:stripped_oak_log
fill 378 225 288 378 227 288 minecraft:red_terracotta
setblock 378 225 292 minecraft:stripped_oak_log
fill 378 225 293 378 228 293 minecraft:red_terracotta
setblock 378 225 296 minecraft:red_terracotta
setblock 378 225 297 minecraft:stripped_oak_log
fill 378 225 298 378 228 298 minecraft:red_terracotta
setblock 378 225 301 minecraft:red_terracotta
fill 378 225 315 378 225 316 minecraft:red_terracotta
setblock 379 225 276 minecraft:stripped_oak_log
fill 379 225 277 379 228 277 minecraft:red_terracotta
setblock 379 225 280 minecraft:red_terracotta
setblock 379 225 281 minecraft:stripped_oak_log
setblock 379 225 282 minecraft:red_terracotta
fill 379 225 290 379 231 291 minecraft:stripped_oak_log
setblock 379 225 292 minecraft:red_terracotta
setblock 379 225 296 minecraft:stripped_oak_log
fill 379 225 297 379 227 297 minecraft:red_terracotta
setblock 379 225 315 minecraft:red_terracotta
setblock 379 225 316 minecraft:stripped_oak_log
fill 380 225 276 380 228 276 minecraft:red_terracotta
setblock 380 225 280 minecraft:stripped_oak_log
setblock 380 225 281 minecraft:red_terracotta
setblock 380 225 314 minecraft:red_terracotta
setblock 380 225 315 minecraft:stripped_oak_log
fill 380 225 316 383 225 316 minecraft:red_terracotta
setblock 381 225 279 minecraft:stripped_oak_log
setblock 381 225 314 minecraft:stripped_oak_log
fill 381 225 315 384 225 315 minecraft:red_terracotta
setblock 382 225 278 minecraft:stripped_oak_log
setblock 382 225 279 minecraft:red_terracotta
fill 382 225 314 382 226 314 minecraft:red_terracotta
setblock 383 225 277 minecraft:stripped_oak_log
setblock 383 225 278 minecraft:red_terracotta
setblock 384 225 276 minecraft:stripped_oak_log
setblock 384 225 277 minecraft:red_terracotta
setblock 384 225 316 minecraft:stripped_oak_log
setblock 385 225 276 minecraft:red_terracotta
fill 385 225 298 394 226 298 minecraft:bone_block
setblock 385 225 315 minecraft:stripped_oak_log
fill 385 225 316 388 225 316 minecraft:red_terracotta
setblock 386 225 314 minecraft:stripped_oak_log
fill 386 225 315 389 225 315 minecraft:red_terracotta
setblock 387 225 278 minecraft:stripped_oak_log
fill 387 225 295 387 225 296 minecraft:bone_block
fill 387 225 300 387 225 301 minecraft:bone_block
setblock 388 225 277 minecraft:stripped_oak_log
setblock 388 225 278 minecraft:red_terracotta
setblock 388 225 279 minecraft:stripped_oak_log
setblock 389 225 276 minecraft:stripped_oak_log
fill 389 225 277 389 227 277 minecraft:red_terracotta
setblock 389 225 278 minecraft:stripped_oak_log
setblock 389 225 316 minecraft:stripped_oak_log
fill 390 225 276 393 225 276 minecraft:red_terracotta
fill 390 225 295 390 225 296 minecraft:bone_block
fill 390 225 300 390 225 301 minecraft:bone_block
setblock 390 225 315 minecraft:stripped_oak_log
fill 390 225 316 393 225 316 minecraft:red_terracotta
fill 391 225 315 394 225 315 minecraft:red_terracotta
setblock 393 225 277 minecraft:stripped_oak_log
fill 393 225 295 393 225 296 minecraft:bone_block
fill 393 225 300 393 225 301 minecraft:bone_block
setblock 394 225 276 minecraft:stripped_oak_log
fill 394 225 277 397 225 277 minecraft:red_terracotta
setblock 394 225 316 minecraft:stripped_oak_log
fill 395 225 276 395 228 276 minecraft:red_terracotta
setblock 395 225 315 minecraft:stripped_oak_log
fill 395 225 316 398 225 316 minecraft:red_terracotta
fill 396 225 295 396 225 296 minecraft:bone_block
fill 396 225 299 396 225 301 minecraft:bone_block
setblock 396 225 314 minecraft:stripped_oak_log
fill 396 225 315 399 225 315 minecraft:red_terracotta
fill 397 225 314 400 225 314 minecraft:red_terracotta
setblock 398 225 277 minecraft:stripped_oak_log
fill 398 225 298 404 226 298 minecraft:bone_block
setblock 399 225 276 minecraft:stripped_oak_log
fill 399 225 277 399 228 277 minecraft:red_terracotta
fill 399 225 295 399 225 296 minecraft:bone_block
fill 399 225 300 399 225 301 minecraft:bone_block
setblock 399 225 316 minecraft:stripped_oak_log
fill 400 225 276 400 228 276 minecraft:red_terracotta
setblock 400 225 315 minecraft:stripped_oak_log
fill 400 225 316 403 225 316 minecraft:red_terracotta
setblock 401 225 314 minecraft:stripped_oak_log
fill 401 225 315 404 225 315 minecraft:red_terracotta
fill 402 225 295 402 225 296 minecraft:bone_block
fill 402 225 300 402 225 301 minecraft:bone_block
fill 402 225 314 402 226 314 minecraft:red_terracotta
setblock 403 225 277 minecraft:stripped_oak_log
setblock 404 225 276 minecraft:stripped_oak_log
setblock 404 225 277 minecraft:red_terracotta
setblock 404 225 316 minecraft:stripped_oak_log
setblock 405 225 276 minecraft:red_terracotta
fill 405 225 295 405 225 296 minecraft:bone_block
fill 405 225 300 405 225 301 minecraft:bone_block
setblock 405 225 315 minecraft:stripped_oak_log
fill 405 225 316 405 228 316 minecraft:red_terracotta
setblock 406 225 300 minecraft:bone_block
fill 406 225 315 406 226 315 minecraft:red_terracotta
setblock 409 225 276 minecraft:stripped_oak_log
setblock 409 225 316 minecraft:stripped_oak_log
fill 410 225 276 413 225 276 minecraft:red_terracotta
setblock 410 225 277 minecraft:stripped_oak_log
setblock 410 225 316 minecraft:red_terracotta
setblock 411 225 301 minecraft:bone_block
setblock 414 225 276 minecraft:stripped_oak_log
setblock 414 225 316 minecraft:stripped_oak_log
fill 415 225 276 415 228 276 minecraft:red_terracotta
fill 415 225 293 415 225 294 minecraft:red_terracotta
setblock 415 225 295 minecraft:stripped_oak_log
fill 415 225 296 415 228 296 minecraft:red_terracotta
setblock 415 225 299 minecraft:red_terracotta
fill 415 225 316 415 226 316 minecraft:red_terracotta
setblock 416 225 278 minecraft:red_terracotta
setblock 416 225 279 minecraft:stripped_oak_log
setblock 416 225 289 minecraft:stripped_oak_log
fill 416 225 290 416 227 290 minecraft:red_terracotta
setblock 416 225 294 minecraft:stripped_oak_log
fill 416 225 295 416 228 295 minecraft:red_terracotta
setblock 416 225 298 minecraft:red_terracotta
setblock 416 225 299 minecraft:stripped_oak_log
fill 416 225 300 416 228 300 minecraft:red_terracotta
fill 416 225 302 416 226 302 minecraft:red_terracotta
setblock 417 225 277 minecraft:red_terracotta
setblock 417 225 278 minecraft:stripped_oak_log
fill 417 225 279 417 225 282 minecraft:red_terracotta
setblock 417 225 283 minecraft:stripped_oak_log
fill 417 225 284 417 225 287 minecraft:red_terracotta
setblock 417 225 288 minecraft:stripped_oak_log
fill 417 225 289 417 228 289 minecraft:red_terracotta
setblock 417 225 293 minecraft:stripped_oak_log
fill 417 225 294 417 228 294 minecraft:red_terracotta
setblock 417 225 298 minecraft:stripped_oak_log
fill 417 225 299 417 228 299 minecraft:red_terracotta
setblock 417 225 303 minecraft:stripped_oak_log
fill 417 225 304 417 225 305 minecraft:red_terracotta
fill 417 225 313 417 235 313 minecraft:stripped_oak_log
setblock 417 225 314 minecraft:red_terracotta
setblock 377 226 276 minecraft:red_terracotta
setblock 377 226 277 minecraft:stripped_oak_log
fill 377 226 278 377 226 281 minecraft:red_terracotta
setblock 377 226 282 minecraft:stripped_oak_log
fill 377 226 283 377 226 286 minecraft:red_terracotta
setblock 377 226 287 minecraft:stripped_oak_log
fill 377 226 288 377 229 288 minecraft:red_terracotta
setblock 377 226 292 minecraft:stripped_oak_log
fill 377 226 293 377 229 293 minecraft:red_terracotta
setblock 377 226 297 minecraft:stripped_oak_log
fill 377 226 298 377 229 298 minecraft:red_terracotta
setblock 377 226 302 minecraft:stripped_oak_log
fill 377 226 303 377 229 303 minecraft:red_terracotta
setblock 377 226 312 minecraft:stripped_oak_log
fill 377 226 313 377 228 313 minecraft:red_terracotta
setblock 378 226 276 minecraft:stripped_oak_log
setblock 378 226 277 minecraft:shroomlight
setblock 378 226 279 minecraft:shroomlight
setblock 378 226 281 minecraft:shroomlight
fill 378 226 282 378 229 282 minecraft:red_terracotta
setblock 378 226 283 minecraft:shroomlight
fill 378 226 284 378 226 285 minecraft:red_terracotta
setblock 378 226 286 minecraft:stripped_oak_log
fill 378 226 287 378 227 287 minecraft:red_terracotta
setblock 378 226 291 minecraft:stripped_oak_log
fill 378 226 292 378 227 292 minecraft:red_terracotta
setblock 378 226 296 minecraft:stripped_oak_log
fill 378 226 297 378 229 297 minecraft:red_terracotta
setblock 378 226 301 minecraft:stripped_oak_log
setblock 378 226 315 minecraft:red_terracotta
setblock 378 226 316 minecraft:stripped_oak_log
setblock 379 226 276 minecraft:shroomlight
setblock 379 226 278 minecraft:shroomlight
setblock 379 226 280 minecraft:shroomlight
fill 379 226 281 379 229 281 minecraft:red_terracotta
setblock 379 226 282 minecraft:shroomlight
setblock 379 226 284 minecraft:shroomlight
fill 379 226 292 379 231 292 minecraft:stripped_oak_log
fill 379 226 295 379 231 295 minecraft:stripped_oak_log
setblock 379 226 296 minecraft:red_terracotta
setblock 379 226 315 minecraft:stripped_oak_log
fill 379 226 316 382 226 316 minecraft:red_terracotta
setblock 380 226 277 minecraft:shroomlight
setblock 380 226 279 minecraft:shroomlight
fill 380 226 280 380 229 280 minecraft:red_terracotta
setblock 380 226 281 minecraft:shroomlight
setblock 380 226 283 minecraft:shroomlight
fill 380 226 315 383 226 315 minecraft:red_terracotta
setblock 381 226 276 minecraft:shroomlight
setblock 381 226 278 minecraft:shroomlight
fill 381 226 279 381 229 279 minecraft:red_terracotta
setblock 381 226 280 minecraft:shroomlight
setblock 381 226 282 minecraft:shroomlight
setblock 381 226 284 minecraft:shroomlight
setblock 381 226 314 minecraft:red_terracotta
setblock 382 226 277 minecraft:shroomlight
fill 382 226 278 382 229 278 minecraft:red_terracotta
setblock 382 226 279 minecraft:shroomlight
setblock 382 226 281 minecraft:shroomlight
setblock 382 226 283 minecraft:shroomlight
setblock 383 226 276 minecraft:shroomlight
fill 383 226 277 383 229 277 minecraft:red_terracotta
setblock 383 226 278 minecraft:shroomlight
fill 383 226 279 383 227 279 minecraft:red_terracotta
setblock 383 226 280 minecraft:shroomlight
setblock 383 226 282 minecraft:shroomlight
setblock 383 226 284 minecraft:shroomlight
setblock 383 226 316 minecraft:stripped_oak_log
fill 384 226 276 384 229 276 minecraft:red_terracotta
setblock 384 226 277 minecraft:shroomlight
fill 384 226 278 384 227 278 minecraft:red_terracotta
setblock 384 226 279 minecraft:shroomlight
setblock 384 226 281 minecraft:shroomlight
setblock 384 226 283 minecraft:shroomlight
setblock 384 226 315 minecraft:stripped_oak_log
fill 384 226 316 387 226 316 minecraft:red_terracotta
setblock 385 226 276 minecraft:shroomlight
fill 385 226 277 385 227 277 minecraft:red_terracotta
setblock 385 226 278 minecraft:shroomlight
setblock 385 226 280 minecraft:shroomlight
setblock 385 226 282 minecraft:shroomlight
setblock 385 226 284 minecraft:shroomlight
fill 385 226 315 388 226 315 minecraft:red_terracotta
fill 386 226 276 386 227 276 minecraft:red_terracotta
setblock 386 226 277 minecraft:shroomlight
setblock 386 226 278 minecraft:stripped_oak_log
setblock 386 226 279 minecraft:shroomlight
setblock 386 226 281 minecraft:shroomlight
setblock 386 226 283 minecraft:shroomlight
setblock 387 226 276 minecraft:shroomlight
setblock 387 226 277 minecraft:stripped_oak_log
setblock 387 226 278 minecraft:shroomlight
setblock 387 226 280 minecraft:shroomlight
setblock 387 226 282 minecraft:shroomlight
setblock 387 226 284 minecraft:shroomlight
setblock 388 226 276 minecraft:stripped_oak_log
setblock 388 226 277 minecraft:shroomlight
fill 388 226 278 388 242 278 minecraft:stripped_oak_log
setblock 388 226 279 minecraft:shroomlight
setblock 388 226 281 minecraft:shroomlight
setblock 388 226 283 minecraft:shroomlight
setblock 388 226 316 minecraft:stripped_oak_log
setblock 389 226 276 minecraft:shroomlight
setblock 389 226 278 minecraft:shroomlight
setblock 389 226 280 minecraft:shroomlight
setblock 389 226 282 minecraft:shroomlight
setblock 389 226 284 minecraft:shroomlight
setblock 389 226 315 minecraft:stripped_oak_log
fill 389 226 316 392 226 316 minecraft:red_terracotta
fill 390 226 276 392 226 276 minecraft:red_terracotta
setblock 390 226 277 minecraft:shroomlight
setblock 390 226 279 minecraft:shroomlight
setblock 390 226 281 minecraft:shroomlight
setblock 390 226 283 minecraft:shroomlight
fill 390 226 315 393 226 315 minecraft:red_terracotta
setblock 392 226 277 minecraft:stripped_oak_log
setblock 393 226 276 minecraft:stripped_oak_log
fill 393 226 277 396 226 277 minecraft:red_terracotta
setblock 393 226 316 minecraft:stripped_oak_log
fill 394 226 276 394 229 276 minecraft:red_terracotta
setblock 394 226 315 minecraft:stripped_oak_log
fill 394 226 316 397 226 316 minecraft:red_terracotta
fill 395 226 315 398 226 315 minecraft:red_terracotta
fill 396 226 314 399 226 314 minecraft:red_terracotta
setblock 397 226 277 minecraft:stripped_oak_log
setblock 398 226 276 minecraft:stripped_oak_log
fill 398 226 277 398 229 277 minecraft:red_terracotta
setblock 398 226 316 minecraft:stripped_oak_log
fill 399 226 276 399 229 276 minecraft:red_terracotta
setblock 399 226 315 minecraft:stripped_oak_log
fill 399 226 316 402 226 316 minecraft:red_terracotta
setblock 400 226 277 minecraft:shroomlight
setblock 400 226 279 minecraft:shroomlight
setblock 400 226 281 minecraft:shroomlight
setblock 400 226 314 minecraft:stripped_oak_log
fill 400 226 315 403 226 315 minecraft:red_terracotta
setblock 401 226 276 minecraft:shroomlight
setblock 401 226 278 minecraft:shroomlight
setblock 401 226 280 minecraft:shroomlight
setblock 401 226 282 minecraft:shroomlight
fill 401 226 314 401 227 314 minecraft:red_terracotta
setblock 402 226 277 minecraft:shroomlight
setblock 402 226 279 minecraft:shroomlight
setblock 402 226 281 minecraft:shroomlight
setblock 403 226 276 minecraft:shroomlight
fill 403 226 277 403 228 277 minecraft:red_terracotta
setblock 403 226 278 minecraft:shroomlight
setblock 403 226 280 minecraft:shroomlight
setblock 403 226 282 minecraft:shroomlight
setblock 403 226 316 minecraft:stripped_oak_log
fill 404 226 276 404 229 276 minecraft:red_terracotta
setblock 404 226 277 minecraft:shroomlight
setblock 404 226 279 minecraft:shroomlight
setblock 404 226 281 minecraft:shroomlight
setblock 404 226 315 minecraft:stripped_oak_log
fill 404 226 316 404 229 316 minecraft:red_terracotta
setblock 405 226 276 minecraft:shroomlight
setblock 405 226 277 minecraft:red_terracotta
setblock 405 226 278 minecraft:shroomlight
setblock 405 226 280 minecraft:shroomlight
setblock 405 226 282 minecraft:shroomlight
setblock 405 226 315 minecraft:red_terracotta
fill 406 226 276 406 227 276 minecraft:red_terracotta
setblock 406 226 277 minecraft:shroomlight
setblock 406 226 279 minecraft:shroomlight
setblock 406 226 281 minecraft:shroomlight
setblock 407 226 276 minecraft:shroomlight
setblock 407 226 278 minecraft:shroomlight
setblock 407 226 280 minecraft:shroomlight
setblock 407 226 282 minecraft:shroomlight
fill 407 226 297 407 226 299 minecraft:bone_block
fill 408 226 276 408 238 276 minecraft:stripped_oak_log
setblock 408 226 277 minecraft:shroomlight
setblock 408 226 279 minecraft:shroomlight
setblock 408 226 281 minecraft:shroomlight
fill 408 226 296 408 226 297 minecraft:bone_block
setblock 408 226 300 minecraft:bone_block
setblock 408 226 316 minecraft:stripped_oak_log
setblock 409 226 276 minecraft:shroomlight
setblock 409 226 278 minecraft:shroomlight
setblock 409 226 280 minecraft:shroomlight
setblock 409 226 282 minecraft:shroomlight
fill 409 226 296 411 226 296 minecraft:bone_block
fill 410 226 276 410 236 276 minecraft:stripped_oak_log
setblock 410 226 277 minecraft:shroomlight
setblock 410 226 279 minecraft:shroomlight
setblock 410 226 281 minecraft:shroomlight
setblock 411 226 276 minecraft:shroomlight
setblock 411 226 278 minecraft:shroomlight
setblock 411 226 280 minecraft:shroomlight
setblock 411 226 282 minecraft:shroomlight
setblock 411 226 297 minecraft:bone_block
setblock 411 226 302 minecraft:shroomlight
setblock 411 226 304 minecraft:shroomlight
setblock 411 226 306 minecraft:shroomlight
setblock 411 226 308 minecraft:shroomlight
setblock 411 226 310 minecraft:shroomlight
setblock 411 226 312 minecraft:shroomlight
setblock 411 226 314 minecraft:shroomlight
setblock 412 226 276 minecraft:red_terracotta
setblock 412 226 277 minecraft:shroomlight
setblock 412 226 279 minecraft:shroomlight
setblock 412 226 281 minecraft:shroomlight
setblock 412 226 303 minecraft:shroomlight
setblock 412 226 305 minecraft:shroomlight
setblock 412 226 307 minecraft:shroomlight
setblock 412 226 309 minecraft:shroomlight
setblock 412 226 311 minecraft:shroomlight
setblock 412 226 313 minecraft:shroomlight
setblock 413 226 276 minecraft:stripped_oak_log
setblock 413 226 302 minecraft:shroomlight
setblock 413 226 304 minecraft:shroomlight
setblock 413 226 306 minecraft:shroomlight
setblock 413 226 308 minecraft:shroomlight
setblock 413 226 310 minecraft:shroomlight
setblock 413 226 312 minecraft:shroomlight
setblock 413 226 314 minecraft:shroomlight
fill 414 226 276 414 229 276 minecraft:red_terracotta
setblock 414 226 303 minecraft:shroomlight
setblock 414 226 305 minecraft:shroomlight
setblock 414 226 307 minecraft:shroomlight
setblock 414 226 309 minecraft:shroomlight
setblock 414 226 311 minecraft:shroomlight
setblock 414 226 313 minecraft:shroomlight
fill 415 226 277 415 227 277 minecraft:red_terracotta
setblock 415 226 294 minecraft:stripped_oak_log
fill 415 226 295 415 227 295 minecraft:red_terracotta
setblock 415 226 299 minecraft:stripped_oak_log
setblock 415 226 302 minecraft:shroomlight
setblock 415 226 304 minecraft:shroomlight
setblock 415 226 306 minecraft:shroomlight
setblock 415 226 308 minecraft:shroomlight
setblock 415 226 310 minecraft:shroomlight
setblock 415 226 312 minecraft:shroomlight
setblock 415 226 314 minecraft:shroomlight
setblock 416 226 278 minecraft:stripped_oak_log
fill 416 226 279 417 226 281 minecraft:red_terracotta
setblock 416 226 289 minecraft:red_terracotta
setblock 416 226 293 minecraft:stripped_oak_log
fill 416 226 294 416 229 294 minecraft:red_terracotta
setblock 416 226 298 minecraft:stripped_oak_log
fill 416 226 299 416 229 299 minecraft:red_terracotta
setblock 416 226 303 minecraft:shroomlight
setblock 416 226 305 minecraft:shroomlight
setblock 416 226 307 minecraft:shroomlight
setblock 416 226 309 minecraft:shroomlight
setblock 416 226 311 minecraft:shroomlight
setblock 416 226 313 minecraft:shroomlight
setblock 417 226 277 minecraft:stripped_oak_log
fill 417 226 278 417 229 278 minecraft:red_terracotta
setblock 417 226 282 minecraft:stripped_oak_log
fill 417 226 283 417 226 286 minecraft:red_terracotta
setblock 417 226 287 minecraft:stripped_oak_log
fill 417 226 288 417 229 288 minecraft:red_terracotta
setblock 417 226 292 minecraft:stripped_oak_log
fill 417 226 293 417 229 293 minecraft:red_terracotta
setblock 417 226 297 minecraft:stripped_oak_log
fill 417 226 298 417 229 298 minecraft:red_terracotta
setblock 417 226 302 minecraft:shroomlight
fill 417 226 303 417 229 303 minecraft:red_terracotta
setblock 417 226 304 minecraft:shroomlight
fill 417 226 305 417 227 305 minecraft:red_terracotta
setblock 417 226 306 minecraft:shroomlight
setblock 417 226 308 minecraft:shroomlight
setblock 417 226 310 minecraft:shroomlight
setblock 417 226 312 minecraft:shroomlight
setblock 417 226 314 minecraft:shroomlight
setblock 377 227 276 minecraft:stripped_oak_log
fill 377 227 277 377 227 280 minecraft:red_terracotta
setblock 377 227 281 minecraft:stripped_oak_log
fill 377 227 282 377 227 285 minecraft:red_terracotta
setblock 377 227 286 minecraft:stripped_oak_log
fill 377 227 287 377 230 287 minecraft:red_terracotta
setblock 377 227 291 minecraft:stripped_oak_log
fill 377 227 292 377 230 292 minecraft:red_terracotta
setblock 377 227 296 minecraft:stripped_oak_log
fill 377 227 297 377 230 297 minecraft:red_terracotta
setblock 377 227 300 minecraft:red_terracotta
setblock 377 227 301 minecraft:stripped_oak_log
fill 377 227 302 377 230 302 minecraft:red_terracotta
fill 377 227 304 377 228 304 minecraft:red_terracotta
fill 377 227 314 377 227 315 minecraft:red_terracotta
setblock 377 227 316 minecraft:stripped_oak_log
fill 378 227 276 378 228 277 minecraft:red_terracotta
setblock 378 227 279 minecraft:red_terracotta
setblock 378 227 280 minecraft:stripped_oak_log
fill 378 227 281 378 228 281 minecraft:red_terracotta
fill 378 227 283 378 227 284 minecraft:red_terracotta
setblock 378 227 285 minecraft:stripped_oak_log
fill 378 227 286 378 230 286 minecraft:red_terracotta
fill 378 227 290 378 231 290 minecraft:stripped_oak_log
setblock 378 227 291 minecraft:red_terracotta
setblock 378 227 295 minecraft:stripped_oak_log
fill 378 227 296 378 229 296 minecraft:red_terracotta
setblock 378 227 300 minecraft:stripped_oak_log
fill 378 227 301 378 230 301 minecraft:red_terracotta
setblock 378 227 315 minecraft:stripped_oak_log
fill 378 227 316 381 227 316 minecraft:red_terracotta
fill 379 227 276 379 228 276 minecraft:red_terracotta
setblock 379 227 278 minecraft:red_terracotta
setblock 379 227 279 minecraft:stripped_oak_log
fill 379 227 280 379 228 280 minecraft:red_terracotta
fill 379 227 282 379 228 282 minecraft:red_terracotta
fill 379 227 284 379 228 284 minecraft:stripped_oak_log
setblock 379 227 285 minecraft:light[level=12]
fill 379 227 293 379 231 294 minecraft:stripped_oak_log
fill 379 227 296 379 231 296 minecraft:stripped_oak_log
setblock 379 227 299 minecraft:light[level=12]
setblock 379 227 306 minecraft:light[level=12]
setblock 379 227 313 minecraft:light[level=12]
fill 379 227 315 382 227 315 minecraft:red_terracotta
setblock 380 227 277 minecraft:red_terracotta
setblock 380 227 278 minecraft:stripped_oak_log
fill 380 227 279 380 228 279 minecraft:red_terracotta
fill 380 227 281 380 228 281 minecraft:red_terracotta
fill 380 227 283 380 228 283 minecraft:stripped_oak_log
setblock 381 227 276 minecraft:red_terracotta
setblock 381 227 277 minecraft:stripped_oak_log
fill 381 227 278 381 228 278 minecraft:red_terracotta
fill 381 227 280 381 228 280 minecraft:stripped_oak_log
fill 381 227 282 381 228 282 minecraft:stripped_oak_log
fill 381 227 284 381 228 284 minecraft:stripped_oak_log
setblock 382 227 276 minecraft:stripped_oak_log
fill 382 227 277 382 228 277 minecraft:red_terracotta
fill 382 227 279 382 228 279 minecraft:red_terracotta
fill 382 227 281 382 228 281 minecraft:stripped_oak_log
fill 382 227 283 382 228 283 minecraft:stripped_oak_log
setblock 382 227 316 minecraft:stripped_oak_log
fill 383 227 276 383 228 276 minecraft:red_terracotta
fill 383 227 278 383 228 278 minecraft:red_terracotta
fill 383 227 280 383 228 280 minecraft:stripped_oak_log
fill 383 227 282 383 228 282 minecraft:stripped_oak_log
fill 383 227 284 383 228 284 minecraft:stripped_oak_log
setblock 383 227 315 minecraft:stripped_oak_log
fill 383 227 316 386 227 316 minecraft:red_terracotta
fill 384 227 277 384 228 277 minecraft:red_terracotta
fill 384 227 279 384 228 279 minecraft:stripped_oak_log
fill 384 227 281 384 228 281 minecraft:stripped_oak_log
fill 384 227 283 384 228 283 minecraft:stripped_oak_log
fill 384 227 315 387 227 315 minecraft:red_terracotta
fill 385 227 276 385 228 276 minecraft:red_terracotta
setblock 385 227 278 minecraft:stripped_oak_log
fill 385 227 280 385 228 280 minecraft:stripped_oak_log
fill 385 227 282 385 228 282 minecraft:stripped_oak_log
fill 385 227 284 385 228 284 minecraft:stripped_oak_log
setblock 386 227 277 minecraft:stripped_oak_log
setblock 386 227 278 minecraft:red_terracotta
fill 386 227 279 386 228 279 minecraft:stripped_oak_log
fill 386 227 281 386 228 281 minecraft:stripped_oak_log
fill 386 227 283 386 228 283 minecraft:stripped_oak_log
setblock 386 227 285 minecraft:light[level=12]
setblock 386 227 292 minecraft:light[level=12]
setblock 386 227 299 minecraft:light[level=12]
setblock 386 227 306 minecraft:light[level=12]
setblock 386 227 313 minecraft:light[level=12]
setblock 387 227 276 minecraft:stripped_oak_log
fill 387 227 277 388 228 277 minecraft:red_terracotta
fill 387 227 278 387 228 278 minecraft:stripped_oak_log
fill 387 227 280 387 228 280 minecraft:stripped_oak_log
fill 387 227 282 387 228 282 minecraft:stripped_oak_log
fill 387 227 284 387 228 284 minecraft:stripped_oak_log
setblock 387 227 316 minecraft:stripped_oak_log
fill 388 227 276 391 227 276 minecraft:red_terracotta
fill 388 227 279 388 228 279 minecraft:stripped_oak_log
fill 388 227 281 388 228 281 minecraft:stripped_oak_log
fill 388 227 283 388 228 283 minecraft:stripped_oak_log
setblock 388 227 315 minecraft:stripped_oak_log
fill 388 227 316 391 227 316 minecraft:red_terracotta
fill 389 227 278 389 228 278 minecraft:stripped_oak_log
fill 389 227 280 389 228 280 minecraft:stripped_oak_log
fill 389 227 282 389 228 282 minecraft:stripped_oak_log
fill 389 227 284 389 228 284 minecraft:stripped_oak_log
setblock 390 227 277 minecraft:red_terracotta
fill 390 227 279 390 228 279 minecraft:stripped_oak_log
fill 390 227 281 390 228 281 minecraft:stripped_oak_log
fill 390 227 283 390 228 283 minecraft:stripped_oak_log
setblock 391 227 277 minecraft:stripped_oak_log
setblock 392 227 276 minecraft:stripped_oak_log
fill 392 227 277 395 227 277 minecraft:red_terracotta
setblock 392 227 315 minecraft:red_terracotta
setblock 392 227 316 minecraft:stripped_oak_log
fill 393 227 276 393 230 276 minecraft:red_terracotta
setblock 393 227 278 minecraft:light[level=12]
setblock 393 227 285 minecraft:light[level=12]
setblock 393 227 292 minecraft:light[level=12]
setblock 393 227 299 minecraft:light[level=12]
setblock 393 227 306 minecraft:light[level=12]
setblock 393 227 313 minecraft:light[level=12]
setblock 393 227 315 minecraft:stripped_oak_log
fill 393 227 316 396 227 316 minecraft:red_terracotta
fill 394 227 315 397 227 315 minecraft:red_terracotta
setblock 396 227 277 minecraft:stripped_oak_log
setblock 397 227 276 minecraft:stripped_oak_log
fill 397 227 277 397 230 277 minecraft:red_terracotta
fill 397 227 314 398 227 314 minecraft:red_terracotta
setblock 397 227 316 minecraft:stripped_oak_log
fill 398 227 276 398 230 276 minecraft:red_terracotta
setblock 398 227 315 minecraft:stripped_oak_log
fill 398 227 316 401 227 316 minecraft:red_terracotta
setblock 399 227 314 minecraft:stripped_oak_log
fill 399 227 315 402 227 315 minecraft:red_terracotta
setblock 400 227 277 minecraft:red_terracotta
fill 400 227 279 400 228 279 minecraft:stripped_oak_log
fill 400 227 281 400 228 281 minecraft:stripped_oak_log
setblock 400 227 285 minecraft:light[level=12]
setblock 400 227 292 minecraft:light[level=12]
setblock 400 227 299 minecraft:light[level=12]
setblock 400 227 306 minecraft:light[level=12]
setblock 400 227 313 minecraft:light[level=12]
setblock 400 227 314 minecraft:red_terracotta
setblock 401 227 276 minecraft:red_terracotta
fill 401 227 277 401 227 278 minecraft:stripped_oak_log
fill 401 227 280 401 228 280 minecraft:stripped_oak_log
fill 401 227 282 401 228 282 minecraft:stripped_oak_log
setblock 402 227 276 minecraft:stripped_oak_log
fill 402 227 277 402 228 277 minecraft:red_terracotta
fill 402 227 279 402 228 279 minecraft:stripped_oak_log
fill 402 227 281 402 228 281 minecraft:stripped_oak_log
setblock 402 227 316 minecraft:stripped_oak_log
fill 403 227 276 403 228 276 minecraft:red_terracotta
fill 403 227 278 403 228 278 minecraft:stripped_oak_log
fill 403 227 280 403 228 280 minecraft:stripped_oak_log
fill 403 227 282 403 228 282 minecraft:stripped_oak_log
setblock 403 227 315 minecraft:stripped_oak_log
fill 403 227 316 403 229 316 minecraft:red_terracotta
setblock 404 227 277 minecraft:red_terracotta
fill 404 227 279 404 228 279 minecraft:stripped_oak_log
fill 404 227 281 404 228 281 minecraft:stripped_oak_log
setblock 404 227 315 minecraft:red_terracotta
fill 405 227 276 405 228 276 minecraft:red_terracotta
fill 405 227 277 405 228 278 minecraft:stripped_oak_log
fill 405 227 280 405 228 280 minecraft:stripped_oak_log
fill 405 227 282 405 228 282 minecraft:stripped_oak_log
fill 406 227 277 406 228 277 minecraft:stripped_oak_log
fill 406 227 279 406 228 279 minecraft:stripped_oak_log
fill 406 227 281 406 228 281 minecraft:stripped_oak_log
fill 407 227 276 407 228 276 minecraft:stripped_oak_log
fill 407 227 278 407 228 278 minecraft:stripped_oak_log
fill 407 227 280 407 228 280 minecraft:stripped_oak_log
fill 407 227 282 407 228 282 minecraft:stripped_oak_log
setblock 407 227 285 minecraft:light[level=12]
setblock 407 227 292 minecraft:light[level=12]
setblock 407 227 299 minecraft:light[level=12]
setblock 407 227 306 minecraft:light[level=12]
setblock 407 227 313 minecraft:light[level=12]
setblock 407 227 316 minecraft:stripped_oak_log
fill 408 227 277 408 228 277 minecraft:stripped_oak_log
fill 408 227 279 408 228 279 minecraft:stripped_oak_log
fill 408 227 281 408 228 281 minecraft:stripped_oak_log
fill 408 227 298 410 227 298 minecraft:bone_block
fill 409 227 276 409 228 276 minecraft:stripped_oak_log
fill 409 227 278 411 228 278 minecraft:stripped_oak_log
fill 409 227 280 409 228 280 minecraft:stripped_oak_log
fill 409 227 282 409 228 282 minecraft:stripped_oak_log
fill 409 227 299 411 227 299 minecraft:bone_block
fill 410 227 277 410 228 277 minecraft:stripped_oak_log
fill 410 227 279 410 228 279 minecraft:stripped_oak_log
fill 410 227 281 410 228 281 minecraft:stripped_oak_log
fill 411 227 276 412 228 276 minecraft:stripped_oak_log
fill 411 227 280 411 228 280 minecraft:stripped_oak_log
fill 411 227 282 411 228 282 minecraft:stripped_oak_log
fill 411 227 302 411 229 302 minecraft:stripped_oak_log
fill 411 227 304 411 229 304 minecraft:stripped_oak_log
fill 411 227 306 411 229 306 minecraft:stripped_oak_log
fill 411 227 308 411 229 308 minecraft:stripped_oak_log
fill 411 227 310 411 229 310 minecraft:stripped_oak_log
fill 411 227 312 411 229 312 minecraft:stripped_oak_log
fill 411 227 314 411 229 314 minecraft:stripped_oak_log
fill 412 227 277 412 228 277 minecraft:stripped_oak_log
fill 412 227 279 412 228 279 minecraft:stripped_oak_log
fill 412 227 281 412 228 281 minecraft:stripped_oak_log
fill 412 227 303 412 229 303 minecraft:stripped_oak_log
fill 412 227 305 412 229 305 minecraft:stripped_oak_log
fill 412 227 307 412 229 307 minecraft:stripped_oak_log
fill 412 227 309 412 229 309 minecraft:stripped_oak_log
fill 412 227 311 412 229 311 minecraft:stripped_oak_log
fill 412 227 313 412 229 313 minecraft:stripped_oak_log
fill 413 227 276 413 230 276 minecraft:red_terracotta
fill 413 227 302 413 228 302 minecraft:stripped_oak_log
fill 413 227 304 413 228 304 minecraft:stripped_oak_log
fill 413 227 306 413 228 306 minecraft:stripped_oak_log
fill 413 227 308 413 228 308 minecraft:stripped_oak_log
fill 413 227 310 413 228 310 minecraft:stripped_oak_log
fill 413 227 312 413 228 312 minecraft:stripped_oak_log
fill 413 227 314 413 228 314 minecraft:stripped_oak_log
setblock 414 227 278 minecraft:light[level=12]
setblock 414 227 285 minecraft:light[level=12]
setblock 414 227 292 minecraft:light[level=12]
setblock 414 227 299 minecraft:light[level=12]
fill 414 227 303 414 228 303 minecraft:stripped_oak_log
fill 414 227 305 414 228 305 minecraft:stripped_oak_log
fill 414 227 307 414 228 307 minecraft:stripped_oak_log
fill 414 227 309 414 228 309 minecraft:stripped_oak_log
fill 414 227 311 414 228 311 minecraft:stripped_oak_log
fill 414 227 313 414 228 313 minecraft:stripped_oak_log
setblock 415 227 298 minecraft:stripped_oak_log
fill 415 227 299 415 228 299 minecraft:red_terracotta
fill 415 227 302 416 227 302 minecraft:stripped_oak_log
fill 415 227 304 415 228 304 minecraft:stripped_oak_log
fill 415 227 306 415 228 306 minecraft:stripped_oak_log
fill 415 227 308 415 228 308 minecraft:stripped_oak_log
fill 415 227 310 415 228 310 minecraft:stripped_oak_log
fill 415 227 312 415 228 312 minecraft:stripped_oak_log
fill 415 227 314 415 228 314 minecraft:stripped_oak_log
setblock 416 227 276 minecraft:red_terracotta
setblock 416 227 277 minecraft:stripped_oak_log
fill 416 227 278 416 227 281 minecraft:red_terracotta
setblock 416 227 282 minecraft:stripped_oak_log
fill 416 227 283 417 229 283 minecraft:red_terracotta
setblock 416 227 292 minecraft:stripped_oak_log
fill 416 227 293 416 230 293 minecraft:red_terracotta
setblock 416 227 297 minecraft:stripped_oak_log
fill 416 227 298 416 230 298 minecraft:red_terracotta
setblock 416 227 303 minecraft:stripped_oak_log
fill 416 227 305 416 228 305 minecraft:stripped_oak_log
fill 416 227 307 416 228 307 minecraft:stripped_oak_log
fill 416 227 309 416 228 309 minecraft:stripped_oak_log
fill 416 227 311 416 228 311 minecraft:stripped_oak_log
fill 416 227 313 416 228 313 minecraft:stripped_oak_log
setblock 417 227 276 minecraft:stripped_oak_log
fill 417 227 277 417 230 277 minecraft:red_terracotta
fill 417 227 279 417 227 280 minecraft:red_terracotta
setblock 417 227 281 minecraft:stripped_oak_log
fill 417 227 282 417 230 282 minecraft:red_terracotta
fill 417 227 284 417 227 285 minecraft:red_terracotta
setblock 417 227 286 minecraft:stripped_oak_log
fill 417 227 287 417 230 287 minecraft:red_terracotta
setblock 417 227 291 minecraft:stripped_oak_log
fill 417 227 292 417 230 292 minecraft:red_terracotta
setblock 417 227 296 minecraft:stripped_oak_log
fill 417 227 297 417 230 297 minecraft:red_terracotta
setblock 417 227 301 minecraft:stripped_oak_log
fill 417 227 302 417 228 302 minecraft:red_terracotta
fill 417 227 304 417 228 304 minecraft:red_terracotta
fill 417 227 306 417 228 306 minecraft:stripped_oak_log
fill 417 227 308 417 228 308 minecraft:stripped_oak_log
fill 417 227 310 417 228 310 minecraft:stripped_oak_log
fill 417 227 312 417 228 312 minecraft:stripped_oak_log
fill 417 227 314 417 228 314 minecraft:stripped_oak_log
setblock 417 227 316 minecraft:stripped_oak_log
fill 376 228 275 376 231 317 minecraft:red_terracotta
fill 377 228 275 377 228 279 minecraft:red_terracotta
setblock 377 228 280 minecraft:stripped_oak_log
fill 377 228 281 377 228 284 minecraft:red_terracotta
setblock 377 228 285 minecraft:stripped_oak_log
fill 377 228 286 377 231 286 minecraft:red_terracotta
setblock 377 228 290 minecraft:stripped_oak_log
fill 377 228 291 377 230 291 minecraft:red_terracotta
setblock 377 228 295 minecraft:stripped_oak_log
fill 377 228 296 377 231 296 minecraft:red_terracotta
setblock 377 228 300 minecraft:stripped_oak_log
fill 377 228 301 377 231 301 minecraft:red_terracotta
setblock 377 228 314 minecraft:red_terracotta
setblock 377 228 315 minecraft:stripped_oak_log
fill 377 228 316 380 228 317 minecraft:red_terracotta
fill 378 228 275 418 231 275 minecraft:red_terracotta
setblock 378 228 279 minecraft:stripped_oak_log
fill 378 228 280 378 231 280 minecraft:red_terracotta
setblock 378 228 283 minecraft:red_terracotta
setblock 378 228 284 minecraft:stripped_oak_log
fill 378 228 285 378 231 285 minecraft:red_terracotta
fill 378 228 288 378 231 289 minecraft:stripped_oak_log
fill 378 228 291 378 231 292 minecraft:stripped_oak_log
fill 378 228 294 378 231 294 minecraft:stripped_oak_log
setblock 378 228 295 minecraft:red_terracotta
setblock 378 228 299 minecraft:stripped_oak_log
fill 378 228 300 378 231 300 minecraft:red_terracotta
fill 378 228 302 378 229 302 minecraft:red_terracotta
fill 378 228 315 381 228 315 minecraft:red_terracotta
setblock 379 228 278 minecraft:stripped_oak_log
fill 379 228 279 379 231 279 minecraft:red_terracotta
setblock 379 228 283 minecraft:stripped_oak_log
setblock 380 228 277 minecraft:stripped_oak_log
fill 380 228 278 380 231 278 minecraft:red_terracotta
setblock 381 228 276 minecraft:stripped_oak_log
fill 381 228 277 381 231 277 minecraft:red_terracotta
setblock 381 228 316 minecraft:stripped_oak_log
fill 381 228 317 418 231 317 minecraft:red_terracotta
fill 382 228 276 382 231 276 minecraft:red_terracotta
setblock 382 228 315 minecraft:stripped_oak_log
fill 382 228 316 385 228 316 minecraft:red_terracotta
fill 383 228 279 383 242 279 minecraft:stripped_oak_log
fill 383 228 315 385 228 315 minecraft:red_terracotta
setblock 384 228 278 minecraft:stripped_oak_log
setblock 385 228 277 minecraft:stripped_oak_log
setblock 385 228 278 minecraft:red_terracotta
setblock 386 228 276 minecraft:stripped_oak_log
setblock 386 228 277 minecraft:red_terracotta
fill 386 228 278 386 242 278 minecraft:stripped_oak_log
setblock 386 228 316 minecraft:stripped_oak_log
fill 387 228 276 390 228 276 minecraft:red_terracotta
fill 387 228 316 390 228 316 minecraft:red_terracotta
fill 389 228 277 390 228 277 minecraft:stripped_oak_log
setblock 391 228 276 minecraft:stripped_oak_log
setblock 391 228 316 minecraft:stripped_oak_log
fill 392 228 276 392 231 276 minecraft:red_terracotta
fill 392 228 316 395 228 316 minecraft:red_terracotta
setblock 394 228 277 minecraft:red_terracotta
fill 394 228 315 396 228 315 minecraft:red_terracotta
setblock 395 228 277 minecraft:stripped_oak_log
setblock 396 228 276 minecraft:stripped_oak_log
fill 396 228 277 396 231 277 minecraft:red_terracotta
setblock 396 228 316 minecraft:stripped_oak_log
fill 397 228 276 397 231 276 minecraft:red_terracotta
setblock 397 228 315 minecraft:stripped_oak_log
fill 397 228 316 400 228 316 minecraft:red_terracotta
fill 398 228 315 401 228 315 minecraft:red_terracotta
setblock 400 228 277 minecraft:stripped_oak_log
setblock 401 228 276 minecraft:stripped_oak_log
fill 401 228 277 401 229 277 minecraft:red_terracotta
setblock 401 228 278 minecraft:stripped_oak_log
setblock 401 228 316 minecraft:stripped_oak_log
fill 402 228 276 402 231 276 minecraft:red_terracotta
setblock 402 228 315 minecraft:stripped_oak_log
fill 402 228 316 402 230 316 minecraft:red_terracotta
setblock 403 228 315 minecraft:red_terracotta
setblock 404 228 277 minecraft:stripped_oak_log
fill 406 228 276 406 238 276 minecraft:stripped_oak_log
setblock 415 228 277 minecraft:stripped_oak_log
setblock 415 228 297 minecraft:stripped_oak_log
setblock 415 228 298 minecraft:red_terracotta
setblock 415 228 302 minecraft:stripped_oak_log
setblock 416 228 276 minecraft:stripped_oak_log
fill 416 228 277 416 228 280 minecraft:red_terracotta
setblock 416 228 281 minecraft:stripped_oak_log
fill 416 228 282 416 231 282 minecraft:red_terracotta
fill 416 228 284 418 228 284 minecraft:red_terracotta
setblock 416 228 291 minecraft:stripped_oak_log
fill 416 228 292 416 229 292 minecraft:red_terracotta
setblock 416 228 296 minecraft:stripped_oak_log
fill 416 228 297 416 231 297 minecraft:red_terracotta
setblock 416 228 301 minecraft:stripped_oak_log
fill 416 228 302 416 228 303 minecraft:red_terracotta
fill 417 228 276 418 231 276 minecraft:red_terracotta
fill 417 228 279 418 228 279 minecraft:red_terracotta
setblock 417 228 280 minecraft:stripped_oak_log
fill 417 228 281 418 231 281 minecraft:red_terracotta
setblock 417 228 285 minecraft:stripped_oak_log
fill 417 228 286 418 231 286 minecraft:red_terracotta
setblock 417 228 290 minecraft:stripped_oak_log
fill 417 228 291 418 231 291 minecraft:red_terracotta
setblock 417 228 295 minecraft:stripped_oak_log
fill 417 228 296 418 231 296 minecraft:red_terracotta
setblock 417 228 300 minecraft:stripped_oak_log
fill 417 228 301 418 231 301 minecraft:red_terracotta
setblock 417 228 305 minecraft:stripped_oak_log
fill 417 228 316 418 229 316 minecraft:red_terracotta
fill 418 228 277 418 231 278 minecraft:red_terracotta
fill 418 228 280 418 231 280 minecraft:red_terracotta
fill 418 228 282 418 231 283 minecraft:red_terracotta
fill 418 228 285 418 231 285 minecraft:red_terracotta
fill 418 228 287 418 231 290 minecraft:red_terracotta
fill 418 228 292 418 231 295 minecraft:red_terracotta
fill 418 228 297 418 231 300 minecraft:red_terracotta
fill 418 228 302 418 231 315 minecraft:red_terracotta
fill 377 229 275 377 229 278 minecraft:red_terracotta
setblock 377 229 279 minecraft:stripped_oak_log
fill 377 229 280 377 229 283 minecraft:red_terracotta
setblock 377 229 284 minecraft:stripped_oak_log
fill 377 229 285 377 232 285 minecraft:red_terracotta
setblock 377 229 289 minecraft:stripped_oak_log
fill 377 229 290 377 232 290 minecraft:red_terracotta
setblock 377 229 294 minecraft:stripped_oak_log
fill 377 229 295 377 232 295 minecraft:red_terracotta
setblock 377 229 299 minecraft:stripped_oak_log
fill 377 229 300 377 232 300 minecraft:red_terracotta
setblock 377 229 304 minecraft:stripped_oak_log
fill 377 229 305 377 232 305 minecraft:red_terracotta
setblock 377 229 314 minecraft:stripped_oak_log
fill 377 229 315 377 231 317 minecraft:red_terracotta
fill 378 229 276 378 230 276 minecraft:red_terracotta
setblock 378 229 277 minecraft:shroomlight
setblock 378 229 278 minecraft:stripped_oak_log
setblock 378 229 279 minecraft:shroomlight
setblock 378 229 281 minecraft:shroomlight
setblock 378 229 283 minecraft:shroomlight
fill 378 229 284 378 232 284 minecraft:red_terracotta
fill 378 229 293 378 231 293 minecraft:stripped_oak_log
fill 378 229 295 378 231 295 minecraft:stripped_oak_log
setblock 378 229 298 minecraft:stripped_oak_log
fill 378 229 299 378 231 299 minecraft:red_terracotta
fill 378 229 316 379 229 317 minecraft:red_terracotta
setblock 379 229 276 minecraft:shroomlight
setblock 379 229 277 minecraft:stripped_oak_log
setblock 379 229 278 minecraft:shroomlight
setblock 379 229 280 minecraft:shroomlight
setblock 379 229 282 minecraft:shroomlight
fill 379 229 283 379 232 283 minecraft:red_terracotta
setblock 379 229 284 minecraft:shroomlight
fill 379 229 315 380 229 315 minecraft:red_terracotta
setblock 380 229 276 minecraft:stripped_oak_log
setblock 380 229 277 minecraft:shroomlight
setblock 380 229 279 minecraft:shroomlight
setblock 380 229 281 minecraft:shroomlight
setblock 380 229 283 minecraft:shroomlight
setblock 380 229 316 minecraft:stripped_oak_log
fill 380 229 317 380 231 317 minecraft:red_terracotta
setblock 381 229 276 minecraft:shroomlight
setblock 381 229 278 minecraft:shroomlight
setblock 381 229 280 minecraft:shroomlight
setblock 381 229 282 minecraft:shroomlight
setblock 381 229 284 minecraft:shroomlight
setblock 381 229 315 minecraft:stripped_oak_log
fill 381 229 316 384 229 316 minecraft:red_terracotta
setblock 382 229 277 minecraft:shroomlight
setblock 382 229 279 minecraft:shroomlight
setblock 382 229 281 minecraft:shroomlight
setblock 382 229 283 minecraft:shroomlight
fill 382 229 315 383 229 315 minecraft:red_terracotta
setblock 383 229 276 minecraft:shroomlight
setblock 383 229 278 minecraft:shroomlight
setblock 383 229 280 minecraft:shroomlight
setblock 383 229 282 minecraft:shroomlight
setblock 383 229 284 minecraft:shroomlight
setblock 384 229 277 minecraft:shroomlight
setblock 384 229 278 minecraft:red_terracotta
setblock 384 229 279 minecraft:shroomlight
setblock 384 229 281 minecraft:shroomlight
setblock 384 229 283 minecraft:shroomlight
setblock 385 229 276 minecraft:shroomlight
fill 385 229 277 385 231 277 minecraft:red_terracotta
setblock 385 229 278 minecraft:shroomlight
setblock 385 229 280 minecraft:shroomlight
setblock 385 229 282 minecraft:shroomlight
setblock 385 229 284 minecraft:shroomlight
setblock 385 229 316 minecraft:stripped_oak_log
fill 386 229 276 386 232 276 minecraft:red_terracotta
setblock 386 229 277 minecraft:shroomlight
setblock 386 229 279 minecraft:shroomlight
setblock 386 229 281 minecraft:shroomlight
setblock 386 229 283 minecraft:shroomlight
fill 386 229 316 389 229 316 minecraft:red_terracotta
setblock 387 229 276 minecraft:shroomlight
setblock 387 229 277 minecraft:red_terracotta
setblock 387 229 278 minecraft:shroomlight
setblock 387 229 280 minecraft:shroomlight
setblock 387 229 282 minecraft:shroomlight
setblock 387 229 284 minecraft:shroomlight
fill 388 229 276 388 230 276 minecraft:red_terracotta
setblock 388 229 277 minecraft:shroomlight
setblock 388 229 279 minecraft:shroomlight
setblock 388 229 281 minecraft:shroomlight
setblock 388 229 283 minecraft:shroomlight
setblock 389 229 276 minecraft:shroomlight
fill 389 229 277 389 231 277 minecraft:stripped_oak_log
setblock 389 229 278 minecraft:shroomlight
setblock 389 229 280 minecraft:shroomlight
setblock 389 229 282 minecraft:shroomlight
setblock 389 229 284 minecraft:shroomlight
setblock 390 229 276 minecraft:stripped_oak_log
setblock 390 229 277 minecraft:shroomlight
setblock 390 229 279 minecraft:shroomlight
setblock 390 229 281 minecraft:shroomlight
setblock 390 229 283 minecraft:shroomlight
setblock 390 229 316 minecraft:stripped_oak_log
fill 391 229 276 391 231 276 minecraft:red_terracotta
fill 391 229 316 394 229 316 minecraft:red_terracotta
setblock 395 229 276 minecraft:stripped_oak_log
setblock 395 229 277 minecraft:red_terracotta
setblock 395 229 315 minecraft:red_terracotta
setblock 395 229 316 minecraft:stripped_oak_log
fill 396 229 276 396 232 276 minecraft:red_terracotta
setblock 396 229 315 minecraft:stripped_oak_log
fill 396 229 316 399 229 316 minecraft:red_terracotta
fill 397 229 315 400 229 315 minecraft:red_terracotta
setblock 399 229 277 minecraft:stripped_oak_log
setblock 400 229 276 minecraft:stripped_oak_log
setblock 400 229 277 minecraft:shroomlight
setblock 400 229 279 minecraft:shroomlight
setblock 400 229 281 minecraft:shroomlight
setblock 400 229 316 minecraft:stripped_oak_log
setblock 401 229 276 minecraft:shroomlight
setblock 401 229 278 minecraft:shroomlight
setblock 401 229 280 minecraft:shroomlight
setblock 401 229 282 minecraft:shroomlight
setblock 401 229 315 minecraft:stripped_oak_log
fill 401 229 316 401 231 316 minecraft:red_terracotta
setblock 402 229 277 minecraft:shroomlight
setblock 402 229 279 minecraft:shroomlight
setblock 402 229 281 minecraft:shroomlight
setblock 403 229 276 minecraft:shroomlight
fill 403 229 277 403 238 277 minecraft:stripped_oak_log
setblock 403 229 278 minecraft:shroomlight
setblock 403 229 280 minecraft:shroomlight
setblock 403 229 282 minecraft:shroomlight
setblock 404 229 277 minecraft:shroomlight
setblock 404 229 279 minecraft:shroomlight
setblock 404 229 281 minecraft:shroomlight
setblock 405 229 276 minecraft:shroomlight
fill 405 229 277 405 238 277 minecraft:stripped_oak_log
setblock 405 229 278 minecraft:shroomlight
setblock 405 229 280 minecraft:shroomlight
setblock 405 229 282 minecraft:shroomlight
setblock 406 229 277 minecraft:shroomlight
setblock 406 229 279 minecraft:shroomlight
setblock 406 229 281 minecraft:shroomlight
setblock 407 229 276 minecraft:shroomlight
setblock 407 229 278 minecraft:shroomlight
setblock 407 229 280 minecraft:shroomlight
setblock 407 229 282 minecraft:shroomlight
setblock 408 229 277 minecraft:shroomlight
setblock 408 229 279 minecraft:shroomlight
setblock 408 229 281 minecraft:shroomlight
setblock 409 229 276 minecraft:shroomlight
setblock 409 229 278 minecraft:shroomlight
setblock 409 229 280 minecraft:shroomlight
setblock 409 229 282 minecraft:shroomlight
setblock 410 229 277 minecraft:shroomlight
fill 410 229 278 410 238 278 minecraft:stripped_oak_log
setblock 410 229 279 minecraft:shroomlight
setblock 410 229 281 minecraft:shroomlight
setblock 411 229 276 minecraft:shroomlight
setblock 411 229 278 minecraft:shroomlight
setblock 411 229 280 minecraft:shroomlight
setblock 411 229 282 minecraft:shroomlight
fill 412 229 276 412 233 276 minecraft:stripped_oak_log
setblock 412 229 277 minecraft:shroomlight
setblock 412 229 279 minecraft:shroomlight
setblock 412 229 281 minecraft:shroomlight
setblock 413 229 302 minecraft:shroomlight
setblock 413 229 304 minecraft:shroomlight
setblock 413 229 306 minecraft:shroomlight
setblock 413 229 308 minecraft:shroomlight
setblock 413 229 310 minecraft:shroomlight
setblock 413 229 312 minecraft:shroomlight
setblock 413 229 314 minecraft:shroomlight
setblock 414 229 303 minecraft:shroomlight
setblock 414 229 305 minecraft:shroomlight
setblock 414 229 307 minecraft:shroomlight
setblock 414 229 309 minecraft:shroomlight
setblock 414 229 311 minecraft:shroomlight
setblock 414 229 313 minecraft:shroomlight
setblock 415 229 276 minecraft:stripped_oak_log
fill 415 229 277 416 231 277 minecraft:red_terracotta
setblock 415 229 302 minecraft:shroomlight
setblock 415 229 304 minecraft:shroomlight
setblock 415 229 306 minecraft:shroomlight
setblock 415 229 308 minecraft:shroomlight
setblock 415 229 310 minecraft:shroomlight
setblock 415 229 312 minecraft:shroomlight
setblock 415 229 314 minecraft:shroomlight
fill 416 229 276 416 232 276 minecraft:red_terracotta
fill 416 229 278 416 229 279 minecraft:red_terracotta
setblock 416 229 280 minecraft:stripped_oak_log
fill 416 229 281 416 232 281 minecraft:red_terracotta
setblock 416 229 284 minecraft:red_terracotta
setblock 416 229 285 minecraft:stripped_oak_log
setblock 416 229 295 minecraft:stripped_oak_log
fill 416 229 296 416 232 296 minecraft:red_terracotta
setblock 416 229 300 minecraft:stripped_oak_log
fill 416 229 301 416 231 302 minecraft:red_terracotta
setblock 416 229 303 minecraft:shroomlight
setblock 416 229 305 minecraft:shroomlight
setblock 416 229 307 minecraft:shroomlight
setblock 416 229 309 minecraft:shroomlight
setblock 416 229 311 minecraft:shroomlight
setblock 416 229 313 minecraft:shroomlight
setblock 417 229 279 minecraft:stripped_oak_log
fill 417 229 280 417 232 280 minecraft:red_terracotta
setblock 417 229 284 minecraft:stripped_oak_log
fill 417 229 285 417 232 285 minecraft:red_terracotta
setblock 417 229 289 minecraft:stripped_oak_log
fill 417 229 290 417 232 290 minecraft:red_terracotta
setblock 417 229 294 minecraft:stripped_oak_log
fill 417 229 295 417 232 295 minecraft:red_terracotta
setblock 417 229 299 minecraft:stripped_oak_log
fill 417 229 300 417 232 300 minecraft:red_terracotta
setblock 417 229 302 minecraft:shroomlight
setblock 417 229 304 minecraft:shroomlight
fill 417 229 305 417 232 305 minecraft:red_terracotta
setblock 417 229 306 minecraft:shroomlight
setblock 417 229 308 minecraft:shroomlight
setblock 417 229 310 minecraft:shroomlight
setblock 417 229 312 minecraft:shroomlight
setblock 417 229 314 minecraft:shroomlight
fill 418 229 279 418 231 279 minecraft:red_terracotta
fill 418 229 284 418 231 284 minecraft:red_terracotta
fill 377 230 275 377 230 277 minecraft:red_terracotta
setblock 377 230 278 minecraft:stripped_oak_log
fill 377 230 279 377 230 282 minecraft:red_terracotta
setblock 377 230 283 minecraft:stripped_oak_log
fill 377 230 284 377 233 284 minecraft:red_terracotta
setblock 377 230 288 minecraft:stripped_oak_log
fill 377 230 289 377 233 289 minecraft:red_terracotta
fill 377 230 293 377 231 293 minecraft:stripped_oak_log
fill 377 230 294 377 231 294 minecraft:red_terracotta
setblock 377 230 298 minecraft:stripped_oak_log
fill 377 230 299 377 233 299 minecraft:red_terracotta
setblock 377 230 303 minecraft:stripped_oak_log
fill 377 230 304 377 233 304 minecraft:red_terracotta
fill 377 230 314 377 233 314 minecraft:red_terracotta
setblock 378 230 277 minecraft:stripped_oak_log
fill 378 230 278 378 231 279 minecraft:red_terracotta
setblock 378 230 281 minecraft:red_terracotta
setblock 378 230 282 minecraft:stripped_oak_log
fill 378 230 283 378 231 283 minecraft:red_terracotta
fill 378 230 296 378 231 296 minecraft:stripped_oak_log
setblock 378 230 298 minecraft:red_terracotta
setblock 378 230 302 minecraft:stripped_oak_log
fill 378 230 316 378 230 317 minecraft:red_terracotta
setblock 379 230 276 minecraft:stripped_oak_log
fill 379 230 277 379 231 278 minecraft:red_terracotta
setblock 379 230 280 minecraft:red_terracotta
fill 379 230 281 380 230 281 minecraft:stripped_oak_log
fill 379 230 282 379 231 282 minecraft:red_terracotta
fill 379 230 284 379 231 284 minecraft:stripped_oak_log
setblock 379 230 316 minecraft:stripped_oak_log
fill 379 230 317 379 231 317 minecraft:red_terracotta
fill 380 230 276 380 231 277 minecraft:red_terracotta
setblock 380 230 279 minecraft:red_terracotta
fill 380 230 280 381 231 280 minecraft:stripped_oak_log
fill 380 230 283 380 231 283 minecraft:stripped_oak_log
fill 380 230 316 383 230 316 minecraft:red_terracotta
fill 381 230 276 381 231 276 minecraft:red_terracotta
setblock 381 230 278 minecraft:red_terracotta
fill 381 230 279 382 231 279 minecraft:stripped_oak_log
fill 381 230 282 381 231 282 minecraft:stripped_oak_log
fill 381 230 284 381 231 284 minecraft:stripped_oak_log
setblock 382 230 277 minecraft:red_terracotta
setblock 382 230 278 minecraft:stripped_oak_log
fill 382 230 281 382 231 281 minecraft:stripped_oak_log
fill 382 230 283 382 231 283 minecraft:stripped_oak_log
setblock 383 230 276 minecraft:red_terracotta
setblock 383 230 277 minecraft:stripped_oak_log
setblock 383 230 278 minecraft:red_terracotta
fill 383 230 280 383 231 280 minecraft:stripped_oak_log
fill 383 230 282 383 231 282 minecraft:stripped_oak_log
fill 383 230 284 383 231 284 minecraft:stripped_oak_log
setblock 384 230 276 minecraft:stripped_oak_log
fill 384 230 277 384 231 277 minecraft:red_terracotta
fill 384 230 278 384 231 279 minecraft:stripped_oak_log
fill 384 230 281 384 231 281 minecraft:stripped_oak_log
fill 384 230 283 384 231 283 minecraft:stripped_oak_log
setblock 384 230 316 minecraft:stripped_oak_log
fill 385 230 276 385 231 276 minecraft:red_terracotta
fill 385 230 278 385 231 278 minecraft:stripped_oak_log
fill 385 230 280 385 231 280 minecraft:stripped_oak_log
fill 385 230 282 385 231 282 minecraft:stripped_oak_log
fill 385 230 284 385 231 284 minecraft:stripped_oak_log
fill 385 230 316 387 230 316 minecraft:red_terracotta
setblock 386 230 277 minecraft:red_terracotta
fill 386 230 279 386 231 279 minecraft:stripped_oak_log
fill 386 230 281 386 231 281 minecraft:stripped_oak_log
fill 386 230 283 386 231 283 minecraft:stripped_oak_log
fill 387 230 276 387 231 276 minecraft:red_terracotta
fill 387 230 277 387 231 278 minecraft:stripped_oak_log
fill 387 230 280 387 231 280 minecraft:stripped_oak_log
fill 387 230 282 387 231 282 minecraft:stripped_oak_log
fill 387 230 284 387 231 284 minecraft:stripped_oak_log
fill 388 230 277 388 231 277 minecraft:stripped_oak_log
fill 388 230 279 388 231 279 minecraft:stripped_oak_log
fill 388 230 281 388 231 281 minecraft:stripped_oak_log
fill 388 230 283 388 231 283 minecraft:stripped_oak_log
fill 389 230 276 389 231 276 minecraft:stripped_oak_log
fill 389 230 278 389 231 278 minecraft:stripped_oak_log
fill 389 230 280 389 231 280 minecraft:stripped_oak_log
fill 389 230 282 389 231 282 minecraft:stripped_oak_log
fill 389 230 284 389 231 284 minecraft:stripped_oak_log
setblock 390 230 276 minecraft:red_terracotta
fill 390 230 277 390 231 277 minecraft:stripped_oak_log
fill 390 230 279 390 231 279 minecraft:stripped_oak_log
fill 390 230 281 390 231 281 minecraft:stripped_oak_log
fill 390 230 283 390 231 283 minecraft:stripped_oak_log
fill 391 230 316 393 230 316 minecraft:red_terracotta
setblock 394 230 276 minecraft:stripped_oak_log
setblock 394 230 316 minecraft:stripped_oak_log
fill 395 230 276 395 233 276 minecraft:red_terracotta
fill 395 230 316 398 230 316 minecraft:red_terracotta
fill 396 230 315 399 230 315 minecraft:red_terracotta
setblock 398 230 277 minecraft:stripped_oak_log
setblock 399 230 276 minecraft:stripped_oak_log
fill 399 230 277 400 230 277 minecraft:red_terracotta
setblock 399 230 316 minecraft:stripped_oak_log
fill 400 230 276 401 231 276 minecraft:red_terracotta
fill 400 230 279 400 231 279 minecraft:stripped_oak_log
fill 400 230 281 400 231 281 minecraft:stripped_oak_log
fill 400 230 316 400 232 316 minecraft:red_terracotta
fill 401 230 277 401 231 278 minecraft:stripped_oak_log
fill 401 230 280 401 231 280 minecraft:stripped_oak_log
fill 401 230 282 401 231 282 minecraft:stripped_oak_log
fill 402 230 277 402 231 277 minecraft:stripped_oak_log
fill 402 230 279 402 231 279 minecraft:stripped_oak_log
fill 402 230 281 402 231 281 minecraft:stripped_oak_log
setblock 403 230 276 minecraft:red_terracotta
fill 403 230 278 403 231 278 minecraft:stripped_oak_log
fill 403 230 280 403 231 280 minecraft:stripped_oak_log
fill 403 230 282 403 231 282 minecraft:stripped_oak_log
fill 404 230 276 404 231 277 minecraft:stripped_oak_log
fill 404 230 279 404 231 279 minecraft:stripped_oak_log
fill 404 230 281 404 231 281 minecraft:stripped_oak_log
fill 405 230 276 405 231 276 minecraft:stripped_oak_log
fill 405 230 278 405 231 278 minecraft:stripped_oak_log
fill 405 230 280 405 231 280 minecraft:stripped_oak_log
fill 405 230 282 405 231 282 minecraft:stripped_oak_log
fill 406 230 277 406 231 277 minecraft:stripped_oak_log
fill 406 230 279 406 231 279 minecraft:stripped_oak_log
fill 406 230 281 406 231 281 minecraft:stripped_oak_log
fill 407 230 276 407 231 276 minecraft:stripped_oak_log
fill 407 230 278 407 231 278 minecraft:stripped_oak_log
fill 407 230 280 407 231 280 minecraft:stripped_oak_log
fill 407 230 282 407 231 282 minecraft:stripped_oak_log
fill 408 230 277 408 231 277 minecraft:stripped_oak_log
fill 408 230 279 408 231 279 minecraft:stripped_oak_log
fill 408 230 281 408 231 281 minecraft:stripped_oak_log
fill 409 230 276 409 231 276 minecraft:stripped_oak_log
fill 409 230 278 409 231 278 minecraft:stripped_oak_log
fill 409 230 280 409 231 280 minecraft:stripped_oak_log
fill 409 230 282 409 231 282 minecraft:stripped_oak_log
fill 410 230 277 410 231 277 minecraft:stripped_oak_log
fill 410 230 279 410 231 279 minecraft:stripped_oak_log
fill 410 230 281 410 231 281 minecraft:stripped_oak_log
fill 411 230 276 411 231 276 minecraft:stripped_oak_log
fill 411 230 278 411 231 278 minecraft:stripped_oak_log
fill 411 230 280 411 231 280 minecraft:stripped_oak_log
fill 411 230 282 411 231 282 minecraft:stripped_oak_log
fill 412 230 277 412 231 277 minecraft:stripped_oak_log
fill 412 230 279 412 231 279 minecraft:stripped_oak_log
fill 412 230 281 412 231 281 minecraft:stripped_oak_log
fill 413 230 302 413 231 302 minecraft:stripped_oak_log
fill 413 230 304 413 231 304 minecraft:stripped_oak_log
fill 413 230 306 413 231 306 minecraft:stripped_oak_log
fill 413 230 308 413 231 308 minecraft:stripped_oak_log
fill 413 230 310 413 231 310 minecraft:stripped_oak_log
fill 413 230 312 413 231 312 minecraft:stripped_oak_log
fill 413 230 314 413 231 314 minecraft:stripped_oak_log
setblock 414 230 276 minecraft:stripped_oak_log
fill 414 230 303 414 231 303 minecraft:stripped_oak_log
fill 414 230 305 414 231 305 minecraft:stripped_oak_log
fill 414 230 307 414 231 307 minecraft:stripped_oak_log
fill 414 230 309 414 231 309 minecraft:stripped_oak_log
fill 414 230 311 414 231 311 minecraft:stripped_oak_log
fill 414 230 313 414 231 313 minecraft:stripped_oak_log
fill 415 230 276 415 233 276 minecraft:red_terracotta
fill 415 230 302 415 231 302 minecraft:stripped_oak_log
fill 415 230 304 415 231 304 minecraft:stripped_oak_log
fill 415 230 306 415 231 306 minecraft:stripped_oak_log
fill 415 230 308 415 231 308 minecraft:stripped_oak_log
fill 415 230 310 415 231 310 minecraft:stripped_oak_log
fill 415 230 312 415 231 312 minecraft:stripped_oak_log
fill 415 230 314 415 231 314 minecraft:stripped_oak_log
setblock 416 230 278 minecraft:red_terracotta
setblock 416 230 279 minecraft:stripped_oak_log
fill 416 230 280 416 233 280 minecraft:red_terracotta
setblock 416 230 283 minecraft:red_terracotta
setblock 416 230 284 minecraft:stripped_oak_log
fill 416 230 285 416 232 286 minecraft:red_terracotta
setblock 416 230 294 minecraft:stripped_oak_log
fill 416 230 295 416 233 295 minecraft:red_terracotta
setblock 416 230 299 minecraft:stripped_oak_log
fill 416 230 300 416 233 300 minecraft:red_terracotta
setblock 416 230 303 minecraft:red_terracotta
fill 416 230 305 416 231 305 minecraft:stripped_oak_log
fill 416 230 307 416 231 307 minecraft:stripped_oak_log
fill 416 230 309 416 231 309 minecraft:stripped_oak_log
fill 416 230 311 416 231 311 minecraft:stripped_oak_log
fill 416 230 313 416 231 313 minecraft:stripped_oak_log
setblock 417 230 278 minecraft:stripped_oak_log
fill 417 230 279 417 233 279 minecraft:red_terracotta
setblock 417 230 283 minecraft:stripped_oak_log
fill 417 230 284 417 233 284 minecraft:red_terracotta
setblock 417 230 288 minecraft:stripped_oak_log
fill 417 230 289 417 233 289 minecraft:red_terracotta
setblock 417 230 293 minecraft:stripped_oak_log
fill 417 230 294 417 233 294 minecraft:red_terracotta
setblock 417 230 298 minecraft:stripped_oak_log
fill 417 230 299 417 233 299 minecraft:red_terracotta
setblock 417 230 302 minecraft:red_terracotta
setblock 417 230 303 minecraft:stripped_oak_log
fill 417 230 304 417 231 304 minecraft:red_terracotta
fill 417 230 306 417 231 306 minecraft:red_terracotta
fill 417 230 308 417 231 308 minecraft:stripped_oak_log
fill 417 230 310 417 231 310 minecraft:stripped_oak_log
fill 417 230 312 417 231 312 minecraft:stripped_oak_log
fill 417 230 314 417 231 314 minecraft:stripped_oak_log
fill 418 230 316 418 231 316 minecraft:red_terracotta
fill 377 231 275 377 231 276 minecraft:red_terracotta
setblock 377 231 277 minecraft:stripped_oak_log
fill 377 231 278 377 231 281 minecraft:red_terracotta
setblock 377 231 282 minecraft:stripped_oak_log
fill 377 231 283 377 234 283 minecraft:red_terracotta
setblock 377 231 287 minecraft:stripped_oak_log
fill 377 231 288 377 234 288 minecraft:red_terracotta
fill 377 231 291 377 231 292 minecraft:stripped_oak_log
setblock 377 231 297 minecraft:stripped_oak_log
fill 377 231 298 377 234 298 minecraft:red_terracotta
setblock 377 231 302 minecraft:stripped_oak_log
fill 377 231 303 378 233 303 minecraft:red_terracotta
setblock 377 231 306 minecraft:red_terracotta
setblock 377 231 307 minecraft:stripped_oak_log
setblock 378 231 276 minecraft:stripped_oak_log
setblock 378 231 277 minecraft:red_terracotta
setblock 378 231 281 minecraft:stripped_oak_log
fill 378 231 282 378 234 282 minecraft:red_terracotta
setblock 378 231 286 minecraft:stripped_oak_log
setblock 378 231 301 minecraft:stripped_oak_log
fill 378 231 302 378 234 302 minecraft:red_terracotta
setblock 378 231 316 minecraft:stripped_oak_log
setblock 378 231 317 minecraft:red_terracotta
setblock 379 231 276 minecraft:red_terracotta
setblock 379 231 280 minecraft:stripped_oak_log
fill 379 231 281 379 234 281 minecraft:red_terracotta
setblock 379 231 286 minecraft:light[level=15]
setblock 379 231 302 minecraft:light[level=15]
setblock 379 231 310 minecraft:light[level=15]
fill 379 231 316 382 231 316 minecraft:red_terracotta
setblock 380 231 279 minecraft:stripped_oak_log
setblock 380 231 281 minecraft:stripped_oak_log
setblock 381 231 278 minecraft:stripped_oak_log
setblock 382 231 277 minecraft:stripped_oak_log
fill 382 231 278 382 232 278 minecraft:red_terracotta
setblock 383 231 276 minecraft:stripped_oak_log
fill 383 231 277 383 233 277 minecraft:red_terracotta
setblock 383 231 278 minecraft:stripped_oak_log
setblock 383 231 316 minecraft:stripped_oak_log
fill 384 231 276 384 234 276 minecraft:red_terracotta
fill 384 231 316 385 231 316 minecraft:red_terracotta
setblock 386 231 277 minecraft:stripped_oak_log
setblock 387 231 286 minecraft:light[level=15]
setblock 387 231 294 minecraft:light[level=15]
setblock 387 231 302 minecraft:light[level=15]
setblock 387 231 310 minecraft:light[level=15]
fill 388 231 276 388 242 276 minecraft:stripped_oak_log
fill 390 231 276 390 236 276 minecraft:stripped_oak_log
setblock 392 231 316 minecraft:red_terracotta
setblock 393 231 276 minecraft:stripped_oak_log
setblock 393 231 316 minecraft:stripped_oak_log
fill 394 231 276 394 234 276 minecraft:red_terracotta
fill 394 231 316 397 231 316 minecraft:red_terracotta
setblock 395 231 278 minecraft:light[level=15]
setblock 395 231 286 minecraft:light[level=15]
setblock 395 231 294 minecraft:light[level=15]
setblock 395 231 302 minecraft:light[level=15]
setblock 395 231 310 minecraft:light[level=15]
setblock 397 231 277 minecraft:stripped_oak_log
setblock 398 231 276 minecraft:stripped_oak_log
setblock 398 231 277 minecraft:red_terracotta
setblock 398 231 316 minecraft:stripped_oak_log
fill 399 231 276 399 234 276 minecraft:red_terracotta
fill 399 231 316 399 234 316 minecraft:red_terracotta
setblock 400 231 277 minecraft:stripped_oak_log
setblock 403 231 276 minecraft:stripped_oak_log
setblock 403 231 286 minecraft:light[level=15]
setblock 403 231 294 minecraft:light[level=15]
setblock 403 231 302 minecraft:light[level=15]
setblock 403 231 310 minecraft:light[level=15]
setblock 411 231 286 minecraft:light[level=15]
setblock 411 231 294 minecraft:light[level=15]
setblock 411 231 302 minecraft:light[level=15]
setblock 411 231 310 minecraft:light[level=15]
setblock 413 231 276 minecraft:stripped_oak_log
fill 414 231 276 414 234 276 minecraft:red_terracotta
fill 415 231 280 415 232 282 minecraft:red_terracotta
setblock 416 231 278 minecraft:stripped_oak_log
fill 416 231 279 416 234 279 minecraft:red_terracotta
setblock 416 231 283 minecraft:stripped_oak_log
fill 416 231 284 416 234 284 minecraft:red_terracotta
setblock 416 231 287 minecraft:red_terracotta
setblock 416 231 288 minecraft:stripped_oak_log
setblock 416 231 294 minecraft:red_terracotta
setblock 416 231 298 minecraft:stripped_oak_log
fill 416 231 299 416 234 299 minecraft:red_terracotta
setblock 416 231 303 minecraft:stripped_oak_log
setblock 417 231 277 minecraft:stripped_oak_log
fill 417 231 278 417 234 278 minecraft:red_terracotta
setblock 417 231 282 minecraft:stripped_oak_log
fill 417 231 283 417 234 283 minecraft:red_terracotta
setblock 417 231 287 minecraft:stripped_oak_log
fill 417 231 288 417 234 288 minecraft:red_terracotta
setblock 417 231 292 minecraft:stripped_oak_log
fill 417 231 293 417 234 293 minecraft:red_terracotta
setblock 417 231 297 minecraft:stripped_oak_log
fill 417 231 298 417 234 298 minecraft:red_terracotta
setblock 417 231 302 minecraft:stripped_oak_log
fill 417 231 303 417 234 303 minecraft:red_terracotta
fill 376 232 275 376 235 317 minecraft:yellow_terracotta
fill 377 232 275 418 235 275 minecraft:yellow_terracotta
setblock 377 232 276 minecraft:stripped_oak_log
fill 377 232 277 377 232 280 minecraft:red_terracotta
setblock 377 232 281 minecraft:stripped_oak_log
fill 377 232 282 377 235 282 minecraft:red_terracotta
setblock 377 232 286 minecraft:stripped_oak_log
fill 377 232 287 378 234 287 minecraft:red_terracotta
setblock 377 232 296 minecraft:stripped_oak_log
fill 377 232 297 377 235 297 minecraft:red_terracotta
setblock 377 232 301 minecraft:stripped_oak_log
fill 377 232 302 377 235 302 minecraft:red_terracotta
setblock 377 232 306 minecraft:stripped_oak_log
fill 377 232 307 377 234 308 minecraft:red_terracotta
setblock 377 232 315 minecraft:red_terracotta
setblock 377 232 316 minecraft:stripped_oak_log
fill 377 232 317 418 235 317 minecraft:yellow_terracotta
fill 378 232 276 378 235 276 minecraft:red_terracotta
setblock 378 232 277 minecraft:shroomlight
fill 378 232 278 378 233 278 minecraft:red_terracotta
setblock 378 232 279 minecraft:shroomlight
setblock 378 232 280 minecraft:stripped_oak_log
setblock 378 232 281 minecraft:shroomlight
setblock 378 232 283 minecraft:shroomlight
setblock 378 232 285 minecraft:stripped_oak_log
fill 378 232 286 378 235 286 minecraft:red_terracotta
setblock 378 232 300 minecraft:stripped_oak_log
fill 378 232 301 378 235 301 minecraft:red_terracotta
setblock 378 232 304 minecraft:red_terracotta
fill 378 232 316 381 232 316 minecraft:red_terracotta
setblock 379 232 276 minecraft:shroomlight
fill 379 232 277 379 233 277 minecraft:red_terracotta
setblock 379 232 278 minecraft:shroomlight
setblock 379 232 279 minecraft:stripped_oak_log
setblock 379 232 280 minecraft:shroomlight
setblock 379 232 282 minecraft:shroomlight
setblock 379 232 284 minecraft:shroomlight
fill 380 232 276 380 233 276 minecraft:red_terracotta
setblock 380 232 277 minecraft:shroomlight
setblock 380 232 278 minecraft:stripped_oak_log
setblock 380 232 279 minecraft:shroomlight
fill 380 232 280 380 242 280 minecraft:stripped_oak_log
setblock 380 232 281 minecraft:shroomlight
setblock 380 232 283 minecraft:shroomlight
setblock 381 232 276 minecraft:shroomlight
setblock 381 232 277 minecraft:stripped_oak_log
setblock 381 232 278 minecraft:shroomlight
fill 381 232 279 381 242 279 minecraft:stripped_oak_log
setblock 381 232 280 minecraft:shroomlight
setblock 381 232 282 minecraft:shroomlight
setblock 381 232 284 minecraft:shroomlight
setblock 382 232 276 minecraft:stripped_oak_log
setblock 382 232 277 minecraft:shroomlight
setblock 382 232 279 minecraft:shroomlight
setblock 382 232 281 minecraft:shroomlight
setblock 382 232 283 minecraft:shroomlight
setblock 382 232 316 minecraft:stripped_oak_log
setblock 383 232 276 minecraft:shroomlight
setblock 383 232 278 minecraft:shroomlight
setblock 383 232 280 minecraft:shroomlight
setblock 383 232 282 minecraft:shroomlight
setblock 383 232 284 minecraft:shroomlight
fill 383 232 316 384 232 316 minecraft:red_terracotta
setblock 384 232 277 minecraft:shroomlight
fill 384 232 278 384 242 278 minecraft:stripped_oak_log
setblock 384 232 279 minecraft:shroomlight
setblock 384 232 281 minecraft:shroomlight
setblock 384 232 283 minecraft:shroomlight
setblock 385 232 276 minecraft:shroomlight
fill 385 232 277 385 242 277 minecraft:stripped_oak_log
setblock 385 232 278 minecraft:shroomlight
setblock 385 232 280 minecraft:shroomlight
setblock 385 232 282 minecraft:shroomlight
setblock 385 232 284 minecraft:shroomlight
setblock 386 232 277 minecraft:shroomlight
setblock 386 232 279 minecraft:shroomlight
setblock 386 232 281 minecraft:shroomlight
setblock 386 232 283 minecraft:shroomlight
schedule function dropper:buildpart/68_8 1t
