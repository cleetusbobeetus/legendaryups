fill 446 258 296 464 258 296 minecraft:gray_concrete
setblock 446 258 316 minecraft:gray_concrete
setblock 450 258 276 minecraft:gray_concrete
setblock 456 258 316 minecraft:gray_concrete
setblock 460 258 276 minecraft:gray_concrete
setblock 464 258 282 minecraft:gray_concrete
setblock 464 258 292 minecraft:gray_concrete
setblock 464 258 302 minecraft:gray_concrete
setblock 464 258 312 minecraft:gray_concrete
fill 424 259 290 434 259 290 minecraft:gray_concrete
fill 424 259 296 428 259 296 minecraft:gray_concrete
fill 424 259 308 432 259 308 minecraft:gray_concrete
fill 424 259 314 431 259 314 minecraft:gray_concrete
setblock 426 259 285 minecraft:light[level=12]
setblock 426 259 292 minecraft:light[level=12]
setblock 426 259 299 minecraft:light[level=12]
setblock 426 259 306 minecraft:light[level=12]
setblock 426 259 313 minecraft:light[level=12]
fill 428 259 278 463 259 278 minecraft:gray_concrete
fill 428 259 302 463 259 302 minecraft:gray_concrete
fill 431 259 277 437 260 277 minecraft:iron_block
fill 432 259 314 432 260 315 minecraft:iron_block
setblock 433 259 285 minecraft:light[level=12]
setblock 433 259 292 minecraft:light[level=12]
setblock 433 259 299 minecraft:light[level=12]
setblock 433 259 306 minecraft:light[level=12]
setblock 433 259 313 minecraft:light[level=12]
fill 433 259 314 443 259 314 minecraft:gray_concrete
setblock 440 259 285 minecraft:light[level=12]
setblock 440 259 292 minecraft:light[level=12]
setblock 440 259 299 minecraft:light[level=12]
setblock 440 259 306 minecraft:light[level=12]
setblock 440 259 313 minecraft:light[level=12]
fill 444 259 305 444 259 316 minecraft:iron_block
setblock 447 259 285 minecraft:light[level=12]
setblock 447 259 292 minecraft:light[level=12]
setblock 447 259 299 minecraft:light[level=12]
setblock 447 259 306 minecraft:light[level=12]
setblock 447 259 313 minecraft:light[level=12]
setblock 454 259 285 minecraft:light[level=12]
setblock 454 259 292 minecraft:light[level=12]
setblock 454 259 299 minecraft:light[level=12]
setblock 454 259 306 minecraft:light[level=12]
setblock 454 259 313 minecraft:light[level=12]
setblock 461 259 285 minecraft:light[level=12]
setblock 461 259 292 minecraft:light[level=12]
setblock 461 259 299 minecraft:light[level=12]
setblock 461 259 306 minecraft:light[level=12]
setblock 461 259 313 minecraft:light[level=12]
fill 426 260 276 426 260 305 minecraft:iron_block
fill 432 260 276 432 261 276 minecraft:iron_block
fill 432 260 278 432 260 313 minecraft:iron_block
fill 438 260 276 438 260 279 minecraft:iron_block
fill 444 260 276 444 260 294 minecraft:iron_block
fill 444 260 301 444 260 310 minecraft:iron_block
fill 450 260 276 450 261 278 minecraft:iron_block
fill 455 260 277 455 263 277 minecraft:purple_wool
fill 456 260 276 456 260 316 minecraft:iron_block
fill 459 260 278 463 260 278 minecraft:gray_concrete
fill 459 260 302 463 260 302 minecraft:gray_concrete
fill 462 260 276 462 261 277 minecraft:iron_block
fill 462 260 279 462 261 299 minecraft:iron_block
fill 424 261 280 424 261 283 minecraft:gray_concrete
fill 424 261 290 424 261 293 minecraft:gray_concrete
fill 424 261 300 424 261 303 minecraft:gray_concrete
fill 424 261 310 424 261 313 minecraft:gray_concrete
fill 425 261 276 428 261 276 minecraft:gray_concrete
fill 426 261 277 426 261 315 minecraft:iron_block
fill 428 261 316 431 261 316 minecraft:gray_concrete
fill 432 261 277 432 261 279 minecraft:iron_block
setblock 434 261 278 minecraft:light[level=15]
setblock 434 261 286 minecraft:light[level=15]
setblock 434 261 294 minecraft:light[level=15]
setblock 434 261 302 minecraft:light[level=15]
setblock 434 261 310 minecraft:light[level=15]
fill 435 261 276 438 261 276 minecraft:gray_concrete
fill 438 261 277 438 261 315 minecraft:iron_block
fill 438 261 316 441 261 316 minecraft:gray_concrete
setblock 442 261 278 minecraft:light[level=15]
setblock 442 261 286 minecraft:light[level=15]
setblock 442 261 294 minecraft:light[level=15]
setblock 442 261 302 minecraft:light[level=15]
setblock 442 261 310 minecraft:light[level=15]
fill 444 261 276 444 261 278 minecraft:iron_block
fill 445 261 276 448 261 276 minecraft:gray_concrete
fill 448 261 316 451 261 316 minecraft:gray_concrete
fill 450 261 279 450 261 313 minecraft:iron_block
fill 455 261 276 458 261 276 minecraft:gray_concrete
fill 456 261 277 456 261 281 minecraft:iron_block
setblock 458 261 278 minecraft:light[level=15]
setblock 458 261 286 minecraft:light[level=15]
setblock 458 261 294 minecraft:light[level=15]
setblock 458 261 302 minecraft:light[level=15]
setblock 458 261 310 minecraft:light[level=15]
fill 458 261 316 461 261 316 minecraft:gray_concrete
setblock 462 261 278 minecraft:iron_block
fill 462 261 300 462 261 315 minecraft:iron_block
fill 464 261 277 464 261 280 minecraft:gray_concrete
fill 464 261 287 464 261 290 minecraft:gray_concrete
fill 464 261 297 464 261 300 minecraft:gray_concrete
fill 464 261 307 464 261 310 minecraft:gray_concrete
fill 425 262 311 425 262 312 minecraft:black_concrete
fill 426 262 309 426 262 310 minecraft:black_concrete
fill 426 262 311 426 264 312 minecraft:gray_concrete
fill 426 262 313 429 262 313 minecraft:black_concrete
fill 427 262 309 428 262 309 minecraft:black_concrete
setblock 429 262 310 minecraft:black_concrete
setblock 429 262 312 minecraft:black_concrete
setblock 430 262 311 minecraft:black_concrete
fill 438 262 312 438 262 315 minecraft:iron_block
fill 450 262 307 450 262 315 minecraft:iron_block
fill 456 262 277 456 263 277 minecraft:purple_wool
fill 426 263 310 426 264 310 minecraft:magenta_concrete
fill 426 263 313 428 264 313 minecraft:magenta_concrete
fill 427 263 309 428 264 309 minecraft:magenta_concrete
fill 429 263 310 429 264 310 minecraft:magenta_concrete
fill 429 263 312 429 264 312 minecraft:magenta_concrete
setblock 424 264 278 minecraft:gray_concrete
setblock 424 264 288 minecraft:gray_concrete
setblock 424 264 298 minecraft:gray_concrete
setblock 424 264 308 minecraft:gray_concrete
setblock 426 264 316 minecraft:gray_concrete
setblock 430 264 276 minecraft:gray_concrete
setblock 436 264 316 minecraft:gray_concrete
setblock 440 264 276 minecraft:gray_concrete
setblock 446 264 316 minecraft:gray_concrete
setblock 450 264 276 minecraft:gray_concrete
fill 451 264 277 457 264 277 minecraft:iron_block
setblock 456 264 316 minecraft:gray_concrete
setblock 460 264 276 minecraft:gray_concrete
setblock 464 264 282 minecraft:gray_concrete
setblock 464 264 292 minecraft:gray_concrete
setblock 464 264 302 minecraft:gray_concrete
setblock 464 264 312 minecraft:gray_concrete
setblock 426 265 278 minecraft:light[level=12]
setblock 426 265 285 minecraft:light[level=12]
setblock 426 265 292 minecraft:light[level=12]
setblock 426 265 299 minecraft:light[level=12]
setblock 426 265 306 minecraft:light[level=12]
setblock 426 265 313 minecraft:light[level=12]
setblock 433 265 278 minecraft:light[level=12]
setblock 433 265 285 minecraft:light[level=12]
setblock 433 265 292 minecraft:light[level=12]
setblock 433 265 299 minecraft:light[level=12]
setblock 433 265 306 minecraft:light[level=12]
setblock 433 265 313 minecraft:light[level=12]
setblock 440 265 278 minecraft:light[level=12]
setblock 440 265 285 minecraft:light[level=12]
setblock 440 265 292 minecraft:light[level=12]
setblock 440 265 299 minecraft:light[level=12]
setblock 440 265 306 minecraft:light[level=12]
setblock 440 265 313 minecraft:light[level=12]
setblock 447 265 278 minecraft:light[level=12]
setblock 447 265 285 minecraft:light[level=12]
setblock 447 265 292 minecraft:light[level=12]
setblock 447 265 299 minecraft:light[level=12]
setblock 447 265 306 minecraft:light[level=12]
setblock 447 265 313 minecraft:light[level=12]
setblock 454 265 278 minecraft:light[level=12]
setblock 454 265 285 minecraft:light[level=12]
setblock 454 265 292 minecraft:light[level=12]
setblock 454 265 299 minecraft:light[level=12]
setblock 454 265 306 minecraft:light[level=12]
setblock 454 265 313 minecraft:light[level=12]
setblock 461 265 278 minecraft:light[level=12]
setblock 461 265 285 minecraft:light[level=12]
setblock 461 265 292 minecraft:light[level=12]
setblock 461 265 299 minecraft:light[level=12]
setblock 461 265 306 minecraft:light[level=12]
setblock 461 265 313 minecraft:light[level=12]
fill 440 266 295 440 278 295 minecraft:light_gray_concrete
setblock 440 266 296 minecraft:white_concrete
fill 440 266 297 440 278 297 minecraft:light_gray_concrete
setblock 440 266 298 minecraft:white_concrete
fill 440 266 299 440 278 299 minecraft:light_gray_concrete
fill 441 266 294 441 282 294 minecraft:light_gray_concrete
setblock 441 266 295 minecraft:white_concrete
fill 441 266 296 441 268 296 minecraft:light_gray_concrete
setblock 441 266 297 minecraft:white_concrete
fill 441 266 298 441 268 298 minecraft:light_gray_concrete
setblock 441 266 299 minecraft:sea_lantern
fill 441 266 300 441 268 300 minecraft:light_gray_concrete
setblock 442 266 294 minecraft:white_concrete
fill 442 266 295 442 278 295 minecraft:light_gray_concrete
setblock 442 266 296 minecraft:sea_lantern
fill 442 266 299 442 268 299 minecraft:light_gray_concrete
setblock 442 266 300 minecraft:white_concrete
setblock 443 266 293 minecraft:sea_lantern
fill 443 266 294 443 278 294 minecraft:light_gray_concrete
setblock 443 266 295 minecraft:white_concrete
fill 443 266 296 443 268 296 minecraft:light_gray_concrete
setblock 443 266 299 minecraft:white_concrete
fill 443 266 300 443 268 300 minecraft:light_gray_concrete
setblock 443 266 301 minecraft:white_concrete
fill 444 266 293 444 282 293 minecraft:light_gray_concrete
setblock 444 266 294 minecraft:white_concrete
fill 444 266 295 444 278 295 minecraft:light_gray_concrete
setblock 444 266 296 minecraft:white_concrete
fill 444 266 297 444 268 297 minecraft:light_gray_concrete
setblock 444 266 298 minecraft:white_concrete
fill 444 266 299 444 268 299 minecraft:light_gray_concrete
setblock 444 266 300 minecraft:white_concrete
setblock 444 266 301 minecraft:sea_lantern
fill 445 266 294 445 282 294 minecraft:light_gray_concrete
setblock 445 266 295 minecraft:white_concrete
fill 445 266 296 445 268 296 minecraft:light_gray_concrete
setblock 445 266 297 minecraft:white_concrete
setblock 445 266 298 minecraft:sea_lantern
setblock 445 266 299 minecraft:white_concrete
fill 445 266 300 445 268 300 minecraft:light_gray_concrete
setblock 446 266 294 minecraft:white_concrete
setblock 446 266 295 minecraft:sea_lantern
setblock 446 266 296 minecraft:white_concrete
fill 446 266 297 446 278 297 minecraft:light_gray_concrete
setblock 446 266 298 minecraft:white_concrete
fill 446 266 299 446 278 299 minecraft:light_gray_concrete
setblock 446 266 300 minecraft:white_concrete
setblock 447 266 295 minecraft:white_concrete
fill 447 266 296 447 282 296 minecraft:light_gray_concrete
setblock 447 266 297 minecraft:white_concrete
fill 447 266 298 447 278 298 minecraft:light_gray_concrete
setblock 447 266 299 minecraft:white_concrete
fill 438 267 296 438 281 296 minecraft:light_gray_concrete
setblock 438 267 297 minecraft:white_concrete
fill 438 267 298 438 281 298 minecraft:light_gray_concrete
setblock 439 267 294 minecraft:white_concrete
fill 439 267 295 439 281 295 minecraft:light_gray_concrete
setblock 439 267 296 minecraft:white_concrete
fill 439 267 297 439 278 297 minecraft:light_gray_concrete
setblock 439 267 298 minecraft:white_concrete
fill 439 267 299 439 278 299 minecraft:light_gray_concrete
setblock 439 267 300 minecraft:sea_lantern
setblock 440 267 293 minecraft:white_concrete
fill 440 267 294 440 281 294 minecraft:light_gray_concrete
fill 440 267 296 440 278 296 minecraft:light_gray_concrete
fill 440 267 298 440 268 298 minecraft:light_gray_concrete
fill 440 267 300 440 278 300 minecraft:light_gray_concrete
setblock 440 267 301 minecraft:white_concrete
setblock 441 267 292 minecraft:white_concrete
fill 441 267 293 441 281 293 minecraft:light_gray_concrete
fill 441 267 295 441 278 295 minecraft:light_gray_concrete
fill 441 267 297 441 268 297 minecraft:light_gray_concrete
fill 441 267 299 441 268 299 minecraft:light_gray_concrete
fill 441 267 301 441 278 301 minecraft:light_gray_concrete
setblock 441 267 302 minecraft:white_concrete
fill 442 267 292 442 281 292 minecraft:light_gray_concrete
setblock 442 267 293 minecraft:white_concrete
fill 442 267 294 442 278 294 minecraft:light_gray_concrete
fill 442 267 296 442 268 296 minecraft:light_gray_concrete
fill 442 267 300 442 268 300 minecraft:light_gray_concrete
setblock 442 267 301 minecraft:white_concrete
setblock 442 267 302 minecraft:sea_lantern
setblock 443 267 292 minecraft:white_concrete
fill 443 267 293 443 283 293 minecraft:light_gray_concrete
fill 443 267 295 443 268 295 minecraft:light_gray_concrete
fill 443 267 299 443 268 299 minecraft:light_gray_concrete
fill 443 267 301 445 268 301 minecraft:light_gray_concrete
setblock 443 267 302 minecraft:white_concrete
fill 444 267 292 444 281 292 minecraft:light_gray_concrete
fill 444 267 294 444 278 294 minecraft:light_gray_concrete
fill 444 267 296 444 268 296 minecraft:light_gray_concrete
fill 444 267 298 446 268 298 minecraft:light_gray_concrete
fill 444 267 300 444 268 300 minecraft:light_gray_concrete
fill 444 267 302 444 278 302 minecraft:light_gray_concrete
setblock 445 267 292 minecraft:white_concrete
setblock 445 267 293 minecraft:sea_lantern
fill 445 267 295 447 278 295 minecraft:light_gray_concrete
fill 445 267 297 445 268 297 minecraft:light_gray_concrete
fill 445 267 299 445 268 299 minecraft:light_gray_concrete
setblock 445 267 302 minecraft:white_concrete
fill 446 267 292 446 281 292 minecraft:light_gray_concrete
setblock 446 267 293 minecraft:white_concrete
fill 446 267 294 446 283 294 minecraft:light_gray_concrete
fill 446 267 296 446 278 296 minecraft:light_gray_concrete
fill 446 267 300 446 278 300 minecraft:light_gray_concrete
setblock 446 267 301 minecraft:sea_lantern
fill 446 267 302 446 281 302 minecraft:light_gray_concrete
fill 447 267 293 447 281 293 minecraft:light_gray_concrete
setblock 447 267 294 minecraft:white_concrete
fill 447 267 297 447 278 297 minecraft:light_gray_concrete
fill 447 267 299 447 278 299 minecraft:light_gray_concrete
setblock 447 267 300 minecraft:white_concrete
fill 447 267 301 447 281 301 minecraft:light_gray_concrete
fill 448 267 294 448 281 294 minecraft:light_gray_concrete
setblock 448 267 295 minecraft:sea_lantern
fill 448 267 296 448 281 296 minecraft:light_gray_concrete
setblock 448 267 297 minecraft:white_concrete
fill 448 267 298 448 281 298 minecraft:light_gray_concrete
setblock 448 267 299 minecraft:white_concrete
fill 448 267 300 448 281 300 minecraft:light_gray_concrete
setblock 449 267 296 minecraft:white_concrete
fill 449 267 297 449 281 297 minecraft:light_gray_concrete
setblock 449 267 298 minecraft:white_concrete
setblock 437 268 295 minecraft:white_concrete
fill 437 268 296 437 280 296 minecraft:light_gray_concrete
setblock 437 268 297 minecraft:white_concrete
fill 437 268 298 437 280 298 minecraft:light_gray_concrete
setblock 437 268 299 minecraft:white_concrete
fill 438 268 293 438 280 293 minecraft:light_gray_concrete
setblock 438 268 294 minecraft:white_concrete
fill 438 268 295 438 280 295 minecraft:light_gray_concrete
fill 438 268 297 438 282 297 minecraft:light_gray_concrete
fill 438 268 299 438 280 299 minecraft:light_gray_concrete
setblock 438 268 300 minecraft:white_concrete
fill 438 268 301 438 280 301 minecraft:light_gray_concrete
fill 439 268 292 439 280 292 minecraft:light_gray_concrete
setblock 439 268 293 minecraft:white_concrete
fill 439 268 294 439 282 294 minecraft:light_gray_concrete
fill 439 268 296 439 282 296 minecraft:light_gray_concrete
fill 439 268 298 439 278 298 minecraft:light_gray_concrete
fill 439 268 300 439 282 300 minecraft:light_gray_concrete
setblock 439 268 301 minecraft:white_concrete
fill 439 268 302 439 280 302 minecraft:light_gray_concrete
setblock 440 268 292 minecraft:sea_lantern
fill 440 268 293 440 282 293 minecraft:light_gray_concrete
fill 440 268 301 440 278 301 minecraft:light_gray_concrete
setblock 440 268 302 minecraft:white_concrete
setblock 441 268 291 minecraft:white_concrete
fill 441 268 292 441 282 292 minecraft:light_gray_concrete
fill 441 268 302 443 278 302 minecraft:light_gray_concrete
setblock 441 268 303 minecraft:white_concrete
fill 442 268 291 442 280 291 minecraft:light_gray_concrete
fill 442 268 293 442 281 293 minecraft:light_gray_concrete
fill 442 268 301 442 278 301 minecraft:light_gray_concrete
fill 442 268 303 442 280 303 minecraft:light_gray_concrete
setblock 443 268 291 minecraft:white_concrete
fill 443 268 292 443 282 292 minecraft:light_gray_concrete
setblock 443 268 303 minecraft:white_concrete
setblock 444 268 291 minecraft:sea_lantern
fill 444 268 303 444 280 303 minecraft:light_gray_concrete
setblock 445 268 291 minecraft:white_concrete
fill 445 268 292 445 281 293 minecraft:light_gray_concrete
fill 445 268 302 445 282 302 minecraft:light_gray_concrete
setblock 445 268 303 minecraft:white_concrete
fill 446 268 291 446 280 291 minecraft:light_gray_concrete
fill 446 268 293 446 282 293 minecraft:light_gray_concrete
fill 446 268 301 446 278 301 minecraft:light_gray_concrete
fill 446 268 303 446 280 303 minecraft:light_gray_concrete
fill 447 268 292 447 280 292 minecraft:light_gray_concrete
fill 447 268 294 447 282 294 minecraft:light_gray_concrete
fill 447 268 300 447 281 300 minecraft:light_gray_concrete
fill 447 268 302 447 280 302 minecraft:light_gray_concrete
setblock 448 268 292 minecraft:white_concrete
fill 448 268 293 448 280 293 minecraft:light_gray_concrete
fill 448 268 295 448 282 295 minecraft:light_gray_concrete
fill 448 268 297 448 281 297 minecraft:light_gray_concrete
fill 448 268 299 448 282 299 minecraft:light_gray_concrete
setblock 448 268 301 minecraft:sea_lantern
setblock 448 268 302 minecraft:white_concrete
setblock 449 268 293 minecraft:white_concrete
fill 449 268 294 449 280 294 minecraft:light_gray_concrete
setblock 449 268 295 minecraft:white_concrete
fill 449 268 296 449 282 296 minecraft:light_gray_concrete
fill 449 268 298 449 282 298 minecraft:light_gray_concrete
setblock 449 268 299 minecraft:white_concrete
fill 449 268 300 449 280 300 minecraft:light_gray_concrete
setblock 449 268 301 minecraft:white_concrete
setblock 450 268 295 minecraft:sea_lantern
setblock 450 268 296 minecraft:white_concrete
fill 450 268 297 450 280 297 minecraft:light_gray_concrete
setblock 450 268 298 minecraft:white_concrete
setblock 450 268 299 minecraft:light_gray_concrete
setblock 426 269 278 minecraft:light[level=15]
setblock 426 269 286 minecraft:light[level=15]
setblock 426 269 294 minecraft:light[level=15]
setblock 426 269 302 minecraft:light[level=15]
setblock 426 269 310 minecraft:light[level=15]
setblock 434 269 278 minecraft:light[level=15]
setblock 434 269 286 minecraft:light[level=15]
setblock 434 269 294 minecraft:light[level=15]
setblock 434 269 302 minecraft:light[level=15]
setblock 434 269 310 minecraft:light[level=15]
setblock 436 269 296 minecraft:light_gray_concrete
setblock 436 269 297 minecraft:white_concrete
setblock 436 269 298 minecraft:light_gray_concrete
setblock 437 269 293 minecraft:light_gray_concrete
setblock 437 269 294 minecraft:white_concrete
fill 437 269 295 437 279 295 minecraft:light_gray_concrete
fill 437 269 297 437 281 297 minecraft:light_gray_concrete
fill 437 269 299 437 279 299 minecraft:light_gray_concrete
setblock 437 269 300 minecraft:white_concrete
setblock 437 269 301 minecraft:light_gray_concrete
fill 438 269 292 438 279 292 minecraft:light_gray_concrete
fill 438 269 294 438 281 294 minecraft:light_gray_concrete
fill 438 269 300 438 281 300 minecraft:light_gray_concrete
fill 438 269 302 438 279 302 minecraft:light_gray_concrete
fill 439 269 291 439 279 291 minecraft:light_gray_concrete
fill 439 269 293 439 281 293 minecraft:light_gray_concrete
fill 439 269 301 439 281 301 minecraft:light_gray_concrete
fill 439 269 303 439 279 303 minecraft:light_gray_concrete
setblock 440 269 291 minecraft:white_concrete
fill 440 269 292 440 281 292 minecraft:light_gray_concrete
fill 440 269 302 440 281 302 minecraft:light_gray_concrete
setblock 440 269 303 minecraft:white_concrete
setblock 441 269 290 minecraft:white_concrete
fill 441 269 291 441 281 291 minecraft:light_gray_concrete
fill 441 269 303 441 281 303 minecraft:light_gray_concrete
setblock 441 269 304 minecraft:white_concrete
setblock 442 269 278 minecraft:light[level=15]
setblock 442 269 286 minecraft:light[level=15]
fill 442 269 290 442 279 290 minecraft:light_gray_concrete
fill 442 269 304 442 279 304 minecraft:light_gray_concrete
setblock 442 269 310 minecraft:light[level=15]
setblock 443 269 290 minecraft:white_concrete
fill 443 269 291 445 280 291 minecraft:light_gray_concrete
fill 443 269 303 443 281 303 minecraft:light_gray_concrete
setblock 443 269 304 minecraft:white_concrete
fill 444 269 290 444 279 290 minecraft:light_gray_concrete
fill 444 269 301 445 278 301 minecraft:light_gray_concrete
fill 444 269 304 444 279 304 minecraft:light_gray_concrete
setblock 445 269 290 minecraft:white_concrete
fill 445 269 303 445 281 303 minecraft:light_gray_concrete
setblock 445 269 304 minecraft:white_concrete
setblock 446 269 290 minecraft:light_gray_concrete
setblock 446 269 304 minecraft:light_gray_concrete
fill 447 269 291 447 279 291 minecraft:light_gray_concrete
fill 447 269 303 447 279 303 minecraft:light_gray_concrete
setblock 448 269 291 minecraft:white_concrete
fill 448 269 292 448 281 292 minecraft:light_gray_concrete
fill 448 269 301 448 280 302 minecraft:light_gray_concrete
setblock 448 269 303 minecraft:white_concrete
setblock 449 269 292 minecraft:white_concrete
fill 449 269 293 449 281 293 minecraft:light_gray_concrete
fill 449 269 295 449 281 295 minecraft:light_gray_concrete
fill 449 269 299 449 280 299 minecraft:light_gray_concrete
fill 449 269 301 449 281 301 minecraft:light_gray_concrete
setblock 449 269 302 minecraft:white_concrete
setblock 450 269 278 minecraft:light[level=15]
setblock 450 269 286 minecraft:light[level=15]
setblock 450 269 293 minecraft:white_concrete
fill 450 269 294 450 279 294 minecraft:light_gray_concrete
setblock 450 269 295 minecraft:white_concrete
fill 450 269 296 450 280 296 minecraft:light_gray_concrete
fill 450 269 298 450 281 298 minecraft:light_gray_concrete
setblock 450 269 299 minecraft:white_concrete
fill 450 269 300 450 279 300 minecraft:light_gray_concrete
setblock 450 269 301 minecraft:sea_lantern
setblock 450 269 302 minecraft:light[level=15]
setblock 450 269 310 minecraft:light[level=15]
setblock 451 269 296 minecraft:white_concrete
setblock 451 269 297 minecraft:light_gray_concrete
setblock 451 269 298 minecraft:sea_lantern
setblock 458 269 278 minecraft:light[level=15]
setblock 458 269 286 minecraft:light[level=15]
setblock 458 269 294 minecraft:light[level=15]
setblock 458 269 302 minecraft:light[level=15]
setblock 458 269 310 minecraft:light[level=15]
setblock 436 270 294 minecraft:sea_lantern
fill 436 270 295 436 278 295 minecraft:light_gray_concrete
setblock 436 270 296 minecraft:white_concrete
fill 436 270 297 436 278 297 minecraft:light_gray_concrete
setblock 436 270 298 minecraft:white_concrete
fill 436 270 299 436 278 299 minecraft:light_gray_concrete
setblock 436 270 300 minecraft:white_concrete
setblock 437 270 292 minecraft:light_gray_concrete
setblock 437 270 293 minecraft:white_concrete
fill 437 270 294 437 280 294 minecraft:light_gray_concrete
fill 437 270 300 437 280 300 minecraft:light_gray_concrete
setblock 437 270 301 minecraft:white_concrete
setblock 437 270 302 minecraft:sea_lantern
setblock 438 270 291 minecraft:light_gray_concrete
setblock 438 270 303 minecraft:light_gray_concrete
setblock 439 270 290 minecraft:light_gray_concrete
setblock 439 270 304 minecraft:light_gray_concrete
setblock 440 270 290 minecraft:white_concrete
fill 440 270 291 440 280 291 minecraft:light_gray_concrete
fill 440 270 303 440 280 303 minecraft:light_gray_concrete
setblock 440 270 304 minecraft:sea_lantern
setblock 441 270 290 minecraft:sea_lantern
fill 441 270 304 441 278 304 minecraft:light_gray_concrete
setblock 442 270 289 minecraft:light_gray_concrete
setblock 442 270 305 minecraft:light_gray_concrete
setblock 443 270 289 minecraft:white_concrete
fill 443 270 290 443 280 290 minecraft:light_gray_concrete
fill 443 270 304 443 280 304 minecraft:light_gray_concrete
setblock 443 270 305 minecraft:white_concrete
setblock 444 270 289 minecraft:light_gray_concrete
setblock 444 270 305 minecraft:light_gray_concrete
setblock 445 270 289 minecraft:sea_lantern
fill 445 270 290 445 280 290 minecraft:light_gray_concrete
fill 445 270 304 445 280 304 minecraft:light_gray_concrete
setblock 445 270 305 minecraft:white_concrete
setblock 446 270 290 minecraft:white_concrete
setblock 446 270 304 minecraft:white_concrete
fill 447 270 290 447 278 290 minecraft:light_gray_concrete
fill 447 270 304 447 278 304 minecraft:light_gray_concrete
setblock 448 270 290 minecraft:white_concrete
fill 448 270 291 448 280 291 minecraft:light_gray_concrete
fill 448 270 303 448 280 303 minecraft:light_gray_concrete
setblock 448 270 304 minecraft:white_concrete
setblock 449 270 291 minecraft:white_concrete
fill 449 270 292 449 280 292 minecraft:light_gray_concrete
fill 449 270 302 449 280 302 minecraft:light_gray_concrete
setblock 449 270 303 minecraft:white_concrete
setblock 450 270 292 minecraft:white_concrete
fill 450 270 293 450 278 293 minecraft:light_gray_concrete
fill 450 270 295 450 280 295 minecraft:light_gray_concrete
fill 450 270 299 450 280 299 minecraft:light_gray_concrete
fill 450 270 301 450 278 301 minecraft:light_gray_concrete
setblock 450 270 302 minecraft:white_concrete
setblock 451 270 294 minecraft:light_gray_concrete
setblock 451 270 295 minecraft:white_concrete
fill 451 270 296 451 278 296 minecraft:light_gray_concrete
setblock 451 270 297 minecraft:white_concrete
fill 451 270 298 451 278 298 minecraft:light_gray_concrete
setblock 451 270 299 minecraft:white_concrete
setblock 451 270 300 minecraft:light_gray_concrete
setblock 426 271 278 minecraft:light[level=12]
setblock 426 271 285 minecraft:light[level=12]
setblock 426 271 292 minecraft:light[level=12]
setblock 426 271 299 minecraft:light[level=12]
setblock 426 271 306 minecraft:light[level=12]
setblock 426 271 313 minecraft:light[level=12]
setblock 433 271 278 minecraft:light[level=12]
setblock 433 271 285 minecraft:light[level=12]
setblock 433 271 292 minecraft:light[level=12]
setblock 433 271 299 minecraft:light[level=12]
setblock 433 271 306 minecraft:light[level=12]
setblock 433 271 313 minecraft:light[level=12]
setblock 435 271 295 minecraft:light_gray_concrete
setblock 435 271 296 minecraft:white_concrete
setblock 435 271 297 minecraft:light_gray_concrete
setblock 435 271 298 minecraft:white_concrete
setblock 435 271 299 minecraft:light_gray_concrete
setblock 436 271 293 minecraft:white_concrete
fill 436 271 294 436 277 294 minecraft:light_gray_concrete
fill 436 271 296 436 279 296 minecraft:light_gray_concrete
fill 436 271 298 436 279 298 minecraft:light_gray_concrete
setblock 436 271 300 minecraft:sea_lantern
setblock 436 271 301 minecraft:white_concrete
setblock 437 271 292 minecraft:white_concrete
fill 437 271 293 437 279 293 minecraft:light_gray_concrete
fill 437 271 301 437 278 301 minecraft:light_gray_concrete
setblock 437 271 302 minecraft:white_concrete
setblock 438 271 291 minecraft:white_concrete
setblock 438 271 303 minecraft:white_concrete
setblock 439 271 290 minecraft:white_concrete
setblock 439 271 304 minecraft:white_concrete
setblock 440 271 278 minecraft:light[level=12]
setblock 440 271 285 minecraft:light[level=12]
setblock 440 271 289 minecraft:white_concrete
fill 440 271 290 441 278 290 minecraft:light_gray_concrete
fill 440 271 304 440 279 304 minecraft:light_gray_concrete
setblock 440 271 305 minecraft:white_concrete
setblock 440 271 306 minecraft:light[level=12]
setblock 440 271 313 minecraft:light[level=12]
setblock 441 271 289 minecraft:light_gray_concrete
setblock 441 271 305 minecraft:light_gray_concrete
setblock 442 271 289 minecraft:white_concrete
setblock 442 271 305 minecraft:white_concrete
fill 443 271 289 443 277 289 minecraft:light_gray_concrete
fill 443 271 305 443 277 305 minecraft:light_gray_concrete
setblock 444 271 289 minecraft:white_concrete
setblock 444 271 305 minecraft:white_concrete
fill 445 271 289 445 277 289 minecraft:light_gray_concrete
fill 445 271 305 445 277 305 minecraft:light_gray_concrete
setblock 446 271 289 minecraft:white_concrete
fill 446 271 290 446 279 290 minecraft:light_gray_concrete
fill 446 271 304 446 279 304 minecraft:light_gray_concrete
setblock 446 271 305 minecraft:white_concrete
setblock 447 271 278 minecraft:light[level=12]
setblock 447 271 285 minecraft:light[level=12]
setblock 447 271 289 minecraft:sea_lantern
setblock 447 271 305 minecraft:light_gray_concrete
setblock 447 271 306 minecraft:light[level=12]
setblock 447 271 313 minecraft:light[level=12]
setblock 448 271 290 minecraft:light_gray_concrete
setblock 448 271 304 minecraft:light_gray_concrete
fill 449 271 291 449 277 291 minecraft:light_gray_concrete
fill 449 271 303 449 277 303 minecraft:light_gray_concrete
fill 450 271 292 450 277 292 minecraft:light_gray_concrete
setblock 450 271 302 minecraft:sea_lantern
setblock 451 271 293 minecraft:light_gray_concrete
setblock 451 271 294 minecraft:white_concrete
fill 451 271 295 451 279 295 minecraft:light_gray_concrete
fill 451 271 297 451 279 297 minecraft:light_gray_concrete
fill 451 271 299 451 279 299 minecraft:light_gray_concrete
setblock 451 271 300 minecraft:white_concrete
setblock 451 271 301 minecraft:light_gray_concrete
setblock 452 271 295 minecraft:white_concrete
setblock 452 271 296 minecraft:sea_lantern
setblock 452 271 297 minecraft:white_concrete
setblock 452 271 298 minecraft:light_gray_concrete
setblock 452 271 299 minecraft:white_concrete
setblock 454 271 278 minecraft:light[level=12]
setblock 454 271 285 minecraft:light[level=12]
setblock 454 271 292 minecraft:light[level=12]
setblock 454 271 299 minecraft:light[level=12]
setblock 454 271 306 minecraft:light[level=12]
setblock 454 271 313 minecraft:light[level=12]
setblock 461 271 278 minecraft:light[level=12]
setblock 461 271 285 minecraft:light[level=12]
setblock 461 271 292 minecraft:light[level=12]
setblock 461 271 299 minecraft:light[level=12]
setblock 461 271 306 minecraft:light[level=12]
setblock 461 271 313 minecraft:light[level=12]
setblock 435 272 294 minecraft:light_gray_concrete
setblock 435 272 295 minecraft:white_concrete
setblock 435 272 296 minecraft:light_gray_concrete
setblock 435 272 297 minecraft:white_concrete
setblock 435 272 298 minecraft:sea_lantern
setblock 435 272 299 minecraft:white_concrete
fill 435 272 300 436 272 300 minecraft:light_gray_concrete
setblock 436 272 292 minecraft:white_concrete
setblock 436 272 293 minecraft:light_gray_concrete
setblock 436 272 301 minecraft:light_gray_concrete
setblock 436 272 302 minecraft:white_concrete
setblock 437 272 291 minecraft:white_concrete
fill 437 272 292 437 278 292 minecraft:light_gray_concrete
fill 437 272 302 437 278 302 minecraft:light_gray_concrete
setblock 437 272 303 minecraft:sea_lantern
setblock 438 272 290 minecraft:white_concrete
fill 438 272 291 438 278 291 minecraft:light_gray_concrete
fill 438 272 303 438 277 303 minecraft:light_gray_concrete
setblock 438 272 304 minecraft:white_concrete
fill 439 272 290 439 276 290 minecraft:light_gray_concrete
fill 439 272 304 439 276 304 minecraft:light_gray_concrete
setblock 440 272 289 minecraft:light_gray_concrete
setblock 440 272 305 minecraft:sea_lantern
setblock 441 272 289 minecraft:white_concrete
setblock 441 272 305 minecraft:white_concrete
setblock 442 272 288 minecraft:sea_lantern
fill 442 272 289 442 278 289 minecraft:light_gray_concrete
fill 442 272 305 442 278 305 minecraft:light_gray_concrete
setblock 442 272 306 minecraft:white_concrete
setblock 443 272 288 minecraft:light_gray_concrete
setblock 443 272 306 minecraft:light_gray_concrete
setblock 444 272 288 minecraft:white_concrete
fill 444 272 289 444 278 289 minecraft:light_gray_concrete
fill 444 272 305 444 278 305 minecraft:light_gray_concrete
setblock 444 272 306 minecraft:white_concrete
setblock 445 272 288 minecraft:light_gray_concrete
setblock 445 272 306 minecraft:light_gray_concrete
fill 446 272 289 446 276 289 minecraft:light_gray_concrete
fill 446 272 305 446 276 305 minecraft:light_gray_concrete
setblock 447 272 289 minecraft:white_concrete
setblock 447 272 305 minecraft:white_concrete
setblock 448 272 290 minecraft:white_concrete
setblock 448 272 304 minecraft:white_concrete
setblock 449 272 290 minecraft:light_gray_concrete
setblock 449 272 304 minecraft:light_gray_concrete
setblock 450 272 291 minecraft:light_gray_concrete
fill 450 272 302 450 272 303 minecraft:light_gray_concrete
setblock 451 272 292 minecraft:light_gray_concrete
setblock 451 272 293 minecraft:white_concrete
fill 451 272 294 451 278 294 minecraft:light_gray_concrete
fill 451 272 300 451 278 300 minecraft:light_gray_concrete
setblock 451 272 301 minecraft:white_concrete
setblock 451 272 302 minecraft:light_gray_concrete
setblock 452 272 294 minecraft:white_concrete
setblock 452 272 295 minecraft:light_gray_concrete
setblock 452 272 296 minecraft:white_concrete
setblock 452 272 297 minecraft:light_gray_concrete
setblock 452 272 298 minecraft:white_concrete
setblock 452 272 299 minecraft:light_gray_concrete
setblock 452 272 300 minecraft:white_concrete
setblock 435 273 294 minecraft:white_concrete
setblock 435 273 295 minecraft:light_gray_concrete
setblock 435 273 296 minecraft:white_concrete
setblock 435 273 297 minecraft:light_gray_concrete
setblock 435 273 298 minecraft:white_concrete
setblock 435 273 299 minecraft:light_gray_concrete
setblock 435 273 300 minecraft:white_concrete
setblock 436 273 292 minecraft:light_gray_concrete
setblock 436 273 293 minecraft:white_concrete
fill 436 273 300 436 277 300 minecraft:light_gray_concrete
setblock 436 273 301 minecraft:sea_lantern
setblock 436 273 302 minecraft:light_gray_concrete
setblock 437 273 291 minecraft:light_gray_concrete
setblock 437 273 303 minecraft:light_gray_concrete
setblock 438 273 290 minecraft:light_gray_concrete
setblock 438 273 304 minecraft:light_gray_concrete
setblock 439 273 289 minecraft:light_gray_concrete
setblock 439 273 305 minecraft:light_gray_concrete
setblock 440 273 289 minecraft:sea_lantern
setblock 440 273 305 minecraft:white_concrete
setblock 441 273 288 minecraft:white_concrete
fill 441 273 289 441 277 289 minecraft:light_gray_concrete
fill 441 273 305 441 277 305 minecraft:light_gray_concrete
setblock 441 273 306 minecraft:white_concrete
setblock 442 273 288 minecraft:light_gray_concrete
setblock 442 273 306 minecraft:light_gray_concrete
setblock 443 273 288 minecraft:white_concrete
setblock 443 273 306 minecraft:white_concrete
setblock 444 273 288 minecraft:sea_lantern
setblock 444 273 306 minecraft:light_gray_concrete
setblock 445 273 288 minecraft:white_concrete
setblock 445 273 306 minecraft:white_concrete
setblock 446 273 288 minecraft:light_gray_concrete
setblock 446 273 306 minecraft:light_gray_concrete
setblock 447 273 289 minecraft:light_gray_concrete
setblock 447 273 305 minecraft:light_gray_concrete
setblock 448 273 289 minecraft:white_concrete
fill 448 273 290 448 277 290 minecraft:light_gray_concrete
fill 448 273 304 448 277 304 minecraft:light_gray_concrete
setblock 448 273 305 minecraft:white_concrete
setblock 449 273 290 minecraft:white_concrete
setblock 449 273 304 minecraft:white_concrete
setblock 450 273 291 minecraft:white_concrete
fill 450 273 302 450 277 302 minecraft:light_gray_concrete
setblock 450 273 303 minecraft:sea_lantern
setblock 451 273 292 minecraft:white_concrete
fill 451 273 293 451 275 293 minecraft:light_gray_concrete
fill 451 273 301 451 275 301 minecraft:light_gray_concrete
setblock 451 273 302 minecraft:white_concrete
setblock 452 273 294 minecraft:light_gray_concrete
setblock 452 273 295 minecraft:white_concrete
setblock 452 273 296 minecraft:light_gray_concrete
setblock 452 273 297 minecraft:sea_lantern
setblock 452 273 298 minecraft:light_gray_concrete
setblock 452 273 299 minecraft:white_concrete
setblock 452 273 300 minecraft:light_gray_concrete
setblock 435 274 293 minecraft:white_concrete
setblock 435 274 294 minecraft:light_gray_concrete
setblock 435 274 295 minecraft:white_concrete
setblock 435 274 296 minecraft:light_gray_concrete
setblock 435 274 297 minecraft:white_concrete
setblock 435 274 298 minecraft:light_gray_concrete
setblock 435 274 299 minecraft:sea_lantern
setblock 435 274 300 minecraft:light_gray_concrete
setblock 435 274 301 minecraft:white_concrete
setblock 436 274 292 minecraft:white_concrete
fill 436 274 293 436 276 293 minecraft:light_gray_concrete
fill 436 274 301 436 276 301 minecraft:light_gray_concrete
setblock 436 274 302 minecraft:white_concrete
setblock 437 274 291 minecraft:white_concrete
setblock 437 274 303 minecraft:white_concrete
setblock 438 274 290 minecraft:sea_lantern
setblock 438 274 304 minecraft:white_concrete
setblock 439 274 289 minecraft:white_concrete
setblock 439 274 305 minecraft:white_concrete
setblock 440 274 289 minecraft:light_gray_concrete
setblock 440 274 305 minecraft:light_gray_concrete
setblock 441 274 288 minecraft:light_gray_concrete
setblock 441 274 306 minecraft:light_gray_concrete
setblock 442 274 288 minecraft:white_concrete
setblock 442 274 306 minecraft:white_concrete
setblock 443 274 288 minecraft:light_gray_concrete
setblock 443 274 306 minecraft:light_gray_concrete
setblock 444 274 288 minecraft:white_concrete
setblock 444 274 306 minecraft:white_concrete
setblock 445 274 288 minecraft:light_gray_concrete
setblock 445 274 306 minecraft:light_gray_concrete
setblock 446 274 288 minecraft:sea_lantern
setblock 446 274 306 minecraft:white_concrete
setblock 447 274 289 minecraft:white_concrete
setblock 447 274 305 minecraft:white_concrete
setblock 448 274 289 minecraft:light_gray_concrete
setblock 448 274 305 minecraft:light_gray_concrete
setblock 449 274 290 minecraft:sea_lantern
setblock 449 274 304 minecraft:light_gray_concrete
setblock 450 274 291 minecraft:light_gray_concrete
setblock 450 274 303 minecraft:light_gray_concrete
setblock 451 274 292 minecraft:light_gray_concrete
setblock 451 274 302 minecraft:light_gray_concrete
setblock 452 274 293 minecraft:light_gray_concrete
setblock 452 274 294 minecraft:white_concrete
setblock 452 274 295 minecraft:light_gray_concrete
setblock 452 274 296 minecraft:white_concrete
setblock 452 274 297 minecraft:light_gray_concrete
setblock 452 274 298 minecraft:white_concrete
setblock 452 274 299 minecraft:light_gray_concrete
setblock 452 274 300 minecraft:white_concrete
setblock 452 274 301 minecraft:light_gray_concrete
setblock 435 275 293 minecraft:light_gray_concrete
setblock 435 275 294 minecraft:sea_lantern
setblock 435 275 295 minecraft:light_gray_concrete
setblock 435 275 296 minecraft:white_concrete
setblock 435 275 297 minecraft:light_gray_concrete
setblock 435 275 298 minecraft:white_concrete
setblock 435 275 299 minecraft:light_gray_concrete
setblock 435 275 300 minecraft:white_concrete
setblock 435 275 301 minecraft:light_gray_concrete
setblock 436 275 292 minecraft:light_gray_concrete
setblock 436 275 302 minecraft:sea_lantern
setblock 437 275 291 minecraft:light_gray_concrete
setblock 437 275 303 minecraft:light_gray_concrete
setblock 438 275 290 minecraft:light_gray_concrete
setblock 438 275 304 minecraft:light_gray_concrete
setblock 439 275 289 minecraft:light_gray_concrete
setblock 439 275 305 minecraft:light_gray_concrete
setblock 440 275 289 minecraft:white_concrete
setblock 440 275 305 minecraft:white_concrete
setblock 441 275 288 minecraft:white_concrete
setblock 441 275 306 minecraft:white_concrete
setblock 442 275 288 minecraft:light_gray_concrete
setblock 442 275 306 minecraft:sea_lantern
setblock 443 275 288 minecraft:white_concrete
setblock 443 275 306 minecraft:white_concrete
setblock 444 275 288 minecraft:light_gray_concrete
setblock 444 275 306 minecraft:light_gray_concrete
setblock 445 275 288 minecraft:white_concrete
setblock 445 275 306 minecraft:white_concrete
setblock 446 275 288 minecraft:light_gray_concrete
setblock 446 275 306 minecraft:light_gray_concrete
setblock 447 275 289 minecraft:light_gray_concrete
setblock 447 275 305 minecraft:light_gray_concrete
setblock 448 275 289 minecraft:white_concrete
setblock 448 275 305 minecraft:white_concrete
setblock 449 275 290 minecraft:white_concrete
setblock 449 275 304 minecraft:white_concrete
setblock 450 275 291 minecraft:white_concrete
setblock 450 275 303 minecraft:white_concrete
setblock 451 275 292 minecraft:white_concrete
setblock 451 275 302 minecraft:white_concrete
setblock 452 275 293 minecraft:white_concrete
setblock 452 275 294 minecraft:light_gray_concrete
setblock 452 275 295 minecraft:white_concrete
setblock 452 275 296 minecraft:light_gray_concrete
setblock 452 275 297 minecraft:white_concrete
setblock 452 275 298 minecraft:sea_lantern
setblock 452 275 299 minecraft:white_concrete
setblock 452 275 300 minecraft:light_gray_concrete
setblock 452 275 301 minecraft:white_concrete
setblock 435 276 294 minecraft:light_gray_concrete
setblock 435 276 295 minecraft:white_concrete
setblock 435 276 296 minecraft:light_gray_concrete
setblock 435 276 297 minecraft:white_concrete
setblock 435 276 298 minecraft:light_gray_concrete
setblock 435 276 299 minecraft:white_concrete
setblock 435 276 300 minecraft:sea_lantern
setblock 436 276 292 minecraft:white_concrete
setblock 436 276 302 minecraft:white_concrete
setblock 437 276 291 minecraft:white_concrete
setblock 437 276 303 minecraft:white_concrete
setblock 438 276 290 minecraft:white_concrete
setblock 438 276 304 minecraft:white_concrete
setblock 439 276 289 minecraft:white_concrete
setblock 439 276 305 minecraft:white_concrete
setblock 440 276 289 minecraft:light_gray_concrete
setblock 440 276 305 minecraft:light_gray_concrete
setblock 441 276 288 minecraft:light_gray_concrete
setblock 441 276 306 minecraft:light_gray_concrete
setblock 442 276 288 minecraft:white_concrete
setblock 442 276 306 minecraft:white_concrete
setblock 443 276 288 minecraft:light_gray_concrete
setblock 443 276 306 minecraft:light_gray_concrete
setblock 444 276 288 minecraft:white_concrete
setblock 444 276 306 minecraft:sea_lantern
setblock 445 276 288 minecraft:light_gray_concrete
setblock 445 276 306 minecraft:light_gray_concrete
setblock 446 276 288 minecraft:white_concrete
setblock 446 276 306 minecraft:white_concrete
setblock 447 276 289 minecraft:white_concrete
setblock 447 276 305 minecraft:white_concrete
setblock 448 276 289 minecraft:light_gray_concrete
setblock 448 276 305 minecraft:sea_lantern
setblock 449 276 290 minecraft:light_gray_concrete
setblock 449 276 304 minecraft:light_gray_concrete
setblock 450 276 291 minecraft:light_gray_concrete
setblock 450 276 303 minecraft:light_gray_concrete
setblock 451 276 292 minecraft:light_gray_concrete
setblock 451 276 293 minecraft:white_concrete
setblock 451 276 301 minecraft:white_concrete
setblock 451 276 302 minecraft:light_gray_concrete
setblock 452 276 294 minecraft:white_concrete
setblock 452 276 295 minecraft:light_gray_concrete
setblock 452 276 296 minecraft:white_concrete
setblock 452 276 297 minecraft:light_gray_concrete
setblock 452 276 298 minecraft:white_concrete
setblock 452 276 299 minecraft:light_gray_concrete
setblock 452 276 300 minecraft:white_concrete
setblock 426 277 278 minecraft:light[level=15]
setblock 426 277 285 minecraft:light[level=12]
setblock 426 277 286 minecraft:light[level=15]
setblock 426 277 292 minecraft:light[level=12]
setblock 426 277 294 minecraft:light[level=15]
setblock 426 277 299 minecraft:light[level=12]
setblock 426 277 302 minecraft:light[level=15]
setblock 426 277 306 minecraft:light[level=12]
setblock 426 277 310 minecraft:light[level=15]
setblock 426 277 313 minecraft:light[level=12]
setblock 433 277 278 minecraft:light[level=12]
setblock 433 277 285 minecraft:light[level=12]
setblock 433 277 292 minecraft:light[level=12]
setblock 433 277 299 minecraft:light[level=12]
setblock 433 277 306 minecraft:light[level=12]
setblock 433 277 313 minecraft:light[level=12]
setblock 434 277 278 minecraft:light[level=15]
setblock 434 277 286 minecraft:light[level=15]
setblock 434 277 294 minecraft:light[level=15]
setblock 434 277 302 minecraft:light[level=15]
setblock 434 277 310 minecraft:light[level=15]
setblock 435 277 294 minecraft:white_concrete
setblock 435 277 295 minecraft:sea_lantern
setblock 435 277 296 minecraft:white_concrete
setblock 435 277 297 minecraft:light_gray_concrete
setblock 435 277 298 minecraft:white_concrete
setblock 435 277 299 minecraft:light_gray_concrete
setblock 435 277 300 minecraft:white_concrete
setblock 436 277 292 minecraft:sea_lantern
setblock 436 277 293 minecraft:white_concrete
setblock 436 277 301 minecraft:white_concrete
setblock 436 277 302 minecraft:light_gray_concrete
setblock 437 277 291 minecraft:light_gray_concrete
setblock 437 277 303 minecraft:light_gray_concrete
setblock 438 277 290 minecraft:light_gray_concrete
setblock 438 277 304 minecraft:light_gray_concrete
setblock 439 277 290 minecraft:white_concrete
setblock 439 277 304 minecraft:white_concrete
setblock 440 277 278 minecraft:light[level=12]
setblock 440 277 285 minecraft:light[level=12]
setblock 440 277 289 minecraft:white_concrete
setblock 440 277 305 minecraft:white_concrete
setblock 440 277 306 minecraft:light[level=12]
setblock 440 277 313 minecraft:light[level=12]
setblock 442 277 278 minecraft:light[level=15]
setblock 442 277 286 minecraft:light[level=15]
setblock 442 277 288 minecraft:light_gray_concrete
setblock 442 277 306 minecraft:light_gray_concrete
setblock 442 277 310 minecraft:light[level=15]
setblock 443 277 288 minecraft:white_concrete
setblock 443 277 306 minecraft:white_concrete
setblock 444 277 288 minecraft:light_gray_concrete
setblock 444 277 306 minecraft:light_gray_concrete
setblock 445 277 288 minecraft:white_concrete
setblock 445 277 306 minecraft:white_concrete
setblock 446 277 289 minecraft:white_concrete
setblock 446 277 305 minecraft:white_concrete
setblock 447 277 278 minecraft:light[level=12]
setblock 447 277 285 minecraft:light[level=12]
setblock 447 277 289 minecraft:light_gray_concrete
setblock 447 277 305 minecraft:light_gray_concrete
setblock 447 277 306 minecraft:light[level=12]
setblock 447 277 313 minecraft:light[level=12]
setblock 449 277 290 minecraft:white_concrete
setblock 449 277 304 minecraft:white_concrete
setblock 450 277 278 minecraft:light[level=15]
setblock 450 277 286 minecraft:light[level=15]
setblock 450 277 291 minecraft:white_concrete
setblock 450 277 303 minecraft:white_concrete
setblock 450 277 310 minecraft:light[level=15]
setblock 451 277 292 minecraft:white_concrete
setblock 451 277 293 minecraft:light_gray_concrete
setblock 451 277 301 minecraft:light_gray_concrete
setblock 451 277 302 minecraft:sea_lantern
setblock 452 277 294 minecraft:light_gray_concrete
setblock 452 277 295 minecraft:white_concrete
setblock 452 277 296 minecraft:light_gray_concrete
setblock 452 277 297 minecraft:white_concrete
setblock 452 277 298 minecraft:light_gray_concrete
setblock 452 277 299 minecraft:sea_lantern
setblock 452 277 300 minecraft:light_gray_concrete
setblock 454 277 278 minecraft:light[level=12]
setblock 454 277 285 minecraft:light[level=12]
setblock 454 277 292 minecraft:light[level=12]
setblock 454 277 299 minecraft:light[level=12]
setblock 454 277 306 minecraft:light[level=12]
setblock 454 277 313 minecraft:light[level=12]
setblock 458 277 278 minecraft:light[level=15]
setblock 458 277 286 minecraft:light[level=15]
setblock 458 277 294 minecraft:light[level=15]
setblock 458 277 302 minecraft:light[level=15]
setblock 458 277 310 minecraft:light[level=15]
setblock 461 277 278 minecraft:light[level=12]
setblock 461 277 285 minecraft:light[level=12]
setblock 461 277 292 minecraft:light[level=12]
setblock 461 277 299 minecraft:light[level=12]
setblock 461 277 306 minecraft:light[level=12]
setblock 461 277 313 minecraft:light[level=12]
setblock 435 278 295 minecraft:white_concrete
setblock 435 278 296 minecraft:light_gray_concrete
setblock 435 278 297 minecraft:white_concrete
setblock 435 278 298 minecraft:light_gray_concrete
setblock 435 278 299 minecraft:white_concrete
setblock 436 278 293 minecraft:light_gray_concrete
setblock 436 278 294 minecraft:white_concrete
setblock 436 278 300 minecraft:white_concrete
setblock 436 278 301 minecraft:light_gray_concrete
setblock 438 278 303 minecraft:sea_lantern
setblock 439 278 290 minecraft:light_gray_concrete
setblock 439 278 304 minecraft:light_gray_concrete
setblock 440 278 289 minecraft:light_gray_concrete
setblock 440 278 305 minecraft:light_gray_concrete
setblock 441 278 289 minecraft:white_concrete
setblock 441 278 305 minecraft:sea_lantern
setblock 443 278 289 minecraft:white_concrete
setblock 443 278 305 minecraft:white_concrete
setblock 445 278 289 minecraft:white_concrete
setblock 445 278 305 minecraft:white_concrete
setblock 446 278 289 minecraft:light_gray_concrete
setblock 446 278 305 minecraft:light_gray_concrete
setblock 447 278 289 minecraft:white_concrete
setblock 447 278 305 minecraft:white_concrete
setblock 448 278 290 minecraft:white_concrete
setblock 448 278 304 minecraft:white_concrete
setblock 449 278 291 minecraft:white_concrete
setblock 449 278 303 minecraft:sea_lantern
setblock 450 278 292 minecraft:white_concrete
setblock 450 278 302 minecraft:white_concrete
setblock 451 278 293 minecraft:white_concrete
setblock 451 278 301 minecraft:white_concrete
setblock 452 278 295 minecraft:light_gray_concrete
setblock 452 278 296 minecraft:white_concrete
setblock 452 278 297 minecraft:light_gray_concrete
setblock 452 278 298 minecraft:white_concrete
setblock 452 278 299 minecraft:light_gray_concrete
setblock 424 279 276 minecraft:magenta_stained_glass
fill 424 279 277 424 279 280 minecraft:black_stained_glass
setblock 424 279 281 minecraft:magenta_stained_glass
fill 424 279 282 424 279 285 minecraft:black_stained_glass
setblock 424 279 286 minecraft:magenta_stained_glass
fill 424 279 287 424 279 290 minecraft:black_stained_glass
setblock 424 279 291 minecraft:magenta_stained_glass
fill 424 279 292 424 279 295 minecraft:black_stained_glass
setblock 424 279 296 minecraft:magenta_stained_glass
fill 424 279 297 424 279 300 minecraft:black_stained_glass
setblock 424 279 301 minecraft:magenta_stained_glass
fill 424 279 302 424 279 305 minecraft:black_stained_glass
setblock 424 279 306 minecraft:magenta_stained_glass
fill 424 279 307 424 279 310 minecraft:black_stained_glass
setblock 424 279 311 minecraft:magenta_stained_glass
fill 424 279 312 424 279 315 minecraft:black_stained_glass
setblock 424 279 316 minecraft:magenta_stained_glass
fill 425 279 276 428 279 276 minecraft:black_stained_glass
setblock 425 279 277 minecraft:magenta_stained_glass
fill 425 279 278 425 279 281 minecraft:black_stained_glass
setblock 425 279 282 minecraft:magenta_stained_glass
fill 425 279 283 425 279 286 minecraft:black_stained_glass
setblock 425 279 287 minecraft:magenta_stained_glass
fill 425 279 288 425 279 291 minecraft:black_stained_glass
setblock 425 279 292 minecraft:magenta_stained_glass
fill 425 279 293 425 279 296 minecraft:black_stained_glass
setblock 425 279 297 minecraft:magenta_stained_glass
fill 425 279 298 425 279 301 minecraft:black_stained_glass
setblock 425 279 302 minecraft:magenta_stained_glass
fill 425 279 303 425 279 306 minecraft:black_stained_glass
setblock 425 279 307 minecraft:magenta_stained_glass
fill 425 279 308 425 279 311 minecraft:black_stained_glass
setblock 425 279 312 minecraft:magenta_stained_glass
fill 425 279 313 425 279 316 minecraft:black_stained_glass
fill 426 279 277 429 279 277 minecraft:black_stained_glass
setblock 426 279 278 minecraft:magenta_stained_glass
fill 426 279 279 426 279 282 minecraft:black_stained_glass
setblock 426 279 283 minecraft:magenta_stained_glass
fill 426 279 284 426 279 287 minecraft:black_stained_glass
setblock 426 279 288 minecraft:magenta_stained_glass
fill 426 279 289 426 279 292 minecraft:black_stained_glass
setblock 426 279 293 minecraft:magenta_stained_glass
fill 426 279 294 426 279 297 minecraft:black_stained_glass
setblock 426 279 298 minecraft:magenta_stained_glass
fill 426 279 299 426 279 302 minecraft:black_stained_glass
setblock 426 279 303 minecraft:magenta_stained_glass
fill 426 279 304 426 279 307 minecraft:black_stained_glass
setblock 426 279 308 minecraft:magenta_stained_glass
fill 426 279 309 426 279 312 minecraft:black_stained_glass
setblock 426 279 313 minecraft:magenta_stained_glass
fill 426 279 314 426 279 316 minecraft:black_stained_glass
fill 427 279 278 430 279 278 minecraft:black_stained_glass
setblock 427 279 279 minecraft:magenta_stained_glass
fill 427 279 280 427 279 283 minecraft:black_stained_glass
setblock 427 279 284 minecraft:magenta_stained_glass
fill 427 279 285 427 279 288 minecraft:black_stained_glass
setblock 427 279 289 minecraft:magenta_stained_glass
fill 427 279 290 427 279 293 minecraft:black_stained_glass
setblock 427 279 294 minecraft:magenta_stained_glass
fill 427 279 295 427 279 298 minecraft:black_stained_glass
setblock 427 279 299 minecraft:magenta_stained_glass
fill 427 279 300 427 279 303 minecraft:black_stained_glass
setblock 427 279 304 minecraft:magenta_stained_glass
fill 427 279 305 427 279 308 minecraft:black_stained_glass
setblock 427 279 309 minecraft:magenta_stained_glass
fill 427 279 310 427 279 313 minecraft:black_stained_glass
setblock 427 279 314 minecraft:magenta_stained_glass
fill 427 279 315 427 279 316 minecraft:black_stained_glass
fill 428 279 279 431 279 279 minecraft:black_stained_glass
setblock 428 279 280 minecraft:magenta_stained_glass
fill 428 279 281 428 279 284 minecraft:black_stained_glass
setblock 428 279 285 minecraft:magenta_stained_glass
fill 428 279 286 428 279 289 minecraft:black_stained_glass
setblock 428 279 290 minecraft:magenta_stained_glass
fill 428 279 291 428 279 294 minecraft:black_stained_glass
setblock 428 279 295 minecraft:magenta_stained_glass
fill 428 279 296 428 279 299 minecraft:black_stained_glass
setblock 428 279 300 minecraft:magenta_stained_glass
fill 428 279 301 428 279 304 minecraft:black_stained_glass
setblock 428 279 305 minecraft:magenta_stained_glass
fill 428 279 306 428 279 309 minecraft:black_stained_glass
setblock 428 279 310 minecraft:magenta_stained_glass
fill 428 279 311 428 279 314 minecraft:black_stained_glass
setblock 428 279 315 minecraft:magenta_stained_glass
setblock 428 279 316 minecraft:black_stained_glass
setblock 429 279 276 minecraft:magenta_stained_glass
fill 429 279 280 432 279 280 minecraft:black_stained_glass
setblock 429 279 281 minecraft:magenta_stained_glass
fill 429 279 282 429 279 285 minecraft:black_stained_glass
setblock 429 279 286 minecraft:magenta_stained_glass
fill 429 279 287 429 279 290 minecraft:black_stained_glass
setblock 429 279 291 minecraft:magenta_stained_glass
fill 429 279 292 429 279 295 minecraft:black_stained_glass
setblock 429 279 296 minecraft:magenta_stained_glass
fill 429 279 297 429 279 300 minecraft:black_stained_glass
setblock 429 279 301 minecraft:magenta_stained_glass
fill 429 279 302 429 279 305 minecraft:black_stained_glass
setblock 429 279 306 minecraft:magenta_stained_glass
fill 429 279 307 429 279 310 minecraft:black_stained_glass
setblock 429 279 311 minecraft:magenta_stained_glass
fill 429 279 312 429 279 315 minecraft:black_stained_glass
setblock 429 279 316 minecraft:magenta_stained_glass
fill 430 279 276 433 279 276 minecraft:black_stained_glass
setblock 430 279 277 minecraft:magenta_stained_glass
fill 430 279 281 433 279 281 minecraft:black_stained_glass
setblock 430 279 282 minecraft:magenta_stained_glass
fill 430 279 283 430 279 286 minecraft:black_stained_glass
setblock 430 279 287 minecraft:magenta_stained_glass
fill 430 279 288 430 279 291 minecraft:black_stained_glass
setblock 430 279 292 minecraft:magenta_stained_glass
fill 430 279 293 430 279 296 minecraft:black_stained_glass
setblock 430 279 297 minecraft:magenta_stained_glass
fill 430 279 298 430 279 301 minecraft:black_stained_glass
setblock 430 279 302 minecraft:magenta_stained_glass
fill 430 279 303 430 279 306 minecraft:black_stained_glass
setblock 430 279 307 minecraft:magenta_stained_glass
fill 430 279 308 430 279 311 minecraft:black_stained_glass
setblock 430 279 312 minecraft:magenta_stained_glass
fill 430 279 313 430 279 316 minecraft:black_stained_glass
fill 431 279 277 434 279 277 minecraft:black_stained_glass
setblock 431 279 278 minecraft:magenta_stained_glass
fill 431 279 282 434 279 282 minecraft:black_stained_glass
setblock 431 279 283 minecraft:magenta_stained_glass
fill 431 279 284 431 279 287 minecraft:black_stained_glass
setblock 431 279 288 minecraft:magenta_stained_glass
fill 431 279 289 431 279 292 minecraft:black_stained_glass
setblock 431 279 293 minecraft:magenta_stained_glass
fill 431 279 294 431 279 297 minecraft:black_stained_glass
setblock 431 279 298 minecraft:magenta_stained_glass
fill 431 279 299 431 279 302 minecraft:black_stained_glass
setblock 431 279 303 minecraft:magenta_stained_glass
fill 431 279 304 431 279 307 minecraft:black_stained_glass
setblock 431 279 308 minecraft:magenta_stained_glass
fill 431 279 309 431 279 312 minecraft:black_stained_glass
setblock 431 279 313 minecraft:magenta_stained_glass
fill 431 279 314 431 279 316 minecraft:black_stained_glass
fill 432 279 278 435 279 278 minecraft:black_stained_glass
setblock 432 279 279 minecraft:magenta_stained_glass
fill 432 279 283 435 279 283 minecraft:black_stained_glass
setblock 432 279 284 minecraft:magenta_stained_glass
fill 432 279 285 432 279 288 minecraft:black_stained_glass
setblock 432 279 289 minecraft:magenta_stained_glass
fill 432 279 290 432 279 293 minecraft:black_stained_glass
setblock 432 279 294 minecraft:magenta_stained_glass
fill 432 279 295 432 279 298 minecraft:black_stained_glass
setblock 432 279 299 minecraft:magenta_stained_glass
fill 432 279 300 432 279 303 minecraft:black_stained_glass
setblock 432 279 304 minecraft:magenta_stained_glass
fill 432 279 305 432 279 308 minecraft:black_stained_glass
setblock 432 279 309 minecraft:magenta_stained_glass
fill 432 279 310 432 279 313 minecraft:black_stained_glass
setblock 432 279 314 minecraft:magenta_stained_glass
fill 432 279 315 432 279 316 minecraft:black_stained_glass
fill 433 279 279 436 279 279 minecraft:black_stained_glass
setblock 433 279 280 minecraft:magenta_stained_glass
fill 433 279 284 436 279 284 minecraft:black_stained_glass
setblock 433 279 285 minecraft:magenta_stained_glass
fill 433 279 286 433 279 289 minecraft:black_stained_glass
setblock 433 279 290 minecraft:magenta_stained_glass
fill 433 279 291 433 279 294 minecraft:black_stained_glass
setblock 433 279 295 minecraft:magenta_stained_glass
fill 433 279 296 433 279 299 minecraft:black_stained_glass
setblock 433 279 300 minecraft:magenta_stained_glass
fill 433 279 301 433 279 304 minecraft:black_stained_glass
setblock 433 279 305 minecraft:magenta_stained_glass
fill 433 279 306 433 279 309 minecraft:black_stained_glass
setblock 433 279 310 minecraft:magenta_stained_glass
fill 433 279 311 433 279 314 minecraft:black_stained_glass
setblock 433 279 315 minecraft:magenta_stained_glass
setblock 433 279 316 minecraft:black_stained_glass
setblock 434 279 276 minecraft:magenta_stained_glass
fill 434 279 280 437 279 280 minecraft:black_stained_glass
setblock 434 279 281 minecraft:magenta_stained_glass
fill 434 279 285 437 279 285 minecraft:black_stained_glass
setblock 434 279 286 minecraft:magenta_stained_glass
fill 434 279 287 434 279 290 minecraft:black_stained_glass
setblock 434 279 291 minecraft:magenta_stained_glass
fill 434 279 292 434 279 295 minecraft:black_stained_glass
setblock 434 279 296 minecraft:magenta_stained_glass
fill 434 279 297 434 279 300 minecraft:black_stained_glass
setblock 434 279 301 minecraft:magenta_stained_glass
fill 434 279 302 434 279 305 minecraft:black_stained_glass
setblock 434 279 306 minecraft:magenta_stained_glass
fill 434 279 307 434 279 310 minecraft:black_stained_glass
setblock 434 279 311 minecraft:magenta_stained_glass
fill 434 279 312 434 279 315 minecraft:black_stained_glass
setblock 434 279 316 minecraft:magenta_stained_glass
fill 435 279 276 438 279 276 minecraft:black_stained_glass
setblock 435 279 277 minecraft:magenta_stained_glass
fill 435 279 281 438 279 281 minecraft:black_stained_glass
setblock 435 279 282 minecraft:magenta_stained_glass
fill 435 279 286 438 279 286 minecraft:black_stained_glass
setblock 435 279 287 minecraft:magenta_stained_glass
fill 435 279 288 435 279 291 minecraft:black_stained_glass
setblock 435 279 292 minecraft:magenta_stained_glass
fill 435 279 293 435 279 296 minecraft:black_stained_glass
setblock 435 279 297 minecraft:magenta_stained_glass
fill 435 279 298 435 279 301 minecraft:black_stained_glass
setblock 435 279 302 minecraft:magenta_stained_glass
fill 435 279 303 435 279 306 minecraft:black_stained_glass
setblock 435 279 307 minecraft:magenta_stained_glass
fill 435 279 308 435 279 311 minecraft:black_stained_glass
setblock 435 279 312 minecraft:magenta_stained_glass
fill 435 279 313 435 279 316 minecraft:black_stained_glass
fill 436 279 277 439 279 277 minecraft:black_stained_glass
setblock 436 279 278 minecraft:magenta_stained_glass
fill 436 279 282 439 279 282 minecraft:black_stained_glass
setblock 436 279 283 minecraft:magenta_stained_glass
fill 436 279 287 439 279 287 minecraft:black_stained_glass
setblock 436 279 288 minecraft:magenta_stained_glass
fill 436 279 289 436 279 292 minecraft:black_stained_glass
setblock 436 279 293 minecraft:magenta_stained_glass
setblock 436 279 294 minecraft:light_gray_concrete
setblock 436 279 295 minecraft:white_concrete
setblock 436 279 297 minecraft:white_concrete
setblock 436 279 299 minecraft:white_concrete
setblock 436 279 300 minecraft:light_gray_concrete
fill 436 279 301 436 279 302 minecraft:black_stained_glass
setblock 436 279 303 minecraft:magenta_stained_glass
fill 436 279 304 436 279 307 minecraft:black_stained_glass
setblock 436 279 308 minecraft:magenta_stained_glass
fill 436 279 309 436 279 312 minecraft:black_stained_glass
setblock 436 279 313 minecraft:magenta_stained_glass
fill 436 279 314 436 279 316 minecraft:black_stained_glass
fill 437 279 278 440 279 278 minecraft:black_stained_glass
setblock 437 279 279 minecraft:magenta_stained_glass
fill 437 279 283 440 279 283 minecraft:black_stained_glass
setblock 437 279 284 minecraft:magenta_stained_glass
fill 437 279 288 440 279 288 minecraft:black_stained_glass
setblock 437 279 289 minecraft:magenta_stained_glass
fill 437 279 290 437 279 291 minecraft:black_stained_glass
setblock 437 279 292 minecraft:white_concrete
setblock 437 279 301 minecraft:sea_lantern
setblock 437 279 302 minecraft:white_concrete
setblock 437 279 303 minecraft:black_stained_glass
setblock 437 279 304 minecraft:magenta_stained_glass
fill 437 279 305 437 279 308 minecraft:black_stained_glass
setblock 437 279 309 minecraft:magenta_stained_glass
fill 437 279 310 437 279 313 minecraft:black_stained_glass
setblock 437 279 314 minecraft:magenta_stained_glass
fill 437 279 315 437 279 316 minecraft:black_stained_glass
fill 438 279 279 441 279 279 minecraft:black_stained_glass
setblock 438 279 280 minecraft:magenta_stained_glass
fill 438 279 284 441 279 284 minecraft:black_stained_glass
setblock 438 279 285 minecraft:magenta_stained_glass
fill 438 279 289 441 279 289 minecraft:black_stained_glass
setblock 438 279 290 minecraft:magenta_stained_glass
setblock 438 279 291 minecraft:white_concrete
setblock 438 279 303 minecraft:white_concrete
setblock 438 279 304 minecraft:black_stained_glass
setblock 438 279 305 minecraft:magenta_stained_glass
fill 438 279 306 438 279 309 minecraft:black_stained_glass
setblock 438 279 310 minecraft:magenta_stained_glass
fill 438 279 311 438 279 314 minecraft:black_stained_glass
setblock 438 279 315 minecraft:magenta_stained_glass
setblock 438 279 316 minecraft:black_stained_glass
setblock 439 279 276 minecraft:magenta_stained_glass
fill 439 279 280 442 279 280 minecraft:black_stained_glass
setblock 439 279 281 minecraft:magenta_stained_glass
fill 439 279 285 442 279 285 minecraft:black_stained_glass
setblock 439 279 286 minecraft:magenta_stained_glass
setblock 439 279 290 minecraft:white_concrete
fill 439 279 297 439 279 299 minecraft:pearlescent_froglight
setblock 439 279 304 minecraft:white_concrete
fill 439 279 305 441 279 305 minecraft:black_stained_glass
setblock 439 279 306 minecraft:magenta_stained_glass
fill 439 279 307 439 279 310 minecraft:black_stained_glass
setblock 439 279 311 minecraft:magenta_stained_glass
fill 439 279 312 439 279 315 minecraft:black_stained_glass
setblock 439 279 316 minecraft:magenta_stained_glass
fill 440 279 276 443 279 276 minecraft:black_stained_glass
setblock 440 279 277 minecraft:magenta_stained_glass
fill 440 279 281 443 279 281 minecraft:black_stained_glass
setblock 440 279 282 minecraft:magenta_stained_glass
fill 440 279 286 443 279 286 minecraft:black_stained_glass
setblock 440 279 287 minecraft:magenta_stained_glass
setblock 440 279 290 minecraft:light_gray_concrete
fill 440 279 295 440 279 297 minecraft:pearlescent_froglight
fill 440 279 299 440 279 301 minecraft:pearlescent_froglight
fill 440 279 306 443 279 306 minecraft:black_stained_glass
setblock 440 279 307 minecraft:magenta_stained_glass
fill 440 279 308 440 279 311 minecraft:black_stained_glass
setblock 440 279 312 minecraft:magenta_stained_glass
fill 440 279 313 440 279 316 minecraft:black_stained_glass
fill 441 279 277 444 279 277 minecraft:black_stained_glass
setblock 441 279 278 minecraft:magenta_stained_glass
fill 441 279 282 444 279 282 minecraft:black_stained_glass
setblock 441 279 283 minecraft:magenta_stained_glass
fill 441 279 287 444 279 287 minecraft:black_stained_glass
setblock 441 279 288 minecraft:magenta_stained_glass
setblock 441 279 290 minecraft:white_concrete
fill 441 279 295 442 279 295 minecraft:pearlescent_froglight
fill 441 279 301 442 279 301 minecraft:pearlescent_froglight
fill 441 279 302 441 282 302 minecraft:light_gray_concrete
setblock 441 279 304 minecraft:white_concrete
fill 441 279 307 444 279 307 minecraft:black_stained_glass
setblock 441 279 308 minecraft:magenta_stained_glass
fill 441 279 309 441 279 312 minecraft:black_stained_glass
setblock 441 279 313 minecraft:magenta_stained_glass
fill 441 279 314 441 279 316 minecraft:black_stained_glass
fill 442 279 278 445 279 278 minecraft:black_stained_glass
setblock 442 279 279 minecraft:magenta_stained_glass
fill 442 279 283 445 279 283 minecraft:black_stained_glass
setblock 442 279 284 minecraft:magenta_stained_glass
fill 442 279 288 445 279 288 minecraft:black_stained_glass
setblock 442 279 289 minecraft:white_concrete
fill 442 279 294 444 279 294 minecraft:pearlescent_froglight
fill 442 279 302 444 279 302 minecraft:pearlescent_froglight
setblock 442 279 305 minecraft:white_concrete
fill 442 279 308 445 279 308 minecraft:black_stained_glass
setblock 442 279 309 minecraft:magenta_stained_glass
fill 442 279 310 442 279 313 minecraft:black_stained_glass
setblock 442 279 314 minecraft:magenta_stained_glass
fill 442 279 315 442 279 316 minecraft:black_stained_glass
fill 443 279 279 446 279 279 minecraft:black_stained_glass
setblock 443 279 280 minecraft:magenta_stained_glass
fill 443 279 284 446 279 284 minecraft:black_stained_glass
setblock 443 279 285 minecraft:magenta_stained_glass
setblock 443 279 289 minecraft:light_gray_concrete
setblock 443 279 305 minecraft:sea_lantern
fill 443 279 309 446 279 309 minecraft:black_stained_glass
setblock 443 279 310 minecraft:magenta_stained_glass
fill 443 279 311 443 279 314 minecraft:black_stained_glass
setblock 443 279 315 minecraft:magenta_stained_glass
setblock 443 279 316 minecraft:black_stained_glass
setblock 444 279 276 minecraft:magenta_stained_glass
fill 444 279 280 447 279 280 minecraft:black_stained_glass
setblock 444 279 281 minecraft:magenta_stained_glass
fill 444 279 285 447 279 285 minecraft:black_stained_glass
setblock 444 279 286 minecraft:magenta_stained_glass
setblock 444 279 289 minecraft:white_concrete
fill 444 279 295 446 279 295 minecraft:pearlescent_froglight
fill 444 279 301 446 279 301 minecraft:pearlescent_froglight
setblock 444 279 305 minecraft:white_concrete
setblock 444 279 306 minecraft:magenta_stained_glass
fill 444 279 310 447 279 310 minecraft:black_stained_glass
setblock 444 279 311 minecraft:magenta_stained_glass
fill 444 279 312 444 279 315 minecraft:black_stained_glass
setblock 444 279 316 minecraft:magenta_stained_glass
fill 445 279 276 448 279 276 minecraft:black_stained_glass
setblock 445 279 277 minecraft:magenta_stained_glass
fill 445 279 281 448 279 281 minecraft:black_stained_glass
setblock 445 279 282 minecraft:magenta_stained_glass
fill 445 279 286 448 279 286 minecraft:black_stained_glass
setblock 445 279 287 minecraft:magenta_stained_glass
setblock 445 279 289 minecraft:light_gray_concrete
setblock 445 279 305 minecraft:light_gray_concrete
fill 445 279 306 448 279 306 minecraft:black_stained_glass
setblock 445 279 307 minecraft:magenta_stained_glass
fill 445 279 311 448 279 311 minecraft:black_stained_glass
setblock 445 279 312 minecraft:magenta_stained_glass
fill 445 279 313 445 279 316 minecraft:black_stained_glass
fill 446 279 277 449 279 277 minecraft:black_stained_glass
setblock 446 279 278 minecraft:magenta_stained_glass
fill 446 279 282 449 279 282 minecraft:black_stained_glass
setblock 446 279 283 minecraft:magenta_stained_glass
fill 446 279 287 449 279 287 minecraft:black_stained_glass
setblock 446 279 288 minecraft:magenta_stained_glass
setblock 446 279 289 minecraft:black_stained_glass
fill 446 279 296 446 279 297 minecraft:pearlescent_froglight
fill 446 279 299 446 279 300 minecraft:pearlescent_froglight
fill 446 279 305 447 279 305 minecraft:black_stained_glass
fill 446 279 307 449 279 307 minecraft:black_stained_glass
setblock 446 279 308 minecraft:magenta_stained_glass
fill 446 279 312 449 279 312 minecraft:black_stained_glass
setblock 446 279 313 minecraft:magenta_stained_glass
fill 446 279 314 446 279 316 minecraft:black_stained_glass
fill 447 279 278 450 279 278 minecraft:black_stained_glass
setblock 447 279 279 minecraft:magenta_stained_glass
fill 447 279 283 450 279 283 minecraft:black_stained_glass
setblock 447 279 284 minecraft:magenta_stained_glass
fill 447 279 288 450 279 288 minecraft:black_stained_glass
setblock 447 279 289 minecraft:magenta_stained_glass
setblock 447 279 290 minecraft:white_concrete
fill 447 279 295 447 282 295 minecraft:light_gray_concrete
fill 447 279 297 447 279 299 minecraft:pearlescent_froglight
setblock 447 279 304 minecraft:sea_lantern
fill 447 279 308 450 279 308 minecraft:black_stained_glass
setblock 447 279 309 minecraft:magenta_stained_glass
fill 447 279 313 450 279 313 minecraft:black_stained_glass
setblock 447 279 314 minecraft:magenta_stained_glass
fill 447 279 315 447 279 316 minecraft:black_stained_glass
fill 448 279 279 451 279 279 minecraft:black_stained_glass
setblock 448 279 280 minecraft:magenta_stained_glass
fill 448 279 284 451 279 284 minecraft:black_stained_glass
setblock 448 279 285 minecraft:magenta_stained_glass
fill 448 279 289 451 279 289 minecraft:black_stained_glass
setblock 448 279 290 minecraft:sea_lantern
setblock 448 279 304 minecraft:light_gray_concrete
setblock 448 279 305 minecraft:magenta_stained_glass
fill 448 279 309 451 279 309 minecraft:black_stained_glass
setblock 448 279 310 minecraft:magenta_stained_glass
fill 448 279 314 451 279 314 minecraft:black_stained_glass
setblock 448 279 315 minecraft:magenta_stained_glass
setblock 448 279 316 minecraft:black_stained_glass
setblock 449 279 276 minecraft:magenta_stained_glass
fill 449 279 280 452 279 280 minecraft:black_stained_glass
setblock 449 279 281 minecraft:magenta_stained_glass
fill 449 279 285 452 279 285 minecraft:black_stained_glass
setblock 449 279 286 minecraft:magenta_stained_glass
fill 449 279 290 452 279 290 minecraft:black_stained_glass
setblock 449 279 291 minecraft:light_gray_concrete
setblock 449 279 303 minecraft:light_gray_concrete
fill 449 279 304 451 279 305 minecraft:black_stained_glass
setblock 449 279 306 minecraft:magenta_stained_glass
fill 449 279 310 452 279 310 minecraft:black_stained_glass
setblock 449 279 311 minecraft:magenta_stained_glass
fill 449 279 315 452 279 315 minecraft:black_stained_glass
setblock 449 279 316 minecraft:magenta_stained_glass
fill 450 279 276 453 279 276 minecraft:black_stained_glass
setblock 450 279 277 minecraft:magenta_stained_glass
fill 450 279 281 453 279 281 minecraft:black_stained_glass
setblock 450 279 282 minecraft:magenta_stained_glass
fill 450 279 286 453 279 286 minecraft:black_stained_glass
setblock 450 279 287 minecraft:magenta_stained_glass
fill 450 279 291 453 279 291 minecraft:black_stained_glass
setblock 450 279 292 minecraft:light_gray_concrete
setblock 450 279 293 minecraft:white_concrete
setblock 450 279 301 minecraft:white_concrete
setblock 450 279 302 minecraft:light_gray_concrete
setblock 450 279 303 minecraft:black_stained_glass
fill 450 279 306 453 279 306 minecraft:black_stained_glass
setblock 450 279 307 minecraft:magenta_stained_glass
fill 450 279 311 453 279 311 minecraft:black_stained_glass
setblock 450 279 312 minecraft:magenta_stained_glass
fill 450 279 316 453 279 316 minecraft:black_stained_glass
fill 451 279 277 454 279 277 minecraft:black_stained_glass
setblock 451 279 278 minecraft:magenta_stained_glass
fill 451 279 282 454 279 282 minecraft:black_stained_glass
setblock 451 279 283 minecraft:magenta_stained_glass
fill 451 279 287 454 279 287 minecraft:black_stained_glass
setblock 451 279 288 minecraft:magenta_stained_glass
fill 451 279 292 454 279 292 minecraft:black_stained_glass
setblock 451 279 293 minecraft:magenta_stained_glass
setblock 451 279 294 minecraft:white_concrete
setblock 451 279 296 minecraft:white_concrete
setblock 451 279 298 minecraft:white_concrete
setblock 451 279 300 minecraft:white_concrete
fill 451 279 301 453 279 302 minecraft:black_stained_glass
setblock 451 279 303 minecraft:magenta_stained_glass
fill 451 279 307 454 279 307 minecraft:black_stained_glass
setblock 451 279 308 minecraft:magenta_stained_glass
fill 451 279 312 454 279 312 minecraft:black_stained_glass
setblock 451 279 313 minecraft:magenta_stained_glass
fill 452 279 278 455 279 278 minecraft:black_stained_glass
setblock 452 279 279 minecraft:magenta_stained_glass
fill 452 279 283 455 279 283 minecraft:black_stained_glass
setblock 452 279 284 minecraft:magenta_stained_glass
fill 452 279 288 455 279 288 minecraft:black_stained_glass
setblock 452 279 289 minecraft:magenta_stained_glass
fill 452 279 293 455 279 293 minecraft:black_stained_glass
setblock 452 279 294 minecraft:magenta_stained_glass
fill 452 279 295 452 279 298 minecraft:black_stained_glass
setblock 452 279 299 minecraft:magenta_stained_glass
setblock 452 279 300 minecraft:black_stained_glass
fill 452 279 303 455 279 303 minecraft:black_stained_glass
setblock 452 279 304 minecraft:magenta_stained_glass
setblock 452 279 305 minecraft:black_stained_glass
fill 452 279 308 455 279 308 minecraft:black_stained_glass
setblock 452 279 309 minecraft:magenta_stained_glass
fill 452 279 313 455 279 313 minecraft:black_stained_glass
setblock 452 279 314 minecraft:magenta_stained_glass
fill 453 279 279 456 279 279 minecraft:black_stained_glass
setblock 453 279 280 minecraft:magenta_stained_glass
fill 453 279 284 456 279 284 minecraft:black_stained_glass
setblock 453 279 285 minecraft:magenta_stained_glass
fill 453 279 289 456 279 289 minecraft:black_stained_glass
setblock 453 279 290 minecraft:magenta_stained_glass
fill 453 279 294 456 279 294 minecraft:black_stained_glass
setblock 453 279 295 minecraft:magenta_stained_glass
fill 453 279 296 453 279 299 minecraft:black_stained_glass
setblock 453 279 300 minecraft:magenta_stained_glass
fill 453 279 304 456 279 304 minecraft:black_stained_glass
setblock 453 279 305 minecraft:magenta_stained_glass
fill 453 279 309 456 279 309 minecraft:black_stained_glass
setblock 453 279 310 minecraft:magenta_stained_glass
fill 453 279 314 456 279 314 minecraft:black_stained_glass
setblock 453 279 315 minecraft:magenta_stained_glass
setblock 454 279 276 minecraft:magenta_stained_glass
fill 454 279 280 457 279 280 minecraft:black_stained_glass
setblock 454 279 281 minecraft:magenta_stained_glass
fill 454 279 285 457 279 285 minecraft:black_stained_glass
setblock 454 279 286 minecraft:magenta_stained_glass
fill 454 279 290 457 279 290 minecraft:black_stained_glass
setblock 454 279 291 minecraft:magenta_stained_glass
fill 454 279 295 457 279 295 minecraft:black_stained_glass
setblock 454 279 296 minecraft:magenta_stained_glass
fill 454 279 297 454 279 300 minecraft:black_stained_glass
setblock 454 279 301 minecraft:magenta_stained_glass
setblock 454 279 302 minecraft:black_stained_glass
fill 454 279 305 457 279 305 minecraft:black_stained_glass
setblock 454 279 306 minecraft:magenta_stained_glass
fill 454 279 310 457 279 310 minecraft:black_stained_glass
setblock 454 279 311 minecraft:magenta_stained_glass
fill 454 279 315 457 279 315 minecraft:black_stained_glass
setblock 454 279 316 minecraft:magenta_stained_glass
fill 455 279 276 458 279 276 minecraft:black_stained_glass
setblock 455 279 277 minecraft:magenta_stained_glass
fill 455 279 281 458 279 281 minecraft:black_stained_glass
setblock 455 279 282 minecraft:magenta_stained_glass
fill 455 279 286 458 279 286 minecraft:black_stained_glass
setblock 455 279 287 minecraft:magenta_stained_glass
fill 455 279 291 458 279 291 minecraft:black_stained_glass
setblock 455 279 292 minecraft:magenta_stained_glass
fill 455 279 296 458 279 296 minecraft:black_stained_glass
setblock 455 279 297 minecraft:magenta_stained_glass
fill 455 279 298 455 279 301 minecraft:black_stained_glass
setblock 455 279 302 minecraft:magenta_stained_glass
fill 455 279 306 458 279 306 minecraft:black_stained_glass
setblock 455 279 307 minecraft:magenta_stained_glass
fill 455 279 311 458 279 311 minecraft:black_stained_glass
setblock 455 279 312 minecraft:magenta_stained_glass
fill 455 279 316 458 279 316 minecraft:black_stained_glass
fill 456 279 277 459 279 277 minecraft:black_stained_glass
setblock 456 279 278 minecraft:magenta_stained_glass
fill 456 279 282 459 279 282 minecraft:black_stained_glass
setblock 456 279 283 minecraft:magenta_stained_glass
fill 456 279 287 459 279 287 minecraft:black_stained_glass
setblock 456 279 288 minecraft:magenta_stained_glass
fill 456 279 292 459 279 292 minecraft:black_stained_glass
setblock 456 279 293 minecraft:magenta_stained_glass
fill 456 279 297 459 279 297 minecraft:black_stained_glass
setblock 456 279 298 minecraft:magenta_stained_glass
fill 456 279 299 456 279 302 minecraft:black_stained_glass
setblock 456 279 303 minecraft:magenta_stained_glass
fill 456 279 307 459 279 307 minecraft:black_stained_glass
setblock 456 279 308 minecraft:magenta_stained_glass
fill 456 279 312 459 279 312 minecraft:black_stained_glass
setblock 456 279 313 minecraft:magenta_stained_glass
fill 457 279 278 460 279 278 minecraft:black_stained_glass
setblock 457 279 279 minecraft:magenta_stained_glass
fill 457 279 283 460 279 283 minecraft:black_stained_glass
setblock 457 279 284 minecraft:magenta_stained_glass
fill 457 279 288 460 279 288 minecraft:black_stained_glass
setblock 457 279 289 minecraft:magenta_stained_glass
fill 457 279 293 460 279 293 minecraft:black_stained_glass
setblock 457 279 294 minecraft:magenta_stained_glass
fill 457 279 298 460 279 298 minecraft:black_stained_glass
setblock 457 279 299 minecraft:magenta_stained_glass
fill 457 279 300 457 279 303 minecraft:black_stained_glass
setblock 457 279 304 minecraft:magenta_stained_glass
fill 457 279 308 460 279 308 minecraft:black_stained_glass
setblock 457 279 309 minecraft:magenta_stained_glass
fill 457 279 313 460 279 313 minecraft:black_stained_glass
setblock 457 279 314 minecraft:magenta_stained_glass
fill 458 279 279 461 279 279 minecraft:black_stained_glass
setblock 458 279 280 minecraft:magenta_stained_glass
fill 458 279 284 461 279 284 minecraft:black_stained_glass
setblock 458 279 285 minecraft:magenta_stained_glass
fill 458 279 289 461 279 289 minecraft:black_stained_glass
setblock 458 279 290 minecraft:magenta_stained_glass
fill 458 279 294 461 279 294 minecraft:black_stained_glass
setblock 458 279 295 minecraft:magenta_stained_glass
fill 458 279 299 461 279 299 minecraft:black_stained_glass
setblock 458 279 300 minecraft:magenta_stained_glass
fill 458 279 301 458 279 304 minecraft:black_stained_glass
setblock 458 279 305 minecraft:magenta_stained_glass
fill 458 279 309 461 279 309 minecraft:black_stained_glass
setblock 458 279 310 minecraft:magenta_stained_glass
fill 458 279 314 461 279 314 minecraft:black_stained_glass
setblock 458 279 315 minecraft:magenta_stained_glass
setblock 459 279 276 minecraft:magenta_stained_glass
fill 459 279 280 462 279 280 minecraft:black_stained_glass
setblock 459 279 281 minecraft:magenta_stained_glass
fill 459 279 285 462 279 285 minecraft:black_stained_glass
setblock 459 279 286 minecraft:magenta_stained_glass
fill 459 279 290 462 279 290 minecraft:black_stained_glass
setblock 459 279 291 minecraft:magenta_stained_glass
fill 459 279 295 462 279 295 minecraft:black_stained_glass
setblock 459 279 296 minecraft:magenta_stained_glass
fill 459 279 300 462 279 300 minecraft:black_stained_glass
setblock 459 279 301 minecraft:magenta_stained_glass
fill 459 279 302 459 279 305 minecraft:black_stained_glass
setblock 459 279 306 minecraft:magenta_stained_glass
fill 459 279 310 462 279 310 minecraft:black_stained_glass
setblock 459 279 311 minecraft:magenta_stained_glass
fill 459 279 315 462 279 315 minecraft:black_stained_glass
setblock 459 279 316 minecraft:magenta_stained_glass
fill 460 279 276 463 279 276 minecraft:black_stained_glass
setblock 460 279 277 minecraft:magenta_stained_glass
fill 460 279 281 463 279 281 minecraft:black_stained_glass
setblock 460 279 282 minecraft:magenta_stained_glass
fill 460 279 286 463 279 286 minecraft:black_stained_glass
setblock 460 279 287 minecraft:magenta_stained_glass
fill 460 279 291 463 279 291 minecraft:black_stained_glass
setblock 460 279 292 minecraft:magenta_stained_glass
fill 460 279 296 463 279 296 minecraft:black_stained_glass
setblock 460 279 297 minecraft:magenta_stained_glass
fill 460 279 301 463 279 301 minecraft:black_stained_glass
setblock 460 279 302 minecraft:magenta_stained_glass
fill 460 279 303 460 279 306 minecraft:black_stained_glass
setblock 460 279 307 minecraft:magenta_stained_glass
fill 460 279 311 463 279 311 minecraft:black_stained_glass
setblock 460 279 312 minecraft:magenta_stained_glass
fill 460 279 316 463 279 316 minecraft:black_stained_glass
fill 461 279 277 464 279 277 minecraft:black_stained_glass
setblock 461 279 278 minecraft:magenta_stained_glass
fill 461 279 282 464 279 282 minecraft:black_stained_glass
setblock 461 279 283 minecraft:magenta_stained_glass
fill 461 279 287 464 279 287 minecraft:black_stained_glass
setblock 461 279 288 minecraft:magenta_stained_glass
fill 461 279 292 464 279 292 minecraft:black_stained_glass
setblock 461 279 293 minecraft:magenta_stained_glass
fill 461 279 297 464 279 297 minecraft:black_stained_glass
setblock 461 279 298 minecraft:magenta_stained_glass
fill 461 279 302 464 279 302 minecraft:black_stained_glass
setblock 461 279 303 minecraft:magenta_stained_glass
fill 461 279 304 461 279 307 minecraft:black_stained_glass
setblock 461 279 308 minecraft:magenta_stained_glass
fill 461 279 312 464 279 312 minecraft:black_stained_glass
setblock 461 279 313 minecraft:magenta_stained_glass
fill 462 279 278 464 279 278 minecraft:black_stained_glass
setblock 462 279 279 minecraft:magenta_stained_glass
fill 462 279 283 464 279 283 minecraft:black_stained_glass
setblock 462 279 284 minecraft:magenta_stained_glass
fill 462 279 288 464 279 288 minecraft:black_stained_glass
setblock 462 279 289 minecraft:magenta_stained_glass
fill 462 279 293 464 279 293 minecraft:black_stained_glass
setblock 462 279 294 minecraft:magenta_stained_glass
fill 462 279 298 464 279 298 minecraft:black_stained_glass
setblock 462 279 299 minecraft:magenta_stained_glass
fill 462 279 303 464 279 303 minecraft:black_stained_glass
setblock 462 279 304 minecraft:magenta_stained_glass
fill 462 279 305 462 279 308 minecraft:black_stained_glass
setblock 462 279 309 minecraft:magenta_stained_glass
fill 462 279 313 464 279 313 minecraft:black_stained_glass
setblock 462 279 314 minecraft:magenta_stained_glass
fill 463 279 279 464 279 279 minecraft:black_stained_glass
setblock 463 279 280 minecraft:magenta_stained_glass
fill 463 279 284 464 279 284 minecraft:black_stained_glass
setblock 463 279 285 minecraft:magenta_stained_glass
fill 463 279 289 464 279 289 minecraft:black_stained_glass
setblock 463 279 290 minecraft:magenta_stained_glass
fill 463 279 294 464 279 294 minecraft:black_stained_glass
setblock 463 279 295 minecraft:magenta_stained_glass
fill 463 279 299 464 279 299 minecraft:black_stained_glass
setblock 463 279 300 minecraft:magenta_stained_glass
fill 463 279 304 464 279 304 minecraft:black_stained_glass
setblock 463 279 305 minecraft:magenta_stained_glass
fill 463 279 306 463 279 309 minecraft:black_stained_glass
setblock 463 279 310 minecraft:magenta_stained_glass
fill 463 279 314 464 279 314 minecraft:black_stained_glass
setblock 463 279 315 minecraft:magenta_stained_glass
setblock 464 279 276 minecraft:magenta_stained_glass
setblock 464 279 280 minecraft:black_stained_glass
setblock 464 279 281 minecraft:magenta_stained_glass
setblock 464 279 285 minecraft:black_stained_glass
setblock 464 279 286 minecraft:magenta_stained_glass
setblock 464 279 290 minecraft:black_stained_glass
setblock 464 279 291 minecraft:magenta_stained_glass
setblock 464 279 295 minecraft:black_stained_glass
setblock 464 279 296 minecraft:magenta_stained_glass
setblock 464 279 300 minecraft:black_stained_glass
setblock 464 279 301 minecraft:magenta_stained_glass
setblock 464 279 305 minecraft:black_stained_glass
setblock 464 279 306 minecraft:magenta_stained_glass
fill 464 279 307 464 279 310 minecraft:black_stained_glass
setblock 464 279 311 minecraft:magenta_stained_glass
setblock 464 279 315 minecraft:black_stained_glass
setblock 464 279 316 minecraft:magenta_stained_glass
setblock 436 280 296 minecraft:white_concrete
setblock 436 280 297 minecraft:light_gray_concrete
setblock 436 280 298 minecraft:white_concrete
setblock 437 280 293 minecraft:white_concrete
setblock 437 280 295 minecraft:white_concrete
setblock 437 280 299 minecraft:white_concrete
setblock 437 280 301 minecraft:white_concrete
setblock 438 280 292 minecraft:white_concrete
setblock 438 280 302 minecraft:white_concrete
setblock 439 280 291 minecraft:white_concrete
fill 439 280 297 439 281 299 minecraft:light_gray_concrete
setblock 439 280 303 minecraft:white_concrete
fill 440 280 295 440 282 297 minecraft:light_gray_concrete
fill 440 280 299 440 281 301 minecraft:light_gray_concrete
setblock 441 280 290 minecraft:light_gray_concrete
fill 441 280 295 442 282 295 minecraft:light_gray_concrete
fill 441 280 301 442 281 301 minecraft:light_gray_concrete
setblock 441 280 304 minecraft:light_gray_concrete
setblock 442 280 290 minecraft:white_concrete
fill 442 280 294 444 282 294 minecraft:light_gray_concrete
fill 442 280 302 444 281 302 minecraft:light_gray_concrete
setblock 442 280 304 minecraft:white_concrete
setblock 444 280 290 minecraft:white_concrete
fill 444 280 295 446 282 295 minecraft:light_gray_concrete
fill 444 280 301 446 281 301 minecraft:light_gray_concrete
setblock 444 280 304 minecraft:white_concrete
setblock 446 280 290 minecraft:white_concrete
fill 446 280 296 446 282 297 minecraft:light_gray_concrete
fill 446 280 299 446 282 300 minecraft:light_gray_concrete
setblock 446 280 304 minecraft:white_concrete
setblock 447 280 291 minecraft:white_concrete
fill 447 280 297 447 282 299 minecraft:light_gray_concrete
setblock 447 280 303 minecraft:white_concrete
setblock 450 280 293 minecraft:light_gray_concrete
setblock 450 280 294 minecraft:white_concrete
setblock 450 280 300 minecraft:white_concrete
setblock 450 280 301 minecraft:sea_lantern
setblock 451 280 296 minecraft:light_gray_concrete
setblock 451 280 297 minecraft:white_concrete
setblock 451 280 298 minecraft:sea_lantern
setblock 437 281 295 minecraft:light_gray_concrete
setblock 437 281 296 minecraft:white_concrete
setblock 437 281 298 minecraft:white_concrete
setblock 437 281 299 minecraft:light_gray_concrete
setblock 438 281 293 minecraft:white_concrete
setblock 438 281 295 minecraft:white_concrete
setblock 438 281 299 minecraft:sea_lantern
setblock 438 281 301 minecraft:white_concrete
setblock 439 281 292 minecraft:white_concrete
setblock 439 281 302 minecraft:white_concrete
setblock 442 281 291 minecraft:white_concrete
setblock 442 281 303 minecraft:white_concrete
setblock 443 281 291 minecraft:light_gray_concrete
setblock 444 281 291 minecraft:white_concrete
setblock 444 281 303 minecraft:sea_lantern
setblock 445 281 291 minecraft:light_gray_concrete
setblock 446 281 291 minecraft:white_concrete
setblock 446 281 303 minecraft:white_concrete
setblock 447 281 292 minecraft:white_concrete
setblock 447 281 302 minecraft:white_concrete
setblock 448 281 293 minecraft:white_concrete
setblock 448 281 301 minecraft:white_concrete
setblock 448 281 302 minecraft:sea_lantern
setblock 449 281 294 minecraft:white_concrete
setblock 449 281 299 minecraft:sea_lantern
setblock 449 281 300 minecraft:white_concrete
setblock 450 281 295 minecraft:white_concrete
setblock 450 281 296 minecraft:sea_lantern
setblock 450 281 297 minecraft:white_concrete
setblock 450 281 299 minecraft:white_concrete
setblock 438 282 296 minecraft:white_concrete
setblock 438 282 298 minecraft:white_concrete
setblock 439 282 295 minecraft:white_concrete
setblock 439 282 297 minecraft:white_concrete
fill 439 282 298 441 282 298 minecraft:light_gray_concrete
setblock 439 282 299 minecraft:white_concrete
setblock 440 282 294 minecraft:white_concrete
fill 440 282 299 442 282 299 minecraft:light_gray_concrete
setblock 440 282 300 minecraft:white_concrete
setblock 440 282 301 minecraft:light_gray_concrete
setblock 441 282 293 minecraft:white_concrete
fill 441 282 296 442 282 297 minecraft:light_gray_concrete
fill 441 282 300 445 282 300 minecraft:light_gray_concrete
setblock 441 282 301 minecraft:white_concrete
setblock 442 282 292 minecraft:white_concrete
setblock 442 282 293 minecraft:sea_lantern
fill 442 282 301 444 282 301 minecraft:light_gray_concrete
setblock 442 282 302 minecraft:white_concrete
fill 443 282 295 443 282 296 minecraft:light_gray_concrete
setblock 443 282 302 minecraft:light_gray_concrete
setblock 444 282 292 minecraft:white_concrete
fill 444 282 296 445 282 297 minecraft:light_gray_concrete
fill 444 282 299 445 282 299 minecraft:light_gray_concrete
setblock 444 282 302 minecraft:white_concrete
setblock 445 282 292 minecraft:light_gray_concrete
setblock 445 282 293 minecraft:white_concrete
fill 445 282 298 446 282 298 minecraft:light_gray_concrete
setblock 445 282 301 minecraft:white_concrete
setblock 446 282 292 minecraft:sea_lantern
setblock 446 282 301 minecraft:light_gray_concrete
setblock 446 282 302 minecraft:white_concrete
setblock 447 282 293 minecraft:white_concrete
setblock 447 282 300 minecraft:sea_lantern
setblock 447 282 301 minecraft:white_concrete
setblock 448 282 294 minecraft:white_concrete
setblock 448 282 296 minecraft:white_concrete
setblock 448 282 297 minecraft:sea_lantern
setblock 448 282 298 minecraft:white_concrete
setblock 448 282 300 minecraft:white_concrete
setblock 449 282 297 minecraft:white_concrete
fill 423 283 281 423 283 284 minecraft:sea_lantern
fill 423 283 291 423 283 294 minecraft:sea_lantern
fill 423 283 301 423 283 304 minecraft:sea_lantern
fill 423 283 311 423 283 314 minecraft:sea_lantern
fill 424 283 277 424 300 277 minecraft:iron_block
fill 424 283 287 424 300 287 minecraft:iron_block
fill 424 283 297 424 300 297 minecraft:iron_block
fill 424 283 307 424 300 307 minecraft:iron_block
fill 425 283 316 425 300 316 minecraft:iron_block
fill 426 283 275 429 283 275 minecraft:sea_lantern
setblock 426 283 278 minecraft:light[level=12]
setblock 426 283 285 minecraft:light[level=12]
setblock 426 283 292 minecraft:light[level=12]
setblock 426 283 299 minecraft:light[level=12]
setblock 426 283 306 minecraft:light[level=12]
setblock 426 283 313 minecraft:light[level=12]
fill 427 283 317 430 283 317 minecraft:sea_lantern
fill 431 283 276 431 300 276 minecraft:iron_block
setblock 433 283 278 minecraft:light[level=12]
setblock 433 283 285 minecraft:light[level=12]
setblock 433 283 292 minecraft:light[level=12]
setblock 433 283 299 minecraft:light[level=12]
setblock 433 283 306 minecraft:light[level=12]
setblock 433 283 313 minecraft:light[level=12]
fill 435 283 316 435 300 316 minecraft:iron_block
fill 436 283 275 439 283 275 minecraft:sea_lantern
fill 437 283 317 440 283 317 minecraft:sea_lantern
setblock 440 283 278 minecraft:light[level=12]
setblock 440 283 285 minecraft:light[level=12]
setblock 440 283 292 minecraft:light[level=12]
setblock 440 283 295 minecraft:white_concrete
setblock 440 283 296 minecraft:light_gray_concrete
setblock 440 283 297 minecraft:white_concrete
setblock 440 283 298 minecraft:light_gray_concrete
setblock 440 283 299 minecraft:white_concrete
setblock 440 283 306 minecraft:light[level=12]
setblock 440 283 313 minecraft:light[level=12]
fill 441 283 276 441 300 276 minecraft:iron_block
setblock 441 283 294 minecraft:white_concrete
setblock 441 283 295 minecraft:light_gray_concrete
setblock 441 283 296 minecraft:white_concrete
setblock 441 283 297 minecraft:light_gray_concrete
setblock 441 283 298 minecraft:white_concrete
setblock 441 283 299 minecraft:light_gray_concrete
setblock 441 283 300 minecraft:white_concrete
setblock 442 283 294 minecraft:light_gray_concrete
setblock 442 283 295 minecraft:white_concrete
setblock 442 283 296 minecraft:light_gray_concrete
setblock 442 283 297 minecraft:white_concrete
setblock 442 283 299 minecraft:sea_lantern
setblock 442 283 300 minecraft:light_gray_concrete
setblock 443 283 294 minecraft:white_concrete
setblock 443 283 295 minecraft:light_gray_concrete
setblock 443 283 296 minecraft:sea_lantern
setblock 443 283 300 minecraft:white_concrete
setblock 443 283 301 minecraft:light_gray_concrete
setblock 444 283 293 minecraft:sea_lantern
setblock 444 283 294 minecraft:light_gray_concrete
setblock 444 283 295 minecraft:white_concrete
setblock 444 283 296 minecraft:light_gray_concrete
setblock 444 283 297 minecraft:white_concrete
setblock 444 283 299 minecraft:white_concrete
setblock 444 283 300 minecraft:light_gray_concrete
setblock 444 283 301 minecraft:white_concrete
setblock 445 283 294 minecraft:white_concrete
setblock 445 283 295 minecraft:light_gray_concrete
setblock 445 283 296 minecraft:white_concrete
setblock 445 283 297 minecraft:light_gray_concrete
setblock 445 283 298 minecraft:white_concrete
setblock 445 283 299 minecraft:light_gray_concrete
setblock 445 283 300 minecraft:white_concrete
fill 445 283 316 445 300 316 minecraft:iron_block
fill 446 283 275 449 283 275 minecraft:sea_lantern
setblock 446 283 295 minecraft:white_concrete
setblock 446 283 296 minecraft:light_gray_concrete
setblock 446 283 297 minecraft:white_concrete
setblock 446 283 298 minecraft:sea_lantern
setblock 446 283 299 minecraft:white_concrete
setblock 446 283 300 minecraft:light_gray_concrete
fill 446 283 307 448 284 307 minecraft:yellow_concrete
setblock 447 283 278 minecraft:light[level=12]
setblock 447 283 285 minecraft:light[level=12]
setblock 447 283 292 minecraft:light[level=12]
setblock 447 283 295 minecraft:sea_lantern
setblock 447 283 296 minecraft:white_concrete
setblock 447 283 297 minecraft:light_gray_concrete
setblock 447 283 298 minecraft:white_concrete
setblock 447 283 299 minecraft:light_gray_concrete
fill 447 283 306 447 284 306 minecraft:yellow_concrete
fill 447 283 308 447 284 308 minecraft:yellow_concrete
setblock 447 283 313 minecraft:light[level=12]
fill 447 283 317 450 283 317 minecraft:sea_lantern
fill 451 283 276 451 300 276 minecraft:iron_block
setblock 454 283 278 minecraft:light[level=12]
setblock 454 283 285 minecraft:light[level=12]
setblock 454 283 292 minecraft:light[level=12]
setblock 454 283 299 minecraft:light[level=12]
setblock 454 283 306 minecraft:light[level=12]
setblock 454 283 313 minecraft:light[level=12]
fill 455 283 316 455 300 316 minecraft:iron_block
fill 456 283 275 459 283 275 minecraft:sea_lantern
fill 457 283 317 460 283 317 minecraft:sea_lantern
fill 461 283 276 461 300 276 minecraft:iron_block
setblock 461 283 278 minecraft:light[level=12]
setblock 461 283 285 minecraft:light[level=12]
setblock 461 283 292 minecraft:light[level=12]
setblock 461 283 299 minecraft:light[level=12]
setblock 461 283 306 minecraft:light[level=12]
setblock 461 283 313 minecraft:light[level=12]
fill 464 283 283 464 300 283 minecraft:iron_block
fill 464 283 293 464 300 293 minecraft:iron_block
fill 464 283 303 464 300 303 minecraft:iron_block
fill 464 283 313 464 300 313 minecraft:iron_block
fill 465 283 276 465 283 279 minecraft:sea_lantern
fill 465 283 286 465 283 289 minecraft:sea_lantern
fill 465 283 296 465 283 299 minecraft:sea_lantern
fill 465 283 306 465 283 309 minecraft:sea_lantern
setblock 465 283 316 minecraft:sea_lantern
fill 423 284 281 423 291 284 minecraft:black_concrete
fill 423 284 291 423 291 294 minecraft:black_concrete
fill 423 284 301 423 291 304 minecraft:black_concrete
fill 423 284 311 423 291 314 minecraft:black_concrete
fill 426 284 275 429 291 275 minecraft:black_concrete
fill 427 284 317 430 291 317 minecraft:black_concrete
fill 436 284 275 439 291 275 minecraft:black_concrete
fill 437 284 317 440 291 317 minecraft:black_concrete
fill 446 284 275 449 291 275 minecraft:black_concrete
fill 447 284 317 450 291 317 minecraft:black_concrete
fill 456 284 275 459 291 275 minecraft:black_concrete
fill 457 284 317 460 291 317 minecraft:black_concrete
fill 465 284 276 465 291 279 minecraft:black_concrete
fill 465 284 286 465 291 289 minecraft:black_concrete
fill 465 284 296 465 291 299 minecraft:black_concrete
fill 465 284 306 465 291 309 minecraft:black_concrete
fill 465 284 316 465 291 316 minecraft:black_concrete
setblock 426 285 278 minecraft:light[level=15]
setblock 426 285 286 minecraft:light[level=15]
setblock 426 285 294 minecraft:light[level=15]
setblock 426 285 302 minecraft:light[level=15]
setblock 426 285 310 minecraft:light[level=15]
setblock 434 285 278 minecraft:light[level=15]
setblock 434 285 286 minecraft:light[level=15]
setblock 434 285 294 minecraft:light[level=15]
setblock 434 285 302 minecraft:light[level=15]
setblock 434 285 310 minecraft:light[level=15]
setblock 442 285 278 minecraft:light[level=15]
setblock 442 285 286 minecraft:light[level=15]
setblock 442 285 294 minecraft:light[level=15]
setblock 442 285 302 minecraft:light[level=15]
setblock 442 285 310 minecraft:light[level=15]
setblock 450 285 278 minecraft:light[level=15]
setblock 450 285 286 minecraft:light[level=15]
setblock 450 285 294 minecraft:light[level=15]
setblock 450 285 302 minecraft:light[level=15]
setblock 450 285 310 minecraft:light[level=15]
setblock 458 285 278 minecraft:light[level=15]
setblock 458 285 286 minecraft:light[level=15]
setblock 458 285 294 minecraft:light[level=15]
setblock 458 285 302 minecraft:light[level=15]
setblock 458 285 310 minecraft:light[level=15]
fill 426 287 294 427 288 298 minecraft:gray_concrete
fill 427 287 290 427 288 293 minecraft:gray_concrete
fill 427 287 299 427 288 302 minecraft:gray_concrete
fill 428 287 288 428 288 290 minecraft:gray_concrete
fill 428 287 302 428 288 304 minecraft:gray_concrete
fill 429 287 286 429 288 288 minecraft:gray_concrete
fill 429 287 304 429 288 306 minecraft:gray_concrete
fill 430 287 285 430 288 286 minecraft:gray_concrete
fill 430 287 306 430 288 307 minecraft:gray_concrete
fill 431 287 284 431 288 285 minecraft:gray_concrete
fill 431 287 307 431 288 308 minecraft:gray_concrete
fill 432 287 283 432 288 284 minecraft:gray_concrete
fill 432 287 308 432 288 309 minecraft:gray_concrete
fill 433 287 282 433 288 283 minecraft:gray_concrete
fill 433 287 309 433 288 310 minecraft:gray_concrete
fill 434 287 281 434 288 282 minecraft:gray_concrete
fill 434 287 310 434 288 311 minecraft:gray_concrete
fill 435 287 281 436 288 281 minecraft:gray_concrete
fill 435 287 311 436 288 311 minecraft:gray_concrete
fill 436 287 280 438 288 280 minecraft:gray_concrete
fill 436 287 312 438 288 312 minecraft:gray_concrete
fill 438 287 279 450 288 279 minecraft:gray_concrete
fill 438 287 313 450 288 313 minecraft:gray_concrete
fill 442 287 278 446 288 278 minecraft:gray_concrete
fill 442 287 314 446 288 314 minecraft:gray_concrete
fill 450 287 280 452 288 280 minecraft:gray_concrete
fill 450 287 312 452 288 312 minecraft:gray_concrete
fill 452 287 281 454 288 281 minecraft:gray_concrete
fill 452 287 311 454 288 311 minecraft:gray_concrete
fill 454 287 282 455 288 282 minecraft:gray_concrete
fill 454 287 310 455 288 310 minecraft:gray_concrete
fill 455 287 283 456 288 283 minecraft:gray_concrete
fill 455 287 309 456 288 309 minecraft:gray_concrete
fill 456 287 284 457 288 284 minecraft:gray_concrete
fill 456 287 308 457 288 308 minecraft:gray_concrete
fill 457 287 285 458 288 285 minecraft:gray_concrete
fill 457 287 307 458 288 307 minecraft:gray_concrete
fill 458 287 286 459 288 286 minecraft:gray_concrete
fill 458 287 306 459 288 306 minecraft:gray_concrete
fill 459 287 287 459 288 288 minecraft:gray_concrete
fill 459 287 304 459 288 305 minecraft:gray_concrete
fill 460 287 288 460 288 290 minecraft:gray_concrete
fill 460 287 302 460 288 304 minecraft:gray_concrete
fill 461 287 290 461 288 302 minecraft:gray_concrete
fill 462 287 294 462 288 298 minecraft:gray_concrete
setblock 424 288 278 minecraft:gray_concrete
fill 424 288 280 424 288 283 minecraft:gray_concrete
setblock 424 288 288 minecraft:gray_concrete
fill 424 288 290 424 288 293 minecraft:gray_concrete
fill 424 288 298 425 289 298 minecraft:gray_concrete
fill 424 288 300 424 288 303 minecraft:gray_concrete
setblock 424 288 308 minecraft:gray_concrete
fill 424 288 310 424 288 313 minecraft:gray_concrete
fill 425 288 276 428 288 276 minecraft:gray_concrete
fill 425 288 297 425 289 297 minecraft:gray_concrete
setblock 426 288 316 minecraft:gray_concrete
fill 428 288 297 432 289 298 minecraft:gray_concrete
fill 428 288 316 431 288 316 minecraft:gray_concrete
setblock 430 288 276 minecraft:gray_concrete
fill 433 288 298 439 289 298 minecraft:gray_concrete
fill 435 288 276 438 288 276 minecraft:gray_concrete
setblock 436 288 316 minecraft:gray_concrete
fill 437 288 299 439 289 299 minecraft:gray_concrete
fill 438 288 316 441 288 316 minecraft:gray_concrete
setblock 440 288 276 minecraft:gray_concrete
fill 445 288 276 448 288 276 minecraft:gray_concrete
setblock 446 288 316 minecraft:gray_concrete
fill 447 288 298 447 289 299 minecraft:gray_concrete
fill 448 288 299 460 289 299 minecraft:gray_concrete
fill 448 288 316 451 288 316 minecraft:gray_concrete
setblock 450 288 276 minecraft:gray_concrete
fill 450 288 301 451 289 302 minecraft:light_blue_concrete
fill 453 288 300 460 289 300 minecraft:gray_concrete
fill 455 288 276 458 288 276 minecraft:gray_concrete
setblock 456 288 316 minecraft:gray_concrete
fill 458 288 316 461 288 316 minecraft:gray_concrete
setblock 460 288 276 minecraft:gray_concrete
fill 462 288 299 464 288 300 minecraft:gray_concrete
fill 464 288 277 464 288 280 minecraft:gray_concrete
setblock 464 288 282 minecraft:gray_concrete
fill 464 288 287 464 288 290 minecraft:gray_concrete
setblock 464 288 292 minecraft:gray_concrete
fill 464 288 297 464 288 298 minecraft:gray_concrete
setblock 464 288 302 minecraft:gray_concrete
fill 464 288 307 464 288 310 minecraft:gray_concrete
setblock 464 288 312 minecraft:gray_concrete
setblock 426 289 278 minecraft:light[level=12]
setblock 426 289 285 minecraft:light[level=12]
setblock 426 289 292 minecraft:light[level=12]
fill 426 289 297 427 289 298 minecraft:gray_concrete
setblock 426 289 299 minecraft:light[level=12]
setblock 426 289 306 minecraft:light[level=12]
setblock 426 289 313 minecraft:light[level=12]
fill 427 289 289 427 289 291 minecraft:sea_lantern
fill 428 289 287 428 289 288 minecraft:sea_lantern
setblock 429 289 286 minecraft:sea_lantern
fill 430 289 284 430 289 285 minecraft:sea_lantern
fill 431 289 283 431 289 284 minecraft:sea_lantern
fill 432 289 282 432 289 283 minecraft:sea_lantern
setblock 433 289 278 minecraft:light[level=12]
setblock 433 289 282 minecraft:sea_lantern
setblock 433 289 285 minecraft:light[level=12]
setblock 433 289 292 minecraft:light[level=12]
setblock 433 289 299 minecraft:light[level=12]
setblock 433 289 306 minecraft:light[level=12]
setblock 433 289 313 minecraft:light[level=12]
setblock 434 289 281 minecraft:sea_lantern
fill 435 289 280 436 289 280 minecraft:sea_lantern
fill 437 289 279 439 289 279 minecraft:sea_lantern
fill 440 289 278 448 289 278 minecraft:sea_lantern
setblock 440 289 285 minecraft:light[level=12]
setblock 440 289 292 minecraft:light[level=12]
setblock 440 289 299 minecraft:light[level=12]
setblock 440 289 306 minecraft:light[level=12]
setblock 440 289 313 minecraft:light[level=12]
setblock 447 289 285 minecraft:light[level=12]
setblock 447 289 292 minecraft:light[level=12]
setblock 447 289 306 minecraft:light[level=12]
setblock 447 289 313 minecraft:light[level=12]
fill 449 289 279 451 289 279 minecraft:sea_lantern
fill 452 289 280 453 289 280 minecraft:sea_lantern
setblock 454 289 278 minecraft:light[level=12]
setblock 454 289 281 minecraft:sea_lantern
setblock 454 289 285 minecraft:light[level=12]
setblock 454 289 292 minecraft:light[level=12]
setblock 454 289 306 minecraft:light[level=12]
setblock 454 289 313 minecraft:light[level=12]
fill 461 289 277 461 290 278 minecraft:iron_block
setblock 461 289 285 minecraft:light[level=12]
setblock 461 289 292 minecraft:light[level=12]
fill 461 289 299 463 289 300 minecraft:gray_concrete
setblock 461 289 306 minecraft:light[level=12]
setblock 461 289 313 minecraft:light[level=12]
setblock 464 289 300 minecraft:gray_concrete
fill 425 290 297 427 290 297 minecraft:magenta_concrete
fill 426 290 298 439 290 298 minecraft:magenta_concrete
fill 428 290 309 428 291 309 minecraft:black_concrete
fill 428 290 311 428 291 311 minecraft:black_concrete
fill 445 290 311 445 291 311 minecraft:black_concrete
fill 447 290 280 447 291 280 minecraft:black_concrete
fill 447 290 299 458 290 299 minecraft:magenta_concrete
fill 450 290 311 450 291 311 minecraft:black_concrete
fill 454 290 280 454 291 280 minecraft:black_concrete
fill 458 290 300 464 290 300 minecraft:magenta_concrete
fill 459 290 303 459 291 303 minecraft:black_concrete
fill 427 291 309 427 292 309 minecraft:black_concrete
fill 428 291 312 428 292 312 minecraft:black_concrete
fill 433 291 276 433 292 278 minecraft:iron_block
fill 440 291 288 442 292 289 minecraft:yellow_concrete
fill 445 291 312 445 292 312 minecraft:black_concrete
fill 447 291 279 447 292 279 minecraft:black_concrete
fill 450 291 312 450 292 312 minecraft:black_concrete
fill 454 291 279 454 292 279 minecraft:black_concrete
fill 460 291 303 460 292 303 minecraft:black_concrete
fill 423 292 281 423 292 284 minecraft:sea_lantern
fill 423 292 291 423 292 294 minecraft:sea_lantern
fill 423 292 301 423 292 304 minecraft:sea_lantern
fill 423 292 311 423 292 314 minecraft:sea_lantern
fill 426 292 275 429 292 275 minecraft:sea_lantern
fill 426 292 309 426 293 309 minecraft:black_concrete
fill 427 292 317 430 292 317 minecraft:sea_lantern
fill 428 292 313 428 293 313 minecraft:black_concrete
fill 436 292 275 439 292 275 minecraft:sea_lantern
fill 437 292 317 440 292 317 minecraft:sea_lantern
fill 445 292 313 445 293 313 minecraft:black_concrete
fill 446 292 275 449 292 275 minecraft:sea_lantern
fill 447 292 278 447 293 278 minecraft:black_concrete
fill 447 292 317 450 292 317 minecraft:sea_lantern
fill 450 292 313 450 293 313 minecraft:black_concrete
fill 454 292 278 454 293 278 minecraft:black_concrete
fill 456 292 275 459 292 275 minecraft:sea_lantern
fill 457 292 299 457 293 300 minecraft:yellow_concrete
fill 457 292 317 460 292 317 minecraft:sea_lantern
fill 461 292 303 461 293 303 minecraft:black_concrete
fill 465 292 276 465 292 279 minecraft:sea_lantern
fill 465 292 286 465 292 289 minecraft:sea_lantern
fill 465 292 296 465 292 299 minecraft:sea_lantern
fill 465 292 306 465 292 309 minecraft:sea_lantern
setblock 465 292 316 minecraft:sea_lantern
fill 423 293 281 423 308 284 minecraft:black_concrete
fill 423 293 291 423 308 294 minecraft:black_concrete
fill 423 293 301 423 308 304 minecraft:black_concrete
fill 423 293 311 423 308 314 minecraft:black_concrete
fill 425 293 309 425 294 309 minecraft:black_concrete
fill 426 293 275 429 308 275 minecraft:black_concrete
setblock 426 293 278 minecraft:light[level=15]
setblock 426 293 286 minecraft:light[level=15]
setblock 426 293 294 minecraft:light[level=15]
setblock 426 293 302 minecraft:light[level=15]
setblock 426 293 310 minecraft:light[level=15]
fill 427 293 317 430 308 317 minecraft:black_concrete
fill 428 293 314 428 294 314 minecraft:black_concrete
setblock 434 293 278 minecraft:light[level=15]
setblock 434 293 286 minecraft:light[level=15]
setblock 434 293 294 minecraft:light[level=15]
setblock 434 293 302 minecraft:light[level=15]
setblock 434 293 310 minecraft:light[level=15]
fill 436 293 275 439 308 275 minecraft:black_concrete
fill 437 293 317 440 308 317 minecraft:black_concrete
setblock 442 293 278 minecraft:light[level=15]
setblock 442 293 286 minecraft:light[level=15]
setblock 442 293 294 minecraft:light[level=15]
setblock 442 293 302 minecraft:light[level=15]
setblock 442 293 310 minecraft:light[level=15]
fill 445 293 314 445 294 314 minecraft:black_concrete
fill 446 293 275 449 308 275 minecraft:black_concrete
fill 447 293 277 447 294 277 minecraft:black_concrete
fill 447 293 317 450 308 317 minecraft:black_concrete
setblock 450 293 278 minecraft:light[level=15]
setblock 450 293 286 minecraft:light[level=15]
setblock 450 293 294 minecraft:light[level=15]
setblock 450 293 302 minecraft:light[level=15]
setblock 450 293 310 minecraft:light[level=15]
fill 450 293 314 450 294 314 minecraft:black_concrete
fill 454 293 277 454 294 277 minecraft:black_concrete
fill 456 293 275 459 308 275 minecraft:black_concrete
fill 457 293 317 460 308 317 minecraft:black_concrete
setblock 458 293 278 minecraft:light[level=15]
setblock 458 293 286 minecraft:light[level=15]
setblock 458 293 294 minecraft:light[level=15]
setblock 458 293 302 minecraft:light[level=15]
setblock 458 293 310 minecraft:light[level=15]
fill 462 293 303 462 294 303 minecraft:black_concrete
fill 465 293 276 465 308 279 minecraft:black_concrete
fill 465 293 286 465 308 289 minecraft:black_concrete
fill 465 293 296 465 308 299 minecraft:black_concrete
fill 465 293 306 465 308 309 minecraft:black_concrete
fill 465 293 316 465 308 316 minecraft:black_concrete
setblock 424 294 278 minecraft:gray_concrete
setblock 424 294 288 minecraft:gray_concrete
setblock 424 294 298 minecraft:gray_concrete
setblock 424 294 308 minecraft:gray_concrete
fill 424 294 309 424 295 309 minecraft:black_concrete
setblock 426 294 316 minecraft:gray_concrete
fill 428 294 315 428 295 315 minecraft:black_concrete
setblock 430 294 276 minecraft:gray_concrete
setblock 436 294 316 minecraft:gray_concrete
setblock 440 294 276 minecraft:gray_concrete
fill 445 294 315 445 295 315 minecraft:black_concrete
setblock 446 294 316 minecraft:gray_concrete
fill 447 294 276 447 295 276 minecraft:black_concrete
setblock 450 294 276 minecraft:gray_concrete
fill 450 294 315 450 295 315 minecraft:black_concrete
fill 454 294 276 454 295 276 minecraft:black_concrete
setblock 456 294 316 minecraft:gray_concrete
setblock 460 294 276 minecraft:gray_concrete
fill 463 294 303 463 295 303 minecraft:black_concrete
setblock 464 294 282 minecraft:gray_concrete
setblock 464 294 292 minecraft:gray_concrete
setblock 464 294 302 minecraft:gray_concrete
setblock 464 294 312 minecraft:gray_concrete
setblock 426 295 278 minecraft:light[level=12]
setblock 426 295 285 minecraft:light[level=12]
setblock 426 295 292 minecraft:light[level=12]
setblock 426 295 299 minecraft:light[level=12]
setblock 426 295 306 minecraft:light[level=12]
setblock 426 295 313 minecraft:light[level=12]
setblock 428 295 282 minecraft:sea_lantern
setblock 428 295 288 minecraft:sea_lantern
setblock 428 295 294 minecraft:sea_lantern
setblock 428 295 300 minecraft:sea_lantern
setblock 428 295 306 minecraft:sea_lantern
setblock 428 295 312 minecraft:sea_lantern
setblock 430 295 280 minecraft:sea_lantern
setblock 433 295 278 minecraft:light[level=12]
setblock 433 295 285 minecraft:light[level=12]
setblock 433 295 292 minecraft:light[level=12]
setblock 433 295 299 minecraft:light[level=12]
setblock 433 295 306 minecraft:light[level=12]
setblock 433 295 313 minecraft:light[level=12]
setblock 434 295 312 minecraft:sea_lantern
setblock 436 295 280 minecraft:sea_lantern
setblock 440 295 278 minecraft:light[level=12]
setblock 440 295 285 minecraft:light[level=12]
setblock 440 295 292 minecraft:light[level=12]
setblock 440 295 299 minecraft:light[level=12]
setblock 440 295 306 minecraft:light[level=12]
setblock 440 295 312 minecraft:sea_lantern
setblock 440 295 313 minecraft:light[level=12]
setblock 442 295 280 minecraft:sea_lantern
setblock 446 295 312 minecraft:sea_lantern
setblock 447 295 278 minecraft:light[level=12]
setblock 447 295 285 minecraft:light[level=12]
setblock 447 295 292 minecraft:light[level=12]
setblock 447 295 299 minecraft:light[level=12]
setblock 447 295 306 minecraft:light[level=12]
setblock 447 295 313 minecraft:light[level=12]
setblock 448 295 280 minecraft:sea_lantern
setblock 452 295 312 minecraft:sea_lantern
setblock 454 295 278 minecraft:light[level=12]
setblock 454 295 280 minecraft:sea_lantern
setblock 454 295 285 minecraft:light[level=12]
setblock 454 295 292 minecraft:light[level=12]
setblock 454 295 299 minecraft:light[level=12]
setblock 454 295 306 minecraft:light[level=12]
setblock 454 295 313 minecraft:light[level=12]
setblock 458 295 312 minecraft:sea_lantern
setblock 460 295 280 minecraft:sea_lantern
setblock 460 295 286 minecraft:sea_lantern
setblock 460 295 292 minecraft:sea_lantern
setblock 460 295 298 minecraft:sea_lantern
setblock 460 295 304 minecraft:sea_lantern
setblock 460 295 310 minecraft:sea_lantern
setblock 461 295 278 minecraft:light[level=12]
setblock 461 295 285 minecraft:light[level=12]
setblock 461 295 292 minecraft:light[level=12]
setblock 461 295 299 minecraft:light[level=12]
setblock 461 295 306 minecraft:light[level=12]
setblock 461 295 313 minecraft:light[level=12]
setblock 424 296 276 minecraft:gray_concrete
fill 424 296 278 424 296 279 minecraft:gray_concrete
fill 424 296 281 426 296 283 minecraft:black_concrete
fill 424 296 284 424 296 285 minecraft:gray_concrete
setblock 424 296 288 minecraft:gray_concrete
fill 424 296 290 424 297 291 minecraft:gray_concrete
fill 424 296 293 424 296 294 minecraft:gray_concrete
fill 424 296 296 425 296 296 minecraft:gray_concrete
fill 424 296 299 424 296 300 minecraft:gray_concrete
fill 424 296 302 424 297 303 minecraft:gray_concrete
fill 424 296 305 424 296 306 minecraft:gray_concrete
fill 424 296 308 424 296 309 minecraft:gray_concrete
fill 424 296 311 424 297 312 minecraft:gray_concrete
fill 424 296 314 424 296 315 minecraft:gray_concrete
fill 425 296 277 425 296 278 minecraft:gray_concrete
fill 425 296 280 426 296 280 minecraft:gray_concrete
setblock 425 296 284 minecraft:gray_concrete
fill 425 296 286 425 296 287 minecraft:gray_concrete
fill 425 296 289 425 296 290 minecraft:gray_concrete
fill 425 296 292 425 296 293 minecraft:gray_concrete
fill 425 296 295 426 296 295 minecraft:gray_concrete
fill 425 296 298 425 296 299 minecraft:gray_concrete
fill 425 296 301 425 296 302 minecraft:gray_concrete
fill 425 296 304 425 296 305 minecraft:gray_concrete
fill 425 296 307 425 296 308 minecraft:gray_concrete
fill 425 296 310 425 296 311 minecraft:gray_concrete
fill 425 296 313 425 296 314 minecraft:gray_concrete
fill 426 296 276 426 296 277 minecraft:gray_concrete
fill 426 296 279 427 296 279 minecraft:gray_concrete
fill 426 296 285 426 296 286 minecraft:gray_concrete
fill 426 296 288 426 296 289 minecraft:gray_concrete
fill 426 296 291 426 296 292 minecraft:gray_concrete
fill 426 296 294 427 296 294 minecraft:gray_concrete
fill 426 296 297 426 296 298 minecraft:gray_concrete
fill 426 296 300 426 296 301 minecraft:gray_concrete
fill 426 296 303 426 296 304 minecraft:gray_concrete
fill 426 296 306 426 296 307 minecraft:gray_concrete
fill 426 296 309 426 296 310 minecraft:gray_concrete
fill 426 296 312 426 296 313 minecraft:gray_concrete
fill 426 296 315 426 296 316 minecraft:gray_concrete
fill 427 296 276 427 297 276 minecraft:gray_concrete
fill 427 296 278 428 296 278 minecraft:gray_concrete
fill 427 296 281 427 296 282 minecraft:gray_concrete
fill 427 296 284 427 296 285 minecraft:gray_concrete
fill 427 296 287 427 296 288 minecraft:gray_concrete
fill 427 296 290 427 296 291 minecraft:gray_concrete
fill 427 296 293 428 296 293 minecraft:gray_concrete
fill 427 296 296 427 296 297 minecraft:gray_concrete
fill 427 296 299 427 296 300 minecraft:gray_concrete
fill 427 296 302 427 296 303 minecraft:gray_concrete
fill 427 296 305 427 296 306 minecraft:gray_concrete
fill 427 296 308 427 296 309 minecraft:gray_concrete
fill 427 296 311 427 296 312 minecraft:gray_concrete
fill 427 296 314 427 296 315 minecraft:gray_concrete
fill 428 296 277 429 296 277 minecraft:gray_concrete
fill 428 296 280 428 296 281 minecraft:gray_concrete
fill 428 296 283 428 296 284 minecraft:gray_concrete
fill 428 296 286 428 296 287 minecraft:gray_concrete
fill 428 296 289 428 296 290 minecraft:gray_concrete
setblock 428 296 292 minecraft:gray_concrete
fill 428 296 295 428 296 296 minecraft:gray_concrete
fill 428 296 298 428 296 299 minecraft:gray_concrete
fill 428 296 301 428 296 302 minecraft:gray_concrete
fill 428 296 304 428 296 305 minecraft:gray_concrete
fill 428 296 307 428 296 308 minecraft:gray_concrete
fill 428 296 310 428 296 311 minecraft:gray_concrete
fill 428 296 313 428 296 314 minecraft:gray_concrete
fill 428 296 316 429 297 316 minecraft:gray_concrete
fill 429 296 276 430 296 276 minecraft:gray_concrete
fill 429 296 279 429 296 280 minecraft:gray_concrete
fill 429 296 312 429 296 313 minecraft:gray_concrete
fill 429 296 315 430 296 315 minecraft:gray_concrete
fill 430 296 278 430 296 279 minecraft:gray_concrete
setblock 430 296 312 minecraft:gray_concrete
fill 430 296 314 431 296 314 minecraft:gray_concrete
fill 431 296 277 431 296 278 minecraft:gray_concrete
fill 431 296 280 432 296 280 minecraft:gray_concrete
fill 431 296 313 432 296 313 minecraft:gray_concrete
fill 431 296 316 432 296 316 minecraft:gray_concrete
fill 432 296 276 432 296 277 minecraft:gray_concrete
fill 432 296 279 433 296 279 minecraft:gray_concrete
fill 432 296 312 433 296 312 minecraft:gray_concrete
fill 432 296 315 433 296 315 minecraft:gray_concrete
setblock 433 296 276 minecraft:gray_concrete
fill 433 296 278 434 296 278 minecraft:gray_concrete
fill 433 296 314 434 296 314 minecraft:gray_concrete
fill 434 296 277 435 296 277 minecraft:gray_concrete
fill 434 296 280 435 296 280 minecraft:gray_concrete
fill 434 296 313 435 296 313 minecraft:gray_concrete
setblock 434 296 316 minecraft:gray_concrete
fill 435 296 276 436 297 276 minecraft:gray_concrete
fill 435 296 279 436 296 279 minecraft:gray_concrete
fill 435 296 312 436 296 312 minecraft:gray_concrete
fill 435 296 315 436 296 315 minecraft:gray_concrete
fill 436 296 278 437 296 278 minecraft:gray_concrete
fill 436 296 314 437 296 314 minecraft:gray_concrete
fill 437 296 277 438 296 277 minecraft:gray_concrete
fill 437 296 280 438 296 280 minecraft:gray_concrete
fill 437 296 313 438 296 313 minecraft:gray_concrete
fill 437 296 316 438 296 316 minecraft:gray_concrete
fill 438 296 276 439 296 276 minecraft:gray_concrete
fill 438 296 279 439 296 279 minecraft:gray_concrete
fill 438 296 312 439 296 312 minecraft:gray_concrete
fill 438 296 315 439 296 315 minecraft:gray_concrete
fill 439 296 278 440 296 278 minecraft:gray_concrete
fill 439 296 314 440 296 314 minecraft:gray_concrete
fill 440 296 277 441 296 277 minecraft:gray_concrete
fill 440 296 280 441 296 280 minecraft:gray_concrete
fill 440 296 313 441 296 313 minecraft:gray_concrete
fill 440 296 316 441 297 316 minecraft:gray_concrete
fill 441 296 279 442 296 279 minecraft:gray_concrete
fill 441 296 312 442 296 312 minecraft:gray_concrete
fill 441 296 315 442 296 315 minecraft:gray_concrete
setblock 442 296 276 minecraft:gray_concrete
fill 442 296 278 443 296 278 minecraft:gray_concrete
fill 442 296 314 443 296 314 minecraft:gray_concrete
fill 443 296 277 444 296 277 minecraft:gray_concrete
fill 443 296 280 444 296 280 minecraft:gray_concrete
fill 443 296 313 444 296 313 minecraft:gray_concrete
fill 443 296 316 444 296 316 minecraft:gray_concrete
fill 444 296 276 445 296 276 minecraft:gray_concrete
fill 444 296 279 445 296 279 minecraft:gray_concrete
fill 444 296 312 445 296 312 minecraft:gray_concrete
fill 444 296 315 445 296 315 minecraft:gray_concrete
fill 445 296 278 446 296 278 minecraft:gray_concrete
fill 445 296 314 446 296 314 minecraft:gray_concrete
fill 446 296 277 447 296 277 minecraft:gray_concrete
fill 446 296 280 447 296 280 minecraft:gray_concrete
fill 446 296 313 447 296 313 minecraft:gray_concrete
fill 446 296 316 447 296 316 minecraft:gray_concrete
fill 447 296 276 448 297 276 minecraft:gray_concrete
fill 447 296 279 448 296 279 minecraft:gray_concrete
fill 447 296 312 448 296 312 minecraft:gray_concrete
fill 447 296 315 448 296 315 minecraft:gray_concrete
fill 448 296 278 449 296 278 minecraft:gray_concrete
fill 448 296 314 449 296 314 minecraft:gray_concrete
fill 449 296 277 450 296 277 minecraft:gray_concrete
fill 449 296 280 450 296 280 minecraft:gray_concrete
fill 449 296 313 450 296 313 minecraft:gray_concrete
fill 449 296 316 450 297 316 minecraft:gray_concrete
setblock 450 296 276 minecraft:gray_concrete
fill 450 296 279 451 296 279 minecraft:gray_concrete
fill 450 296 312 451 296 312 minecraft:gray_concrete
fill 450 296 315 451 296 315 minecraft:gray_concrete
fill 451 296 278 452 296 278 minecraft:gray_concrete
fill 451 296 314 452 296 314 minecraft:gray_concrete
fill 452 296 277 453 296 277 minecraft:gray_concrete
fill 452 296 280 453 296 280 minecraft:gray_concrete
fill 452 296 313 453 296 313 minecraft:gray_concrete
fill 452 296 316 453 296 316 minecraft:gray_concrete
fill 453 296 276 454 296 276 minecraft:gray_concrete
fill 453 296 279 454 296 279 minecraft:gray_concrete
fill 453 296 312 454 296 312 minecraft:gray_concrete
fill 453 296 315 454 296 315 minecraft:gray_concrete
fill 454 296 278 455 296 278 minecraft:gray_concrete
fill 454 296 314 455 296 314 minecraft:gray_concrete
fill 455 296 277 456 296 277 minecraft:gray_concrete
fill 455 296 280 456 296 280 minecraft:gray_concrete
fill 455 296 313 456 296 313 minecraft:gray_concrete
fill 456 296 276 457 297 276 minecraft:gray_concrete
fill 456 296 279 457 296 279 minecraft:gray_concrete
fill 456 296 312 457 296 312 minecraft:gray_concrete
fill 456 296 315 456 296 316 minecraft:gray_concrete
fill 457 296 278 458 296 278 minecraft:gray_concrete
fill 457 296 314 457 296 315 minecraft:gray_concrete
fill 458 296 277 459 296 277 minecraft:gray_concrete
fill 458 296 280 459 296 280 minecraft:gray_concrete
fill 458 296 313 458 296 314 minecraft:gray_concrete
fill 458 296 316 459 297 316 minecraft:gray_concrete
fill 459 296 276 460 296 276 minecraft:gray_concrete
fill 459 296 279 460 296 279 minecraft:gray_concrete
fill 459 296 312 459 296 313 minecraft:gray_concrete
fill 459 296 315 460 296 315 minecraft:gray_concrete
fill 460 296 278 461 296 278 minecraft:gray_concrete
fill 460 296 281 460 296 282 minecraft:gray_concrete
fill 460 296 284 460 296 285 minecraft:gray_concrete
fill 460 296 287 460 296 288 minecraft:gray_concrete
fill 460 296 290 460 296 291 minecraft:gray_concrete
fill 460 296 293 460 296 294 minecraft:gray_concrete
fill 460 296 296 460 296 297 minecraft:gray_concrete
fill 460 296 299 460 296 300 minecraft:gray_concrete
fill 460 296 302 460 296 303 minecraft:gray_concrete
fill 460 296 305 460 296 306 minecraft:gray_concrete
fill 460 296 308 460 296 309 minecraft:gray_concrete
fill 460 296 311 460 296 312 minecraft:gray_concrete
fill 460 296 314 461 296 314 minecraft:gray_concrete
fill 461 296 277 462 296 277 minecraft:gray_concrete
fill 461 296 280 461 296 281 minecraft:gray_concrete
fill 461 296 283 461 296 284 minecraft:gray_concrete
fill 461 296 286 461 296 287 minecraft:gray_concrete
fill 461 296 289 461 296 290 minecraft:gray_concrete
fill 461 296 292 461 296 293 minecraft:gray_concrete
fill 461 296 295 461 296 296 minecraft:gray_concrete
fill 461 296 298 461 296 299 minecraft:gray_concrete
fill 461 296 301 461 296 302 minecraft:gray_concrete
fill 461 296 304 461 296 305 minecraft:gray_concrete
fill 461 296 307 461 296 308 minecraft:gray_concrete
fill 461 296 310 461 296 311 minecraft:gray_concrete
fill 461 296 313 462 296 313 minecraft:gray_concrete
fill 461 296 316 462 296 316 minecraft:gray_concrete
fill 462 296 276 463 296 276 minecraft:gray_concrete
fill 462 296 279 462 296 280 minecraft:gray_concrete
fill 462 296 282 462 296 283 minecraft:gray_concrete
fill 462 296 285 462 296 286 minecraft:gray_concrete
fill 462 296 288 462 296 289 minecraft:gray_concrete
fill 462 296 291 462 296 292 minecraft:gray_concrete
fill 462 296 294 462 296 295 minecraft:gray_concrete
fill 462 296 297 462 296 298 minecraft:gray_concrete
fill 462 296 300 462 296 301 minecraft:gray_concrete
fill 462 296 303 462 296 304 minecraft:gray_concrete
fill 462 296 306 462 296 307 minecraft:gray_concrete
fill 462 296 309 462 296 310 minecraft:gray_concrete
fill 462 296 312 463 296 312 minecraft:gray_concrete
fill 462 296 315 463 296 315 minecraft:gray_concrete
fill 463 296 278 463 296 279 minecraft:gray_concrete
fill 463 296 281 463 296 282 minecraft:gray_concrete
fill 463 296 284 463 296 285 minecraft:gray_concrete
fill 463 296 287 463 296 288 minecraft:gray_concrete
fill 463 296 290 463 296 291 minecraft:gray_concrete
fill 463 296 293 463 296 294 minecraft:gray_concrete
fill 463 296 296 463 296 297 minecraft:gray_concrete
fill 463 296 299 463 296 300 minecraft:gray_concrete
fill 463 296 302 463 296 303 minecraft:gray_concrete
fill 463 296 305 463 296 306 minecraft:gray_concrete
fill 463 296 308 463 296 309 minecraft:gray_concrete
fill 463 296 311 464 296 311 minecraft:gray_concrete
fill 463 296 314 464 296 314 minecraft:gray_concrete
fill 464 296 277 464 297 278 minecraft:gray_concrete
fill 464 296 280 464 296 281 minecraft:gray_concrete
setblock 464 296 284 minecraft:gray_concrete
fill 464 296 286 464 296 287 minecraft:gray_concrete
fill 464 296 289 464 297 290 minecraft:gray_concrete
setblock 464 296 292 minecraft:gray_concrete
fill 464 296 295 464 296 296 minecraft:gray_concrete
fill 464 296 298 464 297 299 minecraft:gray_concrete
fill 464 296 301 464 296 302 minecraft:gray_concrete
fill 464 296 304 464 296 305 minecraft:gray_concrete
fill 464 296 307 464 297 308 minecraft:gray_concrete
fill 464 296 310 464 297 310 minecraft:gray_concrete
setblock 464 296 316 minecraft:gray_concrete
setblock 424 297 280 minecraft:gray_concrete
fill 424 297 281 424 297 283 minecraft:black_concrete
fill 424 297 292 424 297 293 minecraft:gray_concrete
fill 424 297 300 424 297 301 minecraft:gray_concrete
setblock 424 297 310 minecraft:gray_concrete
setblock 424 297 313 minecraft:gray_concrete
fill 425 297 276 426 297 276 minecraft:gray_concrete
fill 425 297 281 426 297 281 minecraft:black_concrete
fill 425 297 282 425 299 282 minecraft:gray_concrete
fill 425 297 283 426 297 283 minecraft:black_concrete
setblock 426 297 282 minecraft:black_concrete
setblock 428 297 276 minecraft:gray_concrete
fill 428 297 280 428 297 312 minecraft:magenta_concrete
fill 429 297 280 460 297 280 minecraft:magenta_concrete
fill 429 297 312 460 297 312 minecraft:magenta_concrete
fill 430 297 316 431 297 316 minecraft:gray_concrete
fill 437 297 276 438 297 276 minecraft:gray_concrete
fill 438 297 316 439 297 316 minecraft:gray_concrete
fill 445 297 276 446 297 276 minecraft:gray_concrete
setblock 448 297 316 minecraft:gray_concrete
setblock 451 297 316 minecraft:gray_concrete
setblock 455 297 276 minecraft:gray_concrete
setblock 458 297 276 minecraft:gray_concrete
fill 460 297 281 460 297 311 minecraft:magenta_concrete
schedule function dropper:buildpart/69_4 1t
