fill 252 191 568 258 192 568 minecraft:iron_block
fill 252 191 575 252 192 575 minecraft:light_gray_concrete
fill 252 191 576 252 192 576 minecraft:white_concrete
fill 252 191 580 252 192 580 minecraft:white_concrete
fill 252 191 581 252 192 581 minecraft:light_gray_concrete
fill 252 191 588 258 192 588 minecraft:iron_block
fill 252 191 590 258 192 590 minecraft:iron_block
setblock 252 191 599 minecraft:yellow_concrete
setblock 253 191 557 minecraft:yellow_concrete
fill 253 191 575 257 192 575 minecraft:white_concrete
fill 253 191 581 257 192 581 minecraft:white_concrete
fill 254 191 574 256 192 574 minecraft:white_concrete
setblock 254 191 577 minecraft:yellow_concrete
setblock 254 191 579 minecraft:yellow_concrete
fill 254 191 582 256 192 582 minecraft:white_concrete
fill 255 191 576 256 191 576 minecraft:yellow_concrete
fill 255 191 580 256 191 580 minecraft:yellow_concrete
fill 256 191 577 257 191 577 minecraft:yellow_concrete
fill 256 191 579 257 191 579 minecraft:yellow_concrete
setblock 257 191 578 minecraft:yellow_concrete
fill 258 191 569 260 192 569 minecraft:iron_block
fill 258 191 575 258 192 575 minecraft:light_gray_concrete
fill 258 191 576 258 192 580 minecraft:white_concrete
fill 258 191 581 258 192 581 minecraft:light_gray_concrete
fill 258 191 587 260 192 587 minecraft:iron_block
fill 259 191 567 260 192 567 minecraft:iron_block
fill 259 191 574 259 192 574 minecraft:light_gray_concrete
fill 259 191 577 259 192 579 minecraft:white_concrete
fill 259 191 582 259 192 582 minecraft:light_gray_concrete
fill 259 191 589 260 192 589 minecraft:iron_block
fill 260 191 573 260 192 573 minecraft:light_gray_concrete
fill 260 191 583 260 192 583 minecraft:light_gray_concrete
fill 261 191 568 262 192 568 minecraft:iron_block
fill 261 191 570 262 192 570 minecraft:iron_block
fill 261 191 572 261 192 572 minecraft:light_gray_concrete
fill 261 191 584 261 192 584 minecraft:light_gray_concrete
fill 261 191 586 262 192 586 minecraft:iron_block
fill 261 191 588 262 192 588 minecraft:iron_block
fill 262 191 571 262 192 571 minecraft:light_gray_concrete
fill 262 191 585 262 192 585 minecraft:light_gray_concrete
fill 263 191 569 263 192 569 minecraft:iron_block
fill 263 191 570 263 192 570 minecraft:light_gray_concrete
fill 263 191 572 263 192 572 minecraft:iron_block
fill 263 191 584 263 192 584 minecraft:iron_block
fill 263 191 586 263 192 586 minecraft:light_gray_concrete
fill 263 191 587 263 192 587 minecraft:iron_block
setblock 263 191 599 minecraft:yellow_concrete
setblock 264 191 557 minecraft:yellow_concrete
fill 264 191 570 264 192 570 minecraft:iron_block
fill 264 191 573 264 192 575 minecraft:iron_block
fill 264 191 581 264 192 583 minecraft:iron_block
fill 264 191 586 264 192 586 minecraft:iron_block
fill 265 191 557 265 193 557 minecraft:orange_terracotta
fill 265 191 571 265 192 572 minecraft:iron_block
fill 265 191 575 265 192 581 minecraft:iron_block
fill 265 191 584 265 192 585 minecraft:iron_block
fill 266 191 573 266 192 574 minecraft:iron_block
fill 266 191 582 266 192 583 minecraft:iron_block
fill 267 191 575 267 191 581 minecraft:iron_block
fill 267 191 599 268 194 599 minecraft:orange_terracotta
fill 269 191 557 269 193 557 minecraft:orange_terracotta
fill 277 191 560 277 194 560 minecraft:orange_terracotta
setblock 277 191 561 minecraft:yellow_concrete
setblock 277 191 565 minecraft:yellow_concrete
fill 277 191 581 277 194 581 minecraft:orange_terracotta
setblock 277 191 585 minecraft:yellow_concrete
fill 277 191 592 277 194 592 minecraft:orange_terracotta
setblock 277 191 593 minecraft:yellow_concrete
setblock 277 191 596 minecraft:yellow_concrete
fill 277 191 597 277 193 597 minecraft:orange_terracotta
setblock 235 192 561 minecraft:orange_terracotta
fill 235 192 562 235 193 562 minecraft:yellow_concrete
fill 235 192 564 235 197 564 minecraft:orange_terracotta
fill 235 192 565 235 192 566 minecraft:yellow_concrete
fill 235 192 567 235 197 567 minecraft:orange_terracotta
fill 235 192 573 235 193 574 minecraft:yellow_concrete
fill 235 192 575 235 197 576 minecraft:orange_terracotta
fill 235 192 585 235 192 586 minecraft:yellow_concrete
fill 235 192 587 235 197 588 minecraft:orange_terracotta
setblock 235 192 593 minecraft:orange_terracotta
fill 235 192 594 235 193 594 minecraft:yellow_concrete
fill 235 192 595 235 197 596 minecraft:orange_terracotta
setblock 235 192 597 minecraft:yellow_concrete
fill 235 192 598 235 195 599 minecraft:orange_terracotta
fill 236 192 558 238 192 558 minecraft:orange_concrete
fill 236 192 560 236 192 562 minecraft:orange_concrete
fill 236 192 564 236 192 566 minecraft:orange_concrete
fill 236 192 568 236 192 570 minecraft:orange_concrete
fill 236 192 572 236 192 574 minecraft:orange_concrete
fill 236 192 576 236 192 578 minecraft:orange_concrete
fill 236 192 580 236 192 582 minecraft:orange_concrete
fill 236 192 584 236 192 586 minecraft:orange_concrete
fill 236 192 588 236 192 590 minecraft:orange_concrete
fill 236 192 592 236 192 594 minecraft:orange_concrete
fill 236 192 596 236 192 598 minecraft:orange_concrete
fill 238 192 598 240 192 598 minecraft:orange_concrete
fill 239 192 575 243 192 581 minecraft:blue_stained_glass
fill 240 192 557 241 197 557 minecraft:orange_terracotta
fill 240 192 558 242 192 558 minecraft:orange_concrete
fill 241 192 599 242 193 599 minecraft:yellow_concrete
fill 242 192 557 243 192 557 minecraft:yellow_concrete
fill 242 192 598 244 192 598 minecraft:orange_concrete
fill 243 192 599 244 197 599 minecraft:orange_terracotta
fill 244 192 558 246 192 558 minecraft:orange_concrete
fill 246 192 598 248 192 598 minecraft:orange_concrete
fill 248 192 558 250 192 558 minecraft:orange_concrete
fill 250 192 598 252 192 598 minecraft:orange_concrete
fill 252 192 557 253 197 557 minecraft:orange_terracotta
fill 252 192 558 254 192 558 minecraft:orange_concrete
fill 252 192 599 252 197 599 minecraft:orange_terracotta
fill 253 192 599 254 192 599 minecraft:yellow_concrete
fill 254 192 557 255 193 557 minecraft:yellow_concrete
fill 254 192 598 256 192 598 minecraft:orange_concrete
fill 255 192 599 256 197 599 minecraft:orange_terracotta
fill 256 192 558 258 192 558 minecraft:orange_concrete
fill 258 192 598 260 192 598 minecraft:orange_concrete
fill 260 192 557 261 194 557 minecraft:orange_terracotta
fill 260 192 558 262 192 558 minecraft:orange_concrete
fill 261 192 599 262 193 599 minecraft:yellow_concrete
fill 262 192 557 263 192 557 minecraft:yellow_concrete
fill 262 192 598 264 192 598 minecraft:orange_concrete
fill 263 192 599 264 197 599 minecraft:orange_terracotta
fill 264 192 557 264 197 557 minecraft:orange_terracotta
fill 264 192 558 266 192 558 minecraft:orange_concrete
setblock 265 192 599 minecraft:yellow_concrete
fill 266 192 557 266 193 557 minecraft:yellow_concrete
fill 266 192 598 268 192 598 minecraft:orange_concrete
fill 266 192 599 266 195 599 minecraft:orange_terracotta
setblock 267 192 557 minecraft:orange_terracotta
fill 267 192 575 271 192 581 minecraft:blue_stained_glass
fill 268 192 558 270 192 558 minecraft:orange_concrete
fill 270 192 598 272 192 598 minecraft:orange_concrete
fill 272 192 557 273 197 557 minecraft:orange_terracotta
fill 272 192 558 274 192 558 minecraft:orange_concrete
fill 273 192 599 274 193 599 minecraft:yellow_concrete
fill 274 192 557 275 193 557 minecraft:yellow_concrete
fill 274 192 598 276 192 598 minecraft:orange_concrete
fill 275 192 599 276 197 599 minecraft:orange_terracotta
fill 276 192 558 276 192 560 minecraft:orange_concrete
fill 276 192 562 276 192 564 minecraft:orange_concrete
fill 276 192 566 276 192 568 minecraft:orange_concrete
fill 276 192 570 276 192 572 minecraft:orange_concrete
fill 276 192 574 276 192 576 minecraft:orange_concrete
fill 276 192 578 276 192 580 minecraft:orange_concrete
fill 276 192 582 276 192 584 minecraft:orange_concrete
fill 276 192 586 276 192 588 minecraft:orange_concrete
fill 276 192 590 276 192 592 minecraft:orange_concrete
fill 276 192 594 276 192 596 minecraft:orange_concrete
fill 277 192 561 277 194 562 minecraft:orange_terracotta
setblock 277 192 563 minecraft:yellow_concrete
fill 277 192 564 277 197 565 minecraft:orange_terracotta
fill 277 192 566 277 193 567 minecraft:yellow_concrete
fill 277 192 572 277 197 573 minecraft:orange_terracotta
fill 277 192 574 277 192 575 minecraft:yellow_concrete
fill 277 192 584 277 197 585 minecraft:orange_terracotta
fill 277 192 586 277 193 587 minecraft:yellow_concrete
fill 277 192 593 277 197 593 minecraft:orange_terracotta
fill 277 192 594 277 192 595 minecraft:yellow_concrete
fill 277 192 596 277 197 596 minecraft:orange_terracotta
fill 277 192 598 277 193 598 minecraft:yellow_concrete
setblock 235 193 561 minecraft:yellow_concrete
fill 235 193 565 235 196 566 minecraft:orange_terracotta
fill 235 193 581 235 195 581 minecraft:orange_terracotta
setblock 235 193 582 minecraft:yellow_concrete
setblock 235 193 585 minecraft:yellow_concrete
fill 235 193 586 235 196 586 minecraft:orange_terracotta
setblock 235 193 593 minecraft:yellow_concrete
fill 235 193 597 235 196 597 minecraft:orange_terracotta
fill 242 193 557 242 196 557 minecraft:orange_terracotta
setblock 243 193 557 minecraft:yellow_concrete
setblock 246 193 557 minecraft:yellow_concrete
fill 247 193 557 247 195 557 minecraft:orange_terracotta
fill 247 193 570 247 193 571 minecraft:iron_block
fill 247 193 585 247 193 586 minecraft:iron_block
fill 249 193 599 250 193 599 minecraft:yellow_concrete
setblock 253 193 599 minecraft:yellow_concrete
fill 254 193 599 254 196 599 minecraft:orange_terracotta
fill 262 193 557 262 196 557 minecraft:orange_terracotta
fill 262 193 570 263 193 570 minecraft:iron_block
fill 262 193 586 263 193 586 minecraft:iron_block
setblock 263 193 557 minecraft:yellow_concrete
fill 265 193 599 265 196 599 minecraft:orange_terracotta
setblock 267 193 557 minecraft:yellow_concrete
fill 269 193 599 269 195 599 minecraft:orange_terracotta
setblock 270 193 599 minecraft:yellow_concrete
setblock 277 193 558 minecraft:yellow_concrete
fill 277 193 559 277 195 559 minecraft:orange_terracotta
fill 277 193 563 277 196 563 minecraft:orange_terracotta
fill 277 193 574 277 196 574 minecraft:orange_terracotta
setblock 277 193 575 minecraft:yellow_concrete
setblock 277 193 578 minecraft:yellow_concrete
fill 277 193 579 277 195 579 minecraft:orange_terracotta
fill 277 193 594 277 196 595 minecraft:orange_terracotta
fill 235 194 559 235 195 560 minecraft:yellow_concrete
fill 235 194 561 235 199 562 minecraft:orange_terracotta
setblock 235 194 563 minecraft:yellow_concrete
fill 235 194 571 235 195 572 minecraft:yellow_concrete
fill 235 194 573 235 199 574 minecraft:orange_terracotta
fill 235 194 580 235 195 580 minecraft:yellow_concrete
fill 235 194 582 235 199 582 minecraft:orange_terracotta
fill 235 194 583 235 194 584 minecraft:yellow_concrete
fill 235 194 585 235 199 585 minecraft:orange_terracotta
fill 235 194 591 235 195 592 minecraft:yellow_concrete
fill 235 194 593 235 199 594 minecraft:orange_terracotta
fill 236 194 557 237 195 557 minecraft:yellow_concrete
setblock 238 194 560 minecraft:light[level=14]
setblock 238 194 568 minecraft:light[level=14]
setblock 238 194 576 minecraft:light[level=14]
setblock 238 194 584 minecraft:light[level=14]
setblock 238 194 592 minecraft:light[level=14]
fill 239 194 599 240 194 599 minecraft:yellow_concrete
fill 241 194 599 242 199 599 minecraft:orange_terracotta
fill 243 194 557 243 199 557 minecraft:orange_terracotta
fill 244 194 557 245 194 557 minecraft:yellow_concrete
fill 246 194 557 246 199 557 minecraft:orange_terracotta
setblock 246 194 560 minecraft:light[level=14]
setblock 246 194 568 minecraft:light[level=14]
setblock 246 194 576 minecraft:light[level=14]
setblock 246 194 584 minecraft:light[level=14]
setblock 246 194 592 minecraft:light[level=14]
fill 248 194 557 248 195 557 minecraft:yellow_concrete
fill 248 194 599 248 195 599 minecraft:yellow_concrete
fill 249 194 599 250 199 599 minecraft:orange_terracotta
setblock 251 194 599 minecraft:yellow_concrete
fill 253 194 599 253 199 599 minecraft:orange_terracotta
fill 254 194 557 255 199 557 minecraft:orange_terracotta
setblock 254 194 560 minecraft:light[level=14]
setblock 254 194 568 minecraft:light[level=14]
setblock 254 194 576 minecraft:light[level=14]
setblock 254 194 584 minecraft:light[level=14]
setblock 254 194 592 minecraft:light[level=14]
fill 256 194 557 257 195 557 minecraft:yellow_concrete
fill 259 194 599 260 195 599 minecraft:yellow_concrete
fill 261 194 599 262 199 599 minecraft:orange_terracotta
setblock 262 194 560 minecraft:light[level=14]
setblock 262 194 568 minecraft:light[level=14]
setblock 262 194 576 minecraft:light[level=14]
setblock 262 194 584 minecraft:light[level=14]
setblock 262 194 592 minecraft:light[level=14]
fill 263 194 557 263 196 557 minecraft:orange_terracotta
setblock 265 194 557 minecraft:yellow_concrete
fill 266 194 557 267 199 557 minecraft:orange_terracotta
fill 268 194 557 269 195 557 minecraft:yellow_concrete
setblock 270 194 560 minecraft:light[level=14]
setblock 270 194 568 minecraft:light[level=14]
setblock 270 194 576 minecraft:light[level=14]
setblock 270 194 584 minecraft:light[level=14]
setblock 270 194 592 minecraft:light[level=14]
fill 270 194 599 270 199 599 minecraft:orange_terracotta
fill 271 194 599 272 194 599 minecraft:yellow_concrete
fill 273 194 599 274 199 599 minecraft:orange_terracotta
fill 274 194 557 275 199 557 minecraft:orange_terracotta
fill 276 194 557 277 194 557 minecraft:yellow_concrete
fill 277 194 558 277 195 558 minecraft:orange_terracotta
fill 277 194 566 277 199 567 minecraft:orange_terracotta
fill 277 194 568 277 195 569 minecraft:yellow_concrete
fill 277 194 575 277 199 575 minecraft:orange_terracotta
fill 277 194 576 277 194 577 minecraft:yellow_concrete
fill 277 194 578 277 199 578 minecraft:orange_terracotta
fill 277 194 580 277 195 580 minecraft:yellow_concrete
fill 277 194 586 277 199 587 minecraft:orange_terracotta
fill 277 194 588 277 195 589 minecraft:yellow_concrete
setblock 277 194 597 minecraft:yellow_concrete
fill 277 194 598 277 199 598 minecraft:orange_terracotta
fill 235 195 563 235 198 563 minecraft:orange_terracotta
setblock 235 195 568 minecraft:yellow_concrete
setblock 235 195 579 minecraft:yellow_concrete
fill 235 195 583 235 198 584 minecraft:orange_terracotta
setblock 236 195 599 minecraft:yellow_concrete
setblock 239 195 599 minecraft:yellow_concrete
fill 240 195 599 240 198 599 minecraft:orange_terracotta
fill 244 195 557 245 198 557 minecraft:orange_terracotta
setblock 247 195 599 minecraft:yellow_concrete
setblock 249 195 557 minecraft:yellow_concrete
fill 251 195 599 251 198 599 minecraft:orange_terracotta
setblock 260 195 557 minecraft:yellow_concrete
fill 261 195 557 261 197 557 minecraft:orange_terracotta
fill 265 195 557 265 198 557 minecraft:orange_terracotta
fill 267 195 599 268 195 599 minecraft:yellow_concrete
setblock 271 195 599 minecraft:yellow_concrete
fill 272 195 599 272 198 599 minecraft:orange_terracotta
fill 276 195 557 276 198 557 minecraft:orange_terracotta
setblock 277 195 557 minecraft:yellow_concrete
fill 277 195 560 277 195 561 minecraft:yellow_concrete
setblock 277 195 562 minecraft:orange_terracotta
fill 277 195 576 277 197 577 minecraft:orange_terracotta
setblock 277 195 581 minecraft:yellow_concrete
setblock 277 195 592 minecraft:yellow_concrete
fill 277 195 597 277 198 597 minecraft:orange_terracotta
fill 235 196 557 235 197 558 minecraft:yellow_concrete
fill 235 196 559 235 201 560 minecraft:orange_terracotta
fill 235 196 568 235 201 568 minecraft:orange_terracotta
fill 235 196 569 235 196 570 minecraft:yellow_concrete
fill 235 196 571 235 201 572 minecraft:orange_terracotta
fill 235 196 577 235 197 578 minecraft:yellow_concrete
fill 235 196 579 235 201 580 minecraft:orange_terracotta
setblock 235 196 581 minecraft:yellow_concrete
fill 235 196 589 235 197 590 minecraft:yellow_concrete
fill 235 196 591 235 201 592 minecraft:orange_terracotta
fill 235 196 598 235 197 598 minecraft:yellow_concrete
fill 235 196 599 236 197 599 minecraft:orange_terracotta
fill 236 196 557 237 201 557 minecraft:orange_terracotta
fill 237 196 599 238 196 599 minecraft:yellow_concrete
fill 238 196 557 239 197 557 minecraft:yellow_concrete
fill 239 196 599 239 201 599 minecraft:orange_terracotta
fill 245 196 599 246 197 599 minecraft:yellow_concrete
setblock 247 196 557 minecraft:yellow_concrete
fill 247 196 599 248 201 599 minecraft:orange_terracotta
fill 248 196 557 249 201 557 minecraft:orange_terracotta
fill 250 196 557 251 197 557 minecraft:yellow_concrete
fill 256 196 557 257 201 557 minecraft:orange_terracotta
fill 257 196 599 258 196 599 minecraft:yellow_concrete
fill 258 196 557 259 196 557 minecraft:yellow_concrete
fill 259 196 599 260 201 599 minecraft:orange_terracotta
fill 260 196 557 260 201 557 minecraft:orange_terracotta
fill 266 196 599 266 197 599 minecraft:yellow_concrete
fill 267 196 599 268 201 599 minecraft:orange_terracotta
fill 268 196 557 269 201 557 minecraft:orange_terracotta
setblock 269 196 599 minecraft:yellow_concrete
fill 270 196 557 271 197 557 minecraft:yellow_concrete
fill 271 196 599 271 201 599 minecraft:orange_terracotta
fill 277 196 557 277 201 557 minecraft:orange_terracotta
fill 277 196 558 277 196 559 minecraft:yellow_concrete
fill 277 196 560 277 197 561 minecraft:orange_terracotta
fill 277 196 562 277 197 562 minecraft:yellow_concrete
fill 277 196 568 277 201 569 minecraft:orange_terracotta
fill 277 196 570 277 197 571 minecraft:yellow_concrete
setblock 277 196 579 minecraft:yellow_concrete
fill 277 196 580 277 201 581 minecraft:orange_terracotta
fill 277 196 582 277 197 583 minecraft:yellow_concrete
fill 277 196 588 277 201 589 minecraft:orange_terracotta
fill 277 196 590 277 196 591 minecraft:yellow_concrete
fill 277 196 592 277 201 592 minecraft:orange_terracotta
fill 277 196 599 277 197 599 minecraft:yellow_concrete
fill 235 197 565 235 197 566 minecraft:yellow_concrete
setblock 235 197 569 minecraft:yellow_concrete
fill 235 197 570 235 200 570 minecraft:orange_terracotta
fill 235 197 581 235 200 581 minecraft:orange_terracotta
setblock 235 197 586 minecraft:yellow_concrete
setblock 235 197 597 minecraft:yellow_concrete
fill 237 197 599 238 200 599 minecraft:orange_terracotta
setblock 242 197 557 minecraft:yellow_concrete
fill 247 197 557 247 200 557 minecraft:orange_terracotta
fill 253 197 563 254 198 564 minecraft:shroomlight
setblock 254 197 599 minecraft:yellow_concrete
setblock 257 197 599 minecraft:yellow_concrete
fill 258 197 557 258 200 557 minecraft:orange_terracotta
fill 258 197 599 258 200 599 minecraft:orange_terracotta
setblock 259 197 557 minecraft:yellow_concrete
fill 262 197 557 263 197 557 minecraft:yellow_concrete
setblock 265 197 599 minecraft:yellow_concrete
fill 269 197 599 269 200 599 minecraft:orange_terracotta
fill 277 197 558 277 199 559 minecraft:orange_terracotta
setblock 277 197 563 minecraft:yellow_concrete
setblock 277 197 574 minecraft:yellow_concrete
fill 277 197 579 277 199 579 minecraft:orange_terracotta
fill 277 197 590 277 200 590 minecraft:orange_terracotta
setblock 277 197 591 minecraft:yellow_concrete
fill 277 197 594 277 197 595 minecraft:yellow_concrete
fill 235 198 557 235 203 558 minecraft:orange_terracotta
fill 235 198 564 235 199 564 minecraft:yellow_concrete
fill 235 198 565 235 203 566 minecraft:orange_terracotta
setblock 235 198 567 minecraft:yellow_concrete
fill 235 198 569 235 203 569 minecraft:orange_terracotta
fill 235 198 575 235 199 576 minecraft:yellow_concrete
fill 235 198 577 235 203 578 minecraft:orange_terracotta
fill 235 198 586 235 203 586 minecraft:orange_terracotta
fill 235 198 587 235 198 588 minecraft:yellow_concrete
fill 235 198 589 235 203 590 minecraft:orange_terracotta
fill 235 198 595 235 199 596 minecraft:yellow_concrete
fill 235 198 597 235 203 598 minecraft:orange_terracotta
setblock 235 198 599 minecraft:yellow_concrete
fill 236 198 558 238 198 558 minecraft:orange_concrete
fill 236 198 560 236 198 562 minecraft:orange_concrete
fill 236 198 564 236 198 566 minecraft:orange_concrete
fill 236 198 568 236 198 570 minecraft:orange_concrete
fill 236 198 572 236 198 574 minecraft:orange_concrete
fill 236 198 576 236 198 578 minecraft:orange_concrete
fill 236 198 580 236 198 582 minecraft:orange_concrete
fill 236 198 584 236 198 586 minecraft:orange_concrete
fill 236 198 588 236 198 590 minecraft:orange_concrete
fill 236 198 592 236 198 594 minecraft:orange_concrete
fill 236 198 596 236 198 598 minecraft:orange_concrete
fill 236 198 599 236 201 599 minecraft:orange_terracotta
fill 238 198 557 239 203 557 minecraft:orange_terracotta
fill 238 198 598 240 198 598 minecraft:orange_concrete
fill 240 198 557 241 198 557 minecraft:yellow_concrete
fill 240 198 558 242 198 558 minecraft:orange_concrete
fill 242 198 557 242 203 557 minecraft:orange_terracotta
fill 242 198 598 244 198 598 minecraft:orange_concrete
fill 243 198 599 244 199 599 minecraft:yellow_concrete
fill 244 198 558 246 198 558 minecraft:orange_concrete
fill 245 198 599 246 203 599 minecraft:orange_terracotta
fill 246 198 598 248 198 598 minecraft:orange_concrete
fill 248 198 558 250 198 558 minecraft:orange_concrete
fill 250 198 557 251 203 557 minecraft:orange_terracotta
fill 250 198 598 252 198 598 minecraft:orange_concrete
fill 252 198 557 253 199 557 minecraft:yellow_concrete
fill 252 198 558 254 198 558 minecraft:orange_concrete
fill 252 198 599 252 199 599 minecraft:yellow_concrete
fill 254 198 598 256 198 598 minecraft:orange_concrete
fill 254 198 599 254 203 599 minecraft:orange_terracotta
fill 255 198 599 256 198 599 minecraft:yellow_concrete
fill 256 198 558 258 198 558 minecraft:orange_concrete
fill 257 198 599 257 203 599 minecraft:orange_terracotta
fill 258 198 598 260 198 598 minecraft:orange_concrete
fill 259 198 557 259 203 557 minecraft:orange_terracotta
fill 260 198 558 262 198 558 minecraft:orange_concrete
setblock 261 198 557 minecraft:yellow_concrete
fill 262 198 557 263 203 557 minecraft:orange_terracotta
fill 262 198 598 264 198 598 minecraft:orange_concrete
fill 263 198 599 264 199 599 minecraft:yellow_concrete
fill 264 198 557 264 199 557 minecraft:yellow_concrete
fill 264 198 558 266 198 558 minecraft:orange_concrete
fill 265 198 599 266 203 599 minecraft:orange_terracotta
fill 266 198 598 268 198 598 minecraft:orange_concrete
fill 268 198 558 270 198 558 minecraft:orange_concrete
fill 270 198 557 271 203 557 minecraft:orange_terracotta
fill 270 198 598 272 198 598 minecraft:orange_concrete
fill 272 198 557 273 199 557 minecraft:yellow_concrete
fill 272 198 558 274 198 558 minecraft:orange_concrete
fill 274 198 598 276 198 598 minecraft:orange_concrete
fill 275 198 599 276 198 599 minecraft:yellow_concrete
fill 276 198 558 276 198 560 minecraft:orange_concrete
fill 276 198 562 276 198 564 minecraft:orange_concrete
fill 276 198 566 276 198 568 minecraft:orange_concrete
fill 276 198 570 276 198 572 minecraft:orange_concrete
fill 276 198 574 276 198 576 minecraft:orange_concrete
fill 276 198 578 276 198 580 minecraft:orange_concrete
fill 276 198 582 276 198 584 minecraft:orange_concrete
fill 276 198 586 276 198 588 minecraft:orange_concrete
fill 276 198 590 276 198 592 minecraft:orange_concrete
fill 276 198 594 276 198 596 minecraft:orange_concrete
fill 277 198 560 277 201 560 minecraft:orange_terracotta
setblock 277 198 561 minecraft:yellow_concrete
fill 277 198 562 277 203 563 minecraft:orange_terracotta
fill 277 198 564 277 199 565 minecraft:yellow_concrete
fill 277 198 570 277 200 571 minecraft:orange_terracotta
fill 277 198 572 277 198 573 minecraft:yellow_concrete
fill 277 198 574 277 203 574 minecraft:orange_terracotta
fill 277 198 576 277 199 576 minecraft:yellow_concrete
setblock 277 198 577 minecraft:orange_terracotta
fill 277 198 582 277 203 583 minecraft:orange_terracotta
fill 277 198 584 277 199 585 minecraft:yellow_concrete
fill 277 198 591 277 203 591 minecraft:orange_terracotta
setblock 277 198 593 minecraft:yellow_concrete
fill 277 198 594 277 203 595 minecraft:orange_terracotta
fill 277 198 596 277 199 596 minecraft:yellow_concrete
fill 277 198 599 277 203 599 minecraft:orange_terracotta
setblock 235 199 563 minecraft:yellow_concrete
fill 235 199 567 235 202 567 minecraft:orange_terracotta
fill 235 199 583 235 199 584 minecraft:yellow_concrete
setblock 235 199 587 minecraft:yellow_concrete
fill 235 199 588 235 202 588 minecraft:orange_terracotta
fill 235 199 599 235 202 599 minecraft:orange_terracotta
fill 240 199 557 240 202 557 minecraft:orange_terracotta
setblock 240 199 599 minecraft:yellow_concrete
setblock 241 199 557 minecraft:yellow_concrete
fill 244 199 557 245 199 557 minecraft:yellow_concrete
setblock 251 199 599 minecraft:yellow_concrete
fill 255 199 599 256 202 599 minecraft:orange_terracotta
fill 261 199 557 261 202 557 minecraft:orange_terracotta
setblock 265 199 557 minecraft:yellow_concrete
setblock 272 199 599 minecraft:yellow_concrete
setblock 275 199 599 minecraft:yellow_concrete
setblock 276 199 557 minecraft:yellow_concrete
fill 276 199 599 276 202 599 minecraft:orange_terracotta
fill 277 199 561 277 201 561 minecraft:orange_terracotta
fill 277 199 572 277 202 572 minecraft:orange_terracotta
setblock 277 199 573 minecraft:yellow_concrete
setblock 277 199 577 minecraft:yellow_concrete
fill 277 199 593 277 202 593 minecraft:orange_terracotta
setblock 277 199 597 minecraft:yellow_concrete
fill 235 200 561 235 201 562 minecraft:yellow_concrete
fill 235 200 563 235 205 564 minecraft:orange_terracotta
fill 235 200 573 235 200 574 minecraft:yellow_concrete
fill 235 200 575 235 205 576 minecraft:orange_terracotta
fill 235 200 582 235 201 582 minecraft:yellow_concrete
fill 235 200 583 235 205 584 minecraft:orange_terracotta
setblock 235 200 585 minecraft:yellow_concrete
fill 235 200 587 235 205 587 minecraft:orange_terracotta
fill 235 200 593 235 201 594 minecraft:yellow_concrete
fill 235 200 595 235 205 596 minecraft:orange_terracotta
fill 240 200 599 240 205 599 minecraft:orange_terracotta
fill 241 200 557 241 205 557 minecraft:orange_terracotta
fill 241 200 599 242 200 599 minecraft:yellow_concrete
setblock 243 200 557 minecraft:yellow_concrete
fill 243 200 599 244 205 599 minecraft:orange_terracotta
fill 244 200 557 245 205 557 minecraft:orange_terracotta
fill 246 200 557 246 201 557 minecraft:yellow_concrete
fill 249 200 599 250 201 599 minecraft:yellow_concrete
fill 251 200 599 252 205 599 minecraft:orange_terracotta
fill 252 200 557 253 205 557 minecraft:orange_terracotta
setblock 253 200 599 minecraft:yellow_concrete
fill 254 200 557 255 200 557 minecraft:yellow_concrete
fill 256 200 560 258 201 560 minecraft:red_concrete
fill 257 200 559 258 201 559 minecraft:red_concrete
fill 261 200 599 262 201 599 minecraft:yellow_concrete
fill 263 200 599 264 205 599 minecraft:orange_terracotta
fill 264 200 557 265 205 557 minecraft:orange_terracotta
fill 266 200 557 267 201 557 minecraft:yellow_concrete
fill 270 200 599 270 201 599 minecraft:yellow_concrete
fill 272 200 557 273 202 557 minecraft:orange_terracotta
fill 272 200 599 272 205 599 minecraft:orange_terracotta
fill 273 200 599 274 200 599 minecraft:yellow_concrete
fill 274 200 557 275 200 557 minecraft:yellow_concrete
fill 275 200 599 275 205 599 minecraft:orange_terracotta
fill 276 200 557 276 205 557 minecraft:orange_terracotta
fill 277 200 558 277 201 558 minecraft:yellow_concrete
setblock 277 200 559 minecraft:orange_terracotta
fill 277 200 564 277 205 565 minecraft:orange_terracotta
fill 277 200 566 277 201 567 minecraft:yellow_concrete
fill 277 200 573 277 202 573 minecraft:orange_terracotta
setblock 277 200 575 minecraft:yellow_concrete
fill 277 200 576 277 205 577 minecraft:orange_terracotta
fill 277 200 578 277 201 579 minecraft:yellow_concrete
fill 277 200 584 277 205 585 minecraft:orange_terracotta
fill 277 200 586 277 200 587 minecraft:yellow_concrete
fill 277 200 596 277 205 597 minecraft:orange_terracotta
fill 277 200 598 277 201 598 minecraft:yellow_concrete
setblock 235 201 570 minecraft:yellow_concrete
setblock 235 201 573 minecraft:yellow_concrete
fill 235 201 574 235 204 574 minecraft:orange_terracotta
setblock 235 201 581 minecraft:yellow_concrete
fill 235 201 585 235 204 585 minecraft:orange_terracotta
fill 237 201 599 238 201 599 minecraft:yellow_concrete
setblock 241 201 599 minecraft:yellow_concrete
fill 242 201 599 242 204 599 minecraft:orange_terracotta
fill 243 201 557 243 204 557 minecraft:orange_terracotta
setblock 247 201 557 minecraft:yellow_concrete
fill 253 201 599 253 204 599 minecraft:orange_terracotta
fill 254 201 557 254 204 557 minecraft:orange_terracotta
setblock 255 201 557 minecraft:yellow_concrete
setblock 258 201 557 minecraft:yellow_concrete
setblock 258 201 599 minecraft:yellow_concrete
setblock 269 201 599 minecraft:yellow_concrete
fill 273 201 599 274 204 599 minecraft:orange_terracotta
fill 274 201 557 274 204 557 minecraft:orange_terracotta
setblock 275 201 557 minecraft:yellow_concrete
setblock 277 201 559 minecraft:yellow_concrete
setblock 277 201 570 minecraft:yellow_concrete
fill 277 201 571 277 203 571 minecraft:orange_terracotta
fill 277 201 575 277 204 575 minecraft:orange_terracotta
fill 277 201 586 277 204 586 minecraft:orange_terracotta
setblock 277 201 587 minecraft:yellow_concrete
setblock 277 201 590 minecraft:yellow_concrete
fill 235 202 559 235 203 560 minecraft:yellow_concrete
fill 235 202 561 235 207 562 minecraft:orange_terracotta
fill 235 202 568 235 203 568 minecraft:yellow_concrete
fill 235 202 570 235 207 570 minecraft:orange_terracotta
fill 235 202 571 235 202 572 minecraft:yellow_concrete
fill 235 202 573 235 207 573 minecraft:orange_terracotta
fill 235 202 579 235 203 580 minecraft:yellow_concrete
fill 235 202 581 235 207 582 minecraft:orange_terracotta
fill 235 202 591 235 202 592 minecraft:yellow_concrete
fill 235 202 593 235 207 594 minecraft:orange_terracotta
fill 236 202 557 237 202 557 minecraft:yellow_concrete
fill 236 202 599 236 203 599 minecraft:yellow_concrete
fill 237 202 599 238 207 599 minecraft:orange_terracotta
setblock 238 202 560 minecraft:light[level=14]
setblock 238 202 568 minecraft:light[level=14]
setblock 238 202 576 minecraft:light[level=14]
setblock 238 202 584 minecraft:light[level=14]
setblock 238 202 592 minecraft:light[level=14]
setblock 239 202 599 minecraft:yellow_concrete
fill 241 202 599 241 207 599 minecraft:orange_terracotta
fill 246 202 557 247 207 557 minecraft:orange_terracotta
setblock 246 202 560 minecraft:light[level=14]
setblock 246 202 568 minecraft:light[level=14]
setblock 246 202 576 minecraft:light[level=14]
setblock 246 202 584 minecraft:light[level=14]
setblock 246 202 592 minecraft:light[level=14]
fill 247 202 599 248 203 599 minecraft:yellow_concrete
fill 248 202 557 249 203 557 minecraft:yellow_concrete
fill 249 202 599 250 207 599 minecraft:orange_terracotta
setblock 254 202 560 minecraft:light[level=14]
setblock 254 202 568 minecraft:light[level=14]
setblock 254 202 576 minecraft:light[level=14]
setblock 254 202 584 minecraft:light[level=14]
setblock 254 202 592 minecraft:light[level=14]
fill 255 202 557 255 207 557 minecraft:orange_terracotta
fill 256 202 557 257 202 557 minecraft:yellow_concrete
fill 258 202 557 258 207 557 minecraft:orange_terracotta
fill 258 202 599 258 207 599 minecraft:orange_terracotta
fill 259 202 599 260 202 599 minecraft:yellow_concrete
fill 260 202 557 260 203 557 minecraft:yellow_concrete
fill 261 202 599 262 207 599 minecraft:orange_terracotta
setblock 262 202 560 minecraft:light[level=14]
setblock 262 202 568 minecraft:light[level=14]
setblock 262 202 576 minecraft:light[level=14]
setblock 262 202 584 minecraft:light[level=14]
setblock 262 202 592 minecraft:light[level=14]
fill 266 202 557 267 207 557 minecraft:orange_terracotta
fill 267 202 599 268 203 599 minecraft:yellow_concrete
fill 268 202 557 269 203 557 minecraft:yellow_concrete
fill 269 202 599 270 207 599 minecraft:orange_terracotta
setblock 270 202 560 minecraft:light[level=14]
setblock 270 202 568 minecraft:light[level=14]
setblock 270 202 576 minecraft:light[level=14]
setblock 270 202 584 minecraft:light[level=14]
setblock 270 202 592 minecraft:light[level=14]
setblock 271 202 599 minecraft:yellow_concrete
fill 275 202 557 275 204 557 minecraft:orange_terracotta
setblock 277 202 557 minecraft:yellow_concrete
fill 277 202 558 277 207 559 minecraft:orange_terracotta
fill 277 202 560 277 203 561 minecraft:yellow_concrete
fill 277 202 566 277 207 567 minecraft:orange_terracotta
fill 277 202 568 277 202 569 minecraft:yellow_concrete
fill 277 202 570 277 203 570 minecraft:orange_terracotta
fill 277 202 578 277 207 579 minecraft:orange_terracotta
fill 277 202 580 277 203 581 minecraft:yellow_concrete
fill 277 202 587 277 207 587 minecraft:orange_terracotta
fill 277 202 588 277 202 589 minecraft:yellow_concrete
fill 277 202 590 277 207 590 minecraft:orange_terracotta
fill 277 202 592 277 203 592 minecraft:yellow_concrete
fill 277 202 598 277 207 598 minecraft:orange_terracotta
setblock 235 203 567 minecraft:yellow_concrete
fill 235 203 571 235 206 572 minecraft:orange_terracotta
setblock 235 203 588 minecraft:yellow_concrete
setblock 235 203 591 minecraft:yellow_concrete
fill 235 203 592 235 206 592 minecraft:orange_terracotta
setblock 235 203 599 minecraft:yellow_concrete
fill 236 203 557 236 206 557 minecraft:orange_terracotta
setblock 237 203 557 minecraft:yellow_concrete
fill 239 203 599 239 206 599 minecraft:orange_terracotta
setblock 240 203 557 minecraft:yellow_concrete
fill 255 203 599 256 203 599 minecraft:yellow_concrete
fill 256 203 557 257 206 557 minecraft:orange_terracotta
setblock 259 203 599 minecraft:yellow_concrete
fill 260 203 599 260 206 599 minecraft:orange_terracotta
setblock 261 203 557 minecraft:yellow_concrete
fill 271 203 599 271 206 599 minecraft:orange_terracotta
setblock 272 203 557 minecraft:yellow_concrete
fill 273 203 557 273 205 557 minecraft:orange_terracotta
setblock 276 203 599 minecraft:yellow_concrete
fill 277 203 557 277 206 557 minecraft:orange_terracotta
fill 277 203 568 277 206 568 minecraft:orange_terracotta
setblock 277 203 569 minecraft:yellow_concrete
fill 277 203 572 277 203 573 minecraft:yellow_concrete
fill 277 203 588 277 205 589 minecraft:orange_terracotta
setblock 277 203 593 minecraft:yellow_concrete
fill 235 204 557 235 204 558 minecraft:yellow_concrete
fill 235 204 559 235 209 560 minecraft:orange_terracotta
fill 235 204 565 235 205 566 minecraft:yellow_concrete
fill 235 204 567 235 209 568 minecraft:orange_terracotta
setblock 235 204 569 minecraft:yellow_concrete
fill 235 204 577 235 205 578 minecraft:yellow_concrete
fill 235 204 579 235 209 580 minecraft:orange_terracotta
fill 235 204 586 235 205 586 minecraft:yellow_concrete
fill 235 204 588 235 209 588 minecraft:orange_terracotta
fill 235 204 589 235 204 590 minecraft:yellow_concrete
fill 235 204 591 235 209 591 minecraft:orange_terracotta
fill 235 204 597 235 205 598 minecraft:yellow_concrete
fill 235 204 599 236 209 599 minecraft:orange_terracotta
fill 236 204 558 238 204 558 minecraft:orange_concrete
fill 236 204 560 236 204 562 minecraft:orange_concrete
fill 236 204 564 236 204 566 minecraft:orange_concrete
fill 236 204 568 236 204 570 minecraft:orange_concrete
fill 236 204 572 236 204 574 minecraft:orange_concrete
fill 236 204 576 236 204 578 minecraft:orange_concrete
fill 236 204 580 236 204 582 minecraft:orange_concrete
fill 236 204 584 236 204 586 minecraft:orange_concrete
fill 236 204 588 236 204 590 minecraft:orange_concrete
fill 236 204 592 236 204 594 minecraft:orange_concrete
fill 236 204 596 236 204 598 minecraft:orange_concrete
fill 237 204 557 237 209 557 minecraft:orange_terracotta
fill 238 204 557 239 204 557 minecraft:yellow_concrete
fill 238 204 598 240 204 598 minecraft:orange_concrete
fill 240 204 557 240 209 557 minecraft:orange_terracotta
fill 240 204 558 242 204 558 minecraft:orange_concrete
fill 242 204 557 242 205 557 minecraft:yellow_concrete
fill 242 204 598 244 204 598 minecraft:orange_concrete
fill 244 204 558 246 204 558 minecraft:orange_concrete
fill 245 204 599 246 204 599 minecraft:yellow_concrete
fill 246 204 598 248 204 598 minecraft:orange_concrete
fill 247 204 599 248 209 599 minecraft:orange_terracotta
fill 248 204 557 249 209 557 minecraft:orange_terracotta
fill 248 204 558 250 204 558 minecraft:orange_concrete
fill 250 204 557 251 205 557 minecraft:yellow_concrete
fill 250 204 598 252 204 598 minecraft:orange_concrete
fill 252 204 558 254 204 558 minecraft:orange_concrete
fill 254 204 596 256 207 597 minecraft:magma_block
fill 254 204 598 256 204 598 minecraft:orange_concrete
fill 254 204 599 254 205 599 minecraft:yellow_concrete
fill 255 204 599 256 209 599 minecraft:orange_terracotta
fill 256 204 558 258 204 558 minecraft:orange_concrete
setblock 257 204 599 minecraft:yellow_concrete
fill 258 204 598 260 204 598 minecraft:orange_concrete
setblock 259 204 557 minecraft:yellow_concrete
fill 259 204 599 259 209 599 minecraft:orange_terracotta
fill 260 204 557 261 209 557 minecraft:orange_terracotta
fill 260 204 558 262 204 558 minecraft:orange_concrete
fill 262 204 557 263 205 557 minecraft:yellow_concrete
fill 262 204 598 264 204 598 minecraft:orange_concrete
fill 264 204 558 266 204 558 minecraft:orange_concrete
fill 265 204 599 266 205 599 minecraft:yellow_concrete
fill 266 204 598 268 204 598 minecraft:orange_concrete
fill 267 204 599 268 209 599 minecraft:orange_terracotta
fill 268 204 557 269 209 557 minecraft:orange_terracotta
fill 268 204 558 270 204 558 minecraft:orange_concrete
fill 270 204 557 271 204 557 minecraft:yellow_concrete
fill 270 204 598 272 204 598 minecraft:orange_concrete
fill 272 204 557 272 209 557 minecraft:orange_terracotta
fill 272 204 558 274 204 558 minecraft:orange_concrete
fill 274 204 598 276 204 598 minecraft:orange_concrete
fill 276 204 558 276 204 560 minecraft:orange_concrete
fill 276 204 562 276 204 564 minecraft:orange_concrete
fill 276 204 566 276 204 568 minecraft:orange_concrete
fill 276 204 570 276 204 572 minecraft:orange_concrete
fill 276 204 574 276 204 576 minecraft:orange_concrete
fill 276 204 578 276 204 580 minecraft:orange_concrete
fill 276 204 582 276 204 584 minecraft:orange_concrete
fill 276 204 586 276 204 588 minecraft:orange_concrete
fill 276 204 590 276 204 592 minecraft:orange_concrete
fill 276 204 594 276 204 596 minecraft:orange_concrete
fill 276 204 599 276 209 599 minecraft:orange_terracotta
fill 277 204 560 277 209 561 minecraft:orange_terracotta
fill 277 204 562 277 205 563 minecraft:yellow_concrete
fill 277 204 569 277 209 569 minecraft:orange_terracotta
fill 277 204 570 277 204 571 minecraft:yellow_concrete
fill 277 204 572 277 205 573 minecraft:orange_terracotta
fill 277 204 574 277 205 574 minecraft:yellow_concrete
fill 277 204 580 277 209 581 minecraft:orange_terracotta
fill 277 204 582 277 205 583 minecraft:yellow_concrete
setblock 277 204 591 minecraft:yellow_concrete
fill 277 204 592 277 209 593 minecraft:orange_terracotta
fill 277 204 594 277 205 595 minecraft:yellow_concrete
fill 277 204 599 277 205 599 minecraft:yellow_concrete
setblock 235 205 557 minecraft:yellow_concrete
fill 235 205 558 235 208 558 minecraft:orange_terracotta
fill 235 205 569 235 208 569 minecraft:orange_terracotta
setblock 235 205 574 minecraft:yellow_concrete
setblock 235 205 585 minecraft:yellow_concrete
fill 235 205 589 235 208 590 minecraft:orange_terracotta
fill 238 205 557 239 208 557 minecraft:orange_terracotta
setblock 242 205 599 minecraft:yellow_concrete
setblock 243 205 557 minecraft:yellow_concrete
setblock 245 205 599 minecraft:yellow_concrete
fill 246 205 599 246 208 599 minecraft:orange_terracotta
fill 253 205 597 253 206 597 minecraft:magma_block
setblock 253 205 599 minecraft:yellow_concrete
setblock 254 205 557 minecraft:yellow_concrete
fill 254 205 595 256 207 595 minecraft:magma_block
fill 254 205 598 256 207 598 minecraft:magma_block
fill 255 205 594 255 207 594 minecraft:magma_block
fill 257 205 597 257 206 597 minecraft:magma_block
fill 257 205 599 257 208 599 minecraft:orange_terracotta
fill 259 205 557 259 208 557 minecraft:orange_terracotta
fill 270 205 557 270 208 557 minecraft:orange_terracotta
setblock 271 205 557 minecraft:yellow_concrete
fill 273 205 599 274 205 599 minecraft:yellow_concrete
fill 274 205 557 275 205 557 minecraft:yellow_concrete
fill 277 205 570 277 207 571 minecraft:orange_terracotta
setblock 277 205 575 minecraft:yellow_concrete
setblock 277 205 586 minecraft:yellow_concrete
fill 277 205 591 277 207 591 minecraft:orange_terracotta
fill 235 206 557 235 211 557 minecraft:orange_terracotta
fill 235 206 563 235 207 564 minecraft:yellow_concrete
fill 235 206 565 235 211 566 minecraft:orange_terracotta
fill 235 206 574 235 211 574 minecraft:orange_terracotta
fill 235 206 575 235 206 576 minecraft:yellow_concrete
fill 235 206 577 235 211 578 minecraft:orange_terracotta
fill 235 206 583 235 207 584 minecraft:yellow_concrete
fill 235 206 585 235 211 586 minecraft:orange_terracotta
setblock 235 206 587 minecraft:yellow_concrete
fill 235 206 595 235 207 596 minecraft:yellow_concrete
fill 235 206 597 235 211 598 minecraft:orange_terracotta
fill 240 206 599 240 207 599 minecraft:yellow_concrete
setblock 241 206 557 minecraft:yellow_concrete
fill 242 206 557 243 211 557 minecraft:orange_terracotta
fill 242 206 599 242 211 599 minecraft:orange_terracotta
fill 243 206 599 244 206 599 minecraft:yellow_concrete
fill 244 206 557 245 207 557 minecraft:yellow_concrete
fill 245 206 599 245 211 599 minecraft:orange_terracotta
fill 250 206 557 251 211 557 minecraft:orange_terracotta
fill 251 206 599 252 207 599 minecraft:yellow_concrete
fill 252 206 557 253 206 557 minecraft:yellow_concrete
fill 253 206 599 254 211 599 minecraft:orange_terracotta
fill 254 206 557 254 211 557 minecraft:orange_terracotta
fill 254 206 594 254 207 594 minecraft:magma_block
fill 255 206 593 255 207 593 minecraft:magma_block
fill 256 206 594 256 207 594 minecraft:magma_block
fill 262 206 557 263 211 557 minecraft:orange_terracotta
fill 263 206 599 264 206 599 minecraft:yellow_concrete
fill 264 206 557 265 207 557 minecraft:yellow_concrete
fill 265 206 599 266 211 599 minecraft:orange_terracotta
fill 271 206 557 271 211 557 minecraft:orange_terracotta
fill 272 206 599 272 207 599 minecraft:yellow_concrete
setblock 273 206 557 minecraft:yellow_concrete
fill 273 206 599 274 211 599 minecraft:orange_terracotta
fill 274 206 557 275 211 557 minecraft:orange_terracotta
setblock 275 206 599 minecraft:yellow_concrete
fill 276 206 557 276 207 557 minecraft:yellow_concrete
fill 277 206 562 277 211 563 minecraft:orange_terracotta
fill 277 206 564 277 207 565 minecraft:yellow_concrete
fill 277 206 572 277 209 572 minecraft:orange_terracotta
setblock 277 206 573 minecraft:yellow_concrete
fill 277 206 574 277 211 575 minecraft:orange_terracotta
fill 277 206 576 277 207 577 minecraft:yellow_concrete
fill 277 206 582 277 208 583 minecraft:orange_terracotta
fill 277 206 584 277 206 585 minecraft:yellow_concrete
fill 277 206 586 277 211 586 minecraft:orange_terracotta
fill 277 206 588 277 207 588 minecraft:yellow_concrete
setblock 277 206 589 minecraft:orange_terracotta
fill 277 206 594 277 211 595 minecraft:orange_terracotta
fill 277 206 596 277 207 597 minecraft:yellow_concrete
fill 277 206 599 277 211 599 minecraft:orange_terracotta
fill 235 207 571 235 207 572 minecraft:yellow_concrete
setblock 235 207 575 minecraft:yellow_concrete
fill 235 207 576 235 210 576 minecraft:orange_terracotta
fill 235 207 587 235 210 587 minecraft:orange_terracotta
setblock 235 207 592 minecraft:yellow_concrete
setblock 236 207 557 minecraft:yellow_concrete
setblock 239 207 599 minecraft:yellow_concrete
fill 241 207 557 241 210 557 minecraft:orange_terracotta
fill 243 207 599 244 210 599 minecraft:orange_terracotta
fill 252 207 557 252 210 557 minecraft:orange_terracotta
setblock 253 207 557 minecraft:yellow_concrete
setblock 255 207 592 minecraft:magma_block
fill 256 207 557 257 207 557 minecraft:yellow_concrete
setblock 260 207 599 minecraft:yellow_concrete
setblock 263 207 599 minecraft:yellow_concrete
fill 264 207 599 264 210 599 minecraft:orange_terracotta
setblock 271 207 599 minecraft:yellow_concrete
fill 273 207 557 273 210 557 minecraft:orange_terracotta
fill 275 207 599 275 210 599 minecraft:orange_terracotta
setblock 277 207 557 minecraft:yellow_concrete
setblock 277 207 568 minecraft:yellow_concrete
fill 277 207 573 277 209 573 minecraft:orange_terracotta
fill 277 207 584 277 210 584 minecraft:orange_terracotta
setblock 277 207 585 minecraft:yellow_concrete
setblock 277 207 589 minecraft:yellow_concrete
fill 235 208 561 235 208 562 minecraft:yellow_concrete
fill 235 208 563 235 212 564 minecraft:orange_terracotta
fill 235 208 570 235 209 570 minecraft:yellow_concrete
fill 235 208 571 235 213 572 minecraft:orange_terracotta
setblock 235 208 573 minecraft:yellow_concrete
fill 235 208 575 235 213 575 minecraft:orange_terracotta
fill 235 208 581 235 209 582 minecraft:yellow_concrete
fill 235 208 583 235 213 584 minecraft:orange_terracotta
fill 235 208 592 235 213 592 minecraft:orange_terracotta
fill 235 208 593 235 208 594 minecraft:yellow_concrete
fill 235 208 595 235 213 596 minecraft:orange_terracotta
fill 236 208 557 236 213 557 minecraft:orange_terracotta
fill 236 208 572 236 209 574 minecraft:magma_block
fill 237 208 573 238 210 573 minecraft:magma_block
fill 237 208 599 238 209 599 minecraft:yellow_concrete
fill 239 208 599 240 212 599 minecraft:orange_terracotta
setblock 241 208 599 minecraft:yellow_concrete
fill 244 208 557 245 213 557 minecraft:orange_terracotta
fill 246 208 557 247 209 557 minecraft:yellow_concrete
fill 249 208 599 250 209 599 minecraft:yellow_concrete
fill 251 208 599 252 213 599 minecraft:orange_terracotta
fill 253 208 557 253 212 557 minecraft:orange_terracotta
fill 253 208 592 255 209 592 minecraft:orange_concrete
fill 254 208 591 254 209 591 minecraft:orange_concrete
fill 254 208 593 254 209 593 minecraft:orange_concrete
setblock 255 208 557 minecraft:yellow_concrete
fill 256 208 557 257 212 557 minecraft:orange_terracotta
fill 258 208 557 258 209 557 minecraft:yellow_concrete
fill 258 208 599 258 209 599 minecraft:yellow_concrete
fill 260 208 599 260 213 599 minecraft:orange_terracotta
fill 261 208 599 262 208 599 minecraft:yellow_concrete
fill 263 208 599 263 212 599 minecraft:orange_terracotta
fill 264 208 557 265 213 557 minecraft:orange_terracotta
fill 266 208 557 267 208 557 minecraft:yellow_concrete
fill 269 208 599 270 209 599 minecraft:yellow_concrete
fill 271 208 599 272 213 599 minecraft:orange_terracotta
fill 276 208 557 277 213 557 minecraft:orange_terracotta
fill 277 208 558 277 209 559 minecraft:yellow_concrete
fill 277 208 564 277 210 565 minecraft:orange_terracotta
fill 277 208 566 277 208 567 minecraft:yellow_concrete
fill 277 208 568 277 213 568 minecraft:orange_terracotta
fill 277 208 570 277 209 570 minecraft:yellow_concrete
setblock 277 208 571 minecraft:orange_terracotta
fill 277 208 576 277 213 577 minecraft:orange_terracotta
fill 277 208 578 277 209 579 minecraft:yellow_concrete
fill 277 208 585 277 210 585 minecraft:orange_terracotta
setblock 277 208 587 minecraft:yellow_concrete
fill 277 208 588 277 213 589 minecraft:orange_terracotta
fill 277 208 590 277 209 591 minecraft:yellow_concrete
fill 277 208 596 277 213 597 minecraft:orange_terracotta
setblock 277 208 598 minecraft:yellow_concrete
setblock 235 209 558 minecraft:yellow_concrete
setblock 235 209 561 minecraft:yellow_concrete
fill 235 209 562 235 212 562 minecraft:orange_terracotta
setblock 235 209 569 minecraft:yellow_concrete
fill 235 209 573 235 212 573 minecraft:orange_terracotta
fill 235 209 589 235 209 590 minecraft:yellow_concrete
setblock 235 209 593 minecraft:yellow_concrete
fill 235 209 594 235 212 594 minecraft:orange_terracotta
fill 237 209 572 240 209 572 minecraft:magma_block
fill 237 209 574 240 209 574 minecraft:magma_block
fill 238 209 557 239 209 557 minecraft:yellow_concrete
fill 239 209 573 243 209 573 minecraft:magma_block
fill 241 209 599 241 212 599 minecraft:orange_terracotta
setblock 246 209 599 minecraft:yellow_concrete
fill 255 209 557 255 211 557 minecraft:orange_terracotta
setblock 257 209 599 minecraft:yellow_concrete
setblock 259 209 557 minecraft:yellow_concrete
fill 261 209 599 262 212 599 minecraft:orange_terracotta
fill 263 209 568 264 210 568 minecraft:shroomlight
fill 266 209 557 266 212 557 minecraft:orange_terracotta
setblock 267 209 557 minecraft:yellow_concrete
setblock 270 209 557 minecraft:yellow_concrete
fill 277 209 566 277 212 566 minecraft:orange_terracotta
setblock 277 209 567 minecraft:yellow_concrete
setblock 277 209 571 minecraft:yellow_concrete
setblock 277 209 582 minecraft:yellow_concrete
fill 277 209 583 277 211 583 minecraft:orange_terracotta
fill 277 209 587 277 212 587 minecraft:orange_terracotta
fill 277 209 598 277 212 598 minecraft:orange_terracotta
fill 235 210 558 235 215 558 minecraft:orange_terracotta
fill 235 210 559 235 210 560 minecraft:yellow_concrete
fill 235 210 561 235 215 561 minecraft:orange_terracotta
fill 235 210 567 235 211 568 minecraft:yellow_concrete
fill 235 210 569 235 213 570 minecraft:orange_terracotta
fill 235 210 579 235 210 580 minecraft:yellow_concrete
fill 235 210 581 235 213 582 minecraft:orange_terracotta
fill 235 210 588 235 211 588 minecraft:yellow_concrete
fill 235 210 589 235 212 590 minecraft:orange_terracotta
setblock 235 210 591 minecraft:yellow_concrete
fill 235 210 593 235 212 593 minecraft:orange_terracotta
fill 235 210 599 236 211 599 minecraft:yellow_concrete
fill 236 210 558 238 210 558 minecraft:orange_concrete
fill 236 210 560 236 210 562 minecraft:orange_concrete
fill 236 210 564 236 210 566 minecraft:orange_concrete
fill 236 210 568 236 210 570 minecraft:orange_concrete
fill 236 210 572 236 210 574 minecraft:orange_concrete
fill 236 210 576 236 210 578 minecraft:orange_concrete
fill 236 210 580 236 210 582 minecraft:orange_concrete
fill 236 210 584 236 210 586 minecraft:orange_concrete
fill 236 210 588 236 210 590 minecraft:orange_concrete
fill 236 210 592 236 210 594 minecraft:orange_concrete
fill 236 210 596 236 210 598 minecraft:orange_concrete
setblock 237 210 557 minecraft:yellow_concrete
fill 237 210 572 239 210 572 minecraft:magma_block
fill 237 210 574 239 210 574 minecraft:magma_block
fill 237 210 599 238 215 599 minecraft:orange_terracotta
fill 238 210 557 239 215 557 minecraft:orange_terracotta
setblock 238 210 560 minecraft:light[level=14]
setblock 238 210 568 minecraft:light[level=14]
setblock 238 210 576 minecraft:light[level=14]
setblock 238 210 584 minecraft:light[level=14]
setblock 238 210 592 minecraft:light[level=14]
fill 238 210 598 240 210 598 minecraft:orange_concrete
fill 239 210 573 241 210 573 minecraft:magma_block
fill 240 210 557 240 211 557 minecraft:yellow_concrete
fill 240 210 558 242 210 558 minecraft:orange_concrete
fill 242 210 598 244 210 598 minecraft:orange_concrete
fill 244 210 558 246 210 558 minecraft:orange_concrete
fill 246 210 557 247 215 557 minecraft:orange_terracotta
setblock 246 210 560 minecraft:light[level=14]
setblock 246 210 568 minecraft:light[level=14]
setblock 246 210 576 minecraft:light[level=14]
setblock 246 210 584 minecraft:light[level=14]
setblock 246 210 592 minecraft:light[level=14]
fill 246 210 598 248 210 598 minecraft:orange_concrete
fill 246 210 599 246 215 599 minecraft:orange_terracotta
fill 247 210 599 248 210 599 minecraft:yellow_concrete
fill 248 210 557 249 210 557 minecraft:yellow_concrete
fill 248 210 558 250 210 558 minecraft:orange_concrete
fill 249 210 599 250 215 599 minecraft:orange_terracotta
fill 250 210 598 252 210 598 minecraft:orange_concrete
fill 252 210 558 254 210 558 minecraft:orange_concrete
setblock 254 210 560 minecraft:light[level=14]
setblock 254 210 568 minecraft:light[level=14]
setblock 254 210 576 minecraft:light[level=14]
setblock 254 210 584 minecraft:light[level=14]
setblock 254 210 592 minecraft:light[level=14]
fill 254 210 598 256 210 598 minecraft:orange_concrete
fill 255 210 599 256 211 599 minecraft:yellow_concrete
fill 256 210 558 258 210 558 minecraft:orange_concrete
fill 257 210 599 258 211 599 minecraft:orange_terracotta
fill 258 210 557 259 211 557 minecraft:orange_terracotta
fill 258 210 598 260 210 598 minecraft:orange_concrete
setblock 259 210 599 minecraft:yellow_concrete
fill 260 210 557 261 211 557 minecraft:yellow_concrete
fill 260 210 558 262 210 558 minecraft:orange_concrete
setblock 262 210 560 minecraft:light[level=14]
setblock 262 210 568 minecraft:light[level=14]
setblock 262 210 576 minecraft:light[level=14]
setblock 262 210 584 minecraft:light[level=14]
setblock 262 210 592 minecraft:light[level=14]
fill 262 210 598 264 210 598 minecraft:orange_concrete
fill 264 210 558 266 210 558 minecraft:orange_concrete
fill 266 210 598 268 210 598 minecraft:orange_concrete
fill 267 210 557 267 211 557 minecraft:orange_terracotta
fill 267 210 599 268 211 599 minecraft:yellow_concrete
fill 268 210 557 269 210 557 minecraft:yellow_concrete
fill 268 210 558 270 210 558 minecraft:orange_concrete
fill 269 210 599 270 215 599 minecraft:orange_terracotta
fill 270 210 557 270 213 557 minecraft:orange_terracotta
setblock 270 210 560 minecraft:light[level=14]
setblock 270 210 568 minecraft:light[level=14]
setblock 270 210 576 minecraft:light[level=14]
setblock 270 210 584 minecraft:light[level=14]
setblock 270 210 592 minecraft:light[level=14]
fill 270 210 598 272 210 598 minecraft:orange_concrete
fill 272 210 557 272 211 557 minecraft:yellow_concrete
fill 272 210 558 274 210 558 minecraft:orange_concrete
fill 274 210 598 276 210 598 minecraft:orange_concrete
fill 276 210 558 276 210 560 minecraft:orange_concrete
fill 276 210 562 276 210 564 minecraft:orange_concrete
fill 276 210 566 276 210 568 minecraft:orange_concrete
fill 276 210 570 276 210 572 minecraft:orange_concrete
fill 276 210 574 276 210 576 minecraft:orange_concrete
fill 276 210 578 276 210 580 minecraft:orange_concrete
fill 276 210 582 276 210 584 minecraft:orange_concrete
fill 276 210 586 276 210 588 minecraft:orange_concrete
fill 276 210 590 276 210 592 minecraft:orange_concrete
fill 276 210 594 276 210 596 minecraft:orange_concrete
fill 276 210 599 276 211 599 minecraft:yellow_concrete
fill 277 210 558 277 212 559 minecraft:orange_terracotta
fill 277 210 560 277 211 561 minecraft:yellow_concrete
fill 277 210 567 277 212 567 minecraft:orange_terracotta
setblock 277 210 569 minecraft:yellow_concrete
fill 277 210 570 277 215 571 minecraft:orange_terracotta
fill 277 210 572 277 211 573 minecraft:yellow_concrete
fill 277 210 578 277 213 579 minecraft:orange_terracotta
fill 277 210 580 277 210 581 minecraft:yellow_concrete
fill 277 210 582 277 211 582 minecraft:orange_terracotta
fill 277 210 590 277 215 591 minecraft:orange_terracotta
fill 277 210 592 277 211 593 minecraft:yellow_concrete
fill 235 211 559 235 214 560 minecraft:orange_terracotta
setblock 235 211 576 minecraft:yellow_concrete
setblock 235 211 579 minecraft:yellow_concrete
fill 235 211 580 235 214 580 minecraft:orange_terracotta
setblock 235 211 587 minecraft:yellow_concrete
fill 235 211 591 235 214 591 minecraft:orange_terracotta
fill 236 211 572 236 211 574 minecraft:magma_block
fill 237 211 557 237 212 557 minecraft:orange_terracotta
setblock 237 211 573 minecraft:magma_block
setblock 241 211 557 minecraft:yellow_concrete
fill 243 211 599 244 211 599 minecraft:yellow_concrete
setblock 247 211 599 minecraft:yellow_concrete
fill 248 211 557 248 214 557 minecraft:orange_terracotta
setblock 248 211 599 minecraft:orange_terracotta
setblock 249 211 557 minecraft:yellow_concrete
setblock 252 211 557 minecraft:yellow_concrete
fill 259 211 599 259 214 599 minecraft:orange_terracotta
setblock 264 211 599 minecraft:yellow_concrete
fill 268 211 557 269 212 557 minecraft:orange_terracotta
setblock 273 211 557 minecraft:yellow_concrete
setblock 275 211 599 minecraft:yellow_concrete
setblock 277 211 564 minecraft:yellow_concrete
fill 277 211 565 277 213 565 minecraft:orange_terracotta
fill 277 211 569 277 214 569 minecraft:orange_terracotta
fill 277 211 580 277 214 580 minecraft:orange_terracotta
setblock 277 211 581 minecraft:yellow_concrete
fill 277 211 584 277 211 585 minecraft:yellow_concrete
setblock 235 212 557 minecraft:yellow_concrete
fill 235 212 565 235 213 566 minecraft:yellow_concrete
fill 235 212 567 235 215 568 minecraft:orange_terracotta
fill 235 212 574 235 213 574 minecraft:yellow_concrete
fill 235 212 576 235 215 576 minecraft:orange_terracotta
fill 235 212 577 235 212 578 minecraft:yellow_concrete
setblock 235 212 579 minecraft:red_concrete
fill 235 212 585 235 213 586 minecraft:yellow_concrete
fill 235 212 587 235 215 588 minecraft:orange_terracotta
fill 235 212 597 235 212 598 minecraft:yellow_concrete
setblock 235 212 599 minecraft:red_concrete
fill 236 212 599 236 215 599 minecraft:orange_terracotta
fill 240 212 557 241 215 557 minecraft:orange_terracotta
fill 242 212 557 243 213 557 minecraft:yellow_concrete
fill 242 212 599 242 213 599 minecraft:yellow_concrete
fill 243 212 599 244 212 599 minecraft:orange_terracotta
setblock 245 212 599 minecraft:yellow_concrete
setblock 247 212 599 minecraft:orange_terracotta
setblock 248 212 599 minecraft:red_concrete
fill 249 212 557 249 215 557 minecraft:orange_terracotta
fill 250 212 557 251 212 557 minecraft:yellow_concrete
fill 252 212 557 252 215 557 minecraft:orange_terracotta
fill 253 212 599 254 213 599 minecraft:yellow_concrete
fill 254 212 557 254 213 557 minecraft:yellow_concrete
setblock 255 212 557 minecraft:red_concrete
fill 255 212 599 257 213 599 minecraft:orange_terracotta
setblock 258 212 557 minecraft:red_concrete
fill 258 212 599 258 213 599 minecraft:red_concrete
fill 259 212 557 261 215 557 minecraft:orange_terracotta
fill 262 212 557 263 213 557 minecraft:yellow_concrete
setblock 264 212 599 minecraft:red_concrete
fill 265 212 599 266 212 599 minecraft:yellow_concrete
setblock 267 212 557 minecraft:red_concrete
fill 267 212 599 268 215 599 minecraft:orange_terracotta
setblock 271 212 557 minecraft:yellow_concrete
fill 272 212 557 273 215 557 minecraft:orange_terracotta
fill 273 212 599 274 213 599 minecraft:yellow_concrete
fill 274 212 557 275 213 557 minecraft:yellow_concrete
fill 275 212 599 275 215 599 minecraft:orange_terracotta
setblock 276 212 599 minecraft:red_concrete
fill 277 212 560 277 215 561 minecraft:orange_terracotta
fill 277 212 562 277 212 563 minecraft:yellow_concrete
fill 277 212 564 277 215 564 minecraft:orange_terracotta
fill 277 212 572 277 215 573 minecraft:orange_terracotta
fill 277 212 574 277 213 575 minecraft:yellow_concrete
fill 277 212 581 277 215 581 minecraft:orange_terracotta
fill 277 212 582 277 212 583 minecraft:yellow_concrete
fill 277 212 584 277 213 585 minecraft:orange_terracotta
fill 277 212 586 277 213 586 minecraft:yellow_concrete
fill 277 212 592 277 215 593 minecraft:orange_terracotta
fill 277 212 594 277 213 595 minecraft:yellow_concrete
setblock 277 212 599 minecraft:yellow_concrete
fill 235 213 557 235 214 557 minecraft:red_concrete
setblock 235 213 562 minecraft:yellow_concrete
setblock 235 213 563 minecraft:red_concrete
setblock 235 213 564 minecraft:orange_terracotta
setblock 235 213 573 minecraft:yellow_concrete
fill 235 213 577 235 213 578 minecraft:red_concrete
fill 235 213 579 235 215 579 minecraft:orange_terracotta
setblock 235 213 589 minecraft:red_concrete
fill 235 213 590 235 215 590 minecraft:orange_terracotta
setblock 235 213 593 minecraft:red_concrete
setblock 235 213 594 minecraft:yellow_concrete
setblock 235 213 597 minecraft:yellow_concrete
fill 235 213 598 235 215 599 minecraft:orange_terracotta
setblock 237 213 557 minecraft:red_concrete
setblock 239 213 599 minecraft:red_concrete
setblock 240 213 599 minecraft:orange_terracotta
setblock 241 213 599 minecraft:yellow_concrete
fill 243 213 599 243 215 599 minecraft:orange_terracotta
setblock 244 213 599 minecraft:red_concrete
fill 245 213 599 245 215 599 minecraft:orange_terracotta
fill 247 213 599 247 214 599 minecraft:red_concrete
fill 248 213 599 248 214 599 minecraft:orange_terracotta
fill 250 213 557 251 213 557 minecraft:orange_terracotta
setblock 253 213 557 minecraft:red_concrete
setblock 255 213 557 minecraft:yellow_concrete
setblock 256 213 557 minecraft:red_concrete
fill 257 213 557 258 213 557 minecraft:orange_terracotta
fill 261 213 599 262 213 599 minecraft:yellow_concrete
setblock 263 213 599 minecraft:red_concrete
setblock 264 213 599 minecraft:orange_terracotta
setblock 265 213 599 minecraft:yellow_concrete
setblock 266 213 557 minecraft:yellow_concrete
fill 266 213 599 266 215 599 minecraft:orange_terracotta
fill 267 213 557 267 215 557 minecraft:orange_terracotta
setblock 268 213 557 minecraft:red_concrete
fill 269 213 557 269 214 557 minecraft:orange_terracotta
setblock 271 213 557 minecraft:orange_terracotta
fill 271 213 581 271 214 581 minecraft:orange_concrete
fill 276 213 599 277 213 599 minecraft:orange_terracotta
setblock 277 213 558 minecraft:red_concrete
fill 277 213 559 277 215 559 minecraft:orange_terracotta
fill 277 213 562 277 215 562 minecraft:orange_terracotta
setblock 277 213 563 minecraft:yellow_concrete
fill 277 213 566 277 213 567 minecraft:yellow_concrete
fill 277 213 582 277 215 583 minecraft:orange_terracotta
setblock 277 213 587 minecraft:yellow_concrete
setblock 277 213 598 minecraft:yellow_concrete
fill 235 214 562 235 215 562 minecraft:orange_terracotta
fill 235 214 563 235 214 564 minecraft:yellow_concrete
fill 235 214 565 235 215 566 minecraft:orange_terracotta
fill 235 214 569 235 215 569 minecraft:orange_terracotta
setblock 235 214 570 minecraft:red_concrete
fill 235 214 571 235 215 572 minecraft:yellow_concrete
fill 235 214 573 235 215 574 minecraft:orange_terracotta
setblock 235 214 575 minecraft:yellow_concrete
fill 235 214 577 235 215 578 minecraft:orange_terracotta
setblock 235 214 581 minecraft:red_concrete
fill 235 214 582 235 215 582 minecraft:orange_terracotta
fill 235 214 583 235 215 584 minecraft:yellow_concrete
fill 235 214 585 235 215 586 minecraft:orange_terracotta
fill 235 214 589 235 215 589 minecraft:orange_terracotta
fill 235 214 592 235 215 592 minecraft:yellow_concrete
fill 235 214 593 235 215 594 minecraft:orange_terracotta
fill 235 214 595 235 214 596 minecraft:yellow_concrete
fill 235 214 597 235 215 597 minecraft:orange_terracotta
fill 236 214 557 236 215 557 minecraft:yellow_concrete
setblock 237 214 557 minecraft:orange_terracotta
fill 239 214 599 240 215 599 minecraft:yellow_concrete
setblock 241 214 599 minecraft:red_concrete
fill 242 214 557 243 215 557 minecraft:orange_terracotta
fill 242 214 599 242 215 599 minecraft:orange_terracotta
fill 244 214 557 245 215 557 minecraft:yellow_concrete
fill 244 214 599 244 215 599 minecraft:orange_terracotta
setblock 250 214 557 minecraft:red_concrete
fill 251 214 557 251 216 557 minecraft:orange_terracotta
fill 251 214 599 252 214 599 minecraft:yellow_concrete
setblock 253 214 557 minecraft:yellow_concrete
setblock 253 214 599 minecraft:red_concrete
fill 254 214 557 255 215 557 minecraft:orange_terracotta
fill 254 214 599 255 215 599 minecraft:orange_terracotta
fill 256 214 557 257 215 557 minecraft:yellow_concrete
setblock 256 214 599 minecraft:red_concrete
fill 257 214 599 258 215 599 minecraft:orange_terracotta
fill 258 214 557 258 215 557 minecraft:orange_terracotta
fill 260 214 599 260 215 599 minecraft:yellow_concrete
fill 261 214 599 262 215 599 minecraft:orange_terracotta
fill 262 214 557 263 215 557 minecraft:orange_terracotta
setblock 263 214 599 minecraft:yellow_concrete
fill 264 214 557 265 214 557 minecraft:yellow_concrete
setblock 264 214 599 minecraft:red_concrete
fill 265 214 599 265 215 599 minecraft:orange_terracotta
fill 266 214 557 266 215 557 minecraft:orange_terracotta
setblock 268 214 557 minecraft:orange_terracotta
fill 270 214 557 271 214 557 minecraft:red_concrete
fill 271 214 599 272 215 599 minecraft:yellow_concrete
fill 273 214 599 274 215 599 minecraft:orange_terracotta
fill 274 214 557 275 215 557 minecraft:orange_terracotta
fill 276 214 557 277 215 557 minecraft:yellow_concrete
fill 276 214 599 276 215 599 minecraft:orange_terracotta
fill 277 214 558 277 215 558 minecraft:orange_terracotta
setblock 277 214 563 minecraft:red_concrete
setblock 277 214 565 minecraft:yellow_concrete
setblock 277 214 566 minecraft:red_concrete
fill 277 214 567 277 215 567 minecraft:orange_terracotta
fill 277 214 568 277 215 568 minecraft:yellow_concrete
fill 277 214 574 277 215 575 minecraft:orange_terracotta
fill 277 214 576 277 215 577 minecraft:yellow_concrete
setblock 277 214 578 minecraft:red_concrete
fill 277 214 579 277 215 579 minecraft:orange_terracotta
fill 277 214 584 277 216 584 minecraft:orange_terracotta
setblock 277 214 585 minecraft:yellow_concrete
fill 277 214 586 277 215 587 minecraft:orange_terracotta
fill 277 214 588 277 215 589 minecraft:yellow_concrete
fill 277 214 594 277 215 595 minecraft:orange_terracotta
fill 277 214 596 277 214 597 minecraft:yellow_concrete
fill 277 214 598 277 215 598 minecraft:orange_terracotta
setblock 277 214 599 minecraft:red_concrete
setblock 235 215 557 minecraft:orange_terracotta
fill 235 215 559 235 215 560 minecraft:yellow_concrete
setblock 235 215 563 minecraft:yellow_concrete
setblock 235 215 564 minecraft:orange_terracotta
setblock 235 215 570 minecraft:orange_terracotta
fill 235 215 575 235 216 575 minecraft:orange_terracotta
setblock 235 215 580 minecraft:yellow_concrete
setblock 235 215 581 minecraft:orange_terracotta
setblock 235 215 591 minecraft:yellow_concrete
fill 235 215 595 235 215 596 minecraft:orange_terracotta
setblock 237 215 557 minecraft:yellow_concrete
setblock 241 215 599 minecraft:orange_terracotta
setblock 247 215 599 minecraft:orange_terracotta
setblock 248 215 557 minecraft:yellow_concrete
setblock 248 215 599 minecraft:yellow_concrete
setblock 250 215 557 minecraft:orange_terracotta
setblock 251 215 599 minecraft:yellow_concrete
fill 252 215 599 253 215 599 minecraft:orange_terracotta
fill 253 215 557 253 216 557 minecraft:orange_terracotta
setblock 256 215 599 minecraft:orange_terracotta
setblock 259 215 599 minecraft:yellow_concrete
fill 263 215 599 264 215 599 minecraft:orange_terracotta
setblock 264 215 557 minecraft:orange_terracotta
setblock 265 215 557 minecraft:yellow_concrete
fill 268 215 557 269 215 557 minecraft:yellow_concrete
fill 270 215 557 271 215 557 minecraft:orange_terracotta
setblock 277 215 563 minecraft:orange_terracotta
fill 277 215 565 277 215 566 minecraft:orange_terracotta
setblock 277 215 569 minecraft:yellow_concrete
setblock 277 215 578 minecraft:orange_terracotta
setblock 277 215 580 minecraft:yellow_concrete
setblock 277 215 585 minecraft:orange_terracotta
setblock 277 215 596 minecraft:orange_terracotta
setblock 277 215 597 minecraft:yellow_concrete
setblock 277 215 599 minecraft:orange_terracotta
fill 235 216 557 237 216 557 minecraft:red_concrete
fill 235 216 558 235 217 558 minecraft:yellow_concrete
fill 235 216 559 235 221 560 minecraft:red_concrete
setblock 235 216 561 minecraft:yellow_concrete
fill 235 216 562 235 218 565 minecraft:red_concrete
setblock 235 216 566 minecraft:orange_terracotta
fill 235 216 567 235 216 568 minecraft:red_concrete
fill 235 216 569 235 217 570 minecraft:yellow_concrete
fill 235 216 571 235 221 571 minecraft:red_concrete
setblock 235 216 572 minecraft:orange_terracotta
fill 235 216 573 235 217 574 minecraft:red_concrete
fill 235 216 576 235 216 580 minecraft:red_concrete
fill 235 216 581 235 216 582 minecraft:yellow_concrete
fill 235 216 583 235 217 588 minecraft:red_concrete
fill 235 216 589 235 217 590 minecraft:yellow_concrete
fill 235 216 591 235 221 591 minecraft:red_concrete
setblock 235 216 592 minecraft:orange_terracotta
setblock 235 216 593 minecraft:yellow_concrete
fill 235 216 594 235 216 599 minecraft:red_concrete
fill 236 216 558 238 216 558 minecraft:orange_concrete
fill 236 216 560 236 216 562 minecraft:orange_concrete
fill 236 216 564 236 216 566 minecraft:orange_concrete
fill 236 216 568 236 216 570 minecraft:orange_concrete
fill 236 216 572 236 216 574 minecraft:orange_concrete
fill 236 216 576 236 216 578 minecraft:orange_concrete
fill 236 216 580 236 216 582 minecraft:orange_concrete
fill 236 216 584 236 216 586 minecraft:orange_concrete
fill 236 216 588 236 216 590 minecraft:orange_concrete
fill 236 216 592 236 216 594 minecraft:orange_concrete
fill 236 216 596 236 216 598 minecraft:orange_concrete
fill 236 216 599 236 217 599 minecraft:red_concrete
fill 237 216 599 238 217 599 minecraft:yellow_concrete
fill 238 216 557 239 217 557 minecraft:yellow_concrete
fill 238 216 598 240 216 598 minecraft:orange_concrete
fill 239 216 599 245 216 599 minecraft:red_concrete
fill 240 216 557 240 217 557 minecraft:orange_terracotta
fill 240 216 558 242 216 558 minecraft:orange_concrete
fill 241 216 557 245 217 557 minecraft:red_concrete
fill 242 216 598 244 216 598 minecraft:orange_concrete
fill 244 216 558 246 216 558 minecraft:orange_concrete
fill 246 216 557 247 216 557 minecraft:yellow_concrete
fill 246 216 598 248 216 598 minecraft:orange_concrete
fill 246 216 599 246 217 599 minecraft:yellow_concrete
fill 247 216 599 248 217 599 minecraft:red_concrete
fill 248 216 557 250 216 557 minecraft:red_concrete
fill 248 216 558 250 216 558 minecraft:orange_concrete
fill 249 216 599 250 216 599 minecraft:yellow_concrete
fill 250 216 598 252 216 598 minecraft:orange_concrete
fill 251 216 599 252 216 599 minecraft:red_concrete
fill 252 216 557 252 217 557 minecraft:red_concrete
fill 252 216 558 254 216 558 minecraft:orange_concrete
setblock 253 216 599 minecraft:orange_terracotta
fill 254 216 557 257 216 557 minecraft:red_concrete
fill 254 216 598 256 216 598 minecraft:orange_concrete
fill 254 216 599 256 216 599 minecraft:red_concrete
fill 256 216 558 258 216 558 minecraft:orange_concrete
fill 257 216 599 258 217 599 minecraft:yellow_concrete
fill 258 216 557 259 217 557 minecraft:yellow_concrete
fill 258 216 598 260 216 598 minecraft:orange_concrete
fill 259 216 599 262 216 599 minecraft:red_concrete
fill 260 216 557 266 217 557 minecraft:red_concrete
fill 260 216 558 262 216 558 minecraft:orange_concrete
fill 262 216 598 264 216 598 minecraft:orange_concrete
setblock 263 216 599 minecraft:orange_terracotta
fill 264 216 558 266 216 558 minecraft:orange_concrete
fill 264 216 599 268 216 599 minecraft:red_concrete
fill 266 216 598 268 216 598 minecraft:orange_concrete
setblock 267 216 557 minecraft:yellow_concrete
fill 268 216 557 269 221 557 minecraft:red_concrete
fill 268 216 558 270 216 558 minecraft:orange_concrete
fill 269 216 599 270 216 599 minecraft:yellow_concrete
fill 270 216 557 270 217 557 minecraft:yellow_concrete
fill 270 216 598 272 216 598 minecraft:orange_concrete
fill 271 216 557 277 216 557 minecraft:red_concrete
fill 271 216 599 273 217 599 minecraft:red_concrete
fill 272 216 558 274 216 558 minecraft:orange_concrete
fill 274 216 598 276 216 598 minecraft:orange_concrete
setblock 274 216 599 minecraft:orange_terracotta
fill 275 216 599 276 217 599 minecraft:red_concrete
fill 276 216 558 276 216 560 minecraft:orange_concrete
fill 276 216 562 276 216 564 minecraft:orange_concrete
fill 276 216 566 276 216 568 minecraft:orange_concrete
fill 276 216 570 276 216 572 minecraft:orange_concrete
fill 276 216 574 276 216 576 minecraft:orange_concrete
fill 276 216 578 276 216 580 minecraft:orange_concrete
fill 276 216 582 276 216 584 minecraft:orange_concrete
fill 276 216 586 276 216 588 minecraft:orange_concrete
fill 276 216 590 276 216 592 minecraft:orange_concrete
fill 276 216 594 276 216 596 minecraft:orange_concrete
fill 277 216 558 277 216 559 minecraft:yellow_concrete
fill 277 216 560 277 216 564 minecraft:red_concrete
setblock 277 216 565 minecraft:orange_terracotta
fill 277 216 566 277 219 569 minecraft:red_concrete
fill 277 216 570 277 217 571 minecraft:yellow_concrete
fill 277 216 572 277 217 577 minecraft:red_concrete
fill 277 216 578 277 216 579 minecraft:yellow_concrete
fill 277 216 580 277 216 581 minecraft:red_concrete
fill 277 216 582 277 217 582 minecraft:yellow_concrete
setblock 277 216 583 minecraft:red_concrete
fill 277 216 585 277 217 586 minecraft:red_concrete
setblock 277 216 587 minecraft:orange_terracotta
fill 277 216 588 277 221 589 minecraft:red_concrete
fill 277 216 590 277 217 591 minecraft:yellow_concrete
setblock 277 216 592 minecraft:orange_terracotta
fill 277 216 593 277 216 598 minecraft:red_concrete
fill 277 216 599 277 217 599 minecraft:yellow_concrete
setblock 235 217 557 minecraft:yellow_concrete
fill 235 217 561 235 220 561 minecraft:red_concrete
fill 235 217 566 235 219 566 minecraft:red_concrete
setblock 235 217 567 minecraft:orange_terracotta
setblock 235 217 568 minecraft:red_concrete
fill 235 217 572 235 221 572 minecraft:red_concrete
fill 235 217 575 235 217 576 minecraft:red_concrete
fill 235 217 577 235 217 578 minecraft:yellow_concrete
fill 235 217 579 235 217 580 minecraft:red_concrete
setblock 235 217 581 minecraft:yellow_concrete
fill 235 217 582 235 218 582 minecraft:orange_terracotta
fill 235 217 592 235 217 596 minecraft:red_concrete
setblock 235 217 597 minecraft:orange_terracotta
setblock 235 217 598 minecraft:yellow_concrete
setblock 235 217 599 minecraft:red_concrete
setblock 236 217 557 minecraft:orange_terracotta
fill 237 217 557 237 221 557 minecraft:red_concrete
fill 239 217 599 244 217 599 minecraft:red_concrete
setblock 245 217 599 minecraft:yellow_concrete
fill 246 217 557 246 220 557 minecraft:red_concrete
setblock 247 217 557 minecraft:yellow_concrete
fill 248 217 557 249 217 557 minecraft:red_concrete
fill 249 217 599 250 220 599 minecraft:red_concrete
fill 250 217 557 251 217 557 minecraft:yellow_concrete
setblock 251 217 599 minecraft:orange_terracotta
fill 252 217 599 254 217 599 minecraft:red_concrete
fill 253 217 557 254 217 557 minecraft:red_concrete
fill 255 217 557 256 217 557 minecraft:orange_terracotta
setblock 255 217 599 minecraft:orange_terracotta
setblock 256 217 599 minecraft:red_concrete
fill 257 217 557 257 221 557 minecraft:red_concrete
setblock 259 217 599 minecraft:orange_terracotta
fill 260 217 599 260 221 599 minecraft:red_concrete
fill 261 217 599 262 217 599 minecraft:orange_terracotta
fill 263 217 599 265 217 599 minecraft:red_concrete
setblock 266 217 599 minecraft:yellow_concrete
setblock 267 217 557 minecraft:orange_terracotta
fill 267 217 599 268 217 599 minecraft:red_concrete
setblock 269 217 599 minecraft:yellow_concrete
fill 270 217 599 270 220 599 minecraft:red_concrete
setblock 271 217 557 minecraft:yellow_concrete
fill 272 217 557 277 217 557 minecraft:red_concrete
fill 274 217 599 274 219 599 minecraft:red_concrete
setblock 277 217 558 minecraft:orange_terracotta
setblock 277 217 559 minecraft:yellow_concrete
fill 277 217 560 277 217 561 minecraft:red_concrete
setblock 277 217 562 minecraft:yellow_concrete
setblock 277 217 563 minecraft:orange_terracotta
fill 277 217 564 277 217 565 minecraft:red_concrete
fill 277 217 578 277 220 578 minecraft:red_concrete
setblock 277 217 579 minecraft:yellow_concrete
fill 277 217 580 277 221 580 minecraft:red_concrete
setblock 277 217 581 minecraft:orange_terracotta
setblock 277 217 583 minecraft:yellow_concrete
setblock 277 217 584 minecraft:red_concrete
fill 277 217 587 277 219 587 minecraft:red_concrete
fill 277 217 592 277 217 593 minecraft:red_concrete
setblock 277 217 594 minecraft:yellow_concrete
fill 277 217 595 277 218 598 minecraft:red_concrete
fill 235 218 557 235 223 558 minecraft:red_concrete
fill 235 218 567 235 218 568 minecraft:yellow_concrete
fill 235 218 569 235 223 570 minecraft:red_concrete
setblock 235 218 573 minecraft:orange_terracotta
fill 235 218 574 235 218 575 minecraft:red_concrete
fill 235 218 576 235 219 576 minecraft:yellow_concrete
fill 235 218 577 235 223 578 minecraft:red_concrete
setblock 235 218 579 minecraft:yellow_concrete
fill 235 218 580 235 221 581 minecraft:red_concrete
fill 235 218 583 235 221 584 minecraft:red_concrete
setblock 235 218 585 minecraft:orange_terracotta
fill 235 218 586 235 219 586 minecraft:red_concrete
fill 235 218 587 235 219 588 minecraft:yellow_concrete
fill 235 218 589 235 223 590 minecraft:red_concrete
setblock 235 218 592 minecraft:orange_terracotta
fill 235 218 593 235 218 597 minecraft:red_concrete
setblock 235 218 598 minecraft:orange_terracotta
fill 235 218 599 236 218 599 minecraft:yellow_concrete
fill 236 218 557 236 221 557 minecraft:red_concrete
fill 237 218 599 242 219 599 minecraft:red_concrete
fill 238 218 557 239 223 557 minecraft:red_concrete
setblock 238 218 560 minecraft:light[level=14]
setblock 238 218 568 minecraft:light[level=14]
setblock 238 218 576 minecraft:light[level=14]
setblock 238 218 584 minecraft:light[level=14]
setblock 238 218 592 minecraft:light[level=14]
fill 240 218 557 241 219 557 minecraft:yellow_concrete
fill 242 218 557 245 219 557 minecraft:red_concrete
fill 243 218 599 244 219 599 minecraft:yellow_concrete
fill 245 218 599 246 223 599 minecraft:red_concrete
setblock 246 218 560 minecraft:light[level=14]
setblock 246 218 568 minecraft:light[level=14]
setblock 246 218 576 minecraft:light[level=14]
setblock 246 218 584 minecraft:light[level=14]
setblock 246 218 592 minecraft:light[level=14]
fill 247 218 557 248 221 557 minecraft:red_concrete
setblock 247 218 599 minecraft:yellow_concrete
fill 248 218 599 248 221 599 minecraft:red_concrete
setblock 249 218 557 minecraft:yellow_concrete
fill 250 218 557 251 223 557 minecraft:red_concrete
fill 251 218 599 251 221 599 minecraft:red_concrete
fill 252 218 557 252 219 557 minecraft:yellow_concrete
setblock 252 218 599 minecraft:orange_terracotta
setblock 253 218 557 minecraft:red_concrete
fill 253 218 599 254 219 599 minecraft:red_concrete
setblock 254 218 557 minecraft:orange_terracotta
setblock 254 218 560 minecraft:light[level=14]
setblock 254 218 568 minecraft:light[level=14]
setblock 254 218 576 minecraft:light[level=14]
setblock 254 218 584 minecraft:light[level=14]
setblock 254 218 592 minecraft:light[level=14]
fill 255 218 557 256 219 557 minecraft:red_concrete
fill 255 218 599 256 219 599 minecraft:yellow_concrete
fill 257 218 599 259 221 599 minecraft:red_concrete
setblock 258 218 557 minecraft:orange_terracotta
fill 259 218 557 259 223 557 minecraft:red_concrete
fill 260 218 557 261 218 557 minecraft:yellow_concrete
fill 261 218 599 263 218 599 minecraft:red_concrete
fill 262 218 557 264 218 557 minecraft:red_concrete
setblock 262 218 560 minecraft:light[level=14]
setblock 262 218 568 minecraft:light[level=14]
setblock 262 218 576 minecraft:light[level=14]
setblock 262 218 584 minecraft:light[level=14]
setblock 262 218 592 minecraft:light[level=14]
fill 264 218 599 264 219 599 minecraft:yellow_concrete
setblock 265 218 557 minecraft:orange_terracotta
fill 265 218 599 266 219 599 minecraft:red_concrete
fill 266 218 557 267 219 557 minecraft:red_concrete
fill 267 218 599 268 218 599 minecraft:yellow_concrete
fill 269 218 599 269 223 599 minecraft:red_concrete
fill 270 218 557 270 223 557 minecraft:red_concrete
setblock 270 218 560 minecraft:light[level=14]
setblock 270 218 568 minecraft:light[level=14]
setblock 270 218 576 minecraft:light[level=14]
setblock 270 218 584 minecraft:light[level=14]
setblock 270 218 592 minecraft:light[level=14]
setblock 271 218 557 minecraft:orange_terracotta
setblock 271 218 599 minecraft:orange_terracotta
fill 272 218 557 273 219 557 minecraft:yellow_concrete
fill 272 218 599 273 219 599 minecraft:red_concrete
fill 274 218 557 276 219 557 minecraft:red_concrete
fill 275 218 599 276 219 599 minecraft:yellow_concrete
setblock 277 218 557 minecraft:orange_terracotta
fill 277 218 558 277 220 559 minecraft:red_concrete
fill 277 218 560 277 218 561 minecraft:yellow_concrete
fill 277 218 562 277 219 563 minecraft:red_concrete
fill 277 218 564 277 219 564 minecraft:yellow_concrete
setblock 277 218 565 minecraft:red_concrete
fill 277 218 570 277 223 571 minecraft:red_concrete
fill 277 218 572 277 219 573 minecraft:yellow_concrete
fill 277 218 574 277 218 576 minecraft:red_concrete
setblock 277 218 577 minecraft:orange_terracotta
fill 277 218 579 277 220 579 minecraft:red_concrete
setblock 277 218 581 minecraft:yellow_concrete
setblock 277 218 582 minecraft:orange_terracotta
fill 277 218 583 277 223 583 minecraft:red_concrete
fill 277 218 584 277 219 585 minecraft:yellow_concrete
fill 277 218 586 277 219 586 minecraft:red_concrete
fill 277 218 590 277 223 591 minecraft:red_concrete
fill 277 218 592 277 218 593 minecraft:yellow_concrete
fill 277 218 594 277 219 594 minecraft:red_concrete
fill 277 218 599 277 223 599 minecraft:red_concrete
fill 235 219 562 235 219 563 minecraft:red_concrete
setblock 235 219 564 minecraft:yellow_concrete
setblock 235 219 565 minecraft:red_concrete
setblock 235 219 567 minecraft:yellow_concrete
fill 235 219 568 235 222 568 minecraft:red_concrete
fill 235 219 573 235 219 574 minecraft:red_concrete
setblock 235 219 575 minecraft:yellow_concrete
fill 235 219 579 235 222 579 minecraft:red_concrete
fill 235 219 582 235 220 582 minecraft:red_concrete
setblock 235 219 585 minecraft:red_concrete
fill 235 219 592 235 219 594 minecraft:red_concrete
fill 235 219 595 235 219 596 minecraft:yellow_concrete
fill 235 219 597 235 219 598 minecraft:red_concrete
setblock 235 219 599 minecraft:yellow_concrete
fill 236 219 599 236 222 599 minecraft:red_concrete
fill 247 219 599 247 222 599 minecraft:red_concrete
fill 249 219 557 249 222 557 minecraft:red_concrete
setblock 252 219 599 minecraft:yellow_concrete
setblock 253 219 557 minecraft:yellow_concrete
setblock 254 219 557 minecraft:red_concrete
fill 258 219 557 258 223 557 minecraft:red_concrete
fill 260 219 557 260 222 557 minecraft:red_concrete
setblock 261 219 557 minecraft:yellow_concrete
fill 261 219 599 262 219 599 minecraft:red_concrete
fill 262 219 557 263 219 557 minecraft:red_concrete
setblock 263 219 599 minecraft:yellow_concrete
setblock 264 219 557 minecraft:yellow_concrete
fill 265 219 557 265 221 557 minecraft:red_concrete
fill 267 219 599 268 221 599 minecraft:red_concrete
fill 271 219 557 271 223 557 minecraft:red_concrete
fill 271 219 599 271 221 599 minecraft:red_concrete
fill 277 219 557 277 221 557 minecraft:red_concrete
fill 277 219 560 277 222 561 minecraft:red_concrete
setblock 277 219 565 minecraft:yellow_concrete
fill 277 219 574 277 219 575 minecraft:red_concrete
setblock 277 219 576 minecraft:yellow_concrete
fill 277 219 577 277 221 577 minecraft:red_concrete
fill 277 219 581 277 222 582 minecraft:red_concrete
fill 277 219 592 277 222 592 minecraft:red_concrete
setblock 277 219 593 minecraft:yellow_concrete
setblock 277 219 595 minecraft:red_concrete
fill 277 219 596 277 219 597 minecraft:yellow_concrete
setblock 277 219 598 minecraft:red_concrete
fill 235 220 562 235 221 562 minecraft:yellow_concrete
fill 235 220 563 235 221 564 minecraft:red_concrete
fill 235 220 565 235 220 566 minecraft:yellow_concrete
fill 235 220 567 235 225 567 minecraft:red_concrete
fill 235 220 573 235 221 574 minecraft:yellow_concrete
fill 235 220 575 235 225 576 minecraft:red_concrete
fill 235 220 585 235 220 586 minecraft:yellow_concrete
fill 235 220 587 235 225 588 minecraft:red_concrete
fill 235 220 592 235 220 593 minecraft:red_concrete
fill 235 220 594 235 221 594 minecraft:yellow_concrete
fill 235 220 595 235 225 596 minecraft:red_concrete
setblock 235 220 597 minecraft:yellow_concrete
fill 235 220 598 235 223 599 minecraft:red_concrete
fill 237 220 599 240 221 599 minecraft:red_concrete
fill 240 220 557 241 225 557 minecraft:red_concrete
fill 241 220 599 242 221 599 minecraft:yellow_concrete
fill 242 220 557 243 220 557 minecraft:yellow_concrete
fill 243 220 599 244 225 599 minecraft:red_concrete
fill 244 220 557 245 221 557 minecraft:red_concrete
fill 252 220 557 253 225 557 minecraft:red_concrete
fill 252 220 599 252 225 599 minecraft:red_concrete
fill 253 220 599 254 220 599 minecraft:yellow_concrete
fill 254 220 557 255 221 557 minecraft:yellow_concrete
fill 255 220 599 256 225 599 minecraft:red_concrete
fill 256 220 557 256 221 557 minecraft:red_concrete
fill 261 220 557 261 225 557 minecraft:red_concrete
fill 261 220 599 262 221 599 minecraft:yellow_concrete
fill 262 220 557 263 220 557 minecraft:yellow_concrete
fill 263 220 599 264 225 599 minecraft:red_concrete
fill 264 220 557 264 225 557 minecraft:red_concrete
setblock 265 220 599 minecraft:yellow_concrete
fill 266 220 557 266 221 557 minecraft:yellow_concrete
fill 266 220 599 266 223 599 minecraft:red_concrete
setblock 267 220 557 minecraft:red_concrete
fill 272 220 557 273 225 557 minecraft:red_concrete
fill 272 220 599 272 221 599 minecraft:red_concrete
fill 273 220 599 274 221 599 minecraft:yellow_concrete
fill 274 220 557 275 221 557 minecraft:yellow_concrete
fill 275 220 599 276 225 599 minecraft:red_concrete
fill 276 220 557 276 221 557 minecraft:red_concrete
fill 277 220 562 277 223 562 minecraft:red_concrete
setblock 277 220 563 minecraft:yellow_concrete
fill 277 220 564 277 225 565 minecraft:red_concrete
fill 277 220 566 277 221 567 minecraft:yellow_concrete
fill 277 220 568 277 221 569 minecraft:red_concrete
fill 277 220 572 277 225 573 minecraft:red_concrete
fill 277 220 574 277 220 575 minecraft:yellow_concrete
fill 277 220 576 277 225 576 minecraft:red_concrete
fill 277 220 584 277 225 585 minecraft:red_concrete
fill 277 220 586 277 221 587 minecraft:yellow_concrete
fill 277 220 593 277 225 593 minecraft:red_concrete
fill 277 220 594 277 220 595 minecraft:yellow_concrete
fill 277 220 596 277 221 597 minecraft:red_concrete
fill 277 220 598 277 221 598 minecraft:yellow_concrete
setblock 235 221 561 minecraft:yellow_concrete
fill 235 221 565 235 224 566 minecraft:red_concrete
setblock 235 221 582 minecraft:yellow_concrete
setblock 235 221 585 minecraft:yellow_concrete
fill 235 221 586 235 224 586 minecraft:red_concrete
setblock 235 221 592 minecraft:red_concrete
setblock 235 221 593 minecraft:yellow_concrete
fill 235 221 597 235 224 597 minecraft:red_concrete
fill 242 221 557 242 224 557 minecraft:red_concrete
setblock 243 221 557 minecraft:yellow_concrete
setblock 246 221 557 minecraft:yellow_concrete
fill 249 221 599 250 221 599 minecraft:yellow_concrete
setblock 253 221 599 minecraft:yellow_concrete
fill 254 221 599 254 224 599 minecraft:red_concrete
fill 262 221 557 263 224 557 minecraft:red_concrete
fill 265 221 599 265 223 599 minecraft:red_concrete
setblock 267 221 557 minecraft:yellow_concrete
setblock 270 221 599 minecraft:yellow_concrete
setblock 277 221 558 minecraft:yellow_concrete
fill 277 221 559 277 223 559 minecraft:red_concrete
fill 277 221 563 277 224 563 minecraft:red_concrete
fill 277 221 574 277 224 574 minecraft:red_concrete
setblock 277 221 575 minecraft:yellow_concrete
fill 277 221 578 277 221 579 minecraft:yellow_concrete
fill 277 221 594 277 223 595 minecraft:red_concrete
fill 235 222 559 235 223 560 minecraft:yellow_concrete
fill 235 222 561 235 227 562 minecraft:red_concrete
setblock 235 222 563 minecraft:yellow_concrete
fill 235 222 564 235 225 564 minecraft:red_concrete
fill 235 222 571 235 223 572 minecraft:yellow_concrete
fill 235 222 573 235 227 574 minecraft:red_concrete
fill 235 222 580 235 223 580 minecraft:yellow_concrete
fill 235 222 581 235 223 582 minecraft:red_concrete
fill 235 222 583 235 222 584 minecraft:yellow_concrete
fill 235 222 585 235 227 585 minecraft:red_concrete
fill 235 222 591 235 223 592 minecraft:yellow_concrete
fill 235 222 593 235 227 594 minecraft:red_concrete
fill 236 222 557 237 223 557 minecraft:yellow_concrete
fill 236 222 558 238 222 558 minecraft:orange_concrete
fill 236 222 560 236 222 562 minecraft:orange_concrete
fill 236 222 564 236 222 566 minecraft:orange_concrete
fill 236 222 568 236 222 570 minecraft:orange_concrete
fill 236 222 572 236 222 574 minecraft:orange_concrete
fill 236 222 576 236 222 578 minecraft:orange_concrete
fill 236 222 580 236 222 582 minecraft:orange_concrete
fill 236 222 584 236 222 586 minecraft:orange_concrete
fill 236 222 588 236 222 590 minecraft:orange_concrete
fill 236 222 592 236 222 594 minecraft:orange_concrete
fill 236 222 596 236 222 598 minecraft:orange_concrete
fill 237 222 599 238 223 599 minecraft:red_concrete
fill 238 222 598 240 222 598 minecraft:orange_concrete
fill 239 222 599 240 222 599 minecraft:yellow_concrete
fill 240 222 558 242 222 558 minecraft:orange_concrete
fill 241 222 599 242 227 599 minecraft:red_concrete
fill 242 222 598 244 222 598 minecraft:orange_concrete
fill 243 222 557 243 227 557 minecraft:red_concrete
fill 244 222 557 245 222 557 minecraft:yellow_concrete
fill 244 222 558 246 222 558 minecraft:orange_concrete
fill 246 222 557 247 223 557 minecraft:red_concrete
fill 246 222 598 248 222 598 minecraft:orange_concrete
fill 248 222 557 248 223 557 minecraft:yellow_concrete
fill 248 222 558 250 222 558 minecraft:orange_concrete
fill 248 222 599 248 223 599 minecraft:yellow_concrete
fill 249 222 599 250 227 599 minecraft:red_concrete
fill 250 222 598 252 222 598 minecraft:orange_concrete
setblock 251 222 599 minecraft:yellow_concrete
fill 252 222 558 254 222 558 minecraft:orange_concrete
fill 253 222 599 253 227 599 minecraft:red_concrete
fill 254 222 557 255 227 557 minecraft:red_concrete
fill 254 222 598 256 222 598 minecraft:orange_concrete
fill 256 222 557 257 223 557 minecraft:yellow_concrete
fill 256 222 558 258 222 558 minecraft:orange_concrete
fill 257 222 599 258 223 599 minecraft:red_concrete
fill 258 222 598 260 222 598 minecraft:orange_concrete
fill 259 222 599 260 223 599 minecraft:yellow_concrete
fill 260 222 558 262 222 558 minecraft:orange_concrete
fill 261 222 599 262 227 599 minecraft:red_concrete
fill 262 222 598 264 222 598 minecraft:orange_concrete
fill 264 222 558 266 222 558 minecraft:orange_concrete
setblock 265 222 557 minecraft:yellow_concrete
fill 266 222 557 267 227 557 minecraft:red_concrete
fill 266 222 598 268 222 598 minecraft:orange_concrete
setblock 267 222 599 minecraft:red_concrete
fill 268 222 557 269 223 557 minecraft:yellow_concrete
fill 268 222 558 270 222 558 minecraft:orange_concrete
fill 268 222 599 268 223 599 minecraft:yellow_concrete
fill 270 222 598 272 222 598 minecraft:orange_concrete
fill 270 222 599 270 227 599 minecraft:red_concrete
fill 271 222 599 272 222 599 minecraft:yellow_concrete
fill 272 222 558 274 222 558 minecraft:orange_concrete
fill 273 222 599 274 224 599 minecraft:red_concrete
fill 274 222 557 275 227 557 minecraft:red_concrete
fill 274 222 598 276 222 598 minecraft:orange_concrete
fill 276 222 557 277 222 557 minecraft:yellow_concrete
fill 276 222 558 276 222 560 minecraft:orange_concrete
fill 276 222 562 276 222 564 minecraft:orange_concrete
fill 276 222 566 276 222 568 minecraft:orange_concrete
fill 276 222 570 276 222 572 minecraft:orange_concrete
fill 276 222 574 276 222 576 minecraft:orange_concrete
fill 276 222 578 276 222 580 minecraft:orange_concrete
fill 276 222 582 276 222 584 minecraft:orange_concrete
fill 276 222 586 276 222 588 minecraft:orange_concrete
fill 276 222 590 276 222 592 minecraft:orange_concrete
fill 276 222 594 276 222 596 minecraft:orange_concrete
fill 277 222 558 277 227 558 minecraft:red_concrete
fill 277 222 566 277 227 567 minecraft:red_concrete
fill 277 222 568 277 223 569 minecraft:yellow_concrete
fill 277 222 575 277 227 575 minecraft:red_concrete
setblock 277 222 577 minecraft:yellow_concrete
fill 277 222 578 277 227 579 minecraft:red_concrete
fill 277 222 580 277 223 580 minecraft:yellow_concrete
fill 277 222 586 277 227 587 minecraft:red_concrete
fill 277 222 588 277 223 589 minecraft:yellow_concrete
fill 277 222 596 277 225 596 minecraft:red_concrete
setblock 277 222 597 minecraft:yellow_concrete
fill 277 222 598 277 227 598 minecraft:red_concrete
fill 235 223 563 235 226 563 minecraft:red_concrete
setblock 235 223 568 minecraft:yellow_concrete
setblock 235 223 579 minecraft:yellow_concrete
fill 235 223 583 235 226 584 minecraft:red_concrete
setblock 236 223 599 minecraft:yellow_concrete
setblock 239 223 599 minecraft:yellow_concrete
fill 240 223 599 240 226 599 minecraft:red_concrete
fill 244 223 557 245 226 557 minecraft:red_concrete
setblock 247 223 599 minecraft:yellow_concrete
setblock 249 223 557 minecraft:yellow_concrete
fill 251 223 599 251 226 599 minecraft:red_concrete
fill 253 223 569 253 224 569 minecraft:shroomlight
setblock 260 223 557 minecraft:yellow_concrete
fill 265 223 557 265 226 557 minecraft:red_concrete
setblock 267 223 599 minecraft:yellow_concrete
fill 268 223 572 269 224 573 minecraft:yellow_concrete
setblock 271 223 599 minecraft:yellow_concrete
fill 272 223 599 272 226 599 minecraft:red_concrete
fill 276 223 557 276 226 557 minecraft:red_concrete
setblock 277 223 557 minecraft:yellow_concrete
fill 277 223 560 277 223 561 minecraft:yellow_concrete
fill 277 223 577 277 226 577 minecraft:red_concrete
setblock 277 223 581 minecraft:yellow_concrete
setblock 277 223 582 minecraft:red_concrete
setblock 277 223 592 minecraft:yellow_concrete
fill 277 223 597 277 225 597 minecraft:red_concrete
fill 235 224 557 235 225 558 minecraft:yellow_concrete
fill 235 224 559 235 229 560 minecraft:red_concrete
fill 235 224 568 235 229 568 minecraft:red_concrete
fill 235 224 569 235 224 570 minecraft:yellow_concrete
fill 235 224 571 235 229 572 minecraft:red_concrete
fill 235 224 577 235 225 578 minecraft:yellow_concrete
fill 235 224 579 235 229 580 minecraft:red_concrete
setblock 235 224 581 minecraft:yellow_concrete
fill 235 224 582 235 227 582 minecraft:red_concrete
fill 235 224 589 235 225 590 minecraft:yellow_concrete
fill 235 224 591 235 229 592 minecraft:red_concrete
fill 235 224 598 235 225 598 minecraft:yellow_concrete
fill 235 224 599 236 225 599 minecraft:red_concrete
fill 236 224 557 237 229 557 minecraft:red_concrete
fill 237 224 599 238 224 599 minecraft:yellow_concrete
fill 238 224 557 239 225 557 minecraft:yellow_concrete
fill 239 224 599 239 229 599 minecraft:red_concrete
fill 245 224 599 246 225 599 minecraft:yellow_concrete
fill 246 224 557 246 227 557 minecraft:red_concrete
setblock 247 224 557 minecraft:yellow_concrete
fill 247 224 599 248 229 599 minecraft:red_concrete
fill 248 224 557 249 229 557 minecraft:red_concrete
fill 250 224 557 251 225 557 minecraft:yellow_concrete
fill 256 224 557 257 229 557 minecraft:red_concrete
fill 257 224 599 258 224 599 minecraft:yellow_concrete
fill 258 224 557 259 224 557 minecraft:yellow_concrete
fill 259 224 599 260 229 599 minecraft:red_concrete
fill 260 224 557 260 229 557 minecraft:red_concrete
fill 265 224 599 266 225 599 minecraft:yellow_concrete
fill 267 224 599 268 229 599 minecraft:red_concrete
fill 268 224 557 269 229 557 minecraft:red_concrete
setblock 269 224 599 minecraft:yellow_concrete
fill 270 224 557 271 225 557 minecraft:yellow_concrete
fill 271 224 599 271 226 599 minecraft:red_concrete
fill 277 224 557 277 229 557 minecraft:red_concrete
setblock 277 224 559 minecraft:yellow_concrete
fill 277 224 560 277 229 561 minecraft:red_concrete
fill 277 224 562 277 225 562 minecraft:yellow_concrete
fill 277 224 568 277 229 569 minecraft:red_concrete
fill 277 224 570 277 224 571 minecraft:yellow_concrete
fill 277 224 580 277 229 581 minecraft:red_concrete
fill 277 224 582 277 225 583 minecraft:yellow_concrete
fill 277 224 588 277 226 589 minecraft:red_concrete
fill 277 224 590 277 224 591 minecraft:yellow_concrete
fill 277 224 592 277 229 592 minecraft:red_concrete
fill 277 224 594 277 225 594 minecraft:yellow_concrete
setblock 277 224 595 minecraft:red_concrete
fill 277 224 599 277 225 599 minecraft:yellow_concrete
fill 235 225 565 235 225 566 minecraft:yellow_concrete
setblock 235 225 569 minecraft:yellow_concrete
fill 235 225 570 235 228 570 minecraft:red_concrete
fill 235 225 581 235 228 581 minecraft:red_concrete
setblock 235 225 586 minecraft:yellow_concrete
setblock 235 225 597 minecraft:yellow_concrete
fill 237 225 599 238 228 599 minecraft:red_concrete
setblock 242 225 557 minecraft:yellow_concrete
fill 247 225 557 247 228 557 minecraft:red_concrete
setblock 254 225 599 minecraft:yellow_concrete
setblock 257 225 599 minecraft:yellow_concrete
fill 258 225 557 258 228 557 minecraft:red_concrete
fill 258 225 599 258 228 599 minecraft:red_concrete
setblock 259 225 557 minecraft:yellow_concrete
fill 262 225 557 263 225 557 minecraft:yellow_concrete
fill 269 225 599 269 228 599 minecraft:red_concrete
fill 273 225 599 273 227 599 minecraft:red_concrete
setblock 274 225 599 minecraft:yellow_concrete
fill 277 225 559 277 228 559 minecraft:red_concrete
setblock 277 225 563 minecraft:yellow_concrete
fill 277 225 570 277 228 570 minecraft:red_concrete
setblock 277 225 571 minecraft:yellow_concrete
setblock 277 225 574 minecraft:yellow_concrete
fill 277 225 590 277 228 590 minecraft:red_concrete
setblock 277 225 591 minecraft:yellow_concrete
setblock 277 225 595 minecraft:yellow_concrete
fill 235 226 557 235 243 558 minecraft:red_concrete
fill 235 226 564 235 227 564 minecraft:yellow_concrete
fill 235 226 565 235 247 566 minecraft:red_concrete
setblock 235 226 567 minecraft:yellow_concrete
fill 235 226 569 235 243 569 minecraft:red_concrete
fill 235 226 575 235 227 576 minecraft:yellow_concrete
fill 235 226 577 235 244 578 minecraft:red_concrete
fill 235 226 586 235 247 586 minecraft:red_concrete
fill 235 226 587 235 226 588 minecraft:yellow_concrete
fill 235 226 589 235 243 590 minecraft:red_concrete
fill 235 226 595 235 227 596 minecraft:yellow_concrete
fill 235 226 597 235 244 598 minecraft:red_concrete
setblock 235 226 599 minecraft:yellow_concrete
fill 236 226 599 236 229 599 minecraft:red_concrete
fill 238 226 557 239 243 557 minecraft:red_concrete
setblock 238 226 560 minecraft:light[level=14]
setblock 238 226 568 minecraft:light[level=14]
setblock 238 226 576 minecraft:light[level=14]
setblock 238 226 584 minecraft:light[level=14]
setblock 238 226 592 minecraft:light[level=14]
fill 240 226 557 241 226 557 minecraft:yellow_concrete
fill 242 226 557 242 247 557 minecraft:red_concrete
fill 243 226 599 244 227 599 minecraft:yellow_concrete
fill 245 226 599 246 243 599 minecraft:red_concrete
setblock 246 226 560 minecraft:light[level=14]
setblock 246 226 568 minecraft:light[level=14]
setblock 246 226 576 minecraft:light[level=14]
setblock 246 226 584 minecraft:light[level=14]
setblock 246 226 592 minecraft:light[level=14]
fill 250 226 557 251 244 557 minecraft:red_concrete
fill 252 226 557 253 227 557 minecraft:yellow_concrete
fill 252 226 599 252 227 599 minecraft:yellow_concrete
setblock 254 226 560 minecraft:light[level=14]
setblock 254 226 568 minecraft:light[level=14]
setblock 254 226 576 minecraft:light[level=14]
setblock 254 226 584 minecraft:light[level=14]
setblock 254 226 592 minecraft:light[level=14]
fill 254 226 599 254 247 599 minecraft:red_concrete
fill 255 226 599 256 226 599 minecraft:yellow_concrete
fill 257 226 599 257 243 599 minecraft:red_concrete
fill 259 226 557 259 243 557 minecraft:red_concrete
setblock 261 226 557 minecraft:yellow_concrete
fill 262 226 557 263 247 557 minecraft:red_concrete
setblock 262 226 560 minecraft:light[level=14]
setblock 262 226 568 minecraft:light[level=14]
setblock 262 226 576 minecraft:light[level=14]
setblock 262 226 584 minecraft:light[level=14]
setblock 262 226 592 minecraft:light[level=14]
fill 263 226 599 264 227 599 minecraft:yellow_concrete
fill 264 226 557 264 227 557 minecraft:yellow_concrete
fill 265 226 599 266 244 599 minecraft:red_concrete
fill 270 226 557 271 243 557 minecraft:red_concrete
setblock 270 226 560 minecraft:light[level=14]
setblock 270 226 568 minecraft:light[level=14]
setblock 270 226 576 minecraft:light[level=14]
setblock 270 226 584 minecraft:light[level=14]
setblock 270 226 592 minecraft:light[level=14]
fill 272 226 557 273 226 557 minecraft:yellow_concrete
fill 274 226 599 274 227 599 minecraft:red_concrete
fill 275 226 599 276 226 599 minecraft:yellow_concrete
fill 277 226 562 277 244 563 minecraft:red_concrete
fill 277 226 564 277 227 565 minecraft:yellow_concrete
fill 277 226 571 277 243 571 minecraft:red_concrete
fill 277 226 572 277 226 573 minecraft:yellow_concrete
fill 277 226 574 277 247 574 minecraft:red_concrete
fill 277 226 576 277 227 576 minecraft:yellow_concrete
fill 277 226 582 277 243 583 minecraft:red_concrete
fill 277 226 584 277 227 585 minecraft:yellow_concrete
fill 277 226 591 277 228 591 minecraft:red_concrete
setblock 277 226 593 minecraft:yellow_concrete
fill 277 226 594 277 244 595 minecraft:red_concrete
fill 277 226 596 277 227 597 minecraft:yellow_concrete
fill 277 226 599 277 243 599 minecraft:red_concrete
setblock 235 227 563 minecraft:yellow_concrete
fill 235 227 567 235 230 567 minecraft:red_concrete
fill 235 227 583 235 227 584 minecraft:yellow_concrete
setblock 235 227 587 minecraft:yellow_concrete
fill 235 227 588 235 230 588 minecraft:red_concrete
fill 235 227 599 235 230 599 minecraft:red_concrete
fill 240 227 557 240 230 557 minecraft:red_concrete
setblock 240 227 599 minecraft:yellow_concrete
setblock 241 227 557 minecraft:yellow_concrete
fill 244 227 557 245 227 557 minecraft:yellow_concrete
setblock 251 227 599 minecraft:yellow_concrete
fill 255 227 599 256 229 599 minecraft:red_concrete
fill 261 227 557 261 230 557 minecraft:red_concrete
setblock 265 227 557 minecraft:yellow_concrete
fill 271 227 599 272 227 599 minecraft:yellow_concrete
fill 272 227 557 272 230 557 minecraft:red_concrete
setblock 273 227 557 minecraft:yellow_concrete
setblock 275 227 599 minecraft:yellow_concrete
setblock 276 227 557 minecraft:yellow_concrete
fill 276 227 599 276 230 599 minecraft:red_concrete
fill 277 227 572 277 230 573 minecraft:red_concrete
setblock 277 227 577 minecraft:yellow_concrete
setblock 277 227 588 minecraft:yellow_concrete
fill 277 227 589 277 229 589 minecraft:red_concrete
fill 277 227 593 277 230 593 minecraft:red_concrete
fill 235 228 561 235 229 562 minecraft:yellow_concrete
fill 235 228 563 235 241 564 minecraft:red_concrete
fill 235 228 573 235 228 574 minecraft:yellow_concrete
fill 235 228 575 235 241 576 minecraft:red_concrete
fill 235 228 582 235 229 582 minecraft:yellow_concrete
fill 235 228 583 235 241 584 minecraft:red_concrete
setblock 235 228 585 minecraft:yellow_concrete
fill 235 228 587 235 245 587 minecraft:red_concrete
fill 235 228 593 235 229 594 minecraft:yellow_concrete
fill 235 228 595 235 241 596 minecraft:red_concrete
fill 236 228 558 238 228 558 minecraft:orange_concrete
fill 236 228 560 236 228 562 minecraft:orange_concrete
fill 236 228 564 236 228 566 minecraft:orange_concrete
fill 236 228 568 236 228 570 minecraft:orange_concrete
fill 236 228 572 236 228 574 minecraft:orange_concrete
fill 236 228 576 236 228 578 minecraft:orange_concrete
fill 236 228 580 236 228 582 minecraft:orange_concrete
fill 236 228 584 236 228 586 minecraft:orange_concrete
fill 236 228 588 236 228 590 minecraft:orange_concrete
fill 236 228 592 236 228 594 minecraft:orange_concrete
fill 236 228 596 236 228 598 minecraft:orange_concrete
fill 238 228 598 240 228 598 minecraft:orange_concrete
fill 240 228 558 242 228 558 minecraft:orange_concrete
fill 240 228 599 240 241 599 minecraft:red_concrete
fill 241 228 557 241 245 557 minecraft:red_concrete
fill 241 228 599 242 228 599 minecraft:yellow_concrete
fill 242 228 598 244 228 598 minecraft:orange_concrete
setblock 243 228 557 minecraft:yellow_concrete
fill 243 228 599 244 245 599 minecraft:red_concrete
fill 244 228 557 245 241 557 minecraft:red_concrete
fill 244 228 558 246 228 558 minecraft:orange_concrete
fill 246 228 557 246 229 557 minecraft:yellow_concrete
fill 246 228 598 248 228 598 minecraft:orange_concrete
fill 248 228 558 250 228 558 minecraft:orange_concrete
fill 249 228 599 250 229 599 minecraft:yellow_concrete
fill 250 228 598 252 228 598 minecraft:orange_concrete
fill 251 228 599 252 241 599 minecraft:red_concrete
fill 252 228 557 253 241 557 minecraft:red_concrete
fill 252 228 558 254 228 558 minecraft:orange_concrete
setblock 253 228 599 minecraft:yellow_concrete
fill 254 228 557 255 228 557 minecraft:yellow_concrete
fill 254 228 598 256 228 598 minecraft:orange_concrete
fill 256 228 558 258 228 558 minecraft:orange_concrete
fill 258 228 598 260 228 598 minecraft:orange_concrete
fill 260 228 558 262 228 558 minecraft:orange_concrete
fill 261 228 599 262 229 599 minecraft:yellow_concrete
fill 262 228 598 264 228 598 minecraft:orange_concrete
fill 263 228 599 264 241 599 minecraft:red_concrete
fill 264 228 557 265 241 557 minecraft:red_concrete
fill 264 228 558 266 228 558 minecraft:orange_concrete
fill 266 228 557 267 229 557 minecraft:yellow_concrete
fill 266 228 598 268 228 598 minecraft:orange_concrete
fill 268 228 558 270 228 558 minecraft:orange_concrete
fill 270 228 598 272 228 598 minecraft:orange_concrete
fill 270 228 599 270 229 599 minecraft:yellow_concrete
fill 271 228 599 272 229 599 minecraft:red_concrete
fill 272 228 558 274 228 558 minecraft:orange_concrete
fill 273 228 557 273 245 557 minecraft:red_concrete
fill 273 228 599 274 228 599 minecraft:yellow_concrete
fill 274 228 557 275 228 557 minecraft:yellow_concrete
fill 274 228 598 276 228 598 minecraft:orange_concrete
fill 275 228 592 275 231 592 minecraft:magma_block
fill 275 228 599 275 245 599 minecraft:red_concrete
fill 276 228 557 276 241 557 minecraft:red_concrete
fill 276 228 558 276 228 560 minecraft:orange_concrete
fill 276 228 562 276 228 564 minecraft:orange_concrete
fill 276 228 566 276 228 568 minecraft:orange_concrete
fill 276 228 570 276 228 572 minecraft:orange_concrete
fill 276 228 574 276 228 576 minecraft:orange_concrete
fill 276 228 578 276 228 580 minecraft:orange_concrete
fill 276 228 582 276 228 584 minecraft:orange_concrete
fill 276 228 586 276 228 588 minecraft:orange_concrete
fill 276 228 590 276 228 592 minecraft:orange_concrete
fill 276 228 594 276 228 596 minecraft:orange_concrete
fill 277 228 558 277 229 558 minecraft:yellow_concrete
fill 277 228 564 277 241 565 minecraft:red_concrete
fill 277 228 566 277 229 567 minecraft:yellow_concrete
setblock 277 228 575 minecraft:yellow_concrete
fill 277 228 576 277 241 577 minecraft:red_concrete
fill 277 228 578 277 229 579 minecraft:yellow_concrete
fill 277 228 584 277 245 585 minecraft:red_concrete
fill 277 228 586 277 228 587 minecraft:yellow_concrete
fill 277 228 588 277 241 588 minecraft:red_concrete
fill 277 228 596 277 241 597 minecraft:red_concrete
fill 277 228 598 277 229 598 minecraft:yellow_concrete
setblock 235 229 570 minecraft:yellow_concrete
setblock 235 229 573 minecraft:yellow_concrete
fill 235 229 574 235 247 574 minecraft:red_concrete
setblock 235 229 581 minecraft:yellow_concrete
fill 235 229 585 235 247 585 minecraft:red_concrete
fill 237 229 599 238 229 599 minecraft:yellow_concrete
fill 241 229 569 242 230 569 minecraft:yellow_concrete
setblock 241 229 599 minecraft:yellow_concrete
fill 242 229 599 242 247 599 minecraft:red_concrete
fill 243 229 557 243 247 557 minecraft:red_concrete
setblock 247 229 557 minecraft:yellow_concrete
fill 253 229 599 253 247 599 minecraft:red_concrete
fill 254 229 557 254 247 557 minecraft:red_concrete
setblock 255 229 557 minecraft:yellow_concrete
setblock 258 229 557 minecraft:yellow_concrete
setblock 258 229 599 minecraft:yellow_concrete
setblock 269 229 599 minecraft:yellow_concrete
fill 273 229 592 274 231 592 minecraft:magma_block
fill 273 229 599 274 247 599 minecraft:red_concrete
fill 274 229 557 275 247 557 minecraft:red_concrete
fill 274 229 591 276 231 591 minecraft:magma_block
fill 274 229 593 276 231 593 minecraft:magma_block
fill 275 229 590 275 231 590 minecraft:magma_block
fill 275 229 594 275 231 594 minecraft:magma_block
fill 276 229 592 276 231 592 minecraft:magma_block
setblock 277 229 559 minecraft:yellow_concrete
setblock 277 229 570 minecraft:yellow_concrete
fill 277 229 575 277 247 575 minecraft:red_concrete
fill 277 229 586 277 247 586 minecraft:red_concrete
setblock 277 229 587 minecraft:yellow_concrete
fill 277 229 590 277 229 591 minecraft:yellow_concrete
fill 235 230 559 235 231 560 minecraft:yellow_concrete
fill 235 230 561 235 243 562 minecraft:red_concrete
fill 235 230 568 235 231 568 minecraft:yellow_concrete
fill 235 230 570 235 243 570 minecraft:red_concrete
fill 235 230 571 235 230 572 minecraft:yellow_concrete
fill 235 230 573 235 247 573 minecraft:red_concrete
fill 235 230 579 235 231 580 minecraft:yellow_concrete
fill 235 230 581 235 243 582 minecraft:red_concrete
fill 235 230 591 235 230 592 minecraft:yellow_concrete
fill 235 230 593 235 243 594 minecraft:red_concrete
fill 236 230 557 237 230 557 minecraft:yellow_concrete
fill 236 230 599 236 231 599 minecraft:yellow_concrete
fill 237 230 599 238 243 599 minecraft:red_concrete
setblock 239 230 599 minecraft:yellow_concrete
fill 241 230 599 241 247 599 minecraft:red_concrete
fill 246 230 557 247 243 557 minecraft:red_concrete
fill 247 230 599 248 231 599 minecraft:yellow_concrete
fill 248 230 557 249 231 557 minecraft:yellow_concrete
fill 249 230 599 250 243 599 minecraft:red_concrete
fill 255 230 557 255 247 557 minecraft:red_concrete
setblock 255 230 599 minecraft:red_concrete
fill 256 230 557 257 230 557 minecraft:yellow_concrete
fill 256 230 599 256 231 599 minecraft:yellow_concrete
fill 258 230 557 258 243 557 minecraft:red_concrete
fill 258 230 599 258 243 599 minecraft:red_concrete
fill 259 230 599 260 230 599 minecraft:yellow_concrete
fill 260 230 557 260 231 557 minecraft:yellow_concrete
fill 261 230 599 262 247 599 minecraft:red_concrete
fill 266 230 557 267 243 557 minecraft:red_concrete
fill 267 230 599 268 231 599 minecraft:yellow_concrete
fill 268 230 557 269 231 557 minecraft:yellow_concrete
fill 269 230 599 270 243 599 minecraft:red_concrete
setblock 271 230 599 minecraft:yellow_concrete
fill 272 230 592 272 231 592 minecraft:magma_block
fill 272 230 599 272 241 599 minecraft:red_concrete
fill 273 230 591 273 231 591 minecraft:magma_block
fill 273 230 593 273 231 593 minecraft:magma_block
fill 274 230 590 274 231 590 minecraft:magma_block
fill 274 230 594 274 231 594 minecraft:magma_block
fill 276 230 590 276 231 590 minecraft:magma_block
fill 276 230 594 276 231 594 minecraft:magma_block
setblock 277 230 557 minecraft:yellow_concrete
fill 277 230 558 277 243 559 minecraft:red_concrete
fill 277 230 560 277 231 561 minecraft:yellow_concrete
fill 277 230 566 277 247 567 minecraft:red_concrete
fill 277 230 568 277 230 569 minecraft:yellow_concrete
fill 277 230 570 277 243 570 minecraft:red_concrete
fill 277 230 578 277 243 579 minecraft:red_concrete
fill 277 230 580 277 231 581 minecraft:yellow_concrete
fill 277 230 587 277 247 587 minecraft:red_concrete
setblock 277 230 589 minecraft:yellow_concrete
fill 277 230 590 277 243 591 minecraft:red_concrete
fill 277 230 592 277 231 592 minecraft:yellow_concrete
fill 277 230 598 277 247 598 minecraft:red_concrete
setblock 235 231 567 minecraft:yellow_concrete
fill 235 231 571 235 241 572 minecraft:red_concrete
setblock 235 231 588 minecraft:yellow_concrete
setblock 235 231 591 minecraft:yellow_concrete
fill 235 231 592 235 241 592 minecraft:red_concrete
setblock 235 231 599 minecraft:yellow_concrete
fill 236 231 557 236 241 557 minecraft:red_concrete
setblock 237 231 557 minecraft:yellow_concrete
fill 239 231 599 239 241 599 minecraft:red_concrete
setblock 240 231 557 minecraft:yellow_concrete
setblock 255 231 599 minecraft:yellow_concrete
fill 256 231 557 257 241 557 minecraft:red_concrete
setblock 259 231 599 minecraft:yellow_concrete
fill 260 231 599 260 241 599 minecraft:red_concrete
setblock 261 231 557 minecraft:yellow_concrete
setblock 271 231 592 minecraft:magma_block
fill 271 231 599 271 241 599 minecraft:red_concrete
setblock 272 231 557 minecraft:yellow_concrete
setblock 272 231 591 minecraft:magma_block
setblock 272 231 593 minecraft:magma_block
setblock 273 231 590 minecraft:magma_block
setblock 273 231 594 minecraft:magma_block
setblock 276 231 599 minecraft:yellow_concrete
fill 277 231 557 277 241 557 minecraft:red_concrete
fill 277 231 568 277 241 568 minecraft:red_concrete
setblock 277 231 569 minecraft:yellow_concrete
fill 277 231 572 277 231 573 minecraft:yellow_concrete
fill 277 231 589 277 241 589 minecraft:red_concrete
setblock 277 231 593 minecraft:yellow_concrete
fill 235 232 559 235 242 560 minecraft:red_concrete
fill 235 232 567 235 245 568 minecraft:red_concrete
fill 235 232 579 235 242 580 minecraft:red_concrete
fill 235 232 588 235 245 588 minecraft:red_concrete
fill 235 232 591 235 242 591 minecraft:red_concrete
fill 235 232 599 236 245 599 minecraft:red_concrete
fill 237 232 557 237 242 557 minecraft:red_concrete
fill 240 232 557 240 245 557 minecraft:red_concrete
fill 247 232 599 248 242 599 minecraft:red_concrete
fill 248 232 557 249 242 557 minecraft:red_concrete
fill 255 232 599 256 245 599 minecraft:red_concrete
fill 259 232 599 259 241 599 minecraft:red_concrete
fill 260 232 557 261 245 557 minecraft:red_concrete
fill 267 232 599 268 242 599 minecraft:red_concrete
fill 268 232 557 269 242 557 minecraft:red_concrete
fill 272 232 557 272 245 557 minecraft:red_concrete
fill 276 232 599 276 245 599 minecraft:red_concrete
fill 277 232 560 277 245 561 minecraft:red_concrete
fill 277 232 569 277 242 569 minecraft:red_concrete
fill 277 232 572 277 245 573 minecraft:red_concrete
fill 277 232 580 277 242 581 minecraft:red_concrete
fill 277 232 592 277 245 593 minecraft:red_concrete
setblock 238 234 560 minecraft:light[level=14]
setblock 238 234 568 minecraft:light[level=14]
setblock 238 234 576 minecraft:light[level=14]
setblock 238 234 584 minecraft:light[level=14]
setblock 238 234 592 minecraft:light[level=14]
setblock 246 234 560 minecraft:light[level=14]
setblock 246 234 568 minecraft:light[level=14]
setblock 246 234 576 minecraft:light[level=14]
setblock 246 234 584 minecraft:light[level=14]
setblock 246 234 592 minecraft:light[level=14]
setblock 254 234 560 minecraft:light[level=14]
setblock 254 234 568 minecraft:light[level=14]
setblock 254 234 576 minecraft:light[level=14]
setblock 254 234 584 minecraft:light[level=14]
setblock 254 234 592 minecraft:light[level=14]
setblock 262 234 560 minecraft:light[level=14]
setblock 262 234 568 minecraft:light[level=14]
setblock 262 234 576 minecraft:light[level=14]
setblock 262 234 584 minecraft:light[level=14]
setblock 262 234 592 minecraft:light[level=14]
setblock 270 234 560 minecraft:light[level=14]
setblock 270 234 568 minecraft:light[level=14]
setblock 270 234 576 minecraft:light[level=14]
setblock 270 234 584 minecraft:light[level=14]
setblock 270 234 592 minecraft:light[level=14]
fill 248 236 578 250 236 580 minecraft:redstone_block
fill 253 236 573 255 236 575 minecraft:redstone_block
fill 253 236 583 255 236 585 minecraft:redstone_block
fill 236 237 558 238 238 598 minecraft:orange_concrete
fill 239 237 558 242 238 598 minecraft:red_concrete
fill 243 237 558 245 238 598 minecraft:orange_concrete
fill 246 237 558 247 237 598 minecraft:red_concrete
fill 248 237 558 250 237 577 minecraft:red_concrete
fill 248 237 581 250 237 598 minecraft:red_concrete
fill 251 237 558 252 237 598 minecraft:orange_concrete
fill 253 237 558 253 237 572 minecraft:orange_concrete
fill 253 237 576 253 237 577 minecraft:orange_concrete
fill 253 237 581 253 237 582 minecraft:orange_concrete
fill 253 237 586 253 237 598 minecraft:orange_concrete
fill 254 237 558 258 237 572 minecraft:red_concrete
fill 254 237 576 258 237 577 minecraft:red_concrete
fill 254 237 581 258 237 582 minecraft:red_concrete
fill 254 237 586 258 237 598 minecraft:red_concrete
fill 256 237 573 258 237 575 minecraft:red_concrete
fill 256 237 578 258 237 580 minecraft:red_concrete
fill 256 237 583 258 237 585 minecraft:red_concrete
fill 259 237 558 261 238 598 minecraft:orange_concrete
fill 262 237 558 266 238 598 minecraft:red_concrete
fill 267 237 558 269 238 598 minecraft:orange_concrete
fill 270 237 558 274 238 598 minecraft:red_concrete
fill 275 237 558 276 238 598 minecraft:orange_concrete
fill 246 238 558 246 238 598 minecraft:red_concrete
fill 247 238 558 250 238 576 minecraft:red_concrete
fill 247 238 577 247 238 581 minecraft:shroomlight
fill 247 238 582 250 238 598 minecraft:red_concrete
fill 248 238 577 256 238 577 minecraft:shroomlight
fill 248 238 578 250 238 580 minecraft:red_concrete
fill 248 238 581 256 238 581 minecraft:shroomlight
fill 251 238 558 251 238 576 minecraft:orange_concrete
fill 251 238 578 252 238 580 minecraft:shroomlight
fill 251 238 582 251 238 598 minecraft:orange_concrete
fill 252 238 558 253 238 571 minecraft:orange_concrete
fill 252 238 572 252 238 576 minecraft:shroomlight
fill 252 238 582 252 238 586 minecraft:shroomlight
fill 252 238 587 253 238 598 minecraft:orange_concrete
fill 253 238 572 256 238 572 minecraft:shroomlight
fill 253 238 573 255 238 575 minecraft:red_concrete
fill 253 238 576 256 238 576 minecraft:shroomlight
fill 253 238 582 256 238 582 minecraft:shroomlight
fill 253 238 583 255 238 585 minecraft:red_concrete
fill 253 238 586 256 238 586 minecraft:shroomlight
fill 254 238 558 258 238 571 minecraft:red_concrete
fill 254 238 587 258 238 598 minecraft:red_concrete
fill 256 238 573 256 238 575 minecraft:shroomlight
fill 256 238 578 256 238 580 minecraft:shroomlight
fill 256 238 583 256 238 585 minecraft:shroomlight
fill 257 238 572 258 238 586 minecraft:red_concrete
fill 235 242 563 235 242 564 minecraft:yellow_concrete
fill 235 242 571 235 243 572 minecraft:yellow_concrete
setblock 235 242 575 minecraft:yellow_concrete
fill 235 242 576 235 245 576 minecraft:red_concrete
fill 235 242 583 235 243 584 minecraft:yellow_concrete
fill 235 242 592 235 243 592 minecraft:yellow_concrete
fill 235 242 595 235 242 596 minecraft:yellow_concrete
fill 236 242 557 236 243 557 minecraft:yellow_concrete
setblock 238 242 560 minecraft:light[level=14]
setblock 238 242 568 minecraft:light[level=14]
setblock 238 242 576 minecraft:light[level=14]
setblock 238 242 584 minecraft:light[level=14]
setblock 238 242 592 minecraft:light[level=14]
fill 239 242 599 240 243 599 minecraft:yellow_concrete
fill 244 242 557 245 243 557 minecraft:yellow_concrete
setblock 246 242 560 minecraft:light[level=14]
setblock 246 242 568 minecraft:light[level=14]
setblock 246 242 576 minecraft:light[level=14]
setblock 246 242 584 minecraft:light[level=14]
setblock 246 242 592 minecraft:light[level=14]
fill 251 242 599 252 242 599 minecraft:yellow_concrete
fill 252 242 557 252 245 557 minecraft:red_concrete
setblock 253 242 557 minecraft:yellow_concrete
setblock 254 242 560 minecraft:light[level=14]
setblock 254 242 568 minecraft:light[level=14]
setblock 254 242 576 minecraft:light[level=14]
setblock 254 242 584 minecraft:light[level=14]
setblock 254 242 592 minecraft:light[level=14]
fill 256 242 557 257 243 557 minecraft:yellow_concrete
fill 259 242 599 260 243 599 minecraft:yellow_concrete
setblock 262 242 560 minecraft:light[level=14]
setblock 262 242 568 minecraft:light[level=14]
setblock 262 242 576 minecraft:light[level=14]
setblock 262 242 584 minecraft:light[level=14]
setblock 262 242 592 minecraft:light[level=14]
setblock 263 242 599 minecraft:yellow_concrete
fill 264 242 557 265 242 557 minecraft:yellow_concrete
fill 264 242 599 264 245 599 minecraft:red_concrete
setblock 270 242 560 minecraft:light[level=14]
setblock 270 242 568 minecraft:light[level=14]
setblock 270 242 576 minecraft:light[level=14]
setblock 270 242 584 minecraft:light[level=14]
setblock 270 242 592 minecraft:light[level=14]
fill 271 242 599 272 243 599 minecraft:yellow_concrete
fill 276 242 557 277 243 557 minecraft:yellow_concrete
fill 277 242 564 277 245 564 minecraft:red_concrete
setblock 277 242 565 minecraft:yellow_concrete
fill 277 242 568 277 243 568 minecraft:yellow_concrete
fill 277 242 576 277 242 577 minecraft:yellow_concrete
fill 277 242 588 277 243 589 minecraft:yellow_concrete
fill 277 242 596 277 242 597 minecraft:yellow_concrete
fill 235 243 559 235 243 560 minecraft:yellow_concrete
setblock 235 243 563 minecraft:yellow_concrete
fill 235 243 564 235 246 564 minecraft:red_concrete
fill 235 243 575 235 246 575 minecraft:red_concrete
fill 235 243 579 235 245 579 minecraft:red_concrete
setblock 235 243 580 minecraft:yellow_concrete
setblock 235 243 591 minecraft:yellow_concrete
fill 235 243 595 235 245 596 minecraft:red_concrete
setblock 237 243 557 minecraft:yellow_concrete
fill 246 243 568 247 244 568 minecraft:orange_concrete
fill 247 243 599 248 243 599 minecraft:yellow_concrete
setblock 248 243 557 minecraft:yellow_concrete
fill 249 243 557 249 245 557 minecraft:red_concrete
fill 250 243 576 250 245 576 minecraft:red_concrete
fill 251 243 577 252 244 578 minecraft:red_concrete
setblock 251 243 599 minecraft:yellow_concrete
fill 252 243 599 252 246 599 minecraft:red_concrete
fill 253 243 557 253 246 557 minecraft:red_concrete
fill 260 243 577 261 244 578 minecraft:red_concrete
fill 262 243 576 262 245 576 minecraft:red_concrete
fill 263 243 599 263 246 599 minecraft:red_concrete
fill 264 243 557 264 246 557 minecraft:red_concrete
setblock 265 243 557 minecraft:yellow_concrete
fill 267 243 599 267 245 599 minecraft:red_concrete
fill 268 243 557 269 243 557 minecraft:yellow_concrete
setblock 268 243 599 minecraft:yellow_concrete
fill 277 243 565 277 246 565 minecraft:red_concrete
setblock 277 243 569 minecraft:yellow_concrete
fill 277 243 576 277 246 576 minecraft:red_concrete
setblock 277 243 577 minecraft:yellow_concrete
setblock 277 243 580 minecraft:yellow_concrete
fill 277 243 581 277 245 581 minecraft:red_concrete
fill 277 243 596 277 246 597 minecraft:red_concrete
fill 235 244 557 237 244 557 minecraft:red_concrete
fill 235 244 558 235 245 558 minecraft:yellow_concrete
fill 235 244 559 235 249 560 minecraft:red_concrete
setblock 235 244 561 minecraft:yellow_concrete
fill 235 244 562 235 247 563 minecraft:red_concrete
fill 235 244 569 235 245 570 minecraft:yellow_concrete
fill 235 244 571 235 249 572 minecraft:red_concrete
fill 235 244 580 235 249 580 minecraft:red_concrete
fill 235 244 581 235 244 582 minecraft:yellow_concrete
fill 235 244 583 235 249 584 minecraft:red_concrete
fill 235 244 589 235 245 590 minecraft:yellow_concrete
fill 235 244 591 235 249 592 minecraft:red_concrete
setblock 235 244 593 minecraft:yellow_concrete
fill 235 244 594 235 247 594 minecraft:red_concrete
fill 237 244 599 238 245 599 minecraft:yellow_concrete
fill 238 244 557 239 245 557 minecraft:yellow_concrete
fill 239 244 599 240 249 599 minecraft:red_concrete
fill 244 244 557 245 249 557 minecraft:red_concrete
setblock 245 244 599 minecraft:red_concrete
fill 246 244 557 247 244 557 minecraft:yellow_concrete
fill 246 244 599 246 245 599 minecraft:yellow_concrete
fill 247 244 573 249 245 573 minecraft:red_concrete
fill 247 244 599 248 245 599 minecraft:red_concrete
fill 248 244 557 248 249 557 minecraft:red_concrete
fill 248 244 571 249 245 572 minecraft:red_concrete
fill 248 244 574 249 245 575 minecraft:red_concrete
setblock 249 244 576 minecraft:red_concrete
fill 249 244 599 250 244 599 minecraft:yellow_concrete
setblock 250 244 575 minecraft:red_concrete
fill 250 244 577 250 244 578 minecraft:red_concrete
setblock 251 244 576 minecraft:red_concrete
fill 251 244 579 252 244 579 minecraft:yellow_concrete
fill 251 244 599 251 249 599 minecraft:red_concrete
fill 256 244 557 257 249 557 minecraft:red_concrete
fill 257 244 599 258 245 599 minecraft:yellow_concrete
fill 258 244 557 259 245 557 minecraft:yellow_concrete
fill 259 244 599 260 249 599 minecraft:red_concrete
fill 260 244 579 261 244 579 minecraft:yellow_concrete
setblock 261 244 576 minecraft:red_concrete
fill 262 244 575 264 244 575 minecraft:red_concrete
fill 262 244 577 262 244 578 minecraft:red_concrete
fill 263 244 574 264 245 574 minecraft:red_concrete
setblock 263 244 576 minecraft:red_concrete
fill 264 244 573 265 245 573 minecraft:red_concrete
fill 265 244 557 266 247 557 minecraft:red_concrete
setblock 267 244 557 minecraft:yellow_concrete
fill 268 244 557 269 249 557 minecraft:red_concrete
fill 268 244 599 268 249 599 minecraft:red_concrete
fill 269 244 599 270 244 599 minecraft:yellow_concrete
fill 270 244 557 270 245 557 minecraft:yellow_concrete
setblock 271 244 557 minecraft:red_concrete
fill 271 244 599 272 249 599 minecraft:red_concrete
fill 276 244 557 277 249 557 minecraft:red_concrete
fill 277 244 558 277 244 559 minecraft:yellow_concrete
fill 277 244 568 277 249 569 minecraft:red_concrete
fill 277 244 570 277 245 571 minecraft:yellow_concrete
fill 277 244 577 277 249 577 minecraft:red_concrete
fill 277 244 578 277 244 579 minecraft:yellow_concrete
fill 277 244 580 277 249 580 minecraft:red_concrete
fill 277 244 582 277 245 582 minecraft:yellow_concrete
setblock 277 244 583 minecraft:red_concrete
fill 277 244 588 277 249 589 minecraft:red_concrete
fill 277 244 590 277 245 591 minecraft:yellow_concrete
fill 277 244 599 277 245 599 minecraft:yellow_concrete
setblock 235 245 557 minecraft:yellow_concrete
fill 235 245 561 235 248 561 minecraft:red_concrete
fill 235 245 577 235 245 578 minecraft:yellow_concrete
setblock 235 245 581 minecraft:yellow_concrete
fill 235 245 582 235 248 582 minecraft:red_concrete
fill 235 245 593 235 247 593 minecraft:red_concrete
fill 235 245 597 235 247 597 minecraft:red_concrete
setblock 235 245 598 minecraft:yellow_concrete
fill 236 245 557 237 249 557 minecraft:red_concrete
fill 243 245 569 244 246 569 minecraft:red_concrete
fill 244 245 570 245 245 571 minecraft:red_concrete
fill 245 245 572 247 245 572 minecraft:red_concrete
setblock 245 245 599 minecraft:yellow_concrete
fill 246 245 557 246 248 557 minecraft:red_concrete
setblock 246 245 571 minecraft:red_concrete
setblock 246 245 573 minecraft:red_concrete
setblock 247 245 557 minecraft:yellow_concrete
setblock 247 245 574 minecraft:red_concrete
fill 247 245 575 247 246 575 minecraft:orange_concrete
fill 248 245 576 249 245 576 minecraft:orange_concrete
fill 249 245 577 249 246 577 minecraft:yellow_concrete
fill 249 245 599 250 247 599 minecraft:red_concrete
fill 250 245 557 251 245 557 minecraft:yellow_concrete
fill 250 245 577 251 245 577 minecraft:orange_concrete
fill 250 245 578 250 246 578 minecraft:red_concrete
fill 250 245 579 251 246 579 minecraft:yellow_concrete
fill 251 245 578 252 245 578 minecraft:yellow_concrete
setblock 252 245 579 minecraft:orange_concrete
fill 260 245 578 261 245 578 minecraft:yellow_concrete
setblock 260 245 579 minecraft:orange_concrete
fill 261 245 577 262 245 577 minecraft:orange_concrete
fill 261 245 579 262 246 579 minecraft:yellow_concrete
fill 262 245 578 262 246 578 minecraft:red_concrete
fill 263 245 575 264 245 575 minecraft:red_concrete
fill 263 245 576 264 245 576 minecraft:orange_concrete
fill 263 245 577 263 246 577 minecraft:yellow_concrete
fill 265 245 572 267 245 572 minecraft:red_concrete
setblock 265 245 574 minecraft:red_concrete
fill 265 245 575 265 246 575 minecraft:orange_concrete
fill 265 245 599 266 245 599 minecraft:yellow_concrete
fill 266 245 571 268 245 571 minecraft:red_concrete
setblock 266 245 573 minecraft:red_concrete
fill 267 245 557 267 248 557 minecraft:red_concrete
fill 267 245 570 268 246 570 minecraft:red_concrete
fill 268 245 569 269 246 569 minecraft:red_concrete
setblock 269 245 599 minecraft:yellow_concrete
fill 270 245 599 270 248 599 minecraft:red_concrete
setblock 271 245 557 minecraft:yellow_concrete
fill 277 245 558 277 248 558 minecraft:red_concrete
setblock 277 245 559 minecraft:yellow_concrete
setblock 277 245 562 minecraft:yellow_concrete
fill 277 245 563 277 247 563 minecraft:red_concrete
fill 277 245 578 277 248 579 minecraft:red_concrete
setblock 277 245 583 minecraft:yellow_concrete
setblock 277 245 594 minecraft:yellow_concrete
fill 277 245 595 277 247 595 minecraft:red_concrete
fill 235 246 557 235 251 558 minecraft:red_concrete
fill 235 246 567 235 246 568 minecraft:yellow_concrete
fill 235 246 569 235 251 570 minecraft:red_concrete
fill 235 246 576 235 247 576 minecraft:yellow_concrete
fill 235 246 577 235 251 578 minecraft:red_concrete
setblock 235 246 579 minecraft:yellow_concrete
fill 235 246 581 235 251 581 minecraft:red_concrete
fill 235 246 587 235 247 588 minecraft:yellow_concrete
fill 235 246 589 235 251 590 minecraft:red_concrete
setblock 235 246 595 minecraft:red_concrete
fill 235 246 596 235 247 596 minecraft:yellow_concrete
fill 235 246 598 235 251 598 minecraft:red_concrete
fill 235 246 599 236 246 599 minecraft:yellow_concrete
fill 236 246 558 238 246 558 minecraft:orange_concrete
fill 236 246 560 236 246 562 minecraft:orange_concrete
fill 236 246 564 236 246 566 minecraft:orange_concrete
fill 236 246 568 236 246 570 minecraft:orange_concrete
fill 236 246 572 236 246 574 minecraft:orange_concrete
fill 236 246 576 236 246 578 minecraft:orange_concrete
fill 236 246 580 236 246 582 minecraft:orange_concrete
fill 236 246 584 236 246 586 minecraft:orange_concrete
fill 236 246 588 236 246 590 minecraft:orange_concrete
fill 236 246 592 236 246 594 minecraft:orange_concrete
fill 236 246 596 236 246 598 minecraft:orange_concrete
fill 237 246 599 238 248 599 minecraft:red_concrete
fill 238 246 557 239 251 557 minecraft:red_concrete
fill 238 246 598 240 246 598 minecraft:orange_concrete
fill 239 246 565 240 247 565 minecraft:red_concrete
fill 240 246 557 241 247 557 minecraft:yellow_concrete
fill 240 246 558 242 246 558 minecraft:orange_concrete
fill 240 246 566 241 247 566 minecraft:red_concrete
fill 241 246 567 242 246 568 minecraft:red_concrete
setblock 242 246 569 minecraft:red_concrete
fill 242 246 598 244 246 598 minecraft:orange_concrete
setblock 243 246 568 minecraft:red_concrete
fill 243 246 570 245 246 570 minecraft:red_concrete
fill 243 246 599 244 247 599 minecraft:yellow_concrete
fill 244 246 558 246 246 558 minecraft:orange_concrete
setblock 245 246 571 minecraft:red_concrete
fill 245 246 572 245 247 573 minecraft:orange_concrete
fill 245 246 599 246 251 599 minecraft:red_concrete
setblock 246 246 572 minecraft:red_concrete
fill 246 246 573 247 246 574 minecraft:orange_concrete
fill 246 246 598 248 246 598 minecraft:orange_concrete
fill 247 246 557 247 251 557 minecraft:red_concrete
fill 247 246 576 249 246 576 minecraft:yellow_concrete
setblock 247 246 599 minecraft:yellow_concrete
fill 248 246 558 250 246 558 minecraft:orange_concrete
fill 248 246 574 248 246 575 minecraft:orange_concrete
setblock 248 246 577 minecraft:yellow_concrete
fill 248 246 599 248 249 599 minecraft:red_concrete
setblock 249 246 557 minecraft:yellow_concrete
setblock 249 246 578 minecraft:red_concrete
fill 249 246 579 249 248 579 minecraft:yellow_concrete
fill 250 246 557 251 251 557 minecraft:red_concrete
setblock 250 246 577 minecraft:red_concrete
fill 250 246 580 251 246 580 minecraft:orange_concrete
fill 250 246 598 252 246 598 minecraft:orange_concrete
setblock 251 246 578 minecraft:yellow_concrete
fill 252 246 557 252 247 557 minecraft:yellow_concrete
fill 252 246 558 254 246 558 minecraft:orange_concrete
fill 254 246 598 256 246 598 minecraft:orange_concrete
fill 255 246 599 256 247 599 minecraft:yellow_concrete
fill 256 246 558 258 246 558 minecraft:orange_concrete
fill 257 246 599 258 251 599 minecraft:red_concrete
schedule function dropper:buildpart/137_4 1t
