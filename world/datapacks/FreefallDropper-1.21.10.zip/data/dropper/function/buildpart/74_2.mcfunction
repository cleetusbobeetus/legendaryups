setblock 97 90 357 minecraft:light[level=15]
setblock 97 90 360 minecraft:light[level=12]
setblock 97 90 363 minecraft:stripped_spruce_log
fill 98 90 363 98 93 363 minecraft:stone
setblock 104 90 325 minecraft:light[level=12]
setblock 104 90 332 minecraft:light[level=12]
setblock 104 90 339 minecraft:light[level=12]
setblock 104 90 346 minecraft:light[level=12]
setblock 104 90 353 minecraft:light[level=12]
setblock 104 90 360 minecraft:light[level=12]
fill 105 90 323 106 90 323 minecraft:stone
setblock 105 90 325 minecraft:light[level=15]
setblock 105 90 333 minecraft:light[level=15]
setblock 105 90 341 minecraft:light[level=15]
setblock 105 90 349 minecraft:light[level=15]
setblock 105 90 357 minecraft:light[level=15]
setblock 106 90 363 minecraft:stone
setblock 107 90 323 minecraft:stripped_spruce_log
setblock 107 90 363 minecraft:stripped_spruce_log
fill 108 90 323 110 90 324 minecraft:stone
setblock 108 90 362 minecraft:stripped_spruce_log
fill 108 90 363 111 90 363 minecraft:stone
setblock 108 90 364 minecraft:raw_iron_block
fill 109 90 362 112 90 362 minecraft:stone
fill 110 90 361 113 90 361 minecraft:stone
setblock 111 90 323 minecraft:stone
setblock 111 90 324 minecraft:stripped_spruce_log
setblock 111 90 325 minecraft:light[level=12]
setblock 111 90 332 minecraft:light[level=12]
setblock 111 90 339 minecraft:light[level=12]
setblock 111 90 346 minecraft:light[level=12]
setblock 111 90 353 minecraft:light[level=12]
setblock 111 90 360 minecraft:light[level=12]
setblock 112 90 323 minecraft:stripped_spruce_log
fill 112 90 324 112 92 325 minecraft:stone
setblock 112 90 363 minecraft:stripped_spruce_log
fill 113 90 323 113 93 323 minecraft:stone
fill 113 90 325 113 91 325 minecraft:stone
setblock 113 90 333 minecraft:light[level=15]
setblock 113 90 341 minecraft:light[level=15]
setblock 113 90 349 minecraft:light[level=15]
setblock 113 90 357 minecraft:light[level=15]
setblock 113 90 362 minecraft:stripped_spruce_log
fill 113 90 363 116 90 363 minecraft:stone
setblock 114 90 361 minecraft:stripped_spruce_log
fill 114 90 362 114 93 362 minecraft:stone
fill 115 90 361 115 93 361 minecraft:stone
setblock 116 90 324 minecraft:stripped_spruce_log
setblock 117 90 323 minecraft:stripped_spruce_log
fill 117 90 324 117 93 324 minecraft:stone
setblock 117 90 363 minecraft:stripped_spruce_log
fill 118 90 323 118 93 323 minecraft:stone
setblock 118 90 325 minecraft:light[level=12]
setblock 118 90 332 minecraft:light[level=12]
setblock 118 90 339 minecraft:light[level=12]
setblock 118 90 346 minecraft:light[level=12]
setblock 118 90 353 minecraft:light[level=12]
setblock 118 90 360 minecraft:light[level=12]
setblock 118 90 362 minecraft:stripped_spruce_log
fill 118 90 363 121 90 363 minecraft:stone
fill 119 90 362 119 93 362 minecraft:stone
setblock 121 90 323 minecraft:stone
setblock 121 90 325 minecraft:light[level=15]
setblock 121 90 333 minecraft:light[level=15]
setblock 121 90 341 minecraft:light[level=15]
setblock 121 90 349 minecraft:light[level=15]
setblock 121 90 357 minecraft:light[level=15]
setblock 122 90 363 minecraft:stripped_spruce_log
setblock 123 90 362 minecraft:stripped_spruce_log
fill 123 90 363 126 90 363 minecraft:stone
fill 124 90 362 127 90 362 minecraft:stone
setblock 125 90 325 minecraft:light[level=12]
setblock 125 90 332 minecraft:light[level=12]
setblock 125 90 339 minecraft:light[level=12]
setblock 125 90 346 minecraft:light[level=12]
setblock 125 90 353 minecraft:light[level=12]
setblock 125 90 360 minecraft:light[level=12]
fill 126 90 361 128 90 361 minecraft:stone
setblock 127 90 323 minecraft:stripped_spruce_log
setblock 127 90 363 minecraft:stripped_spruce_log
fill 128 90 323 131 90 323 minecraft:stone
setblock 128 90 362 minecraft:stripped_spruce_log
fill 128 90 363 128 93 363 minecraft:stone
setblock 129 90 325 minecraft:light[level=15]
setblock 129 90 333 minecraft:light[level=15]
setblock 129 90 341 minecraft:light[level=15]
setblock 129 90 349 minecraft:light[level=15]
setblock 129 90 357 minecraft:light[level=15]
setblock 129 90 360 minecraft:stone
setblock 129 90 361 minecraft:stripped_spruce_log
fill 129 90 362 129 93 362 minecraft:stone
setblock 130 90 360 minecraft:stripped_spruce_log
fill 130 90 361 130 93 361 minecraft:stone
fill 131 90 360 131 93 360 minecraft:stone
setblock 132 90 323 minecraft:stripped_spruce_log
setblock 132 90 325 minecraft:light[level=12]
setblock 132 90 332 minecraft:light[level=12]
setblock 132 90 339 minecraft:light[level=12]
setblock 132 90 346 minecraft:light[level=12]
setblock 132 90 353 minecraft:light[level=12]
setblock 132 90 358 minecraft:stripped_spruce_log
fill 132 90 359 132 93 359 minecraft:stone
setblock 132 90 363 minecraft:stripped_spruce_log
fill 133 90 323 133 93 323 minecraft:stone
setblock 133 90 337 minecraft:stripped_spruce_log
fill 133 90 338 133 90 341 minecraft:stone
setblock 133 90 342 minecraft:stripped_spruce_log
fill 133 90 343 134 90 345 minecraft:stone
setblock 133 90 357 minecraft:stripped_spruce_log
fill 133 90 358 133 93 358 minecraft:stone
setblock 133 90 362 minecraft:stripped_spruce_log
fill 133 90 363 133 93 363 minecraft:stone
setblock 134 90 336 minecraft:stripped_spruce_log
fill 134 90 337 134 93 337 minecraft:stone
setblock 134 90 341 minecraft:stripped_spruce_log
fill 134 90 342 134 93 342 minecraft:stone
setblock 134 90 346 minecraft:stripped_spruce_log
fill 134 90 347 134 93 347 minecraft:stone
setblock 134 90 351 minecraft:stripped_spruce_log
fill 134 90 352 134 93 352 minecraft:stone
setblock 134 90 356 minecraft:stripped_spruce_log
fill 134 90 357 134 93 357 minecraft:stone
setblock 134 90 361 minecraft:stripped_spruce_log
setblock 134 90 362 minecraft:stone
setblock 135 90 335 minecraft:stripped_spruce_log
fill 135 90 336 135 93 336 minecraft:stone
setblock 135 90 340 minecraft:stripped_spruce_log
fill 135 90 341 135 93 341 minecraft:stone
setblock 135 90 345 minecraft:stripped_spruce_log
fill 135 90 346 135 93 346 minecraft:stone
setblock 135 90 350 minecraft:stripped_spruce_log
fill 135 90 351 135 93 351 minecraft:stone
setblock 135 90 355 minecraft:stripped_spruce_log
fill 135 90 356 135 93 356 minecraft:stone
setblock 135 90 360 minecraft:stripped_spruce_log
fill 135 90 361 135 93 361 minecraft:stone
fill 136 90 331 136 105 331 minecraft:cobbled_deepslate
fill 136 90 356 136 98 356 minecraft:cobbled_deepslate
fill 94 91 358 94 107 358 minecraft:cobbled_deepslate
setblock 95 91 322 minecraft:raw_gold_block
setblock 95 91 323 minecraft:stone
setblock 95 91 324 minecraft:stripped_spruce_log
fill 95 91 325 95 91 328 minecraft:stone
setblock 95 91 329 minecraft:stripped_spruce_log
fill 95 91 330 95 91 333 minecraft:stone
setblock 95 91 334 minecraft:stripped_spruce_log
fill 95 91 335 95 91 338 minecraft:stone
setblock 95 91 339 minecraft:stripped_spruce_log
fill 95 91 340 95 91 343 minecraft:stone
setblock 95 91 344 minecraft:stripped_spruce_log
fill 95 91 345 95 91 348 minecraft:stone
setblock 95 91 349 minecraft:stripped_spruce_log
fill 95 91 350 95 91 353 minecraft:stone
setblock 95 91 354 minecraft:stripped_spruce_log
fill 95 91 355 95 93 355 minecraft:stone
setblock 95 91 359 minecraft:stripped_spruce_log
fill 95 91 360 95 94 360 minecraft:stone
setblock 96 91 323 minecraft:stripped_spruce_log
fill 96 91 324 96 94 324 minecraft:spruce_log
setblock 96 91 333 minecraft:stripped_spruce_log
fill 96 91 334 96 91 337 minecraft:stone
setblock 96 91 338 minecraft:stripped_spruce_log
fill 96 91 339 96 94 339 minecraft:stone
setblock 96 91 342 minecraft:stone
fill 96 91 343 96 94 343 minecraft:spruce_log
fill 96 91 344 96 94 344 minecraft:stone
fill 96 91 362 96 94 362 minecraft:spruce_log
setblock 96 91 363 minecraft:stripped_spruce_log
fill 97 91 323 98 93 323 minecraft:stone
setblock 97 91 337 minecraft:stripped_spruce_log
fill 97 91 338 97 94 338 minecraft:stone
setblock 97 91 342 minecraft:stripped_spruce_log
fill 97 91 343 97 94 343 minecraft:stone
fill 97 91 363 97 94 363 minecraft:stone
fill 100 91 359 100 92 359 minecraft:cobbled_deepslate
fill 100 91 361 100 92 361 minecraft:cobbled_deepslate
fill 102 91 359 102 92 359 minecraft:cobbled_deepslate
fill 102 91 361 102 92 361 minecraft:cobbled_deepslate
fill 103 91 323 105 91 323 minecraft:stone
fill 104 91 363 105 91 363 minecraft:stone
setblock 106 91 323 minecraft:stripped_spruce_log
fill 106 91 324 109 91 324 minecraft:stone
fill 106 91 360 106 95 360 minecraft:cobbled_deepslate
setblock 106 91 363 minecraft:stripped_spruce_log
fill 107 91 323 110 91 323 minecraft:stone
setblock 107 91 362 minecraft:stripped_spruce_log
fill 107 91 363 110 91 363 minecraft:stone
fill 108 91 362 111 91 362 minecraft:stone
fill 108 91 364 108 98 364 minecraft:cobbled_deepslate
setblock 109 91 325 minecraft:stripped_spruce_log
fill 109 91 361 112 91 361 minecraft:stone
setblock 110 91 324 minecraft:stripped_spruce_log
fill 110 91 325 111 93 325 minecraft:stone
setblock 111 91 323 minecraft:stripped_spruce_log
fill 111 91 324 111 94 324 minecraft:stone
setblock 111 91 363 minecraft:stripped_spruce_log
fill 112 91 323 112 94 323 minecraft:stone
setblock 112 91 362 minecraft:stripped_spruce_log
fill 112 91 363 115 91 363 minecraft:stone
setblock 113 91 361 minecraft:stripped_spruce_log
fill 113 91 362 113 94 362 minecraft:stone
setblock 114 91 325 minecraft:stripped_spruce_log
fill 114 91 361 114 94 361 minecraft:stone
fill 115 91 324 115 94 324 minecraft:spruce_log
fill 115 91 362 115 94 362 minecraft:spruce_log
setblock 116 91 323 minecraft:stripped_spruce_log
fill 116 91 324 116 94 324 minecraft:stone
setblock 116 91 363 minecraft:stripped_spruce_log
fill 117 91 323 117 94 323 minecraft:stone
setblock 117 91 362 minecraft:stripped_spruce_log
fill 117 91 363 120 91 363 minecraft:stone
fill 118 91 324 118 92 324 minecraft:stone
setblock 118 91 361 minecraft:stripped_spruce_log
fill 118 91 362 118 94 362 minecraft:stone
fill 118 91 364 118 107 364 minecraft:cobbled_deepslate
fill 119 91 361 119 93 361 minecraft:stone
setblock 119 91 364 minecraft:raw_gold_block
fill 120 91 364 124 94 364 minecraft:cobbled_deepslate
setblock 121 91 323 minecraft:stripped_spruce_log
setblock 121 91 362 minecraft:stone
setblock 121 91 363 minecraft:stripped_spruce_log
fill 122 91 323 125 91 323 minecraft:stone
setblock 122 91 362 minecraft:stripped_spruce_log
fill 122 91 363 125 91 363 minecraft:stone
fill 123 91 362 126 91 362 minecraft:stone
fill 124 91 361 127 91 361 minecraft:stone
setblock 126 91 323 minecraft:stripped_spruce_log
setblock 126 91 363 minecraft:stripped_spruce_log
fill 127 91 323 130 91 323 minecraft:stone
setblock 127 91 362 minecraft:stripped_spruce_log
fill 127 91 363 127 94 363 minecraft:stone
setblock 128 91 360 minecraft:stone
setblock 128 91 361 minecraft:stripped_spruce_log
fill 128 91 362 128 94 362 minecraft:stone
setblock 129 91 360 minecraft:stripped_spruce_log
fill 129 91 361 129 94 361 minecraft:stone
fill 130 91 360 130 94 360 minecraft:stone
setblock 131 91 323 minecraft:stripped_spruce_log
setblock 131 91 363 minecraft:stripped_spruce_log
fill 132 91 323 132 94 323 minecraft:stone
setblock 132 91 357 minecraft:stripped_spruce_log
fill 132 91 358 132 92 358 minecraft:stone
setblock 132 91 362 minecraft:stripped_spruce_log
fill 132 91 363 132 94 363 minecraft:stone
fill 133 91 337 133 91 340 minecraft:stone
setblock 133 91 341 minecraft:stripped_spruce_log
fill 133 91 342 133 91 345 minecraft:stone
setblock 133 91 346 minecraft:stripped_spruce_log
fill 133 91 347 133 93 348 minecraft:stone
fill 133 91 353 133 92 353 minecraft:stone
setblock 133 91 356 minecraft:stripped_spruce_log
fill 133 91 357 133 94 357 minecraft:stone
setblock 133 91 361 minecraft:stripped_spruce_log
fill 133 91 362 133 94 362 minecraft:stone
fill 134 91 324 134 94 324 minecraft:spruce_log
setblock 134 91 335 minecraft:stripped_spruce_log
fill 134 91 336 134 94 336 minecraft:stone
setblock 134 91 340 minecraft:stripped_spruce_log
fill 134 91 341 134 94 341 minecraft:stone
fill 134 91 343 134 94 343 minecraft:spruce_log
setblock 134 91 344 minecraft:stone
setblock 134 91 345 minecraft:stripped_spruce_log
fill 134 91 346 134 94 346 minecraft:stone
setblock 134 91 350 minecraft:stripped_spruce_log
fill 134 91 351 134 94 351 minecraft:stone
setblock 134 91 355 minecraft:stripped_spruce_log
fill 134 91 356 134 94 356 minecraft:stone
setblock 134 91 360 minecraft:stripped_spruce_log
fill 134 91 361 134 94 361 minecraft:stone
fill 134 91 362 134 94 362 minecraft:spruce_log
setblock 135 91 324 minecraft:stripped_spruce_log
setblock 135 91 334 minecraft:stripped_spruce_log
fill 135 91 335 135 94 335 minecraft:stone
setblock 135 91 339 minecraft:stripped_spruce_log
fill 135 91 340 135 94 340 minecraft:stone
setblock 135 91 344 minecraft:stripped_spruce_log
fill 135 91 345 135 94 345 minecraft:stone
setblock 135 91 349 minecraft:stripped_spruce_log
fill 135 91 350 135 94 350 minecraft:stone
setblock 135 91 354 minecraft:stripped_spruce_log
fill 135 91 355 135 94 355 minecraft:stone
setblock 135 91 359 minecraft:stripped_spruce_log
fill 135 91 360 135 94 360 minecraft:stone
setblock 136 91 332 minecraft:raw_iron_block
fill 136 91 336 136 107 336 minecraft:cobbled_deepslate
setblock 136 91 337 minecraft:gold_block
fill 136 91 338 136 103 340 minecraft:cobbled_deepslate
setblock 94 92 337 minecraft:raw_gold_block
fill 95 92 322 95 103 322 minecraft:cobbled_deepslate
setblock 95 92 323 minecraft:stripped_spruce_log
fill 95 92 324 95 92 327 minecraft:stone
setblock 95 92 328 minecraft:stripped_spruce_log
fill 95 92 329 95 92 332 minecraft:stone
setblock 95 92 333 minecraft:stripped_spruce_log
fill 95 92 334 95 92 337 minecraft:stone
setblock 95 92 338 minecraft:stripped_spruce_log
fill 95 92 339 95 92 342 minecraft:stone
setblock 95 92 343 minecraft:stripped_spruce_log
fill 95 92 344 95 92 347 minecraft:stone
setblock 95 92 348 minecraft:stripped_spruce_log
fill 95 92 349 95 92 352 minecraft:stone
setblock 95 92 353 minecraft:stripped_spruce_log
fill 95 92 354 95 93 354 minecraft:stone
setblock 95 92 358 minecraft:stripped_spruce_log
fill 95 92 359 95 94 359 minecraft:stone
setblock 95 92 363 minecraft:stripped_spruce_log
fill 96 92 323 96 95 323 minecraft:stone
fill 96 92 333 96 92 336 minecraft:stone
setblock 96 92 337 minecraft:stripped_spruce_log
fill 96 92 338 96 95 338 minecraft:stone
setblock 96 92 342 minecraft:stripped_spruce_log
setblock 96 92 347 minecraft:stripped_spruce_log
fill 96 92 363 96 95 363 minecraft:stone
fill 97 92 337 97 93 337 minecraft:stone
setblock 97 92 341 minecraft:stripped_spruce_log
fill 97 92 342 97 95 342 minecraft:stone
fill 97 92 344 97 93 344 minecraft:stone
setblock 99 92 323 minecraft:stone
setblock 99 92 363 minecraft:stone
setblock 100 92 323 minecraft:stripped_spruce_log
fill 101 92 323 104 92 323 minecraft:stone
fill 102 92 363 104 92 363 minecraft:stone
setblock 102 92 364 minecraft:raw_gold_block
fill 103 92 364 103 107 364 minecraft:cobbled_deepslate
setblock 105 92 323 minecraft:stripped_spruce_log
fill 105 92 324 108 92 324 minecraft:stone
setblock 105 92 363 minecraft:stripped_spruce_log
fill 106 92 323 109 92 323 minecraft:stone
setblock 106 92 362 minecraft:stripped_spruce_log
fill 106 92 363 109 92 363 minecraft:stone
fill 107 92 362 110 92 362 minecraft:stone
setblock 108 92 325 minecraft:stripped_spruce_log
fill 108 92 361 111 92 361 minecraft:stone
setblock 109 92 324 minecraft:stripped_spruce_log
fill 109 92 325 109 95 325 minecraft:stone
setblock 110 92 323 minecraft:stripped_spruce_log
fill 110 92 324 110 95 324 minecraft:stone
setblock 110 92 363 minecraft:stripped_spruce_log
fill 111 92 323 111 95 323 minecraft:stone
setblock 111 92 362 minecraft:stripped_spruce_log
fill 111 92 363 114 92 363 minecraft:stone
setblock 112 92 361 minecraft:stripped_spruce_log
fill 112 92 362 112 95 362 minecraft:stone
setblock 113 92 325 minecraft:stripped_spruce_log
fill 113 92 361 113 95 361 minecraft:stone
setblock 114 92 324 minecraft:stripped_spruce_log
fill 114 92 325 115 94 325 minecraft:stone
setblock 115 92 323 minecraft:stripped_spruce_log
setblock 115 92 363 minecraft:stripped_spruce_log
fill 116 92 323 116 95 323 minecraft:stone
setblock 116 92 362 minecraft:stripped_spruce_log
fill 116 92 363 119 92 363 minecraft:stone
setblock 117 92 361 minecraft:stripped_spruce_log
fill 117 92 362 117 95 362 minecraft:stone
fill 118 92 361 118 94 361 minecraft:stone
fill 119 92 364 119 104 364 minecraft:cobbled_deepslate
setblock 120 92 323 minecraft:stripped_spruce_log
setblock 120 92 363 minecraft:stripped_spruce_log
fill 121 92 323 124 92 323 minecraft:stone
setblock 121 92 362 minecraft:stripped_spruce_log
fill 121 92 363 124 92 363 minecraft:stone
fill 122 92 362 125 92 362 minecraft:stone
fill 123 92 361 126 92 361 minecraft:stone
setblock 125 92 323 minecraft:stripped_spruce_log
setblock 125 92 363 minecraft:stripped_spruce_log
setblock 125 92 364 minecraft:raw_gold_block
fill 126 92 323 129 92 323 minecraft:stone
setblock 126 92 362 minecraft:stripped_spruce_log
fill 126 92 363 126 95 363 minecraft:stone
setblock 127 92 361 minecraft:stripped_spruce_log
fill 127 92 362 127 95 362 minecraft:stone
setblock 128 92 360 minecraft:stripped_spruce_log
fill 128 92 361 128 95 361 minecraft:stone
setblock 129 92 324 minecraft:stripped_spruce_log
fill 129 92 360 129 95 360 minecraft:stone
setblock 130 92 323 minecraft:stripped_spruce_log
fill 130 92 324 133 92 324 minecraft:stone
setblock 130 92 363 minecraft:stripped_spruce_log
fill 131 92 323 131 95 323 minecraft:stone
setblock 131 92 362 minecraft:stripped_spruce_log
fill 131 92 363 131 95 363 minecraft:stone
setblock 132 92 322 minecraft:raw_iron_block
setblock 132 92 340 minecraft:stone
setblock 132 92 341 minecraft:stripped_spruce_log
fill 132 92 342 132 92 345 minecraft:stone
setblock 132 92 361 minecraft:stripped_spruce_log
fill 132 92 362 132 95 362 minecraft:stone
fill 133 92 337 133 92 339 minecraft:stone
setblock 133 92 340 minecraft:stripped_spruce_log
fill 133 92 341 133 92 344 minecraft:stone
setblock 133 92 345 minecraft:stripped_spruce_log
fill 133 92 346 133 95 346 minecraft:stone
setblock 133 92 349 minecraft:stone
setblock 133 92 350 minecraft:stripped_spruce_log
setblock 133 92 355 minecraft:stripped_spruce_log
fill 133 92 356 133 93 356 minecraft:stone
setblock 133 92 360 minecraft:stripped_spruce_log
fill 133 92 361 133 95 361 minecraft:stone
setblock 134 92 323 minecraft:stone
fill 134 92 335 134 93 335 minecraft:stone
setblock 134 92 339 minecraft:stripped_spruce_log
fill 134 92 340 134 95 340 minecraft:stone
setblock 134 92 344 minecraft:stripped_spruce_log
fill 134 92 345 134 95 345 minecraft:stone
setblock 134 92 349 minecraft:stripped_spruce_log
fill 134 92 350 134 95 350 minecraft:stone
setblock 134 92 354 minecraft:stripped_spruce_log
fill 134 92 355 134 95 355 minecraft:stone
setblock 134 92 359 minecraft:stripped_spruce_log
fill 134 92 360 134 95 360 minecraft:stone
setblock 135 92 323 minecraft:stripped_spruce_log
fill 135 92 324 135 94 325 minecraft:stone
setblock 135 92 333 minecraft:stripped_spruce_log
fill 135 92 334 135 95 334 minecraft:stone
setblock 135 92 338 minecraft:stripped_spruce_log
fill 135 92 339 135 95 339 minecraft:stone
setblock 135 92 343 minecraft:stripped_spruce_log
fill 135 92 344 135 95 344 minecraft:stone
setblock 135 92 348 minecraft:stripped_spruce_log
fill 135 92 349 135 95 349 minecraft:stone
setblock 135 92 353 minecraft:stripped_spruce_log
fill 135 92 354 135 95 354 minecraft:stone
setblock 135 92 358 minecraft:stripped_spruce_log
fill 135 92 359 135 95 359 minecraft:stone
setblock 135 92 363 minecraft:stripped_spruce_log
fill 136 92 332 136 107 332 minecraft:cobbled_deepslate
fill 136 92 337 136 93 337 minecraft:cobbled_deepslate
fill 136 92 351 136 107 354 minecraft:cobbled_deepslate
setblock 136 92 355 minecraft:raw_iron_block
fill 94 93 337 94 107 337 minecraft:cobbled_deepslate
fill 95 93 323 95 93 326 minecraft:stone
setblock 95 93 327 minecraft:stripped_spruce_log
fill 95 93 328 95 93 331 minecraft:stone
setblock 95 93 332 minecraft:stripped_spruce_log
fill 95 93 333 95 93 336 minecraft:stone
setblock 95 93 337 minecraft:stripped_spruce_log
fill 95 93 338 95 93 341 minecraft:stone
setblock 95 93 342 minecraft:stripped_spruce_log
fill 95 93 343 95 93 346 minecraft:stone
setblock 95 93 347 minecraft:stripped_spruce_log
fill 95 93 348 95 93 351 minecraft:stone
setblock 95 93 352 minecraft:stripped_spruce_log
setblock 95 93 353 minecraft:stone
setblock 95 93 357 minecraft:stripped_spruce_log
fill 95 93 358 95 94 358 minecraft:stone
setblock 95 93 362 minecraft:stripped_spruce_log
fill 95 93 363 95 96 363 minecraft:stone
fill 96 93 334 96 93 335 minecraft:stone
setblock 96 93 336 minecraft:stripped_spruce_log
fill 96 93 337 96 96 337 minecraft:stone
setblock 96 93 341 minecraft:stripped_spruce_log
fill 96 93 342 96 96 342 minecraft:stone
setblock 96 93 346 minecraft:stripped_spruce_log
fill 96 93 347 96 94 348 minecraft:stone
setblock 97 93 340 minecraft:stripped_spruce_log
fill 97 93 341 97 95 341 minecraft:stone
setblock 99 93 323 minecraft:stripped_spruce_log
setblock 99 93 363 minecraft:stripped_spruce_log
fill 100 93 323 103 93 323 minecraft:stone
fill 100 93 363 103 93 363 minecraft:stone
setblock 100 93 364 minecraft:raw_iron_block
fill 101 93 364 102 107 364 minecraft:cobbled_deepslate
setblock 103 93 324 minecraft:stripped_spruce_log
setblock 104 93 323 minecraft:stripped_spruce_log
fill 104 93 324 107 93 324 minecraft:stone
setblock 104 93 363 minecraft:stripped_spruce_log
fill 105 93 323 108 93 323 minecraft:stone
setblock 105 93 362 minecraft:stripped_spruce_log
fill 105 93 363 108 93 363 minecraft:stone
setblock 106 93 325 minecraft:stone
fill 106 93 362 109 93 362 minecraft:stone
setblock 107 93 325 minecraft:stripped_spruce_log
setblock 108 93 324 minecraft:stripped_spruce_log
fill 108 93 325 108 96 325 minecraft:stone
fill 108 93 361 110 93 361 minecraft:stone
setblock 109 93 323 minecraft:stripped_spruce_log
fill 109 93 324 109 96 324 minecraft:stone
setblock 109 93 363 minecraft:stripped_spruce_log
fill 110 93 323 110 96 323 minecraft:stone
setblock 110 93 362 minecraft:stripped_spruce_log
fill 110 93 363 113 93 363 minecraft:stone
setblock 111 93 361 minecraft:stripped_spruce_log
fill 111 93 362 111 96 362 minecraft:stone
setblock 112 93 324 minecraft:stone
setblock 112 93 325 minecraft:stripped_spruce_log
fill 112 93 361 112 96 361 minecraft:stone
setblock 113 93 324 minecraft:stripped_spruce_log
fill 113 93 325 113 96 325 minecraft:stone
setblock 114 93 323 minecraft:stripped_spruce_log
fill 114 93 324 114 96 324 minecraft:stone
setblock 114 93 363 minecraft:stripped_spruce_log
fill 115 93 323 115 96 323 minecraft:stone
fill 115 93 363 118 93 363 minecraft:stone
setblock 116 93 361 minecraft:stripped_spruce_log
fill 116 93 362 116 96 362 minecraft:stone
fill 117 93 361 117 94 361 minecraft:stone
setblock 118 93 324 minecraft:stripped_spruce_log
setblock 119 93 323 minecraft:stripped_spruce_log
fill 119 93 324 119 96 324 minecraft:stone
setblock 119 93 363 minecraft:stripped_spruce_log
fill 120 93 323 123 93 323 minecraft:stone
setblock 120 93 361 minecraft:stone
setblock 120 93 362 minecraft:stripped_spruce_log
fill 120 93 363 123 93 363 minecraft:stone
fill 121 93 362 124 93 362 minecraft:stone
fill 122 93 361 125 93 361 minecraft:stone
setblock 124 93 323 minecraft:stripped_spruce_log
setblock 124 93 363 minecraft:stripped_spruce_log
fill 125 93 323 128 93 323 minecraft:stone
setblock 125 93 362 minecraft:stripped_spruce_log
fill 125 93 363 125 96 363 minecraft:stone
fill 125 93 364 125 105 364 minecraft:cobbled_deepslate
fill 126 93 324 127 93 324 minecraft:stone
setblock 126 93 361 minecraft:stripped_spruce_log
fill 126 93 362 126 96 362 minecraft:stone
setblock 127 93 360 minecraft:stripped_spruce_log
fill 127 93 361 127 96 361 minecraft:stone
setblock 128 93 324 minecraft:stripped_spruce_log
fill 128 93 360 128 95 360 minecraft:stone
setblock 129 93 323 minecraft:stripped_spruce_log
fill 129 93 324 132 93 324 minecraft:stone
setblock 129 93 363 minecraft:stripped_spruce_log
fill 130 93 323 130 96 323 minecraft:stone
setblock 130 93 362 minecraft:stripped_spruce_log
fill 130 93 363 130 96 363 minecraft:stone
setblock 131 93 361 minecraft:stripped_spruce_log
fill 131 93 362 131 96 362 minecraft:stone
fill 132 93 322 132 104 322 minecraft:cobbled_deepslate
setblock 132 93 340 minecraft:stripped_spruce_log
fill 132 93 341 132 93 344 minecraft:stone
setblock 132 93 345 minecraft:stripped_spruce_log
fill 132 93 346 132 95 347 minecraft:stone
setblock 132 93 360 minecraft:stripped_spruce_log
fill 132 93 361 132 96 361 minecraft:stone
setblock 133 93 324 minecraft:stripped_spruce_log
fill 133 93 337 133 93 338 minecraft:stone
setblock 133 93 339 minecraft:stripped_spruce_log
fill 133 93 340 133 93 343 minecraft:stone
setblock 133 93 344 minecraft:stripped_spruce_log
fill 133 93 345 133 96 345 minecraft:stone
setblock 133 93 349 minecraft:stripped_spruce_log
fill 133 93 350 133 95 351 minecraft:stone
setblock 133 93 354 minecraft:stripped_spruce_log
setblock 133 93 355 minecraft:stone
setblock 133 93 359 minecraft:stripped_spruce_log
fill 133 93 360 133 95 360 minecraft:stone
setblock 134 93 323 minecraft:stripped_spruce_log
setblock 134 93 338 minecraft:stripped_spruce_log
fill 134 93 339 134 96 339 minecraft:stone
fill 134 93 344 134 96 344 minecraft:stone
setblock 134 93 348 minecraft:stripped_spruce_log
fill 134 93 349 134 96 349 minecraft:stone
setblock 134 93 353 minecraft:stripped_spruce_log
fill 134 93 354 134 95 354 minecraft:stone
setblock 134 93 358 minecraft:stripped_spruce_log
fill 134 93 359 134 95 359 minecraft:stone
setblock 134 93 363 minecraft:stripped_spruce_log
fill 135 93 323 135 96 323 minecraft:stone
setblock 135 93 326 minecraft:stone
fill 135 93 333 135 94 333 minecraft:stone
setblock 135 93 337 minecraft:stripped_spruce_log
fill 135 93 338 135 96 338 minecraft:stone
setblock 135 93 342 minecraft:stripped_spruce_log
fill 135 93 343 135 96 343 minecraft:stone
setblock 135 93 347 minecraft:stripped_spruce_log
fill 135 93 348 135 96 348 minecraft:stone
setblock 135 93 352 minecraft:stripped_spruce_log
fill 135 93 353 135 96 353 minecraft:stone
setblock 135 93 357 minecraft:stripped_spruce_log
fill 135 93 358 135 96 358 minecraft:stone
setblock 135 93 362 minecraft:stripped_spruce_log
fill 135 93 363 135 96 363 minecraft:stone
fill 136 93 355 136 107 355 minecraft:cobbled_deepslate
fill 95 94 323 95 94 325 minecraft:stone
setblock 95 94 326 minecraft:stripped_spruce_log
fill 95 94 327 95 94 330 minecraft:stone
setblock 95 94 331 minecraft:stripped_spruce_log
fill 95 94 332 95 94 335 minecraft:stone
setblock 95 94 336 minecraft:stripped_spruce_log
fill 95 94 337 95 94 340 minecraft:stone
setblock 95 94 341 minecraft:stripped_spruce_log
fill 95 94 342 95 94 345 minecraft:stone
setblock 95 94 346 minecraft:stripped_spruce_log
fill 95 94 347 95 94 350 minecraft:stone
setblock 95 94 351 minecraft:stripped_spruce_log
setblock 95 94 352 minecraft:stone
setblock 95 94 357 minecraft:stone
setblock 95 94 361 minecraft:stripped_spruce_log
fill 95 94 362 95 96 362 minecraft:stone
setblock 96 94 335 minecraft:stripped_spruce_log
fill 96 94 336 96 95 336 minecraft:stone
setblock 96 94 340 minecraft:stripped_spruce_log
fill 96 94 341 96 96 341 minecraft:stone
setblock 96 94 345 minecraft:stripped_spruce_log
fill 96 94 346 96 96 346 minecraft:stone
setblock 97 94 323 minecraft:stone
setblock 97 94 339 minecraft:stripped_spruce_log
fill 97 94 340 97 95 340 minecraft:stone
setblock 97 94 344 minecraft:stripped_spruce_log
setblock 98 94 323 minecraft:stripped_spruce_log
setblock 98 94 363 minecraft:stripped_spruce_log
fill 99 94 323 102 94 323 minecraft:stone
fill 99 94 363 102 94 363 minecraft:stone
fill 100 94 364 100 107 364 minecraft:cobbled_deepslate
setblock 101 94 324 minecraft:stone
setblock 102 94 324 minecraft:stripped_spruce_log
setblock 103 94 323 minecraft:stripped_spruce_log
fill 103 94 324 106 94 324 minecraft:stone
setblock 103 94 363 minecraft:stripped_spruce_log
fill 104 94 323 107 94 323 minecraft:stone
setblock 104 94 362 minecraft:stripped_spruce_log
fill 104 94 363 107 94 363 minecraft:stone
setblock 105 94 325 minecraft:stone
fill 105 94 360 105 95 360 minecraft:cobbled_deepslate
fill 105 94 362 108 94 362 minecraft:stone
setblock 106 94 325 minecraft:stripped_spruce_log
fill 106 94 359 106 95 359 minecraft:cobbled_deepslate
fill 106 94 361 106 95 361 minecraft:cobbled_deepslate
setblock 107 94 324 minecraft:stripped_spruce_log
fill 107 94 325 107 97 325 minecraft:stone
fill 107 94 360 107 95 360 minecraft:cobbled_deepslate
fill 107 94 361 109 94 361 minecraft:stone
setblock 108 94 323 minecraft:stripped_spruce_log
fill 108 94 324 108 96 324 minecraft:stone
fill 108 94 326 109 94 326 minecraft:stone
setblock 108 94 363 minecraft:stripped_spruce_log
fill 109 94 323 109 96 323 minecraft:stone
setblock 109 94 362 minecraft:stripped_spruce_log
fill 109 94 363 112 94 363 minecraft:stone
setblock 110 94 325 minecraft:stone
setblock 110 94 326 minecraft:stripped_spruce_log
setblock 110 94 361 minecraft:stripped_spruce_log
fill 110 94 362 110 96 362 minecraft:stone
setblock 111 94 325 minecraft:stripped_spruce_log
fill 111 94 326 112 95 326 minecraft:stone
fill 111 94 361 111 97 361 minecraft:stone
setblock 112 94 324 minecraft:stripped_spruce_log
fill 112 94 325 112 97 325 minecraft:stone
setblock 113 94 323 minecraft:stripped_spruce_log
fill 113 94 324 113 96 324 minecraft:stone
setblock 113 94 363 minecraft:stripped_spruce_log
setblock 114 94 322 minecraft:raw_iron_block
fill 114 94 323 114 96 323 minecraft:stone
setblock 114 94 362 minecraft:stripped_spruce_log
fill 114 94 363 117 94 363 minecraft:stone
setblock 115 94 361 minecraft:stripped_spruce_log
fill 116 94 361 116 95 361 minecraft:stone
setblock 117 94 324 minecraft:stripped_spruce_log
setblock 118 94 323 minecraft:stripped_spruce_log
fill 118 94 324 118 96 324 minecraft:stone
setblock 118 94 363 minecraft:stripped_spruce_log
fill 119 94 323 122 94 323 minecraft:stone
setblock 119 94 362 minecraft:stripped_spruce_log
fill 119 94 363 122 94 363 minecraft:stone
fill 120 94 362 123 94 362 minecraft:stone
fill 122 94 361 124 94 361 minecraft:stone
setblock 123 94 323 minecraft:stripped_spruce_log
setblock 123 94 363 minecraft:stripped_spruce_log
fill 124 94 323 126 94 324 minecraft:stone
setblock 124 94 362 minecraft:stripped_spruce_log
fill 124 94 363 124 96 363 minecraft:stone
setblock 125 94 361 minecraft:stripped_spruce_log
fill 125 94 362 125 96 362 minecraft:stone
fill 126 94 361 126 97 361 minecraft:stone
setblock 127 94 323 minecraft:stone
setblock 127 94 324 minecraft:stripped_spruce_log
setblock 127 94 360 minecraft:stone
setblock 128 94 323 minecraft:stripped_spruce_log
fill 128 94 324 131 94 324 minecraft:stone
setblock 128 94 363 minecraft:stripped_spruce_log
fill 129 94 323 129 96 323 minecraft:stone
setblock 129 94 362 minecraft:stripped_spruce_log
fill 129 94 363 129 96 363 minecraft:stone
setblock 130 94 361 minecraft:stripped_spruce_log
fill 130 94 362 130 96 362 minecraft:stone
setblock 131 94 360 minecraft:stripped_spruce_log
fill 131 94 361 131 96 361 minecraft:stone
setblock 132 94 324 minecraft:stripped_spruce_log
fill 132 94 340 132 94 343 minecraft:stone
setblock 132 94 344 minecraft:stripped_spruce_log
fill 132 94 345 132 97 345 minecraft:stone
setblock 132 94 348 minecraft:stone
setblock 132 94 360 minecraft:stone
setblock 133 94 323 minecraft:stripped_spruce_log
fill 133 94 324 133 96 324 minecraft:stone
setblock 133 94 338 minecraft:stripped_spruce_log
fill 133 94 339 133 94 342 minecraft:stone
setblock 133 94 343 minecraft:stripped_spruce_log
fill 133 94 344 133 97 344 minecraft:stone
setblock 133 94 347 minecraft:stone
setblock 133 94 348 minecraft:stripped_spruce_log
fill 133 94 349 133 97 349 minecraft:stone
setblock 133 94 358 minecraft:stripped_spruce_log
fill 133 94 359 133 95 359 minecraft:stone
setblock 133 94 363 minecraft:stripped_spruce_log
fill 134 94 323 134 96 323 minecraft:stone
setblock 134 94 337 minecraft:stripped_spruce_log
fill 134 94 338 134 96 338 minecraft:stone
setblock 134 94 342 minecraft:stripped_spruce_log
setblock 134 94 347 minecraft:stripped_spruce_log
fill 134 94 348 134 96 348 minecraft:stone
setblock 134 94 352 minecraft:stripped_spruce_log
fill 134 94 353 134 95 353 minecraft:stone
setblock 134 94 357 minecraft:stripped_spruce_log
fill 134 94 358 134 95 358 minecraft:stone
fill 134 94 363 134 96 363 minecraft:stone
setblock 135 94 326 minecraft:stripped_spruce_log
setblock 135 94 336 minecraft:stripped_spruce_log
fill 135 94 337 135 96 337 minecraft:stone
setblock 135 94 341 minecraft:stripped_spruce_log
fill 135 94 342 135 96 342 minecraft:stone
setblock 135 94 346 minecraft:stripped_spruce_log
fill 135 94 347 135 96 347 minecraft:stone
setblock 135 94 351 minecraft:stripped_spruce_log
fill 135 94 352 135 96 352 minecraft:stone
setblock 135 94 356 minecraft:stripped_spruce_log
fill 135 94 357 135 96 357 minecraft:stone
setblock 135 94 361 minecraft:stripped_spruce_log
fill 135 94 362 135 96 362 minecraft:stone
setblock 136 94 337 minecraft:raw_iron_block
fill 94 95 342 94 104 343 minecraft:cobbled_deepslate
setblock 94 95 344 minecraft:gold_block
fill 95 95 323 95 95 324 minecraft:stone
setblock 95 95 325 minecraft:stripped_spruce_log
fill 95 95 326 95 95 329 minecraft:stone
setblock 95 95 330 minecraft:stripped_spruce_log
fill 95 95 331 95 95 334 minecraft:stone
setblock 95 95 335 minecraft:stripped_spruce_log
fill 95 95 336 95 95 339 minecraft:stone
setblock 95 95 340 minecraft:stripped_spruce_log
fill 95 95 341 95 95 344 minecraft:stone
setblock 95 95 345 minecraft:stripped_spruce_log
fill 95 95 346 95 95 349 minecraft:stone
setblock 95 95 350 minecraft:stripped_spruce_log
setblock 95 95 351 minecraft:stone
setblock 95 95 360 minecraft:stripped_spruce_log
setblock 95 95 361 minecraft:stone
setblock 96 95 324 minecraft:glowstone
fill 96 95 325 96 96 325 minecraft:stone
setblock 96 95 339 minecraft:stripped_spruce_log
fill 96 95 340 96 96 340 minecraft:stone
setblock 96 95 343 minecraft:glowstone
setblock 96 95 344 minecraft:stripped_spruce_log
fill 96 95 345 96 96 345 minecraft:stone
fill 96 95 347 96 96 347 minecraft:stone
setblock 96 95 362 minecraft:glowstone
setblock 97 95 323 minecraft:stripped_spruce_log
setblock 97 95 343 minecraft:stripped_spruce_log
setblock 97 95 363 minecraft:stripped_spruce_log
fill 98 95 323 101 95 323 minecraft:stone
fill 98 95 363 101 95 363 minecraft:stone
setblock 100 95 324 minecraft:stone
setblock 101 95 324 minecraft:stripped_spruce_log
setblock 102 95 323 minecraft:stripped_spruce_log
fill 102 95 324 105 95 324 minecraft:stone
setblock 102 95 363 minecraft:stripped_spruce_log
fill 103 95 323 106 95 323 minecraft:stone
fill 103 95 363 106 95 363 minecraft:stone
setblock 104 95 325 minecraft:stone
fill 104 95 362 107 95 362 minecraft:stone
setblock 105 95 325 minecraft:stripped_spruce_log
setblock 105 95 359 minecraft:cobbled_deepslate
setblock 105 95 361 minecraft:cobbled_deepslate
setblock 106 95 324 minecraft:stripped_spruce_log
fill 106 95 325 106 98 325 minecraft:stone
setblock 107 95 323 minecraft:stripped_spruce_log
fill 107 95 324 107 96 324 minecraft:stone
fill 107 95 326 108 95 326 minecraft:stone
setblock 107 95 359 minecraft:cobbled_deepslate
fill 107 95 361 108 95 361 minecraft:stone
setblock 107 95 363 minecraft:stripped_spruce_log
fill 108 95 323 108 96 323 minecraft:stone
setblock 108 95 362 minecraft:stripped_spruce_log
fill 108 95 363 111 95 363 minecraft:stone
setblock 109 95 326 minecraft:stripped_spruce_log
setblock 109 95 361 minecraft:stripped_spruce_log
fill 109 95 362 109 96 362 minecraft:stone
setblock 110 95 325 minecraft:stripped_spruce_log
fill 110 95 326 110 98 326 minecraft:stone
fill 110 95 361 110 97 361 minecraft:stone
setblock 111 95 324 minecraft:stripped_spruce_log
fill 111 95 325 111 98 325 minecraft:stone
setblock 112 95 323 minecraft:stripped_spruce_log
fill 112 95 324 112 96 324 minecraft:stone
setblock 112 95 363 minecraft:stripped_spruce_log
fill 113 95 323 113 96 323 minecraft:stone
setblock 113 95 362 minecraft:stripped_spruce_log
fill 113 95 363 116 95 363 minecraft:stone
fill 114 95 322 114 107 322 minecraft:cobbled_deepslate
setblock 114 95 325 minecraft:stone
setblock 114 95 361 minecraft:stripped_spruce_log
fill 114 95 362 114 96 362 minecraft:stone
setblock 115 95 324 minecraft:glowstone
setblock 115 95 325 minecraft:stripped_spruce_log
setblock 115 95 361 minecraft:stone
setblock 115 95 362 minecraft:glowstone
setblock 116 95 324 minecraft:stripped_spruce_log
setblock 117 95 323 minecraft:stripped_spruce_log
fill 117 95 324 117 96 324 minecraft:stone
setblock 117 95 363 minecraft:stripped_spruce_log
fill 118 95 323 121 95 323 minecraft:stone
setblock 118 95 362 minecraft:stripped_spruce_log
fill 118 95 363 121 95 363 minecraft:stone
fill 119 95 362 122 95 362 minecraft:stone
fill 120 95 364 123 104 364 minecraft:cobbled_deepslate
setblock 122 95 323 minecraft:stripped_spruce_log
setblock 122 95 363 minecraft:stripped_spruce_log
fill 123 95 323 125 95 324 minecraft:stone
setblock 123 95 361 minecraft:stone
setblock 123 95 362 minecraft:stripped_spruce_log
fill 123 95 363 123 96 363 minecraft:stone
setblock 124 95 361 minecraft:stripped_spruce_log
fill 124 95 362 124 96 362 minecraft:stone
setblock 124 95 364 minecraft:gold_block
fill 125 95 361 125 97 361 minecraft:stone
setblock 126 95 323 minecraft:stone
setblock 126 95 324 minecraft:stripped_spruce_log
setblock 127 95 323 minecraft:stripped_spruce_log
fill 127 95 324 130 95 324 minecraft:stone
setblock 127 95 363 minecraft:stripped_spruce_log
fill 128 95 323 128 96 323 minecraft:stone
setblock 128 95 362 minecraft:stripped_spruce_log
fill 128 95 363 128 96 363 minecraft:stone
setblock 129 95 361 minecraft:stripped_spruce_log
fill 129 95 362 129 96 362 minecraft:stone
setblock 130 95 360 minecraft:stripped_spruce_log
fill 130 95 361 130 97 361 minecraft:stone
setblock 131 95 324 minecraft:stripped_spruce_log
setblock 132 95 323 minecraft:stripped_spruce_log
fill 132 95 324 132 96 324 minecraft:stone
fill 132 95 340 132 95 342 minecraft:stone
setblock 132 95 343 minecraft:stripped_spruce_log
fill 132 95 344 132 97 344 minecraft:stone
setblock 132 95 348 minecraft:stripped_spruce_log
setblock 132 95 363 minecraft:stripped_spruce_log
fill 133 95 323 133 96 323 minecraft:stone
fill 133 95 338 133 95 341 minecraft:stone
setblock 133 95 342 minecraft:stripped_spruce_log
fill 133 95 343 133 98 343 minecraft:stone
setblock 133 95 347 minecraft:stripped_spruce_log
fill 133 95 348 133 98 348 minecraft:stone
setblock 133 95 362 minecraft:stripped_spruce_log
fill 133 95 363 133 96 363 minecraft:stone
setblock 134 95 324 minecraft:glowstone
setblock 134 95 336 minecraft:stripped_spruce_log
fill 134 95 337 134 96 337 minecraft:stone
setblock 134 95 341 minecraft:stripped_spruce_log
fill 134 95 342 134 96 342 minecraft:stone
setblock 134 95 343 minecraft:glowstone
setblock 134 95 346 minecraft:stripped_spruce_log
fill 134 95 347 134 96 347 minecraft:stone
setblock 134 95 351 minecraft:stripped_spruce_log
fill 134 95 352 134 96 352 minecraft:stone
setblock 134 95 356 minecraft:stripped_spruce_log
setblock 134 95 357 minecraft:stone
setblock 134 95 361 minecraft:stripped_spruce_log
setblock 134 95 362 minecraft:glowstone
setblock 135 95 324 minecraft:stone
setblock 135 95 325 minecraft:stripped_spruce_log
fill 135 95 326 135 95 327 minecraft:stone
setblock 135 95 335 minecraft:stripped_spruce_log
fill 135 95 336 135 96 336 minecraft:stone
setblock 135 95 340 minecraft:stripped_spruce_log
fill 135 95 341 135 96 341 minecraft:stone
setblock 135 95 345 minecraft:stripped_spruce_log
fill 135 95 346 135 96 346 minecraft:stone
setblock 135 95 350 minecraft:stripped_spruce_log
fill 135 95 351 135 96 351 minecraft:stone
setblock 135 95 355 minecraft:stripped_spruce_log
fill 135 95 356 135 96 356 minecraft:stone
setblock 135 95 360 minecraft:stripped_spruce_log
fill 135 95 361 135 96 361 minecraft:stone
fill 136 95 337 136 107 337 minecraft:cobbled_deepslate
fill 94 96 344 94 107 344 minecraft:cobbled_deepslate
setblock 94 96 353 minecraft:raw_gold_block
setblock 95 96 323 minecraft:stone
setblock 95 96 324 minecraft:stripped_spruce_log
fill 95 96 325 95 96 328 minecraft:stone
setblock 95 96 329 minecraft:stripped_spruce_log
fill 95 96 330 95 96 333 minecraft:stone
setblock 95 96 334 minecraft:stripped_spruce_log
fill 95 96 335 95 96 338 minecraft:stone
setblock 95 96 339 minecraft:stripped_spruce_log
fill 95 96 340 95 96 343 minecraft:stone
setblock 95 96 344 minecraft:stripped_spruce_log
fill 95 96 345 95 96 348 minecraft:stone
setblock 95 96 349 minecraft:stripped_spruce_log
setblock 95 96 350 minecraft:stone
setblock 96 96 323 minecraft:stripped_spruce_log
fill 96 96 324 96 97 324 minecraft:spruce_log
setblock 96 96 338 minecraft:stripped_spruce_log
setblock 96 96 339 minecraft:stone
fill 96 96 343 96 97 343 minecraft:spruce_log
setblock 96 96 344 minecraft:stone
fill 96 96 362 96 97 362 minecraft:spruce_log
setblock 96 96 363 minecraft:stripped_spruce_log
fill 97 96 323 100 96 323 minecraft:stone
setblock 97 96 325 minecraft:light[level=12]
setblock 97 96 332 minecraft:light[level=12]
setblock 97 96 339 minecraft:light[level=12]
setblock 97 96 346 minecraft:light[level=12]
setblock 97 96 353 minecraft:light[level=12]
setblock 97 96 360 minecraft:light[level=12]
setblock 99 96 324 minecraft:stone
setblock 100 96 324 minecraft:stripped_spruce_log
setblock 100 96 363 minecraft:stone
setblock 101 96 323 minecraft:stripped_spruce_log
fill 101 96 324 104 96 324 minecraft:stone
setblock 101 96 363 minecraft:stripped_spruce_log
fill 102 96 323 105 96 323 minecraft:stone
fill 102 96 363 105 96 363 minecraft:stone
setblock 103 96 325 minecraft:stone
setblock 104 96 325 minecraft:stripped_spruce_log
setblock 104 96 332 minecraft:light[level=12]
setblock 104 96 339 minecraft:light[level=12]
setblock 104 96 346 minecraft:light[level=12]
setblock 104 96 353 minecraft:light[level=12]
setblock 104 96 360 minecraft:light[level=12]
fill 104 96 362 106 96 362 minecraft:stone
setblock 105 96 324 minecraft:stripped_spruce_log
fill 105 96 325 105 99 325 minecraft:stone
setblock 106 96 323 minecraft:stripped_spruce_log
setblock 106 96 324 minecraft:stone
fill 106 96 326 107 96 326 minecraft:stone
setblock 106 96 363 minecraft:stripped_spruce_log
setblock 107 96 323 minecraft:stone
setblock 107 96 361 minecraft:stone
setblock 107 96 362 minecraft:stripped_spruce_log
fill 107 96 363 110 96 363 minecraft:stone
setblock 108 96 326 minecraft:stripped_spruce_log
setblock 108 96 361 minecraft:stripped_spruce_log
setblock 108 96 362 minecraft:stone
setblock 109 96 325 minecraft:stripped_spruce_log
fill 109 96 326 109 99 326 minecraft:stone
fill 109 96 361 109 97 361 minecraft:stone
setblock 110 96 324 minecraft:stripped_spruce_log
fill 110 96 325 110 99 325 minecraft:stone
setblock 111 96 323 minecraft:stripped_spruce_log
setblock 111 96 324 minecraft:stone
fill 111 96 326 111 97 326 minecraft:stone
setblock 111 96 332 minecraft:light[level=12]
setblock 111 96 339 minecraft:light[level=12]
setblock 111 96 346 minecraft:light[level=12]
setblock 111 96 353 minecraft:light[level=12]
setblock 111 96 360 minecraft:light[level=12]
setblock 111 96 363 minecraft:stripped_spruce_log
setblock 112 96 323 minecraft:stone
setblock 112 96 362 minecraft:stripped_spruce_log
fill 112 96 363 115 96 363 minecraft:stone
setblock 113 96 361 minecraft:stripped_spruce_log
setblock 113 96 362 minecraft:stone
setblock 114 96 325 minecraft:stripped_spruce_log
setblock 114 96 361 minecraft:stone
fill 115 96 324 115 97 324 minecraft:spruce_log
setblock 115 96 325 minecraft:stone
fill 115 96 362 115 97 362 minecraft:spruce_log
setblock 116 96 323 minecraft:stripped_spruce_log
setblock 116 96 324 minecraft:stone
setblock 116 96 363 minecraft:stripped_spruce_log
fill 117 96 323 120 96 323 minecraft:stone
setblock 117 96 362 minecraft:stripped_spruce_log
fill 117 96 363 120 96 363 minecraft:stone
setblock 118 96 325 minecraft:light[level=12]
setblock 118 96 332 minecraft:light[level=12]
setblock 118 96 339 minecraft:light[level=12]
setblock 118 96 346 minecraft:light[level=12]
setblock 118 96 353 minecraft:light[level=12]
setblock 118 96 360 minecraft:light[level=12]
fill 118 96 362 121 96 362 minecraft:stone
setblock 121 96 323 minecraft:stripped_spruce_log
setblock 121 96 363 minecraft:stripped_spruce_log
fill 122 96 323 125 96 323 minecraft:stone
setblock 122 96 362 minecraft:stripped_spruce_log
setblock 122 96 363 minecraft:stone
fill 123 96 324 124 96 324 minecraft:stone
setblock 123 96 362 minecraft:stone
setblock 124 96 361 minecraft:stone
fill 124 96 364 124 107 364 minecraft:cobbled_deepslate
setblock 125 96 324 minecraft:stripped_spruce_log
setblock 125 96 325 minecraft:light[level=12]
setblock 125 96 332 minecraft:light[level=12]
setblock 125 96 339 minecraft:light[level=12]
setblock 125 96 346 minecraft:light[level=12]
setblock 125 96 353 minecraft:light[level=12]
setblock 125 96 360 minecraft:light[level=12]
setblock 126 96 323 minecraft:stripped_spruce_log
fill 126 96 324 129 96 324 minecraft:stone
setblock 126 96 363 minecraft:stripped_spruce_log
setblock 127 96 323 minecraft:stone
setblock 127 96 362 minecraft:stripped_spruce_log
setblock 127 96 363 minecraft:stone
setblock 128 96 361 minecraft:stripped_spruce_log
setblock 128 96 362 minecraft:stone
fill 129 96 361 129 97 361 minecraft:stone
setblock 130 96 324 minecraft:stripped_spruce_log
setblock 131 96 323 minecraft:stripped_spruce_log
setblock 131 96 324 minecraft:stone
setblock 131 96 363 minecraft:stripped_spruce_log
setblock 132 96 323 minecraft:stone
setblock 132 96 325 minecraft:light[level=12]
setblock 132 96 332 minecraft:light[level=12]
setblock 132 96 339 minecraft:light[level=12]
setblock 132 96 341 minecraft:stone
setblock 132 96 342 minecraft:stripped_spruce_log
fill 132 96 343 132 97 343 minecraft:stone
setblock 132 96 346 minecraft:stone
setblock 132 96 347 minecraft:stripped_spruce_log
setblock 132 96 348 minecraft:stone
setblock 132 96 353 minecraft:light[level=12]
setblock 132 96 360 minecraft:light[level=12]
setblock 132 96 362 minecraft:stripped_spruce_log
setblock 132 96 363 minecraft:stone
fill 133 96 339 133 96 340 minecraft:stone
setblock 133 96 341 minecraft:stripped_spruce_log
fill 133 96 342 133 98 342 minecraft:stone
setblock 133 96 346 minecraft:stripped_spruce_log
fill 133 96 347 133 99 347 minecraft:stone
setblock 133 96 350 minecraft:stone
setblock 133 96 362 minecraft:stone
fill 134 96 324 134 97 324 minecraft:spruce_log
setblock 134 96 340 minecraft:stripped_spruce_log
setblock 134 96 341 minecraft:stone
fill 134 96 343 134 97 343 minecraft:spruce_log
setblock 134 96 345 minecraft:stripped_spruce_log
setblock 134 96 346 minecraft:stone
setblock 134 96 350 minecraft:stripped_spruce_log
setblock 134 96 351 minecraft:stone
setblock 134 96 360 minecraft:stripped_spruce_log
setblock 134 96 361 minecraft:stone
fill 134 96 362 134 97 362 minecraft:spruce_log
setblock 135 96 324 minecraft:stripped_spruce_log
fill 135 96 325 135 96 326 minecraft:stone
setblock 135 96 335 minecraft:stone
setblock 135 96 339 minecraft:stripped_spruce_log
setblock 135 96 340 minecraft:stone
setblock 135 96 344 minecraft:stripped_spruce_log
setblock 135 96 345 minecraft:stone
setblock 135 96 349 minecraft:stripped_spruce_log
setblock 135 96 350 minecraft:stone
setblock 135 96 354 minecraft:stripped_spruce_log
setblock 135 96 355 minecraft:stone
setblock 135 96 359 minecraft:stripped_spruce_log
setblock 135 96 360 minecraft:stone
fill 136 96 345 136 107 346 minecraft:cobbled_deepslate
setblock 136 96 347 minecraft:raw_iron_block
fill 94 97 322 94 103 322 minecraft:cobbled_deepslate
setblock 94 97 323 minecraft:gold_block
fill 94 97 324 94 98 324 minecraft:cobbled_deepslate
setblock 94 97 331 minecraft:gold_block
fill 94 97 353 94 107 353 minecraft:cobbled_deepslate
fill 95 97 323 95 97 363 minecraft:spruce_planks
fill 96 97 323 135 97 323 minecraft:spruce_planks
fill 96 97 325 96 97 342 minecraft:spruce_planks
fill 96 97 344 96 97 361 minecraft:spruce_planks
fill 96 97 363 135 97 363 minecraft:spruce_planks
fill 97 97 324 114 97 324 minecraft:spruce_planks
fill 97 97 362 114 97 362 minecraft:spruce_planks
setblock 103 97 325 minecraft:stripped_spruce_log
fill 104 97 325 104 100 325 minecraft:stone
setblock 106 97 326 minecraft:stone
setblock 107 97 326 minecraft:stripped_spruce_log
setblock 108 97 325 minecraft:stripped_spruce_log
fill 108 97 326 108 100 326 minecraft:stone
setblock 108 97 361 minecraft:stone
fill 109 97 325 109 100 325 minecraft:stone
fill 112 97 322 112 107 322 minecraft:cobbled_deepslate
setblock 112 97 361 minecraft:stripped_spruce_log
setblock 113 97 322 minecraft:raw_gold_block
setblock 113 97 325 minecraft:stripped_spruce_log
setblock 114 97 325 minecraft:stone
fill 116 97 324 133 97 324 minecraft:spruce_planks
fill 116 97 362 133 97 362 minecraft:spruce_planks
setblock 127 97 361 minecraft:stripped_spruce_log
setblock 128 97 361 minecraft:stone
setblock 132 97 346 minecraft:stripped_spruce_log
setblock 132 97 347 minecraft:stone
setblock 133 97 340 minecraft:stripped_spruce_log
setblock 133 97 341 minecraft:stone
setblock 133 97 345 minecraft:stripped_spruce_log
fill 133 97 346 133 100 346 minecraft:stone
setblock 133 97 350 minecraft:stripped_spruce_log
fill 134 97 325 135 97 342 minecraft:spruce_planks
fill 134 97 344 135 97 361 minecraft:spruce_planks
setblock 135 97 324 minecraft:spruce_planks
setblock 135 97 343 minecraft:spruce_planks
setblock 135 97 362 minecraft:spruce_planks
fill 136 97 347 136 103 347 minecraft:cobbled_deepslate
fill 94 98 323 94 107 323 minecraft:cobbled_deepslate
fill 94 98 331 94 103 331 minecraft:cobbled_deepslate
fill 95 98 323 95 98 326 minecraft:stone
setblock 95 98 327 minecraft:stripped_spruce_log
fill 95 98 328 95 99 330 minecraft:stone
setblock 95 98 337 minecraft:stripped_spruce_log
fill 95 98 338 95 98 341 minecraft:stone
setblock 95 98 342 minecraft:stripped_spruce_log
fill 95 98 343 95 98 346 minecraft:stone
setblock 95 98 347 minecraft:stripped_spruce_log
fill 95 98 348 95 98 349 minecraft:stone
fill 96 98 323 98 98 323 minecraft:stone
fill 96 98 342 96 98 345 minecraft:stone
setblock 97 98 325 minecraft:light[level=15]
setblock 97 98 333 minecraft:light[level=15]
setblock 97 98 341 minecraft:light[level=15]
setblock 97 98 349 minecraft:light[level=15]
setblock 97 98 357 minecraft:light[level=15]
setblock 99 98 323 minecraft:stripped_spruce_log
fill 99 98 324 102 98 324 minecraft:stone
setblock 100 98 322 minecraft:gold_block
fill 100 98 323 103 98 323 minecraft:stone
setblock 102 98 325 minecraft:stripped_spruce_log
fill 102 98 363 103 98 363 minecraft:stone
setblock 103 98 324 minecraft:stripped_spruce_log
fill 103 98 325 103 101 325 minecraft:stone
setblock 104 98 323 minecraft:stripped_spruce_log
fill 104 98 324 107 98 324 minecraft:stone
setblock 104 98 363 minecraft:stripped_spruce_log
fill 105 98 323 108 98 323 minecraft:stone
setblock 105 98 326 minecraft:stone
setblock 105 98 333 minecraft:light[level=15]
setblock 105 98 341 minecraft:light[level=15]
setblock 105 98 349 minecraft:light[level=15]
setblock 105 98 357 minecraft:light[level=15]
setblock 105 98 362 minecraft:stripped_spruce_log
fill 105 98 363 108 98 363 minecraft:stone
setblock 106 98 326 minecraft:stripped_spruce_log
fill 106 98 362 109 98 362 minecraft:stone
setblock 107 98 325 minecraft:stripped_spruce_log
fill 107 98 326 107 101 326 minecraft:stone
setblock 108 98 324 minecraft:stripped_spruce_log
fill 108 98 325 108 101 325 minecraft:stone
setblock 109 98 323 minecraft:stripped_spruce_log
fill 109 98 324 112 98 324 minecraft:stone
setblock 109 98 363 minecraft:stripped_spruce_log
fill 110 98 323 113 98 323 minecraft:stone
setblock 110 98 362 minecraft:stripped_spruce_log
fill 110 98 363 113 98 363 minecraft:stone
fill 111 98 362 114 98 362 minecraft:stone
setblock 112 98 325 minecraft:stripped_spruce_log
fill 113 98 322 113 103 322 minecraft:cobbled_deepslate
setblock 113 98 324 minecraft:stripped_spruce_log
setblock 113 98 325 minecraft:stone
setblock 113 98 333 minecraft:light[level=15]
setblock 113 98 341 minecraft:light[level=15]
setblock 113 98 349 minecraft:light[level=15]
setblock 113 98 357 minecraft:light[level=15]
setblock 114 98 323 minecraft:stripped_spruce_log
fill 114 98 324 116 98 324 minecraft:stone
setblock 114 98 363 minecraft:stripped_spruce_log
fill 115 98 323 118 98 323 minecraft:stone
setblock 115 98 362 minecraft:stripped_spruce_log
fill 115 98 363 118 98 363 minecraft:stone
setblock 119 98 323 minecraft:stripped_spruce_log
setblock 119 98 363 minecraft:stripped_spruce_log
fill 120 98 323 123 98 323 minecraft:stone
fill 120 98 363 123 98 363 minecraft:stone
setblock 121 98 325 minecraft:light[level=15]
setblock 121 98 333 minecraft:light[level=15]
setblock 121 98 341 minecraft:light[level=15]
setblock 121 98 349 minecraft:light[level=15]
setblock 121 98 357 minecraft:light[level=15]
fill 121 98 362 124 98 362 minecraft:stone
setblock 123 98 324 minecraft:stripped_spruce_log
setblock 124 98 322 minecraft:diamond_block
setblock 124 98 323 minecraft:stripped_spruce_log
fill 124 98 324 127 98 324 minecraft:stone
setblock 124 98 363 minecraft:stripped_spruce_log
fill 125 98 323 128 98 323 minecraft:stone
setblock 125 98 362 minecraft:stripped_spruce_log
fill 125 98 363 128 98 363 minecraft:stone
fill 126 98 362 129 98 362 minecraft:stone
setblock 127 98 361 minecraft:stone
setblock 128 98 324 minecraft:stripped_spruce_log
setblock 129 98 323 minecraft:stripped_spruce_log
fill 129 98 324 131 98 324 minecraft:stone
setblock 129 98 325 minecraft:light[level=15]
setblock 129 98 333 minecraft:light[level=15]
setblock 129 98 341 minecraft:light[level=15]
setblock 129 98 349 minecraft:light[level=15]
setblock 129 98 357 minecraft:light[level=15]
setblock 129 98 363 minecraft:stripped_spruce_log
fill 130 98 323 133 98 323 minecraft:stone
setblock 130 98 362 minecraft:stripped_spruce_log
fill 130 98 363 133 98 363 minecraft:stone
setblock 131 98 362 minecraft:stone
setblock 132 98 345 minecraft:stripped_spruce_log
setblock 132 98 346 minecraft:stone
setblock 133 98 344 minecraft:stripped_spruce_log
fill 133 98 345 135 99 345 minecraft:stone
setblock 133 98 349 minecraft:stripped_spruce_log
setblock 134 98 323 minecraft:stripped_spruce_log
fill 134 98 340 134 98 342 minecraft:stone
setblock 134 98 343 minecraft:stripped_spruce_log
fill 134 98 344 135 100 344 minecraft:stone
fill 134 98 346 134 98 347 minecraft:stone
setblock 134 98 348 minecraft:stripped_spruce_log
fill 134 98 349 135 99 350 minecraft:stone
setblock 134 98 363 minecraft:stripped_spruce_log
fill 135 98 323 135 98 325 minecraft:stone
fill 135 98 338 135 98 341 minecraft:stone
setblock 135 98 342 minecraft:stripped_spruce_log
fill 135 98 343 135 101 343 minecraft:stone
setblock 135 98 346 minecraft:stone
setblock 135 98 347 minecraft:stripped_spruce_log
fill 135 98 348 135 101 348 minecraft:stone
setblock 135 98 351 minecraft:stone
setblock 135 98 352 minecraft:stripped_spruce_log
setblock 94 99 324 minecraft:gold_block
fill 95 99 323 95 99 325 minecraft:stone
setblock 95 99 326 minecraft:stripped_spruce_log
fill 95 99 327 95 102 327 minecraft:stone
fill 95 99 339 95 99 340 minecraft:stone
setblock 95 99 341 minecraft:stripped_spruce_log
fill 95 99 342 95 99 345 minecraft:stone
setblock 95 99 346 minecraft:stripped_spruce_log
fill 95 99 347 95 100 348 minecraft:stone
fill 96 99 323 97 99 323 minecraft:stone
setblock 98 99 323 minecraft:stripped_spruce_log
fill 99 99 323 101 99 324 minecraft:stone
fill 100 99 322 100 107 322 minecraft:cobbled_deepslate
setblock 102 99 323 minecraft:stone
setblock 102 99 324 minecraft:stripped_spruce_log
fill 102 99 325 102 102 325 minecraft:stone
setblock 102 99 363 minecraft:stone
setblock 103 99 323 minecraft:stripped_spruce_log
fill 103 99 324 106 99 324 minecraft:stone
setblock 103 99 363 minecraft:stripped_spruce_log
fill 104 99 323 107 99 323 minecraft:stone
fill 104 99 363 107 99 363 minecraft:stone
setblock 105 99 326 minecraft:stripped_spruce_log
fill 105 99 362 108 99 362 minecraft:stone
setblock 106 99 325 minecraft:stripped_spruce_log
fill 106 99 326 106 102 326 minecraft:stone
setblock 107 99 324 minecraft:stripped_spruce_log
fill 107 99 325 107 102 325 minecraft:stone
setblock 108 99 323 minecraft:stripped_spruce_log
fill 108 99 324 111 99 324 minecraft:stone
setblock 108 99 363 minecraft:stripped_spruce_log
setblock 108 99 364 minecraft:diamond_block
fill 109 99 323 112 99 323 minecraft:stone
setblock 109 99 362 minecraft:stripped_spruce_log
fill 109 99 363 112 99 363 minecraft:stone
fill 110 99 362 113 99 362 minecraft:stone
setblock 111 99 325 minecraft:stripped_spruce_log
setblock 112 99 324 minecraft:stripped_spruce_log
setblock 112 99 325 minecraft:stone
setblock 113 99 323 minecraft:stripped_spruce_log
fill 113 99 324 115 99 324 minecraft:stone
setblock 113 99 363 minecraft:stripped_spruce_log
fill 114 99 323 117 99 323 minecraft:stone
fill 114 99 363 117 99 363 minecraft:stone
setblock 118 99 323 minecraft:stripped_spruce_log
setblock 118 99 363 minecraft:stripped_spruce_log
fill 119 99 323 122 99 323 minecraft:stone
fill 119 99 363 122 99 363 minecraft:stone
setblock 123 99 323 minecraft:stripped_spruce_log
setblock 123 99 362 minecraft:stone
setblock 123 99 363 minecraft:stripped_spruce_log
fill 124 99 322 124 103 322 minecraft:cobbled_deepslate
fill 124 99 323 126 99 324 minecraft:stone
setblock 124 99 362 minecraft:stripped_spruce_log
fill 124 99 363 127 99 363 minecraft:stone
fill 125 99 362 128 99 362 minecraft:stone
setblock 127 99 323 minecraft:stone
setblock 127 99 324 minecraft:stripped_spruce_log
setblock 128 99 323 minecraft:stripped_spruce_log
fill 128 99 324 130 99 324 minecraft:stone
setblock 128 99 363 minecraft:stripped_spruce_log
fill 129 99 323 132 99 323 minecraft:stone
setblock 129 99 362 minecraft:stripped_spruce_log
fill 129 99 363 132 99 363 minecraft:stone
setblock 130 99 362 minecraft:stone
setblock 133 99 323 minecraft:stripped_spruce_log
setblock 133 99 343 minecraft:stripped_spruce_log
setblock 133 99 344 minecraft:stone
setblock 133 99 348 minecraft:stripped_spruce_log
setblock 134 99 341 minecraft:stone
setblock 134 99 342 minecraft:stripped_spruce_log
fill 134 99 343 134 100 343 minecraft:stone
setblock 134 99 346 minecraft:stone
setblock 134 99 347 minecraft:stripped_spruce_log
fill 134 99 348 134 102 348 minecraft:stone
fill 135 99 339 135 99 340 minecraft:stone
setblock 135 99 341 minecraft:stripped_spruce_log
fill 135 99 342 135 102 342 minecraft:stone
setblock 135 99 346 minecraft:stripped_spruce_log
fill 135 99 347 135 102 347 minecraft:stone
setblock 135 99 351 minecraft:stripped_spruce_log
setblock 136 99 356 minecraft:raw_gold_block
fill 94 100 324 94 107 324 minecraft:cobbled_deepslate
fill 95 100 323 95 100 324 minecraft:stone
setblock 95 100 325 minecraft:stripped_spruce_log
fill 95 100 326 95 103 326 minecraft:stone
fill 95 100 328 95 100 329 minecraft:stone
setblock 95 100 330 minecraft:stripped_spruce_log
fill 95 100 341 95 100 344 minecraft:stone
setblock 95 100 345 minecraft:stripped_spruce_log
fill 95 100 346 95 101 346 minecraft:stone
setblock 96 100 323 minecraft:stone
fill 96 100 340 96 112 340 minecraft:iron_bars
setblock 97 100 323 minecraft:stripped_spruce_log
fill 98 100 323 101 100 323 minecraft:stone
fill 99 100 324 100 100 324 minecraft:stone
setblock 101 100 324 minecraft:stripped_spruce_log
setblock 102 100 323 minecraft:stripped_spruce_log
fill 102 100 324 105 100 324 minecraft:stone
setblock 102 100 363 minecraft:stripped_spruce_log
fill 103 100 323 106 100 323 minecraft:stone
fill 103 100 363 106 100 363 minecraft:stone
setblock 105 100 325 minecraft:stripped_spruce_log
fill 105 100 326 105 103 326 minecraft:stone
setblock 106 100 324 minecraft:stripped_spruce_log
fill 106 100 325 106 103 325 minecraft:stone
fill 106 100 362 107 100 362 minecraft:stone
fill 106 100 364 106 107 364 minecraft:cobbled_deepslate
setblock 107 100 323 minecraft:stripped_spruce_log
fill 107 100 324 110 100 324 minecraft:stone
setblock 107 100 363 minecraft:stripped_spruce_log
setblock 107 100 364 minecraft:raw_gold_block
fill 108 100 323 111 100 323 minecraft:stone
setblock 108 100 362 minecraft:stripped_spruce_log
fill 108 100 363 111 100 363 minecraft:stone
fill 108 100 364 108 107 364 minecraft:cobbled_deepslate
fill 109 100 362 111 100 362 minecraft:stone
setblock 110 100 325 minecraft:stripped_spruce_log
setblock 111 100 324 minecraft:stripped_spruce_log
fill 111 100 325 111 101 325 minecraft:stone
setblock 112 100 323 minecraft:stripped_spruce_log
fill 112 100 324 114 100 324 minecraft:stone
setblock 112 100 363 minecraft:stripped_spruce_log
fill 113 100 323 116 100 323 minecraft:stone
fill 113 100 363 116 100 363 minecraft:stone
fill 116 100 322 118 105 322 minecraft:cobbled_deepslate
setblock 117 100 323 minecraft:stripped_spruce_log
setblock 117 100 363 minecraft:stripped_spruce_log
fill 118 100 323 121 100 323 minecraft:stone
fill 118 100 363 121 100 363 minecraft:stone
setblock 119 100 322 minecraft:raw_gold_block
fill 120 100 322 121 107 322 minecraft:cobbled_deepslate
setblock 122 100 323 minecraft:stripped_spruce_log
setblock 122 100 363 minecraft:stripped_spruce_log
fill 123 100 323 126 100 323 minecraft:stone
fill 123 100 363 126 100 363 minecraft:stone
fill 124 100 324 125 100 324 minecraft:stone
fill 124 100 362 127 100 362 minecraft:stone
setblock 126 100 324 minecraft:stripped_spruce_log
setblock 127 100 323 minecraft:stripped_spruce_log
fill 127 100 324 129 100 324 minecraft:stone
setblock 127 100 363 minecraft:stripped_spruce_log
fill 128 100 323 131 100 323 minecraft:stone
setblock 128 100 362 minecraft:stripped_spruce_log
fill 128 100 363 131 100 363 minecraft:stone
setblock 132 100 323 minecraft:stripped_spruce_log
setblock 133 100 347 minecraft:stripped_spruce_log
setblock 134 100 345 minecraft:stone
setblock 134 100 346 minecraft:stripped_spruce_log
fill 134 100 347 134 103 347 minecraft:stone
fill 134 100 349 135 100 349 minecraft:stone
setblock 135 100 341 minecraft:stone
setblock 135 100 345 minecraft:stripped_spruce_log
fill 135 100 346 135 103 346 minecraft:stone
setblock 135 100 350 minecraft:stripped_spruce_log
fill 135 100 351 135 103 351 minecraft:stone
setblock 136 100 344 minecraft:raw_gold_block
fill 136 100 356 136 107 356 minecraft:cobbled_deepslate
setblock 94 101 350 minecraft:raw_iron_block
fill 94 101 351 94 102 351 minecraft:cobbled_deepslate
setblock 95 101 324 minecraft:stripped_spruce_log
fill 95 101 325 95 104 325 minecraft:stone
setblock 95 101 328 minecraft:stone
setblock 95 101 329 minecraft:stripped_spruce_log
fill 95 101 330 95 104 330 minecraft:stone
setblock 95 101 344 minecraft:stripped_spruce_log
setblock 95 101 345 minecraft:stone
setblock 95 101 347 minecraft:stone
setblock 96 101 322 minecraft:raw_gold_block
setblock 96 101 323 minecraft:stripped_spruce_log
fill 97 101 323 100 101 323 minecraft:stone
setblock 97 101 364 minecraft:diamond_block
setblock 99 101 324 minecraft:stone
setblock 100 101 324 minecraft:stripped_spruce_log
setblock 101 101 323 minecraft:stripped_spruce_log
fill 101 101 324 101 103 325 minecraft:stone
fill 102 101 323 104 101 324 minecraft:stone
fill 102 101 363 105 101 363 minecraft:stone
setblock 104 101 325 minecraft:stripped_spruce_log
fill 104 101 326 104 104 326 minecraft:stone
setblock 105 101 323 minecraft:stone
setblock 105 101 324 minecraft:stripped_spruce_log
fill 105 101 325 105 104 325 minecraft:stone
setblock 106 101 323 minecraft:stripped_spruce_log
fill 106 101 324 109 101 324 minecraft:stone
setblock 106 101 362 minecraft:stone
setblock 106 101 363 minecraft:stripped_spruce_log
fill 107 101 323 110 101 323 minecraft:stone
setblock 107 101 362 minecraft:stripped_spruce_log
fill 107 101 363 110 101 363 minecraft:stone
fill 107 101 364 107 103 364 minecraft:cobbled_deepslate
setblock 108 101 326 minecraft:stripped_spruce_log
fill 108 101 362 109 101 362 minecraft:stone
setblock 109 101 325 minecraft:stripped_spruce_log
setblock 110 101 324 minecraft:stripped_spruce_log
fill 110 101 325 110 102 325 minecraft:stone
setblock 111 101 323 minecraft:stripped_spruce_log
fill 111 101 324 113 101 324 minecraft:stone
setblock 111 101 363 minecraft:stripped_spruce_log
fill 112 101 323 115 101 323 minecraft:stone
fill 112 101 363 115 101 363 minecraft:stone
setblock 116 101 323 minecraft:stripped_spruce_log
setblock 117 101 323 minecraft:stone
fill 119 101 322 119 107 322 minecraft:cobbled_deepslate
fill 119 101 323 120 101 323 minecraft:stone
fill 119 101 363 120 101 363 minecraft:stone
setblock 121 101 323 minecraft:stripped_spruce_log
setblock 121 101 363 minecraft:stripped_spruce_log
fill 122 101 323 125 101 323 minecraft:stone
fill 122 101 363 125 101 363 minecraft:stone
setblock 125 101 324 minecraft:stripped_spruce_log
setblock 126 101 323 minecraft:stripped_spruce_log
fill 126 101 324 127 101 324 minecraft:stone
setblock 126 101 363 minecraft:stripped_spruce_log
fill 127 101 323 130 101 323 minecraft:stone
fill 127 101 363 130 101 363 minecraft:stone
setblock 131 101 323 minecraft:stripped_spruce_log
setblock 134 101 344 minecraft:stone
setblock 134 101 345 minecraft:stripped_spruce_log
fill 134 101 346 134 103 346 minecraft:stone
setblock 134 101 349 minecraft:stone
setblock 134 101 364 minecraft:raw_iron_block
setblock 135 101 344 minecraft:stripped_spruce_log
fill 135 101 345 135 104 345 minecraft:stone
setblock 135 101 349 minecraft:stripped_spruce_log
fill 135 101 350 135 104 350 minecraft:stone
fill 135 101 364 136 103 364 minecraft:cobbled_deepslate
setblock 136 101 324 minecraft:raw_gold_block
fill 136 101 344 136 105 344 minecraft:cobbled_deepslate
fill 94 102 334 94 107 335 minecraft:cobbled_deepslate
setblock 94 102 336 minecraft:raw_iron_block
fill 94 102 350 94 107 350 minecraft:cobbled_deepslate
fill 95 102 324 95 105 324 minecraft:stone
setblock 95 102 328 minecraft:stripped_spruce_log
fill 95 102 329 95 105 329 minecraft:stone
fill 95 102 331 95 103 331 minecraft:stone
fill 96 102 322 96 103 322 minecraft:cobbled_deepslate
fill 97 102 323 99 102 323 minecraft:stone
setblock 97 102 325 minecraft:light[level=12]
setblock 97 102 332 minecraft:light[level=12]
setblock 97 102 339 minecraft:light[level=12]
setblock 97 102 346 minecraft:light[level=12]
setblock 97 102 353 minecraft:light[level=12]
setblock 97 102 360 minecraft:light[level=12]
fill 97 102 364 97 107 364 minecraft:cobbled_deepslate
setblock 99 102 324 minecraft:stripped_spruce_log
setblock 100 102 323 minecraft:stripped_spruce_log
fill 100 102 324 100 105 324 minecraft:stone
fill 101 102 323 104 102 323 minecraft:stone
fill 102 102 324 103 102 324 minecraft:stone
fill 102 102 363 104 102 363 minecraft:stone
setblock 103 102 325 minecraft:stripped_spruce_log
setblock 104 102 324 minecraft:stripped_spruce_log
fill 104 102 325 104 105 325 minecraft:stone
setblock 104 102 332 minecraft:light[level=12]
setblock 104 102 339 minecraft:light[level=12]
setblock 104 102 346 minecraft:light[level=12]
setblock 104 102 353 minecraft:light[level=12]
setblock 104 102 360 minecraft:light[level=12]
setblock 105 102 323 minecraft:stripped_spruce_log
fill 105 102 324 108 102 324 minecraft:stone
setblock 105 102 363 minecraft:stripped_spruce_log
fill 106 102 323 109 102 323 minecraft:stone
fill 106 102 363 109 102 363 minecraft:stone
setblock 107 102 326 minecraft:stripped_spruce_log
setblock 107 102 362 minecraft:stone
setblock 108 102 325 minecraft:stripped_spruce_log
setblock 109 102 324 minecraft:stripped_spruce_log
fill 109 102 325 109 104 325 minecraft:stone
setblock 110 102 323 minecraft:stripped_spruce_log
fill 110 102 324 112 102 324 minecraft:stone
setblock 110 102 363 minecraft:stripped_spruce_log
fill 111 102 323 114 102 323 minecraft:stone
setblock 111 102 325 minecraft:light[level=12]
setblock 111 102 332 minecraft:light[level=12]
setblock 111 102 339 minecraft:light[level=12]
setblock 111 102 346 minecraft:light[level=12]
setblock 111 102 353 minecraft:light[level=12]
setblock 111 102 360 minecraft:light[level=12]
fill 111 102 363 113 102 363 minecraft:stone
setblock 115 102 323 minecraft:stripped_spruce_log
setblock 118 102 325 minecraft:light[level=12]
setblock 118 102 332 minecraft:light[level=12]
setblock 118 102 339 minecraft:light[level=12]
setblock 118 102 346 minecraft:light[level=12]
setblock 118 102 353 minecraft:light[level=12]
setblock 118 102 360 minecraft:light[level=12]
setblock 120 102 323 minecraft:stripped_spruce_log
setblock 120 102 363 minecraft:stripped_spruce_log
fill 121 102 323 124 102 323 minecraft:stone
fill 121 102 363 124 102 363 minecraft:stone
setblock 125 102 323 minecraft:stripped_spruce_log
fill 125 102 324 126 102 324 minecraft:stone
setblock 125 102 325 minecraft:light[level=12]
setblock 125 102 332 minecraft:light[level=12]
setblock 125 102 339 minecraft:light[level=12]
setblock 125 102 346 minecraft:light[level=12]
setblock 125 102 353 minecraft:light[level=12]
setblock 125 102 360 minecraft:light[level=12]
setblock 125 102 363 minecraft:stripped_spruce_log
fill 126 102 323 129 102 323 minecraft:stone
fill 126 102 363 129 102 363 minecraft:stone
setblock 130 102 323 minecraft:stripped_spruce_log
setblock 132 102 325 minecraft:light[level=12]
setblock 132 102 332 minecraft:light[level=12]
setblock 132 102 339 minecraft:light[level=12]
setblock 132 102 346 minecraft:light[level=12]
setblock 132 102 353 minecraft:light[level=12]
setblock 132 102 360 minecraft:light[level=12]
setblock 133 102 364 minecraft:raw_iron_block
setblock 134 102 345 minecraft:stone
setblock 134 102 349 minecraft:stripped_spruce_log
fill 134 102 364 134 104 364 minecraft:cobbled_deepslate
setblock 135 102 343 minecraft:stripped_spruce_log
fill 135 102 344 135 105 344 minecraft:stone
setblock 135 102 348 minecraft:stripped_spruce_log
fill 135 102 349 135 105 349 minecraft:stone
fill 136 102 324 136 104 324 minecraft:cobbled_deepslate
fill 94 103 336 94 108 336 minecraft:cobbled_deepslate
setblock 94 103 351 minecraft:diamond_block
setblock 95 103 327 minecraft:stripped_spruce_log
fill 95 103 328 96 105 328 minecraft:stone
setblock 95 103 332 minecraft:stripped_spruce_log
fill 96 103 327 96 106 327 minecraft:stone
fill 96 103 329 96 104 329 minecraft:stone
fill 97 103 323 98 103 323 minecraft:stone
setblock 99 103 323 minecraft:stripped_spruce_log
fill 99 103 324 99 106 324 minecraft:stone
fill 100 103 323 103 103 323 minecraft:stone
fill 100 103 325 100 104 325 minecraft:stone
setblock 102 103 324 minecraft:stone
setblock 102 103 325 minecraft:stripped_spruce_log
fill 102 103 363 103 103 363 minecraft:stone
setblock 103 103 324 minecraft:stripped_spruce_log
fill 103 103 325 103 105 326 minecraft:stone
setblock 104 103 323 minecraft:stripped_spruce_log
fill 104 103 324 107 103 324 minecraft:stone
setblock 104 103 363 minecraft:stripped_spruce_log
fill 105 103 323 108 103 323 minecraft:stone
fill 105 103 363 108 103 363 minecraft:stone
setblock 106 103 326 minecraft:stripped_spruce_log
setblock 107 103 325 minecraft:stripped_spruce_log
fill 107 103 326 107 104 326 minecraft:stone
setblock 108 103 324 minecraft:stripped_spruce_log
fill 108 103 325 108 106 325 minecraft:stone
setblock 109 103 322 minecraft:diamond_block
setblock 109 103 323 minecraft:stripped_spruce_log
fill 109 103 324 111 104 324 minecraft:stone
setblock 109 103 363 minecraft:stripped_spruce_log
fill 110 103 323 113 103 323 minecraft:stone
fill 110 103 363 112 104 363 minecraft:stone
setblock 110 103 364 minecraft:gold_block
setblock 114 103 323 minecraft:stripped_spruce_log
fill 120 103 323 123 103 323 minecraft:stone
fill 120 103 363 123 103 363 minecraft:stone
setblock 124 103 323 minecraft:stripped_spruce_log
setblock 124 103 363 minecraft:stripped_spruce_log
fill 125 103 323 128 103 323 minecraft:stone
fill 125 103 363 128 103 363 minecraft:stone
setblock 129 103 323 minecraft:stripped_spruce_log
fill 133 103 364 133 107 364 minecraft:cobbled_deepslate
setblock 134 103 348 minecraft:stripped_spruce_log
fill 134 103 349 134 106 349 minecraft:stone
fill 135 103 343 135 106 343 minecraft:stone
setblock 135 103 347 minecraft:stripped_spruce_log
fill 135 103 348 135 106 348 minecraft:stone
setblock 94 104 322 minecraft:deepslate
fill 94 104 330 94 104 331 minecraft:deepslate
setblock 94 104 333 minecraft:deepslate
setblock 94 104 341 minecraft:deepslate
fill 94 104 351 94 107 351 minecraft:cobbled_deepslate
fill 94 104 360 94 104 361 minecraft:deepslate
setblock 95 104 322 minecraft:gold_block
setblock 95 104 326 minecraft:stripped_spruce_log
fill 95 104 327 95 107 327 minecraft:stone
setblock 95 104 331 minecraft:stripped_spruce_log
fill 95 104 332 95 105 334 minecraft:stone
setblock 96 104 322 minecraft:deepslate
fill 96 104 323 97 104 323 minecraft:stone
fill 96 104 326 96 107 326 minecraft:stone
setblock 96 104 330 minecraft:stripped_spruce_log
fill 96 104 331 96 107 331 minecraft:stone
setblock 98 104 323 minecraft:stripped_spruce_log
fill 98 104 324 98 107 324 minecraft:stone
fill 99 104 323 102 104 323 minecraft:stone
setblock 99 104 364 minecraft:deepslate
setblock 101 104 324 minecraft:stone
setblock 101 104 325 minecraft:stripped_spruce_log
fill 101 104 363 102 104 363 minecraft:stone
setblock 102 104 324 minecraft:stripped_spruce_log
fill 102 104 325 102 106 326 minecraft:stone
setblock 103 104 323 minecraft:stripped_spruce_log
fill 103 104 324 106 104 324 minecraft:stone
setblock 103 104 363 minecraft:stripped_spruce_log
fill 104 104 323 107 104 323 minecraft:stone
fill 104 104 363 107 104 363 minecraft:stone
fill 104 104 364 105 104 364 minecraft:raw_gold_block
setblock 105 104 326 minecraft:stripped_spruce_log
setblock 106 104 325 minecraft:stripped_spruce_log
fill 106 104 326 106 106 326 minecraft:stone
fill 106 104 362 106 106 362 minecraft:stone
setblock 107 104 324 minecraft:stripped_spruce_log
fill 107 104 325 107 107 325 minecraft:stone
setblock 107 104 364 minecraft:deepslate
setblock 108 104 323 minecraft:stripped_spruce_log
fill 108 104 324 108 107 324 minecraft:stone
setblock 108 104 363 minecraft:stripped_spruce_log
fill 109 104 322 109 107 322 minecraft:cobbled_deepslate
fill 109 104 323 112 104 323 minecraft:stone
fill 109 104 363 109 107 363 minecraft:stone
fill 110 104 364 110 105 364 minecraft:cobbled_deepslate
setblock 111 104 322 minecraft:diamond_block
setblock 113 104 322 minecraft:deepslate
setblock 113 104 323 minecraft:stripped_spruce_log
setblock 114 104 364 minecraft:deepslate
fill 119 104 363 122 104 363 minecraft:stone
fill 120 104 323 122 104 323 minecraft:stone
fill 123 104 322 124 104 322 minecraft:deepslate
setblock 123 104 323 minecraft:stripped_spruce_log
setblock 123 104 363 minecraft:stripped_spruce_log
fill 124 104 323 127 104 323 minecraft:stone
fill 124 104 363 127 104 363 minecraft:stone
fill 127 104 322 128 104 322 minecraft:cobbled_deepslate
setblock 128 104 323 minecraft:stripped_spruce_log
fill 129 104 322 129 105 322 minecraft:deepslate
setblock 134 104 347 minecraft:stripped_spruce_log
fill 134 104 348 134 107 348 minecraft:stone
fill 135 104 327 135 104 330 minecraft:stone
setblock 135 104 331 minecraft:stripped_spruce_log
fill 135 104 332 135 107 332 minecraft:stone
setblock 135 104 346 minecraft:stripped_spruce_log
fill 135 104 347 135 107 347 minecraft:stone
setblock 135 104 351 minecraft:stripped_spruce_log
fill 135 104 352 135 107 352 minecraft:stone
fill 135 104 364 135 107 364 minecraft:cobbled_deepslate
fill 136 104 338 136 104 339 minecraft:deepslate
fill 136 104 340 136 107 340 minecraft:cobbled_deepslate
fill 136 104 341 136 104 342 minecraft:deepslate
setblock 136 104 347 minecraft:deepslate
setblock 136 104 364 minecraft:deepslate
fill 94 105 322 96 105 322 minecraft:cobbled_deepslate
fill 94 105 326 94 107 326 minecraft:cobbled_deepslate
setblock 94 105 327 minecraft:diamond_block
fill 94 105 330 94 108 330 minecraft:cobbled_deepslate
setblock 94 105 331 minecraft:deepslate
fill 94 105 333 94 107 333 minecraft:cobbled_deepslate
fill 94 105 341 94 107 342 minecraft:cobbled_deepslate
setblock 94 105 343 minecraft:deepslate
fill 94 105 355 94 106 355 minecraft:deepslate
fill 94 105 360 94 107 361 minecraft:cobbled_deepslate
fill 95 105 323 96 105 323 minecraft:stone
setblock 95 105 325 minecraft:stripped_spruce_log
fill 95 105 326 95 108 326 minecraft:stone
setblock 95 105 330 minecraft:stripped_spruce_log
fill 95 105 331 95 108 331 minecraft:stone
setblock 95 105 335 minecraft:stripped_spruce_log
fill 96 105 325 96 108 325 minecraft:stone
setblock 96 105 329 minecraft:stripped_spruce_log
fill 96 105 330 97 107 330 minecraft:stone
fill 96 105 332 96 105 333 minecraft:stone
fill 97 105 322 97 106 322 minecraft:deepslate
setblock 97 105 323 minecraft:stripped_spruce_log
fill 97 105 324 97 108 324 minecraft:stone
setblock 97 105 328 minecraft:stripped_spruce_log
fill 97 105 329 97 108 329 minecraft:stone
fill 98 105 323 101 105 323 minecraft:stone
setblock 99 105 325 minecraft:stone
fill 99 105 364 99 107 364 minecraft:cobbled_deepslate
setblock 100 105 325 minecraft:stripped_spruce_log
fill 100 105 363 101 105 363 minecraft:stone
setblock 101 105 324 minecraft:stripped_spruce_log
fill 101 105 325 101 107 326 minecraft:stone
setblock 102 105 323 minecraft:stripped_spruce_log
fill 102 105 324 105 105 324 minecraft:stone
setblock 102 105 363 minecraft:stripped_spruce_log
fill 103 105 323 106 105 323 minecraft:stone
fill 103 105 363 106 105 363 minecraft:stone
setblock 104 105 326 minecraft:stripped_spruce_log
fill 104 105 362 105 107 362 minecraft:stone
setblock 104 105 364 minecraft:deepslate
setblock 105 105 325 minecraft:stripped_spruce_log
fill 105 105 326 105 107 326 minecraft:stone
fill 105 105 364 105 107 364 minecraft:cobbled_deepslate
setblock 106 105 324 minecraft:stripped_spruce_log
fill 106 105 325 106 108 325 minecraft:stone
setblock 107 105 323 minecraft:stripped_spruce_log
fill 107 105 324 107 108 324 minecraft:stone
setblock 107 105 362 minecraft:stone
setblock 107 105 363 minecraft:stripped_spruce_log
fill 107 105 364 107 107 364 minecraft:cobbled_deepslate
fill 108 105 323 111 105 323 minecraft:stone
fill 108 105 363 108 108 363 minecraft:stone
fill 109 105 324 110 105 324 minecraft:stone
fill 110 105 363 111 105 363 minecraft:stone
fill 111 105 322 111 107 322 minecraft:cobbled_deepslate
setblock 112 105 323 minecraft:stripped_spruce_log
fill 113 105 322 113 107 322 minecraft:cobbled_deepslate
fill 114 105 364 114 107 364 minecraft:cobbled_deepslate
fill 118 105 363 121 105 363 minecraft:stone
fill 119 105 323 121 105 323 minecraft:stone
setblock 119 105 364 minecraft:deepslate
fill 120 105 364 121 107 364 minecraft:cobbled_deepslate
setblock 122 105 323 minecraft:stripped_spruce_log
setblock 122 105 363 minecraft:stripped_spruce_log
setblock 122 105 364 minecraft:deepslate
fill 123 105 322 124 107 322 minecraft:cobbled_deepslate
fill 123 105 323 126 105 323 minecraft:stone
fill 123 105 363 126 105 363 minecraft:stone
fill 123 105 364 123 107 364 minecraft:cobbled_deepslate
setblock 126 105 364 minecraft:diamond_block
fill 127 105 322 127 107 322 minecraft:cobbled_deepslate
setblock 127 105 323 minecraft:stripped_spruce_log
setblock 127 105 363 minecraft:stripped_spruce_log
setblock 128 105 322 minecraft:deepslate
setblock 128 105 323 minecraft:stone
fill 131 105 322 133 105 322 minecraft:deepslate
fill 131 105 364 131 108 364 minecraft:cobbled_deepslate
setblock 132 105 364 minecraft:deepslate
setblock 134 105 347 minecraft:stone
setblock 134 105 350 minecraft:stone
setblock 134 105 364 minecraft:deepslate
fill 135 105 322 136 105 322 minecraft:deepslate
fill 135 105 326 135 105 329 minecraft:stone
setblock 135 105 330 minecraft:stripped_spruce_log
fill 135 105 331 135 108 331 minecraft:stone
fill 135 105 333 135 105 334 minecraft:stone
setblock 135 105 335 minecraft:stripped_spruce_log
setblock 135 105 345 minecraft:stripped_spruce_log
fill 135 105 346 135 108 346 minecraft:stone
setblock 135 105 350 minecraft:stripped_spruce_log
fill 135 105 351 135 108 351 minecraft:stone
fill 135 105 353 135 106 353 minecraft:stone
setblock 136 105 324 minecraft:deepslate
fill 136 105 338 136 107 339 minecraft:cobbled_deepslate
fill 136 105 341 136 107 341 minecraft:cobbled_deepslate
setblock 136 105 342 minecraft:deepslate
fill 136 105 347 136 107 347 minecraft:cobbled_deepslate
fill 136 105 349 136 105 350 minecraft:deepslate
setblock 136 105 359 minecraft:deepslate
fill 136 105 364 136 107 364 minecraft:cobbled_deepslate
fill 94 106 322 94 109 322 minecraft:cobbled_deepslate
fill 94 106 327 94 107 327 minecraft:cobbled_deepslate
setblock 94 106 329 minecraft:deepslate
fill 94 106 331 94 107 331 minecraft:cobbled_deepslate
fill 94 106 339 94 107 339 minecraft:cobbled_deepslate
setblock 94 106 340 minecraft:deepslate
fill 94 106 343 94 107 343 minecraft:cobbled_deepslate
setblock 94 106 346 minecraft:deepslate
fill 94 106 362 94 107 363 minecraft:cobbled_deepslate
setblock 94 106 364 minecraft:deepslate
setblock 95 106 322 minecraft:deepslate
setblock 95 106 323 minecraft:stone
setblock 95 106 324 minecraft:stripped_spruce_log
fill 95 106 325 95 109 325 minecraft:stone
setblock 95 106 328 minecraft:stone
setblock 95 106 329 minecraft:stripped_spruce_log
fill 95 106 330 95 109 330 minecraft:stone
fill 95 106 332 95 106 333 minecraft:stone
setblock 95 106 334 minecraft:stripped_spruce_log
fill 95 106 335 95 108 336 minecraft:stone
setblock 95 106 349 minecraft:stripped_spruce_log
fill 95 106 350 95 108 351 minecraft:stone
fill 96 106 322 96 107 322 minecraft:cobbled_deepslate
setblock 96 106 323 minecraft:stripped_spruce_log
setblock 96 106 328 minecraft:stripped_spruce_log
fill 96 106 329 96 109 329 minecraft:stone
setblock 96 106 332 minecraft:stone
setblock 96 106 333 minecraft:stripped_spruce_log
fill 96 106 334 96 109 334 minecraft:stone
fill 97 106 323 100 106 323 minecraft:stone
setblock 97 106 325 minecraft:light[level=15]
setblock 97 106 326 minecraft:stone
setblock 97 106 327 minecraft:stripped_spruce_log
fill 97 106 328 97 109 328 minecraft:stone
setblock 97 106 331 minecraft:stone
setblock 97 106 332 minecraft:stripped_spruce_log
setblock 97 106 333 minecraft:light[level=15]
setblock 97 106 341 minecraft:light[level=15]
setblock 97 106 349 minecraft:light[level=15]
setblock 97 106 357 minecraft:light[level=15]
setblock 98 106 325 minecraft:stone
setblock 99 106 325 minecraft:stripped_spruce_log
setblock 100 106 324 minecraft:stripped_spruce_log
fill 100 106 325 100 108 326 minecraft:stone
setblock 100 106 363 minecraft:stone
setblock 101 106 323 minecraft:stripped_spruce_log
fill 101 106 324 104 106 324 minecraft:stone
setblock 101 106 363 minecraft:stripped_spruce_log
fill 102 106 323 105 106 323 minecraft:stone
fill 102 106 363 105 106 363 minecraft:stone
setblock 103 106 325 minecraft:stone
setblock 103 106 326 minecraft:stripped_spruce_log
fill 103 106 362 103 109 362 minecraft:stone
setblock 104 106 325 minecraft:stripped_spruce_log
fill 104 106 326 104 108 326 minecraft:stone
fill 104 106 364 104 107 364 minecraft:cobbled_deepslate
setblock 105 106 324 minecraft:stripped_spruce_log
fill 105 106 325 105 109 325 minecraft:stone
setblock 105 106 333 minecraft:light[level=15]
setblock 105 106 341 minecraft:light[level=15]
setblock 105 106 349 minecraft:light[level=15]
setblock 105 106 357 minecraft:light[level=15]
setblock 106 106 323 minecraft:stripped_spruce_log
fill 106 106 324 106 109 324 minecraft:stone
setblock 106 106 363 minecraft:stripped_spruce_log
fill 107 106 323 110 106 323 minecraft:stone
setblock 107 106 362 minecraft:stripped_spruce_log
fill 107 106 363 107 109 363 minecraft:stone
setblock 109 106 324 minecraft:stone
setblock 110 106 324 minecraft:stripped_spruce_log
setblock 110 106 363 minecraft:stone
setblock 110 106 364 minecraft:deepslate
setblock 111 106 323 minecraft:stripped_spruce_log
setblock 111 106 363 minecraft:stripped_spruce_log
setblock 112 106 323 minecraft:stone
setblock 113 106 325 minecraft:light[level=15]
setblock 113 106 333 minecraft:light[level=15]
setblock 113 106 341 minecraft:light[level=15]
setblock 113 106 349 minecraft:light[level=15]
setblock 113 106 357 minecraft:light[level=15]
setblock 115 106 364 minecraft:deepslate
setblock 116 106 322 minecraft:deepslate
fill 117 106 322 118 107 322 minecraft:cobbled_deepslate
fill 117 106 363 120 106 363 minecraft:stone
fill 119 106 323 120 106 323 minecraft:stone
fill 119 106 364 119 107 364 minecraft:cobbled_deepslate
setblock 121 106 323 minecraft:stripped_spruce_log
setblock 121 106 325 minecraft:light[level=15]
setblock 121 106 333 minecraft:light[level=15]
setblock 121 106 341 minecraft:light[level=15]
setblock 121 106 349 minecraft:light[level=15]
setblock 121 106 357 minecraft:light[level=15]
setblock 121 106 363 minecraft:stripped_spruce_log
fill 122 106 323 125 106 323 minecraft:stone
fill 122 106 363 125 106 363 minecraft:stone
fill 122 106 364 122 107 364 minecraft:cobbled_deepslate
fill 125 106 364 126 106 364 minecraft:deepslate
setblock 126 106 323 minecraft:stripped_spruce_log
setblock 126 106 363 minecraft:stripped_spruce_log
setblock 127 106 323 minecraft:stone
fill 128 106 322 129 107 322 minecraft:cobbled_deepslate
setblock 129 106 325 minecraft:light[level=15]
setblock 129 106 333 minecraft:light[level=15]
setblock 129 106 341 minecraft:light[level=15]
setblock 129 106 349 minecraft:light[level=15]
setblock 129 106 357 minecraft:light[level=15]
fill 131 106 322 133 107 322 minecraft:cobbled_deepslate
fill 132 106 364 132 107 364 minecraft:cobbled_deepslate
setblock 134 106 330 minecraft:stripped_spruce_log
fill 134 106 331 134 109 331 minecraft:stone
setblock 134 106 350 minecraft:stripped_spruce_log
fill 134 106 351 134 109 351 minecraft:stone
fill 134 106 364 134 107 364 minecraft:cobbled_deepslate
fill 135 106 322 136 107 322 minecraft:cobbled_deepslate
fill 135 106 326 135 106 328 minecraft:stone
setblock 135 106 329 minecraft:stripped_spruce_log
fill 135 106 330 135 109 330 minecraft:stone
setblock 135 106 333 minecraft:stone
setblock 135 106 334 minecraft:stripped_spruce_log
fill 135 106 335 135 107 337 minecraft:stone
setblock 135 106 344 minecraft:stripped_spruce_log
fill 135 106 345 135 109 345 minecraft:stone
setblock 135 106 349 minecraft:stripped_spruce_log
fill 135 106 350 135 109 350 minecraft:stone
setblock 135 106 354 minecraft:stripped_spruce_log
setblock 136 106 323 minecraft:deepslate
fill 136 106 324 136 107 324 minecraft:cobbled_deepslate
setblock 136 106 331 minecraft:deepslate
fill 136 106 342 136 108 342 minecraft:cobbled_deepslate
setblock 136 106 344 minecraft:deepslate
fill 136 106 349 136 107 350 minecraft:cobbled_deepslate
fill 136 106 359 136 107 359 minecraft:cobbled_deepslate
setblock 94 107 329 minecraft:cobbled_deepslate
setblock 94 107 340 minecraft:cobbled_deepslate
setblock 94 107 346 minecraft:cobbled_deepslate
setblock 94 107 355 minecraft:cobbled_deepslate
fill 94 107 364 94 108 364 minecraft:cobbled_deepslate
setblock 95 107 322 minecraft:cobbled_deepslate
setblock 95 107 323 minecraft:stripped_spruce_log
fill 95 107 324 95 110 324 minecraft:stone
setblock 95 107 328 minecraft:stripped_spruce_log
fill 95 107 329 95 110 329 minecraft:stone
setblock 95 107 332 minecraft:stone
setblock 95 107 333 minecraft:stripped_spruce_log
fill 95 107 334 95 110 334 minecraft:stone
setblock 95 107 337 minecraft:stone
fill 95 107 349 95 109 349 minecraft:stone
setblock 95 107 352 minecraft:stone
setblock 95 107 353 minecraft:stripped_spruce_log
fill 96 107 323 99 107 323 minecraft:stone
fill 96 107 324 96 110 324 minecraft:spruce_log
setblock 96 107 327 minecraft:stripped_spruce_log
fill 96 107 328 96 110 328 minecraft:stone
setblock 96 107 332 minecraft:stripped_spruce_log
fill 96 107 333 97 109 333 minecraft:stone
fill 96 107 335 96 108 335 minecraft:stone
fill 96 107 343 96 110 343 minecraft:spruce_log
fill 96 107 362 96 110 362 minecraft:spruce_log
setblock 97 107 322 minecraft:cobbled_deepslate
setblock 97 107 326 minecraft:stripped_spruce_log
fill 97 107 327 97 110 327 minecraft:stone
setblock 97 107 331 minecraft:stripped_spruce_log
fill 97 107 332 97 110 332 minecraft:stone
setblock 98 107 325 minecraft:stripped_spruce_log
fill 98 107 328 98 107 329 minecraft:stone
setblock 98 107 330 minecraft:stripped_spruce_log
fill 98 107 331 98 110 331 minecraft:stone
setblock 99 107 324 minecraft:stripped_spruce_log
fill 99 107 325 99 110 325 minecraft:stone
setblock 99 107 363 minecraft:stone
setblock 100 107 323 minecraft:stripped_spruce_log
fill 100 107 324 103 107 324 minecraft:stone
setblock 100 107 363 minecraft:stripped_spruce_log
fill 101 107 323 104 107 323 minecraft:stone
setblock 101 107 362 minecraft:stripped_spruce_log
fill 101 107 363 104 107 363 minecraft:stone
setblock 102 107 325 minecraft:stone
setblock 102 107 326 minecraft:stripped_spruce_log
fill 102 107 362 102 110 362 minecraft:stone
setblock 103 107 325 minecraft:stripped_spruce_log
fill 103 107 326 103 109 326 minecraft:stone
setblock 104 107 324 minecraft:stripped_spruce_log
fill 104 107 325 104 110 325 minecraft:stone
setblock 105 107 323 minecraft:stripped_spruce_log
fill 105 107 324 105 110 324 minecraft:stone
setblock 105 107 363 minecraft:stripped_spruce_log
fill 106 107 323 109 107 323 minecraft:stone
setblock 106 107 362 minecraft:stripped_spruce_log
fill 106 107 363 106 110 363 minecraft:stone
fill 107 107 362 107 110 362 minecraft:stone
setblock 109 107 324 minecraft:stripped_spruce_log
setblock 110 107 323 minecraft:stripped_spruce_log
setblock 110 107 363 minecraft:stripped_spruce_log
setblock 110 107 364 minecraft:cobbled_deepslate
setblock 111 107 323 minecraft:stone
fill 111 107 363 111 110 363 minecraft:stone
fill 115 107 324 115 110 324 minecraft:spruce_log
fill 115 107 362 115 110 362 minecraft:spruce_log
setblock 115 107 364 minecraft:cobbled_deepslate
setblock 116 107 322 minecraft:cobbled_deepslate
fill 116 107 363 119 107 363 minecraft:stone
setblock 119 107 323 minecraft:stone
setblock 120 107 323 minecraft:stripped_spruce_log
setblock 120 107 363 minecraft:stripped_spruce_log
fill 121 107 323 124 107 323 minecraft:stone
setblock 121 107 362 minecraft:stripped_spruce_log
fill 121 107 363 124 107 363 minecraft:stone
fill 122 107 362 123 109 362 minecraft:stone
setblock 125 107 323 minecraft:stripped_spruce_log
setblock 125 107 363 minecraft:stripped_spruce_log
fill 125 107 364 126 107 364 minecraft:cobbled_deepslate
setblock 126 107 323 minecraft:stone
fill 126 107 363 126 108 363 minecraft:stone
fill 134 107 324 134 110 324 minecraft:spruce_log
setblock 134 107 329 minecraft:stripped_spruce_log
fill 134 107 330 134 110 330 minecraft:stone
fill 134 107 332 134 107 333 minecraft:stone
setblock 134 107 334 minecraft:stripped_spruce_log
fill 134 107 343 134 110 343 minecraft:spruce_log
setblock 134 107 349 minecraft:stripped_spruce_log
fill 134 107 350 134 108 350 minecraft:stone
fill 134 107 362 134 110 362 minecraft:spruce_log
fill 135 107 326 135 107 327 minecraft:stone
setblock 135 107 328 minecraft:stripped_spruce_log
fill 135 107 329 135 110 329 minecraft:stone
setblock 135 107 333 minecraft:stripped_spruce_log
fill 135 107 334 135 110 334 minecraft:stone
setblock 135 107 338 minecraft:stripped_spruce_log
fill 135 107 339 135 109 340 minecraft:stone
setblock 135 107 342 minecraft:stone
setblock 135 107 343 minecraft:stripped_spruce_log
fill 135 107 344 135 110 344 minecraft:stone
setblock 135 107 348 minecraft:stripped_spruce_log
fill 135 107 349 135 110 349 minecraft:stone
setblock 135 107 353 minecraft:stripped_spruce_log
fill 135 107 354 135 109 355 minecraft:stone
setblock 136 107 323 minecraft:cobbled_deepslate
setblock 136 107 331 minecraft:cobbled_deepslate
setblock 136 107 344 minecraft:cobbled_deepslate
fill 94 108 323 94 108 329 minecraft:deepslate
fill 94 108 331 94 109 335 minecraft:deepslate
fill 94 108 337 94 121 341 minecraft:deepslate
setblock 94 108 342 minecraft:cobbled_deepslate
fill 94 108 343 94 132 347 minecraft:deepslate
fill 94 108 349 94 125 353 minecraft:deepslate
fill 94 108 355 94 108 363 minecraft:deepslate
fill 95 108 322 98 133 322 minecraft:deepslate
fill 95 108 323 98 108 323 minecraft:stone
setblock 95 108 327 minecraft:stripped_spruce_log
fill 95 108 328 95 111 328 minecraft:stone
setblock 95 108 332 minecraft:stripped_spruce_log
fill 95 108 333 95 111 333 minecraft:stone
setblock 95 108 337 minecraft:stripped_spruce_log
fill 95 108 338 95 111 338 minecraft:stone
setblock 95 108 352 minecraft:stripped_spruce_log
fill 95 108 353 95 109 355 minecraft:stone
fill 95 108 364 110 108 364 minecraft:deepslate
setblock 96 108 326 minecraft:stripped_spruce_log
fill 96 108 327 96 111 327 minecraft:stone
setblock 96 108 330 minecraft:stone
setblock 96 108 331 minecraft:stripped_spruce_log
fill 96 108 332 96 111 332 minecraft:stone
setblock 96 108 336 minecraft:stripped_spruce_log
setblock 97 108 325 minecraft:light[level=12]
fill 97 108 326 97 110 326 minecraft:stone
setblock 97 108 330 minecraft:stripped_spruce_log
fill 97 108 331 97 111 331 minecraft:stone
setblock 97 108 334 minecraft:stone
setblock 97 108 339 minecraft:light[level=12]
setblock 97 108 346 minecraft:light[level=12]
setblock 97 108 353 minecraft:light[level=12]
setblock 97 108 360 minecraft:light[level=12]
setblock 98 108 324 minecraft:stripped_spruce_log
fill 98 108 325 98 110 325 minecraft:stone
setblock 98 108 328 minecraft:stone
setblock 98 108 329 minecraft:stripped_spruce_log
fill 98 108 330 98 111 330 minecraft:stone
fill 98 108 332 98 109 332 minecraft:stone
setblock 98 108 363 minecraft:stone
setblock 99 108 323 minecraft:stripped_spruce_log
fill 99 108 324 102 108 324 minecraft:stone
setblock 99 108 363 minecraft:stripped_spruce_log
setblock 100 108 322 minecraft:raw_iron_block
fill 100 108 323 103 108 323 minecraft:stone
setblock 100 108 362 minecraft:stripped_spruce_log
fill 100 108 363 103 108 363 minecraft:stone
fill 101 108 322 104 108 322 minecraft:deepslate
setblock 101 108 325 minecraft:stone
setblock 101 108 326 minecraft:stripped_spruce_log
fill 101 108 362 101 111 362 minecraft:stone
setblock 102 108 325 minecraft:stripped_spruce_log
fill 102 108 326 102 109 326 minecraft:stone
setblock 103 108 324 minecraft:stripped_spruce_log
fill 103 108 325 103 110 325 minecraft:stone
setblock 104 108 323 minecraft:stripped_spruce_log
fill 104 108 324 104 111 324 minecraft:stone
setblock 104 108 332 minecraft:light[level=12]
setblock 104 108 339 minecraft:light[level=12]
setblock 104 108 346 minecraft:light[level=12]
setblock 104 108 353 minecraft:light[level=12]
setblock 104 108 360 minecraft:light[level=12]
setblock 104 108 362 minecraft:stone
setblock 104 108 363 minecraft:stripped_spruce_log
fill 105 108 323 108 108 323 minecraft:stone
setblock 105 108 362 minecraft:stripped_spruce_log
fill 105 108 363 105 111 363 minecraft:stone
fill 106 108 322 113 109 322 minecraft:deepslate
fill 106 108 362 106 111 362 minecraft:stone
setblock 108 108 324 minecraft:stripped_spruce_log
setblock 109 108 323 minecraft:stripped_spruce_log
fill 109 108 362 111 109 362 minecraft:raw_gold_block
setblock 109 108 363 minecraft:stripped_spruce_log
setblock 110 108 323 minecraft:stone
fill 110 108 360 110 110 361 minecraft:raw_gold_block
fill 110 108 363 110 111 363 minecraft:stone
setblock 111 108 325 minecraft:light[level=12]
setblock 111 108 332 minecraft:light[level=12]
setblock 111 108 339 minecraft:light[level=12]
setblock 111 108 346 minecraft:light[level=12]
setblock 111 108 353 minecraft:light[level=12]
setblock 111 108 360 minecraft:light[level=12]
fill 112 108 363 112 109 363 minecraft:stone
fill 112 108 364 112 171 364 minecraft:deepslate
setblock 114 108 322 minecraft:raw_iron_block
fill 114 108 364 116 112 364 minecraft:deepslate
fill 115 108 322 131 108 322 minecraft:deepslate
fill 115 108 363 118 108 363 minecraft:stone
setblock 118 108 325 minecraft:light[level=12]
setblock 118 108 332 minecraft:light[level=12]
setblock 118 108 339 minecraft:light[level=12]
setblock 118 108 346 minecraft:light[level=12]
setblock 118 108 353 minecraft:light[level=12]
setblock 118 108 360 minecraft:light[level=12]
fill 118 108 364 127 109 364 minecraft:deepslate
setblock 119 108 323 minecraft:stripped_spruce_log
setblock 119 108 362 minecraft:stone
setblock 119 108 363 minecraft:stripped_spruce_log
fill 120 108 323 123 108 323 minecraft:stone
setblock 120 108 362 minecraft:stripped_spruce_log
fill 120 108 363 123 108 363 minecraft:stone
fill 121 108 362 121 111 362 minecraft:stone
setblock 124 108 323 minecraft:stripped_spruce_log
setblock 124 108 363 minecraft:stripped_spruce_log
setblock 125 108 323 minecraft:stone
setblock 125 108 325 minecraft:light[level=12]
setblock 125 108 332 minecraft:light[level=12]
setblock 125 108 339 minecraft:light[level=12]
setblock 125 108 346 minecraft:light[level=12]
setblock 125 108 353 minecraft:light[level=12]
setblock 125 108 360 minecraft:light[level=12]
fill 125 108 363 125 110 363 minecraft:stone
setblock 128 108 364 minecraft:raw_gold_block
fill 129 108 364 130 129 364 minecraft:deepslate
setblock 132 108 322 minecraft:diamond_block
setblock 132 108 325 minecraft:light[level=12]
setblock 132 108 332 minecraft:light[level=12]
setblock 132 108 339 minecraft:light[level=12]
setblock 132 108 346 minecraft:light[level=12]
setblock 132 108 353 minecraft:light[level=12]
setblock 132 108 360 minecraft:light[level=12]
fill 132 108 364 134 118 364 minecraft:deepslate
fill 133 108 322 135 115 322 minecraft:deepslate
setblock 134 108 328 minecraft:stripped_spruce_log
fill 134 108 329 134 111 329 minecraft:stone
setblock 134 108 332 minecraft:stone
setblock 134 108 333 minecraft:stripped_spruce_log
fill 134 108 334 134 109 336 minecraft:stone
setblock 134 108 349 minecraft:stone
setblock 134 108 352 minecraft:stone
fill 135 108 325 135 108 326 minecraft:stone
setblock 135 108 327 minecraft:stripped_spruce_log
fill 135 108 328 135 111 328 minecraft:stone
setblock 135 108 332 minecraft:stripped_spruce_log
fill 135 108 333 135 111 333 minecraft:stone
fill 135 108 335 135 108 336 minecraft:stone
setblock 135 108 337 minecraft:stripped_spruce_log
fill 135 108 338 135 111 338 minecraft:stone
setblock 135 108 341 minecraft:stone
setblock 135 108 342 minecraft:stripped_spruce_log
fill 135 108 343 135 111 343 minecraft:stone
setblock 135 108 347 minecraft:stripped_spruce_log
fill 135 108 348 135 111 348 minecraft:stone
setblock 135 108 352 minecraft:stripped_spruce_log
fill 135 108 353 135 111 353 minecraft:stone
setblock 135 108 364 minecraft:diamond_block
setblock 136 108 322 minecraft:cobbled_deepslate
fill 136 108 323 136 108 333 minecraft:deepslate
fill 136 108 335 136 108 341 minecraft:deepslate
fill 136 108 343 136 108 351 minecraft:deepslate
setblock 136 108 352 minecraft:cobbled_deepslate
fill 136 108 353 136 108 364 minecraft:deepslate
fill 94 109 323 94 174 323 minecraft:deepslate
setblock 94 109 324 minecraft:cobbled_deepslate
fill 94 109 325 94 109 330 minecraft:deepslate
fill 94 109 336 94 139 336 minecraft:deepslate
setblock 94 109 342 minecraft:deepslate
fill 94 109 348 94 126 348 minecraft:deepslate
fill 94 109 354 94 110 362 minecraft:deepslate
setblock 94 109 363 minecraft:cobbled_deepslate
fill 94 109 364 100 109 364 minecraft:deepslate
fill 95 109 323 97 109 323 minecraft:stone
setblock 95 109 326 minecraft:stripped_spruce_log
fill 95 109 327 95 112 327 minecraft:stone
setblock 95 109 331 minecraft:stripped_spruce_log
fill 95 109 332 95 112 332 minecraft:stone
setblock 95 109 335 minecraft:stone
setblock 95 109 336 minecraft:stripped_spruce_log
fill 95 109 337 96 111 337 minecraft:stone
fill 95 109 339 95 110 339 minecraft:stone
setblock 95 109 350 minecraft:stone
setblock 95 109 351 minecraft:stripped_spruce_log
fill 95 109 352 95 112 352 minecraft:stone
setblock 95 109 356 minecraft:stripped_spruce_log
setblock 96 109 325 minecraft:stripped_spruce_log
fill 96 109 326 96 112 326 minecraft:stone
setblock 96 109 330 minecraft:stripped_spruce_log
fill 96 109 331 96 112 331 minecraft:stone
setblock 96 109 335 minecraft:stripped_spruce_log
fill 96 109 336 96 112 336 minecraft:stone
setblock 97 109 324 minecraft:stripped_spruce_log
setblock 97 109 329 minecraft:stripped_spruce_log
fill 97 109 330 97 112 330 minecraft:stone
setblock 97 109 334 minecraft:stripped_spruce_log
fill 97 109 335 97 112 335 minecraft:stone
setblock 97 109 363 minecraft:stone
setblock 98 109 323 minecraft:stripped_spruce_log
fill 98 109 324 101 109 324 minecraft:stone
setblock 98 109 328 minecraft:stripped_spruce_log
fill 98 109 329 98 111 329 minecraft:stone
setblock 98 109 333 minecraft:stripped_spruce_log
setblock 98 109 363 minecraft:stripped_spruce_log
fill 99 109 322 102 109 322 minecraft:deepslate
fill 99 109 323 102 109 323 minecraft:stone
fill 99 109 363 102 109 363 minecraft:stone
setblock 100 109 325 minecraft:stone
setblock 100 109 326 minecraft:stripped_spruce_log
fill 100 109 362 100 112 362 minecraft:stone
setblock 101 109 325 minecraft:stripped_spruce_log
setblock 101 109 326 minecraft:stone
fill 101 109 364 102 109 364 minecraft:cobbled_deepslate
setblock 102 109 324 minecraft:stripped_spruce_log
fill 102 109 325 102 111 325 minecraft:stone
setblock 103 109 322 minecraft:cobbled_deepslate
setblock 103 109 323 minecraft:stripped_spruce_log
fill 103 109 324 103 112 324 minecraft:stone
setblock 103 109 363 minecraft:stripped_spruce_log
fill 103 109 364 111 113 364 minecraft:deepslate
fill 104 109 322 105 131 322 minecraft:deepslate
fill 104 109 323 107 109 323 minecraft:stone
setblock 104 109 362 minecraft:stripped_spruce_log
fill 104 109 363 104 112 363 minecraft:stone
fill 105 109 362 105 112 362 minecraft:stone
setblock 107 109 324 minecraft:stripped_spruce_log
setblock 108 109 323 minecraft:stripped_spruce_log
setblock 108 109 363 minecraft:stripped_spruce_log
setblock 109 109 323 minecraft:stone
fill 109 109 360 109 109 361 minecraft:raw_gold_block
fill 109 109 363 109 112 363 minecraft:stone
fill 110 109 358 110 110 359 minecraft:raw_gold_block
fill 111 109 360 111 109 361 minecraft:raw_gold_block
fill 113 109 364 113 143 364 minecraft:deepslate
fill 114 109 322 116 109 322 minecraft:deepslate
fill 114 109 363 117 109 363 minecraft:stone
setblock 117 109 322 minecraft:cobbled_deepslate
fill 117 109 364 117 174 364 minecraft:deepslate
fill 118 109 322 118 174 322 minecraft:deepslate
setblock 118 109 362 minecraft:stone
setblock 118 109 363 minecraft:stripped_spruce_log
setblock 119 109 322 minecraft:cobbled_deepslate
fill 119 109 323 122 109 323 minecraft:stone
setblock 119 109 362 minecraft:stripped_spruce_log
fill 119 109 363 122 109 363 minecraft:stone
fill 120 109 322 132 109 322 minecraft:deepslate
fill 120 109 362 120 112 362 minecraft:stone
setblock 123 109 323 minecraft:stripped_spruce_log
setblock 123 109 363 minecraft:stripped_spruce_log
setblock 124 109 323 minecraft:stone
fill 124 109 363 124 111 363 minecraft:stone
fill 128 109 364 128 126 364 minecraft:deepslate
fill 131 109 364 131 170 364 minecraft:deepslate
setblock 134 109 328 minecraft:stone
setblock 134 109 332 minecraft:stripped_spruce_log
fill 134 109 333 134 112 333 minecraft:stone
setblock 134 109 337 minecraft:stripped_spruce_log
setblock 134 109 352 minecraft:stripped_spruce_log
setblock 135 109 325 minecraft:stone
setblock 135 109 326 minecraft:stripped_spruce_log
fill 135 109 327 135 112 327 minecraft:stone
setblock 135 109 331 minecraft:stripped_spruce_log
fill 135 109 332 135 112 332 minecraft:stone
setblock 135 109 335 minecraft:stone
setblock 135 109 336 minecraft:stripped_spruce_log
fill 135 109 337 135 112 337 minecraft:stone
setblock 135 109 341 minecraft:stripped_spruce_log
fill 135 109 342 135 112 342 minecraft:stone
setblock 135 109 346 minecraft:stripped_spruce_log
fill 135 109 347 135 110 347 minecraft:stone
setblock 135 109 351 minecraft:stripped_spruce_log
fill 135 109 352 135 112 352 minecraft:stone
setblock 135 109 356 minecraft:stripped_spruce_log
fill 135 109 364 136 109 364 minecraft:deepslate
fill 136 109 322 136 109 325 minecraft:deepslate
setblock 136 109 326 minecraft:cobbled_deepslate
fill 136 109 327 136 115 328 minecraft:deepslate
setblock 136 109 329 minecraft:gold_block
setblock 136 109 330 minecraft:cobbled_deepslate
fill 136 109 331 136 109 335 minecraft:deepslate
setblock 136 109 336 minecraft:cobbled_deepslate
fill 136 109 337 136 112 342 minecraft:deepslate
setblock 136 109 343 minecraft:cobbled_deepslate
fill 136 109 344 136 126 350 minecraft:deepslate
setblock 136 109 351 minecraft:cobbled_deepslate
fill 136 109 352 136 112 354 minecraft:deepslate
setblock 136 109 355 minecraft:cobbled_deepslate
fill 136 109 356 136 109 362 minecraft:deepslate
fill 136 109 363 136 110 363 minecraft:cobbled_deepslate
fill 94 110 322 94 175 322 minecraft:deepslate
fill 94 110 324 94 112 328 minecraft:deepslate
fill 94 110 329 94 110 330 minecraft:cobbled_deepslate
fill 94 110 331 94 125 332 minecraft:deepslate
setblock 94 110 333 minecraft:cobbled_deepslate
fill 94 110 334 94 172 335 minecraft:deepslate
setblock 94 110 342 minecraft:cobbled_deepslate
fill 94 110 363 94 116 364 minecraft:deepslate
fill 95 110 323 96 110 323 minecraft:stone
setblock 95 110 325 minecraft:stripped_spruce_log
fill 95 110 326 95 112 326 minecraft:stone
setblock 95 110 330 minecraft:stripped_spruce_log
fill 95 110 331 95 112 331 minecraft:stone
setblock 95 110 335 minecraft:stripped_spruce_log
fill 95 110 336 95 112 336 minecraft:stone
setblock 95 110 350 minecraft:stripped_spruce_log
fill 95 110 351 95 111 351 minecraft:stone
fill 95 110 353 95 110 354 minecraft:stone
setblock 95 110 355 minecraft:stripped_spruce_log
fill 95 110 356 95 111 358 minecraft:stone
fill 95 110 364 96 174 364 minecraft:deepslate
fill 96 110 325 96 112 325 minecraft:stone
setblock 96 110 329 minecraft:stripped_spruce_log
fill 96 110 330 96 112 330 minecraft:stone
setblock 96 110 333 minecraft:stone
setblock 96 110 334 minecraft:stripped_spruce_log
fill 96 110 335 96 112 335 minecraft:stone
setblock 97 110 323 minecraft:stripped_spruce_log
fill 97 110 324 100 110 324 minecraft:stone
setblock 97 110 328 minecraft:stripped_spruce_log
fill 97 110 329 97 113 329 minecraft:stone
setblock 97 110 333 minecraft:stripped_spruce_log
fill 97 110 334 97 113 334 minecraft:stone
fill 97 110 336 97 111 336 minecraft:stone
setblock 97 110 363 minecraft:stripped_spruce_log
setblock 97 110 364 minecraft:cobbled_deepslate
fill 98 110 323 101 110 323 minecraft:stone
setblock 98 110 328 minecraft:stone
setblock 98 110 332 minecraft:stripped_spruce_log
fill 98 110 333 98 111 333 minecraft:stone
fill 98 110 363 101 110 363 minecraft:stone
fill 98 110 364 102 143 364 minecraft:deepslate
fill 99 110 322 100 110 322 minecraft:cobbled_deepslate
fill 99 110 362 99 112 362 minecraft:stone
setblock 100 110 325 minecraft:stripped_spruce_log
fill 101 110 322 103 116 322 minecraft:deepslate
setblock 101 110 324 minecraft:stripped_spruce_log
fill 101 110 325 101 111 325 minecraft:stone
setblock 102 110 323 minecraft:stripped_spruce_log
fill 102 110 324 102 112 324 minecraft:stone
fill 102 110 361 103 110 361 minecraft:stone
setblock 102 110 363 minecraft:stripped_spruce_log
fill 103 110 323 106 110 323 minecraft:stone
setblock 103 110 362 minecraft:stripped_spruce_log
fill 103 110 363 103 112 363 minecraft:stone
fill 104 110 362 104 112 362 minecraft:stone
fill 106 110 322 106 168 322 minecraft:deepslate
setblock 106 110 324 minecraft:stripped_spruce_log
setblock 107 110 322 minecraft:cobbled_deepslate
setblock 107 110 323 minecraft:stripped_spruce_log
setblock 107 110 363 minecraft:stripped_spruce_log
fill 108 110 322 109 121 322 minecraft:deepslate
setblock 108 110 323 minecraft:stone
fill 108 110 363 108 112 363 minecraft:stone
setblock 110 110 322 minecraft:cobbled_deepslate
fill 110 110 355 110 110 357 minecraft:raw_gold_block
fill 111 110 322 114 167 322 minecraft:deepslate
fill 114 110 363 116 110 363 minecraft:stone
setblock 115 110 322 minecraft:cobbled_deepslate
fill 116 110 322 117 133 322 minecraft:deepslate
setblock 117 110 363 minecraft:stripped_spruce_log
setblock 118 110 362 minecraft:stripped_spruce_log
fill 118 110 363 121 110 363 minecraft:stone
fill 118 110 364 120 141 364 minecraft:deepslate
fill 119 110 322 122 165 322 minecraft:deepslate
fill 119 110 323 121 110 323 minecraft:stone
fill 119 110 362 119 112 362 minecraft:stone
setblock 121 110 364 minecraft:cobbled_deepslate
setblock 122 110 323 minecraft:stripped_spruce_log
setblock 122 110 362 minecraft:stone
setblock 122 110 363 minecraft:stripped_spruce_log
fill 122 110 364 127 129 364 minecraft:deepslate
setblock 123 110 322 minecraft:cobbled_deepslate
setblock 123 110 323 minecraft:stone
setblock 123 110 362 minecraft:stripped_spruce_log
fill 123 110 363 123 112 363 minecraft:stone
fill 124 110 322 130 110 322 minecraft:deepslate
fill 127 110 360 134 111 360 minecraft:stripped_spruce_log
setblock 131 110 322 minecraft:cobbled_deepslate
fill 132 110 322 132 111 322 minecraft:deepslate
setblock 134 110 331 minecraft:stripped_spruce_log
fill 134 110 332 134 112 332 minecraft:stone
fill 134 110 334 134 110 335 minecraft:stone
setblock 134 110 336 minecraft:stripped_spruce_log
fill 134 110 337 134 112 338 minecraft:stone
fill 135 110 325 135 111 325 minecraft:stripped_spruce_log
fill 135 110 326 135 112 326 minecraft:stone
setblock 135 110 330 minecraft:stripped_spruce_log
fill 135 110 331 135 112 331 minecraft:stone
setblock 135 110 335 minecraft:stripped_spruce_log
fill 135 110 336 135 112 336 minecraft:stone
setblock 135 110 339 minecraft:stone
setblock 135 110 340 minecraft:stripped_spruce_log
fill 135 110 341 135 112 341 minecraft:stone
setblock 135 110 345 minecraft:stripped_spruce_log
setblock 135 110 346 minecraft:stone
setblock 135 110 350 minecraft:stripped_spruce_log
fill 135 110 351 135 112 351 minecraft:stone
setblock 135 110 354 minecraft:stone
setblock 135 110 355 minecraft:stripped_spruce_log
fill 135 110 356 135 112 357 minecraft:stone
fill 135 110 364 135 140 364 minecraft:deepslate
fill 136 110 322 136 175 322 minecraft:deepslate
setblock 136 110 323 minecraft:cobbled_deepslate
fill 136 110 324 136 137 326 minecraft:deepslate
setblock 136 110 329 minecraft:cobbled_deepslate
fill 136 110 330 136 152 331 minecraft:deepslate
setblock 136 110 332 minecraft:cobbled_deepslate
fill 136 110 333 136 148 336 minecraft:deepslate
fill 136 110 343 136 172 343 minecraft:deepslate
fill 136 110 351 136 174 351 minecraft:deepslate
fill 136 110 355 136 113 356 minecraft:deepslate
setblock 136 110 357 minecraft:cobbled_deepslate
fill 136 110 358 136 133 361 minecraft:deepslate
setblock 136 110 362 minecraft:cobbled_deepslate
setblock 136 110 364 minecraft:cobbled_deepslate
fill 94 111 329 94 140 330 minecraft:deepslate
fill 94 111 333 94 123 333 minecraft:deepslate
fill 94 111 342 94 172 342 minecraft:deepslate
fill 94 111 354 94 113 356 minecraft:deepslate
setblock 94 111 357 minecraft:raw_iron_block
fill 94 111 358 94 113 362 minecraft:deepslate
setblock 95 111 323 minecraft:stone
setblock 95 111 324 minecraft:stripped_spruce_log
fill 95 111 325 95 112 325 minecraft:stone
setblock 95 111 329 minecraft:stripped_spruce_log
fill 95 111 330 95 112 330 minecraft:stone
setblock 95 111 334 minecraft:stripped_spruce_log
fill 95 111 335 95 112 335 minecraft:stone
fill 95 111 339 113 111 339 minecraft:stripped_spruce_log
fill 95 111 346 135 111 346 minecraft:stripped_spruce_log
setblock 95 111 353 minecraft:stone
setblock 95 111 354 minecraft:stripped_spruce_log
fill 95 111 355 96 112 355 minecraft:stone
setblock 95 111 359 minecraft:stripped_spruce_log
fill 95 111 360 95 112 360 minecraft:stone
setblock 96 111 323 minecraft:stripped_spruce_log
setblock 96 111 324 minecraft:glowstone
setblock 96 111 328 minecraft:stripped_spruce_log
fill 96 111 329 96 112 329 minecraft:stone
setblock 96 111 333 minecraft:stripped_spruce_log
fill 96 111 334 96 112 334 minecraft:stone
setblock 96 111 338 minecraft:stripped_spruce_log
setblock 96 111 343 minecraft:glowstone
fill 96 111 353 97 112 353 minecraft:stripped_spruce_log
setblock 96 111 354 minecraft:stone
fill 96 111 356 96 112 356 minecraft:stone
fill 96 111 360 126 111 360 minecraft:stripped_spruce_log
setblock 96 111 362 minecraft:glowstone
setblock 96 111 363 minecraft:stripped_spruce_log
fill 97 111 323 99 111 324 minecraft:stone
fill 97 111 325 99 112 325 minecraft:stripped_spruce_log
setblock 97 111 327 minecraft:stripped_spruce_log
fill 97 111 328 97 112 328 minecraft:stone
setblock 97 111 332 minecraft:stripped_spruce_log
fill 97 111 333 97 114 333 minecraft:stone
fill 97 111 363 100 111 363 minecraft:stone
fill 97 111 364 97 175 364 minecraft:deepslate
setblock 98 111 331 minecraft:stripped_spruce_log
fill 98 111 332 98 112 332 minecraft:stone
fill 98 111 362 98 112 362 minecraft:stone
fill 99 111 322 100 139 322 minecraft:deepslate
fill 99 111 332 126 112 332 minecraft:stripped_spruce_log
setblock 100 111 323 minecraft:stone
setblock 100 111 324 minecraft:stripped_spruce_log
setblock 100 111 325 minecraft:stone
setblock 101 111 323 minecraft:stripped_spruce_log
fill 101 111 324 101 112 324 minecraft:stone
fill 101 111 361 102 111 361 minecraft:stone
setblock 101 111 363 minecraft:stripped_spruce_log
fill 102 111 323 105 111 323 minecraft:stone
setblock 102 111 362 minecraft:stripped_spruce_log
fill 102 111 363 102 112 363 minecraft:stone
fill 103 111 325 134 111 325 minecraft:stripped_spruce_log
setblock 103 111 361 minecraft:stripped_spruce_log
fill 103 111 362 103 112 362 minecraft:stone
setblock 105 111 324 minecraft:stripped_spruce_log
setblock 106 111 323 minecraft:stripped_spruce_log
setblock 106 111 363 minecraft:stripped_spruce_log
fill 107 111 322 107 115 322 minecraft:deepslate
setblock 107 111 323 minecraft:stone
fill 107 111 363 107 112 363 minecraft:stone
fill 110 111 322 110 128 322 minecraft:deepslate
fill 111 111 359 111 113 359 minecraft:stripped_spruce_log
fill 114 111 363 115 111 363 minecraft:stone
fill 115 111 322 115 134 322 minecraft:deepslate
setblock 115 111 324 minecraft:glowstone
setblock 115 111 362 minecraft:glowstone
setblock 116 111 363 minecraft:stripped_spruce_log
setblock 117 111 362 minecraft:stripped_spruce_log
fill 117 111 363 120 111 363 minecraft:stone
fill 118 111 362 118 112 362 minecraft:stone
fill 121 111 339 135 111 339 minecraft:stripped_spruce_log
setblock 121 111 363 minecraft:stripped_spruce_log
fill 121 111 364 121 174 364 minecraft:deepslate
setblock 122 111 362 minecraft:stripped_spruce_log
fill 122 111 363 122 112 363 minecraft:stone
fill 123 111 322 123 121 322 minecraft:deepslate
setblock 124 111 322 minecraft:raw_iron_block
fill 125 111 322 131 111 322 minecraft:deepslate
fill 130 111 332 133 112 332 minecraft:stripped_spruce_log
setblock 134 111 324 minecraft:glowstone
setblock 134 111 330 minecraft:stripped_spruce_log
fill 134 111 331 134 112 331 minecraft:stone
setblock 134 111 334 minecraft:stone
setblock 134 111 335 minecraft:stripped_spruce_log
fill 134 111 336 134 112 336 minecraft:stone
setblock 134 111 343 minecraft:glowstone
setblock 134 111 362 minecraft:glowstone
setblock 135 111 329 minecraft:stripped_spruce_log
fill 135 111 330 135 112 330 minecraft:stone
setblock 135 111 334 minecraft:stripped_spruce_log
fill 135 111 335 135 112 335 minecraft:stone
fill 135 111 340 135 112 340 minecraft:stone
setblock 135 111 349 minecraft:stripped_spruce_log
fill 135 111 350 135 112 350 minecraft:stone
setblock 135 111 354 minecraft:stripped_spruce_log
fill 135 111 355 135 112 355 minecraft:stone
fill 136 111 323 136 116 323 minecraft:deepslate
fill 136 111 329 136 130 329 minecraft:deepslate
fill 136 111 332 136 115 332 minecraft:deepslate
fill 136 111 357 136 120 357 minecraft:deepslate
fill 136 111 362 136 171 364 minecraft:deepslate
fill 94 112 357 94 174 357 minecraft:deepslate
setblock 95 112 323 minecraft:stripped_spruce_log
setblock 95 112 324 minecraft:stone
setblock 95 112 328 minecraft:stripped_spruce_log
setblock 95 112 329 minecraft:stone
schedule function dropper:buildpart/74_3 1t
