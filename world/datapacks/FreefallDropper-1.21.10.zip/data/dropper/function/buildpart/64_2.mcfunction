fill 209 125 287 209 125 288 minecraft:sea_lantern
fill 209 125 292 210 125 292 minecraft:prismarine
fill 209 125 293 210 125 295 minecraft:prismarine_bricks
fill 209 125 296 210 125 296 minecraft:prismarine
fill 209 125 300 209 125 301 minecraft:sea_lantern
fill 209 125 302 230 125 302 minecraft:dark_prismarine
fill 210 125 287 229 125 287 minecraft:dark_prismarine
fill 210 125 288 210 125 289 minecraft:sea_lantern
fill 210 125 299 210 125 300 minecraft:sea_lantern
fill 210 125 301 230 125 301 minecraft:dark_prismarine
fill 211 125 277 224 125 279 minecraft:dark_prismarine
fill 211 125 288 229 125 289 minecraft:dark_prismarine
fill 211 125 290 211 125 298 minecraft:sea_lantern
fill 211 125 299 229 125 300 minecraft:dark_prismarine
fill 211 125 313 224 125 315 minecraft:dark_prismarine
fill 212 125 290 229 125 293 minecraft:dark_prismarine
setblock 212 125 294 minecraft:prismarine_bricks
fill 212 125 295 225 125 298 minecraft:dark_prismarine
setblock 212 125 317 minecraft:prismarine_bricks
fill 213 125 294 230 125 294 minecraft:dark_prismarine
setblock 214 125 317 minecraft:dark_prismarine
fill 216 125 275 217 125 275 minecraft:prismarine_bricks
fill 218 125 317 219 126 317 minecraft:dark_prismarine
fill 221 125 275 222 125 275 minecraft:prismarine_bricks
fill 223 125 317 223 127 317 minecraft:dark_prismarine
fill 225 125 277 229 125 277 minecraft:dark_prismarine
fill 225 125 315 229 125 315 minecraft:dark_prismarine
fill 225 125 317 225 126 317 minecraft:dark_prismarine
fill 226 125 298 229 125 298 minecraft:dark_prismarine
setblock 226 125 317 minecraft:prismarine_bricks
fill 227 125 275 228 125 275 minecraft:prismarine_bricks
fill 228 125 278 229 125 280 minecraft:dark_prismarine
fill 228 125 312 229 125 314 minecraft:dark_prismarine
fill 229 125 295 229 125 297 minecraft:dark_prismarine
setblock 230 125 275 minecraft:prismarine_bricks
setblock 230 125 285 minecraft:prismarine_bricks
setblock 230 125 296 minecraft:prismarine_bricks
fill 230 125 297 230 126 297 minecraft:dark_prismarine
setblock 230 125 303 minecraft:prismarine_bricks
fill 188 126 275 188 126 277 minecraft:dark_prismarine
setblock 188 126 279 minecraft:dark_prismarine
fill 188 126 281 188 126 283 minecraft:dark_prismarine
setblock 188 126 286 minecraft:dark_prismarine
setblock 188 126 295 minecraft:dark_prismarine
fill 188 126 297 188 126 301 minecraft:dark_prismarine
fill 188 126 303 188 126 306 minecraft:dark_prismarine
fill 188 126 312 188 126 313 minecraft:dark_prismarine
setblock 191 126 286 minecraft:light[level=15]
setblock 191 126 294 minecraft:light[level=15]
fill 191 126 295 192 140 297 minecraft:quartz_pillar
setblock 191 126 302 minecraft:light[level=15]
setblock 191 126 310 minecraft:light[level=15]
setblock 196 126 275 minecraft:dark_prismarine
setblock 199 126 275 minecraft:dark_prismarine
setblock 199 126 278 minecraft:light[level=15]
setblock 199 126 286 minecraft:light[level=15]
setblock 199 126 302 minecraft:light[level=15]
setblock 199 126 310 minecraft:light[level=15]
setblock 200 126 317 minecraft:dark_prismarine
setblock 206 126 275 minecraft:dark_prismarine
setblock 207 126 278 minecraft:light[level=15]
setblock 207 126 286 minecraft:light[level=15]
setblock 207 126 294 minecraft:light[level=15]
setblock 207 126 302 minecraft:light[level=15]
setblock 207 126 310 minecraft:light[level=15]
fill 207 126 317 207 128 317 minecraft:dark_prismarine
setblock 209 126 275 minecraft:dark_prismarine
setblock 212 126 317 minecraft:dark_prismarine
setblock 214 126 317 minecraft:sea_lantern
setblock 215 126 278 minecraft:light[level=15]
setblock 215 126 286 minecraft:light[level=15]
setblock 215 126 294 minecraft:light[level=15]
setblock 215 126 302 minecraft:light[level=15]
setblock 215 126 310 minecraft:light[level=15]
fill 216 126 275 217 126 275 minecraft:dark_prismarine
fill 221 126 275 222 126 275 minecraft:dark_prismarine
setblock 223 126 278 minecraft:light[level=15]
setblock 223 126 286 minecraft:light[level=15]
setblock 223 126 294 minecraft:light[level=15]
setblock 223 126 302 minecraft:light[level=15]
setblock 223 126 310 minecraft:light[level=15]
setblock 226 126 317 minecraft:dark_prismarine
fill 227 126 275 228 126 275 minecraft:dark_prismarine
setblock 230 126 275 minecraft:dark_prismarine
setblock 230 126 281 minecraft:dark_prismarine
setblock 230 126 283 minecraft:dark_prismarine
setblock 230 126 285 minecraft:dark_prismarine
setblock 230 126 294 minecraft:dark_prismarine
setblock 230 126 296 minecraft:dark_prismarine
fill 230 126 301 230 126 303 minecraft:dark_prismarine
setblock 230 126 306 minecraft:dark_prismarine
fill 230 126 308 230 127 308 minecraft:dark_prismarine
setblock 188 127 275 minecraft:dark_prismarine
fill 188 127 276 188 127 305 minecraft:prismarine_bricks
setblock 188 127 306 minecraft:dark_prismarine
fill 188 127 307 188 127 312 minecraft:prismarine_bricks
setblock 188 127 313 minecraft:dark_prismarine
fill 188 127 314 188 214 316 minecraft:prismarine_bricks
setblock 189 127 275 minecraft:prismarine_bricks
fill 189 127 317 201 127 317 minecraft:prismarine_bricks
setblock 190 127 275 minecraft:sea_lantern
fill 191 127 275 197 127 275 minecraft:prismarine_bricks
setblock 198 127 275 minecraft:dark_prismarine
fill 199 127 275 212 127 275 minecraft:prismarine_bricks
setblock 202 127 317 minecraft:dark_prismarine
fill 203 127 317 206 127 317 minecraft:prismarine_bricks
fill 208 127 317 213 127 317 minecraft:prismarine_bricks
setblock 214 127 317 minecraft:dark_prismarine
fill 215 127 275 217 128 275 minecraft:prismarine_bricks
fill 215 127 317 219 128 317 minecraft:prismarine_bricks
fill 219 127 275 224 128 275 minecraft:prismarine_bricks
setblock 220 127 317 minecraft:sea_lantern
fill 221 127 317 222 217 317 minecraft:prismarine_bricks
fill 224 127 317 228 128 317 minecraft:prismarine_bricks
fill 227 127 275 228 132 275 minecraft:prismarine_bricks
setblock 229 127 317 minecraft:dark_prismarine
fill 230 127 275 230 127 294 minecraft:prismarine_bricks
fill 230 127 296 230 128 300 minecraft:prismarine_bricks
setblock 230 127 301 minecraft:dark_prismarine
fill 230 127 302 230 127 307 minecraft:prismarine_bricks
fill 230 127 309 230 128 317 minecraft:prismarine_bricks
fill 188 128 275 188 217 275 minecraft:prismarine_bricks
setblock 188 128 276 minecraft:sea_lantern
fill 188 128 277 188 217 278 minecraft:prismarine_bricks
setblock 188 128 279 minecraft:dark_prismarine
fill 188 128 280 188 128 290 minecraft:prismarine_bricks
fill 188 128 291 188 128 292 minecraft:dark_prismarine
setblock 188 128 293 minecraft:prismarine_bricks
setblock 188 128 294 minecraft:dark_prismarine
fill 188 128 295 188 128 304 minecraft:prismarine_bricks
setblock 188 128 305 minecraft:dark_prismarine
fill 188 128 306 188 128 311 minecraft:prismarine_bricks
fill 188 128 312 188 129 312 minecraft:dark_prismarine
fill 188 128 313 188 214 313 minecraft:prismarine_bricks
setblock 188 128 317 minecraft:prismarine_bricks
setblock 189 128 275 minecraft:dark_prismarine
fill 189 128 317 190 128 317 minecraft:dark_prismarine
fill 190 128 275 193 129 275 minecraft:prismarine_bricks
setblock 191 128 285 minecraft:light[level=12]
setblock 191 128 292 minecraft:light[level=12]
setblock 191 128 299 minecraft:light[level=12]
setblock 191 128 306 minecraft:light[level=12]
fill 191 128 317 202 128 317 minecraft:prismarine_bricks
fill 194 128 275 194 129 275 minecraft:dark_prismarine
fill 195 128 275 209 128 275 minecraft:prismarine_bricks
setblock 198 128 278 minecraft:light[level=12]
setblock 198 128 285 minecraft:light[level=12]
setblock 198 128 292 minecraft:light[level=12]
setblock 198 128 299 minecraft:light[level=12]
setblock 198 128 306 minecraft:light[level=12]
setblock 198 128 313 minecraft:light[level=12]
fill 203 128 317 204 128 317 minecraft:dark_prismarine
setblock 205 128 278 minecraft:light[level=12]
setblock 205 128 285 minecraft:light[level=12]
setblock 205 128 292 minecraft:light[level=12]
setblock 205 128 299 minecraft:light[level=12]
setblock 205 128 306 minecraft:light[level=12]
setblock 205 128 313 minecraft:light[level=12]
fill 205 128 317 206 217 317 minecraft:prismarine_bricks
fill 208 128 317 208 188 317 minecraft:prismarine_bricks
fill 209 128 317 210 128 317 minecraft:dark_prismarine
setblock 210 128 275 minecraft:dark_prismarine
fill 211 128 275 214 140 275 minecraft:prismarine_bricks
fill 211 128 317 211 213 317 minecraft:prismarine_bricks
setblock 212 128 278 minecraft:light[level=12]
setblock 212 128 285 minecraft:light[level=12]
setblock 212 128 292 minecraft:light[level=12]
setblock 212 128 299 minecraft:light[level=12]
setblock 212 128 306 minecraft:light[level=12]
setblock 212 128 313 minecraft:light[level=12]
setblock 212 128 317 minecraft:dark_prismarine
fill 213 128 317 214 128 317 minecraft:prismarine_bricks
setblock 218 128 275 minecraft:prismarine_bricks
setblock 219 128 278 minecraft:light[level=12]
setblock 219 128 285 minecraft:light[level=12]
setblock 219 128 292 minecraft:light[level=12]
setblock 219 128 299 minecraft:light[level=12]
setblock 219 128 306 minecraft:light[level=12]
setblock 219 128 313 minecraft:light[level=12]
fill 220 128 317 220 215 317 minecraft:prismarine_bricks
fill 223 128 317 223 158 317 minecraft:prismarine_bricks
fill 225 128 275 225 217 275 minecraft:prismarine_bricks
setblock 226 128 285 minecraft:light[level=12]
setblock 226 128 292 minecraft:light[level=12]
setblock 226 128 299 minecraft:light[level=12]
setblock 226 128 306 minecraft:light[level=12]
fill 229 128 275 229 217 275 minecraft:prismarine_bricks
fill 229 128 317 229 214 317 minecraft:prismarine_bricks
setblock 230 128 275 minecraft:dark_prismarine
fill 230 128 276 230 128 282 minecraft:prismarine_bricks
fill 230 128 283 230 129 283 minecraft:dark_prismarine
fill 230 128 284 230 128 291 minecraft:prismarine_bricks
setblock 230 128 292 minecraft:dark_prismarine
fill 230 128 293 230 213 293 minecraft:prismarine_bricks
setblock 230 128 294 minecraft:dark_prismarine
fill 230 128 295 230 148 295 minecraft:prismarine_bricks
fill 230 128 301 230 128 302 minecraft:prismarine_bricks
setblock 230 128 303 minecraft:dark_prismarine
fill 230 128 304 230 148 308 minecraft:prismarine_bricks
setblock 188 129 276 minecraft:dark_prismarine
fill 188 129 279 190 129 280 minecraft:prismarine_bricks
fill 188 129 281 188 131 284 minecraft:sea_lantern
fill 188 129 285 188 176 289 minecraft:prismarine_bricks
setblock 188 129 290 minecraft:dark_prismarine
fill 188 129 291 188 159 292 minecraft:prismarine_bricks
fill 188 129 293 188 131 296 minecraft:sea_lantern
fill 188 129 297 188 142 304 minecraft:prismarine_bricks
fill 188 129 305 188 131 308 minecraft:sea_lantern
fill 188 129 309 188 144 311 minecraft:prismarine_bricks
fill 188 129 317 191 131 317 minecraft:sea_lantern
fill 189 129 275 189 129 278 minecraft:prismarine_bricks
fill 189 129 281 197 129 284 minecraft:prismarine_bricks
fill 189 129 286 189 206 288 minecraft:prismarine_bricks
fill 189 129 298 189 206 300 minecraft:prismarine_bricks
fill 189 129 310 189 206 312 minecraft:prismarine_bricks
fill 190 129 276 190 129 278 minecraft:prismarine_bricks
fill 191 129 276 195 129 277 minecraft:prismarine_bricks
fill 192 129 317 194 214 317 minecraft:prismarine_bricks
fill 194 129 278 197 129 280 minecraft:prismarine_bricks
fill 194 129 287 194 129 288 minecraft:white_stained_glass
fill 195 129 275 198 131 275 minecraft:sea_lantern
fill 195 129 316 197 206 316 minecraft:prismarine_bricks
setblock 195 129 317 minecraft:sea_lantern
fill 196 129 317 199 155 317 minecraft:prismarine_bricks
fill 199 129 275 206 151 275 minecraft:prismarine_bricks
fill 200 129 317 203 131 317 minecraft:sea_lantern
fill 201 129 276 203 206 276 minecraft:prismarine_bricks
setblock 204 129 317 minecraft:dark_prismarine
fill 207 129 275 210 131 275 minecraft:sea_lantern
fill 207 129 316 207 206 317 minecraft:prismarine_bricks
fill 208 129 316 217 129 316 minecraft:prismarine_bricks
fill 209 129 312 217 129 312 minecraft:prismarine_bricks
fill 209 129 317 210 165 317 minecraft:prismarine_bricks
fill 211 129 313 217 129 315 minecraft:prismarine_bricks
fill 212 129 317 215 131 317 minecraft:sea_lantern
fill 213 129 276 215 206 276 minecraft:prismarine_bricks
setblock 215 129 275 minecraft:dark_prismarine
fill 216 129 275 217 147 275 minecraft:prismarine_bricks
fill 216 129 317 219 155 317 minecraft:prismarine_bricks
setblock 218 129 275 minecraft:dark_prismarine
fill 219 129 275 222 131 275 minecraft:sea_lantern
fill 219 129 316 221 206 316 minecraft:prismarine_bricks
fill 223 129 275 224 217 275 minecraft:prismarine_bricks
fill 223 129 311 223 129 313 minecraft:dark_prismarine
fill 224 129 310 226 129 310 minecraft:dark_prismarine
fill 224 129 311 224 206 313 minecraft:prismarine_bricks
setblock 224 129 314 minecraft:dark_prismarine
fill 224 129 317 227 131 317 minecraft:sea_lantern
fill 225 129 276 227 206 276 minecraft:prismarine_bricks
fill 225 129 311 226 206 311 minecraft:prismarine_bricks
fill 226 129 275 226 218 275 minecraft:prismarine_bricks
setblock 227 129 311 minecraft:dark_prismarine
fill 228 129 317 228 130 317 minecraft:prismarine_bricks
fill 229 129 284 230 132 286 minecraft:prismarine_bricks
fill 229 129 296 230 132 298 minecraft:prismarine_bricks
fill 229 129 308 229 206 310 minecraft:prismarine_bricks
fill 230 129 275 230 215 275 minecraft:prismarine_bricks
fill 230 129 276 230 131 279 minecraft:sea_lantern
fill 230 129 280 230 217 280 minecraft:prismarine_bricks
setblock 230 129 281 minecraft:dark_prismarine
fill 230 129 282 230 206 282 minecraft:prismarine_bricks
fill 230 129 287 230 202 287 minecraft:prismarine_bricks
fill 230 129 288 230 131 291 minecraft:sea_lantern
fill 230 129 292 230 213 292 minecraft:prismarine_bricks
fill 230 129 294 230 210 294 minecraft:prismarine_bricks
fill 230 129 299 230 217 299 minecraft:prismarine_bricks
fill 230 129 300 230 131 303 minecraft:sea_lantern
fill 230 129 309 230 189 311 minecraft:prismarine_bricks
fill 230 129 312 230 131 315 minecraft:sea_lantern
fill 230 129 316 230 187 317 minecraft:prismarine_bricks
fill 188 130 276 188 180 276 minecraft:prismarine_bricks
setblock 188 130 279 minecraft:sea_lantern
fill 188 130 280 188 199 280 minecraft:prismarine_bricks
fill 188 130 290 188 217 290 minecraft:prismarine_bricks
fill 188 130 312 188 217 312 minecraft:prismarine_bricks
fill 189 130 275 189 136 275 minecraft:prismarine_bricks
setblock 189 130 276 minecraft:sea_lantern
fill 189 130 277 189 139 277 minecraft:prismarine_bricks
setblock 189 130 278 minecraft:sea_lantern
fill 189 130 279 189 144 279 minecraft:prismarine_bricks
setblock 189 130 280 minecraft:sea_lantern
fill 189 130 281 189 144 281 minecraft:prismarine_bricks
setblock 189 130 282 minecraft:sea_lantern
fill 189 130 283 189 144 284 minecraft:prismarine_bricks
setblock 190 130 275 minecraft:sea_lantern
fill 190 130 276 190 206 276 minecraft:prismarine_bricks
setblock 190 130 277 minecraft:sea_lantern
fill 190 130 278 190 150 278 minecraft:prismarine_bricks
setblock 190 130 279 minecraft:sea_lantern
fill 190 130 280 190 150 280 minecraft:prismarine_bricks
setblock 190 130 281 minecraft:sea_lantern
fill 190 130 282 190 150 282 minecraft:prismarine_bricks
setblock 190 130 283 minecraft:sea_lantern
fill 190 130 284 197 150 284 minecraft:prismarine_bricks
fill 191 130 275 191 217 275 minecraft:prismarine_bricks
setblock 191 130 276 minecraft:sea_lantern
fill 191 130 277 191 139 277 minecraft:prismarine_bricks
setblock 191 130 278 minecraft:sea_lantern
fill 191 130 279 191 140 279 minecraft:quartz_pillar
setblock 191 130 280 minecraft:sea_lantern
fill 191 130 281 191 150 281 minecraft:prismarine_bricks
setblock 191 130 282 minecraft:sea_lantern
fill 191 130 283 191 150 283 minecraft:prismarine_bricks
setblock 192 130 275 minecraft:sea_lantern
fill 192 130 276 192 139 276 minecraft:prismarine_bricks
setblock 192 130 277 minecraft:sea_lantern
fill 192 130 278 192 140 278 minecraft:quartz_pillar
setblock 192 130 279 minecraft:sea_lantern
fill 192 130 280 192 140 280 minecraft:quartz_pillar
setblock 192 130 281 minecraft:sea_lantern
fill 192 130 282 192 150 282 minecraft:prismarine_bricks
setblock 192 130 283 minecraft:sea_lantern
fill 193 130 275 193 214 275 minecraft:prismarine_bricks
setblock 193 130 276 minecraft:sea_lantern
fill 193 130 277 193 139 277 minecraft:prismarine_bricks
setblock 193 130 278 minecraft:sea_lantern
fill 193 130 279 193 140 279 minecraft:quartz_pillar
setblock 193 130 280 minecraft:sea_lantern
fill 193 130 281 193 150 281 minecraft:prismarine_bricks
setblock 193 130 282 minecraft:sea_lantern
fill 193 130 283 193 150 283 minecraft:prismarine_bricks
setblock 194 130 275 minecraft:sea_lantern
fill 194 130 276 194 139 276 minecraft:prismarine_bricks
setblock 194 130 277 minecraft:sea_lantern
fill 194 130 278 194 150 278 minecraft:prismarine_bricks
setblock 194 130 279 minecraft:sea_lantern
fill 194 130 280 194 150 280 minecraft:prismarine_bricks
setblock 194 130 281 minecraft:sea_lantern
fill 194 130 282 194 150 282 minecraft:prismarine_bricks
setblock 194 130 283 minecraft:sea_lantern
setblock 195 130 276 minecraft:sea_lantern
fill 195 130 277 195 139 277 minecraft:prismarine_bricks
setblock 195 130 278 minecraft:sea_lantern
fill 195 130 279 197 150 279 minecraft:prismarine_bricks
setblock 195 130 280 minecraft:sea_lantern
fill 195 130 281 197 150 281 minecraft:prismarine_bricks
setblock 195 130 282 minecraft:sea_lantern
fill 195 130 283 197 150 283 minecraft:prismarine_bricks
fill 195 130 317 195 218 317 minecraft:prismarine_bricks
fill 196 130 278 197 150 278 minecraft:prismarine_bricks
fill 196 130 280 197 150 280 minecraft:prismarine_bricks
fill 196 130 282 197 150 282 minecraft:prismarine_bricks
fill 200 130 287 200 131 287 minecraft:light_blue_stained_glass
fill 204 130 317 204 217 317 minecraft:prismarine_bricks
fill 208 130 313 208 140 315 minecraft:quartz_pillar
fill 208 130 316 208 206 316 minecraft:prismarine_bricks
setblock 209 130 312 minecraft:sea_lantern
fill 209 130 313 209 140 313 minecraft:quartz_pillar
setblock 209 130 314 minecraft:sea_lantern
fill 209 130 315 209 140 315 minecraft:quartz_pillar
setblock 209 130 316 minecraft:sea_lantern
fill 210 130 312 210 144 312 minecraft:prismarine_bricks
setblock 210 130 313 minecraft:sea_lantern
fill 210 130 314 210 140 314 minecraft:quartz_pillar
setblock 210 130 315 minecraft:sea_lantern
fill 210 130 316 210 144 316 minecraft:prismarine_bricks
setblock 211 130 312 minecraft:sea_lantern
fill 211 130 313 211 144 313 minecraft:prismarine_bricks
setblock 211 130 314 minecraft:sea_lantern
fill 211 130 315 211 144 315 minecraft:prismarine_bricks
setblock 211 130 316 minecraft:sea_lantern
fill 212 130 312 212 144 312 minecraft:prismarine_bricks
setblock 212 130 313 minecraft:sea_lantern
fill 212 130 314 212 144 314 minecraft:prismarine_bricks
setblock 212 130 315 minecraft:sea_lantern
fill 212 130 316 212 144 316 minecraft:prismarine_bricks
setblock 213 130 312 minecraft:sea_lantern
fill 213 130 313 213 144 313 minecraft:prismarine_bricks
setblock 213 130 314 minecraft:sea_lantern
fill 213 130 315 213 144 315 minecraft:prismarine_bricks
setblock 213 130 316 minecraft:sea_lantern
fill 214 130 312 214 144 312 minecraft:prismarine_bricks
setblock 214 130 313 minecraft:sea_lantern
fill 214 130 314 214 144 314 minecraft:prismarine_bricks
setblock 214 130 315 minecraft:sea_lantern
fill 214 130 316 214 144 316 minecraft:prismarine_bricks
fill 215 130 275 215 213 275 minecraft:prismarine_bricks
setblock 215 130 312 minecraft:sea_lantern
fill 215 130 313 215 144 313 minecraft:prismarine_bricks
setblock 215 130 314 minecraft:sea_lantern
fill 215 130 315 215 144 315 minecraft:prismarine_bricks
setblock 215 130 316 minecraft:sea_lantern
fill 216 130 312 216 144 312 minecraft:prismarine_bricks
setblock 216 130 313 minecraft:sea_lantern
fill 216 130 314 216 144 314 minecraft:prismarine_bricks
setblock 216 130 315 minecraft:sea_lantern
fill 216 130 316 216 144 316 minecraft:prismarine_bricks
setblock 217 130 312 minecraft:sea_lantern
fill 217 130 313 217 144 313 minecraft:prismarine_bricks
setblock 217 130 314 minecraft:sea_lantern
fill 217 130 315 217 144 315 minecraft:prismarine_bricks
setblock 217 130 316 minecraft:sea_lantern
fill 218 130 275 218 132 275 minecraft:prismarine_bricks
fill 224 130 293 225 131 293 minecraft:white_stained_glass
fill 230 130 281 230 139 281 minecraft:prismarine_bricks
fill 230 130 283 230 214 283 minecraft:prismarine_bricks
fill 188 131 279 188 217 279 minecraft:prismarine_bricks
fill 189 131 276 189 132 276 minecraft:prismarine_bricks
fill 189 131 278 189 132 278 minecraft:prismarine_bricks
fill 189 131 280 189 132 280 minecraft:prismarine_bricks
fill 189 131 282 189 132 282 minecraft:prismarine_bricks
fill 190 131 275 190 132 275 minecraft:prismarine_bricks
fill 190 131 277 190 132 277 minecraft:prismarine_bricks
fill 190 131 279 190 132 279 minecraft:prismarine_bricks
fill 190 131 281 190 132 281 minecraft:prismarine_bricks
fill 190 131 283 190 132 283 minecraft:prismarine_bricks
fill 191 131 276 191 132 276 minecraft:prismarine_bricks
fill 191 131 278 191 132 278 minecraft:quartz_pillar
fill 191 131 280 191 132 280 minecraft:quartz_pillar
fill 191 131 282 191 132 282 minecraft:prismarine_bricks
fill 192 131 275 192 132 275 minecraft:prismarine_bricks
fill 192 131 277 192 132 277 minecraft:prismarine_bricks
fill 192 131 279 192 132 279 minecraft:quartz_pillar
fill 192 131 281 192 132 281 minecraft:prismarine_bricks
fill 192 131 283 192 132 283 minecraft:prismarine_bricks
fill 193 131 276 193 132 276 minecraft:prismarine_bricks
fill 193 131 278 193 132 278 minecraft:quartz_pillar
fill 193 131 280 193 132 280 minecraft:quartz_pillar
fill 193 131 282 193 132 282 minecraft:prismarine_bricks
fill 194 131 275 194 132 275 minecraft:prismarine_bricks
fill 194 131 277 194 132 277 minecraft:prismarine_bricks
fill 194 131 279 194 132 279 minecraft:prismarine_bricks
fill 194 131 281 194 132 281 minecraft:prismarine_bricks
fill 194 131 283 194 132 283 minecraft:prismarine_bricks
fill 195 131 276 195 132 276 minecraft:prismarine_bricks
fill 195 131 278 195 132 278 minecraft:prismarine_bricks
fill 195 131 280 195 132 280 minecraft:prismarine_bricks
fill 195 131 282 195 132 282 minecraft:prismarine_bricks
fill 198 131 291 199 132 291 minecraft:white_stained_glass
fill 209 131 312 209 132 312 minecraft:prismarine_bricks
fill 209 131 314 209 132 314 minecraft:quartz_pillar
fill 209 131 316 209 132 316 minecraft:prismarine_bricks
fill 210 131 313 210 132 313 minecraft:quartz_pillar
fill 210 131 315 210 132 315 minecraft:quartz_pillar
fill 211 131 312 211 132 312 minecraft:prismarine_bricks
fill 211 131 314 211 132 314 minecraft:prismarine_bricks
fill 211 131 316 211 132 316 minecraft:prismarine_bricks
fill 212 131 313 212 132 313 minecraft:prismarine_bricks
fill 212 131 315 212 132 315 minecraft:prismarine_bricks
fill 213 131 312 213 132 312 minecraft:prismarine_bricks
fill 213 131 314 213 132 314 minecraft:prismarine_bricks
fill 213 131 316 213 132 316 minecraft:prismarine_bricks
fill 214 131 313 214 132 313 minecraft:prismarine_bricks
fill 214 131 315 214 132 315 minecraft:prismarine_bricks
fill 215 131 312 215 132 312 minecraft:prismarine_bricks
fill 215 131 314 215 132 314 minecraft:prismarine_bricks
fill 215 131 316 215 132 316 minecraft:prismarine_bricks
fill 216 131 313 216 132 313 minecraft:prismarine_bricks
fill 216 131 315 216 132 315 minecraft:prismarine_bricks
fill 217 131 312 217 132 312 minecraft:prismarine_bricks
fill 217 131 314 217 132 314 minecraft:prismarine_bricks
fill 217 131 316 217 132 316 minecraft:prismarine_bricks
fill 222 131 283 222 140 283 minecraft:green_terracotta
setblock 228 131 317 minecraft:sea_lantern
fill 188 132 281 188 145 281 minecraft:prismarine_bricks
fill 188 132 282 188 132 283 minecraft:sea_lantern
fill 188 132 284 188 145 284 minecraft:prismarine_bricks
fill 188 132 293 188 145 293 minecraft:prismarine_bricks
fill 188 132 294 188 132 295 minecraft:sea_lantern
fill 188 132 296 188 145 296 minecraft:prismarine_bricks
fill 188 132 305 188 145 305 minecraft:prismarine_bricks
fill 188 132 306 188 132 307 minecraft:sea_lantern
fill 188 132 308 188 145 308 minecraft:prismarine_bricks
fill 188 132 317 188 145 317 minecraft:prismarine_bricks
fill 189 132 317 190 132 317 minecraft:sea_lantern
fill 191 132 317 191 145 317 minecraft:prismarine_bricks
fill 195 132 275 195 145 275 minecraft:prismarine_bricks
fill 196 132 275 197 132 275 minecraft:sea_lantern
fill 198 132 275 198 145 275 minecraft:prismarine_bricks
fill 200 132 317 200 145 317 minecraft:prismarine_bricks
fill 201 132 317 202 132 317 minecraft:sea_lantern
fill 203 132 317 203 145 317 minecraft:prismarine_bricks
fill 207 132 275 207 145 275 minecraft:prismarine_bricks
fill 208 132 275 209 132 275 minecraft:sea_lantern
fill 210 132 275 210 145 275 minecraft:prismarine_bricks
fill 212 132 317 212 145 317 minecraft:prismarine_bricks
fill 213 132 288 214 133 288 minecraft:light_blue_stained_glass
fill 213 132 317 214 132 317 minecraft:sea_lantern
fill 215 132 317 215 145 317 minecraft:prismarine_bricks
fill 218 132 284 219 133 284 minecraft:white_stained_glass
fill 219 132 275 219 145 275 minecraft:prismarine_bricks
fill 220 132 275 221 132 275 minecraft:sea_lantern
fill 222 132 275 222 145 275 minecraft:prismarine_bricks
fill 224 132 317 224 145 317 minecraft:prismarine_bricks
fill 225 132 317 226 132 317 minecraft:sea_lantern
fill 227 132 317 228 145 317 minecraft:prismarine_bricks
fill 230 132 276 230 145 276 minecraft:prismarine_bricks
fill 230 132 277 230 132 278 minecraft:sea_lantern
fill 230 132 279 230 140 279 minecraft:prismarine_bricks
fill 230 132 288 230 145 288 minecraft:prismarine_bricks
fill 230 132 289 230 132 290 minecraft:sea_lantern
fill 230 132 291 230 145 291 minecraft:prismarine_bricks
fill 230 132 300 230 145 300 minecraft:prismarine_bricks
fill 230 132 301 230 132 302 minecraft:sea_lantern
fill 230 132 303 230 145 303 minecraft:prismarine_bricks
fill 230 132 312 230 132 314 minecraft:sea_lantern
fill 230 132 315 230 145 315 minecraft:prismarine_bricks
fill 188 133 282 188 145 283 minecraft:prismarine_bricks
fill 188 133 294 188 145 295 minecraft:prismarine_bricks
fill 188 133 306 188 145 307 minecraft:prismarine_bricks
setblock 189 133 276 minecraft:sea_lantern
setblock 189 133 278 minecraft:sea_lantern
setblock 189 133 280 minecraft:sea_lantern
setblock 189 133 282 minecraft:sea_lantern
fill 189 133 317 190 145 317 minecraft:prismarine_bricks
setblock 190 133 275 minecraft:sea_lantern
setblock 190 133 277 minecraft:sea_lantern
setblock 190 133 279 minecraft:sea_lantern
setblock 190 133 281 minecraft:sea_lantern
setblock 190 133 283 minecraft:sea_lantern
setblock 191 133 276 minecraft:sea_lantern
setblock 191 133 278 minecraft:sea_lantern
setblock 191 133 280 minecraft:sea_lantern
setblock 191 133 282 minecraft:sea_lantern
setblock 192 133 275 minecraft:sea_lantern
setblock 192 133 277 minecraft:sea_lantern
setblock 192 133 279 minecraft:sea_lantern
setblock 192 133 281 minecraft:sea_lantern
setblock 192 133 283 minecraft:sea_lantern
setblock 193 133 276 minecraft:sea_lantern
setblock 193 133 278 minecraft:sea_lantern
setblock 193 133 280 minecraft:sea_lantern
setblock 193 133 282 minecraft:sea_lantern
setblock 194 133 275 minecraft:sea_lantern
setblock 194 133 277 minecraft:sea_lantern
setblock 194 133 279 minecraft:sea_lantern
setblock 194 133 281 minecraft:sea_lantern
setblock 194 133 283 minecraft:sea_lantern
setblock 195 133 276 minecraft:sea_lantern
setblock 195 133 278 minecraft:sea_lantern
setblock 195 133 280 minecraft:sea_lantern
setblock 195 133 282 minecraft:sea_lantern
fill 196 133 275 197 145 275 minecraft:prismarine_bricks
fill 201 133 317 202 145 317 minecraft:prismarine_bricks
fill 208 133 275 209 145 275 minecraft:prismarine_bricks
setblock 209 133 312 minecraft:sea_lantern
setblock 209 133 314 minecraft:sea_lantern
setblock 209 133 316 minecraft:sea_lantern
setblock 210 133 313 minecraft:sea_lantern
setblock 210 133 315 minecraft:sea_lantern
setblock 211 133 312 minecraft:sea_lantern
setblock 211 133 314 minecraft:sea_lantern
setblock 211 133 316 minecraft:sea_lantern
setblock 212 133 313 minecraft:sea_lantern
setblock 212 133 315 minecraft:sea_lantern
setblock 213 133 312 minecraft:sea_lantern
setblock 213 133 314 minecraft:sea_lantern
setblock 213 133 316 minecraft:sea_lantern
fill 213 133 317 214 145 317 minecraft:prismarine_bricks
setblock 214 133 313 minecraft:sea_lantern
setblock 214 133 315 minecraft:sea_lantern
setblock 215 133 312 minecraft:sea_lantern
setblock 215 133 314 minecraft:sea_lantern
setblock 215 133 316 minecraft:sea_lantern
setblock 216 133 313 minecraft:sea_lantern
setblock 216 133 315 minecraft:sea_lantern
setblock 217 133 312 minecraft:sea_lantern
setblock 217 133 314 minecraft:sea_lantern
setblock 217 133 316 minecraft:sea_lantern
setblock 218 133 275 minecraft:sea_lantern
fill 220 133 275 221 145 275 minecraft:prismarine_bricks
fill 225 133 317 226 145 317 minecraft:prismarine_bricks
fill 227 133 275 227 187 275 minecraft:prismarine_bricks
setblock 228 133 275 minecraft:sea_lantern
fill 229 133 284 229 206 286 minecraft:prismarine_bricks
fill 229 133 296 229 206 298 minecraft:prismarine_bricks
fill 230 133 277 230 145 278 minecraft:prismarine_bricks
setblock 230 133 284 minecraft:sea_lantern
fill 230 133 285 230 195 286 minecraft:prismarine_bricks
fill 230 133 289 230 145 290 minecraft:prismarine_bricks
setblock 230 133 296 minecraft:sea_lantern
fill 230 133 297 230 217 298 minecraft:prismarine_bricks
fill 230 133 301 230 145 302 minecraft:prismarine_bricks
fill 230 133 312 230 134 314 minecraft:prismarine_bricks
fill 189 134 276 189 135 276 minecraft:prismarine_bricks
fill 189 134 278 189 135 278 minecraft:prismarine_bricks
fill 189 134 280 189 135 280 minecraft:prismarine_bricks
fill 189 134 282 189 135 282 minecraft:prismarine_bricks
fill 190 134 275 190 135 275 minecraft:prismarine_bricks
fill 190 134 277 190 135 277 minecraft:prismarine_bricks
fill 190 134 279 190 135 279 minecraft:prismarine_bricks
fill 190 134 281 190 135 281 minecraft:prismarine_bricks
fill 190 134 283 190 135 283 minecraft:prismarine_bricks
fill 191 134 276 191 135 276 minecraft:prismarine_bricks
fill 191 134 278 191 135 278 minecraft:quartz_pillar
fill 191 134 280 191 135 280 minecraft:quartz_pillar
fill 191 134 282 191 135 282 minecraft:prismarine_bricks
setblock 191 134 285 minecraft:light[level=12]
setblock 191 134 286 minecraft:light[level=15]
setblock 191 134 292 minecraft:light[level=12]
setblock 191 134 294 minecraft:light[level=15]
setblock 191 134 299 minecraft:light[level=12]
setblock 191 134 302 minecraft:light[level=15]
setblock 191 134 306 minecraft:light[level=12]
setblock 191 134 310 minecraft:light[level=15]
fill 192 134 275 192 135 275 minecraft:prismarine_bricks
fill 192 134 277 192 135 277 minecraft:prismarine_bricks
fill 192 134 279 192 135 279 minecraft:quartz_pillar
fill 192 134 281 192 135 281 minecraft:prismarine_bricks
fill 192 134 283 192 135 283 minecraft:prismarine_bricks
fill 193 134 276 193 135 276 minecraft:prismarine_bricks
fill 193 134 278 193 135 278 minecraft:quartz_pillar
fill 193 134 280 193 135 280 minecraft:quartz_pillar
fill 193 134 282 193 135 282 minecraft:prismarine_bricks
fill 194 134 275 194 135 275 minecraft:prismarine_bricks
fill 194 134 277 194 135 277 minecraft:prismarine_bricks
fill 194 134 279 194 135 279 minecraft:prismarine_bricks
fill 194 134 281 194 135 281 minecraft:prismarine_bricks
fill 194 134 283 194 135 283 minecraft:prismarine_bricks
fill 195 134 276 195 135 276 minecraft:prismarine_bricks
fill 195 134 278 195 135 278 minecraft:prismarine_bricks
fill 195 134 280 195 135 280 minecraft:prismarine_bricks
fill 195 134 282 195 135 282 minecraft:prismarine_bricks
setblock 198 134 278 minecraft:light[level=12]
setblock 198 134 285 minecraft:light[level=12]
setblock 198 134 292 minecraft:light[level=12]
setblock 198 134 299 minecraft:light[level=12]
setblock 198 134 306 minecraft:light[level=12]
setblock 198 134 313 minecraft:light[level=12]
setblock 199 134 278 minecraft:light[level=15]
setblock 199 134 286 minecraft:light[level=15]
setblock 199 134 294 minecraft:light[level=15]
setblock 199 134 302 minecraft:light[level=15]
setblock 199 134 310 minecraft:light[level=15]
setblock 205 134 278 minecraft:light[level=12]
setblock 205 134 285 minecraft:light[level=12]
setblock 205 134 292 minecraft:light[level=12]
setblock 205 134 299 minecraft:light[level=12]
setblock 205 134 306 minecraft:light[level=12]
setblock 205 134 313 minecraft:light[level=12]
setblock 207 134 278 minecraft:light[level=15]
setblock 207 134 286 minecraft:light[level=15]
setblock 207 134 294 minecraft:light[level=15]
setblock 207 134 302 minecraft:light[level=15]
setblock 207 134 310 minecraft:light[level=15]
fill 209 134 312 209 135 312 minecraft:prismarine_bricks
fill 209 134 314 209 135 314 minecraft:quartz_pillar
fill 209 134 316 209 135 316 minecraft:prismarine_bricks
fill 210 134 313 210 135 313 minecraft:quartz_pillar
fill 210 134 315 210 135 315 minecraft:quartz_pillar
fill 211 134 312 211 135 312 minecraft:prismarine_bricks
fill 211 134 314 211 135 314 minecraft:prismarine_bricks
fill 211 134 316 211 135 316 minecraft:prismarine_bricks
setblock 212 134 278 minecraft:light[level=12]
setblock 212 134 285 minecraft:light[level=12]
setblock 212 134 292 minecraft:light[level=12]
setblock 212 134 299 minecraft:light[level=12]
setblock 212 134 306 minecraft:light[level=12]
fill 212 134 313 212 135 313 minecraft:prismarine_bricks
fill 212 134 315 212 135 315 minecraft:prismarine_bricks
fill 213 134 312 213 135 312 minecraft:prismarine_bricks
fill 213 134 314 213 135 314 minecraft:prismarine_bricks
fill 213 134 316 213 135 316 minecraft:prismarine_bricks
fill 214 134 313 214 135 313 minecraft:prismarine_bricks
fill 214 134 315 214 135 315 minecraft:prismarine_bricks
setblock 215 134 278 minecraft:light[level=15]
setblock 215 134 286 minecraft:light[level=15]
setblock 215 134 294 minecraft:light[level=15]
setblock 215 134 302 minecraft:light[level=15]
setblock 215 134 310 minecraft:light[level=15]
fill 215 134 312 215 135 312 minecraft:prismarine_bricks
fill 215 134 314 215 135 314 minecraft:prismarine_bricks
fill 215 134 316 215 135 316 minecraft:prismarine_bricks
fill 216 134 313 216 135 313 minecraft:prismarine_bricks
fill 216 134 315 216 135 315 minecraft:prismarine_bricks
fill 217 134 312 217 135 312 minecraft:prismarine_bricks
fill 217 134 314 217 135 314 minecraft:prismarine_bricks
fill 217 134 316 217 135 316 minecraft:prismarine_bricks
fill 218 134 275 218 208 275 minecraft:prismarine_bricks
setblock 219 134 278 minecraft:light[level=12]
setblock 219 134 285 minecraft:light[level=12]
setblock 219 134 292 minecraft:light[level=12]
setblock 219 134 299 minecraft:light[level=12]
setblock 219 134 306 minecraft:light[level=12]
setblock 219 134 313 minecraft:light[level=12]
setblock 223 134 278 minecraft:light[level=15]
setblock 223 134 286 minecraft:light[level=15]
setblock 223 134 294 minecraft:light[level=15]
setblock 223 134 302 minecraft:light[level=15]
setblock 223 134 310 minecraft:light[level=15]
setblock 226 134 285 minecraft:light[level=12]
setblock 226 134 292 minecraft:light[level=12]
setblock 226 134 299 minecraft:light[level=12]
setblock 226 134 306 minecraft:light[level=12]
fill 228 134 275 228 217 275 minecraft:prismarine_bricks
fill 230 134 284 230 215 284 minecraft:prismarine_bricks
fill 230 134 296 230 213 296 minecraft:prismarine_bricks
setblock 230 135 312 minecraft:sea_lantern
fill 230 135 313 230 145 314 minecraft:prismarine_bricks
setblock 189 136 276 minecraft:sea_lantern
setblock 189 136 278 minecraft:sea_lantern
setblock 189 136 280 minecraft:sea_lantern
setblock 189 136 282 minecraft:sea_lantern
setblock 190 136 275 minecraft:sea_lantern
setblock 190 136 277 minecraft:sea_lantern
setblock 190 136 279 minecraft:sea_lantern
setblock 190 136 281 minecraft:sea_lantern
setblock 190 136 283 minecraft:sea_lantern
setblock 191 136 276 minecraft:sea_lantern
setblock 191 136 278 minecraft:sea_lantern
setblock 191 136 280 minecraft:sea_lantern
setblock 191 136 282 minecraft:sea_lantern
setblock 192 136 275 minecraft:sea_lantern
setblock 192 136 277 minecraft:sea_lantern
setblock 192 136 279 minecraft:sea_lantern
setblock 192 136 281 minecraft:sea_lantern
setblock 192 136 283 minecraft:sea_lantern
setblock 193 136 276 minecraft:sea_lantern
setblock 193 136 278 minecraft:sea_lantern
setblock 193 136 280 minecraft:sea_lantern
setblock 193 136 282 minecraft:sea_lantern
setblock 194 136 275 minecraft:sea_lantern
setblock 194 136 277 minecraft:sea_lantern
setblock 194 136 279 minecraft:sea_lantern
setblock 194 136 281 minecraft:sea_lantern
setblock 194 136 283 minecraft:sea_lantern
setblock 195 136 276 minecraft:sea_lantern
setblock 195 136 278 minecraft:sea_lantern
setblock 195 136 280 minecraft:sea_lantern
setblock 195 136 282 minecraft:sea_lantern
setblock 209 136 312 minecraft:sea_lantern
setblock 209 136 314 minecraft:sea_lantern
setblock 209 136 316 minecraft:sea_lantern
setblock 210 136 313 minecraft:sea_lantern
setblock 210 136 315 minecraft:sea_lantern
setblock 211 136 312 minecraft:sea_lantern
setblock 211 136 314 minecraft:sea_lantern
setblock 211 136 316 minecraft:sea_lantern
setblock 212 136 313 minecraft:sea_lantern
setblock 212 136 315 minecraft:sea_lantern
setblock 213 136 312 minecraft:sea_lantern
setblock 213 136 314 minecraft:sea_lantern
setblock 213 136 316 minecraft:sea_lantern
setblock 214 136 313 minecraft:sea_lantern
setblock 214 136 315 minecraft:sea_lantern
setblock 215 136 312 minecraft:sea_lantern
setblock 215 136 314 minecraft:sea_lantern
setblock 215 136 316 minecraft:sea_lantern
setblock 216 136 313 minecraft:sea_lantern
setblock 216 136 315 minecraft:sea_lantern
setblock 217 136 312 minecraft:sea_lantern
setblock 217 136 314 minecraft:sea_lantern
setblock 217 136 316 minecraft:sea_lantern
fill 230 136 312 230 145 312 minecraft:prismarine_bricks
setblock 189 137 275 minecraft:sea_lantern
fill 189 137 276 189 206 276 minecraft:prismarine_bricks
fill 189 137 278 189 150 278 minecraft:prismarine_bricks
fill 189 137 280 189 144 280 minecraft:prismarine_bricks
fill 189 137 282 189 144 282 minecraft:prismarine_bricks
fill 190 137 275 190 217 275 minecraft:prismarine_bricks
fill 190 137 277 190 139 277 minecraft:prismarine_bricks
fill 190 137 279 190 150 279 minecraft:prismarine_bricks
fill 190 137 281 190 150 281 minecraft:prismarine_bricks
fill 190 137 283 190 150 283 minecraft:prismarine_bricks
fill 191 137 276 191 206 276 minecraft:prismarine_bricks
fill 191 137 278 191 140 278 minecraft:quartz_pillar
fill 191 137 280 191 140 280 minecraft:quartz_pillar
fill 191 137 282 191 150 282 minecraft:prismarine_bricks
fill 192 137 275 192 215 275 minecraft:prismarine_bricks
fill 192 137 277 192 139 277 minecraft:prismarine_bricks
fill 192 137 279 192 140 279 minecraft:quartz_pillar
fill 192 137 281 192 150 281 minecraft:prismarine_bricks
fill 192 137 283 192 150 283 minecraft:prismarine_bricks
fill 193 137 276 193 139 276 minecraft:prismarine_bricks
fill 193 137 278 193 140 278 minecraft:quartz_pillar
fill 193 137 280 193 140 280 minecraft:quartz_pillar
fill 193 137 282 193 150 282 minecraft:prismarine_bricks
fill 194 137 275 194 157 275 minecraft:prismarine_bricks
fill 194 137 277 194 139 277 minecraft:prismarine_bricks
fill 194 137 279 194 150 279 minecraft:prismarine_bricks
fill 194 137 281 194 150 281 minecraft:prismarine_bricks
fill 194 137 283 194 150 283 minecraft:prismarine_bricks
fill 195 137 276 195 139 276 minecraft:prismarine_bricks
fill 195 137 278 195 150 278 minecraft:prismarine_bricks
fill 195 137 280 195 150 280 minecraft:prismarine_bricks
fill 195 137 282 195 150 282 minecraft:prismarine_bricks
fill 209 137 312 209 138 312 minecraft:prismarine_bricks
fill 209 137 314 209 138 314 minecraft:quartz_pillar
fill 209 137 316 209 138 316 minecraft:prismarine_bricks
fill 210 137 313 210 138 313 minecraft:quartz_pillar
fill 210 137 315 210 138 315 minecraft:quartz_pillar
fill 211 137 312 211 138 312 minecraft:prismarine_bricks
fill 211 137 314 211 138 314 minecraft:prismarine_bricks
fill 211 137 316 211 138 316 minecraft:prismarine_bricks
fill 212 137 313 212 138 313 minecraft:prismarine_bricks
fill 212 137 315 212 138 315 minecraft:prismarine_bricks
fill 213 137 312 213 138 312 minecraft:prismarine_bricks
fill 213 137 314 213 138 314 minecraft:prismarine_bricks
fill 213 137 316 213 138 316 minecraft:prismarine_bricks
fill 214 137 313 214 138 313 minecraft:prismarine_bricks
fill 214 137 315 214 138 315 minecraft:prismarine_bricks
fill 215 137 312 215 138 312 minecraft:prismarine_bricks
fill 215 137 314 215 138 314 minecraft:prismarine_bricks
fill 215 137 316 215 138 316 minecraft:prismarine_bricks
fill 216 137 313 216 138 313 minecraft:prismarine_bricks
fill 216 137 315 216 138 315 minecraft:prismarine_bricks
fill 217 137 312 217 138 312 minecraft:prismarine_bricks
fill 217 137 314 217 138 314 minecraft:prismarine_bricks
fill 217 137 316 217 138 316 minecraft:prismarine_bricks
fill 223 137 311 223 137 313 minecraft:dark_prismarine
fill 224 137 310 226 137 310 minecraft:dark_prismarine
setblock 224 137 314 minecraft:dark_prismarine
setblock 227 137 311 minecraft:dark_prismarine
fill 189 138 275 189 155 275 minecraft:prismarine_bricks
fill 189 138 290 195 138 290 minecraft:dark_prismarine
fill 191 138 288 195 139 289 minecraft:dark_prismarine
fill 191 138 291 195 139 292 minecraft:dark_prismarine
fill 191 139 290 195 139 290 minecraft:dark_prismarine
setblock 209 139 312 minecraft:sea_lantern
setblock 209 139 314 minecraft:sea_lantern
setblock 209 139 316 minecraft:sea_lantern
setblock 210 139 313 minecraft:sea_lantern
setblock 210 139 315 minecraft:sea_lantern
setblock 211 139 312 minecraft:sea_lantern
setblock 211 139 314 minecraft:sea_lantern
setblock 211 139 316 minecraft:sea_lantern
setblock 212 139 313 minecraft:sea_lantern
setblock 212 139 315 minecraft:sea_lantern
setblock 213 139 312 minecraft:sea_lantern
setblock 213 139 314 minecraft:sea_lantern
setblock 213 139 316 minecraft:sea_lantern
setblock 214 139 313 minecraft:sea_lantern
setblock 214 139 315 minecraft:sea_lantern
setblock 215 139 312 minecraft:sea_lantern
setblock 215 139 314 minecraft:sea_lantern
setblock 215 139 316 minecraft:sea_lantern
setblock 216 139 313 minecraft:sea_lantern
setblock 216 139 315 minecraft:sea_lantern
setblock 217 139 312 minecraft:sea_lantern
setblock 217 139 314 minecraft:sea_lantern
setblock 217 139 316 minecraft:sea_lantern
fill 190 140 277 194 140 277 minecraft:gold_block
fill 190 140 285 190 145 287 minecraft:prismarine_bricks
fill 190 140 298 190 145 299 minecraft:prismarine_bricks
fill 190 140 309 190 145 311 minecraft:prismarine_bricks
setblock 191 140 285 minecraft:light[level=12]
setblock 191 140 292 minecraft:light[level=12]
setblock 191 140 299 minecraft:light[level=12]
setblock 191 140 306 minecraft:light[level=12]
fill 192 140 276 194 140 276 minecraft:gold_block
fill 192 140 289 194 141 291 minecraft:prismarine_bricks
fill 196 140 315 198 145 315 minecraft:prismarine_bricks
setblock 198 140 278 minecraft:light[level=12]
setblock 198 140 285 minecraft:light[level=12]
setblock 198 140 292 minecraft:light[level=12]
setblock 198 140 299 minecraft:light[level=12]
setblock 198 140 306 minecraft:light[level=12]
setblock 198 140 313 minecraft:light[level=12]
fill 200 140 277 202 145 277 minecraft:prismarine_bricks
setblock 205 140 278 minecraft:light[level=12]
setblock 205 140 285 minecraft:light[level=12]
setblock 205 140 292 minecraft:light[level=12]
setblock 205 140 299 minecraft:light[level=12]
setblock 205 140 306 minecraft:light[level=12]
setblock 205 140 313 minecraft:light[level=12]
fill 209 140 312 209 141 312 minecraft:prismarine_bricks
setblock 209 140 314 minecraft:quartz_pillar
fill 209 140 316 209 141 316 minecraft:prismarine_bricks
setblock 210 140 313 minecraft:quartz_pillar
setblock 210 140 315 minecraft:quartz_pillar
fill 211 140 312 211 141 312 minecraft:prismarine_bricks
fill 211 140 314 211 141 314 minecraft:prismarine_bricks
fill 211 140 316 211 141 316 minecraft:prismarine_bricks
fill 212 140 277 214 145 277 minecraft:prismarine_bricks
setblock 212 140 278 minecraft:light[level=12]
setblock 212 140 285 minecraft:light[level=12]
setblock 212 140 292 minecraft:light[level=12]
setblock 212 140 299 minecraft:light[level=12]
setblock 212 140 306 minecraft:light[level=12]
fill 212 140 313 212 141 313 minecraft:prismarine_bricks
fill 212 140 315 212 141 315 minecraft:prismarine_bricks
fill 213 140 312 213 141 312 minecraft:prismarine_bricks
fill 213 140 314 213 141 314 minecraft:prismarine_bricks
fill 213 140 316 213 141 316 minecraft:prismarine_bricks
fill 214 140 313 214 141 313 minecraft:prismarine_bricks
fill 214 140 315 214 141 315 minecraft:prismarine_bricks
fill 215 140 312 215 141 312 minecraft:prismarine_bricks
fill 215 140 314 215 141 314 minecraft:prismarine_bricks
fill 215 140 316 215 141 316 minecraft:prismarine_bricks
fill 216 140 313 216 141 313 minecraft:prismarine_bricks
fill 216 140 315 216 141 315 minecraft:prismarine_bricks
fill 217 140 312 217 141 312 minecraft:prismarine_bricks
fill 217 140 314 217 141 314 minecraft:prismarine_bricks
fill 217 140 316 217 141 316 minecraft:prismarine_bricks
setblock 219 140 278 minecraft:light[level=12]
setblock 219 140 285 minecraft:light[level=12]
setblock 219 140 292 minecraft:light[level=12]
setblock 219 140 299 minecraft:light[level=12]
setblock 219 140 306 minecraft:light[level=12]
setblock 219 140 313 minecraft:light[level=12]
fill 220 140 315 222 145 315 minecraft:prismarine_bricks
fill 224 140 277 226 145 277 minecraft:prismarine_bricks
setblock 226 140 285 minecraft:light[level=12]
setblock 226 140 292 minecraft:light[level=12]
setblock 226 140 299 minecraft:light[level=12]
setblock 226 140 306 minecraft:light[level=12]
fill 228 140 285 228 145 287 minecraft:prismarine_bricks
fill 228 140 298 228 145 299 minecraft:prismarine_bricks
fill 228 140 309 228 145 311 minecraft:prismarine_bricks
setblock 230 140 281 minecraft:sea_lantern
fill 189 141 296 193 142 296 minecraft:prismarine_bricks
fill 190 141 295 192 142 295 minecraft:prismarine_bricks
fill 190 141 297 192 142 297 minecraft:prismarine_bricks
fill 190 141 313 194 142 313 minecraft:prismarine_bricks
setblock 191 141 277 minecraft:gold_block
fill 191 141 278 193 142 280 minecraft:prismarine_bricks
fill 191 141 294 191 142 294 minecraft:prismarine_bricks
fill 191 141 298 191 142 298 minecraft:prismarine_bricks
fill 191 141 312 193 142 312 minecraft:prismarine_bricks
fill 191 141 314 193 142 314 minecraft:prismarine_bricks
fill 192 141 277 192 142 277 minecraft:prismarine_bricks
fill 192 141 311 192 142 311 minecraft:prismarine_bricks
fill 192 141 315 192 142 315 minecraft:prismarine_bricks
setblock 193 141 277 minecraft:gold_block
fill 207 141 278 211 142 278 minecraft:prismarine_bricks
fill 207 141 314 210 141 314 minecraft:prismarine_bricks
fill 208 141 277 210 142 277 minecraft:prismarine_bricks
fill 208 141 279 210 142 279 minecraft:prismarine_bricks
fill 208 141 313 210 141 313 minecraft:prismarine_bricks
fill 208 141 315 210 141 315 minecraft:prismarine_bricks
fill 209 141 276 209 142 276 minecraft:prismarine_bricks
fill 209 141 280 209 142 280 minecraft:prismarine_bricks
setblock 211 141 275 minecraft:sea_lantern
fill 212 141 275 214 170 275 minecraft:prismarine_bricks
fill 224 141 279 228 142 279 minecraft:prismarine_bricks
fill 225 141 278 227 142 278 minecraft:prismarine_bricks
fill 225 141 280 227 142 280 minecraft:prismarine_bricks
fill 225 141 296 228 142 296 minecraft:prismarine_bricks
fill 225 141 312 227 142 314 minecraft:prismarine_bricks
fill 226 141 281 226 142 281 minecraft:prismarine_bricks
fill 226 141 295 228 142 295 minecraft:prismarine_bricks
fill 226 141 297 228 142 297 minecraft:prismarine_bricks
fill 226 141 315 226 142 315 minecraft:prismarine_bricks
fill 227 141 294 227 142 294 minecraft:prismarine_bricks
fill 227 141 298 227 142 298 minecraft:prismarine_bricks
fill 228 141 313 228 142 313 minecraft:prismarine_bricks
setblock 230 141 279 minecraft:sea_lantern
fill 230 141 281 230 217 281 minecraft:prismarine_bricks
setblock 191 142 286 minecraft:light[level=15]
setblock 191 142 302 minecraft:light[level=15]
setblock 191 142 310 minecraft:light[level=15]
fill 192 142 290 194 144 290 minecraft:prismarine_bricks
fill 193 142 289 193 144 289 minecraft:prismarine_bricks
fill 193 142 291 193 144 291 minecraft:prismarine_bricks
setblock 199 142 278 minecraft:light[level=15]
setblock 199 142 286 minecraft:light[level=15]
setblock 199 142 294 minecraft:light[level=15]
setblock 199 142 302 minecraft:light[level=15]
setblock 199 142 310 minecraft:light[level=15]
setblock 207 142 286 minecraft:light[level=15]
setblock 207 142 294 minecraft:light[level=15]
setblock 207 142 302 minecraft:light[level=15]
setblock 207 142 310 minecraft:light[level=15]
fill 207 142 314 208 142 314 minecraft:prismarine_bricks
fill 208 142 313 209 142 313 minecraft:prismarine_bricks
fill 208 142 315 209 142 315 minecraft:prismarine_bricks
setblock 209 142 312 minecraft:sea_lantern
setblock 209 142 314 minecraft:sea_lantern
setblock 209 142 316 minecraft:sea_lantern
setblock 210 142 313 minecraft:sea_lantern
setblock 210 142 314 minecraft:prismarine_bricks
setblock 210 142 315 minecraft:sea_lantern
fill 211 142 275 211 217 275 minecraft:prismarine_bricks
setblock 211 142 312 minecraft:sea_lantern
setblock 211 142 314 minecraft:sea_lantern
setblock 211 142 316 minecraft:sea_lantern
setblock 212 142 313 minecraft:sea_lantern
setblock 212 142 315 minecraft:sea_lantern
setblock 213 142 312 minecraft:sea_lantern
setblock 213 142 314 minecraft:sea_lantern
setblock 213 142 316 minecraft:sea_lantern
setblock 214 142 313 minecraft:sea_lantern
setblock 214 142 315 minecraft:sea_lantern
setblock 215 142 278 minecraft:light[level=15]
setblock 215 142 286 minecraft:light[level=15]
setblock 215 142 294 minecraft:light[level=15]
setblock 215 142 302 minecraft:light[level=15]
setblock 215 142 310 minecraft:light[level=15]
setblock 215 142 312 minecraft:sea_lantern
setblock 215 142 314 minecraft:sea_lantern
setblock 215 142 316 minecraft:sea_lantern
setblock 216 142 313 minecraft:sea_lantern
setblock 216 142 315 minecraft:sea_lantern
setblock 217 142 312 minecraft:sea_lantern
setblock 217 142 314 minecraft:sea_lantern
setblock 217 142 316 minecraft:sea_lantern
setblock 223 142 278 minecraft:light[level=15]
setblock 223 142 286 minecraft:light[level=15]
setblock 223 142 294 minecraft:light[level=15]
setblock 223 142 302 minecraft:light[level=15]
setblock 223 142 310 minecraft:light[level=15]
fill 230 142 279 230 145 279 minecraft:prismarine_bricks
fill 188 143 297 188 213 303 minecraft:prismarine_bricks
setblock 188 143 304 minecraft:sea_lantern
fill 190 143 295 192 170 297 minecraft:quartz_pillar
fill 191 143 278 193 170 280 minecraft:quartz_pillar
fill 191 143 312 193 170 314 minecraft:quartz_pillar
fill 208 143 277 210 170 279 minecraft:quartz_pillar
fill 208 143 313 210 170 315 minecraft:quartz_pillar
fill 209 143 312 209 144 312 minecraft:prismarine_bricks
fill 209 143 316 209 206 316 minecraft:prismarine_bricks
fill 211 143 312 211 144 312 minecraft:prismarine_bricks
fill 211 143 314 211 144 314 minecraft:prismarine_bricks
fill 211 143 316 211 144 316 minecraft:prismarine_bricks
fill 212 143 313 212 144 313 minecraft:prismarine_bricks
fill 212 143 315 212 144 315 minecraft:prismarine_bricks
fill 213 143 312 213 144 312 minecraft:prismarine_bricks
fill 213 143 314 213 144 314 minecraft:prismarine_bricks
fill 213 143 316 213 144 316 minecraft:prismarine_bricks
fill 214 143 313 214 144 313 minecraft:prismarine_bricks
fill 214 143 315 214 144 315 minecraft:prismarine_bricks
fill 215 143 312 215 144 312 minecraft:prismarine_bricks
fill 215 143 314 215 144 314 minecraft:prismarine_bricks
fill 215 143 316 215 144 316 minecraft:prismarine_bricks
fill 216 143 313 216 144 313 minecraft:prismarine_bricks
fill 216 143 315 216 144 315 minecraft:prismarine_bricks
fill 217 143 312 217 144 312 minecraft:prismarine_bricks
fill 217 143 314 217 144 314 minecraft:prismarine_bricks
fill 217 143 316 217 144 316 minecraft:prismarine_bricks
fill 222 143 288 226 144 292 minecraft:dark_prismarine
fill 225 143 278 227 170 280 minecraft:quartz_pillar
fill 225 143 312 227 170 314 minecraft:quartz_pillar
fill 226 143 295 228 170 297 minecraft:quartz_pillar
fill 227 143 290 228 143 290 minecraft:dark_prismarine
fill 188 144 304 188 215 304 minecraft:prismarine_bricks
fill 188 145 309 188 147 310 minecraft:prismarine_bricks
setblock 188 145 311 minecraft:sea_lantern
fill 189 145 279 189 145 284 minecraft:dark_prismarine
fill 189 145 291 189 145 296 minecraft:dark_prismarine
fill 189 145 303 189 145 308 minecraft:dark_prismarine
fill 189 145 315 189 145 316 minecraft:dark_prismarine
fill 190 145 316 193 145 316 minecraft:dark_prismarine
fill 193 145 276 198 145 276 minecraft:dark_prismarine
fill 193 145 290 193 149 290 minecraft:prismarine_bricks
fill 200 145 316 205 145 316 minecraft:dark_prismarine
fill 205 145 276 210 145 276 minecraft:dark_prismarine
fill 211 145 313 216 145 315 minecraft:gold_block
fill 212 145 316 217 145 316 minecraft:dark_prismarine
fill 217 145 276 222 145 276 minecraft:dark_prismarine
fill 223 145 289 225 146 291 minecraft:prismarine_bricks
fill 223 145 311 223 145 313 minecraft:dark_prismarine
fill 224 145 310 226 145 310 minecraft:dark_prismarine
setblock 224 145 314 minecraft:dark_prismarine
fill 224 145 316 229 145 316 minecraft:dark_prismarine
setblock 227 145 311 minecraft:dark_prismarine
fill 229 145 276 229 145 281 minecraft:dark_prismarine
fill 229 145 288 229 145 293 minecraft:dark_prismarine
fill 229 145 300 229 145 305 minecraft:dark_prismarine
fill 229 145 312 229 145 315 minecraft:dark_prismarine
fill 188 146 281 188 151 284 minecraft:sea_lantern
fill 188 146 293 188 151 296 minecraft:sea_lantern
fill 188 146 305 188 151 308 minecraft:sea_lantern
fill 188 146 311 188 217 311 minecraft:prismarine_bricks
fill 188 146 317 191 151 317 minecraft:sea_lantern
fill 189 146 279 189 150 284 minecraft:prismarine_bricks
setblock 191 146 285 minecraft:light[level=12]
setblock 191 146 292 minecraft:light[level=12]
setblock 191 146 299 minecraft:light[level=12]
setblock 191 146 306 minecraft:light[level=12]
fill 195 146 275 198 151 275 minecraft:sea_lantern
setblock 198 146 278 minecraft:light[level=12]
setblock 198 146 285 minecraft:light[level=12]
setblock 198 146 292 minecraft:light[level=12]
setblock 198 146 299 minecraft:light[level=12]
setblock 198 146 306 minecraft:light[level=12]
setblock 198 146 313 minecraft:light[level=12]
fill 200 146 317 203 151 317 minecraft:sea_lantern
setblock 205 146 278 minecraft:light[level=12]
setblock 205 146 285 minecraft:light[level=12]
setblock 205 146 292 minecraft:light[level=12]
setblock 205 146 299 minecraft:light[level=12]
setblock 205 146 306 minecraft:light[level=12]
setblock 205 146 313 minecraft:light[level=12]
fill 207 146 275 210 151 275 minecraft:sea_lantern
fill 211 146 314 215 146 314 minecraft:gold_block
setblock 212 146 278 minecraft:light[level=12]
setblock 212 146 285 minecraft:light[level=12]
setblock 212 146 292 minecraft:light[level=12]
setblock 212 146 299 minecraft:light[level=12]
setblock 212 146 306 minecraft:light[level=12]
setblock 212 146 313 minecraft:light[level=12]
fill 212 146 317 215 151 317 minecraft:sea_lantern
fill 219 146 275 222 151 275 minecraft:sea_lantern
setblock 219 146 278 minecraft:light[level=12]
setblock 219 146 285 minecraft:light[level=12]
setblock 219 146 292 minecraft:light[level=12]
setblock 219 146 299 minecraft:light[level=12]
setblock 219 146 306 minecraft:light[level=12]
setblock 219 146 313 minecraft:light[level=12]
fill 224 146 317 227 151 317 minecraft:sea_lantern
setblock 226 146 285 minecraft:light[level=12]
setblock 226 146 292 minecraft:light[level=12]
setblock 226 146 299 minecraft:light[level=12]
setblock 226 146 306 minecraft:light[level=12]
fill 228 146 317 228 213 317 minecraft:prismarine_bricks
fill 230 146 276 230 151 279 minecraft:sea_lantern
fill 230 146 288 230 151 291 minecraft:sea_lantern
fill 230 146 300 230 151 303 minecraft:sea_lantern
fill 230 146 312 230 151 315 minecraft:sea_lantern
fill 212 147 313 214 147 315 minecraft:gold_block
fill 223 147 290 225 149 290 minecraft:prismarine_bricks
fill 224 147 289 224 149 289 minecraft:prismarine_bricks
fill 224 147 291 224 149 291 minecraft:prismarine_bricks
fill 188 148 309 188 158 309 minecraft:prismarine_bricks
setblock 188 148 310 minecraft:sea_lantern
fill 213 148 312 213 148 316 minecraft:gold_block
setblock 216 148 275 minecraft:sea_lantern
fill 217 148 275 217 217 275 minecraft:prismarine_bricks
fill 188 149 310 188 196 310 minecraft:prismarine_bricks
fill 216 149 275 216 205 275 minecraft:prismarine_bricks
setblock 230 149 295 minecraft:sea_lantern
fill 230 149 304 230 149 305 minecraft:prismarine_bricks
setblock 230 149 306 minecraft:sea_lantern
fill 230 149 307 230 188 308 minecraft:prismarine_bricks
setblock 191 150 286 minecraft:light[level=15]
setblock 191 150 294 minecraft:light[level=15]
setblock 191 150 302 minecraft:light[level=15]
setblock 191 150 310 minecraft:light[level=15]
setblock 193 150 290 minecraft:sea_lantern
setblock 199 150 278 minecraft:light[level=15]
setblock 199 150 286 minecraft:light[level=15]
setblock 199 150 294 minecraft:light[level=15]
setblock 199 150 302 minecraft:light[level=15]
setblock 199 150 310 minecraft:light[level=15]
setblock 207 150 278 minecraft:light[level=15]
setblock 207 150 286 minecraft:light[level=15]
setblock 207 150 294 minecraft:light[level=15]
setblock 207 150 302 minecraft:light[level=15]
setblock 207 150 310 minecraft:light[level=15]
setblock 215 150 278 minecraft:light[level=15]
setblock 215 150 286 minecraft:light[level=15]
setblock 215 150 294 minecraft:light[level=15]
setblock 215 150 302 minecraft:light[level=15]
setblock 215 150 310 minecraft:light[level=15]
setblock 223 150 278 minecraft:light[level=15]
setblock 223 150 286 minecraft:light[level=15]
setblock 223 150 294 minecraft:light[level=15]
setblock 223 150 302 minecraft:light[level=15]
setblock 223 150 310 minecraft:light[level=15]
fill 224 150 290 224 154 290 minecraft:prismarine_bricks
fill 230 150 295 230 202 295 minecraft:prismarine_bricks
setblock 230 150 304 minecraft:sea_lantern
fill 230 150 305 230 181 306 minecraft:prismarine_bricks
fill 190 151 279 190 151 283 minecraft:gold_block
fill 191 151 281 196 151 283 minecraft:gold_block
fill 194 151 279 196 151 280 minecraft:gold_block
fill 220 151 282 220 160 282 minecraft:green_terracotta
fill 230 151 304 230 217 304 minecraft:prismarine_bricks
fill 188 152 281 188 165 281 minecraft:prismarine_bricks
fill 188 152 282 188 152 283 minecraft:sea_lantern
fill 188 152 284 188 165 284 minecraft:prismarine_bricks
fill 188 152 293 188 165 293 minecraft:prismarine_bricks
fill 188 152 294 188 152 295 minecraft:sea_lantern
fill 188 152 296 188 154 296 minecraft:prismarine_bricks
fill 188 152 305 188 165 305 minecraft:prismarine_bricks
fill 188 152 306 188 152 307 minecraft:sea_lantern
fill 188 152 308 188 165 308 minecraft:prismarine_bricks
fill 188 152 317 188 165 317 minecraft:prismarine_bricks
fill 189 152 317 190 152 317 minecraft:sea_lantern
fill 191 152 281 195 152 282 minecraft:gold_block
setblock 191 152 285 minecraft:light[level=12]
setblock 191 152 292 minecraft:light[level=12]
setblock 191 152 299 minecraft:light[level=12]
setblock 191 152 306 minecraft:light[level=12]
fill 191 152 317 191 165 317 minecraft:prismarine_bricks
fill 194 152 280 195 152 280 minecraft:gold_block
fill 195 152 275 195 165 275 minecraft:prismarine_bricks
fill 196 152 275 197 152 275 minecraft:sea_lantern
fill 198 152 275 204 165 275 minecraft:prismarine_bricks
setblock 198 152 278 minecraft:light[level=12]
setblock 198 152 285 minecraft:light[level=12]
setblock 198 152 292 minecraft:light[level=12]
setblock 198 152 299 minecraft:light[level=12]
setblock 198 152 306 minecraft:light[level=12]
setblock 198 152 313 minecraft:light[level=12]
fill 200 152 317 200 165 317 minecraft:prismarine_bricks
fill 201 152 317 202 152 317 minecraft:sea_lantern
fill 203 152 317 203 165 317 minecraft:prismarine_bricks
setblock 205 152 275 minecraft:sea_lantern
setblock 205 152 278 minecraft:light[level=12]
setblock 205 152 285 minecraft:light[level=12]
setblock 205 152 292 minecraft:light[level=12]
setblock 205 152 299 minecraft:light[level=12]
setblock 205 152 306 minecraft:light[level=12]
setblock 205 152 313 minecraft:light[level=12]
fill 206 152 275 207 165 275 minecraft:prismarine_bricks
fill 208 152 275 209 152 275 minecraft:sea_lantern
fill 210 152 275 210 165 275 minecraft:prismarine_bricks
setblock 212 152 278 minecraft:light[level=12]
setblock 212 152 285 minecraft:light[level=12]
setblock 212 152 292 minecraft:light[level=12]
setblock 212 152 299 minecraft:light[level=12]
setblock 212 152 306 minecraft:light[level=12]
setblock 212 152 313 minecraft:light[level=12]
fill 212 152 317 212 165 317 minecraft:prismarine_bricks
fill 213 152 317 214 152 317 minecraft:sea_lantern
fill 215 152 317 215 165 317 minecraft:prismarine_bricks
fill 219 152 275 219 165 275 minecraft:prismarine_bricks
setblock 219 152 278 minecraft:light[level=12]
setblock 219 152 285 minecraft:light[level=12]
setblock 219 152 292 minecraft:light[level=12]
setblock 219 152 299 minecraft:light[level=12]
setblock 219 152 306 minecraft:light[level=12]
setblock 219 152 313 minecraft:light[level=12]
fill 220 152 275 221 152 275 minecraft:sea_lantern
fill 222 152 275 222 165 275 minecraft:prismarine_bricks
fill 224 152 317 224 165 317 minecraft:prismarine_bricks
fill 225 152 317 226 152 317 minecraft:sea_lantern
setblock 226 152 285 minecraft:light[level=12]
setblock 226 152 292 minecraft:light[level=12]
setblock 226 152 299 minecraft:light[level=12]
setblock 226 152 306 minecraft:light[level=12]
fill 227 152 317 227 165 317 minecraft:prismarine_bricks
fill 230 152 276 230 165 276 minecraft:prismarine_bricks
fill 230 152 277 230 152 278 minecraft:sea_lantern
fill 230 152 279 230 165 279 minecraft:prismarine_bricks
fill 230 152 288 230 165 288 minecraft:prismarine_bricks
fill 230 152 289 230 152 290 minecraft:sea_lantern
fill 230 152 291 230 165 291 minecraft:prismarine_bricks
fill 230 152 300 230 165 300 minecraft:prismarine_bricks
fill 230 152 301 230 152 302 minecraft:sea_lantern
fill 230 152 303 230 165 303 minecraft:prismarine_bricks
fill 230 152 312 230 165 312 minecraft:prismarine_bricks
fill 230 152 313 230 152 314 minecraft:sea_lantern
fill 230 152 315 230 165 315 minecraft:prismarine_bricks
fill 188 153 282 188 165 283 minecraft:prismarine_bricks
fill 188 153 294 188 165 295 minecraft:prismarine_bricks
fill 188 153 306 188 165 307 minecraft:prismarine_bricks
fill 189 153 317 190 165 317 minecraft:prismarine_bricks
fill 192 153 281 194 153 281 minecraft:gold_block
fill 196 153 275 197 165 275 minecraft:prismarine_bricks
fill 201 153 317 202 165 317 minecraft:prismarine_bricks
fill 205 153 275 205 215 275 minecraft:prismarine_bricks
fill 208 153 275 209 165 275 minecraft:prismarine_bricks
fill 213 153 278 214 154 278 minecraft:white_stained_glass
fill 213 153 317 214 165 317 minecraft:prismarine_bricks
fill 214 153 277 214 154 277 minecraft:white_stained_glass
fill 214 153 279 214 154 279 minecraft:white_stained_glass
fill 220 153 275 221 165 275 minecraft:prismarine_bricks
fill 221 153 312 221 163 312 minecraft:iron_block
fill 223 153 311 223 153 313 minecraft:dark_prismarine
fill 224 153 310 226 153 310 minecraft:dark_prismarine
setblock 224 153 314 minecraft:dark_prismarine
fill 225 153 317 226 165 317 minecraft:prismarine_bricks
setblock 227 153 311 minecraft:dark_prismarine
fill 230 153 277 230 160 278 minecraft:prismarine_bricks
fill 230 153 289 230 165 290 minecraft:prismarine_bricks
fill 230 153 301 230 165 302 minecraft:prismarine_bricks
fill 230 153 313 230 165 314 minecraft:prismarine_bricks
fill 193 154 281 193 154 282 minecraft:gold_block
fill 202 154 288 203 155 289 minecraft:light_blue_stained_glass
setblock 188 155 296 minecraft:sea_lantern
setblock 224 155 290 minecraft:sea_lantern
fill 188 156 296 188 165 296 minecraft:prismarine_bricks
setblock 189 156 275 minecraft:sea_lantern
fill 196 156 317 197 189 317 minecraft:prismarine_bricks
setblock 198 156 317 minecraft:sea_lantern
fill 199 156 317 199 217 317 minecraft:prismarine_bricks
fill 216 156 317 217 215 317 minecraft:prismarine_bricks
setblock 218 156 317 minecraft:sea_lantern
fill 219 156 317 219 217 317 minecraft:prismarine_bricks
fill 189 157 275 189 186 275 minecraft:prismarine_bricks
fill 198 157 317 198 217 317 minecraft:prismarine_bricks
fill 218 157 317 218 168 317 minecraft:prismarine_bricks
setblock 191 158 285 minecraft:light[level=12]
setblock 191 158 286 minecraft:light[level=15]
setblock 191 158 292 minecraft:light[level=12]
setblock 191 158 294 minecraft:light[level=15]
setblock 191 158 299 minecraft:light[level=12]
setblock 191 158 302 minecraft:light[level=15]
setblock 191 158 306 minecraft:light[level=12]
setblock 191 158 310 minecraft:light[level=15]
setblock 194 158 275 minecraft:sea_lantern
setblock 198 158 278 minecraft:light[level=12]
setblock 198 158 285 minecraft:light[level=12]
setblock 198 158 292 minecraft:light[level=12]
setblock 198 158 299 minecraft:light[level=12]
setblock 198 158 306 minecraft:light[level=12]
setblock 198 158 313 minecraft:light[level=12]
setblock 199 158 278 minecraft:light[level=15]
setblock 199 158 286 minecraft:light[level=15]
setblock 199 158 294 minecraft:light[level=15]
setblock 199 158 302 minecraft:light[level=15]
setblock 199 158 310 minecraft:light[level=15]
setblock 205 158 278 minecraft:light[level=12]
setblock 205 158 285 minecraft:light[level=12]
setblock 205 158 292 minecraft:light[level=12]
setblock 205 158 299 minecraft:light[level=12]
setblock 205 158 306 minecraft:light[level=12]
setblock 205 158 313 minecraft:light[level=12]
setblock 207 158 278 minecraft:light[level=15]
setblock 207 158 286 minecraft:light[level=15]
setblock 207 158 294 minecraft:light[level=15]
setblock 207 158 302 minecraft:light[level=15]
setblock 207 158 310 minecraft:light[level=15]
setblock 212 158 278 minecraft:light[level=12]
setblock 212 158 285 minecraft:light[level=12]
setblock 212 158 292 minecraft:light[level=12]
setblock 212 158 299 minecraft:light[level=12]
setblock 212 158 306 minecraft:light[level=12]
setblock 212 158 313 minecraft:light[level=12]
setblock 215 158 278 minecraft:light[level=15]
setblock 215 158 286 minecraft:light[level=15]
setblock 215 158 294 minecraft:light[level=15]
setblock 215 158 302 minecraft:light[level=15]
setblock 215 158 310 minecraft:light[level=15]
setblock 219 158 278 minecraft:light[level=12]
setblock 219 158 285 minecraft:light[level=12]
setblock 219 158 292 minecraft:light[level=12]
setblock 219 158 299 minecraft:light[level=12]
setblock 219 158 306 minecraft:light[level=12]
setblock 219 158 313 minecraft:light[level=12]
fill 220 158 302 226 176 306 minecraft:prismarine_bricks
fill 221 158 301 225 176 301 minecraft:prismarine_bricks
fill 221 158 307 225 176 307 minecraft:prismarine_bricks
setblock 223 158 278 minecraft:light[level=15]
setblock 223 158 286 minecraft:light[level=15]
setblock 223 158 294 minecraft:light[level=15]
setblock 223 158 310 minecraft:light[level=15]
setblock 226 158 285 minecraft:light[level=12]
setblock 226 158 292 minecraft:light[level=12]
setblock 226 158 299 minecraft:light[level=12]
setblock 188 159 309 minecraft:sea_lantern
fill 194 159 275 194 215 275 minecraft:prismarine_bricks
fill 218 159 303 219 175 305 minecraft:prismarine_bricks
fill 219 159 301 219 175 302 minecraft:prismarine_bricks
fill 219 159 306 219 175 307 minecraft:prismarine_bricks
fill 220 159 300 220 175 301 minecraft:prismarine_bricks
fill 220 159 307 220 175 308 minecraft:prismarine_bricks
fill 221 159 300 226 175 300 minecraft:prismarine_bricks
fill 221 159 308 226 175 308 minecraft:prismarine_bricks
fill 222 159 299 224 175 299 minecraft:prismarine_bricks
fill 222 159 309 224 175 309 minecraft:prismarine_bricks
setblock 223 159 317 minecraft:sea_lantern
fill 226 159 301 227 175 301 minecraft:prismarine_bricks
fill 226 159 307 227 175 307 minecraft:prismarine_bricks
fill 227 159 302 227 175 306 minecraft:prismarine_bricks
fill 228 159 303 228 175 305 minecraft:prismarine_bricks
fill 188 160 291 188 217 291 minecraft:prismarine_bricks
setblock 188 160 292 minecraft:sea_lantern
fill 188 160 309 188 217 309 minecraft:prismarine_bricks
fill 190 160 285 190 165 287 minecraft:prismarine_bricks
fill 190 160 298 190 165 299 minecraft:prismarine_bricks
fill 190 160 309 190 165 311 minecraft:prismarine_bricks
fill 196 160 315 198 165 315 minecraft:prismarine_bricks
fill 200 160 277 202 165 277 minecraft:prismarine_bricks
fill 212 160 277 214 165 277 minecraft:prismarine_bricks
fill 217 160 302 217 174 306 minecraft:prismarine_bricks
fill 218 160 301 218 174 302 minecraft:prismarine_bricks
fill 218 160 306 218 174 307 minecraft:prismarine_bricks
fill 219 160 300 219 174 300 minecraft:prismarine_bricks
fill 219 160 308 219 174 308 minecraft:prismarine_bricks
fill 220 160 299 221 174 299 minecraft:prismarine_bricks
fill 220 160 309 221 174 309 minecraft:prismarine_bricks
fill 220 160 315 222 165 315 minecraft:prismarine_bricks
fill 221 160 298 225 174 298 minecraft:prismarine_bricks
fill 221 160 310 225 174 310 minecraft:prismarine_bricks
fill 223 160 317 223 165 317 minecraft:prismarine_bricks
fill 224 160 277 226 165 277 minecraft:prismarine_bricks
fill 225 160 299 226 174 299 minecraft:prismarine_bricks
fill 225 160 309 226 174 309 minecraft:prismarine_bricks
fill 227 160 300 227 174 300 minecraft:prismarine_bricks
fill 227 160 308 227 174 308 minecraft:prismarine_bricks
fill 228 160 285 228 165 287 minecraft:prismarine_bricks
fill 228 160 298 228 171 299 minecraft:prismarine_bricks
fill 228 160 301 228 174 302 minecraft:prismarine_bricks
fill 228 160 306 228 174 307 minecraft:prismarine_bricks
fill 228 160 309 228 169 311 minecraft:prismarine_bricks
fill 229 160 302 229 164 306 minecraft:prismarine_bricks
fill 188 161 292 188 178 292 minecraft:prismarine_bricks
fill 216 161 303 216 173 305 minecraft:prismarine_bricks
fill 217 161 301 217 173 301 minecraft:prismarine_bricks
fill 217 161 307 217 173 307 minecraft:prismarine_bricks
fill 218 161 299 218 173 300 minecraft:prismarine_bricks
fill 218 161 308 218 173 309 minecraft:prismarine_bricks
fill 219 161 299 219 173 299 minecraft:prismarine_bricks
fill 219 161 309 219 173 309 minecraft:prismarine_bricks
fill 220 161 298 220 173 298 minecraft:prismarine_bricks
fill 220 161 310 220 173 310 minecraft:prismarine_bricks
fill 222 161 297 224 173 297 minecraft:prismarine_bricks
fill 222 161 311 223 173 311 minecraft:prismarine_bricks
fill 223 161 312 223 161 313 minecraft:dark_prismarine
setblock 224 161 314 minecraft:dark_prismarine
fill 226 161 298 226 173 298 minecraft:prismarine_bricks
fill 226 161 310 226 173 310 minecraft:prismarine_bricks
fill 227 161 299 227 173 299 minecraft:prismarine_bricks
fill 227 161 309 227 173 309 minecraft:prismarine_bricks
setblock 227 161 311 minecraft:dark_prismarine
fill 228 161 300 228 173 300 minecraft:prismarine_bricks
fill 228 161 308 228 173 308 minecraft:prismarine_bricks
fill 229 161 301 229 164 301 minecraft:prismarine_bricks
fill 229 161 307 229 173 307 minecraft:prismarine_bricks
fill 230 161 277 230 165 277 minecraft:prismarine_bricks
setblock 230 161 278 minecraft:sea_lantern
fill 216 162 301 216 172 302 minecraft:prismarine_bricks
fill 216 162 306 216 172 307 minecraft:prismarine_bricks
fill 217 162 300 217 172 300 minecraft:prismarine_bricks
fill 217 162 308 217 172 308 minecraft:prismarine_bricks
fill 219 162 298 219 172 298 minecraft:prismarine_bricks
fill 219 162 310 219 172 310 minecraft:prismarine_bricks
fill 220 162 297 221 172 297 minecraft:prismarine_bricks
fill 220 162 311 221 172 311 minecraft:prismarine_bricks
fill 225 162 297 225 172 297 minecraft:prismarine_bricks
fill 227 162 298 227 172 298 minecraft:prismarine_bricks
fill 227 162 310 227 172 310 minecraft:prismarine_bricks
fill 229 162 300 229 164 300 minecraft:prismarine_bricks
fill 230 162 278 230 163 278 minecraft:prismarine_bricks
fill 215 163 301 215 163 302 minecraft:dark_prismarine
fill 215 163 303 215 171 305 minecraft:prismarine_bricks
fill 215 163 306 215 163 307 minecraft:dark_prismarine
fill 216 163 300 216 171 300 minecraft:prismarine_bricks
fill 216 163 308 216 171 308 minecraft:prismarine_bricks
fill 217 163 299 217 171 299 minecraft:prismarine_bricks
fill 217 163 309 217 171 309 minecraft:prismarine_bricks
fill 218 163 298 218 171 298 minecraft:prismarine_bricks
fill 218 163 310 218 171 310 minecraft:prismarine_bricks
fill 219 163 297 219 171 297 minecraft:prismarine_bricks
fill 219 163 311 219 171 311 minecraft:prismarine_bricks
fill 222 163 296 224 171 296 minecraft:prismarine_bricks
fill 222 163 312 223 171 312 minecraft:prismarine_bricks
fill 227 163 311 227 171 311 minecraft:prismarine_bricks
fill 229 163 299 229 171 299 minecraft:prismarine_bricks
setblock 191 164 285 minecraft:light[level=12]
setblock 191 164 292 minecraft:light[level=12]
setblock 191 164 299 minecraft:light[level=12]
setblock 191 164 306 minecraft:light[level=12]
setblock 198 164 278 minecraft:light[level=12]
setblock 198 164 285 minecraft:light[level=12]
setblock 198 164 292 minecraft:light[level=12]
setblock 198 164 299 minecraft:light[level=12]
setblock 198 164 306 minecraft:light[level=12]
setblock 198 164 313 minecraft:light[level=12]
setblock 205 164 278 minecraft:light[level=12]
setblock 205 164 285 minecraft:light[level=12]
setblock 205 164 292 minecraft:light[level=12]
setblock 205 164 299 minecraft:light[level=12]
setblock 205 164 306 minecraft:light[level=12]
setblock 205 164 313 minecraft:light[level=12]
setblock 212 164 278 minecraft:light[level=12]
setblock 212 164 285 minecraft:light[level=12]
setblock 212 164 292 minecraft:light[level=12]
setblock 212 164 299 minecraft:light[level=12]
setblock 212 164 306 minecraft:light[level=12]
setblock 212 164 313 minecraft:light[level=12]
fill 215 164 301 215 170 302 minecraft:prismarine_bricks
fill 215 164 306 215 170 307 minecraft:prismarine_bricks
fill 217 164 298 217 170 298 minecraft:prismarine_bricks
fill 217 164 310 217 170 310 minecraft:prismarine_bricks
setblock 219 164 278 minecraft:light[level=12]
setblock 219 164 285 minecraft:light[level=12]
setblock 219 164 292 minecraft:light[level=12]
setblock 219 164 313 minecraft:light[level=12]
fill 220 164 296 221 170 296 minecraft:prismarine_bricks
fill 220 164 312 221 170 312 minecraft:prismarine_bricks
fill 225 164 296 225 172 296 minecraft:prismarine_bricks
setblock 226 164 285 minecraft:light[level=12]
setblock 226 164 292 minecraft:light[level=12]
setblock 230 164 278 minecraft:sea_lantern
fill 189 165 279 189 165 284 minecraft:dark_prismarine
fill 189 165 291 189 165 296 minecraft:dark_prismarine
fill 189 165 303 189 165 308 minecraft:dark_prismarine
fill 189 165 315 189 165 316 minecraft:dark_prismarine
fill 190 165 316 193 165 316 minecraft:dark_prismarine
fill 193 165 276 198 165 276 minecraft:dark_prismarine
fill 200 165 316 205 165 316 minecraft:dark_prismarine
fill 205 165 276 210 165 276 minecraft:dark_prismarine
fill 212 165 316 217 165 316 minecraft:dark_prismarine
fill 216 165 299 216 169 299 minecraft:prismarine_bricks
fill 216 165 309 216 169 309 minecraft:prismarine_bricks
fill 217 165 276 222 165 276 minecraft:dark_prismarine
fill 218 165 297 218 169 297 minecraft:prismarine_bricks
fill 218 165 311 218 169 311 minecraft:prismarine_bricks
fill 224 165 316 229 165 316 minecraft:dark_prismarine
fill 229 165 276 229 165 281 minecraft:dark_prismarine
fill 229 165 288 229 165 293 minecraft:dark_prismarine
fill 229 165 300 229 165 305 minecraft:dark_prismarine
fill 229 165 306 229 174 306 minecraft:prismarine_bricks
fill 229 165 312 229 165 315 minecraft:dark_prismarine
setblock 230 165 278 minecraft:prismarine_bricks
fill 188 166 281 188 171 284 minecraft:sea_lantern
fill 188 166 293 188 171 296 minecraft:sea_lantern
fill 188 166 305 188 171 308 minecraft:sea_lantern
fill 188 166 317 191 171 317 minecraft:sea_lantern
setblock 191 166 286 minecraft:light[level=15]
setblock 191 166 294 minecraft:light[level=15]
setblock 191 166 302 minecraft:light[level=15]
setblock 191 166 310 minecraft:light[level=15]
fill 195 166 275 198 171 275 minecraft:sea_lantern
fill 199 166 275 200 178 275 minecraft:prismarine_bricks
setblock 199 166 278 minecraft:light[level=15]
setblock 199 166 286 minecraft:light[level=15]
setblock 199 166 294 minecraft:light[level=15]
setblock 199 166 302 minecraft:light[level=15]
setblock 199 166 310 minecraft:light[level=15]
fill 200 166 317 203 171 317 minecraft:sea_lantern
setblock 201 166 275 minecraft:sea_lantern
fill 202 166 275 204 179 275 minecraft:prismarine_bricks
fill 206 166 275 206 213 275 minecraft:prismarine_bricks
fill 207 166 275 210 171 275 minecraft:sea_lantern
setblock 207 166 278 minecraft:light[level=15]
setblock 207 166 286 minecraft:light[level=15]
setblock 207 166 294 minecraft:light[level=15]
setblock 207 166 302 minecraft:light[level=15]
setblock 207 166 310 minecraft:light[level=15]
fill 208 166 280 208 167 280 minecraft:white_stained_glass
setblock 209 166 317 minecraft:sea_lantern
fill 210 166 317 210 217 317 minecraft:prismarine_bricks
fill 212 166 317 215 171 317 minecraft:sea_lantern
setblock 215 166 278 minecraft:light[level=15]
setblock 215 166 286 minecraft:light[level=15]
setblock 215 166 294 minecraft:light[level=15]
fill 215 166 300 215 168 300 minecraft:prismarine_bricks
fill 215 166 308 215 168 308 minecraft:prismarine_bricks
setblock 215 166 310 minecraft:light[level=15]
fill 219 166 275 222 171 275 minecraft:sea_lantern
fill 219 166 296 219 168 296 minecraft:prismarine_bricks
fill 219 166 312 219 168 312 minecraft:prismarine_bricks
setblock 223 166 278 minecraft:light[level=15]
setblock 223 166 286 minecraft:light[level=15]
setblock 223 166 294 minecraft:light[level=15]
fill 223 166 317 227 166 317 minecraft:sea_lantern
fill 229 166 300 229 172 305 minecraft:prismarine_bricks
fill 230 166 276 230 171 279 minecraft:sea_lantern
fill 230 166 288 230 171 291 minecraft:sea_lantern
fill 230 166 300 230 171 303 minecraft:sea_lantern
fill 230 166 312 230 171 315 minecraft:sea_lantern
fill 201 167 275 201 213 275 minecraft:prismarine_bricks
fill 209 167 317 209 217 317 minecraft:prismarine_bricks
setblock 214 167 304 minecraft:prismarine_bricks
setblock 223 167 295 minecraft:prismarine_bricks
setblock 223 167 313 minecraft:prismarine_bricks
fill 223 167 317 223 217 317 minecraft:prismarine_bricks
fill 224 167 317 227 171 317 minecraft:sea_lantern
fill 207 168 310 207 169 311 minecraft:white_stained_glass
fill 208 168 304 209 169 305 minecraft:light_blue_stained_glass
fill 215 168 299 215 169 299 minecraft:sea_lantern
fill 215 168 309 215 169 309 minecraft:sea_lantern
fill 214 169 300 214 169 301 minecraft:sea_lantern
fill 214 169 307 214 169 308 minecraft:sea_lantern
fill 215 169 300 215 170 300 minecraft:sea_lantern
fill 215 169 308 215 170 308 minecraft:sea_lantern
setblock 218 169 317 minecraft:sea_lantern
setblock 223 169 313 minecraft:dark_prismarine
setblock 224 169 314 minecraft:dark_prismarine
setblock 191 170 285 minecraft:light[level=12]
setblock 191 170 292 minecraft:light[level=12]
setblock 191 170 299 minecraft:light[level=12]
setblock 191 170 306 minecraft:light[level=12]
setblock 198 170 278 minecraft:light[level=12]
setblock 198 170 285 minecraft:light[level=12]
setblock 198 170 292 minecraft:light[level=12]
setblock 198 170 299 minecraft:light[level=12]
setblock 198 170 306 minecraft:light[level=12]
setblock 198 170 313 minecraft:light[level=12]
setblock 205 170 278 minecraft:light[level=12]
setblock 205 170 285 minecraft:light[level=12]
setblock 205 170 292 minecraft:light[level=12]
setblock 205 170 299 minecraft:light[level=12]
setblock 205 170 306 minecraft:light[level=12]
setblock 205 170 313 minecraft:light[level=12]
setblock 212 170 278 minecraft:light[level=12]
setblock 212 170 285 minecraft:light[level=12]
setblock 212 170 292 minecraft:light[level=12]
setblock 212 170 299 minecraft:light[level=12]
setblock 212 170 306 minecraft:light[level=12]
setblock 212 170 313 minecraft:light[level=12]
fill 218 170 317 218 217 317 minecraft:prismarine_bricks
setblock 219 170 278 minecraft:light[level=12]
setblock 219 170 285 minecraft:light[level=12]
setblock 219 170 292 minecraft:light[level=12]
setblock 219 170 313 minecraft:light[level=12]
setblock 226 170 285 minecraft:light[level=12]
setblock 226 170 292 minecraft:light[level=12]
fill 228 170 309 228 171 310 minecraft:prismarine_bricks
fill 189 171 296 193 172 296 minecraft:prismarine_bricks
fill 190 171 279 194 172 279 minecraft:prismarine_bricks
fill 190 171 295 192 172 295 minecraft:prismarine_bricks
fill 190 171 297 192 172 297 minecraft:prismarine_bricks
fill 190 171 313 194 172 313 minecraft:prismarine_bricks
fill 191 171 278 193 172 278 minecraft:prismarine_bricks
fill 191 171 280 193 172 280 minecraft:prismarine_bricks
fill 191 171 294 191 172 294 minecraft:prismarine_bricks
fill 191 171 298 191 172 298 minecraft:prismarine_bricks
fill 191 171 312 193 172 312 minecraft:prismarine_bricks
fill 191 171 314 193 172 314 minecraft:prismarine_bricks
fill 192 171 277 192 172 277 minecraft:prismarine_bricks
fill 192 171 281 192 172 281 minecraft:prismarine_bricks
fill 192 171 311 192 172 311 minecraft:prismarine_bricks
fill 192 171 315 192 172 315 minecraft:prismarine_bricks
fill 207 171 278 211 172 278 minecraft:prismarine_bricks
fill 207 171 314 211 172 314 minecraft:prismarine_bricks
fill 208 171 277 210 172 277 minecraft:prismarine_bricks
fill 208 171 279 210 172 279 minecraft:prismarine_bricks
fill 208 171 313 210 172 313 minecraft:prismarine_bricks
fill 208 171 315 210 172 315 minecraft:prismarine_bricks
fill 209 171 276 209 172 276 minecraft:prismarine_bricks
fill 209 171 280 209 172 280 minecraft:prismarine_bricks
fill 209 171 312 209 172 312 minecraft:prismarine_bricks
fill 212 171 275 212 217 275 minecraft:prismarine_bricks
setblock 213 171 275 minecraft:sea_lantern
fill 214 171 275 214 215 275 minecraft:prismarine_bricks
setblock 221 171 312 minecraft:iron_block
fill 224 171 279 228 172 279 minecraft:prismarine_bricks
fill 225 171 278 227 172 278 minecraft:prismarine_bricks
fill 225 171 280 227 172 280 minecraft:prismarine_bricks
fill 225 171 312 227 172 314 minecraft:prismarine_bricks
fill 226 171 277 226 172 277 minecraft:prismarine_bricks
fill 226 171 281 226 172 281 minecraft:prismarine_bricks
fill 226 171 295 228 172 297 minecraft:prismarine_bricks
fill 226 171 315 226 172 315 minecraft:prismarine_bricks
fill 227 171 294 227 172 294 minecraft:prismarine_bricks
fill 228 171 313 228 172 313 minecraft:prismarine_bricks
fill 188 172 281 188 185 281 minecraft:prismarine_bricks
fill 188 172 282 188 172 283 minecraft:sea_lantern
fill 188 172 284 188 185 284 minecraft:prismarine_bricks
fill 188 172 293 188 185 293 minecraft:prismarine_bricks
fill 188 172 294 188 172 295 minecraft:sea_lantern
fill 188 172 296 188 185 296 minecraft:prismarine_bricks
fill 188 172 305 188 185 305 minecraft:prismarine_bricks
fill 188 172 306 188 172 307 minecraft:sea_lantern
fill 188 172 308 188 185 308 minecraft:prismarine_bricks
fill 188 172 317 188 185 317 minecraft:prismarine_bricks
fill 189 172 308 195 172 308 minecraft:dark_prismarine
fill 189 172 317 190 172 317 minecraft:sea_lantern
fill 191 172 306 195 173 307 minecraft:dark_prismarine
fill 191 172 309 195 173 310 minecraft:dark_prismarine
fill 191 172 317 191 185 317 minecraft:prismarine_bricks
fill 195 172 275 195 185 275 minecraft:prismarine_bricks
fill 196 172 275 197 172 275 minecraft:sea_lantern
fill 198 172 275 198 185 275 minecraft:prismarine_bricks
fill 200 172 317 200 185 317 minecraft:prismarine_bricks
fill 201 172 317 202 172 317 minecraft:sea_lantern
fill 203 172 317 203 185 317 minecraft:prismarine_bricks
fill 207 172 275 207 185 275 minecraft:prismarine_bricks
fill 208 172 275 209 172 275 minecraft:sea_lantern
fill 210 172 275 210 185 275 minecraft:prismarine_bricks
fill 212 172 317 212 185 317 minecraft:prismarine_bricks
fill 213 172 275 213 217 275 minecraft:prismarine_bricks
fill 213 172 317 214 172 317 minecraft:sea_lantern
fill 215 172 317 215 184 317 minecraft:prismarine_bricks
fill 219 172 275 219 185 275 minecraft:prismarine_bricks
fill 220 172 275 221 172 275 minecraft:sea_lantern
fill 222 172 275 222 185 275 minecraft:prismarine_bricks
fill 224 172 317 224 185 317 minecraft:prismarine_bricks
fill 225 172 317 227 172 317 minecraft:sea_lantern
fill 228 172 299 228 173 299 minecraft:prismarine_bricks
fill 228 172 309 228 173 309 minecraft:prismarine_bricks
fill 230 172 276 230 185 276 minecraft:prismarine_bricks
fill 230 172 277 230 172 278 minecraft:sea_lantern
fill 230 172 279 230 185 279 minecraft:prismarine_bricks
fill 230 172 288 230 185 288 minecraft:prismarine_bricks
fill 230 172 289 230 172 290 minecraft:sea_lantern
fill 230 172 291 230 185 291 minecraft:prismarine_bricks
fill 230 172 300 230 185 300 minecraft:prismarine_bricks
fill 230 172 301 230 172 302 minecraft:sea_lantern
fill 230 172 303 230 185 303 minecraft:prismarine_bricks
fill 230 172 312 230 185 312 minecraft:prismarine_bricks
fill 230 172 313 230 172 314 minecraft:sea_lantern
fill 230 172 315 230 185 315 minecraft:prismarine_bricks
fill 188 173 282 188 185 283 minecraft:prismarine_bricks
fill 188 173 294 188 185 295 minecraft:prismarine_bricks
fill 188 173 306 188 185 307 minecraft:prismarine_bricks
fill 189 173 317 190 185 317 minecraft:prismarine_bricks
fill 190 173 295 192 200 297 minecraft:quartz_pillar
fill 191 173 278 193 200 280 minecraft:quartz_pillar
fill 191 173 308 195 173 308 minecraft:dark_prismarine
fill 191 173 312 193 200 314 minecraft:quartz_pillar
fill 196 173 275 197 185 275 minecraft:prismarine_bricks
fill 201 173 317 202 185 317 minecraft:prismarine_bricks
fill 208 173 275 209 185 275 minecraft:prismarine_bricks
fill 208 173 277 210 200 279 minecraft:quartz_pillar
fill 208 173 313 210 200 315 minecraft:quartz_pillar
fill 213 173 317 214 185 317 minecraft:prismarine_bricks
fill 220 173 275 221 185 275 minecraft:prismarine_bricks
fill 225 173 278 227 200 280 minecraft:quartz_pillar
fill 225 173 312 227 200 314 minecraft:quartz_pillar
fill 225 173 317 226 185 317 minecraft:prismarine_bricks
fill 226 173 295 228 200 297 minecraft:quartz_pillar
setblock 227 173 317 minecraft:sea_lantern
fill 229 173 301 229 173 305 minecraft:prismarine_bricks
fill 230 173 277 230 185 278 minecraft:prismarine_bricks
fill 230 173 289 230 185 290 minecraft:prismarine_bricks
fill 230 173 301 230 185 302 minecraft:prismarine_bricks
fill 230 173 313 230 185 314 minecraft:prismarine_bricks
setblock 191 174 286 minecraft:light[level=15]
setblock 191 174 294 minecraft:light[level=15]
setblock 191 174 302 minecraft:light[level=15]
setblock 191 174 310 minecraft:light[level=15]
fill 192 174 307 194 175 309 minecraft:prismarine_bricks
setblock 199 174 278 minecraft:light[level=15]
setblock 199 174 286 minecraft:light[level=15]
setblock 199 174 294 minecraft:light[level=15]
setblock 199 174 302 minecraft:light[level=15]
setblock 199 174 310 minecraft:light[level=15]
setblock 207 174 278 minecraft:light[level=15]
setblock 207 174 286 minecraft:light[level=15]
setblock 207 174 294 minecraft:light[level=15]
setblock 207 174 302 minecraft:light[level=15]
setblock 207 174 310 minecraft:light[level=15]
setblock 215 174 278 minecraft:light[level=15]
setblock 215 174 286 minecraft:light[level=15]
setblock 215 174 294 minecraft:light[level=15]
setblock 215 174 302 minecraft:light[level=15]
setblock 215 174 310 minecraft:light[level=15]
setblock 223 174 278 minecraft:light[level=15]
setblock 223 174 286 minecraft:light[level=15]
setblock 223 174 294 minecraft:light[level=15]
fill 227 174 317 227 181 317 minecraft:prismarine_bricks
fill 229 174 302 229 174 305 minecraft:prismarine_bricks
setblock 191 176 285 minecraft:light[level=12]
setblock 191 176 292 minecraft:light[level=12]
setblock 191 176 299 minecraft:light[level=12]
setblock 191 176 306 minecraft:light[level=12]
fill 192 176 308 194 178 308 minecraft:prismarine_bricks
fill 193 176 307 193 178 307 minecraft:prismarine_bricks
fill 193 176 309 193 178 309 minecraft:prismarine_bricks
setblock 198 176 278 minecraft:light[level=12]
setblock 198 176 285 minecraft:light[level=12]
setblock 198 176 292 minecraft:light[level=12]
setblock 198 176 299 minecraft:light[level=12]
setblock 198 176 306 minecraft:light[level=12]
setblock 198 176 313 minecraft:light[level=12]
setblock 205 176 278 minecraft:light[level=12]
setblock 205 176 285 minecraft:light[level=12]
setblock 205 176 292 minecraft:light[level=12]
setblock 205 176 299 minecraft:light[level=12]
setblock 205 176 306 minecraft:light[level=12]
setblock 205 176 313 minecraft:light[level=12]
setblock 212 176 278 minecraft:light[level=12]
setblock 212 176 285 minecraft:light[level=12]
setblock 212 176 292 minecraft:light[level=12]
setblock 212 176 299 minecraft:light[level=12]
setblock 212 176 306 minecraft:light[level=12]
setblock 212 176 313 minecraft:light[level=12]
setblock 219 176 278 minecraft:light[level=12]
setblock 219 176 285 minecraft:light[level=12]
setblock 219 176 292 minecraft:light[level=12]
setblock 219 176 299 minecraft:light[level=12]
setblock 219 176 306 minecraft:light[level=12]
setblock 219 176 313 minecraft:light[level=12]
setblock 226 176 285 minecraft:light[level=12]
setblock 226 176 292 minecraft:light[level=12]
setblock 226 176 299 minecraft:light[level=12]
fill 188 177 285 188 186 288 minecraft:prismarine_bricks
setblock 188 177 289 minecraft:sea_lantern
fill 190 177 288 195 177 288 minecraft:dark_prismarine
fill 191 177 286 195 178 287 minecraft:dark_prismarine
fill 191 177 289 195 178 290 minecraft:dark_prismarine
fill 202 177 312 202 190 312 minecraft:iron_block
fill 223 177 311 223 177 313 minecraft:dark_prismarine
fill 224 177 310 226 177 310 minecraft:dark_prismarine
setblock 224 177 314 minecraft:dark_prismarine
setblock 227 177 311 minecraft:dark_prismarine
fill 188 178 289 188 217 289 minecraft:prismarine_bricks
fill 191 178 288 195 178 288 minecraft:dark_prismarine
setblock 188 179 292 minecraft:sea_lantern
fill 192 179 287 194 180 289 minecraft:prismarine_bricks
fill 193 179 308 193 183 308 minecraft:prismarine_bricks
fill 199 179 275 199 213 275 minecraft:prismarine_bricks
setblock 200 179 275 minecraft:sea_lantern
fill 188 180 292 188 217 292 minecraft:prismarine_bricks
fill 190 180 285 190 185 287 minecraft:prismarine_bricks
fill 190 180 298 190 185 299 minecraft:prismarine_bricks
fill 190 180 309 190 185 311 minecraft:prismarine_bricks
fill 194 180 304 194 190 304 minecraft:green_terracotta
fill 196 180 315 198 185 315 minecraft:prismarine_bricks
fill 200 180 275 200 215 275 minecraft:prismarine_bricks
fill 200 180 277 202 185 277 minecraft:prismarine_bricks
fill 202 180 275 202 217 275 minecraft:prismarine_bricks
setblock 203 180 275 minecraft:sea_lantern
fill 204 180 275 204 217 275 minecraft:prismarine_bricks
fill 212 180 277 214 185 277 minecraft:prismarine_bricks
fill 220 180 315 222 185 315 minecraft:prismarine_bricks
fill 224 180 277 226 185 277 minecraft:prismarine_bricks
fill 228 180 285 228 185 287 minecraft:prismarine_bricks
fill 228 180 298 228 185 299 minecraft:prismarine_bricks
fill 228 180 309 228 185 311 minecraft:prismarine_bricks
setblock 188 181 276 minecraft:sea_lantern
fill 192 181 288 194 183 288 minecraft:prismarine_bricks
fill 193 181 287 193 183 287 minecraft:prismarine_bricks
fill 193 181 289 193 183 289 minecraft:prismarine_bricks
fill 202 181 287 203 182 287 minecraft:light_blue_stained_glass
fill 203 181 275 203 201 275 minecraft:prismarine_bricks
fill 188 182 276 188 217 276 minecraft:prismarine_bricks
setblock 191 182 285 minecraft:light[level=12]
setblock 191 182 286 minecraft:light[level=15]
setblock 191 182 292 minecraft:light[level=12]
setblock 191 182 294 minecraft:light[level=15]
setblock 191 182 299 minecraft:light[level=12]
setblock 191 182 302 minecraft:light[level=15]
setblock 191 182 306 minecraft:light[level=12]
setblock 191 182 310 minecraft:light[level=15]
setblock 198 182 278 minecraft:light[level=12]
setblock 198 182 285 minecraft:light[level=12]
setblock 198 182 292 minecraft:light[level=12]
setblock 198 182 299 minecraft:light[level=12]
setblock 198 182 306 minecraft:light[level=12]
setblock 198 182 313 minecraft:light[level=12]
setblock 199 182 278 minecraft:light[level=15]
setblock 199 182 286 minecraft:light[level=15]
setblock 199 182 294 minecraft:light[level=15]
setblock 199 182 302 minecraft:light[level=15]
setblock 199 182 310 minecraft:light[level=15]
setblock 205 182 278 minecraft:light[level=12]
setblock 205 182 285 minecraft:light[level=12]
setblock 205 182 292 minecraft:light[level=12]
setblock 205 182 299 minecraft:light[level=12]
setblock 205 182 306 minecraft:light[level=12]
setblock 205 182 313 minecraft:light[level=12]
setblock 207 182 278 minecraft:light[level=15]
setblock 207 182 286 minecraft:light[level=15]
setblock 207 182 294 minecraft:light[level=15]
setblock 207 182 302 minecraft:light[level=15]
setblock 207 182 310 minecraft:light[level=15]
setblock 212 182 278 minecraft:light[level=12]
setblock 212 182 285 minecraft:light[level=12]
setblock 212 182 292 minecraft:light[level=12]
setblock 212 182 299 minecraft:light[level=12]
setblock 212 182 306 minecraft:light[level=12]
setblock 212 182 313 minecraft:light[level=12]
setblock 215 182 278 minecraft:light[level=15]
setblock 215 182 286 minecraft:light[level=15]
setblock 215 182 294 minecraft:light[level=15]
setblock 215 182 302 minecraft:light[level=15]
setblock 215 182 310 minecraft:light[level=15]
setblock 219 182 278 minecraft:light[level=12]
setblock 219 182 285 minecraft:light[level=12]
setblock 219 182 292 minecraft:light[level=12]
setblock 219 182 299 minecraft:light[level=12]
setblock 219 182 306 minecraft:light[level=12]
setblock 219 182 313 minecraft:light[level=12]
setblock 223 182 278 minecraft:light[level=15]
setblock 223 182 286 minecraft:light[level=15]
setblock 223 182 294 minecraft:light[level=15]
setblock 223 182 302 minecraft:light[level=15]
setblock 223 182 310 minecraft:light[level=15]
setblock 226 182 285 minecraft:light[level=12]
setblock 226 182 292 minecraft:light[level=12]
setblock 226 182 299 minecraft:light[level=12]
setblock 226 182 306 minecraft:light[level=12]
setblock 227 182 317 minecraft:sea_lantern
setblock 230 182 305 minecraft:sea_lantern
fill 230 182 306 230 218 306 minecraft:prismarine_bricks
fill 220 183 281 220 184 282 minecraft:white_stained_glass
fill 227 183 317 227 185 317 minecraft:prismarine_bricks
fill 230 183 305 230 217 305 minecraft:prismarine_bricks
fill 193 184 288 193 188 288 minecraft:prismarine_bricks
setblock 193 184 308 minecraft:sea_lantern
fill 189 185 279 189 185 284 minecraft:dark_prismarine
fill 189 185 291 189 185 296 minecraft:dark_prismarine
fill 189 185 303 189 185 308 minecraft:dark_prismarine
fill 189 185 315 189 185 316 minecraft:dark_prismarine
fill 190 185 316 193 185 316 minecraft:dark_prismarine
fill 193 185 276 198 185 276 minecraft:dark_prismarine
fill 200 185 316 205 185 316 minecraft:dark_prismarine
fill 205 185 276 210 185 276 minecraft:dark_prismarine
fill 212 185 316 217 185 316 minecraft:dark_prismarine
fill 215 185 317 215 191 317 minecraft:sea_lantern
fill 217 185 276 222 185 276 minecraft:dark_prismarine
fill 223 185 311 223 185 313 minecraft:dark_prismarine
fill 224 185 310 226 185 310 minecraft:dark_prismarine
setblock 224 185 314 minecraft:dark_prismarine
fill 224 185 316 229 185 316 minecraft:dark_prismarine
setblock 227 185 311 minecraft:dark_prismarine
fill 229 185 276 229 185 281 minecraft:dark_prismarine
fill 229 185 288 229 185 293 minecraft:dark_prismarine
fill 229 185 300 229 185 305 minecraft:dark_prismarine
fill 229 185 312 229 185 315 minecraft:dark_prismarine
fill 188 186 281 188 191 284 minecraft:sea_lantern
fill 188 186 293 188 191 296 minecraft:sea_lantern
fill 188 186 305 188 191 308 minecraft:sea_lantern
fill 188 186 317 191 191 317 minecraft:sea_lantern
fill 195 186 275 198 191 275 minecraft:sea_lantern
fill 200 186 317 203 191 317 minecraft:sea_lantern
fill 207 186 275 210 191 275 minecraft:sea_lantern
fill 208 186 276 210 187 276 minecraft:prismarine_bricks
fill 210 186 316 210 187 316 minecraft:prismarine_bricks
fill 212 186 317 214 191 317 minecraft:sea_lantern
fill 219 186 275 222 191 275 minecraft:sea_lantern
fill 224 186 317 227 191 317 minecraft:sea_lantern
fill 230 186 276 230 191 279 minecraft:sea_lantern
fill 230 186 288 230 191 291 minecraft:sea_lantern
fill 230 186 300 230 191 303 minecraft:sea_lantern
fill 230 186 312 230 191 315 minecraft:sea_lantern
fill 188 187 285 188 217 285 minecraft:prismarine_bricks
setblock 188 187 286 minecraft:sea_lantern
fill 188 187 287 188 217 288 minecraft:prismarine_bricks
setblock 189 187 275 minecraft:sea_lantern
fill 188 188 286 188 217 286 minecraft:prismarine_bricks
fill 189 188 275 189 217 275 minecraft:prismarine_bricks
setblock 191 188 285 minecraft:light[level=12]
setblock 191 188 292 minecraft:light[level=12]
setblock 191 188 299 minecraft:light[level=12]
setblock 191 188 306 minecraft:light[level=12]
setblock 198 188 278 minecraft:light[level=12]
setblock 198 188 285 minecraft:light[level=12]
setblock 198 188 292 minecraft:light[level=12]
setblock 198 188 299 minecraft:light[level=12]
setblock 198 188 306 minecraft:light[level=12]
setblock 198 188 313 minecraft:light[level=12]
setblock 205 188 278 minecraft:light[level=12]
setblock 205 188 285 minecraft:light[level=12]
setblock 205 188 292 minecraft:light[level=12]
setblock 205 188 299 minecraft:light[level=12]
setblock 205 188 306 minecraft:light[level=12]
setblock 205 188 313 minecraft:light[level=12]
setblock 209 188 276 minecraft:prismarine_bricks
fill 209 188 312 209 190 312 minecraft:prismarine_bricks
setblock 212 188 278 minecraft:light[level=12]
setblock 212 188 285 minecraft:light[level=12]
setblock 212 188 292 minecraft:light[level=12]
setblock 212 188 299 minecraft:light[level=12]
setblock 212 188 306 minecraft:light[level=12]
setblock 212 188 313 minecraft:light[level=12]
setblock 219 188 278 minecraft:light[level=12]
setblock 219 188 285 minecraft:light[level=12]
setblock 219 188 292 minecraft:light[level=12]
setblock 219 188 299 minecraft:light[level=12]
setblock 219 188 306 minecraft:light[level=12]
setblock 219 188 313 minecraft:light[level=12]
setblock 226 188 285 minecraft:light[level=12]
setblock 226 188 292 minecraft:light[level=12]
setblock 226 188 299 minecraft:light[level=12]
setblock 226 188 306 minecraft:light[level=12]
setblock 227 188 275 minecraft:sea_lantern
setblock 230 188 316 minecraft:sea_lantern
fill 230 188 317 230 213 317 minecraft:prismarine_bricks
setblock 193 189 288 minecraft:sea_lantern
fill 196 189 280 196 197 280 minecraft:iron_block
fill 197 189 293 198 190 293 minecraft:white_stained_glass
fill 208 189 280 210 190 280 minecraft:prismarine_bricks
fill 208 189 311 208 190 312 minecraft:prismarine_bricks
setblock 208 189 317 minecraft:sea_lantern
setblock 209 189 276 minecraft:gold_block
fill 209 189 311 210 190 311 minecraft:prismarine_bricks
fill 210 189 312 210 190 312 minecraft:prismarine_bricks
fill 227 189 275 227 217 275 minecraft:prismarine_bricks
setblock 230 189 307 minecraft:sea_lantern
fill 230 189 308 230 202 308 minecraft:prismarine_bricks
fill 230 189 316 230 217 316 minecraft:prismarine_bricks
setblock 191 190 286 minecraft:light[level=15]
setblock 191 190 294 minecraft:light[level=15]
setblock 191 190 302 minecraft:light[level=15]
setblock 191 190 310 minecraft:light[level=15]
fill 196 190 286 196 191 286 minecraft:white_stained_glass
fill 196 190 317 196 197 317 minecraft:prismarine_bricks
setblock 197 190 317 minecraft:sea_lantern
setblock 199 190 278 minecraft:light[level=15]
setblock 199 190 286 minecraft:light[level=15]
setblock 199 190 294 minecraft:light[level=15]
setblock 199 190 302 minecraft:light[level=15]
setblock 199 190 310 minecraft:light[level=15]
setblock 207 190 278 minecraft:light[level=15]
setblock 207 190 286 minecraft:light[level=15]
setblock 207 190 294 minecraft:light[level=15]
setblock 207 190 302 minecraft:light[level=15]
setblock 207 190 310 minecraft:light[level=15]
fill 208 190 281 210 191 281 minecraft:prismarine_bricks
fill 208 190 310 210 191 310 minecraft:prismarine_bricks
fill 208 190 317 208 219 317 minecraft:prismarine_bricks
fill 209 190 282 209 192 282 minecraft:prismarine_bricks
fill 209 190 309 209 192 309 minecraft:prismarine_bricks
setblock 215 190 278 minecraft:light[level=15]
setblock 215 190 286 minecraft:light[level=15]
setblock 215 190 294 minecraft:light[level=15]
setblock 215 190 302 minecraft:light[level=15]
setblock 215 190 310 minecraft:light[level=15]
setblock 223 190 278 minecraft:light[level=15]
setblock 223 190 286 minecraft:light[level=15]
setblock 223 190 294 minecraft:light[level=15]
setblock 223 190 302 minecraft:light[level=15]
setblock 223 190 310 minecraft:light[level=15]
fill 230 190 307 230 217 307 minecraft:prismarine_bricks
fill 230 190 309 230 191 309 minecraft:sea_lantern
fill 230 190 310 230 217 311 minecraft:prismarine_bricks
fill 197 191 317 197 217 317 minecraft:prismarine_bricks
fill 208 191 282 208 192 282 minecraft:prismarine_bricks
fill 208 191 309 208 192 309 minecraft:prismarine_bricks
setblock 209 191 280 minecraft:prismarine_bricks
fill 209 191 283 209 193 283 minecraft:prismarine_bricks
fill 209 191 308 209 193 308 minecraft:prismarine_bricks
setblock 209 191 311 minecraft:prismarine_bricks
setblock 209 191 312 minecraft:gold_block
fill 210 191 282 210 192 282 minecraft:prismarine_bricks
fill 210 191 309 210 192 309 minecraft:prismarine_bricks
fill 219 191 300 221 192 301 minecraft:white_stained_glass
fill 188 192 281 188 205 281 minecraft:prismarine_bricks
fill 188 192 282 188 192 283 minecraft:sea_lantern
fill 188 192 284 188 205 284 minecraft:prismarine_bricks
fill 188 192 293 188 205 293 minecraft:prismarine_bricks
fill 188 192 294 188 192 295 minecraft:sea_lantern
fill 188 192 296 188 205 296 minecraft:prismarine_bricks
fill 188 192 305 188 205 305 minecraft:prismarine_bricks
fill 188 192 306 188 192 307 minecraft:sea_lantern
fill 188 192 308 188 205 308 minecraft:prismarine_bricks
fill 188 192 317 188 205 317 minecraft:prismarine_bricks
fill 189 192 317 190 192 317 minecraft:sea_lantern
fill 191 192 317 191 205 317 minecraft:prismarine_bricks
fill 195 192 275 195 205 275 minecraft:prismarine_bricks
fill 196 192 275 197 192 275 minecraft:sea_lantern
fill 198 192 275 198 205 275 minecraft:prismarine_bricks
fill 200 192 317 200 205 317 minecraft:prismarine_bricks
fill 201 192 317 202 192 317 minecraft:sea_lantern
fill 203 192 317 203 205 317 minecraft:prismarine_bricks
fill 207 192 275 207 205 275 minecraft:prismarine_bricks
fill 208 192 275 209 192 275 minecraft:sea_lantern
fill 208 192 283 208 192 284 minecraft:prismarine_bricks
fill 208 192 307 208 192 308 minecraft:prismarine_bricks
fill 209 192 280 209 192 281 minecraft:gold_block
fill 209 192 284 209 194 285 minecraft:prismarine_bricks
fill 209 192 306 209 194 307 minecraft:prismarine_bricks
setblock 209 192 310 minecraft:prismarine_bricks
setblock 209 192 311 minecraft:gold_block
fill 210 192 275 210 205 275 minecraft:prismarine_bricks
fill 210 192 283 210 192 284 minecraft:prismarine_bricks
fill 210 192 307 210 192 308 minecraft:prismarine_bricks
fill 212 192 317 212 205 317 minecraft:prismarine_bricks
fill 213 192 282 213 193 283 minecraft:white_stained_glass
fill 213 192 317 214 192 317 minecraft:sea_lantern
fill 215 192 317 215 205 317 minecraft:prismarine_bricks
fill 219 192 275 219 205 275 minecraft:prismarine_bricks
fill 220 192 275 221 192 275 minecraft:sea_lantern
fill 222 192 275 222 205 275 minecraft:prismarine_bricks
fill 224 192 317 224 205 317 minecraft:prismarine_bricks
fill 225 192 317 226 192 317 minecraft:sea_lantern
fill 227 192 317 227 205 317 minecraft:prismarine_bricks
fill 230 192 276 230 205 276 minecraft:prismarine_bricks
fill 230 192 277 230 192 278 minecraft:sea_lantern
fill 230 192 279 230 205 279 minecraft:prismarine_bricks
fill 230 192 288 230 205 288 minecraft:prismarine_bricks
fill 230 192 289 230 192 290 minecraft:sea_lantern
fill 230 192 291 230 205 291 minecraft:prismarine_bricks
fill 230 192 300 230 205 300 minecraft:prismarine_bricks
fill 230 192 301 230 192 302 minecraft:sea_lantern
fill 230 192 303 230 205 303 minecraft:prismarine_bricks
fill 230 192 309 230 213 309 minecraft:prismarine_bricks
fill 230 192 312 230 205 312 minecraft:prismarine_bricks
fill 230 192 313 230 192 314 minecraft:sea_lantern
fill 230 192 315 230 205 315 minecraft:prismarine_bricks
fill 188 193 282 188 204 283 minecraft:prismarine_bricks
fill 188 193 294 188 205 295 minecraft:prismarine_bricks
fill 188 193 306 188 205 307 minecraft:prismarine_bricks
fill 189 193 317 190 205 317 minecraft:prismarine_bricks
fill 196 193 275 197 205 275 minecraft:prismarine_bricks
fill 201 193 317 202 205 317 minecraft:prismarine_bricks
fill 208 193 275 209 205 275 minecraft:prismarine_bricks
fill 208 193 284 208 193 286 minecraft:prismarine_bricks
fill 208 193 305 208 193 307 minecraft:prismarine_bricks
setblock 209 193 282 minecraft:gold_block
fill 209 193 286 209 194 287 minecraft:prismarine_bricks
fill 209 193 304 209 195 305 minecraft:prismarine_bricks
setblock 209 193 309 minecraft:gold_block
fill 210 193 284 210 193 286 minecraft:prismarine_bricks
fill 210 193 305 210 193 307 minecraft:prismarine_bricks
fill 213 193 317 214 205 317 minecraft:prismarine_bricks
fill 220 193 275 221 205 275 minecraft:prismarine_bricks
fill 223 193 311 223 193 313 minecraft:dark_prismarine
fill 224 193 310 226 193 310 minecraft:dark_prismarine
setblock 224 193 314 minecraft:dark_prismarine
fill 225 193 317 226 205 317 minecraft:prismarine_bricks
setblock 227 193 311 minecraft:dark_prismarine
fill 230 193 277 230 205 278 minecraft:prismarine_bricks
fill 230 193 289 230 200 290 minecraft:prismarine_bricks
fill 230 193 301 230 205 302 minecraft:prismarine_bricks
fill 230 193 313 230 205 314 minecraft:prismarine_bricks
setblock 191 194 285 minecraft:light[level=12]
setblock 191 194 292 minecraft:light[level=12]
setblock 191 194 299 minecraft:light[level=12]
setblock 191 194 306 minecraft:light[level=12]
setblock 198 194 278 minecraft:light[level=12]
setblock 198 194 285 minecraft:light[level=12]
setblock 198 194 292 minecraft:light[level=12]
setblock 198 194 299 minecraft:light[level=12]
setblock 198 194 306 minecraft:light[level=12]
setblock 198 194 313 minecraft:light[level=12]
setblock 205 194 278 minecraft:light[level=12]
setblock 205 194 285 minecraft:light[level=12]
setblock 205 194 292 minecraft:light[level=12]
setblock 205 194 299 minecraft:light[level=12]
setblock 205 194 306 minecraft:light[level=12]
setblock 205 194 313 minecraft:light[level=12]
fill 208 194 285 208 194 288 minecraft:prismarine_bricks
fill 208 194 303 208 194 306 minecraft:prismarine_bricks
setblock 209 194 283 minecraft:gold_block
fill 209 194 288 209 196 289 minecraft:prismarine_bricks
fill 209 194 302 209 196 303 minecraft:prismarine_bricks
setblock 209 194 308 minecraft:gold_block
fill 210 194 285 210 194 288 minecraft:prismarine_bricks
fill 210 194 303 210 194 306 minecraft:prismarine_bricks
setblock 212 194 278 minecraft:light[level=12]
setblock 212 194 285 minecraft:light[level=12]
setblock 212 194 292 minecraft:light[level=12]
setblock 212 194 299 minecraft:light[level=12]
setblock 212 194 306 minecraft:light[level=12]
setblock 212 194 313 minecraft:light[level=12]
setblock 219 194 278 minecraft:light[level=12]
setblock 219 194 285 minecraft:light[level=12]
setblock 219 194 292 minecraft:light[level=12]
setblock 219 194 299 minecraft:light[level=12]
setblock 219 194 306 minecraft:light[level=12]
setblock 219 194 313 minecraft:light[level=12]
setblock 226 194 285 minecraft:light[level=12]
setblock 226 194 292 minecraft:light[level=12]
setblock 226 194 299 minecraft:light[level=12]
setblock 226 194 306 minecraft:light[level=12]
fill 208 195 287 208 195 290 minecraft:prismarine_bricks
fill 208 195 301 208 195 304 minecraft:prismarine_bricks
fill 209 195 285 209 195 286 minecraft:gold_block
fill 209 195 287 210 195 287 minecraft:prismarine_bricks
fill 209 195 290 209 196 294 minecraft:prismarine_bricks
fill 209 195 297 209 196 301 minecraft:prismarine_bricks
setblock 209 195 306 minecraft:gold_block
fill 210 195 288 210 195 290 minecraft:prismarine_bricks
fill 210 195 301 210 195 304 minecraft:prismarine_bricks
fill 208 196 290 208 196 301 minecraft:prismarine_bricks
fill 209 196 286 209 196 287 minecraft:gold_block
fill 209 196 295 210 197 296 minecraft:prismarine_bricks
fill 209 196 304 209 196 305 minecraft:gold_block
fill 210 196 290 210 196 294 minecraft:prismarine_bricks
fill 210 196 297 210 196 301 minecraft:prismarine_bricks
setblock 230 196 285 minecraft:sea_lantern
fill 230 196 286 230 217 286 minecraft:prismarine_bricks
setblock 188 197 310 minecraft:sea_lantern
fill 208 197 294 208 197 297 minecraft:prismarine_bricks
fill 209 197 289 209 197 290 minecraft:gold_block
fill 209 197 291 209 197 294 minecraft:prismarine_bricks
fill 209 197 297 209 197 300 minecraft:prismarine_bricks
fill 209 197 301 209 197 302 minecraft:gold_block
setblock 210 197 294 minecraft:prismarine_bricks
setblock 210 197 297 minecraft:prismarine_bricks
fill 230 197 285 230 213 285 minecraft:prismarine_bricks
fill 188 198 310 188 215 310 minecraft:prismarine_bricks
setblock 191 198 286 minecraft:light[level=15]
setblock 191 198 294 minecraft:light[level=15]
setblock 191 198 302 minecraft:light[level=15]
setblock 191 198 310 minecraft:light[level=15]
setblock 196 198 317 minecraft:sea_lantern
setblock 199 198 278 minecraft:light[level=15]
setblock 199 198 286 minecraft:light[level=15]
setblock 199 198 294 minecraft:light[level=15]
setblock 199 198 302 minecraft:light[level=15]
setblock 199 198 310 minecraft:light[level=15]
setblock 207 198 278 minecraft:light[level=15]
setblock 207 198 286 minecraft:light[level=15]
setblock 207 198 294 minecraft:light[level=15]
setblock 207 198 302 minecraft:light[level=15]
setblock 207 198 310 minecraft:light[level=15]
fill 209 198 291 209 198 300 minecraft:gold_block
setblock 215 198 278 minecraft:light[level=15]
setblock 215 198 286 minecraft:light[level=15]
setblock 215 198 294 minecraft:light[level=15]
setblock 215 198 302 minecraft:light[level=15]
setblock 215 198 310 minecraft:light[level=15]
setblock 223 198 278 minecraft:light[level=15]
setblock 223 198 286 minecraft:light[level=15]
setblock 223 198 294 minecraft:light[level=15]
setblock 223 198 302 minecraft:light[level=15]
setblock 223 198 310 minecraft:light[level=15]
fill 196 199 317 196 209 317 minecraft:prismarine_bricks
setblock 188 200 280 minecraft:sea_lantern
fill 190 200 285 190 205 287 minecraft:prismarine_bricks
fill 190 200 298 190 205 299 minecraft:prismarine_bricks
fill 190 200 309 190 205 311 minecraft:prismarine_bricks
setblock 191 200 285 minecraft:light[level=12]
setblock 191 200 292 minecraft:light[level=12]
setblock 191 200 299 minecraft:light[level=12]
setblock 191 200 306 minecraft:light[level=12]
fill 195 200 287 197 201 287 minecraft:white_stained_glass
fill 196 200 286 196 201 286 minecraft:white_stained_glass
fill 196 200 288 196 201 288 minecraft:white_stained_glass
fill 196 200 315 198 205 315 minecraft:prismarine_bricks
setblock 198 200 278 minecraft:light[level=12]
setblock 198 200 285 minecraft:light[level=12]
setblock 198 200 292 minecraft:light[level=12]
setblock 198 200 299 minecraft:light[level=12]
setblock 198 200 306 minecraft:light[level=12]
setblock 198 200 313 minecraft:light[level=12]
fill 200 200 277 202 205 277 minecraft:prismarine_bricks
setblock 205 200 278 minecraft:light[level=12]
setblock 205 200 285 minecraft:light[level=12]
setblock 205 200 292 minecraft:light[level=12]
setblock 205 200 299 minecraft:light[level=12]
setblock 205 200 306 minecraft:light[level=12]
setblock 205 200 313 minecraft:light[level=12]
fill 206 200 283 207 201 284 minecraft:light_blue_stained_glass
fill 212 200 277 214 205 277 minecraft:prismarine_bricks
setblock 212 200 278 minecraft:light[level=12]
setblock 212 200 285 minecraft:light[level=12]
setblock 212 200 292 minecraft:light[level=12]
setblock 212 200 299 minecraft:light[level=12]
setblock 212 200 306 minecraft:light[level=12]
setblock 212 200 313 minecraft:light[level=12]
setblock 219 200 278 minecraft:light[level=12]
setblock 219 200 285 minecraft:light[level=12]
setblock 219 200 292 minecraft:light[level=12]
setblock 219 200 299 minecraft:light[level=12]
setblock 219 200 306 minecraft:light[level=12]
setblock 219 200 313 minecraft:light[level=12]
fill 220 200 315 222 205 315 minecraft:prismarine_bricks
fill 224 200 277 226 205 277 minecraft:prismarine_bricks
setblock 226 200 285 minecraft:light[level=12]
setblock 226 200 292 minecraft:light[level=12]
setblock 226 200 299 minecraft:light[level=12]
setblock 226 200 306 minecraft:light[level=12]
fill 228 200 285 228 205 287 minecraft:prismarine_bricks
fill 228 200 298 228 205 299 minecraft:prismarine_bricks
fill 228 200 309 228 205 311 minecraft:prismarine_bricks
fill 188 201 280 188 217 280 minecraft:prismarine_bricks
fill 189 201 296 193 202 296 minecraft:prismarine_bricks
fill 190 201 279 194 202 279 minecraft:prismarine_bricks
fill 190 201 295 192 202 295 minecraft:prismarine_bricks
fill 190 201 297 192 202 297 minecraft:prismarine_bricks
fill 190 201 313 194 202 313 minecraft:prismarine_bricks
fill 191 201 278 193 202 278 minecraft:prismarine_bricks
fill 191 201 280 193 202 280 minecraft:prismarine_bricks
fill 191 201 294 191 202 294 minecraft:prismarine_bricks
fill 191 201 298 191 202 298 minecraft:prismarine_bricks
fill 191 201 312 193 202 312 minecraft:prismarine_bricks
fill 191 201 314 193 202 314 minecraft:prismarine_bricks
fill 192 201 277 192 202 277 minecraft:prismarine_bricks
fill 192 201 281 192 202 281 minecraft:prismarine_bricks
fill 192 201 311 192 202 311 minecraft:prismarine_bricks
fill 192 201 315 192 202 315 minecraft:prismarine_bricks
fill 207 201 278 211 202 278 minecraft:prismarine_bricks
fill 207 201 314 211 202 314 minecraft:prismarine_bricks
fill 208 201 277 210 202 277 minecraft:prismarine_bricks
fill 208 201 279 210 202 279 minecraft:prismarine_bricks
fill 208 201 313 210 202 313 minecraft:prismarine_bricks
fill 208 201 315 210 202 315 minecraft:prismarine_bricks
fill 209 201 276 209 202 276 minecraft:prismarine_bricks
fill 209 201 280 209 202 280 minecraft:prismarine_bricks
fill 209 201 312 209 202 312 minecraft:prismarine_bricks
fill 223 201 311 223 201 313 minecraft:dark_prismarine
fill 224 201 279 228 202 279 minecraft:prismarine_bricks
fill 224 201 310 226 201 310 minecraft:dark_prismarine
setblock 224 201 314 minecraft:dark_prismarine
fill 225 201 278 227 202 278 minecraft:prismarine_bricks
fill 225 201 280 227 202 280 minecraft:prismarine_bricks
fill 225 201 296 228 202 296 minecraft:prismarine_bricks
fill 225 201 312 227 202 314 minecraft:prismarine_bricks
fill 226 201 281 226 202 281 minecraft:prismarine_bricks
fill 226 201 295 228 202 295 minecraft:prismarine_bricks
fill 226 201 297 228 202 297 minecraft:prismarine_bricks
fill 226 201 315 226 202 315 minecraft:prismarine_bricks
fill 227 201 294 227 202 294 minecraft:prismarine_bricks
fill 227 201 298 227 202 298 minecraft:prismarine_bricks
setblock 227 201 311 minecraft:dark_prismarine
fill 228 201 313 228 202 313 minecraft:prismarine_bricks
setblock 230 201 289 minecraft:sea_lantern
fill 230 201 290 230 205 290 minecraft:prismarine_bricks
setblock 203 202 275 minecraft:sea_lantern
fill 224 202 286 224 203 286 minecraft:light_blue_stained_glass
fill 230 202 289 230 203 289 minecraft:prismarine_bricks
fill 190 203 295 192 213 297 minecraft:quartz_pillar
fill 191 203 278 193 230 280 minecraft:quartz_pillar
fill 191 203 312 193 230 314 minecraft:quartz_pillar
fill 203 203 275 203 217 275 minecraft:prismarine_bricks
fill 203 203 311 204 204 311 minecraft:white_stained_glass
fill 208 203 277 210 230 279 minecraft:quartz_pillar
fill 208 203 313 210 230 315 minecraft:quartz_pillar
fill 211 203 309 215 204 313 minecraft:dark_prismarine
fill 213 203 314 213 203 315 minecraft:dark_prismarine
fill 215 203 288 217 204 288 minecraft:white_stained_glass
fill 216 203 287 216 204 287 minecraft:white_stained_glass
fill 216 203 289 216 204 289 minecraft:white_stained_glass
fill 225 203 278 227 230 280 minecraft:quartz_pillar
fill 225 203 312 227 230 314 minecraft:quartz_pillar
fill 226 203 295 228 230 297 minecraft:quartz_pillar
setblock 230 203 287 minecraft:sea_lantern
setblock 230 203 295 minecraft:sea_lantern
setblock 230 203 308 minecraft:sea_lantern
fill 230 204 287 230 217 287 minecraft:prismarine_bricks
setblock 230 204 289 minecraft:sea_lantern
fill 230 204 295 230 217 295 minecraft:prismarine_bricks
fill 230 204 308 230 213 308 minecraft:prismarine_bricks
fill 188 205 282 188 206 282 minecraft:sea_lantern
setblock 188 205 283 minecraft:prismarine_bricks
fill 189 205 279 189 205 284 minecraft:dark_prismarine
fill 189 205 291 189 205 296 minecraft:dark_prismarine
fill 189 205 303 189 205 308 minecraft:dark_prismarine
fill 189 205 315 189 205 316 minecraft:dark_prismarine
fill 190 205 316 193 205 316 minecraft:dark_prismarine
fill 193 205 276 198 205 276 minecraft:dark_prismarine
fill 200 205 316 205 205 316 minecraft:dark_prismarine
fill 205 205 276 210 205 276 minecraft:dark_prismarine
fill 212 205 310 214 206 312 minecraft:prismarine_bricks
fill 212 205 316 217 205 316 minecraft:dark_prismarine
fill 217 205 276 222 205 276 minecraft:dark_prismarine
fill 223 205 312 223 206 312 minecraft:gold_block
fill 224 205 314 224 206 314 minecraft:gold_block
fill 224 205 316 229 205 316 minecraft:dark_prismarine
fill 225 205 310 226 206 310 minecraft:gold_block
fill 227 205 311 227 206 311 minecraft:gold_block
fill 229 205 276 229 205 281 minecraft:dark_prismarine
fill 229 205 288 229 205 293 minecraft:dark_prismarine
fill 229 205 300 229 205 305 minecraft:dark_prismarine
fill 229 205 312 229 205 315 minecraft:dark_prismarine
setblock 230 205 289 minecraft:prismarine_bricks
setblock 188 206 281 minecraft:sea_lantern
fill 188 206 283 188 206 284 minecraft:sea_lantern
fill 188 206 293 188 206 296 minecraft:sea_lantern
fill 188 206 305 188 206 308 minecraft:sea_lantern
fill 188 206 317 191 206 317 minecraft:sea_lantern
setblock 191 206 285 minecraft:light[level=12]
setblock 191 206 286 minecraft:light[level=15]
setblock 191 206 292 minecraft:light[level=12]
setblock 191 206 294 minecraft:light[level=15]
setblock 191 206 299 minecraft:light[level=12]
setblock 191 206 302 minecraft:light[level=15]
setblock 191 206 306 minecraft:light[level=12]
setblock 191 206 310 minecraft:light[level=15]
fill 195 206 275 198 206 275 minecraft:sea_lantern
setblock 198 206 278 minecraft:light[level=12]
setblock 198 206 285 minecraft:light[level=12]
setblock 198 206 292 minecraft:light[level=12]
setblock 198 206 299 minecraft:light[level=12]
setblock 198 206 306 minecraft:light[level=12]
setblock 198 206 313 minecraft:light[level=12]
setblock 199 206 278 minecraft:light[level=15]
setblock 199 206 286 minecraft:light[level=15]
setblock 199 206 294 minecraft:light[level=15]
setblock 199 206 302 minecraft:light[level=15]
setblock 199 206 310 minecraft:light[level=15]
fill 200 206 317 203 206 317 minecraft:sea_lantern
setblock 205 206 278 minecraft:light[level=12]
setblock 205 206 285 minecraft:light[level=12]
setblock 205 206 292 minecraft:light[level=12]
setblock 205 206 299 minecraft:light[level=12]
setblock 205 206 306 minecraft:light[level=12]
setblock 205 206 313 minecraft:light[level=12]
fill 207 206 275 210 206 275 minecraft:sea_lantern
setblock 207 206 278 minecraft:light[level=15]
setblock 207 206 286 minecraft:light[level=15]
setblock 207 206 294 minecraft:light[level=15]
setblock 207 206 302 minecraft:light[level=15]
setblock 207 206 310 minecraft:light[level=15]
setblock 212 206 278 minecraft:light[level=12]
setblock 212 206 285 minecraft:light[level=12]
setblock 212 206 292 minecraft:light[level=12]
setblock 212 206 299 minecraft:light[level=12]
setblock 212 206 306 minecraft:light[level=12]
setblock 212 206 313 minecraft:light[level=12]
fill 212 206 317 215 206 317 minecraft:sea_lantern
setblock 215 206 278 minecraft:light[level=15]
setblock 215 206 286 minecraft:light[level=15]
setblock 215 206 294 minecraft:light[level=15]
setblock 215 206 302 minecraft:light[level=15]
setblock 215 206 310 minecraft:light[level=15]
setblock 216 206 275 minecraft:sea_lantern
fill 219 206 275 222 206 275 minecraft:sea_lantern
setblock 219 206 278 minecraft:light[level=12]
setblock 219 206 285 minecraft:light[level=12]
setblock 219 206 292 minecraft:light[level=12]
setblock 219 206 299 minecraft:light[level=12]
setblock 219 206 306 minecraft:light[level=12]
setblock 219 206 313 minecraft:light[level=12]
setblock 223 206 278 minecraft:light[level=15]
setblock 223 206 286 minecraft:light[level=15]
setblock 223 206 294 minecraft:light[level=15]
setblock 223 206 302 minecraft:light[level=15]
setblock 223 206 310 minecraft:light[level=15]
fill 224 206 317 227 206 317 minecraft:sea_lantern
setblock 226 206 285 minecraft:light[level=12]
setblock 226 206 292 minecraft:light[level=12]
setblock 226 206 299 minecraft:light[level=12]
setblock 226 206 306 minecraft:light[level=12]
fill 230 206 276 230 206 279 minecraft:sea_lantern
fill 230 206 288 230 206 291 minecraft:sea_lantern
fill 230 206 300 230 206 303 minecraft:sea_lantern
fill 230 206 312 230 206 315 minecraft:sea_lantern
fill 188 207 281 188 215 284 minecraft:prismarine_bricks
fill 188 207 293 188 217 296 minecraft:prismarine_bricks
fill 188 207 305 188 213 308 minecraft:prismarine_bricks
fill 188 207 317 191 214 317 minecraft:prismarine_bricks
fill 195 207 275 198 217 275 minecraft:prismarine_bricks
fill 200 207 317 203 215 317 minecraft:prismarine_bricks
fill 207 207 275 210 209 275 minecraft:prismarine_bricks
fill 207 207 317 207 217 317 minecraft:prismarine_bricks
fill 212 207 317 215 213 317 minecraft:prismarine_bricks
fill 216 207 275 216 214 275 minecraft:prismarine_bricks
fill 219 207 275 222 213 275 minecraft:prismarine_bricks
fill 224 207 317 227 215 317 minecraft:prismarine_bricks
fill 230 207 276 230 213 279 minecraft:prismarine_bricks
setblock 230 207 282 minecraft:sea_lantern
fill 230 207 288 230 217 291 minecraft:prismarine_bricks
fill 230 207 300 230 215 303 minecraft:prismarine_bricks
fill 230 207 312 230 208 315 minecraft:prismarine_bricks
fill 230 208 282 230 217 282 minecraft:prismarine_bricks
fill 194 209 299 195 210 299 minecraft:white_stained_glass
setblock 218 209 275 minecraft:sea_lantern
fill 230 209 312 230 215 312 minecraft:prismarine_bricks
setblock 230 209 313 minecraft:sea_lantern
fill 230 209 314 230 217 315 minecraft:prismarine_bricks
setblock 196 210 317 minecraft:sea_lantern
fill 207 210 275 208 215 275 minecraft:prismarine_bricks
setblock 209 210 275 minecraft:sea_lantern
fill 210 210 275 210 218 275 minecraft:prismarine_bricks
fill 218 210 275 218 217 275 minecraft:prismarine_bricks
fill 230 210 313 230 215 313 minecraft:prismarine_bricks
fill 196 211 317 196 213 317 minecraft:prismarine_bricks
fill 209 211 275 209 217 275 minecraft:prismarine_bricks
setblock 230 211 294 minecraft:sea_lantern
setblock 191 212 285 minecraft:light[level=12]
setblock 191 212 292 minecraft:light[level=12]
setblock 191 212 299 minecraft:light[level=12]
setblock 191 212 306 minecraft:light[level=12]
fill 196 212 295 196 213 299 minecraft:gold_block
fill 197 212 293 197 213 294 minecraft:gold_block
fill 197 212 295 197 213 295 minecraft:prismarine
fill 197 212 296 197 213 296 minecraft:dark_prismarine
fill 197 212 297 197 213 298 minecraft:prismarine
fill 197 212 299 197 213 299 minecraft:dark_prismarine
fill 197 212 300 197 213 301 minecraft:gold_block
setblock 198 212 278 minecraft:light[level=12]
setblock 198 212 285 minecraft:light[level=12]
fill 198 212 292 198 213 292 minecraft:gold_block
fill 198 212 293 198 213 294 minecraft:prismarine
fill 198 212 295 198 213 295 minecraft:dark_prismarine
fill 198 212 296 198 213 297 minecraft:prismarine
fill 198 212 298 198 213 298 minecraft:dark_prismarine
fill 198 212 299 198 213 300 minecraft:prismarine
fill 198 212 301 198 213 301 minecraft:dark_prismarine
fill 198 212 302 198 213 302 minecraft:gold_block
setblock 198 212 306 minecraft:light[level=12]
setblock 198 212 313 minecraft:light[level=12]
fill 199 212 291 199 213 291 minecraft:gold_block
fill 199 212 292 199 213 293 minecraft:prismarine
fill 199 212 294 199 213 294 minecraft:dark_prismarine
fill 199 212 295 199 213 296 minecraft:prismarine
fill 199 212 297 199 213 297 minecraft:dark_prismarine
fill 199 212 298 199 213 299 minecraft:prismarine
fill 199 212 300 199 213 300 minecraft:dark_prismarine
fill 199 212 301 199 213 302 minecraft:prismarine
fill 199 212 303 199 213 303 minecraft:gold_block
fill 200 212 290 201 213 290 minecraft:gold_block
fill 200 212 291 200 213 292 minecraft:prismarine
fill 200 212 293 200 213 293 minecraft:dark_prismarine
fill 200 212 294 200 213 295 minecraft:prismarine
setblock 200 212 296 minecraft:dark_prismarine
fill 200 212 297 200 212 298 minecraft:prismarine
fill 200 212 299 200 213 299 minecraft:dark_prismarine
fill 200 212 300 200 213 301 minecraft:prismarine
fill 200 212 302 200 213 302 minecraft:dark_prismarine
fill 200 212 303 201 213 303 minecraft:prismarine
fill 200 212 304 201 213 304 minecraft:gold_block
fill 201 212 291 201 213 291 minecraft:prismarine
fill 201 212 292 201 213 292 minecraft:dark_prismarine
fill 201 212 293 201 212 294 minecraft:prismarine
setblock 201 212 295 minecraft:dark_prismarine
setblock 201 212 296 minecraft:prismarine
setblock 201 212 298 minecraft:dark_prismarine
fill 201 212 299 201 212 300 minecraft:prismarine
fill 201 212 301 201 213 301 minecraft:dark_prismarine
fill 201 212 302 202 213 302 minecraft:prismarine
fill 202 212 289 206 213 289 minecraft:gold_block
fill 202 212 290 202 213 290 minecraft:prismarine
fill 202 212 291 202 213 291 minecraft:dark_prismarine
fill 202 212 292 202 213 293 minecraft:prismarine
setblock 202 212 294 minecraft:dark_prismarine
setblock 202 212 300 minecraft:dark_prismarine
fill 202 212 301 203 212 301 minecraft:prismarine
fill 202 212 303 202 213 303 minecraft:dark_prismarine
fill 202 212 304 203 213 304 minecraft:prismarine
fill 202 212 305 206 213 305 minecraft:gold_block
fill 203 212 290 203 213 290 minecraft:dark_prismarine
fill 203 212 291 203 213 292 minecraft:prismarine
setblock 203 212 293 minecraft:dark_prismarine
setblock 203 212 294 minecraft:prismarine
setblock 203 212 300 minecraft:prismarine
fill 203 212 302 203 213 302 minecraft:dark_prismarine
fill 203 212 303 204 213 303 minecraft:prismarine
fill 204 212 290 204 213 291 minecraft:prismarine
fill 204 212 292 204 213 292 minecraft:dark_prismarine
fill 204 212 293 205 212 293 minecraft:prismarine
setblock 204 212 301 minecraft:dark_prismarine
fill 204 212 302 205 213 302 minecraft:prismarine
fill 204 212 304 204 213 304 minecraft:dark_prismarine
setblock 205 212 278 minecraft:light[level=12]
setblock 205 212 285 minecraft:light[level=12]
fill 205 212 290 205 213 290 minecraft:prismarine
fill 205 212 291 205 213 291 minecraft:dark_prismarine
fill 205 212 292 206 213 292 minecraft:prismarine
setblock 205 212 294 minecraft:dark_prismarine
setblock 205 212 300 minecraft:dark_prismarine
fill 205 212 301 206 212 301 minecraft:prismarine
fill 205 212 303 205 213 303 minecraft:dark_prismarine
fill 205 212 304 206 213 304 minecraft:prismarine
setblock 205 212 306 minecraft:light[level=12]
setblock 205 212 313 minecraft:light[level=12]
fill 206 212 290 206 213 290 minecraft:dark_prismarine
fill 206 212 291 207 213 291 minecraft:prismarine
fill 206 212 293 206 213 293 minecraft:dark_prismarine
fill 206 212 294 207 212 294 minecraft:prismarine
fill 206 212 300 207 212 300 minecraft:prismarine
fill 206 212 302 206 213 302 minecraft:dark_prismarine
fill 206 212 303 207 213 303 minecraft:prismarine
fill 207 212 290 208 213 290 minecraft:gold_block
fill 207 212 292 207 213 292 minecraft:dark_prismarine
fill 207 212 293 208 213 293 minecraft:prismarine
setblock 207 212 295 minecraft:dark_prismarine
schedule function dropper:buildpart/64_3 1t
