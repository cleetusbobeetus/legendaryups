setblock 411 114 631 minecraft:light[level=12]
setblock 411 114 639 minecraft:light[level=12]
fill 411 114 645 413 114 645 minecraft:polished_blackstone
fill 413 114 604 414 115 604 minecraft:red_concrete
fill 413 114 605 415 114 605 minecraft:polished_blackstone
fill 415 114 645 417 114 645 minecraft:polished_blackstone
fill 415 114 646 415 115 646 minecraft:purple_terracotta
fill 416 114 646 417 114 646 minecraft:red_concrete
fill 417 114 605 417 114 607 minecraft:polished_blackstone
fill 417 114 609 417 114 611 minecraft:polished_blackstone
fill 417 114 613 417 114 615 minecraft:polished_blackstone
fill 417 114 617 417 114 619 minecraft:polished_blackstone
fill 417 114 621 417 114 623 minecraft:polished_blackstone
fill 417 114 625 417 114 627 minecraft:polished_blackstone
fill 417 114 629 417 114 631 minecraft:polished_blackstone
fill 417 114 633 417 114 635 minecraft:polished_blackstone
fill 417 114 637 417 114 639 minecraft:polished_blackstone
fill 417 114 641 417 114 643 minecraft:polished_blackstone
setblock 418 114 608 minecraft:red_concrete
fill 418 114 609 418 119 610 minecraft:purple_terracotta
fill 418 114 611 418 115 612 minecraft:red_concrete
fill 418 114 617 418 119 618 minecraft:purple_terracotta
fill 418 114 619 418 114 620 minecraft:red_concrete
fill 418 114 621 418 119 621 minecraft:purple_terracotta
fill 418 114 629 418 119 630 minecraft:purple_terracotta
fill 418 114 631 418 115 632 minecraft:red_concrete
fill 418 114 633 418 115 636 minecraft:purple_terracotta
fill 418 114 638 418 119 638 minecraft:purple_terracotta
setblock 418 114 640 minecraft:red_concrete
fill 418 114 641 418 119 642 minecraft:purple_terracotta
fill 418 114 643 418 115 643 minecraft:red_concrete
setblock 418 114 644 minecraft:purple_terracotta
fill 418 114 646 418 119 646 minecraft:purple_terracotta
setblock 376 115 610 minecraft:red_concrete
fill 376 115 614 376 118 615 minecraft:purple_terracotta
setblock 376 115 631 minecraft:red_concrete
setblock 376 115 634 minecraft:red_concrete
fill 376 115 635 376 118 635 minecraft:purple_terracotta
setblock 376 115 641 minecraft:purple_terracotta
setblock 376 115 642 minecraft:red_concrete
fill 376 115 646 376 118 646 minecraft:purple_terracotta
fill 380 115 646 380 117 646 minecraft:purple_terracotta
fill 381 115 604 381 118 604 minecraft:purple_terracotta
setblock 381 115 646 minecraft:red_concrete
setblock 382 115 604 minecraft:red_concrete
fill 382 115 646 383 115 646 minecraft:purple_terracotta
setblock 384 115 604 minecraft:purple_terracotta
setblock 385 115 604 minecraft:red_concrete
setblock 392 115 646 minecraft:red_concrete
setblock 396 115 642 minecraft:crying_obsidian
setblock 396 115 646 minecraft:red_concrete
fill 397 115 643 397 115 644 minecraft:crying_obsidian
fill 397 115 646 397 118 646 minecraft:purple_terracotta
fill 398 115 644 398 116 644 minecraft:crying_obsidian
fill 401 115 604 402 118 604 minecraft:purple_terracotta
fill 403 115 637 403 115 638 minecraft:crying_obsidian
setblock 406 115 604 minecraft:red_concrete
fill 408 115 646 408 117 646 minecraft:purple_terracotta
setblock 413 115 646 minecraft:red_concrete
setblock 414 115 646 minecraft:purple_terracotta
setblock 416 115 646 minecraft:red_concrete
setblock 417 115 604 minecraft:red_concrete
fill 417 115 646 417 118 646 minecraft:purple_terracotta
fill 418 115 608 418 118 608 minecraft:purple_terracotta
fill 418 115 619 418 118 619 minecraft:purple_terracotta
setblock 418 115 620 minecraft:red_concrete
fill 418 115 623 418 115 624 minecraft:red_concrete
fill 418 115 640 418 118 640 minecraft:purple_terracotta
setblock 418 115 644 minecraft:red_concrete
fill 376 116 608 376 117 609 minecraft:red_concrete
fill 376 116 610 376 121 611 minecraft:purple_terracotta
setblock 376 116 612 minecraft:red_concrete
fill 376 116 620 376 117 621 minecraft:red_concrete
fill 376 116 622 376 121 623 minecraft:purple_terracotta
fill 376 116 629 376 117 629 minecraft:red_concrete
fill 376 116 631 376 121 631 minecraft:purple_terracotta
fill 376 116 632 376 116 633 minecraft:red_concrete
fill 376 116 634 376 121 634 minecraft:purple_terracotta
fill 376 116 640 376 117 641 minecraft:red_concrete
fill 376 116 642 376 121 643 minecraft:purple_terracotta
fill 381 116 646 381 117 646 minecraft:purple_terracotta
fill 382 116 604 382 121 604 minecraft:purple_terracotta
fill 382 116 646 383 116 646 minecraft:red_concrete
fill 383 116 604 384 116 604 minecraft:red_concrete
fill 384 116 646 385 121 646 minecraft:purple_terracotta
fill 385 116 604 385 121 604 minecraft:purple_terracotta
fill 387 116 604 387 117 604 minecraft:red_concrete
fill 390 116 646 391 117 646 minecraft:red_concrete
fill 392 116 646 393 121 646 minecraft:purple_terracotta
fill 393 116 604 394 121 604 minecraft:purple_terracotta
setblock 394 116 646 minecraft:red_concrete
fill 395 116 604 396 117 604 minecraft:red_concrete
fill 396 116 646 396 118 646 minecraft:purple_terracotta
setblock 397 116 644 minecraft:crying_obsidian
fill 402 116 646 403 117 646 minecraft:red_concrete
fill 403 116 604 403 119 604 minecraft:purple_terracotta
fill 403 116 637 405 116 637 minecraft:crying_obsidian
setblock 404 116 604 minecraft:red_concrete
fill 404 116 638 405 116 638 minecraft:crying_obsidian
fill 404 116 646 405 121 646 minecraft:purple_terracotta
fill 405 116 604 406 121 604 minecraft:purple_terracotta
fill 407 116 604 408 117 604 minecraft:red_concrete
setblock 410 116 646 minecraft:purple_terracotta
fill 411 116 646 411 117 646 minecraft:red_concrete
fill 413 116 604 414 121 604 minecraft:purple_terracotta
fill 413 116 646 413 121 646 minecraft:purple_terracotta
fill 414 116 646 415 116 646 minecraft:red_concrete
fill 415 116 604 416 116 604 minecraft:red_concrete
fill 416 116 646 416 121 646 minecraft:purple_terracotta
fill 417 116 604 417 121 604 minecraft:purple_terracotta
fill 418 116 611 418 121 612 minecraft:purple_terracotta
fill 418 116 613 418 117 614 minecraft:red_concrete
fill 418 116 620 418 121 620 minecraft:purple_terracotta
setblock 418 116 622 minecraft:red_concrete
fill 418 116 623 418 121 624 minecraft:purple_terracotta
fill 418 116 625 418 117 625 minecraft:red_concrete
fill 418 116 631 418 121 632 minecraft:purple_terracotta
fill 418 116 633 418 116 634 minecraft:red_concrete
fill 418 116 635 418 117 636 minecraft:purple_terracotta
fill 418 116 643 418 121 644 minecraft:purple_terracotta
fill 418 116 645 418 117 645 minecraft:red_concrete
fill 376 117 612 376 120 612 minecraft:purple_terracotta
setblock 376 117 617 minecraft:red_concrete
setblock 376 117 628 minecraft:red_concrete
fill 376 117 632 376 120 633 minecraft:purple_terracotta
fill 378 117 646 379 117 646 minecraft:red_concrete
setblock 382 117 646 minecraft:red_concrete
fill 383 117 604 384 120 604 minecraft:purple_terracotta
fill 383 117 646 383 120 646 minecraft:purple_terracotta
setblock 388 117 604 minecraft:red_concrete
fill 394 117 646 394 120 646 minecraft:purple_terracotta
fill 398 117 646 398 119 646 minecraft:purple_terracotta
setblock 399 117 604 minecraft:red_concrete
setblock 399 117 646 minecraft:red_concrete
fill 404 117 604 404 120 604 minecraft:purple_terracotta
fill 405 117 638 407 117 638 minecraft:crying_obsidian
setblock 410 117 646 minecraft:red_concrete
fill 414 117 646 415 120 646 minecraft:purple_terracotta
fill 415 117 604 415 120 604 minecraft:purple_terracotta
setblock 416 117 604 minecraft:red_concrete
fill 418 117 605 418 117 606 minecraft:red_concrete
fill 418 117 622 418 120 622 minecraft:purple_terracotta
setblock 418 117 626 minecraft:red_concrete
fill 418 117 633 418 120 633 minecraft:purple_terracotta
setblock 418 117 634 minecraft:red_concrete
setblock 418 117 637 minecraft:red_concrete
fill 376 118 606 376 119 607 minecraft:red_concrete
fill 376 118 608 376 123 609 minecraft:purple_terracotta
fill 376 118 617 376 123 617 minecraft:purple_terracotta
fill 376 118 618 376 118 619 minecraft:red_concrete
fill 376 118 620 376 123 621 minecraft:purple_terracotta
fill 376 118 626 376 119 627 minecraft:red_concrete
fill 376 118 628 376 123 629 minecraft:purple_terracotta
setblock 376 118 630 minecraft:red_concrete
fill 376 118 638 376 119 639 minecraft:red_concrete
fill 376 118 640 376 123 641 minecraft:purple_terracotta
fill 377 118 604 378 119 604 minecraft:red_concrete
fill 377 118 646 377 119 646 minecraft:red_concrete
fill 378 118 646 379 119 646 minecraft:purple_terracotta
fill 380 118 646 381 118 646 minecraft:red_concrete
fill 382 118 646 382 123 646 minecraft:purple_terracotta
setblock 386 118 604 minecraft:red_concrete
fill 387 118 604 388 123 604 minecraft:purple_terracotta
fill 388 118 646 389 119 646 minecraft:red_concrete
fill 389 118 604 390 119 604 minecraft:red_concrete
fill 390 118 646 391 123 646 minecraft:purple_terracotta
fill 395 118 604 396 123 604 minecraft:purple_terracotta
fill 397 118 604 398 118 604 minecraft:red_concrete
fill 399 118 604 399 123 604 minecraft:purple_terracotta
fill 399 118 646 399 119 646 minecraft:purple_terracotta
fill 400 118 646 401 118 646 minecraft:red_concrete
fill 402 118 646 403 123 646 minecraft:purple_terracotta
fill 407 118 604 408 123 604 minecraft:purple_terracotta
fill 407 118 638 409 118 638 minecraft:crying_obsidian
fill 408 118 646 409 119 646 minecraft:red_concrete
fill 409 118 604 410 119 604 minecraft:red_concrete
fill 410 118 646 411 123 646 minecraft:purple_terracotta
setblock 412 118 646 minecraft:red_concrete
fill 416 118 604 416 123 604 minecraft:purple_terracotta
setblock 418 118 604 minecraft:red_concrete
fill 418 118 605 418 123 606 minecraft:purple_terracotta
fill 418 118 607 418 119 607 minecraft:red_concrete
fill 418 118 613 418 123 614 minecraft:purple_terracotta
fill 418 118 615 418 118 616 minecraft:red_concrete
fill 418 118 625 418 123 626 minecraft:purple_terracotta
fill 418 118 627 418 119 628 minecraft:red_concrete
fill 418 118 634 418 123 634 minecraft:purple_terracotta
fill 418 118 635 418 118 636 minecraft:red_concrete
fill 418 118 637 418 123 637 minecraft:purple_terracotta
fill 418 118 639 418 119 639 minecraft:red_concrete
fill 418 118 645 418 123 645 minecraft:purple_terracotta
fill 376 119 614 376 119 615 minecraft:red_concrete
setblock 376 119 618 minecraft:red_concrete
fill 376 119 619 376 122 619 minecraft:purple_terracotta
fill 376 119 630 376 122 630 minecraft:purple_terracotta
setblock 376 119 635 minecraft:red_concrete
setblock 376 119 646 minecraft:red_concrete
fill 380 119 646 381 121 646 minecraft:purple_terracotta
setblock 381 119 604 minecraft:red_concrete
fill 386 119 604 386 122 604 minecraft:purple_terracotta
fill 396 119 646 397 119 646 minecraft:red_concrete
fill 397 119 604 397 122 604 minecraft:purple_terracotta
setblock 398 119 604 minecraft:red_concrete
setblock 400 119 646 minecraft:red_concrete
fill 401 119 604 402 119 604 minecraft:red_concrete
fill 401 119 646 401 122 646 minecraft:purple_terracotta
fill 408 119 638 410 119 638 minecraft:crying_obsidian
fill 409 119 639 410 119 639 minecraft:crying_obsidian
fill 412 119 646 412 122 646 minecraft:purple_terracotta
setblock 417 119 646 minecraft:red_concrete
fill 418 119 604 418 122 604 minecraft:purple_terracotta
setblock 418 119 608 minecraft:red_concrete
fill 418 119 615 418 122 615 minecraft:purple_terracotta
setblock 418 119 616 minecraft:red_concrete
setblock 418 119 619 minecraft:red_concrete
fill 418 119 635 418 122 636 minecraft:purple_terracotta
setblock 418 119 640 minecraft:red_concrete
fill 376 120 604 376 120 605 minecraft:red_concrete
fill 376 120 606 376 125 607 minecraft:purple_terracotta
fill 376 120 613 376 121 613 minecraft:red_concrete
fill 376 120 614 376 125 615 minecraft:purple_terracotta
setblock 376 120 616 minecraft:red_concrete
fill 376 120 618 376 125 618 minecraft:purple_terracotta
fill 376 120 624 376 121 625 minecraft:red_concrete
fill 376 120 626 376 125 627 minecraft:purple_terracotta
fill 376 120 635 376 125 635 minecraft:purple_terracotta
fill 376 120 636 376 120 637 minecraft:red_concrete
fill 376 120 638 376 122 639 minecraft:purple_terracotta
fill 376 120 644 376 121 645 minecraft:red_concrete
fill 376 120 646 377 125 646 minecraft:purple_terracotta
fill 377 120 604 378 125 604 minecraft:purple_terracotta
fill 377 120 605 379 120 605 minecraft:polished_blackstone
fill 377 120 607 377 120 609 minecraft:polished_blackstone
fill 377 120 611 377 120 613 minecraft:polished_blackstone
fill 377 120 615 377 120 617 minecraft:polished_blackstone
fill 377 120 619 377 120 621 minecraft:polished_blackstone
fill 377 120 623 377 120 625 minecraft:polished_blackstone
fill 377 120 627 377 120 629 minecraft:polished_blackstone
fill 377 120 631 377 120 633 minecraft:polished_blackstone
fill 377 120 635 377 120 637 minecraft:polished_blackstone
fill 377 120 639 377 120 641 minecraft:polished_blackstone
fill 377 120 643 377 120 645 minecraft:polished_blackstone
setblock 378 120 646 minecraft:red_concrete
fill 379 120 604 380 120 604 minecraft:red_concrete
fill 379 120 645 381 120 645 minecraft:polished_blackstone
fill 379 120 646 379 123 646 minecraft:purple_terracotta
fill 381 120 604 381 125 604 minecraft:purple_terracotta
fill 381 120 605 383 120 605 minecraft:polished_blackstone
fill 383 120 645 385 120 645 minecraft:polished_blackstone
fill 384 120 627 386 121 627 minecraft:red_concrete
fill 385 120 605 387 120 605 minecraft:polished_blackstone
fill 385 120 626 385 121 626 minecraft:red_concrete
fill 385 120 628 385 121 628 minecraft:red_concrete
fill 386 120 646 387 121 646 minecraft:red_concrete
fill 387 120 645 389 120 645 minecraft:polished_blackstone
fill 388 120 646 389 125 646 minecraft:purple_terracotta
fill 389 120 604 390 125 604 minecraft:purple_terracotta
fill 389 120 605 391 120 605 minecraft:polished_blackstone
fill 391 120 604 392 121 604 minecraft:red_concrete
fill 391 120 645 393 120 645 minecraft:polished_blackstone
fill 393 120 605 395 120 605 minecraft:polished_blackstone
fill 395 120 645 397 120 645 minecraft:polished_blackstone
fill 395 120 646 395 121 646 minecraft:red_concrete
fill 396 120 646 397 121 646 minecraft:purple_terracotta
fill 397 120 605 399 120 605 minecraft:polished_blackstone
fill 398 120 604 398 125 604 minecraft:purple_terracotta
fill 398 120 646 399 120 646 minecraft:red_concrete
fill 399 120 645 401 120 645 minecraft:polished_blackstone
setblock 400 120 604 minecraft:red_concrete
fill 400 120 646 400 125 646 minecraft:purple_terracotta
fill 401 120 604 402 125 604 minecraft:purple_terracotta
fill 401 120 605 403 120 605 minecraft:polished_blackstone
fill 403 120 604 403 121 604 minecraft:red_concrete
fill 403 120 645 405 120 645 minecraft:polished_blackstone
fill 405 120 605 407 120 605 minecraft:polished_blackstone
fill 406 120 646 407 121 646 minecraft:red_concrete
fill 407 120 645 409 120 645 minecraft:polished_blackstone
fill 408 120 646 409 125 646 minecraft:purple_terracotta
fill 409 120 604 410 125 604 minecraft:purple_terracotta
fill 409 120 605 411 120 605 minecraft:polished_blackstone
setblock 410 120 639 minecraft:crying_obsidian
fill 411 120 604 412 120 604 minecraft:red_concrete
fill 411 120 645 413 120 645 minecraft:polished_blackstone
fill 413 120 605 415 120 605 minecraft:polished_blackstone
fill 415 120 645 417 120 645 minecraft:polished_blackstone
fill 417 120 605 417 120 607 minecraft:polished_blackstone
fill 417 120 609 417 120 611 minecraft:polished_blackstone
fill 417 120 613 417 120 615 minecraft:polished_blackstone
fill 417 120 617 417 120 619 minecraft:polished_blackstone
fill 417 120 621 417 120 623 minecraft:polished_blackstone
fill 417 120 625 417 120 627 minecraft:polished_blackstone
fill 417 120 629 417 120 631 minecraft:polished_blackstone
fill 417 120 633 417 120 635 minecraft:polished_blackstone
fill 417 120 637 417 120 639 minecraft:polished_blackstone
fill 417 120 641 417 120 643 minecraft:polished_blackstone
fill 417 120 646 417 125 646 minecraft:purple_terracotta
fill 418 120 607 418 125 608 minecraft:purple_terracotta
fill 418 120 609 418 121 610 minecraft:red_concrete
fill 418 120 616 418 125 616 minecraft:purple_terracotta
fill 418 120 617 418 120 618 minecraft:red_concrete
fill 418 120 619 418 125 619 minecraft:purple_terracotta
fill 418 120 621 418 121 621 minecraft:red_concrete
fill 418 120 627 418 125 628 minecraft:purple_terracotta
fill 418 120 629 418 121 630 minecraft:red_concrete
setblock 418 120 638 minecraft:red_concrete
fill 418 120 639 418 125 640 minecraft:purple_terracotta
fill 418 120 641 418 121 642 minecraft:red_concrete
fill 418 120 646 418 121 646 minecraft:red_concrete
setblock 376 121 604 minecraft:red_concrete
fill 376 121 605 376 124 605 minecraft:purple_terracotta
setblock 376 121 612 minecraft:red_concrete
fill 376 121 616 376 124 616 minecraft:purple_terracotta
fill 376 121 632 376 121 633 minecraft:red_concrete
setblock 376 121 636 minecraft:red_concrete
fill 376 121 637 376 124 637 minecraft:purple_terracotta
fill 378 121 646 378 123 646 minecraft:purple_terracotta
fill 379 121 604 379 124 604 minecraft:purple_terracotta
setblock 380 121 604 minecraft:red_concrete
fill 383 121 604 384 121 604 minecraft:red_concrete
setblock 383 121 646 minecraft:red_concrete
setblock 394 121 646 minecraft:red_concrete
fill 398 121 646 399 123 646 minecraft:purple_terracotta
fill 400 121 604 400 124 604 minecraft:purple_terracotta
setblock 404 121 604 minecraft:red_concrete
fill 411 121 604 411 124 604 minecraft:purple_terracotta
setblock 412 121 604 minecraft:red_concrete
fill 414 121 646 415 121 646 minecraft:red_concrete
setblock 415 121 604 minecraft:red_concrete
fill 418 121 617 418 124 618 minecraft:purple_terracotta
setblock 418 121 622 minecraft:red_concrete
setblock 418 121 633 minecraft:red_concrete
fill 418 121 638 418 124 638 minecraft:purple_terracotta
fill 376 122 604 376 127 604 minecraft:purple_terracotta
fill 376 122 610 376 123 611 minecraft:red_concrete
fill 376 122 612 376 127 613 minecraft:purple_terracotta
fill 376 122 622 376 122 623 minecraft:red_concrete
fill 376 122 624 376 127 625 minecraft:purple_terracotta
fill 376 122 631 376 123 631 minecraft:red_concrete
fill 376 122 632 376 127 633 minecraft:purple_terracotta
setblock 376 122 634 minecraft:red_concrete
fill 376 122 636 376 124 636 minecraft:purple_terracotta
fill 376 122 642 376 123 643 minecraft:red_concrete
fill 376 122 644 376 127 645 minecraft:purple_terracotta
setblock 379 122 607 minecraft:light[level=12]
setblock 379 122 615 minecraft:light[level=12]
setblock 379 122 623 minecraft:light[level=12]
setblock 379 122 631 minecraft:light[level=12]
setblock 379 122 639 minecraft:light[level=12]
fill 380 122 604 380 127 604 minecraft:purple_terracotta
setblock 380 122 646 minecraft:purple_terracotta
fill 381 122 646 381 123 646 minecraft:red_concrete
setblock 382 122 604 minecraft:red_concrete
fill 383 122 604 384 127 604 minecraft:purple_terracotta
fill 383 122 646 383 127 646 minecraft:purple_terracotta
fill 384 122 646 385 122 646 minecraft:red_concrete
fill 385 122 604 385 123 604 minecraft:red_concrete
fill 386 122 646 387 124 646 minecraft:purple_terracotta
setblock 387 122 607 minecraft:light[level=12]
setblock 387 122 615 minecraft:light[level=12]
setblock 387 122 623 minecraft:light[level=12]
setblock 387 122 631 minecraft:light[level=12]
setblock 387 122 639 minecraft:light[level=12]
fill 391 122 604 392 127 604 minecraft:purple_terracotta
fill 392 122 646 393 123 646 minecraft:red_concrete
fill 393 122 604 394 122 604 minecraft:red_concrete
fill 394 122 646 395 127 646 minecraft:purple_terracotta
setblock 395 122 607 minecraft:light[level=12]
setblock 395 122 615 minecraft:light[level=12]
setblock 395 122 623 minecraft:light[level=12]
setblock 395 122 631 minecraft:light[level=12]
setblock 395 122 639 minecraft:light[level=12]
setblock 396 122 646 minecraft:red_concrete
fill 397 122 646 397 125 646 minecraft:purple_terracotta
fill 403 122 604 404 127 604 minecraft:purple_terracotta
setblock 403 122 607 minecraft:light[level=12]
setblock 403 122 615 minecraft:light[level=12]
setblock 403 122 623 minecraft:light[level=12]
setblock 403 122 631 minecraft:light[level=12]
setblock 403 122 639 minecraft:light[level=12]
fill 404 122 646 405 122 646 minecraft:red_concrete
fill 405 122 604 406 123 604 minecraft:red_concrete
fill 406 122 646 407 127 646 minecraft:purple_terracotta
setblock 411 122 607 minecraft:light[level=12]
setblock 411 122 615 minecraft:light[level=12]
setblock 411 122 623 minecraft:light[level=12]
setblock 411 122 631 minecraft:light[level=12]
setblock 411 122 639 minecraft:light[level=12]
fill 412 122 604 412 127 604 minecraft:purple_terracotta
fill 413 122 604 414 122 604 minecraft:red_concrete
fill 413 122 646 413 123 646 minecraft:red_concrete
fill 414 122 646 415 127 646 minecraft:purple_terracotta
fill 415 122 604 415 127 604 minecraft:purple_terracotta
setblock 416 122 646 minecraft:red_concrete
fill 417 122 604 417 123 604 minecraft:red_concrete
fill 418 122 609 418 127 610 minecraft:purple_terracotta
fill 418 122 611 418 123 612 minecraft:red_concrete
setblock 418 122 620 minecraft:red_concrete
fill 418 122 621 418 127 622 minecraft:purple_terracotta
fill 418 122 623 418 123 624 minecraft:red_concrete
fill 418 122 629 418 127 630 minecraft:purple_terracotta
fill 418 122 631 418 122 632 minecraft:red_concrete
fill 418 122 633 418 127 633 minecraft:purple_terracotta
fill 418 122 641 418 127 642 minecraft:purple_terracotta
fill 418 122 643 418 123 644 minecraft:red_concrete
fill 418 122 646 418 127 646 minecraft:purple_terracotta
setblock 376 123 619 minecraft:red_concrete
setblock 376 123 622 minecraft:red_concrete
fill 376 123 623 376 126 623 minecraft:purple_terracotta
setblock 376 123 630 minecraft:red_concrete
fill 376 123 634 376 126 634 minecraft:purple_terracotta
fill 376 123 638 376 125 638 minecraft:purple_terracotta
setblock 376 123 639 minecraft:red_concrete
setblock 380 123 646 minecraft:red_concrete
fill 382 123 604 382 126 604 minecraft:purple_terracotta
setblock 384 123 646 minecraft:red_concrete
fill 385 123 646 385 126 646 minecraft:purple_terracotta
setblock 386 123 604 minecraft:red_concrete
fill 393 123 604 393 126 604 minecraft:purple_terracotta
setblock 394 123 604 minecraft:red_concrete
fill 396 123 646 396 125 646 minecraft:purple_terracotta
setblock 397 123 604 minecraft:red_concrete
setblock 401 123 646 minecraft:red_concrete
setblock 404 123 646 minecraft:red_concrete
fill 405 123 646 405 126 646 minecraft:purple_terracotta
setblock 412 123 646 minecraft:red_concrete
fill 413 123 604 414 126 604 minecraft:purple_terracotta
fill 416 123 646 416 126 646 minecraft:purple_terracotta
setblock 418 123 604 minecraft:red_concrete
setblock 418 123 615 minecraft:red_concrete
fill 418 123 620 418 126 620 minecraft:purple_terracotta
fill 418 123 631 418 126 631 minecraft:purple_terracotta
setblock 418 123 632 minecraft:red_concrete
fill 418 123 635 418 123 636 minecraft:red_concrete
fill 376 124 608 376 125 609 minecraft:red_concrete
fill 376 124 610 376 129 611 minecraft:purple_terracotta
fill 376 124 617 376 125 617 minecraft:red_concrete
fill 376 124 619 376 129 619 minecraft:purple_terracotta
fill 376 124 620 376 124 621 minecraft:red_concrete
fill 376 124 622 376 129 622 minecraft:purple_terracotta
fill 376 124 628 376 125 629 minecraft:red_concrete
fill 376 124 630 376 129 631 minecraft:purple_terracotta
fill 376 124 639 376 125 639 minecraft:purple_terracotta
fill 376 124 640 376 124 641 minecraft:red_concrete
fill 376 124 642 376 129 643 minecraft:purple_terracotta
fill 378 124 646 379 125 646 minecraft:red_concrete
fill 380 124 646 381 129 646 minecraft:purple_terracotta
setblock 382 124 646 minecraft:red_concrete
fill 384 124 646 384 126 646 minecraft:purple_terracotta
fill 385 124 604 386 129 604 minecraft:purple_terracotta
fill 387 124 604 388 125 604 minecraft:red_concrete
fill 390 124 646 391 125 646 minecraft:red_concrete
fill 392 124 646 393 129 646 minecraft:purple_terracotta
fill 394 124 604 394 129 604 minecraft:purple_terracotta
fill 395 124 604 396 124 604 minecraft:red_concrete
fill 397 124 604 397 129 604 minecraft:purple_terracotta
setblock 398 124 646 minecraft:purple_terracotta
fill 399 124 604 399 125 604 minecraft:red_concrete
fill 399 124 646 399 125 646 minecraft:red_concrete
fill 401 124 646 401 129 646 minecraft:purple_terracotta
fill 402 124 646 403 124 646 minecraft:red_concrete
fill 404 124 646 404 129 646 minecraft:purple_terracotta
fill 405 124 604 406 129 604 minecraft:purple_terracotta
fill 407 124 604 408 125 604 minecraft:red_concrete
fill 410 124 646 411 125 646 minecraft:red_concrete
fill 412 124 646 413 129 646 minecraft:purple_terracotta
setblock 416 124 604 minecraft:red_concrete
fill 417 124 604 418 129 604 minecraft:purple_terracotta
fill 418 124 605 418 125 606 minecraft:red_concrete
fill 418 124 611 418 129 612 minecraft:purple_terracotta
fill 418 124 613 418 124 614 minecraft:red_concrete
fill 418 124 615 418 129 615 minecraft:purple_terracotta
fill 418 124 623 418 129 624 minecraft:purple_terracotta
fill 418 124 625 418 125 626 minecraft:red_concrete
fill 418 124 632 418 129 632 minecraft:purple_terracotta
setblock 418 124 634 minecraft:red_concrete
fill 418 124 635 418 129 636 minecraft:purple_terracotta
fill 418 124 637 418 125 637 minecraft:red_concrete
fill 418 124 643 418 129 644 minecraft:purple_terracotta
setblock 418 124 645 minecraft:red_concrete
setblock 376 125 605 minecraft:red_concrete
setblock 376 125 616 minecraft:red_concrete
fill 376 125 620 376 128 621 minecraft:purple_terracotta
fill 376 125 636 376 125 637 minecraft:red_concrete
setblock 376 125 640 minecraft:red_concrete
fill 376 125 641 376 128 641 minecraft:purple_terracotta
setblock 379 125 604 minecraft:red_concrete
fill 382 125 646 382 128 646 minecraft:purple_terracotta
fill 386 125 646 386 127 646 minecraft:purple_terracotta
setblock 387 125 646 minecraft:red_concrete
fill 395 125 604 396 128 604 minecraft:purple_terracotta
setblock 398 125 646 minecraft:red_concrete
setblock 400 125 604 minecraft:red_concrete
fill 402 125 646 403 128 646 minecraft:purple_terracotta
setblock 411 125 604 minecraft:red_concrete
fill 416 125 604 416 128 604 minecraft:purple_terracotta
fill 418 125 613 418 128 613 minecraft:purple_terracotta
setblock 418 125 614 minecraft:red_concrete
fill 418 125 617 418 125 618 minecraft:red_concrete
fill 418 125 634 418 128 634 minecraft:purple_terracotta
setblock 418 125 638 minecraft:red_concrete
fill 418 125 645 418 128 645 minecraft:purple_terracotta
fill 376 126 605 376 131 605 minecraft:purple_terracotta
fill 376 126 606 376 126 607 minecraft:red_concrete
fill 376 126 608 376 131 609 minecraft:purple_terracotta
fill 376 126 614 376 127 615 minecraft:red_concrete
fill 376 126 616 376 131 617 minecraft:purple_terracotta
setblock 376 126 618 minecraft:red_concrete
fill 376 126 626 376 127 627 minecraft:red_concrete
fill 376 126 628 376 131 629 minecraft:purple_terracotta
fill 376 126 635 376 127 635 minecraft:red_concrete
fill 376 126 636 376 127 637 minecraft:purple_terracotta
fill 376 126 638 376 126 639 minecraft:red_concrete
fill 376 126 640 376 131 640 minecraft:purple_terracotta
fill 376 126 646 377 127 646 minecraft:red_concrete
fill 377 126 604 378 126 604 minecraft:red_concrete
fill 377 126 605 379 126 605 minecraft:polished_blackstone
fill 377 126 607 377 126 609 minecraft:polished_blackstone
fill 377 126 611 377 126 613 minecraft:polished_blackstone
fill 377 126 615 377 126 617 minecraft:polished_blackstone
fill 377 126 619 377 126 621 minecraft:polished_blackstone
fill 377 126 623 377 126 625 minecraft:polished_blackstone
fill 377 126 627 377 126 629 minecraft:polished_blackstone
fill 377 126 631 377 126 633 minecraft:polished_blackstone
fill 377 126 635 377 126 637 minecraft:polished_blackstone
fill 377 126 639 377 126 641 minecraft:polished_blackstone
fill 377 126 643 377 126 645 minecraft:polished_blackstone
fill 378 126 646 379 131 646 minecraft:purple_terracotta
fill 379 126 604 379 131 604 minecraft:purple_terracotta
fill 379 126 645 381 126 645 minecraft:polished_blackstone
fill 381 126 604 381 127 604 minecraft:red_concrete
fill 381 126 605 383 126 605 minecraft:polished_blackstone
fill 383 126 645 385 126 645 minecraft:polished_blackstone
fill 385 126 605 387 126 605 minecraft:polished_blackstone
fill 385 126 615 385 127 617 minecraft:red_concrete
fill 386 126 615 386 127 616 minecraft:red_concrete
fill 387 126 604 388 131 604 minecraft:purple_terracotta
fill 387 126 645 389 126 645 minecraft:polished_blackstone
fill 387 126 646 387 127 646 minecraft:purple_terracotta
fill 388 126 646 389 126 646 minecraft:red_concrete
fill 389 126 604 390 127 604 minecraft:red_concrete
fill 389 126 605 391 126 605 minecraft:polished_blackstone
fill 390 126 646 391 131 646 minecraft:purple_terracotta
fill 391 126 645 393 126 645 minecraft:polished_blackstone
fill 393 126 605 395 126 605 minecraft:polished_blackstone
fill 395 126 645 397 126 645 minecraft:polished_blackstone
fill 396 126 646 397 127 646 minecraft:red_concrete
fill 397 126 605 399 126 605 minecraft:polished_blackstone
setblock 398 126 604 minecraft:red_concrete
fill 398 126 646 399 131 646 minecraft:purple_terracotta
fill 399 126 604 400 131 604 minecraft:purple_terracotta
fill 399 126 645 401 126 645 minecraft:polished_blackstone
setblock 400 126 646 minecraft:red_concrete
fill 401 126 604 402 127 604 minecraft:red_concrete
fill 401 126 605 403 126 605 minecraft:polished_blackstone
fill 403 126 645 405 126 645 minecraft:polished_blackstone
fill 405 126 605 407 126 605 minecraft:polished_blackstone
fill 407 126 604 408 131 604 minecraft:purple_terracotta
fill 407 126 645 409 126 645 minecraft:polished_blackstone
fill 408 126 646 409 127 646 minecraft:red_concrete
fill 409 126 604 410 126 604 minecraft:red_concrete
fill 409 126 605 411 126 605 minecraft:polished_blackstone
fill 410 126 646 411 131 646 minecraft:purple_terracotta
fill 411 126 604 411 131 604 minecraft:purple_terracotta
fill 411 126 645 413 126 645 minecraft:polished_blackstone
fill 413 126 605 415 126 605 minecraft:polished_blackstone
fill 415 126 645 417 126 645 minecraft:polished_blackstone
fill 417 126 605 417 126 607 minecraft:polished_blackstone
fill 417 126 609 417 126 611 minecraft:polished_blackstone
fill 417 126 613 417 126 615 minecraft:polished_blackstone
fill 417 126 617 417 126 619 minecraft:polished_blackstone
fill 417 126 621 417 126 623 minecraft:polished_blackstone
fill 417 126 625 417 126 627 minecraft:polished_blackstone
fill 417 126 629 417 126 631 minecraft:polished_blackstone
fill 417 126 633 417 126 635 minecraft:polished_blackstone
fill 417 126 637 417 126 639 minecraft:polished_blackstone
fill 417 126 641 417 126 643 minecraft:polished_blackstone
fill 417 126 646 417 127 646 minecraft:red_concrete
fill 418 126 605 418 131 606 minecraft:purple_terracotta
fill 418 126 607 418 127 608 minecraft:red_concrete
fill 418 126 614 418 131 614 minecraft:purple_terracotta
setblock 418 126 616 minecraft:red_concrete
fill 418 126 617 418 131 618 minecraft:purple_terracotta
fill 418 126 619 418 127 619 minecraft:red_concrete
fill 418 126 625 418 131 626 minecraft:purple_terracotta
fill 418 126 627 418 126 628 minecraft:red_concrete
fill 418 126 637 418 131 638 minecraft:purple_terracotta
fill 418 126 639 418 127 640 minecraft:red_concrete
setblock 376 127 606 minecraft:red_concrete
fill 376 127 607 376 130 607 minecraft:purple_terracotta
fill 376 127 618 376 130 618 minecraft:purple_terracotta
setblock 376 127 623 minecraft:red_concrete
setblock 376 127 634 minecraft:red_concrete
fill 376 127 638 376 129 639 minecraft:purple_terracotta
fill 377 127 604 378 130 604 minecraft:purple_terracotta
setblock 382 127 604 minecraft:red_concrete
fill 384 127 646 385 127 646 minecraft:red_concrete
setblock 388 127 646 minecraft:red_concrete
fill 389 127 646 389 130 646 minecraft:purple_terracotta
setblock 393 127 604 minecraft:red_concrete
fill 398 127 604 398 130 604 minecraft:purple_terracotta
fill 400 127 646 400 130 646 minecraft:purple_terracotta
setblock 405 127 646 minecraft:red_concrete
fill 409 127 604 409 130 604 minecraft:purple_terracotta
setblock 410 127 604 minecraft:red_concrete
fill 413 127 604 414 127 604 minecraft:red_concrete
setblock 416 127 646 minecraft:red_concrete
fill 418 127 616 418 130 616 minecraft:purple_terracotta
setblock 418 127 620 minecraft:red_concrete
fill 418 127 627 418 130 627 minecraft:purple_terracotta
setblock 418 127 628 minecraft:red_concrete
setblock 418 127 631 minecraft:red_concrete
setblock 376 128 604 minecraft:red_concrete
fill 376 128 606 376 133 606 minecraft:purple_terracotta
fill 376 128 612 376 129 613 minecraft:red_concrete
fill 376 128 614 376 133 615 minecraft:purple_terracotta
fill 376 128 623 376 133 623 minecraft:purple_terracotta
fill 376 128 624 376 128 625 minecraft:red_concrete
fill 376 128 626 376 130 627 minecraft:purple_terracotta
fill 376 128 632 376 129 633 minecraft:red_concrete
fill 376 128 634 376 133 635 minecraft:purple_terracotta
setblock 376 128 636 minecraft:red_concrete
fill 376 128 637 376 131 637 minecraft:purple_terracotta
fill 376 128 644 376 129 645 minecraft:red_concrete
fill 376 128 646 377 133 646 minecraft:purple_terracotta
setblock 380 128 604 minecraft:red_concrete
fill 381 128 604 382 133 604 minecraft:purple_terracotta
fill 383 128 604 384 129 604 minecraft:red_concrete
fill 383 128 646 383 129 646 minecraft:red_concrete
fill 384 128 646 385 129 646 minecraft:purple_terracotta
fill 386 128 646 387 128 646 minecraft:red_concrete
fill 388 128 646 388 133 646 minecraft:purple_terracotta
fill 389 128 604 390 133 604 minecraft:purple_terracotta
fill 391 128 604 392 128 604 minecraft:red_concrete
fill 393 128 604 393 133 604 minecraft:purple_terracotta
fill 394 128 646 395 129 646 minecraft:red_concrete
fill 396 128 646 397 133 646 minecraft:purple_terracotta
fill 401 128 604 402 133 604 minecraft:purple_terracotta
fill 403 128 604 404 129 604 minecraft:red_concrete
fill 405 128 646 405 133 646 minecraft:purple_terracotta
fill 406 128 646 407 128 646 minecraft:red_concrete
fill 408 128 646 409 133 646 minecraft:purple_terracotta
fill 410 128 604 410 133 604 minecraft:purple_terracotta
setblock 412 128 604 minecraft:red_concrete
fill 413 128 604 414 133 604 minecraft:purple_terracotta
fill 414 128 646 415 129 646 minecraft:red_concrete
fill 415 128 604 415 129 604 minecraft:red_concrete
fill 416 128 646 417 133 646 minecraft:purple_terracotta
fill 418 128 607 418 133 608 minecraft:purple_terracotta
fill 418 128 609 418 128 610 minecraft:red_concrete
fill 418 128 619 418 133 620 minecraft:purple_terracotta
fill 418 128 621 418 129 622 minecraft:red_concrete
fill 418 128 628 418 133 628 minecraft:purple_terracotta
fill 418 128 629 418 128 630 minecraft:red_concrete
fill 418 128 631 418 133 631 minecraft:purple_terracotta
fill 418 128 633 418 129 633 minecraft:red_concrete
fill 418 128 639 418 133 640 minecraft:purple_terracotta
fill 418 128 641 418 129 642 minecraft:red_concrete
setblock 418 128 646 minecraft:red_concrete
fill 376 129 604 376 132 604 minecraft:purple_terracotta
fill 376 129 620 376 129 621 minecraft:red_concrete
setblock 376 129 624 minecraft:red_concrete
fill 376 129 625 376 132 625 minecraft:purple_terracotta
fill 376 129 636 376 131 636 minecraft:purple_terracotta
setblock 376 129 641 minecraft:red_concrete
fill 380 129 604 380 132 604 minecraft:purple_terracotta
setblock 382 129 646 minecraft:red_concrete
fill 386 129 646 387 131 646 minecraft:purple_terracotta
fill 391 129 604 391 132 604 minecraft:purple_terracotta
setblock 392 129 604 minecraft:red_concrete
fill 395 129 604 396 129 604 minecraft:red_concrete
fill 402 129 646 403 129 646 minecraft:red_concrete
setblock 406 129 646 minecraft:red_concrete
fill 407 129 646 407 132 646 minecraft:purple_terracotta
fill 412 129 604 412 132 604 minecraft:purple_terracotta
setblock 416 129 604 minecraft:red_concrete
fill 418 129 609 418 132 609 minecraft:purple_terracotta
setblock 418 129 610 minecraft:red_concrete
setblock 418 129 613 minecraft:red_concrete
fill 418 129 629 418 132 630 minecraft:purple_terracotta
setblock 418 129 634 minecraft:red_concrete
setblock 418 129 645 minecraft:red_concrete
fill 418 129 646 418 132 646 minecraft:purple_terracotta
fill 376 130 610 376 130 611 minecraft:red_concrete
fill 376 130 612 376 135 613 minecraft:purple_terracotta
fill 376 130 619 376 131 619 minecraft:red_concrete
fill 376 130 620 376 135 621 minecraft:purple_terracotta
setblock 376 130 622 minecraft:red_concrete
fill 376 130 624 376 132 624 minecraft:purple_terracotta
fill 376 130 630 376 131 631 minecraft:red_concrete
fill 376 130 632 376 135 633 minecraft:purple_terracotta
setblock 376 130 638 minecraft:purple_terracotta
fill 376 130 639 376 131 639 minecraft:red_concrete
fill 376 130 641 376 135 641 minecraft:purple_terracotta
fill 376 130 642 376 130 643 minecraft:red_concrete
fill 376 130 644 376 132 645 minecraft:purple_terracotta
setblock 379 130 607 minecraft:light[level=12]
setblock 379 130 615 minecraft:light[level=12]
setblock 379 130 623 minecraft:light[level=12]
setblock 379 130 631 minecraft:light[level=12]
setblock 379 130 639 minecraft:light[level=12]
fill 380 130 646 381 131 646 minecraft:red_concrete
fill 382 130 646 383 135 646 minecraft:purple_terracotta
fill 383 130 604 384 135 604 minecraft:purple_terracotta
setblock 384 130 646 minecraft:red_concrete
fill 385 130 604 386 131 604 minecraft:red_concrete
fill 385 130 646 385 133 646 minecraft:purple_terracotta
setblock 387 130 607 minecraft:light[level=12]
setblock 387 130 615 minecraft:light[level=12]
setblock 387 130 623 minecraft:light[level=12]
setblock 387 130 631 minecraft:light[level=12]
setblock 387 130 639 minecraft:light[level=12]
fill 392 130 604 392 135 604 minecraft:purple_terracotta
fill 392 130 646 393 130 646 minecraft:red_concrete
setblock 394 130 604 minecraft:red_concrete
fill 394 130 646 395 135 646 minecraft:purple_terracotta
fill 395 130 604 396 135 604 minecraft:purple_terracotta
setblock 395 130 607 minecraft:light[level=12]
setblock 395 130 615 minecraft:light[level=12]
setblock 395 130 623 minecraft:light[level=12]
setblock 395 130 631 minecraft:light[level=12]
setblock 395 130 639 minecraft:light[level=12]
fill 397 130 604 397 131 604 minecraft:red_concrete
fill 401 130 646 401 131 646 minecraft:red_concrete
fill 402 130 646 403 135 646 minecraft:purple_terracotta
fill 403 130 604 404 135 604 minecraft:purple_terracotta
setblock 403 130 607 minecraft:light[level=12]
setblock 403 130 615 minecraft:light[level=12]
setblock 403 130 623 minecraft:light[level=12]
setblock 403 130 631 minecraft:light[level=12]
setblock 403 130 639 minecraft:light[level=12]
setblock 404 130 646 minecraft:red_concrete
fill 405 130 604 406 130 604 minecraft:red_concrete
fill 406 130 646 406 135 646 minecraft:purple_terracotta
setblock 411 130 607 minecraft:light[level=12]
setblock 411 130 615 minecraft:light[level=12]
setblock 411 130 623 minecraft:light[level=12]
setblock 411 130 631 minecraft:light[level=12]
setblock 411 130 639 minecraft:light[level=12]
fill 412 130 646 413 131 646 minecraft:red_concrete
fill 414 130 646 415 135 646 minecraft:purple_terracotta
fill 415 130 604 416 135 604 minecraft:purple_terracotta
fill 417 130 604 418 131 604 minecraft:red_concrete
fill 418 130 610 418 135 610 minecraft:purple_terracotta
fill 418 130 611 418 130 612 minecraft:red_concrete
fill 418 130 613 418 135 613 minecraft:purple_terracotta
fill 418 130 615 418 131 615 minecraft:red_concrete
fill 418 130 621 418 135 622 minecraft:purple_terracotta
fill 418 130 623 418 131 624 minecraft:red_concrete
setblock 418 130 632 minecraft:red_concrete
fill 418 130 633 418 135 634 minecraft:purple_terracotta
fill 418 130 635 418 131 636 minecraft:red_concrete
fill 418 130 641 418 135 642 minecraft:purple_terracotta
fill 418 130 643 418 130 644 minecraft:red_concrete
fill 418 130 645 418 135 645 minecraft:purple_terracotta
setblock 376 131 607 minecraft:red_concrete
setblock 376 131 610 minecraft:red_concrete
fill 376 131 611 376 134 611 minecraft:purple_terracotta
setblock 376 131 618 minecraft:red_concrete
fill 376 131 622 376 134 622 minecraft:purple_terracotta
fill 376 131 626 376 133 626 minecraft:purple_terracotta
setblock 376 131 627 minecraft:red_concrete
setblock 376 131 638 minecraft:red_concrete
setblock 376 131 642 minecraft:red_concrete
fill 376 131 643 376 134 643 minecraft:purple_terracotta
fill 377 131 604 378 131 604 minecraft:red_concrete
fill 384 131 646 384 133 646 minecraft:purple_terracotta
setblock 389 131 646 minecraft:red_concrete
setblock 392 131 646 minecraft:red_concrete
fill 393 131 646 393 134 646 minecraft:purple_terracotta
fill 394 131 604 394 134 604 minecraft:purple_terracotta
setblock 398 131 604 minecraft:red_concrete
setblock 400 131 646 minecraft:red_concrete
fill 404 131 646 404 134 646 minecraft:purple_terracotta
fill 405 131 604 405 134 604 minecraft:purple_terracotta
setblock 406 131 604 minecraft:red_concrete
setblock 409 131 604 minecraft:red_concrete
fill 418 131 611 418 134 612 minecraft:purple_terracotta
setblock 418 131 616 minecraft:red_concrete
setblock 418 131 627 minecraft:red_concrete
fill 418 131 632 418 134 632 minecraft:purple_terracotta
fill 418 131 643 418 134 643 minecraft:purple_terracotta
setblock 418 131 644 minecraft:red_concrete
fill 376 132 605 376 133 605 minecraft:red_concrete
fill 376 132 607 376 137 607 minecraft:purple_terracotta
fill 376 132 608 376 132 609 minecraft:red_concrete
fill 376 132 610 376 137 610 minecraft:purple_terracotta
fill 376 132 616 376 133 617 minecraft:red_concrete
fill 376 132 618 376 137 619 minecraft:purple_terracotta
fill 376 132 627 376 133 627 minecraft:purple_terracotta
fill 376 132 628 376 132 629 minecraft:red_concrete
fill 376 132 630 376 137 631 minecraft:purple_terracotta
fill 376 132 636 376 133 637 minecraft:red_concrete
fill 376 132 638 376 137 639 minecraft:purple_terracotta
setblock 376 132 640 minecraft:red_concrete
fill 376 132 642 376 134 642 minecraft:purple_terracotta
fill 377 132 604 378 137 604 minecraft:purple_terracotta
fill 377 132 605 379 132 605 minecraft:polished_blackstone
fill 377 132 607 377 132 609 minecraft:polished_blackstone
fill 377 132 611 377 132 613 minecraft:polished_blackstone
fill 377 132 615 377 132 617 minecraft:polished_blackstone
fill 377 132 619 377 132 621 minecraft:polished_blackstone
fill 377 132 623 377 132 625 minecraft:polished_blackstone
fill 377 132 627 377 132 629 minecraft:polished_blackstone
fill 377 132 631 377 132 633 minecraft:polished_blackstone
fill 377 132 635 377 132 637 minecraft:polished_blackstone
fill 377 132 639 377 132 641 minecraft:polished_blackstone
fill 377 132 643 377 132 645 minecraft:polished_blackstone
fill 378 132 646 379 133 646 minecraft:red_concrete
fill 379 132 604 379 133 604 minecraft:red_concrete
fill 379 132 645 381 132 645 minecraft:polished_blackstone
fill 380 132 646 381 137 646 minecraft:purple_terracotta
fill 381 132 605 383 132 605 minecraft:polished_blackstone
fill 383 132 645 385 132 645 minecraft:polished_blackstone
fill 385 132 604 386 137 604 minecraft:purple_terracotta
fill 385 132 605 387 132 605 minecraft:polished_blackstone
setblock 386 132 646 minecraft:purple_terracotta
fill 387 132 604 388 132 604 minecraft:red_concrete
fill 387 132 645 389 132 645 minecraft:polished_blackstone
fill 387 132 646 387 133 646 minecraft:red_concrete
fill 389 132 605 391 132 605 minecraft:polished_blackstone
fill 389 132 646 389 137 646 minecraft:purple_terracotta
fill 390 132 646 391 132 646 minecraft:red_concrete
fill 391 132 645 393 132 645 minecraft:polished_blackstone
fill 392 132 646 392 137 646 minecraft:purple_terracotta
fill 393 132 605 395 132 605 minecraft:polished_blackstone
fill 395 132 645 397 132 645 minecraft:polished_blackstone
fill 397 132 604 398 137 604 minecraft:purple_terracotta
fill 397 132 605 399 132 605 minecraft:polished_blackstone
fill 398 132 646 399 133 646 minecraft:red_concrete
fill 399 132 604 400 133 604 minecraft:red_concrete
fill 399 132 645 401 132 645 minecraft:polished_blackstone
fill 400 132 646 401 137 646 minecraft:purple_terracotta
fill 401 132 605 403 132 605 minecraft:polished_blackstone
fill 403 132 645 405 132 645 minecraft:polished_blackstone
fill 405 132 605 407 132 605 minecraft:polished_blackstone
fill 406 132 604 406 137 604 minecraft:purple_terracotta
fill 407 132 604 408 132 604 minecraft:red_concrete
fill 407 132 645 409 132 645 minecraft:polished_blackstone
fill 409 132 604 409 137 604 minecraft:purple_terracotta
fill 409 132 605 411 132 605 minecraft:polished_blackstone
fill 410 132 646 411 132 646 minecraft:red_concrete
fill 411 132 604 411 133 604 minecraft:red_concrete
fill 411 132 645 413 132 645 minecraft:polished_blackstone
fill 412 132 646 413 137 646 minecraft:purple_terracotta
fill 413 132 605 415 132 605 minecraft:polished_blackstone
fill 415 132 645 417 132 645 minecraft:polished_blackstone
fill 417 132 604 418 137 604 minecraft:purple_terracotta
fill 417 132 605 417 132 607 minecraft:polished_blackstone
fill 417 132 609 417 132 611 minecraft:polished_blackstone
fill 417 132 613 417 132 615 minecraft:polished_blackstone
fill 417 132 617 417 132 619 minecraft:polished_blackstone
fill 417 132 621 417 132 623 minecraft:polished_blackstone
fill 417 132 625 417 132 627 minecraft:polished_blackstone
fill 417 132 629 417 132 631 minecraft:polished_blackstone
fill 417 132 633 417 132 635 minecraft:polished_blackstone
fill 417 132 637 417 132 639 minecraft:polished_blackstone
fill 417 132 641 417 132 643 minecraft:polished_blackstone
fill 418 132 605 418 133 606 minecraft:red_concrete
setblock 418 132 614 minecraft:red_concrete
fill 418 132 615 418 137 616 minecraft:purple_terracotta
fill 418 132 617 418 133 618 minecraft:red_concrete
fill 418 132 623 418 137 624 minecraft:purple_terracotta
fill 418 132 625 418 132 626 minecraft:red_concrete
fill 418 132 627 418 137 627 minecraft:purple_terracotta
fill 418 132 635 418 137 636 minecraft:purple_terracotta
fill 418 132 637 418 133 638 minecraft:red_concrete
fill 418 132 644 418 137 644 minecraft:purple_terracotta
setblock 376 133 604 minecraft:red_concrete
fill 376 133 608 376 136 609 minecraft:purple_terracotta
fill 376 133 624 376 133 625 minecraft:red_concrete
setblock 376 133 628 minecraft:red_concrete
fill 376 133 629 376 136 629 minecraft:purple_terracotta
fill 376 133 640 376 136 640 minecraft:purple_terracotta
fill 376 133 644 376 135 644 minecraft:purple_terracotta
setblock 376 133 645 minecraft:red_concrete
setblock 380 133 604 minecraft:red_concrete
fill 380 133 621 382 138 622 minecraft:yellow_concrete
fill 381 133 620 381 138 620 minecraft:yellow_concrete
fill 381 133 623 382 138 623 minecraft:yellow_concrete
setblock 386 133 646 minecraft:red_concrete
fill 387 133 604 387 136 604 minecraft:purple_terracotta
setblock 388 133 604 minecraft:red_concrete
fill 390 133 646 391 136 646 minecraft:purple_terracotta
setblock 391 133 604 minecraft:red_concrete
fill 398 133 642 399 134 643 minecraft:blackstone
fill 407 133 604 408 136 604 minecraft:purple_terracotta
setblock 407 133 646 minecraft:red_concrete
setblock 410 133 646 minecraft:red_concrete
fill 411 133 646 411 136 646 minecraft:purple_terracotta
setblock 412 133 604 minecraft:red_concrete
setblock 418 133 609 minecraft:red_concrete
fill 418 133 614 418 136 614 minecraft:purple_terracotta
fill 418 133 625 418 136 625 minecraft:purple_terracotta
setblock 418 133 626 minecraft:red_concrete
fill 418 133 629 418 133 630 minecraft:red_concrete
setblock 418 133 646 minecraft:red_concrete
fill 376 134 604 376 139 605 minecraft:purple_terracotta
setblock 376 134 606 minecraft:red_concrete
fill 376 134 614 376 135 615 minecraft:red_concrete
fill 376 134 616 376 139 617 minecraft:purple_terracotta
fill 376 134 623 376 135 623 minecraft:red_concrete
fill 376 134 624 376 135 625 minecraft:purple_terracotta
fill 376 134 626 376 134 627 minecraft:red_concrete
fill 376 134 628 376 139 628 minecraft:purple_terracotta
fill 376 134 634 376 135 635 minecraft:red_concrete
fill 376 134 636 376 139 637 minecraft:purple_terracotta
fill 376 134 645 376 135 645 minecraft:purple_terracotta
fill 376 134 646 377 134 646 minecraft:red_concrete
fill 378 134 646 379 139 646 minecraft:purple_terracotta
fill 379 134 604 380 139 604 minecraft:purple_terracotta
fill 379 134 621 379 137 622 minecraft:yellow_concrete
fill 380 134 620 380 137 620 minecraft:yellow_concrete
fill 380 134 623 380 137 623 minecraft:yellow_concrete
fill 381 134 604 382 135 604 minecraft:red_concrete
fill 381 134 624 382 137 624 minecraft:yellow_concrete
fill 382 134 620 383 137 620 minecraft:yellow_concrete
fill 383 134 621 383 137 623 minecraft:yellow_concrete
fill 384 134 646 385 135 646 minecraft:red_concrete
fill 386 134 646 387 139 646 minecraft:purple_terracotta
fill 388 134 604 388 139 604 minecraft:purple_terracotta
setblock 388 134 646 minecraft:red_concrete
fill 389 134 604 390 134 604 minecraft:red_concrete
fill 391 134 604 391 139 604 minecraft:purple_terracotta
fill 393 134 604 393 135 604 minecraft:red_concrete
fill 396 134 646 397 135 646 minecraft:red_concrete
fill 398 134 646 399 139 646 minecraft:purple_terracotta
fill 399 134 604 400 139 604 minecraft:purple_terracotta
fill 401 134 604 402 135 604 minecraft:red_concrete
fill 405 134 646 405 135 646 minecraft:red_concrete
fill 407 134 646 407 139 646 minecraft:purple_terracotta
fill 408 134 646 409 134 646 minecraft:red_concrete
setblock 410 134 604 minecraft:red_concrete
fill 410 134 646 410 139 646 minecraft:purple_terracotta
fill 411 134 604 412 139 604 minecraft:purple_terracotta
fill 413 134 604 414 135 604 minecraft:red_concrete
fill 416 134 646 417 135 646 minecraft:red_concrete
fill 418 134 605 418 139 606 minecraft:purple_terracotta
fill 418 134 607 418 134 608 minecraft:red_concrete
fill 418 134 609 418 139 609 minecraft:purple_terracotta
fill 418 134 617 418 139 618 minecraft:purple_terracotta
fill 418 134 619 418 135 620 minecraft:red_concrete
fill 418 134 626 418 139 626 minecraft:purple_terracotta
setblock 418 134 628 minecraft:red_concrete
fill 418 134 629 418 139 630 minecraft:purple_terracotta
fill 418 134 631 418 135 631 minecraft:red_concrete
fill 418 134 637 418 139 638 minecraft:purple_terracotta
fill 418 134 639 418 134 640 minecraft:red_concrete
fill 418 134 646 418 139 646 minecraft:purple_terracotta
fill 376 135 606 376 138 606 minecraft:purple_terracotta
setblock 376 135 611 minecraft:red_concrete
setblock 376 135 622 minecraft:red_concrete
fill 376 135 626 376 137 627 minecraft:purple_terracotta
fill 376 135 642 376 135 643 minecraft:red_concrete
setblock 376 135 646 minecraft:red_concrete
fill 377 135 646 377 138 646 minecraft:purple_terracotta
fill 379 135 620 379 136 620 minecraft:yellow_concrete
fill 379 135 623 379 136 623 minecraft:yellow_concrete
fill 380 135 619 382 136 619 minecraft:yellow_concrete
fill 380 135 624 380 136 624 minecraft:yellow_concrete
fill 383 135 624 383 136 624 minecraft:yellow_concrete
fill 384 135 621 384 136 622 minecraft:yellow_concrete
fill 388 135 646 388 138 646 minecraft:purple_terracotta
fill 389 135 604 390 138 604 minecraft:purple_terracotta
setblock 393 135 646 minecraft:red_concrete
setblock 394 135 604 minecraft:red_concrete
fill 401 135 609 403 136 609 minecraft:magma_block
fill 402 135 610 402 136 610 minecraft:magma_block
setblock 404 135 646 minecraft:red_concrete
setblock 405 135 604 minecraft:red_concrete
fill 408 135 646 409 138 646 minecraft:purple_terracotta
fill 410 135 604 410 138 604 minecraft:purple_terracotta
fill 418 135 607 418 138 607 minecraft:purple_terracotta
setblock 418 135 608 minecraft:red_concrete
fill 418 135 611 418 135 612 minecraft:red_concrete
fill 418 135 628 418 138 628 minecraft:purple_terracotta
setblock 418 135 632 minecraft:red_concrete
fill 418 135 639 418 138 639 minecraft:purple_terracotta
setblock 418 135 640 minecraft:red_concrete
setblock 418 135 643 minecraft:red_concrete
fill 376 136 611 376 141 611 minecraft:purple_terracotta
fill 376 136 612 376 136 613 minecraft:red_concrete
fill 376 136 614 376 138 615 minecraft:purple_terracotta
fill 376 136 620 376 137 621 minecraft:red_concrete
fill 376 136 622 376 141 623 minecraft:purple_terracotta
setblock 376 136 624 minecraft:red_concrete
fill 376 136 625 376 139 625 minecraft:purple_terracotta
fill 376 136 632 376 137 633 minecraft:red_concrete
fill 376 136 634 376 141 635 minecraft:purple_terracotta
fill 376 136 641 376 137 641 minecraft:red_concrete
fill 376 136 642 376 137 643 minecraft:purple_terracotta
fill 376 136 644 376 136 645 minecraft:red_concrete
fill 376 136 646 376 141 646 minecraft:purple_terracotta
fill 381 136 604 382 141 604 minecraft:purple_terracotta
fill 382 136 646 383 137 646 minecraft:red_concrete
fill 383 136 604 384 137 604 minecraft:red_concrete
fill 384 136 646 385 141 646 minecraft:purple_terracotta
setblock 392 136 604 minecraft:red_concrete
fill 393 136 604 394 141 604 minecraft:purple_terracotta
fill 393 136 646 393 141 646 minecraft:purple_terracotta
fill 394 136 646 395 136 646 minecraft:red_concrete
fill 395 136 604 396 137 604 minecraft:red_concrete
fill 396 136 646 397 141 646 minecraft:purple_terracotta
fill 401 136 604 402 141 604 minecraft:purple_terracotta
fill 402 136 646 403 137 646 minecraft:red_concrete
fill 403 136 604 404 136 604 minecraft:red_concrete
fill 404 136 646 405 141 646 minecraft:purple_terracotta
fill 405 136 604 405 141 604 minecraft:purple_terracotta
setblock 406 136 646 minecraft:red_concrete
fill 413 136 604 414 141 604 minecraft:purple_terracotta
fill 414 136 646 415 137 646 minecraft:red_concrete
fill 415 136 604 416 137 604 minecraft:red_concrete
fill 416 136 646 417 141 646 minecraft:purple_terracotta
fill 418 136 608 418 141 608 minecraft:purple_terracotta
setblock 418 136 610 minecraft:red_concrete
fill 418 136 611 418 141 612 minecraft:purple_terracotta
fill 418 136 613 418 137 613 minecraft:red_concrete
fill 418 136 619 418 141 620 minecraft:purple_terracotta
fill 418 136 621 418 136 622 minecraft:red_concrete
fill 418 136 631 418 141 632 minecraft:purple_terracotta
fill 418 136 633 418 137 634 minecraft:red_concrete
fill 418 136 640 418 141 640 minecraft:purple_terracotta
fill 418 136 641 418 136 642 minecraft:red_concrete
fill 418 136 643 418 141 643 minecraft:purple_terracotta
fill 418 136 645 418 137 645 minecraft:red_concrete
fill 376 137 608 376 137 609 minecraft:red_concrete
setblock 376 137 612 minecraft:red_concrete
fill 376 137 613 376 140 613 minecraft:purple_terracotta
fill 376 137 624 376 139 624 minecraft:purple_terracotta
setblock 376 137 629 minecraft:red_concrete
setblock 376 137 640 minecraft:red_concrete
fill 376 137 644 376 139 645 minecraft:purple_terracotta
setblock 387 137 604 minecraft:red_concrete
fill 390 137 646 391 137 646 minecraft:red_concrete
fill 392 137 604 392 140 604 minecraft:purple_terracotta
setblock 394 137 646 minecraft:red_concrete
fill 395 137 646 395 140 646 minecraft:purple_terracotta
fill 403 137 604 403 140 604 minecraft:purple_terracotta
setblock 404 137 604 minecraft:red_concrete
fill 406 137 646 406 140 646 minecraft:purple_terracotta
fill 407 137 604 408 137 604 minecraft:red_concrete
setblock 411 137 646 minecraft:red_concrete
fill 418 137 610 418 140 610 minecraft:purple_terracotta
setblock 418 137 614 minecraft:red_concrete
fill 418 137 621 418 140 621 minecraft:purple_terracotta
setblock 418 137 622 minecraft:red_concrete
setblock 418 137 625 minecraft:red_concrete
fill 418 137 641 418 140 642 minecraft:purple_terracotta
fill 376 138 607 376 139 607 minecraft:red_concrete
fill 376 138 608 376 143 609 minecraft:purple_terracotta
setblock 376 138 610 minecraft:red_concrete
fill 376 138 612 376 140 612 minecraft:purple_terracotta
fill 376 138 618 376 139 619 minecraft:red_concrete
fill 376 138 620 376 143 621 minecraft:purple_terracotta
setblock 376 138 626 minecraft:purple_terracotta
fill 376 138 627 376 139 627 minecraft:red_concrete
fill 376 138 629 376 143 629 minecraft:purple_terracotta
fill 376 138 630 376 138 631 minecraft:red_concrete
fill 376 138 632 376 140 633 minecraft:purple_terracotta
fill 376 138 638 376 139 639 minecraft:red_concrete
fill 376 138 640 376 143 641 minecraft:purple_terracotta
setblock 376 138 642 minecraft:red_concrete
fill 376 138 643 376 141 643 minecraft:purple_terracotta
fill 377 138 604 378 139 604 minecraft:red_concrete
fill 377 138 605 379 138 605 minecraft:polished_blackstone
fill 377 138 607 377 138 609 minecraft:polished_blackstone
fill 377 138 611 377 138 613 minecraft:polished_blackstone
fill 377 138 615 377 138 617 minecraft:polished_blackstone
fill 377 138 619 377 138 621 minecraft:polished_blackstone
fill 377 138 623 377 138 625 minecraft:polished_blackstone
fill 377 138 627 377 138 629 minecraft:polished_blackstone
fill 377 138 631 377 138 633 minecraft:polished_blackstone
fill 377 138 635 377 138 637 minecraft:polished_blackstone
fill 377 138 639 377 138 641 minecraft:polished_blackstone
fill 377 138 643 377 138 645 minecraft:polished_blackstone
setblock 379 138 607 minecraft:light[level=12]
setblock 379 138 615 minecraft:light[level=12]
setblock 379 138 623 minecraft:light[level=12]
setblock 379 138 631 minecraft:light[level=12]
setblock 379 138 639 minecraft:light[level=12]
fill 379 138 645 381 138 645 minecraft:polished_blackstone
fill 380 138 646 381 138 646 minecraft:red_concrete
fill 381 138 605 383 138 605 minecraft:polished_blackstone
fill 382 138 646 383 143 646 minecraft:purple_terracotta
fill 383 138 604 384 143 604 minecraft:purple_terracotta
fill 383 138 645 385 138 645 minecraft:polished_blackstone
fill 385 138 604 386 138 604 minecraft:red_concrete
fill 385 138 605 387 138 605 minecraft:polished_blackstone
fill 387 138 604 387 143 604 minecraft:purple_terracotta
setblock 387 138 607 minecraft:light[level=12]
setblock 387 138 615 minecraft:light[level=12]
setblock 387 138 623 minecraft:light[level=12]
setblock 387 138 631 minecraft:light[level=12]
setblock 387 138 639 minecraft:light[level=12]
fill 387 138 645 389 138 645 minecraft:polished_blackstone
fill 389 138 605 391 138 605 minecraft:polished_blackstone
fill 389 138 646 389 139 646 minecraft:red_concrete
fill 390 138 646 391 143 646 minecraft:purple_terracotta
fill 391 138 645 393 138 645 minecraft:polished_blackstone
setblock 392 138 646 minecraft:red_concrete
fill 393 138 605 395 138 605 minecraft:polished_blackstone
fill 394 138 646 394 143 646 minecraft:purple_terracotta
fill 395 138 604 396 143 604 minecraft:purple_terracotta
setblock 395 138 607 minecraft:light[level=12]
setblock 395 138 615 minecraft:light[level=12]
setblock 395 138 623 minecraft:light[level=12]
setblock 395 138 631 minecraft:light[level=12]
setblock 395 138 639 minecraft:light[level=12]
fill 395 138 645 397 138 645 minecraft:polished_blackstone
fill 397 138 604 398 139 604 minecraft:red_concrete
fill 397 138 605 399 138 605 minecraft:polished_blackstone
fill 399 138 645 401 138 645 minecraft:polished_blackstone
fill 400 138 646 401 139 646 minecraft:red_concrete
fill 401 138 605 403 138 605 minecraft:polished_blackstone
fill 402 138 646 403 143 646 minecraft:purple_terracotta
setblock 403 138 607 minecraft:light[level=12]
setblock 403 138 615 minecraft:light[level=12]
setblock 403 138 623 minecraft:light[level=12]
setblock 403 138 631 minecraft:light[level=12]
setblock 403 138 639 minecraft:light[level=12]
fill 403 138 645 405 138 645 minecraft:polished_blackstone
fill 404 138 604 404 143 604 minecraft:purple_terracotta
fill 405 138 605 407 138 605 minecraft:polished_blackstone
setblock 406 138 604 minecraft:red_concrete
fill 407 138 604 408 143 604 minecraft:purple_terracotta
fill 407 138 645 409 138 645 minecraft:polished_blackstone
fill 409 138 604 409 139 604 minecraft:red_concrete
fill 409 138 605 411 138 605 minecraft:polished_blackstone
setblock 411 138 607 minecraft:light[level=12]
setblock 411 138 615 minecraft:light[level=12]
setblock 411 138 623 minecraft:light[level=12]
setblock 411 138 631 minecraft:light[level=12]
setblock 411 138 639 minecraft:light[level=12]
fill 411 138 645 413 138 645 minecraft:polished_blackstone
fill 411 138 646 411 143 646 minecraft:purple_terracotta
fill 412 138 646 413 138 646 minecraft:red_concrete
fill 413 138 605 415 138 605 minecraft:polished_blackstone
fill 414 138 646 415 143 646 minecraft:purple_terracotta
fill 415 138 604 416 143 604 minecraft:purple_terracotta
fill 415 138 645 417 138 645 minecraft:polished_blackstone
fill 417 138 604 418 138 604 minecraft:red_concrete
fill 417 138 605 417 138 607 minecraft:polished_blackstone
fill 417 138 609 417 138 611 minecraft:polished_blackstone
fill 417 138 613 417 138 615 minecraft:polished_blackstone
fill 417 138 617 417 138 619 minecraft:polished_blackstone
fill 417 138 621 417 138 623 minecraft:polished_blackstone
fill 417 138 625 417 138 627 minecraft:polished_blackstone
fill 417 138 629 417 138 631 minecraft:polished_blackstone
fill 417 138 633 417 138 635 minecraft:polished_blackstone
fill 417 138 637 417 138 639 minecraft:polished_blackstone
fill 417 138 641 417 138 643 minecraft:polished_blackstone
fill 418 138 613 418 143 614 minecraft:purple_terracotta
fill 418 138 615 418 139 616 minecraft:red_concrete
fill 418 138 622 418 143 622 minecraft:purple_terracotta
fill 418 138 623 418 138 624 minecraft:red_concrete
fill 418 138 625 418 143 625 minecraft:purple_terracotta
fill 418 138 627 418 139 627 minecraft:red_concrete
fill 418 138 633 418 143 634 minecraft:purple_terracotta
fill 418 138 635 418 139 636 minecraft:red_concrete
setblock 418 138 644 minecraft:red_concrete
fill 418 138 645 418 143 645 minecraft:purple_terracotta
setblock 376 139 606 minecraft:red_concrete
fill 376 139 610 376 142 610 minecraft:purple_terracotta
fill 376 139 614 376 141 614 minecraft:purple_terracotta
setblock 376 139 615 minecraft:red_concrete
setblock 376 139 626 minecraft:red_concrete
setblock 376 139 630 minecraft:red_concrete
fill 376 139 631 376 142 631 minecraft:purple_terracotta
fill 376 139 642 376 141 642 minecraft:purple_terracotta
setblock 377 139 646 minecraft:red_concrete
setblock 380 139 646 minecraft:red_concrete
fill 381 139 646 381 142 646 minecraft:purple_terracotta
fill 385 139 604 385 142 604 minecraft:purple_terracotta
setblock 386 139 604 minecraft:red_concrete
setblock 388 139 646 minecraft:red_concrete
fill 389 139 604 390 139 604 minecraft:red_concrete
fill 392 139 646 392 142 646 minecraft:purple_terracotta
fill 406 139 604 406 142 604 minecraft:purple_terracotta
fill 408 139 646 409 139 646 minecraft:red_concrete
setblock 410 139 604 minecraft:red_concrete
setblock 412 139 646 minecraft:red_concrete
fill 413 139 646 413 142 646 minecraft:purple_terracotta
fill 417 139 604 417 142 604 minecraft:purple_terracotta
setblock 418 139 604 minecraft:red_concrete
setblock 418 139 607 minecraft:red_concrete
fill 418 139 623 418 142 624 minecraft:purple_terracotta
setblock 418 139 628 minecraft:red_concrete
setblock 418 139 639 minecraft:red_concrete
fill 418 139 644 418 142 644 minecraft:purple_terracotta
fill 376 140 604 376 141 605 minecraft:red_concrete
fill 376 140 606 376 145 607 minecraft:purple_terracotta
fill 376 140 615 376 141 615 minecraft:purple_terracotta
fill 376 140 616 376 140 617 minecraft:red_concrete
fill 376 140 618 376 145 619 minecraft:purple_terracotta
fill 376 140 624 376 141 625 minecraft:red_concrete
fill 376 140 626 376 145 627 minecraft:purple_terracotta
setblock 376 140 628 minecraft:red_concrete
fill 376 140 630 376 142 630 minecraft:purple_terracotta
fill 376 140 636 376 141 637 minecraft:red_concrete
fill 376 140 638 376 145 639 minecraft:purple_terracotta
setblock 376 140 644 minecraft:purple_terracotta
fill 376 140 645 376 141 645 minecraft:red_concrete
fill 377 140 604 378 145 604 minecraft:purple_terracotta
fill 377 140 646 377 145 646 minecraft:purple_terracotta
fill 378 140 646 379 140 646 minecraft:red_concrete
fill 379 140 604 380 141 604 minecraft:red_concrete
fill 380 140 646 380 145 646 minecraft:purple_terracotta
fill 382 140 617 383 141 618 minecraft:magma_block
fill 386 140 604 386 145 604 minecraft:purple_terracotta
fill 386 140 646 387 141 646 minecraft:red_concrete
setblock 388 140 604 minecraft:red_concrete
fill 388 140 646 389 145 646 minecraft:purple_terracotta
fill 389 140 604 390 145 604 minecraft:purple_terracotta
fill 391 140 604 391 141 604 minecraft:red_concrete
fill 397 140 604 398 145 604 minecraft:purple_terracotta
fill 398 140 646 399 140 646 minecraft:red_concrete
fill 399 140 604 400 140 604 minecraft:red_concrete
fill 400 140 646 401 145 646 minecraft:purple_terracotta
fill 407 140 646 407 141 646 minecraft:red_concrete
fill 408 140 646 409 145 646 minecraft:purple_terracotta
fill 409 140 604 410 145 604 minecraft:purple_terracotta
setblock 410 140 646 minecraft:red_concrete
fill 411 140 604 412 141 604 minecraft:red_concrete
fill 412 140 646 412 145 646 minecraft:purple_terracotta
fill 418 140 604 418 145 604 minecraft:purple_terracotta
fill 418 140 605 418 140 606 minecraft:red_concrete
fill 418 140 607 418 145 607 minecraft:purple_terracotta
fill 418 140 609 418 141 609 minecraft:red_concrete
fill 418 140 615 418 145 616 minecraft:purple_terracotta
fill 418 140 617 418 141 618 minecraft:red_concrete
setblock 418 140 626 minecraft:red_concrete
fill 418 140 627 418 145 628 minecraft:purple_terracotta
fill 418 140 629 418 141 630 minecraft:red_concrete
fill 418 140 635 418 145 636 minecraft:purple_terracotta
fill 418 140 637 418 140 638 minecraft:red_concrete
fill 418 140 639 418 145 639 minecraft:purple_terracotta
fill 418 140 646 418 141 646 minecraft:red_concrete
fill 376 141 612 376 141 613 minecraft:red_concrete
setblock 376 141 616 minecraft:red_concrete
fill 376 141 617 376 144 617 minecraft:purple_terracotta
fill 376 141 628 376 144 628 minecraft:purple_terracotta
fill 376 141 632 376 143 632 minecraft:purple_terracotta
setblock 376 141 633 minecraft:red_concrete
setblock 376 141 644 minecraft:red_concrete
fill 378 141 646 379 144 646 minecraft:purple_terracotta
fill 388 141 604 388 144 604 minecraft:purple_terracotta
setblock 392 141 604 minecraft:red_concrete
setblock 395 141 646 minecraft:red_concrete
setblock 398 141 646 minecraft:red_concrete
fill 399 141 604 399 144 604 minecraft:purple_terracotta
fill 399 141 646 399 144 646 minecraft:purple_terracotta
setblock 400 141 604 minecraft:red_concrete
setblock 403 141 604 minecraft:red_concrete
setblock 406 141 646 minecraft:red_concrete
fill 410 141 646 410 144 646 minecraft:purple_terracotta
fill 418 141 605 418 144 606 minecraft:purple_terracotta
setblock 418 141 610 minecraft:red_concrete
setblock 418 141 621 minecraft:red_concrete
fill 418 141 626 418 144 626 minecraft:purple_terracotta
fill 418 141 637 418 144 637 minecraft:purple_terracotta
setblock 418 141 638 minecraft:red_concrete
fill 418 141 641 418 141 642 minecraft:red_concrete
fill 376 142 604 376 147 605 minecraft:purple_terracotta
fill 376 142 611 376 143 611 minecraft:red_concrete
fill 376 142 612 376 143 613 minecraft:purple_terracotta
fill 376 142 614 376 142 615 minecraft:red_concrete
fill 376 142 616 376 147 616 minecraft:purple_terracotta
fill 376 142 622 376 143 623 minecraft:red_concrete
fill 376 142 624 376 147 625 minecraft:purple_terracotta
fill 376 142 633 376 143 633 minecraft:purple_terracotta
fill 376 142 634 376 142 635 minecraft:red_concrete
fill 376 142 636 376 147 637 minecraft:purple_terracotta
fill 376 142 642 376 143 643 minecraft:red_concrete
fill 376 142 644 376 147 645 minecraft:purple_terracotta
setblock 376 142 646 minecraft:red_concrete
fill 379 142 604 380 147 604 minecraft:purple_terracotta
fill 381 142 604 382 142 604 minecraft:red_concrete
fill 384 142 646 385 143 646 minecraft:red_concrete
fill 386 142 646 387 147 646 minecraft:purple_terracotta
fill 391 142 604 392 147 604 minecraft:purple_terracotta
fill 393 142 604 394 143 604 minecraft:red_concrete
fill 393 142 646 393 143 646 minecraft:red_concrete
fill 395 142 646 395 147 646 minecraft:purple_terracotta
fill 396 142 646 397 142 646 minecraft:red_concrete
fill 398 142 646 398 147 646 minecraft:purple_terracotta
fill 400 142 604 400 147 604 minecraft:purple_terracotta
fill 401 142 604 402 142 604 minecraft:red_concrete
fill 403 142 604 403 147 604 minecraft:purple_terracotta
fill 404 142 646 405 143 646 minecraft:red_concrete
fill 405 142 604 405 143 604 minecraft:red_concrete
fill 406 142 646 407 147 646 minecraft:purple_terracotta
fill 411 142 604 412 147 604 minecraft:purple_terracotta
fill 413 142 604 414 143 604 minecraft:red_concrete
fill 416 142 646 417 142 646 minecraft:red_concrete
setblock 418 142 608 minecraft:red_concrete
fill 418 142 609 418 147 610 minecraft:purple_terracotta
fill 418 142 611 418 143 612 minecraft:red_concrete
fill 418 142 617 418 147 618 minecraft:purple_terracotta
fill 418 142 619 418 142 620 minecraft:red_concrete
fill 418 142 621 418 147 621 minecraft:purple_terracotta
fill 418 142 629 418 147 630 minecraft:purple_terracotta
fill 418 142 631 418 143 632 minecraft:red_concrete
fill 418 142 638 418 147 638 minecraft:purple_terracotta
setblock 418 142 640 minecraft:red_concrete
fill 418 142 641 418 147 642 minecraft:purple_terracotta
fill 418 142 643 418 143 643 minecraft:red_concrete
fill 418 142 646 418 147 646 minecraft:purple_terracotta
setblock 376 143 610 minecraft:red_concrete
fill 376 143 614 376 145 615 minecraft:purple_terracotta
fill 376 143 630 376 143 631 minecraft:red_concrete
setblock 376 143 634 minecraft:red_concrete
fill 376 143 635 376 146 635 minecraft:purple_terracotta
fill 376 143 646 376 146 646 minecraft:purple_terracotta
fill 381 143 604 381 146 604 minecraft:purple_terracotta
setblock 381 143 646 minecraft:red_concrete
setblock 382 143 604 minecraft:red_concrete
setblock 385 143 604 minecraft:red_concrete
setblock 392 143 646 minecraft:red_concrete
fill 396 143 646 397 146 646 minecraft:purple_terracotta
fill 401 143 604 402 146 604 minecraft:purple_terracotta
setblock 406 143 604 minecraft:red_concrete
setblock 413 143 646 minecraft:red_concrete
setblock 416 143 646 minecraft:red_concrete
setblock 417 143 604 minecraft:red_concrete
fill 417 143 646 417 146 646 minecraft:purple_terracotta
fill 418 143 608 418 146 608 minecraft:purple_terracotta
fill 418 143 619 418 146 619 minecraft:purple_terracotta
setblock 418 143 620 minecraft:red_concrete
fill 418 143 623 418 143 624 minecraft:red_concrete
fill 418 143 640 418 146 640 minecraft:purple_terracotta
setblock 418 143 644 minecraft:red_concrete
fill 376 144 608 376 145 609 minecraft:red_concrete
fill 376 144 610 376 149 611 minecraft:purple_terracotta
setblock 376 144 612 minecraft:red_concrete
fill 376 144 613 376 147 613 minecraft:purple_terracotta
fill 376 144 620 376 145 621 minecraft:red_concrete
fill 376 144 622 376 149 623 minecraft:purple_terracotta
fill 376 144 629 376 145 629 minecraft:red_concrete
fill 376 144 630 376 145 631 minecraft:purple_terracotta
fill 376 144 632 376 144 633 minecraft:red_concrete
fill 376 144 634 376 149 634 minecraft:purple_terracotta
fill 376 144 640 376 145 641 minecraft:red_concrete
fill 376 144 642 376 149 643 minecraft:purple_terracotta
fill 377 144 605 379 144 605 minecraft:polished_blackstone
fill 377 144 607 377 144 609 minecraft:polished_blackstone
fill 377 144 611 377 144 613 minecraft:polished_blackstone
fill 377 144 615 377 144 617 minecraft:polished_blackstone
fill 377 144 619 377 144 621 minecraft:polished_blackstone
fill 377 144 623 377 144 625 minecraft:polished_blackstone
fill 377 144 627 377 144 629 minecraft:polished_blackstone
fill 377 144 631 377 144 633 minecraft:polished_blackstone
fill 377 144 635 377 144 637 minecraft:polished_blackstone
fill 377 144 639 377 144 641 minecraft:polished_blackstone
fill 377 144 643 377 144 645 minecraft:polished_blackstone
fill 379 144 645 381 144 645 minecraft:polished_blackstone
fill 381 144 605 383 144 605 minecraft:polished_blackstone
fill 381 144 646 381 149 646 minecraft:purple_terracotta
fill 382 144 604 382 149 604 minecraft:purple_terracotta
fill 382 144 646 383 144 646 minecraft:red_concrete
fill 383 144 604 384 144 604 minecraft:red_concrete
fill 383 144 645 385 144 645 minecraft:polished_blackstone
fill 384 144 646 385 149 646 minecraft:purple_terracotta
fill 385 144 604 385 149 604 minecraft:purple_terracotta
fill 385 144 605 387 144 605 minecraft:polished_blackstone
fill 387 144 604 387 145 604 minecraft:red_concrete
fill 387 144 645 389 144 645 minecraft:polished_blackstone
fill 389 144 605 391 144 605 minecraft:polished_blackstone
fill 390 144 646 391 145 646 minecraft:red_concrete
fill 391 144 645 393 144 645 minecraft:polished_blackstone
fill 392 144 646 393 149 646 minecraft:purple_terracotta
fill 393 144 604 394 149 604 minecraft:purple_terracotta
fill 393 144 605 395 144 605 minecraft:polished_blackstone
setblock 394 144 646 minecraft:red_concrete
fill 395 144 604 396 145 604 minecraft:red_concrete
fill 395 144 645 397 144 645 minecraft:polished_blackstone
fill 397 144 605 399 144 605 minecraft:polished_blackstone
fill 399 144 645 401 144 645 minecraft:polished_blackstone
fill 401 144 605 403 144 605 minecraft:polished_blackstone
fill 402 144 646 403 145 646 minecraft:red_concrete
fill 403 144 645 405 144 645 minecraft:polished_blackstone
setblock 404 144 604 minecraft:red_concrete
fill 404 144 646 405 149 646 minecraft:purple_terracotta
fill 405 144 604 406 149 604 minecraft:purple_terracotta
fill 405 144 605 407 144 605 minecraft:polished_blackstone
fill 407 144 604 408 145 604 minecraft:red_concrete
fill 407 144 645 409 144 645 minecraft:polished_blackstone
fill 409 144 605 411 144 605 minecraft:polished_blackstone
fill 411 144 645 413 144 645 minecraft:polished_blackstone
fill 411 144 646 411 145 646 minecraft:red_concrete
fill 413 144 604 414 149 604 minecraft:purple_terracotta
fill 413 144 605 415 144 605 minecraft:polished_blackstone
fill 413 144 646 413 149 646 minecraft:purple_terracotta
fill 414 144 646 415 144 646 minecraft:red_concrete
fill 415 144 604 416 144 604 minecraft:red_concrete
fill 415 144 645 417 144 645 minecraft:polished_blackstone
fill 416 144 646 416 149 646 minecraft:purple_terracotta
fill 417 144 604 417 149 604 minecraft:purple_terracotta
fill 417 144 605 417 144 607 minecraft:polished_blackstone
fill 417 144 609 417 144 611 minecraft:polished_blackstone
fill 417 144 613 417 144 615 minecraft:polished_blackstone
fill 417 144 617 417 144 619 minecraft:polished_blackstone
fill 417 144 621 417 144 623 minecraft:polished_blackstone
fill 417 144 625 417 144 627 minecraft:polished_blackstone
fill 417 144 629 417 144 631 minecraft:polished_blackstone
fill 417 144 633 417 144 635 minecraft:polished_blackstone
fill 417 144 637 417 144 639 minecraft:polished_blackstone
fill 417 144 641 417 144 643 minecraft:polished_blackstone
fill 418 144 611 418 149 612 minecraft:purple_terracotta
fill 418 144 613 418 145 614 minecraft:red_concrete
fill 418 144 620 418 149 620 minecraft:purple_terracotta
setblock 418 144 622 minecraft:red_concrete
fill 418 144 623 418 149 624 minecraft:purple_terracotta
fill 418 144 625 418 145 625 minecraft:red_concrete
fill 418 144 631 418 149 632 minecraft:purple_terracotta
fill 418 144 633 418 144 634 minecraft:red_concrete
fill 418 144 643 418 149 644 minecraft:purple_terracotta
fill 418 144 645 418 145 645 minecraft:red_concrete
fill 376 145 612 376 147 612 minecraft:purple_terracotta
setblock 376 145 617 minecraft:red_concrete
setblock 376 145 628 minecraft:red_concrete
fill 376 145 632 376 147 633 minecraft:purple_terracotta
fill 378 145 646 379 145 646 minecraft:red_concrete
setblock 382 145 646 minecraft:red_concrete
fill 383 145 604 384 148 604 minecraft:purple_terracotta
fill 383 145 646 383 148 646 minecraft:purple_terracotta
setblock 388 145 604 minecraft:red_concrete
fill 388 145 612 389 146 613 minecraft:blackstone
fill 394 145 646 394 148 646 minecraft:purple_terracotta
setblock 399 145 604 minecraft:red_concrete
setblock 399 145 646 minecraft:red_concrete
fill 400 145 608 400 146 608 minecraft:red_concrete
fill 404 145 604 404 148 604 minecraft:purple_terracotta
setblock 410 145 646 minecraft:red_concrete
fill 414 145 646 415 148 646 minecraft:purple_terracotta
fill 415 145 604 415 148 604 minecraft:purple_terracotta
setblock 416 145 604 minecraft:red_concrete
fill 418 145 605 418 145 606 minecraft:red_concrete
fill 418 145 622 418 148 622 minecraft:purple_terracotta
setblock 418 145 626 minecraft:red_concrete
fill 418 145 633 418 148 633 minecraft:purple_terracotta
setblock 418 145 634 minecraft:red_concrete
setblock 418 145 637 minecraft:red_concrete
fill 376 146 606 376 147 607 minecraft:red_concrete
fill 376 146 608 376 163 609 minecraft:purple_terracotta
setblock 376 146 614 minecraft:purple_terracotta
fill 376 146 615 376 147 615 minecraft:red_concrete
fill 376 146 617 376 167 617 minecraft:purple_terracotta
fill 376 146 618 376 146 619 minecraft:red_concrete
fill 376 146 620 376 148 621 minecraft:purple_terracotta
fill 376 146 626 376 147 627 minecraft:red_concrete
fill 376 146 628 376 164 629 minecraft:purple_terracotta
setblock 376 146 630 minecraft:red_concrete
fill 376 146 631 376 149 631 minecraft:purple_terracotta
fill 376 146 638 376 146 639 minecraft:red_concrete
fill 376 146 640 376 163 641 minecraft:purple_terracotta
fill 377 146 604 378 147 604 minecraft:red_concrete
fill 377 146 646 377 147 646 minecraft:red_concrete
fill 378 146 646 379 167 646 minecraft:purple_terracotta
setblock 379 146 607 minecraft:light[level=12]
setblock 379 146 615 minecraft:light[level=12]
setblock 379 146 623 minecraft:light[level=12]
setblock 379 146 631 minecraft:light[level=12]
setblock 379 146 639 minecraft:light[level=12]
setblock 380 146 646 minecraft:red_concrete
fill 382 146 646 382 163 646 minecraft:purple_terracotta
setblock 386 146 604 minecraft:red_concrete
fill 387 146 604 388 164 604 minecraft:purple_terracotta
setblock 387 146 607 minecraft:light[level=12]
setblock 387 146 615 minecraft:light[level=12]
setblock 387 146 623 minecraft:light[level=12]
setblock 387 146 631 minecraft:light[level=12]
setblock 387 146 639 minecraft:light[level=12]
fill 388 146 646 389 147 646 minecraft:red_concrete
fill 389 146 604 390 147 604 minecraft:red_concrete
fill 390 146 646 391 164 646 minecraft:purple_terracotta
fill 395 146 604 396 163 604 minecraft:purple_terracotta
setblock 395 146 607 minecraft:light[level=12]
setblock 395 146 615 minecraft:light[level=12]
setblock 395 146 623 minecraft:light[level=12]
setblock 395 146 631 minecraft:light[level=12]
setblock 395 146 639 minecraft:light[level=12]
fill 397 146 604 398 146 604 minecraft:red_concrete
fill 399 146 604 399 167 604 minecraft:purple_terracotta
fill 399 146 646 399 167 646 minecraft:purple_terracotta
fill 400 146 646 401 146 646 minecraft:red_concrete
fill 402 146 646 403 163 646 minecraft:purple_terracotta
setblock 403 146 607 minecraft:light[level=12]
setblock 403 146 615 minecraft:light[level=12]
setblock 403 146 623 minecraft:light[level=12]
setblock 403 146 631 minecraft:light[level=12]
setblock 403 146 639 minecraft:light[level=12]
fill 407 146 604 408 164 604 minecraft:purple_terracotta
fill 408 146 646 409 147 646 minecraft:red_concrete
fill 409 146 604 410 147 604 minecraft:red_concrete
fill 410 146 646 411 164 646 minecraft:purple_terracotta
setblock 411 146 607 minecraft:light[level=12]
setblock 411 146 615 minecraft:light[level=12]
setblock 411 146 623 minecraft:light[level=12]
setblock 411 146 631 minecraft:light[level=12]
setblock 411 146 639 minecraft:light[level=12]
setblock 412 146 646 minecraft:red_concrete
fill 416 146 604 416 163 604 minecraft:purple_terracotta
setblock 418 146 604 minecraft:red_concrete
fill 418 146 605 418 167 606 minecraft:purple_terracotta
fill 418 146 607 418 147 607 minecraft:red_concrete
fill 418 146 613 418 163 614 minecraft:purple_terracotta
fill 418 146 615 418 146 616 minecraft:red_concrete
fill 418 146 625 418 164 626 minecraft:purple_terracotta
fill 418 146 627 418 147 628 minecraft:red_concrete
fill 418 146 634 418 163 634 minecraft:purple_terracotta
fill 418 146 635 418 146 636 minecraft:red_concrete
fill 418 146 637 418 167 637 minecraft:purple_terracotta
fill 418 146 639 418 147 639 minecraft:red_concrete
fill 418 146 645 418 163 645 minecraft:purple_terracotta
setblock 376 147 614 minecraft:red_concrete
setblock 376 147 618 minecraft:red_concrete
fill 376 147 619 376 150 619 minecraft:purple_terracotta
fill 376 147 630 376 149 630 minecraft:purple_terracotta
setblock 376 147 635 minecraft:red_concrete
setblock 376 147 638 minecraft:red_concrete
fill 376 147 639 376 150 639 minecraft:purple_terracotta
setblock 376 147 646 minecraft:red_concrete
fill 380 147 646 380 150 646 minecraft:purple_terracotta
setblock 381 147 604 minecraft:red_concrete
fill 386 147 604 386 150 604 minecraft:purple_terracotta
fill 396 147 646 397 147 646 minecraft:red_concrete
fill 397 147 604 397 150 604 minecraft:purple_terracotta
setblock 398 147 604 minecraft:red_concrete
setblock 400 147 646 minecraft:red_concrete
fill 401 147 604 402 147 604 minecraft:red_concrete
fill 401 147 646 401 150 646 minecraft:purple_terracotta
fill 412 147 646 412 150 646 minecraft:purple_terracotta
setblock 417 147 646 minecraft:red_concrete
fill 418 147 604 418 150 604 minecraft:purple_terracotta
setblock 418 147 608 minecraft:red_concrete
fill 418 147 615 418 150 615 minecraft:purple_terracotta
setblock 418 147 616 minecraft:red_concrete
setblock 418 147 619 minecraft:red_concrete
fill 418 147 635 418 150 636 minecraft:purple_terracotta
setblock 418 147 640 minecraft:red_concrete
fill 376 148 604 376 148 605 minecraft:red_concrete
fill 376 148 606 376 161 607 minecraft:purple_terracotta
fill 376 148 612 376 149 613 minecraft:red_concrete
fill 376 148 614 376 161 615 minecraft:purple_terracotta
setblock 376 148 616 minecraft:red_concrete
fill 376 148 618 376 150 618 minecraft:purple_terracotta
fill 376 148 624 376 149 625 minecraft:red_concrete
fill 376 148 626 376 161 627 minecraft:purple_terracotta
setblock 376 148 632 minecraft:purple_terracotta
fill 376 148 633 376 149 633 minecraft:red_concrete
fill 376 148 635 376 161 635 minecraft:purple_terracotta
fill 376 148 636 376 148 637 minecraft:red_concrete
fill 376 148 638 376 165 638 minecraft:purple_terracotta
fill 376 148 644 376 149 645 minecraft:red_concrete
fill 376 148 646 377 161 646 minecraft:purple_terracotta
fill 377 148 604 378 165 604 minecraft:purple_terracotta
fill 379 148 604 380 148 604 minecraft:red_concrete
fill 381 148 604 381 161 604 minecraft:purple_terracotta
fill 386 148 646 387 148 646 minecraft:red_concrete
fill 388 148 646 389 161 646 minecraft:purple_terracotta
fill 389 148 604 390 161 604 minecraft:purple_terracotta
fill 391 148 604 392 149 604 minecraft:red_concrete
fill 395 148 646 395 149 646 minecraft:red_concrete
fill 396 148 646 397 161 646 minecraft:purple_terracotta
fill 398 148 604 398 165 604 minecraft:purple_terracotta
setblock 398 148 646 minecraft:red_concrete
setblock 400 148 604 minecraft:red_concrete
fill 400 148 646 400 165 646 minecraft:purple_terracotta
fill 401 148 604 402 161 604 minecraft:purple_terracotta
fill 403 148 604 403 149 604 minecraft:red_concrete
fill 406 148 646 407 149 646 minecraft:red_concrete
fill 408 148 646 409 161 646 minecraft:purple_terracotta
fill 409 148 604 410 161 604 minecraft:purple_terracotta
fill 411 148 604 412 148 604 minecraft:red_concrete
fill 417 148 646 417 161 646 minecraft:purple_terracotta
fill 418 148 607 418 161 608 minecraft:purple_terracotta
fill 418 148 609 418 149 610 minecraft:red_concrete
fill 418 148 616 418 165 616 minecraft:purple_terracotta
fill 418 148 617 418 148 618 minecraft:red_concrete
fill 418 148 619 418 161 619 minecraft:purple_terracotta
fill 418 148 621 418 149 621 minecraft:red_concrete
fill 418 148 627 418 161 628 minecraft:purple_terracotta
fill 418 148 629 418 149 630 minecraft:red_concrete
setblock 418 148 638 minecraft:red_concrete
fill 418 148 639 418 161 640 minecraft:purple_terracotta
fill 418 148 641 418 149 642 minecraft:red_concrete
fill 418 148 646 418 149 646 minecraft:red_concrete
setblock 376 149 604 minecraft:red_concrete
fill 376 149 605 376 167 605 minecraft:purple_terracotta
fill 376 149 616 376 167 616 minecraft:purple_terracotta
fill 376 149 620 376 163 620 minecraft:purple_terracotta
setblock 376 149 621 minecraft:red_concrete
setblock 376 149 632 minecraft:red_concrete
fill 376 149 636 376 167 637 minecraft:purple_terracotta
fill 379 149 604 379 167 604 minecraft:purple_terracotta
setblock 380 149 604 minecraft:red_concrete
fill 383 149 604 384 149 604 minecraft:red_concrete
setblock 383 149 646 minecraft:red_concrete
fill 385 149 620 386 150 621 minecraft:red_concrete
setblock 386 149 646 minecraft:red_concrete
fill 387 149 620 387 150 620 minecraft:red_concrete
fill 387 149 646 387 167 646 minecraft:purple_terracotta
setblock 394 149 646 minecraft:red_concrete
fill 398 149 646 398 167 646 minecraft:purple_terracotta
fill 400 149 604 400 167 604 minecraft:purple_terracotta
setblock 404 149 604 minecraft:red_concrete
fill 411 149 604 411 167 604 minecraft:purple_terracotta
setblock 412 149 604 minecraft:red_concrete
fill 414 149 646 415 149 646 minecraft:red_concrete
setblock 415 149 604 minecraft:red_concrete
fill 418 149 617 418 167 618 minecraft:purple_terracotta
setblock 418 149 622 minecraft:red_concrete
setblock 418 149 633 minecraft:red_concrete
fill 418 149 638 418 167 638 minecraft:purple_terracotta
fill 376 150 604 376 167 604 minecraft:purple_terracotta
fill 376 150 610 376 151 611 minecraft:red_concrete
fill 376 150 612 376 163 613 minecraft:purple_terracotta
fill 376 150 621 376 163 621 minecraft:purple_terracotta
fill 376 150 622 376 150 623 minecraft:red_concrete
fill 376 150 624 376 167 625 minecraft:purple_terracotta
fill 376 150 630 376 151 631 minecraft:red_concrete
fill 376 150 632 376 163 633 minecraft:purple_terracotta
setblock 376 150 634 minecraft:red_concrete
fill 376 150 642 376 151 643 minecraft:red_concrete
fill 376 150 644 376 163 645 minecraft:purple_terracotta
fill 377 150 605 379 150 605 minecraft:polished_blackstone
fill 377 150 607 377 150 609 minecraft:polished_blackstone
fill 377 150 611 377 150 613 minecraft:polished_blackstone
fill 377 150 615 377 150 617 minecraft:polished_blackstone
fill 377 150 619 377 150 621 minecraft:polished_blackstone
fill 377 150 623 377 150 625 minecraft:polished_blackstone
fill 377 150 627 377 150 629 minecraft:polished_blackstone
fill 377 150 631 377 150 633 minecraft:polished_blackstone
fill 377 150 635 377 150 637 minecraft:polished_blackstone
fill 377 150 639 377 150 641 minecraft:polished_blackstone
fill 377 150 643 377 150 645 minecraft:polished_blackstone
fill 379 150 645 381 150 645 minecraft:polished_blackstone
fill 380 150 604 380 167 604 minecraft:purple_terracotta
fill 381 150 605 383 150 605 minecraft:polished_blackstone
fill 381 150 646 381 151 646 minecraft:red_concrete
setblock 382 150 604 minecraft:red_concrete
fill 383 150 604 384 163 604 minecraft:purple_terracotta
fill 383 150 645 385 150 645 minecraft:polished_blackstone
fill 383 150 646 383 163 646 minecraft:purple_terracotta
fill 384 150 646 385 150 646 minecraft:red_concrete
fill 385 150 604 385 151 604 minecraft:red_concrete
fill 385 150 605 387 150 605 minecraft:polished_blackstone
fill 386 150 646 386 167 646 minecraft:purple_terracotta
fill 387 150 645 389 150 645 minecraft:polished_blackstone
fill 389 150 605 391 150 605 minecraft:polished_blackstone
fill 391 150 604 392 163 604 minecraft:purple_terracotta
fill 391 150 645 393 150 645 minecraft:polished_blackstone
fill 392 150 646 393 151 646 minecraft:red_concrete
fill 393 150 604 394 150 604 minecraft:red_concrete
fill 393 150 605 395 150 605 minecraft:polished_blackstone
fill 394 150 646 395 163 646 minecraft:purple_terracotta
fill 395 150 645 397 150 645 minecraft:polished_blackstone
fill 396 150 636 396 151 636 minecraft:blackstone
fill 397 150 605 399 150 605 minecraft:polished_blackstone
fill 399 150 645 401 150 645 minecraft:polished_blackstone
fill 401 150 605 403 150 605 minecraft:polished_blackstone
fill 403 150 604 404 163 604 minecraft:purple_terracotta
fill 403 150 645 405 150 645 minecraft:polished_blackstone
fill 404 150 646 405 150 646 minecraft:red_concrete
fill 405 150 604 406 151 604 minecraft:red_concrete
fill 405 150 605 407 150 605 minecraft:polished_blackstone
fill 406 150 646 407 163 646 minecraft:purple_terracotta
fill 407 150 645 409 150 645 minecraft:polished_blackstone
fill 409 150 605 411 150 605 minecraft:polished_blackstone
fill 411 150 645 413 150 645 minecraft:polished_blackstone
fill 412 150 604 412 167 604 minecraft:purple_terracotta
fill 413 150 604 414 150 604 minecraft:red_concrete
fill 413 150 605 415 150 605 minecraft:polished_blackstone
fill 413 150 646 413 151 646 minecraft:red_concrete
fill 414 150 646 415 163 646 minecraft:purple_terracotta
fill 415 150 604 415 163 604 minecraft:purple_terracotta
fill 415 150 645 417 150 645 minecraft:polished_blackstone
setblock 416 150 646 minecraft:red_concrete
fill 417 150 604 417 151 604 minecraft:red_concrete
fill 417 150 605 417 150 607 minecraft:polished_blackstone
fill 417 150 609 417 150 611 minecraft:polished_blackstone
fill 417 150 613 417 150 615 minecraft:polished_blackstone
fill 417 150 617 417 150 619 minecraft:polished_blackstone
fill 417 150 621 417 150 623 minecraft:polished_blackstone
fill 417 150 625 417 150 627 minecraft:polished_blackstone
fill 417 150 629 417 150 631 minecraft:polished_blackstone
fill 417 150 633 417 150 635 minecraft:polished_blackstone
fill 417 150 637 417 150 639 minecraft:polished_blackstone
fill 417 150 641 417 150 643 minecraft:polished_blackstone
fill 418 150 609 418 163 610 minecraft:purple_terracotta
fill 418 150 611 418 151 612 minecraft:red_concrete
setblock 418 150 620 minecraft:red_concrete
fill 418 150 621 418 163 622 minecraft:purple_terracotta
fill 418 150 623 418 151 624 minecraft:red_concrete
fill 418 150 629 418 167 630 minecraft:purple_terracotta
fill 418 150 631 418 150 632 minecraft:red_concrete
fill 418 150 633 418 163 633 minecraft:purple_terracotta
fill 418 150 641 418 163 642 minecraft:purple_terracotta
fill 418 150 643 418 151 644 minecraft:red_concrete
fill 418 150 646 418 167 646 minecraft:purple_terracotta
fill 376 151 618 376 151 619 minecraft:red_concrete
setblock 376 151 622 minecraft:red_concrete
fill 376 151 623 376 161 623 minecraft:purple_terracotta
fill 376 151 634 376 161 634 minecraft:purple_terracotta
setblock 376 151 639 minecraft:red_concrete
setblock 380 151 646 minecraft:red_concrete
fill 382 151 604 382 161 604 minecraft:purple_terracotta
fill 384 151 646 385 161 646 minecraft:purple_terracotta
setblock 386 151 604 minecraft:red_concrete
fill 393 151 604 393 161 604 minecraft:purple_terracotta
setblock 394 151 604 minecraft:red_concrete
setblock 397 151 604 minecraft:red_concrete
setblock 401 151 646 minecraft:red_concrete
setblock 404 151 646 minecraft:red_concrete
fill 405 151 646 405 161 646 minecraft:purple_terracotta
setblock 412 151 646 minecraft:red_concrete
fill 413 151 604 414 161 604 minecraft:purple_terracotta
fill 416 151 646 416 161 646 minecraft:purple_terracotta
setblock 418 151 604 minecraft:red_concrete
setblock 418 151 615 minecraft:red_concrete
fill 418 151 620 418 161 620 minecraft:purple_terracotta
fill 418 151 631 418 161 631 minecraft:purple_terracotta
setblock 418 151 632 minecraft:red_concrete
fill 418 151 635 418 151 636 minecraft:red_concrete
fill 376 152 610 376 162 611 minecraft:purple_terracotta
fill 376 152 618 376 165 619 minecraft:purple_terracotta
fill 376 152 622 376 162 622 minecraft:purple_terracotta
fill 376 152 630 376 165 631 minecraft:purple_terracotta
fill 376 152 639 376 165 639 minecraft:purple_terracotta
fill 376 152 642 376 162 643 minecraft:purple_terracotta
fill 380 152 646 381 165 646 minecraft:purple_terracotta
fill 385 152 604 386 165 604 minecraft:purple_terracotta
fill 392 152 646 393 162 646 minecraft:purple_terracotta
fill 394 152 604 394 162 604 minecraft:purple_terracotta
fill 397 152 604 397 165 604 minecraft:purple_terracotta
fill 401 152 646 401 165 646 minecraft:purple_terracotta
fill 404 152 646 404 162 646 minecraft:purple_terracotta
fill 405 152 604 406 162 604 minecraft:purple_terracotta
fill 412 152 646 413 165 646 minecraft:purple_terracotta
fill 417 152 604 418 165 604 minecraft:purple_terracotta
fill 418 152 611 418 162 612 minecraft:purple_terracotta
fill 418 152 615 418 165 615 minecraft:purple_terracotta
fill 418 152 623 418 165 624 minecraft:purple_terracotta
fill 418 152 632 418 162 632 minecraft:purple_terracotta
fill 418 152 635 418 165 636 minecraft:purple_terracotta
fill 418 152 643 418 162 644 minecraft:purple_terracotta
setblock 379 154 607 minecraft:light[level=12]
setblock 379 154 615 minecraft:light[level=12]
setblock 379 154 623 minecraft:light[level=12]
setblock 379 154 631 minecraft:light[level=12]
setblock 379 154 639 minecraft:light[level=12]
setblock 387 154 607 minecraft:light[level=12]
setblock 387 154 615 minecraft:light[level=12]
setblock 387 154 623 minecraft:light[level=12]
setblock 387 154 631 minecraft:light[level=12]
setblock 387 154 639 minecraft:light[level=12]
setblock 395 154 607 minecraft:light[level=12]
setblock 395 154 615 minecraft:light[level=12]
setblock 395 154 623 minecraft:light[level=12]
setblock 395 154 631 minecraft:light[level=12]
setblock 395 154 639 minecraft:light[level=12]
setblock 403 154 607 minecraft:light[level=12]
setblock 403 154 615 minecraft:light[level=12]
setblock 403 154 623 minecraft:light[level=12]
setblock 403 154 631 minecraft:light[level=12]
setblock 403 154 639 minecraft:light[level=12]
setblock 411 154 607 minecraft:light[level=12]
setblock 411 154 615 minecraft:light[level=12]
setblock 411 154 623 minecraft:light[level=12]
setblock 411 154 631 minecraft:light[level=12]
setblock 411 154 639 minecraft:light[level=12]
fill 393 156 619 395 156 621 minecraft:redstone_block
fill 393 156 627 395 156 629 minecraft:redstone_block
fill 399 156 627 401 156 629 minecraft:redstone_block
fill 400 156 620 402 156 622 minecraft:redstone_block
fill 381 157 624 384 158 624 minecraft:red_concrete
fill 382 157 619 382 158 622 minecraft:black_concrete
fill 382 157 623 386 158 623 minecraft:red_concrete
fill 382 157 625 382 158 627 minecraft:red_concrete
fill 382 157 628 386 158 629 minecraft:black_concrete
fill 383 157 617 384 158 621 minecraft:black_concrete
fill 383 157 622 388 158 622 minecraft:red_concrete
fill 383 157 625 383 158 626 minecraft:red_concrete
fill 383 157 627 387 158 627 minecraft:black_concrete
fill 383 157 630 385 158 631 minecraft:black_concrete
fill 384 157 615 394 158 615 minecraft:red_concrete
fill 384 157 616 391 158 616 minecraft:black_concrete
fill 384 157 625 388 158 626 minecraft:black_concrete
fill 384 157 632 385 158 633 minecraft:black_concrete
fill 385 157 614 392 158 614 minecraft:red_concrete
fill 385 157 617 386 158 620 minecraft:black_concrete
fill 385 157 621 392 157 621 minecraft:red_concrete
fill 385 157 624 391 158 624 minecraft:black_concrete
fill 385 157 634 385 158 634 minecraft:black_concrete
fill 386 157 613 390 158 613 minecraft:red_concrete
fill 386 157 630 386 158 630 minecraft:black_concrete
fill 386 157 631 388 158 635 minecraft:red_concrete
fill 387 157 612 397 158 612 minecraft:black_concrete
fill 387 157 617 392 157 619 minecraft:black_concrete
fill 387 157 620 392 157 620 minecraft:red_concrete
fill 387 157 623 395 157 623 minecraft:black_concrete
fill 387 157 628 387 158 628 minecraft:black_concrete
fill 387 157 629 388 158 630 minecraft:red_concrete
fill 387 157 636 388 158 636 minecraft:red_concrete
fill 388 157 611 396 158 611 minecraft:black_concrete
fill 388 157 627 389 158 628 minecraft:red_concrete
fill 388 157 637 388 158 637 minecraft:red_concrete
fill 389 157 622 393 157 622 minecraft:black_concrete
fill 389 157 625 389 158 625 minecraft:black_concrete
fill 389 157 626 391 158 626 minecraft:red_concrete
fill 389 157 629 389 158 629 minecraft:red_concrete
fill 389 157 630 392 157 637 minecraft:black_concrete
fill 390 157 610 394 158 610 minecraft:black_concrete
fill 390 157 625 392 158 625 minecraft:red_concrete
fill 390 157 627 390 158 627 minecraft:red_concrete
fill 390 157 628 392 157 629 minecraft:black_concrete
fill 390 157 638 394 158 638 minecraft:black_concrete
fill 391 157 613 397 158 613 minecraft:black_concrete
fill 391 157 627 392 157 627 minecraft:black_concrete
fill 392 157 609 393 158 609 minecraft:black_concrete
fill 392 157 616 395 158 616 minecraft:red_concrete
fill 392 157 624 393 158 624 minecraft:red_concrete
fill 392 157 626 399 157 626 minecraft:black_concrete
fill 392 157 639 395 158 639 minecraft:black_concrete
fill 393 157 614 398 158 614 minecraft:black_concrete
fill 393 157 617 393 157 618 minecraft:black_concrete
fill 393 157 625 395 157 625 minecraft:black_concrete
fill 393 157 630 394 157 634 minecraft:red_concrete
fill 393 157 635 393 158 637 minecraft:black_concrete
fill 394 157 609 398 158 609 minecraft:red_concrete
fill 394 157 617 396 158 617 minecraft:red_concrete
setblock 394 157 618 minecraft:black_concrete
setblock 394 157 622 minecraft:red_concrete
fill 394 157 624 395 157 624 minecraft:black_concrete
fill 394 157 635 396 158 636 minecraft:red_concrete
fill 394 157 637 394 158 637 minecraft:black_concrete
fill 395 157 610 399 158 610 minecraft:red_concrete
fill 395 157 615 398 158 615 minecraft:black_concrete
fill 395 157 618 396 157 618 minecraft:red_concrete
fill 395 157 622 399 157 622 minecraft:black_concrete
fill 395 157 630 397 157 632 minecraft:black_concrete
fill 395 157 633 395 158 634 minecraft:red_concrete
fill 395 157 637 397 158 638 minecraft:red_concrete
fill 396 157 616 399 158 616 minecraft:black_concrete
fill 396 157 619 397 157 619 minecraft:red_concrete
fill 396 157 620 396 157 621 minecraft:black_concrete
fill 396 157 627 396 157 629 minecraft:black_concrete
fill 396 157 633 399 158 634 minecraft:black_concrete
fill 396 157 639 400 158 639 minecraft:red_concrete
fill 397 157 608 397 158 608 minecraft:red_concrete
fill 397 157 611 399 158 611 minecraft:red_concrete
fill 397 157 617 399 158 618 minecraft:black_concrete
fill 397 157 620 397 158 620 minecraft:red_concrete
fill 397 157 621 398 158 621 minecraft:black_concrete
fill 397 157 627 398 157 627 minecraft:black_concrete
fill 397 157 628 397 158 629 minecraft:red_concrete
fill 397 157 635 403 158 636 minecraft:black_concrete
fill 397 157 640 397 158 640 minecraft:red_concrete
fill 398 157 612 400 158 613 minecraft:red_concrete
fill 398 157 619 399 157 620 minecraft:black_concrete
setblock 398 157 628 minecraft:black_concrete
fill 398 157 629 398 157 631 minecraft:red_concrete
fill 398 157 632 398 158 632 minecraft:black_concrete
fill 398 157 637 406 158 637 minecraft:black_concrete
fill 398 157 638 399 158 638 minecraft:red_concrete
fill 399 157 609 402 158 609 minecraft:black_concrete
fill 399 157 614 401 158 615 minecraft:red_concrete
setblock 399 157 621 minecraft:red_concrete
fill 399 157 623 400 157 625 minecraft:black_concrete
fill 399 157 630 399 157 632 minecraft:red_concrete
fill 400 157 610 404 158 611 minecraft:black_concrete
fill 400 157 616 401 157 619 minecraft:red_concrete
setblock 400 157 626 minecraft:red_concrete
fill 400 157 630 411 157 630 minecraft:black_concrete
fill 400 157 631 400 158 633 minecraft:red_concrete
fill 400 157 634 401 158 634 minecraft:black_concrete
fill 400 157 638 404 158 638 minecraft:black_concrete
fill 401 157 612 405 158 613 minecraft:black_concrete
setblock 401 157 623 minecraft:black_concrete
fill 401 157 624 402 158 624 minecraft:red_concrete
fill 401 157 625 405 157 626 minecraft:black_concrete
fill 401 157 631 411 158 631 minecraft:black_concrete
fill 401 157 632 402 158 633 minecraft:red_concrete
fill 401 157 639 402 158 639 minecraft:black_concrete
fill 402 157 614 404 157 619 minecraft:black_concrete
fill 402 157 623 404 157 623 minecraft:red_concrete
fill 402 157 627 407 157 628 minecraft:red_concrete
fill 402 157 629 412 157 629 minecraft:black_concrete
fill 402 157 634 409 158 634 minecraft:red_concrete
fill 403 157 620 403 157 621 minecraft:black_concrete
fill 403 157 622 405 157 622 minecraft:red_concrete
fill 403 157 624 409 158 624 minecraft:black_concrete
fill 403 157 632 410 158 632 minecraft:black_concrete
fill 403 157 633 410 158 633 minecraft:red_concrete
fill 404 157 620 404 158 620 minecraft:black_concrete
fill 404 157 621 406 158 621 minecraft:red_concrete
fill 404 157 635 408 158 635 minecraft:red_concrete
fill 404 157 636 407 158 636 minecraft:black_concrete
fill 405 157 611 405 158 611 minecraft:black_concrete
fill 405 157 614 405 158 618 minecraft:black_concrete
fill 405 157 619 406 158 620 minecraft:red_concrete
fill 405 157 623 410 158 623 minecraft:black_concrete
fill 406 157 611 406 158 618 minecraft:red_concrete
fill 406 157 622 410 158 622 minecraft:black_concrete
fill 406 157 625 407 158 625 minecraft:black_concrete
fill 406 157 626 411 158 626 minecraft:red_concrete
fill 407 157 612 407 158 619 minecraft:red_concrete
fill 407 157 620 411 158 621 minecraft:black_concrete
fill 408 157 613 408 158 617 minecraft:red_concrete
fill 408 157 618 411 158 619 minecraft:black_concrete
fill 408 157 625 412 158 625 minecraft:red_concrete
fill 408 157 627 409 158 627 minecraft:red_concrete
fill 408 157 628 412 158 628 minecraft:black_concrete
fill 409 157 614 409 158 617 minecraft:black_concrete
fill 410 157 615 410 158 617 minecraft:black_concrete
fill 410 157 624 413 158 624 minecraft:red_concrete
fill 410 157 627 412 158 627 minecraft:black_concrete
fill 411 157 617 411 158 617 minecraft:black_concrete
fill 411 157 622 412 158 623 minecraft:red_concrete
fill 412 157 619 412 158 620 minecraft:black_concrete
fill 412 157 621 412 158 621 minecraft:red_concrete
fill 412 157 626 412 158 626 minecraft:black_concrete
fill 377 158 605 380 158 645 minecraft:black_concrete
fill 381 158 605 381 158 623 minecraft:black_concrete
fill 381 158 625 381 158 645 minecraft:black_concrete
fill 382 158 605 382 158 618 minecraft:black_concrete
fill 382 158 630 382 158 645 minecraft:black_concrete
fill 383 158 605 383 158 616 minecraft:black_concrete
fill 383 158 632 383 158 645 minecraft:black_concrete
fill 384 158 605 384 158 614 minecraft:black_concrete
fill 384 158 634 384 158 645 minecraft:black_concrete
fill 385 158 605 385 158 613 minecraft:black_concrete
fill 385 158 621 391 158 621 minecraft:red_concrete
fill 385 158 635 385 158 645 minecraft:black_concrete
fill 386 158 605 386 158 612 minecraft:black_concrete
fill 386 158 636 386 158 645 minecraft:black_concrete
fill 387 158 605 387 158 611 minecraft:black_concrete
fill 387 158 617 391 158 619 minecraft:black_concrete
fill 387 158 620 391 158 620 minecraft:red_concrete
fill 387 158 623 394 158 623 minecraft:black_concrete
fill 387 158 637 387 158 645 minecraft:black_concrete
fill 388 158 605 389 158 610 minecraft:black_concrete
fill 388 158 638 389 158 645 minecraft:black_concrete
fill 389 158 622 391 158 622 minecraft:black_concrete
fill 389 158 630 391 158 637 minecraft:black_concrete
fill 390 158 605 391 158 609 minecraft:black_concrete
fill 390 158 628 391 158 629 minecraft:black_concrete
fill 390 158 639 391 158 645 minecraft:black_concrete
setblock 391 158 627 minecraft:black_concrete
fill 392 158 605 396 158 608 minecraft:black_concrete
fill 392 158 617 393 158 617 minecraft:black_concrete
fill 392 158 618 392 158 622 minecraft:shroomlight
fill 392 158 626 392 158 630 minecraft:shroomlight
fill 392 158 631 392 158 637 minecraft:black_concrete
fill 392 158 640 396 158 645 minecraft:black_concrete
fill 393 158 618 396 158 618 minecraft:shroomlight
fill 393 158 619 395 158 621 minecraft:black_concrete
fill 393 158 622 399 158 622 minecraft:shroomlight
fill 393 158 625 394 158 625 minecraft:black_concrete
fill 393 158 626 402 158 626 minecraft:shroomlight
fill 393 158 627 395 158 629 minecraft:black_concrete
fill 393 158 630 396 158 630 minecraft:shroomlight
fill 393 158 631 394 158 634 minecraft:red_concrete
setblock 394 158 624 minecraft:black_concrete
fill 395 158 623 395 158 625 minecraft:shroomlight
fill 395 158 631 397 158 632 minecraft:black_concrete
fill 396 158 619 396 158 621 minecraft:shroomlight
fill 396 158 627 396 158 629 minecraft:shroomlight
fill 397 158 605 417 158 607 minecraft:black_concrete
setblock 397 158 619 minecraft:red_concrete
setblock 397 158 627 minecraft:black_concrete
setblock 397 158 630 minecraft:black_concrete
fill 397 158 641 417 158 645 minecraft:black_concrete
fill 398 158 608 417 158 608 minecraft:black_concrete
fill 398 158 619 398 158 620 minecraft:black_concrete
fill 398 158 627 398 158 630 minecraft:shroomlight
fill 398 158 631 399 158 631 minecraft:red_concrete
fill 398 158 640 417 158 640 minecraft:black_concrete
fill 399 158 619 399 158 621 minecraft:shroomlight
fill 399 158 623 399 158 625 minecraft:shroomlight
fill 399 158 627 401 158 629 minecraft:black_concrete
fill 399 158 630 402 158 630 minecraft:shroomlight
setblock 399 158 632 minecraft:red_concrete
fill 400 158 616 401 158 618 minecraft:red_concrete
fill 400 158 619 403 158 619 minecraft:shroomlight
fill 400 158 620 402 158 622 minecraft:black_concrete
fill 400 158 623 403 158 623 minecraft:shroomlight
fill 400 158 624 400 158 625 minecraft:black_concrete
fill 401 158 625 405 158 625 minecraft:black_concrete
fill 402 158 614 404 158 618 minecraft:black_concrete
fill 402 158 627 402 158 629 minecraft:shroomlight
fill 403 158 609 417 158 609 minecraft:black_concrete
fill 403 158 620 403 158 622 minecraft:shroomlight
fill 403 158 626 405 158 626 minecraft:black_concrete
fill 403 158 627 407 158 628 minecraft:red_concrete
fill 403 158 629 417 158 630 minecraft:black_concrete
fill 403 158 639 417 158 639 minecraft:black_concrete
setblock 404 158 619 minecraft:black_concrete
fill 404 158 622 404 158 623 minecraft:red_concrete
fill 405 158 610 417 158 610 minecraft:black_concrete
setblock 405 158 622 minecraft:red_concrete
fill 405 158 638 417 158 638 minecraft:black_concrete
fill 407 158 611 417 158 611 minecraft:black_concrete
fill 407 158 637 417 158 637 minecraft:black_concrete
fill 408 158 612 417 158 612 minecraft:black_concrete
fill 408 158 636 417 158 636 minecraft:black_concrete
fill 409 158 613 417 158 613 minecraft:black_concrete
fill 409 158 635 417 158 635 minecraft:black_concrete
fill 410 158 614 417 158 614 minecraft:black_concrete
fill 410 158 634 417 158 634 minecraft:black_concrete
fill 411 158 615 417 158 616 minecraft:black_concrete
fill 411 158 632 417 158 633 minecraft:black_concrete
fill 412 158 617 417 158 618 minecraft:black_concrete
fill 412 158 631 417 158 631 minecraft:black_concrete
fill 413 158 619 417 158 623 minecraft:black_concrete
fill 413 158 625 417 158 628 minecraft:black_concrete
fill 414 158 624 417 158 624 minecraft:black_concrete
fill 395 159 623 395 159 625 minecraft:lime_stained_glass
fill 396 159 622 398 159 622 minecraft:lime_stained_glass
fill 396 159 626 398 159 626 minecraft:lime_stained_glass
fill 399 159 623 399 159 625 minecraft:lime_stained_glass
fill 386 160 622 394 160 626 minecraft:light_gray_concrete
fill 387 160 619 407 160 621 minecraft:light_gray_concrete
fill 387 160 627 407 160 629 minecraft:light_gray_concrete
fill 388 160 618 406 163 618 minecraft:light_gray_concrete
fill 388 160 630 406 163 630 minecraft:light_gray_concrete
fill 389 160 617 405 163 617 minecraft:light_gray_concrete
fill 389 160 631 405 163 631 minecraft:light_gray_concrete
fill 390 160 616 404 163 616 minecraft:light_gray_concrete
fill 390 160 632 404 163 632 minecraft:light_gray_concrete
fill 391 160 615 403 163 615 minecraft:light_gray_concrete
fill 391 160 633 403 163 633 minecraft:light_gray_concrete
fill 392 160 614 402 163 614 minecraft:light_gray_concrete
fill 392 160 634 402 163 634 minecraft:light_gray_concrete
fill 395 160 613 399 163 613 minecraft:light_gray_concrete
fill 395 160 622 395 160 623 minecraft:light_gray_concrete
fill 395 160 625 395 160 626 minecraft:light_gray_concrete
fill 395 160 635 399 163 635 minecraft:light_gray_concrete
setblock 396 160 622 minecraft:light_gray_concrete
setblock 396 160 626 minecraft:light_gray_concrete
fill 398 160 622 408 160 622 minecraft:light_gray_concrete
fill 398 160 626 408 160 626 minecraft:light_gray_concrete
fill 399 160 623 408 160 623 minecraft:light_gray_concrete
fill 399 160 625 408 160 625 minecraft:light_gray_concrete
fill 400 160 624 408 160 624 minecraft:light_gray_concrete
fill 384 161 620 384 162 628 minecraft:sea_lantern
fill 385 161 618 385 162 621 minecraft:sea_lantern
fill 385 161 622 393 161 626 minecraft:light_gray_concrete
fill 385 161 627 385 162 630 minecraft:sea_lantern
fill 386 161 616 386 162 618 minecraft:sea_lantern
fill 386 161 619 396 161 621 minecraft:light_gray_concrete
fill 386 161 627 396 161 629 minecraft:light_gray_concrete
fill 386 161 630 386 162 632 minecraft:sea_lantern
fill 387 161 615 387 162 616 minecraft:sea_lantern
fill 387 161 617 387 162 618 minecraft:light_gray_concrete
fill 387 161 630 387 162 631 minecraft:light_gray_concrete
fill 387 161 632 387 162 633 minecraft:sea_lantern
fill 388 161 614 388 162 615 minecraft:sea_lantern
fill 388 161 616 388 162 617 minecraft:light_gray_concrete
fill 388 161 631 388 162 632 minecraft:light_gray_concrete
fill 388 161 633 388 162 634 minecraft:sea_lantern
fill 389 161 613 389 162 614 minecraft:sea_lantern
fill 389 161 615 389 162 616 minecraft:light_gray_concrete
fill 389 161 632 389 162 633 minecraft:light_gray_concrete
fill 389 161 634 389 162 635 minecraft:sea_lantern
fill 390 161 613 391 162 613 minecraft:sea_lantern
fill 390 161 614 390 162 615 minecraft:light_gray_concrete
fill 390 161 633 390 162 634 minecraft:light_gray_concrete
fill 390 161 635 391 162 635 minecraft:sea_lantern
fill 391 161 612 394 162 612 minecraft:sea_lantern
fill 391 161 614 391 162 614 minecraft:light_gray_concrete
fill 391 161 634 391 162 634 minecraft:light_gray_concrete
fill 391 161 636 394 162 636 minecraft:sea_lantern
fill 392 161 613 394 162 613 minecraft:light_gray_concrete
fill 392 161 635 394 162 635 minecraft:light_gray_concrete
fill 393 161 611 401 162 611 minecraft:sea_lantern
fill 393 161 637 401 162 637 minecraft:sea_lantern
fill 394 161 622 394 161 623 minecraft:light_gray_concrete
fill 394 161 624 394 164 624 minecraft:light_blue_stained_glass
fill 394 161 625 394 161 626 minecraft:light_gray_concrete
fill 395 161 612 399 162 612 minecraft:light_gray_concrete
fill 395 161 622 395 163 622 minecraft:light_blue_stained_glass
fill 395 161 626 395 163 626 minecraft:light_blue_stained_glass
fill 395 161 636 399 162 636 minecraft:light_gray_concrete
fill 397 161 619 408 161 620 minecraft:light_gray_concrete
fill 397 161 621 397 164 621 minecraft:light_blue_stained_glass
fill 397 161 627 397 164 627 minecraft:light_blue_stained_glass
fill 397 161 628 408 161 629 minecraft:light_gray_concrete
fill 398 161 621 408 161 621 minecraft:light_gray_concrete
fill 398 161 627 408 161 627 minecraft:light_gray_concrete
fill 399 161 622 399 163 622 minecraft:light_blue_stained_glass
fill 399 161 626 399 163 626 minecraft:light_blue_stained_glass
fill 400 161 612 403 162 612 minecraft:sea_lantern
fill 400 161 613 402 162 613 minecraft:light_gray_concrete
fill 400 161 622 409 161 623 minecraft:light_gray_concrete
fill 400 161 624 400 164 624 minecraft:light_blue_stained_glass
fill 400 161 625 409 161 626 minecraft:light_gray_concrete
fill 400 161 635 402 162 635 minecraft:light_gray_concrete
fill 400 161 636 403 162 636 minecraft:sea_lantern
fill 401 161 624 409 161 624 minecraft:light_gray_concrete
fill 403 161 613 405 162 613 minecraft:sea_lantern
fill 403 161 614 404 162 614 minecraft:light_gray_concrete
fill 403 161 634 404 162 634 minecraft:light_gray_concrete
fill 403 161 635 405 162 635 minecraft:sea_lantern
fill 404 161 615 405 162 615 minecraft:light_gray_concrete
fill 404 161 633 405 162 633 minecraft:light_gray_concrete
fill 405 161 614 406 162 614 minecraft:sea_lantern
fill 405 161 616 406 162 616 minecraft:light_gray_concrete
fill 405 161 632 406 162 632 minecraft:light_gray_concrete
fill 405 161 634 406 162 634 minecraft:sea_lantern
fill 406 161 615 407 162 615 minecraft:sea_lantern
fill 406 161 617 407 162 617 minecraft:light_gray_concrete
fill 406 161 631 407 162 631 minecraft:light_gray_concrete
fill 406 161 633 407 162 633 minecraft:sea_lantern
fill 407 161 616 408 162 616 minecraft:sea_lantern
fill 407 161 618 407 162 618 minecraft:light_gray_concrete
fill 407 161 630 407 162 630 minecraft:light_gray_concrete
fill 407 161 632 408 162 632 minecraft:sea_lantern
fill 408 161 617 408 162 618 minecraft:sea_lantern
fill 408 161 630 408 162 631 minecraft:sea_lantern
fill 409 161 618 409 162 621 minecraft:sea_lantern
fill 409 161 627 409 162 630 minecraft:sea_lantern
fill 410 161 620 410 162 628 minecraft:sea_lantern
setblock 376 162 606 minecraft:red_concrete
fill 376 162 607 376 165 607 minecraft:purple_terracotta
fill 376 162 614 376 162 615 minecraft:red_concrete
fill 376 162 623 376 163 623 minecraft:red_concrete
setblock 376 162 626 minecraft:red_concrete
fill 376 162 627 376 165 627 minecraft:purple_terracotta
fill 376 162 634 376 163 635 minecraft:red_concrete
fill 376 162 646 377 162 646 minecraft:red_concrete
fill 377 162 605 379 162 605 minecraft:polished_blackstone
fill 377 162 607 377 162 609 minecraft:polished_blackstone
fill 377 162 611 377 162 613 minecraft:polished_blackstone
fill 377 162 615 377 162 617 minecraft:polished_blackstone
fill 377 162 619 377 162 621 minecraft:polished_blackstone
fill 377 162 623 377 162 625 minecraft:polished_blackstone
fill 377 162 627 377 162 629 minecraft:polished_blackstone
fill 377 162 631 377 162 633 minecraft:polished_blackstone
fill 377 162 635 377 162 637 minecraft:polished_blackstone
fill 377 162 639 377 162 641 minecraft:polished_blackstone
fill 377 162 643 377 162 645 minecraft:polished_blackstone
setblock 379 162 607 minecraft:light[level=12]
setblock 379 162 615 minecraft:light[level=12]
setblock 379 162 623 minecraft:light[level=12]
setblock 379 162 631 minecraft:light[level=12]
setblock 379 162 639 minecraft:light[level=12]
fill 379 162 645 381 162 645 minecraft:polished_blackstone
fill 381 162 604 382 163 604 minecraft:red_concrete
fill 381 162 605 383 162 605 minecraft:polished_blackstone
fill 383 162 645 385 162 645 minecraft:polished_blackstone
fill 384 162 646 385 163 646 minecraft:red_concrete
fill 385 162 605 387 162 605 minecraft:polished_blackstone
fill 385 162 622 392 162 626 minecraft:light_gray_concrete
fill 386 162 619 393 162 621 minecraft:light_gray_concrete
fill 386 162 627 393 162 629 minecraft:light_gray_concrete
setblock 387 162 607 minecraft:light[level=12]
setblock 387 162 639 minecraft:light[level=12]
fill 387 162 645 389 162 645 minecraft:polished_blackstone
setblock 388 162 646 minecraft:red_concrete
fill 389 162 604 390 162 604 minecraft:red_concrete
fill 389 162 605 391 162 605 minecraft:polished_blackstone
fill 389 162 646 389 165 646 minecraft:purple_terracotta
fill 391 162 645 393 162 645 minecraft:polished_blackstone
fill 393 162 604 393 163 604 minecraft:red_concrete
fill 393 162 605 395 162 605 minecraft:polished_blackstone
fill 393 162 622 393 166 626 minecraft:light_blue_stained_glass
fill 394 162 619 394 162 620 minecraft:light_gray_concrete
fill 394 162 621 394 165 623 minecraft:light_blue_stained_glass
fill 394 162 625 394 165 627 minecraft:light_blue_stained_glass
fill 394 162 628 394 162 629 minecraft:light_gray_concrete
setblock 395 162 607 minecraft:light[level=12]
fill 395 162 619 408 162 619 minecraft:light_gray_concrete
fill 395 162 620 396 165 621 minecraft:light_blue_stained_glass
fill 395 162 627 396 165 628 minecraft:light_blue_stained_glass
fill 395 162 629 408 162 629 minecraft:light_gray_concrete
setblock 395 162 639 minecraft:light[level=12]
fill 395 162 645 397 162 645 minecraft:polished_blackstone
fill 396 162 646 397 163 646 minecraft:red_concrete
fill 397 162 605 399 162 605 minecraft:polished_blackstone
fill 397 162 620 399 166 620 minecraft:light_blue_stained_glass
fill 397 162 628 399 166 628 minecraft:light_blue_stained_glass
fill 398 162 621 400 165 621 minecraft:light_blue_stained_glass
fill 398 162 627 400 165 627 minecraft:light_blue_stained_glass
fill 399 162 645 401 162 645 minecraft:polished_blackstone
fill 400 162 620 408 162 620 minecraft:light_gray_concrete
fill 400 162 622 401 165 623 minecraft:light_blue_stained_glass
fill 400 162 625 401 165 626 minecraft:light_blue_stained_glass
fill 400 162 628 408 162 628 minecraft:light_gray_concrete
fill 401 162 604 402 163 604 minecraft:red_concrete
fill 401 162 605 403 162 605 minecraft:polished_blackstone
fill 401 162 621 408 162 621 minecraft:light_gray_concrete
fill 401 162 624 401 166 624 minecraft:light_blue_stained_glass
fill 401 162 627 408 162 627 minecraft:light_gray_concrete
fill 402 162 622 409 162 626 minecraft:light_gray_concrete
setblock 403 162 607 minecraft:light[level=12]
setblock 403 162 639 minecraft:light[level=12]
fill 403 162 645 405 162 645 minecraft:polished_blackstone
fill 405 162 605 407 162 605 minecraft:polished_blackstone
fill 405 162 646 405 163 646 minecraft:red_concrete
fill 407 162 645 409 162 645 minecraft:polished_blackstone
fill 408 162 646 409 162 646 minecraft:red_concrete
fill 409 162 604 409 165 604 minecraft:purple_terracotta
fill 409 162 605 411 162 605 minecraft:polished_blackstone
setblock 410 162 604 minecraft:red_concrete
setblock 411 162 607 minecraft:light[level=12]
setblock 411 162 615 minecraft:light[level=12]
setblock 411 162 623 minecraft:light[level=12]
setblock 411 162 631 minecraft:light[level=12]
setblock 411 162 639 minecraft:light[level=12]
fill 411 162 645 413 162 645 minecraft:polished_blackstone
fill 413 162 604 414 163 604 minecraft:red_concrete
fill 413 162 605 415 162 605 minecraft:polished_blackstone
fill 415 162 645 417 162 645 minecraft:polished_blackstone
fill 416 162 646 417 163 646 minecraft:red_concrete
fill 417 162 605 417 162 607 minecraft:polished_blackstone
fill 417 162 609 417 162 611 minecraft:polished_blackstone
fill 417 162 613 417 162 615 minecraft:polished_blackstone
fill 417 162 617 417 162 619 minecraft:polished_blackstone
fill 417 162 621 417 162 623 minecraft:polished_blackstone
fill 417 162 625 417 162 627 minecraft:polished_blackstone
fill 417 162 629 417 162 631 minecraft:polished_blackstone
fill 417 162 633 417 162 635 minecraft:polished_blackstone
fill 417 162 637 417 162 639 minecraft:polished_blackstone
fill 417 162 641 417 162 643 minecraft:polished_blackstone
fill 418 162 607 418 162 608 minecraft:red_concrete
fill 418 162 619 418 163 620 minecraft:red_concrete
fill 418 162 627 418 165 627 minecraft:purple_terracotta
setblock 418 162 628 minecraft:red_concrete
fill 418 162 631 418 163 631 minecraft:red_concrete
fill 418 162 639 418 162 640 minecraft:red_concrete
fill 376 163 606 376 165 606 minecraft:purple_terracotta
fill 376 163 610 376 165 610 minecraft:purple_terracotta
setblock 376 163 611 minecraft:red_concrete
setblock 376 163 614 minecraft:red_concrete
fill 376 163 615 376 166 615 minecraft:purple_terracotta
setblock 376 163 622 minecraft:red_concrete
fill 376 163 626 376 166 626 minecraft:purple_terracotta
fill 376 163 642 376 163 643 minecraft:red_concrete
setblock 376 163 646 minecraft:red_concrete
fill 377 163 646 377 166 646 minecraft:purple_terracotta
fill 386 163 622 391 163 626 minecraft:light_gray_concrete
fill 387 163 619 392 163 621 minecraft:light_gray_concrete
fill 387 163 627 392 163 629 minecraft:light_gray_concrete
fill 388 163 646 388 166 646 minecraft:purple_terracotta
fill 389 163 604 390 165 604 minecraft:purple_terracotta
fill 392 163 622 392 165 626 minecraft:light_blue_stained_glass
fill 392 163 646 392 165 646 minecraft:purple_terracotta
fill 393 163 610 394 164 611 minecraft:red_concrete
fill 393 163 619 394 163 619 minecraft:light_gray_concrete
fill 393 163 620 393 165 621 minecraft:light_blue_stained_glass
fill 393 163 627 393 165 628 minecraft:light_blue_stained_glass
fill 393 163 629 394 163 629 minecraft:light_gray_concrete
setblock 393 163 646 minecraft:red_concrete
setblock 394 163 604 minecraft:red_concrete
fill 394 163 620 394 165 620 minecraft:light_blue_stained_glass
fill 394 163 628 394 165 628 minecraft:light_blue_stained_glass
fill 395 163 619 399 165 619 minecraft:light_blue_stained_glass
fill 395 163 629 399 165 629 minecraft:light_blue_stained_glass
fill 400 163 619 407 163 619 minecraft:light_gray_concrete
fill 400 163 620 401 165 620 minecraft:light_blue_stained_glass
fill 400 163 628 401 165 628 minecraft:light_blue_stained_glass
fill 400 163 629 407 163 629 minecraft:light_gray_concrete
fill 401 163 621 401 165 621 minecraft:light_blue_stained_glass
fill 401 163 627 401 165 627 minecraft:light_blue_stained_glass
fill 402 163 620 407 163 621 minecraft:light_gray_concrete
fill 402 163 622 402 165 626 minecraft:light_blue_stained_glass
fill 402 163 627 407 163 628 minecraft:light_gray_concrete
fill 403 163 622 408 163 626 minecraft:light_gray_concrete
setblock 404 163 646 minecraft:red_concrete
setblock 405 163 604 minecraft:red_concrete
fill 406 163 604 406 165 604 minecraft:purple_terracotta
fill 408 163 646 409 166 646 minecraft:purple_terracotta
fill 410 163 604 410 166 604 minecraft:purple_terracotta
fill 418 163 607 418 166 607 minecraft:purple_terracotta
setblock 418 163 608 minecraft:red_concrete
fill 418 163 611 418 163 612 minecraft:red_concrete
fill 418 163 628 418 166 628 minecraft:purple_terracotta
setblock 418 163 632 minecraft:red_concrete
fill 418 163 639 418 166 639 minecraft:purple_terracotta
setblock 418 163 640 minecraft:red_concrete
setblock 418 163 643 minecraft:red_concrete
fill 418 163 644 418 165 644 minecraft:purple_terracotta
setblock 376 164 608 minecraft:purple_terracotta
fill 376 164 609 376 165 609 minecraft:red_concrete
fill 376 164 611 376 169 611 minecraft:purple_terracotta
fill 376 164 612 376 164 613 minecraft:red_concrete
fill 376 164 614 376 169 614 minecraft:purple_terracotta
fill 376 164 620 376 165 621 minecraft:red_concrete
fill 376 164 622 376 169 623 minecraft:purple_terracotta
fill 376 164 632 376 164 633 minecraft:red_concrete
fill 376 164 634 376 169 635 minecraft:purple_terracotta
setblock 376 164 640 minecraft:purple_terracotta
fill 376 164 641 376 165 641 minecraft:red_concrete
fill 376 164 642 376 169 643 minecraft:purple_terracotta
setblock 376 164 644 minecraft:red_concrete
fill 376 164 645 376 167 646 minecraft:purple_terracotta
fill 381 164 604 382 169 604 minecraft:purple_terracotta
fill 382 164 646 383 165 646 minecraft:red_concrete
fill 383 164 604 384 165 604 minecraft:red_concrete
fill 384 164 646 385 169 646 minecraft:purple_terracotta
fill 391 164 604 391 167 604 minecraft:purple_terracotta
setblock 391 164 624 minecraft:light_blue_stained_glass
setblock 392 164 604 minecraft:red_concrete
setblock 392 164 621 minecraft:light_blue_stained_glass
setblock 392 164 627 minecraft:light_blue_stained_glass
fill 393 164 604 394 169 604 minecraft:purple_terracotta
fill 393 164 646 393 169 646 minecraft:purple_terracotta
setblock 394 164 619 minecraft:light_blue_stained_glass
setblock 394 164 629 minecraft:light_blue_stained_glass
fill 394 164 646 395 164 646 minecraft:red_concrete
fill 395 164 604 396 165 604 minecraft:red_concrete
fill 396 164 646 397 169 646 minecraft:purple_terracotta
setblock 397 164 618 minecraft:light_blue_stained_glass
setblock 397 164 630 minecraft:light_blue_stained_glass
setblock 400 164 619 minecraft:light_blue_stained_glass
setblock 400 164 629 minecraft:light_blue_stained_glass
fill 401 164 604 402 169 604 minecraft:purple_terracotta
setblock 402 164 621 minecraft:light_blue_stained_glass
setblock 402 164 627 minecraft:light_blue_stained_glass
fill 402 164 646 403 165 646 minecraft:red_concrete
fill 403 164 604 404 164 604 minecraft:red_concrete
setblock 403 164 624 minecraft:light_blue_stained_glass
fill 404 164 646 405 169 646 minecraft:purple_terracotta
fill 405 164 604 405 169 604 minecraft:purple_terracotta
setblock 406 164 646 minecraft:red_concrete
fill 407 164 646 407 167 646 minecraft:purple_terracotta
fill 413 164 604 414 169 604 minecraft:purple_terracotta
fill 414 164 646 415 165 646 minecraft:red_concrete
fill 415 164 604 416 165 604 minecraft:red_concrete
fill 416 164 646 417 169 646 minecraft:purple_terracotta
fill 418 164 608 418 167 609 minecraft:purple_terracotta
setblock 418 164 610 minecraft:red_concrete
fill 418 164 611 418 169 612 minecraft:purple_terracotta
fill 418 164 613 418 165 613 minecraft:red_concrete
setblock 418 164 614 minecraft:purple_terracotta
fill 418 164 619 418 169 620 minecraft:purple_terracotta
fill 418 164 621 418 164 622 minecraft:red_concrete
fill 418 164 631 418 169 632 minecraft:purple_terracotta
fill 418 164 633 418 165 634 minecraft:red_concrete
fill 418 164 640 418 169 640 minecraft:purple_terracotta
fill 418 164 641 418 164 642 minecraft:red_concrete
fill 418 164 643 418 169 643 minecraft:purple_terracotta
fill 418 164 645 418 165 645 minecraft:red_concrete
setblock 376 165 608 minecraft:red_concrete
fill 376 165 612 376 168 613 minecraft:purple_terracotta
fill 376 165 628 376 167 628 minecraft:purple_terracotta
setblock 376 165 629 minecraft:red_concrete
setblock 376 165 632 minecraft:red_concrete
fill 376 165 633 376 168 633 minecraft:purple_terracotta
setblock 376 165 640 minecraft:red_concrete
fill 376 165 644 376 168 644 minecraft:purple_terracotta
setblock 387 165 604 minecraft:red_concrete
fill 388 165 604 388 167 604 minecraft:purple_terracotta
fill 390 165 646 391 165 646 minecraft:red_concrete
fill 392 165 604 392 167 604 minecraft:purple_terracotta
setblock 394 165 646 minecraft:red_concrete
fill 395 165 646 395 168 646 minecraft:purple_terracotta
fill 403 165 604 403 168 604 minecraft:purple_terracotta
setblock 404 165 604 minecraft:red_concrete
fill 406 165 646 406 168 646 minecraft:purple_terracotta
fill 407 165 604 408 165 604 minecraft:red_concrete
fill 410 165 646 410 167 646 minecraft:purple_terracotta
setblock 411 165 646 minecraft:red_concrete
fill 413 165 641 414 199 642 minecraft:polished_blackstone
fill 418 165 610 418 168 610 minecraft:purple_terracotta
setblock 418 165 614 minecraft:red_concrete
fill 418 165 621 418 168 621 minecraft:purple_terracotta
setblock 418 165 622 minecraft:red_concrete
setblock 418 165 625 minecraft:red_concrete
fill 418 165 626 418 167 626 minecraft:purple_terracotta
fill 418 165 641 418 168 642 minecraft:purple_terracotta
fill 376 166 606 376 167 607 minecraft:red_concrete
fill 376 166 608 376 171 609 minecraft:purple_terracotta
setblock 376 166 610 minecraft:red_concrete
fill 376 166 618 376 167 619 minecraft:red_concrete
fill 376 166 620 376 171 621 minecraft:purple_terracotta
fill 376 166 627 376 167 627 minecraft:red_concrete
fill 376 166 629 376 171 629 minecraft:purple_terracotta
fill 376 166 630 376 166 631 minecraft:red_concrete
fill 376 166 632 376 171 632 minecraft:purple_terracotta
fill 376 166 638 376 167 639 minecraft:red_concrete
fill 376 166 640 376 171 641 minecraft:purple_terracotta
fill 377 166 604 378 167 604 minecraft:red_concrete
fill 380 166 646 381 166 646 minecraft:red_concrete
fill 382 166 646 383 171 646 minecraft:purple_terracotta
fill 383 166 604 384 168 604 minecraft:purple_terracotta
fill 385 166 604 386 166 604 minecraft:red_concrete
fill 387 166 604 387 171 604 minecraft:purple_terracotta
fill 389 166 604 389 167 604 minecraft:red_concrete
fill 389 166 646 389 167 646 minecraft:red_concrete
setblock 390 166 604 minecraft:purple_terracotta
fill 390 166 646 391 171 646 minecraft:purple_terracotta
setblock 392 166 646 minecraft:red_concrete
fill 394 166 621 394 166 622 minecraft:light_blue_stained_glass
fill 394 166 626 394 166 627 minecraft:light_blue_stained_glass
fill 394 166 646 394 171 646 minecraft:purple_terracotta
fill 395 166 604 396 171 604 minecraft:purple_terracotta
fill 395 166 620 395 166 621 minecraft:light_blue_stained_glass
fill 395 166 627 395 166 628 minecraft:light_blue_stained_glass
setblock 396 166 620 minecraft:light_blue_stained_glass
setblock 396 166 628 minecraft:light_blue_stained_glass
fill 397 166 604 398 167 604 minecraft:red_concrete
fill 399 166 621 400 166 621 minecraft:light_blue_stained_glass
fill 399 166 627 400 166 627 minecraft:light_blue_stained_glass
fill 400 166 622 401 166 622 minecraft:light_blue_stained_glass
fill 400 166 626 401 166 626 minecraft:light_blue_stained_glass
fill 400 166 646 401 167 646 minecraft:red_concrete
setblock 401 166 623 minecraft:light_blue_stained_glass
setblock 401 166 625 minecraft:light_blue_stained_glass
fill 402 166 646 403 171 646 minecraft:purple_terracotta
fill 404 166 604 404 171 604 minecraft:purple_terracotta
setblock 406 166 604 minecraft:red_concrete
fill 407 166 604 408 171 604 minecraft:purple_terracotta
fill 409 166 604 409 167 604 minecraft:red_concrete
fill 411 166 646 411 171 646 minecraft:purple_terracotta
fill 412 166 641 412 167 642 minecraft:black_concrete
fill 412 166 646 413 166 646 minecraft:red_concrete
fill 413 166 640 414 167 640 minecraft:black_concrete
fill 413 166 643 414 167 643 minecraft:black_concrete
fill 414 166 646 415 171 646 minecraft:purple_terracotta
fill 415 166 604 416 171 604 minecraft:purple_terracotta
fill 415 166 641 415 167 642 minecraft:black_concrete
fill 417 166 604 418 166 604 minecraft:red_concrete
fill 418 166 613 418 171 614 minecraft:purple_terracotta
fill 418 166 615 418 167 616 minecraft:red_concrete
fill 418 166 622 418 171 622 minecraft:purple_terracotta
fill 418 166 623 418 166 624 minecraft:red_concrete
fill 418 166 625 418 171 625 minecraft:purple_terracotta
fill 418 166 627 418 167 627 minecraft:red_concrete
fill 418 166 633 418 171 634 minecraft:purple_terracotta
fill 418 166 635 418 167 636 minecraft:red_concrete
setblock 418 166 644 minecraft:red_concrete
fill 418 166 645 418 171 645 minecraft:purple_terracotta
fill 376 167 610 376 170 610 minecraft:purple_terracotta
setblock 376 167 615 minecraft:red_concrete
setblock 376 167 626 minecraft:red_concrete
fill 376 167 630 376 170 631 minecraft:purple_terracotta
setblock 377 167 646 minecraft:red_concrete
setblock 380 167 646 minecraft:red_concrete
fill 381 167 646 381 170 646 minecraft:purple_terracotta
fill 385 167 604 385 170 604 minecraft:purple_terracotta
setblock 386 167 604 minecraft:red_concrete
setblock 388 167 646 minecraft:red_concrete
setblock 390 167 604 minecraft:red_concrete
fill 392 167 646 392 170 646 minecraft:purple_terracotta
fill 406 167 604 406 170 604 minecraft:purple_terracotta
fill 408 167 646 409 167 646 minecraft:red_concrete
setblock 410 167 604 minecraft:red_concrete
setblock 412 167 640 minecraft:black_concrete
setblock 412 167 643 minecraft:black_concrete
setblock 412 167 646 minecraft:red_concrete
fill 413 167 646 413 170 646 minecraft:purple_terracotta
setblock 415 167 640 minecraft:black_concrete
setblock 415 167 643 minecraft:black_concrete
fill 416 167 641 416 167 642 minecraft:black_concrete
fill 417 167 604 417 170 604 minecraft:purple_terracotta
setblock 418 167 604 minecraft:red_concrete
setblock 418 167 607 minecraft:red_concrete
fill 418 167 623 418 170 624 minecraft:purple_terracotta
setblock 418 167 628 minecraft:red_concrete
setblock 418 167 639 minecraft:red_concrete
fill 418 167 644 418 170 644 minecraft:purple_terracotta
fill 376 168 604 376 169 605 minecraft:red_concrete
fill 376 168 606 376 173 607 minecraft:purple_terracotta
fill 376 168 615 376 173 615 minecraft:purple_terracotta
fill 376 168 616 376 168 617 minecraft:red_concrete
fill 376 168 618 376 173 619 minecraft:purple_terracotta
fill 376 168 624 376 169 625 minecraft:red_concrete
fill 376 168 626 376 173 627 minecraft:purple_terracotta
setblock 376 168 628 minecraft:red_concrete
fill 376 168 636 376 169 637 minecraft:red_concrete
fill 376 168 638 376 173 639 minecraft:purple_terracotta
fill 376 168 645 376 169 645 minecraft:red_concrete
fill 376 168 646 377 169 646 minecraft:purple_terracotta
fill 377 168 604 378 173 604 minecraft:purple_terracotta
fill 377 168 605 379 168 605 minecraft:polished_blackstone
fill 377 168 607 377 168 609 minecraft:polished_blackstone
fill 377 168 611 377 168 613 minecraft:polished_blackstone
fill 377 168 615 377 168 617 minecraft:polished_blackstone
fill 377 168 619 377 168 621 minecraft:polished_blackstone
fill 377 168 623 377 168 625 minecraft:polished_blackstone
fill 377 168 627 377 168 629 minecraft:polished_blackstone
fill 377 168 631 377 168 633 minecraft:polished_blackstone
fill 377 168 635 377 168 637 minecraft:polished_blackstone
fill 377 168 639 377 168 641 minecraft:polished_blackstone
fill 377 168 643 377 168 645 minecraft:polished_blackstone
fill 378 168 646 379 168 646 minecraft:red_concrete
fill 379 168 604 380 169 604 minecraft:red_concrete
fill 379 168 645 381 168 645 minecraft:polished_blackstone
fill 380 168 646 380 173 646 minecraft:purple_terracotta
fill 381 168 605 383 168 605 minecraft:polished_blackstone
fill 383 168 645 385 168 645 minecraft:polished_blackstone
fill 385 168 605 387 168 605 minecraft:polished_blackstone
fill 386 168 604 386 170 604 minecraft:purple_terracotta
fill 386 168 646 387 169 646 minecraft:red_concrete
fill 387 168 645 389 168 645 minecraft:polished_blackstone
setblock 388 168 604 minecraft:red_concrete
fill 388 168 646 389 173 646 minecraft:purple_terracotta
fill 389 168 604 390 173 604 minecraft:purple_terracotta
fill 389 168 605 391 168 605 minecraft:polished_blackstone
schedule function dropper:buildpart/152_3 1t
