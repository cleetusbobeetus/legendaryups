fill 260 132 558 262 132 558 minecraft:orange_concrete
fill 260 132 567 262 132 567 minecraft:gray_concrete
fill 262 132 598 264 132 598 minecraft:orange_concrete
fill 263 132 566 263 132 568 minecraft:magma_block
fill 263 132 592 269 132 592 minecraft:gray_concrete
fill 264 132 558 266 132 558 minecraft:orange_concrete
fill 264 132 566 267 132 569 minecraft:gray_concrete
fill 264 132 591 270 132 591 minecraft:gray_concrete
fill 264 132 599 268 132 599 minecraft:orange_terracotta
fill 265 132 557 265 137 557 minecraft:orange_terracotta
fill 265 132 570 267 132 570 minecraft:gray_concrete
fill 265 132 590 268 132 590 minecraft:gray_concrete
fill 266 132 557 267 132 557 minecraft:yellow_concrete
fill 266 132 571 267 132 571 minecraft:gray_concrete
fill 266 132 598 268 132 598 minecraft:orange_concrete
fill 267 132 572 272 132 572 minecraft:gray_concrete
fill 267 132 588 272 132 588 minecraft:gray_concrete
fill 268 132 557 269 133 557 minecraft:orange_terracotta
fill 268 132 558 270 132 558 minecraft:orange_concrete
fill 268 132 587 272 132 587 minecraft:gray_concrete
fill 269 132 574 270 132 576 minecraft:gray_concrete
fill 269 132 586 272 132 586 minecraft:gray_concrete
fill 269 132 599 270 132 599 minecraft:yellow_concrete
fill 270 132 557 270 133 557 minecraft:yellow_concrete
setblock 270 132 577 minecraft:gray_concrete
fill 270 132 579 271 132 583 minecraft:gray_concrete
fill 270 132 598 272 132 598 minecraft:orange_concrete
fill 271 132 574 272 132 575 minecraft:gray_concrete
fill 271 132 599 272 137 599 minecraft:orange_terracotta
fill 272 132 558 274 132 558 minecraft:orange_concrete
fill 272 132 579 273 132 581 minecraft:gray_concrete
setblock 273 132 575 minecraft:gray_concrete
fill 274 132 598 276 132 598 minecraft:orange_concrete
fill 276 132 557 277 137 557 minecraft:orange_terracotta
fill 276 132 558 276 132 560 minecraft:orange_concrete
fill 276 132 562 276 132 564 minecraft:orange_concrete
fill 276 132 566 276 132 568 minecraft:orange_concrete
fill 276 132 570 276 132 572 minecraft:orange_concrete
fill 276 132 574 276 132 576 minecraft:orange_concrete
fill 276 132 578 276 132 580 minecraft:orange_concrete
fill 276 132 582 276 132 584 minecraft:orange_concrete
fill 276 132 586 276 132 588 minecraft:orange_concrete
fill 276 132 590 276 132 592 minecraft:orange_concrete
fill 276 132 594 276 132 596 minecraft:orange_concrete
fill 277 132 558 277 133 559 minecraft:yellow_concrete
fill 277 132 560 277 133 560 minecraft:orange_terracotta
fill 277 132 566 277 135 566 minecraft:orange_terracotta
setblock 277 132 567 minecraft:yellow_concrete
fill 277 132 568 277 137 569 minecraft:orange_terracotta
fill 277 132 570 277 133 571 minecraft:yellow_concrete
fill 277 132 576 277 137 577 minecraft:orange_terracotta
fill 277 132 578 277 132 579 minecraft:yellow_concrete
fill 277 132 580 277 137 580 minecraft:orange_terracotta
fill 277 132 588 277 137 589 minecraft:orange_terracotta
fill 277 132 590 277 133 591 minecraft:yellow_concrete
fill 277 132 592 277 133 595 minecraft:orange_terracotta
fill 277 132 597 277 137 597 minecraft:orange_terracotta
setblock 235 133 557 minecraft:yellow_concrete
fill 235 133 561 235 136 562 minecraft:orange_terracotta
fill 235 133 575 235 133 576 minecraft:orange_terracotta
fill 235 133 577 235 133 578 minecraft:yellow_concrete
setblock 235 133 579 minecraft:orange_terracotta
setblock 235 133 581 minecraft:yellow_concrete
fill 235 133 582 235 136 582 minecraft:orange_terracotta
fill 235 133 593 235 136 593 minecraft:orange_terracotta
fill 235 133 597 235 135 597 minecraft:orange_terracotta
setblock 235 133 598 minecraft:yellow_concrete
setblock 235 133 599 minecraft:orange_terracotta
fill 236 133 557 237 137 557 minecraft:orange_terracotta
setblock 236 133 579 minecraft:magma_block
setblock 239 133 557 minecraft:yellow_concrete
fill 240 133 557 246 133 557 minecraft:orange_terracotta
setblock 244 133 599 minecraft:orange_terracotta
setblock 245 133 599 minecraft:yellow_concrete
setblock 247 133 557 minecraft:yellow_concrete
fill 249 133 599 250 136 599 minecraft:orange_terracotta
setblock 250 133 557 minecraft:yellow_concrete
fill 251 133 557 252 133 557 minecraft:orange_terracotta
fill 264 133 599 265 133 599 minecraft:orange_terracotta
fill 266 133 557 267 136 557 minecraft:orange_terracotta
setblock 266 133 599 minecraft:yellow_concrete
fill 267 133 599 268 133 599 minecraft:orange_terracotta
setblock 269 133 599 minecraft:yellow_concrete
fill 270 133 599 270 136 599 minecraft:orange_terracotta
setblock 271 133 557 minecraft:yellow_concrete
fill 274 133 599 276 133 599 minecraft:orange_terracotta
setblock 277 133 561 minecraft:orange_terracotta
setblock 277 133 562 minecraft:yellow_concrete
fill 277 133 563 277 135 563 minecraft:orange_terracotta
fill 277 133 567 277 136 567 minecraft:orange_terracotta
fill 277 133 578 277 136 578 minecraft:orange_terracotta
setblock 277 133 579 minecraft:yellow_concrete
setblock 277 133 581 minecraft:orange_terracotta
fill 277 133 582 277 133 583 minecraft:yellow_concrete
fill 277 133 584 277 133 585 minecraft:orange_terracotta
setblock 277 133 599 minecraft:yellow_concrete
fill 235 134 557 235 139 558 minecraft:orange_terracotta
setblock 235 134 559 minecraft:yellow_concrete
fill 235 134 560 235 137 560 minecraft:orange_terracotta
fill 235 134 566 235 135 566 minecraft:orange_terracotta
fill 235 134 567 235 135 568 minecraft:yellow_concrete
fill 235 134 569 235 139 570 minecraft:orange_terracotta
setblock 235 134 575 minecraft:orange_terracotta
fill 235 134 576 235 135 576 minecraft:yellow_concrete
fill 235 134 577 235 135 578 minecraft:orange_terracotta
fill 235 134 579 235 134 580 minecraft:yellow_concrete
fill 235 134 581 235 139 581 minecraft:orange_terracotta
fill 235 134 587 235 135 588 minecraft:yellow_concrete
fill 235 134 589 235 139 590 minecraft:orange_terracotta
fill 235 134 598 235 135 598 minecraft:orange_terracotta
fill 235 134 599 236 134 599 minecraft:yellow_concrete
fill 237 134 599 238 139 599 minecraft:orange_terracotta
fill 238 134 557 239 139 557 minecraft:orange_terracotta
fill 240 134 557 241 135 557 minecraft:yellow_concrete
fill 242 134 557 247 135 557 minecraft:orange_terracotta
fill 243 134 599 244 135 599 minecraft:yellow_concrete
fill 245 134 599 246 139 599 minecraft:orange_terracotta
setblock 247 134 599 minecraft:yellow_concrete
fill 248 134 557 249 134 557 minecraft:yellow_concrete
fill 250 134 557 251 135 557 minecraft:orange_terracotta
fill 251 134 599 254 134 599 minecraft:orange_terracotta
fill 252 134 557 252 135 557 minecraft:yellow_concrete
fill 255 134 599 256 135 599 minecraft:yellow_concrete
fill 257 134 599 258 139 599 minecraft:orange_terracotta
fill 258 134 557 259 139 557 minecraft:orange_terracotta
fill 260 134 557 261 135 557 minecraft:yellow_concrete
fill 264 134 599 264 135 599 minecraft:yellow_concrete
fill 265 134 599 266 135 599 minecraft:orange_terracotta
fill 267 134 599 268 134 599 minecraft:yellow_concrete
fill 268 134 557 268 137 557 minecraft:orange_terracotta
setblock 269 134 557 minecraft:yellow_concrete
fill 269 134 599 269 139 599 minecraft:orange_terracotta
fill 270 134 557 271 139 557 minecraft:orange_terracotta
fill 272 134 557 273 135 557 minecraft:yellow_concrete
fill 274 134 557 275 135 557 minecraft:orange_terracotta
fill 274 134 599 274 135 599 minecraft:orange_terracotta
fill 275 134 599 276 135 599 minecraft:yellow_concrete
fill 277 134 558 277 139 559 minecraft:orange_terracotta
fill 277 134 560 277 134 561 minecraft:yellow_concrete
fill 277 134 562 277 139 562 minecraft:orange_terracotta
fill 277 134 570 277 139 571 minecraft:orange_terracotta
fill 277 134 572 277 135 573 minecraft:yellow_concrete
fill 277 134 574 277 135 575 minecraft:orange_terracotta
fill 277 134 579 277 139 579 minecraft:orange_terracotta
setblock 277 134 581 minecraft:yellow_concrete
fill 277 134 582 277 139 583 minecraft:orange_terracotta
fill 277 134 584 277 135 584 minecraft:yellow_concrete
setblock 277 134 585 minecraft:orange_terracotta
fill 277 134 590 277 139 591 minecraft:orange_terracotta
fill 277 134 592 277 134 593 minecraft:yellow_concrete
fill 277 134 594 277 135 595 minecraft:orange_terracotta
fill 277 134 599 277 139 599 minecraft:orange_terracotta
fill 235 135 559 235 138 559 minecraft:orange_terracotta
setblock 235 135 564 minecraft:yellow_concrete
setblock 235 135 575 minecraft:yellow_concrete
fill 235 135 579 235 137 580 minecraft:orange_terracotta
setblock 235 135 594 minecraft:orange_terracotta
fill 235 135 595 235 135 596 minecraft:yellow_concrete
setblock 235 135 599 minecraft:yellow_concrete
fill 236 135 599 236 138 599 minecraft:orange_terracotta
fill 243 135 566 243 136 566 minecraft:red_concrete
fill 247 135 599 247 138 599 minecraft:orange_terracotta
fill 248 135 557 249 138 557 minecraft:orange_terracotta
fill 251 135 599 251 137 599 minecraft:orange_terracotta
setblock 252 135 599 minecraft:yellow_concrete
setblock 253 135 557 minecraft:yellow_concrete
fill 253 135 599 254 135 599 minecraft:orange_terracotta
setblock 263 135 599 minecraft:yellow_concrete
setblock 264 135 557 minecraft:yellow_concrete
fill 267 135 599 268 138 599 minecraft:orange_terracotta
fill 269 135 557 269 138 557 minecraft:orange_terracotta
fill 277 135 560 277 138 560 minecraft:orange_terracotta
setblock 277 135 561 minecraft:yellow_concrete
fill 277 135 564 277 135 565 minecraft:yellow_concrete
fill 277 135 581 277 138 581 minecraft:orange_terracotta
setblock 277 135 585 minecraft:yellow_concrete
fill 277 135 592 277 138 592 minecraft:orange_terracotta
setblock 277 135 593 minecraft:yellow_concrete
setblock 277 135 596 minecraft:yellow_concrete
fill 235 136 564 235 141 564 minecraft:orange_terracotta
fill 235 136 565 235 136 566 minecraft:yellow_concrete
fill 235 136 567 235 138 568 minecraft:orange_terracotta
fill 235 136 573 235 137 574 minecraft:yellow_concrete
fill 235 136 575 235 141 576 minecraft:orange_terracotta
setblock 235 136 577 minecraft:yellow_concrete
fill 235 136 578 235 139 578 minecraft:orange_terracotta
fill 235 136 585 235 137 586 minecraft:yellow_concrete
fill 235 136 587 235 141 588 minecraft:orange_terracotta
fill 235 136 594 235 137 594 minecraft:yellow_concrete
fill 235 136 595 235 137 596 minecraft:orange_terracotta
fill 235 136 597 235 136 598 minecraft:yellow_concrete
fill 235 136 599 235 141 599 minecraft:orange_terracotta
fill 240 136 557 241 141 557 minecraft:orange_terracotta
fill 241 136 599 242 137 599 minecraft:yellow_concrete
fill 242 136 557 243 137 557 minecraft:yellow_concrete
fill 243 136 599 244 141 599 minecraft:orange_terracotta
fill 244 136 557 247 136 557 minecraft:orange_terracotta
fill 250 136 557 250 139 557 minecraft:orange_terracotta
setblock 251 136 557 minecraft:yellow_concrete
fill 252 136 557 253 141 557 minecraft:orange_terracotta
fill 252 136 599 252 141 599 minecraft:orange_terracotta
fill 253 136 599 254 136 599 minecraft:yellow_concrete
fill 254 136 557 255 137 557 minecraft:yellow_concrete
fill 255 136 599 256 141 599 minecraft:orange_terracotta
fill 260 136 557 261 141 557 minecraft:orange_terracotta
fill 261 136 599 262 137 599 minecraft:yellow_concrete
fill 262 136 557 263 136 557 minecraft:yellow_concrete
fill 263 136 599 264 141 599 minecraft:orange_terracotta
fill 264 136 557 264 141 557 minecraft:orange_terracotta
setblock 265 136 599 minecraft:yellow_concrete
fill 266 136 599 266 139 599 minecraft:orange_terracotta
fill 272 136 557 273 141 557 minecraft:orange_terracotta
fill 273 136 599 274 137 599 minecraft:yellow_concrete
fill 274 136 557 275 137 557 minecraft:yellow_concrete
fill 275 136 599 276 141 599 minecraft:orange_terracotta
fill 277 136 561 277 141 561 minecraft:orange_terracotta
setblock 277 136 563 minecraft:yellow_concrete
fill 277 136 564 277 141 565 minecraft:orange_terracotta
fill 277 136 566 277 137 566 minecraft:yellow_concrete
fill 277 136 572 277 141 573 minecraft:orange_terracotta
fill 277 136 574 277 136 575 minecraft:yellow_concrete
fill 277 136 584 277 141 585 minecraft:orange_terracotta
fill 277 136 586 277 137 587 minecraft:yellow_concrete
fill 277 136 593 277 141 593 minecraft:orange_terracotta
fill 277 136 594 277 136 595 minecraft:yellow_concrete
fill 277 136 596 277 141 596 minecraft:orange_terracotta
fill 277 136 598 277 137 598 minecraft:yellow_concrete
fill 235 137 561 235 137 562 minecraft:yellow_concrete
setblock 235 137 565 minecraft:yellow_concrete
fill 235 137 566 235 140 566 minecraft:orange_terracotta
fill 235 137 577 235 139 577 minecraft:orange_terracotta
setblock 235 137 582 minecraft:yellow_concrete
setblock 235 137 593 minecraft:yellow_concrete
fill 235 137 597 235 139 598 minecraft:orange_terracotta
fill 240 137 558 242 137 559 minecraft:magma_block
fill 241 137 560 241 140 560 minecraft:magma_block
fill 244 137 557 245 137 557 minecraft:orange_terracotta
setblock 246 137 557 minecraft:yellow_concrete
fill 247 137 557 247 139 557 minecraft:orange_terracotta
fill 249 137 599 250 137 599 minecraft:yellow_concrete
fill 251 137 557 251 140 557 minecraft:orange_terracotta
setblock 253 137 599 minecraft:yellow_concrete
fill 254 137 599 254 140 599 minecraft:orange_terracotta
fill 260 137 589 260 138 589 minecraft:red_concrete
fill 262 137 557 262 140 557 minecraft:orange_terracotta
setblock 263 137 557 minecraft:yellow_concrete
fill 265 137 599 265 140 599 minecraft:orange_terracotta
fill 266 137 557 267 137 557 minecraft:yellow_concrete
setblock 270 137 599 minecraft:yellow_concrete
fill 277 137 563 277 140 563 minecraft:orange_terracotta
setblock 277 137 567 minecraft:yellow_concrete
fill 277 137 574 277 140 574 minecraft:orange_terracotta
setblock 277 137 575 minecraft:yellow_concrete
setblock 277 137 578 minecraft:yellow_concrete
fill 277 137 594 277 140 595 minecraft:orange_terracotta
fill 235 138 560 235 139 560 minecraft:yellow_concrete
fill 235 138 561 235 143 562 minecraft:orange_terracotta
setblock 235 138 563 minecraft:yellow_concrete
fill 235 138 565 235 140 565 minecraft:orange_terracotta
fill 235 138 571 235 139 572 minecraft:yellow_concrete
fill 235 138 573 235 143 574 minecraft:orange_terracotta
setblock 235 138 579 minecraft:orange_terracotta
fill 235 138 580 235 139 580 minecraft:yellow_concrete
fill 235 138 582 235 143 582 minecraft:orange_terracotta
fill 235 138 583 235 138 584 minecraft:yellow_concrete
fill 235 138 585 235 140 586 minecraft:orange_terracotta
fill 235 138 591 235 139 592 minecraft:yellow_concrete
fill 235 138 593 235 143 594 minecraft:orange_terracotta
setblock 235 138 595 minecraft:yellow_concrete
fill 235 138 596 235 141 596 minecraft:orange_terracotta
fill 236 138 557 237 139 557 minecraft:yellow_concrete
fill 236 138 558 238 138 558 minecraft:orange_concrete
fill 236 138 560 236 138 562 minecraft:orange_concrete
fill 236 138 564 236 138 566 minecraft:orange_concrete
fill 236 138 568 236 138 570 minecraft:orange_concrete
fill 236 138 572 236 138 574 minecraft:orange_concrete
fill 236 138 576 236 138 578 minecraft:orange_concrete
fill 236 138 580 236 138 582 minecraft:orange_concrete
fill 236 138 584 236 138 586 minecraft:orange_concrete
fill 236 138 588 236 138 590 minecraft:orange_concrete
fill 236 138 592 236 138 594 minecraft:orange_concrete
fill 236 138 596 236 138 598 minecraft:orange_concrete
setblock 238 138 560 minecraft:light[level=14]
setblock 238 138 568 minecraft:light[level=14]
setblock 238 138 576 minecraft:light[level=14]
setblock 238 138 584 minecraft:light[level=14]
setblock 238 138 592 minecraft:light[level=14]
fill 238 138 598 240 138 598 minecraft:orange_concrete
fill 239 138 558 239 139 558 minecraft:magma_block
fill 239 138 599 240 138 599 minecraft:yellow_concrete
fill 240 138 558 242 138 558 minecraft:orange_concrete
fill 240 138 559 240 139 561 minecraft:magma_block
fill 241 138 559 242 140 559 minecraft:magma_block
fill 241 138 561 241 139 562 minecraft:magma_block
fill 241 138 599 242 143 599 minecraft:orange_terracotta
fill 242 138 557 243 143 557 minecraft:orange_terracotta
fill 242 138 560 242 139 561 minecraft:magma_block
fill 242 138 598 244 138 598 minecraft:orange_concrete
fill 243 138 558 243 139 558 minecraft:magma_block
fill 244 138 557 245 138 557 minecraft:yellow_concrete
fill 244 138 558 246 138 558 minecraft:orange_concrete
fill 246 138 557 246 143 557 minecraft:orange_terracotta
setblock 246 138 560 minecraft:light[level=14]
setblock 246 138 568 minecraft:light[level=14]
setblock 246 138 576 minecraft:light[level=14]
setblock 246 138 584 minecraft:light[level=14]
setblock 246 138 592 minecraft:light[level=14]
fill 246 138 598 248 138 598 minecraft:orange_concrete
fill 248 138 558 250 138 558 minecraft:orange_concrete
fill 248 138 599 248 139 599 minecraft:yellow_concrete
fill 249 138 599 250 143 599 minecraft:orange_terracotta
fill 250 138 598 252 138 598 minecraft:orange_concrete
setblock 251 138 599 minecraft:yellow_concrete
fill 252 138 558 254 138 558 minecraft:orange_concrete
fill 253 138 599 253 143 599 minecraft:orange_terracotta
fill 254 138 557 255 143 557 minecraft:orange_terracotta
setblock 254 138 560 minecraft:light[level=14]
setblock 254 138 568 minecraft:light[level=14]
setblock 254 138 576 minecraft:light[level=14]
setblock 254 138 584 minecraft:light[level=14]
setblock 254 138 592 minecraft:light[level=14]
fill 254 138 598 256 138 598 minecraft:orange_concrete
fill 256 138 557 257 139 557 minecraft:yellow_concrete
fill 256 138 558 258 138 558 minecraft:orange_concrete
fill 258 138 598 260 138 598 minecraft:orange_concrete
fill 259 138 599 260 139 599 minecraft:yellow_concrete
fill 260 138 558 262 138 558 minecraft:orange_concrete
fill 261 138 599 262 143 599 minecraft:orange_terracotta
setblock 262 138 560 minecraft:light[level=14]
setblock 262 138 568 minecraft:light[level=14]
setblock 262 138 576 minecraft:light[level=14]
setblock 262 138 584 minecraft:light[level=14]
setblock 262 138 592 minecraft:light[level=14]
fill 262 138 598 264 138 598 minecraft:orange_concrete
fill 263 138 557 263 143 557 minecraft:orange_terracotta
fill 264 138 558 266 138 558 minecraft:orange_concrete
setblock 265 138 557 minecraft:yellow_concrete
fill 266 138 557 267 143 557 minecraft:orange_terracotta
fill 266 138 598 268 138 598 minecraft:orange_concrete
fill 268 138 557 268 139 557 minecraft:yellow_concrete
fill 268 138 558 270 138 558 minecraft:orange_concrete
setblock 270 138 560 minecraft:light[level=14]
setblock 270 138 568 minecraft:light[level=14]
setblock 270 138 576 minecraft:light[level=14]
setblock 270 138 584 minecraft:light[level=14]
setblock 270 138 592 minecraft:light[level=14]
fill 270 138 598 272 138 598 minecraft:orange_concrete
fill 270 138 599 270 143 599 minecraft:orange_terracotta
fill 271 138 599 272 138 599 minecraft:yellow_concrete
fill 272 138 558 274 138 558 minecraft:orange_concrete
fill 273 138 599 274 143 599 minecraft:orange_terracotta
fill 274 138 557 275 143 557 minecraft:orange_terracotta
fill 274 138 598 276 138 598 minecraft:orange_concrete
fill 276 138 557 277 138 557 minecraft:yellow_concrete
fill 276 138 558 276 138 560 minecraft:orange_concrete
fill 276 138 562 276 138 564 minecraft:orange_concrete
fill 276 138 566 276 138 568 minecraft:orange_concrete
fill 276 138 570 276 138 572 minecraft:orange_concrete
fill 276 138 574 276 138 576 minecraft:orange_concrete
fill 276 138 578 276 138 580 minecraft:orange_concrete
fill 276 138 582 276 138 584 minecraft:orange_concrete
fill 276 138 586 276 138 588 minecraft:orange_concrete
fill 276 138 590 276 138 592 minecraft:orange_concrete
fill 276 138 594 276 138 596 minecraft:orange_concrete
fill 277 138 566 277 143 567 minecraft:orange_terracotta
fill 277 138 568 277 139 569 minecraft:yellow_concrete
fill 277 138 575 277 143 575 minecraft:orange_terracotta
fill 277 138 576 277 138 577 minecraft:yellow_concrete
fill 277 138 578 277 143 578 minecraft:orange_terracotta
fill 277 138 580 277 139 580 minecraft:yellow_concrete
fill 277 138 586 277 143 587 minecraft:orange_terracotta
fill 277 138 588 277 139 589 minecraft:yellow_concrete
setblock 277 138 597 minecraft:yellow_concrete
fill 277 138 598 277 143 598 minecraft:orange_terracotta
setblock 235 139 559 minecraft:yellow_concrete
fill 235 139 563 235 142 563 minecraft:orange_terracotta
fill 235 139 567 235 141 567 minecraft:orange_terracotta
setblock 235 139 568 minecraft:yellow_concrete
setblock 235 139 579 minecraft:yellow_concrete
setblock 235 139 583 minecraft:yellow_concrete
fill 235 139 584 235 142 584 minecraft:orange_terracotta
fill 235 139 595 235 141 595 minecraft:orange_terracotta
setblock 236 139 599 minecraft:yellow_concrete
setblock 239 139 599 minecraft:yellow_concrete
fill 240 139 558 242 140 558 minecraft:magma_block
setblock 240 139 562 minecraft:magma_block
fill 240 139 599 240 142 599 minecraft:orange_terracotta
fill 241 139 563 241 139 564 minecraft:magma_block
setblock 242 139 562 minecraft:magma_block
fill 244 139 557 244 142 557 minecraft:orange_terracotta
setblock 245 139 557 minecraft:yellow_concrete
setblock 247 139 599 minecraft:yellow_concrete
fill 248 139 557 249 139 557 minecraft:yellow_concrete
fill 251 139 599 251 142 599 minecraft:orange_terracotta
fill 265 139 557 265 142 557 minecraft:orange_terracotta
fill 265 139 587 265 140 587 minecraft:yellow_concrete
fill 267 139 599 268 139 599 minecraft:yellow_concrete
setblock 269 139 557 minecraft:yellow_concrete
setblock 271 139 599 minecraft:yellow_concrete
fill 272 139 599 272 142 599 minecraft:orange_terracotta
fill 276 139 557 276 142 557 minecraft:orange_terracotta
setblock 277 139 557 minecraft:yellow_concrete
setblock 277 139 560 minecraft:yellow_concrete
fill 277 139 576 277 142 577 minecraft:orange_terracotta
setblock 277 139 581 minecraft:yellow_concrete
setblock 277 139 592 minecraft:yellow_concrete
fill 277 139 597 277 142 597 minecraft:orange_terracotta
fill 235 140 557 235 141 558 minecraft:yellow_concrete
fill 235 140 559 235 145 560 minecraft:orange_terracotta
fill 235 140 568 235 141 568 minecraft:orange_terracotta
fill 235 140 569 235 140 570 minecraft:yellow_concrete
fill 235 140 571 235 145 572 minecraft:orange_terracotta
fill 235 140 577 235 141 578 minecraft:yellow_concrete
fill 235 140 579 235 145 580 minecraft:orange_terracotta
setblock 235 140 581 minecraft:yellow_concrete
fill 235 140 583 235 142 583 minecraft:orange_terracotta
fill 235 140 589 235 141 590 minecraft:yellow_concrete
fill 235 140 591 235 145 592 minecraft:orange_terracotta
setblock 235 140 597 minecraft:orange_terracotta
fill 235 140 598 235 141 598 minecraft:yellow_concrete
fill 236 140 557 237 145 557 minecraft:orange_terracotta
fill 236 140 599 236 145 599 minecraft:orange_terracotta
fill 237 140 599 238 140 599 minecraft:yellow_concrete
fill 238 140 557 239 141 557 minecraft:yellow_concrete
fill 239 140 599 239 145 599 minecraft:orange_terracotta
setblock 240 140 559 minecraft:magma_block
setblock 241 140 561 minecraft:magma_block
fill 245 140 557 245 145 557 minecraft:orange_terracotta
fill 245 140 599 246 141 599 minecraft:yellow_concrete
setblock 247 140 557 minecraft:yellow_concrete
fill 247 140 599 248 145 599 minecraft:orange_terracotta
fill 248 140 557 249 145 557 minecraft:orange_terracotta
fill 250 140 557 250 141 557 minecraft:yellow_concrete
fill 256 140 557 257 145 557 minecraft:orange_terracotta
fill 257 140 599 258 140 599 minecraft:yellow_concrete
fill 258 140 557 259 140 557 minecraft:yellow_concrete
fill 259 140 599 260 145 599 minecraft:orange_terracotta
fill 266 140 599 266 141 599 minecraft:yellow_concrete
fill 267 140 599 268 145 599 minecraft:orange_terracotta
fill 268 140 557 269 145 557 minecraft:orange_terracotta
setblock 269 140 599 minecraft:yellow_concrete
fill 270 140 557 271 141 557 minecraft:yellow_concrete
fill 271 140 599 271 145 599 minecraft:orange_terracotta
fill 277 140 557 277 145 557 minecraft:orange_terracotta
fill 277 140 558 277 140 559 minecraft:yellow_concrete
fill 277 140 560 277 145 560 minecraft:orange_terracotta
fill 277 140 562 277 141 562 minecraft:yellow_concrete
fill 277 140 568 277 145 569 minecraft:orange_terracotta
fill 277 140 570 277 141 571 minecraft:yellow_concrete
setblock 277 140 579 minecraft:yellow_concrete
fill 277 140 580 277 145 581 minecraft:orange_terracotta
fill 277 140 582 277 141 583 minecraft:yellow_concrete
fill 277 140 588 277 145 589 minecraft:orange_terracotta
fill 277 140 590 277 140 591 minecraft:yellow_concrete
fill 277 140 592 277 145 592 minecraft:orange_terracotta
fill 277 140 599 277 141 599 minecraft:yellow_concrete
fill 235 141 565 235 141 566 minecraft:yellow_concrete
setblock 235 141 569 minecraft:yellow_concrete
fill 235 141 570 235 144 570 minecraft:orange_terracotta
fill 235 141 581 235 144 581 minecraft:orange_terracotta
fill 235 141 585 235 143 585 minecraft:orange_terracotta
setblock 235 141 586 minecraft:yellow_concrete
setblock 235 141 597 minecraft:yellow_concrete
fill 237 141 599 238 144 599 minecraft:orange_terracotta
fill 247 141 557 247 144 557 minecraft:orange_terracotta
setblock 251 141 557 minecraft:yellow_concrete
setblock 254 141 599 minecraft:yellow_concrete
setblock 257 141 599 minecraft:yellow_concrete
fill 258 141 557 258 144 557 minecraft:orange_terracotta
fill 258 141 599 258 144 599 minecraft:orange_terracotta
setblock 259 141 557 minecraft:yellow_concrete
setblock 262 141 557 minecraft:yellow_concrete
setblock 265 141 599 minecraft:yellow_concrete
fill 269 141 599 269 144 599 minecraft:orange_terracotta
fill 277 141 558 277 144 559 minecraft:orange_terracotta
setblock 277 141 563 minecraft:yellow_concrete
setblock 277 141 574 minecraft:yellow_concrete
fill 277 141 579 277 144 579 minecraft:orange_terracotta
fill 277 141 590 277 144 590 minecraft:orange_terracotta
setblock 277 141 591 minecraft:yellow_concrete
fill 277 141 594 277 141 595 minecraft:yellow_concrete
fill 235 142 557 235 147 558 minecraft:orange_terracotta
fill 235 142 564 235 143 564 minecraft:yellow_concrete
fill 235 142 565 235 143 566 minecraft:orange_terracotta
fill 235 142 567 235 142 568 minecraft:yellow_concrete
fill 235 142 569 235 147 569 minecraft:orange_terracotta
fill 235 142 575 235 143 576 minecraft:yellow_concrete
fill 235 142 577 235 147 578 minecraft:orange_terracotta
fill 235 142 586 235 143 586 minecraft:orange_terracotta
fill 235 142 587 235 142 588 minecraft:yellow_concrete
fill 235 142 589 235 147 590 minecraft:orange_terracotta
fill 235 142 595 235 143 596 minecraft:yellow_concrete
fill 235 142 597 235 147 598 minecraft:orange_terracotta
setblock 235 142 599 minecraft:yellow_concrete
fill 238 142 557 239 147 557 minecraft:orange_terracotta
fill 240 142 557 241 142 557 minecraft:yellow_concrete
fill 243 142 599 244 143 599 minecraft:yellow_concrete
fill 245 142 599 246 147 599 minecraft:orange_terracotta
fill 250 142 557 251 147 557 minecraft:orange_terracotta
fill 252 142 557 253 143 557 minecraft:yellow_concrete
fill 252 142 599 252 143 599 minecraft:yellow_concrete
fill 254 142 599 254 147 599 minecraft:orange_terracotta
fill 255 142 599 256 142 599 minecraft:yellow_concrete
fill 257 142 599 257 147 599 minecraft:orange_terracotta
fill 259 142 557 259 147 557 minecraft:orange_terracotta
fill 260 142 557 261 142 557 minecraft:yellow_concrete
fill 262 142 557 262 147 557 minecraft:orange_terracotta
fill 263 142 599 264 143 599 minecraft:yellow_concrete
fill 264 142 557 264 143 557 minecraft:yellow_concrete
fill 265 142 599 266 147 599 minecraft:orange_terracotta
fill 270 142 557 271 147 557 minecraft:orange_terracotta
fill 272 142 557 273 143 557 minecraft:yellow_concrete
fill 275 142 599 276 142 599 minecraft:yellow_concrete
setblock 277 142 561 minecraft:yellow_concrete
fill 277 142 562 277 147 563 minecraft:orange_terracotta
fill 277 142 564 277 143 565 minecraft:yellow_concrete
fill 277 142 570 277 147 571 minecraft:orange_terracotta
fill 277 142 572 277 142 573 minecraft:yellow_concrete
fill 277 142 574 277 147 574 minecraft:orange_terracotta
fill 277 142 582 277 147 583 minecraft:orange_terracotta
fill 277 142 584 277 143 585 minecraft:yellow_concrete
fill 277 142 591 277 147 591 minecraft:orange_terracotta
setblock 277 142 593 minecraft:yellow_concrete
fill 277 142 594 277 147 595 minecraft:orange_terracotta
fill 277 142 596 277 143 596 minecraft:yellow_concrete
fill 277 142 599 277 147 599 minecraft:orange_terracotta
setblock 235 143 563 minecraft:yellow_concrete
fill 235 143 567 235 145 568 minecraft:orange_terracotta
fill 235 143 583 235 143 584 minecraft:yellow_concrete
setblock 235 143 587 minecraft:yellow_concrete
fill 235 143 588 235 146 588 minecraft:orange_terracotta
fill 235 143 599 235 146 599 minecraft:orange_terracotta
fill 240 143 557 240 146 557 minecraft:orange_terracotta
setblock 240 143 599 minecraft:yellow_concrete
setblock 241 143 557 minecraft:yellow_concrete
setblock 244 143 557 minecraft:yellow_concrete
setblock 251 143 599 minecraft:yellow_concrete
fill 255 143 599 256 146 599 minecraft:orange_terracotta
fill 260 143 557 261 146 557 minecraft:orange_terracotta
setblock 265 143 557 minecraft:yellow_concrete
setblock 272 143 599 minecraft:yellow_concrete
setblock 275 143 599 minecraft:yellow_concrete
setblock 276 143 557 minecraft:yellow_concrete
fill 276 143 599 276 146 599 minecraft:orange_terracotta
fill 277 143 561 277 146 561 minecraft:orange_terracotta
fill 277 143 572 277 146 572 minecraft:orange_terracotta
setblock 277 143 573 minecraft:yellow_concrete
fill 277 143 576 277 143 577 minecraft:yellow_concrete
fill 277 143 593 277 146 593 minecraft:orange_terracotta
setblock 277 143 597 minecraft:yellow_concrete
fill 235 144 561 235 145 562 minecraft:yellow_concrete
fill 235 144 563 235 149 564 minecraft:orange_terracotta
setblock 235 144 565 minecraft:yellow_concrete
fill 235 144 566 235 147 566 minecraft:orange_terracotta
fill 235 144 573 235 145 574 minecraft:yellow_concrete
fill 235 144 575 235 149 576 minecraft:orange_terracotta
fill 235 144 582 235 145 582 minecraft:yellow_concrete
fill 235 144 583 235 145 584 minecraft:orange_terracotta
fill 235 144 585 235 144 586 minecraft:yellow_concrete
fill 235 144 587 235 149 587 minecraft:orange_terracotta
fill 235 144 593 235 145 594 minecraft:yellow_concrete
fill 235 144 595 235 149 596 minecraft:orange_terracotta
fill 236 144 558 238 144 558 minecraft:orange_concrete
fill 236 144 560 236 144 562 minecraft:orange_concrete
fill 236 144 564 236 144 566 minecraft:orange_concrete
fill 236 144 568 236 144 570 minecraft:orange_concrete
fill 236 144 572 236 144 574 minecraft:orange_concrete
fill 236 144 576 236 144 578 minecraft:orange_concrete
fill 236 144 580 236 144 582 minecraft:orange_concrete
fill 236 144 584 236 144 586 minecraft:orange_concrete
fill 236 144 588 236 144 590 minecraft:orange_concrete
fill 236 144 592 236 144 594 minecraft:orange_concrete
fill 236 144 596 236 144 598 minecraft:orange_concrete
fill 238 144 598 240 144 598 minecraft:orange_concrete
fill 240 144 558 242 144 558 minecraft:orange_concrete
fill 240 144 599 240 149 599 minecraft:orange_terracotta
fill 241 144 557 241 149 557 minecraft:orange_terracotta
fill 241 144 599 242 144 599 minecraft:yellow_concrete
fill 242 144 557 243 144 557 minecraft:yellow_concrete
fill 242 144 598 244 144 598 minecraft:orange_concrete
fill 243 144 599 244 149 599 minecraft:orange_terracotta
fill 244 144 557 244 149 557 minecraft:orange_terracotta
fill 244 144 558 246 144 558 minecraft:orange_concrete
fill 246 144 557 246 145 557 minecraft:yellow_concrete
fill 246 144 598 248 144 598 minecraft:orange_concrete
fill 248 144 558 250 144 558 minecraft:orange_concrete
fill 249 144 599 250 145 599 minecraft:yellow_concrete
fill 250 144 598 252 144 598 minecraft:orange_concrete
fill 251 144 599 252 149 599 minecraft:orange_terracotta
fill 252 144 557 253 149 557 minecraft:orange_terracotta
fill 252 144 558 254 144 558 minecraft:orange_concrete
setblock 253 144 599 minecraft:yellow_concrete
fill 254 144 557 255 145 557 minecraft:yellow_concrete
fill 254 144 598 256 144 598 minecraft:orange_concrete
fill 256 144 558 258 144 558 minecraft:orange_concrete
fill 258 144 598 260 144 598 minecraft:orange_concrete
fill 260 144 558 262 144 558 minecraft:orange_concrete
fill 261 144 599 262 145 599 minecraft:yellow_concrete
fill 262 144 598 264 144 598 minecraft:orange_concrete
setblock 263 144 557 minecraft:yellow_concrete
fill 263 144 599 264 149 599 minecraft:orange_terracotta
fill 264 144 557 265 149 557 minecraft:orange_terracotta
fill 264 144 558 266 144 558 minecraft:orange_concrete
fill 266 144 557 267 145 557 minecraft:yellow_concrete
fill 266 144 598 268 144 598 minecraft:orange_concrete
fill 268 144 558 270 144 558 minecraft:orange_concrete
fill 270 144 598 272 144 598 minecraft:orange_concrete
fill 270 144 599 270 145 599 minecraft:yellow_concrete
fill 272 144 557 273 149 557 minecraft:orange_terracotta
fill 272 144 558 274 144 558 minecraft:orange_concrete
fill 272 144 599 272 149 599 minecraft:orange_terracotta
fill 273 144 599 274 144 599 minecraft:yellow_concrete
fill 274 144 557 275 144 557 minecraft:yellow_concrete
fill 274 144 598 276 144 598 minecraft:orange_concrete
fill 275 144 599 275 149 599 minecraft:orange_terracotta
fill 276 144 557 276 149 557 minecraft:orange_terracotta
fill 276 144 558 276 144 560 minecraft:orange_concrete
fill 276 144 562 276 144 564 minecraft:orange_concrete
fill 276 144 566 276 144 568 minecraft:orange_concrete
fill 276 144 570 276 144 572 minecraft:orange_concrete
fill 276 144 574 276 144 576 minecraft:orange_concrete
fill 276 144 578 276 144 580 minecraft:orange_concrete
fill 276 144 582 276 144 584 minecraft:orange_concrete
fill 276 144 586 276 144 588 minecraft:orange_concrete
fill 276 144 590 276 144 592 minecraft:orange_concrete
fill 276 144 594 276 144 596 minecraft:orange_concrete
fill 277 144 564 277 149 565 minecraft:orange_terracotta
fill 277 144 566 277 145 567 minecraft:yellow_concrete
fill 277 144 573 277 149 573 minecraft:orange_terracotta
setblock 277 144 575 minecraft:yellow_concrete
fill 277 144 576 277 149 577 minecraft:orange_terracotta
fill 277 144 578 277 145 578 minecraft:yellow_concrete
fill 277 144 584 277 149 585 minecraft:orange_terracotta
fill 277 144 586 277 144 587 minecraft:yellow_concrete
fill 277 144 596 277 149 597 minecraft:orange_terracotta
fill 277 144 598 277 145 598 minecraft:yellow_concrete
fill 235 145 565 235 147 565 minecraft:orange_terracotta
setblock 235 145 570 minecraft:yellow_concrete
setblock 235 145 581 minecraft:yellow_concrete
fill 235 145 585 235 147 586 minecraft:orange_terracotta
fill 237 145 599 238 145 599 minecraft:yellow_concrete
setblock 241 145 599 minecraft:yellow_concrete
fill 242 145 557 243 148 557 minecraft:orange_terracotta
fill 242 145 599 242 148 599 minecraft:orange_terracotta
setblock 247 145 557 minecraft:yellow_concrete
fill 253 145 599 253 148 599 minecraft:orange_terracotta
setblock 258 145 557 minecraft:yellow_concrete
setblock 258 145 599 minecraft:yellow_concrete
fill 263 145 557 263 148 557 minecraft:orange_terracotta
setblock 269 145 599 minecraft:yellow_concrete
fill 273 145 599 274 148 599 minecraft:orange_terracotta
fill 274 145 557 274 148 557 minecraft:orange_terracotta
setblock 275 145 557 minecraft:yellow_concrete
fill 277 145 558 277 145 559 minecraft:yellow_concrete
fill 277 145 575 277 148 575 minecraft:orange_terracotta
setblock 277 145 579 minecraft:yellow_concrete
fill 277 145 586 277 148 586 minecraft:orange_terracotta
setblock 277 145 587 minecraft:yellow_concrete
setblock 277 145 590 minecraft:yellow_concrete
fill 235 146 559 235 147 560 minecraft:yellow_concrete
fill 235 146 561 235 151 562 minecraft:orange_terracotta
setblock 235 146 567 minecraft:orange_terracotta
fill 235 146 568 235 147 568 minecraft:yellow_concrete
fill 235 146 570 235 151 570 minecraft:orange_terracotta
fill 235 146 571 235 146 572 minecraft:yellow_concrete
fill 235 146 573 235 148 574 minecraft:orange_terracotta
fill 235 146 579 235 147 580 minecraft:yellow_concrete
fill 235 146 581 235 151 582 minecraft:orange_terracotta
setblock 235 146 583 minecraft:yellow_concrete
fill 235 146 584 235 149 584 minecraft:orange_terracotta
fill 235 146 591 235 146 592 minecraft:yellow_concrete
fill 235 146 593 235 151 594 minecraft:orange_terracotta
fill 236 146 557 237 147 557 minecraft:yellow_concrete
fill 236 146 599 236 147 599 minecraft:yellow_concrete
fill 237 146 599 238 151 599 minecraft:orange_terracotta
setblock 238 146 560 minecraft:light[level=14]
setblock 238 146 568 minecraft:light[level=14]
setblock 238 146 576 minecraft:light[level=14]
setblock 238 146 584 minecraft:light[level=14]
setblock 238 146 592 minecraft:light[level=14]
setblock 239 146 599 minecraft:yellow_concrete
fill 241 146 599 241 151 599 minecraft:orange_terracotta
setblock 245 146 557 minecraft:yellow_concrete
fill 246 146 557 247 151 557 minecraft:orange_terracotta
setblock 246 146 560 minecraft:light[level=14]
setblock 246 146 568 minecraft:light[level=14]
setblock 246 146 576 minecraft:light[level=14]
setblock 246 146 584 minecraft:light[level=14]
setblock 246 146 592 minecraft:light[level=14]
fill 247 146 599 248 147 599 minecraft:yellow_concrete
fill 248 146 557 249 147 557 minecraft:yellow_concrete
fill 249 146 599 250 151 599 minecraft:orange_terracotta
fill 254 146 557 255 151 557 minecraft:orange_terracotta
setblock 254 146 560 minecraft:light[level=14]
setblock 254 146 568 minecraft:light[level=14]
setblock 254 146 576 minecraft:light[level=14]
setblock 254 146 584 minecraft:light[level=14]
setblock 254 146 592 minecraft:light[level=14]
fill 256 146 557 257 146 557 minecraft:yellow_concrete
fill 258 146 557 258 151 557 minecraft:orange_terracotta
fill 258 146 599 258 151 599 minecraft:orange_terracotta
fill 259 146 599 260 146 599 minecraft:yellow_concrete
fill 261 146 599 262 151 599 minecraft:orange_terracotta
setblock 262 146 560 minecraft:light[level=14]
setblock 262 146 568 minecraft:light[level=14]
setblock 262 146 576 minecraft:light[level=14]
setblock 262 146 584 minecraft:light[level=14]
setblock 262 146 592 minecraft:light[level=14]
fill 266 146 557 267 151 557 minecraft:orange_terracotta
fill 267 146 599 268 147 599 minecraft:yellow_concrete
fill 268 146 557 269 147 557 minecraft:yellow_concrete
fill 269 146 599 270 151 599 minecraft:orange_terracotta
setblock 270 146 560 minecraft:light[level=14]
setblock 270 146 568 minecraft:light[level=14]
setblock 270 146 576 minecraft:light[level=14]
setblock 270 146 584 minecraft:light[level=14]
setblock 270 146 592 minecraft:light[level=14]
setblock 271 146 599 minecraft:yellow_concrete
fill 275 146 557 275 151 557 minecraft:orange_terracotta
setblock 277 146 557 minecraft:yellow_concrete
fill 277 146 558 277 151 559 minecraft:orange_terracotta
fill 277 146 560 277 147 560 minecraft:yellow_concrete
fill 277 146 566 277 151 567 minecraft:orange_terracotta
fill 277 146 568 277 146 569 minecraft:yellow_concrete
fill 277 146 578 277 151 579 minecraft:orange_terracotta
fill 277 146 580 277 147 581 minecraft:yellow_concrete
fill 277 146 587 277 151 587 minecraft:orange_terracotta
fill 277 146 588 277 146 589 minecraft:yellow_concrete
fill 277 146 590 277 151 590 minecraft:orange_terracotta
fill 277 146 592 277 147 592 minecraft:yellow_concrete
fill 277 146 598 277 151 598 minecraft:orange_terracotta
setblock 235 147 567 minecraft:yellow_concrete
setblock 235 147 571 minecraft:yellow_concrete
fill 235 147 572 235 150 572 minecraft:orange_terracotta
fill 235 147 583 235 149 583 minecraft:orange_terracotta
setblock 235 147 588 minecraft:yellow_concrete
setblock 235 147 591 minecraft:yellow_concrete
fill 235 147 592 235 150 592 minecraft:orange_terracotta
setblock 235 147 599 minecraft:yellow_concrete
fill 239 147 599 239 150 599 minecraft:orange_terracotta
setblock 240 147 557 minecraft:yellow_concrete
fill 245 147 557 245 150 557 minecraft:orange_terracotta
fill 245 147 580 246 148 581 minecraft:red_concrete
fill 255 147 599 256 147 599 minecraft:yellow_concrete
fill 256 147 557 256 150 557 minecraft:orange_terracotta
setblock 257 147 557 minecraft:yellow_concrete
setblock 259 147 599 minecraft:yellow_concrete
fill 260 147 557 261 147 557 minecraft:yellow_concrete
fill 260 147 599 260 150 599 minecraft:orange_terracotta
fill 271 147 599 271 150 599 minecraft:orange_terracotta
setblock 276 147 599 minecraft:yellow_concrete
fill 277 147 557 277 150 557 minecraft:orange_terracotta
setblock 277 147 561 minecraft:yellow_concrete
fill 277 147 568 277 150 568 minecraft:orange_terracotta
setblock 277 147 569 minecraft:yellow_concrete
setblock 277 147 572 minecraft:yellow_concrete
fill 277 147 588 277 150 589 minecraft:orange_terracotta
setblock 277 147 593 minecraft:yellow_concrete
fill 235 148 557 235 148 558 minecraft:yellow_concrete
fill 235 148 559 235 153 560 minecraft:orange_terracotta
fill 235 148 565 235 149 566 minecraft:yellow_concrete
fill 235 148 567 235 153 568 minecraft:orange_terracotta
setblock 235 148 569 minecraft:yellow_concrete
fill 235 148 571 235 150 571 minecraft:orange_terracotta
fill 235 148 577 235 149 578 minecraft:yellow_concrete
fill 235 148 579 235 153 580 minecraft:orange_terracotta
setblock 235 148 585 minecraft:orange_terracotta
fill 235 148 586 235 149 586 minecraft:yellow_concrete
fill 235 148 588 235 153 588 minecraft:orange_terracotta
fill 235 148 589 235 148 590 minecraft:yellow_concrete
fill 235 148 591 235 153 591 minecraft:orange_terracotta
fill 235 148 597 235 149 598 minecraft:yellow_concrete
fill 235 148 599 236 153 599 minecraft:orange_terracotta
fill 236 148 557 237 153 557 minecraft:orange_terracotta
fill 238 148 557 239 148 557 minecraft:yellow_concrete
fill 240 148 557 240 153 557 minecraft:orange_terracotta
fill 245 148 599 246 148 599 minecraft:yellow_concrete
fill 247 148 599 248 153 599 minecraft:orange_terracotta
fill 248 148 557 249 153 557 minecraft:orange_terracotta
fill 250 148 557 251 149 557 minecraft:yellow_concrete
fill 252 148 565 252 149 565 minecraft:orange_concrete
fill 254 148 599 254 149 599 minecraft:yellow_concrete
fill 255 148 599 256 153 599 minecraft:orange_terracotta
fill 257 148 557 257 153 557 minecraft:orange_terracotta
setblock 257 148 599 minecraft:yellow_concrete
setblock 259 148 557 minecraft:yellow_concrete
fill 259 148 599 259 153 599 minecraft:orange_terracotta
fill 260 148 557 261 153 557 minecraft:orange_terracotta
fill 262 148 557 262 149 557 minecraft:yellow_concrete
fill 265 148 599 266 149 599 minecraft:yellow_concrete
fill 267 148 599 268 153 599 minecraft:orange_terracotta
fill 268 148 557 269 153 557 minecraft:orange_terracotta
fill 270 148 557 271 148 557 minecraft:yellow_concrete
fill 276 148 599 276 153 599 minecraft:orange_terracotta
fill 277 148 560 277 153 561 minecraft:orange_terracotta
fill 277 148 562 277 149 563 minecraft:yellow_concrete
fill 277 148 569 277 153 569 minecraft:orange_terracotta
fill 277 148 570 277 148 571 minecraft:yellow_concrete
fill 277 148 572 277 153 572 minecraft:orange_terracotta
fill 277 148 574 277 149 574 minecraft:yellow_concrete
fill 277 148 580 277 153 581 minecraft:orange_terracotta
fill 277 148 582 277 149 583 minecraft:yellow_concrete
setblock 277 148 591 minecraft:yellow_concrete
fill 277 148 592 277 153 593 minecraft:orange_terracotta
fill 277 148 594 277 149 595 minecraft:yellow_concrete
fill 277 148 599 277 149 599 minecraft:yellow_concrete
setblock 235 149 557 minecraft:yellow_concrete
fill 235 149 558 235 152 558 minecraft:orange_terracotta
fill 235 149 569 235 152 569 minecraft:orange_terracotta
fill 235 149 573 235 151 573 minecraft:orange_terracotta
setblock 235 149 574 minecraft:yellow_concrete
setblock 235 149 585 minecraft:yellow_concrete
fill 235 149 589 235 152 590 minecraft:orange_terracotta
fill 238 149 557 238 152 557 minecraft:orange_terracotta
setblock 239 149 557 minecraft:yellow_concrete
fill 242 149 557 243 149 557 minecraft:yellow_concrete
setblock 242 149 599 minecraft:yellow_concrete
setblock 245 149 599 minecraft:yellow_concrete
fill 246 149 599 246 152 599 minecraft:orange_terracotta
setblock 253 149 599 minecraft:yellow_concrete
fill 257 149 599 257 152 599 minecraft:orange_terracotta
fill 259 149 557 259 152 557 minecraft:orange_terracotta
setblock 263 149 557 minecraft:yellow_concrete
fill 270 149 557 270 152 557 minecraft:orange_terracotta
setblock 271 149 557 minecraft:yellow_concrete
fill 273 149 599 274 149 599 minecraft:yellow_concrete
setblock 274 149 557 minecraft:yellow_concrete
fill 277 149 570 277 152 571 minecraft:orange_terracotta
setblock 277 149 575 minecraft:yellow_concrete
setblock 277 149 586 minecraft:yellow_concrete
fill 277 149 591 277 152 591 minecraft:orange_terracotta
fill 235 150 557 235 155 557 minecraft:orange_terracotta
fill 235 150 563 235 151 564 minecraft:yellow_concrete
fill 235 150 565 235 155 566 minecraft:orange_terracotta
fill 235 150 574 235 151 574 minecraft:orange_terracotta
fill 235 150 575 235 150 576 minecraft:yellow_concrete
fill 235 150 577 235 155 578 minecraft:orange_terracotta
fill 235 150 583 235 151 584 minecraft:yellow_concrete
fill 235 150 585 235 155 586 minecraft:orange_terracotta
setblock 235 150 587 minecraft:yellow_concrete
fill 235 150 595 235 151 596 minecraft:yellow_concrete
fill 235 150 597 235 155 598 minecraft:orange_terracotta
fill 236 150 558 238 150 558 minecraft:orange_concrete
fill 236 150 560 236 150 562 minecraft:orange_concrete
fill 236 150 564 236 150 566 minecraft:orange_concrete
fill 236 150 568 236 150 570 minecraft:orange_concrete
fill 236 150 572 236 150 574 minecraft:orange_concrete
fill 236 150 576 236 150 578 minecraft:orange_concrete
fill 236 150 580 236 150 582 minecraft:orange_concrete
fill 236 150 584 236 150 586 minecraft:orange_concrete
fill 236 150 588 236 150 590 minecraft:orange_concrete
fill 236 150 592 236 150 594 minecraft:orange_concrete
fill 236 150 596 236 150 598 minecraft:orange_concrete
fill 238 150 598 240 150 598 minecraft:orange_concrete
fill 239 150 557 239 155 557 minecraft:orange_terracotta
fill 240 150 558 242 150 558 minecraft:orange_concrete
fill 240 150 599 240 151 599 minecraft:yellow_concrete
setblock 241 150 557 minecraft:yellow_concrete
fill 242 150 557 243 155 557 minecraft:orange_terracotta
fill 242 150 598 244 150 598 minecraft:orange_concrete
fill 242 150 599 242 155 599 minecraft:orange_terracotta
fill 243 150 581 243 151 581 minecraft:orange_concrete
fill 243 150 599 244 150 599 minecraft:yellow_concrete
fill 244 150 557 244 151 557 minecraft:yellow_concrete
fill 244 150 558 246 150 558 minecraft:orange_concrete
fill 245 150 599 245 155 599 minecraft:orange_terracotta
fill 246 150 598 248 150 598 minecraft:orange_concrete
fill 248 150 558 250 150 558 minecraft:orange_concrete
fill 250 150 557 251 155 557 minecraft:orange_terracotta
fill 250 150 598 252 150 598 minecraft:orange_concrete
fill 251 150 599 252 151 599 minecraft:yellow_concrete
fill 252 150 557 253 150 557 minecraft:yellow_concrete
fill 252 150 558 254 150 558 minecraft:orange_concrete
fill 253 150 599 254 155 599 minecraft:orange_terracotta
fill 254 150 598 256 150 598 minecraft:orange_concrete
fill 256 150 558 258 150 558 minecraft:orange_concrete
fill 258 150 598 260 150 598 minecraft:orange_concrete
fill 260 150 558 262 150 558 minecraft:orange_concrete
fill 262 150 557 263 155 557 minecraft:orange_terracotta
fill 262 150 598 264 150 598 minecraft:orange_concrete
fill 263 150 599 264 150 599 minecraft:yellow_concrete
fill 264 150 557 265 151 557 minecraft:yellow_concrete
fill 264 150 558 266 150 558 minecraft:orange_concrete
fill 265 150 599 266 155 599 minecraft:orange_terracotta
fill 266 150 598 268 150 598 minecraft:orange_concrete
fill 268 150 558 270 150 558 minecraft:orange_concrete
fill 270 150 598 272 150 598 minecraft:orange_concrete
fill 271 150 557 271 155 557 minecraft:orange_terracotta
fill 272 150 557 273 150 557 minecraft:yellow_concrete
fill 272 150 558 274 150 558 minecraft:orange_concrete
fill 272 150 599 272 151 599 minecraft:yellow_concrete
fill 273 150 599 274 155 599 minecraft:orange_terracotta
fill 274 150 557 274 155 557 minecraft:orange_terracotta
fill 274 150 598 276 150 598 minecraft:orange_concrete
setblock 275 150 599 minecraft:yellow_concrete
fill 276 150 557 276 151 557 minecraft:yellow_concrete
fill 276 150 558 276 150 560 minecraft:orange_concrete
fill 276 150 562 276 150 564 minecraft:orange_concrete
fill 276 150 566 276 150 568 minecraft:orange_concrete
fill 276 150 570 276 150 572 minecraft:orange_concrete
fill 276 150 574 276 150 576 minecraft:orange_concrete
fill 276 150 578 276 150 580 minecraft:orange_concrete
fill 276 150 582 276 150 584 minecraft:orange_concrete
fill 276 150 586 276 150 588 minecraft:orange_concrete
fill 276 150 590 276 150 592 minecraft:orange_concrete
fill 276 150 594 276 150 596 minecraft:orange_concrete
fill 277 150 562 277 155 563 minecraft:orange_terracotta
fill 277 150 564 277 151 565 minecraft:yellow_concrete
setblock 277 150 573 minecraft:yellow_concrete
fill 277 150 574 277 155 575 minecraft:orange_terracotta
fill 277 150 576 277 151 577 minecraft:yellow_concrete
fill 277 150 582 277 155 583 minecraft:orange_terracotta
fill 277 150 584 277 150 585 minecraft:yellow_concrete
fill 277 150 586 277 155 586 minecraft:orange_terracotta
fill 277 150 594 277 155 595 minecraft:orange_terracotta
fill 277 150 596 277 151 597 minecraft:yellow_concrete
fill 277 150 599 277 155 599 minecraft:orange_terracotta
fill 235 151 571 235 151 572 minecraft:yellow_concrete
setblock 235 151 575 minecraft:yellow_concrete
fill 235 151 576 235 154 576 minecraft:orange_terracotta
fill 235 151 587 235 154 587 minecraft:orange_terracotta
setblock 235 151 592 minecraft:yellow_concrete
setblock 239 151 599 minecraft:yellow_concrete
fill 240 151 558 240 153 559 minecraft:magma_block
fill 241 151 557 241 154 557 minecraft:orange_terracotta
fill 243 151 599 244 154 599 minecraft:orange_terracotta
setblock 245 151 557 minecraft:yellow_concrete
fill 252 151 557 252 154 557 minecraft:orange_terracotta
setblock 253 151 557 minecraft:yellow_concrete
setblock 256 151 557 minecraft:yellow_concrete
setblock 260 151 599 minecraft:yellow_concrete
setblock 263 151 599 minecraft:yellow_concrete
fill 264 151 599 264 154 599 minecraft:orange_terracotta
setblock 271 151 599 minecraft:yellow_concrete
fill 272 151 557 273 154 557 minecraft:orange_terracotta
fill 275 151 599 275 154 599 minecraft:orange_terracotta
setblock 277 151 557 minecraft:yellow_concrete
setblock 277 151 568 minecraft:yellow_concrete
fill 277 151 573 277 154 573 minecraft:orange_terracotta
fill 277 151 584 277 154 584 minecraft:orange_terracotta
setblock 277 151 585 minecraft:yellow_concrete
fill 277 151 588 277 151 589 minecraft:yellow_concrete
fill 235 152 561 235 153 562 minecraft:yellow_concrete
fill 235 152 563 235 157 564 minecraft:orange_terracotta
fill 235 152 570 235 153 570 minecraft:yellow_concrete
fill 235 152 571 235 153 572 minecraft:orange_terracotta
fill 235 152 573 235 152 574 minecraft:yellow_concrete
fill 235 152 575 235 157 575 minecraft:orange_terracotta
fill 235 152 581 235 153 582 minecraft:yellow_concrete
fill 235 152 583 235 157 584 minecraft:orange_terracotta
fill 235 152 592 235 157 592 minecraft:orange_terracotta
fill 235 152 593 235 152 594 minecraft:yellow_concrete
fill 235 152 595 235 157 596 minecraft:orange_terracotta
fill 237 152 599 238 153 599 minecraft:yellow_concrete
fill 239 152 558 239 152 560 minecraft:magma_block
fill 239 152 599 240 157 599 minecraft:orange_terracotta
fill 240 152 560 240 152 562 minecraft:magma_block
fill 241 152 558 241 152 560 minecraft:magma_block
setblock 241 152 599 minecraft:yellow_concrete
fill 244 152 557 245 157 557 minecraft:orange_terracotta
fill 246 152 557 247 153 557 minecraft:yellow_concrete
fill 249 152 599 250 153 599 minecraft:yellow_concrete
fill 251 152 599 252 157 599 minecraft:orange_terracotta
fill 253 152 557 253 157 557 minecraft:orange_terracotta
fill 254 152 557 255 152 557 minecraft:yellow_concrete
fill 256 152 557 256 157 557 minecraft:orange_terracotta
fill 258 152 557 258 153 557 minecraft:yellow_concrete
fill 258 152 599 258 153 599 minecraft:yellow_concrete
fill 260 152 599 260 157 599 minecraft:orange_terracotta
fill 261 152 599 262 152 599 minecraft:yellow_concrete
fill 263 152 599 263 157 599 minecraft:orange_terracotta
fill 264 152 557 265 157 557 minecraft:orange_terracotta
fill 266 152 557 267 153 557 minecraft:yellow_concrete
fill 269 152 599 270 153 599 minecraft:yellow_concrete
fill 271 152 599 272 157 599 minecraft:orange_terracotta
setblock 275 152 557 minecraft:yellow_concrete
fill 276 152 557 277 157 557 minecraft:orange_terracotta
fill 277 152 558 277 153 559 minecraft:yellow_concrete
fill 277 152 564 277 157 565 minecraft:orange_terracotta
fill 277 152 566 277 152 567 minecraft:yellow_concrete
fill 277 152 568 277 157 568 minecraft:orange_terracotta
fill 277 152 576 277 157 577 minecraft:orange_terracotta
fill 277 152 578 277 153 579 minecraft:yellow_concrete
fill 277 152 585 277 157 585 minecraft:orange_terracotta
setblock 277 152 587 minecraft:yellow_concrete
fill 277 152 588 277 157 589 minecraft:orange_terracotta
fill 277 152 590 277 153 590 minecraft:yellow_concrete
fill 277 152 596 277 157 597 minecraft:orange_terracotta
setblock 277 152 598 minecraft:yellow_concrete
setblock 235 153 558 minecraft:yellow_concrete
setblock 235 153 569 minecraft:yellow_concrete
fill 235 153 573 235 155 574 minecraft:orange_terracotta
fill 235 153 589 235 153 590 minecraft:yellow_concrete
setblock 235 153 593 minecraft:yellow_concrete
fill 235 153 594 235 156 594 minecraft:orange_terracotta
setblock 238 153 557 minecraft:yellow_concrete
fill 239 153 558 239 153 559 minecraft:magma_block
fill 240 153 560 240 153 561 minecraft:magma_block
fill 241 153 558 241 153 559 minecraft:magma_block
fill 241 153 599 241 156 599 minecraft:orange_terracotta
setblock 246 153 599 minecraft:yellow_concrete
fill 254 153 557 255 156 557 minecraft:orange_terracotta
setblock 257 153 599 minecraft:yellow_concrete
setblock 259 153 557 minecraft:yellow_concrete
fill 261 153 599 262 156 599 minecraft:orange_terracotta
setblock 270 153 557 minecraft:yellow_concrete
fill 275 153 557 275 156 557 minecraft:orange_terracotta
fill 277 153 566 277 156 566 minecraft:orange_terracotta
setblock 277 153 567 minecraft:yellow_concrete
fill 277 153 570 277 153 571 minecraft:yellow_concrete
fill 277 153 587 277 156 587 minecraft:orange_terracotta
setblock 277 153 591 minecraft:yellow_concrete
fill 277 153 598 277 156 598 minecraft:orange_terracotta
fill 235 154 558 235 159 558 minecraft:orange_terracotta
fill 235 154 559 235 154 560 minecraft:yellow_concrete
fill 235 154 561 235 156 562 minecraft:orange_terracotta
fill 235 154 567 235 155 568 minecraft:yellow_concrete
fill 235 154 569 235 159 570 minecraft:orange_terracotta
setblock 235 154 571 minecraft:yellow_concrete
fill 235 154 572 235 157 572 minecraft:orange_terracotta
fill 235 154 579 235 154 580 minecraft:yellow_concrete
fill 235 154 581 235 159 582 minecraft:orange_terracotta
fill 235 154 588 235 155 588 minecraft:yellow_concrete
fill 235 154 589 235 159 590 minecraft:orange_terracotta
setblock 235 154 591 minecraft:yellow_concrete
fill 235 154 593 235 159 593 minecraft:orange_terracotta
fill 235 154 599 236 155 599 minecraft:yellow_concrete
fill 236 154 557 237 154 557 minecraft:yellow_concrete
fill 237 154 599 238 159 599 minecraft:orange_terracotta
fill 238 154 557 238 159 557 minecraft:orange_terracotta
setblock 238 154 560 minecraft:light[level=14]
setblock 238 154 568 minecraft:light[level=14]
setblock 238 154 576 minecraft:light[level=14]
setblock 238 154 584 minecraft:light[level=14]
setblock 238 154 592 minecraft:light[level=14]
fill 240 154 557 240 155 557 minecraft:yellow_concrete
setblock 240 154 558 minecraft:magma_block
fill 246 154 557 247 159 557 minecraft:orange_terracotta
setblock 246 154 560 minecraft:light[level=14]
setblock 246 154 568 minecraft:light[level=14]
setblock 246 154 576 minecraft:light[level=14]
setblock 246 154 584 minecraft:light[level=14]
setblock 246 154 592 minecraft:light[level=14]
fill 246 154 599 246 159 599 minecraft:orange_terracotta
fill 247 154 599 248 154 599 minecraft:yellow_concrete
fill 248 154 557 249 155 557 minecraft:yellow_concrete
fill 249 154 599 250 159 599 minecraft:orange_terracotta
setblock 254 154 560 minecraft:light[level=14]
setblock 254 154 568 minecraft:light[level=14]
setblock 254 154 576 minecraft:light[level=14]
setblock 254 154 584 minecraft:light[level=14]
setblock 254 154 592 minecraft:light[level=14]
fill 255 154 599 256 155 599 minecraft:yellow_concrete
setblock 257 154 557 minecraft:yellow_concrete
fill 257 154 599 258 159 599 minecraft:orange_terracotta
fill 258 154 557 259 159 557 minecraft:orange_terracotta
setblock 259 154 599 minecraft:yellow_concrete
fill 260 154 557 261 155 557 minecraft:yellow_concrete
setblock 262 154 560 minecraft:light[level=14]
setblock 262 154 568 minecraft:light[level=14]
setblock 262 154 576 minecraft:light[level=14]
setblock 262 154 584 minecraft:light[level=14]
setblock 262 154 592 minecraft:light[level=14]
fill 266 154 557 267 159 557 minecraft:orange_terracotta
fill 267 154 599 268 155 599 minecraft:yellow_concrete
fill 268 154 557 269 154 557 minecraft:yellow_concrete
fill 269 154 599 270 159 599 minecraft:orange_terracotta
fill 270 154 557 270 159 557 minecraft:orange_terracotta
setblock 270 154 560 minecraft:light[level=14]
setblock 270 154 568 minecraft:light[level=14]
setblock 270 154 576 minecraft:light[level=14]
setblock 270 154 584 minecraft:light[level=14]
setblock 270 154 592 minecraft:light[level=14]
fill 276 154 599 276 155 599 minecraft:yellow_concrete
fill 277 154 558 277 159 559 minecraft:orange_terracotta
fill 277 154 560 277 155 561 minecraft:yellow_concrete
fill 277 154 567 277 159 567 minecraft:orange_terracotta
setblock 277 154 569 minecraft:yellow_concrete
fill 277 154 570 277 159 571 minecraft:orange_terracotta
fill 277 154 572 277 155 572 minecraft:yellow_concrete
fill 277 154 578 277 159 579 minecraft:orange_terracotta
fill 277 154 580 277 154 581 minecraft:yellow_concrete
fill 277 154 590 277 159 591 minecraft:orange_terracotta
fill 277 154 592 277 155 593 minecraft:yellow_concrete
setblock 235 155 559 minecraft:yellow_concrete
fill 235 155 560 235 158 560 minecraft:orange_terracotta
fill 235 155 571 235 157 571 minecraft:orange_terracotta
setblock 235 155 576 minecraft:yellow_concrete
setblock 235 155 579 minecraft:yellow_concrete
fill 235 155 580 235 158 580 minecraft:orange_terracotta
setblock 235 155 587 minecraft:yellow_concrete
fill 235 155 591 235 158 591 minecraft:orange_terracotta
fill 236 155 557 237 157 557 minecraft:orange_terracotta
setblock 241 155 557 minecraft:yellow_concrete
fill 243 155 599 244 155 599 minecraft:yellow_concrete
setblock 247 155 599 minecraft:yellow_concrete
fill 248 155 599 248 158 599 minecraft:orange_terracotta
setblock 252 155 557 minecraft:yellow_concrete
fill 257 155 557 257 158 557 minecraft:orange_terracotta
fill 259 155 599 259 158 599 minecraft:orange_terracotta
setblock 264 155 599 minecraft:yellow_concrete
fill 268 155 557 268 158 557 minecraft:orange_terracotta
setblock 269 155 557 minecraft:yellow_concrete
fill 272 155 557 273 155 557 minecraft:yellow_concrete
setblock 275 155 599 minecraft:yellow_concrete
fill 277 155 569 277 158 569 minecraft:orange_terracotta
setblock 277 155 573 minecraft:yellow_concrete
fill 277 155 580 277 158 580 minecraft:orange_terracotta
setblock 277 155 581 minecraft:yellow_concrete
setblock 277 155 584 minecraft:yellow_concrete
setblock 235 156 557 minecraft:yellow_concrete
fill 235 156 559 235 158 559 minecraft:orange_terracotta
fill 235 156 565 235 157 566 minecraft:yellow_concrete
fill 235 156 567 235 161 568 minecraft:orange_terracotta
setblock 235 156 573 minecraft:orange_terracotta
fill 235 156 574 235 157 574 minecraft:yellow_concrete
fill 235 156 576 235 161 576 minecraft:orange_terracotta
fill 235 156 577 235 156 578 minecraft:yellow_concrete
fill 235 156 579 235 161 579 minecraft:orange_terracotta
fill 235 156 585 235 157 586 minecraft:yellow_concrete
fill 235 156 587 235 161 588 minecraft:orange_terracotta
fill 235 156 597 235 156 598 minecraft:yellow_concrete
fill 235 156 599 236 161 599 minecraft:orange_terracotta
fill 236 156 558 238 156 558 minecraft:orange_concrete
fill 236 156 560 236 156 562 minecraft:orange_concrete
fill 236 156 564 236 156 566 minecraft:orange_concrete
fill 236 156 568 236 156 570 minecraft:orange_concrete
fill 236 156 572 236 156 574 minecraft:orange_concrete
fill 236 156 576 236 156 578 minecraft:orange_concrete
fill 236 156 580 236 156 582 minecraft:orange_concrete
fill 236 156 584 236 156 586 minecraft:orange_concrete
fill 236 156 588 236 156 590 minecraft:orange_concrete
fill 236 156 592 236 156 594 minecraft:orange_concrete
fill 236 156 596 236 156 598 minecraft:orange_concrete
fill 238 156 598 240 156 598 minecraft:orange_concrete
setblock 239 156 557 minecraft:yellow_concrete
fill 240 156 557 241 161 557 minecraft:orange_terracotta
fill 240 156 558 242 156 558 minecraft:orange_concrete
fill 242 156 557 243 157 557 minecraft:yellow_concrete
fill 242 156 598 244 156 598 minecraft:orange_concrete
fill 242 156 599 242 157 599 minecraft:yellow_concrete
fill 243 156 599 244 161 599 minecraft:orange_terracotta
fill 244 156 558 246 156 558 minecraft:orange_concrete
setblock 245 156 599 minecraft:yellow_concrete
fill 246 156 598 248 156 598 minecraft:orange_concrete
fill 247 156 599 247 161 599 minecraft:orange_terracotta
fill 248 156 557 249 161 557 minecraft:orange_terracotta
fill 248 156 558 250 156 558 minecraft:orange_concrete
fill 250 156 557 251 156 557 minecraft:yellow_concrete
fill 250 156 598 252 156 598 minecraft:orange_concrete
fill 252 156 557 252 161 557 minecraft:orange_terracotta
fill 252 156 558 254 156 558 minecraft:orange_concrete
fill 253 156 599 254 157 599 minecraft:yellow_concrete
fill 254 156 598 256 156 598 minecraft:orange_concrete
fill 255 156 599 256 161 599 minecraft:orange_terracotta
fill 256 156 558 258 156 558 minecraft:orange_concrete
fill 258 156 598 260 156 598 minecraft:orange_concrete
fill 260 156 557 261 161 557 minecraft:orange_terracotta
fill 260 156 558 262 156 558 minecraft:orange_concrete
fill 262 156 557 263 157 557 minecraft:yellow_concrete
fill 262 156 598 264 156 598 minecraft:orange_concrete
fill 264 156 558 266 156 558 minecraft:orange_concrete
fill 264 156 599 264 161 599 minecraft:orange_terracotta
fill 265 156 599 266 156 599 minecraft:yellow_concrete
fill 266 156 598 268 156 598 minecraft:orange_concrete
fill 267 156 599 268 161 599 minecraft:orange_terracotta
fill 268 156 558 270 156 558 minecraft:orange_concrete
fill 269 156 557 269 161 557 minecraft:orange_terracotta
fill 270 156 598 272 156 598 minecraft:orange_concrete
setblock 271 156 557 minecraft:yellow_concrete
fill 272 156 557 273 161 557 minecraft:orange_terracotta
fill 272 156 558 274 156 558 minecraft:orange_concrete
fill 273 156 599 274 157 599 minecraft:yellow_concrete
fill 274 156 557 274 157 557 minecraft:yellow_concrete
fill 274 156 598 276 156 598 minecraft:orange_concrete
fill 275 156 599 276 161 599 minecraft:orange_terracotta
fill 276 156 558 276 156 560 minecraft:orange_concrete
fill 276 156 562 276 156 564 minecraft:orange_concrete
fill 276 156 566 276 156 568 minecraft:orange_concrete
fill 276 156 570 276 156 572 minecraft:orange_concrete
fill 276 156 574 276 156 576 minecraft:orange_concrete
fill 276 156 578 276 156 580 minecraft:orange_concrete
fill 276 156 582 276 156 584 minecraft:orange_concrete
fill 276 156 586 276 156 588 minecraft:orange_concrete
fill 276 156 590 276 156 592 minecraft:orange_concrete
fill 276 156 594 276 156 596 minecraft:orange_concrete
fill 277 156 560 277 161 561 minecraft:orange_terracotta
fill 277 156 562 277 156 563 minecraft:yellow_concrete
fill 277 156 572 277 161 573 minecraft:orange_terracotta
fill 277 156 574 277 157 575 minecraft:yellow_concrete
fill 277 156 581 277 161 581 minecraft:orange_terracotta
fill 277 156 582 277 156 583 minecraft:yellow_concrete
fill 277 156 584 277 161 584 minecraft:orange_terracotta
fill 277 156 586 277 157 586 minecraft:yellow_concrete
fill 277 156 592 277 161 593 minecraft:orange_terracotta
fill 277 156 594 277 157 595 minecraft:yellow_concrete
setblock 277 156 599 minecraft:yellow_concrete
fill 235 157 557 235 160 557 minecraft:orange_terracotta
fill 235 157 561 235 159 561 minecraft:orange_terracotta
setblock 235 157 562 minecraft:yellow_concrete
setblock 235 157 573 minecraft:yellow_concrete
fill 235 157 577 235 160 578 minecraft:orange_terracotta
setblock 235 157 594 minecraft:yellow_concrete
setblock 235 157 597 minecraft:yellow_concrete
fill 235 157 598 235 160 598 minecraft:orange_terracotta
fill 239 157 557 239 159 557 minecraft:orange_terracotta
setblock 241 157 599 minecraft:yellow_concrete
fill 245 157 599 245 160 599 minecraft:orange_terracotta
fill 250 157 557 250 160 557 minecraft:orange_terracotta
setblock 251 157 557 minecraft:yellow_concrete
fill 254 157 557 255 157 557 minecraft:yellow_concrete
fill 261 157 599 262 157 599 minecraft:yellow_concrete
setblock 265 157 599 minecraft:yellow_concrete
fill 266 157 599 266 160 599 minecraft:orange_terracotta
fill 268 157 567 269 158 567 minecraft:yellow_concrete
fill 271 157 557 271 160 557 minecraft:orange_terracotta
setblock 275 157 557 minecraft:yellow_concrete
fill 277 157 562 277 160 562 minecraft:orange_terracotta
setblock 277 157 563 minecraft:yellow_concrete
setblock 277 157 566 minecraft:yellow_concrete
fill 277 157 582 277 160 583 minecraft:orange_terracotta
setblock 277 157 587 minecraft:yellow_concrete
setblock 277 157 598 minecraft:yellow_concrete
fill 277 157 599 277 160 599 minecraft:orange_terracotta
fill 235 158 562 235 159 562 minecraft:orange_terracotta
fill 235 158 563 235 158 564 minecraft:yellow_concrete
fill 235 158 565 235 163 566 minecraft:orange_terracotta
fill 235 158 571 235 159 572 minecraft:yellow_concrete
fill 235 158 573 235 163 574 minecraft:orange_terracotta
setblock 235 158 575 minecraft:yellow_concrete
fill 235 158 583 235 159 584 minecraft:yellow_concrete
fill 235 158 585 235 163 586 minecraft:orange_terracotta
fill 235 158 592 235 159 592 minecraft:yellow_concrete
fill 235 158 594 235 163 594 minecraft:orange_terracotta
fill 235 158 595 235 158 596 minecraft:yellow_concrete
fill 235 158 597 235 163 597 minecraft:orange_terracotta
fill 236 158 557 236 159 557 minecraft:yellow_concrete
setblock 237 158 557 minecraft:orange_terracotta
fill 239 158 599 240 159 599 minecraft:yellow_concrete
fill 241 158 599 242 163 599 minecraft:orange_terracotta
fill 242 158 557 243 163 557 minecraft:orange_terracotta
fill 242 158 570 242 159 571 minecraft:orange_concrete
fill 244 158 557 245 159 557 minecraft:yellow_concrete
fill 251 158 557 251 163 557 minecraft:orange_terracotta
fill 251 158 599 252 158 599 minecraft:yellow_concrete
setblock 253 158 557 minecraft:yellow_concrete
fill 253 158 599 254 163 599 minecraft:orange_terracotta
fill 254 158 557 255 163 557 minecraft:orange_terracotta
fill 256 158 557 256 159 557 minecraft:yellow_concrete
fill 260 158 599 260 159 599 minecraft:yellow_concrete
fill 261 158 599 262 163 599 minecraft:orange_terracotta
fill 262 158 557 263 163 557 minecraft:orange_terracotta
setblock 263 158 599 minecraft:yellow_concrete
fill 264 158 557 265 158 557 minecraft:yellow_concrete
fill 265 158 599 265 163 599 minecraft:orange_terracotta
fill 271 158 599 272 159 599 minecraft:yellow_concrete
fill 273 158 599 274 163 599 minecraft:orange_terracotta
fill 274 158 557 275 163 557 minecraft:orange_terracotta
fill 276 158 557 277 159 557 minecraft:yellow_concrete
fill 277 158 563 277 163 563 minecraft:orange_terracotta
fill 277 158 564 277 158 565 minecraft:yellow_concrete
fill 277 158 566 277 163 566 minecraft:orange_terracotta
fill 277 158 568 277 159 568 minecraft:yellow_concrete
fill 277 158 574 277 163 575 minecraft:orange_terracotta
fill 277 158 576 277 159 577 minecraft:yellow_concrete
setblock 277 158 585 minecraft:yellow_concrete
fill 277 158 586 277 163 587 minecraft:orange_terracotta
fill 277 158 588 277 159 589 minecraft:yellow_concrete
fill 277 158 594 277 163 595 minecraft:orange_terracotta
fill 277 158 596 277 158 597 minecraft:yellow_concrete
fill 277 158 598 277 163 598 minecraft:orange_terracotta
fill 235 159 559 235 159 560 minecraft:yellow_concrete
setblock 235 159 563 minecraft:yellow_concrete
fill 235 159 564 235 162 564 minecraft:orange_terracotta
fill 235 159 575 235 162 575 minecraft:orange_terracotta
setblock 235 159 580 minecraft:yellow_concrete
setblock 235 159 591 minecraft:yellow_concrete
fill 235 159 595 235 162 596 minecraft:orange_terracotta
fill 236 159 572 239 161 574 minecraft:magma_block
setblock 237 159 557 minecraft:yellow_concrete
fill 240 159 573 242 160 573 minecraft:magma_block
setblock 248 159 599 minecraft:yellow_concrete
setblock 251 159 599 minecraft:yellow_concrete
fill 252 159 599 252 162 599 minecraft:orange_terracotta
fill 253 159 557 253 162 557 minecraft:orange_terracotta
setblock 257 159 557 minecraft:yellow_concrete
setblock 259 159 599 minecraft:yellow_concrete
fill 263 159 599 263 162 599 minecraft:orange_terracotta
fill 264 159 557 264 162 557 minecraft:orange_terracotta
setblock 265 159 557 minecraft:yellow_concrete
setblock 268 159 557 minecraft:yellow_concrete
fill 277 159 564 277 162 565 minecraft:orange_terracotta
setblock 277 159 569 minecraft:yellow_concrete
setblock 277 159 580 minecraft:yellow_concrete
fill 277 159 585 277 162 585 minecraft:orange_terracotta
fill 277 159 596 277 162 596 minecraft:orange_terracotta
setblock 277 159 597 minecraft:yellow_concrete
fill 235 160 558 235 161 558 minecraft:yellow_concrete
fill 235 160 559 235 161 560 minecraft:orange_terracotta
fill 235 160 561 235 160 562 minecraft:yellow_concrete
fill 235 160 563 235 165 563 minecraft:orange_terracotta
fill 235 160 569 235 161 570 minecraft:yellow_concrete
fill 235 160 571 235 165 572 minecraft:orange_terracotta
fill 235 160 580 235 165 580 minecraft:orange_terracotta
fill 235 160 581 235 160 582 minecraft:yellow_concrete
fill 235 160 583 235 165 584 minecraft:orange_terracotta
fill 235 160 589 235 161 590 minecraft:yellow_concrete
fill 235 160 591 235 165 592 minecraft:orange_terracotta
setblock 235 160 593 minecraft:yellow_concrete
fill 236 160 557 237 165 557 minecraft:orange_terracotta
fill 236 160 571 236 161 571 minecraft:magma_block
fill 236 160 575 236 161 575 minecraft:magma_block
fill 237 160 599 238 161 599 minecraft:yellow_concrete
fill 238 160 557 239 161 557 minecraft:yellow_concrete
fill 239 160 599 240 165 599 minecraft:orange_terracotta
setblock 240 160 572 minecraft:magma_block
setblock 240 160 574 minecraft:magma_block
fill 242 160 588 242 161 589 minecraft:yellow_concrete
fill 244 160 557 245 165 557 minecraft:orange_terracotta
fill 246 160 557 247 160 557 minecraft:yellow_concrete
fill 246 160 599 246 161 599 minecraft:yellow_concrete
fill 248 160 599 248 165 599 minecraft:orange_terracotta
fill 249 160 599 250 160 599 minecraft:yellow_concrete
fill 251 160 599 251 165 599 minecraft:orange_terracotta
fill 256 160 557 257 165 557 minecraft:orange_terracotta
fill 257 160 599 258 161 599 minecraft:yellow_concrete
fill 258 160 557 259 161 557 minecraft:yellow_concrete
fill 259 160 599 260 165 599 minecraft:orange_terracotta
fill 265 160 557 265 165 557 minecraft:orange_terracotta
fill 266 160 557 267 160 557 minecraft:yellow_concrete
fill 268 160 557 268 165 557 minecraft:orange_terracotta
fill 269 160 599 270 160 599 minecraft:yellow_concrete
fill 270 160 557 270 161 557 minecraft:yellow_concrete
fill 271 160 599 272 165 599 minecraft:orange_terracotta
fill 276 160 557 277 165 557 minecraft:orange_terracotta
fill 277 160 558 277 161 559 minecraft:yellow_concrete
setblock 277 160 567 minecraft:yellow_concrete
fill 277 160 568 277 165 569 minecraft:orange_terracotta
fill 277 160 570 277 161 571 minecraft:yellow_concrete
fill 277 160 576 277 165 577 minecraft:orange_terracotta
fill 277 160 578 277 160 579 minecraft:yellow_concrete
fill 277 160 580 277 165 580 minecraft:orange_terracotta
fill 277 160 588 277 165 589 minecraft:orange_terracotta
fill 277 160 590 277 161 591 minecraft:yellow_concrete
fill 277 160 597 277 165 597 minecraft:orange_terracotta
setblock 235 161 557 minecraft:yellow_concrete
fill 235 161 561 235 163 562 minecraft:orange_terracotta
fill 235 161 577 235 161 578 minecraft:yellow_concrete
setblock 235 161 581 minecraft:yellow_concrete
fill 235 161 582 235 164 582 minecraft:orange_terracotta
fill 235 161 593 235 164 593 minecraft:orange_terracotta
setblock 235 161 598 minecraft:yellow_concrete
setblock 240 161 573 minecraft:magma_block
setblock 245 161 599 minecraft:yellow_concrete
fill 246 161 557 246 164 557 minecraft:orange_terracotta
setblock 247 161 557 minecraft:yellow_concrete
fill 249 161 558 249 161 562 minecraft:magma_block
fill 249 161 599 250 164 599 minecraft:orange_terracotta
setblock 250 161 557 minecraft:yellow_concrete
fill 266 161 557 267 164 557 minecraft:orange_terracotta
setblock 266 161 599 minecraft:yellow_concrete
setblock 269 161 599 minecraft:yellow_concrete
fill 270 161 599 270 164 599 minecraft:orange_terracotta
setblock 271 161 557 minecraft:yellow_concrete
setblock 277 161 562 minecraft:yellow_concrete
fill 277 161 567 277 164 567 minecraft:orange_terracotta
fill 277 161 578 277 164 578 minecraft:orange_terracotta
setblock 277 161 579 minecraft:yellow_concrete
fill 277 161 582 277 161 583 minecraft:yellow_concrete
setblock 277 161 599 minecraft:yellow_concrete
fill 235 162 557 235 167 558 minecraft:orange_terracotta
setblock 235 162 559 minecraft:yellow_concrete
fill 235 162 560 235 165 560 minecraft:orange_terracotta
fill 235 162 567 235 162 568 minecraft:yellow_concrete
fill 235 162 569 235 167 570 minecraft:orange_terracotta
fill 235 162 576 235 163 576 minecraft:yellow_concrete
fill 235 162 577 235 167 578 minecraft:orange_terracotta
setblock 235 162 579 minecraft:yellow_concrete
fill 235 162 581 235 167 581 minecraft:orange_terracotta
fill 235 162 587 235 163 588 minecraft:yellow_concrete
fill 235 162 589 235 167 590 minecraft:orange_terracotta
fill 235 162 598 235 167 598 minecraft:orange_terracotta
fill 235 162 599 236 162 599 minecraft:yellow_concrete
fill 236 162 558 238 162 558 minecraft:orange_concrete
fill 236 162 560 236 162 562 minecraft:orange_concrete
fill 236 162 564 236 162 566 minecraft:orange_concrete
fill 236 162 568 236 162 570 minecraft:orange_concrete
fill 236 162 572 236 162 574 minecraft:orange_concrete
fill 236 162 576 236 162 578 minecraft:orange_concrete
fill 236 162 580 236 162 582 minecraft:orange_concrete
fill 236 162 584 236 162 586 minecraft:orange_concrete
fill 236 162 588 236 162 590 minecraft:orange_concrete
fill 236 162 592 236 162 594 minecraft:orange_concrete
fill 236 162 596 236 162 598 minecraft:orange_concrete
fill 237 162 572 237 162 574 minecraft:magma_block
fill 237 162 577 241 162 577 minecraft:magma_block
fill 237 162 599 238 167 599 minecraft:orange_terracotta
fill 238 162 557 239 167 557 minecraft:orange_terracotta
setblock 238 162 560 minecraft:light[level=14]
setblock 238 162 568 minecraft:light[level=14]
setblock 238 162 576 minecraft:light[level=14]
setblock 238 162 584 minecraft:light[level=14]
setblock 238 162 592 minecraft:light[level=14]
fill 238 162 598 240 162 598 minecraft:orange_concrete
fill 240 162 557 241 163 557 minecraft:yellow_concrete
fill 240 162 558 242 162 558 minecraft:orange_concrete
fill 242 162 598 244 162 598 minecraft:orange_concrete
fill 243 162 599 244 163 599 minecraft:yellow_concrete
fill 244 162 558 246 162 558 minecraft:orange_concrete
fill 245 162 599 246 167 599 minecraft:orange_terracotta
setblock 246 162 560 minecraft:light[level=14]
setblock 246 162 568 minecraft:light[level=14]
setblock 246 162 576 minecraft:light[level=14]
setblock 246 162 584 minecraft:light[level=14]
setblock 246 162 592 minecraft:light[level=14]
fill 246 162 598 248 162 598 minecraft:orange_concrete
fill 247 162 557 247 167 557 minecraft:orange_terracotta
setblock 247 162 599 minecraft:yellow_concrete
fill 248 162 557 249 162 557 minecraft:yellow_concrete
fill 248 162 558 250 162 558 minecraft:orange_concrete
fill 248 162 559 250 162 560 minecraft:magma_block
setblock 249 162 561 minecraft:magma_block
fill 250 162 557 250 167 557 minecraft:orange_terracotta
fill 250 162 598 252 162 598 minecraft:orange_concrete
fill 252 162 557 252 163 557 minecraft:yellow_concrete
fill 252 162 558 254 162 558 minecraft:orange_concrete
setblock 254 162 560 minecraft:light[level=14]
setblock 254 162 568 minecraft:light[level=14]
setblock 254 162 576 minecraft:light[level=14]
setblock 254 162 584 minecraft:light[level=14]
setblock 254 162 592 minecraft:light[level=14]
fill 254 162 598 256 162 598 minecraft:orange_concrete
fill 255 162 599 256 163 599 minecraft:yellow_concrete
fill 256 162 558 258 162 558 minecraft:orange_concrete
fill 257 162 599 258 167 599 minecraft:orange_terracotta
fill 258 162 557 259 167 557 minecraft:orange_terracotta
fill 258 162 598 260 162 598 minecraft:orange_concrete
fill 260 162 557 261 163 557 minecraft:yellow_concrete
fill 260 162 558 262 162 558 minecraft:orange_concrete
setblock 262 162 560 minecraft:light[level=14]
setblock 262 162 568 minecraft:light[level=14]
setblock 262 162 576 minecraft:light[level=14]
setblock 262 162 584 minecraft:light[level=14]
setblock 262 162 592 minecraft:light[level=14]
fill 262 162 598 264 162 598 minecraft:orange_concrete
fill 264 162 558 266 162 558 minecraft:orange_concrete
fill 264 162 599 264 163 599 minecraft:yellow_concrete
fill 266 162 598 268 162 598 minecraft:orange_concrete
fill 266 162 599 266 167 599 minecraft:orange_terracotta
fill 267 162 599 268 162 599 minecraft:yellow_concrete
fill 268 162 558 270 162 558 minecraft:orange_concrete
setblock 269 162 557 minecraft:yellow_concrete
fill 269 162 599 269 167 599 minecraft:orange_terracotta
fill 270 162 557 271 167 557 minecraft:orange_terracotta
setblock 270 162 560 minecraft:light[level=14]
setblock 270 162 568 minecraft:light[level=14]
setblock 270 162 576 minecraft:light[level=14]
setblock 270 162 584 minecraft:light[level=14]
setblock 270 162 592 minecraft:light[level=14]
fill 270 162 598 272 162 598 minecraft:orange_concrete
fill 272 162 557 273 163 557 minecraft:yellow_concrete
fill 272 162 558 274 162 558 minecraft:orange_concrete
fill 274 162 598 276 162 598 minecraft:orange_concrete
fill 275 162 599 276 163 599 minecraft:yellow_concrete
fill 276 162 558 276 162 560 minecraft:orange_concrete
fill 276 162 562 276 162 564 minecraft:orange_concrete
fill 276 162 566 276 162 568 minecraft:orange_concrete
fill 276 162 570 276 162 572 minecraft:orange_concrete
fill 276 162 574 276 162 576 minecraft:orange_concrete
fill 276 162 578 276 162 580 minecraft:orange_concrete
fill 276 162 582 276 162 584 minecraft:orange_concrete
fill 276 162 586 276 162 588 minecraft:orange_concrete
fill 276 162 590 276 162 592 minecraft:orange_concrete
fill 276 162 594 276 162 596 minecraft:orange_concrete
fill 277 162 558 277 167 559 minecraft:orange_terracotta
fill 277 162 560 277 162 561 minecraft:yellow_concrete
fill 277 162 562 277 167 562 minecraft:orange_terracotta
fill 277 162 570 277 167 571 minecraft:orange_terracotta
fill 277 162 572 277 163 573 minecraft:yellow_concrete
fill 277 162 579 277 167 579 minecraft:orange_terracotta
setblock 277 162 581 minecraft:yellow_concrete
fill 277 162 582 277 167 583 minecraft:orange_terracotta
fill 277 162 584 277 163 584 minecraft:yellow_concrete
fill 277 162 590 277 167 591 minecraft:orange_terracotta
fill 277 162 592 277 162 593 minecraft:yellow_concrete
fill 277 162 599 277 167 599 minecraft:orange_terracotta
fill 235 163 559 235 165 559 minecraft:orange_terracotta
setblock 235 163 564 minecraft:yellow_concrete
setblock 235 163 567 minecraft:yellow_concrete
fill 235 163 568 235 166 568 minecraft:orange_terracotta
setblock 235 163 575 minecraft:yellow_concrete
fill 235 163 579 235 166 579 minecraft:orange_terracotta
fill 235 163 595 235 163 596 minecraft:yellow_concrete
setblock 235 163 599 minecraft:yellow_concrete
fill 236 163 576 238 163 578 minecraft:magma_block
fill 236 163 599 236 166 599 minecraft:orange_terracotta
fill 239 163 577 240 163 577 minecraft:magma_block
fill 245 163 566 245 164 566 minecraft:red_concrete
fill 247 163 599 247 166 599 minecraft:orange_terracotta
fill 248 163 557 249 165 557 minecraft:orange_terracotta
fill 248 163 558 250 163 559 minecraft:magma_block
setblock 249 163 560 minecraft:magma_block
setblock 252 163 599 minecraft:yellow_concrete
setblock 253 163 557 minecraft:yellow_concrete
setblock 263 163 599 minecraft:yellow_concrete
setblock 264 163 557 minecraft:yellow_concrete
fill 267 163 599 268 166 599 minecraft:orange_terracotta
fill 269 163 557 269 166 557 minecraft:orange_terracotta
fill 277 163 560 277 166 560 minecraft:orange_terracotta
setblock 277 163 561 minecraft:yellow_concrete
fill 277 163 564 277 163 565 minecraft:yellow_concrete
fill 277 163 581 277 166 581 minecraft:orange_terracotta
setblock 277 163 585 minecraft:yellow_concrete
fill 277 163 592 277 166 592 minecraft:orange_terracotta
setblock 277 163 593 minecraft:yellow_concrete
setblock 277 163 596 minecraft:yellow_concrete
setblock 235 164 561 minecraft:orange_terracotta
fill 235 164 562 235 165 562 minecraft:yellow_concrete
fill 235 164 564 235 169 564 minecraft:orange_terracotta
fill 235 164 565 235 164 566 minecraft:yellow_concrete
fill 235 164 567 235 169 567 minecraft:orange_terracotta
fill 235 164 573 235 165 574 minecraft:yellow_concrete
fill 235 164 575 235 169 576 minecraft:orange_terracotta
fill 235 164 585 235 164 586 minecraft:yellow_concrete
fill 235 164 587 235 169 588 minecraft:orange_terracotta
fill 235 164 594 235 165 594 minecraft:yellow_concrete
fill 235 164 595 235 169 596 minecraft:orange_terracotta
setblock 235 164 597 minecraft:yellow_concrete
fill 235 164 599 235 169 599 minecraft:orange_terracotta
fill 236 164 576 237 164 578 minecraft:magma_block
setblock 238 164 577 minecraft:magma_block
fill 240 164 557 241 169 557 minecraft:orange_terracotta
fill 241 164 599 242 165 599 minecraft:yellow_concrete
fill 242 164 557 243 165 557 minecraft:yellow_concrete
fill 243 164 599 244 169 599 minecraft:orange_terracotta
setblock 249 164 558 minecraft:magma_block
fill 250 164 584 250 165 584 minecraft:red_concrete
setblock 251 164 557 minecraft:yellow_concrete
fill 252 164 557 253 169 557 minecraft:orange_terracotta
fill 252 164 599 252 169 599 minecraft:orange_terracotta
fill 253 164 599 254 164 599 minecraft:yellow_concrete
fill 254 164 557 255 165 557 minecraft:yellow_concrete
fill 255 164 599 256 169 599 minecraft:orange_terracotta
fill 260 164 557 261 169 557 minecraft:orange_terracotta
fill 261 164 599 262 165 599 minecraft:yellow_concrete
fill 262 164 557 263 164 557 minecraft:yellow_concrete
fill 263 164 599 264 169 599 minecraft:orange_terracotta
fill 264 164 557 264 169 557 minecraft:orange_terracotta
setblock 265 164 599 minecraft:yellow_concrete
fill 272 164 557 273 169 557 minecraft:orange_terracotta
fill 273 164 599 274 165 599 minecraft:yellow_concrete
fill 274 164 557 275 165 557 minecraft:yellow_concrete
fill 275 164 599 276 169 599 minecraft:orange_terracotta
fill 277 164 561 277 169 561 minecraft:orange_terracotta
setblock 277 164 563 minecraft:yellow_concrete
fill 277 164 564 277 169 565 minecraft:orange_terracotta
fill 277 164 566 277 165 566 minecraft:yellow_concrete
fill 277 164 572 277 169 573 minecraft:orange_terracotta
fill 277 164 574 277 164 575 minecraft:yellow_concrete
fill 277 164 584 277 169 585 minecraft:orange_terracotta
fill 277 164 586 277 165 587 minecraft:yellow_concrete
fill 277 164 593 277 169 593 minecraft:orange_terracotta
fill 277 164 594 277 164 595 minecraft:yellow_concrete
fill 277 164 596 277 169 596 minecraft:orange_terracotta
fill 277 164 598 277 165 598 minecraft:yellow_concrete
setblock 235 165 561 minecraft:yellow_concrete
fill 235 165 565 235 168 566 minecraft:orange_terracotta
setblock 235 165 582 minecraft:yellow_concrete
setblock 235 165 585 minecraft:yellow_concrete
fill 235 165 586 235 168 586 minecraft:orange_terracotta
setblock 235 165 593 minecraft:yellow_concrete
fill 235 165 597 235 168 597 minecraft:orange_terracotta
setblock 236 165 577 minecraft:magma_block
setblock 246 165 557 minecraft:yellow_concrete
fill 249 165 599 250 165 599 minecraft:yellow_concrete
fill 251 165 557 251 167 557 minecraft:orange_terracotta
setblock 253 165 599 minecraft:yellow_concrete
fill 254 165 599 254 168 599 minecraft:orange_terracotta
fill 259 165 588 259 166 589 minecraft:shroomlight
fill 262 165 557 262 168 557 minecraft:orange_terracotta
setblock 263 165 557 minecraft:yellow_concrete
fill 265 165 599 265 168 599 minecraft:orange_terracotta
fill 266 165 557 267 165 557 minecraft:yellow_concrete
setblock 270 165 599 minecraft:yellow_concrete
fill 277 165 563 277 168 563 minecraft:orange_terracotta
setblock 277 165 567 minecraft:yellow_concrete
fill 277 165 574 277 168 574 minecraft:orange_terracotta
setblock 277 165 575 minecraft:yellow_concrete
setblock 277 165 578 minecraft:yellow_concrete
fill 277 165 594 277 168 595 minecraft:orange_terracotta
fill 235 166 559 235 167 560 minecraft:yellow_concrete
fill 235 166 561 235 171 562 minecraft:orange_terracotta
setblock 235 166 563 minecraft:yellow_concrete
fill 235 166 571 235 167 572 minecraft:yellow_concrete
fill 235 166 573 235 171 574 minecraft:orange_terracotta
fill 235 166 580 235 167 580 minecraft:yellow_concrete
fill 235 166 582 235 171 582 minecraft:orange_terracotta
fill 235 166 583 235 166 584 minecraft:yellow_concrete
fill 235 166 585 235 171 585 minecraft:orange_terracotta
fill 235 166 591 235 167 592 minecraft:yellow_concrete
fill 235 166 593 235 171 594 minecraft:orange_terracotta
fill 236 166 557 237 167 557 minecraft:yellow_concrete
fill 239 166 599 240 166 599 minecraft:yellow_concrete
fill 241 166 599 242 171 599 minecraft:orange_terracotta
fill 242 166 557 243 168 557 minecraft:orange_terracotta
fill 244 166 557 245 166 557 minecraft:yellow_concrete
fill 246 166 557 246 171 557 minecraft:orange_terracotta
fill 248 166 557 248 167 557 minecraft:yellow_concrete
fill 248 166 599 248 167 599 minecraft:yellow_concrete
setblock 249 166 557 minecraft:orange_terracotta
fill 249 166 599 250 171 599 minecraft:orange_terracotta
setblock 251 166 599 minecraft:yellow_concrete
fill 253 166 599 253 171 599 minecraft:orange_terracotta
fill 254 166 557 255 171 557 minecraft:orange_terracotta
fill 256 166 557 257 167 557 minecraft:yellow_concrete
fill 259 166 599 260 167 599 minecraft:yellow_concrete
fill 261 166 599 262 171 599 minecraft:orange_terracotta
fill 263 166 557 263 171 557 minecraft:orange_terracotta
setblock 265 166 557 minecraft:yellow_concrete
fill 266 166 557 267 171 557 minecraft:orange_terracotta
fill 268 166 557 268 167 557 minecraft:yellow_concrete
fill 270 166 599 270 171 599 minecraft:orange_terracotta
fill 271 166 599 272 166 599 minecraft:yellow_concrete
fill 273 166 599 274 171 599 minecraft:orange_terracotta
fill 274 166 557 275 171 557 minecraft:orange_terracotta
fill 276 166 557 277 166 557 minecraft:yellow_concrete
fill 277 166 566 277 171 567 minecraft:orange_terracotta
fill 277 166 568 277 167 569 minecraft:yellow_concrete
fill 277 166 575 277 171 575 minecraft:orange_terracotta
fill 277 166 576 277 166 577 minecraft:yellow_concrete
fill 277 166 578 277 171 578 minecraft:orange_terracotta
fill 277 166 580 277 167 580 minecraft:yellow_concrete
fill 277 166 586 277 171 587 minecraft:orange_terracotta
fill 277 166 588 277 167 589 minecraft:yellow_concrete
setblock 277 166 597 minecraft:yellow_concrete
fill 277 166 598 277 171 598 minecraft:orange_terracotta
fill 235 167 563 235 170 563 minecraft:orange_terracotta
setblock 235 167 568 minecraft:yellow_concrete
setblock 235 167 579 minecraft:yellow_concrete
fill 235 167 583 235 170 584 minecraft:orange_terracotta
setblock 236 167 599 minecraft:yellow_concrete
setblock 239 167 599 minecraft:yellow_concrete
fill 240 167 599 240 170 599 minecraft:orange_terracotta
fill 244 167 557 244 170 557 minecraft:orange_terracotta
setblock 245 167 557 minecraft:yellow_concrete
setblock 247 167 599 minecraft:yellow_concrete
setblock 249 167 557 minecraft:yellow_concrete
fill 251 167 599 251 170 599 minecraft:orange_terracotta
fill 265 167 557 265 170 557 minecraft:orange_terracotta
fill 267 167 599 268 167 599 minecraft:yellow_concrete
setblock 269 167 557 minecraft:yellow_concrete
setblock 271 167 599 minecraft:yellow_concrete
fill 272 167 599 272 170 599 minecraft:orange_terracotta
fill 276 167 557 276 170 557 minecraft:orange_terracotta
setblock 277 167 557 minecraft:yellow_concrete
setblock 277 167 560 minecraft:yellow_concrete
fill 277 167 576 277 170 577 minecraft:orange_terracotta
setblock 277 167 581 minecraft:yellow_concrete
setblock 277 167 592 minecraft:yellow_concrete
fill 277 167 597 277 170 597 minecraft:orange_terracotta
fill 235 168 557 235 169 558 minecraft:yellow_concrete
fill 235 168 559 235 173 560 minecraft:orange_terracotta
fill 235 168 568 235 173 568 minecraft:orange_terracotta
fill 235 168 569 235 168 570 minecraft:yellow_concrete
fill 235 168 571 235 173 572 minecraft:orange_terracotta
fill 235 168 577 235 169 578 minecraft:yellow_concrete
fill 235 168 579 235 173 580 minecraft:orange_terracotta
setblock 235 168 581 minecraft:yellow_concrete
fill 235 168 589 235 169 590 minecraft:yellow_concrete
fill 235 168 591 235 173 592 minecraft:orange_terracotta
fill 235 168 598 235 169 598 minecraft:yellow_concrete
fill 236 168 557 237 173 557 minecraft:orange_terracotta
fill 236 168 558 238 168 558 minecraft:orange_concrete
fill 236 168 560 236 168 562 minecraft:orange_concrete
fill 236 168 564 236 168 566 minecraft:orange_concrete
fill 236 168 568 236 168 570 minecraft:orange_concrete
fill 236 168 572 236 168 574 minecraft:orange_concrete
fill 236 168 576 236 168 578 minecraft:orange_concrete
fill 236 168 580 236 168 582 minecraft:orange_concrete
fill 236 168 584 236 168 586 minecraft:orange_concrete
fill 236 168 588 236 168 590 minecraft:orange_concrete
fill 236 168 592 236 168 594 minecraft:orange_concrete
fill 236 168 596 236 168 598 minecraft:orange_concrete
fill 236 168 599 236 173 599 minecraft:orange_terracotta
fill 237 168 599 238 168 599 minecraft:yellow_concrete
fill 238 168 557 239 169 557 minecraft:yellow_concrete
fill 238 168 598 240 168 598 minecraft:orange_concrete
fill 239 168 599 239 173 599 minecraft:orange_terracotta
fill 240 168 558 242 168 558 minecraft:orange_concrete
fill 242 168 598 244 168 598 minecraft:orange_concrete
fill 244 168 558 246 168 558 minecraft:orange_concrete
fill 245 168 557 245 170 557 minecraft:orange_terracotta
fill 245 168 599 246 169 599 minecraft:yellow_concrete
fill 246 168 598 248 168 598 minecraft:orange_concrete
setblock 247 168 557 minecraft:yellow_concrete
fill 247 168 599 248 173 599 minecraft:orange_terracotta
fill 248 168 557 249 173 557 minecraft:orange_terracotta
fill 248 168 558 250 168 558 minecraft:orange_concrete
fill 250 168 557 251 169 557 minecraft:yellow_concrete
fill 250 168 598 252 168 598 minecraft:orange_concrete
fill 252 168 558 254 168 558 minecraft:orange_concrete
fill 254 168 598 256 168 598 minecraft:orange_concrete
fill 256 168 557 257 173 557 minecraft:orange_terracotta
fill 256 168 558 258 168 558 minecraft:orange_concrete
fill 257 168 599 258 168 599 minecraft:yellow_concrete
fill 258 168 557 259 168 557 minecraft:yellow_concrete
fill 258 168 598 260 168 598 minecraft:orange_concrete
fill 259 168 599 260 173 599 minecraft:orange_terracotta
fill 260 168 558 262 168 558 minecraft:orange_concrete
fill 262 168 598 264 168 598 minecraft:orange_concrete
fill 264 168 558 266 168 558 minecraft:orange_concrete
fill 266 168 598 268 168 598 minecraft:orange_concrete
fill 266 168 599 266 169 599 minecraft:yellow_concrete
fill 267 168 599 268 173 599 minecraft:orange_terracotta
fill 268 168 557 269 173 557 minecraft:orange_terracotta
fill 268 168 558 270 168 558 minecraft:orange_concrete
setblock 269 168 599 minecraft:yellow_concrete
fill 270 168 557 271 169 557 minecraft:yellow_concrete
fill 270 168 598 272 168 598 minecraft:orange_concrete
fill 271 168 599 271 173 599 minecraft:orange_terracotta
fill 272 168 558 274 168 558 minecraft:orange_concrete
fill 274 168 598 276 168 598 minecraft:orange_concrete
fill 276 168 558 276 168 560 minecraft:orange_concrete
fill 276 168 562 276 168 564 minecraft:orange_concrete
fill 276 168 566 276 168 568 minecraft:orange_concrete
fill 276 168 570 276 168 572 minecraft:orange_concrete
fill 276 168 574 276 168 576 minecraft:orange_concrete
fill 276 168 578 276 168 580 minecraft:orange_concrete
fill 276 168 582 276 168 584 minecraft:orange_concrete
fill 276 168 586 276 168 588 minecraft:orange_concrete
fill 276 168 590 276 168 592 minecraft:orange_concrete
fill 276 168 594 276 168 596 minecraft:orange_concrete
fill 277 168 557 277 173 557 minecraft:orange_terracotta
fill 277 168 558 277 168 559 minecraft:yellow_concrete
fill 277 168 560 277 173 560 minecraft:orange_terracotta
fill 277 168 562 277 169 562 minecraft:yellow_concrete
fill 277 168 568 277 173 569 minecraft:orange_terracotta
fill 277 168 570 277 169 571 minecraft:yellow_concrete
setblock 277 168 579 minecraft:yellow_concrete
fill 277 168 580 277 173 581 minecraft:orange_terracotta
fill 277 168 582 277 169 583 minecraft:yellow_concrete
fill 277 168 588 277 173 589 minecraft:orange_terracotta
fill 277 168 590 277 168 591 minecraft:yellow_concrete
fill 277 168 592 277 173 592 minecraft:orange_terracotta
fill 277 168 599 277 169 599 minecraft:yellow_concrete
fill 235 169 565 235 169 566 minecraft:yellow_concrete
setblock 235 169 569 minecraft:yellow_concrete
fill 235 169 570 235 172 570 minecraft:orange_terracotta
fill 235 169 581 235 172 581 minecraft:orange_terracotta
setblock 235 169 586 minecraft:yellow_concrete
setblock 235 169 597 minecraft:yellow_concrete
fill 237 169 599 238 172 599 minecraft:orange_terracotta
setblock 242 169 557 minecraft:yellow_concrete
fill 243 169 557 243 171 557 minecraft:orange_terracotta
fill 247 169 557 247 172 557 minecraft:orange_terracotta
setblock 254 169 599 minecraft:yellow_concrete
setblock 257 169 599 minecraft:yellow_concrete
fill 258 169 557 258 172 557 minecraft:orange_terracotta
fill 258 169 599 258 172 599 minecraft:orange_terracotta
setblock 259 169 557 minecraft:yellow_concrete
setblock 262 169 557 minecraft:yellow_concrete
setblock 265 169 599 minecraft:yellow_concrete
fill 269 169 599 269 172 599 minecraft:orange_terracotta
fill 277 169 558 277 172 559 minecraft:orange_terracotta
setblock 277 169 563 minecraft:yellow_concrete
setblock 277 169 574 minecraft:yellow_concrete
fill 277 169 579 277 172 579 minecraft:orange_terracotta
fill 277 169 590 277 172 590 minecraft:orange_terracotta
setblock 277 169 591 minecraft:yellow_concrete
fill 277 169 594 277 169 595 minecraft:yellow_concrete
fill 235 170 557 235 175 558 minecraft:orange_terracotta
fill 235 170 564 235 171 564 minecraft:yellow_concrete
fill 235 170 565 235 175 566 minecraft:orange_terracotta
setblock 235 170 567 minecraft:yellow_concrete
fill 235 170 569 235 175 569 minecraft:orange_terracotta
fill 235 170 575 235 171 576 minecraft:yellow_concrete
fill 235 170 577 235 175 578 minecraft:orange_terracotta
fill 235 170 586 235 175 586 minecraft:orange_terracotta
fill 235 170 587 235 170 588 minecraft:yellow_concrete
fill 235 170 589 235 175 590 minecraft:orange_terracotta
fill 235 170 595 235 171 596 minecraft:yellow_concrete
fill 235 170 597 235 175 598 minecraft:orange_terracotta
setblock 235 170 599 minecraft:yellow_concrete
fill 238 170 557 239 175 557 minecraft:orange_terracotta
setblock 238 170 560 minecraft:light[level=14]
setblock 238 170 568 minecraft:light[level=14]
setblock 238 170 576 minecraft:light[level=14]
setblock 238 170 584 minecraft:light[level=14]
setblock 238 170 592 minecraft:light[level=14]
fill 240 170 557 241 170 557 minecraft:yellow_concrete
fill 242 170 557 242 171 557 minecraft:orange_terracotta
fill 243 170 599 244 171 599 minecraft:yellow_concrete
fill 245 170 599 246 175 599 minecraft:orange_terracotta
setblock 246 170 560 minecraft:light[level=14]
setblock 246 170 568 minecraft:light[level=14]
setblock 246 170 576 minecraft:light[level=14]
setblock 246 170 584 minecraft:light[level=14]
setblock 246 170 592 minecraft:light[level=14]
fill 250 170 557 251 175 557 minecraft:orange_terracotta
fill 251 170 593 252 171 593 minecraft:red_concrete
fill 252 170 557 253 171 557 minecraft:yellow_concrete
fill 252 170 599 252 171 599 minecraft:yellow_concrete
setblock 254 170 560 minecraft:light[level=14]
setblock 254 170 568 minecraft:light[level=14]
setblock 254 170 576 minecraft:light[level=14]
setblock 254 170 584 minecraft:light[level=14]
setblock 254 170 592 minecraft:light[level=14]
fill 254 170 599 254 175 599 minecraft:orange_terracotta
fill 255 170 599 256 170 599 minecraft:yellow_concrete
fill 257 170 599 257 175 599 minecraft:orange_terracotta
fill 259 170 557 259 175 557 minecraft:orange_terracotta
fill 260 170 557 261 170 557 minecraft:yellow_concrete
fill 262 170 557 262 175 557 minecraft:orange_terracotta
setblock 262 170 560 minecraft:light[level=14]
setblock 262 170 568 minecraft:light[level=14]
setblock 262 170 576 minecraft:light[level=14]
setblock 262 170 584 minecraft:light[level=14]
setblock 262 170 592 minecraft:light[level=14]
fill 263 170 599 264 171 599 minecraft:yellow_concrete
fill 264 170 557 264 171 557 minecraft:yellow_concrete
fill 265 170 599 266 175 599 minecraft:orange_terracotta
fill 270 170 557 271 175 557 minecraft:orange_terracotta
setblock 270 170 560 minecraft:light[level=14]
setblock 270 170 568 minecraft:light[level=14]
setblock 270 170 576 minecraft:light[level=14]
fill 270 170 583 271 171 584 minecraft:red_concrete
setblock 270 170 592 minecraft:light[level=14]
fill 272 170 557 273 171 557 minecraft:yellow_concrete
fill 275 170 599 276 170 599 minecraft:yellow_concrete
setblock 277 170 561 minecraft:yellow_concrete
fill 277 170 562 277 175 563 minecraft:orange_terracotta
fill 277 170 564 277 171 565 minecraft:yellow_concrete
fill 277 170 570 277 175 571 minecraft:orange_terracotta
fill 277 170 572 277 170 573 minecraft:yellow_concrete
fill 277 170 574 277 175 574 minecraft:orange_terracotta
fill 277 170 582 277 175 583 minecraft:orange_terracotta
fill 277 170 584 277 171 585 minecraft:yellow_concrete
fill 277 170 591 277 175 591 minecraft:orange_terracotta
setblock 277 170 593 minecraft:yellow_concrete
fill 277 170 594 277 175 595 minecraft:orange_terracotta
fill 277 170 596 277 171 596 minecraft:yellow_concrete
fill 277 170 599 277 175 599 minecraft:orange_terracotta
setblock 235 171 563 minecraft:yellow_concrete
fill 235 171 567 235 174 567 minecraft:orange_terracotta
fill 235 171 583 235 171 584 minecraft:yellow_concrete
setblock 235 171 587 minecraft:yellow_concrete
fill 235 171 588 235 174 588 minecraft:orange_terracotta
fill 235 171 599 235 174 599 minecraft:orange_terracotta
fill 240 171 557 240 174 557 minecraft:orange_terracotta
setblock 240 171 599 minecraft:yellow_concrete
setblock 241 171 557 minecraft:yellow_concrete
fill 244 171 557 245 171 557 minecraft:yellow_concrete
setblock 251 171 599 minecraft:yellow_concrete
fill 255 171 599 256 174 599 minecraft:orange_terracotta
fill 260 171 557 261 173 557 minecraft:orange_terracotta
setblock 265 171 557 minecraft:yellow_concrete
setblock 272 171 599 minecraft:yellow_concrete
setblock 275 171 599 minecraft:yellow_concrete
setblock 276 171 557 minecraft:yellow_concrete
fill 276 171 599 276 174 599 minecraft:orange_terracotta
fill 277 171 561 277 174 561 minecraft:orange_terracotta
fill 277 171 572 277 174 572 minecraft:orange_terracotta
setblock 277 171 573 minecraft:yellow_concrete
fill 277 171 576 277 171 577 minecraft:yellow_concrete
fill 277 171 593 277 174 593 minecraft:orange_terracotta
setblock 277 171 597 minecraft:yellow_concrete
fill 235 172 561 235 173 562 minecraft:yellow_concrete
fill 235 172 563 235 177 564 minecraft:orange_terracotta
fill 235 172 573 235 172 574 minecraft:yellow_concrete
fill 235 172 575 235 177 576 minecraft:orange_terracotta
fill 235 172 582 235 173 582 minecraft:yellow_concrete
fill 235 172 583 235 177 584 minecraft:orange_terracotta
setblock 235 172 585 minecraft:yellow_concrete
fill 235 172 587 235 177 587 minecraft:orange_terracotta
fill 235 172 593 235 173 594 minecraft:yellow_concrete
fill 235 172 595 235 177 596 minecraft:orange_terracotta
fill 240 172 599 240 177 599 minecraft:orange_terracotta
fill 241 172 557 241 177 557 minecraft:orange_terracotta
fill 241 172 599 242 172 599 minecraft:yellow_concrete
fill 242 172 557 243 172 557 minecraft:yellow_concrete
fill 243 172 599 244 177 599 minecraft:orange_terracotta
fill 244 172 557 245 173 557 minecraft:orange_terracotta
fill 246 172 557 246 173 557 minecraft:yellow_concrete
fill 249 172 599 250 173 599 minecraft:yellow_concrete
fill 251 172 599 252 177 599 minecraft:orange_terracotta
fill 252 172 557 253 177 557 minecraft:orange_terracotta
setblock 253 172 599 minecraft:yellow_concrete
fill 254 172 557 255 173 557 minecraft:yellow_concrete
fill 261 172 599 262 173 599 minecraft:yellow_concrete
setblock 263 172 557 minecraft:yellow_concrete
fill 263 172 599 264 177 599 minecraft:orange_terracotta
fill 264 172 557 265 177 557 minecraft:orange_terracotta
fill 266 172 557 267 173 557 minecraft:yellow_concrete
fill 270 172 599 270 173 599 minecraft:yellow_concrete
fill 272 172 557 273 177 557 minecraft:orange_terracotta
fill 272 172 599 272 177 599 minecraft:orange_terracotta
fill 273 172 599 274 172 599 minecraft:yellow_concrete
fill 274 172 557 275 172 557 minecraft:yellow_concrete
fill 275 172 599 275 177 599 minecraft:orange_terracotta
fill 276 172 557 276 177 557 minecraft:orange_terracotta
fill 277 172 564 277 177 565 minecraft:orange_terracotta
fill 277 172 566 277 173 567 minecraft:yellow_concrete
fill 277 172 573 277 177 573 minecraft:orange_terracotta
setblock 277 172 575 minecraft:yellow_concrete
fill 277 172 576 277 177 577 minecraft:orange_terracotta
fill 277 172 578 277 173 578 minecraft:yellow_concrete
fill 277 172 584 277 177 585 minecraft:orange_terracotta
fill 277 172 586 277 172 587 minecraft:yellow_concrete
fill 277 172 596 277 177 597 minecraft:orange_terracotta
fill 277 172 598 277 173 598 minecraft:yellow_concrete
setblock 235 173 570 minecraft:yellow_concrete
setblock 235 173 573 minecraft:yellow_concrete
fill 235 173 574 235 176 574 minecraft:orange_terracotta
setblock 235 173 581 minecraft:yellow_concrete
fill 235 173 585 235 176 585 minecraft:orange_terracotta
fill 237 173 599 238 173 599 minecraft:yellow_concrete
setblock 241 173 599 minecraft:yellow_concrete
fill 242 173 557 243 175 557 minecraft:orange_terracotta
fill 242 173 599 242 176 599 minecraft:orange_terracotta
setblock 247 173 557 minecraft:yellow_concrete
fill 253 173 599 253 176 599 minecraft:orange_terracotta
setblock 258 173 557 minecraft:yellow_concrete
setblock 258 173 599 minecraft:yellow_concrete
fill 263 173 557 263 175 557 minecraft:orange_terracotta
setblock 269 173 599 minecraft:yellow_concrete
fill 273 173 599 274 176 599 minecraft:orange_terracotta
fill 274 173 557 274 176 557 minecraft:orange_terracotta
setblock 275 173 557 minecraft:yellow_concrete
fill 277 173 558 277 173 559 minecraft:yellow_concrete
fill 277 173 575 277 176 575 minecraft:orange_terracotta
setblock 277 173 579 minecraft:yellow_concrete
fill 277 173 586 277 176 586 minecraft:orange_terracotta
setblock 277 173 587 minecraft:yellow_concrete
setblock 277 173 590 minecraft:yellow_concrete
fill 235 174 559 235 175 560 minecraft:yellow_concrete
fill 235 174 561 235 191 562 minecraft:orange_terracotta
fill 235 174 568 235 175 568 minecraft:yellow_concrete
fill 235 174 570 235 195 570 minecraft:orange_terracotta
fill 235 174 571 235 174 572 minecraft:yellow_concrete
fill 235 174 573 235 191 573 minecraft:orange_terracotta
fill 235 174 579 235 175 580 minecraft:yellow_concrete
fill 235 174 581 235 192 582 minecraft:orange_terracotta
fill 235 174 591 235 174 592 minecraft:yellow_concrete
fill 235 174 593 235 191 594 minecraft:orange_terracotta
fill 236 174 557 237 175 557 minecraft:yellow_concrete
fill 236 174 558 238 174 558 minecraft:orange_concrete
fill 236 174 560 236 174 562 minecraft:orange_concrete
fill 236 174 564 236 174 566 minecraft:orange_concrete
fill 236 174 568 236 174 570 minecraft:orange_concrete
fill 236 174 572 236 174 574 minecraft:orange_concrete
fill 236 174 576 236 174 578 minecraft:orange_concrete
fill 236 174 580 236 174 582 minecraft:orange_concrete
fill 236 174 584 236 174 586 minecraft:orange_concrete
fill 236 174 588 236 174 590 minecraft:orange_concrete
fill 236 174 592 236 174 594 minecraft:orange_concrete
fill 236 174 596 236 174 598 minecraft:orange_concrete
fill 236 174 599 236 175 599 minecraft:yellow_concrete
fill 237 174 599 238 195 599 minecraft:orange_terracotta
fill 238 174 598 240 174 598 minecraft:orange_concrete
setblock 239 174 599 minecraft:yellow_concrete
fill 240 174 558 242 174 558 minecraft:orange_concrete
fill 241 174 599 241 191 599 minecraft:orange_terracotta
fill 242 174 598 244 174 598 minecraft:orange_concrete
fill 244 174 557 244 177 557 minecraft:orange_terracotta
fill 244 174 558 246 174 558 minecraft:orange_concrete
setblock 245 174 557 minecraft:yellow_concrete
fill 246 174 557 247 192 557 minecraft:orange_terracotta
fill 246 174 598 248 174 598 minecraft:orange_concrete
fill 247 174 599 248 175 599 minecraft:yellow_concrete
fill 248 174 557 249 175 557 minecraft:yellow_concrete
fill 248 174 558 250 174 558 minecraft:orange_concrete
fill 249 174 599 250 192 599 minecraft:orange_terracotta
fill 250 174 598 252 174 598 minecraft:orange_concrete
fill 252 174 558 254 174 558 minecraft:orange_concrete
fill 254 174 557 255 176 557 minecraft:orange_terracotta
fill 254 174 598 256 174 598 minecraft:orange_concrete
fill 256 174 557 257 174 557 minecraft:yellow_concrete
fill 256 174 558 258 174 558 minecraft:orange_concrete
fill 258 174 557 258 195 557 minecraft:orange_terracotta
fill 258 174 598 260 174 598 minecraft:orange_concrete
fill 258 174 599 258 195 599 minecraft:orange_terracotta
fill 259 174 599 260 174 599 minecraft:yellow_concrete
fill 260 174 557 260 175 557 minecraft:yellow_concrete
fill 260 174 558 262 174 558 minecraft:orange_concrete
setblock 261 174 557 minecraft:orange_terracotta
fill 261 174 599 262 191 599 minecraft:orange_terracotta
fill 262 174 598 264 174 598 minecraft:orange_concrete
fill 264 174 558 266 174 558 minecraft:orange_concrete
fill 266 174 557 267 191 557 minecraft:orange_terracotta
fill 266 174 598 268 174 598 minecraft:orange_concrete
fill 267 174 599 268 175 599 minecraft:yellow_concrete
fill 268 174 557 269 175 557 minecraft:yellow_concrete
fill 268 174 558 270 174 558 minecraft:orange_concrete
fill 269 174 599 270 192 599 minecraft:orange_terracotta
fill 270 174 598 272 174 598 minecraft:orange_concrete
setblock 271 174 599 minecraft:yellow_concrete
fill 272 174 558 274 174 558 minecraft:orange_concrete
fill 274 174 598 276 174 598 minecraft:orange_concrete
fill 275 174 557 275 191 557 minecraft:orange_terracotta
fill 276 174 558 276 174 560 minecraft:orange_concrete
fill 276 174 562 276 174 564 minecraft:orange_concrete
fill 276 174 566 276 174 568 minecraft:orange_concrete
fill 276 174 570 276 174 572 minecraft:orange_concrete
fill 276 174 574 276 174 576 minecraft:orange_concrete
fill 276 174 578 276 174 580 minecraft:orange_concrete
fill 276 174 582 276 174 584 minecraft:orange_concrete
fill 276 174 586 276 174 588 minecraft:orange_concrete
fill 276 174 590 276 174 592 minecraft:orange_concrete
fill 276 174 594 276 174 596 minecraft:orange_concrete
setblock 277 174 557 minecraft:yellow_concrete
fill 277 174 558 277 192 559 minecraft:orange_terracotta
fill 277 174 560 277 175 560 minecraft:yellow_concrete
fill 277 174 566 277 191 567 minecraft:orange_terracotta
fill 277 174 568 277 174 569 minecraft:yellow_concrete
fill 277 174 578 277 192 579 minecraft:orange_terracotta
fill 277 174 580 277 175 581 minecraft:yellow_concrete
fill 277 174 587 277 191 587 minecraft:orange_terracotta
fill 277 174 588 277 174 589 minecraft:yellow_concrete
fill 277 174 590 277 195 590 minecraft:orange_terracotta
fill 277 174 592 277 175 592 minecraft:yellow_concrete
fill 277 174 598 277 191 598 minecraft:orange_terracotta
setblock 235 175 567 minecraft:yellow_concrete
fill 235 175 571 235 178 572 minecraft:orange_terracotta
setblock 235 175 588 minecraft:yellow_concrete
setblock 235 175 591 minecraft:yellow_concrete
fill 235 175 592 235 178 592 minecraft:orange_terracotta
setblock 235 175 599 minecraft:yellow_concrete
fill 239 175 599 239 178 599 minecraft:orange_terracotta
setblock 240 175 557 minecraft:yellow_concrete
fill 245 175 557 245 177 557 minecraft:orange_terracotta
fill 255 175 599 256 175 599 minecraft:yellow_concrete
fill 256 175 557 256 178 557 minecraft:orange_terracotta
setblock 257 175 557 minecraft:yellow_concrete
setblock 259 175 599 minecraft:yellow_concrete
fill 260 175 599 260 178 599 minecraft:orange_terracotta
setblock 261 175 557 minecraft:yellow_concrete
fill 271 175 599 271 178 599 minecraft:orange_terracotta
setblock 276 175 599 minecraft:yellow_concrete
fill 277 175 557 277 178 557 minecraft:orange_terracotta
setblock 277 175 561 minecraft:yellow_concrete
fill 277 175 568 277 178 568 minecraft:orange_terracotta
setblock 277 175 569 minecraft:yellow_concrete
setblock 277 175 572 minecraft:yellow_concrete
fill 277 175 588 277 178 589 minecraft:orange_terracotta
setblock 277 175 593 minecraft:yellow_concrete
fill 235 176 557 235 176 558 minecraft:yellow_concrete
fill 235 176 559 235 193 560 minecraft:orange_terracotta
fill 235 176 565 235 177 566 minecraft:yellow_concrete
fill 235 176 567 235 189 568 minecraft:orange_terracotta
setblock 235 176 569 minecraft:yellow_concrete
fill 235 176 577 235 177 578 minecraft:yellow_concrete
fill 235 176 579 235 189 580 minecraft:orange_terracotta
fill 235 176 586 235 177 586 minecraft:yellow_concrete
fill 235 176 588 235 189 588 minecraft:orange_terracotta
fill 235 176 589 235 176 590 minecraft:yellow_concrete
fill 235 176 591 235 193 591 minecraft:orange_terracotta
fill 235 176 597 235 177 598 minecraft:yellow_concrete
fill 235 176 599 236 189 599 minecraft:orange_terracotta
fill 236 176 557 237 178 557 minecraft:orange_terracotta
fill 238 176 557 239 176 557 minecraft:yellow_concrete
fill 240 176 557 240 189 557 minecraft:orange_terracotta
fill 242 176 557 242 177 557 minecraft:yellow_concrete
setblock 243 176 557 minecraft:orange_terracotta
fill 245 176 599 246 176 599 minecraft:yellow_concrete
fill 247 176 599 248 189 599 minecraft:orange_terracotta
fill 248 176 557 249 189 557 minecraft:orange_terracotta
fill 250 176 557 251 177 557 minecraft:yellow_concrete
fill 254 176 599 254 177 599 minecraft:yellow_concrete
fill 255 176 599 256 189 599 minecraft:orange_terracotta
fill 257 176 557 257 178 557 minecraft:orange_terracotta
setblock 257 176 599 minecraft:yellow_concrete
setblock 259 176 557 minecraft:yellow_concrete
fill 259 176 599 259 193 599 minecraft:orange_terracotta
fill 260 176 557 261 189 557 minecraft:orange_terracotta
fill 262 176 557 263 177 557 minecraft:yellow_concrete
fill 265 176 599 266 177 599 minecraft:yellow_concrete
fill 267 176 599 268 189 599 minecraft:orange_terracotta
fill 268 176 557 269 189 557 minecraft:orange_terracotta
fill 270 176 557 271 176 557 minecraft:yellow_concrete
fill 276 176 599 276 189 599 minecraft:orange_terracotta
fill 277 176 560 277 189 561 minecraft:orange_terracotta
fill 277 176 562 277 177 563 minecraft:yellow_concrete
fill 277 176 569 277 193 569 minecraft:orange_terracotta
fill 277 176 570 277 176 571 minecraft:yellow_concrete
fill 277 176 572 277 189 572 minecraft:orange_terracotta
fill 277 176 574 277 177 574 minecraft:yellow_concrete
fill 277 176 580 277 189 581 minecraft:orange_terracotta
fill 277 176 582 277 177 583 minecraft:yellow_concrete
setblock 277 176 591 minecraft:yellow_concrete
fill 277 176 592 277 189 593 minecraft:orange_terracotta
fill 277 176 594 277 177 595 minecraft:yellow_concrete
fill 277 176 599 277 177 599 minecraft:yellow_concrete
setblock 235 177 557 minecraft:yellow_concrete
fill 235 177 558 235 195 558 minecraft:orange_terracotta
fill 235 177 569 235 195 569 minecraft:orange_terracotta
setblock 235 177 574 minecraft:yellow_concrete
setblock 235 177 585 minecraft:yellow_concrete
fill 235 177 589 235 195 590 minecraft:orange_terracotta
fill 238 177 557 238 195 557 minecraft:orange_terracotta
setblock 239 177 557 minecraft:yellow_concrete
setblock 242 177 599 minecraft:yellow_concrete
setblock 243 177 557 minecraft:yellow_concrete
setblock 245 177 599 minecraft:yellow_concrete
fill 246 177 599 246 195 599 minecraft:orange_terracotta
setblock 253 177 599 minecraft:yellow_concrete
setblock 254 177 557 minecraft:yellow_concrete
fill 255 177 557 255 191 557 minecraft:orange_terracotta
fill 257 177 599 257 195 599 minecraft:orange_terracotta
fill 259 177 557 259 195 557 minecraft:orange_terracotta
fill 269 177 593 269 177 596 minecraft:magma_block
fill 270 177 557 270 195 557 minecraft:orange_terracotta
setblock 271 177 557 minecraft:yellow_concrete
fill 273 177 599 274 177 599 minecraft:yellow_concrete
setblock 274 177 557 minecraft:yellow_concrete
fill 277 177 570 277 195 571 minecraft:orange_terracotta
setblock 277 177 575 minecraft:yellow_concrete
setblock 277 177 586 minecraft:yellow_concrete
fill 277 177 591 277 195 591 minecraft:orange_terracotta
fill 235 178 557 235 195 557 minecraft:orange_terracotta
fill 235 178 563 235 179 564 minecraft:yellow_concrete
fill 235 178 565 235 191 566 minecraft:orange_terracotta
fill 235 178 574 235 191 574 minecraft:orange_terracotta
fill 235 178 575 235 178 576 minecraft:yellow_concrete
fill 235 178 577 235 195 578 minecraft:orange_terracotta
fill 235 178 583 235 179 584 minecraft:yellow_concrete
fill 235 178 585 235 191 586 minecraft:orange_terracotta
setblock 235 178 587 minecraft:yellow_concrete
fill 235 178 595 235 179 596 minecraft:yellow_concrete
fill 235 178 597 235 191 598 minecraft:orange_terracotta
setblock 238 178 560 minecraft:light[level=14]
setblock 238 178 568 minecraft:light[level=14]
setblock 238 178 576 minecraft:light[level=14]
setblock 238 178 584 minecraft:light[level=14]
setblock 238 178 592 minecraft:light[level=14]
fill 239 178 557 239 195 557 minecraft:orange_terracotta
fill 240 178 599 240 179 599 minecraft:yellow_concrete
setblock 241 178 557 minecraft:yellow_concrete
fill 242 178 557 243 191 557 minecraft:orange_terracotta
fill 242 178 599 242 191 599 minecraft:orange_terracotta
fill 243 178 599 244 178 599 minecraft:yellow_concrete
fill 244 178 557 245 179 557 minecraft:yellow_concrete
fill 245 178 599 245 195 599 minecraft:orange_terracotta
setblock 246 178 560 minecraft:light[level=14]
setblock 246 178 568 minecraft:light[level=14]
setblock 246 178 576 minecraft:light[level=14]
setblock 246 178 584 minecraft:light[level=14]
setblock 246 178 592 minecraft:light[level=14]
fill 250 178 557 251 195 557 minecraft:orange_terracotta
fill 251 178 599 252 179 599 minecraft:yellow_concrete
fill 252 178 557 253 178 557 minecraft:yellow_concrete
fill 253 178 599 254 191 599 minecraft:orange_terracotta
fill 254 178 557 254 191 557 minecraft:orange_terracotta
setblock 254 178 560 minecraft:light[level=14]
setblock 254 178 568 minecraft:light[level=14]
setblock 254 178 576 minecraft:light[level=14]
setblock 254 178 584 minecraft:light[level=14]
setblock 254 178 592 minecraft:light[level=14]
fill 262 178 557 263 191 557 minecraft:orange_terracotta
setblock 262 178 560 minecraft:light[level=14]
setblock 262 178 568 minecraft:light[level=14]
setblock 262 178 576 minecraft:light[level=14]
setblock 262 178 584 minecraft:light[level=14]
setblock 262 178 592 minecraft:light[level=14]
fill 263 178 599 264 178 599 minecraft:yellow_concrete
fill 264 178 557 265 179 557 minecraft:yellow_concrete
fill 265 178 599 266 191 599 minecraft:orange_terracotta
fill 268 178 596 270 178 597 minecraft:magma_block
setblock 269 178 595 minecraft:magma_block
fill 269 178 598 269 179 598 minecraft:magma_block
setblock 270 178 560 minecraft:light[level=14]
setblock 270 178 568 minecraft:light[level=14]
setblock 270 178 576 minecraft:light[level=14]
setblock 270 178 584 minecraft:light[level=14]
setblock 270 178 592 minecraft:light[level=14]
fill 271 178 557 271 195 557 minecraft:orange_terracotta
fill 272 178 557 273 178 557 minecraft:yellow_concrete
fill 272 178 599 272 179 599 minecraft:yellow_concrete
fill 273 178 599 274 191 599 minecraft:orange_terracotta
fill 274 178 557 274 191 557 minecraft:orange_terracotta
setblock 275 178 599 minecraft:yellow_concrete
fill 276 178 557 276 179 557 minecraft:yellow_concrete
fill 277 178 562 277 191 563 minecraft:orange_terracotta
fill 277 178 564 277 179 565 minecraft:yellow_concrete
setblock 277 178 573 minecraft:yellow_concrete
fill 277 178 574 277 191 575 minecraft:orange_terracotta
fill 277 178 576 277 179 577 minecraft:yellow_concrete
fill 277 178 582 277 195 583 minecraft:orange_terracotta
fill 277 178 584 277 178 585 minecraft:yellow_concrete
fill 277 178 586 277 191 586 minecraft:orange_terracotta
fill 277 178 594 277 191 595 minecraft:orange_terracotta
fill 277 178 596 277 179 597 minecraft:yellow_concrete
fill 277 178 599 277 195 599 minecraft:orange_terracotta
fill 235 179 571 235 179 572 minecraft:yellow_concrete
setblock 235 179 575 minecraft:yellow_concrete
fill 235 179 576 235 189 576 minecraft:orange_terracotta
fill 235 179 587 235 189 587 minecraft:orange_terracotta
setblock 235 179 592 minecraft:yellow_concrete
setblock 236 179 557 minecraft:yellow_concrete
fill 237 179 557 237 193 557 minecraft:orange_terracotta
setblock 239 179 599 minecraft:yellow_concrete
fill 241 179 557 241 189 557 minecraft:orange_terracotta
fill 243 179 599 244 189 599 minecraft:orange_terracotta
fill 252 179 557 252 189 557 minecraft:orange_terracotta
setblock 253 179 557 minecraft:yellow_concrete
fill 256 179 557 257 179 557 minecraft:yellow_concrete
setblock 260 179 599 minecraft:yellow_concrete
setblock 263 179 599 minecraft:yellow_concrete
fill 264 179 599 264 189 599 minecraft:orange_terracotta
fill 268 179 597 270 179 597 minecraft:magma_block
setblock 269 179 596 minecraft:magma_block
setblock 271 179 599 minecraft:yellow_concrete
fill 272 179 557 273 189 557 minecraft:orange_terracotta
fill 275 179 599 275 189 599 minecraft:orange_terracotta
setblock 277 179 557 minecraft:yellow_concrete
setblock 277 179 568 minecraft:yellow_concrete
fill 277 179 573 277 189 573 minecraft:orange_terracotta
fill 277 179 584 277 189 584 minecraft:orange_terracotta
setblock 277 179 585 minecraft:yellow_concrete
fill 277 179 588 277 179 589 minecraft:yellow_concrete
fill 235 180 563 235 190 564 minecraft:orange_terracotta
fill 235 180 571 235 193 572 minecraft:orange_terracotta
fill 235 180 575 235 190 575 minecraft:orange_terracotta
fill 235 180 583 235 193 584 minecraft:orange_terracotta
fill 235 180 592 235 193 592 minecraft:orange_terracotta
fill 235 180 595 235 190 596 minecraft:orange_terracotta
fill 236 180 557 236 193 557 minecraft:orange_terracotta
fill 239 180 599 240 193 599 minecraft:orange_terracotta
fill 244 180 557 245 193 557 minecraft:orange_terracotta
fill 251 180 599 252 190 599 minecraft:orange_terracotta
fill 253 180 557 253 190 557 minecraft:orange_terracotta
setblock 254 180 577 minecraft:yellow_concrete
setblock 254 180 579 minecraft:yellow_concrete
fill 255 180 576 256 180 576 minecraft:yellow_concrete
fill 255 180 580 256 180 580 minecraft:yellow_concrete
fill 256 180 557 257 193 557 minecraft:orange_terracotta
fill 256 180 577 257 180 577 minecraft:yellow_concrete
fill 256 180 579 257 180 579 minecraft:yellow_concrete
setblock 257 180 578 minecraft:yellow_concrete
fill 260 180 599 260 193 599 minecraft:orange_terracotta
fill 263 180 599 263 190 599 minecraft:orange_terracotta
fill 264 180 557 265 190 557 minecraft:orange_terracotta
fill 271 180 599 272 193 599 minecraft:orange_terracotta
fill 276 180 557 277 193 557 minecraft:orange_terracotta
fill 277 180 564 277 189 565 minecraft:orange_terracotta
fill 277 180 568 277 193 568 minecraft:orange_terracotta
fill 277 180 576 277 193 577 minecraft:orange_terracotta
fill 277 180 585 277 190 585 minecraft:orange_terracotta
fill 277 180 588 277 193 589 minecraft:orange_terracotta
fill 277 180 596 277 190 597 minecraft:orange_terracotta
fill 252 181 577 253 181 579 minecraft:yellow_concrete
fill 253 181 575 254 181 576 minecraft:yellow_concrete
fill 253 181 580 254 181 581 minecraft:yellow_concrete
fill 254 181 577 254 183 577 minecraft:shroomlight
fill 254 181 579 254 183 579 minecraft:shroomlight
fill 255 181 575 258 181 575 minecraft:yellow_concrete
fill 255 181 576 256 190 576 minecraft:shroomlight
fill 255 181 580 256 190 580 minecraft:shroomlight
fill 255 181 581 258 181 581 minecraft:yellow_concrete
fill 256 181 577 257 183 577 minecraft:shroomlight
fill 256 181 579 257 183 579 minecraft:shroomlight
fill 257 181 576 258 181 576 minecraft:yellow_concrete
fill 257 181 578 257 190 578 minecraft:shroomlight
fill 257 181 580 258 181 580 minecraft:yellow_concrete
fill 258 181 577 259 181 579 minecraft:yellow_concrete
fill 251 182 577 251 183 579 minecraft:yellow_concrete
fill 252 182 575 252 182 576 minecraft:yellow_concrete
fill 252 182 577 253 189 579 minecraft:shroomlight
fill 252 182 580 252 182 581 minecraft:yellow_concrete
fill 253 182 574 258 182 574 minecraft:yellow_concrete
fill 253 182 575 254 183 576 minecraft:shroomlight
fill 253 182 580 254 189 581 minecraft:shroomlight
fill 253 182 582 258 182 582 minecraft:yellow_concrete
fill 255 182 575 258 183 575 minecraft:shroomlight
fill 255 182 581 258 189 581 minecraft:shroomlight
fill 257 182 576 258 183 576 minecraft:shroomlight
fill 257 182 580 258 189 580 minecraft:shroomlight
fill 258 182 577 259 189 579 minecraft:shroomlight
fill 259 182 575 259 182 576 minecraft:yellow_concrete
fill 259 182 580 259 182 581 minecraft:yellow_concrete
fill 260 182 577 260 183 579 minecraft:yellow_concrete
fill 251 183 575 251 183 576 minecraft:yellow_concrete
fill 251 183 580 251 184 581 minecraft:yellow_concrete
fill 252 183 574 253 183 574 minecraft:yellow_concrete
fill 252 183 575 252 183 576 minecraft:shroomlight
fill 252 183 580 252 188 581 minecraft:shroomlight
fill 252 183 582 253 183 582 minecraft:yellow_concrete
fill 254 183 573 257 185 573 minecraft:yellow_concrete
fill 254 183 574 257 188 574 minecraft:shroomlight
fill 254 183 582 257 183 582 minecraft:shroomlight
fill 254 183 583 257 183 583 minecraft:yellow_concrete
fill 258 183 574 259 183 574 minecraft:yellow_concrete
fill 258 183 582 259 183 582 minecraft:yellow_concrete
fill 259 183 575 259 183 576 minecraft:shroomlight
fill 259 183 580 259 188 581 minecraft:shroomlight
fill 260 183 575 260 183 576 minecraft:yellow_concrete
fill 260 183 580 260 184 581 minecraft:yellow_concrete
fill 250 184 577 250 187 579 minecraft:yellow_concrete
fill 251 184 573 253 184 575 minecraft:redstone_block
setblock 251 184 576 minecraft:yellow_concrete
fill 251 184 577 251 187 579 minecraft:shroomlight
fill 252 184 576 254 188 576 minecraft:shroomlight
fill 252 184 582 252 188 582 minecraft:yellow_concrete
fill 253 184 582 253 187 582 minecraft:shroomlight
fill 253 184 583 253 185 583 minecraft:yellow_concrete
fill 254 184 575 257 189 575 minecraft:shroomlight
fill 254 184 582 256 184 584 minecraft:redstone_block
fill 257 184 576 257 189 577 minecraft:shroomlight
fill 257 184 579 257 190 579 minecraft:shroomlight
fill 257 184 582 258 187 582 minecraft:shroomlight
fill 257 184 583 258 185 583 minecraft:yellow_concrete
fill 258 184 573 258 185 573 minecraft:yellow_concrete
fill 258 184 574 260 184 576 minecraft:redstone_block
fill 259 184 582 259 188 582 minecraft:yellow_concrete
fill 260 184 577 260 187 579 minecraft:shroomlight
fill 261 184 577 261 185 579 minecraft:yellow_concrete
setblock 250 185 576 minecraft:yellow_concrete
fill 250 185 580 250 186 580 minecraft:yellow_concrete
fill 251 185 576 251 186 576 minecraft:shroomlight
fill 251 185 580 251 186 580 minecraft:shroomlight
fill 251 185 581 251 188 581 minecraft:yellow_concrete
fill 260 185 580 260 186 580 minecraft:shroomlight
fill 260 185 581 260 188 581 minecraft:yellow_concrete
setblock 261 185 576 minecraft:yellow_concrete
fill 261 185 580 261 186 580 minecraft:yellow_concrete
fill 236 186 558 249 186 598 minecraft:red_nether_bricks
fill 250 186 558 276 186 571 minecraft:red_nether_bricks
fill 250 186 572 250 186 576 minecraft:shroomlight
fill 250 186 581 250 186 598 minecraft:red_nether_bricks
fill 251 186 572 254 186 572 minecraft:shroomlight
fill 251 186 573 253 186 575 minecraft:red_nether_bricks
fill 251 186 582 251 186 598 minecraft:red_nether_bricks
fill 252 186 583 252 186 598 minecraft:red_nether_bricks
fill 253 186 583 253 186 585 minecraft:shroomlight
fill 253 186 586 276 186 598 minecraft:red_nether_bricks
setblock 254 186 573 minecraft:shroomlight
fill 254 186 582 256 186 584 minecraft:red_nether_bricks
fill 254 186 585 257 186 585 minecraft:shroomlight
fill 255 186 572 276 186 572 minecraft:red_nether_bricks
fill 255 186 573 256 188 573 minecraft:yellow_concrete
fill 257 186 573 261 186 573 minecraft:shroomlight
fill 257 186 583 257 186 584 minecraft:shroomlight
fill 258 186 574 260 186 576 minecraft:red_nether_bricks
fill 258 186 583 258 187 583 minecraft:yellow_concrete
fill 258 186 584 276 186 585 minecraft:red_nether_bricks
fill 259 186 583 276 186 583 minecraft:red_nether_bricks
fill 260 186 582 276 186 582 minecraft:red_nether_bricks
fill 261 186 574 261 186 577 minecraft:shroomlight
fill 261 186 578 261 187 579 minecraft:yellow_concrete
fill 261 186 581 276 186 581 minecraft:red_nether_bricks
fill 262 186 573 276 186 580 minecraft:red_nether_bricks
fill 251 187 575 251 188 576 minecraft:yellow_concrete
fill 251 187 580 251 188 580 minecraft:yellow_concrete
fill 252 187 574 252 188 574 minecraft:yellow_concrete
fill 252 187 575 253 188 575 minecraft:shroomlight
fill 253 187 573 254 187 573 minecraft:yellow_concrete
setblock 253 187 574 minecraft:shroomlight
fill 253 187 583 257 187 583 minecraft:yellow_concrete
fill 254 187 582 256 188 582 minecraft:shroomlight
fill 257 187 573 258 187 573 minecraft:yellow_concrete
fill 258 187 574 258 187 576 minecraft:shroomlight
fill 259 187 574 259 188 574 minecraft:yellow_concrete
fill 259 187 575 259 188 576 minecraft:shroomlight
fill 260 187 575 260 188 576 minecraft:yellow_concrete
fill 260 187 580 260 188 580 minecraft:yellow_concrete
setblock 261 187 577 minecraft:yellow_concrete
fill 251 188 577 251 189 579 minecraft:yellow_concrete
fill 253 188 574 253 189 574 minecraft:yellow_concrete
fill 253 188 582 253 189 582 minecraft:yellow_concrete
setblock 254 188 573 minecraft:yellow_concrete
fill 254 188 583 257 188 583 minecraft:yellow_concrete
setblock 257 188 573 minecraft:yellow_concrete
setblock 257 188 582 minecraft:shroomlight
fill 258 188 574 258 189 574 minecraft:yellow_concrete
fill 258 188 575 258 189 576 minecraft:shroomlight
fill 258 188 582 258 189 582 minecraft:yellow_concrete
fill 260 188 577 260 189 579 minecraft:yellow_concrete
fill 252 189 575 252 189 576 minecraft:yellow_concrete
fill 252 189 580 252 189 581 minecraft:yellow_concrete
fill 253 189 575 253 189 576 minecraft:shroomlight
fill 254 189 574 257 189 574 minecraft:yellow_concrete
fill 254 189 576 254 189 577 minecraft:shroomlight
fill 254 189 579 254 190 579 minecraft:shroomlight
fill 254 189 582 257 189 582 minecraft:yellow_concrete
fill 256 189 577 256 190 577 minecraft:shroomlight
fill 256 189 579 256 190 579 minecraft:shroomlight
fill 259 189 575 259 189 576 minecraft:yellow_concrete
fill 259 189 580 259 189 581 minecraft:yellow_concrete
fill 235 190 567 235 190 568 minecraft:yellow_concrete
fill 235 190 576 235 191 576 minecraft:yellow_concrete
setblock 235 190 579 minecraft:yellow_concrete
fill 235 190 580 235 193 580 minecraft:orange_terracotta
fill 235 190 587 235 191 588 minecraft:yellow_concrete
fill 235 190 599 236 190 599 minecraft:yellow_concrete
fill 240 190 557 241 191 557 minecraft:yellow_concrete
fill 243 190 599 244 191 599 minecraft:yellow_concrete
fill 244 190 575 244 193 581 minecraft:iron_block
fill 245 190 573 245 193 574 minecraft:iron_block
fill 245 190 582 245 193 583 minecraft:iron_block
fill 246 190 571 246 193 572 minecraft:iron_block
fill 246 190 584 246 193 585 minecraft:iron_block
fill 247 190 570 247 190 571 minecraft:iron_block
fill 247 190 585 247 190 586 minecraft:iron_block
setblock 247 190 599 minecraft:yellow_concrete
fill 248 190 557 248 193 557 minecraft:orange_terracotta
fill 248 190 569 248 193 570 minecraft:iron_block
fill 248 190 586 248 193 587 minecraft:iron_block
fill 248 190 599 248 193 599 minecraft:orange_terracotta
setblock 249 190 557 minecraft:yellow_concrete
fill 249 190 569 249 193 569 minecraft:iron_block
fill 249 190 587 249 193 587 minecraft:iron_block
fill 250 190 568 251 193 568 minecraft:iron_block
fill 250 190 588 251 193 588 minecraft:iron_block
fill 252 190 557 252 191 557 minecraft:yellow_concrete
fill 252 190 567 258 193 567 minecraft:iron_block
fill 252 190 577 253 190 579 minecraft:yellow_concrete
fill 252 190 589 258 193 589 minecraft:iron_block
fill 253 190 575 254 190 576 minecraft:yellow_concrete
fill 253 190 580 254 190 581 minecraft:yellow_concrete
setblock 254 190 577 minecraft:shroomlight
fill 255 190 575 258 190 575 minecraft:yellow_concrete
fill 255 190 581 258 190 581 minecraft:yellow_concrete
fill 255 190 599 256 191 599 minecraft:yellow_concrete
fill 257 190 576 258 190 576 minecraft:yellow_concrete
setblock 257 190 577 minecraft:shroomlight
fill 257 190 580 258 190 580 minecraft:yellow_concrete
fill 258 190 577 259 190 579 minecraft:yellow_concrete
fill 259 190 568 260 193 568 minecraft:iron_block
fill 259 190 588 260 193 588 minecraft:iron_block
fill 260 190 557 261 191 557 minecraft:yellow_concrete
fill 261 190 569 262 193 569 minecraft:iron_block
fill 261 190 587 262 193 587 minecraft:iron_block
fill 262 190 570 263 190 570 minecraft:iron_block
fill 262 190 586 263 190 586 minecraft:iron_block
fill 263 190 571 264 193 571 minecraft:iron_block
fill 263 190 585 264 193 585 minecraft:iron_block
fill 264 190 572 264 193 572 minecraft:iron_block
fill 264 190 584 264 193 584 minecraft:iron_block
fill 264 190 599 264 191 599 minecraft:yellow_concrete
fill 265 190 573 265 193 574 minecraft:iron_block
fill 265 190 582 265 193 583 minecraft:iron_block
fill 266 190 575 266 193 581 minecraft:iron_block
fill 267 190 599 268 190 599 minecraft:yellow_concrete
fill 268 190 557 268 193 557 minecraft:orange_terracotta
setblock 269 190 557 minecraft:yellow_concrete
fill 272 190 557 273 191 557 minecraft:yellow_concrete
fill 275 190 599 276 191 599 minecraft:yellow_concrete
fill 277 190 560 277 190 561 minecraft:yellow_concrete
fill 277 190 564 277 191 564 minecraft:yellow_concrete
setblock 277 190 565 minecraft:orange_terracotta
fill 277 190 572 277 191 573 minecraft:yellow_concrete
fill 277 190 580 277 193 580 minecraft:orange_terracotta
setblock 277 190 581 minecraft:yellow_concrete
fill 277 190 584 277 191 584 minecraft:yellow_concrete
fill 277 190 592 277 190 593 minecraft:yellow_concrete
fill 235 191 563 235 193 563 minecraft:orange_terracotta
setblock 235 191 564 minecraft:yellow_concrete
setblock 235 191 567 minecraft:yellow_concrete
fill 235 191 568 235 194 568 minecraft:orange_terracotta
setblock 235 191 575 minecraft:yellow_concrete
fill 235 191 579 235 194 579 minecraft:orange_terracotta
fill 235 191 595 235 191 596 minecraft:yellow_concrete
setblock 235 191 599 minecraft:yellow_concrete
fill 236 191 599 236 194 599 minecraft:orange_terracotta
fill 243 191 575 243 191 581 minecraft:iron_block
fill 244 191 573 244 192 574 minecraft:iron_block
fill 244 191 582 244 192 583 minecraft:iron_block
fill 245 191 571 245 192 572 minecraft:iron_block
fill 245 191 575 245 192 581 minecraft:iron_block
fill 245 191 584 245 192 585 minecraft:iron_block
fill 246 191 570 246 192 570 minecraft:iron_block
fill 246 191 573 246 192 575 minecraft:iron_block
fill 246 191 581 246 192 583 minecraft:iron_block
fill 246 191 586 246 192 586 minecraft:iron_block
fill 247 191 569 247 192 569 minecraft:iron_block
fill 247 191 570 247 192 570 minecraft:light_gray_concrete
fill 247 191 571 247 192 572 minecraft:iron_block
fill 247 191 584 247 192 585 minecraft:iron_block
fill 247 191 586 247 192 586 minecraft:light_gray_concrete
fill 247 191 587 247 192 587 minecraft:iron_block
fill 247 191 599 247 194 599 minecraft:orange_terracotta
fill 248 191 568 249 192 568 minecraft:iron_block
fill 248 191 571 248 192 571 minecraft:light_gray_concrete
fill 248 191 585 248 192 585 minecraft:light_gray_concrete
fill 248 191 588 249 192 588 minecraft:iron_block
fill 249 191 557 249 194 557 minecraft:orange_terracotta
fill 249 191 570 249 192 570 minecraft:iron_block
fill 249 191 572 249 192 572 minecraft:light_gray_concrete
fill 249 191 584 249 192 584 minecraft:light_gray_concrete
fill 249 191 586 249 192 586 minecraft:iron_block
fill 250 191 567 251 192 567 minecraft:iron_block
fill 250 191 569 252 192 569 minecraft:iron_block
fill 250 191 573 250 192 573 minecraft:light_gray_concrete
fill 250 191 583 250 192 583 minecraft:light_gray_concrete
fill 250 191 587 252 192 587 minecraft:iron_block
fill 250 191 589 251 192 589 minecraft:iron_block
fill 251 191 574 251 192 574 minecraft:light_gray_concrete
fill 251 191 577 252 192 579 minecraft:white_concrete
fill 251 191 582 251 192 582 minecraft:light_gray_concrete
fill 251 191 599 251 193 599 minecraft:orange_terracotta
fill 252 191 566 258 192 566 minecraft:iron_block
schedule function dropper:buildpart/137_3 1t
