setblock 179 162 313 minecraft:light[level=12]
fill 179 162 316 179 164 316 minecraft:packed_ice
fill 180 162 276 180 163 276 minecraft:packed_ice
setblock 180 162 283 minecraft:snow_block
fill 180 162 284 180 164 284 minecraft:packed_ice
setblock 180 162 288 minecraft:snow_block
fill 180 162 289 180 165 289 minecraft:packed_ice
setblock 180 162 293 minecraft:snow_block
fill 180 162 294 180 165 294 minecraft:packed_ice
fill 180 162 296 181 162 296 minecraft:packed_ice
fill 181 162 275 182 162 275 minecraft:packed_ice
setblock 181 162 282 minecraft:snow_block
fill 181 162 283 181 165 283 minecraft:packed_ice
setblock 181 162 287 minecraft:snow_block
fill 181 162 288 181 165 288 minecraft:packed_ice
setblock 181 162 292 minecraft:snow_block
fill 181 162 293 181 165 293 minecraft:packed_ice
setblock 181 162 297 minecraft:snow_block
fill 181 162 298 181 165 298 minecraft:packed_ice
fill 181 162 302 181 165 302 minecraft:snow_block
setblock 181 162 303 minecraft:packed_ice
setblock 181 162 307 minecraft:snow_block
fill 181 162 308 181 164 308 minecraft:packed_ice
setblock 181 162 312 minecraft:snow_block
fill 181 162 313 181 165 313 minecraft:packed_ice
fill 181 162 315 181 162 316 minecraft:packed_ice
setblock 182 162 276 minecraft:snow_block
fill 182 162 277 182 165 277 minecraft:packed_ice
setblock 182 162 281 minecraft:snow_block
fill 182 162 282 182 165 282 minecraft:packed_ice
setblock 182 162 286 minecraft:snow_block
fill 182 162 287 182 165 287 minecraft:packed_ice
setblock 182 162 291 minecraft:snow_block
fill 182 162 292 182 165 292 minecraft:packed_ice
setblock 182 162 296 minecraft:snow_block
fill 182 162 297 182 165 297 minecraft:packed_ice
setblock 182 162 301 minecraft:snow_block
fill 182 162 302 182 165 302 minecraft:packed_ice
setblock 182 162 306 minecraft:snow_block
fill 182 162 307 182 165 307 minecraft:packed_ice
setblock 182 162 311 minecraft:snow_block
fill 182 162 312 182 165 312 minecraft:packed_ice
setblock 182 162 316 minecraft:snow_block
setblock 183 162 288 minecraft:packed_ice
fill 183 162 296 183 163 296 minecraft:packed_ice
setblock 183 162 299 minecraft:white_concrete
fill 183 162 301 183 165 301 minecraft:blue_ice
setblock 183 162 313 minecraft:packed_ice
setblock 183 162 315 minecraft:light_blue_concrete
fill 141 163 287 141 165 287 minecraft:blue_ice
setblock 141 163 292 minecraft:blue_ice
setblock 141 163 309 minecraft:packed_ice
fill 142 163 275 144 165 275 minecraft:blue_ice
fill 142 163 276 142 166 276 minecraft:packed_ice
setblock 142 163 280 minecraft:snow_block
fill 142 163 281 142 166 281 minecraft:packed_ice
setblock 142 163 285 minecraft:snow_block
fill 142 163 286 142 165 287 minecraft:packed_ice
setblock 142 163 290 minecraft:snow_block
fill 142 163 291 142 165 292 minecraft:packed_ice
setblock 142 163 295 minecraft:snow_block
fill 142 163 296 142 166 296 minecraft:packed_ice
setblock 142 163 300 minecraft:snow_block
setblock 142 163 301 minecraft:packed_ice
setblock 142 163 305 minecraft:snow_block
fill 142 163 306 142 165 306 minecraft:packed_ice
setblock 142 163 310 minecraft:snow_block
fill 142 163 311 142 166 311 minecraft:packed_ice
setblock 142 163 314 minecraft:packed_ice
setblock 142 163 315 minecraft:snow_block
fill 142 163 316 142 166 316 minecraft:packed_ice
setblock 143 163 279 minecraft:snow_block
fill 143 163 280 143 166 280 minecraft:packed_ice
setblock 143 163 284 minecraft:snow_block
fill 143 163 285 143 166 285 minecraft:packed_ice
setblock 143 163 289 minecraft:snow_block
fill 143 163 290 143 166 290 minecraft:packed_ice
setblock 143 163 293 minecraft:packed_ice
setblock 143 163 294 minecraft:snow_block
fill 143 163 295 143 166 295 minecraft:packed_ice
setblock 143 163 309 minecraft:snow_block
fill 143 163 310 143 166 310 minecraft:packed_ice
setblock 143 163 313 minecraft:packed_ice
setblock 143 163 314 minecraft:snow_block
fill 143 163 315 143 166 315 minecraft:packed_ice
setblock 144 163 283 minecraft:snow_block
fill 144 163 284 144 164 284 minecraft:packed_ice
setblock 144 163 288 minecraft:snow_block
fill 144 163 289 144 165 289 minecraft:packed_ice
setblock 144 163 293 minecraft:snow_block
setblock 144 163 309 minecraft:packed_ice
setblock 144 163 313 minecraft:snow_block
fill 144 163 314 144 166 314 minecraft:packed_ice
setblock 145 163 277 minecraft:snow_block
fill 146 163 275 146 165 275 minecraft:blue_ice
setblock 146 163 276 minecraft:snow_block
fill 146 163 277 146 165 277 minecraft:packed_ice
fill 146 163 314 147 163 314 minecraft:packed_ice
setblock 146 163 316 minecraft:snow_block
fill 147 163 276 147 166 276 minecraft:packed_ice
setblock 147 163 315 minecraft:snow_block
fill 147 163 316 147 166 316 minecraft:packed_ice
setblock 148 163 314 minecraft:snow_block
fill 148 163 315 148 166 315 minecraft:packed_ice
setblock 151 163 276 minecraft:snow_block
setblock 151 163 316 minecraft:snow_block
setblock 152 163 315 minecraft:snow_block
fill 152 163 316 152 166 316 minecraft:packed_ice
fill 153 163 315 156 163 315 minecraft:packed_ice
fill 154 163 275 154 165 275 minecraft:blue_ice
fill 155 163 314 157 163 314 minecraft:packed_ice
setblock 156 163 276 minecraft:snow_block
setblock 156 163 316 minecraft:snow_block
fill 157 163 276 158 165 276 minecraft:packed_ice
setblock 157 163 315 minecraft:snow_block
fill 157 163 316 157 166 316 minecraft:packed_ice
setblock 158 163 275 minecraft:blue_ice
setblock 158 163 313 minecraft:packed_ice
setblock 158 163 314 minecraft:snow_block
fill 158 163 315 158 166 315 minecraft:packed_ice
fill 158 163 317 158 164 317 minecraft:packed_ice
setblock 159 163 313 minecraft:snow_block
fill 159 163 314 162 163 314 minecraft:packed_ice
fill 160 163 313 160 166 313 minecraft:packed_ice
setblock 161 163 276 minecraft:snow_block
fill 161 163 310 161 200 311 minecraft:snow_block
setblock 161 163 312 minecraft:packed_ice
setblock 161 163 316 minecraft:snow_block
fill 162 163 276 162 166 276 minecraft:packed_ice
setblock 162 163 315 minecraft:snow_block
fill 162 163 316 162 166 316 minecraft:packed_ice
setblock 163 163 312 minecraft:packed_ice
setblock 163 163 314 minecraft:snow_block
fill 163 163 315 163 166 315 minecraft:packed_ice
fill 164 163 275 164 166 275 minecraft:blue_ice
setblock 164 163 313 minecraft:snow_block
fill 164 163 314 164 166 314 minecraft:packed_ice
fill 165 163 313 165 164 313 minecraft:packed_ice
setblock 166 163 316 minecraft:snow_block
fill 166 163 317 167 165 317 minecraft:blue_ice
setblock 167 163 315 minecraft:snow_block
fill 167 163 316 167 166 316 minecraft:packed_ice
fill 168 163 315 168 164 315 minecraft:packed_ice
fill 168 163 317 169 163 317 minecraft:packed_ice
fill 174 163 317 174 165 317 minecraft:blue_ice
fill 178 163 316 178 165 316 minecraft:packed_ice
fill 179 163 276 179 164 276 minecraft:packed_ice
setblock 179 163 287 minecraft:packed_ice
setblock 179 163 288 minecraft:snow_block
fill 179 163 289 179 166 289 minecraft:packed_ice
setblock 179 163 293 minecraft:snow_block
setblock 180 163 287 minecraft:snow_block
fill 180 163 288 180 166 288 minecraft:packed_ice
setblock 180 163 292 minecraft:snow_block
fill 180 163 293 180 166 293 minecraft:packed_ice
setblock 180 163 296 minecraft:packed_ice
fill 180 163 315 181 163 315 minecraft:packed_ice
fill 181 163 275 182 163 275 minecraft:blue_ice
setblock 181 163 276 minecraft:snow_block
fill 181 163 279 181 164 279 minecraft:packed_ice
setblock 181 163 281 minecraft:snow_block
fill 181 163 282 181 166 282 minecraft:packed_ice
setblock 181 163 286 minecraft:snow_block
fill 181 163 287 181 166 287 minecraft:packed_ice
setblock 181 163 291 minecraft:snow_block
fill 181 163 292 181 166 292 minecraft:packed_ice
setblock 181 163 296 minecraft:snow_block
fill 181 163 297 181 166 297 minecraft:packed_ice
fill 181 163 301 181 165 301 minecraft:snow_block
fill 181 163 303 181 165 303 minecraft:snow_block
fill 181 163 306 181 164 306 minecraft:snow_block
fill 181 163 307 181 164 307 minecraft:packed_ice
setblock 181 163 311 minecraft:snow_block
fill 181 163 312 181 166 312 minecraft:packed_ice
setblock 181 163 316 minecraft:snow_block
setblock 181 163 317 minecraft:packed_ice
fill 182 163 276 182 166 276 minecraft:packed_ice
setblock 182 163 280 minecraft:snow_block
fill 182 163 281 182 166 281 minecraft:packed_ice
setblock 182 163 285 minecraft:snow_block
fill 182 163 286 182 166 286 minecraft:packed_ice
setblock 182 163 290 minecraft:snow_block
fill 182 163 291 182 166 291 minecraft:packed_ice
setblock 182 163 295 minecraft:snow_block
fill 182 163 296 182 166 296 minecraft:packed_ice
setblock 182 163 300 minecraft:snow_block
fill 182 163 301 182 166 301 minecraft:packed_ice
setblock 182 163 305 minecraft:snow_block
fill 182 163 306 182 165 306 minecraft:packed_ice
setblock 182 163 310 minecraft:snow_block
fill 182 163 311 182 166 311 minecraft:packed_ice
setblock 182 163 315 minecraft:snow_block
fill 182 163 316 182 166 316 minecraft:packed_ice
fill 183 163 288 183 165 288 minecraft:blue_ice
fill 183 163 299 183 164 299 minecraft:packed_ice
setblock 183 163 302 minecraft:packed_ice
fill 183 163 307 183 165 307 minecraft:blue_ice
setblock 183 163 308 minecraft:packed_ice
fill 183 163 313 183 165 313 minecraft:blue_ice
fill 183 163 315 183 165 315 minecraft:blue_ice
fill 141 164 290 142 164 290 minecraft:packed_ice
setblock 141 164 292 minecraft:packed_ice
fill 141 164 297 141 165 297 minecraft:blue_ice
setblock 141 164 298 minecraft:packed_ice
setblock 141 164 303 minecraft:packed_ice
fill 141 164 309 141 165 309 minecraft:blue_ice
setblock 142 164 279 minecraft:snow_block
fill 142 164 280 142 167 280 minecraft:packed_ice
setblock 142 164 284 minecraft:snow_block
fill 142 164 285 142 167 285 minecraft:packed_ice
setblock 142 164 289 minecraft:snow_block
setblock 142 164 294 minecraft:snow_block
fill 142 164 295 142 167 295 minecraft:packed_ice
setblock 142 164 299 minecraft:snow_block
setblock 142 164 304 minecraft:snow_block
setblock 142 164 305 minecraft:packed_ice
setblock 142 164 309 minecraft:snow_block
fill 142 164 310 142 167 310 minecraft:packed_ice
setblock 142 164 314 minecraft:snow_block
fill 142 164 315 142 167 315 minecraft:packed_ice
setblock 143 164 278 minecraft:snow_block
fill 143 164 279 143 167 279 minecraft:packed_ice
setblock 143 164 283 minecraft:snow_block
fill 143 164 284 143 166 284 minecraft:packed_ice
setblock 143 164 288 minecraft:snow_block
fill 143 164 289 143 167 289 minecraft:packed_ice
setblock 143 164 293 minecraft:snow_block
fill 143 164 294 143 167 294 minecraft:packed_ice
setblock 143 164 308 minecraft:snow_block
fill 143 164 309 143 165 309 minecraft:packed_ice
setblock 143 164 313 minecraft:snow_block
fill 143 164 314 143 167 314 minecraft:packed_ice
setblock 144 164 277 minecraft:snow_block
setblock 144 164 287 minecraft:snow_block
fill 144 164 288 144 165 288 minecraft:packed_ice
setblock 144 164 292 minecraft:snow_block
setblock 144 164 312 minecraft:snow_block
fill 144 164 313 144 166 313 minecraft:packed_ice
setblock 145 164 276 minecraft:snow_block
fill 145 164 277 145 167 277 minecraft:packed_ice
setblock 145 164 316 minecraft:snow_block
fill 146 164 276 146 167 276 minecraft:packed_ice
setblock 146 164 314 minecraft:packed_ice
setblock 146 164 315 minecraft:snow_block
fill 146 164 316 146 167 316 minecraft:packed_ice
setblock 147 164 314 minecraft:snow_block
fill 147 164 315 147 167 315 minecraft:packed_ice
setblock 150 164 276 minecraft:snow_block
setblock 150 164 316 minecraft:snow_block
setblock 151 164 315 minecraft:snow_block
fill 151 164 316 151 167 316 minecraft:packed_ice
fill 152 164 309 152 171 309 minecraft:packed_ice
fill 152 164 315 155 164 315 minecraft:packed_ice
setblock 153 164 317 minecraft:packed_ice
fill 155 164 314 156 164 314 minecraft:packed_ice
setblock 155 164 316 minecraft:snow_block
fill 156 164 276 156 167 276 minecraft:packed_ice
setblock 156 164 315 minecraft:snow_block
fill 156 164 316 156 167 316 minecraft:packed_ice
fill 157 164 275 158 164 275 minecraft:packed_ice
setblock 157 164 314 minecraft:snow_block
fill 157 164 315 157 167 315 minecraft:packed_ice
setblock 158 164 313 minecraft:snow_block
fill 158 164 314 161 164 314 minecraft:packed_ice
fill 159 164 313 159 167 313 minecraft:packed_ice
setblock 160 164 276 minecraft:snow_block
setblock 160 164 316 minecraft:snow_block
fill 161 164 276 161 167 276 minecraft:packed_ice
fill 161 164 312 163 200 312 minecraft:snow_block
setblock 161 164 315 minecraft:snow_block
fill 161 164 316 161 167 316 minecraft:packed_ice
setblock 162 164 275 minecraft:packed_ice
setblock 162 164 314 minecraft:snow_block
fill 162 164 315 162 167 315 minecraft:packed_ice
setblock 163 164 313 minecraft:snow_block
fill 163 164 314 163 167 314 minecraft:packed_ice
fill 164 164 313 164 165 313 minecraft:packed_ice
setblock 165 164 316 minecraft:snow_block
setblock 166 164 315 minecraft:snow_block
fill 166 164 316 166 167 316 minecraft:packed_ice
fill 167 164 315 167 165 315 minecraft:packed_ice
setblock 168 164 275 minecraft:packed_ice
fill 168 164 317 169 165 317 minecraft:blue_ice
fill 175 164 317 177 165 317 minecraft:blue_ice
setblock 176 164 275 minecraft:packed_ice
fill 177 164 316 177 166 316 minecraft:packed_ice
setblock 178 164 275 minecraft:packed_ice
setblock 178 164 317 minecraft:packed_ice
fill 179 164 288 179 165 288 minecraft:packed_ice
fill 179 164 290 179 164 291 minecraft:packed_ice
setblock 179 164 292 minecraft:snow_block
fill 179 164 293 179 167 293 minecraft:packed_ice
setblock 180 164 276 minecraft:snow_block
setblock 180 164 286 minecraft:snow_block
fill 180 164 287 180 167 287 minecraft:packed_ice
setblock 180 164 291 minecraft:snow_block
fill 180 164 292 180 167 292 minecraft:packed_ice
setblock 180 164 296 minecraft:snow_block
setblock 180 164 315 minecraft:packed_ice
setblock 180 164 316 minecraft:snow_block
fill 181 164 275 181 165 275 minecraft:blue_ice
fill 181 164 276 181 166 277 minecraft:packed_ice
setblock 181 164 280 minecraft:snow_block
fill 181 164 281 181 166 281 minecraft:packed_ice
setblock 181 164 285 minecraft:snow_block
fill 181 164 286 181 167 286 minecraft:packed_ice
setblock 181 164 290 minecraft:snow_block
fill 181 164 291 181 167 291 minecraft:packed_ice
setblock 181 164 295 minecraft:snow_block
fill 181 164 296 181 167 296 minecraft:packed_ice
fill 181 164 300 181 165 300 minecraft:snow_block
fill 181 164 304 181 165 305 minecraft:snow_block
setblock 181 164 310 minecraft:snow_block
fill 181 164 311 181 166 311 minecraft:packed_ice
setblock 181 164 315 minecraft:snow_block
fill 181 164 316 181 167 316 minecraft:packed_ice
fill 181 164 317 181 166 317 minecraft:blue_ice
setblock 182 164 275 minecraft:packed_ice
setblock 182 164 279 minecraft:snow_block
fill 182 164 280 182 167 280 minecraft:packed_ice
setblock 182 164 284 minecraft:snow_block
fill 182 164 285 182 167 285 minecraft:packed_ice
setblock 182 164 289 minecraft:snow_block
fill 182 164 290 182 167 290 minecraft:packed_ice
setblock 182 164 294 minecraft:snow_block
fill 182 164 295 182 167 295 minecraft:packed_ice
setblock 182 164 299 minecraft:snow_block
fill 182 164 300 182 167 300 minecraft:packed_ice
setblock 182 164 304 minecraft:snow_block
fill 182 164 305 182 165 305 minecraft:packed_ice
setblock 182 164 309 minecraft:snow_block
fill 182 164 310 182 167 310 minecraft:packed_ice
setblock 182 164 314 minecraft:snow_block
fill 182 164 315 182 167 315 minecraft:packed_ice
fill 183 164 282 183 165 282 minecraft:blue_ice
setblock 183 164 283 minecraft:packed_ice
setblock 183 164 286 minecraft:packed_ice
fill 183 164 296 183 165 296 minecraft:blue_ice
fill 183 164 302 183 165 302 minecraft:blue_ice
fill 183 164 308 183 165 308 minecraft:blue_ice
setblock 141 165 290 minecraft:blue_ice
setblock 141 165 292 minecraft:blue_ice
setblock 141 165 298 minecraft:blue_ice
setblock 141 165 303 minecraft:blue_ice
setblock 142 165 278 minecraft:snow_block
fill 142 165 279 142 168 279 minecraft:packed_ice
setblock 142 165 283 minecraft:snow_block
fill 142 165 284 142 168 284 minecraft:packed_ice
setblock 142 165 288 minecraft:snow_block
fill 142 165 289 142 167 290 minecraft:packed_ice
setblock 142 165 293 minecraft:snow_block
fill 142 165 294 142 168 294 minecraft:packed_ice
setblock 142 165 298 minecraft:snow_block
setblock 142 165 308 minecraft:snow_block
fill 142 165 309 142 168 309 minecraft:packed_ice
setblock 142 165 313 minecraft:snow_block
fill 142 165 314 142 168 314 minecraft:packed_ice
setblock 143 165 277 minecraft:snow_block
fill 143 165 278 143 168 278 minecraft:packed_ice
setblock 143 165 282 minecraft:snow_block
fill 143 165 283 143 166 283 minecraft:packed_ice
setblock 143 165 287 minecraft:snow_block
fill 143 165 288 143 167 288 minecraft:packed_ice
setblock 143 165 292 minecraft:snow_block
fill 143 165 293 143 168 293 minecraft:packed_ice
setblock 143 165 312 minecraft:snow_block
fill 143 165 313 143 168 313 minecraft:packed_ice
setblock 144 165 276 minecraft:snow_block
fill 144 165 277 144 168 277 minecraft:packed_ice
setblock 144 165 291 minecraft:snow_block
setblock 144 165 312 minecraft:packed_ice
setblock 144 165 316 minecraft:snow_block
fill 145 165 276 145 168 276 minecraft:packed_ice
setblock 145 165 315 minecraft:snow_block
fill 145 165 316 145 168 316 minecraft:packed_ice
setblock 145 165 317 minecraft:white_concrete
setblock 146 165 314 minecraft:snow_block
fill 146 165 315 146 168 315 minecraft:packed_ice
setblock 149 165 276 minecraft:snow_block
setblock 149 165 316 minecraft:snow_block
setblock 150 165 276 minecraft:packed_ice
setblock 150 165 315 minecraft:snow_block
fill 150 165 316 150 168 316 minecraft:packed_ice
fill 151 165 309 151 171 309 minecraft:packed_ice
fill 151 165 315 154 165 315 minecraft:packed_ice
fill 152 165 308 152 171 308 minecraft:packed_ice
setblock 153 165 317 minecraft:blue_ice
setblock 154 165 316 minecraft:snow_block
setblock 155 165 314 minecraft:packed_ice
setblock 155 165 315 minecraft:snow_block
fill 155 165 316 155 168 316 minecraft:packed_ice
setblock 156 165 314 minecraft:snow_block
fill 156 165 315 156 168 315 minecraft:packed_ice
fill 157 165 275 158 165 275 minecraft:blue_ice
fill 157 165 314 160 165 314 minecraft:packed_ice
fill 158 165 313 158 167 313 minecraft:packed_ice
setblock 158 165 317 minecraft:blue_ice
setblock 159 165 276 minecraft:snow_block
setblock 159 165 316 minecraft:snow_block
fill 160 165 276 160 168 276 minecraft:packed_ice
setblock 160 165 315 minecraft:snow_block
fill 160 165 316 160 168 316 minecraft:packed_ice
setblock 161 165 314 minecraft:snow_block
fill 161 165 315 161 168 315 minecraft:packed_ice
setblock 162 165 275 minecraft:blue_ice
setblock 162 165 313 minecraft:snow_block
fill 162 165 314 162 168 314 minecraft:packed_ice
setblock 163 165 313 minecraft:packed_ice
setblock 164 165 276 minecraft:snow_block
setblock 164 165 316 minecraft:snow_block
setblock 165 165 315 minecraft:snow_block
fill 165 165 316 165 168 316 minecraft:packed_ice
fill 166 165 315 166 166 315 minecraft:packed_ice
setblock 168 165 275 minecraft:blue_ice
setblock 173 165 307 minecraft:snow_block
setblock 176 165 275 minecraft:blue_ice
setblock 178 165 275 minecraft:blue_ice
setblock 178 165 276 minecraft:packed_ice
setblock 178 165 317 minecraft:blue_ice
setblock 179 165 276 minecraft:snow_block
setblock 179 165 290 minecraft:packed_ice
setblock 179 165 291 minecraft:snow_block
fill 179 165 292 179 168 292 minecraft:packed_ice
setblock 179 165 315 minecraft:packed_ice
setblock 179 165 316 minecraft:snow_block
fill 180 165 276 180 168 276 minecraft:packed_ice
setblock 180 165 285 minecraft:snow_block
fill 180 165 286 180 166 286 minecraft:packed_ice
setblock 180 165 290 minecraft:snow_block
fill 180 165 291 180 168 291 minecraft:packed_ice
setblock 180 165 295 minecraft:snow_block
fill 180 165 296 180 168 296 minecraft:packed_ice
setblock 180 165 315 minecraft:snow_block
fill 180 165 316 180 168 316 minecraft:packed_ice
setblock 181 165 278 minecraft:packed_ice
setblock 181 165 280 minecraft:packed_ice
setblock 181 165 284 minecraft:snow_block
fill 181 165 285 181 168 285 minecraft:packed_ice
setblock 181 165 289 minecraft:snow_block
fill 181 165 290 181 168 290 minecraft:packed_ice
setblock 181 165 294 minecraft:snow_block
fill 181 165 295 181 168 295 minecraft:packed_ice
setblock 181 165 299 minecraft:snow_block
setblock 181 165 309 minecraft:snow_block
setblock 181 165 310 minecraft:packed_ice
setblock 181 165 314 minecraft:snow_block
fill 181 165 315 181 168 315 minecraft:packed_ice
setblock 182 165 275 minecraft:blue_ice
setblock 182 165 278 minecraft:snow_block
fill 182 165 279 182 168 279 minecraft:packed_ice
setblock 182 165 283 minecraft:snow_block
fill 182 165 284 182 168 284 minecraft:packed_ice
setblock 182 165 288 minecraft:snow_block
fill 182 165 289 182 168 289 minecraft:packed_ice
setblock 182 165 293 minecraft:snow_block
fill 182 165 294 182 168 294 minecraft:packed_ice
setblock 182 165 298 minecraft:snow_block
fill 182 165 299 182 168 299 minecraft:packed_ice
setblock 182 165 303 minecraft:snow_block
setblock 182 165 304 minecraft:packed_ice
setblock 182 165 308 minecraft:snow_block
fill 182 165 309 182 167 309 minecraft:packed_ice
setblock 182 165 313 minecraft:snow_block
fill 182 165 314 182 168 314 minecraft:packed_ice
setblock 183 165 283 minecraft:blue_ice
setblock 183 165 286 minecraft:blue_ice
setblock 183 165 299 minecraft:blue_ice
setblock 183 165 310 minecraft:light_blue_concrete
fill 141 166 276 141 166 278 minecraft:packed_ice
fill 141 166 279 141 167 279 minecraft:blue_ice
fill 141 166 280 141 166 294 minecraft:packed_ice
fill 141 166 296 141 166 298 minecraft:packed_ice
fill 141 166 300 141 237 300 minecraft:packed_ice
fill 141 166 302 141 166 313 minecraft:packed_ice
fill 141 166 315 141 167 315 minecraft:packed_ice
fill 141 166 317 147 166 317 minecraft:packed_ice
fill 142 166 275 149 167 275 minecraft:packed_ice
setblock 142 166 277 minecraft:snow_block
fill 142 166 278 142 169 278 minecraft:packed_ice
setblock 142 166 282 minecraft:snow_block
fill 142 166 283 142 169 283 minecraft:packed_ice
setblock 142 166 286 minecraft:packed_ice
setblock 142 166 287 minecraft:snow_block
fill 142 166 288 142 169 288 minecraft:packed_ice
setblock 142 166 291 minecraft:packed_ice
setblock 142 166 292 minecraft:snow_block
fill 142 166 293 142 169 293 minecraft:packed_ice
setblock 142 166 297 minecraft:snow_block
fill 142 166 298 142 169 298 minecraft:packed_ice
setblock 142 166 307 minecraft:snow_block
fill 142 166 308 142 167 308 minecraft:packed_ice
setblock 142 166 312 minecraft:snow_block
fill 142 166 313 142 169 313 minecraft:packed_ice
setblock 143 166 276 minecraft:snow_block
fill 143 166 277 143 169 277 minecraft:packed_ice
setblock 143 166 281 minecraft:snow_block
setblock 143 166 282 minecraft:packed_ice
setblock 143 166 286 minecraft:snow_block
fill 143 166 287 143 167 287 minecraft:packed_ice
setblock 143 166 291 minecraft:snow_block
fill 143 166 292 143 168 292 minecraft:packed_ice
setblock 143 166 311 minecraft:snow_block
fill 143 166 312 143 169 312 minecraft:packed_ice
setblock 143 166 316 minecraft:snow_block
fill 144 166 276 144 169 276 minecraft:packed_ice
setblock 144 166 315 minecraft:snow_block
fill 144 166 316 144 169 316 minecraft:packed_ice
setblock 145 166 314 minecraft:snow_block
fill 145 166 315 145 169 315 minecraft:packed_ice
setblock 148 166 276 minecraft:snow_block
setblock 148 166 316 minecraft:snow_block
fill 149 166 276 149 169 276 minecraft:packed_ice
setblock 149 166 315 minecraft:snow_block
fill 149 166 316 149 169 316 minecraft:packed_ice
setblock 150 166 275 minecraft:blue_ice
fill 150 166 315 153 166 315 minecraft:packed_ice
fill 150 166 317 150 238 317 minecraft:packed_ice
fill 151 166 275 151 167 275 minecraft:packed_ice
fill 151 166 308 151 171 308 minecraft:packed_ice
setblock 152 166 275 minecraft:blue_ice
fill 152 166 310 152 171 310 minecraft:packed_ice
fill 152 166 317 159 179 317 minecraft:packed_ice
fill 153 166 275 163 166 275 minecraft:packed_ice
fill 153 166 309 153 171 309 minecraft:packed_ice
setblock 153 166 316 minecraft:snow_block
setblock 154 166 315 minecraft:snow_block
fill 154 166 316 154 169 316 minecraft:packed_ice
fill 155 166 276 155 168 276 minecraft:packed_ice
setblock 155 166 314 minecraft:snow_block
fill 155 166 315 155 169 315 minecraft:packed_ice
fill 156 166 314 159 166 314 minecraft:packed_ice
setblock 157 166 276 minecraft:packed_ice
setblock 158 166 276 minecraft:snow_block
setblock 158 166 316 minecraft:snow_block
fill 159 166 276 159 169 276 minecraft:packed_ice
setblock 159 166 315 minecraft:snow_block
fill 159 166 316 159 169 316 minecraft:packed_ice
setblock 160 166 314 minecraft:snow_block
fill 160 166 315 160 169 315 minecraft:packed_ice
setblock 161 166 313 minecraft:snow_block
fill 161 166 314 161 169 314 minecraft:packed_ice
setblock 161 166 317 minecraft:blue_ice
setblock 162 166 313 minecraft:packed_ice
fill 162 166 317 163 217 317 minecraft:packed_ice
setblock 163 166 276 minecraft:snow_block
setblock 163 166 316 minecraft:snow_block
setblock 164 166 315 minecraft:snow_block
fill 164 166 316 164 169 316 minecraft:packed_ice
fill 165 166 275 172 167 275 minecraft:packed_ice
fill 165 166 315 165 168 315 minecraft:packed_ice
fill 165 166 317 165 187 317 minecraft:packed_ice
setblock 166 166 317 minecraft:blue_ice
fill 167 166 317 174 166 317 minecraft:packed_ice
setblock 168 166 316 minecraft:snow_block
fill 174 166 275 174 186 275 minecraft:packed_ice
setblock 175 166 275 minecraft:blue_ice
setblock 175 166 317 minecraft:blue_ice
fill 176 166 275 183 167 275 minecraft:packed_ice
fill 176 166 317 180 172 317 minecraft:packed_ice
fill 177 166 281 177 167 281 minecraft:packed_ice
setblock 178 166 276 minecraft:snow_block
fill 178 166 280 178 167 280 minecraft:packed_ice
fill 178 166 282 178 167 282 minecraft:packed_ice
setblock 178 166 316 minecraft:snow_block
fill 179 166 276 179 169 276 minecraft:packed_ice
fill 179 166 281 179 167 281 minecraft:packed_ice
setblock 179 166 290 minecraft:snow_block
fill 179 166 291 179 167 291 minecraft:packed_ice
fill 179 166 298 180 167 298 minecraft:packed_ice
setblock 179 166 315 minecraft:snow_block
fill 179 166 316 179 169 316 minecraft:packed_ice
setblock 180 166 289 minecraft:snow_block
fill 180 166 290 180 169 290 minecraft:packed_ice
setblock 180 166 294 minecraft:snow_block
fill 180 166 295 180 169 295 minecraft:packed_ice
fill 180 166 299 181 166 299 minecraft:packed_ice
fill 180 166 315 180 169 315 minecraft:packed_ice
setblock 181 166 278 minecraft:snow_block
setblock 181 166 283 minecraft:snow_block
fill 181 166 284 181 169 284 minecraft:packed_ice
setblock 181 166 288 minecraft:snow_block
fill 181 166 289 181 169 289 minecraft:packed_ice
setblock 181 166 293 minecraft:snow_block
fill 181 166 294 181 169 294 minecraft:packed_ice
setblock 181 166 298 minecraft:snow_block
setblock 181 166 300 minecraft:packed_ice
setblock 181 166 313 minecraft:snow_block
fill 181 166 314 181 169 314 minecraft:packed_ice
setblock 182 166 277 minecraft:snow_block
fill 182 166 278 183 169 278 minecraft:packed_ice
setblock 182 166 282 minecraft:snow_block
fill 182 166 283 183 169 283 minecraft:packed_ice
setblock 182 166 287 minecraft:snow_block
fill 182 166 288 183 169 288 minecraft:packed_ice
setblock 182 166 292 minecraft:snow_block
fill 182 166 293 182 169 293 minecraft:packed_ice
setblock 182 166 297 minecraft:snow_block
fill 182 166 298 183 167 298 minecraft:packed_ice
setblock 182 166 307 minecraft:snow_block
fill 182 166 308 183 166 308 minecraft:packed_ice
setblock 182 166 312 minecraft:snow_block
fill 182 166 313 183 169 313 minecraft:packed_ice
fill 182 166 317 183 199 317 minecraft:packed_ice
fill 183 166 276 183 167 277 minecraft:packed_ice
fill 183 166 279 183 207 282 minecraft:packed_ice
fill 183 166 284 183 166 287 minecraft:packed_ice
fill 183 166 289 183 167 292 minecraft:packed_ice
fill 183 166 293 183 167 293 minecraft:blue_ice
fill 183 166 294 183 226 297 minecraft:packed_ice
fill 183 166 299 183 167 299 minecraft:packed_ice
fill 183 166 301 183 166 305 minecraft:packed_ice
setblock 183 166 306 minecraft:blue_ice
fill 183 166 307 183 237 307 minecraft:packed_ice
fill 183 166 309 183 167 312 minecraft:packed_ice
fill 183 166 314 183 189 315 minecraft:packed_ice
fill 141 167 276 141 237 276 minecraft:packed_ice
setblock 141 167 277 minecraft:blue_ice
setblock 141 167 278 minecraft:packed_ice
fill 141 167 280 141 167 281 minecraft:blue_ice
fill 141 167 282 141 183 285 minecraft:packed_ice
setblock 141 167 286 minecraft:blue_ice
fill 141 167 287 141 167 297 minecraft:packed_ice
setblock 141 167 298 minecraft:blue_ice
fill 141 167 299 141 216 299 minecraft:packed_ice
fill 141 167 301 141 237 301 minecraft:packed_ice
setblock 141 167 302 minecraft:blue_ice
fill 141 167 303 141 177 313 minecraft:packed_ice
setblock 141 167 317 minecraft:blue_ice
setblock 142 167 276 minecraft:snow_block
fill 142 167 277 142 170 277 minecraft:packed_ice
setblock 142 167 281 minecraft:snow_block
fill 142 167 282 142 170 282 minecraft:packed_ice
setblock 142 167 286 minecraft:snow_block
fill 142 167 287 142 170 287 minecraft:packed_ice
setblock 142 167 291 minecraft:snow_block
fill 142 167 292 142 170 292 minecraft:packed_ice
setblock 142 167 296 minecraft:snow_block
fill 142 167 297 142 170 297 minecraft:packed_ice
setblock 142 167 311 minecraft:snow_block
fill 142 167 312 142 170 312 minecraft:packed_ice
setblock 142 167 316 minecraft:snow_block
setblock 142 167 317 minecraft:packed_ice
fill 143 167 276 143 170 276 minecraft:packed_ice
setblock 143 167 290 minecraft:snow_block
fill 143 167 291 143 168 291 minecraft:packed_ice
setblock 143 167 311 minecraft:packed_ice
setblock 143 167 315 minecraft:snow_block
fill 143 167 316 143 170 316 minecraft:packed_ice
fill 143 167 317 143 168 317 minecraft:blue_ice
fill 144 167 315 144 170 315 minecraft:packed_ice
fill 144 167 317 149 167 317 minecraft:packed_ice
setblock 147 167 276 minecraft:snow_block
setblock 147 167 316 minecraft:snow_block
fill 148 167 276 148 170 276 minecraft:packed_ice
setblock 148 167 315 minecraft:snow_block
fill 148 167 316 148 170 316 minecraft:packed_ice
fill 149 167 315 152 167 315 minecraft:packed_ice
fill 150 167 275 150 237 275 minecraft:packed_ice
fill 150 167 309 150 171 309 minecraft:packed_ice
fill 151 167 310 151 171 310 minecraft:packed_ice
fill 151 167 317 151 182 317 minecraft:packed_ice
fill 152 167 275 155 167 275 minecraft:packed_ice
fill 152 167 307 152 171 307 minecraft:packed_ice
setblock 152 167 316 minecraft:snow_block
fill 153 167 308 153 171 308 minecraft:packed_ice
fill 153 167 310 153 171 310 minecraft:packed_ice
setblock 153 167 315 minecraft:snow_block
fill 153 167 316 153 170 316 minecraft:packed_ice
fill 154 167 276 154 169 276 minecraft:packed_ice
fill 154 167 315 154 170 315 minecraft:packed_ice
fill 155 167 314 158 167 314 minecraft:packed_ice
setblock 156 167 275 minecraft:light_blue_concrete
fill 157 167 275 164 196 275 minecraft:packed_ice
setblock 157 167 276 minecraft:snow_block
setblock 157 167 316 minecraft:snow_block
fill 158 167 276 158 170 276 minecraft:packed_ice
setblock 158 167 315 minecraft:snow_block
fill 158 167 316 158 170 316 minecraft:packed_ice
setblock 159 167 314 minecraft:snow_block
fill 159 167 315 159 170 315 minecraft:packed_ice
setblock 160 167 313 minecraft:snow_block
fill 160 167 314 160 170 314 minecraft:packed_ice
setblock 161 167 313 minecraft:packed_ice
setblock 161 167 317 minecraft:packed_ice
setblock 162 167 276 minecraft:snow_block
setblock 162 167 316 minecraft:snow_block
fill 163 167 276 163 170 276 minecraft:packed_ice
setblock 163 167 315 minecraft:snow_block
fill 163 167 316 163 170 316 minecraft:packed_ice
setblock 164 167 314 minecraft:snow_block
fill 164 167 315 164 169 315 minecraft:packed_ice
fill 164 167 317 164 237 317 minecraft:packed_ice
fill 166 167 317 167 167 317 minecraft:packed_ice
setblock 167 167 316 minecraft:snow_block
setblock 168 167 317 minecraft:blue_ice
fill 169 167 317 169 237 317 minecraft:packed_ice
setblock 170 167 317 minecraft:blue_ice
fill 171 167 317 175 173 317 minecraft:packed_ice
setblock 173 167 275 minecraft:packed_ice
fill 175 167 275 175 237 275 minecraft:packed_ice
setblock 176 167 316 minecraft:packed_ice
setblock 177 167 276 minecraft:snow_block
setblock 177 167 316 minecraft:snow_block
fill 178 167 276 178 170 276 minecraft:packed_ice
fill 178 167 298 178 167 300 minecraft:packed_ice
fill 178 167 316 178 170 316 minecraft:packed_ice
setblock 179 167 290 minecraft:packed_ice
fill 179 167 299 180 167 300 minecraft:packed_ice
fill 179 167 315 179 170 315 minecraft:packed_ice
setblock 180 167 277 minecraft:packed_ice
setblock 180 167 288 minecraft:snow_block
fill 180 167 289 180 170 289 minecraft:packed_ice
setblock 180 167 293 minecraft:snow_block
fill 180 167 294 180 170 294 minecraft:packed_ice
setblock 181 167 276 minecraft:packed_ice
setblock 181 167 277 minecraft:snow_block
fill 181 167 278 181 169 279 minecraft:packed_ice
setblock 181 167 282 minecraft:snow_block
fill 181 167 283 181 170 283 minecraft:packed_ice
setblock 181 167 287 minecraft:snow_block
fill 181 167 288 181 170 288 minecraft:packed_ice
setblock 181 167 292 minecraft:snow_block
fill 181 167 293 181 170 293 minecraft:packed_ice
setblock 181 167 297 minecraft:snow_block
fill 181 167 298 181 170 298 minecraft:packed_ice
setblock 181 167 312 minecraft:snow_block
fill 181 167 313 181 168 313 minecraft:packed_ice
fill 181 167 317 181 238 317 minecraft:packed_ice
setblock 182 167 276 minecraft:snow_block
fill 182 167 277 182 170 277 minecraft:packed_ice
setblock 182 167 281 minecraft:snow_block
fill 182 167 282 182 170 282 minecraft:packed_ice
setblock 182 167 286 minecraft:snow_block
fill 182 167 287 182 170 287 minecraft:packed_ice
setblock 182 167 291 minecraft:snow_block
fill 182 167 292 182 170 292 minecraft:packed_ice
setblock 182 167 296 minecraft:snow_block
fill 182 167 297 182 170 297 minecraft:packed_ice
setblock 182 167 311 minecraft:snow_block
fill 182 167 312 182 170 312 minecraft:packed_ice
setblock 182 167 316 minecraft:snow_block
fill 183 167 284 183 196 286 minecraft:packed_ice
setblock 183 167 287 minecraft:blue_ice
fill 183 167 300 183 167 302 minecraft:packed_ice
setblock 183 167 303 minecraft:blue_ice
fill 183 167 304 183 211 306 minecraft:packed_ice
setblock 183 167 308 minecraft:packed_ice
fill 183 167 316 183 219 316 minecraft:packed_ice
fill 141 168 277 141 237 277 minecraft:packed_ice
setblock 141 168 278 minecraft:blue_ice
fill 141 168 279 141 233 281 minecraft:packed_ice
fill 141 168 286 141 168 290 minecraft:packed_ice
setblock 141 168 291 minecraft:blue_ice
fill 141 168 292 141 197 298 minecraft:packed_ice
fill 141 168 302 141 205 302 minecraft:packed_ice
fill 141 168 314 141 237 314 minecraft:packed_ice
setblock 141 168 315 minecraft:blue_ice
fill 141 168 316 141 222 317 minecraft:packed_ice
setblock 142 168 275 minecraft:blue_ice
fill 142 168 276 142 171 276 minecraft:packed_ice
setblock 142 168 280 minecraft:snow_block
fill 142 168 281 142 171 281 minecraft:packed_ice
setblock 142 168 285 minecraft:snow_block
fill 142 168 286 142 169 286 minecraft:packed_ice
setblock 142 168 289 minecraft:packed_ice
setblock 142 168 290 minecraft:snow_block
fill 142 168 291 142 171 291 minecraft:packed_ice
setblock 142 168 295 minecraft:snow_block
fill 142 168 296 142 171 296 minecraft:packed_ice
setblock 142 168 310 minecraft:snow_block
fill 142 168 311 142 171 311 minecraft:packed_ice
setblock 142 168 315 minecraft:snow_block
fill 142 168 316 142 171 316 minecraft:packed_ice
setblock 142 168 317 minecraft:blue_ice
fill 143 168 275 144 198 275 minecraft:packed_ice
setblock 143 168 279 minecraft:snow_block
setblock 143 168 314 minecraft:snow_block
fill 143 168 315 143 171 315 minecraft:packed_ice
setblock 144 168 278 minecraft:light[level=15]
setblock 144 168 285 minecraft:light[level=12]
setblock 144 168 286 minecraft:light[level=15]
setblock 144 168 292 minecraft:light[level=12]
setblock 144 168 294 minecraft:light[level=15]
setblock 144 168 299 minecraft:light[level=12]
setblock 144 168 302 minecraft:light[level=15]
setblock 144 168 306 minecraft:light[level=12]
setblock 144 168 310 minecraft:light[level=15]
setblock 144 168 313 minecraft:light[level=12]
fill 144 168 317 144 237 317 minecraft:packed_ice
setblock 145 168 275 minecraft:blue_ice
setblock 145 168 317 minecraft:blue_ice
fill 146 168 275 147 234 275 minecraft:packed_ice
setblock 146 168 276 minecraft:snow_block
setblock 146 168 316 minecraft:snow_block
fill 146 168 317 149 170 317 minecraft:packed_ice
fill 147 168 276 147 171 276 minecraft:packed_ice
setblock 147 168 315 minecraft:snow_block
fill 147 168 316 147 171 316 minecraft:packed_ice
setblock 148 168 275 minecraft:white_concrete
fill 148 168 315 151 168 315 minecraft:packed_ice
fill 149 168 275 149 235 275 minecraft:packed_ice
fill 150 168 308 150 171 308 minecraft:packed_ice
fill 150 168 310 150 171 310 minecraft:packed_ice
setblock 151 168 275 minecraft:blue_ice
setblock 151 168 278 minecraft:light[level=12]
setblock 151 168 285 minecraft:light[level=12]
setblock 151 168 292 minecraft:light[level=12]
setblock 151 168 299 minecraft:light[level=12]
setblock 151 168 306 minecraft:light[level=12]
fill 151 168 307 151 171 307 minecraft:packed_ice
setblock 151 168 313 minecraft:light[level=12]
setblock 151 168 316 minecraft:snow_block
fill 152 168 275 153 173 275 minecraft:packed_ice
setblock 152 168 278 minecraft:light[level=15]
setblock 152 168 286 minecraft:light[level=15]
setblock 152 168 294 minecraft:light[level=15]
setblock 152 168 315 minecraft:snow_block
fill 152 168 316 152 171 316 minecraft:packed_ice
fill 153 168 276 153 170 276 minecraft:packed_ice
fill 153 168 307 153 171 307 minecraft:packed_ice
fill 153 168 315 153 171 315 minecraft:packed_ice
setblock 154 168 275 minecraft:blue_ice
fill 154 168 309 154 171 309 minecraft:packed_ice
fill 155 168 275 156 181 275 minecraft:packed_ice
fill 155 168 314 157 168 314 minecraft:packed_ice
setblock 156 168 276 minecraft:snow_block
setblock 156 168 316 minecraft:snow_block
fill 157 168 276 157 171 276 minecraft:packed_ice
setblock 157 168 315 minecraft:snow_block
fill 157 168 316 157 171 316 minecraft:packed_ice
setblock 158 168 278 minecraft:light[level=12]
setblock 158 168 285 minecraft:light[level=12]
setblock 158 168 299 minecraft:light[level=12]
setblock 158 168 306 minecraft:light[level=12]
setblock 158 168 313 minecraft:light[level=12]
setblock 158 168 314 minecraft:snow_block
fill 158 168 315 158 171 315 minecraft:packed_ice
fill 159 168 310 160 169 311 minecraft:snow_block
fill 159 168 314 159 171 314 minecraft:packed_ice
setblock 160 168 278 minecraft:light[level=15]
setblock 160 168 286 minecraft:light[level=15]
setblock 160 168 294 minecraft:light[level=15]
setblock 160 168 302 minecraft:light[level=15]
fill 160 168 317 160 237 317 minecraft:packed_ice
setblock 161 168 276 minecraft:snow_block
setblock 161 168 316 minecraft:snow_block
setblock 161 168 317 minecraft:blue_ice
fill 162 168 276 162 171 276 minecraft:packed_ice
setblock 162 168 315 minecraft:snow_block
fill 162 168 316 162 171 316 minecraft:packed_ice
setblock 163 168 314 minecraft:snow_block
fill 163 168 315 163 171 315 minecraft:packed_ice
fill 165 168 275 171 168 275 minecraft:packed_ice
setblock 165 168 278 minecraft:light[level=12]
setblock 165 168 285 minecraft:light[level=12]
setblock 165 168 292 minecraft:light[level=12]
setblock 165 168 299 minecraft:light[level=12]
setblock 165 168 306 minecraft:light[level=12]
setblock 165 168 313 minecraft:light[level=12]
setblock 166 168 316 minecraft:snow_block
fill 166 168 317 167 168 317 minecraft:blue_ice
setblock 168 168 278 minecraft:light[level=15]
setblock 168 168 286 minecraft:light[level=15]
setblock 168 168 294 minecraft:light[level=15]
setblock 168 168 302 minecraft:light[level=15]
setblock 168 168 310 minecraft:light[level=15]
fill 168 168 317 168 232 317 minecraft:packed_ice
fill 170 168 317 170 237 317 minecraft:packed_ice
setblock 172 168 275 minecraft:light_blue_concrete
setblock 172 168 278 minecraft:light[level=12]
setblock 172 168 285 minecraft:light[level=12]
setblock 172 168 292 minecraft:light[level=12]
setblock 172 168 299 minecraft:light[level=12]
setblock 172 168 306 minecraft:light[level=12]
setblock 172 168 313 minecraft:light[level=12]
setblock 173 168 275 minecraft:blue_ice
fill 176 168 275 177 195 275 minecraft:packed_ice
setblock 176 168 276 minecraft:snow_block
setblock 176 168 278 minecraft:light[level=15]
setblock 176 168 286 minecraft:light[level=15]
setblock 176 168 294 minecraft:light[level=15]
setblock 176 168 302 minecraft:light[level=15]
setblock 176 168 316 minecraft:snow_block
fill 177 168 276 177 171 276 minecraft:packed_ice
fill 177 168 316 177 171 316 minecraft:packed_ice
setblock 178 168 275 minecraft:blue_ice
setblock 179 168 275 minecraft:white_concrete
setblock 179 168 277 minecraft:packed_ice
setblock 179 168 278 minecraft:light[level=12]
setblock 179 168 285 minecraft:light[level=12]
fill 179 168 288 179 171 290 minecraft:blue_ice
setblock 179 168 293 minecraft:snow_block
setblock 179 168 299 minecraft:light[level=12]
setblock 179 168 306 minecraft:light[level=12]
setblock 179 168 313 minecraft:light[level=12]
fill 180 168 275 183 169 275 minecraft:packed_ice
setblock 180 168 277 minecraft:snow_block
setblock 180 168 287 minecraft:snow_block
fill 180 168 288 180 169 288 minecraft:packed_ice
setblock 180 168 292 minecraft:snow_block
fill 180 168 293 180 171 293 minecraft:packed_ice
setblock 181 168 276 minecraft:snow_block
fill 181 168 277 181 171 277 minecraft:packed_ice
setblock 181 168 280 minecraft:packed_ice
setblock 181 168 286 minecraft:snow_block
fill 181 168 287 181 171 287 minecraft:packed_ice
setblock 181 168 291 minecraft:snow_block
fill 181 168 292 181 171 292 minecraft:packed_ice
setblock 181 168 296 minecraft:snow_block
fill 181 168 297 181 171 297 minecraft:packed_ice
setblock 181 168 316 minecraft:snow_block
fill 182 168 276 182 171 276 minecraft:packed_ice
setblock 182 168 280 minecraft:snow_block
fill 182 168 281 182 171 281 minecraft:packed_ice
setblock 182 168 285 minecraft:snow_block
fill 182 168 286 182 171 286 minecraft:packed_ice
setblock 182 168 290 minecraft:snow_block
fill 182 168 291 183 171 291 minecraft:packed_ice
setblock 182 168 295 minecraft:snow_block
fill 182 168 296 182 171 296 minecraft:packed_ice
fill 182 168 298 182 169 298 minecraft:packed_ice
setblock 182 168 300 minecraft:snow_block
setblock 182 168 310 minecraft:snow_block
fill 182 168 311 183 169 311 minecraft:packed_ice
setblock 182 168 315 minecraft:snow_block
fill 182 168 316 182 171 316 minecraft:packed_ice
setblock 183 168 276 minecraft:blue_ice
fill 183 168 277 183 235 277 minecraft:packed_ice
fill 183 168 287 183 237 287 minecraft:packed_ice
setblock 183 168 289 minecraft:blue_ice
fill 183 168 290 183 218 290 minecraft:packed_ice
fill 183 168 292 183 237 293 minecraft:packed_ice
setblock 183 168 298 minecraft:blue_ice
setblock 183 168 299 minecraft:white_concrete
fill 183 168 300 183 233 300 minecraft:packed_ice
setblock 183 168 301 minecraft:white_concrete
fill 183 168 302 183 214 303 minecraft:packed_ice
setblock 183 168 308 minecraft:blue_ice
fill 183 168 309 183 237 310 minecraft:packed_ice
setblock 183 168 312 minecraft:blue_ice
fill 141 169 275 142 234 275 minecraft:packed_ice
fill 141 169 278 141 237 278 minecraft:packed_ice
fill 141 169 286 141 181 286 minecraft:packed_ice
setblock 141 169 287 minecraft:white_concrete
fill 141 169 288 141 174 291 minecraft:packed_ice
fill 141 169 315 142 172 315 minecraft:packed_ice
setblock 142 169 279 minecraft:snow_block
fill 142 169 280 142 172 280 minecraft:packed_ice
setblock 142 169 284 minecraft:snow_block
setblock 142 169 285 minecraft:packed_ice
setblock 142 169 289 minecraft:snow_block
fill 142 169 290 142 171 290 minecraft:packed_ice
setblock 142 169 294 minecraft:snow_block
fill 142 169 295 142 172 295 minecraft:packed_ice
fill 142 169 310 142 171 310 minecraft:packed_ice
setblock 142 169 314 minecraft:snow_block
fill 142 169 317 143 235 317 minecraft:packed_ice
setblock 143 169 278 minecraft:snow_block
fill 143 169 279 143 172 279 minecraft:packed_ice
setblock 143 169 313 minecraft:snow_block
fill 143 169 314 143 172 314 minecraft:packed_ice
setblock 144 169 277 minecraft:snow_block
fill 145 169 275 145 186 275 minecraft:packed_ice
setblock 145 169 276 minecraft:snow_block
setblock 145 169 316 minecraft:snow_block
fill 145 169 317 145 220 317 minecraft:packed_ice
fill 146 169 276 146 172 276 minecraft:packed_ice
setblock 146 169 315 minecraft:snow_block
fill 146 169 316 146 172 316 minecraft:packed_ice
fill 147 169 315 150 169 315 minecraft:packed_ice
fill 148 169 275 148 234 275 minecraft:packed_ice
setblock 150 169 276 minecraft:snow_block
fill 150 169 307 150 171 307 minecraft:packed_ice
setblock 150 169 316 minecraft:snow_block
fill 151 169 275 151 172 276 minecraft:packed_ice
fill 151 169 311 153 171 311 minecraft:packed_ice
setblock 151 169 315 minecraft:snow_block
fill 151 169 316 151 172 316 minecraft:packed_ice
fill 152 169 276 152 171 276 minecraft:packed_ice
fill 152 169 306 152 171 306 minecraft:packed_ice
fill 152 169 315 152 172 315 minecraft:packed_ice
fill 154 169 275 154 235 275 minecraft:packed_ice
fill 154 169 308 154 171 308 minecraft:packed_ice
fill 154 169 310 154 171 310 minecraft:packed_ice
fill 154 169 314 156 169 314 minecraft:packed_ice
setblock 155 169 276 minecraft:snow_block
setblock 155 169 316 minecraft:snow_block
fill 156 169 276 156 172 276 minecraft:packed_ice
setblock 156 169 315 minecraft:snow_block
fill 156 169 316 156 172 316 minecraft:packed_ice
setblock 157 169 314 minecraft:snow_block
fill 157 169 315 157 172 315 minecraft:packed_ice
fill 158 169 314 158 172 314 minecraft:packed_ice
setblock 160 169 276 minecraft:snow_block
setblock 160 169 316 minecraft:snow_block
fill 161 169 276 161 172 276 minecraft:packed_ice
setblock 161 169 315 minecraft:snow_block
fill 161 169 316 161 169 317 minecraft:packed_ice
setblock 162 169 314 minecraft:snow_block
fill 162 169 315 162 172 315 minecraft:packed_ice
fill 165 169 275 166 176 275 minecraft:packed_ice
setblock 165 169 316 minecraft:snow_block
fill 166 169 316 166 170 317 minecraft:packed_ice
setblock 167 169 275 minecraft:white_concrete
fill 167 169 317 167 203 317 minecraft:packed_ice
fill 168 169 275 173 224 275 minecraft:packed_ice
setblock 175 169 276 minecraft:snow_block
setblock 175 169 316 minecraft:snow_block
fill 176 169 276 176 172 276 minecraft:packed_ice
fill 176 169 289 178 171 289 minecraft:blue_ice
fill 176 169 316 176 172 316 minecraft:packed_ice
fill 177 169 277 178 169 277 minecraft:packed_ice
fill 178 169 275 179 237 275 minecraft:packed_ice
fill 178 169 288 178 171 288 minecraft:blue_ice
fill 178 169 290 178 171 290 minecraft:blue_ice
fill 178 169 315 178 171 315 minecraft:packed_ice
setblock 179 169 277 minecraft:snow_block
setblock 179 169 293 minecraft:packed_ice
setblock 180 169 276 minecraft:snow_block
fill 180 169 277 180 172 277 minecraft:packed_ice
fill 180 169 287 180 170 287 minecraft:blue_ice
setblock 180 169 291 minecraft:snow_block
fill 180 169 292 180 172 292 minecraft:packed_ice
setblock 180 169 296 minecraft:snow_block
fill 180 169 297 180 172 297 minecraft:packed_ice
setblock 180 169 316 minecraft:snow_block
fill 181 169 276 181 172 276 minecraft:packed_ice
setblock 181 169 280 minecraft:snow_block
fill 181 169 281 181 171 282 minecraft:packed_ice
setblock 181 169 285 minecraft:snow_block
fill 181 169 286 181 172 286 minecraft:packed_ice
setblock 181 169 290 minecraft:snow_block
fill 181 169 291 181 172 291 minecraft:packed_ice
setblock 181 169 295 minecraft:snow_block
fill 181 169 296 181 172 296 minecraft:packed_ice
setblock 181 169 315 minecraft:snow_block
fill 181 169 316 181 172 316 minecraft:packed_ice
setblock 182 169 279 minecraft:snow_block
fill 182 169 280 182 172 280 minecraft:packed_ice
setblock 182 169 284 minecraft:snow_block
fill 182 169 285 182 172 285 minecraft:packed_ice
setblock 182 169 289 minecraft:snow_block
fill 182 169 290 182 172 290 minecraft:packed_ice
setblock 182 169 294 minecraft:snow_block
fill 182 169 295 182 172 295 minecraft:packed_ice
setblock 182 169 299 minecraft:snow_block
fill 182 169 300 182 172 300 minecraft:packed_ice
setblock 182 169 314 minecraft:snow_block
fill 182 169 315 182 172 315 minecraft:packed_ice
fill 183 169 276 183 172 276 minecraft:packed_ice
fill 183 169 289 183 234 289 minecraft:packed_ice
fill 183 169 298 183 237 299 minecraft:packed_ice
fill 183 169 301 183 237 301 minecraft:packed_ice
fill 183 169 308 183 174 308 minecraft:packed_ice
fill 183 169 312 183 200 312 minecraft:packed_ice
fill 141 170 287 141 237 287 minecraft:packed_ice
setblock 142 170 278 minecraft:snow_block
fill 142 170 279 142 173 279 minecraft:packed_ice
setblock 142 170 283 minecraft:snow_block
setblock 142 170 284 minecraft:packed_ice
setblock 142 170 288 minecraft:snow_block
fill 142 170 289 142 171 289 minecraft:packed_ice
setblock 142 170 293 minecraft:snow_block
fill 142 170 294 142 173 294 minecraft:packed_ice
setblock 142 170 298 minecraft:snow_block
setblock 142 170 313 minecraft:snow_block
fill 142 170 314 142 173 314 minecraft:packed_ice
setblock 143 170 277 minecraft:snow_block
fill 143 170 278 143 173 278 minecraft:packed_ice
fill 143 170 313 143 173 313 minecraft:packed_ice
setblock 144 170 276 minecraft:snow_block
fill 144 170 277 145 172 277 minecraft:packed_ice
setblock 144 170 316 minecraft:snow_block
fill 145 170 276 145 173 276 minecraft:packed_ice
setblock 145 170 315 minecraft:snow_block
fill 145 170 316 145 173 316 minecraft:packed_ice
fill 146 170 315 149 170 315 minecraft:packed_ice
setblock 149 170 276 minecraft:snow_block
fill 149 170 308 149 171 310 minecraft:packed_ice
setblock 149 170 316 minecraft:snow_block
fill 150 170 276 150 173 276 minecraft:packed_ice
fill 150 170 311 150 171 311 minecraft:packed_ice
setblock 150 170 315 minecraft:snow_block
fill 150 170 316 150 173 316 minecraft:packed_ice
fill 151 170 306 151 171 306 minecraft:packed_ice
fill 151 170 315 151 173 315 minecraft:packed_ice
fill 153 170 306 153 171 306 minecraft:packed_ice
setblock 154 170 276 minecraft:snow_block
fill 154 170 307 154 171 307 minecraft:packed_ice
fill 154 170 311 154 171 311 minecraft:packed_ice
fill 154 170 314 155 170 314 minecraft:packed_ice
setblock 154 170 316 minecraft:snow_block
fill 155 170 276 155 173 276 minecraft:packed_ice
setblock 155 170 315 minecraft:snow_block
fill 155 170 316 155 173 316 minecraft:packed_ice
setblock 156 170 314 minecraft:snow_block
fill 156 170 315 156 173 315 minecraft:packed_ice
fill 157 170 314 157 173 314 minecraft:packed_ice
setblock 159 170 276 minecraft:snow_block
setblock 159 170 316 minecraft:snow_block
fill 160 170 276 160 173 276 minecraft:packed_ice
setblock 160 170 315 minecraft:snow_block
fill 160 170 316 161 172 316 minecraft:packed_ice
setblock 161 170 314 minecraft:snow_block
fill 161 170 315 161 173 315 minecraft:packed_ice
setblock 161 170 317 minecraft:white_concrete
setblock 164 170 316 minecraft:snow_block
fill 165 170 316 165 173 316 minecraft:packed_ice
fill 166 170 311 166 180 311 minecraft:packed_ice
fill 167 170 275 167 215 275 minecraft:packed_ice
fill 169 170 283 170 171 284 minecraft:white_concrete
setblock 174 170 276 minecraft:snow_block
setblock 174 170 316 minecraft:snow_block
fill 175 170 276 175 173 276 minecraft:packed_ice
fill 175 170 289 175 171 289 minecraft:blue_ice
fill 175 170 316 175 173 316 minecraft:packed_ice
fill 176 170 277 177 170 277 minecraft:packed_ice
fill 176 170 288 177 171 288 minecraft:blue_ice
fill 176 170 290 177 171 290 minecraft:blue_ice
fill 177 170 315 177 172 315 minecraft:packed_ice
setblock 178 170 277 minecraft:snow_block
setblock 179 170 276 minecraft:snow_block
fill 179 170 277 179 173 277 minecraft:packed_ice
setblock 179 170 287 minecraft:blue_ice
setblock 179 170 291 minecraft:blue_ice
setblock 179 170 316 minecraft:snow_block
fill 180 170 275 180 173 276 minecraft:packed_ice
fill 180 170 288 180 171 288 minecraft:blue_ice
setblock 180 170 290 minecraft:snow_block
fill 180 170 291 180 173 291 minecraft:packed_ice
setblock 180 170 295 minecraft:snow_block
fill 180 170 296 180 173 296 minecraft:packed_ice
setblock 180 170 315 minecraft:snow_block
fill 180 170 316 180 173 316 minecraft:packed_ice
fill 181 170 275 181 193 275 minecraft:packed_ice
setblock 181 170 278 minecraft:packed_ice
setblock 181 170 279 minecraft:snow_block
fill 181 170 280 181 173 280 minecraft:packed_ice
setblock 181 170 284 minecraft:snow_block
fill 181 170 285 181 173 285 minecraft:packed_ice
setblock 181 170 289 minecraft:snow_block
fill 181 170 290 181 173 290 minecraft:packed_ice
setblock 181 170 294 minecraft:snow_block
fill 181 170 295 181 173 295 minecraft:packed_ice
setblock 181 170 299 minecraft:snow_block
setblock 181 170 314 minecraft:snow_block
fill 181 170 315 181 173 315 minecraft:packed_ice
setblock 182 170 275 minecraft:light_blue_concrete
setblock 182 170 278 minecraft:snow_block
fill 182 170 279 182 173 279 minecraft:packed_ice
setblock 182 170 283 minecraft:snow_block
fill 182 170 284 182 173 284 minecraft:packed_ice
setblock 182 170 288 minecraft:snow_block
fill 182 170 289 182 173 289 minecraft:packed_ice
setblock 182 170 293 minecraft:snow_block
fill 182 170 294 182 173 294 minecraft:packed_ice
setblock 182 170 298 minecraft:snow_block
fill 182 170 299 182 173 299 minecraft:packed_ice
setblock 182 170 313 minecraft:snow_block
fill 182 170 314 182 173 314 minecraft:packed_ice
fill 183 170 275 183 237 275 minecraft:packed_ice
fill 183 170 278 183 171 278 minecraft:packed_ice
fill 183 170 283 183 180 283 minecraft:packed_ice
fill 183 170 288 183 237 288 minecraft:packed_ice
fill 183 170 311 183 237 311 minecraft:packed_ice
fill 183 170 313 183 235 313 minecraft:packed_ice
setblock 142 171 277 minecraft:snow_block
fill 142 171 278 142 174 278 minecraft:packed_ice
setblock 142 171 282 minecraft:snow_block
fill 142 171 283 142 174 283 minecraft:packed_ice
setblock 142 171 292 minecraft:snow_block
fill 142 171 293 142 174 293 minecraft:packed_ice
setblock 142 171 297 minecraft:snow_block
fill 142 171 298 142 173 299 minecraft:packed_ice
setblock 142 171 312 minecraft:snow_block
fill 142 171 313 142 174 313 minecraft:packed_ice
setblock 143 171 276 minecraft:snow_block
fill 143 171 277 143 174 277 minecraft:packed_ice
setblock 143 171 316 minecraft:snow_block
fill 144 171 276 144 174 276 minecraft:packed_ice
setblock 144 171 315 minecraft:snow_block
fill 144 171 316 144 174 316 minecraft:packed_ice
fill 145 171 315 148 171 315 minecraft:packed_ice
setblock 146 171 317 minecraft:light_blue_concrete
fill 147 171 317 149 172 317 minecraft:packed_ice
setblock 148 171 276 minecraft:snow_block
setblock 148 171 316 minecraft:snow_block
fill 149 171 276 149 174 276 minecraft:packed_ice
setblock 149 171 307 minecraft:packed_ice
setblock 149 171 311 minecraft:packed_ice
setblock 149 171 315 minecraft:snow_block
fill 149 171 316 149 174 316 minecraft:packed_ice
setblock 150 171 306 minecraft:packed_ice
fill 150 171 315 150 174 315 minecraft:packed_ice
fill 151 171 312 153 171 312 minecraft:packed_ice
setblock 153 171 276 minecraft:snow_block
fill 153 171 314 154 171 314 minecraft:packed_ice
setblock 153 171 316 minecraft:snow_block
fill 154 171 276 154 174 276 minecraft:packed_ice
setblock 154 171 306 minecraft:packed_ice
setblock 154 171 315 minecraft:snow_block
fill 154 171 316 154 174 316 minecraft:packed_ice
fill 155 171 277 156 171 277 minecraft:packed_ice
fill 155 171 307 155 171 310 minecraft:packed_ice
setblock 155 171 314 minecraft:snow_block
fill 155 171 315 155 174 315 minecraft:packed_ice
fill 156 171 314 156 174 314 minecraft:packed_ice
setblock 157 171 277 minecraft:snow_block
setblock 158 171 276 minecraft:snow_block
fill 158 171 277 159 173 277 minecraft:packed_ice
setblock 158 171 316 minecraft:snow_block
fill 159 171 276 159 174 276 minecraft:packed_ice
setblock 159 171 315 minecraft:snow_block
fill 159 171 316 159 174 316 minecraft:packed_ice
setblock 160 171 314 minecraft:snow_block
fill 160 171 315 160 174 315 minecraft:packed_ice
setblock 161 171 314 minecraft:packed_ice
fill 161 171 317 161 235 317 minecraft:packed_ice
setblock 163 171 276 minecraft:snow_block
setblock 163 171 316 minecraft:snow_block
fill 164 171 316 164 174 316 minecraft:packed_ice
fill 166 171 317 166 216 317 minecraft:packed_ice
setblock 172 171 276 minecraft:packed_ice
setblock 173 171 276 minecraft:snow_block
setblock 173 171 316 minecraft:snow_block
fill 174 171 276 174 174 276 minecraft:packed_ice
setblock 174 171 289 minecraft:blue_ice
fill 174 171 316 174 174 316 minecraft:packed_ice
fill 175 171 277 176 171 277 minecraft:packed_ice
setblock 177 171 277 minecraft:snow_block
setblock 178 171 276 minecraft:snow_block
fill 178 171 277 178 173 278 minecraft:packed_ice
setblock 178 171 316 minecraft:snow_block
fill 179 171 276 179 174 276 minecraft:packed_ice
fill 179 171 278 180 171 278 minecraft:packed_ice
setblock 179 171 294 minecraft:packed_ice
setblock 179 171 315 minecraft:snow_block
fill 179 171 316 179 174 316 minecraft:packed_ice
setblock 180 171 279 minecraft:snow_block
setblock 180 171 289 minecraft:blue_ice
fill 180 171 290 180 172 290 minecraft:packed_ice
setblock 180 171 294 minecraft:snow_block
fill 180 171 295 180 174 295 minecraft:packed_ice
setblock 180 171 298 minecraft:packed_ice
fill 180 171 315 180 174 315 minecraft:packed_ice
setblock 181 171 278 minecraft:snow_block
fill 181 171 279 181 174 279 minecraft:packed_ice
setblock 181 171 283 minecraft:snow_block
fill 181 171 284 181 174 284 minecraft:packed_ice
setblock 181 171 288 minecraft:snow_block
fill 181 171 289 181 174 289 minecraft:packed_ice
setblock 181 171 293 minecraft:snow_block
fill 181 171 294 181 174 294 minecraft:packed_ice
setblock 181 171 298 minecraft:snow_block
fill 181 171 299 181 174 299 minecraft:packed_ice
setblock 181 171 314 minecraft:packed_ice
fill 182 171 275 182 234 275 minecraft:packed_ice
setblock 182 171 277 minecraft:snow_block
fill 182 171 278 182 174 278 minecraft:packed_ice
setblock 182 171 282 minecraft:snow_block
fill 182 171 283 182 174 283 minecraft:packed_ice
setblock 182 171 287 minecraft:snow_block
fill 182 171 288 182 174 288 minecraft:packed_ice
setblock 182 171 292 minecraft:snow_block
fill 182 171 293 182 174 293 minecraft:packed_ice
setblock 182 171 297 minecraft:snow_block
fill 182 171 298 182 174 298 minecraft:packed_ice
setblock 182 171 301 minecraft:packed_ice
setblock 182 171 312 minecraft:snow_block
fill 182 171 313 182 174 313 minecraft:packed_ice
setblock 142 172 276 minecraft:snow_block
fill 142 172 277 142 175 277 minecraft:packed_ice
setblock 142 172 281 minecraft:snow_block
fill 142 172 282 142 175 282 minecraft:packed_ice
fill 142 172 284 142 173 284 minecraft:packed_ice
setblock 142 172 291 minecraft:snow_block
fill 142 172 292 142 173 292 minecraft:packed_ice
setblock 142 172 296 minecraft:snow_block
fill 142 172 297 142 175 297 minecraft:packed_ice
setblock 142 172 300 minecraft:packed_ice
setblock 142 172 311 minecraft:snow_block
fill 142 172 312 142 175 312 minecraft:packed_ice
setblock 142 172 316 minecraft:snow_block
fill 143 172 276 143 175 276 minecraft:packed_ice
setblock 143 172 280 minecraft:snow_block
setblock 143 172 315 minecraft:snow_block
fill 143 172 316 143 175 316 minecraft:packed_ice
fill 144 172 315 147 172 315 minecraft:packed_ice
setblock 146 172 277 minecraft:snow_block
fill 146 172 317 146 225 317 minecraft:packed_ice
setblock 147 172 276 minecraft:snow_block
setblock 147 172 316 minecraft:snow_block
fill 148 172 276 148 175 276 minecraft:packed_ice
setblock 148 172 315 minecraft:snow_block
fill 148 172 316 148 175 316 minecraft:packed_ice
fill 149 172 315 149 175 315 minecraft:packed_ice
fill 151 172 308 152 172 309 minecraft:blue_ice
setblock 152 172 276 minecraft:snow_block
fill 152 172 277 155 172 277 minecraft:packed_ice
setblock 152 172 316 minecraft:snow_block
fill 153 172 276 153 175 276 minecraft:packed_ice
setblock 153 172 309 minecraft:blue_ice
setblock 153 172 314 minecraft:packed_ice
setblock 153 172 315 minecraft:snow_block
fill 153 172 316 153 175 316 minecraft:packed_ice
setblock 154 172 314 minecraft:snow_block
fill 154 172 315 154 175 315 minecraft:packed_ice
fill 155 172 314 155 175 314 minecraft:packed_ice
setblock 156 172 277 minecraft:snow_block
setblock 157 172 276 minecraft:snow_block
fill 157 172 277 157 175 277 minecraft:packed_ice
setblock 157 172 316 minecraft:snow_block
fill 158 172 276 158 175 276 minecraft:packed_ice
setblock 158 172 315 minecraft:snow_block
fill 158 172 316 158 175 316 minecraft:packed_ice
setblock 159 172 314 minecraft:snow_block
fill 159 172 315 159 175 315 minecraft:packed_ice
setblock 160 172 277 minecraft:packed_ice
fill 160 172 314 160 173 314 minecraft:packed_ice
setblock 162 172 276 minecraft:snow_block
setblock 162 172 316 minecraft:snow_block
fill 163 172 276 164 174 276 minecraft:packed_ice
setblock 163 172 315 minecraft:snow_block
fill 163 172 316 163 175 316 minecraft:packed_ice
setblock 171 172 276 minecraft:packed_ice
setblock 172 172 276 minecraft:snow_block
setblock 172 172 316 minecraft:snow_block
fill 173 172 276 173 174 277 minecraft:packed_ice
fill 173 172 316 173 175 316 minecraft:packed_ice
fill 174 172 277 175 172 277 minecraft:packed_ice
setblock 176 172 277 minecraft:snow_block
fill 176 172 278 177 174 278 minecraft:packed_ice
fill 176 172 315 176 173 315 minecraft:packed_ice
setblock 177 172 276 minecraft:snow_block
fill 177 172 277 177 175 277 minecraft:packed_ice
setblock 177 172 316 minecraft:snow_block
fill 178 172 276 178 175 276 minecraft:packed_ice
setblock 178 172 315 minecraft:snow_block
fill 178 172 316 178 175 316 minecraft:packed_ice
setblock 179 172 278 minecraft:packed_ice
fill 179 172 315 179 175 315 minecraft:packed_ice
setblock 180 172 278 minecraft:snow_block
fill 180 172 279 180 173 281 minecraft:packed_ice
setblock 180 172 293 minecraft:snow_block
fill 180 172 294 180 174 294 minecraft:packed_ice
setblock 180 172 298 minecraft:snow_block
setblock 181 172 277 minecraft:snow_block
fill 181 172 278 181 175 278 minecraft:packed_ice
setblock 181 172 281 minecraft:packed_ice
setblock 181 172 282 minecraft:snow_block
fill 181 172 283 181 175 283 minecraft:packed_ice
setblock 181 172 287 minecraft:snow_block
fill 181 172 288 181 174 288 minecraft:packed_ice
setblock 181 172 292 minecraft:snow_block
fill 181 172 293 181 175 293 minecraft:packed_ice
setblock 181 172 297 minecraft:snow_block
fill 181 172 298 181 175 298 minecraft:packed_ice
fill 181 172 300 181 173 300 minecraft:packed_ice
setblock 182 172 276 minecraft:snow_block
fill 182 172 277 182 175 277 minecraft:packed_ice
setblock 182 172 281 minecraft:snow_block
fill 182 172 282 182 175 282 minecraft:packed_ice
setblock 182 172 286 minecraft:snow_block
fill 182 172 287 182 175 287 minecraft:packed_ice
setblock 182 172 291 minecraft:snow_block
fill 182 172 292 182 175 292 minecraft:packed_ice
setblock 182 172 296 minecraft:snow_block
fill 182 172 297 182 175 297 minecraft:packed_ice
setblock 182 172 301 minecraft:snow_block
setblock 182 172 316 minecraft:snow_block
setblock 183 172 278 minecraft:white_concrete
fill 183 172 291 183 194 291 minecraft:packed_ice
fill 141 173 315 141 200 315 minecraft:packed_ice
fill 142 173 276 142 176 276 minecraft:packed_ice
setblock 142 173 280 minecraft:snow_block
fill 142 173 281 142 176 281 minecraft:packed_ice
setblock 142 173 295 minecraft:snow_block
fill 142 173 296 142 176 296 minecraft:packed_ice
setblock 142 173 300 minecraft:snow_block
fill 142 173 301 142 176 301 minecraft:packed_ice
fill 142 173 308 144 175 310 minecraft:blue_ice
fill 142 173 311 142 176 311 minecraft:packed_ice
setblock 142 173 315 minecraft:snow_block
fill 142 173 316 142 176 316 minecraft:packed_ice
setblock 143 173 279 minecraft:snow_block
fill 143 173 280 143 176 280 minecraft:packed_ice
setblock 143 173 314 minecraft:snow_block
fill 143 173 315 146 173 315 minecraft:packed_ice
setblock 144 173 277 minecraft:packed_ice
setblock 145 173 277 minecraft:snow_block
fill 145 173 309 147 174 309 minecraft:blue_ice
setblock 146 173 276 minecraft:snow_block
fill 146 173 277 149 173 277 minecraft:packed_ice
setblock 146 173 316 minecraft:snow_block
fill 147 173 276 147 176 276 minecraft:packed_ice
setblock 147 173 315 minecraft:snow_block
fill 147 173 316 147 176 316 minecraft:packed_ice
setblock 147 173 317 minecraft:white_concrete
fill 148 173 315 148 176 315 minecraft:packed_ice
fill 148 173 317 149 237 317 minecraft:packed_ice
setblock 150 173 277 minecraft:snow_block
fill 151 173 275 151 229 275 minecraft:packed_ice
setblock 151 173 276 minecraft:snow_block
fill 151 173 277 154 173 277 minecraft:packed_ice
fill 151 173 309 152 173 309 minecraft:blue_ice
setblock 151 173 316 minecraft:snow_block
fill 152 173 276 152 176 276 minecraft:packed_ice
fill 152 173 308 152 174 308 minecraft:blue_ice
setblock 152 173 314 minecraft:packed_ice
setblock 152 173 315 minecraft:snow_block
fill 152 173 316 152 176 316 minecraft:packed_ice
setblock 153 173 314 minecraft:snow_block
fill 153 173 315 153 176 315 minecraft:packed_ice
fill 154 173 314 154 176 314 minecraft:packed_ice
setblock 155 173 277 minecraft:snow_block
setblock 156 173 276 minecraft:snow_block
fill 156 173 277 156 176 277 minecraft:packed_ice
setblock 156 173 316 minecraft:snow_block
fill 157 173 276 157 176 276 minecraft:packed_ice
setblock 157 173 315 minecraft:snow_block
fill 157 173 316 157 176 316 minecraft:packed_ice
setblock 158 173 314 minecraft:snow_block
fill 158 173 315 158 176 315 minecraft:packed_ice
fill 159 173 314 159 174 314 minecraft:packed_ice
setblock 160 173 277 minecraft:snow_block
setblock 160 173 316 minecraft:packed_ice
setblock 161 173 276 minecraft:snow_block
fill 161 173 277 161 175 277 minecraft:packed_ice
setblock 161 173 316 minecraft:snow_block
fill 162 173 276 162 176 276 minecraft:packed_ice
setblock 162 173 315 minecraft:snow_block
fill 162 173 316 162 176 316 minecraft:packed_ice
fill 169 173 276 170 173 276 minecraft:packed_ice
setblock 171 173 276 minecraft:snow_block
setblock 171 173 316 minecraft:snow_block
fill 172 173 276 172 175 277 minecraft:packed_ice
fill 172 173 316 172 176 316 minecraft:packed_ice
setblock 174 173 277 minecraft:packed_ice
setblock 174 173 278 minecraft:snow_block
setblock 175 173 277 minecraft:snow_block
fill 175 173 278 175 176 278 minecraft:packed_ice
fill 175 173 315 175 174 315 minecraft:packed_ice
setblock 176 173 276 minecraft:snow_block
fill 176 173 277 176 176 277 minecraft:packed_ice
setblock 176 173 316 minecraft:snow_block
fill 176 173 317 178 235 317 minecraft:packed_ice
fill 177 173 276 177 176 276 minecraft:packed_ice
setblock 177 173 315 minecraft:snow_block
fill 177 173 316 177 176 316 minecraft:packed_ice
setblock 178 173 279 minecraft:snow_block
fill 178 173 315 178 176 315 minecraft:packed_ice
setblock 179 173 278 minecraft:snow_block
fill 179 173 279 179 176 279 minecraft:packed_ice
setblock 179 173 317 minecraft:light_blue_concrete
setblock 180 173 277 minecraft:snow_block
fill 180 173 278 180 176 278 minecraft:packed_ice
setblock 180 173 282 minecraft:snow_block
setblock 180 173 292 minecraft:snow_block
fill 180 173 293 180 174 293 minecraft:packed_ice
setblock 180 173 297 minecraft:snow_block
fill 180 173 298 180 175 299 minecraft:packed_ice
fill 180 173 317 180 237 317 minecraft:packed_ice
setblock 181 173 276 minecraft:snow_block
fill 181 173 277 181 176 277 minecraft:packed_ice
setblock 181 173 281 minecraft:snow_block
fill 181 173 282 181 176 282 minecraft:packed_ice
setblock 181 173 286 minecraft:snow_block
fill 181 173 287 181 174 287 minecraft:packed_ice
setblock 181 173 291 minecraft:snow_block
fill 181 173 292 181 175 292 minecraft:packed_ice
setblock 181 173 296 minecraft:snow_block
fill 181 173 297 181 176 297 minecraft:packed_ice
setblock 181 173 316 minecraft:snow_block
fill 182 173 276 182 176 276 minecraft:packed_ice
setblock 182 173 280 minecraft:snow_block
fill 182 173 281 182 176 281 minecraft:packed_ice
setblock 182 173 285 minecraft:snow_block
fill 182 173 286 182 176 286 minecraft:packed_ice
setblock 182 173 290 minecraft:snow_block
fill 182 173 291 182 176 291 minecraft:packed_ice
setblock 182 173 295 minecraft:snow_block
fill 182 173 296 182 176 296 minecraft:packed_ice
setblock 182 173 300 minecraft:snow_block
fill 182 173 301 182 175 302 minecraft:packed_ice
setblock 182 173 315 minecraft:snow_block
fill 182 173 316 182 176 316 minecraft:packed_ice
setblock 183 173 276 minecraft:white_concrete
fill 183 173 278 183 238 278 minecraft:packed_ice
setblock 142 174 279 minecraft:snow_block
fill 142 174 280 142 177 280 minecraft:packed_ice
setblock 142 174 284 minecraft:snow_block
setblock 142 174 294 minecraft:snow_block
fill 142 174 295 142 175 295 minecraft:packed_ice
setblock 142 174 298 minecraft:packed_ice
setblock 142 174 299 minecraft:snow_block
fill 142 174 300 142 177 300 minecraft:packed_ice
fill 142 174 302 142 174 303 minecraft:packed_ice
fill 142 174 307 143 175 307 minecraft:blue_ice
setblock 142 174 314 minecraft:snow_block
fill 142 174 315 145 174 315 minecraft:packed_ice
setblock 143 174 278 minecraft:snow_block
fill 143 174 279 143 177 279 minecraft:packed_ice
fill 143 174 311 143 175 311 minecraft:blue_ice
fill 143 174 314 143 175 314 minecraft:packed_ice
setblock 144 174 277 minecraft:snow_block
setblock 144 174 278 minecraft:light[level=12]
setblock 144 174 285 minecraft:light[level=12]
setblock 144 174 292 minecraft:light[level=12]
setblock 144 174 299 minecraft:light[level=12]
setblock 144 174 306 minecraft:light[level=12]
setblock 144 174 313 minecraft:light[level=12]
setblock 145 174 276 minecraft:snow_block
fill 145 174 277 148 174 277 minecraft:packed_ice
fill 145 174 308 146 174 308 minecraft:blue_ice
fill 145 174 310 146 174 310 minecraft:blue_ice
setblock 145 174 316 minecraft:snow_block
fill 146 174 276 146 177 276 minecraft:packed_ice
setblock 146 174 315 minecraft:snow_block
fill 146 174 316 146 177 316 minecraft:packed_ice
fill 147 174 315 147 176 315 minecraft:packed_ice
fill 147 174 317 147 178 317 minecraft:packed_ice
setblock 149 174 277 minecraft:snow_block
setblock 150 174 276 minecraft:snow_block
fill 150 174 277 153 174 277 minecraft:packed_ice
setblock 150 174 316 minecraft:snow_block
fill 151 174 276 151 177 276 minecraft:packed_ice
setblock 151 174 278 minecraft:light[level=12]
setblock 151 174 285 minecraft:light[level=12]
setblock 151 174 292 minecraft:light[level=12]
setblock 151 174 299 minecraft:light[level=12]
setblock 151 174 306 minecraft:light[level=12]
setblock 151 174 313 minecraft:light[level=12]
setblock 151 174 315 minecraft:snow_block
fill 151 174 316 151 177 316 minecraft:packed_ice
fill 152 174 275 152 216 275 minecraft:packed_ice
fill 152 174 309 152 175 309 minecraft:blue_ice
setblock 152 174 314 minecraft:snow_block
fill 152 174 315 152 177 315 minecraft:packed_ice
setblock 153 174 275 minecraft:light_blue_concrete
fill 153 174 314 153 177 314 minecraft:packed_ice
setblock 154 174 277 minecraft:snow_block
setblock 155 174 276 minecraft:snow_block
fill 155 174 277 155 176 278 minecraft:packed_ice
setblock 155 174 316 minecraft:snow_block
fill 156 174 276 156 177 276 minecraft:packed_ice
fill 156 174 278 157 174 278 minecraft:packed_ice
setblock 156 174 315 minecraft:snow_block
fill 156 174 316 156 177 316 minecraft:packed_ice
setblock 157 174 314 minecraft:snow_block
fill 157 174 315 157 177 315 minecraft:packed_ice
setblock 158 174 277 minecraft:packed_ice
setblock 158 174 278 minecraft:light[level=12]
setblock 158 174 285 minecraft:light[level=12]
setblock 158 174 299 minecraft:light[level=12]
setblock 158 174 306 minecraft:light[level=12]
setblock 158 174 313 minecraft:light[level=12]
fill 158 174 314 158 175 314 minecraft:packed_ice
setblock 159 174 277 minecraft:snow_block
setblock 160 174 276 minecraft:snow_block
fill 160 174 277 160 177 277 minecraft:packed_ice
setblock 160 174 316 minecraft:snow_block
fill 161 174 276 161 177 276 minecraft:packed_ice
setblock 161 174 315 minecraft:snow_block
fill 161 174 316 161 177 316 minecraft:packed_ice
setblock 165 174 276 minecraft:snow_block
setblock 165 174 278 minecraft:light[level=12]
setblock 165 174 285 minecraft:light[level=12]
setblock 165 174 292 minecraft:light[level=12]
setblock 165 174 299 minecraft:light[level=12]
setblock 165 174 306 minecraft:light[level=12]
setblock 165 174 313 minecraft:light[level=12]
fill 166 174 276 169 174 276 minecraft:packed_ice
setblock 170 174 276 minecraft:snow_block
fill 171 174 276 171 176 277 minecraft:packed_ice
fill 171 174 316 171 177 317 minecraft:packed_ice
setblock 172 174 278 minecraft:light[level=12]
setblock 172 174 285 minecraft:light[level=12]
setblock 172 174 292 minecraft:light[level=12]
setblock 172 174 299 minecraft:light[level=12]
setblock 172 174 306 minecraft:light[level=12]
setblock 172 174 313 minecraft:light[level=12]
setblock 172 174 317 minecraft:white_concrete
setblock 173 174 278 minecraft:snow_block
fill 173 174 317 175 183 317 minecraft:packed_ice
setblock 174 174 277 minecraft:snow_block
fill 174 174 278 174 177 278 minecraft:packed_ice
setblock 175 174 276 minecraft:snow_block
fill 175 174 277 175 177 277 minecraft:packed_ice
fill 175 174 279 176 174 279 minecraft:packed_ice
setblock 175 174 316 minecraft:snow_block
fill 176 174 276 176 177 276 minecraft:packed_ice
setblock 176 174 315 minecraft:snow_block
fill 176 174 316 176 177 316 minecraft:packed_ice
setblock 177 174 279 minecraft:snow_block
fill 177 174 315 177 177 315 minecraft:packed_ice
setblock 178 174 277 minecraft:packed_ice
setblock 178 174 278 minecraft:snow_block
fill 178 174 279 178 177 279 minecraft:packed_ice
setblock 179 174 277 minecraft:snow_block
fill 179 174 278 179 177 278 minecraft:packed_ice
fill 179 174 280 180 174 280 minecraft:packed_ice
setblock 179 174 285 minecraft:light[level=12]
setblock 179 174 292 minecraft:light[level=12]
setblock 179 174 299 minecraft:light[level=12]
setblock 179 174 306 minecraft:light[level=12]
setblock 179 174 313 minecraft:light[level=12]
fill 179 174 317 179 237 317 minecraft:packed_ice
fill 180 174 275 180 237 275 minecraft:packed_ice
setblock 180 174 276 minecraft:snow_block
fill 180 174 277 180 177 277 minecraft:packed_ice
fill 180 174 279 180 175 279 minecraft:packed_ice
setblock 180 174 281 minecraft:snow_block
fill 180 174 282 180 176 283 minecraft:packed_ice
setblock 180 174 296 minecraft:snow_block
fill 180 174 297 180 175 297 minecraft:packed_ice
setblock 180 174 316 minecraft:snow_block
fill 181 174 276 181 177 276 minecraft:packed_ice
setblock 181 174 280 minecraft:snow_block
fill 181 174 281 181 177 281 minecraft:packed_ice
setblock 181 174 285 minecraft:snow_block
fill 181 174 286 181 176 286 minecraft:packed_ice
setblock 181 174 290 minecraft:snow_block
fill 181 174 291 181 175 291 minecraft:packed_ice
setblock 181 174 295 minecraft:snow_block
fill 181 174 296 181 176 296 minecraft:packed_ice
setblock 181 174 300 minecraft:snow_block
fill 181 174 301 181 176 301 minecraft:packed_ice
setblock 181 174 315 minecraft:snow_block
fill 181 174 316 181 177 316 minecraft:packed_ice
setblock 182 174 279 minecraft:snow_block
fill 182 174 280 182 177 280 minecraft:packed_ice
setblock 182 174 284 minecraft:snow_block
fill 182 174 285 182 177 285 minecraft:packed_ice
setblock 182 174 289 minecraft:snow_block
fill 182 174 290 182 176 290 minecraft:packed_ice
setblock 182 174 294 minecraft:snow_block
fill 182 174 295 182 177 295 minecraft:packed_ice
setblock 182 174 299 minecraft:snow_block
fill 182 174 300 182 177 300 minecraft:packed_ice
setblock 182 174 314 minecraft:snow_block
fill 182 174 315 182 177 315 minecraft:packed_ice
fill 183 174 276 183 235 276 minecraft:packed_ice
fill 141 175 288 141 227 290 minecraft:packed_ice
setblock 141 175 291 minecraft:light_blue_concrete
setblock 142 175 278 minecraft:snow_block
fill 142 175 279 142 178 279 minecraft:packed_ice
setblock 142 175 283 minecraft:snow_block
fill 142 175 284 142 177 284 minecraft:packed_ice
setblock 142 175 294 minecraft:packed_ice
setblock 142 175 298 minecraft:snow_block
fill 142 175 299 142 178 299 minecraft:packed_ice
setblock 142 175 302 minecraft:packed_ice
setblock 142 175 303 minecraft:snow_block
fill 142 175 304 142 178 304 minecraft:packed_ice
setblock 142 175 313 minecraft:snow_block
fill 142 175 314 142 177 315 minecraft:packed_ice
setblock 143 175 277 minecraft:snow_block
fill 143 175 278 143 178 278 minecraft:packed_ice
setblock 143 175 281 minecraft:packed_ice
fill 143 175 315 144 175 315 minecraft:packed_ice
setblock 144 175 276 minecraft:snow_block
fill 144 175 277 147 175 277 minecraft:packed_ice
setblock 144 175 316 minecraft:snow_block
fill 145 175 276 145 178 276 minecraft:packed_ice
fill 145 175 308 145 175 310 minecraft:blue_ice
setblock 145 175 315 minecraft:snow_block
fill 145 175 316 145 178 316 minecraft:packed_ice
fill 146 175 315 146 176 315 minecraft:packed_ice
setblock 148 175 277 minecraft:snow_block
setblock 149 175 276 minecraft:snow_block
fill 149 175 277 152 175 277 minecraft:packed_ice
setblock 149 175 316 minecraft:snow_block
fill 150 175 276 150 178 276 minecraft:packed_ice
setblock 150 175 315 minecraft:snow_block
fill 150 175 316 150 178 316 minecraft:packed_ice
fill 151 175 315 151 178 315 minecraft:packed_ice
fill 152 175 314 152 177 314 minecraft:packed_ice
fill 153 175 275 153 191 275 minecraft:packed_ice
setblock 153 175 277 minecraft:snow_block
fill 153 175 278 154 177 278 minecraft:packed_ice
setblock 154 175 276 minecraft:snow_block
fill 154 175 277 154 178 277 minecraft:packed_ice
setblock 154 175 316 minecraft:snow_block
fill 155 175 276 155 178 276 minecraft:packed_ice
setblock 155 175 315 minecraft:snow_block
fill 155 175 316 155 178 316 minecraft:packed_ice
setblock 156 175 278 minecraft:packed_ice
setblock 156 175 314 minecraft:snow_block
fill 156 175 315 156 178 315 minecraft:packed_ice
setblock 157 175 278 minecraft:snow_block
fill 157 175 314 157 176 314 minecraft:packed_ice
setblock 158 175 277 minecraft:snow_block
setblock 159 175 276 minecraft:snow_block
fill 159 175 277 159 177 277 minecraft:packed_ice
setblock 159 175 316 minecraft:snow_block
fill 160 175 276 160 178 276 minecraft:packed_ice
setblock 160 175 315 minecraft:snow_block
fill 160 175 316 160 177 316 minecraft:packed_ice
setblock 161 175 315 minecraft:packed_ice
setblock 163 175 276 minecraft:packed_ice
setblock 164 175 276 minecraft:snow_block
fill 165 175 276 168 175 276 minecraft:packed_ice
fill 165 175 311 165 180 311 minecraft:packed_ice
fill 166 175 310 166 180 310 minecraft:packed_ice
fill 166 175 312 166 180 312 minecraft:packed_ice
fill 167 175 311 167 180 311 minecraft:packed_ice
setblock 169 175 276 minecraft:snow_block
fill 169 175 305 170 176 306 minecraft:snow_block
fill 170 175 276 170 177 277 minecraft:packed_ice
fill 170 175 300 171 176 301 minecraft:white_concrete
fill 170 175 316 170 176 316 minecraft:packed_ice
setblock 172 175 278 minecraft:snow_block
fill 172 175 317 172 236 317 minecraft:packed_ice
setblock 173 175 276 minecraft:packed_ice
setblock 173 175 277 minecraft:snow_block
fill 173 175 278 173 178 278 minecraft:packed_ice
setblock 174 175 276 minecraft:snow_block
fill 174 175 277 174 178 277 minecraft:packed_ice
fill 174 175 279 175 175 279 minecraft:packed_ice
setblock 174 175 315 minecraft:packed_ice
setblock 174 175 316 minecraft:snow_block
fill 175 175 276 175 178 276 minecraft:packed_ice
setblock 175 175 315 minecraft:snow_block
fill 175 175 316 175 178 316 minecraft:packed_ice
setblock 176 175 278 minecraft:packed_ice
setblock 176 175 279 minecraft:snow_block
fill 176 175 315 176 177 315 minecraft:packed_ice
setblock 177 175 278 minecraft:snow_block
fill 177 175 279 177 178 279 minecraft:packed_ice
setblock 178 175 277 minecraft:snow_block
fill 178 175 278 178 178 278 minecraft:packed_ice
setblock 179 175 276 minecraft:snow_block
fill 179 175 277 179 178 277 minecraft:packed_ice
setblock 179 175 280 minecraft:packed_ice
setblock 179 175 281 minecraft:snow_block
setblock 179 175 316 minecraft:snow_block
fill 180 175 276 180 178 276 minecraft:packed_ice
setblock 180 175 280 minecraft:snow_block
fill 180 175 281 180 178 281 minecraft:packed_ice
setblock 180 175 284 minecraft:packed_ice
setblock 180 175 295 minecraft:snow_block
setblock 180 175 296 minecraft:packed_ice
setblock 180 175 315 minecraft:snow_block
fill 180 175 316 180 178 316 minecraft:packed_ice
setblock 181 175 279 minecraft:snow_block
fill 181 175 280 181 178 280 minecraft:packed_ice
setblock 181 175 284 minecraft:snow_block
fill 181 175 285 181 178 285 minecraft:packed_ice
setblock 181 175 294 minecraft:snow_block
fill 181 175 295 181 176 295 minecraft:packed_ice
setblock 181 175 299 minecraft:snow_block
fill 181 175 300 181 176 300 minecraft:packed_ice
setblock 181 175 315 minecraft:packed_ice
setblock 182 175 278 minecraft:snow_block
fill 182 175 279 182 178 279 minecraft:packed_ice
setblock 182 175 283 minecraft:snow_block
fill 182 175 284 182 178 284 minecraft:packed_ice
setblock 182 175 288 minecraft:snow_block
fill 182 175 289 182 176 289 minecraft:packed_ice
setblock 182 175 293 minecraft:snow_block
fill 182 175 294 182 176 294 minecraft:packed_ice
setblock 182 175 298 minecraft:snow_block
fill 182 175 299 182 178 299 minecraft:packed_ice
setblock 182 175 303 minecraft:snow_block
fill 182 175 314 182 176 314 minecraft:packed_ice
setblock 183 175 308 minecraft:light_blue_concrete
fill 141 176 291 141 216 291 minecraft:packed_ice
setblock 142 176 277 minecraft:snow_block
fill 142 176 278 142 179 278 minecraft:packed_ice
setblock 142 176 282 minecraft:snow_block
fill 142 176 283 142 179 283 minecraft:packed_ice
setblock 142 176 297 minecraft:snow_block
fill 142 176 298 142 177 298 minecraft:packed_ice
setblock 142 176 302 minecraft:snow_block
fill 142 176 303 142 179 303 minecraft:packed_ice
fill 142 176 305 142 177 305 minecraft:packed_ice
fill 142 176 308 143 176 310 minecraft:blue_ice
setblock 142 176 312 minecraft:snow_block
fill 142 176 313 142 177 313 minecraft:packed_ice
setblock 143 176 276 minecraft:snow_block
fill 143 176 277 146 176 277 minecraft:packed_ice
setblock 143 176 281 minecraft:snow_block
setblock 143 176 315 minecraft:packed_ice
setblock 143 176 316 minecraft:snow_block
fill 144 176 276 144 179 276 minecraft:packed_ice
setblock 144 176 278 minecraft:light[level=15]
setblock 144 176 286 minecraft:light[level=15]
setblock 144 176 294 minecraft:light[level=15]
setblock 144 176 302 minecraft:light[level=15]
setblock 144 176 309 minecraft:blue_ice
setblock 144 176 310 minecraft:light[level=15]
setblock 144 176 315 minecraft:snow_block
fill 144 176 316 144 179 316 minecraft:packed_ice
setblock 145 176 315 minecraft:packed_ice
setblock 147 176 277 minecraft:snow_block
setblock 148 176 276 minecraft:snow_block
fill 148 176 277 151 176 277 minecraft:packed_ice
setblock 148 176 316 minecraft:snow_block
fill 149 176 276 149 179 276 minecraft:packed_ice
setblock 149 176 315 minecraft:snow_block
fill 149 176 316 149 179 316 minecraft:packed_ice
fill 150 176 315 150 179 315 minecraft:packed_ice
setblock 152 176 277 minecraft:snow_block
fill 152 176 278 152 178 278 minecraft:packed_ice
setblock 152 176 286 minecraft:light[level=15]
setblock 152 176 294 minecraft:light[level=15]
setblock 152 176 310 minecraft:light[level=15]
setblock 153 176 276 minecraft:snow_block
fill 153 176 277 153 179 277 minecraft:packed_ice
setblock 153 176 316 minecraft:snow_block
fill 154 176 276 154 179 276 minecraft:packed_ice
setblock 154 176 315 minecraft:snow_block
fill 154 176 316 154 179 316 minecraft:packed_ice
setblock 155 176 314 minecraft:snow_block
fill 155 176 315 155 179 315 minecraft:packed_ice
setblock 156 176 278 minecraft:snow_block
setblock 156 176 314 minecraft:packed_ice
setblock 157 176 277 minecraft:snow_block
setblock 157 176 278 minecraft:packed_ice
setblock 158 176 276 minecraft:snow_block
fill 158 176 277 158 178 277 minecraft:packed_ice
setblock 158 176 316 minecraft:snow_block
fill 159 176 276 159 179 276 minecraft:packed_ice
setblock 159 176 315 minecraft:snow_block
fill 159 176 316 159 178 316 minecraft:packed_ice
setblock 160 176 278 minecraft:light[level=15]
setblock 160 176 286 minecraft:light[level=15]
setblock 160 176 294 minecraft:light[level=15]
setblock 160 176 302 minecraft:light[level=15]
setblock 160 176 310 minecraft:light[level=15]
setblock 160 176 315 minecraft:packed_ice
setblock 163 176 276 minecraft:snow_block
fill 164 176 276 167 176 276 minecraft:packed_ice
setblock 168 176 276 minecraft:snow_block
setblock 168 176 278 minecraft:light[level=15]
setblock 168 176 286 minecraft:light[level=15]
setblock 168 176 294 minecraft:light[level=15]
setblock 168 176 302 minecraft:light[level=15]
setblock 168 176 310 minecraft:light[level=15]
fill 169 176 276 169 178 277 minecraft:packed_ice
setblock 171 176 278 minecraft:snow_block
setblock 172 176 276 minecraft:packed_ice
setblock 172 176 277 minecraft:snow_block
fill 172 176 278 172 179 278 minecraft:packed_ice
setblock 173 176 276 minecraft:snow_block
fill 173 176 277 173 179 277 minecraft:packed_ice
fill 173 176 279 174 176 279 minecraft:packed_ice
setblock 173 176 316 minecraft:snow_block
fill 174 176 276 174 179 276 minecraft:packed_ice
fill 174 176 316 174 179 316 minecraft:packed_ice
setblock 175 176 279 minecraft:snow_block
setblock 175 176 315 minecraft:packed_ice
setblock 176 176 278 minecraft:snow_block
fill 176 176 279 176 179 279 minecraft:packed_ice
setblock 176 176 286 minecraft:light[level=15]
setblock 176 176 294 minecraft:light[level=15]
setblock 176 176 302 minecraft:light[level=15]
setblock 177 176 277 minecraft:snow_block
fill 177 176 278 177 179 278 minecraft:packed_ice
setblock 178 176 276 minecraft:snow_block
fill 178 176 277 178 179 277 minecraft:packed_ice
setblock 178 176 316 minecraft:snow_block
fill 179 176 276 179 179 276 minecraft:packed_ice
setblock 179 176 280 minecraft:snow_block
fill 179 176 281 179 177 282 minecraft:packed_ice
setblock 179 176 315 minecraft:snow_block
fill 179 176 316 179 179 316 minecraft:packed_ice
setblock 180 176 279 minecraft:snow_block
fill 180 176 280 180 179 280 minecraft:packed_ice
setblock 180 176 284 minecraft:snow_block
setblock 181 176 278 minecraft:snow_block
fill 181 176 279 181 179 279 minecraft:packed_ice
setblock 181 176 283 minecraft:snow_block
fill 181 176 284 181 179 284 minecraft:packed_ice
setblock 181 176 294 minecraft:packed_ice
setblock 181 176 298 minecraft:snow_block
fill 181 176 299 181 177 299 minecraft:packed_ice
setblock 182 176 277 minecraft:snow_block
fill 182 176 278 182 179 278 minecraft:packed_ice
setblock 182 176 282 minecraft:snow_block
fill 182 176 283 182 179 283 minecraft:packed_ice
setblock 182 176 287 minecraft:snow_block
setblock 182 176 288 minecraft:packed_ice
setblock 182 176 292 minecraft:snow_block
setblock 182 176 293 minecraft:packed_ice
setblock 182 176 297 minecraft:snow_block
fill 182 176 298 182 178 298 minecraft:packed_ice
setblock 182 176 301 minecraft:packed_ice
setblock 182 176 302 minecraft:snow_block
fill 182 176 303 182 177 303 minecraft:packed_ice
fill 183 176 308 183 201 308 minecraft:packed_ice
setblock 142 177 276 minecraft:snow_block
fill 142 177 277 145 177 277 minecraft:packed_ice
setblock 142 177 281 minecraft:snow_block
fill 142 177 282 142 180 282 minecraft:packed_ice
setblock 142 177 297 minecraft:packed_ice
setblock 142 177 301 minecraft:snow_block
fill 142 177 302 142 180 302 minecraft:packed_ice
setblock 142 177 312 minecraft:packed_ice
setblock 142 177 316 minecraft:snow_block
fill 143 177 276 143 180 276 minecraft:packed_ice
setblock 143 177 280 minecraft:snow_block
fill 143 177 316 143 179 316 minecraft:packed_ice
setblock 146 177 277 minecraft:snow_block
setblock 147 177 276 minecraft:snow_block
fill 147 177 277 150 177 277 minecraft:packed_ice
setblock 147 177 316 minecraft:snow_block
fill 148 177 276 148 180 276 minecraft:packed_ice
setblock 148 177 315 minecraft:snow_block
fill 148 177 316 148 180 316 minecraft:packed_ice
fill 149 177 315 149 178 315 minecraft:packed_ice
setblock 151 177 277 minecraft:snow_block
setblock 152 177 276 minecraft:snow_block
fill 152 177 277 152 180 277 minecraft:packed_ice
setblock 152 177 316 minecraft:snow_block
fill 153 177 276 153 180 276 minecraft:packed_ice
setblock 153 177 315 minecraft:snow_block
fill 153 177 316 153 180 316 minecraft:packed_ice
setblock 154 177 314 minecraft:snow_block
fill 154 177 315 154 179 315 minecraft:packed_ice
setblock 155 177 277 minecraft:packed_ice
setblock 155 177 278 minecraft:snow_block
setblock 155 177 314 minecraft:packed_ice
setblock 156 177 277 minecraft:snow_block
setblock 156 177 278 minecraft:packed_ice
setblock 157 177 276 minecraft:snow_block
fill 157 177 277 157 179 277 minecraft:packed_ice
setblock 157 177 316 minecraft:snow_block
fill 158 177 276 158 179 276 minecraft:packed_ice
setblock 158 177 315 minecraft:snow_block
fill 158 177 316 158 179 316 minecraft:packed_ice
setblock 162 177 276 minecraft:snow_block
setblock 163 177 276 minecraft:packed_ice
setblock 165 177 275 minecraft:white_concrete
fill 165 177 310 165 180 310 minecraft:packed_ice
fill 165 177 312 165 180 312 minecraft:packed_ice
fill 166 177 275 166 177 276 minecraft:packed_ice
setblock 167 177 276 minecraft:snow_block
fill 167 177 310 167 180 310 minecraft:packed_ice
fill 167 177 312 167 180 312 minecraft:packed_ice
fill 168 177 276 168 180 276 minecraft:packed_ice
setblock 170 177 278 minecraft:snow_block
setblock 171 177 276 minecraft:packed_ice
setblock 171 177 277 minecraft:snow_block
fill 171 177 278 171 180 278 minecraft:packed_ice
setblock 172 177 276 minecraft:snow_block
fill 172 177 277 172 180 277 minecraft:packed_ice
fill 172 177 279 173 177 279 minecraft:packed_ice
setblock 172 177 316 minecraft:snow_block
fill 173 177 276 173 180 276 minecraft:packed_ice
fill 173 177 316 173 180 316 minecraft:packed_ice
setblock 174 177 279 minecraft:snow_block
setblock 175 177 278 minecraft:snow_block
fill 175 177 279 175 180 279 minecraft:packed_ice
setblock 176 177 277 minecraft:snow_block
fill 176 177 278 176 180 278 minecraft:packed_ice
setblock 177 177 276 minecraft:snow_block
fill 177 177 277 177 180 277 minecraft:packed_ice
setblock 177 177 316 minecraft:snow_block
fill 178 177 276 178 180 276 minecraft:packed_ice
fill 178 177 316 178 179 316 minecraft:packed_ice
setblock 179 177 279 minecraft:snow_block
fill 179 177 280 179 178 280 minecraft:packed_ice
setblock 180 177 278 minecraft:snow_block
fill 180 177 279 180 180 279 minecraft:packed_ice
setblock 180 177 282 minecraft:packed_ice
setblock 180 177 283 minecraft:snow_block
setblock 180 177 284 minecraft:packed_ice
setblock 181 177 277 minecraft:snow_block
fill 181 177 278 181 180 278 minecraft:packed_ice
setblock 181 177 282 minecraft:snow_block
fill 181 177 283 181 180 283 minecraft:packed_ice
setblock 181 177 298 minecraft:packed_ice
setblock 182 177 276 minecraft:snow_block
fill 182 177 277 182 180 277 minecraft:packed_ice
setblock 182 177 281 minecraft:snow_block
fill 182 177 282 182 180 282 minecraft:packed_ice
setblock 182 177 286 minecraft:snow_block
setblock 182 177 287 minecraft:packed_ice
setblock 182 177 296 minecraft:snow_block
setblock 182 177 297 minecraft:packed_ice
setblock 182 177 301 minecraft:snow_block
fill 182 177 302 182 178 302 minecraft:packed_ice
setblock 182 177 316 minecraft:snow_block
fill 141 178 303 141 181 310 minecraft:packed_ice
setblock 141 178 311 minecraft:white_concrete
fill 141 178 312 141 237 313 minecraft:packed_ice
fill 142 178 276 142 180 277 minecraft:packed_ice
setblock 142 178 280 minecraft:snow_block
fill 142 178 281 142 181 281 minecraft:packed_ice
setblock 142 178 300 minecraft:snow_block
fill 142 178 301 142 179 301 minecraft:packed_ice
setblock 142 178 305 minecraft:snow_block
fill 142 178 306 142 181 306 minecraft:packed_ice
setblock 142 178 314 minecraft:packed_ice
setblock 142 178 315 minecraft:snow_block
fill 142 178 316 142 179 316 minecraft:packed_ice
fill 143 178 277 144 178 277 minecraft:packed_ice
setblock 143 178 279 minecraft:snow_block
setblock 143 178 280 minecraft:packed_ice
setblock 145 178 277 minecraft:snow_block
setblock 146 178 276 minecraft:snow_block
fill 146 178 277 149 178 277 minecraft:packed_ice
setblock 146 178 316 minecraft:snow_block
fill 147 178 276 147 181 276 minecraft:packed_ice
fill 147 178 316 147 181 316 minecraft:packed_ice
setblock 150 178 277 minecraft:snow_block
setblock 151 178 276 minecraft:snow_block
fill 151 178 277 151 180 277 minecraft:packed_ice
setblock 151 178 316 minecraft:snow_block
fill 152 178 276 152 181 276 minecraft:packed_ice
setblock 152 178 315 minecraft:snow_block
fill 152 178 316 152 181 316 minecraft:packed_ice
setblock 153 178 278 minecraft:packed_ice
fill 153 178 315 153 180 315 minecraft:packed_ice
setblock 154 178 278 minecraft:snow_block
setblock 155 178 277 minecraft:snow_block
setblock 155 178 278 minecraft:packed_ice
setblock 156 178 276 minecraft:snow_block
fill 156 178 277 156 179 277 minecraft:packed_ice
setblock 156 178 316 minecraft:snow_block
fill 157 178 276 157 180 276 minecraft:packed_ice
setblock 157 178 315 minecraft:snow_block
fill 157 178 316 157 179 316 minecraft:packed_ice
setblock 161 178 276 minecraft:snow_block
fill 165 178 275 166 181 275 minecraft:packed_ice
fill 167 178 276 167 179 276 minecraft:packed_ice
setblock 170 178 276 minecraft:packed_ice
setblock 170 178 277 minecraft:snow_block
fill 170 178 278 170 180 278 minecraft:packed_ice
setblock 171 178 276 minecraft:snow_block
fill 171 178 277 171 181 277 minecraft:packed_ice
setblock 171 178 316 minecraft:snow_block
fill 171 178 317 171 237 317 minecraft:packed_ice
fill 172 178 276 172 181 276 minecraft:packed_ice
setblock 172 178 279 minecraft:packed_ice
fill 172 178 316 172 179 316 minecraft:packed_ice
setblock 173 178 279 minecraft:snow_block
setblock 174 178 278 minecraft:snow_block
fill 174 178 279 174 181 279 minecraft:packed_ice
setblock 175 178 277 minecraft:snow_block
fill 175 178 278 175 181 278 minecraft:packed_ice
setblock 176 178 276 minecraft:snow_block
fill 176 178 277 176 181 277 minecraft:packed_ice
setblock 176 178 316 minecraft:snow_block
fill 177 178 276 177 181 276 minecraft:packed_ice
fill 177 178 316 177 180 316 minecraft:packed_ice
setblock 178 178 279 minecraft:snow_block
setblock 179 178 278 minecraft:snow_block
setblock 179 178 279 minecraft:packed_ice
setblock 179 178 281 minecraft:packed_ice
setblock 180 178 277 minecraft:snow_block
fill 180 178 278 180 179 278 minecraft:packed_ice
setblock 180 178 282 minecraft:snow_block
fill 180 178 283 180 179 283 minecraft:packed_ice
setblock 181 178 276 minecraft:snow_block
fill 181 178 277 181 180 277 minecraft:packed_ice
setblock 181 178 281 minecraft:snow_block
fill 181 178 282 181 181 282 minecraft:packed_ice
setblock 181 178 316 minecraft:snow_block
fill 182 178 276 182 181 276 minecraft:packed_ice
setblock 182 178 280 minecraft:snow_block
fill 182 178 281 182 181 281 minecraft:packed_ice
setblock 182 178 285 minecraft:snow_block
fill 182 178 286 182 179 286 minecraft:packed_ice
setblock 182 178 300 minecraft:snow_block
setblock 182 178 301 minecraft:packed_ice
setblock 182 178 316 minecraft:packed_ice
fill 141 179 311 141 237 311 minecraft:packed_ice
setblock 142 179 279 minecraft:snow_block
fill 142 179 280 142 181 280 minecraft:packed_ice
setblock 142 179 300 minecraft:packed_ice
setblock 142 179 304 minecraft:snow_block
fill 142 179 305 142 182 305 minecraft:packed_ice
setblock 142 179 315 minecraft:packed_ice
setblock 145 179 276 minecraft:snow_block
setblock 145 179 316 minecraft:snow_block
fill 146 179 276 146 180 276 minecraft:packed_ice
fill 146 179 316 146 180 316 minecraft:packed_ice
setblock 147 179 317 minecraft:white_concrete
setblock 148 179 277 minecraft:packed_ice
setblock 149 179 277 minecraft:snow_block
setblock 150 179 276 minecraft:snow_block
fill 150 179 277 150 180 277 minecraft:packed_ice
setblock 150 179 316 minecraft:snow_block
fill 151 179 276 151 182 276 minecraft:packed_ice
setblock 151 179 315 minecraft:snow_block
fill 151 179 316 151 182 316 minecraft:packed_ice
fill 152 179 315 152 180 315 minecraft:packed_ice
setblock 154 179 277 minecraft:snow_block
setblock 155 179 276 minecraft:snow_block
fill 155 179 277 155 180 277 minecraft:packed_ice
setblock 155 179 316 minecraft:snow_block
fill 156 179 276 156 180 276 minecraft:packed_ice
fill 156 179 316 156 180 316 minecraft:packed_ice
setblock 169 179 276 minecraft:packed_ice
setblock 169 179 277 minecraft:snow_block
setblock 170 179 276 minecraft:snow_block
fill 170 179 277 170 182 277 minecraft:packed_ice
fill 171 179 276 171 182 276 minecraft:packed_ice
setblock 172 179 279 minecraft:snow_block
setblock 173 179 278 minecraft:snow_block
fill 173 179 279 173 181 279 minecraft:packed_ice
setblock 174 179 277 minecraft:snow_block
fill 174 179 278 174 182 278 minecraft:packed_ice
setblock 175 179 276 minecraft:snow_block
fill 175 179 277 175 182 277 minecraft:packed_ice
setblock 175 179 316 minecraft:snow_block
fill 176 179 276 176 182 276 minecraft:packed_ice
fill 176 179 316 176 180 316 minecraft:packed_ice
setblock 177 179 279 minecraft:snow_block
setblock 178 179 278 minecraft:snow_block
setblock 178 179 279 minecraft:packed_ice
setblock 179 179 277 minecraft:snow_block
fill 179 179 278 179 180 278 minecraft:packed_ice
setblock 180 179 276 minecraft:snow_block
fill 180 179 277 180 181 277 minecraft:packed_ice
setblock 180 179 281 minecraft:snow_block
setblock 180 179 282 minecraft:packed_ice
setblock 180 179 316 minecraft:snow_block
fill 181 179 276 181 182 276 minecraft:packed_ice
setblock 181 179 280 minecraft:snow_block
fill 181 179 281 181 182 281 minecraft:packed_ice
setblock 182 179 279 minecraft:snow_block
fill 182 179 280 182 182 280 minecraft:packed_ice
setblock 182 179 284 minecraft:snow_block
fill 182 179 285 182 182 285 minecraft:packed_ice
setblock 142 180 278 minecraft:snow_block
fill 142 180 279 142 181 279 minecraft:packed_ice
setblock 142 180 303 minecraft:snow_block
fill 142 180 304 142 183 304 minecraft:packed_ice
setblock 144 180 276 minecraft:snow_block
setblock 144 180 278 minecraft:light[level=12]
setblock 144 180 285 minecraft:light[level=12]
setblock 144 180 292 minecraft:light[level=12]
setblock 144 180 299 minecraft:light[level=12]
setblock 144 180 306 minecraft:light[level=12]
setblock 144 180 313 minecraft:light[level=12]
setblock 145 180 276 minecraft:packed_ice
fill 147 180 317 147 218 317 minecraft:packed_ice
setblock 149 180 276 minecraft:snow_block
setblock 149 180 316 minecraft:snow_block
fill 150 180 276 150 182 276 minecraft:packed_ice
fill 150 180 316 150 183 316 minecraft:packed_ice
setblock 151 180 278 minecraft:light[level=12]
setblock 151 180 285 minecraft:light[level=12]
setblock 151 180 292 minecraft:light[level=12]
setblock 151 180 299 minecraft:light[level=12]
setblock 151 180 306 minecraft:light[level=12]
setblock 151 180 313 minecraft:light[level=12]
setblock 151 180 315 minecraft:packed_ice
fill 152 180 317 154 188 317 minecraft:packed_ice
setblock 153 180 277 minecraft:snow_block
setblock 154 180 276 minecraft:snow_block
setblock 154 180 277 minecraft:packed_ice
setblock 154 180 316 minecraft:snow_block
fill 155 180 276 155 181 276 minecraft:packed_ice
fill 155 180 316 155 181 316 minecraft:packed_ice
setblock 155 180 317 minecraft:light_blue_concrete
fill 156 180 317 159 195 317 minecraft:packed_ice
setblock 158 180 278 minecraft:light[level=12]
setblock 158 180 285 minecraft:light[level=12]
setblock 158 180 299 minecraft:light[level=12]
setblock 158 180 306 minecraft:light[level=12]
setblock 158 180 313 minecraft:light[level=12]
setblock 165 180 278 minecraft:light[level=12]
setblock 165 180 285 minecraft:light[level=12]
setblock 165 180 292 minecraft:light[level=12]
setblock 165 180 299 minecraft:light[level=12]
setblock 165 180 306 minecraft:light[level=12]
setblock 165 180 313 minecraft:light[level=12]
setblock 166 180 309 minecraft:packed_ice
setblock 166 180 313 minecraft:packed_ice
setblock 169 180 276 minecraft:snow_block
fill 169 180 277 169 181 277 minecraft:packed_ice
fill 170 180 276 170 183 276 minecraft:packed_ice
fill 170 180 289 170 181 289 minecraft:blue_ice
setblock 172 180 278 minecraft:snow_block
setblock 172 180 279 minecraft:packed_ice
setblock 172 180 285 minecraft:light[level=12]
setblock 172 180 292 minecraft:light[level=12]
setblock 172 180 299 minecraft:light[level=12]
setblock 172 180 306 minecraft:light[level=12]
setblock 172 180 313 minecraft:light[level=12]
setblock 173 180 277 minecraft:snow_block
fill 173 180 278 173 183 278 minecraft:packed_ice
setblock 174 180 276 minecraft:snow_block
fill 174 180 277 174 183 277 minecraft:packed_ice
setblock 174 180 316 minecraft:snow_block
fill 175 180 276 175 183 276 minecraft:packed_ice
setblock 175 180 316 minecraft:packed_ice
setblock 176 180 279 minecraft:snow_block
setblock 177 180 278 minecraft:snow_block
setblock 177 180 279 minecraft:packed_ice
setblock 178 180 277 minecraft:snow_block
fill 178 180 278 178 181 278 minecraft:packed_ice
setblock 179 180 276 minecraft:snow_block
fill 179 180 277 179 181 277 minecraft:packed_ice
setblock 179 180 285 minecraft:light[level=12]
setblock 179 180 292 minecraft:light[level=12]
setblock 179 180 299 minecraft:light[level=12]
setblock 179 180 306 minecraft:light[level=12]
setblock 179 180 313 minecraft:light[level=12]
fill 180 180 276 180 182 276 minecraft:packed_ice
setblock 180 180 280 minecraft:snow_block
setblock 180 180 281 minecraft:packed_ice
setblock 181 180 279 minecraft:snow_block
fill 181 180 280 181 182 280 minecraft:packed_ice
setblock 181 180 284 minecraft:snow_block
setblock 182 180 278 minecraft:snow_block
fill 182 180 279 182 183 279 minecraft:packed_ice
setblock 182 180 283 minecraft:snow_block
fill 182 180 284 182 183 284 minecraft:packed_ice
setblock 142 181 277 minecraft:snow_block
setblock 142 181 278 minecraft:packed_ice
fill 142 181 303 142 184 303 minecraft:packed_ice
fill 145 181 281 145 188 281 minecraft:snow_block
setblock 148 181 276 minecraft:snow_block
setblock 148 181 316 minecraft:snow_block
fill 149 181 276 149 182 276 minecraft:packed_ice
fill 149 181 316 149 184 316 minecraft:packed_ice
setblock 153 181 276 minecraft:snow_block
setblock 153 181 316 minecraft:snow_block
setblock 154 181 276 minecraft:packed_ice
fill 154 181 316 154 182 316 minecraft:packed_ice
fill 155 181 317 155 234 317 minecraft:packed_ice
fill 164 181 279 164 187 279 minecraft:packed_ice
setblock 168 181 276 minecraft:snow_block
fill 169 181 276 169 184 276 minecraft:packed_ice
setblock 171 181 278 minecraft:snow_block
setblock 172 181 277 minecraft:snow_block
fill 172 181 278 172 184 278 minecraft:packed_ice
setblock 173 181 276 minecraft:snow_block
fill 173 181 277 173 184 277 minecraft:packed_ice
fill 174 181 276 174 184 276 minecraft:packed_ice
setblock 175 181 279 minecraft:snow_block
setblock 176 181 278 minecraft:snow_block
setblock 177 181 277 minecraft:snow_block
setblock 177 181 278 minecraft:packed_ice
setblock 178 181 276 minecraft:snow_block
fill 178 181 277 178 182 277 minecraft:packed_ice
fill 179 181 276 179 183 276 minecraft:packed_ice
setblock 181 181 278 minecraft:snow_block
setblock 181 181 279 minecraft:packed_ice
setblock 181 181 283 minecraft:snow_block
setblock 182 181 277 minecraft:snow_block
fill 182 181 278 182 184 278 minecraft:packed_ice
setblock 182 181 282 minecraft:snow_block
fill 182 181 283 182 184 283 minecraft:packed_ice
setblock 183 181 283 minecraft:light_blue_concrete
setblock 141 182 286 minecraft:white_concrete
fill 141 182 303 141 184 306 minecraft:packed_ice
setblock 141 182 307 minecraft:white_concrete
fill 141 182 308 141 185 310 minecraft:packed_ice
setblock 142 182 306 minecraft:snow_block
fill 142 182 307 142 185 307 minecraft:packed_ice
fill 148 182 316 148 185 316 minecraft:packed_ice
setblock 152 182 276 minecraft:snow_block
setblock 152 182 316 minecraft:snow_block
setblock 153 182 276 minecraft:packed_ice
setblock 153 182 316 minecraft:packed_ice
setblock 155 182 275 minecraft:white_concrete
fill 156 182 275 156 217 275 minecraft:packed_ice
setblock 165 182 275 minecraft:white_concrete
fill 166 182 275 166 235 275 minecraft:packed_ice
fill 168 182 276 168 185 276 minecraft:packed_ice
fill 170 182 289 170 188 289 minecraft:packed_ice
setblock 171 182 277 minecraft:snow_block
fill 171 182 278 171 183 278 minecraft:packed_ice
setblock 172 182 276 minecraft:snow_block
fill 172 182 277 172 185 277 minecraft:packed_ice
fill 173 182 276 173 185 276 minecraft:packed_ice
setblock 175 182 278 minecraft:snow_block
setblock 176 182 277 minecraft:snow_block
setblock 176 182 278 minecraft:packed_ice
setblock 177 182 276 minecraft:snow_block
fill 177 182 277 177 183 277 minecraft:packed_ice
fill 178 182 276 178 184 276 minecraft:packed_ice
setblock 181 182 282 minecraft:snow_block
setblock 182 182 276 minecraft:snow_block
setblock 182 182 277 minecraft:packed_ice
setblock 182 182 281 minecraft:snow_block
fill 182 182 282 182 185 282 minecraft:packed_ice
fill 183 182 283 183 237 283 minecraft:packed_ice
fill 141 183 286 141 237 286 minecraft:packed_ice
fill 141 183 307 141 237 307 minecraft:packed_ice
setblock 142 183 305 minecraft:snow_block
fill 142 183 306 142 186 306 minecraft:packed_ice
fill 142 183 308 142 184 308 minecraft:packed_ice
setblock 151 183 316 minecraft:snow_block
setblock 151 183 317 minecraft:white_concrete
fill 152 183 316 152 186 316 minecraft:packed_ice
fill 155 183 275 155 237 275 minecraft:packed_ice
fill 165 183 275 165 210 275 minecraft:packed_ice
fill 169 183 289 169 188 289 minecraft:packed_ice
setblock 170 183 277 minecraft:snow_block
fill 170 183 288 170 188 288 minecraft:packed_ice
setblock 171 183 276 minecraft:snow_block
fill 171 183 277 171 186 277 minecraft:packed_ice
fill 172 183 276 172 186 276 minecraft:packed_ice
setblock 174 183 278 minecraft:snow_block
setblock 175 183 277 minecraft:snow_block
setblock 176 183 276 minecraft:snow_block
fill 176 183 277 176 184 277 minecraft:packed_ice
fill 177 183 276 177 186 276 minecraft:packed_ice
setblock 182 183 280 minecraft:snow_block
fill 182 183 281 182 186 281 minecraft:packed_ice
setblock 182 183 285 minecraft:snow_block
fill 141 184 282 141 232 284 minecraft:packed_ice
setblock 141 184 285 minecraft:white_concrete
setblock 142 184 304 minecraft:snow_block
fill 142 184 305 142 187 305 minecraft:packed_ice
setblock 142 184 309 minecraft:snow_block
fill 142 184 310 142 187 310 minecraft:packed_ice
setblock 144 184 278 minecraft:light[level=15]
fill 144 184 281 144 188 281 minecraft:snow_block
setblock 144 184 286 minecraft:light[level=15]
setblock 144 184 294 minecraft:light[level=15]
setblock 144 184 302 minecraft:light[level=15]
setblock 144 184 310 minecraft:light[level=15]
fill 145 184 280 145 188 280 minecraft:snow_block
fill 145 184 282 145 188 282 minecraft:snow_block
fill 146 184 281 146 188 281 minecraft:snow_block
fill 147 184 316 147 186 316 minecraft:packed_ice
fill 148 184 312 148 190 312 minecraft:packed_ice
setblock 150 184 316 minecraft:snow_block
fill 151 184 316 151 187 317 minecraft:packed_ice
setblock 152 184 278 minecraft:light[level=15]
setblock 152 184 286 minecraft:light[level=15]
setblock 152 184 294 minecraft:light[level=15]
setblock 152 184 310 minecraft:light[level=15]
setblock 160 184 278 minecraft:light[level=15]
setblock 160 184 286 minecraft:light[level=15]
setblock 160 184 294 minecraft:light[level=15]
setblock 160 184 302 minecraft:light[level=15]
setblock 160 184 310 minecraft:light[level=15]
setblock 168 184 278 minecraft:light[level=15]
setblock 168 184 286 minecraft:light[level=15]
setblock 168 184 294 minecraft:light[level=15]
setblock 168 184 302 minecraft:light[level=15]
setblock 168 184 310 minecraft:light[level=15]
fill 169 184 288 169 188 288 minecraft:packed_ice
setblock 170 184 276 minecraft:snow_block
fill 170 184 277 170 187 277 minecraft:packed_ice
fill 170 184 290 170 188 290 minecraft:packed_ice
fill 171 184 276 171 187 276 minecraft:packed_ice
fill 171 184 288 171 188 289 minecraft:packed_ice
setblock 173 184 278 minecraft:snow_block
fill 173 184 317 173 200 317 minecraft:packed_ice
setblock 174 184 277 minecraft:snow_block
setblock 174 184 317 minecraft:white_concrete
setblock 175 184 276 minecraft:snow_block
fill 175 184 277 175 185 277 minecraft:packed_ice
fill 175 184 317 175 237 317 minecraft:packed_ice
fill 176 184 276 176 187 276 minecraft:packed_ice
setblock 176 184 278 minecraft:light[level=15]
setblock 176 184 286 minecraft:light[level=15]
setblock 176 184 294 minecraft:light[level=15]
setblock 176 184 302 minecraft:light[level=15]
setblock 182 184 279 minecraft:snow_block
fill 182 184 280 182 187 280 minecraft:packed_ice
setblock 182 184 284 minecraft:snow_block
fill 182 184 285 182 187 285 minecraft:packed_ice
fill 141 185 285 141 202 285 minecraft:packed_ice
fill 141 185 303 141 235 304 minecraft:packed_ice
setblock 141 185 305 minecraft:light_blue_concrete
fill 141 185 306 141 237 306 minecraft:packed_ice
setblock 142 185 303 minecraft:snow_block
fill 142 185 304 142 188 304 minecraft:packed_ice
setblock 142 185 308 minecraft:snow_block
fill 142 185 309 143 187 309 minecraft:packed_ice
fill 142 185 311 142 185 312 minecraft:packed_ice
fill 143 185 305 143 185 306 minecraft:packed_ice
setblock 143 185 307 minecraft:snow_block
fill 143 185 308 143 188 308 minecraft:packed_ice
fill 146 185 316 146 187 316 minecraft:packed_ice
setblock 149 185 316 minecraft:snow_block
fill 150 185 316 150 188 316 minecraft:packed_ice
fill 168 185 289 168 188 289 minecraft:packed_ice
setblock 169 185 276 minecraft:snow_block
fill 169 185 277 169 188 277 minecraft:packed_ice
fill 169 185 287 170 188 287 minecraft:packed_ice
fill 169 185 290 169 188 290 minecraft:packed_ice
fill 170 185 276 170 188 276 minecraft:packed_ice
fill 171 185 290 171 188 290 minecraft:packed_ice
setblock 173 185 277 minecraft:snow_block
setblock 174 185 276 minecraft:snow_block
fill 174 185 277 174 188 277 minecraft:packed_ice
fill 174 185 317 174 188 317 minecraft:packed_ice
fill 175 185 276 175 188 276 minecraft:packed_ice
fill 182 185 279 182 188 279 minecraft:packed_ice
setblock 182 185 283 minecraft:snow_block
fill 182 185 284 182 188 284 minecraft:packed_ice
fill 182 185 286 182 186 286 minecraft:packed_ice
fill 141 186 305 141 237 305 minecraft:packed_ice
setblock 141 186 308 minecraft:white_concrete
fill 141 186 309 141 209 310 minecraft:packed_ice
setblock 142 186 302 minecraft:snow_block
fill 142 186 303 142 189 303 minecraft:packed_ice
setblock 142 186 307 minecraft:snow_block
fill 142 186 308 142 189 308 minecraft:packed_ice
setblock 142 186 311 minecraft:packed_ice
setblock 142 186 312 minecraft:snow_block
fill 142 186 313 142 189 313 minecraft:packed_ice
fill 143 186 304 143 186 305 minecraft:packed_ice
setblock 143 186 306 minecraft:snow_block
fill 143 186 307 144 188 307 minecraft:packed_ice
setblock 143 186 310 minecraft:packed_ice
setblock 143 186 311 minecraft:snow_block
setblock 144 186 278 minecraft:light[level=12]
fill 144 186 280 144 188 280 minecraft:snow_block
fill 144 186 282 144 188 282 minecraft:snow_block
setblock 144 186 285 minecraft:light[level=12]
setblock 144 186 292 minecraft:light[level=12]
setblock 144 186 299 minecraft:light[level=12]
fill 144 186 306 144 189 306 minecraft:packed_ice
fill 144 186 308 144 187 308 minecraft:packed_ice
setblock 144 186 313 minecraft:light[level=12]
fill 145 186 316 145 188 316 minecraft:packed_ice
fill 146 186 280 146 188 280 minecraft:snow_block
fill 146 186 282 146 188 282 minecraft:snow_block
setblock 148 186 316 minecraft:snow_block
fill 149 186 316 149 189 316 minecraft:packed_ice
setblock 151 186 278 minecraft:light[level=12]
setblock 151 186 285 minecraft:light[level=12]
setblock 151 186 292 minecraft:light[level=12]
setblock 151 186 299 minecraft:light[level=12]
setblock 151 186 306 minecraft:light[level=12]
setblock 151 186 313 minecraft:light[level=12]
fill 154 186 314 154 192 314 minecraft:packed_ice
setblock 158 186 278 minecraft:light[level=12]
setblock 158 186 285 minecraft:light[level=12]
setblock 158 186 299 minecraft:light[level=12]
setblock 158 186 306 minecraft:light[level=12]
setblock 158 186 313 minecraft:light[level=12]
fill 163 186 279 163 187 279 minecraft:packed_ice
fill 164 186 278 164 187 278 minecraft:packed_ice
fill 164 186 280 164 187 280 minecraft:packed_ice
setblock 165 186 278 minecraft:light[level=12]
fill 165 186 279 165 187 279 minecraft:packed_ice
setblock 165 186 285 minecraft:light[level=12]
setblock 165 186 292 minecraft:light[level=12]
setblock 165 186 299 minecraft:light[level=12]
setblock 165 186 306 minecraft:light[level=12]
setblock 165 186 313 minecraft:light[level=12]
setblock 167 186 276 minecraft:packed_ice
setblock 168 186 276 minecraft:snow_block
fill 168 186 288 168 188 288 minecraft:packed_ice
fill 168 186 290 168 188 290 minecraft:packed_ice
fill 169 186 276 169 189 276 minecraft:packed_ice
fill 170 186 291 170 188 291 minecraft:packed_ice
fill 171 186 287 171 188 287 minecraft:packed_ice
setblock 172 186 277 minecraft:snow_block
setblock 172 186 278 minecraft:light[level=12]
setblock 172 186 285 minecraft:light[level=12]
fill 172 186 288 172 188 289 minecraft:packed_ice
setblock 172 186 292 minecraft:light[level=12]
setblock 172 186 299 minecraft:light[level=12]
setblock 172 186 306 minecraft:light[level=12]
setblock 172 186 313 minecraft:light[level=12]
setblock 173 186 276 minecraft:snow_block
fill 173 186 277 173 189 277 minecraft:packed_ice
fill 174 186 276 174 189 276 minecraft:packed_ice
setblock 179 186 278 minecraft:light[level=12]
setblock 179 186 285 minecraft:light[level=12]
setblock 179 186 292 minecraft:light[level=12]
setblock 179 186 299 minecraft:light[level=12]
setblock 179 186 306 minecraft:light[level=12]
setblock 179 186 313 minecraft:light[level=12]
setblock 182 186 282 minecraft:snow_block
fill 182 186 283 182 189 283 minecraft:packed_ice
setblock 182 186 306 minecraft:packed_ice
setblock 182 186 307 minecraft:snow_block
fill 182 186 308 182 187 310 minecraft:packed_ice
setblock 141 187 308 minecraft:light_blue_concrete
fill 142 187 302 142 190 302 minecraft:packed_ice
setblock 142 187 306 minecraft:snow_block
fill 142 187 307 142 190 307 minecraft:packed_ice
setblock 142 187 311 minecraft:snow_block
fill 142 187 312 143 189 312 minecraft:packed_ice
fill 142 187 314 142 187 315 minecraft:packed_ice
fill 143 187 303 143 187 304 minecraft:packed_ice
setblock 143 187 305 minecraft:snow_block
fill 143 187 306 143 190 306 minecraft:packed_ice
setblock 143 187 310 minecraft:snow_block
fill 143 187 311 144 189 311 minecraft:packed_ice
fill 143 187 313 143 188 313 minecraft:packed_ice
fill 143 187 316 144 189 316 minecraft:packed_ice
setblock 144 187 304 minecraft:snow_block
fill 144 187 305 144 190 305 minecraft:packed_ice
setblock 144 187 309 minecraft:snow_block
fill 144 187 310 144 190 310 minecraft:packed_ice
setblock 145 187 275 minecraft:light_blue_concrete
fill 145 187 296 145 193 296 minecraft:packed_ice
setblock 145 187 307 minecraft:packed_ice
setblock 145 187 308 minecraft:snow_block
fill 146 187 315 147 187 315 minecraft:packed_ice
setblock 147 187 316 minecraft:snow_block
setblock 148 187 315 minecraft:snow_block
fill 148 187 316 148 190 316 minecraft:packed_ice
schedule function dropper:buildpart/63_7 1t
