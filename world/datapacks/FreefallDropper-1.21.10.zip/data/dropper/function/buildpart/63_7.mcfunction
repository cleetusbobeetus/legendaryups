fill 149 187 315 150 189 315 minecraft:packed_ice
setblock 152 187 316 minecraft:snow_block
setblock 166 187 276 minecraft:packed_ice
setblock 167 187 276 minecraft:snow_block
fill 168 187 276 168 189 277 minecraft:packed_ice
fill 168 187 287 168 188 287 minecraft:packed_ice
fill 169 187 286 170 188 286 minecraft:packed_ice
fill 169 187 291 169 188 291 minecraft:packed_ice
fill 169 187 316 171 187 316 minecraft:packed_ice
setblock 171 187 277 minecraft:snow_block
fill 171 187 291 171 188 291 minecraft:packed_ice
setblock 172 187 276 minecraft:snow_block
fill 172 187 277 172 190 277 minecraft:packed_ice
fill 172 187 287 172 188 287 minecraft:packed_ice
fill 172 187 290 172 188 290 minecraft:packed_ice
setblock 172 187 316 minecraft:snow_block
fill 173 187 276 173 190 276 minecraft:packed_ice
fill 173 187 316 173 190 316 minecraft:packed_ice
setblock 174 187 275 minecraft:light_blue_concrete
setblock 177 187 276 minecraft:snow_block
setblock 182 187 281 minecraft:snow_block
fill 182 187 282 182 190 282 minecraft:packed_ice
setblock 182 187 286 minecraft:snow_block
fill 182 187 287 182 189 288 minecraft:packed_ice
setblock 182 187 305 minecraft:packed_ice
setblock 182 187 306 minecraft:snow_block
fill 182 187 307 182 190 307 minecraft:packed_ice
setblock 182 187 311 minecraft:snow_block
fill 182 187 312 182 188 314 minecraft:packed_ice
fill 141 188 308 141 237 308 minecraft:packed_ice
fill 142 188 283 142 188 284 minecraft:packed_ice
setblock 142 188 285 minecraft:snow_block
fill 142 188 286 142 189 288 minecraft:packed_ice
fill 142 188 301 142 191 301 minecraft:packed_ice
setblock 142 188 305 minecraft:snow_block
fill 142 188 306 142 191 306 minecraft:packed_ice
setblock 142 188 309 minecraft:packed_ice
setblock 142 188 310 minecraft:snow_block
fill 142 188 311 142 191 311 minecraft:packed_ice
setblock 142 188 314 minecraft:packed_ice
setblock 142 188 315 minecraft:snow_block
fill 142 188 316 142 191 316 minecraft:packed_ice
setblock 143 188 281 minecraft:snow_block
fill 143 188 302 143 188 303 minecraft:packed_ice
setblock 143 188 304 minecraft:snow_block
fill 143 188 305 143 191 305 minecraft:packed_ice
setblock 143 188 309 minecraft:snow_block
fill 143 188 310 143 191 310 minecraft:packed_ice
setblock 143 188 314 minecraft:snow_block
fill 144 188 304 144 191 304 minecraft:packed_ice
setblock 144 188 308 minecraft:snow_block
fill 144 188 309 145 190 309 minecraft:packed_ice
setblock 144 188 312 minecraft:packed_ice
fill 144 188 315 146 188 315 minecraft:packed_ice
fill 145 188 275 145 190 275 minecraft:packed_ice
setblock 145 188 279 minecraft:snow_block
setblock 145 188 283 minecraft:snow_block
fill 145 188 305 145 188 306 minecraft:packed_ice
setblock 145 188 307 minecraft:snow_block
fill 145 188 308 145 191 308 minecraft:packed_ice
fill 145 188 310 145 189 310 minecraft:packed_ice
fill 146 188 314 147 188 314 minecraft:packed_ice
setblock 146 188 316 minecraft:snow_block
setblock 147 188 281 minecraft:snow_block
fill 147 188 312 147 190 312 minecraft:packed_ice
setblock 147 188 315 minecraft:snow_block
fill 147 188 316 147 191 316 minecraft:packed_ice
fill 148 188 276 148 190 276 minecraft:packed_ice
fill 148 188 311 148 190 311 minecraft:packed_ice
fill 148 188 313 148 192 313 minecraft:packed_ice
setblock 148 188 314 minecraft:snow_block
fill 148 188 315 148 191 315 minecraft:packed_ice
fill 149 188 312 149 190 312 minecraft:packed_ice
fill 149 188 314 149 191 314 minecraft:packed_ice
setblock 151 188 315 minecraft:packed_ice
setblock 151 188 316 minecraft:snow_block
fill 151 188 317 151 234 317 minecraft:packed_ice
fill 152 188 316 152 191 316 minecraft:packed_ice
setblock 165 188 276 minecraft:packed_ice
setblock 165 188 317 minecraft:light_blue_concrete
setblock 166 188 276 minecraft:snow_block
fill 167 188 276 167 190 277 minecraft:packed_ice
fill 167 188 287 167 188 290 minecraft:packed_ice
fill 167 188 316 170 188 316 minecraft:packed_ice
setblock 168 188 286 minecraft:packed_ice
setblock 168 188 291 minecraft:packed_ice
setblock 170 188 277 minecraft:snow_block
fill 170 188 278 170 189 278 minecraft:packed_ice
setblock 171 188 276 minecraft:snow_block
fill 171 188 277 171 191 277 minecraft:packed_ice
setblock 171 188 286 minecraft:packed_ice
setblock 171 188 316 minecraft:snow_block
fill 172 188 276 172 191 276 minecraft:packed_ice
setblock 172 188 291 minecraft:packed_ice
fill 172 188 316 172 191 316 minecraft:packed_ice
fill 173 188 288 173 188 289 minecraft:packed_ice
fill 174 188 275 174 237 275 minecraft:packed_ice
fill 174 188 316 175 188 316 minecraft:packed_ice
setblock 176 188 276 minecraft:snow_block
fill 177 188 276 177 191 276 minecraft:packed_ice
fill 180 188 289 180 192 289 minecraft:packed_ice
fill 181 188 309 181 188 310 minecraft:packed_ice
setblock 181 188 316 minecraft:snow_block
fill 182 188 278 182 189 278 minecraft:packed_ice
setblock 182 188 280 minecraft:snow_block
fill 182 188 281 182 191 281 minecraft:packed_ice
setblock 182 188 285 minecraft:snow_block
fill 182 188 286 182 191 286 minecraft:packed_ice
setblock 182 188 289 minecraft:packed_ice
setblock 182 188 304 minecraft:packed_ice
setblock 182 188 305 minecraft:snow_block
fill 182 188 306 182 191 306 minecraft:packed_ice
fill 182 188 308 182 188 309 minecraft:packed_ice
setblock 182 188 310 minecraft:snow_block
fill 182 188 311 182 191 311 minecraft:packed_ice
setblock 182 188 315 minecraft:snow_block
fill 182 188 316 182 191 316 minecraft:packed_ice
setblock 142 189 283 minecraft:packed_ice
setblock 142 189 284 minecraft:snow_block
fill 142 189 285 142 192 285 minecraft:packed_ice
setblock 142 189 289 minecraft:snow_block
fill 142 189 290 142 191 291 minecraft:packed_ice
setblock 142 189 304 minecraft:snow_block
fill 142 189 305 142 192 305 minecraft:packed_ice
setblock 142 189 309 minecraft:snow_block
fill 142 189 310 142 192 310 minecraft:packed_ice
setblock 142 189 314 minecraft:snow_block
fill 142 189 315 145 189 315 minecraft:packed_ice
setblock 143 189 302 minecraft:packed_ice
setblock 143 189 303 minecraft:snow_block
fill 143 189 304 143 192 304 minecraft:packed_ice
setblock 143 189 307 minecraft:packed_ice
setblock 143 189 308 minecraft:snow_block
fill 143 189 309 143 192 309 minecraft:packed_ice
setblock 143 189 313 minecraft:snow_block
fill 143 189 314 146 189 314 minecraft:packed_ice
fill 144 189 303 144 192 303 minecraft:packed_ice
setblock 144 189 307 minecraft:snow_block
fill 144 189 308 144 192 308 minecraft:packed_ice
setblock 144 189 312 minecraft:snow_block
fill 144 189 313 144 192 313 minecraft:packed_ice
setblock 145 189 305 minecraft:packed_ice
setblock 145 189 306 minecraft:snow_block
fill 145 189 307 145 192 307 minecraft:packed_ice
setblock 145 189 311 minecraft:snow_block
fill 145 189 312 145 192 312 minecraft:packed_ice
setblock 145 189 316 minecraft:snow_block
fill 146 189 276 147 191 276 minecraft:packed_ice
fill 146 189 308 146 189 309 minecraft:packed_ice
setblock 146 189 315 minecraft:snow_block
fill 146 189 316 146 192 316 minecraft:packed_ice
fill 147 189 311 147 190 311 minecraft:packed_ice
setblock 147 189 313 minecraft:packed_ice
setblock 147 189 314 minecraft:snow_block
fill 147 189 315 147 192 315 minecraft:packed_ice
fill 148 189 314 148 192 314 minecraft:packed_ice
setblock 149 189 276 minecraft:packed_ice
fill 149 189 311 149 190 311 minecraft:packed_ice
fill 149 189 313 149 190 313 minecraft:packed_ice
fill 150 189 314 150 190 314 minecraft:packed_ice
setblock 150 189 316 minecraft:snow_block
setblock 151 189 315 minecraft:snow_block
fill 151 189 316 151 192 316 minecraft:packed_ice
setblock 152 189 317 minecraft:white_concrete
fill 153 189 317 154 211 317 minecraft:packed_ice
setblock 164 189 276 minecraft:packed_ice
setblock 165 189 276 minecraft:snow_block
fill 165 189 317 165 231 317 minecraft:packed_ice
fill 166 189 276 166 191 277 minecraft:packed_ice
fill 166 189 316 169 189 316 minecraft:packed_ice
fill 168 189 315 170 189 315 minecraft:packed_ice
setblock 169 189 277 minecraft:snow_block
fill 169 189 278 169 190 278 minecraft:packed_ice
fill 169 189 288 170 190 289 minecraft:blue_ice
setblock 170 189 276 minecraft:snow_block
fill 170 189 277 170 192 277 minecraft:packed_ice
setblock 170 189 316 minecraft:snow_block
fill 171 189 276 171 192 276 minecraft:packed_ice
setblock 171 189 289 minecraft:blue_ice
setblock 171 189 315 minecraft:snow_block
fill 171 189 316 171 192 316 minecraft:packed_ice
setblock 174 189 316 minecraft:packed_ice
setblock 174 189 317 minecraft:light_blue_concrete
setblock 175 189 276 minecraft:snow_block
setblock 175 189 316 minecraft:snow_block
fill 176 189 276 176 192 276 minecraft:packed_ice
fill 176 189 316 179 189 316 minecraft:packed_ice
setblock 180 189 316 minecraft:snow_block
fill 181 189 276 182 191 276 minecraft:packed_ice
fill 181 189 307 181 189 309 minecraft:packed_ice
setblock 181 189 310 minecraft:snow_block
fill 181 189 311 181 190 313 minecraft:packed_ice
fill 181 189 316 181 192 316 minecraft:packed_ice
fill 182 189 277 182 190 277 minecraft:packed_ice
setblock 182 189 279 minecraft:snow_block
fill 182 189 280 182 192 280 minecraft:packed_ice
setblock 182 189 284 minecraft:snow_block
fill 182 189 285 182 192 285 minecraft:packed_ice
setblock 182 189 289 minecraft:snow_block
fill 182 189 290 182 192 290 minecraft:packed_ice
setblock 182 189 304 minecraft:snow_block
fill 182 189 305 182 192 305 minecraft:packed_ice
setblock 182 189 308 minecraft:packed_ice
setblock 182 189 309 minecraft:snow_block
fill 182 189 310 182 192 310 minecraft:packed_ice
fill 182 189 312 182 189 313 minecraft:packed_ice
setblock 182 189 314 minecraft:snow_block
fill 182 189 315 182 192 315 minecraft:packed_ice
setblock 142 190 283 minecraft:snow_block
fill 142 190 284 142 192 284 minecraft:packed_ice
fill 142 190 286 142 190 287 minecraft:packed_ice
setblock 142 190 288 minecraft:snow_block
fill 142 190 289 143 192 289 minecraft:packed_ice
setblock 142 190 292 minecraft:packed_ice
setblock 142 190 293 minecraft:snow_block
fill 142 190 294 142 193 294 minecraft:packed_ice
fill 142 190 300 142 192 300 minecraft:packed_ice
setblock 142 190 303 minecraft:snow_block
fill 142 190 304 142 193 304 minecraft:packed_ice
setblock 142 190 308 minecraft:snow_block
fill 142 190 309 142 193 309 minecraft:packed_ice
setblock 142 190 312 minecraft:packed_ice
setblock 142 190 313 minecraft:snow_block
fill 142 190 314 144 190 315 minecraft:packed_ice
setblock 143 190 286 minecraft:packed_ice
setblock 143 190 287 minecraft:snow_block
fill 143 190 288 143 193 288 minecraft:packed_ice
fill 143 190 290 143 190 291 minecraft:packed_ice
setblock 143 190 301 minecraft:packed_ice
setblock 143 190 302 minecraft:snow_block
fill 143 190 303 143 193 303 minecraft:packed_ice
setblock 143 190 307 minecraft:snow_block
fill 143 190 308 143 193 308 minecraft:packed_ice
setblock 143 190 311 minecraft:packed_ice
setblock 143 190 312 minecraft:snow_block
fill 143 190 313 143 193 313 minecraft:packed_ice
setblock 143 190 316 minecraft:packed_ice
setblock 144 190 306 minecraft:snow_block
fill 144 190 307 144 193 307 minecraft:packed_ice
setblock 144 190 311 minecraft:snow_block
fill 144 190 312 144 193 312 minecraft:packed_ice
setblock 144 190 316 minecraft:snow_block
fill 145 190 276 145 193 276 minecraft:packed_ice
setblock 145 190 305 minecraft:snow_block
fill 145 190 306 145 192 306 minecraft:packed_ice
setblock 145 190 310 minecraft:snow_block
fill 145 190 311 145 193 311 minecraft:packed_ice
fill 145 190 313 145 190 314 minecraft:packed_ice
setblock 145 190 315 minecraft:snow_block
fill 145 190 316 145 193 316 minecraft:packed_ice
fill 146 190 307 146 190 308 minecraft:packed_ice
setblock 146 190 309 minecraft:snow_block
fill 146 190 310 146 192 310 minecraft:packed_ice
setblock 146 190 313 minecraft:packed_ice
setblock 146 190 314 minecraft:snow_block
fill 146 190 315 146 193 315 minecraft:packed_ice
setblock 147 190 313 minecraft:snow_block
fill 147 190 314 147 193 314 minecraft:packed_ice
setblock 149 190 276 minecraft:snow_block
setblock 149 190 315 minecraft:packed_ice
setblock 149 190 316 minecraft:snow_block
setblock 150 190 315 minecraft:snow_block
fill 150 190 316 150 193 316 minecraft:packed_ice
fill 151 190 315 151 192 315 minecraft:packed_ice
fill 152 190 317 152 238 317 minecraft:packed_ice
setblock 164 190 276 minecraft:snow_block
setblock 164 190 316 minecraft:snow_block
fill 165 190 276 165 193 276 minecraft:packed_ice
fill 165 190 316 168 190 316 minecraft:packed_ice
fill 166 190 315 169 190 315 minecraft:packed_ice
setblock 168 190 276 minecraft:packed_ice
setblock 168 190 277 minecraft:snow_block
setblock 168 190 278 minecraft:packed_ice
setblock 169 190 276 minecraft:snow_block
fill 169 190 277 169 193 277 minecraft:packed_ice
setblock 169 190 316 minecraft:snow_block
fill 170 190 276 170 193 276 minecraft:packed_ice
setblock 170 190 315 minecraft:snow_block
fill 170 190 316 170 193 316 minecraft:packed_ice
fill 171 190 315 173 191 315 minecraft:packed_ice
setblock 173 190 277 minecraft:snow_block
setblock 174 190 276 minecraft:snow_block
setblock 174 190 316 minecraft:snow_block
fill 174 190 317 174 198 317 minecraft:packed_ice
fill 175 190 276 175 193 276 minecraft:packed_ice
fill 175 190 316 178 190 316 minecraft:packed_ice
setblock 178 190 276 minecraft:packed_ice
setblock 179 190 276 minecraft:snow_block
fill 179 190 311 180 191 311 minecraft:blue_ice
setblock 179 190 316 minecraft:snow_block
fill 180 190 276 180 193 276 minecraft:packed_ice
fill 180 190 310 180 191 310 minecraft:blue_ice
fill 180 190 312 180 191 312 minecraft:blue_ice
fill 180 190 316 180 193 316 minecraft:packed_ice
setblock 181 190 286 minecraft:packed_ice
fill 181 190 307 181 190 308 minecraft:packed_ice
setblock 181 190 309 minecraft:snow_block
fill 181 190 310 181 193 310 minecraft:packed_ice
setblock 181 190 314 minecraft:snow_block
fill 181 190 315 181 193 315 minecraft:packed_ice
setblock 182 190 278 minecraft:snow_block
fill 182 190 279 182 192 279 minecraft:packed_ice
setblock 182 190 283 minecraft:snow_block
fill 182 190 284 182 193 284 minecraft:packed_ice
setblock 182 190 287 minecraft:packed_ice
setblock 182 190 288 minecraft:snow_block
fill 182 190 289 182 193 289 minecraft:packed_ice
fill 182 190 291 182 191 291 minecraft:packed_ice
setblock 182 190 303 minecraft:snow_block
fill 182 190 304 182 193 304 minecraft:packed_ice
setblock 182 190 308 minecraft:snow_block
fill 182 190 309 182 193 309 minecraft:packed_ice
setblock 182 190 312 minecraft:packed_ice
setblock 182 190 313 minecraft:snow_block
fill 182 190 314 183 193 314 minecraft:packed_ice
setblock 183 190 315 minecraft:white_concrete
setblock 142 191 283 minecraft:packed_ice
setblock 142 191 286 minecraft:packed_ice
setblock 142 191 287 minecraft:snow_block
fill 142 191 288 142 194 288 minecraft:packed_ice
setblock 142 191 292 minecraft:snow_block
fill 142 191 293 143 193 293 minecraft:packed_ice
fill 142 191 295 142 191 296 minecraft:packed_ice
setblock 142 191 297 minecraft:snow_block
fill 142 191 298 142 193 299 minecraft:packed_ice
setblock 142 191 302 minecraft:snow_block
fill 142 191 303 142 194 303 minecraft:packed_ice
setblock 142 191 307 minecraft:snow_block
fill 142 191 308 142 194 308 minecraft:packed_ice
setblock 142 191 312 minecraft:snow_block
fill 142 191 313 142 192 315 minecraft:packed_ice
setblock 143 191 286 minecraft:snow_block
fill 143 191 287 143 194 287 minecraft:packed_ice
setblock 143 191 290 minecraft:packed_ice
setblock 143 191 291 minecraft:snow_block
fill 143 191 292 143 194 292 minecraft:packed_ice
setblock 143 191 301 minecraft:snow_block
fill 143 191 302 143 194 302 minecraft:packed_ice
setblock 143 191 306 minecraft:snow_block
fill 143 191 307 143 194 307 minecraft:packed_ice
setblock 143 191 311 minecraft:snow_block
fill 143 191 312 143 194 312 minecraft:packed_ice
fill 143 191 314 143 191 315 minecraft:packed_ice
setblock 143 191 316 minecraft:snow_block
fill 144 191 276 144 194 276 minecraft:packed_ice
setblock 144 191 289 minecraft:packed_ice
setblock 144 191 305 minecraft:snow_block
fill 144 191 306 144 194 306 minecraft:packed_ice
setblock 144 191 309 minecraft:packed_ice
setblock 144 191 310 minecraft:snow_block
fill 144 191 311 144 194 311 minecraft:packed_ice
setblock 144 191 314 minecraft:packed_ice
setblock 144 191 315 minecraft:snow_block
fill 144 191 316 144 194 316 minecraft:packed_ice
setblock 145 191 275 minecraft:light_blue_concrete
fill 145 191 305 145 192 305 minecraft:packed_ice
setblock 145 191 309 minecraft:snow_block
fill 145 191 310 145 194 310 minecraft:packed_ice
setblock 145 191 313 minecraft:packed_ice
setblock 145 191 314 minecraft:snow_block
fill 145 191 315 145 194 315 minecraft:packed_ice
setblock 146 191 308 minecraft:snow_block
setblock 146 191 309 minecraft:packed_ice
setblock 146 191 313 minecraft:snow_block
fill 146 191 314 146 194 314 minecraft:packed_ice
fill 147 191 313 147 193 313 minecraft:packed_ice
setblock 148 191 276 minecraft:snow_block
setblock 148 191 316 minecraft:snow_block
setblock 149 191 276 minecraft:packed_ice
setblock 149 191 315 minecraft:snow_block
fill 149 191 316 149 194 316 minecraft:packed_ice
setblock 150 191 314 minecraft:snow_block
fill 150 191 315 150 194 315 minecraft:packed_ice
fill 153 191 314 153 192 314 minecraft:packed_ice
fill 154 191 313 154 192 313 minecraft:packed_ice
fill 154 191 315 154 192 315 minecraft:packed_ice
fill 155 191 314 155 192 314 minecraft:packed_ice
setblock 163 191 276 minecraft:snow_block
setblock 163 191 316 minecraft:snow_block
fill 164 191 276 164 194 276 minecraft:packed_ice
fill 164 191 316 167 191 316 minecraft:packed_ice
fill 165 191 277 165 192 277 minecraft:packed_ice
fill 165 191 315 168 191 315 minecraft:packed_ice
setblock 167 191 276 minecraft:packed_ice
setblock 167 191 277 minecraft:snow_block
setblock 168 191 276 minecraft:snow_block
fill 168 191 277 168 194 277 minecraft:packed_ice
setblock 168 191 316 minecraft:snow_block
fill 169 191 276 169 194 276 minecraft:packed_ice
setblock 169 191 315 minecraft:snow_block
fill 169 191 316 169 194 316 minecraft:packed_ice
fill 170 191 288 170 191 289 minecraft:blue_ice
fill 170 191 315 170 194 315 minecraft:packed_ice
setblock 172 191 277 minecraft:snow_block
fill 172 191 299 172 192 314 minecraft:snow_block
setblock 173 191 276 minecraft:snow_block
fill 173 191 279 173 192 312 minecraft:snow_block
setblock 173 191 316 minecraft:snow_block
fill 174 191 276 174 194 276 minecraft:packed_ice
fill 174 191 277 174 192 292 minecraft:snow_block
fill 174 191 316 177 191 316 minecraft:packed_ice
setblock 178 191 276 minecraft:snow_block
setblock 178 191 316 minecraft:snow_block
fill 179 191 276 179 194 276 minecraft:packed_ice
fill 179 191 289 179 192 289 minecraft:packed_ice
setblock 179 191 310 minecraft:blue_ice
setblock 179 191 312 minecraft:blue_ice
setblock 179 191 315 minecraft:snow_block
fill 179 191 316 179 194 316 minecraft:packed_ice
fill 180 191 288 180 192 288 minecraft:packed_ice
fill 180 191 290 180 192 290 minecraft:packed_ice
fill 180 191 315 180 194 315 minecraft:packed_ice
fill 181 191 289 181 192 289 minecraft:packed_ice
setblock 181 191 307 minecraft:packed_ice
setblock 181 191 308 minecraft:snow_block
fill 181 191 309 181 194 309 minecraft:packed_ice
fill 181 191 311 181 191 312 minecraft:packed_ice
setblock 181 191 313 minecraft:snow_block
fill 181 191 314 181 194 314 minecraft:packed_ice
setblock 182 191 277 minecraft:snow_block
fill 182 191 278 182 194 278 minecraft:packed_ice
setblock 182 191 282 minecraft:snow_block
fill 182 191 283 182 193 283 minecraft:packed_ice
setblock 182 191 287 minecraft:snow_block
fill 182 191 288 182 194 288 minecraft:packed_ice
setblock 182 191 292 minecraft:snow_block
fill 182 191 303 182 192 303 minecraft:packed_ice
setblock 182 191 307 minecraft:snow_block
fill 182 191 308 182 194 308 minecraft:packed_ice
setblock 182 191 312 minecraft:snow_block
fill 182 191 313 182 194 313 minecraft:packed_ice
fill 183 191 315 183 233 315 minecraft:packed_ice
setblock 142 192 286 minecraft:snow_block
fill 142 192 287 142 195 287 minecraft:packed_ice
setblock 142 192 290 minecraft:packed_ice
setblock 142 192 291 minecraft:snow_block
fill 142 192 292 142 195 292 minecraft:packed_ice
setblock 142 192 295 minecraft:packed_ice
setblock 142 192 296 minecraft:snow_block
fill 142 192 297 142 195 297 minecraft:packed_ice
setblock 142 192 301 minecraft:snow_block
fill 142 192 302 142 195 302 minecraft:packed_ice
setblock 142 192 306 minecraft:snow_block
fill 142 192 307 142 195 307 minecraft:packed_ice
setblock 142 192 311 minecraft:snow_block
fill 142 192 312 142 195 312 minecraft:packed_ice
setblock 142 192 316 minecraft:snow_block
setblock 143 192 286 minecraft:packed_ice
setblock 143 192 290 minecraft:snow_block
fill 143 192 291 144 194 291 minecraft:packed_ice
setblock 143 192 294 minecraft:packed_ice
setblock 143 192 295 minecraft:snow_block
fill 143 192 296 144 193 296 minecraft:packed_ice
fill 143 192 301 143 195 301 minecraft:packed_ice
setblock 143 192 305 minecraft:snow_block
fill 143 192 306 143 195 306 minecraft:packed_ice
setblock 143 192 310 minecraft:snow_block
fill 143 192 311 143 195 311 minecraft:packed_ice
setblock 143 192 314 minecraft:packed_ice
setblock 143 192 315 minecraft:snow_block
fill 143 192 316 143 195 316 minecraft:packed_ice
setblock 144 192 278 minecraft:light[level=15]
setblock 144 192 285 minecraft:light[level=12]
setblock 144 192 286 minecraft:light[level=15]
setblock 144 192 289 minecraft:snow_block
fill 144 192 290 144 195 290 minecraft:packed_ice
fill 144 192 292 144 193 292 minecraft:packed_ice
setblock 144 192 294 minecraft:light[level=15]
setblock 144 192 299 minecraft:light[level=12]
setblock 144 192 302 minecraft:light[level=15]
setblock 144 192 304 minecraft:snow_block
fill 144 192 305 144 194 305 minecraft:packed_ice
setblock 144 192 309 minecraft:snow_block
fill 144 192 310 144 195 310 minecraft:packed_ice
setblock 144 192 314 minecraft:snow_block
fill 144 192 315 144 195 315 minecraft:packed_ice
fill 145 192 275 145 237 275 minecraft:packed_ice
fill 145 192 295 145 193 295 minecraft:packed_ice
fill 145 192 297 145 193 297 minecraft:packed_ice
setblock 145 192 308 minecraft:snow_block
fill 145 192 309 145 194 309 minecraft:packed_ice
setblock 145 192 313 minecraft:snow_block
fill 145 192 314 145 195 314 minecraft:packed_ice
setblock 146 192 276 minecraft:packed_ice
fill 146 192 296 146 193 296 minecraft:packed_ice
fill 146 192 313 146 194 313 minecraft:packed_ice
setblock 147 192 276 minecraft:snow_block
setblock 147 192 316 minecraft:snow_block
setblock 148 192 276 minecraft:packed_ice
setblock 148 192 315 minecraft:snow_block
fill 148 192 316 148 195 316 minecraft:packed_ice
setblock 149 192 314 minecraft:snow_block
fill 149 192 315 149 195 315 minecraft:packed_ice
setblock 150 192 314 minecraft:packed_ice
setblock 151 192 278 minecraft:light[level=12]
setblock 151 192 285 minecraft:light[level=12]
setblock 151 192 292 minecraft:light[level=12]
setblock 151 192 299 minecraft:light[level=12]
setblock 151 192 306 minecraft:light[level=12]
setblock 151 192 313 minecraft:light[level=12]
setblock 152 192 278 minecraft:light[level=15]
setblock 152 192 286 minecraft:light[level=15]
setblock 152 192 294 minecraft:light[level=15]
setblock 152 192 310 minecraft:light[level=15]
setblock 152 192 316 minecraft:snow_block
setblock 153 192 275 minecraft:white_concrete
setblock 158 192 278 minecraft:light[level=12]
setblock 158 192 285 minecraft:light[level=12]
setblock 158 192 299 minecraft:light[level=12]
setblock 158 192 306 minecraft:light[level=12]
setblock 158 192 313 minecraft:light[level=12]
setblock 160 192 278 minecraft:light[level=15]
setblock 160 192 286 minecraft:light[level=15]
setblock 160 192 294 minecraft:light[level=15]
setblock 160 192 302 minecraft:light[level=15]
setblock 160 192 310 minecraft:light[level=15]
setblock 162 192 276 minecraft:snow_block
setblock 162 192 316 minecraft:snow_block
fill 163 192 276 163 195 276 minecraft:packed_ice
fill 163 192 316 166 192 316 minecraft:packed_ice
fill 164 192 277 164 193 277 minecraft:packed_ice
fill 164 192 315 167 192 315 minecraft:packed_ice
setblock 165 192 278 minecraft:light[level=12]
setblock 165 192 285 minecraft:light[level=12]
setblock 165 192 292 minecraft:light[level=12]
setblock 165 192 299 minecraft:light[level=12]
setblock 165 192 306 minecraft:light[level=12]
setblock 165 192 313 minecraft:light[level=12]
setblock 166 192 276 minecraft:packed_ice
setblock 166 192 277 minecraft:snow_block
setblock 167 192 276 minecraft:snow_block
fill 167 192 277 167 195 277 minecraft:packed_ice
setblock 167 192 316 minecraft:snow_block
fill 168 192 276 168 195 276 minecraft:packed_ice
setblock 168 192 278 minecraft:light[level=15]
setblock 168 192 286 minecraft:light[level=15]
setblock 168 192 294 minecraft:light[level=15]
setblock 168 192 302 minecraft:light[level=15]
setblock 168 192 310 minecraft:light[level=15]
setblock 168 192 314 minecraft:packed_ice
setblock 168 192 315 minecraft:snow_block
fill 168 192 316 168 195 316 minecraft:packed_ice
setblock 169 192 314 minecraft:snow_block
fill 169 192 315 169 195 315 minecraft:packed_ice
setblock 170 192 289 minecraft:blue_ice
setblock 171 192 277 minecraft:snow_block
fill 171 192 315 172 192 315 minecraft:packed_ice
setblock 172 192 276 minecraft:snow_block
setblock 172 192 277 minecraft:packed_ice
setblock 172 192 278 minecraft:light[level=12]
setblock 172 192 285 minecraft:light[level=12]
setblock 172 192 292 minecraft:light[level=12]
setblock 172 192 316 minecraft:snow_block
fill 173 192 276 173 195 276 minecraft:packed_ice
setblock 173 192 315 minecraft:snow_block
fill 173 192 316 176 192 316 minecraft:packed_ice
fill 174 192 315 174 193 315 minecraft:packed_ice
setblock 176 192 278 minecraft:light[level=15]
setblock 176 192 286 minecraft:light[level=15]
setblock 176 192 294 minecraft:light[level=15]
setblock 176 192 302 minecraft:light[level=15]
setblock 177 192 276 minecraft:snow_block
setblock 177 192 316 minecraft:snow_block
fill 178 192 276 178 195 276 minecraft:packed_ice
setblock 178 192 315 minecraft:snow_block
fill 178 192 316 178 195 316 minecraft:packed_ice
setblock 179 192 278 minecraft:light[level=12]
setblock 179 192 285 minecraft:light[level=12]
setblock 179 192 288 minecraft:packed_ice
setblock 179 192 290 minecraft:packed_ice
setblock 179 192 292 minecraft:light[level=12]
setblock 179 192 299 minecraft:light[level=12]
setblock 179 192 306 minecraft:light[level=12]
setblock 179 192 313 minecraft:light[level=12]
fill 179 192 315 179 195 315 minecraft:packed_ice
fill 180 192 311 180 192 312 minecraft:packed_ice
setblock 181 192 276 minecraft:packed_ice
setblock 181 192 288 minecraft:packed_ice
setblock 181 192 290 minecraft:packed_ice
setblock 181 192 307 minecraft:snow_block
fill 181 192 308 181 195 308 minecraft:packed_ice
setblock 181 192 311 minecraft:packed_ice
setblock 181 192 312 minecraft:snow_block
fill 181 192 313 181 195 313 minecraft:packed_ice
setblock 182 192 276 minecraft:snow_block
fill 182 192 277 182 195 277 minecraft:packed_ice
setblock 182 192 281 minecraft:snow_block
setblock 182 192 282 minecraft:packed_ice
setblock 182 192 286 minecraft:snow_block
fill 182 192 287 182 195 287 minecraft:packed_ice
setblock 182 192 291 minecraft:snow_block
fill 182 192 292 182 194 293 minecraft:packed_ice
setblock 182 192 306 minecraft:snow_block
fill 182 192 307 182 195 307 minecraft:packed_ice
setblock 182 192 311 minecraft:snow_block
fill 182 192 312 182 195 312 minecraft:packed_ice
setblock 182 192 316 minecraft:snow_block
setblock 142 193 285 minecraft:snow_block
fill 142 193 286 142 195 286 minecraft:packed_ice
setblock 142 193 289 minecraft:packed_ice
setblock 142 193 290 minecraft:snow_block
fill 142 193 291 142 196 291 minecraft:packed_ice
setblock 142 193 295 minecraft:snow_block
fill 142 193 296 142 196 296 minecraft:packed_ice
setblock 142 193 300 minecraft:snow_block
fill 142 193 301 142 196 301 minecraft:packed_ice
setblock 142 193 305 minecraft:snow_block
fill 142 193 306 142 196 306 minecraft:packed_ice
setblock 142 193 310 minecraft:snow_block
fill 142 193 311 142 196 311 minecraft:packed_ice
fill 142 193 313 142 193 314 minecraft:packed_ice
setblock 142 193 315 minecraft:snow_block
fill 142 193 316 142 196 316 minecraft:packed_ice
setblock 143 193 289 minecraft:snow_block
fill 143 193 290 143 196 290 minecraft:packed_ice
setblock 143 193 294 minecraft:snow_block
fill 143 193 295 143 196 295 minecraft:packed_ice
fill 143 193 297 143 193 298 minecraft:packed_ice
setblock 143 193 299 minecraft:snow_block
fill 143 193 300 143 196 300 minecraft:packed_ice
setblock 143 193 304 minecraft:snow_block
fill 143 193 305 143 196 305 minecraft:packed_ice
setblock 143 193 309 minecraft:snow_block
fill 143 193 310 143 196 310 minecraft:packed_ice
setblock 143 193 314 minecraft:snow_block
fill 143 193 315 143 196 315 minecraft:packed_ice
fill 144 193 289 144 194 289 minecraft:packed_ice
setblock 144 193 293 minecraft:snow_block
fill 144 193 294 144 196 294 minecraft:packed_ice
setblock 144 193 304 minecraft:packed_ice
setblock 144 193 308 minecraft:snow_block
fill 144 193 309 144 196 309 minecraft:packed_ice
setblock 144 193 313 minecraft:snow_block
fill 144 193 314 144 196 314 minecraft:packed_ice
setblock 145 193 307 minecraft:snow_block
fill 145 193 308 145 194 308 minecraft:packed_ice
setblock 145 193 312 minecraft:snow_block
fill 145 193 313 145 194 313 minecraft:packed_ice
setblock 146 193 276 minecraft:snow_block
setblock 146 193 316 minecraft:snow_block
setblock 147 193 276 minecraft:packed_ice
setblock 147 193 315 minecraft:snow_block
fill 147 193 316 147 196 316 minecraft:packed_ice
setblock 148 193 314 minecraft:snow_block
fill 148 193 315 148 196 315 minecraft:packed_ice
setblock 149 193 314 minecraft:packed_ice
setblock 151 193 316 minecraft:snow_block
setblock 152 193 316 minecraft:packed_ice
fill 153 193 275 153 234 275 minecraft:packed_ice
fill 162 193 276 162 196 276 minecraft:packed_ice
fill 162 193 316 165 193 316 minecraft:packed_ice
fill 164 193 315 166 193 315 minecraft:packed_ice
setblock 165 193 277 minecraft:snow_block
setblock 166 193 276 minecraft:snow_block
fill 166 193 277 166 196 277 minecraft:packed_ice
setblock 166 193 316 minecraft:snow_block
fill 167 193 276 167 196 276 minecraft:packed_ice
setblock 167 193 314 minecraft:packed_ice
setblock 167 193 315 minecraft:snow_block
fill 167 193 316 167 196 316 minecraft:packed_ice
setblock 168 193 314 minecraft:snow_block
fill 168 193 315 168 196 315 minecraft:packed_ice
setblock 170 193 277 minecraft:snow_block
setblock 171 193 276 minecraft:snow_block
setblock 171 193 277 minecraft:packed_ice
setblock 171 193 315 minecraft:packed_ice
setblock 171 193 316 minecraft:snow_block
fill 172 193 276 172 196 276 minecraft:packed_ice
fill 172 193 305 172 193 314 minecraft:blue_ice
setblock 172 193 315 minecraft:snow_block
fill 172 193 316 175 193 316 minecraft:packed_ice
fill 173 193 286 173 193 306 minecraft:blue_ice
fill 173 193 315 173 194 315 minecraft:packed_ice
fill 174 193 277 174 193 286 minecraft:blue_ice
setblock 176 193 276 minecraft:snow_block
setblock 176 193 316 minecraft:snow_block
setblock 177 193 276 minecraft:packed_ice
setblock 177 193 315 minecraft:snow_block
fill 177 193 316 177 196 316 minecraft:packed_ice
fill 178 193 315 178 196 315 minecraft:packed_ice
setblock 180 193 311 minecraft:packed_ice
setblock 180 193 312 minecraft:snow_block
fill 180 193 313 180 195 314 minecraft:packed_ice
setblock 181 193 276 minecraft:snow_block
fill 181 193 307 181 194 307 minecraft:packed_ice
setblock 181 193 311 minecraft:snow_block
fill 181 193 312 181 196 312 minecraft:packed_ice
setblock 181 193 316 minecraft:snow_block
fill 182 193 276 182 196 276 minecraft:packed_ice
setblock 182 193 285 minecraft:snow_block
fill 182 193 286 182 195 286 minecraft:packed_ice
setblock 182 193 290 minecraft:snow_block
fill 182 193 291 182 196 291 minecraft:packed_ice
setblock 182 193 294 minecraft:packed_ice
setblock 182 193 305 minecraft:snow_block
fill 182 193 306 182 196 306 minecraft:packed_ice
setblock 182 193 310 minecraft:snow_block
fill 182 193 311 182 196 311 minecraft:packed_ice
setblock 182 193 315 minecraft:snow_block
fill 182 193 316 182 196 316 minecraft:packed_ice
setblock 142 194 285 minecraft:packed_ice
setblock 142 194 289 minecraft:snow_block
fill 142 194 290 142 197 290 minecraft:packed_ice
setblock 142 194 293 minecraft:packed_ice
setblock 142 194 294 minecraft:snow_block
fill 142 194 295 142 197 295 minecraft:packed_ice
setblock 142 194 298 minecraft:packed_ice
setblock 142 194 299 minecraft:snow_block
fill 142 194 300 142 197 300 minecraft:packed_ice
setblock 142 194 304 minecraft:snow_block
fill 142 194 305 142 197 305 minecraft:packed_ice
setblock 142 194 309 minecraft:snow_block
fill 142 194 310 142 197 310 minecraft:packed_ice
setblock 142 194 313 minecraft:packed_ice
setblock 142 194 314 minecraft:snow_block
fill 142 194 315 142 197 315 minecraft:packed_ice
fill 143 194 276 143 195 276 minecraft:packed_ice
setblock 143 194 288 minecraft:snow_block
fill 143 194 289 143 197 289 minecraft:packed_ice
setblock 143 194 293 minecraft:snow_block
fill 143 194 294 143 197 294 minecraft:packed_ice
fill 143 194 296 143 194 297 minecraft:packed_ice
setblock 143 194 298 minecraft:snow_block
fill 143 194 299 143 197 299 minecraft:packed_ice
setblock 143 194 303 minecraft:snow_block
fill 143 194 304 143 197 304 minecraft:packed_ice
setblock 143 194 308 minecraft:snow_block
fill 143 194 309 143 197 309 minecraft:packed_ice
setblock 143 194 313 minecraft:snow_block
fill 143 194 314 143 197 314 minecraft:packed_ice
setblock 144 194 292 minecraft:snow_block
fill 144 194 293 144 197 293 minecraft:packed_ice
fill 144 194 295 144 195 295 minecraft:packed_ice
setblock 144 194 307 minecraft:snow_block
fill 144 194 308 144 196 308 minecraft:packed_ice
setblock 144 194 312 minecraft:snow_block
fill 144 194 313 144 197 313 minecraft:packed_ice
setblock 145 194 276 minecraft:snow_block
setblock 145 194 311 minecraft:snow_block
fill 145 194 312 145 195 312 minecraft:packed_ice
setblock 145 194 316 minecraft:snow_block
fill 146 194 276 146 195 276 minecraft:packed_ice
setblock 146 194 315 minecraft:snow_block
fill 146 194 316 146 197 316 minecraft:packed_ice
setblock 147 194 314 minecraft:snow_block
fill 147 194 315 147 197 315 minecraft:packed_ice
setblock 148 194 314 minecraft:packed_ice
setblock 150 194 316 minecraft:snow_block
setblock 151 194 316 minecraft:packed_ice
fill 161 194 276 161 197 276 minecraft:packed_ice
fill 161 194 316 164 194 316 minecraft:packed_ice
fill 163 194 315 165 194 315 minecraft:packed_ice
setblock 164 194 277 minecraft:snow_block
setblock 165 194 276 minecraft:snow_block
fill 165 194 277 165 197 277 minecraft:packed_ice
setblock 165 194 316 minecraft:snow_block
fill 166 194 276 166 197 276 minecraft:packed_ice
setblock 166 194 315 minecraft:snow_block
fill 166 194 316 166 197 316 minecraft:packed_ice
fill 167 194 315 167 197 315 minecraft:packed_ice
setblock 169 194 277 minecraft:snow_block
setblock 170 194 276 minecraft:snow_block
setblock 170 194 277 minecraft:packed_ice
setblock 170 194 316 minecraft:snow_block
fill 171 194 276 171 197 276 minecraft:packed_ice
setblock 171 194 315 minecraft:snow_block
fill 171 194 316 174 194 316 minecraft:packed_ice
fill 172 194 315 172 195 315 minecraft:packed_ice
setblock 175 194 276 minecraft:snow_block
setblock 175 194 316 minecraft:snow_block
fill 176 194 316 176 197 316 minecraft:packed_ice
fill 177 194 315 177 197 315 minecraft:packed_ice
setblock 180 194 276 minecraft:snow_block
setblock 180 194 311 minecraft:snow_block
fill 180 194 312 180 197 312 minecraft:packed_ice
setblock 180 194 316 minecraft:snow_block
setblock 181 194 275 minecraft:white_concrete
fill 181 194 276 181 197 276 minecraft:packed_ice
setblock 181 194 310 minecraft:snow_block
fill 181 194 311 181 197 311 minecraft:packed_ice
setblock 181 194 315 minecraft:snow_block
fill 181 194 316 181 197 316 minecraft:packed_ice
setblock 182 194 285 minecraft:packed_ice
setblock 182 194 289 minecraft:snow_block
fill 182 194 290 182 197 290 minecraft:packed_ice
setblock 182 194 294 minecraft:snow_block
fill 182 194 295 182 197 295 minecraft:packed_ice
setblock 182 194 304 minecraft:snow_block
fill 182 194 305 182 197 305 minecraft:packed_ice
setblock 182 194 309 minecraft:snow_block
fill 182 194 310 182 197 310 minecraft:packed_ice
setblock 182 194 314 minecraft:snow_block
fill 182 194 315 182 197 315 minecraft:packed_ice
fill 183 194 314 183 203 314 minecraft:packed_ice
setblock 142 195 288 minecraft:snow_block
fill 142 195 289 142 198 289 minecraft:packed_ice
setblock 142 195 293 minecraft:snow_block
fill 142 195 294 142 198 294 minecraft:packed_ice
setblock 142 195 298 minecraft:snow_block
fill 142 195 299 142 198 299 minecraft:packed_ice
setblock 142 195 303 minecraft:snow_block
fill 142 195 304 142 198 304 minecraft:packed_ice
setblock 142 195 308 minecraft:snow_block
fill 142 195 309 142 198 309 minecraft:packed_ice
setblock 142 195 313 minecraft:snow_block
fill 142 195 314 142 198 314 minecraft:packed_ice
fill 143 195 288 143 196 288 minecraft:packed_ice
setblock 143 195 291 minecraft:packed_ice
setblock 143 195 292 minecraft:snow_block
fill 143 195 293 143 198 293 minecraft:packed_ice
setblock 143 195 296 minecraft:packed_ice
setblock 143 195 297 minecraft:snow_block
fill 143 195 298 143 198 298 minecraft:packed_ice
setblock 143 195 302 minecraft:snow_block
fill 143 195 303 143 198 303 minecraft:packed_ice
setblock 143 195 307 minecraft:snow_block
fill 143 195 308 143 198 308 minecraft:packed_ice
setblock 143 195 312 minecraft:snow_block
fill 143 195 313 143 198 313 minecraft:packed_ice
setblock 144 195 276 minecraft:snow_block
setblock 144 195 291 minecraft:snow_block
fill 144 195 292 144 198 292 minecraft:packed_ice
setblock 144 195 296 minecraft:snow_block
setblock 144 195 306 minecraft:snow_block
setblock 144 195 307 minecraft:packed_ice
setblock 144 195 311 minecraft:snow_block
fill 144 195 312 144 198 312 minecraft:packed_ice
setblock 144 195 316 minecraft:snow_block
fill 145 195 276 145 198 276 minecraft:packed_ice
setblock 145 195 311 minecraft:packed_ice
setblock 145 195 315 minecraft:snow_block
fill 145 195 316 145 198 316 minecraft:packed_ice
setblock 146 195 314 minecraft:snow_block
fill 146 195 315 146 198 315 minecraft:packed_ice
setblock 147 195 314 minecraft:packed_ice
setblock 149 195 316 minecraft:snow_block
fill 150 195 316 150 196 316 minecraft:packed_ice
fill 161 195 316 163 195 316 minecraft:packed_ice
setblock 163 195 277 minecraft:snow_block
fill 163 195 315 164 195 315 minecraft:packed_ice
setblock 164 195 276 minecraft:snow_block
fill 164 195 277 164 198 277 minecraft:packed_ice
setblock 164 195 316 minecraft:snow_block
fill 165 195 276 165 198 276 minecraft:packed_ice
setblock 165 195 315 minecraft:snow_block
fill 165 195 316 165 198 316 minecraft:packed_ice
fill 166 195 315 166 198 315 minecraft:packed_ice
setblock 168 195 277 minecraft:snow_block
setblock 169 195 276 minecraft:snow_block
fill 169 195 277 169 198 277 minecraft:packed_ice
setblock 169 195 316 minecraft:snow_block
fill 170 195 276 170 198 276 minecraft:packed_ice
setblock 170 195 315 minecraft:snow_block
fill 170 195 316 173 195 316 minecraft:packed_ice
fill 171 195 315 171 196 315 minecraft:packed_ice
setblock 174 195 276 minecraft:snow_block
setblock 174 195 316 minecraft:snow_block
fill 175 195 316 175 198 316 minecraft:packed_ice
setblock 179 195 276 minecraft:snow_block
setblock 179 195 316 minecraft:snow_block
fill 180 195 276 180 198 276 minecraft:packed_ice
setblock 180 195 315 minecraft:snow_block
fill 180 195 316 180 198 316 minecraft:packed_ice
fill 181 195 275 181 237 275 minecraft:packed_ice
setblock 181 195 309 minecraft:snow_block
fill 181 195 310 181 198 310 minecraft:packed_ice
setblock 181 195 314 minecraft:snow_block
fill 181 195 315 181 198 315 minecraft:packed_ice
setblock 182 195 278 minecraft:snow_block
setblock 182 195 288 minecraft:snow_block
fill 182 195 289 182 198 289 minecraft:packed_ice
setblock 182 195 292 minecraft:packed_ice
setblock 182 195 293 minecraft:snow_block
fill 182 195 294 182 198 294 minecraft:packed_ice
fill 182 195 296 182 196 296 minecraft:packed_ice
fill 182 195 304 182 198 304 minecraft:packed_ice
setblock 182 195 308 minecraft:snow_block
fill 182 195 309 182 198 309 minecraft:packed_ice
setblock 182 195 313 minecraft:snow_block
fill 182 195 314 182 198 314 minecraft:packed_ice
setblock 183 195 291 minecraft:white_concrete
setblock 142 196 276 minecraft:packed_ice
setblock 142 196 287 minecraft:snow_block
fill 142 196 288 142 199 288 minecraft:packed_ice
setblock 142 196 292 minecraft:snow_block
fill 142 196 293 142 199 293 minecraft:packed_ice
setblock 142 196 297 minecraft:snow_block
fill 142 196 298 142 199 298 minecraft:packed_ice
setblock 142 196 302 minecraft:snow_block
fill 142 196 303 142 199 303 minecraft:packed_ice
setblock 142 196 307 minecraft:snow_block
fill 142 196 308 142 199 308 minecraft:packed_ice
setblock 142 196 312 minecraft:snow_block
fill 142 196 313 142 199 313 minecraft:packed_ice
setblock 143 196 276 minecraft:snow_block
setblock 143 196 291 minecraft:snow_block
fill 143 196 292 143 199 292 minecraft:packed_ice
setblock 143 196 296 minecraft:snow_block
fill 143 196 297 144 198 297 minecraft:packed_ice
setblock 143 196 301 minecraft:snow_block
fill 143 196 302 143 199 302 minecraft:packed_ice
setblock 143 196 306 minecraft:snow_block
fill 143 196 307 143 199 307 minecraft:packed_ice
setblock 143 196 311 minecraft:snow_block
fill 143 196 312 143 199 312 minecraft:packed_ice
setblock 143 196 316 minecraft:snow_block
fill 144 196 276 144 199 276 minecraft:packed_ice
fill 144 196 291 144 199 291 minecraft:packed_ice
setblock 144 196 295 minecraft:snow_block
fill 144 196 296 144 199 296 minecraft:packed_ice
setblock 144 196 310 minecraft:snow_block
fill 144 196 311 144 198 311 minecraft:packed_ice
setblock 144 196 315 minecraft:snow_block
fill 144 196 316 144 199 316 minecraft:packed_ice
setblock 145 196 314 minecraft:snow_block
fill 145 196 315 145 199 315 minecraft:packed_ice
setblock 146 196 314 minecraft:packed_ice
setblock 148 196 316 minecraft:snow_block
fill 149 196 316 149 198 316 minecraft:packed_ice
fill 156 196 317 157 229 317 minecraft:packed_ice
setblock 158 196 317 minecraft:light_blue_concrete
fill 159 196 317 159 234 317 minecraft:packed_ice
fill 160 196 276 160 198 276 minecraft:packed_ice
fill 160 196 316 162 196 316 minecraft:packed_ice
fill 162 196 315 163 196 315 minecraft:packed_ice
setblock 163 196 276 minecraft:snow_block
fill 163 196 277 163 199 277 minecraft:packed_ice
setblock 163 196 316 minecraft:snow_block
fill 164 196 276 164 199 276 minecraft:packed_ice
setblock 164 196 315 minecraft:snow_block
fill 164 196 316 164 199 316 minecraft:packed_ice
fill 165 196 315 165 199 315 minecraft:packed_ice
setblock 167 196 277 minecraft:snow_block
setblock 168 196 276 minecraft:snow_block
fill 168 196 277 168 199 277 minecraft:packed_ice
setblock 168 196 316 minecraft:snow_block
fill 169 196 276 169 199 276 minecraft:packed_ice
setblock 169 196 315 minecraft:snow_block
fill 169 196 316 172 196 316 minecraft:packed_ice
fill 170 196 315 170 199 315 minecraft:packed_ice
setblock 173 196 276 minecraft:snow_block
setblock 173 196 316 minecraft:snow_block
fill 174 196 276 174 199 276 minecraft:packed_ice
fill 174 196 316 174 199 316 minecraft:packed_ice
setblock 176 196 275 minecraft:white_concrete
fill 176 196 315 176 198 315 minecraft:packed_ice
fill 177 196 275 177 196 276 minecraft:packed_ice
setblock 178 196 276 minecraft:snow_block
setblock 178 196 316 minecraft:snow_block
fill 179 196 276 179 199 276 minecraft:packed_ice
setblock 179 196 315 minecraft:snow_block
fill 179 196 316 179 199 316 minecraft:packed_ice
setblock 180 196 313 minecraft:packed_ice
setblock 180 196 314 minecraft:snow_block
fill 180 196 315 180 199 315 minecraft:packed_ice
setblock 181 196 308 minecraft:snow_block
fill 181 196 309 181 199 309 minecraft:packed_ice
setblock 181 196 313 minecraft:snow_block
fill 181 196 314 181 199 314 minecraft:packed_ice
setblock 182 196 277 minecraft:snow_block
fill 182 196 278 182 199 278 minecraft:packed_ice
fill 182 196 288 182 197 288 minecraft:packed_ice
setblock 182 196 292 minecraft:snow_block
fill 182 196 293 182 199 293 minecraft:packed_ice
setblock 182 196 297 minecraft:snow_block
fill 182 196 298 182 199 298 minecraft:packed_ice
setblock 182 196 307 minecraft:snow_block
fill 182 196 308 182 199 308 minecraft:packed_ice
setblock 182 196 312 minecraft:snow_block
fill 182 196 313 182 199 313 minecraft:packed_ice
fill 183 196 291 183 233 291 minecraft:packed_ice
setblock 142 197 276 minecraft:snow_block
fill 142 197 287 142 200 287 minecraft:packed_ice
setblock 142 197 291 minecraft:snow_block
fill 142 197 292 142 200 292 minecraft:packed_ice
setblock 142 197 296 minecraft:snow_block
fill 142 197 297 142 200 297 minecraft:packed_ice
setblock 142 197 301 minecraft:snow_block
fill 142 197 302 142 200 302 minecraft:packed_ice
setblock 142 197 306 minecraft:snow_block
fill 142 197 307 142 200 307 minecraft:packed_ice
setblock 142 197 311 minecraft:snow_block
fill 142 197 312 142 200 312 minecraft:packed_ice
setblock 142 197 316 minecraft:snow_block
fill 143 197 276 143 200 276 minecraft:packed_ice
setblock 143 197 290 minecraft:snow_block
fill 143 197 291 143 200 291 minecraft:packed_ice
setblock 143 197 295 minecraft:snow_block
fill 143 197 296 143 200 296 minecraft:packed_ice
setblock 143 197 300 minecraft:snow_block
fill 143 197 301 143 200 301 minecraft:packed_ice
setblock 143 197 305 minecraft:snow_block
fill 143 197 306 143 200 306 minecraft:packed_ice
setblock 143 197 310 minecraft:snow_block
fill 143 197 311 143 200 311 minecraft:packed_ice
setblock 143 197 315 minecraft:snow_block
fill 143 197 316 143 200 316 minecraft:packed_ice
setblock 144 197 294 minecraft:snow_block
fill 144 197 295 144 200 295 minecraft:packed_ice
setblock 144 197 298 minecraft:packed_ice
setblock 144 197 309 minecraft:snow_block
setblock 144 197 310 minecraft:packed_ice
setblock 144 197 314 minecraft:snow_block
fill 144 197 315 144 200 315 minecraft:packed_ice
fill 145 197 314 145 198 314 minecraft:packed_ice
fill 146 197 298 146 197 301 minecraft:blue_ice
fill 147 197 297 147 197 298 minecraft:blue_ice
fill 147 197 301 155 197 301 minecraft:blue_ice
setblock 147 197 316 minecraft:snow_block
setblock 148 197 297 minecraft:blue_ice
fill 148 197 316 148 200 316 minecraft:packed_ice
fill 149 197 298 149 198 298 minecraft:blue_ice
fill 149 197 300 155 197 300 minecraft:blue_ice
fill 149 197 302 150 197 305 minecraft:blue_ice
setblock 150 197 299 minecraft:blue_ice
fill 150 197 306 155 197 306 minecraft:blue_ice
fill 151 197 305 151 199 305 minecraft:blue_ice
fill 151 197 307 154 197 307 minecraft:blue_ice
fill 155 197 302 156 197 305 minecraft:blue_ice
fill 157 197 275 162 210 275 minecraft:packed_ice
fill 158 197 317 158 235 317 minecraft:packed_ice
fill 159 197 276 159 199 276 minecraft:packed_ice
fill 159 197 310 160 197 312 minecraft:blue_ice
fill 159 197 316 161 197 316 minecraft:packed_ice
fill 160 197 309 161 198 309 minecraft:blue_ice
fill 160 197 313 164 197 313 minecraft:blue_ice
fill 161 197 308 164 197 308 minecraft:blue_ice
fill 161 197 314 163 197 314 minecraft:blue_ice
setblock 162 197 276 minecraft:snow_block
fill 162 197 277 162 200 277 minecraft:packed_ice
setblock 162 197 315 minecraft:packed_ice
setblock 162 197 316 minecraft:snow_block
setblock 163 197 275 minecraft:white_concrete
fill 163 197 276 163 200 276 minecraft:packed_ice
fill 163 197 309 165 197 309 minecraft:blue_ice
setblock 163 197 315 minecraft:snow_block
fill 163 197 316 163 200 316 minecraft:packed_ice
fill 164 197 275 164 214 275 minecraft:packed_ice
fill 164 197 310 165 198 310 minecraft:blue_ice
fill 164 197 312 167 197 312 minecraft:blue_ice
fill 164 197 315 164 200 315 minecraft:packed_ice
fill 165 197 283 165 197 286 minecraft:blue_ice
fill 165 197 311 165 198 311 minecraft:blue_ice
setblock 166 197 277 minecraft:snow_block
fill 166 197 282 166 197 283 minecraft:blue_ice
fill 166 197 286 167 197 286 minecraft:blue_ice
setblock 167 197 276 minecraft:snow_block
fill 167 197 277 167 200 277 minecraft:packed_ice
fill 167 197 283 168 197 283 minecraft:blue_ice
fill 167 197 310 167 198 311 minecraft:blue_ice
fill 167 197 313 168 198 313 minecraft:blue_ice
setblock 167 197 316 minecraft:snow_block
fill 168 197 276 168 200 276 minecraft:packed_ice
fill 168 197 284 168 197 285 minecraft:blue_ice
fill 168 197 309 168 197 310 minecraft:blue_ice
fill 168 197 314 171 197 314 minecraft:blue_ice
setblock 168 197 315 minecraft:snow_block
fill 168 197 316 171 197 316 minecraft:packed_ice
fill 169 197 309 170 197 309 minecraft:blue_ice
fill 169 197 315 169 200 315 minecraft:packed_ice
fill 170 197 310 171 198 310 minecraft:blue_ice
fill 170 197 313 171 198 313 minecraft:blue_ice
fill 171 197 311 174 197 312 minecraft:blue_ice
setblock 172 197 276 minecraft:snow_block
setblock 172 197 316 minecraft:snow_block
fill 173 197 276 173 200 276 minecraft:packed_ice
fill 173 197 316 173 200 316 minecraft:packed_ice
fill 174 197 309 175 197 310 minecraft:blue_ice
fill 174 197 313 175 197 314 minecraft:blue_ice
fill 175 197 276 176 197 276 minecraft:packed_ice
fill 176 197 275 177 217 275 minecraft:packed_ice
fill 176 197 309 178 197 309 minecraft:blue_ice
fill 176 197 314 178 197 314 minecraft:blue_ice
setblock 177 197 276 minecraft:snow_block
setblock 177 197 316 minecraft:snow_block
fill 178 197 276 178 200 276 minecraft:packed_ice
fill 178 197 310 179 197 310 minecraft:blue_ice
fill 178 197 313 179 197 313 minecraft:blue_ice
setblock 178 197 315 minecraft:snow_block
fill 178 197 316 178 200 316 minecraft:packed_ice
fill 179 197 311 179 198 312 minecraft:blue_ice
setblock 179 197 314 minecraft:snow_block
fill 179 197 315 179 200 315 minecraft:packed_ice
setblock 180 197 313 minecraft:snow_block
fill 180 197 314 180 200 314 minecraft:packed_ice
fill 181 197 308 181 200 308 minecraft:packed_ice
setblock 181 197 312 minecraft:snow_block
fill 181 197 313 181 200 313 minecraft:packed_ice
setblock 182 197 276 minecraft:snow_block
fill 182 197 277 182 200 277 minecraft:packed_ice
setblock 182 197 291 minecraft:snow_block
fill 182 197 292 182 200 292 minecraft:packed_ice
setblock 182 197 296 minecraft:snow_block
fill 182 197 297 182 200 297 minecraft:packed_ice
fill 182 197 299 182 197 300 minecraft:packed_ice
fill 182 197 303 182 199 303 minecraft:packed_ice
setblock 182 197 306 minecraft:snow_block
fill 182 197 307 182 200 307 minecraft:packed_ice
setblock 182 197 311 minecraft:snow_block
fill 182 197 312 182 200 312 minecraft:packed_ice
setblock 182 197 316 minecraft:snow_block
setblock 183 197 284 minecraft:white_concrete
fill 183 197 285 183 235 286 minecraft:packed_ice
fill 141 198 292 141 201 293 minecraft:packed_ice
setblock 141 198 294 minecraft:light_blue_concrete
fill 141 198 295 141 203 298 minecraft:packed_ice
fill 142 198 276 142 200 277 minecraft:packed_ice
setblock 142 198 290 minecraft:snow_block
fill 142 198 291 142 200 291 minecraft:packed_ice
setblock 142 198 295 minecraft:snow_block
fill 142 198 296 142 200 296 minecraft:packed_ice
setblock 142 198 300 minecraft:snow_block
fill 142 198 301 142 200 301 minecraft:packed_ice
setblock 142 198 305 minecraft:snow_block
fill 142 198 306 142 200 306 minecraft:packed_ice
setblock 142 198 310 minecraft:snow_block
fill 142 198 311 142 200 311 minecraft:packed_ice
setblock 142 198 315 minecraft:snow_block
fill 142 198 316 142 200 316 minecraft:packed_ice
setblock 143 198 289 minecraft:snow_block
fill 143 198 290 143 200 290 minecraft:packed_ice
setblock 143 198 294 minecraft:snow_block
fill 143 198 295 143 200 295 minecraft:packed_ice
setblock 143 198 299 minecraft:snow_block
fill 143 198 300 143 200 300 minecraft:packed_ice
setblock 143 198 304 minecraft:snow_block
fill 143 198 305 143 200 305 minecraft:packed_ice
setblock 143 198 309 minecraft:snow_block
fill 143 198 310 143 200 310 minecraft:packed_ice
setblock 143 198 314 minecraft:snow_block
fill 143 198 315 143 200 315 minecraft:packed_ice
setblock 144 198 278 minecraft:light[level=12]
setblock 144 198 285 minecraft:light[level=12]
setblock 144 198 293 minecraft:snow_block
fill 144 198 294 144 200 294 minecraft:packed_ice
setblock 144 198 298 minecraft:snow_block
fill 144 198 299 144 200 299 minecraft:packed_ice
setblock 144 198 306 minecraft:light[level=12]
setblock 144 198 313 minecraft:snow_block
fill 144 198 314 144 199 314 minecraft:packed_ice
setblock 146 198 276 minecraft:snow_block
fill 146 198 298 146 198 300 minecraft:blue_ice
setblock 146 198 316 minecraft:snow_block
fill 147 198 298 147 199 298 minecraft:blue_ice
fill 147 198 301 148 198 301 minecraft:blue_ice
setblock 147 198 315 minecraft:snow_block
fill 147 198 316 147 200 316 minecraft:packed_ice
fill 149 198 300 149 199 300 minecraft:blue_ice
fill 150 198 302 150 198 305 minecraft:blue_ice
setblock 151 198 278 minecraft:light[level=12]
setblock 151 198 285 minecraft:light[level=12]
setblock 151 198 292 minecraft:light[level=12]
setblock 151 198 299 minecraft:light[level=12]
fill 151 198 301 155 198 301 minecraft:blue_ice
fill 151 198 306 154 198 306 minecraft:blue_ice
setblock 151 198 313 minecraft:light[level=12]
fill 152 198 300 153 198 300 minecraft:blue_ice
fill 155 198 302 155 198 305 minecraft:blue_ice
fill 156 198 303 156 198 304 minecraft:blue_ice
fill 158 198 276 158 200 276 minecraft:packed_ice
setblock 158 198 278 minecraft:light[level=12]
setblock 158 198 285 minecraft:light[level=12]
setblock 158 198 299 minecraft:light[level=12]
setblock 158 198 306 minecraft:light[level=12]
setblock 158 198 313 minecraft:light[level=12]
fill 159 198 316 160 198 316 minecraft:packed_ice
fill 160 198 310 160 198 312 minecraft:blue_ice
setblock 161 198 276 minecraft:snow_block
fill 161 198 277 161 200 277 minecraft:packed_ice
fill 161 198 313 164 198 313 minecraft:blue_ice
setblock 161 198 315 minecraft:packed_ice
setblock 161 198 316 minecraft:snow_block
fill 162 198 276 162 200 276 minecraft:packed_ice
fill 162 198 308 163 198 308 minecraft:blue_ice
setblock 162 198 315 minecraft:snow_block
fill 162 198 316 162 200 316 minecraft:packed_ice
fill 163 198 275 163 199 275 minecraft:packed_ice
fill 163 198 309 164 198 309 minecraft:blue_ice
fill 163 198 315 163 200 315 minecraft:packed_ice
fill 164 198 312 164 199 312 minecraft:blue_ice
setblock 165 198 277 minecraft:snow_block
setblock 165 198 278 minecraft:light[level=12]
fill 165 198 283 165 198 285 minecraft:blue_ice
setblock 165 198 292 minecraft:light[level=12]
setblock 165 198 299 minecraft:light[level=12]
setblock 165 198 306 minecraft:light[level=12]
setblock 165 198 313 minecraft:light[level=12]
setblock 166 198 276 minecraft:snow_block
fill 166 198 277 166 200 277 minecraft:packed_ice
fill 166 198 283 167 199 283 minecraft:blue_ice
setblock 166 198 286 minecraft:blue_ice
setblock 166 198 316 minecraft:snow_block
fill 167 198 276 167 200 276 minecraft:packed_ice
fill 167 198 312 167 199 312 minecraft:blue_ice
setblock 167 198 315 minecraft:snow_block
fill 167 198 316 170 198 316 minecraft:packed_ice
setblock 168 198 284 minecraft:blue_ice
fill 168 198 310 168 199 310 minecraft:blue_ice
fill 168 198 315 168 200 315 minecraft:packed_ice
setblock 169 198 309 minecraft:blue_ice
fill 169 198 314 170 198 314 minecraft:blue_ice
setblock 171 198 276 minecraft:snow_block
fill 171 198 311 171 199 312 minecraft:blue_ice
setblock 171 198 316 minecraft:snow_block
fill 172 198 276 172 200 276 minecraft:packed_ice
setblock 172 198 278 minecraft:light[level=12]
setblock 172 198 285 minecraft:light[level=12]
setblock 172 198 292 minecraft:light[level=12]
setblock 172 198 299 minecraft:light[level=12]
setblock 172 198 306 minecraft:light[level=12]
setblock 172 198 313 minecraft:light[level=12]
fill 172 198 316 172 200 316 minecraft:packed_ice
fill 174 198 310 174 198 313 minecraft:blue_ice
setblock 175 198 276 minecraft:packed_ice
fill 175 198 309 175 198 310 minecraft:blue_ice
fill 175 198 313 175 198 314 minecraft:blue_ice
fill 175 198 315 175 199 315 minecraft:packed_ice
setblock 176 198 276 minecraft:snow_block
fill 176 198 309 177 198 309 minecraft:blue_ice
fill 176 198 314 177 198 314 minecraft:blue_ice
setblock 176 198 316 minecraft:snow_block
fill 177 198 276 177 200 276 minecraft:packed_ice
setblock 177 198 315 minecraft:snow_block
fill 177 198 316 177 200 316 minecraft:packed_ice
fill 178 198 310 178 199 310 minecraft:blue_ice
fill 178 198 313 178 199 313 minecraft:blue_ice
fill 178 198 315 178 200 315 minecraft:packed_ice
setblock 179 198 278 minecraft:light[level=12]
setblock 179 198 285 minecraft:light[level=12]
setblock 179 198 292 minecraft:light[level=12]
setblock 179 198 299 minecraft:light[level=12]
setblock 179 198 306 minecraft:light[level=12]
setblock 179 198 313 minecraft:light[level=12]
fill 179 198 314 179 200 314 minecraft:packed_ice
setblock 180 198 312 minecraft:snow_block
fill 180 198 313 180 200 313 minecraft:packed_ice
setblock 181 198 276 minecraft:snow_block
setblock 181 198 311 minecraft:snow_block
fill 181 198 312 181 200 312 minecraft:packed_ice
setblock 181 198 316 minecraft:snow_block
fill 182 198 276 182 200 276 minecraft:packed_ice
setblock 182 198 279 minecraft:packed_ice
setblock 182 198 290 minecraft:snow_block
fill 182 198 291 182 200 291 minecraft:packed_ice
setblock 182 198 295 minecraft:snow_block
fill 182 198 296 182 200 296 minecraft:packed_ice
setblock 182 198 299 minecraft:packed_ice
setblock 182 198 300 minecraft:snow_block
fill 182 198 301 182 200 302 minecraft:packed_ice
setblock 182 198 305 minecraft:snow_block
fill 182 198 306 182 200 306 minecraft:packed_ice
setblock 182 198 310 minecraft:snow_block
fill 182 198 311 182 200 311 minecraft:packed_ice
setblock 182 198 315 minecraft:snow_block
fill 182 198 316 182 200 316 minecraft:packed_ice
fill 183 198 284 183 202 284 minecraft:packed_ice
fill 141 199 294 141 237 294 minecraft:packed_ice
setblock 142 199 278 minecraft:packed_ice
setblock 142 199 289 minecraft:snow_block
fill 142 199 290 142 200 290 minecraft:packed_ice
setblock 142 199 294 minecraft:snow_block
fill 142 199 295 142 200 295 minecraft:packed_ice
setblock 142 199 299 minecraft:snow_block
fill 142 199 300 142 200 300 minecraft:packed_ice
setblock 142 199 304 minecraft:snow_block
fill 142 199 305 142 200 305 minecraft:packed_ice
setblock 142 199 309 minecraft:snow_block
fill 142 199 310 142 200 310 minecraft:packed_ice
setblock 142 199 314 minecraft:snow_block
fill 142 199 315 142 200 315 minecraft:packed_ice
fill 143 199 275 143 237 275 minecraft:packed_ice
fill 143 199 289 143 200 289 minecraft:packed_ice
setblock 143 199 293 minecraft:snow_block
fill 143 199 294 143 200 294 minecraft:packed_ice
setblock 143 199 297 minecraft:packed_ice
setblock 143 199 298 minecraft:snow_block
fill 143 199 299 143 200 299 minecraft:packed_ice
setblock 143 199 303 minecraft:snow_block
fill 143 199 304 143 200 304 minecraft:packed_ice
setblock 143 199 308 minecraft:snow_block
fill 143 199 309 143 200 309 minecraft:packed_ice
setblock 143 199 313 minecraft:snow_block
fill 143 199 314 143 200 314 minecraft:packed_ice
setblock 144 199 275 minecraft:white_concrete
setblock 144 199 292 minecraft:snow_block
fill 144 199 293 144 200 293 minecraft:packed_ice
setblock 144 199 297 minecraft:snow_block
fill 144 199 298 144 200 298 minecraft:packed_ice
fill 144 199 300 144 200 300 minecraft:packed_ice
setblock 144 199 313 minecraft:packed_ice
setblock 145 199 276 minecraft:snow_block
setblock 145 199 316 minecraft:snow_block
fill 146 199 276 146 200 276 minecraft:packed_ice
setblock 146 199 299 minecraft:blue_ice
setblock 146 199 315 minecraft:snow_block
fill 146 199 316 146 200 316 minecraft:packed_ice
fill 150 199 303 150 199 304 minecraft:blue_ice
fill 152 199 301 154 199 301 minecraft:blue_ice
fill 152 199 306 153 199 306 minecraft:blue_ice
fill 155 199 302 155 199 304 minecraft:blue_ice
fill 157 199 276 157 200 276 minecraft:packed_ice
fill 158 199 316 159 199 316 minecraft:packed_ice
setblock 159 199 277 minecraft:snow_block
setblock 160 199 276 minecraft:snow_block
fill 160 199 277 160 200 277 minecraft:packed_ice
fill 160 199 310 160 199 311 minecraft:blue_ice
setblock 160 199 316 minecraft:snow_block
fill 161 199 276 161 200 276 minecraft:packed_ice
setblock 161 199 309 minecraft:blue_ice
setblock 161 199 315 minecraft:snow_block
fill 161 199 316 161 200 316 minecraft:packed_ice
fill 162 199 313 163 199 313 minecraft:blue_ice
fill 162 199 315 162 200 315 minecraft:packed_ice
setblock 163 199 278 minecraft:snow_block
setblock 163 199 309 minecraft:blue_ice
setblock 164 199 277 minecraft:snow_block
fill 164 199 278 165 200 278 minecraft:packed_ice
setblock 164 199 310 minecraft:blue_ice
setblock 165 199 276 minecraft:snow_block
fill 165 199 277 165 200 277 minecraft:packed_ice
fill 165 199 284 165 199 285 minecraft:blue_ice
setblock 165 199 316 minecraft:snow_block
fill 166 199 276 166 200 276 minecraft:packed_ice
setblock 166 199 315 minecraft:snow_block
fill 166 199 316 169 199 316 minecraft:packed_ice
fill 167 199 315 167 200 315 minecraft:packed_ice
setblock 168 199 313 minecraft:blue_ice
setblock 169 199 277 minecraft:snow_block
setblock 170 199 276 minecraft:snow_block
setblock 170 199 310 minecraft:blue_ice
setblock 170 199 313 minecraft:blue_ice
setblock 170 199 316 minecraft:snow_block
fill 171 199 276 171 200 276 minecraft:packed_ice
fill 171 199 316 171 200 316 minecraft:packed_ice
fill 174 199 311 174 199 312 minecraft:blue_ice
fill 174 199 315 174 200 315 minecraft:packed_ice
setblock 174 199 317 minecraft:light_blue_concrete
setblock 175 199 276 minecraft:snow_block
setblock 175 199 310 minecraft:blue_ice
setblock 175 199 313 minecraft:blue_ice
setblock 175 199 316 minecraft:snow_block
fill 176 199 276 176 200 276 minecraft:packed_ice
setblock 176 199 315 minecraft:snow_block
fill 176 199 316 176 200 316 minecraft:packed_ice
fill 177 199 315 177 200 315 minecraft:packed_ice
fill 178 199 314 178 200 314 minecraft:packed_ice
setblock 180 199 276 minecraft:snow_block
fill 180 199 277 181 200 277 minecraft:packed_ice
fill 180 199 312 180 200 312 minecraft:packed_ice
setblock 180 199 316 minecraft:snow_block
fill 181 199 276 181 200 276 minecraft:packed_ice
fill 181 199 293 181 199 294 minecraft:packed_ice
setblock 181 199 295 minecraft:snow_block
fill 181 199 296 181 200 297 minecraft:packed_ice
setblock 181 199 310 minecraft:snow_block
fill 181 199 311 181 200 311 minecraft:packed_ice
setblock 181 199 315 minecraft:snow_block
fill 181 199 316 181 200 316 minecraft:packed_ice
setblock 182 199 279 minecraft:snow_block
setblock 182 199 289 minecraft:snow_block
fill 182 199 290 182 200 290 minecraft:packed_ice
setblock 182 199 294 minecraft:snow_block
fill 182 199 295 182 200 295 minecraft:packed_ice
setblock 182 199 299 minecraft:snow_block
fill 182 199 300 182 200 300 minecraft:packed_ice
setblock 182 199 304 minecraft:snow_block
fill 182 199 305 182 200 305 minecraft:packed_ice
setblock 182 199 309 minecraft:snow_block
fill 182 199 310 182 200 310 minecraft:packed_ice
setblock 182 199 314 minecraft:snow_block
fill 182 199 315 182 200 315 minecraft:packed_ice
setblock 142 200 278 minecraft:snow_block
setblock 142 200 279 minecraft:packed_ice
setblock 142 200 288 minecraft:snow_block
setblock 142 200 289 minecraft:packed_ice
setblock 142 200 293 minecraft:snow_block
setblock 142 200 294 minecraft:packed_ice
setblock 142 200 298 minecraft:snow_block
setblock 142 200 299 minecraft:packed_ice
setblock 142 200 303 minecraft:snow_block
setblock 142 200 304 minecraft:packed_ice
setblock 142 200 308 minecraft:snow_block
setblock 142 200 309 minecraft:packed_ice
setblock 142 200 313 minecraft:snow_block
setblock 142 200 314 minecraft:packed_ice
setblock 143 200 292 minecraft:snow_block
setblock 143 200 293 minecraft:packed_ice
setblock 143 200 297 minecraft:snow_block
setblock 143 200 298 minecraft:packed_ice
setblock 143 200 302 minecraft:snow_block
setblock 143 200 303 minecraft:packed_ice
setblock 143 200 307 minecraft:snow_block
setblock 143 200 308 minecraft:packed_ice
setblock 143 200 312 minecraft:snow_block
setblock 143 200 313 minecraft:packed_ice
fill 144 200 275 144 238 275 minecraft:packed_ice
setblock 144 200 276 minecraft:snow_block
setblock 144 200 278 minecraft:light[level=15]
setblock 144 200 286 minecraft:light[level=15]
setblock 144 200 291 minecraft:snow_block
setblock 144 200 292 minecraft:packed_ice
setblock 144 200 296 minecraft:snow_block
setblock 144 200 297 minecraft:packed_ice
setblock 144 200 301 minecraft:snow_block
setblock 144 200 302 minecraft:light[level=15]
setblock 144 200 310 minecraft:light[level=15]
setblock 144 200 316 minecraft:snow_block
setblock 145 200 276 minecraft:packed_ice
setblock 145 200 295 minecraft:snow_block
setblock 145 200 296 minecraft:packed_ice
setblock 145 200 315 minecraft:snow_block
setblock 145 200 316 minecraft:packed_ice
setblock 146 200 315 minecraft:packed_ice
setblock 147 200 276 minecraft:packed_ice
setblock 152 200 278 minecraft:light[level=15]
setblock 152 200 286 minecraft:light[level=15]
setblock 152 200 294 minecraft:light[level=15]
setblock 152 200 310 minecraft:light[level=15]
setblock 156 200 276 minecraft:packed_ice
fill 157 200 316 158 200 316 minecraft:packed_ice
setblock 158 200 277 minecraft:snow_block
setblock 159 200 276 minecraft:snow_block
setblock 159 200 277 minecraft:packed_ice
setblock 159 200 316 minecraft:snow_block
setblock 160 200 276 minecraft:packed_ice
setblock 160 200 278 minecraft:light[level=15]
setblock 160 200 286 minecraft:light[level=15]
setblock 160 200 294 minecraft:light[level=15]
setblock 160 200 302 minecraft:light[level=15]
setblock 160 200 310 minecraft:light[level=15]
setblock 160 200 315 minecraft:snow_block
setblock 160 200 316 minecraft:packed_ice
setblock 161 200 278 minecraft:packed_ice
setblock 161 200 315 minecraft:packed_ice
setblock 162 200 278 minecraft:snow_block
setblock 163 200 275 minecraft:white_concrete
setblock 163 200 277 minecraft:snow_block
setblock 163 200 278 minecraft:packed_ice
setblock 164 200 276 minecraft:snow_block
setblock 164 200 277 minecraft:packed_ice
setblock 164 200 316 minecraft:snow_block
setblock 165 200 276 minecraft:packed_ice
setblock 165 200 315 minecraft:snow_block
fill 165 200 316 168 200 316 minecraft:packed_ice
setblock 166 200 278 minecraft:packed_ice
setblock 166 200 315 minecraft:packed_ice
setblock 168 200 277 minecraft:snow_block
setblock 168 200 278 minecraft:light[level=15]
setblock 168 200 286 minecraft:light[level=15]
setblock 168 200 294 minecraft:light[level=15]
setblock 168 200 302 minecraft:light[level=15]
setblock 168 200 310 minecraft:light[level=15]
setblock 169 200 276 minecraft:snow_block
fill 169 200 277 170 200 277 minecraft:packed_ice
setblock 169 200 316 minecraft:snow_block
setblock 170 200 276 minecraft:packed_ice
setblock 170 200 315 minecraft:snow_block
setblock 170 200 316 minecraft:packed_ice
setblock 173 200 315 minecraft:packed_ice
setblock 174 200 276 minecraft:snow_block
setblock 174 200 316 minecraft:snow_block
fill 174 200 317 174 237 317 minecraft:packed_ice
setblock 175 200 276 minecraft:packed_ice
setblock 175 200 315 minecraft:snow_block
setblock 175 200 316 minecraft:packed_ice
setblock 176 200 278 minecraft:light[level=15]
setblock 176 200 286 minecraft:light[level=15]
setblock 176 200 294 minecraft:light[level=15]
setblock 176 200 302 minecraft:light[level=15]
setblock 176 200 315 minecraft:packed_ice
setblock 178 200 277 minecraft:snow_block
setblock 179 200 276 minecraft:snow_block
setblock 179 200 277 minecraft:packed_ice
setblock 179 200 316 minecraft:snow_block
setblock 180 200 276 minecraft:packed_ice
setblock 180 200 311 minecraft:packed_ice
setblock 180 200 315 minecraft:snow_block
setblock 180 200 316 minecraft:packed_ice
setblock 181 200 278 minecraft:packed_ice
fill 181 200 292 181 200 293 minecraft:packed_ice
setblock 181 200 294 minecraft:snow_block
setblock 181 200 295 minecraft:packed_ice
setblock 181 200 298 minecraft:packed_ice
setblock 181 200 299 minecraft:snow_block
fill 181 200 300 181 200 301 minecraft:packed_ice
setblock 181 200 307 minecraft:packed_ice
setblock 181 200 309 minecraft:snow_block
setblock 181 200 310 minecraft:packed_ice
setblock 181 200 314 minecraft:snow_block
setblock 181 200 315 minecraft:packed_ice
setblock 182 200 278 minecraft:snow_block
fill 182 200 279 182 200 280 minecraft:packed_ice
setblock 182 200 289 minecraft:packed_ice
setblock 182 200 293 minecraft:snow_block
setblock 182 200 294 minecraft:packed_ice
setblock 182 200 298 minecraft:snow_block
setblock 182 200 299 minecraft:packed_ice
setblock 182 200 303 minecraft:snow_block
setblock 182 200 304 minecraft:packed_ice
setblock 182 200 308 minecraft:snow_block
setblock 182 200 309 minecraft:packed_ice
setblock 182 200 313 minecraft:snow_block
setblock 182 200 314 minecraft:packed_ice
setblock 182 200 317 minecraft:light_blue_concrete
fill 183 200 317 183 233 317 minecraft:packed_ice
setblock 141 201 315 minecraft:light_blue_concrete
fill 163 201 275 163 222 275 minecraft:packed_ice
setblock 173 201 317 minecraft:light_blue_concrete
fill 182 201 317 182 221 317 minecraft:packed_ice
setblock 183 201 312 minecraft:white_concrete
setblock 141 202 292 minecraft:white_concrete
fill 141 202 293 141 206 293 minecraft:packed_ice
fill 141 202 315 141 235 315 minecraft:packed_ice
fill 173 202 317 173 233 317 minecraft:packed_ice
setblock 183 202 308 minecraft:light_blue_concrete
fill 183 202 312 183 234 312 minecraft:packed_ice
setblock 141 203 285 minecraft:light_blue_concrete
setblock 141 203 292 minecraft:light_blue_concrete
setblock 183 203 284 minecraft:light_blue_concrete
fill 183 203 308 183 207 308 minecraft:packed_ice
fill 141 204 285 141 234 285 minecraft:packed_ice
fill 141 204 292 141 230 292 minecraft:packed_ice
fill 141 204 295 141 226 297 minecraft:packed_ice
setblock 141 204 298 minecraft:white_concrete
setblock 144 204 278 minecraft:light[level=12]
setblock 144 204 285 minecraft:light[level=12]
setblock 144 204 292 minecraft:light[level=12]
setblock 144 204 299 minecraft:light[level=12]
setblock 144 204 306 minecraft:light[level=12]
setblock 144 204 313 minecraft:light[level=12]
setblock 151 204 278 minecraft:light[level=12]
setblock 151 204 285 minecraft:light[level=12]
setblock 151 204 292 minecraft:light[level=12]
setblock 151 204 299 minecraft:light[level=12]
setblock 151 204 306 minecraft:light[level=12]
setblock 151 204 313 minecraft:light[level=12]
setblock 158 204 278 minecraft:light[level=12]
setblock 158 204 285 minecraft:light[level=12]
setblock 158 204 299 minecraft:light[level=12]
setblock 158 204 306 minecraft:light[level=12]
setblock 158 204 313 minecraft:light[level=12]
setblock 165 204 278 minecraft:light[level=12]
setblock 165 204 285 minecraft:light[level=12]
setblock 165 204 292 minecraft:light[level=12]
setblock 165 204 299 minecraft:light[level=12]
setblock 165 204 306 minecraft:light[level=12]
setblock 165 204 313 minecraft:light[level=12]
setblock 167 204 317 minecraft:white_concrete
setblock 172 204 278 minecraft:light[level=12]
setblock 172 204 285 minecraft:light[level=12]
setblock 172 204 292 minecraft:light[level=12]
setblock 172 204 299 minecraft:light[level=12]
setblock 172 204 306 minecraft:light[level=12]
setblock 172 204 313 minecraft:light[level=12]
setblock 179 204 278 minecraft:light[level=12]
setblock 179 204 285 minecraft:light[level=12]
setblock 179 204 292 minecraft:light[level=12]
setblock 179 204 299 minecraft:light[level=12]
setblock 179 204 306 minecraft:light[level=12]
setblock 179 204 313 minecraft:light[level=12]
fill 183 204 284 183 237 284 minecraft:packed_ice
setblock 183 204 314 minecraft:light_blue_concrete
fill 141 205 298 141 237 298 minecraft:packed_ice
fill 167 205 317 167 237 317 minecraft:packed_ice
fill 183 205 314 183 233 314 minecraft:packed_ice
setblock 141 206 302 minecraft:light_blue_concrete
fill 148 206 289 148 208 293 minecraft:blue_ice
fill 149 206 287 149 208 290 minecraft:blue_ice
fill 149 206 291 154 206 291 minecraft:packed_ice
fill 149 206 292 149 208 295 minecraft:blue_ice
fill 150 206 285 150 208 286 minecraft:blue_ice
fill 150 206 287 155 206 290 minecraft:packed_ice
fill 150 206 292 155 206 295 minecraft:packed_ice
fill 150 206 296 150 208 297 minecraft:blue_ice
fill 151 206 284 151 207 285 minecraft:blue_ice
fill 151 206 286 165 207 286 minecraft:packed_ice
fill 151 206 296 165 207 296 minecraft:packed_ice
fill 151 206 297 151 207 298 minecraft:blue_ice
fill 152 206 283 152 207 284 minecraft:blue_ice
fill 152 206 285 164 207 285 minecraft:packed_ice
fill 152 206 297 164 207 297 minecraft:packed_ice
fill 152 206 298 152 207 299 minecraft:blue_ice
fill 153 206 283 153 208 283 minecraft:blue_ice
fill 153 206 284 163 207 284 minecraft:packed_ice
fill 153 206 298 163 207 298 minecraft:packed_ice
fill 153 206 299 153 207 299 minecraft:blue_ice
fill 154 206 282 157 208 282 minecraft:blue_ice
fill 154 206 283 162 207 283 minecraft:packed_ice
fill 154 206 299 162 207 299 minecraft:packed_ice
fill 154 206 300 157 208 300 minecraft:blue_ice
fill 156 206 281 160 208 281 minecraft:blue_ice
fill 156 206 287 157 206 288 minecraft:packed_ice
fill 156 206 294 157 206 295 minecraft:packed_ice
fill 156 206 301 160 208 301 minecraft:blue_ice
fill 158 206 282 158 207 282 minecraft:packed_ice
fill 158 206 287 166 206 287 minecraft:packed_ice
fill 158 206 295 166 206 295 minecraft:packed_ice
fill 158 206 300 158 207 300 minecraft:packed_ice
fill 159 206 282 162 208 282 minecraft:blue_ice
fill 159 206 288 166 206 288 minecraft:packed_ice
fill 159 206 294 166 206 294 minecraft:packed_ice
fill 159 206 300 162 208 300 minecraft:blue_ice
fill 161 206 289 166 206 290 minecraft:packed_ice
fill 161 206 292 166 206 293 minecraft:packed_ice
fill 162 206 291 167 206 291 minecraft:packed_ice
fill 163 206 283 164 208 283 minecraft:blue_ice
fill 163 206 299 164 207 299 minecraft:blue_ice
fill 164 206 284 165 207 284 minecraft:blue_ice
fill 164 206 298 165 207 298 minecraft:blue_ice
fill 165 206 285 166 207 285 minecraft:blue_ice
fill 165 206 297 166 207 297 minecraft:blue_ice
fill 166 206 286 166 207 286 minecraft:blue_ice
fill 166 206 296 166 207 296 minecraft:blue_ice
fill 167 206 287 167 208 290 minecraft:blue_ice
fill 167 206 292 167 208 295 minecraft:blue_ice
fill 168 206 289 168 208 293 minecraft:blue_ice
setblock 141 207 293 minecraft:light_blue_concrete
fill 141 207 302 142 207 302 minecraft:packed_ice
fill 142 207 276 142 207 277 minecraft:snow_block
setblock 142 207 278 minecraft:packed_ice
fill 142 207 279 142 207 281 minecraft:snow_block
setblock 142 207 282 minecraft:packed_ice
fill 142 207 283 142 207 285 minecraft:snow_block
setblock 142 207 286 minecraft:packed_ice
fill 142 207 287 142 207 289 minecraft:snow_block
setblock 142 207 290 minecraft:packed_ice
fill 142 207 291 142 207 293 minecraft:snow_block
setblock 142 207 294 minecraft:packed_ice
fill 142 207 295 142 207 297 minecraft:snow_block
setblock 142 207 298 minecraft:packed_ice
fill 142 207 299 142 207 301 minecraft:snow_block
fill 142 207 303 142 207 305 minecraft:snow_block
setblock 142 207 306 minecraft:packed_ice
fill 142 207 307 142 207 309 minecraft:snow_block
setblock 142 207 310 minecraft:packed_ice
fill 142 207 311 142 207 313 minecraft:snow_block
setblock 142 207 314 minecraft:packed_ice
fill 142 207 315 143 207 316 minecraft:snow_block
setblock 143 207 276 minecraft:snow_block
setblock 143 207 277 minecraft:packed_ice
fill 143 207 278 143 207 280 minecraft:snow_block
setblock 143 207 281 minecraft:packed_ice
fill 143 207 282 143 207 284 minecraft:snow_block
setblock 143 207 285 minecraft:packed_ice
fill 143 207 286 143 207 288 minecraft:snow_block
setblock 143 207 289 minecraft:packed_ice
fill 143 207 290 143 207 292 minecraft:snow_block
setblock 143 207 293 minecraft:packed_ice
fill 143 207 294 143 207 296 minecraft:snow_block
setblock 143 207 297 minecraft:packed_ice
fill 143 207 298 143 207 300 minecraft:snow_block
setblock 143 207 301 minecraft:packed_ice
fill 143 207 302 143 207 304 minecraft:snow_block
setblock 143 207 305 minecraft:packed_ice
fill 143 207 306 143 207 308 minecraft:snow_block
setblock 143 207 309 minecraft:packed_ice
fill 143 207 310 143 207 312 minecraft:snow_block
setblock 143 207 313 minecraft:packed_ice
fill 143 207 314 145 207 314 minecraft:snow_block
setblock 144 207 276 minecraft:packed_ice
fill 144 207 277 144 207 279 minecraft:snow_block
setblock 144 207 280 minecraft:packed_ice
fill 144 207 281 144 207 283 minecraft:snow_block
setblock 144 207 284 minecraft:packed_ice
fill 144 207 285 144 207 287 minecraft:snow_block
setblock 144 207 288 minecraft:packed_ice
fill 144 207 289 144 207 291 minecraft:snow_block
setblock 144 207 292 minecraft:packed_ice
fill 144 207 293 144 207 295 minecraft:snow_block
setblock 144 207 296 minecraft:packed_ice
fill 144 207 297 144 207 299 minecraft:snow_block
setblock 144 207 300 minecraft:packed_ice
fill 144 207 301 144 207 303 minecraft:snow_block
setblock 144 207 304 minecraft:packed_ice
fill 144 207 305 144 207 307 minecraft:snow_block
setblock 144 207 308 minecraft:packed_ice
fill 144 207 309 144 207 311 minecraft:snow_block
setblock 144 207 312 minecraft:packed_ice
fill 144 207 313 146 207 313 minecraft:snow_block
setblock 144 207 315 minecraft:snow_block
setblock 144 207 316 minecraft:packed_ice
fill 145 207 276 145 207 278 minecraft:snow_block
setblock 145 207 279 minecraft:packed_ice
fill 145 207 280 145 207 282 minecraft:snow_block
setblock 145 207 283 minecraft:packed_ice
fill 145 207 284 145 207 286 minecraft:snow_block
setblock 145 207 287 minecraft:packed_ice
fill 145 207 288 145 207 290 minecraft:snow_block
setblock 145 207 291 minecraft:packed_ice
fill 145 207 292 145 207 294 minecraft:snow_block
setblock 145 207 295 minecraft:packed_ice
fill 145 207 296 145 207 298 minecraft:snow_block
setblock 145 207 299 minecraft:packed_ice
fill 145 207 300 145 207 302 minecraft:snow_block
setblock 145 207 303 minecraft:packed_ice
fill 145 207 304 145 207 306 minecraft:snow_block
setblock 145 207 307 minecraft:packed_ice
fill 145 207 308 145 207 310 minecraft:snow_block
setblock 145 207 311 minecraft:packed_ice
fill 145 207 312 147 207 312 minecraft:snow_block
setblock 145 207 315 minecraft:packed_ice
fill 145 207 316 147 207 316 minecraft:snow_block
fill 146 207 276 146 207 277 minecraft:snow_block
setblock 146 207 278 minecraft:packed_ice
fill 146 207 279 146 207 281 minecraft:snow_block
setblock 146 207 282 minecraft:packed_ice
fill 146 207 283 146 207 285 minecraft:snow_block
setblock 146 207 286 minecraft:packed_ice
fill 146 207 287 146 207 289 minecraft:snow_block
setblock 146 207 290 minecraft:packed_ice
fill 146 207 291 146 207 293 minecraft:snow_block
setblock 146 207 294 minecraft:packed_ice
fill 146 207 295 146 207 297 minecraft:snow_block
setblock 146 207 298 minecraft:packed_ice
fill 146 207 299 146 207 301 minecraft:snow_block
setblock 146 207 302 minecraft:packed_ice
fill 146 207 303 146 207 305 minecraft:snow_block
setblock 146 207 306 minecraft:packed_ice
fill 146 207 307 146 207 309 minecraft:snow_block
setblock 146 207 310 minecraft:packed_ice
fill 146 207 311 148 207 311 minecraft:snow_block
setblock 146 207 314 minecraft:packed_ice
fill 146 207 315 148 207 315 minecraft:snow_block
setblock 147 207 276 minecraft:snow_block
setblock 147 207 277 minecraft:packed_ice
fill 147 207 278 147 207 280 minecraft:snow_block
setblock 147 207 281 minecraft:packed_ice
fill 147 207 282 147 207 284 minecraft:snow_block
setblock 147 207 285 minecraft:packed_ice
fill 147 207 286 147 207 288 minecraft:snow_block
setblock 147 207 289 minecraft:packed_ice
fill 147 207 290 147 207 292 minecraft:snow_block
setblock 147 207 293 minecraft:packed_ice
fill 147 207 294 147 207 296 minecraft:snow_block
setblock 147 207 297 minecraft:packed_ice
fill 147 207 298 147 207 300 minecraft:snow_block
setblock 147 207 301 minecraft:packed_ice
fill 147 207 302 147 207 304 minecraft:snow_block
setblock 147 207 305 minecraft:packed_ice
fill 147 207 306 147 207 308 minecraft:snow_block
setblock 147 207 309 minecraft:packed_ice
fill 147 207 310 149 207 310 minecraft:snow_block
setblock 147 207 313 minecraft:packed_ice
fill 147 207 314 149 207 314 minecraft:snow_block
setblock 148 207 276 minecraft:packed_ice
fill 148 207 277 148 207 279 minecraft:snow_block
setblock 148 207 280 minecraft:packed_ice
fill 148 207 281 148 207 283 minecraft:snow_block
setblock 148 207 284 minecraft:packed_ice
fill 148 207 285 148 207 287 minecraft:snow_block
setblock 148 207 288 minecraft:blue_ice
setblock 148 207 294 minecraft:blue_ice
setblock 148 207 295 minecraft:snow_block
setblock 148 207 296 minecraft:packed_ice
fill 148 207 297 148 207 299 minecraft:snow_block
setblock 148 207 300 minecraft:packed_ice
fill 148 207 301 148 207 303 minecraft:snow_block
setblock 148 207 304 minecraft:packed_ice
fill 148 207 305 148 207 307 minecraft:snow_block
setblock 148 207 308 minecraft:packed_ice
fill 148 207 309 150 207 309 minecraft:snow_block
setblock 148 207 312 minecraft:packed_ice
fill 148 207 313 150 207 313 minecraft:snow_block
setblock 148 207 316 minecraft:packed_ice
fill 149 207 276 149 207 278 minecraft:snow_block
setblock 149 207 279 minecraft:packed_ice
fill 149 207 280 149 207 282 minecraft:snow_block
setblock 149 207 283 minecraft:packed_ice
fill 149 207 284 149 207 285 minecraft:snow_block
setblock 149 207 286 minecraft:blue_ice
fill 149 207 291 153 207 291 minecraft:packed_ice
setblock 149 207 296 minecraft:blue_ice
fill 149 207 297 149 207 298 minecraft:snow_block
setblock 149 207 299 minecraft:packed_ice
fill 149 207 300 149 207 302 minecraft:snow_block
setblock 149 207 303 minecraft:packed_ice
fill 149 207 304 149 207 306 minecraft:snow_block
setblock 149 207 307 minecraft:packed_ice
fill 149 207 308 151 207 308 minecraft:snow_block
setblock 149 207 311 minecraft:packed_ice
fill 149 207 312 151 207 312 minecraft:snow_block
setblock 149 207 315 minecraft:packed_ice
fill 149 207 316 151 207 316 minecraft:snow_block
fill 150 207 276 150 207 277 minecraft:snow_block
setblock 150 207 278 minecraft:packed_ice
fill 150 207 279 150 207 281 minecraft:snow_block
setblock 150 207 282 minecraft:packed_ice
fill 150 207 283 150 207 284 minecraft:snow_block
fill 150 207 287 153 207 290 minecraft:packed_ice
fill 150 207 292 153 207 295 minecraft:packed_ice
setblock 150 207 298 minecraft:packed_ice
fill 150 207 299 150 207 301 minecraft:snow_block
setblock 150 207 302 minecraft:packed_ice
fill 150 207 303 150 207 305 minecraft:snow_block
setblock 150 207 306 minecraft:packed_ice
fill 150 207 307 152 207 307 minecraft:snow_block
setblock 150 207 310 minecraft:packed_ice
fill 150 207 311 152 207 311 minecraft:snow_block
setblock 150 207 314 minecraft:packed_ice
fill 150 207 315 152 207 315 minecraft:snow_block
setblock 151 207 276 minecraft:snow_block
setblock 151 207 277 minecraft:packed_ice
fill 151 207 278 151 207 280 minecraft:snow_block
setblock 151 207 281 minecraft:packed_ice
fill 151 207 282 151 207 283 minecraft:snow_block
fill 151 207 299 151 207 300 minecraft:snow_block
setblock 151 207 301 minecraft:packed_ice
fill 151 207 302 151 207 304 minecraft:snow_block
setblock 151 207 305 minecraft:packed_ice
fill 151 207 306 153 207 306 minecraft:snow_block
setblock 151 207 309 minecraft:packed_ice
fill 151 207 310 153 207 310 minecraft:snow_block
setblock 151 207 313 minecraft:packed_ice
fill 151 207 314 153 207 314 minecraft:snow_block
setblock 152 207 276 minecraft:packed_ice
fill 152 207 277 152 207 279 minecraft:snow_block
setblock 152 207 280 minecraft:packed_ice
fill 152 207 281 152 207 282 minecraft:snow_block
setblock 152 207 300 minecraft:packed_ice
fill 152 207 301 152 207 303 minecraft:snow_block
setblock 152 207 304 minecraft:packed_ice
fill 152 207 305 154 207 305 minecraft:snow_block
setblock 152 207 308 minecraft:packed_ice
fill 152 207 309 154 207 309 minecraft:snow_block
setblock 152 207 312 minecraft:packed_ice
fill 152 207 313 154 207 313 minecraft:snow_block
setblock 152 207 316 minecraft:packed_ice
fill 153 207 276 153 207 278 minecraft:snow_block
setblock 153 207 279 minecraft:packed_ice
fill 153 207 280 154 207 281 minecraft:snow_block
setblock 153 207 282 minecraft:blue_ice
setblock 153 207 300 minecraft:blue_ice
fill 153 207 301 153 207 302 minecraft:snow_block
setblock 153 207 303 minecraft:packed_ice
fill 153 207 304 155 207 304 minecraft:snow_block
setblock 153 207 307 minecraft:packed_ice
fill 153 207 308 155 207 308 minecraft:snow_block
setblock 153 207 311 minecraft:packed_ice
fill 153 207 312 155 207 312 minecraft:snow_block
setblock 153 207 315 minecraft:packed_ice
fill 153 207 316 155 207 316 minecraft:snow_block
fill 154 207 276 154 207 277 minecraft:snow_block
setblock 154 207 278 minecraft:packed_ice
fill 154 207 279 156 207 279 minecraft:snow_block
fill 154 207 287 154 207 289 minecraft:packed_ice
fill 154 207 290 154 207 292 minecraft:sea_lantern
fill 154 207 293 154 207 295 minecraft:packed_ice
setblock 154 207 301 minecraft:snow_block
setblock 154 207 302 minecraft:packed_ice
fill 154 207 303 156 207 303 minecraft:snow_block
setblock 154 207 306 minecraft:packed_ice
fill 154 207 307 156 207 307 minecraft:snow_block
setblock 154 207 310 minecraft:packed_ice
fill 154 207 311 156 207 311 minecraft:snow_block
setblock 154 207 314 minecraft:packed_ice
fill 154 207 315 156 207 315 minecraft:snow_block
setblock 155 207 276 minecraft:snow_block
setblock 155 207 277 minecraft:packed_ice
fill 155 207 278 157 207 278 minecraft:snow_block
setblock 155 207 280 minecraft:snow_block
setblock 155 207 281 minecraft:blue_ice
fill 155 207 287 156 207 287 minecraft:packed_ice
fill 155 207 288 155 207 290 minecraft:sea_lantern
fill 155 207 292 155 207 294 minecraft:sea_lantern
fill 155 207 295 156 207 295 minecraft:packed_ice
setblock 155 207 301 minecraft:blue_ice
fill 155 207 302 157 207 302 minecraft:snow_block
setblock 155 207 305 minecraft:packed_ice
fill 155 207 306 157 207 306 minecraft:snow_block
setblock 155 207 309 minecraft:packed_ice
fill 155 207 310 157 207 310 minecraft:snow_block
setblock 155 207 313 minecraft:packed_ice
fill 155 207 314 157 207 314 minecraft:snow_block
setblock 156 207 276 minecraft:packed_ice
fill 156 207 277 158 207 277 minecraft:snow_block
setblock 156 207 280 minecraft:packed_ice
fill 156 207 288 157 207 288 minecraft:sea_lantern
fill 156 207 294 157 207 294 minecraft:sea_lantern
setblock 156 207 304 minecraft:packed_ice
fill 156 207 305 158 207 305 minecraft:snow_block
setblock 156 207 308 minecraft:packed_ice
fill 156 207 309 158 207 309 minecraft:snow_block
setblock 156 207 312 minecraft:packed_ice
fill 156 207 313 158 207 313 minecraft:snow_block
setblock 156 207 316 minecraft:packed_ice
fill 157 207 276 159 207 276 minecraft:snow_block
setblock 157 207 279 minecraft:packed_ice
fill 157 207 280 159 207 280 minecraft:snow_block
fill 157 207 287 159 207 287 minecraft:sea_lantern
fill 157 207 295 159 207 295 minecraft:sea_lantern
setblock 157 207 303 minecraft:packed_ice
fill 157 207 304 159 207 304 minecraft:snow_block
setblock 157 207 307 minecraft:packed_ice
fill 157 207 308 159 207 308 minecraft:snow_block
setblock 157 207 311 minecraft:packed_ice
fill 157 207 312 159 207 312 minecraft:snow_block
setblock 157 207 315 minecraft:packed_ice
fill 157 207 316 159 207 316 minecraft:snow_block
setblock 158 207 278 minecraft:packed_ice
fill 158 207 279 160 207 279 minecraft:snow_block
setblock 158 207 302 minecraft:packed_ice
fill 158 207 303 160 207 303 minecraft:snow_block
setblock 158 207 306 minecraft:packed_ice
fill 158 207 307 160 207 307 minecraft:snow_block
setblock 158 207 310 minecraft:packed_ice
fill 158 207 311 160 207 311 minecraft:snow_block
setblock 158 207 314 minecraft:packed_ice
fill 158 207 315 160 207 315 minecraft:snow_block
setblock 159 207 277 minecraft:packed_ice
fill 159 207 278 161 207 278 minecraft:snow_block
fill 159 207 288 161 207 288 minecraft:sea_lantern
fill 159 207 294 161 207 294 minecraft:sea_lantern
fill 159 207 302 161 207 302 minecraft:snow_block
setblock 159 207 305 minecraft:packed_ice
fill 159 207 306 161 207 306 minecraft:snow_block
setblock 159 207 309 minecraft:packed_ice
fill 159 207 310 161 207 310 minecraft:snow_block
setblock 159 207 313 minecraft:packed_ice
fill 159 207 314 161 207 314 minecraft:snow_block
setblock 160 207 276 minecraft:packed_ice
fill 160 207 277 162 207 277 minecraft:snow_block
setblock 160 207 280 minecraft:packed_ice
fill 160 207 287 166 207 287 minecraft:packed_ice
fill 160 207 295 166 207 295 minecraft:packed_ice
setblock 160 207 304 minecraft:packed_ice
fill 160 207 305 162 207 305 minecraft:snow_block
setblock 160 207 308 minecraft:packed_ice
fill 160 207 309 162 207 309 minecraft:snow_block
setblock 160 207 312 minecraft:packed_ice
fill 160 207 313 162 207 313 minecraft:snow_block
setblock 160 207 316 minecraft:packed_ice
fill 161 207 276 163 207 276 minecraft:snow_block
setblock 161 207 279 minecraft:packed_ice
fill 161 207 280 163 207 280 minecraft:snow_block
setblock 161 207 281 minecraft:blue_ice
fill 161 207 289 161 207 290 minecraft:sea_lantern
fill 161 207 292 161 207 293 minecraft:sea_lantern
setblock 161 207 301 minecraft:blue_ice
setblock 161 207 303 minecraft:packed_ice
fill 161 207 304 163 207 304 minecraft:snow_block
setblock 161 207 307 minecraft:packed_ice
fill 161 207 308 163 207 308 minecraft:snow_block
setblock 161 207 311 minecraft:packed_ice
fill 161 207 312 163 207 312 minecraft:snow_block
setblock 161 207 315 minecraft:packed_ice
fill 161 207 316 163 207 316 minecraft:snow_block
setblock 162 207 278 minecraft:packed_ice
fill 162 207 279 164 207 279 minecraft:snow_block
setblock 162 207 281 minecraft:snow_block
fill 162 207 288 166 207 289 minecraft:packed_ice
fill 162 207 290 162 207 292 minecraft:sea_lantern
fill 162 207 293 166 207 294 minecraft:packed_ice
setblock 162 207 301 minecraft:snow_block
setblock 162 207 302 minecraft:packed_ice
fill 162 207 303 164 207 303 minecraft:snow_block
setblock 162 207 306 minecraft:packed_ice
fill 162 207 307 164 207 307 minecraft:snow_block
setblock 162 207 310 minecraft:packed_ice
fill 162 207 311 164 207 311 minecraft:snow_block
setblock 162 207 314 minecraft:packed_ice
fill 162 207 315 164 207 315 minecraft:snow_block
setblock 163 207 277 minecraft:packed_ice
fill 163 207 278 165 207 278 minecraft:snow_block
setblock 163 207 281 minecraft:packed_ice
setblock 163 207 282 minecraft:blue_ice
fill 163 207 290 166 207 292 minecraft:packed_ice
setblock 163 207 300 minecraft:blue_ice
setblock 163 207 301 minecraft:packed_ice
fill 163 207 302 165 207 302 minecraft:snow_block
setblock 163 207 305 minecraft:packed_ice
fill 163 207 306 165 207 306 minecraft:snow_block
setblock 163 207 309 minecraft:packed_ice
fill 163 207 310 165 207 310 minecraft:snow_block
setblock 163 207 313 minecraft:packed_ice
fill 163 207 314 165 207 314 minecraft:snow_block
setblock 164 207 276 minecraft:packed_ice
fill 164 207 277 166 207 277 minecraft:snow_block
setblock 164 207 280 minecraft:packed_ice
fill 164 207 281 165 207 282 minecraft:snow_block
setblock 164 207 300 minecraft:packed_ice
fill 164 207 301 166 207 301 minecraft:snow_block
setblock 164 207 304 minecraft:packed_ice
fill 164 207 305 166 207 305 minecraft:snow_block
setblock 164 207 308 minecraft:packed_ice
fill 164 207 309 166 207 309 minecraft:snow_block
setblock 164 207 312 minecraft:packed_ice
fill 164 207 313 166 207 313 minecraft:snow_block
setblock 164 207 316 minecraft:packed_ice
fill 165 207 276 167 207 276 minecraft:snow_block
setblock 165 207 279 minecraft:packed_ice
fill 165 207 280 167 207 280 minecraft:snow_block
setblock 165 207 283 minecraft:packed_ice
setblock 165 207 299 minecraft:packed_ice
fill 165 207 300 167 207 300 minecraft:snow_block
setblock 165 207 303 minecraft:packed_ice
fill 165 207 304 167 207 304 minecraft:snow_block
setblock 165 207 307 minecraft:packed_ice
fill 165 207 308 167 207 308 minecraft:snow_block
setblock 165 207 311 minecraft:packed_ice
fill 165 207 312 167 207 312 minecraft:snow_block
setblock 165 207 315 minecraft:packed_ice
fill 165 207 316 167 207 316 minecraft:snow_block
setblock 166 207 278 minecraft:packed_ice
fill 166 207 279 168 207 279 minecraft:snow_block
setblock 166 207 281 minecraft:snow_block
setblock 166 207 282 minecraft:packed_ice
fill 166 207 283 167 207 284 minecraft:snow_block
setblock 166 207 298 minecraft:packed_ice
fill 166 207 299 168 207 299 minecraft:snow_block
setblock 166 207 302 minecraft:packed_ice
fill 166 207 303 168 207 303 minecraft:snow_block
setblock 166 207 306 minecraft:packed_ice
fill 166 207 307 168 207 307 minecraft:snow_block
setblock 166 207 310 minecraft:packed_ice
fill 166 207 311 168 207 311 minecraft:snow_block
setblock 166 207 314 minecraft:packed_ice
fill 166 207 315 168 207 315 minecraft:snow_block
setblock 167 207 277 minecraft:packed_ice
fill 167 207 278 169 207 278 minecraft:snow_block
setblock 167 207 281 minecraft:packed_ice
fill 167 207 282 169 207 282 minecraft:snow_block
setblock 167 207 285 minecraft:packed_ice
setblock 167 207 286 minecraft:blue_ice
setblock 167 207 291 minecraft:packed_ice
setblock 167 207 296 minecraft:blue_ice
setblock 167 207 297 minecraft:packed_ice
fill 167 207 298 169 207 298 minecraft:snow_block
setblock 167 207 301 minecraft:packed_ice
fill 167 207 302 169 207 302 minecraft:snow_block
setblock 167 207 305 minecraft:packed_ice
fill 167 207 306 169 207 306 minecraft:snow_block
setblock 167 207 309 minecraft:packed_ice
fill 167 207 310 169 207 310 minecraft:snow_block
setblock 167 207 313 minecraft:packed_ice
fill 167 207 314 169 207 314 minecraft:snow_block
setblock 168 207 276 minecraft:packed_ice
fill 168 207 277 170 207 277 minecraft:snow_block
setblock 168 207 280 minecraft:packed_ice
fill 168 207 281 170 207 281 minecraft:snow_block
setblock 168 207 283 minecraft:snow_block
setblock 168 207 284 minecraft:packed_ice
fill 168 207 285 168 207 287 minecraft:snow_block
setblock 168 207 288 minecraft:blue_ice
setblock 168 207 294 minecraft:blue_ice
setblock 168 207 295 minecraft:snow_block
setblock 168 207 296 minecraft:packed_ice
fill 168 207 297 170 207 297 minecraft:snow_block
setblock 168 207 300 minecraft:packed_ice
fill 168 207 301 170 207 301 minecraft:snow_block
setblock 168 207 304 minecraft:packed_ice
fill 168 207 305 170 207 305 minecraft:snow_block
setblock 168 207 308 minecraft:packed_ice
fill 168 207 309 170 207 309 minecraft:snow_block
setblock 168 207 312 minecraft:packed_ice
fill 168 207 313 170 207 313 minecraft:snow_block
setblock 168 207 316 minecraft:packed_ice
fill 169 207 276 171 207 276 minecraft:snow_block
setblock 169 207 279 minecraft:packed_ice
fill 169 207 280 171 207 280 minecraft:snow_block
setblock 169 207 283 minecraft:packed_ice
fill 169 207 284 169 207 286 minecraft:snow_block
setblock 169 207 287 minecraft:packed_ice
fill 169 207 288 169 207 290 minecraft:snow_block
setblock 169 207 291 minecraft:packed_ice
fill 169 207 292 169 207 294 minecraft:snow_block
setblock 169 207 295 minecraft:packed_ice
fill 169 207 296 171 207 296 minecraft:snow_block
setblock 169 207 299 minecraft:packed_ice
fill 169 207 300 171 207 300 minecraft:snow_block
setblock 169 207 303 minecraft:packed_ice
fill 169 207 304 171 207 304 minecraft:snow_block
setblock 169 207 307 minecraft:packed_ice
fill 169 207 308 171 207 308 minecraft:snow_block
setblock 169 207 311 minecraft:packed_ice
fill 169 207 312 171 207 312 minecraft:snow_block
setblock 169 207 315 minecraft:packed_ice
fill 169 207 316 171 207 316 minecraft:snow_block
setblock 170 207 278 minecraft:packed_ice
fill 170 207 279 172 207 279 minecraft:snow_block
setblock 170 207 282 minecraft:packed_ice
fill 170 207 283 170 207 285 minecraft:snow_block
setblock 170 207 286 minecraft:packed_ice
fill 170 207 287 170 207 289 minecraft:snow_block
setblock 170 207 290 minecraft:packed_ice
fill 170 207 291 170 207 293 minecraft:snow_block
setblock 170 207 294 minecraft:packed_ice
fill 170 207 295 172 207 295 minecraft:snow_block
setblock 170 207 298 minecraft:packed_ice
fill 170 207 299 172 207 299 minecraft:snow_block
setblock 170 207 302 minecraft:packed_ice
fill 170 207 303 172 207 303 minecraft:snow_block
setblock 170 207 306 minecraft:packed_ice
fill 170 207 307 172 207 307 minecraft:snow_block
setblock 170 207 310 minecraft:packed_ice
fill 170 207 311 172 207 311 minecraft:snow_block
setblock 170 207 314 minecraft:packed_ice
fill 170 207 315 172 207 315 minecraft:snow_block
setblock 171 207 277 minecraft:packed_ice
fill 171 207 278 173 207 278 minecraft:snow_block
setblock 171 207 281 minecraft:packed_ice
fill 171 207 282 171 207 284 minecraft:snow_block
setblock 171 207 285 minecraft:packed_ice
fill 171 207 286 171 207 288 minecraft:snow_block
setblock 171 207 289 minecraft:packed_ice
fill 171 207 290 171 207 292 minecraft:snow_block
setblock 171 207 293 minecraft:packed_ice
fill 171 207 294 173 207 294 minecraft:snow_block
setblock 171 207 297 minecraft:packed_ice
fill 171 207 298 173 207 298 minecraft:snow_block
setblock 171 207 301 minecraft:packed_ice
fill 171 207 302 173 207 302 minecraft:snow_block
setblock 171 207 305 minecraft:packed_ice
fill 171 207 306 173 207 306 minecraft:snow_block
setblock 171 207 309 minecraft:packed_ice
fill 171 207 310 173 207 310 minecraft:snow_block
setblock 171 207 313 minecraft:packed_ice
fill 171 207 314 173 207 314 minecraft:snow_block
setblock 172 207 276 minecraft:packed_ice
fill 172 207 277 174 207 277 minecraft:snow_block
setblock 172 207 280 minecraft:packed_ice
fill 172 207 281 172 207 283 minecraft:snow_block
setblock 172 207 284 minecraft:packed_ice
fill 172 207 285 172 207 287 minecraft:snow_block
setblock 172 207 288 minecraft:packed_ice
fill 172 207 289 172 207 291 minecraft:snow_block
setblock 172 207 292 minecraft:packed_ice
fill 172 207 293 174 207 293 minecraft:snow_block
setblock 172 207 296 minecraft:packed_ice
fill 172 207 297 174 207 297 minecraft:snow_block
setblock 172 207 300 minecraft:packed_ice
fill 172 207 301 174 207 301 minecraft:snow_block
setblock 172 207 304 minecraft:packed_ice
fill 172 207 305 174 207 305 minecraft:snow_block
setblock 172 207 308 minecraft:packed_ice
fill 172 207 309 174 207 309 minecraft:snow_block
setblock 172 207 312 minecraft:packed_ice
fill 172 207 313 174 207 313 minecraft:snow_block
setblock 172 207 316 minecraft:packed_ice
fill 173 207 276 175 207 276 minecraft:snow_block
setblock 173 207 279 minecraft:packed_ice
fill 173 207 280 173 207 282 minecraft:snow_block
setblock 173 207 283 minecraft:packed_ice
fill 173 207 284 173 207 286 minecraft:snow_block
setblock 173 207 287 minecraft:packed_ice
fill 173 207 288 173 207 290 minecraft:snow_block
setblock 173 207 291 minecraft:packed_ice
fill 173 207 292 175 207 292 minecraft:snow_block
setblock 173 207 295 minecraft:packed_ice
fill 173 207 296 175 207 296 minecraft:snow_block
setblock 173 207 299 minecraft:packed_ice
fill 173 207 300 175 207 300 minecraft:snow_block
setblock 173 207 303 minecraft:packed_ice
fill 173 207 304 175 207 304 minecraft:snow_block
setblock 173 207 307 minecraft:packed_ice
fill 173 207 308 175 207 308 minecraft:snow_block
setblock 173 207 311 minecraft:packed_ice
fill 173 207 312 175 207 312 minecraft:snow_block
setblock 173 207 315 minecraft:packed_ice
fill 173 207 316 175 207 316 minecraft:snow_block
setblock 174 207 278 minecraft:packed_ice
fill 174 207 279 174 207 281 minecraft:snow_block
setblock 174 207 282 minecraft:packed_ice
fill 174 207 283 174 207 285 minecraft:snow_block
setblock 174 207 286 minecraft:packed_ice
fill 174 207 287 174 207 289 minecraft:snow_block
setblock 174 207 290 minecraft:packed_ice
fill 174 207 291 176 207 291 minecraft:snow_block
setblock 174 207 294 minecraft:packed_ice
fill 174 207 295 176 207 295 minecraft:snow_block
setblock 174 207 298 minecraft:packed_ice
fill 174 207 299 176 207 299 minecraft:snow_block
setblock 174 207 302 minecraft:packed_ice
fill 174 207 303 176 207 303 minecraft:snow_block
setblock 174 207 306 minecraft:packed_ice
fill 174 207 307 176 207 307 minecraft:snow_block
setblock 174 207 310 minecraft:packed_ice
fill 174 207 311 176 207 311 minecraft:snow_block
setblock 174 207 314 minecraft:packed_ice
fill 174 207 315 176 207 315 minecraft:snow_block
setblock 175 207 277 minecraft:packed_ice
fill 175 207 278 175 207 280 minecraft:snow_block
setblock 175 207 281 minecraft:packed_ice
fill 175 207 282 175 207 284 minecraft:snow_block
setblock 175 207 285 minecraft:packed_ice
fill 175 207 286 175 207 288 minecraft:snow_block
setblock 175 207 289 minecraft:packed_ice
fill 175 207 290 177 207 290 minecraft:snow_block
setblock 175 207 293 minecraft:packed_ice
fill 175 207 294 177 207 294 minecraft:snow_block
setblock 175 207 297 minecraft:packed_ice
fill 175 207 298 177 207 298 minecraft:snow_block
setblock 175 207 301 minecraft:packed_ice
fill 175 207 302 177 207 302 minecraft:snow_block
setblock 175 207 305 minecraft:packed_ice
fill 175 207 306 177 207 306 minecraft:snow_block
setblock 175 207 309 minecraft:packed_ice
fill 175 207 310 177 207 310 minecraft:snow_block
setblock 175 207 313 minecraft:packed_ice
fill 175 207 314 177 207 314 minecraft:snow_block
setblock 176 207 276 minecraft:packed_ice
fill 176 207 277 176 207 279 minecraft:snow_block
setblock 176 207 280 minecraft:packed_ice
fill 176 207 281 176 207 283 minecraft:snow_block
setblock 176 207 284 minecraft:packed_ice
fill 176 207 285 176 207 287 minecraft:snow_block
setblock 176 207 288 minecraft:packed_ice
fill 176 207 289 178 207 289 minecraft:snow_block
setblock 176 207 292 minecraft:packed_ice
fill 176 207 293 178 207 293 minecraft:snow_block
setblock 176 207 296 minecraft:packed_ice
fill 176 207 297 178 207 297 minecraft:snow_block
setblock 176 207 300 minecraft:packed_ice
fill 176 207 301 178 207 301 minecraft:snow_block
setblock 176 207 304 minecraft:packed_ice
fill 176 207 305 178 207 305 minecraft:snow_block
setblock 176 207 308 minecraft:packed_ice
fill 176 207 309 178 207 309 minecraft:snow_block
setblock 176 207 312 minecraft:packed_ice
fill 176 207 313 178 207 313 minecraft:snow_block
setblock 176 207 316 minecraft:packed_ice
fill 177 207 276 177 207 278 minecraft:snow_block
setblock 177 207 279 minecraft:packed_ice
fill 177 207 280 177 207 282 minecraft:snow_block
setblock 177 207 283 minecraft:packed_ice
fill 177 207 284 177 207 286 minecraft:snow_block
setblock 177 207 287 minecraft:packed_ice
fill 177 207 288 179 207 288 minecraft:snow_block
setblock 177 207 291 minecraft:packed_ice
fill 177 207 292 179 207 292 minecraft:snow_block
setblock 177 207 295 minecraft:packed_ice
fill 177 207 296 179 207 296 minecraft:snow_block
setblock 177 207 299 minecraft:packed_ice
fill 177 207 300 179 207 300 minecraft:snow_block
setblock 177 207 303 minecraft:packed_ice
fill 177 207 304 179 207 304 minecraft:snow_block
setblock 177 207 307 minecraft:packed_ice
fill 177 207 308 179 207 308 minecraft:snow_block
setblock 177 207 311 minecraft:packed_ice
fill 177 207 312 179 207 312 minecraft:snow_block
setblock 177 207 315 minecraft:packed_ice
fill 177 207 316 179 207 316 minecraft:snow_block
fill 178 207 276 178 207 277 minecraft:snow_block
setblock 178 207 278 minecraft:packed_ice
fill 178 207 279 178 207 281 minecraft:snow_block
setblock 178 207 282 minecraft:packed_ice
fill 178 207 283 178 207 285 minecraft:snow_block
setblock 178 207 286 minecraft:packed_ice
fill 178 207 287 180 207 287 minecraft:snow_block
setblock 178 207 290 minecraft:packed_ice
fill 178 207 291 180 207 291 minecraft:snow_block
setblock 178 207 294 minecraft:packed_ice
fill 178 207 295 180 207 295 minecraft:snow_block
setblock 178 207 298 minecraft:packed_ice
fill 178 207 299 180 207 299 minecraft:snow_block
setblock 178 207 302 minecraft:packed_ice
fill 178 207 303 180 207 303 minecraft:snow_block
setblock 178 207 306 minecraft:packed_ice
fill 178 207 307 180 207 307 minecraft:snow_block
setblock 178 207 310 minecraft:packed_ice
fill 178 207 311 180 207 311 minecraft:snow_block
setblock 178 207 314 minecraft:packed_ice
fill 178 207 315 180 207 315 minecraft:snow_block
setblock 179 207 276 minecraft:snow_block
setblock 179 207 277 minecraft:packed_ice
fill 179 207 278 179 207 280 minecraft:snow_block
setblock 179 207 281 minecraft:packed_ice
fill 179 207 282 179 207 284 minecraft:snow_block
setblock 179 207 285 minecraft:packed_ice
fill 179 207 286 181 207 286 minecraft:snow_block
setblock 179 207 289 minecraft:packed_ice
fill 179 207 290 181 207 290 minecraft:snow_block
setblock 179 207 293 minecraft:packed_ice
fill 179 207 294 181 207 294 minecraft:snow_block
setblock 179 207 297 minecraft:packed_ice
fill 179 207 298 181 207 298 minecraft:snow_block
setblock 179 207 301 minecraft:packed_ice
fill 179 207 302 181 207 302 minecraft:snow_block
setblock 179 207 305 minecraft:packed_ice
fill 179 207 306 181 207 306 minecraft:snow_block
setblock 179 207 309 minecraft:packed_ice
fill 179 207 310 181 207 310 minecraft:snow_block
setblock 179 207 313 minecraft:packed_ice
fill 179 207 314 181 207 314 minecraft:snow_block
setblock 180 207 276 minecraft:packed_ice
fill 180 207 277 180 207 279 minecraft:snow_block
setblock 180 207 280 minecraft:packed_ice
fill 180 207 281 180 207 283 minecraft:snow_block
setblock 180 207 284 minecraft:packed_ice
fill 180 207 285 182 207 285 minecraft:snow_block
setblock 180 207 288 minecraft:packed_ice
fill 180 207 289 182 207 289 minecraft:snow_block
setblock 180 207 292 minecraft:packed_ice
fill 180 207 293 182 207 293 minecraft:snow_block
setblock 180 207 296 minecraft:packed_ice
fill 180 207 297 182 207 297 minecraft:snow_block
setblock 180 207 300 minecraft:packed_ice
fill 180 207 301 182 207 301 minecraft:snow_block
setblock 180 207 304 minecraft:packed_ice
fill 180 207 305 182 207 305 minecraft:snow_block
setblock 180 207 308 minecraft:packed_ice
fill 180 207 309 182 207 309 minecraft:snow_block
setblock 180 207 312 minecraft:packed_ice
fill 180 207 313 182 207 313 minecraft:snow_block
setblock 180 207 316 minecraft:packed_ice
fill 181 207 276 181 207 278 minecraft:snow_block
setblock 181 207 279 minecraft:packed_ice
fill 181 207 280 181 207 282 minecraft:snow_block
setblock 181 207 283 minecraft:packed_ice
fill 181 207 284 182 207 284 minecraft:snow_block
setblock 181 207 287 minecraft:packed_ice
fill 181 207 288 182 207 288 minecraft:snow_block
setblock 181 207 291 minecraft:packed_ice
fill 181 207 292 182 207 292 minecraft:snow_block
setblock 181 207 295 minecraft:packed_ice
fill 181 207 296 182 207 296 minecraft:snow_block
setblock 181 207 299 minecraft:packed_ice
fill 181 207 300 182 207 300 minecraft:snow_block
setblock 181 207 303 minecraft:packed_ice
fill 181 207 304 182 207 304 minecraft:snow_block
setblock 181 207 307 minecraft:packed_ice
fill 181 207 308 182 207 308 minecraft:snow_block
setblock 181 207 311 minecraft:packed_ice
fill 181 207 312 182 207 312 minecraft:snow_block
setblock 181 207 315 minecraft:packed_ice
fill 181 207 316 182 207 316 minecraft:snow_block
fill 182 207 276 182 207 277 minecraft:snow_block
setblock 182 207 278 minecraft:packed_ice
fill 182 207 279 182 207 281 minecraft:snow_block
setblock 182 207 282 minecraft:packed_ice
setblock 182 207 283 minecraft:snow_block
setblock 182 207 286 minecraft:packed_ice
setblock 182 207 287 minecraft:snow_block
setblock 182 207 290 minecraft:packed_ice
setblock 182 207 291 minecraft:snow_block
setblock 182 207 294 minecraft:packed_ice
setblock 182 207 295 minecraft:snow_block
setblock 182 207 298 minecraft:packed_ice
setblock 182 207 299 minecraft:snow_block
setblock 182 207 302 minecraft:packed_ice
setblock 182 207 303 minecraft:snow_block
setblock 182 207 306 minecraft:packed_ice
setblock 182 207 307 minecraft:snow_block
setblock 182 207 310 minecraft:packed_ice
setblock 182 207 311 minecraft:snow_block
setblock 182 207 314 minecraft:packed_ice
setblock 182 207 315 minecraft:snow_block
setblock 141 208 293 minecraft:packed_ice
fill 141 208 302 141 219 302 minecraft:packed_ice
setblock 144 208 278 minecraft:light[level=15]
setblock 144 208 286 minecraft:light[level=15]
setblock 144 208 294 minecraft:light[level=15]
setblock 144 208 302 minecraft:light[level=15]
setblock 144 208 310 minecraft:light[level=15]
fill 149 208 291 150 208 291 minecraft:blue_ice
fill 150 208 287 150 208 290 minecraft:blue_ice
fill 150 208 292 150 208 295 minecraft:blue_ice
fill 151 208 284 153 209 299 minecraft:gray_concrete
setblock 152 208 278 minecraft:light[level=15]
setblock 152 208 283 minecraft:blue_ice
setblock 152 208 302 minecraft:light[level=15]
setblock 152 208 310 minecraft:light[level=15]
fill 154 208 283 162 208 283 minecraft:blue_ice
fill 154 208 284 166 209 286 minecraft:gray_concrete
fill 154 208 297 166 209 299 minecraft:gray_concrete
fill 158 208 282 158 214 282 minecraft:blue_ice
fill 158 208 300 158 214 300 minecraft:blue_ice
setblock 160 208 278 minecraft:light[level=15]
setblock 160 208 302 minecraft:light[level=15]
setblock 160 208 310 minecraft:light[level=15]
fill 164 208 287 166 209 296 minecraft:gray_concrete
fill 167 208 291 167 214 291 minecraft:blue_ice
setblock 168 208 278 minecraft:light[level=15]
setblock 168 208 286 minecraft:light[level=15]
setblock 168 208 294 minecraft:light[level=15]
setblock 168 208 302 minecraft:light[level=15]
setblock 168 208 310 minecraft:light[level=15]
setblock 176 208 278 minecraft:light[level=15]
setblock 176 208 286 minecraft:light[level=15]
setblock 176 208 294 minecraft:light[level=15]
setblock 176 208 302 minecraft:light[level=15]
setblock 176 208 310 minecraft:light[level=15]
setblock 183 208 279 minecraft:light_blue_concrete
fill 183 208 280 183 233 282 minecraft:packed_ice
setblock 183 208 308 minecraft:white_concrete
setblock 141 209 293 minecraft:white_concrete
fill 149 209 291 149 214 291 minecraft:blue_ice
fill 183 209 279 183 235 279 minecraft:packed_ice
fill 183 209 308 183 237 308 minecraft:packed_ice
fill 141 210 293 141 232 293 minecraft:packed_ice
setblock 141 210 309 minecraft:white_concrete
fill 141 210 310 141 237 310 minecraft:packed_ice
setblock 144 210 278 minecraft:light[level=12]
setblock 144 210 285 minecraft:light[level=12]
setblock 144 210 292 minecraft:light[level=12]
setblock 144 210 299 minecraft:light[level=12]
setblock 144 210 306 minecraft:light[level=12]
setblock 144 210 313 minecraft:light[level=12]
setblock 151 210 278 minecraft:light[level=12]
fill 151 210 284 151 222 284 minecraft:gray_concrete
setblock 151 210 285 minecraft:black_stained_glass
fill 151 210 286 166 223 286 minecraft:gray_concrete
setblock 151 210 287 minecraft:light_blue_stained_glass
fill 151 210 288 153 223 288 minecraft:gray_concrete
setblock 151 210 289 minecraft:black_stained_glass
fill 151 210 290 153 223 290 minecraft:gray_concrete
setblock 151 210 291 minecraft:light_blue_stained_glass
fill 151 210 292 153 223 292 minecraft:gray_concrete
setblock 151 210 293 minecraft:sea_lantern
fill 151 210 294 153 223 294 minecraft:gray_concrete
setblock 151 210 295 minecraft:light_blue_stained_glass
fill 151 210 296 153 223 296 minecraft:gray_concrete
setblock 151 210 297 minecraft:black_stained_glass
fill 151 210 298 151 223 299 minecraft:gray_concrete
setblock 151 210 306 minecraft:light[level=12]
setblock 151 210 313 minecraft:light[level=12]
setblock 152 210 284 minecraft:black_stained_glass
fill 152 210 285 165 223 285 minecraft:gray_concrete
fill 152 210 287 153 223 287 minecraft:gray_concrete
fill 152 210 289 153 223 289 minecraft:gray_concrete
fill 152 210 291 153 223 291 minecraft:gray_concrete
fill 152 210 293 153 223 293 minecraft:gray_concrete
fill 152 210 295 153 223 295 minecraft:gray_concrete
fill 152 210 297 165 223 298 minecraft:gray_concrete
setblock 152 210 299 minecraft:black_stained_glass
fill 153 210 284 153 222 284 minecraft:gray_concrete
fill 153 210 299 153 223 299 minecraft:gray_concrete
setblock 154 210 284 minecraft:black_stained_glass
setblock 154 210 299 minecraft:black_stained_glass
fill 155 210 284 155 222 284 minecraft:gray_concrete
fill 155 210 299 155 223 299 minecraft:gray_concrete
setblock 156 210 284 minecraft:sea_lantern
setblock 156 210 299 minecraft:black_stained_glass
fill 157 210 284 157 222 284 minecraft:gray_concrete
fill 157 210 299 157 223 299 minecraft:gray_concrete
setblock 158 210 278 minecraft:light[level=12]
setblock 158 210 284 minecraft:black_stained_glass
setblock 158 210 299 minecraft:sea_lantern
setblock 158 210 306 minecraft:light[level=12]
setblock 158 210 313 minecraft:light[level=12]
fill 159 210 284 159 222 284 minecraft:gray_concrete
fill 159 210 299 159 223 299 minecraft:gray_concrete
setblock 160 210 284 minecraft:light_blue_stained_glass
setblock 160 210 299 minecraft:light_blue_stained_glass
fill 161 210 284 161 222 284 minecraft:gray_concrete
fill 161 210 299 161 223 299 minecraft:gray_concrete
setblock 162 210 284 minecraft:black_stained_glass
setblock 162 210 299 minecraft:black_stained_glass
fill 163 210 284 163 222 284 minecraft:gray_concrete
fill 163 210 299 163 223 299 minecraft:gray_concrete
setblock 164 210 284 minecraft:sea_lantern
fill 164 210 287 165 223 296 minecraft:gray_concrete
setblock 164 210 299 minecraft:black_stained_glass
setblock 165 210 278 minecraft:light[level=12]
fill 165 210 284 166 222 284 minecraft:gray_concrete
fill 165 210 299 166 223 299 minecraft:gray_concrete
setblock 165 210 306 minecraft:light[level=12]
setblock 165 210 313 minecraft:light[level=12]
setblock 166 210 285 minecraft:sea_lantern
setblock 166 210 287 minecraft:black_stained_glass
fill 166 210 288 166 223 288 minecraft:gray_concrete
setblock 166 210 289 minecraft:sea_lantern
fill 166 210 290 166 223 290 minecraft:gray_concrete
setblock 166 210 291 minecraft:sea_lantern
fill 166 210 292 166 223 292 minecraft:gray_concrete
setblock 166 210 293 minecraft:sea_lantern
fill 166 210 294 166 223 294 minecraft:gray_concrete
setblock 166 210 295 minecraft:sea_lantern
fill 166 210 296 166 223 296 minecraft:gray_concrete
setblock 166 210 297 minecraft:sea_lantern
fill 166 210 298 166 223 298 minecraft:gray_concrete
setblock 172 210 278 minecraft:light[level=12]
setblock 172 210 285 minecraft:light[level=12]
setblock 172 210 292 minecraft:light[level=12]
setblock 172 210 299 minecraft:light[level=12]
setblock 172 210 306 minecraft:light[level=12]
setblock 172 210 313 minecraft:light[level=12]
setblock 179 210 278 minecraft:light[level=12]
setblock 179 210 285 minecraft:light[level=12]
setblock 179 210 292 minecraft:light[level=12]
setblock 179 210 299 minecraft:light[level=12]
setblock 179 210 306 minecraft:light[level=12]
setblock 179 210 313 minecraft:light[level=12]
fill 141 211 309 141 237 309 minecraft:packed_ice
fill 142 211 279 142 211 281 minecraft:packed_ice
setblock 142 211 282 minecraft:snow_block
fill 142 211 283 142 211 286 minecraft:packed_ice
setblock 142 211 287 minecraft:snow_block
fill 142 211 288 142 214 288 minecraft:packed_ice
fill 142 211 294 142 211 296 minecraft:packed_ice
setblock 142 211 297 minecraft:snow_block
fill 142 211 298 142 211 301 minecraft:packed_ice
setblock 142 211 302 minecraft:snow_block
fill 142 211 303 142 211 306 minecraft:packed_ice
setblock 142 211 307 minecraft:snow_block
fill 143 211 299 143 211 300 minecraft:packed_ice
setblock 143 211 301 minecraft:snow_block
fill 143 211 302 143 211 303 minecraft:packed_ice
fill 147 211 277 149 211 279 minecraft:snow_block
fill 149 211 296 150 211 297 minecraft:white_concrete
fill 151 211 276 152 211 276 minecraft:packed_ice
schedule function dropper:buildpart/63_8 1t
