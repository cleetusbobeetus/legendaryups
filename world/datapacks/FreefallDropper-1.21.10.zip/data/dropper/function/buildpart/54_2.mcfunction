setblock 318 178 236 minecraft:magma_block
fill 318 178 238 320 181 238 minecraft:basalt
setblock 318 178 239 minecraft:magma_block
setblock 318 178 242 minecraft:magma_block
setblock 318 178 245 minecraft:magma_block
fill 318 178 246 320 184 247 minecraft:basalt
setblock 318 178 248 minecraft:magma_block
setblock 318 178 254 minecraft:magma_block
fill 318 178 255 320 184 256 minecraft:basalt
setblock 318 178 257 minecraft:magma_block
setblock 318 178 260 minecraft:magma_block
fill 318 178 261 323 180 261 minecraft:basalt
setblock 318 178 263 minecraft:magma_block
setblock 318 178 266 minecraft:magma_block
setblock 318 178 269 minecraft:magma_block
setblock 319 178 233 minecraft:basalt
fill 319 178 236 322 178 236 minecraft:basalt
fill 319 178 239 323 178 239 minecraft:basalt
fill 319 178 242 323 180 242 minecraft:basalt
fill 319 178 245 323 181 245 minecraft:basalt
fill 319 178 248 320 184 254 minecraft:basalt
fill 319 178 257 323 181 257 minecraft:basalt
fill 319 178 260 323 180 260 minecraft:basalt
fill 319 178 263 323 178 263 minecraft:basalt
fill 319 178 266 322 178 266 minecraft:basalt
setblock 319 178 269 minecraft:basalt
setblock 321 178 235 minecraft:magma_block
setblock 321 178 238 minecraft:magma_block
setblock 321 178 241 minecraft:magma_block
fill 321 178 243 323 180 243 minecraft:basalt
setblock 321 178 244 minecraft:magma_block
fill 321 178 246 323 181 246 minecraft:basalt
setblock 321 178 247 minecraft:magma_block
fill 321 178 248 323 182 249 minecraft:basalt
setblock 321 178 250 minecraft:magma_block
fill 321 178 251 323 182 252 minecraft:basalt
setblock 321 178 253 minecraft:magma_block
fill 321 178 254 323 182 255 minecraft:basalt
setblock 321 178 256 minecraft:magma_block
fill 321 178 258 323 181 258 minecraft:basalt
setblock 321 178 259 minecraft:magma_block
setblock 321 178 262 minecraft:magma_block
setblock 321 178 265 minecraft:magma_block
fill 322 178 238 323 178 238 minecraft:basalt
fill 322 178 241 323 180 241 minecraft:basalt
fill 322 178 244 323 181 244 minecraft:basalt
fill 322 178 247 323 181 247 minecraft:basalt
fill 322 178 250 323 181 250 minecraft:basalt
fill 322 178 253 323 181 253 minecraft:basalt
fill 322 178 256 323 181 256 minecraft:basalt
fill 322 178 259 323 180 259 minecraft:basalt
fill 322 178 262 323 179 262 minecraft:basalt
setblock 322 178 265 minecraft:basalt
fill 282 179 243 282 204 247 minecraft:blackstone
setblock 282 179 248 minecraft:shroomlight
fill 282 179 249 282 276 249 minecraft:blackstone
setblock 282 179 251 minecraft:crying_obsidian
fill 282 179 252 282 185 252 minecraft:blackstone
fill 283 179 237 284 179 265 minecraft:basalt
fill 284 179 235 284 179 236 minecraft:basalt
setblock 284 179 266 minecraft:basalt
setblock 284 179 267 minecraft:magma_block
setblock 285 179 231 minecraft:light[level=12]
fill 285 179 234 285 179 235 minecraft:basalt
fill 285 179 238 285 182 238 minecraft:basalt
fill 285 179 241 285 184 241 minecraft:basalt
fill 285 179 244 285 185 244 minecraft:basalt
fill 285 179 247 285 186 247 minecraft:basalt
fill 285 179 250 286 186 250 minecraft:basalt
fill 285 179 253 286 186 253 minecraft:basalt
fill 285 179 256 285 186 256 minecraft:basalt
fill 285 179 259 285 185 259 minecraft:basalt
fill 285 179 262 289 183 262 minecraft:basalt
fill 285 179 265 285 181 265 minecraft:basalt
setblock 285 179 268 minecraft:basalt
fill 286 179 233 286 179 234 minecraft:basalt
fill 286 179 249 286 188 249 minecraft:basalt
fill 286 179 251 286 188 252 minecraft:basalt
setblock 286 179 269 minecraft:basalt
setblock 287 179 233 minecraft:magma_block
fill 287 179 234 288 180 234 minecraft:basalt
setblock 287 179 245 minecraft:magma_block
fill 287 179 246 287 188 246 minecraft:basalt
fill 287 179 256 287 188 256 minecraft:basalt
setblock 287 179 257 minecraft:magma_block
setblock 287 179 269 minecraft:magma_block
fill 288 179 232 291 179 233 minecraft:basalt
fill 288 179 237 288 184 237 minecraft:basalt
fill 288 179 240 288 186 240 minecraft:basalt
fill 288 179 243 288 188 244 minecraft:basalt
fill 288 179 258 288 188 259 minecraft:basalt
fill 288 179 261 288 186 261 minecraft:basalt
fill 288 179 264 288 184 264 minecraft:basalt
fill 288 179 267 288 182 267 minecraft:basalt
fill 288 179 269 291 180 269 minecraft:basalt
fill 289 179 231 290 179 231 minecraft:basalt
fill 289 179 242 289 189 242 minecraft:basalt
fill 289 179 260 289 188 260 minecraft:basalt
fill 290 179 230 291 179 230 minecraft:basalt
setblock 290 179 241 minecraft:magma_block
fill 290 179 261 290 188 261 minecraft:basalt
setblock 290 179 262 minecraft:magma_block
fill 291 179 236 291 185 236 minecraft:basalt
fill 291 179 239 292 179 239 minecraft:basalt
fill 291 179 263 292 179 263 minecraft:basalt
fill 291 179 266 291 185 266 minecraft:basalt
fill 292 179 229 294 179 229 minecraft:basalt
fill 292 179 232 294 182 232 minecraft:basalt
fill 293 179 238 293 188 238 minecraft:basalt
setblock 293 179 239 minecraft:light[level=12]
setblock 293 179 247 minecraft:light[level=12]
setblock 293 179 255 minecraft:light[level=12]
setblock 293 179 263 minecraft:light[level=12]
setblock 293 179 264 minecraft:magma_block
fill 294 179 235 298 186 235 minecraft:basalt
fill 294 179 237 295 188 237 minecraft:basalt
fill 294 179 265 295 179 265 minecraft:basalt
fill 294 179 268 294 185 268 minecraft:basalt
setblock 296 179 236 minecraft:magma_block
setblock 296 179 266 minecraft:magma_block
fill 297 179 231 297 183 231 minecraft:basalt
fill 297 179 234 297 186 234 minecraft:basalt
fill 297 179 236 297 188 236 minecraft:basalt
fill 297 179 266 297 186 267 minecraft:basalt
setblock 299 179 235 minecraft:magma_block
fill 300 179 230 300 182 230 minecraft:basalt
fill 300 179 233 300 185 233 minecraft:basalt
fill 300 179 235 304 188 235 minecraft:basalt
fill 300 179 267 301 188 267 minecraft:basalt
fill 300 179 269 300 185 269 minecraft:basalt
setblock 301 179 239 minecraft:light[level=12]
setblock 301 179 247 minecraft:light[level=12]
setblock 301 179 255 minecraft:light[level=12]
setblock 301 179 263 minecraft:light[level=12]
setblock 302 179 267 minecraft:magma_block
fill 303 179 229 303 181 229 minecraft:basalt
fill 303 179 232 303 184 232 minecraft:basalt
fill 303 179 267 303 186 268 minecraft:basalt
fill 304 179 267 304 188 267 minecraft:basalt
fill 306 179 231 306 183 231 minecraft:basalt
fill 306 179 234 306 186 234 minecraft:basalt
fill 306 179 267 306 186 267 minecraft:basalt
fill 307 179 236 309 186 236 minecraft:basalt
fill 307 179 266 309 186 266 minecraft:basalt
fill 309 179 230 313 179 230 minecraft:basalt
fill 309 179 233 309 184 233 minecraft:basalt
fill 309 179 237 310 188 237 minecraft:basalt
setblock 309 179 239 minecraft:light[level=12]
setblock 309 179 247 minecraft:light[level=12]
setblock 309 179 255 minecraft:light[level=12]
setblock 309 179 263 minecraft:light[level=12]
fill 309 179 265 310 188 265 minecraft:basalt
fill 309 179 269 309 184 269 minecraft:basalt
fill 311 179 238 312 186 238 minecraft:basalt
setblock 311 179 264 minecraft:magma_block
setblock 312 179 229 minecraft:basalt
fill 312 179 232 316 179 232 minecraft:basalt
fill 312 179 235 312 185 235 minecraft:basalt
fill 312 179 239 312 188 239 minecraft:basalt
fill 312 179 263 312 188 263 minecraft:basalt
fill 312 179 265 312 186 265 minecraft:basalt
fill 312 179 268 319 179 268 minecraft:basalt
setblock 314 179 230 minecraft:magma_block
fill 314 179 241 314 188 241 minecraft:basalt
fill 314 179 261 315 186 261 minecraft:basalt
setblock 315 179 231 minecraft:basalt
fill 315 179 234 319 179 234 minecraft:basalt
fill 315 179 237 321 179 237 minecraft:basalt
fill 315 179 240 315 186 240 minecraft:basalt
fill 315 179 242 315 188 242 minecraft:basalt
fill 315 179 260 315 188 260 minecraft:basalt
fill 315 179 264 322 179 264 minecraft:basalt
fill 315 179 267 319 179 267 minecraft:basalt
fill 316 179 243 316 188 244 minecraft:basalt
fill 316 179 258 316 179 259 minecraft:basalt
setblock 317 179 231 minecraft:light[level=12]
fill 317 179 245 317 188 246 minecraft:basalt
setblock 317 179 247 minecraft:light[level=12]
setblock 317 179 255 minecraft:light[level=12]
setblock 317 179 256 minecraft:magma_block
fill 317 179 257 318 186 257 minecraft:basalt
setblock 318 179 233 minecraft:basalt
fill 318 179 236 320 179 236 minecraft:basalt
fill 318 179 239 322 179 239 minecraft:basalt
fill 318 179 242 318 185 242 minecraft:basalt
fill 318 179 245 318 186 245 minecraft:basalt
fill 318 179 248 318 186 254 minecraft:basalt
fill 318 179 260 318 185 260 minecraft:basalt
fill 318 179 263 322 179 263 minecraft:basalt
fill 318 179 266 320 179 266 minecraft:basalt
setblock 318 179 269 minecraft:basalt
setblock 320 179 267 minecraft:magma_block
fill 321 179 238 322 179 238 minecraft:basalt
fill 321 179 241 321 182 241 minecraft:basalt
fill 321 179 244 321 183 244 minecraft:basalt
fill 321 179 247 321 184 247 minecraft:basalt
fill 321 179 250 321 184 250 minecraft:basalt
fill 321 179 253 321 184 253 minecraft:basalt
fill 321 179 256 321 184 256 minecraft:basalt
fill 321 179 259 321 183 259 minecraft:basalt
fill 321 179 262 321 181 262 minecraft:basalt
setblock 321 179 265 minecraft:basalt
setblock 323 179 239 minecraft:magma_block
setblock 323 179 263 minecraft:magma_block
fill 282 180 248 282 230 248 minecraft:blackstone
fill 282 180 251 282 189 251 minecraft:blackstone
fill 283 180 228 285 251 228 minecraft:blackstone
fill 283 180 238 284 180 238 minecraft:basalt
setblock 283 180 239 minecraft:magma_block
fill 283 180 240 284 181 262 minecraft:basalt
setblock 283 180 263 minecraft:magma_block
fill 283 180 264 284 180 264 minecraft:basalt
setblock 284 180 237 minecraft:basalt
fill 284 180 239 284 181 239 minecraft:basalt
fill 284 180 263 284 181 263 minecraft:basalt
setblock 284 180 265 minecraft:basalt
fill 285 180 266 287 180 266 minecraft:basalt
setblock 286 180 228 minecraft:crying_obsidian
setblock 286 180 235 minecraft:magma_block
fill 286 180 267 287 180 267 minecraft:basalt
fill 287 180 228 288 180 228 minecraft:blackstone
fill 287 180 235 293 181 235 minecraft:basalt
fill 287 180 245 288 187 245 minecraft:basalt
fill 287 180 247 287 188 255 minecraft:basalt
fill 287 180 257 288 187 257 minecraft:basalt
fill 287 180 268 293 180 268 minecraft:basalt
fill 288 180 233 291 180 233 minecraft:basalt
fill 289 180 232 291 180 232 minecraft:basalt
setblock 289 180 243 minecraft:magma_block
fill 289 180 259 289 189 259 minecraft:basalt
fill 290 180 241 290 187 242 minecraft:basalt
fill 290 180 260 290 189 260 minecraft:basalt
fill 290 180 262 291 187 262 minecraft:basalt
fill 291 180 239 291 188 240 minecraft:basalt
fill 291 180 263 291 188 263 minecraft:basalt
setblock 292 180 230 minecraft:magma_block
setblock 292 180 239 minecraft:magma_block
setblock 292 180 263 minecraft:magma_block
fill 293 180 230 299 180 230 minecraft:basalt
fill 293 180 239 293 189 239 minecraft:basalt
fill 293 180 263 293 187 264 minecraft:basalt
fill 294 180 238 294 189 238 minecraft:basalt
fill 294 180 264 294 188 265 minecraft:basalt
setblock 295 180 229 minecraft:magma_block
setblock 295 180 265 minecraft:magma_block
fill 296 180 229 302 180 229 minecraft:basalt
fill 296 180 236 296 187 237 minecraft:basalt
fill 296 180 265 296 187 266 minecraft:basalt
fill 298 180 236 300 188 236 minecraft:basalt
fill 298 180 266 300 188 266 minecraft:basalt
fill 299 180 228 299 191 228 minecraft:blackstone
fill 299 180 235 299 187 235 minecraft:basalt
setblock 300 180 228 minecraft:shroomlight
fill 301 180 228 301 216 228 minecraft:blackstone
setblock 301 180 236 minecraft:magma_block
setblock 301 180 266 minecraft:magma_block
fill 302 180 236 306 188 236 minecraft:basalt
fill 302 180 266 302 187 267 minecraft:basalt
fill 303 180 266 306 188 266 minecraft:basalt
fill 304 180 229 309 180 229 minecraft:basalt
fill 307 180 231 313 180 231 minecraft:basalt
fill 308 180 237 308 189 237 minecraft:basalt
fill 308 180 265 308 189 265 minecraft:basalt
fill 309 180 230 309 181 230 minecraft:basalt
setblock 310 180 230 minecraft:magma_block
fill 310 180 233 316 180 233 minecraft:basalt
fill 310 180 238 310 189 238 minecraft:basalt
fill 310 180 264 311 187 264 minecraft:basalt
fill 310 180 269 316 180 269 minecraft:basalt
fill 311 180 230 312 180 230 minecraft:basalt
fill 311 180 239 311 189 239 minecraft:basalt
fill 311 180 263 311 189 263 minecraft:basalt
fill 312 180 232 315 180 232 minecraft:basalt
fill 312 180 268 317 180 268 minecraft:basalt
fill 313 180 235 318 180 235 minecraft:basalt
fill 313 180 240 313 188 240 minecraft:basalt
setblock 313 180 262 minecraft:magma_block
fill 314 180 242 314 189 242 minecraft:basalt
fill 314 180 260 314 189 260 minecraft:basalt
fill 315 180 234 317 180 234 minecraft:basalt
fill 315 180 237 320 180 237 minecraft:basalt
fill 315 180 243 315 189 243 minecraft:basalt
fill 315 180 259 316 188 259 minecraft:basalt
fill 315 180 264 321 180 264 minecraft:basalt
fill 315 180 267 318 180 267 minecraft:basalt
fill 316 180 240 322 180 240 minecraft:basalt
fill 316 180 245 316 189 245 minecraft:basalt
fill 316 180 257 316 189 257 minecraft:basalt
setblock 316 180 258 minecraft:magma_block
fill 317 180 247 317 187 256 minecraft:basalt
fill 318 180 236 318 181 236 minecraft:basalt
fill 318 180 239 321 180 239 minecraft:basalt
fill 318 180 263 321 180 263 minecraft:basalt
fill 318 180 266 318 181 266 minecraft:basalt
setblock 319 180 236 minecraft:magma_block
setblock 319 180 266 minecraft:magma_block
setblock 321 180 238 minecraft:basalt
setblock 322 180 262 minecraft:magma_block
fill 282 181 259 282 209 260 minecraft:blackstone
setblock 282 181 261 minecraft:shroomlight
fill 282 181 262 282 203 270 minecraft:blackstone
setblock 284 181 238 minecraft:basalt
setblock 284 181 264 minecraft:basalt
setblock 285 181 237 minecraft:magma_block
fill 286 181 228 286 228 228 minecraft:blackstone
fill 286 181 236 287 181 237 minecraft:basalt
fill 286 181 266 287 181 266 minecraft:basalt
setblock 287 181 228 minecraft:shroomlight
setblock 287 181 267 minecraft:basalt
fill 288 181 228 288 283 228 minecraft:blackstone
setblock 288 181 234 minecraft:basalt
fill 288 181 246 288 189 247 minecraft:basalt
setblock 288 181 248 minecraft:magma_block
fill 288 181 249 292 181 252 minecraft:blackstone
setblock 288 181 254 minecraft:magma_block
fill 288 181 255 288 189 256 minecraft:basalt
fill 288 181 268 293 181 268 minecraft:basalt
fill 289 181 233 291 181 233 minecraft:basalt
fill 289 181 243 289 188 245 minecraft:basalt
fill 289 181 246 291 181 248 minecraft:blackstone
fill 289 181 257 289 188 258 minecraft:basalt
fill 289 181 269 291 181 269 minecraft:basalt
setblock 290 181 243 minecraft:basalt
fill 290 181 259 290 190 259 minecraft:basalt
setblock 291 181 232 minecraft:magma_block
setblock 291 181 241 minecraft:magma_block
fill 291 181 261 291 189 261 minecraft:basalt
fill 292 181 231 293 181 231 minecraft:basalt
fill 292 181 239 292 188 240 minecraft:basalt
fill 292 181 247 292 183 248 minecraft:blackstone
fill 292 181 262 292 188 263 minecraft:basalt
fill 293 181 248 293 183 251 minecraft:blackstone
setblock 294 181 231 minecraft:magma_block
fill 294 181 239 294 190 239 minecraft:basalt
fill 294 181 263 294 190 263 minecraft:basalt
fill 295 181 230 296 181 231 minecraft:basalt
fill 295 181 238 296 181 238 minecraft:basalt
fill 295 181 264 295 188 265 minecraft:basalt
fill 296 181 264 296 190 264 minecraft:basalt
setblock 297 181 230 minecraft:magma_block
fill 297 181 237 299 181 237 minecraft:basalt
fill 297 181 265 299 189 265 minecraft:basalt
fill 298 181 229 299 181 230 minecraft:basalt
fill 300 181 228 300 283 228 minecraft:blackstone
setblock 300 181 229 minecraft:magma_block
fill 301 181 229 302 181 229 minecraft:basalt
fill 301 181 236 301 188 236 minecraft:basalt
fill 301 181 266 301 188 266 minecraft:basalt
fill 304 181 229 306 181 229 minecraft:basalt
fill 305 181 237 307 188 237 minecraft:basalt
fill 305 181 265 307 181 265 minecraft:basalt
fill 307 181 231 311 181 231 minecraft:basalt
fill 308 181 238 308 190 238 minecraft:basalt
fill 308 181 264 309 181 264 minecraft:basalt
setblock 309 181 238 minecraft:magma_block
fill 310 181 233 314 181 233 minecraft:basalt
fill 310 181 239 310 190 239 minecraft:basalt
fill 310 181 263 310 190 263 minecraft:basalt
fill 310 181 269 314 181 269 minecraft:basalt
setblock 312 181 231 minecraft:magma_block
fill 312 181 232 313 181 232 minecraft:basalt
setblock 312 181 240 minecraft:magma_block
fill 312 181 262 313 188 262 minecraft:basalt
fill 312 181 268 316 181 268 minecraft:basalt
fill 313 181 235 317 181 235 minecraft:basalt
fill 313 181 241 313 188 241 minecraft:basalt
fill 313 181 261 313 189 261 minecraft:basalt
fill 313 181 265 319 181 265 minecraft:basalt
fill 314 181 243 314 190 243 minecraft:basalt
setblock 314 181 259 minecraft:basalt
setblock 315 181 233 minecraft:magma_block
fill 315 181 234 316 181 234 minecraft:basalt
fill 315 181 237 319 181 237 minecraft:basalt
fill 315 181 244 315 189 244 minecraft:basalt
setblock 315 181 245 minecraft:magma_block
setblock 315 181 257 minecraft:magma_block
fill 315 181 258 316 188 258 minecraft:basalt
fill 315 181 264 320 181 264 minecraft:basalt
fill 315 181 267 317 181 267 minecraft:basalt
setblock 315 181 269 minecraft:magma_block
fill 316 181 240 320 182 240 minecraft:basalt
fill 316 181 246 316 188 248 minecraft:basalt
fill 316 181 254 316 188 256 minecraft:basalt
fill 318 181 228 318 231 228 minecraft:blackstone
fill 318 181 239 320 181 239 minecraft:basalt
fill 318 181 261 322 181 261 minecraft:basalt
fill 318 181 263 320 181 263 minecraft:basalt
setblock 319 181 228 minecraft:shroomlight
fill 319 181 242 322 181 242 minecraft:basalt
fill 319 181 260 322 181 260 minecraft:basalt
setblock 321 181 240 minecraft:magma_block
fill 321 181 243 322 182 243 minecraft:basalt
setblock 322 181 241 minecraft:basalt
fill 322 181 259 322 182 259 minecraft:basalt
fill 324 181 243 324 217 245 minecraft:blackstone
setblock 324 181 246 minecraft:shroomlight
fill 324 181 247 324 283 247 minecraft:blackstone
setblock 282 182 254 minecraft:magma_block
fill 282 182 255 282 207 255 minecraft:blackstone
fill 282 182 261 282 283 261 minecraft:blackstone
fill 283 182 241 284 182 261 minecraft:basalt
setblock 284 182 240 minecraft:basalt
setblock 284 182 262 minecraft:basalt
fill 286 182 237 287 182 237 minecraft:basalt
fill 287 182 228 287 187 228 minecraft:blackstone
setblock 287 182 236 minecraft:basalt
setblock 287 182 266 minecraft:basalt
fill 288 182 235 293 182 235 minecraft:basalt
fill 288 182 248 288 189 254 minecraft:basalt
setblock 289 182 234 minecraft:basalt
fill 289 182 246 289 190 246 minecraft:basalt
fill 289 182 247 291 182 253 minecraft:blackstone
fill 289 182 256 289 190 256 minecraft:basalt
fill 289 182 268 293 182 268 minecraft:basalt
setblock 290 182 234 minecraft:magma_block
setblock 290 182 243 minecraft:magma_block
fill 290 182 244 290 190 244 minecraft:basalt
fill 290 182 246 292 183 246 minecraft:blackstone
setblock 290 182 258 minecraft:magma_block
fill 291 182 233 291 182 234 minecraft:basalt
fill 291 182 241 291 190 242 minecraft:basalt
fill 291 182 260 291 190 260 minecraft:basalt
setblock 291 182 269 minecraft:basalt
fill 292 182 234 296 184 234 minecraft:basalt
fill 292 182 241 292 190 241 minecraft:basalt
fill 292 182 249 292 183 252 minecraft:blackstone
fill 292 182 261 292 190 261 minecraft:basalt
fill 293 182 240 293 190 240 minecraft:basalt
fill 293 182 247 293 183 247 minecraft:blackstone
fill 293 182 252 293 183 252 minecraft:blackstone
fill 293 182 262 293 190 262 minecraft:basalt
fill 294 182 231 296 182 231 minecraft:basalt
fill 294 182 249 294 183 249 minecraft:blackstone
fill 295 182 238 295 188 239 minecraft:basalt
fill 295 182 263 295 190 263 minecraft:basalt
setblock 296 182 238 minecraft:magma_block
fill 297 182 237 297 189 238 minecraft:basalt
fill 297 182 264 297 190 264 minecraft:basalt
fill 298 182 230 299 182 230 minecraft:basalt
fill 298 182 237 298 188 237 minecraft:basalt
setblock 299 182 237 minecraft:magma_block
setblock 299 182 270 minecraft:shroomlight
fill 300 182 237 304 189 237 minecraft:basalt
fill 300 182 265 304 182 265 minecraft:basalt
fill 300 182 270 307 195 270 minecraft:blackstone
setblock 301 182 230 minecraft:basalt
setblock 302 182 230 minecraft:magma_block
fill 303 182 230 306 182 230 minecraft:basalt
setblock 305 182 265 minecraft:magma_block
fill 306 182 265 307 189 265 minecraft:basalt
fill 307 182 231 307 183 231 minecraft:basalt
fill 307 182 238 307 190 238 minecraft:basalt
fill 307 182 264 307 190 264 minecraft:basalt
setblock 308 182 231 minecraft:magma_block
setblock 308 182 264 minecraft:magma_block
fill 309 182 231 310 182 231 minecraft:basalt
fill 309 182 238 309 189 239 minecraft:basalt
fill 309 182 263 309 189 264 minecraft:basalt
fill 310 182 233 313 182 233 minecraft:basalt
fill 310 182 269 313 182 269 minecraft:basalt
fill 311 182 240 312 189 240 minecraft:basalt
fill 311 182 262 311 190 262 minecraft:basalt
setblock 312 182 232 minecraft:basalt
fill 312 182 241 312 190 241 minecraft:basalt
fill 312 182 261 312 189 261 minecraft:basalt
fill 312 182 268 313 183 268 minecraft:basalt
fill 313 182 235 316 182 235 minecraft:basalt
fill 313 182 242 313 190 242 minecraft:basalt
fill 313 182 260 313 190 260 minecraft:basalt
fill 313 182 265 318 182 265 minecraft:basalt
setblock 314 182 244 minecraft:magma_block
fill 314 182 258 314 190 258 minecraft:basalt
setblock 314 182 259 minecraft:magma_block
setblock 314 182 268 minecraft:magma_block
setblock 315 182 234 minecraft:basalt
fill 315 182 237 318 182 237 minecraft:basalt
fill 315 182 245 315 189 246 minecraft:basalt
fill 315 182 256 315 189 257 minecraft:basalt
fill 315 182 264 319 182 264 minecraft:basalt
fill 315 182 267 315 182 268 minecraft:basalt
fill 316 182 249 316 182 253 minecraft:basalt
setblock 316 182 267 minecraft:basalt
fill 318 182 238 319 182 239 minecraft:basalt
fill 318 182 261 321 182 261 minecraft:basalt
fill 318 182 263 319 182 263 minecraft:basalt
fill 319 182 228 319 283 228 minecraft:blackstone
fill 319 182 242 321 182 242 minecraft:basalt
fill 319 182 245 322 182 245 minecraft:basalt
fill 319 182 257 322 182 257 minecraft:basalt
fill 319 182 260 321 182 260 minecraft:basalt
fill 321 182 246 322 182 246 minecraft:basalt
fill 321 182 258 322 182 258 minecraft:basalt
setblock 322 182 244 minecraft:basalt
fill 322 182 247 322 183 247 minecraft:basalt
fill 322 182 250 322 183 250 minecraft:basalt
fill 322 182 253 322 183 253 minecraft:basalt
fill 322 182 256 322 183 256 minecraft:basalt
setblock 323 182 247 minecraft:magma_block
setblock 323 182 250 minecraft:magma_block
setblock 323 182 253 minecraft:magma_block
fill 324 182 229 324 205 230 minecraft:blackstone
setblock 324 182 231 minecraft:magma_block
fill 324 182 232 324 185 236 minecraft:blackstone
fill 324 182 237 324 183 237 minecraft:magma_block
fill 324 182 246 324 217 246 minecraft:blackstone
fill 282 183 232 282 203 235 minecraft:blackstone
setblock 282 183 236 minecraft:crying_obsidian
fill 282 183 254 282 283 254 minecraft:blackstone
fill 283 183 243 284 183 243 minecraft:basalt
setblock 283 183 244 minecraft:magma_block
fill 283 183 245 284 183 258 minecraft:basalt
setblock 283 183 259 minecraft:magma_block
fill 284 183 241 284 183 242 minecraft:basalt
fill 284 183 244 284 184 244 minecraft:basalt
fill 284 183 259 284 183 261 minecraft:basalt
setblock 285 183 231 minecraft:light[level=12]
setblock 285 183 238 minecraft:light[level=12]
fill 285 183 240 287 183 240 minecraft:basalt
setblock 285 183 266 minecraft:light[level=12]
fill 286 183 239 287 183 239 minecraft:basalt
fill 286 183 263 287 183 263 minecraft:basalt
setblock 286 183 264 minecraft:magma_block
setblock 287 183 237 minecraft:basalt
fill 287 183 264 287 183 265 minecraft:basalt
setblock 288 183 236 minecraft:basalt
fill 288 183 265 288 183 266 minecraft:basalt
fill 289 183 235 293 183 235 minecraft:basalt
setblock 289 183 236 minecraft:magma_block
fill 289 183 247 289 191 247 minecraft:basalt
setblock 289 183 248 minecraft:magma_block
fill 289 183 249 289 191 249 minecraft:basalt
fill 289 183 250 291 183 252 minecraft:blackstone
fill 289 183 253 289 191 253 minecraft:basalt
setblock 289 183 254 minecraft:magma_block
fill 289 183 255 289 191 255 minecraft:basalt
fill 289 183 265 293 184 265 minecraft:basalt
setblock 289 183 266 minecraft:magma_block
fill 290 183 236 290 184 236 minecraft:basalt
fill 290 183 243 291 190 243 minecraft:basalt
fill 290 183 245 290 191 245 minecraft:basalt
fill 290 183 247 291 183 249 minecraft:blackstone
fill 290 183 253 292 183 253 minecraft:blackstone
fill 290 183 257 290 190 258 minecraft:basalt
fill 290 183 266 290 184 266 minecraft:basalt
setblock 291 183 234 minecraft:basalt
setblock 291 183 245 minecraft:blackstone
fill 291 183 259 291 191 259 minecraft:basalt
fill 291 183 268 293 183 268 minecraft:basalt
setblock 292 183 231 minecraft:light[level=12]
fill 292 183 242 292 191 242 minecraft:basalt
setblock 292 183 245 minecraft:light[level=12]
setblock 292 183 259 minecraft:light[level=12]
fill 292 183 260 292 191 260 minecraft:basalt
fill 293 183 241 293 191 241 minecraft:basalt
setblock 293 183 246 minecraft:blackstone
fill 293 183 261 293 191 261 minecraft:basalt
setblock 294 183 232 minecraft:basalt
fill 294 183 240 294 191 240 minecraft:basalt
setblock 294 183 248 minecraft:blackstone
fill 294 183 250 294 183 251 minecraft:blackstone
fill 294 183 262 294 191 262 minecraft:basalt
fill 296 183 238 296 190 239 minecraft:basalt
fill 296 183 263 296 191 263 minecraft:basalt
fill 298 183 231 303 183 231 minecraft:basalt
fill 298 183 238 300 191 238 minecraft:basalt
fill 298 183 264 300 183 264 minecraft:basalt
fill 299 183 237 299 190 237 minecraft:basalt
setblock 299 183 245 minecraft:light[level=12]
setblock 299 183 252 minecraft:light[level=12]
setblock 299 183 259 minecraft:light[level=12]
fill 299 183 270 299 252 270 minecraft:blackstone
fill 300 183 265 300 189 265 minecraft:basalt
setblock 301 183 265 minecraft:magma_block
fill 302 183 265 305 190 265 minecraft:basalt
setblock 304 183 231 minecraft:magma_block
fill 304 183 232 309 183 232 minecraft:basalt
fill 304 183 238 306 190 238 minecraft:basalt
setblock 304 183 264 minecraft:magma_block
setblock 305 183 231 minecraft:basalt
fill 305 183 264 306 191 264 minecraft:basalt
setblock 306 183 245 minecraft:light[level=12]
setblock 306 183 252 minecraft:light[level=12]
setblock 306 183 259 minecraft:light[level=12]
fill 307 183 234 312 184 234 minecraft:basalt
fill 308 183 239 308 191 239 minecraft:basalt
fill 308 183 263 308 190 264 minecraft:basalt
setblock 310 183 232 minecraft:magma_block
fill 310 183 233 312 183 233 minecraft:basalt
fill 310 183 236 315 183 236 minecraft:basalt
fill 310 183 240 310 191 240 minecraft:basalt
setblock 310 183 262 minecraft:magma_block
fill 310 183 266 315 183 266 minecraft:basalt
fill 310 183 269 312 183 269 minecraft:basalt
fill 311 183 241 311 191 241 minecraft:basalt
fill 311 183 261 311 191 261 minecraft:basalt
fill 312 183 242 312 191 242 minecraft:basalt
fill 312 183 260 312 191 260 minecraft:basalt
setblock 313 183 231 minecraft:light[level=12]
setblock 313 183 234 minecraft:magma_block
fill 313 183 235 315 183 235 minecraft:basalt
setblock 313 183 243 minecraft:magma_block
setblock 313 183 245 minecraft:light[level=12]
setblock 313 183 252 minecraft:light[level=12]
fill 313 183 259 314 190 259 minecraft:basalt
fill 313 183 265 317 183 265 minecraft:basalt
fill 314 183 244 314 190 245 minecraft:basalt
fill 314 183 257 314 191 257 minecraft:basalt
fill 314 183 262 318 184 262 minecraft:basalt
fill 315 183 237 317 183 237 minecraft:basalt
fill 315 183 247 315 191 249 minecraft:basalt
fill 315 183 253 315 183 255 minecraft:basalt
fill 315 183 264 318 183 264 minecraft:basalt
setblock 315 183 267 minecraft:basalt
setblock 316 183 236 minecraft:magma_block
fill 316 183 240 319 183 240 minecraft:basalt
fill 316 183 249 316 190 250 minecraft:basalt
setblock 316 183 251 minecraft:magma_block
fill 316 183 252 316 190 253 minecraft:basalt
setblock 316 183 266 minecraft:magma_block
fill 318 183 238 318 183 239 minecraft:basalt
fill 318 183 261 320 183 261 minecraft:basalt
setblock 318 183 263 minecraft:basalt
fill 319 183 242 320 183 242 minecraft:basalt
fill 319 183 245 321 183 245 minecraft:basalt
fill 319 183 257 321 183 257 minecraft:basalt
fill 319 183 260 320 183 260 minecraft:basalt
setblock 319 183 262 minecraft:magma_block
setblock 320 183 231 minecraft:light[level=12]
setblock 320 183 238 minecraft:light[level=12]
setblock 320 183 266 minecraft:light[level=12]
setblock 321 183 243 minecraft:basalt
fill 321 183 246 321 184 246 minecraft:basalt
fill 321 183 248 321 183 249 minecraft:basalt
fill 321 183 251 321 183 252 minecraft:basalt
fill 321 183 254 321 183 255 minecraft:basalt
setblock 321 183 258 minecraft:basalt
setblock 322 183 246 minecraft:magma_block
setblock 322 183 248 minecraft:basalt
setblock 322 183 249 minecraft:magma_block
setblock 322 183 251 minecraft:basalt
setblock 322 183 252 minecraft:magma_block
setblock 322 183 254 minecraft:basalt
setblock 322 183 255 minecraft:magma_block
fill 324 183 231 324 193 231 minecraft:blackstone
setblock 324 183 266 minecraft:shroomlight
fill 324 183 267 324 184 267 minecraft:blackstone
fill 282 184 236 282 283 236 minecraft:blackstone
fill 283 184 246 284 184 256 minecraft:basalt
fill 284 184 243 287 184 243 minecraft:basalt
setblock 284 184 245 minecraft:basalt
fill 284 184 257 284 184 259 minecraft:basalt
setblock 285 184 242 minecraft:magma_block
setblock 285 184 260 minecraft:magma_block
fill 285 184 261 287 184 261 minecraft:basalt
fill 286 184 240 287 184 240 minecraft:basalt
fill 286 184 242 287 185 242 minecraft:basalt
fill 286 184 260 287 185 260 minecraft:basalt
fill 286 184 262 289 184 262 minecraft:basalt
setblock 287 184 239 minecraft:basalt
setblock 287 184 263 minecraft:basalt
setblock 288 184 238 minecraft:magma_block
setblock 288 184 265 minecraft:magma_block
fill 289 184 238 292 185 238 minecraft:basalt
fill 289 184 248 289 191 248 minecraft:basalt
fill 289 184 250 289 191 252 minecraft:basalt
fill 289 184 254 289 191 254 minecraft:basalt
fill 290 184 246 290 190 247 minecraft:basalt
fill 290 184 248 290 184 250 minecraft:magma_block
fill 290 184 255 290 191 256 minecraft:basalt
fill 291 184 235 293 184 235 minecraft:basalt
fill 291 184 244 291 191 245 minecraft:basalt
setblock 291 184 249 minecraft:magma_block
fill 291 184 257 291 192 257 minecraft:basalt
setblock 291 184 258 minecraft:magma_block
setblock 291 184 267 minecraft:magma_block
fill 292 184 243 292 192 243 minecraft:basalt
fill 292 184 259 292 191 259 minecraft:basalt
fill 292 184 267 293 184 268 minecraft:basalt
fill 293 184 242 293 192 242 minecraft:basalt
fill 293 184 260 293 192 260 minecraft:basalt
setblock 294 184 233 minecraft:magma_block
fill 294 184 241 294 192 241 minecraft:basalt
fill 294 184 261 294 192 261 minecraft:basalt
fill 294 184 267 296 186 267 minecraft:basalt
setblock 294 184 269 minecraft:magma_block
fill 295 184 233 299 184 233 minecraft:basalt
fill 295 184 240 296 184 240 minecraft:basalt
fill 295 184 262 296 191 262 minecraft:basalt
fill 295 184 269 299 184 269 minecraft:basalt
setblock 297 184 232 minecraft:magma_block
fill 297 184 239 298 191 239 minecraft:basalt
fill 297 184 263 298 191 263 minecraft:basalt
fill 298 184 232 302 184 232 minecraft:basalt
fill 298 184 264 299 190 264 minecraft:basalt
setblock 300 184 264 minecraft:magma_block
fill 301 184 238 303 191 238 minecraft:basalt
fill 301 184 264 301 190 265 minecraft:basalt
fill 302 184 264 304 191 264 minecraft:basalt
fill 304 184 232 305 184 232 minecraft:basalt
setblock 306 184 232 minecraft:magma_block
fill 306 184 239 307 191 239 minecraft:basalt
fill 306 184 263 307 191 263 minecraft:basalt
setblock 307 184 232 minecraft:basalt
fill 307 184 267 313 184 267 minecraft:basalt
fill 308 184 240 308 192 240 minecraft:basalt
fill 308 184 262 310 191 262 minecraft:basalt
setblock 309 184 240 minecraft:magma_block
setblock 310 184 233 minecraft:basalt
fill 310 184 236 314 184 236 minecraft:basalt
fill 310 184 241 310 191 241 minecraft:basalt
fill 310 184 261 310 192 261 minecraft:basalt
fill 310 184 266 314 184 266 minecraft:basalt
setblock 310 184 269 minecraft:basalt
fill 311 184 242 311 192 242 minecraft:basalt
fill 311 184 260 311 194 260 minecraft:basalt
fill 312 184 243 313 191 243 minecraft:basalt
fill 312 184 259 312 195 259 minecraft:basalt
setblock 312 184 268 minecraft:basalt
setblock 313 184 235 minecraft:basalt
fill 313 184 238 316 184 239 minecraft:basalt
fill 313 184 244 313 191 245 minecraft:basalt
fill 313 184 257 313 191 258 minecraft:basalt
fill 313 184 265 314 185 265 minecraft:basalt
fill 314 184 246 314 191 247 minecraft:basalt
fill 314 184 255 314 184 256 minecraft:basalt
fill 315 184 237 316 184 237 minecraft:basalt
fill 315 184 241 319 184 241 minecraft:basalt
setblock 315 184 250 minecraft:magma_block
fill 315 184 251 315 191 252 minecraft:basalt
setblock 315 184 253 minecraft:magma_block
fill 315 184 254 315 191 255 minecraft:basalt
fill 315 184 264 316 184 264 minecraft:basalt
setblock 315 184 265 minecraft:magma_block
fill 316 184 240 317 185 240 minecraft:basalt
fill 316 184 251 316 190 251 minecraft:basalt
setblock 316 184 265 minecraft:basalt
setblock 317 184 239 minecraft:basalt
setblock 318 184 240 minecraft:magma_block
fill 318 184 261 319 184 261 minecraft:basalt
setblock 319 184 242 minecraft:basalt
fill 319 184 245 320 184 245 minecraft:basalt
fill 319 184 257 320 184 257 minecraft:basalt
setblock 319 184 260 minecraft:basalt
setblock 321 184 248 minecraft:magma_block
setblock 321 184 249 minecraft:basalt
setblock 321 184 251 minecraft:magma_block
setblock 321 184 252 minecraft:basalt
setblock 321 184 254 minecraft:magma_block
setblock 321 184 255 minecraft:basalt
setblock 324 184 237 minecraft:shroomlight
setblock 324 184 266 minecraft:magma_block
setblock 284 185 246 minecraft:basalt
setblock 284 185 247 minecraft:magma_block
fill 284 185 248 284 185 249 minecraft:basalt
setblock 284 185 250 minecraft:magma_block
fill 284 185 251 284 186 252 minecraft:basalt
setblock 284 185 253 minecraft:magma_block
fill 284 185 254 284 185 255 minecraft:basalt
setblock 284 185 256 minecraft:magma_block
fill 285 185 243 287 185 243 minecraft:basalt
fill 286 185 261 287 185 261 minecraft:basalt
setblock 287 185 240 minecraft:magma_block
fill 287 185 262 289 185 262 minecraft:basalt
fill 290 185 237 293 185 237 minecraft:basalt
setblock 290 185 248 minecraft:magma_block
fill 290 185 249 290 192 250 minecraft:basalt
setblock 290 185 251 minecraft:magma_block
fill 290 185 252 290 192 253 minecraft:basalt
setblock 290 185 254 minecraft:magma_block
fill 290 185 265 293 185 265 minecraft:basalt
fill 291 185 246 291 192 246 minecraft:basalt
fill 291 185 256 291 192 256 minecraft:basalt
fill 291 185 258 292 191 258 minecraft:basalt
setblock 292 185 235 minecraft:basalt
fill 292 185 244 292 191 244 minecraft:basalt
fill 292 185 267 293 185 267 minecraft:basalt
setblock 293 185 235 minecraft:magma_block
fill 293 185 243 293 192 243 minecraft:basalt
setblock 293 185 259 minecraft:magma_block
fill 294 185 234 295 185 234 minecraft:basalt
fill 294 185 242 294 192 242 minecraft:basalt
fill 294 185 260 294 192 260 minecraft:basalt
fill 295 185 240 295 191 241 minecraft:basalt
fill 295 185 261 295 191 261 minecraft:basalt
setblock 296 185 234 minecraft:magma_block
setblock 296 185 240 minecraft:magma_block
fill 297 185 233 298 185 233 minecraft:basalt
fill 297 185 240 297 192 240 minecraft:basalt
fill 297 185 262 297 192 262 minecraft:basalt
fill 297 185 269 298 185 269 minecraft:basalt
setblock 299 185 233 minecraft:magma_block
setblock 299 185 239 minecraft:magma_block
setblock 299 185 263 minecraft:magma_block
setblock 299 185 269 minecraft:magma_block
fill 300 185 239 305 185 239 minecraft:basalt
fill 300 185 263 300 191 264 minecraft:basalt
fill 301 185 233 307 185 233 minecraft:basalt
fill 301 185 263 305 185 263 minecraft:basalt
fill 301 185 269 307 185 269 minecraft:basalt
fill 304 185 268 310 185 268 minecraft:basalt
fill 305 185 235 310 186 235 minecraft:basalt
fill 307 185 234 310 185 234 minecraft:basalt
fill 307 185 240 307 192 240 minecraft:basalt
setblock 307 185 262 minecraft:basalt
fill 307 185 267 312 185 267 minecraft:basalt
fill 309 185 240 309 191 241 minecraft:basalt
fill 309 185 261 309 192 261 minecraft:basalt
fill 310 185 236 313 185 236 minecraft:basalt
fill 310 185 242 310 192 242 minecraft:basalt
fill 310 185 260 310 193 260 minecraft:basalt
fill 310 185 266 313 185 266 minecraft:basalt
setblock 311 185 235 minecraft:magma_block
fill 311 185 237 313 186 237 minecraft:basalt
fill 311 185 243 311 192 243 minecraft:basalt
setblock 311 185 259 minecraft:magma_block
fill 312 185 244 312 192 244 minecraft:basalt
fill 312 185 258 312 194 258 minecraft:basalt
fill 313 185 238 315 185 239 minecraft:basalt
fill 313 185 246 313 191 246 minecraft:basalt
fill 313 185 256 314 190 256 minecraft:basalt
fill 313 185 263 316 185 263 minecraft:basalt
setblock 314 185 237 minecraft:magma_block
fill 314 185 248 314 192 248 minecraft:basalt
setblock 314 185 249 minecraft:magma_block
fill 314 185 250 314 192 251 minecraft:basalt
setblock 314 185 252 minecraft:magma_block
fill 314 185 253 314 192 254 minecraft:basalt
setblock 314 185 255 minecraft:magma_block
fill 314 185 262 317 185 262 minecraft:basalt
fill 315 185 241 318 185 241 minecraft:basalt
fill 315 185 250 315 191 250 minecraft:basalt
fill 315 185 253 315 191 253 minecraft:basalt
setblock 315 185 264 minecraft:basalt
setblock 316 185 239 minecraft:basalt
fill 317 185 243 319 185 244 minecraft:basalt
fill 317 185 258 319 185 259 minecraft:basalt
fill 318 185 246 319 185 247 minecraft:basalt
fill 318 185 255 319 185 256 minecraft:basalt
setblock 318 185 261 minecraft:basalt
fill 319 185 245 319 186 245 minecraft:basalt
fill 319 185 248 319 185 254 minecraft:basalt
fill 319 185 257 319 186 257 minecraft:basalt
setblock 320 185 246 minecraft:basalt
setblock 320 185 247 minecraft:magma_block
fill 320 185 248 320 185 249 minecraft:basalt
setblock 320 185 250 minecraft:magma_block
fill 320 185 251 320 186 252 minecraft:basalt
setblock 320 185 253 minecraft:magma_block
fill 320 185 254 320 185 255 minecraft:basalt
setblock 320 185 256 minecraft:magma_block
setblock 324 185 237 minecraft:magma_block
setblock 324 185 266 minecraft:blackstone
setblock 324 185 267 minecraft:magma_block
setblock 282 186 252 minecraft:shroomlight
fill 283 186 229 283 186 269 minecraft:blackstone
fill 284 186 229 284 186 249 minecraft:blackstone
setblock 284 186 250 minecraft:basalt
fill 284 186 253 284 186 269 minecraft:blackstone
fill 285 186 229 285 186 244 minecraft:blackstone
fill 285 186 257 286 186 257 minecraft:basalt
fill 285 186 258 285 186 269 minecraft:blackstone
fill 286 186 229 286 186 242 minecraft:blackstone
fill 286 186 243 287 186 243 minecraft:basalt
setblock 286 186 258 minecraft:basalt
fill 286 186 260 286 186 269 minecraft:blackstone
fill 287 186 229 323 186 232 minecraft:blackstone
fill 287 186 241 287 186 242 minecraft:basalt
fill 287 186 260 287 186 261 minecraft:basalt
fill 287 186 266 291 186 269 minecraft:blackstone
fill 288 186 241 289 186 241 minecraft:basalt
fill 288 186 262 289 186 262 minecraft:basalt
fill 289 186 239 290 186 239 minecraft:basalt
fill 289 186 263 290 186 263 minecraft:basalt
fill 290 186 238 292 186 238 minecraft:basalt
fill 290 186 248 291 186 248 minecraft:basalt
fill 290 186 251 290 192 251 minecraft:basalt
fill 290 186 254 291 186 254 minecraft:basalt
fill 290 186 264 292 186 264 minecraft:basalt
setblock 291 186 237 minecraft:basalt
fill 291 186 247 291 193 247 minecraft:basalt
fill 291 186 255 291 192 255 minecraft:basalt
fill 291 186 265 293 186 265 minecraft:basalt
setblock 292 186 237 minecraft:magma_block
fill 292 186 245 292 193 245 minecraft:basalt
fill 292 186 257 292 193 257 minecraft:basalt
fill 292 186 267 293 186 269 minecraft:blackstone
fill 293 186 237 293 187 237 minecraft:basalt
fill 293 186 244 293 193 244 minecraft:basalt
setblock 293 186 247 minecraft:light[level=12]
fill 293 186 251 293 187 251 minecraft:magma_block
setblock 293 186 255 minecraft:light[level=12]
fill 293 186 258 293 192 259 minecraft:basalt
fill 294 186 243 294 193 243 minecraft:basalt
fill 294 186 259 294 193 259 minecraft:basalt
fill 294 186 268 295 186 269 minecraft:blackstone
setblock 295 186 242 minecraft:magma_block
setblock 295 186 260 minecraft:magma_block
setblock 296 186 234 minecraft:basalt
fill 296 186 240 296 192 241 minecraft:basalt
fill 296 186 261 296 193 261 minecraft:basalt
fill 296 186 268 297 186 268 minecraft:basalt
fill 296 186 269 300 186 269 minecraft:blackstone
fill 298 186 240 299 193 240 minecraft:basalt
setblock 298 186 262 minecraft:magma_block
fill 298 186 268 298 187 268 minecraft:magma_block
fill 299 186 239 303 192 239 minecraft:basalt
fill 299 186 262 299 192 263 minecraft:basalt
fill 299 186 268 302 186 268 minecraft:basalt
fill 301 186 233 303 186 233 minecraft:basalt
setblock 301 186 247 minecraft:light[level=12]
setblock 301 186 255 minecraft:light[level=12]
fill 301 186 263 303 192 263 minecraft:basalt
fill 301 186 269 303 186 269 minecraft:basalt
setblock 304 186 239 minecraft:magma_block
setblock 304 186 263 minecraft:magma_block
fill 304 186 268 306 186 268 minecraft:basalt
fill 304 186 269 323 186 269 minecraft:blackstone
fill 305 186 239 305 192 240 minecraft:basalt
fill 305 186 262 305 192 263 minecraft:basalt
fill 306 186 240 306 193 240 minecraft:basalt
fill 306 186 262 306 192 262 minecraft:basalt
fill 307 186 234 308 186 234 minecraft:basalt
setblock 307 186 262 minecraft:magma_block
fill 307 186 267 309 186 267 minecraft:basalt
fill 307 186 268 307 187 268 minecraft:magma_block
fill 308 186 241 308 193 241 minecraft:basalt
fill 308 186 261 308 193 261 minecraft:basalt
setblock 308 186 268 minecraft:basalt
fill 309 186 242 309 193 242 minecraft:basalt
setblock 309 186 247 minecraft:light[level=12]
setblock 309 186 255 minecraft:light[level=12]
fill 309 186 260 309 193 260 minecraft:basalt
fill 309 186 268 323 186 268 minecraft:blackstone
fill 310 186 236 312 186 236 minecraft:basalt
setblock 310 186 243 minecraft:magma_block
fill 310 186 259 311 194 259 minecraft:basalt
fill 310 186 266 312 186 266 minecraft:basalt
fill 310 186 267 310 187 267 minecraft:magma_block
fill 311 186 244 311 193 244 minecraft:basalt
fill 311 186 258 311 196 258 minecraft:basalt
fill 311 186 267 324 186 267 minecraft:blackstone
fill 312 186 245 312 192 245 minecraft:basalt
fill 312 186 257 312 192 257 minecraft:basalt
fill 313 186 238 314 186 239 minecraft:basalt
fill 313 186 247 313 193 247 minecraft:basalt
setblock 313 186 248 minecraft:magma_block
setblock 313 186 254 minecraft:magma_block
fill 313 186 255 314 192 255 minecraft:basalt
fill 313 186 263 315 186 263 minecraft:basalt
setblock 313 186 265 minecraft:basalt
fill 313 186 266 323 186 266 minecraft:blackstone
fill 314 186 249 314 192 249 minecraft:basalt
fill 314 186 252 314 192 252 minecraft:basalt
fill 314 186 262 315 187 262 minecraft:basalt
setblock 315 186 239 minecraft:basalt
fill 315 186 241 315 187 241 minecraft:basalt
setblock 316 186 240 minecraft:basalt
setblock 316 186 241 minecraft:magma_block
setblock 316 186 262 minecraft:magma_block
setblock 317 186 239 minecraft:light[level=12]
setblock 317 186 241 minecraft:basalt
fill 317 186 243 318 186 244 minecraft:basalt
fill 317 186 258 318 186 259 minecraft:basalt
setblock 317 186 263 minecraft:light[level=12]
fill 318 186 246 318 187 247 minecraft:basalt
fill 318 186 255 318 187 256 minecraft:basalt
setblock 319 186 246 minecraft:magma_block
fill 319 186 247 319 186 248 minecraft:basalt
setblock 319 186 249 minecraft:magma_block
fill 319 186 250 319 186 254 minecraft:basalt
setblock 319 186 255 minecraft:magma_block
setblock 319 186 256 minecraft:basalt
fill 320 186 233 323 186 249 minecraft:blackstone
setblock 320 186 250 minecraft:basalt
fill 320 186 253 323 186 265 minecraft:blackstone
fill 321 186 250 323 186 252 minecraft:blackstone
fill 324 186 232 324 188 235 minecraft:blackstone
fill 324 186 236 324 187 236 minecraft:magma_block
fill 324 186 237 324 191 237 minecraft:blackstone
setblock 324 186 266 minecraft:magma_block
fill 282 187 252 282 243 252 minecraft:blackstone
fill 283 187 229 284 187 269 minecraft:magma_block
fill 285 187 229 285 187 248 minecraft:magma_block
setblock 285 187 249 minecraft:basalt
setblock 285 187 250 minecraft:magma_block
fill 285 187 253 285 187 269 minecraft:magma_block
fill 286 187 229 323 187 231 minecraft:magma_block
fill 286 187 245 286 187 246 minecraft:basalt
fill 286 187 250 286 188 250 minecraft:basalt
fill 286 187 253 286 187 255 minecraft:basalt
setblock 286 187 257 minecraft:basalt
fill 286 187 267 295 187 269 minecraft:magma_block
fill 287 187 243 287 187 244 minecraft:basalt
setblock 287 187 259 minecraft:basalt
setblock 288 187 270 minecraft:magma_block
setblock 289 187 241 minecraft:basalt
setblock 289 187 262 minecraft:basalt
setblock 290 187 239 minecraft:basalt
fill 290 187 248 290 192 248 minecraft:basalt
fill 290 187 254 290 192 254 minecraft:basalt
setblock 290 187 263 minecraft:basalt
fill 291 187 238 292 187 238 minecraft:basalt
setblock 291 187 248 minecraft:magma_block
fill 291 187 249 291 192 250 minecraft:basalt
setblock 291 187 251 minecraft:magma_block
fill 291 187 252 291 192 253 minecraft:basalt
setblock 291 187 254 minecraft:magma_block
fill 291 187 264 292 187 264 minecraft:basalt
fill 292 187 246 292 193 247 minecraft:basalt
fill 292 187 255 292 193 256 minecraft:basalt
fill 293 187 245 293 193 245 minecraft:basalt
fill 293 187 257 293 193 257 minecraft:basalt
setblock 293 187 265 minecraft:basalt
fill 294 187 236 295 187 236 minecraft:basalt
setblock 294 187 244 minecraft:magma_block
fill 294 187 258 294 193 258 minecraft:basalt
fill 294 187 266 295 187 266 minecraft:basalt
fill 295 187 242 295 193 243 minecraft:basalt
fill 295 187 259 295 193 260 minecraft:basalt
fill 296 187 235 298 187 235 minecraft:basalt
fill 296 187 242 296 193 242 minecraft:basalt
fill 296 187 260 296 193 260 minecraft:basalt
setblock 296 187 267 minecraft:basalt
fill 296 187 268 297 187 269 minecraft:magma_block
fill 297 187 241 298 192 241 minecraft:basalt
setblock 297 187 261 minecraft:magma_block
fill 297 187 266 297 188 266 minecraft:basalt
setblock 297 187 267 minecraft:magma_block
fill 298 187 261 298 193 262 minecraft:basalt
fill 298 187 269 323 187 269 minecraft:magma_block
setblock 299 187 268 minecraft:magma_block
fill 300 187 234 304 187 234 minecraft:basalt
fill 300 187 240 304 192 240 minecraft:basalt
fill 300 187 262 302 193 262 minecraft:basalt
fill 300 187 268 302 187 268 minecraft:basalt
setblock 303 187 262 minecraft:magma_block
fill 303 187 267 303 188 267 minecraft:basalt
setblock 303 187 268 minecraft:magma_block
fill 304 187 239 304 192 239 minecraft:basalt
fill 304 187 262 304 192 263 minecraft:basalt
setblock 304 187 268 minecraft:basalt
fill 305 187 235 308 187 235 minecraft:basalt
fill 305 187 268 306 187 268 minecraft:magma_block
fill 306 187 241 307 192 241 minecraft:basalt
setblock 306 187 261 minecraft:magma_block
setblock 306 187 267 minecraft:magma_block
fill 307 187 236 308 188 236 minecraft:basalt
fill 307 187 261 307 192 262 minecraft:basalt
fill 307 187 266 308 187 267 minecraft:basalt
fill 308 187 242 308 193 242 minecraft:basalt
fill 308 187 260 308 193 260 minecraft:basalt
fill 308 187 268 323 187 268 minecraft:magma_block
setblock 309 187 236 minecraft:magma_block
fill 309 187 243 310 192 243 minecraft:basalt
fill 309 187 259 309 195 259 minecraft:basalt
fill 309 187 266 309 187 267 minecraft:magma_block
setblock 310 187 236 minecraft:basalt
fill 310 187 244 310 193 244 minecraft:basalt
fill 310 187 258 310 195 258 minecraft:basalt
setblock 310 187 266 minecraft:basalt
fill 311 187 237 311 187 238 minecraft:basalt
fill 311 187 245 311 193 245 minecraft:basalt
fill 311 187 257 311 195 257 minecraft:basalt
fill 311 187 267 323 187 267 minecraft:magma_block
setblock 312 187 238 minecraft:magma_block
fill 312 187 246 312 193 246 minecraft:basalt
setblock 312 187 247 minecraft:magma_block
fill 312 187 255 312 193 255 minecraft:basalt
setblock 312 187 256 minecraft:magma_block
fill 312 187 264 313 187 264 minecraft:basalt
fill 313 187 238 313 187 239 minecraft:basalt
fill 313 187 248 313 193 254 minecraft:basalt
fill 313 187 263 314 187 263 minecraft:basalt
setblock 314 187 239 minecraft:basalt
fill 314 187 261 314 188 261 minecraft:basalt
fill 314 187 264 314 189 265 minecraft:blackstone
setblock 315 187 240 minecraft:magma_block
setblock 315 187 261 minecraft:magma_block
fill 315 187 264 315 189 264 minecraft:blackstone
setblock 316 187 242 minecraft:basalt
setblock 316 187 260 minecraft:basalt
fill 317 187 243 317 187 244 minecraft:basalt
fill 317 187 257 317 187 259 minecraft:basalt
setblock 318 187 245 minecraft:magma_block
setblock 318 187 248 minecraft:magma_block
fill 318 187 249 319 187 253 minecraft:basalt
setblock 318 187 254 minecraft:magma_block
setblock 318 187 257 minecraft:magma_block
fill 321 187 232 323 187 266 minecraft:magma_block
fill 324 187 266 324 283 266 minecraft:blackstone
setblock 324 187 267 minecraft:shroomlight
fill 283 188 229 284 188 269 minecraft:shroomlight
fill 285 188 229 323 188 230 minecraft:shroomlight
fill 285 188 268 323 188 269 minecraft:shroomlight
setblock 286 188 248 minecraft:basalt
fill 286 188 253 286 188 254 minecraft:basalt
setblock 287 188 228 minecraft:shroomlight
setblock 287 188 245 minecraft:magma_block
setblock 287 188 257 minecraft:magma_block
fill 288 188 245 288 189 245 minecraft:basalt
fill 288 188 257 288 189 257 minecraft:basalt
fill 288 188 270 288 201 270 minecraft:blackstone
setblock 290 188 240 minecraft:basalt
setblock 290 188 241 minecraft:magma_block
fill 290 188 242 290 189 242 minecraft:basalt
setblock 290 188 262 minecraft:magma_block
fill 291 188 248 292 193 248 minecraft:basalt
fill 291 188 251 292 188 251 minecraft:basalt
fill 291 188 254 292 193 254 minecraft:basalt
setblock 291 188 262 minecraft:basalt
fill 292 188 249 292 193 250 minecraft:basalt
fill 292 188 252 292 193 253 minecraft:basalt
setblock 293 188 246 minecraft:magma_block
fill 293 188 256 293 193 256 minecraft:basalt
fill 293 188 263 293 189 263 minecraft:basalt
setblock 293 188 264 minecraft:magma_block
fill 294 188 244 294 192 245 minecraft:basalt
fill 294 188 257 294 192 257 minecraft:basalt
setblock 296 188 236 minecraft:magma_block
fill 296 188 237 296 189 237 minecraft:basalt
fill 296 188 243 296 193 243 minecraft:basalt
fill 296 188 259 296 193 259 minecraft:basalt
fill 296 188 265 296 189 265 minecraft:basalt
setblock 296 188 266 minecraft:magma_block
fill 297 188 242 297 193 242 minecraft:basalt
fill 297 188 260 297 193 261 minecraft:basalt
setblock 299 188 235 minecraft:magma_block
setblock 299 188 241 minecraft:magma_block
fill 299 188 261 301 192 261 minecraft:basalt
setblock 299 188 267 minecraft:basalt
fill 300 188 241 305 188 241 minecraft:basalt
setblock 302 188 261 minecraft:magma_block
fill 302 188 266 302 189 266 minecraft:basalt
setblock 302 188 267 minecraft:magma_block
fill 303 188 261 303 193 262 minecraft:basalt
fill 304 188 261 306 193 261 minecraft:basalt
setblock 305 188 235 minecraft:basalt
fill 307 188 242 307 193 242 minecraft:basalt
fill 307 188 260 307 193 260 minecraft:basalt
fill 307 188 266 308 188 266 minecraft:basalt
fill 308 188 243 308 193 243 minecraft:basalt
setblock 308 188 259 minecraft:magma_block
setblock 310 188 245 minecraft:basalt
setblock 310 188 257 minecraft:basalt
fill 310 188 264 310 189 264 minecraft:basalt
setblock 311 188 238 minecraft:basalt
setblock 311 188 246 minecraft:magma_block
fill 311 188 256 312 193 256 minecraft:basalt
setblock 311 188 264 minecraft:magma_block
fill 312 188 247 312 192 254 minecraft:basalt
setblock 313 188 239 minecraft:basalt
setblock 313 188 263 minecraft:basalt
fill 313 188 264 313 189 264 minecraft:blackstone
setblock 314 188 262 minecraft:basalt
fill 314 188 263 314 189 263 minecraft:blackstone
setblock 317 188 247 minecraft:magma_block
fill 317 188 248 317 188 255 minecraft:basalt
setblock 317 188 256 minecraft:magma_block
setblock 317 188 257 minecraft:basalt
fill 318 188 248 318 188 254 minecraft:basalt
fill 322 188 231 323 188 267 minecraft:shroomlight
setblock 324 188 236 minecraft:shroomlight
setblock 324 188 257 minecraft:magma_block
setblock 324 188 267 minecraft:magma_block
setblock 285 189 231 minecraft:light[level=12]
setblock 285 189 238 minecraft:light[level=12]
setblock 285 189 245 minecraft:light[level=12]
setblock 285 189 252 minecraft:light[level=12]
setblock 285 189 259 minecraft:light[level=12]
setblock 285 189 266 minecraft:light[level=12]
fill 287 189 228 287 283 228 minecraft:blackstone
fill 287 189 248 287 189 254 minecraft:basalt
fill 289 189 241 290 189 241 minecraft:basalt
setblock 289 189 243 minecraft:magma_block
fill 289 189 244 289 189 245 minecraft:basalt
fill 289 189 257 289 190 257 minecraft:basalt
setblock 289 189 258 minecraft:magma_block
fill 291 189 251 291 195 251 minecraft:basalt
setblock 292 189 231 minecraft:light[level=12]
setblock 292 189 238 minecraft:light[level=12]
setblock 292 189 240 minecraft:basalt
setblock 292 189 251 minecraft:magma_block
setblock 292 189 262 minecraft:basalt
setblock 292 189 266 minecraft:light[level=12]
fill 293 189 246 293 193 248 minecraft:basalt
fill 293 189 254 293 193 255 minecraft:basalt
setblock 294 189 246 minecraft:basalt
fill 294 189 256 294 193 256 minecraft:basalt
fill 294 189 264 295 189 264 minecraft:basalt
setblock 295 189 238 minecraft:magma_block
fill 295 189 239 295 190 239 minecraft:basalt
setblock 295 189 244 minecraft:magma_block
fill 295 189 258 295 193 258 minecraft:basalt
fill 297 189 243 297 193 243 minecraft:basalt
fill 297 189 259 297 192 259 minecraft:basalt
setblock 298 189 237 minecraft:magma_block
fill 298 189 242 299 193 242 minecraft:basalt
fill 298 189 260 299 193 260 minecraft:basalt
setblock 299 189 231 minecraft:light[level=12]
fill 299 189 236 300 189 236 minecraft:basalt
fill 299 189 241 303 193 241 minecraft:basalt
setblock 299 189 245 minecraft:light[level=12]
setblock 299 189 252 minecraft:light[level=12]
setblock 299 189 259 minecraft:light[level=12]
fill 299 189 266 300 189 266 minecraft:basalt
setblock 301 189 236 minecraft:magma_block
setblock 301 189 266 minecraft:magma_block
fill 302 189 236 305 189 236 minecraft:basalt
fill 302 189 261 302 193 261 minecraft:basalt
fill 303 189 266 305 189 266 minecraft:basalt
setblock 304 189 241 minecraft:magma_block
fill 305 189 237 306 190 237 minecraft:basalt
fill 305 189 241 305 193 242 minecraft:basalt
fill 305 189 260 306 193 260 minecraft:basalt
setblock 306 189 231 minecraft:light[level=12]
fill 306 189 242 306 193 242 minecraft:basalt
setblock 306 189 245 minecraft:light[level=12]
setblock 306 189 252 minecraft:light[level=12]
setblock 306 189 259 minecraft:light[level=12]
setblock 306 189 266 minecraft:light[level=12]
setblock 307 189 237 minecraft:magma_block
setblock 307 189 243 minecraft:magma_block
fill 307 189 259 308 193 259 minecraft:basalt
fill 309 189 244 309 193 244 minecraft:basalt
fill 309 189 258 309 192 258 minecraft:basalt
setblock 310 189 245 minecraft:magma_block
fill 310 189 246 311 193 246 minecraft:basalt
fill 310 189 256 310 193 256 minecraft:basalt
setblock 310 189 257 minecraft:magma_block
fill 311 189 247 311 193 248 minecraft:basalt
fill 311 189 254 311 193 255 minecraft:basalt
setblock 312 189 262 minecraft:basalt
setblock 313 189 231 minecraft:light[level=12]
setblock 313 189 238 minecraft:light[level=12]
setblock 313 189 241 minecraft:magma_block
setblock 313 189 266 minecraft:light[level=12]
fill 315 189 258 315 189 259 minecraft:basalt
setblock 316 189 246 minecraft:magma_block
fill 316 189 247 316 190 248 minecraft:basalt
fill 316 189 254 317 189 254 minecraft:basalt
setblock 316 189 255 minecraft:magma_block
setblock 316 189 256 minecraft:basalt
fill 317 189 248 317 189 253 minecraft:basalt
setblock 320 189 231 minecraft:light[level=12]
setblock 320 189 238 minecraft:light[level=12]
setblock 320 189 245 minecraft:light[level=12]
setblock 320 189 252 minecraft:light[level=12]
setblock 320 189 259 minecraft:light[level=12]
setblock 320 189 266 minecraft:light[level=12]
fill 324 189 232 324 254 234 minecraft:blackstone
fill 324 189 235 324 190 235 minecraft:magma_block
fill 324 189 236 324 190 236 minecraft:blackstone
fill 324 189 257 324 283 257 minecraft:blackstone
fill 324 189 267 324 196 267 minecraft:blackstone
setblock 324 189 268 minecraft:magma_block
setblock 324 189 269 minecraft:blackstone
setblock 282 190 251 minecraft:crying_obsidian
fill 287 190 241 288 190 242 minecraft:basalt
setblock 288 190 247 minecraft:basalt
setblock 288 190 248 minecraft:magma_block
fill 288 190 249 288 190 250 minecraft:basalt
setblock 288 190 251 minecraft:magma_block
fill 288 190 252 288 190 253 minecraft:basalt
setblock 288 190 254 minecraft:magma_block
setblock 288 190 255 minecraft:basalt
fill 289 190 228 290 197 228 minecraft:blackstone
fill 289 190 240 290 190 240 minecraft:basalt
fill 289 190 241 290 190 242 minecraft:magma_block
setblock 289 190 243 minecraft:basalt
setblock 289 190 245 minecraft:basalt
setblock 291 190 228 minecraft:shroomlight
fill 292 190 228 297 249 228 minecraft:blackstone
fill 292 190 251 293 190 251 minecraft:basalt
setblock 292 190 270 minecraft:crying_obsidian
fill 293 190 249 293 193 250 minecraft:basalt
fill 293 190 252 293 193 253 minecraft:basalt
fill 293 190 270 294 239 270 minecraft:blackstone
setblock 294 190 246 minecraft:magma_block
fill 294 190 247 294 193 247 minecraft:basalt
setblock 294 190 255 minecraft:magma_block
fill 295 190 244 295 193 245 minecraft:basalt
fill 295 190 257 295 193 257 minecraft:basalt
setblock 295 190 270 minecraft:magma_block
fill 296 190 244 296 193 244 minecraft:basalt
fill 296 190 258 296 193 258 minecraft:basalt
setblock 297 190 238 minecraft:basalt
setblock 298 190 237 minecraft:basalt
fill 298 190 243 298 193 243 minecraft:basalt
fill 298 190 259 298 193 259 minecraft:basalt
fill 298 190 265 299 190 265 minecraft:basalt
fill 300 190 237 302 190 237 minecraft:basalt
fill 300 190 242 304 190 242 minecraft:basalt
fill 300 190 260 304 190 260 minecraft:basalt
setblock 300 190 265 minecraft:magma_block
setblock 303 190 237 minecraft:magma_block
setblock 304 190 237 minecraft:basalt
fill 304 190 241 304 193 241 minecraft:basalt
fill 306 190 243 307 193 243 minecraft:basalt
fill 306 190 259 306 192 259 minecraft:basalt
setblock 306 190 265 minecraft:basalt
fill 308 190 244 308 193 244 minecraft:basalt
fill 308 190 258 308 193 258 minecraft:basalt
setblock 309 190 239 minecraft:basalt
fill 309 190 245 310 193 245 minecraft:basalt
fill 309 190 257 310 193 257 minecraft:basalt
setblock 309 190 263 minecraft:basalt
fill 310 190 247 310 193 247 minecraft:basalt
fill 310 190 255 310 193 255 minecraft:basalt
setblock 311 190 240 minecraft:basalt
fill 311 190 249 311 190 253 minecraft:basalt
setblock 312 190 261 minecraft:magma_block
setblock 315 190 245 minecraft:magma_block
setblock 315 190 246 minecraft:basalt
setblock 315 190 256 minecraft:basalt
setblock 315 190 257 minecraft:magma_block
fill 316 190 254 316 190 255 minecraft:basalt
fill 324 190 268 324 195 268 minecraft:blackstone
setblock 324 190 269 minecraft:magma_block
fill 282 191 251 282 228 251 minecraft:blackstone
fill 285 191 241 286 191 242 minecraft:basalt
fill 287 191 240 288 191 240 minecraft:basalt
fill 287 191 241 288 191 242 minecraft:magma_block
fill 287 191 243 288 191 243 minecraft:basalt
fill 289 191 241 290 191 242 minecraft:basalt
setblock 290 191 246 minecraft:magma_block
fill 290 191 247 290 192 247 minecraft:basalt
setblock 290 191 257 minecraft:basalt
fill 291 191 228 291 283 228 minecraft:blackstone
setblock 291 191 243 minecraft:basalt
fill 292 191 251 292 195 251 minecraft:basalt
fill 292 191 270 292 206 270 minecraft:blackstone
setblock 293 191 251 minecraft:magma_block
fill 294 191 246 295 193 246 minecraft:basalt
fill 294 191 248 294 192 249 minecraft:basalt
fill 294 191 253 294 192 255 minecraft:basalt
fill 295 191 256 295 193 256 minecraft:basalt
fill 295 191 270 295 264 270 minecraft:blackstone
setblock 296 191 239 minecraft:basalt
fill 296 191 245 296 193 245 minecraft:basalt
fill 296 191 257 296 193 257 minecraft:basalt
fill 297 191 244 297 192 244 minecraft:basalt
fill 297 191 258 297 193 258 minecraft:basalt
setblock 298 191 264 minecraft:basalt
setblock 299 191 243 minecraft:magma_block
fill 299 191 259 300 193 259 minecraft:basalt
setblock 299 191 264 minecraft:magma_block
fill 300 191 242 300 192 243 minecraft:basalt
fill 300 191 260 301 193 260 minecraft:basalt
fill 301 191 242 301 193 242 minecraft:basalt
setblock 301 191 264 minecraft:basalt
setblock 302 191 242 minecraft:magma_block
setblock 302 191 260 minecraft:magma_block
fill 303 191 242 304 192 242 minecraft:basalt
fill 303 191 260 304 192 260 minecraft:basalt
setblock 304 191 238 minecraft:basalt
fill 304 191 243 305 191 243 minecraft:basalt
fill 304 191 259 304 193 259 minecraft:basalt
setblock 305 191 238 minecraft:magma_block
setblock 305 191 259 minecraft:magma_block
setblock 306 191 238 minecraft:basalt
fill 307 191 244 307 193 244 minecraft:basalt
fill 307 191 258 307 193 258 minecraft:basalt
fill 308 191 245 308 193 245 minecraft:basalt
fill 308 191 257 308 193 257 minecraft:basalt
setblock 308 191 263 minecraft:basalt
fill 309 191 246 309 192 246 minecraft:basalt
fill 309 191 256 309 193 256 minecraft:basalt
fill 310 191 248 310 193 249 minecraft:basalt
fill 310 191 253 310 191 254 minecraft:basalt
fill 311 191 249 311 193 250 minecraft:basalt
setblock 311 191 251 minecraft:magma_block
fill 311 191 252 311 193 253 minecraft:basalt
fill 313 191 256 313 192 256 minecraft:basalt
setblock 313 191 259 minecraft:basalt
setblock 314 191 245 minecraft:basalt
setblock 314 191 256 minecraft:magma_block
fill 324 191 235 324 283 235 minecraft:blackstone
setblock 324 191 236 minecraft:magma_block
setblock 324 191 269 minecraft:shroomlight
fill 283 192 241 284 192 242 minecraft:basalt
fill 285 192 240 286 192 240 minecraft:basalt
fill 285 192 241 286 192 242 minecraft:magma_block
fill 285 192 243 286 192 243 minecraft:basalt
fill 287 192 241 288 192 242 minecraft:basalt
setblock 290 192 255 minecraft:basalt
setblock 291 192 245 minecraft:basalt
setblock 292 192 244 minecraft:magma_block
setblock 292 192 258 minecraft:basalt
setblock 292 192 259 minecraft:magma_block
fill 293 192 251 294 192 251 minecraft:basalt
fill 294 192 250 294 193 250 minecraft:basalt
fill 294 192 252 294 193 252 minecraft:basalt
setblock 295 192 241 minecraft:basalt
fill 295 192 247 295 192 248 minecraft:basalt
setblock 295 192 254 minecraft:basalt
setblock 295 192 255 minecraft:magma_block
setblock 295 192 261 minecraft:magma_block
fill 296 192 246 296 193 246 minecraft:basalt
fill 296 192 256 296 193 256 minecraft:basalt
setblock 296 192 262 minecraft:basalt
fill 297 192 245 297 193 245 minecraft:basalt
fill 297 192 257 297 193 257 minecraft:basalt
setblock 298 192 239 minecraft:magma_block
fill 298 192 244 299 192 244 minecraft:basalt
fill 298 192 258 299 192 258 minecraft:basalt
setblock 298 192 263 minecraft:magma_block
setblock 299 192 228 minecraft:magma_block
fill 299 192 243 299 193 243 minecraft:basalt
setblock 300 192 263 minecraft:basalt
fill 301 192 243 303 193 243 minecraft:basalt
setblock 301 192 259 minecraft:magma_block
fill 302 192 242 302 193 242 minecraft:basalt
fill 302 192 259 302 193 260 minecraft:basalt
fill 303 192 259 303 193 259 minecraft:basalt
setblock 304 192 243 minecraft:magma_block
fill 305 192 243 305 192 244 minecraft:basalt
fill 305 192 258 305 192 259 minecraft:basalt
setblock 306 192 239 minecraft:basalt
setblock 306 192 244 minecraft:basalt
fill 306 192 258 306 193 258 minecraft:basalt
setblock 306 192 263 minecraft:basalt
setblock 307 192 245 minecraft:magma_block
setblock 307 192 257 minecraft:magma_block
fill 308 192 246 308 193 246 minecraft:basalt
fill 308 192 256 308 193 256 minecraft:basalt
setblock 308 192 262 minecraft:basalt
setblock 309 192 241 minecraft:basalt
fill 309 192 247 309 192 248 minecraft:basalt
fill 309 192 254 309 192 255 minecraft:basalt
setblock 310 192 241 minecraft:magma_block
setblock 310 192 250 minecraft:magma_block
fill 310 192 251 310 193 252 minecraft:basalt
setblock 310 192 253 minecraft:magma_block
fill 310 192 254 310 193 254 minecraft:basalt
fill 311 192 251 311 193 251 minecraft:basalt
setblock 312 192 243 minecraft:basalt
setblock 313 192 245 minecraft:basalt
setblock 313 192 246 minecraft:magma_block
setblock 313 192 257 minecraft:basalt
setblock 314 192 247 minecraft:basalt
fill 324 192 236 324 230 236 minecraft:blackstone
setblock 324 192 237 minecraft:shroomlight
fill 324 192 240 324 228 240 minecraft:blackstone
setblock 324 192 241 minecraft:crying_obsidian
fill 324 192 269 324 194 269 minecraft:magma_block
fill 282 193 239 282 283 240 minecraft:blackstone
fill 282 193 241 282 194 242 minecraft:basalt
fill 283 193 240 284 193 240 minecraft:basalt
fill 283 193 241 284 193 242 minecraft:magma_block
fill 283 193 243 284 193 243 minecraft:basalt
setblock 285 193 231 minecraft:light[level=12]
setblock 285 193 239 minecraft:light[level=12]
fill 285 193 241 286 193 242 minecraft:basalt
setblock 285 193 247 minecraft:light[level=12]
setblock 285 193 255 minecraft:light[level=12]
setblock 285 193 263 minecraft:light[level=12]
setblock 291 193 249 minecraft:magma_block
fill 291 193 250 291 195 250 minecraft:basalt
setblock 291 193 252 minecraft:magma_block
setblock 291 193 253 minecraft:basalt
setblock 291 193 255 minecraft:magma_block
setblock 293 193 231 minecraft:light[level=12]
setblock 293 193 239 minecraft:light[level=12]
fill 293 193 251 293 195 251 minecraft:basalt
setblock 293 193 258 minecraft:basalt
setblock 293 193 263 minecraft:light[level=12]
setblock 294 193 244 minecraft:basalt
setblock 294 193 245 minecraft:magma_block
fill 294 193 248 296 193 248 minecraft:magma_block
setblock 294 193 249 minecraft:basalt
fill 294 193 251 295 193 251 minecraft:magma_block
setblock 294 193 253 minecraft:basalt
fill 294 193 254 296 193 254 minecraft:magma_block
fill 294 193 255 295 193 255 minecraft:basalt
setblock 294 193 257 minecraft:magma_block
setblock 295 193 247 minecraft:basalt
fill 295 193 249 295 193 250 minecraft:magma_block
fill 295 193 252 295 193 253 minecraft:magma_block
setblock 296 193 241 minecraft:basalt
setblock 296 193 247 minecraft:magma_block
setblock 296 193 255 minecraft:magma_block
setblock 297 193 241 minecraft:magma_block
setblock 297 193 244 minecraft:magma_block
setblock 297 193 246 minecraft:magma_block
setblock 297 193 256 minecraft:magma_block
setblock 297 193 259 minecraft:magma_block
setblock 298 193 241 minecraft:basalt
setblock 298 193 244 minecraft:basalt
fill 298 193 245 299 193 245 minecraft:magma_block
fill 298 193 257 299 193 257 minecraft:magma_block
setblock 298 193 258 minecraft:basalt
fill 299 193 228 299 240 228 minecraft:blackstone
fill 299 193 244 306 193 244 minecraft:magma_block
fill 299 193 258 305 193 258 minecraft:magma_block
fill 299 193 261 299 193 262 minecraft:basalt
setblock 300 193 240 minecraft:magma_block
setblock 300 193 242 minecraft:basalt
setblock 300 193 243 minecraft:magma_block
setblock 300 193 261 minecraft:magma_block
setblock 301 193 231 minecraft:light[level=12]
setblock 301 193 239 minecraft:light[level=12]
fill 301 193 240 305 193 240 minecraft:basalt
setblock 301 193 247 minecraft:light[level=12]
setblock 301 193 255 minecraft:light[level=12]
setblock 301 193 259 minecraft:basalt
setblock 301 193 261 minecraft:basalt
setblock 301 193 263 minecraft:light[level=12]
setblock 303 193 242 minecraft:magma_block
setblock 303 193 260 minecraft:magma_block
fill 304 193 242 304 193 243 minecraft:basalt
setblock 304 193 260 minecraft:basalt
fill 304 193 262 305 193 262 minecraft:basalt
setblock 305 193 243 minecraft:basalt
fill 305 193 245 306 193 245 minecraft:magma_block
fill 305 193 257 306 193 257 minecraft:magma_block
setblock 305 193 259 minecraft:basalt
setblock 306 193 241 minecraft:magma_block
setblock 306 193 259 minecraft:magma_block
setblock 306 193 262 minecraft:magma_block
setblock 307 193 241 minecraft:basalt
setblock 307 193 245 minecraft:basalt
setblock 307 193 246 minecraft:magma_block
setblock 307 193 256 minecraft:magma_block
setblock 307 193 257 minecraft:basalt
setblock 307 193 261 minecraft:basalt
fill 308 193 247 308 193 248 minecraft:magma_block
fill 308 193 254 309 193 255 minecraft:magma_block
setblock 309 193 231 minecraft:light[level=12]
setblock 309 193 239 minecraft:light[level=12]
setblock 309 193 243 minecraft:magma_block
setblock 309 193 246 minecraft:magma_block
setblock 309 193 247 minecraft:basalt
fill 309 193 248 309 193 253 minecraft:magma_block
setblock 309 193 258 minecraft:magma_block
setblock 309 193 263 minecraft:light[level=12]
setblock 310 193 243 minecraft:basalt
setblock 310 193 250 minecraft:basalt
setblock 310 193 253 minecraft:basalt
setblock 312 193 245 minecraft:magma_block
setblock 312 193 247 minecraft:basalt
setblock 312 193 248 minecraft:magma_block
fill 312 193 249 312 193 250 minecraft:basalt
setblock 312 193 251 minecraft:magma_block
fill 312 193 252 312 193 253 minecraft:basalt
setblock 312 193 254 minecraft:magma_block
setblock 312 193 257 minecraft:magma_block
setblock 313 193 255 minecraft:basalt
fill 314 193 270 318 202 270 minecraft:blackstone
setblock 317 193 231 minecraft:light[level=12]
setblock 317 193 239 minecraft:light[level=12]
setblock 317 193 247 minecraft:light[level=12]
setblock 317 193 255 minecraft:light[level=12]
setblock 317 193 263 minecraft:light[level=12]
setblock 319 193 270 minecraft:magma_block
setblock 320 193 228 minecraft:magma_block
fill 320 193 270 324 283 270 minecraft:blackstone
fill 324 193 237 324 201 237 minecraft:blackstone
fill 324 193 241 324 207 241 minecraft:blackstone
fill 283 194 241 284 194 242 minecraft:basalt
fill 292 194 250 292 195 250 minecraft:basalt
setblock 308 194 259 minecraft:basalt
fill 309 194 258 309 195 258 minecraft:basalt
setblock 310 194 256 minecraft:magma_block
fill 310 194 257 310 195 257 minecraft:basalt
setblock 311 194 256 minecraft:basalt
setblock 312 194 228 minecraft:crying_obsidian
fill 313 194 228 314 233 228 minecraft:blackstone
fill 319 194 270 319 282 270 minecraft:blackstone
fill 320 194 228 320 283 228 minecraft:blackstone
setblock 324 194 231 minecraft:shroomlight
fill 282 195 241 282 283 242 minecraft:blackstone
setblock 285 195 231 minecraft:light[level=12]
setblock 285 195 238 minecraft:light[level=12]
setblock 285 195 245 minecraft:light[level=12]
setblock 285 195 252 minecraft:light[level=12]
setblock 285 195 259 minecraft:light[level=12]
setblock 285 195 266 minecraft:light[level=12]
setblock 292 195 231 minecraft:light[level=12]
setblock 292 195 238 minecraft:light[level=12]
setblock 292 195 245 minecraft:light[level=12]
setblock 292 195 252 minecraft:light[level=12]
setblock 292 195 259 minecraft:light[level=12]
setblock 292 195 266 minecraft:light[level=12]
setblock 299 195 231 minecraft:light[level=12]
setblock 299 195 238 minecraft:light[level=12]
setblock 299 195 245 minecraft:light[level=12]
setblock 299 195 252 minecraft:light[level=12]
setblock 299 195 259 minecraft:light[level=12]
setblock 299 195 266 minecraft:light[level=12]
setblock 303 195 228 minecraft:shroomlight
fill 305 195 228 306 283 228 minecraft:blackstone
setblock 306 195 231 minecraft:light[level=12]
setblock 306 195 238 minecraft:light[level=12]
setblock 306 195 245 minecraft:light[level=12]
setblock 306 195 252 minecraft:light[level=12]
setblock 306 195 259 minecraft:light[level=12]
setblock 306 195 266 minecraft:light[level=12]
setblock 307 195 228 minecraft:magma_block
setblock 310 195 259 minecraft:basalt
setblock 311 195 259 minecraft:magma_block
fill 312 195 228 312 283 228 minecraft:blackstone
setblock 312 195 258 minecraft:magma_block
setblock 313 195 231 minecraft:light[level=12]
setblock 313 195 238 minecraft:light[level=12]
setblock 313 195 245 minecraft:light[level=12]
setblock 313 195 252 minecraft:light[level=12]
setblock 313 195 259 minecraft:light[level=12]
setblock 313 195 266 minecraft:light[level=12]
setblock 320 195 231 minecraft:light[level=12]
setblock 320 195 238 minecraft:light[level=12]
setblock 320 195 245 minecraft:light[level=12]
setblock 320 195 252 minecraft:light[level=12]
setblock 320 195 259 minecraft:light[level=12]
setblock 320 195 266 minecraft:light[level=12]
fill 324 195 231 324 196 231 minecraft:blackstone
setblock 324 195 269 minecraft:shroomlight
fill 300 196 270 303 213 270 minecraft:blackstone
fill 303 196 228 303 229 228 minecraft:blackstone
setblock 304 196 270 minecraft:shroomlight
fill 305 196 270 307 197 270 minecraft:blackstone
fill 307 196 228 307 283 228 minecraft:blackstone
setblock 324 196 268 minecraft:magma_block
fill 324 196 269 324 283 269 minecraft:blackstone
fill 304 197 270 304 236 270 minecraft:blackstone
setblock 324 197 231 minecraft:crying_obsidian
fill 324 197 267 324 198 267 minecraft:magma_block
fill 324 197 268 324 283 268 minecraft:blackstone
setblock 289 198 228 minecraft:crying_obsidian
fill 290 198 228 290 204 228 minecraft:blackstone
setblock 305 198 270 minecraft:magma_block
fill 306 198 270 307 240 270 minecraft:blackstone
fill 324 198 231 324 239 231 minecraft:blackstone
fill 289 199 228 289 283 228 minecraft:blackstone
setblock 302 199 228 minecraft:magma_block
fill 305 199 270 305 258 270 minecraft:blackstone
setblock 324 199 267 minecraft:shroomlight
fill 282 200 229 282 211 229 minecraft:blackstone
setblock 282 200 230 minecraft:magma_block
fill 285 200 231 285 201 231 minecraft:light[level=12]
setblock 285 200 239 minecraft:light[level=12]
setblock 285 200 247 minecraft:light[level=12]
setblock 285 200 255 minecraft:light[level=12]
setblock 285 200 263 minecraft:light[level=12]
setblock 293 200 231 minecraft:light[level=12]
setblock 293 200 239 minecraft:light[level=12]
setblock 293 200 247 minecraft:light[level=12]
setblock 293 200 255 minecraft:light[level=12]
setblock 293 200 263 minecraft:light[level=12]
setblock 301 200 231 minecraft:light[level=12]
setblock 301 200 239 minecraft:light[level=12]
setblock 301 200 247 minecraft:light[level=12]
setblock 301 200 255 minecraft:light[level=12]
setblock 301 200 263 minecraft:light[level=12]
fill 302 200 228 302 283 228 minecraft:blackstone
setblock 309 200 231 minecraft:light[level=12]
setblock 309 200 239 minecraft:light[level=12]
setblock 309 200 247 minecraft:light[level=12]
setblock 309 200 255 minecraft:light[level=12]
setblock 309 200 263 minecraft:light[level=12]
setblock 315 200 228 minecraft:shroomlight
setblock 317 200 231 minecraft:light[level=12]
setblock 317 200 239 minecraft:light[level=12]
setblock 317 200 247 minecraft:light[level=12]
setblock 317 200 255 minecraft:light[level=12]
setblock 317 200 263 minecraft:light[level=12]
fill 318 200 232 318 204 232 minecraft:basalt
fill 324 200 267 324 283 267 minecraft:blackstone
fill 282 201 230 282 283 230 minecraft:blackstone
setblock 285 201 238 minecraft:light[level=12]
setblock 285 201 245 minecraft:light[level=12]
setblock 285 201 252 minecraft:light[level=12]
setblock 285 201 259 minecraft:light[level=12]
setblock 285 201 266 minecraft:light[level=12]
setblock 292 201 231 minecraft:light[level=12]
setblock 292 201 238 minecraft:light[level=12]
setblock 292 201 245 minecraft:light[level=12]
setblock 292 201 252 minecraft:light[level=12]
setblock 292 201 259 minecraft:light[level=12]
setblock 292 201 266 minecraft:light[level=12]
setblock 299 201 231 minecraft:light[level=12]
setblock 299 201 238 minecraft:light[level=12]
setblock 299 201 245 minecraft:light[level=12]
setblock 299 201 252 minecraft:light[level=12]
setblock 299 201 259 minecraft:light[level=12]
setblock 299 201 266 minecraft:light[level=12]
setblock 306 201 231 minecraft:light[level=12]
setblock 306 201 238 minecraft:light[level=12]
setblock 306 201 245 minecraft:light[level=12]
setblock 306 201 252 minecraft:light[level=12]
setblock 306 201 259 minecraft:light[level=12]
setblock 306 201 266 minecraft:light[level=12]
setblock 313 201 231 minecraft:light[level=12]
setblock 313 201 238 minecraft:light[level=12]
setblock 313 201 245 minecraft:light[level=12]
setblock 313 201 252 minecraft:light[level=12]
setblock 313 201 259 minecraft:light[level=12]
setblock 313 201 266 minecraft:light[level=12]
fill 315 201 228 315 283 228 minecraft:blackstone
setblock 320 201 231 minecraft:light[level=12]
setblock 320 201 238 minecraft:light[level=12]
setblock 320 201 245 minecraft:light[level=12]
setblock 320 201 252 minecraft:light[level=12]
setblock 320 201 259 minecraft:light[level=12]
setblock 320 201 266 minecraft:light[level=12]
fill 288 202 270 288 204 270 minecraft:magma_block
fill 295 202 231 298 204 232 minecraft:basalt
fill 296 202 230 297 204 230 minecraft:basalt
fill 296 202 233 298 249 233 minecraft:basalt
setblock 324 202 237 minecraft:magma_block
fill 324 202 258 324 214 258 minecraft:blackstone
setblock 324 202 259 minecraft:shroomlight
fill 324 202 260 324 283 260 minecraft:blackstone
fill 287 203 233 287 213 233 minecraft:blackstone
fill 294 203 231 294 205 232 minecraft:blackstone
fill 295 203 230 295 205 230 minecraft:blackstone
fill 295 203 233 295 204 234 minecraft:blackstone
fill 296 203 229 297 205 229 minecraft:blackstone
fill 296 203 234 298 204 234 minecraft:blackstone
fill 298 203 230 299 205 230 minecraft:blackstone
fill 299 203 231 299 204 233 minecraft:blackstone
fill 314 203 270 316 247 270 minecraft:blackstone
fill 316 203 258 318 255 261 minecraft:basalt
fill 317 203 262 317 255 262 minecraft:basalt
setblock 317 203 270 minecraft:crying_obsidian
fill 318 203 270 318 283 270 minecraft:blackstone
fill 319 203 259 319 255 261 minecraft:basalt
fill 324 203 237 324 283 237 minecraft:blackstone
fill 324 203 259 324 237 259 minecraft:blackstone
fill 282 204 232 282 221 233 minecraft:blackstone
setblock 282 204 234 minecraft:magma_block
fill 282 204 235 282 283 235 minecraft:blackstone
fill 282 204 262 282 221 263 minecraft:blackstone
setblock 282 204 264 minecraft:shroomlight
fill 282 204 265 282 233 270 minecraft:blackstone
fill 293 204 232 293 205 232 minecraft:blackstone
fill 294 204 230 294 205 230 minecraft:blackstone
fill 294 204 233 294 204 234 minecraft:blackstone
fill 295 204 229 295 205 229 minecraft:blackstone
fill 295 204 235 298 204 235 minecraft:blackstone
fill 298 204 229 299 205 229 minecraft:blackstone
setblock 299 204 234 minecraft:blackstone
fill 300 204 230 300 204 233 minecraft:blackstone
fill 312 204 246 312 205 248 minecraft:blackstone
fill 313 204 247 313 205 248 minecraft:blackstone
fill 315 204 258 315 205 261 minecraft:blackstone
fill 316 204 257 318 205 257 minecraft:blackstone
fill 316 204 262 316 205 262 minecraft:blackstone
fill 317 204 270 317 283 270 minecraft:blackstone
fill 318 204 262 319 205 262 minecraft:blackstone
fill 319 204 258 320 205 258 minecraft:blackstone
fill 320 204 259 320 205 261 minecraft:blackstone
fill 282 205 234 286 205 234 minecraft:blackstone
fill 282 205 243 286 205 246 minecraft:blackstone
setblock 282 205 247 minecraft:magma_block
fill 282 205 264 286 205 264 minecraft:blackstone
fill 283 205 229 286 205 233 minecraft:blackstone
fill 283 205 235 286 205 242 minecraft:blackstone
fill 283 205 247 286 205 263 minecraft:blackstone
fill 283 205 265 286 205 269 minecraft:blackstone
fill 284 205 270 286 207 270 minecraft:blackstone
fill 287 205 229 292 205 232 minecraft:blackstone
fill 287 205 266 323 205 269 minecraft:blackstone
setblock 287 205 270 minecraft:shroomlight
setblock 288 205 270 minecraft:blackstone
setblock 290 205 228 minecraft:shroomlight
fill 293 205 229 293 205 231 minecraft:blackstone
setblock 294 205 229 minecraft:blackstone
fill 295 205 231 323 205 232 minecraft:blackstone
fill 296 205 230 297 205 230 minecraft:blackstone
fill 300 205 229 323 205 230 minecraft:blackstone
fill 314 205 258 314 205 262 minecraft:blackstone
setblock 315 205 257 minecraft:blackstone
fill 315 205 262 315 205 263 minecraft:blackstone
fill 316 205 256 323 205 256 minecraft:blackstone
fill 316 205 263 323 205 263 minecraft:blackstone
fill 319 205 257 323 205 257 minecraft:blackstone
fill 320 205 233 323 205 255 minecraft:blackstone
fill 320 205 262 323 205 262 minecraft:blackstone
fill 320 205 264 323 205 265 minecraft:blackstone
fill 321 205 258 323 205 261 minecraft:blackstone
fill 324 205 252 324 283 252 minecraft:blackstone
fill 324 205 253 324 206 253 minecraft:magma_block
fill 282 206 234 282 283 234 minecraft:blackstone
fill 282 206 243 282 222 247 minecraft:blackstone
fill 282 206 264 282 283 264 minecraft:blackstone
fill 283 206 229 285 206 269 minecraft:magma_block
fill 286 206 229 323 206 231 minecraft:magma_block
fill 286 206 267 323 206 269 minecraft:magma_block
fill 287 206 270 287 208 270 minecraft:blackstone
fill 288 206 270 288 208 270 minecraft:magma_block
fill 290 206 228 290 283 228 minecraft:blackstone
fill 295 206 232 298 223 232 minecraft:basalt
setblock 309 206 228 minecraft:crying_obsidian
fill 310 206 228 310 283 228 minecraft:blackstone
fill 318 206 232 318 210 232 minecraft:basalt
fill 321 206 232 323 206 266 minecraft:magma_block
fill 324 206 229 324 283 229 minecraft:blackstone
setblock 324 206 230 minecraft:magma_block
fill 283 207 229 284 207 269 minecraft:shroomlight
fill 285 207 229 323 207 230 minecraft:shroomlight
setblock 285 207 231 minecraft:light[level=12]
fill 285 207 238 285 207 239 minecraft:light[level=12]
setblock 285 207 245 minecraft:light[level=12]
setblock 285 207 247 minecraft:light[level=12]
setblock 285 207 252 minecraft:light[level=12]
setblock 285 207 255 minecraft:light[level=12]
setblock 285 207 259 minecraft:light[level=12]
setblock 285 207 263 minecraft:light[level=12]
setblock 285 207 266 minecraft:light[level=12]
fill 285 207 268 323 207 269 minecraft:shroomlight
fill 292 207 231 293 207 231 minecraft:light[level=12]
setblock 292 207 238 minecraft:light[level=12]
setblock 292 207 245 minecraft:light[level=12]
setblock 292 207 252 minecraft:light[level=12]
setblock 292 207 259 minecraft:light[level=12]
setblock 292 207 266 minecraft:light[level=12]
setblock 292 207 270 minecraft:crying_obsidian
setblock 293 207 239 minecraft:light[level=12]
setblock 293 207 247 minecraft:light[level=12]
setblock 293 207 255 minecraft:light[level=12]
setblock 293 207 263 minecraft:light[level=12]
fill 295 207 231 298 223 231 minecraft:basalt
setblock 299 207 231 minecraft:light[level=12]
setblock 299 207 238 minecraft:light[level=12]
setblock 299 207 245 minecraft:light[level=12]
setblock 299 207 252 minecraft:light[level=12]
setblock 299 207 259 minecraft:light[level=12]
setblock 299 207 266 minecraft:light[level=12]
setblock 301 207 231 minecraft:light[level=12]
setblock 301 207 239 minecraft:light[level=12]
setblock 301 207 247 minecraft:light[level=12]
setblock 301 207 255 minecraft:light[level=12]
setblock 301 207 263 minecraft:light[level=12]
setblock 306 207 231 minecraft:light[level=12]
setblock 306 207 238 minecraft:light[level=12]
setblock 306 207 245 minecraft:light[level=12]
setblock 306 207 252 minecraft:light[level=12]
setblock 306 207 259 minecraft:light[level=12]
setblock 306 207 266 minecraft:light[level=12]
fill 309 207 228 309 283 228 minecraft:blackstone
setblock 309 207 231 minecraft:light[level=12]
setblock 309 207 239 minecraft:light[level=12]
setblock 309 207 247 minecraft:light[level=12]
setblock 309 207 255 minecraft:light[level=12]
setblock 309 207 263 minecraft:light[level=12]
setblock 313 207 231 minecraft:light[level=12]
setblock 313 207 238 minecraft:light[level=12]
setblock 313 207 245 minecraft:light[level=12]
setblock 313 207 252 minecraft:light[level=12]
setblock 313 207 259 minecraft:light[level=12]
setblock 313 207 266 minecraft:light[level=12]
setblock 317 207 231 minecraft:light[level=12]
setblock 317 207 239 minecraft:light[level=12]
setblock 317 207 247 minecraft:light[level=12]
setblock 317 207 255 minecraft:light[level=12]
setblock 317 207 263 minecraft:light[level=12]
setblock 320 207 231 minecraft:light[level=12]
setblock 320 207 238 minecraft:light[level=12]
setblock 320 207 245 minecraft:light[level=12]
setblock 320 207 252 minecraft:light[level=12]
setblock 320 207 259 minecraft:light[level=12]
setblock 320 207 266 minecraft:light[level=12]
fill 322 207 231 323 207 267 minecraft:shroomlight
fill 324 207 230 324 283 230 minecraft:blackstone
fill 324 207 253 324 241 253 minecraft:blackstone
setblock 282 208 255 minecraft:shroomlight
fill 284 208 270 285 228 270 minecraft:blackstone
setblock 286 208 270 minecraft:magma_block
fill 292 208 270 292 283 270 minecraft:blackstone
fill 296 208 230 297 223 230 minecraft:basalt
fill 317 208 232 317 210 232 minecraft:basalt
fill 318 208 231 318 210 231 minecraft:basalt
fill 318 208 233 318 210 233 minecraft:basalt
fill 319 208 232 319 210 232 minecraft:basalt
setblock 324 208 241 minecraft:magma_block
fill 282 209 255 282 260 255 minecraft:blackstone
fill 286 209 233 286 213 233 minecraft:blackstone
fill 286 209 270 286 283 270 minecraft:blackstone
fill 287 209 232 287 213 232 minecraft:blackstone
fill 287 209 234 287 213 234 minecraft:blackstone
setblock 287 209 270 minecraft:shroomlight
fill 288 209 233 288 213 233 minecraft:blackstone
setblock 288 209 270 minecraft:blackstone
fill 324 209 241 324 233 241 minecraft:blackstone
setblock 282 210 259 minecraft:crying_obsidian
setblock 282 210 260 minecraft:blackstone
setblock 287 210 270 minecraft:blackstone
setblock 288 210 270 minecraft:magma_block
fill 303 210 233 304 211 234 minecraft:blackstone
setblock 309 210 270 minecraft:magma_block
fill 282 211 259 282 236 259 minecraft:blackstone
setblock 282 211 260 minecraft:shroomlight
fill 287 211 270 287 212 270 minecraft:magma_block
fill 288 211 270 288 212 270 minecraft:blackstone
fill 309 211 270 309 262 270 minecraft:blackstone
setblock 282 212 229 minecraft:magma_block
fill 282 212 260 282 283 260 minecraft:blackstone
fill 286 212 232 286 213 232 minecraft:blackstone
fill 286 212 234 286 213 234 minecraft:blackstone
fill 288 212 232 288 213 232 minecraft:blackstone
fill 288 212 234 288 213 234 minecraft:blackstone
fill 282 213 229 282 214 229 minecraft:blackstone
fill 285 213 231 285 214 231 minecraft:light[level=12]
setblock 285 213 238 minecraft:light[level=12]
setblock 285 213 245 minecraft:light[level=12]
setblock 285 213 252 minecraft:light[level=12]
setblock 285 213 259 minecraft:light[level=12]
setblock 285 213 266 minecraft:light[level=12]
fill 287 213 270 287 223 270 minecraft:blackstone
setblock 288 213 270 minecraft:shroomlight
setblock 292 213 231 minecraft:light[level=12]
setblock 292 213 238 minecraft:light[level=12]
setblock 292 213 245 minecraft:light[level=12]
setblock 292 213 252 minecraft:light[level=12]
setblock 292 213 259 minecraft:light[level=12]
setblock 292 213 266 minecraft:light[level=12]
setblock 299 213 231 minecraft:light[level=12]
setblock 299 213 238 minecraft:light[level=12]
setblock 299 213 245 minecraft:light[level=12]
setblock 299 213 252 minecraft:light[level=12]
setblock 299 213 259 minecraft:light[level=12]
setblock 299 213 266 minecraft:light[level=12]
setblock 306 213 231 minecraft:light[level=12]
setblock 306 213 238 minecraft:light[level=12]
setblock 306 213 245 minecraft:light[level=12]
setblock 306 213 252 minecraft:light[level=12]
setblock 306 213 259 minecraft:light[level=12]
setblock 306 213 266 minecraft:light[level=12]
setblock 313 213 231 minecraft:light[level=12]
setblock 313 213 238 minecraft:light[level=12]
setblock 313 213 245 minecraft:light[level=12]
setblock 313 213 252 minecraft:light[level=12]
setblock 313 213 259 minecraft:light[level=12]
setblock 313 213 266 minecraft:light[level=12]
setblock 320 213 231 minecraft:light[level=12]
setblock 320 213 238 minecraft:light[level=12]
setblock 320 213 245 minecraft:light[level=12]
setblock 320 213 252 minecraft:light[level=12]
setblock 320 213 259 minecraft:light[level=12]
setblock 320 213 266 minecraft:light[level=12]
setblock 285 214 239 minecraft:light[level=12]
setblock 285 214 247 minecraft:light[level=12]
setblock 285 214 255 minecraft:light[level=12]
setblock 285 214 263 minecraft:light[level=12]
setblock 288 214 270 minecraft:magma_block
setblock 293 214 231 minecraft:light[level=12]
setblock 293 214 239 minecraft:light[level=12]
setblock 293 214 247 minecraft:light[level=12]
setblock 293 214 255 minecraft:light[level=12]
setblock 293 214 263 minecraft:light[level=12]
fill 300 214 270 300 267 270 minecraft:blackstone
setblock 301 214 231 minecraft:light[level=12]
setblock 301 214 239 minecraft:light[level=12]
setblock 301 214 247 minecraft:light[level=12]
setblock 301 214 255 minecraft:light[level=12]
setblock 301 214 263 minecraft:light[level=12]
setblock 301 214 270 minecraft:shroomlight
fill 302 214 270 303 283 270 minecraft:blackstone
setblock 309 214 231 minecraft:light[level=12]
setblock 309 214 239 minecraft:light[level=12]
setblock 309 214 247 minecraft:light[level=12]
setblock 309 214 255 minecraft:light[level=12]
setblock 309 214 263 minecraft:light[level=12]
setblock 317 214 231 minecraft:light[level=12]
setblock 317 214 239 minecraft:light[level=12]
setblock 317 214 247 minecraft:light[level=12]
setblock 317 214 255 minecraft:light[level=12]
setblock 317 214 263 minecraft:light[level=12]
setblock 324 214 254 minecraft:crying_obsidian
setblock 282 215 229 minecraft:shroomlight
fill 288 215 270 288 216 270 minecraft:blackstone
fill 289 215 270 289 216 270 minecraft:magma_block
fill 290 215 270 291 222 270 minecraft:blackstone
fill 301 215 270 301 283 270 minecraft:blackstone
setblock 324 215 249 minecraft:magma_block
fill 324 215 254 324 283 254 minecraft:blackstone
setblock 324 215 258 minecraft:shroomlight
fill 282 216 229 282 283 229 minecraft:blackstone
fill 324 216 249 324 260 249 minecraft:blackstone
fill 324 216 258 324 283 258 minecraft:blackstone
setblock 288 217 270 minecraft:shroomlight
setblock 289 217 270 minecraft:blackstone
setblock 301 217 228 minecraft:crying_obsidian
fill 315 217 255 315 218 255 minecraft:magma_block
fill 288 218 270 288 224 270 minecraft:blackstone
fill 289 218 270 289 220 270 minecraft:magma_block
fill 296 218 263 296 219 263 minecraft:magma_block
fill 301 218 228 301 223 228 minecraft:blackstone
setblock 324 218 243 minecraft:magma_block
fill 324 218 244 324 283 245 minecraft:blackstone
setblock 324 218 246 minecraft:crying_obsidian
setblock 285 219 231 minecraft:light[level=12]
setblock 285 219 238 minecraft:light[level=12]
setblock 285 219 245 minecraft:light[level=12]
setblock 285 219 252 minecraft:light[level=12]
setblock 285 219 259 minecraft:light[level=12]
setblock 285 219 266 minecraft:light[level=12]
setblock 292 219 231 minecraft:light[level=12]
setblock 292 219 238 minecraft:light[level=12]
setblock 292 219 245 minecraft:light[level=12]
setblock 292 219 252 minecraft:light[level=12]
setblock 292 219 259 minecraft:light[level=12]
setblock 292 219 266 minecraft:light[level=12]
setblock 299 219 231 minecraft:light[level=12]
setblock 299 219 238 minecraft:light[level=12]
setblock 299 219 245 minecraft:light[level=12]
setblock 299 219 252 minecraft:light[level=12]
setblock 299 219 259 minecraft:light[level=12]
setblock 299 219 266 minecraft:light[level=12]
setblock 306 219 231 minecraft:light[level=12]
setblock 306 219 238 minecraft:light[level=12]
setblock 306 219 245 minecraft:light[level=12]
setblock 306 219 252 minecraft:light[level=12]
setblock 306 219 259 minecraft:light[level=12]
setblock 306 219 266 minecraft:light[level=12]
setblock 313 219 231 minecraft:light[level=12]
setblock 313 219 238 minecraft:light[level=12]
setblock 313 219 245 minecraft:light[level=12]
setblock 313 219 252 minecraft:light[level=12]
setblock 313 219 259 minecraft:light[level=12]
setblock 313 219 266 minecraft:light[level=12]
setblock 320 219 231 minecraft:light[level=12]
setblock 320 219 238 minecraft:light[level=12]
setblock 320 219 245 minecraft:light[level=12]
setblock 320 219 252 minecraft:light[level=12]
setblock 320 219 259 minecraft:light[level=12]
setblock 320 219 266 minecraft:light[level=12]
fill 324 219 243 324 283 243 minecraft:blackstone
fill 324 219 246 324 283 246 minecraft:blackstone
setblock 285 221 231 minecraft:light[level=12]
setblock 285 221 239 minecraft:light[level=12]
setblock 285 221 247 minecraft:light[level=12]
setblock 285 221 255 minecraft:light[level=12]
setblock 285 221 263 minecraft:light[level=12]
setblock 289 221 270 minecraft:shroomlight
setblock 293 221 231 minecraft:light[level=12]
setblock 293 221 239 minecraft:light[level=12]
setblock 293 221 247 minecraft:light[level=12]
setblock 293 221 255 minecraft:light[level=12]
setblock 293 221 263 minecraft:light[level=12]
setblock 301 221 231 minecraft:light[level=12]
setblock 301 221 239 minecraft:light[level=12]
setblock 301 221 247 minecraft:light[level=12]
setblock 301 221 255 minecraft:light[level=12]
setblock 301 221 263 minecraft:light[level=12]
setblock 309 221 231 minecraft:light[level=12]
setblock 309 221 239 minecraft:light[level=12]
setblock 309 221 247 minecraft:light[level=12]
setblock 309 221 255 minecraft:light[level=12]
setblock 309 221 263 minecraft:light[level=12]
setblock 317 221 231 minecraft:light[level=12]
setblock 317 221 239 minecraft:light[level=12]
setblock 317 221 247 minecraft:light[level=12]
setblock 317 221 255 minecraft:light[level=12]
setblock 317 221 263 minecraft:light[level=12]
setblock 282 222 232 minecraft:magma_block
fill 282 222 233 282 283 233 minecraft:blackstone
fill 282 222 262 282 254 262 minecraft:blackstone
setblock 282 222 263 minecraft:shroomlight
setblock 289 222 270 minecraft:magma_block
fill 293 222 239 293 222 240 minecraft:basalt
setblock 293 222 241 minecraft:magma_block
fill 293 222 242 293 224 242 minecraft:basalt
fill 303 222 261 303 223 261 minecraft:magma_block
fill 282 223 232 282 283 232 minecraft:blackstone
fill 282 223 243 282 226 245 minecraft:blackstone
setblock 282 223 246 minecraft:magma_block
fill 282 223 247 282 283 247 minecraft:blackstone
fill 282 223 263 282 231 263 minecraft:blackstone
setblock 289 223 270 minecraft:blackstone
setblock 290 223 270 minecraft:magma_block
fill 291 223 240 291 224 240 minecraft:basalt
fill 291 223 270 291 228 270 minecraft:blackstone
fill 292 223 239 292 224 239 minecraft:basalt
setblock 292 223 240 minecraft:magma_block
fill 292 223 241 292 224 242 minecraft:basalt
setblock 293 223 239 minecraft:magma_block
fill 293 223 240 294 224 241 minecraft:basalt
fill 294 223 239 294 224 239 minecraft:basalt
setblock 294 223 242 minecraft:basalt
fill 296 223 270 296 283 270 minecraft:blackstone
setblock 297 223 270 minecraft:crying_obsidian
fill 282 224 246 286 224 246 minecraft:blackstone
fill 283 224 229 286 224 245 minecraft:blackstone
fill 283 224 247 286 224 269 minecraft:blackstone
fill 287 224 229 323 224 232 minecraft:blackstone
fill 287 224 252 287 225 254 minecraft:blackstone
fill 287 224 266 323 224 269 minecraft:blackstone
setblock 287 224 270 minecraft:shroomlight
fill 288 224 253 288 225 254 minecraft:blackstone
setblock 289 224 270 minecraft:magma_block
fill 290 224 270 290 227 270 minecraft:blackstone
setblock 291 224 241 minecraft:basalt
fill 292 224 240 292 225 240 minecraft:basalt
setblock 293 224 239 minecraft:basalt
fill 297 224 270 297 283 270 minecraft:blackstone
setblock 301 224 228 minecraft:shroomlight
fill 303 224 261 303 232 261 minecraft:blackstone
fill 320 224 233 323 224 265 minecraft:blackstone
fill 282 225 246 282 283 246 minecraft:blackstone
fill 283 225 229 285 225 269 minecraft:magma_block
fill 286 225 229 323 225 231 minecraft:magma_block
fill 286 225 267 323 225 269 minecraft:magma_block
fill 287 225 270 287 283 270 minecraft:blackstone
setblock 288 225 270 minecraft:shroomlight
setblock 289 225 270 minecraft:blackstone
setblock 292 225 238 minecraft:light[level=12]
setblock 292 225 241 minecraft:basalt
setblock 292 225 245 minecraft:light[level=12]
setblock 292 225 252 minecraft:light[level=12]
setblock 292 225 259 minecraft:light[level=12]
setblock 292 225 266 minecraft:light[level=12]
setblock 293 225 240 minecraft:basalt
setblock 293 225 241 minecraft:magma_block
setblock 294 225 240 minecraft:magma_block
setblock 294 225 241 minecraft:basalt
fill 295 225 232 298 242 232 minecraft:basalt
setblock 299 225 238 minecraft:light[level=12]
setblock 299 225 245 minecraft:light[level=12]
setblock 299 225 252 minecraft:light[level=12]
setblock 299 225 259 minecraft:light[level=12]
setblock 299 225 266 minecraft:light[level=12]
fill 301 225 228 301 283 228 minecraft:blackstone
fill 304 225 261 304 232 261 minecraft:blackstone
setblock 306 225 238 minecraft:light[level=12]
setblock 306 225 245 minecraft:light[level=12]
setblock 306 225 252 minecraft:light[level=12]
setblock 306 225 259 minecraft:light[level=12]
setblock 306 225 266 minecraft:light[level=12]
setblock 313 225 238 minecraft:light[level=12]
setblock 313 225 245 minecraft:light[level=12]
setblock 313 225 252 minecraft:light[level=12]
setblock 313 225 259 minecraft:light[level=12]
setblock 313 225 266 minecraft:light[level=12]
setblock 320 225 238 minecraft:light[level=12]
setblock 320 225 245 minecraft:light[level=12]
setblock 320 225 252 minecraft:light[level=12]
setblock 320 225 259 minecraft:light[level=12]
setblock 320 225 266 minecraft:light[level=12]
fill 321 225 232 323 225 266 minecraft:magma_block
fill 283 226 229 284 226 269 minecraft:shroomlight
fill 285 226 229 323 226 230 minecraft:shroomlight
fill 285 226 268 323 226 269 minecraft:shroomlight
fill 288 226 270 288 283 270 minecraft:blackstone
fill 289 226 270 289 227 270 minecraft:magma_block
fill 295 226 231 298 242 231 minecraft:basalt
fill 303 226 260 304 232 260 minecraft:blackstone
fill 322 226 231 323 226 267 minecraft:shroomlight
fill 282 227 243 282 228 243 minecraft:crying_obsidian
fill 282 227 244 282 283 245 minecraft:blackstone
fill 296 227 230 297 242 230 minecraft:basalt
fill 302 227 260 302 232 261 minecraft:blackstone
fill 303 227 259 303 232 259 minecraft:blackstone
fill 303 227 262 304 232 262 minecraft:blackstone
fill 305 227 261 305 232 261 minecraft:blackstone
fill 314 227 266 314 237 266 minecraft:blackstone
setblock 285 228 231 minecraft:light[level=12]
setblock 285 228 239 minecraft:light[level=12]
setblock 285 228 247 minecraft:light[level=12]
setblock 285 228 255 minecraft:light[level=12]
setblock 285 228 263 minecraft:light[level=12]
fill 289 228 270 289 283 270 minecraft:blackstone
setblock 290 228 270 minecraft:magma_block
setblock 293 228 231 minecraft:light[level=12]
setblock 293 228 239 minecraft:light[level=12]
setblock 293 228 247 minecraft:light[level=12]
setblock 293 228 255 minecraft:light[level=12]
setblock 293 228 263 minecraft:light[level=12]
setblock 301 228 231 minecraft:light[level=12]
setblock 301 228 239 minecraft:light[level=12]
setblock 301 228 247 minecraft:light[level=12]
setblock 301 228 255 minecraft:light[level=12]
setblock 301 228 263 minecraft:light[level=12]
fill 302 228 259 302 232 259 minecraft:blackstone
fill 302 228 262 302 232 262 minecraft:blackstone
fill 304 228 259 304 232 259 minecraft:blackstone
fill 305 228 260 305 232 260 minecraft:blackstone
fill 305 228 262 305 232 262 minecraft:blackstone
setblock 309 228 231 minecraft:light[level=12]
setblock 309 228 239 minecraft:light[level=12]
setblock 309 228 247 minecraft:light[level=12]
setblock 309 228 255 minecraft:light[level=12]
setblock 309 228 263 minecraft:light[level=12]
setblock 317 228 231 minecraft:light[level=12]
setblock 317 228 239 minecraft:light[level=12]
setblock 317 228 247 minecraft:light[level=12]
setblock 317 228 255 minecraft:light[level=12]
setblock 317 228 263 minecraft:light[level=12]
fill 282 229 243 282 283 243 minecraft:blackstone
setblock 282 229 251 minecraft:shroomlight
setblock 284 229 270 minecraft:crying_obsidian
fill 285 229 270 285 270 270 minecraft:blackstone
setblock 286 229 228 minecraft:shroomlight
fill 290 229 270 290 283 270 minecraft:blackstone
setblock 291 229 270 minecraft:shroomlight
fill 301 229 260 301 232 261 minecraft:blackstone
fill 303 229 263 304 232 263 minecraft:blackstone
fill 305 229 259 305 232 259 minecraft:blackstone
fill 306 229 261 306 232 261 minecraft:blackstone
setblock 324 229 238 minecraft:shroomlight
setblock 324 229 240 minecraft:shroomlight
fill 282 230 251 282 283 251 minecraft:blackstone
fill 284 230 270 284 258 270 minecraft:blackstone
fill 286 230 228 286 274 228 minecraft:blackstone
fill 291 230 270 291 283 270 minecraft:blackstone
fill 301 230 259 301 232 259 minecraft:blackstone
fill 301 230 262 301 232 262 minecraft:blackstone
fill 302 230 258 305 232 258 minecraft:blackstone
fill 302 230 263 302 232 263 minecraft:blackstone
setblock 303 230 228 minecraft:shroomlight
fill 305 230 263 305 232 263 minecraft:blackstone
fill 306 230 259 306 232 260 minecraft:blackstone
fill 306 230 262 306 232 262 minecraft:blackstone
setblock 310 230 270 minecraft:crying_obsidian
fill 311 230 270 312 269 270 minecraft:blackstone
fill 324 230 238 324 283 238 minecraft:blackstone
fill 324 230 240 324 272 240 minecraft:blackstone
setblock 282 231 248 minecraft:crying_obsidian
setblock 285 231 231 minecraft:light[level=12]
setblock 285 231 238 minecraft:light[level=12]
setblock 285 231 245 minecraft:light[level=12]
setblock 285 231 252 minecraft:light[level=12]
setblock 285 231 259 minecraft:light[level=12]
setblock 285 231 266 minecraft:light[level=12]
setblock 292 231 231 minecraft:light[level=12]
setblock 292 231 238 minecraft:light[level=12]
setblock 292 231 245 minecraft:light[level=12]
setblock 292 231 252 minecraft:light[level=12]
setblock 292 231 259 minecraft:light[level=12]
setblock 292 231 266 minecraft:light[level=12]
setblock 299 231 231 minecraft:light[level=12]
setblock 299 231 238 minecraft:light[level=12]
setblock 299 231 245 minecraft:light[level=12]
setblock 299 231 252 minecraft:light[level=12]
setblock 299 231 259 minecraft:light[level=12]
setblock 299 231 266 minecraft:light[level=12]
fill 300 231 260 300 232 261 minecraft:blackstone
fill 301 231 258 301 232 258 minecraft:blackstone
fill 301 231 263 301 232 263 minecraft:blackstone
fill 302 231 264 304 232 264 minecraft:blackstone
fill 303 231 228 303 283 228 minecraft:blackstone
setblock 306 231 231 minecraft:light[level=12]
setblock 306 231 238 minecraft:light[level=12]
setblock 306 231 245 minecraft:light[level=12]
setblock 306 231 252 minecraft:light[level=12]
fill 306 231 263 306 232 263 minecraft:blackstone
setblock 306 231 266 minecraft:light[level=12]
fill 307 231 261 307 232 261 minecraft:blackstone
fill 310 231 270 310 283 270 minecraft:blackstone
setblock 313 231 231 minecraft:light[level=12]
setblock 313 231 238 minecraft:light[level=12]
setblock 313 231 245 minecraft:light[level=12]
setblock 313 231 252 minecraft:light[level=12]
setblock 313 231 259 minecraft:light[level=12]
setblock 313 231 266 minecraft:light[level=12]
setblock 320 231 231 minecraft:light[level=12]
setblock 320 231 238 minecraft:light[level=12]
setblock 320 231 245 minecraft:light[level=12]
setblock 320 231 252 minecraft:light[level=12]
setblock 320 231 259 minecraft:light[level=12]
setblock 320 231 266 minecraft:light[level=12]
setblock 324 231 236 minecraft:shroomlight
fill 282 232 248 282 283 248 minecraft:blackstone
setblock 282 232 263 minecraft:magma_block
setblock 300 232 259 minecraft:blackstone
setblock 300 232 262 minecraft:blackstone
setblock 301 232 264 minecraft:blackstone
fill 302 232 257 305 232 257 minecraft:blackstone
setblock 305 232 264 minecraft:blackstone
setblock 306 232 258 minecraft:blackstone
fill 307 232 259 307 232 260 minecraft:blackstone
setblock 307 232 262 minecraft:blackstone
setblock 318 232 228 minecraft:magma_block
fill 324 232 236 324 283 236 minecraft:blackstone
fill 282 233 263 282 283 263 minecraft:blackstone
fill 303 233 260 304 234 261 minecraft:magma_block
fill 313 233 266 313 237 266 minecraft:blackstone
fill 314 233 265 314 237 265 minecraft:blackstone
fill 314 233 267 314 237 267 minecraft:blackstone
fill 315 233 266 315 237 266 minecraft:blackstone
fill 318 233 228 318 283 228 minecraft:blackstone
fill 282 234 265 282 259 267 minecraft:blackstone
setblock 282 234 268 minecraft:shroomlight
fill 282 234 269 282 283 270 minecraft:blackstone
fill 313 234 228 313 283 228 minecraft:blackstone
setblock 314 234 228 minecraft:magma_block
setblock 324 234 241 minecraft:magma_block
setblock 324 234 255 minecraft:crying_obsidian
fill 324 234 256 324 283 256 minecraft:blackstone
fill 324 234 262 324 235 264 minecraft:blackstone
setblock 324 234 265 minecraft:shroomlight
fill 282 235 237 282 283 237 minecraft:blackstone
setblock 282 235 238 minecraft:shroomlight
fill 282 235 268 282 244 268 minecraft:blackstone
setblock 285 235 231 minecraft:light[level=12]
setblock 285 235 239 minecraft:light[level=12]
setblock 285 235 247 minecraft:light[level=12]
setblock 285 235 255 minecraft:light[level=12]
setblock 285 235 263 minecraft:light[level=12]
fill 287 235 240 288 236 240 minecraft:magma_block
fill 288 235 239 288 236 239 minecraft:magma_block
fill 288 235 241 288 236 241 minecraft:magma_block
setblock 293 235 231 minecraft:light[level=12]
setblock 293 235 239 minecraft:light[level=12]
setblock 293 235 247 minecraft:light[level=12]
setblock 293 235 255 minecraft:light[level=12]
setblock 293 235 263 minecraft:light[level=12]
setblock 301 235 231 minecraft:light[level=12]
setblock 301 235 239 minecraft:light[level=12]
setblock 301 235 247 minecraft:light[level=12]
setblock 301 235 255 minecraft:light[level=12]
setblock 301 235 263 minecraft:light[level=12]
fill 303 235 260 303 235 261 minecraft:magma_block
setblock 304 235 261 minecraft:magma_block
setblock 309 235 231 minecraft:light[level=12]
setblock 309 235 239 minecraft:light[level=12]
setblock 309 235 247 minecraft:light[level=12]
setblock 309 235 255 minecraft:light[level=12]
setblock 309 235 263 minecraft:light[level=12]
fill 314 235 228 314 283 228 minecraft:blackstone
setblock 317 235 231 minecraft:light[level=12]
setblock 317 235 239 minecraft:light[level=12]
setblock 317 235 247 minecraft:light[level=12]
setblock 317 235 255 minecraft:light[level=12]
setblock 317 235 263 minecraft:light[level=12]
fill 324 235 241 324 283 241 minecraft:blackstone
fill 324 235 255 324 283 255 minecraft:blackstone
fill 324 235 265 324 283 265 minecraft:blackstone
fill 282 236 238 282 283 238 minecraft:blackstone
setblock 303 236 261 minecraft:magma_block
fill 313 236 265 313 237 265 minecraft:blackstone
fill 313 236 267 313 237 267 minecraft:blackstone
fill 315 236 265 315 237 265 minecraft:blackstone
fill 315 236 267 315 237 267 minecraft:blackstone
fill 324 236 262 324 283 263 minecraft:blackstone
setblock 324 236 264 minecraft:magma_block
setblock 282 237 259 minecraft:crying_obsidian
setblock 285 237 231 minecraft:light[level=12]
setblock 285 237 238 minecraft:light[level=12]
setblock 285 237 245 minecraft:light[level=12]
setblock 285 237 252 minecraft:light[level=12]
setblock 285 237 259 minecraft:light[level=12]
setblock 285 237 266 minecraft:light[level=12]
setblock 292 237 231 minecraft:light[level=12]
setblock 292 237 238 minecraft:light[level=12]
setblock 292 237 245 minecraft:light[level=12]
setblock 292 237 252 minecraft:light[level=12]
setblock 292 237 259 minecraft:light[level=12]
setblock 292 237 266 minecraft:light[level=12]
setblock 299 237 231 minecraft:light[level=12]
setblock 299 237 238 minecraft:light[level=12]
setblock 299 237 245 minecraft:light[level=12]
setblock 299 237 252 minecraft:light[level=12]
setblock 299 237 259 minecraft:light[level=12]
setblock 299 237 266 minecraft:light[level=12]
setblock 304 237 270 minecraft:magma_block
setblock 306 237 231 minecraft:light[level=12]
setblock 306 237 238 minecraft:light[level=12]
setblock 306 237 245 minecraft:light[level=12]
setblock 306 237 252 minecraft:light[level=12]
setblock 306 237 259 minecraft:light[level=12]
setblock 306 237 266 minecraft:light[level=12]
setblock 313 237 231 minecraft:light[level=12]
setblock 313 237 238 minecraft:light[level=12]
setblock 313 237 245 minecraft:light[level=12]
setblock 313 237 252 minecraft:light[level=12]
setblock 313 237 259 minecraft:light[level=12]
setblock 320 237 231 minecraft:light[level=12]
setblock 320 237 238 minecraft:light[level=12]
setblock 320 237 245 minecraft:light[level=12]
setblock 320 237 252 minecraft:light[level=12]
setblock 320 237 259 minecraft:light[level=12]
setblock 320 237 266 minecraft:light[level=12]
fill 324 237 264 324 276 264 minecraft:blackstone
fill 282 238 259 282 247 259 minecraft:blackstone
fill 304 238 270 304 283 270 minecraft:blackstone
setblock 324 238 259 minecraft:crying_obsidian
fill 304 239 260 305 239 260 minecraft:basalt
setblock 305 239 259 minecraft:basalt
setblock 305 239 261 minecraft:magma_block
setblock 306 239 260 minecraft:magma_block
fill 306 239 261 307 240 261 minecraft:basalt
fill 307 239 260 308 240 260 minecraft:basalt
fill 324 239 259 324 283 259 minecraft:blackstone
setblock 293 240 270 minecraft:magma_block
fill 294 240 270 294 283 270 minecraft:blackstone
setblock 304 240 259 minecraft:basalt
setblock 304 240 260 minecraft:magma_block
fill 304 240 261 305 241 261 minecraft:basalt
setblock 305 240 259 minecraft:magma_block
fill 305 240 260 306 241 260 minecraft:basalt
fill 305 240 262 306 240 262 minecraft:basalt
fill 306 240 259 308 241 259 minecraft:basalt
setblock 308 240 261 minecraft:basalt
setblock 324 240 231 minecraft:shroomlight
fill 293 241 270 293 264 270 minecraft:blackstone
setblock 299 241 228 minecraft:magma_block
fill 305 241 259 305 242 259 minecraft:basalt
setblock 305 241 262 minecraft:basalt
fill 306 241 258 307 241 258 minecraft:basalt
fill 306 241 261 306 242 261 minecraft:basalt
setblock 306 241 270 minecraft:magma_block
fill 307 241 260 307 242 260 minecraft:basalt
setblock 307 241 261 minecraft:magma_block
fill 307 241 270 307 283 270 minecraft:blackstone
setblock 308 241 260 minecraft:magma_block
fill 324 241 231 324 283 231 minecraft:blackstone
setblock 285 242 231 minecraft:light[level=12]
setblock 285 242 239 minecraft:light[level=12]
setblock 285 242 247 minecraft:light[level=12]
setblock 285 242 255 minecraft:light[level=12]
setblock 285 242 263 minecraft:light[level=12]
setblock 293 242 231 minecraft:light[level=12]
setblock 293 242 239 minecraft:light[level=12]
setblock 293 242 247 minecraft:light[level=12]
setblock 293 242 255 minecraft:light[level=12]
setblock 293 242 263 minecraft:light[level=12]
fill 299 242 228 299 278 228 minecraft:blackstone
fill 299 242 261 301 243 261 minecraft:blackstone
fill 300 242 260 300 243 260 minecraft:blackstone
fill 300 242 262 300 243 262 minecraft:blackstone
setblock 301 242 231 minecraft:light[level=12]
setblock 301 242 239 minecraft:light[level=12]
setblock 301 242 247 minecraft:light[level=12]
setblock 301 242 255 minecraft:light[level=12]
setblock 301 242 263 minecraft:light[level=12]
setblock 305 242 260 minecraft:basalt
setblock 305 242 261 minecraft:magma_block
fill 306 242 258 306 242 259 minecraft:basalt
setblock 306 242 260 minecraft:magma_block
fill 306 242 270 306 283 270 minecraft:blackstone
setblock 307 242 259 minecraft:magma_block
setblock 307 242 261 minecraft:basalt
setblock 309 242 231 minecraft:light[level=12]
setblock 309 242 239 minecraft:light[level=12]
setblock 309 242 247 minecraft:light[level=12]
setblock 309 242 255 minecraft:light[level=12]
setblock 309 242 263 minecraft:light[level=12]
fill 316 242 249 316 243 249 minecraft:blackstone
setblock 317 242 231 minecraft:light[level=12]
setblock 317 242 239 minecraft:light[level=12]
setblock 317 242 247 minecraft:light[level=12]
setblock 317 242 255 minecraft:light[level=12]
setblock 317 242 263 minecraft:light[level=12]
setblock 324 242 253 minecraft:magma_block
fill 283 243 229 286 243 269 minecraft:blackstone
fill 287 243 229 323 243 232 minecraft:blackstone
fill 287 243 266 323 243 269 minecraft:blackstone
setblock 292 243 238 minecraft:light[level=12]
setblock 292 243 245 minecraft:light[level=12]
setblock 292 243 252 minecraft:light[level=12]
setblock 292 243 259 minecraft:light[level=12]
setblock 299 243 238 minecraft:light[level=12]
setblock 299 243 245 minecraft:light[level=12]
setblock 299 243 252 minecraft:light[level=12]
setblock 299 243 259 minecraft:light[level=12]
setblock 306 243 238 minecraft:light[level=12]
setblock 306 243 245 minecraft:light[level=12]
setblock 306 243 252 minecraft:light[level=12]
setblock 306 243 259 minecraft:light[level=12]
setblock 313 243 238 minecraft:light[level=12]
setblock 313 243 245 minecraft:light[level=12]
setblock 313 243 252 minecraft:light[level=12]
setblock 313 243 259 minecraft:light[level=12]
fill 320 243 233 323 243 265 minecraft:blackstone
fill 324 243 253 324 283 253 minecraft:blackstone
fill 282 244 252 285 244 252 minecraft:magma_block
fill 283 244 229 285 244 251 minecraft:magma_block
fill 283 244 253 285 244 269 minecraft:magma_block
fill 286 244 229 323 244 231 minecraft:magma_block
fill 286 244 267 323 244 269 minecraft:magma_block
fill 295 244 232 298 249 232 minecraft:basalt
fill 321 244 232 323 244 266 minecraft:magma_block
fill 282 245 252 282 249 252 minecraft:blackstone
setblock 282 245 268 minecraft:magma_block
fill 283 245 229 284 245 269 minecraft:shroomlight
fill 285 245 229 323 245 230 minecraft:shroomlight
fill 285 245 268 323 245 269 minecraft:shroomlight
fill 295 245 231 298 249 231 minecraft:basalt
fill 322 245 231 323 245 267 minecraft:shroomlight
fill 282 246 268 282 283 268 minecraft:blackstone
fill 289 246 252 291 246 253 minecraft:polished_blackstone
fill 296 246 230 297 250 230 minecraft:basalt
fill 287 247 252 288 247 253 minecraft:polished_blackstone
fill 289 247 251 290 247 251 minecraft:polished_blackstone
fill 289 247 252 290 247 253 minecraft:magma_block
fill 289 247 254 290 247 254 minecraft:polished_blackstone
fill 291 247 252 291 247 253 minecraft:polished_blackstone
setblock 282 248 259 minecraft:magma_block
fill 285 248 252 286 248 253 minecraft:polished_blackstone
fill 287 248 251 288 248 251 minecraft:polished_blackstone
fill 287 248 252 288 248 253 minecraft:magma_block
fill 287 248 254 288 248 254 minecraft:polished_blackstone
fill 289 248 252 290 248 253 minecraft:polished_blackstone
fill 295 248 234 296 248 237 minecraft:basalt
fill 297 248 236 297 249 236 minecraft:basalt
setblock 314 248 270 minecraft:shroomlight
fill 315 248 270 316 283 270 minecraft:blackstone
fill 282 249 259 282 283 259 minecraft:blackstone
fill 283 249 252 284 249 253 minecraft:polished_blackstone
schedule function dropper:buildpart/54_3 1t
