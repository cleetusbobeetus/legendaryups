fill 518 92 292 521 92 292 minecraft:white_concrete
fill 518 92 294 518 93 294 minecraft:white_concrete
fill 518 92 296 518 93 296 minecraft:white_concrete
fill 518 92 298 518 93 298 minecraft:white_concrete
fill 518 92 300 518 93 300 minecraft:white_concrete
fill 518 92 302 518 93 302 minecraft:white_concrete
fill 518 92 304 518 93 304 minecraft:white_concrete
fill 518 92 317 519 92 317 minecraft:shroomlight
fill 519 92 293 519 93 293 minecraft:white_concrete
fill 519 92 295 519 93 295 minecraft:white_concrete
fill 519 92 297 519 93 297 minecraft:white_concrete
fill 519 92 299 519 93 299 minecraft:white_concrete
fill 519 92 301 519 93 301 minecraft:white_concrete
fill 519 92 303 519 93 303 minecraft:white_concrete
fill 519 92 305 519 93 305 minecraft:white_concrete
fill 520 92 275 520 99 275 minecraft:brown_terracotta
fill 520 92 294 520 93 294 minecraft:white_concrete
fill 520 92 296 520 93 296 minecraft:white_concrete
fill 520 92 298 520 93 298 minecraft:white_concrete
fill 520 92 300 520 93 300 minecraft:white_concrete
fill 520 92 302 520 93 302 minecraft:white_concrete
fill 520 92 304 520 93 304 minecraft:white_concrete
fill 520 92 317 520 99 317 minecraft:brown_terracotta
setblock 521 92 275 minecraft:white_concrete
fill 521 92 293 521 93 293 minecraft:white_concrete
fill 521 92 295 521 93 295 minecraft:white_concrete
fill 521 92 297 521 93 297 minecraft:white_concrete
fill 521 92 299 521 93 299 minecraft:white_concrete
fill 521 92 301 521 93 301 minecraft:white_concrete
fill 521 92 303 521 93 303 minecraft:white_concrete
fill 521 92 305 521 93 305 minecraft:white_concrete
setblock 521 92 317 minecraft:white_concrete
fill 522 92 275 522 99 275 minecraft:brown_terracotta
fill 522 92 294 522 93 294 minecraft:white_concrete
fill 522 92 296 522 93 296 minecraft:white_concrete
fill 522 92 298 522 93 298 minecraft:white_concrete
fill 522 92 300 522 93 300 minecraft:white_concrete
fill 522 92 302 522 93 302 minecraft:white_concrete
fill 522 92 304 522 93 304 minecraft:white_concrete
fill 522 92 317 522 99 317 minecraft:brown_terracotta
fill 523 92 293 523 93 293 minecraft:white_concrete
fill 523 92 295 523 93 295 minecraft:white_concrete
fill 523 92 297 523 93 297 minecraft:white_concrete
fill 523 92 299 523 93 299 minecraft:white_concrete
fill 523 92 301 523 93 301 minecraft:white_concrete
fill 523 92 303 523 93 303 minecraft:white_concrete
fill 523 92 305 523 93 305 minecraft:white_concrete
fill 524 92 275 524 99 275 minecraft:brown_terracotta
fill 524 92 294 524 93 294 minecraft:white_concrete
fill 524 92 296 524 93 296 minecraft:white_concrete
fill 524 92 298 524 93 298 minecraft:white_concrete
fill 524 92 300 524 93 300 minecraft:white_concrete
fill 524 92 302 524 93 302 minecraft:white_concrete
fill 524 92 304 524 93 304 minecraft:white_concrete
fill 524 92 317 524 99 317 minecraft:brown_terracotta
fill 525 92 275 526 92 275 minecraft:shroomlight
fill 525 92 293 525 93 293 minecraft:white_concrete
fill 525 92 295 525 93 295 minecraft:white_concrete
fill 525 92 297 525 93 297 minecraft:white_concrete
fill 525 92 299 525 93 299 minecraft:white_concrete
fill 525 92 301 525 93 301 minecraft:white_concrete
fill 525 92 303 525 93 303 minecraft:white_concrete
fill 525 92 305 525 93 305 minecraft:white_concrete
setblock 525 92 317 minecraft:white_concrete
fill 526 92 294 526 93 294 minecraft:white_concrete
fill 526 92 300 526 93 300 minecraft:white_concrete
fill 526 92 302 526 93 302 minecraft:white_concrete
fill 526 92 304 526 93 304 minecraft:white_concrete
fill 526 92 317 526 99 317 minecraft:brown_terracotta
fill 527 92 275 528 98 275 minecraft:brown_terracotta
fill 528 92 317 528 99 317 minecraft:brown_terracotta
setblock 529 92 275 minecraft:white_concrete
setblock 529 92 317 minecraft:white_concrete
fill 530 92 275 530 99 275 minecraft:brown_terracotta
fill 530 92 317 531 92 317 minecraft:shroomlight
fill 532 92 275 532 99 275 minecraft:brown_terracotta
fill 532 92 317 532 99 317 minecraft:brown_terracotta
setblock 533 92 275 minecraft:white_concrete
fill 533 92 284 533 100 285 minecraft:brown_terracotta
setblock 533 92 317 minecraft:white_concrete
fill 534 92 275 534 99 275 minecraft:brown_terracotta
fill 534 92 283 534 100 283 minecraft:brown_terracotta
fill 534 92 317 534 99 317 minecraft:brown_terracotta
fill 535 92 284 535 100 285 minecraft:brown_terracotta
fill 536 92 275 536 99 275 minecraft:brown_terracotta
fill 536 92 317 536 99 317 minecraft:brown_terracotta
fill 537 92 275 538 92 275 minecraft:shroomlight
setblock 537 92 317 minecraft:white_concrete
fill 538 92 317 538 99 317 minecraft:brown_terracotta
fill 539 92 275 540 98 275 minecraft:brown_terracotta
fill 540 92 317 540 99 317 minecraft:brown_terracotta
setblock 541 92 275 minecraft:white_concrete
setblock 541 92 317 minecraft:white_concrete
fill 542 92 275 542 99 275 minecraft:brown_terracotta
fill 542 92 317 543 92 317 minecraft:shroomlight
fill 544 92 275 544 99 275 minecraft:brown_terracotta
fill 544 92 317 544 99 317 minecraft:brown_terracotta
setblock 545 92 275 minecraft:white_concrete
setblock 545 92 317 minecraft:white_concrete
fill 546 92 275 546 99 275 minecraft:brown_terracotta
fill 546 92 317 546 99 317 minecraft:brown_terracotta
fill 548 92 275 548 99 275 minecraft:brown_terracotta
fill 548 92 317 548 99 317 minecraft:brown_terracotta
fill 549 92 275 550 92 275 minecraft:shroomlight
fill 549 92 309 549 93 309 minecraft:white_concrete
fill 549 92 311 549 93 311 minecraft:white_concrete
fill 549 92 313 549 93 313 minecraft:white_concrete
fill 549 92 315 549 93 315 minecraft:white_concrete
setblock 549 92 317 minecraft:white_concrete
fill 550 92 310 550 93 310 minecraft:white_concrete
fill 550 92 312 550 93 312 minecraft:white_concrete
fill 550 92 314 550 93 314 minecraft:white_concrete
fill 550 92 316 550 93 316 minecraft:white_concrete
fill 550 92 317 550 99 317 minecraft:brown_terracotta
fill 551 92 275 552 98 275 minecraft:brown_terracotta
fill 551 92 283 551 93 283 minecraft:white_concrete
fill 551 92 285 551 93 285 minecraft:white_concrete
fill 551 92 287 551 93 287 minecraft:white_concrete
fill 551 92 289 551 93 289 minecraft:white_concrete
fill 551 92 309 551 93 309 minecraft:white_concrete
fill 551 92 311 551 93 311 minecraft:white_concrete
fill 551 92 313 551 93 313 minecraft:white_concrete
fill 551 92 315 551 93 315 minecraft:white_concrete
fill 552 92 282 552 93 282 minecraft:white_concrete
fill 552 92 284 552 93 284 minecraft:white_concrete
fill 552 92 286 552 93 286 minecraft:white_concrete
fill 552 92 288 552 93 288 minecraft:white_concrete
fill 552 92 290 552 93 290 minecraft:white_concrete
fill 552 92 310 552 93 310 minecraft:white_concrete
fill 552 92 312 552 93 312 minecraft:white_concrete
fill 552 92 314 552 93 314 minecraft:white_concrete
fill 552 92 316 552 93 316 minecraft:white_concrete
fill 552 92 317 552 99 317 minecraft:brown_terracotta
setblock 553 92 275 minecraft:white_concrete
fill 553 92 283 553 93 283 minecraft:white_concrete
fill 553 92 285 553 93 285 minecraft:white_concrete
fill 553 92 287 553 93 287 minecraft:white_concrete
fill 553 92 289 553 93 289 minecraft:white_concrete
fill 553 92 309 553 93 309 minecraft:white_concrete
fill 553 92 311 553 93 311 minecraft:white_concrete
fill 553 92 313 553 93 313 minecraft:white_concrete
fill 553 92 315 553 93 315 minecraft:white_concrete
setblock 553 92 317 minecraft:white_concrete
fill 554 92 275 554 99 275 minecraft:brown_terracotta
fill 554 92 282 554 93 282 minecraft:white_concrete
fill 554 92 284 554 93 284 minecraft:white_concrete
fill 554 92 286 554 93 286 minecraft:white_concrete
fill 554 92 288 554 93 288 minecraft:white_concrete
fill 554 92 290 554 93 290 minecraft:white_concrete
fill 554 92 310 554 93 310 minecraft:white_concrete
fill 554 92 312 554 93 312 minecraft:white_concrete
fill 554 92 314 554 93 314 minecraft:white_concrete
fill 554 92 316 554 93 316 minecraft:white_concrete
fill 554 92 317 555 92 317 minecraft:shroomlight
fill 555 92 283 555 93 283 minecraft:white_concrete
fill 555 92 285 555 93 285 minecraft:white_concrete
fill 555 92 287 555 93 287 minecraft:white_concrete
fill 555 92 289 555 93 289 minecraft:white_concrete
fill 555 92 309 555 93 309 minecraft:white_concrete
fill 555 92 311 555 93 311 minecraft:white_concrete
fill 555 92 313 555 93 313 minecraft:white_concrete
fill 555 92 315 555 93 315 minecraft:white_concrete
fill 556 92 275 556 99 275 minecraft:brown_terracotta
fill 556 92 282 556 93 282 minecraft:white_concrete
fill 556 92 284 556 93 284 minecraft:white_concrete
fill 556 92 286 556 93 286 minecraft:white_concrete
fill 556 92 288 556 93 288 minecraft:white_concrete
fill 556 92 290 556 93 290 minecraft:white_concrete
fill 556 92 317 556 99 317 minecraft:brown_terracotta
setblock 557 92 275 minecraft:white_concrete
fill 557 92 283 557 93 283 minecraft:white_concrete
fill 557 92 285 557 93 285 minecraft:white_concrete
fill 557 92 287 557 93 287 minecraft:white_concrete
fill 557 92 289 557 93 289 minecraft:white_concrete
setblock 557 92 317 minecraft:white_concrete
fill 558 92 275 558 99 275 minecraft:brown_terracotta
fill 558 92 282 558 93 282 minecraft:white_concrete
fill 558 92 284 558 93 284 minecraft:white_concrete
fill 558 92 286 558 93 286 minecraft:white_concrete
fill 558 92 288 558 93 288 minecraft:white_concrete
fill 558 92 290 558 93 290 minecraft:white_concrete
fill 558 92 317 558 99 317 minecraft:brown_terracotta
setblock 559 92 275 minecraft:white_concrete
fill 559 92 276 559 99 276 minecraft:brown_terracotta
fill 559 92 277 559 92 278 minecraft:shroomlight
setblock 559 92 279 minecraft:white_concrete
fill 559 92 280 559 99 280 minecraft:brown_terracotta
fill 559 92 282 559 99 282 minecraft:brown_terracotta
setblock 559 92 283 minecraft:white_concrete
fill 559 92 284 559 99 284 minecraft:brown_terracotta
fill 559 92 286 559 99 286 minecraft:brown_terracotta
setblock 559 92 287 minecraft:white_concrete
fill 559 92 288 559 99 288 minecraft:brown_terracotta
fill 559 92 289 559 92 290 minecraft:shroomlight
setblock 559 92 291 minecraft:white_concrete
fill 559 92 292 559 99 292 minecraft:brown_terracotta
fill 559 92 294 559 99 294 minecraft:brown_terracotta
setblock 559 92 295 minecraft:white_concrete
fill 559 92 296 559 99 296 minecraft:brown_terracotta
fill 559 92 298 559 99 298 minecraft:brown_terracotta
setblock 559 92 299 minecraft:white_concrete
fill 559 92 300 559 99 300 minecraft:brown_terracotta
fill 559 92 301 559 92 302 minecraft:shroomlight
setblock 559 92 303 minecraft:white_concrete
fill 559 92 304 559 99 304 minecraft:brown_terracotta
fill 559 92 306 559 99 306 minecraft:brown_terracotta
setblock 559 92 307 minecraft:white_concrete
fill 559 92 308 559 99 308 minecraft:brown_terracotta
fill 559 92 310 559 99 310 minecraft:brown_terracotta
setblock 559 92 311 minecraft:white_concrete
fill 559 92 312 559 99 312 minecraft:brown_terracotta
fill 559 92 313 559 92 314 minecraft:shroomlight
setblock 559 92 315 minecraft:white_concrete
fill 559 92 316 559 99 316 minecraft:brown_terracotta
fill 517 93 275 517 100 275 minecraft:brown_terracotta
fill 517 93 279 517 100 279 minecraft:brown_terracotta
fill 517 93 282 517 99 283 minecraft:brown_terracotta
fill 517 93 287 517 100 287 minecraft:brown_terracotta
fill 517 93 289 517 96 291 minecraft:shroomlight
fill 517 93 294 517 99 295 minecraft:brown_terracotta
fill 517 93 299 517 100 299 minecraft:brown_terracotta
fill 517 93 303 517 100 303 minecraft:brown_terracotta
fill 517 93 306 517 99 307 minecraft:brown_terracotta
fill 517 93 311 517 100 311 minecraft:brown_terracotta
fill 517 93 315 517 100 315 minecraft:brown_terracotta
fill 517 93 317 519 98 317 minecraft:brown_terracotta
setblock 520 93 292 minecraft:light[level=12]
setblock 520 93 306 minecraft:light[level=12]
setblock 520 93 313 minecraft:light[level=12]
fill 521 93 275 521 100 275 minecraft:brown_terracotta
fill 521 93 290 521 93 292 minecraft:red_concrete
fill 521 93 317 521 100 317 minecraft:brown_terracotta
fill 525 93 275 526 99 275 minecraft:brown_terracotta
fill 525 93 317 525 100 317 minecraft:brown_terracotta
setblock 527 93 278 minecraft:light[level=12]
setblock 527 93 285 minecraft:light[level=12]
setblock 527 93 292 minecraft:light[level=12]
setblock 527 93 299 minecraft:light[level=12]
fill 527 93 304 529 94 304 minecraft:white_concrete
setblock 527 93 306 minecraft:light[level=12]
fill 528 93 303 528 94 303 minecraft:white_concrete
fill 528 93 305 528 94 305 minecraft:white_concrete
fill 529 93 275 529 100 275 minecraft:brown_terracotta
fill 529 93 317 531 98 317 minecraft:brown_terracotta
fill 533 93 275 533 100 275 minecraft:brown_terracotta
fill 533 93 283 533 100 283 minecraft:brown_terracotta
fill 533 93 286 535 100 286 minecraft:brown_terracotta
fill 533 93 317 533 100 317 minecraft:brown_terracotta
setblock 534 93 278 minecraft:light[level=12]
setblock 534 93 292 minecraft:light[level=12]
setblock 534 93 299 minecraft:light[level=12]
setblock 534 93 306 minecraft:light[level=12]
fill 535 93 283 535 100 283 minecraft:brown_terracotta
fill 537 93 275 538 99 275 minecraft:brown_terracotta
fill 537 93 317 537 100 317 minecraft:brown_terracotta
fill 541 93 275 541 100 275 minecraft:brown_terracotta
setblock 541 93 285 minecraft:light[level=12]
setblock 541 93 292 minecraft:light[level=12]
setblock 541 93 299 minecraft:light[level=12]
setblock 541 93 306 minecraft:light[level=12]
setblock 541 93 313 minecraft:light[level=12]
fill 541 93 317 543 98 317 minecraft:brown_terracotta
fill 545 93 275 545 100 275 minecraft:brown_terracotta
fill 545 93 317 545 100 317 minecraft:brown_terracotta
setblock 548 93 278 minecraft:light[level=12]
setblock 548 93 285 minecraft:light[level=12]
setblock 548 93 292 minecraft:light[level=12]
setblock 548 93 299 minecraft:light[level=12]
setblock 548 93 306 minecraft:light[level=12]
setblock 548 93 313 minecraft:light[level=12]
fill 549 93 275 550 99 275 minecraft:brown_terracotta
fill 549 93 317 549 100 317 minecraft:brown_terracotta
fill 553 93 275 553 100 275 minecraft:brown_terracotta
fill 553 93 317 555 98 317 minecraft:brown_terracotta
setblock 555 93 278 minecraft:light[level=12]
setblock 555 93 292 minecraft:light[level=12]
setblock 555 93 299 minecraft:light[level=12]
setblock 555 93 306 minecraft:light[level=12]
fill 557 93 275 557 100 275 minecraft:brown_terracotta
fill 557 93 317 557 100 317 minecraft:brown_terracotta
fill 559 93 275 559 98 275 minecraft:brown_terracotta
fill 559 93 277 559 98 279 minecraft:brown_terracotta
fill 559 93 283 559 100 283 minecraft:brown_terracotta
fill 559 93 287 559 100 287 minecraft:brown_terracotta
fill 559 93 289 559 98 291 minecraft:brown_terracotta
fill 559 93 295 559 100 295 minecraft:brown_terracotta
fill 559 93 299 559 100 299 minecraft:brown_terracotta
fill 559 93 301 559 98 303 minecraft:brown_terracotta
fill 559 93 307 559 100 307 minecraft:brown_terracotta
fill 559 93 311 559 100 311 minecraft:brown_terracotta
fill 559 93 313 559 98 315 minecraft:brown_terracotta
setblock 518 94 294 minecraft:shroomlight
setblock 518 94 296 minecraft:shroomlight
setblock 518 94 298 minecraft:shroomlight
setblock 518 94 300 minecraft:shroomlight
setblock 518 94 302 minecraft:shroomlight
setblock 518 94 304 minecraft:shroomlight
setblock 519 94 293 minecraft:shroomlight
setblock 519 94 295 minecraft:shroomlight
setblock 519 94 297 minecraft:shroomlight
setblock 519 94 299 minecraft:shroomlight
setblock 519 94 301 minecraft:shroomlight
setblock 519 94 303 minecraft:shroomlight
setblock 519 94 305 minecraft:shroomlight
setblock 520 94 294 minecraft:shroomlight
setblock 520 94 296 minecraft:shroomlight
setblock 520 94 298 minecraft:shroomlight
setblock 520 94 300 minecraft:shroomlight
setblock 520 94 302 minecraft:shroomlight
setblock 520 94 304 minecraft:shroomlight
setblock 521 94 290 minecraft:white_concrete
setblock 521 94 293 minecraft:shroomlight
setblock 521 94 295 minecraft:shroomlight
setblock 521 94 297 minecraft:shroomlight
setblock 521 94 299 minecraft:shroomlight
setblock 521 94 301 minecraft:shroomlight
setblock 521 94 303 minecraft:shroomlight
setblock 521 94 305 minecraft:shroomlight
setblock 522 94 294 minecraft:shroomlight
setblock 522 94 296 minecraft:shroomlight
setblock 522 94 298 minecraft:shroomlight
setblock 522 94 300 minecraft:shroomlight
setblock 522 94 302 minecraft:shroomlight
setblock 522 94 304 minecraft:shroomlight
setblock 523 94 293 minecraft:shroomlight
setblock 523 94 295 minecraft:shroomlight
setblock 523 94 297 minecraft:shroomlight
setblock 523 94 299 minecraft:shroomlight
setblock 523 94 301 minecraft:shroomlight
setblock 523 94 303 minecraft:shroomlight
setblock 523 94 305 minecraft:shroomlight
setblock 524 94 294 minecraft:shroomlight
setblock 524 94 296 minecraft:shroomlight
setblock 524 94 298 minecraft:shroomlight
setblock 524 94 300 minecraft:shroomlight
setblock 524 94 302 minecraft:shroomlight
setblock 524 94 304 minecraft:shroomlight
setblock 525 94 293 minecraft:shroomlight
setblock 525 94 295 minecraft:shroomlight
setblock 525 94 297 minecraft:shroomlight
setblock 525 94 299 minecraft:shroomlight
setblock 525 94 301 minecraft:shroomlight
setblock 525 94 303 minecraft:shroomlight
setblock 525 94 305 minecraft:shroomlight
setblock 526 94 294 minecraft:shroomlight
setblock 526 94 300 minecraft:shroomlight
setblock 526 94 302 minecraft:shroomlight
setblock 526 94 304 minecraft:shroomlight
fill 532 94 284 532 100 285 minecraft:brown_terracotta
fill 534 94 282 534 100 282 minecraft:brown_terracotta
fill 536 94 283 536 100 285 minecraft:brown_terracotta
fill 541 94 277 545 94 282 minecraft:red_concrete
fill 542 94 276 544 152 276 minecraft:white_concrete
setblock 549 94 309 minecraft:shroomlight
setblock 549 94 311 minecraft:shroomlight
setblock 549 94 313 minecraft:shroomlight
setblock 549 94 315 minecraft:shroomlight
setblock 550 94 310 minecraft:shroomlight
setblock 550 94 312 minecraft:shroomlight
setblock 550 94 314 minecraft:shroomlight
setblock 550 94 316 minecraft:shroomlight
setblock 551 94 283 minecraft:shroomlight
setblock 551 94 285 minecraft:shroomlight
setblock 551 94 287 minecraft:shroomlight
setblock 551 94 289 minecraft:shroomlight
setblock 551 94 309 minecraft:shroomlight
setblock 551 94 311 minecraft:shroomlight
setblock 551 94 313 minecraft:shroomlight
setblock 551 94 315 minecraft:shroomlight
setblock 552 94 282 minecraft:shroomlight
setblock 552 94 284 minecraft:shroomlight
setblock 552 94 286 minecraft:shroomlight
setblock 552 94 288 minecraft:shroomlight
setblock 552 94 290 minecraft:shroomlight
setblock 552 94 310 minecraft:shroomlight
setblock 552 94 312 minecraft:shroomlight
setblock 552 94 314 minecraft:shroomlight
setblock 552 94 316 minecraft:shroomlight
setblock 553 94 283 minecraft:shroomlight
setblock 553 94 285 minecraft:shroomlight
setblock 553 94 287 minecraft:shroomlight
setblock 553 94 289 minecraft:shroomlight
setblock 553 94 309 minecraft:shroomlight
setblock 553 94 311 minecraft:shroomlight
setblock 553 94 313 minecraft:shroomlight
setblock 553 94 315 minecraft:shroomlight
setblock 554 94 282 minecraft:shroomlight
setblock 554 94 284 minecraft:shroomlight
setblock 554 94 286 minecraft:shroomlight
setblock 554 94 288 minecraft:shroomlight
setblock 554 94 290 minecraft:shroomlight
setblock 554 94 310 minecraft:shroomlight
setblock 554 94 312 minecraft:shroomlight
setblock 554 94 314 minecraft:shroomlight
setblock 554 94 316 minecraft:shroomlight
setblock 555 94 283 minecraft:shroomlight
setblock 555 94 285 minecraft:shroomlight
setblock 555 94 287 minecraft:shroomlight
setblock 555 94 289 minecraft:shroomlight
setblock 555 94 309 minecraft:shroomlight
setblock 555 94 311 minecraft:shroomlight
setblock 555 94 313 minecraft:shroomlight
setblock 555 94 315 minecraft:shroomlight
setblock 556 94 282 minecraft:shroomlight
setblock 556 94 284 minecraft:shroomlight
setblock 556 94 286 minecraft:shroomlight
setblock 556 94 288 minecraft:shroomlight
setblock 556 94 290 minecraft:shroomlight
setblock 557 94 283 minecraft:shroomlight
setblock 557 94 285 minecraft:shroomlight
setblock 557 94 287 minecraft:shroomlight
setblock 557 94 289 minecraft:shroomlight
setblock 558 94 282 minecraft:shroomlight
setblock 558 94 284 minecraft:shroomlight
setblock 558 94 286 minecraft:shroomlight
setblock 558 94 288 minecraft:shroomlight
setblock 558 94 290 minecraft:shroomlight
fill 518 95 294 518 97 294 minecraft:white_concrete
fill 518 95 296 518 97 296 minecraft:white_concrete
fill 518 95 298 518 152 298 minecraft:white_concrete
fill 518 95 300 518 152 300 minecraft:white_concrete
fill 518 95 302 518 97 302 minecraft:white_concrete
fill 518 95 304 518 97 304 minecraft:white_concrete
fill 519 95 293 519 97 293 minecraft:white_concrete
fill 519 95 295 519 97 295 minecraft:white_concrete
fill 519 95 297 519 97 297 minecraft:white_concrete
fill 519 95 299 519 97 299 minecraft:white_concrete
fill 519 95 301 519 97 301 minecraft:white_concrete
fill 519 95 303 519 97 303 minecraft:white_concrete
fill 519 95 305 519 97 305 minecraft:white_concrete
fill 520 95 294 520 97 294 minecraft:white_concrete
fill 520 95 296 520 97 296 minecraft:white_concrete
fill 520 95 298 520 97 298 minecraft:white_concrete
fill 520 95 300 520 97 300 minecraft:white_concrete
fill 520 95 302 520 97 302 minecraft:white_concrete
fill 520 95 304 520 97 304 minecraft:white_concrete
fill 521 95 293 521 97 293 minecraft:white_concrete
fill 521 95 295 521 97 295 minecraft:white_concrete
fill 521 95 297 521 97 297 minecraft:white_concrete
fill 521 95 299 521 97 299 minecraft:white_concrete
fill 521 95 301 521 97 301 minecraft:white_concrete
fill 521 95 303 521 97 303 minecraft:white_concrete
fill 521 95 305 521 97 305 minecraft:white_concrete
fill 522 95 294 522 97 294 minecraft:white_concrete
fill 522 95 296 522 97 296 minecraft:white_concrete
fill 522 95 298 522 97 298 minecraft:white_concrete
fill 522 95 300 522 97 300 minecraft:white_concrete
fill 522 95 302 522 97 302 minecraft:white_concrete
fill 522 95 304 522 97 304 minecraft:white_concrete
fill 523 95 293 523 97 293 minecraft:white_concrete
fill 523 95 295 523 97 295 minecraft:white_concrete
fill 523 95 297 523 97 297 minecraft:white_concrete
fill 523 95 299 523 97 299 minecraft:white_concrete
fill 523 95 301 523 97 301 minecraft:white_concrete
fill 523 95 303 523 97 303 minecraft:white_concrete
fill 523 95 305 523 97 305 minecraft:white_concrete
fill 524 95 294 524 97 294 minecraft:white_concrete
fill 524 95 296 524 97 296 minecraft:white_concrete
fill 524 95 298 524 97 298 minecraft:white_concrete
fill 524 95 300 524 97 300 minecraft:white_concrete
fill 524 95 302 524 97 302 minecraft:white_concrete
fill 524 95 304 524 97 304 minecraft:white_concrete
fill 525 95 293 525 97 293 minecraft:white_concrete
fill 525 95 295 525 97 295 minecraft:white_concrete
fill 525 95 297 525 97 297 minecraft:white_concrete
fill 525 95 299 525 97 299 minecraft:white_concrete
fill 525 95 301 525 97 301 minecraft:white_concrete
fill 525 95 303 525 97 303 minecraft:white_concrete
fill 525 95 305 525 97 305 minecraft:white_concrete
fill 526 95 294 526 97 294 minecraft:white_concrete
fill 526 95 300 526 97 300 minecraft:white_concrete
fill 526 95 302 526 97 302 minecraft:white_concrete
fill 526 95 304 526 97 304 minecraft:white_concrete
fill 532 95 283 532 100 283 minecraft:brown_terracotta
fill 532 95 286 532 100 286 minecraft:brown_terracotta
fill 533 95 282 533 100 282 minecraft:brown_terracotta
fill 533 95 287 535 100 287 minecraft:brown_terracotta
fill 535 95 282 535 100 282 minecraft:brown_terracotta
fill 536 95 286 536 100 286 minecraft:brown_terracotta
fill 541 95 280 541 100 280 minecraft:brown_terracotta
fill 542 95 278 544 95 281 minecraft:red_concrete
fill 549 95 309 549 96 309 minecraft:white_concrete
fill 549 95 311 549 96 311 minecraft:white_concrete
fill 549 95 313 549 96 313 minecraft:white_concrete
fill 549 95 315 549 96 315 minecraft:white_concrete
fill 550 95 310 550 96 310 minecraft:white_concrete
fill 550 95 312 550 96 312 minecraft:white_concrete
fill 550 95 314 550 96 314 minecraft:white_concrete
fill 550 95 316 550 96 316 minecraft:white_concrete
fill 551 95 283 551 96 283 minecraft:white_concrete
fill 551 95 285 551 96 285 minecraft:white_concrete
fill 551 95 287 551 96 287 minecraft:white_concrete
fill 551 95 289 551 96 289 minecraft:white_concrete
fill 551 95 309 551 96 309 minecraft:white_concrete
fill 551 95 311 551 96 311 minecraft:white_concrete
fill 551 95 313 551 96 313 minecraft:white_concrete
fill 551 95 315 551 96 315 minecraft:white_concrete
fill 552 95 282 552 96 282 minecraft:white_concrete
fill 552 95 284 552 96 284 minecraft:white_concrete
fill 552 95 286 552 96 286 minecraft:white_concrete
fill 552 95 288 552 96 288 minecraft:white_concrete
fill 552 95 290 552 96 290 minecraft:white_concrete
fill 552 95 310 552 96 310 minecraft:white_concrete
fill 552 95 312 552 96 312 minecraft:white_concrete
fill 552 95 314 552 96 314 minecraft:white_concrete
fill 552 95 316 552 96 316 minecraft:white_concrete
fill 553 95 283 553 96 283 minecraft:white_concrete
fill 553 95 285 553 96 285 minecraft:white_concrete
fill 553 95 287 553 96 287 minecraft:white_concrete
fill 553 95 289 553 96 289 minecraft:white_concrete
fill 553 95 309 553 96 309 minecraft:white_concrete
fill 553 95 311 553 96 311 minecraft:white_concrete
fill 553 95 313 553 96 313 minecraft:white_concrete
fill 553 95 315 553 96 315 minecraft:white_concrete
fill 554 95 282 554 96 282 minecraft:white_concrete
fill 554 95 284 554 96 284 minecraft:white_concrete
fill 554 95 286 554 96 286 minecraft:white_concrete
fill 554 95 288 554 96 288 minecraft:white_concrete
fill 554 95 290 554 96 290 minecraft:white_concrete
fill 554 95 310 554 96 310 minecraft:white_concrete
fill 554 95 312 554 96 312 minecraft:white_concrete
fill 554 95 314 554 96 314 minecraft:white_concrete
fill 554 95 316 554 96 316 minecraft:white_concrete
fill 555 95 283 555 96 283 minecraft:white_concrete
fill 555 95 285 555 96 285 minecraft:white_concrete
fill 555 95 287 555 96 287 minecraft:white_concrete
fill 555 95 289 555 96 289 minecraft:white_concrete
fill 555 95 309 555 96 309 minecraft:white_concrete
fill 555 95 311 555 96 311 minecraft:white_concrete
fill 555 95 313 555 96 313 minecraft:white_concrete
fill 555 95 315 555 96 315 minecraft:white_concrete
fill 556 95 282 556 96 282 minecraft:white_concrete
fill 556 95 284 556 96 284 minecraft:white_concrete
fill 556 95 286 556 96 286 minecraft:white_concrete
fill 556 95 288 556 96 288 minecraft:white_concrete
fill 556 95 290 556 96 290 minecraft:white_concrete
fill 557 95 283 557 96 283 minecraft:white_concrete
fill 557 95 285 557 96 285 minecraft:white_concrete
fill 557 95 287 557 96 287 minecraft:white_concrete
fill 557 95 289 557 96 289 minecraft:white_concrete
fill 558 95 282 558 96 282 minecraft:white_concrete
fill 558 95 284 558 96 284 minecraft:white_concrete
fill 558 95 286 558 96 286 minecraft:white_concrete
fill 558 95 288 558 96 288 minecraft:white_concrete
fill 558 95 290 558 96 290 minecraft:white_concrete
fill 526 96 299 526 97 299 minecraft:white_concrete
fill 531 96 283 531 100 285 minecraft:brown_terracotta
fill 532 96 282 532 100 282 minecraft:brown_terracotta
fill 532 96 287 532 100 287 minecraft:brown_terracotta
fill 536 96 282 536 100 282 minecraft:brown_terracotta
fill 536 96 287 536 100 287 minecraft:brown_terracotta
fill 537 96 283 537 100 286 minecraft:brown_terracotta
fill 541 96 279 542 96 279 minecraft:brown_terracotta
fill 541 96 281 543 100 281 minecraft:brown_terracotta
setblock 542 96 280 minecraft:brown_terracotta
fill 542 96 282 542 100 282 minecraft:brown_terracotta
fill 543 96 279 543 97 280 minecraft:red_concrete
fill 517 97 289 517 98 291 minecraft:brown_terracotta
fill 518 97 276 520 152 276 minecraft:white_concrete
fill 518 97 286 518 152 288 minecraft:white_concrete
fill 519 97 278 522 97 288 minecraft:red_concrete
fill 531 97 282 531 100 282 minecraft:brown_terracotta
fill 531 97 286 531 100 286 minecraft:brown_terracotta
fill 533 97 281 535 100 281 minecraft:brown_terracotta
fill 533 97 288 535 100 288 minecraft:brown_terracotta
fill 537 97 282 537 100 282 minecraft:brown_terracotta
fill 540 97 280 540 100 280 minecraft:brown_terracotta
fill 541 97 279 541 100 279 minecraft:brown_terracotta
fill 541 97 282 541 100 282 minecraft:brown_terracotta
fill 542 97 278 542 100 278 minecraft:brown_terracotta
fill 542 97 279 542 97 280 minecraft:red_concrete
fill 543 97 282 543 100 282 minecraft:brown_terracotta
fill 544 97 279 544 97 280 minecraft:red_concrete
fill 544 97 281 544 100 281 minecraft:brown_terracotta
setblock 549 97 309 minecraft:shroomlight
setblock 549 97 311 minecraft:shroomlight
setblock 549 97 313 minecraft:shroomlight
setblock 549 97 315 minecraft:shroomlight
setblock 550 97 310 minecraft:shroomlight
setblock 550 97 312 minecraft:shroomlight
setblock 550 97 314 minecraft:shroomlight
setblock 550 97 316 minecraft:shroomlight
setblock 551 97 283 minecraft:shroomlight
setblock 551 97 285 minecraft:shroomlight
setblock 551 97 287 minecraft:shroomlight
setblock 551 97 289 minecraft:shroomlight
setblock 551 97 309 minecraft:shroomlight
setblock 551 97 311 minecraft:shroomlight
setblock 551 97 313 minecraft:shroomlight
setblock 551 97 315 minecraft:shroomlight
setblock 552 97 282 minecraft:shroomlight
setblock 552 97 284 minecraft:shroomlight
setblock 552 97 286 minecraft:shroomlight
setblock 552 97 288 minecraft:shroomlight
setblock 552 97 290 minecraft:shroomlight
setblock 552 97 310 minecraft:shroomlight
setblock 552 97 312 minecraft:shroomlight
setblock 552 97 314 minecraft:shroomlight
setblock 552 97 316 minecraft:shroomlight
setblock 553 97 283 minecraft:shroomlight
setblock 553 97 285 minecraft:shroomlight
setblock 553 97 287 minecraft:shroomlight
setblock 553 97 289 minecraft:shroomlight
setblock 553 97 309 minecraft:shroomlight
setblock 553 97 311 minecraft:shroomlight
setblock 553 97 313 minecraft:shroomlight
setblock 553 97 315 minecraft:shroomlight
setblock 554 97 282 minecraft:shroomlight
setblock 554 97 284 minecraft:shroomlight
setblock 554 97 286 minecraft:shroomlight
setblock 554 97 288 minecraft:shroomlight
setblock 554 97 290 minecraft:shroomlight
setblock 554 97 310 minecraft:shroomlight
setblock 554 97 312 minecraft:shroomlight
setblock 554 97 314 minecraft:shroomlight
setblock 554 97 316 minecraft:shroomlight
setblock 555 97 283 minecraft:shroomlight
setblock 555 97 285 minecraft:shroomlight
setblock 555 97 287 minecraft:shroomlight
setblock 555 97 289 minecraft:shroomlight
setblock 555 97 309 minecraft:shroomlight
setblock 555 97 311 minecraft:shroomlight
setblock 555 97 313 minecraft:shroomlight
setblock 555 97 315 minecraft:shroomlight
setblock 556 97 282 minecraft:shroomlight
setblock 556 97 284 minecraft:shroomlight
setblock 556 97 286 minecraft:shroomlight
setblock 556 97 288 minecraft:shroomlight
setblock 556 97 290 minecraft:shroomlight
setblock 557 97 283 minecraft:shroomlight
setblock 557 97 285 minecraft:shroomlight
setblock 557 97 287 minecraft:shroomlight
setblock 557 97 289 minecraft:shroomlight
setblock 558 97 282 minecraft:shroomlight
setblock 558 97 284 minecraft:shroomlight
setblock 558 97 286 minecraft:shroomlight
setblock 558 97 288 minecraft:shroomlight
setblock 558 97 290 minecraft:shroomlight
fill 519 98 294 525 98 304 minecraft:red_concrete
fill 520 98 279 521 98 287 minecraft:red_concrete
fill 530 98 283 530 100 286 minecraft:brown_terracotta
fill 531 98 287 531 100 287 minecraft:brown_terracotta
fill 532 98 281 532 100 281 minecraft:brown_terracotta
fill 532 98 288 532 100 288 minecraft:brown_terracotta
fill 536 98 281 536 100 281 minecraft:brown_terracotta
fill 536 98 288 536 100 288 minecraft:brown_terracotta
fill 537 98 287 537 100 287 minecraft:brown_terracotta
fill 538 98 283 538 100 286 minecraft:brown_terracotta
fill 540 98 279 540 100 279 minecraft:brown_terracotta
fill 540 98 281 540 100 281 minecraft:brown_terracotta
fill 541 98 278 541 100 278 minecraft:brown_terracotta
fill 542 98 279 544 100 280 minecraft:brown_terracotta
fill 543 98 278 543 100 278 minecraft:brown_terracotta
fill 544 98 282 544 100 282 minecraft:brown_terracotta
fill 549 98 309 549 99 309 minecraft:white_concrete
fill 549 98 311 549 99 311 minecraft:white_concrete
fill 549 98 313 549 99 313 minecraft:white_concrete
fill 549 98 315 549 99 315 minecraft:white_concrete
fill 550 98 310 550 99 310 minecraft:white_concrete
fill 550 98 312 550 99 312 minecraft:white_concrete
fill 550 98 314 550 99 314 minecraft:white_concrete
fill 550 98 316 550 99 316 minecraft:white_concrete
fill 551 98 283 551 99 283 minecraft:white_concrete
fill 551 98 285 551 99 285 minecraft:white_concrete
fill 551 98 287 551 99 287 minecraft:white_concrete
fill 551 98 289 551 99 289 minecraft:white_concrete
fill 551 98 309 551 99 309 minecraft:white_concrete
fill 551 98 311 551 99 311 minecraft:white_concrete
fill 551 98 313 551 99 313 minecraft:white_concrete
fill 551 98 315 551 99 315 minecraft:white_concrete
fill 552 98 282 552 99 282 minecraft:white_concrete
fill 552 98 284 552 99 284 minecraft:white_concrete
fill 552 98 286 552 99 286 minecraft:white_concrete
fill 552 98 288 552 99 288 minecraft:white_concrete
fill 552 98 290 552 99 290 minecraft:white_concrete
fill 552 98 310 552 99 310 minecraft:white_concrete
fill 552 98 312 552 99 312 minecraft:white_concrete
fill 552 98 314 552 99 314 minecraft:white_concrete
fill 552 98 316 552 99 316 minecraft:white_concrete
fill 553 98 283 553 99 283 minecraft:white_concrete
fill 553 98 285 553 99 285 minecraft:white_concrete
fill 553 98 287 553 99 287 minecraft:white_concrete
fill 553 98 289 553 99 289 minecraft:white_concrete
fill 553 98 309 553 99 309 minecraft:white_concrete
fill 553 98 311 553 99 311 minecraft:white_concrete
fill 553 98 313 553 99 313 minecraft:white_concrete
fill 553 98 315 553 99 315 minecraft:white_concrete
fill 554 98 282 554 99 282 minecraft:white_concrete
fill 554 98 284 554 99 284 minecraft:white_concrete
fill 554 98 286 554 99 286 minecraft:white_concrete
fill 554 98 288 554 99 288 minecraft:white_concrete
fill 554 98 290 554 99 290 minecraft:white_concrete
fill 554 98 310 554 99 310 minecraft:white_concrete
fill 554 98 312 554 99 312 minecraft:white_concrete
fill 554 98 314 554 99 314 minecraft:white_concrete
fill 554 98 316 554 99 316 minecraft:white_concrete
fill 555 98 283 555 99 283 minecraft:white_concrete
fill 555 98 285 555 99 285 minecraft:white_concrete
fill 555 98 287 555 99 287 minecraft:white_concrete
fill 555 98 289 555 99 289 minecraft:white_concrete
fill 555 98 309 555 99 309 minecraft:white_concrete
fill 555 98 311 555 99 311 minecraft:white_concrete
fill 555 98 313 555 99 313 minecraft:white_concrete
fill 555 98 315 555 99 315 minecraft:white_concrete
fill 556 98 282 556 99 282 minecraft:white_concrete
fill 556 98 284 556 99 284 minecraft:white_concrete
fill 556 98 286 556 99 286 minecraft:white_concrete
fill 556 98 288 556 99 288 minecraft:white_concrete
fill 556 98 290 556 99 290 minecraft:white_concrete
fill 557 98 283 557 99 283 minecraft:white_concrete
fill 557 98 285 557 99 285 minecraft:white_concrete
fill 557 98 287 557 99 287 minecraft:white_concrete
fill 557 98 289 557 99 289 minecraft:white_concrete
fill 558 98 282 558 99 282 minecraft:white_concrete
fill 558 98 284 558 99 284 minecraft:white_concrete
fill 558 98 286 558 99 286 minecraft:white_concrete
fill 558 98 288 558 99 288 minecraft:white_concrete
fill 558 98 290 558 99 290 minecraft:white_concrete
setblock 517 99 277 minecraft:white_concrete
setblock 517 99 280 minecraft:brown_terracotta
setblock 517 99 281 minecraft:white_concrete
setblock 517 99 285 minecraft:white_concrete
setblock 517 99 289 minecraft:white_concrete
fill 517 99 290 517 99 292 minecraft:brown_terracotta
setblock 517 99 293 minecraft:white_concrete
setblock 517 99 297 minecraft:white_concrete
setblock 517 99 301 minecraft:white_concrete
setblock 517 99 304 minecraft:brown_terracotta
setblock 517 99 305 minecraft:white_concrete
setblock 517 99 309 minecraft:white_concrete
setblock 517 99 313 minecraft:white_concrete
setblock 517 99 317 minecraft:white_concrete
setblock 518 99 317 minecraft:brown_terracotta
setblock 519 99 275 minecraft:white_concrete
setblock 519 99 317 minecraft:white_concrete
setblock 520 99 278 minecraft:light[level=15]
fill 520 99 280 521 99 286 minecraft:red_concrete
setblock 520 99 292 minecraft:light[level=12]
setblock 520 99 294 minecraft:light[level=15]
fill 520 99 295 524 99 303 minecraft:red_concrete
setblock 520 99 306 minecraft:light[level=12]
setblock 520 99 310 minecraft:light[level=15]
setblock 520 99 313 minecraft:light[level=12]
setblock 523 99 275 minecraft:white_concrete
setblock 523 99 317 minecraft:white_concrete
setblock 527 99 275 minecraft:white_concrete
setblock 527 99 278 minecraft:light[level=12]
setblock 527 99 285 minecraft:light[level=12]
setblock 527 99 292 minecraft:light[level=12]
setblock 527 99 299 minecraft:light[level=12]
setblock 527 99 306 minecraft:light[level=12]
setblock 527 99 317 minecraft:white_concrete
setblock 528 99 275 minecraft:brown_terracotta
setblock 528 99 278 minecraft:light[level=15]
setblock 528 99 286 minecraft:light[level=15]
setblock 528 99 294 minecraft:light[level=15]
setblock 528 99 302 minecraft:light[level=15]
setblock 528 99 310 minecraft:light[level=15]
fill 529 99 317 530 99 317 minecraft:brown_terracotta
fill 530 99 282 530 100 282 minecraft:brown_terracotta
fill 530 99 287 530 100 287 minecraft:brown_terracotta
setblock 531 99 275 minecraft:white_concrete
fill 531 99 281 531 100 281 minecraft:brown_terracotta
fill 531 99 288 531 100 288 minecraft:brown_terracotta
setblock 531 99 317 minecraft:white_concrete
fill 532 99 280 536 100 280 minecraft:brown_terracotta
fill 533 99 289 535 100 289 minecraft:brown_terracotta
setblock 534 99 278 minecraft:light[level=12]
setblock 534 99 292 minecraft:light[level=12]
setblock 534 99 299 minecraft:light[level=12]
setblock 534 99 306 minecraft:light[level=12]
setblock 535 99 275 minecraft:white_concrete
setblock 535 99 317 minecraft:white_concrete
setblock 536 99 278 minecraft:light[level=15]
setblock 536 99 294 minecraft:light[level=15]
setblock 536 99 302 minecraft:light[level=15]
setblock 536 99 310 minecraft:light[level=15]
fill 537 99 281 537 100 281 minecraft:brown_terracotta
fill 537 99 288 537 100 288 minecraft:brown_terracotta
fill 538 99 282 538 100 282 minecraft:brown_terracotta
fill 538 99 287 538 100 287 minecraft:brown_terracotta
setblock 539 99 275 minecraft:white_concrete
fill 539 99 280 539 100 280 minecraft:brown_terracotta
setblock 539 99 317 minecraft:white_concrete
setblock 540 99 275 minecraft:brown_terracotta
fill 540 99 278 540 100 278 minecraft:brown_terracotta
fill 540 99 282 540 100 282 minecraft:brown_terracotta
fill 541 99 283 543 100 283 minecraft:brown_terracotta
setblock 541 99 285 minecraft:light[level=12]
setblock 541 99 292 minecraft:light[level=12]
setblock 541 99 299 minecraft:light[level=12]
setblock 541 99 306 minecraft:light[level=12]
setblock 541 99 313 minecraft:light[level=12]
fill 541 99 317 542 99 317 minecraft:brown_terracotta
setblock 543 99 275 minecraft:white_concrete
setblock 543 99 317 minecraft:white_concrete
fill 544 99 278 544 100 278 minecraft:brown_terracotta
setblock 544 99 286 minecraft:light[level=15]
setblock 544 99 294 minecraft:light[level=15]
setblock 544 99 302 minecraft:light[level=15]
setblock 544 99 310 minecraft:light[level=15]
fill 545 99 279 545 100 281 minecraft:brown_terracotta
setblock 547 99 275 minecraft:white_concrete
setblock 547 99 317 minecraft:white_concrete
setblock 548 99 278 minecraft:light[level=12]
setblock 548 99 285 minecraft:light[level=12]
setblock 548 99 292 minecraft:light[level=12]
setblock 548 99 299 minecraft:light[level=12]
setblock 548 99 306 minecraft:light[level=12]
setblock 548 99 313 minecraft:light[level=12]
setblock 551 99 275 minecraft:white_concrete
setblock 551 99 317 minecraft:white_concrete
setblock 552 99 275 minecraft:brown_terracotta
setblock 552 99 278 minecraft:light[level=15]
setblock 552 99 294 minecraft:light[level=15]
fill 552 99 296 552 100 296 minecraft:shroomlight
setblock 552 99 302 minecraft:light[level=15]
fill 553 99 317 554 99 317 minecraft:brown_terracotta
setblock 555 99 275 minecraft:white_concrete
setblock 555 99 278 minecraft:light[level=12]
setblock 555 99 292 minecraft:light[level=12]
setblock 555 99 299 minecraft:light[level=12]
setblock 555 99 306 minecraft:light[level=12]
setblock 555 99 317 minecraft:white_concrete
setblock 559 99 275 minecraft:white_concrete
setblock 559 99 277 minecraft:white_concrete
fill 559 99 278 559 99 279 minecraft:brown_terracotta
setblock 559 99 281 minecraft:white_concrete
setblock 559 99 285 minecraft:white_concrete
setblock 559 99 289 minecraft:white_concrete
fill 559 99 290 559 99 291 minecraft:brown_terracotta
setblock 559 99 293 minecraft:white_concrete
setblock 559 99 297 minecraft:white_concrete
setblock 559 99 301 minecraft:white_concrete
fill 559 99 302 559 99 303 minecraft:brown_terracotta
setblock 559 99 305 minecraft:white_concrete
setblock 559 99 309 minecraft:white_concrete
setblock 559 99 313 minecraft:white_concrete
fill 559 99 314 559 99 315 minecraft:brown_terracotta
setblock 559 99 317 minecraft:white_concrete
setblock 517 100 276 minecraft:white_concrete
fill 517 100 277 517 107 277 minecraft:brown_terracotta
setblock 517 100 278 minecraft:white_concrete
setblock 517 100 280 minecraft:white_concrete
fill 517 100 281 517 105 281 minecraft:brown_terracotta
setblock 517 100 282 minecraft:white_concrete
setblock 517 100 283 minecraft:brown_terracotta
setblock 517 100 284 minecraft:white_concrete
fill 517 100 285 517 107 285 minecraft:brown_terracotta
setblock 517 100 286 minecraft:white_concrete
setblock 517 100 288 minecraft:white_concrete
fill 517 100 289 517 107 289 minecraft:brown_terracotta
setblock 517 100 290 minecraft:white_concrete
setblock 517 100 291 minecraft:brown_terracotta
setblock 517 100 292 minecraft:white_concrete
fill 517 100 293 517 105 293 minecraft:brown_terracotta
setblock 517 100 294 minecraft:white_concrete
setblock 517 100 295 minecraft:brown_terracotta
setblock 517 100 296 minecraft:white_concrete
fill 517 100 297 517 107 297 minecraft:brown_terracotta
setblock 517 100 298 minecraft:white_concrete
setblock 517 100 300 minecraft:white_concrete
fill 517 100 301 517 107 301 minecraft:brown_terracotta
setblock 517 100 302 minecraft:white_concrete
setblock 517 100 304 minecraft:white_concrete
fill 517 100 305 517 105 305 minecraft:brown_terracotta
setblock 517 100 306 minecraft:white_concrete
setblock 517 100 307 minecraft:brown_terracotta
setblock 517 100 308 minecraft:white_concrete
fill 517 100 309 517 107 309 minecraft:brown_terracotta
setblock 517 100 310 minecraft:white_concrete
setblock 517 100 312 minecraft:white_concrete
fill 517 100 313 517 107 313 minecraft:brown_terracotta
setblock 517 100 314 minecraft:white_concrete
setblock 517 100 316 minecraft:white_concrete
setblock 517 100 317 minecraft:brown_terracotta
setblock 518 100 275 minecraft:white_concrete
setblock 518 100 317 minecraft:white_concrete
fill 519 100 275 519 107 275 minecraft:brown_terracotta
fill 519 100 281 522 100 284 minecraft:red_concrete
fill 519 100 285 519 105 287 minecraft:white_concrete
fill 519 100 297 519 105 299 minecraft:white_concrete
fill 519 100 309 519 105 311 minecraft:white_concrete
fill 519 100 317 519 105 317 minecraft:brown_terracotta
setblock 520 100 275 minecraft:white_concrete
fill 520 100 285 522 100 285 minecraft:red_concrete
setblock 520 100 317 minecraft:white_concrete
fill 521 100 296 523 100 302 minecraft:red_concrete
setblock 522 100 275 minecraft:white_concrete
setblock 522 100 317 minecraft:white_concrete
fill 523 100 275 523 107 275 minecraft:brown_terracotta
fill 523 100 317 523 107 317 minecraft:brown_terracotta
setblock 524 100 275 minecraft:white_concrete
setblock 524 100 317 minecraft:white_concrete
setblock 525 100 275 minecraft:brown_terracotta
setblock 526 100 275 minecraft:white_concrete
setblock 526 100 317 minecraft:white_concrete
fill 527 100 275 527 105 275 minecraft:brown_terracotta
fill 527 100 317 527 107 317 minecraft:brown_terracotta
setblock 528 100 275 minecraft:white_concrete
setblock 528 100 317 minecraft:white_concrete
fill 529 100 277 531 105 277 minecraft:white_concrete
fill 529 100 283 529 100 286 minecraft:brown_terracotta
setblock 529 100 317 minecraft:brown_terracotta
setblock 530 100 275 minecraft:white_concrete
setblock 530 100 281 minecraft:brown_terracotta
setblock 530 100 317 minecraft:white_concrete
fill 531 100 275 531 107 275 minecraft:brown_terracotta
setblock 531 100 280 minecraft:brown_terracotta
fill 531 100 317 531 105 317 minecraft:brown_terracotta
setblock 532 100 275 minecraft:white_concrete
setblock 532 100 289 minecraft:brown_terracotta
setblock 532 100 317 minecraft:white_concrete
setblock 534 100 275 minecraft:white_concrete
setblock 534 100 317 minecraft:white_concrete
fill 535 100 275 535 107 275 minecraft:brown_terracotta
fill 535 100 317 535 107 317 minecraft:brown_terracotta
setblock 536 100 275 minecraft:white_concrete
setblock 536 100 289 minecraft:brown_terracotta
setblock 536 100 317 minecraft:white_concrete
setblock 537 100 275 minecraft:brown_terracotta
setblock 537 100 280 minecraft:brown_terracotta
fill 537 100 315 539 105 315 minecraft:white_concrete
setblock 538 100 275 minecraft:white_concrete
fill 538 100 281 539 100 281 minecraft:brown_terracotta
setblock 538 100 288 minecraft:brown_terracotta
setblock 538 100 317 minecraft:white_concrete
fill 539 100 275 539 105 275 minecraft:brown_terracotta
setblock 539 100 279 minecraft:brown_terracotta
fill 539 100 282 539 100 286 minecraft:brown_terracotta
fill 539 100 317 539 107 317 minecraft:brown_terracotta
setblock 540 100 275 minecraft:white_concrete
setblock 540 100 283 minecraft:brown_terracotta
setblock 540 100 317 minecraft:white_concrete
fill 541 100 277 543 105 277 minecraft:white_concrete
setblock 541 100 317 minecraft:brown_terracotta
setblock 542 100 275 minecraft:white_concrete
setblock 542 100 317 minecraft:white_concrete
fill 543 100 275 543 107 275 minecraft:brown_terracotta
fill 543 100 317 543 105 317 minecraft:brown_terracotta
setblock 544 100 275 minecraft:white_concrete
setblock 544 100 283 minecraft:brown_terracotta
setblock 544 100 317 minecraft:white_concrete
setblock 545 100 278 minecraft:brown_terracotta
setblock 545 100 282 minecraft:brown_terracotta
setblock 546 100 275 minecraft:white_concrete
setblock 546 100 317 minecraft:white_concrete
fill 547 100 275 547 107 275 minecraft:brown_terracotta
fill 547 100 317 547 107 317 minecraft:brown_terracotta
setblock 548 100 275 minecraft:white_concrete
setblock 548 100 317 minecraft:white_concrete
setblock 549 100 275 minecraft:brown_terracotta
setblock 549 100 309 minecraft:shroomlight
setblock 549 100 311 minecraft:shroomlight
setblock 549 100 313 minecraft:shroomlight
setblock 549 100 315 minecraft:shroomlight
setblock 550 100 275 minecraft:white_concrete
setblock 550 100 310 minecraft:shroomlight
setblock 550 100 312 minecraft:shroomlight
setblock 550 100 314 minecraft:shroomlight
setblock 550 100 316 minecraft:shroomlight
setblock 550 100 317 minecraft:white_concrete
fill 551 100 275 551 105 275 minecraft:brown_terracotta
setblock 551 100 283 minecraft:shroomlight
setblock 551 100 285 minecraft:shroomlight
setblock 551 100 287 minecraft:shroomlight
setblock 551 100 289 minecraft:shroomlight
setblock 551 100 309 minecraft:shroomlight
setblock 551 100 311 minecraft:shroomlight
setblock 551 100 313 minecraft:shroomlight
setblock 551 100 315 minecraft:shroomlight
fill 551 100 317 551 107 317 minecraft:brown_terracotta
setblock 552 100 275 minecraft:white_concrete
setblock 552 100 282 minecraft:shroomlight
setblock 552 100 284 minecraft:shroomlight
setblock 552 100 286 minecraft:shroomlight
setblock 552 100 288 minecraft:shroomlight
setblock 552 100 290 minecraft:shroomlight
setblock 552 100 310 minecraft:shroomlight
setblock 552 100 312 minecraft:shroomlight
setblock 552 100 314 minecraft:shroomlight
setblock 552 100 316 minecraft:shroomlight
setblock 552 100 317 minecraft:white_concrete
fill 553 100 277 555 105 277 minecraft:white_concrete
setblock 553 100 283 minecraft:shroomlight
setblock 553 100 285 minecraft:shroomlight
setblock 553 100 287 minecraft:shroomlight
setblock 553 100 289 minecraft:shroomlight
setblock 553 100 309 minecraft:shroomlight
setblock 553 100 311 minecraft:shroomlight
setblock 553 100 313 minecraft:shroomlight
setblock 553 100 315 minecraft:shroomlight
setblock 553 100 317 minecraft:brown_terracotta
setblock 554 100 275 minecraft:white_concrete
setblock 554 100 282 minecraft:shroomlight
setblock 554 100 284 minecraft:shroomlight
setblock 554 100 286 minecraft:shroomlight
setblock 554 100 288 minecraft:shroomlight
setblock 554 100 290 minecraft:shroomlight
setblock 554 100 310 minecraft:shroomlight
setblock 554 100 312 minecraft:shroomlight
setblock 554 100 314 minecraft:shroomlight
setblock 554 100 316 minecraft:shroomlight
setblock 554 100 317 minecraft:white_concrete
fill 555 100 275 555 107 275 minecraft:brown_terracotta
setblock 555 100 283 minecraft:shroomlight
setblock 555 100 285 minecraft:shroomlight
setblock 555 100 287 minecraft:shroomlight
setblock 555 100 289 minecraft:shroomlight
setblock 555 100 309 minecraft:shroomlight
setblock 555 100 311 minecraft:shroomlight
setblock 555 100 313 minecraft:shroomlight
setblock 555 100 315 minecraft:shroomlight
fill 555 100 317 555 105 317 minecraft:brown_terracotta
setblock 556 100 275 minecraft:white_concrete
setblock 556 100 282 minecraft:shroomlight
setblock 556 100 284 minecraft:shroomlight
setblock 556 100 286 minecraft:shroomlight
setblock 556 100 288 minecraft:shroomlight
setblock 556 100 290 minecraft:shroomlight
setblock 556 100 317 minecraft:white_concrete
setblock 557 100 283 minecraft:shroomlight
setblock 557 100 285 minecraft:shroomlight
setblock 557 100 287 minecraft:shroomlight
setblock 557 100 289 minecraft:shroomlight
fill 557 100 297 557 105 299 minecraft:white_concrete
fill 557 100 309 557 105 311 minecraft:white_concrete
setblock 558 100 275 minecraft:white_concrete
setblock 558 100 282 minecraft:shroomlight
setblock 558 100 284 minecraft:shroomlight
setblock 558 100 286 minecraft:shroomlight
setblock 558 100 288 minecraft:shroomlight
setblock 558 100 290 minecraft:shroomlight
setblock 558 100 317 minecraft:white_concrete
setblock 559 100 275 minecraft:brown_terracotta
setblock 559 100 276 minecraft:white_concrete
fill 559 100 277 559 105 277 minecraft:brown_terracotta
setblock 559 100 278 minecraft:white_concrete
setblock 559 100 279 minecraft:brown_terracotta
setblock 559 100 280 minecraft:white_concrete
fill 559 100 281 559 107 281 minecraft:brown_terracotta
setblock 559 100 282 minecraft:white_concrete
setblock 559 100 284 minecraft:white_concrete
fill 559 100 285 559 107 285 minecraft:brown_terracotta
setblock 559 100 286 minecraft:white_concrete
setblock 559 100 288 minecraft:white_concrete
fill 559 100 289 559 105 289 minecraft:brown_terracotta
setblock 559 100 290 minecraft:white_concrete
setblock 559 100 291 minecraft:brown_terracotta
setblock 559 100 292 minecraft:white_concrete
fill 559 100 293 559 107 293 minecraft:brown_terracotta
setblock 559 100 294 minecraft:white_concrete
setblock 559 100 296 minecraft:white_concrete
fill 559 100 297 559 107 297 minecraft:brown_terracotta
setblock 559 100 298 minecraft:white_concrete
setblock 559 100 300 minecraft:white_concrete
fill 559 100 301 559 105 301 minecraft:brown_terracotta
setblock 559 100 302 minecraft:white_concrete
setblock 559 100 303 minecraft:brown_terracotta
setblock 559 100 304 minecraft:white_concrete
fill 559 100 305 559 107 305 minecraft:brown_terracotta
setblock 559 100 306 minecraft:white_concrete
setblock 559 100 308 minecraft:white_concrete
fill 559 100 309 559 107 309 minecraft:brown_terracotta
setblock 559 100 310 minecraft:white_concrete
setblock 559 100 312 minecraft:white_concrete
fill 559 100 313 559 105 313 minecraft:brown_terracotta
setblock 559 100 314 minecraft:white_concrete
setblock 559 100 315 minecraft:brown_terracotta
setblock 559 100 316 minecraft:white_concrete
fill 559 100 317 559 107 317 minecraft:brown_terracotta
setblock 517 101 275 minecraft:white_concrete
fill 517 101 276 517 108 276 minecraft:brown_terracotta
fill 517 101 278 517 108 278 minecraft:brown_terracotta
setblock 517 101 279 minecraft:white_concrete
fill 517 101 280 517 108 280 minecraft:brown_terracotta
fill 517 101 282 517 105 282 minecraft:brown_terracotta
setblock 517 101 283 minecraft:white_concrete
fill 517 101 284 517 105 284 minecraft:brown_terracotta
fill 517 101 286 517 108 286 minecraft:brown_terracotta
setblock 517 101 287 minecraft:white_concrete
fill 517 101 288 517 108 288 minecraft:brown_terracotta
fill 517 101 290 517 108 290 minecraft:brown_terracotta
setblock 517 101 291 minecraft:white_concrete
fill 517 101 292 517 108 292 minecraft:brown_terracotta
fill 517 101 294 517 105 294 minecraft:brown_terracotta
setblock 517 101 295 minecraft:white_concrete
fill 517 101 296 517 105 296 minecraft:brown_terracotta
fill 517 101 298 517 108 298 minecraft:brown_terracotta
setblock 517 101 299 minecraft:white_concrete
fill 517 101 300 517 108 300 minecraft:brown_terracotta
fill 517 101 302 517 108 302 minecraft:brown_terracotta
setblock 517 101 303 minecraft:white_concrete
fill 517 101 304 517 108 304 minecraft:brown_terracotta
fill 517 101 306 517 105 306 minecraft:brown_terracotta
setblock 517 101 307 minecraft:white_concrete
fill 517 101 308 517 105 308 minecraft:brown_terracotta
fill 517 101 310 517 108 310 minecraft:brown_terracotta
setblock 517 101 311 minecraft:white_concrete
fill 517 101 312 517 108 312 minecraft:brown_terracotta
fill 517 101 314 517 108 314 minecraft:brown_terracotta
setblock 517 101 315 minecraft:white_concrete
fill 517 101 316 517 108 316 minecraft:brown_terracotta
setblock 517 101 317 minecraft:white_concrete
fill 518 101 275 518 108 275 minecraft:brown_terracotta
fill 518 101 317 518 105 317 minecraft:brown_terracotta
fill 520 101 275 520 108 275 minecraft:brown_terracotta
fill 520 101 317 520 105 317 minecraft:brown_terracotta
setblock 521 101 275 minecraft:white_concrete
setblock 521 101 317 minecraft:white_concrete
fill 522 101 275 522 108 275 minecraft:brown_terracotta
fill 522 101 297 522 101 301 minecraft:red_concrete
fill 522 101 317 522 108 317 minecraft:brown_terracotta
fill 524 101 275 524 105 275 minecraft:brown_terracotta
fill 524 101 317 524 108 317 minecraft:brown_terracotta
setblock 525 101 275 minecraft:white_concrete
setblock 525 101 317 minecraft:white_concrete
fill 526 101 275 526 105 275 minecraft:brown_terracotta
fill 526 101 317 526 108 317 minecraft:brown_terracotta
fill 528 101 275 528 108 275 minecraft:brown_terracotta
fill 528 101 317 528 108 317 minecraft:brown_terracotta
setblock 529 101 275 minecraft:white_concrete
setblock 529 101 317 minecraft:white_concrete
fill 530 101 275 530 108 275 minecraft:brown_terracotta
fill 530 101 317 530 105 317 minecraft:brown_terracotta
fill 532 101 275 532 108 275 minecraft:brown_terracotta
fill 532 101 317 532 105 317 minecraft:brown_terracotta
setblock 533 101 275 minecraft:white_concrete
setblock 533 101 317 minecraft:white_concrete
fill 534 101 275 534 108 275 minecraft:brown_terracotta
fill 534 101 284 534 103 285 minecraft:white_concrete
fill 534 101 317 534 108 317 minecraft:brown_terracotta
fill 536 101 275 536 105 275 minecraft:brown_terracotta
fill 536 101 317 536 108 317 minecraft:brown_terracotta
setblock 537 101 275 minecraft:white_concrete
setblock 537 101 317 minecraft:white_concrete
fill 538 101 275 538 105 275 minecraft:brown_terracotta
fill 538 101 317 538 108 317 minecraft:brown_terracotta
fill 540 101 275 540 108 275 minecraft:brown_terracotta
fill 540 101 317 540 108 317 minecraft:brown_terracotta
setblock 541 101 275 minecraft:white_concrete
setblock 541 101 317 minecraft:white_concrete
fill 542 101 275 542 108 275 minecraft:brown_terracotta
fill 542 101 280 542 104 280 minecraft:white_concrete
fill 542 101 317 542 105 317 minecraft:brown_terracotta
fill 544 101 275 544 108 275 minecraft:brown_terracotta
fill 544 101 317 544 105 317 minecraft:brown_terracotta
setblock 545 101 275 minecraft:white_concrete
setblock 545 101 317 minecraft:white_concrete
fill 546 101 275 546 108 275 minecraft:brown_terracotta
fill 546 101 317 546 108 317 minecraft:brown_terracotta
fill 548 101 275 548 105 275 minecraft:brown_terracotta
fill 548 101 317 548 108 317 minecraft:brown_terracotta
setblock 549 101 275 minecraft:white_concrete
fill 549 101 309 549 103 309 minecraft:white_concrete
fill 549 101 311 549 103 311 minecraft:white_concrete
fill 549 101 313 549 103 313 minecraft:white_concrete
fill 549 101 315 549 105 315 minecraft:white_concrete
setblock 549 101 317 minecraft:white_concrete
fill 550 101 275 550 105 275 minecraft:brown_terracotta
fill 550 101 310 550 103 310 minecraft:white_concrete
fill 550 101 312 550 103 312 minecraft:white_concrete
fill 550 101 314 550 103 314 minecraft:white_concrete
fill 550 101 316 550 152 316 minecraft:white_concrete
fill 550 101 317 550 108 317 minecraft:brown_terracotta
fill 551 101 283 551 102 283 minecraft:white_concrete
fill 551 101 285 551 102 285 minecraft:white_concrete
fill 551 101 287 551 102 287 minecraft:white_concrete
fill 551 101 289 551 102 289 minecraft:white_concrete
fill 551 101 309 551 103 309 minecraft:white_concrete
fill 551 101 311 551 103 311 minecraft:white_concrete
fill 551 101 313 551 103 313 minecraft:white_concrete
fill 551 101 315 551 105 315 minecraft:white_concrete
fill 552 101 275 552 108 275 minecraft:brown_terracotta
fill 552 101 282 552 102 282 minecraft:white_concrete
fill 552 101 284 552 102 284 minecraft:white_concrete
fill 552 101 286 552 102 286 minecraft:white_concrete
fill 552 101 288 552 102 288 minecraft:white_concrete
fill 552 101 290 552 102 290 minecraft:white_concrete
fill 552 101 296 552 110 296 minecraft:brown_terracotta
fill 552 101 310 552 103 310 minecraft:white_concrete
fill 552 101 312 552 103 312 minecraft:white_concrete
fill 552 101 314 552 103 314 minecraft:white_concrete
fill 552 101 316 552 103 316 minecraft:white_concrete
fill 552 101 317 552 108 317 minecraft:brown_terracotta
setblock 553 101 275 minecraft:white_concrete
fill 553 101 283 553 102 283 minecraft:white_concrete
fill 553 101 285 553 102 285 minecraft:white_concrete
fill 553 101 287 553 102 287 minecraft:white_concrete
fill 553 101 289 553 102 289 minecraft:white_concrete
fill 553 101 309 553 103 309 minecraft:white_concrete
fill 553 101 311 553 103 311 minecraft:white_concrete
fill 553 101 313 553 103 313 minecraft:white_concrete
fill 553 101 315 553 103 315 minecraft:white_concrete
setblock 553 101 317 minecraft:white_concrete
fill 554 101 275 554 108 275 minecraft:brown_terracotta
fill 554 101 282 554 102 282 minecraft:white_concrete
fill 554 101 284 554 102 284 minecraft:white_concrete
fill 554 101 286 554 102 286 minecraft:white_concrete
fill 554 101 288 554 102 288 minecraft:white_concrete
fill 554 101 290 554 102 290 minecraft:white_concrete
fill 554 101 310 554 103 310 minecraft:white_concrete
fill 554 101 312 554 103 312 minecraft:white_concrete
fill 554 101 314 554 103 314 minecraft:white_concrete
fill 554 101 316 554 103 316 minecraft:white_concrete
fill 554 101 317 554 105 317 minecraft:brown_terracotta
fill 555 101 283 555 102 283 minecraft:white_concrete
fill 555 101 285 555 102 285 minecraft:white_concrete
fill 555 101 287 555 102 287 minecraft:white_concrete
fill 555 101 289 555 102 289 minecraft:white_concrete
fill 555 101 309 555 103 309 minecraft:white_concrete
fill 555 101 311 555 103 311 minecraft:white_concrete
fill 555 101 313 555 103 313 minecraft:white_concrete
fill 555 101 315 555 103 315 minecraft:white_concrete
fill 556 101 275 556 108 275 minecraft:brown_terracotta
fill 556 101 282 556 102 282 minecraft:white_concrete
fill 556 101 284 556 102 284 minecraft:white_concrete
fill 556 101 286 556 102 286 minecraft:white_concrete
fill 556 101 288 556 102 288 minecraft:white_concrete
fill 556 101 290 556 102 290 minecraft:white_concrete
fill 556 101 317 556 105 317 minecraft:brown_terracotta
setblock 557 101 275 minecraft:white_concrete
fill 557 101 283 557 102 283 minecraft:white_concrete
fill 557 101 285 557 105 285 minecraft:white_concrete
fill 557 101 287 557 105 287 minecraft:white_concrete
fill 557 101 289 557 102 289 minecraft:white_concrete
setblock 557 101 317 minecraft:white_concrete
fill 558 101 275 558 108 275 minecraft:brown_terracotta
fill 558 101 282 558 102 282 minecraft:white_concrete
fill 558 101 284 558 152 284 minecraft:white_concrete
fill 558 101 286 558 152 286 minecraft:white_concrete
fill 558 101 288 558 102 288 minecraft:white_concrete
fill 558 101 290 558 102 290 minecraft:white_concrete
fill 558 101 317 558 108 317 minecraft:brown_terracotta
setblock 559 101 275 minecraft:white_concrete
fill 559 101 276 559 105 276 minecraft:brown_terracotta
fill 559 101 278 559 105 278 minecraft:brown_terracotta
setblock 559 101 279 minecraft:white_concrete
fill 559 101 280 559 108 280 minecraft:brown_terracotta
fill 559 101 282 559 108 282 minecraft:brown_terracotta
setblock 559 101 283 minecraft:white_concrete
fill 559 101 284 559 108 284 minecraft:brown_terracotta
fill 559 101 286 559 108 286 minecraft:brown_terracotta
setblock 559 101 287 minecraft:white_concrete
fill 559 101 288 559 105 288 minecraft:brown_terracotta
fill 559 101 290 559 105 290 minecraft:brown_terracotta
setblock 559 101 291 minecraft:white_concrete
fill 559 101 292 559 108 292 minecraft:brown_terracotta
fill 559 101 294 559 108 294 minecraft:brown_terracotta
setblock 559 101 295 minecraft:white_concrete
fill 559 101 296 559 108 296 minecraft:brown_terracotta
fill 559 101 298 559 108 298 minecraft:brown_terracotta
setblock 559 101 299 minecraft:white_concrete
fill 559 101 300 559 105 300 minecraft:brown_terracotta
fill 559 101 302 559 105 302 minecraft:brown_terracotta
setblock 559 101 303 minecraft:white_concrete
fill 559 101 304 559 108 304 minecraft:brown_terracotta
fill 559 101 306 559 108 306 minecraft:brown_terracotta
setblock 559 101 307 minecraft:white_concrete
fill 559 101 308 559 108 308 minecraft:brown_terracotta
fill 559 101 310 559 108 310 minecraft:brown_terracotta
setblock 559 101 311 minecraft:white_concrete
fill 559 101 312 559 105 312 minecraft:brown_terracotta
fill 559 101 314 559 105 314 minecraft:brown_terracotta
setblock 559 101 315 minecraft:white_concrete
fill 559 101 316 559 108 316 minecraft:brown_terracotta
fill 517 102 275 517 109 275 minecraft:brown_terracotta
fill 517 102 279 517 109 279 minecraft:brown_terracotta
fill 517 102 283 517 105 283 minecraft:brown_terracotta
fill 517 102 287 517 109 287 minecraft:brown_terracotta
fill 517 102 291 517 109 291 minecraft:brown_terracotta
fill 517 102 295 517 105 295 minecraft:brown_terracotta
fill 517 102 299 517 109 299 minecraft:brown_terracotta
fill 517 102 303 517 109 303 minecraft:brown_terracotta
fill 517 102 307 517 105 307 minecraft:brown_terracotta
fill 517 102 311 517 109 311 minecraft:brown_terracotta
fill 517 102 315 517 109 315 minecraft:brown_terracotta
fill 517 102 317 517 105 317 minecraft:brown_terracotta
fill 521 102 275 521 109 275 minecraft:brown_terracotta
fill 521 102 317 521 109 317 minecraft:brown_terracotta
fill 525 102 275 525 105 275 minecraft:brown_terracotta
fill 525 102 317 525 109 317 minecraft:brown_terracotta
fill 529 102 275 529 109 275 minecraft:brown_terracotta
fill 529 102 317 529 105 317 minecraft:brown_terracotta
fill 533 102 275 533 109 275 minecraft:brown_terracotta
fill 533 102 317 533 109 317 minecraft:brown_terracotta
fill 537 102 275 537 105 275 minecraft:brown_terracotta
fill 537 102 317 537 109 317 minecraft:brown_terracotta
fill 541 102 275 541 109 275 minecraft:brown_terracotta
fill 541 102 317 541 105 317 minecraft:brown_terracotta
fill 545 102 275 545 109 275 minecraft:brown_terracotta
fill 545 102 317 545 109 317 minecraft:brown_terracotta
fill 549 102 275 549 105 275 minecraft:brown_terracotta
fill 549 102 317 549 109 317 minecraft:brown_terracotta
fill 551 102 296 551 110 297 minecraft:brown_terracotta
fill 552 102 297 552 110 297 minecraft:brown_terracotta
fill 553 102 275 553 109 275 minecraft:brown_terracotta
fill 553 102 317 553 105 317 minecraft:brown_terracotta
fill 557 102 275 557 109 275 minecraft:brown_terracotta
fill 557 102 317 557 109 317 minecraft:brown_terracotta
fill 559 102 275 559 107 275 minecraft:brown_terracotta
fill 559 102 279 559 105 279 minecraft:brown_terracotta
fill 559 102 283 559 109 283 minecraft:brown_terracotta
fill 559 102 287 559 109 287 minecraft:brown_terracotta
fill 559 102 291 559 105 291 minecraft:brown_terracotta
fill 559 102 295 559 109 295 minecraft:brown_terracotta
fill 559 102 299 559 109 299 minecraft:brown_terracotta
fill 559 102 303 559 105 303 minecraft:brown_terracotta
fill 559 102 307 559 109 307 minecraft:brown_terracotta
fill 559 102 311 559 109 311 minecraft:brown_terracotta
fill 559 102 315 559 105 315 minecraft:brown_terracotta
fill 551 103 295 552 110 295 minecraft:brown_terracotta
fill 552 103 283 556 103 289 minecraft:red_concrete
fill 553 103 296 553 110 296 minecraft:brown_terracotta
fill 557 103 283 557 103 284 minecraft:red_concrete
fill 557 103 288 557 103 289 minecraft:red_concrete
fill 524 104 316 526 152 316 minecraft:white_concrete
fill 525 104 313 535 104 314 minecraft:red_concrete
fill 525 104 315 527 105 315 minecraft:white_concrete
fill 528 104 315 535 104 315 minecraft:red_concrete
fill 529 104 306 529 105 306 minecraft:shroomlight
fill 533 104 283 535 106 286 minecraft:spruce_leaves[persistent=true]
fill 536 104 284 536 106 284 minecraft:spruce_leaves[persistent=true]
fill 536 104 316 536 152 316 minecraft:white_concrete
fill 541 104 279 541 106 281 minecraft:spruce_leaves[persistent=true]
fill 542 104 279 543 106 279 minecraft:spruce_leaves[persistent=true]
fill 542 104 281 543 106 282 minecraft:spruce_leaves[persistent=true]
fill 543 104 280 544 106 280 minecraft:spruce_leaves[persistent=true]
fill 544 104 281 544 106 281 minecraft:spruce_leaves[persistent=true]
fill 550 104 296 550 110 297 minecraft:brown_terracotta
fill 550 104 310 554 104 314 minecraft:red_concrete
fill 551 104 298 552 110 298 minecraft:brown_terracotta
fill 552 104 315 554 104 315 minecraft:red_concrete
fill 553 104 284 556 104 288 minecraft:red_concrete
fill 553 104 295 553 110 295 minecraft:brown_terracotta
fill 553 104 297 553 110 297 minecraft:brown_terracotta
fill 553 104 308 553 107 308 minecraft:iron_block
fill 518 105 279 518 105 284 minecraft:brown_terracotta
fill 518 105 291 518 105 296 minecraft:brown_terracotta
fill 518 105 303 518 105 308 minecraft:brown_terracotta
fill 518 105 315 518 105 316 minecraft:brown_terracotta
fill 519 105 316 522 105 316 minecraft:brown_terracotta
setblock 520 105 278 minecraft:light[level=12]
setblock 520 105 285 minecraft:light[level=12]
setblock 520 105 292 minecraft:light[level=12]
setblock 520 105 299 minecraft:light[level=12]
setblock 520 105 306 minecraft:light[level=12]
setblock 520 105 313 minecraft:light[level=12]
fill 522 105 276 527 105 276 minecraft:brown_terracotta
fill 526 105 314 534 105 314 minecraft:red_concrete
setblock 527 105 278 minecraft:light[level=12]
setblock 527 105 285 minecraft:light[level=12]
setblock 527 105 292 minecraft:light[level=12]
setblock 527 105 299 minecraft:light[level=12]
setblock 527 105 306 minecraft:light[level=12]
setblock 527 105 313 minecraft:light[level=12]
fill 529 105 316 534 105 316 minecraft:brown_terracotta
fill 532 105 284 532 105 285 minecraft:spruce_leaves[persistent=true]
fill 534 105 276 539 105 276 minecraft:brown_terracotta
setblock 534 105 278 minecraft:light[level=12]
setblock 534 105 292 minecraft:light[level=12]
setblock 534 105 299 minecraft:light[level=12]
setblock 534 105 306 minecraft:light[level=12]
setblock 534 105 313 minecraft:light[level=12]
setblock 536 105 285 minecraft:spruce_leaves[persistent=true]
fill 538 105 313 538 106 313 minecraft:red_concrete
fill 540 105 280 540 105 281 minecraft:spruce_leaves[persistent=true]
setblock 541 105 278 minecraft:light[level=12]
setblock 541 105 282 minecraft:spruce_leaves[persistent=true]
setblock 541 105 285 minecraft:light[level=12]
setblock 541 105 292 minecraft:light[level=12]
setblock 541 105 299 minecraft:light[level=12]
setblock 541 105 306 minecraft:light[level=12]
setblock 541 105 313 minecraft:light[level=12]
fill 541 105 316 546 105 316 minecraft:brown_terracotta
fill 542 105 278 543 105 278 minecraft:spruce_leaves[persistent=true]
fill 542 105 280 542 106 280 minecraft:spruce_leaves[persistent=true]
setblock 544 105 279 minecraft:spruce_leaves[persistent=true]
fill 546 105 276 551 105 276 minecraft:brown_terracotta
setblock 548 105 278 minecraft:light[level=12]
setblock 548 105 285 minecraft:light[level=12]
setblock 548 105 292 minecraft:light[level=12]
setblock 548 105 299 minecraft:light[level=12]
fill 548 105 306 549 106 307 minecraft:white_concrete
setblock 548 105 313 minecraft:light[level=12]
fill 550 105 295 550 110 295 minecraft:brown_terracotta
fill 550 105 298 550 110 298 minecraft:brown_terracotta
fill 551 105 294 552 110 294 minecraft:brown_terracotta
fill 551 105 311 553 105 314 minecraft:red_concrete
fill 553 105 298 553 110 298 minecraft:brown_terracotta
fill 553 105 316 558 105 316 minecraft:brown_terracotta
fill 554 105 285 555 105 287 minecraft:red_concrete
fill 554 105 296 554 110 297 minecraft:brown_terracotta
setblock 555 105 278 minecraft:light[level=12]
setblock 555 105 292 minecraft:light[level=12]
setblock 555 105 299 minecraft:light[level=12]
setblock 555 105 306 minecraft:light[level=12]
setblock 555 105 313 minecraft:light[level=12]
fill 558 105 276 558 105 281 minecraft:brown_terracotta
fill 558 105 288 558 105 293 minecraft:brown_terracotta
fill 558 105 300 558 105 305 minecraft:brown_terracotta
fill 558 105 312 558 105 315 minecraft:brown_terracotta
fill 517 106 281 517 111 284 minecraft:shroomlight
fill 517 106 293 517 111 296 minecraft:shroomlight
fill 517 106 305 517 111 308 minecraft:shroomlight
fill 517 106 317 520 111 317 minecraft:shroomlight
fill 524 106 275 527 111 275 minecraft:shroomlight
fill 527 106 313 533 106 315 minecraft:red_concrete
fill 529 106 306 529 115 306 minecraft:brown_terracotta
fill 529 106 317 532 111 317 minecraft:shroomlight
fill 536 106 275 539 111 275 minecraft:shroomlight
fill 541 106 317 544 111 317 minecraft:shroomlight
fill 548 106 275 551 111 275 minecraft:shroomlight
fill 549 106 295 549 110 297 minecraft:brown_terracotta
fill 550 106 294 550 110 294 minecraft:brown_terracotta
fill 551 106 299 552 110 299 minecraft:brown_terracotta
fill 552 106 312 552 107 313 minecraft:red_concrete
fill 553 106 294 553 110 294 minecraft:brown_terracotta
fill 553 106 317 556 111 317 minecraft:shroomlight
fill 554 106 286 555 106 286 minecraft:red_concrete
fill 554 106 295 554 110 295 minecraft:brown_terracotta
fill 554 106 298 554 110 298 minecraft:brown_terracotta
fill 559 106 276 559 111 279 minecraft:shroomlight
fill 559 106 288 559 111 291 minecraft:shroomlight
fill 559 106 300 559 111 303 minecraft:shroomlight
fill 559 106 312 559 111 315 minecraft:shroomlight
setblock 520 107 278 minecraft:light[level=15]
setblock 520 107 286 minecraft:light[level=15]
setblock 520 107 294 minecraft:light[level=15]
setblock 520 107 302 minecraft:light[level=15]
setblock 520 107 310 minecraft:light[level=15]
setblock 528 107 278 minecraft:light[level=15]
setblock 528 107 286 minecraft:light[level=15]
setblock 528 107 294 minecraft:light[level=15]
setblock 528 107 302 minecraft:light[level=15]
setblock 528 107 310 minecraft:light[level=15]
fill 528 107 312 532 107 316 minecraft:red_concrete
setblock 536 107 278 minecraft:light[level=15]
setblock 536 107 286 minecraft:light[level=15]
setblock 536 107 294 minecraft:light[level=15]
setblock 536 107 302 minecraft:light[level=15]
setblock 536 107 310 minecraft:light[level=15]
setblock 544 107 278 minecraft:light[level=15]
setblock 544 107 286 minecraft:light[level=15]
setblock 544 107 294 minecraft:light[level=15]
setblock 544 107 302 minecraft:light[level=15]
setblock 544 107 310 minecraft:light[level=15]
fill 549 107 294 549 110 294 minecraft:brown_terracotta
fill 549 107 298 549 110 298 minecraft:brown_terracotta
fill 550 107 299 550 110 299 minecraft:brown_terracotta
fill 551 107 293 552 110 293 minecraft:brown_terracotta
fill 551 107 312 551 107 313 minecraft:red_concrete
setblock 552 107 278 minecraft:light[level=15]
setblock 552 107 286 minecraft:light[level=15]
setblock 552 107 302 minecraft:light[level=15]
setblock 552 107 310 minecraft:light[level=15]
fill 553 107 299 553 110 299 minecraft:brown_terracotta
fill 553 107 312 553 107 313 minecraft:red_concrete
fill 554 107 294 554 110 294 minecraft:brown_terracotta
fill 555 107 296 555 110 297 minecraft:brown_terracotta
setblock 517 108 277 minecraft:white_concrete
setblock 517 108 285 minecraft:white_concrete
setblock 517 108 289 minecraft:white_concrete
setblock 517 108 297 minecraft:white_concrete
setblock 517 108 301 minecraft:white_concrete
setblock 517 108 309 minecraft:white_concrete
setblock 517 108 313 minecraft:white_concrete
setblock 519 108 275 minecraft:white_concrete
fill 522 108 294 522 115 294 minecraft:red_concrete
setblock 523 108 275 minecraft:white_concrete
setblock 523 108 317 minecraft:white_concrete
setblock 527 108 317 minecraft:white_concrete
fill 528 108 306 528 115 306 minecraft:brown_terracotta
fill 529 108 305 529 115 305 minecraft:brown_terracotta
fill 529 108 307 529 115 307 minecraft:brown_terracotta
fill 530 108 306 530 115 306 minecraft:brown_terracotta
setblock 531 108 275 minecraft:white_concrete
setblock 535 108 275 minecraft:white_concrete
setblock 535 108 317 minecraft:white_concrete
setblock 539 108 317 minecraft:white_concrete
setblock 543 108 275 minecraft:white_concrete
setblock 547 108 275 minecraft:white_concrete
setblock 547 108 317 minecraft:white_concrete
fill 548 108 295 548 110 298 minecraft:brown_terracotta
fill 549 108 299 549 110 299 minecraft:brown_terracotta
fill 550 108 293 550 110 293 minecraft:brown_terracotta
fill 551 108 300 553 110 300 minecraft:brown_terracotta
setblock 551 108 317 minecraft:white_concrete
fill 553 108 293 553 110 293 minecraft:brown_terracotta
fill 553 108 305 557 108 311 minecraft:brown_terracotta
fill 554 108 299 554 110 299 minecraft:brown_terracotta
setblock 555 108 275 minecraft:white_concrete
fill 555 108 295 555 110 295 minecraft:brown_terracotta
fill 555 108 298 555 110 298 minecraft:brown_terracotta
setblock 559 108 275 minecraft:white_concrete
setblock 559 108 281 minecraft:white_concrete
setblock 559 108 285 minecraft:white_concrete
setblock 559 108 293 minecraft:white_concrete
setblock 559 108 297 minecraft:white_concrete
setblock 559 108 305 minecraft:white_concrete
setblock 559 108 309 minecraft:white_concrete
setblock 559 108 317 minecraft:white_concrete
setblock 517 109 276 minecraft:white_concrete
fill 517 109 277 517 116 277 minecraft:brown_terracotta
setblock 517 109 278 minecraft:white_concrete
setblock 517 109 280 minecraft:white_concrete
fill 517 109 285 517 116 285 minecraft:brown_terracotta
setblock 517 109 286 minecraft:white_concrete
setblock 517 109 288 minecraft:white_concrete
fill 517 109 289 517 116 289 minecraft:brown_terracotta
setblock 517 109 290 minecraft:white_concrete
setblock 517 109 292 minecraft:white_concrete
fill 517 109 297 517 116 297 minecraft:brown_terracotta
setblock 517 109 298 minecraft:white_concrete
setblock 517 109 300 minecraft:white_concrete
fill 517 109 301 517 116 301 minecraft:brown_terracotta
setblock 517 109 302 minecraft:white_concrete
setblock 517 109 304 minecraft:white_concrete
fill 517 109 309 517 116 309 minecraft:brown_terracotta
setblock 517 109 310 minecraft:white_concrete
setblock 517 109 312 minecraft:white_concrete
fill 517 109 313 517 116 313 minecraft:brown_terracotta
setblock 517 109 314 minecraft:white_concrete
setblock 517 109 316 minecraft:white_concrete
setblock 518 109 275 minecraft:white_concrete
fill 519 109 275 519 116 275 minecraft:brown_terracotta
fill 519 109 292 521 115 296 minecraft:red_concrete
setblock 520 109 275 minecraft:white_concrete
fill 520 109 291 524 121 291 minecraft:red_concrete
fill 520 109 297 524 121 297 minecraft:red_concrete
setblock 522 109 275 minecraft:white_concrete
fill 522 109 292 525 115 293 minecraft:red_concrete
fill 522 109 295 525 115 296 minecraft:red_concrete
setblock 522 109 317 minecraft:white_concrete
fill 523 109 275 523 116 275 minecraft:brown_terracotta
fill 523 109 294 525 115 294 minecraft:red_concrete
fill 523 109 317 523 116 317 minecraft:brown_terracotta
setblock 524 109 317 minecraft:white_concrete
setblock 526 109 317 minecraft:white_concrete
fill 527 109 317 527 116 317 minecraft:brown_terracotta
setblock 528 109 275 minecraft:white_concrete
fill 528 109 305 528 115 305 minecraft:brown_terracotta
fill 528 109 307 528 115 307 minecraft:brown_terracotta
setblock 528 109 317 minecraft:white_concrete
setblock 530 109 275 minecraft:white_concrete
fill 530 109 305 530 115 305 minecraft:brown_terracotta
fill 530 109 307 530 115 307 minecraft:brown_terracotta
fill 531 109 275 531 116 275 minecraft:brown_terracotta
setblock 532 109 275 minecraft:white_concrete
setblock 534 109 275 minecraft:white_concrete
setblock 534 109 317 minecraft:white_concrete
fill 535 109 275 535 116 275 minecraft:brown_terracotta
fill 535 109 317 535 116 317 minecraft:brown_terracotta
setblock 536 109 317 minecraft:white_concrete
setblock 538 109 317 minecraft:white_concrete
fill 539 109 317 539 116 317 minecraft:brown_terracotta
setblock 540 109 275 minecraft:white_concrete
setblock 540 109 317 minecraft:white_concrete
setblock 542 109 275 minecraft:white_concrete
fill 543 109 275 543 116 275 minecraft:brown_terracotta
setblock 544 109 275 minecraft:white_concrete
setblock 546 109 275 minecraft:white_concrete
setblock 546 109 317 minecraft:white_concrete
fill 547 109 275 547 116 275 minecraft:brown_terracotta
fill 547 109 317 547 116 317 minecraft:brown_terracotta
fill 548 109 294 548 110 294 minecraft:brown_terracotta
setblock 548 109 317 minecraft:white_concrete
fill 549 109 293 549 110 293 minecraft:brown_terracotta
fill 550 109 300 550 110 300 minecraft:brown_terracotta
setblock 550 109 317 minecraft:white_concrete
fill 551 109 292 552 110 292 minecraft:brown_terracotta
fill 551 109 317 551 116 317 minecraft:brown_terracotta
setblock 552 109 275 minecraft:white_concrete
setblock 552 109 317 minecraft:white_concrete
fill 553 109 305 557 109 311 minecraft:white_concrete
setblock 554 109 275 minecraft:white_concrete
fill 554 109 293 554 110 293 minecraft:brown_terracotta
fill 554 109 300 554 110 300 minecraft:brown_terracotta
fill 555 109 275 555 116 275 minecraft:brown_terracotta
fill 555 109 294 555 110 294 minecraft:brown_terracotta
fill 555 109 299 555 110 299 minecraft:brown_terracotta
setblock 556 109 275 minecraft:white_concrete
fill 556 109 296 556 110 297 minecraft:brown_terracotta
setblock 558 109 275 minecraft:white_concrete
setblock 558 109 317 minecraft:white_concrete
setblock 559 109 275 minecraft:brown_terracotta
setblock 559 109 280 minecraft:white_concrete
fill 559 109 281 559 116 281 minecraft:brown_terracotta
setblock 559 109 282 minecraft:white_concrete
setblock 559 109 284 minecraft:white_concrete
fill 559 109 285 559 116 285 minecraft:brown_terracotta
setblock 559 109 286 minecraft:white_concrete
setblock 559 109 292 minecraft:white_concrete
fill 559 109 293 559 116 293 minecraft:brown_terracotta
setblock 559 109 294 minecraft:white_concrete
setblock 559 109 296 minecraft:white_concrete
fill 559 109 297 559 116 297 minecraft:brown_terracotta
setblock 559 109 298 minecraft:white_concrete
setblock 559 109 304 minecraft:white_concrete
fill 559 109 305 559 116 305 minecraft:brown_terracotta
setblock 559 109 306 minecraft:white_concrete
setblock 559 109 308 minecraft:white_concrete
fill 559 109 309 559 116 309 minecraft:brown_terracotta
setblock 559 109 310 minecraft:white_concrete
setblock 559 109 316 minecraft:white_concrete
fill 559 109 317 559 116 317 minecraft:brown_terracotta
setblock 517 110 275 minecraft:white_concrete
fill 517 110 276 517 117 276 minecraft:brown_terracotta
fill 517 110 278 517 117 278 minecraft:brown_terracotta
setblock 517 110 279 minecraft:white_concrete
fill 517 110 280 517 117 280 minecraft:brown_terracotta
fill 517 110 286 517 117 286 minecraft:brown_terracotta
setblock 517 110 287 minecraft:white_concrete
fill 517 110 288 517 117 288 minecraft:brown_terracotta
fill 517 110 290 517 117 290 minecraft:brown_terracotta
setblock 517 110 291 minecraft:white_concrete
fill 517 110 292 517 117 292 minecraft:brown_terracotta
fill 517 110 298 517 117 298 minecraft:brown_terracotta
setblock 517 110 299 minecraft:white_concrete
fill 517 110 300 517 117 300 minecraft:brown_terracotta
fill 517 110 302 517 117 302 minecraft:brown_terracotta
setblock 517 110 303 minecraft:white_concrete
fill 517 110 304 517 117 304 minecraft:brown_terracotta
fill 517 110 310 517 117 310 minecraft:brown_terracotta
setblock 517 110 311 minecraft:white_concrete
fill 517 110 312 517 117 312 minecraft:brown_terracotta
fill 517 110 314 517 117 314 minecraft:brown_terracotta
setblock 517 110 315 minecraft:white_concrete
fill 517 110 316 517 117 316 minecraft:brown_terracotta
fill 518 110 275 518 117 275 minecraft:brown_terracotta
fill 518 110 292 518 120 296 minecraft:red_concrete
fill 519 110 291 519 120 291 minecraft:red_concrete
fill 519 110 297 519 119 297 minecraft:red_concrete
fill 520 110 275 520 117 275 minecraft:brown_terracotta
fill 520 110 290 524 118 290 minecraft:red_concrete
fill 520 110 298 524 120 298 minecraft:red_concrete
setblock 521 110 275 minecraft:white_concrete
setblock 521 110 317 minecraft:white_concrete
fill 522 110 275 522 117 275 minecraft:brown_terracotta
fill 522 110 317 522 117 317 minecraft:brown_terracotta
fill 524 110 277 524 118 277 minecraft:red_wool
fill 524 110 317 524 117 317 minecraft:brown_terracotta
fill 525 110 291 525 120 291 minecraft:red_concrete
fill 525 110 297 525 120 297 minecraft:red_concrete
setblock 525 110 317 minecraft:white_concrete
fill 526 110 292 526 120 296 minecraft:red_concrete
fill 526 110 317 526 117 317 minecraft:brown_terracotta
fill 527 110 306 527 115 306 minecraft:brown_terracotta
fill 528 110 275 528 117 275 minecraft:brown_terracotta
fill 528 110 317 528 117 317 minecraft:brown_terracotta
setblock 529 110 275 minecraft:white_concrete
fill 529 110 304 529 115 304 minecraft:brown_terracotta
fill 529 110 308 530 115 308 minecraft:brown_terracotta
fill 530 110 275 530 117 275 minecraft:brown_terracotta
fill 531 110 305 531 115 307 minecraft:brown_terracotta
fill 532 110 275 532 117 275 minecraft:brown_terracotta
setblock 533 110 275 minecraft:white_concrete
setblock 533 110 317 minecraft:white_concrete
fill 534 110 275 534 117 275 minecraft:brown_terracotta
fill 534 110 317 534 117 317 minecraft:brown_terracotta
fill 536 110 317 536 117 317 minecraft:brown_terracotta
setblock 537 110 317 minecraft:white_concrete
fill 538 110 317 538 117 317 minecraft:brown_terracotta
fill 540 110 275 540 117 275 minecraft:brown_terracotta
fill 540 110 317 540 117 317 minecraft:brown_terracotta
setblock 541 110 275 minecraft:white_concrete
fill 542 110 275 542 117 275 minecraft:brown_terracotta
fill 544 110 275 544 117 275 minecraft:brown_terracotta
setblock 545 110 275 minecraft:white_concrete
setblock 545 110 317 minecraft:white_concrete
fill 546 110 275 546 117 275 minecraft:brown_terracotta
fill 546 110 317 546 117 317 minecraft:brown_terracotta
fill 547 110 295 547 110 298 minecraft:brown_terracotta
setblock 548 110 293 minecraft:brown_terracotta
setblock 548 110 299 minecraft:brown_terracotta
fill 548 110 317 548 117 317 minecraft:brown_terracotta
setblock 549 110 300 minecraft:brown_terracotta
setblock 549 110 317 minecraft:white_concrete
setblock 550 110 292 minecraft:brown_terracotta
fill 550 110 317 550 117 317 minecraft:brown_terracotta
fill 551 110 301 553 110 301 minecraft:brown_terracotta
fill 552 110 275 552 117 275 minecraft:brown_terracotta
fill 552 110 317 552 117 317 minecraft:brown_terracotta
setblock 553 110 275 minecraft:white_concrete
fill 553 110 292 554 110 292 minecraft:brown_terracotta
fill 553 110 305 553 110 311 minecraft:red_concrete
fill 554 110 275 554 117 275 minecraft:brown_terracotta
setblock 555 110 293 minecraft:brown_terracotta
fill 556 110 275 556 117 275 minecraft:brown_terracotta
setblock 556 110 295 minecraft:brown_terracotta
setblock 556 110 298 minecraft:brown_terracotta
setblock 557 110 275 minecraft:white_concrete
setblock 557 110 317 minecraft:white_concrete
fill 558 110 275 558 117 275 minecraft:brown_terracotta
fill 558 110 307 558 113 309 minecraft:shroomlight
fill 558 110 310 558 152 310 minecraft:white_concrete
fill 558 110 317 558 117 317 minecraft:brown_terracotta
setblock 559 110 275 minecraft:white_concrete
fill 559 110 280 559 117 280 minecraft:brown_terracotta
fill 559 110 282 559 117 282 minecraft:brown_terracotta
setblock 559 110 283 minecraft:white_concrete
fill 559 110 284 559 117 284 minecraft:brown_terracotta
fill 559 110 286 559 117 286 minecraft:brown_terracotta
setblock 559 110 287 minecraft:white_concrete
fill 559 110 292 559 117 292 minecraft:brown_terracotta
fill 559 110 294 559 117 294 minecraft:brown_terracotta
setblock 559 110 295 minecraft:white_concrete
fill 559 110 296 559 117 296 minecraft:brown_terracotta
fill 559 110 298 559 117 298 minecraft:brown_terracotta
setblock 559 110 299 minecraft:white_concrete
fill 559 110 304 559 117 304 minecraft:brown_terracotta
fill 559 110 306 559 117 306 minecraft:brown_terracotta
setblock 559 110 307 minecraft:white_concrete
fill 559 110 308 559 117 308 minecraft:brown_terracotta
fill 559 110 310 559 117 310 minecraft:brown_terracotta
setblock 559 110 311 minecraft:white_concrete
fill 559 110 316 559 117 316 minecraft:brown_terracotta
fill 517 111 275 517 118 275 minecraft:brown_terracotta
fill 517 111 279 517 118 279 minecraft:brown_terracotta
fill 517 111 287 517 118 287 minecraft:brown_terracotta
fill 517 111 291 517 118 291 minecraft:brown_terracotta
fill 517 111 299 517 118 299 minecraft:brown_terracotta
fill 517 111 303 517 118 303 minecraft:brown_terracotta
fill 517 111 311 517 118 311 minecraft:brown_terracotta
fill 517 111 315 517 118 315 minecraft:brown_terracotta
fill 518 111 290 518 119 291 minecraft:red_concrete
fill 518 111 297 518 119 297 minecraft:red_concrete
fill 519 111 290 519 119 290 minecraft:red_concrete
fill 519 111 298 519 119 298 minecraft:red_concrete
setblock 520 111 278 minecraft:light[level=12]
setblock 520 111 285 minecraft:light[level=12]
fill 520 111 289 524 118 289 minecraft:red_concrete
fill 520 111 299 524 119 299 minecraft:red_concrete
setblock 520 111 306 minecraft:light[level=12]
setblock 520 111 313 minecraft:light[level=12]
fill 521 111 275 521 118 275 minecraft:brown_terracotta
fill 521 111 317 521 118 317 minecraft:brown_terracotta
fill 522 111 277 523 118 277 minecraft:red_wool
fill 525 111 277 526 118 277 minecraft:red_wool
fill 525 111 290 526 119 290 minecraft:red_concrete
fill 525 111 298 526 119 298 minecraft:red_concrete
fill 525 111 317 525 118 317 minecraft:brown_terracotta
fill 526 111 291 526 119 291 minecraft:red_concrete
fill 526 111 297 526 119 297 minecraft:red_concrete
setblock 527 111 278 minecraft:light[level=12]
fill 527 111 281 527 111 282 minecraft:lime_concrete
setblock 527 111 285 minecraft:light[level=12]
fill 527 111 292 527 119 294 minecraft:red_concrete
setblock 527 111 299 minecraft:light[level=12]
fill 527 111 305 527 115 305 minecraft:brown_terracotta
fill 527 111 307 527 115 307 minecraft:brown_terracotta
setblock 527 111 313 minecraft:light[level=12]
fill 528 111 282 528 112 282 minecraft:lime_concrete
fill 528 111 304 528 115 304 minecraft:brown_terracotta
fill 528 111 308 528 115 308 minecraft:brown_terracotta
fill 529 111 275 529 118 275 minecraft:brown_terracotta
fill 530 111 304 530 115 304 minecraft:brown_terracotta
fill 533 111 275 533 118 275 minecraft:brown_terracotta
fill 533 111 317 533 118 317 minecraft:brown_terracotta
setblock 534 111 278 minecraft:light[level=12]
setblock 534 111 285 minecraft:light[level=12]
setblock 534 111 292 minecraft:light[level=12]
setblock 534 111 299 minecraft:light[level=12]
setblock 534 111 306 minecraft:light[level=12]
setblock 534 111 313 minecraft:light[level=12]
fill 537 111 317 537 118 317 minecraft:brown_terracotta
fill 541 111 275 541 118 275 minecraft:brown_terracotta
setblock 541 111 278 minecraft:light[level=12]
setblock 541 111 285 minecraft:light[level=12]
setblock 541 111 292 minecraft:light[level=12]
setblock 541 111 299 minecraft:light[level=12]
setblock 541 111 306 minecraft:light[level=12]
setblock 541 111 313 minecraft:light[level=12]
fill 545 111 275 545 118 275 minecraft:brown_terracotta
fill 545 111 317 545 118 317 minecraft:brown_terracotta
setblock 548 111 278 minecraft:light[level=12]
setblock 548 111 285 minecraft:light[level=12]
setblock 548 111 292 minecraft:light[level=12]
setblock 548 111 299 minecraft:light[level=12]
setblock 548 111 306 minecraft:light[level=12]
setblock 548 111 313 minecraft:light[level=12]
fill 549 111 317 549 118 317 minecraft:brown_terracotta
fill 552 111 296 552 113 296 minecraft:white_concrete
fill 553 111 275 553 118 275 minecraft:brown_terracotta
setblock 553 111 305 minecraft:white_concrete
setblock 553 111 308 minecraft:white_concrete
setblock 553 111 311 minecraft:white_concrete
setblock 555 111 278 minecraft:light[level=12]
setblock 555 111 285 minecraft:light[level=12]
setblock 555 111 292 minecraft:light[level=12]
setblock 555 111 299 minecraft:light[level=12]
setblock 555 111 306 minecraft:light[level=12]
setblock 555 111 313 minecraft:light[level=12]
fill 557 111 275 557 118 275 minecraft:brown_terracotta
fill 557 111 317 557 118 317 minecraft:brown_terracotta
fill 559 111 275 559 116 275 minecraft:brown_terracotta
fill 559 111 283 559 118 283 minecraft:brown_terracotta
fill 559 111 287 559 118 287 minecraft:brown_terracotta
fill 559 111 295 559 118 295 minecraft:brown_terracotta
fill 559 111 299 559 118 299 minecraft:brown_terracotta
fill 559 111 307 559 118 307 minecraft:brown_terracotta
fill 559 111 311 559 118 311 minecraft:brown_terracotta
fill 517 112 281 517 116 281 minecraft:brown_terracotta
fill 517 112 282 517 112 283 minecraft:shroomlight
fill 517 112 284 517 117 284 minecraft:brown_terracotta
fill 517 112 293 517 116 293 minecraft:brown_terracotta
fill 517 112 294 517 112 295 minecraft:shroomlight
fill 517 112 296 517 117 296 minecraft:brown_terracotta
fill 517 112 305 517 116 305 minecraft:brown_terracotta
fill 517 112 306 517 112 307 minecraft:shroomlight
fill 517 112 308 517 117 308 minecraft:brown_terracotta
fill 517 112 317 517 116 317 minecraft:brown_terracotta
fill 518 112 317 519 112 317 minecraft:shroomlight
fill 519 112 289 519 118 289 minecraft:red_concrete
fill 519 112 299 519 118 299 minecraft:red_concrete
fill 520 112 288 524 118 288 minecraft:red_concrete
fill 520 112 300 524 118 300 minecraft:red_concrete
fill 520 112 317 520 117 317 minecraft:brown_terracotta
fill 524 112 275 524 117 275 minecraft:brown_terracotta
fill 525 112 275 526 112 275 minecraft:shroomlight
fill 525 112 289 525 118 289 minecraft:red_concrete
fill 525 112 299 525 118 299 minecraft:red_concrete
fill 526 112 281 528 113 281 minecraft:white_concrete
fill 526 112 306 526 115 306 minecraft:brown_terracotta
fill 527 112 275 527 116 275 minecraft:brown_terracotta
fill 527 112 280 527 113 280 minecraft:white_concrete
fill 527 112 282 527 113 282 minecraft:white_concrete
fill 527 112 291 527 118 291 minecraft:red_concrete
fill 527 112 304 527 115 304 minecraft:brown_terracotta
fill 527 112 308 527 115 308 minecraft:brown_terracotta
fill 528 112 292 528 118 294 minecraft:red_concrete
fill 528 112 309 530 115 309 minecraft:brown_terracotta
fill 529 112 303 530 115 303 minecraft:brown_terracotta
fill 529 112 317 529 118 317 minecraft:brown_terracotta
fill 530 112 317 531 112 317 minecraft:shroomlight
fill 531 112 304 531 115 304 minecraft:brown_terracotta
fill 531 112 308 531 115 308 minecraft:brown_terracotta
fill 532 112 305 532 115 307 minecraft:brown_terracotta
fill 532 112 317 532 117 317 minecraft:brown_terracotta
fill 536 112 275 536 117 275 minecraft:brown_terracotta
fill 537 112 275 538 112 275 minecraft:shroomlight
fill 539 112 275 539 116 275 minecraft:brown_terracotta
fill 541 112 317 541 118 317 minecraft:brown_terracotta
fill 542 112 317 543 112 317 minecraft:shroomlight
fill 544 112 317 544 117 317 minecraft:brown_terracotta
fill 548 112 275 548 117 275 minecraft:brown_terracotta
fill 549 112 275 550 112 275 minecraft:shroomlight
fill 551 112 275 551 116 275 minecraft:brown_terracotta
fill 553 112 317 553 118 317 minecraft:brown_terracotta
fill 554 112 317 555 112 317 minecraft:shroomlight
fill 556 112 317 556 117 317 minecraft:brown_terracotta
fill 559 112 276 559 117 276 minecraft:brown_terracotta
fill 559 112 277 559 112 278 minecraft:shroomlight
fill 559 112 279 559 118 279 minecraft:brown_terracotta
fill 559 112 288 559 117 288 minecraft:brown_terracotta
fill 559 112 289 559 112 290 minecraft:shroomlight
fill 559 112 291 559 118 291 minecraft:brown_terracotta
fill 559 112 300 559 117 300 minecraft:brown_terracotta
fill 559 112 301 559 112 302 minecraft:shroomlight
fill 559 112 303 559 118 303 minecraft:brown_terracotta
fill 559 112 312 559 117 312 minecraft:brown_terracotta
fill 559 112 313 559 112 314 minecraft:shroomlight
fill 559 112 315 559 118 315 minecraft:brown_terracotta
fill 517 113 282 517 117 283 minecraft:brown_terracotta
fill 517 113 294 517 117 295 minecraft:brown_terracotta
fill 517 113 306 517 117 307 minecraft:brown_terracotta
fill 518 113 289 518 117 289 minecraft:red_concrete
fill 518 113 317 519 116 317 minecraft:brown_terracotta
fill 519 113 288 519 117 288 minecraft:red_concrete
fill 519 113 300 519 117 300 minecraft:red_concrete
fill 525 113 275 526 117 275 minecraft:brown_terracotta
fill 525 113 288 525 117 288 minecraft:red_concrete
fill 525 113 300 525 117 300 minecraft:red_concrete
fill 526 113 289 526 117 289 minecraft:red_concrete
fill 526 113 299 526 117 299 minecraft:red_concrete
fill 526 113 305 526 115 305 minecraft:brown_terracotta
fill 526 113 307 526 115 308 minecraft:brown_terracotta
fill 527 113 286 528 114 287 minecraft:white_concrete
fill 527 113 290 527 117 290 minecraft:red_concrete
fill 527 113 309 527 115 309 minecraft:brown_terracotta
fill 528 113 291 528 117 291 minecraft:red_concrete
fill 528 113 303 528 115 303 minecraft:brown_terracotta
fill 530 113 317 531 116 317 minecraft:brown_terracotta
fill 531 113 303 531 115 303 minecraft:brown_terracotta
fill 531 113 309 531 115 309 minecraft:brown_terracotta
fill 532 113 304 532 115 304 minecraft:brown_terracotta
fill 532 113 308 532 115 308 minecraft:brown_terracotta
fill 537 113 275 538 117 275 minecraft:brown_terracotta
fill 542 113 317 543 116 317 minecraft:brown_terracotta
fill 549 113 275 550 117 275 minecraft:brown_terracotta
fill 554 113 317 555 116 317 minecraft:brown_terracotta
fill 559 113 277 559 116 278 minecraft:brown_terracotta
fill 559 113 289 559 116 290 minecraft:brown_terracotta
fill 559 113 301 559 116 302 minecraft:brown_terracotta
fill 559 113 313 559 116 314 minecraft:brown_terracotta
fill 525 114 306 525 115 306 minecraft:brown_terracotta
fill 526 114 304 526 115 304 minecraft:brown_terracotta
fill 527 114 295 527 119 295 minecraft:red_concrete
setblock 527 114 303 minecraft:brown_terracotta
fill 528 114 310 530 115 310 minecraft:brown_terracotta
fill 529 114 302 530 115 302 minecraft:brown_terracotta
fill 533 114 305 533 115 307 minecraft:brown_terracotta
fill 550 114 296 553 116 297 minecraft:spruce_leaves[persistent=true]
fill 551 114 295 553 116 295 minecraft:spruce_leaves[persistent=true]
fill 551 114 298 552 116 298 minecraft:spruce_leaves[persistent=true]
fill 558 114 308 558 152 309 minecraft:white_concrete
fill 518 115 285 527 115 285 minecraft:shroomlight
fill 518 115 302 518 115 303 minecraft:shroomlight
fill 519 115 303 527 115 303 minecraft:shroomlight
setblock 520 115 278 minecraft:light[level=15]
fill 520 115 284 524 115 284 minecraft:shroomlight
setblock 520 115 286 minecraft:light[level=15]
setblock 520 115 302 minecraft:light[level=15]
fill 520 115 304 524 115 304 minecraft:shroomlight
setblock 520 115 310 minecraft:light[level=15]
setblock 522 115 287 minecraft:red_concrete
setblock 522 115 301 minecraft:red_concrete
fill 525 115 304 525 115 305 minecraft:brown_terracotta
fill 525 115 307 525 115 308 minecraft:brown_terracotta
fill 526 115 286 528 115 286 minecraft:shroomlight
fill 526 115 302 528 115 302 minecraft:shroomlight
setblock 526 115 309 minecraft:brown_terracotta
setblock 527 115 310 minecraft:brown_terracotta
setblock 528 115 278 minecraft:light[level=15]
fill 528 115 287 529 115 287 minecraft:shroomlight
fill 528 115 301 529 115 301 minecraft:shroomlight
fill 529 115 288 530 115 288 minecraft:shroomlight
fill 530 115 289 531 115 290 minecraft:shroomlight
fill 531 115 291 531 115 294 minecraft:shroomlight
setblock 531 115 302 minecraft:brown_terracotta
setblock 531 115 310 minecraft:brown_terracotta
fill 532 115 292 532 115 294 minecraft:shroomlight
setblock 532 115 303 minecraft:brown_terracotta
setblock 532 115 309 minecraft:brown_terracotta
setblock 533 115 304 minecraft:brown_terracotta
setblock 533 115 308 minecraft:brown_terracotta
setblock 536 115 278 minecraft:light[level=15]
setblock 536 115 286 minecraft:light[level=15]
setblock 536 115 294 minecraft:light[level=15]
setblock 536 115 302 minecraft:light[level=15]
setblock 536 115 310 minecraft:light[level=15]
setblock 544 115 278 minecraft:light[level=15]
setblock 544 115 286 minecraft:light[level=15]
setblock 544 115 294 minecraft:light[level=15]
setblock 544 115 302 minecraft:light[level=15]
setblock 544 115 310 minecraft:light[level=15]
setblock 550 115 295 minecraft:spruce_leaves[persistent=true]
setblock 550 115 298 minecraft:spruce_leaves[persistent=true]
fill 551 115 294 552 115 294 minecraft:spruce_leaves[persistent=true]
setblock 552 115 278 minecraft:light[level=15]
setblock 552 115 286 minecraft:light[level=15]
setblock 552 115 302 minecraft:light[level=15]
setblock 552 115 310 minecraft:light[level=15]
setblock 553 115 298 minecraft:spruce_leaves[persistent=true]
fill 519 116 292 519 121 296 minecraft:red_concrete
fill 520 116 292 524 116 296 minecraft:orange_terracotta
fill 525 116 292 525 121 296 minecraft:red_concrete
fill 529 116 306 529 119 306 minecraft:white_concrete
setblock 517 117 277 minecraft:white_concrete
setblock 517 117 281 minecraft:white_concrete
setblock 517 117 285 minecraft:white_concrete
setblock 517 117 289 minecraft:white_concrete
setblock 517 117 293 minecraft:white_concrete
setblock 517 117 297 minecraft:white_concrete
setblock 517 117 301 minecraft:white_concrete
setblock 517 117 305 minecraft:white_concrete
setblock 517 117 309 minecraft:white_concrete
setblock 517 117 313 minecraft:white_concrete
setblock 517 117 317 minecraft:white_concrete
setblock 518 117 317 minecraft:brown_terracotta
setblock 519 117 275 minecraft:white_concrete
setblock 519 117 317 minecraft:white_concrete
setblock 520 117 278 minecraft:light[level=12]
setblock 520 117 285 minecraft:light[level=12]
fill 520 117 292 521 120 296 minecraft:orange_terracotta
setblock 520 117 306 minecraft:light[level=12]
setblock 520 117 313 minecraft:light[level=12]
fill 522 117 292 524 120 293 minecraft:orange_terracotta
fill 522 117 294 522 118 294 minecraft:ochre_froglight
fill 522 117 295 524 120 296 minecraft:orange_terracotta
setblock 523 117 275 minecraft:white_concrete
fill 523 117 294 524 120 294 minecraft:orange_terracotta
setblock 523 117 317 minecraft:white_concrete
setblock 527 117 275 minecraft:white_concrete
setblock 527 117 278 minecraft:light[level=12]
setblock 527 117 285 minecraft:light[level=12]
setblock 527 117 299 minecraft:light[level=12]
setblock 527 117 306 minecraft:light[level=12]
setblock 527 117 313 minecraft:light[level=12]
setblock 527 117 317 minecraft:white_concrete
setblock 530 117 317 minecraft:brown_terracotta
setblock 531 117 275 minecraft:white_concrete
setblock 531 117 317 minecraft:white_concrete
setblock 534 117 278 minecraft:light[level=12]
setblock 534 117 285 minecraft:light[level=12]
setblock 534 117 292 minecraft:light[level=12]
setblock 534 117 299 minecraft:light[level=12]
setblock 534 117 306 minecraft:light[level=12]
setblock 534 117 313 minecraft:light[level=12]
setblock 535 117 275 minecraft:white_concrete
setblock 535 117 317 minecraft:white_concrete
setblock 539 117 275 minecraft:white_concrete
setblock 539 117 317 minecraft:white_concrete
setblock 541 117 278 minecraft:light[level=12]
setblock 541 117 285 minecraft:light[level=12]
setblock 541 117 292 minecraft:light[level=12]
setblock 541 117 299 minecraft:light[level=12]
setblock 541 117 306 minecraft:light[level=12]
setblock 541 117 313 minecraft:light[level=12]
setblock 542 117 317 minecraft:brown_terracotta
setblock 543 117 275 minecraft:white_concrete
setblock 543 117 317 minecraft:white_concrete
setblock 547 117 275 minecraft:white_concrete
setblock 547 117 317 minecraft:white_concrete
setblock 548 117 278 minecraft:light[level=12]
fill 548 117 280 548 120 280 minecraft:iron_block
setblock 548 117 285 minecraft:light[level=12]
setblock 548 117 292 minecraft:light[level=12]
setblock 548 117 299 minecraft:light[level=12]
setblock 548 117 306 minecraft:light[level=12]
setblock 548 117 313 minecraft:light[level=12]
setblock 551 117 275 minecraft:white_concrete
setblock 551 117 317 minecraft:white_concrete
setblock 554 117 317 minecraft:brown_terracotta
setblock 555 117 275 minecraft:white_concrete
setblock 555 117 278 minecraft:light[level=12]
setblock 555 117 285 minecraft:light[level=12]
setblock 555 117 292 minecraft:light[level=12]
setblock 555 117 299 minecraft:light[level=12]
setblock 555 117 306 minecraft:light[level=12]
setblock 555 117 313 minecraft:light[level=12]
setblock 555 117 317 minecraft:white_concrete
setblock 559 117 275 minecraft:white_concrete
setblock 559 117 277 minecraft:white_concrete
setblock 559 117 278 minecraft:brown_terracotta
setblock 559 117 281 minecraft:white_concrete
setblock 559 117 285 minecraft:white_concrete
setblock 559 117 289 minecraft:white_concrete
setblock 559 117 290 minecraft:brown_terracotta
setblock 559 117 293 minecraft:white_concrete
setblock 559 117 297 minecraft:white_concrete
setblock 559 117 301 minecraft:white_concrete
setblock 559 117 302 minecraft:brown_terracotta
setblock 559 117 305 minecraft:white_concrete
setblock 559 117 309 minecraft:white_concrete
setblock 559 117 313 minecraft:white_concrete
setblock 559 117 314 minecraft:brown_terracotta
setblock 559 117 317 minecraft:white_concrete
setblock 517 118 276 minecraft:white_concrete
fill 517 118 277 517 125 277 minecraft:brown_terracotta
setblock 517 118 278 minecraft:white_concrete
setblock 517 118 280 minecraft:white_concrete
fill 517 118 281 517 125 281 minecraft:brown_terracotta
setblock 517 118 282 minecraft:white_concrete
setblock 517 118 283 minecraft:brown_terracotta
setblock 517 118 284 minecraft:white_concrete
fill 517 118 285 517 125 285 minecraft:brown_terracotta
setblock 517 118 286 minecraft:white_concrete
setblock 517 118 288 minecraft:white_concrete
fill 517 118 289 517 125 289 minecraft:brown_terracotta
setblock 517 118 290 minecraft:white_concrete
setblock 517 118 292 minecraft:white_concrete
fill 517 118 293 517 125 293 minecraft:brown_terracotta
setblock 517 118 294 minecraft:white_concrete
setblock 517 118 295 minecraft:brown_terracotta
fill 517 118 296 517 121 298 minecraft:shroomlight
setblock 517 118 300 minecraft:white_concrete
fill 517 118 301 517 125 301 minecraft:brown_terracotta
setblock 517 118 302 minecraft:white_concrete
setblock 517 118 304 minecraft:white_concrete
fill 517 118 305 517 125 305 minecraft:brown_terracotta
setblock 517 118 306 minecraft:white_concrete
setblock 517 118 307 minecraft:brown_terracotta
setblock 517 118 308 minecraft:white_concrete
fill 517 118 309 517 125 309 minecraft:brown_terracotta
setblock 517 118 310 minecraft:white_concrete
setblock 517 118 312 minecraft:white_concrete
fill 517 118 313 517 125 313 minecraft:brown_terracotta
setblock 517 118 314 minecraft:white_concrete
setblock 517 118 316 minecraft:white_concrete
setblock 517 118 317 minecraft:brown_terracotta
setblock 518 118 275 minecraft:white_concrete
setblock 518 118 317 minecraft:white_concrete
fill 519 118 275 519 125 275 minecraft:brown_terracotta
fill 519 118 317 519 125 317 minecraft:brown_terracotta
setblock 520 118 275 minecraft:white_concrete
setblock 520 118 317 minecraft:white_concrete
setblock 522 118 275 minecraft:white_concrete
setblock 522 118 317 minecraft:white_concrete
fill 523 118 275 523 125 275 minecraft:brown_terracotta
fill 523 118 317 523 125 317 minecraft:brown_terracotta
setblock 524 118 275 minecraft:white_concrete
setblock 524 118 317 minecraft:white_concrete
setblock 525 118 275 minecraft:brown_terracotta
setblock 526 118 275 minecraft:white_concrete
setblock 526 118 317 minecraft:white_concrete
fill 527 118 275 527 125 275 minecraft:brown_terracotta
fill 527 118 317 527 125 317 minecraft:brown_terracotta
setblock 528 118 275 minecraft:white_concrete
setblock 528 118 317 minecraft:white_concrete
setblock 530 118 275 minecraft:white_concrete
setblock 530 118 317 minecraft:white_concrete
fill 531 118 275 531 125 275 minecraft:brown_terracotta
fill 531 118 317 531 125 317 minecraft:brown_terracotta
setblock 532 118 275 minecraft:white_concrete
setblock 532 118 317 minecraft:white_concrete
setblock 534 118 275 minecraft:white_concrete
setblock 534 118 317 minecraft:white_concrete
fill 535 118 275 535 125 275 minecraft:brown_terracotta
fill 535 118 317 535 125 317 minecraft:brown_terracotta
setblock 536 118 275 minecraft:white_concrete
setblock 536 118 317 minecraft:white_concrete
setblock 537 118 275 minecraft:brown_terracotta
setblock 538 118 275 minecraft:white_concrete
setblock 538 118 317 minecraft:white_concrete
fill 539 118 275 539 125 275 minecraft:brown_terracotta
fill 539 118 317 539 125 317 minecraft:brown_terracotta
setblock 540 118 275 minecraft:white_concrete
setblock 540 118 317 minecraft:white_concrete
setblock 542 118 275 minecraft:white_concrete
setblock 542 118 317 minecraft:white_concrete
fill 543 118 275 543 125 275 minecraft:brown_terracotta
fill 543 118 317 543 125 317 minecraft:brown_terracotta
setblock 544 118 275 minecraft:white_concrete
setblock 544 118 317 minecraft:white_concrete
setblock 546 118 275 minecraft:white_concrete
setblock 546 118 317 minecraft:white_concrete
fill 547 118 275 547 122 275 minecraft:brown_terracotta
fill 547 118 317 547 125 317 minecraft:brown_terracotta
setblock 548 118 275 minecraft:white_concrete
setblock 548 118 317 minecraft:white_concrete
setblock 549 118 275 minecraft:brown_terracotta
setblock 550 118 275 minecraft:white_concrete
setblock 550 118 317 minecraft:white_concrete
fill 551 118 275 551 125 275 minecraft:brown_terracotta
fill 551 118 317 551 125 317 minecraft:brown_terracotta
setblock 552 118 275 minecraft:white_concrete
setblock 552 118 317 minecraft:white_concrete
setblock 554 118 275 minecraft:white_concrete
setblock 554 118 317 minecraft:white_concrete
fill 555 118 275 555 125 275 minecraft:brown_terracotta
fill 555 118 317 555 125 317 minecraft:brown_terracotta
setblock 556 118 275 minecraft:white_concrete
setblock 556 118 317 minecraft:white_concrete
setblock 558 118 275 minecraft:white_concrete
setblock 558 118 317 minecraft:white_concrete
setblock 559 118 275 minecraft:brown_terracotta
setblock 559 118 276 minecraft:white_concrete
fill 559 118 277 559 125 277 minecraft:brown_terracotta
setblock 559 118 278 minecraft:white_concrete
setblock 559 118 280 minecraft:white_concrete
fill 559 118 281 559 125 281 minecraft:brown_terracotta
setblock 559 118 282 minecraft:white_concrete
setblock 559 118 284 minecraft:white_concrete
fill 559 118 285 559 125 285 minecraft:brown_terracotta
setblock 559 118 286 minecraft:white_concrete
setblock 559 118 288 minecraft:white_concrete
fill 559 118 289 559 125 289 minecraft:brown_terracotta
setblock 559 118 290 minecraft:white_concrete
setblock 559 118 292 minecraft:white_concrete
fill 559 118 293 559 125 293 minecraft:brown_terracotta
setblock 559 118 294 minecraft:white_concrete
setblock 559 118 296 minecraft:white_concrete
fill 559 118 297 559 125 297 minecraft:brown_terracotta
setblock 559 118 298 minecraft:white_concrete
setblock 559 118 300 minecraft:white_concrete
fill 559 118 301 559 125 301 minecraft:brown_terracotta
setblock 559 118 302 minecraft:white_concrete
setblock 559 118 304 minecraft:white_concrete
fill 559 118 305 559 125 305 minecraft:brown_terracotta
setblock 559 118 306 minecraft:white_concrete
setblock 559 118 308 minecraft:white_concrete
fill 559 118 309 559 125 309 minecraft:brown_terracotta
setblock 559 118 310 minecraft:white_concrete
setblock 559 118 312 minecraft:white_concrete
fill 559 118 313 559 125 313 minecraft:brown_terracotta
setblock 559 118 314 minecraft:white_concrete
setblock 559 118 316 minecraft:white_concrete
fill 559 118 317 559 125 317 minecraft:brown_terracotta
setblock 517 119 275 minecraft:white_concrete
fill 517 119 276 517 126 276 minecraft:brown_terracotta
fill 517 119 278 517 126 278 minecraft:brown_terracotta
setblock 517 119 279 minecraft:white_concrete
fill 517 119 280 517 126 280 minecraft:brown_terracotta
fill 517 119 282 517 125 282 minecraft:brown_terracotta
setblock 517 119 283 minecraft:white_concrete
fill 517 119 284 517 125 284 minecraft:brown_terracotta
fill 517 119 286 517 126 286 minecraft:brown_terracotta
setblock 517 119 287 minecraft:white_concrete
fill 517 119 288 517 126 288 minecraft:brown_terracotta
fill 517 119 290 517 126 290 minecraft:brown_terracotta
setblock 517 119 291 minecraft:white_concrete
fill 517 119 292 517 126 292 minecraft:brown_terracotta
fill 517 119 294 517 125 294 minecraft:brown_terracotta
setblock 517 119 295 minecraft:white_concrete
setblock 517 119 299 minecraft:white_concrete
fill 517 119 300 517 126 300 minecraft:brown_terracotta
fill 517 119 302 517 126 302 minecraft:brown_terracotta
setblock 517 119 303 minecraft:white_concrete
fill 517 119 304 517 126 304 minecraft:brown_terracotta
fill 517 119 306 517 125 306 minecraft:brown_terracotta
setblock 517 119 307 minecraft:white_concrete
fill 517 119 308 517 125 308 minecraft:brown_terracotta
fill 517 119 310 517 126 310 minecraft:brown_terracotta
setblock 517 119 311 minecraft:white_concrete
fill 517 119 312 517 126 312 minecraft:brown_terracotta
fill 517 119 314 517 126 314 minecraft:brown_terracotta
setblock 517 119 315 minecraft:white_concrete
fill 517 119 316 517 126 316 minecraft:brown_terracotta
setblock 517 119 317 minecraft:white_concrete
fill 518 119 275 518 126 275 minecraft:brown_terracotta
fill 518 119 317 518 125 317 minecraft:brown_terracotta
fill 520 119 275 520 126 275 minecraft:brown_terracotta
fill 520 119 286 524 119 290 minecraft:orange_terracotta
fill 520 119 317 520 125 317 minecraft:brown_terracotta
setblock 521 119 275 minecraft:white_concrete
fill 521 119 277 527 120 277 minecraft:iron_block
setblock 521 119 300 minecraft:white_concrete
setblock 521 119 317 minecraft:white_concrete
fill 522 119 275 522 126 275 minecraft:brown_terracotta
fill 522 119 294 522 120 294 minecraft:orange_terracotta
fill 522 119 317 522 126 317 minecraft:brown_terracotta
fill 524 119 275 524 125 275 minecraft:brown_terracotta
fill 524 119 317 524 126 317 minecraft:brown_terracotta
setblock 525 119 275 minecraft:white_concrete
setblock 525 119 317 minecraft:white_concrete
fill 526 119 275 526 125 275 minecraft:brown_terracotta
fill 526 119 317 526 126 317 minecraft:brown_terracotta
fill 528 119 275 528 126 275 minecraft:brown_terracotta
fill 528 119 305 528 121 307 minecraft:spruce_leaves[persistent=true]
fill 528 119 317 528 126 317 minecraft:brown_terracotta
setblock 529 119 275 minecraft:white_concrete
fill 529 119 305 530 121 305 minecraft:spruce_leaves[persistent=true]
fill 529 119 307 529 121 308 minecraft:spruce_leaves[persistent=true]
setblock 529 119 317 minecraft:white_concrete
fill 530 119 275 530 126 275 minecraft:brown_terracotta
fill 530 119 306 530 121 307 minecraft:spruce_leaves[persistent=true]
fill 530 119 317 530 125 317 minecraft:brown_terracotta
fill 531 119 306 531 121 306 minecraft:spruce_leaves[persistent=true]
fill 532 119 275 532 126 275 minecraft:brown_terracotta
fill 532 119 317 532 125 317 minecraft:brown_terracotta
setblock 533 119 275 minecraft:white_concrete
setblock 533 119 317 minecraft:white_concrete
fill 534 119 275 534 126 275 minecraft:brown_terracotta
fill 534 119 317 534 126 317 minecraft:brown_terracotta
fill 536 119 275 536 125 275 minecraft:brown_terracotta
fill 536 119 317 536 126 317 minecraft:brown_terracotta
setblock 537 119 275 minecraft:white_concrete
setblock 537 119 317 minecraft:white_concrete
fill 538 119 275 538 125 275 minecraft:brown_terracotta
fill 538 119 317 538 126 317 minecraft:brown_terracotta
fill 540 119 275 540 126 275 minecraft:brown_terracotta
fill 540 119 317 540 126 317 minecraft:brown_terracotta
setblock 541 119 275 minecraft:white_concrete
setblock 541 119 317 minecraft:white_concrete
fill 542 119 275 542 126 275 minecraft:brown_terracotta
fill 542 119 317 542 125 317 minecraft:brown_terracotta
fill 544 119 275 544 126 275 minecraft:brown_terracotta
fill 544 119 317 544 125 317 minecraft:brown_terracotta
setblock 545 119 275 minecraft:white_concrete
setblock 545 119 317 minecraft:white_concrete
fill 546 119 275 546 126 275 minecraft:brown_terracotta
fill 546 119 317 546 126 317 minecraft:brown_terracotta
fill 548 119 275 548 122 275 minecraft:brown_terracotta
fill 548 119 317 548 126 317 minecraft:brown_terracotta
setblock 549 119 275 minecraft:white_concrete
setblock 549 119 317 minecraft:white_concrete
fill 550 119 275 550 125 275 minecraft:brown_terracotta
fill 550 119 317 550 126 317 minecraft:brown_terracotta
fill 552 119 275 552 126 275 minecraft:brown_terracotta
fill 552 119 317 552 126 317 minecraft:brown_terracotta
setblock 553 119 275 minecraft:white_concrete
setblock 553 119 317 minecraft:white_concrete
fill 554 119 275 554 126 275 minecraft:brown_terracotta
fill 554 119 317 554 125 317 minecraft:brown_terracotta
fill 556 119 275 556 126 275 minecraft:brown_terracotta
fill 556 119 317 556 125 317 minecraft:brown_terracotta
setblock 557 119 275 minecraft:white_concrete
setblock 557 119 317 minecraft:white_concrete
fill 558 119 275 558 126 275 minecraft:brown_terracotta
fill 558 119 317 558 126 317 minecraft:brown_terracotta
setblock 559 119 275 minecraft:white_concrete
fill 559 119 276 559 125 276 minecraft:brown_terracotta
fill 559 119 278 559 125 278 minecraft:brown_terracotta
setblock 559 119 279 minecraft:white_concrete
fill 559 119 280 559 126 280 minecraft:brown_terracotta
fill 559 119 282 559 126 282 minecraft:brown_terracotta
setblock 559 119 283 minecraft:white_concrete
fill 559 119 284 559 126 284 minecraft:brown_terracotta
fill 559 119 286 559 126 286 minecraft:brown_terracotta
setblock 559 119 287 minecraft:white_concrete
fill 559 119 288 559 125 288 minecraft:brown_terracotta
fill 559 119 290 559 125 290 minecraft:brown_terracotta
setblock 559 119 291 minecraft:white_concrete
fill 559 119 292 559 126 292 minecraft:brown_terracotta
fill 559 119 294 559 126 294 minecraft:brown_terracotta
setblock 559 119 295 minecraft:white_concrete
fill 559 119 296 559 126 296 minecraft:brown_terracotta
fill 559 119 298 559 126 298 minecraft:brown_terracotta
setblock 559 119 299 minecraft:white_concrete
fill 559 119 300 559 125 300 minecraft:brown_terracotta
fill 559 119 302 559 125 302 minecraft:brown_terracotta
setblock 559 119 303 minecraft:white_concrete
fill 559 119 304 559 126 304 minecraft:brown_terracotta
fill 559 119 306 559 126 306 minecraft:brown_terracotta
setblock 559 119 307 minecraft:white_concrete
fill 559 119 308 559 126 308 minecraft:brown_terracotta
fill 559 119 310 559 126 310 minecraft:brown_terracotta
setblock 559 119 311 minecraft:white_concrete
fill 559 119 312 559 125 312 minecraft:brown_terracotta
fill 559 119 314 559 125 314 minecraft:brown_terracotta
setblock 559 119 315 minecraft:white_concrete
fill 559 119 316 559 126 316 minecraft:brown_terracotta
fill 517 120 275 517 127 275 minecraft:brown_terracotta
fill 517 120 279 517 127 279 minecraft:brown_terracotta
fill 517 120 283 517 125 283 minecraft:brown_terracotta
fill 517 120 287 517 127 287 minecraft:brown_terracotta
fill 517 120 291 517 127 291 minecraft:brown_terracotta
fill 517 120 295 517 125 295 minecraft:brown_terracotta
fill 517 120 299 517 127 299 minecraft:brown_terracotta
fill 517 120 303 517 127 303 minecraft:brown_terracotta
fill 517 120 307 517 125 307 minecraft:brown_terracotta
fill 517 120 311 517 127 311 minecraft:brown_terracotta
fill 517 120 315 517 127 315 minecraft:brown_terracotta
fill 517 120 317 517 125 317 minecraft:brown_terracotta
fill 519 120 285 519 125 287 minecraft:white_concrete
fill 519 120 297 519 125 299 minecraft:white_concrete
fill 519 120 309 519 125 311 minecraft:white_concrete
fill 520 120 286 521 123 290 minecraft:orange_terracotta
fill 521 120 275 521 127 275 minecraft:brown_terracotta
fill 521 120 317 521 127 317 minecraft:brown_terracotta
fill 522 120 286 524 123 287 minecraft:orange_terracotta
fill 522 120 288 522 121 288 minecraft:ochre_froglight
fill 522 120 289 524 123 290 minecraft:orange_terracotta
fill 523 120 288 524 123 288 minecraft:orange_terracotta
fill 525 120 275 525 125 275 minecraft:brown_terracotta
fill 525 120 315 527 125 315 minecraft:white_concrete
fill 525 120 317 525 127 317 minecraft:brown_terracotta
fill 527 120 305 527 120 307 minecraft:spruce_leaves[persistent=true]
fill 528 120 304 530 120 304 minecraft:spruce_leaves[persistent=true]
setblock 528 120 308 minecraft:spruce_leaves[persistent=true]
fill 529 120 275 529 127 275 minecraft:brown_terracotta
fill 529 120 277 531 125 277 minecraft:white_concrete
fill 529 120 306 529 121 306 minecraft:spruce_leaves[persistent=true]
fill 529 120 317 529 125 317 minecraft:brown_terracotta
setblock 530 120 308 minecraft:spruce_leaves[persistent=true]
setblock 531 120 305 minecraft:spruce_leaves[persistent=true]
setblock 531 120 307 minecraft:spruce_leaves[persistent=true]
fill 533 120 275 533 127 275 minecraft:brown_terracotta
fill 533 120 317 533 127 317 minecraft:brown_terracotta
fill 537 120 275 537 125 275 minecraft:brown_terracotta
fill 537 120 315 539 125 315 minecraft:white_concrete
fill 537 120 317 537 127 317 minecraft:brown_terracotta
fill 541 120 275 541 127 275 minecraft:brown_terracotta
fill 541 120 277 543 125 277 minecraft:white_concrete
fill 541 120 317 541 125 317 minecraft:brown_terracotta
fill 545 120 275 545 127 275 minecraft:brown_terracotta
fill 545 120 317 545 127 317 minecraft:brown_terracotta
fill 549 120 275 549 122 275 minecraft:brown_terracotta
fill 549 120 315 551 125 315 minecraft:white_concrete
fill 549 120 317 549 127 317 minecraft:brown_terracotta
fill 553 120 275 553 127 275 minecraft:brown_terracotta
fill 553 120 277 555 125 277 minecraft:white_concrete
fill 553 120 317 553 125 317 minecraft:brown_terracotta
fill 557 120 275 557 127 275 minecraft:brown_terracotta
fill 557 120 285 557 125 287 minecraft:white_concrete
fill 557 120 297 557 125 299 minecraft:white_concrete
fill 557 120 309 557 125 311 minecraft:white_concrete
fill 557 120 317 557 127 317 minecraft:brown_terracotta
fill 559 120 275 559 125 275 minecraft:brown_terracotta
fill 559 120 279 559 125 279 minecraft:brown_terracotta
fill 559 120 283 559 127 283 minecraft:brown_terracotta
fill 559 120 287 559 127 287 minecraft:brown_terracotta
fill 559 120 291 559 125 291 minecraft:brown_terracotta
fill 559 120 295 559 127 295 minecraft:brown_terracotta
fill 559 120 299 559 127 299 minecraft:brown_terracotta
fill 559 120 303 559 125 303 minecraft:brown_terracotta
fill 559 120 307 559 127 307 minecraft:brown_terracotta
fill 559 120 311 559 127 311 minecraft:brown_terracotta
fill 559 120 315 559 125 315 minecraft:brown_terracotta
fill 520 121 292 524 121 296 minecraft:white_concrete
fill 545 121 276 551 121 280 minecraft:brown_terracotta
fill 517 122 296 517 125 298 minecraft:brown_terracotta
fill 521 122 292 523 122 296 minecraft:white_concrete
fill 522 122 288 522 123 288 minecraft:orange_terracotta
fill 545 122 276 551 122 280 minecraft:white_concrete
setblock 520 123 278 minecraft:light[level=15]
setblock 520 123 285 minecraft:light[level=12]
setblock 520 123 292 minecraft:light[level=12]
setblock 520 123 294 minecraft:light[level=15]
setblock 520 123 299 minecraft:light[level=12]
setblock 520 123 302 minecraft:light[level=15]
setblock 520 123 306 minecraft:light[level=12]
setblock 520 123 310 minecraft:light[level=15]
setblock 520 123 313 minecraft:light[level=12]
fill 522 123 292 522 123 296 minecraft:white_concrete
setblock 527 123 278 minecraft:light[level=12]
setblock 527 123 285 minecraft:light[level=12]
setblock 527 123 292 minecraft:light[level=12]
setblock 527 123 299 minecraft:light[level=12]
setblock 527 123 306 minecraft:light[level=12]
setblock 527 123 313 minecraft:light[level=12]
setblock 528 123 278 minecraft:light[level=15]
setblock 528 123 286 minecraft:light[level=15]
setblock 528 123 294 minecraft:light[level=15]
setblock 528 123 302 minecraft:light[level=15]
setblock 528 123 310 minecraft:light[level=15]
setblock 534 123 278 minecraft:light[level=12]
setblock 534 123 285 minecraft:light[level=12]
setblock 534 123 292 minecraft:light[level=12]
setblock 534 123 299 minecraft:light[level=12]
setblock 534 123 306 minecraft:light[level=12]
setblock 534 123 313 minecraft:light[level=12]
setblock 536 123 278 minecraft:light[level=15]
setblock 536 123 286 minecraft:light[level=15]
setblock 536 123 294 minecraft:light[level=15]
setblock 536 123 302 minecraft:light[level=15]
setblock 536 123 310 minecraft:light[level=15]
setblock 541 123 278 minecraft:light[level=12]
setblock 541 123 285 minecraft:light[level=12]
setblock 541 123 292 minecraft:light[level=12]
setblock 541 123 299 minecraft:light[level=12]
setblock 541 123 306 minecraft:light[level=12]
setblock 541 123 313 minecraft:light[level=12]
setblock 544 123 278 minecraft:light[level=15]
setblock 544 123 286 minecraft:light[level=15]
setblock 544 123 294 minecraft:light[level=15]
setblock 544 123 302 minecraft:light[level=15]
setblock 544 123 310 minecraft:light[level=15]
fill 545 123 280 551 123 280 minecraft:red_concrete
fill 547 123 275 549 126 275 minecraft:shroomlight
fill 547 123 289 547 124 290 minecraft:red_concrete
setblock 548 123 278 minecraft:light[level=12]
setblock 548 123 285 minecraft:light[level=12]
fill 548 123 289 548 124 289 minecraft:red_concrete
setblock 548 123 292 minecraft:light[level=12]
setblock 548 123 299 minecraft:light[level=12]
setblock 548 123 306 minecraft:light[level=12]
setblock 548 123 313 minecraft:light[level=12]
setblock 552 123 278 minecraft:light[level=15]
setblock 552 123 286 minecraft:light[level=15]
setblock 552 123 294 minecraft:light[level=15]
setblock 552 123 302 minecraft:light[level=15]
setblock 552 123 310 minecraft:light[level=15]
setblock 555 123 278 minecraft:light[level=12]
setblock 555 123 285 minecraft:light[level=12]
setblock 555 123 292 minecraft:light[level=12]
setblock 555 123 299 minecraft:light[level=12]
setblock 555 123 306 minecraft:light[level=12]
setblock 555 123 313 minecraft:light[level=12]
fill 520 124 286 524 124 290 minecraft:white_concrete
setblock 545 124 280 minecraft:white_concrete
setblock 548 124 280 minecraft:white_concrete
fill 549 124 299 549 125 300 minecraft:lime_concrete
setblock 551 124 280 minecraft:white_concrete
fill 518 125 279 518 125 284 minecraft:brown_terracotta
fill 518 125 291 518 125 296 minecraft:brown_terracotta
fill 518 125 303 518 125 308 minecraft:brown_terracotta
fill 518 125 315 518 125 316 minecraft:brown_terracotta
fill 519 125 316 522 125 316 minecraft:brown_terracotta
fill 521 125 286 523 125 290 minecraft:white_concrete
fill 522 125 276 527 125 276 minecraft:brown_terracotta
fill 529 125 316 534 125 316 minecraft:brown_terracotta
fill 534 125 276 539 125 276 minecraft:brown_terracotta
fill 541 125 316 546 125 316 minecraft:brown_terracotta
fill 546 125 276 551 125 276 minecraft:brown_terracotta
fill 553 125 316 558 125 316 minecraft:brown_terracotta
fill 558 125 276 558 125 281 minecraft:brown_terracotta
fill 558 125 288 558 125 293 minecraft:brown_terracotta
fill 558 125 300 558 125 305 minecraft:brown_terracotta
fill 558 125 312 558 125 315 minecraft:brown_terracotta
setblock 517 126 277 minecraft:white_concrete
fill 517 126 281 517 131 284 minecraft:shroomlight
setblock 517 126 285 minecraft:white_concrete
setblock 517 126 289 minecraft:white_concrete
fill 517 126 293 517 131 296 minecraft:shroomlight
setblock 517 126 297 minecraft:white_concrete
setblock 517 126 298 minecraft:brown_terracotta
setblock 517 126 301 minecraft:white_concrete
fill 517 126 305 517 131 308 minecraft:shroomlight
setblock 517 126 309 minecraft:white_concrete
setblock 517 126 313 minecraft:white_concrete
fill 517 126 317 520 131 317 minecraft:shroomlight
setblock 519 126 275 minecraft:white_concrete
fill 522 126 286 522 126 290 minecraft:white_concrete
setblock 523 126 275 minecraft:white_concrete
setblock 523 126 317 minecraft:white_concrete
fill 524 126 275 527 131 275 minecraft:shroomlight
setblock 527 126 317 minecraft:white_concrete
fill 529 126 317 532 131 317 minecraft:shroomlight
setblock 531 126 275 minecraft:white_concrete
setblock 535 126 275 minecraft:white_concrete
setblock 535 126 317 minecraft:white_concrete
fill 536 126 275 539 131 275 minecraft:shroomlight
setblock 539 126 317 minecraft:white_concrete
fill 541 126 317 544 131 317 minecraft:shroomlight
setblock 543 126 275 minecraft:white_concrete
setblock 547 126 317 minecraft:white_concrete
fill 550 126 275 551 131 275 minecraft:shroomlight
setblock 551 126 317 minecraft:white_concrete
schedule function dropper:buildpart/71_2 1t
