setblock 494 165 489 minecraft:magma_block
fill 494 165 494 494 166 494 minecraft:blackstone
fill 495 165 481 495 173 499 minecraft:oak_planks
fill 495 165 501 505 169 501 minecraft:blackstone
fill 496 165 481 504 173 499 minecraft:smooth_stone
fill 496 165 502 504 169 502 minecraft:blackstone
fill 497 165 503 503 170 503 minecraft:blackstone
fill 499 165 476 502 169 480 minecraft:blackstone
fill 503 165 477 503 170 480 minecraft:blackstone
fill 504 165 479 505 170 480 minecraft:blackstone
fill 505 165 481 505 170 487 minecraft:blackstone
fill 505 165 489 506 170 493 minecraft:blackstone
fill 505 165 494 505 170 494 minecraft:orange_concrete
fill 505 165 495 506 170 499 minecraft:blackstone
fill 506 165 481 506 170 486 minecraft:blackstone
fill 506 165 488 508 170 488 minecraft:blackstone
fill 506 165 494 508 170 494 minecraft:blackstone
fill 507 165 482 507 170 485 minecraft:blackstone
fill 507 165 487 508 170 487 minecraft:blackstone
fill 507 165 489 508 170 492 minecraft:blackstone
fill 507 165 495 507 170 498 minecraft:blackstone
fill 508 165 486 508 170 486 minecraft:blackstone
fill 508 165 495 508 170 495 minecraft:blackstone
setblock 473 166 466 minecraft:light[level=14]
setblock 473 166 474 minecraft:light[level=14]
setblock 473 166 482 minecraft:light[level=14]
setblock 473 166 498 minecraft:light[level=14]
setblock 481 166 466 minecraft:light[level=14]
setblock 481 166 474 minecraft:light[level=14]
setblock 489 166 466 minecraft:light[level=14]
setblock 489 166 490 minecraft:light[level=14]
setblock 497 166 466 minecraft:light[level=14]
setblock 505 166 466 minecraft:light[level=14]
setblock 505 166 474 minecraft:light[level=14]
fill 489 167 481 489 167 483 minecraft:blackstone
fill 489 167 497 491 167 499 minecraft:blackstone
fill 490 167 483 494 167 483 minecraft:blackstone
fill 491 167 482 494 167 482 minecraft:blackstone
fill 492 167 497 494 167 497 minecraft:blackstone
fill 471 168 470 471 168 472 minecraft:red_terracotta
setblock 471 168 473 minecraft:terracotta
fill 471 168 474 471 168 477 minecraft:red_terracotta
setblock 471 168 478 minecraft:terracotta
fill 471 168 479 471 168 482 minecraft:red_terracotta
setblock 471 168 483 minecraft:terracotta
fill 471 168 484 471 168 487 minecraft:red_terracotta
setblock 471 168 488 minecraft:terracotta
fill 471 168 489 471 168 492 minecraft:red_terracotta
setblock 471 168 493 minecraft:terracotta
fill 471 168 494 471 168 497 minecraft:red_terracotta
setblock 471 168 498 minecraft:terracotta
fill 471 168 499 471 168 502 minecraft:red_terracotta
setblock 471 168 503 minecraft:terracotta
setblock 472 168 472 minecraft:terracotta
fill 472 168 473 472 168 476 minecraft:red_terracotta
setblock 472 168 477 minecraft:terracotta
fill 472 168 478 472 168 481 minecraft:red_terracotta
setblock 472 168 482 minecraft:terracotta
fill 472 168 483 472 168 486 minecraft:red_terracotta
fill 472 168 494 472 168 496 minecraft:red_terracotta
setblock 472 168 497 minecraft:terracotta
fill 472 168 498 472 168 501 minecraft:red_terracotta
fill 472 168 504 474 168 504 minecraft:red_terracotta
fill 473 168 473 473 168 475 minecraft:red_terracotta
setblock 473 168 476 minecraft:terracotta
fill 473 168 477 473 168 480 minecraft:red_terracotta
setblock 473 168 481 minecraft:terracotta
fill 473 168 482 473 170 483 minecraft:red_terracotta
setblock 474 168 464 minecraft:red_terracotta
setblock 474 168 474 minecraft:red_terracotta
setblock 474 168 475 minecraft:terracotta
fill 474 168 476 474 168 479 minecraft:red_terracotta
setblock 474 168 480 minecraft:terracotta
fill 474 168 481 474 171 481 minecraft:red_terracotta
setblock 475 168 464 minecraft:terracotta
setblock 475 168 503 minecraft:red_terracotta
setblock 475 168 504 minecraft:terracotta
fill 476 168 464 479 168 464 minecraft:red_terracotta
setblock 476 168 503 minecraft:terracotta
fill 476 168 504 479 168 504 minecraft:red_terracotta
fill 477 168 503 478 168 503 minecraft:red_terracotta
setblock 480 168 464 minecraft:terracotta
fill 481 168 464 483 168 464 minecraft:red_terracotta
fill 488 168 464 489 168 464 minecraft:red_terracotta
setblock 489 168 481 minecraft:blackstone
setblock 489 168 499 minecraft:blackstone
setblock 490 168 464 minecraft:terracotta
fill 491 168 464 494 168 464 minecraft:red_terracotta
setblock 493 168 465 minecraft:red_terracotta
fill 493 168 481 494 168 481 minecraft:blackstone
fill 493 168 499 494 168 499 minecraft:blackstone
setblock 494 168 465 minecraft:terracotta
setblock 495 168 464 minecraft:terracotta
fill 495 168 465 497 168 465 minecraft:red_terracotta
fill 496 168 464 499 168 464 minecraft:red_terracotta
setblock 500 168 464 minecraft:terracotta
setblock 501 168 464 minecraft:red_terracotta
fill 503 168 504 504 168 504 minecraft:red_terracotta
setblock 504 168 503 minecraft:red_terracotta
setblock 505 168 504 minecraft:terracotta
fill 506 168 504 509 168 504 minecraft:red_terracotta
setblock 510 168 478 minecraft:red_terracotta
setblock 510 168 479 minecraft:terracotta
fill 510 168 480 511 170 480 minecraft:red_terracotta
setblock 510 168 493 minecraft:red_terracotta
setblock 510 168 494 minecraft:terracotta
fill 510 168 495 510 168 498 minecraft:red_terracotta
setblock 510 168 499 minecraft:terracotta
fill 510 168 500 511 168 502 minecraft:red_terracotta
setblock 510 168 504 minecraft:terracotta
setblock 511 168 473 minecraft:terracotta
fill 511 168 474 511 168 477 minecraft:red_terracotta
setblock 511 168 478 minecraft:terracotta
fill 511 168 479 511 171 479 minecraft:red_terracotta
fill 511 168 481 511 168 482 minecraft:red_terracotta
setblock 511 168 483 minecraft:terracotta
fill 511 168 484 511 168 487 minecraft:red_terracotta
setblock 511 168 488 minecraft:terracotta
fill 511 168 489 511 168 492 minecraft:red_terracotta
setblock 511 168 493 minecraft:terracotta
fill 511 168 494 511 168 497 minecraft:red_terracotta
setblock 511 168 498 minecraft:terracotta
fill 511 168 499 511 171 499 minecraft:red_terracotta
setblock 511 168 503 minecraft:terracotta
fill 511 168 504 511 171 504 minecraft:red_terracotta
setblock 471 169 471 minecraft:red_terracotta
setblock 471 169 472 minecraft:terracotta
fill 471 169 473 471 169 476 minecraft:red_terracotta
setblock 471 169 477 minecraft:terracotta
fill 471 169 478 471 169 481 minecraft:red_terracotta
setblock 471 169 482 minecraft:terracotta
fill 471 169 483 471 169 486 minecraft:red_terracotta
setblock 471 169 487 minecraft:terracotta
fill 471 169 488 471 169 491 minecraft:red_terracotta
setblock 471 169 492 minecraft:terracotta
fill 471 169 493 471 169 496 minecraft:red_terracotta
setblock 471 169 497 minecraft:terracotta
fill 471 169 498 471 169 501 minecraft:red_terracotta
setblock 471 169 502 minecraft:terracotta
fill 471 169 503 471 172 503 minecraft:red_terracotta
fill 472 169 472 472 169 475 minecraft:red_terracotta
setblock 472 169 476 minecraft:terracotta
fill 472 169 477 472 169 480 minecraft:red_terracotta
setblock 472 169 481 minecraft:terracotta
fill 472 169 482 472 169 485 minecraft:red_terracotta
setblock 472 169 486 minecraft:terracotta
setblock 472 169 496 minecraft:terracotta
fill 472 169 497 472 169 500 minecraft:red_terracotta
setblock 472 169 501 minecraft:terracotta
fill 472 169 504 473 169 504 minecraft:red_terracotta
setblock 473 169 464 minecraft:red_terracotta
fill 473 169 473 473 169 474 minecraft:red_terracotta
setblock 473 169 475 minecraft:terracotta
fill 473 169 476 473 169 479 minecraft:red_terracotta
setblock 473 169 480 minecraft:terracotta
fill 473 169 481 473 172 481 minecraft:red_terracotta
setblock 473 169 484 minecraft:red_terracotta
setblock 474 169 464 minecraft:terracotta
fill 474 169 475 474 169 478 minecraft:red_terracotta
setblock 474 169 479 minecraft:terracotta
fill 474 169 480 474 172 480 minecraft:red_terracotta
setblock 474 169 504 minecraft:terracotta
fill 475 169 464 478 169 464 minecraft:red_terracotta
setblock 475 169 503 minecraft:terracotta
fill 475 169 504 478 169 504 minecraft:red_terracotta
fill 476 169 503 477 169 503 minecraft:red_terracotta
setblock 479 169 464 minecraft:terracotta
fill 479 169 480 485 169 480 minecraft:blackstone
setblock 479 169 504 minecraft:terracotta
fill 480 169 464 482 169 464 minecraft:red_terracotta
fill 485 169 500 485 169 504 minecraft:blackstone
fill 486 169 501 488 169 504 minecraft:blackstone
setblock 488 169 464 minecraft:red_terracotta
setblock 489 169 464 minecraft:terracotta
setblock 489 169 502 minecraft:orange_concrete
fill 490 169 464 493 169 464 minecraft:red_terracotta
fill 490 169 502 493 169 503 minecraft:blackstone
setblock 493 169 465 minecraft:terracotta
setblock 493 169 478 minecraft:orange_concrete
setblock 494 169 464 minecraft:terracotta
fill 494 169 465 496 170 465 minecraft:red_terracotta
fill 495 169 464 498 169 464 minecraft:red_terracotta
setblock 497 169 480 minecraft:blackstone
fill 497 169 500 503 169 500 minecraft:blackstone
setblock 499 169 464 minecraft:terracotta
setblock 500 169 464 minecraft:red_terracotta
setblock 503 169 504 minecraft:red_terracotta
setblock 504 169 504 minecraft:terracotta
fill 505 169 504 508 169 504 minecraft:red_terracotta
setblock 509 169 504 minecraft:terracotta
setblock 510 169 478 minecraft:terracotta
fill 510 169 479 510 172 479 minecraft:red_terracotta
fill 510 169 481 510 169 482 minecraft:red_terracotta
fill 510 169 494 510 169 497 minecraft:red_terracotta
setblock 510 169 498 minecraft:terracotta
fill 510 169 499 510 169 502 minecraft:red_terracotta
fill 510 169 504 510 172 504 minecraft:red_terracotta
fill 511 169 474 511 169 476 minecraft:red_terracotta
setblock 511 169 477 minecraft:terracotta
fill 511 169 478 511 172 478 minecraft:red_terracotta
setblock 511 169 481 minecraft:red_terracotta
setblock 511 169 482 minecraft:terracotta
fill 511 169 483 511 169 486 minecraft:red_terracotta
setblock 511 169 487 minecraft:terracotta
fill 511 169 488 511 169 491 minecraft:red_terracotta
setblock 511 169 492 minecraft:terracotta
fill 511 169 493 511 169 496 minecraft:red_terracotta
setblock 511 169 497 minecraft:terracotta
fill 511 169 498 511 172 498 minecraft:red_terracotta
fill 511 169 500 511 169 501 minecraft:red_terracotta
setblock 511 169 502 minecraft:terracotta
fill 511 169 503 511 172 503 minecraft:red_terracotta
setblock 471 170 471 minecraft:terracotta
fill 471 170 472 471 170 475 minecraft:red_terracotta
setblock 471 170 476 minecraft:terracotta
fill 471 170 477 471 170 480 minecraft:red_terracotta
setblock 471 170 481 minecraft:terracotta
fill 471 170 482 471 170 485 minecraft:red_terracotta
setblock 471 170 486 minecraft:terracotta
fill 471 170 487 471 171 489 minecraft:red_terracotta
fill 471 170 493 471 170 495 minecraft:red_terracotta
setblock 471 170 496 minecraft:terracotta
fill 471 170 497 471 170 500 minecraft:red_terracotta
setblock 471 170 501 minecraft:terracotta
fill 471 170 502 471 173 502 minecraft:red_terracotta
fill 471 170 504 472 170 504 minecraft:red_terracotta
fill 472 170 472 472 170 474 minecraft:red_terracotta
setblock 472 170 475 minecraft:terracotta
fill 472 170 476 472 170 479 minecraft:red_terracotta
setblock 472 170 480 minecraft:terracotta
fill 472 170 481 472 170 484 minecraft:red_terracotta
setblock 472 170 485 minecraft:terracotta
fill 472 170 486 472 173 486 minecraft:red_terracotta
setblock 472 170 499 minecraft:red_terracotta
setblock 472 170 500 minecraft:terracotta
setblock 473 170 464 minecraft:terracotta
setblock 473 170 474 minecraft:terracotta
fill 473 170 475 473 170 478 minecraft:red_terracotta
setblock 473 170 479 minecraft:terracotta
fill 473 170 480 473 173 480 minecraft:red_terracotta
setblock 473 170 484 minecraft:terracotta
setblock 473 170 504 minecraft:terracotta
fill 474 170 464 477 170 464 minecraft:red_terracotta
fill 474 170 476 474 170 477 minecraft:red_terracotta
setblock 474 170 478 minecraft:terracotta
fill 474 170 479 474 173 479 minecraft:red_terracotta
setblock 474 170 503 minecraft:terracotta
fill 474 170 504 477 170 504 minecraft:red_terracotta
fill 475 170 503 476 172 503 minecraft:red_terracotta
setblock 478 170 464 minecraft:terracotta
setblock 478 170 504 minecraft:terracotta
fill 479 170 464 481 171 464 minecraft:red_terracotta
fill 479 170 480 482 170 480 minecraft:blackstone
fill 479 170 500 482 170 502 minecraft:blackstone
fill 479 170 504 479 173 504 minecraft:red_terracotta
fill 482 170 476 483 170 479 minecraft:blackstone
fill 483 170 501 483 170 502 minecraft:blackstone
fill 484 170 476 484 170 478 minecraft:blackstone
fill 484 170 502 484 170 504 minecraft:orange_concrete
fill 485 170 476 485 170 477 minecraft:blackstone
fill 485 170 503 487 170 504 minecraft:blackstone
setblock 487 170 477 minecraft:blackstone
setblock 488 170 464 minecraft:terracotta
fill 488 170 504 489 170 504 minecraft:blackstone
fill 489 170 464 492 170 464 minecraft:red_terracotta
setblock 489 170 503 minecraft:terracotta
fill 490 170 503 493 170 503 minecraft:red_terracotta
fill 491 170 502 494 170 502 minecraft:red_terracotta
setblock 492 170 465 minecraft:terracotta
setblock 493 170 464 minecraft:terracotta
fill 493 170 465 493 173 465 minecraft:red_terracotta
fill 494 170 464 497 170 464 minecraft:red_terracotta
fill 494 170 501 495 170 501 minecraft:red_terracotta
setblock 494 170 503 minecraft:terracotta
fill 495 170 477 497 170 477 minecraft:blackstone
setblock 495 170 502 minecraft:terracotta
setblock 496 170 501 minecraft:terracotta
fill 496 170 502 497 172 502 minecraft:red_terracotta
fill 497 170 501 498 170 501 minecraft:red_terracotta
setblock 498 170 464 minecraft:terracotta
fill 498 170 476 498 170 478 minecraft:orange_concrete
fill 498 170 502 504 170 502 minecraft:blackstone
fill 499 170 464 499 173 464 minecraft:red_terracotta
fill 499 170 476 502 170 479 minecraft:blackstone
fill 499 170 501 505 170 501 minecraft:blackstone
fill 500 170 480 502 170 480 minecraft:blackstone
fill 500 170 500 503 170 500 minecraft:blackstone
setblock 503 170 504 minecraft:terracotta
fill 504 170 504 507 170 504 minecraft:red_terracotta
setblock 508 170 504 minecraft:terracotta
fill 509 170 504 509 173 504 minecraft:red_terracotta
fill 510 170 478 510 173 478 minecraft:red_terracotta
setblock 510 170 481 minecraft:red_terracotta
setblock 510 170 482 minecraft:terracotta
fill 510 170 483 511 172 483 minecraft:red_terracotta
setblock 510 170 496 minecraft:red_terracotta
setblock 510 170 497 minecraft:terracotta
fill 510 170 498 510 170 501 minecraft:red_terracotta
setblock 510 170 502 minecraft:terracotta
fill 511 170 474 511 170 475 minecraft:red_terracotta
setblock 511 170 476 minecraft:terracotta
fill 511 170 477 511 173 477 minecraft:red_terracotta
setblock 511 170 481 minecraft:terracotta
fill 511 170 482 511 173 482 minecraft:red_terracotta
fill 511 170 484 511 170 485 minecraft:red_terracotta
setblock 511 170 486 minecraft:terracotta
fill 511 170 487 511 170 490 minecraft:red_terracotta
setblock 511 170 491 minecraft:terracotta
fill 511 170 492 511 170 495 minecraft:red_terracotta
setblock 511 170 496 minecraft:terracotta
fill 511 170 497 511 173 497 minecraft:red_terracotta
setblock 511 170 500 minecraft:red_terracotta
setblock 511 170 501 minecraft:terracotta
fill 511 170 502 511 173 502 minecraft:red_terracotta
fill 471 171 471 471 171 474 minecraft:red_terracotta
setblock 471 171 475 minecraft:terracotta
fill 471 171 476 471 171 479 minecraft:red_terracotta
setblock 471 171 480 minecraft:terracotta
fill 471 171 481 471 171 484 minecraft:red_terracotta
setblock 471 171 485 minecraft:terracotta
fill 471 171 486 471 174 486 minecraft:red_terracotta
setblock 471 171 495 minecraft:terracotta
fill 471 171 496 471 171 499 minecraft:red_terracotta
setblock 471 171 500 minecraft:terracotta
fill 471 171 501 471 174 501 minecraft:red_terracotta
setblock 471 171 504 minecraft:red_terracotta
setblock 472 171 464 minecraft:terracotta
setblock 472 171 473 minecraft:red_terracotta
setblock 472 171 474 minecraft:terracotta
fill 472 171 475 472 171 478 minecraft:red_terracotta
setblock 472 171 479 minecraft:terracotta
fill 472 171 480 472 171 483 minecraft:red_terracotta
setblock 472 171 484 minecraft:terracotta
fill 472 171 485 472 174 485 minecraft:red_terracotta
setblock 472 171 504 minecraft:terracotta
fill 473 171 464 476 171 464 minecraft:red_terracotta
fill 473 171 475 473 171 477 minecraft:red_terracotta
setblock 473 171 478 minecraft:terracotta
fill 473 171 479 473 174 479 minecraft:red_terracotta
setblock 473 171 482 minecraft:red_terracotta
setblock 473 171 483 minecraft:terracotta
fill 473 171 484 473 174 484 minecraft:red_terracotta
fill 473 171 504 476 171 504 minecraft:red_terracotta
setblock 474 171 477 minecraft:terracotta
fill 474 171 478 474 172 478 minecraft:red_terracotta
fill 474 171 503 474 174 503 minecraft:red_terracotta
setblock 477 171 464 minecraft:terracotta
setblock 477 171 504 minecraft:terracotta
fill 478 171 464 478 174 464 minecraft:red_terracotta
fill 478 171 504 478 174 504 minecraft:red_terracotta
fill 480 171 504 480 172 504 minecraft:red_terracotta
fill 482 171 505 500 225 505 minecraft:red_terracotta
setblock 486 171 504 minecraft:red_terracotta
setblock 487 171 464 minecraft:terracotta
setblock 487 171 504 minecraft:terracotta
fill 488 171 464 491 171 464 minecraft:red_terracotta
setblock 488 171 503 minecraft:terracotta
fill 488 171 504 491 171 504 minecraft:red_terracotta
fill 489 171 503 492 171 503 minecraft:red_terracotta
fill 491 171 502 493 171 502 minecraft:red_terracotta
setblock 492 171 464 minecraft:terracotta
fill 492 171 465 492 174 465 minecraft:red_terracotta
setblock 492 171 504 minecraft:terracotta
fill 493 171 464 496 171 464 minecraft:red_terracotta
setblock 493 171 503 minecraft:terracotta
fill 493 171 504 496 171 504 minecraft:red_terracotta
fill 494 171 465 495 171 465 minecraft:red_terracotta
setblock 494 171 501 minecraft:red_terracotta
setblock 494 171 502 minecraft:terracotta
fill 494 171 503 497 171 503 minecraft:red_terracotta
setblock 495 171 501 minecraft:terracotta
fill 495 171 502 495 174 502 minecraft:red_terracotta
fill 496 171 501 497 171 501 minecraft:red_terracotta
setblock 497 171 464 minecraft:terracotta
setblock 497 171 504 minecraft:terracotta
fill 498 171 464 498 174 464 minecraft:red_terracotta
setblock 498 171 502 minecraft:red_terracotta
setblock 498 171 503 minecraft:terracotta
fill 498 171 504 501 171 504 minecraft:red_terracotta
setblock 499 171 502 minecraft:terracotta
fill 499 171 503 502 171 503 minecraft:red_terracotta
setblock 500 171 502 minecraft:red_terracotta
setblock 502 171 504 minecraft:terracotta
fill 503 171 504 506 171 504 minecraft:red_terracotta
setblock 507 171 504 minecraft:terracotta
fill 508 171 504 508 174 504 minecraft:red_terracotta
setblock 510 171 480 minecraft:red_terracotta
setblock 510 171 481 minecraft:terracotta
fill 510 171 482 510 174 482 minecraft:red_terracotta
fill 510 171 484 510 171 485 minecraft:red_terracotta
fill 510 171 497 510 171 500 minecraft:red_terracotta
setblock 510 171 501 minecraft:terracotta
fill 510 171 502 510 174 502 minecraft:red_terracotta
setblock 511 171 474 minecraft:red_terracotta
setblock 511 171 475 minecraft:terracotta
fill 511 171 476 511 174 476 minecraft:red_terracotta
setblock 511 171 480 minecraft:terracotta
fill 511 171 481 511 174 481 minecraft:red_terracotta
setblock 511 171 484 minecraft:red_terracotta
setblock 511 171 485 minecraft:terracotta
fill 511 171 486 511 171 489 minecraft:red_terracotta
setblock 511 171 490 minecraft:terracotta
fill 511 171 491 511 171 494 minecraft:red_terracotta
setblock 511 171 495 minecraft:terracotta
fill 511 171 496 511 174 496 minecraft:red_terracotta
setblock 511 171 500 minecraft:terracotta
fill 511 171 501 511 174 501 minecraft:red_terracotta
setblock 471 172 464 minecraft:terracotta
fill 471 172 465 471 175 465 minecraft:red_terracotta
fill 471 172 470 471 172 473 minecraft:red_terracotta
setblock 471 172 474 minecraft:terracotta
fill 471 172 475 471 172 478 minecraft:red_terracotta
setblock 471 172 479 minecraft:terracotta
fill 471 172 480 471 172 483 minecraft:red_terracotta
setblock 471 172 484 minecraft:terracotta
fill 471 172 485 471 175 485 minecraft:red_terracotta
fill 471 172 487 471 172 488 minecraft:red_terracotta
setblock 471 172 489 minecraft:terracotta
fill 471 172 497 471 172 498 minecraft:red_terracotta
setblock 471 172 499 minecraft:terracotta
fill 471 172 500 471 175 500 minecraft:red_terracotta
setblock 471 172 504 minecraft:terracotta
fill 472 172 464 475 172 464 minecraft:red_terracotta
setblock 472 172 473 minecraft:terracotta
fill 472 172 474 472 172 477 minecraft:red_terracotta
setblock 472 172 478 minecraft:terracotta
fill 472 172 479 472 172 482 minecraft:red_terracotta
setblock 472 172 483 minecraft:terracotta
fill 472 172 484 472 175 484 minecraft:red_terracotta
setblock 472 172 487 minecraft:red_terracotta
fill 472 172 504 475 172 504 minecraft:red_terracotta
fill 473 172 475 473 172 476 minecraft:red_terracotta
setblock 473 172 477 minecraft:terracotta
fill 473 172 478 473 175 478 minecraft:red_terracotta
setblock 473 172 482 minecraft:terracotta
fill 473 172 483 473 175 483 minecraft:red_terracotta
fill 473 172 503 473 175 503 minecraft:red_terracotta
setblock 474 172 481 minecraft:terracotta
setblock 476 172 464 minecraft:terracotta
setblock 476 172 504 minecraft:terracotta
fill 477 172 464 477 175 464 minecraft:red_terracotta
fill 477 172 504 477 175 504 minecraft:red_terracotta
fill 479 172 464 480 172 464 minecraft:red_terracotta
setblock 481 172 464 minecraft:terracotta
setblock 481 172 504 minecraft:terracotta
fill 482 172 464 482 175 464 minecraft:red_terracotta
fill 484 172 504 485 172 504 minecraft:red_terracotta
setblock 485 172 464 minecraft:red_terracotta
setblock 486 172 464 minecraft:terracotta
setblock 486 172 504 minecraft:terracotta
fill 487 172 464 490 172 464 minecraft:red_terracotta
fill 487 172 504 490 172 504 minecraft:red_terracotta
fill 488 172 503 491 172 503 minecraft:red_terracotta
fill 490 172 502 492 172 502 minecraft:red_terracotta
setblock 491 172 464 minecraft:terracotta
fill 491 172 465 491 175 465 minecraft:red_terracotta
setblock 491 172 504 minecraft:terracotta
fill 492 172 464 495 172 464 minecraft:red_terracotta
setblock 492 172 503 minecraft:terracotta
fill 492 172 504 495 172 504 minecraft:red_terracotta
setblock 493 172 501 minecraft:red_terracotta
setblock 493 172 502 minecraft:terracotta
fill 493 172 503 496 172 503 minecraft:red_terracotta
setblock 494 172 465 minecraft:red_terracotta
setblock 494 172 501 minecraft:terracotta
fill 494 172 502 494 175 502 minecraft:red_terracotta
setblock 495 172 465 minecraft:terracotta
fill 495 172 501 496 172 501 minecraft:red_terracotta
setblock 496 172 464 minecraft:terracotta
setblock 496 172 504 minecraft:terracotta
fill 497 172 464 497 175 464 minecraft:red_terracotta
setblock 497 172 503 minecraft:terracotta
fill 497 172 504 500 172 504 minecraft:red_terracotta
setblock 498 172 502 minecraft:terracotta
fill 498 172 503 501 172 503 minecraft:red_terracotta
fill 499 172 502 499 173 502 minecraft:red_terracotta
setblock 501 172 504 minecraft:terracotta
setblock 502 172 503 minecraft:terracotta
fill 502 172 504 505 172 504 minecraft:red_terracotta
setblock 506 172 504 minecraft:terracotta
fill 507 172 504 507 175 504 minecraft:red_terracotta
setblock 510 172 480 minecraft:terracotta
fill 510 172 481 510 175 481 minecraft:red_terracotta
setblock 510 172 484 minecraft:red_terracotta
setblock 510 172 485 minecraft:terracotta
fill 510 172 486 511 174 486 minecraft:red_terracotta
fill 510 172 498 510 172 499 minecraft:red_terracotta
setblock 510 172 500 minecraft:terracotta
fill 510 172 501 510 175 501 minecraft:red_terracotta
fill 510 172 503 510 173 503 minecraft:red_terracotta
setblock 511 172 474 minecraft:terracotta
fill 511 172 475 511 175 475 minecraft:red_terracotta
setblock 511 172 479 minecraft:terracotta
fill 511 172 480 511 175 480 minecraft:red_terracotta
setblock 511 172 484 minecraft:terracotta
fill 511 172 485 511 175 485 minecraft:red_terracotta
fill 511 172 487 511 172 488 minecraft:red_terracotta
setblock 511 172 489 minecraft:terracotta
fill 511 172 490 511 172 493 minecraft:red_terracotta
setblock 511 172 494 minecraft:terracotta
fill 511 172 495 511 175 495 minecraft:red_terracotta
setblock 511 172 499 minecraft:terracotta
fill 511 172 500 511 175 500 minecraft:red_terracotta
setblock 511 172 504 minecraft:terracotta
fill 471 173 464 474 173 464 minecraft:red_terracotta
fill 471 173 466 471 173 467 minecraft:red_terracotta
setblock 471 173 468 minecraft:terracotta
fill 471 173 469 471 173 472 minecraft:red_terracotta
setblock 471 173 473 minecraft:terracotta
fill 471 173 474 471 173 477 minecraft:red_terracotta
setblock 471 173 478 minecraft:terracotta
fill 471 173 479 471 173 482 minecraft:red_terracotta
setblock 471 173 483 minecraft:terracotta
fill 471 173 484 471 176 484 minecraft:red_terracotta
setblock 471 173 487 minecraft:red_terracotta
setblock 471 173 488 minecraft:terracotta
fill 471 173 489 471 175 490 minecraft:red_terracotta
setblock 471 173 497 minecraft:red_terracotta
setblock 471 173 498 minecraft:terracotta
fill 471 173 499 471 176 499 minecraft:red_terracotta
setblock 471 173 503 minecraft:terracotta
fill 471 173 504 474 173 504 minecraft:red_terracotta
fill 472 173 473 472 173 476 minecraft:red_terracotta
setblock 472 173 477 minecraft:terracotta
fill 472 173 478 472 173 481 minecraft:red_terracotta
setblock 472 173 482 minecraft:terracotta
fill 472 173 483 472 176 483 minecraft:red_terracotta
setblock 472 173 487 minecraft:terracotta
setblock 472 173 502 minecraft:terracotta
fill 472 173 503 472 176 503 minecraft:red_terracotta
setblock 473 173 465 minecraft:red_terracotta
setblock 473 173 475 minecraft:red_terracotta
setblock 473 173 476 minecraft:terracotta
fill 473 173 477 473 176 477 minecraft:red_terracotta
setblock 473 173 481 minecraft:terracotta
fill 473 173 482 474 175 482 minecraft:red_terracotta
setblock 473 173 485 minecraft:red_terracotta
setblock 474 173 465 minecraft:terracotta
setblock 474 173 480 minecraft:terracotta
fill 474 173 481 474 176 481 minecraft:red_terracotta
setblock 475 173 464 minecraft:terracotta
fill 475 173 465 477 174 465 minecraft:red_terracotta
setblock 475 173 503 minecraft:red_terracotta
setblock 475 173 504 minecraft:terracotta
fill 476 173 464 476 176 464 minecraft:red_terracotta
setblock 476 173 503 minecraft:terracotta
fill 476 173 504 476 176 504 minecraft:red_terracotta
setblock 479 173 464 minecraft:red_terracotta
setblock 480 173 464 minecraft:terracotta
setblock 480 173 504 minecraft:terracotta
fill 481 173 464 481 176 464 minecraft:red_terracotta
fill 481 173 504 484 173 504 minecraft:red_terracotta
fill 483 173 464 484 173 464 minecraft:red_terracotta
setblock 485 173 464 minecraft:terracotta
setblock 485 173 504 minecraft:terracotta
fill 486 173 464 489 173 464 minecraft:red_terracotta
fill 486 173 504 489 173 504 minecraft:red_terracotta
fill 487 173 503 490 173 503 minecraft:red_terracotta
setblock 489 173 465 minecraft:terracotta
setblock 490 173 464 minecraft:terracotta
fill 490 173 465 490 176 465 minecraft:red_terracotta
fill 490 173 502 491 173 502 minecraft:red_terracotta
setblock 490 173 504 minecraft:terracotta
fill 491 173 464 494 173 464 minecraft:red_terracotta
setblock 491 173 503 minecraft:terracotta
fill 491 173 504 494 173 504 minecraft:red_terracotta
setblock 492 173 502 minecraft:terracotta
fill 492 173 503 495 173 503 minecraft:red_terracotta
setblock 493 173 501 minecraft:terracotta
fill 493 173 502 493 176 502 minecraft:red_terracotta
setblock 494 173 465 minecraft:terracotta
fill 494 173 501 495 174 501 minecraft:red_terracotta
setblock 495 173 464 minecraft:terracotta
fill 495 173 465 495 176 465 minecraft:red_terracotta
setblock 495 173 504 minecraft:terracotta
fill 496 173 464 496 176 464 minecraft:red_terracotta
setblock 496 173 502 minecraft:red_terracotta
setblock 496 173 503 minecraft:terracotta
fill 496 173 504 499 173 504 minecraft:red_terracotta
setblock 497 173 502 minecraft:terracotta
fill 497 173 503 500 173 503 minecraft:red_terracotta
fill 498 173 502 498 176 502 minecraft:red_terracotta
setblock 500 173 504 minecraft:terracotta
setblock 501 173 503 minecraft:terracotta
fill 501 173 504 504 173 504 minecraft:red_terracotta
setblock 505 173 504 minecraft:terracotta
fill 506 173 504 506 176 504 minecraft:red_terracotta
fill 509 173 503 509 174 503 minecraft:red_terracotta
fill 510 173 477 510 174 477 minecraft:red_terracotta
setblock 510 173 479 minecraft:terracotta
fill 510 173 480 510 176 480 minecraft:red_terracotta
setblock 510 173 483 minecraft:red_terracotta
setblock 510 173 484 minecraft:terracotta
fill 510 173 485 510 176 485 minecraft:red_terracotta
fill 510 173 487 510 173 488 minecraft:red_terracotta
setblock 510 173 498 minecraft:red_terracotta
setblock 510 173 499 minecraft:terracotta
fill 510 173 500 510 176 500 minecraft:red_terracotta
setblock 510 173 504 minecraft:terracotta
fill 511 173 474 511 176 474 minecraft:red_terracotta
setblock 511 173 478 minecraft:terracotta
fill 511 173 479 511 176 479 minecraft:red_terracotta
setblock 511 173 483 minecraft:terracotta
fill 511 173 484 511 176 484 minecraft:red_terracotta
setblock 511 173 487 minecraft:red_terracotta
setblock 511 173 488 minecraft:terracotta
fill 511 173 489 511 173 492 minecraft:red_terracotta
setblock 511 173 493 minecraft:terracotta
fill 511 173 494 511 176 494 minecraft:red_terracotta
setblock 511 173 498 minecraft:terracotta
fill 511 173 499 511 176 499 minecraft:red_terracotta
setblock 511 173 503 minecraft:terracotta
fill 511 173 504 511 176 504 minecraft:red_terracotta
fill 471 174 464 473 174 464 minecraft:red_terracotta
setblock 471 174 466 minecraft:red_terracotta
setblock 471 174 467 minecraft:terracotta
fill 471 174 468 471 174 471 minecraft:red_terracotta
setblock 471 174 472 minecraft:terracotta
fill 471 174 473 471 174 476 minecraft:red_terracotta
setblock 471 174 477 minecraft:terracotta
fill 471 174 478 471 174 481 minecraft:red_terracotta
setblock 471 174 482 minecraft:terracotta
fill 471 174 483 471 177 483 minecraft:red_terracotta
setblock 471 174 487 minecraft:terracotta
fill 471 174 488 472 176 488 minecraft:red_terracotta
setblock 471 174 491 minecraft:red_terracotta
setblock 471 174 497 minecraft:terracotta
fill 471 174 498 471 177 498 minecraft:red_terracotta
setblock 471 174 502 minecraft:terracotta
fill 471 174 503 471 176 504 minecraft:red_terracotta
setblock 472 174 465 minecraft:red_terracotta
setblock 472 174 466 minecraft:terracotta
fill 472 174 467 472 177 467 minecraft:red_terracotta
fill 472 174 472 472 174 475 minecraft:red_terracotta
setblock 472 174 476 minecraft:terracotta
fill 472 174 477 472 174 480 minecraft:red_terracotta
setblock 472 174 481 minecraft:terracotta
fill 472 174 482 472 177 482 minecraft:red_terracotta
setblock 472 174 486 minecraft:terracotta
fill 472 174 487 472 177 487 minecraft:red_terracotta
setblock 472 174 501 minecraft:terracotta
fill 472 174 502 472 177 502 minecraft:red_terracotta
fill 472 174 504 473 174 504 minecraft:red_terracotta
setblock 473 174 465 minecraft:terracotta
setblock 473 174 466 minecraft:light[level=14]
setblock 473 174 474 minecraft:light[level=14]
setblock 473 174 475 minecraft:terracotta
fill 473 174 476 473 177 476 minecraft:red_terracotta
setblock 473 174 480 minecraft:terracotta
fill 473 174 481 473 177 481 minecraft:red_terracotta
setblock 473 174 485 minecraft:terracotta
fill 473 174 486 473 177 486 minecraft:red_terracotta
setblock 473 174 490 minecraft:light[level=14]
setblock 473 174 498 minecraft:light[level=14]
setblock 474 174 464 minecraft:terracotta
fill 474 174 465 474 177 465 minecraft:red_terracotta
setblock 474 174 479 minecraft:terracotta
fill 474 174 480 474 175 480 minecraft:red_terracotta
setblock 474 174 504 minecraft:terracotta
fill 475 174 464 475 177 464 minecraft:red_terracotta
setblock 475 174 503 minecraft:terracotta
fill 475 174 504 475 177 504 minecraft:red_terracotta
fill 476 174 503 476 177 503 minecraft:red_terracotta
setblock 478 174 465 minecraft:terracotta
setblock 479 174 464 minecraft:terracotta
setblock 479 174 504 minecraft:terracotta
fill 480 174 464 480 177 464 minecraft:red_terracotta
fill 480 174 504 483 174 504 minecraft:red_terracotta
setblock 481 174 466 minecraft:light[level=14]
setblock 481 174 474 minecraft:light[level=14]
setblock 481 174 482 minecraft:light[level=14]
setblock 481 174 490 minecraft:light[level=14]
setblock 481 174 498 minecraft:light[level=14]
setblock 483 174 464 minecraft:red_terracotta
setblock 484 174 464 minecraft:terracotta
setblock 484 174 504 minecraft:terracotta
fill 485 174 464 488 174 464 minecraft:red_terracotta
fill 485 174 504 488 174 504 minecraft:red_terracotta
fill 486 174 503 489 174 503 minecraft:red_terracotta
setblock 487 174 465 minecraft:red_terracotta
setblock 488 174 465 minecraft:terracotta
setblock 489 174 464 minecraft:terracotta
fill 489 174 465 489 177 465 minecraft:red_terracotta
setblock 489 174 466 minecraft:light[level=14]
setblock 489 174 474 minecraft:light[level=14]
setblock 489 174 482 minecraft:light[level=14]
setblock 489 174 490 minecraft:light[level=14]
setblock 489 174 498 minecraft:light[level=14]
fill 489 174 502 490 174 502 minecraft:red_terracotta
setblock 489 174 504 minecraft:terracotta
fill 490 174 464 493 174 464 minecraft:red_terracotta
setblock 490 174 503 minecraft:terracotta
fill 490 174 504 493 174 504 minecraft:red_terracotta
setblock 491 174 502 minecraft:terracotta
fill 491 174 503 494 174 503 minecraft:red_terracotta
setblock 492 174 501 minecraft:terracotta
fill 492 174 502 492 177 502 minecraft:red_terracotta
setblock 493 174 465 minecraft:terracotta
fill 493 174 501 493 177 501 minecraft:red_terracotta
setblock 494 174 464 minecraft:terracotta
fill 494 174 465 494 177 465 minecraft:red_terracotta
setblock 494 174 504 minecraft:terracotta
fill 495 174 464 495 177 464 minecraft:red_terracotta
setblock 495 174 503 minecraft:terracotta
fill 495 174 504 498 174 504 minecraft:red_terracotta
fill 496 174 465 496 175 465 minecraft:red_terracotta
setblock 496 174 502 minecraft:terracotta
fill 496 174 503 499 174 503 minecraft:red_terracotta
setblock 497 174 466 minecraft:light[level=14]
setblock 497 174 474 minecraft:light[level=14]
setblock 497 174 482 minecraft:light[level=14]
setblock 497 174 490 minecraft:light[level=14]
setblock 497 174 498 minecraft:light[level=14]
fill 497 174 502 497 177 502 minecraft:red_terracotta
setblock 499 174 464 minecraft:terracotta
setblock 499 174 504 minecraft:terracotta
setblock 500 174 503 minecraft:terracotta
fill 500 174 504 503 174 504 minecraft:red_terracotta
fill 501 174 503 501 177 503 minecraft:red_terracotta
setblock 504 174 504 minecraft:terracotta
setblock 505 174 466 minecraft:light[level=14]
setblock 505 174 474 minecraft:light[level=14]
setblock 505 174 482 minecraft:light[level=14]
setblock 505 174 490 minecraft:light[level=14]
setblock 505 174 498 minecraft:light[level=14]
fill 505 174 504 505 177 504 minecraft:red_terracotta
fill 508 174 503 508 175 503 minecraft:red_terracotta
fill 509 174 481 509 174 483 minecraft:red_terracotta
setblock 509 174 484 minecraft:terracotta
fill 509 174 485 509 177 485 minecraft:red_terracotta
setblock 509 174 504 minecraft:terracotta
fill 510 174 464 511 176 464 minecraft:red_terracotta
setblock 510 174 478 minecraft:terracotta
fill 510 174 479 510 177 479 minecraft:red_terracotta
setblock 510 174 483 minecraft:terracotta
fill 510 174 484 510 177 484 minecraft:red_terracotta
setblock 510 174 487 minecraft:red_terracotta
setblock 510 174 488 minecraft:terracotta
fill 510 174 489 511 175 490 minecraft:red_terracotta
setblock 510 174 498 minecraft:terracotta
fill 510 174 499 510 177 499 minecraft:red_terracotta
setblock 510 174 503 minecraft:terracotta
fill 510 174 504 510 177 504 minecraft:red_terracotta
fill 511 174 465 511 175 465 minecraft:red_terracotta
setblock 511 174 477 minecraft:terracotta
fill 511 174 478 511 177 478 minecraft:red_terracotta
setblock 511 174 482 minecraft:terracotta
fill 511 174 483 511 177 483 minecraft:red_terracotta
setblock 511 174 487 minecraft:terracotta
fill 511 174 488 511 177 488 minecraft:red_terracotta
setblock 511 174 491 minecraft:red_terracotta
setblock 511 174 492 minecraft:terracotta
fill 511 174 493 511 177 493 minecraft:red_terracotta
setblock 511 174 497 minecraft:terracotta
fill 511 174 498 511 177 498 minecraft:red_terracotta
setblock 511 174 502 minecraft:terracotta
fill 511 174 503 511 177 503 minecraft:red_terracotta
fill 471 175 464 472 175 464 minecraft:red_terracotta
setblock 471 175 466 minecraft:terracotta
fill 471 175 467 471 175 470 minecraft:red_terracotta
setblock 471 175 471 minecraft:terracotta
fill 471 175 472 471 175 475 minecraft:red_terracotta
setblock 471 175 476 minecraft:terracotta
fill 471 175 477 471 175 480 minecraft:red_terracotta
setblock 471 175 481 minecraft:terracotta
fill 471 175 482 471 178 482 minecraft:red_terracotta
setblock 471 175 486 minecraft:terracotta
fill 471 175 487 471 178 487 minecraft:red_terracotta
setblock 471 175 491 minecraft:terracotta
fill 471 175 492 471 178 492 minecraft:red_terracotta
fill 471 175 497 471 178 497 minecraft:red_terracotta
setblock 471 175 501 minecraft:terracotta
fill 471 175 502 471 178 502 minecraft:red_terracotta
setblock 472 175 465 minecraft:terracotta
fill 472 175 466 472 178 466 minecraft:red_terracotta
fill 472 175 468 472 175 469 minecraft:red_terracotta
setblock 472 175 470 minecraft:terracotta
fill 472 175 471 472 175 474 minecraft:red_terracotta
setblock 472 175 475 minecraft:terracotta
fill 472 175 476 472 175 479 minecraft:red_terracotta
setblock 472 175 480 minecraft:terracotta
fill 472 175 481 472 178 481 minecraft:red_terracotta
setblock 472 175 485 minecraft:terracotta
fill 472 175 486 472 178 486 minecraft:red_terracotta
setblock 472 175 489 minecraft:red_terracotta
fill 472 175 501 472 178 501 minecraft:red_terracotta
setblock 472 175 504 minecraft:red_terracotta
setblock 473 175 464 minecraft:terracotta
fill 473 175 465 473 178 465 minecraft:red_terracotta
setblock 473 175 479 minecraft:terracotta
fill 473 175 480 473 178 480 minecraft:red_terracotta
setblock 473 175 484 minecraft:terracotta
fill 473 175 485 473 178 485 minecraft:red_terracotta
setblock 473 175 504 minecraft:terracotta
fill 474 175 464 474 178 464 minecraft:red_terracotta
setblock 474 175 503 minecraft:terracotta
fill 474 175 504 474 178 504 minecraft:red_terracotta
fill 475 175 465 476 175 465 minecraft:red_terracotta
fill 475 175 503 475 178 503 minecraft:red_terracotta
setblock 477 175 465 minecraft:terracotta
setblock 478 175 464 minecraft:terracotta
fill 478 175 465 479 177 465 minecraft:red_terracotta
setblock 478 175 504 minecraft:terracotta
fill 479 175 464 479 178 464 minecraft:red_terracotta
fill 479 175 504 482 175 504 minecraft:red_terracotta
setblock 483 175 464 minecraft:terracotta
setblock 483 175 504 minecraft:terracotta
fill 484 175 464 487 175 464 minecraft:red_terracotta
fill 484 175 504 487 175 504 minecraft:red_terracotta
fill 485 175 465 486 175 465 minecraft:red_terracotta
fill 485 175 503 488 175 503 minecraft:red_terracotta
setblock 487 175 465 minecraft:terracotta
setblock 488 175 464 minecraft:terracotta
fill 488 175 465 488 178 465 minecraft:red_terracotta
fill 488 175 502 489 175 502 minecraft:red_terracotta
setblock 488 175 504 minecraft:terracotta
fill 489 175 464 492 175 464 minecraft:red_terracotta
setblock 489 175 503 minecraft:terracotta
fill 489 175 504 492 175 504 minecraft:red_terracotta
setblock 490 175 502 minecraft:terracotta
fill 490 175 503 493 175 503 minecraft:red_terracotta
setblock 491 175 466 minecraft:terracotta
setblock 491 175 501 minecraft:terracotta
fill 491 175 502 491 178 502 minecraft:red_terracotta
setblock 492 175 465 minecraft:terracotta
fill 492 175 501 492 178 501 minecraft:red_terracotta
setblock 493 175 464 minecraft:terracotta
fill 493 175 465 493 178 465 minecraft:red_terracotta
setblock 493 175 504 minecraft:terracotta
fill 494 175 464 494 178 464 minecraft:red_terracotta
fill 494 175 501 494 176 501 minecraft:red_terracotta
setblock 494 175 503 minecraft:terracotta
fill 494 175 504 497 175 504 minecraft:red_terracotta
setblock 495 175 502 minecraft:terracotta
fill 495 175 503 498 175 503 minecraft:red_terracotta
fill 496 175 502 496 178 502 minecraft:red_terracotta
setblock 498 175 464 minecraft:terracotta
setblock 498 175 504 minecraft:terracotta
fill 499 175 464 499 178 464 minecraft:red_terracotta
setblock 499 175 503 minecraft:terracotta
fill 499 175 504 502 175 504 minecraft:red_terracotta
fill 500 175 503 500 178 503 minecraft:red_terracotta
setblock 503 175 504 minecraft:terracotta
fill 504 175 504 504 178 504 minecraft:red_terracotta
fill 507 175 503 507 176 503 minecraft:red_terracotta
setblock 508 175 464 minecraft:terracotta
setblock 508 175 504 minecraft:terracotta
fill 509 175 464 509 178 464 minecraft:red_terracotta
fill 509 175 480 509 175 482 minecraft:red_terracotta
setblock 509 175 483 minecraft:terracotta
fill 509 175 484 509 178 484 minecraft:red_terracotta
fill 509 175 486 509 175 487 minecraft:red_terracotta
setblock 509 175 503 minecraft:terracotta
fill 509 175 504 509 178 504 minecraft:red_terracotta
setblock 510 175 476 minecraft:red_terracotta
setblock 510 175 477 minecraft:terracotta
fill 510 175 478 510 178 478 minecraft:red_terracotta
setblock 510 175 482 minecraft:terracotta
fill 510 175 483 510 178 483 minecraft:red_terracotta
setblock 510 175 486 minecraft:red_terracotta
setblock 510 175 487 minecraft:terracotta
fill 510 175 488 510 178 488 minecraft:red_terracotta
setblock 510 175 491 minecraft:red_terracotta
setblock 510 175 492 minecraft:terracotta
fill 510 175 498 510 178 498 minecraft:red_terracotta
setblock 510 175 502 minecraft:terracotta
fill 510 175 503 510 178 503 minecraft:red_terracotta
setblock 511 175 466 minecraft:terracotta
fill 511 175 467 511 177 468 minecraft:red_terracotta
fill 511 175 472 511 177 473 minecraft:red_terracotta
setblock 511 175 476 minecraft:terracotta
fill 511 175 477 511 178 477 minecraft:red_terracotta
setblock 511 175 481 minecraft:terracotta
fill 511 175 482 511 178 482 minecraft:red_terracotta
setblock 511 175 486 minecraft:terracotta
fill 511 175 487 511 178 487 minecraft:red_terracotta
setblock 511 175 491 minecraft:terracotta
fill 511 175 492 511 178 492 minecraft:red_terracotta
setblock 511 175 496 minecraft:terracotta
fill 511 175 497 511 178 497 minecraft:red_terracotta
setblock 511 175 501 minecraft:terracotta
fill 511 175 502 511 178 502 minecraft:red_terracotta
setblock 471 176 464 minecraft:red_terracotta
setblock 471 176 465 minecraft:terracotta
fill 471 176 466 471 176 469 minecraft:red_terracotta
setblock 471 176 470 minecraft:terracotta
fill 471 176 471 471 176 474 minecraft:red_terracotta
setblock 471 176 475 minecraft:terracotta
fill 471 176 476 471 176 479 minecraft:red_terracotta
setblock 471 176 480 minecraft:terracotta
fill 471 176 481 471 179 481 minecraft:red_terracotta
setblock 471 176 485 minecraft:terracotta
fill 471 176 486 471 179 486 minecraft:red_terracotta
setblock 471 176 489 minecraft:red_terracotta
setblock 471 176 490 minecraft:terracotta
fill 471 176 491 471 179 491 minecraft:red_terracotta
fill 471 176 493 471 177 493 minecraft:red_terracotta
setblock 471 176 500 minecraft:terracotta
fill 471 176 501 471 179 501 minecraft:red_terracotta
setblock 472 176 464 minecraft:terracotta
fill 472 176 465 472 179 465 minecraft:red_terracotta
setblock 472 176 468 minecraft:red_terracotta
setblock 472 176 469 minecraft:terracotta
fill 472 176 470 472 176 473 minecraft:red_terracotta
setblock 472 176 474 minecraft:terracotta
fill 472 176 475 472 176 478 minecraft:red_terracotta
setblock 472 176 479 minecraft:terracotta
fill 472 176 480 472 179 480 minecraft:red_terracotta
setblock 472 176 484 minecraft:terracotta
fill 472 176 485 472 179 485 minecraft:red_terracotta
setblock 472 176 489 minecraft:terracotta
fill 472 176 490 472 179 490 minecraft:red_terracotta
setblock 472 176 504 minecraft:terracotta
fill 473 176 464 473 179 464 minecraft:red_terracotta
fill 473 176 466 473 176 467 minecraft:red_terracotta
setblock 473 176 468 minecraft:terracotta
setblock 473 176 478 minecraft:terracotta
fill 473 176 479 473 179 479 minecraft:red_terracotta
setblock 473 176 482 minecraft:red_terracotta
setblock 473 176 483 minecraft:terracotta
fill 473 176 484 473 179 484 minecraft:red_terracotta
setblock 473 176 487 minecraft:red_terracotta
setblock 473 176 503 minecraft:terracotta
fill 473 176 504 473 179 504 minecraft:red_terracotta
setblock 474 176 466 minecraft:red_terracotta
setblock 474 176 482 minecraft:terracotta
setblock 474 176 483 minecraft:red_terracotta
fill 474 176 503 474 179 503 minecraft:red_terracotta
setblock 475 176 465 minecraft:red_terracotta
setblock 475 176 466 minecraft:terracotta
setblock 476 176 465 minecraft:terracotta
fill 476 176 466 476 179 466 minecraft:red_terracotta
setblock 477 176 464 minecraft:terracotta
fill 477 176 465 477 179 465 minecraft:red_terracotta
setblock 477 176 504 minecraft:terracotta
fill 478 176 464 478 179 464 minecraft:red_terracotta
fill 478 176 488 489 177 489 minecraft:iron_block
fill 478 176 504 481 176 504 minecraft:red_terracotta
setblock 480 176 465 minecraft:red_terracotta
setblock 481 176 465 minecraft:terracotta
setblock 482 176 464 minecraft:terracotta
fill 482 176 465 485 176 465 minecraft:red_terracotta
setblock 482 176 504 minecraft:terracotta
fill 483 176 464 486 176 464 minecraft:red_terracotta
fill 483 176 504 486 176 504 minecraft:red_terracotta
fill 484 176 503 487 176 503 minecraft:red_terracotta
setblock 486 176 465 minecraft:terracotta
setblock 487 176 464 minecraft:terracotta
fill 487 176 465 487 179 465 minecraft:red_terracotta
fill 487 176 502 488 176 502 minecraft:red_terracotta
setblock 487 176 504 minecraft:terracotta
fill 488 176 464 491 176 464 minecraft:red_terracotta
fill 488 176 466 489 176 466 minecraft:red_terracotta
setblock 488 176 503 minecraft:terracotta
fill 488 176 504 491 176 504 minecraft:red_terracotta
setblock 489 176 502 minecraft:terracotta
fill 489 176 503 492 176 503 minecraft:red_terracotta
setblock 490 176 466 minecraft:terracotta
fill 490 176 488 490 177 488 minecraft:iron_block
fill 490 176 502 490 179 502 minecraft:red_terracotta
setblock 491 176 465 minecraft:terracotta
fill 491 176 466 493 177 466 minecraft:red_terracotta
fill 491 176 501 491 179 501 minecraft:red_terracotta
setblock 492 176 464 minecraft:terracotta
fill 492 176 465 492 179 465 minecraft:red_terracotta
fill 492 176 469 493 177 469 minecraft:orange_concrete
fill 492 176 488 504 177 489 minecraft:iron_block
setblock 492 176 504 minecraft:terracotta
fill 493 176 464 493 179 464 minecraft:red_terracotta
setblock 493 176 503 minecraft:terracotta
fill 493 176 504 496 176 504 minecraft:red_terracotta
setblock 494 176 502 minecraft:terracotta
fill 494 176 503 497 176 503 minecraft:red_terracotta
fill 495 176 502 495 179 502 minecraft:red_terracotta
setblock 496 176 465 minecraft:terracotta
setblock 497 176 464 minecraft:terracotta
setblock 497 176 504 minecraft:terracotta
fill 498 176 464 498 179 464 minecraft:red_terracotta
setblock 498 176 503 minecraft:terracotta
fill 498 176 504 501 176 504 minecraft:red_terracotta
fill 499 176 503 499 179 503 minecraft:red_terracotta
fill 500 176 464 500 177 464 minecraft:red_terracotta
fill 502 176 470 502 177 471 minecraft:orange_concrete
setblock 502 176 504 minecraft:terracotta
fill 503 176 504 503 179 504 minecraft:red_terracotta
setblock 506 176 464 minecraft:red_terracotta
fill 506 176 503 506 177 503 minecraft:red_terracotta
setblock 507 176 464 minecraft:terracotta
setblock 507 176 504 minecraft:terracotta
fill 508 176 464 508 179 464 minecraft:red_terracotta
setblock 508 176 503 minecraft:terracotta
fill 508 176 504 508 179 504 minecraft:red_terracotta
fill 509 176 479 509 176 481 minecraft:red_terracotta
setblock 509 176 482 minecraft:terracotta
fill 509 176 483 509 179 483 minecraft:red_terracotta
setblock 509 176 486 minecraft:red_terracotta
setblock 509 176 487 minecraft:terracotta
fill 509 176 488 509 178 489 minecraft:red_terracotta
fill 509 176 503 509 179 503 minecraft:red_terracotta
setblock 510 176 465 minecraft:red_terracotta
setblock 510 176 476 minecraft:terracotta
fill 510 176 477 510 179 477 minecraft:red_terracotta
setblock 510 176 481 minecraft:terracotta
fill 510 176 482 510 179 482 minecraft:red_terracotta
setblock 510 176 486 minecraft:terracotta
fill 510 176 487 510 179 487 minecraft:red_terracotta
fill 510 176 489 510 176 490 minecraft:red_terracotta
setblock 510 176 491 minecraft:terracotta
fill 510 176 492 510 177 494 minecraft:red_terracotta
fill 510 176 497 510 179 497 minecraft:red_terracotta
setblock 510 176 501 minecraft:terracotta
fill 510 176 502 510 179 502 minecraft:red_terracotta
setblock 511 176 465 minecraft:terracotta
fill 511 176 466 511 179 466 minecraft:red_terracotta
setblock 511 176 469 minecraft:red_terracotta
setblock 511 176 470 minecraft:terracotta
fill 511 176 471 511 179 471 minecraft:red_terracotta
setblock 511 176 475 minecraft:terracotta
fill 511 176 476 511 179 476 minecraft:red_terracotta
setblock 511 176 480 minecraft:terracotta
fill 511 176 481 511 179 481 minecraft:red_terracotta
setblock 511 176 485 minecraft:terracotta
fill 511 176 486 511 179 486 minecraft:red_terracotta
setblock 511 176 489 minecraft:red_terracotta
setblock 511 176 490 minecraft:terracotta
fill 511 176 491 511 179 491 minecraft:red_terracotta
setblock 511 176 495 minecraft:terracotta
fill 511 176 496 511 179 496 minecraft:red_terracotta
setblock 511 176 500 minecraft:terracotta
fill 511 176 501 511 179 501 minecraft:red_terracotta
setblock 471 177 464 minecraft:terracotta
fill 471 177 465 471 177 468 minecraft:red_terracotta
setblock 471 177 469 minecraft:terracotta
fill 471 177 470 471 177 473 minecraft:red_terracotta
setblock 471 177 474 minecraft:terracotta
fill 471 177 475 471 177 478 minecraft:red_terracotta
setblock 471 177 479 minecraft:terracotta
fill 471 177 480 471 180 480 minecraft:red_terracotta
setblock 471 177 484 minecraft:terracotta
fill 471 177 485 471 180 485 minecraft:red_terracotta
setblock 471 177 488 minecraft:red_terracotta
setblock 471 177 489 minecraft:terracotta
fill 471 177 490 471 180 490 minecraft:red_terracotta
setblock 471 177 494 minecraft:terracotta
fill 471 177 495 471 179 496 minecraft:red_terracotta
setblock 471 177 499 minecraft:terracotta
fill 471 177 500 471 180 500 minecraft:red_terracotta
setblock 471 177 503 minecraft:red_terracotta
setblock 471 177 504 minecraft:terracotta
fill 472 177 464 472 180 464 minecraft:red_terracotta
setblock 472 177 468 minecraft:terracotta
fill 472 177 469 472 177 472 minecraft:red_terracotta
setblock 472 177 473 minecraft:terracotta
fill 472 177 474 472 177 477 minecraft:red_terracotta
setblock 472 177 478 minecraft:terracotta
fill 472 177 479 472 180 479 minecraft:red_terracotta
setblock 472 177 483 minecraft:terracotta
fill 472 177 484 472 180 484 minecraft:red_terracotta
setblock 472 177 488 minecraft:terracotta
fill 472 177 489 472 180 489 minecraft:red_terracotta
setblock 472 177 503 minecraft:terracotta
fill 472 177 504 472 180 504 minecraft:red_terracotta
setblock 473 177 466 minecraft:red_terracotta
setblock 473 177 467 minecraft:terracotta
fill 473 177 468 473 178 470 minecraft:red_terracotta
setblock 473 177 477 minecraft:terracotta
fill 473 177 478 473 179 478 minecraft:red_terracotta
setblock 473 177 482 minecraft:terracotta
fill 473 177 483 473 180 483 minecraft:red_terracotta
setblock 473 177 487 minecraft:terracotta
fill 473 177 503 473 180 503 minecraft:red_terracotta
setblock 474 177 466 minecraft:terracotta
setblock 475 177 465 minecraft:terracotta
fill 475 177 466 475 180 466 minecraft:red_terracotta
setblock 476 177 464 minecraft:terracotta
fill 476 177 465 476 180 465 minecraft:red_terracotta
setblock 476 177 504 minecraft:terracotta
fill 477 177 464 477 180 464 minecraft:red_terracotta
fill 477 177 466 477 178 466 minecraft:red_terracotta
fill 477 177 504 480 177 504 minecraft:red_terracotta
setblock 480 177 465 minecraft:terracotta
setblock 481 177 464 minecraft:terracotta
fill 481 177 465 484 177 465 minecraft:red_terracotta
setblock 481 177 504 minecraft:terracotta
fill 482 177 464 485 177 464 minecraft:red_terracotta
fill 482 177 504 485 177 504 minecraft:red_terracotta
fill 483 177 503 486 177 503 minecraft:red_terracotta
setblock 485 177 465 minecraft:terracotta
setblock 486 177 464 minecraft:terracotta
fill 486 177 465 486 179 466 minecraft:red_terracotta
setblock 486 177 504 minecraft:terracotta
fill 487 177 464 490 177 464 minecraft:red_terracotta
fill 487 177 466 488 177 466 minecraft:red_terracotta
setblock 487 177 502 minecraft:red_terracotta
setblock 487 177 503 minecraft:terracotta
fill 487 177 504 490 177 504 minecraft:red_terracotta
setblock 488 177 502 minecraft:terracotta
fill 488 177 503 491 177 503 minecraft:red_terracotta
setblock 489 177 466 minecraft:terracotta
fill 489 177 502 489 180 502 minecraft:red_terracotta
setblock 490 177 465 minecraft:terracotta
fill 490 177 466 490 180 466 minecraft:red_terracotta
fill 490 177 501 490 179 501 minecraft:red_terracotta
setblock 491 177 464 minecraft:terracotta
fill 491 177 465 491 180 465 minecraft:red_terracotta
setblock 491 177 504 minecraft:terracotta
fill 492 177 464 492 180 464 minecraft:red_terracotta
setblock 492 177 503 minecraft:terracotta
fill 492 177 504 495 177 504 minecraft:red_terracotta
setblock 493 177 502 minecraft:terracotta
fill 493 177 503 496 177 503 minecraft:red_terracotta
setblock 494 177 466 minecraft:terracotta
setblock 494 177 501 minecraft:terracotta
fill 494 177 502 494 180 502 minecraft:red_terracotta
setblock 495 177 465 minecraft:terracotta
setblock 496 177 464 minecraft:terracotta
fill 496 177 465 497 179 465 minecraft:red_terracotta
setblock 496 177 504 minecraft:terracotta
fill 497 177 464 497 180 464 minecraft:red_terracotta
setblock 497 177 503 minecraft:terracotta
fill 497 177 504 500 177 504 minecraft:red_terracotta
fill 498 177 503 498 180 503 minecraft:red_terracotta
setblock 501 177 464 minecraft:terracotta
setblock 501 177 504 minecraft:terracotta
fill 502 177 504 502 180 504 minecraft:red_terracotta
fill 504 177 464 505 177 464 minecraft:red_terracotta
fill 504 177 503 505 178 503 minecraft:red_terracotta
setblock 506 177 464 minecraft:terracotta
setblock 506 177 504 minecraft:terracotta
fill 507 177 464 507 180 464 minecraft:red_terracotta
setblock 507 177 503 minecraft:terracotta
fill 507 177 504 507 180 504 minecraft:red_terracotta
fill 508 177 465 509 177 465 minecraft:red_terracotta
setblock 508 177 482 minecraft:terracotta
fill 508 177 483 508 177 486 minecraft:red_terracotta
setblock 508 177 487 minecraft:terracotta
fill 508 177 503 508 180 503 minecraft:red_terracotta
fill 509 177 479 509 177 480 minecraft:red_terracotta
setblock 509 177 481 minecraft:terracotta
fill 509 177 482 509 180 482 minecraft:red_terracotta
setblock 509 177 486 minecraft:terracotta
fill 509 177 487 509 180 487 minecraft:red_terracotta
setblock 509 177 490 minecraft:red_terracotta
setblock 509 177 491 minecraft:terracotta
setblock 510 177 464 minecraft:red_terracotta
setblock 510 177 465 minecraft:terracotta
fill 510 177 466 510 178 468 minecraft:red_terracotta
setblock 510 177 475 minecraft:terracotta
fill 510 177 476 510 180 476 minecraft:red_terracotta
setblock 510 177 480 minecraft:terracotta
fill 510 177 481 510 180 481 minecraft:red_terracotta
setblock 510 177 485 minecraft:terracotta
fill 510 177 486 510 180 486 minecraft:red_terracotta
setblock 510 177 489 minecraft:red_terracotta
setblock 510 177 490 minecraft:terracotta
fill 510 177 491 510 180 491 minecraft:red_terracotta
setblock 510 177 495 minecraft:terracotta
fill 510 177 496 510 180 496 minecraft:red_terracotta
setblock 510 177 500 minecraft:terracotta
fill 510 177 501 510 180 501 minecraft:red_terracotta
setblock 511 177 464 minecraft:terracotta
fill 511 177 465 511 180 465 minecraft:red_terracotta
setblock 511 177 469 minecraft:terracotta
fill 511 177 470 511 180 470 minecraft:red_terracotta
setblock 511 177 474 minecraft:terracotta
fill 511 177 475 511 180 475 minecraft:red_terracotta
setblock 511 177 479 minecraft:terracotta
fill 511 177 480 511 180 480 minecraft:red_terracotta
setblock 511 177 484 minecraft:terracotta
fill 511 177 485 511 180 485 minecraft:red_terracotta
setblock 511 177 489 minecraft:terracotta
fill 511 177 490 511 180 490 minecraft:red_terracotta
setblock 511 177 494 minecraft:terracotta
fill 511 177 495 511 180 495 minecraft:red_terracotta
setblock 511 177 499 minecraft:terracotta
fill 511 177 500 511 180 500 minecraft:red_terracotta
setblock 511 177 504 minecraft:terracotta
fill 471 178 464 471 178 467 minecraft:red_terracotta
setblock 471 178 468 minecraft:terracotta
fill 471 178 469 471 178 472 minecraft:red_terracotta
setblock 471 178 473 minecraft:terracotta
fill 471 178 474 471 178 477 minecraft:red_terracotta
setblock 471 178 478 minecraft:terracotta
fill 471 178 479 471 181 479 minecraft:red_terracotta
setblock 471 178 483 minecraft:terracotta
fill 471 178 484 471 181 484 minecraft:red_terracotta
setblock 471 178 488 minecraft:terracotta
fill 471 178 489 471 181 489 minecraft:red_terracotta
setblock 471 178 493 minecraft:terracotta
fill 471 178 494 471 181 494 minecraft:red_terracotta
setblock 471 178 498 minecraft:terracotta
fill 471 178 499 471 180 499 minecraft:red_terracotta
setblock 471 178 503 minecraft:terracotta
fill 471 178 504 471 181 504 minecraft:red_terracotta
setblock 472 178 467 minecraft:terracotta
fill 472 178 468 472 178 471 minecraft:red_terracotta
setblock 472 178 472 minecraft:terracotta
fill 472 178 473 472 178 476 minecraft:red_terracotta
setblock 472 178 477 minecraft:terracotta
fill 472 178 478 472 181 478 minecraft:red_terracotta
setblock 472 178 482 minecraft:terracotta
fill 472 178 483 472 181 483 minecraft:red_terracotta
setblock 472 178 487 minecraft:terracotta
fill 472 178 488 473 180 488 minecraft:red_terracotta
setblock 472 178 491 minecraft:red_terracotta
setblock 472 178 502 minecraft:terracotta
fill 472 178 503 472 180 503 minecraft:red_terracotta
setblock 473 178 466 minecraft:terracotta
fill 473 178 467 473 181 467 minecraft:red_terracotta
setblock 473 178 471 minecraft:terracotta
setblock 473 178 476 minecraft:terracotta
setblock 473 178 477 minecraft:red_terracotta
setblock 473 178 481 minecraft:terracotta
fill 473 178 482 473 180 482 minecraft:red_terracotta
setblock 473 178 486 minecraft:terracotta
fill 473 178 487 473 180 487 minecraft:red_terracotta
setblock 474 178 465 minecraft:terracotta
fill 474 178 466 474 181 466 minecraft:red_terracotta
setblock 475 178 464 minecraft:terracotta
fill 475 178 465 475 181 465 minecraft:red_terracotta
setblock 475 178 504 minecraft:terracotta
fill 476 178 464 476 181 464 minecraft:red_terracotta
setblock 476 178 503 minecraft:terracotta
fill 476 178 504 479 178 504 minecraft:red_terracotta
setblock 478 178 465 minecraft:red_terracotta
setblock 478 178 466 minecraft:terracotta
setblock 479 178 465 minecraft:terracotta
setblock 480 178 464 minecraft:terracotta
fill 480 178 465 483 178 465 minecraft:red_terracotta
setblock 480 178 504 minecraft:terracotta
fill 481 178 464 484 178 464 minecraft:red_terracotta
fill 481 178 504 484 178 504 minecraft:red_terracotta
fill 482 178 503 485 178 503 minecraft:red_terracotta
setblock 484 178 465 minecraft:terracotta
fill 484 178 466 485 180 466 minecraft:red_terracotta
setblock 485 178 464 minecraft:terracotta
fill 485 178 465 485 181 465 minecraft:red_terracotta
setblock 485 178 504 minecraft:terracotta
fill 486 178 464 489 178 464 minecraft:red_terracotta
setblock 486 178 502 minecraft:red_terracotta
setblock 486 178 503 minecraft:terracotta
fill 486 178 504 489 178 504 minecraft:red_terracotta
setblock 487 178 466 minecraft:red_terracotta
setblock 487 178 502 minecraft:terracotta
fill 487 178 503 490 178 503 minecraft:red_terracotta
setblock 488 178 466 minecraft:terracotta
fill 488 178 502 488 181 502 minecraft:red_terracotta
setblock 489 178 465 minecraft:terracotta
fill 489 178 466 489 181 466 minecraft:red_terracotta
setblock 490 178 464 minecraft:terracotta
fill 490 178 465 490 181 465 minecraft:red_terracotta
setblock 490 178 504 minecraft:terracotta
fill 491 178 464 491 181 464 minecraft:red_terracotta
fill 491 178 466 492 178 466 minecraft:red_terracotta
setblock 491 178 503 minecraft:terracotta
fill 491 178 504 494 178 504 minecraft:red_terracotta
setblock 492 178 502 minecraft:terracotta
fill 492 178 503 495 178 503 minecraft:red_terracotta
setblock 493 178 466 minecraft:terracotta
setblock 493 178 501 minecraft:terracotta
fill 493 178 502 493 181 502 minecraft:red_terracotta
setblock 494 178 465 minecraft:terracotta
fill 494 178 466 494 179 466 minecraft:red_terracotta
setblock 495 178 464 minecraft:terracotta
fill 495 178 465 495 181 465 minecraft:red_terracotta
setblock 495 178 504 minecraft:terracotta
fill 496 178 464 496 181 464 minecraft:red_terracotta
setblock 496 178 503 minecraft:terracotta
fill 496 178 504 499 178 504 minecraft:red_terracotta
fill 497 178 503 497 180 503 minecraft:red_terracotta
setblock 500 178 464 minecraft:terracotta
setblock 500 178 504 minecraft:terracotta
fill 501 178 464 504 178 464 minecraft:red_terracotta
setblock 501 178 503 minecraft:terracotta
fill 501 178 504 501 181 504 minecraft:red_terracotta
setblock 505 178 464 minecraft:terracotta
setblock 505 178 504 minecraft:terracotta
fill 506 178 464 506 181 464 minecraft:red_terracotta
setblock 506 178 503 minecraft:terracotta
fill 506 178 504 506 181 504 minecraft:red_terracotta
fill 507 178 465 508 178 465 minecraft:red_terracotta
fill 507 178 503 507 181 503 minecraft:red_terracotta
setblock 508 178 481 minecraft:terracotta
fill 508 178 482 508 178 485 minecraft:red_terracotta
setblock 508 178 486 minecraft:terracotta
fill 508 178 487 508 179 489 minecraft:red_terracotta
setblock 509 178 465 minecraft:terracotta
fill 509 178 478 509 178 479 minecraft:red_terracotta
setblock 509 178 480 minecraft:terracotta
fill 509 178 481 509 181 481 minecraft:red_terracotta
setblock 509 178 485 minecraft:terracotta
fill 509 178 486 509 181 486 minecraft:red_terracotta
setblock 509 178 490 minecraft:terracotta
fill 509 178 491 509 180 492 minecraft:red_terracotta
setblock 510 178 464 minecraft:terracotta
fill 510 178 465 510 181 465 minecraft:red_terracotta
setblock 510 178 469 minecraft:terracotta
fill 510 178 470 510 178 473 minecraft:red_terracotta
setblock 510 178 474 minecraft:terracotta
fill 510 178 475 510 181 475 minecraft:red_terracotta
setblock 510 178 479 minecraft:terracotta
fill 510 178 480 510 181 480 minecraft:red_terracotta
setblock 510 178 484 minecraft:terracotta
fill 510 178 485 510 181 485 minecraft:red_terracotta
setblock 510 178 489 minecraft:terracotta
fill 510 178 490 510 181 490 minecraft:red_terracotta
fill 510 178 492 510 178 493 minecraft:red_terracotta
setblock 510 178 494 minecraft:terracotta
fill 510 178 495 510 181 495 minecraft:red_terracotta
setblock 510 178 499 minecraft:terracotta
fill 510 178 500 510 179 500 minecraft:red_terracotta
setblock 510 178 504 minecraft:terracotta
fill 511 178 464 511 181 464 minecraft:red_terracotta
setblock 511 178 467 minecraft:red_terracotta
setblock 511 178 468 minecraft:terracotta
fill 511 178 469 511 181 469 minecraft:red_terracotta
setblock 511 178 472 minecraft:red_terracotta
setblock 511 178 473 minecraft:terracotta
fill 511 178 474 511 181 474 minecraft:red_terracotta
setblock 511 178 478 minecraft:terracotta
fill 511 178 479 511 181 479 minecraft:red_terracotta
setblock 511 178 483 minecraft:terracotta
fill 511 178 484 511 181 484 minecraft:red_terracotta
setblock 511 178 488 minecraft:terracotta
fill 511 178 489 511 181 489 minecraft:red_terracotta
setblock 511 178 493 minecraft:terracotta
fill 511 178 494 511 181 494 minecraft:red_terracotta
setblock 511 178 498 minecraft:terracotta
fill 511 178 499 511 181 499 minecraft:red_terracotta
setblock 511 178 503 minecraft:terracotta
fill 511 178 504 511 181 504 minecraft:red_terracotta
fill 471 179 464 471 179 466 minecraft:red_terracotta
setblock 471 179 467 minecraft:terracotta
fill 471 179 468 471 179 471 minecraft:red_terracotta
setblock 471 179 472 minecraft:terracotta
fill 471 179 473 471 179 476 minecraft:red_terracotta
setblock 471 179 477 minecraft:terracotta
fill 471 179 478 471 182 478 minecraft:red_terracotta
setblock 471 179 482 minecraft:terracotta
fill 471 179 483 471 182 483 minecraft:red_terracotta
setblock 471 179 487 minecraft:terracotta
fill 471 179 488 471 182 488 minecraft:red_terracotta
setblock 471 179 492 minecraft:terracotta
fill 471 179 493 471 182 493 minecraft:red_terracotta
setblock 471 179 497 minecraft:terracotta
setblock 471 179 498 minecraft:red_terracotta
setblock 471 179 502 minecraft:terracotta
fill 471 179 503 471 182 503 minecraft:red_terracotta
setblock 472 179 466 minecraft:terracotta
fill 472 179 467 472 179 470 minecraft:red_terracotta
setblock 472 179 471 minecraft:terracotta
fill 472 179 472 472 179 475 minecraft:red_terracotta
setblock 472 179 476 minecraft:terracotta
fill 472 179 477 472 182 477 minecraft:red_terracotta
setblock 472 179 481 minecraft:terracotta
fill 472 179 482 472 182 482 minecraft:red_terracotta
setblock 472 179 486 minecraft:terracotta
fill 472 179 487 472 182 487 minecraft:red_terracotta
setblock 472 179 491 minecraft:terracotta
setblock 472 179 502 minecraft:red_terracotta
setblock 473 179 465 minecraft:terracotta
fill 473 179 466 473 182 466 minecraft:red_terracotta
fill 473 179 468 473 179 469 minecraft:red_terracotta
setblock 473 179 470 minecraft:terracotta
fill 473 179 471 473 180 472 minecraft:red_terracotta
setblock 473 179 480 minecraft:terracotta
fill 473 179 481 473 180 481 minecraft:red_terracotta
setblock 473 179 485 minecraft:terracotta
fill 473 179 486 473 181 486 minecraft:red_terracotta
setblock 474 179 464 minecraft:terracotta
fill 474 179 465 474 182 465 minecraft:red_terracotta
fill 474 179 467 474 180 467 minecraft:red_terracotta
setblock 474 179 504 minecraft:terracotta
fill 475 179 464 475 182 464 minecraft:red_terracotta
setblock 475 179 503 minecraft:terracotta
fill 475 179 504 478 179 504 minecraft:red_terracotta
setblock 477 179 466 minecraft:terracotta
setblock 478 179 465 minecraft:terracotta
fill 478 179 466 481 179 466 minecraft:red_terracotta
setblock 479 179 464 minecraft:terracotta
fill 479 179 465 482 179 465 minecraft:red_terracotta
setblock 479 179 504 minecraft:terracotta
fill 480 179 464 483 179 464 minecraft:red_terracotta
fill 480 179 504 483 179 504 minecraft:red_terracotta
setblock 482 179 466 minecraft:terracotta
fill 482 179 503 484 179 503 minecraft:red_terracotta
setblock 483 179 465 minecraft:terracotta
fill 483 179 466 483 182 466 minecraft:red_terracotta
setblock 484 179 464 minecraft:terracotta
fill 484 179 465 484 182 465 minecraft:red_terracotta
setblock 484 179 504 minecraft:terracotta
fill 485 179 464 488 179 464 minecraft:red_terracotta
setblock 485 179 503 minecraft:terracotta
fill 485 179 504 488 179 504 minecraft:red_terracotta
setblock 486 179 502 minecraft:terracotta
fill 486 179 503 489 179 503 minecraft:red_terracotta
setblock 487 179 466 minecraft:terracotta
fill 487 179 502 487 182 502 minecraft:red_terracotta
setblock 488 179 465 minecraft:terracotta
fill 488 179 466 488 181 467 minecraft:red_terracotta
setblock 489 179 464 minecraft:terracotta
fill 489 179 465 489 182 465 minecraft:red_terracotta
fill 489 179 467 489 180 467 minecraft:red_terracotta
setblock 489 179 504 minecraft:terracotta
fill 490 179 464 490 182 464 minecraft:red_terracotta
setblock 490 179 503 minecraft:terracotta
fill 490 179 504 493 179 504 minecraft:red_terracotta
setblock 491 179 466 minecraft:red_terracotta
setblock 491 179 502 minecraft:terracotta
fill 491 179 503 494 179 503 minecraft:red_terracotta
setblock 492 179 466 minecraft:terracotta
fill 492 179 502 492 181 502 minecraft:red_terracotta
setblock 493 179 465 minecraft:terracotta
fill 493 179 466 493 181 466 minecraft:red_terracotta
setblock 494 179 464 minecraft:terracotta
fill 494 179 465 494 182 465 minecraft:red_terracotta
setblock 494 179 504 minecraft:terracotta
fill 495 179 464 495 182 464 minecraft:red_terracotta
setblock 495 179 503 minecraft:terracotta
fill 495 179 504 498 179 504 minecraft:red_terracotta
setblock 496 179 502 minecraft:terracotta
fill 496 179 503 496 181 503 minecraft:red_terracotta
setblock 499 179 464 minecraft:terracotta
setblock 499 179 504 minecraft:terracotta
fill 500 179 464 503 179 464 minecraft:red_terracotta
fill 500 179 504 500 181 504 minecraft:red_terracotta
setblock 504 179 464 minecraft:terracotta
setblock 504 179 504 minecraft:terracotta
fill 505 179 464 505 182 464 minecraft:red_terracotta
setblock 505 179 503 minecraft:terracotta
fill 505 179 504 505 182 504 minecraft:red_terracotta
fill 506 179 465 507 179 465 minecraft:red_terracotta
fill 506 179 503 506 180 503 minecraft:red_terracotta
setblock 508 179 465 minecraft:terracotta
fill 508 179 481 508 179 484 minecraft:red_terracotta
setblock 508 179 485 minecraft:terracotta
fill 508 179 486 508 182 486 minecraft:red_terracotta
setblock 508 179 490 minecraft:terracotta
setblock 509 179 464 minecraft:terracotta
fill 509 179 465 509 181 466 minecraft:red_terracotta
setblock 509 179 478 minecraft:red_terracotta
setblock 509 179 479 minecraft:terracotta
fill 509 179 480 509 182 480 minecraft:red_terracotta
setblock 509 179 484 minecraft:terracotta
fill 509 179 485 509 182 485 minecraft:red_terracotta
setblock 509 179 488 minecraft:red_terracotta
setblock 509 179 489 minecraft:terracotta
fill 509 179 490 509 182 490 minecraft:red_terracotta
setblock 509 179 493 minecraft:red_terracotta
setblock 509 179 504 minecraft:terracotta
fill 510 179 464 510 182 464 minecraft:red_terracotta
fill 510 179 466 510 179 467 minecraft:red_terracotta
setblock 510 179 468 minecraft:terracotta
fill 510 179 469 510 179 472 minecraft:red_terracotta
setblock 510 179 473 minecraft:terracotta
fill 510 179 474 510 182 474 minecraft:red_terracotta
setblock 510 179 478 minecraft:terracotta
fill 510 179 479 510 182 479 minecraft:red_terracotta
setblock 510 179 483 minecraft:terracotta
fill 510 179 484 510 182 484 minecraft:red_terracotta
setblock 510 179 488 minecraft:terracotta
fill 510 179 489 510 182 489 minecraft:red_terracotta
setblock 510 179 492 minecraft:red_terracotta
setblock 510 179 493 minecraft:terracotta
fill 510 179 494 510 182 494 minecraft:red_terracotta
setblock 510 179 498 minecraft:terracotta
setblock 510 179 499 minecraft:red_terracotta
setblock 510 179 503 minecraft:terracotta
fill 510 179 504 510 182 504 minecraft:red_terracotta
setblock 511 179 467 minecraft:terracotta
fill 511 179 468 511 182 468 minecraft:red_terracotta
setblock 511 179 472 minecraft:terracotta
fill 511 179 473 511 182 473 minecraft:red_terracotta
setblock 511 179 477 minecraft:terracotta
fill 511 179 478 511 182 478 minecraft:red_terracotta
setblock 511 179 482 minecraft:terracotta
fill 511 179 483 511 182 483 minecraft:red_terracotta
setblock 511 179 487 minecraft:terracotta
fill 511 179 488 511 182 488 minecraft:red_terracotta
setblock 511 179 492 minecraft:terracotta
fill 511 179 493 511 182 493 minecraft:red_terracotta
setblock 511 179 497 minecraft:terracotta
fill 511 179 498 511 181 498 minecraft:red_terracotta
setblock 511 179 502 minecraft:terracotta
fill 511 179 503 511 182 503 minecraft:red_terracotta
fill 471 180 464 471 180 465 minecraft:red_terracotta
setblock 471 180 466 minecraft:terracotta
fill 471 180 467 471 180 470 minecraft:red_terracotta
setblock 471 180 471 minecraft:terracotta
fill 471 180 472 471 180 475 minecraft:red_terracotta
setblock 471 180 476 minecraft:terracotta
fill 471 180 477 471 183 477 minecraft:red_terracotta
setblock 471 180 481 minecraft:terracotta
fill 471 180 482 471 183 482 minecraft:red_terracotta
setblock 471 180 486 minecraft:terracotta
fill 471 180 487 471 183 487 minecraft:red_terracotta
setblock 471 180 491 minecraft:terracotta
fill 471 180 492 471 183 492 minecraft:red_terracotta
setblock 471 180 495 minecraft:red_terracotta
setblock 471 180 501 minecraft:terracotta
fill 471 180 502 471 182 502 minecraft:red_terracotta
setblock 472 180 465 minecraft:terracotta
fill 472 180 466 472 180 469 minecraft:red_terracotta
setblock 472 180 470 minecraft:terracotta
fill 472 180 471 472 180 474 minecraft:red_terracotta
setblock 472 180 475 minecraft:terracotta
fill 472 180 476 472 182 476 minecraft:red_terracotta
setblock 472 180 480 minecraft:terracotta
fill 472 180 481 472 182 481 minecraft:red_terracotta
setblock 472 180 485 minecraft:terracotta
fill 472 180 486 472 183 486 minecraft:red_terracotta
setblock 472 180 490 minecraft:terracotta
fill 472 180 491 472 181 491 minecraft:red_terracotta
setblock 473 180 464 minecraft:terracotta
fill 473 180 465 473 183 465 minecraft:red_terracotta
setblock 473 180 468 minecraft:red_terracotta
setblock 473 180 469 minecraft:terracotta
fill 473 180 470 473 183 470 minecraft:red_terracotta
setblock 473 180 484 minecraft:terracotta
fill 473 180 485 473 181 485 minecraft:red_terracotta
setblock 473 180 504 minecraft:terracotta
fill 474 180 464 474 183 464 minecraft:red_terracotta
fill 474 180 504 477 180 504 minecraft:red_terracotta
setblock 476 180 466 minecraft:terracotta
setblock 477 180 465 minecraft:terracotta
fill 477 180 466 480 180 466 minecraft:red_terracotta
setblock 478 180 464 minecraft:terracotta
fill 478 180 465 481 180 465 minecraft:red_terracotta
setblock 478 180 504 minecraft:terracotta
fill 479 180 464 482 180 464 minecraft:red_terracotta
fill 479 180 504 482 180 504 minecraft:red_terracotta
setblock 481 180 466 minecraft:terracotta
setblock 482 180 465 minecraft:terracotta
fill 482 180 466 482 183 466 minecraft:red_terracotta
fill 482 180 503 483 180 503 minecraft:red_terracotta
setblock 483 180 464 minecraft:terracotta
fill 483 180 465 483 183 465 minecraft:red_terracotta
setblock 483 180 504 minecraft:terracotta
fill 484 180 464 487 180 464 minecraft:red_terracotta
setblock 484 180 503 minecraft:terracotta
fill 484 180 504 487 180 504 minecraft:red_terracotta
fill 485 180 503 488 180 503 minecraft:red_terracotta
setblock 486 180 465 minecraft:red_terracotta
setblock 486 180 466 minecraft:terracotta
fill 486 180 502 486 181 502 minecraft:red_terracotta
setblock 487 180 465 minecraft:terracotta
fill 487 180 466 487 182 467 minecraft:red_terracotta
setblock 488 180 464 minecraft:terracotta
fill 488 180 465 488 183 465 minecraft:red_terracotta
setblock 488 180 504 minecraft:terracotta
fill 489 180 464 489 183 464 minecraft:red_terracotta
setblock 489 180 503 minecraft:terracotta
fill 489 180 504 492 180 504 minecraft:red_terracotta
setblock 490 180 467 minecraft:terracotta
setblock 490 180 502 minecraft:terracotta
fill 490 180 503 493 180 503 minecraft:red_terracotta
setblock 491 180 466 minecraft:terracotta
fill 491 180 502 491 182 502 minecraft:red_terracotta
setblock 492 180 465 minecraft:terracotta
fill 492 180 466 492 182 466 minecraft:red_terracotta
setblock 493 180 464 minecraft:terracotta
fill 493 180 465 493 183 465 minecraft:red_terracotta
setblock 493 180 504 minecraft:terracotta
fill 494 180 464 494 183 464 minecraft:red_terracotta
setblock 494 180 503 minecraft:terracotta
fill 494 180 504 497 180 504 minecraft:red_terracotta
fill 495 180 503 495 181 503 minecraft:red_terracotta
setblock 496 180 465 minecraft:red_terracotta
setblock 498 180 464 minecraft:terracotta
setblock 498 180 504 minecraft:terracotta
fill 499 180 464 502 180 464 minecraft:red_terracotta
fill 499 180 504 499 181 504 minecraft:red_terracotta
setblock 503 180 464 minecraft:terracotta
setblock 503 180 504 minecraft:terracotta
fill 504 180 464 504 183 464 minecraft:red_terracotta
fill 504 180 504 504 183 504 minecraft:red_terracotta
fill 505 180 465 506 180 465 minecraft:red_terracotta
setblock 505 180 503 minecraft:red_terracotta
setblock 507 180 465 minecraft:terracotta
setblock 508 180 464 minecraft:terracotta
fill 508 180 465 508 182 466 minecraft:red_terracotta
fill 508 180 481 508 180 483 minecraft:red_terracotta
setblock 508 180 484 minecraft:terracotta
fill 508 180 485 508 183 485 minecraft:red_terracotta
fill 508 180 487 508 180 488 minecraft:red_terracotta
setblock 508 180 489 minecraft:terracotta
fill 508 180 490 508 182 491 minecraft:red_terracotta
setblock 508 180 504 minecraft:terracotta
fill 509 180 464 509 183 464 minecraft:red_terracotta
setblock 509 180 467 minecraft:red_terracotta
setblock 509 180 468 minecraft:terracotta
setblock 509 180 478 minecraft:terracotta
fill 509 180 479 509 182 479 minecraft:red_terracotta
setblock 509 180 483 minecraft:terracotta
fill 509 180 484 509 183 484 minecraft:red_terracotta
setblock 509 180 488 minecraft:terracotta
fill 509 180 489 509 183 489 minecraft:red_terracotta
setblock 509 180 493 minecraft:terracotta
setblock 509 180 503 minecraft:terracotta
fill 509 180 504 509 183 504 minecraft:red_terracotta
setblock 510 180 466 minecraft:red_terracotta
setblock 510 180 467 minecraft:terracotta
fill 510 180 468 510 180 471 minecraft:red_terracotta
setblock 510 180 472 minecraft:terracotta
fill 510 180 473 510 183 473 minecraft:red_terracotta
setblock 510 180 477 minecraft:terracotta
fill 510 180 478 510 183 478 minecraft:red_terracotta
setblock 510 180 482 minecraft:terracotta
fill 510 180 483 510 183 483 minecraft:red_terracotta
setblock 510 180 487 minecraft:terracotta
fill 510 180 488 510 183 488 minecraft:red_terracotta
setblock 510 180 492 minecraft:terracotta
fill 510 180 493 510 183 493 minecraft:red_terracotta
setblock 510 180 502 minecraft:terracotta
fill 510 180 503 510 181 503 minecraft:red_terracotta
setblock 511 180 466 minecraft:terracotta
fill 511 180 467 511 183 467 minecraft:red_terracotta
setblock 511 180 471 minecraft:terracotta
fill 511 180 472 511 183 472 minecraft:red_terracotta
setblock 511 180 476 minecraft:terracotta
fill 511 180 477 511 183 477 minecraft:red_terracotta
setblock 511 180 481 minecraft:terracotta
fill 511 180 482 511 183 482 minecraft:red_terracotta
setblock 511 180 486 minecraft:terracotta
fill 511 180 487 511 183 487 minecraft:red_terracotta
setblock 511 180 491 minecraft:terracotta
fill 511 180 492 511 183 492 minecraft:red_terracotta
setblock 511 180 496 minecraft:terracotta
fill 511 180 497 511 182 497 minecraft:red_terracotta
setblock 511 180 501 minecraft:terracotta
fill 511 180 502 511 182 502 minecraft:red_terracotta
setblock 471 181 464 minecraft:red_terracotta
setblock 471 181 465 minecraft:terracotta
fill 471 181 466 471 181 469 minecraft:red_terracotta
setblock 471 181 470 minecraft:terracotta
fill 471 181 471 471 181 474 minecraft:red_terracotta
setblock 471 181 475 minecraft:terracotta
fill 471 181 476 471 184 476 minecraft:red_terracotta
setblock 471 181 480 minecraft:terracotta
fill 471 181 481 471 184 481 minecraft:red_terracotta
setblock 471 181 485 minecraft:terracotta
fill 471 181 486 471 184 486 minecraft:red_terracotta
setblock 471 181 490 minecraft:terracotta
fill 471 181 491 471 184 491 minecraft:red_terracotta
setblock 471 181 495 minecraft:terracotta
setblock 471 181 501 minecraft:red_terracotta
setblock 472 181 464 minecraft:terracotta
fill 472 181 465 472 181 468 minecraft:red_terracotta
setblock 472 181 469 minecraft:terracotta
fill 472 181 470 472 181 473 minecraft:red_terracotta
setblock 472 181 474 minecraft:terracotta
fill 472 181 475 472 182 475 minecraft:red_terracotta
setblock 472 181 479 minecraft:terracotta
fill 472 181 480 472 182 480 minecraft:red_terracotta
setblock 472 181 484 minecraft:terracotta
fill 472 181 485 472 183 485 minecraft:red_terracotta
setblock 472 181 488 minecraft:red_terracotta
setblock 472 181 489 minecraft:terracotta
fill 472 181 490 472 182 490 minecraft:red_terracotta
setblock 472 181 504 minecraft:terracotta
fill 473 181 464 473 184 464 minecraft:red_terracotta
setblock 473 181 468 minecraft:terracotta
fill 473 181 469 473 184 469 minecraft:red_terracotta
fill 473 181 471 473 182 471 minecraft:red_terracotta
setblock 473 181 484 minecraft:red_terracotta
fill 473 181 504 476 181 504 minecraft:red_terracotta
setblock 475 181 466 minecraft:terracotta
setblock 476 181 465 minecraft:terracotta
fill 476 181 466 479 181 466 minecraft:red_terracotta
setblock 477 181 464 minecraft:terracotta
fill 477 181 465 480 181 465 minecraft:red_terracotta
setblock 477 181 504 minecraft:terracotta
fill 478 181 464 481 181 464 minecraft:red_terracotta
fill 478 181 504 481 181 504 minecraft:red_terracotta
setblock 480 181 466 minecraft:terracotta
setblock 481 181 465 minecraft:terracotta
fill 481 181 466 481 182 466 minecraft:red_terracotta
setblock 482 181 464 minecraft:terracotta
fill 482 181 465 482 184 465 minecraft:red_terracotta
setblock 482 181 504 minecraft:terracotta
fill 483 181 464 486 181 464 minecraft:red_terracotta
setblock 483 181 503 minecraft:terracotta
fill 483 181 504 486 181 504 minecraft:red_terracotta
setblock 484 181 466 minecraft:red_terracotta
fill 484 181 503 487 181 503 minecraft:red_terracotta
setblock 485 181 466 minecraft:terracotta
setblock 486 181 465 minecraft:terracotta
fill 486 181 466 486 182 467 minecraft:red_terracotta
setblock 487 181 464 minecraft:terracotta
fill 487 181 465 487 184 465 minecraft:red_terracotta
setblock 487 181 504 minecraft:terracotta
fill 488 181 464 488 184 464 minecraft:red_terracotta
setblock 488 181 503 minecraft:terracotta
fill 488 181 504 491 181 504 minecraft:red_terracotta
setblock 489 181 467 minecraft:terracotta
setblock 489 181 502 minecraft:terracotta
fill 489 181 503 492 181 503 minecraft:red_terracotta
setblock 490 181 466 minecraft:terracotta
fill 490 181 502 490 182 502 minecraft:red_terracotta
setblock 491 181 465 minecraft:terracotta
fill 491 181 466 491 183 466 minecraft:red_terracotta
setblock 492 181 464 minecraft:terracotta
fill 492 181 465 492 184 465 minecraft:red_terracotta
setblock 492 181 504 minecraft:terracotta
fill 493 181 464 493 184 464 minecraft:red_terracotta
setblock 493 181 503 minecraft:terracotta
fill 493 181 504 496 181 504 minecraft:red_terracotta
fill 494 181 503 494 182 503 minecraft:red_terracotta
setblock 497 181 464 minecraft:terracotta
setblock 497 181 504 minecraft:terracotta
fill 498 181 464 501 181 464 minecraft:red_terracotta
fill 498 181 504 498 182 504 minecraft:red_terracotta
setblock 502 181 464 minecraft:terracotta
setblock 502 181 504 minecraft:terracotta
fill 503 181 464 503 183 464 minecraft:red_terracotta
fill 503 181 504 503 182 504 minecraft:red_terracotta
setblock 505 181 465 minecraft:red_terracotta
setblock 506 181 465 minecraft:terracotta
setblock 507 181 464 minecraft:terracotta
fill 507 181 465 507 184 465 minecraft:red_terracotta
setblock 507 181 504 minecraft:terracotta
fill 508 181 464 508 184 464 minecraft:red_terracotta
setblock 508 181 482 minecraft:red_terracotta
setblock 508 181 483 minecraft:terracotta
fill 508 181 484 508 183 484 minecraft:red_terracotta
setblock 508 181 487 minecraft:red_terracotta
setblock 508 181 488 minecraft:terracotta
fill 508 181 489 508 184 489 minecraft:red_terracotta
setblock 508 181 503 minecraft:terracotta
fill 508 181 504 508 184 504 minecraft:red_terracotta
setblock 509 181 467 minecraft:terracotta
fill 509 181 468 510 181 470 minecraft:red_terracotta
setblock 509 181 482 minecraft:terracotta
fill 509 181 483 509 184 483 minecraft:red_terracotta
setblock 509 181 487 minecraft:terracotta
fill 509 181 488 509 184 488 minecraft:red_terracotta
setblock 509 181 491 minecraft:red_terracotta
setblock 509 181 492 minecraft:terracotta
fill 509 181 493 509 183 493 minecraft:red_terracotta
setblock 509 181 503 minecraft:red_terracotta
setblock 510 181 466 minecraft:terracotta
fill 510 181 467 510 184 467 minecraft:red_terracotta
setblock 510 181 471 minecraft:terracotta
fill 510 181 472 510 184 472 minecraft:red_terracotta
setblock 510 181 476 minecraft:terracotta
fill 510 181 477 510 184 477 minecraft:red_terracotta
setblock 510 181 481 minecraft:terracotta
fill 510 181 482 510 184 482 minecraft:red_terracotta
setblock 510 181 486 minecraft:terracotta
fill 510 181 487 510 184 487 minecraft:red_terracotta
setblock 510 181 491 minecraft:terracotta
fill 510 181 492 510 184 492 minecraft:red_terracotta
setblock 511 181 465 minecraft:terracotta
fill 511 181 466 511 184 466 minecraft:red_terracotta
setblock 511 181 470 minecraft:terracotta
fill 511 181 471 511 184 471 minecraft:red_terracotta
setblock 511 181 475 minecraft:terracotta
fill 511 181 476 511 184 476 minecraft:red_terracotta
setblock 511 181 480 minecraft:terracotta
fill 511 181 481 511 184 481 minecraft:red_terracotta
setblock 511 181 485 minecraft:terracotta
fill 511 181 486 511 184 486 minecraft:red_terracotta
setblock 511 181 490 minecraft:terracotta
fill 511 181 491 511 184 491 minecraft:red_terracotta
setblock 511 181 495 minecraft:terracotta
fill 511 181 496 511 183 496 minecraft:red_terracotta
setblock 511 181 500 minecraft:terracotta
setblock 511 181 501 minecraft:red_terracotta
setblock 471 182 464 minecraft:terracotta
fill 471 182 465 471 182 468 minecraft:red_terracotta
setblock 471 182 469 minecraft:terracotta
fill 471 182 470 471 182 473 minecraft:red_terracotta
setblock 471 182 474 minecraft:terracotta
fill 471 182 475 471 185 475 minecraft:red_terracotta
setblock 471 182 479 minecraft:terracotta
fill 471 182 480 471 184 480 minecraft:red_terracotta
setblock 471 182 484 minecraft:terracotta
fill 471 182 485 471 185 485 minecraft:red_terracotta
setblock 471 182 489 minecraft:terracotta
fill 471 182 490 471 185 490 minecraft:red_terracotta
setblock 471 182 494 minecraft:terracotta
setblock 471 182 504 minecraft:terracotta
fill 472 182 464 472 182 467 minecraft:red_terracotta
setblock 472 182 468 minecraft:terracotta
fill 472 182 469 472 182 472 minecraft:red_terracotta
setblock 472 182 473 minecraft:terracotta
fill 472 182 474 472 184 474 minecraft:red_terracotta
setblock 472 182 478 minecraft:terracotta
setblock 472 182 479 minecraft:red_terracotta
setblock 472 182 483 minecraft:terracotta
fill 472 182 484 472 183 484 minecraft:red_terracotta
setblock 472 182 488 minecraft:terracotta
fill 472 182 489 472 183 489 minecraft:red_terracotta
fill 472 182 504 475 182 504 minecraft:red_terracotta
setblock 473 182 467 minecraft:terracotta
fill 473 182 468 473 184 468 minecraft:red_terracotta
setblock 473 182 474 minecraft:light[level=14]
setblock 473 182 482 minecraft:light[level=14]
setblock 473 182 490 minecraft:light[level=14]
setblock 473 182 498 minecraft:light[level=14]
setblock 474 182 466 minecraft:terracotta
setblock 475 182 465 minecraft:terracotta
fill 475 182 466 477 182 466 minecraft:red_terracotta
setblock 476 182 464 minecraft:terracotta
fill 476 182 465 479 182 465 minecraft:red_terracotta
setblock 476 182 504 minecraft:terracotta
fill 477 182 464 480 182 464 minecraft:red_terracotta
fill 477 182 504 480 182 504 minecraft:red_terracotta
setblock 480 182 465 minecraft:terracotta
setblock 481 182 464 minecraft:terracotta
fill 481 182 465 481 185 465 minecraft:red_terracotta
setblock 481 182 474 minecraft:light[level=14]
setblock 481 182 482 minecraft:light[level=14]
setblock 481 182 490 minecraft:light[level=14]
setblock 481 182 498 minecraft:light[level=14]
setblock 481 182 504 minecraft:terracotta
fill 482 182 464 485 182 464 minecraft:red_terracotta
fill 482 182 504 485 182 504 minecraft:red_terracotta
fill 483 182 503 486 182 503 minecraft:red_terracotta
setblock 484 182 466 minecraft:terracotta
setblock 485 182 465 minecraft:terracotta
fill 485 182 466 485 185 466 minecraft:red_terracotta
setblock 486 182 464 minecraft:terracotta
fill 486 182 465 486 185 465 minecraft:red_terracotta
setblock 486 182 504 minecraft:terracotta
fill 487 182 464 487 185 464 minecraft:red_terracotta
setblock 487 182 503 minecraft:terracotta
fill 487 182 504 490 182 504 minecraft:red_terracotta
setblock 488 182 466 minecraft:red_terracotta
setblock 488 182 467 minecraft:terracotta
setblock 488 182 502 minecraft:terracotta
fill 488 182 503 491 182 503 minecraft:red_terracotta
setblock 489 182 466 minecraft:terracotta
setblock 489 182 474 minecraft:light[level=14]
setblock 489 182 482 minecraft:light[level=14]
setblock 489 182 490 minecraft:light[level=14]
setblock 489 182 498 minecraft:light[level=14]
fill 489 182 502 489 183 502 minecraft:red_terracotta
setblock 490 182 465 minecraft:terracotta
fill 490 182 466 490 183 466 minecraft:red_terracotta
setblock 491 182 464 minecraft:terracotta
fill 491 182 465 491 184 465 minecraft:red_terracotta
setblock 491 182 504 minecraft:terracotta
fill 492 182 464 492 185 464 minecraft:red_terracotta
setblock 492 182 503 minecraft:terracotta
fill 492 182 504 495 182 504 minecraft:red_terracotta
fill 493 182 503 493 183 503 minecraft:red_terracotta
setblock 496 182 464 minecraft:terracotta
setblock 496 182 504 minecraft:terracotta
setblock 497 182 464 minecraft:red_terracotta
setblock 497 182 466 minecraft:light[level=14]
setblock 497 182 474 minecraft:light[level=14]
setblock 497 182 482 minecraft:light[level=14]
setblock 497 182 490 minecraft:light[level=14]
setblock 497 182 498 minecraft:light[level=14]
setblock 497 182 504 minecraft:red_terracotta
setblock 502 182 464 minecraft:red_terracotta
setblock 502 182 504 minecraft:red_terracotta
setblock 505 182 465 minecraft:terracotta
setblock 505 182 466 minecraft:light[level=14]
setblock 505 182 474 minecraft:light[level=14]
setblock 505 182 482 minecraft:light[level=14]
setblock 505 182 490 minecraft:light[level=14]
setblock 505 182 498 minecraft:light[level=14]
setblock 506 182 464 minecraft:terracotta
fill 506 182 465 506 185 465 minecraft:red_terracotta
setblock 506 182 504 minecraft:terracotta
fill 507 182 464 507 185 464 minecraft:red_terracotta
fill 507 182 504 507 184 504 minecraft:red_terracotta
setblock 508 182 483 minecraft:red_terracotta
setblock 508 182 487 minecraft:terracotta
fill 508 182 488 508 184 488 minecraft:red_terracotta
setblock 509 182 465 minecraft:red_terracotta
setblock 509 182 466 minecraft:terracotta
fill 509 182 467 509 182 470 minecraft:red_terracotta
setblock 509 182 471 minecraft:terracotta
setblock 509 182 481 minecraft:terracotta
fill 509 182 482 509 184 482 minecraft:red_terracotta
setblock 509 182 486 minecraft:terracotta
fill 509 182 487 509 185 487 minecraft:red_terracotta
setblock 509 182 491 minecraft:terracotta
fill 509 182 492 509 185 492 minecraft:red_terracotta
setblock 510 182 465 minecraft:terracotta
fill 510 182 466 510 185 466 minecraft:red_terracotta
fill 510 182 468 510 182 469 minecraft:red_terracotta
setblock 510 182 470 minecraft:terracotta
fill 510 182 471 510 185 471 minecraft:red_terracotta
setblock 510 182 475 minecraft:terracotta
fill 510 182 476 510 185 476 minecraft:red_terracotta
setblock 510 182 480 minecraft:terracotta
fill 510 182 481 510 185 481 minecraft:red_terracotta
setblock 510 182 485 minecraft:terracotta
fill 510 182 486 510 185 486 minecraft:red_terracotta
setblock 510 182 490 minecraft:terracotta
fill 510 182 491 510 185 491 minecraft:red_terracotta
setblock 510 182 495 minecraft:terracotta
setblock 511 182 464 minecraft:terracotta
fill 511 182 465 511 185 465 minecraft:red_terracotta
setblock 511 182 469 minecraft:terracotta
fill 511 182 470 511 185 470 minecraft:red_terracotta
setblock 511 182 474 minecraft:terracotta
fill 511 182 475 511 185 475 minecraft:red_terracotta
setblock 511 182 479 minecraft:terracotta
fill 511 182 480 511 185 480 minecraft:red_terracotta
setblock 511 182 484 minecraft:terracotta
fill 511 182 485 511 185 485 minecraft:red_terracotta
setblock 511 182 489 minecraft:terracotta
fill 511 182 490 511 185 490 minecraft:red_terracotta
setblock 511 182 494 minecraft:terracotta
fill 511 182 495 511 185 495 minecraft:red_terracotta
setblock 511 182 504 minecraft:terracotta
fill 471 183 464 471 183 467 minecraft:red_terracotta
setblock 471 183 468 minecraft:terracotta
fill 471 183 469 471 183 472 minecraft:red_terracotta
setblock 471 183 473 minecraft:terracotta
fill 471 183 474 471 186 474 minecraft:red_terracotta
setblock 471 183 478 minecraft:terracotta
fill 471 183 479 471 184 479 minecraft:red_terracotta
setblock 471 183 483 minecraft:terracotta
fill 471 183 484 471 185 484 minecraft:red_terracotta
setblock 471 183 488 minecraft:terracotta
fill 471 183 489 471 186 489 minecraft:red_terracotta
setblock 471 183 493 minecraft:terracotta
setblock 471 183 494 minecraft:red_terracotta
setblock 471 183 503 minecraft:terracotta
fill 471 183 504 473 183 504 minecraft:red_terracotta
fill 472 183 464 472 183 466 minecraft:red_terracotta
setblock 472 183 467 minecraft:terracotta
fill 472 183 468 472 183 471 minecraft:red_terracotta
setblock 472 183 472 minecraft:terracotta
fill 472 183 473 472 186 473 minecraft:red_terracotta
setblock 472 183 487 minecraft:terracotta
setblock 472 183 488 minecraft:red_terracotta
setblock 473 183 466 minecraft:terracotta
fill 473 183 467 473 184 467 minecraft:red_terracotta
setblock 474 183 465 minecraft:terracotta
fill 474 183 466 475 183 466 minecraft:red_terracotta
setblock 475 183 464 minecraft:terracotta
fill 475 183 465 478 183 465 minecraft:red_terracotta
fill 476 183 464 479 183 464 minecraft:red_terracotta
setblock 479 183 465 minecraft:terracotta
setblock 480 183 464 minecraft:terracotta
fill 480 183 465 480 186 465 minecraft:red_terracotta
setblock 480 183 504 minecraft:terracotta
fill 481 183 464 484 183 464 minecraft:red_terracotta
fill 481 183 504 484 183 504 minecraft:red_terracotta
setblock 483 183 466 minecraft:terracotta
setblock 484 183 465 minecraft:terracotta
fill 484 183 466 484 186 466 minecraft:red_terracotta
fill 484 183 503 485 183 503 minecraft:red_terracotta
setblock 485 183 464 minecraft:terracotta
fill 485 183 465 485 186 465 minecraft:red_terracotta
setblock 485 183 504 minecraft:terracotta
fill 486 183 464 486 186 464 minecraft:red_terracotta
fill 486 183 466 487 183 466 minecraft:red_terracotta
setblock 486 183 503 minecraft:terracotta
fill 486 183 504 489 183 504 minecraft:red_terracotta
fill 487 183 503 490 183 503 minecraft:red_terracotta
setblock 488 183 466 minecraft:terracotta
setblock 488 183 502 minecraft:red_terracotta
setblock 489 183 465 minecraft:terracotta
fill 489 183 466 489 184 466 minecraft:red_terracotta
setblock 490 183 464 minecraft:terracotta
fill 490 183 465 490 185 465 minecraft:red_terracotta
setblock 490 183 504 minecraft:terracotta
fill 491 183 464 491 186 464 minecraft:red_terracotta
setblock 491 183 503 minecraft:terracotta
fill 491 183 504 494 183 504 minecraft:red_terracotta
setblock 492 183 503 minecraft:red_terracotta
setblock 495 183 464 minecraft:terracotta
setblock 495 183 504 minecraft:terracotta
setblock 496 183 504 minecraft:red_terracotta
setblock 505 183 464 minecraft:terracotta
setblock 505 183 465 minecraft:red_terracotta
setblock 505 183 504 minecraft:terracotta
fill 506 183 464 506 186 464 minecraft:red_terracotta
fill 506 183 504 506 184 504 minecraft:red_terracotta
setblock 508 183 465 minecraft:red_terracotta
setblock 508 183 466 minecraft:terracotta
setblock 508 183 486 minecraft:terracotta
fill 508 183 487 508 184 487 minecraft:red_terracotta
setblock 508 183 490 minecraft:red_terracotta
setblock 508 183 491 minecraft:terracotta
setblock 509 183 465 minecraft:terracotta
fill 509 183 466 509 183 469 minecraft:red_terracotta
setblock 509 183 470 minecraft:terracotta
fill 509 183 471 509 186 471 minecraft:red_terracotta
setblock 509 183 481 minecraft:red_terracotta
setblock 509 183 485 minecraft:terracotta
fill 509 183 486 509 186 486 minecraft:red_terracotta
setblock 509 183 490 minecraft:terracotta
fill 509 183 491 509 186 491 minecraft:red_terracotta
setblock 510 183 464 minecraft:terracotta
fill 510 183 465 510 185 465 minecraft:red_terracotta
setblock 510 183 468 minecraft:red_terracotta
setblock 510 183 469 minecraft:terracotta
fill 510 183 470 510 186 470 minecraft:red_terracotta
setblock 510 183 474 minecraft:terracotta
fill 510 183 475 510 186 475 minecraft:red_terracotta
setblock 510 183 479 minecraft:terracotta
fill 510 183 480 510 184 480 minecraft:red_terracotta
setblock 510 183 484 minecraft:terracotta
fill 510 183 485 510 186 485 minecraft:red_terracotta
setblock 510 183 489 minecraft:terracotta
fill 510 183 490 510 186 490 minecraft:red_terracotta
setblock 510 183 494 minecraft:terracotta
setblock 510 183 504 minecraft:terracotta
fill 511 183 464 511 186 464 minecraft:red_terracotta
setblock 511 183 468 minecraft:terracotta
fill 511 183 469 511 186 469 minecraft:red_terracotta
setblock 511 183 473 minecraft:terracotta
fill 511 183 474 511 186 474 minecraft:red_terracotta
setblock 511 183 478 minecraft:terracotta
fill 511 183 479 511 186 479 minecraft:red_terracotta
setblock 511 183 483 minecraft:terracotta
fill 511 183 484 511 186 484 minecraft:red_terracotta
setblock 511 183 488 minecraft:terracotta
fill 511 183 489 511 186 489 minecraft:red_terracotta
setblock 511 183 493 minecraft:terracotta
fill 511 183 494 511 186 494 minecraft:red_terracotta
setblock 511 183 504 minecraft:red_terracotta
fill 471 184 464 471 184 466 minecraft:red_terracotta
setblock 471 184 467 minecraft:terracotta
fill 471 184 468 471 184 471 minecraft:red_terracotta
setblock 471 184 472 minecraft:terracotta
fill 471 184 473 471 187 473 minecraft:red_terracotta
setblock 471 184 477 minecraft:terracotta
fill 471 184 478 471 185 478 minecraft:red_terracotta
setblock 471 184 482 minecraft:terracotta
setblock 471 184 483 minecraft:red_terracotta
setblock 471 184 487 minecraft:terracotta
fill 471 184 488 471 186 488 minecraft:red_terracotta
setblock 471 184 492 minecraft:terracotta
fill 471 184 493 471 185 493 minecraft:red_terracotta
fill 472 184 464 472 184 465 minecraft:red_terracotta
setblock 472 184 466 minecraft:terracotta
fill 472 184 467 472 184 470 minecraft:red_terracotta
setblock 472 184 471 minecraft:terracotta
fill 472 184 472 472 187 472 minecraft:red_terracotta
setblock 473 184 465 minecraft:terracotta
setblock 473 184 466 minecraft:red_terracotta
setblock 473 184 470 minecraft:terracotta
setblock 474 184 464 minecraft:terracotta
fill 474 184 465 477 184 465 minecraft:red_terracotta
fill 475 184 464 478 184 464 minecraft:red_terracotta
setblock 478 184 465 minecraft:terracotta
setblock 479 184 464 minecraft:terracotta
fill 479 184 465 479 185 465 minecraft:red_terracotta
fill 480 184 464 483 184 464 minecraft:red_terracotta
fill 481 184 504 483 184 504 minecraft:red_terracotta
setblock 482 184 466 minecraft:terracotta
setblock 483 184 465 minecraft:terracotta
fill 483 184 466 483 185 466 minecraft:red_terracotta
setblock 484 184 464 minecraft:terracotta
fill 484 184 465 484 187 465 minecraft:red_terracotta
setblock 484 184 503 minecraft:red_terracotta
setblock 484 184 504 minecraft:terracotta
fill 485 184 464 485 187 464 minecraft:red_terracotta
setblock 485 184 503 minecraft:terracotta
fill 485 184 504 488 184 504 minecraft:red_terracotta
setblock 486 184 466 minecraft:red_terracotta
fill 486 184 503 489 184 503 minecraft:red_terracotta
setblock 487 184 466 minecraft:terracotta
setblock 488 184 465 minecraft:terracotta
fill 488 184 466 488 185 466 minecraft:red_terracotta
setblock 489 184 464 minecraft:terracotta
fill 489 184 465 489 186 465 minecraft:red_terracotta
setblock 489 184 504 minecraft:terracotta
fill 490 184 464 490 187 464 minecraft:red_terracotta
setblock 490 184 503 minecraft:terracotta
fill 490 184 504 493 184 504 minecraft:red_terracotta
setblock 491 184 503 minecraft:red_terracotta
setblock 494 184 464 minecraft:terracotta
setblock 494 184 504 minecraft:terracotta
setblock 504 184 464 minecraft:terracotta
fill 505 184 464 505 187 464 minecraft:red_terracotta
setblock 508 184 465 minecraft:terracotta
setblock 508 184 486 minecraft:red_terracotta
setblock 508 184 490 minecraft:terracotta
setblock 509 184 464 minecraft:terracotta
fill 509 184 465 509 185 465 minecraft:red_terracotta
fill 509 184 467 509 184 468 minecraft:red_terracotta
setblock 509 184 469 minecraft:terracotta
fill 509 184 470 509 187 470 minecraft:red_terracotta
setblock 509 184 484 minecraft:terracotta
fill 509 184 485 509 185 485 minecraft:red_terracotta
setblock 509 184 489 minecraft:terracotta
fill 509 184 490 509 187 490 minecraft:red_terracotta
fill 510 184 464 510 187 464 minecraft:red_terracotta
setblock 510 184 468 minecraft:terracotta
fill 510 184 469 510 187 469 minecraft:red_terracotta
setblock 510 184 473 minecraft:terracotta
fill 510 184 474 510 187 474 minecraft:red_terracotta
setblock 510 184 478 minecraft:terracotta
setblock 510 184 479 minecraft:red_terracotta
setblock 510 184 483 minecraft:terracotta
fill 510 184 484 510 186 484 minecraft:red_terracotta
setblock 510 184 488 minecraft:terracotta
fill 510 184 489 510 187 489 minecraft:red_terracotta
setblock 510 184 493 minecraft:terracotta
setblock 510 184 494 minecraft:red_terracotta
setblock 511 184 467 minecraft:terracotta
fill 511 184 468 511 187 468 minecraft:red_terracotta
setblock 511 184 472 minecraft:terracotta
fill 511 184 473 511 187 473 minecraft:red_terracotta
setblock 511 184 477 minecraft:terracotta
fill 511 184 478 511 187 478 minecraft:red_terracotta
setblock 511 184 482 minecraft:terracotta
fill 511 184 483 511 187 483 minecraft:red_terracotta
setblock 511 184 487 minecraft:terracotta
fill 511 184 488 511 187 488 minecraft:red_terracotta
setblock 511 184 492 minecraft:terracotta
fill 511 184 493 511 187 493 minecraft:red_terracotta
fill 471 185 464 471 185 465 minecraft:red_terracotta
setblock 471 185 466 minecraft:terracotta
fill 471 185 467 471 185 470 minecraft:red_terracotta
setblock 471 185 471 minecraft:terracotta
fill 471 185 472 471 188 472 minecraft:red_terracotta
setblock 471 185 476 minecraft:terracotta
fill 471 185 477 471 186 477 minecraft:red_terracotta
setblock 471 185 486 minecraft:terracotta
fill 471 185 487 471 186 487 minecraft:red_terracotta
setblock 471 185 491 minecraft:terracotta
fill 471 185 492 471 186 492 minecraft:red_terracotta
setblock 472 185 464 minecraft:red_terracotta
setblock 472 185 465 minecraft:terracotta
fill 472 185 466 472 185 469 minecraft:red_terracotta
setblock 472 185 470 minecraft:terracotta
fill 472 185 471 472 188 471 minecraft:red_terracotta
setblock 473 185 464 minecraft:terracotta
fill 473 185 465 475 185 465 minecraft:red_terracotta
fill 474 185 464 477 185 464 minecraft:red_terracotta
setblock 478 185 464 minecraft:terracotta
fill 479 185 464 482 185 464 minecraft:red_terracotta
fill 481 185 504 482 185 504 minecraft:red_terracotta
setblock 482 185 465 minecraft:terracotta
setblock 483 185 464 minecraft:terracotta
fill 483 185 465 483 188 465 minecraft:red_terracotta
setblock 483 185 504 minecraft:terracotta
fill 484 185 464 484 188 464 minecraft:red_terracotta
setblock 484 185 503 minecraft:terracotta
fill 484 185 504 487 185 504 minecraft:red_terracotta
fill 485 185 503 488 185 503 minecraft:red_terracotta
setblock 486 185 466 minecraft:terracotta
setblock 487 185 465 minecraft:terracotta
setblock 487 185 466 minecraft:red_terracotta
setblock 488 185 464 minecraft:terracotta
fill 488 185 465 488 187 465 minecraft:red_terracotta
setblock 488 185 504 minecraft:terracotta
fill 489 185 464 489 188 464 minecraft:red_terracotta
setblock 489 185 503 minecraft:terracotta
fill 489 185 504 492 185 504 minecraft:red_terracotta
setblock 490 185 503 minecraft:red_terracotta
fill 503 185 498 507 222 498 minecraft:terracotta
setblock 504 185 464 minecraft:red_terracotta
fill 504 185 497 507 222 497 minecraft:terracotta
fill 504 185 499 506 222 500 minecraft:terracotta
fill 505 185 496 505 222 496 minecraft:terracotta
setblock 507 185 465 minecraft:terracotta
fill 507 185 499 507 222 499 minecraft:terracotta
setblock 508 185 464 minecraft:terracotta
fill 508 185 465 508 186 465 minecraft:red_terracotta
fill 509 185 464 509 188 464 minecraft:red_terracotta
setblock 509 185 468 minecraft:terracotta
fill 509 185 469 509 188 469 minecraft:red_terracotta
setblock 509 185 472 minecraft:red_terracotta
setblock 509 185 484 minecraft:red_terracotta
setblock 509 185 488 minecraft:terracotta
fill 509 185 489 509 187 489 minecraft:red_terracotta
setblock 510 185 467 minecraft:terracotta
fill 510 185 468 510 188 468 minecraft:red_terracotta
setblock 510 185 472 minecraft:terracotta
fill 510 185 473 510 188 473 minecraft:red_terracotta
setblock 510 185 482 minecraft:terracotta
fill 510 185 483 510 186 483 minecraft:red_terracotta
setblock 510 185 487 minecraft:terracotta
fill 510 185 488 510 188 488 minecraft:red_terracotta
setblock 510 185 492 minecraft:terracotta
fill 510 185 493 510 187 493 minecraft:red_terracotta
setblock 511 185 466 minecraft:terracotta
fill 511 185 467 511 188 467 minecraft:red_terracotta
setblock 511 185 471 minecraft:terracotta
fill 511 185 472 511 188 472 minecraft:red_terracotta
setblock 511 185 476 minecraft:terracotta
fill 511 185 477 511 188 477 minecraft:red_terracotta
setblock 511 185 481 minecraft:terracotta
fill 511 185 482 511 187 482 minecraft:red_terracotta
setblock 511 185 486 minecraft:terracotta
fill 511 185 487 511 188 487 minecraft:red_terracotta
setblock 511 185 491 minecraft:terracotta
fill 511 185 492 511 188 492 minecraft:red_terracotta
setblock 471 186 464 minecraft:red_terracotta
setblock 471 186 465 minecraft:terracotta
fill 471 186 466 471 186 469 minecraft:red_terracotta
setblock 471 186 470 minecraft:terracotta
fill 471 186 471 471 189 471 minecraft:red_terracotta
setblock 471 186 475 minecraft:terracotta
fill 471 186 476 471 189 476 minecraft:red_terracotta
setblock 471 186 490 minecraft:terracotta
fill 471 186 491 471 187 491 minecraft:red_terracotta
setblock 472 186 464 minecraft:terracotta
fill 472 186 465 472 186 468 minecraft:red_terracotta
setblock 472 186 469 minecraft:terracotta
fill 472 186 470 472 189 470 minecraft:red_terracotta
fill 473 186 464 473 186 465 minecraft:red_terracotta
fill 474 186 464 476 186 464 minecraft:red_terracotta
setblock 477 186 464 minecraft:terracotta
fill 478 186 464 481 186 464 minecraft:red_terracotta
setblock 481 186 465 minecraft:terracotta
setblock 481 186 504 minecraft:red_terracotta
setblock 482 186 464 minecraft:terracotta
fill 482 186 465 482 189 465 minecraft:red_terracotta
setblock 482 186 504 minecraft:terracotta
fill 483 186 464 483 189 464 minecraft:red_terracotta
fill 483 186 504 486 186 504 minecraft:red_terracotta
setblock 485 186 466 minecraft:terracotta
fill 485 186 503 487 186 503 minecraft:red_terracotta
setblock 486 186 465 minecraft:terracotta
setblock 486 186 466 minecraft:red_terracotta
setblock 487 186 464 minecraft:terracotta
fill 487 186 465 487 188 465 minecraft:red_terracotta
setblock 487 186 504 minecraft:terracotta
fill 488 186 464 488 189 464 minecraft:red_terracotta
setblock 488 186 503 minecraft:terracotta
fill 488 186 504 491 186 504 minecraft:red_terracotta
fill 502 186 498 502 187 498 minecraft:brown_terracotta
fill 503 186 496 503 187 497 minecraft:brown_terracotta
fill 503 186 499 503 187 500 minecraft:brown_terracotta
fill 504 186 496 504 187 496 minecraft:brown_terracotta
fill 504 186 501 506 187 501 minecraft:brown_terracotta
fill 505 186 495 505 187 495 minecraft:brown_terracotta
fill 506 186 496 507 187 496 minecraft:brown_terracotta
setblock 507 186 464 minecraft:terracotta
fill 507 186 500 507 187 500 minecraft:brown_terracotta
fill 508 186 464 508 189 464 minecraft:red_terracotta
fill 508 186 497 508 187 499 minecraft:brown_terracotta
setblock 509 186 472 minecraft:terracotta
setblock 509 186 487 minecraft:terracotta
setblock 509 186 488 minecraft:red_terracotta
setblock 510 186 466 minecraft:terracotta
fill 510 186 467 510 189 467 minecraft:red_terracotta
setblock 510 186 471 minecraft:terracotta
fill 510 186 472 510 189 472 minecraft:red_terracotta
setblock 510 186 476 minecraft:terracotta
setblock 510 186 486 minecraft:terracotta
fill 510 186 487 510 187 487 minecraft:red_terracotta
setblock 510 186 491 minecraft:terracotta
fill 510 186 492 510 189 492 minecraft:red_terracotta
setblock 511 186 465 minecraft:terracotta
fill 511 186 466 511 189 466 minecraft:red_terracotta
setblock 511 186 470 minecraft:terracotta
fill 511 186 471 511 189 471 minecraft:red_terracotta
setblock 511 186 475 minecraft:terracotta
fill 511 186 476 511 189 476 minecraft:red_terracotta
setblock 511 186 480 minecraft:terracotta
fill 511 186 481 511 187 481 minecraft:red_terracotta
setblock 511 186 485 minecraft:terracotta
fill 511 186 486 511 188 486 minecraft:red_terracotta
setblock 511 186 490 minecraft:terracotta
fill 511 186 491 511 189 491 minecraft:red_terracotta
setblock 471 187 464 minecraft:terracotta
fill 471 187 465 471 187 468 minecraft:red_terracotta
setblock 471 187 469 minecraft:terracotta
fill 471 187 470 471 190 470 minecraft:red_terracotta
setblock 471 187 474 minecraft:terracotta
fill 471 187 475 471 190 475 minecraft:red_terracotta
fill 472 187 464 475 187 464 minecraft:red_terracotta
fill 472 187 466 472 187 467 minecraft:red_terracotta
setblock 472 187 468 minecraft:terracotta
fill 472 187 469 472 190 469 minecraft:red_terracotta
setblock 472 187 473 minecraft:terracotta
setblock 476 187 464 minecraft:terracotta
fill 477 187 464 480 187 464 minecraft:red_terracotta
setblock 481 187 464 minecraft:terracotta
fill 481 187 465 481 190 465 minecraft:red_terracotta
setblock 481 187 504 minecraft:terracotta
fill 482 187 464 482 190 464 minecraft:red_terracotta
fill 482 187 504 485 187 504 minecraft:red_terracotta
fill 484 187 503 486 187 503 minecraft:red_terracotta
setblock 485 187 465 minecraft:terracotta
setblock 486 187 464 minecraft:terracotta
fill 486 187 465 486 189 465 minecraft:red_terracotta
setblock 486 187 504 minecraft:terracotta
fill 487 187 464 487 190 464 minecraft:red_terracotta
setblock 487 187 503 minecraft:terracotta
fill 487 187 504 490 187 504 minecraft:red_terracotta
fill 502 187 496 502 187 497 minecraft:brown_terracotta
fill 502 187 499 502 187 500 minecraft:brown_terracotta
fill 503 187 495 504 187 495 minecraft:brown_terracotta
setblock 503 187 501 minecraft:brown_terracotta
fill 504 187 502 506 187 502 minecraft:brown_terracotta
setblock 506 187 464 minecraft:terracotta
fill 506 187 495 507 187 495 minecraft:brown_terracotta
fill 507 187 464 507 190 464 minecraft:red_terracotta
fill 507 187 501 508 187 501 minecraft:brown_terracotta
setblock 508 187 496 minecraft:brown_terracotta
setblock 508 187 500 minecraft:brown_terracotta
setblock 509 187 471 minecraft:terracotta
fill 509 187 472 509 189 473 minecraft:red_terracotta
fill 509 187 497 509 187 499 minecraft:brown_terracotta
setblock 510 187 470 minecraft:terracotta
fill 510 187 471 510 190 471 minecraft:red_terracotta
setblock 510 187 475 minecraft:terracotta
fill 510 187 476 510 190 476 minecraft:red_terracotta
setblock 510 187 486 minecraft:red_terracotta
setblock 510 187 490 minecraft:terracotta
fill 510 187 491 510 189 491 minecraft:red_terracotta
fill 511 187 465 511 188 465 minecraft:red_terracotta
setblock 511 187 469 minecraft:terracotta
fill 511 187 470 511 190 470 minecraft:red_terracotta
setblock 511 187 474 minecraft:terracotta
fill 511 187 475 511 190 475 minecraft:red_terracotta
setblock 511 187 479 minecraft:terracotta
setblock 511 187 480 minecraft:red_terracotta
setblock 511 187 484 minecraft:terracotta
fill 511 187 485 511 188 485 minecraft:red_terracotta
setblock 511 187 489 minecraft:terracotta
fill 511 187 490 511 190 490 minecraft:red_terracotta
setblock 511 187 494 minecraft:terracotta
fill 471 188 464 471 188 467 minecraft:red_terracotta
setblock 471 188 468 minecraft:terracotta
fill 471 188 469 471 191 469 minecraft:red_terracotta
setblock 471 188 473 minecraft:terracotta
fill 471 188 474 471 191 474 minecraft:red_terracotta
fill 472 188 464 473 188 464 minecraft:red_terracotta
setblock 472 188 467 minecraft:terracotta
fill 472 188 468 472 191 468 minecraft:red_terracotta
setblock 472 188 472 minecraft:terracotta
fill 472 188 473 472 191 473 minecraft:red_terracotta
fill 477 188 464 479 188 464 minecraft:red_terracotta
setblock 480 188 464 minecraft:terracotta
fill 481 188 464 481 191 464 minecraft:red_terracotta
fill 481 188 504 484 188 504 minecraft:red_terracotta
setblock 484 188 465 minecraft:terracotta
fill 484 188 503 485 188 503 minecraft:red_terracotta
setblock 485 188 464 minecraft:terracotta
fill 485 188 465 485 191 465 minecraft:red_terracotta
setblock 485 188 504 minecraft:terracotta
fill 486 188 464 486 191 464 minecraft:red_terracotta
setblock 486 188 503 minecraft:terracotta
fill 486 188 504 489 188 504 minecraft:red_terracotta
fill 487 188 503 487 191 503 minecraft:red_terracotta
setblock 490 188 504 minecraft:terracotta
setblock 505 188 464 minecraft:terracotta
fill 506 188 464 506 191 464 minecraft:red_terracotta
setblock 509 188 470 minecraft:terracotta
fill 509 188 471 509 191 471 minecraft:red_terracotta
setblock 509 188 474 minecraft:red_terracotta
setblock 510 188 469 minecraft:terracotta
fill 510 188 470 510 191 470 minecraft:red_terracotta
setblock 510 188 474 minecraft:terracotta
fill 510 188 475 510 191 475 minecraft:red_terracotta
fill 510 188 477 510 189 477 minecraft:red_terracotta
setblock 510 188 489 minecraft:terracotta
fill 510 188 490 510 189 490 minecraft:red_terracotta
setblock 511 188 468 minecraft:terracotta
fill 511 188 469 511 191 469 minecraft:red_terracotta
setblock 511 188 473 minecraft:terracotta
fill 511 188 474 511 191 474 minecraft:red_terracotta
setblock 511 188 478 minecraft:terracotta
fill 511 188 479 511 191 479 minecraft:red_terracotta
setblock 511 188 488 minecraft:terracotta
fill 511 188 489 511 190 489 minecraft:red_terracotta
setblock 511 188 493 minecraft:terracotta
fill 511 188 494 511 191 494 minecraft:red_terracotta
fill 471 189 464 471 189 466 minecraft:red_terracotta
setblock 471 189 467 minecraft:terracotta
fill 471 189 468 471 192 468 minecraft:red_terracotta
setblock 471 189 472 minecraft:terracotta
fill 471 189 473 471 192 473 minecraft:red_terracotta
setblock 471 189 477 minecraft:terracotta
fill 472 189 464 472 190 464 minecraft:red_terracotta
setblock 472 189 467 minecraft:red_terracotta
setblock 472 189 471 minecraft:terracotta
fill 472 189 472 472 192 472 minecraft:red_terracotta
fill 477 189 464 478 189 464 minecraft:red_terracotta
setblock 479 189 464 minecraft:terracotta
fill 480 189 464 480 191 465 minecraft:red_terracotta
fill 480 189 504 483 189 504 minecraft:red_terracotta
setblock 483 189 465 minecraft:terracotta
fill 483 189 503 484 189 503 minecraft:red_terracotta
setblock 484 189 464 minecraft:terracotta
fill 484 189 465 484 192 465 minecraft:red_terracotta
setblock 484 189 504 minecraft:terracotta
fill 485 189 464 485 192 464 minecraft:red_terracotta
setblock 485 189 503 minecraft:terracotta
fill 485 189 504 488 189 504 minecraft:red_terracotta
fill 486 189 503 486 192 503 minecraft:red_terracotta
setblock 489 189 504 minecraft:terracotta
fill 498 189 479 498 190 479 minecraft:magma_block
setblock 504 189 464 minecraft:terracotta
fill 505 189 464 505 192 464 minecraft:red_terracotta
setblock 509 189 469 minecraft:terracotta
fill 509 189 470 509 192 470 minecraft:red_terracotta
setblock 509 189 474 minecraft:terracotta
fill 509 189 475 509 192 475 minecraft:red_terracotta
setblock 510 189 468 minecraft:terracotta
fill 510 189 469 510 192 469 minecraft:red_terracotta
setblock 510 189 473 minecraft:terracotta
fill 510 189 474 510 192 474 minecraft:red_terracotta
setblock 511 189 467 minecraft:terracotta
fill 511 189 468 511 192 468 minecraft:red_terracotta
setblock 511 189 472 minecraft:terracotta
fill 511 189 473 511 192 473 minecraft:red_terracotta
setblock 511 189 477 minecraft:terracotta
fill 511 189 478 511 192 478 minecraft:red_terracotta
fill 511 189 480 511 190 480 minecraft:red_terracotta
setblock 511 189 487 minecraft:terracotta
fill 511 189 488 511 190 488 minecraft:red_terracotta
setblock 511 189 492 minecraft:terracotta
fill 511 189 493 511 192 493 minecraft:red_terracotta
fill 511 189 495 511 190 495 minecraft:red_terracotta
fill 471 190 464 471 190 465 minecraft:red_terracotta
setblock 471 190 466 minecraft:terracotta
fill 471 190 467 471 193 467 minecraft:red_terracotta
setblock 471 190 471 minecraft:terracotta
fill 471 190 472 471 193 472 minecraft:red_terracotta
setblock 471 190 476 minecraft:terracotta
fill 471 190 477 471 193 477 minecraft:red_terracotta
setblock 472 190 470 minecraft:terracotta
fill 472 190 471 472 193 471 minecraft:red_terracotta
setblock 472 190 474 minecraft:red_terracotta
setblock 473 190 466 minecraft:light[level=14]
setblock 473 190 474 minecraft:light[level=14]
setblock 473 190 482 minecraft:light[level=14]
setblock 473 190 490 minecraft:light[level=14]
setblock 473 190 498 minecraft:light[level=14]
fill 476 190 464 477 190 464 minecraft:red_terracotta
setblock 478 190 464 minecraft:terracotta
fill 479 190 464 479 193 464 minecraft:red_terracotta
fill 479 190 504 482 190 504 minecraft:red_terracotta
setblock 481 190 466 minecraft:light[level=14]
setblock 481 190 474 minecraft:light[level=14]
setblock 481 190 482 minecraft:light[level=14]
setblock 481 190 490 minecraft:light[level=14]
setblock 481 190 498 minecraft:light[level=14]
fill 481 190 503 483 190 503 minecraft:red_terracotta
setblock 482 190 465 minecraft:terracotta
setblock 483 190 464 minecraft:terracotta
fill 483 190 465 483 193 465 minecraft:red_terracotta
setblock 483 190 504 minecraft:terracotta
fill 484 190 464 484 193 464 minecraft:red_terracotta
setblock 484 190 503 minecraft:terracotta
fill 484 190 504 487 190 504 minecraft:red_terracotta
fill 485 190 503 485 193 503 minecraft:red_terracotta
setblock 488 190 464 minecraft:terracotta
setblock 488 190 504 minecraft:terracotta
setblock 489 190 466 minecraft:light[level=14]
setblock 489 190 474 minecraft:light[level=14]
setblock 489 190 482 minecraft:light[level=14]
setblock 489 190 490 minecraft:light[level=14]
setblock 489 190 498 minecraft:light[level=14]
fill 489 190 504 489 193 504 minecraft:red_terracotta
setblock 497 190 466 minecraft:light[level=14]
setblock 497 190 474 minecraft:light[level=14]
setblock 497 190 482 minecraft:light[level=14]
setblock 497 190 490 minecraft:light[level=14]
setblock 497 190 498 minecraft:light[level=14]
fill 504 190 464 504 193 464 minecraft:red_terracotta
setblock 505 190 466 minecraft:light[level=14]
setblock 505 190 474 minecraft:light[level=14]
setblock 505 190 482 minecraft:light[level=14]
setblock 505 190 490 minecraft:light[level=14]
setblock 508 190 464 minecraft:terracotta
setblock 509 190 469 minecraft:red_terracotta
setblock 509 190 472 minecraft:red_terracotta
setblock 509 190 473 minecraft:terracotta
fill 509 190 474 509 193 474 minecraft:red_terracotta
fill 509 190 476 509 191 476 minecraft:red_terracotta
fill 510 190 468 510 193 468 minecraft:red_terracotta
setblock 510 190 472 minecraft:terracotta
fill 510 190 473 510 193 473 minecraft:red_terracotta
setblock 510 190 477 minecraft:terracotta
fill 510 190 478 510 193 478 minecraft:red_terracotta
setblock 511 190 466 minecraft:terracotta
fill 511 190 467 511 193 467 minecraft:red_terracotta
setblock 511 190 471 minecraft:terracotta
fill 511 190 472 511 193 472 minecraft:red_terracotta
setblock 511 190 476 minecraft:terracotta
fill 511 190 477 511 193 477 minecraft:red_terracotta
setblock 511 190 491 minecraft:terracotta
fill 511 190 492 511 192 492 minecraft:red_terracotta
setblock 471 191 464 minecraft:red_terracotta
setblock 471 191 465 minecraft:terracotta
fill 471 191 466 471 194 466 minecraft:red_terracotta
setblock 471 191 470 minecraft:terracotta
fill 471 191 471 471 194 471 minecraft:red_terracotta
setblock 471 191 475 minecraft:terracotta
fill 471 191 476 471 194 476 minecraft:red_terracotta
fill 471 191 478 471 192 478 minecraft:red_terracotta
fill 471 191 493 471 191 494 minecraft:red_terracotta
setblock 471 191 495 minecraft:terracotta
fill 471 191 496 471 194 496 minecraft:red_terracotta
setblock 472 191 464 minecraft:terracotta
setblock 472 191 469 minecraft:terracotta
fill 472 191 470 472 194 470 minecraft:red_terracotta
setblock 472 191 474 minecraft:terracotta
fill 475 191 464 476 191 464 minecraft:red_terracotta
setblock 477 191 464 minecraft:terracotta
setblock 477 191 504 minecraft:terracotta
schedule function dropper:buildpart/118_7 1t
