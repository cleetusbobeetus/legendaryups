fill 144 101 617 149 102 617 minecraft:iron_block
fill 144 101 619 144 102 620 minecraft:iron_block
fill 145 101 614 148 102 614 minecraft:iron_block
fill 145 101 620 148 102 620 minecraft:iron_block
fill 146 101 615 146 102 616 minecraft:iron_block
fill 146 101 618 146 102 619 minecraft:iron_block
fill 148 101 615 149 102 615 minecraft:iron_block
fill 148 101 619 149 102 619 minecraft:iron_block
fill 149 101 616 149 102 616 minecraft:iron_block
fill 149 101 618 149 102 618 minecraft:iron_block
setblock 142 102 607 minecraft:iron_block
setblock 142 102 617 minecraft:iron_block
setblock 142 102 627 minecraft:iron_block
setblock 142 102 637 minecraft:iron_block
fill 144 102 611 144 102 613 minecraft:iron_block
setblock 144 102 645 minecraft:iron_block
fill 145 102 611 146 102 611 minecraft:iron_block
fill 145 102 613 146 102 613 minecraft:iron_block
fill 145 102 615 145 102 616 minecraft:iron_block
setblock 146 102 612 minecraft:iron_block
setblock 148 102 605 minecraft:iron_block
setblock 154 102 645 minecraft:iron_block
setblock 158 102 605 minecraft:iron_block
setblock 164 102 645 minecraft:iron_block
setblock 168 102 605 minecraft:iron_block
setblock 174 102 645 minecraft:iron_block
setblock 178 102 605 minecraft:iron_block
setblock 182 102 611 minecraft:iron_block
setblock 182 102 621 minecraft:iron_block
setblock 182 102 631 minecraft:iron_block
setblock 182 102 641 minecraft:iron_block
fill 141 103 610 141 103 613 minecraft:sea_lantern
fill 141 103 620 141 103 623 minecraft:sea_lantern
fill 141 103 630 141 103 633 minecraft:sea_lantern
fill 141 103 640 141 103 643 minecraft:sea_lantern
fill 144 103 604 147 103 604 minecraft:sea_lantern
setblock 144 103 607 minecraft:light[level=14]
setblock 144 103 615 minecraft:light[level=14]
setblock 144 103 623 minecraft:light[level=14]
setblock 144 103 631 minecraft:light[level=14]
setblock 144 103 639 minecraft:light[level=14]
fill 145 103 646 148 103 646 minecraft:sea_lantern
setblock 152 103 607 minecraft:light[level=14]
setblock 152 103 615 minecraft:light[level=14]
setblock 152 103 623 minecraft:light[level=14]
setblock 152 103 631 minecraft:light[level=14]
setblock 152 103 639 minecraft:light[level=14]
fill 154 103 604 157 103 604 minecraft:sea_lantern
fill 155 103 646 158 103 646 minecraft:sea_lantern
setblock 160 103 607 minecraft:light[level=14]
setblock 160 103 615 minecraft:light[level=14]
setblock 160 103 623 minecraft:light[level=14]
setblock 160 103 631 minecraft:light[level=14]
setblock 160 103 639 minecraft:light[level=14]
fill 164 103 604 167 103 604 minecraft:sea_lantern
fill 165 103 646 168 103 646 minecraft:sea_lantern
setblock 168 103 607 minecraft:light[level=14]
setblock 168 103 615 minecraft:light[level=14]
setblock 168 103 623 minecraft:light[level=14]
setblock 168 103 631 minecraft:light[level=14]
setblock 168 103 639 minecraft:light[level=14]
fill 174 103 604 177 103 604 minecraft:sea_lantern
fill 175 103 646 178 103 646 minecraft:sea_lantern
setblock 176 103 607 minecraft:light[level=14]
setblock 176 103 615 minecraft:light[level=14]
setblock 176 103 623 minecraft:light[level=14]
setblock 176 103 631 minecraft:light[level=14]
setblock 176 103 639 minecraft:light[level=14]
fill 183 103 605 183 103 608 minecraft:sea_lantern
fill 183 103 615 183 103 618 minecraft:sea_lantern
fill 183 103 625 183 103 628 minecraft:sea_lantern
fill 183 103 635 183 103 638 minecraft:sea_lantern
setblock 183 103 645 minecraft:sea_lantern
fill 141 104 610 141 111 613 minecraft:polished_blackstone
fill 141 104 620 141 111 623 minecraft:polished_blackstone
fill 141 104 630 141 111 633 minecraft:polished_blackstone
fill 141 104 640 141 111 643 minecraft:polished_blackstone
fill 144 104 604 147 111 604 minecraft:polished_blackstone
fill 145 104 646 148 111 646 minecraft:polished_blackstone
fill 154 104 604 157 111 604 minecraft:polished_blackstone
fill 155 104 646 158 111 646 minecraft:polished_blackstone
fill 164 104 604 167 111 604 minecraft:polished_blackstone
fill 165 104 646 168 111 646 minecraft:polished_blackstone
fill 174 104 604 177 111 604 minecraft:polished_blackstone
fill 175 104 646 178 111 646 minecraft:polished_blackstone
fill 183 104 605 183 111 608 minecraft:polished_blackstone
fill 183 104 615 183 111 618 minecraft:polished_blackstone
fill 183 104 625 183 111 628 minecraft:polished_blackstone
fill 183 104 635 183 111 638 minecraft:polished_blackstone
fill 183 104 645 183 111 645 minecraft:polished_blackstone
setblock 171 105 607 minecraft:iron_block
setblock 171 105 609 minecraft:iron_block
setblock 173 105 607 minecraft:iron_block
setblock 173 105 609 minecraft:iron_block
setblock 177 106 632 minecraft:iron_block
setblock 177 106 634 minecraft:iron_block
setblock 179 106 632 minecraft:iron_block
setblock 179 106 634 minecraft:iron_block
fill 143 107 615 143 107 617 minecraft:iron_block
fill 144 107 611 144 107 613 minecraft:iron_block
fill 144 107 615 145 107 615 minecraft:iron_block
fill 144 107 617 145 107 617 minecraft:iron_block
fill 145 107 611 146 107 611 minecraft:iron_block
fill 145 107 613 146 107 613 minecraft:iron_block
setblock 145 107 616 minecraft:iron_block
setblock 146 107 612 minecraft:iron_block
fill 180 107 633 181 108 633 minecraft:iron_block
setblock 142 108 607 minecraft:iron_block
fill 142 108 609 142 108 612 minecraft:iron_block
setblock 142 108 617 minecraft:iron_block
fill 142 108 619 142 108 622 minecraft:iron_block
setblock 142 108 627 minecraft:iron_block
fill 142 108 629 142 108 632 minecraft:iron_block
setblock 142 108 637 minecraft:iron_block
fill 142 108 639 142 108 642 minecraft:iron_block
fill 143 108 605 146 108 605 minecraft:iron_block
setblock 144 108 645 minecraft:iron_block
fill 146 108 645 149 108 645 minecraft:iron_block
setblock 148 108 605 minecraft:iron_block
fill 153 108 605 156 108 605 minecraft:iron_block
setblock 154 108 645 minecraft:iron_block
fill 156 108 645 159 108 645 minecraft:iron_block
setblock 158 108 605 minecraft:iron_block
fill 163 108 605 166 108 605 minecraft:iron_block
setblock 164 108 645 minecraft:iron_block
fill 166 108 645 169 108 645 minecraft:iron_block
setblock 168 108 605 minecraft:iron_block
fill 173 108 605 176 108 605 minecraft:iron_block
setblock 174 108 645 minecraft:iron_block
setblock 176 108 633 minecraft:sea_lantern
fill 176 108 645 179 108 645 minecraft:iron_block
setblock 178 108 605 minecraft:iron_block
fill 182 108 606 182 108 609 minecraft:iron_block
setblock 182 108 611 minecraft:iron_block
fill 182 108 616 182 108 619 minecraft:iron_block
setblock 182 108 621 minecraft:iron_block
fill 182 108 626 182 108 629 minecraft:iron_block
setblock 182 108 631 minecraft:iron_block
fill 182 108 636 182 108 639 minecraft:iron_block
setblock 182 108 641 minecraft:iron_block
setblock 144 111 607 minecraft:light[level=14]
setblock 144 111 615 minecraft:light[level=14]
setblock 144 111 623 minecraft:light[level=14]
setblock 144 111 631 minecraft:light[level=14]
setblock 144 111 639 minecraft:light[level=14]
setblock 152 111 607 minecraft:light[level=14]
setblock 152 111 615 minecraft:light[level=14]
setblock 152 111 623 minecraft:light[level=14]
setblock 152 111 631 minecraft:light[level=14]
setblock 152 111 639 minecraft:light[level=14]
setblock 160 111 607 minecraft:light[level=14]
setblock 160 111 615 minecraft:light[level=14]
setblock 160 111 623 minecraft:light[level=14]
setblock 160 111 631 minecraft:light[level=14]
setblock 160 111 639 minecraft:light[level=14]
setblock 168 111 607 minecraft:light[level=14]
setblock 168 111 615 minecraft:light[level=14]
setblock 168 111 623 minecraft:light[level=14]
setblock 168 111 631 minecraft:light[level=14]
setblock 168 111 639 minecraft:light[level=14]
setblock 171 111 607 minecraft:iron_block
setblock 171 111 609 minecraft:iron_block
setblock 173 111 607 minecraft:iron_block
setblock 173 111 609 minecraft:iron_block
setblock 176 111 607 minecraft:light[level=14]
setblock 176 111 615 minecraft:light[level=14]
setblock 176 111 623 minecraft:light[level=14]
setblock 176 111 631 minecraft:light[level=14]
setblock 176 111 639 minecraft:light[level=14]
fill 141 112 610 141 112 613 minecraft:sea_lantern
fill 141 112 620 141 112 623 minecraft:sea_lantern
fill 141 112 630 141 112 633 minecraft:sea_lantern
fill 141 112 640 141 112 643 minecraft:sea_lantern
fill 143 112 615 143 112 617 minecraft:iron_block
fill 144 112 604 147 112 604 minecraft:sea_lantern
fill 144 112 611 144 112 613 minecraft:iron_block
fill 144 112 615 145 112 615 minecraft:iron_block
fill 144 112 617 145 112 617 minecraft:iron_block
fill 145 112 611 146 112 611 minecraft:iron_block
fill 145 112 613 146 112 613 minecraft:iron_block
setblock 145 112 616 minecraft:iron_block
fill 145 112 646 148 112 646 minecraft:sea_lantern
setblock 146 112 612 minecraft:iron_block
fill 154 112 604 157 112 604 minecraft:sea_lantern
fill 155 112 646 158 112 646 minecraft:sea_lantern
fill 164 112 604 167 112 604 minecraft:sea_lantern
fill 165 112 646 168 112 646 minecraft:sea_lantern
fill 172 112 605 172 113 606 minecraft:iron_block
fill 174 112 604 177 112 604 minecraft:sea_lantern
fill 175 112 646 178 112 646 minecraft:sea_lantern
fill 183 112 605 183 112 608 minecraft:sea_lantern
fill 183 112 615 183 112 618 minecraft:sea_lantern
fill 183 112 625 183 112 628 minecraft:sea_lantern
fill 183 112 635 183 112 638 minecraft:sea_lantern
setblock 183 112 645 minecraft:sea_lantern
fill 141 113 610 141 120 613 minecraft:polished_blackstone
fill 141 113 620 141 120 623 minecraft:polished_blackstone
fill 141 113 630 141 120 633 minecraft:polished_blackstone
fill 141 113 640 141 120 643 minecraft:polished_blackstone
fill 144 113 604 147 120 604 minecraft:polished_blackstone
fill 145 113 646 148 120 646 minecraft:polished_blackstone
fill 154 113 604 157 120 604 minecraft:polished_blackstone
fill 155 113 646 158 120 646 minecraft:polished_blackstone
fill 164 113 604 167 120 604 minecraft:polished_blackstone
fill 165 113 646 168 120 646 minecraft:polished_blackstone
setblock 172 113 610 minecraft:sea_lantern
fill 174 113 604 177 120 604 minecraft:polished_blackstone
fill 175 113 646 178 120 646 minecraft:polished_blackstone
setblock 177 113 632 minecraft:iron_block
setblock 177 113 634 minecraft:iron_block
setblock 179 113 632 minecraft:iron_block
setblock 179 113 634 minecraft:iron_block
fill 183 113 605 183 120 608 minecraft:polished_blackstone
fill 183 113 615 183 120 618 minecraft:polished_blackstone
fill 183 113 625 183 120 628 minecraft:polished_blackstone
fill 183 113 635 183 120 638 minecraft:polished_blackstone
fill 183 113 645 183 120 645 minecraft:polished_blackstone
setblock 142 114 607 minecraft:iron_block
setblock 142 114 617 minecraft:iron_block
setblock 142 114 627 minecraft:iron_block
setblock 142 114 637 minecraft:iron_block
setblock 144 114 645 minecraft:iron_block
setblock 148 114 605 minecraft:iron_block
setblock 154 114 645 minecraft:iron_block
setblock 158 114 605 minecraft:iron_block
setblock 164 114 645 minecraft:iron_block
setblock 168 114 605 minecraft:iron_block
setblock 174 114 645 minecraft:iron_block
setblock 178 114 605 minecraft:iron_block
setblock 182 114 611 minecraft:iron_block
setblock 182 114 621 minecraft:iron_block
setblock 182 114 631 minecraft:iron_block
setblock 182 114 641 minecraft:iron_block
fill 142 117 609 142 117 612 minecraft:iron_block
fill 142 117 619 142 117 622 minecraft:iron_block
fill 142 117 629 142 117 632 minecraft:iron_block
fill 142 117 639 142 117 642 minecraft:iron_block
fill 143 117 605 146 117 605 minecraft:iron_block
fill 143 117 612 144 118 612 minecraft:iron_block
fill 143 117 615 143 117 617 minecraft:iron_block
fill 144 117 611 146 117 611 minecraft:iron_block
fill 144 117 613 146 117 613 minecraft:iron_block
fill 144 117 615 145 117 615 minecraft:iron_block
fill 144 117 617 145 117 617 minecraft:iron_block
setblock 145 117 616 minecraft:iron_block
setblock 146 117 612 minecraft:iron_block
fill 146 117 645 149 117 645 minecraft:iron_block
fill 153 117 605 156 117 605 minecraft:iron_block
fill 156 117 645 159 117 645 minecraft:iron_block
fill 163 117 605 166 117 605 minecraft:iron_block
fill 166 117 645 169 117 645 minecraft:iron_block
setblock 171 117 607 minecraft:iron_block
setblock 171 117 609 minecraft:iron_block
fill 173 117 605 176 117 605 minecraft:iron_block
setblock 173 117 607 minecraft:iron_block
setblock 173 117 609 minecraft:iron_block
fill 176 117 645 179 117 645 minecraft:iron_block
fill 182 117 606 182 117 609 minecraft:iron_block
fill 182 117 616 182 117 619 minecraft:iron_block
fill 182 117 626 182 117 629 minecraft:iron_block
fill 182 117 636 182 117 639 minecraft:iron_block
setblock 142 118 612 minecraft:iron_block
setblock 146 118 612 minecraft:sea_lantern
setblock 144 119 607 minecraft:light[level=14]
setblock 144 119 615 minecraft:light[level=14]
setblock 144 119 623 minecraft:light[level=14]
setblock 144 119 631 minecraft:light[level=14]
setblock 144 119 639 minecraft:light[level=14]
setblock 152 119 607 minecraft:light[level=14]
setblock 152 119 615 minecraft:light[level=14]
setblock 152 119 623 minecraft:light[level=14]
setblock 152 119 631 minecraft:light[level=14]
setblock 152 119 639 minecraft:light[level=14]
setblock 160 119 607 minecraft:light[level=14]
setblock 160 119 615 minecraft:light[level=14]
setblock 160 119 623 minecraft:light[level=14]
setblock 160 119 631 minecraft:light[level=14]
setblock 160 119 639 minecraft:light[level=14]
setblock 168 119 607 minecraft:light[level=14]
setblock 168 119 615 minecraft:light[level=14]
setblock 168 119 623 minecraft:light[level=14]
setblock 168 119 631 minecraft:light[level=14]
setblock 168 119 639 minecraft:light[level=14]
setblock 176 119 607 minecraft:light[level=14]
setblock 176 119 615 minecraft:light[level=14]
setblock 176 119 623 minecraft:light[level=14]
setblock 176 119 631 minecraft:light[level=14]
setblock 176 119 639 minecraft:light[level=14]
setblock 142 120 607 minecraft:iron_block
setblock 142 120 617 minecraft:iron_block
setblock 142 120 627 minecraft:iron_block
setblock 142 120 637 minecraft:iron_block
setblock 144 120 645 minecraft:iron_block
setblock 148 120 605 minecraft:iron_block
setblock 154 120 645 minecraft:iron_block
setblock 158 120 605 minecraft:iron_block
setblock 164 120 645 minecraft:iron_block
setblock 168 120 605 minecraft:iron_block
setblock 174 120 645 minecraft:iron_block
setblock 177 120 632 minecraft:iron_block
setblock 177 120 634 minecraft:iron_block
setblock 178 120 605 minecraft:iron_block
setblock 179 120 632 minecraft:iron_block
setblock 179 120 634 minecraft:iron_block
setblock 182 120 611 minecraft:iron_block
setblock 182 120 621 minecraft:iron_block
setblock 182 120 631 minecraft:iron_block
setblock 182 120 641 minecraft:iron_block
fill 141 121 610 141 121 613 minecraft:sea_lantern
fill 141 121 620 141 121 623 minecraft:sea_lantern
fill 141 121 630 141 121 633 minecraft:sea_lantern
fill 141 121 640 141 121 643 minecraft:sea_lantern
fill 144 121 604 147 121 604 minecraft:sea_lantern
fill 145 121 646 148 121 646 minecraft:sea_lantern
fill 154 121 604 157 121 604 minecraft:sea_lantern
fill 155 121 646 158 121 646 minecraft:sea_lantern
fill 164 121 604 167 121 604 minecraft:sea_lantern
fill 165 121 646 168 121 646 minecraft:sea_lantern
fill 174 121 604 177 121 604 minecraft:sea_lantern
fill 175 121 646 178 121 646 minecraft:sea_lantern
fill 183 121 605 183 121 608 minecraft:sea_lantern
fill 183 121 615 183 121 618 minecraft:sea_lantern
fill 183 121 625 183 121 628 minecraft:sea_lantern
fill 183 121 635 183 121 638 minecraft:sea_lantern
setblock 183 121 645 minecraft:sea_lantern
fill 141 122 610 141 129 613 minecraft:polished_blackstone
fill 141 122 620 141 129 623 minecraft:polished_blackstone
fill 141 122 630 141 129 633 minecraft:polished_blackstone
fill 141 122 640 141 129 643 minecraft:polished_blackstone
fill 143 122 615 143 122 617 minecraft:iron_block
fill 144 122 604 147 129 604 minecraft:polished_blackstone
fill 144 122 611 144 122 613 minecraft:iron_block
fill 144 122 615 145 122 615 minecraft:iron_block
fill 144 122 617 145 122 617 minecraft:iron_block
fill 145 122 611 146 122 611 minecraft:iron_block
fill 145 122 613 146 122 613 minecraft:iron_block
setblock 145 122 616 minecraft:iron_block
fill 145 122 646 148 129 646 minecraft:polished_blackstone
setblock 146 122 612 minecraft:iron_block
fill 154 122 604 157 129 604 minecraft:polished_blackstone
fill 155 122 646 158 129 646 minecraft:polished_blackstone
fill 164 122 604 167 129 604 minecraft:polished_blackstone
fill 165 122 646 168 129 646 minecraft:polished_blackstone
fill 174 122 604 177 129 604 minecraft:polished_blackstone
fill 175 122 646 178 129 646 minecraft:polished_blackstone
fill 183 122 605 183 129 608 minecraft:polished_blackstone
fill 183 122 615 183 129 618 minecraft:polished_blackstone
fill 183 122 625 183 129 628 minecraft:polished_blackstone
fill 183 122 635 183 129 638 minecraft:polished_blackstone
fill 183 122 645 183 129 645 minecraft:polished_blackstone
setblock 171 123 607 minecraft:iron_block
setblock 171 123 609 minecraft:iron_block
setblock 173 123 607 minecraft:iron_block
setblock 173 123 609 minecraft:iron_block
setblock 142 126 607 minecraft:iron_block
fill 142 126 609 142 126 612 minecraft:iron_block
setblock 142 126 617 minecraft:iron_block
fill 142 126 619 142 126 622 minecraft:iron_block
setblock 142 126 627 minecraft:iron_block
fill 142 126 629 142 126 632 minecraft:iron_block
setblock 142 126 637 minecraft:iron_block
fill 142 126 639 142 126 642 minecraft:iron_block
fill 143 126 605 146 126 605 minecraft:iron_block
setblock 144 126 645 minecraft:iron_block
fill 146 126 645 149 126 645 minecraft:iron_block
setblock 148 126 605 minecraft:iron_block
fill 153 126 605 156 126 605 minecraft:iron_block
setblock 154 126 645 minecraft:iron_block
fill 156 126 645 159 126 645 minecraft:iron_block
setblock 158 126 605 minecraft:iron_block
fill 163 126 605 166 126 605 minecraft:iron_block
setblock 164 126 645 minecraft:iron_block
fill 166 126 645 169 126 645 minecraft:iron_block
setblock 168 126 605 minecraft:iron_block
fill 173 126 605 176 126 605 minecraft:iron_block
setblock 174 126 645 minecraft:iron_block
fill 176 126 645 179 126 645 minecraft:iron_block
setblock 178 126 605 minecraft:iron_block
fill 182 126 606 182 126 609 minecraft:iron_block
setblock 182 126 611 minecraft:iron_block
fill 182 126 616 182 126 619 minecraft:iron_block
setblock 182 126 621 minecraft:iron_block
fill 182 126 626 182 126 629 minecraft:iron_block
setblock 182 126 631 minecraft:iron_block
fill 182 126 636 182 126 639 minecraft:iron_block
setblock 182 126 641 minecraft:iron_block
fill 143 127 615 143 127 617 minecraft:iron_block
setblock 144 127 607 minecraft:light[level=14]
fill 144 127 611 144 127 613 minecraft:iron_block
fill 144 127 615 145 127 615 minecraft:iron_block
fill 144 127 617 145 127 617 minecraft:iron_block
setblock 144 127 623 minecraft:light[level=14]
setblock 144 127 631 minecraft:light[level=14]
setblock 144 127 639 minecraft:light[level=14]
fill 145 127 611 146 127 611 minecraft:iron_block
fill 145 127 613 146 127 613 minecraft:iron_block
setblock 145 127 616 minecraft:iron_block
setblock 146 127 612 minecraft:iron_block
setblock 152 127 607 minecraft:light[level=14]
setblock 152 127 615 minecraft:light[level=14]
setblock 152 127 623 minecraft:light[level=14]
setblock 152 127 631 minecraft:light[level=14]
setblock 152 127 639 minecraft:light[level=14]
setblock 160 127 607 minecraft:light[level=14]
setblock 160 127 615 minecraft:light[level=14]
setblock 160 127 623 minecraft:light[level=14]
setblock 160 127 631 minecraft:light[level=14]
setblock 160 127 639 minecraft:light[level=14]
setblock 168 127 607 minecraft:light[level=14]
setblock 168 127 615 minecraft:light[level=14]
setblock 168 127 623 minecraft:light[level=14]
setblock 168 127 631 minecraft:light[level=14]
setblock 168 127 639 minecraft:light[level=14]
setblock 176 127 607 minecraft:light[level=14]
setblock 176 127 615 minecraft:light[level=14]
setblock 176 127 623 minecraft:light[level=14]
setblock 176 127 631 minecraft:light[level=14]
setblock 176 127 639 minecraft:light[level=14]
setblock 177 127 632 minecraft:iron_block
setblock 177 127 634 minecraft:iron_block
setblock 179 127 632 minecraft:iron_block
setblock 179 127 634 minecraft:iron_block
setblock 171 129 607 minecraft:iron_block
setblock 171 129 609 minecraft:iron_block
setblock 173 129 607 minecraft:iron_block
setblock 173 129 609 minecraft:iron_block
fill 141 130 610 141 130 613 minecraft:sea_lantern
fill 141 130 620 141 130 623 minecraft:sea_lantern
fill 141 130 630 141 130 633 minecraft:sea_lantern
fill 141 130 640 141 130 643 minecraft:sea_lantern
fill 144 130 604 147 130 604 minecraft:sea_lantern
fill 145 130 646 148 130 646 minecraft:sea_lantern
fill 154 130 604 157 130 604 minecraft:sea_lantern
fill 155 130 646 158 130 646 minecraft:sea_lantern
fill 164 130 604 167 130 604 minecraft:sea_lantern
fill 165 130 646 168 130 646 minecraft:sea_lantern
fill 174 130 604 177 130 604 minecraft:sea_lantern
fill 175 130 646 178 130 646 minecraft:sea_lantern
fill 183 130 605 183 130 608 minecraft:sea_lantern
fill 183 130 615 183 130 618 minecraft:sea_lantern
fill 183 130 625 183 130 628 minecraft:sea_lantern
fill 183 130 635 183 130 638 minecraft:sea_lantern
setblock 183 130 645 minecraft:sea_lantern
fill 141 131 610 141 147 613 minecraft:polished_blackstone
fill 141 131 620 141 147 623 minecraft:polished_blackstone
fill 141 131 630 141 147 633 minecraft:polished_blackstone
fill 141 131 640 141 147 643 minecraft:polished_blackstone
fill 144 131 604 147 147 604 minecraft:polished_blackstone
fill 145 131 646 148 147 646 minecraft:polished_blackstone
fill 154 131 604 157 147 604 minecraft:polished_blackstone
fill 155 131 646 158 147 646 minecraft:polished_blackstone
fill 164 131 604 167 147 604 minecraft:polished_blackstone
fill 165 131 646 168 147 646 minecraft:polished_blackstone
fill 174 131 604 177 147 604 minecraft:polished_blackstone
fill 175 131 646 178 147 646 minecraft:polished_blackstone
fill 183 131 605 183 147 608 minecraft:polished_blackstone
fill 183 131 615 183 147 618 minecraft:polished_blackstone
fill 183 131 625 183 147 628 minecraft:polished_blackstone
fill 183 131 635 183 147 638 minecraft:polished_blackstone
fill 183 131 645 183 147 645 minecraft:polished_blackstone
setblock 142 132 607 minecraft:iron_block
fill 142 132 617 145 132 617 minecraft:iron_block
setblock 142 132 627 minecraft:iron_block
setblock 142 132 637 minecraft:iron_block
fill 143 132 615 143 132 616 minecraft:iron_block
fill 144 132 611 144 132 613 minecraft:iron_block
fill 144 132 615 145 132 615 minecraft:iron_block
setblock 144 132 645 minecraft:iron_block
fill 145 132 611 146 132 611 minecraft:iron_block
fill 145 132 613 146 132 613 minecraft:iron_block
setblock 145 132 616 minecraft:iron_block
setblock 146 132 612 minecraft:iron_block
setblock 148 132 605 minecraft:iron_block
setblock 154 132 645 minecraft:iron_block
setblock 158 132 605 minecraft:iron_block
setblock 164 132 645 minecraft:iron_block
setblock 168 132 605 minecraft:iron_block
setblock 174 132 645 minecraft:iron_block
setblock 178 132 605 minecraft:iron_block
setblock 182 132 611 minecraft:iron_block
setblock 182 132 621 minecraft:iron_block
setblock 182 132 631 minecraft:iron_block
setblock 182 132 641 minecraft:iron_block
setblock 177 134 632 minecraft:iron_block
setblock 177 134 634 minecraft:iron_block
setblock 179 134 632 minecraft:iron_block
setblock 179 134 634 minecraft:iron_block
fill 142 135 609 142 135 612 minecraft:iron_block
fill 142 135 619 142 135 622 minecraft:iron_block
fill 142 135 629 142 135 632 minecraft:iron_block
fill 142 135 639 142 135 642 minecraft:iron_block
fill 143 135 605 146 135 605 minecraft:iron_block
setblock 144 135 607 minecraft:light[level=14]
setblock 144 135 615 minecraft:light[level=14]
setblock 144 135 623 minecraft:light[level=14]
setblock 144 135 631 minecraft:light[level=14]
setblock 144 135 639 minecraft:light[level=14]
fill 146 135 645 149 135 645 minecraft:iron_block
setblock 152 135 607 minecraft:light[level=14]
setblock 152 135 615 minecraft:light[level=14]
setblock 152 135 623 minecraft:light[level=14]
setblock 152 135 631 minecraft:light[level=14]
setblock 152 135 639 minecraft:light[level=14]
fill 153 135 605 156 135 605 minecraft:iron_block
fill 156 135 645 159 135 645 minecraft:iron_block
setblock 160 135 607 minecraft:light[level=14]
setblock 160 135 615 minecraft:light[level=14]
setblock 160 135 623 minecraft:light[level=14]
setblock 160 135 631 minecraft:light[level=14]
setblock 160 135 639 minecraft:light[level=14]
fill 163 135 605 166 135 605 minecraft:iron_block
fill 166 135 645 169 135 645 minecraft:iron_block
setblock 168 135 607 minecraft:light[level=14]
setblock 168 135 615 minecraft:light[level=14]
setblock 168 135 623 minecraft:light[level=14]
setblock 168 135 631 minecraft:light[level=14]
setblock 168 135 639 minecraft:light[level=14]
fill 173 135 605 176 135 605 minecraft:iron_block
setblock 176 135 607 minecraft:light[level=14]
setblock 176 135 615 minecraft:light[level=14]
setblock 176 135 623 minecraft:light[level=14]
setblock 176 135 631 minecraft:light[level=14]
setblock 176 135 639 minecraft:light[level=14]
fill 176 135 645 179 135 645 minecraft:iron_block
fill 182 135 606 182 135 609 minecraft:iron_block
fill 182 135 616 182 135 619 minecraft:iron_block
fill 182 135 626 182 135 629 minecraft:iron_block
fill 182 135 636 182 135 639 minecraft:iron_block
fill 155 140 622 157 140 624 minecraft:iron_block
fill 155 140 625 157 140 626 minecraft:light_blue_concrete
fill 156 140 620 158 140 621 minecraft:iron_block
fill 156 140 627 158 140 628 minecraft:light_blue_concrete
fill 157 140 618 159 140 619 minecraft:iron_block
fill 157 140 629 159 140 630 minecraft:light_blue_concrete
fill 158 140 617 163 140 617 minecraft:iron_block
fill 158 140 623 160 140 625 minecraft:redstone_block
fill 158 140 631 164 140 631 minecraft:light_blue_concrete
fill 160 140 616 163 144 616 minecraft:iron_block
fill 160 140 618 161 140 618 minecraft:iron_block
fill 160 140 630 161 140 630 minecraft:light_blue_concrete
fill 160 140 632 164 140 632 minecraft:light_blue_concrete
fill 162 140 615 163 144 615 minecraft:iron_block
fill 162 140 628 164 140 630 minecraft:redstone_block
fill 162 140 633 164 142 633 minecraft:light_blue_concrete
fill 164 140 615 166 140 617 minecraft:light_blue_concrete
fill 165 140 631 166 140 633 minecraft:iron_block
fill 167 140 616 168 140 618 minecraft:light_blue_concrete
fill 167 140 620 169 140 622 minecraft:redstone_block
fill 167 140 626 169 140 628 minecraft:redstone_block
fill 167 140 630 168 140 632 minecraft:iron_block
fill 169 140 617 170 140 619 minecraft:light_blue_concrete
fill 169 140 629 170 140 631 minecraft:iron_block
fill 170 140 620 172 140 621 minecraft:light_blue_concrete
fill 170 140 627 172 140 628 minecraft:iron_block
fill 171 140 618 171 144 619 minecraft:light_blue_concrete
fill 171 140 622 173 140 623 minecraft:light_blue_concrete
fill 171 140 624 173 140 626 minecraft:iron_block
fill 171 140 629 171 144 630 minecraft:iron_block
fill 154 141 623 155 142 624 minecraft:iron_block
fill 154 141 625 156 143 625 minecraft:light_blue_concrete
fill 155 141 620 156 143 622 minecraft:iron_block
fill 155 141 626 156 143 628 minecraft:light_blue_concrete
fill 156 141 618 157 143 619 minecraft:iron_block
fill 156 141 623 156 144 623 minecraft:iron_block
fill 156 141 624 157 141 624 minecraft:light_blue_stained_glass
fill 156 141 629 157 143 630 minecraft:light_blue_concrete
fill 157 141 617 160 143 617 minecraft:iron_block
fill 157 141 620 157 144 620 minecraft:iron_block
fill 157 141 621 157 141 623 minecraft:light_blue_stained_glass
fill 157 141 625 157 141 627 minecraft:light_blue_stained_glass
fill 157 141 628 157 144 628 minecraft:light_blue_concrete
fill 157 141 631 160 143 631 minecraft:light_blue_concrete
fill 158 141 616 159 143 616 minecraft:iron_block
fill 158 141 618 158 144 618 minecraft:iron_block
fill 158 141 619 166 141 622 minecraft:light_blue_stained_glass
fill 158 141 626 161 141 629 minecraft:light_blue_stained_glass
fill 158 141 630 158 144 630 minecraft:light_blue_concrete
fill 158 141 632 163 143 632 minecraft:light_blue_concrete
fill 159 141 618 169 142 618 minecraft:light_blue_stained_glass
fill 159 141 630 161 141 630 minecraft:light_blue_stained_glass
fill 160 141 615 161 142 615 minecraft:iron_block
fill 160 141 633 161 142 633 minecraft:light_blue_concrete
fill 161 141 617 167 142 617 minecraft:light_blue_stained_glass
fill 161 141 623 162 141 625 minecraft:light_blue_stained_glass
fill 161 141 631 167 141 631 minecraft:light_blue_stained_glass
fill 162 141 626 166 141 627 minecraft:light_blue_stained_glass
fill 163 141 614 163 143 614 minecraft:iron_block
fill 163 141 634 164 143 634 minecraft:light_blue_concrete
fill 164 141 614 165 142 615 minecraft:light_blue_concrete
fill 164 141 616 164 142 616 minecraft:light_blue_stained_glass
fill 164 141 632 164 142 632 minecraft:light_blue_stained_glass
fill 165 141 616 170 143 616 minecraft:light_blue_concrete
fill 165 141 628 166 141 630 minecraft:light_blue_stained_glass
fill 165 141 632 165 143 634 minecraft:iron_block
fill 166 141 615 168 142 615 minecraft:light_blue_concrete
fill 166 141 623 171 141 625 minecraft:light_blue_stained_glass
fill 166 141 632 168 142 633 minecraft:iron_block
fill 167 141 619 170 141 619 minecraft:light_blue_stained_glass
fill 167 141 629 169 141 630 minecraft:light_blue_stained_glass
fill 168 141 617 171 143 617 minecraft:light_blue_concrete
fill 168 141 631 171 143 631 minecraft:iron_block
fill 169 141 632 170 143 632 minecraft:iron_block
fill 170 141 618 170 144 618 minecraft:light_blue_concrete
fill 170 141 620 170 141 622 minecraft:light_blue_stained_glass
fill 170 141 626 170 141 629 minecraft:light_blue_stained_glass
fill 170 141 630 170 144 630 minecraft:iron_block
fill 171 141 620 173 143 620 minecraft:light_blue_concrete
fill 171 141 621 171 142 622 minecraft:light_blue_stained_glass
fill 171 141 626 171 142 627 minecraft:light_blue_stained_glass
fill 171 141 628 173 143 628 minecraft:iron_block
fill 172 141 618 172 143 619 minecraft:light_blue_concrete
fill 172 141 621 173 143 623 minecraft:light_blue_concrete
fill 172 141 624 172 142 624 minecraft:light_blue_stained_glass
fill 172 141 625 173 143 627 minecraft:iron_block
fill 172 141 629 172 143 630 minecraft:iron_block
fill 173 141 624 174 142 624 minecraft:iron_block
fill 174 141 623 174 143 623 minecraft:light_blue_concrete
fill 174 141 625 174 143 625 minecraft:iron_block
fill 142 142 605 153 142 645 minecraft:netherite_block
fill 154 142 605 154 142 621 minecraft:netherite_block
setblock 154 142 622 minecraft:iron_block
setblock 154 142 626 minecraft:light_blue_concrete
fill 154 142 627 154 142 645 minecraft:netherite_block
fill 155 142 605 155 142 618 minecraft:netherite_block
setblock 155 142 619 minecraft:iron_block
setblock 155 142 629 minecraft:light_blue_concrete
fill 155 142 630 155 142 645 minecraft:netherite_block
fill 156 142 605 156 142 617 minecraft:netherite_block
setblock 156 142 624 minecraft:light_blue_stained_glass
fill 156 142 631 156 142 645 minecraft:netherite_block
fill 157 142 605 157 142 616 minecraft:netherite_block
fill 157 142 621 165 142 621 minecraft:light_blue_stained_glass
fill 157 142 622 157 142 626 minecraft:sea_lantern
fill 157 142 627 160 142 627 minecraft:light_blue_stained_glass
fill 157 142 632 157 142 645 minecraft:netherite_block
fill 158 142 605 158 142 615 minecraft:netherite_block
fill 158 142 619 165 142 620 minecraft:light_blue_stained_glass
fill 158 142 622 162 142 622 minecraft:sea_lantern
fill 158 142 623 160 142 625 minecraft:netherite_block
fill 158 142 626 162 142 626 minecraft:sea_lantern
fill 158 142 628 160 142 629 minecraft:light_blue_stained_glass
fill 158 142 633 158 142 645 minecraft:netherite_block
fill 159 142 605 161 142 614 minecraft:netherite_block
setblock 159 142 615 minecraft:iron_block
fill 159 142 630 160 142 630 minecraft:light_blue_stained_glass
setblock 159 142 633 minecraft:light_blue_concrete
fill 159 142 634 161 142 645 minecraft:netherite_block
fill 161 142 623 161 142 625 minecraft:sea_lantern
fill 161 142 627 161 142 631 minecraft:sea_lantern
fill 162 142 605 182 142 613 minecraft:netherite_block
setblock 162 142 614 minecraft:iron_block
fill 162 142 623 162 142 625 minecraft:ochre_froglight
fill 162 142 627 166 142 627 minecraft:sea_lantern
fill 162 142 628 164 142 630 minecraft:netherite_block
fill 162 142 631 165 142 631 minecraft:sea_lantern
setblock 162 142 634 minecraft:light_blue_concrete
fill 162 142 635 182 142 645 minecraft:netherite_block
fill 163 142 622 165 142 622 minecraft:ochre_froglight
fill 163 142 626 165 142 626 minecraft:ochre_froglight
fill 165 142 628 165 142 630 minecraft:sea_lantern
setblock 166 142 614 minecraft:light_blue_concrete
fill 166 142 619 166 142 622 minecraft:sea_lantern
fill 166 142 623 166 142 625 minecraft:ochre_froglight
setblock 166 142 626 minecraft:sea_lantern
fill 166 142 628 166 142 629 minecraft:sea_lantern
fill 166 142 630 167 142 631 minecraft:light_blue_stained_glass
setblock 166 142 634 minecraft:iron_block
fill 167 142 614 182 142 614 minecraft:netherite_block
fill 167 142 619 170 142 619 minecraft:sea_lantern
fill 167 142 620 169 142 622 minecraft:netherite_block
fill 167 142 623 170 142 623 minecraft:sea_lantern
fill 167 142 624 171 142 624 minecraft:light_blue_stained_glass
fill 167 142 625 170 142 625 minecraft:sea_lantern
fill 167 142 626 169 142 628 minecraft:netherite_block
fill 167 142 629 170 142 629 minecraft:sea_lantern
fill 167 142 634 182 142 634 minecraft:netherite_block
fill 168 142 630 169 142 630 minecraft:light_blue_stained_glass
setblock 169 142 615 minecraft:light_blue_concrete
setblock 169 142 633 minecraft:iron_block
fill 170 142 615 182 142 615 minecraft:netherite_block
fill 170 142 620 170 142 622 minecraft:sea_lantern
fill 170 142 626 170 142 628 minecraft:sea_lantern
fill 170 142 633 182 142 633 minecraft:netherite_block
fill 171 142 616 182 142 616 minecraft:netherite_block
setblock 171 142 623 minecraft:light_blue_stained_glass
setblock 171 142 625 minecraft:light_blue_stained_glass
fill 171 142 632 182 142 632 minecraft:netherite_block
fill 172 142 617 182 142 617 minecraft:netherite_block
fill 172 142 631 182 142 631 minecraft:netherite_block
fill 173 142 618 182 142 618 minecraft:netherite_block
setblock 173 142 619 minecraft:light_blue_concrete
setblock 173 142 629 minecraft:iron_block
fill 173 142 630 182 142 630 minecraft:netherite_block
fill 174 142 619 182 142 621 minecraft:netherite_block
setblock 174 142 622 minecraft:light_blue_concrete
setblock 174 142 626 minecraft:iron_block
fill 174 142 627 182 142 629 minecraft:netherite_block
fill 175 142 622 182 142 626 minecraft:netherite_block
setblock 144 143 607 minecraft:light[level=14]
setblock 144 143 615 minecraft:light[level=14]
setblock 144 143 623 minecraft:light[level=14]
setblock 144 143 631 minecraft:light[level=14]
setblock 144 143 639 minecraft:light[level=14]
setblock 152 143 607 minecraft:light[level=14]
setblock 152 143 615 minecraft:light[level=14]
setblock 152 143 623 minecraft:light[level=14]
setblock 152 143 631 minecraft:light[level=14]
setblock 152 143 639 minecraft:light[level=14]
fill 154 143 623 154 143 624 minecraft:iron_block
fill 155 143 615 155 144 615 minecraft:bone_block
fill 155 143 623 155 144 623 minecraft:iron_block
fill 155 143 624 155 153 624 minecraft:bone_block
fill 155 143 633 155 144 633 minecraft:bone_block
fill 156 143 624 157 144 624 minecraft:iron_block
fill 157 143 621 158 143 623 minecraft:iron_block
fill 157 143 625 158 143 627 minecraft:light_blue_concrete
fill 158 143 615 158 144 615 minecraft:bone_block
fill 158 143 619 159 143 620 minecraft:iron_block
fill 158 143 624 158 149 624 minecraft:bone_block
fill 158 143 628 159 143 629 minecraft:light_blue_concrete
fill 158 143 633 158 144 633 minecraft:bone_block
fill 159 143 618 163 143 618 minecraft:iron_block
setblock 159 143 621 minecraft:iron_block
setblock 159 143 627 minecraft:light_blue_concrete
fill 159 143 630 164 143 630 minecraft:light_blue_concrete
setblock 160 143 607 minecraft:light[level=14]
setblock 160 143 615 minecraft:iron_block
fill 160 143 619 161 143 619 minecraft:iron_block
setblock 160 143 623 minecraft:light[level=14]
fill 160 143 629 161 143 629 minecraft:light_blue_concrete
setblock 160 143 633 minecraft:light_blue_concrete
setblock 160 143 639 minecraft:light[level=14]
fill 161 143 615 161 144 615 minecraft:bone_block
fill 161 143 617 163 144 617 minecraft:iron_block
fill 161 143 624 161 149 624 minecraft:bone_block
fill 161 143 631 164 144 631 minecraft:light_blue_concrete
fill 161 143 633 161 144 633 minecraft:bone_block
fill 162 143 633 163 144 633 minecraft:light_blue_concrete
fill 164 143 614 165 143 614 minecraft:light_blue_concrete
fill 164 143 615 164 144 615 minecraft:bone_block
fill 164 143 616 164 143 618 minecraft:light_blue_concrete
fill 164 143 632 164 144 632 minecraft:light_blue_concrete
fill 164 143 633 164 144 633 minecraft:bone_block
fill 165 143 615 166 144 615 minecraft:light_blue_concrete
fill 165 143 617 167 143 618 minecraft:light_blue_concrete
fill 165 143 630 167 143 631 minecraft:iron_block
fill 166 143 632 166 144 633 minecraft:iron_block
fill 167 143 615 167 144 615 minecraft:bone_block
fill 167 143 619 170 143 619 minecraft:light_blue_concrete
fill 167 143 624 167 149 624 minecraft:bone_block
fill 167 143 629 170 143 629 minecraft:iron_block
fill 167 143 632 168 144 632 minecraft:iron_block
fill 167 143 633 167 144 633 minecraft:bone_block
setblock 168 143 607 minecraft:light[level=14]
setblock 168 143 615 minecraft:light_blue_concrete
fill 168 143 618 169 144 618 minecraft:light_blue_concrete
setblock 168 143 623 minecraft:light[level=14]
fill 168 143 630 169 144 630 minecraft:iron_block
setblock 168 143 633 minecraft:iron_block
setblock 168 143 639 minecraft:light[level=14]
fill 169 143 620 170 143 621 minecraft:light_blue_concrete
fill 169 143 627 170 143 628 minecraft:iron_block
fill 170 143 615 170 144 615 minecraft:bone_block
fill 170 143 622 171 143 623 minecraft:light_blue_concrete
fill 170 143 624 170 149 624 minecraft:bone_block
fill 170 143 625 171 143 626 minecraft:iron_block
fill 170 143 633 170 144 633 minecraft:bone_block
fill 171 143 621 171 144 621 minecraft:light_blue_concrete
fill 171 143 624 172 144 624 minecraft:iron_block
fill 171 143 627 171 144 627 minecraft:iron_block
fill 173 143 615 173 144 615 minecraft:bone_block
fill 173 143 624 173 149 624 minecraft:bone_block
fill 173 143 633 173 144 633 minecraft:bone_block
setblock 174 143 624 minecraft:iron_block
setblock 176 143 607 minecraft:light[level=14]
setblock 176 143 615 minecraft:light[level=14]
setblock 176 143 623 minecraft:light[level=14]
setblock 176 143 631 minecraft:light[level=14]
setblock 176 143 639 minecraft:light[level=14]
fill 155 144 622 157 144 622 minecraft:iron_block
fill 155 144 625 157 144 626 minecraft:light_blue_concrete
fill 156 144 620 156 144 621 minecraft:iron_block
fill 156 144 627 156 144 628 minecraft:light_blue_concrete
fill 157 144 618 157 144 619 minecraft:iron_block
fill 157 144 621 158 144 621 minecraft:iron_block
setblock 157 144 623 minecraft:iron_block
fill 157 144 627 158 144 627 minecraft:light_blue_concrete
fill 157 144 629 157 144 630 minecraft:light_blue_concrete
fill 158 144 617 160 144 617 minecraft:iron_block
fill 158 144 619 158 144 620 minecraft:iron_block
fill 158 144 628 158 144 629 minecraft:light_blue_concrete
fill 158 144 631 160 144 631 minecraft:light_blue_concrete
fill 159 144 618 159 144 619 minecraft:iron_block
fill 159 144 629 159 144 630 minecraft:light_blue_concrete
fill 160 144 618 161 144 618 minecraft:iron_block
fill 160 144 630 161 144 630 minecraft:light_blue_concrete
fill 160 144 632 163 144 632 minecraft:light_blue_concrete
fill 164 144 616 168 144 617 minecraft:light_blue_concrete
fill 165 144 631 165 144 633 minecraft:iron_block
fill 166 144 631 170 144 631 minecraft:iron_block
setblock 167 144 618 minecraft:light_blue_concrete
setblock 167 144 630 minecraft:iron_block
fill 169 144 617 170 144 617 minecraft:light_blue_concrete
fill 169 144 619 170 144 619 minecraft:light_blue_concrete
fill 169 144 629 170 144 629 minecraft:iron_block
fill 170 144 620 170 144 621 minecraft:light_blue_concrete
fill 170 144 627 170 144 628 minecraft:iron_block
fill 171 144 620 172 144 620 minecraft:light_blue_concrete
fill 171 144 622 173 144 623 minecraft:light_blue_concrete
fill 171 144 625 173 144 626 minecraft:iron_block
fill 171 144 628 172 144 628 minecraft:iron_block
setblock 172 144 621 minecraft:light_blue_concrete
setblock 172 144 627 minecraft:iron_block
fill 155 145 616 155 146 616 minecraft:bone_block
fill 155 145 632 155 146 632 minecraft:bone_block
fill 158 145 616 158 146 616 minecraft:bone_block
fill 158 145 632 158 146 632 minecraft:bone_block
fill 161 145 616 161 146 616 minecraft:bone_block
fill 161 145 632 161 146 632 minecraft:bone_block
fill 164 145 616 164 146 616 minecraft:bone_block
fill 164 145 632 164 146 632 minecraft:bone_block
fill 167 145 616 167 146 616 minecraft:bone_block
fill 167 145 632 167 146 632 minecraft:bone_block
fill 170 145 616 170 146 616 minecraft:bone_block
fill 170 145 632 170 146 632 minecraft:bone_block
fill 173 145 616 173 146 616 minecraft:bone_block
fill 173 145 632 173 146 632 minecraft:bone_block
fill 142 146 606 142 214 606 minecraft:iron_block
fill 142 146 616 142 214 616 minecraft:iron_block
fill 142 146 622 144 147 622 minecraft:iron_block
fill 142 146 626 142 214 626 minecraft:iron_block
fill 142 146 636 142 214 636 minecraft:iron_block
fill 143 146 645 143 214 645 minecraft:iron_block
fill 146 146 607 148 214 607 minecraft:iron_block
fill 147 146 606 147 214 606 minecraft:iron_block
fill 147 146 608 147 214 608 minecraft:iron_block
fill 149 146 605 149 214 605 minecraft:iron_block
fill 153 146 645 153 214 645 minecraft:iron_block
fill 159 146 605 159 214 605 minecraft:iron_block
fill 163 146 645 163 214 645 minecraft:iron_block
fill 169 146 605 169 214 605 minecraft:iron_block
fill 170 146 640 172 214 642 minecraft:iron_block
fill 173 146 645 173 214 645 minecraft:iron_block
fill 179 146 605 179 214 605 minecraft:iron_block
fill 182 146 612 182 214 612 minecraft:iron_block
fill 182 146 622 182 214 622 minecraft:iron_block
fill 182 146 632 182 214 632 minecraft:iron_block
fill 182 146 642 182 214 642 minecraft:iron_block
fill 149 147 623 151 153 623 minecraft:bone_block
fill 149 147 625 151 153 625 minecraft:bone_block
fill 150 147 622 150 153 622 minecraft:bone_block
fill 150 147 624 152 154 624 minecraft:bone_block
fill 150 147 626 151 153 626 minecraft:bone_block
fill 155 147 617 155 148 617 minecraft:bone_block
fill 155 147 631 155 148 631 minecraft:bone_block
fill 158 147 617 158 148 617 minecraft:bone_block
fill 158 147 631 158 148 631 minecraft:bone_block
fill 161 147 617 161 148 617 minecraft:bone_block
fill 161 147 631 161 148 631 minecraft:bone_block
fill 164 147 617 164 148 617 minecraft:bone_block
fill 164 147 631 164 148 631 minecraft:bone_block
fill 167 147 617 167 148 617 minecraft:bone_block
fill 167 147 631 167 148 631 minecraft:bone_block
fill 170 147 617 170 148 617 minecraft:bone_block
fill 170 147 631 170 148 631 minecraft:bone_block
fill 173 147 617 173 148 617 minecraft:bone_block
fill 173 147 631 173 148 631 minecraft:bone_block
fill 141 148 610 141 148 613 minecraft:sea_lantern
fill 141 148 620 141 148 623 minecraft:sea_lantern
fill 141 148 630 141 148 633 minecraft:sea_lantern
fill 141 148 640 141 148 643 minecraft:sea_lantern
fill 144 148 604 147 148 604 minecraft:sea_lantern
fill 145 148 646 148 148 646 minecraft:sea_lantern
setblock 146 148 606 minecraft:iron_block
setblock 146 148 608 minecraft:iron_block
setblock 148 148 606 minecraft:iron_block
setblock 148 148 608 minecraft:iron_block
fill 148 148 622 148 151 623 minecraft:bone_block
fill 149 148 622 149 152 622 minecraft:bone_block
fill 149 148 624 149 154 624 minecraft:bone_block
fill 149 148 626 149 152 626 minecraft:bone_block
fill 150 148 627 152 152 627 minecraft:bone_block
fill 151 148 622 152 154 622 minecraft:bone_block
fill 152 148 623 153 154 623 minecraft:bone_block
fill 152 148 625 153 153 626 minecraft:bone_block
fill 153 148 624 154 153 624 minecraft:bone_block
fill 154 148 604 157 148 604 minecraft:sea_lantern
fill 154 148 625 154 152 625 minecraft:bone_block
fill 155 148 618 155 150 618 minecraft:bone_block
fill 155 148 630 155 150 630 minecraft:bone_block
fill 155 148 646 158 148 646 minecraft:sea_lantern
fill 158 148 618 158 150 618 minecraft:bone_block
fill 158 148 630 158 150 630 minecraft:bone_block
fill 161 148 618 161 150 618 minecraft:bone_block
fill 161 148 630 161 150 630 minecraft:bone_block
fill 164 148 604 167 148 604 minecraft:sea_lantern
fill 164 148 618 164 150 618 minecraft:bone_block
fill 164 148 630 164 150 630 minecraft:bone_block
fill 165 148 646 168 148 646 minecraft:sea_lantern
fill 167 148 618 167 150 618 minecraft:bone_block
fill 167 148 630 167 150 630 minecraft:bone_block
fill 169 148 640 169 148 642 minecraft:iron_block
fill 170 148 618 170 150 618 minecraft:bone_block
fill 170 148 630 170 150 630 minecraft:bone_block
fill 170 148 639 172 148 639 minecraft:iron_block
fill 170 148 643 172 148 643 minecraft:iron_block
fill 173 148 618 173 150 618 minecraft:bone_block
fill 173 148 630 173 150 630 minecraft:bone_block
fill 173 148 640 173 148 642 minecraft:iron_block
fill 174 148 604 177 148 604 minecraft:sea_lantern
fill 175 148 646 178 148 646 minecraft:sea_lantern
fill 183 148 605 183 148 608 minecraft:sea_lantern
fill 183 148 615 183 148 618 minecraft:sea_lantern
fill 183 148 625 183 148 628 minecraft:sea_lantern
fill 183 148 635 183 148 638 minecraft:sea_lantern
setblock 183 148 645 minecraft:sea_lantern
fill 141 149 610 141 156 613 minecraft:polished_blackstone
fill 141 149 620 141 156 623 minecraft:polished_blackstone
fill 141 149 630 141 156 633 minecraft:polished_blackstone
fill 141 149 640 141 156 643 minecraft:polished_blackstone
fill 144 149 604 147 156 604 minecraft:polished_blackstone
fill 145 149 646 148 156 646 minecraft:polished_blackstone
fill 148 149 624 148 151 626 minecraft:bone_block
fill 149 149 621 152 151 621 minecraft:bone_block
fill 149 149 627 149 151 627 minecraft:bone_block
fill 151 149 642 151 150 644 minecraft:iron_block
fill 153 149 622 153 153 622 minecraft:bone_block
fill 153 149 627 153 152 627 minecraft:bone_block
fill 154 149 604 157 156 604 minecraft:polished_blackstone
fill 154 149 623 155 152 623 minecraft:bone_block
fill 154 149 626 154 152 626 minecraft:bone_block
fill 155 149 625 155 152 625 minecraft:bone_block
fill 155 149 646 158 156 646 minecraft:polished_blackstone
fill 158 149 623 158 152 623 minecraft:bone_block
fill 158 149 625 158 152 625 minecraft:bone_block
fill 161 149 623 161 152 623 minecraft:bone_block
fill 161 149 625 161 152 625 minecraft:bone_block
fill 164 149 604 167 156 604 minecraft:polished_blackstone
fill 164 149 625 164 152 625 minecraft:bone_block
fill 165 149 646 168 156 646 minecraft:polished_blackstone
fill 167 149 623 167 152 623 minecraft:bone_block
fill 167 149 625 167 152 625 minecraft:bone_block
fill 170 149 623 170 152 623 minecraft:bone_block
fill 170 149 625 170 152 625 minecraft:bone_block
fill 173 149 623 173 152 623 minecraft:bone_block
fill 173 149 625 173 152 625 minecraft:bone_block
fill 174 149 604 177 156 604 minecraft:polished_blackstone
fill 175 149 646 178 156 646 minecraft:polished_blackstone
fill 183 149 605 183 156 608 minecraft:polished_blackstone
fill 183 149 615 183 156 618 minecraft:polished_blackstone
fill 183 149 625 183 156 628 minecraft:polished_blackstone
fill 183 149 635 183 156 638 minecraft:polished_blackstone
fill 183 149 645 183 156 645 minecraft:polished_blackstone
setblock 142 150 607 minecraft:iron_block
setblock 142 150 617 minecraft:iron_block
setblock 142 150 627 minecraft:iron_block
setblock 142 150 637 minecraft:iron_block
setblock 144 150 645 minecraft:iron_block
setblock 148 150 605 minecraft:iron_block
setblock 151 150 628 minecraft:bone_block
fill 153 150 621 153 153 621 minecraft:bone_block
fill 154 150 622 154 152 622 minecraft:bone_block
setblock 154 150 645 minecraft:iron_block
fill 155 150 619 155 151 619 minecraft:bone_block
fill 155 150 629 155 151 629 minecraft:bone_block
setblock 158 150 605 minecraft:iron_block
fill 158 150 619 158 151 619 minecraft:bone_block
fill 158 150 629 158 151 629 minecraft:bone_block
fill 161 150 619 161 151 619 minecraft:bone_block
fill 161 150 629 161 151 629 minecraft:bone_block
fill 164 150 619 164 151 619 minecraft:bone_block
fill 164 150 629 164 151 629 minecraft:bone_block
setblock 164 150 645 minecraft:iron_block
fill 167 150 619 167 151 619 minecraft:bone_block
fill 167 150 629 167 151 629 minecraft:bone_block
setblock 168 150 605 minecraft:iron_block
fill 170 150 619 170 151 619 minecraft:bone_block
fill 170 150 629 170 151 629 minecraft:bone_block
fill 173 150 619 173 151 619 minecraft:bone_block
fill 173 150 629 173 151 629 minecraft:bone_block
setblock 174 150 645 minecraft:iron_block
setblock 178 150 605 minecraft:iron_block
setblock 182 150 611 minecraft:iron_block
setblock 182 150 621 minecraft:iron_block
setblock 182 150 631 minecraft:iron_block
setblock 182 150 641 minecraft:iron_block
setblock 144 151 607 minecraft:light[level=14]
setblock 144 151 615 minecraft:light[level=14]
setblock 144 151 623 minecraft:light[level=14]
setblock 144 151 631 minecraft:light[level=14]
setblock 144 151 639 minecraft:light[level=14]
setblock 152 151 607 minecraft:light[level=14]
setblock 152 151 615 minecraft:light[level=14]
setblock 152 151 631 minecraft:light[level=14]
setblock 152 151 639 minecraft:light[level=14]
fill 155 151 620 155 152 620 minecraft:bone_block
fill 155 151 628 155 152 628 minecraft:bone_block
fill 158 151 620 158 152 620 minecraft:bone_block
fill 158 151 628 158 152 628 minecraft:bone_block
setblock 160 151 607 minecraft:light[level=14]
setblock 160 151 615 minecraft:light[level=14]
setblock 160 151 623 minecraft:light[level=14]
setblock 160 151 631 minecraft:light[level=14]
setblock 160 151 639 minecraft:light[level=14]
fill 161 151 620 161 152 620 minecraft:bone_block
fill 161 151 628 161 152 628 minecraft:bone_block
fill 164 151 620 164 152 620 minecraft:bone_block
fill 164 151 628 164 152 628 minecraft:bone_block
fill 167 151 620 167 152 620 minecraft:bone_block
fill 167 151 628 167 152 628 minecraft:bone_block
setblock 168 151 607 minecraft:light[level=14]
setblock 168 151 615 minecraft:light[level=14]
setblock 168 151 623 minecraft:light[level=14]
setblock 168 151 631 minecraft:light[level=14]
setblock 168 151 639 minecraft:light[level=14]
fill 170 151 620 170 152 620 minecraft:bone_block
fill 170 151 628 170 152 628 minecraft:bone_block
fill 173 151 620 173 152 620 minecraft:bone_block
fill 173 151 628 173 152 628 minecraft:bone_block
setblock 176 151 607 minecraft:light[level=14]
setblock 176 151 615 minecraft:light[level=14]
setblock 176 151 623 minecraft:light[level=14]
setblock 176 151 631 minecraft:light[level=14]
setblock 176 151 639 minecraft:light[level=14]
fill 146 152 605 146 153 606 minecraft:iron_block
fill 148 152 623 148 152 625 minecraft:bone_block
fill 150 152 621 152 152 621 minecraft:bone_block
fill 155 152 621 155 152 622 minecraft:bone_block
fill 155 152 626 155 152 627 minecraft:bone_block
fill 156 152 624 161 153 624 minecraft:bone_block
fill 158 152 621 158 152 622 minecraft:bone_block
fill 158 152 626 158 152 627 minecraft:bone_block
fill 161 152 621 161 152 622 minecraft:bone_block
fill 161 152 626 161 152 627 minecraft:bone_block
fill 164 152 621 164 152 622 minecraft:bone_block
fill 164 152 626 164 152 627 minecraft:bone_block
fill 165 152 624 175 153 624 minecraft:bone_block
fill 167 152 621 167 152 622 minecraft:bone_block
fill 167 152 626 167 152 627 minecraft:bone_block
fill 170 152 621 170 152 622 minecraft:bone_block
fill 170 152 626 170 152 627 minecraft:bone_block
fill 173 152 621 173 152 622 minecraft:bone_block
fill 173 152 626 173 152 627 minecraft:bone_block
fill 142 153 609 142 153 612 minecraft:iron_block
fill 142 153 619 142 153 622 minecraft:iron_block
fill 142 153 629 142 153 632 minecraft:iron_block
fill 142 153 639 142 153 642 minecraft:iron_block
fill 143 153 605 145 153 605 minecraft:iron_block
fill 146 153 645 149 153 645 minecraft:iron_block
setblock 148 153 624 minecraft:bone_block
fill 151 153 621 152 153 621 minecraft:bone_block
fill 153 153 605 156 153 605 minecraft:iron_block
setblock 154 153 623 minecraft:bone_block
fill 156 153 645 159 153 645 minecraft:iron_block
fill 163 153 605 166 153 605 minecraft:iron_block
fill 166 153 645 169 153 645 minecraft:iron_block
fill 173 153 605 176 153 605 minecraft:iron_block
fill 176 153 645 179 153 645 minecraft:iron_block
fill 182 153 606 182 153 609 minecraft:iron_block
fill 182 153 616 182 153 619 minecraft:iron_block
fill 182 153 626 182 153 629 minecraft:iron_block
fill 182 153 636 182 153 639 minecraft:iron_block
setblock 146 154 606 minecraft:iron_block
setblock 146 154 608 minecraft:iron_block
setblock 148 154 606 minecraft:iron_block
setblock 148 154 608 minecraft:iron_block
setblock 151 154 623 minecraft:bone_block
fill 151 154 625 152 154 625 minecraft:bone_block
fill 169 154 640 169 154 642 minecraft:iron_block
fill 170 154 639 172 154 639 minecraft:iron_block
fill 170 154 643 172 154 643 minecraft:iron_block
fill 173 154 640 173 154 642 minecraft:iron_block
setblock 142 156 607 minecraft:iron_block
setblock 142 156 617 minecraft:iron_block
setblock 142 156 627 minecraft:iron_block
setblock 142 156 637 minecraft:iron_block
setblock 144 156 645 minecraft:iron_block
setblock 148 156 605 minecraft:iron_block
setblock 154 156 645 minecraft:iron_block
setblock 158 156 605 minecraft:iron_block
setblock 164 156 645 minecraft:iron_block
setblock 168 156 605 minecraft:iron_block
setblock 174 156 645 minecraft:iron_block
setblock 178 156 605 minecraft:iron_block
setblock 182 156 611 minecraft:iron_block
setblock 182 156 621 minecraft:iron_block
setblock 182 156 631 minecraft:iron_block
setblock 182 156 641 minecraft:iron_block
fill 141 157 610 141 157 613 minecraft:sea_lantern
fill 141 157 620 141 157 623 minecraft:sea_lantern
fill 141 157 630 141 157 633 minecraft:sea_lantern
fill 141 157 640 141 157 643 minecraft:sea_lantern
fill 144 157 604 147 157 604 minecraft:sea_lantern
fill 145 157 646 148 157 646 minecraft:sea_lantern
fill 154 157 604 157 157 604 minecraft:sea_lantern
fill 155 157 646 158 157 646 minecraft:sea_lantern
fill 164 157 604 167 157 604 minecraft:sea_lantern
fill 165 157 646 168 157 646 minecraft:sea_lantern
fill 174 157 604 177 157 604 minecraft:sea_lantern
fill 175 157 646 178 157 646 minecraft:sea_lantern
fill 183 157 605 183 157 608 minecraft:sea_lantern
fill 183 157 615 183 157 618 minecraft:sea_lantern
fill 183 157 625 183 157 628 minecraft:sea_lantern
fill 183 157 635 183 157 638 minecraft:sea_lantern
setblock 183 157 645 minecraft:sea_lantern
fill 141 158 610 141 165 613 minecraft:polished_blackstone
fill 141 158 620 141 165 623 minecraft:polished_blackstone
fill 141 158 630 141 165 633 minecraft:polished_blackstone
fill 141 158 640 141 165 643 minecraft:polished_blackstone
fill 144 158 604 147 165 604 minecraft:polished_blackstone
fill 145 158 646 148 165 646 minecraft:polished_blackstone
fill 154 158 604 157 165 604 minecraft:polished_blackstone
fill 155 158 646 158 165 646 minecraft:polished_blackstone
fill 164 158 604 167 165 604 minecraft:polished_blackstone
fill 165 158 646 168 165 646 minecraft:polished_blackstone
fill 174 158 604 177 165 604 minecraft:polished_blackstone
fill 175 158 646 178 165 646 minecraft:polished_blackstone
fill 183 158 605 183 165 608 minecraft:polished_blackstone
fill 183 158 615 183 165 618 minecraft:polished_blackstone
fill 183 158 625 183 165 628 minecraft:polished_blackstone
fill 183 158 635 183 165 638 minecraft:polished_blackstone
fill 183 158 645 183 165 645 minecraft:polished_blackstone
setblock 144 159 607 minecraft:light[level=14]
setblock 144 159 615 minecraft:light[level=14]
setblock 144 159 623 minecraft:light[level=14]
setblock 144 159 631 minecraft:light[level=14]
setblock 144 159 639 minecraft:light[level=14]
setblock 152 159 607 minecraft:light[level=14]
setblock 152 159 615 minecraft:light[level=14]
setblock 152 159 623 minecraft:light[level=14]
setblock 152 159 631 minecraft:light[level=14]
setblock 152 159 639 minecraft:light[level=14]
setblock 160 159 607 minecraft:light[level=14]
setblock 160 159 615 minecraft:light[level=14]
setblock 160 159 623 minecraft:light[level=14]
setblock 160 159 631 minecraft:light[level=14]
setblock 160 159 639 minecraft:light[level=14]
setblock 168 159 607 minecraft:light[level=14]
setblock 168 159 615 minecraft:light[level=14]
setblock 168 159 623 minecraft:light[level=14]
setblock 168 159 631 minecraft:light[level=14]
setblock 168 159 639 minecraft:light[level=14]
setblock 176 159 607 minecraft:light[level=14]
setblock 176 159 615 minecraft:light[level=14]
setblock 176 159 623 minecraft:light[level=14]
setblock 176 159 631 minecraft:light[level=14]
setblock 176 159 639 minecraft:light[level=14]
setblock 146 160 606 minecraft:iron_block
setblock 146 160 608 minecraft:iron_block
setblock 148 160 606 minecraft:iron_block
setblock 148 160 608 minecraft:iron_block
fill 169 160 640 169 160 642 minecraft:iron_block
fill 170 160 639 172 160 639 minecraft:iron_block
fill 170 160 643 172 160 643 minecraft:iron_block
fill 173 160 640 173 160 642 minecraft:iron_block
setblock 142 162 607 minecraft:iron_block
fill 142 162 609 142 162 612 minecraft:iron_block
setblock 142 162 617 minecraft:iron_block
fill 142 162 619 142 162 622 minecraft:iron_block
setblock 142 162 627 minecraft:iron_block
fill 142 162 629 142 162 632 minecraft:iron_block
setblock 142 162 637 minecraft:iron_block
fill 142 162 639 142 162 642 minecraft:iron_block
fill 143 162 605 146 162 605 minecraft:iron_block
fill 143 162 609 144 163 609 minecraft:iron_block
setblock 144 162 645 minecraft:iron_block
fill 146 162 645 149 162 645 minecraft:iron_block
setblock 148 162 605 minecraft:iron_block
fill 153 162 605 156 162 605 minecraft:iron_block
setblock 154 162 645 minecraft:iron_block
fill 156 162 645 159 162 645 minecraft:iron_block
setblock 158 162 605 minecraft:iron_block
fill 163 162 605 166 162 605 minecraft:iron_block
setblock 164 162 645 minecraft:iron_block
fill 166 162 645 169 162 645 minecraft:iron_block
setblock 168 162 605 minecraft:iron_block
fill 173 162 605 176 162 605 minecraft:iron_block
setblock 174 162 645 minecraft:iron_block
fill 176 162 645 179 162 645 minecraft:iron_block
setblock 178 162 605 minecraft:iron_block
fill 182 162 606 182 162 609 minecraft:iron_block
setblock 182 162 611 minecraft:iron_block
fill 182 162 616 182 162 619 minecraft:iron_block
setblock 182 162 621 minecraft:iron_block
fill 182 162 626 182 162 629 minecraft:iron_block
setblock 182 162 631 minecraft:iron_block
fill 182 162 636 182 162 639 minecraft:iron_block
setblock 182 162 641 minecraft:iron_block
setblock 142 163 609 minecraft:iron_block
fill 141 166 610 141 166 613 minecraft:sea_lantern
fill 141 166 620 141 166 623 minecraft:sea_lantern
fill 141 166 630 141 166 633 minecraft:sea_lantern
fill 141 166 640 141 166 643 minecraft:sea_lantern
fill 144 166 604 147 166 604 minecraft:sea_lantern
fill 145 166 646 148 166 646 minecraft:sea_lantern
setblock 146 166 606 minecraft:iron_block
setblock 146 166 608 minecraft:iron_block
setblock 148 166 606 minecraft:iron_block
setblock 148 166 608 minecraft:iron_block
fill 154 166 604 157 166 604 minecraft:sea_lantern
fill 155 166 646 158 166 646 minecraft:sea_lantern
fill 164 166 604 167 166 604 minecraft:sea_lantern
fill 165 166 646 168 166 646 minecraft:sea_lantern
fill 169 166 640 169 166 642 minecraft:iron_block
fill 170 166 639 172 166 639 minecraft:iron_block
fill 170 166 643 172 166 643 minecraft:iron_block
fill 173 166 640 173 166 642 minecraft:iron_block
fill 174 166 604 177 166 604 minecraft:sea_lantern
fill 175 166 646 178 166 646 minecraft:sea_lantern
fill 183 166 605 183 166 608 minecraft:sea_lantern
fill 183 166 615 183 166 618 minecraft:sea_lantern
fill 183 166 625 183 166 628 minecraft:sea_lantern
fill 183 166 635 183 166 638 minecraft:sea_lantern
setblock 183 166 645 minecraft:sea_lantern
fill 141 167 610 141 174 613 minecraft:polished_blackstone
fill 141 167 620 141 174 623 minecraft:polished_blackstone
fill 141 167 630 141 174 633 minecraft:polished_blackstone
fill 141 167 640 141 174 643 minecraft:polished_blackstone
fill 144 167 604 147 174 604 minecraft:polished_blackstone
setblock 144 167 607 minecraft:light[level=14]
setblock 144 167 615 minecraft:light[level=14]
setblock 144 167 623 minecraft:light[level=14]
setblock 144 167 631 minecraft:light[level=14]
setblock 144 167 639 minecraft:light[level=14]
fill 145 167 646 148 174 646 minecraft:polished_blackstone
setblock 152 167 607 minecraft:light[level=14]
fill 152 167 610 152 175 610 minecraft:iron_block
setblock 152 167 615 minecraft:light[level=14]
setblock 152 167 623 minecraft:light[level=14]
setblock 152 167 631 minecraft:light[level=14]
setblock 152 167 639 minecraft:light[level=14]
fill 154 167 604 157 174 604 minecraft:polished_blackstone
fill 155 167 646 158 174 646 minecraft:polished_blackstone
setblock 160 167 607 minecraft:light[level=14]
setblock 160 167 615 minecraft:light[level=14]
setblock 160 167 623 minecraft:light[level=14]
setblock 160 167 631 minecraft:light[level=14]
setblock 160 167 639 minecraft:light[level=14]
fill 164 167 604 167 174 604 minecraft:polished_blackstone
fill 165 167 646 168 174 646 minecraft:polished_blackstone
setblock 168 167 607 minecraft:light[level=14]
setblock 168 167 615 minecraft:light[level=14]
setblock 168 167 623 minecraft:light[level=14]
setblock 168 167 631 minecraft:light[level=14]
setblock 168 167 639 minecraft:light[level=14]
fill 174 167 604 177 174 604 minecraft:polished_blackstone
fill 175 167 646 178 174 646 minecraft:polished_blackstone
setblock 176 167 607 minecraft:light[level=14]
setblock 176 167 615 minecraft:light[level=14]
setblock 176 167 623 minecraft:light[level=14]
setblock 176 167 631 minecraft:light[level=14]
setblock 176 167 639 minecraft:light[level=14]
fill 183 167 605 183 174 608 minecraft:polished_blackstone
fill 183 167 615 183 174 618 minecraft:polished_blackstone
fill 183 167 625 183 174 628 minecraft:polished_blackstone
fill 183 167 635 183 174 638 minecraft:polished_blackstone
fill 183 167 645 183 174 645 minecraft:polished_blackstone
setblock 142 168 607 minecraft:iron_block
setblock 142 168 617 minecraft:iron_block
setblock 142 168 627 minecraft:iron_block
setblock 142 168 637 minecraft:iron_block
setblock 144 168 645 minecraft:iron_block
setblock 148 168 605 minecraft:iron_block
setblock 154 168 645 minecraft:iron_block
setblock 158 168 605 minecraft:iron_block
setblock 164 168 645 minecraft:iron_block
setblock 168 168 605 minecraft:iron_block
setblock 174 168 645 minecraft:iron_block
setblock 178 168 605 minecraft:iron_block
setblock 182 168 611 minecraft:iron_block
setblock 182 168 621 minecraft:iron_block
setblock 182 168 631 minecraft:iron_block
setblock 182 168 641 minecraft:iron_block
fill 142 171 609 142 171 612 minecraft:iron_block
fill 142 171 619 142 171 622 minecraft:iron_block
fill 142 171 629 142 171 632 minecraft:iron_block
fill 142 171 639 142 171 642 minecraft:iron_block
fill 143 171 605 146 171 605 minecraft:iron_block
fill 146 171 645 149 171 645 minecraft:iron_block
fill 153 171 605 156 171 605 minecraft:iron_block
fill 156 171 645 159 171 645 minecraft:iron_block
fill 163 171 605 166 171 605 minecraft:iron_block
fill 166 171 645 169 171 645 minecraft:iron_block
fill 173 171 605 176 171 605 minecraft:iron_block
fill 176 171 645 179 171 645 minecraft:iron_block
fill 182 171 606 182 171 609 minecraft:iron_block
fill 182 171 616 182 171 619 minecraft:iron_block
fill 182 171 626 182 171 629 minecraft:iron_block
fill 182 171 636 182 171 639 minecraft:iron_block
setblock 146 172 606 minecraft:iron_block
setblock 146 172 608 minecraft:iron_block
setblock 148 172 606 minecraft:iron_block
setblock 148 172 608 minecraft:iron_block
fill 169 172 640 169 172 642 minecraft:iron_block
fill 170 172 639 172 172 639 minecraft:iron_block
fill 170 172 643 172 172 643 minecraft:iron_block
fill 173 172 640 173 172 642 minecraft:iron_block
setblock 142 174 607 minecraft:iron_block
setblock 142 174 617 minecraft:iron_block
setblock 142 174 627 minecraft:iron_block
setblock 142 174 637 minecraft:iron_block
setblock 144 174 645 minecraft:iron_block
setblock 148 174 605 minecraft:iron_block
setblock 154 174 645 minecraft:iron_block
setblock 158 174 605 minecraft:iron_block
setblock 164 174 645 minecraft:iron_block
setblock 168 174 605 minecraft:iron_block
setblock 174 174 645 minecraft:iron_block
setblock 178 174 605 minecraft:iron_block
setblock 182 174 611 minecraft:iron_block
setblock 182 174 621 minecraft:iron_block
setblock 182 174 631 minecraft:iron_block
setblock 182 174 641 minecraft:iron_block
fill 141 175 610 141 175 613 minecraft:sea_lantern
fill 141 175 620 141 175 623 minecraft:sea_lantern
fill 141 175 630 141 175 633 minecraft:sea_lantern
fill 141 175 640 141 175 643 minecraft:sea_lantern
fill 144 175 604 147 175 604 minecraft:sea_lantern
setblock 144 175 607 minecraft:light[level=14]
setblock 144 175 615 minecraft:light[level=14]
setblock 144 175 623 minecraft:light[level=14]
setblock 144 175 631 minecraft:light[level=14]
setblock 144 175 639 minecraft:light[level=14]
fill 145 175 646 148 175 646 minecraft:sea_lantern
setblock 152 175 607 minecraft:light[level=14]
setblock 152 175 615 minecraft:light[level=14]
setblock 152 175 623 minecraft:light[level=14]
setblock 152 175 631 minecraft:light[level=14]
setblock 152 175 639 minecraft:light[level=14]
fill 154 175 604 157 175 604 minecraft:sea_lantern
fill 155 175 646 158 175 646 minecraft:sea_lantern
setblock 160 175 607 minecraft:light[level=14]
setblock 160 175 615 minecraft:light[level=14]
setblock 160 175 623 minecraft:light[level=14]
setblock 160 175 631 minecraft:light[level=14]
setblock 160 175 639 minecraft:light[level=14]
fill 164 175 604 167 175 604 minecraft:sea_lantern
fill 165 175 646 168 175 646 minecraft:sea_lantern
setblock 168 175 607 minecraft:light[level=14]
setblock 168 175 615 minecraft:light[level=14]
setblock 168 175 623 minecraft:light[level=14]
setblock 168 175 631 minecraft:light[level=14]
setblock 168 175 639 minecraft:light[level=14]
fill 174 175 604 177 175 604 minecraft:sea_lantern
fill 175 175 646 178 175 646 minecraft:sea_lantern
setblock 176 175 607 minecraft:light[level=14]
setblock 176 175 615 minecraft:light[level=14]
setblock 176 175 623 minecraft:light[level=14]
setblock 176 175 631 minecraft:light[level=14]
setblock 176 175 639 minecraft:light[level=14]
fill 183 175 605 183 175 608 minecraft:sea_lantern
fill 183 175 615 183 175 618 minecraft:sea_lantern
fill 183 175 625 183 175 628 minecraft:sea_lantern
fill 183 175 635 183 175 638 minecraft:sea_lantern
setblock 183 175 645 minecraft:sea_lantern
fill 141 176 610 141 183 613 minecraft:polished_blackstone
fill 141 176 620 141 183 623 minecraft:polished_blackstone
fill 141 176 630 141 183 633 minecraft:polished_blackstone
fill 141 176 640 141 183 643 minecraft:polished_blackstone
fill 144 176 604 147 183 604 minecraft:polished_blackstone
fill 145 176 646 148 183 646 minecraft:polished_blackstone
fill 154 176 604 157 183 604 minecraft:polished_blackstone
fill 155 176 646 158 183 646 minecraft:polished_blackstone
fill 164 176 604 167 183 604 minecraft:polished_blackstone
fill 165 176 646 168 183 646 minecraft:polished_blackstone
fill 170 176 643 172 177 644 minecraft:iron_block
fill 171 176 645 171 177 645 minecraft:iron_block
fill 174 176 604 177 183 604 minecraft:polished_blackstone
fill 175 176 646 178 183 646 minecraft:polished_blackstone
fill 183 176 605 183 183 608 minecraft:polished_blackstone
fill 183 176 615 183 183 618 minecraft:polished_blackstone
fill 183 176 625 183 183 628 minecraft:polished_blackstone
fill 183 176 635 183 183 638 minecraft:polished_blackstone
fill 183 176 645 183 183 645 minecraft:polished_blackstone
setblock 171 177 639 minecraft:sea_lantern
setblock 146 178 606 minecraft:iron_block
setblock 146 178 608 minecraft:iron_block
setblock 148 178 606 minecraft:iron_block
setblock 148 178 608 minecraft:iron_block
fill 160 178 607 164 179 611 minecraft:netherite_block
fill 162 178 605 162 178 606 minecraft:netherite_block
fill 169 178 640 169 178 642 minecraft:iron_block
fill 170 178 639 172 178 639 minecraft:iron_block
fill 170 178 643 172 178 643 minecraft:iron_block
fill 173 178 640 173 178 642 minecraft:iron_block
setblock 142 180 607 minecraft:iron_block
fill 142 180 609 142 180 612 minecraft:iron_block
setblock 142 180 617 minecraft:iron_block
fill 142 180 619 142 180 622 minecraft:iron_block
setblock 142 180 627 minecraft:iron_block
fill 142 180 629 142 180 632 minecraft:iron_block
setblock 142 180 637 minecraft:iron_block
fill 142 180 639 142 180 642 minecraft:iron_block
fill 143 180 605 146 180 605 minecraft:iron_block
setblock 144 180 645 minecraft:iron_block
fill 146 180 645 149 180 645 minecraft:iron_block
setblock 148 180 605 minecraft:iron_block
fill 153 180 605 156 180 605 minecraft:iron_block
setblock 154 180 645 minecraft:iron_block
fill 156 180 645 159 180 645 minecraft:iron_block
setblock 158 180 605 minecraft:iron_block
fill 163 180 605 166 180 605 minecraft:iron_block
setblock 164 180 645 minecraft:iron_block
fill 166 180 645 169 180 645 minecraft:iron_block
setblock 168 180 605 minecraft:iron_block
fill 173 180 605 176 180 605 minecraft:iron_block
setblock 174 180 645 minecraft:iron_block
fill 176 180 645 179 180 645 minecraft:iron_block
setblock 178 180 605 minecraft:iron_block
fill 182 180 606 182 180 609 minecraft:iron_block
setblock 182 180 611 minecraft:iron_block
fill 182 180 616 182 180 619 minecraft:iron_block
setblock 182 180 621 minecraft:iron_block
fill 182 180 626 182 180 629 minecraft:iron_block
setblock 182 180 631 minecraft:iron_block
fill 182 180 636 182 180 639 minecraft:iron_block
setblock 182 180 641 minecraft:iron_block
setblock 144 183 607 minecraft:light[level=14]
setblock 144 183 615 minecraft:light[level=14]
setblock 144 183 623 minecraft:light[level=14]
setblock 144 183 631 minecraft:light[level=14]
setblock 144 183 639 minecraft:light[level=14]
fill 147 183 605 147 184 605 minecraft:iron_block
setblock 152 183 607 minecraft:light[level=14]
setblock 152 183 615 minecraft:light[level=14]
setblock 152 183 623 minecraft:light[level=14]
setblock 152 183 631 minecraft:light[level=14]
setblock 152 183 639 minecraft:light[level=14]
fill 159 183 607 159 184 611 minecraft:iron_block
fill 160 183 606 160 184 607 minecraft:iron_block
fill 160 183 609 165 184 609 minecraft:iron_block
fill 160 183 611 160 184 612 minecraft:iron_block
setblock 160 183 615 minecraft:light[level=14]
setblock 160 183 623 minecraft:light[level=14]
setblock 160 183 631 minecraft:light[level=14]
setblock 160 183 639 minecraft:light[level=14]
fill 161 183 606 164 184 606 minecraft:iron_block
fill 161 183 612 164 184 612 minecraft:iron_block
fill 162 183 607 162 184 608 minecraft:iron_block
fill 162 183 610 162 184 611 minecraft:iron_block
fill 164 183 607 165 184 607 minecraft:iron_block
fill 164 183 611 165 184 611 minecraft:iron_block
fill 165 183 608 165 184 608 minecraft:iron_block
fill 165 183 610 165 184 610 minecraft:iron_block
setblock 168 183 607 minecraft:light[level=14]
setblock 168 183 615 minecraft:light[level=14]
setblock 168 183 623 minecraft:light[level=14]
setblock 168 183 631 minecraft:light[level=14]
setblock 168 183 639 minecraft:light[level=14]
setblock 176 183 607 minecraft:light[level=14]
setblock 176 183 615 minecraft:light[level=14]
setblock 176 183 623 minecraft:light[level=14]
setblock 176 183 631 minecraft:light[level=14]
setblock 176 183 639 minecraft:light[level=14]
fill 141 184 610 141 184 613 minecraft:sea_lantern
fill 141 184 620 141 184 623 minecraft:sea_lantern
fill 141 184 630 141 184 633 minecraft:sea_lantern
fill 141 184 640 141 184 643 minecraft:sea_lantern
fill 144 184 604 147 184 604 minecraft:sea_lantern
fill 145 184 646 148 184 646 minecraft:sea_lantern
setblock 146 184 606 minecraft:iron_block
setblock 146 184 608 minecraft:iron_block
setblock 147 184 609 minecraft:sea_lantern
setblock 148 184 606 minecraft:iron_block
setblock 148 184 608 minecraft:iron_block
fill 154 184 604 157 184 604 minecraft:sea_lantern
fill 155 184 646 158 184 646 minecraft:sea_lantern
fill 164 184 604 167 184 604 minecraft:sea_lantern
fill 165 184 646 168 184 646 minecraft:sea_lantern
fill 169 184 640 169 184 642 minecraft:iron_block
fill 170 184 639 172 184 639 minecraft:iron_block
fill 170 184 643 172 184 643 minecraft:iron_block
fill 173 184 640 173 184 642 minecraft:iron_block
fill 174 184 604 177 184 604 minecraft:sea_lantern
fill 175 184 646 178 184 646 minecraft:sea_lantern
fill 183 184 605 183 184 608 minecraft:sea_lantern
fill 183 184 615 183 184 618 minecraft:sea_lantern
fill 183 184 625 183 184 628 minecraft:sea_lantern
fill 183 184 635 183 184 638 minecraft:sea_lantern
setblock 183 184 645 minecraft:sea_lantern
setblock 141 185 604 minecraft:netherite_block
fill 141 185 605 141 188 607 minecraft:polished_blackstone
setblock 141 185 609 minecraft:netherite_block
fill 141 185 610 141 188 613 minecraft:polished_blackstone
fill 141 185 620 141 188 623 minecraft:polished_blackstone
fill 141 185 630 141 188 630 minecraft:polished_blackstone
setblock 141 185 631 minecraft:netherite_block
fill 141 185 632 141 188 633 minecraft:polished_blackstone
fill 141 185 640 141 186 641 minecraft:polished_blackstone
fill 141 185 642 141 186 642 minecraft:netherite_block
fill 141 185 643 141 188 643 minecraft:polished_blackstone
fill 144 185 604 147 185 604 minecraft:polished_blackstone
fill 145 185 646 148 185 646 minecraft:polished_blackstone
fill 151 185 646 152 185 646 minecraft:netherite_block
fill 153 185 646 159 185 646 minecraft:polished_blackstone
setblock 154 185 604 minecraft:netherite_block
fill 155 185 604 157 185 604 minecraft:polished_blackstone
setblock 159 185 604 minecraft:netherite_block
setblock 160 185 646 minecraft:netherite_block
fill 162 185 646 163 186 646 minecraft:polished_blackstone
fill 164 185 604 166 188 604 minecraft:polished_blackstone
setblock 164 185 646 minecraft:netherite_block
fill 165 185 646 166 188 646 minecraft:polished_blackstone
setblock 167 185 604 minecraft:netherite_block
fill 167 185 646 167 186 646 minecraft:netherite_block
fill 168 185 604 168 189 604 minecraft:polished_blackstone
fill 168 185 646 168 188 646 minecraft:polished_blackstone
fill 169 185 604 170 185 604 minecraft:netherite_block
fill 171 185 604 177 185 604 minecraft:polished_blackstone
fill 175 185 646 175 188 646 minecraft:polished_blackstone
setblock 176 185 646 minecraft:netherite_block
fill 177 185 646 178 188 646 minecraft:polished_blackstone
setblock 179 185 646 minecraft:netherite_block
fill 180 185 646 183 186 646 minecraft:polished_blackstone
setblock 183 185 605 minecraft:netherite_block
fill 183 185 606 183 186 608 minecraft:polished_blackstone
fill 183 185 615 183 185 621 minecraft:polished_blackstone
setblock 183 185 622 minecraft:netherite_block
fill 183 185 625 183 188 625 minecraft:polished_blackstone
setblock 183 185 626 minecraft:netherite_block
fill 183 185 627 183 185 628 minecraft:polished_blackstone
fill 183 185 635 183 186 638 minecraft:polished_blackstone
setblock 183 185 640 minecraft:netherite_block
fill 183 185 641 183 188 645 minecraft:polished_blackstone
fill 141 186 604 141 188 604 minecraft:polished_blackstone
setblock 141 186 609 minecraft:polished_blackstone
setblock 141 186 615 minecraft:netherite_block
fill 141 186 616 141 188 616 minecraft:polished_blackstone
fill 141 186 627 141 186 628 minecraft:netherite_block
fill 141 186 629 141 188 629 minecraft:polished_blackstone
fill 141 186 631 141 188 631 minecraft:polished_blackstone
setblock 142 186 607 minecraft:iron_block
setblock 142 186 617 minecraft:iron_block
setblock 142 186 627 minecraft:iron_block
setblock 142 186 637 minecraft:iron_block
fill 144 186 604 144 188 604 minecraft:polished_blackstone
setblock 144 186 645 minecraft:iron_block
setblock 145 186 604 minecraft:netherite_block
setblock 145 186 646 minecraft:netherite_block
fill 146 186 604 147 188 604 minecraft:polished_blackstone
setblock 146 186 646 minecraft:polished_blackstone
fill 147 186 646 147 187 646 minecraft:netherite_block
setblock 148 186 605 minecraft:iron_block
fill 148 186 646 148 188 646 minecraft:polished_blackstone
setblock 149 186 646 minecraft:netherite_block
fill 151 186 604 152 188 604 minecraft:polished_blackstone
fill 151 186 646 153 186 646 minecraft:polished_blackstone
setblock 153 186 604 minecraft:netherite_block
fill 154 186 604 156 186 604 minecraft:polished_blackstone
setblock 154 186 645 minecraft:iron_block
setblock 154 186 646 minecraft:netherite_block
fill 155 186 646 160 188 646 minecraft:polished_blackstone
setblock 157 186 604 minecraft:netherite_block
setblock 158 186 605 minecraft:iron_block
fill 159 186 604 159 188 604 minecraft:polished_blackstone
setblock 164 186 645 minecraft:iron_block
setblock 164 186 646 minecraft:polished_blackstone
fill 167 186 604 167 188 604 minecraft:polished_blackstone
setblock 168 186 605 minecraft:iron_block
fill 169 186 604 170 188 604 minecraft:polished_blackstone
fill 171 186 604 172 186 604 minecraft:netherite_block
setblock 172 186 646 minecraft:netherite_block
fill 173 186 604 176 186 604 minecraft:polished_blackstone
setblock 174 186 645 minecraft:iron_block
setblock 176 186 646 minecraft:polished_blackstone
setblock 177 186 604 minecraft:netherite_block
setblock 178 186 605 minecraft:iron_block
fill 179 186 646 179 189 646 minecraft:polished_blackstone
setblock 182 186 611 minecraft:iron_block
setblock 182 186 621 minecraft:iron_block
setblock 182 186 631 minecraft:iron_block
setblock 182 186 641 minecraft:iron_block
fill 183 186 605 183 188 605 minecraft:polished_blackstone
fill 183 186 615 183 188 620 minecraft:polished_blackstone
setblock 183 186 621 minecraft:netherite_block
fill 183 186 622 183 188 622 minecraft:polished_blackstone
fill 183 186 626 183 188 626 minecraft:polished_blackstone
setblock 183 186 627 minecraft:netherite_block
fill 183 186 628 183 188 628 minecraft:polished_blackstone
setblock 183 186 629 minecraft:netherite_block
fill 183 186 630 183 188 630 minecraft:polished_blackstone
fill 183 186 640 183 188 640 minecraft:polished_blackstone
setblock 141 187 609 minecraft:netherite_block
fill 141 187 615 141 188 615 minecraft:polished_blackstone
fill 141 187 627 141 188 628 minecraft:polished_blackstone
fill 141 187 640 141 188 640 minecraft:polished_blackstone
setblock 141 187 641 minecraft:netherite_block
fill 141 187 642 141 188 642 minecraft:polished_blackstone
fill 145 187 604 145 188 604 minecraft:polished_blackstone
fill 145 187 646 145 188 646 minecraft:polished_blackstone
setblock 146 187 646 minecraft:netherite_block
fill 149 187 646 149 188 646 minecraft:polished_blackstone
fill 151 187 646 151 188 646 minecraft:polished_blackstone
setblock 152 187 646 minecraft:netherite_block
fill 153 187 604 154 188 604 minecraft:polished_blackstone
fill 153 187 646 154 188 646 minecraft:polished_blackstone
setblock 155 187 604 minecraft:netherite_block
fill 156 187 604 157 188 604 minecraft:polished_blackstone
fill 162 187 646 162 188 646 minecraft:polished_blackstone
fill 163 187 646 164 187 646 minecraft:netherite_block
fill 167 187 646 167 188 646 minecraft:polished_blackstone
fill 171 187 604 173 188 604 minecraft:polished_blackstone
fill 172 187 646 172 188 646 minecraft:polished_blackstone
setblock 173 187 646 minecraft:netherite_block
setblock 174 187 604 minecraft:netherite_block
fill 174 187 646 174 188 646 minecraft:polished_blackstone
fill 175 187 604 177 188 604 minecraft:polished_blackstone
setblock 176 187 646 minecraft:netherite_block
fill 180 187 646 182 188 646 minecraft:polished_blackstone
fill 182 187 604 182 189 604 minecraft:polished_blackstone
setblock 183 187 604 minecraft:netherite_block
fill 183 187 606 183 188 606 minecraft:polished_blackstone
setblock 183 187 607 minecraft:netherite_block
fill 183 187 608 183 188 608 minecraft:polished_blackstone
fill 183 187 621 183 188 621 minecraft:polished_blackstone
fill 183 187 627 183 188 627 minecraft:polished_blackstone
fill 183 187 629 183 189 629 minecraft:polished_blackstone
setblock 183 187 632 minecraft:netherite_block
setblock 183 187 635 minecraft:netherite_block
fill 183 187 636 183 188 638 minecraft:polished_blackstone
setblock 183 187 646 minecraft:netherite_block
fill 141 188 609 141 189 609 minecraft:polished_blackstone
setblock 141 188 641 minecraft:polished_blackstone
fill 146 188 646 147 188 646 minecraft:polished_blackstone
fill 152 188 646 152 189 646 minecraft:polished_blackstone
setblock 155 188 604 minecraft:polished_blackstone
fill 163 188 646 164 188 646 minecraft:polished_blackstone
setblock 173 188 646 minecraft:polished_blackstone
setblock 174 188 604 minecraft:polished_blackstone
setblock 176 188 646 minecraft:polished_blackstone
setblock 183 188 604 minecraft:polished_blackstone
fill 183 188 607 183 190 607 minecraft:polished_blackstone
setblock 183 188 632 minecraft:polished_blackstone
setblock 183 188 635 minecraft:polished_blackstone
fill 183 188 646 183 189 646 minecraft:polished_blackstone
fill 141 189 604 141 190 605 minecraft:netherite_block
setblock 141 189 606 minecraft:polished_blackstone
fill 141 189 607 141 307 607 minecraft:netherite_block
fill 141 189 610 141 189 613 minecraft:netherite_block
fill 141 189 615 141 307 619 minecraft:netherite_block
fill 141 189 620 141 190 620 minecraft:polished_blackstone
fill 141 189 621 141 192 625 minecraft:netherite_block
fill 141 189 627 141 192 634 minecraft:netherite_block
setblock 141 189 635 minecraft:polished_blackstone
fill 141 189 636 141 192 644 minecraft:netherite_block
fill 141 189 646 145 189 646 minecraft:netherite_block
fill 142 189 604 162 189 604 minecraft:netherite_block
fill 142 189 609 142 189 612 minecraft:iron_block
fill 142 189 619 142 189 622 minecraft:iron_block
fill 142 189 629 142 189 632 minecraft:iron_block
fill 142 189 639 142 189 642 minecraft:iron_block
fill 143 189 605 146 189 605 minecraft:iron_block
fill 146 189 645 149 189 645 minecraft:iron_block
setblock 146 189 646 minecraft:polished_blackstone
fill 147 189 646 151 189 646 minecraft:netherite_block
fill 153 189 605 156 189 605 minecraft:iron_block
fill 153 189 646 153 190 646 minecraft:polished_blackstone
fill 154 189 646 159 189 646 minecraft:netherite_block
fill 156 189 645 159 189 645 minecraft:iron_block
setblock 160 189 646 minecraft:polished_blackstone
fill 161 189 646 178 189 646 minecraft:netherite_block
fill 163 189 605 166 189 605 minecraft:iron_block
fill 164 189 604 167 192 604 minecraft:netherite_block
fill 166 189 645 169 189 645 minecraft:iron_block
fill 169 189 604 177 189 604 minecraft:netherite_block
fill 173 189 605 176 189 605 minecraft:iron_block
fill 176 189 645 179 189 645 minecraft:iron_block
setblock 178 189 604 minecraft:polished_blackstone
fill 179 189 604 179 307 604 minecraft:netherite_block
setblock 180 189 604 minecraft:polished_blackstone
fill 180 189 646 182 190 646 minecraft:netherite_block
fill 181 189 604 181 307 604 minecraft:netherite_block
fill 182 189 606 182 189 609 minecraft:iron_block
fill 182 189 616 182 189 619 minecraft:iron_block
fill 182 189 626 182 189 629 minecraft:iron_block
fill 182 189 636 182 189 639 minecraft:iron_block
fill 183 189 604 183 189 606 minecraft:netherite_block
fill 183 189 608 183 192 615 minecraft:netherite_block
setblock 183 189 616 minecraft:polished_blackstone
fill 183 189 617 183 189 628 minecraft:netherite_block
fill 183 189 630 183 307 633 minecraft:netherite_block
setblock 183 189 634 minecraft:polished_blackstone
fill 183 189 635 183 189 640 minecraft:netherite_block
setblock 183 189 641 minecraft:polished_blackstone
fill 183 189 642 183 307 642 minecraft:netherite_block
setblock 183 189 643 minecraft:polished_blackstone
fill 183 189 644 183 190 645 minecraft:netherite_block
fill 141 190 606 141 307 606 minecraft:netherite_block
fill 141 190 608 141 190 611 minecraft:netherite_block
setblock 141 190 612 minecraft:polished_blackstone
fill 141 190 613 141 190 614 minecraft:netherite_block
fill 141 190 626 141 307 626 minecraft:netherite_block
fill 141 190 635 141 307 635 minecraft:netherite_block
fill 141 190 645 141 307 645 minecraft:netherite_block
setblock 141 190 646 minecraft:polished_blackstone
fill 142 190 604 151 190 604 minecraft:netherite_block
fill 142 190 646 146 190 646 minecraft:netherite_block
setblock 146 190 606 minecraft:iron_block
setblock 146 190 608 minecraft:iron_block
setblock 147 190 646 minecraft:polished_blackstone
setblock 148 190 606 minecraft:iron_block
setblock 148 190 608 minecraft:iron_block
fill 148 190 646 148 192 646 minecraft:netherite_block
fill 149 190 646 149 191 646 minecraft:polished_blackstone
fill 150 190 646 152 307 646 minecraft:netherite_block
setblock 152 190 604 minecraft:polished_blackstone
fill 153 190 604 161 190 604 minecraft:netherite_block
fill 154 190 646 154 307 646 minecraft:netherite_block
setblock 155 190 646 minecraft:polished_blackstone
fill 156 190 646 169 190 646 minecraft:netherite_block
setblock 162 190 604 minecraft:polished_blackstone
fill 163 190 604 163 307 604 minecraft:netherite_block
fill 168 190 604 173 307 604 minecraft:netherite_block
fill 169 190 640 169 190 642 minecraft:iron_block
fill 170 190 639 172 190 639 minecraft:iron_block
fill 170 190 643 172 190 643 minecraft:iron_block
setblock 170 190 646 minecraft:polished_blackstone
fill 171 190 646 179 190 646 minecraft:netherite_block
fill 173 190 640 173 190 642 minecraft:iron_block
setblock 174 190 604 minecraft:polished_blackstone
fill 175 190 604 178 192 604 minecraft:netherite_block
fill 180 190 604 180 307 604 minecraft:netherite_block
fill 182 190 604 183 190 604 minecraft:netherite_block
fill 183 190 605 183 192 605 minecraft:netherite_block
setblock 183 190 606 minecraft:polished_blackstone
fill 183 190 616 183 190 626 minecraft:netherite_block
setblock 183 190 627 minecraft:polished_blackstone
fill 183 190 628 183 192 629 minecraft:netherite_block
fill 183 190 634 183 307 634 minecraft:netherite_block
fill 183 190 635 183 191 635 minecraft:polished_blackstone
fill 183 190 636 183 192 641 minecraft:netherite_block
fill 183 190 643 183 307 643 minecraft:netherite_block
fill 183 190 646 183 307 646 minecraft:netherite_block
fill 141 191 604 142 307 604 minecraft:netherite_block
setblock 141 191 605 minecraft:polished_blackstone
fill 141 191 608 141 307 609 minecraft:netherite_block
setblock 141 191 610 minecraft:polished_blackstone
fill 141 191 611 141 192 612 minecraft:netherite_block
setblock 141 191 613 minecraft:polished_blackstone
fill 141 191 614 141 307 614 minecraft:netherite_block
fill 141 191 620 141 192 620 minecraft:netherite_block
fill 141 191 646 144 307 646 minecraft:netherite_block
fill 143 191 604 144 191 604 minecraft:polished_blackstone
setblock 144 191 607 minecraft:light[level=14]
setblock 144 191 615 minecraft:light[level=14]
setblock 144 191 623 minecraft:light[level=14]
setblock 144 191 631 minecraft:light[level=14]
setblock 144 191 639 minecraft:light[level=14]
fill 145 191 604 145 192 604 minecraft:netherite_block
fill 145 191 646 146 191 646 minecraft:polished_blackstone
setblock 146 191 604 minecraft:polished_blackstone
fill 147 191 604 149 192 604 minecraft:netherite_block
fill 147 191 646 147 192 646 minecraft:netherite_block
fill 150 191 604 151 191 604 minecraft:polished_blackstone
fill 152 191 604 157 192 604 minecraft:netherite_block
setblock 152 191 607 minecraft:light[level=14]
setblock 152 191 615 minecraft:light[level=14]
setblock 152 191 623 minecraft:light[level=14]
setblock 152 191 631 minecraft:light[level=14]
setblock 152 191 639 minecraft:light[level=14]
fill 153 191 646 153 307 646 minecraft:netherite_block
fill 155 191 646 155 192 646 minecraft:netherite_block
setblock 156 191 646 minecraft:polished_blackstone
fill 157 191 646 157 192 646 minecraft:netherite_block
setblock 158 191 604 minecraft:polished_blackstone
setblock 158 191 646 minecraft:polished_blackstone
fill 159 191 604 159 307 604 minecraft:netherite_block
fill 159 191 646 162 307 646 minecraft:netherite_block
setblock 160 191 604 minecraft:polished_blackstone
setblock 160 191 607 minecraft:light[level=14]
setblock 160 191 615 minecraft:light[level=14]
setblock 160 191 623 minecraft:light[level=14]
setblock 160 191 631 minecraft:light[level=14]
setblock 160 191 639 minecraft:light[level=14]
fill 161 191 604 162 307 604 minecraft:netherite_block
fill 163 191 638 167 192 642 minecraft:netherite_block
setblock 163 191 646 minecraft:polished_blackstone
fill 164 191 646 174 192 646 minecraft:netherite_block
fill 165 191 643 165 191 644 minecraft:netherite_block
setblock 168 191 607 minecraft:light[level=14]
setblock 168 191 615 minecraft:light[level=14]
setblock 168 191 623 minecraft:light[level=14]
setblock 168 191 631 minecraft:light[level=14]
setblock 168 191 639 minecraft:light[level=14]
fill 174 191 604 174 192 604 minecraft:netherite_block
setblock 175 191 646 minecraft:polished_blackstone
setblock 176 191 607 minecraft:light[level=14]
setblock 176 191 615 minecraft:light[level=14]
setblock 176 191 623 minecraft:light[level=14]
setblock 176 191 631 minecraft:light[level=14]
setblock 176 191 639 minecraft:light[level=14]
fill 176 191 646 181 192 646 minecraft:netherite_block
fill 182 191 604 182 307 604 minecraft:netherite_block
setblock 182 191 646 minecraft:polished_blackstone
setblock 183 191 604 minecraft:polished_blackstone
fill 183 191 606 183 192 607 minecraft:netherite_block
fill 183 191 616 183 192 623 minecraft:netherite_block
setblock 183 191 624 minecraft:polished_blackstone
fill 183 191 625 183 192 627 minecraft:netherite_block
setblock 183 191 644 minecraft:polished_blackstone
fill 183 191 645 183 192 645 minecraft:netherite_block
fill 141 192 605 141 307 605 minecraft:netherite_block
setblock 141 192 610 minecraft:netherite_block
setblock 141 192 613 minecraft:netherite_block
setblock 142 192 607 minecraft:iron_block
setblock 142 192 617 minecraft:iron_block
setblock 142 192 627 minecraft:iron_block
setblock 142 192 637 minecraft:iron_block
fill 143 192 604 144 192 604 minecraft:netherite_block
setblock 144 192 645 minecraft:iron_block
fill 145 192 646 146 192 646 minecraft:netherite_block
setblock 146 192 604 minecraft:netherite_block
setblock 148 192 605 minecraft:iron_block
fill 149 192 646 149 307 646 minecraft:netherite_block
fill 150 192 604 151 307 604 minecraft:netherite_block
setblock 154 192 645 minecraft:iron_block
setblock 156 192 646 minecraft:netherite_block
fill 158 192 604 158 307 604 minecraft:netherite_block
setblock 158 192 605 minecraft:iron_block
setblock 158 192 646 minecraft:netherite_block
fill 160 192 604 160 307 604 minecraft:netherite_block
fill 163 192 646 163 307 646 minecraft:netherite_block
setblock 164 192 645 minecraft:iron_block
setblock 168 192 605 minecraft:iron_block
setblock 174 192 645 minecraft:iron_block
setblock 175 192 646 minecraft:netherite_block
setblock 178 192 605 minecraft:iron_block
setblock 182 192 611 minecraft:iron_block
setblock 182 192 621 minecraft:iron_block
setblock 182 192 631 minecraft:iron_block
setblock 182 192 641 minecraft:iron_block
fill 182 192 646 182 307 646 minecraft:netherite_block
fill 183 192 604 183 307 604 minecraft:netherite_block
fill 183 192 624 183 307 624 minecraft:netherite_block
setblock 183 192 635 minecraft:netherite_block
fill 183 192 644 183 307 644 minecraft:netherite_block
fill 141 193 610 141 193 613 minecraft:sea_lantern
fill 141 193 620 141 193 623 minecraft:sea_lantern
fill 141 193 624 141 307 625 minecraft:netherite_block
fill 141 193 627 141 307 629 minecraft:netherite_block
fill 141 193 630 141 193 633 minecraft:sea_lantern
fill 141 193 634 141 307 634 minecraft:netherite_block
fill 141 193 636 141 307 639 minecraft:netherite_block
fill 141 193 640 141 193 643 minecraft:sea_lantern
fill 141 193 644 141 307 644 minecraft:netherite_block
fill 143 193 604 143 307 604 minecraft:netherite_block
fill 144 193 604 147 193 604 minecraft:sea_lantern
fill 145 193 646 148 193 646 minecraft:sea_lantern
fill 148 193 604 149 307 604 minecraft:netherite_block
fill 152 193 604 153 307 604 minecraft:netherite_block
fill 154 193 604 157 193 604 minecraft:sea_lantern
fill 155 193 646 158 193 646 minecraft:sea_lantern
fill 164 193 604 167 193 604 minecraft:sea_lantern
fill 164 193 646 164 307 646 minecraft:netherite_block
fill 165 193 646 168 193 646 minecraft:sea_lantern
fill 169 193 646 174 307 646 minecraft:netherite_block
fill 174 193 604 177 193 604 minecraft:sea_lantern
fill 175 193 646 178 193 646 minecraft:sea_lantern
fill 178 193 604 178 307 604 minecraft:netherite_block
fill 179 193 646 181 307 646 minecraft:netherite_block
fill 183 193 605 183 193 608 minecraft:sea_lantern
fill 183 193 609 183 307 614 minecraft:netherite_block
fill 183 193 615 183 193 618 minecraft:sea_lantern
fill 183 193 619 183 307 623 minecraft:netherite_block
fill 183 193 625 183 193 628 minecraft:sea_lantern
fill 183 193 629 183 307 629 minecraft:netherite_block
fill 183 193 635 183 193 638 minecraft:sea_lantern
fill 183 193 639 183 307 641 minecraft:netherite_block
setblock 183 193 645 minecraft:sea_lantern
fill 141 194 610 141 201 613 minecraft:netherite_block
fill 141 194 620 141 201 623 minecraft:netherite_block
fill 141 194 630 141 201 633 minecraft:netherite_block
fill 141 194 640 141 201 643 minecraft:netherite_block
fill 144 194 604 147 201 604 minecraft:netherite_block
fill 145 194 646 148 201 646 minecraft:netherite_block
fill 154 194 604 157 201 604 minecraft:netherite_block
fill 155 194 646 158 201 646 minecraft:netherite_block
fill 164 194 604 167 201 604 minecraft:netherite_block
fill 165 194 646 168 201 646 minecraft:netherite_block
fill 174 194 604 177 201 604 minecraft:netherite_block
fill 175 194 646 178 201 646 minecraft:netherite_block
fill 183 194 605 183 201 608 minecraft:netherite_block
fill 183 194 615 183 201 618 minecraft:netherite_block
fill 183 194 625 183 201 628 minecraft:netherite_block
fill 183 194 635 183 201 638 minecraft:netherite_block
fill 183 194 645 183 201 645 minecraft:netherite_block
setblock 146 196 606 minecraft:iron_block
setblock 146 196 608 minecraft:iron_block
setblock 148 196 606 minecraft:iron_block
setblock 148 196 608 minecraft:iron_block
fill 162 196 638 162 197 642 minecraft:iron_block
fill 163 196 637 163 197 638 minecraft:iron_block
fill 163 196 640 169 196 640 minecraft:iron_block
fill 163 196 642 163 197 643 minecraft:iron_block
fill 164 196 637 167 197 637 minecraft:iron_block
fill 164 196 643 167 197 643 minecraft:iron_block
fill 165 196 638 165 197 639 minecraft:iron_block
fill 165 196 641 165 197 642 minecraft:iron_block
fill 167 196 638 168 197 638 minecraft:iron_block
fill 167 196 642 169 196 642 minecraft:iron_block
fill 168 196 639 168 197 639 minecraft:iron_block
fill 168 196 641 169 196 641 minecraft:iron_block
fill 170 196 639 172 196 639 minecraft:iron_block
fill 170 196 643 172 196 643 minecraft:iron_block
fill 173 196 640 173 196 642 minecraft:iron_block
fill 163 197 640 168 197 640 minecraft:iron_block
fill 167 197 642 168 197 642 minecraft:iron_block
setblock 168 197 641 minecraft:iron_block
setblock 142 198 607 minecraft:iron_block
fill 142 198 609 142 198 612 minecraft:iron_block
setblock 142 198 617 minecraft:iron_block
fill 142 198 619 142 198 622 minecraft:iron_block
setblock 142 198 627 minecraft:iron_block
fill 142 198 629 142 198 632 minecraft:iron_block
setblock 142 198 637 minecraft:iron_block
fill 142 198 639 142 198 642 minecraft:iron_block
fill 143 198 605 146 198 605 minecraft:iron_block
setblock 144 198 645 minecraft:iron_block
fill 146 198 645 149 198 645 minecraft:iron_block
setblock 148 198 605 minecraft:iron_block
fill 153 198 605 156 198 605 minecraft:iron_block
setblock 154 198 645 minecraft:iron_block
fill 156 198 645 159 198 645 minecraft:iron_block
setblock 158 198 605 minecraft:iron_block
fill 163 198 605 166 198 605 minecraft:iron_block
setblock 164 198 645 minecraft:iron_block
fill 166 198 645 169 198 645 minecraft:iron_block
setblock 168 198 605 minecraft:iron_block
fill 173 198 605 176 198 605 minecraft:iron_block
setblock 174 198 645 minecraft:iron_block
fill 176 198 645 179 198 645 minecraft:iron_block
setblock 178 198 605 minecraft:iron_block
fill 182 198 606 182 198 609 minecraft:iron_block
setblock 182 198 611 minecraft:iron_block
fill 182 198 616 182 198 619 minecraft:iron_block
setblock 182 198 621 minecraft:iron_block
fill 182 198 626 182 198 629 minecraft:iron_block
setblock 182 198 631 minecraft:iron_block
fill 182 198 636 182 198 639 minecraft:iron_block
setblock 182 198 641 minecraft:iron_block
setblock 144 199 607 minecraft:light[level=14]
setblock 144 199 615 minecraft:light[level=14]
setblock 144 199 623 minecraft:light[level=14]
setblock 144 199 631 minecraft:light[level=14]
setblock 144 199 639 minecraft:light[level=14]
setblock 152 199 607 minecraft:light[level=14]
setblock 152 199 615 minecraft:light[level=14]
setblock 152 199 623 minecraft:light[level=14]
setblock 152 199 631 minecraft:light[level=14]
setblock 152 199 639 minecraft:light[level=14]
setblock 160 199 607 minecraft:light[level=14]
setblock 160 199 615 minecraft:light[level=14]
setblock 160 199 623 minecraft:light[level=14]
setblock 160 199 631 minecraft:light[level=14]
setblock 160 199 639 minecraft:light[level=14]
setblock 168 199 607 minecraft:light[level=14]
setblock 168 199 615 minecraft:light[level=14]
setblock 168 199 623 minecraft:light[level=14]
setblock 168 199 631 minecraft:light[level=14]
setblock 168 199 639 minecraft:light[level=14]
setblock 176 199 607 minecraft:light[level=14]
setblock 176 199 615 minecraft:light[level=14]
setblock 176 199 623 minecraft:light[level=14]
setblock 176 199 631 minecraft:light[level=14]
setblock 176 199 639 minecraft:light[level=14]
fill 173 201 641 182 201 641 minecraft:iron_block
fill 180 201 617 181 202 617 minecraft:iron_block
fill 181 201 635 181 202 635 minecraft:iron_block
fill 141 202 610 141 202 613 minecraft:sea_lantern
fill 141 202 620 141 202 623 minecraft:sea_lantern
fill 141 202 630 141 202 633 minecraft:sea_lantern
fill 141 202 640 141 202 643 minecraft:sea_lantern
fill 142 202 611 155 203 611 minecraft:iron_block
fill 142 202 617 179 202 617 minecraft:iron_block
fill 142 202 620 144 203 620 minecraft:iron_block
fill 142 202 623 144 203 623 minecraft:iron_block
fill 142 202 629 181 203 629 minecraft:iron_block
fill 142 202 635 180 202 635 minecraft:iron_block
fill 142 202 641 169 202 641 minecraft:iron_block
fill 144 202 604 147 202 604 minecraft:sea_lantern
fill 145 202 646 148 202 646 minecraft:sea_lantern
setblock 146 202 606 minecraft:iron_block
setblock 146 202 608 minecraft:iron_block
setblock 148 202 606 minecraft:iron_block
setblock 148 202 608 minecraft:iron_block
fill 154 202 604 157 202 604 minecraft:sea_lantern
fill 155 202 646 158 202 646 minecraft:sea_lantern
fill 164 202 604 167 202 604 minecraft:sea_lantern
fill 165 202 646 168 202 646 minecraft:sea_lantern
setblock 169 202 640 minecraft:iron_block
setblock 169 202 642 minecraft:iron_block
fill 170 202 639 172 202 639 minecraft:iron_block
fill 170 202 643 172 202 643 minecraft:iron_block
fill 173 202 640 173 202 642 minecraft:iron_block
fill 174 202 604 177 202 604 minecraft:sea_lantern
fill 174 202 641 178 202 641 minecraft:iron_block
fill 175 202 646 178 202 646 minecraft:sea_lantern
fill 183 202 605 183 202 608 minecraft:sea_lantern
fill 183 202 615 183 202 618 minecraft:sea_lantern
fill 183 202 625 183 202 628 minecraft:sea_lantern
fill 183 202 635 183 202 638 minecraft:sea_lantern
setblock 183 202 645 minecraft:sea_lantern
fill 141 203 610 141 210 613 minecraft:netherite_block
fill 141 203 620 141 210 623 minecraft:netherite_block
fill 141 203 630 141 210 633 minecraft:netherite_block
fill 141 203 640 141 210 643 minecraft:netherite_block
fill 142 203 617 145 203 617 minecraft:iron_block
fill 142 203 635 145 203 635 minecraft:iron_block
fill 142 203 641 144 203 641 minecraft:iron_block
fill 144 203 604 147 210 604 minecraft:netherite_block
fill 145 203 623 158 203 623 minecraft:iron_block
fill 145 203 646 148 210 646 minecraft:netherite_block
fill 154 203 604 157 210 604 minecraft:netherite_block
fill 155 203 646 158 210 646 minecraft:netherite_block
fill 156 203 611 182 203 611 minecraft:iron_block
fill 164 203 604 167 210 604 minecraft:netherite_block
fill 164 203 623 170 203 623 minecraft:iron_block
fill 165 203 646 168 210 646 minecraft:netherite_block
fill 172 203 636 172 204 639 minecraft:iron_block
fill 172 203 643 172 203 645 minecraft:iron_block
fill 174 203 604 177 210 604 minecraft:netherite_block
fill 175 203 646 178 210 646 minecraft:netherite_block
fill 183 203 605 183 210 608 minecraft:netherite_block
fill 183 203 615 183 210 618 minecraft:netherite_block
fill 183 203 625 183 210 628 minecraft:netherite_block
fill 183 203 635 183 210 638 minecraft:netherite_block
fill 183 203 645 183 210 645 minecraft:netherite_block
setblock 142 204 607 minecraft:iron_block
setblock 142 204 617 minecraft:iron_block
setblock 142 204 627 minecraft:iron_block
setblock 142 204 637 minecraft:iron_block
setblock 144 204 645 minecraft:iron_block
fill 148 204 605 148 205 606 minecraft:iron_block
fill 148 204 608 148 204 644 minecraft:iron_block
fill 154 204 605 154 204 645 minecraft:iron_block
setblock 158 204 605 minecraft:iron_block
fill 160 204 605 160 205 621 minecraft:iron_block
fill 160 204 627 160 204 644 minecraft:iron_block
setblock 164 204 645 minecraft:iron_block
fill 166 204 605 166 204 645 minecraft:iron_block
fill 167 204 623 182 204 623 minecraft:iron_block
setblock 168 204 605 minecraft:iron_block
fill 172 204 605 172 204 622 minecraft:iron_block
fill 172 204 624 172 204 635 minecraft:iron_block
setblock 174 204 645 minecraft:iron_block
fill 178 204 605 178 205 609 minecraft:iron_block
setblock 182 204 611 minecraft:iron_block
setblock 182 204 621 minecraft:iron_block
setblock 182 204 631 minecraft:iron_block
setblock 182 204 641 minecraft:iron_block
setblock 148 205 608 minecraft:iron_block
fill 154 205 605 154 205 614 minecraft:iron_block
fill 160 205 627 160 205 636 minecraft:iron_block
fill 166 205 605 166 205 611 minecraft:iron_block
fill 172 205 605 172 205 607 minecraft:iron_block
fill 178 205 610 178 205 645 minecraft:iron_block
fill 142 207 609 142 207 612 minecraft:iron_block
fill 142 207 619 142 207 622 minecraft:iron_block
fill 142 207 629 142 207 632 minecraft:iron_block
fill 142 207 639 142 207 642 minecraft:iron_block
fill 143 207 605 146 207 605 minecraft:iron_block
setblock 144 207 607 minecraft:light[level=14]
setblock 144 207 615 minecraft:light[level=14]
setblock 144 207 623 minecraft:light[level=14]
setblock 144 207 631 minecraft:light[level=14]
setblock 144 207 639 minecraft:light[level=14]
fill 146 207 645 149 207 645 minecraft:iron_block
setblock 152 207 607 minecraft:light[level=14]
setblock 152 207 615 minecraft:light[level=14]
setblock 152 207 623 minecraft:light[level=14]
setblock 152 207 631 minecraft:light[level=14]
setblock 152 207 639 minecraft:light[level=14]
fill 153 207 605 156 207 605 minecraft:iron_block
fill 156 207 645 159 207 645 minecraft:iron_block
setblock 160 207 607 minecraft:light[level=14]
setblock 160 207 615 minecraft:light[level=14]
setblock 160 207 623 minecraft:light[level=14]
setblock 160 207 631 minecraft:light[level=14]
setblock 160 207 639 minecraft:light[level=14]
fill 163 207 605 166 207 605 minecraft:iron_block
fill 166 207 645 169 207 645 minecraft:iron_block
setblock 168 207 607 minecraft:light[level=14]
setblock 168 207 615 minecraft:light[level=14]
setblock 168 207 623 minecraft:light[level=14]
setblock 168 207 631 minecraft:light[level=14]
setblock 168 207 639 minecraft:light[level=14]
fill 173 207 605 176 207 605 minecraft:iron_block
setblock 176 207 607 minecraft:light[level=14]
setblock 176 207 615 minecraft:light[level=14]
setblock 176 207 623 minecraft:light[level=14]
setblock 176 207 631 minecraft:light[level=14]
setblock 176 207 639 minecraft:light[level=14]
fill 176 207 645 179 207 645 minecraft:iron_block
fill 182 207 606 182 207 609 minecraft:iron_block
fill 182 207 616 182 207 619 minecraft:iron_block
fill 182 207 626 182 207 629 minecraft:iron_block
fill 182 207 636 182 207 639 minecraft:iron_block
setblock 146 208 606 minecraft:iron_block
setblock 146 208 608 minecraft:iron_block
setblock 148 208 606 minecraft:iron_block
setblock 148 208 608 minecraft:iron_block
fill 169 208 640 169 208 642 minecraft:iron_block
fill 170 208 639 172 208 639 minecraft:iron_block
fill 170 208 643 172 208 643 minecraft:iron_block
fill 173 208 640 173 208 642 minecraft:iron_block
setblock 142 210 607 minecraft:iron_block
setblock 142 210 617 minecraft:iron_block
setblock 142 210 627 minecraft:iron_block
setblock 142 210 637 minecraft:iron_block
setblock 144 210 645 minecraft:iron_block
setblock 148 210 605 minecraft:iron_block
setblock 154 210 645 minecraft:iron_block
setblock 158 210 605 minecraft:iron_block
setblock 164 210 645 minecraft:iron_block
setblock 168 210 605 minecraft:iron_block
setblock 174 210 645 minecraft:iron_block
setblock 178 210 605 minecraft:iron_block
setblock 182 210 611 minecraft:iron_block
setblock 182 210 621 minecraft:iron_block
setblock 182 210 631 minecraft:iron_block
setblock 182 210 641 minecraft:iron_block
fill 141 211 610 141 211 613 minecraft:sea_lantern
fill 141 211 620 141 211 623 minecraft:sea_lantern
fill 141 211 630 141 211 633 minecraft:sea_lantern
fill 141 211 640 141 211 643 minecraft:sea_lantern
fill 144 211 604 147 211 604 minecraft:sea_lantern
fill 145 211 646 148 211 646 minecraft:sea_lantern
fill 154 211 604 157 211 604 minecraft:sea_lantern
fill 155 211 646 158 211 646 minecraft:sea_lantern
fill 164 211 604 167 211 604 minecraft:sea_lantern
fill 165 211 646 168 211 646 minecraft:sea_lantern
fill 174 211 604 177 211 604 minecraft:sea_lantern
fill 175 211 646 178 211 646 minecraft:sea_lantern
fill 183 211 605 183 211 608 minecraft:sea_lantern
fill 183 211 615 183 211 618 minecraft:sea_lantern
fill 183 211 625 183 211 628 minecraft:sea_lantern
fill 183 211 635 183 211 638 minecraft:sea_lantern
setblock 183 211 645 minecraft:sea_lantern
fill 141 212 610 141 228 613 minecraft:netherite_block
fill 141 212 620 141 228 623 minecraft:netherite_block
fill 141 212 630 141 228 633 minecraft:netherite_block
fill 141 212 640 141 228 643 minecraft:netherite_block
fill 142 212 620 144 213 620 minecraft:iron_block
fill 144 212 604 147 228 604 minecraft:netherite_block
fill 145 212 646 148 228 646 minecraft:netherite_block
fill 154 212 604 157 228 604 minecraft:netherite_block
fill 155 212 646 158 228 646 minecraft:netherite_block
fill 164 212 604 167 228 604 minecraft:netherite_block
fill 165 212 646 168 228 646 minecraft:netherite_block
fill 174 212 604 177 228 604 minecraft:netherite_block
fill 175 212 646 178 228 646 minecraft:netherite_block
fill 183 212 605 183 228 608 minecraft:netherite_block
fill 183 212 615 183 228 618 minecraft:netherite_block
fill 183 212 625 183 228 628 minecraft:netherite_block
fill 183 212 635 183 228 638 minecraft:netherite_block
fill 183 212 645 183 228 645 minecraft:netherite_block
fill 145 213 605 145 214 607 minecraft:iron_block
setblock 144 215 607 minecraft:light[level=14]
setblock 144 215 615 minecraft:light[level=14]
setblock 144 215 623 minecraft:light[level=14]
setblock 144 215 631 minecraft:light[level=14]
setblock 144 215 639 minecraft:light[level=14]
setblock 152 215 607 minecraft:light[level=14]
setblock 152 215 615 minecraft:light[level=14]
setblock 152 215 623 minecraft:light[level=14]
setblock 152 215 631 minecraft:light[level=14]
setblock 152 215 639 minecraft:light[level=14]
setblock 160 215 607 minecraft:light[level=14]
setblock 160 215 615 minecraft:light[level=14]
setblock 160 215 623 minecraft:light[level=14]
setblock 160 215 631 minecraft:light[level=14]
setblock 160 215 639 minecraft:light[level=14]
setblock 168 215 607 minecraft:light[level=14]
setblock 168 215 615 minecraft:light[level=14]
setblock 168 215 623 minecraft:light[level=14]
setblock 168 215 631 minecraft:light[level=14]
setblock 168 215 639 minecraft:light[level=14]
setblock 176 215 607 minecraft:light[level=14]
setblock 176 215 615 minecraft:light[level=14]
setblock 176 215 623 minecraft:light[level=14]
setblock 176 215 631 minecraft:light[level=14]
setblock 176 215 639 minecraft:light[level=14]
fill 155 219 623 157 219 625 minecraft:redstone_block
fill 160 219 628 162 219 630 minecraft:redstone_block
fill 163 219 619 165 219 621 minecraft:redstone_block
fill 165 219 624 167 219 626 minecraft:redstone_block
fill 142 220 605 142 221 615 minecraft:netherite_block
fill 142 220 616 182 220 616 minecraft:gold_block
fill 142 220 617 142 221 627 minecraft:netherite_block
fill 142 220 628 159 220 628 minecraft:gold_block
fill 142 220 629 142 221 639 minecraft:netherite_block
fill 142 220 640 182 221 640 minecraft:gold_block
fill 142 220 641 142 221 645 minecraft:netherite_block
fill 143 220 605 143 221 615 minecraft:iron_block
fill 143 220 617 143 221 627 minecraft:iron_block
fill 143 220 629 143 221 639 minecraft:iron_block
fill 143 220 641 143 221 645 minecraft:iron_block
fill 144 220 605 144 221 615 minecraft:netherite_block
fill 144 220 617 144 221 627 minecraft:netherite_block
fill 144 220 629 144 221 639 minecraft:netherite_block
fill 144 220 641 144 221 645 minecraft:netherite_block
fill 145 220 605 145 221 615 minecraft:iron_block
fill 145 220 617 145 221 627 minecraft:iron_block
fill 145 220 629 145 221 639 minecraft:iron_block
fill 145 220 641 145 221 645 minecraft:iron_block
fill 146 220 605 146 221 615 minecraft:netherite_block
fill 146 220 617 146 221 627 minecraft:netherite_block
fill 146 220 629 146 221 639 minecraft:netherite_block
fill 146 220 641 146 221 645 minecraft:netherite_block
fill 147 220 605 147 221 615 minecraft:iron_block
fill 147 220 617 147 221 627 minecraft:iron_block
fill 147 220 629 147 221 639 minecraft:iron_block
fill 147 220 641 147 221 645 minecraft:iron_block
fill 148 220 605 148 221 615 minecraft:netherite_block
fill 148 220 617 148 220 627 minecraft:netherite_block
fill 148 220 629 148 221 639 minecraft:netherite_block
fill 148 220 641 148 221 645 minecraft:netherite_block
fill 149 220 605 149 221 615 minecraft:iron_block
fill 149 220 617 149 221 627 minecraft:iron_block
fill 149 220 629 149 221 639 minecraft:iron_block
fill 149 220 641 149 221 645 minecraft:iron_block
fill 150 220 605 150 221 615 minecraft:netherite_block
fill 150 220 617 150 220 627 minecraft:netherite_block
fill 150 220 629 150 220 639 minecraft:netherite_block
fill 150 220 641 150 221 645 minecraft:netherite_block
fill 151 220 605 151 221 615 minecraft:iron_block
fill 151 220 617 151 221 627 minecraft:iron_block
fill 151 220 629 151 221 639 minecraft:iron_block
fill 151 220 641 151 221 645 minecraft:iron_block
fill 152 220 605 152 221 615 minecraft:netherite_block
fill 152 220 617 152 220 627 minecraft:netherite_block
fill 152 220 629 152 220 639 minecraft:netherite_block
fill 152 220 641 152 221 645 minecraft:netherite_block
fill 153 220 605 153 221 615 minecraft:iron_block
fill 153 220 617 153 222 627 minecraft:iron_block
fill 153 220 629 153 221 639 minecraft:iron_block
fill 153 220 641 153 221 645 minecraft:iron_block
fill 154 220 605 154 220 615 minecraft:netherite_block
fill 154 220 617 154 220 627 minecraft:netherite_block
fill 154 220 629 154 220 639 minecraft:netherite_block
fill 154 220 641 154 221 645 minecraft:netherite_block
fill 155 220 605 155 221 615 minecraft:iron_block
fill 155 220 617 155 222 622 minecraft:iron_block
fill 155 220 626 155 222 627 minecraft:iron_block
fill 155 220 629 155 221 639 minecraft:iron_block
fill 155 220 641 155 221 645 minecraft:iron_block
fill 156 220 605 156 220 615 minecraft:netherite_block
fill 156 220 617 156 220 622 minecraft:netherite_block
fill 156 220 626 156 220 627 minecraft:netherite_block
fill 156 220 629 156 220 639 minecraft:netherite_block
fill 156 220 641 156 221 645 minecraft:netherite_block
fill 157 220 605 157 221 615 minecraft:iron_block
fill 157 220 617 157 222 622 minecraft:iron_block
fill 157 220 626 157 222 627 minecraft:iron_block
fill 157 220 629 157 221 639 minecraft:iron_block
fill 157 220 641 157 221 645 minecraft:iron_block
fill 158 220 605 158 220 615 minecraft:netherite_block
fill 158 220 617 158 220 627 minecraft:netherite_block
fill 158 220 629 158 220 639 minecraft:netherite_block
fill 158 220 641 158 221 645 minecraft:netherite_block
fill 159 220 605 159 221 615 minecraft:iron_block
fill 159 220 617 159 220 627 minecraft:iron_block
fill 159 220 629 159 221 639 minecraft:iron_block
fill 159 220 641 159 221 645 minecraft:iron_block
fill 160 220 605 160 220 615 minecraft:netherite_block
fill 160 220 617 160 220 622 minecraft:netherite_block
fill 160 220 626 160 220 627 minecraft:netherite_block
fill 160 220 631 160 220 639 minecraft:netherite_block
fill 160 220 641 160 221 645 minecraft:netherite_block
fill 161 220 605 161 221 615 minecraft:iron_block
fill 161 220 617 161 220 622 minecraft:iron_block
fill 161 220 626 161 220 627 minecraft:iron_block
fill 161 220 631 161 221 639 minecraft:iron_block
fill 161 220 641 161 221 645 minecraft:iron_block
fill 162 220 605 162 220 615 minecraft:netherite_block
fill 162 220 617 162 220 622 minecraft:netherite_block
fill 162 220 626 162 220 627 minecraft:netherite_block
fill 162 220 631 162 220 639 minecraft:netherite_block
fill 162 220 641 162 221 645 minecraft:netherite_block
fill 163 220 605 163 221 615 minecraft:iron_block
fill 163 220 617 163 222 618 minecraft:iron_block
fill 163 220 622 163 220 627 minecraft:iron_block
fill 163 220 628 182 220 628 minecraft:gold_block
fill 163 220 629 163 221 639 minecraft:iron_block
fill 163 220 641 163 221 645 minecraft:iron_block
fill 164 220 605 164 220 615 minecraft:netherite_block
fill 164 220 617 164 220 618 minecraft:netherite_block
fill 164 220 622 164 220 627 minecraft:netherite_block
fill 164 220 629 164 220 639 minecraft:netherite_block
fill 164 220 641 164 221 645 minecraft:netherite_block
fill 165 220 605 165 221 615 minecraft:iron_block
fill 165 220 617 165 222 618 minecraft:iron_block
fill 165 220 622 165 222 623 minecraft:iron_block
fill 165 220 627 165 222 627 minecraft:iron_block
fill 165 220 629 165 221 639 minecraft:iron_block
fill 165 220 641 165 221 645 minecraft:iron_block
fill 166 220 605 166 220 615 minecraft:netherite_block
fill 166 220 617 166 220 623 minecraft:netherite_block
setblock 166 220 627 minecraft:netherite_block
fill 166 220 629 166 220 639 minecraft:netherite_block
fill 166 220 641 166 221 645 minecraft:netherite_block
fill 167 220 605 167 221 615 minecraft:iron_block
fill 167 220 617 167 222 623 minecraft:iron_block
fill 167 220 627 167 222 627 minecraft:iron_block
fill 167 220 629 167 221 639 minecraft:iron_block
fill 167 220 641 167 221 645 minecraft:iron_block
fill 168 220 605 168 220 615 minecraft:netherite_block
fill 168 220 617 168 220 627 minecraft:netherite_block
fill 168 220 629 168 220 639 minecraft:netherite_block
fill 168 220 641 168 221 645 minecraft:netherite_block
fill 169 220 605 169 221 615 minecraft:iron_block
fill 169 220 617 169 222 627 minecraft:iron_block
fill 169 220 629 169 221 639 minecraft:iron_block
fill 169 220 641 169 221 645 minecraft:iron_block
fill 170 220 605 170 221 615 minecraft:netherite_block
fill 170 220 617 170 220 627 minecraft:netherite_block
fill 170 220 629 170 220 639 minecraft:netherite_block
fill 170 220 641 170 221 645 minecraft:netherite_block
fill 171 220 605 171 221 615 minecraft:iron_block
fill 171 220 617 171 221 627 minecraft:iron_block
fill 171 220 629 171 221 639 minecraft:iron_block
fill 171 220 641 171 221 645 minecraft:iron_block
fill 172 220 605 172 221 615 minecraft:netherite_block
fill 172 220 617 172 220 627 minecraft:netherite_block
fill 172 220 629 172 220 639 minecraft:netherite_block
fill 172 220 641 172 221 645 minecraft:netherite_block
fill 173 220 605 173 221 615 minecraft:iron_block
fill 173 220 617 173 221 627 minecraft:iron_block
fill 173 220 629 173 221 639 minecraft:iron_block
fill 173 220 641 173 221 645 minecraft:iron_block
fill 174 220 605 174 221 615 minecraft:netherite_block
fill 174 220 617 174 220 627 minecraft:netherite_block
fill 174 220 629 174 221 639 minecraft:netherite_block
fill 174 220 641 174 221 645 minecraft:netherite_block
fill 175 220 605 175 221 615 minecraft:iron_block
fill 175 220 617 175 221 627 minecraft:iron_block
fill 175 220 629 175 221 639 minecraft:iron_block
fill 175 220 641 175 221 645 minecraft:iron_block
fill 176 220 605 176 221 615 minecraft:netherite_block
fill 176 220 617 176 221 627 minecraft:netherite_block
fill 176 220 629 176 221 639 minecraft:netherite_block
fill 176 220 641 176 221 645 minecraft:netherite_block
fill 177 220 605 177 221 615 minecraft:iron_block
fill 177 220 617 177 221 627 minecraft:iron_block
fill 177 220 629 177 221 639 minecraft:iron_block
fill 177 220 641 177 221 645 minecraft:iron_block
fill 178 220 605 178 221 615 minecraft:netherite_block
fill 178 220 617 178 221 627 minecraft:netherite_block
fill 178 220 629 178 221 639 minecraft:netherite_block
fill 178 220 641 178 221 645 minecraft:netherite_block
fill 179 220 605 179 221 615 minecraft:iron_block
fill 179 220 617 179 221 627 minecraft:iron_block
fill 179 220 629 179 221 639 minecraft:iron_block
fill 179 220 641 179 221 645 minecraft:iron_block
fill 180 220 605 180 221 615 minecraft:netherite_block
fill 180 220 617 180 221 627 minecraft:netherite_block
fill 180 220 629 180 221 639 minecraft:netherite_block
fill 180 220 641 180 221 645 minecraft:netherite_block
fill 181 220 605 181 221 615 minecraft:iron_block
fill 181 220 617 181 221 627 minecraft:iron_block
fill 181 220 629 181 221 639 minecraft:iron_block
fill 181 220 641 181 221 645 minecraft:iron_block
fill 182 220 605 182 221 615 minecraft:netherite_block
fill 182 220 617 182 221 627 minecraft:netherite_block
fill 182 220 629 182 221 639 minecraft:netherite_block
fill 182 220 641 182 221 645 minecraft:netherite_block
fill 142 221 616 153 221 616 minecraft:gold_block
fill 142 221 628 149 221 628 minecraft:gold_block
fill 148 221 617 148 221 623 minecraft:netherite_block
fill 148 221 624 148 222 624 minecraft:iron_block
fill 148 221 625 148 221 627 minecraft:netherite_block
setblock 150 221 617 minecraft:netherite_block
fill 150 221 618 150 222 620 minecraft:iron_block
fill 150 221 621 150 221 623 minecraft:netherite_block
fill 150 221 624 150 222 624 minecraft:iron_block
fill 150 221 625 150 221 627 minecraft:netherite_block
fill 150 221 628 150 222 630 minecraft:iron_block
fill 150 221 631 150 221 639 minecraft:netherite_block
fill 151 221 628 172 222 628 minecraft:iron_block
setblock 152 221 617 minecraft:netherite_block
fill 152 221 618 152 222 627 minecraft:iron_block
fill 152 221 629 152 222 630 minecraft:iron_block
fill 152 221 631 152 221 639 minecraft:netherite_block
fill 154 221 605 154 221 613 minecraft:netherite_block
fill 154 221 614 154 222 627 minecraft:iron_block
fill 154 221 629 154 222 634 minecraft:iron_block
fill 154 221 635 154 221 639 minecraft:netherite_block
fill 155 221 616 168 222 616 minecraft:iron_block
fill 155 221 623 157 222 625 minecraft:iron_block
fill 156 221 605 156 221 614 minecraft:netherite_block
fill 156 221 615 156 222 615 minecraft:iron_block
fill 156 221 617 156 222 622 minecraft:iron_block
fill 156 221 626 156 222 627 minecraft:iron_block
fill 156 221 629 156 222 633 minecraft:iron_block
fill 156 221 634 156 221 639 minecraft:netherite_block
fill 158 221 605 158 221 611 minecraft:netherite_block
fill 158 221 612 158 222 615 minecraft:iron_block
fill 158 221 617 158 222 623 minecraft:iron_block
fill 158 221 624 159 221 624 minecraft:waxed_copper_block
fill 158 221 625 158 222 627 minecraft:iron_block
fill 158 221 629 158 222 636 minecraft:iron_block
fill 158 221 637 158 221 639 minecraft:netherite_block
fill 159 221 617 160 222 621 minecraft:iron_block
fill 159 221 622 159 222 623 minecraft:waxed_copper_block
fill 159 221 625 159 222 626 minecraft:waxed_copper_block
fill 159 221 627 160 222 627 minecraft:iron_block
fill 160 221 605 160 221 613 minecraft:netherite_block
fill 160 221 614 160 222 615 minecraft:iron_block
fill 160 221 622 163 221 622 minecraft:waxed_copper_block
fill 160 221 626 163 221 626 minecraft:waxed_copper_block
fill 160 221 629 160 222 634 minecraft:iron_block
fill 160 221 635 160 221 639 minecraft:netherite_block
fill 161 221 617 162 222 620 minecraft:iron_block
fill 161 221 621 161 223 621 minecraft:waxed_copper_block
fill 161 221 627 161 223 627 minecraft:waxed_copper_block
fill 161 221 629 162 222 630 minecraft:iron_block
fill 162 221 605 162 221 613 minecraft:netherite_block
fill 162 221 614 162 222 615 minecraft:iron_block
fill 162 221 621 166 222 621 minecraft:iron_block
fill 162 221 627 164 222 627 minecraft:iron_block
fill 162 221 631 162 222 634 minecraft:iron_block
fill 162 221 635 162 221 639 minecraft:netherite_block
fill 163 221 619 166 222 620 minecraft:iron_block
fill 163 221 623 163 221 625 minecraft:waxed_copper_block
fill 164 221 605 164 221 611 minecraft:netherite_block
fill 164 221 612 164 222 615 minecraft:iron_block
fill 164 221 617 164 222 618 minecraft:iron_block
fill 164 221 622 164 222 623 minecraft:iron_block
fill 164 221 624 164 223 624 minecraft:waxed_copper_block
fill 164 221 625 168 222 626 minecraft:iron_block
fill 164 221 629 164 222 636 minecraft:iron_block
fill 164 221 637 164 221 639 minecraft:netherite_block
fill 165 221 624 168 222 624 minecraft:iron_block
fill 166 221 605 166 221 614 minecraft:netherite_block
fill 166 221 615 166 222 615 minecraft:iron_block
fill 166 221 617 166 222 618 minecraft:iron_block
fill 166 221 622 166 222 623 minecraft:iron_block
fill 166 221 627 166 222 627 minecraft:iron_block
fill 166 221 629 166 222 633 minecraft:iron_block
fill 166 221 634 166 221 639 minecraft:netherite_block
fill 168 221 605 168 221 613 minecraft:netherite_block
fill 168 221 614 168 222 615 minecraft:iron_block
fill 168 221 617 168 222 623 minecraft:iron_block
fill 168 221 627 168 222 627 minecraft:iron_block
fill 168 221 629 168 222 634 minecraft:iron_block
fill 168 221 635 168 221 639 minecraft:netherite_block
fill 169 221 616 182 221 616 minecraft:gold_block
setblock 170 221 617 minecraft:netherite_block
fill 170 221 618 170 222 627 minecraft:iron_block
fill 170 221 629 170 222 630 minecraft:iron_block
fill 170 221 631 170 221 639 minecraft:netherite_block
setblock 172 221 617 minecraft:netherite_block
fill 172 221 618 172 222 620 minecraft:iron_block
fill 172 221 621 172 221 623 minecraft:netherite_block
fill 172 221 624 172 222 624 minecraft:iron_block
fill 172 221 625 172 221 627 minecraft:netherite_block
fill 172 221 629 172 222 630 minecraft:iron_block
fill 172 221 631 172 221 639 minecraft:netherite_block
fill 173 221 628 182 221 628 minecraft:gold_block
fill 174 221 617 174 221 623 minecraft:netherite_block
fill 174 221 624 174 222 624 minecraft:iron_block
fill 174 221 625 174 221 627 minecraft:netherite_block
setblock 149 222 619 minecraft:iron_block
fill 149 222 623 149 222 625 minecraft:iron_block
setblock 149 222 629 minecraft:iron_block
fill 151 222 618 151 222 627 minecraft:iron_block
fill 151 222 629 151 222 630 minecraft:iron_block
fill 153 222 614 153 222 615 minecraft:iron_block
fill 153 222 629 153 222 631 minecraft:iron_block
fill 153 222 633 153 222 634 minecraft:iron_block
setblock 155 222 615 minecraft:iron_block
fill 155 222 629 155 222 633 minecraft:iron_block
fill 157 222 614 157 222 615 minecraft:iron_block
fill 157 222 629 157 222 634 minecraft:iron_block
fill 158 222 624 158 223 624 minecraft:waxed_copper_block
fill 159 222 612 159 222 615 minecraft:iron_block
fill 159 222 629 159 222 636 minecraft:iron_block
setblock 160 222 622 minecraft:waxed_copper_block
setblock 160 222 626 minecraft:waxed_copper_block
fill 161 222 613 161 222 615 minecraft:iron_block
fill 161 222 631 161 222 635 minecraft:iron_block
fill 162 222 622 163 222 622 minecraft:waxed_copper_block
fill 162 222 626 163 222 626 minecraft:waxed_copper_block
fill 163 222 612 163 222 615 minecraft:iron_block
setblock 163 222 623 minecraft:waxed_copper_block
setblock 163 222 625 minecraft:waxed_copper_block
fill 163 222 629 163 222 636 minecraft:iron_block
fill 165 222 614 165 222 615 minecraft:iron_block
fill 165 222 629 165 222 634 minecraft:iron_block
setblock 167 222 615 minecraft:iron_block
fill 167 222 629 167 222 633 minecraft:iron_block
fill 169 222 614 169 222 615 minecraft:iron_block
fill 169 222 629 169 222 631 minecraft:iron_block
fill 169 222 633 169 222 634 minecraft:iron_block
fill 171 222 618 171 222 627 minecraft:iron_block
fill 171 222 629 171 222 630 minecraft:iron_block
setblock 173 222 619 minecraft:iron_block
fill 173 222 623 173 222 625 minecraft:iron_block
setblock 173 222 629 minecraft:iron_block
setblock 144 223 607 minecraft:light[level=14]
schedule function dropper:buildpart/147_2 1t
