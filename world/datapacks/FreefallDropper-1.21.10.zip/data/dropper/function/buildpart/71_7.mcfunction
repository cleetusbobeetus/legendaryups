fill 542 299 275 542 306 275 minecraft:brown_terracotta
fill 542 299 317 542 306 317 minecraft:brown_terracotta
fill 544 299 275 544 306 275 minecraft:brown_terracotta
setblock 544 299 278 minecraft:light[level=15]
setblock 544 299 286 minecraft:light[level=15]
setblock 544 299 294 minecraft:light[level=15]
setblock 544 299 302 minecraft:light[level=15]
setblock 544 299 310 minecraft:light[level=15]
fill 544 299 317 544 306 317 minecraft:brown_terracotta
setblock 545 299 275 minecraft:white_concrete
setblock 545 299 317 minecraft:white_concrete
fill 546 299 275 546 306 275 minecraft:brown_terracotta
fill 546 299 317 546 306 317 minecraft:brown_terracotta
fill 548 299 275 548 306 275 minecraft:brown_terracotta
fill 548 299 317 548 306 317 minecraft:brown_terracotta
setblock 549 299 275 minecraft:white_concrete
setblock 549 299 317 minecraft:white_concrete
fill 550 299 275 550 306 275 minecraft:brown_terracotta
fill 550 299 317 550 306 317 minecraft:brown_terracotta
fill 551 299 276 555 299 280 minecraft:orange_terracotta
fill 552 299 275 552 306 275 minecraft:brown_terracotta
setblock 552 299 281 minecraft:brown_terracotta
setblock 552 299 286 minecraft:light[level=15]
setblock 552 299 294 minecraft:light[level=15]
setblock 552 299 302 minecraft:light[level=15]
setblock 552 299 310 minecraft:light[level=15]
fill 552 299 317 552 306 317 minecraft:brown_terracotta
setblock 553 299 275 minecraft:white_concrete
fill 553 299 281 555 300 281 minecraft:white_concrete
setblock 553 299 282 minecraft:brown_terracotta
setblock 553 299 317 minecraft:white_concrete
fill 554 299 275 554 306 275 minecraft:brown_terracotta
fill 554 299 317 554 306 317 minecraft:brown_terracotta
fill 556 299 275 556 306 275 minecraft:brown_terracotta
fill 556 299 276 556 300 276 minecraft:white_concrete
fill 556 299 279 556 299 282 minecraft:brown_terracotta
fill 556 299 317 556 306 317 minecraft:brown_terracotta
setblock 557 299 275 minecraft:white_concrete
setblock 557 299 317 minecraft:white_concrete
fill 558 299 275 558 306 275 minecraft:brown_terracotta
fill 558 299 317 558 306 317 minecraft:brown_terracotta
setblock 559 299 275 minecraft:white_concrete
fill 559 299 276 559 306 276 minecraft:brown_terracotta
fill 559 299 278 559 306 278 minecraft:brown_terracotta
setblock 559 299 279 minecraft:white_concrete
fill 559 299 280 559 306 280 minecraft:brown_terracotta
fill 559 299 282 559 306 282 minecraft:brown_terracotta
setblock 559 299 283 minecraft:white_concrete
fill 559 299 284 559 306 284 minecraft:brown_terracotta
fill 559 299 286 559 306 286 minecraft:brown_terracotta
setblock 559 299 287 minecraft:white_concrete
fill 559 299 288 559 306 288 minecraft:brown_terracotta
fill 559 299 290 559 306 290 minecraft:brown_terracotta
setblock 559 299 291 minecraft:white_concrete
fill 559 299 292 559 306 292 minecraft:brown_terracotta
fill 559 299 294 559 306 294 minecraft:brown_terracotta
setblock 559 299 295 minecraft:white_concrete
fill 559 299 296 559 306 296 minecraft:brown_terracotta
fill 559 299 298 559 306 298 minecraft:brown_terracotta
setblock 559 299 299 minecraft:white_concrete
fill 559 299 300 559 306 300 minecraft:brown_terracotta
fill 559 299 302 559 306 302 minecraft:brown_terracotta
setblock 559 299 303 minecraft:white_concrete
fill 559 299 304 559 306 304 minecraft:brown_terracotta
fill 559 299 306 559 306 306 minecraft:brown_terracotta
setblock 559 299 307 minecraft:white_concrete
fill 559 299 308 559 306 308 minecraft:brown_terracotta
fill 559 299 310 559 306 310 minecraft:brown_terracotta
setblock 559 299 311 minecraft:white_concrete
fill 559 299 312 559 306 312 minecraft:brown_terracotta
fill 559 299 314 559 306 314 minecraft:brown_terracotta
setblock 559 299 315 minecraft:white_concrete
fill 559 299 316 559 306 316 minecraft:brown_terracotta
fill 517 300 275 517 307 275 minecraft:brown_terracotta
fill 517 300 279 517 307 279 minecraft:brown_terracotta
fill 517 300 283 517 307 283 minecraft:brown_terracotta
fill 517 300 287 517 307 287 minecraft:brown_terracotta
fill 517 300 291 517 307 291 minecraft:brown_terracotta
fill 517 300 295 517 307 295 minecraft:brown_terracotta
fill 517 300 299 517 307 299 minecraft:brown_terracotta
fill 517 300 303 517 307 303 minecraft:brown_terracotta
fill 517 300 307 517 307 307 minecraft:brown_terracotta
fill 517 300 311 517 307 311 minecraft:brown_terracotta
fill 517 300 315 517 307 315 minecraft:brown_terracotta
fill 517 300 317 517 305 317 minecraft:brown_terracotta
fill 519 300 285 519 300 287 minecraft:white_concrete
setblock 519 300 299 minecraft:white_concrete
fill 519 300 309 519 300 311 minecraft:white_concrete
fill 521 300 275 521 307 275 minecraft:brown_terracotta
fill 521 300 317 521 307 317 minecraft:brown_terracotta
fill 525 300 275 525 307 275 minecraft:brown_terracotta
fill 525 300 315 527 300 315 minecraft:white_concrete
fill 525 300 317 525 307 317 minecraft:brown_terracotta
fill 529 300 275 529 307 275 minecraft:brown_terracotta
fill 529 300 277 531 300 277 minecraft:white_concrete
fill 529 300 317 529 307 317 minecraft:brown_terracotta
fill 533 300 275 533 307 275 minecraft:brown_terracotta
fill 533 300 317 533 307 317 minecraft:brown_terracotta
fill 537 300 275 537 307 275 minecraft:brown_terracotta
fill 537 300 315 539 300 315 minecraft:white_concrete
fill 537 300 317 537 307 317 minecraft:brown_terracotta
fill 541 300 275 541 307 275 minecraft:brown_terracotta
fill 541 300 277 543 300 277 minecraft:white_concrete
fill 541 300 317 541 307 317 minecraft:brown_terracotta
fill 545 300 275 545 307 275 minecraft:brown_terracotta
fill 545 300 317 545 307 317 minecraft:brown_terracotta
fill 549 300 275 549 307 275 minecraft:brown_terracotta
fill 549 300 315 551 300 315 minecraft:white_concrete
fill 549 300 317 549 307 317 minecraft:brown_terracotta
fill 551 300 276 552 303 280 minecraft:orange_terracotta
setblock 552 300 281 minecraft:red_concrete
fill 553 300 275 553 307 275 minecraft:brown_terracotta
fill 553 300 276 555 303 277 minecraft:orange_terracotta
fill 553 300 278 553 301 278 minecraft:ochre_froglight
fill 553 300 279 555 303 280 minecraft:orange_terracotta
setblock 553 300 282 minecraft:red_concrete
fill 553 300 317 553 307 317 minecraft:brown_terracotta
fill 554 300 278 555 303 278 minecraft:orange_terracotta
fill 556 300 279 556 300 282 minecraft:red_concrete
fill 557 300 275 557 307 275 minecraft:brown_terracotta
fill 557 300 285 557 300 286 minecraft:white_concrete
fill 557 300 297 557 300 299 minecraft:white_concrete
fill 557 300 309 557 300 311 minecraft:white_concrete
fill 557 300 317 557 307 317 minecraft:brown_terracotta
fill 559 300 275 559 305 275 minecraft:brown_terracotta
fill 559 300 279 559 307 279 minecraft:brown_terracotta
fill 559 300 283 559 307 283 minecraft:brown_terracotta
fill 559 300 287 559 307 287 minecraft:brown_terracotta
fill 559 300 291 559 307 291 minecraft:brown_terracotta
fill 559 300 295 559 307 295 minecraft:brown_terracotta
fill 559 300 299 559 307 299 minecraft:brown_terracotta
fill 559 300 303 559 307 303 minecraft:brown_terracotta
fill 559 300 307 559 307 307 minecraft:brown_terracotta
fill 559 300 311 559 307 311 minecraft:brown_terracotta
fill 559 300 315 559 307 315 minecraft:brown_terracotta
fill 551 302 310 555 302 314 minecraft:orange_terracotta
fill 553 302 278 553 303 278 minecraft:orange_terracotta
setblock 520 303 278 minecraft:light[level=12]
setblock 520 303 285 minecraft:light[level=12]
setblock 520 303 292 minecraft:light[level=12]
setblock 520 303 299 minecraft:light[level=12]
setblock 520 303 306 minecraft:light[level=12]
setblock 520 303 313 minecraft:light[level=12]
setblock 527 303 278 minecraft:light[level=12]
setblock 527 303 285 minecraft:light[level=12]
setblock 527 303 292 minecraft:light[level=12]
setblock 527 303 299 minecraft:light[level=12]
setblock 527 303 306 minecraft:light[level=12]
setblock 527 303 313 minecraft:light[level=12]
setblock 534 303 278 minecraft:light[level=12]
setblock 534 303 285 minecraft:light[level=12]
setblock 534 303 292 minecraft:light[level=12]
setblock 534 303 299 minecraft:light[level=12]
setblock 534 303 306 minecraft:light[level=12]
setblock 534 303 313 minecraft:light[level=12]
setblock 541 303 278 minecraft:light[level=12]
setblock 541 303 285 minecraft:light[level=12]
setblock 541 303 292 minecraft:light[level=12]
setblock 541 303 299 minecraft:light[level=12]
setblock 541 303 306 minecraft:light[level=12]
setblock 541 303 313 minecraft:light[level=12]
setblock 548 303 278 minecraft:light[level=12]
setblock 548 303 285 minecraft:light[level=12]
setblock 548 303 292 minecraft:light[level=12]
setblock 548 303 299 minecraft:light[level=12]
setblock 548 303 306 minecraft:light[level=12]
setblock 548 303 313 minecraft:light[level=12]
fill 551 303 310 552 303 314 minecraft:orange_terracotta
fill 553 303 310 555 303 311 minecraft:orange_terracotta
setblock 553 303 312 minecraft:ochre_froglight
fill 553 303 313 555 303 314 minecraft:orange_terracotta
fill 554 303 312 555 303 312 minecraft:orange_terracotta
setblock 555 303 285 minecraft:light[level=12]
setblock 555 303 292 minecraft:light[level=12]
setblock 555 303 299 minecraft:light[level=12]
setblock 555 303 306 minecraft:light[level=12]
setblock 517 306 277 minecraft:white_concrete
setblock 517 306 281 minecraft:white_concrete
setblock 517 306 285 minecraft:white_concrete
setblock 517 306 289 minecraft:white_concrete
setblock 517 306 293 minecraft:white_concrete
setblock 517 306 297 minecraft:white_concrete
setblock 517 306 301 minecraft:white_concrete
setblock 517 306 305 minecraft:white_concrete
setblock 517 306 309 minecraft:white_concrete
setblock 517 306 313 minecraft:white_concrete
setblock 517 306 317 minecraft:white_concrete
setblock 519 306 275 minecraft:white_concrete
setblock 519 306 317 minecraft:white_concrete
setblock 523 306 275 minecraft:white_concrete
setblock 523 306 317 minecraft:white_concrete
setblock 527 306 275 minecraft:white_concrete
setblock 527 306 317 minecraft:white_concrete
setblock 531 306 275 minecraft:white_concrete
setblock 531 306 317 minecraft:white_concrete
setblock 535 306 275 minecraft:white_concrete
setblock 535 306 317 minecraft:white_concrete
setblock 539 306 275 minecraft:white_concrete
setblock 539 306 317 minecraft:white_concrete
setblock 543 306 275 minecraft:white_concrete
setblock 543 306 317 minecraft:white_concrete
setblock 547 306 275 minecraft:white_concrete
setblock 547 306 317 minecraft:white_concrete
setblock 551 306 275 minecraft:white_concrete
setblock 551 306 317 minecraft:white_concrete
setblock 555 306 275 minecraft:white_concrete
setblock 555 306 317 minecraft:white_concrete
setblock 559 306 275 minecraft:white_concrete
setblock 559 306 277 minecraft:white_concrete
setblock 559 306 281 minecraft:white_concrete
setblock 559 306 285 minecraft:white_concrete
setblock 559 306 289 minecraft:white_concrete
setblock 559 306 293 minecraft:white_concrete
setblock 559 306 297 minecraft:white_concrete
setblock 559 306 301 minecraft:white_concrete
setblock 559 306 305 minecraft:white_concrete
setblock 559 306 309 minecraft:white_concrete
setblock 559 306 313 minecraft:white_concrete
setblock 559 306 317 minecraft:white_concrete
setblock 517 307 276 minecraft:white_concrete
fill 517 307 277 517 308 277 minecraft:brown_terracotta
setblock 517 307 278 minecraft:white_concrete
setblock 517 307 280 minecraft:white_concrete
fill 517 307 281 517 308 281 minecraft:brown_terracotta
setblock 517 307 282 minecraft:white_concrete
setblock 517 307 284 minecraft:white_concrete
fill 517 307 285 517 308 285 minecraft:brown_terracotta
setblock 517 307 286 minecraft:white_concrete
setblock 517 307 288 minecraft:white_concrete
fill 517 307 289 517 308 289 minecraft:brown_terracotta
setblock 517 307 290 minecraft:white_concrete
setblock 517 307 292 minecraft:white_concrete
fill 517 307 293 517 308 293 minecraft:brown_terracotta
setblock 517 307 294 minecraft:white_concrete
setblock 517 307 296 minecraft:white_concrete
fill 517 307 297 517 308 297 minecraft:brown_terracotta
setblock 517 307 298 minecraft:white_concrete
setblock 517 307 300 minecraft:white_concrete
fill 517 307 301 517 308 301 minecraft:brown_terracotta
setblock 517 307 302 minecraft:white_concrete
setblock 517 307 304 minecraft:white_concrete
fill 517 307 305 517 308 305 minecraft:brown_terracotta
setblock 517 307 306 minecraft:white_concrete
setblock 517 307 308 minecraft:white_concrete
fill 517 307 309 517 308 309 minecraft:brown_terracotta
setblock 517 307 310 minecraft:white_concrete
setblock 517 307 312 minecraft:white_concrete
fill 517 307 313 517 308 313 minecraft:brown_terracotta
setblock 517 307 314 minecraft:white_concrete
setblock 517 307 316 minecraft:white_concrete
setblock 517 307 317 minecraft:brown_terracotta
setblock 518 307 275 minecraft:white_concrete
setblock 518 307 317 minecraft:white_concrete
fill 519 307 275 519 308 275 minecraft:brown_terracotta
fill 519 307 317 519 308 317 minecraft:brown_terracotta
setblock 520 307 275 minecraft:white_concrete
setblock 520 307 317 minecraft:white_concrete
setblock 522 307 275 minecraft:white_concrete
setblock 522 307 317 minecraft:white_concrete
fill 523 307 275 523 308 275 minecraft:brown_terracotta
fill 523 307 317 523 308 317 minecraft:brown_terracotta
setblock 524 307 275 minecraft:white_concrete
setblock 524 307 317 minecraft:white_concrete
setblock 526 307 275 minecraft:white_concrete
setblock 526 307 317 minecraft:white_concrete
fill 527 307 275 527 308 275 minecraft:brown_terracotta
fill 527 307 317 527 308 317 minecraft:brown_terracotta
setblock 528 307 275 minecraft:white_concrete
setblock 528 307 317 minecraft:white_concrete
setblock 530 307 275 minecraft:white_concrete
setblock 530 307 317 minecraft:white_concrete
fill 531 307 275 531 308 275 minecraft:brown_terracotta
fill 531 307 317 531 308 317 minecraft:brown_terracotta
setblock 532 307 275 minecraft:white_concrete
setblock 532 307 317 minecraft:white_concrete
setblock 534 307 275 minecraft:white_concrete
setblock 534 307 317 minecraft:white_concrete
fill 535 307 275 535 308 275 minecraft:brown_terracotta
fill 535 307 317 535 308 317 minecraft:brown_terracotta
setblock 536 307 275 minecraft:white_concrete
setblock 536 307 317 minecraft:white_concrete
setblock 538 307 275 minecraft:white_concrete
setblock 538 307 317 minecraft:white_concrete
fill 539 307 275 539 308 275 minecraft:brown_terracotta
fill 539 307 317 539 308 317 minecraft:brown_terracotta
setblock 540 307 275 minecraft:white_concrete
setblock 540 307 317 minecraft:white_concrete
setblock 542 307 275 minecraft:white_concrete
setblock 542 307 317 minecraft:white_concrete
fill 543 307 275 543 308 275 minecraft:brown_terracotta
fill 543 307 317 543 308 317 minecraft:brown_terracotta
setblock 544 307 275 minecraft:white_concrete
setblock 544 307 317 minecraft:white_concrete
setblock 546 307 275 minecraft:white_concrete
setblock 546 307 317 minecraft:white_concrete
fill 547 307 275 547 308 275 minecraft:brown_terracotta
fill 547 307 317 547 308 317 minecraft:brown_terracotta
setblock 548 307 275 minecraft:white_concrete
setblock 548 307 317 minecraft:white_concrete
setblock 550 307 275 minecraft:white_concrete
setblock 550 307 317 minecraft:white_concrete
fill 551 307 275 551 308 275 minecraft:brown_terracotta
fill 551 307 310 555 307 314 minecraft:white_concrete
fill 551 307 317 551 308 317 minecraft:brown_terracotta
setblock 552 307 275 minecraft:white_concrete
setblock 552 307 317 minecraft:white_concrete
setblock 554 307 275 minecraft:white_concrete
setblock 554 307 317 minecraft:white_concrete
fill 555 307 275 555 308 275 minecraft:brown_terracotta
fill 555 307 317 555 308 317 minecraft:brown_terracotta
setblock 556 307 275 minecraft:white_concrete
setblock 556 307 317 minecraft:white_concrete
setblock 558 307 275 minecraft:white_concrete
setblock 558 307 317 minecraft:white_concrete
setblock 559 307 275 minecraft:brown_terracotta
setblock 559 307 276 minecraft:white_concrete
fill 559 307 277 559 308 277 minecraft:brown_terracotta
setblock 559 307 278 minecraft:white_concrete
setblock 559 307 280 minecraft:white_concrete
fill 559 307 281 559 308 281 minecraft:brown_terracotta
setblock 559 307 282 minecraft:white_concrete
setblock 559 307 284 minecraft:white_concrete
fill 559 307 285 559 308 285 minecraft:brown_terracotta
setblock 559 307 286 minecraft:white_concrete
setblock 559 307 288 minecraft:white_concrete
fill 559 307 289 559 308 289 minecraft:brown_terracotta
setblock 559 307 290 minecraft:white_concrete
setblock 559 307 292 minecraft:white_concrete
fill 559 307 293 559 308 293 minecraft:brown_terracotta
setblock 559 307 294 minecraft:white_concrete
setblock 559 307 296 minecraft:white_concrete
fill 559 307 297 559 308 297 minecraft:brown_terracotta
setblock 559 307 298 minecraft:white_concrete
setblock 559 307 300 minecraft:white_concrete
fill 559 307 301 559 308 301 minecraft:brown_terracotta
setblock 559 307 302 minecraft:white_concrete
setblock 559 307 304 minecraft:white_concrete
fill 559 307 305 559 308 305 minecraft:brown_terracotta
setblock 559 307 306 minecraft:white_concrete
setblock 559 307 308 minecraft:white_concrete
fill 559 307 309 559 308 309 minecraft:brown_terracotta
setblock 559 307 310 minecraft:white_concrete
setblock 559 307 312 minecraft:white_concrete
fill 559 307 313 559 308 313 minecraft:brown_terracotta
setblock 559 307 314 minecraft:white_concrete
setblock 559 307 316 minecraft:white_concrete
fill 559 307 317 559 308 317 minecraft:brown_terracotta
setblock 517 308 275 minecraft:white_concrete
setblock 517 308 276 minecraft:brown_terracotta
setblock 517 308 278 minecraft:brown_terracotta
setblock 517 308 279 minecraft:white_concrete
setblock 517 308 280 minecraft:brown_terracotta
setblock 517 308 282 minecraft:brown_terracotta
setblock 517 308 283 minecraft:white_concrete
setblock 517 308 284 minecraft:brown_terracotta
setblock 517 308 286 minecraft:brown_terracotta
setblock 517 308 287 minecraft:white_concrete
setblock 517 308 288 minecraft:brown_terracotta
setblock 517 308 290 minecraft:brown_terracotta
setblock 517 308 291 minecraft:white_concrete
setblock 517 308 292 minecraft:brown_terracotta
setblock 517 308 294 minecraft:brown_terracotta
setblock 517 308 295 minecraft:white_concrete
setblock 517 308 296 minecraft:brown_terracotta
setblock 517 308 298 minecraft:brown_terracotta
setblock 517 308 299 minecraft:white_concrete
setblock 517 308 300 minecraft:brown_terracotta
setblock 517 308 302 minecraft:brown_terracotta
setblock 517 308 303 minecraft:white_concrete
setblock 517 308 304 minecraft:brown_terracotta
setblock 517 308 306 minecraft:brown_terracotta
setblock 517 308 307 minecraft:white_concrete
setblock 517 308 308 minecraft:brown_terracotta
setblock 517 308 310 minecraft:brown_terracotta
setblock 517 308 311 minecraft:white_concrete
setblock 517 308 312 minecraft:brown_terracotta
setblock 517 308 314 minecraft:brown_terracotta
setblock 517 308 315 minecraft:white_concrete
setblock 517 308 316 minecraft:brown_terracotta
setblock 517 308 317 minecraft:white_concrete
setblock 518 308 275 minecraft:brown_terracotta
setblock 518 308 317 minecraft:brown_terracotta
setblock 520 308 275 minecraft:brown_terracotta
setblock 520 308 317 minecraft:brown_terracotta
setblock 521 308 275 minecraft:white_concrete
setblock 521 308 317 minecraft:white_concrete
setblock 522 308 275 minecraft:brown_terracotta
setblock 522 308 317 minecraft:brown_terracotta
setblock 524 308 275 minecraft:brown_terracotta
setblock 524 308 317 minecraft:brown_terracotta
setblock 525 308 275 minecraft:white_concrete
setblock 525 308 317 minecraft:white_concrete
setblock 526 308 275 minecraft:brown_terracotta
setblock 526 308 317 minecraft:brown_terracotta
setblock 528 308 275 minecraft:brown_terracotta
setblock 528 308 317 minecraft:brown_terracotta
setblock 529 308 275 minecraft:white_concrete
setblock 529 308 317 minecraft:white_concrete
setblock 530 308 275 minecraft:brown_terracotta
setblock 530 308 317 minecraft:brown_terracotta
setblock 532 308 275 minecraft:brown_terracotta
setblock 532 308 317 minecraft:brown_terracotta
setblock 533 308 275 minecraft:white_concrete
setblock 533 308 317 minecraft:white_concrete
setblock 534 308 275 minecraft:brown_terracotta
setblock 534 308 317 minecraft:brown_terracotta
setblock 536 308 275 minecraft:brown_terracotta
setblock 536 308 317 minecraft:brown_terracotta
setblock 537 308 275 minecraft:white_concrete
setblock 537 308 317 minecraft:white_concrete
setblock 538 308 275 minecraft:brown_terracotta
setblock 538 308 317 minecraft:brown_terracotta
setblock 540 308 275 minecraft:brown_terracotta
setblock 540 308 317 minecraft:brown_terracotta
setblock 541 308 275 minecraft:white_concrete
setblock 541 308 317 minecraft:white_concrete
setblock 542 308 275 minecraft:brown_terracotta
setblock 542 308 317 minecraft:brown_terracotta
setblock 544 308 275 minecraft:brown_terracotta
setblock 544 308 317 minecraft:brown_terracotta
setblock 545 308 275 minecraft:white_concrete
setblock 545 308 317 minecraft:white_concrete
setblock 546 308 275 minecraft:brown_terracotta
setblock 546 308 317 minecraft:brown_terracotta
setblock 548 308 275 minecraft:brown_terracotta
setblock 548 308 317 minecraft:brown_terracotta
setblock 549 308 275 minecraft:white_concrete
setblock 549 308 317 minecraft:white_concrete
setblock 550 308 275 minecraft:brown_terracotta
setblock 550 308 317 minecraft:brown_terracotta
setblock 552 308 275 minecraft:brown_terracotta
fill 552 308 310 554 308 314 minecraft:white_concrete
setblock 552 308 317 minecraft:brown_terracotta
setblock 553 308 275 minecraft:white_concrete
setblock 553 308 317 minecraft:white_concrete
setblock 554 308 275 minecraft:brown_terracotta
setblock 554 308 317 minecraft:brown_terracotta
setblock 556 308 275 minecraft:brown_terracotta
setblock 556 308 317 minecraft:brown_terracotta
setblock 557 308 275 minecraft:white_concrete
setblock 557 308 317 minecraft:white_concrete
setblock 558 308 275 minecraft:brown_terracotta
setblock 558 308 317 minecraft:brown_terracotta
setblock 559 308 275 minecraft:white_concrete
setblock 559 308 276 minecraft:brown_terracotta
setblock 559 308 278 minecraft:brown_terracotta
setblock 559 308 279 minecraft:white_concrete
setblock 559 308 280 minecraft:brown_terracotta
setblock 559 308 282 minecraft:brown_terracotta
setblock 559 308 283 minecraft:white_concrete
setblock 559 308 284 minecraft:brown_terracotta
setblock 559 308 286 minecraft:brown_terracotta
setblock 559 308 287 minecraft:white_concrete
setblock 559 308 288 minecraft:brown_terracotta
setblock 559 308 290 minecraft:brown_terracotta
setblock 559 308 291 minecraft:white_concrete
setblock 559 308 292 minecraft:brown_terracotta
setblock 559 308 294 minecraft:brown_terracotta
setblock 559 308 295 minecraft:white_concrete
setblock 559 308 296 minecraft:brown_terracotta
setblock 559 308 298 minecraft:brown_terracotta
setblock 559 308 299 minecraft:white_concrete
setblock 559 308 300 minecraft:brown_terracotta
setblock 559 308 302 minecraft:brown_terracotta
setblock 559 308 303 minecraft:white_concrete
setblock 559 308 304 minecraft:brown_terracotta
setblock 559 308 306 minecraft:brown_terracotta
setblock 559 308 307 minecraft:white_concrete
setblock 559 308 308 minecraft:brown_terracotta
setblock 559 308 310 minecraft:brown_terracotta
setblock 559 308 311 minecraft:white_concrete
setblock 559 308 312 minecraft:brown_terracotta
setblock 559 308 314 minecraft:brown_terracotta
setblock 559 308 315 minecraft:white_concrete
setblock 559 308 316 minecraft:brown_terracotta
