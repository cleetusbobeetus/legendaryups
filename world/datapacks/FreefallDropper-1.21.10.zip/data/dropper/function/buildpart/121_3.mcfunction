setblock 61 291 534 minecraft:crying_obsidian
fill 61 291 535 61 291 550 minecraft:polished_blackstone_bricks
fill 62 291 512 62 291 526 minecraft:polished_blackstone_bricks
setblock 62 291 527 minecraft:crying_obsidian
fill 62 291 535 62 291 536 minecraft:crying_obsidian
fill 62 291 537 62 291 550 minecraft:polished_blackstone_bricks
fill 63 291 512 63 291 525 minecraft:polished_blackstone_bricks
setblock 63 291 526 minecraft:crying_obsidian
fill 63 291 537 63 292 537 minecraft:crying_obsidian
fill 63 291 538 63 291 550 minecraft:polished_blackstone_bricks
fill 64 291 512 64 291 524 minecraft:polished_blackstone_bricks
setblock 64 291 525 minecraft:crying_obsidian
fill 64 291 538 64 292 538 minecraft:crying_obsidian
fill 64 291 539 64 291 550 minecraft:polished_blackstone_bricks
fill 65 291 512 66 291 523 minecraft:polished_blackstone_bricks
fill 65 291 524 66 291 524 minecraft:crying_obsidian
setblock 66 291 529 minecraft:light[level=11]
setblock 66 291 537 minecraft:light[level=11]
fill 66 291 539 67 292 539 minecraft:crying_obsidian
fill 66 291 540 67 291 550 minecraft:polished_blackstone_bricks
fill 67 291 512 87 291 522 minecraft:polished_blackstone_bricks
fill 67 291 523 70 292 523 minecraft:crying_obsidian
fill 70 291 539 70 292 539 minecraft:crying_obsidian
fill 71 291 523 87 291 523 minecraft:polished_blackstone_bricks
fill 71 291 538 72 291 538 minecraft:crying_obsidian
fill 71 291 539 87 291 539 minecraft:polished_blackstone_bricks
fill 72 291 524 72 292 524 minecraft:crying_obsidian
fill 73 291 524 87 291 524 minecraft:polished_blackstone_bricks
setblock 74 291 529 minecraft:light[level=11]
fill 76 291 534 76 292 534 minecraft:crying_obsidian
fill 77 291 534 87 291 534 minecraft:polished_blackstone_bricks
fill 47 292 516 47 307 516 minecraft:blackstone
fill 47 292 517 47 292 518 minecraft:crying_obsidian
fill 47 292 519 47 307 519 minecraft:blackstone
fill 47 292 528 47 307 528 minecraft:blackstone
fill 47 292 529 47 292 530 minecraft:crying_obsidian
fill 47 292 531 47 307 531 minecraft:blackstone
fill 47 292 540 47 307 540 minecraft:blackstone
fill 47 292 541 47 292 542 minecraft:crying_obsidian
fill 47 292 543 47 307 543 minecraft:blackstone
fill 47 292 552 47 307 552 minecraft:blackstone
fill 48 292 552 49 292 552 minecraft:crying_obsidian
fill 49 292 512 59 292 550 minecraft:blackstone
fill 50 292 552 50 307 552 minecraft:blackstone
fill 54 292 510 54 307 510 minecraft:blackstone
fill 55 292 510 56 292 510 minecraft:crying_obsidian
fill 57 292 510 57 307 510 minecraft:blackstone
fill 59 292 552 59 307 552 minecraft:blackstone
fill 60 292 512 60 292 527 minecraft:blackstone
fill 60 292 528 60 292 534 minecraft:crying_obsidian
fill 60 292 535 60 292 550 minecraft:blackstone
fill 60 292 552 61 292 552 minecraft:crying_obsidian
fill 61 292 512 61 292 526 minecraft:blackstone
setblock 61 292 527 minecraft:crying_obsidian
setblock 61 292 535 minecraft:crying_obsidian
fill 61 292 536 61 292 550 minecraft:blackstone
fill 62 292 512 62 292 525 minecraft:blackstone
setblock 62 292 526 minecraft:crying_obsidian
setblock 62 292 536 minecraft:crying_obsidian
fill 62 292 537 62 292 550 minecraft:blackstone
fill 62 292 552 62 307 552 minecraft:blackstone
fill 63 292 512 63 292 524 minecraft:blackstone
setblock 63 292 525 minecraft:crying_obsidian
fill 63 292 538 63 292 550 minecraft:blackstone
fill 64 292 512 64 292 523 minecraft:blackstone
setblock 64 292 524 minecraft:crying_obsidian
fill 64 292 539 64 292 550 minecraft:blackstone
fill 65 292 512 87 292 522 minecraft:blackstone
fill 65 292 523 66 292 523 minecraft:crying_obsidian
setblock 65 292 539 minecraft:crying_obsidian
fill 65 292 540 87 292 550 minecraft:blackstone
fill 66 292 510 66 307 510 minecraft:blackstone
fill 67 292 510 68 292 510 minecraft:crying_obsidian
fill 69 292 510 69 307 510 minecraft:blackstone
setblock 71 292 523 minecraft:crying_obsidian
setblock 71 292 539 minecraft:crying_obsidian
fill 71 292 552 71 307 552 minecraft:blackstone
fill 72 292 523 87 292 523 minecraft:blackstone
fill 72 292 538 73 292 538 minecraft:crying_obsidian
fill 72 292 539 87 292 539 minecraft:blackstone
fill 72 292 552 73 292 552 minecraft:crying_obsidian
setblock 73 292 524 minecraft:crying_obsidian
fill 74 292 524 87 292 524 minecraft:blackstone
setblock 74 292 525 minecraft:crying_obsidian
setblock 74 292 537 minecraft:crying_obsidian
fill 74 292 538 87 292 538 minecraft:blackstone
fill 74 292 552 74 307 552 minecraft:blackstone
fill 75 292 525 87 292 525 minecraft:blackstone
setblock 75 292 526 minecraft:crying_obsidian
setblock 75 292 536 minecraft:crying_obsidian
fill 75 292 537 87 292 537 minecraft:blackstone
fill 76 292 526 87 292 527 minecraft:blackstone
setblock 76 292 528 minecraft:crying_obsidian
fill 76 292 535 87 292 536 minecraft:blackstone
fill 77 292 528 87 292 534 minecraft:blackstone
fill 78 292 510 78 307 510 minecraft:blackstone
fill 79 292 510 80 292 510 minecraft:crying_obsidian
fill 81 292 510 81 307 510 minecraft:blackstone
fill 83 292 552 83 307 552 minecraft:blackstone
fill 84 292 552 85 292 552 minecraft:crying_obsidian
fill 86 292 552 86 307 552 minecraft:blackstone
fill 89 292 511 89 307 511 minecraft:blackstone
fill 89 292 512 89 292 513 minecraft:crying_obsidian
fill 89 292 514 89 307 514 minecraft:blackstone
fill 89 292 523 89 307 523 minecraft:blackstone
fill 89 292 524 89 292 525 minecraft:crying_obsidian
fill 89 292 526 89 307 526 minecraft:blackstone
fill 89 292 535 89 307 535 minecraft:blackstone
fill 89 292 536 89 292 537 minecraft:crying_obsidian
fill 89 292 538 89 307 538 minecraft:blackstone
fill 89 292 547 89 307 547 minecraft:blackstone
fill 89 292 548 89 292 549 minecraft:crying_obsidian
fill 89 292 550 89 307 550 minecraft:blackstone
fill 47 293 517 47 307 518 minecraft:blackstone
fill 47 293 529 47 307 530 minecraft:blackstone
fill 47 293 541 47 307 542 minecraft:blackstone
fill 48 293 511 50 300 511 minecraft:polished_blackstone_bricks
fill 48 293 521 48 300 523 minecraft:polished_blackstone_bricks
fill 48 293 533 48 300 535 minecraft:polished_blackstone_bricks
fill 48 293 545 48 300 547 minecraft:polished_blackstone_bricks
fill 48 293 552 49 307 552 minecraft:blackstone
fill 51 293 514 53 300 515 minecraft:polished_blackstone_bricks
fill 52 293 513 53 300 513 minecraft:polished_blackstone_bricks
fill 54 293 514 54 300 514 minecraft:polished_blackstone_bricks
fill 54 293 551 56 300 551 minecraft:polished_blackstone_bricks
fill 55 293 510 56 307 510 minecraft:blackstone
fill 60 293 511 62 300 511 minecraft:polished_blackstone_bricks
fill 60 293 552 61 307 552 minecraft:blackstone
fill 66 293 551 68 300 551 minecraft:polished_blackstone_bricks
fill 67 293 510 68 307 510 minecraft:blackstone
fill 72 293 511 74 300 511 minecraft:polished_blackstone_bricks
fill 72 293 552 73 307 552 minecraft:blackstone
fill 78 293 551 80 300 551 minecraft:polished_blackstone_bricks
fill 79 293 510 80 307 510 minecraft:blackstone
fill 84 293 511 86 300 511 minecraft:polished_blackstone_bricks
fill 84 293 552 85 307 552 minecraft:blackstone
fill 88 293 519 88 300 521 minecraft:polished_blackstone_bricks
fill 88 293 531 88 300 533 minecraft:polished_blackstone_bricks
fill 88 293 543 88 300 545 minecraft:polished_blackstone_bricks
fill 89 293 512 89 307 513 minecraft:blackstone
fill 89 293 524 89 307 525 minecraft:blackstone
fill 89 293 536 89 307 537 minecraft:blackstone
fill 89 293 548 89 307 549 minecraft:blackstone
setblock 50 299 513 minecraft:light[level=11]
fill 50 299 514 50 300 514 minecraft:purple_stained_glass
setblock 50 299 521 minecraft:light[level=11]
setblock 50 299 529 minecraft:light[level=11]
setblock 50 299 537 minecraft:light[level=11]
setblock 50 299 545 minecraft:light[level=11]
fill 51 299 513 51 300 513 minecraft:purple_stained_glass
fill 51 299 516 53 300 516 minecraft:purple_stained_glass
fill 52 299 512 53 300 512 minecraft:purple_stained_glass
fill 54 299 513 54 300 513 minecraft:purple_stained_glass
fill 54 299 515 54 300 515 minecraft:purple_stained_glass
setblock 58 299 513 minecraft:light[level=11]
setblock 58 299 521 minecraft:light[level=11]
setblock 58 299 529 minecraft:light[level=11]
setblock 58 299 537 minecraft:light[level=11]
setblock 58 299 545 minecraft:light[level=11]
setblock 66 299 513 minecraft:light[level=11]
setblock 66 299 521 minecraft:light[level=11]
setblock 66 299 529 minecraft:light[level=11]
setblock 66 299 537 minecraft:light[level=11]
setblock 66 299 545 minecraft:light[level=11]
setblock 74 299 513 minecraft:light[level=11]
setblock 74 299 521 minecraft:light[level=11]
setblock 74 299 529 minecraft:light[level=11]
setblock 74 299 537 minecraft:light[level=11]
setblock 74 299 545 minecraft:light[level=11]
setblock 82 299 513 minecraft:light[level=11]
setblock 82 299 521 minecraft:light[level=11]
setblock 82 299 529 minecraft:light[level=11]
setblock 82 299 537 minecraft:light[level=11]
setblock 82 299 545 minecraft:light[level=11]
fill 49 300 520 49 300 522 minecraft:polished_blackstone_bricks
fill 49 300 532 49 300 534 minecraft:polished_blackstone_bricks
fill 49 300 544 49 300 546 minecraft:polished_blackstone_bricks
fill 55 300 550 57 300 550 minecraft:polished_blackstone_bricks
fill 59 300 512 61 300 512 minecraft:polished_blackstone_bricks
fill 67 300 550 69 300 550 minecraft:polished_blackstone_bricks
fill 71 300 512 73 300 512 minecraft:polished_blackstone_bricks
fill 79 300 550 81 300 550 minecraft:polished_blackstone_bricks
fill 83 300 512 85 300 512 minecraft:polished_blackstone_bricks
fill 87 300 520 87 300 522 minecraft:polished_blackstone_bricks
fill 87 300 532 87 300 534 minecraft:polished_blackstone_bricks
fill 87 300 544 87 300 546 minecraft:polished_blackstone_bricks
