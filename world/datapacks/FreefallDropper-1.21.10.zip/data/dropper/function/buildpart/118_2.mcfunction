fill 475 54 504 475 57 504 minecraft:red_terracotta
setblock 476 54 502 minecraft:terracotta
fill 476 54 503 476 57 503 minecraft:red_terracotta
fill 477 54 502 477 57 502 minecraft:red_terracotta
setblock 478 54 465 minecraft:terracotta
setblock 479 54 464 minecraft:terracotta
fill 479 54 465 479 57 465 minecraft:red_terracotta
setblock 479 54 504 minecraft:terracotta
fill 480 54 464 480 57 464 minecraft:red_terracotta
setblock 480 54 503 minecraft:terracotta
fill 480 54 504 480 57 504 minecraft:red_terracotta
setblock 481 54 466 minecraft:light[level=14]
setblock 481 54 474 minecraft:light[level=14]
setblock 481 54 482 minecraft:light[level=14]
setblock 481 54 490 minecraft:light[level=14]
setblock 481 54 498 minecraft:light[level=14]
setblock 481 54 502 minecraft:terracotta
fill 481 54 503 481 57 503 minecraft:red_terracotta
fill 482 54 502 482 55 502 minecraft:red_terracotta
setblock 484 54 464 minecraft:terracotta
setblock 484 54 504 minecraft:terracotta
setblock 485 54 503 minecraft:terracotta
fill 485 54 504 488 54 504 minecraft:red_terracotta
setblock 486 54 503 minecraft:red_terracotta
setblock 489 54 466 minecraft:light[level=14]
setblock 489 54 474 minecraft:light[level=14]
setblock 489 54 482 minecraft:light[level=14]
setblock 489 54 490 minecraft:light[level=14]
setblock 489 54 498 minecraft:light[level=14]
setblock 489 54 504 minecraft:terracotta
fill 490 54 504 490 57 504 minecraft:red_terracotta
fill 492 54 503 494 54 503 minecraft:red_terracotta
setblock 494 54 504 minecraft:terracotta
fill 495 54 464 495 57 464 minecraft:red_terracotta
setblock 495 54 503 minecraft:terracotta
fill 495 54 504 495 57 504 minecraft:red_terracotta
fill 496 54 503 496 57 503 minecraft:red_terracotta
setblock 497 54 466 minecraft:light[level=14]
setblock 497 54 474 minecraft:light[level=14]
setblock 497 54 490 minecraft:light[level=14]
setblock 497 54 498 minecraft:light[level=14]
setblock 499 54 464 minecraft:terracotta
setblock 499 54 504 minecraft:terracotta
fill 500 54 464 500 57 464 minecraft:red_terracotta
setblock 500 54 503 minecraft:terracotta
fill 500 54 504 500 57 504 minecraft:red_terracotta
setblock 505 54 466 minecraft:light[level=14]
setblock 505 54 474 minecraft:light[level=14]
setblock 505 54 482 minecraft:light[level=14]
setblock 505 54 490 minecraft:light[level=14]
setblock 505 54 498 minecraft:light[level=14]
fill 511 54 464 511 55 465 minecraft:red_terracotta
setblock 511 54 477 minecraft:terracotta
fill 511 54 478 511 57 478 minecraft:red_terracotta
setblock 511 54 482 minecraft:terracotta
fill 511 54 483 511 57 483 minecraft:red_terracotta
fill 511 54 485 511 55 485 minecraft:red_terracotta
setblock 471 55 466 minecraft:terracotta
fill 471 55 467 471 57 468 minecraft:red_terracotta
setblock 471 55 481 minecraft:terracotta
fill 471 55 482 471 58 482 minecraft:red_terracotta
setblock 471 55 501 minecraft:terracotta
fill 471 55 502 471 58 502 minecraft:red_terracotta
setblock 472 55 465 minecraft:terracotta
fill 472 55 466 472 58 466 minecraft:red_terracotta
setblock 473 55 464 minecraft:terracotta
fill 473 55 465 473 58 465 minecraft:red_terracotta
setblock 473 55 504 minecraft:terracotta
fill 474 55 464 474 58 464 minecraft:red_terracotta
setblock 474 55 502 minecraft:red_terracotta
setblock 474 55 503 minecraft:terracotta
fill 474 55 504 474 58 504 minecraft:red_terracotta
setblock 475 55 502 minecraft:terracotta
fill 475 55 503 475 58 503 minecraft:red_terracotta
fill 476 55 502 476 58 502 minecraft:red_terracotta
setblock 477 55 465 minecraft:terracotta
setblock 478 55 464 minecraft:terracotta
fill 478 55 465 478 58 465 minecraft:red_terracotta
setblock 478 55 504 minecraft:terracotta
fill 479 55 464 479 58 464 minecraft:red_terracotta
setblock 479 55 503 minecraft:terracotta
fill 479 55 504 479 58 504 minecraft:red_terracotta
setblock 480 55 502 minecraft:terracotta
fill 480 55 503 480 58 503 minecraft:red_terracotta
fill 481 55 502 481 56 502 minecraft:red_terracotta
setblock 483 55 464 minecraft:terracotta
setblock 483 55 504 minecraft:terracotta
setblock 484 55 503 minecraft:terracotta
fill 484 55 504 487 55 504 minecraft:red_terracotta
setblock 485 55 503 minecraft:red_terracotta
setblock 488 55 504 minecraft:terracotta
fill 489 55 504 489 58 504 minecraft:red_terracotta
fill 492 55 503 493 55 503 minecraft:red_terracotta
setblock 493 55 504 minecraft:terracotta
fill 494 55 464 494 58 464 minecraft:red_terracotta
setblock 494 55 503 minecraft:terracotta
fill 494 55 504 494 58 504 minecraft:red_terracotta
fill 495 55 503 495 58 503 minecraft:red_terracotta
setblock 498 55 464 minecraft:terracotta
setblock 498 55 504 minecraft:terracotta
fill 499 55 464 499 58 464 minecraft:red_terracotta
setblock 499 55 503 minecraft:terracotta
fill 499 55 504 499 58 504 minecraft:red_terracotta
fill 510 55 464 510 57 464 minecraft:red_terracotta
setblock 511 55 466 minecraft:terracotta
fill 511 55 467 511 58 467 minecraft:red_terracotta
setblock 511 55 476 minecraft:terracotta
fill 511 55 477 511 58 477 minecraft:red_terracotta
setblock 511 55 481 minecraft:terracotta
fill 511 55 482 511 58 482 minecraft:red_terracotta
setblock 471 56 465 minecraft:terracotta
fill 471 56 466 471 59 466 minecraft:red_terracotta
setblock 471 56 469 minecraft:red_terracotta
fill 471 56 481 471 59 481 minecraft:red_terracotta
fill 471 56 483 471 57 483 minecraft:red_terracotta
setblock 471 56 500 minecraft:terracotta
fill 471 56 501 472 58 501 minecraft:red_terracotta
setblock 472 56 464 minecraft:terracotta
fill 472 56 465 472 59 465 minecraft:red_terracotta
fill 472 56 467 472 57 467 minecraft:red_terracotta
setblock 472 56 504 minecraft:terracotta
fill 473 56 464 473 59 464 minecraft:red_terracotta
setblock 473 56 503 minecraft:terracotta
fill 473 56 504 473 59 504 minecraft:red_terracotta
setblock 474 56 502 minecraft:terracotta
fill 474 56 503 474 59 503 minecraft:red_terracotta
fill 475 56 502 475 59 502 minecraft:red_terracotta
setblock 476 56 465 minecraft:terracotta
setblock 477 56 464 minecraft:terracotta
fill 477 56 465 477 59 465 minecraft:red_terracotta
setblock 477 56 504 minecraft:terracotta
fill 478 56 464 478 59 464 minecraft:red_terracotta
setblock 478 56 503 minecraft:terracotta
fill 478 56 504 478 59 504 minecraft:red_terracotta
setblock 479 56 502 minecraft:terracotta
fill 479 56 503 479 59 503 minecraft:red_terracotta
fill 480 56 502 480 58 502 minecraft:red_terracotta
setblock 482 56 464 minecraft:terracotta
setblock 482 56 504 minecraft:terracotta
fill 483 56 464 483 59 464 minecraft:red_terracotta
setblock 483 56 503 minecraft:terracotta
fill 483 56 504 486 56 504 minecraft:red_terracotta
fill 484 56 503 484 57 503 minecraft:red_terracotta
setblock 487 56 504 minecraft:terracotta
fill 488 56 504 488 59 504 minecraft:red_terracotta
setblock 492 56 503 minecraft:red_terracotta
setblock 492 56 504 minecraft:terracotta
fill 493 56 464 493 59 464 minecraft:red_terracotta
setblock 493 56 503 minecraft:terracotta
fill 493 56 504 493 59 504 minecraft:red_terracotta
fill 494 56 503 494 59 503 minecraft:red_terracotta
setblock 497 56 464 minecraft:terracotta
setblock 497 56 504 minecraft:terracotta
fill 498 56 464 498 59 464 minecraft:red_terracotta
setblock 498 56 503 minecraft:terracotta
fill 498 56 504 498 59 504 minecraft:red_terracotta
setblock 499 56 503 minecraft:red_terracotta
setblock 502 56 464 minecraft:terracotta
setblock 502 56 504 minecraft:terracotta
fill 503 56 464 503 59 464 minecraft:red_terracotta
fill 508 56 464 509 58 464 minecraft:red_terracotta
setblock 511 56 464 minecraft:red_terracotta
setblock 511 56 465 minecraft:terracotta
fill 511 56 466 511 59 466 minecraft:red_terracotta
fill 511 56 468 511 56 469 minecraft:red_terracotta
fill 511 56 476 511 59 476 minecraft:red_terracotta
setblock 511 56 480 minecraft:terracotta
fill 511 56 481 511 59 481 minecraft:red_terracotta
setblock 511 56 485 minecraft:terracotta
fill 511 56 486 511 59 486 minecraft:red_terracotta
fill 511 56 503 511 56 504 minecraft:red_terracotta
setblock 471 57 464 minecraft:terracotta
fill 471 57 465 471 60 465 minecraft:red_terracotta
setblock 471 57 469 minecraft:terracotta
fill 471 57 470 471 60 470 minecraft:red_terracotta
fill 471 57 480 471 60 480 minecraft:red_terracotta
setblock 471 57 484 minecraft:terracotta
fill 471 57 485 471 60 485 minecraft:red_terracotta
fill 471 57 500 471 60 500 minecraft:red_terracotta
setblock 471 57 504 minecraft:terracotta
fill 472 57 464 472 60 464 minecraft:red_terracotta
setblock 472 57 468 minecraft:terracotta
setblock 472 57 503 minecraft:terracotta
fill 472 57 504 472 60 504 minecraft:red_terracotta
setblock 473 57 466 minecraft:red_terracotta
setblock 473 57 502 minecraft:terracotta
fill 473 57 503 473 60 503 minecraft:red_terracotta
setblock 474 57 466 minecraft:terracotta
fill 474 57 502 474 60 502 minecraft:red_terracotta
setblock 475 57 465 minecraft:terracotta
fill 475 57 466 477 58 466 minecraft:red_terracotta
setblock 476 57 464 minecraft:terracotta
fill 476 57 465 476 60 465 minecraft:red_terracotta
setblock 476 57 504 minecraft:terracotta
fill 477 57 464 477 60 464 minecraft:red_terracotta
setblock 477 57 503 minecraft:terracotta
fill 477 57 504 477 60 504 minecraft:red_terracotta
setblock 478 57 502 minecraft:terracotta
fill 478 57 503 478 60 503 minecraft:red_terracotta
fill 479 57 502 479 60 502 minecraft:red_terracotta
setblock 480 57 465 minecraft:terracotta
setblock 481 57 464 minecraft:terracotta
setblock 481 57 504 minecraft:terracotta
fill 482 57 464 482 60 464 minecraft:red_terracotta
setblock 482 57 503 minecraft:terracotta
fill 482 57 504 485 57 504 minecraft:red_terracotta
fill 483 57 503 483 59 503 minecraft:red_terracotta
setblock 486 57 504 minecraft:terracotta
fill 487 57 504 487 60 504 minecraft:red_terracotta
setblock 491 57 464 minecraft:terracotta
setblock 491 57 504 minecraft:terracotta
fill 492 57 464 492 60 464 minecraft:red_terracotta
setblock 492 57 503 minecraft:terracotta
fill 492 57 504 492 60 504 minecraft:red_terracotta
fill 493 57 503 493 60 503 minecraft:red_terracotta
setblock 496 57 464 minecraft:terracotta
fill 496 57 465 498 58 465 minecraft:red_terracotta
setblock 496 57 504 minecraft:terracotta
fill 497 57 464 497 60 464 minecraft:red_terracotta
setblock 497 57 503 minecraft:terracotta
fill 497 57 504 497 60 504 minecraft:red_terracotta
fill 498 57 503 498 58 503 minecraft:red_terracotta
setblock 501 57 464 minecraft:terracotta
setblock 501 57 504 minecraft:terracotta
fill 502 57 464 502 60 464 minecraft:red_terracotta
fill 504 57 464 505 57 464 minecraft:red_terracotta
setblock 506 57 464 minecraft:terracotta
fill 507 57 464 507 60 464 minecraft:red_terracotta
setblock 510 57 465 minecraft:terracotta
setblock 510 57 504 minecraft:red_terracotta
setblock 511 57 464 minecraft:terracotta
fill 511 57 465 511 60 465 minecraft:red_terracotta
setblock 511 57 468 minecraft:red_terracotta
setblock 511 57 469 minecraft:terracotta
fill 511 57 470 511 58 472 minecraft:red_terracotta
setblock 511 57 474 minecraft:terracotta
fill 511 57 475 511 60 475 minecraft:red_terracotta
setblock 511 57 479 minecraft:terracotta
fill 511 57 480 511 60 480 minecraft:red_terracotta
setblock 511 57 484 minecraft:terracotta
fill 511 57 485 511 60 485 minecraft:red_terracotta
fill 511 57 487 511 58 487 minecraft:red_terracotta
setblock 511 57 503 minecraft:red_terracotta
setblock 511 57 504 minecraft:terracotta
fill 471 58 464 471 61 464 minecraft:red_terracotta
setblock 471 58 467 minecraft:red_terracotta
setblock 471 58 468 minecraft:terracotta
fill 471 58 469 472 60 469 minecraft:red_terracotta
fill 471 58 471 471 59 471 minecraft:red_terracotta
setblock 471 58 483 minecraft:terracotta
fill 471 58 484 471 61 484 minecraft:red_terracotta
fill 471 58 486 471 58 487 minecraft:red_terracotta
setblock 471 58 488 minecraft:terracotta
fill 471 58 499 471 61 499 minecraft:red_terracotta
setblock 471 58 503 minecraft:terracotta
fill 471 58 504 471 61 504 minecraft:red_terracotta
setblock 472 58 467 minecraft:terracotta
fill 472 58 468 472 61 468 minecraft:red_terracotta
fill 472 58 500 472 59 500 minecraft:red_terracotta
setblock 472 58 502 minecraft:terracotta
fill 472 58 503 472 61 503 minecraft:red_terracotta
setblock 473 58 466 minecraft:terracotta
fill 473 58 467 473 61 467 minecraft:red_terracotta
fill 473 58 502 473 61 502 minecraft:red_terracotta
setblock 474 58 465 minecraft:terracotta
fill 474 58 466 474 61 466 minecraft:red_terracotta
setblock 475 58 464 minecraft:terracotta
fill 475 58 465 475 61 465 minecraft:red_terracotta
setblock 475 58 504 minecraft:terracotta
fill 476 58 464 476 61 464 minecraft:red_terracotta
setblock 476 58 503 minecraft:terracotta
fill 476 58 504 476 61 504 minecraft:red_terracotta
setblock 477 58 502 minecraft:terracotta
fill 477 58 503 477 61 503 minecraft:red_terracotta
setblock 478 58 466 minecraft:terracotta
fill 478 58 502 478 61 502 minecraft:red_terracotta
setblock 479 58 465 minecraft:terracotta
setblock 480 58 464 minecraft:terracotta
fill 480 58 465 481 60 465 minecraft:red_terracotta
setblock 480 58 504 minecraft:terracotta
fill 481 58 464 481 61 464 minecraft:red_terracotta
setblock 481 58 503 minecraft:terracotta
fill 481 58 504 484 58 504 minecraft:red_terracotta
fill 482 58 503 482 61 503 minecraft:red_terracotta
setblock 484 58 464 minecraft:red_terracotta
setblock 485 58 504 minecraft:terracotta
fill 486 58 504 486 61 504 minecraft:red_terracotta
setblock 490 58 464 minecraft:terracotta
setblock 490 58 504 minecraft:terracotta
fill 491 58 464 491 61 464 minecraft:red_terracotta
setblock 491 58 503 minecraft:terracotta
fill 491 58 504 491 61 504 minecraft:red_terracotta
fill 492 58 503 492 61 503 minecraft:red_terracotta
setblock 494 58 465 minecraft:terracotta
setblock 495 58 464 minecraft:terracotta
fill 495 58 465 495 61 465 minecraft:red_terracotta
setblock 495 58 504 minecraft:terracotta
fill 496 58 464 496 61 464 minecraft:red_terracotta
setblock 496 58 503 minecraft:terracotta
fill 496 58 504 496 61 504 minecraft:red_terracotta
fill 497 58 503 497 60 503 minecraft:red_terracotta
setblock 499 58 465 minecraft:terracotta
setblock 500 58 464 minecraft:terracotta
fill 500 58 465 500 61 465 minecraft:red_terracotta
setblock 500 58 504 minecraft:terracotta
fill 501 58 464 501 61 464 minecraft:red_terracotta
fill 501 58 504 501 59 504 minecraft:red_terracotta
setblock 504 58 464 minecraft:red_terracotta
setblock 505 58 464 minecraft:terracotta
fill 506 58 464 506 61 464 minecraft:red_terracotta
setblock 509 58 465 minecraft:terracotta
setblock 509 58 504 minecraft:red_terracotta
setblock 510 58 464 minecraft:terracotta
fill 510 58 465 510 58 468 minecraft:red_terracotta
fill 510 58 481 510 58 483 minecraft:red_terracotta
setblock 510 58 484 minecraft:terracotta
setblock 510 58 504 minecraft:terracotta
fill 511 58 464 511 61 464 minecraft:red_terracotta
setblock 511 58 468 minecraft:terracotta
fill 511 58 469 511 61 469 minecraft:red_terracotta
setblock 511 58 473 minecraft:terracotta
fill 511 58 474 511 61 474 minecraft:red_terracotta
setblock 511 58 478 minecraft:terracotta
fill 511 58 479 511 61 479 minecraft:red_terracotta
setblock 511 58 483 minecraft:terracotta
fill 511 58 484 511 61 484 minecraft:red_terracotta
setblock 511 58 488 minecraft:terracotta
setblock 511 58 502 minecraft:red_terracotta
setblock 511 58 503 minecraft:terracotta
fill 511 58 504 511 61 504 minecraft:red_terracotta
setblock 471 59 467 minecraft:terracotta
fill 471 59 468 471 62 468 minecraft:red_terracotta
setblock 471 59 472 minecraft:terracotta
fill 471 59 473 471 62 473 minecraft:red_terracotta
fill 471 59 479 471 61 479 minecraft:red_terracotta
setblock 471 59 482 minecraft:terracotta
fill 471 59 483 472 61 483 minecraft:red_terracotta
setblock 471 59 486 minecraft:red_terracotta
setblock 471 59 487 minecraft:terracotta
fill 471 59 488 471 59 491 minecraft:red_terracotta
fill 471 59 498 471 62 498 minecraft:red_terracotta
setblock 471 59 501 minecraft:red_terracotta
setblock 471 59 502 minecraft:terracotta
fill 471 59 503 471 62 503 minecraft:red_terracotta
setblock 472 59 466 minecraft:terracotta
fill 472 59 467 472 62 467 minecraft:red_terracotta
setblock 472 59 470 minecraft:red_terracotta
fill 472 59 484 472 59 485 minecraft:red_terracotta
setblock 472 59 486 minecraft:terracotta
fill 472 59 487 472 61 488 minecraft:red_terracotta
setblock 472 59 501 minecraft:terracotta
fill 472 59 502 472 62 502 minecraft:red_terracotta
setblock 473 59 465 minecraft:terracotta
fill 473 59 466 473 62 466 minecraft:red_terracotta
fill 473 59 468 473 60 468 minecraft:red_terracotta
fill 473 59 501 473 62 501 minecraft:red_terracotta
setblock 474 59 464 minecraft:terracotta
fill 474 59 465 474 62 465 minecraft:red_terracotta
setblock 474 59 504 minecraft:terracotta
fill 475 59 464 475 62 464 minecraft:red_terracotta
fill 475 59 466 476 59 466 minecraft:red_terracotta
setblock 475 59 503 minecraft:terracotta
fill 475 59 504 475 62 504 minecraft:red_terracotta
setblock 476 59 502 minecraft:terracotta
fill 476 59 503 476 62 503 minecraft:red_terracotta
setblock 477 59 466 minecraft:terracotta
fill 477 59 502 477 62 502 minecraft:red_terracotta
setblock 478 59 465 minecraft:terracotta
fill 478 59 466 478 62 466 minecraft:red_terracotta
setblock 479 59 464 minecraft:terracotta
fill 479 59 465 479 62 465 minecraft:red_terracotta
setblock 479 59 504 minecraft:terracotta
fill 480 59 464 480 62 464 minecraft:red_terracotta
setblock 480 59 503 minecraft:terracotta
fill 480 59 504 483 59 504 minecraft:red_terracotta
fill 481 59 503 481 62 503 minecraft:red_terracotta
setblock 484 59 464 minecraft:terracotta
setblock 484 59 504 minecraft:terracotta
fill 485 59 464 485 62 464 minecraft:red_terracotta
fill 485 59 504 485 62 504 minecraft:red_terracotta
setblock 488 59 464 minecraft:red_terracotta
setblock 489 59 464 minecraft:terracotta
setblock 489 59 504 minecraft:terracotta
fill 490 59 464 490 62 464 minecraft:red_terracotta
setblock 490 59 503 minecraft:terracotta
fill 490 59 504 490 62 504 minecraft:red_terracotta
fill 491 59 503 491 62 503 minecraft:red_terracotta
setblock 492 59 465 minecraft:red_terracotta
setblock 493 59 465 minecraft:terracotta
setblock 494 59 464 minecraft:terracotta
fill 494 59 465 494 62 465 minecraft:red_terracotta
setblock 494 59 504 minecraft:terracotta
fill 495 59 464 495 62 464 minecraft:red_terracotta
setblock 495 59 503 minecraft:terracotta
fill 495 59 504 495 62 504 minecraft:red_terracotta
fill 496 59 465 497 59 465 minecraft:red_terracotta
fill 496 59 503 496 61 503 minecraft:red_terracotta
setblock 498 59 465 minecraft:terracotta
setblock 499 59 464 minecraft:terracotta
fill 499 59 465 499 62 465 minecraft:red_terracotta
setblock 499 59 504 minecraft:terracotta
fill 500 59 464 500 62 464 minecraft:red_terracotta
fill 500 59 504 500 61 504 minecraft:red_terracotta
fill 501 59 465 501 60 465 minecraft:red_terracotta
fill 501 59 496 501 60 497 minecraft:magma_block
setblock 504 59 464 minecraft:terracotta
fill 505 59 464 505 62 464 minecraft:red_terracotta
setblock 507 59 465 minecraft:red_terracotta
setblock 508 59 464 minecraft:red_terracotta
setblock 508 59 465 minecraft:terracotta
setblock 508 59 504 minecraft:red_terracotta
setblock 509 59 464 minecraft:terracotta
fill 509 59 465 510 61 465 minecraft:red_terracotta
setblock 509 59 504 minecraft:terracotta
fill 510 59 464 510 62 464 minecraft:red_terracotta
fill 510 59 466 510 59 467 minecraft:red_terracotta
setblock 510 59 468 minecraft:terracotta
fill 510 59 469 510 61 470 minecraft:red_terracotta
fill 510 59 481 510 59 482 minecraft:red_terracotta
setblock 510 59 483 minecraft:terracotta
fill 510 59 484 510 60 486 minecraft:red_terracotta
fill 510 59 504 510 62 504 minecraft:red_terracotta
setblock 511 59 467 minecraft:terracotta
fill 511 59 468 511 62 468 minecraft:red_terracotta
fill 511 59 470 511 59 471 minecraft:red_terracotta
setblock 511 59 472 minecraft:terracotta
fill 511 59 473 511 62 473 minecraft:red_terracotta
setblock 511 59 477 minecraft:terracotta
fill 511 59 478 511 62 478 minecraft:red_terracotta
setblock 511 59 482 minecraft:terracotta
fill 511 59 483 511 62 483 minecraft:red_terracotta
setblock 511 59 487 minecraft:terracotta
fill 511 59 488 511 60 490 minecraft:red_terracotta
setblock 511 59 501 minecraft:red_terracotta
setblock 511 59 502 minecraft:terracotta
fill 511 59 503 511 62 503 minecraft:red_terracotta
setblock 471 60 466 minecraft:terracotta
fill 471 60 467 471 63 467 minecraft:red_terracotta
setblock 471 60 471 minecraft:terracotta
fill 471 60 472 471 63 472 minecraft:red_terracotta
fill 471 60 474 471 61 474 minecraft:red_terracotta
setblock 471 60 481 minecraft:terracotta
fill 471 60 482 472 62 482 minecraft:red_terracotta
setblock 471 60 486 minecraft:terracotta
fill 471 60 487 471 60 490 minecraft:red_terracotta
setblock 471 60 491 minecraft:terracotta
fill 471 60 492 471 60 495 minecraft:red_terracotta
setblock 471 60 496 minecraft:terracotta
fill 471 60 497 471 63 497 minecraft:red_terracotta
setblock 471 60 501 minecraft:terracotta
fill 471 60 502 471 63 502 minecraft:red_terracotta
setblock 472 60 465 minecraft:terracotta
fill 472 60 466 472 63 466 minecraft:red_terracotta
setblock 472 60 470 minecraft:terracotta
fill 472 60 471 472 63 471 minecraft:red_terracotta
setblock 472 60 484 minecraft:red_terracotta
setblock 472 60 485 minecraft:terracotta
fill 472 60 486 472 63 486 minecraft:red_terracotta
setblock 472 60 489 minecraft:red_terracotta
setblock 472 60 490 minecraft:terracotta
fill 472 60 491 472 63 491 minecraft:red_terracotta
setblock 472 60 499 minecraft:red_terracotta
setblock 472 60 500 minecraft:terracotta
fill 472 60 501 472 63 501 minecraft:red_terracotta
setblock 473 60 464 minecraft:terracotta
fill 473 60 465 473 63 465 minecraft:red_terracotta
setblock 473 60 469 minecraft:terracotta
setblock 473 60 504 minecraft:terracotta
fill 474 60 464 474 63 464 minecraft:red_terracotta
setblock 474 60 467 minecraft:red_terracotta
setblock 474 60 503 minecraft:terracotta
fill 474 60 504 474 63 504 minecraft:red_terracotta
setblock 475 60 466 minecraft:red_terracotta
setblock 475 60 502 minecraft:terracotta
fill 475 60 503 475 63 503 minecraft:red_terracotta
setblock 476 60 466 minecraft:terracotta
fill 476 60 502 476 63 502 minecraft:red_terracotta
setblock 477 60 465 minecraft:terracotta
fill 477 60 466 477 63 466 minecraft:red_terracotta
setblock 478 60 464 minecraft:terracotta
fill 478 60 465 478 63 465 minecraft:red_terracotta
setblock 478 60 504 minecraft:terracotta
fill 479 60 464 479 63 464 minecraft:red_terracotta
setblock 479 60 503 minecraft:terracotta
fill 479 60 504 482 60 504 minecraft:red_terracotta
fill 480 60 503 480 62 503 minecraft:red_terracotta
setblock 483 60 464 minecraft:terracotta
setblock 483 60 504 minecraft:terracotta
fill 484 60 464 484 63 464 minecraft:red_terracotta
fill 484 60 504 484 63 504 minecraft:red_terracotta
fill 486 60 464 487 60 464 minecraft:red_terracotta
setblock 488 60 464 minecraft:terracotta
setblock 488 60 504 minecraft:terracotta
fill 489 60 464 489 63 464 minecraft:red_terracotta
fill 489 60 504 489 63 504 minecraft:red_terracotta
fill 490 60 503 490 62 503 minecraft:red_terracotta
setblock 491 60 465 minecraft:red_terracotta
setblock 492 60 465 minecraft:terracotta
setblock 493 60 464 minecraft:terracotta
fill 493 60 465 493 63 465 minecraft:red_terracotta
setblock 493 60 504 minecraft:terracotta
fill 494 60 464 494 63 464 minecraft:red_terracotta
setblock 494 60 503 minecraft:terracotta
fill 494 60 504 494 63 504 minecraft:red_terracotta
setblock 495 60 466 minecraft:red_terracotta
fill 495 60 503 495 62 503 minecraft:red_terracotta
setblock 496 60 465 minecraft:red_terracotta
setblock 496 60 466 minecraft:terracotta
setblock 497 60 465 minecraft:terracotta
fill 497 60 466 497 63 466 minecraft:red_terracotta
setblock 498 60 464 minecraft:terracotta
fill 498 60 465 498 63 465 minecraft:red_terracotta
setblock 498 60 504 minecraft:terracotta
fill 499 60 464 499 63 464 minecraft:red_terracotta
fill 499 60 504 499 62 504 minecraft:red_terracotta
setblock 502 60 465 minecraft:terracotta
setblock 503 60 464 minecraft:terracotta
fill 503 60 465 506 60 465 minecraft:red_terracotta
fill 504 60 464 504 63 464 minecraft:red_terracotta
setblock 507 60 465 minecraft:terracotta
setblock 508 60 464 minecraft:terracotta
fill 508 60 465 508 62 466 minecraft:red_terracotta
setblock 508 60 504 minecraft:terracotta
fill 509 60 464 509 63 464 minecraft:red_terracotta
fill 509 60 466 509 60 467 minecraft:red_terracotta
setblock 509 60 468 minecraft:terracotta
fill 509 60 504 509 63 504 minecraft:red_terracotta
setblock 510 60 466 minecraft:red_terracotta
setblock 510 60 467 minecraft:terracotta
fill 510 60 468 510 63 468 minecraft:red_terracotta
setblock 510 60 471 minecraft:red_terracotta
setblock 510 60 472 minecraft:terracotta
fill 510 60 480 510 60 481 minecraft:red_terracotta
setblock 510 60 482 minecraft:terracotta
fill 510 60 483 510 63 483 minecraft:red_terracotta
setblock 510 60 487 minecraft:terracotta
fill 510 60 488 510 63 488 minecraft:red_terracotta
setblock 511 60 466 minecraft:terracotta
fill 511 60 467 511 63 467 minecraft:red_terracotta
setblock 511 60 470 minecraft:red_terracotta
setblock 511 60 471 minecraft:terracotta
fill 511 60 472 511 63 472 minecraft:red_terracotta
setblock 511 60 476 minecraft:terracotta
fill 511 60 477 511 63 477 minecraft:red_terracotta
setblock 511 60 481 minecraft:terracotta
fill 511 60 482 511 63 482 minecraft:red_terracotta
setblock 511 60 486 minecraft:terracotta
fill 511 60 487 511 63 487 minecraft:red_terracotta
setblock 511 60 491 minecraft:terracotta
setblock 511 60 501 minecraft:terracotta
fill 511 60 502 511 63 502 minecraft:red_terracotta
setblock 471 61 465 minecraft:terracotta
fill 471 61 466 471 64 466 minecraft:red_terracotta
setblock 471 61 469 minecraft:red_terracotta
setblock 471 61 470 minecraft:terracotta
fill 471 61 471 471 64 471 minecraft:red_terracotta
setblock 471 61 475 minecraft:terracotta
fill 471 61 476 471 62 478 minecraft:red_terracotta
setblock 471 61 480 minecraft:terracotta
fill 471 61 481 471 64 481 minecraft:red_terracotta
setblock 471 61 485 minecraft:terracotta
fill 471 61 486 471 61 489 minecraft:red_terracotta
setblock 471 61 490 minecraft:terracotta
fill 471 61 491 471 61 494 minecraft:red_terracotta
setblock 471 61 495 minecraft:terracotta
fill 471 61 496 472 63 496 minecraft:red_terracotta
setblock 471 61 500 minecraft:terracotta
fill 471 61 501 471 64 501 minecraft:red_terracotta
setblock 472 61 464 minecraft:terracotta
fill 472 61 465 472 64 465 minecraft:red_terracotta
setblock 472 61 469 minecraft:terracotta
fill 472 61 470 473 63 470 minecraft:red_terracotta
fill 472 61 472 472 62 472 minecraft:red_terracotta
setblock 472 61 484 minecraft:terracotta
fill 472 61 485 473 63 485 minecraft:red_terracotta
setblock 472 61 489 minecraft:terracotta
fill 472 61 490 473 63 490 minecraft:red_terracotta
fill 472 61 492 472 61 493 minecraft:red_terracotta
setblock 472 61 494 minecraft:terracotta
fill 472 61 495 472 64 495 minecraft:red_terracotta
fill 472 61 497 472 61 498 minecraft:red_terracotta
setblock 472 61 499 minecraft:terracotta
fill 472 61 500 473 63 500 minecraft:red_terracotta
setblock 472 61 504 minecraft:terracotta
fill 473 61 464 473 64 464 minecraft:red_terracotta
setblock 473 61 468 minecraft:terracotta
fill 473 61 469 473 64 469 minecraft:red_terracotta
fill 473 61 486 473 61 487 minecraft:red_terracotta
setblock 473 61 488 minecraft:terracotta
fill 473 61 489 473 64 489 minecraft:red_terracotta
setblock 473 61 503 minecraft:terracotta
fill 473 61 504 473 64 504 minecraft:red_terracotta
setblock 474 61 467 minecraft:terracotta
setblock 474 61 502 minecraft:terracotta
fill 474 61 503 474 64 503 minecraft:red_terracotta
setblock 475 61 466 minecraft:terracotta
fill 475 61 467 475 62 467 minecraft:red_terracotta
fill 475 61 502 475 64 502 minecraft:red_terracotta
setblock 476 61 465 minecraft:terracotta
fill 476 61 466 476 64 466 minecraft:red_terracotta
setblock 477 61 464 minecraft:terracotta
fill 477 61 465 477 64 465 minecraft:red_terracotta
setblock 477 61 504 minecraft:terracotta
fill 478 61 464 478 64 464 minecraft:red_terracotta
setblock 478 61 503 minecraft:terracotta
fill 478 61 504 481 61 504 minecraft:red_terracotta
fill 479 61 503 479 63 503 minecraft:red_terracotta
setblock 480 61 465 minecraft:red_terracotta
setblock 481 61 465 minecraft:terracotta
setblock 482 61 464 minecraft:terracotta
setblock 482 61 504 minecraft:terracotta
fill 483 61 464 483 63 464 minecraft:red_terracotta
fill 483 61 504 483 63 504 minecraft:red_terracotta
setblock 486 61 464 minecraft:red_terracotta
setblock 487 61 464 minecraft:terracotta
setblock 487 61 504 minecraft:terracotta
fill 488 61 464 488 64 464 minecraft:red_terracotta
fill 488 61 504 488 64 504 minecraft:red_terracotta
fill 489 61 465 490 61 465 minecraft:red_terracotta
setblock 491 61 465 minecraft:terracotta
setblock 492 61 464 minecraft:terracotta
fill 492 61 465 492 64 465 minecraft:red_terracotta
setblock 492 61 504 minecraft:terracotta
fill 493 61 464 493 64 464 minecraft:red_terracotta
fill 493 61 466 494 61 466 minecraft:red_terracotta
setblock 493 61 503 minecraft:terracotta
fill 493 61 504 493 64 504 minecraft:red_terracotta
fill 494 61 503 494 62 503 minecraft:red_terracotta
setblock 495 61 466 minecraft:terracotta
setblock 496 61 465 minecraft:terracotta
fill 496 61 466 496 64 466 minecraft:red_terracotta
setblock 497 61 464 minecraft:terracotta
fill 497 61 465 497 64 465 minecraft:red_terracotta
setblock 497 61 504 minecraft:terracotta
fill 498 61 464 498 64 464 minecraft:red_terracotta
fill 498 61 466 498 62 466 minecraft:red_terracotta
fill 498 61 504 498 62 504 minecraft:red_terracotta
setblock 501 61 465 minecraft:terracotta
setblock 502 61 464 minecraft:terracotta
fill 502 61 465 505 61 465 minecraft:red_terracotta
fill 503 61 464 503 64 464 minecraft:red_terracotta
setblock 506 61 465 minecraft:terracotta
setblock 507 61 464 minecraft:terracotta
fill 507 61 465 507 63 466 minecraft:red_terracotta
setblock 507 61 504 minecraft:terracotta
fill 508 61 464 508 64 464 minecraft:red_terracotta
fill 508 61 504 508 64 504 minecraft:red_terracotta
setblock 509 61 466 minecraft:red_terracotta
setblock 509 61 467 minecraft:terracotta
fill 509 61 468 509 62 470 minecraft:red_terracotta
setblock 510 61 466 minecraft:terracotta
fill 510 61 467 510 64 467 minecraft:red_terracotta
setblock 510 61 471 minecraft:terracotta
fill 510 61 472 510 62 474 minecraft:red_terracotta
setblock 510 61 480 minecraft:red_terracotta
setblock 510 61 481 minecraft:terracotta
fill 510 61 482 510 63 482 minecraft:red_terracotta
fill 510 61 484 510 61 485 minecraft:red_terracotta
setblock 510 61 486 minecraft:terracotta
fill 510 61 487 510 64 487 minecraft:red_terracotta
fill 510 61 489 511 61 489 minecraft:red_terracotta
setblock 511 61 465 minecraft:terracotta
fill 511 61 466 511 64 466 minecraft:red_terracotta
setblock 511 61 470 minecraft:terracotta
fill 511 61 471 511 64 471 minecraft:red_terracotta
setblock 511 61 475 minecraft:terracotta
fill 511 61 476 511 64 476 minecraft:red_terracotta
setblock 511 61 480 minecraft:terracotta
fill 511 61 481 511 64 481 minecraft:red_terracotta
setblock 511 61 485 minecraft:terracotta
fill 511 61 486 511 64 486 minecraft:red_terracotta
fill 511 61 488 511 62 488 minecraft:red_terracotta
setblock 511 61 490 minecraft:terracotta
fill 511 61 491 511 62 493 minecraft:red_terracotta
setblock 511 61 500 minecraft:terracotta
fill 511 61 501 511 64 501 minecraft:red_terracotta
setblock 471 62 464 minecraft:terracotta
fill 471 62 465 471 65 465 minecraft:red_terracotta
setblock 471 62 469 minecraft:terracotta
fill 471 62 470 471 65 470 minecraft:red_terracotta
setblock 471 62 474 minecraft:terracotta
fill 471 62 475 471 65 475 minecraft:red_terracotta
setblock 471 62 479 minecraft:terracotta
fill 471 62 480 471 64 480 minecraft:red_terracotta
setblock 471 62 483 minecraft:red_terracotta
setblock 471 62 484 minecraft:terracotta
fill 471 62 485 471 62 488 minecraft:red_terracotta
setblock 471 62 489 minecraft:terracotta
fill 471 62 490 471 62 493 minecraft:red_terracotta
setblock 471 62 494 minecraft:terracotta
fill 471 62 495 471 65 495 minecraft:red_terracotta
setblock 471 62 499 minecraft:terracotta
fill 471 62 500 471 65 500 minecraft:red_terracotta
setblock 471 62 504 minecraft:terracotta
fill 472 62 464 472 65 464 minecraft:red_terracotta
setblock 472 62 468 minecraft:terracotta
fill 472 62 469 472 65 469 minecraft:red_terracotta
setblock 472 62 473 minecraft:terracotta
setblock 472 62 483 minecraft:terracotta
fill 472 62 484 472 64 484 minecraft:red_terracotta
setblock 472 62 487 minecraft:red_terracotta
setblock 472 62 488 minecraft:terracotta
fill 472 62 489 472 65 489 minecraft:red_terracotta
setblock 472 62 492 minecraft:red_terracotta
setblock 472 62 493 minecraft:terracotta
fill 472 62 494 472 65 494 minecraft:red_terracotta
setblock 472 62 497 minecraft:red_terracotta
setblock 472 62 498 minecraft:terracotta
fill 472 62 499 472 65 499 minecraft:red_terracotta
setblock 472 62 503 minecraft:terracotta
fill 472 62 504 472 65 504 minecraft:red_terracotta
setblock 473 62 467 minecraft:terracotta
fill 473 62 468 474 63 468 minecraft:red_terracotta
setblock 473 62 474 minecraft:light[level=14]
setblock 473 62 482 minecraft:light[level=14]
setblock 473 62 486 minecraft:red_terracotta
setblock 473 62 487 minecraft:terracotta
fill 473 62 488 473 65 488 minecraft:red_terracotta
setblock 473 62 491 minecraft:red_terracotta
setblock 473 62 492 minecraft:terracotta
fill 473 62 493 473 65 493 minecraft:red_terracotta
setblock 473 62 498 minecraft:light[level=14]
setblock 473 62 502 minecraft:terracotta
fill 473 62 503 473 65 503 minecraft:red_terracotta
setblock 474 62 466 minecraft:terracotta
fill 474 62 467 474 64 467 minecraft:red_terracotta
fill 474 62 502 474 64 502 minecraft:red_terracotta
setblock 475 62 465 minecraft:terracotta
fill 475 62 466 475 65 466 minecraft:red_terracotta
setblock 476 62 464 minecraft:terracotta
fill 476 62 465 476 65 465 minecraft:red_terracotta
setblock 476 62 504 minecraft:terracotta
fill 477 62 464 477 65 464 minecraft:red_terracotta
setblock 477 62 503 minecraft:terracotta
fill 477 62 504 480 62 504 minecraft:red_terracotta
fill 478 62 503 478 64 503 minecraft:red_terracotta
setblock 480 62 465 minecraft:terracotta
setblock 481 62 464 minecraft:terracotta
setblock 481 62 466 minecraft:light[level=14]
setblock 481 62 474 minecraft:light[level=14]
setblock 481 62 482 minecraft:light[level=14]
setblock 481 62 490 minecraft:light[level=14]
setblock 481 62 498 minecraft:light[level=14]
setblock 481 62 504 minecraft:terracotta
fill 482 62 464 482 63 464 minecraft:red_terracotta
fill 482 62 504 482 64 504 minecraft:red_terracotta
setblock 486 62 464 minecraft:terracotta
setblock 486 62 504 minecraft:terracotta
fill 487 62 464 487 65 464 minecraft:red_terracotta
fill 487 62 504 487 64 504 minecraft:red_terracotta
setblock 489 62 465 minecraft:red_terracotta
setblock 489 62 466 minecraft:light[level=14]
setblock 489 62 474 minecraft:light[level=14]
setblock 489 62 482 minecraft:light[level=14]
setblock 489 62 490 minecraft:light[level=14]
setblock 489 62 498 minecraft:light[level=14]
setblock 490 62 465 minecraft:terracotta
setblock 491 62 464 minecraft:terracotta
fill 491 62 465 491 65 465 minecraft:red_terracotta
setblock 491 62 504 minecraft:terracotta
fill 492 62 464 492 65 464 minecraft:red_terracotta
fill 492 62 466 493 62 466 minecraft:red_terracotta
setblock 492 62 503 minecraft:terracotta
fill 492 62 504 492 65 504 minecraft:red_terracotta
fill 493 62 503 493 63 503 minecraft:red_terracotta
setblock 494 62 466 minecraft:terracotta
setblock 495 62 465 minecraft:terracotta
fill 495 62 466 495 64 466 minecraft:red_terracotta
setblock 496 62 464 minecraft:terracotta
fill 496 62 465 496 65 465 minecraft:red_terracotta
setblock 496 62 504 minecraft:terracotta
fill 497 62 464 497 65 464 minecraft:red_terracotta
setblock 497 62 474 minecraft:light[level=14]
setblock 497 62 490 minecraft:light[level=14]
setblock 497 62 498 minecraft:light[level=14]
fill 497 62 504 497 63 504 minecraft:red_terracotta
setblock 500 62 465 minecraft:terracotta
setblock 501 62 464 minecraft:terracotta
fill 501 62 465 504 62 465 minecraft:red_terracotta
fill 502 62 464 502 65 464 minecraft:red_terracotta
setblock 505 62 465 minecraft:terracotta
setblock 505 62 466 minecraft:light[level=14]
setblock 505 62 474 minecraft:light[level=14]
setblock 505 62 482 minecraft:light[level=14]
setblock 505 62 490 minecraft:light[level=14]
setblock 505 62 498 minecraft:light[level=14]
setblock 506 62 464 minecraft:terracotta
fill 506 62 465 506 64 466 minecraft:red_terracotta
fill 507 62 464 507 65 464 minecraft:red_terracotta
fill 507 62 504 507 65 504 minecraft:red_terracotta
setblock 509 62 465 minecraft:red_terracotta
setblock 509 62 466 minecraft:terracotta
fill 509 62 467 509 65 467 minecraft:red_terracotta
setblock 509 62 471 minecraft:terracotta
setblock 510 62 465 minecraft:terracotta
fill 510 62 466 510 65 466 minecraft:red_terracotta
setblock 510 62 469 minecraft:red_terracotta
setblock 510 62 470 minecraft:terracotta
fill 510 62 471 510 65 471 minecraft:red_terracotta
setblock 510 62 475 minecraft:terracotta
fill 510 62 476 510 65 476 minecraft:red_terracotta
setblock 510 62 480 minecraft:terracotta
fill 510 62 481 510 63 481 minecraft:red_terracotta
setblock 510 62 484 minecraft:red_terracotta
setblock 510 62 485 minecraft:terracotta
fill 510 62 486 510 65 486 minecraft:red_terracotta
setblock 510 62 489 minecraft:red_terracotta
setblock 510 62 490 minecraft:terracotta
fill 510 62 503 510 63 503 minecraft:red_terracotta
setblock 511 62 464 minecraft:terracotta
fill 511 62 465 511 65 465 minecraft:red_terracotta
setblock 511 62 469 minecraft:terracotta
fill 511 62 470 511 65 470 minecraft:red_terracotta
setblock 511 62 474 minecraft:terracotta
fill 511 62 475 511 65 475 minecraft:red_terracotta
setblock 511 62 479 minecraft:terracotta
fill 511 62 480 511 65 480 minecraft:red_terracotta
setblock 511 62 484 minecraft:terracotta
fill 511 62 485 511 65 485 minecraft:red_terracotta
setblock 511 62 489 minecraft:terracotta
fill 511 62 490 511 65 490 minecraft:red_terracotta
setblock 511 62 494 minecraft:terracotta
fill 511 62 495 511 64 496 minecraft:red_terracotta
setblock 511 62 499 minecraft:terracotta
fill 511 62 500 511 65 500 minecraft:red_terracotta
setblock 511 62 504 minecraft:terracotta
fill 471 63 464 471 66 464 minecraft:red_terracotta
setblock 471 63 468 minecraft:terracotta
fill 471 63 469 471 66 469 minecraft:red_terracotta
setblock 471 63 473 minecraft:terracotta
fill 471 63 474 471 66 474 minecraft:red_terracotta
fill 471 63 476 471 63 477 minecraft:red_terracotta
setblock 471 63 478 minecraft:terracotta
setblock 471 63 479 minecraft:red_terracotta
setblock 471 63 482 minecraft:red_terracotta
setblock 471 63 483 minecraft:terracotta
fill 471 63 484 471 63 487 minecraft:red_terracotta
setblock 471 63 488 minecraft:terracotta
fill 471 63 489 471 63 492 minecraft:red_terracotta
setblock 471 63 493 minecraft:terracotta
fill 471 63 494 471 66 494 minecraft:red_terracotta
setblock 471 63 498 minecraft:terracotta
fill 471 63 499 471 66 499 minecraft:red_terracotta
setblock 471 63 503 minecraft:terracotta
fill 471 63 504 471 66 504 minecraft:red_terracotta
setblock 472 63 467 minecraft:terracotta
fill 472 63 468 472 66 468 minecraft:red_terracotta
setblock 472 63 472 minecraft:terracotta
fill 472 63 473 472 66 473 minecraft:red_terracotta
setblock 472 63 483 minecraft:red_terracotta
setblock 472 63 487 minecraft:terracotta
fill 472 63 488 472 66 488 minecraft:red_terracotta
setblock 472 63 492 minecraft:terracotta
fill 472 63 493 472 66 493 minecraft:red_terracotta
setblock 472 63 497 minecraft:terracotta
fill 472 63 498 472 66 498 minecraft:red_terracotta
setblock 472 63 502 minecraft:terracotta
fill 472 63 503 472 66 503 minecraft:red_terracotta
setblock 473 63 466 minecraft:terracotta
fill 473 63 467 473 66 467 minecraft:red_terracotta
setblock 473 63 471 minecraft:terracotta
setblock 473 63 486 minecraft:terracotta
fill 473 63 487 473 65 487 minecraft:red_terracotta
setblock 473 63 491 minecraft:terracotta
fill 473 63 492 473 66 492 minecraft:red_terracotta
fill 473 63 494 473 63 495 minecraft:red_terracotta
setblock 473 63 501 minecraft:terracotta
fill 473 63 502 473 64 502 minecraft:red_terracotta
setblock 474 63 465 minecraft:terracotta
fill 474 63 466 474 66 466 minecraft:red_terracotta
setblock 475 63 464 minecraft:terracotta
fill 475 63 465 475 66 465 minecraft:red_terracotta
setblock 475 63 504 minecraft:terracotta
fill 476 63 464 476 66 464 minecraft:red_terracotta
setblock 476 63 503 minecraft:terracotta
fill 476 63 504 479 63 504 minecraft:red_terracotta
fill 477 63 503 477 64 503 minecraft:red_terracotta
setblock 479 63 465 minecraft:terracotta
setblock 480 63 464 minecraft:terracotta
setblock 480 63 504 minecraft:terracotta
fill 481 63 464 481 64 464 minecraft:red_terracotta
fill 481 63 504 481 64 504 minecraft:red_terracotta
setblock 485 63 464 minecraft:terracotta
setblock 485 63 504 minecraft:terracotta
fill 486 63 464 486 64 464 minecraft:red_terracotta
fill 486 63 504 486 64 504 minecraft:red_terracotta
setblock 488 63 465 minecraft:red_terracotta
setblock 489 63 465 minecraft:terracotta
setblock 490 63 464 minecraft:terracotta
fill 490 63 465 490 66 465 minecraft:red_terracotta
setblock 490 63 504 minecraft:terracotta
fill 491 63 464 491 66 464 minecraft:red_terracotta
fill 491 63 466 492 63 466 minecraft:red_terracotta
setblock 491 63 503 minecraft:terracotta
fill 491 63 504 491 66 504 minecraft:red_terracotta
setblock 492 63 503 minecraft:red_terracotta
setblock 493 63 466 minecraft:terracotta
setblock 494 63 465 minecraft:terracotta
fill 494 63 466 494 65 466 minecraft:red_terracotta
setblock 495 63 464 minecraft:terracotta
fill 495 63 465 495 66 465 minecraft:red_terracotta
setblock 495 63 504 minecraft:terracotta
fill 496 63 464 496 66 464 minecraft:red_terracotta
fill 496 63 504 496 64 504 minecraft:red_terracotta
setblock 498 63 466 minecraft:terracotta
setblock 499 63 465 minecraft:terracotta
setblock 500 63 464 minecraft:terracotta
fill 500 63 465 503 63 465 minecraft:red_terracotta
fill 501 63 464 501 66 464 minecraft:red_terracotta
setblock 504 63 465 minecraft:terracotta
setblock 505 63 464 minecraft:terracotta
fill 505 63 465 505 66 465 minecraft:red_terracotta
fill 506 63 464 506 66 464 minecraft:red_terracotta
setblock 508 63 465 minecraft:red_terracotta
setblock 508 63 466 minecraft:terracotta
fill 508 63 467 508 65 468 minecraft:red_terracotta
setblock 509 63 465 minecraft:terracotta
fill 509 63 466 509 66 466 minecraft:red_terracotta
fill 509 63 468 509 63 469 minecraft:red_terracotta
setblock 509 63 470 minecraft:terracotta
fill 509 63 471 509 65 472 minecraft:red_terracotta
setblock 510 63 464 minecraft:terracotta
fill 510 63 465 510 66 465 minecraft:red_terracotta
setblock 510 63 469 minecraft:terracotta
fill 510 63 470 510 66 470 minecraft:red_terracotta
fill 510 63 472 510 63 473 minecraft:red_terracotta
setblock 510 63 474 minecraft:terracotta
fill 510 63 475 510 66 475 minecraft:red_terracotta
setblock 510 63 484 minecraft:terracotta
fill 510 63 485 510 65 485 minecraft:red_terracotta
setblock 510 63 489 minecraft:terracotta
fill 510 63 490 510 64 492 minecraft:red_terracotta
setblock 510 63 504 minecraft:terracotta
fill 511 63 464 511 66 464 minecraft:red_terracotta
setblock 511 63 468 minecraft:terracotta
fill 511 63 469 511 66 469 minecraft:red_terracotta
setblock 511 63 473 minecraft:terracotta
fill 511 63 474 511 66 474 minecraft:red_terracotta
setblock 511 63 478 minecraft:terracotta
fill 511 63 479 511 66 479 minecraft:red_terracotta
setblock 511 63 483 minecraft:terracotta
fill 511 63 484 511 66 484 minecraft:red_terracotta
setblock 511 63 488 minecraft:terracotta
fill 511 63 489 511 66 489 minecraft:red_terracotta
fill 511 63 491 511 63 492 minecraft:red_terracotta
setblock 511 63 493 minecraft:terracotta
fill 511 63 494 511 66 494 minecraft:red_terracotta
setblock 511 63 497 minecraft:red_terracotta
setblock 511 63 498 minecraft:terracotta
fill 511 63 499 511 66 499 minecraft:red_terracotta
setblock 511 63 503 minecraft:terracotta
fill 511 63 504 511 66 504 minecraft:red_terracotta
setblock 471 64 467 minecraft:terracotta
fill 471 64 468 471 67 468 minecraft:red_terracotta
setblock 471 64 472 minecraft:terracotta
fill 471 64 473 471 67 473 minecraft:red_terracotta
setblock 471 64 476 minecraft:red_terracotta
setblock 471 64 477 minecraft:terracotta
setblock 471 64 482 minecraft:terracotta
fill 471 64 483 471 64 486 minecraft:red_terracotta
setblock 471 64 487 minecraft:terracotta
fill 471 64 488 471 64 491 minecraft:red_terracotta
setblock 471 64 492 minecraft:terracotta
fill 471 64 493 471 67 493 minecraft:red_terracotta
setblock 471 64 496 minecraft:red_terracotta
setblock 471 64 497 minecraft:terracotta
fill 471 64 498 471 67 498 minecraft:red_terracotta
setblock 471 64 502 minecraft:terracotta
fill 471 64 503 471 67 503 minecraft:red_terracotta
setblock 472 64 466 minecraft:terracotta
fill 472 64 467 472 67 467 minecraft:red_terracotta
setblock 472 64 470 minecraft:red_terracotta
setblock 472 64 471 minecraft:terracotta
fill 472 64 472 472 67 472 minecraft:red_terracotta
setblock 472 64 485 minecraft:red_terracotta
setblock 472 64 486 minecraft:terracotta
fill 472 64 487 472 67 487 minecraft:red_terracotta
setblock 472 64 490 minecraft:red_terracotta
setblock 472 64 491 minecraft:terracotta
fill 472 64 492 472 67 492 minecraft:red_terracotta
setblock 472 64 496 minecraft:terracotta
fill 472 64 497 472 67 497 minecraft:red_terracotta
setblock 472 64 500 minecraft:red_terracotta
setblock 472 64 501 minecraft:terracotta
fill 472 64 502 472 67 502 minecraft:red_terracotta
setblock 473 64 465 minecraft:terracotta
fill 473 64 466 473 66 466 minecraft:red_terracotta
fill 473 64 468 473 65 468 minecraft:red_terracotta
setblock 473 64 470 minecraft:terracotta
setblock 473 64 471 minecraft:red_terracotta
setblock 473 64 486 minecraft:red_terracotta
setblock 473 64 490 minecraft:terracotta
fill 473 64 491 473 67 491 minecraft:red_terracotta
setblock 473 64 494 minecraft:red_terracotta
setblock 473 64 495 minecraft:terracotta
fill 473 64 496 473 67 496 minecraft:red_terracotta
setblock 473 64 501 minecraft:red_terracotta
setblock 474 64 464 minecraft:terracotta
fill 474 64 465 474 67 465 minecraft:red_terracotta
setblock 474 64 504 minecraft:terracotta
fill 475 64 464 475 67 464 minecraft:red_terracotta
setblock 475 64 503 minecraft:terracotta
fill 475 64 504 478 64 504 minecraft:red_terracotta
fill 476 64 503 476 65 503 minecraft:red_terracotta
setblock 478 64 465 minecraft:terracotta
setblock 479 64 464 minecraft:terracotta
setblock 479 64 504 minecraft:terracotta
setblock 480 64 464 minecraft:red_terracotta
setblock 480 64 504 minecraft:red_terracotta
setblock 488 64 465 minecraft:terracotta
setblock 489 64 464 minecraft:terracotta
fill 489 64 465 489 65 465 minecraft:red_terracotta
setblock 489 64 504 minecraft:terracotta
fill 490 64 464 490 67 464 minecraft:red_terracotta
fill 490 64 504 490 66 504 minecraft:red_terracotta
setblock 491 64 466 minecraft:red_terracotta
setblock 492 64 466 minecraft:terracotta
setblock 493 64 465 minecraft:terracotta
fill 493 64 466 493 65 466 minecraft:red_terracotta
setblock 494 64 464 minecraft:terracotta
fill 494 64 465 494 66 465 minecraft:red_terracotta
setblock 494 64 504 minecraft:terracotta
fill 495 64 464 495 67 464 minecraft:red_terracotta
setblock 495 64 504 minecraft:red_terracotta
setblock 498 64 465 minecraft:terracotta
setblock 499 64 464 minecraft:terracotta
fill 499 64 465 502 64 465 minecraft:red_terracotta
fill 500 64 464 500 65 464 minecraft:red_terracotta
setblock 503 64 465 minecraft:terracotta
setblock 504 64 464 minecraft:terracotta
fill 504 64 465 504 66 465 minecraft:red_terracotta
fill 505 64 464 505 67 464 minecraft:red_terracotta
setblock 505 64 466 minecraft:red_terracotta
setblock 507 64 465 minecraft:red_terracotta
setblock 507 64 466 minecraft:terracotta
setblock 508 64 465 minecraft:terracotta
fill 508 64 466 508 67 466 minecraft:red_terracotta
setblock 508 64 469 minecraft:red_terracotta
setblock 509 64 464 minecraft:terracotta
fill 509 64 465 509 67 465 minecraft:red_terracotta
setblock 509 64 468 minecraft:red_terracotta
setblock 509 64 469 minecraft:terracotta
fill 509 64 470 509 67 470 minecraft:red_terracotta
setblock 509 64 473 minecraft:red_terracotta
setblock 509 64 504 minecraft:terracotta
fill 510 64 464 510 67 464 minecraft:red_terracotta
setblock 510 64 468 minecraft:terracotta
fill 510 64 469 510 67 469 minecraft:red_terracotta
setblock 510 64 472 minecraft:red_terracotta
setblock 510 64 473 minecraft:terracotta
fill 510 64 474 510 67 474 minecraft:red_terracotta
setblock 510 64 483 minecraft:terracotta
setblock 510 64 484 minecraft:red_terracotta
setblock 510 64 488 minecraft:terracotta
fill 510 64 489 510 67 489 minecraft:red_terracotta
setblock 510 64 493 minecraft:terracotta
setblock 510 64 503 minecraft:terracotta
fill 510 64 504 510 67 504 minecraft:red_terracotta
setblock 511 64 467 minecraft:terracotta
fill 511 64 468 511 67 468 minecraft:red_terracotta
setblock 511 64 472 minecraft:terracotta
fill 511 64 473 511 67 473 minecraft:red_terracotta
setblock 511 64 477 minecraft:terracotta
fill 511 64 478 511 67 478 minecraft:red_terracotta
setblock 511 64 482 minecraft:terracotta
fill 511 64 483 511 66 483 minecraft:red_terracotta
setblock 511 64 487 minecraft:terracotta
fill 511 64 488 511 67 488 minecraft:red_terracotta
setblock 511 64 491 minecraft:red_terracotta
setblock 511 64 492 minecraft:terracotta
fill 511 64 493 511 67 493 minecraft:red_terracotta
setblock 511 64 497 minecraft:terracotta
fill 511 64 498 511 67 498 minecraft:red_terracotta
setblock 511 64 502 minecraft:terracotta
fill 511 64 503 511 67 503 minecraft:red_terracotta
setblock 471 65 466 minecraft:terracotta
fill 471 65 467 471 68 467 minecraft:red_terracotta
setblock 471 65 471 minecraft:terracotta
fill 471 65 472 471 68 472 minecraft:red_terracotta
setblock 471 65 476 minecraft:terracotta
fill 471 65 482 471 65 485 minecraft:red_terracotta
setblock 471 65 486 minecraft:terracotta
fill 471 65 487 471 65 490 minecraft:red_terracotta
setblock 471 65 491 minecraft:terracotta
fill 471 65 492 471 68 492 minecraft:red_terracotta
setblock 471 65 496 minecraft:terracotta
fill 471 65 497 471 68 497 minecraft:red_terracotta
setblock 471 65 501 minecraft:terracotta
fill 471 65 502 471 68 502 minecraft:red_terracotta
setblock 472 65 465 minecraft:terracotta
fill 472 65 466 472 68 466 minecraft:red_terracotta
setblock 472 65 470 minecraft:terracotta
fill 472 65 471 472 68 471 minecraft:red_terracotta
setblock 472 65 485 minecraft:terracotta
fill 472 65 486 472 66 486 minecraft:red_terracotta
setblock 472 65 490 minecraft:terracotta
fill 472 65 491 472 68 491 minecraft:red_terracotta
setblock 472 65 495 minecraft:terracotta
fill 472 65 496 472 68 496 minecraft:red_terracotta
setblock 472 65 500 minecraft:terracotta
fill 472 65 501 472 68 501 minecraft:red_terracotta
setblock 473 65 464 minecraft:terracotta
fill 473 65 465 473 68 465 minecraft:red_terracotta
setblock 473 65 469 minecraft:terracotta
fill 473 65 470 473 66 470 minecraft:red_terracotta
setblock 473 65 489 minecraft:terracotta
fill 473 65 490 473 67 490 minecraft:red_terracotta
setblock 473 65 494 minecraft:terracotta
fill 473 65 495 473 68 495 minecraft:red_terracotta
setblock 473 65 504 minecraft:terracotta
fill 474 65 464 474 68 464 minecraft:red_terracotta
setblock 474 65 503 minecraft:terracotta
fill 474 65 504 477 65 504 minecraft:red_terracotta
fill 475 65 503 475 66 503 minecraft:red_terracotta
setblock 477 65 465 minecraft:terracotta
setblock 478 65 464 minecraft:terracotta
setblock 478 65 504 minecraft:terracotta
setblock 479 65 464 minecraft:red_terracotta
setblock 479 65 504 minecraft:red_terracotta
setblock 488 65 464 minecraft:terracotta
setblock 488 65 504 minecraft:terracotta
fill 489 65 464 489 67 464 minecraft:red_terracotta
fill 489 65 504 489 66 504 minecraft:red_terracotta
setblock 492 65 465 minecraft:terracotta
setblock 492 65 466 minecraft:red_terracotta
setblock 493 65 464 minecraft:terracotta
fill 493 65 465 493 66 465 minecraft:red_terracotta
setblock 493 65 504 minecraft:terracotta
fill 494 65 464 494 67 464 minecraft:red_terracotta
setblock 494 65 504 minecraft:red_terracotta
setblock 497 65 465 minecraft:terracotta
setblock 498 65 464 minecraft:terracotta
setblock 498 65 465 minecraft:red_terracotta
fill 499 65 464 499 66 464 minecraft:red_terracotta
setblock 503 65 464 minecraft:terracotta
setblock 503 65 465 minecraft:red_terracotta
fill 504 65 464 504 68 464 minecraft:red_terracotta
setblock 506 65 465 minecraft:red_terracotta
setblock 506 65 466 minecraft:terracotta
setblock 507 65 465 minecraft:terracotta
fill 507 65 466 507 68 466 minecraft:red_terracotta
setblock 508 65 464 minecraft:terracotta
fill 508 65 465 508 68 465 minecraft:red_terracotta
setblock 508 65 469 minecraft:terracotta
fill 508 65 470 508 68 470 minecraft:red_terracotta
setblock 508 65 504 minecraft:terracotta
fill 509 65 464 509 68 464 minecraft:red_terracotta
setblock 509 65 468 minecraft:terracotta
fill 509 65 469 509 68 469 minecraft:red_terracotta
setblock 509 65 473 minecraft:terracotta
fill 509 65 504 509 68 504 minecraft:red_terracotta
setblock 510 65 467 minecraft:terracotta
fill 510 65 468 510 68 468 minecraft:red_terracotta
setblock 510 65 472 minecraft:terracotta
fill 510 65 473 510 68 473 minecraft:red_terracotta
setblock 510 65 487 minecraft:terracotta
fill 510 65 488 510 67 488 minecraft:red_terracotta
fill 510 65 490 510 65 491 minecraft:red_terracotta
setblock 510 65 492 minecraft:terracotta
fill 510 65 493 510 68 493 minecraft:red_terracotta
setblock 511 65 466 minecraft:terracotta
fill 511 65 467 511 68 467 minecraft:red_terracotta
setblock 511 65 471 minecraft:terracotta
fill 511 65 472 511 68 472 minecraft:red_terracotta
setblock 511 65 476 minecraft:terracotta
fill 511 65 477 511 68 477 minecraft:red_terracotta
setblock 511 65 481 minecraft:terracotta
fill 511 65 482 511 66 482 minecraft:red_terracotta
setblock 511 65 486 minecraft:terracotta
fill 511 65 487 511 68 487 minecraft:red_terracotta
setblock 511 65 491 minecraft:terracotta
fill 511 65 492 511 68 492 minecraft:red_terracotta
setblock 511 65 495 minecraft:red_terracotta
setblock 511 65 496 minecraft:terracotta
fill 511 65 497 511 68 497 minecraft:red_terracotta
setblock 511 65 501 minecraft:terracotta
fill 511 65 502 511 68 502 minecraft:red_terracotta
setblock 471 66 465 minecraft:terracotta
fill 471 66 466 471 69 466 minecraft:red_terracotta
setblock 471 66 470 minecraft:terracotta
fill 471 66 471 471 69 471 minecraft:red_terracotta
setblock 471 66 475 minecraft:terracotta
fill 471 66 476 471 69 476 minecraft:red_terracotta
fill 471 66 483 471 66 484 minecraft:red_terracotta
setblock 471 66 485 minecraft:terracotta
fill 471 66 486 471 66 489 minecraft:red_terracotta
setblock 471 66 490 minecraft:terracotta
fill 471 66 491 471 69 491 minecraft:red_terracotta
setblock 471 66 495 minecraft:terracotta
fill 471 66 496 471 69 496 minecraft:red_terracotta
setblock 471 66 500 minecraft:terracotta
fill 471 66 501 471 69 501 minecraft:red_terracotta
setblock 472 66 464 minecraft:terracotta
fill 472 66 465 472 68 465 minecraft:red_terracotta
setblock 472 66 469 minecraft:terracotta
fill 472 66 470 472 69 470 minecraft:red_terracotta
setblock 472 66 489 minecraft:terracotta
fill 472 66 490 472 69 490 minecraft:red_terracotta
setblock 472 66 494 minecraft:terracotta
fill 472 66 495 472 69 495 minecraft:red_terracotta
setblock 472 66 499 minecraft:terracotta
fill 472 66 500 472 69 500 minecraft:red_terracotta
setblock 472 66 504 minecraft:terracotta
fill 473 66 464 473 69 464 minecraft:red_terracotta
setblock 473 66 468 minecraft:terracotta
setblock 473 66 469 minecraft:red_terracotta
setblock 473 66 488 minecraft:terracotta
fill 473 66 489 473 67 489 minecraft:red_terracotta
setblock 473 66 493 minecraft:terracotta
fill 473 66 494 473 69 494 minecraft:red_terracotta
setblock 473 66 503 minecraft:terracotta
fill 473 66 504 476 66 504 minecraft:red_terracotta
setblock 474 66 503 minecraft:red_terracotta
setblock 476 66 465 minecraft:terracotta
setblock 477 66 464 minecraft:terracotta
setblock 477 66 504 minecraft:terracotta
setblock 478 66 504 minecraft:red_terracotta
setblock 487 66 464 minecraft:terracotta
fill 488 66 464 488 67 464 minecraft:red_terracotta
setblock 491 66 465 minecraft:terracotta
setblock 492 66 464 minecraft:terracotta
fill 492 66 465 492 67 465 minecraft:red_terracotta
setblock 492 66 504 minecraft:terracotta
fill 493 66 464 493 68 464 minecraft:red_terracotta
setblock 497 66 464 minecraft:terracotta
setblock 498 66 464 minecraft:red_terracotta
setblock 502 66 464 minecraft:terracotta
fill 503 66 464 503 67 464 minecraft:red_terracotta
setblock 506 66 465 minecraft:terracotta
fill 506 66 466 506 67 466 minecraft:red_terracotta
setblock 507 66 464 minecraft:terracotta
fill 507 66 465 507 69 465 minecraft:red_terracotta
fill 508 66 464 508 69 464 minecraft:red_terracotta
setblock 508 66 467 minecraft:red_terracotta
setblock 508 66 468 minecraft:terracotta
fill 508 66 469 508 68 469 minecraft:red_terracotta
fill 508 66 504 508 69 504 minecraft:red_terracotta
setblock 509 66 467 minecraft:terracotta
fill 509 66 468 509 69 468 minecraft:red_terracotta
setblock 509 66 471 minecraft:red_terracotta
setblock 509 66 472 minecraft:terracotta
fill 509 66 473 509 69 473 minecraft:red_terracotta
setblock 510 66 466 minecraft:terracotta
fill 510 66 467 510 69 467 minecraft:red_terracotta
setblock 510 66 471 minecraft:terracotta
fill 510 66 472 510 69 472 minecraft:red_terracotta
setblock 510 66 476 minecraft:terracotta
setblock 510 66 487 minecraft:red_terracotta
setblock 510 66 490 minecraft:red_terracotta
setblock 510 66 491 minecraft:terracotta
fill 510 66 492 510 69 492 minecraft:red_terracotta
fill 510 66 494 510 67 494 minecraft:red_terracotta
setblock 511 66 465 minecraft:terracotta
fill 511 66 466 511 69 466 minecraft:red_terracotta
setblock 511 66 470 minecraft:terracotta
fill 511 66 471 511 69 471 minecraft:red_terracotta
setblock 511 66 475 minecraft:terracotta
fill 511 66 476 511 69 476 minecraft:red_terracotta
setblock 511 66 480 minecraft:terracotta
setblock 511 66 481 minecraft:red_terracotta
setblock 511 66 485 minecraft:terracotta
fill 511 66 486 511 68 486 minecraft:red_terracotta
setblock 511 66 490 minecraft:terracotta
fill 511 66 491 511 69 491 minecraft:red_terracotta
setblock 511 66 495 minecraft:terracotta
fill 511 66 496 511 69 496 minecraft:red_terracotta
setblock 511 66 500 minecraft:terracotta
fill 511 66 501 511 69 501 minecraft:red_terracotta
setblock 471 67 464 minecraft:terracotta
fill 471 67 465 471 70 465 minecraft:red_terracotta
setblock 471 67 469 minecraft:terracotta
fill 471 67 470 471 70 470 minecraft:red_terracotta
setblock 471 67 474 minecraft:terracotta
fill 471 67 475 471 70 475 minecraft:red_terracotta
setblock 471 67 484 minecraft:terracotta
fill 471 67 485 471 67 488 minecraft:red_terracotta
setblock 471 67 489 minecraft:terracotta
fill 471 67 490 471 70 490 minecraft:red_terracotta
setblock 471 67 494 minecraft:terracotta
fill 471 67 495 471 70 495 minecraft:red_terracotta
setblock 471 67 499 minecraft:terracotta
fill 471 67 500 471 70 500 minecraft:red_terracotta
setblock 471 67 504 minecraft:terracotta
fill 472 67 464 472 70 464 minecraft:red_terracotta
setblock 472 67 468 minecraft:terracotta
fill 472 67 469 472 69 469 minecraft:red_terracotta
setblock 472 67 473 minecraft:terracotta
setblock 472 67 488 minecraft:terracotta
fill 472 67 489 472 70 489 minecraft:red_terracotta
setblock 472 67 493 minecraft:terracotta
fill 472 67 494 472 70 494 minecraft:red_terracotta
setblock 472 67 498 minecraft:terracotta
fill 472 67 499 472 70 499 minecraft:red_terracotta
setblock 472 67 503 minecraft:terracotta
fill 472 67 504 475 67 504 minecraft:red_terracotta
setblock 473 67 492 minecraft:terracotta
fill 473 67 493 473 70 493 minecraft:red_terracotta
setblock 473 67 503 minecraft:red_terracotta
setblock 476 67 464 minecraft:terracotta
setblock 476 67 504 minecraft:terracotta
setblock 491 67 464 minecraft:terracotta
fill 492 67 464 492 68 464 minecraft:red_terracotta
setblock 496 67 464 minecraft:terracotta
setblock 505 67 465 minecraft:terracotta
setblock 506 67 464 minecraft:terracotta
fill 506 67 465 506 70 465 minecraft:red_terracotta
fill 507 67 464 507 70 464 minecraft:red_terracotta
setblock 508 67 468 minecraft:red_terracotta
setblock 509 67 466 minecraft:terracotta
fill 509 67 467 509 70 467 minecraft:red_terracotta
setblock 509 67 471 minecraft:terracotta
fill 509 67 472 509 70 472 minecraft:red_terracotta
fill 509 67 474 509 68 474 minecraft:red_terracotta
setblock 510 67 465 minecraft:terracotta
fill 510 67 466 510 70 466 minecraft:red_terracotta
setblock 510 67 470 minecraft:terracotta
fill 510 67 471 510 70 471 minecraft:red_terracotta
setblock 510 67 475 minecraft:terracotta
fill 510 67 476 510 70 476 minecraft:red_terracotta
setblock 510 67 490 minecraft:terracotta
fill 510 67 491 510 70 491 minecraft:red_terracotta
setblock 510 67 495 minecraft:terracotta
setblock 511 67 464 minecraft:terracotta
fill 511 67 465 511 70 465 minecraft:red_terracotta
setblock 511 67 469 minecraft:terracotta
fill 511 67 470 511 70 470 minecraft:red_terracotta
setblock 511 67 474 minecraft:terracotta
fill 511 67 475 511 70 475 minecraft:red_terracotta
setblock 511 67 479 minecraft:terracotta
setblock 511 67 484 minecraft:terracotta
setblock 511 67 485 minecraft:red_terracotta
setblock 511 67 489 minecraft:terracotta
fill 511 67 490 511 70 490 minecraft:red_terracotta
setblock 511 67 494 minecraft:terracotta
fill 511 67 495 511 70 495 minecraft:red_terracotta
setblock 511 67 499 minecraft:terracotta
fill 511 67 500 511 70 500 minecraft:red_terracotta
setblock 511 67 504 minecraft:terracotta
fill 471 68 464 471 71 464 minecraft:red_terracotta
setblock 471 68 468 minecraft:terracotta
fill 471 68 469 471 71 469 minecraft:red_terracotta
setblock 471 68 473 minecraft:terracotta
fill 471 68 474 471 71 474 minecraft:red_terracotta
fill 471 68 485 471 68 487 minecraft:red_terracotta
setblock 471 68 488 minecraft:terracotta
fill 471 68 489 471 71 489 minecraft:red_terracotta
setblock 471 68 493 minecraft:terracotta
fill 471 68 494 471 71 494 minecraft:red_terracotta
setblock 471 68 498 minecraft:terracotta
fill 471 68 499 471 71 499 minecraft:red_terracotta
setblock 471 68 503 minecraft:terracotta
fill 471 68 504 474 68 504 minecraft:red_terracotta
setblock 472 68 467 minecraft:terracotta
fill 472 68 468 472 69 468 minecraft:red_terracotta
setblock 472 68 472 minecraft:terracotta
setblock 472 68 488 minecraft:red_terracotta
setblock 472 68 492 minecraft:terracotta
fill 472 68 493 472 71 493 minecraft:red_terracotta
setblock 472 68 497 minecraft:terracotta
fill 472 68 498 472 71 498 minecraft:red_terracotta
setblock 472 68 502 minecraft:terracotta
setblock 472 68 503 minecraft:red_terracotta
setblock 473 68 491 minecraft:terracotta
fill 473 68 492 473 70 492 minecraft:red_terracotta
setblock 473 68 496 minecraft:terracotta
setblock 475 68 504 minecraft:terracotta
setblock 490 68 464 minecraft:terracotta
setblock 491 68 464 minecraft:red_terracotta
setblock 505 68 464 minecraft:terracotta
setblock 505 68 465 minecraft:red_terracotta
fill 506 68 464 506 71 464 minecraft:red_terracotta
setblock 508 68 466 minecraft:terracotta
setblock 509 68 465 minecraft:terracotta
fill 509 68 466 509 71 466 minecraft:red_terracotta
setblock 509 68 470 minecraft:terracotta
fill 509 68 471 509 71 471 minecraft:red_terracotta
setblock 510 68 464 minecraft:terracotta
fill 510 68 465 510 71 465 minecraft:red_terracotta
setblock 510 68 469 minecraft:terracotta
fill 510 68 470 510 71 470 minecraft:red_terracotta
setblock 510 68 474 minecraft:terracotta
fill 510 68 475 510 71 475 minecraft:red_terracotta
setblock 510 68 490 minecraft:red_terracotta
setblock 510 68 494 minecraft:terracotta
fill 510 68 495 510 71 495 minecraft:red_terracotta
setblock 510 68 504 minecraft:terracotta
fill 511 68 464 511 71 464 minecraft:red_terracotta
setblock 511 68 468 minecraft:terracotta
fill 511 68 469 511 71 469 minecraft:red_terracotta
setblock 511 68 473 minecraft:terracotta
fill 511 68 474 511 71 474 minecraft:red_terracotta
setblock 511 68 478 minecraft:terracotta
setblock 511 68 488 minecraft:terracotta
fill 511 68 489 511 71 489 minecraft:red_terracotta
setblock 511 68 493 minecraft:terracotta
fill 511 68 494 511 71 494 minecraft:red_terracotta
setblock 511 68 498 minecraft:terracotta
fill 511 68 499 511 71 499 minecraft:red_terracotta
setblock 511 68 503 minecraft:terracotta
fill 511 68 504 511 71 504 minecraft:red_terracotta
setblock 471 69 467 minecraft:terracotta
fill 471 69 468 471 72 468 minecraft:red_terracotta
setblock 471 69 472 minecraft:terracotta
fill 471 69 473 471 72 473 minecraft:red_terracotta
setblock 471 69 486 minecraft:red_terracotta
setblock 471 69 487 minecraft:terracotta
fill 471 69 488 471 72 488 minecraft:red_terracotta
setblock 471 69 492 minecraft:terracotta
fill 471 69 493 471 72 493 minecraft:red_terracotta
setblock 471 69 497 minecraft:terracotta
fill 471 69 498 471 72 498 minecraft:red_terracotta
setblock 471 69 502 minecraft:terracotta
fill 471 69 503 471 71 504 minecraft:red_terracotta
setblock 472 69 466 minecraft:terracotta
setblock 472 69 467 minecraft:red_terracotta
setblock 472 69 471 minecraft:terracotta
setblock 472 69 472 minecraft:red_terracotta
setblock 472 69 491 minecraft:terracotta
fill 472 69 492 472 72 492 minecraft:red_terracotta
setblock 472 69 496 minecraft:terracotta
fill 472 69 497 472 72 497 minecraft:red_terracotta
setblock 472 69 501 minecraft:terracotta
fill 472 69 504 473 69 504 minecraft:red_terracotta
setblock 473 69 495 minecraft:terracotta
fill 473 69 496 473 72 496 minecraft:red_terracotta
setblock 474 69 504 minecraft:terracotta
fill 480 69 491 481 70 493 minecraft:orange_concrete
fill 483 69 495 483 70 495 minecraft:orange_concrete
setblock 504 69 464 minecraft:terracotta
fill 505 69 464 505 72 464 minecraft:red_terracotta
setblock 507 69 466 minecraft:terracotta
setblock 508 69 465 minecraft:terracotta
fill 508 69 466 508 71 466 minecraft:red_terracotta
setblock 509 69 464 minecraft:terracotta
fill 509 69 465 509 72 465 minecraft:red_terracotta
setblock 509 69 469 minecraft:terracotta
fill 509 69 470 509 72 470 minecraft:red_terracotta
setblock 509 69 474 minecraft:terracotta
setblock 509 69 504 minecraft:terracotta
fill 510 69 464 510 72 464 minecraft:red_terracotta
setblock 510 69 468 minecraft:terracotta
fill 510 69 469 510 72 469 minecraft:red_terracotta
setblock 510 69 473 minecraft:terracotta
fill 510 69 474 510 72 474 minecraft:red_terracotta
setblock 510 69 493 minecraft:terracotta
fill 510 69 494 510 72 494 minecraft:red_terracotta
fill 510 69 496 510 69 497 minecraft:red_terracotta
fill 510 69 504 510 72 504 minecraft:red_terracotta
setblock 511 69 467 minecraft:terracotta
fill 511 69 468 511 72 468 minecraft:red_terracotta
setblock 511 69 472 minecraft:terracotta
fill 511 69 473 511 72 473 minecraft:red_terracotta
setblock 511 69 477 minecraft:terracotta
fill 511 69 478 511 72 478 minecraft:red_terracotta
setblock 511 69 487 minecraft:terracotta
fill 511 69 488 511 70 488 minecraft:red_terracotta
setblock 511 69 492 minecraft:terracotta
fill 511 69 493 511 72 493 minecraft:red_terracotta
setblock 511 69 497 minecraft:terracotta
fill 511 69 498 511 72 498 minecraft:red_terracotta
setblock 511 69 502 minecraft:terracotta
fill 511 69 503 511 72 503 minecraft:red_terracotta
fill 470 70 463 470 70 477 minecraft:blackstone
setblock 470 70 478 minecraft:brown_terracotta
fill 470 70 479 470 70 488 minecraft:blackstone
setblock 470 70 489 minecraft:brown_terracotta
fill 470 70 490 470 70 498 minecraft:blackstone
setblock 470 70 499 minecraft:brown_terracotta
fill 470 70 500 470 70 505 minecraft:blackstone
fill 471 70 463 473 70 463 minecraft:blackstone
setblock 471 70 466 minecraft:terracotta
fill 471 70 467 471 73 467 minecraft:red_terracotta
setblock 471 70 471 minecraft:terracotta
fill 471 70 472 471 73 472 minecraft:red_terracotta
setblock 471 70 476 minecraft:terracotta
fill 471 70 487 471 73 487 minecraft:red_terracotta
setblock 471 70 491 minecraft:terracotta
fill 471 70 492 471 73 492 minecraft:red_terracotta
setblock 471 70 496 minecraft:terracotta
fill 471 70 497 471 73 497 minecraft:red_terracotta
setblock 471 70 501 minecraft:terracotta
fill 471 70 502 471 73 502 minecraft:red_terracotta
fill 471 70 505 471 71 505 minecraft:brown_terracotta
setblock 472 70 470 minecraft:terracotta
setblock 472 70 490 minecraft:terracotta
fill 472 70 491 472 73 491 minecraft:red_terracotta
setblock 472 70 495 minecraft:terracotta
fill 472 70 496 472 73 496 minecraft:red_terracotta
setblock 472 70 500 minecraft:terracotta
fill 472 70 501 472 73 501 minecraft:red_terracotta
setblock 472 70 504 minecraft:red_terracotta
fill 472 70 505 491 70 505 minecraft:blackstone
setblock 473 70 466 minecraft:light[level=14]
setblock 473 70 474 minecraft:light[level=14]
setblock 473 70 482 minecraft:light[level=14]
setblock 473 70 490 minecraft:light[level=14]
setblock 473 70 494 minecraft:terracotta
fill 473 70 495 473 73 495 minecraft:red_terracotta
setblock 473 70 498 minecraft:light[level=14]
setblock 473 70 504 minecraft:terracotta
setblock 474 70 463 minecraft:brown_terracotta
fill 475 70 463 484 71 463 minecraft:blackstone
setblock 481 70 466 minecraft:light[level=14]
setblock 481 70 474 minecraft:light[level=14]
setblock 481 70 482 minecraft:light[level=14]
setblock 481 70 490 minecraft:light[level=14]
setblock 481 70 498 minecraft:light[level=14]
setblock 485 70 463 minecraft:brown_terracotta
fill 486 70 463 495 70 463 minecraft:blackstone
setblock 489 70 466 minecraft:light[level=14]
setblock 489 70 474 minecraft:light[level=14]
setblock 489 70 482 minecraft:light[level=14]
setblock 489 70 490 minecraft:light[level=14]
setblock 489 70 498 minecraft:light[level=14]
setblock 492 70 505 minecraft:brown_terracotta
fill 493 70 505 512 70 505 minecraft:blackstone
setblock 496 70 463 minecraft:brown_terracotta
fill 497 70 463 510 70 463 minecraft:blackstone
setblock 497 70 466 minecraft:light[level=14]
setblock 497 70 474 minecraft:light[level=14]
setblock 497 70 490 minecraft:light[level=14]
setblock 497 70 498 minecraft:light[level=14]
fill 504 70 464 504 73 464 minecraft:red_terracotta
setblock 505 70 466 minecraft:light[level=14]
setblock 505 70 474 minecraft:light[level=14]
setblock 505 70 482 minecraft:light[level=14]
setblock 505 70 490 minecraft:light[level=14]
setblock 505 70 498 minecraft:light[level=14]
setblock 507 70 465 minecraft:terracotta
setblock 508 70 464 minecraft:terracotta
fill 508 70 465 508 73 465 minecraft:red_terracotta
setblock 508 70 504 minecraft:terracotta
fill 509 70 464 509 73 464 minecraft:red_terracotta
setblock 509 70 468 minecraft:terracotta
fill 509 70 469 509 73 469 minecraft:red_terracotta
setblock 509 70 473 minecraft:terracotta
fill 509 70 474 509 73 474 minecraft:red_terracotta
fill 509 70 504 509 73 504 minecraft:red_terracotta
setblock 510 70 467 minecraft:terracotta
fill 510 70 468 510 73 468 minecraft:red_terracotta
setblock 510 70 472 minecraft:terracotta
fill 510 70 473 510 73 473 minecraft:red_terracotta
setblock 510 70 492 minecraft:terracotta
fill 510 70 493 510 73 493 minecraft:red_terracotta
setblock 510 70 496 minecraft:red_terracotta
setblock 510 70 497 minecraft:terracotta
fill 510 70 498 510 73 498 minecraft:red_terracotta
setblock 511 70 463 minecraft:brown_terracotta
setblock 511 70 466 minecraft:terracotta
fill 511 70 467 511 73 467 minecraft:red_terracotta
setblock 511 70 471 minecraft:terracotta
fill 511 70 472 511 73 472 minecraft:red_terracotta
setblock 511 70 476 minecraft:terracotta
fill 511 70 477 511 73 477 minecraft:red_terracotta
setblock 511 70 491 minecraft:terracotta
fill 511 70 492 511 73 492 minecraft:red_terracotta
setblock 511 70 496 minecraft:terracotta
fill 511 70 497 511 73 497 minecraft:red_terracotta
setblock 511 70 501 minecraft:terracotta
fill 511 70 502 511 73 502 minecraft:red_terracotta
fill 512 70 463 512 71 463 minecraft:blackstone
setblock 512 70 464 minecraft:brown_terracotta
fill 512 70 465 512 73 466 minecraft:blackstone
setblock 512 70 467 minecraft:brown_terracotta
fill 512 70 468 512 70 471 minecraft:blackstone
fill 512 70 472 512 71 472 minecraft:brown_terracotta
fill 512 70 473 512 70 503 minecraft:blackstone
setblock 512 70 504 minecraft:brown_terracotta
setblock 470 71 463 minecraft:brown_terracotta
fill 470 71 464 470 71 470 minecraft:blackstone
fill 470 71 471 470 71 472 minecraft:brown_terracotta
fill 470 71 473 470 73 479 minecraft:blackstone
fill 470 71 480 470 71 481 minecraft:brown_terracotta
fill 470 71 482 470 71 491 minecraft:blackstone
fill 470 71 492 470 72 492 minecraft:brown_terracotta
fill 470 71 493 470 73 504 minecraft:blackstone
setblock 470 71 505 minecraft:brown_terracotta
setblock 471 71 463 minecraft:blackstone
setblock 471 71 465 minecraft:terracotta
fill 471 71 466 471 72 466 minecraft:red_terracotta
setblock 471 71 470 minecraft:terracotta
fill 471 71 471 471 74 471 minecraft:red_terracotta
setblock 471 71 475 minecraft:terracotta
fill 471 71 476 471 74 476 minecraft:red_terracotta
setblock 471 71 490 minecraft:terracotta
fill 471 71 491 471 74 491 minecraft:red_terracotta
setblock 471 71 495 minecraft:terracotta
fill 471 71 496 471 74 496 minecraft:red_terracotta
setblock 471 71 500 minecraft:terracotta
fill 471 71 501 471 74 501 minecraft:red_terracotta
setblock 472 71 463 minecraft:brown_terracotta
fill 472 71 490 472 74 490 minecraft:red_terracotta
setblock 472 71 494 minecraft:terracotta
fill 472 71 495 472 74 495 minecraft:red_terracotta
setblock 472 71 499 minecraft:terracotta
fill 472 71 500 472 74 500 minecraft:red_terracotta
setblock 472 71 504 minecraft:terracotta
fill 472 71 505 475 71 505 minecraft:blackstone
fill 473 71 463 474 73 463 minecraft:blackstone
setblock 473 71 493 minecraft:terracotta
fill 473 71 494 473 74 494 minecraft:red_terracotta
setblock 473 71 497 minecraft:red_terracotta
fill 473 71 504 473 74 504 minecraft:red_terracotta
setblock 476 71 505 minecraft:brown_terracotta
fill 477 71 505 479 73 505 minecraft:blackstone
setblock 480 71 505 minecraft:brown_terracotta
fill 481 71 505 482 73 505 minecraft:blackstone
setblock 483 71 505 minecraft:brown_terracotta
fill 484 71 505 505 71 505 minecraft:blackstone
fill 485 71 463 487 71 463 minecraft:blackstone
setblock 488 71 463 minecraft:brown_terracotta
fill 489 71 463 492 73 463 minecraft:blackstone
setblock 493 71 463 minecraft:brown_terracotta
fill 494 71 463 498 71 463 minecraft:blackstone
setblock 499 71 463 minecraft:brown_terracotta
fill 500 71 463 507 73 463 minecraft:blackstone
setblock 505 71 465 minecraft:red_terracotta
setblock 506 71 465 minecraft:terracotta
setblock 506 71 505 minecraft:brown_terracotta
setblock 507 71 464 minecraft:terracotta
fill 507 71 465 507 74 465 minecraft:red_terracotta
setblock 507 71 504 minecraft:terracotta
fill 507 71 505 512 73 505 minecraft:blackstone
setblock 508 71 463 minecraft:brown_terracotta
fill 508 71 464 508 74 464 minecraft:red_terracotta
fill 508 71 504 508 74 504 minecraft:red_terracotta
fill 509 71 463 509 73 463 minecraft:blackstone
setblock 509 71 467 minecraft:terracotta
fill 509 71 468 509 74 468 minecraft:red_terracotta
setblock 509 71 472 minecraft:terracotta
fill 509 71 473 509 74 473 minecraft:red_terracotta
fill 509 71 475 509 72 475 minecraft:red_terracotta
setblock 510 71 463 minecraft:brown_terracotta
setblock 510 71 466 minecraft:terracotta
fill 510 71 467 510 74 467 minecraft:red_terracotta
setblock 510 71 471 minecraft:terracotta
fill 510 71 472 510 74 472 minecraft:red_terracotta
setblock 510 71 476 minecraft:terracotta
setblock 510 71 491 minecraft:terracotta
fill 510 71 492 510 74 492 minecraft:red_terracotta
setblock 510 71 496 minecraft:terracotta
fill 510 71 497 510 74 497 minecraft:red_terracotta
fill 510 71 499 510 71 500 minecraft:red_terracotta
fill 511 71 463 511 74 463 minecraft:blackstone
setblock 511 71 465 minecraft:terracotta
fill 511 71 466 511 74 466 minecraft:red_terracotta
setblock 511 71 470 minecraft:terracotta
fill 511 71 471 511 74 471 minecraft:red_terracotta
setblock 511 71 475 minecraft:terracotta
fill 511 71 476 511 74 476 minecraft:red_terracotta
setblock 511 71 490 minecraft:terracotta
fill 511 71 491 511 74 491 minecraft:red_terracotta
setblock 511 71 495 minecraft:terracotta
fill 511 71 496 511 74 496 minecraft:red_terracotta
setblock 511 71 500 minecraft:terracotta
fill 511 71 501 511 74 501 minecraft:red_terracotta
fill 512 71 464 512 73 464 minecraft:blackstone
fill 512 71 467 512 73 469 minecraft:blackstone
setblock 512 71 470 minecraft:brown_terracotta
setblock 512 71 471 minecraft:blackstone
setblock 512 71 473 minecraft:brown_terracotta
fill 512 71 474 512 73 474 minecraft:blackstone
setblock 512 71 475 minecraft:brown_terracotta
fill 512 71 476 512 73 477 minecraft:blackstone
setblock 512 71 478 minecraft:brown_terracotta
fill 512 71 479 512 73 480 minecraft:blackstone
setblock 512 71 481 minecraft:brown_terracotta
fill 512 71 482 512 73 486 minecraft:blackstone
fill 512 71 487 512 72 487 minecraft:brown_terracotta
fill 512 71 488 512 71 497 minecraft:blackstone
setblock 512 71 498 minecraft:brown_terracotta
fill 512 71 499 512 71 504 minecraft:blackstone
fill 470 72 463 470 75 463 minecraft:blackstone
setblock 470 72 464 minecraft:brown_terracotta
fill 470 72 465 470 73 472 minecraft:blackstone
fill 470 72 480 470 73 483 minecraft:blackstone
setblock 470 72 484 minecraft:brown_terracotta
fill 470 72 485 470 73 491 minecraft:blackstone
fill 470 72 505 474 73 505 minecraft:blackstone
setblock 471 72 463 minecraft:brown_terracotta
setblock 471 72 464 minecraft:terracotta
setblock 471 72 465 minecraft:red_terracotta
setblock 471 72 469 minecraft:terracotta
fill 471 72 470 471 75 470 minecraft:red_terracotta
setblock 471 72 474 minecraft:terracotta
fill 471 72 475 471 75 475 minecraft:red_terracotta
fill 471 72 477 471 73 477 minecraft:red_terracotta
setblock 471 72 489 minecraft:terracotta
fill 471 72 490 471 75 490 minecraft:red_terracotta
setblock 471 72 494 minecraft:terracotta
fill 471 72 495 471 75 495 minecraft:red_terracotta
setblock 471 72 499 minecraft:terracotta
fill 471 72 500 471 75 500 minecraft:red_terracotta
setblock 471 72 503 minecraft:red_terracotta
setblock 471 72 504 minecraft:terracotta
fill 472 72 463 472 73 463 minecraft:blackstone
setblock 472 72 493 minecraft:terracotta
fill 472 72 494 472 75 494 minecraft:red_terracotta
setblock 472 72 498 minecraft:terracotta
fill 472 72 499 472 75 499 minecraft:red_terracotta
setblock 472 72 502 minecraft:red_terracotta
fill 472 72 504 472 75 504 minecraft:red_terracotta
fill 473 72 493 473 74 493 minecraft:red_terracotta
setblock 473 72 497 minecraft:terracotta
fill 475 72 463 475 73 463 minecraft:blackstone
setblock 475 72 505 minecraft:brown_terracotta
fill 476 72 463 477 72 463 minecraft:brown_terracotta
fill 476 72 505 476 73 505 minecraft:blackstone
fill 478 72 463 481 73 463 minecraft:blackstone
fill 480 72 505 480 73 505 minecraft:blackstone
setblock 482 72 463 minecraft:brown_terracotta
fill 483 72 463 486 73 463 minecraft:blackstone
fill 483 72 505 494 73 505 minecraft:blackstone
setblock 487 72 463 minecraft:brown_terracotta
fill 488 72 463 488 73 463 minecraft:blackstone
fill 493 72 463 494 73 463 minecraft:blackstone
setblock 495 72 463 minecraft:brown_terracotta
setblock 495 72 505 minecraft:brown_terracotta
fill 496 72 463 499 73 463 minecraft:blackstone
fill 496 72 505 503 73 505 minecraft:blackstone
fill 503 72 464 503 74 464 minecraft:red_terracotta
setblock 504 72 505 minecraft:brown_terracotta
setblock 505 72 465 minecraft:terracotta
fill 505 72 505 506 73 505 minecraft:blackstone
setblock 506 72 464 minecraft:terracotta
fill 506 72 465 506 75 465 minecraft:red_terracotta
setblock 506 72 504 minecraft:terracotta
fill 507 72 464 507 75 464 minecraft:red_terracotta
fill 507 72 504 507 75 504 minecraft:red_terracotta
fill 508 72 463 508 73 463 minecraft:blackstone
fill 509 72 467 509 73 467 minecraft:red_terracotta
setblock 509 72 471 minecraft:terracotta
fill 509 72 472 509 75 472 minecraft:red_terracotta
fill 509 72 503 510 73 503 minecraft:red_terracotta
fill 510 72 463 510 73 463 minecraft:blackstone
setblock 510 72 465 minecraft:terracotta
fill 510 72 466 510 75 466 minecraft:red_terracotta
setblock 510 72 470 minecraft:terracotta
fill 510 72 471 510 75 471 minecraft:red_terracotta
setblock 510 72 475 minecraft:terracotta
fill 510 72 476 510 74 477 minecraft:red_terracotta
setblock 510 72 495 minecraft:terracotta
fill 510 72 496 510 75 496 minecraft:red_terracotta
setblock 510 72 499 minecraft:red_terracotta
setblock 510 72 500 minecraft:terracotta
fill 510 72 501 510 74 502 minecraft:red_terracotta
setblock 511 72 464 minecraft:terracotta
fill 511 72 465 511 75 465 minecraft:red_terracotta
setblock 511 72 469 minecraft:terracotta
fill 511 72 470 511 75 470 minecraft:red_terracotta
setblock 511 72 474 minecraft:terracotta
fill 511 72 475 511 75 475 minecraft:red_terracotta
setblock 511 72 479 minecraft:terracotta
setblock 511 72 489 minecraft:terracotta
fill 511 72 490 511 75 490 minecraft:red_terracotta
setblock 511 72 494 minecraft:terracotta
fill 511 72 495 511 75 495 minecraft:red_terracotta
setblock 511 72 499 minecraft:terracotta
fill 511 72 500 511 75 500 minecraft:red_terracotta
setblock 511 72 504 minecraft:terracotta
setblock 512 72 463 minecraft:brown_terracotta
fill 512 72 470 512 73 470 minecraft:blackstone
setblock 512 72 471 minecraft:brown_terracotta
fill 512 72 472 512 73 473 minecraft:blackstone
fill 512 72 475 512 73 475 minecraft:blackstone
fill 512 72 478 512 74 478 minecraft:blackstone
fill 512 72 481 512 73 481 minecraft:blackstone
fill 512 72 488 512 73 496 minecraft:blackstone
setblock 512 72 497 minecraft:brown_terracotta
fill 512 72 498 512 73 499 minecraft:blackstone
setblock 512 72 500 minecraft:brown_terracotta
fill 512 72 501 512 73 502 minecraft:blackstone
setblock 512 72 503 minecraft:brown_terracotta
fill 512 72 504 512 73 504 minecraft:blackstone
setblock 470 73 464 minecraft:blackstone
setblock 470 73 484 minecraft:blackstone
setblock 470 73 492 minecraft:blackstone
setblock 471 73 463 minecraft:blackstone
setblock 471 73 468 minecraft:terracotta
fill 471 73 469 471 75 469 minecraft:red_terracotta
setblock 471 73 473 minecraft:terracotta
fill 471 73 474 471 76 474 minecraft:red_terracotta
setblock 471 73 478 minecraft:terracotta
setblock 471 73 488 minecraft:terracotta
fill 471 73 489 471 76 489 minecraft:red_terracotta
setblock 471 73 493 minecraft:terracotta
fill 471 73 494 471 76 494 minecraft:red_terracotta
setblock 471 73 498 minecraft:terracotta
fill 471 73 499 471 76 499 minecraft:red_terracotta
setblock 471 73 503 minecraft:terracotta
fill 471 73 504 471 76 504 minecraft:red_terracotta
setblock 472 73 492 minecraft:terracotta
fill 472 73 493 472 76 493 minecraft:red_terracotta
setblock 472 73 497 minecraft:terracotta
fill 472 73 498 473 75 498 minecraft:red_terracotta
setblock 472 73 502 minecraft:terracotta
setblock 473 73 496 minecraft:terracotta
fill 473 73 497 473 76 497 minecraft:red_terracotta
setblock 475 73 505 minecraft:blackstone
fill 476 73 463 477 73 463 minecraft:blackstone
setblock 482 73 463 minecraft:blackstone
setblock 487 73 463 minecraft:blackstone
setblock 495 73 463 minecraft:blackstone
setblock 495 73 505 minecraft:blackstone
fill 502 73 464 502 75 464 minecraft:red_terracotta
setblock 504 73 465 minecraft:terracotta
setblock 504 73 504 minecraft:red_terracotta
setblock 504 73 505 minecraft:blackstone
setblock 505 73 464 minecraft:terracotta
fill 505 73 465 505 76 465 minecraft:red_terracotta
setblock 505 73 504 minecraft:terracotta
fill 506 73 464 506 76 464 minecraft:red_terracotta
setblock 506 73 503 minecraft:terracotta
fill 506 73 504 506 76 504 minecraft:red_terracotta
fill 507 73 503 508 75 503 minecraft:red_terracotta
setblock 508 73 472 minecraft:red_terracotta
setblock 509 73 465 minecraft:terracotta
setblock 509 73 470 minecraft:terracotta
fill 509 73 471 509 76 471 minecraft:red_terracotta
setblock 509 73 475 minecraft:terracotta
fill 509 73 476 509 76 476 minecraft:red_terracotta
setblock 509 73 494 minecraft:red_terracotta
setblock 509 73 495 minecraft:terracotta
fill 509 73 496 509 73 499 minecraft:red_terracotta
setblock 509 73 500 minecraft:terracotta
setblock 510 73 464 minecraft:terracotta
fill 510 73 465 510 76 465 minecraft:red_terracotta
setblock 510 73 469 minecraft:terracotta
fill 510 73 470 510 76 470 minecraft:red_terracotta
setblock 510 73 474 minecraft:terracotta
fill 510 73 475 510 76 475 minecraft:red_terracotta
setblock 510 73 478 minecraft:red_terracotta
setblock 510 73 494 minecraft:terracotta
fill 510 73 495 510 76 495 minecraft:red_terracotta
setblock 510 73 499 minecraft:terracotta
fill 510 73 500 510 76 500 minecraft:red_terracotta
setblock 510 73 504 minecraft:terracotta
fill 511 73 464 511 76 464 minecraft:red_terracotta
setblock 511 73 468 minecraft:terracotta
fill 511 73 469 511 76 469 minecraft:red_terracotta
setblock 511 73 473 minecraft:terracotta
fill 511 73 474 511 76 474 minecraft:red_terracotta
setblock 511 73 478 minecraft:terracotta
fill 511 73 479 511 76 479 minecraft:red_terracotta
setblock 511 73 493 minecraft:terracotta
fill 511 73 494 511 76 494 minecraft:red_terracotta
setblock 511 73 498 minecraft:terracotta
fill 511 73 499 511 76 499 minecraft:red_terracotta
setblock 511 73 503 minecraft:terracotta
fill 511 73 504 511 76 504 minecraft:red_terracotta
setblock 512 73 463 minecraft:blackstone
setblock 512 73 471 minecraft:blackstone
fill 512 73 487 512 74 487 minecraft:blackstone
fill 512 73 497 512 74 497 minecraft:blackstone
setblock 512 73 500 minecraft:blackstone
setblock 512 73 503 minecraft:blackstone
fill 470 74 464 470 74 465 minecraft:brown_terracotta
setblock 470 74 466 minecraft:blackstone
fill 470 74 467 470 151 468 minecraft:brown_terracotta
setblock 470 74 469 minecraft:blackstone
fill 470 74 470 470 74 486 minecraft:brown_terracotta
setblock 470 74 487 minecraft:blackstone
fill 470 74 488 470 151 488 minecraft:brown_terracotta
setblock 470 74 489 minecraft:blackstone
fill 470 74 490 470 74 504 minecraft:brown_terracotta
fill 470 74 505 471 74 505 minecraft:blackstone
fill 471 74 463 479 74 463 minecraft:brown_terracotta
setblock 471 74 468 minecraft:red_terracotta
setblock 471 74 472 minecraft:terracotta
fill 471 74 473 471 77 473 minecraft:red_terracotta
setblock 471 74 477 minecraft:terracotta
fill 471 74 478 471 75 480 minecraft:red_terracotta
setblock 471 74 487 minecraft:terracotta
fill 471 74 488 471 77 488 minecraft:red_terracotta
setblock 471 74 492 minecraft:terracotta
fill 471 74 493 471 77 493 minecraft:red_terracotta
setblock 471 74 497 minecraft:terracotta
fill 471 74 498 471 77 498 minecraft:red_terracotta
setblock 471 74 502 minecraft:terracotta
fill 471 74 503 472 76 503 minecraft:red_terracotta
setblock 472 74 491 minecraft:terracotta
fill 472 74 492 472 77 492 minecraft:red_terracotta
setblock 472 74 496 minecraft:terracotta
fill 472 74 497 472 77 497 minecraft:red_terracotta
setblock 472 74 501 minecraft:terracotta
fill 472 74 502 472 77 502 minecraft:red_terracotta
fill 472 74 505 478 74 505 minecraft:brown_terracotta
setblock 473 74 495 minecraft:terracotta
fill 473 74 496 473 77 496 minecraft:red_terracotta
setblock 473 74 499 minecraft:red_terracotta
fill 478 74 485 478 75 486 minecraft:orange_concrete
setblock 479 74 505 minecraft:blackstone
setblock 480 74 463 minecraft:blackstone
fill 480 74 505 483 74 505 minecraft:brown_terracotta
fill 481 74 463 484 147 463 minecraft:brown_terracotta
fill 484 74 505 484 75 505 minecraft:blackstone
setblock 485 74 463 minecraft:blackstone
fill 485 74 504 487 75 504 minecraft:red_terracotta
fill 485 74 505 493 75 505 minecraft:brown_terracotta
fill 486 74 463 505 75 463 minecraft:brown_terracotta
setblock 494 74 505 minecraft:blackstone
fill 495 74 505 497 149 505 minecraft:brown_terracotta
fill 498 74 505 499 74 505 minecraft:blackstone
fill 500 74 505 500 151 505 minecraft:brown_terracotta
fill 501 74 464 501 76 464 minecraft:red_terracotta
fill 501 74 505 502 74 505 minecraft:blackstone
setblock 503 74 465 minecraft:terracotta
setblock 503 74 504 minecraft:red_terracotta
fill 503 74 505 512 75 505 minecraft:brown_terracotta
setblock 504 74 464 minecraft:terracotta
fill 504 74 465 504 77 465 minecraft:red_terracotta
setblock 504 74 504 minecraft:terracotta
fill 505 74 464 505 77 464 minecraft:red_terracotta
setblock 505 74 503 minecraft:terracotta
fill 505 74 504 505 77 504 minecraft:red_terracotta
fill 506 74 463 506 75 463 minecraft:blackstone
setblock 506 74 466 minecraft:red_terracotta
fill 506 74 503 506 77 503 minecraft:red_terracotta
fill 507 74 463 510 149 463 minecraft:brown_terracotta
setblock 507 74 466 minecraft:terracotta
fill 507 74 502 509 75 502 minecraft:red_terracotta
setblock 508 74 465 minecraft:terracotta
setblock 508 74 473 minecraft:red_terracotta
setblock 509 74 464 minecraft:terracotta
fill 509 74 465 509 77 465 minecraft:red_terracotta
setblock 509 74 469 minecraft:terracotta
fill 509 74 470 509 75 470 minecraft:red_terracotta
setblock 509 74 474 minecraft:terracotta
fill 509 74 475 509 77 475 minecraft:red_terracotta
setblock 509 74 494 minecraft:terracotta
fill 509 74 495 509 74 498 minecraft:red_terracotta
setblock 509 74 499 minecraft:terracotta
fill 509 74 500 509 76 501 minecraft:red_terracotta
setblock 509 74 503 minecraft:red_terracotta
setblock 509 74 504 minecraft:terracotta
fill 510 74 464 510 77 464 minecraft:red_terracotta
setblock 510 74 468 minecraft:terracotta
fill 510 74 469 510 76 469 minecraft:red_terracotta
setblock 510 74 473 minecraft:terracotta
fill 510 74 474 510 77 474 minecraft:red_terracotta
setblock 510 74 478 minecraft:terracotta
setblock 510 74 493 minecraft:terracotta
fill 510 74 494 510 77 494 minecraft:red_terracotta
setblock 510 74 498 minecraft:terracotta
fill 510 74 499 510 77 499 minecraft:red_terracotta
setblock 510 74 503 minecraft:terracotta
fill 510 74 504 510 77 504 minecraft:red_terracotta
setblock 511 74 467 minecraft:terracotta
fill 511 74 468 511 77 468 minecraft:red_terracotta
setblock 511 74 472 minecraft:terracotta
fill 511 74 473 511 77 473 minecraft:red_terracotta
setblock 511 74 477 minecraft:terracotta
fill 511 74 478 511 77 478 minecraft:red_terracotta
fill 511 74 480 511 75 480 minecraft:red_terracotta
setblock 511 74 492 minecraft:terracotta
fill 511 74 493 511 77 493 minecraft:red_terracotta
setblock 511 74 497 minecraft:terracotta
fill 511 74 498 511 77 498 minecraft:red_terracotta
setblock 511 74 502 minecraft:terracotta
fill 511 74 503 511 77 503 minecraft:red_terracotta
fill 512 74 463 512 75 467 minecraft:brown_terracotta
setblock 512 74 468 minecraft:blackstone
fill 512 74 469 512 75 477 minecraft:brown_terracotta
setblock 512 74 479 minecraft:blackstone
fill 512 74 480 512 75 486 minecraft:brown_terracotta
fill 512 74 488 512 151 488 minecraft:brown_terracotta
setblock 512 74 489 minecraft:blackstone
fill 512 74 490 512 74 496 minecraft:brown_terracotta
fill 512 74 498 512 75 504 minecraft:brown_terracotta
setblock 470 75 464 minecraft:brown_terracotta
setblock 470 75 465 minecraft:blackstone
fill 470 75 466 470 151 466 minecraft:brown_terracotta
fill 470 75 469 470 75 482 minecraft:brown_terracotta
setblock 470 75 483 minecraft:blackstone
fill 470 75 484 470 75 487 minecraft:brown_terracotta
fill 470 75 489 470 75 502 minecraft:brown_terracotta
fill 470 75 503 470 75 504 minecraft:blackstone
fill 470 75 505 472 151 505 minecraft:brown_terracotta
fill 471 75 463 472 151 463 minecraft:brown_terracotta
setblock 471 75 471 minecraft:terracotta
fill 471 75 472 471 77 472 minecraft:red_terracotta
setblock 471 75 476 minecraft:terracotta
fill 471 75 477 471 78 477 minecraft:red_terracotta
setblock 471 75 481 minecraft:terracotta
fill 471 75 487 471 77 487 minecraft:red_terracotta
setblock 471 75 491 minecraft:terracotta
fill 471 75 492 471 78 492 minecraft:red_terracotta
setblock 471 75 496 minecraft:terracotta
fill 471 75 497 471 78 497 minecraft:red_terracotta
setblock 471 75 501 minecraft:terracotta
fill 471 75 502 471 78 502 minecraft:red_terracotta
fill 472 75 491 472 76 491 minecraft:red_terracotta
setblock 472 75 495 minecraft:terracotta
fill 472 75 496 472 78 496 minecraft:red_terracotta
setblock 472 75 500 minecraft:terracotta
fill 472 75 501 472 78 501 minecraft:red_terracotta
setblock 473 75 463 minecraft:blackstone
setblock 473 75 494 minecraft:terracotta
fill 473 75 495 473 77 495 minecraft:red_terracotta
setblock 473 75 499 minecraft:terracotta
fill 473 75 500 473 78 500 minecraft:red_terracotta
setblock 473 75 504 minecraft:terracotta
setblock 473 75 505 minecraft:blackstone
fill 474 75 463 474 151 463 minecraft:brown_terracotta
fill 474 75 504 474 78 504 minecraft:red_terracotta
fill 474 75 505 479 147 505 minecraft:brown_terracotta
setblock 475 75 463 minecraft:blackstone
fill 476 75 463 480 75 463 minecraft:brown_terracotta
setblock 480 75 505 minecraft:blackstone
fill 481 75 505 483 75 505 minecraft:brown_terracotta
setblock 483 75 504 minecraft:terracotta
fill 484 75 504 484 78 504 minecraft:red_terracotta
fill 485 75 463 485 149 463 minecraft:brown_terracotta
fill 486 75 464 487 75 464 minecraft:red_terracotta
setblock 488 75 464 minecraft:terracotta
setblock 488 75 504 minecraft:terracotta
fill 489 75 464 489 78 464 minecraft:red_terracotta
fill 489 75 504 489 78 504 minecraft:red_terracotta
fill 494 75 505 494 147 505 minecraft:brown_terracotta
fill 498 75 505 499 149 505 minecraft:brown_terracotta
fill 500 75 464 500 77 464 minecraft:red_terracotta
fill 501 75 504 502 75 504 minecraft:red_terracotta
fill 501 75 505 502 148 505 minecraft:brown_terracotta
setblock 502 75 465 minecraft:terracotta
setblock 503 75 464 minecraft:terracotta
fill 503 75 465 503 78 465 minecraft:red_terracotta
setblock 503 75 503 minecraft:red_terracotta
setblock 503 75 504 minecraft:terracotta
fill 504 75 464 504 78 464 minecraft:red_terracotta
setblock 504 75 503 minecraft:terracotta
fill 504 75 504 504 78 504 minecraft:red_terracotta
setblock 505 75 466 minecraft:red_terracotta
setblock 505 75 502 minecraft:terracotta
fill 505 75 503 505 78 503 minecraft:red_terracotta
setblock 506 75 466 minecraft:terracotta
fill 506 75 502 506 78 502 minecraft:red_terracotta
setblock 507 75 465 minecraft:terracotta
fill 507 75 466 507 76 466 minecraft:red_terracotta
setblock 508 75 464 minecraft:terracotta
fill 508 75 465 508 78 465 minecraft:red_terracotta
setblock 508 75 498 minecraft:red_terracotta
setblock 508 75 499 minecraft:terracotta
setblock 508 75 504 minecraft:terracotta
fill 509 75 464 509 78 464 minecraft:red_terracotta
setblock 509 75 469 minecraft:red_terracotta
setblock 509 75 473 minecraft:terracotta
fill 509 75 474 509 77 474 minecraft:red_terracotta
setblock 509 75 477 minecraft:red_terracotta
fill 509 75 494 509 75 497 minecraft:red_terracotta
setblock 509 75 498 minecraft:terracotta
fill 509 75 499 509 78 499 minecraft:red_terracotta
setblock 509 75 503 minecraft:terracotta
fill 509 75 504 509 78 504 minecraft:red_terracotta
setblock 510 75 467 minecraft:terracotta
fill 510 75 468 510 76 468 minecraft:red_terracotta
setblock 510 75 472 minecraft:terracotta
fill 510 75 473 510 78 473 minecraft:red_terracotta
setblock 510 75 476 minecraft:red_terracotta
setblock 510 75 477 minecraft:terracotta
fill 510 75 478 510 77 479 minecraft:red_terracotta
setblock 510 75 492 minecraft:terracotta
fill 510 75 493 510 77 493 minecraft:red_terracotta
setblock 510 75 497 minecraft:terracotta
fill 510 75 498 510 78 498 minecraft:red_terracotta
setblock 510 75 501 minecraft:red_terracotta
setblock 510 75 502 minecraft:terracotta
fill 510 75 503 510 78 503 minecraft:red_terracotta
setblock 511 75 463 minecraft:brown_terracotta
setblock 511 75 466 minecraft:terracotta
fill 511 75 467 511 77 467 minecraft:red_terracotta
setblock 511 75 471 minecraft:terracotta
fill 511 75 472 511 78 472 minecraft:red_terracotta
setblock 511 75 476 minecraft:terracotta
fill 511 75 477 511 78 477 minecraft:red_terracotta
setblock 511 75 491 minecraft:terracotta
fill 511 75 492 511 78 492 minecraft:red_terracotta
setblock 511 75 496 minecraft:terracotta
fill 511 75 497 511 78 497 minecraft:red_terracotta
setblock 511 75 501 minecraft:terracotta
fill 511 75 502 511 78 502 minecraft:red_terracotta
fill 512 75 468 512 147 468 minecraft:brown_terracotta
fill 512 75 478 512 151 479 minecraft:brown_terracotta
fill 512 75 487 512 151 487 minecraft:brown_terracotta
fill 512 75 489 512 148 489 minecraft:brown_terracotta
setblock 512 75 490 minecraft:blackstone
fill 512 75 491 512 148 497 minecraft:brown_terracotta
fill 470 76 463 470 151 463 minecraft:brown_terracotta
setblock 470 76 464 minecraft:blackstone
fill 470 76 465 470 151 465 minecraft:brown_terracotta
fill 470 76 469 470 148 477 minecraft:brown_terracotta
setblock 470 76 478 minecraft:blackstone
fill 470 76 479 470 148 486 minecraft:brown_terracotta
setblock 470 76 487 minecraft:blackstone
fill 470 76 489 470 147 499 minecraft:brown_terracotta
setblock 470 76 500 minecraft:blackstone
fill 470 76 501 470 147 504 minecraft:brown_terracotta
setblock 471 76 471 minecraft:red_terracotta
setblock 471 76 475 minecraft:terracotta
fill 471 76 476 471 79 476 minecraft:red_terracotta
fill 471 76 478 471 76 479 minecraft:red_terracotta
setblock 471 76 480 minecraft:terracotta
fill 471 76 481 471 77 483 minecraft:red_terracotta
setblock 471 76 490 minecraft:terracotta
fill 471 76 491 471 79 491 minecraft:red_terracotta
setblock 471 76 495 minecraft:terracotta
fill 471 76 496 471 79 496 minecraft:red_terracotta
setblock 471 76 500 minecraft:terracotta
fill 471 76 501 471 79 501 minecraft:red_terracotta
setblock 472 76 494 minecraft:terracotta
fill 472 76 495 472 79 495 minecraft:red_terracotta
setblock 472 76 498 minecraft:red_terracotta
setblock 472 76 499 minecraft:terracotta
fill 472 76 500 472 79 500 minecraft:red_terracotta
setblock 472 76 504 minecraft:terracotta
fill 473 76 463 473 148 463 minecraft:brown_terracotta
setblock 473 76 494 minecraft:red_terracotta
setblock 473 76 498 minecraft:terracotta
fill 473 76 499 473 78 499 minecraft:red_terracotta
fill 473 76 504 473 79 504 minecraft:red_terracotta
fill 473 76 505 473 149 505 minecraft:brown_terracotta
fill 475 76 463 475 151 463 minecraft:brown_terracotta
setblock 476 76 463 minecraft:blackstone
fill 477 76 463 477 151 463 minecraft:brown_terracotta
setblock 478 76 463 minecraft:blackstone
fill 479 76 463 479 152 463 minecraft:brown_terracotta
setblock 480 76 463 minecraft:blackstone
fill 480 76 504 481 76 504 minecraft:red_terracotta
fill 480 76 505 480 151 505 minecraft:brown_terracotta
setblock 481 76 505 minecraft:blackstone
setblock 482 76 504 minecraft:terracotta
fill 482 76 505 484 147 505 minecraft:brown_terracotta
setblock 483 76 503 minecraft:terracotta
fill 483 76 504 483 79 504 minecraft:red_terracotta
fill 484 76 503 487 76 503 minecraft:red_terracotta
fill 485 76 464 486 76 464 minecraft:red_terracotta
fill 485 76 504 486 76 504 minecraft:red_terracotta
setblock 485 76 505 minecraft:blackstone
fill 486 76 463 497 147 463 minecraft:brown_terracotta
fill 486 76 505 491 147 505 minecraft:brown_terracotta
setblock 487 76 464 minecraft:terracotta
setblock 487 76 504 minecraft:terracotta
fill 488 76 464 488 79 464 minecraft:red_terracotta
fill 488 76 504 488 79 504 minecraft:red_terracotta
fill 490 76 464 490 77 464 minecraft:red_terracotta
setblock 492 76 505 minecraft:blackstone
fill 493 76 505 493 151 505 minecraft:brown_terracotta
setblock 498 76 463 minecraft:blackstone
fill 499 76 463 506 147 463 minecraft:brown_terracotta
fill 499 76 464 499 78 464 minecraft:red_terracotta
fill 500 76 491 500 77 491 minecraft:orange_concrete
fill 500 76 504 501 76 504 minecraft:red_terracotta
setblock 502 76 464 minecraft:terracotta
fill 502 76 465 502 79 465 minecraft:red_terracotta
setblock 502 76 503 minecraft:red_terracotta
setblock 502 76 504 minecraft:terracotta
fill 503 76 464 503 79 464 minecraft:red_terracotta
setblock 503 76 503 minecraft:terracotta
fill 503 76 504 503 79 504 minecraft:red_terracotta
fill 503 76 505 506 151 505 minecraft:brown_terracotta
setblock 504 76 502 minecraft:terracotta
fill 504 76 503 504 79 503 minecraft:red_terracotta
setblock 505 76 466 minecraft:terracotta
fill 505 76 502 505 79 502 minecraft:red_terracotta
setblock 506 76 465 minecraft:terracotta
fill 506 76 466 506 77 466 minecraft:red_terracotta
fill 506 76 501 508 77 501 minecraft:red_terracotta
setblock 507 76 464 minecraft:terracotta
fill 507 76 465 507 79 465 minecraft:red_terracotta
fill 507 76 502 507 76 503 minecraft:red_terracotta
setblock 507 76 504 minecraft:terracotta
setblock 507 76 505 minecraft:blackstone
fill 508 76 464 508 79 464 minecraft:red_terracotta
setblock 508 76 497 minecraft:red_terracotta
setblock 508 76 498 minecraft:terracotta
fill 508 76 499 508 78 500 minecraft:red_terracotta
setblock 508 76 502 minecraft:red_terracotta
setblock 508 76 503 minecraft:terracotta
fill 508 76 504 508 79 504 minecraft:red_terracotta
fill 508 76 505 508 151 505 minecraft:brown_terracotta
setblock 509 76 472 minecraft:terracotta
fill 509 76 473 509 77 473 minecraft:red_terracotta
setblock 509 76 477 minecraft:terracotta
fill 509 76 494 509 76 496 minecraft:red_terracotta
setblock 509 76 497 minecraft:terracotta
fill 509 76 498 509 79 498 minecraft:red_terracotta
setblock 509 76 502 minecraft:terracotta
fill 509 76 503 509 79 503 minecraft:red_terracotta
setblock 509 76 505 minecraft:blackstone
setblock 510 76 466 minecraft:terracotta
setblock 510 76 467 minecraft:red_terracotta
setblock 510 76 471 minecraft:terracotta
fill 510 76 472 510 77 472 minecraft:red_terracotta
setblock 510 76 476 minecraft:terracotta
fill 510 76 477 510 78 477 minecraft:red_terracotta
setblock 510 76 492 minecraft:red_terracotta
setblock 510 76 496 minecraft:terracotta
fill 510 76 497 510 79 497 minecraft:red_terracotta
setblock 510 76 501 minecraft:terracotta
fill 510 76 502 510 79 502 minecraft:red_terracotta
fill 510 76 505 511 151 505 minecraft:brown_terracotta
fill 511 76 463 512 76 463 minecraft:blackstone
setblock 511 76 465 minecraft:terracotta
fill 511 76 466 511 78 466 minecraft:red_terracotta
setblock 511 76 470 minecraft:terracotta
fill 511 76 471 511 78 471 minecraft:red_terracotta
setblock 511 76 475 minecraft:terracotta
fill 511 76 476 511 79 476 minecraft:red_terracotta
setblock 511 76 480 minecraft:terracotta
fill 511 76 481 511 79 481 minecraft:red_terracotta
setblock 511 76 490 minecraft:terracotta
fill 511 76 491 511 77 491 minecraft:red_terracotta
setblock 511 76 495 minecraft:terracotta
fill 511 76 496 511 79 496 minecraft:red_terracotta
setblock 511 76 500 minecraft:terracotta
fill 511 76 501 511 79 501 minecraft:red_terracotta
fill 512 76 464 512 147 464 minecraft:brown_terracotta
setblock 512 76 465 minecraft:blackstone
fill 512 76 466 512 151 467 minecraft:brown_terracotta
fill 512 76 469 512 76 470 minecraft:blackstone
fill 512 76 471 512 149 477 minecraft:brown_terracotta
fill 512 76 480 512 148 483 minecraft:brown_terracotta
fill 512 76 484 512 76 485 minecraft:blackstone
fill 512 76 486 512 151 486 minecraft:brown_terracotta
fill 512 76 490 512 149 490 minecraft:brown_terracotta
fill 512 76 498 512 151 499 minecraft:brown_terracotta
setblock 512 76 500 minecraft:blackstone
fill 512 76 501 512 149 502 minecraft:brown_terracotta
setblock 512 76 503 minecraft:blackstone
fill 512 76 504 512 151 504 minecraft:brown_terracotta
setblock 512 76 505 minecraft:blackstone
fill 470 77 464 470 151 464 minecraft:brown_terracotta
fill 470 77 478 470 151 478 minecraft:brown_terracotta
fill 470 77 487 470 151 487 minecraft:brown_terracotta
fill 470 77 500 470 148 500 minecraft:brown_terracotta
setblock 471 77 474 minecraft:terracotta
fill 471 77 475 471 79 475 minecraft:red_terracotta
setblock 471 77 478 minecraft:red_terracotta
setblock 471 77 479 minecraft:terracotta
fill 471 77 480 471 80 480 minecraft:red_terracotta
setblock 471 77 484 minecraft:terracotta
fill 471 77 485 471 77 486 minecraft:red_terracotta
setblock 471 77 489 minecraft:terracotta
fill 471 77 490 471 79 490 minecraft:red_terracotta
setblock 471 77 494 minecraft:terracotta
fill 471 77 495 471 80 495 minecraft:red_terracotta
setblock 471 77 499 minecraft:terracotta
fill 471 77 500 471 80 500 minecraft:red_terracotta
setblock 471 77 503 minecraft:red_terracotta
setblock 471 77 504 minecraft:terracotta
setblock 472 77 493 minecraft:terracotta
fill 472 77 494 472 79 494 minecraft:red_terracotta
setblock 472 77 498 minecraft:terracotta
fill 472 77 499 472 80 499 minecraft:red_terracotta
setblock 472 77 503 minecraft:terracotta
fill 472 77 504 472 80 504 minecraft:red_terracotta
setblock 473 77 497 minecraft:terracotta
fill 473 77 498 473 78 498 minecraft:red_terracotta
fill 473 77 503 473 78 503 minecraft:red_terracotta
setblock 475 77 504 minecraft:red_terracotta
fill 476 77 463 476 149 463 minecraft:brown_terracotta
fill 478 77 463 478 147 463 minecraft:brown_terracotta
fill 478 77 504 480 77 504 minecraft:red_terracotta
fill 480 77 463 480 152 463 minecraft:brown_terracotta
setblock 481 77 503 minecraft:red_terracotta
setblock 481 77 504 minecraft:terracotta
fill 481 77 505 481 151 505 minecraft:brown_terracotta
setblock 482 77 503 minecraft:terracotta
fill 482 77 504 482 80 504 minecraft:red_terracotta
fill 483 77 503 486 77 503 minecraft:red_terracotta
fill 484 77 464 485 77 464 minecraft:red_terracotta
setblock 485 77 504 minecraft:red_terracotta
fill 485 77 505 485 151 505 minecraft:brown_terracotta
setblock 486 77 464 minecraft:terracotta
setblock 486 77 504 minecraft:terracotta
fill 487 77 464 487 80 464 minecraft:red_terracotta
setblock 487 77 503 minecraft:terracotta
fill 487 77 504 487 80 504 minecraft:red_terracotta
fill 488 77 503 488 78 503 minecraft:red_terracotta
setblock 490 77 504 minecraft:red_terracotta
fill 492 77 505 492 149 505 minecraft:brown_terracotta
fill 498 77 463 498 147 463 minecraft:brown_terracotta
fill 498 77 464 498 79 464 minecraft:red_terracotta
fill 499 77 504 500 77 504 minecraft:red_terracotta
setblock 501 77 464 minecraft:terracotta
fill 501 77 465 501 80 465 minecraft:red_terracotta
setblock 501 77 503 minecraft:red_terracotta
setblock 501 77 504 minecraft:terracotta
fill 502 77 464 502 80 464 minecraft:red_terracotta
setblock 502 77 502 minecraft:red_terracotta
setblock 502 77 503 minecraft:terracotta
fill 502 77 504 502 80 504 minecraft:red_terracotta
setblock 503 77 502 minecraft:terracotta
fill 503 77 503 503 80 503 minecraft:red_terracotta
setblock 504 77 466 minecraft:terracotta
fill 504 77 502 504 80 502 minecraft:red_terracotta
setblock 505 77 465 minecraft:terracotta
fill 505 77 466 505 78 466 minecraft:red_terracotta
fill 505 77 501 505 80 501 minecraft:red_terracotta
setblock 506 77 464 minecraft:terracotta
fill 506 77 465 506 80 465 minecraft:red_terracotta
setblock 506 77 504 minecraft:terracotta
fill 507 77 464 507 80 464 minecraft:red_terracotta
setblock 507 77 502 minecraft:red_terracotta
setblock 507 77 503 minecraft:terracotta
fill 507 77 504 507 80 504 minecraft:red_terracotta
fill 507 77 505 507 151 505 minecraft:brown_terracotta
setblock 508 77 497 minecraft:terracotta
fill 508 77 498 508 78 498 minecraft:red_terracotta
setblock 508 77 502 minecraft:terracotta
fill 508 77 503 508 80 503 minecraft:red_terracotta
setblock 509 77 476 minecraft:terracotta
setblock 509 77 477 minecraft:red_terracotta
setblock 509 77 495 minecraft:red_terracotta
setblock 509 77 496 minecraft:terracotta
fill 509 77 497 509 79 497 minecraft:red_terracotta
setblock 509 77 500 minecraft:red_terracotta
setblock 509 77 501 minecraft:terracotta
fill 509 77 502 509 80 502 minecraft:red_terracotta
fill 509 77 505 509 148 505 minecraft:brown_terracotta
setblock 510 77 465 minecraft:terracotta
setblock 510 77 470 minecraft:terracotta
setblock 510 77 471 minecraft:red_terracotta
setblock 510 77 475 minecraft:terracotta
fill 510 77 476 510 78 476 minecraft:red_terracotta
setblock 510 77 495 minecraft:terracotta
fill 510 77 496 510 80 496 minecraft:red_terracotta
setblock 510 77 500 minecraft:terracotta
fill 510 77 501 510 80 501 minecraft:red_terracotta
fill 511 77 463 512 149 463 minecraft:brown_terracotta
setblock 511 77 464 minecraft:terracotta
fill 511 77 465 511 78 465 minecraft:red_terracotta
setblock 511 77 469 minecraft:terracotta
fill 511 77 470 511 78 470 minecraft:red_terracotta
setblock 511 77 474 minecraft:terracotta
fill 511 77 475 511 79 475 minecraft:red_terracotta
setblock 511 77 479 minecraft:terracotta
fill 511 77 480 511 80 480 minecraft:red_terracotta
setblock 511 77 494 minecraft:terracotta
fill 511 77 495 511 80 495 minecraft:red_terracotta
setblock 511 77 499 minecraft:terracotta
fill 511 77 500 511 80 500 minecraft:red_terracotta
setblock 511 77 504 minecraft:terracotta
fill 512 77 465 512 149 465 minecraft:brown_terracotta
fill 512 77 469 512 147 470 minecraft:brown_terracotta
fill 512 77 484 512 147 485 minecraft:brown_terracotta
fill 512 77 500 512 151 500 minecraft:brown_terracotta
fill 512 77 503 512 151 503 minecraft:brown_terracotta
fill 512 77 505 512 151 505 minecraft:brown_terracotta
setblock 471 78 474 minecraft:red_terracotta
setblock 471 78 478 minecraft:terracotta
fill 471 78 479 471 81 479 minecraft:red_terracotta
fill 471 78 481 471 78 482 minecraft:red_terracotta
setblock 471 78 483 minecraft:terracotta
fill 471 78 484 471 80 485 minecraft:red_terracotta
setblock 471 78 488 minecraft:terracotta
setblock 471 78 489 minecraft:red_terracotta
setblock 471 78 493 minecraft:terracotta
fill 471 78 494 471 81 494 minecraft:red_terracotta
setblock 471 78 498 minecraft:terracotta
fill 471 78 499 471 81 499 minecraft:red_terracotta
setblock 471 78 503 minecraft:terracotta
fill 471 78 504 471 81 504 minecraft:red_terracotta
setblock 472 78 493 minecraft:red_terracotta
setblock 472 78 497 minecraft:terracotta
fill 472 78 498 472 81 498 minecraft:red_terracotta
setblock 472 78 502 minecraft:terracotta
fill 472 78 503 472 80 503 minecraft:red_terracotta
setblock 473 78 466 minecraft:light[level=14]
setblock 473 78 474 minecraft:light[level=14]
setblock 473 78 482 minecraft:light[level=14]
setblock 473 78 490 minecraft:light[level=14]
setblock 473 78 497 minecraft:red_terracotta
setblock 475 78 504 minecraft:terracotta
fill 476 78 504 479 78 504 minecraft:red_terracotta
setblock 480 78 503 minecraft:red_terracotta
setblock 480 78 504 minecraft:terracotta
setblock 481 78 466 minecraft:light[level=14]
setblock 481 78 474 minecraft:light[level=14]
fill 481 78 476 482 78 480 minecraft:orange_concrete
setblock 481 78 482 minecraft:light[level=14]
setblock 481 78 490 minecraft:light[level=14]
setblock 481 78 498 minecraft:light[level=14]
setblock 481 78 503 minecraft:terracotta
fill 481 78 504 481 81 504 minecraft:red_terracotta
fill 482 78 475 489 78 475 minecraft:orange_concrete
fill 482 78 481 488 78 481 minecraft:orange_concrete
fill 482 78 503 485 78 503 minecraft:red_terracotta
fill 483 78 464 484 78 464 minecraft:red_terracotta
fill 483 78 474 488 78 474 minecraft:orange_concrete
fill 483 78 476 483 80 476 minecraft:orange_concrete
fill 483 78 480 483 80 480 minecraft:orange_concrete
fill 483 78 482 487 78 482 minecraft:orange_concrete
fill 484 78 502 484 79 502 minecraft:red_terracotta
setblock 485 78 464 minecraft:terracotta
fill 485 78 473 486 78 473 minecraft:orange_concrete
setblock 485 78 504 minecraft:terracotta
fill 486 78 464 486 81 464 minecraft:red_terracotta
setblock 486 78 503 minecraft:terracotta
fill 486 78 504 486 81 504 minecraft:red_terracotta
fill 487 78 476 489 78 476 minecraft:orange_concrete
fill 487 78 480 489 78 480 minecraft:orange_concrete
fill 487 78 503 487 80 503 minecraft:red_terracotta
fill 488 78 477 489 79 479 minecraft:orange_concrete
setblock 489 78 466 minecraft:light[level=14]
setblock 489 78 474 minecraft:light[level=14]
setblock 489 78 482 minecraft:light[level=14]
setblock 489 78 490 minecraft:light[level=14]
setblock 489 78 498 minecraft:light[level=14]
setblock 490 78 464 minecraft:terracotta
setblock 490 78 478 minecraft:orange_concrete
fill 490 78 481 492 78 484 minecraft:orange_concrete
setblock 490 78 504 minecraft:terracotta
fill 491 78 479 493 78 480 minecraft:orange_concrete
fill 491 78 485 493 78 486 minecraft:orange_concrete
fill 493 78 478 497 78 478 minecraft:orange_concrete
fill 493 78 487 497 78 487 minecraft:orange_concrete
fill 494 78 479 498 78 479 minecraft:orange_concrete
fill 494 78 486 498 78 486 minecraft:orange_concrete
fill 497 78 464 497 80 464 minecraft:red_terracotta
setblock 497 78 466 minecraft:light[level=14]
setblock 497 78 474 minecraft:light[level=14]
fill 497 78 480 499 78 480 minecraft:orange_concrete
fill 497 78 485 499 78 485 minecraft:orange_concrete
setblock 497 78 490 minecraft:light[level=14]
setblock 497 78 498 minecraft:light[level=14]
fill 498 78 481 499 79 484 minecraft:orange_concrete
fill 498 78 504 499 78 504 minecraft:red_terracotta
setblock 500 78 464 minecraft:terracotta
fill 500 78 465 500 81 465 minecraft:red_terracotta
fill 500 78 482 500 78 484 minecraft:orange_concrete
setblock 500 78 503 minecraft:red_terracotta
setblock 500 78 504 minecraft:terracotta
fill 501 78 464 501 81 464 minecraft:red_terracotta
setblock 501 78 502 minecraft:red_terracotta
setblock 501 78 503 minecraft:terracotta
fill 501 78 504 501 81 504 minecraft:red_terracotta
setblock 502 78 502 minecraft:terracotta
fill 502 78 503 502 81 503 minecraft:red_terracotta
fill 503 78 502 503 81 502 minecraft:red_terracotta
setblock 504 78 465 minecraft:terracotta
fill 504 78 466 504 79 466 minecraft:red_terracotta
fill 504 78 501 504 81 501 minecraft:red_terracotta
setblock 505 78 464 minecraft:terracotta
fill 505 78 465 505 81 465 minecraft:red_terracotta
setblock 505 78 474 minecraft:light[level=14]
setblock 505 78 482 minecraft:light[level=14]
setblock 505 78 490 minecraft:light[level=14]
setblock 505 78 498 minecraft:light[level=14]
setblock 505 78 504 minecraft:terracotta
fill 506 78 464 506 81 464 minecraft:red_terracotta
fill 506 78 501 507 78 501 minecraft:red_terracotta
setblock 506 78 503 minecraft:terracotta
fill 506 78 504 506 81 504 minecraft:red_terracotta
setblock 507 78 502 minecraft:terracotta
fill 507 78 503 507 81 503 minecraft:red_terracotta
setblock 508 78 501 minecraft:terracotta
fill 508 78 502 508 81 502 minecraft:red_terracotta
setblock 509 78 465 minecraft:terracotta
setblock 509 78 495 minecraft:terracotta
fill 509 78 496 509 79 496 minecraft:red_terracotta
setblock 509 78 500 minecraft:terracotta
fill 509 78 501 509 81 501 minecraft:red_terracotta
setblock 510 78 464 minecraft:terracotta
setblock 510 78 474 minecraft:terracotta
setblock 510 78 475 minecraft:red_terracotta
setblock 510 78 478 minecraft:red_terracotta
setblock 510 78 479 minecraft:terracotta
setblock 510 78 494 minecraft:terracotta
fill 510 78 495 510 79 495 minecraft:red_terracotta
setblock 510 78 499 minecraft:terracotta
fill 510 78 500 510 81 500 minecraft:red_terracotta
setblock 510 78 504 minecraft:terracotta
fill 511 78 464 511 80 464 minecraft:red_terracotta
setblock 511 78 473 minecraft:terracotta
fill 511 78 474 511 79 474 minecraft:red_terracotta
setblock 511 78 478 minecraft:terracotta
fill 511 78 479 511 80 479 minecraft:red_terracotta
setblock 511 78 493 minecraft:terracotta
fill 511 78 494 511 80 494 minecraft:red_terracotta
setblock 511 78 498 minecraft:terracotta
fill 511 78 499 511 81 499 minecraft:red_terracotta
setblock 511 78 503 minecraft:terracotta
fill 511 78 504 511 81 504 minecraft:red_terracotta
setblock 471 79 477 minecraft:terracotta
fill 471 79 478 471 81 478 minecraft:red_terracotta
setblock 471 79 481 minecraft:red_terracotta
setblock 471 79 482 minecraft:terracotta
fill 471 79 483 471 81 483 minecraft:red_terracotta
setblock 471 79 492 minecraft:terracotta
fill 471 79 493 471 80 493 minecraft:red_terracotta
setblock 471 79 497 minecraft:terracotta
fill 471 79 498 471 81 498 minecraft:red_terracotta
setblock 471 79 502 minecraft:terracotta
fill 471 79 503 471 81 503 minecraft:red_terracotta
setblock 472 79 496 minecraft:terracotta
fill 472 79 497 472 80 497 minecraft:red_terracotta
setblock 472 79 501 minecraft:terracotta
fill 472 79 502 472 81 502 minecraft:red_terracotta
setblock 474 79 504 minecraft:terracotta
fill 475 79 504 478 79 504 minecraft:red_terracotta
schedule function dropper:buildpart/118_3 1t
