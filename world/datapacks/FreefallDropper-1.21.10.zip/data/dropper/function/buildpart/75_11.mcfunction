setblock 153 222 362 minecraft:dark_prismarine
fill 153 222 363 153 225 363 minecraft:blue_terracotta
fill 154 222 322 156 244 322 minecraft:blue_concrete
setblock 154 222 325 minecraft:blue_terracotta
fill 154 222 362 154 225 362 minecraft:blue_terracotta
setblock 155 222 325 minecraft:dark_prismarine
setblock 156 222 324 minecraft:dark_prismarine
fill 156 222 325 156 225 325 minecraft:blue_terracotta
fill 157 222 322 158 222 322 minecraft:blue_terracotta
setblock 157 222 323 minecraft:dark_prismarine
fill 157 222 324 157 225 324 minecraft:blue_terracotta
setblock 157 222 363 minecraft:dark_prismarine
fill 157 222 364 161 222 364 minecraft:blue_concrete
fill 158 222 323 158 225 323 minecraft:blue_terracotta
setblock 158 222 362 minecraft:dark_prismarine
fill 158 222 363 158 225 363 minecraft:blue_terracotta
fill 159 222 322 163 222 322 minecraft:blue_concrete
setblock 159 222 361 minecraft:dark_prismarine
fill 159 222 362 159 225 362 minecraft:blue_terracotta
fill 160 222 361 160 225 361 minecraft:blue_terracotta
setblock 161 222 324 minecraft:dark_prismarine
setblock 162 222 323 minecraft:dark_prismarine
fill 162 222 324 162 225 324 minecraft:blue_terracotta
setblock 162 222 363 minecraft:dark_prismarine
fill 162 222 364 162 223 364 minecraft:blue_terracotta
fill 163 222 323 163 225 323 minecraft:blue_terracotta
setblock 163 222 362 minecraft:dark_prismarine
fill 163 222 363 166 222 363 minecraft:blue_terracotta
fill 163 222 364 166 222 364 minecraft:blue_concrete
fill 164 222 362 166 223 362 minecraft:blue_terracotta
setblock 167 222 363 minecraft:dark_prismarine
setblock 167 222 364 minecraft:blue_terracotta
fill 168 222 363 168 225 363 minecraft:blue_terracotta
fill 168 222 364 171 236 364 minecraft:blue_concrete
setblock 172 222 363 minecraft:dark_prismarine
setblock 172 222 364 minecraft:blue_terracotta
fill 173 222 323 173 225 323 minecraft:blue_terracotta
setblock 173 222 362 minecraft:dark_prismarine
fill 173 222 363 173 225 363 minecraft:blue_terracotta
fill 174 222 362 174 225 362 minecraft:blue_terracotta
setblock 177 222 323 minecraft:dark_prismarine
setblock 177 222 363 minecraft:dark_prismarine
fill 177 222 364 177 308 364 minecraft:blue_concrete
fill 178 222 323 178 225 323 minecraft:blue_terracotta
setblock 178 222 362 minecraft:dark_prismarine
fill 178 222 363 178 225 363 minecraft:blue_terracotta
setblock 179 222 341 minecraft:dark_prismarine
fill 179 222 342 179 225 342 minecraft:blue_terracotta
setblock 179 222 345 minecraft:blue_terracotta
fill 179 222 362 179 225 362 minecraft:blue_terracotta
setblock 180 222 340 minecraft:dark_prismarine
fill 180 222 341 180 225 341 minecraft:blue_terracotta
setblock 180 222 345 minecraft:dark_prismarine
fill 180 222 346 180 225 346 minecraft:blue_terracotta
setblock 181 222 339 minecraft:dark_prismarine
fill 181 222 340 181 225 340 minecraft:blue_terracotta
setblock 181 222 344 minecraft:dark_prismarine
fill 181 222 345 181 225 345 minecraft:blue_terracotta
setblock 181 222 349 minecraft:dark_prismarine
setblock 182 222 323 minecraft:dark_prismarine
fill 182 222 324 182 224 325 minecraft:blue_terracotta
setblock 182 222 338 minecraft:dark_prismarine
fill 182 222 339 182 225 339 minecraft:blue_terracotta
setblock 182 222 343 minecraft:dark_prismarine
fill 182 222 344 182 225 344 minecraft:blue_terracotta
setblock 182 222 348 minecraft:dark_prismarine
fill 182 222 349 182 225 349 minecraft:blue_terracotta
setblock 182 222 359 minecraft:blue_terracotta
fill 182 222 361 182 223 361 minecraft:blue_terracotta
setblock 182 222 363 minecraft:dark_prismarine
setblock 182 222 364 minecraft:blue_concrete
fill 183 222 323 183 308 323 minecraft:blue_concrete
setblock 183 222 324 minecraft:blue_terracotta
fill 183 222 325 183 222 330 minecraft:blue_concrete
setblock 183 222 331 minecraft:blue_terracotta
fill 183 222 332 183 238 336 minecraft:blue_concrete
setblock 183 222 337 minecraft:blue_terracotta
fill 183 222 338 183 222 341 minecraft:blue_concrete
setblock 183 222 342 minecraft:blue_terracotta
fill 183 222 343 183 256 344 minecraft:blue_concrete
fill 183 222 353 183 308 353 minecraft:blue_concrete
fill 183 222 356 183 244 356 minecraft:blue_concrete
fill 141 223 326 141 236 326 minecraft:blue_concrete
setblock 141 223 327 minecraft:blue_terracotta
fill 141 223 328 141 236 334 minecraft:blue_concrete
setblock 141 223 335 minecraft:blue_terracotta
fill 141 223 336 141 224 343 minecraft:blue_concrete
setblock 141 223 344 minecraft:blue_terracotta
fill 141 223 345 141 230 347 minecraft:blue_concrete
fill 141 223 348 141 223 349 minecraft:blue_terracotta
fill 141 223 350 141 308 350 minecraft:blue_concrete
fill 141 223 353 141 308 353 minecraft:blue_concrete
setblock 141 223 354 minecraft:blue_terracotta
fill 141 223 355 141 308 355 minecraft:blue_concrete
setblock 141 223 356 minecraft:light_blue_wool
fill 141 223 357 141 258 360 minecraft:blue_concrete
setblock 141 223 361 minecraft:blue_terracotta
fill 141 223 362 141 308 363 minecraft:blue_concrete
fill 142 223 322 145 267 322 minecraft:blue_concrete
fill 142 223 323 142 226 323 minecraft:blue_terracotta
setblock 142 223 327 minecraft:dark_prismarine
fill 142 223 328 142 226 328 minecraft:blue_terracotta
setblock 142 223 332 minecraft:dark_prismarine
fill 142 223 333 142 226 333 minecraft:blue_terracotta
setblock 142 223 337 minecraft:dark_prismarine
fill 142 223 338 142 226 338 minecraft:blue_terracotta
setblock 142 223 342 minecraft:dark_prismarine
fill 142 223 343 142 226 343 minecraft:blue_terracotta
setblock 142 223 347 minecraft:dark_prismarine
fill 142 223 348 142 226 348 minecraft:blue_terracotta
fill 142 223 363 142 226 363 minecraft:blue_terracotta
fill 143 223 324 143 224 324 minecraft:blue_terracotta
setblock 143 223 341 minecraft:dark_prismarine
fill 143 223 342 143 225 342 minecraft:blue_terracotta
fill 144 223 364 144 308 364 minecraft:blue_concrete
setblock 146 223 322 minecraft:blue_terracotta
setblock 146 223 323 minecraft:dark_prismarine
setblock 146 223 363 minecraft:purple_concrete
setblock 146 223 364 minecraft:blue_terracotta
fill 147 223 322 147 308 322 minecraft:blue_concrete
fill 147 223 323 147 226 323 minecraft:blue_terracotta
setblock 147 223 364 minecraft:cyan_concrete
fill 148 223 324 149 223 324 minecraft:blue_terracotta
setblock 150 223 324 minecraft:dark_prismarine
setblock 151 223 323 minecraft:dark_prismarine
fill 151 223 324 151 226 324 minecraft:blue_terracotta
setblock 151 223 363 minecraft:dark_prismarine
fill 152 223 323 153 225 323 minecraft:blue_terracotta
setblock 152 223 362 minecraft:dark_prismarine
fill 152 223 363 152 226 363 minecraft:blue_terracotta
fill 152 223 364 153 308 364 minecraft:blue_concrete
fill 153 223 322 153 229 322 minecraft:blue_concrete
setblock 153 223 325 minecraft:blue_terracotta
fill 153 223 362 153 226 362 minecraft:blue_terracotta
setblock 154 223 325 minecraft:dark_prismarine
setblock 154 223 364 minecraft:blue_terracotta
setblock 155 223 324 minecraft:dark_prismarine
fill 155 223 325 155 226 325 minecraft:blue_terracotta
fill 155 223 361 155 225 361 minecraft:blue_terracotta
fill 155 223 364 157 273 364 minecraft:blue_concrete
setblock 156 223 323 minecraft:dark_prismarine
fill 156 223 324 156 226 324 minecraft:blue_terracotta
setblock 156 223 363 minecraft:dark_prismarine
fill 157 223 322 157 223 323 minecraft:blue_terracotta
fill 157 223 325 158 223 325 minecraft:blue_terracotta
setblock 157 223 362 minecraft:dark_prismarine
fill 157 223 363 157 226 363 minecraft:blue_terracotta
fill 158 223 322 159 238 322 minecraft:blue_concrete
setblock 158 223 361 minecraft:dark_prismarine
fill 158 223 362 158 226 362 minecraft:blue_terracotta
setblock 158 223 364 minecraft:blue_terracotta
setblock 159 223 325 minecraft:dark_prismarine
fill 159 223 361 159 226 361 minecraft:blue_terracotta
fill 159 223 364 161 308 364 minecraft:blue_concrete
setblock 160 223 322 minecraft:blue_terracotta
setblock 160 223 324 minecraft:dark_prismarine
fill 160 223 325 160 226 325 minecraft:blue_terracotta
fill 161 223 322 167 238 322 minecraft:blue_concrete
setblock 161 223 323 minecraft:dark_prismarine
fill 161 223 324 161 226 324 minecraft:blue_terracotta
setblock 161 223 363 minecraft:dark_prismarine
fill 162 223 323 162 226 323 minecraft:blue_terracotta
setblock 162 223 362 minecraft:dark_prismarine
fill 162 223 363 165 223 363 minecraft:blue_terracotta
fill 163 223 324 163 224 324 minecraft:blue_terracotta
fill 163 223 362 163 226 362 minecraft:blue_terracotta
fill 163 223 364 164 240 364 minecraft:blue_concrete
setblock 165 223 364 minecraft:blue_terracotta
setblock 166 223 323 minecraft:dark_prismarine
setblock 166 223 363 minecraft:dark_prismarine
fill 166 223 364 167 233 364 minecraft:blue_concrete
fill 167 223 363 167 226 363 minecraft:blue_terracotta
setblock 168 223 322 minecraft:blue_terracotta
fill 169 223 322 175 228 322 minecraft:blue_concrete
setblock 171 223 323 minecraft:dark_prismarine
setblock 171 223 363 minecraft:dark_prismarine
fill 172 223 323 172 226 323 minecraft:blue_terracotta
setblock 172 223 362 minecraft:dark_prismarine
fill 172 223 363 172 226 363 minecraft:blue_terracotta
fill 172 223 364 174 273 364 minecraft:blue_concrete
fill 173 223 362 173 226 362 minecraft:blue_terracotta
fill 174 223 323 175 223 323 minecraft:blue_terracotta
setblock 175 223 364 minecraft:blue_terracotta
setblock 176 223 322 minecraft:blue_terracotta
setblock 176 223 323 minecraft:dark_prismarine
fill 176 223 324 179 223 324 minecraft:blue_terracotta
setblock 176 223 363 minecraft:dark_prismarine
fill 176 223 364 176 308 364 minecraft:blue_concrete
fill 177 223 322 179 308 322 minecraft:blue_concrete
fill 177 223 323 177 226 323 minecraft:blue_terracotta
setblock 177 223 362 minecraft:dark_prismarine
fill 177 223 363 177 226 363 minecraft:blue_terracotta
fill 178 223 362 178 226 362 minecraft:blue_terracotta
fill 179 223 341 179 225 341 minecraft:blue_terracotta
setblock 179 223 345 minecraft:dark_prismarine
fill 179 223 346 179 226 346 minecraft:blue_terracotta
setblock 180 223 322 minecraft:light_blue_wool
setblock 180 223 339 minecraft:dark_prismarine
fill 180 223 340 180 226 340 minecraft:blue_terracotta
setblock 180 223 344 minecraft:dark_prismarine
fill 180 223 345 180 226 345 minecraft:blue_terracotta
setblock 180 223 348 minecraft:blue_terracotta
fill 181 223 322 182 229 322 minecraft:blue_concrete
setblock 181 223 323 minecraft:dark_prismarine
setblock 181 223 338 minecraft:dark_prismarine
fill 181 223 339 181 226 339 minecraft:blue_terracotta
setblock 181 223 343 minecraft:dark_prismarine
fill 181 223 344 181 226 344 minecraft:blue_terracotta
setblock 181 223 348 minecraft:dark_prismarine
fill 181 223 349 181 225 350 minecraft:blue_terracotta
setblock 181 223 363 minecraft:dark_prismarine
fill 182 223 323 182 226 323 minecraft:blue_terracotta
setblock 182 223 326 minecraft:blue_terracotta
setblock 182 223 337 minecraft:dark_prismarine
fill 182 223 338 182 226 338 minecraft:blue_terracotta
setblock 182 223 342 minecraft:dark_prismarine
fill 182 223 343 182 226 343 minecraft:blue_terracotta
setblock 182 223 347 minecraft:dark_prismarine
fill 182 223 348 182 226 348 minecraft:blue_terracotta
setblock 182 223 362 minecraft:dark_prismarine
fill 182 223 363 182 225 363 minecraft:blue_terracotta
setblock 182 223 364 minecraft:light_blue_wool
setblock 183 223 322 minecraft:blue_terracotta
fill 183 223 324 183 261 329 minecraft:blue_concrete
setblock 183 223 330 minecraft:blue_terracotta
fill 183 223 331 183 308 331 minecraft:blue_concrete
fill 183 223 337 183 276 339 minecraft:blue_concrete
setblock 183 223 340 minecraft:blue_terracotta
fill 183 223 341 183 268 342 minecraft:blue_concrete
setblock 183 223 357 minecraft:blue_terracotta
fill 183 223 358 183 298 359 minecraft:blue_concrete
setblock 183 223 360 minecraft:blue_terracotta
fill 183 223 361 183 308 364 minecraft:blue_concrete
fill 141 224 327 141 308 327 minecraft:blue_concrete
fill 141 224 335 141 308 335 minecraft:blue_concrete
fill 141 224 344 141 302 344 minecraft:blue_concrete
fill 141 224 348 141 280 349 minecraft:blue_concrete
fill 141 224 354 141 298 354 minecraft:blue_concrete
fill 141 224 356 141 308 356 minecraft:blue_concrete
fill 141 224 361 141 308 361 minecraft:blue_concrete
setblock 142 224 326 minecraft:dark_prismarine
fill 142 224 327 142 227 327 minecraft:blue_terracotta
setblock 142 224 330 minecraft:blue_terracotta
setblock 142 224 331 minecraft:dark_prismarine
fill 142 224 332 142 227 332 minecraft:blue_terracotta
setblock 142 224 335 minecraft:blue_terracotta
setblock 142 224 336 minecraft:dark_prismarine
fill 142 224 337 142 227 337 minecraft:blue_terracotta
setblock 142 224 341 minecraft:dark_prismarine
fill 142 224 342 142 227 342 minecraft:blue_terracotta
setblock 142 224 346 minecraft:dark_prismarine
fill 142 224 347 142 227 347 minecraft:blue_terracotta
setblock 143 224 325 minecraft:dark_prismarine
fill 143 224 326 143 227 326 minecraft:blue_terracotta
setblock 143 224 340 minecraft:dark_prismarine
fill 143 224 341 143 225 341 minecraft:blue_terracotta
setblock 144 224 324 minecraft:dark_prismarine
setblock 145 224 323 minecraft:dark_prismarine
fill 145 224 324 148 224 324 minecraft:blue_terracotta
fill 146 224 322 146 308 322 minecraft:blue_concrete
fill 146 224 323 146 227 323 minecraft:blue_terracotta
fill 146 224 364 147 308 364 minecraft:blue_concrete
fill 148 224 363 148 225 363 minecraft:blue_terracotta
setblock 149 224 324 minecraft:dark_prismarine
setblock 150 224 323 minecraft:dark_prismarine
fill 150 224 324 150 227 324 minecraft:blue_terracotta
setblock 150 224 363 minecraft:dark_prismarine
fill 151 224 323 151 227 323 minecraft:blue_terracotta
fill 151 224 325 152 224 325 minecraft:blue_terracotta
setblock 151 224 362 minecraft:dark_prismarine
fill 151 224 363 151 227 363 minecraft:blue_terracotta
fill 152 224 362 152 227 362 minecraft:blue_terracotta
setblock 153 224 325 minecraft:dark_prismarine
setblock 154 224 324 minecraft:dark_prismarine
fill 154 224 325 154 227 325 minecraft:blue_terracotta
fill 154 224 364 154 245 364 minecraft:blue_concrete
setblock 155 224 323 minecraft:dark_prismarine
fill 155 224 324 155 227 324 minecraft:blue_terracotta
setblock 155 224 363 minecraft:dark_prismarine
fill 156 224 323 157 226 323 minecraft:blue_terracotta
setblock 156 224 362 minecraft:dark_prismarine
fill 156 224 363 156 227 363 minecraft:blue_terracotta
fill 157 224 322 157 308 322 minecraft:blue_concrete
setblock 157 224 325 minecraft:blue_terracotta
setblock 157 224 361 minecraft:dark_prismarine
fill 157 224 362 157 227 362 minecraft:blue_terracotta
setblock 158 224 325 minecraft:dark_prismarine
fill 158 224 361 158 227 361 minecraft:blue_terracotta
fill 158 224 364 158 308 364 minecraft:blue_concrete
setblock 159 224 324 minecraft:dark_prismarine
fill 159 224 325 159 227 325 minecraft:blue_terracotta
fill 160 224 322 160 308 322 minecraft:blue_concrete
setblock 160 224 323 minecraft:dark_prismarine
fill 160 224 324 160 227 324 minecraft:blue_terracotta
setblock 160 224 363 minecraft:dark_prismarine
fill 161 224 323 161 227 323 minecraft:blue_terracotta
setblock 161 224 362 minecraft:dark_prismarine
fill 161 224 363 164 224 363 minecraft:blue_terracotta
fill 162 224 362 162 227 362 minecraft:blue_terracotta
fill 162 224 364 162 308 364 minecraft:blue_concrete
fill 164 224 362 165 224 362 minecraft:blue_terracotta
setblock 165 224 323 minecraft:dark_prismarine
setblock 165 224 363 minecraft:dark_prismarine
fill 165 224 364 165 308 364 minecraft:blue_concrete
fill 166 224 323 169 224 323 minecraft:blue_terracotta
fill 166 224 363 166 227 363 minecraft:blue_terracotta
fill 168 224 322 168 308 322 minecraft:blue_concrete
setblock 170 224 323 minecraft:dark_prismarine
setblock 170 224 362 minecraft:blue_terracotta
setblock 170 224 363 minecraft:dark_prismarine
fill 171 224 323 171 227 323 minecraft:blue_terracotta
setblock 171 224 362 minecraft:dark_prismarine
fill 171 224 363 171 227 363 minecraft:blue_terracotta
fill 172 224 362 172 227 362 minecraft:blue_terracotta
setblock 174 224 323 minecraft:blue_terracotta
setblock 174 224 324 minecraft:dark_prismarine
setblock 175 224 323 minecraft:dark_prismarine
fill 175 224 324 178 224 324 minecraft:blue_terracotta
setblock 175 224 363 minecraft:dark_prismarine
fill 175 224 364 175 308 364 minecraft:blue_concrete
fill 176 224 322 176 308 322 minecraft:blue_concrete
fill 176 224 323 176 227 323 minecraft:blue_terracotta
setblock 176 224 362 minecraft:dark_prismarine
fill 176 224 363 176 227 363 minecraft:blue_terracotta
fill 177 224 362 177 227 362 minecraft:blue_terracotta
setblock 179 224 324 minecraft:dark_prismarine
setblock 179 224 343 minecraft:blue_terracotta
setblock 179 224 344 minecraft:dark_prismarine
fill 179 224 345 179 227 345 minecraft:blue_terracotta
fill 179 224 347 179 225 347 minecraft:blue_terracotta
fill 180 224 322 180 308 322 minecraft:blue_concrete
setblock 180 224 323 minecraft:dark_prismarine
fill 180 224 324 180 227 324 minecraft:blue_terracotta
fill 180 224 339 180 225 339 minecraft:blue_terracotta
setblock 180 224 343 minecraft:dark_prismarine
fill 180 224 344 180 227 344 minecraft:blue_terracotta
setblock 180 224 348 minecraft:dark_prismarine
fill 180 224 349 180 227 349 minecraft:blue_terracotta
setblock 180 224 363 minecraft:dark_prismarine
fill 181 224 323 181 227 323 minecraft:blue_terracotta
setblock 181 224 337 minecraft:dark_prismarine
fill 181 224 338 181 227 338 minecraft:blue_terracotta
setblock 181 224 342 minecraft:dark_prismarine
fill 181 224 343 181 227 343 minecraft:blue_terracotta
setblock 181 224 347 minecraft:dark_prismarine
fill 181 224 348 181 227 348 minecraft:blue_terracotta
fill 181 224 363 181 226 363 minecraft:blue_terracotta
setblock 182 224 326 minecraft:dark_prismarine
fill 182 224 327 182 226 328 minecraft:blue_terracotta
fill 182 224 332 182 225 332 minecraft:purple_concrete
setblock 182 224 336 minecraft:dark_prismarine
fill 182 224 337 182 227 337 minecraft:blue_terracotta
setblock 182 224 341 minecraft:dark_prismarine
fill 182 224 342 182 227 342 minecraft:blue_terracotta
setblock 182 224 346 minecraft:dark_prismarine
fill 182 224 347 182 227 347 minecraft:blue_terracotta
setblock 182 224 351 minecraft:dark_prismarine
setblock 182 224 357 minecraft:purple_concrete
setblock 182 224 362 minecraft:blue_terracotta
fill 182 224 364 182 308 364 minecraft:blue_concrete
fill 183 224 322 183 308 322 minecraft:blue_concrete
fill 183 224 330 183 308 330 minecraft:blue_concrete
fill 183 224 340 183 278 340 minecraft:blue_concrete
fill 183 224 357 183 308 357 minecraft:blue_concrete
fill 183 224 360 183 308 360 minecraft:blue_concrete
fill 141 225 336 141 227 342 minecraft:blue_concrete
setblock 141 225 343 minecraft:cyan_concrete
setblock 142 225 325 minecraft:dark_prismarine
fill 142 225 326 142 228 326 minecraft:blue_terracotta
setblock 142 225 330 minecraft:dark_prismarine
fill 142 225 331 142 228 331 minecraft:blue_terracotta
setblock 142 225 335 minecraft:dark_prismarine
fill 142 225 336 142 228 336 minecraft:blue_terracotta
setblock 142 225 340 minecraft:dark_prismarine
fill 142 225 341 142 228 341 minecraft:blue_terracotta
setblock 142 225 345 minecraft:dark_prismarine
fill 142 225 346 142 228 346 minecraft:blue_terracotta
setblock 142 225 349 minecraft:blue_terracotta
setblock 142 225 354 minecraft:purple_concrete
setblock 143 225 324 minecraft:dark_prismarine
fill 143 225 325 143 228 325 minecraft:blue_terracotta
fill 143 225 327 143 225 328 minecraft:blue_terracotta
setblock 143 225 344 minecraft:dark_prismarine
setblock 143 225 345 minecraft:blue_terracotta
setblock 144 225 323 minecraft:dark_prismarine
fill 144 225 324 147 225 324 minecraft:blue_terracotta
fill 145 225 323 145 228 323 minecraft:blue_terracotta
fill 147 225 363 147 226 363 minecraft:blue_terracotta
setblock 148 225 324 minecraft:dark_prismarine
fill 148 225 345 148 230 345 minecraft:magenta_terracotta
setblock 149 225 323 minecraft:dark_prismarine
fill 149 225 324 149 227 325 minecraft:blue_terracotta
setblock 149 225 363 minecraft:dark_prismarine
fill 150 225 323 150 228 323 minecraft:blue_terracotta
fill 150 225 325 151 225 325 minecraft:blue_terracotta
fill 150 225 363 150 228 363 minecraft:blue_terracotta
fill 151 225 362 151 228 362 minecraft:blue_terracotta
setblock 151 225 364 minecraft:cyan_concrete
setblock 152 225 325 minecraft:dark_prismarine
setblock 153 225 324 minecraft:dark_prismarine
fill 153 225 325 153 227 326 minecraft:blue_terracotta
setblock 154 225 323 minecraft:dark_prismarine
fill 154 225 324 154 228 324 minecraft:blue_terracotta
fill 154 225 326 155 225 326 minecraft:blue_terracotta
fill 154 225 361 154 226 361 minecraft:blue_terracotta
setblock 154 225 363 minecraft:dark_prismarine
fill 155 225 323 155 228 323 minecraft:blue_terracotta
setblock 155 225 362 minecraft:dark_prismarine
fill 155 225 363 155 228 363 minecraft:blue_terracotta
setblock 156 225 326 minecraft:dark_prismarine
setblock 156 225 361 minecraft:dark_prismarine
fill 156 225 362 156 228 362 minecraft:blue_terracotta
setblock 157 225 325 minecraft:dark_prismarine
fill 157 225 326 157 228 326 minecraft:blue_terracotta
fill 157 225 361 157 228 361 minecraft:blue_terracotta
setblock 158 225 324 minecraft:dark_prismarine
fill 158 225 325 158 228 325 minecraft:blue_terracotta
setblock 159 225 323 minecraft:dark_prismarine
fill 159 225 324 159 228 324 minecraft:blue_terracotta
setblock 159 225 363 minecraft:dark_prismarine
fill 160 225 323 160 228 323 minecraft:blue_terracotta
setblock 160 225 362 minecraft:dark_prismarine
fill 160 225 363 163 225 363 minecraft:blue_terracotta
fill 161 225 362 161 228 362 minecraft:blue_terracotta
setblock 163 225 324 minecraft:dark_prismarine
setblock 164 225 323 minecraft:dark_prismarine
setblock 164 225 362 minecraft:blue_terracotta
setblock 164 225 363 minecraft:dark_prismarine
fill 165 225 323 168 225 323 minecraft:blue_terracotta
setblock 165 225 362 minecraft:dark_prismarine
fill 165 225 363 165 228 363 minecraft:blue_terracotta
setblock 169 225 323 minecraft:dark_prismarine
setblock 169 225 362 minecraft:blue_terracotta
setblock 169 225 363 minecraft:dark_prismarine
fill 170 225 323 170 228 323 minecraft:blue_terracotta
setblock 170 225 362 minecraft:dark_prismarine
fill 170 225 363 170 228 363 minecraft:blue_terracotta
fill 171 225 362 171 228 362 minecraft:blue_terracotta
setblock 172 225 324 minecraft:blue_terracotta
setblock 173 225 324 minecraft:dark_prismarine
setblock 174 225 323 minecraft:dark_prismarine
fill 174 225 324 177 225 324 minecraft:blue_terracotta
setblock 174 225 363 minecraft:dark_prismarine
fill 175 225 323 175 228 323 minecraft:blue_terracotta
setblock 175 225 362 minecraft:dark_prismarine
fill 175 225 363 175 228 363 minecraft:blue_terracotta
fill 176 225 362 176 228 362 minecraft:blue_terracotta
setblock 178 225 324 minecraft:dark_prismarine
setblock 179 225 323 minecraft:dark_prismarine
fill 179 225 324 179 228 324 minecraft:blue_terracotta
setblock 179 225 343 minecraft:dark_prismarine
fill 179 225 344 179 228 344 minecraft:blue_terracotta
setblock 179 225 348 minecraft:dark_prismarine
setblock 179 225 363 minecraft:dark_prismarine
fill 180 225 323 180 228 323 minecraft:blue_terracotta
setblock 180 225 342 minecraft:dark_prismarine
fill 180 225 343 180 228 343 minecraft:blue_terracotta
setblock 180 225 347 minecraft:dark_prismarine
fill 180 225 348 180 228 348 minecraft:blue_terracotta
fill 180 225 363 180 227 363 minecraft:blue_terracotta
fill 181 225 324 181 225 325 minecraft:blue_terracotta
setblock 181 225 337 minecraft:blue_terracotta
setblock 181 225 341 minecraft:dark_prismarine
fill 181 225 342 181 228 342 minecraft:blue_terracotta
setblock 181 225 346 minecraft:dark_prismarine
fill 181 225 347 181 228 347 minecraft:blue_terracotta
setblock 181 225 351 minecraft:dark_prismarine
setblock 182 225 324 minecraft:blue_terracotta
setblock 182 225 325 minecraft:dark_prismarine
fill 182 225 326 182 228 326 minecraft:blue_terracotta
setblock 182 225 329 minecraft:blue_terracotta
setblock 182 225 330 minecraft:dark_prismarine
setblock 182 225 334 minecraft:blue_terracotta
setblock 182 225 335 minecraft:dark_prismarine
fill 182 225 336 182 228 336 minecraft:blue_terracotta
setblock 182 225 340 minecraft:dark_prismarine
fill 182 225 341 182 228 341 minecraft:blue_terracotta
setblock 182 225 345 minecraft:dark_prismarine
fill 182 225 346 182 228 346 minecraft:blue_terracotta
setblock 182 225 350 minecraft:dark_prismarine
fill 182 225 351 182 227 352 minecraft:blue_terracotta
fill 141 226 343 141 308 343 minecraft:blue_concrete
setblock 142 226 324 minecraft:dark_prismarine
fill 142 226 325 142 229 325 minecraft:blue_terracotta
setblock 142 226 329 minecraft:dark_prismarine
fill 142 226 330 142 229 330 minecraft:blue_terracotta
setblock 142 226 334 minecraft:dark_prismarine
fill 142 226 335 142 229 335 minecraft:blue_terracotta
setblock 142 226 339 minecraft:dark_prismarine
fill 142 226 340 142 228 340 minecraft:blue_terracotta
setblock 142 226 344 minecraft:dark_prismarine
fill 142 226 345 142 229 345 minecraft:blue_terracotta
setblock 142 226 349 minecraft:dark_prismarine
setblock 142 226 360 minecraft:purple_concrete
setblock 143 226 323 minecraft:dark_prismarine
fill 143 226 324 146 226 324 minecraft:blue_terracotta
setblock 143 226 327 minecraft:blue_terracotta
setblock 143 226 328 minecraft:dark_prismarine
fill 143 226 329 143 229 329 minecraft:blue_terracotta
setblock 143 226 343 minecraft:dark_prismarine
setblock 143 226 344 minecraft:blue_terracotta
fill 144 226 323 144 229 323 minecraft:blue_terracotta
fill 145 226 363 145 227 363 minecraft:purple_concrete
fill 146 226 363 146 227 363 minecraft:blue_terracotta
setblock 147 226 324 minecraft:dark_prismarine
fill 147 226 325 148 228 325 minecraft:blue_terracotta
setblock 148 226 323 minecraft:dark_prismarine
fill 148 226 324 148 229 324 minecraft:blue_terracotta
setblock 148 226 363 minecraft:dark_prismarine
fill 149 226 323 149 229 323 minecraft:blue_terracotta
fill 149 226 363 149 229 363 minecraft:blue_terracotta
setblock 150 226 325 minecraft:blue_terracotta
fill 150 226 362 150 229 362 minecraft:blue_terracotta
setblock 151 226 325 minecraft:dark_prismarine
fill 151 226 326 152 228 326 minecraft:blue_terracotta
fill 151 226 364 151 299 364 minecraft:blue_concrete
setblock 152 226 323 minecraft:blue_terracotta
setblock 152 226 324 minecraft:dark_prismarine
fill 152 226 325 152 229 325 minecraft:blue_terracotta
setblock 153 226 323 minecraft:dark_prismarine
fill 153 226 324 153 229 324 minecraft:blue_terracotta
fill 153 226 361 153 227 361 minecraft:blue_terracotta
setblock 153 226 363 minecraft:dark_prismarine
fill 154 226 323 154 229 323 minecraft:blue_terracotta
setblock 154 226 326 minecraft:blue_terracotta
setblock 154 226 362 minecraft:dark_prismarine
fill 154 226 363 154 229 363 minecraft:blue_terracotta
setblock 155 226 326 minecraft:dark_prismarine
setblock 155 226 361 minecraft:dark_prismarine
fill 155 226 362 155 229 362 minecraft:blue_terracotta
setblock 156 226 325 minecraft:dark_prismarine
fill 156 226 326 156 229 326 minecraft:blue_terracotta
fill 156 226 361 156 229 361 minecraft:blue_terracotta
setblock 157 226 324 minecraft:dark_prismarine
fill 157 226 325 157 229 325 minecraft:blue_terracotta
setblock 158 226 323 minecraft:dark_prismarine
fill 158 226 324 158 229 324 minecraft:blue_terracotta
setblock 158 226 363 minecraft:dark_prismarine
fill 159 226 323 159 229 323 minecraft:blue_terracotta
setblock 159 226 362 minecraft:dark_prismarine
fill 159 226 363 162 226 363 minecraft:blue_terracotta
fill 160 226 362 160 229 362 minecraft:blue_terracotta
setblock 162 226 324 minecraft:dark_prismarine
setblock 163 226 323 minecraft:dark_prismarine
fill 163 226 324 163 227 324 minecraft:blue_terracotta
setblock 163 226 363 minecraft:dark_prismarine
fill 164 226 323 167 226 323 minecraft:blue_terracotta
setblock 164 226 362 minecraft:dark_prismarine
fill 164 226 363 164 229 363 minecraft:blue_terracotta
setblock 168 226 323 minecraft:dark_prismarine
setblock 168 226 363 minecraft:dark_prismarine
fill 169 226 323 169 229 323 minecraft:blue_terracotta
setblock 169 226 362 minecraft:dark_prismarine
fill 169 226 363 169 229 363 minecraft:blue_terracotta
fill 170 226 362 170 229 362 minecraft:blue_terracotta
setblock 171 226 324 minecraft:blue_terracotta
setblock 172 226 324 minecraft:dark_prismarine
setblock 173 226 323 minecraft:dark_prismarine
fill 173 226 324 176 226 324 minecraft:blue_terracotta
setblock 173 226 363 minecraft:dark_prismarine
fill 174 226 323 174 229 323 minecraft:blue_terracotta
setblock 174 226 362 minecraft:dark_prismarine
fill 174 226 363 174 229 363 minecraft:blue_terracotta
fill 175 226 362 175 229 362 minecraft:blue_terracotta
setblock 176 226 325 minecraft:dark_prismarine
setblock 177 226 324 minecraft:dark_prismarine
setblock 178 226 323 minecraft:dark_prismarine
fill 178 226 324 178 229 324 minecraft:blue_terracotta
setblock 178 226 363 minecraft:dark_prismarine
fill 179 226 323 179 229 323 minecraft:blue_terracotta
setblock 179 226 342 minecraft:dark_prismarine
fill 179 226 343 179 227 343 minecraft:blue_terracotta
setblock 179 226 347 minecraft:dark_prismarine
fill 179 226 348 179 228 348 minecraft:blue_terracotta
fill 179 226 363 179 228 363 minecraft:blue_terracotta
setblock 180 226 341 minecraft:dark_prismarine
fill 180 226 342 180 228 342 minecraft:blue_terracotta
setblock 180 226 346 minecraft:dark_prismarine
fill 180 226 347 180 229 347 minecraft:blue_terracotta
setblock 180 226 350 minecraft:blue_terracotta
setblock 181 226 324 minecraft:blue_terracotta
setblock 181 226 325 minecraft:dark_prismarine
fill 181 226 326 181 228 327 minecraft:blue_terracotta
setblock 181 226 340 minecraft:dark_prismarine
fill 181 226 341 181 229 341 minecraft:blue_terracotta
setblock 181 226 345 minecraft:dark_prismarine
fill 181 226 346 181 229 346 minecraft:blue_terracotta
setblock 181 226 349 minecraft:blue_terracotta
setblock 181 226 350 minecraft:dark_prismarine
fill 181 226 351 181 229 351 minecraft:blue_terracotta
setblock 182 226 324 minecraft:dark_prismarine
fill 182 226 325 182 229 325 minecraft:blue_terracotta
setblock 182 226 329 minecraft:dark_prismarine
fill 182 226 330 182 226 333 minecraft:blue_terracotta
setblock 182 226 334 minecraft:dark_prismarine
fill 182 226 335 182 229 335 minecraft:blue_terracotta
setblock 182 226 339 minecraft:dark_prismarine
fill 182 226 340 182 229 340 minecraft:blue_terracotta
setblock 182 226 344 minecraft:dark_prismarine
fill 182 226 345 182 229 345 minecraft:blue_terracotta
setblock 182 226 349 minecraft:dark_prismarine
fill 182 226 350 182 229 350 minecraft:blue_terracotta
setblock 142 227 323 minecraft:dark_prismarine
fill 142 227 324 145 227 324 minecraft:blue_terracotta
setblock 142 227 328 minecraft:dark_prismarine
fill 142 227 329 142 229 329 minecraft:blue_terracotta
setblock 142 227 333 minecraft:dark_prismarine
fill 142 227 334 142 229 334 minecraft:blue_terracotta
setblock 142 227 338 minecraft:dark_prismarine
fill 142 227 339 142 228 339 minecraft:blue_terracotta
setblock 142 227 343 minecraft:dark_prismarine
fill 142 227 344 142 229 344 minecraft:blue_terracotta
setblock 142 227 348 minecraft:dark_prismarine
fill 142 227 349 142 229 350 minecraft:blue_terracotta
fill 143 227 323 143 229 323 minecraft:blue_terracotta
setblock 143 227 327 minecraft:dark_prismarine
fill 143 227 328 143 229 328 minecraft:blue_terracotta
fill 143 227 330 143 228 330 minecraft:blue_terracotta
setblock 144 227 325 minecraft:blue_terracotta
setblock 144 227 332 minecraft:light[level=12]
setblock 144 227 339 minecraft:light[level=12]
setblock 144 227 346 minecraft:light[level=12]
setblock 144 227 353 minecraft:light[level=12]
setblock 144 227 360 minecraft:light[level=12]
setblock 145 227 325 minecraft:dark_prismarine
setblock 146 227 324 minecraft:dark_prismarine
fill 146 227 325 146 229 325 minecraft:blue_terracotta
setblock 147 227 323 minecraft:dark_prismarine
fill 147 227 324 147 229 324 minecraft:blue_terracotta
setblock 147 227 363 minecraft:dark_prismarine
fill 148 227 323 148 229 323 minecraft:blue_terracotta
fill 148 227 363 148 229 363 minecraft:blue_terracotta
setblock 150 227 325 minecraft:dark_prismarine
fill 150 227 326 150 229 326 minecraft:blue_terracotta
setblock 151 227 324 minecraft:dark_prismarine
fill 151 227 325 151 229 325 minecraft:blue_terracotta
setblock 151 227 332 minecraft:light[level=12]
setblock 151 227 339 minecraft:light[level=12]
setblock 151 227 346 minecraft:light[level=12]
setblock 151 227 353 minecraft:light[level=12]
setblock 151 227 360 minecraft:light[level=12]
setblock 152 227 323 minecraft:dark_prismarine
fill 152 227 324 152 229 324 minecraft:blue_terracotta
setblock 152 227 363 minecraft:dark_prismarine
fill 153 227 323 153 229 323 minecraft:blue_terracotta
setblock 153 227 362 minecraft:dark_prismarine
fill 153 227 363 153 229 363 minecraft:blue_terracotta
setblock 154 227 326 minecraft:dark_prismarine
setblock 154 227 361 minecraft:dark_prismarine
fill 154 227 362 154 229 362 minecraft:blue_terracotta
setblock 155 227 325 minecraft:dark_prismarine
fill 155 227 326 155 229 326 minecraft:blue_terracotta
fill 155 227 361 155 229 361 minecraft:blue_terracotta
setblock 156 227 323 minecraft:blue_terracotta
setblock 156 227 324 minecraft:dark_prismarine
fill 156 227 325 156 229 325 minecraft:blue_terracotta
setblock 157 227 323 minecraft:dark_prismarine
fill 157 227 324 157 229 324 minecraft:blue_terracotta
setblock 157 227 363 minecraft:dark_prismarine
fill 158 227 323 158 229 323 minecraft:blue_terracotta
setblock 158 227 332 minecraft:light[level=12]
setblock 158 227 339 minecraft:light[level=12]
setblock 158 227 346 minecraft:light[level=12]
setblock 158 227 353 minecraft:light[level=12]
setblock 158 227 360 minecraft:light[level=12]
setblock 158 227 362 minecraft:dark_prismarine
fill 158 227 363 161 227 363 minecraft:blue_terracotta
setblock 159 227 361 minecraft:dark_prismarine
fill 159 227 362 159 229 362 minecraft:blue_terracotta
setblock 160 227 325 minecraft:dark_prismarine
setblock 161 227 324 minecraft:dark_prismarine
setblock 162 227 323 minecraft:dark_prismarine
fill 162 227 324 162 228 324 minecraft:blue_terracotta
setblock 162 227 363 minecraft:dark_prismarine
fill 163 227 323 166 227 323 minecraft:blue_terracotta
setblock 163 227 362 minecraft:dark_prismarine
fill 163 227 363 163 229 363 minecraft:blue_terracotta
setblock 165 227 325 minecraft:light[level=12]
setblock 165 227 332 minecraft:light[level=12]
setblock 165 227 339 minecraft:light[level=12]
setblock 165 227 346 minecraft:light[level=12]
setblock 165 227 353 minecraft:light[level=12]
setblock 165 227 360 minecraft:light[level=12]
setblock 167 227 323 minecraft:dark_prismarine
setblock 167 227 363 minecraft:dark_prismarine
fill 168 227 323 168 229 323 minecraft:blue_terracotta
fill 168 227 363 168 229 363 minecraft:blue_terracotta
setblock 169 227 362 minecraft:blue_terracotta
setblock 170 227 324 minecraft:blue_terracotta
setblock 171 227 324 minecraft:dark_prismarine
setblock 172 227 323 minecraft:dark_prismarine
fill 172 227 324 175 227 324 minecraft:blue_terracotta
setblock 172 227 325 minecraft:light[level=12]
setblock 172 227 332 minecraft:light[level=12]
setblock 172 227 339 minecraft:light[level=12]
setblock 172 227 346 minecraft:light[level=12]
setblock 172 227 353 minecraft:light[level=12]
setblock 172 227 360 minecraft:light[level=12]
setblock 172 227 363 minecraft:dark_prismarine
fill 173 227 323 173 229 323 minecraft:blue_terracotta
setblock 173 227 362 minecraft:dark_prismarine
fill 173 227 363 173 229 363 minecraft:blue_terracotta
setblock 174 227 325 minecraft:blue_terracotta
fill 174 227 337 174 228 338 minecraft:dark_prismarine
fill 174 227 362 174 229 362 minecraft:blue_terracotta
setblock 175 227 325 minecraft:dark_prismarine
setblock 176 227 324 minecraft:dark_prismarine
fill 176 227 325 178 227 325 minecraft:blue_terracotta
setblock 177 227 323 minecraft:dark_prismarine
fill 177 227 324 177 229 324 minecraft:blue_terracotta
setblock 177 227 363 minecraft:dark_prismarine
fill 178 227 323 178 229 323 minecraft:blue_terracotta
fill 178 227 363 178 229 363 minecraft:blue_terracotta
setblock 179 227 325 minecraft:light[level=12]
setblock 179 227 332 minecraft:light[level=12]
setblock 179 227 339 minecraft:light[level=12]
setblock 179 227 342 minecraft:blue_terracotta
setblock 179 227 346 minecraft:dark_prismarine
fill 179 227 347 179 229 347 minecraft:blue_terracotta
setblock 179 227 349 minecraft:blue_terracotta
setblock 179 227 353 minecraft:light[level=12]
setblock 179 227 360 minecraft:light[level=12]
setblock 180 227 340 minecraft:dark_prismarine
fill 180 227 341 180 228 341 minecraft:blue_terracotta
setblock 180 227 345 minecraft:dark_prismarine
fill 180 227 346 180 229 346 minecraft:blue_terracotta
setblock 180 227 350 minecraft:dark_prismarine
setblock 181 227 324 minecraft:dark_prismarine
fill 181 227 325 181 229 325 minecraft:blue_terracotta
setblock 181 227 328 minecraft:blue_terracotta
setblock 181 227 329 minecraft:dark_prismarine
setblock 181 227 339 minecraft:dark_prismarine
fill 181 227 340 181 228 340 minecraft:blue_terracotta
setblock 181 227 344 minecraft:dark_prismarine
fill 181 227 345 181 229 345 minecraft:blue_terracotta
setblock 181 227 349 minecraft:dark_prismarine
fill 181 227 350 181 229 350 minecraft:blue_terracotta
setblock 182 227 323 minecraft:dark_prismarine
fill 182 227 324 182 229 324 minecraft:blue_terracotta
setblock 182 227 327 minecraft:blue_terracotta
setblock 182 227 328 minecraft:dark_prismarine
fill 182 227 329 182 227 332 minecraft:blue_terracotta
setblock 182 227 333 minecraft:dark_prismarine
fill 182 227 334 182 229 334 minecraft:blue_terracotta
setblock 182 227 338 minecraft:dark_prismarine
fill 182 227 339 182 229 339 minecraft:blue_terracotta
setblock 182 227 343 minecraft:dark_prismarine
fill 182 227 344 182 229 344 minecraft:blue_terracotta
setblock 182 227 348 minecraft:dark_prismarine
fill 182 227 349 182 229 349 minecraft:blue_terracotta
setblock 182 227 358 minecraft:purple_concrete
fill 141 228 336 141 308 337 minecraft:blue_concrete
setblock 141 228 338 minecraft:light_blue_wool
fill 141 228 339 141 287 342 minecraft:blue_concrete
fill 142 228 323 142 229 324 minecraft:blue_terracotta
setblock 142 228 327 minecraft:dark_prismarine
fill 142 228 328 142 229 328 minecraft:blue_terracotta
setblock 142 228 332 minecraft:dark_prismarine
fill 142 228 333 142 229 333 minecraft:blue_terracotta
setblock 142 228 337 minecraft:dark_prismarine
setblock 142 228 338 minecraft:blue_terracotta
setblock 142 228 342 minecraft:dark_prismarine
fill 142 228 343 142 229 343 minecraft:blue_terracotta
setblock 142 228 347 minecraft:dark_prismarine
fill 142 228 348 142 229 348 minecraft:blue_terracotta
setblock 142 228 353 minecraft:purple_concrete
fill 143 228 324 144 228 324 minecraft:blue_terracotta
setblock 143 228 326 minecraft:dark_prismarine
fill 143 228 327 144 229 327 minecraft:blue_terracotta
setblock 143 228 331 minecraft:dark_prismarine
setblock 144 228 325 minecraft:dark_prismarine
fill 144 228 326 144 229 326 minecraft:blue_terracotta
setblock 145 228 324 minecraft:dark_prismarine
fill 145 228 325 145 229 325 minecraft:blue_terracotta
setblock 146 228 323 minecraft:dark_prismarine
fill 146 228 324 146 229 324 minecraft:blue_terracotta
setblock 146 228 363 minecraft:dark_prismarine
fill 147 228 323 147 229 323 minecraft:blue_terracotta
fill 147 228 363 147 229 363 minecraft:blue_terracotta
setblock 149 228 322 minecraft:cyan_concrete
setblock 149 228 324 minecraft:blue_terracotta
setblock 149 228 325 minecraft:dark_prismarine
fill 149 228 326 149 229 326 minecraft:blue_terracotta
fill 150 228 322 151 292 322 minecraft:blue_concrete
setblock 150 228 324 minecraft:dark_prismarine
fill 150 228 325 150 229 325 minecraft:blue_terracotta
setblock 151 228 323 minecraft:dark_prismarine
fill 151 228 324 151 229 324 minecraft:blue_terracotta
setblock 151 228 363 minecraft:dark_prismarine
fill 152 228 323 152 229 323 minecraft:blue_terracotta
setblock 152 228 362 minecraft:dark_prismarine
fill 152 228 363 152 229 363 minecraft:blue_terracotta
setblock 153 228 325 minecraft:blue_terracotta
setblock 153 228 326 minecraft:dark_prismarine
setblock 153 228 361 minecraft:dark_prismarine
fill 153 228 362 153 229 362 minecraft:blue_terracotta
setblock 154 228 325 minecraft:dark_prismarine
fill 154 228 326 154 229 326 minecraft:blue_terracotta
fill 154 228 361 154 229 361 minecraft:blue_terracotta
setblock 155 228 324 minecraft:dark_prismarine
fill 155 228 325 155 229 325 minecraft:blue_terracotta
setblock 156 228 323 minecraft:dark_prismarine
fill 156 228 324 156 229 324 minecraft:blue_terracotta
setblock 156 228 363 minecraft:dark_prismarine
fill 157 228 323 157 229 323 minecraft:blue_terracotta
setblock 157 228 362 minecraft:dark_prismarine
fill 157 228 363 160 228 363 minecraft:blue_terracotta
setblock 158 228 361 minecraft:dark_prismarine
fill 158 228 362 158 229 362 minecraft:blue_terracotta
setblock 159 228 325 minecraft:dark_prismarine
setblock 160 228 324 minecraft:dark_prismarine
setblock 160 228 325 minecraft:blue_terracotta
setblock 161 228 323 minecraft:dark_prismarine
fill 161 228 324 161 229 324 minecraft:blue_terracotta
setblock 161 228 363 minecraft:dark_prismarine
fill 162 228 323 165 228 323 minecraft:blue_terracotta
setblock 162 228 362 minecraft:dark_prismarine
fill 162 228 363 162 229 363 minecraft:blue_terracotta
setblock 166 228 323 minecraft:dark_prismarine
setblock 166 228 363 minecraft:dark_prismarine
fill 167 228 323 167 229 323 minecraft:blue_terracotta
fill 167 228 363 167 229 363 minecraft:blue_terracotta
setblock 169 228 324 minecraft:blue_terracotta
setblock 170 228 324 minecraft:dark_prismarine
setblock 171 228 323 minecraft:dark_prismarine
fill 171 228 324 174 228 324 minecraft:blue_terracotta
setblock 171 228 363 minecraft:dark_prismarine
fill 172 228 323 172 229 323 minecraft:blue_terracotta
setblock 172 228 362 minecraft:dark_prismarine
fill 172 228 363 172 229 363 minecraft:blue_terracotta
setblock 173 228 325 minecraft:blue_terracotta
fill 173 228 362 173 229 362 minecraft:blue_terracotta
setblock 174 228 325 minecraft:dark_prismarine
setblock 175 228 324 minecraft:dark_prismarine
fill 175 228 325 177 229 325 minecraft:blue_terracotta
setblock 176 228 323 minecraft:dark_prismarine
fill 176 228 324 176 229 324 minecraft:blue_terracotta
fill 176 228 341 176 234 341 minecraft:magenta_terracotta
setblock 176 228 363 minecraft:dark_prismarine
fill 177 228 323 177 229 323 minecraft:blue_terracotta
fill 177 228 363 177 229 363 minecraft:blue_terracotta
setblock 179 228 345 minecraft:dark_prismarine
fill 179 228 346 179 229 346 minecraft:blue_terracotta
setblock 180 228 324 minecraft:dark_prismarine
setblock 180 228 344 minecraft:dark_prismarine
fill 180 228 345 180 229 345 minecraft:blue_terracotta
setblock 180 228 349 minecraft:dark_prismarine
setblock 180 228 350 minecraft:blue_terracotta
setblock 181 228 323 minecraft:dark_prismarine
setblock 181 228 324 minecraft:blue_terracotta
setblock 181 228 328 minecraft:dark_prismarine
fill 181 228 329 182 229 330 minecraft:blue_terracotta
setblock 181 228 339 minecraft:blue_terracotta
setblock 181 228 343 minecraft:dark_prismarine
fill 181 228 344 181 229 344 minecraft:blue_terracotta
setblock 181 228 348 minecraft:dark_prismarine
fill 181 228 349 181 229 349 minecraft:blue_terracotta
fill 182 228 323 182 229 323 minecraft:blue_terracotta
setblock 182 228 327 minecraft:dark_prismarine
fill 182 228 328 182 229 328 minecraft:blue_terracotta
setblock 182 228 331 minecraft:blue_terracotta
setblock 182 228 332 minecraft:dark_prismarine
fill 182 228 333 182 229 333 minecraft:blue_terracotta
setblock 182 228 337 minecraft:dark_prismarine
fill 182 228 338 182 229 338 minecraft:blue_terracotta
setblock 182 228 342 minecraft:dark_prismarine
fill 182 228 343 182 229 343 minecraft:blue_terracotta
setblock 182 228 347 minecraft:dark_prismarine
fill 182 228 348 182 229 348 minecraft:blue_terracotta
setblock 182 228 351 minecraft:blue_terracotta
setblock 182 228 352 minecraft:dark_prismarine
fill 141 229 338 141 308 338 minecraft:blue_concrete
setblock 142 229 326 minecraft:dark_prismarine
setblock 142 229 327 minecraft:blue_terracotta
setblock 142 229 331 minecraft:dark_prismarine
setblock 142 229 332 minecraft:blue_terracotta
setblock 142 229 340 minecraft:purple_concrete
setblock 142 229 342 minecraft:blue_terracotta
setblock 142 229 346 minecraft:dark_prismarine
setblock 142 229 347 minecraft:blue_terracotta
setblock 142 229 359 minecraft:purple_concrete
setblock 143 229 324 minecraft:blue_terracotta
setblock 143 229 325 minecraft:dark_prismarine
setblock 143 229 326 minecraft:blue_terracotta
setblock 143 229 330 minecraft:dark_prismarine
setblock 143 229 331 minecraft:blue_terracotta
setblock 144 229 324 minecraft:dark_prismarine
setblock 144 229 325 minecraft:blue_terracotta
setblock 144 229 328 minecraft:blue_terracotta
setblock 144 229 333 minecraft:light[level=13]
setblock 144 229 341 minecraft:light[level=13]
setblock 144 229 349 minecraft:light[level=13]
setblock 144 229 357 minecraft:light[level=13]
setblock 145 229 323 minecraft:dark_prismarine
setblock 145 229 324 minecraft:blue_terracotta
setblock 146 229 323 minecraft:blue_terracotta
setblock 146 229 363 minecraft:blue_terracotta
setblock 147 229 325 minecraft:blue_terracotta
setblock 148 229 325 minecraft:dark_prismarine
setblock 148 229 326 minecraft:blue_terracotta
fill 149 229 322 149 308 322 minecraft:blue_concrete
setblock 149 229 324 minecraft:dark_prismarine
setblock 149 229 325 minecraft:blue_terracotta
setblock 149 229 362 minecraft:blue_terracotta
setblock 150 229 323 minecraft:dark_prismarine
setblock 150 229 324 minecraft:blue_terracotta
setblock 150 229 363 minecraft:dark_prismarine
setblock 151 229 323 minecraft:blue_terracotta
setblock 151 229 326 minecraft:blue_terracotta
setblock 151 229 362 minecraft:dark_prismarine
setblock 151 229 363 minecraft:blue_terracotta
setblock 152 229 326 minecraft:dark_prismarine
setblock 152 229 333 minecraft:light[level=13]
setblock 152 229 341 minecraft:light[level=13]
setblock 152 229 349 minecraft:light[level=13]
setblock 152 229 357 minecraft:light[level=13]
setblock 152 229 362 minecraft:blue_terracotta
setblock 153 229 325 minecraft:dark_prismarine
setblock 153 229 326 minecraft:blue_terracotta
setblock 153 229 361 minecraft:blue_terracotta
setblock 154 229 324 minecraft:dark_prismarine
setblock 154 229 325 minecraft:blue_terracotta
setblock 155 229 323 minecraft:dark_prismarine
setblock 155 229 324 minecraft:blue_terracotta
setblock 155 229 363 minecraft:dark_prismarine
setblock 156 229 323 minecraft:blue_terracotta
setblock 156 229 362 minecraft:dark_prismarine
fill 156 229 363 159 229 363 minecraft:blue_terracotta
setblock 157 229 362 minecraft:blue_terracotta
setblock 158 229 325 minecraft:dark_prismarine
setblock 159 229 324 minecraft:dark_prismarine
setblock 159 229 325 minecraft:blue_terracotta
setblock 160 229 323 minecraft:dark_prismarine
setblock 160 229 324 minecraft:blue_terracotta
setblock 160 229 325 minecraft:light[level=13]
setblock 160 229 333 minecraft:light[level=13]
setblock 160 229 341 minecraft:light[level=13]
setblock 160 229 349 minecraft:light[level=13]
setblock 160 229 357 minecraft:light[level=13]
setblock 160 229 363 minecraft:dark_prismarine
fill 161 229 323 164 229 323 minecraft:blue_terracotta
setblock 161 229 363 minecraft:blue_terracotta
setblock 165 229 323 minecraft:dark_prismarine
setblock 165 229 363 minecraft:dark_prismarine
setblock 166 229 323 minecraft:blue_terracotta
setblock 166 229 363 minecraft:blue_terracotta
setblock 168 229 325 minecraft:light[level=13]
setblock 168 229 333 minecraft:light[level=13]
setblock 168 229 341 minecraft:light[level=13]
setblock 168 229 349 minecraft:light[level=13]
setblock 168 229 357 minecraft:light[level=13]
fill 169 229 322 172 292 322 minecraft:blue_concrete
setblock 169 229 324 minecraft:dark_prismarine
fill 169 229 357 169 234 357 minecraft:magenta_terracotta
setblock 170 229 323 minecraft:dark_prismarine
fill 170 229 324 173 229 324 minecraft:blue_terracotta
setblock 170 229 363 minecraft:dark_prismarine
setblock 171 229 323 minecraft:blue_terracotta
setblock 171 229 362 minecraft:dark_prismarine
setblock 171 229 363 minecraft:blue_terracotta
setblock 172 229 362 minecraft:blue_terracotta
setblock 173 229 322 minecraft:light_blue_wool
setblock 173 229 325 minecraft:dark_prismarine
fill 174 229 322 175 308 322 minecraft:blue_concrete
setblock 174 229 324 minecraft:dark_prismarine
setblock 174 229 325 minecraft:blue_terracotta
setblock 175 229 323 minecraft:dark_prismarine
setblock 175 229 324 minecraft:blue_terracotta
fill 175 229 340 175 230 340 minecraft:magenta_terracotta
setblock 175 229 363 minecraft:dark_prismarine
setblock 176 229 323 minecraft:blue_terracotta
setblock 176 229 333 minecraft:light[level=13]
setblock 176 229 349 minecraft:light[level=13]
setblock 176 229 357 minecraft:light[level=13]
setblock 176 229 363 minecraft:blue_terracotta
setblock 179 229 324 minecraft:dark_prismarine
setblock 180 229 323 minecraft:dark_prismarine
setblock 180 229 324 minecraft:blue_terracotta
setblock 180 229 343 minecraft:dark_prismarine
setblock 180 229 344 minecraft:blue_terracotta
setblock 180 229 348 minecraft:dark_prismarine
setblock 180 229 349 minecraft:blue_terracotta
setblock 181 229 323 minecraft:blue_terracotta
setblock 181 229 326 minecraft:blue_terracotta
setblock 181 229 327 minecraft:dark_prismarine
setblock 181 229 328 minecraft:blue_terracotta
setblock 181 229 331 minecraft:blue_terracotta
setblock 181 229 342 minecraft:dark_prismarine
setblock 181 229 343 minecraft:blue_terracotta
setblock 181 229 347 minecraft:dark_prismarine
setblock 181 229 348 minecraft:blue_terracotta
setblock 182 229 326 minecraft:dark_prismarine
setblock 182 229 327 minecraft:blue_terracotta
setblock 182 229 331 minecraft:dark_prismarine
setblock 182 229 332 minecraft:blue_terracotta
setblock 182 229 336 minecraft:dark_prismarine
setblock 182 229 337 minecraft:blue_terracotta
setblock 182 229 341 minecraft:dark_prismarine
setblock 182 229 342 minecraft:blue_terracotta
setblock 182 229 346 minecraft:dark_prismarine
setblock 182 229 347 minecraft:blue_terracotta
setblock 182 229 351 minecraft:dark_prismarine
setblock 182 229 352 minecraft:blue_terracotta
setblock 182 229 363 minecraft:purple_concrete
setblock 153 230 322 minecraft:light_blue_wool
fill 173 230 322 173 308 322 minecraft:blue_concrete
fill 176 230 339 176 233 339 minecraft:magenta_terracotta
fill 181 230 322 181 290 322 minecraft:blue_concrete
setblock 182 230 322 minecraft:light_blue_wool
fill 141 231 345 141 305 345 minecraft:blue_concrete
setblock 141 231 346 minecraft:cyan_concrete
fill 141 231 347 141 308 347 minecraft:blue_concrete
fill 148 231 343 154 248 345 minecraft:jungle_log
fill 149 231 342 153 249 342 minecraft:jungle_log
fill 149 231 346 153 249 346 minecraft:jungle_log
fill 150 231 341 152 249 341 minecraft:jungle_log
fill 150 231 347 152 249 347 minecraft:jungle_log
fill 153 231 322 153 290 322 minecraft:blue_concrete
fill 182 231 322 182 234 322 minecraft:blue_concrete
fill 141 232 346 141 308 346 minecraft:blue_concrete
fill 175 232 340 175 234 340 minecraft:magenta_terracotta
setblock 144 233 325 minecraft:light[level=12]
setblock 144 233 332 minecraft:light[level=12]
setblock 144 233 339 minecraft:light[level=12]
setblock 144 233 346 minecraft:light[level=12]
setblock 144 233 353 minecraft:light[level=12]
setblock 144 233 360 minecraft:light[level=12]
setblock 151 233 325 minecraft:light[level=12]
setblock 151 233 332 minecraft:light[level=12]
setblock 151 233 339 minecraft:light[level=12]
setblock 151 233 353 minecraft:light[level=12]
setblock 151 233 360 minecraft:light[level=12]
fill 155 233 329 155 234 329 minecraft:magenta_terracotta
fill 156 233 330 156 234 330 minecraft:magenta_terracotta
setblock 158 233 325 minecraft:light[level=12]
setblock 158 233 332 minecraft:light[level=12]
setblock 158 233 339 minecraft:light[level=12]
setblock 158 233 346 minecraft:light[level=12]
setblock 158 233 353 minecraft:light[level=12]
setblock 158 233 360 minecraft:light[level=12]
setblock 165 233 325 minecraft:light[level=12]
setblock 165 233 332 minecraft:light[level=12]
setblock 165 233 339 minecraft:light[level=12]
setblock 165 233 346 minecraft:light[level=12]
setblock 165 233 353 minecraft:light[level=12]
setblock 165 233 360 minecraft:light[level=12]
setblock 172 233 325 minecraft:light[level=12]
setblock 172 233 332 minecraft:light[level=12]
setblock 172 233 339 minecraft:light[level=12]
setblock 172 233 346 minecraft:light[level=12]
setblock 172 233 353 minecraft:light[level=12]
setblock 172 233 360 minecraft:light[level=12]
setblock 179 233 325 minecraft:light[level=12]
setblock 179 233 332 minecraft:light[level=12]
setblock 179 233 339 minecraft:light[level=12]
setblock 179 233 346 minecraft:light[level=12]
setblock 179 233 353 minecraft:light[level=12]
setblock 179 233 360 minecraft:light[level=12]
setblock 166 234 364 minecraft:cyan_concrete
fill 167 234 364 167 308 364 minecraft:blue_concrete
setblock 170 234 357 minecraft:magenta_terracotta
fill 142 235 323 144 237 323 minecraft:black_stained_glass
fill 142 235 324 142 237 331 minecraft:black_wool
fill 142 235 332 144 237 336 minecraft:black_stained_glass
fill 142 235 337 145 237 344 minecraft:black_wool
fill 142 235 345 143 237 349 minecraft:black_stained_glass
fill 142 235 350 145 237 356 minecraft:black_wool
fill 142 235 357 143 237 361 minecraft:black_stained_glass
fill 142 235 362 146 237 363 minecraft:black_wool
fill 143 235 324 143 237 324 minecraft:black_stained_glass
fill 143 235 325 145 237 331 minecraft:black_wool
fill 144 235 324 151 237 324 minecraft:black_wool
fill 144 235 345 144 237 348 minecraft:black_stained_glass
fill 144 235 349 150 237 349 minecraft:black_wool
fill 144 235 357 150 237 357 minecraft:black_wool
fill 144 235 358 144 237 361 minecraft:black_stained_glass
fill 145 235 323 150 237 323 minecraft:black_wool
fill 145 235 332 149 237 336 minecraft:black_wool
fill 145 235 345 147 237 348 minecraft:black_wool
fill 145 235 358 149 237 361 minecraft:black_wool
fill 146 235 325 182 237 325 minecraft:black_wool
fill 146 235 326 148 237 329 minecraft:black_stained_glass
fill 146 235 330 146 237 331 minecraft:black_wool
fill 146 235 337 146 237 338 minecraft:black_wool
fill 146 235 339 148 237 342 minecraft:black_stained_glass
fill 146 235 343 147 237 344 minecraft:black_wool
fill 146 235 350 182 237 350 minecraft:black_wool
fill 146 235 351 148 237 355 minecraft:black_stained_glass
fill 146 235 356 182 237 356 minecraft:black_wool
fill 147 235 330 148 237 330 minecraft:black_stained_glass
fill 147 235 331 182 237 331 minecraft:black_wool
fill 147 235 337 182 237 337 minecraft:black_wool
fill 147 235 338 148 237 338 minecraft:black_stained_glass
fill 147 235 362 182 237 362 minecraft:black_wool
fill 147 235 363 147 237 363 minecraft:black_stained_glass
fill 148 235 346 148 237 348 minecraft:black_wool
fill 148 235 363 155 237 363 minecraft:black_wool
fill 149 235 326 154 237 326 minecraft:black_wool
fill 149 235 327 149 237 328 minecraft:black_stained_glass
fill 149 235 329 154 237 330 minecraft:black_wool
fill 149 235 338 154 237 339 minecraft:black_wool
fill 149 235 340 149 237 341 minecraft:black_stained_glass
fill 149 235 347 149 237 348 minecraft:black_wool
fill 149 235 351 154 237 352 minecraft:black_wool
fill 149 235 353 149 237 353 minecraft:black_stained_glass
fill 149 235 354 154 237 355 minecraft:black_wool
fill 150 235 327 154 237 328 minecraft:black_wool
fill 150 235 332 150 237 332 minecraft:black_wool
fill 150 235 333 153 237 335 minecraft:black_stained_glass
fill 150 235 336 150 237 336 minecraft:black_wool
fill 150 235 340 154 237 340 minecraft:black_wool
fill 150 235 348 150 237 348 minecraft:black_wool
fill 150 235 353 154 237 353 minecraft:black_wool
fill 150 235 358 150 237 358 minecraft:black_wool
fill 150 235 359 153 237 360 minecraft:black_stained_glass
fill 150 235 361 150 237 361 minecraft:black_wool
fill 151 235 323 153 237 323 minecraft:black_stained_glass
fill 151 235 332 153 237 332 minecraft:black_stained_glass
fill 151 235 336 153 237 336 minecraft:black_stained_glass
fill 151 235 348 152 237 349 minecraft:black_stained_glass
fill 151 235 357 152 237 358 minecraft:black_stained_glass
fill 151 235 361 153 237 361 minecraft:black_stained_glass
fill 152 235 324 152 237 324 minecraft:black_stained_glass
fill 153 235 324 160 237 324 minecraft:black_wool
fill 153 235 341 154 237 341 minecraft:black_wool
fill 153 235 347 153 237 348 minecraft:black_stained_glass
fill 153 235 349 159 237 349 minecraft:black_wool
fill 153 235 357 159 237 357 minecraft:black_wool
fill 153 235 358 153 237 358 minecraft:black_stained_glass
fill 154 235 323 159 237 323 minecraft:black_wool
fill 154 235 332 158 237 336 minecraft:black_wool
fill 154 235 342 154 237 342 minecraft:black_wool
fill 154 235 346 158 237 348 minecraft:black_wool
fill 154 235 358 158 237 361 minecraft:black_wool
fill 155 235 326 157 237 329 minecraft:black_stained_glass
fill 155 235 330 155 237 330 minecraft:black_wool
fill 155 235 338 155 237 338 minecraft:black_wool
fill 155 235 339 157 237 342 minecraft:black_stained_glass
fill 155 235 343 159 236 345 minecraft:black_wool
fill 155 235 351 157 237 355 minecraft:black_stained_glass
fill 156 235 330 157 237 330 minecraft:black_stained_glass
fill 156 235 338 157 237 338 minecraft:black_stained_glass
fill 156 235 363 156 237 363 minecraft:black_stained_glass
fill 157 235 363 164 237 363 minecraft:black_wool
fill 158 235 326 163 237 327 minecraft:black_wool
fill 158 235 328 158 237 328 minecraft:black_stained_glass
fill 158 235 329 163 237 330 minecraft:black_wool
fill 158 235 338 163 237 339 minecraft:black_wool
fill 158 235 340 158 237 340 minecraft:black_stained_glass
fill 158 235 341 160 236 342 minecraft:black_wool
fill 158 235 351 163 237 352 minecraft:black_wool
fill 158 235 353 158 237 353 minecraft:black_stained_glass
fill 158 235 354 163 237 355 minecraft:black_wool
fill 159 235 328 163 237 328 minecraft:black_wool
fill 159 235 332 159 237 332 minecraft:black_wool
fill 159 235 333 162 237 335 minecraft:black_stained_glass
fill 159 235 336 159 237 336 minecraft:black_wool
fill 159 235 340 163 237 340 minecraft:black_wool
fill 159 235 346 160 236 347 minecraft:black_stained_glass
fill 159 235 348 159 237 348 minecraft:black_wool
fill 159 235 353 163 237 353 minecraft:black_wool
fill 159 235 358 162 237 360 minecraft:black_stained_glass
fill 159 235 361 159 237 361 minecraft:black_wool
fill 160 235 323 162 237 323 minecraft:black_stained_glass
fill 160 235 332 162 237 332 minecraft:black_stained_glass
fill 160 235 336 162 237 336 minecraft:black_stained_glass
fill 160 235 348 161 237 349 minecraft:black_stained_glass
fill 160 235 357 161 237 357 minecraft:black_stained_glass
fill 160 235 361 162 237 361 minecraft:black_stained_glass
fill 161 235 324 161 237 324 minecraft:black_stained_glass
fill 161 235 341 163 236 341 minecraft:black_wool
fill 161 235 347 162 236 347 minecraft:black_stained_glass
fill 162 235 324 169 237 324 minecraft:black_wool
fill 162 235 348 162 237 348 minecraft:black_stained_glass
fill 162 235 349 168 237 349 minecraft:black_wool
fill 162 235 357 168 237 357 minecraft:black_wool
fill 163 235 323 168 237 323 minecraft:black_wool
fill 163 235 332 167 237 336 minecraft:black_wool
fill 163 235 347 167 236 348 minecraft:black_wool
fill 163 235 358 167 237 361 minecraft:black_wool
fill 164 235 326 166 237 330 minecraft:black_stained_glass
fill 164 235 338 164 237 338 minecraft:black_wool
fill 164 235 339 166 236 342 minecraft:black_stained_glass
fill 164 235 346 167 236 346 minecraft:black_wool
fill 164 235 351 166 237 355 minecraft:black_stained_glass
fill 165 235 338 166 237 338 minecraft:black_stained_glass
fill 165 235 343 168 236 345 minecraft:black_wool
fill 165 235 363 165 237 363 minecraft:black_stained_glass
fill 166 235 363 173 237 363 minecraft:black_wool
fill 166 235 364 166 273 364 minecraft:blue_concrete
fill 167 235 326 172 237 330 minecraft:black_wool
fill 167 235 338 172 237 342 minecraft:black_wool
fill 167 235 351 172 237 355 minecraft:black_wool
fill 168 235 332 168 237 332 minecraft:black_wool
fill 168 235 333 171 237 335 minecraft:black_stained_glass
fill 168 235 336 168 237 336 minecraft:black_wool
fill 168 235 346 171 237 348 minecraft:black_stained_glass
fill 168 235 358 171 237 360 minecraft:black_stained_glass
fill 168 235 361 168 237 361 minecraft:black_wool
fill 169 235 323 171 237 323 minecraft:black_stained_glass
fill 169 235 332 171 237 332 minecraft:black_stained_glass
fill 169 235 336 171 237 336 minecraft:black_stained_glass
fill 169 235 343 182 237 344 minecraft:black_wool
fill 169 235 345 171 237 345 minecraft:black_stained_glass
fill 169 235 349 170 237 349 minecraft:black_stained_glass
fill 169 235 357 170 237 357 minecraft:black_stained_glass
fill 169 235 361 171 237 361 minecraft:black_stained_glass
fill 170 235 324 170 237 324 minecraft:black_stained_glass
fill 171 235 324 178 237 324 minecraft:black_wool
fill 171 235 349 177 237 349 minecraft:black_wool
fill 171 235 357 177 237 357 minecraft:black_wool
fill 172 235 323 177 237 323 minecraft:black_wool
fill 172 235 332 176 237 336 minecraft:black_wool
fill 172 235 345 176 237 348 minecraft:black_wool
fill 172 235 358 176 237 361 minecraft:black_wool
fill 173 235 326 175 237 330 minecraft:black_stained_glass
fill 173 235 338 173 237 338 minecraft:black_wool
fill 173 235 339 175 237 342 minecraft:black_stained_glass
fill 173 235 351 175 237 355 minecraft:black_stained_glass
fill 174 235 338 175 237 338 minecraft:black_stained_glass
fill 174 235 363 174 237 363 minecraft:black_stained_glass
fill 175 235 363 182 237 363 minecraft:black_wool
fill 176 235 326 181 237 330 minecraft:black_wool
fill 176 235 338 181 237 342 minecraft:black_wool
fill 176 235 351 181 237 355 minecraft:black_wool
fill 177 235 332 177 237 332 minecraft:black_wool
fill 177 235 333 180 237 335 minecraft:black_stained_glass
fill 177 235 336 177 237 336 minecraft:black_wool
fill 177 235 345 177 237 345 minecraft:black_wool
fill 177 235 346 180 237 348 minecraft:black_stained_glass
fill 177 235 358 180 237 360 minecraft:black_stained_glass
fill 177 235 361 177 237 361 minecraft:black_wool
fill 178 235 323 180 237 323 minecraft:black_stained_glass
fill 178 235 332 179 237 332 minecraft:black_stained_glass
fill 178 235 336 180 237 336 minecraft:black_stained_glass
fill 178 235 345 180 237 345 minecraft:black_stained_glass
fill 178 235 349 179 237 349 minecraft:black_stained_glass
fill 178 235 357 179 237 357 minecraft:black_stained_glass
fill 178 235 361 180 237 361 minecraft:black_stained_glass
fill 179 235 324 179 237 324 minecraft:black_stained_glass
fill 180 235 324 182 237 324 minecraft:black_wool
fill 180 235 332 182 237 332 minecraft:black_wool
fill 180 235 349 182 237 349 minecraft:black_wool
fill 180 235 357 182 237 357 minecraft:black_wool
fill 181 235 323 182 237 323 minecraft:black_wool
fill 181 235 333 182 237 336 minecraft:black_wool
fill 181 235 345 182 237 348 minecraft:black_wool
fill 181 235 358 182 237 361 minecraft:black_wool
setblock 182 235 322 minecraft:light_blue_wool
fill 182 235 326 182 237 330 minecraft:black_stained_glass
fill 182 235 338 182 237 338 minecraft:black_wool
fill 182 235 339 182 237 342 minecraft:black_stained_glass
fill 182 235 351 182 237 355 minecraft:black_stained_glass
fill 182 236 322 182 282 322 minecraft:blue_concrete
setblock 141 237 326 minecraft:light_blue_wool
fill 141 237 328 141 249 332 minecraft:blue_concrete
setblock 141 237 333 minecraft:light_blue_wool
fill 141 237 334 141 308 334 minecraft:blue_concrete
fill 155 237 343 158 237 345 minecraft:black_wool
fill 158 237 341 158 237 342 minecraft:black_wool
setblock 159 237 341 minecraft:black_wool
setblock 159 237 342 minecraft:sea_lantern
fill 159 237 343 159 237 345 minecraft:ochre_froglight
setblock 159 237 346 minecraft:sea_lantern
setblock 159 237 347 minecraft:black_stained_glass
setblock 160 237 341 minecraft:sea_lantern
setblock 160 237 342 minecraft:ochre_froglight
setblock 160 237 346 minecraft:ochre_froglight
setblock 160 237 347 minecraft:sea_lantern
fill 161 237 341 163 237 341 minecraft:ochre_froglight
fill 161 237 347 163 237 347 minecraft:ochre_froglight
fill 163 237 348 167 237 348 minecraft:black_wool
fill 164 237 339 166 237 340 minecraft:black_stained_glass
setblock 164 237 341 minecraft:sea_lantern
setblock 164 237 342 minecraft:ochre_froglight
setblock 164 237 346 minecraft:ochre_froglight
setblock 164 237 347 minecraft:sea_lantern
fill 165 237 341 166 237 341 minecraft:black_stained_glass
setblock 165 237 342 minecraft:sea_lantern
fill 165 237 343 165 237 345 minecraft:ochre_froglight
setblock 165 237 346 minecraft:sea_lantern
fill 165 237 347 167 237 347 minecraft:black_wool
setblock 166 237 342 minecraft:black_stained_glass
fill 166 237 343 167 237 346 minecraft:black_wool
fill 168 237 343 168 237 345 minecraft:black_wool
fill 168 237 364 168 245 364 minecraft:blue_concrete
setblock 169 237 364 minecraft:cyan_concrete
fill 170 237 364 171 308 364 minecraft:blue_concrete
fill 141 238 326 141 308 326 minecraft:blue_concrete
fill 141 238 333 141 308 333 minecraft:blue_concrete
fill 148 238 346 148 246 346 minecraft:magenta_terracotta
fill 154 238 330 156 242 330 minecraft:magenta_terracotta
fill 155 238 329 155 270 329 minecraft:magenta_terracotta
fill 155 238 358 156 262 359 minecraft:magenta_terracotta
fill 168 238 327 170 247 327 minecraft:magenta_terracotta
fill 169 238 328 169 262 328 minecraft:magenta_terracotta
fill 169 238 356 170 242 357 minecraft:magenta_terracotta
fill 169 238 364 169 262 364 minecraft:blue_concrete
fill 175 238 340 177 238 340 minecraft:magenta_terracotta
fill 176 238 341 177 250 341 minecraft:magenta_terracotta
setblock 144 239 325 minecraft:light[level=12]
setblock 144 239 332 minecraft:light[level=12]
setblock 144 239 339 minecraft:light[level=12]
setblock 144 239 346 minecraft:light[level=12]
setblock 144 239 353 minecraft:light[level=12]
setblock 144 239 360 minecraft:light[level=12]
setblock 151 239 325 minecraft:light[level=12]
setblock 151 239 332 minecraft:light[level=12]
setblock 151 239 339 minecraft:light[level=12]
setblock 151 239 353 minecraft:light[level=12]
setblock 151 239 360 minecraft:light[level=12]
fill 158 239 322 158 308 322 minecraft:blue_concrete
setblock 158 239 325 minecraft:light[level=12]
setblock 158 239 332 minecraft:light[level=12]
setblock 158 239 339 minecraft:light[level=12]
setblock 158 239 346 minecraft:light[level=12]
setblock 158 239 353 minecraft:light[level=12]
setblock 158 239 360 minecraft:light[level=12]
setblock 159 239 322 minecraft:cyan_concrete
fill 161 239 322 161 308 322 minecraft:blue_concrete
setblock 162 239 322 minecraft:light_blue_wool
fill 163 239 322 167 297 322 minecraft:blue_concrete
setblock 165 239 325 minecraft:light[level=12]
setblock 165 239 332 minecraft:light[level=12]
setblock 165 239 339 minecraft:light[level=12]
setblock 165 239 346 minecraft:light[level=12]
setblock 165 239 353 minecraft:light[level=12]
setblock 165 239 360 minecraft:light[level=12]
setblock 172 239 325 minecraft:light[level=12]
setblock 172 239 332 minecraft:light[level=12]
setblock 172 239 339 minecraft:light[level=12]
setblock 172 239 346 minecraft:light[level=12]
setblock 172 239 353 minecraft:light[level=12]
setblock 172 239 360 minecraft:light[level=12]
fill 176 239 340 177 240 340 minecraft:magenta_terracotta
setblock 179 239 325 minecraft:light[level=12]
setblock 179 239 332 minecraft:light[level=12]
setblock 179 239 339 minecraft:light[level=12]
setblock 179 239 346 minecraft:light[level=12]
setblock 179 239 353 minecraft:light[level=12]
setblock 179 239 360 minecraft:light[level=12]
setblock 183 239 332 minecraft:light_blue_wool
fill 183 239 333 183 265 336 minecraft:blue_concrete
fill 159 240 322 159 308 322 minecraft:blue_concrete
fill 162 240 322 162 308 322 minecraft:blue_concrete
fill 183 240 332 183 308 332 minecraft:blue_concrete
setblock 142 241 323 minecraft:blue_terracotta
setblock 142 241 324 minecraft:dark_prismarine
fill 142 241 325 142 241 328 minecraft:blue_terracotta
setblock 142 241 329 minecraft:dark_prismarine
fill 142 241 330 142 241 333 minecraft:blue_terracotta
setblock 142 241 334 minecraft:dark_prismarine
fill 142 241 335 142 241 338 minecraft:blue_terracotta
setblock 142 241 339 minecraft:dark_prismarine
fill 142 241 340 142 244 340 minecraft:blue_terracotta
setblock 142 241 349 minecraft:purple_concrete
fill 142 241 351 142 241 353 minecraft:blue_terracotta
setblock 142 241 354 minecraft:dark_prismarine
fill 142 241 355 142 241 358 minecraft:blue_terracotta
setblock 142 241 359 minecraft:dark_prismarine
fill 142 241 360 142 241 363 minecraft:blue_terracotta
setblock 143 241 323 minecraft:dark_prismarine
fill 143 241 324 143 241 327 minecraft:blue_terracotta
setblock 143 241 328 minecraft:dark_prismarine
fill 143 241 329 143 241 332 minecraft:blue_terracotta
setblock 143 241 333 minecraft:dark_prismarine
fill 143 241 334 143 241 337 minecraft:blue_terracotta
setblock 143 241 338 minecraft:dark_prismarine
setblock 143 241 352 minecraft:blue_terracotta
setblock 143 241 353 minecraft:dark_prismarine
fill 143 241 354 143 241 357 minecraft:blue_terracotta
setblock 143 241 358 minecraft:dark_prismarine
fill 143 241 359 143 241 362 minecraft:blue_terracotta
setblock 143 241 363 minecraft:dark_prismarine
fill 144 241 323 146 241 324 minecraft:blue_terracotta
fill 144 241 329 144 241 331 minecraft:blue_terracotta
setblock 144 241 332 minecraft:dark_prismarine
fill 144 241 333 144 241 336 minecraft:blue_terracotta
fill 144 241 354 144 241 356 minecraft:blue_terracotta
setblock 144 241 357 minecraft:dark_prismarine
fill 144 241 358 144 241 361 minecraft:blue_terracotta
setblock 144 241 362 minecraft:dark_prismarine
fill 144 241 363 147 241 363 minecraft:blue_terracotta
setblock 145 241 356 minecraft:dark_prismarine
fill 145 241 357 145 241 360 minecraft:blue_terracotta
setblock 145 241 361 minecraft:dark_prismarine
fill 145 241 362 148 241 362 minecraft:blue_terracotta
setblock 146 241 360 minecraft:dark_prismarine
fill 146 241 361 149 241 361 minecraft:blue_terracotta
setblock 147 241 323 minecraft:blue_terracotta
setblock 147 241 324 minecraft:dark_prismarine
fill 147 241 360 150 241 360 minecraft:blue_terracotta
setblock 148 241 323 minecraft:dark_prismarine
fill 148 241 324 149 243 324 minecraft:blue_terracotta
setblock 148 241 363 minecraft:dark_prismarine
fill 149 241 323 152 241 323 minecraft:blue_terracotta
setblock 149 241 362 minecraft:dark_prismarine
fill 149 241 363 152 241 363 minecraft:blue_terracotta
setblock 150 241 361 minecraft:dark_prismarine
fill 150 241 362 153 241 362 minecraft:blue_terracotta
setblock 151 241 360 minecraft:dark_prismarine
fill 151 241 361 153 242 361 minecraft:blue_terracotta
setblock 152 241 358 minecraft:spruce_planks
setblock 153 241 363 minecraft:dark_prismarine
setblock 154 241 362 minecraft:dark_prismarine
fill 154 241 363 157 241 363 minecraft:blue_terracotta
fill 160 241 363 162 241 363 minecraft:blue_terracotta
setblock 163 241 362 minecraft:blue_terracotta
setblock 163 241 363 minecraft:dark_prismarine
fill 163 241 364 163 308 364 minecraft:blue_concrete
setblock 164 241 362 minecraft:dark_prismarine
fill 164 241 363 167 241 363 minecraft:blue_terracotta
setblock 164 241 364 minecraft:cyan_concrete
fill 165 241 362 168 241 362 minecraft:blue_terracotta
setblock 168 241 323 minecraft:dark_prismarine
fill 168 241 336 173 241 338 minecraft:black_concrete
setblock 168 241 363 minecraft:dark_prismarine
fill 169 241 335 173 241 335 minecraft:black_concrete
fill 169 241 339 173 241 339 minecraft:black_concrete
setblock 169 241 362 minecraft:dark_prismarine
fill 169 241 363 171 242 363 minecraft:blue_terracotta
fill 170 241 334 171 241 334 minecraft:black_concrete
fill 170 241 340 171 241 340 minecraft:black_concrete
setblock 172 241 363 minecraft:purple_concrete
fill 175 241 341 175 255 341 minecraft:magenta_terracotta
fill 176 241 340 176 248 340 minecraft:magenta_terracotta
setblock 177 241 323 minecraft:purple_concrete
fill 180 241 332 180 241 335 minecraft:blue_terracotta
setblock 180 241 336 minecraft:dark_prismarine
fill 181 241 328 181 241 329 minecraft:blue_terracotta
setblock 181 241 330 minecraft:dark_prismarine
fill 181 241 331 181 241 334 minecraft:blue_terracotta
setblock 181 241 335 minecraft:dark_prismarine
fill 181 241 336 181 241 339 minecraft:blue_terracotta
setblock 182 241 323 minecraft:blue_terracotta
setblock 182 241 324 minecraft:dark_prismarine
fill 182 241 325 182 241 328 minecraft:blue_terracotta
setblock 182 241 329 minecraft:dark_prismarine
fill 182 241 330 182 241 333 minecraft:blue_terracotta
setblock 182 241 334 minecraft:dark_prismarine
fill 182 241 335 182 241 338 minecraft:blue_terracotta
setblock 182 241 339 minecraft:dark_prismarine
fill 182 241 340 182 242 342 minecraft:blue_terracotta
fill 182 241 352 182 241 353 minecraft:blue_terracotta
setblock 182 241 354 minecraft:dark_prismarine
fill 182 241 355 182 241 358 minecraft:blue_terracotta
setblock 182 241 359 minecraft:dark_prismarine
fill 182 241 360 182 242 362 minecraft:blue_terracotta
setblock 142 242 323 minecraft:dark_prismarine
fill 142 242 324 142 242 327 minecraft:blue_terracotta
setblock 142 242 328 minecraft:dark_prismarine
fill 142 242 329 142 242 332 minecraft:blue_terracotta
setblock 142 242 333 minecraft:dark_prismarine
fill 142 242 334 142 242 337 minecraft:blue_terracotta
setblock 142 242 338 minecraft:dark_prismarine
fill 142 242 339 143 244 339 minecraft:blue_terracotta
fill 142 242 341 142 243 341 minecraft:blue_terracotta
fill 142 242 351 142 242 352 minecraft:blue_terracotta
setblock 142 242 353 minecraft:dark_prismarine
fill 142 242 354 142 242 357 minecraft:blue_terracotta
setblock 142 242 358 minecraft:dark_prismarine
fill 142 242 359 142 242 362 minecraft:blue_terracotta
setblock 142 242 363 minecraft:dark_prismarine
fill 143 242 323 143 242 326 minecraft:blue_terracotta
setblock 143 242 327 minecraft:dark_prismarine
fill 143 242 328 143 242 331 minecraft:blue_terracotta
setblock 143 242 332 minecraft:dark_prismarine
fill 143 242 333 143 242 336 minecraft:blue_terracotta
setblock 143 242 337 minecraft:dark_prismarine
fill 143 242 338 143 245 338 minecraft:blue_terracotta
setblock 143 242 352 minecraft:dark_prismarine
fill 143 242 353 143 242 356 minecraft:blue_terracotta
setblock 143 242 357 minecraft:dark_prismarine
fill 143 242 358 143 242 361 minecraft:blue_terracotta
setblock 143 242 362 minecraft:dark_prismarine
fill 143 242 363 146 242 363 minecraft:blue_terracotta
fill 144 242 323 145 242 324 minecraft:blue_terracotta
setblock 144 242 330 minecraft:blue_terracotta
setblock 144 242 331 minecraft:dark_prismarine
fill 144 242 332 144 242 335 minecraft:blue_terracotta
setblock 144 242 336 minecraft:dark_prismarine
fill 144 242 337 144 245 337 minecraft:blue_terracotta
fill 144 242 338 145 242 339 minecraft:spruce_planks
fill 144 242 354 144 242 355 minecraft:blue_terracotta
setblock 144 242 356 minecraft:dark_prismarine
fill 144 242 357 144 242 360 minecraft:blue_terracotta
setblock 144 242 361 minecraft:dark_prismarine
fill 144 242 362 147 242 362 minecraft:blue_terracotta
setblock 145 242 355 minecraft:dark_prismarine
fill 145 242 356 145 242 359 minecraft:blue_terracotta
setblock 145 242 360 minecraft:dark_prismarine
fill 145 242 361 148 242 361 minecraft:blue_terracotta
setblock 146 242 323 minecraft:blue_terracotta
setblock 146 242 324 minecraft:dark_prismarine
fill 146 242 360 149 242 360 minecraft:blue_terracotta
setblock 147 242 323 minecraft:dark_prismarine
fill 147 242 324 147 245 324 minecraft:blue_terracotta
setblock 147 242 363 minecraft:dark_prismarine
fill 148 242 323 151 242 323 minecraft:blue_terracotta
setblock 148 242 362 minecraft:dark_prismarine
fill 148 242 363 151 242 363 minecraft:blue_terracotta
setblock 149 242 361 minecraft:dark_prismarine
fill 149 242 362 152 242 362 minecraft:blue_terracotta
setblock 150 242 360 minecraft:dark_prismarine
fill 150 242 361 150 245 361 minecraft:blue_terracotta
fill 151 242 360 151 243 360 minecraft:blue_terracotta
setblock 152 242 323 minecraft:dark_prismarine
setblock 152 242 363 minecraft:dark_prismarine
setblock 153 242 362 minecraft:dark_prismarine
fill 153 242 363 156 242 363 minecraft:blue_terracotta
fill 154 242 362 155 244 362 minecraft:blue_terracotta
setblock 157 242 363 minecraft:dark_prismarine
fill 158 242 363 161 242 363 minecraft:blue_terracotta
fill 161 242 362 162 242 362 minecraft:blue_terracotta
setblock 162 242 363 minecraft:dark_prismarine
setblock 163 242 362 minecraft:dark_prismarine
fill 163 242 363 166 242 363 minecraft:blue_terracotta
setblock 164 242 361 minecraft:dark_prismarine
fill 164 242 362 167 242 362 minecraft:blue_terracotta
fill 164 242 364 164 272 364 minecraft:blue_concrete
fill 165 242 361 167 243 361 minecraft:blue_terracotta
setblock 166 242 323 minecraft:blue_terracotta
setblock 167 242 323 minecraft:dark_prismarine
setblock 167 242 363 minecraft:dark_prismarine
fill 168 242 323 169 244 323 minecraft:blue_terracotta
setblock 168 242 362 minecraft:dark_prismarine
fill 168 242 363 168 245 363 minecraft:blue_terracotta
fill 169 242 336 169 246 336 minecraft:dark_prismarine
fill 169 242 362 169 245 362 minecraft:blue_terracotta
setblock 171 242 323 minecraft:purple_concrete
fill 171 242 339 171 243 339 minecraft:dark_prismarine
fill 172 242 336 172 246 336 minecraft:dark_prismarine
setblock 178 242 363 minecraft:purple_concrete
fill 180 242 332 180 242 334 minecraft:blue_terracotta
setblock 180 242 335 minecraft:dark_prismarine
fill 180 242 336 182 242 337 minecraft:blue_terracotta
setblock 181 242 323 minecraft:blue_terracotta
setblock 181 242 328 minecraft:blue_terracotta
setblock 181 242 329 minecraft:dark_prismarine
fill 181 242 330 181 242 333 minecraft:blue_terracotta
setblock 181 242 334 minecraft:dark_prismarine
fill 181 242 335 182 244 335 minecraft:blue_terracotta
setblock 181 242 338 minecraft:blue_terracotta
setblock 181 242 339 minecraft:dark_prismarine
fill 181 242 340 181 245 340 minecraft:blue_terracotta
setblock 181 242 363 minecraft:blue_terracotta
setblock 182 242 323 minecraft:dark_prismarine
fill 182 242 324 182 242 327 minecraft:blue_terracotta
setblock 182 242 328 minecraft:dark_prismarine
fill 182 242 329 182 242 332 minecraft:blue_terracotta
setblock 182 242 333 minecraft:dark_prismarine
fill 182 242 334 182 245 334 minecraft:blue_terracotta
setblock 182 242 338 minecraft:dark_prismarine
fill 182 242 339 182 245 339 minecraft:blue_terracotta
setblock 182 242 343 minecraft:dark_prismarine
setblock 182 242 352 minecraft:blue_terracotta
setblock 182 242 353 minecraft:dark_prismarine
fill 182 242 354 182 242 357 minecraft:blue_terracotta
setblock 182 242 358 minecraft:dark_prismarine
fill 182 242 359 182 245 359 minecraft:blue_terracotta
setblock 182 242 363 minecraft:dark_prismarine
fill 142 243 323 142 243 326 minecraft:blue_terracotta
setblock 142 243 327 minecraft:dark_prismarine
fill 142 243 328 142 243 331 minecraft:blue_terracotta
setblock 142 243 332 minecraft:dark_prismarine
fill 142 243 333 142 243 336 minecraft:blue_terracotta
setblock 142 243 337 minecraft:dark_prismarine
fill 142 243 338 142 246 338 minecraft:blue_terracotta
setblock 142 243 342 minecraft:dark_prismarine
setblock 142 243 351 minecraft:blue_terracotta
setblock 142 243 352 minecraft:dark_prismarine
fill 142 243 353 142 243 356 minecraft:blue_terracotta
setblock 142 243 357 minecraft:dark_prismarine
fill 142 243 358 142 243 361 minecraft:blue_terracotta
setblock 142 243 362 minecraft:dark_prismarine
fill 142 243 363 145 243 363 minecraft:blue_terracotta
fill 143 243 323 143 243 325 minecraft:blue_terracotta
setblock 143 243 326 minecraft:dark_prismarine
fill 143 243 327 143 243 330 minecraft:blue_terracotta
setblock 143 243 331 minecraft:dark_prismarine
fill 143 243 332 143 243 335 minecraft:blue_terracotta
setblock 143 243 336 minecraft:dark_prismarine
fill 143 243 337 143 246 337 minecraft:blue_terracotta
setblock 143 243 340 minecraft:blue_terracotta
fill 143 243 352 143 243 355 minecraft:blue_terracotta
setblock 143 243 356 minecraft:dark_prismarine
fill 143 243 357 143 243 360 minecraft:blue_terracotta
setblock 143 243 361 minecraft:dark_prismarine
fill 143 243 362 146 243 362 minecraft:blue_terracotta
fill 144 243 323 144 243 324 minecraft:blue_terracotta
fill 144 243 331 144 243 334 minecraft:blue_terracotta
setblock 144 243 335 minecraft:dark_prismarine
fill 144 243 336 144 245 336 minecraft:blue_terracotta
fill 144 243 338 144 244 338 minecraft:blue_terracotta
fill 144 243 339 145 243 339 minecraft:spruce_planks
fill 144 243 353 144 243 354 minecraft:blue_terracotta
setblock 144 243 355 minecraft:dark_prismarine
fill 144 243 356 144 243 359 minecraft:blue_terracotta
setblock 144 243 360 minecraft:dark_prismarine
fill 144 243 361 147 243 361 minecraft:blue_terracotta
setblock 145 243 323 minecraft:blue_terracotta
setblock 145 243 324 minecraft:dark_prismarine
setblock 145 243 338 minecraft:spruce_planks
fill 145 243 355 145 243 358 minecraft:blue_terracotta
setblock 145 243 359 minecraft:dark_prismarine
fill 145 243 360 148 243 360 minecraft:blue_terracotta
setblock 146 243 323 minecraft:dark_prismarine
fill 146 243 324 146 246 324 minecraft:blue_terracotta
setblock 146 243 358 minecraft:dark_prismarine
fill 146 243 359 148 243 359 minecraft:blue_terracotta
setblock 146 243 363 minecraft:dark_prismarine
fill 147 243 323 150 243 323 minecraft:blue_terracotta
setblock 147 243 362 minecraft:dark_prismarine
fill 147 243 363 150 243 363 minecraft:blue_terracotta
setblock 148 243 361 minecraft:dark_prismarine
fill 148 243 362 151 243 362 minecraft:blue_terracotta
setblock 149 243 360 minecraft:dark_prismarine
fill 149 243 361 149 246 361 minecraft:blue_terracotta
setblock 149 243 364 minecraft:light_blue_wool
fill 150 243 360 150 245 360 minecraft:blue_terracotta
fill 150 243 364 150 293 364 minecraft:blue_concrete
setblock 151 243 323 minecraft:dark_prismarine
fill 151 243 361 152 243 361 minecraft:blue_terracotta
setblock 151 243 363 minecraft:dark_prismarine
setblock 152 243 362 minecraft:dark_prismarine
fill 152 243 363 155 243 363 minecraft:blue_terracotta
setblock 153 243 361 minecraft:dark_prismarine
fill 153 243 362 153 246 362 minecraft:blue_terracotta
fill 155 243 330 156 244 330 minecraft:magenta_terracotta
setblock 156 243 362 minecraft:blue_terracotta
setblock 156 243 363 minecraft:dark_prismarine
fill 157 243 363 160 243 363 minecraft:blue_terracotta
fill 159 243 323 159 244 323 minecraft:purple_concrete
fill 159 243 362 161 243 362 minecraft:blue_terracotta
fill 161 243 348 162 244 349 minecraft:dark_prismarine
setblock 161 243 363 minecraft:dark_prismarine
setblock 162 243 361 minecraft:blue_terracotta
setblock 162 243 362 minecraft:dark_prismarine
fill 162 243 363 165 243 363 minecraft:blue_terracotta
setblock 163 243 361 minecraft:dark_prismarine
fill 163 243 362 166 243 362 minecraft:blue_terracotta
fill 164 243 361 164 246 361 minecraft:blue_terracotta
setblock 165 243 323 minecraft:blue_terracotta
setblock 166 243 323 minecraft:dark_prismarine
setblock 166 243 363 minecraft:dark_prismarine
fill 167 243 323 167 246 323 minecraft:blue_terracotta
setblock 167 243 362 minecraft:dark_prismarine
fill 167 243 363 167 246 363 minecraft:blue_terracotta
fill 168 243 362 168 246 362 minecraft:blue_terracotta
fill 169 243 356 169 249 357 minecraft:magenta_terracotta
fill 169 243 363 170 243 363 minecraft:blue_terracotta
fill 170 243 357 170 255 357 minecraft:magenta_terracotta
setblock 171 243 363 minecraft:dark_prismarine
fill 177 243 350 178 244 351 minecraft:spruce_planks
setblock 180 243 323 minecraft:blue_terracotta
fill 180 243 332 180 243 333 minecraft:blue_terracotta
setblock 180 243 334 minecraft:dark_prismarine
fill 180 243 335 180 243 338 minecraft:blue_terracotta
setblock 180 243 363 minecraft:blue_terracotta
setblock 181 243 323 minecraft:dark_prismarine
setblock 181 243 327 minecraft:blue_terracotta
setblock 181 243 328 minecraft:dark_prismarine
fill 181 243 329 181 243 332 minecraft:blue_terracotta
setblock 181 243 333 minecraft:dark_prismarine
fill 181 243 334 181 246 334 minecraft:blue_terracotta
fill 181 243 336 181 243 337 minecraft:blue_terracotta
setblock 181 243 338 minecraft:dark_prismarine
fill 181 243 339 181 246 339 minecraft:blue_terracotta
fill 181 243 341 182 243 341 minecraft:blue_terracotta
setblock 181 243 357 minecraft:blue_terracotta
setblock 181 243 358 minecraft:dark_prismarine
fill 181 243 359 181 245 360 minecraft:blue_terracotta
setblock 181 243 363 minecraft:dark_prismarine
fill 182 243 323 182 243 326 minecraft:blue_terracotta
setblock 182 243 327 minecraft:dark_prismarine
fill 182 243 328 182 243 331 minecraft:blue_terracotta
setblock 182 243 332 minecraft:dark_prismarine
fill 182 243 333 182 246 333 minecraft:blue_terracotta
setblock 182 243 336 minecraft:blue_terracotta
setblock 182 243 337 minecraft:dark_prismarine
fill 182 243 338 182 246 338 minecraft:blue_terracotta
fill 182 243 340 182 244 340 minecraft:blue_terracotta
setblock 182 243 342 minecraft:dark_prismarine
fill 182 243 343 182 245 344 minecraft:blue_terracotta
setblock 182 243 350 minecraft:purple_concrete
setblock 182 243 352 minecraft:dark_prismarine
fill 182 243 353 182 243 356 minecraft:blue_terracotta
setblock 182 243 357 minecraft:dark_prismarine
fill 182 243 358 182 246 358 minecraft:blue_terracotta
fill 182 243 360 182 243 361 minecraft:blue_terracotta
setblock 182 243 362 minecraft:dark_prismarine
fill 182 243 363 182 246 363 minecraft:blue_terracotta
fill 142 244 323 142 244 325 minecraft:blue_terracotta
setblock 142 244 326 minecraft:dark_prismarine
fill 142 244 327 142 244 330 minecraft:blue_terracotta
setblock 142 244 331 minecraft:dark_prismarine
fill 142 244 332 142 244 335 minecraft:blue_terracotta
setblock 142 244 336 minecraft:dark_prismarine
fill 142 244 337 142 247 337 minecraft:blue_terracotta
setblock 142 244 341 minecraft:dark_prismarine
fill 142 244 342 142 246 343 minecraft:blue_terracotta
setblock 142 244 351 minecraft:dark_prismarine
fill 142 244 352 142 244 355 minecraft:blue_terracotta
setblock 142 244 356 minecraft:dark_prismarine
fill 142 244 357 142 244 360 minecraft:blue_terracotta
setblock 142 244 361 minecraft:dark_prismarine
fill 142 244 362 144 244 363 minecraft:blue_terracotta
fill 143 244 323 143 244 324 minecraft:blue_terracotta
setblock 143 244 325 minecraft:dark_prismarine
fill 143 244 326 143 244 329 minecraft:blue_terracotta
setblock 143 244 330 minecraft:dark_prismarine
fill 143 244 331 143 244 334 minecraft:blue_terracotta
setblock 143 244 335 minecraft:dark_prismarine
fill 143 244 336 143 247 336 minecraft:blue_terracotta
setblock 143 244 340 minecraft:dark_prismarine
fill 143 244 341 143 247 341 minecraft:blue_terracotta
fill 143 244 352 143 244 354 minecraft:blue_terracotta
setblock 143 244 355 minecraft:dark_prismarine
fill 143 244 356 143 244 359 minecraft:blue_terracotta
setblock 143 244 360 minecraft:dark_prismarine
fill 143 244 361 146 244 361 minecraft:blue_terracotta
setblock 144 244 323 minecraft:blue_terracotta
setblock 144 244 324 minecraft:dark_prismarine
setblock 144 244 333 minecraft:blue_terracotta
setblock 144 244 334 minecraft:dark_prismarine
fill 144 244 335 144 245 335 minecraft:blue_terracotta
setblock 144 244 354 minecraft:dark_prismarine
fill 144 244 355 144 244 358 minecraft:blue_terracotta
setblock 144 244 359 minecraft:dark_prismarine
fill 144 244 360 147 244 360 minecraft:blue_terracotta
setblock 145 244 323 minecraft:dark_prismarine
fill 145 244 324 145 247 324 minecraft:blue_terracotta
fill 145 244 355 145 244 357 minecraft:blue_terracotta
setblock 145 244 358 minecraft:dark_prismarine
fill 145 244 359 147 244 359 minecraft:blue_terracotta
setblock 145 244 362 minecraft:blue_terracotta
setblock 145 244 363 minecraft:dark_prismarine
fill 146 244 323 149 244 323 minecraft:blue_terracotta
setblock 146 244 362 minecraft:dark_prismarine
fill 146 244 363 149 244 363 minecraft:blue_terracotta
setblock 147 244 361 minecraft:dark_prismarine
fill 147 244 362 150 244 362 minecraft:blue_terracotta
setblock 148 244 324 minecraft:blue_terracotta
setblock 148 244 360 minecraft:dark_prismarine
fill 148 244 361 148 247 361 minecraft:blue_terracotta
setblock 148 244 364 minecraft:light_blue_wool
fill 149 244 360 149 246 360 minecraft:blue_terracotta
fill 149 244 364 149 305 364 minecraft:blue_concrete
setblock 150 244 323 minecraft:dark_prismarine
setblock 150 244 363 minecraft:dark_prismarine
setblock 151 244 323 minecraft:blue_terracotta
setblock 151 244 361 minecraft:blue_terracotta
setblock 151 244 362 minecraft:dark_prismarine
fill 151 244 363 154 244 363 minecraft:blue_terracotta
setblock 152 244 361 minecraft:dark_prismarine
fill 152 244 362 152 247 362 minecraft:blue_terracotta
setblock 153 244 323 minecraft:purple_concrete
setblock 153 244 361 minecraft:blue_terracotta
setblock 155 244 363 minecraft:dark_prismarine
fill 156 244 329 156 262 329 minecraft:magenta_terracotta
setblock 156 244 362 minecraft:dark_prismarine
fill 156 244 363 159 244 363 minecraft:blue_terracotta
fill 157 244 362 160 244 362 minecraft:blue_terracotta
fill 160 244 348 160 245 349 minecraft:black_concrete
setblock 160 244 363 minecraft:dark_prismarine
fill 161 244 350 162 245 350 minecraft:black_concrete
setblock 161 244 362 minecraft:dark_prismarine
fill 161 244 363 164 244 363 minecraft:blue_terracotta
setblock 162 244 361 minecraft:dark_prismarine
fill 162 244 362 165 244 362 minecraft:blue_terracotta
fill 163 244 348 163 245 349 minecraft:black_concrete
fill 163 244 361 163 247 361 minecraft:blue_terracotta
setblock 164 244 323 minecraft:blue_terracotta
setblock 165 244 323 minecraft:dark_prismarine
fill 165 244 361 166 244 361 minecraft:blue_terracotta
setblock 165 244 363 minecraft:dark_prismarine
fill 166 244 323 166 247 323 minecraft:blue_terracotta
setblock 166 244 362 minecraft:dark_prismarine
fill 166 244 363 166 247 363 minecraft:blue_terracotta
setblock 167 244 361 minecraft:dark_prismarine
fill 167 244 362 167 247 362 minecraft:blue_terracotta
setblock 169 244 363 minecraft:blue_terracotta
setblock 170 244 363 minecraft:dark_prismarine
fill 171 244 363 171 245 363 minecraft:blue_terracotta
setblock 178 244 323 minecraft:purple_concrete
setblock 179 244 323 minecraft:blue_terracotta
setblock 179 244 363 minecraft:blue_terracotta
setblock 180 244 323 minecraft:dark_prismarine
setblock 180 244 332 minecraft:blue_terracotta
setblock 180 244 333 minecraft:dark_prismarine
fill 180 244 334 180 244 337 minecraft:blue_terracotta
setblock 180 244 338 minecraft:dark_prismarine
fill 180 244 339 180 246 339 minecraft:blue_terracotta
setblock 180 244 363 minecraft:dark_prismarine
fill 181 244 323 182 246 323 minecraft:blue_terracotta
setblock 181 244 327 minecraft:dark_prismarine
fill 181 244 328 181 244 331 minecraft:blue_terracotta
setblock 181 244 332 minecraft:dark_prismarine
fill 181 244 333 181 247 333 minecraft:blue_terracotta
setblock 181 244 336 minecraft:blue_terracotta
setblock 181 244 337 minecraft:dark_prismarine
fill 181 244 338 181 247 338 minecraft:blue_terracotta
setblock 181 244 341 minecraft:blue_terracotta
setblock 181 244 342 minecraft:dark_prismarine
setblock 181 244 357 minecraft:dark_prismarine
fill 181 244 358 181 247 358 minecraft:blue_terracotta
setblock 181 244 361 minecraft:blue_terracotta
setblock 181 244 362 minecraft:dark_prismarine
fill 181 244 363 181 247 363 minecraft:blue_terracotta
fill 182 244 324 182 244 325 minecraft:blue_terracotta
setblock 182 244 326 minecraft:dark_prismarine
fill 182 244 327 182 244 330 minecraft:blue_terracotta
setblock 182 244 331 minecraft:dark_prismarine
fill 182 244 332 182 247 332 minecraft:blue_terracotta
setblock 182 244 336 minecraft:dark_prismarine
fill 182 244 337 182 247 337 minecraft:blue_terracotta
setblock 182 244 341 minecraft:dark_prismarine
fill 182 244 342 182 247 342 minecraft:blue_terracotta
fill 182 244 353 182 244 355 minecraft:blue_terracotta
setblock 182 244 356 minecraft:dark_prismarine
fill 182 244 357 182 247 357 minecraft:blue_terracotta
setblock 182 244 360 minecraft:blue_terracotta
setblock 182 244 361 minecraft:dark_prismarine
fill 182 244 362 182 247 362 minecraft:blue_terracotta
fill 142 245 323 142 245 324 minecraft:blue_terracotta
setblock 142 245 325 minecraft:dark_prismarine
fill 142 245 326 142 245 329 minecraft:blue_terracotta
setblock 142 245 330 minecraft:dark_prismarine
fill 142 245 331 142 245 334 minecraft:blue_terracotta
setblock 142 245 335 minecraft:dark_prismarine
fill 142 245 336 142 248 336 minecraft:blue_terracotta
setblock 142 245 339 minecraft:blue_terracotta
setblock 142 245 340 minecraft:dark_prismarine
fill 142 245 341 142 248 341 minecraft:blue_terracotta
setblock 142 245 344 minecraft:blue_terracotta
setblock 142 245 348 minecraft:purple_concrete
fill 142 245 351 142 245 354 minecraft:blue_terracotta
setblock 142 245 355 minecraft:dark_prismarine
fill 142 245 356 142 245 359 minecraft:blue_terracotta
setblock 142 245 360 minecraft:dark_prismarine
fill 142 245 361 143 245 363 minecraft:blue_terracotta
setblock 143 245 323 minecraft:blue_terracotta
setblock 143 245 324 minecraft:dark_prismarine
fill 143 245 325 143 245 328 minecraft:blue_terracotta
setblock 143 245 329 minecraft:dark_prismarine
fill 143 245 330 143 245 333 minecraft:blue_terracotta
setblock 143 245 334 minecraft:dark_prismarine
fill 143 245 335 143 247 335 minecraft:blue_terracotta
setblock 143 245 339 minecraft:dark_prismarine
fill 143 245 340 143 248 340 minecraft:blue_terracotta
setblock 143 245 353 minecraft:blue_terracotta
setblock 143 245 354 minecraft:dark_prismarine
fill 143 245 355 143 245 358 minecraft:blue_terracotta
setblock 143 245 359 minecraft:dark_prismarine
fill 143 245 360 146 245 360 minecraft:blue_terracotta
setblock 144 245 323 minecraft:dark_prismarine
fill 144 245 324 144 248 324 minecraft:blue_terracotta
setblock 144 245 325 minecraft:light[level=13]
setblock 144 245 332 minecraft:light[level=12]
setblock 144 245 333 minecraft:light[level=13]
setblock 144 245 338 minecraft:dark_prismarine
setblock 144 245 339 minecraft:light[level=12]
setblock 144 245 341 minecraft:light[level=13]
setblock 144 245 346 minecraft:light[level=12]
setblock 144 245 349 minecraft:light[level=13]
setblock 144 245 353 minecraft:light[level=12]
fill 144 245 354 144 245 357 minecraft:blue_terracotta
setblock 144 245 358 minecraft:dark_prismarine
fill 144 245 359 145 247 359 minecraft:blue_terracotta
fill 144 245 361 144 245 362 minecraft:blue_terracotta
setblock 144 245 363 minecraft:dark_prismarine
fill 145 245 323 148 245 323 minecraft:blue_terracotta
setblock 145 245 356 minecraft:blue_terracotta
setblock 145 245 357 minecraft:dark_prismarine
fill 145 245 358 145 247 358 minecraft:blue_terracotta
setblock 145 245 361 minecraft:blue_terracotta
setblock 145 245 362 minecraft:dark_prismarine
fill 145 245 363 148 245 363 minecraft:blue_terracotta
setblock 146 245 361 minecraft:dark_prismarine
fill 146 245 362 149 245 362 minecraft:blue_terracotta
setblock 147 245 360 minecraft:dark_prismarine
fill 147 245 361 147 248 361 minecraft:blue_terracotta
fill 148 245 360 148 246 360 minecraft:blue_terracotta
fill 148 245 364 148 308 364 minecraft:blue_concrete
setblock 149 245 323 minecraft:dark_prismarine
setblock 149 245 363 minecraft:dark_prismarine
fill 150 245 323 150 246 323 minecraft:blue_terracotta
setblock 150 245 362 minecraft:dark_prismarine
fill 150 245 363 153 245 363 minecraft:blue_terracotta
setblock 151 245 325 minecraft:light[level=12]
setblock 151 245 332 minecraft:light[level=12]
setblock 151 245 339 minecraft:light[level=12]
setblock 151 245 353 minecraft:light[level=12]
setblock 151 245 360 minecraft:light[level=12]
setblock 151 245 361 minecraft:dark_prismarine
fill 151 245 362 151 248 362 minecraft:blue_terracotta
setblock 152 245 325 minecraft:light[level=13]
setblock 152 245 333 minecraft:light[level=13]
setblock 152 245 349 minecraft:light[level=13]
setblock 152 245 357 minecraft:light[level=13]
setblock 152 245 361 minecraft:blue_terracotta
setblock 154 245 322 minecraft:cyan_concrete
fill 154 245 329 154 246 329 minecraft:magenta_terracotta
setblock 154 245 362 minecraft:blue_terracotta
setblock 154 245 363 minecraft:dark_prismarine
fill 155 245 322 156 308 322 minecraft:blue_concrete
fill 155 245 330 155 253 330 minecraft:magenta_terracotta
setblock 155 245 362 minecraft:dark_prismarine
fill 155 245 363 158 245 363 minecraft:blue_terracotta
fill 156 245 362 159 245 362 minecraft:blue_terracotta
setblock 158 245 325 minecraft:light[level=12]
setblock 158 245 332 minecraft:light[level=12]
setblock 158 245 339 minecraft:light[level=12]
setblock 158 245 346 minecraft:light[level=12]
setblock 158 245 353 minecraft:light[level=12]
setblock 158 245 360 minecraft:light[level=12]
setblock 159 245 363 minecraft:dark_prismarine
setblock 160 245 325 minecraft:light[level=13]
setblock 160 245 333 minecraft:light[level=13]
setblock 160 245 350 minecraft:black_concrete
setblock 160 245 357 minecraft:light[level=13]
setblock 160 245 362 minecraft:dark_prismarine
fill 160 245 363 163 245 363 minecraft:blue_terracotta
fill 161 245 348 161 245 349 minecraft:dark_prismarine
setblock 161 245 361 minecraft:dark_prismarine
fill 161 245 362 164 245 362 minecraft:blue_terracotta
fill 162 245 349 162 249 349 minecraft:dark_prismarine
fill 162 245 361 162 246 361 minecraft:blue_terracotta
setblock 163 245 323 minecraft:blue_terracotta
setblock 164 245 323 minecraft:dark_prismarine
setblock 164 245 363 minecraft:dark_prismarine
fill 165 245 323 165 248 323 minecraft:blue_terracotta
setblock 165 245 325 minecraft:light[level=12]
setblock 165 245 332 minecraft:light[level=12]
setblock 165 245 339 minecraft:light[level=12]
setblock 165 245 353 minecraft:light[level=12]
setblock 165 245 360 minecraft:light[level=12]
setblock 165 245 361 minecraft:blue_terracotta
setblock 165 245 362 minecraft:dark_prismarine
fill 165 245 363 165 248 363 minecraft:blue_terracotta
setblock 166 245 361 minecraft:dark_prismarine
fill 166 245 362 166 248 362 minecraft:blue_terracotta
setblock 168 245 323 minecraft:blue_terracotta
setblock 168 245 325 minecraft:light[level=13]
setblock 168 245 333 minecraft:light[level=13]
setblock 168 245 341 minecraft:light[level=13]
setblock 168 245 349 minecraft:light[level=13]
fill 168 245 357 168 247 357 minecraft:magenta_terracotta
setblock 169 245 323 minecraft:dark_prismarine
setblock 169 245 363 minecraft:dark_prismarine
fill 170 245 363 170 246 363 minecraft:blue_terracotta
setblock 172 245 323 minecraft:purple_concrete
setblock 172 245 325 minecraft:light[level=12]
setblock 172 245 332 minecraft:light[level=12]
setblock 172 245 339 minecraft:light[level=12]
setblock 172 245 346 minecraft:light[level=12]
setblock 172 245 353 minecraft:light[level=12]
setblock 172 245 360 minecraft:light[level=12]
setblock 176 245 325 minecraft:light[level=13]
setblock 176 245 333 minecraft:light[level=13]
setblock 176 245 349 minecraft:light[level=13]
setblock 176 245 357 minecraft:light[level=13]
fill 177 245 363 177 246 363 minecraft:purple_concrete
setblock 178 245 323 minecraft:blue_terracotta
setblock 179 245 323 minecraft:dark_prismarine
setblock 179 245 325 minecraft:light[level=12]
setblock 179 245 332 minecraft:light[level=12]
setblock 179 245 339 minecraft:light[level=12]
setblock 179 245 346 minecraft:light[level=12]
setblock 179 245 353 minecraft:light[level=12]
setblock 179 245 360 minecraft:light[level=12]
setblock 179 245 363 minecraft:dark_prismarine
fill 180 245 323 180 248 323 minecraft:blue_terracotta
fill 180 245 333 180 245 336 minecraft:blue_terracotta
setblock 180 245 337 minecraft:dark_prismarine
fill 180 245 338 180 247 338 minecraft:blue_terracotta
fill 180 245 363 180 248 363 minecraft:blue_terracotta
fill 181 245 324 181 245 325 minecraft:blue_terracotta
setblock 181 245 326 minecraft:dark_prismarine
fill 181 245 327 181 245 330 minecraft:blue_terracotta
setblock 181 245 331 minecraft:dark_prismarine
fill 181 245 332 181 248 332 minecraft:blue_terracotta
setblock 181 245 335 minecraft:blue_terracotta
setblock 181 245 336 minecraft:dark_prismarine
fill 181 245 337 181 248 337 minecraft:blue_terracotta
setblock 181 245 341 minecraft:dark_prismarine
fill 181 245 342 181 248 342 minecraft:blue_terracotta
setblock 181 245 357 minecraft:blue_terracotta
setblock 181 245 361 minecraft:dark_prismarine
fill 181 245 362 181 248 362 minecraft:blue_terracotta
setblock 182 245 324 minecraft:blue_terracotta
setblock 182 245 325 minecraft:dark_prismarine
fill 182 245 326 182 245 329 minecraft:blue_terracotta
setblock 182 245 330 minecraft:dark_prismarine
fill 182 245 331 182 248 331 minecraft:blue_terracotta
setblock 182 245 335 minecraft:dark_prismarine
fill 182 245 336 182 248 336 minecraft:blue_terracotta
setblock 182 245 340 minecraft:dark_prismarine
fill 182 245 341 182 248 341 minecraft:blue_terracotta
setblock 182 245 345 minecraft:dark_prismarine
fill 182 245 353 182 245 354 minecraft:blue_terracotta
setblock 182 245 355 minecraft:dark_prismarine
fill 182 245 356 182 248 356 minecraft:blue_terracotta
setblock 182 245 360 minecraft:dark_prismarine
fill 182 245 361 182 248 361 minecraft:blue_terracotta
setblock 183 245 356 minecraft:cyan_concrete
setblock 142 246 323 minecraft:blue_terracotta
setblock 142 246 324 minecraft:dark_prismarine
fill 142 246 325 142 246 328 minecraft:blue_terracotta
setblock 142 246 329 minecraft:dark_prismarine
fill 142 246 330 142 246 333 minecraft:blue_terracotta
setblock 142 246 334 minecraft:dark_prismarine
fill 142 246 335 142 249 335 minecraft:blue_terracotta
setblock 142 246 339 minecraft:dark_prismarine
fill 142 246 340 142 249 340 minecraft:blue_terracotta
setblock 142 246 344 minecraft:dark_prismarine
fill 142 246 351 142 246 353 minecraft:blue_terracotta
setblock 142 246 354 minecraft:dark_prismarine
fill 142 246 355 142 246 358 minecraft:blue_terracotta
setblock 142 246 359 minecraft:dark_prismarine
fill 142 246 360 142 246 363 minecraft:blue_terracotta
setblock 143 246 323 minecraft:dark_prismarine
fill 143 246 324 143 246 326 minecraft:blue_terracotta
setblock 143 246 332 minecraft:blue_terracotta
setblock 143 246 333 minecraft:dark_prismarine
setblock 143 246 334 minecraft:blue_terracotta
setblock 143 246 338 minecraft:dark_prismarine
fill 143 246 339 143 249 339 minecraft:blue_terracotta
setblock 143 246 342 minecraft:blue_terracotta
setblock 143 246 353 minecraft:dark_prismarine
fill 143 246 354 143 246 357 minecraft:blue_terracotta
setblock 143 246 358 minecraft:dark_prismarine
fill 143 246 359 143 246 362 minecraft:blue_terracotta
setblock 143 246 363 minecraft:dark_prismarine
fill 144 246 323 147 246 323 minecraft:blue_terracotta
fill 144 246 355 144 246 356 minecraft:blue_terracotta
setblock 144 246 357 minecraft:dark_prismarine
fill 144 246 358 144 249 358 minecraft:blue_terracotta
fill 144 246 360 144 246 361 minecraft:blue_terracotta
setblock 144 246 362 minecraft:dark_prismarine
fill 144 246 363 147 246 363 minecraft:blue_terracotta
setblock 145 246 357 minecraft:blue_terracotta
setblock 145 246 360 minecraft:blue_terracotta
setblock 145 246 361 minecraft:dark_prismarine
fill 145 246 362 148 246 362 minecraft:blue_terracotta
setblock 146 246 360 minecraft:dark_prismarine
fill 146 246 361 146 249 361 minecraft:blue_terracotta
setblock 147 246 324 minecraft:dark_prismarine
fill 147 246 360 147 247 360 minecraft:blue_terracotta
setblock 148 246 323 minecraft:dark_prismarine
setblock 148 246 363 minecraft:dark_prismarine
fill 149 246 323 149 248 323 minecraft:blue_terracotta
setblock 149 246 362 minecraft:dark_prismarine
fill 149 246 363 152 246 363 minecraft:blue_terracotta
setblock 150 246 361 minecraft:dark_prismarine
fill 150 246 362 150 249 362 minecraft:blue_terracotta
setblock 151 246 361 minecraft:blue_terracotta
setblock 153 246 363 minecraft:dark_prismarine
fill 154 246 322 154 266 322 minecraft:blue_concrete
setblock 154 246 362 minecraft:dark_prismarine
fill 154 246 363 157 246 363 minecraft:blue_terracotta
setblock 154 246 364 minecraft:cyan_concrete
setblock 155 246 362 minecraft:blue_terracotta
fill 157 246 362 158 246 362 minecraft:blue_terracotta
setblock 158 246 363 minecraft:dark_prismarine
setblock 159 246 362 minecraft:dark_prismarine
fill 159 246 363 162 246 363 minecraft:blue_terracotta
fill 160 246 362 163 246 362 minecraft:blue_terracotta
fill 161 246 349 161 248 349 minecraft:dark_prismarine
setblock 161 246 361 minecraft:blue_terracotta
setblock 163 246 323 minecraft:dark_prismarine
setblock 163 246 363 minecraft:dark_prismarine
fill 164 246 323 164 249 323 minecraft:blue_terracotta
setblock 164 246 362 minecraft:dark_prismarine
fill 164 246 363 164 249 363 minecraft:blue_terracotta
setblock 165 246 361 minecraft:dark_prismarine
fill 165 246 362 165 249 362 minecraft:blue_terracotta
setblock 168 246 323 minecraft:dark_prismarine
setblock 168 246 363 minecraft:dark_prismarine
setblock 168 246 364 minecraft:light_blue_wool
fill 169 246 363 169 247 363 minecraft:blue_terracotta
fill 176 246 342 176 262 342 minecraft:magenta_terracotta
setblock 178 246 323 minecraft:dark_prismarine
setblock 178 246 363 minecraft:dark_prismarine
fill 179 246 323 179 249 323 minecraft:blue_terracotta
fill 179 246 363 179 249 363 minecraft:blue_terracotta
setblock 180 246 335 minecraft:blue_terracotta
setblock 180 246 336 minecraft:dark_prismarine
fill 180 246 337 180 247 337 minecraft:blue_terracotta
fill 180 246 362 180 249 362 minecraft:blue_terracotta
setblock 181 246 324 minecraft:blue_terracotta
setblock 181 246 325 minecraft:dark_prismarine
fill 181 246 326 181 246 329 minecraft:blue_terracotta
setblock 181 246 330 minecraft:dark_prismarine
fill 181 246 331 181 247 331 minecraft:blue_terracotta
setblock 181 246 335 minecraft:dark_prismarine
fill 181 246 336 181 249 336 minecraft:blue_terracotta
setblock 181 246 340 minecraft:dark_prismarine
fill 181 246 341 181 249 341 minecraft:blue_terracotta
setblock 181 246 359 minecraft:blue_terracotta
setblock 181 246 360 minecraft:dark_prismarine
fill 181 246 361 181 249 361 minecraft:blue_terracotta
setblock 182 246 324 minecraft:dark_prismarine
fill 182 246 325 182 246 328 minecraft:blue_terracotta
setblock 182 246 329 minecraft:dark_prismarine
fill 182 246 330 182 249 330 minecraft:blue_terracotta
setblock 182 246 334 minecraft:dark_prismarine
fill 182 246 335 182 249 335 minecraft:blue_terracotta
setblock 182 246 339 minecraft:dark_prismarine
fill 182 246 340 182 249 340 minecraft:blue_terracotta
setblock 182 246 343 minecraft:blue_terracotta
setblock 182 246 344 minecraft:dark_prismarine
fill 182 246 345 182 249 345 minecraft:blue_terracotta
setblock 182 246 351 minecraft:purple_concrete
setblock 182 246 354 minecraft:dark_prismarine
fill 182 246 355 182 248 355 minecraft:blue_terracotta
setblock 182 246 359 minecraft:dark_prismarine
fill 182 246 360 182 249 360 minecraft:blue_terracotta
fill 183 246 356 183 308 356 minecraft:blue_concrete
setblock 142 247 323 minecraft:dark_prismarine
fill 142 247 324 142 247 327 minecraft:blue_terracotta
setblock 142 247 328 minecraft:dark_prismarine
fill 142 247 329 142 247 332 minecraft:blue_terracotta
setblock 142 247 333 minecraft:dark_prismarine
fill 142 247 334 142 249 334 minecraft:blue_terracotta
setblock 142 247 338 minecraft:dark_prismarine
fill 142 247 339 142 250 339 minecraft:blue_terracotta
setblock 142 247 342 minecraft:blue_terracotta
setblock 142 247 343 minecraft:dark_prismarine
fill 142 247 344 142 248 345 minecraft:blue_terracotta
setblock 142 247 352 minecraft:blue_terracotta
setblock 142 247 353 minecraft:dark_prismarine
fill 142 247 354 142 247 357 minecraft:blue_terracotta
setblock 142 247 358 minecraft:dark_prismarine
fill 142 247 359 142 247 362 minecraft:blue_terracotta
setblock 142 247 363 minecraft:dark_prismarine
fill 143 247 323 143 248 325 minecraft:blue_terracotta
setblock 143 247 337 minecraft:dark_prismarine
fill 143 247 338 143 248 338 minecraft:blue_terracotta
setblock 143 247 342 minecraft:dark_prismarine
fill 143 247 354 143 247 356 minecraft:blue_terracotta
setblock 143 247 357 minecraft:dark_prismarine
fill 143 247 358 143 247 361 minecraft:blue_terracotta
setblock 143 247 362 minecraft:dark_prismarine
fill 143 247 363 146 247 363 minecraft:blue_terracotta
fill 144 247 323 146 247 323 minecraft:blue_terracotta
setblock 144 247 356 minecraft:dark_prismarine
fill 144 247 357 144 249 357 minecraft:blue_terracotta
setblock 144 247 360 minecraft:blue_terracotta
setblock 144 247 361 minecraft:dark_prismarine
fill 144 247 362 147 247 362 minecraft:blue_terracotta
setblock 145 247 360 minecraft:dark_prismarine
fill 145 247 361 145 250 361 minecraft:blue_terracotta
setblock 146 247 324 minecraft:dark_prismarine
fill 146 247 360 146 248 360 minecraft:blue_terracotta
setblock 147 247 323 minecraft:dark_prismarine
setblock 147 247 363 minecraft:dark_prismarine
fill 148 247 323 148 250 323 minecraft:blue_terracotta
setblock 148 247 362 minecraft:dark_prismarine
fill 148 247 363 151 247 363 minecraft:blue_terracotta
setblock 149 247 361 minecraft:dark_prismarine
fill 149 247 362 149 250 362 minecraft:blue_terracotta
setblock 150 247 361 minecraft:blue_terracotta
fill 152 247 327 152 257 327 minecraft:iron_bars
setblock 152 247 363 minecraft:dark_prismarine
setblock 153 247 362 minecraft:dark_prismarine
fill 153 247 363 156 247 363 minecraft:blue_terracotta
fill 154 247 364 154 308 364 minecraft:blue_concrete
setblock 157 247 363 minecraft:dark_prismarine
setblock 158 247 362 minecraft:dark_prismarine
fill 158 247 363 161 247 363 minecraft:blue_terracotta
fill 159 247 362 162 247 362 minecraft:blue_terracotta
setblock 160 247 323 minecraft:purple_concrete
setblock 162 247 323 minecraft:dark_prismarine
setblock 162 247 363 minecraft:dark_prismarine
fill 163 247 323 163 250 323 minecraft:blue_terracotta
setblock 163 247 362 minecraft:dark_prismarine
fill 163 247 363 163 250 363 minecraft:blue_terracotta
fill 164 247 362 164 250 362 minecraft:blue_terracotta
setblock 167 247 323 minecraft:dark_prismarine
setblock 167 247 363 minecraft:dark_prismarine
setblock 168 247 323 minecraft:blue_terracotta
fill 168 247 363 168 249 363 minecraft:blue_terracotta
fill 168 247 364 168 308 364 minecraft:blue_concrete
fill 169 247 358 169 258 358 minecraft:magenta_terracotta
setblock 177 247 323 minecraft:dark_prismarine
fill 178 247 323 178 250 323 minecraft:blue_terracotta
fill 178 247 363 178 250 363 minecraft:blue_terracotta
setblock 180 247 324 minecraft:blue_terracotta
setblock 181 247 323 minecraft:blue_terracotta
setblock 181 247 324 minecraft:dark_prismarine
fill 181 247 325 182 247 327 minecraft:blue_terracotta
setblock 181 247 330 minecraft:blue_terracotta
setblock 181 247 334 minecraft:dark_prismarine
fill 181 247 335 181 250 335 minecraft:blue_terracotta
setblock 181 247 339 minecraft:dark_prismarine
fill 181 247 340 181 250 340 minecraft:blue_terracotta
setblock 181 247 359 minecraft:dark_prismarine
fill 181 247 360 181 250 360 minecraft:blue_terracotta
setblock 182 247 323 minecraft:dark_prismarine
fill 182 247 324 182 250 324 minecraft:blue_terracotta
setblock 182 247 328 minecraft:dark_prismarine
fill 182 247 329 182 250 329 minecraft:blue_terracotta
setblock 182 247 333 minecraft:dark_prismarine
fill 182 247 334 182 250 334 minecraft:blue_terracotta
setblock 182 247 338 minecraft:dark_prismarine
fill 182 247 339 182 250 339 minecraft:blue_terracotta
setblock 182 247 343 minecraft:dark_prismarine
fill 182 247 344 182 250 344 minecraft:blue_terracotta
setblock 182 247 358 minecraft:dark_prismarine
fill 182 247 359 182 250 359 minecraft:blue_terracotta
setblock 182 247 363 minecraft:dark_prismarine
fill 142 248 323 142 248 326 minecraft:blue_terracotta
setblock 142 248 327 minecraft:dark_prismarine
fill 142 248 328 142 248 331 minecraft:blue_terracotta
setblock 142 248 332 minecraft:dark_prismarine
setblock 142 248 333 minecraft:blue_terracotta
setblock 142 248 337 minecraft:dark_prismarine
fill 142 248 338 142 251 338 minecraft:blue_terracotta
setblock 142 248 342 minecraft:dark_prismarine
fill 142 248 343 142 251 343 minecraft:blue_terracotta
setblock 142 248 346 minecraft:blue_terracotta
setblock 142 248 347 minecraft:purple_concrete
setblock 142 248 352 minecraft:dark_prismarine
fill 142 248 353 142 248 356 minecraft:blue_terracotta
setblock 142 248 357 minecraft:dark_prismarine
fill 142 248 358 142 248 361 minecraft:blue_terracotta
setblock 142 248 362 minecraft:dark_prismarine
fill 142 248 363 145 248 363 minecraft:blue_terracotta
setblock 143 248 337 minecraft:blue_terracotta
setblock 143 248 341 minecraft:dark_prismarine
fill 143 248 342 143 251 342 minecraft:blue_terracotta
setblock 143 248 355 minecraft:blue_terracotta
setblock 143 248 356 minecraft:dark_prismarine
fill 143 248 357 143 248 360 minecraft:blue_terracotta
setblock 143 248 361 minecraft:dark_prismarine
fill 143 248 362 146 248 362 minecraft:blue_terracotta
fill 144 248 323 145 248 323 minecraft:blue_terracotta
setblock 144 248 359 minecraft:blue_terracotta
setblock 144 248 360 minecraft:dark_prismarine
fill 144 248 361 144 251 361 minecraft:blue_terracotta
setblock 145 248 324 minecraft:dark_prismarine
setblock 145 248 359 minecraft:dark_prismarine
setblock 145 248 360 minecraft:blue_terracotta
setblock 146 248 323 minecraft:dark_prismarine
setblock 146 248 363 minecraft:dark_prismarine
fill 147 248 323 147 251 323 minecraft:blue_terracotta
setblock 147 248 362 minecraft:dark_prismarine
fill 147 248 363 150 248 363 minecraft:blue_terracotta
setblock 148 248 361 minecraft:dark_prismarine
fill 148 248 362 148 251 362 minecraft:blue_terracotta
setblock 149 248 361 minecraft:blue_terracotta
setblock 151 248 363 minecraft:dark_prismarine
setblock 152 248 362 minecraft:dark_prismarine
fill 152 248 363 155 248 363 minecraft:blue_terracotta
setblock 154 248 323 minecraft:purple_concrete
setblock 156 248 363 minecraft:dark_prismarine
fill 157 248 363 160 248 363 minecraft:blue_terracotta
fill 158 248 362 161 248 362 minecraft:blue_terracotta
setblock 161 248 323 minecraft:dark_prismarine
setblock 161 248 363 minecraft:dark_prismarine
fill 162 248 323 162 251 323 minecraft:blue_terracotta
setblock 162 248 362 minecraft:dark_prismarine
fill 162 248 363 162 251 363 minecraft:blue_terracotta
fill 163 248 362 163 251 362 minecraft:blue_terracotta
setblock 166 248 323 minecraft:dark_prismarine
setblock 166 248 363 minecraft:dark_prismarine
fill 167 248 323 167 251 323 minecraft:blue_terracotta
fill 167 248 363 167 251 363 minecraft:blue_terracotta
fill 169 248 327 170 255 327 minecraft:magenta_terracotta
setblock 170 248 363 minecraft:purple_concrete
setblock 173 248 323 minecraft:purple_concrete
setblock 176 248 323 minecraft:dark_prismarine
fill 177 248 323 177 251 323 minecraft:blue_terracotta
fill 177 248 363 177 251 363 minecraft:blue_terracotta
setblock 179 248 324 minecraft:blue_terracotta
setblock 180 248 324 minecraft:dark_prismarine
setblock 181 248 323 minecraft:dark_prismarine
fill 181 248 324 181 248 327 minecraft:blue_terracotta
setblock 181 248 333 minecraft:dark_prismarine
fill 181 248 334 181 249 334 minecraft:blue_terracotta
setblock 181 248 338 minecraft:dark_prismarine
fill 181 248 339 181 251 339 minecraft:blue_terracotta
fill 181 248 359 181 251 359 minecraft:blue_terracotta
setblock 181 248 363 minecraft:dark_prismarine
fill 182 248 323 182 251 323 minecraft:blue_terracotta
fill 182 248 325 182 248 326 minecraft:blue_terracotta
setblock 182 248 327 minecraft:dark_prismarine
fill 182 248 328 182 251 328 minecraft:blue_terracotta
setblock 182 248 332 minecraft:dark_prismarine
fill 182 248 333 182 251 333 minecraft:blue_terracotta
setblock 182 248 337 minecraft:dark_prismarine
fill 182 248 338 182 251 338 minecraft:blue_terracotta
setblock 182 248 342 minecraft:dark_prismarine
fill 182 248 343 182 251 343 minecraft:blue_terracotta
setblock 182 248 357 minecraft:dark_prismarine
fill 182 248 358 182 251 358 minecraft:blue_terracotta
setblock 182 248 362 minecraft:dark_prismarine
fill 182 248 363 182 251 363 minecraft:blue_terracotta
setblock 141 249 324 minecraft:light_blue_wool
fill 141 249 325 141 308 325 minecraft:blue_concrete
fill 142 249 323 142 249 325 minecraft:blue_terracotta
setblock 142 249 326 minecraft:dark_prismarine
fill 142 249 327 142 249 329 minecraft:blue_terracotta
setblock 142 249 336 minecraft:dark_prismarine
fill 142 249 337 142 252 337 minecraft:blue_terracotta
setblock 142 249 341 minecraft:dark_prismarine
fill 142 249 342 142 252 342 minecraft:blue_terracotta
fill 142 249 344 142 250 344 minecraft:jungle_log
setblock 142 249 345 minecraft:blue_terracotta
setblock 142 249 346 minecraft:dark_prismarine
fill 142 249 347 142 252 347 minecraft:blue_terracotta
fill 142 249 353 142 249 355 minecraft:blue_terracotta
setblock 142 249 356 minecraft:dark_prismarine
fill 142 249 357 142 249 360 minecraft:blue_terracotta
setblock 142 249 361 minecraft:dark_prismarine
fill 142 249 362 144 249 363 minecraft:blue_terracotta
fill 143 249 323 143 249 324 minecraft:blue_terracotta
setblock 143 249 325 minecraft:dark_prismarine
setblock 143 249 340 minecraft:dark_prismarine
fill 143 249 341 143 252 341 minecraft:blue_terracotta
setblock 143 249 355 minecraft:dark_prismarine
fill 143 249 356 143 249 359 minecraft:blue_terracotta
setblock 143 249 360 minecraft:dark_prismarine
fill 143 249 361 143 252 361 minecraft:blue_terracotta
setblock 144 249 323 minecraft:blue_terracotta
setblock 144 249 324 minecraft:dark_prismarine
setblock 144 249 359 minecraft:dark_prismarine
fill 144 249 360 144 252 360 minecraft:blue_terracotta
setblock 145 249 323 minecraft:dark_prismarine
fill 145 249 324 145 252 324 minecraft:blue_terracotta
setblock 145 249 362 minecraft:blue_terracotta
setblock 145 249 363 minecraft:dark_prismarine
fill 146 249 323 146 252 323 minecraft:blue_terracotta
setblock 146 249 362 minecraft:dark_prismarine
fill 146 249 363 149 249 363 minecraft:blue_terracotta
setblock 147 249 361 minecraft:dark_prismarine
fill 147 249 362 147 252 362 minecraft:blue_terracotta
fill 148 249 343 152 249 345 minecraft:jungle_log
setblock 148 249 361 minecraft:blue_terracotta
setblock 150 249 363 minecraft:dark_prismarine
setblock 151 249 362 minecraft:dark_prismarine
fill 151 249 363 154 249 363 minecraft:blue_terracotta
fill 153 249 343 157 249 345 minecraft:jungle_leaves[persistent=true]
fill 154 249 341 157 254 342 minecraft:jungle_leaves[persistent=true]
fill 154 249 346 157 254 347 minecraft:jungle_leaves[persistent=true]
fill 155 249 340 159 251 340 minecraft:jungle_leaves[persistent=true]
fill 155 249 348 159 251 348 minecraft:jungle_leaves[persistent=true]
setblock 155 249 363 minecraft:dark_prismarine
fill 156 249 363 159 249 363 minecraft:blue_terracotta
fill 157 249 339 161 252 339 minecraft:jungle_leaves[persistent=true]
fill 157 249 349 161 252 349 minecraft:jungle_leaves[persistent=true]
fill 158 249 341 158 251 341 minecraft:jungle_leaves[persistent=true]
fill 158 249 347 158 251 347 minecraft:jungle_leaves[persistent=true]
fill 158 249 362 160 249 362 minecraft:blue_terracotta
fill 160 249 344 160 250 344 minecraft:jungle_log
setblock 160 249 363 minecraft:dark_prismarine
fill 161 249 323 161 252 323 minecraft:blue_terracotta
setblock 161 249 362 minecraft:dark_prismarine
fill 161 249 363 161 252 363 minecraft:blue_terracotta
fill 162 249 362 162 252 362 minecraft:blue_terracotta
setblock 165 249 323 minecraft:dark_prismarine
setblock 165 249 363 minecraft:dark_prismarine
fill 166 249 323 166 252 323 minecraft:blue_terracotta
fill 166 249 363 166 252 363 minecraft:blue_terracotta
fill 168 249 357 168 250 357 minecraft:magenta_terracotta
fill 176 249 323 176 252 323 minecraft:blue_terracotta
setblock 176 249 363 minecraft:purple_concrete
setblock 179 249 324 minecraft:dark_prismarine
fill 179 249 362 179 250 362 minecraft:blue_terracotta
setblock 180 249 323 minecraft:dark_prismarine
fill 180 249 324 181 251 324 minecraft:blue_terracotta
setblock 180 249 363 minecraft:dark_prismarine
fill 181 249 323 181 252 323 minecraft:blue_terracotta
fill 181 249 325 181 249 326 minecraft:blue_terracotta
setblock 181 249 327 minecraft:dark_prismarine
setblock 181 249 337 minecraft:dark_prismarine
fill 181 249 338 181 252 338 minecraft:blue_terracotta
setblock 181 249 342 minecraft:dark_prismarine
fill 181 249 343 181 252 343 minecraft:blue_terracotta
setblock 181 249 362 minecraft:dark_prismarine
fill 181 249 363 181 252 363 minecraft:blue_terracotta
setblock 182 249 325 minecraft:blue_terracotta
setblock 182 249 326 minecraft:dark_prismarine
fill 182 249 327 182 252 327 minecraft:blue_terracotta
setblock 182 249 331 minecraft:dark_prismarine
fill 182 249 332 182 252 332 minecraft:blue_terracotta
setblock 182 249 336 minecraft:dark_prismarine
fill 182 249 337 182 252 337 minecraft:blue_terracotta
setblock 182 249 341 minecraft:dark_prismarine
fill 182 249 342 182 252 342 minecraft:blue_terracotta
setblock 182 249 346 minecraft:dark_prismarine
setblock 182 249 352 minecraft:purple_concrete
setblock 182 249 356 minecraft:dark_prismarine
fill 182 249 357 182 252 357 minecraft:blue_terracotta
setblock 182 249 361 minecraft:dark_prismarine
fill 182 249 362 182 252 362 minecraft:blue_terracotta
fill 141 250 324 141 308 324 minecraft:blue_concrete
setblock 141 250 328 minecraft:cyan_concrete
fill 141 250 329 141 308 332 minecraft:blue_concrete
fill 142 250 323 142 250 324 minecraft:blue_terracotta
setblock 142 250 325 minecraft:dark_prismarine
fill 142 250 326 142 251 328 minecraft:blue_terracotta
setblock 142 250 335 minecraft:dark_prismarine
fill 142 250 336 142 251 336 minecraft:blue_terracotta
setblock 142 250 340 minecraft:dark_prismarine
fill 142 250 341 142 253 341 minecraft:blue_terracotta
setblock 142 250 345 minecraft:dark_prismarine
fill 142 250 346 142 253 346 minecraft:blue_terracotta
fill 142 250 348 142 251 348 minecraft:blue_terracotta
fill 142 250 352 142 250 354 minecraft:blue_terracotta
setblock 142 250 355 minecraft:dark_prismarine
fill 142 250 356 142 250 359 minecraft:blue_terracotta
setblock 142 250 360 minecraft:dark_prismarine
fill 142 250 361 142 251 363 minecraft:blue_terracotta
setblock 143 250 323 minecraft:blue_terracotta
setblock 143 250 324 minecraft:dark_prismarine
fill 143 250 325 143 253 325 minecraft:blue_terracotta
fill 143 250 340 143 251 340 minecraft:blue_terracotta
setblock 143 250 343 minecraft:blue_terracotta
fill 143 250 344 145 250 344 minecraft:jungle_log
fill 143 250 356 143 250 358 minecraft:blue_terracotta
setblock 143 250 359 minecraft:dark_prismarine
fill 143 250 360 143 253 360 minecraft:blue_terracotta
fill 143 250 362 143 250 363 minecraft:blue_terracotta
setblock 144 250 323 minecraft:dark_prismarine
fill 144 250 324 144 253 324 minecraft:blue_terracotta
setblock 144 250 358 minecraft:dark_prismarine
fill 144 250 359 144 252 359 minecraft:blue_terracotta
setblock 144 250 362 minecraft:blue_terracotta
setblock 144 250 363 minecraft:dark_prismarine
fill 145 250 323 145 253 323 minecraft:blue_terracotta
setblock 145 250 362 minecraft:dark_prismarine
fill 145 250 363 148 250 363 minecraft:blue_terracotta
setblock 146 250 361 minecraft:dark_prismarine
fill 146 250 362 146 253 362 minecraft:blue_terracotta
fill 147 250 337 147 250 338 minecraft:jungle_log
fill 147 250 350 147 250 351 minecraft:jungle_log
setblock 147 250 361 minecraft:blue_terracotta
fill 148 250 338 148 250 339 minecraft:jungle_log
fill 148 250 343 148 250 345 minecraft:jungle_log
fill 148 250 349 148 250 350 minecraft:jungle_log
setblock 149 250 342 minecraft:jungle_log
fill 149 250 343 156 250 345 minecraft:jungle_leaves[persistent=true]
setblock 149 250 346 minecraft:jungle_log
setblock 149 250 363 minecraft:dark_prismarine
fill 150 250 341 153 250 342 minecraft:jungle_leaves[persistent=true]
fill 150 250 346 153 250 347 minecraft:jungle_leaves[persistent=true]
setblock 150 250 362 minecraft:dark_prismarine
fill 150 250 363 153 250 363 minecraft:blue_terracotta
fill 151 250 339 153 250 340 minecraft:jungle_leaves[persistent=true]
fill 151 250 348 153 250 349 minecraft:jungle_leaves[persistent=true]
fill 152 250 338 153 255 338 minecraft:jungle_leaves[persistent=true]
fill 152 250 350 153 255 350 minecraft:jungle_leaves[persistent=true]
fill 154 250 337 154 255 337 minecraft:jungle_leaves[persistent=true]
fill 154 250 338 154 250 339 minecraft:jungle_log
fill 154 250 340 154 259 340 minecraft:jungle_leaves[persistent=true]
fill 154 250 348 154 259 348 minecraft:jungle_leaves[persistent=true]
fill 154 250 349 154 250 350 minecraft:jungle_log
fill 154 250 351 154 255 351 minecraft:jungle_leaves[persistent=true]
setblock 154 250 363 minecraft:dark_prismarine
fill 155 250 337 155 250 338 minecraft:jungle_log
fill 155 250 339 156 255 339 minecraft:jungle_leaves[persistent=true]
fill 155 250 349 156 255 349 minecraft:jungle_leaves[persistent=true]
fill 155 250 350 155 250 351 minecraft:jungle_log
fill 155 250 363 158 250 363 minecraft:blue_terracotta
fill 156 250 336 162 255 338 minecraft:jungle_leaves[persistent=true]
fill 156 250 350 162 255 352 minecraft:jungle_leaves[persistent=true]
fill 157 250 343 157 252 343 minecraft:jungle_leaves[persistent=true]
fill 157 250 344 159 250 344 minecraft:jungle_log
fill 157 250 345 157 252 345 minecraft:jungle_leaves[persistent=true]
fill 158 250 362 159 250 362 minecraft:blue_terracotta
setblock 159 250 323 minecraft:dark_prismarine
setblock 159 250 363 minecraft:dark_prismarine
fill 160 250 323 160 253 323 minecraft:blue_terracotta
setblock 160 250 362 minecraft:dark_prismarine
fill 160 250 363 160 253 363 minecraft:blue_terracotta
fill 161 250 362 161 253 362 minecraft:blue_terracotta
fill 162 250 339 167 251 339 minecraft:jungle_leaves[persistent=true]
fill 162 250 349 167 251 349 minecraft:jungle_leaves[persistent=true]
fill 163 250 337 164 255 338 minecraft:jungle_leaves[persistent=true]
fill 163 250 350 164 255 351 minecraft:jungle_leaves[persistent=true]
setblock 164 250 323 minecraft:dark_prismarine
setblock 164 250 363 minecraft:dark_prismarine
fill 165 250 323 165 253 323 minecraft:blue_terracotta
fill 165 250 338 166 255 338 minecraft:jungle_leaves[persistent=true]
fill 165 250 340 167 251 340 minecraft:jungle_leaves[persistent=true]
fill 165 250 348 167 251 348 minecraft:jungle_leaves[persistent=true]
fill 165 250 350 166 255 350 minecraft:jungle_leaves[persistent=true]
fill 165 250 363 165 253 363 minecraft:blue_terracotta
fill 166 250 341 168 251 341 minecraft:jungle_leaves[persistent=true]
fill 166 250 347 168 251 347 minecraft:jungle_leaves[persistent=true]
fill 167 250 342 168 251 346 minecraft:jungle_leaves[persistent=true]
setblock 168 250 323 minecraft:blue_terracotta
fill 168 250 358 168 255 358 minecraft:purple_concrete
fill 169 250 343 169 255 345 minecraft:jungle_leaves[persistent=true]
fill 169 250 357 169 268 357 minecraft:magenta_terracotta
setblock 174 250 323 minecraft:dark_prismarine
fill 175 250 323 175 253 323 minecraft:blue_terracotta
fill 176 250 363 176 252 363 minecraft:blue_terracotta
schedule function dropper:buildpart/75_12 1t
