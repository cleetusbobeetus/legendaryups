fill 76 233 359 76 234 359 minecraft:stripped_dark_oak_log
fill 76 233 361 76 234 361 minecraft:stripped_dark_oak_log
fill 76 233 363 76 234 363 minecraft:stripped_dark_oak_log
fill 77 233 358 77 234 358 minecraft:stripped_dark_oak_log
fill 77 233 360 77 234 360 minecraft:stripped_dark_oak_log
fill 77 233 362 77 234 362 minecraft:stripped_dark_oak_log
fill 78 233 357 78 234 357 minecraft:stripped_dark_oak_log
fill 78 233 359 78 234 359 minecraft:stripped_dark_oak_log
fill 78 233 361 78 234 361 minecraft:stripped_dark_oak_log
fill 78 233 363 78 234 363 minecraft:stripped_dark_oak_log
fill 79 233 358 79 234 358 minecraft:stripped_dark_oak_log
fill 79 233 360 79 234 360 minecraft:stripped_dark_oak_log
fill 79 233 362 79 234 362 minecraft:stripped_dark_oak_log
fill 80 233 357 80 234 357 minecraft:stripped_dark_oak_log
fill 80 233 359 80 234 359 minecraft:stripped_dark_oak_log
fill 80 233 361 80 234 361 minecraft:stripped_dark_oak_log
fill 80 233 363 80 234 363 minecraft:stripped_dark_oak_log
fill 81 233 358 81 234 358 minecraft:stripped_dark_oak_log
fill 81 233 360 81 234 360 minecraft:stripped_dark_oak_log
fill 81 233 362 81 234 362 minecraft:stripped_dark_oak_log
fill 82 233 333 82 242 333 minecraft:dark_oak_planks
fill 82 233 353 82 234 353 minecraft:stripped_dark_oak_log
fill 82 233 355 82 234 355 minecraft:stripped_dark_oak_log
fill 82 233 357 82 234 357 minecraft:stripped_dark_oak_log
fill 82 233 359 82 234 359 minecraft:stripped_dark_oak_log
fill 82 233 361 82 234 361 minecraft:stripped_dark_oak_log
fill 82 233 363 82 234 363 minecraft:stripped_dark_oak_log
setblock 83 233 323 minecraft:stripped_dark_oak_log
fill 83 233 352 83 234 352 minecraft:stripped_dark_oak_log
fill 83 233 354 83 234 354 minecraft:stripped_dark_oak_log
fill 83 233 356 83 234 356 minecraft:stripped_dark_oak_log
fill 83 233 358 83 234 358 minecraft:stripped_dark_oak_log
fill 83 233 360 83 234 360 minecraft:stripped_dark_oak_log
fill 83 233 362 83 234 362 minecraft:stripped_dark_oak_log
fill 83 233 364 83 234 364 minecraft:dark_oak_planks
fill 84 233 353 84 234 353 minecraft:stripped_dark_oak_log
fill 84 233 355 84 234 355 minecraft:stripped_dark_oak_log
fill 84 233 357 84 234 357 minecraft:stripped_dark_oak_log
fill 84 233 359 84 234 359 minecraft:stripped_dark_oak_log
fill 84 233 361 84 234 361 minecraft:stripped_dark_oak_log
fill 84 233 363 84 234 363 minecraft:stripped_dark_oak_log
fill 85 233 352 85 234 352 minecraft:stripped_dark_oak_log
fill 85 233 354 85 234 354 minecraft:stripped_dark_oak_log
fill 85 233 356 85 234 356 minecraft:stripped_dark_oak_log
fill 85 233 358 85 234 358 minecraft:stripped_dark_oak_log
fill 85 233 360 85 234 360 minecraft:stripped_dark_oak_log
fill 85 233 362 85 234 362 minecraft:stripped_dark_oak_log
fill 85 233 364 85 234 364 minecraft:dark_oak_planks
fill 86 233 353 86 234 353 minecraft:stripped_dark_oak_log
fill 86 233 355 86 234 355 minecraft:stripped_dark_oak_log
fill 86 233 357 86 234 357 minecraft:stripped_dark_oak_log
fill 86 233 359 86 234 359 minecraft:stripped_dark_oak_log
fill 86 233 361 86 234 361 minecraft:stripped_dark_oak_log
fill 86 233 363 86 234 363 minecraft:stripped_dark_oak_log
fill 87 233 327 87 234 327 minecraft:dark_oak_planks
fill 87 233 352 87 234 352 minecraft:stripped_dark_oak_log
fill 87 233 354 87 234 354 minecraft:stripped_dark_oak_log
fill 87 233 356 87 234 356 minecraft:stripped_dark_oak_log
fill 87 233 358 87 234 358 minecraft:stripped_dark_oak_log
fill 87 233 360 87 234 360 minecraft:stripped_dark_oak_log
fill 87 233 362 87 234 362 minecraft:stripped_dark_oak_log
fill 87 233 364 87 234 364 minecraft:dark_oak_planks
setblock 88 233 325 minecraft:stripped_dark_oak_log
setblock 88 233 332 minecraft:stripped_dark_oak_log
setblock 88 233 339 minecraft:stripped_dark_oak_log
setblock 88 233 346 minecraft:stripped_dark_oak_log
fill 88 233 353 88 234 353 minecraft:stripped_dark_oak_log
fill 88 233 355 88 234 355 minecraft:stripped_dark_oak_log
fill 88 233 357 88 234 357 minecraft:stripped_dark_oak_log
fill 88 233 359 88 234 359 minecraft:stripped_dark_oak_log
fill 88 233 361 88 234 361 minecraft:stripped_dark_oak_log
fill 88 233 363 88 234 363 minecraft:stripped_dark_oak_log
fill 47 234 322 47 308 323 minecraft:dark_oak_planks
setblock 47 234 324 minecraft:red_concrete
fill 48 234 324 48 235 324 minecraft:stripped_dark_oak_log
fill 48 234 331 48 235 331 minecraft:stripped_dark_oak_log
fill 48 234 338 48 235 338 minecraft:stripped_dark_oak_log
fill 48 234 345 48 235 345 minecraft:stripped_dark_oak_log
fill 48 234 352 48 235 352 minecraft:stripped_dark_oak_log
setblock 52 234 329 minecraft:shroomlight
setblock 52 234 335 minecraft:shroomlight
setblock 52 234 341 minecraft:shroomlight
setblock 52 234 347 minecraft:shroomlight
setblock 52 234 353 minecraft:shroomlight
fill 54 234 323 54 235 323 minecraft:stripped_dark_oak_log
setblock 54 234 327 minecraft:shroomlight
setblock 58 234 359 minecraft:shroomlight
fill 58 234 363 58 235 363 minecraft:stripped_dark_oak_log
setblock 60 234 327 minecraft:shroomlight
fill 61 234 323 61 235 323 minecraft:stripped_dark_oak_log
setblock 64 234 359 minecraft:shroomlight
fill 65 234 363 65 235 363 minecraft:stripped_dark_oak_log
setblock 66 234 327 minecraft:shroomlight
fill 68 234 323 68 235 323 minecraft:stripped_dark_oak_log
setblock 70 234 359 minecraft:shroomlight
setblock 72 234 327 minecraft:shroomlight
fill 72 234 363 72 235 363 minecraft:stripped_dark_oak_log
fill 75 234 323 75 235 323 minecraft:stripped_dark_oak_log
setblock 78 234 327 minecraft:shroomlight
fill 80 234 333 80 242 333 minecraft:dark_oak_planks
fill 81 234 332 82 242 332 minecraft:dark_oak_planks
fill 81 234 334 82 242 334 minecraft:dark_oak_planks
fill 82 234 323 82 235 323 minecraft:stripped_dark_oak_log
setblock 84 234 327 minecraft:shroomlight
setblock 84 234 333 minecraft:shroomlight
setblock 84 234 339 minecraft:shroomlight
setblock 84 234 345 minecraft:shroomlight
setblock 84 234 351 minecraft:shroomlight
fill 88 234 324 88 235 324 minecraft:stripped_dark_oak_log
fill 88 234 331 88 235 331 minecraft:stripped_dark_oak_log
fill 88 234 338 88 235 338 minecraft:stripped_dark_oak_log
fill 88 234 345 88 235 345 minecraft:stripped_dark_oak_log
fill 47 235 324 47 308 324 minecraft:dark_oak_planks
fill 48 235 323 49 235 323 minecraft:stripped_dark_oak_log
fill 48 235 325 66 235 327 minecraft:stripped_dark_oak_log
fill 48 235 329 52 235 330 minecraft:stripped_dark_oak_log
fill 48 235 332 52 235 334 minecraft:stripped_dark_oak_log
fill 48 235 336 52 235 337 minecraft:stripped_dark_oak_log
fill 48 235 339 52 235 341 minecraft:stripped_dark_oak_log
fill 48 235 343 52 235 344 minecraft:stripped_dark_oak_log
fill 48 235 346 52 235 348 minecraft:stripped_dark_oak_log
fill 48 235 350 52 235 351 minecraft:stripped_dark_oak_log
fill 48 235 353 52 235 355 minecraft:stripped_dark_oak_log
fill 48 235 357 48 235 360 minecraft:stripped_dark_oak_log
fill 48 235 361 54 235 362 minecraft:red_concrete
fill 48 235 363 57 235 363 minecraft:stripped_dark_oak_log
fill 49 235 324 87 235 324 minecraft:stripped_dark_oak_log
fill 49 235 328 52 235 328 minecraft:stripped_dark_oak_log
fill 49 235 331 52 235 331 minecraft:stripped_dark_oak_log
fill 49 235 335 52 235 335 minecraft:stripped_dark_oak_log
fill 49 235 338 52 235 338 minecraft:stripped_dark_oak_log
fill 49 235 342 52 235 342 minecraft:stripped_dark_oak_log
fill 49 235 345 52 235 345 minecraft:stripped_dark_oak_log
fill 49 235 349 52 235 349 minecraft:stripped_dark_oak_log
fill 49 235 352 52 235 352 minecraft:stripped_dark_oak_log
fill 49 235 356 52 235 359 minecraft:stripped_dark_oak_log
fill 49 235 360 54 235 360 minecraft:red_concrete
fill 51 235 323 53 235 323 minecraft:stripped_dark_oak_log
fill 53 235 359 75 235 359 minecraft:stripped_dark_oak_log
fill 55 235 323 56 235 323 minecraft:stripped_dark_oak_log
fill 55 235 360 62 235 362 minecraft:stripped_dark_oak_log
fill 58 235 323 60 235 323 minecraft:stripped_dark_oak_log
fill 59 235 363 61 235 363 minecraft:stripped_dark_oak_log
fill 62 235 323 63 235 323 minecraft:stripped_dark_oak_log
fill 63 235 360 75 235 360 minecraft:stripped_dark_oak_log
setblock 63 235 361 minecraft:red_concrete
fill 63 235 362 64 235 363 minecraft:stripped_dark_oak_log
fill 64 235 361 75 235 361 minecraft:stripped_dark_oak_log
fill 65 235 323 67 235 323 minecraft:stripped_dark_oak_log
fill 65 235 362 75 235 362 minecraft:stripped_dark_oak_log
fill 66 235 328 68 237 328 minecraft:cherry_leaves[persistent=true]
fill 66 235 363 68 235 363 minecraft:stripped_dark_oak_log
fill 67 235 325 88 235 326 minecraft:stripped_dark_oak_log
fill 68 235 327 87 235 327 minecraft:stripped_dark_oak_log
fill 69 235 323 70 235 323 minecraft:stripped_dark_oak_log
fill 70 235 363 71 235 363 minecraft:stripped_dark_oak_log
fill 72 235 323 74 235 323 minecraft:stripped_dark_oak_log
fill 73 235 363 75 235 363 minecraft:stripped_dark_oak_log
fill 76 235 323 77 235 323 minecraft:stripped_dark_oak_log
setblock 76 235 357 minecraft:shroomlight
setblock 76 235 359 minecraft:shroomlight
setblock 76 235 361 minecraft:shroomlight
setblock 76 235 363 minecraft:shroomlight
setblock 77 235 358 minecraft:shroomlight
setblock 77 235 360 minecraft:shroomlight
setblock 77 235 362 minecraft:shroomlight
setblock 78 235 357 minecraft:shroomlight
setblock 78 235 359 minecraft:shroomlight
setblock 78 235 361 minecraft:shroomlight
setblock 78 235 363 minecraft:shroomlight
fill 79 235 323 81 235 323 minecraft:stripped_dark_oak_log
setblock 79 235 358 minecraft:shroomlight
setblock 79 235 360 minecraft:shroomlight
setblock 79 235 362 minecraft:shroomlight
fill 80 235 332 80 242 332 minecraft:dark_oak_planks
fill 80 235 334 80 242 334 minecraft:dark_oak_planks
setblock 80 235 357 minecraft:shroomlight
setblock 80 235 359 minecraft:shroomlight
setblock 80 235 361 minecraft:shroomlight
setblock 80 235 363 minecraft:shroomlight
setblock 81 235 358 minecraft:shroomlight
setblock 81 235 360 minecraft:shroomlight
setblock 81 235 362 minecraft:shroomlight
setblock 82 235 353 minecraft:shroomlight
setblock 82 235 355 minecraft:shroomlight
setblock 82 235 357 minecraft:shroomlight
setblock 82 235 359 minecraft:shroomlight
setblock 82 235 361 minecraft:shroomlight
setblock 82 235 363 minecraft:shroomlight
fill 83 235 323 84 235 323 minecraft:stripped_dark_oak_log
fill 83 235 332 83 242 334 minecraft:dark_oak_planks
setblock 83 235 352 minecraft:shroomlight
setblock 83 235 354 minecraft:shroomlight
setblock 83 235 356 minecraft:shroomlight
setblock 83 235 358 minecraft:shroomlight
setblock 83 235 360 minecraft:shroomlight
setblock 83 235 362 minecraft:shroomlight
setblock 83 235 364 minecraft:shroomlight
fill 84 235 328 87 235 351 minecraft:stripped_dark_oak_log
setblock 84 235 353 minecraft:shroomlight
setblock 84 235 355 minecraft:shroomlight
setblock 84 235 357 minecraft:shroomlight
setblock 84 235 359 minecraft:shroomlight
setblock 84 235 361 minecraft:shroomlight
setblock 84 235 363 minecraft:shroomlight
setblock 85 235 352 minecraft:shroomlight
setblock 85 235 354 minecraft:shroomlight
setblock 85 235 356 minecraft:shroomlight
setblock 85 235 358 minecraft:shroomlight
setblock 85 235 360 minecraft:shroomlight
setblock 85 235 362 minecraft:shroomlight
setblock 85 235 364 minecraft:shroomlight
fill 86 235 323 88 235 323 minecraft:stripped_dark_oak_log
setblock 86 235 353 minecraft:shroomlight
setblock 86 235 355 minecraft:shroomlight
setblock 86 235 357 minecraft:shroomlight
setblock 86 235 359 minecraft:shroomlight
setblock 86 235 361 minecraft:shroomlight
setblock 86 235 363 minecraft:shroomlight
setblock 87 235 352 minecraft:shroomlight
setblock 87 235 354 minecraft:shroomlight
setblock 87 235 356 minecraft:shroomlight
setblock 87 235 358 minecraft:shroomlight
setblock 87 235 360 minecraft:shroomlight
setblock 87 235 362 minecraft:shroomlight
setblock 87 235 364 minecraft:shroomlight
fill 88 235 328 88 235 330 minecraft:stripped_dark_oak_log
fill 88 235 332 88 235 333 minecraft:stripped_dark_oak_log
fill 88 235 335 88 235 337 minecraft:stripped_dark_oak_log
fill 88 235 339 88 235 340 minecraft:stripped_dark_oak_log
fill 88 235 342 88 235 344 minecraft:stripped_dark_oak_log
fill 88 235 346 88 235 347 minecraft:stripped_dark_oak_log
fill 88 235 349 88 235 351 minecraft:stripped_dark_oak_log
setblock 88 235 353 minecraft:shroomlight
setblock 88 235 355 minecraft:shroomlight
setblock 88 235 357 minecraft:shroomlight
setblock 88 235 359 minecraft:shroomlight
setblock 88 235 361 minecraft:shroomlight
setblock 88 235 363 minecraft:shroomlight
setblock 48 236 326 minecraft:stripped_dark_oak_log
setblock 48 236 333 minecraft:stripped_dark_oak_log
setblock 48 236 340 minecraft:stripped_dark_oak_log
setblock 48 236 347 minecraft:stripped_dark_oak_log
setblock 48 236 354 minecraft:stripped_dark_oak_log
setblock 48 236 361 minecraft:stripped_dark_oak_log
fill 48 236 363 48 269 363 minecraft:stripped_dark_oak_log
fill 49 236 340 49 248 344 minecraft:red_wool
fill 49 236 348 49 238 352 minecraft:red_wool
fill 49 236 361 53 236 361 minecraft:red_concrete
setblock 52 236 323 minecraft:stripped_dark_oak_log
fill 52 236 327 52 236 359 minecraft:red_concrete
fill 53 236 327 84 236 327 minecraft:red_concrete
fill 53 236 359 75 236 359 minecraft:red_concrete
setblock 53 236 363 minecraft:stripped_dark_oak_log
fill 55 236 363 55 269 363 minecraft:stripped_dark_oak_log
setblock 59 236 323 minecraft:stripped_dark_oak_log
setblock 60 236 363 minecraft:stripped_dark_oak_log
setblock 66 236 323 minecraft:stripped_dark_oak_log
fill 66 236 325 68 236 326 minecraft:cherry_leaves[persistent=true]
fill 67 236 329 68 236 329 minecraft:cherry_leaves[persistent=true]
setblock 67 236 363 minecraft:stripped_dark_oak_log
fill 69 236 326 69 237 326 minecraft:cherry_leaves[persistent=true]
setblock 69 236 328 minecraft:cherry_leaves[persistent=true]
setblock 73 236 323 minecraft:stripped_dark_oak_log
setblock 74 236 363 minecraft:stripped_dark_oak_log
fill 76 236 357 76 237 357 minecraft:stripped_dark_oak_log
fill 76 236 359 76 237 359 minecraft:stripped_dark_oak_log
fill 76 236 361 76 237 361 minecraft:stripped_dark_oak_log
fill 76 236 363 76 237 363 minecraft:stripped_dark_oak_log
fill 77 236 358 77 237 358 minecraft:stripped_dark_oak_log
fill 77 236 360 77 237 360 minecraft:stripped_dark_oak_log
fill 77 236 362 77 237 362 minecraft:stripped_dark_oak_log
fill 78 236 357 78 237 357 minecraft:stripped_dark_oak_log
fill 78 236 359 78 237 359 minecraft:stripped_dark_oak_log
fill 78 236 361 78 237 361 minecraft:stripped_dark_oak_log
fill 78 236 363 78 237 363 minecraft:stripped_dark_oak_log
fill 79 236 333 79 242 333 minecraft:dark_oak_planks
fill 79 236 358 79 237 358 minecraft:stripped_dark_oak_log
fill 79 236 360 79 237 360 minecraft:stripped_dark_oak_log
fill 79 236 362 79 237 362 minecraft:stripped_dark_oak_log
setblock 80 236 323 minecraft:stripped_dark_oak_log
fill 80 236 331 82 242 331 minecraft:dark_oak_planks
fill 80 236 335 82 242 335 minecraft:dark_oak_planks
fill 80 236 357 80 237 357 minecraft:stripped_dark_oak_log
fill 80 236 359 80 237 359 minecraft:stripped_dark_oak_log
fill 80 236 361 80 237 361 minecraft:stripped_dark_oak_log
fill 80 236 363 80 237 363 minecraft:stripped_dark_oak_log
fill 81 236 358 81 237 358 minecraft:stripped_dark_oak_log
fill 81 236 360 81 237 360 minecraft:stripped_dark_oak_log
fill 81 236 362 81 237 362 minecraft:stripped_dark_oak_log
fill 82 236 353 82 237 353 minecraft:stripped_dark_oak_log
fill 82 236 355 82 237 355 minecraft:stripped_dark_oak_log
fill 82 236 357 82 237 357 minecraft:stripped_dark_oak_log
fill 82 236 359 82 237 359 minecraft:stripped_dark_oak_log
fill 82 236 361 82 237 361 minecraft:stripped_dark_oak_log
fill 82 236 363 82 237 363 minecraft:stripped_dark_oak_log
fill 83 236 352 83 237 352 minecraft:stripped_dark_oak_log
fill 83 236 354 83 237 354 minecraft:stripped_dark_oak_log
fill 83 236 356 83 237 356 minecraft:stripped_dark_oak_log
fill 83 236 358 83 237 358 minecraft:stripped_dark_oak_log
fill 83 236 360 83 237 360 minecraft:stripped_dark_oak_log
fill 83 236 362 83 237 362 minecraft:stripped_dark_oak_log
fill 83 236 364 83 237 364 minecraft:dark_oak_planks
fill 84 236 328 84 236 351 minecraft:red_concrete
fill 84 236 353 84 237 353 minecraft:stripped_dark_oak_log
fill 84 236 355 84 237 355 minecraft:stripped_dark_oak_log
fill 84 236 357 84 237 357 minecraft:stripped_dark_oak_log
fill 84 236 359 84 237 359 minecraft:stripped_dark_oak_log
fill 84 236 361 84 237 361 minecraft:stripped_dark_oak_log
fill 84 236 363 84 237 363 minecraft:stripped_dark_oak_log
fill 85 236 352 85 237 352 minecraft:stripped_dark_oak_log
fill 85 236 354 85 237 354 minecraft:stripped_dark_oak_log
fill 85 236 356 85 237 356 minecraft:stripped_dark_oak_log
fill 85 236 358 85 237 358 minecraft:stripped_dark_oak_log
fill 85 236 360 85 237 360 minecraft:stripped_dark_oak_log
fill 85 236 362 85 237 362 minecraft:stripped_dark_oak_log
fill 85 236 364 85 237 364 minecraft:dark_oak_planks
fill 86 236 343 86 241 347 minecraft:red_wool
fill 86 236 353 86 237 353 minecraft:stripped_dark_oak_log
fill 86 236 355 86 237 355 minecraft:stripped_dark_oak_log
fill 86 236 357 86 237 357 minecraft:stripped_dark_oak_log
fill 86 236 359 86 237 359 minecraft:stripped_dark_oak_log
fill 86 236 361 86 237 361 minecraft:stripped_dark_oak_log
fill 86 236 363 86 237 363 minecraft:stripped_dark_oak_log
setblock 87 236 323 minecraft:stripped_dark_oak_log
fill 87 236 352 87 237 352 minecraft:stripped_dark_oak_log
fill 87 236 354 87 237 354 minecraft:stripped_dark_oak_log
fill 87 236 356 87 237 356 minecraft:stripped_dark_oak_log
fill 87 236 358 87 237 358 minecraft:stripped_dark_oak_log
fill 87 236 360 87 237 360 minecraft:stripped_dark_oak_log
fill 87 236 362 87 237 362 minecraft:stripped_dark_oak_log
fill 87 236 364 87 237 364 minecraft:dark_oak_planks
setblock 88 236 329 minecraft:stripped_dark_oak_log
setblock 88 236 336 minecraft:stripped_dark_oak_log
setblock 88 236 343 minecraft:stripped_dark_oak_log
setblock 88 236 350 minecraft:stripped_dark_oak_log
fill 88 236 353 88 237 353 minecraft:stripped_dark_oak_log
fill 88 236 355 88 237 355 minecraft:stripped_dark_oak_log
fill 88 236 357 88 237 357 minecraft:stripped_dark_oak_log
fill 88 236 359 88 237 359 minecraft:stripped_dark_oak_log
fill 88 236 361 88 237 361 minecraft:stripped_dark_oak_log
fill 88 236 363 88 237 363 minecraft:stripped_dark_oak_log
setblock 48 237 327 minecraft:stripped_dark_oak_log
setblock 48 237 334 minecraft:stripped_dark_oak_log
setblock 48 237 341 minecraft:stripped_dark_oak_log
setblock 48 237 348 minecraft:stripped_dark_oak_log
setblock 48 237 355 minecraft:stripped_dark_oak_log
fill 48 237 360 52 237 361 minecraft:red_concrete
setblock 48 237 362 minecraft:stripped_dark_oak_log
fill 49 237 362 52 237 362 minecraft:red_concrete
setblock 51 237 323 minecraft:stripped_dark_oak_log
setblock 54 237 363 minecraft:stripped_dark_oak_log
setblock 58 237 323 minecraft:stripped_dark_oak_log
setblock 61 237 363 minecraft:stripped_dark_oak_log
setblock 65 237 323 minecraft:stripped_dark_oak_log
fill 66 237 326 68 237 327 minecraft:cherry_leaves[persistent=true]
fill 67 237 325 68 237 325 minecraft:cherry_leaves[persistent=true]
setblock 68 237 363 minecraft:stripped_dark_oak_log
setblock 69 237 327 minecraft:cherry_leaves[persistent=true]
setblock 72 237 323 minecraft:stripped_dark_oak_log
setblock 75 237 363 minecraft:stripped_dark_oak_log
setblock 79 237 323 minecraft:stripped_dark_oak_log
fill 79 237 332 79 242 332 minecraft:dark_oak_planks
fill 79 237 334 79 242 334 minecraft:dark_oak_planks
fill 83 237 331 83 242 331 minecraft:dark_oak_planks
fill 83 237 335 83 242 335 minecraft:dark_oak_planks
fill 84 237 332 84 242 334 minecraft:dark_oak_planks
setblock 86 237 323 minecraft:stripped_dark_oak_log
setblock 88 237 328 minecraft:stripped_dark_oak_log
setblock 88 237 335 minecraft:stripped_dark_oak_log
setblock 88 237 342 minecraft:stripped_dark_oak_log
setblock 88 237 349 minecraft:stripped_dark_oak_log
setblock 89 237 349 minecraft:red_concrete
fill 89 237 350 89 308 353 minecraft:dark_oak_planks
fill 49 238 359 51 238 363 minecraft:red_concrete
setblock 50 238 325 minecraft:light[level=12]
setblock 50 238 332 minecraft:light[level=12]
setblock 50 238 339 minecraft:light[level=12]
setblock 50 238 346 minecraft:light[level=12]
setblock 50 238 353 minecraft:light[level=12]
setblock 57 238 325 minecraft:light[level=12]
setblock 57 238 332 minecraft:light[level=12]
setblock 57 238 353 minecraft:light[level=12]
setblock 57 238 360 minecraft:light[level=12]
setblock 64 238 325 minecraft:light[level=12]
setblock 64 238 332 minecraft:light[level=12]
setblock 64 238 339 minecraft:light[level=12]
setblock 64 238 346 minecraft:light[level=12]
setblock 64 238 353 minecraft:light[level=12]
setblock 64 238 360 minecraft:light[level=12]
setblock 71 238 325 minecraft:light[level=12]
setblock 71 238 332 minecraft:light[level=12]
setblock 71 238 339 minecraft:light[level=12]
setblock 71 238 346 minecraft:light[level=12]
setblock 71 238 353 minecraft:light[level=12]
setblock 71 238 360 minecraft:light[level=12]
setblock 75 238 325 minecraft:red_concrete
setblock 76 238 357 minecraft:shroomlight
setblock 76 238 359 minecraft:shroomlight
setblock 76 238 361 minecraft:shroomlight
setblock 76 238 363 minecraft:shroomlight
setblock 77 238 358 minecraft:shroomlight
setblock 77 238 360 minecraft:shroomlight
setblock 77 238 362 minecraft:shroomlight
setblock 78 238 325 minecraft:light[level=12]
setblock 78 238 332 minecraft:light[level=12]
fill 78 238 333 78 242 333 minecraft:dark_oak_planks
setblock 78 238 339 minecraft:light[level=12]
setblock 78 238 346 minecraft:light[level=12]
setblock 78 238 353 minecraft:light[level=12]
setblock 78 238 357 minecraft:shroomlight
setblock 78 238 359 minecraft:shroomlight
setblock 78 238 361 minecraft:shroomlight
setblock 78 238 363 minecraft:shroomlight
fill 79 238 331 79 242 331 minecraft:dark_oak_planks
fill 79 238 335 79 242 335 minecraft:dark_oak_planks
setblock 79 238 358 minecraft:shroomlight
setblock 79 238 360 minecraft:shroomlight
setblock 79 238 362 minecraft:shroomlight
fill 80 238 330 83 239 330 minecraft:dark_oak_planks
fill 80 238 336 83 242 336 minecraft:dark_oak_planks
setblock 80 238 357 minecraft:shroomlight
setblock 80 238 359 minecraft:shroomlight
setblock 80 238 361 minecraft:shroomlight
setblock 80 238 363 minecraft:shroomlight
setblock 81 238 358 minecraft:shroomlight
setblock 81 238 360 minecraft:shroomlight
setblock 81 238 362 minecraft:shroomlight
setblock 82 238 353 minecraft:shroomlight
setblock 82 238 355 minecraft:shroomlight
setblock 82 238 357 minecraft:shroomlight
setblock 82 238 359 minecraft:shroomlight
setblock 82 238 361 minecraft:shroomlight
setblock 82 238 363 minecraft:shroomlight
setblock 83 238 352 minecraft:shroomlight
setblock 83 238 354 minecraft:shroomlight
setblock 83 238 356 minecraft:shroomlight
setblock 83 238 358 minecraft:shroomlight
setblock 83 238 360 minecraft:shroomlight
setblock 83 238 362 minecraft:shroomlight
setblock 83 238 364 minecraft:shroomlight
fill 84 238 331 84 242 331 minecraft:dark_oak_planks
fill 84 238 335 84 242 335 minecraft:dark_oak_planks
setblock 84 238 353 minecraft:shroomlight
setblock 84 238 355 minecraft:shroomlight
setblock 84 238 357 minecraft:shroomlight
setblock 84 238 359 minecraft:shroomlight
setblock 84 238 361 minecraft:shroomlight
setblock 84 238 363 minecraft:shroomlight
setblock 85 238 325 minecraft:light[level=12]
setblock 85 238 332 minecraft:light[level=12]
setblock 85 238 339 minecraft:light[level=12]
setblock 85 238 346 minecraft:light[level=12]
setblock 85 238 352 minecraft:shroomlight
setblock 85 238 354 minecraft:shroomlight
setblock 85 238 356 minecraft:shroomlight
setblock 85 238 358 minecraft:shroomlight
setblock 85 238 360 minecraft:shroomlight
setblock 85 238 362 minecraft:shroomlight
setblock 85 238 364 minecraft:shroomlight
setblock 86 238 353 minecraft:shroomlight
setblock 86 238 355 minecraft:shroomlight
setblock 86 238 357 minecraft:shroomlight
setblock 86 238 359 minecraft:shroomlight
setblock 86 238 361 minecraft:shroomlight
setblock 86 238 363 minecraft:shroomlight
setblock 87 238 352 minecraft:shroomlight
setblock 87 238 354 minecraft:shroomlight
setblock 87 238 356 minecraft:shroomlight
setblock 87 238 358 minecraft:shroomlight
setblock 87 238 360 minecraft:shroomlight
setblock 87 238 362 minecraft:shroomlight
setblock 87 238 364 minecraft:shroomlight
setblock 88 238 353 minecraft:shroomlight
setblock 88 238 355 minecraft:shroomlight
setblock 88 238 357 minecraft:shroomlight
setblock 88 238 359 minecraft:shroomlight
setblock 88 238 361 minecraft:shroomlight
setblock 88 238 363 minecraft:shroomlight
fill 89 238 349 89 308 349 minecraft:dark_oak_planks
fill 48 239 325 50 239 325 minecraft:iron_bars
fill 48 239 329 48 240 329 minecraft:stripped_dark_oak_log
fill 48 239 336 48 240 336 minecraft:stripped_dark_oak_log
fill 48 239 343 48 240 343 minecraft:stripped_dark_oak_log
fill 48 239 350 48 240 350 minecraft:stripped_dark_oak_log
fill 48 239 357 48 240 357 minecraft:stripped_dark_oak_log
fill 49 239 323 49 240 323 minecraft:stripped_dark_oak_log
fill 49 239 347 49 240 353 minecraft:iron_bars
fill 49 239 363 49 240 363 minecraft:stripped_dark_oak_log
fill 56 239 323 56 240 323 minecraft:stripped_dark_oak_log
fill 56 239 363 56 240 363 minecraft:stripped_dark_oak_log
fill 57 239 343 57 240 343 minecraft:stripped_dark_oak_log
fill 63 239 323 63 240 323 minecraft:stripped_dark_oak_log
fill 63 239 363 63 240 363 minecraft:stripped_dark_oak_log
fill 70 239 323 70 240 323 minecraft:stripped_dark_oak_log
fill 70 239 363 70 240 363 minecraft:stripped_dark_oak_log
fill 75 239 325 75 240 325 minecraft:shroomlight
fill 76 239 357 76 240 357 minecraft:stripped_dark_oak_log
fill 76 239 359 76 240 359 minecraft:stripped_dark_oak_log
fill 76 239 361 76 240 361 minecraft:stripped_dark_oak_log
fill 76 239 363 76 240 363 minecraft:stripped_dark_oak_log
fill 77 239 323 77 240 323 minecraft:stripped_dark_oak_log
fill 77 239 358 77 240 358 minecraft:stripped_dark_oak_log
fill 77 239 360 77 240 360 minecraft:stripped_dark_oak_log
fill 77 239 362 77 240 362 minecraft:stripped_dark_oak_log
fill 78 239 331 78 242 332 minecraft:dark_oak_planks
fill 78 239 334 78 242 335 minecraft:dark_oak_planks
fill 78 239 357 78 240 357 minecraft:stripped_dark_oak_log
fill 78 239 359 78 240 359 minecraft:stripped_dark_oak_log
fill 78 239 361 78 240 361 minecraft:stripped_dark_oak_log
fill 78 239 363 78 240 363 minecraft:stripped_dark_oak_log
fill 79 239 330 79 242 330 minecraft:dark_oak_planks
fill 79 239 336 79 242 336 minecraft:dark_oak_planks
fill 79 239 358 79 240 358 minecraft:stripped_dark_oak_log
fill 79 239 360 79 240 360 minecraft:stripped_dark_oak_log
fill 79 239 362 79 240 362 minecraft:stripped_dark_oak_log
fill 80 239 357 80 240 357 minecraft:stripped_dark_oak_log
fill 80 239 359 80 240 359 minecraft:stripped_dark_oak_log
fill 80 239 361 80 240 361 minecraft:stripped_dark_oak_log
fill 80 239 363 80 240 363 minecraft:stripped_dark_oak_log
fill 81 239 358 81 240 358 minecraft:stripped_dark_oak_log
fill 81 239 360 81 240 360 minecraft:stripped_dark_oak_log
fill 81 239 362 81 240 362 minecraft:stripped_dark_oak_log
fill 82 239 353 82 240 353 minecraft:stripped_dark_oak_log
fill 82 239 355 82 240 355 minecraft:stripped_dark_oak_log
fill 82 239 357 82 240 357 minecraft:stripped_dark_oak_log
fill 82 239 359 82 240 359 minecraft:stripped_dark_oak_log
fill 82 239 361 82 240 361 minecraft:stripped_dark_oak_log
fill 82 239 363 82 240 363 minecraft:stripped_dark_oak_log
fill 83 239 352 83 240 352 minecraft:stripped_dark_oak_log
fill 83 239 354 83 240 354 minecraft:stripped_dark_oak_log
fill 83 239 356 83 240 356 minecraft:stripped_dark_oak_log
fill 83 239 358 83 240 358 minecraft:stripped_dark_oak_log
fill 83 239 360 83 240 360 minecraft:stripped_dark_oak_log
fill 83 239 362 83 240 362 minecraft:stripped_dark_oak_log
fill 83 239 364 83 240 364 minecraft:dark_oak_planks
fill 84 239 323 84 240 323 minecraft:stripped_dark_oak_log
fill 84 239 353 84 240 353 minecraft:stripped_dark_oak_log
fill 84 239 355 84 240 355 minecraft:stripped_dark_oak_log
fill 84 239 357 84 240 357 minecraft:stripped_dark_oak_log
fill 84 239 359 84 240 359 minecraft:stripped_dark_oak_log
fill 84 239 361 84 240 361 minecraft:stripped_dark_oak_log
fill 84 239 363 84 240 363 minecraft:stripped_dark_oak_log
fill 85 239 332 85 242 334 minecraft:dark_oak_planks
fill 85 239 352 85 240 352 minecraft:stripped_dark_oak_log
fill 85 239 354 85 240 354 minecraft:stripped_dark_oak_log
fill 85 239 356 85 240 356 minecraft:stripped_dark_oak_log
fill 85 239 358 85 240 358 minecraft:stripped_dark_oak_log
fill 85 239 360 85 240 360 minecraft:stripped_dark_oak_log
fill 85 239 362 85 240 362 minecraft:stripped_dark_oak_log
fill 85 239 364 85 240 364 minecraft:dark_oak_planks
fill 86 239 353 86 240 353 minecraft:stripped_dark_oak_log
fill 86 239 355 86 240 355 minecraft:stripped_dark_oak_log
fill 86 239 357 86 240 357 minecraft:stripped_dark_oak_log
fill 86 239 359 86 240 359 minecraft:stripped_dark_oak_log
fill 86 239 361 86 240 361 minecraft:stripped_dark_oak_log
fill 86 239 363 86 240 363 minecraft:stripped_dark_oak_log
fill 87 239 352 87 240 352 minecraft:stripped_dark_oak_log
fill 87 239 354 87 240 354 minecraft:stripped_dark_oak_log
fill 87 239 356 87 240 356 minecraft:stripped_dark_oak_log
fill 87 239 358 87 240 358 minecraft:stripped_dark_oak_log
fill 87 239 360 87 240 360 minecraft:stripped_dark_oak_log
fill 87 239 362 87 240 362 minecraft:stripped_dark_oak_log
fill 87 239 364 87 240 364 minecraft:dark_oak_planks
fill 88 239 326 88 240 326 minecraft:stripped_dark_oak_log
fill 88 239 333 88 240 333 minecraft:stripped_dark_oak_log
fill 88 239 340 88 240 340 minecraft:stripped_dark_oak_log
fill 88 239 347 88 240 347 minecraft:stripped_dark_oak_log
fill 88 239 353 88 240 353 minecraft:stripped_dark_oak_log
fill 88 239 355 88 240 355 minecraft:stripped_dark_oak_log
fill 88 239 357 88 240 357 minecraft:stripped_dark_oak_log
fill 88 239 359 88 240 359 minecraft:stripped_dark_oak_log
fill 88 239 361 88 240 361 minecraft:stripped_dark_oak_log
fill 88 239 363 88 240 363 minecraft:stripped_dark_oak_log
fill 48 240 323 48 240 327 minecraft:stripped_dark_oak_log
fill 48 240 330 48 240 334 minecraft:stripped_dark_oak_log
fill 48 240 337 48 240 341 minecraft:stripped_dark_oak_log
fill 48 240 344 48 240 348 minecraft:stripped_dark_oak_log
fill 48 240 351 48 240 355 minecraft:stripped_dark_oak_log
fill 48 240 358 48 240 362 minecraft:stripped_dark_oak_log
fill 49 240 325 50 240 325 minecraft:iron_bars
setblock 50 240 333 minecraft:light[level=15]
setblock 50 240 341 minecraft:light[level=15]
setblock 50 240 349 minecraft:light[level=15]
setblock 50 240 357 minecraft:light[level=15]
fill 50 240 363 54 240 363 minecraft:stripped_dark_oak_log
fill 51 240 323 55 240 323 minecraft:stripped_dark_oak_log
fill 57 240 363 61 240 363 minecraft:stripped_dark_oak_log
fill 58 240 323 62 240 323 minecraft:stripped_dark_oak_log
setblock 58 240 325 minecraft:light[level=15]
setblock 58 240 333 minecraft:light[level=15]
setblock 58 240 341 minecraft:light[level=15]
setblock 58 240 349 minecraft:light[level=15]
setblock 58 240 357 minecraft:light[level=15]
fill 64 240 363 68 240 363 minecraft:stripped_dark_oak_log
fill 65 240 323 69 240 323 minecraft:stripped_dark_oak_log
setblock 66 240 325 minecraft:light[level=15]
setblock 66 240 333 minecraft:light[level=15]
setblock 66 240 341 minecraft:light[level=15]
setblock 66 240 349 minecraft:light[level=15]
setblock 66 240 357 minecraft:light[level=15]
fill 71 240 363 75 240 363 minecraft:stripped_dark_oak_log
fill 72 240 323 76 240 323 minecraft:stripped_dark_oak_log
setblock 74 240 325 minecraft:light[level=15]
setblock 74 240 333 minecraft:light[level=15]
setblock 74 240 341 minecraft:light[level=15]
setblock 74 240 349 minecraft:light[level=15]
setblock 74 240 357 minecraft:light[level=15]
fill 77 240 333 77 242 333 minecraft:dark_oak_planks
fill 79 240 323 83 240 323 minecraft:stripped_dark_oak_log
fill 80 240 329 81 242 330 minecraft:dark_oak_planks
fill 80 240 337 83 242 337 minecraft:dark_oak_planks
setblock 82 240 325 minecraft:light[level=15]
fill 82 240 329 83 242 329 minecraft:dark_oak_planks
fill 82 240 330 82 243 330 minecraft:iron_bars
setblock 82 240 341 minecraft:light[level=15]
setblock 82 240 349 minecraft:light[level=15]
fill 83 240 330 84 242 330 minecraft:dark_oak_planks
fill 84 240 336 84 242 336 minecraft:dark_oak_planks
fill 85 240 331 85 242 331 minecraft:dark_oak_planks
fill 85 240 335 85 242 335 minecraft:dark_oak_planks
fill 86 240 323 88 240 323 minecraft:stripped_dark_oak_log
fill 88 240 324 88 240 325 minecraft:stripped_dark_oak_log
fill 88 240 328 88 240 332 minecraft:stripped_dark_oak_log
fill 88 240 335 88 240 339 minecraft:stripped_dark_oak_log
fill 88 240 342 88 240 346 minecraft:stripped_dark_oak_log
fill 88 240 349 88 240 351 minecraft:stripped_dark_oak_log
fill 48 241 322 51 303 322 minecraft:dark_oak_planks
setblock 48 241 324 minecraft:stripped_dark_oak_log
setblock 48 241 331 minecraft:stripped_dark_oak_log
setblock 48 241 338 minecraft:stripped_dark_oak_log
setblock 48 241 345 minecraft:stripped_dark_oak_log
setblock 48 241 352 minecraft:stripped_dark_oak_log
setblock 48 241 359 minecraft:stripped_dark_oak_log
setblock 51 241 363 minecraft:stripped_dark_oak_log
setblock 52 241 322 minecraft:red_concrete
fill 53 241 322 56 245 322 minecraft:dark_oak_planks
setblock 54 241 323 minecraft:stripped_dark_oak_log
setblock 58 241 363 minecraft:stripped_dark_oak_log
setblock 61 241 323 minecraft:stripped_dark_oak_log
setblock 65 241 363 minecraft:stripped_dark_oak_log
setblock 68 241 323 minecraft:stripped_dark_oak_log
setblock 72 241 363 minecraft:stripped_dark_oak_log
setblock 75 241 323 minecraft:stripped_dark_oak_log
setblock 75 241 325 minecraft:red_concrete
setblock 76 241 357 minecraft:shroomlight
setblock 76 241 359 minecraft:shroomlight
setblock 76 241 361 minecraft:shroomlight
setblock 76 241 363 minecraft:shroomlight
fill 77 241 331 77 242 332 minecraft:dark_oak_planks
fill 77 241 334 77 242 335 minecraft:dark_oak_planks
setblock 77 241 358 minecraft:shroomlight
setblock 77 241 360 minecraft:shroomlight
setblock 77 241 362 minecraft:shroomlight
fill 78 241 330 78 242 330 minecraft:dark_oak_planks
fill 78 241 336 78 242 336 minecraft:dark_oak_planks
setblock 78 241 357 minecraft:shroomlight
setblock 78 241 359 minecraft:shroomlight
setblock 78 241 361 minecraft:shroomlight
setblock 78 241 363 minecraft:shroomlight
fill 79 241 329 79 242 329 minecraft:dark_oak_planks
fill 79 241 337 79 242 337 minecraft:dark_oak_planks
setblock 79 241 358 minecraft:shroomlight
setblock 79 241 360 minecraft:shroomlight
setblock 79 241 362 minecraft:shroomlight
setblock 80 241 357 minecraft:shroomlight
setblock 80 241 359 minecraft:shroomlight
setblock 80 241 361 minecraft:shroomlight
setblock 80 241 363 minecraft:shroomlight
setblock 81 241 358 minecraft:shroomlight
setblock 81 241 360 minecraft:shroomlight
setblock 81 241 362 minecraft:shroomlight
setblock 82 241 323 minecraft:stripped_dark_oak_log
setblock 82 241 353 minecraft:shroomlight
setblock 82 241 355 minecraft:shroomlight
setblock 82 241 357 minecraft:shroomlight
setblock 82 241 359 minecraft:shroomlight
setblock 82 241 361 minecraft:shroomlight
setblock 82 241 363 minecraft:shroomlight
setblock 83 241 352 minecraft:shroomlight
setblock 83 241 354 minecraft:shroomlight
setblock 83 241 356 minecraft:shroomlight
setblock 83 241 358 minecraft:shroomlight
setblock 83 241 360 minecraft:shroomlight
setblock 83 241 362 minecraft:shroomlight
setblock 83 241 364 minecraft:shroomlight
fill 84 241 329 84 242 329 minecraft:dark_oak_planks
fill 84 241 337 84 242 337 minecraft:dark_oak_planks
setblock 84 241 353 minecraft:shroomlight
setblock 84 241 355 minecraft:shroomlight
setblock 84 241 357 minecraft:shroomlight
setblock 84 241 359 minecraft:shroomlight
setblock 84 241 361 minecraft:shroomlight
setblock 84 241 363 minecraft:shroomlight
fill 85 241 330 85 242 330 minecraft:dark_oak_planks
fill 85 241 336 85 242 336 minecraft:dark_oak_planks
setblock 85 241 352 minecraft:shroomlight
setblock 85 241 354 minecraft:shroomlight
setblock 85 241 356 minecraft:shroomlight
setblock 85 241 358 minecraft:shroomlight
setblock 85 241 360 minecraft:shroomlight
setblock 85 241 362 minecraft:shroomlight
setblock 85 241 364 minecraft:shroomlight
fill 86 241 332 86 242 334 minecraft:dark_oak_planks
setblock 86 241 353 minecraft:shroomlight
setblock 86 241 355 minecraft:shroomlight
setblock 86 241 357 minecraft:shroomlight
setblock 86 241 359 minecraft:shroomlight
setblock 86 241 361 minecraft:shroomlight
setblock 86 241 363 minecraft:shroomlight
setblock 87 241 352 minecraft:shroomlight
setblock 87 241 354 minecraft:shroomlight
setblock 87 241 356 minecraft:shroomlight
setblock 87 241 358 minecraft:shroomlight
setblock 87 241 360 minecraft:shroomlight
setblock 87 241 362 minecraft:shroomlight
setblock 87 241 364 minecraft:shroomlight
setblock 88 241 324 minecraft:stripped_dark_oak_log
setblock 88 241 331 minecraft:stripped_dark_oak_log
setblock 88 241 338 minecraft:stripped_dark_oak_log
setblock 88 241 345 minecraft:stripped_dark_oak_log
setblock 88 241 353 minecraft:shroomlight
setblock 88 241 355 minecraft:shroomlight
setblock 88 241 357 minecraft:shroomlight
setblock 88 241 359 minecraft:shroomlight
setblock 88 241 361 minecraft:shroomlight
setblock 88 241 363 minecraft:shroomlight
setblock 48 242 325 minecraft:stripped_dark_oak_log
setblock 48 242 332 minecraft:stripped_dark_oak_log
setblock 48 242 339 minecraft:stripped_dark_oak_log
setblock 48 242 346 minecraft:stripped_dark_oak_log
setblock 48 242 353 minecraft:stripped_dark_oak_log
setblock 48 242 360 minecraft:stripped_dark_oak_log
fill 52 242 322 52 308 322 minecraft:dark_oak_planks
setblock 52 242 363 minecraft:stripped_dark_oak_log
setblock 53 242 323 minecraft:stripped_dark_oak_log
setblock 59 242 363 minecraft:stripped_dark_oak_log
setblock 60 242 323 minecraft:stripped_dark_oak_log
setblock 66 242 363 minecraft:stripped_dark_oak_log
setblock 67 242 323 minecraft:stripped_dark_oak_log
setblock 73 242 363 minecraft:stripped_dark_oak_log
setblock 74 242 323 minecraft:stripped_dark_oak_log
setblock 76 242 333 minecraft:dark_oak_planks
fill 76 242 357 76 243 357 minecraft:stripped_dark_oak_log
fill 76 242 359 76 243 359 minecraft:stripped_dark_oak_log
fill 76 242 361 76 243 361 minecraft:stripped_dark_oak_log
fill 76 242 363 76 243 363 minecraft:stripped_dark_oak_log
setblock 77 242 330 minecraft:dark_oak_planks
setblock 77 242 336 minecraft:dark_oak_planks
fill 77 242 358 77 243 358 minecraft:stripped_dark_oak_log
fill 77 242 360 77 243 360 minecraft:stripped_dark_oak_log
fill 77 242 362 77 243 362 minecraft:stripped_dark_oak_log
setblock 78 242 329 minecraft:dark_oak_planks
setblock 78 242 337 minecraft:dark_oak_planks
fill 78 242 357 78 243 357 minecraft:stripped_dark_oak_log
fill 78 242 359 78 243 359 minecraft:stripped_dark_oak_log
fill 78 242 361 78 243 361 minecraft:stripped_dark_oak_log
fill 78 242 363 78 243 363 minecraft:stripped_dark_oak_log
fill 79 242 358 79 243 358 minecraft:stripped_dark_oak_log
fill 79 242 360 79 243 360 minecraft:stripped_dark_oak_log
fill 79 242 362 79 243 362 minecraft:stripped_dark_oak_log
fill 80 242 328 83 242 328 minecraft:dark_oak_planks
fill 80 242 338 83 242 338 minecraft:dark_oak_planks
fill 80 242 357 80 243 357 minecraft:stripped_dark_oak_log
fill 80 242 359 80 243 359 minecraft:stripped_dark_oak_log
fill 80 242 361 80 243 361 minecraft:stripped_dark_oak_log
fill 80 242 363 80 243 363 minecraft:stripped_dark_oak_log
setblock 81 242 323 minecraft:stripped_dark_oak_log
fill 81 242 358 81 243 358 minecraft:stripped_dark_oak_log
fill 81 242 360 81 243 360 minecraft:stripped_dark_oak_log
fill 81 242 362 81 243 362 minecraft:stripped_dark_oak_log
fill 82 242 353 82 243 353 minecraft:stripped_dark_oak_log
fill 82 242 355 82 243 355 minecraft:stripped_dark_oak_log
fill 82 242 357 82 243 357 minecraft:stripped_dark_oak_log
fill 82 242 359 82 243 359 minecraft:stripped_dark_oak_log
fill 82 242 361 82 243 361 minecraft:stripped_dark_oak_log
fill 82 242 363 82 243 363 minecraft:stripped_dark_oak_log
fill 83 242 352 83 243 352 minecraft:stripped_dark_oak_log
fill 83 242 354 83 243 354 minecraft:stripped_dark_oak_log
fill 83 242 356 83 243 356 minecraft:stripped_dark_oak_log
fill 83 242 358 83 243 358 minecraft:stripped_dark_oak_log
fill 83 242 360 83 243 360 minecraft:stripped_dark_oak_log
fill 83 242 362 83 243 362 minecraft:stripped_dark_oak_log
fill 83 242 364 83 243 364 minecraft:dark_oak_planks
fill 84 242 353 84 243 353 minecraft:stripped_dark_oak_log
fill 84 242 355 84 243 355 minecraft:stripped_dark_oak_log
fill 84 242 357 84 243 357 minecraft:stripped_dark_oak_log
fill 84 242 359 84 243 359 minecraft:stripped_dark_oak_log
fill 84 242 361 84 243 361 minecraft:stripped_dark_oak_log
fill 84 242 363 84 243 363 minecraft:stripped_dark_oak_log
setblock 85 242 329 minecraft:dark_oak_planks
fill 85 242 352 85 243 352 minecraft:stripped_dark_oak_log
fill 85 242 354 85 243 354 minecraft:stripped_dark_oak_log
fill 85 242 356 85 243 356 minecraft:stripped_dark_oak_log
fill 85 242 358 85 243 358 minecraft:stripped_dark_oak_log
fill 85 242 360 85 243 360 minecraft:stripped_dark_oak_log
fill 85 242 362 85 243 362 minecraft:stripped_dark_oak_log
fill 85 242 364 85 243 364 minecraft:dark_oak_planks
setblock 86 242 331 minecraft:dark_oak_planks
setblock 86 242 335 minecraft:dark_oak_planks
fill 86 242 342 86 243 348 minecraft:iron_bars
fill 86 242 353 86 243 353 minecraft:stripped_dark_oak_log
fill 86 242 355 86 243 355 minecraft:stripped_dark_oak_log
fill 86 242 357 86 243 357 minecraft:stripped_dark_oak_log
fill 86 242 359 86 243 359 minecraft:stripped_dark_oak_log
fill 86 242 361 86 243 361 minecraft:stripped_dark_oak_log
fill 86 242 363 86 243 363 minecraft:stripped_dark_oak_log
fill 87 242 352 87 243 352 minecraft:stripped_dark_oak_log
fill 87 242 354 87 243 354 minecraft:stripped_dark_oak_log
fill 87 242 356 87 243 356 minecraft:stripped_dark_oak_log
fill 87 242 358 87 243 358 minecraft:stripped_dark_oak_log
fill 87 242 360 87 243 360 minecraft:stripped_dark_oak_log
fill 87 242 362 87 243 362 minecraft:stripped_dark_oak_log
fill 87 242 364 87 243 364 minecraft:dark_oak_planks
setblock 88 242 323 minecraft:stripped_dark_oak_log
setblock 88 242 330 minecraft:stripped_dark_oak_log
setblock 88 242 337 minecraft:stripped_dark_oak_log
setblock 88 242 344 minecraft:stripped_dark_oak_log
setblock 88 242 351 minecraft:stripped_dark_oak_log
fill 88 242 353 88 243 353 minecraft:stripped_dark_oak_log
fill 88 242 355 88 243 355 minecraft:stripped_dark_oak_log
fill 88 242 357 88 243 357 minecraft:stripped_dark_oak_log
fill 88 242 359 88 243 359 minecraft:stripped_dark_oak_log
fill 88 242 361 88 243 361 minecraft:stripped_dark_oak_log
fill 88 242 363 88 243 363 minecraft:stripped_dark_oak_log
setblock 48 243 326 minecraft:stripped_dark_oak_log
setblock 48 243 333 minecraft:stripped_dark_oak_log
setblock 48 243 340 minecraft:stripped_dark_oak_log
setblock 48 243 347 minecraft:stripped_dark_oak_log
setblock 48 243 354 minecraft:stripped_dark_oak_log
setblock 48 243 361 minecraft:stripped_dark_oak_log
setblock 52 243 323 minecraft:stripped_dark_oak_log
setblock 53 243 363 minecraft:stripped_dark_oak_log
setblock 59 243 323 minecraft:stripped_dark_oak_log
setblock 60 243 363 minecraft:stripped_dark_oak_log
setblock 66 243 323 minecraft:stripped_dark_oak_log
setblock 67 243 363 minecraft:stripped_dark_oak_log
setblock 73 243 323 minecraft:stripped_dark_oak_log
setblock 74 243 363 minecraft:stripped_dark_oak_log
setblock 80 243 323 minecraft:stripped_dark_oak_log
fill 81 243 333 81 245 333 minecraft:stripped_dark_oak_log
setblock 87 243 323 minecraft:stripped_dark_oak_log
setblock 88 243 329 minecraft:stripped_dark_oak_log
setblock 88 243 336 minecraft:stripped_dark_oak_log
setblock 88 243 343 minecraft:stripped_dark_oak_log
setblock 88 243 350 minecraft:stripped_dark_oak_log
setblock 48 244 327 minecraft:stripped_dark_oak_log
setblock 48 244 334 minecraft:stripped_dark_oak_log
setblock 48 244 341 minecraft:stripped_dark_oak_log
setblock 48 244 348 minecraft:stripped_dark_oak_log
setblock 48 244 355 minecraft:stripped_dark_oak_log
setblock 48 244 362 minecraft:stripped_dark_oak_log
setblock 50 244 325 minecraft:light[level=12]
setblock 50 244 332 minecraft:light[level=12]
setblock 50 244 339 minecraft:light[level=12]
setblock 50 244 346 minecraft:light[level=12]
setblock 50 244 353 minecraft:light[level=12]
setblock 50 244 360 minecraft:light[level=12]
setblock 51 244 323 minecraft:stripped_dark_oak_log
setblock 54 244 363 minecraft:stripped_dark_oak_log
setblock 57 244 325 minecraft:light[level=12]
setblock 57 244 332 minecraft:light[level=12]
setblock 57 244 339 minecraft:light[level=12]
setblock 57 244 346 minecraft:light[level=12]
setblock 57 244 353 minecraft:light[level=12]
setblock 57 244 360 minecraft:light[level=12]
setblock 58 244 323 minecraft:stripped_dark_oak_log
setblock 61 244 363 minecraft:stripped_dark_oak_log
setblock 64 244 325 minecraft:light[level=12]
setblock 64 244 332 minecraft:light[level=12]
setblock 64 244 339 minecraft:light[level=12]
setblock 64 244 346 minecraft:light[level=12]
setblock 64 244 353 minecraft:light[level=12]
setblock 64 244 360 minecraft:light[level=12]
setblock 65 244 323 minecraft:stripped_dark_oak_log
fill 66 244 322 66 308 322 minecraft:dark_oak_planks
setblock 67 244 322 minecraft:red_concrete
setblock 68 244 363 minecraft:stripped_dark_oak_log
setblock 71 244 325 minecraft:light[level=12]
setblock 71 244 332 minecraft:light[level=12]
setblock 71 244 339 minecraft:light[level=12]
setblock 71 244 346 minecraft:light[level=12]
setblock 71 244 353 minecraft:light[level=12]
setblock 71 244 360 minecraft:light[level=12]
setblock 72 244 323 minecraft:stripped_dark_oak_log
setblock 75 244 363 minecraft:stripped_dark_oak_log
setblock 76 244 357 minecraft:shroomlight
setblock 76 244 359 minecraft:shroomlight
setblock 76 244 361 minecraft:shroomlight
setblock 76 244 363 minecraft:shroomlight
setblock 77 244 358 minecraft:shroomlight
setblock 77 244 360 minecraft:shroomlight
setblock 77 244 362 minecraft:shroomlight
setblock 78 244 325 minecraft:light[level=12]
setblock 78 244 332 minecraft:light[level=12]
setblock 78 244 339 minecraft:light[level=12]
setblock 78 244 346 minecraft:light[level=12]
setblock 78 244 353 minecraft:light[level=12]
setblock 78 244 357 minecraft:shroomlight
setblock 78 244 359 minecraft:shroomlight
setblock 78 244 361 minecraft:shroomlight
setblock 78 244 363 minecraft:shroomlight
setblock 79 244 323 minecraft:stripped_dark_oak_log
setblock 79 244 358 minecraft:shroomlight
setblock 79 244 360 minecraft:shroomlight
setblock 79 244 362 minecraft:shroomlight
setblock 80 244 357 minecraft:shroomlight
setblock 80 244 359 minecraft:shroomlight
setblock 80 244 361 minecraft:shroomlight
setblock 80 244 363 minecraft:shroomlight
setblock 81 244 358 minecraft:shroomlight
setblock 81 244 360 minecraft:shroomlight
setblock 81 244 362 minecraft:shroomlight
fill 82 244 325 87 244 335 minecraft:dark_oak_planks
setblock 82 244 353 minecraft:shroomlight
setblock 82 244 355 minecraft:shroomlight
setblock 82 244 357 minecraft:shroomlight
setblock 82 244 359 minecraft:shroomlight
setblock 82 244 361 minecraft:shroomlight
setblock 82 244 363 minecraft:shroomlight
setblock 83 244 352 minecraft:shroomlight
setblock 83 244 354 minecraft:shroomlight
setblock 83 244 356 minecraft:shroomlight
setblock 83 244 358 minecraft:shroomlight
setblock 83 244 360 minecraft:shroomlight
setblock 83 244 362 minecraft:shroomlight
setblock 83 244 364 minecraft:shroomlight
setblock 84 244 353 minecraft:shroomlight
setblock 84 244 355 minecraft:shroomlight
setblock 84 244 357 minecraft:shroomlight
setblock 84 244 359 minecraft:shroomlight
setblock 84 244 361 minecraft:shroomlight
setblock 84 244 363 minecraft:shroomlight
setblock 85 244 339 minecraft:light[level=12]
setblock 85 244 346 minecraft:light[level=12]
setblock 85 244 352 minecraft:shroomlight
setblock 85 244 354 minecraft:shroomlight
setblock 85 244 356 minecraft:shroomlight
setblock 85 244 358 minecraft:shroomlight
setblock 85 244 360 minecraft:shroomlight
setblock 85 244 362 minecraft:shroomlight
setblock 85 244 364 minecraft:shroomlight
setblock 86 244 323 minecraft:stripped_dark_oak_log
setblock 86 244 353 minecraft:shroomlight
setblock 86 244 355 minecraft:shroomlight
setblock 86 244 357 minecraft:shroomlight
setblock 86 244 359 minecraft:shroomlight
setblock 86 244 361 minecraft:shroomlight
setblock 86 244 363 minecraft:shroomlight
setblock 87 244 352 minecraft:shroomlight
setblock 87 244 354 minecraft:shroomlight
setblock 87 244 356 minecraft:shroomlight
setblock 87 244 358 minecraft:shroomlight
setblock 87 244 360 minecraft:shroomlight
setblock 87 244 362 minecraft:shroomlight
setblock 87 244 364 minecraft:shroomlight
setblock 88 244 328 minecraft:stripped_dark_oak_log
setblock 88 244 335 minecraft:stripped_dark_oak_log
setblock 88 244 342 minecraft:stripped_dark_oak_log
setblock 88 244 349 minecraft:stripped_dark_oak_log
setblock 88 244 353 minecraft:shroomlight
setblock 88 244 355 minecraft:shroomlight
setblock 88 244 357 minecraft:shroomlight
setblock 88 244 359 minecraft:shroomlight
setblock 88 244 361 minecraft:shroomlight
setblock 88 244 363 minecraft:shroomlight
fill 67 245 322 67 308 322 minecraft:dark_oak_planks
fill 76 245 357 76 247 357 minecraft:stripped_dark_oak_log
fill 76 245 359 76 247 359 minecraft:stripped_dark_oak_log
fill 76 245 361 76 247 361 minecraft:stripped_dark_oak_log
fill 76 245 363 76 269 363 minecraft:stripped_dark_oak_log
fill 77 245 358 77 247 358 minecraft:stripped_dark_oak_log
fill 77 245 360 77 247 360 minecraft:stripped_dark_oak_log
fill 77 245 362 77 247 362 minecraft:stripped_dark_oak_log
fill 78 245 357 78 247 357 minecraft:stripped_dark_oak_log
fill 78 245 359 78 247 359 minecraft:stripped_dark_oak_log
fill 78 245 361 78 247 361 minecraft:stripped_dark_oak_log
fill 78 245 363 78 247 363 minecraft:stripped_dark_oak_log
fill 79 245 358 79 247 358 minecraft:stripped_dark_oak_log
fill 79 245 360 79 247 360 minecraft:stripped_dark_oak_log
fill 79 245 362 79 247 362 minecraft:stripped_dark_oak_log
fill 80 245 357 80 247 357 minecraft:stripped_dark_oak_log
fill 80 245 359 80 247 359 minecraft:stripped_dark_oak_log
fill 80 245 361 80 247 361 minecraft:stripped_dark_oak_log
fill 80 245 363 80 247 363 minecraft:stripped_dark_oak_log
fill 81 245 358 81 247 358 minecraft:stripped_dark_oak_log
fill 81 245 360 81 247 360 minecraft:stripped_dark_oak_log
fill 81 245 362 81 247 362 minecraft:stripped_dark_oak_log
fill 82 245 325 87 245 335 minecraft:stripped_dark_oak_log
fill 82 245 353 82 247 353 minecraft:stripped_dark_oak_log
fill 82 245 355 82 247 355 minecraft:stripped_dark_oak_log
fill 82 245 357 82 247 357 minecraft:stripped_dark_oak_log
fill 82 245 359 82 247 359 minecraft:stripped_dark_oak_log
fill 82 245 361 82 247 361 minecraft:stripped_dark_oak_log
fill 82 245 363 82 247 363 minecraft:stripped_dark_oak_log
fill 83 245 352 83 247 352 minecraft:stripped_dark_oak_log
fill 83 245 354 83 246 354 minecraft:stripped_dark_oak_log
fill 83 245 356 83 246 356 minecraft:stripped_dark_oak_log
fill 83 245 358 83 246 358 minecraft:stripped_dark_oak_log
fill 83 245 360 83 246 360 minecraft:stripped_dark_oak_log
fill 83 245 362 83 246 362 minecraft:stripped_dark_oak_log
fill 83 245 364 83 246 364 minecraft:dark_oak_planks
fill 84 245 353 84 247 353 minecraft:stripped_dark_oak_log
fill 84 245 355 84 246 355 minecraft:stripped_dark_oak_log
fill 84 245 357 84 246 357 minecraft:stripped_dark_oak_log
fill 84 245 359 84 246 359 minecraft:stripped_dark_oak_log
fill 84 245 361 84 246 361 minecraft:stripped_dark_oak_log
fill 84 245 363 84 246 363 minecraft:stripped_dark_oak_log
fill 85 245 352 85 247 352 minecraft:stripped_dark_oak_log
fill 85 245 354 85 246 354 minecraft:stripped_dark_oak_log
fill 85 245 356 85 246 356 minecraft:stripped_dark_oak_log
fill 85 245 358 85 246 358 minecraft:stripped_dark_oak_log
fill 85 245 360 85 246 360 minecraft:stripped_dark_oak_log
fill 85 245 362 85 246 362 minecraft:stripped_dark_oak_log
fill 85 245 364 85 246 364 minecraft:dark_oak_planks
fill 86 245 353 86 247 353 minecraft:stripped_dark_oak_log
fill 86 245 355 86 246 355 minecraft:stripped_dark_oak_log
fill 86 245 357 86 246 357 minecraft:stripped_dark_oak_log
fill 86 245 359 86 246 359 minecraft:stripped_dark_oak_log
fill 86 245 361 86 246 361 minecraft:stripped_dark_oak_log
fill 86 245 363 86 246 363 minecraft:stripped_dark_oak_log
fill 87 245 352 87 247 352 minecraft:stripped_dark_oak_log
fill 87 245 354 87 246 354 minecraft:stripped_dark_oak_log
fill 87 245 356 87 246 356 minecraft:stripped_dark_oak_log
fill 87 245 358 87 246 358 minecraft:stripped_dark_oak_log
fill 87 245 360 87 246 360 minecraft:stripped_dark_oak_log
fill 87 245 362 87 246 362 minecraft:stripped_dark_oak_log
fill 87 245 364 87 246 364 minecraft:dark_oak_planks
fill 88 245 353 88 247 353 minecraft:stripped_dark_oak_log
fill 88 245 355 88 246 355 minecraft:stripped_dark_oak_log
fill 88 245 357 88 246 357 minecraft:stripped_dark_oak_log
fill 88 245 359 88 246 359 minecraft:stripped_dark_oak_log
fill 88 245 361 88 246 361 minecraft:stripped_dark_oak_log
fill 88 245 363 88 246 363 minecraft:stripped_dark_oak_log
setblock 48 246 329 minecraft:stripped_dark_oak_log
setblock 48 246 336 minecraft:stripped_dark_oak_log
setblock 48 246 343 minecraft:stripped_dark_oak_log
setblock 48 246 350 minecraft:stripped_dark_oak_log
setblock 48 246 357 minecraft:stripped_dark_oak_log
setblock 49 246 323 minecraft:stripped_dark_oak_log
setblock 49 246 363 minecraft:stripped_dark_oak_log
fill 53 246 322 55 308 322 minecraft:dark_oak_planks
setblock 56 246 322 minecraft:red_concrete
setblock 56 246 323 minecraft:stripped_dark_oak_log
setblock 56 246 363 minecraft:stripped_dark_oak_log
setblock 63 246 323 minecraft:stripped_dark_oak_log
setblock 63 246 363 minecraft:stripped_dark_oak_log
setblock 70 246 323 minecraft:stripped_dark_oak_log
setblock 70 246 363 minecraft:stripped_dark_oak_log
setblock 74 246 324 minecraft:red_concrete
setblock 77 246 323 minecraft:stripped_dark_oak_log
fill 80 246 332 81 248 334 minecraft:cherry_leaves[persistent=true]
fill 82 246 325 82 246 335 minecraft:red_concrete
fill 83 246 332 83 248 334 minecraft:cherry_leaves[persistent=true]
setblock 84 246 323 minecraft:stripped_dark_oak_log
setblock 88 246 326 minecraft:stripped_dark_oak_log
fill 88 246 329 88 249 331 minecraft:shroomlight
setblock 88 246 333 minecraft:stripped_dark_oak_log
setblock 88 246 340 minecraft:stripped_dark_oak_log
setblock 88 246 347 minecraft:stripped_dark_oak_log
setblock 48 247 323 minecraft:stripped_dark_oak_log
setblock 48 247 330 minecraft:stripped_dark_oak_log
setblock 48 247 337 minecraft:stripped_dark_oak_log
setblock 48 247 344 minecraft:stripped_dark_oak_log
setblock 48 247 351 minecraft:stripped_dark_oak_log
setblock 48 247 358 minecraft:stripped_dark_oak_log
setblock 50 247 363 minecraft:stripped_dark_oak_log
setblock 55 247 323 minecraft:stripped_dark_oak_log
fill 56 247 322 56 248 322 minecraft:dark_oak_planks
setblock 56 247 364 minecraft:red_concrete
setblock 57 247 363 minecraft:stripped_dark_oak_log
fill 57 247 364 57 308 364 minecraft:dark_oak_planks
setblock 62 247 323 minecraft:stripped_dark_oak_log
setblock 64 247 363 minecraft:stripped_dark_oak_log
setblock 69 247 323 minecraft:stripped_dark_oak_log
setblock 71 247 363 minecraft:stripped_dark_oak_log
fill 74 247 324 74 248 324 minecraft:shroomlight
setblock 76 247 323 minecraft:stripped_dark_oak_log
setblock 79 247 333 minecraft:cherry_leaves[persistent=true]
fill 80 247 331 82 247 331 minecraft:cherry_leaves[persistent=true]
setblock 81 247 335 minecraft:cherry_leaves[persistent=true]
setblock 82 247 325 minecraft:stripped_dark_oak_log
setblock 82 247 330 minecraft:stripped_dark_oak_log
fill 82 247 332 82 248 334 minecraft:cherry_leaves[persistent=true]
setblock 82 247 335 minecraft:stripped_dark_oak_log
setblock 83 247 323 minecraft:stripped_dark_oak_log
setblock 83 247 354 minecraft:shroomlight
setblock 83 247 356 minecraft:shroomlight
setblock 83 247 358 minecraft:shroomlight
setblock 83 247 360 minecraft:shroomlight
setblock 83 247 362 minecraft:shroomlight
setblock 83 247 364 minecraft:shroomlight
setblock 84 247 355 minecraft:shroomlight
setblock 84 247 357 minecraft:shroomlight
setblock 84 247 359 minecraft:shroomlight
setblock 84 247 361 minecraft:shroomlight
setblock 84 247 363 minecraft:shroomlight
setblock 85 247 354 minecraft:shroomlight
setblock 85 247 356 minecraft:shroomlight
setblock 85 247 358 minecraft:shroomlight
setblock 85 247 360 minecraft:shroomlight
setblock 85 247 362 minecraft:shroomlight
setblock 85 247 364 minecraft:shroomlight
setblock 86 247 355 minecraft:shroomlight
setblock 86 247 357 minecraft:shroomlight
setblock 86 247 359 minecraft:shroomlight
setblock 86 247 361 minecraft:shroomlight
setblock 86 247 363 minecraft:shroomlight
setblock 87 247 354 minecraft:shroomlight
setblock 87 247 356 minecraft:shroomlight
setblock 87 247 358 minecraft:shroomlight
setblock 87 247 360 minecraft:shroomlight
setblock 87 247 362 minecraft:shroomlight
setblock 87 247 364 minecraft:shroomlight
setblock 88 247 325 minecraft:stripped_dark_oak_log
setblock 88 247 332 minecraft:stripped_dark_oak_log
setblock 88 247 339 minecraft:stripped_dark_oak_log
setblock 88 247 346 minecraft:stripped_dark_oak_log
setblock 88 247 355 minecraft:shroomlight
setblock 88 247 357 minecraft:shroomlight
setblock 88 247 359 minecraft:shroomlight
setblock 88 247 361 minecraft:shroomlight
setblock 88 247 363 minecraft:shroomlight
setblock 89 247 338 minecraft:red_concrete
fill 89 247 339 89 257 340 minecraft:dark_oak_planks
fill 89 247 355 89 256 358 minecraft:dark_oak_planks
setblock 89 247 359 minecraft:red_concrete
setblock 48 248 324 minecraft:stripped_dark_oak_log
setblock 48 248 331 minecraft:stripped_dark_oak_log
setblock 48 248 338 minecraft:stripped_dark_oak_log
setblock 48 248 345 minecraft:stripped_dark_oak_log
setblock 48 248 352 minecraft:stripped_dark_oak_log
setblock 48 248 359 minecraft:stripped_dark_oak_log
setblock 50 248 325 minecraft:light[level=15]
setblock 50 248 333 minecraft:light[level=15]
setblock 50 248 340 minecraft:red_concrete
setblock 50 248 341 minecraft:light[level=15]
setblock 50 248 349 minecraft:light[level=15]
setblock 50 248 357 minecraft:light[level=15]
setblock 51 248 363 minecraft:stripped_dark_oak_log
setblock 54 248 323 minecraft:stripped_dark_oak_log
fill 56 248 364 56 308 364 minecraft:dark_oak_planks
setblock 58 248 325 minecraft:light[level=15]
setblock 58 248 333 minecraft:light[level=15]
setblock 58 248 341 minecraft:light[level=15]
setblock 58 248 349 minecraft:light[level=15]
setblock 58 248 357 minecraft:light[level=15]
setblock 58 248 363 minecraft:stripped_dark_oak_log
setblock 59 248 364 minecraft:red_concrete
setblock 61 248 323 minecraft:stripped_dark_oak_log
setblock 65 248 363 minecraft:stripped_dark_oak_log
setblock 66 248 325 minecraft:light[level=15]
setblock 66 248 333 minecraft:light[level=15]
setblock 66 248 341 minecraft:light[level=15]
setblock 66 248 349 minecraft:light[level=15]
setblock 66 248 357 minecraft:light[level=15]
setblock 68 248 323 minecraft:stripped_dark_oak_log
setblock 72 248 363 minecraft:stripped_dark_oak_log
setblock 74 248 325 minecraft:light[level=15]
setblock 74 248 333 minecraft:light[level=15]
setblock 74 248 341 minecraft:light[level=15]
setblock 74 248 349 minecraft:light[level=15]
setblock 74 248 357 minecraft:light[level=15]
setblock 75 248 323 minecraft:stripped_dark_oak_log
fill 77 248 358 87 248 362 minecraft:red_concrete
setblock 82 248 323 minecraft:stripped_dark_oak_log
setblock 82 248 325 minecraft:light[level=15]
setblock 82 248 341 minecraft:light[level=15]
setblock 82 248 349 minecraft:light[level=15]
setblock 82 248 357 minecraft:light[level=15]
fill 83 248 353 87 248 353 minecraft:red_concrete
fill 83 248 354 83 250 354 minecraft:stripped_dark_oak_log
fill 83 248 356 83 250 356 minecraft:stripped_dark_oak_log
fill 83 248 364 83 261 364 minecraft:dark_oak_planks
fill 84 248 355 84 250 355 minecraft:stripped_dark_oak_log
fill 84 248 357 84 250 357 minecraft:stripped_dark_oak_log
fill 84 248 363 84 250 363 minecraft:stripped_dark_oak_log
fill 85 248 354 85 250 354 minecraft:stripped_dark_oak_log
fill 85 248 356 85 250 356 minecraft:stripped_dark_oak_log
fill 85 248 364 85 308 364 minecraft:dark_oak_planks
fill 86 248 355 86 250 355 minecraft:stripped_dark_oak_log
fill 86 248 357 86 250 357 minecraft:stripped_dark_oak_log
fill 86 248 363 86 250 363 minecraft:stripped_dark_oak_log
fill 87 248 354 87 250 354 minecraft:stripped_dark_oak_log
fill 87 248 356 87 250 356 minecraft:stripped_dark_oak_log
fill 87 248 364 87 308 364 minecraft:dark_oak_planks
setblock 88 248 324 minecraft:stripped_dark_oak_log
setblock 88 248 338 minecraft:stripped_dark_oak_log
setblock 88 248 345 minecraft:stripped_dark_oak_log
fill 88 248 355 88 269 355 minecraft:stripped_dark_oak_log
fill 88 248 357 88 250 357 minecraft:stripped_dark_oak_log
fill 88 248 359 88 250 359 minecraft:stripped_dark_oak_log
fill 88 248 361 88 250 361 minecraft:stripped_dark_oak_log
fill 88 248 363 88 250 363 minecraft:stripped_dark_oak_log
fill 89 248 338 89 274 338 minecraft:dark_oak_planks
fill 89 248 359 89 308 359 minecraft:dark_oak_planks
fill 48 249 325 48 250 325 minecraft:stripped_dark_oak_log
fill 48 249 332 48 250 332 minecraft:stripped_dark_oak_log
fill 48 249 339 48 250 339 minecraft:stripped_dark_oak_log
fill 48 249 346 48 250 346 minecraft:stripped_dark_oak_log
fill 48 249 353 48 250 353 minecraft:stripped_dark_oak_log
fill 48 249 360 48 250 360 minecraft:stripped_dark_oak_log
fill 49 249 339 49 250 345 minecraft:iron_bars
fill 50 249 340 50 250 340 minecraft:shroomlight
fill 52 249 363 52 250 363 minecraft:stripped_dark_oak_log
fill 53 249 323 53 250 323 minecraft:stripped_dark_oak_log
setblock 56 249 322 minecraft:red_concrete
fill 59 249 363 59 250 363 minecraft:stripped_dark_oak_log
fill 59 249 364 59 308 364 minecraft:dark_oak_planks
fill 60 249 323 60 250 323 minecraft:stripped_dark_oak_log
fill 66 249 363 66 250 363 minecraft:stripped_dark_oak_log
fill 67 249 323 67 250 323 minecraft:stripped_dark_oak_log
fill 71 249 322 72 308 322 minecraft:dark_oak_planks
setblock 73 249 322 minecraft:red_concrete
fill 73 249 363 73 250 363 minecraft:stripped_dark_oak_log
fill 74 249 323 74 250 323 minecraft:stripped_dark_oak_log
setblock 74 249 324 minecraft:red_concrete
fill 78 249 359 86 249 361 minecraft:red_concrete
fill 80 249 363 80 250 363 minecraft:stripped_dark_oak_log
fill 81 249 323 81 250 323 minecraft:stripped_dark_oak_log
fill 83 249 358 87 250 358 minecraft:stripped_dark_oak_log
fill 83 249 362 87 250 362 minecraft:stripped_dark_oak_log
fill 87 249 359 87 250 361 minecraft:stripped_dark_oak_log
fill 88 249 323 88 250 323 minecraft:stripped_dark_oak_log
fill 88 249 337 88 250 337 minecraft:stripped_dark_oak_log
fill 88 249 344 88 250 344 minecraft:stripped_dark_oak_log
fill 88 249 351 88 250 351 minecraft:stripped_dark_oak_log
fill 48 250 323 48 250 324 minecraft:stripped_dark_oak_log
fill 48 250 326 48 250 327 minecraft:stripped_dark_oak_log
fill 48 250 329 48 250 331 minecraft:stripped_dark_oak_log
fill 48 250 333 48 250 334 minecraft:stripped_dark_oak_log
fill 48 250 336 48 250 338 minecraft:stripped_dark_oak_log
fill 48 250 340 48 250 341 minecraft:stripped_dark_oak_log
fill 48 250 343 48 250 345 minecraft:stripped_dark_oak_log
fill 48 250 347 48 250 348 minecraft:stripped_dark_oak_log
fill 48 250 350 48 250 352 minecraft:stripped_dark_oak_log
fill 48 250 354 48 250 355 minecraft:stripped_dark_oak_log
fill 48 250 357 48 250 359 minecraft:stripped_dark_oak_log
fill 48 250 361 48 250 362 minecraft:stripped_dark_oak_log
setblock 49 250 323 minecraft:stripped_dark_oak_log
fill 49 250 363 51 250 363 minecraft:stripped_dark_oak_log
setblock 50 250 325 minecraft:light[level=12]
setblock 50 250 332 minecraft:light[level=12]
setblock 50 250 339 minecraft:light[level=12]
setblock 50 250 346 minecraft:light[level=12]
setblock 50 250 353 minecraft:light[level=12]
setblock 50 250 360 minecraft:light[level=12]
fill 51 250 323 52 250 323 minecraft:stripped_dark_oak_log
fill 53 250 363 54 250 363 minecraft:stripped_dark_oak_log
fill 54 250 323 56 250 323 minecraft:stripped_dark_oak_log
fill 56 250 322 56 308 322 minecraft:dark_oak_planks
fill 56 250 363 58 250 363 minecraft:stripped_dark_oak_log
setblock 57 250 325 minecraft:light[level=12]
setblock 57 250 332 minecraft:light[level=12]
setblock 57 250 339 minecraft:light[level=12]
setblock 57 250 346 minecraft:light[level=12]
setblock 57 250 353 minecraft:light[level=12]
setblock 57 250 360 minecraft:light[level=12]
fill 58 250 323 59 250 323 minecraft:stripped_dark_oak_log
fill 60 250 363 61 250 363 minecraft:stripped_dark_oak_log
fill 61 250 323 63 250 323 minecraft:stripped_dark_oak_log
fill 63 250 363 65 250 363 minecraft:stripped_dark_oak_log
setblock 64 250 325 minecraft:light[level=12]
setblock 64 250 332 minecraft:light[level=12]
setblock 64 250 339 minecraft:light[level=12]
setblock 64 250 346 minecraft:light[level=12]
setblock 64 250 353 minecraft:light[level=12]
setblock 64 250 360 minecraft:light[level=12]
fill 65 250 323 66 250 323 minecraft:stripped_dark_oak_log
fill 67 250 363 68 250 363 minecraft:stripped_dark_oak_log
fill 68 250 323 70 250 323 minecraft:stripped_dark_oak_log
fill 70 250 363 72 250 363 minecraft:stripped_dark_oak_log
setblock 71 250 325 minecraft:light[level=12]
setblock 71 250 332 minecraft:light[level=12]
setblock 71 250 339 minecraft:light[level=12]
setblock 71 250 346 minecraft:light[level=12]
setblock 71 250 353 minecraft:light[level=12]
setblock 71 250 360 minecraft:light[level=12]
fill 72 250 323 73 250 323 minecraft:stripped_dark_oak_log
fill 73 250 322 73 308 322 minecraft:dark_oak_planks
fill 74 250 363 75 250 363 minecraft:stripped_dark_oak_log
fill 75 250 323 77 250 323 minecraft:stripped_dark_oak_log
fill 77 250 363 79 250 363 minecraft:stripped_dark_oak_log
setblock 78 250 325 minecraft:light[level=12]
setblock 78 250 332 minecraft:light[level=12]
setblock 78 250 339 minecraft:light[level=12]
setblock 78 250 346 minecraft:light[level=12]
setblock 78 250 353 minecraft:light[level=12]
setblock 78 250 360 minecraft:light[level=12]
fill 79 250 323 80 250 323 minecraft:stripped_dark_oak_log
fill 79 250 360 85 250 360 minecraft:red_concrete
fill 81 250 363 82 250 363 minecraft:stripped_dark_oak_log
fill 82 250 323 84 250 323 minecraft:stripped_dark_oak_log
fill 83 250 359 86 250 359 minecraft:stripped_dark_oak_log
fill 83 250 361 86 250 361 minecraft:stripped_dark_oak_log
setblock 85 250 325 minecraft:light[level=12]
setblock 85 250 332 minecraft:light[level=12]
setblock 85 250 339 minecraft:light[level=12]
setblock 85 250 346 minecraft:light[level=12]
setblock 85 250 353 minecraft:light[level=12]
fill 86 250 323 87 250 323 minecraft:stripped_dark_oak_log
setblock 86 250 360 minecraft:stripped_dark_oak_log
fill 88 250 324 88 250 326 minecraft:stripped_dark_oak_log
fill 88 250 328 88 250 333 minecraft:stripped_dark_oak_log
fill 88 250 335 88 250 336 minecraft:stripped_dark_oak_log
fill 88 250 338 88 250 340 minecraft:stripped_dark_oak_log
fill 88 250 342 88 250 343 minecraft:stripped_dark_oak_log
fill 88 250 345 88 250 347 minecraft:stripped_dark_oak_log
fill 88 250 349 88 250 350 minecraft:stripped_dark_oak_log
fill 88 250 352 88 250 353 minecraft:stripped_dark_oak_log
setblock 88 250 364 minecraft:red_concrete
fill 89 250 364 89 308 364 minecraft:dark_oak_planks
setblock 48 251 327 minecraft:stripped_dark_oak_log
setblock 48 251 334 minecraft:stripped_dark_oak_log
setblock 48 251 341 minecraft:stripped_dark_oak_log
setblock 48 251 348 minecraft:stripped_dark_oak_log
setblock 48 251 355 minecraft:stripped_dark_oak_log
setblock 48 251 362 minecraft:stripped_dark_oak_log
setblock 50 251 340 minecraft:red_concrete
setblock 51 251 323 minecraft:stripped_dark_oak_log
setblock 54 251 363 minecraft:stripped_dark_oak_log
setblock 58 251 323 minecraft:stripped_dark_oak_log
setblock 61 251 363 minecraft:stripped_dark_oak_log
setblock 65 251 323 minecraft:stripped_dark_oak_log
setblock 68 251 363 minecraft:stripped_dark_oak_log
setblock 72 251 323 minecraft:stripped_dark_oak_log
setblock 75 251 363 minecraft:stripped_dark_oak_log
setblock 79 251 323 minecraft:stripped_dark_oak_log
fill 80 251 359 87 251 361 minecraft:red_concrete
setblock 82 251 363 minecraft:stripped_dark_oak_log
fill 84 251 355 87 251 358 minecraft:red_concrete
fill 84 251 362 87 251 363 minecraft:red_concrete
setblock 86 251 323 minecraft:stripped_dark_oak_log
setblock 88 251 328 minecraft:stripped_dark_oak_log
setblock 88 251 335 minecraft:stripped_dark_oak_log
setblock 88 251 342 minecraft:stripped_dark_oak_log
setblock 88 251 349 minecraft:stripped_dark_oak_log
fill 88 251 364 88 308 364 minecraft:dark_oak_planks
fill 89 251 331 89 263 335 minecraft:dark_oak_planks
setblock 89 251 336 minecraft:red_concrete
fill 47 252 338 47 287 341 minecraft:dark_oak_planks
setblock 47 252 342 minecraft:red_concrete
fill 47 252 343 47 260 350 minecraft:dark_oak_planks
fill 58 252 322 58 273 322 minecraft:dark_oak_planks
setblock 59 252 322 minecraft:red_concrete
fill 60 252 322 61 308 322 minecraft:dark_oak_planks
fill 85 252 356 86 252 363 minecraft:red_concrete
setblock 87 252 334 minecraft:red_concrete
fill 89 252 336 89 308 336 minecraft:dark_oak_planks
fill 47 253 342 47 262 342 minecraft:dark_oak_planks
setblock 48 253 329 minecraft:stripped_dark_oak_log
setblock 48 253 336 minecraft:stripped_dark_oak_log
setblock 48 253 343 minecraft:stripped_dark_oak_log
setblock 48 253 350 minecraft:stripped_dark_oak_log
setblock 48 253 357 minecraft:stripped_dark_oak_log
setblock 49 253 323 minecraft:stripped_dark_oak_log
setblock 49 253 363 minecraft:stripped_dark_oak_log
setblock 56 253 323 minecraft:stripped_dark_oak_log
setblock 56 253 363 minecraft:stripped_dark_oak_log
fill 59 253 322 59 289 322 minecraft:dark_oak_planks
setblock 63 253 323 minecraft:stripped_dark_oak_log
setblock 63 253 363 minecraft:stripped_dark_oak_log
setblock 70 253 323 minecraft:stripped_dark_oak_log
setblock 70 253 363 minecraft:stripped_dark_oak_log
setblock 76 253 364 minecraft:red_concrete
setblock 77 253 323 minecraft:stripped_dark_oak_log
setblock 77 253 363 minecraft:stripped_dark_oak_log
fill 77 253 364 82 256 364 minecraft:dark_oak_planks
fill 80 253 354 80 254 354 minecraft:shroomlight
setblock 84 253 323 minecraft:stripped_dark_oak_log
setblock 84 253 363 minecraft:stripped_dark_oak_log
fill 85 253 357 86 253 363 minecraft:red_concrete
fill 87 253 334 87 254 334 minecraft:shroomlight
setblock 88 253 326 minecraft:stripped_dark_oak_log
setblock 88 253 333 minecraft:stripped_dark_oak_log
setblock 88 253 340 minecraft:stripped_dark_oak_log
setblock 88 253 347 minecraft:stripped_dark_oak_log
setblock 88 253 354 minecraft:stripped_dark_oak_log
setblock 88 253 361 minecraft:stripped_dark_oak_log
setblock 47 254 358 minecraft:red_concrete
setblock 48 254 323 minecraft:stripped_dark_oak_log
setblock 48 254 330 minecraft:stripped_dark_oak_log
setblock 48 254 337 minecraft:stripped_dark_oak_log
setblock 48 254 344 minecraft:stripped_dark_oak_log
setblock 48 254 351 minecraft:stripped_dark_oak_log
setblock 48 254 358 minecraft:stripped_dark_oak_log
setblock 50 254 363 minecraft:stripped_dark_oak_log
setblock 55 254 323 minecraft:stripped_dark_oak_log
setblock 57 254 363 minecraft:stripped_dark_oak_log
setblock 62 254 323 minecraft:stripped_dark_oak_log
setblock 64 254 363 minecraft:stripped_dark_oak_log
setblock 69 254 323 minecraft:stripped_dark_oak_log
setblock 71 254 363 minecraft:stripped_dark_oak_log
setblock 76 254 323 minecraft:stripped_dark_oak_log
fill 76 254 364 76 308 364 minecraft:dark_oak_planks
setblock 78 254 363 minecraft:stripped_dark_oak_log
setblock 83 254 323 minecraft:stripped_dark_oak_log
fill 84 254 358 87 254 362 minecraft:red_concrete
setblock 85 254 363 minecraft:stripped_dark_oak_log
setblock 88 254 325 minecraft:stripped_dark_oak_log
setblock 88 254 332 minecraft:stripped_dark_oak_log
setblock 88 254 339 minecraft:stripped_dark_oak_log
setblock 88 254 346 minecraft:stripped_dark_oak_log
setblock 88 254 353 minecraft:stripped_dark_oak_log
setblock 88 254 360 minecraft:stripped_dark_oak_log
fill 47 255 358 47 308 358 minecraft:dark_oak_planks
setblock 48 255 324 minecraft:stripped_dark_oak_log
setblock 48 255 331 minecraft:stripped_dark_oak_log
setblock 48 255 338 minecraft:stripped_dark_oak_log
setblock 48 255 345 minecraft:stripped_dark_oak_log
setblock 48 255 352 minecraft:stripped_dark_oak_log
setblock 48 255 359 minecraft:stripped_dark_oak_log
setblock 51 255 363 minecraft:stripped_dark_oak_log
setblock 54 255 323 minecraft:stripped_dark_oak_log
setblock 58 255 363 minecraft:stripped_dark_oak_log
setblock 61 255 323 minecraft:stripped_dark_oak_log
setblock 65 255 363 minecraft:stripped_dark_oak_log
setblock 68 255 323 minecraft:stripped_dark_oak_log
setblock 72 255 363 minecraft:stripped_dark_oak_log
setblock 75 255 323 minecraft:stripped_dark_oak_log
setblock 79 255 363 minecraft:stripped_dark_oak_log
fill 80 255 354 80 265 354 minecraft:dark_oak_planks
setblock 82 255 323 minecraft:stripped_dark_oak_log
setblock 86 255 363 minecraft:stripped_dark_oak_log
setblock 87 255 334 minecraft:red_concrete
setblock 88 255 324 minecraft:stripped_dark_oak_log
setblock 88 255 331 minecraft:stripped_dark_oak_log
setblock 88 255 338 minecraft:stripped_dark_oak_log
setblock 88 255 345 minecraft:stripped_dark_oak_log
setblock 88 255 352 minecraft:stripped_dark_oak_log
setblock 88 255 359 minecraft:stripped_dark_oak_log
setblock 48 256 325 minecraft:stripped_dark_oak_log
setblock 48 256 332 minecraft:stripped_dark_oak_log
setblock 48 256 339 minecraft:stripped_dark_oak_log
setblock 48 256 346 minecraft:stripped_dark_oak_log
setblock 48 256 353 minecraft:stripped_dark_oak_log
setblock 48 256 360 minecraft:stripped_dark_oak_log
setblock 50 256 325 minecraft:light[level=15]
setblock 50 256 332 minecraft:light[level=12]
setblock 50 256 333 minecraft:light[level=15]
setblock 50 256 339 minecraft:light[level=12]
setblock 50 256 341 minecraft:light[level=15]
setblock 50 256 346 minecraft:light[level=12]
setblock 50 256 349 minecraft:light[level=15]
setblock 50 256 353 minecraft:light[level=12]
setblock 50 256 357 minecraft:light[level=15]
setblock 50 256 360 minecraft:light[level=12]
setblock 52 256 363 minecraft:stripped_dark_oak_log
setblock 53 256 323 minecraft:stripped_dark_oak_log
setblock 57 256 325 minecraft:light[level=12]
setblock 57 256 332 minecraft:light[level=12]
setblock 57 256 339 minecraft:light[level=12]
setblock 57 256 346 minecraft:light[level=12]
setblock 57 256 353 minecraft:light[level=12]
setblock 57 256 360 minecraft:light[level=12]
setblock 58 256 325 minecraft:light[level=15]
setblock 58 256 333 minecraft:light[level=15]
setblock 58 256 341 minecraft:light[level=15]
setblock 58 256 349 minecraft:light[level=15]
setblock 58 256 357 minecraft:light[level=15]
setblock 59 256 363 minecraft:stripped_dark_oak_log
setblock 60 256 323 minecraft:stripped_dark_oak_log
setblock 64 256 325 minecraft:light[level=12]
setblock 64 256 332 minecraft:light[level=12]
setblock 64 256 339 minecraft:light[level=12]
setblock 64 256 346 minecraft:light[level=12]
setblock 64 256 353 minecraft:light[level=12]
setblock 64 256 360 minecraft:light[level=12]
setblock 66 256 325 minecraft:light[level=15]
setblock 66 256 333 minecraft:light[level=15]
setblock 66 256 341 minecraft:light[level=15]
setblock 66 256 349 minecraft:light[level=15]
setblock 66 256 357 minecraft:light[level=15]
setblock 66 256 363 minecraft:stripped_dark_oak_log
setblock 67 256 323 minecraft:stripped_dark_oak_log
setblock 71 256 325 minecraft:light[level=12]
setblock 71 256 332 minecraft:light[level=12]
setblock 71 256 339 minecraft:light[level=12]
setblock 71 256 346 minecraft:light[level=12]
setblock 71 256 353 minecraft:light[level=12]
setblock 71 256 360 minecraft:light[level=12]
setblock 73 256 363 minecraft:stripped_dark_oak_log
setblock 74 256 323 minecraft:stripped_dark_oak_log
setblock 74 256 325 minecraft:light[level=15]
setblock 74 256 333 minecraft:light[level=15]
setblock 74 256 341 minecraft:light[level=15]
setblock 74 256 349 minecraft:light[level=15]
setblock 74 256 357 minecraft:light[level=15]
fill 77 256 328 77 259 328 minecraft:iron_bars
setblock 78 256 325 minecraft:light[level=12]
setblock 78 256 332 minecraft:light[level=12]
setblock 78 256 339 minecraft:light[level=12]
setblock 78 256 346 minecraft:light[level=12]
setblock 78 256 353 minecraft:light[level=12]
setblock 78 256 360 minecraft:light[level=12]
fill 80 256 353 80 265 353 minecraft:dark_oak_planks
setblock 80 256 363 minecraft:stripped_dark_oak_log
setblock 81 256 323 minecraft:stripped_dark_oak_log
setblock 82 256 325 minecraft:light[level=15]
setblock 82 256 333 minecraft:light[level=15]
setblock 82 256 341 minecraft:light[level=15]
setblock 82 256 349 minecraft:light[level=15]
setblock 82 256 357 minecraft:light[level=15]
setblock 85 256 325 minecraft:light[level=12]
setblock 85 256 332 minecraft:light[level=12]
setblock 85 256 339 minecraft:light[level=12]
setblock 85 256 346 minecraft:light[level=12]
setblock 85 256 353 minecraft:light[level=12]
setblock 85 256 360 minecraft:light[level=12]
setblock 87 256 363 minecraft:stripped_dark_oak_log
setblock 88 256 323 minecraft:stripped_dark_oak_log
setblock 88 256 330 minecraft:stripped_dark_oak_log
setblock 88 256 337 minecraft:stripped_dark_oak_log
setblock 88 256 344 minecraft:stripped_dark_oak_log
setblock 88 256 351 minecraft:stripped_dark_oak_log
setblock 88 256 358 minecraft:stripped_dark_oak_log
setblock 48 257 326 minecraft:stripped_dark_oak_log
setblock 48 257 333 minecraft:stripped_dark_oak_log
setblock 48 257 340 minecraft:stripped_dark_oak_log
setblock 48 257 347 minecraft:stripped_dark_oak_log
setblock 48 257 354 minecraft:stripped_dark_oak_log
setblock 48 257 361 minecraft:stripped_dark_oak_log
setblock 52 257 323 minecraft:stripped_dark_oak_log
setblock 53 257 363 minecraft:stripped_dark_oak_log
setblock 59 257 323 minecraft:stripped_dark_oak_log
setblock 60 257 363 minecraft:stripped_dark_oak_log
setblock 66 257 323 minecraft:stripped_dark_oak_log
setblock 67 257 363 minecraft:stripped_dark_oak_log
setblock 73 257 323 minecraft:stripped_dark_oak_log
setblock 74 257 363 minecraft:stripped_dark_oak_log
fill 77 257 364 78 308 364 minecraft:dark_oak_planks
fill 79 257 353 79 265 354 minecraft:dark_oak_planks
setblock 79 257 364 minecraft:red_concrete
setblock 80 257 323 minecraft:stripped_dark_oak_log
fill 80 257 355 80 265 355 minecraft:dark_oak_planks
fill 80 257 364 82 308 364 minecraft:dark_oak_planks
fill 81 257 354 81 265 354 minecraft:dark_oak_planks
setblock 81 257 363 minecraft:stripped_dark_oak_log
setblock 87 257 323 minecraft:stripped_dark_oak_log
setblock 88 257 329 minecraft:stripped_dark_oak_log
setblock 88 257 336 minecraft:stripped_dark_oak_log
setblock 88 257 343 minecraft:stripped_dark_oak_log
setblock 88 257 350 minecraft:stripped_dark_oak_log
setblock 88 257 357 minecraft:stripped_dark_oak_log
setblock 88 257 363 minecraft:stripped_dark_oak_log
setblock 89 257 355 minecraft:red_concrete
fill 89 257 356 89 308 358 minecraft:dark_oak_planks
setblock 48 258 327 minecraft:stripped_dark_oak_log
setblock 48 258 334 minecraft:stripped_dark_oak_log
setblock 48 258 341 minecraft:stripped_dark_oak_log
setblock 48 258 348 minecraft:stripped_dark_oak_log
setblock 48 258 355 minecraft:stripped_dark_oak_log
setblock 48 258 362 minecraft:stripped_dark_oak_log
setblock 51 258 323 minecraft:stripped_dark_oak_log
setblock 54 258 363 minecraft:stripped_dark_oak_log
setblock 58 258 323 minecraft:stripped_dark_oak_log
setblock 61 258 363 minecraft:stripped_dark_oak_log
setblock 65 258 323 minecraft:stripped_dark_oak_log
setblock 68 258 363 minecraft:stripped_dark_oak_log
setblock 72 258 323 minecraft:stripped_dark_oak_log
setblock 75 258 363 minecraft:stripped_dark_oak_log
setblock 79 258 323 minecraft:stripped_dark_oak_log
fill 79 258 355 79 265 355 minecraft:dark_oak_planks
fill 79 258 364 79 308 364 minecraft:dark_oak_planks
fill 80 258 352 80 265 352 minecraft:dark_oak_planks
fill 81 258 353 81 265 353 minecraft:dark_oak_planks
fill 81 258 355 81 265 355 minecraft:dark_oak_planks
setblock 82 258 363 minecraft:stripped_dark_oak_log
setblock 86 258 323 minecraft:stripped_dark_oak_log
setblock 88 258 328 minecraft:stripped_dark_oak_log
setblock 88 258 335 minecraft:stripped_dark_oak_log
setblock 88 258 342 minecraft:stripped_dark_oak_log
setblock 88 258 349 minecraft:stripped_dark_oak_log
setblock 88 258 356 minecraft:stripped_dark_oak_log
fill 89 258 339 89 308 339 minecraft:dark_oak_planks
setblock 89 258 340 minecraft:red_concrete
fill 89 258 355 89 308 355 minecraft:dark_oak_planks
setblock 47 259 337 minecraft:red_concrete
fill 78 259 353 78 265 355 minecraft:dark_oak_planks
fill 79 259 352 79 265 352 minecraft:dark_oak_planks
fill 80 259 356 80 265 356 minecraft:dark_oak_planks
fill 81 259 352 81 265 352 minecraft:dark_oak_planks
fill 82 259 353 82 265 354 minecraft:dark_oak_planks
fill 89 259 340 89 308 340 minecraft:dark_oak_planks
fill 47 260 337 47 308 337 minecraft:dark_oak_planks
fill 48 260 323 48 260 327 minecraft:stripped_dark_oak_log
fill 48 260 329 48 260 334 minecraft:stripped_dark_oak_log
fill 48 260 336 48 260 341 minecraft:stripped_dark_oak_log
fill 48 260 343 48 260 348 minecraft:stripped_dark_oak_log
fill 48 260 350 48 260 355 minecraft:stripped_dark_oak_log
fill 48 260 357 48 260 362 minecraft:stripped_dark_oak_log
setblock 49 260 323 minecraft:stripped_dark_oak_log
fill 49 260 363 54 260 363 minecraft:stripped_dark_oak_log
fill 51 260 323 56 260 323 minecraft:stripped_dark_oak_log
fill 56 260 363 61 260 363 minecraft:stripped_dark_oak_log
fill 58 260 323 63 260 323 minecraft:stripped_dark_oak_log
fill 63 260 363 68 260 363 minecraft:stripped_dark_oak_log
fill 65 260 323 70 260 323 minecraft:stripped_dark_oak_log
fill 70 260 363 75 260 363 minecraft:stripped_dark_oak_log
fill 72 260 323 77 260 323 minecraft:stripped_dark_oak_log
fill 73 260 324 81 260 328 minecraft:dark_oak_planks
fill 77 260 363 82 260 363 minecraft:stripped_dark_oak_log
fill 78 260 352 78 265 352 minecraft:dark_oak_planks
fill 79 260 323 84 260 323 minecraft:stripped_dark_oak_log
fill 79 260 356 79 265 356 minecraft:dark_oak_planks
fill 80 260 351 80 265 351 minecraft:dark_oak_planks
fill 81 260 356 81 265 356 minecraft:dark_oak_planks
fill 82 260 352 82 265 352 minecraft:dark_oak_planks
fill 82 260 355 82 265 355 minecraft:dark_oak_planks
fill 84 260 363 88 260 363 minecraft:stripped_dark_oak_log
fill 86 260 323 88 260 323 minecraft:stripped_dark_oak_log
fill 88 260 324 88 260 326 minecraft:stripped_dark_oak_log
fill 88 260 328 88 260 333 minecraft:stripped_dark_oak_log
fill 88 260 335 88 260 340 minecraft:stripped_dark_oak_log
fill 88 260 342 88 260 347 minecraft:stripped_dark_oak_log
fill 88 260 349 88 260 354 minecraft:stripped_dark_oak_log
fill 88 260 356 88 260 361 minecraft:stripped_dark_oak_log
setblock 89 260 346 minecraft:red_concrete
fill 47 261 343 47 308 349 minecraft:dark_oak_planks
setblock 47 261 350 minecraft:red_concrete
setblock 48 261 323 minecraft:stripped_dark_oak_log
setblock 48 261 330 minecraft:stripped_dark_oak_log
setblock 48 261 337 minecraft:stripped_dark_oak_log
setblock 48 261 344 minecraft:stripped_dark_oak_log
setblock 48 261 351 minecraft:stripped_dark_oak_log
setblock 48 261 358 minecraft:stripped_dark_oak_log
setblock 50 261 363 minecraft:stripped_dark_oak_log
setblock 55 261 323 minecraft:stripped_dark_oak_log
setblock 57 261 363 minecraft:stripped_dark_oak_log
setblock 62 261 323 minecraft:stripped_dark_oak_log
setblock 64 261 363 minecraft:stripped_dark_oak_log
setblock 69 261 323 minecraft:stripped_dark_oak_log
setblock 71 261 363 minecraft:stripped_dark_oak_log
fill 73 261 323 77 261 328 minecraft:stripped_dark_oak_log
fill 77 261 353 77 265 355 minecraft:dark_oak_planks
fill 78 261 324 81 261 328 minecraft:stripped_dark_oak_log
fill 78 261 356 78 265 356 minecraft:dark_oak_planks
setblock 78 261 363 minecraft:stripped_dark_oak_log
fill 79 261 323 81 261 323 minecraft:stripped_dark_oak_log
fill 79 261 351 79 265 351 minecraft:dark_oak_planks
fill 80 261 357 80 265 357 minecraft:dark_oak_planks
fill 81 261 351 81 265 351 minecraft:dark_oak_planks
fill 82 261 356 82 265 356 minecraft:dark_oak_planks
setblock 83 261 323 minecraft:stripped_dark_oak_log
fill 83 261 353 83 265 354 minecraft:dark_oak_planks
setblock 85 261 363 minecraft:stripped_dark_oak_log
setblock 88 261 325 minecraft:stripped_dark_oak_log
setblock 88 261 332 minecraft:stripped_dark_oak_log
setblock 88 261 339 minecraft:stripped_dark_oak_log
setblock 88 261 346 minecraft:stripped_dark_oak_log
setblock 88 261 353 minecraft:stripped_dark_oak_log
setblock 88 261 360 minecraft:stripped_dark_oak_log
fill 89 261 346 89 274 346 minecraft:dark_oak_planks
fill 47 262 350 47 308 350 minecraft:dark_oak_planks
setblock 48 262 324 minecraft:stripped_dark_oak_log
setblock 48 262 331 minecraft:stripped_dark_oak_log
setblock 48 262 338 minecraft:stripped_dark_oak_log
setblock 48 262 345 minecraft:stripped_dark_oak_log
setblock 48 262 352 minecraft:stripped_dark_oak_log
setblock 48 262 359 minecraft:stripped_dark_oak_log
setblock 50 262 325 minecraft:light[level=12]
setblock 50 262 332 minecraft:light[level=12]
setblock 50 262 339 minecraft:light[level=12]
setblock 50 262 346 minecraft:light[level=12]
setblock 50 262 353 minecraft:light[level=12]
setblock 50 262 360 minecraft:light[level=12]
setblock 51 262 363 minecraft:stripped_dark_oak_log
setblock 54 262 323 minecraft:stripped_dark_oak_log
setblock 57 262 325 minecraft:light[level=12]
setblock 57 262 332 minecraft:light[level=12]
setblock 57 262 339 minecraft:light[level=12]
setblock 57 262 346 minecraft:light[level=12]
setblock 57 262 353 minecraft:light[level=12]
setblock 57 262 360 minecraft:light[level=12]
setblock 58 262 363 minecraft:stripped_dark_oak_log
setblock 61 262 323 minecraft:stripped_dark_oak_log
setblock 64 262 325 minecraft:light[level=12]
setblock 64 262 332 minecraft:light[level=12]
setblock 64 262 339 minecraft:light[level=12]
setblock 64 262 346 minecraft:light[level=12]
setblock 64 262 353 minecraft:light[level=12]
setblock 64 262 360 minecraft:light[level=12]
setblock 65 262 363 minecraft:stripped_dark_oak_log
setblock 68 262 323 minecraft:stripped_dark_oak_log
setblock 71 262 325 minecraft:light[level=12]
setblock 71 262 332 minecraft:light[level=12]
setblock 71 262 339 minecraft:light[level=12]
setblock 71 262 346 minecraft:light[level=12]
setblock 71 262 353 minecraft:light[level=12]
setblock 71 262 360 minecraft:light[level=12]
setblock 72 262 363 minecraft:stripped_dark_oak_log
fill 73 262 328 81 262 328 minecraft:red_concrete
fill 75 262 322 75 308 322 minecraft:dark_oak_planks
setblock 75 262 323 minecraft:stripped_dark_oak_log
fill 76 262 322 78 265 322 minecraft:shroomlight
fill 77 262 352 77 265 352 minecraft:dark_oak_planks
fill 77 262 356 77 265 356 minecraft:dark_oak_planks
setblock 78 262 325 minecraft:light[level=12]
setblock 78 262 332 minecraft:light[level=12]
setblock 78 262 339 minecraft:light[level=12]
setblock 78 262 346 minecraft:light[level=12]
fill 78 262 351 78 265 351 minecraft:dark_oak_planks
fill 78 262 357 79 265 357 minecraft:dark_oak_planks
setblock 78 262 360 minecraft:light[level=12]
setblock 79 262 363 minecraft:stripped_dark_oak_log
fill 81 262 357 81 265 357 minecraft:dark_oak_planks
setblock 82 262 323 minecraft:stripped_dark_oak_log
fill 82 262 351 82 265 351 minecraft:dark_oak_planks
fill 83 262 352 83 265 352 minecraft:dark_oak_planks
fill 83 262 355 83 265 355 minecraft:dark_oak_planks
setblock 83 262 364 minecraft:red_concrete
setblock 85 262 325 minecraft:light[level=12]
setblock 85 262 332 minecraft:light[level=12]
setblock 85 262 339 minecraft:light[level=12]
setblock 85 262 346 minecraft:light[level=12]
setblock 85 262 353 minecraft:light[level=12]
setblock 85 262 360 minecraft:light[level=12]
setblock 86 262 363 minecraft:stripped_dark_oak_log
setblock 88 262 324 minecraft:stripped_dark_oak_log
setblock 88 262 331 minecraft:stripped_dark_oak_log
setblock 88 262 338 minecraft:stripped_dark_oak_log
setblock 88 262 345 minecraft:stripped_dark_oak_log
setblock 88 262 352 minecraft:stripped_dark_oak_log
setblock 88 262 359 minecraft:stripped_dark_oak_log
setblock 47 263 342 minecraft:red_concrete
setblock 48 263 325 minecraft:stripped_dark_oak_log
setblock 48 263 332 minecraft:stripped_dark_oak_log
setblock 48 263 339 minecraft:stripped_dark_oak_log
setblock 48 263 346 minecraft:stripped_dark_oak_log
setblock 48 263 353 minecraft:stripped_dark_oak_log
setblock 48 263 360 minecraft:stripped_dark_oak_log
setblock 52 263 363 minecraft:stripped_dark_oak_log
setblock 53 263 323 minecraft:stripped_dark_oak_log
setblock 59 263 363 minecraft:stripped_dark_oak_log
setblock 60 263 323 minecraft:stripped_dark_oak_log
setblock 66 263 363 minecraft:stripped_dark_oak_log
setblock 67 263 323 minecraft:stripped_dark_oak_log
setblock 73 263 328 minecraft:stripped_dark_oak_log
setblock 73 263 363 minecraft:stripped_dark_oak_log
setblock 74 263 323 minecraft:stripped_dark_oak_log
fill 76 263 352 76 265 355 minecraft:dark_oak_planks
setblock 77 263 328 minecraft:stripped_dark_oak_log
fill 77 263 351 77 265 351 minecraft:dark_oak_planks
fill 78 263 350 81 265 350 minecraft:dark_oak_planks
fill 80 263 358 80 265 358 minecraft:dark_oak_planks
setblock 80 263 363 minecraft:stripped_dark_oak_log
setblock 81 263 323 minecraft:stripped_dark_oak_log
setblock 81 263 328 minecraft:stripped_dark_oak_log
fill 82 263 357 82 265 357 minecraft:dark_oak_planks
fill 83 263 351 83 265 351 minecraft:dark_oak_planks
fill 83 263 356 83 265 356 minecraft:dark_oak_planks
fill 83 263 364 83 308 364 minecraft:dark_oak_planks
fill 84 263 353 84 265 354 minecraft:dark_oak_planks
setblock 87 263 363 minecraft:stripped_dark_oak_log
setblock 88 263 323 minecraft:stripped_dark_oak_log
setblock 88 263 330 minecraft:stripped_dark_oak_log
setblock 88 263 337 minecraft:stripped_dark_oak_log
setblock 88 263 344 minecraft:stripped_dark_oak_log
setblock 88 263 351 minecraft:stripped_dark_oak_log
setblock 88 263 358 minecraft:stripped_dark_oak_log
setblock 89 263 324 minecraft:red_concrete
fill 89 263 325 89 308 325 minecraft:dark_oak_planks
fill 47 264 342 47 308 342 minecraft:dark_oak_planks
setblock 48 264 326 minecraft:stripped_dark_oak_log
setblock 48 264 333 minecraft:stripped_dark_oak_log
setblock 48 264 340 minecraft:stripped_dark_oak_log
setblock 48 264 347 minecraft:stripped_dark_oak_log
setblock 48 264 354 minecraft:stripped_dark_oak_log
setblock 48 264 361 minecraft:stripped_dark_oak_log
setblock 50 264 325 minecraft:light[level=15]
setblock 50 264 333 minecraft:light[level=15]
setblock 50 264 341 minecraft:light[level=15]
setblock 50 264 349 minecraft:light[level=15]
setblock 50 264 357 minecraft:light[level=15]
setblock 52 264 323 minecraft:stripped_dark_oak_log
setblock 53 264 363 minecraft:stripped_dark_oak_log
setblock 58 264 325 minecraft:light[level=15]
setblock 58 264 333 minecraft:light[level=15]
setblock 58 264 341 minecraft:light[level=15]
setblock 58 264 349 minecraft:light[level=15]
setblock 58 264 357 minecraft:light[level=15]
setblock 59 264 323 minecraft:stripped_dark_oak_log
setblock 60 264 363 minecraft:stripped_dark_oak_log
setblock 66 264 323 minecraft:stripped_dark_oak_log
setblock 66 264 325 minecraft:light[level=15]
setblock 66 264 333 minecraft:light[level=15]
setblock 66 264 341 minecraft:light[level=15]
setblock 66 264 349 minecraft:light[level=15]
setblock 66 264 357 minecraft:light[level=15]
setblock 67 264 363 minecraft:stripped_dark_oak_log
fill 70 264 364 73 271 364 minecraft:dark_oak_planks
setblock 73 264 323 minecraft:stripped_dark_oak_log
setblock 74 264 325 minecraft:light[level=15]
setblock 74 264 333 minecraft:light[level=15]
setblock 74 264 341 minecraft:light[level=15]
setblock 74 264 349 minecraft:light[level=15]
setblock 74 264 357 minecraft:light[level=15]
setblock 74 264 363 minecraft:stripped_dark_oak_log
setblock 74 264 364 minecraft:red_concrete
fill 76 264 351 76 265 351 minecraft:dark_oak_planks
fill 76 264 356 76 265 356 minecraft:dark_oak_planks
fill 77 264 350 77 265 350 minecraft:dark_oak_planks
fill 77 264 357 77 265 357 minecraft:dark_oak_planks
fill 78 264 358 79 265 358 minecraft:dark_oak_planks
setblock 80 264 323 minecraft:stripped_dark_oak_log
fill 81 264 358 82 265 358 minecraft:dark_oak_planks
setblock 81 264 363 minecraft:stripped_dark_oak_log
setblock 82 264 325 minecraft:light[level=15]
setblock 82 264 333 minecraft:light[level=15]
setblock 82 264 341 minecraft:light[level=15]
setblock 82 264 349 minecraft:light[level=15]
fill 82 264 350 82 265 350 minecraft:dark_oak_planks
fill 83 264 357 83 265 357 minecraft:dark_oak_planks
fill 84 264 352 84 265 352 minecraft:dark_oak_planks
fill 84 264 355 84 265 356 minecraft:dark_oak_planks
setblock 87 264 323 minecraft:stripped_dark_oak_log
setblock 88 264 329 minecraft:stripped_dark_oak_log
setblock 88 264 336 minecraft:stripped_dark_oak_log
setblock 88 264 343 minecraft:stripped_dark_oak_log
setblock 88 264 350 minecraft:stripped_dark_oak_log
setblock 88 264 357 minecraft:stripped_dark_oak_log
setblock 88 264 363 minecraft:stripped_dark_oak_log
fill 89 264 324 89 308 324 minecraft:dark_oak_planks
fill 89 264 331 89 308 332 minecraft:dark_oak_planks
setblock 89 264 333 minecraft:red_concrete
fill 89 264 334 89 271 335 minecraft:dark_oak_planks
setblock 48 265 327 minecraft:stripped_dark_oak_log
setblock 48 265 334 minecraft:stripped_dark_oak_log
setblock 48 265 341 minecraft:stripped_dark_oak_log
setblock 48 265 348 minecraft:stripped_dark_oak_log
setblock 48 265 355 minecraft:stripped_dark_oak_log
setblock 48 265 362 minecraft:stripped_dark_oak_log
setblock 51 265 323 minecraft:stripped_dark_oak_log
setblock 54 265 363 minecraft:stripped_dark_oak_log
setblock 58 265 323 minecraft:stripped_dark_oak_log
setblock 61 265 363 minecraft:stripped_dark_oak_log
setblock 65 265 323 minecraft:stripped_dark_oak_log
setblock 68 265 363 minecraft:stripped_dark_oak_log
setblock 72 265 323 minecraft:stripped_dark_oak_log
fill 74 265 364 74 308 364 minecraft:dark_oak_planks
fill 75 265 352 75 265 355 minecraft:dark_oak_planks
setblock 75 265 363 minecraft:stripped_dark_oak_log
setblock 76 265 357 minecraft:dark_oak_planks
setblock 77 265 358 minecraft:dark_oak_planks
fill 78 265 349 82 265 349 minecraft:dark_oak_planks
setblock 79 265 323 minecraft:stripped_dark_oak_log
setblock 80 265 359 minecraft:dark_oak_planks
setblock 82 265 363 minecraft:stripped_dark_oak_log
setblock 83 265 350 minecraft:dark_oak_planks
setblock 83 265 358 minecraft:dark_oak_planks
setblock 84 265 351 minecraft:dark_oak_planks
setblock 84 265 357 minecraft:dark_oak_planks
fill 85 265 353 85 265 354 minecraft:dark_oak_planks
setblock 86 265 323 minecraft:stripped_dark_oak_log
setblock 88 265 328 minecraft:stripped_dark_oak_log
setblock 88 265 335 minecraft:stripped_dark_oak_log
setblock 88 265 342 minecraft:stripped_dark_oak_log
setblock 88 265 349 minecraft:stripped_dark_oak_log
setblock 88 265 356 minecraft:stripped_dark_oak_log
fill 89 265 333 89 308 333 minecraft:dark_oak_planks
fill 76 266 322 78 307 322 minecraft:dark_oak_planks
fill 80 266 354 80 269 354 minecraft:stripped_dark_oak_log
setblock 48 267 329 minecraft:stripped_dark_oak_log
setblock 48 267 336 minecraft:stripped_dark_oak_log
setblock 48 267 343 minecraft:stripped_dark_oak_log
setblock 48 267 350 minecraft:stripped_dark_oak_log
setblock 48 267 357 minecraft:stripped_dark_oak_log
setblock 49 267 323 minecraft:stripped_dark_oak_log
setblock 49 267 363 minecraft:stripped_dark_oak_log
setblock 56 267 323 minecraft:stripped_dark_oak_log
setblock 56 267 363 minecraft:stripped_dark_oak_log
setblock 63 267 323 minecraft:stripped_dark_oak_log
setblock 63 267 363 minecraft:stripped_dark_oak_log
setblock 70 267 323 minecraft:stripped_dark_oak_log
setblock 70 267 363 minecraft:stripped_dark_oak_log
setblock 77 267 323 minecraft:stripped_dark_oak_log
setblock 77 267 363 minecraft:stripped_dark_oak_log
setblock 84 267 323 minecraft:stripped_dark_oak_log
setblock 84 267 363 minecraft:stripped_dark_oak_log
setblock 88 267 326 minecraft:stripped_dark_oak_log
setblock 88 267 333 minecraft:stripped_dark_oak_log
setblock 88 267 340 minecraft:stripped_dark_oak_log
setblock 88 267 347 minecraft:stripped_dark_oak_log
setblock 88 267 354 minecraft:stripped_dark_oak_log
setblock 88 267 361 minecraft:stripped_dark_oak_log
setblock 48 268 323 minecraft:stripped_dark_oak_log
setblock 48 268 330 minecraft:stripped_dark_oak_log
setblock 48 268 337 minecraft:stripped_dark_oak_log
setblock 48 268 344 minecraft:stripped_dark_oak_log
setblock 48 268 351 minecraft:stripped_dark_oak_log
setblock 48 268 358 minecraft:stripped_dark_oak_log
setblock 50 268 325 minecraft:light[level=12]
setblock 50 268 332 minecraft:light[level=12]
setblock 50 268 339 minecraft:light[level=12]
setblock 50 268 346 minecraft:light[level=12]
setblock 50 268 353 minecraft:light[level=12]
setblock 50 268 360 minecraft:light[level=12]
setblock 50 268 363 minecraft:stripped_dark_oak_log
setblock 55 268 323 minecraft:stripped_dark_oak_log
setblock 57 268 325 minecraft:light[level=12]
setblock 57 268 332 minecraft:light[level=12]
setblock 57 268 339 minecraft:light[level=12]
setblock 57 268 346 minecraft:light[level=12]
setblock 57 268 353 minecraft:light[level=12]
setblock 57 268 360 minecraft:light[level=12]
setblock 57 268 363 minecraft:stripped_dark_oak_log
setblock 62 268 323 minecraft:stripped_dark_oak_log
setblock 64 268 325 minecraft:light[level=12]
setblock 64 268 332 minecraft:light[level=12]
setblock 64 268 339 minecraft:light[level=12]
setblock 64 268 346 minecraft:light[level=12]
setblock 64 268 353 minecraft:light[level=12]
setblock 64 268 360 minecraft:light[level=12]
setblock 64 268 363 minecraft:stripped_dark_oak_log
setblock 69 268 323 minecraft:stripped_dark_oak_log
setblock 71 268 325 minecraft:light[level=12]
setblock 71 268 332 minecraft:light[level=12]
setblock 71 268 339 minecraft:light[level=12]
setblock 71 268 346 minecraft:light[level=12]
setblock 71 268 353 minecraft:light[level=12]
setblock 71 268 360 minecraft:light[level=12]
setblock 71 268 363 minecraft:stripped_dark_oak_log
setblock 76 268 323 minecraft:stripped_dark_oak_log
setblock 78 268 325 minecraft:light[level=12]
setblock 78 268 332 minecraft:light[level=12]
setblock 78 268 339 minecraft:light[level=12]
setblock 78 268 346 minecraft:light[level=12]
setblock 78 268 353 minecraft:light[level=12]
setblock 78 268 360 minecraft:light[level=12]
setblock 78 268 363 minecraft:stripped_dark_oak_log
setblock 83 268 323 minecraft:stripped_dark_oak_log
setblock 85 268 325 minecraft:light[level=12]
setblock 85 268 332 minecraft:light[level=12]
setblock 85 268 339 minecraft:light[level=12]
setblock 85 268 346 minecraft:light[level=12]
setblock 85 268 353 minecraft:light[level=12]
setblock 85 268 360 minecraft:light[level=12]
setblock 85 268 363 minecraft:stripped_dark_oak_log
setblock 88 268 325 minecraft:stripped_dark_oak_log
setblock 88 268 332 minecraft:stripped_dark_oak_log
setblock 88 268 339 minecraft:stripped_dark_oak_log
setblock 88 268 346 minecraft:stripped_dark_oak_log
setblock 88 268 353 minecraft:stripped_dark_oak_log
setblock 88 268 360 minecraft:stripped_dark_oak_log
setblock 89 268 360 minecraft:red_concrete
setblock 48 269 324 minecraft:stripped_dark_oak_log
setblock 48 269 331 minecraft:stripped_dark_oak_log
setblock 48 269 338 minecraft:stripped_dark_oak_log
setblock 48 269 345 minecraft:stripped_dark_oak_log
setblock 48 269 352 minecraft:stripped_dark_oak_log
setblock 48 269 359 minecraft:stripped_dark_oak_log
setblock 51 269 363 minecraft:stripped_dark_oak_log
setblock 54 269 323 minecraft:stripped_dark_oak_log
setblock 58 269 363 minecraft:stripped_dark_oak_log
setblock 61 269 323 minecraft:stripped_dark_oak_log
setblock 65 269 363 minecraft:stripped_dark_oak_log
setblock 68 269 323 minecraft:stripped_dark_oak_log
setblock 72 269 363 minecraft:stripped_dark_oak_log
setblock 74 269 324 minecraft:red_concrete
setblock 75 269 323 minecraft:stripped_dark_oak_log
fill 78 269 354 79 269 354 minecraft:cherry_leaves[persistent=true]
fill 79 269 352 80 269 353 minecraft:cherry_leaves[persistent=true]
fill 79 269 355 81 269 355 minecraft:cherry_leaves[persistent=true]
setblock 79 269 363 minecraft:stripped_dark_oak_log
fill 81 269 353 81 269 354 minecraft:cherry_leaves[persistent=true]
setblock 82 269 323 minecraft:stripped_dark_oak_log
setblock 86 269 363 minecraft:stripped_dark_oak_log
setblock 88 269 324 minecraft:stripped_dark_oak_log
setblock 88 269 331 minecraft:stripped_dark_oak_log
setblock 88 269 338 minecraft:stripped_dark_oak_log
setblock 88 269 345 minecraft:stripped_dark_oak_log
setblock 88 269 352 minecraft:stripped_dark_oak_log
setblock 88 269 359 minecraft:stripped_dark_oak_log
fill 89 269 360 89 308 360 minecraft:dark_oak_planks
setblock 65 270 322 minecraft:red_concrete
fill 74 270 324 74 271 324 minecraft:shroomlight
fill 65 271 322 65 308 322 minecraft:dark_oak_planks
setblock 50 272 325 minecraft:light[level=15]
setblock 50 272 333 minecraft:light[level=15]
setblock 50 272 341 minecraft:light[level=15]
setblock 50 272 349 minecraft:light[level=15]
setblock 50 272 357 minecraft:light[level=15]
setblock 58 272 325 minecraft:light[level=15]
setblock 58 272 333 minecraft:light[level=15]
setblock 58 272 341 minecraft:light[level=15]
setblock 58 272 349 minecraft:light[level=15]
setblock 58 272 357 minecraft:light[level=15]
setblock 66 272 325 minecraft:light[level=15]
setblock 66 272 333 minecraft:light[level=15]
setblock 66 272 341 minecraft:light[level=15]
setblock 66 272 349 minecraft:light[level=15]
setblock 66 272 357 minecraft:light[level=15]
fill 70 272 364 72 292 364 minecraft:dark_oak_planks
setblock 73 272 364 minecraft:red_concrete
setblock 74 272 324 minecraft:red_concrete
setblock 74 272 325 minecraft:light[level=15]
setblock 74 272 333 minecraft:light[level=15]
setblock 74 272 341 minecraft:light[level=15]
setblock 74 272 349 minecraft:light[level=15]
setblock 74 272 357 minecraft:light[level=15]
setblock 82 272 325 minecraft:light[level=15]
setblock 82 272 333 minecraft:light[level=15]
setblock 82 272 341 minecraft:light[level=15]
setblock 82 272 349 minecraft:light[level=15]
setblock 82 272 357 minecraft:light[level=15]
setblock 89 272 334 minecraft:red_concrete
fill 89 272 335 89 308 335 minecraft:dark_oak_planks
fill 49 273 324 49 274 324 minecraft:red_concrete
fill 49 273 325 49 274 361 minecraft:deepslate_tiles
fill 49 273 362 49 274 362 minecraft:red_concrete
fill 50 273 324 86 274 324 minecraft:deepslate_tiles
fill 50 273 325 50 275 325 minecraft:red_concrete
fill 50 273 326 50 275 360 minecraft:deepslate_tiles
fill 50 273 361 50 275 361 minecraft:red_concrete
fill 50 273 362 86 274 362 minecraft:deepslate_tiles
fill 51 273 325 85 275 325 minecraft:deepslate_tiles
fill 51 273 326 51 275 326 minecraft:red_concrete
fill 51 273 327 51 275 359 minecraft:deepslate_tiles
fill 51 273 360 51 275 360 minecraft:red_concrete
fill 51 273 361 85 275 361 minecraft:deepslate_tiles
fill 52 273 326 84 275 326 minecraft:deepslate_tiles
fill 52 273 327 52 276 327 minecraft:red_concrete
fill 52 273 328 52 276 358 minecraft:deepslate_tiles
fill 52 273 359 52 276 359 minecraft:red_concrete
fill 52 273 360 84 275 360 minecraft:deepslate_tiles
fill 53 273 327 83 276 327 minecraft:deepslate_tiles
fill 53 273 328 53 276 328 minecraft:red_concrete
fill 53 273 329 53 276 357 minecraft:deepslate_tiles
fill 53 273 358 53 276 358 minecraft:red_concrete
fill 53 273 359 83 276 359 minecraft:deepslate_tiles
fill 54 273 328 82 276 328 minecraft:deepslate_tiles
fill 54 273 329 54 277 329 minecraft:red_concrete
fill 54 273 330 54 277 356 minecraft:deepslate_tiles
fill 54 273 357 54 277 357 minecraft:red_concrete
fill 54 273 358 82 276 358 minecraft:deepslate_tiles
fill 55 273 329 81 277 329 minecraft:deepslate_tiles
fill 55 273 330 55 277 330 minecraft:red_concrete
fill 55 273 331 55 277 355 minecraft:deepslate_tiles
fill 55 273 356 55 277 356 minecraft:red_concrete
fill 55 273 357 81 277 357 minecraft:deepslate_tiles
fill 56 273 330 80 277 330 minecraft:deepslate_tiles
fill 56 273 331 56 278 331 minecraft:red_concrete
fill 56 273 332 56 279 354 minecraft:deepslate_tiles
fill 56 273 355 56 278 355 minecraft:red_concrete
fill 56 273 356 80 277 356 minecraft:deepslate_tiles
fill 57 273 331 79 279 331 minecraft:deepslate_tiles
fill 57 273 332 57 278 332 minecraft:red_concrete
fill 57 273 333 57 279 353 minecraft:deepslate_tiles
fill 57 273 354 57 278 354 minecraft:red_concrete
fill 57 273 355 79 279 355 minecraft:deepslate_tiles
fill 58 273 332 78 279 332 minecraft:deepslate_tiles
fill 58 273 333 58 279 333 minecraft:red_concrete
fill 58 273 334 58 279 352 minecraft:deepslate_tiles
fill 58 273 353 58 279 353 minecraft:red_concrete
fill 58 273 354 78 279 354 minecraft:deepslate_tiles
fill 59 273 333 77 279 333 minecraft:deepslate_tiles
fill 59 273 334 59 279 334 minecraft:red_concrete
fill 59 273 335 59 279 351 minecraft:deepslate_tiles
fill 59 273 352 59 279 352 minecraft:red_concrete
fill 59 273 353 77 279 353 minecraft:deepslate_tiles
fill 60 273 334 76 279 334 minecraft:deepslate_tiles
fill 60 273 335 60 279 335 minecraft:red_concrete
fill 60 273 336 60 279 350 minecraft:deepslate_tiles
fill 60 273 351 60 279 351 minecraft:red_concrete
fill 60 273 352 76 279 352 minecraft:deepslate_tiles
fill 61 273 335 75 279 335 minecraft:deepslate_tiles
fill 61 273 336 61 279 336 minecraft:red_concrete
fill 61 273 337 61 279 349 minecraft:deepslate_tiles
fill 61 273 350 61 279 350 minecraft:red_concrete
fill 61 273 351 75 279 351 minecraft:deepslate_tiles
fill 62 273 336 74 279 336 minecraft:deepslate_tiles
fill 62 273 337 62 279 337 minecraft:red_concrete
fill 62 273 338 62 279 348 minecraft:deepslate_tiles
fill 62 273 349 62 279 349 minecraft:red_concrete
fill 62 273 350 74 278 350 minecraft:deepslate_tiles
fill 63 273 337 73 279 337 minecraft:deepslate_tiles
fill 63 273 338 63 279 338 minecraft:red_concrete
fill 63 273 339 63 278 347 minecraft:deepslate_tiles
fill 63 273 348 63 279 348 minecraft:red_concrete
fill 63 273 349 73 273 349 minecraft:deepslate_tiles
fill 64 273 338 72 279 338 minecraft:deepslate_tiles
fill 64 273 339 64 279 339 minecraft:red_concrete
fill 64 273 340 64 273 346 minecraft:deepslate_tiles
fill 64 273 347 64 278 347 minecraft:red_concrete
fill 64 273 348 72 273 348 minecraft:deepslate_tiles
fill 65 273 339 71 279 339 minecraft:deepslate_tiles
fill 65 273 340 65 279 340 minecraft:red_concrete
fill 65 273 341 65 273 345 minecraft:deepslate_tiles
setblock 65 273 346 minecraft:red_concrete
fill 65 273 347 66 273 347 minecraft:deepslate_tiles
fill 66 273 340 70 279 340 minecraft:deepslate_tiles
fill 66 273 341 66 279 341 minecraft:red_concrete
fill 66 273 342 66 273 344 minecraft:deepslate_tiles
setblock 66 273 345 minecraft:red_concrete
fill 67 273 341 69 279 341 minecraft:deepslate_tiles
fill 67 273 342 67 278 342 minecraft:red_concrete
setblock 67 273 343 minecraft:deepslate_tiles
setblock 67 273 344 minecraft:red_concrete
fill 68 273 342 68 278 342 minecraft:deepslate_tiles
fill 68 273 343 68 278 343 minecraft:red_concrete
fill 68 273 344 68 273 345 minecraft:deepslate_tiles
fill 68 273 347 71 273 347 minecraft:deepslate_tiles
fill 69 273 342 69 279 342 minecraft:red_concrete
fill 69 273 343 87 274 343 minecraft:deepslate_tiles
setblock 69 273 344 minecraft:red_concrete
fill 69 273 345 69 273 346 minecraft:deepslate_tiles
fill 70 273 341 70 279 341 minecraft:red_concrete
fill 70 273 342 87 274 342 minecraft:deepslate_tiles
fill 70 273 344 87 274 344 minecraft:deepslate_tiles
fill 70 273 345 70 278 345 minecraft:red_concrete
setblock 70 273 346 minecraft:deepslate_tiles
fill 71 273 340 71 279 340 minecraft:red_concrete
fill 71 273 341 87 274 341 minecraft:deepslate_tiles
fill 71 273 345 87 274 345 minecraft:deepslate_tiles
fill 71 273 346 71 278 346 minecraft:red_concrete
fill 72 273 339 72 279 339 minecraft:red_concrete
fill 72 273 340 87 274 340 minecraft:deepslate_tiles
fill 72 273 346 87 274 346 minecraft:deepslate_tiles
fill 72 273 347 72 279 347 minecraft:red_concrete
fill 73 273 338 73 279 338 minecraft:red_concrete
fill 73 273 339 87 274 339 minecraft:deepslate_tiles
fill 73 273 347 87 274 347 minecraft:deepslate_tiles
fill 73 273 348 73 279 348 minecraft:red_concrete
fill 73 273 364 73 308 364 minecraft:dark_oak_planks
fill 74 273 337 74 279 337 minecraft:red_concrete
fill 74 273 338 87 274 338 minecraft:deepslate_tiles
fill 74 273 348 87 274 348 minecraft:deepslate_tiles
fill 74 273 349 74 279 349 minecraft:red_concrete
fill 75 273 336 75 279 336 minecraft:red_concrete
fill 75 273 337 87 274 337 minecraft:deepslate_tiles
fill 75 273 349 87 274 349 minecraft:deepslate_tiles
fill 75 273 350 75 279 350 minecraft:red_concrete
fill 76 273 335 76 279 335 minecraft:red_concrete
fill 76 273 336 87 274 336 minecraft:deepslate_tiles
fill 76 273 350 87 274 350 minecraft:deepslate_tiles
fill 76 273 351 76 279 351 minecraft:red_concrete
fill 77 273 334 77 279 334 minecraft:red_concrete
fill 77 273 335 87 274 335 minecraft:deepslate_tiles
fill 77 273 351 87 274 351 minecraft:deepslate_tiles
fill 77 273 352 77 279 352 minecraft:red_concrete
fill 78 273 333 78 279 333 minecraft:red_concrete
fill 78 273 334 87 274 334 minecraft:deepslate_tiles
fill 78 273 352 87 274 352 minecraft:deepslate_tiles
fill 78 273 353 78 279 353 minecraft:red_concrete
fill 79 273 332 79 278 332 minecraft:red_concrete
fill 79 273 333 87 274 333 minecraft:deepslate_tiles
fill 79 273 353 87 274 353 minecraft:deepslate_tiles
fill 79 273 354 79 278 354 minecraft:red_concrete
fill 80 273 331 80 278 331 minecraft:red_concrete
fill 80 273 332 87 274 332 minecraft:deepslate_tiles
fill 80 273 354 87 274 354 minecraft:deepslate_tiles
fill 80 273 355 80 278 355 minecraft:red_concrete
fill 81 273 330 81 277 330 minecraft:red_concrete
fill 81 273 331 87 274 331 minecraft:deepslate_tiles
fill 81 273 355 87 274 355 minecraft:deepslate_tiles
fill 81 273 356 81 277 356 minecraft:red_concrete
fill 82 273 329 82 277 329 minecraft:red_concrete
fill 82 273 330 87 274 330 minecraft:deepslate_tiles
fill 82 273 356 87 274 356 minecraft:deepslate_tiles
fill 82 273 357 82 277 357 minecraft:red_concrete
fill 83 273 328 83 276 328 minecraft:red_concrete
fill 83 273 329 87 274 329 minecraft:deepslate_tiles
fill 83 273 357 87 274 357 minecraft:deepslate_tiles
fill 83 273 358 83 276 358 minecraft:red_concrete
fill 84 273 327 84 276 327 minecraft:red_concrete
fill 84 273 328 87 274 328 minecraft:deepslate_tiles
fill 84 273 358 87 274 358 minecraft:deepslate_tiles
fill 84 273 359 84 276 359 minecraft:red_concrete
fill 85 273 326 85 275 326 minecraft:red_concrete
fill 85 273 327 87 274 327 minecraft:deepslate_tiles
fill 85 273 359 87 274 359 minecraft:deepslate_tiles
fill 85 273 360 85 275 360 minecraft:red_concrete
fill 86 273 325 86 275 325 minecraft:red_concrete
fill 86 273 326 87 274 326 minecraft:deepslate_tiles
fill 86 273 360 87 274 360 minecraft:deepslate_tiles
fill 86 273 361 86 275 361 minecraft:red_concrete
fill 87 273 324 87 274 324 minecraft:red_concrete
fill 87 273 325 87 274 325 minecraft:deepslate_tiles
fill 87 273 361 87 274 361 minecraft:deepslate_tiles
fill 87 273 362 87 274 362 minecraft:red_concrete
fill 89 273 334 89 285 334 minecraft:dark_oak_planks
setblock 58 274 322 minecraft:red_concrete
fill 63 274 349 66 278 349 minecraft:deepslate_tiles
fill 64 274 340 64 278 345 minecraft:deepslate_tiles
fill 64 274 348 64 278 348 minecraft:deepslate_tiles
fill 65 274 341 65 278 343 minecraft:deepslate_tiles
fill 66 274 342 66 278 343 minecraft:deepslate_tiles
fill 68 274 349 73 278 349 minecraft:deepslate_tiles
fill 70 274 347 71 278 348 minecraft:deepslate_tiles
fill 72 274 348 72 279 348 minecraft:deepslate_tiles
fill 58 275 322 58 283 322 minecraft:dark_oak_planks
fill 64 275 364 64 303 364 minecraft:dark_oak_planks
setblock 65 275 364 minecraft:red_concrete
fill 66 275 364 66 308 364 minecraft:dark_oak_planks
fill 69 275 343 86 275 343 minecraft:deepslate_tiles
fill 70 275 342 86 275 342 minecraft:deepslate_tiles
fill 70 275 344 86 275 344 minecraft:deepslate_tiles
fill 71 275 341 86 275 341 minecraft:deepslate_tiles
fill 71 275 345 86 275 345 minecraft:deepslate_tiles
fill 72 275 340 86 275 340 minecraft:deepslate_tiles
fill 72 275 346 86 275 346 minecraft:deepslate_tiles
fill 73 275 339 86 275 339 minecraft:deepslate_tiles
fill 73 275 347 86 275 347 minecraft:deepslate_tiles
fill 74 275 338 86 275 338 minecraft:deepslate_tiles
fill 74 275 348 86 275 348 minecraft:deepslate_tiles
fill 75 275 337 86 275 337 minecraft:deepslate_tiles
fill 75 275 349 86 275 349 minecraft:deepslate_tiles
fill 76 275 336 86 275 336 minecraft:deepslate_tiles
fill 76 275 350 86 275 350 minecraft:deepslate_tiles
fill 77 275 335 86 275 335 minecraft:deepslate_tiles
fill 77 275 351 86 275 351 minecraft:deepslate_tiles
fill 78 275 334 86 275 334 minecraft:deepslate_tiles
fill 78 275 352 86 275 352 minecraft:deepslate_tiles
fill 79 275 333 86 275 333 minecraft:deepslate_tiles
fill 79 275 353 86 275 353 minecraft:deepslate_tiles
fill 80 275 332 86 275 332 minecraft:deepslate_tiles
fill 80 275 354 86 275 354 minecraft:deepslate_tiles
fill 81 275 331 86 275 331 minecraft:deepslate_tiles
fill 81 275 355 86 275 355 minecraft:deepslate_tiles
fill 82 275 330 86 275 330 minecraft:deepslate_tiles
fill 82 275 356 86 275 356 minecraft:deepslate_tiles
fill 83 275 329 86 275 329 minecraft:deepslate_tiles
fill 83 275 357 86 275 357 minecraft:deepslate_tiles
fill 84 275 328 86 275 328 minecraft:deepslate_tiles
fill 84 275 358 86 275 358 minecraft:deepslate_tiles
fill 85 275 327 86 275 327 minecraft:deepslate_tiles
fill 85 275 359 86 275 359 minecraft:deepslate_tiles
setblock 86 275 326 minecraft:deepslate_tiles
setblock 86 275 360 minecraft:deepslate_tiles
setblock 89 275 338 minecraft:red_concrete
setblock 89 275 346 minecraft:red_concrete
fill 65 276 364 65 308 364 minecraft:dark_oak_planks
setblock 68 276 364 minecraft:red_concrete
fill 69 276 343 84 276 343 minecraft:deepslate_tiles
fill 70 276 342 84 276 342 minecraft:deepslate_tiles
fill 70 276 344 84 276 344 minecraft:deepslate_tiles
fill 71 276 341 84 276 341 minecraft:deepslate_tiles
fill 71 276 345 84 276 345 minecraft:deepslate_tiles
fill 72 276 340 84 276 340 minecraft:deepslate_tiles
fill 72 276 346 84 276 346 minecraft:deepslate_tiles
fill 73 276 339 84 276 339 minecraft:deepslate_tiles
fill 73 276 347 84 276 347 minecraft:deepslate_tiles
fill 74 276 338 84 276 338 minecraft:deepslate_tiles
fill 74 276 348 84 276 348 minecraft:deepslate_tiles
fill 75 276 337 84 276 337 minecraft:deepslate_tiles
fill 75 276 349 84 276 349 minecraft:deepslate_tiles
fill 76 276 336 84 276 336 minecraft:deepslate_tiles
fill 76 276 350 84 276 350 minecraft:deepslate_tiles
fill 77 276 335 84 276 335 minecraft:deepslate_tiles
fill 77 276 351 84 276 351 minecraft:deepslate_tiles
fill 78 276 334 84 276 334 minecraft:deepslate_tiles
fill 78 276 352 84 276 352 minecraft:deepslate_tiles
fill 79 276 333 84 276 333 minecraft:deepslate_tiles
fill 79 276 353 84 276 353 minecraft:deepslate_tiles
fill 80 276 332 84 276 332 minecraft:deepslate_tiles
fill 80 276 354 84 276 354 minecraft:deepslate_tiles
fill 81 276 331 84 276 331 minecraft:deepslate_tiles
fill 81 276 355 84 276 355 minecraft:deepslate_tiles
fill 82 276 330 84 276 330 minecraft:deepslate_tiles
fill 82 276 356 84 276 356 minecraft:deepslate_tiles
fill 83 276 329 84 276 329 minecraft:deepslate_tiles
fill 83 276 357 84 276 357 minecraft:deepslate_tiles
setblock 84 276 328 minecraft:deepslate_tiles
setblock 84 276 358 minecraft:deepslate_tiles
fill 89 276 338 89 308 338 minecraft:dark_oak_planks
fill 89 276 346 89 308 346 minecraft:dark_oak_planks
fill 68 277 364 68 308 364 minecraft:dark_oak_planks
fill 69 277 343 82 277 343 minecraft:deepslate_tiles
fill 70 277 342 82 277 342 minecraft:deepslate_tiles
fill 70 277 344 82 277 344 minecraft:deepslate_tiles
fill 71 277 341 82 277 341 minecraft:deepslate_tiles
fill 71 277 345 82 277 345 minecraft:deepslate_tiles
fill 72 277 340 82 277 340 minecraft:deepslate_tiles
fill 72 277 346 82 277 346 minecraft:deepslate_tiles
fill 73 277 339 82 277 339 minecraft:deepslate_tiles
fill 73 277 347 82 277 347 minecraft:deepslate_tiles
fill 74 277 338 82 277 338 minecraft:deepslate_tiles
fill 74 277 348 82 277 348 minecraft:deepslate_tiles
fill 75 277 337 82 277 337 minecraft:deepslate_tiles
fill 75 277 349 82 277 349 minecraft:deepslate_tiles
fill 76 277 336 82 277 336 minecraft:deepslate_tiles
fill 76 277 350 82 277 350 minecraft:deepslate_tiles
fill 77 277 335 82 277 335 minecraft:deepslate_tiles
fill 77 277 351 82 277 351 minecraft:deepslate_tiles
fill 78 277 334 82 277 334 minecraft:deepslate_tiles
fill 78 277 352 82 277 352 minecraft:deepslate_tiles
fill 79 277 333 82 277 333 minecraft:deepslate_tiles
fill 79 277 353 82 277 353 minecraft:deepslate_tiles
fill 80 277 332 82 277 332 minecraft:deepslate_tiles
fill 80 277 354 82 277 354 minecraft:deepslate_tiles
fill 81 277 331 82 277 331 minecraft:deepslate_tiles
fill 81 277 355 82 277 355 minecraft:deepslate_tiles
setblock 82 277 330 minecraft:deepslate_tiles
setblock 82 277 356 minecraft:deepslate_tiles
setblock 64 278 325 minecraft:red_concrete
fill 69 278 343 80 278 343 minecraft:deepslate_tiles
fill 70 278 342 80 279 342 minecraft:deepslate_tiles
fill 70 278 344 80 278 344 minecraft:deepslate_tiles
fill 71 278 341 80 279 341 minecraft:deepslate_tiles
fill 71 278 345 80 278 345 minecraft:deepslate_tiles
fill 72 278 340 80 279 340 minecraft:deepslate_tiles
fill 72 278 346 80 279 346 minecraft:deepslate_tiles
fill 73 278 339 80 279 339 minecraft:deepslate_tiles
fill 73 278 347 80 279 347 minecraft:deepslate_tiles
fill 74 278 338 80 279 338 minecraft:deepslate_tiles
fill 74 278 348 80 279 348 minecraft:deepslate_tiles
fill 75 278 337 80 279 337 minecraft:deepslate_tiles
fill 75 278 349 80 279 349 minecraft:deepslate_tiles
fill 76 278 336 80 279 336 minecraft:deepslate_tiles
fill 76 278 350 80 279 350 minecraft:deepslate_tiles
fill 77 278 335 80 279 335 minecraft:deepslate_tiles
fill 77 278 351 80 279 351 minecraft:deepslate_tiles
fill 78 278 334 80 279 334 minecraft:deepslate_tiles
fill 78 278 352 80 279 352 minecraft:deepslate_tiles
fill 79 278 333 80 279 333 minecraft:deepslate_tiles
fill 79 278 353 80 279 353 minecraft:deepslate_tiles
fill 80 278 332 80 279 332 minecraft:deepslate_tiles
fill 80 278 354 80 279 354 minecraft:deepslate_tiles
fill 48 279 323 55 279 363 minecraft:deepslate_tiles
fill 56 279 323 56 279 331 minecraft:deepslate_tiles
fill 56 279 355 56 279 363 minecraft:deepslate_tiles
fill 57 279 323 63 279 330 minecraft:deepslate_tiles
setblock 57 279 332 minecraft:deepslate_tiles
setblock 57 279 354 minecraft:deepslate_tiles
fill 57 279 356 88 279 363 minecraft:deepslate_tiles
fill 62 279 350 65 279 350 minecraft:deepslate_tiles
fill 63 279 339 63 279 344 minecraft:deepslate_tiles
fill 63 279 345 63 279 347 minecraft:gold_block
setblock 63 279 349 minecraft:deepslate_tiles
fill 64 279 323 88 279 324 minecraft:deepslate_tiles
fill 64 279 325 64 280 325 minecraft:shroomlight
fill 64 279 326 88 279 330 minecraft:deepslate_tiles
fill 64 279 340 64 279 342 minecraft:deepslate_tiles
fill 64 279 343 64 279 345 minecraft:gold_block
fill 64 279 347 64 279 349 minecraft:gold_block
fill 65 279 325 88 279 325 minecraft:deepslate_tiles
fill 65 279 341 65 279 342 minecraft:deepslate_tiles
fill 65 279 343 66 279 343 minecraft:gold_block
fill 65 279 349 66 279 349 minecraft:gold_block
fill 66 279 342 68 279 342 minecraft:gold_block
fill 66 279 350 68 279 350 minecraft:gold_block
fill 68 279 343 70 279 343 minecraft:gold_block
fill 68 279 349 70 279 349 minecraft:gold_block
fill 69 279 350 74 279 350 minecraft:deepslate_tiles
fill 70 279 344 70 279 345 minecraft:gold_block
fill 70 279 347 70 279 348 minecraft:gold_block
fill 71 279 343 88 279 344 minecraft:deepslate_tiles
fill 71 279 345 71 279 347 minecraft:gold_block
fill 71 279 348 71 279 349 minecraft:deepslate_tiles
fill 72 279 345 88 279 345 minecraft:deepslate_tiles
fill 72 279 349 73 279 349 minecraft:deepslate_tiles
setblock 79 279 332 minecraft:deepslate_tiles
setblock 79 279 354 minecraft:deepslate_tiles
fill 80 279 331 88 279 331 minecraft:deepslate_tiles
fill 80 279 355 88 279 355 minecraft:deepslate_tiles
fill 81 279 332 88 279 342 minecraft:deepslate_tiles
fill 81 279 346 88 279 354 minecraft:deepslate_tiles
setblock 50 280 325 minecraft:light[level=15]
setblock 50 280 332 minecraft:light[level=12]
setblock 50 280 333 minecraft:light[level=15]
setblock 50 280 339 minecraft:light[level=12]
setblock 50 280 341 minecraft:light[level=15]
setblock 50 280 346 minecraft:light[level=12]
setblock 50 280 349 minecraft:light[level=15]
setblock 50 280 353 minecraft:light[level=12]
setblock 50 280 357 minecraft:light[level=15]
setblock 50 280 360 minecraft:light[level=12]
setblock 53 280 325 minecraft:red_concrete
setblock 57 280 325 minecraft:light[level=12]
setblock 57 280 332 minecraft:light[level=12]
setblock 57 280 339 minecraft:light[level=12]
setblock 57 280 346 minecraft:light[level=12]
setblock 57 280 353 minecraft:light[level=12]
setblock 57 280 360 minecraft:light[level=12]
setblock 58 280 325 minecraft:light[level=15]
setblock 58 280 333 minecraft:light[level=15]
setblock 58 280 341 minecraft:light[level=15]
setblock 58 280 349 minecraft:light[level=15]
setblock 58 280 357 minecraft:light[level=15]
fill 59 280 354 62 282 355 minecraft:cherry_leaves[persistent=true]
setblock 64 280 332 minecraft:light[level=12]
setblock 64 280 339 minecraft:light[level=12]
setblock 64 280 353 minecraft:light[level=12]
setblock 64 280 360 minecraft:light[level=12]
setblock 66 280 325 minecraft:light[level=15]
setblock 66 280 333 minecraft:light[level=15]
setblock 66 280 341 minecraft:light[level=15]
setblock 66 280 349 minecraft:light[level=15]
setblock 66 280 357 minecraft:light[level=15]
setblock 71 280 325 minecraft:light[level=12]
setblock 71 280 332 minecraft:light[level=12]
setblock 71 280 339 minecraft:light[level=12]
setblock 71 280 346 minecraft:light[level=12]
setblock 71 280 353 minecraft:light[level=12]
setblock 71 280 360 minecraft:light[level=12]
setblock 74 280 325 minecraft:light[level=15]
setblock 74 280 333 minecraft:light[level=15]
setblock 74 280 341 minecraft:light[level=15]
setblock 74 280 349 minecraft:light[level=15]
setblock 74 280 357 minecraft:light[level=15]
setblock 78 280 325 minecraft:light[level=12]
setblock 78 280 332 minecraft:light[level=12]
setblock 78 280 339 minecraft:light[level=12]
setblock 78 280 346 minecraft:light[level=12]
setblock 78 280 353 minecraft:light[level=12]
setblock 78 280 360 minecraft:light[level=12]
setblock 82 280 325 minecraft:light[level=15]
setblock 82 280 333 minecraft:light[level=15]
setblock 82 280 341 minecraft:light[level=15]
setblock 82 280 349 minecraft:light[level=15]
setblock 82 280 357 minecraft:light[level=15]
setblock 85 280 325 minecraft:light[level=12]
setblock 85 280 332 minecraft:light[level=12]
setblock 85 280 339 minecraft:light[level=12]
setblock 85 280 346 minecraft:light[level=12]
setblock 85 280 353 minecraft:light[level=12]
setblock 85 280 360 minecraft:light[level=12]
fill 53 281 325 53 282 325 minecraft:shroomlight
fill 58 281 354 58 282 354 minecraft:cherry_leaves[persistent=true]
fill 59 281 353 61 282 353 minecraft:cherry_leaves[persistent=true]
fill 59 281 356 61 282 356 minecraft:cherry_leaves[persistent=true]
setblock 64 281 325 minecraft:red_concrete
setblock 62 282 353 minecraft:cherry_leaves[persistent=true]
setblock 48 283 324 minecraft:stripped_dark_oak_log
fill 48 283 328 48 300 328 minecraft:stripped_dark_oak_log
setblock 48 283 331 minecraft:stripped_dark_oak_log
fill 48 283 335 48 300 335 minecraft:stripped_dark_oak_log
setblock 48 283 338 minecraft:stripped_dark_oak_log
fill 48 283 342 48 300 342 minecraft:stripped_dark_oak_log
setblock 48 283 345 minecraft:stripped_dark_oak_log
fill 48 283 349 48 300 349 minecraft:stripped_dark_oak_log
setblock 48 283 352 minecraft:stripped_dark_oak_log
fill 48 283 356 48 300 356 minecraft:stripped_dark_oak_log
setblock 48 283 359 minecraft:stripped_dark_oak_log
fill 48 283 363 48 300 363 minecraft:stripped_dark_oak_log
fill 50 283 323 50 300 323 minecraft:stripped_dark_oak_log
setblock 51 283 363 minecraft:stripped_dark_oak_log
setblock 53 283 325 minecraft:red_concrete
setblock 54 283 323 minecraft:stripped_dark_oak_log
fill 55 283 363 55 300 363 minecraft:stripped_dark_oak_log
fill 57 283 323 57 300 323 minecraft:stripped_dark_oak_log
fill 58 283 324 62 286 324 minecraft:red_wool
setblock 58 283 363 minecraft:stripped_dark_oak_log
fill 59 283 354 61 283 354 minecraft:cherry_leaves[persistent=true]
setblock 60 283 335 minecraft:red_concrete
fill 60 283 336 60 283 350 minecraft:deepslate_tiles
setblock 60 283 351 minecraft:red_concrete
fill 60 283 355 61 283 356 minecraft:cherry_leaves[persistent=true]
setblock 61 283 323 minecraft:stripped_dark_oak_log
fill 61 283 335 75 283 335 minecraft:deepslate_tiles
setblock 61 283 336 minecraft:red_concrete
fill 61 283 337 61 283 349 minecraft:deepslate_tiles
setblock 61 283 350 minecraft:red_concrete
fill 61 283 351 75 283 351 minecraft:deepslate_tiles
setblock 61 283 353 minecraft:cherry_leaves[persistent=true]
fill 62 283 336 74 283 336 minecraft:deepslate_tiles
fill 62 283 337 62 284 337 minecraft:red_concrete
fill 62 283 338 62 284 348 minecraft:deepslate_tiles
fill 62 283 349 62 284 349 minecraft:red_concrete
fill 62 283 350 74 283 350 minecraft:deepslate_tiles
fill 62 283 363 69 285 363 minecraft:stripped_dark_oak_log
fill 63 283 337 73 284 337 minecraft:deepslate_tiles
fill 63 283 338 63 284 338 minecraft:red_concrete
fill 63 283 339 63 284 347 minecraft:deepslate_tiles
fill 63 283 348 63 284 348 minecraft:red_concrete
fill 63 283 349 73 284 349 minecraft:deepslate_tiles
fill 63 283 354 69 285 362 minecraft:stripped_dark_oak_log
fill 64 283 323 83 285 323 minecraft:stripped_dark_oak_log
fill 64 283 338 72 284 338 minecraft:deepslate_tiles
fill 64 283 339 64 285 339 minecraft:red_concrete
fill 64 283 340 64 285 346 minecraft:deepslate_tiles
fill 64 283 347 64 285 347 minecraft:red_concrete
fill 64 283 348 72 284 348 minecraft:deepslate_tiles
fill 65 283 324 83 285 326 minecraft:stripped_dark_oak_log
fill 65 283 339 71 285 339 minecraft:deepslate_tiles
fill 65 283 340 65 285 340 minecraft:red_concrete
fill 65 283 341 65 285 345 minecraft:deepslate_tiles
fill 65 283 346 65 285 346 minecraft:red_concrete
fill 65 283 347 66 285 347 minecraft:deepslate_tiles
fill 66 283 340 70 285 340 minecraft:deepslate_tiles
fill 66 283 341 66 285 341 minecraft:red_concrete
fill 66 283 342 66 285 344 minecraft:deepslate_tiles
fill 66 283 345 66 285 345 minecraft:red_concrete
fill 67 283 341 69 285 341 minecraft:deepslate_tiles
fill 67 283 342 67 285 342 minecraft:red_concrete
fill 67 283 343 67 285 343 minecraft:deepslate_tiles
fill 67 283 344 67 285 344 minecraft:red_concrete
fill 68 283 342 68 285 342 minecraft:deepslate_tiles
fill 68 283 343 68 285 343 minecraft:red_concrete
fill 68 283 344 68 285 344 minecraft:deepslate_tiles
fill 68 283 347 71 285 347 minecraft:deepslate_tiles
fill 69 283 342 69 285 342 minecraft:red_concrete
fill 69 283 343 76 283 343 minecraft:deepslate_tiles
fill 69 283 344 69 285 344 minecraft:red_concrete
fill 69 283 345 69 285 346 minecraft:deepslate_tiles
fill 70 283 341 70 285 341 minecraft:red_concrete
fill 70 283 342 76 283 342 minecraft:deepslate_tiles
fill 70 283 344 76 283 344 minecraft:deepslate_tiles
fill 70 283 345 70 285 345 minecraft:red_concrete
fill 70 283 346 70 285 346 minecraft:deepslate_tiles
schedule function dropper:buildpart/73_5 1t
