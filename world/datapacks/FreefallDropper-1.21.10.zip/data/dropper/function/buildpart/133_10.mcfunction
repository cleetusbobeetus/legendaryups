fill 64 269 596 64 271 596 minecraft:cobbled_deepslate
setblock 65 269 559 minecraft:calcite
setblock 66 269 558 minecraft:calcite
setblock 66 269 559 minecraft:cobbled_deepslate
setblock 66 269 598 minecraft:calcite
setblock 67 269 558 minecraft:cobbled_deepslate
setblock 67 269 597 minecraft:calcite
fill 67 269 598 67 272 598 minecraft:cobbled_deepslate
setblock 76 269 598 minecraft:calcite
fill 77 269 598 77 272 598 minecraft:cobbled_deepslate
setblock 81 269 558 minecraft:calcite
setblock 81 269 598 minecraft:calcite
fill 82 269 558 82 270 558 minecraft:cobbled_deepslate
fill 82 269 598 82 272 598 minecraft:cobbled_deepslate
setblock 85 269 585 minecraft:cobbled_deepslate
setblock 86 269 568 minecraft:calcite
fill 86 269 569 86 272 569 minecraft:cobbled_deepslate
setblock 86 269 572 minecraft:cobbled_deepslate
setblock 86 269 583 minecraft:calcite
fill 86 269 584 86 270 584 minecraft:cobbled_deepslate
setblock 86 269 588 minecraft:calcite
fill 86 269 589 86 270 589 minecraft:cobbled_deepslate
setblock 87 269 562 minecraft:calcite
fill 87 269 563 87 270 563 minecraft:cobbled_deepslate
setblock 87 269 567 minecraft:calcite
fill 87 269 568 87 272 568 minecraft:cobbled_deepslate
setblock 87 269 572 minecraft:calcite
fill 87 269 573 87 272 573 minecraft:cobbled_deepslate
setblock 87 269 577 minecraft:calcite
setblock 87 269 578 minecraft:cobbled_deepslate
setblock 87 269 582 minecraft:calcite
fill 87 269 583 87 270 583 minecraft:cobbled_deepslate
setblock 87 269 587 minecraft:calcite
fill 87 269 588 87 271 588 minecraft:cobbled_deepslate
setblock 88 269 561 minecraft:calcite
fill 88 269 562 88 271 562 minecraft:cobbled_deepslate
setblock 88 269 566 minecraft:calcite
fill 88 269 567 88 272 567 minecraft:cobbled_deepslate
setblock 88 269 571 minecraft:calcite
fill 88 269 572 88 272 572 minecraft:cobbled_deepslate
setblock 88 269 576 minecraft:calcite
fill 88 269 577 88 271 577 minecraft:cobbled_deepslate
setblock 88 269 581 minecraft:calcite
fill 88 269 582 88 271 582 minecraft:cobbled_deepslate
setblock 88 269 586 minecraft:calcite
fill 88 269 587 88 272 587 minecraft:cobbled_deepslate
setblock 88 269 591 minecraft:calcite
fill 88 269 592 88 271 592 minecraft:cobbled_deepslate
setblock 48 270 560 minecraft:calcite
fill 48 270 561 48 272 561 minecraft:cobbled_deepslate
setblock 48 270 565 minecraft:calcite
fill 48 270 566 48 273 566 minecraft:cobbled_deepslate
setblock 48 270 570 minecraft:calcite
fill 48 270 571 48 273 571 minecraft:cobbled_deepslate
setblock 48 270 575 minecraft:calcite
setblock 48 270 585 minecraft:calcite
setblock 48 270 586 minecraft:cobbled_deepslate
setblock 48 270 590 minecraft:calcite
setblock 48 270 591 minecraft:cobbled_deepslate
setblock 49 270 564 minecraft:calcite
fill 49 270 565 49 272 565 minecraft:cobbled_deepslate
setblock 49 270 569 minecraft:calcite
fill 49 270 570 49 273 570 minecraft:cobbled_deepslate
setblock 50 270 568 minecraft:calcite
setblock 55 270 558 minecraft:calcite
fill 55 270 559 55 271 559 minecraft:cobbled_deepslate
setblock 55 270 598 minecraft:calcite
fill 56 270 558 56 273 558 minecraft:cobbled_deepslate
fill 56 270 598 56 273 598 minecraft:cobbled_deepslate
fill 57 270 597 57 273 597 minecraft:cobbled_deepslate
setblock 58 270 560 minecraft:calcite
setblock 59 270 559 minecraft:calcite
fill 59 270 560 59 271 560 minecraft:cobbled_deepslate
setblock 60 270 558 minecraft:calcite
fill 60 270 559 60 273 559 minecraft:cobbled_deepslate
fill 60 270 596 61 270 596 minecraft:cobbled_deepslate
setblock 60 270 598 minecraft:calcite
fill 61 270 558 61 273 558 minecraft:cobbled_deepslate
setblock 61 270 597 minecraft:calcite
fill 61 270 598 61 273 598 minecraft:cobbled_deepslate
setblock 62 270 596 minecraft:calcite
fill 62 270 597 62 273 597 minecraft:cobbled_deepslate
fill 63 270 596 63 273 596 minecraft:cobbled_deepslate
setblock 64 270 559 minecraft:calcite
setblock 65 270 558 minecraft:calcite
setblock 65 270 598 minecraft:calcite
setblock 66 270 558 minecraft:cobbled_deepslate
setblock 66 270 597 minecraft:calcite
fill 66 270 598 66 273 598 minecraft:cobbled_deepslate
setblock 75 270 598 minecraft:calcite
fill 76 270 598 76 273 598 minecraft:cobbled_deepslate
fill 77 270 565 77 270 568 minecraft:diamond_block
fill 78 270 564 78 270 565 minecraft:diamond_block
fill 78 270 568 78 270 569 minecraft:diamond_block
fill 79 270 564 81 270 564 minecraft:diamond_block
fill 79 270 569 81 270 569 minecraft:diamond_block
fill 79 270 597 80 270 597 minecraft:cobbled_deepslate
setblock 80 270 558 minecraft:calcite
setblock 80 270 598 minecraft:calcite
setblock 81 270 558 minecraft:cobbled_deepslate
fill 81 270 565 82 271 565 minecraft:diamond_block
fill 81 270 568 82 271 568 minecraft:diamond_block
fill 81 270 598 81 273 598 minecraft:cobbled_deepslate
fill 82 270 566 82 271 567 minecraft:diamond_block
setblock 86 270 567 minecraft:calcite
fill 86 270 568 86 272 568 minecraft:cobbled_deepslate
fill 86 270 570 86 270 571 minecraft:cobbled_deepslate
setblock 86 270 572 minecraft:calcite
setblock 86 270 587 minecraft:calcite
setblock 86 270 588 minecraft:cobbled_deepslate
setblock 87 270 566 minecraft:calcite
fill 87 270 567 87 273 567 minecraft:cobbled_deepslate
setblock 87 270 570 minecraft:cobbled_deepslate
setblock 87 270 571 minecraft:calcite
fill 87 270 572 87 273 572 minecraft:cobbled_deepslate
setblock 87 270 582 minecraft:cobbled_deepslate
setblock 87 270 586 minecraft:calcite
fill 87 270 587 87 271 587 minecraft:cobbled_deepslate
setblock 87 270 591 minecraft:calcite
setblock 88 270 561 minecraft:cobbled_deepslate
setblock 88 270 565 minecraft:calcite
fill 88 270 566 88 273 566 minecraft:cobbled_deepslate
setblock 88 270 570 minecraft:calcite
fill 88 270 571 88 273 571 minecraft:cobbled_deepslate
setblock 88 270 575 minecraft:calcite
fill 88 270 576 88 273 576 minecraft:cobbled_deepslate
setblock 88 270 580 minecraft:calcite
fill 88 270 581 88 271 581 minecraft:cobbled_deepslate
setblock 88 270 585 minecraft:calcite
fill 88 270 586 88 272 586 minecraft:cobbled_deepslate
setblock 88 270 590 minecraft:calcite
fill 88 270 591 88 272 591 minecraft:cobbled_deepslate
setblock 48 271 560 minecraft:cobbled_deepslate
setblock 48 271 564 minecraft:calcite
fill 48 271 565 48 273 565 minecraft:cobbled_deepslate
setblock 48 271 569 minecraft:calcite
fill 48 271 570 48 273 570 minecraft:cobbled_deepslate
setblock 48 271 574 minecraft:calcite
setblock 48 271 589 minecraft:calcite
setblock 48 271 590 minecraft:cobbled_deepslate
setblock 49 271 563 minecraft:calcite
fill 49 271 564 49 272 564 minecraft:cobbled_deepslate
setblock 49 271 568 minecraft:calcite
fill 49 271 569 49 273 569 minecraft:cobbled_deepslate
setblock 54 271 558 minecraft:calcite
fill 55 271 558 55 273 558 minecraft:cobbled_deepslate
fill 55 271 598 55 273 598 minecraft:cobbled_deepslate
setblock 58 271 559 minecraft:calcite
setblock 58 271 560 minecraft:cobbled_deepslate
setblock 59 271 558 minecraft:calcite
fill 59 271 559 59 273 559 minecraft:cobbled_deepslate
fill 59 271 596 60 271 596 minecraft:cobbled_deepslate
setblock 59 271 598 minecraft:calcite
fill 60 271 558 60 273 558 minecraft:cobbled_deepslate
setblock 60 271 597 minecraft:calcite
fill 60 271 598 60 273 598 minecraft:cobbled_deepslate
setblock 61 271 596 minecraft:calcite
fill 61 271 597 61 273 597 minecraft:cobbled_deepslate
fill 62 271 596 62 273 596 minecraft:cobbled_deepslate
setblock 63 271 559 minecraft:calcite
setblock 64 271 558 minecraft:calcite
setblock 64 271 598 minecraft:calcite
setblock 65 271 558 minecraft:cobbled_deepslate
setblock 65 271 597 minecraft:calcite
fill 65 271 598 65 273 598 minecraft:cobbled_deepslate
setblock 66 271 597 minecraft:cobbled_deepslate
fill 75 271 598 75 273 598 minecraft:cobbled_deepslate
fill 77 271 566 77 271 567 minecraft:diamond_block
fill 78 271 565 78 272 565 minecraft:diamond_block
fill 78 271 568 78 272 568 minecraft:diamond_block
fill 79 271 564 80 271 564 minecraft:diamond_block
fill 79 271 569 80 271 569 minecraft:diamond_block
setblock 79 271 597 minecraft:cobbled_deepslate
setblock 79 271 598 minecraft:calcite
setblock 80 271 597 minecraft:calcite
fill 80 271 598 80 273 598 minecraft:cobbled_deepslate
setblock 86 271 567 minecraft:cobbled_deepslate
setblock 86 271 570 minecraft:cobbled_deepslate
setblock 86 271 571 minecraft:calcite
setblock 86 271 572 minecraft:cobbled_deepslate
setblock 87 271 565 minecraft:calcite
fill 87 271 566 87 272 566 minecraft:cobbled_deepslate
setblock 87 271 570 minecraft:calcite
fill 87 271 571 87 273 571 minecraft:cobbled_deepslate
setblock 87 271 585 minecraft:calcite
setblock 87 271 586 minecraft:cobbled_deepslate
setblock 87 271 590 minecraft:calcite
setblock 88 271 564 minecraft:calcite
fill 88 271 565 88 273 565 minecraft:cobbled_deepslate
setblock 88 271 569 minecraft:calcite
fill 88 271 570 88 273 570 minecraft:cobbled_deepslate
setblock 88 271 574 minecraft:calcite
fill 88 271 575 88 273 575 minecraft:cobbled_deepslate
setblock 88 271 584 minecraft:calcite
fill 88 271 585 88 272 585 minecraft:cobbled_deepslate
setblock 88 271 589 minecraft:calcite
fill 88 271 590 88 272 590 minecraft:cobbled_deepslate
setblock 48 272 563 minecraft:calcite
fill 48 272 564 48 273 564 minecraft:cobbled_deepslate
setblock 48 272 568 minecraft:calcite
fill 48 272 569 48 273 569 minecraft:cobbled_deepslate
setblock 48 272 573 minecraft:calcite
setblock 48 272 574 minecraft:cobbled_deepslate
setblock 49 272 567 minecraft:calcite
fill 49 272 568 49 273 568 minecraft:cobbled_deepslate
setblock 50 272 560 minecraft:light[level=14]
setblock 50 272 568 minecraft:light[level=14]
setblock 50 272 576 minecraft:light[level=14]
setblock 50 272 584 minecraft:light[level=14]
setblock 50 272 592 minecraft:light[level=14]
setblock 53 272 558 minecraft:calcite
fill 54 272 558 54 273 558 minecraft:cobbled_deepslate
fill 54 272 598 54 273 598 minecraft:cobbled_deepslate
fill 56 272 597 56 273 597 minecraft:cobbled_deepslate
setblock 57 272 559 minecraft:calcite
setblock 58 272 558 minecraft:calcite
fill 58 272 559 58 273 559 minecraft:cobbled_deepslate
setblock 58 272 560 minecraft:light[level=14]
setblock 58 272 568 minecraft:light[level=14]
setblock 58 272 576 minecraft:light[level=14]
setblock 58 272 584 minecraft:light[level=14]
setblock 58 272 592 minecraft:light[level=14]
fill 58 272 596 59 272 596 minecraft:cobbled_deepslate
setblock 58 272 598 minecraft:calcite
fill 59 272 558 59 273 558 minecraft:cobbled_deepslate
setblock 59 272 597 minecraft:calcite
fill 59 272 598 59 273 598 minecraft:cobbled_deepslate
setblock 60 272 596 minecraft:calcite
fill 60 272 597 60 273 597 minecraft:cobbled_deepslate
fill 61 272 596 61 273 596 minecraft:cobbled_deepslate
setblock 62 272 559 minecraft:calcite
setblock 63 272 558 minecraft:calcite
setblock 63 272 598 minecraft:calcite
setblock 64 272 558 minecraft:cobbled_deepslate
setblock 64 272 597 minecraft:calcite
fill 64 272 598 64 273 598 minecraft:cobbled_deepslate
fill 65 272 597 65 273 597 minecraft:cobbled_deepslate
setblock 66 272 560 minecraft:light[level=14]
setblock 66 272 568 minecraft:light[level=14]
setblock 66 272 576 minecraft:light[level=14]
setblock 66 272 584 minecraft:light[level=14]
setblock 66 272 592 minecraft:light[level=14]
setblock 74 272 560 minecraft:light[level=14]
setblock 74 272 568 minecraft:light[level=14]
setblock 74 272 576 minecraft:light[level=14]
setblock 74 272 584 minecraft:light[level=14]
setblock 74 272 592 minecraft:light[level=14]
setblock 78 272 598 minecraft:calcite
fill 79 272 598 79 273 598 minecraft:cobbled_deepslate
setblock 81 272 565 minecraft:diamond_block
setblock 81 272 568 minecraft:diamond_block
setblock 82 272 560 minecraft:light[level=14]
setblock 82 272 568 minecraft:light[level=14]
setblock 82 272 576 minecraft:light[level=14]
setblock 82 272 584 minecraft:light[level=14]
setblock 82 272 592 minecraft:light[level=14]
setblock 86 272 570 minecraft:calcite
setblock 86 272 571 minecraft:cobbled_deepslate
setblock 87 272 565 minecraft:cobbled_deepslate
setblock 87 272 569 minecraft:calcite
fill 87 272 570 87 273 570 minecraft:cobbled_deepslate
setblock 87 272 574 minecraft:calcite
setblock 88 272 563 minecraft:calcite
fill 88 272 564 88 273 564 minecraft:cobbled_deepslate
setblock 88 272 568 minecraft:calcite
fill 88 272 569 88 273 569 minecraft:cobbled_deepslate
setblock 88 272 573 minecraft:calcite
fill 88 272 574 88 273 574 minecraft:cobbled_deepslate
setblock 88 272 588 minecraft:calcite
setblock 88 272 589 minecraft:cobbled_deepslate
setblock 48 273 563 minecraft:cobbled_deepslate
setblock 48 273 567 minecraft:calcite
setblock 48 273 568 minecraft:cobbled_deepslate
setblock 48 273 572 minecraft:calcite
setblock 48 273 573 minecraft:cobbled_deepslate
setblock 49 273 566 minecraft:calcite
setblock 49 273 567 minecraft:cobbled_deepslate
setblock 53 273 558 minecraft:cobbled_deepslate
setblock 55 273 597 minecraft:cobbled_deepslate
setblock 56 273 559 minecraft:calcite
setblock 57 273 558 minecraft:calcite
setblock 57 273 559 minecraft:cobbled_deepslate
setblock 57 273 598 minecraft:calcite
setblock 58 273 558 minecraft:cobbled_deepslate
setblock 58 273 596 minecraft:cobbled_deepslate
setblock 58 273 597 minecraft:calcite
setblock 58 273 598 minecraft:cobbled_deepslate
setblock 59 273 596 minecraft:calcite
setblock 59 273 597 minecraft:cobbled_deepslate
setblock 60 273 596 minecraft:cobbled_deepslate
setblock 62 273 558 minecraft:calcite
setblock 62 273 598 minecraft:calcite
setblock 63 273 558 minecraft:cobbled_deepslate
setblock 63 273 597 minecraft:calcite
setblock 63 273 598 minecraft:cobbled_deepslate
setblock 64 273 597 minecraft:cobbled_deepslate
setblock 67 273 598 minecraft:calcite
setblock 74 273 598 minecraft:cobbled_deepslate
setblock 77 273 598 minecraft:calcite
setblock 78 273 598 minecraft:cobbled_deepslate
setblock 87 273 568 minecraft:calcite
setblock 87 273 569 minecraft:cobbled_deepslate
setblock 87 273 573 minecraft:calcite
setblock 88 273 567 minecraft:calcite
setblock 88 273 568 minecraft:cobbled_deepslate
setblock 88 273 572 minecraft:calcite
setblock 88 273 573 minecraft:cobbled_deepslate
fill 47 279 568 47 307 568 minecraft:deepslate
fill 47 279 569 62 279 585 minecraft:smooth_basalt
fill 47 279 586 47 307 586 minecraft:deepslate
fill 48 279 567 82 279 568 minecraft:smooth_basalt
fill 48 279 586 82 279 587 minecraft:smooth_basalt
fill 49 279 565 81 279 566 minecraft:smooth_basalt
fill 49 279 588 81 279 589 minecraft:smooth_basalt
fill 50 279 564 80 279 564 minecraft:smooth_basalt
fill 50 279 590 80 279 590 minecraft:smooth_basalt
fill 51 279 563 79 279 563 minecraft:smooth_basalt
fill 51 279 591 79 279 591 minecraft:smooth_basalt
fill 52 279 562 78 279 562 minecraft:smooth_basalt
fill 52 279 592 78 279 592 minecraft:smooth_basalt
fill 53 279 561 77 279 561 minecraft:smooth_basalt
fill 53 279 593 77 279 593 minecraft:smooth_basalt
fill 55 279 560 75 279 560 minecraft:smooth_basalt
fill 55 279 594 75 279 594 minecraft:smooth_basalt
fill 57 279 559 73 279 559 minecraft:smooth_basalt
fill 57 279 595 73 279 595 minecraft:smooth_basalt
fill 59 279 558 71 279 558 minecraft:smooth_basalt
fill 59 279 596 71 279 596 minecraft:smooth_basalt
fill 62 279 557 64 307 557 minecraft:deepslate
fill 63 279 569 63 279 576 minecraft:smooth_basalt
fill 63 279 578 63 279 585 minecraft:smooth_basalt
fill 64 279 569 64 279 575 minecraft:smooth_basalt
fill 64 279 579 64 279 585 minecraft:smooth_basalt
fill 65 279 557 65 286 557 minecraft:smooth_basalt
fill 65 279 569 83 279 574 minecraft:smooth_basalt
fill 65 279 580 83 279 585 minecraft:smooth_basalt
fill 65 279 597 65 286 597 minecraft:smooth_basalt
fill 66 279 575 84 279 575 minecraft:smooth_basalt
fill 66 279 579 84 279 579 minecraft:smooth_basalt
fill 67 279 576 84 279 576 minecraft:smooth_basalt
fill 67 279 578 84 279 578 minecraft:smooth_basalt
fill 68 279 577 85 279 577 minecraft:smooth_basalt
fill 84 279 571 84 286 574 minecraft:smooth_basalt
fill 84 279 580 84 286 583 minecraft:smooth_basalt
fill 47 280 569 47 286 574 minecraft:smooth_basalt
fill 47 280 575 47 286 575 minecraft:calcite
fill 47 280 576 47 286 583 minecraft:smooth_basalt
fill 47 280 584 47 286 584 minecraft:calcite
fill 47 280 585 65 282 585 minecraft:smooth_basalt
fill 48 280 558 48 280 566 minecraft:deepslate
fill 48 280 567 49 286 573 minecraft:smooth_basalt
fill 48 280 574 49 286 574 minecraft:calcite
fill 48 280 575 48 286 582 minecraft:smooth_basalt
fill 48 280 583 48 287 583 minecraft:calcite
fill 48 280 584 53 285 584 minecraft:smooth_basalt
fill 48 280 586 52 286 587 minecraft:smooth_basalt
fill 48 280 588 48 280 598 minecraft:deepslate
fill 49 280 558 49 280 564 minecraft:deepslate
fill 49 280 565 60 284 566 minecraft:smooth_basalt
fill 49 280 575 49 286 580 minecraft:smooth_basalt
fill 49 280 581 49 286 581 minecraft:calcite
fill 49 280 582 54 284 583 minecraft:smooth_basalt
fill 49 280 588 51 286 589 minecraft:smooth_basalt
fill 49 280 590 49 280 598 minecraft:deepslate
fill 50 280 558 50 280 563 minecraft:deepslate
fill 50 280 564 59 285 564 minecraft:smooth_basalt
fill 50 280 567 52 286 567 minecraft:calcite
fill 50 280 568 50 285 579 minecraft:smooth_basalt
fill 50 280 580 50 285 580 minecraft:calcite
fill 50 280 581 55 284 581 minecraft:smooth_basalt
fill 50 280 590 51 286 590 minecraft:smooth_basalt
fill 50 280 591 50 280 598 minecraft:deepslate
fill 51 280 558 51 280 562 minecraft:deepslate
fill 51 280 563 65 285 563 minecraft:smooth_basalt
fill 51 280 568 55 284 572 minecraft:smooth_basalt
fill 51 280 573 52 285 573 minecraft:calcite
fill 51 280 574 52 284 578 minecraft:smooth_basalt
fill 51 280 579 51 285 579 minecraft:calcite
fill 51 280 580 56 283 580 minecraft:smooth_basalt
fill 51 280 591 51 286 591 minecraft:smooth_basalt
fill 51 280 592 51 280 598 minecraft:deepslate
fill 52 280 558 52 280 561 minecraft:deepslate
fill 52 280 562 55 286 562 minecraft:smooth_basalt
fill 52 280 579 60 281 579 minecraft:smooth_basalt
fill 52 280 588 57 285 588 minecraft:smooth_basalt
fill 52 280 589 52 286 592 minecraft:calcite
fill 52 280 593 52 280 598 minecraft:deepslate
fill 53 280 558 54 280 560 minecraft:deepslate
fill 53 280 561 54 286 561 minecraft:calcite
fill 53 280 567 62 283 567 minecraft:smooth_basalt
fill 53 280 573 57 282 577 minecraft:smooth_basalt
fill 53 280 578 53 284 578 minecraft:calcite
fill 53 280 586 53 285 586 minecraft:calcite
fill 53 280 587 57 284 587 minecraft:smooth_basalt
fill 53 280 589 57 285 593 minecraft:smooth_basalt
fill 53 280 594 54 280 598 minecraft:deepslate
fill 54 280 578 59 282 578 minecraft:smooth_basalt
fill 54 280 584 54 284 584 minecraft:calcite
fill 54 280 586 72 283 586 minecraft:smooth_basalt
fill 55 280 558 56 280 559 minecraft:deepslate
fill 55 280 560 63 286 561 minecraft:smooth_basalt
fill 55 280 582 55 284 582 minecraft:calcite
fill 55 280 583 83 282 584 minecraft:smooth_basalt
fill 55 280 594 58 286 594 minecraft:smooth_basalt
fill 55 280 595 56 280 598 minecraft:deepslate
fill 56 280 562 57 286 562 minecraft:calcite
fill 56 280 568 57 284 568 minecraft:calcite
fill 56 280 569 58 283 572 minecraft:smooth_basalt
fill 56 280 581 56 283 581 minecraft:calcite
fill 56 280 582 63 281 582 minecraft:smooth_basalt
fill 57 280 558 58 280 558 minecraft:deepslate
fill 57 280 559 62 286 559 minecraft:smooth_basalt
fill 57 280 580 57 283 580 minecraft:calcite
fill 57 280 581 61 281 581 minecraft:smooth_basalt
fill 57 280 595 58 286 595 minecraft:smooth_basalt
fill 57 280 596 58 280 598 minecraft:deepslate
fill 58 280 562 77 285 562 minecraft:smooth_basalt
fill 58 280 568 76 283 568 minecraft:smooth_basalt
fill 58 280 573 58 282 575 minecraft:smooth_basalt
fill 58 280 576 58 282 576 minecraft:calcite
fill 58 280 577 59 282 577 minecraft:smooth_basalt
fill 58 280 580 60 282 580 minecraft:smooth_basalt
fill 58 280 587 58 284 591 minecraft:calcite
fill 58 280 592 64 285 593 minecraft:smooth_basalt
fill 59 280 558 61 286 558 minecraft:smooth_basalt
fill 59 280 569 59 283 569 minecraft:calcite
fill 59 280 570 63 281 572 minecraft:smooth_basalt
fill 59 280 573 59 282 573 minecraft:calcite
fill 59 280 574 59 282 576 minecraft:smooth_basalt
fill 59 280 587 62 283 591 minecraft:smooth_basalt
fill 59 280 594 59 286 595 minecraft:calcite
fill 59 280 596 67 286 596 minecraft:smooth_basalt
fill 59 280 597 64 280 598 minecraft:deepslate
fill 60 280 564 60 285 564 minecraft:calcite
fill 60 280 569 63 282 569 minecraft:smooth_basalt
fill 60 280 573 60 281 575 minecraft:smooth_basalt
fill 60 280 576 61 281 578 minecraft:diamond_block
fill 60 280 594 65 286 595 minecraft:smooth_basalt
fill 61 280 564 71 284 564 minecraft:smooth_basalt
fill 61 280 565 61 284 565 minecraft:calcite
fill 61 280 566 61 284 566 minecraft:smooth_basalt
fill 61 280 573 61 281 573 minecraft:smooth_basalt
fill 61 280 574 62 281 575 minecraft:diamond_block
fill 61 280 579 62 281 580 minecraft:diamond_block
fill 62 280 558 62 286 558 minecraft:calcite
fill 62 280 565 66 284 565 minecraft:smooth_basalt
fill 62 280 566 62 284 566 minecraft:calcite
fill 62 280 573 68 281 573 minecraft:diamond_block
fill 62 280 576 62 280 578 minecraft:sea_lantern
fill 62 280 581 68 281 581 minecraft:diamond_block
fill 63 280 558 71 286 558 minecraft:smooth_basalt
fill 63 280 559 63 286 559 minecraft:calcite
fill 63 280 566 66 284 566 minecraft:smooth_basalt
fill 63 280 567 63 283 567 minecraft:calcite
fill 63 280 574 63 281 574 minecraft:diamond_block
fill 63 280 575 63 280 576 minecraft:sea_lantern
fill 63 280 578 63 280 579 minecraft:sea_lantern
fill 63 280 580 63 281 580 minecraft:diamond_block
fill 63 280 587 66 283 587 minecraft:smooth_basalt
fill 63 280 588 63 284 589 minecraft:calcite
fill 63 280 590 63 284 591 minecraft:smooth_basalt
fill 64 280 559 70 286 559 minecraft:smooth_basalt
fill 64 280 560 64 286 560 minecraft:calcite
fill 64 280 561 64 286 561 minecraft:smooth_basalt
fill 64 280 567 71 283 567 minecraft:smooth_basalt
fill 64 280 569 64 282 569 minecraft:calcite
fill 64 280 570 75 282 571 minecraft:smooth_basalt
fill 64 280 572 66 281 572 minecraft:diamond_block
fill 64 280 574 64 280 575 minecraft:sea_lantern
fill 64 280 579 64 280 580 minecraft:sea_lantern
fill 64 280 582 66 281 582 minecraft:diamond_block
fill 64 280 588 67 284 590 minecraft:smooth_basalt
fill 64 280 591 64 285 591 minecraft:calcite
fill 65 280 560 70 286 560 minecraft:smooth_basalt
fill 65 280 561 65 286 561 minecraft:calcite
fill 65 280 569 83 282 569 minecraft:smooth_basalt
fill 65 280 574 66 280 574 minecraft:sea_lantern
fill 65 280 580 66 280 580 minecraft:sea_lantern
fill 65 280 591 72 285 592 minecraft:smooth_basalt
fill 65 280 593 65 286 593 minecraft:calcite
fill 65 280 598 88 280 598 minecraft:deepslate
fill 66 280 561 77 286 561 minecraft:smooth_basalt
fill 66 280 563 66 285 563 minecraft:calcite
fill 66 280 575 67 280 575 minecraft:sea_lantern
fill 66 280 579 67 280 579 minecraft:sea_lantern
fill 66 280 585 66 282 585 minecraft:calcite
fill 66 280 593 75 286 593 minecraft:smooth_basalt
fill 66 280 594 66 286 594 minecraft:calcite
fill 66 280 595 66 286 595 minecraft:smooth_basalt
fill 66 280 597 88 280 597 minecraft:deepslate
fill 67 280 563 71 285 563 minecraft:smooth_basalt
fill 67 280 565 67 284 566 minecraft:calcite
fill 67 280 572 74 281 572 minecraft:smooth_basalt
fill 67 280 574 69 281 574 minecraft:diamond_block
fill 67 280 576 68 280 576 minecraft:sea_lantern
fill 67 280 578 68 280 578 minecraft:sea_lantern
fill 67 280 580 69 281 580 minecraft:diamond_block
fill 67 280 582 83 281 582 minecraft:smooth_basalt
fill 67 280 585 70 282 585 minecraft:smooth_basalt
fill 67 280 587 67 283 587 minecraft:calcite
fill 67 280 594 75 286 594 minecraft:smooth_basalt
fill 67 280 595 67 286 595 minecraft:calcite
fill 68 280 565 71 284 566 minecraft:smooth_basalt
fill 68 280 575 69 281 575 minecraft:diamond_block
setblock 68 280 577 minecraft:sea_lantern
fill 68 280 579 69 281 579 minecraft:diamond_block
fill 68 280 587 77 283 587 minecraft:smooth_basalt
fill 68 280 588 68 284 588 minecraft:calcite
fill 68 280 589 68 284 590 minecraft:smooth_basalt
fill 68 280 595 73 286 595 minecraft:smooth_basalt
fill 68 280 596 68 286 596 minecraft:calcite
fill 69 280 573 73 281 573 minecraft:smooth_basalt
fill 69 280 576 70 281 578 minecraft:diamond_block
fill 69 280 581 70 281 581 minecraft:smooth_basalt
fill 69 280 588 81 284 588 minecraft:smooth_basalt
fill 69 280 589 69 284 589 minecraft:calcite
fill 69 280 590 69 285 590 minecraft:smooth_basalt
fill 69 280 596 71 286 596 minecraft:smooth_basalt
fill 70 280 574 72 281 575 minecraft:smooth_basalt
fill 70 280 579 80 281 580 minecraft:smooth_basalt
fill 70 280 589 81 284 589 minecraft:smooth_basalt
fill 70 280 590 70 285 590 minecraft:calcite
fill 71 280 559 71 286 560 minecraft:calcite
fill 71 280 576 71 282 578 minecraft:smooth_basalt
fill 71 280 581 71 282 581 minecraft:calcite
fill 71 280 585 71 283 585 minecraft:calcite
fill 71 280 590 80 285 590 minecraft:smooth_basalt
fill 72 280 558 88 280 558 minecraft:deepslate
fill 72 280 559 73 286 560 minecraft:smooth_basalt
fill 72 280 563 72 284 567 minecraft:calcite
fill 72 280 576 76 282 577 minecraft:smooth_basalt
fill 72 280 578 72 282 578 minecraft:calcite
fill 72 280 581 77 282 581 minecraft:smooth_basalt
fill 72 280 585 83 283 585 minecraft:smooth_basalt
fill 72 280 596 88 280 596 minecraft:deepslate
fill 73 280 563 77 284 567 minecraft:smooth_basalt
fill 73 280 574 73 283 574 minecraft:calcite
fill 73 280 575 78 282 575 minecraft:smooth_basalt
fill 73 280 578 84 282 578 minecraft:smooth_basalt
fill 73 280 586 74 284 586 minecraft:calcite
fill 73 280 591 79 286 591 minecraft:smooth_basalt
fill 73 280 592 74 286 592 minecraft:calcite
fill 74 280 559 88 280 559 minecraft:deepslate
fill 74 280 560 75 286 560 minecraft:smooth_basalt
fill 74 280 573 74 283 573 minecraft:calcite
fill 74 280 574 79 283 574 minecraft:smooth_basalt
fill 74 280 595 88 280 595 minecraft:deepslate
fill 75 280 572 75 284 572 minecraft:calcite
fill 75 280 573 80 284 573 minecraft:smooth_basalt
fill 75 280 586 82 285 586 minecraft:smooth_basalt
fill 75 280 592 78 286 592 minecraft:smooth_basalt
fill 76 280 560 88 280 560 minecraft:deepslate
fill 76 280 570 76 284 570 minecraft:calcite
fill 76 280 571 81 284 572 minecraft:smooth_basalt
fill 76 280 593 77 286 593 minecraft:calcite
fill 76 280 594 88 280 594 minecraft:deepslate
fill 77 280 568 77 285 568 minecraft:calcite
fill 77 280 570 82 285 570 minecraft:smooth_basalt
fill 77 280 576 77 284 576 minecraft:calcite
fill 77 280 577 85 284 577 minecraft:smooth_basalt
fill 78 280 561 88 280 561 minecraft:deepslate
fill 78 280 562 78 286 565 minecraft:calcite
fill 78 280 566 81 286 568 minecraft:smooth_basalt
fill 78 280 576 84 284 576 minecraft:smooth_basalt
fill 78 280 581 79 285 581 minecraft:calcite
fill 78 280 587 80 286 587 minecraft:calcite
fill 78 280 593 88 280 593 minecraft:deepslate
fill 79 280 562 88 280 562 minecraft:deepslate
fill 79 280 563 79 286 565 minecraft:smooth_basalt
fill 79 280 575 79 285 575 minecraft:calcite
fill 79 280 592 88 280 592 minecraft:deepslate
fill 80 280 563 88 280 563 minecraft:deepslate
fill 80 280 564 80 286 565 minecraft:smooth_basalt
fill 80 280 574 80 285 574 minecraft:calcite
fill 80 280 575 84 285 575 minecraft:smooth_basalt
fill 80 280 581 83 285 581 minecraft:smooth_basalt
fill 80 280 591 88 280 591 minecraft:deepslate
fill 81 280 564 88 280 564 minecraft:deepslate
fill 81 280 565 81 286 565 minecraft:smooth_basalt
fill 81 280 573 81 286 573 minecraft:calcite
fill 81 280 574 83 286 574 minecraft:smooth_basalt
fill 81 280 579 82 286 579 minecraft:smooth_basalt
fill 81 280 580 82 286 580 minecraft:calcite
fill 81 280 587 82 286 587 minecraft:smooth_basalt
fill 81 280 590 88 280 590 minecraft:deepslate
fill 82 280 565 88 280 566 minecraft:deepslate
fill 82 280 567 82 286 568 minecraft:smooth_basalt
fill 82 280 571 82 286 571 minecraft:calcite
fill 82 280 572 83 286 573 minecraft:smooth_basalt
fill 82 280 588 88 280 589 minecraft:deepslate
fill 83 280 567 88 280 568 minecraft:deepslate
fill 83 280 570 83 286 570 minecraft:calcite
fill 83 280 571 83 286 571 minecraft:smooth_basalt
fill 83 280 579 83 286 579 minecraft:calcite
fill 83 280 580 83 286 580 minecraft:smooth_basalt
fill 83 280 586 88 280 587 minecraft:deepslate
fill 84 280 569 88 280 570 minecraft:deepslate
fill 84 280 579 84 286 579 minecraft:smooth_basalt
fill 84 280 584 88 280 585 minecraft:deepslate
fill 85 280 571 88 280 576 minecraft:deepslate
fill 85 280 578 88 280 583 minecraft:deepslate
fill 86 280 577 88 280 577 minecraft:deepslate
fill 52 282 579 59 282 579 minecraft:smooth_basalt
fill 56 282 582 62 282 582 minecraft:smooth_basalt
fill 57 282 581 60 282 581 minecraft:smooth_basalt
fill 59 282 570 62 282 572 minecraft:smooth_basalt
fill 60 282 573 60 282 574 minecraft:smooth_basalt
fill 63 282 570 63 282 571 minecraft:smooth_basalt
fill 68 282 572 74 282 572 minecraft:smooth_basalt
fill 68 282 582 83 282 582 minecraft:smooth_basalt
fill 70 282 573 72 282 574 minecraft:smooth_basalt
fill 70 282 580 70 282 581 minecraft:smooth_basalt
fill 71 282 575 72 282 575 minecraft:smooth_basalt
fill 71 282 579 80 282 580 minecraft:smooth_basalt
fill 73 282 573 73 283 573 minecraft:smooth_basalt
fill 47 283 585 62 283 585 minecraft:smooth_basalt
fill 52 283 579 56 283 579 minecraft:smooth_basalt
fill 53 283 573 56 283 577 minecraft:smooth_basalt
fill 54 283 578 56 283 578 minecraft:smooth_basalt
fill 55 283 583 59 283 584 minecraft:smooth_basalt
fill 56 283 582 58 283 582 minecraft:smooth_basalt
fill 57 283 573 57 283 574 minecraft:smooth_basalt
setblock 57 283 581 minecraft:smooth_basalt
fill 59 283 570 59 283 571 minecraft:smooth_basalt
fill 60 283 569 60 283 570 minecraft:smooth_basalt
setblock 60 283 584 minecraft:smooth_basalt
fill 61 283 569 62 283 569 minecraft:smooth_basalt
fill 68 283 569 83 283 569 minecraft:smooth_basalt
fill 68 283 585 70 283 585 minecraft:smooth_basalt
fill 70 283 570 75 283 570 minecraft:smooth_basalt
fill 70 283 584 83 283 584 minecraft:smooth_basalt
fill 71 283 571 75 283 571 minecraft:smooth_basalt
fill 71 283 583 83 283 583 minecraft:smooth_basalt
fill 72 283 572 74 283 572 minecraft:smooth_basalt
fill 72 283 582 83 283 582 minecraft:smooth_basalt
fill 73 283 580 77 283 581 minecraft:smooth_basalt
fill 74 283 575 76 283 579 minecraft:smooth_basalt
fill 77 283 575 78 284 575 minecraft:smooth_basalt
fill 77 283 578 80 284 579 minecraft:smooth_basalt
fill 78 283 580 80 285 580 minecraft:smooth_basalt
fill 81 283 578 84 286 578 minecraft:smooth_basalt
fill 47 284 585 57 284 585 minecraft:smooth_basalt
fill 48 284 558 48 284 560 minecraft:cobbled_deepslate
setblock 48 284 561 minecraft:calcite
fill 48 284 562 48 284 565 minecraft:cobbled_deepslate
setblock 48 284 566 minecraft:calcite
setblock 48 284 591 minecraft:calcite
fill 48 284 592 48 284 595 minecraft:cobbled_deepslate
setblock 48 284 596 minecraft:calcite
fill 48 284 597 50 284 598 minecraft:cobbled_deepslate
fill 49 284 558 49 284 559 minecraft:cobbled_deepslate
setblock 49 284 560 minecraft:calcite
fill 49 284 561 49 284 564 minecraft:cobbled_deepslate
fill 49 284 592 49 284 594 minecraft:cobbled_deepslate
setblock 49 284 595 minecraft:calcite
fill 49 284 596 52 284 596 minecraft:cobbled_deepslate
setblock 50 284 558 minecraft:cobbled_deepslate
setblock 50 284 559 minecraft:calcite
fill 50 284 560 50 285 562 minecraft:cobbled_deepslate
setblock 50 284 594 minecraft:calcite
fill 50 284 595 53 284 595 minecraft:cobbled_deepslate
setblock 51 284 558 minecraft:calcite
fill 51 284 559 53 284 560 minecraft:cobbled_deepslate
fill 51 284 580 54 284 580 minecraft:smooth_basalt
setblock 51 284 597 minecraft:cobbled_deepslate
setblock 51 284 598 minecraft:calcite
fill 52 284 558 55 284 558 minecraft:cobbled_deepslate
fill 52 284 579 54 284 579 minecraft:smooth_basalt
setblock 52 284 597 minecraft:calcite
fill 52 284 598 55 284 598 minecraft:cobbled_deepslate
fill 53 284 567 61 284 567 minecraft:smooth_basalt
fill 53 284 573 54 284 577 minecraft:smooth_basalt
setblock 53 284 596 minecraft:calcite
fill 53 284 597 56 284 597 minecraft:cobbled_deepslate
setblock 54 284 559 minecraft:cobbled_deepslate
setblock 54 284 560 minecraft:calcite
setblock 54 284 578 minecraft:smooth_basalt
fill 54 284 586 59 284 586 minecraft:smooth_basalt
setblock 54 284 595 minecraft:calcite
fill 54 284 596 57 284 596 minecraft:cobbled_deepslate
setblock 55 284 559 minecraft:calcite
setblock 55 284 573 minecraft:smooth_basalt
fill 55 284 583 56 284 584 minecraft:smooth_basalt
fill 55 284 595 56 284 595 minecraft:cobbled_deepslate
setblock 56 284 558 minecraft:calcite
fill 56 284 559 56 287 559 minecraft:cobbled_deepslate
fill 56 284 569 56 284 571 minecraft:smooth_basalt
setblock 56 284 598 minecraft:calcite
fill 57 284 558 58 286 558 minecraft:cobbled_deepslate
setblock 57 284 569 minecraft:smooth_basalt
setblock 57 284 597 minecraft:calcite
fill 57 284 598 60 284 598 minecraft:cobbled_deepslate
fill 58 284 568 59 284 568 minecraft:smooth_basalt
setblock 58 284 596 minecraft:calcite
fill 58 284 597 61 284 597 minecraft:cobbled_deepslate
fill 59 284 587 61 284 591 minecraft:smooth_basalt
setblock 61 284 598 minecraft:calcite
fill 62 284 588 62 284 591 minecraft:smooth_basalt
setblock 62 284 597 minecraft:calcite
fill 62 284 598 65 284 598 minecraft:cobbled_deepslate
fill 63 284 597 64 286 597 minecraft:cobbled_deepslate
fill 64 284 567 64 285 567 minecraft:light_blue_stained_glass
setblock 66 284 597 minecraft:cobbled_deepslate
setblock 66 284 598 minecraft:calcite
setblock 67 284 597 minecraft:calcite
fill 67 284 598 70 284 598 minecraft:cobbled_deepslate
fill 68 284 597 71 284 597 minecraft:cobbled_deepslate
fill 69 284 567 71 284 567 minecraft:smooth_basalt
fill 69 284 587 77 284 587 minecraft:smooth_basalt
fill 71 284 568 76 284 568 minecraft:smooth_basalt
fill 71 284 586 72 284 586 minecraft:smooth_basalt
setblock 71 284 598 minecraft:calcite
fill 72 284 558 75 284 558 minecraft:cobbled_deepslate
setblock 72 284 596 minecraft:cobbled_deepslate
setblock 72 284 597 minecraft:calcite
fill 72 284 598 75 284 598 minecraft:cobbled_deepslate
fill 73 284 569 83 284 569 minecraft:smooth_basalt
fill 73 284 585 83 284 585 minecraft:smooth_basalt
setblock 73 284 596 minecraft:calcite
fill 73 284 597 76 284 597 minecraft:cobbled_deepslate
setblock 74 284 559 minecraft:cobbled_deepslate
fill 74 284 570 75 284 571 minecraft:smooth_basalt
fill 74 284 583 83 284 584 minecraft:smooth_basalt
fill 74 284 596 75 284 596 minecraft:cobbled_deepslate
setblock 75 284 559 minecraft:calcite
fill 75 284 581 77 284 582 minecraft:smooth_basalt
setblock 76 284 558 minecraft:calcite
fill 76 284 559 79 284 559 minecraft:cobbled_deepslate
fill 76 284 574 76 284 580 minecraft:smooth_basalt
setblock 76 284 598 minecraft:calcite
fill 77 284 558 80 284 558 minecraft:cobbled_deepslate
fill 77 284 574 79 284 574 minecraft:smooth_basalt
setblock 77 284 580 minecraft:smooth_basalt
setblock 77 284 597 minecraft:calcite
fill 77 284 598 80 284 598 minecraft:cobbled_deepslate
fill 78 284 582 83 285 582 minecraft:smooth_basalt
setblock 78 284 597 minecraft:cobbled_deepslate
setblock 81 284 558 minecraft:calcite
setblock 81 284 598 minecraft:calcite
fill 82 284 558 85 284 558 minecraft:cobbled_deepslate
fill 82 284 559 84 284 560 minecraft:light_blue_stained_glass
fill 82 284 598 85 284 598 minecraft:cobbled_deepslate
fill 83 284 561 85 284 561 minecraft:light_blue_stained_glass
setblock 85 284 559 minecraft:calcite
fill 85 284 560 86 284 560 minecraft:light_blue_stained_glass
setblock 86 284 558 minecraft:calcite
fill 86 284 559 88 285 559 minecraft:cobbled_deepslate
setblock 86 284 598 minecraft:calcite
fill 87 284 558 88 286 558 minecraft:cobbled_deepslate
fill 87 284 560 87 284 561 minecraft:cobbled_deepslate
setblock 87 284 562 minecraft:calcite
fill 87 284 570 87 284 571 minecraft:cobbled_deepslate
setblock 87 284 572 minecraft:calcite
fill 87 284 573 87 284 576 minecraft:cobbled_deepslate
setblock 87 284 577 minecraft:calcite
fill 87 284 578 88 284 580 minecraft:cobbled_deepslate
fill 87 284 598 88 286 598 minecraft:cobbled_deepslate
setblock 88 284 560 minecraft:cobbled_deepslate
setblock 88 284 561 minecraft:calcite
fill 88 284 562 88 284 565 minecraft:cobbled_deepslate
setblock 88 284 566 minecraft:calcite
fill 88 284 567 88 284 570 minecraft:cobbled_deepslate
setblock 88 284 571 minecraft:calcite
fill 88 284 572 88 284 575 minecraft:cobbled_deepslate
setblock 88 284 576 minecraft:calcite
fill 88 284 577 88 287 577 minecraft:cobbled_deepslate
setblock 88 284 581 minecraft:calcite
fill 88 284 582 88 286 583 minecraft:cobbled_deepslate
fill 88 284 594 88 284 595 minecraft:cobbled_deepslate
setblock 88 284 596 minecraft:calcite
fill 88 284 597 88 287 597 minecraft:cobbled_deepslate
fill 47 285 585 54 285 585 minecraft:smooth_basalt
fill 48 285 558 48 285 559 minecraft:cobbled_deepslate
setblock 48 285 560 minecraft:calcite
fill 48 285 561 48 285 564 minecraft:cobbled_deepslate
setblock 48 285 565 minecraft:calcite
fill 48 285 566 48 288 566 minecraft:cobbled_deepslate
fill 48 285 591 48 285 594 minecraft:cobbled_deepslate
setblock 48 285 595 minecraft:calcite
fill 48 285 596 49 285 598 minecraft:cobbled_deepslate
setblock 49 285 558 minecraft:cobbled_deepslate
setblock 49 285 559 minecraft:calcite
fill 49 285 560 49 285 563 minecraft:cobbled_deepslate
setblock 49 285 564 minecraft:calcite
fill 49 285 565 57 285 566 minecraft:smooth_basalt
fill 49 285 582 52 285 583 minecraft:smooth_basalt
setblock 49 285 593 minecraft:cobbled_deepslate
setblock 49 285 594 minecraft:calcite
fill 49 285 595 52 285 595 minecraft:cobbled_deepslate
setblock 50 285 558 minecraft:calcite
fill 50 285 559 53 285 559 minecraft:cobbled_deepslate
fill 50 285 581 52 285 581 minecraft:smooth_basalt
fill 50 285 594 50 286 594 minecraft:cobbled_deepslate
fill 50 285 596 50 285 597 minecraft:cobbled_deepslate
setblock 50 285 598 minecraft:calcite
fill 51 285 558 54 285 558 minecraft:cobbled_deepslate
fill 51 285 560 52 285 560 minecraft:cobbled_deepslate
fill 51 285 568 52 285 572 minecraft:smooth_basalt
fill 51 285 574 51 285 578 minecraft:smooth_basalt
fill 51 285 580 52 285 580 minecraft:smooth_basalt
setblock 51 285 596 minecraft:cobbled_deepslate
setblock 51 285 597 minecraft:calcite
fill 51 285 598 54 285 598 minecraft:cobbled_deepslate
setblock 52 285 574 minecraft:smooth_basalt
setblock 52 285 596 minecraft:calcite
fill 52 285 597 55 285 597 minecraft:cobbled_deepslate
setblock 53 285 560 minecraft:calcite
fill 53 285 567 53 285 571 minecraft:smooth_basalt
setblock 53 285 583 minecraft:smooth_basalt
fill 53 285 587 56 285 587 minecraft:smooth_basalt
setblock 53 285 595 minecraft:calcite
fill 53 285 596 56 285 596 minecraft:cobbled_deepslate
setblock 54 285 559 minecraft:calcite
fill 54 285 560 54 288 560 minecraft:cobbled_deepslate
fill 54 285 567 54 285 569 minecraft:smooth_basalt
fill 54 285 586 55 285 586 minecraft:smooth_basalt
fill 54 285 595 55 285 595 minecraft:cobbled_deepslate
setblock 55 285 558 minecraft:calcite
fill 55 285 559 55 288 559 minecraft:cobbled_deepslate
fill 55 285 567 55 285 568 minecraft:smooth_basalt
setblock 55 285 598 minecraft:calcite
fill 56 285 558 56 288 558 minecraft:cobbled_deepslate
setblock 56 285 567 minecraft:smooth_basalt
setblock 56 285 597 minecraft:calcite
fill 56 285 598 59 285 598 minecraft:cobbled_deepslate
setblock 57 285 596 minecraft:calcite
fill 57 285 597 60 285 597 minecraft:cobbled_deepslate
fill 58 285 565 59 285 565 minecraft:smooth_basalt
fill 58 285 589 58 285 591 minecraft:calcite
setblock 58 285 596 minecraft:cobbled_deepslate
fill 59 285 589 59 285 591 minecraft:smooth_basalt
fill 60 285 590 62 285 591 minecraft:smooth_basalt
setblock 60 285 598 minecraft:calcite
fill 61 285 564 62 285 564 minecraft:smooth_basalt
setblock 61 285 597 minecraft:calcite
fill 61 285 598 64 285 598 minecraft:cobbled_deepslate
fill 62 285 597 62 286 597 minecraft:cobbled_deepslate
setblock 63 285 591 minecraft:smooth_basalt
setblock 65 285 598 minecraft:calcite
setblock 66 285 597 minecraft:calcite
fill 66 285 598 69 285 598 minecraft:cobbled_deepslate
fill 67 285 597 70 285 597 minecraft:cobbled_deepslate
fill 68 285 564 71 285 564 minecraft:smooth_basalt
setblock 68 285 590 minecraft:smooth_basalt
setblock 70 285 598 minecraft:calcite
setblock 71 285 565 minecraft:smooth_basalt
fill 71 285 589 81 285 589 minecraft:smooth_basalt
setblock 71 285 597 minecraft:calcite
fill 71 285 598 74 285 598 minecraft:cobbled_deepslate
fill 72 285 558 74 285 558 minecraft:cobbled_deepslate
fill 72 285 563 72 285 565 minecraft:calcite
setblock 72 285 596 minecraft:calcite
fill 72 285 597 75 285 597 minecraft:cobbled_deepslate
fill 73 285 563 77 285 566 minecraft:smooth_basalt
fill 73 285 588 81 285 588 minecraft:smooth_basalt
setblock 73 285 596 minecraft:cobbled_deepslate
setblock 74 285 559 minecraft:calcite
fill 74 285 567 77 285 567 minecraft:smooth_basalt
fill 74 285 587 77 285 587 minecraft:smooth_basalt
setblock 75 285 558 minecraft:calcite
fill 75 285 559 78 285 559 minecraft:cobbled_deepslate
fill 75 285 568 76 285 568 minecraft:smooth_basalt
fill 75 285 583 76 300 584 minecraft:calcite
setblock 75 285 598 minecraft:calcite
fill 76 285 558 79 285 558 minecraft:cobbled_deepslate
fill 76 285 569 83 285 569 minecraft:smooth_basalt
fill 76 285 582 77 300 582 minecraft:calcite
fill 76 285 585 83 285 585 minecraft:smooth_basalt
setblock 76 285 597 minecraft:calcite
fill 76 285 598 79 285 598 minecraft:cobbled_deepslate
fill 77 285 571 81 285 571 minecraft:smooth_basalt
fill 77 285 583 83 285 584 minecraft:smooth_basalt
setblock 77 285 597 minecraft:cobbled_deepslate
fill 78 285 572 79 285 574 minecraft:smooth_basalt
setblock 79 285 559 minecraft:calcite
fill 79 285 576 80 285 579 minecraft:smooth_basalt
setblock 80 285 558 minecraft:calcite
fill 80 285 572 80 285 573 minecraft:smooth_basalt
setblock 80 285 598 minecraft:calcite
fill 81 285 558 84 285 558 minecraft:cobbled_deepslate
fill 81 285 572 81 286 572 minecraft:smooth_basalt
fill 81 285 576 84 286 577 minecraft:smooth_basalt
setblock 81 285 598 minecraft:cobbled_deepslate
fill 82 285 559 83 285 559 minecraft:light_blue_stained_glass
fill 83 285 560 85 285 560 minecraft:light_blue_stained_glass
setblock 84 285 559 minecraft:calcite
setblock 84 285 598 minecraft:cobbled_deepslate
setblock 85 285 558 minecraft:calcite
fill 85 285 559 85 288 559 minecraft:cobbled_deepslate
fill 85 285 577 85 286 577 minecraft:smooth_basalt
setblock 85 285 598 minecraft:calcite
fill 86 285 558 86 288 558 minecraft:cobbled_deepslate
fill 86 285 598 86 288 598 minecraft:cobbled_deepslate
setblock 87 285 560 minecraft:cobbled_deepslate
setblock 87 285 561 minecraft:calcite
fill 87 285 562 88 285 564 minecraft:cobbled_deepslate
setblock 87 285 571 minecraft:calcite
fill 87 285 572 87 285 575 minecraft:cobbled_deepslate
setblock 87 285 576 minecraft:calcite
fill 87 285 577 87 285 580 minecraft:cobbled_deepslate
setblock 88 285 560 minecraft:calcite
fill 88 285 561 88 288 561 minecraft:cobbled_deepslate
setblock 88 285 565 minecraft:calcite
fill 88 285 566 88 285 569 minecraft:cobbled_deepslate
setblock 88 285 570 minecraft:calcite
fill 88 285 571 88 285 574 minecraft:cobbled_deepslate
setblock 88 285 575 minecraft:calcite
fill 88 285 576 88 288 576 minecraft:cobbled_deepslate
fill 88 285 578 88 285 579 minecraft:cobbled_deepslate
setblock 88 285 580 minecraft:calcite
fill 88 285 581 88 288 581 minecraft:cobbled_deepslate
setblock 88 285 594 minecraft:cobbled_deepslate
setblock 88 285 595 minecraft:calcite
fill 88 285 596 88 288 596 minecraft:cobbled_deepslate
fill 47 286 585 51 286 585 minecraft:smooth_basalt
setblock 48 286 558 minecraft:cobbled_deepslate
setblock 48 286 559 minecraft:calcite
fill 48 286 560 48 286 563 minecraft:cobbled_deepslate
setblock 48 286 564 minecraft:calcite
fill 48 286 565 48 289 565 minecraft:cobbled_deepslate
fill 48 286 584 50 286 584 minecraft:smooth_basalt
fill 48 286 591 48 286 593 minecraft:cobbled_deepslate
setblock 48 286 594 minecraft:calcite
fill 48 286 595 48 286 598 minecraft:cobbled_deepslate
setblock 49 286 558 minecraft:calcite
fill 49 286 559 49 286 562 minecraft:cobbled_deepslate
setblock 49 286 563 minecraft:calcite
fill 49 286 564 49 289 564 minecraft:cobbled_deepslate
fill 49 286 565 53 286 566 minecraft:smooth_basalt
fill 49 286 582 50 286 583 minecraft:smooth_basalt
setblock 49 286 593 minecraft:calcite
fill 49 286 594 49 286 597 minecraft:cobbled_deepslate
setblock 49 286 598 minecraft:calcite
fill 50 286 558 50 286 561 minecraft:cobbled_deepslate
setblock 50 286 562 minecraft:calcite
fill 50 286 564 56 286 564 minecraft:smooth_basalt
fill 50 286 568 50 286 572 minecraft:smooth_basalt
setblock 50 286 593 minecraft:light_blue_stained_glass
fill 50 286 595 50 286 596 minecraft:cobbled_deepslate
setblock 50 286 597 minecraft:calcite
fill 50 286 598 53 286 598 minecraft:cobbled_deepslate
fill 51 286 558 51 286 560 minecraft:cobbled_deepslate
fill 51 286 563 57 286 563 minecraft:smooth_basalt
fill 51 286 568 51 286 569 minecraft:smooth_basalt
fill 51 286 577 51 294 577 minecraft:deepslate
fill 51 286 594 51 287 595 minecraft:light_blue_stained_glass
setblock 51 286 596 minecraft:calcite
fill 51 286 597 54 286 597 minecraft:cobbled_deepslate
fill 52 286 558 52 286 559 minecraft:cobbled_deepslate
setblock 52 286 560 minecraft:calcite
setblock 52 286 568 minecraft:smooth_basalt
fill 52 286 588 53 286 588 minecraft:smooth_basalt
fill 52 286 596 55 286 596 minecraft:cobbled_deepslate
setblock 53 286 558 minecraft:cobbled_deepslate
setblock 53 286 559 minecraft:calcite
fill 53 286 560 53 289 560 minecraft:cobbled_deepslate
fill 53 286 589 54 286 593 minecraft:smooth_basalt
setblock 54 286 558 minecraft:calcite
fill 54 286 559 54 289 559 minecraft:cobbled_deepslate
setblock 54 286 565 minecraft:smooth_basalt
setblock 54 286 598 minecraft:calcite
fill 55 286 558 55 289 558 minecraft:cobbled_deepslate
fill 55 286 590 56 286 593 minecraft:smooth_basalt
setblock 55 286 597 minecraft:calcite
fill 55 286 598 58 286 598 minecraft:cobbled_deepslate
setblock 56 286 596 minecraft:calcite
fill 56 286 597 59 286 597 minecraft:cobbled_deepslate
fill 57 286 591 57 286 593 minecraft:smooth_basalt
setblock 57 286 596 minecraft:cobbled_deepslate
fill 58 286 562 60 286 562 minecraft:smooth_basalt
fill 58 286 592 60 286 593 minecraft:smooth_basalt
setblock 59 286 598 minecraft:calcite
setblock 60 286 597 minecraft:calcite
fill 60 286 598 63 286 598 minecraft:cobbled_deepslate
fill 61 286 593 64 286 593 minecraft:smooth_basalt
setblock 61 286 597 minecraft:cobbled_deepslate
fill 63 286 567 64 294 567 minecraft:deepslate
setblock 64 286 598 minecraft:calcite
fill 65 286 598 68 286 598 minecraft:cobbled_deepslate
fill 66 286 597 69 286 597 minecraft:cobbled_deepslate
setblock 69 286 598 minecraft:calcite
fill 70 286 562 77 286 562 minecraft:smooth_basalt
fill 70 286 592 72 286 592 minecraft:smooth_basalt
setblock 70 286 597 minecraft:calcite
fill 70 286 598 73 286 598 minecraft:cobbled_deepslate
fill 71 286 597 74 286 597 minecraft:cobbled_deepslate
fill 72 286 558 73 286 558 minecraft:cobbled_deepslate
fill 73 286 563 77 286 563 minecraft:smooth_basalt
setblock 74 286 558 minecraft:calcite
fill 74 286 559 77 286 559 minecraft:cobbled_deepslate
fill 74 286 564 77 286 564 minecraft:smooth_basalt
fill 74 286 583 74 287 584 minecraft:deepslate
fill 74 286 590 80 286 590 minecraft:smooth_basalt
setblock 74 286 598 minecraft:calcite
fill 75 286 558 78 286 558 minecraft:cobbled_deepslate
fill 75 286 582 75 287 582 minecraft:deepslate
fill 75 286 585 75 287 586 minecraft:deepslate
setblock 75 286 597 minecraft:calcite
fill 75 286 598 78 286 598 minecraft:cobbled_deepslate
fill 76 286 565 77 286 565 minecraft:smooth_basalt
fill 76 286 581 79 287 581 minecraft:deepslate
fill 76 286 585 78 300 585 minecraft:calcite
fill 76 286 586 76 287 586 minecraft:deepslate
fill 76 286 589 81 286 589 minecraft:smooth_basalt
setblock 77 286 566 minecraft:smooth_basalt
fill 77 286 583 79 300 584 minecraft:calcite
fill 77 286 586 77 300 586 minecraft:calcite
fill 77 286 587 77 287 587 minecraft:deepslate
fill 77 286 588 81 286 588 minecraft:smooth_basalt
setblock 78 286 559 minecraft:calcite
fill 78 286 582 79 300 582 minecraft:calcite
fill 78 286 586 82 286 586 minecraft:smooth_basalt
setblock 79 286 558 minecraft:calcite
fill 79 286 569 83 286 569 minecraft:smooth_basalt
fill 79 286 585 83 286 585 minecraft:smooth_basalt
setblock 79 286 598 minecraft:calcite
fill 80 286 558 83 286 558 minecraft:cobbled_deepslate
fill 80 286 570 80 286 572 minecraft:smooth_basalt
fill 80 286 582 83 286 584 minecraft:smooth_basalt
fill 81 286 570 81 286 571 minecraft:smooth_basalt
fill 81 286 575 84 286 575 minecraft:smooth_basalt
fill 81 286 581 83 286 581 minecraft:smooth_basalt
setblock 82 286 570 minecraft:smooth_basalt
setblock 84 286 558 minecraft:calcite
fill 84 286 559 84 289 559 minecraft:cobbled_deepslate
fill 85 286 558 85 289 558 minecraft:cobbled_deepslate
fill 85 286 598 85 287 598 minecraft:cobbled_deepslate
fill 86 286 559 87 286 559 minecraft:cobbled_deepslate
setblock 87 286 560 minecraft:calcite
fill 87 286 561 87 286 564 minecraft:cobbled_deepslate
setblock 87 286 565 minecraft:calcite
fill 87 286 572 87 286 574 minecraft:cobbled_deepslate
setblock 87 286 575 minecraft:calcite
fill 87 286 576 87 286 579 minecraft:cobbled_deepslate
setblock 87 286 580 minecraft:calcite
fill 87 286 581 87 287 581 minecraft:cobbled_deepslate
setblock 88 286 559 minecraft:calcite
fill 88 286 560 88 289 560 minecraft:cobbled_deepslate
fill 88 286 562 88 286 563 minecraft:cobbled_deepslate
setblock 88 286 564 minecraft:calcite
fill 88 286 565 88 286 568 minecraft:cobbled_deepslate
setblock 88 286 569 minecraft:calcite
fill 88 286 570 88 286 573 minecraft:cobbled_deepslate
setblock 88 286 574 minecraft:calcite
fill 88 286 575 88 289 575 minecraft:cobbled_deepslate
setblock 88 286 578 minecraft:cobbled_deepslate
setblock 88 286 579 minecraft:calcite
fill 88 286 580 88 289 580 minecraft:cobbled_deepslate
setblock 88 286 584 minecraft:calcite
setblock 88 286 594 minecraft:calcite
fill 88 286 595 88 288 595 minecraft:cobbled_deepslate
fill 47 287 569 47 307 585 minecraft:deepslate
setblock 48 287 558 minecraft:calcite
fill 48 287 559 48 287 562 minecraft:cobbled_deepslate
setblock 48 287 563 minecraft:calcite
fill 48 287 564 48 290 564 minecraft:cobbled_deepslate
setblock 48 287 567 minecraft:cobbled_deepslate
setblock 48 287 573 minecraft:calcite
fill 48 287 574 48 287 577 minecraft:cobbled_deepslate
setblock 48 287 578 minecraft:calcite
fill 48 287 579 48 287 582 minecraft:cobbled_deepslate
fill 48 287 584 48 288 586 minecraft:cobbled_deepslate
fill 48 287 591 48 287 592 minecraft:cobbled_deepslate
setblock 48 287 593 minecraft:calcite
fill 48 287 594 48 287 597 minecraft:cobbled_deepslate
setblock 48 287 598 minecraft:calcite
fill 49 287 558 49 287 561 minecraft:cobbled_deepslate
setblock 49 287 562 minecraft:calcite
fill 49 287 563 49 290 563 minecraft:cobbled_deepslate
setblock 49 287 576 minecraft:cobbled_deepslate
setblock 49 287 577 minecraft:calcite
fill 49 287 578 49 287 581 minecraft:cobbled_deepslate
setblock 49 287 582 minecraft:calcite
fill 49 287 583 49 290 583 minecraft:cobbled_deepslate
fill 49 287 593 49 287 596 minecraft:cobbled_deepslate
setblock 49 287 597 minecraft:calcite
fill 49 287 598 52 287 598 minecraft:cobbled_deepslate
fill 50 287 558 50 287 560 minecraft:cobbled_deepslate
setblock 50 287 561 minecraft:calcite
fill 50 287 562 50 290 562 minecraft:cobbled_deepslate
fill 50 287 594 50 288 594 minecraft:light_blue_stained_glass
setblock 50 287 595 minecraft:cobbled_deepslate
setblock 50 287 596 minecraft:calcite
fill 50 287 597 53 287 597 minecraft:cobbled_deepslate
fill 51 287 558 51 287 559 minecraft:cobbled_deepslate
setblock 51 287 560 minecraft:calcite
fill 51 287 596 54 287 596 minecraft:cobbled_deepslate
setblock 52 287 558 minecraft:cobbled_deepslate
setblock 52 287 559 minecraft:calcite
fill 52 287 560 52 290 560 minecraft:cobbled_deepslate
fill 52 287 595 52 288 595 minecraft:light_blue_stained_glass
setblock 53 287 558 minecraft:calcite
fill 53 287 559 53 290 559 minecraft:cobbled_deepslate
setblock 53 287 598 minecraft:calcite
fill 54 287 558 54 290 558 minecraft:cobbled_deepslate
setblock 54 287 597 minecraft:calcite
fill 54 287 598 57 287 598 minecraft:cobbled_deepslate
setblock 55 287 596 minecraft:calcite
fill 55 287 597 58 287 597 minecraft:cobbled_deepslate
setblock 56 287 596 minecraft:cobbled_deepslate
setblock 57 287 558 minecraft:cobbled_deepslate
setblock 57 287 559 minecraft:calcite
setblock 58 287 558 minecraft:calcite
setblock 58 287 598 minecraft:calcite
fill 59 287 558 61 287 558 minecraft:cobbled_deepslate
setblock 59 287 559 minecraft:light_blue_stained_glass
setblock 59 287 597 minecraft:calcite
fill 59 287 598 62 287 598 minecraft:cobbled_deepslate
setblock 63 287 598 minecraft:calcite
fill 64 287 558 67 287 558 minecraft:cobbled_deepslate
fill 64 287 598 67 287 598 minecraft:cobbled_deepslate
fill 65 287 557 65 307 557 minecraft:deepslate
fill 67 287 597 68 287 597 minecraft:cobbled_deepslate
setblock 68 287 558 minecraft:calcite
fill 68 287 559 71 287 559 minecraft:cobbled_deepslate
setblock 68 287 598 minecraft:calcite
fill 69 287 558 72 287 558 minecraft:cobbled_deepslate
setblock 69 287 597 minecraft:calcite
fill 69 287 598 72 287 598 minecraft:cobbled_deepslate
fill 70 287 597 73 287 597 minecraft:cobbled_deepslate
setblock 72 287 559 minecraft:calcite
setblock 73 287 558 minecraft:calcite
fill 73 287 559 76 287 559 minecraft:cobbled_deepslate
fill 73 287 583 73 287 584 minecraft:deepslate
setblock 73 287 598 minecraft:calcite
fill 74 287 558 77 287 558 minecraft:cobbled_deepslate
fill 74 287 581 74 287 582 minecraft:deepslate
fill 74 287 585 74 287 586 minecraft:deepslate
fill 74 287 598 77 287 598 minecraft:cobbled_deepslate
fill 75 287 580 75 287 581 minecraft:deepslate
fill 75 287 587 76 287 587 minecraft:deepslate
fill 76 287 580 79 287 580 minecraft:deepslate
setblock 77 287 559 minecraft:calcite
setblock 77 287 588 minecraft:deepslate
setblock 78 287 558 minecraft:calcite
fill 78 287 586 80 287 587 minecraft:deepslate
fill 79 287 558 82 287 558 minecraft:cobbled_deepslate
fill 79 287 585 79 300 585 minecraft:calcite
fill 80 287 581 80 287 585 minecraft:deepslate
fill 81 287 582 81 287 585 minecraft:deepslate
setblock 83 287 558 minecraft:calcite
fill 83 287 559 83 290 559 minecraft:cobbled_deepslate
fill 84 287 558 84 290 558 minecraft:cobbled_deepslate
setblock 86 287 559 minecraft:cobbled_deepslate
setblock 86 287 560 minecraft:calcite
setblock 87 287 558 minecraft:cobbled_deepslate
setblock 87 287 559 minecraft:calcite
fill 87 287 560 87 287 563 minecraft:cobbled_deepslate
setblock 87 287 564 minecraft:calcite
fill 87 287 565 88 289 565 minecraft:cobbled_deepslate
setblock 87 287 574 minecraft:calcite
fill 87 287 575 87 287 578 minecraft:cobbled_deepslate
setblock 87 287 579 minecraft:calcite
fill 87 287 580 87 289 580 minecraft:cobbled_deepslate
setblock 87 287 598 minecraft:cobbled_deepslate
setblock 88 287 558 minecraft:calcite
fill 88 287 559 88 290 559 minecraft:cobbled_deepslate
setblock 88 287 562 minecraft:cobbled_deepslate
setblock 88 287 563 minecraft:calcite
fill 88 287 564 88 290 564 minecraft:cobbled_deepslate
fill 88 287 566 88 287 567 minecraft:cobbled_deepslate
setblock 88 287 568 minecraft:calcite
fill 88 287 569 88 287 572 minecraft:cobbled_deepslate
setblock 88 287 573 minecraft:calcite
fill 88 287 574 88 290 574 minecraft:cobbled_deepslate
setblock 88 287 578 minecraft:calcite
fill 88 287 579 88 290 579 minecraft:cobbled_deepslate
setblock 88 287 582 minecraft:cobbled_deepslate
setblock 88 287 583 minecraft:calcite
fill 88 287 584 88 290 584 minecraft:cobbled_deepslate
setblock 88 287 598 minecraft:calcite
fill 48 288 558 48 288 561 minecraft:cobbled_deepslate
setblock 48 288 562 minecraft:calcite
fill 48 288 563 48 291 563 minecraft:cobbled_deepslate
setblock 48 288 567 minecraft:calcite
fill 48 288 575 48 288 576 minecraft:cobbled_deepslate
setblock 48 288 577 minecraft:calcite
fill 48 288 578 48 288 581 minecraft:cobbled_deepslate
setblock 48 288 582 minecraft:calcite
fill 48 288 583 48 291 583 minecraft:cobbled_deepslate
setblock 48 288 587 minecraft:calcite
setblock 48 288 591 minecraft:cobbled_deepslate
setblock 48 288 592 minecraft:calcite
fill 48 288 593 48 288 596 minecraft:cobbled_deepslate
setblock 48 288 597 minecraft:calcite
fill 48 288 598 51 288 598 minecraft:cobbled_deepslate
fill 49 288 558 49 288 560 minecraft:cobbled_deepslate
setblock 49 288 561 minecraft:calcite
fill 49 288 562 49 291 562 minecraft:cobbled_deepslate
fill 49 288 578 49 288 580 minecraft:cobbled_deepslate
setblock 49 288 581 minecraft:calcite
fill 49 288 582 49 291 582 minecraft:cobbled_deepslate
fill 49 288 584 49 289 584 minecraft:cobbled_deepslate
fill 49 288 594 49 288 595 minecraft:cobbled_deepslate
setblock 49 288 596 minecraft:calcite
fill 49 288 597 52 288 597 minecraft:cobbled_deepslate
fill 50 288 558 50 288 559 minecraft:cobbled_deepslate
setblock 50 288 560 minecraft:calcite
fill 50 288 561 50 291 561 minecraft:cobbled_deepslate
setblock 50 288 568 minecraft:light[level=14]
setblock 50 288 576 minecraft:light[level=14]
setblock 50 288 584 minecraft:light[level=14]
setblock 50 288 592 minecraft:light[level=14]
fill 50 288 595 51 289 595 minecraft:light_blue_stained_glass
fill 50 288 596 53 288 596 minecraft:cobbled_deepslate
setblock 51 288 558 minecraft:cobbled_deepslate
setblock 51 288 559 minecraft:calcite
fill 51 288 560 51 291 560 minecraft:cobbled_deepslate
setblock 52 288 558 minecraft:calcite
fill 52 288 559 52 291 559 minecraft:cobbled_deepslate
setblock 52 288 598 minecraft:calcite
fill 53 288 558 53 291 558 minecraft:cobbled_deepslate
setblock 53 288 597 minecraft:calcite
fill 53 288 598 56 288 598 minecraft:cobbled_deepslate
setblock 54 288 596 minecraft:calcite
fill 54 288 597 57 288 597 minecraft:cobbled_deepslate
setblock 56 288 559 minecraft:calcite
setblock 57 288 558 minecraft:calcite
setblock 57 288 598 minecraft:calcite
fill 58 288 558 59 288 558 minecraft:cobbled_deepslate
setblock 58 288 560 minecraft:light[level=14]
setblock 58 288 568 minecraft:light[level=14]
setblock 58 288 576 minecraft:light[level=14]
setblock 58 288 584 minecraft:light[level=14]
setblock 58 288 592 minecraft:light[level=14]
fill 58 288 598 61 288 598 minecraft:cobbled_deepslate
setblock 62 288 598 minecraft:calcite
fill 63 288 566 64 294 566 minecraft:deepslate
fill 63 288 568 64 294 568 minecraft:deepslate
fill 63 288 598 66 288 598 minecraft:cobbled_deepslate
fill 65 288 558 66 288 558 minecraft:cobbled_deepslate
setblock 66 288 560 minecraft:light[level=14]
setblock 66 288 568 minecraft:light[level=14]
setblock 66 288 576 minecraft:light[level=14]
setblock 66 288 584 minecraft:light[level=14]
setblock 66 288 592 minecraft:light[level=14]
setblock 67 288 558 minecraft:calcite
setblock 67 288 598 minecraft:calcite
fill 68 288 558 70 288 559 minecraft:cobbled_deepslate
fill 68 288 598 71 288 598 minecraft:cobbled_deepslate
fill 69 288 597 71 288 597 minecraft:cobbled_deepslate
setblock 71 288 558 minecraft:cobbled_deepslate
setblock 71 288 559 minecraft:calcite
setblock 72 288 558 minecraft:calcite
fill 72 288 559 75 288 559 minecraft:cobbled_deepslate
setblock 72 288 598 minecraft:calcite
fill 73 288 558 76 288 558 minecraft:cobbled_deepslate
fill 73 288 598 75 288 598 minecraft:cobbled_deepslate
setblock 74 288 560 minecraft:light[level=14]
setblock 74 288 568 minecraft:light[level=14]
setblock 74 288 576 minecraft:light[level=14]
setblock 74 288 584 minecraft:light[level=14]
setblock 74 288 592 minecraft:light[level=14]
setblock 76 288 559 minecraft:calcite
setblock 77 288 558 minecraft:calcite
fill 78 288 558 81 288 558 minecraft:cobbled_deepslate
setblock 82 288 558 minecraft:calcite
setblock 82 288 560 minecraft:light[level=14]
setblock 82 288 568 minecraft:light[level=14]
setblock 82 288 576 minecraft:light[level=14]
setblock 82 288 584 minecraft:light[level=14]
setblock 82 288 592 minecraft:light[level=14]
fill 83 288 558 83 291 558 minecraft:cobbled_deepslate
setblock 86 288 559 minecraft:calcite
fill 86 288 560 87 289 561 minecraft:cobbled_deepslate
setblock 87 288 558 minecraft:calcite
fill 87 288 559 87 291 559 minecraft:cobbled_deepslate
setblock 87 288 562 minecraft:cobbled_deepslate
setblock 87 288 563 minecraft:calcite
fill 87 288 564 87 291 564 minecraft:cobbled_deepslate
fill 87 288 566 88 288 566 minecraft:cobbled_deepslate
fill 87 288 576 87 288 577 minecraft:cobbled_deepslate
setblock 87 288 578 minecraft:calcite
fill 87 288 579 87 289 579 minecraft:cobbled_deepslate
setblock 87 288 598 minecraft:calcite
fill 88 288 558 88 291 558 minecraft:cobbled_deepslate
setblock 88 288 562 minecraft:calcite
fill 88 288 563 88 291 563 minecraft:cobbled_deepslate
setblock 88 288 567 minecraft:calcite
fill 88 288 568 88 288 571 minecraft:cobbled_deepslate
setblock 88 288 572 minecraft:calcite
fill 88 288 573 88 290 573 minecraft:cobbled_deepslate
setblock 88 288 577 minecraft:calcite
fill 88 288 578 88 291 578 minecraft:cobbled_deepslate
setblock 88 288 582 minecraft:calcite
fill 88 288 583 88 291 583 minecraft:cobbled_deepslate
fill 88 288 585 88 289 585 minecraft:cobbled_deepslate
setblock 88 288 597 minecraft:calcite
fill 88 288 598 88 291 598 minecraft:cobbled_deepslate
fill 48 289 558 48 289 560 minecraft:cobbled_deepslate
setblock 48 289 561 minecraft:calcite
fill 48 289 562 48 292 562 minecraft:cobbled_deepslate
setblock 48 289 566 minecraft:calcite
fill 48 289 567 48 292 567 minecraft:cobbled_deepslate
setblock 48 289 576 minecraft:calcite
fill 48 289 577 48 289 580 minecraft:cobbled_deepslate
setblock 48 289 581 minecraft:calcite
fill 48 289 582 48 292 582 minecraft:cobbled_deepslate
fill 48 289 584 48 289 585 minecraft:cobbled_deepslate
setblock 48 289 586 minecraft:calcite
fill 48 289 587 48 289 590 minecraft:cobbled_deepslate
setblock 48 289 591 minecraft:calcite
fill 48 289 592 48 289 595 minecraft:cobbled_deepslate
setblock 48 289 596 minecraft:calcite
fill 48 289 597 50 289 598 minecraft:cobbled_deepslate
fill 49 289 558 49 289 559 minecraft:cobbled_deepslate
setblock 49 289 560 minecraft:calcite
fill 49 289 561 49 292 561 minecraft:cobbled_deepslate
setblock 49 289 579 minecraft:cobbled_deepslate
setblock 49 289 580 minecraft:calcite
fill 49 289 581 49 292 581 minecraft:cobbled_deepslate
setblock 49 289 585 minecraft:calcite
setblock 49 289 594 minecraft:cobbled_deepslate
setblock 49 289 595 minecraft:calcite
fill 49 289 596 49 292 596 minecraft:cobbled_deepslate
setblock 50 289 558 minecraft:cobbled_deepslate
setblock 50 289 559 minecraft:calcite
fill 50 289 560 50 292 560 minecraft:cobbled_deepslate
fill 50 289 596 52 289 596 minecraft:light_blue_stained_glass
setblock 51 289 558 minecraft:calcite
fill 51 289 559 51 292 559 minecraft:cobbled_deepslate
setblock 51 289 597 minecraft:cobbled_deepslate
setblock 51 289 598 minecraft:calcite
fill 52 289 558 52 292 558 minecraft:cobbled_deepslate
setblock 52 289 597 minecraft:calcite
fill 52 289 598 55 289 598 minecraft:cobbled_deepslate
fill 53 289 597 56 289 597 minecraft:cobbled_deepslate
setblock 55 289 559 minecraft:calcite
setblock 56 289 558 minecraft:calcite
setblock 56 289 598 minecraft:calcite
fill 57 289 558 58 289 558 minecraft:cobbled_deepslate
fill 57 289 598 59 289 598 minecraft:cobbled_deepslate
fill 58 289 561 60 300 562 minecraft:calcite
fill 59 289 560 59 300 560 minecraft:calcite
fill 59 289 563 60 300 563 minecraft:calcite
fill 62 289 566 62 294 567 minecraft:deepslate
fill 63 289 565 64 294 565 minecraft:deepslate
fill 64 289 598 65 289 598 minecraft:cobbled_deepslate
setblock 65 289 558 minecraft:cobbled_deepslate
fill 65 289 566 65 294 567 minecraft:deepslate
setblock 66 289 558 minecraft:calcite
setblock 66 289 598 minecraft:calcite
fill 67 289 558 70 289 558 minecraft:cobbled_deepslate
fill 67 289 598 70 289 598 minecraft:cobbled_deepslate
setblock 69 289 559 minecraft:cobbled_deepslate
setblock 70 289 559 minecraft:calcite
setblock 71 289 558 minecraft:calcite
fill 71 289 559 74 289 559 minecraft:cobbled_deepslate
setblock 71 289 598 minecraft:calcite
fill 72 289 558 75 289 558 minecraft:cobbled_deepslate
fill 72 289 598 73 289 598 minecraft:cobbled_deepslate
setblock 76 289 558 minecraft:calcite
fill 77 289 558 80 289 558 minecraft:cobbled_deepslate
setblock 81 289 558 minecraft:calcite
fill 82 289 558 82 292 558 minecraft:cobbled_deepslate
setblock 85 289 559 minecraft:calcite
setblock 86 289 558 minecraft:calcite
fill 86 289 559 86 292 559 minecraft:cobbled_deepslate
setblock 86 289 562 minecraft:cobbled_deepslate
setblock 86 289 598 minecraft:calcite
fill 87 289 558 87 292 558 minecraft:cobbled_deepslate
setblock 87 289 562 minecraft:calcite
fill 87 289 563 87 292 563 minecraft:cobbled_deepslate
setblock 87 289 566 minecraft:cobbled_deepslate
fill 87 289 598 87 292 598 minecraft:cobbled_deepslate
setblock 88 289 561 minecraft:calcite
fill 88 289 562 88 292 562 minecraft:cobbled_deepslate
setblock 88 289 566 minecraft:calcite
fill 88 289 567 88 289 570 minecraft:cobbled_deepslate
setblock 88 289 571 minecraft:calcite
fill 88 289 572 88 292 572 minecraft:cobbled_deepslate
setblock 88 289 576 minecraft:calcite
fill 88 289 577 88 292 577 minecraft:cobbled_deepslate
setblock 88 289 581 minecraft:calcite
fill 88 289 582 88 292 582 minecraft:cobbled_deepslate
setblock 88 289 596 minecraft:calcite
fill 88 289 597 88 292 597 minecraft:cobbled_deepslate
fill 48 290 558 48 290 559 minecraft:cobbled_deepslate
setblock 48 290 560 minecraft:calcite
fill 48 290 561 48 293 561 minecraft:cobbled_deepslate
setblock 48 290 565 minecraft:calcite
fill 48 290 566 48 293 566 minecraft:cobbled_deepslate
fill 48 290 577 48 290 579 minecraft:cobbled_deepslate
setblock 48 290 580 minecraft:calcite
fill 48 290 581 48 293 581 minecraft:cobbled_deepslate
setblock 48 290 584 minecraft:cobbled_deepslate
setblock 48 290 585 minecraft:calcite
fill 48 290 586 48 290 589 minecraft:cobbled_deepslate
setblock 48 290 590 minecraft:calcite
fill 48 290 591 48 290 594 minecraft:cobbled_deepslate
setblock 48 290 595 minecraft:calcite
fill 48 290 596 48 291 598 minecraft:cobbled_deepslate
setblock 49 290 558 minecraft:cobbled_deepslate
setblock 49 290 559 minecraft:calcite
fill 49 290 560 49 293 560 minecraft:cobbled_deepslate
setblock 49 290 564 minecraft:calcite
fill 49 290 565 49 293 565 minecraft:cobbled_deepslate
fill 49 290 580 49 293 580 minecraft:cobbled_deepslate
setblock 49 290 584 minecraft:calcite
fill 49 290 585 49 292 586 minecraft:cobbled_deepslate
fill 49 290 595 49 293 595 minecraft:cobbled_deepslate
fill 49 290 597 49 290 598 minecraft:cobbled_deepslate
setblock 50 290 558 minecraft:calcite
fill 50 290 559 50 293 559 minecraft:cobbled_deepslate
fill 50 290 596 51 290 596 minecraft:light_blue_stained_glass
setblock 50 290 597 minecraft:cobbled_deepslate
setblock 50 290 598 minecraft:calcite
fill 51 290 558 51 293 558 minecraft:cobbled_deepslate
setblock 51 290 597 minecraft:calcite
fill 51 290 598 54 290 598 minecraft:cobbled_deepslate
fill 52 290 597 54 290 597 minecraft:cobbled_deepslate
setblock 54 290 559 minecraft:calcite
setblock 55 290 558 minecraft:calcite
setblock 55 290 598 minecraft:calcite
fill 56 290 558 57 290 558 minecraft:cobbled_deepslate
fill 56 290 598 57 290 598 minecraft:cobbled_deepslate
fill 57 290 561 57 291 562 minecraft:deepslate
fill 58 290 560 58 291 560 minecraft:deepslate
fill 58 290 563 58 291 563 minecraft:deepslate
fill 59 290 564 59 291 564 minecraft:deepslate
fill 60 290 560 60 291 560 minecraft:deepslate
fill 61 290 561 61 291 563 minecraft:deepslate
fill 62 290 568 62 294 568 minecraft:deepslate
fill 63 290 569 64 294 569 minecraft:deepslate
fill 65 290 565 65 294 565 minecraft:deepslate
fill 65 290 568 65 294 568 minecraft:deepslate
fill 66 290 558 69 290 558 minecraft:cobbled_deepslate
fill 66 290 598 69 290 598 minecraft:cobbled_deepslate
setblock 69 290 559 minecraft:calcite
setblock 70 290 558 minecraft:calcite
fill 70 290 559 73 290 559 minecraft:cobbled_deepslate
setblock 70 290 598 minecraft:calcite
fill 71 290 558 74 290 558 minecraft:cobbled_deepslate
fill 71 290 598 72 290 598 minecraft:cobbled_deepslate
setblock 75 290 558 minecraft:calcite
fill 76 290 558 78 290 558 minecraft:cobbled_deepslate
setblock 80 290 558 minecraft:calcite
fill 81 290 558 81 293 558 minecraft:cobbled_deepslate
setblock 84 290 559 minecraft:calcite
setblock 85 290 558 minecraft:calcite
fill 85 290 559 85 292 560 minecraft:cobbled_deepslate
fill 86 290 558 86 293 558 minecraft:cobbled_deepslate
fill 86 290 560 86 290 561 minecraft:cobbled_deepslate
setblock 86 290 562 minecraft:calcite
fill 86 290 563 86 293 563 minecraft:cobbled_deepslate
fill 86 290 598 86 293 598 minecraft:cobbled_deepslate
setblock 87 290 560 minecraft:cobbled_deepslate
setblock 87 290 561 minecraft:calcite
fill 87 290 562 87 293 562 minecraft:cobbled_deepslate
setblock 87 290 565 minecraft:cobbled_deepslate
setblock 87 290 566 minecraft:calcite
fill 87 290 567 88 292 567 minecraft:cobbled_deepslate
setblock 88 290 560 minecraft:calcite
fill 88 290 561 88 293 561 minecraft:cobbled_deepslate
setblock 88 290 565 minecraft:calcite
fill 88 290 566 88 293 566 minecraft:cobbled_deepslate
fill 88 290 568 88 290 569 minecraft:cobbled_deepslate
setblock 88 290 570 minecraft:calcite
fill 88 290 571 88 293 571 minecraft:cobbled_deepslate
setblock 88 290 575 minecraft:calcite
fill 88 290 576 88 293 576 minecraft:cobbled_deepslate
setblock 88 290 580 minecraft:calcite
fill 88 290 581 88 293 581 minecraft:cobbled_deepslate
setblock 88 290 585 minecraft:calcite
fill 88 290 586 88 293 586 minecraft:cobbled_deepslate
fill 88 290 596 88 293 596 minecraft:cobbled_deepslate
setblock 48 291 558 minecraft:cobbled_deepslate
setblock 48 291 559 minecraft:calcite
fill 48 291 560 48 294 560 minecraft:cobbled_deepslate
setblock 48 291 564 minecraft:calcite
fill 48 291 565 48 294 565 minecraft:cobbled_deepslate
fill 48 291 577 48 291 578 minecraft:cobbled_deepslate
setblock 48 291 579 minecraft:calcite
fill 48 291 580 48 294 580 minecraft:cobbled_deepslate
setblock 48 291 584 minecraft:calcite
fill 48 291 585 48 291 588 minecraft:cobbled_deepslate
setblock 48 291 589 minecraft:calcite
fill 48 291 590 48 291 593 minecraft:cobbled_deepslate
setblock 48 291 594 minecraft:calcite
fill 48 291 595 48 294 595 minecraft:cobbled_deepslate
setblock 49 291 558 minecraft:calcite
fill 49 291 559 49 294 559 minecraft:cobbled_deepslate
setblock 49 291 563 minecraft:calcite
fill 49 291 564 49 294 564 minecraft:cobbled_deepslate
setblock 49 291 583 minecraft:calcite
fill 49 291 584 49 294 584 minecraft:cobbled_deepslate
setblock 49 291 587 minecraft:cobbled_deepslate
setblock 49 291 588 minecraft:calcite
setblock 49 291 597 minecraft:cobbled_deepslate
setblock 49 291 598 minecraft:calcite
fill 50 291 558 50 294 558 minecraft:cobbled_deepslate
setblock 50 291 562 minecraft:calcite
setblock 50 291 597 minecraft:calcite
fill 50 291 598 53 291 598 minecraft:cobbled_deepslate
fill 51 291 597 53 291 597 minecraft:cobbled_deepslate
setblock 53 291 559 minecraft:calcite
setblock 54 291 558 minecraft:calcite
setblock 54 291 559 minecraft:cobbled_deepslate
setblock 54 291 598 minecraft:calcite
fill 55 291 558 56 291 558 minecraft:cobbled_deepslate
fill 55 291 598 56 291 598 minecraft:cobbled_deepslate
setblock 57 291 560 minecraft:deepslate
setblock 57 291 563 minecraft:deepslate
fill 58 291 559 60 291 559 minecraft:deepslate
setblock 58 291 564 minecraft:deepslate
fill 60 291 564 61 291 564 minecraft:deepslate
setblock 61 291 560 minecraft:deepslate
fill 61 291 566 61 294 567 minecraft:deepslate
fill 62 291 561 62 291 562 minecraft:deepslate
fill 62 291 565 62 294 565 minecraft:deepslate
fill 62 291 569 62 294 569 minecraft:deepslate
fill 65 291 569 65 294 569 minecraft:deepslate
fill 66 291 558 68 291 558 minecraft:cobbled_deepslate
fill 66 291 566 66 294 568 minecraft:deepslate
fill 67 291 598 68 291 598 minecraft:cobbled_deepslate
setblock 68 291 559 minecraft:calcite
setblock 69 291 558 minecraft:calcite
fill 69 291 559 72 291 559 minecraft:cobbled_deepslate
setblock 69 291 598 minecraft:calcite
fill 70 291 558 73 291 558 minecraft:cobbled_deepslate
setblock 70 291 598 minecraft:cobbled_deepslate
setblock 74 291 558 minecraft:calcite
fill 75 291 558 76 291 558 minecraft:cobbled_deepslate
fill 80 291 558 80 294 558 minecraft:cobbled_deepslate
setblock 83 291 559 minecraft:calcite
setblock 84 291 558 minecraft:calcite
fill 84 291 559 84 294 559 minecraft:cobbled_deepslate
fill 85 291 558 85 294 558 minecraft:cobbled_deepslate
setblock 86 291 560 minecraft:cobbled_deepslate
setblock 86 291 561 minecraft:calcite
fill 86 291 562 86 294 562 minecraft:cobbled_deepslate
fill 86 291 564 86 292 564 minecraft:cobbled_deepslate
setblock 87 291 560 minecraft:calcite
fill 87 291 561 87 294 561 minecraft:cobbled_deepslate
setblock 87 291 565 minecraft:calcite
fill 87 291 566 87 294 566 minecraft:cobbled_deepslate
setblock 88 291 559 minecraft:calcite
fill 88 291 560 88 294 560 minecraft:cobbled_deepslate
setblock 88 291 564 minecraft:calcite
fill 88 291 565 88 294 565 minecraft:cobbled_deepslate
setblock 88 291 568 minecraft:cobbled_deepslate
setblock 88 291 569 minecraft:calcite
fill 88 291 570 88 294 570 minecraft:cobbled_deepslate
setblock 88 291 574 minecraft:calcite
setblock 88 291 575 minecraft:cobbled_deepslate
setblock 88 291 579 minecraft:calcite
fill 88 291 580 88 294 580 minecraft:cobbled_deepslate
setblock 88 291 584 minecraft:calcite
fill 88 291 585 88 294 585 minecraft:cobbled_deepslate
fill 88 291 587 88 292 587 minecraft:cobbled_deepslate
setblock 48 292 558 minecraft:calcite
fill 48 292 559 48 295 559 minecraft:cobbled_deepslate
setblock 48 292 563 minecraft:calcite
fill 48 292 564 48 295 564 minecraft:cobbled_deepslate
setblock 48 292 568 minecraft:calcite
setblock 48 292 578 minecraft:calcite
fill 48 292 579 48 295 579 minecraft:cobbled_deepslate
setblock 48 292 583 minecraft:calcite
fill 48 292 584 48 292 587 minecraft:cobbled_deepslate
setblock 48 292 588 minecraft:calcite
fill 48 292 589 48 292 592 minecraft:cobbled_deepslate
setblock 48 292 593 minecraft:calcite
fill 48 292 594 49 294 594 minecraft:cobbled_deepslate
fill 48 292 596 48 292 597 minecraft:cobbled_deepslate
setblock 48 292 598 minecraft:calcite
fill 49 292 558 49 295 558 minecraft:cobbled_deepslate
setblock 49 292 562 minecraft:calcite
fill 49 292 563 49 295 563 minecraft:cobbled_deepslate
setblock 49 292 582 minecraft:calcite
fill 49 292 583 49 295 583 minecraft:cobbled_deepslate
setblock 49 292 587 minecraft:calcite
fill 49 292 588 49 292 591 minecraft:cobbled_deepslate
setblock 49 292 597 minecraft:calcite
fill 49 292 598 52 292 598 minecraft:cobbled_deepslate
setblock 50 292 561 minecraft:calcite
fill 50 292 562 50 295 562 minecraft:cobbled_deepslate
fill 50 292 597 52 292 597 minecraft:cobbled_deepslate
setblock 51 292 560 minecraft:calcite
setblock 52 292 559 minecraft:calcite
setblock 53 292 558 minecraft:calcite
setblock 53 292 559 minecraft:cobbled_deepslate
setblock 53 292 598 minecraft:calcite
fill 54 292 558 55 292 558 minecraft:cobbled_deepslate
fill 54 292 598 55 292 598 minecraft:cobbled_deepslate
fill 61 292 565 61 294 565 minecraft:deepslate
fill 61 292 568 61 294 568 minecraft:deepslate
fill 62 292 564 65 294 564 minecraft:deepslate
fill 65 292 558 67 292 558 minecraft:cobbled_deepslate
fill 66 292 565 66 294 565 minecraft:deepslate
setblock 68 292 558 minecraft:calcite
fill 68 292 559 71 292 559 minecraft:cobbled_deepslate
setblock 68 292 598 minecraft:calcite
fill 69 292 558 72 292 558 minecraft:cobbled_deepslate
setblock 72 292 559 minecraft:calcite
setblock 73 292 558 minecraft:calcite
fill 74 292 558 75 292 558 minecraft:cobbled_deepslate
setblock 82 292 559 minecraft:calcite
setblock 83 292 558 minecraft:calcite
fill 83 292 559 83 295 559 minecraft:cobbled_deepslate
fill 84 292 558 84 295 558 minecraft:cobbled_deepslate
fill 84 292 560 84 293 560 minecraft:cobbled_deepslate
setblock 86 292 560 minecraft:calcite
fill 86 292 561 86 295 561 minecraft:cobbled_deepslate
setblock 86 292 565 minecraft:calcite
setblock 87 292 559 minecraft:calcite
fill 87 292 560 87 295 560 minecraft:cobbled_deepslate
setblock 87 292 564 minecraft:calcite
fill 87 292 565 87 295 565 minecraft:cobbled_deepslate
setblock 87 292 568 minecraft:cobbled_deepslate
fill 87 292 582 87 292 583 minecraft:cobbled_deepslate
setblock 88 292 558 minecraft:calcite
fill 88 292 559 88 295 559 minecraft:cobbled_deepslate
setblock 88 292 563 minecraft:calcite
fill 88 292 564 88 295 564 minecraft:cobbled_deepslate
setblock 88 292 568 minecraft:calcite
fill 88 292 569 88 295 569 minecraft:cobbled_deepslate
setblock 88 292 578 minecraft:calcite
fill 88 292 579 88 295 579 minecraft:cobbled_deepslate
setblock 88 292 583 minecraft:calcite
fill 88 292 584 88 295 584 minecraft:cobbled_deepslate
setblock 88 292 588 minecraft:calcite
fill 88 292 589 88 295 589 minecraft:cobbled_deepslate
setblock 88 292 598 minecraft:calcite
fill 48 293 558 48 296 558 minecraft:cobbled_deepslate
setblock 48 293 562 minecraft:calcite
fill 48 293 563 48 296 563 minecraft:cobbled_deepslate
setblock 48 293 567 minecraft:calcite
fill 48 293 568 48 295 569 minecraft:cobbled_deepslate
fill 48 293 578 48 296 578 minecraft:cobbled_deepslate
setblock 48 293 582 minecraft:calcite
fill 48 293 583 48 293 586 minecraft:cobbled_deepslate
setblock 48 293 587 minecraft:calcite
fill 48 293 588 48 293 591 minecraft:cobbled_deepslate
setblock 48 293 592 minecraft:calcite
fill 48 293 593 49 295 593 minecraft:cobbled_deepslate
setblock 48 293 596 minecraft:cobbled_deepslate
setblock 48 293 597 minecraft:calcite
fill 48 293 598 51 293 598 minecraft:cobbled_deepslate
setblock 49 293 561 minecraft:calcite
fill 49 293 562 49 296 562 minecraft:cobbled_deepslate
setblock 49 293 566 minecraft:calcite
setblock 49 293 581 minecraft:calcite
fill 49 293 582 49 296 582 minecraft:cobbled_deepslate
setblock 49 293 585 minecraft:cobbled_deepslate
setblock 49 293 586 minecraft:calcite
fill 49 293 587 49 293 590 minecraft:cobbled_deepslate
setblock 49 293 591 minecraft:calcite
fill 49 293 592 49 296 592 minecraft:cobbled_deepslate
setblock 49 293 596 minecraft:calcite
fill 49 293 597 51 294 597 minecraft:cobbled_deepslate
setblock 50 293 560 minecraft:calcite
fill 50 293 561 50 295 561 minecraft:cobbled_deepslate
fill 50 293 577 50 294 577 minecraft:deepslate
setblock 50 293 584 minecraft:cobbled_deepslate
setblock 50 293 585 minecraft:calcite
fill 50 293 586 50 295 587 minecraft:cobbled_deepslate
setblock 51 293 559 minecraft:calcite
fill 51 293 576 51 294 576 minecraft:deepslate
fill 51 293 578 51 294 578 minecraft:deepslate
setblock 52 293 558 minecraft:calcite
fill 52 293 559 52 294 559 minecraft:cobbled_deepslate
fill 52 293 577 52 294 577 minecraft:deepslate
setblock 52 293 598 minecraft:calcite
fill 53 293 558 54 294 558 minecraft:cobbled_deepslate
fill 53 293 598 54 294 598 minecraft:cobbled_deepslate
fill 60 293 566 60 294 568 minecraft:deepslate
fill 61 293 564 61 294 564 minecraft:deepslate
fill 61 293 569 61 294 569 minecraft:deepslate
fill 62 293 570 65 294 570 minecraft:deepslate
fill 65 293 558 66 293 558 minecraft:cobbled_deepslate
fill 66 293 564 66 294 564 minecraft:deepslate
fill 66 293 569 66 294 569 minecraft:deepslate
setblock 67 293 558 minecraft:calcite
fill 67 293 566 67 294 568 minecraft:deepslate
fill 68 293 558 70 293 559 minecraft:cobbled_deepslate
setblock 71 293 558 minecraft:cobbled_deepslate
setblock 71 293 559 minecraft:calcite
setblock 72 293 558 minecraft:calcite
fill 73 293 558 74 294 558 minecraft:cobbled_deepslate
setblock 82 293 558 minecraft:calcite
fill 82 293 559 82 296 559 minecraft:cobbled_deepslate
fill 83 293 558 83 296 558 minecraft:cobbled_deepslate
setblock 85 293 559 minecraft:cobbled_deepslate
setblock 85 293 560 minecraft:calcite
fill 85 293 598 85 294 598 minecraft:cobbled_deepslate
setblock 86 293 559 minecraft:calcite
fill 86 293 560 86 296 560 minecraft:cobbled_deepslate
setblock 86 293 564 minecraft:calcite
fill 86 293 565 86 295 566 minecraft:cobbled_deepslate
setblock 87 293 558 minecraft:calcite
fill 87 293 559 87 296 559 minecraft:cobbled_deepslate
setblock 87 293 563 minecraft:calcite
fill 87 293 564 87 296 564 minecraft:cobbled_deepslate
setblock 87 293 567 minecraft:cobbled_deepslate
setblock 87 293 568 minecraft:calcite
fill 87 293 569 87 296 569 minecraft:cobbled_deepslate
fill 87 293 581 87 293 582 minecraft:cobbled_deepslate
setblock 87 293 583 minecraft:calcite
fill 87 293 584 87 294 586 minecraft:cobbled_deepslate
setblock 87 293 598 minecraft:calcite
fill 88 293 558 88 296 558 minecraft:cobbled_deepslate
setblock 88 293 562 minecraft:calcite
fill 88 293 563 88 296 563 minecraft:cobbled_deepslate
setblock 88 293 567 minecraft:calcite
fill 88 293 568 88 296 568 minecraft:cobbled_deepslate
setblock 88 293 572 minecraft:calcite
fill 88 293 573 88 296 573 minecraft:cobbled_deepslate
setblock 88 293 577 minecraft:calcite
fill 88 293 578 88 296 578 minecraft:cobbled_deepslate
setblock 88 293 582 minecraft:calcite
fill 88 293 583 88 296 583 minecraft:cobbled_deepslate
setblock 88 293 587 minecraft:calcite
fill 88 293 588 88 296 588 minecraft:cobbled_deepslate
fill 88 293 590 88 293 591 minecraft:cobbled_deepslate
setblock 88 293 592 minecraft:calcite
fill 88 293 593 88 294 595 minecraft:cobbled_deepslate
setblock 88 293 597 minecraft:calcite
fill 88 293 598 88 296 598 minecraft:cobbled_deepslate
setblock 48 294 561 minecraft:calcite
fill 48 294 562 48 297 562 minecraft:cobbled_deepslate
setblock 48 294 566 minecraft:calcite
fill 48 294 567 49 296 567 minecraft:cobbled_deepslate
setblock 48 294 570 minecraft:cobbled_deepslate
setblock 48 294 581 minecraft:calcite
fill 48 294 582 48 294 585 minecraft:cobbled_deepslate
setblock 48 294 586 minecraft:calcite
fill 48 294 587 48 294 590 minecraft:cobbled_deepslate
setblock 48 294 591 minecraft:calcite
fill 48 294 592 48 297 592 minecraft:cobbled_deepslate
setblock 48 294 596 minecraft:calcite
fill 48 294 597 48 296 598 minecraft:cobbled_deepslate
setblock 49 294 560 minecraft:calcite
fill 49 294 561 49 297 561 minecraft:cobbled_deepslate
setblock 49 294 565 minecraft:calcite
fill 49 294 566 49 297 566 minecraft:cobbled_deepslate
setblock 49 294 580 minecraft:calcite
fill 49 294 581 49 297 581 minecraft:cobbled_deepslate
setblock 49 294 585 minecraft:calcite
fill 49 294 586 49 294 589 minecraft:cobbled_deepslate
setblock 49 294 590 minecraft:calcite
fill 49 294 591 49 297 591 minecraft:cobbled_deepslate
setblock 49 294 595 minecraft:calcite
fill 49 294 596 49 297 596 minecraft:cobbled_deepslate
fill 49 294 598 50 294 598 minecraft:cobbled_deepslate
setblock 50 294 559 minecraft:calcite
setblock 50 294 560 minecraft:cobbled_deepslate
setblock 50 294 583 minecraft:cobbled_deepslate
setblock 50 294 584 minecraft:calcite
fill 50 294 585 50 297 585 minecraft:cobbled_deepslate
setblock 50 294 588 minecraft:cobbled_deepslate
setblock 50 294 589 minecraft:calcite
fill 50 294 591 51 294 593 minecraft:light_blue_stained_glass
setblock 51 294 558 minecraft:calcite
fill 51 294 559 51 296 559 minecraft:cobbled_deepslate
setblock 51 294 598 minecraft:calcite
fill 52 294 558 52 297 558 minecraft:cobbled_deepslate
fill 52 294 598 52 297 598 minecraft:cobbled_deepslate
setblock 60 294 565 minecraft:deepslate
setblock 60 294 569 minecraft:deepslate
setblock 61 294 570 minecraft:deepslate
fill 62 294 563 65 294 563 minecraft:deepslate
fill 64 294 558 65 294 558 minecraft:cobbled_deepslate
setblock 66 294 558 minecraft:calcite
setblock 66 294 570 minecraft:deepslate
fill 67 294 558 69 294 559 minecraft:cobbled_deepslate
setblock 67 294 565 minecraft:deepslate
setblock 67 294 569 minecraft:deepslate
setblock 70 294 558 minecraft:cobbled_deepslate
setblock 70 294 559 minecraft:calcite
setblock 71 294 558 minecraft:calcite
setblock 71 294 559 minecraft:cobbled_deepslate
fill 72 294 558 72 297 558 minecraft:cobbled_deepslate
fill 79 294 558 79 295 558 minecraft:cobbled_deepslate
setblock 81 294 558 minecraft:calcite
fill 81 294 559 81 297 559 minecraft:cobbled_deepslate
fill 82 294 558 82 297 558 minecraft:cobbled_deepslate
setblock 83 294 560 minecraft:cobbled_deepslate
setblock 84 294 560 minecraft:calcite
setblock 85 294 559 minecraft:calcite
fill 85 294 560 85 294 563 minecraft:cobbled_deepslate
setblock 85 294 564 minecraft:calcite
setblock 86 294 558 minecraft:calcite
fill 86 294 559 86 297 559 minecraft:cobbled_deepslate
setblock 86 294 563 minecraft:calcite
fill 86 294 564 86 297 564 minecraft:cobbled_deepslate
setblock 86 294 567 minecraft:cobbled_deepslate
setblock 86 294 568 minecraft:calcite
setblock 86 294 598 minecraft:calcite
fill 87 294 558 87 297 558 minecraft:cobbled_deepslate
setblock 87 294 562 minecraft:calcite
fill 87 294 563 87 297 563 minecraft:cobbled_deepslate
setblock 87 294 567 minecraft:calcite
fill 87 294 568 87 297 568 minecraft:cobbled_deepslate
fill 87 294 570 87 295 570 minecraft:cobbled_deepslate
setblock 87 294 581 minecraft:cobbled_deepslate
setblock 87 294 582 minecraft:calcite
fill 87 294 583 87 297 583 minecraft:cobbled_deepslate
setblock 87 294 587 minecraft:calcite
fill 87 294 588 87 297 588 minecraft:cobbled_deepslate
fill 87 294 598 87 297 598 minecraft:cobbled_deepslate
setblock 88 294 561 minecraft:calcite
fill 88 294 562 88 297 562 minecraft:cobbled_deepslate
setblock 88 294 566 minecraft:calcite
fill 88 294 567 88 297 567 minecraft:cobbled_deepslate
setblock 88 294 571 minecraft:calcite
fill 88 294 572 88 297 572 minecraft:cobbled_deepslate
fill 88 294 574 88 295 574 minecraft:cobbled_deepslate
setblock 88 294 576 minecraft:calcite
fill 88 294 577 88 297 577 minecraft:cobbled_deepslate
setblock 88 294 581 minecraft:calcite
fill 88 294 582 88 297 582 minecraft:cobbled_deepslate
setblock 88 294 586 minecraft:calcite
fill 88 294 587 88 297 587 minecraft:cobbled_deepslate
setblock 88 294 590 minecraft:cobbled_deepslate
setblock 88 294 591 minecraft:calcite
fill 88 294 592 88 297 592 minecraft:cobbled_deepslate
setblock 88 294 596 minecraft:calcite
fill 88 294 597 88 297 597 minecraft:cobbled_deepslate
setblock 48 295 560 minecraft:calcite
fill 48 295 561 48 298 561 minecraft:cobbled_deepslate
setblock 48 295 565 minecraft:calcite
fill 48 295 566 48 298 566 minecraft:cobbled_deepslate
setblock 48 295 570 minecraft:calcite
fill 48 295 571 48 298 571 minecraft:cobbled_deepslate
fill 48 295 577 48 297 577 minecraft:cobbled_deepslate
setblock 48 295 580 minecraft:calcite
fill 48 295 581 48 295 584 minecraft:cobbled_deepslate
setblock 48 295 585 minecraft:calcite
fill 48 295 586 48 295 589 minecraft:cobbled_deepslate
setblock 48 295 590 minecraft:calcite
fill 48 295 591 48 298 591 minecraft:cobbled_deepslate
setblock 48 295 594 minecraft:cobbled_deepslate
setblock 48 295 595 minecraft:calcite
fill 48 295 596 48 298 596 minecraft:cobbled_deepslate
setblock 49 295 559 minecraft:calcite
fill 49 295 560 49 298 560 minecraft:cobbled_deepslate
setblock 49 295 564 minecraft:calcite
fill 49 295 565 49 298 565 minecraft:cobbled_deepslate
fill 49 295 580 49 296 580 minecraft:cobbled_deepslate
setblock 49 295 584 minecraft:calcite
fill 49 295 585 49 295 588 minecraft:cobbled_deepslate
setblock 49 295 589 minecraft:calcite
fill 49 295 590 50 297 590 minecraft:cobbled_deepslate
setblock 49 295 594 minecraft:calcite
fill 49 295 595 49 298 595 minecraft:cobbled_deepslate
fill 49 295 597 49 295 598 minecraft:cobbled_deepslate
setblock 50 295 558 minecraft:calcite
fill 50 295 559 50 297 559 minecraft:cobbled_deepslate
setblock 50 295 583 minecraft:calcite
fill 50 295 584 50 298 584 minecraft:cobbled_deepslate
setblock 50 295 588 minecraft:calcite
fill 50 295 589 50 298 589 minecraft:cobbled_deepslate
fill 50 295 591 50 296 591 minecraft:cobbled_deepslate
fill 50 295 592 52 295 593 minecraft:light_blue_stained_glass
setblock 50 295 597 minecraft:cobbled_deepslate
setblock 50 295 598 minecraft:calcite
fill 51 295 558 51 298 558 minecraft:cobbled_deepslate
fill 51 295 591 52 295 591 minecraft:light_blue_stained_glass
setblock 51 295 597 minecraft:calcite
fill 51 295 598 51 298 598 minecraft:cobbled_deepslate
setblock 53 295 558 minecraft:cobbled_deepslate
fill 53 295 592 53 296 592 minecraft:light_blue_stained_glass
fill 53 295 598 53 296 598 minecraft:cobbled_deepslate
fill 63 295 566 64 296 567 minecraft:light_blue_stained_glass
setblock 64 295 558 minecraft:cobbled_deepslate
setblock 65 295 558 minecraft:calcite
fill 66 295 558 68 295 559 minecraft:cobbled_deepslate
fill 66 295 598 67 297 598 minecraft:cobbled_deepslate
setblock 69 295 558 minecraft:cobbled_deepslate
setblock 69 295 559 minecraft:calcite
setblock 70 295 558 minecraft:calcite
fill 70 295 559 70 296 559 minecraft:cobbled_deepslate
fill 71 295 558 71 298 558 minecraft:cobbled_deepslate
fill 73 295 558 73 296 558 minecraft:cobbled_deepslate
setblock 80 295 558 minecraft:calcite
fill 81 295 558 81 298 558 minecraft:cobbled_deepslate
setblock 82 295 560 minecraft:cobbled_deepslate
setblock 83 295 560 minecraft:calcite
setblock 84 295 559 minecraft:calcite
fill 84 295 560 85 296 561 minecraft:cobbled_deepslate
setblock 84 295 598 minecraft:cobbled_deepslate
setblock 85 295 558 minecraft:calcite
fill 85 295 559 85 298 559 minecraft:cobbled_deepslate
setblock 85 295 562 minecraft:cobbled_deepslate
setblock 85 295 563 minecraft:calcite
fill 85 295 564 85 296 566 minecraft:cobbled_deepslate
setblock 85 295 598 minecraft:calcite
fill 86 295 558 86 298 558 minecraft:cobbled_deepslate
setblock 86 295 562 minecraft:calcite
fill 86 295 563 86 298 563 minecraft:cobbled_deepslate
setblock 86 295 567 minecraft:calcite
fill 86 295 568 86 297 569 minecraft:cobbled_deepslate
fill 86 295 598 86 298 598 minecraft:cobbled_deepslate
setblock 87 295 561 minecraft:calcite
fill 87 295 562 87 298 562 minecraft:cobbled_deepslate
setblock 87 295 566 minecraft:calcite
fill 87 295 567 87 298 567 minecraft:cobbled_deepslate
setblock 87 295 571 minecraft:calcite
setblock 87 295 581 minecraft:calcite
fill 87 295 582 87 298 582 minecraft:cobbled_deepslate
fill 87 295 584 87 295 585 minecraft:cobbled_deepslate
setblock 87 295 586 minecraft:calcite
fill 87 295 587 87 298 587 minecraft:cobbled_deepslate
fill 87 295 589 87 295 590 minecraft:cobbled_deepslate
setblock 87 295 591 minecraft:calcite
fill 87 295 597 87 298 597 minecraft:cobbled_deepslate
setblock 88 295 560 minecraft:calcite
fill 88 295 561 88 298 561 minecraft:cobbled_deepslate
setblock 88 295 565 minecraft:calcite
fill 88 295 566 88 298 566 minecraft:cobbled_deepslate
setblock 88 295 570 minecraft:calcite
fill 88 295 571 88 298 571 minecraft:cobbled_deepslate
setblock 88 295 575 minecraft:calcite
fill 88 295 576 88 297 576 minecraft:cobbled_deepslate
setblock 88 295 580 minecraft:calcite
fill 88 295 581 88 298 581 minecraft:cobbled_deepslate
setblock 88 295 585 minecraft:calcite
fill 88 295 586 88 298 586 minecraft:cobbled_deepslate
setblock 88 295 590 minecraft:calcite
fill 88 295 591 88 298 591 minecraft:cobbled_deepslate
fill 88 295 593 88 295 594 minecraft:cobbled_deepslate
setblock 88 295 595 minecraft:calcite
fill 88 295 596 88 298 596 minecraft:cobbled_deepslate
setblock 48 296 559 minecraft:calcite
fill 48 296 560 48 299 560 minecraft:cobbled_deepslate
setblock 48 296 564 minecraft:calcite
fill 48 296 565 48 299 565 minecraft:cobbled_deepslate
setblock 48 296 568 minecraft:cobbled_deepslate
setblock 48 296 569 minecraft:calcite
fill 48 296 570 48 299 570 minecraft:cobbled_deepslate
fill 48 296 572 48 297 572 minecraft:cobbled_deepslate
setblock 48 296 579 minecraft:calcite
fill 48 296 580 48 296 583 minecraft:cobbled_deepslate
setblock 48 296 584 minecraft:calcite
fill 48 296 585 48 296 588 minecraft:cobbled_deepslate
setblock 48 296 589 minecraft:calcite
fill 48 296 590 48 299 590 minecraft:cobbled_deepslate
setblock 48 296 593 minecraft:cobbled_deepslate
setblock 48 296 594 minecraft:calcite
fill 48 296 595 48 299 595 minecraft:cobbled_deepslate
setblock 49 296 558 minecraft:calcite
fill 49 296 559 49 298 559 minecraft:cobbled_deepslate
setblock 49 296 563 minecraft:calcite
fill 49 296 564 49 299 564 minecraft:cobbled_deepslate
setblock 49 296 568 minecraft:calcite
setblock 49 296 583 minecraft:calcite
fill 49 296 584 49 296 587 minecraft:cobbled_deepslate
setblock 49 296 588 minecraft:calcite
fill 49 296 589 49 299 589 minecraft:cobbled_deepslate
setblock 49 296 593 minecraft:calcite
fill 49 296 594 49 299 594 minecraft:cobbled_deepslate
setblock 49 296 597 minecraft:cobbled_deepslate
setblock 49 296 598 minecraft:calcite
fill 50 296 558 50 299 558 minecraft:cobbled_deepslate
setblock 50 296 560 minecraft:light[level=14]
setblock 50 296 568 minecraft:light[level=14]
setblock 50 296 576 minecraft:light[level=14]
fill 50 296 583 50 297 583 minecraft:cobbled_deepslate
setblock 50 296 586 minecraft:cobbled_deepslate
setblock 50 296 587 minecraft:calcite
fill 50 296 588 50 299 588 minecraft:cobbled_deepslate
setblock 50 296 592 minecraft:calcite
setblock 50 296 593 minecraft:light_blue_stained_glass
setblock 50 296 597 minecraft:calcite
fill 50 296 598 50 299 598 minecraft:cobbled_deepslate
fill 51 296 592 52 296 592 minecraft:light_blue_stained_glass
setblock 51 296 597 minecraft:cobbled_deepslate
setblock 54 296 592 minecraft:light_blue_stained_glass
setblock 58 296 560 minecraft:light[level=14]
setblock 58 296 568 minecraft:light[level=14]
setblock 58 296 576 minecraft:light[level=14]
setblock 58 296 584 minecraft:light[level=14]
setblock 58 296 592 minecraft:light[level=14]
setblock 63 296 558 minecraft:cobbled_deepslate
setblock 64 296 558 minecraft:calcite
setblock 64 296 598 minecraft:calcite
fill 65 296 558 68 296 558 minecraft:cobbled_deepslate
fill 65 296 598 65 299 598 minecraft:cobbled_deepslate
fill 66 296 559 67 296 559 minecraft:cobbled_deepslate
setblock 66 296 560 minecraft:light[level=14]
setblock 66 296 568 minecraft:light[level=14]
setblock 66 296 576 minecraft:light[level=14]
setblock 66 296 584 minecraft:light[level=14]
setblock 66 296 592 minecraft:light[level=14]
setblock 68 296 559 minecraft:calcite
setblock 69 296 558 minecraft:calcite
fill 69 296 559 69 297 559 minecraft:cobbled_deepslate
fill 70 296 558 70 298 558 minecraft:cobbled_deepslate
setblock 74 296 560 minecraft:light[level=14]
setblock 74 296 568 minecraft:light[level=14]
setblock 74 296 576 minecraft:light[level=14]
setblock 74 296 584 minecraft:light[level=14]
setblock 74 296 592 minecraft:light[level=14]
setblock 78 296 558 minecraft:cobbled_deepslate
setblock 79 296 558 minecraft:calcite
fill 80 296 558 80 298 559 minecraft:cobbled_deepslate
setblock 82 296 560 minecraft:calcite
setblock 82 296 568 minecraft:light[level=14]
setblock 82 296 576 minecraft:light[level=14]
setblock 82 296 584 minecraft:light[level=14]
setblock 82 296 592 minecraft:light[level=14]
setblock 83 296 559 minecraft:calcite
fill 83 296 560 83 298 561 minecraft:cobbled_deepslate
setblock 83 296 598 minecraft:cobbled_deepslate
setblock 84 296 558 minecraft:calcite
fill 84 296 559 84 299 559 minecraft:cobbled_deepslate
setblock 84 296 598 minecraft:calcite
fill 85 296 558 85 299 558 minecraft:cobbled_deepslate
setblock 85 296 562 minecraft:calcite
fill 85 296 563 85 299 563 minecraft:cobbled_deepslate
setblock 85 296 567 minecraft:calcite
fill 85 296 598 85 299 598 minecraft:cobbled_deepslate
setblock 86 296 561 minecraft:calcite
fill 86 296 562 86 299 562 minecraft:cobbled_deepslate
setblock 86 296 565 minecraft:cobbled_deepslate
setblock 86 296 566 minecraft:calcite
fill 86 296 567 86 299 567 minecraft:cobbled_deepslate
setblock 86 296 570 minecraft:cobbled_deepslate
setblock 86 296 586 minecraft:calcite
fill 86 296 587 86 299 587 minecraft:cobbled_deepslate
fill 86 296 597 86 299 597 minecraft:cobbled_deepslate
setblock 87 296 560 minecraft:calcite
fill 87 296 561 87 299 561 minecraft:cobbled_deepslate
setblock 87 296 565 minecraft:calcite
fill 87 296 566 87 299 566 minecraft:cobbled_deepslate
setblock 87 296 570 minecraft:calcite
fill 87 296 571 87 298 572 minecraft:cobbled_deepslate
fill 87 296 581 87 297 581 minecraft:cobbled_deepslate
setblock 87 296 584 minecraft:cobbled_deepslate
setblock 87 296 585 minecraft:calcite
fill 87 296 586 87 299 586 minecraft:cobbled_deepslate
setblock 87 296 589 minecraft:cobbled_deepslate
setblock 87 296 590 minecraft:calcite
fill 87 296 591 87 296 594 minecraft:cobbled_deepslate
setblock 87 296 595 minecraft:calcite
fill 87 296 596 87 299 596 minecraft:cobbled_deepslate
setblock 88 296 559 minecraft:calcite
fill 88 296 560 88 299 560 minecraft:cobbled_deepslate
setblock 88 296 564 minecraft:calcite
fill 88 296 565 88 299 565 minecraft:cobbled_deepslate
setblock 88 296 569 minecraft:calcite
fill 88 296 570 88 299 570 minecraft:cobbled_deepslate
setblock 88 296 574 minecraft:calcite
fill 88 296 575 88 299 575 minecraft:cobbled_deepslate
setblock 88 296 579 minecraft:calcite
fill 88 296 580 88 299 580 minecraft:cobbled_deepslate
setblock 88 296 584 minecraft:calcite
fill 88 296 585 88 299 585 minecraft:cobbled_deepslate
setblock 88 296 589 minecraft:calcite
fill 88 296 590 88 299 590 minecraft:cobbled_deepslate
setblock 88 296 593 minecraft:cobbled_deepslate
setblock 88 296 594 minecraft:calcite
fill 88 296 595 88 299 595 minecraft:cobbled_deepslate
setblock 48 297 558 minecraft:calcite
fill 48 297 559 48 300 559 minecraft:cobbled_deepslate
setblock 48 297 563 minecraft:calcite
fill 48 297 564 48 300 564 minecraft:cobbled_deepslate
setblock 48 297 567 minecraft:cobbled_deepslate
setblock 48 297 568 minecraft:calcite
fill 48 297 569 49 299 569 minecraft:cobbled_deepslate
setblock 48 297 573 minecraft:calcite
setblock 48 297 578 minecraft:calcite
fill 48 297 579 48 297 582 minecraft:cobbled_deepslate
setblock 48 297 583 minecraft:calcite
fill 48 297 584 48 297 587 minecraft:cobbled_deepslate
setblock 48 297 588 minecraft:calcite
fill 48 297 589 48 300 589 minecraft:cobbled_deepslate
setblock 48 297 593 minecraft:calcite
fill 48 297 594 48 300 594 minecraft:cobbled_deepslate
setblock 48 297 597 minecraft:cobbled_deepslate
setblock 48 297 598 minecraft:calcite
fill 49 297 558 49 299 558 minecraft:cobbled_deepslate
setblock 49 297 562 minecraft:calcite
fill 49 297 563 49 299 563 minecraft:cobbled_deepslate
setblock 49 297 567 minecraft:calcite
fill 49 297 568 49 300 568 minecraft:cobbled_deepslate
setblock 49 297 582 minecraft:calcite
fill 49 297 583 49 297 586 minecraft:cobbled_deepslate
setblock 49 297 587 minecraft:calcite
fill 49 297 588 49 300 588 minecraft:cobbled_deepslate
setblock 49 297 592 minecraft:calcite
fill 49 297 593 50 299 593 minecraft:cobbled_deepslate
setblock 49 297 597 minecraft:calcite
fill 49 297 598 49 300 598 minecraft:cobbled_deepslate
fill 50 297 561 50 300 563 minecraft:light_blue_stained_glass
setblock 50 297 586 minecraft:calcite
fill 50 297 587 50 300 587 minecraft:cobbled_deepslate
setblock 50 297 591 minecraft:calcite
fill 50 297 592 50 300 592 minecraft:cobbled_deepslate
fill 50 297 597 50 299 597 minecraft:cobbled_deepslate
fill 51 297 562 51 300 562 minecraft:light_blue_stained_glass
setblock 53 297 598 minecraft:calcite
fill 56 297 561 57 297 562 minecraft:diamond_block
fill 57 297 560 58 298 560 minecraft:diamond_block
fill 57 297 563 58 297 564 minecraft:diamond_block
fill 58 297 559 61 297 559 minecraft:diamond_block
fill 59 297 564 61 297 564 minecraft:diamond_block
fill 60 297 560 62 297 560 minecraft:diamond_block
fill 61 297 561 62 297 563 minecraft:diamond_block
setblock 63 297 558 minecraft:calcite
fill 63 297 567 64 297 567 minecraft:light_blue_stained_glass
setblock 63 297 598 minecraft:calcite
fill 64 297 558 67 297 558 minecraft:cobbled_deepslate
fill 64 297 598 64 300 598 minecraft:cobbled_deepslate
fill 65 297 559 66 297 559 minecraft:cobbled_deepslate
setblock 67 297 559 minecraft:calcite
setblock 68 297 558 minecraft:calcite
setblock 68 297 559 minecraft:cobbled_deepslate
fill 69 297 558 69 299 558 minecraft:cobbled_deepslate
fill 73 297 558 73 300 558 minecraft:light_blue_stained_glass
fill 73 297 582 74 297 585 minecraft:diamond_block
fill 74 297 581 81 297 581 minecraft:diamond_block
fill 74 297 586 76 297 586 minecraft:diamond_block
fill 75 297 580 80 297 580 minecraft:diamond_block
fill 75 297 582 75 299 582 minecraft:diamond_block
fill 75 297 585 75 299 585 minecraft:diamond_block
fill 75 297 587 80 297 587 minecraft:diamond_block
fill 76 297 588 78 297 588 minecraft:diamond_block
setblock 78 297 558 minecraft:calcite
fill 78 297 586 81 297 586 minecraft:diamond_block
fill 79 297 558 79 300 558 minecraft:cobbled_deepslate
fill 80 297 582 81 297 585 minecraft:diamond_block
setblock 81 297 560 minecraft:calcite
setblock 82 297 559 minecraft:calcite
fill 82 297 560 82 300 560 minecraft:cobbled_deepslate
setblock 82 297 598 minecraft:cobbled_deepslate
setblock 83 297 558 minecraft:calcite
fill 83 297 559 83 300 559 minecraft:cobbled_deepslate
setblock 83 297 598 minecraft:calcite
fill 84 297 558 84 300 558 minecraft:cobbled_deepslate
fill 84 297 560 84 297 561 minecraft:cobbled_deepslate
fill 84 297 598 84 300 598 minecraft:cobbled_deepslate
setblock 85 297 560 minecraft:cobbled_deepslate
setblock 85 297 561 minecraft:calcite
fill 85 297 562 85 300 562 minecraft:cobbled_deepslate
fill 85 297 564 85 297 565 minecraft:cobbled_deepslate
setblock 85 297 566 minecraft:calcite
fill 85 297 567 85 299 568 minecraft:cobbled_deepslate
fill 85 297 597 85 300 597 minecraft:cobbled_deepslate
setblock 86 297 560 minecraft:calcite
fill 86 297 561 86 300 561 minecraft:cobbled_deepslate
setblock 86 297 565 minecraft:calcite
fill 86 297 566 86 300 566 minecraft:cobbled_deepslate
setblock 86 297 570 minecraft:calcite
setblock 86 297 585 minecraft:calcite
fill 86 297 586 86 299 586 minecraft:cobbled_deepslate
fill 86 297 588 86 297 589 minecraft:cobbled_deepslate
setblock 86 297 590 minecraft:calcite
setblock 87 297 559 minecraft:calcite
fill 87 297 560 87 300 560 minecraft:cobbled_deepslate
setblock 87 297 564 minecraft:calcite
fill 87 297 565 87 300 565 minecraft:cobbled_deepslate
setblock 87 297 569 minecraft:calcite
fill 87 297 570 87 300 570 minecraft:cobbled_deepslate
setblock 87 297 584 minecraft:calcite
fill 87 297 585 87 300 585 minecraft:cobbled_deepslate
setblock 87 297 589 minecraft:calcite
fill 87 297 590 87 297 593 minecraft:cobbled_deepslate
setblock 87 297 594 minecraft:calcite
fill 87 297 595 87 300 595 minecraft:cobbled_deepslate
setblock 88 297 558 minecraft:calcite
fill 88 297 559 88 300 559 minecraft:cobbled_deepslate
setblock 88 297 563 minecraft:calcite
fill 88 297 564 88 300 564 minecraft:cobbled_deepslate
setblock 88 297 568 minecraft:calcite
fill 88 297 569 88 300 569 minecraft:cobbled_deepslate
setblock 88 297 573 minecraft:calcite
fill 88 297 574 88 300 574 minecraft:cobbled_deepslate
setblock 88 297 578 minecraft:calcite
fill 88 297 579 88 298 579 minecraft:cobbled_deepslate
setblock 88 297 583 minecraft:calcite
fill 88 297 584 88 300 584 minecraft:cobbled_deepslate
setblock 88 297 588 minecraft:calcite
fill 88 297 589 88 300 589 minecraft:cobbled_deepslate
setblock 88 297 593 minecraft:calcite
fill 88 297 594 88 300 594 minecraft:cobbled_deepslate
setblock 88 297 598 minecraft:calcite
fill 48 298 558 48 300 558 minecraft:cobbled_deepslate
setblock 48 298 562 minecraft:calcite
fill 48 298 563 48 300 563 minecraft:cobbled_deepslate
setblock 48 298 567 minecraft:calcite
fill 48 298 568 48 300 568 minecraft:cobbled_deepslate
setblock 48 298 572 minecraft:calcite
fill 48 298 573 48 299 574 minecraft:cobbled_deepslate
fill 48 298 578 48 298 581 minecraft:cobbled_deepslate
setblock 48 298 582 minecraft:calcite
fill 48 298 583 48 298 586 minecraft:cobbled_deepslate
setblock 48 298 587 minecraft:calcite
fill 48 298 588 48 300 588 minecraft:cobbled_deepslate
setblock 48 298 592 minecraft:calcite
fill 48 298 593 48 300 593 minecraft:cobbled_deepslate
setblock 48 298 597 minecraft:calcite
fill 48 298 598 48 300 598 minecraft:cobbled_deepslate
setblock 49 298 561 minecraft:calcite
fill 49 298 562 49 299 562 minecraft:cobbled_deepslate
setblock 49 298 566 minecraft:calcite
fill 49 298 567 49 300 567 minecraft:cobbled_deepslate
setblock 49 298 581 minecraft:calcite
fill 49 298 582 49 298 585 minecraft:cobbled_deepslate
setblock 49 298 586 minecraft:calcite
fill 49 298 587 49 300 587 minecraft:cobbled_deepslate
setblock 49 298 590 minecraft:cobbled_deepslate
setblock 49 298 591 minecraft:calcite
fill 49 298 592 49 300 592 minecraft:cobbled_deepslate
setblock 49 298 596 minecraft:calcite
fill 49 298 597 49 300 597 minecraft:cobbled_deepslate
fill 50 298 560 50 300 560 minecraft:light_blue_stained_glass
fill 50 298 564 50 300 564 minecraft:light_blue_stained_glass
setblock 50 298 585 minecraft:calcite
fill 50 298 586 50 300 586 minecraft:cobbled_deepslate
setblock 50 298 590 minecraft:calcite
fill 50 298 591 50 300 591 minecraft:cobbled_deepslate
fill 51 298 561 51 300 561 minecraft:light_blue_stained_glass
fill 51 298 563 51 300 563 minecraft:light_blue_stained_glass
fill 52 298 562 52 300 562 minecraft:light_blue_stained_glass
setblock 52 298 598 minecraft:calcite
fill 57 298 561 57 298 563 minecraft:diamond_block
fill 58 298 563 58 298 564 minecraft:diamond_block
fill 59 298 559 60 298 559 minecraft:diamond_block
fill 59 298 564 60 298 564 minecraft:diamond_block
fill 60 298 560 61 298 560 minecraft:diamond_block
fill 61 298 561 61 298 563 minecraft:diamond_block
fill 63 298 558 66 298 558 minecraft:cobbled_deepslate
fill 63 298 598 63 300 598 minecraft:cobbled_deepslate
setblock 64 298 567 minecraft:light_blue_stained_glass
setblock 66 298 559 minecraft:calcite
setblock 66 298 598 minecraft:cobbled_deepslate
setblock 67 298 558 minecraft:calcite
setblock 67 298 559 minecraft:cobbled_deepslate
setblock 67 298 598 minecraft:calcite
fill 68 298 558 68 299 558 minecraft:cobbled_deepslate
fill 72 298 558 72 300 561 minecraft:light_blue_stained_glass
fill 73 298 559 73 300 563 minecraft:light_blue_stained_glass
fill 74 298 558 74 300 561 minecraft:light_blue_stained_glass
fill 74 298 582 74 298 585 minecraft:diamond_block
fill 75 298 558 75 300 558 minecraft:light_blue_stained_glass
fill 75 298 581 80 298 581 minecraft:diamond_block
fill 75 298 586 76 298 586 minecraft:diamond_block
fill 76 298 580 78 298 580 minecraft:diamond_block
fill 76 298 587 79 298 587 minecraft:diamond_block
fill 78 298 558 78 300 558 minecraft:cobbled_deepslate
fill 78 298 586 80 298 586 minecraft:diamond_block
setblock 79 298 559 minecraft:cobbled_deepslate
fill 80 298 582 80 298 585 minecraft:diamond_block
setblock 81 298 559 minecraft:calcite
fill 81 298 560 81 299 560 minecraft:cobbled_deepslate
fill 81 298 583 81 298 584 minecraft:diamond_block
setblock 82 298 558 minecraft:calcite
fill 82 298 559 82 300 559 minecraft:cobbled_deepslate
setblock 82 298 598 minecraft:calcite
fill 83 298 558 83 300 558 minecraft:cobbled_deepslate
fill 83 298 598 83 300 598 minecraft:cobbled_deepslate
setblock 84 298 560 minecraft:cobbled_deepslate
setblock 84 298 561 minecraft:calcite
fill 84 298 597 84 300 597 minecraft:cobbled_deepslate
setblock 85 298 560 minecraft:calcite
fill 85 298 561 85 299 561 minecraft:cobbled_deepslate
setblock 85 298 564 minecraft:cobbled_deepslate
setblock 85 298 565 minecraft:calcite
fill 85 298 566 85 300 566 minecraft:cobbled_deepslate
setblock 85 298 569 minecraft:cobbled_deepslate
setblock 86 298 559 minecraft:calcite
fill 86 298 560 86 300 560 minecraft:cobbled_deepslate
setblock 86 298 564 minecraft:calcite
fill 86 298 565 86 300 565 minecraft:cobbled_deepslate
setblock 86 298 568 minecraft:cobbled_deepslate
setblock 86 298 569 minecraft:calcite
fill 86 298 570 86 300 571 minecraft:cobbled_deepslate
setblock 86 298 585 minecraft:cobbled_deepslate
setblock 86 298 588 minecraft:cobbled_deepslate
setblock 86 298 589 minecraft:calcite
fill 86 298 590 86 298 593 minecraft:cobbled_deepslate
setblock 87 298 558 minecraft:calcite
fill 87 298 559 87 300 559 minecraft:cobbled_deepslate
setblock 87 298 563 minecraft:calcite
fill 87 298 564 87 300 564 minecraft:cobbled_deepslate
setblock 87 298 568 minecraft:calcite
fill 87 298 569 87 300 569 minecraft:cobbled_deepslate
setblock 87 298 573 minecraft:calcite
setblock 87 298 583 minecraft:calcite
fill 87 298 584 87 300 584 minecraft:cobbled_deepslate
setblock 87 298 588 minecraft:calcite
fill 87 298 589 87 298 592 minecraft:cobbled_deepslate
setblock 87 298 593 minecraft:calcite
fill 87 298 594 87 300 594 minecraft:cobbled_deepslate
setblock 87 298 598 minecraft:calcite
fill 88 298 558 88 300 558 minecraft:cobbled_deepslate
setblock 88 298 562 minecraft:calcite
fill 88 298 563 88 300 563 minecraft:cobbled_deepslate
setblock 88 298 567 minecraft:calcite
fill 88 298 568 88 300 568 minecraft:cobbled_deepslate
setblock 88 298 572 minecraft:calcite
fill 88 298 573 88 300 573 minecraft:cobbled_deepslate
setblock 88 298 582 minecraft:calcite
fill 88 298 583 88 300 583 minecraft:cobbled_deepslate
setblock 88 298 587 minecraft:calcite
fill 88 298 588 88 300 588 minecraft:cobbled_deepslate
setblock 88 298 592 minecraft:calcite
fill 88 298 593 88 300 593 minecraft:cobbled_deepslate
setblock 88 298 597 minecraft:calcite
fill 88 298 598 88 300 598 minecraft:cobbled_deepslate
setblock 48 299 561 minecraft:calcite
fill 48 299 562 48 300 562 minecraft:cobbled_deepslate
setblock 48 299 566 minecraft:calcite
fill 48 299 567 48 300 567 minecraft:cobbled_deepslate
setblock 48 299 571 minecraft:calcite
fill 48 299 572 48 300 572 minecraft:cobbled_deepslate
fill 48 299 579 48 299 580 minecraft:cobbled_deepslate
setblock 48 299 581 minecraft:calcite
fill 48 299 582 48 299 585 minecraft:cobbled_deepslate
setblock 48 299 586 minecraft:calcite
fill 48 299 587 48 300 587 minecraft:cobbled_deepslate
setblock 48 299 591 minecraft:calcite
fill 48 299 592 48 300 592 minecraft:cobbled_deepslate
setblock 48 299 596 minecraft:calcite
fill 48 299 597 48 300 597 minecraft:cobbled_deepslate
fill 49 299 560 49 300 561 minecraft:light_blue_stained_glass
setblock 49 299 565 minecraft:calcite
fill 49 299 566 49 300 566 minecraft:cobbled_deepslate
fill 49 299 582 49 299 584 minecraft:cobbled_deepslate
setblock 49 299 585 minecraft:calcite
fill 49 299 586 49 300 586 minecraft:cobbled_deepslate
setblock 49 299 590 minecraft:calcite
fill 49 299 591 49 300 591 minecraft:cobbled_deepslate
setblock 49 299 595 minecraft:calcite
fill 49 299 596 49 300 596 minecraft:cobbled_deepslate
setblock 50 299 585 minecraft:cobbled_deepslate
setblock 50 299 589 minecraft:calcite
fill 50 299 590 50 300 590 minecraft:cobbled_deepslate
fill 51 299 560 51 300 560 minecraft:light_blue_stained_glass
fill 51 299 564 51 300 564 minecraft:light_blue_stained_glass
setblock 51 299 598 minecraft:calcite
fill 52 299 561 52 300 561 minecraft:light_blue_stained_glass
fill 52 299 563 52 300 563 minecraft:light_blue_stained_glass
setblock 52 299 598 minecraft:cobbled_deepslate
fill 53 299 562 53 300 562 minecraft:light_blue_stained_glass
fill 57 299 561 57 299 562 minecraft:diamond_block
setblock 58 299 560 minecraft:diamond_block
setblock 58 299 563 minecraft:diamond_block
setblock 60 299 560 minecraft:diamond_block
fill 61 299 561 61 299 562 minecraft:diamond_block
fill 62 299 598 62 300 598 minecraft:cobbled_deepslate
fill 63 299 558 65 299 558 minecraft:cobbled_deepslate
setblock 66 299 558 minecraft:calcite
setblock 66 299 598 minecraft:calcite
fill 67 299 558 67 300 558 minecraft:cobbled_deepslate
fill 71 299 558 71 300 560 minecraft:light_blue_stained_glass
fill 72 299 562 72 299 563 minecraft:light_blue_stained_glass
fill 73 299 564 73 299 565 minecraft:light_blue_stained_glass
fill 74 299 562 74 299 563 minecraft:light_blue_stained_glass
fill 75 299 559 75 300 560 minecraft:light_blue_stained_glass
fill 76 299 581 78 299 581 minecraft:diamond_block
setblock 76 299 586 minecraft:diamond_block
fill 78 299 586 79 299 586 minecraft:diamond_block
setblock 80 299 558 minecraft:cobbled_deepslate
setblock 80 299 559 minecraft:calcite
fill 80 299 583 80 299 585 minecraft:diamond_block
setblock 81 299 558 minecraft:calcite
fill 81 299 559 81 300 559 minecraft:cobbled_deepslate
setblock 81 299 598 minecraft:calcite
fill 82 299 558 82 300 558 minecraft:cobbled_deepslate
fill 82 299 598 82 300 598 minecraft:cobbled_deepslate
setblock 83 299 560 minecraft:cobbled_deepslate
setblock 83 299 561 minecraft:calcite
fill 83 299 597 83 300 597 minecraft:cobbled_deepslate
setblock 84 299 560 minecraft:calcite
setblock 84 299 561 minecraft:cobbled_deepslate
setblock 85 299 559 minecraft:calcite
fill 85 299 560 85 300 560 minecraft:cobbled_deepslate
setblock 85 299 564 minecraft:calcite
fill 85 299 565 85 300 565 minecraft:cobbled_deepslate
setblock 85 299 569 minecraft:calcite
setblock 86 299 558 minecraft:calcite
fill 86 299 559 86 300 559 minecraft:cobbled_deepslate
setblock 86 299 563 minecraft:calcite
fill 86 299 564 86 300 564 minecraft:cobbled_deepslate
setblock 86 299 568 minecraft:calcite
fill 86 299 569 86 300 569 minecraft:cobbled_deepslate
setblock 86 299 588 minecraft:calcite
fill 86 299 589 86 299 592 minecraft:cobbled_deepslate
setblock 86 299 593 minecraft:calcite
fill 86 299 594 86 300 594 minecraft:cobbled_deepslate
setblock 86 299 598 minecraft:calcite
fill 87 299 558 87 300 558 minecraft:cobbled_deepslate
setblock 87 299 562 minecraft:calcite
fill 87 299 563 87 300 563 minecraft:cobbled_deepslate
setblock 87 299 567 minecraft:calcite
fill 87 299 568 87 300 568 minecraft:cobbled_deepslate
setblock 87 299 571 minecraft:cobbled_deepslate
setblock 87 299 572 minecraft:calcite
setblock 87 299 573 minecraft:cobbled_deepslate
setblock 87 299 583 minecraft:cobbled_deepslate
setblock 87 299 587 minecraft:calcite
fill 87 299 588 87 299 591 minecraft:cobbled_deepslate
setblock 87 299 592 minecraft:calcite
fill 87 299 593 87 300 593 minecraft:cobbled_deepslate
setblock 87 299 597 minecraft:calcite
fill 87 299 598 87 300 598 minecraft:cobbled_deepslate
setblock 88 299 561 minecraft:calcite
fill 88 299 562 88 300 562 minecraft:cobbled_deepslate
setblock 88 299 566 minecraft:calcite
fill 88 299 567 88 300 567 minecraft:cobbled_deepslate
setblock 88 299 571 minecraft:calcite
fill 88 299 572 88 300 572 minecraft:cobbled_deepslate
setblock 88 299 581 minecraft:calcite
fill 88 299 582 88 300 582 minecraft:cobbled_deepslate
setblock 88 299 586 minecraft:calcite
fill 88 299 587 88 300 587 minecraft:cobbled_deepslate
setblock 88 299 591 minecraft:calcite
fill 88 299 592 88 300 592 minecraft:cobbled_deepslate
setblock 88 299 596 minecraft:calcite
fill 88 299 597 88 300 597 minecraft:cobbled_deepslate
setblock 48 300 560 minecraft:calcite
setblock 48 300 561 minecraft:cobbled_deepslate
setblock 48 300 565 minecraft:calcite
setblock 48 300 566 minecraft:cobbled_deepslate
setblock 48 300 569 minecraft:cobbled_deepslate
setblock 48 300 570 minecraft:calcite
setblock 48 300 571 minecraft:cobbled_deepslate
setblock 48 300 573 minecraft:cobbled_deepslate
setblock 48 300 580 minecraft:calcite
fill 48 300 581 48 300 584 minecraft:cobbled_deepslate
setblock 48 300 585 minecraft:calcite
setblock 48 300 586 minecraft:cobbled_deepslate
setblock 48 300 590 minecraft:calcite
setblock 48 300 591 minecraft:cobbled_deepslate
setblock 48 300 595 minecraft:calcite
setblock 48 300 596 minecraft:cobbled_deepslate
fill 49 300 562 49 300 564 minecraft:light_blue_stained_glass
setblock 49 300 565 minecraft:cobbled_deepslate
setblock 49 300 583 minecraft:cobbled_deepslate
setblock 49 300 584 minecraft:calcite
setblock 49 300 585 minecraft:cobbled_deepslate
setblock 49 300 589 minecraft:calcite
setblock 49 300 590 minecraft:cobbled_deepslate
setblock 49 300 593 minecraft:cobbled_deepslate
setblock 49 300 594 minecraft:calcite
setblock 49 300 595 minecraft:cobbled_deepslate
setblock 50 300 588 minecraft:calcite
setblock 50 300 589 minecraft:cobbled_deepslate
setblock 50 300 593 minecraft:calcite
setblock 50 300 598 minecraft:calcite
setblock 51 300 598 minecraft:cobbled_deepslate
setblock 53 300 561 minecraft:light_blue_stained_glass
setblock 53 300 563 minecraft:light_blue_stained_glass
setblock 54 300 562 minecraft:light_blue_stained_glass
setblock 64 300 558 minecraft:cobbled_deepslate
setblock 65 300 558 minecraft:calcite
setblock 65 300 598 minecraft:calcite
setblock 66 300 558 minecraft:cobbled_deepslate
setblock 72 300 562 minecraft:light_blue_stained_glass
setblock 74 300 562 minecraft:light_blue_stained_glass
setblock 80 300 558 minecraft:calcite
setblock 80 300 559 minecraft:cobbled_deepslate
setblock 81 300 558 minecraft:cobbled_deepslate
setblock 81 300 598 minecraft:cobbled_deepslate
setblock 83 300 560 minecraft:calcite
setblock 84 300 559 minecraft:calcite
setblock 84 300 560 minecraft:cobbled_deepslate
setblock 85 300 558 minecraft:calcite
setblock 85 300 559 minecraft:cobbled_deepslate
setblock 85 300 563 minecraft:calcite
setblock 85 300 564 minecraft:cobbled_deepslate
setblock 85 300 567 minecraft:cobbled_deepslate
setblock 85 300 568 minecraft:calcite
setblock 85 300 569 minecraft:cobbled_deepslate
setblock 85 300 598 minecraft:calcite
setblock 86 300 558 minecraft:cobbled_deepslate
setblock 86 300 562 minecraft:calcite
setblock 86 300 563 minecraft:cobbled_deepslate
setblock 86 300 567 minecraft:calcite
setblock 86 300 568 minecraft:cobbled_deepslate
setblock 86 300 587 minecraft:calcite
fill 86 300 588 86 300 591 minecraft:cobbled_deepslate
setblock 86 300 592 minecraft:calcite
setblock 86 300 593 minecraft:cobbled_deepslate
setblock 86 300 595 minecraft:cobbled_deepslate
setblock 86 300 597 minecraft:calcite
setblock 86 300 598 minecraft:cobbled_deepslate
setblock 87 300 561 minecraft:calcite
setblock 87 300 562 minecraft:cobbled_deepslate
setblock 87 300 566 minecraft:calcite
setblock 87 300 567 minecraft:cobbled_deepslate
setblock 87 300 571 minecraft:calcite
setblock 87 300 572 minecraft:cobbled_deepslate
setblock 87 300 586 minecraft:calcite
fill 87 300 587 87 300 590 minecraft:cobbled_deepslate
setblock 87 300 591 minecraft:calcite
setblock 87 300 592 minecraft:cobbled_deepslate
setblock 87 300 596 minecraft:calcite
setblock 87 300 597 minecraft:cobbled_deepslate
setblock 88 300 560 minecraft:calcite
setblock 88 300 561 minecraft:cobbled_deepslate
setblock 88 300 565 minecraft:calcite
setblock 88 300 566 minecraft:cobbled_deepslate
setblock 88 300 570 minecraft:calcite
setblock 88 300 571 minecraft:cobbled_deepslate
setblock 88 300 585 minecraft:calcite
setblock 88 300 586 minecraft:cobbled_deepslate
setblock 88 300 590 minecraft:calcite
schedule function dropper:buildpart/133_11 1t
