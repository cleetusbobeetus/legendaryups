setblock 153 201 323 minecraft:dark_prismarine
fill 153 201 324 155 201 324 minecraft:blue_terracotta
fill 154 201 323 157 201 323 minecraft:blue_terracotta
setblock 158 201 323 minecraft:dark_prismarine
fill 159 201 323 162 201 323 minecraft:blue_terracotta
setblock 159 201 363 minecraft:purple_concrete
fill 160 201 324 161 201 324 minecraft:blue_terracotta
setblock 162 201 324 minecraft:dark_prismarine
setblock 162 201 325 minecraft:blue_terracotta
setblock 163 201 323 minecraft:dark_prismarine
fill 163 201 324 166 201 324 minecraft:blue_terracotta
fill 164 201 323 167 201 323 minecraft:blue_terracotta
setblock 164 201 326 minecraft:blue_terracotta
fill 164 201 363 167 201 363 minecraft:blue_terracotta
setblock 165 201 326 minecraft:dark_prismarine
setblock 166 201 325 minecraft:dark_prismarine
fill 166 201 326 166 203 326 minecraft:blue_terracotta
setblock 167 201 324 minecraft:dark_prismarine
fill 167 201 325 167 204 325 minecraft:blue_terracotta
fill 167 201 362 168 201 362 minecraft:blue_terracotta
setblock 168 201 323 minecraft:dark_prismarine
fill 168 201 324 168 204 324 minecraft:blue_terracotta
setblock 168 201 363 minecraft:dark_prismarine
fill 169 201 323 169 204 323 minecraft:blue_terracotta
setblock 169 201 362 minecraft:dark_prismarine
fill 169 201 363 169 204 363 minecraft:blue_terracotta
setblock 170 201 326 minecraft:dark_prismarine
fill 170 201 362 170 203 362 minecraft:blue_terracotta
setblock 171 201 325 minecraft:dark_prismarine
fill 171 201 326 171 202 326 minecraft:blue_terracotta
setblock 172 201 324 minecraft:dark_prismarine
fill 172 201 325 172 203 325 minecraft:blue_terracotta
setblock 173 201 323 minecraft:dark_prismarine
fill 173 201 324 173 203 324 minecraft:blue_terracotta
setblock 173 201 363 minecraft:dark_prismarine
fill 174 201 323 174 204 323 minecraft:blue_terracotta
setblock 174 201 362 minecraft:dark_prismarine
fill 174 201 363 174 203 363 minecraft:blue_terracotta
setblock 177 201 324 minecraft:dark_prismarine
setblock 178 201 323 minecraft:dark_prismarine
setblock 178 201 363 minecraft:dark_prismarine
fill 179 201 322 179 201 323 minecraft:blue_terracotta
setblock 179 201 363 minecraft:blue_terracotta
setblock 180 201 322 minecraft:cyan_concrete
fill 181 201 322 181 220 322 minecraft:blue_terracotta
fill 181 201 348 181 201 349 minecraft:blue_terracotta
setblock 181 201 350 minecraft:dark_prismarine
fill 181 201 351 181 204 351 minecraft:blue_terracotta
fill 181 201 353 182 201 353 minecraft:blue_terracotta
setblock 182 201 324 minecraft:dark_prismarine
fill 182 201 325 182 202 325 minecraft:blue_terracotta
setblock 182 201 329 minecraft:dark_prismarine
setblock 182 201 344 minecraft:dark_prismarine
fill 182 201 345 182 203 345 minecraft:blue_terracotta
setblock 182 201 349 minecraft:dark_prismarine
fill 182 201 350 182 204 350 minecraft:blue_terracotta
setblock 182 201 354 minecraft:dark_prismarine
fill 182 201 355 182 204 355 minecraft:blue_terracotta
setblock 182 201 359 minecraft:dark_prismarine
fill 182 201 360 182 204 360 minecraft:blue_terracotta
setblock 142 202 323 minecraft:purple_concrete
setblock 142 202 327 minecraft:blue_terracotta
setblock 142 202 328 minecraft:dark_prismarine
fill 142 202 329 142 205 329 minecraft:blue_terracotta
setblock 142 202 332 minecraft:blue_terracotta
setblock 142 202 343 minecraft:dark_prismarine
fill 142 202 344 142 205 344 minecraft:blue_terracotta
setblock 142 202 348 minecraft:dark_prismarine
fill 142 202 349 142 205 349 minecraft:blue_terracotta
setblock 142 202 353 minecraft:dark_prismarine
fill 142 202 354 142 205 354 minecraft:blue_terracotta
setblock 143 202 343 minecraft:blue_terracotta
setblock 143 202 347 minecraft:dark_prismarine
fill 143 202 348 143 205 348 minecraft:blue_terracotta
setblock 143 202 352 minecraft:dark_prismarine
fill 143 202 353 143 205 353 minecraft:blue_terracotta
fill 144 202 323 146 202 323 minecraft:blue_terracotta
setblock 144 202 345 minecraft:blue_terracotta
setblock 144 202 346 minecraft:dark_prismarine
fill 144 202 347 144 205 347 minecraft:blue_terracotta
setblock 144 202 350 minecraft:blue_terracotta
setblock 144 202 351 minecraft:dark_prismarine
fill 144 202 352 144 205 352 minecraft:blue_terracotta
setblock 145 202 350 minecraft:dark_prismarine
fill 145 202 351 145 203 351 minecraft:blue_terracotta
setblock 146 202 363 minecraft:purple_concrete
fill 146 202 364 146 220 364 minecraft:blue_terracotta
setblock 147 202 323 minecraft:dark_prismarine
setblock 147 202 324 minecraft:blue_terracotta
setblock 147 202 363 minecraft:dark_prismarine
fill 148 202 323 148 204 323 minecraft:blue_terracotta
setblock 148 202 363 minecraft:blue_terracotta
setblock 151 202 324 minecraft:dark_prismarine
setblock 152 202 323 minecraft:dark_prismarine
fill 152 202 324 153 202 324 minecraft:blue_terracotta
fill 153 202 323 156 202 323 minecraft:blue_terracotta
setblock 157 202 323 minecraft:dark_prismarine
fill 158 202 323 161 202 323 minecraft:blue_terracotta
setblock 161 202 324 minecraft:dark_prismarine
setblock 162 202 323 minecraft:dark_prismarine
fill 162 202 324 165 202 324 minecraft:blue_terracotta
fill 163 202 323 166 202 323 minecraft:blue_terracotta
fill 164 202 363 166 202 363 minecraft:blue_terracotta
setblock 165 202 325 minecraft:dark_prismarine
setblock 165 202 326 minecraft:blue_terracotta
setblock 166 202 324 minecraft:dark_prismarine
fill 166 202 325 166 205 325 minecraft:blue_terracotta
setblock 167 202 323 minecraft:dark_prismarine
fill 167 202 324 167 205 324 minecraft:blue_terracotta
setblock 167 202 363 minecraft:dark_prismarine
fill 168 202 323 168 205 323 minecraft:blue_terracotta
setblock 168 202 362 minecraft:dark_prismarine
fill 168 202 363 168 205 363 minecraft:blue_terracotta
setblock 169 202 326 minecraft:dark_prismarine
fill 169 202 362 169 203 362 minecraft:blue_terracotta
setblock 170 202 325 minecraft:dark_prismarine
setblock 170 202 326 minecraft:blue_terracotta
setblock 171 202 324 minecraft:dark_prismarine
fill 171 202 325 171 203 325 minecraft:blue_terracotta
fill 171 202 355 171 204 355 minecraft:magenta_terracotta
setblock 172 202 323 minecraft:dark_prismarine
fill 172 202 324 172 204 324 minecraft:blue_terracotta
setblock 172 202 363 minecraft:dark_prismarine
fill 173 202 323 173 204 323 minecraft:blue_terracotta
fill 173 202 363 173 204 363 minecraft:blue_terracotta
setblock 177 202 323 minecraft:dark_prismarine
setblock 177 202 363 minecraft:dark_prismarine
setblock 178 202 323 minecraft:blue_terracotta
fill 179 202 322 180 216 322 minecraft:blue_terracotta
setblock 181 202 348 minecraft:blue_terracotta
setblock 181 202 349 minecraft:dark_prismarine
fill 181 202 350 181 205 350 minecraft:blue_terracotta
setblock 181 202 353 minecraft:blue_terracotta
setblock 181 202 354 minecraft:dark_prismarine
setblock 182 202 324 minecraft:blue_terracotta
setblock 182 202 328 minecraft:dark_prismarine
fill 182 202 329 182 204 330 minecraft:blue_terracotta
setblock 182 202 344 minecraft:purple_concrete
setblock 182 202 348 minecraft:dark_prismarine
fill 182 202 349 182 205 349 minecraft:blue_terracotta
setblock 182 202 353 minecraft:dark_prismarine
fill 182 202 354 182 205 354 minecraft:blue_terracotta
setblock 182 202 358 minecraft:dark_prismarine
fill 182 202 359 182 205 359 minecraft:blue_terracotta
setblock 182 202 363 minecraft:dark_prismarine
setblock 142 203 327 minecraft:dark_prismarine
fill 142 203 328 142 206 328 minecraft:blue_terracotta
setblock 142 203 332 minecraft:dark_prismarine
fill 142 203 333 142 206 333 minecraft:blue_terracotta
setblock 142 203 342 minecraft:dark_prismarine
fill 142 203 343 142 206 343 minecraft:blue_terracotta
setblock 142 203 347 minecraft:dark_prismarine
fill 142 203 348 142 206 348 minecraft:blue_terracotta
setblock 142 203 352 minecraft:dark_prismarine
fill 142 203 353 142 206 353 minecraft:blue_terracotta
setblock 142 203 357 minecraft:dark_prismarine
setblock 143 203 346 minecraft:dark_prismarine
fill 143 203 347 143 206 347 minecraft:blue_terracotta
setblock 143 203 351 minecraft:dark_prismarine
fill 143 203 352 143 206 352 minecraft:blue_terracotta
setblock 144 203 325 minecraft:light[level=12]
setblock 144 203 332 minecraft:light[level=12]
setblock 144 203 339 minecraft:light[level=12]
setblock 144 203 345 minecraft:dark_prismarine
fill 144 203 346 144 204 346 minecraft:blue_terracotta
setblock 144 203 350 minecraft:dark_prismarine
fill 144 203 351 144 206 351 minecraft:blue_terracotta
setblock 144 203 354 minecraft:blue_terracotta
setblock 144 203 360 minecraft:light[level=12]
setblock 145 203 323 minecraft:blue_terracotta
setblock 145 203 349 minecraft:dark_prismarine
setblock 145 203 350 minecraft:blue_terracotta
setblock 146 203 323 minecraft:dark_prismarine
fill 147 203 323 147 204 323 minecraft:blue_terracotta
setblock 151 203 323 minecraft:dark_prismarine
setblock 151 203 325 minecraft:light[level=12]
setblock 151 203 332 minecraft:light[level=12]
setblock 151 203 339 minecraft:light[level=12]
setblock 151 203 346 minecraft:light[level=12]
setblock 151 203 353 minecraft:light[level=12]
setblock 151 203 360 minecraft:light[level=12]
fill 152 203 323 153 203 323 minecraft:blue_terracotta
setblock 152 203 363 minecraft:purple_concrete
fill 155 203 331 155 234 331 minecraft:magenta_terracotta
setblock 158 203 325 minecraft:light[level=12]
setblock 158 203 332 minecraft:light[level=12]
setblock 158 203 339 minecraft:light[level=12]
setblock 158 203 346 minecraft:light[level=12]
setblock 158 203 353 minecraft:light[level=12]
setblock 158 203 360 minecraft:light[level=12]
setblock 160 203 323 minecraft:blue_terracotta
setblock 161 203 323 minecraft:dark_prismarine
fill 162 203 323 164 203 324 minecraft:blue_terracotta
setblock 164 203 325 minecraft:dark_prismarine
setblock 165 203 323 minecraft:blue_terracotta
setblock 165 203 324 minecraft:dark_prismarine
fill 165 203 325 165 205 325 minecraft:blue_terracotta
setblock 165 203 332 minecraft:light[level=12]
setblock 165 203 339 minecraft:light[level=12]
setblock 165 203 346 minecraft:light[level=12]
setblock 165 203 353 minecraft:light[level=12]
setblock 165 203 360 minecraft:light[level=12]
setblock 165 203 363 minecraft:blue_terracotta
setblock 166 203 323 minecraft:dark_prismarine
fill 166 203 324 166 206 324 minecraft:blue_terracotta
setblock 166 203 363 minecraft:dark_prismarine
fill 167 203 323 167 206 323 minecraft:blue_terracotta
fill 167 203 363 167 206 363 minecraft:blue_terracotta
setblock 168 203 326 minecraft:dark_prismarine
setblock 169 203 325 minecraft:dark_prismarine
setblock 169 203 326 minecraft:blue_terracotta
setblock 170 203 324 minecraft:dark_prismarine
fill 170 203 325 170 204 325 minecraft:blue_terracotta
setblock 171 203 323 minecraft:dark_prismarine
fill 171 203 324 171 204 324 minecraft:blue_terracotta
setblock 171 203 363 minecraft:dark_prismarine
fill 172 203 323 172 205 323 minecraft:blue_terracotta
setblock 172 203 332 minecraft:light[level=12]
setblock 172 203 339 minecraft:light[level=12]
setblock 172 203 346 minecraft:light[level=12]
setblock 172 203 353 minecraft:light[level=12]
setblock 172 203 360 minecraft:light[level=12]
fill 172 203 363 172 205 363 minecraft:blue_terracotta
setblock 179 203 325 minecraft:light[level=12]
setblock 179 203 332 minecraft:light[level=12]
setblock 179 203 339 minecraft:light[level=12]
setblock 179 203 346 minecraft:light[level=12]
setblock 179 203 353 minecraft:light[level=12]
setblock 179 203 360 minecraft:light[level=12]
fill 181 203 349 181 206 349 minecraft:blue_terracotta
setblock 181 203 352 minecraft:blue_terracotta
setblock 181 203 353 minecraft:dark_prismarine
fill 181 203 354 181 205 355 minecraft:blue_terracotta
setblock 182 203 327 minecraft:dark_prismarine
fill 182 203 328 182 204 328 minecraft:blue_terracotta
setblock 182 203 338 minecraft:purple_concrete
setblock 182 203 347 minecraft:dark_prismarine
fill 182 203 348 182 206 348 minecraft:blue_terracotta
setblock 182 203 352 minecraft:dark_prismarine
fill 182 203 353 182 206 353 minecraft:blue_terracotta
setblock 182 203 357 minecraft:dark_prismarine
fill 182 203 358 182 206 358 minecraft:blue_terracotta
setblock 142 204 327 minecraft:blue_terracotta
setblock 142 204 330 minecraft:blue_terracotta
setblock 142 204 331 minecraft:dark_prismarine
fill 142 204 332 143 206 332 minecraft:blue_terracotta
fill 142 204 334 142 204 335 minecraft:blue_terracotta
fill 142 204 342 142 207 342 minecraft:blue_terracotta
setblock 142 204 346 minecraft:dark_prismarine
fill 142 204 347 142 207 347 minecraft:blue_terracotta
setblock 142 204 351 minecraft:dark_prismarine
fill 142 204 352 142 207 352 minecraft:blue_terracotta
setblock 142 204 356 minecraft:dark_prismarine
fill 142 204 357 142 207 357 minecraft:blue_terracotta
setblock 143 204 330 minecraft:dark_prismarine
fill 143 204 331 143 207 331 minecraft:blue_terracotta
setblock 143 204 345 minecraft:dark_prismarine
fill 143 204 346 143 207 346 minecraft:blue_terracotta
setblock 143 204 350 minecraft:dark_prismarine
fill 143 204 351 143 207 351 minecraft:blue_terracotta
setblock 143 204 355 minecraft:dark_prismarine
fill 143 204 356 143 207 356 minecraft:blue_terracotta
setblock 144 204 349 minecraft:dark_prismarine
fill 144 204 350 144 207 350 minecraft:blue_terracotta
setblock 144 204 354 minecraft:dark_prismarine
fill 148 204 346 148 234 346 minecraft:magenta_terracotta
setblock 150 204 323 minecraft:dark_prismarine
setblock 158 204 363 minecraft:purple_concrete
fill 161 204 322 161 207 323 minecraft:blue_terracotta
setblock 162 204 322 minecraft:light_blue_wool
fill 162 204 323 163 204 324 minecraft:blue_terracotta
setblock 164 204 323 minecraft:blue_terracotta
setblock 164 204 324 minecraft:dark_prismarine
setblock 164 204 325 minecraft:blue_terracotta
setblock 165 204 323 minecraft:dark_prismarine
fill 165 204 324 165 207 324 minecraft:blue_terracotta
setblock 165 204 363 minecraft:dark_prismarine
fill 166 204 323 166 207 323 minecraft:blue_terracotta
fill 166 204 363 166 207 363 minecraft:blue_terracotta
setblock 168 204 325 minecraft:dark_prismarine
setblock 169 204 324 minecraft:dark_prismarine
setblock 169 204 325 minecraft:blue_terracotta
setblock 170 204 323 minecraft:dark_prismarine
fill 170 204 324 170 205 324 minecraft:blue_terracotta
setblock 170 204 363 minecraft:dark_prismarine
fill 171 204 323 171 206 323 minecraft:blue_terracotta
fill 171 204 363 171 207 363 minecraft:blue_terracotta
fill 177 204 340 177 234 340 minecraft:magenta_terracotta
setblock 177 204 363 minecraft:purple_concrete
setblock 181 204 352 minecraft:dark_prismarine
fill 181 204 353 181 207 353 minecraft:blue_terracotta
fill 182 204 326 182 205 326 minecraft:purple_concrete
setblock 182 204 332 minecraft:purple_concrete
setblock 182 204 346 minecraft:dark_prismarine
fill 182 204 347 182 207 347 minecraft:blue_terracotta
setblock 182 204 351 minecraft:dark_prismarine
fill 182 204 352 182 207 352 minecraft:blue_terracotta
setblock 182 204 356 minecraft:dark_prismarine
fill 182 204 357 182 207 357 minecraft:blue_terracotta
setblock 142 205 330 minecraft:dark_prismarine
fill 142 205 331 142 208 331 minecraft:blue_terracotta
setblock 142 205 334 minecraft:blue_terracotta
setblock 142 205 335 minecraft:dark_prismarine
fill 142 205 336 142 207 337 minecraft:blue_terracotta
setblock 142 205 341 minecraft:purple_concrete
setblock 142 205 345 minecraft:dark_prismarine
fill 142 205 346 142 208 346 minecraft:blue_terracotta
setblock 142 205 350 minecraft:dark_prismarine
fill 142 205 351 142 208 351 minecraft:blue_terracotta
setblock 142 205 355 minecraft:dark_prismarine
fill 142 205 356 142 208 356 minecraft:blue_terracotta
fill 142 205 358 142 206 358 minecraft:blue_terracotta
setblock 142 205 360 minecraft:purple_concrete
fill 143 205 330 143 208 330 minecraft:blue_terracotta
setblock 143 205 333 minecraft:blue_terracotta
setblock 143 205 334 minecraft:dark_prismarine
fill 143 205 345 143 208 345 minecraft:blue_terracotta
setblock 143 205 349 minecraft:dark_prismarine
fill 143 205 350 143 208 350 minecraft:blue_terracotta
setblock 143 205 354 minecraft:dark_prismarine
fill 143 205 355 143 208 355 minecraft:blue_terracotta
setblock 144 205 325 minecraft:light[level=13]
setblock 144 205 333 minecraft:light[level=13]
setblock 144 205 341 minecraft:light[level=13]
setblock 144 205 348 minecraft:dark_prismarine
fill 144 205 349 144 208 349 minecraft:blue_terracotta
setblock 144 205 353 minecraft:dark_prismarine
fill 144 205 354 144 208 354 minecraft:blue_terracotta
setblock 144 205 357 minecraft:light[level=13]
setblock 152 205 325 minecraft:light[level=13]
setblock 152 205 333 minecraft:light[level=13]
setblock 152 205 341 minecraft:light[level=13]
setblock 152 205 349 minecraft:light[level=13]
setblock 152 205 357 minecraft:light[level=13]
setblock 160 205 323 minecraft:purple_concrete
setblock 160 205 325 minecraft:light[level=13]
setblock 160 205 333 minecraft:light[level=13]
setblock 160 205 341 minecraft:light[level=13]
setblock 160 205 349 minecraft:light[level=13]
setblock 160 205 357 minecraft:light[level=13]
fill 162 205 322 162 206 323 minecraft:blue_terracotta
setblock 163 205 323 minecraft:blue_terracotta
setblock 163 205 324 minecraft:dark_prismarine
setblock 164 205 323 minecraft:dark_prismarine
fill 164 205 324 164 208 324 minecraft:blue_terracotta
setblock 164 205 363 minecraft:purple_concrete
fill 165 205 323 165 208 323 minecraft:blue_terracotta
fill 165 205 363 165 208 363 minecraft:blue_terracotta
setblock 167 205 325 minecraft:dark_prismarine
setblock 168 205 324 minecraft:dark_prismarine
setblock 168 205 325 minecraft:blue_terracotta
setblock 168 205 333 minecraft:light[level=13]
setblock 168 205 341 minecraft:light[level=13]
setblock 168 205 349 minecraft:light[level=13]
setblock 168 205 357 minecraft:light[level=13]
setblock 169 205 323 minecraft:dark_prismarine
fill 169 205 324 169 206 324 minecraft:blue_terracotta
setblock 169 205 363 minecraft:dark_prismarine
fill 170 205 323 170 208 323 minecraft:blue_terracotta
fill 170 205 363 170 208 363 minecraft:blue_terracotta
setblock 176 205 325 minecraft:light[level=13]
setblock 176 205 333 minecraft:light[level=13]
setblock 176 205 341 minecraft:light[level=13]
setblock 176 205 349 minecraft:light[level=13]
setblock 176 205 357 minecraft:light[level=13]
setblock 179 205 323 minecraft:purple_concrete
setblock 181 205 351 minecraft:dark_prismarine
fill 181 205 352 181 208 352 minecraft:blue_terracotta
setblock 181 205 356 minecraft:dark_prismarine
setblock 182 205 329 minecraft:blue_terracotta
setblock 182 205 330 minecraft:dark_prismarine
fill 182 205 331 182 208 331 minecraft:blue_terracotta
setblock 182 205 345 minecraft:purple_concrete
fill 182 205 346 182 208 346 minecraft:blue_terracotta
setblock 182 205 350 minecraft:dark_prismarine
fill 182 205 351 182 208 351 minecraft:blue_terracotta
setblock 182 205 355 minecraft:dark_prismarine
fill 182 205 356 182 208 356 minecraft:blue_terracotta
setblock 182 205 360 minecraft:dark_prismarine
setblock 142 206 329 minecraft:dark_prismarine
fill 142 206 330 142 209 330 minecraft:blue_terracotta
setblock 142 206 334 minecraft:dark_prismarine
fill 142 206 335 143 208 335 minecraft:blue_terracotta
setblock 142 206 338 minecraft:blue_terracotta
setblock 142 206 339 minecraft:dark_prismarine
fill 142 206 340 142 208 341 minecraft:blue_terracotta
setblock 142 206 344 minecraft:dark_prismarine
fill 142 206 345 142 209 345 minecraft:blue_terracotta
setblock 142 206 349 minecraft:dark_prismarine
fill 142 206 350 142 209 350 minecraft:blue_terracotta
setblock 142 206 354 minecraft:dark_prismarine
fill 142 206 355 142 209 355 minecraft:blue_terracotta
fill 143 206 329 143 209 329 minecraft:blue_terracotta
setblock 143 206 333 minecraft:dark_prismarine
fill 143 206 334 143 209 334 minecraft:blue_terracotta
fill 143 206 336 143 207 336 minecraft:blue_terracotta
setblock 143 206 348 minecraft:dark_prismarine
fill 143 206 349 143 209 349 minecraft:blue_terracotta
setblock 143 206 353 minecraft:dark_prismarine
fill 143 206 354 143 209 354 minecraft:blue_terracotta
setblock 143 206 357 minecraft:blue_terracotta
fill 144 206 348 144 207 348 minecraft:blue_terracotta
setblock 144 206 352 minecraft:dark_prismarine
fill 144 206 353 144 209 353 minecraft:blue_terracotta
setblock 145 206 363 minecraft:purple_concrete
fill 147 206 346 147 234 346 minecraft:magenta_terracotta
fill 151 206 363 151 207 363 minecraft:purple_concrete
setblock 154 206 323 minecraft:purple_concrete
setblock 163 206 323 minecraft:dark_prismarine
fill 163 206 324 163 209 324 minecraft:blue_terracotta
fill 164 206 323 164 209 323 minecraft:blue_terracotta
fill 164 206 363 164 209 363 minecraft:blue_terracotta
setblock 166 206 325 minecraft:dark_prismarine
setblock 167 206 324 minecraft:dark_prismarine
setblock 168 206 323 minecraft:dark_prismarine
fill 168 206 324 168 207 324 minecraft:blue_terracotta
setblock 168 206 363 minecraft:dark_prismarine
fill 169 206 323 169 209 323 minecraft:blue_terracotta
fill 169 206 363 169 209 363 minecraft:blue_terracotta
setblock 173 206 323 minecraft:purple_concrete
setblock 181 206 350 minecraft:dark_prismarine
fill 181 206 351 181 209 351 minecraft:blue_terracotta
setblock 181 206 354 minecraft:blue_terracotta
setblock 181 206 355 minecraft:dark_prismarine
fill 181 206 356 181 208 357 minecraft:blue_terracotta
setblock 182 206 329 minecraft:dark_prismarine
fill 182 206 330 182 209 330 minecraft:blue_terracotta
fill 182 206 332 182 206 333 minecraft:blue_terracotta
setblock 182 206 339 minecraft:purple_concrete
setblock 182 206 349 minecraft:dark_prismarine
fill 182 206 350 182 209 350 minecraft:blue_terracotta
setblock 182 206 354 minecraft:dark_prismarine
fill 182 206 355 182 209 355 minecraft:blue_terracotta
setblock 182 206 359 minecraft:dark_prismarine
fill 182 206 360 182 208 361 minecraft:blue_terracotta
setblock 142 207 327 minecraft:blue_terracotta
setblock 142 207 328 minecraft:dark_prismarine
fill 142 207 329 142 210 329 minecraft:blue_terracotta
setblock 142 207 332 minecraft:blue_terracotta
setblock 142 207 333 minecraft:dark_prismarine
fill 142 207 334 142 210 334 minecraft:blue_terracotta
setblock 142 207 338 minecraft:dark_prismarine
fill 142 207 339 143 209 339 minecraft:blue_terracotta
setblock 142 207 343 minecraft:dark_prismarine
fill 142 207 344 142 210 344 minecraft:blue_terracotta
setblock 142 207 348 minecraft:dark_prismarine
fill 142 207 349 142 210 349 minecraft:blue_terracotta
setblock 142 207 353 minecraft:dark_prismarine
fill 142 207 354 142 210 354 minecraft:blue_terracotta
setblock 142 207 358 minecraft:dark_prismarine
fill 142 207 359 142 210 359 minecraft:blue_terracotta
setblock 143 207 332 minecraft:dark_prismarine
fill 143 207 333 144 209 333 minecraft:blue_terracotta
setblock 143 207 337 minecraft:dark_prismarine
fill 143 207 338 143 210 338 minecraft:blue_terracotta
setblock 143 207 347 minecraft:dark_prismarine
fill 143 207 348 143 210 348 minecraft:blue_terracotta
setblock 143 207 352 minecraft:dark_prismarine
fill 143 207 353 143 210 353 minecraft:blue_terracotta
setblock 143 207 357 minecraft:dark_prismarine
setblock 144 207 331 minecraft:dark_prismarine
fill 144 207 332 144 210 332 minecraft:blue_terracotta
fill 144 207 334 144 207 335 minecraft:blue_terracotta
setblock 144 207 336 minecraft:dark_prismarine
setblock 144 207 351 minecraft:dark_prismarine
fill 144 207 352 144 210 352 minecraft:blue_terracotta
setblock 144 207 355 minecraft:blue_terracotta
setblock 148 207 323 minecraft:purple_concrete
setblock 157 207 363 minecraft:purple_concrete
fill 162 207 322 162 220 322 minecraft:blue_terracotta
setblock 162 207 323 minecraft:dark_prismarine
fill 163 207 323 163 210 323 minecraft:blue_terracotta
fill 163 207 363 163 210 363 minecraft:blue_terracotta
setblock 166 207 324 minecraft:dark_prismarine
setblock 167 207 323 minecraft:dark_prismarine
fill 167 207 324 167 210 324 minecraft:blue_terracotta
setblock 167 207 363 minecraft:dark_prismarine
fill 168 207 323 168 210 323 minecraft:blue_terracotta
fill 168 207 363 168 210 363 minecraft:blue_terracotta
setblock 176 207 363 minecraft:purple_concrete
setblock 181 207 349 minecraft:dark_prismarine
fill 181 207 350 181 210 350 minecraft:blue_terracotta
setblock 181 207 354 minecraft:dark_prismarine
fill 181 207 355 181 210 355 minecraft:blue_terracotta
setblock 181 207 358 minecraft:blue_terracotta
fill 182 207 329 182 210 329 minecraft:blue_terracotta
setblock 182 207 332 minecraft:blue_terracotta
setblock 182 207 333 minecraft:dark_prismarine
fill 182 207 334 182 209 335 minecraft:blue_terracotta
fill 182 207 345 182 209 345 minecraft:blue_terracotta
setblock 182 207 348 minecraft:dark_prismarine
fill 182 207 349 182 210 349 minecraft:blue_terracotta
setblock 182 207 353 minecraft:dark_prismarine
fill 182 207 354 182 210 354 minecraft:blue_terracotta
setblock 182 207 358 minecraft:dark_prismarine
fill 182 207 359 182 210 359 minecraft:blue_terracotta
setblock 182 207 362 minecraft:blue_terracotta
setblock 183 207 331 minecraft:cyan_concrete
setblock 141 208 328 minecraft:light_blue_wool
setblock 142 208 327 minecraft:dark_prismarine
fill 142 208 328 142 211 328 minecraft:blue_terracotta
setblock 142 208 332 minecraft:dark_prismarine
fill 142 208 333 142 211 333 minecraft:blue_terracotta
setblock 142 208 336 minecraft:blue_terracotta
setblock 142 208 337 minecraft:dark_prismarine
fill 142 208 338 142 211 338 minecraft:blue_terracotta
setblock 142 208 342 minecraft:dark_prismarine
fill 142 208 343 143 210 343 minecraft:blue_terracotta
setblock 142 208 347 minecraft:dark_prismarine
fill 142 208 348 142 211 348 minecraft:blue_terracotta
setblock 142 208 352 minecraft:dark_prismarine
fill 142 208 353 142 211 353 minecraft:blue_terracotta
setblock 142 208 357 minecraft:dark_prismarine
fill 142 208 358 143 210 358 minecraft:blue_terracotta
fill 142 208 360 142 209 360 minecraft:blue_terracotta
setblock 143 208 331 minecraft:dark_prismarine
fill 143 208 332 143 211 332 minecraft:blue_terracotta
setblock 143 208 336 minecraft:dark_prismarine
fill 143 208 337 144 210 337 minecraft:blue_terracotta
setblock 143 208 340 minecraft:blue_terracotta
setblock 143 208 341 minecraft:dark_prismarine
fill 143 208 342 143 211 342 minecraft:blue_terracotta
fill 143 208 344 143 209 344 minecraft:blue_terracotta
setblock 143 208 346 minecraft:dark_prismarine
fill 143 208 347 143 211 347 minecraft:blue_terracotta
setblock 143 208 351 minecraft:dark_prismarine
fill 143 208 352 143 211 352 minecraft:blue_terracotta
setblock 143 208 356 minecraft:dark_prismarine
fill 143 208 357 143 211 357 minecraft:blue_terracotta
setblock 144 208 330 minecraft:dark_prismarine
fill 144 208 331 144 211 331 minecraft:blue_terracotta
setblock 144 208 334 minecraft:blue_terracotta
setblock 144 208 335 minecraft:dark_prismarine
fill 144 208 336 144 211 336 minecraft:blue_terracotta
fill 144 208 338 144 209 338 minecraft:blue_terracotta
setblock 144 208 350 minecraft:dark_prismarine
fill 144 208 351 144 211 351 minecraft:blue_terracotta
setblock 144 208 355 minecraft:dark_prismarine
fill 144 208 356 144 211 356 minecraft:blue_terracotta
setblock 160 208 323 minecraft:blue_terracotta
fill 161 208 322 161 220 322 minecraft:blue_terracotta
setblock 161 208 323 minecraft:dark_prismarine
fill 162 208 323 162 210 324 minecraft:blue_terracotta
fill 162 208 363 162 211 363 minecraft:blue_terracotta
setblock 165 208 324 minecraft:dark_prismarine
fill 165 208 362 166 208 362 minecraft:blue_terracotta
setblock 166 208 323 minecraft:dark_prismarine
fill 166 208 324 166 211 324 minecraft:blue_terracotta
setblock 166 208 363 minecraft:dark_prismarine
fill 167 208 323 167 211 323 minecraft:blue_terracotta
setblock 167 208 362 minecraft:dark_prismarine
fill 167 208 363 167 211 363 minecraft:blue_terracotta
fill 168 208 362 168 211 362 minecraft:blue_terracotta
setblock 171 208 363 minecraft:dark_prismarine
fill 176 208 340 176 234 340 minecraft:magenta_terracotta
fill 180 208 352 180 208 353 minecraft:blue_terracotta
setblock 180 208 354 minecraft:dark_prismarine
fill 180 208 355 180 210 356 minecraft:blue_terracotta
fill 181 208 349 181 211 349 minecraft:blue_terracotta
setblock 181 208 353 minecraft:dark_prismarine
fill 181 208 354 181 211 354 minecraft:blue_terracotta
setblock 181 208 358 minecraft:dark_prismarine
fill 181 208 359 181 210 360 minecraft:blue_terracotta
setblock 182 208 327 minecraft:purple_concrete
setblock 182 208 332 minecraft:dark_prismarine
fill 182 208 333 182 211 333 minecraft:blue_terracotta
setblock 182 208 336 minecraft:blue_terracotta
setblock 182 208 337 minecraft:dark_prismarine
fill 182 208 338 182 210 339 minecraft:blue_terracotta
fill 182 208 344 182 210 344 minecraft:blue_terracotta
setblock 182 208 347 minecraft:dark_prismarine
fill 182 208 348 182 211 348 minecraft:blue_terracotta
setblock 182 208 352 minecraft:dark_prismarine
fill 182 208 353 182 211 353 minecraft:blue_terracotta
setblock 182 208 357 minecraft:dark_prismarine
fill 182 208 358 182 211 358 minecraft:blue_terracotta
setblock 182 208 362 minecraft:dark_prismarine
fill 182 208 363 182 211 363 minecraft:blue_terracotta
fill 183 208 331 183 217 331 minecraft:blue_terracotta
fill 141 209 328 141 216 328 minecraft:blue_terracotta
fill 142 209 327 142 212 327 minecraft:blue_terracotta
setblock 142 209 331 minecraft:dark_prismarine
fill 142 209 332 142 212 332 minecraft:blue_terracotta
setblock 142 209 335 minecraft:blue_terracotta
setblock 142 209 336 minecraft:dark_prismarine
fill 142 209 337 142 212 337 minecraft:blue_terracotta
setblock 142 209 340 minecraft:blue_terracotta
setblock 142 209 341 minecraft:dark_prismarine
fill 142 209 342 142 212 342 minecraft:blue_terracotta
setblock 142 209 346 minecraft:dark_prismarine
fill 142 209 347 142 212 347 minecraft:blue_terracotta
setblock 142 209 351 minecraft:dark_prismarine
fill 142 209 352 142 212 352 minecraft:blue_terracotta
setblock 142 209 356 minecraft:dark_prismarine
fill 142 209 357 142 212 357 minecraft:blue_terracotta
setblock 142 209 361 minecraft:dark_prismarine
fill 143 209 328 143 210 328 minecraft:blue_terracotta
setblock 143 209 330 minecraft:dark_prismarine
fill 143 209 331 143 212 331 minecraft:blue_terracotta
setblock 143 209 335 minecraft:dark_prismarine
fill 143 209 336 143 212 336 minecraft:blue_terracotta
setblock 143 209 340 minecraft:dark_prismarine
fill 143 209 341 143 212 341 minecraft:blue_terracotta
setblock 143 209 345 minecraft:dark_prismarine
fill 143 209 346 143 212 346 minecraft:blue_terracotta
setblock 143 209 350 minecraft:dark_prismarine
fill 143 209 351 143 212 351 minecraft:blue_terracotta
setblock 143 209 355 minecraft:dark_prismarine
fill 143 209 356 143 212 356 minecraft:blue_terracotta
setblock 143 209 359 minecraft:blue_terracotta
setblock 144 209 325 minecraft:light[level=12]
fill 144 209 330 144 212 330 minecraft:blue_terracotta
setblock 144 209 334 minecraft:dark_prismarine
fill 144 209 335 145 211 335 minecraft:blue_terracotta
setblock 144 209 339 minecraft:dark_prismarine
fill 144 209 340 144 212 340 minecraft:blue_terracotta
setblock 144 209 346 minecraft:light[level=12]
setblock 144 209 349 minecraft:dark_prismarine
fill 144 209 350 144 211 350 minecraft:blue_terracotta
setblock 144 209 354 minecraft:dark_prismarine
fill 144 209 355 144 212 355 minecraft:blue_terracotta
setblock 144 209 360 minecraft:light[level=12]
setblock 144 209 363 minecraft:purple_concrete
setblock 145 209 333 minecraft:dark_prismarine
fill 145 209 334 145 212 334 minecraft:blue_terracotta
fill 145 209 336 145 210 336 minecraft:blue_terracotta
setblock 151 209 325 minecraft:light[level=12]
setblock 151 209 332 minecraft:light[level=12]
setblock 151 209 339 minecraft:light[level=12]
setblock 151 209 346 minecraft:light[level=12]
setblock 151 209 353 minecraft:light[level=12]
setblock 151 209 360 minecraft:light[level=12]
setblock 155 209 323 minecraft:purple_concrete
setblock 158 209 325 minecraft:light[level=12]
setblock 158 209 332 minecraft:light[level=12]
setblock 158 209 339 minecraft:light[level=12]
setblock 158 209 346 minecraft:light[level=12]
setblock 158 209 353 minecraft:light[level=12]
setblock 158 209 360 minecraft:light[level=12]
setblock 159 209 323 minecraft:blue_terracotta
setblock 160 209 323 minecraft:dark_prismarine
fill 161 209 323 161 211 324 minecraft:blue_terracotta
fill 161 209 363 161 212 363 minecraft:blue_terracotta
fill 163 209 362 165 209 362 minecraft:blue_terracotta
setblock 164 209 324 minecraft:dark_prismarine
setblock 165 209 323 minecraft:dark_prismarine
fill 165 209 324 165 212 324 minecraft:blue_terracotta
setblock 165 209 325 minecraft:light[level=12]
setblock 165 209 332 minecraft:light[level=12]
setblock 165 209 339 minecraft:light[level=12]
setblock 165 209 346 minecraft:light[level=12]
setblock 165 209 353 minecraft:light[level=12]
setblock 165 209 360 minecraft:light[level=12]
setblock 165 209 363 minecraft:dark_prismarine
fill 166 209 323 166 212 323 minecraft:blue_terracotta
setblock 166 209 362 minecraft:dark_prismarine
fill 166 209 363 166 212 363 minecraft:blue_terracotta
fill 167 209 362 167 212 362 minecraft:blue_terracotta
fill 169 209 362 169 210 362 minecraft:blue_terracotta
setblock 170 209 363 minecraft:dark_prismarine
fill 171 209 322 174 216 322 minecraft:blue_terracotta
fill 171 209 363 172 211 363 minecraft:blue_terracotta
setblock 172 209 325 minecraft:light[level=12]
setblock 172 209 332 minecraft:light[level=12]
setblock 172 209 339 minecraft:light[level=12]
setblock 172 209 346 minecraft:light[level=12]
setblock 172 209 353 minecraft:light[level=12]
setblock 172 209 360 minecraft:light[level=12]
setblock 175 209 322 minecraft:cyan_concrete
setblock 179 209 325 minecraft:light[level=12]
setblock 179 209 332 minecraft:light[level=12]
setblock 179 209 339 minecraft:light[level=12]
setblock 179 209 346 minecraft:light[level=12]
setblock 179 209 353 minecraft:light[level=12]
setblock 179 209 360 minecraft:light[level=12]
setblock 180 209 323 minecraft:purple_concrete
setblock 180 209 352 minecraft:blue_terracotta
setblock 180 209 353 minecraft:dark_prismarine
fill 180 209 354 180 212 354 minecraft:blue_terracotta
setblock 180 209 357 minecraft:blue_terracotta
setblock 180 209 358 minecraft:dark_prismarine
setblock 180 209 363 minecraft:dark_prismarine
fill 181 209 348 181 212 348 minecraft:blue_terracotta
setblock 181 209 352 minecraft:dark_prismarine
fill 181 209 353 181 212 353 minecraft:blue_terracotta
setblock 181 209 356 minecraft:blue_terracotta
setblock 181 209 357 minecraft:dark_prismarine
fill 181 209 358 181 212 358 minecraft:blue_terracotta
setblock 181 209 361 minecraft:blue_terracotta
fill 181 209 363 181 212 363 minecraft:blue_terracotta
fill 182 209 328 182 211 328 minecraft:blue_terracotta
setblock 182 209 331 minecraft:dark_prismarine
fill 182 209 332 182 212 332 minecraft:blue_terracotta
setblock 182 209 336 minecraft:dark_prismarine
fill 182 209 337 182 212 337 minecraft:blue_terracotta
setblock 182 209 340 minecraft:blue_terracotta
setblock 182 209 341 minecraft:dark_prismarine
fill 182 209 342 182 211 343 minecraft:blue_terracotta
setblock 182 209 346 minecraft:dark_prismarine
fill 182 209 347 182 212 347 minecraft:blue_terracotta
setblock 182 209 351 minecraft:dark_prismarine
fill 182 209 352 182 212 352 minecraft:blue_terracotta
setblock 182 209 356 minecraft:dark_prismarine
fill 182 209 357 182 212 357 minecraft:blue_terracotta
setblock 182 209 360 minecraft:blue_terracotta
setblock 182 209 361 minecraft:dark_prismarine
fill 182 209 362 182 212 362 minecraft:blue_terracotta
fill 142 210 326 142 213 326 minecraft:blue_terracotta
setblock 142 210 330 minecraft:dark_prismarine
fill 142 210 331 142 213 331 minecraft:blue_terracotta
setblock 142 210 335 minecraft:dark_prismarine
fill 142 210 336 142 213 336 minecraft:blue_terracotta
setblock 142 210 339 minecraft:blue_terracotta
setblock 142 210 340 minecraft:dark_prismarine
fill 142 210 341 142 213 341 minecraft:blue_terracotta
setblock 142 210 345 minecraft:dark_prismarine
fill 142 210 346 142 213 346 minecraft:blue_terracotta
setblock 142 210 350 minecraft:dark_prismarine
fill 142 210 351 142 213 351 minecraft:blue_terracotta
setblock 142 210 355 minecraft:dark_prismarine
fill 142 210 356 142 213 356 minecraft:blue_terracotta
setblock 142 210 360 minecraft:dark_prismarine
fill 142 210 361 142 211 363 minecraft:blue_terracotta
setblock 143 210 329 minecraft:dark_prismarine
fill 143 210 330 143 213 330 minecraft:blue_terracotta
setblock 143 210 333 minecraft:blue_terracotta
setblock 143 210 334 minecraft:dark_prismarine
fill 143 210 335 143 213 335 minecraft:blue_terracotta
setblock 143 210 339 minecraft:dark_prismarine
fill 143 210 340 143 213 340 minecraft:blue_terracotta
setblock 143 210 344 minecraft:dark_prismarine
fill 143 210 345 143 213 345 minecraft:blue_terracotta
setblock 143 210 349 minecraft:dark_prismarine
fill 143 210 350 143 213 350 minecraft:blue_terracotta
setblock 143 210 354 minecraft:dark_prismarine
fill 143 210 355 143 213 355 minecraft:blue_terracotta
setblock 143 210 359 minecraft:dark_prismarine
fill 143 210 360 143 213 360 minecraft:blue_terracotta
setblock 143 210 363 minecraft:blue_terracotta
setblock 144 210 333 minecraft:dark_prismarine
fill 144 210 334 144 213 334 minecraft:blue_terracotta
setblock 144 210 338 minecraft:dark_prismarine
fill 144 210 339 144 213 339 minecraft:blue_terracotta
fill 144 210 341 144 210 342 minecraft:blue_terracotta
setblock 144 210 349 minecraft:blue_terracotta
setblock 144 210 353 minecraft:dark_prismarine
fill 144 210 354 144 213 354 minecraft:blue_terracotta
setblock 144 210 357 minecraft:blue_terracotta
setblock 144 210 363 minecraft:dark_prismarine
setblock 145 210 332 minecraft:dark_prismarine
fill 145 210 333 145 213 333 minecraft:blue_terracotta
setblock 145 210 337 minecraft:dark_prismarine
fill 145 210 338 145 213 338 minecraft:blue_terracotta
setblock 149 210 323 minecraft:purple_concrete
setblock 150 210 363 minecraft:purple_concrete
setblock 152 210 364 minecraft:cyan_concrete
fill 156 210 335 156 211 335 minecraft:dark_prismarine
setblock 158 210 323 minecraft:blue_terracotta
setblock 159 210 323 minecraft:dark_prismarine
setblock 159 210 363 minecraft:dark_prismarine
fill 160 210 323 160 213 323 minecraft:blue_terracotta
fill 160 210 363 160 213 363 minecraft:blue_terracotta
fill 161 210 362 164 210 362 minecraft:blue_terracotta
setblock 163 210 324 minecraft:dark_prismarine
setblock 164 210 323 minecraft:dark_prismarine
fill 164 210 324 164 213 324 minecraft:blue_terracotta
fill 164 210 361 165 210 361 minecraft:blue_terracotta
setblock 164 210 363 minecraft:dark_prismarine
fill 165 210 323 165 213 323 minecraft:blue_terracotta
setblock 165 210 362 minecraft:dark_prismarine
fill 165 210 363 165 213 363 minecraft:blue_terracotta
setblock 166 210 361 minecraft:dark_prismarine
fill 166 210 362 166 213 362 minecraft:blue_terracotta
fill 167 210 361 167 213 361 minecraft:blue_terracotta
setblock 169 210 323 minecraft:dark_prismarine
setblock 169 210 363 minecraft:dark_prismarine
setblock 170 210 362 minecraft:dark_prismarine
fill 170 210 363 170 213 363 minecraft:blue_terracotta
setblock 173 210 363 minecraft:blue_terracotta
setblock 174 210 323 minecraft:purple_concrete
fill 175 210 322 175 216 322 minecraft:blue_terracotta
setblock 175 210 363 minecraft:purple_concrete
fill 177 210 363 178 210 363 minecraft:blue_terracotta
setblock 179 210 363 minecraft:dark_prismarine
setblock 180 210 351 minecraft:blue_terracotta
setblock 180 210 352 minecraft:dark_prismarine
fill 180 210 353 180 213 353 minecraft:blue_terracotta
setblock 180 210 357 minecraft:dark_prismarine
fill 180 210 358 180 212 359 minecraft:blue_terracotta
setblock 180 210 362 minecraft:dark_prismarine
fill 180 210 363 180 213 363 minecraft:blue_terracotta
fill 181 210 332 181 210 335 minecraft:blue_terracotta
setblock 181 210 336 minecraft:dark_prismarine
fill 181 210 337 181 211 339 minecraft:blue_terracotta
fill 181 210 347 181 213 347 minecraft:blue_terracotta
setblock 181 210 351 minecraft:dark_prismarine
fill 181 210 352 181 213 352 minecraft:blue_terracotta
setblock 181 210 356 minecraft:dark_prismarine
fill 181 210 357 181 213 357 minecraft:blue_terracotta
setblock 181 210 361 minecraft:dark_prismarine
fill 181 210 362 181 213 362 minecraft:blue_terracotta
setblock 182 210 330 minecraft:dark_prismarine
fill 182 210 331 182 213 331 minecraft:blue_terracotta
setblock 182 210 334 minecraft:blue_terracotta
setblock 182 210 335 minecraft:dark_prismarine
fill 182 210 336 182 213 336 minecraft:blue_terracotta
setblock 182 210 340 minecraft:dark_prismarine
fill 182 210 341 182 213 341 minecraft:blue_terracotta
setblock 182 210 345 minecraft:dark_prismarine
fill 182 210 346 182 213 346 minecraft:blue_terracotta
setblock 182 210 350 minecraft:dark_prismarine
fill 182 210 351 182 213 351 minecraft:blue_terracotta
setblock 182 210 355 minecraft:dark_prismarine
fill 182 210 356 182 213 356 minecraft:blue_terracotta
setblock 182 210 360 minecraft:dark_prismarine
fill 182 210 361 182 213 361 minecraft:blue_terracotta
fill 142 211 325 142 214 325 minecraft:blue_terracotta
setblock 142 211 329 minecraft:dark_prismarine
fill 142 211 330 142 214 330 minecraft:blue_terracotta
setblock 142 211 334 minecraft:dark_prismarine
fill 142 211 335 142 214 335 minecraft:blue_terracotta
setblock 142 211 339 minecraft:dark_prismarine
fill 142 211 340 142 214 340 minecraft:blue_terracotta
setblock 142 211 343 minecraft:blue_terracotta
setblock 142 211 344 minecraft:dark_prismarine
fill 142 211 345 142 214 345 minecraft:blue_terracotta
setblock 142 211 349 minecraft:dark_prismarine
fill 142 211 350 142 214 350 minecraft:blue_terracotta
setblock 142 211 354 minecraft:dark_prismarine
fill 142 211 355 142 214 355 minecraft:blue_terracotta
setblock 142 211 358 minecraft:blue_terracotta
setblock 142 211 359 minecraft:dark_prismarine
fill 142 211 360 142 214 360 minecraft:blue_terracotta
setblock 143 211 323 minecraft:dark_prismarine
setblock 143 211 328 minecraft:dark_prismarine
fill 143 211 329 143 214 329 minecraft:blue_terracotta
setblock 143 211 333 minecraft:dark_prismarine
fill 143 211 334 143 214 334 minecraft:blue_terracotta
setblock 143 211 337 minecraft:blue_terracotta
setblock 143 211 338 minecraft:dark_prismarine
fill 143 211 339 143 214 339 minecraft:blue_terracotta
setblock 143 211 343 minecraft:dark_prismarine
fill 143 211 344 143 214 344 minecraft:blue_terracotta
setblock 143 211 348 minecraft:dark_prismarine
fill 143 211 349 143 214 349 minecraft:blue_terracotta
setblock 143 211 353 minecraft:dark_prismarine
fill 143 211 354 143 214 354 minecraft:blue_terracotta
setblock 143 211 358 minecraft:dark_prismarine
fill 143 211 359 143 214 359 minecraft:blue_terracotta
fill 143 211 361 143 212 361 minecraft:blue_terracotta
setblock 143 211 363 minecraft:dark_prismarine
setblock 144 211 322 minecraft:cyan_concrete
fill 144 211 323 146 212 323 minecraft:blue_terracotta
setblock 144 211 332 minecraft:dark_prismarine
fill 144 211 333 144 214 333 minecraft:blue_terracotta
setblock 144 211 337 minecraft:dark_prismarine
fill 144 211 338 144 214 338 minecraft:blue_terracotta
setblock 144 211 341 minecraft:blue_terracotta
setblock 144 211 342 minecraft:dark_prismarine
fill 144 211 343 144 214 343 minecraft:blue_terracotta
setblock 144 211 352 minecraft:dark_prismarine
fill 144 211 353 144 213 353 minecraft:blue_terracotta
setblock 144 211 357 minecraft:dark_prismarine
fill 144 211 358 144 214 358 minecraft:blue_terracotta
fill 144 211 363 146 212 363 minecraft:blue_terracotta
fill 145 211 322 145 220 322 minecraft:blue_terracotta
fill 145 211 332 145 213 332 minecraft:blue_terracotta
setblock 145 211 336 minecraft:dark_prismarine
fill 145 211 337 145 214 337 minecraft:blue_terracotta
fill 145 211 339 145 212 339 minecraft:blue_terracotta
fill 152 211 364 152 220 364 minecraft:blue_terracotta
setblock 156 211 363 minecraft:purple_concrete
setblock 157 211 323 minecraft:blue_terracotta
setblock 158 211 323 minecraft:dark_prismarine
setblock 158 211 363 minecraft:dark_prismarine
fill 159 211 323 159 213 324 minecraft:blue_terracotta
fill 159 211 363 159 214 363 minecraft:blue_terracotta
fill 160 211 324 160 212 324 minecraft:blue_terracotta
fill 160 211 362 163 211 362 minecraft:blue_terracotta
setblock 162 211 323 minecraft:blue_terracotta
setblock 162 211 324 minecraft:dark_prismarine
fill 162 211 361 164 211 361 minecraft:blue_terracotta
setblock 163 211 323 minecraft:dark_prismarine
fill 163 211 324 163 214 324 minecraft:blue_terracotta
setblock 163 211 363 minecraft:dark_prismarine
fill 164 211 323 164 214 323 minecraft:blue_terracotta
setblock 164 211 362 minecraft:dark_prismarine
fill 164 211 363 164 214 363 minecraft:blue_terracotta
setblock 165 211 361 minecraft:dark_prismarine
fill 165 211 362 165 214 362 minecraft:blue_terracotta
fill 166 211 361 166 214 361 minecraft:blue_terracotta
setblock 167 211 324 minecraft:dark_prismarine
setblock 168 211 323 minecraft:dark_prismarine
fill 168 211 361 168 212 361 minecraft:blue_terracotta
setblock 168 211 363 minecraft:dark_prismarine
fill 169 211 323 169 214 323 minecraft:blue_terracotta
setblock 169 211 362 minecraft:dark_prismarine
fill 169 211 363 169 214 363 minecraft:blue_terracotta
fill 170 211 328 170 213 328 minecraft:magenta_terracotta
fill 170 211 356 170 234 356 minecraft:magenta_terracotta
fill 170 211 362 171 213 362 minecraft:blue_terracotta
setblock 173 211 363 minecraft:dark_prismarine
fill 174 211 363 177 211 363 minecraft:blue_terracotta
setblock 178 211 362 minecraft:blue_terracotta
setblock 178 211 363 minecraft:dark_prismarine
fill 179 211 355 179 211 356 minecraft:blue_terracotta
setblock 179 211 357 minecraft:dark_prismarine
setblock 179 211 362 minecraft:dark_prismarine
fill 179 211 363 179 214 363 minecraft:blue_terracotta
setblock 180 211 350 minecraft:blue_terracotta
setblock 180 211 351 minecraft:dark_prismarine
fill 180 211 352 180 214 352 minecraft:blue_terracotta
setblock 180 211 355 minecraft:blue_terracotta
setblock 180 211 356 minecraft:dark_prismarine
fill 180 211 357 180 214 357 minecraft:blue_terracotta
setblock 180 211 360 minecraft:blue_terracotta
setblock 180 211 361 minecraft:dark_prismarine
fill 180 211 362 180 214 362 minecraft:blue_terracotta
fill 181 211 331 181 211 334 minecraft:blue_terracotta
setblock 181 211 335 minecraft:dark_prismarine
fill 181 211 336 181 214 336 minecraft:blue_terracotta
setblock 181 211 340 minecraft:dark_prismarine
fill 181 211 341 181 211 344 minecraft:blue_terracotta
setblock 181 211 345 minecraft:dark_prismarine
fill 181 211 346 181 214 346 minecraft:blue_terracotta
setblock 181 211 350 minecraft:dark_prismarine
fill 181 211 351 181 214 351 minecraft:blue_terracotta
setblock 181 211 355 minecraft:dark_prismarine
fill 181 211 356 181 214 356 minecraft:blue_terracotta
setblock 181 211 359 minecraft:blue_terracotta
setblock 181 211 360 minecraft:dark_prismarine
fill 181 211 361 181 214 361 minecraft:blue_terracotta
fill 182 211 327 182 212 327 minecraft:blue_terracotta
setblock 182 211 329 minecraft:dark_prismarine
fill 182 211 330 182 214 330 minecraft:blue_terracotta
setblock 182 211 334 minecraft:dark_prismarine
fill 182 211 335 182 214 335 minecraft:blue_terracotta
setblock 182 211 338 minecraft:blue_terracotta
setblock 182 211 339 minecraft:dark_prismarine
fill 182 211 340 182 214 340 minecraft:blue_terracotta
setblock 182 211 344 minecraft:dark_prismarine
fill 182 211 345 182 214 345 minecraft:blue_terracotta
setblock 182 211 349 minecraft:dark_prismarine
fill 182 211 350 182 214 350 minecraft:blue_terracotta
setblock 182 211 354 minecraft:dark_prismarine
fill 182 211 355 182 214 355 minecraft:blue_terracotta
setblock 182 211 359 minecraft:dark_prismarine
fill 182 211 360 182 214 360 minecraft:blue_terracotta
setblock 142 212 323 minecraft:dark_prismarine
fill 142 212 324 142 215 324 minecraft:blue_terracotta
setblock 142 212 328 minecraft:dark_prismarine
fill 142 212 329 142 215 329 minecraft:blue_terracotta
setblock 142 212 333 minecraft:dark_prismarine
fill 142 212 334 142 215 334 minecraft:blue_terracotta
setblock 142 212 338 minecraft:dark_prismarine
fill 142 212 339 142 215 339 minecraft:blue_terracotta
setblock 142 212 343 minecraft:dark_prismarine
fill 142 212 344 142 215 344 minecraft:blue_terracotta
setblock 142 212 348 minecraft:dark_prismarine
fill 142 212 349 142 215 349 minecraft:blue_terracotta
setblock 142 212 353 minecraft:dark_prismarine
fill 142 212 354 142 215 354 minecraft:blue_terracotta
setblock 142 212 358 minecraft:dark_prismarine
fill 142 212 359 142 215 359 minecraft:blue_terracotta
fill 142 212 361 142 212 362 minecraft:blue_terracotta
setblock 142 212 363 minecraft:dark_prismarine
fill 143 212 323 143 215 323 minecraft:blue_terracotta
setblock 143 212 327 minecraft:dark_prismarine
fill 143 212 328 143 215 328 minecraft:blue_terracotta
setblock 143 212 332 minecraft:dark_prismarine
fill 143 212 333 143 215 333 minecraft:blue_terracotta
setblock 143 212 337 minecraft:dark_prismarine
fill 143 212 338 143 215 338 minecraft:blue_terracotta
setblock 143 212 342 minecraft:dark_prismarine
fill 143 212 343 143 215 343 minecraft:blue_terracotta
setblock 143 212 347 minecraft:dark_prismarine
fill 143 212 348 143 215 348 minecraft:blue_terracotta
setblock 143 212 352 minecraft:dark_prismarine
fill 143 212 353 143 215 353 minecraft:blue_terracotta
setblock 143 212 357 minecraft:dark_prismarine
fill 143 212 358 143 215 358 minecraft:blue_terracotta
setblock 143 212 362 minecraft:dark_prismarine
fill 143 212 363 143 215 363 minecraft:blue_terracotta
fill 144 212 322 144 220 322 minecraft:blue_terracotta
setblock 144 212 331 minecraft:dark_prismarine
fill 144 212 332 144 215 332 minecraft:blue_terracotta
setblock 144 212 335 minecraft:blue_terracotta
setblock 144 212 336 minecraft:dark_prismarine
fill 144 212 337 144 215 337 minecraft:blue_terracotta
setblock 144 212 341 minecraft:dark_prismarine
fill 144 212 342 144 215 342 minecraft:blue_terracotta
fill 144 212 344 144 213 344 minecraft:blue_terracotta
setblock 144 212 351 minecraft:dark_prismarine
setblock 144 212 352 minecraft:blue_terracotta
setblock 144 212 356 minecraft:dark_prismarine
fill 144 212 357 144 214 357 minecraft:blue_terracotta
fill 144 212 359 144 213 359 minecraft:blue_terracotta
fill 144 212 362 144 215 362 minecraft:blue_terracotta
setblock 145 212 335 minecraft:dark_prismarine
fill 145 212 336 145 215 336 minecraft:blue_terracotta
setblock 145 212 340 minecraft:dark_prismarine
setblock 147 212 323 minecraft:dark_prismarine
setblock 147 212 363 minecraft:dark_prismarine
setblock 148 212 347 minecraft:pink_terracotta
fill 149 212 347 149 213 347 minecraft:magenta_terracotta
fill 149 212 360 149 222 360 minecraft:black_concrete
fill 153 212 364 153 220 364 minecraft:blue_terracotta
setblock 154 212 331 minecraft:pink_terracotta
setblock 154 212 364 minecraft:light_blue_wool
fill 155 212 364 155 220 364 minecraft:blue_terracotta
setblock 156 212 323 minecraft:blue_terracotta
setblock 156 212 363 minecraft:blue_terracotta
setblock 157 212 323 minecraft:dark_prismarine
setblock 157 212 363 minecraft:dark_prismarine
fill 158 212 323 158 214 324 minecraft:blue_terracotta
setblock 158 212 362 minecraft:dark_prismarine
fill 158 212 363 158 215 363 minecraft:blue_terracotta
fill 159 212 362 162 212 362 minecraft:blue_terracotta
fill 160 212 361 163 212 361 minecraft:blue_terracotta
setblock 161 212 323 minecraft:blue_terracotta
setblock 161 212 324 minecraft:dark_prismarine
setblock 162 212 323 minecraft:dark_prismarine
fill 162 212 324 162 214 325 minecraft:blue_terracotta
fill 162 212 360 164 212 360 minecraft:blue_terracotta
setblock 162 212 363 minecraft:dark_prismarine
fill 163 212 323 163 215 323 minecraft:blue_terracotta
fill 163 212 325 163 213 325 minecraft:blue_terracotta
setblock 163 212 362 minecraft:dark_prismarine
fill 163 212 363 163 215 363 minecraft:blue_terracotta
setblock 164 212 361 minecraft:dark_prismarine
fill 164 212 362 164 215 362 minecraft:blue_terracotta
setblock 165 212 360 minecraft:dark_prismarine
fill 165 212 361 165 215 361 minecraft:blue_terracotta
setblock 166 212 324 minecraft:dark_prismarine
fill 166 212 360 166 215 360 minecraft:blue_terracotta
setblock 167 212 323 minecraft:dark_prismarine
setblock 167 212 324 minecraft:blue_terracotta
setblock 167 212 363 minecraft:dark_prismarine
fill 168 212 323 168 215 323 minecraft:blue_terracotta
setblock 168 212 362 minecraft:dark_prismarine
fill 168 212 363 168 215 363 minecraft:blue_terracotta
setblock 169 212 328 minecraft:pink_terracotta
setblock 169 212 361 minecraft:dark_prismarine
fill 169 212 362 169 215 362 minecraft:blue_terracotta
setblock 170 212 355 minecraft:pink_terracotta
setblock 170 212 364 minecraft:cyan_concrete
setblock 171 212 363 minecraft:blue_terracotta
setblock 172 212 362 minecraft:blue_terracotta
setblock 172 212 363 minecraft:dark_prismarine
setblock 173 212 362 minecraft:dark_prismarine
fill 173 212 363 176 212 363 minecraft:blue_terracotta
fill 174 212 362 177 212 362 minecraft:blue_terracotta
fill 176 212 339 177 212 339 minecraft:pink_terracotta
setblock 177 212 363 minecraft:dark_prismarine
setblock 178 212 361 minecraft:blue_terracotta
setblock 178 212 362 minecraft:dark_prismarine
fill 178 212 363 178 215 363 minecraft:blue_terracotta
fill 179 212 354 179 212 355 minecraft:blue_terracotta
setblock 179 212 356 minecraft:dark_prismarine
fill 179 212 357 179 213 359 minecraft:blue_terracotta
setblock 179 212 361 minecraft:dark_prismarine
fill 179 212 362 179 215 362 minecraft:blue_terracotta
setblock 180 212 335 minecraft:dark_prismarine
fill 180 212 336 180 213 338 minecraft:blue_terracotta
setblock 180 212 350 minecraft:dark_prismarine
fill 180 212 351 180 215 351 minecraft:blue_terracotta
setblock 180 212 355 minecraft:dark_prismarine
fill 180 212 356 180 215 356 minecraft:blue_terracotta
setblock 180 212 360 minecraft:dark_prismarine
fill 180 212 361 180 215 361 minecraft:blue_terracotta
setblock 181 212 323 minecraft:purple_concrete
fill 181 212 331 181 212 333 minecraft:blue_terracotta
setblock 181 212 334 minecraft:dark_prismarine
fill 181 212 335 181 215 335 minecraft:blue_terracotta
fill 181 212 337 181 212 338 minecraft:blue_terracotta
setblock 181 212 339 minecraft:dark_prismarine
fill 181 212 340 181 212 343 minecraft:blue_terracotta
setblock 181 212 344 minecraft:dark_prismarine
fill 181 212 345 181 215 345 minecraft:blue_terracotta
setblock 181 212 349 minecraft:dark_prismarine
fill 181 212 350 181 215 350 minecraft:blue_terracotta
setblock 181 212 354 minecraft:dark_prismarine
fill 181 212 355 181 215 355 minecraft:blue_terracotta
setblock 181 212 359 minecraft:dark_prismarine
fill 181 212 360 181 215 360 minecraft:blue_terracotta
setblock 182 212 323 minecraft:dark_prismarine
setblock 182 212 328 minecraft:dark_prismarine
fill 182 212 329 182 215 329 minecraft:blue_terracotta
setblock 182 212 333 minecraft:dark_prismarine
fill 182 212 334 182 215 334 minecraft:blue_terracotta
setblock 182 212 338 minecraft:dark_prismarine
fill 182 212 339 182 215 339 minecraft:blue_terracotta
setblock 182 212 342 minecraft:blue_terracotta
setblock 182 212 343 minecraft:dark_prismarine
fill 182 212 344 182 215 344 minecraft:blue_terracotta
setblock 182 212 348 minecraft:dark_prismarine
fill 182 212 349 182 215 349 minecraft:blue_terracotta
setblock 182 212 353 minecraft:dark_prismarine
fill 182 212 354 182 215 354 minecraft:blue_terracotta
setblock 182 212 358 minecraft:dark_prismarine
fill 182 212 359 182 215 359 minecraft:blue_terracotta
setblock 182 212 363 minecraft:dark_prismarine
fill 142 213 323 142 216 323 minecraft:blue_terracotta
setblock 142 213 327 minecraft:dark_prismarine
fill 142 213 328 142 216 328 minecraft:blue_terracotta
setblock 142 213 332 minecraft:dark_prismarine
fill 142 213 333 142 216 333 minecraft:blue_terracotta
setblock 142 213 337 minecraft:dark_prismarine
fill 142 213 338 142 216 338 minecraft:blue_terracotta
setblock 142 213 342 minecraft:dark_prismarine
fill 142 213 343 142 216 343 minecraft:blue_terracotta
setblock 142 213 347 minecraft:dark_prismarine
fill 142 213 348 142 216 348 minecraft:blue_terracotta
setblock 142 213 352 minecraft:dark_prismarine
fill 142 213 353 142 216 353 minecraft:blue_terracotta
setblock 142 213 357 minecraft:dark_prismarine
fill 142 213 358 142 216 358 minecraft:blue_terracotta
setblock 142 213 361 minecraft:blue_terracotta
setblock 142 213 362 minecraft:dark_prismarine
fill 142 213 363 142 216 363 minecraft:blue_terracotta
fill 143 213 327 143 214 327 minecraft:blue_terracotta
setblock 143 213 331 minecraft:dark_prismarine
fill 143 213 332 143 216 332 minecraft:blue_terracotta
setblock 143 213 336 minecraft:dark_prismarine
fill 143 213 337 143 216 337 minecraft:blue_terracotta
setblock 143 213 341 minecraft:dark_prismarine
fill 143 213 342 143 216 342 minecraft:blue_terracotta
setblock 143 213 346 minecraft:dark_prismarine
fill 143 213 347 143 216 347 minecraft:blue_terracotta
setblock 143 213 351 minecraft:dark_prismarine
fill 143 213 352 143 215 352 minecraft:blue_terracotta
setblock 143 213 356 minecraft:dark_prismarine
fill 143 213 357 143 216 357 minecraft:blue_terracotta
setblock 143 213 361 minecraft:dark_prismarine
fill 143 213 362 143 216 362 minecraft:blue_terracotta
fill 144 213 323 145 213 323 minecraft:blue_terracotta
setblock 144 213 325 minecraft:light[level=13]
setblock 144 213 330 minecraft:dark_prismarine
fill 144 213 331 144 215 331 minecraft:blue_terracotta
setblock 144 213 335 minecraft:dark_prismarine
fill 144 213 336 144 216 336 minecraft:blue_terracotta
setblock 144 213 340 minecraft:dark_prismarine
fill 144 213 341 145 214 341 minecraft:blue_terracotta
setblock 144 213 349 minecraft:light[level=13]
setblock 144 213 355 minecraft:dark_prismarine
fill 144 213 356 144 214 356 minecraft:blue_terracotta
fill 144 213 363 145 213 363 minecraft:blue_terracotta
setblock 145 213 334 minecraft:dark_prismarine
fill 145 213 335 145 215 335 minecraft:blue_terracotta
setblock 145 213 339 minecraft:dark_prismarine
fill 145 213 340 145 215 340 minecraft:blue_terracotta
fill 145 213 362 145 214 362 minecraft:blue_terracotta
setblock 146 213 323 minecraft:dark_prismarine
setblock 146 213 363 minecraft:dark_prismarine
fill 147 213 323 147 216 323 minecraft:blue_terracotta
fill 147 213 363 147 216 363 minecraft:blue_terracotta
fill 148 213 347 148 230 347 minecraft:magenta_terracotta
setblock 149 213 363 minecraft:purple_concrete
fill 150 213 323 150 214 323 minecraft:purple_concrete
setblock 152 213 325 minecraft:light[level=13]
setblock 152 213 333 minecraft:light[level=13]
setblock 152 213 341 minecraft:light[level=13]
setblock 152 213 349 minecraft:light[level=13]
setblock 152 213 357 minecraft:light[level=13]
fill 154 213 323 155 213 323 minecraft:blue_terracotta
fill 154 213 331 154 231 331 minecraft:magenta_terracotta
fill 154 213 364 154 220 364 minecraft:blue_terracotta
setblock 155 213 363 minecraft:blue_terracotta
setblock 156 213 323 minecraft:dark_prismarine
setblock 156 213 363 minecraft:dark_prismarine
fill 157 213 323 157 216 323 minecraft:blue_terracotta
setblock 157 213 362 minecraft:dark_prismarine
fill 157 213 363 157 216 363 minecraft:blue_terracotta
fill 158 213 362 161 213 362 minecraft:blue_terracotta
fill 159 213 361 162 213 361 minecraft:blue_terracotta
setblock 160 213 324 minecraft:dark_prismarine
setblock 160 213 325 minecraft:light[level=13]
setblock 160 213 333 minecraft:light[level=13]
setblock 160 213 341 minecraft:light[level=13]
setblock 160 213 349 minecraft:light[level=13]
setblock 160 213 357 minecraft:light[level=13]
setblock 161 213 323 minecraft:dark_prismarine
fill 161 213 324 161 215 325 minecraft:blue_terracotta
fill 161 213 360 163 213 360 minecraft:blue_terracotta
setblock 161 213 363 minecraft:dark_prismarine
fill 162 213 323 162 216 323 minecraft:blue_terracotta
setblock 162 213 362 minecraft:dark_prismarine
fill 162 213 363 162 216 363 minecraft:blue_terracotta
setblock 163 213 361 minecraft:dark_prismarine
fill 163 213 362 163 216 362 minecraft:blue_terracotta
setblock 164 213 360 minecraft:dark_prismarine
fill 164 213 361 164 216 361 minecraft:blue_terracotta
setblock 165 213 324 minecraft:dark_prismarine
fill 165 213 360 165 216 360 minecraft:blue_terracotta
setblock 166 213 323 minecraft:dark_prismarine
fill 166 213 324 166 214 324 minecraft:blue_terracotta
setblock 166 213 363 minecraft:dark_prismarine
fill 167 213 323 167 216 323 minecraft:blue_terracotta
fill 167 213 360 167 214 360 minecraft:blue_terracotta
setblock 167 213 362 minecraft:dark_prismarine
fill 167 213 363 167 216 363 minecraft:blue_terracotta
setblock 168 213 325 minecraft:light[level=13]
setblock 168 213 333 minecraft:light[level=13]
setblock 168 213 341 minecraft:light[level=13]
setblock 168 213 349 minecraft:light[level=13]
setblock 168 213 357 minecraft:light[level=13]
setblock 168 213 361 minecraft:dark_prismarine
fill 168 213 362 168 216 362 minecraft:blue_terracotta
fill 169 213 328 169 234 328 minecraft:magenta_terracotta
fill 169 213 356 169 234 356 minecraft:magenta_terracotta
fill 169 213 361 170 215 361 minecraft:blue_terracotta
fill 170 213 355 170 229 355 minecraft:magenta_terracotta
fill 170 213 364 170 216 364 minecraft:blue_terracotta
setblock 171 213 363 minecraft:dark_prismarine
setblock 172 213 362 minecraft:dark_prismarine
fill 172 213 363 175 213 363 minecraft:blue_terracotta
fill 173 213 362 176 213 362 minecraft:blue_terracotta
setblock 175 213 323 minecraft:purple_concrete
setblock 176 213 325 minecraft:light[level=13]
setblock 176 213 333 minecraft:light[level=13]
fill 176 213 339 177 229 339 minecraft:magenta_terracotta
setblock 176 213 341 minecraft:light[level=13]
setblock 176 213 349 minecraft:light[level=13]
setblock 176 213 357 minecraft:light[level=13]
fill 176 213 361 177 213 361 minecraft:blue_terracotta
setblock 176 213 363 minecraft:dark_prismarine
setblock 177 213 362 minecraft:dark_prismarine
fill 177 213 363 177 216 363 minecraft:blue_terracotta
setblock 178 213 361 minecraft:dark_prismarine
fill 178 213 362 178 216 362 minecraft:blue_terracotta
setblock 179 213 354 minecraft:blue_terracotta
setblock 179 213 355 minecraft:dark_prismarine
fill 179 213 356 179 216 356 minecraft:blue_terracotta
setblock 179 213 360 minecraft:dark_prismarine
fill 179 213 361 179 216 361 minecraft:blue_terracotta
setblock 180 213 323 minecraft:blue_terracotta
setblock 180 213 334 minecraft:dark_prismarine
fill 180 213 335 180 216 335 minecraft:blue_terracotta
setblock 180 213 339 minecraft:dark_prismarine
fill 180 213 340 181 214 341 minecraft:blue_terracotta
setblock 180 213 349 minecraft:dark_prismarine
fill 180 213 350 180 215 350 minecraft:blue_terracotta
setblock 180 213 354 minecraft:dark_prismarine
fill 180 213 355 180 216 355 minecraft:blue_terracotta
setblock 180 213 358 minecraft:blue_terracotta
setblock 180 213 359 minecraft:dark_prismarine
fill 180 213 360 180 216 360 minecraft:blue_terracotta
setblock 181 213 323 minecraft:dark_prismarine
fill 181 213 331 181 213 332 minecraft:blue_terracotta
setblock 181 213 333 minecraft:dark_prismarine
fill 181 213 334 181 216 334 minecraft:blue_terracotta
setblock 181 213 337 minecraft:blue_terracotta
setblock 181 213 338 minecraft:dark_prismarine
fill 181 213 339 181 216 339 minecraft:blue_terracotta
setblock 181 213 342 minecraft:blue_terracotta
setblock 181 213 343 minecraft:dark_prismarine
fill 181 213 344 181 216 344 minecraft:blue_terracotta
setblock 181 213 348 minecraft:dark_prismarine
fill 181 213 349 181 216 349 minecraft:blue_terracotta
setblock 181 213 353 minecraft:dark_prismarine
fill 181 213 354 181 216 354 minecraft:blue_terracotta
setblock 181 213 358 minecraft:dark_prismarine
fill 181 213 359 181 216 359 minecraft:blue_terracotta
setblock 181 213 363 minecraft:dark_prismarine
fill 182 213 323 182 213 326 minecraft:blue_terracotta
setblock 182 213 327 minecraft:dark_prismarine
fill 182 213 328 182 215 328 minecraft:blue_terracotta
setblock 182 213 332 minecraft:dark_prismarine
fill 182 213 333 182 216 333 minecraft:blue_terracotta
setblock 182 213 337 minecraft:dark_prismarine
fill 182 213 338 182 216 338 minecraft:blue_terracotta
setblock 182 213 342 minecraft:dark_prismarine
fill 182 213 343 182 216 343 minecraft:blue_terracotta
setblock 182 213 347 minecraft:dark_prismarine
fill 182 213 348 182 216 348 minecraft:blue_terracotta
setblock 182 213 352 minecraft:dark_prismarine
fill 182 213 353 182 216 353 minecraft:blue_terracotta
setblock 182 213 357 minecraft:dark_prismarine
fill 182 213 358 182 216 358 minecraft:blue_terracotta
setblock 182 213 362 minecraft:dark_prismarine
fill 182 213 363 182 216 363 minecraft:blue_terracotta
fill 141 214 357 142 217 357 minecraft:blue_terracotta
setblock 141 214 358 minecraft:light_blue_wool
setblock 142 214 326 minecraft:dark_prismarine
fill 142 214 327 142 217 327 minecraft:blue_terracotta
setblock 142 214 331 minecraft:dark_prismarine
fill 142 214 332 142 217 332 minecraft:blue_terracotta
setblock 142 214 336 minecraft:dark_prismarine
fill 142 214 337 142 217 337 minecraft:blue_terracotta
setblock 142 214 341 minecraft:dark_prismarine
fill 142 214 342 142 217 342 minecraft:blue_terracotta
setblock 142 214 346 minecraft:dark_prismarine
fill 142 214 347 142 217 347 minecraft:blue_terracotta
setblock 142 214 351 minecraft:dark_prismarine
fill 142 214 352 142 217 352 minecraft:blue_terracotta
setblock 142 214 356 minecraft:dark_prismarine
setblock 142 214 361 minecraft:dark_prismarine
fill 142 214 362 142 217 362 minecraft:blue_terracotta
setblock 143 214 330 minecraft:dark_prismarine
fill 143 214 331 143 217 331 minecraft:blue_terracotta
setblock 143 214 335 minecraft:dark_prismarine
fill 143 214 336 143 217 336 minecraft:blue_terracotta
setblock 143 214 340 minecraft:dark_prismarine
fill 143 214 341 143 217 341 minecraft:blue_terracotta
setblock 143 214 345 minecraft:dark_prismarine
fill 143 214 346 143 217 346 minecraft:blue_terracotta
setblock 143 214 350 minecraft:dark_prismarine
fill 143 214 351 143 215 351 minecraft:blue_terracotta
setblock 143 214 355 minecraft:dark_prismarine
fill 143 214 356 143 216 356 minecraft:blue_terracotta
setblock 143 214 360 minecraft:dark_prismarine
fill 143 214 361 143 217 361 minecraft:blue_terracotta
setblock 144 214 323 minecraft:blue_terracotta
setblock 144 214 330 minecraft:blue_terracotta
setblock 144 214 334 minecraft:dark_prismarine
fill 144 214 335 144 217 335 minecraft:blue_terracotta
setblock 144 214 339 minecraft:dark_prismarine
fill 144 214 340 144 217 340 minecraft:blue_terracotta
setblock 144 214 344 minecraft:dark_prismarine
setblock 144 214 355 minecraft:blue_terracotta
setblock 144 214 359 minecraft:dark_prismarine
setblock 144 214 363 minecraft:blue_terracotta
setblock 145 214 323 minecraft:dark_prismarine
setblock 145 214 333 minecraft:dark_prismarine
fill 145 214 334 145 215 334 minecraft:blue_terracotta
setblock 145 214 338 minecraft:dark_prismarine
fill 145 214 339 145 216 339 minecraft:blue_terracotta
setblock 145 214 363 minecraft:dark_prismarine
fill 146 214 323 146 217 323 minecraft:blue_terracotta
fill 146 214 363 146 217 363 minecraft:blue_terracotta
fill 148 214 323 148 215 323 minecraft:blue_terracotta
fill 148 214 363 148 215 363 minecraft:blue_terracotta
fill 153 214 323 154 214 323 minecraft:blue_terracotta
setblock 154 214 363 minecraft:blue_terracotta
setblock 155 214 323 minecraft:dark_prismarine
setblock 155 214 363 minecraft:dark_prismarine
fill 156 214 323 156 217 323 minecraft:blue_terracotta
setblock 156 214 362 minecraft:dark_prismarine
fill 156 214 363 156 217 363 minecraft:blue_terracotta
fill 157 214 324 157 215 324 minecraft:blue_terracotta
fill 157 214 362 160 214 362 minecraft:blue_terracotta
fill 158 214 361 161 214 361 minecraft:blue_terracotta
setblock 159 214 323 minecraft:blue_terracotta
setblock 159 214 324 minecraft:dark_prismarine
setblock 160 214 323 minecraft:dark_prismarine
fill 160 214 324 160 216 325 minecraft:blue_terracotta
fill 160 214 360 162 214 360 minecraft:blue_terracotta
setblock 160 214 363 minecraft:dark_prismarine
fill 161 214 323 161 217 323 minecraft:blue_terracotta
setblock 161 214 362 minecraft:dark_prismarine
fill 161 214 363 161 217 363 minecraft:blue_terracotta
setblock 162 214 361 minecraft:dark_prismarine
fill 162 214 362 162 217 362 minecraft:blue_terracotta
setblock 163 214 360 minecraft:dark_prismarine
fill 163 214 361 163 217 361 minecraft:blue_terracotta
setblock 164 214 324 minecraft:dark_prismarine
fill 164 214 360 164 217 360 minecraft:blue_terracotta
setblock 165 214 323 minecraft:dark_prismarine
fill 165 214 324 165 216 324 minecraft:blue_terracotta
setblock 165 214 363 minecraft:dark_prismarine
fill 166 214 323 166 217 323 minecraft:blue_terracotta
setblock 166 214 362 minecraft:dark_prismarine
fill 166 214 363 166 217 363 minecraft:blue_terracotta
setblock 167 214 361 minecraft:dark_prismarine
fill 167 214 362 167 217 362 minecraft:blue_terracotta
fill 168 214 361 168 217 361 minecraft:blue_terracotta
setblock 170 214 362 minecraft:blue_terracotta
setblock 170 214 363 minecraft:dark_prismarine
setblock 171 214 362 minecraft:dark_prismarine
fill 171 214 363 174 214 363 minecraft:blue_terracotta
fill 172 214 362 175 214 362 minecraft:blue_terracotta
fill 175 214 361 176 214 361 minecraft:blue_terracotta
setblock 175 214 363 minecraft:dark_prismarine
setblock 176 214 362 minecraft:dark_prismarine
fill 176 214 363 176 217 363 minecraft:blue_terracotta
setblock 177 214 361 minecraft:dark_prismarine
fill 177 214 362 177 217 362 minecraft:blue_terracotta
setblock 178 214 360 minecraft:dark_prismarine
fill 178 214 361 178 217 361 minecraft:blue_terracotta
setblock 179 214 323 minecraft:blue_terracotta
setblock 179 214 354 minecraft:dark_prismarine
fill 179 214 355 179 215 355 minecraft:blue_terracotta
fill 179 214 357 179 214 358 minecraft:blue_terracotta
setblock 179 214 359 minecraft:dark_prismarine
fill 179 214 360 179 216 360 minecraft:blue_terracotta
setblock 180 214 323 minecraft:dark_prismarine
fill 180 214 334 180 215 334 minecraft:blue_terracotta
fill 180 214 336 180 214 337 minecraft:blue_terracotta
setblock 180 214 338 minecraft:dark_prismarine
fill 180 214 339 180 217 339 minecraft:blue_terracotta
setblock 180 214 342 minecraft:blue_terracotta
setblock 180 214 343 minecraft:dark_prismarine
fill 180 214 344 180 217 344 minecraft:blue_terracotta
setblock 180 214 349 minecraft:blue_terracotta
setblock 180 214 353 minecraft:dark_prismarine
fill 180 214 354 180 217 354 minecraft:blue_terracotta
setblock 180 214 358 minecraft:dark_prismarine
fill 180 214 359 180 217 359 minecraft:blue_terracotta
setblock 180 214 363 minecraft:dark_prismarine
fill 181 214 323 182 216 323 minecraft:blue_terracotta
setblock 181 214 331 minecraft:blue_terracotta
setblock 181 214 332 minecraft:dark_prismarine
fill 181 214 333 181 217 333 minecraft:blue_terracotta
setblock 181 214 337 minecraft:dark_prismarine
fill 181 214 338 181 217 338 minecraft:blue_terracotta
setblock 181 214 342 minecraft:dark_prismarine
fill 181 214 343 181 217 343 minecraft:blue_terracotta
setblock 181 214 347 minecraft:dark_prismarine
fill 181 214 348 181 217 348 minecraft:blue_terracotta
setblock 181 214 352 minecraft:dark_prismarine
fill 181 214 353 181 217 353 minecraft:blue_terracotta
setblock 181 214 357 minecraft:dark_prismarine
fill 181 214 358 181 217 358 minecraft:blue_terracotta
setblock 181 214 362 minecraft:dark_prismarine
fill 181 214 363 181 217 363 minecraft:blue_terracotta
fill 182 214 324 182 214 325 minecraft:blue_terracotta
setblock 182 214 326 minecraft:dark_prismarine
fill 182 214 327 182 215 327 minecraft:blue_terracotta
setblock 182 214 331 minecraft:dark_prismarine
fill 182 214 332 182 217 332 minecraft:blue_terracotta
setblock 182 214 336 minecraft:dark_prismarine
fill 182 214 337 182 217 337 minecraft:blue_terracotta
setblock 182 214 341 minecraft:dark_prismarine
fill 182 214 342 182 217 342 minecraft:blue_terracotta
setblock 182 214 346 minecraft:dark_prismarine
fill 182 214 347 182 217 347 minecraft:blue_terracotta
setblock 182 214 351 minecraft:dark_prismarine
fill 182 214 352 182 217 352 minecraft:blue_terracotta
setblock 182 214 356 minecraft:dark_prismarine
fill 182 214 357 182 217 357 minecraft:blue_terracotta
setblock 182 214 361 minecraft:dark_prismarine
fill 182 214 362 182 217 362 minecraft:blue_terracotta
setblock 183 214 327 minecraft:cyan_concrete
setblock 141 215 358 minecraft:cyan_concrete
setblock 142 215 325 minecraft:dark_prismarine
fill 142 215 326 142 218 326 minecraft:blue_terracotta
setblock 142 215 330 minecraft:dark_prismarine
fill 142 215 331 142 218 331 minecraft:blue_terracotta
setblock 142 215 335 minecraft:dark_prismarine
fill 142 215 336 142 218 336 minecraft:blue_terracotta
setblock 142 215 340 minecraft:dark_prismarine
fill 142 215 341 142 218 341 minecraft:blue_terracotta
setblock 142 215 345 minecraft:dark_prismarine
fill 142 215 346 142 218 346 minecraft:blue_terracotta
setblock 142 215 350 minecraft:dark_prismarine
fill 142 215 351 142 217 351 minecraft:blue_terracotta
setblock 142 215 355 minecraft:dark_prismarine
fill 142 215 356 142 218 356 minecraft:blue_terracotta
setblock 142 215 360 minecraft:dark_prismarine
fill 142 215 361 142 218 361 minecraft:blue_terracotta
setblock 143 215 329 minecraft:dark_prismarine
fill 143 215 330 143 216 330 minecraft:blue_terracotta
setblock 143 215 334 minecraft:dark_prismarine
fill 143 215 335 143 218 335 minecraft:blue_terracotta
setblock 143 215 339 minecraft:dark_prismarine
fill 143 215 340 143 218 340 minecraft:blue_terracotta
setblock 143 215 344 minecraft:dark_prismarine
fill 143 215 345 143 218 345 minecraft:blue_terracotta
setblock 143 215 349 minecraft:dark_prismarine
setblock 143 215 350 minecraft:blue_terracotta
setblock 143 215 354 minecraft:dark_prismarine
fill 143 215 355 143 216 355 minecraft:blue_terracotta
setblock 143 215 359 minecraft:dark_prismarine
fill 143 215 360 143 217 360 minecraft:blue_terracotta
setblock 144 215 323 minecraft:dark_prismarine
setblock 144 215 325 minecraft:light[level=12]
setblock 144 215 333 minecraft:dark_prismarine
fill 144 215 334 144 217 334 minecraft:blue_terracotta
setblock 144 215 338 minecraft:dark_prismarine
fill 144 215 339 144 218 339 minecraft:blue_terracotta
fill 144 215 341 144 216 341 minecraft:blue_terracotta
setblock 144 215 343 minecraft:dark_prismarine
setblock 144 215 344 minecraft:blue_terracotta
setblock 144 215 346 minecraft:light[level=12]
setblock 144 215 353 minecraft:light[level=12]
setblock 144 215 360 minecraft:light[level=12]
setblock 144 215 363 minecraft:dark_prismarine
fill 145 215 323 145 218 323 minecraft:blue_terracotta
setblock 145 215 337 minecraft:dark_prismarine
fill 145 215 338 145 216 338 minecraft:blue_terracotta
setblock 145 215 362 minecraft:dark_prismarine
fill 145 215 363 145 218 363 minecraft:blue_terracotta
setblock 151 215 325 minecraft:light[level=12]
setblock 151 215 332 minecraft:light[level=12]
setblock 151 215 339 minecraft:light[level=12]
setblock 151 215 346 minecraft:light[level=12]
setblock 151 215 353 minecraft:light[level=12]
setblock 151 215 360 minecraft:light[level=12]
fill 152 215 323 153 215 323 minecraft:blue_terracotta
setblock 153 215 363 minecraft:blue_terracotta
setblock 154 215 323 minecraft:dark_prismarine
setblock 154 215 363 minecraft:dark_prismarine
fill 155 215 323 155 218 323 minecraft:blue_terracotta
setblock 155 215 362 minecraft:dark_prismarine
fill 155 215 363 155 218 363 minecraft:blue_terracotta
fill 156 215 324 156 216 324 minecraft:blue_terracotta
fill 156 215 362 159 215 362 minecraft:blue_terracotta
fill 157 215 361 160 215 361 minecraft:blue_terracotta
setblock 158 215 323 minecraft:blue_terracotta
setblock 158 215 324 minecraft:dark_prismarine
setblock 158 215 325 minecraft:light[level=12]
setblock 158 215 332 minecraft:light[level=12]
setblock 158 215 339 minecraft:light[level=12]
setblock 158 215 346 minecraft:light[level=12]
setblock 158 215 353 minecraft:light[level=12]
setblock 158 215 360 minecraft:light[level=12]
setblock 159 215 323 minecraft:dark_prismarine
fill 159 215 324 159 218 324 minecraft:blue_terracotta
setblock 159 215 363 minecraft:dark_prismarine
fill 160 215 323 160 218 323 minecraft:blue_terracotta
fill 160 215 360 161 215 360 minecraft:blue_terracotta
setblock 160 215 362 minecraft:dark_prismarine
fill 160 215 363 160 218 363 minecraft:blue_terracotta
setblock 161 215 361 minecraft:dark_prismarine
fill 161 215 362 161 218 362 minecraft:blue_terracotta
setblock 162 215 324 minecraft:blue_terracotta
setblock 162 215 360 minecraft:dark_prismarine
fill 162 215 361 162 218 361 minecraft:blue_terracotta
setblock 163 215 324 minecraft:dark_prismarine
fill 163 215 360 163 217 360 minecraft:blue_terracotta
setblock 164 215 323 minecraft:dark_prismarine
fill 164 215 324 164 217 324 minecraft:blue_terracotta
setblock 164 215 363 minecraft:dark_prismarine
fill 165 215 323 165 218 323 minecraft:blue_terracotta
setblock 165 215 325 minecraft:light[level=12]
setblock 165 215 332 minecraft:light[level=12]
setblock 165 215 339 minecraft:light[level=12]
setblock 165 215 346 minecraft:light[level=12]
setblock 165 215 353 minecraft:light[level=12]
setblock 165 215 362 minecraft:dark_prismarine
fill 165 215 363 165 218 363 minecraft:blue_terracotta
setblock 166 215 361 minecraft:dark_prismarine
fill 166 215 362 166 218 362 minecraft:blue_terracotta
fill 167 215 361 167 217 361 minecraft:blue_terracotta
setblock 169 215 363 minecraft:dark_prismarine
setblock 170 215 362 minecraft:dark_prismarine
fill 170 215 363 173 215 363 minecraft:blue_terracotta
fill 171 215 362 174 215 362 minecraft:blue_terracotta
setblock 172 215 325 minecraft:light[level=12]
setblock 172 215 332 minecraft:light[level=12]
setblock 172 215 339 minecraft:light[level=12]
setblock 172 215 346 minecraft:light[level=12]
setblock 172 215 353 minecraft:light[level=12]
setblock 172 215 360 minecraft:light[level=12]
fill 174 215 361 175 215 361 minecraft:blue_terracotta
setblock 174 215 363 minecraft:dark_prismarine
setblock 175 215 362 minecraft:dark_prismarine
fill 175 215 363 175 218 363 minecraft:blue_terracotta
setblock 176 215 361 minecraft:dark_prismarine
fill 176 215 362 176 218 362 minecraft:blue_terracotta
fill 177 215 361 177 218 361 minecraft:blue_terracotta
setblock 178 215 323 minecraft:blue_terracotta
fill 178 215 360 178 216 360 minecraft:blue_terracotta
setblock 179 215 323 minecraft:dark_prismarine
setblock 179 215 325 minecraft:light[level=12]
setblock 179 215 332 minecraft:light[level=12]
setblock 179 215 339 minecraft:light[level=12]
setblock 179 215 346 minecraft:light[level=12]
setblock 179 215 353 minecraft:light[level=12]
setblock 179 215 357 minecraft:blue_terracotta
setblock 179 215 358 minecraft:dark_prismarine
fill 179 215 359 179 216 359 minecraft:blue_terracotta
setblock 179 215 363 minecraft:dark_prismarine
fill 180 215 323 180 218 323 minecraft:blue_terracotta
setblock 180 215 336 minecraft:blue_terracotta
setblock 180 215 337 minecraft:dark_prismarine
fill 180 215 338 180 218 338 minecraft:blue_terracotta
fill 180 215 340 180 215 341 minecraft:blue_terracotta
setblock 180 215 342 minecraft:dark_prismarine
fill 180 215 343 180 218 343 minecraft:blue_terracotta
fill 180 215 345 180 215 346 minecraft:blue_terracotta
setblock 180 215 352 minecraft:dark_prismarine
fill 180 215 353 180 217 353 minecraft:blue_terracotta
setblock 180 215 357 minecraft:dark_prismarine
fill 180 215 358 180 218 358 minecraft:blue_terracotta
setblock 180 215 362 minecraft:dark_prismarine
fill 180 215 363 180 218 363 minecraft:blue_terracotta
fill 181 215 332 181 216 332 minecraft:blue_terracotta
setblock 181 215 336 minecraft:dark_prismarine
fill 181 215 337 181 218 337 minecraft:blue_terracotta
setblock 181 215 340 minecraft:blue_terracotta
setblock 181 215 341 minecraft:dark_prismarine
fill 181 215 342 181 218 342 minecraft:blue_terracotta
setblock 181 215 346 minecraft:dark_prismarine
fill 181 215 347 181 218 347 minecraft:blue_terracotta
setblock 181 215 351 minecraft:dark_prismarine
fill 181 215 352 181 218 352 minecraft:blue_terracotta
setblock 181 215 356 minecraft:dark_prismarine
fill 181 215 357 181 218 357 minecraft:blue_terracotta
setblock 181 215 361 minecraft:dark_prismarine
fill 181 215 362 181 218 362 minecraft:blue_terracotta
setblock 182 215 324 minecraft:blue_terracotta
setblock 182 215 325 minecraft:dark_prismarine
setblock 182 215 330 minecraft:dark_prismarine
fill 182 215 331 182 217 331 minecraft:blue_terracotta
setblock 182 215 335 minecraft:dark_prismarine
fill 182 215 336 182 218 336 minecraft:blue_terracotta
setblock 182 215 340 minecraft:dark_prismarine
fill 182 215 341 182 218 341 minecraft:blue_terracotta
setblock 182 215 345 minecraft:dark_prismarine
fill 182 215 346 182 218 346 minecraft:blue_terracotta
setblock 182 215 350 minecraft:dark_prismarine
fill 182 215 351 182 218 351 minecraft:blue_terracotta
setblock 182 215 355 minecraft:dark_prismarine
fill 182 215 356 182 218 356 minecraft:blue_terracotta
setblock 182 215 360 minecraft:dark_prismarine
fill 182 215 361 182 218 361 minecraft:blue_terracotta
fill 183 215 327 183 220 327 minecraft:blue_terracotta
fill 141 216 358 141 220 358 minecraft:blue_terracotta
setblock 142 216 324 minecraft:dark_prismarine
fill 142 216 325 142 219 325 minecraft:blue_terracotta
setblock 142 216 329 minecraft:dark_prismarine
fill 142 216 330 142 219 330 minecraft:blue_terracotta
setblock 142 216 334 minecraft:dark_prismarine
fill 142 216 335 142 219 335 minecraft:blue_terracotta
setblock 142 216 339 minecraft:dark_prismarine
fill 142 216 340 142 219 340 minecraft:blue_terracotta
setblock 142 216 344 minecraft:dark_prismarine
fill 142 216 345 142 219 345 minecraft:blue_terracotta
setblock 142 216 349 minecraft:dark_prismarine
fill 142 216 350 142 218 350 minecraft:blue_terracotta
setblock 142 216 354 minecraft:dark_prismarine
fill 142 216 355 142 218 355 minecraft:blue_terracotta
setblock 142 216 359 minecraft:dark_prismarine
fill 142 216 360 142 219 360 minecraft:blue_terracotta
setblock 143 216 323 minecraft:dark_prismarine
setblock 143 216 329 minecraft:blue_terracotta
setblock 143 216 333 minecraft:dark_prismarine
fill 143 216 334 143 219 334 minecraft:blue_terracotta
setblock 143 216 338 minecraft:dark_prismarine
fill 143 216 339 143 219 339 minecraft:blue_terracotta
setblock 143 216 343 minecraft:dark_prismarine
fill 143 216 344 143 219 344 minecraft:blue_terracotta
setblock 143 216 354 minecraft:blue_terracotta
setblock 143 216 358 minecraft:dark_prismarine
fill 143 216 359 143 217 359 minecraft:blue_terracotta
setblock 143 216 363 minecraft:dark_prismarine
fill 144 216 323 144 219 323 minecraft:blue_terracotta
setblock 144 216 332 minecraft:dark_prismarine
setblock 144 216 333 minecraft:blue_terracotta
setblock 144 216 337 minecraft:dark_prismarine
fill 144 216 338 144 219 338 minecraft:blue_terracotta
setblock 144 216 342 minecraft:dark_prismarine
fill 144 216 343 144 217 343 minecraft:blue_terracotta
setblock 144 216 362 minecraft:dark_prismarine
fill 144 216 363 144 219 363 minecraft:blue_terracotta
setblock 145 216 336 minecraft:dark_prismarine
setblock 145 216 337 minecraft:blue_terracotta
setblock 148 216 323 minecraft:dark_prismarine
fill 148 216 363 148 217 363 minecraft:purple_concrete
fill 151 216 323 152 216 323 minecraft:blue_terracotta
setblock 152 216 363 minecraft:blue_terracotta
setblock 153 216 323 minecraft:dark_prismarine
setblock 153 216 363 minecraft:dark_prismarine
fill 154 216 323 154 219 323 minecraft:blue_terracotta
fill 154 216 363 154 219 363 minecraft:blue_terracotta
fill 155 216 362 158 216 362 minecraft:blue_terracotta
setblock 157 216 324 minecraft:dark_prismarine
fill 157 216 361 159 216 361 minecraft:blue_terracotta
setblock 158 216 323 minecraft:dark_prismarine
fill 158 216 324 158 219 324 minecraft:blue_terracotta
setblock 158 216 363 minecraft:dark_prismarine
fill 159 216 323 159 219 323 minecraft:blue_terracotta
fill 159 216 360 160 216 360 minecraft:blue_terracotta
setblock 159 216 362 minecraft:dark_prismarine
fill 159 216 363 159 219 363 minecraft:blue_terracotta
setblock 160 216 361 minecraft:dark_prismarine
fill 160 216 362 160 219 362 minecraft:blue_terracotta
setblock 161 216 324 minecraft:blue_terracotta
setblock 161 216 360 minecraft:dark_prismarine
fill 161 216 361 161 219 361 minecraft:blue_terracotta
setblock 162 216 324 minecraft:dark_prismarine
fill 162 216 360 162 218 360 minecraft:blue_terracotta
setblock 163 216 323 minecraft:dark_prismarine
fill 163 216 324 163 219 324 minecraft:blue_terracotta
setblock 163 216 363 minecraft:dark_prismarine
fill 164 216 323 164 219 323 minecraft:blue_terracotta
setblock 164 216 362 minecraft:dark_prismarine
fill 164 216 363 164 219 363 minecraft:blue_terracotta
setblock 165 216 361 minecraft:dark_prismarine
fill 165 216 362 165 219 362 minecraft:blue_terracotta
fill 166 216 361 166 218 361 minecraft:blue_terracotta
setblock 168 216 323 minecraft:dark_prismarine
setblock 168 216 363 minecraft:dark_prismarine
setblock 169 216 361 minecraft:blue_terracotta
setblock 169 216 362 minecraft:dark_prismarine
fill 169 216 363 172 216 363 minecraft:blue_terracotta
fill 170 216 362 173 216 362 minecraft:blue_terracotta
setblock 173 216 363 minecraft:dark_prismarine
setblock 174 216 361 minecraft:blue_terracotta
setblock 174 216 362 minecraft:dark_prismarine
fill 174 216 363 174 219 363 minecraft:blue_terracotta
setblock 175 216 361 minecraft:dark_prismarine
fill 175 216 362 175 219 362 minecraft:blue_terracotta
setblock 176 216 323 minecraft:purple_concrete
fill 176 216 361 176 219 361 minecraft:blue_terracotta
setblock 178 216 323 minecraft:dark_prismarine
setblock 178 216 363 minecraft:dark_prismarine
fill 179 216 323 179 219 323 minecraft:blue_terracotta
setblock 179 216 357 minecraft:dark_prismarine
setblock 179 216 358 minecraft:blue_terracotta
setblock 179 216 362 minecraft:dark_prismarine
fill 179 216 363 179 219 363 minecraft:blue_terracotta
setblock 180 216 336 minecraft:dark_prismarine
fill 180 216 337 180 219 337 minecraft:blue_terracotta
setblock 180 216 340 minecraft:blue_terracotta
setblock 180 216 341 minecraft:dark_prismarine
fill 180 216 342 180 219 342 minecraft:blue_terracotta
setblock 180 216 345 minecraft:blue_terracotta
setblock 180 216 346 minecraft:dark_prismarine
setblock 180 216 351 minecraft:dark_prismarine
setblock 180 216 352 minecraft:blue_terracotta
setblock 180 216 356 minecraft:dark_prismarine
fill 180 216 357 180 218 357 minecraft:blue_terracotta
setblock 180 216 361 minecraft:dark_prismarine
fill 180 216 362 180 219 362 minecraft:blue_terracotta
setblock 181 216 335 minecraft:dark_prismarine
fill 181 216 336 181 219 336 minecraft:blue_terracotta
setblock 181 216 340 minecraft:dark_prismarine
fill 181 216 341 181 219 341 minecraft:blue_terracotta
setblock 181 216 345 minecraft:dark_prismarine
fill 181 216 346 181 219 346 minecraft:blue_terracotta
setblock 181 216 350 minecraft:dark_prismarine
fill 181 216 351 181 218 351 minecraft:blue_terracotta
setblock 181 216 355 minecraft:dark_prismarine
fill 181 216 356 181 219 356 minecraft:blue_terracotta
setblock 181 216 360 minecraft:dark_prismarine
fill 181 216 361 181 219 361 minecraft:blue_terracotta
setblock 182 216 324 minecraft:dark_prismarine
setblock 182 216 329 minecraft:dark_prismarine
fill 182 216 330 182 217 330 minecraft:blue_terracotta
setblock 182 216 334 minecraft:dark_prismarine
fill 182 216 335 182 219 335 minecraft:blue_terracotta
setblock 182 216 339 minecraft:dark_prismarine
fill 182 216 340 182 219 340 minecraft:blue_terracotta
setblock 182 216 344 minecraft:dark_prismarine
fill 182 216 345 182 219 345 minecraft:blue_terracotta
setblock 182 216 349 minecraft:dark_prismarine
fill 182 216 350 182 219 350 minecraft:blue_terracotta
setblock 182 216 354 minecraft:dark_prismarine
fill 182 216 355 182 219 355 minecraft:blue_terracotta
setblock 182 216 359 minecraft:dark_prismarine
fill 182 216 360 182 219 360 minecraft:blue_terracotta
setblock 141 217 328 minecraft:blue_concrete
setblock 141 217 337 minecraft:blue_concrete
setblock 141 217 339 minecraft:blue_concrete
setblock 141 217 348 minecraft:light_blue_wool
fill 141 217 364 142 217 364 minecraft:blue_concrete
setblock 142 217 323 minecraft:dark_prismarine
fill 142 217 324 142 220 324 minecraft:blue_terracotta
setblock 142 217 328 minecraft:dark_prismarine
fill 142 217 329 142 220 329 minecraft:blue_terracotta
setblock 142 217 333 minecraft:dark_prismarine
fill 142 217 334 142 220 334 minecraft:blue_terracotta
setblock 142 217 338 minecraft:dark_prismarine
fill 142 217 339 142 220 339 minecraft:blue_terracotta
setblock 142 217 343 minecraft:dark_prismarine
fill 142 217 344 142 220 344 minecraft:blue_terracotta
setblock 142 217 348 minecraft:dark_prismarine
fill 142 217 349 142 218 349 minecraft:blue_terracotta
setblock 142 217 353 minecraft:dark_prismarine
fill 142 217 354 142 218 354 minecraft:blue_terracotta
setblock 142 217 358 minecraft:dark_prismarine
fill 142 217 359 142 220 359 minecraft:blue_terracotta
setblock 142 217 363 minecraft:dark_prismarine
fill 143 217 323 143 220 323 minecraft:blue_terracotta
setblock 143 217 332 minecraft:dark_prismarine
fill 143 217 333 143 218 333 minecraft:blue_terracotta
setblock 143 217 337 minecraft:dark_prismarine
fill 143 217 338 143 220 338 minecraft:blue_terracotta
setblock 143 217 342 minecraft:dark_prismarine
fill 143 217 343 143 220 343 minecraft:blue_terracotta
setblock 143 217 358 minecraft:blue_terracotta
setblock 143 217 362 minecraft:dark_prismarine
fill 143 217 363 143 220 363 minecraft:blue_terracotta
setblock 144 217 336 minecraft:dark_prismarine
fill 144 217 337 144 218 337 minecraft:blue_terracotta
setblock 144 217 341 minecraft:dark_prismarine
fill 144 217 342 144 218 342 minecraft:blue_terracotta
setblock 147 217 323 minecraft:dark_prismarine
setblock 151 217 323 minecraft:blue_terracotta
setblock 152 217 322 minecraft:blue_concrete
setblock 152 217 323 minecraft:dark_prismarine
setblock 152 217 363 minecraft:dark_prismarine
fill 153 217 323 153 220 323 minecraft:blue_terracotta
fill 153 217 363 153 220 363 minecraft:blue_terracotta
fill 154 217 330 155 234 330 minecraft:magenta_terracotta
fill 154 217 362 157 217 362 minecraft:blue_terracotta
setblock 155 217 324 minecraft:blue_terracotta
setblock 156 217 324 minecraft:dark_prismarine
setblock 157 217 322 minecraft:blue_concrete
setblock 157 217 323 minecraft:dark_prismarine
fill 157 217 324 157 220 324 minecraft:blue_terracotta
fill 157 217 361 158 217 361 minecraft:blue_terracotta
setblock 157 217 363 minecraft:dark_prismarine
fill 158 217 322 158 220 323 minecraft:blue_terracotta
setblock 158 217 362 minecraft:dark_prismarine
fill 158 217 363 158 220 363 minecraft:blue_terracotta
setblock 159 217 322 minecraft:blue_concrete
setblock 159 217 360 minecraft:blue_terracotta
setblock 159 217 361 minecraft:dark_prismarine
fill 159 217 362 159 220 362 minecraft:blue_terracotta
setblock 160 217 324 minecraft:blue_terracotta
setblock 160 217 360 minecraft:dark_prismarine
fill 160 217 361 160 220 361 minecraft:blue_terracotta
setblock 161 217 324 minecraft:dark_prismarine
fill 161 217 360 161 218 360 minecraft:blue_terracotta
setblock 162 217 323 minecraft:dark_prismarine
fill 162 217 324 162 220 324 minecraft:blue_terracotta
setblock 162 217 363 minecraft:dark_prismarine
fill 163 217 322 164 217 322 minecraft:blue_concrete
fill 163 217 323 163 220 323 minecraft:blue_terracotta
setblock 163 217 362 minecraft:dark_prismarine
fill 163 217 363 163 220 363 minecraft:blue_terracotta
setblock 164 217 361 minecraft:dark_prismarine
fill 164 217 362 164 220 362 minecraft:blue_terracotta
setblock 164 217 364 minecraft:blue_concrete
fill 165 217 361 165 219 361 minecraft:blue_terracotta
fill 165 217 364 166 220 364 minecraft:blue_terracotta
fill 167 217 322 167 218 322 minecraft:blue_concrete
setblock 167 217 323 minecraft:dark_prismarine
setblock 167 217 363 minecraft:dark_prismarine
fill 168 217 322 168 220 322 minecraft:blue_terracotta
setblock 168 217 362 minecraft:dark_prismarine
fill 168 217 363 171 217 363 minecraft:blue_terracotta
setblock 169 217 322 minecraft:blue_concrete
fill 169 217 362 172 217 362 minecraft:blue_terracotta
setblock 170 217 323 minecraft:purple_concrete
setblock 170 217 364 minecraft:blue_concrete
fill 171 217 322 172 220 322 minecraft:blue_terracotta
setblock 172 217 363 minecraft:dark_prismarine
setblock 173 217 322 minecraft:blue_concrete
setblock 173 217 362 minecraft:dark_prismarine
fill 173 217 363 173 220 363 minecraft:blue_terracotta
fill 174 217 322 174 220 322 minecraft:blue_terracotta
fill 174 217 362 174 220 362 minecraft:blue_terracotta
setblock 175 217 322 minecraft:blue_concrete
fill 175 217 361 175 218 361 minecraft:blue_terracotta
setblock 177 217 323 minecraft:dark_prismarine
setblock 177 217 363 minecraft:dark_prismarine
fill 178 217 323 178 220 323 minecraft:blue_terracotta
setblock 178 217 362 minecraft:dark_prismarine
fill 178 217 363 178 220 363 minecraft:blue_terracotta
fill 179 217 322 179 220 322 minecraft:blue_terracotta
setblock 179 217 361 minecraft:dark_prismarine
fill 179 217 362 179 220 362 minecraft:blue_terracotta
setblock 180 217 322 minecraft:blue_concrete
fill 180 217 336 180 218 336 minecraft:blue_terracotta
setblock 180 217 340 minecraft:dark_prismarine
fill 180 217 341 180 220 341 minecraft:blue_terracotta
setblock 180 217 345 minecraft:dark_prismarine
fill 180 217 346 180 220 346 minecraft:blue_terracotta
setblock 180 217 355 minecraft:dark_prismarine
fill 180 217 356 180 218 356 minecraft:blue_terracotta
setblock 180 217 360 minecraft:dark_prismarine
fill 180 217 361 180 219 361 minecraft:blue_terracotta
setblock 181 217 323 minecraft:blue_terracotta
setblock 181 217 334 minecraft:dark_prismarine
fill 181 217 335 181 219 335 minecraft:blue_terracotta
setblock 181 217 339 minecraft:dark_prismarine
fill 181 217 340 181 220 340 minecraft:blue_terracotta
setblock 181 217 344 minecraft:dark_prismarine
fill 181 217 345 181 220 345 minecraft:blue_terracotta
setblock 181 217 349 minecraft:dark_prismarine
fill 181 217 350 181 219 350 minecraft:blue_terracotta
setblock 181 217 354 minecraft:dark_prismarine
fill 181 217 355 181 219 355 minecraft:blue_terracotta
setblock 181 217 359 minecraft:dark_prismarine
fill 181 217 360 181 220 360 minecraft:blue_terracotta
setblock 182 217 323 minecraft:dark_prismarine
setblock 182 217 324 minecraft:blue_terracotta
setblock 182 217 333 minecraft:dark_prismarine
fill 182 217 334 182 220 334 minecraft:blue_terracotta
setblock 182 217 338 minecraft:dark_prismarine
fill 182 217 339 182 220 339 minecraft:blue_terracotta
setblock 182 217 343 minecraft:dark_prismarine
fill 182 217 344 182 220 344 minecraft:blue_terracotta
setblock 182 217 348 minecraft:dark_prismarine
fill 182 217 349 182 220 349 minecraft:blue_terracotta
setblock 182 217 353 minecraft:dark_prismarine
fill 182 217 354 182 220 354 minecraft:blue_terracotta
setblock 182 217 358 minecraft:dark_prismarine
fill 182 217 359 182 220 359 minecraft:blue_terracotta
setblock 182 217 363 minecraft:dark_prismarine
setblock 182 217 364 minecraft:blue_concrete
fill 183 217 322 183 218 322 minecraft:blue_concrete
fill 183 217 323 183 220 323 minecraft:blue_terracotta
setblock 183 217 336 minecraft:blue_concrete
fill 183 217 344 183 219 344 minecraft:blue_concrete
setblock 183 217 360 minecraft:blue_concrete
fill 183 217 364 183 220 364 minecraft:blue_terracotta
setblock 141 218 326 minecraft:blue_concrete
fill 141 218 328 142 220 328 minecraft:blue_terracotta
fill 141 218 334 141 220 334 minecraft:blue_terracotta
setblock 141 218 335 minecraft:blue_concrete
fill 141 218 337 141 220 337 minecraft:blue_terracotta
fill 141 218 339 141 220 339 minecraft:blue_terracotta
setblock 141 218 343 minecraft:blue_concrete
fill 141 218 348 142 220 348 minecraft:blue_terracotta
setblock 141 218 357 minecraft:blue_concrete
fill 141 218 364 142 218 364 minecraft:blue_terracotta
fill 142 218 323 142 221 323 minecraft:blue_terracotta
setblock 142 218 327 minecraft:dark_prismarine
setblock 142 218 332 minecraft:dark_prismarine
fill 142 218 333 142 221 333 minecraft:blue_terracotta
setblock 142 218 337 minecraft:dark_prismarine
fill 142 218 338 142 221 338 minecraft:blue_terracotta
setblock 142 218 342 minecraft:dark_prismarine
fill 142 218 343 142 221 343 minecraft:blue_terracotta
setblock 142 218 347 minecraft:dark_prismarine
setblock 142 218 357 minecraft:dark_prismarine
fill 142 218 358 142 219 358 minecraft:blue_terracotta
setblock 142 218 362 minecraft:dark_prismarine
fill 142 218 363 142 221 363 minecraft:blue_terracotta
setblock 143 218 332 minecraft:blue_terracotta
setblock 143 218 336 minecraft:dark_prismarine
fill 143 218 337 143 221 337 minecraft:blue_terracotta
setblock 143 218 341 minecraft:dark_prismarine
fill 143 218 342 143 221 342 minecraft:blue_terracotta
setblock 144 218 336 minecraft:blue_terracotta
setblock 144 218 340 minecraft:dark_prismarine
fill 144 218 341 144 219 341 minecraft:blue_terracotta
setblock 146 218 323 minecraft:dark_prismarine
fill 146 218 359 146 228 359 minecraft:iron_bars
fill 147 218 323 147 221 323 minecraft:blue_terracotta
fill 149 218 322 149 220 322 minecraft:blue_terracotta
setblock 150 218 322 minecraft:blue_concrete
setblock 150 218 323 minecraft:blue_terracotta
setblock 151 218 323 minecraft:dark_prismarine
setblock 151 218 363 minecraft:dark_prismarine
fill 152 218 322 152 218 323 minecraft:blue_terracotta
fill 152 218 363 152 221 363 minecraft:blue_terracotta
fill 154 218 362 156 218 362 minecraft:blue_terracotta
setblock 155 218 324 minecraft:dark_prismarine
setblock 156 218 323 minecraft:dark_prismarine
fill 156 218 324 156 221 324 minecraft:blue_terracotta
fill 156 218 361 157 218 361 minecraft:blue_terracotta
setblock 156 218 363 minecraft:dark_prismarine
fill 157 218 322 157 220 323 minecraft:blue_terracotta
setblock 157 218 362 minecraft:dark_prismarine
fill 157 218 363 157 221 363 minecraft:blue_terracotta
setblock 158 218 361 minecraft:dark_prismarine
fill 158 218 362 158 221 362 minecraft:blue_terracotta
fill 159 218 322 159 220 322 minecraft:blue_terracotta
fill 159 218 361 159 221 361 minecraft:blue_terracotta
setblock 160 218 324 minecraft:dark_prismarine
setblock 160 218 360 minecraft:blue_terracotta
setblock 161 218 323 minecraft:dark_prismarine
fill 161 218 324 161 221 324 minecraft:blue_terracotta
setblock 161 218 363 minecraft:dark_prismarine
fill 162 218 323 162 221 323 minecraft:blue_terracotta
setblock 162 218 362 minecraft:dark_prismarine
fill 162 218 363 162 221 363 minecraft:blue_terracotta
fill 163 218 322 164 220 322 minecraft:blue_terracotta
setblock 163 218 361 minecraft:dark_prismarine
fill 163 218 362 163 221 362 minecraft:blue_terracotta
fill 164 218 361 164 220 361 minecraft:blue_terracotta
fill 164 218 364 164 220 364 minecraft:blue_terracotta
setblock 166 218 322 minecraft:blue_concrete
setblock 166 218 323 minecraft:dark_prismarine
setblock 166 218 363 minecraft:dark_prismarine
setblock 167 218 323 minecraft:blue_terracotta
setblock 167 218 362 minecraft:dark_prismarine
fill 167 218 363 170 218 363 minecraft:blue_terracotta
fill 168 218 362 171 218 362 minecraft:blue_terracotta
fill 169 218 322 169 220 322 minecraft:blue_terracotta
fill 170 218 364 170 220 364 minecraft:blue_terracotta
setblock 171 218 363 minecraft:dark_prismarine
setblock 171 218 364 minecraft:blue_concrete
setblock 172 218 362 minecraft:dark_prismarine
fill 172 218 363 172 221 363 minecraft:blue_terracotta
fill 173 218 322 173 220 322 minecraft:blue_terracotta
fill 173 218 362 173 221 362 minecraft:blue_terracotta
setblock 175 218 322 minecraft:blue_terracotta
setblock 175 218 364 minecraft:blue_concrete
setblock 176 218 322 minecraft:cyan_concrete
setblock 176 218 363 minecraft:dark_prismarine
fill 176 218 364 176 220 364 minecraft:blue_terracotta
fill 177 218 323 177 221 323 minecraft:blue_terracotta
setblock 177 218 362 minecraft:dark_prismarine
fill 177 218 363 177 221 363 minecraft:blue_terracotta
setblock 177 218 364 minecraft:blue_concrete
setblock 178 218 361 minecraft:dark_prismarine
fill 178 218 362 178 221 362 minecraft:blue_terracotta
fill 179 218 361 179 219 361 minecraft:blue_terracotta
fill 180 218 322 180 220 322 minecraft:blue_terracotta
setblock 180 218 339 minecraft:dark_prismarine
fill 180 218 340 180 221 340 minecraft:blue_terracotta
setblock 180 218 344 minecraft:dark_prismarine
fill 180 218 345 180 221 345 minecraft:blue_terracotta
setblock 180 218 359 minecraft:dark_prismarine
fill 180 218 360 180 219 360 minecraft:blue_terracotta
setblock 181 218 323 minecraft:dark_prismarine
setblock 181 218 334 minecraft:blue_terracotta
setblock 181 218 338 minecraft:dark_prismarine
fill 181 218 339 181 221 339 minecraft:blue_terracotta
setblock 181 218 343 minecraft:dark_prismarine
fill 181 218 344 181 221 344 minecraft:blue_terracotta
setblock 181 218 348 minecraft:dark_prismarine
fill 181 218 349 181 221 349 minecraft:blue_terracotta
setblock 181 218 353 minecraft:dark_prismarine
fill 181 218 354 181 219 354 minecraft:blue_terracotta
setblock 181 218 358 minecraft:dark_prismarine
fill 181 218 359 181 220 359 minecraft:blue_terracotta
setblock 181 218 363 minecraft:dark_prismarine
fill 182 218 323 182 221 323 minecraft:blue_terracotta
setblock 182 218 330 minecraft:purple_concrete
setblock 182 218 332 minecraft:dark_prismarine
fill 182 218 333 182 220 333 minecraft:blue_terracotta
setblock 182 218 337 minecraft:dark_prismarine
fill 182 218 338 182 221 338 minecraft:blue_terracotta
setblock 182 218 342 minecraft:dark_prismarine
fill 182 218 343 182 221 343 minecraft:blue_terracotta
setblock 182 218 347 minecraft:dark_prismarine
fill 182 218 348 182 221 348 minecraft:blue_terracotta
setblock 182 218 352 minecraft:dark_prismarine
fill 182 218 353 182 220 353 minecraft:blue_terracotta
setblock 182 218 357 minecraft:dark_prismarine
fill 182 218 358 182 221 358 minecraft:blue_terracotta
setblock 182 218 362 minecraft:dark_prismarine
fill 182 218 363 182 221 364 minecraft:blue_terracotta
fill 183 218 325 183 220 325 minecraft:blue_terracotta
setblock 183 218 326 minecraft:blue_concrete
fill 183 218 330 183 218 331 minecraft:blue_concrete
fill 183 218 336 183 220 336 minecraft:blue_terracotta
setblock 183 218 343 minecraft:blue_concrete
fill 183 218 345 183 220 346 minecraft:blue_terracotta
setblock 183 218 347 minecraft:blue_concrete
setblock 183 218 349 minecraft:blue_concrete
fill 183 218 360 183 220 360 minecraft:blue_terracotta
setblock 141 219 322 minecraft:blue_concrete
fill 141 219 323 141 220 323 minecraft:blue_terracotta
setblock 141 219 324 minecraft:blue_concrete
fill 141 219 325 141 220 326 minecraft:blue_terracotta
fill 141 219 329 141 220 330 minecraft:blue_terracotta
setblock 141 219 331 minecraft:light_blue_wool
fill 141 219 335 141 220 335 minecraft:blue_terracotta
setblock 141 219 336 minecraft:blue_concrete
fill 141 219 343 141 220 343 minecraft:blue_terracotta
fill 141 219 353 141 220 354 minecraft:blue_terracotta
fill 141 219 355 141 219 356 minecraft:blue_concrete
fill 141 219 357 142 219 357 minecraft:blue_terracotta
fill 141 219 361 141 220 362 minecraft:blue_terracotta
fill 141 219 363 141 219 364 minecraft:blue_concrete
setblock 142 219 326 minecraft:dark_prismarine
fill 142 219 327 142 222 327 minecraft:blue_terracotta
setblock 142 219 331 minecraft:dark_prismarine
fill 142 219 332 142 222 332 minecraft:blue_terracotta
setblock 142 219 336 minecraft:dark_prismarine
fill 142 219 337 142 222 337 minecraft:blue_terracotta
setblock 142 219 341 minecraft:dark_prismarine
fill 142 219 342 142 222 342 minecraft:blue_terracotta
setblock 142 219 346 minecraft:dark_prismarine
fill 142 219 347 142 222 347 minecraft:blue_terracotta
setblock 142 219 361 minecraft:dark_prismarine
fill 142 219 362 142 222 362 minecraft:blue_terracotta
fill 142 219 364 142 220 364 minecraft:blue_terracotta
setblock 143 219 335 minecraft:dark_prismarine
fill 143 219 336 143 221 336 minecraft:blue_terracotta
setblock 143 219 340 minecraft:dark_prismarine
fill 143 219 341 143 222 341 minecraft:blue_terracotta
setblock 143 219 345 minecraft:dark_prismarine
setblock 144 219 339 minecraft:dark_prismarine
setblock 144 219 340 minecraft:blue_terracotta
setblock 145 219 323 minecraft:dark_prismarine
setblock 145 219 363 minecraft:dark_prismarine
fill 146 219 322 146 220 323 minecraft:blue_terracotta
setblock 147 219 322 minecraft:light_blue_wool
fill 147 219 364 148 219 364 minecraft:blue_concrete
fill 148 219 323 149 219 323 minecraft:blue_terracotta
fill 148 219 360 148 222 360 minecraft:black_concrete
fill 149 219 359 149 222 359 minecraft:black_concrete
fill 149 219 361 149 222 361 minecraft:black_concrete
fill 150 219 322 150 220 322 minecraft:blue_terracotta
setblock 150 219 323 minecraft:dark_prismarine
fill 150 219 360 150 222 360 minecraft:black_concrete
fill 151 219 323 152 221 323 minecraft:blue_terracotta
fill 151 219 363 151 222 363 minecraft:blue_terracotta
setblock 152 219 322 minecraft:blue_concrete
setblock 154 219 324 minecraft:dark_prismarine
fill 154 219 362 155 219 362 minecraft:blue_terracotta
setblock 155 219 323 minecraft:dark_prismarine
fill 155 219 324 155 222 324 minecraft:blue_terracotta
setblock 155 219 363 minecraft:dark_prismarine
fill 156 219 323 156 222 323 minecraft:blue_terracotta
setblock 156 219 361 minecraft:blue_terracotta
setblock 156 219 362 minecraft:dark_prismarine
fill 156 219 363 156 222 363 minecraft:blue_terracotta
setblock 156 219 364 minecraft:blue_concrete
setblock 157 219 361 minecraft:dark_prismarine
fill 157 219 362 157 222 362 minecraft:blue_terracotta
fill 158 219 361 158 222 361 minecraft:blue_terracotta
setblock 159 219 324 minecraft:dark_prismarine
setblock 160 219 323 minecraft:dark_prismarine
fill 160 219 324 160 222 324 minecraft:blue_terracotta
setblock 160 219 363 minecraft:dark_prismarine
fill 161 219 323 161 222 323 minecraft:blue_terracotta
setblock 161 219 362 minecraft:dark_prismarine
fill 161 219 363 161 222 363 minecraft:blue_terracotta
setblock 162 219 361 minecraft:dark_prismarine
fill 162 219 362 162 222 362 minecraft:blue_terracotta
fill 163 219 361 163 221 361 minecraft:blue_terracotta
setblock 165 219 323 minecraft:dark_prismarine
setblock 165 219 363 minecraft:dark_prismarine
fill 166 219 322 166 220 323 minecraft:blue_terracotta
setblock 166 219 362 minecraft:dark_prismarine
fill 166 219 363 169 219 363 minecraft:blue_terracotta
fill 167 219 322 167 220 322 minecraft:blue_terracotta
fill 167 219 362 170 219 362 minecraft:blue_terracotta
setblock 170 219 322 minecraft:blue_concrete
fill 170 219 327 170 234 327 minecraft:magenta_terracotta
setblock 170 219 363 minecraft:dark_prismarine
setblock 171 219 362 minecraft:dark_prismarine
fill 171 219 363 171 220 364 minecraft:blue_terracotta
fill 172 219 362 172 222 362 minecraft:blue_terracotta
setblock 175 219 322 minecraft:blue_concrete
setblock 175 219 363 minecraft:dark_prismarine
fill 175 219 364 175 220 364 minecraft:blue_terracotta
fill 176 219 322 176 220 323 minecraft:blue_terracotta
setblock 176 219 362 minecraft:dark_prismarine
fill 176 219 363 176 222 363 minecraft:blue_terracotta
setblock 177 219 322 minecraft:cyan_concrete
setblock 177 219 361 minecraft:dark_prismarine
fill 177 219 362 177 222 362 minecraft:blue_terracotta
fill 177 219 364 177 221 364 minecraft:blue_terracotta
fill 178 219 361 178 220 361 minecraft:blue_terracotta
setblock 180 219 323 minecraft:dark_prismarine
setblock 180 219 338 minecraft:dark_prismarine
fill 180 219 339 180 222 339 minecraft:blue_terracotta
setblock 180 219 343 minecraft:dark_prismarine
fill 180 219 344 180 222 344 minecraft:blue_terracotta
setblock 180 219 359 minecraft:blue_terracotta
setblock 180 219 363 minecraft:dark_prismarine
fill 181 219 323 181 222 323 minecraft:blue_terracotta
setblock 181 219 337 minecraft:dark_prismarine
fill 181 219 338 181 222 338 minecraft:blue_terracotta
setblock 181 219 342 minecraft:dark_prismarine
fill 181 219 343 181 222 343 minecraft:blue_terracotta
setblock 181 219 347 minecraft:dark_prismarine
fill 181 219 348 181 222 348 minecraft:blue_terracotta
setblock 181 219 357 minecraft:dark_prismarine
fill 181 219 358 181 220 358 minecraft:blue_terracotta
setblock 181 219 362 minecraft:dark_prismarine
fill 181 219 363 181 222 363 minecraft:blue_terracotta
setblock 182 219 324 minecraft:purple_concrete
setblock 182 219 336 minecraft:dark_prismarine
fill 182 219 337 182 222 337 minecraft:blue_terracotta
setblock 182 219 341 minecraft:dark_prismarine
fill 182 219 342 182 222 342 minecraft:blue_terracotta
setblock 182 219 346 minecraft:dark_prismarine
fill 182 219 347 183 220 347 minecraft:blue_terracotta
setblock 182 219 351 minecraft:dark_prismarine
fill 182 219 352 182 221 352 minecraft:blue_terracotta
setblock 182 219 356 minecraft:dark_prismarine
fill 182 219 357 182 221 357 minecraft:blue_terracotta
setblock 182 219 361 minecraft:dark_prismarine
fill 182 219 362 183 220 362 minecraft:blue_terracotta
fill 183 219 322 183 220 322 minecraft:blue_terracotta
fill 183 219 326 183 220 326 minecraft:blue_terracotta
fill 183 219 330 183 220 331 minecraft:blue_terracotta
fill 183 219 343 183 220 343 minecraft:blue_terracotta
fill 183 219 349 183 220 349 minecraft:blue_terracotta
setblock 183 219 352 minecraft:blue_concrete
setblock 183 219 361 minecraft:light_blue_wool
setblock 141 220 322 minecraft:blue_terracotta
fill 141 220 324 141 221 324 minecraft:blue_terracotta
fill 141 220 331 142 220 331 minecraft:blue_terracotta
fill 141 220 336 142 220 336 minecraft:blue_terracotta
fill 141 220 355 141 220 357 minecraft:blue_terracotta
fill 141 220 363 141 220 364 minecraft:blue_terracotta
setblock 142 220 325 minecraft:dark_prismarine
fill 142 220 326 142 223 326 minecraft:blue_terracotta
setblock 142 220 330 minecraft:dark_prismarine
setblock 142 220 335 minecraft:dark_prismarine
setblock 142 220 340 minecraft:dark_prismarine
fill 142 220 341 142 223 341 minecraft:blue_terracotta
setblock 142 220 345 minecraft:dark_prismarine
fill 142 220 346 142 223 346 minecraft:blue_terracotta
setblock 142 220 349 minecraft:purple_concrete
setblock 142 220 360 minecraft:dark_prismarine
fill 142 220 361 142 221 361 minecraft:blue_terracotta
setblock 143 220 335 minecraft:blue_terracotta
setblock 143 220 339 minecraft:dark_prismarine
fill 143 220 340 143 223 340 minecraft:blue_terracotta
setblock 143 220 344 minecraft:dark_prismarine
setblock 143 220 345 minecraft:blue_terracotta
setblock 144 220 323 minecraft:dark_prismarine
setblock 144 220 363 minecraft:dark_prismarine
fill 145 220 323 145 223 323 minecraft:blue_terracotta
setblock 147 220 322 minecraft:blue_terracotta
setblock 147 220 363 minecraft:purple_concrete
fill 147 220 364 148 220 364 minecraft:blue_terracotta
setblock 148 220 323 minecraft:blue_terracotta
setblock 149 220 323 minecraft:dark_prismarine
fill 149 220 346 149 230 346 minecraft:magenta_terracotta
fill 150 220 323 150 223 323 minecraft:blue_terracotta
fill 152 220 322 152 221 322 minecraft:blue_terracotta
setblock 153 220 324 minecraft:dark_prismarine
setblock 154 220 323 minecraft:dark_prismarine
fill 154 220 324 154 223 324 minecraft:blue_terracotta
setblock 154 220 362 minecraft:blue_terracotta
setblock 154 220 363 minecraft:dark_prismarine
fill 155 220 323 155 223 323 minecraft:blue_terracotta
setblock 155 220 362 minecraft:dark_prismarine
fill 155 220 363 155 223 363 minecraft:blue_terracotta
setblock 156 220 361 minecraft:dark_prismarine
fill 156 220 362 156 223 362 minecraft:blue_terracotta
setblock 156 220 364 minecraft:blue_terracotta
fill 157 220 361 157 223 361 minecraft:blue_terracotta
setblock 158 220 324 minecraft:dark_prismarine
setblock 159 220 323 minecraft:dark_prismarine
fill 159 220 324 159 223 324 minecraft:blue_terracotta
setblock 159 220 363 minecraft:dark_prismarine
fill 160 220 323 160 223 323 minecraft:blue_terracotta
setblock 160 220 362 minecraft:dark_prismarine
fill 160 220 363 160 223 363 minecraft:blue_terracotta
setblock 161 220 361 minecraft:dark_prismarine
fill 161 220 362 161 223 362 minecraft:blue_terracotta
fill 162 220 361 162 222 361 minecraft:blue_terracotta
setblock 163 220 324 minecraft:dark_prismarine
setblock 164 220 323 minecraft:dark_prismarine
setblock 164 220 363 minecraft:dark_prismarine
fill 165 220 323 165 223 323 minecraft:blue_terracotta
setblock 165 220 362 minecraft:dark_prismarine
fill 165 220 363 168 220 363 minecraft:blue_terracotta
fill 166 220 362 168 220 362 minecraft:blue_terracotta
setblock 169 220 363 minecraft:dark_prismarine
setblock 170 220 322 minecraft:blue_terracotta
fill 170 220 328 170 221 328 minecraft:magenta_terracotta
fill 170 220 363 170 223 363 minecraft:blue_terracotta
fill 171 220 362 171 223 362 minecraft:blue_terracotta
setblock 174 220 363 minecraft:dark_prismarine
fill 175 220 322 175 220 323 minecraft:blue_terracotta
setblock 175 220 362 minecraft:dark_prismarine
fill 175 220 363 175 223 363 minecraft:blue_terracotta
fill 176 220 362 176 223 362 minecraft:blue_terracotta
setblock 177 220 322 minecraft:blue_terracotta
setblock 177 220 361 minecraft:blue_terracotta
setblock 179 220 323 minecraft:dark_prismarine
setblock 179 220 342 minecraft:blue_terracotta
setblock 179 220 363 minecraft:dark_prismarine
fill 180 220 323 180 223 323 minecraft:blue_terracotta
fill 180 220 338 180 221 338 minecraft:blue_terracotta
setblock 180 220 342 minecraft:dark_prismarine
fill 180 220 343 180 223 343 minecraft:blue_terracotta
setblock 180 220 347 minecraft:dark_prismarine
setblock 180 220 362 minecraft:dark_prismarine
fill 180 220 363 180 223 363 minecraft:blue_terracotta
setblock 181 220 336 minecraft:dark_prismarine
fill 181 220 337 181 223 337 minecraft:blue_terracotta
setblock 181 220 341 minecraft:dark_prismarine
fill 181 220 342 181 223 342 minecraft:blue_terracotta
setblock 181 220 346 minecraft:dark_prismarine
fill 181 220 347 181 223 347 minecraft:blue_terracotta
setblock 181 220 357 minecraft:blue_terracotta
setblock 181 220 361 minecraft:dark_prismarine
fill 181 220 362 181 221 362 minecraft:blue_terracotta
setblock 182 220 335 minecraft:dark_prismarine
fill 182 220 336 182 223 336 minecraft:blue_terracotta
setblock 182 220 340 minecraft:dark_prismarine
fill 182 220 341 182 223 341 minecraft:blue_terracotta
setblock 182 220 345 minecraft:dark_prismarine
fill 182 220 346 182 223 346 minecraft:blue_terracotta
setblock 182 220 350 minecraft:dark_prismarine
fill 182 220 351 182 223 351 minecraft:blue_terracotta
setblock 182 220 355 minecraft:dark_prismarine
setblock 182 220 356 minecraft:blue_terracotta
setblock 182 220 360 minecraft:dark_prismarine
fill 182 220 361 183 220 361 minecraft:blue_terracotta
fill 183 220 344 183 221 344 minecraft:blue_terracotta
setblock 183 220 352 minecraft:blue_terracotta
fill 141 221 322 141 298 323 minecraft:blue_concrete
fill 141 221 325 141 221 340 minecraft:blue_concrete
fill 141 221 342 141 221 350 minecraft:blue_concrete
setblock 141 221 351 minecraft:blue_terracotta
fill 141 221 352 141 221 359 minecraft:blue_concrete
fill 141 221 361 141 222 363 minecraft:blue_concrete
setblock 141 221 364 minecraft:blue_terracotta
fill 142 221 322 147 222 322 minecraft:blue_concrete
setblock 142 221 324 minecraft:dark_prismarine
fill 142 221 325 142 224 325 minecraft:blue_terracotta
setblock 142 221 328 minecraft:blue_terracotta
setblock 142 221 329 minecraft:dark_prismarine
fill 142 221 330 142 223 331 minecraft:blue_terracotta
setblock 142 221 334 minecraft:dark_prismarine
fill 142 221 335 142 223 336 minecraft:blue_terracotta
setblock 142 221 339 minecraft:dark_prismarine
fill 142 221 340 142 224 340 minecraft:blue_terracotta
setblock 142 221 344 minecraft:dark_prismarine
fill 142 221 345 142 224 345 minecraft:blue_terracotta
setblock 142 221 348 minecraft:blue_terracotta
setblock 142 221 355 minecraft:purple_concrete
fill 142 221 364 144 221 364 minecraft:blue_concrete
setblock 143 221 323 minecraft:dark_prismarine
setblock 143 221 338 minecraft:dark_prismarine
fill 143 221 339 143 223 339 minecraft:blue_terracotta
setblock 143 221 343 minecraft:dark_prismarine
fill 143 221 344 143 224 344 minecraft:blue_terracotta
setblock 143 221 363 minecraft:dark_prismarine
fill 144 221 323 144 224 323 minecraft:blue_terracotta
setblock 144 221 325 minecraft:light[level=13]
setblock 144 221 332 minecraft:light[level=12]
setblock 144 221 333 minecraft:light[level=13]
setblock 144 221 339 minecraft:light[level=12]
setblock 144 221 341 minecraft:light[level=13]
setblock 144 221 346 minecraft:light[level=12]
setblock 144 221 349 minecraft:light[level=13]
setblock 144 221 353 minecraft:light[level=12]
setblock 144 221 357 minecraft:light[level=13]
setblock 144 221 360 minecraft:light[level=12]
fill 146 221 323 146 222 323 minecraft:blue_terracotta
fill 146 221 364 147 222 364 minecraft:blue_concrete
setblock 148 221 323 minecraft:dark_prismarine
setblock 148 221 364 minecraft:blue_terracotta
fill 149 221 322 151 227 322 minecraft:blue_concrete
fill 149 221 323 149 224 323 minecraft:blue_terracotta
fill 149 221 364 150 242 364 minecraft:blue_concrete
fill 150 221 363 150 223 363 minecraft:blue_terracotta
setblock 151 221 325 minecraft:light[level=12]
setblock 151 221 332 minecraft:light[level=12]
setblock 151 221 339 minecraft:light[level=12]
setblock 151 221 346 minecraft:light[level=12]
setblock 151 221 353 minecraft:light[level=12]
setblock 151 221 360 minecraft:light[level=12]
setblock 151 221 364 minecraft:blue_terracotta
setblock 152 221 324 minecraft:dark_prismarine
setblock 152 221 325 minecraft:light[level=13]
setblock 152 221 333 minecraft:light[level=13]
setblock 152 221 341 minecraft:light[level=13]
setblock 152 221 349 minecraft:light[level=13]
setblock 152 221 357 minecraft:light[level=13]
fill 152 221 364 156 222 364 minecraft:blue_concrete
fill 153 221 322 162 221 322 minecraft:blue_concrete
setblock 153 221 323 minecraft:dark_prismarine
fill 153 221 324 153 224 324 minecraft:blue_terracotta
setblock 153 221 362 minecraft:blue_terracotta
setblock 153 221 363 minecraft:dark_prismarine
fill 154 221 323 154 224 323 minecraft:blue_terracotta
setblock 154 221 362 minecraft:dark_prismarine
fill 154 221 363 154 224 363 minecraft:blue_terracotta
fill 155 221 362 155 224 362 minecraft:blue_terracotta
setblock 156 221 325 minecraft:dark_prismarine
fill 156 221 361 156 224 361 minecraft:blue_terracotta
setblock 157 221 323 minecraft:blue_terracotta
setblock 157 221 324 minecraft:dark_prismarine
fill 157 221 325 159 222 325 minecraft:blue_terracotta
setblock 158 221 323 minecraft:dark_prismarine
fill 158 221 324 158 224 324 minecraft:blue_terracotta
setblock 158 221 332 minecraft:light[level=12]
setblock 158 221 339 minecraft:light[level=12]
setblock 158 221 346 minecraft:light[level=12]
setblock 158 221 353 minecraft:light[level=12]
setblock 158 221 360 minecraft:light[level=12]
setblock 158 221 363 minecraft:dark_prismarine
fill 158 221 364 164 221 364 minecraft:blue_concrete
fill 159 221 323 159 224 323 minecraft:blue_terracotta
setblock 159 221 362 minecraft:dark_prismarine
fill 159 221 363 159 224 363 minecraft:blue_terracotta
setblock 160 221 325 minecraft:light[level=13]
setblock 160 221 333 minecraft:light[level=13]
setblock 160 221 341 minecraft:light[level=13]
setblock 160 221 349 minecraft:light[level=13]
setblock 160 221 357 minecraft:light[level=13]
setblock 160 221 361 minecraft:dark_prismarine
fill 160 221 362 160 224 362 minecraft:blue_terracotta
fill 161 221 361 161 224 361 minecraft:blue_terracotta
setblock 162 221 324 minecraft:dark_prismarine
setblock 163 221 322 minecraft:blue_terracotta
setblock 163 221 323 minecraft:dark_prismarine
setblock 163 221 363 minecraft:dark_prismarine
fill 164 221 322 183 222 322 minecraft:blue_concrete
fill 164 221 323 164 224 323 minecraft:blue_terracotta
setblock 164 221 362 minecraft:dark_prismarine
fill 164 221 363 167 221 363 minecraft:blue_terracotta
setblock 165 221 325 minecraft:light[level=12]
setblock 165 221 332 minecraft:light[level=12]
setblock 165 221 339 minecraft:light[level=12]
setblock 165 221 346 minecraft:light[level=12]
setblock 165 221 353 minecraft:light[level=12]
setblock 165 221 360 minecraft:light[level=12]
fill 165 221 362 167 221 362 minecraft:blue_terracotta
setblock 165 221 364 minecraft:blue_terracotta
fill 166 221 323 166 222 323 minecraft:blue_terracotta
fill 166 221 364 172 221 364 minecraft:blue_concrete
setblock 168 221 325 minecraft:light[level=13]
setblock 168 221 333 minecraft:light[level=13]
setblock 168 221 341 minecraft:light[level=13]
setblock 168 221 349 minecraft:light[level=13]
setblock 168 221 357 minecraft:light[level=13]
setblock 168 221 363 minecraft:dark_prismarine
fill 169 221 363 169 224 363 minecraft:blue_terracotta
setblock 171 221 323 minecraft:purple_concrete
fill 171 221 363 171 222 363 minecraft:blue_terracotta
setblock 172 221 325 minecraft:light[level=12]
setblock 172 221 332 minecraft:light[level=12]
setblock 172 221 339 minecraft:light[level=12]
setblock 172 221 346 minecraft:light[level=12]
setblock 172 221 353 minecraft:light[level=12]
setblock 172 221 360 minecraft:light[level=12]
setblock 173 221 363 minecraft:dark_prismarine
fill 173 221 364 173 222 364 minecraft:blue_terracotta
fill 174 221 323 176 222 323 minecraft:blue_terracotta
setblock 174 221 362 minecraft:dark_prismarine
fill 174 221 363 174 224 363 minecraft:blue_terracotta
fill 174 221 364 176 222 364 minecraft:blue_concrete
fill 175 221 362 175 224 362 minecraft:blue_terracotta
setblock 176 221 325 minecraft:light[level=13]
setblock 176 221 333 minecraft:light[level=13]
setblock 176 221 341 minecraft:light[level=13]
setblock 176 221 349 minecraft:light[level=13]
setblock 176 221 357 minecraft:light[level=13]
setblock 178 221 323 minecraft:dark_prismarine
setblock 178 221 363 minecraft:dark_prismarine
fill 178 221 364 181 256 364 minecraft:blue_concrete
fill 179 221 323 179 224 323 minecraft:blue_terracotta
setblock 179 221 325 minecraft:light[level=12]
setblock 179 221 332 minecraft:light[level=12]
setblock 179 221 339 minecraft:light[level=12]
setblock 179 221 342 minecraft:dark_prismarine
fill 179 221 343 179 223 344 minecraft:blue_terracotta
setblock 179 221 346 minecraft:light[level=12]
setblock 179 221 353 minecraft:light[level=12]
setblock 179 221 360 minecraft:light[level=12]
setblock 179 221 362 minecraft:dark_prismarine
fill 179 221 363 179 224 363 minecraft:blue_terracotta
setblock 180 221 341 minecraft:dark_prismarine
fill 180 221 342 180 224 342 minecraft:blue_terracotta
setblock 180 221 346 minecraft:dark_prismarine
fill 180 221 347 180 224 347 minecraft:blue_terracotta
fill 180 221 362 180 223 362 minecraft:blue_terracotta
setblock 181 221 336 minecraft:blue_terracotta
setblock 181 221 340 minecraft:dark_prismarine
fill 181 221 341 181 224 341 minecraft:blue_terracotta
setblock 181 221 345 minecraft:dark_prismarine
fill 181 221 346 181 224 346 minecraft:blue_terracotta
setblock 181 221 360 minecraft:dark_prismarine
fill 181 221 361 182 221 361 minecraft:blue_terracotta
setblock 182 221 324 minecraft:dark_prismarine
setblock 182 221 331 minecraft:purple_concrete
setblock 182 221 334 minecraft:dark_prismarine
fill 182 221 335 182 224 335 minecraft:blue_terracotta
setblock 182 221 339 minecraft:dark_prismarine
fill 182 221 340 182 224 340 minecraft:blue_terracotta
setblock 182 221 344 minecraft:dark_prismarine
fill 182 221 345 182 224 345 minecraft:blue_terracotta
fill 182 221 347 182 222 347 minecraft:blue_terracotta
setblock 182 221 349 minecraft:dark_prismarine
fill 182 221 350 182 224 350 minecraft:blue_terracotta
setblock 182 221 356 minecraft:purple_concrete
setblock 182 221 359 minecraft:dark_prismarine
fill 182 221 360 182 222 360 minecraft:blue_terracotta
fill 182 221 362 182 222 362 minecraft:blue_terracotta
fill 183 221 323 183 221 343 minecraft:blue_concrete
fill 183 221 345 183 262 352 minecraft:blue_concrete
fill 183 221 354 183 308 355 minecraft:blue_concrete
fill 183 221 357 183 222 364 minecraft:blue_concrete
fill 141 222 324 141 248 325 minecraft:blue_concrete
setblock 141 222 326 minecraft:blue_terracotta
fill 141 222 327 141 222 336 minecraft:blue_concrete
setblock 141 222 337 minecraft:blue_terracotta
fill 141 222 338 141 222 349 minecraft:blue_concrete
setblock 141 222 350 minecraft:blue_terracotta
fill 141 222 351 141 297 352 minecraft:blue_concrete
setblock 141 222 353 minecraft:blue_terracotta
fill 141 222 354 141 222 360 minecraft:blue_concrete
fill 141 222 364 143 308 364 minecraft:blue_concrete
setblock 142 222 323 minecraft:dark_prismarine
fill 142 222 324 142 225 324 minecraft:blue_terracotta
setblock 142 222 328 minecraft:dark_prismarine
fill 142 222 329 142 225 329 minecraft:blue_terracotta
setblock 142 222 333 minecraft:dark_prismarine
fill 142 222 334 142 225 334 minecraft:blue_terracotta
setblock 142 222 338 minecraft:dark_prismarine
fill 142 222 339 142 225 339 minecraft:blue_terracotta
setblock 142 222 343 minecraft:dark_prismarine
fill 142 222 344 142 225 344 minecraft:blue_terracotta
setblock 142 222 348 minecraft:dark_prismarine
setblock 142 222 361 minecraft:purple_concrete
setblock 142 222 363 minecraft:dark_prismarine
fill 143 222 323 143 225 323 minecraft:blue_terracotta
setblock 143 222 338 minecraft:blue_terracotta
setblock 143 222 342 minecraft:dark_prismarine
fill 143 222 343 143 225 343 minecraft:blue_terracotta
fill 143 222 363 143 223 363 minecraft:blue_terracotta
setblock 144 222 364 minecraft:cyan_concrete
fill 145 222 364 145 308 364 minecraft:blue_concrete
setblock 147 222 323 minecraft:dark_prismarine
fill 148 222 322 148 307 322 minecraft:blue_concrete
fill 148 222 323 148 225 323 minecraft:blue_terracotta
fill 148 222 364 148 243 364 minecraft:blue_concrete
fill 149 222 363 149 224 363 minecraft:blue_terracotta
setblock 150 222 324 minecraft:blue_terracotta
setblock 151 222 323 minecraft:blue_terracotta
setblock 151 222 324 minecraft:dark_prismarine
fill 151 222 364 151 224 364 minecraft:blue_concrete
fill 152 222 322 152 308 322 minecraft:blue_concrete
setblock 152 222 323 minecraft:dark_prismarine
fill 152 222 324 152 225 324 minecraft:blue_terracotta
setblock 152 222 363 minecraft:dark_prismarine
fill 153 222 322 153 222 323 minecraft:blue_terracotta
schedule function dropper:buildpart/75_11 1t
