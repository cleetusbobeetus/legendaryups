fill 22 230 465 22 230 467 minecraft:dark_oak_planks
fill 22 230 469 22 230 471 minecraft:dark_oak_planks
fill 22 230 473 22 230 475 minecraft:dark_oak_planks
fill 22 230 477 22 230 479 minecraft:dark_oak_planks
fill 22 230 481 23 230 481 minecraft:ochre_froglight
fill 22 230 487 23 230 487 minecraft:ochre_froglight
fill 22 230 489 22 230 491 minecraft:dark_oak_planks
fill 22 230 493 22 230 495 minecraft:dark_oak_planks
fill 22 230 497 22 230 499 minecraft:dark_oak_planks
fill 22 230 501 22 230 503 minecraft:dark_oak_planks
fill 23 230 465 25 230 467 minecraft:red_wool
fill 23 230 469 25 230 471 minecraft:blue_wool
fill 23 230 473 25 230 475 minecraft:red_wool
fill 23 230 477 25 230 479 minecraft:blue_wool
fill 23 230 482 24 230 482 minecraft:ochre_froglight
fill 23 230 486 24 230 486 minecraft:ochre_froglight
fill 23 230 489 25 230 491 minecraft:red_wool
fill 23 230 493 25 230 495 minecraft:blue_wool
fill 23 230 497 25 230 499 minecraft:red_wool
fill 23 230 501 25 230 503 minecraft:blue_wool
fill 24 230 481 25 230 481 minecraft:red_wool
fill 24 230 483 25 230 483 minecraft:ochre_froglight
fill 24 230 485 25 230 485 minecraft:ochre_froglight
fill 24 230 487 25 230 487 minecraft:blue_wool
setblock 25 230 482 minecraft:red_wool
setblock 25 230 484 minecraft:ochre_froglight
setblock 25 230 486 minecraft:blue_wool
fill 26 230 465 26 230 467 minecraft:dark_oak_planks
fill 26 230 469 26 230 471 minecraft:dark_oak_planks
fill 26 230 473 26 230 475 minecraft:dark_oak_planks
fill 26 230 477 26 230 479 minecraft:dark_oak_planks
fill 26 230 481 26 230 487 minecraft:dark_oak_planks
fill 26 230 489 26 230 491 minecraft:dark_oak_planks
fill 26 230 493 26 230 495 minecraft:dark_oak_planks
fill 26 230 497 26 230 499 minecraft:dark_oak_planks
fill 26 230 501 26 230 503 minecraft:dark_oak_planks
fill 27 230 465 29 230 467 minecraft:blue_wool
fill 27 230 469 29 230 471 minecraft:red_wool
fill 27 230 473 29 230 475 minecraft:blue_wool
fill 27 230 477 29 230 479 minecraft:red_wool
fill 27 230 481 29 230 483 minecraft:blue_wool
fill 27 230 484 41 230 484 minecraft:dark_oak_planks
fill 27 230 485 29 230 487 minecraft:red_wool
fill 27 230 489 29 230 491 minecraft:blue_wool
fill 27 230 493 29 230 495 minecraft:red_wool
fill 27 230 497 29 230 499 minecraft:blue_wool
fill 27 230 501 29 230 503 minecraft:red_wool
fill 30 230 465 30 230 467 minecraft:dark_oak_planks
fill 30 230 469 30 230 471 minecraft:dark_oak_planks
fill 30 230 473 30 230 475 minecraft:dark_oak_planks
fill 30 230 477 30 230 479 minecraft:dark_oak_planks
fill 30 230 481 30 230 483 minecraft:dark_oak_planks
fill 30 230 485 30 230 487 minecraft:dark_oak_planks
fill 30 230 489 30 230 491 minecraft:dark_oak_planks
fill 30 230 493 30 230 495 minecraft:dark_oak_planks
fill 30 230 497 30 230 499 minecraft:dark_oak_planks
fill 30 230 501 30 230 503 minecraft:dark_oak_planks
fill 31 230 465 33 230 467 minecraft:red_wool
fill 31 230 469 33 230 471 minecraft:blue_wool
fill 31 230 473 33 230 475 minecraft:red_wool
fill 31 230 477 33 230 479 minecraft:blue_wool
fill 31 230 481 33 230 483 minecraft:red_wool
fill 31 230 485 33 230 487 minecraft:blue_wool
fill 31 230 489 33 230 491 minecraft:red_wool
fill 31 230 493 33 230 495 minecraft:blue_wool
fill 31 230 497 33 230 499 minecraft:red_wool
fill 31 230 501 33 230 503 minecraft:blue_wool
fill 34 230 465 34 230 467 minecraft:dark_oak_planks
fill 34 230 469 34 230 471 minecraft:dark_oak_planks
fill 34 230 473 34 230 475 minecraft:dark_oak_planks
fill 34 230 477 34 230 479 minecraft:dark_oak_planks
fill 34 230 481 34 230 483 minecraft:dark_oak_planks
fill 34 230 485 34 230 487 minecraft:dark_oak_planks
fill 34 230 489 34 230 491 minecraft:dark_oak_planks
fill 34 230 493 34 230 495 minecraft:dark_oak_planks
fill 34 230 497 34 230 499 minecraft:dark_oak_planks
fill 34 230 501 34 230 503 minecraft:dark_oak_planks
fill 35 230 465 37 230 467 minecraft:blue_wool
fill 35 230 469 37 230 471 minecraft:red_wool
fill 35 230 473 37 230 475 minecraft:blue_wool
fill 35 230 477 37 230 479 minecraft:red_wool
fill 35 230 481 37 230 483 minecraft:blue_wool
fill 35 230 485 37 230 487 minecraft:red_wool
fill 35 230 489 37 230 491 minecraft:blue_wool
fill 35 230 493 37 230 495 minecraft:red_wool
fill 35 230 497 37 230 499 minecraft:blue_wool
fill 35 230 501 37 230 503 minecraft:red_wool
fill 38 230 465 38 230 467 minecraft:dark_oak_planks
fill 38 230 469 38 230 471 minecraft:dark_oak_planks
fill 38 230 473 38 230 475 minecraft:dark_oak_planks
fill 38 230 477 38 230 479 minecraft:dark_oak_planks
fill 38 230 481 38 230 483 minecraft:dark_oak_planks
fill 38 230 485 38 230 487 minecraft:dark_oak_planks
fill 38 230 489 38 230 491 minecraft:dark_oak_planks
fill 38 230 493 38 230 495 minecraft:dark_oak_planks
fill 38 230 497 38 230 499 minecraft:dark_oak_planks
fill 38 230 501 38 230 503 minecraft:dark_oak_planks
fill 39 230 465 41 230 467 minecraft:red_wool
fill 39 230 469 41 230 471 minecraft:blue_wool
fill 39 230 473 41 230 475 minecraft:red_wool
fill 39 230 477 41 230 479 minecraft:blue_wool
fill 39 230 481 41 230 483 minecraft:red_wool
fill 39 230 485 41 230 487 minecraft:blue_wool
fill 39 230 489 41 230 491 minecraft:red_wool
fill 39 230 493 41 230 495 minecraft:blue_wool
fill 39 230 497 41 230 499 minecraft:red_wool
fill 39 230 501 41 230 503 minecraft:blue_wool
setblock 3 233 466 minecraft:light[level=12]
setblock 3 233 474 minecraft:light[level=12]
setblock 3 233 482 minecraft:light[level=12]
setblock 3 233 490 minecraft:light[level=12]
setblock 3 233 498 minecraft:light[level=12]
setblock 11 233 466 minecraft:light[level=12]
setblock 11 233 474 minecraft:light[level=12]
setblock 11 233 482 minecraft:light[level=12]
setblock 11 233 490 minecraft:light[level=12]
setblock 11 233 498 minecraft:light[level=12]
setblock 19 233 466 minecraft:light[level=12]
setblock 19 233 474 minecraft:light[level=12]
setblock 19 233 482 minecraft:light[level=12]
setblock 19 233 490 minecraft:light[level=12]
setblock 19 233 498 minecraft:light[level=12]
setblock 27 233 466 minecraft:light[level=12]
setblock 27 233 474 minecraft:light[level=12]
setblock 27 233 482 minecraft:light[level=12]
setblock 27 233 490 minecraft:light[level=12]
setblock 27 233 498 minecraft:light[level=12]
setblock 35 233 466 minecraft:light[level=12]
setblock 35 233 474 minecraft:light[level=12]
setblock 35 233 482 minecraft:light[level=12]
setblock 35 233 490 minecraft:light[level=12]
setblock 35 233 498 minecraft:light[level=12]
setblock 1 234 465 minecraft:bookshelf
fill 1 234 469 1 273 469 minecraft:bookshelf
setblock 1 234 472 minecraft:bookshelf
fill 1 234 476 1 273 476 minecraft:bookshelf
setblock 1 234 479 minecraft:bookshelf
fill 1 234 483 1 273 483 minecraft:bookshelf
setblock 1 234 486 minecraft:bookshelf
fill 1 234 490 1 273 490 minecraft:bookshelf
setblock 1 234 493 minecraft:bookshelf
fill 1 234 497 1 273 497 minecraft:bookshelf
setblock 1 234 500 minecraft:bookshelf
fill 1 234 504 1 273 504 minecraft:bookshelf
fill 3 234 464 3 273 464 minecraft:bookshelf
fill 4 234 500 12 246 504 minecraft:bookshelf
setblock 7 234 464 minecraft:bookshelf
fill 10 234 464 10 273 464 minecraft:bookshelf
setblock 14 234 464 minecraft:bookshelf
fill 15 234 504 15 273 504 minecraft:bookshelf
fill 17 234 464 17 273 464 minecraft:bookshelf
setblock 18 234 504 minecraft:bookshelf
setblock 21 234 464 minecraft:bookshelf
fill 22 234 504 22 273 504 minecraft:bookshelf
fill 24 234 464 24 273 464 minecraft:bookshelf
setblock 25 234 504 minecraft:bookshelf
setblock 28 234 464 minecraft:bookshelf
fill 28 234 499 38 234 504 minecraft:bookshelf
fill 31 234 464 31 273 464 minecraft:bookshelf
setblock 35 234 464 minecraft:bookshelf
fill 38 234 464 38 273 464 minecraft:bookshelf
fill 39 234 481 41 234 485 minecraft:bookshelf
setblock 39 234 504 minecraft:bookshelf
setblock 41 234 465 minecraft:bookshelf
fill 41 234 468 41 273 468 minecraft:bookshelf
setblock 41 234 472 minecraft:bookshelf
fill 41 234 475 41 273 475 minecraft:bookshelf
setblock 41 234 479 minecraft:bookshelf
fill 41 234 486 41 235 486 minecraft:bookshelf
fill 41 234 489 41 273 489 minecraft:bookshelf
setblock 41 234 493 minecraft:bookshelf
fill 41 234 496 41 273 496 minecraft:bookshelf
setblock 41 234 500 minecraft:bookshelf
fill 41 234 503 41 273 503 minecraft:bookshelf
setblock 1 235 466 minecraft:bookshelf
setblock 1 235 473 minecraft:bookshelf
setblock 1 235 480 minecraft:bookshelf
setblock 1 235 487 minecraft:bookshelf
setblock 1 235 494 minecraft:bookshelf
setblock 1 235 501 minecraft:bookshelf
setblock 6 235 464 minecraft:bookshelf
setblock 13 235 464 minecraft:bookshelf
setblock 19 235 504 minecraft:bookshelf
setblock 20 235 464 minecraft:bookshelf
setblock 26 235 504 minecraft:bookshelf
setblock 27 235 464 minecraft:bookshelf
setblock 28 235 499 minecraft:ochre_froglight
fill 28 235 500 28 256 500 minecraft:bookshelf
setblock 28 235 501 minecraft:ochre_froglight
fill 28 235 502 28 256 502 minecraft:bookshelf
setblock 28 235 503 minecraft:ochre_froglight
fill 28 235 504 28 256 504 minecraft:bookshelf
fill 29 235 499 29 256 499 minecraft:bookshelf
setblock 29 235 500 minecraft:ochre_froglight
fill 29 235 501 29 256 501 minecraft:bookshelf
setblock 29 235 502 minecraft:ochre_froglight
fill 29 235 503 29 256 503 minecraft:bookshelf
setblock 29 235 504 minecraft:ochre_froglight
setblock 30 235 499 minecraft:ochre_froglight
fill 30 235 500 30 256 500 minecraft:bookshelf
setblock 30 235 501 minecraft:ochre_froglight
fill 30 235 502 30 256 502 minecraft:bookshelf
setblock 30 235 503 minecraft:ochre_froglight
fill 30 235 504 30 256 504 minecraft:bookshelf
fill 31 235 499 31 256 499 minecraft:bookshelf
setblock 31 235 500 minecraft:ochre_froglight
fill 31 235 501 31 256 501 minecraft:bookshelf
setblock 31 235 502 minecraft:ochre_froglight
fill 31 235 503 31 256 503 minecraft:bookshelf
setblock 31 235 504 minecraft:ochre_froglight
setblock 32 235 499 minecraft:ochre_froglight
fill 32 235 500 32 256 500 minecraft:bookshelf
setblock 32 235 501 minecraft:ochre_froglight
fill 32 235 502 32 256 502 minecraft:bookshelf
setblock 32 235 503 minecraft:ochre_froglight
fill 32 235 504 32 256 504 minecraft:bookshelf
fill 33 235 499 33 256 499 minecraft:bookshelf
setblock 33 235 500 minecraft:ochre_froglight
fill 33 235 501 33 256 501 minecraft:bookshelf
setblock 33 235 502 minecraft:ochre_froglight
fill 33 235 503 33 256 503 minecraft:bookshelf
setblock 33 235 504 minecraft:ochre_froglight
setblock 34 235 464 minecraft:bookshelf
setblock 34 235 499 minecraft:ochre_froglight
fill 34 235 500 34 256 500 minecraft:bookshelf
setblock 34 235 501 minecraft:ochre_froglight
fill 34 235 502 34 256 502 minecraft:bookshelf
setblock 34 235 503 minecraft:ochre_froglight
fill 34 235 504 34 257 504 minecraft:bookshelf
fill 35 235 499 35 256 499 minecraft:bookshelf
setblock 35 235 500 minecraft:ochre_froglight
fill 35 235 501 35 256 501 minecraft:bookshelf
setblock 35 235 502 minecraft:ochre_froglight
fill 35 235 503 35 256 503 minecraft:bookshelf
setblock 35 235 504 minecraft:ochre_froglight
setblock 36 235 499 minecraft:ochre_froglight
fill 36 235 500 36 256 500 minecraft:bookshelf
setblock 36 235 501 minecraft:ochre_froglight
fill 36 235 502 36 256 502 minecraft:bookshelf
setblock 36 235 503 minecraft:ochre_froglight
fill 36 235 504 36 273 504 minecraft:bookshelf
fill 37 235 499 37 256 499 minecraft:bookshelf
setblock 37 235 500 minecraft:ochre_froglight
fill 37 235 501 37 256 501 minecraft:bookshelf
setblock 37 235 502 minecraft:ochre_froglight
fill 37 235 503 37 256 503 minecraft:bookshelf
setblock 37 235 504 minecraft:ochre_froglight
setblock 38 235 499 minecraft:ochre_froglight
fill 38 235 500 38 256 500 minecraft:bookshelf
setblock 38 235 501 minecraft:ochre_froglight
fill 38 235 502 38 256 502 minecraft:bookshelf
setblock 38 235 503 minecraft:ochre_froglight
fill 38 235 504 38 256 504 minecraft:bookshelf
fill 39 235 484 40 235 488 minecraft:bookshelf
setblock 40 235 504 minecraft:bookshelf
setblock 41 235 464 minecraft:bookshelf
setblock 41 235 471 minecraft:bookshelf
setblock 41 235 478 minecraft:bookshelf
fill 41 235 482 41 273 482 minecraft:bookshelf
fill 41 235 484 41 235 485 minecraft:bookshelf
fill 41 235 487 41 236 488 minecraft:bookshelf
fill 41 235 492 41 237 492 minecraft:bookshelf
setblock 41 235 499 minecraft:bookshelf
setblock 1 236 467 minecraft:bookshelf
setblock 1 236 474 minecraft:bookshelf
setblock 1 236 481 minecraft:bookshelf
setblock 1 236 488 minecraft:bookshelf
setblock 1 236 495 minecraft:bookshelf
setblock 1 236 502 minecraft:bookshelf
setblock 5 236 464 minecraft:bookshelf
setblock 12 236 464 minecraft:bookshelf
setblock 13 236 504 minecraft:bookshelf
setblock 19 236 464 minecraft:bookshelf
setblock 20 236 504 minecraft:bookshelf
setblock 26 236 464 minecraft:bookshelf
setblock 27 236 504 minecraft:bookshelf
fill 28 236 499 28 237 499 minecraft:bookshelf
fill 28 236 501 28 237 501 minecraft:bookshelf
fill 28 236 503 28 237 503 minecraft:bookshelf
fill 29 236 500 29 237 500 minecraft:bookshelf
fill 29 236 502 29 237 502 minecraft:bookshelf
fill 29 236 504 29 237 504 minecraft:bookshelf
fill 30 236 499 30 237 499 minecraft:bookshelf
fill 30 236 501 30 237 501 minecraft:bookshelf
fill 30 236 503 30 237 503 minecraft:bookshelf
fill 31 236 500 31 237 500 minecraft:bookshelf
fill 31 236 502 31 237 502 minecraft:bookshelf
fill 31 236 504 31 237 504 minecraft:bookshelf
fill 32 236 499 32 237 499 minecraft:bookshelf
fill 32 236 501 32 237 501 minecraft:bookshelf
fill 32 236 503 32 237 503 minecraft:bookshelf
setblock 33 236 464 minecraft:bookshelf
fill 33 236 500 33 237 500 minecraft:bookshelf
fill 33 236 502 33 237 502 minecraft:bookshelf
fill 33 236 504 33 237 504 minecraft:bookshelf
fill 34 236 499 34 237 499 minecraft:bookshelf
fill 34 236 501 34 237 501 minecraft:bookshelf
fill 34 236 503 34 237 503 minecraft:bookshelf
fill 35 236 500 35 237 500 minecraft:bookshelf
fill 35 236 502 35 237 502 minecraft:bookshelf
fill 35 236 504 35 237 504 minecraft:bookshelf
fill 36 236 499 36 237 499 minecraft:bookshelf
fill 36 236 501 36 237 501 minecraft:bookshelf
fill 36 236 503 36 237 503 minecraft:bookshelf
fill 37 236 500 37 237 500 minecraft:bookshelf
fill 37 236 502 37 237 502 minecraft:bookshelf
fill 37 236 504 37 237 504 minecraft:bookshelf
fill 38 236 499 38 237 499 minecraft:bookshelf
fill 38 236 501 38 237 501 minecraft:bookshelf
fill 38 236 503 38 237 503 minecraft:bookshelf
fill 39 236 487 40 236 491 minecraft:bookshelf
setblock 40 236 464 minecraft:bookshelf
setblock 41 236 470 minecraft:bookshelf
setblock 41 236 477 minecraft:bookshelf
setblock 41 236 484 minecraft:bookshelf
fill 41 236 490 41 237 491 minecraft:bookshelf
setblock 41 236 498 minecraft:bookshelf
setblock 41 236 504 minecraft:bookshelf
setblock 1 237 468 minecraft:bookshelf
setblock 1 237 475 minecraft:bookshelf
setblock 1 237 482 minecraft:bookshelf
setblock 1 237 489 minecraft:bookshelf
setblock 1 237 496 minecraft:bookshelf
setblock 1 237 503 minecraft:bookshelf
setblock 4 237 464 minecraft:bookshelf
setblock 11 237 464 minecraft:bookshelf
setblock 14 237 504 minecraft:bookshelf
setblock 18 237 464 minecraft:bookshelf
setblock 21 237 504 minecraft:bookshelf
setblock 25 237 464 minecraft:bookshelf
setblock 32 237 464 minecraft:bookshelf
setblock 39 237 464 minecraft:bookshelf
fill 39 237 490 40 237 495 minecraft:bookshelf
setblock 41 237 469 minecraft:bookshelf
setblock 41 237 476 minecraft:bookshelf
setblock 41 237 483 minecraft:bookshelf
fill 41 237 493 41 237 495 minecraft:bookshelf
fill 41 237 497 41 238 497 minecraft:bookshelf
setblock 28 238 499 minecraft:ochre_froglight
setblock 28 238 501 minecraft:ochre_froglight
setblock 28 238 503 minecraft:ochre_froglight
setblock 29 238 500 minecraft:ochre_froglight
setblock 29 238 502 minecraft:ochre_froglight
setblock 29 238 504 minecraft:ochre_froglight
setblock 30 238 499 minecraft:ochre_froglight
setblock 30 238 501 minecraft:ochre_froglight
setblock 30 238 503 minecraft:ochre_froglight
setblock 31 238 500 minecraft:ochre_froglight
setblock 31 238 502 minecraft:ochre_froglight
setblock 31 238 504 minecraft:ochre_froglight
setblock 32 238 499 minecraft:ochre_froglight
setblock 32 238 501 minecraft:ochre_froglight
setblock 32 238 503 minecraft:ochre_froglight
setblock 33 238 500 minecraft:ochre_froglight
setblock 33 238 502 minecraft:ochre_froglight
setblock 33 238 504 minecraft:ochre_froglight
setblock 34 238 499 minecraft:ochre_froglight
setblock 34 238 501 minecraft:ochre_froglight
setblock 34 238 503 minecraft:ochre_froglight
setblock 35 238 500 minecraft:ochre_froglight
setblock 35 238 502 minecraft:ochre_froglight
setblock 35 238 504 minecraft:ochre_froglight
setblock 36 238 499 minecraft:ochre_froglight
setblock 36 238 501 minecraft:ochre_froglight
setblock 36 238 503 minecraft:ochre_froglight
setblock 37 238 500 minecraft:ochre_froglight
setblock 37 238 502 minecraft:ochre_froglight
setblock 37 238 504 minecraft:ochre_froglight
setblock 38 238 499 minecraft:ochre_froglight
setblock 38 238 501 minecraft:ochre_froglight
setblock 38 238 503 minecraft:ochre_froglight
fill 39 238 493 39 238 499 minecraft:bookshelf
fill 40 238 494 40 238 500 minecraft:bookshelf
fill 41 238 494 41 238 495 minecraft:bookshelf
fill 41 238 498 41 238 501 minecraft:bookshelf
fill 1 239 470 1 240 470 minecraft:bookshelf
fill 1 239 477 1 240 477 minecraft:bookshelf
fill 1 239 484 1 240 484 minecraft:bookshelf
fill 1 239 491 1 240 491 minecraft:bookshelf
fill 1 239 498 1 240 498 minecraft:bookshelf
fill 2 239 464 2 240 464 minecraft:bookshelf
fill 2 239 504 2 240 504 minecraft:bookshelf
fill 9 239 464 9 240 464 minecraft:bookshelf
fill 16 239 464 16 240 464 minecraft:bookshelf
fill 16 239 504 16 240 504 minecraft:bookshelf
fill 23 239 464 23 240 464 minecraft:bookshelf
fill 23 239 504 23 240 504 minecraft:bookshelf
fill 28 239 499 28 240 499 minecraft:bookshelf
fill 28 239 501 28 240 501 minecraft:bookshelf
fill 28 239 503 28 240 503 minecraft:bookshelf
fill 29 239 500 29 240 500 minecraft:bookshelf
fill 29 239 502 29 240 502 minecraft:bookshelf
fill 29 239 504 29 240 504 minecraft:bookshelf
fill 30 239 464 30 240 464 minecraft:bookshelf
fill 30 239 499 30 240 499 minecraft:bookshelf
fill 30 239 501 30 240 501 minecraft:bookshelf
fill 30 239 503 30 240 503 minecraft:bookshelf
fill 31 239 500 31 240 500 minecraft:bookshelf
fill 31 239 502 31 240 502 minecraft:bookshelf
fill 31 239 504 31 240 504 minecraft:bookshelf
fill 32 239 499 32 240 499 minecraft:bookshelf
fill 32 239 501 32 240 501 minecraft:bookshelf
fill 32 239 503 32 240 503 minecraft:bookshelf
fill 33 239 500 33 240 500 minecraft:bookshelf
fill 33 239 502 33 240 502 minecraft:bookshelf
fill 33 239 504 33 240 504 minecraft:bookshelf
fill 34 239 499 34 240 499 minecraft:bookshelf
fill 34 239 501 34 240 501 minecraft:bookshelf
fill 34 239 503 34 240 503 minecraft:bookshelf
fill 35 239 500 35 240 500 minecraft:bookshelf
fill 35 239 502 35 240 502 minecraft:bookshelf
fill 35 239 504 35 240 504 minecraft:bookshelf
fill 36 239 499 36 240 499 minecraft:bookshelf
fill 36 239 501 36 240 501 minecraft:bookshelf
fill 36 239 503 36 240 503 minecraft:bookshelf
fill 37 239 464 37 240 464 minecraft:bookshelf
fill 37 239 500 37 240 500 minecraft:bookshelf
fill 37 239 502 37 240 502 minecraft:bookshelf
fill 37 239 504 37 240 504 minecraft:bookshelf
fill 38 239 499 41 239 499 minecraft:bookshelf
fill 38 239 501 41 239 501 minecraft:bookshelf
fill 38 239 503 40 240 503 minecraft:bookshelf
fill 39 239 497 39 239 498 minecraft:bookshelf
fill 39 239 500 41 239 500 minecraft:bookshelf
fill 39 239 502 41 239 502 minecraft:bookshelf
fill 39 239 504 41 240 504 minecraft:bookshelf
setblock 40 239 498 minecraft:bookshelf
fill 41 239 467 41 240 467 minecraft:bookshelf
fill 41 239 474 41 240 474 minecraft:bookshelf
fill 41 239 481 41 240 481 minecraft:bookshelf
fill 41 239 488 41 240 488 minecraft:bookshelf
fill 41 239 495 41 240 495 minecraft:bookshelf
fill 1 240 464 1 240 468 minecraft:bookshelf
fill 1 240 471 1 240 475 minecraft:bookshelf
fill 1 240 478 1 240 482 minecraft:bookshelf
fill 1 240 485 1 240 489 minecraft:bookshelf
fill 1 240 492 1 240 496 minecraft:bookshelf
fill 1 240 499 1 240 503 minecraft:bookshelf
setblock 3 240 504 minecraft:bookshelf
fill 4 240 464 8 240 464 minecraft:bookshelf
fill 11 240 464 15 240 464 minecraft:bookshelf
fill 13 240 504 14 240 504 minecraft:bookshelf
fill 17 240 504 21 240 504 minecraft:bookshelf
fill 18 240 464 22 240 464 minecraft:bookshelf
fill 24 240 504 27 240 504 minecraft:bookshelf
fill 25 240 464 29 240 464 minecraft:bookshelf
fill 32 240 464 36 240 464 minecraft:bookshelf
setblock 38 240 499 minecraft:bookshelf
setblock 38 240 501 minecraft:bookshelf
fill 39 240 464 41 240 464 minecraft:bookshelf
setblock 39 240 502 minecraft:bookshelf
fill 41 240 465 41 240 466 minecraft:bookshelf
fill 41 240 469 41 240 473 minecraft:bookshelf
fill 41 240 476 41 240 480 minecraft:bookshelf
fill 41 240 483 41 240 487 minecraft:bookshelf
fill 41 240 490 41 240 494 minecraft:bookshelf
fill 41 240 497 41 240 502 minecraft:bookshelf
setblock 1 241 465 minecraft:bookshelf
setblock 1 241 472 minecraft:bookshelf
setblock 1 241 479 minecraft:bookshelf
setblock 1 241 486 minecraft:bookshelf
setblock 1 241 493 minecraft:bookshelf
setblock 1 241 500 minecraft:bookshelf
setblock 3 241 466 minecraft:light[level=12]
setblock 3 241 474 minecraft:light[level=12]
setblock 3 241 482 minecraft:light[level=12]
setblock 3 241 490 minecraft:light[level=12]
setblock 3 241 498 minecraft:light[level=12]
setblock 7 241 464 minecraft:bookshelf
setblock 11 241 466 minecraft:light[level=12]
setblock 11 241 474 minecraft:light[level=12]
setblock 11 241 482 minecraft:light[level=12]
setblock 11 241 490 minecraft:light[level=12]
setblock 11 241 498 minecraft:light[level=12]
setblock 14 241 464 minecraft:bookshelf
setblock 18 241 504 minecraft:bookshelf
setblock 19 241 466 minecraft:light[level=12]
setblock 19 241 474 minecraft:light[level=12]
setblock 19 241 482 minecraft:light[level=12]
setblock 19 241 490 minecraft:light[level=12]
setblock 19 241 498 minecraft:light[level=12]
setblock 21 241 464 minecraft:bookshelf
setblock 25 241 504 minecraft:bookshelf
setblock 27 241 466 minecraft:light[level=12]
setblock 27 241 474 minecraft:light[level=12]
setblock 27 241 482 minecraft:light[level=12]
setblock 27 241 490 minecraft:light[level=12]
setblock 27 241 498 minecraft:light[level=12]
setblock 28 241 464 minecraft:bookshelf
setblock 28 241 499 minecraft:ochre_froglight
setblock 28 241 501 minecraft:ochre_froglight
setblock 28 241 503 minecraft:ochre_froglight
setblock 29 241 500 minecraft:ochre_froglight
setblock 29 241 502 minecraft:ochre_froglight
setblock 29 241 504 minecraft:ochre_froglight
setblock 30 241 499 minecraft:ochre_froglight
setblock 30 241 501 minecraft:ochre_froglight
setblock 30 241 503 minecraft:ochre_froglight
setblock 31 241 500 minecraft:ochre_froglight
setblock 31 241 502 minecraft:ochre_froglight
setblock 31 241 504 minecraft:ochre_froglight
setblock 32 241 499 minecraft:ochre_froglight
setblock 32 241 501 minecraft:ochre_froglight
setblock 32 241 503 minecraft:ochre_froglight
setblock 33 241 500 minecraft:ochre_froglight
setblock 33 241 502 minecraft:ochre_froglight
setblock 33 241 504 minecraft:ochre_froglight
setblock 34 241 499 minecraft:ochre_froglight
setblock 34 241 501 minecraft:ochre_froglight
setblock 34 241 503 minecraft:ochre_froglight
setblock 35 241 464 minecraft:bookshelf
setblock 35 241 466 minecraft:light[level=12]
setblock 35 241 474 minecraft:light[level=12]
setblock 35 241 482 minecraft:light[level=12]
setblock 35 241 490 minecraft:light[level=12]
setblock 35 241 498 minecraft:light[level=12]
setblock 35 241 500 minecraft:ochre_froglight
setblock 35 241 502 minecraft:ochre_froglight
setblock 35 241 504 minecraft:ochre_froglight
setblock 36 241 499 minecraft:ochre_froglight
setblock 36 241 501 minecraft:ochre_froglight
setblock 36 241 503 minecraft:ochre_froglight
setblock 37 241 500 minecraft:ochre_froglight
setblock 37 241 502 minecraft:ochre_froglight
setblock 37 241 504 minecraft:ochre_froglight
setblock 38 241 499 minecraft:ochre_froglight
setblock 38 241 501 minecraft:ochre_froglight
setblock 38 241 503 minecraft:ochre_froglight
setblock 39 241 504 minecraft:bookshelf
setblock 41 241 465 minecraft:bookshelf
setblock 41 241 472 minecraft:bookshelf
setblock 41 241 479 minecraft:bookshelf
setblock 41 241 486 minecraft:bookshelf
setblock 41 241 493 minecraft:bookshelf
setblock 41 241 500 minecraft:bookshelf
setblock 1 242 466 minecraft:bookshelf
setblock 1 242 473 minecraft:bookshelf
setblock 1 242 480 minecraft:bookshelf
setblock 1 242 487 minecraft:bookshelf
setblock 1 242 494 minecraft:bookshelf
setblock 1 242 501 minecraft:bookshelf
setblock 6 242 464 minecraft:bookshelf
setblock 13 242 464 minecraft:bookshelf
setblock 19 242 504 minecraft:bookshelf
setblock 20 242 464 minecraft:bookshelf
fill 26 242 502 27 243 504 minecraft:bookshelf
setblock 27 242 464 minecraft:bookshelf
fill 28 242 499 28 243 499 minecraft:bookshelf
fill 28 242 501 28 243 501 minecraft:bookshelf
fill 28 242 503 28 243 503 minecraft:bookshelf
fill 29 242 500 29 243 500 minecraft:bookshelf
fill 29 242 502 29 243 502 minecraft:bookshelf
fill 29 242 504 29 243 504 minecraft:bookshelf
fill 30 242 499 30 243 499 minecraft:bookshelf
fill 30 242 501 30 243 501 minecraft:bookshelf
fill 30 242 503 30 243 503 minecraft:bookshelf
fill 31 242 500 31 243 500 minecraft:bookshelf
fill 31 242 502 31 243 502 minecraft:bookshelf
fill 31 242 504 31 243 504 minecraft:bookshelf
fill 32 242 499 32 243 499 minecraft:bookshelf
fill 32 242 501 32 243 501 minecraft:bookshelf
fill 32 242 503 32 243 503 minecraft:bookshelf
fill 33 242 500 33 243 500 minecraft:bookshelf
fill 33 242 502 33 243 502 minecraft:bookshelf
fill 33 242 504 33 243 504 minecraft:bookshelf
setblock 34 242 464 minecraft:bookshelf
fill 34 242 499 34 243 499 minecraft:bookshelf
fill 34 242 501 34 243 501 minecraft:bookshelf
fill 34 242 503 34 243 503 minecraft:bookshelf
fill 35 242 500 35 243 500 minecraft:bookshelf
fill 35 242 502 35 243 502 minecraft:bookshelf
fill 35 242 504 35 243 504 minecraft:bookshelf
fill 36 242 499 36 243 499 minecraft:bookshelf
fill 36 242 501 36 243 501 minecraft:bookshelf
fill 36 242 503 36 243 503 minecraft:bookshelf
fill 37 242 500 37 243 500 minecraft:bookshelf
fill 37 242 502 37 243 502 minecraft:bookshelf
fill 37 242 504 37 243 504 minecraft:bookshelf
fill 38 242 499 38 243 499 minecraft:bookshelf
fill 38 242 501 38 243 501 minecraft:bookshelf
fill 38 242 503 38 243 503 minecraft:bookshelf
setblock 40 242 504 minecraft:bookshelf
setblock 41 242 464 minecraft:bookshelf
setblock 41 242 471 minecraft:bookshelf
setblock 41 242 478 minecraft:bookshelf
setblock 41 242 485 minecraft:bookshelf
setblock 41 242 492 minecraft:bookshelf
setblock 41 242 499 minecraft:bookshelf
setblock 1 243 467 minecraft:bookshelf
setblock 1 243 474 minecraft:bookshelf
setblock 1 243 481 minecraft:bookshelf
setblock 1 243 488 minecraft:bookshelf
setblock 1 243 495 minecraft:bookshelf
setblock 1 243 502 minecraft:bookshelf
setblock 5 243 464 minecraft:bookshelf
setblock 12 243 464 minecraft:bookshelf
setblock 13 243 504 minecraft:bookshelf
setblock 19 243 464 minecraft:bookshelf
fill 20 243 504 20 245 504 minecraft:bookshelf
fill 23 243 502 25 243 504 minecraft:bookshelf
setblock 26 243 464 minecraft:bookshelf
setblock 33 243 464 minecraft:bookshelf
setblock 40 243 464 minecraft:bookshelf
setblock 41 243 470 minecraft:bookshelf
setblock 41 243 477 minecraft:bookshelf
setblock 41 243 484 minecraft:bookshelf
setblock 41 243 491 minecraft:bookshelf
setblock 41 243 498 minecraft:bookshelf
setblock 41 243 504 minecraft:bookshelf
setblock 1 244 468 minecraft:bookshelf
setblock 1 244 475 minecraft:bookshelf
setblock 1 244 482 minecraft:bookshelf
setblock 1 244 489 minecraft:bookshelf
setblock 1 244 496 minecraft:bookshelf
setblock 1 244 503 minecraft:bookshelf
setblock 4 244 464 minecraft:bookshelf
setblock 11 244 464 minecraft:bookshelf
setblock 14 244 504 minecraft:bookshelf
setblock 18 244 464 minecraft:bookshelf
fill 20 244 502 24 244 503 minecraft:bookshelf
fill 21 244 504 21 245 504 minecraft:bookshelf
fill 23 244 504 24 244 504 minecraft:bookshelf
setblock 25 244 464 minecraft:bookshelf
setblock 28 244 499 minecraft:ochre_froglight
setblock 28 244 501 minecraft:ochre_froglight
setblock 28 244 503 minecraft:ochre_froglight
setblock 29 244 500 minecraft:ochre_froglight
setblock 29 244 502 minecraft:ochre_froglight
setblock 29 244 504 minecraft:ochre_froglight
setblock 30 244 499 minecraft:ochre_froglight
setblock 30 244 501 minecraft:ochre_froglight
setblock 30 244 503 minecraft:ochre_froglight
setblock 31 244 500 minecraft:ochre_froglight
setblock 31 244 502 minecraft:ochre_froglight
setblock 31 244 504 minecraft:ochre_froglight
setblock 32 244 464 minecraft:bookshelf
setblock 32 244 499 minecraft:ochre_froglight
setblock 32 244 501 minecraft:ochre_froglight
setblock 32 244 503 minecraft:ochre_froglight
setblock 33 244 500 minecraft:ochre_froglight
setblock 33 244 502 minecraft:ochre_froglight
setblock 33 244 504 minecraft:ochre_froglight
setblock 34 244 499 minecraft:ochre_froglight
setblock 34 244 501 minecraft:ochre_froglight
setblock 34 244 503 minecraft:ochre_froglight
setblock 35 244 500 minecraft:ochre_froglight
setblock 35 244 502 minecraft:ochre_froglight
setblock 35 244 504 minecraft:ochre_froglight
setblock 36 244 499 minecraft:ochre_froglight
setblock 36 244 501 minecraft:ochre_froglight
setblock 36 244 503 minecraft:ochre_froglight
setblock 37 244 500 minecraft:ochre_froglight
setblock 37 244 502 minecraft:ochre_froglight
setblock 37 244 504 minecraft:ochre_froglight
setblock 38 244 499 minecraft:ochre_froglight
setblock 38 244 501 minecraft:ochre_froglight
setblock 38 244 503 minecraft:ochre_froglight
setblock 39 244 464 minecraft:bookshelf
setblock 41 244 469 minecraft:bookshelf
setblock 41 244 476 minecraft:bookshelf
setblock 41 244 483 minecraft:bookshelf
setblock 41 244 490 minecraft:bookshelf
setblock 41 244 497 minecraft:bookshelf
fill 17 245 502 19 245 504 minecraft:bookshelf
fill 20 245 502 21 245 503 minecraft:bookshelf
fill 28 245 499 28 246 499 minecraft:bookshelf
fill 28 245 501 28 246 501 minecraft:bookshelf
fill 28 245 503 28 246 503 minecraft:bookshelf
fill 29 245 500 29 246 500 minecraft:bookshelf
fill 29 245 502 29 246 502 minecraft:bookshelf
fill 29 245 504 29 246 504 minecraft:bookshelf
fill 30 245 499 30 246 499 minecraft:bookshelf
fill 30 245 501 30 246 501 minecraft:bookshelf
fill 30 245 503 30 246 503 minecraft:bookshelf
fill 31 245 500 31 246 500 minecraft:bookshelf
fill 31 245 502 31 246 502 minecraft:bookshelf
fill 31 245 504 31 246 504 minecraft:bookshelf
fill 32 245 499 32 246 499 minecraft:bookshelf
fill 32 245 501 32 246 501 minecraft:bookshelf
fill 32 245 503 32 246 503 minecraft:bookshelf
fill 33 245 500 33 246 500 minecraft:bookshelf
fill 33 245 502 33 246 502 minecraft:bookshelf
fill 33 245 504 33 246 504 minecraft:bookshelf
fill 34 245 499 34 246 499 minecraft:bookshelf
fill 34 245 501 34 246 501 minecraft:bookshelf
fill 34 245 503 34 246 503 minecraft:bookshelf
fill 35 245 500 35 246 500 minecraft:bookshelf
fill 35 245 502 35 246 502 minecraft:bookshelf
fill 35 245 504 35 246 504 minecraft:bookshelf
fill 36 245 499 36 246 499 minecraft:bookshelf
fill 36 245 501 36 246 501 minecraft:bookshelf
fill 36 245 503 36 246 503 minecraft:bookshelf
fill 37 245 500 37 246 500 minecraft:bookshelf
fill 37 245 502 37 246 502 minecraft:bookshelf
fill 37 245 504 37 246 504 minecraft:bookshelf
fill 38 245 499 38 246 499 minecraft:bookshelf
fill 38 245 501 38 246 501 minecraft:bookshelf
fill 38 245 503 38 246 503 minecraft:bookshelf
setblock 1 246 470 minecraft:bookshelf
setblock 1 246 477 minecraft:bookshelf
setblock 1 246 484 minecraft:bookshelf
setblock 1 246 491 minecraft:bookshelf
setblock 1 246 498 minecraft:bookshelf
setblock 2 246 464 minecraft:bookshelf
setblock 2 246 504 minecraft:bookshelf
setblock 9 246 464 minecraft:bookshelf
fill 13 246 504 14 247 504 minecraft:bookshelf
fill 14 246 502 18 246 503 minecraft:bookshelf
setblock 16 246 464 minecraft:bookshelf
fill 16 246 504 18 246 504 minecraft:bookshelf
setblock 23 246 464 minecraft:bookshelf
setblock 23 246 504 minecraft:bookshelf
setblock 30 246 464 minecraft:bookshelf
setblock 37 246 464 minecraft:bookshelf
setblock 41 246 467 minecraft:bookshelf
setblock 41 246 474 minecraft:bookshelf
setblock 41 246 481 minecraft:bookshelf
setblock 41 246 488 minecraft:bookshelf
setblock 41 246 495 minecraft:bookshelf
setblock 41 246 502 minecraft:bookshelf
setblock 1 247 464 minecraft:bookshelf
setblock 1 247 471 minecraft:bookshelf
setblock 1 247 478 minecraft:bookshelf
setblock 1 247 485 minecraft:bookshelf
setblock 1 247 492 minecraft:bookshelf
setblock 1 247 499 minecraft:bookshelf
setblock 3 247 504 minecraft:bookshelf
setblock 8 247 464 minecraft:bookshelf
fill 8 247 504 12 247 504 minecraft:bookshelf
fill 10 247 502 15 247 503 minecraft:bookshelf
setblock 15 247 464 minecraft:bookshelf
setblock 17 247 504 minecraft:bookshelf
setblock 22 247 464 minecraft:bookshelf
setblock 24 247 504 minecraft:bookshelf
setblock 28 247 499 minecraft:ochre_froglight
setblock 28 247 501 minecraft:ochre_froglight
setblock 28 247 503 minecraft:ochre_froglight
setblock 29 247 464 minecraft:bookshelf
setblock 29 247 500 minecraft:ochre_froglight
setblock 29 247 502 minecraft:ochre_froglight
setblock 29 247 504 minecraft:ochre_froglight
setblock 30 247 499 minecraft:ochre_froglight
setblock 30 247 501 minecraft:ochre_froglight
setblock 30 247 503 minecraft:ochre_froglight
setblock 31 247 500 minecraft:ochre_froglight
setblock 31 247 502 minecraft:ochre_froglight
setblock 31 247 504 minecraft:ochre_froglight
setblock 32 247 499 minecraft:ochre_froglight
setblock 32 247 501 minecraft:ochre_froglight
setblock 32 247 503 minecraft:ochre_froglight
setblock 33 247 500 minecraft:ochre_froglight
setblock 33 247 502 minecraft:ochre_froglight
setblock 33 247 504 minecraft:ochre_froglight
setblock 34 247 499 minecraft:ochre_froglight
setblock 34 247 501 minecraft:ochre_froglight
setblock 34 247 503 minecraft:ochre_froglight
setblock 35 247 500 minecraft:ochre_froglight
setblock 35 247 502 minecraft:ochre_froglight
setblock 35 247 504 minecraft:ochre_froglight
setblock 36 247 464 minecraft:bookshelf
setblock 36 247 499 minecraft:ochre_froglight
setblock 36 247 501 minecraft:ochre_froglight
setblock 36 247 503 minecraft:ochre_froglight
setblock 37 247 500 minecraft:ochre_froglight
setblock 37 247 502 minecraft:ochre_froglight
setblock 37 247 504 minecraft:ochre_froglight
setblock 38 247 499 minecraft:ochre_froglight
setblock 38 247 501 minecraft:ochre_froglight
setblock 38 247 503 minecraft:ochre_froglight
setblock 41 247 466 minecraft:bookshelf
setblock 41 247 473 minecraft:bookshelf
setblock 41 247 480 minecraft:bookshelf
setblock 41 247 487 minecraft:bookshelf
setblock 41 247 494 minecraft:bookshelf
setblock 41 247 501 minecraft:bookshelf
setblock 1 248 465 minecraft:bookshelf
setblock 1 248 472 minecraft:bookshelf
setblock 1 248 479 minecraft:bookshelf
setblock 1 248 486 minecraft:bookshelf
setblock 1 248 493 minecraft:bookshelf
setblock 1 248 500 minecraft:bookshelf
fill 4 248 504 11 248 504 minecraft:bookshelf
fill 5 248 503 11 248 503 minecraft:bookshelf
fill 6 248 502 12 248 502 minecraft:bookshelf
setblock 7 248 464 minecraft:bookshelf
setblock 14 248 464 minecraft:bookshelf
setblock 18 248 504 minecraft:bookshelf
setblock 21 248 464 minecraft:bookshelf
setblock 25 248 504 minecraft:bookshelf
setblock 28 248 464 minecraft:bookshelf
fill 28 248 499 28 249 499 minecraft:bookshelf
fill 28 248 501 28 249 501 minecraft:bookshelf
fill 28 248 503 28 249 503 minecraft:bookshelf
fill 29 248 500 29 249 500 minecraft:bookshelf
fill 29 248 502 29 249 502 minecraft:bookshelf
fill 29 248 504 29 249 504 minecraft:bookshelf
fill 30 248 499 30 249 499 minecraft:bookshelf
fill 30 248 501 30 249 501 minecraft:bookshelf
fill 30 248 503 30 249 503 minecraft:bookshelf
fill 31 248 500 31 249 500 minecraft:bookshelf
fill 31 248 502 31 249 502 minecraft:bookshelf
fill 31 248 504 31 249 504 minecraft:bookshelf
fill 32 248 499 32 249 499 minecraft:bookshelf
fill 32 248 501 32 249 501 minecraft:bookshelf
fill 32 248 503 32 249 503 minecraft:bookshelf
fill 33 248 500 33 249 500 minecraft:bookshelf
fill 33 248 502 33 249 502 minecraft:bookshelf
fill 33 248 504 33 249 504 minecraft:bookshelf
fill 34 248 499 34 249 499 minecraft:bookshelf
fill 34 248 501 34 249 501 minecraft:bookshelf
fill 34 248 503 34 249 503 minecraft:bookshelf
setblock 35 248 464 minecraft:bookshelf
fill 35 248 500 35 249 500 minecraft:bookshelf
fill 35 248 502 35 249 502 minecraft:bookshelf
fill 35 248 504 35 249 504 minecraft:bookshelf
fill 36 248 499 36 249 499 minecraft:bookshelf
fill 36 248 501 36 249 501 minecraft:bookshelf
fill 36 248 503 36 249 503 minecraft:bookshelf
fill 37 248 500 37 249 500 minecraft:bookshelf
fill 37 248 502 37 249 502 minecraft:bookshelf
fill 37 248 504 37 249 504 minecraft:bookshelf
fill 38 248 499 38 249 499 minecraft:bookshelf
fill 38 248 501 38 249 501 minecraft:bookshelf
fill 38 248 503 38 249 503 minecraft:bookshelf
setblock 39 248 504 minecraft:bookshelf
setblock 41 248 465 minecraft:bookshelf
setblock 41 248 472 minecraft:bookshelf
setblock 41 248 479 minecraft:bookshelf
setblock 41 248 486 minecraft:bookshelf
setblock 41 248 493 minecraft:bookshelf
setblock 41 248 500 minecraft:bookshelf
fill 1 249 466 1 250 466 minecraft:bookshelf
fill 1 249 473 1 250 473 minecraft:bookshelf
fill 1 249 480 1 250 480 minecraft:bookshelf
fill 1 249 487 1 250 487 minecraft:bookshelf
fill 1 249 494 1 252 494 minecraft:bookshelf
fill 1 249 501 3 249 503 minecraft:bookshelf
fill 2 249 504 6 250 504 minecraft:bookshelf
setblock 3 249 466 minecraft:light[level=12]
setblock 3 249 474 minecraft:light[level=12]
setblock 3 249 482 minecraft:light[level=12]
setblock 3 249 490 minecraft:light[level=12]
setblock 3 249 498 minecraft:light[level=12]
fill 3 249 500 3 250 500 minecraft:bookshelf
fill 4 249 502 7 249 503 minecraft:bookshelf
fill 6 249 464 6 250 464 minecraft:bookshelf
setblock 8 249 502 minecraft:bookshelf
fill 8 249 504 8 273 504 minecraft:bookshelf
setblock 11 249 466 minecraft:light[level=12]
setblock 11 249 474 minecraft:light[level=12]
setblock 11 249 482 minecraft:light[level=12]
setblock 11 249 490 minecraft:light[level=12]
setblock 11 249 498 minecraft:light[level=12]
fill 12 249 504 12 250 504 minecraft:bookshelf
fill 13 249 464 13 250 464 minecraft:bookshelf
setblock 19 249 466 minecraft:light[level=12]
setblock 19 249 474 minecraft:light[level=12]
setblock 19 249 482 minecraft:light[level=12]
setblock 19 249 490 minecraft:light[level=12]
setblock 19 249 498 minecraft:light[level=12]
fill 19 249 504 19 250 504 minecraft:bookshelf
fill 20 249 464 20 250 464 minecraft:bookshelf
fill 26 249 504 26 250 504 minecraft:bookshelf
fill 27 249 464 27 250 464 minecraft:bookshelf
setblock 27 249 466 minecraft:light[level=12]
setblock 27 249 474 minecraft:light[level=12]
setblock 27 249 482 minecraft:light[level=12]
setblock 27 249 490 minecraft:light[level=12]
setblock 27 249 498 minecraft:light[level=12]
fill 34 249 464 34 250 464 minecraft:bookshelf
setblock 35 249 466 minecraft:light[level=12]
setblock 35 249 474 minecraft:light[level=12]
setblock 35 249 482 minecraft:light[level=12]
setblock 35 249 490 minecraft:light[level=12]
setblock 35 249 498 minecraft:light[level=12]
fill 40 249 504 40 250 504 minecraft:bookshelf
fill 41 249 464 41 250 464 minecraft:bookshelf
fill 41 249 471 41 250 471 minecraft:bookshelf
fill 41 249 478 41 250 478 minecraft:bookshelf
fill 41 249 485 41 250 485 minecraft:bookshelf
fill 41 249 492 41 250 492 minecraft:bookshelf
fill 41 249 499 41 250 499 minecraft:bookshelf
fill 1 250 464 1 250 465 minecraft:bookshelf
fill 1 250 467 1 250 468 minecraft:bookshelf
fill 1 250 470 1 250 472 minecraft:bookshelf
fill 1 250 474 1 250 475 minecraft:bookshelf
fill 1 250 477 1 250 479 minecraft:bookshelf
fill 1 250 481 1 250 482 minecraft:bookshelf
fill 1 250 484 1 250 486 minecraft:bookshelf
fill 1 250 488 1 250 489 minecraft:bookshelf
fill 1 250 491 1 250 493 minecraft:bookshelf
fill 1 250 495 1 251 496 minecraft:bookshelf
fill 1 250 498 2 250 503 minecraft:bookshelf
setblock 2 250 464 minecraft:bookshelf
fill 2 250 496 3 251 497 minecraft:bookshelf
fill 3 250 498 3 250 499 minecraft:bookshelf
fill 3 250 501 3 250 502 minecraft:bookshelf
fill 4 250 464 5 250 464 minecraft:bookshelf
fill 7 250 464 9 250 464 minecraft:bookshelf
fill 7 250 504 7 251 504 minecraft:bookshelf
fill 9 250 504 11 250 504 minecraft:bookshelf
fill 11 250 464 12 250 464 minecraft:bookshelf
fill 13 250 504 14 250 504 minecraft:bookshelf
fill 14 250 464 16 250 464 minecraft:bookshelf
fill 16 250 504 18 250 504 minecraft:bookshelf
fill 18 250 464 19 250 464 minecraft:bookshelf
fill 20 250 504 21 250 504 minecraft:bookshelf
fill 21 250 464 23 250 464 minecraft:bookshelf
fill 23 250 504 25 250 504 minecraft:bookshelf
fill 25 250 464 26 250 464 minecraft:bookshelf
setblock 27 250 504 minecraft:bookshelf
fill 28 250 464 30 250 464 minecraft:bookshelf
setblock 28 250 499 minecraft:ochre_froglight
setblock 28 250 501 minecraft:ochre_froglight
setblock 28 250 503 minecraft:ochre_froglight
setblock 29 250 500 minecraft:ochre_froglight
setblock 29 250 502 minecraft:ochre_froglight
setblock 29 250 504 minecraft:ochre_froglight
setblock 30 250 499 minecraft:ochre_froglight
setblock 30 250 501 minecraft:ochre_froglight
setblock 30 250 503 minecraft:ochre_froglight
setblock 31 250 500 minecraft:ochre_froglight
setblock 31 250 502 minecraft:ochre_froglight
setblock 31 250 504 minecraft:ochre_froglight
fill 32 250 464 33 250 464 minecraft:bookshelf
setblock 32 250 499 minecraft:ochre_froglight
setblock 32 250 501 minecraft:ochre_froglight
setblock 32 250 503 minecraft:ochre_froglight
setblock 33 250 500 minecraft:ochre_froglight
setblock 33 250 502 minecraft:ochre_froglight
setblock 33 250 504 minecraft:ochre_froglight
setblock 34 250 499 minecraft:ochre_froglight
setblock 34 250 501 minecraft:ochre_froglight
setblock 34 250 503 minecraft:ochre_froglight
fill 35 250 464 37 250 464 minecraft:bookshelf
setblock 35 250 500 minecraft:ochre_froglight
setblock 35 250 502 minecraft:ochre_froglight
setblock 35 250 504 minecraft:ochre_froglight
setblock 36 250 499 minecraft:ochre_froglight
setblock 36 250 501 minecraft:ochre_froglight
setblock 36 250 503 minecraft:ochre_froglight
setblock 37 250 500 minecraft:ochre_froglight
setblock 37 250 502 minecraft:ochre_froglight
setblock 37 250 504 minecraft:ochre_froglight
setblock 38 250 499 minecraft:ochre_froglight
setblock 38 250 501 minecraft:ochre_froglight
setblock 38 250 503 minecraft:ochre_froglight
fill 39 250 464 40 250 464 minecraft:bookshelf
setblock 39 250 504 minecraft:bookshelf
fill 41 250 465 41 250 467 minecraft:bookshelf
fill 41 250 469 41 250 470 minecraft:bookshelf
fill 41 250 472 41 250 474 minecraft:bookshelf
fill 41 250 476 41 250 477 minecraft:bookshelf
fill 41 250 479 41 250 481 minecraft:bookshelf
fill 41 250 483 41 250 484 minecraft:bookshelf
fill 41 250 486 41 250 488 minecraft:bookshelf
fill 41 250 490 41 250 491 minecraft:bookshelf
fill 41 250 493 41 250 495 minecraft:bookshelf
fill 41 250 497 41 250 498 minecraft:bookshelf
fill 41 250 500 41 250 502 minecraft:bookshelf
setblock 41 250 504 minecraft:bookshelf
setblock 1 251 468 minecraft:bookshelf
setblock 1 251 475 minecraft:bookshelf
setblock 1 251 482 minecraft:bookshelf
fill 1 251 489 1 253 489 minecraft:bookshelf
fill 1 251 493 3 252 493 minecraft:bookshelf
fill 1 251 498 1 251 499 minecraft:bookshelf
setblock 1 251 503 minecraft:bookshelf
fill 2 251 492 3 252 492 minecraft:bookshelf
fill 2 251 494 3 251 495 minecraft:bookshelf
setblock 2 251 498 minecraft:bookshelf
setblock 4 251 464 minecraft:bookshelf
setblock 11 251 464 minecraft:bookshelf
setblock 14 251 504 minecraft:bookshelf
setblock 18 251 464 minecraft:bookshelf
setblock 21 251 504 minecraft:bookshelf
setblock 25 251 464 minecraft:bookshelf
fill 28 251 499 28 252 499 minecraft:bookshelf
fill 28 251 501 28 252 501 minecraft:bookshelf
fill 28 251 503 28 252 503 minecraft:bookshelf
fill 29 251 500 29 252 500 minecraft:bookshelf
fill 29 251 502 29 252 502 minecraft:bookshelf
fill 29 251 504 29 252 504 minecraft:bookshelf
fill 30 251 499 30 252 499 minecraft:bookshelf
fill 30 251 501 30 252 501 minecraft:bookshelf
fill 30 251 503 30 252 503 minecraft:bookshelf
fill 31 251 500 31 252 500 minecraft:bookshelf
fill 31 251 502 31 252 502 minecraft:bookshelf
fill 31 251 504 31 252 504 minecraft:bookshelf
setblock 32 251 464 minecraft:bookshelf
fill 32 251 499 32 252 499 minecraft:bookshelf
fill 32 251 501 32 252 501 minecraft:bookshelf
fill 32 251 503 32 252 503 minecraft:bookshelf
fill 33 251 500 33 252 500 minecraft:bookshelf
fill 33 251 502 33 252 502 minecraft:bookshelf
fill 33 251 504 33 252 504 minecraft:bookshelf
fill 34 251 499 34 252 499 minecraft:bookshelf
fill 34 251 501 34 252 501 minecraft:bookshelf
fill 34 251 503 34 252 503 minecraft:bookshelf
fill 35 251 500 35 252 500 minecraft:bookshelf
fill 35 251 502 35 252 502 minecraft:bookshelf
fill 35 251 504 35 252 504 minecraft:bookshelf
fill 36 251 499 36 252 499 minecraft:bookshelf
fill 36 251 501 36 252 501 minecraft:bookshelf
fill 36 251 503 36 252 503 minecraft:bookshelf
fill 37 251 500 37 252 500 minecraft:bookshelf
fill 37 251 502 37 252 502 minecraft:bookshelf
fill 37 251 504 37 252 504 minecraft:bookshelf
fill 38 251 499 38 252 499 minecraft:bookshelf
fill 38 251 501 38 252 501 minecraft:bookshelf
fill 38 251 503 38 252 503 minecraft:bookshelf
setblock 39 251 464 minecraft:bookshelf
setblock 41 251 469 minecraft:bookshelf
setblock 41 251 476 minecraft:bookshelf
setblock 41 251 483 minecraft:bookshelf
setblock 41 251 490 minecraft:bookshelf
setblock 41 251 497 minecraft:bookshelf
fill 1 252 491 1 252 492 minecraft:bookshelf
fill 2 252 489 3 252 491 minecraft:bookshelf
setblock 2 252 494 minecraft:bookshelf
setblock 1 253 470 minecraft:bookshelf
setblock 1 253 477 minecraft:bookshelf
fill 1 253 484 1 255 484 minecraft:bookshelf
fill 1 253 486 3 253 488 minecraft:bookshelf
setblock 1 253 491 minecraft:bookshelf
fill 1 253 496 7 253 496 minecraft:dark_oak_planks
setblock 1 253 498 minecraft:bookshelf
setblock 2 253 464 minecraft:bookshelf
fill 2 253 489 3 253 490 minecraft:bookshelf
setblock 2 253 504 minecraft:bookshelf
fill 3 253 494 7 254 495 minecraft:dark_oak_planks
fill 3 253 497 7 254 498 minecraft:dark_oak_planks
setblock 9 253 464 minecraft:bookshelf
setblock 9 253 504 minecraft:bookshelf
setblock 16 253 464 minecraft:bookshelf
setblock 16 253 504 minecraft:bookshelf
setblock 23 253 464 minecraft:bookshelf
setblock 23 253 504 minecraft:bookshelf
setblock 28 253 499 minecraft:ochre_froglight
setblock 28 253 501 minecraft:ochre_froglight
setblock 28 253 503 minecraft:ochre_froglight
setblock 29 253 500 minecraft:ochre_froglight
setblock 29 253 502 minecraft:ochre_froglight
setblock 29 253 504 minecraft:ochre_froglight
setblock 30 253 464 minecraft:bookshelf
setblock 30 253 499 minecraft:ochre_froglight
setblock 30 253 501 minecraft:ochre_froglight
setblock 30 253 503 minecraft:ochre_froglight
setblock 31 253 500 minecraft:ochre_froglight
setblock 31 253 502 minecraft:ochre_froglight
setblock 31 253 504 minecraft:ochre_froglight
setblock 32 253 499 minecraft:ochre_froglight
setblock 32 253 501 minecraft:ochre_froglight
setblock 32 253 503 minecraft:ochre_froglight
setblock 33 253 500 minecraft:ochre_froglight
setblock 33 253 502 minecraft:ochre_froglight
setblock 33 253 504 minecraft:ochre_froglight
setblock 34 253 499 minecraft:ochre_froglight
setblock 34 253 501 minecraft:ochre_froglight
setblock 34 253 503 minecraft:ochre_froglight
setblock 35 253 500 minecraft:ochre_froglight
setblock 35 253 502 minecraft:ochre_froglight
setblock 35 253 504 minecraft:ochre_froglight
setblock 36 253 499 minecraft:ochre_froglight
setblock 36 253 501 minecraft:ochre_froglight
setblock 36 253 503 minecraft:ochre_froglight
setblock 37 253 464 minecraft:bookshelf
setblock 37 253 500 minecraft:ochre_froglight
setblock 37 253 502 minecraft:ochre_froglight
setblock 37 253 504 minecraft:ochre_froglight
setblock 38 253 499 minecraft:ochre_froglight
setblock 38 253 501 minecraft:ochre_froglight
setblock 38 253 503 minecraft:ochre_froglight
setblock 41 253 467 minecraft:bookshelf
setblock 41 253 474 minecraft:bookshelf
setblock 41 253 481 minecraft:bookshelf
setblock 41 253 488 minecraft:bookshelf
setblock 41 253 495 minecraft:bookshelf
setblock 41 253 502 minecraft:bookshelf
setblock 1 254 464 minecraft:bookshelf
setblock 1 254 471 minecraft:bookshelf
setblock 1 254 478 minecraft:bookshelf
fill 1 254 485 3 254 487 minecraft:bookshelf
setblock 1 254 492 minecraft:bookshelf
setblock 1 254 499 minecraft:bookshelf
fill 2 254 483 3 255 484 minecraft:bookshelf
fill 3 254 496 7 254 496 minecraft:dark_oak_planks
setblock 3 254 504 minecraft:bookshelf
setblock 8 254 464 minecraft:bookshelf
setblock 10 254 504 minecraft:bookshelf
setblock 15 254 464 minecraft:bookshelf
setblock 17 254 504 minecraft:bookshelf
fill 21 254 501 21 255 503 minecraft:gold_block
setblock 22 254 464 minecraft:bookshelf
setblock 24 254 504 minecraft:bookshelf
fill 28 254 499 28 256 499 minecraft:bookshelf
fill 28 254 501 28 256 501 minecraft:bookshelf
fill 28 254 503 28 256 503 minecraft:bookshelf
setblock 29 254 464 minecraft:bookshelf
fill 29 254 500 29 256 500 minecraft:bookshelf
fill 29 254 502 29 256 502 minecraft:bookshelf
fill 29 254 504 29 273 504 minecraft:bookshelf
fill 30 254 499 30 256 499 minecraft:bookshelf
fill 30 254 501 30 256 501 minecraft:bookshelf
fill 30 254 503 30 256 503 minecraft:bookshelf
fill 31 254 500 31 256 500 minecraft:bookshelf
fill 31 254 502 31 256 502 minecraft:bookshelf
fill 31 254 504 31 256 504 minecraft:bookshelf
fill 32 254 499 32 256 499 minecraft:bookshelf
fill 32 254 501 32 256 501 minecraft:bookshelf
fill 32 254 503 32 256 503 minecraft:bookshelf
fill 33 254 500 33 256 500 minecraft:bookshelf
fill 33 254 502 33 256 502 minecraft:bookshelf
fill 33 254 504 33 256 504 minecraft:bookshelf
fill 34 254 499 34 256 499 minecraft:bookshelf
fill 34 254 501 34 256 501 minecraft:bookshelf
fill 34 254 503 34 256 503 minecraft:bookshelf
fill 35 254 500 35 256 500 minecraft:bookshelf
fill 35 254 502 35 256 502 minecraft:bookshelf
fill 35 254 504 35 256 504 minecraft:bookshelf
setblock 36 254 464 minecraft:bookshelf
fill 36 254 499 36 256 499 minecraft:bookshelf
fill 36 254 501 36 256 501 minecraft:bookshelf
fill 36 254 503 36 256 503 minecraft:bookshelf
fill 37 254 500 37 256 500 minecraft:bookshelf
fill 37 254 502 37 256 502 minecraft:bookshelf
fill 37 254 504 37 256 504 minecraft:bookshelf
fill 38 254 499 38 256 499 minecraft:bookshelf
fill 38 254 501 38 256 501 minecraft:bookshelf
fill 38 254 503 38 256 503 minecraft:bookshelf
setblock 41 254 466 minecraft:bookshelf
setblock 41 254 473 minecraft:bookshelf
setblock 41 254 480 minecraft:bookshelf
setblock 41 254 487 minecraft:bookshelf
setblock 41 254 494 minecraft:bookshelf
setblock 41 254 501 minecraft:bookshelf
setblock 1 255 465 minecraft:bookshelf
setblock 1 255 472 minecraft:bookshelf
fill 1 255 479 1 255 482 minecraft:bookshelf
setblock 1 255 486 minecraft:bookshelf
setblock 1 255 493 minecraft:bookshelf
setblock 1 255 500 minecraft:bookshelf
fill 2 255 480 3 255 482 minecraft:bookshelf
fill 4 255 496 6 262 496 minecraft:purple_concrete
setblock 4 255 504 minecraft:bookshelf
fill 5 255 495 5 262 495 minecraft:purple_concrete
fill 5 255 497 5 262 497 minecraft:purple_concrete
setblock 7 255 464 minecraft:bookshelf
setblock 11 255 504 minecraft:bookshelf
setblock 14 255 464 minecraft:bookshelf
setblock 18 255 504 minecraft:bookshelf
setblock 21 255 464 minecraft:bookshelf
setblock 25 255 504 minecraft:bookshelf
setblock 28 255 464 minecraft:bookshelf
setblock 35 255 464 minecraft:bookshelf
setblock 39 255 504 minecraft:bookshelf
setblock 41 255 465 minecraft:bookshelf
setblock 41 255 472 minecraft:bookshelf
setblock 41 255 479 minecraft:bookshelf
setblock 41 255 486 minecraft:bookshelf
setblock 41 255 493 minecraft:bookshelf
setblock 41 255 500 minecraft:bookshelf
setblock 1 256 466 minecraft:bookshelf
fill 1 256 473 1 258 473 minecraft:bookshelf
fill 1 256 477 3 256 481 minecraft:bookshelf
setblock 1 256 487 minecraft:bookshelf
setblock 1 256 494 minecraft:bookshelf
setblock 1 256 501 minecraft:bookshelf
setblock 5 256 504 minecraft:bookshelf
setblock 6 256 464 minecraft:bookshelf
setblock 12 256 504 minecraft:bookshelf
setblock 13 256 464 minecraft:bookshelf
setblock 19 256 504 minecraft:bookshelf
setblock 20 256 464 minecraft:bookshelf
setblock 26 256 504 minecraft:bookshelf
setblock 27 256 464 minecraft:bookshelf
setblock 34 256 464 minecraft:bookshelf
setblock 40 256 504 minecraft:bookshelf
setblock 41 256 464 minecraft:bookshelf
setblock 41 256 471 minecraft:bookshelf
setblock 41 256 478 minecraft:bookshelf
setblock 41 256 485 minecraft:bookshelf
setblock 41 256 492 minecraft:bookshelf
setblock 41 256 499 minecraft:bookshelf
fill 1 257 467 1 260 467 minecraft:bookshelf
fill 1 257 472 1 258 472 minecraft:bookshelf
fill 1 257 474 3 257 475 minecraft:bookshelf
fill 1 257 477 3 257 477 minecraft:bookshelf
setblock 1 257 481 minecraft:bookshelf
setblock 1 257 488 minecraft:bookshelf
setblock 1 257 495 minecraft:bookshelf
setblock 1 257 502 minecraft:bookshelf
fill 2 257 473 3 258 473 minecraft:bookshelf
fill 2 257 476 3 257 476 minecraft:bookshelf
fill 2 257 478 3 257 478 minecraft:bookshelf
setblock 3 257 466 minecraft:light[level=12]
setblock 3 257 482 minecraft:light[level=12]
setblock 3 257 490 minecraft:light[level=12]
setblock 3 257 498 minecraft:light[level=12]
setblock 5 257 464 minecraft:bookshelf
setblock 6 257 504 minecraft:bookshelf
setblock 11 257 466 minecraft:light[level=12]
setblock 11 257 474 minecraft:light[level=12]
setblock 11 257 482 minecraft:light[level=12]
setblock 11 257 490 minecraft:light[level=12]
setblock 11 257 498 minecraft:light[level=12]
setblock 12 257 464 minecraft:bookshelf
setblock 13 257 504 minecraft:bookshelf
setblock 19 257 464 minecraft:bookshelf
setblock 19 257 466 minecraft:light[level=12]
setblock 19 257 474 minecraft:light[level=12]
setblock 19 257 482 minecraft:light[level=12]
setblock 19 257 490 minecraft:light[level=12]
setblock 19 257 498 minecraft:light[level=12]
setblock 20 257 504 minecraft:bookshelf
setblock 26 257 464 minecraft:bookshelf
setblock 27 257 466 minecraft:light[level=12]
setblock 27 257 474 minecraft:light[level=12]
setblock 27 257 482 minecraft:light[level=12]
setblock 27 257 490 minecraft:light[level=12]
setblock 27 257 498 minecraft:light[level=12]
setblock 27 257 504 minecraft:bookshelf
setblock 33 257 464 minecraft:bookshelf
setblock 35 257 466 minecraft:light[level=12]
setblock 35 257 474 minecraft:light[level=12]
setblock 35 257 482 minecraft:light[level=12]
setblock 35 257 490 minecraft:light[level=12]
setblock 35 257 498 minecraft:light[level=12]
setblock 40 257 464 minecraft:bookshelf
setblock 41 257 470 minecraft:bookshelf
setblock 41 257 477 minecraft:bookshelf
setblock 41 257 484 minecraft:bookshelf
setblock 41 257 491 minecraft:bookshelf
setblock 41 257 498 minecraft:bookshelf
setblock 41 257 504 minecraft:bookshelf
fill 1 258 468 2 259 468 minecraft:bookshelf
fill 1 258 470 3 258 471 minecraft:bookshelf
fill 1 258 474 1 258 475 minecraft:bookshelf
setblock 1 258 482 minecraft:bookshelf
setblock 1 258 489 minecraft:bookshelf
setblock 1 258 496 minecraft:bookshelf
setblock 1 258 503 minecraft:bookshelf
fill 2 258 469 3 259 469 minecraft:bookshelf
fill 2 258 472 3 258 472 minecraft:bookshelf
fill 2 258 474 3 258 474 minecraft:bookshelf
setblock 3 258 475 minecraft:bookshelf
setblock 4 258 464 minecraft:bookshelf
setblock 7 258 504 minecraft:bookshelf
setblock 11 258 464 minecraft:bookshelf
fill 13 258 474 15 259 474 minecraft:red_wool
fill 14 258 473 14 259 473 minecraft:red_wool
fill 14 258 475 14 259 475 minecraft:red_wool
setblock 14 258 504 minecraft:bookshelf
setblock 18 258 464 minecraft:bookshelf
setblock 21 258 504 minecraft:bookshelf
setblock 25 258 464 minecraft:bookshelf
setblock 28 258 504 minecraft:bookshelf
fill 30 258 466 34 259 470 minecraft:dark_oak_planks
setblock 32 258 464 minecraft:bookshelf
setblock 32 258 465 minecraft:dark_oak_planks
setblock 35 258 504 minecraft:bookshelf
setblock 39 258 464 minecraft:bookshelf
setblock 41 258 469 minecraft:bookshelf
setblock 41 258 476 minecraft:bookshelf
setblock 41 258 483 minecraft:bookshelf
setblock 41 258 490 minecraft:bookshelf
setblock 41 258 497 minecraft:bookshelf
fill 1 259 464 2 259 466 minecraft:bookshelf
fill 2 259 467 3 259 467 minecraft:bookshelf
fill 2 259 470 3 259 470 minecraft:bookshelf
fill 3 259 465 4 260 466 minecraft:bookshelf
setblock 3 259 468 minecraft:bookshelf
setblock 3 259 471 minecraft:bookshelf
fill 5 259 466 5 260 466 minecraft:bookshelf
fill 1 260 464 1 260 466 minecraft:bookshelf
setblock 1 260 468 minecraft:bookshelf
fill 1 260 470 1 260 475 minecraft:bookshelf
fill 1 260 477 1 260 482 minecraft:bookshelf
fill 1 260 484 1 260 489 minecraft:bookshelf
fill 1 260 491 1 260 496 minecraft:bookshelf
fill 1 260 498 1 260 503 minecraft:bookshelf
fill 2 260 464 2 260 465 minecraft:bookshelf
fill 2 260 504 7 260 504 minecraft:bookshelf
fill 3 260 481 3 261 481 minecraft:white_wool
fill 4 260 464 9 260 464 minecraft:bookshelf
fill 5 260 465 9 260 465 minecraft:bookshelf
fill 6 260 466 9 260 466 minecraft:bookshelf
fill 9 260 504 14 260 504 minecraft:bookshelf
fill 11 260 464 16 260 464 minecraft:bookshelf
fill 16 260 504 21 260 504 minecraft:bookshelf
fill 18 260 464 23 260 464 minecraft:bookshelf
fill 23 260 504 28 260 504 minecraft:bookshelf
fill 25 260 464 30 260 464 minecraft:bookshelf
fill 30 260 504 35 260 504 minecraft:bookshelf
fill 31 260 468 33 266 468 minecraft:purple_concrete
fill 32 260 464 37 260 464 minecraft:bookshelf
fill 32 260 467 32 266 467 minecraft:purple_concrete
fill 32 260 469 32 266 469 minecraft:purple_concrete
fill 37 260 504 41 260 504 minecraft:bookshelf
fill 39 260 464 41 260 464 minecraft:bookshelf
fill 41 260 465 41 260 467 minecraft:bookshelf
fill 41 260 469 41 260 474 minecraft:bookshelf
fill 41 260 476 41 260 481 minecraft:bookshelf
fill 41 260 483 41 260 488 minecraft:bookshelf
fill 41 260 490 41 260 495 minecraft:bookshelf
fill 41 260 497 41 260 502 minecraft:bookshelf
setblock 1 261 464 minecraft:bookshelf
setblock 1 261 471 minecraft:bookshelf
setblock 1 261 478 minecraft:bookshelf
setblock 1 261 485 minecraft:bookshelf
setblock 1 261 492 minecraft:bookshelf
setblock 1 261 499 minecraft:bookshelf
setblock 3 261 504 minecraft:bookshelf
fill 6 261 464 9 261 464 minecraft:bookshelf
fill 7 261 465 13 261 465 minecraft:bookshelf
fill 8 261 466 13 261 466 minecraft:bookshelf
setblock 10 261 504 minecraft:bookshelf
fill 11 261 464 12 262 464 minecraft:bookshelf
fill 15 261 464 15 263 464 minecraft:bookshelf
setblock 17 261 504 minecraft:bookshelf
setblock 22 261 464 minecraft:bookshelf
setblock 24 261 504 minecraft:bookshelf
setblock 29 261 464 minecraft:bookshelf
setblock 31 261 504 minecraft:bookshelf
setblock 36 261 464 minecraft:bookshelf
setblock 38 261 504 minecraft:bookshelf
setblock 41 261 466 minecraft:bookshelf
setblock 41 261 473 minecraft:bookshelf
setblock 41 261 480 minecraft:bookshelf
setblock 41 261 487 minecraft:bookshelf
setblock 41 261 494 minecraft:bookshelf
setblock 41 261 501 minecraft:bookshelf
setblock 1 262 465 minecraft:bookshelf
setblock 1 262 472 minecraft:bookshelf
setblock 1 262 479 minecraft:bookshelf
setblock 1 262 486 minecraft:bookshelf
setblock 1 262 493 minecraft:bookshelf
setblock 1 262 500 minecraft:bookshelf
setblock 4 262 504 minecraft:bookshelf
setblock 7 262 464 minecraft:bookshelf
fill 11 262 465 16 262 465 minecraft:bookshelf
setblock 11 262 504 minecraft:bookshelf
fill 12 262 466 16 262 466 minecraft:bookshelf
fill 13 262 464 14 262 464 minecraft:bookshelf
fill 16 262 464 16 263 464 minecraft:bookshelf
setblock 18 262 504 minecraft:bookshelf
setblock 21 262 464 minecraft:bookshelf
setblock 25 262 504 minecraft:bookshelf
setblock 28 262 464 minecraft:bookshelf
setblock 32 262 504 minecraft:bookshelf
setblock 35 262 464 minecraft:bookshelf
setblock 39 262 504 minecraft:bookshelf
setblock 41 262 465 minecraft:bookshelf
setblock 41 262 472 minecraft:bookshelf
setblock 41 262 479 minecraft:bookshelf
setblock 41 262 486 minecraft:bookshelf
setblock 41 262 493 minecraft:bookshelf
setblock 41 262 500 minecraft:bookshelf
setblock 1 263 466 minecraft:bookshelf
setblock 1 263 473 minecraft:bookshelf
fill 1 263 478 3 264 478 minecraft:gold_block
setblock 1 263 480 minecraft:bookshelf
setblock 1 263 487 minecraft:bookshelf
setblock 1 263 494 minecraft:bookshelf
fill 1 263 495 3 263 495 minecraft:gold_block
setblock 1 263 501 minecraft:bookshelf
setblock 5 263 504 minecraft:bookshelf
setblock 6 263 464 minecraft:bookshelf
setblock 12 263 504 minecraft:bookshelf
setblock 13 263 464 minecraft:bookshelf
fill 15 263 465 19 263 466 minecraft:bookshelf
fill 18 263 464 20 264 464 minecraft:bookshelf
setblock 19 263 504 minecraft:bookshelf
setblock 26 263 504 minecraft:bookshelf
setblock 27 263 464 minecraft:bookshelf
setblock 33 263 504 minecraft:bookshelf
setblock 34 263 464 minecraft:bookshelf
setblock 40 263 504 minecraft:bookshelf
setblock 41 263 464 minecraft:bookshelf
setblock 41 263 471 minecraft:bookshelf
setblock 41 263 478 minecraft:bookshelf
setblock 41 263 485 minecraft:bookshelf
setblock 41 263 492 minecraft:bookshelf
setblock 41 263 499 minecraft:bookshelf
setblock 1 264 467 minecraft:bookshelf
setblock 1 264 474 minecraft:bookshelf
setblock 1 264 481 minecraft:bookshelf
setblock 1 264 488 minecraft:bookshelf
setblock 1 264 495 minecraft:bookshelf
setblock 1 264 502 minecraft:bookshelf
fill 2 264 495 3 264 495 minecraft:gold_block
setblock 5 264 464 minecraft:bookshelf
setblock 6 264 504 minecraft:bookshelf
setblock 12 264 464 minecraft:bookshelf
setblock 13 264 504 minecraft:bookshelf
fill 18 264 465 22 264 466 minecraft:bookshelf
setblock 20 264 504 minecraft:bookshelf
fill 21 264 464 22 265 464 minecraft:bookshelf
setblock 26 264 464 minecraft:bookshelf
setblock 27 264 504 minecraft:bookshelf
setblock 33 264 464 minecraft:bookshelf
setblock 34 264 504 minecraft:bookshelf
setblock 40 264 464 minecraft:bookshelf
setblock 41 264 470 minecraft:bookshelf
setblock 41 264 477 minecraft:bookshelf
setblock 41 264 484 minecraft:bookshelf
setblock 41 264 491 minecraft:bookshelf
setblock 41 264 498 minecraft:bookshelf
setblock 41 264 504 minecraft:bookshelf
setblock 1 265 468 minecraft:bookshelf
setblock 1 265 475 minecraft:bookshelf
setblock 1 265 482 minecraft:bookshelf
setblock 1 265 489 minecraft:bookshelf
setblock 1 265 496 minecraft:bookshelf
setblock 1 265 503 minecraft:bookshelf
setblock 3 265 466 minecraft:light[level=12]
setblock 3 265 474 minecraft:light[level=12]
setblock 3 265 482 minecraft:light[level=12]
setblock 3 265 490 minecraft:light[level=12]
setblock 3 265 498 minecraft:light[level=12]
setblock 4 265 464 minecraft:bookshelf
setblock 5 265 496 minecraft:ochre_froglight
setblock 7 265 504 minecraft:bookshelf
setblock 11 265 464 minecraft:bookshelf
setblock 11 265 466 minecraft:light[level=12]
setblock 11 265 474 minecraft:light[level=12]
setblock 11 265 482 minecraft:light[level=12]
setblock 11 265 490 minecraft:light[level=12]
setblock 11 265 498 minecraft:light[level=12]
fill 14 265 478 16 266 478 minecraft:white_wool
setblock 14 265 504 minecraft:bookshelf
fill 15 265 477 15 266 477 minecraft:white_wool
fill 15 265 479 15 266 479 minecraft:white_wool
setblock 18 265 464 minecraft:bookshelf
setblock 19 265 466 minecraft:light[level=12]
setblock 19 265 474 minecraft:light[level=12]
setblock 19 265 482 minecraft:light[level=12]
setblock 19 265 490 minecraft:light[level=12]
setblock 19 265 498 minecraft:light[level=12]
fill 21 265 465 25 265 466 minecraft:bookshelf
setblock 21 265 504 minecraft:bookshelf
setblock 23 265 464 minecraft:bookshelf
fill 25 265 464 25 266 464 minecraft:bookshelf
setblock 27 265 466 minecraft:light[level=12]
setblock 27 265 474 minecraft:light[level=12]
setblock 27 265 482 minecraft:light[level=12]
setblock 27 265 490 minecraft:light[level=12]
setblock 27 265 498 minecraft:light[level=12]
setblock 28 265 504 minecraft:bookshelf
setblock 32 265 464 minecraft:bookshelf
setblock 35 265 466 minecraft:light[level=12]
setblock 35 265 474 minecraft:light[level=12]
setblock 35 265 482 minecraft:light[level=12]
setblock 35 265 490 minecraft:light[level=12]
setblock 35 265 498 minecraft:light[level=12]
setblock 35 265 504 minecraft:bookshelf
setblock 39 265 464 minecraft:bookshelf
setblock 41 265 469 minecraft:bookshelf
setblock 41 265 476 minecraft:bookshelf
setblock 41 265 483 minecraft:bookshelf
setblock 41 265 490 minecraft:bookshelf
setblock 41 265 497 minecraft:bookshelf
fill 24 266 465 28 266 466 minecraft:bookshelf
fill 26 266 464 29 266 464 minecraft:bookshelf
fill 30 266 480 32 267 480 minecraft:red_wool
fill 31 266 479 31 268 479 minecraft:red_wool
setblock 1 267 470 minecraft:bookshelf
setblock 1 267 477 minecraft:bookshelf
setblock 1 267 484 minecraft:bookshelf
setblock 1 267 491 minecraft:bookshelf
setblock 1 267 498 minecraft:bookshelf
setblock 2 267 464 minecraft:bookshelf
setblock 2 267 504 minecraft:bookshelf
setblock 9 267 464 minecraft:bookshelf
setblock 9 267 504 minecraft:bookshelf
setblock 16 267 464 minecraft:bookshelf
setblock 16 267 504 minecraft:bookshelf
setblock 23 267 464 minecraft:bookshelf
setblock 23 267 504 minecraft:bookshelf
fill 27 267 465 32 267 466 minecraft:bookshelf
fill 28 267 464 30 267 464 minecraft:bookshelf
fill 30 267 478 30 268 479 minecraft:red_wool
setblock 30 267 504 minecraft:bookshelf
fill 31 267 478 31 268 478 minecraft:red_wool
fill 32 267 464 33 268 464 minecraft:bookshelf
fill 37 267 464 37 270 464 minecraft:bookshelf
setblock 37 267 504 minecraft:bookshelf
setblock 41 267 467 minecraft:bookshelf
setblock 41 267 474 minecraft:bookshelf
setblock 41 267 481 minecraft:bookshelf
setblock 41 267 488 minecraft:bookshelf
setblock 41 267 495 minecraft:bookshelf
setblock 41 267 502 minecraft:bookshelf
setblock 1 268 464 minecraft:bookshelf
setblock 1 268 471 minecraft:bookshelf
setblock 1 268 478 minecraft:bookshelf
setblock 1 268 485 minecraft:bookshelf
setblock 1 268 492 minecraft:bookshelf
setblock 1 268 499 minecraft:bookshelf
setblock 3 268 504 minecraft:bookshelf
setblock 8 268 464 minecraft:bookshelf
setblock 10 268 504 minecraft:bookshelf
setblock 15 268 464 minecraft:bookshelf
setblock 17 268 504 minecraft:bookshelf
setblock 22 268 464 minecraft:bookshelf
setblock 24 268 504 minecraft:bookshelf
setblock 29 268 464 minecraft:bookshelf
fill 30 268 466 36 268 466 minecraft:bookshelf
fill 31 268 465 37 268 465 minecraft:bookshelf
setblock 31 268 504 minecraft:bookshelf
fill 34 268 464 36 268 464 minecraft:bookshelf
setblock 38 268 504 minecraft:bookshelf
fill 41 268 466 41 270 466 minecraft:bookshelf
setblock 41 268 473 minecraft:bookshelf
setblock 41 268 480 minecraft:bookshelf
setblock 41 268 487 minecraft:bookshelf
setblock 41 268 494 minecraft:bookshelf
setblock 41 268 501 minecraft:bookshelf
fill 1 269 465 1 270 465 minecraft:bookshelf
fill 1 269 472 1 270 472 minecraft:bookshelf
fill 1 269 479 1 270 479 minecraft:bookshelf
fill 1 269 486 1 270 486 minecraft:bookshelf
fill 1 269 493 1 270 493 minecraft:bookshelf
fill 1 269 500 1 270 500 minecraft:bookshelf
fill 4 269 504 4 270 504 minecraft:bookshelf
fill 7 269 464 7 270 464 minecraft:bookshelf
fill 11 269 504 11 270 504 minecraft:bookshelf
fill 14 269 464 14 270 464 minecraft:bookshelf
fill 18 269 504 18 270 504 minecraft:bookshelf
fill 21 269 464 21 270 464 minecraft:bookshelf
fill 25 269 504 25 270 504 minecraft:bookshelf
fill 28 269 464 28 270 464 minecraft:bookshelf
fill 32 269 504 32 270 504 minecraft:bookshelf
fill 34 269 466 40 269 466 minecraft:bookshelf
fill 35 269 464 36 269 465 minecraft:bookshelf
fill 37 269 465 41 269 465 minecraft:bookshelf
fill 39 269 464 41 270 464 minecraft:bookshelf
fill 39 269 467 39 270 468 minecraft:bookshelf
fill 39 269 504 39 270 504 minecraft:bookshelf
fill 40 269 467 40 270 467 minecraft:bookshelf
fill 41 269 472 41 271 472 minecraft:bookshelf
fill 41 269 479 41 270 479 minecraft:bookshelf
fill 41 269 486 41 270 486 minecraft:bookshelf
fill 41 269 493 41 270 493 minecraft:bookshelf
fill 41 269 500 41 270 500 minecraft:bookshelf
fill 1 270 464 2 270 464 minecraft:bookshelf
fill 1 270 466 1 270 468 minecraft:bookshelf
fill 1 270 470 1 270 471 minecraft:bookshelf
fill 1 270 473 1 270 475 minecraft:bookshelf
fill 1 270 477 1 270 478 minecraft:bookshelf
fill 1 270 480 1 270 482 minecraft:bookshelf
fill 1 270 484 1 270 485 minecraft:bookshelf
fill 1 270 487 1 270 489 minecraft:bookshelf
fill 1 270 491 1 270 492 minecraft:bookshelf
fill 1 270 494 1 270 496 minecraft:bookshelf
fill 1 270 498 1 270 499 minecraft:bookshelf
fill 1 270 501 1 270 503 minecraft:bookshelf
fill 2 270 504 3 270 504 minecraft:bookshelf
fill 4 270 464 6 270 464 minecraft:bookshelf
fill 5 270 504 7 270 504 minecraft:bookshelf
fill 8 270 464 9 270 464 minecraft:bookshelf
fill 9 270 504 10 270 504 minecraft:bookshelf
fill 10 270 483 10 272 483 minecraft:purple_stained_glass
fill 10 270 484 10 273 484 minecraft:dark_oak_planks
fill 10 270 485 10 273 489 minecraft:purple_stained_glass
fill 10 270 490 10 273 490 minecraft:dark_oak_planks
fill 10 270 491 10 272 491 minecraft:purple_stained_glass
fill 11 270 464 13 270 464 minecraft:bookshelf
fill 11 270 481 11 272 482 minecraft:purple_stained_glass
fill 11 270 492 11 272 493 minecraft:purple_stained_glass
fill 12 270 480 12 273 480 minecraft:purple_stained_glass
fill 12 270 494 12 273 494 minecraft:purple_stained_glass
fill 12 270 504 14 270 504 minecraft:bookshelf
fill 13 270 479 13 273 479 minecraft:dark_oak_planks
fill 13 270 495 13 273 495 minecraft:dark_oak_planks
fill 14 270 478 14 273 478 minecraft:purple_stained_glass
fill 14 270 496 14 273 496 minecraft:purple_stained_glass
fill 15 270 464 16 270 464 minecraft:bookshelf
fill 15 270 477 16 272 477 minecraft:purple_stained_glass
fill 15 270 497 16 272 497 minecraft:purple_stained_glass
fill 16 270 504 17 270 504 minecraft:bookshelf
fill 17 270 476 17 272 476 minecraft:purple_stained_glass
fill 17 270 498 17 272 498 minecraft:purple_stained_glass
fill 18 270 464 20 270 464 minecraft:bookshelf
fill 18 270 476 18 273 476 minecraft:dark_oak_planks
fill 18 270 498 18 273 498 minecraft:dark_oak_planks
fill 19 270 476 23 273 476 minecraft:purple_stained_glass
fill 19 270 498 23 273 498 minecraft:purple_stained_glass
fill 19 270 504 21 270 504 minecraft:bookshelf
fill 22 270 464 23 270 464 minecraft:bookshelf
fill 23 270 504 24 270 504 minecraft:bookshelf
fill 24 270 476 24 273 476 minecraft:dark_oak_planks
fill 24 270 498 24 273 498 minecraft:dark_oak_planks
fill 25 270 464 27 270 464 minecraft:bookshelf
fill 25 270 476 25 272 476 minecraft:purple_stained_glass
fill 25 270 498 25 272 498 minecraft:purple_stained_glass
fill 26 270 477 27 272 477 minecraft:purple_stained_glass
fill 26 270 497 27 272 497 minecraft:purple_stained_glass
fill 26 270 504 28 270 504 minecraft:bookshelf
fill 28 270 478 28 273 478 minecraft:purple_stained_glass
fill 28 270 496 28 273 496 minecraft:purple_stained_glass
fill 29 270 464 30 270 464 minecraft:bookshelf
fill 29 270 479 29 273 479 minecraft:dark_oak_planks
fill 29 270 495 29 273 495 minecraft:dark_oak_planks
fill 30 270 480 30 273 480 minecraft:purple_stained_glass
fill 30 270 494 30 273 494 minecraft:purple_stained_glass
fill 30 270 504 31 270 504 minecraft:bookshelf
fill 31 270 481 31 272 482 minecraft:purple_stained_glass
fill 31 270 492 31 272 493 minecraft:purple_stained_glass
fill 32 270 464 36 270 464 minecraft:bookshelf
setblock 32 270 468 minecraft:ochre_froglight
fill 32 270 483 32 272 483 minecraft:purple_stained_glass
fill 32 270 484 32 273 484 minecraft:dark_oak_planks
fill 32 270 485 32 273 489 minecraft:purple_stained_glass
fill 32 270 490 32 273 490 minecraft:dark_oak_planks
fill 32 270 491 32 272 491 minecraft:purple_stained_glass
fill 33 270 504 35 270 504 minecraft:bookshelf
fill 37 270 504 38 270 504 minecraft:bookshelf
fill 39 270 466 40 270 466 minecraft:bookshelf
fill 39 270 469 40 270 472 minecraft:bookshelf
fill 40 270 465 41 270 465 minecraft:bookshelf
setblock 40 270 468 minecraft:bookshelf
fill 40 270 504 41 270 504 minecraft:bookshelf
setblock 41 270 467 minecraft:bookshelf
fill 41 270 469 41 271 471 minecraft:bookshelf
fill 41 270 473 41 271 474 minecraft:bookshelf
fill 41 270 476 41 270 478 minecraft:bookshelf
fill 41 270 480 41 270 481 minecraft:bookshelf
fill 41 270 483 41 270 485 minecraft:bookshelf
fill 41 270 487 41 270 488 minecraft:bookshelf
fill 41 270 490 41 270 492 minecraft:bookshelf
fill 41 270 494 41 270 495 minecraft:bookshelf
fill 41 270 497 41 270 499 minecraft:bookshelf
fill 41 270 501 41 270 502 minecraft:bookshelf
setblock 1 271 467 minecraft:bookshelf
setblock 1 271 474 minecraft:bookshelf
setblock 1 271 481 minecraft:bookshelf
setblock 1 271 488 minecraft:bookshelf
setblock 1 271 495 minecraft:bookshelf
setblock 1 271 502 minecraft:bookshelf
setblock 5 271 464 minecraft:bookshelf
setblock 6 271 504 minecraft:bookshelf
setblock 12 271 464 minecraft:bookshelf
fill 12 271 481 12 274 481 minecraft:purple_stained_glass
fill 12 271 493 12 274 493 minecraft:purple_stained_glass
setblock 13 271 504 minecraft:bookshelf
fill 15 271 478 15 274 478 minecraft:purple_stained_glass
fill 15 271 496 15 274 496 minecraft:purple_stained_glass
setblock 19 271 464 minecraft:bookshelf
setblock 20 271 504 minecraft:bookshelf
setblock 26 271 464 minecraft:bookshelf
fill 27 271 478 27 274 478 minecraft:purple_stained_glass
fill 27 271 496 27 274 496 minecraft:purple_stained_glass
setblock 27 271 504 minecraft:bookshelf
fill 30 271 481 30 274 481 minecraft:purple_stained_glass
fill 30 271 493 30 274 493 minecraft:purple_stained_glass
setblock 33 271 464 minecraft:bookshelf
setblock 34 271 504 minecraft:bookshelf
fill 39 271 471 40 271 476 minecraft:bookshelf
setblock 40 271 464 minecraft:bookshelf
setblock 40 271 470 minecraft:bookshelf
fill 41 271 477 41 272 477 minecraft:bookshelf
setblock 41 271 484 minecraft:bookshelf
setblock 41 271 491 minecraft:bookshelf
setblock 41 271 498 minecraft:bookshelf
setblock 41 271 504 minecraft:bookshelf
setblock 1 272 468 minecraft:bookshelf
setblock 1 272 475 minecraft:bookshelf
setblock 1 272 482 minecraft:bookshelf
setblock 1 272 489 minecraft:bookshelf
setblock 1 272 496 minecraft:bookshelf
setblock 1 272 503 minecraft:bookshelf
setblock 4 272 464 minecraft:bookshelf
setblock 7 272 504 minecraft:bookshelf
setblock 11 272 464 minecraft:bookshelf
fill 11 272 483 11 274 483 minecraft:purple_stained_glass
fill 11 272 491 11 274 491 minecraft:purple_stained_glass
fill 13 272 480 13 275 480 minecraft:purple_stained_glass
fill 13 272 494 13 275 494 minecraft:purple_stained_glass
fill 14 272 479 14 275 479 minecraft:purple_stained_glass
fill 14 272 495 14 275 495 minecraft:purple_stained_glass
setblock 14 272 504 minecraft:bookshelf
fill 17 272 477 17 274 477 minecraft:purple_stained_glass
fill 17 272 497 17 274 497 minecraft:purple_stained_glass
setblock 18 272 464 minecraft:bookshelf
setblock 21 272 504 minecraft:bookshelf
setblock 25 272 464 minecraft:bookshelf
fill 25 272 477 25 274 477 minecraft:purple_stained_glass
fill 25 272 497 25 274 497 minecraft:purple_stained_glass
fill 28 272 479 28 275 479 minecraft:purple_stained_glass
fill 28 272 495 28 275 495 minecraft:purple_stained_glass
setblock 28 272 504 minecraft:bookshelf
fill 29 272 480 29 275 480 minecraft:purple_stained_glass
fill 29 272 494 29 275 494 minecraft:purple_stained_glass
fill 31 272 483 31 274 483 minecraft:purple_stained_glass
fill 31 272 491 31 274 491 minecraft:purple_stained_glass
setblock 32 272 464 minecraft:bookshelf
setblock 35 272 504 minecraft:bookshelf
setblock 39 272 464 minecraft:bookshelf
fill 39 272 475 40 272 479 minecraft:bookshelf
fill 40 272 474 41 272 474 minecraft:bookshelf
setblock 41 272 469 minecraft:bookshelf
setblock 41 272 476 minecraft:bookshelf
fill 41 272 478 41 273 479 minecraft:bookshelf
setblock 41 272 483 minecraft:bookshelf
setblock 41 272 490 minecraft:bookshelf
setblock 41 272 497 minecraft:bookshelf
setblock 3 273 466 minecraft:light[level=12]
setblock 3 273 474 minecraft:light[level=12]
setblock 3 273 482 minecraft:light[level=12]
setblock 3 273 490 minecraft:light[level=12]
setblock 3 273 498 minecraft:light[level=12]
setblock 11 273 466 minecraft:light[level=12]
setblock 11 273 474 minecraft:light[level=12]
setblock 11 273 482 minecraft:purple_stained_glass
fill 11 273 484 11 275 484 minecraft:dark_oak_planks
fill 11 273 490 11 275 490 minecraft:dark_oak_planks
setblock 11 273 492 minecraft:purple_stained_glass
setblock 11 273 498 minecraft:light[level=12]
setblock 16 273 477 minecraft:purple_stained_glass
setblock 16 273 497 minecraft:purple_stained_glass
fill 18 273 477 18 275 477 minecraft:dark_oak_planks
fill 18 273 497 18 275 497 minecraft:dark_oak_planks
setblock 19 273 466 minecraft:light[level=12]
setblock 19 273 474 minecraft:light[level=12]
setblock 19 273 482 minecraft:light[level=12]
setblock 19 273 490 minecraft:light[level=12]
fill 24 273 477 24 275 477 minecraft:dark_oak_planks
fill 24 273 497 24 275 497 minecraft:dark_oak_planks
setblock 26 273 477 minecraft:purple_stained_glass
setblock 26 273 497 minecraft:purple_stained_glass
setblock 27 273 466 minecraft:light[level=12]
setblock 27 273 474 minecraft:light[level=12]
setblock 27 273 482 minecraft:light[level=12]
setblock 27 273 490 minecraft:light[level=12]
setblock 27 273 498 minecraft:light[level=12]
setblock 31 273 482 minecraft:purple_stained_glass
fill 31 273 484 31 275 484 minecraft:dark_oak_planks
fill 31 273 490 31 275 490 minecraft:dark_oak_planks
setblock 31 273 492 minecraft:purple_stained_glass
setblock 35 273 466 minecraft:light[level=12]
setblock 35 273 474 minecraft:light[level=12]
setblock 35 273 482 minecraft:light[level=12]
setblock 35 273 490 minecraft:light[level=12]
setblock 35 273 498 minecraft:light[level=12]
fill 39 273 478 40 273 482 minecraft:bookshelf
fill 41 273 480 41 273 481 minecraft:bookshelf
fill 10 274 486 11 274 488 minecraft:purple_stained_glass
fill 11 274 485 11 275 485 minecraft:purple_stained_glass
fill 11 274 489 11 275 489 minecraft:purple_stained_glass
fill 12 274 482 12 275 482 minecraft:purple_stained_glass
fill 12 274 492 12 275 492 minecraft:purple_stained_glass
fill 13 274 481 13 276 481 minecraft:purple_stained_glass
fill 13 274 493 13 276 493 minecraft:purple_stained_glass
fill 15 274 479 15 276 479 minecraft:purple_stained_glass
fill 15 274 495 15 276 495 minecraft:purple_stained_glass
fill 16 274 478 16 275 478 minecraft:purple_stained_glass
fill 16 274 496 16 275 496 minecraft:purple_stained_glass
fill 19 274 477 23 275 477 minecraft:purple_stained_glass
fill 19 274 497 23 275 497 minecraft:purple_stained_glass
fill 20 274 476 22 274 476 minecraft:purple_stained_glass
fill 20 274 498 22 274 498 minecraft:purple_stained_glass
fill 26 274 478 26 275 478 minecraft:purple_stained_glass
fill 26 274 496 26 275 496 minecraft:purple_stained_glass
fill 27 274 479 27 276 479 minecraft:purple_stained_glass
fill 27 274 495 27 276 495 minecraft:purple_stained_glass
fill 29 274 481 29 276 481 minecraft:purple_stained_glass
fill 29 274 493 29 276 493 minecraft:purple_stained_glass
fill 30 274 482 30 275 482 minecraft:purple_stained_glass
fill 30 274 492 30 275 492 minecraft:purple_stained_glass
fill 31 274 485 31 275 489 minecraft:purple_stained_glass
fill 32 274 486 32 274 488 minecraft:purple_stained_glass
fill 11 275 486 11 276 488 minecraft:purple_stained_glass
fill 12 275 483 12 276 484 minecraft:purple_stained_glass
fill 12 275 490 12 276 491 minecraft:purple_stained_glass
fill 13 275 482 13 276 482 minecraft:purple_stained_glass
fill 13 275 492 13 276 492 minecraft:purple_stained_glass
fill 14 275 480 14 276 480 minecraft:dark_oak_planks
fill 14 275 494 14 276 494 minecraft:dark_oak_planks
fill 16 275 479 16 276 479 minecraft:purple_stained_glass
fill 16 275 495 16 276 495 minecraft:purple_stained_glass
fill 17 275 478 18 276 478 minecraft:purple_stained_glass
fill 17 275 496 18 276 496 minecraft:purple_stained_glass
fill 24 275 478 25 276 478 minecraft:purple_stained_glass
fill 24 275 496 25 276 496 minecraft:purple_stained_glass
fill 26 275 479 26 276 479 minecraft:purple_stained_glass
fill 26 275 495 26 276 495 minecraft:purple_stained_glass
fill 28 275 480 28 276 480 minecraft:dark_oak_planks
fill 28 275 494 28 276 494 minecraft:dark_oak_planks
fill 29 275 482 29 276 482 minecraft:purple_stained_glass
fill 29 275 492 29 276 492 minecraft:purple_stained_glass
fill 30 275 483 30 276 484 minecraft:purple_stained_glass
fill 30 275 490 30 276 491 minecraft:purple_stained_glass
fill 12 276 485 12 277 489 minecraft:purple_stained_glass
fill 13 276 483 13 277 483 minecraft:purple_stained_glass
fill 13 276 491 13 277 491 minecraft:purple_stained_glass
fill 14 276 481 14 277 481 minecraft:purple_stained_glass
fill 14 276 493 14 277 493 minecraft:purple_stained_glass
fill 15 276 480 15 277 480 minecraft:purple_stained_glass
fill 15 276 494 15 277 494 minecraft:purple_stained_glass
fill 17 276 479 17 277 479 minecraft:purple_stained_glass
fill 17 276 495 17 277 495 minecraft:purple_stained_glass
fill 19 276 478 23 277 478 minecraft:purple_stained_glass
fill 19 276 496 23 277 496 minecraft:purple_stained_glass
fill 20 276 477 22 276 477 minecraft:purple_stained_glass
fill 20 276 497 22 276 497 minecraft:purple_stained_glass
fill 25 276 479 25 277 479 minecraft:purple_stained_glass
fill 25 276 495 25 277 495 minecraft:purple_stained_glass
fill 27 276 480 27 277 480 minecraft:purple_stained_glass
fill 27 276 494 27 277 494 minecraft:purple_stained_glass
fill 28 276 481 28 277 481 minecraft:purple_stained_glass
fill 28 276 493 28 277 493 minecraft:purple_stained_glass
fill 29 276 483 29 277 483 minecraft:purple_stained_glass
fill 29 276 491 29 277 491 minecraft:purple_stained_glass
fill 30 276 485 30 277 489 minecraft:purple_stained_glass
fill 31 276 486 31 276 488 minecraft:purple_stained_glass
setblock 13 277 484 minecraft:purple_stained_glass
fill 13 277 485 13 278 485 minecraft:dark_oak_planks
fill 13 277 486 13 278 488 minecraft:purple_stained_glass
fill 13 277 489 13 278 489 minecraft:dark_oak_planks
setblock 13 277 490 minecraft:purple_stained_glass
fill 14 277 482 14 277 483 minecraft:purple_stained_glass
fill 14 277 491 14 277 492 minecraft:purple_stained_glass
setblock 15 277 481 minecraft:dark_oak_planks
setblock 15 277 493 minecraft:dark_oak_planks
fill 16 277 480 17 277 480 minecraft:purple_stained_glass
fill 16 277 494 17 277 494 minecraft:purple_stained_glass
setblock 18 277 479 minecraft:purple_stained_glass
setblock 18 277 495 minecraft:purple_stained_glass
fill 19 277 479 19 278 479 minecraft:dark_oak_planks
fill 19 277 495 19 278 495 minecraft:dark_oak_planks
fill 20 277 479 22 278 479 minecraft:purple_stained_glass
fill 20 277 495 22 278 495 minecraft:purple_stained_glass
fill 23 277 479 23 278 479 minecraft:dark_oak_planks
fill 23 277 495 23 278 495 minecraft:dark_oak_planks
setblock 24 277 479 minecraft:purple_stained_glass
setblock 24 277 495 minecraft:purple_stained_glass
fill 25 277 480 26 277 480 minecraft:purple_stained_glass
fill 25 277 494 26 277 494 minecraft:purple_stained_glass
setblock 27 277 481 minecraft:dark_oak_planks
setblock 27 277 493 minecraft:dark_oak_planks
fill 28 277 482 28 277 483 minecraft:purple_stained_glass
fill 28 277 491 28 277 492 minecraft:purple_stained_glass
setblock 29 277 484 minecraft:purple_stained_glass
fill 29 277 485 29 278 485 minecraft:dark_oak_planks
fill 29 277 486 29 278 488 minecraft:purple_stained_glass
fill 29 277 489 29 278 489 minecraft:dark_oak_planks
setblock 29 277 490 minecraft:purple_stained_glass
fill 14 278 483 14 278 484 minecraft:purple_stained_glass
fill 14 278 485 14 279 485 minecraft:dark_oak_planks
fill 14 278 486 14 280 488 minecraft:purple_stained_glass
fill 14 278 489 14 279 489 minecraft:dark_oak_planks
fill 14 278 490 14 278 491 minecraft:purple_stained_glass
fill 15 278 482 15 278 483 minecraft:purple_stained_glass
fill 15 278 491 15 278 492 minecraft:purple_stained_glass
fill 16 278 481 17 278 481 minecraft:purple_stained_glass
fill 16 278 482 16 279 482 minecraft:dark_oak_planks
fill 16 278 492 16 279 492 minecraft:dark_oak_planks
fill 16 278 493 17 278 493 minecraft:purple_stained_glass
fill 17 278 480 18 278 480 minecraft:purple_stained_glass
fill 17 278 494 18 278 494 minecraft:purple_stained_glass
fill 19 278 480 19 279 480 minecraft:dark_oak_planks
fill 19 278 494 19 279 494 minecraft:dark_oak_planks
fill 20 278 480 22 280 480 minecraft:purple_stained_glass
fill 20 278 494 22 280 494 minecraft:purple_stained_glass
fill 23 278 480 23 279 480 minecraft:dark_oak_planks
fill 23 278 494 23 279 494 minecraft:dark_oak_planks
fill 24 278 480 25 278 480 minecraft:purple_stained_glass
fill 24 278 494 25 278 494 minecraft:purple_stained_glass
fill 25 278 481 26 278 481 minecraft:purple_stained_glass
fill 25 278 493 26 278 493 minecraft:purple_stained_glass
fill 26 278 482 26 279 482 minecraft:dark_oak_planks
fill 26 278 492 26 279 492 minecraft:dark_oak_planks
fill 27 278 482 27 278 483 minecraft:purple_stained_glass
fill 27 278 491 27 278 492 minecraft:purple_stained_glass
fill 28 278 483 28 278 484 minecraft:purple_stained_glass
fill 28 278 485 28 279 485 minecraft:dark_oak_planks
fill 28 278 486 28 280 488 minecraft:purple_stained_glass
fill 28 278 489 28 279 489 minecraft:dark_oak_planks
fill 28 278 490 28 278 491 minecraft:purple_stained_glass
fill 15 279 483 15 280 491 minecraft:purple_stained_glass
fill 16 279 483 16 280 485 minecraft:purple_stained_glass
fill 16 279 489 16 280 491 minecraft:purple_stained_glass
fill 17 279 481 19 280 482 minecraft:purple_stained_glass
setblock 17 279 483 minecraft:dark_oak_planks
setblock 17 279 491 minecraft:dark_oak_planks
fill 17 279 492 19 280 493 minecraft:purple_stained_glass
fill 20 279 481 25 280 481 minecraft:purple_stained_glass
fill 20 279 493 25 280 493 minecraft:purple_stained_glass
fill 23 279 482 25 280 482 minecraft:purple_stained_glass
fill 23 279 492 25 280 492 minecraft:purple_stained_glass
setblock 25 279 483 minecraft:dark_oak_planks
setblock 25 279 491 minecraft:dark_oak_planks
fill 26 279 483 27 280 485 minecraft:purple_stained_glass
fill 26 279 489 27 280 491 minecraft:purple_stained_glass
fill 27 279 486 27 280 488 minecraft:purple_stained_glass
fill 1 280 464 11 280 504 minecraft:dark_oak_planks
fill 12 280 464 12 280 483 minecraft:dark_oak_planks
fill 12 280 484 13 280 490 minecraft:purple_stained_glass
fill 12 280 491 12 280 504 minecraft:dark_oak_planks
fill 13 280 464 13 280 481 minecraft:dark_oak_planks
fill 13 280 482 14 280 483 minecraft:purple_stained_glass
fill 13 280 491 14 280 492 minecraft:purple_stained_glass
fill 13 280 493 13 280 504 minecraft:dark_oak_planks
fill 14 280 464 14 280 480 minecraft:dark_oak_planks
fill 14 280 481 16 280 481 minecraft:purple_stained_glass
fill 14 280 484 14 280 485 minecraft:purple_stained_glass
fill 14 280 489 14 280 490 minecraft:purple_stained_glass
fill 14 280 493 16 280 493 minecraft:purple_stained_glass
fill 14 280 494 14 280 504 minecraft:dark_oak_planks
fill 15 280 464 15 280 479 minecraft:dark_oak_planks
fill 15 280 480 19 280 480 minecraft:purple_stained_glass
fill 15 280 482 16 280 482 minecraft:purple_stained_glass
fill 15 280 492 16 280 492 minecraft:purple_stained_glass
fill 15 280 494 19 280 494 minecraft:purple_stained_glass
fill 15 280 495 15 280 504 minecraft:dark_oak_planks
fill 16 280 464 17 280 478 minecraft:dark_oak_planks
fill 16 280 479 26 280 479 minecraft:purple_stained_glass
fill 16 280 486 17 280 488 minecraft:purple_stained_glass
fill 16 280 495 26 280 495 minecraft:purple_stained_glass
fill 16 280 496 17 280 504 minecraft:dark_oak_planks
fill 17 280 483 17 280 485 minecraft:purple_stained_glass
fill 17 280 489 17 280 491 minecraft:purple_stained_glass
fill 18 280 464 41 280 477 minecraft:dark_oak_planks
fill 18 280 478 24 280 478 minecraft:purple_stained_glass
fill 18 280 483 18 280 484 minecraft:purple_stained_glass
fill 18 280 485 18 280 489 minecraft:ochre_froglight
fill 18 280 490 18 280 491 minecraft:purple_stained_glass
fill 18 280 496 24 280 496 minecraft:purple_stained_glass
fill 18 280 497 41 280 504 minecraft:dark_oak_planks
fill 19 280 483 25 280 483 minecraft:purple_stained_glass
fill 19 280 484 19 280 485 minecraft:ochre_froglight
fill 19 280 489 19 280 490 minecraft:ochre_froglight
fill 19 280 491 25 280 491 minecraft:purple_stained_glass
fill 20 280 482 22 280 482 minecraft:purple_stained_glass
fill 20 280 484 23 280 484 minecraft:ochre_froglight
fill 20 280 490 23 280 490 minecraft:ochre_froglight
fill 20 280 492 22 280 492 minecraft:purple_stained_glass
fill 23 280 480 27 280 480 minecraft:purple_stained_glass
fill 23 280 485 24 280 485 minecraft:ochre_froglight
fill 23 280 489 24 280 489 minecraft:ochre_froglight
fill 23 280 494 27 280 494 minecraft:purple_stained_glass
fill 24 280 484 25 280 484 minecraft:purple_stained_glass
fill 24 280 486 24 280 488 minecraft:ochre_froglight
fill 24 280 490 25 280 490 minecraft:purple_stained_glass
fill 25 280 478 41 280 478 minecraft:dark_oak_planks
fill 25 280 485 25 280 489 minecraft:purple_stained_glass
fill 25 280 496 41 280 496 minecraft:dark_oak_planks
fill 26 280 481 28 280 482 minecraft:purple_stained_glass
fill 26 280 486 26 280 488 minecraft:purple_stained_glass
fill 26 280 492 28 280 493 minecraft:purple_stained_glass
fill 27 280 479 41 280 479 minecraft:dark_oak_planks
fill 27 280 495 41 280 495 minecraft:dark_oak_planks
fill 28 280 480 41 280 480 minecraft:dark_oak_planks
fill 28 280 483 29 280 485 minecraft:purple_stained_glass
fill 28 280 489 29 280 491 minecraft:purple_stained_glass
fill 28 280 494 41 280 494 minecraft:dark_oak_planks
fill 29 280 481 41 280 481 minecraft:dark_oak_planks
setblock 29 280 482 minecraft:purple_stained_glass
fill 29 280 486 30 280 488 minecraft:purple_stained_glass
setblock 29 280 492 minecraft:purple_stained_glass
fill 29 280 493 41 280 493 minecraft:dark_oak_planks
fill 30 280 482 41 280 483 minecraft:dark_oak_planks
fill 30 280 484 30 280 485 minecraft:purple_stained_glass
fill 30 280 489 30 280 490 minecraft:purple_stained_glass
fill 30 280 491 41 280 492 minecraft:dark_oak_planks
fill 31 280 484 41 280 490 minecraft:dark_oak_planks
setblock 3 281 466 minecraft:light[level=12]
setblock 3 281 474 minecraft:light[level=12]
setblock 3 281 482 minecraft:light[level=12]
setblock 3 281 490 minecraft:light[level=12]
setblock 3 281 498 minecraft:light[level=12]
setblock 11 281 466 minecraft:light[level=12]
setblock 11 281 474 minecraft:light[level=12]
setblock 11 281 482 minecraft:light[level=12]
setblock 11 281 490 minecraft:light[level=12]
setblock 11 281 498 minecraft:light[level=12]
fill 18 281 486 18 281 488 minecraft:purple_stained_glass
setblock 19 281 466 minecraft:light[level=12]
setblock 19 281 474 minecraft:light[level=12]
setblock 19 281 482 minecraft:light[level=12]
setblock 19 281 485 minecraft:dark_oak_planks
setblock 19 281 489 minecraft:dark_oak_planks
setblock 19 281 490 minecraft:light[level=12]
setblock 19 281 498 minecraft:light[level=12]
fill 20 281 484 22 281 484 minecraft:purple_stained_glass
fill 20 281 490 22 281 490 minecraft:purple_stained_glass
setblock 23 281 485 minecraft:dark_oak_planks
setblock 23 281 489 minecraft:dark_oak_planks
fill 24 281 486 24 281 488 minecraft:purple_stained_glass
setblock 27 281 466 minecraft:light[level=12]
setblock 27 281 474 minecraft:light[level=12]
setblock 27 281 482 minecraft:light[level=12]
setblock 27 281 490 minecraft:light[level=12]
setblock 27 281 498 minecraft:light[level=12]
setblock 35 281 466 minecraft:light[level=12]
setblock 35 281 474 minecraft:light[level=12]
setblock 35 281 482 minecraft:light[level=12]
setblock 35 281 490 minecraft:light[level=12]
setblock 35 281 498 minecraft:light[level=12]
fill 1 284 466 20 284 466 minecraft:bookshelf
fill 1 284 469 12 285 469 minecraft:bookshelf
setblock 1 284 473 minecraft:bookshelf
fill 1 284 476 1 300 476 minecraft:bookshelf
setblock 1 284 480 minecraft:bookshelf
fill 1 284 483 1 300 483 minecraft:bookshelf
fill 1 284 486 1 285 497 minecraft:bookshelf
setblock 1 284 501 minecraft:bookshelf
fill 1 284 504 1 300 504 minecraft:bookshelf
fill 2 284 464 20 285 465 minecraft:bookshelf
fill 2 284 467 12 285 468 minecraft:bookshelf
fill 2 284 470 12 285 472 minecraft:bookshelf
fill 2 284 486 7 285 496 minecraft:bookshelf
setblock 5 284 504 minecraft:bookshelf
fill 8 284 486 8 285 494 minecraft:bookshelf
fill 8 284 504 8 300 504 minecraft:bookshelf
setblock 12 284 504 minecraft:bookshelf
fill 13 284 467 20 285 467 minecraft:bookshelf
fill 14 284 496 26 285 504 minecraft:bookshelf
fill 20 284 495 26 285 495 minecraft:bookshelf
fill 24 284 464 24 300 464 minecraft:bookshelf
setblock 27 284 464 minecraft:bookshelf
fill 29 284 504 29 300 504 minecraft:bookshelf
fill 31 284 464 31 300 464 minecraft:bookshelf
fill 33 284 474 41 285 482 minecraft:bookshelf
setblock 33 284 504 minecraft:bookshelf
setblock 34 284 464 minecraft:bookshelf
fill 36 284 504 36 300 504 minecraft:bookshelf
fill 38 284 464 38 300 464 minecraft:bookshelf
fill 39 284 483 41 284 485 minecraft:bookshelf
setblock 40 284 504 minecraft:bookshelf
setblock 41 284 464 minecraft:bookshelf
fill 41 284 468 41 300 468 minecraft:bookshelf
setblock 41 284 471 minecraft:bookshelf
fill 41 284 489 41 300 489 minecraft:bookshelf
setblock 41 284 492 minecraft:bookshelf
fill 41 284 496 41 300 496 minecraft:bookshelf
setblock 41 284 499 minecraft:bookshelf
fill 41 284 503 41 300 503 minecraft:bookshelf
setblock 1 285 467 minecraft:bookshelf
setblock 1 285 474 minecraft:bookshelf
setblock 1 285 481 minecraft:bookshelf
setblock 1 285 502 minecraft:bookshelf
fill 2 285 466 20 285 466 minecraft:bookshelf
setblock 6 285 504 minecraft:bookshelf
setblock 13 285 504 minecraft:bookshelf
setblock 26 285 464 minecraft:bookshelf
setblock 27 285 504 minecraft:bookshelf
setblock 33 285 464 minecraft:bookshelf
setblock 34 285 504 minecraft:bookshelf
fill 39 285 484 41 285 488 minecraft:bookshelf
setblock 40 285 464 minecraft:bookshelf
setblock 41 285 470 minecraft:bookshelf
fill 41 285 491 41 287 491 minecraft:bookshelf
setblock 41 285 498 minecraft:bookshelf
setblock 41 285 504 minecraft:bookshelf
fill 1 286 468 1 286 469 minecraft:bookshelf
setblock 1 286 475 minecraft:bookshelf
setblock 1 286 482 minecraft:bookshelf
setblock 1 286 486 minecraft:ochre_froglight
fill 1 286 487 1 300 487 minecraft:bookshelf
setblock 1 286 488 minecraft:ochre_froglight
fill 1 286 489 1 300 489 minecraft:bookshelf
setblock 1 286 490 minecraft:ochre_froglight
fill 1 286 491 1 300 491 minecraft:bookshelf
setblock 1 286 492 minecraft:ochre_froglight
fill 1 286 493 1 300 493 minecraft:bookshelf
setblock 1 286 494 minecraft:ochre_froglight
fill 1 286 495 1 300 495 minecraft:bookshelf
setblock 1 286 496 minecraft:ochre_froglight
fill 1 286 497 1 300 497 minecraft:bookshelf
setblock 1 286 503 minecraft:bookshelf
fill 2 286 464 2 300 464 minecraft:bookshelf
setblock 2 286 465 minecraft:ochre_froglight
fill 2 286 466 2 300 466 minecraft:bookshelf
setblock 2 286 467 minecraft:ochre_froglight
fill 2 286 468 2 300 468 minecraft:bookshelf
setblock 2 286 469 minecraft:ochre_froglight
fill 2 286 470 2 300 470 minecraft:bookshelf
setblock 2 286 471 minecraft:ochre_froglight
fill 2 286 472 2 300 472 minecraft:bookshelf
fill 2 286 486 2 300 486 minecraft:bookshelf
setblock 2 286 487 minecraft:ochre_froglight
fill 2 286 488 2 300 488 minecraft:bookshelf
setblock 2 286 489 minecraft:ochre_froglight
fill 2 286 490 2 300 490 minecraft:bookshelf
setblock 2 286 491 minecraft:ochre_froglight
fill 2 286 492 2 300 492 minecraft:bookshelf
setblock 2 286 493 minecraft:ochre_froglight
fill 2 286 494 2 300 494 minecraft:bookshelf
setblock 2 286 495 minecraft:ochre_froglight
fill 2 286 496 2 300 496 minecraft:bookshelf
setblock 3 286 464 minecraft:ochre_froglight
fill 3 286 465 3 300 465 minecraft:bookshelf
setblock 3 286 466 minecraft:ochre_froglight
fill 3 286 467 3 300 467 minecraft:bookshelf
setblock 3 286 468 minecraft:ochre_froglight
fill 3 286 469 3 300 469 minecraft:bookshelf
setblock 3 286 470 minecraft:ochre_froglight
fill 3 286 471 3 300 471 minecraft:bookshelf
setblock 3 286 472 minecraft:ochre_froglight
setblock 3 286 486 minecraft:ochre_froglight
fill 3 286 487 3 300 487 minecraft:bookshelf
setblock 3 286 488 minecraft:ochre_froglight
fill 3 286 489 3 300 489 minecraft:bookshelf
setblock 3 286 490 minecraft:ochre_froglight
fill 3 286 491 3 300 491 minecraft:bookshelf
setblock 3 286 492 minecraft:ochre_froglight
fill 3 286 493 3 300 493 minecraft:bookshelf
setblock 3 286 494 minecraft:ochre_froglight
fill 3 286 495 3 300 495 minecraft:bookshelf
setblock 3 286 496 minecraft:ochre_froglight
fill 4 286 464 4 300 464 minecraft:bookshelf
setblock 4 286 465 minecraft:ochre_froglight
fill 4 286 466 4 300 466 minecraft:bookshelf
setblock 4 286 467 minecraft:ochre_froglight
fill 4 286 468 4 300 468 minecraft:bookshelf
setblock 4 286 469 minecraft:ochre_froglight
fill 4 286 470 4 300 470 minecraft:bookshelf
setblock 4 286 471 minecraft:ochre_froglight
fill 4 286 472 4 300 472 minecraft:bookshelf
fill 4 286 486 4 300 486 minecraft:bookshelf
setblock 4 286 487 minecraft:ochre_froglight
fill 4 286 488 4 300 488 minecraft:bookshelf
setblock 4 286 489 minecraft:ochre_froglight
fill 4 286 490 4 300 490 minecraft:bookshelf
setblock 4 286 491 minecraft:ochre_froglight
fill 4 286 492 4 300 492 minecraft:bookshelf
setblock 4 286 493 minecraft:ochre_froglight
fill 4 286 494 4 300 494 minecraft:bookshelf
setblock 4 286 495 minecraft:ochre_froglight
fill 4 286 496 4 300 496 minecraft:bookshelf
setblock 5 286 464 minecraft:ochre_froglight
fill 5 286 465 5 300 465 minecraft:bookshelf
setblock 5 286 466 minecraft:ochre_froglight
fill 5 286 467 5 300 467 minecraft:bookshelf
setblock 5 286 468 minecraft:ochre_froglight
fill 5 286 469 5 300 469 minecraft:bookshelf
setblock 5 286 470 minecraft:ochre_froglight
fill 5 286 471 5 300 471 minecraft:bookshelf
setblock 5 286 472 minecraft:ochre_froglight
setblock 5 286 486 minecraft:ochre_froglight
fill 5 286 487 5 300 487 minecraft:bookshelf
setblock 5 286 488 minecraft:ochre_froglight
fill 5 286 489 5 300 489 minecraft:bookshelf
setblock 5 286 490 minecraft:ochre_froglight
fill 5 286 491 5 300 491 minecraft:bookshelf
setblock 5 286 492 minecraft:ochre_froglight
fill 5 286 493 5 300 493 minecraft:bookshelf
setblock 5 286 494 minecraft:ochre_froglight
fill 5 286 495 5 300 495 minecraft:bookshelf
setblock 5 286 496 minecraft:ochre_froglight
fill 6 286 464 6 300 464 minecraft:bookshelf
setblock 6 286 465 minecraft:ochre_froglight
fill 6 286 466 6 300 466 minecraft:bookshelf
setblock 6 286 467 minecraft:ochre_froglight
fill 6 286 468 6 300 468 minecraft:bookshelf
setblock 6 286 469 minecraft:ochre_froglight
fill 6 286 470 6 300 470 minecraft:bookshelf
setblock 6 286 471 minecraft:ochre_froglight
fill 6 286 472 6 300 472 minecraft:bookshelf
fill 6 286 486 6 300 486 minecraft:bookshelf
setblock 6 286 487 minecraft:ochre_froglight
fill 6 286 488 6 300 488 minecraft:bookshelf
setblock 6 286 489 minecraft:ochre_froglight
fill 6 286 490 6 300 490 minecraft:bookshelf
setblock 6 286 491 minecraft:ochre_froglight
fill 6 286 492 6 300 492 minecraft:bookshelf
setblock 6 286 493 minecraft:ochre_froglight
fill 6 286 494 6 300 494 minecraft:bookshelf
setblock 6 286 495 minecraft:ochre_froglight
fill 6 286 496 6 300 496 minecraft:bookshelf
setblock 7 286 464 minecraft:ochre_froglight
fill 7 286 465 7 300 465 minecraft:bookshelf
setblock 7 286 466 minecraft:ochre_froglight
fill 7 286 467 7 300 467 minecraft:bookshelf
setblock 7 286 468 minecraft:ochre_froglight
fill 7 286 469 7 300 469 minecraft:bookshelf
setblock 7 286 470 minecraft:ochre_froglight
fill 7 286 471 7 300 471 minecraft:bookshelf
setblock 7 286 472 minecraft:ochre_froglight
setblock 7 286 486 minecraft:ochre_froglight
fill 7 286 487 7 300 487 minecraft:bookshelf
setblock 7 286 488 minecraft:ochre_froglight
fill 7 286 489 7 300 489 minecraft:bookshelf
setblock 7 286 490 minecraft:ochre_froglight
fill 7 286 491 7 300 491 minecraft:bookshelf
setblock 7 286 492 minecraft:ochre_froglight
fill 7 286 493 7 300 493 minecraft:bookshelf
setblock 7 286 494 minecraft:ochre_froglight
fill 7 286 495 7 300 495 minecraft:bookshelf
setblock 7 286 496 minecraft:ochre_froglight
setblock 7 286 504 minecraft:bookshelf
fill 8 286 464 8 300 464 minecraft:bookshelf
setblock 8 286 465 minecraft:ochre_froglight
fill 8 286 466 8 300 466 minecraft:bookshelf
setblock 8 286 467 minecraft:ochre_froglight
fill 8 286 468 8 300 468 minecraft:bookshelf
setblock 8 286 469 minecraft:ochre_froglight
fill 8 286 470 8 300 470 minecraft:bookshelf
setblock 8 286 471 minecraft:ochre_froglight
fill 8 286 472 8 300 472 minecraft:bookshelf
fill 8 286 486 8 300 486 minecraft:bookshelf
setblock 8 286 487 minecraft:ochre_froglight
fill 8 286 488 8 300 488 minecraft:bookshelf
setblock 8 286 489 minecraft:ochre_froglight
fill 8 286 490 8 300 490 minecraft:bookshelf
setblock 8 286 491 minecraft:ochre_froglight
fill 8 286 492 8 300 492 minecraft:bookshelf
setblock 8 286 493 minecraft:ochre_froglight
fill 8 286 494 8 300 494 minecraft:bookshelf
setblock 9 286 464 minecraft:ochre_froglight
fill 9 286 465 9 300 465 minecraft:bookshelf
setblock 9 286 466 minecraft:ochre_froglight
fill 9 286 467 9 300 467 minecraft:bookshelf
setblock 9 286 468 minecraft:ochre_froglight
fill 9 286 469 9 300 469 minecraft:bookshelf
setblock 9 286 470 minecraft:ochre_froglight
fill 9 286 471 9 300 471 minecraft:bookshelf
setblock 9 286 472 minecraft:ochre_froglight
fill 10 286 464 10 300 464 minecraft:bookshelf
setblock 10 286 465 minecraft:ochre_froglight
fill 10 286 466 10 300 466 minecraft:bookshelf
setblock 10 286 467 minecraft:ochre_froglight
fill 10 286 468 10 300 468 minecraft:bookshelf
setblock 10 286 469 minecraft:ochre_froglight
fill 10 286 470 10 300 470 minecraft:bookshelf
setblock 10 286 471 minecraft:ochre_froglight
fill 10 286 472 10 300 472 minecraft:bookshelf
setblock 11 286 464 minecraft:ochre_froglight
fill 11 286 465 11 300 465 minecraft:bookshelf
setblock 11 286 466 minecraft:ochre_froglight
fill 11 286 467 11 300 467 minecraft:bookshelf
setblock 11 286 468 minecraft:ochre_froglight
fill 11 286 469 11 300 469 minecraft:bookshelf
setblock 11 286 470 minecraft:ochre_froglight
fill 11 286 471 11 300 471 minecraft:bookshelf
setblock 11 286 472 minecraft:ochre_froglight
fill 12 286 464 12 300 464 minecraft:bookshelf
setblock 12 286 465 minecraft:ochre_froglight
fill 12 286 466 12 300 466 minecraft:bookshelf
setblock 12 286 467 minecraft:ochre_froglight
fill 12 286 468 12 300 468 minecraft:bookshelf
setblock 12 286 469 minecraft:ochre_froglight
fill 12 286 470 12 300 470 minecraft:bookshelf
setblock 12 286 471 minecraft:ochre_froglight
fill 12 286 472 12 300 472 minecraft:bookshelf
setblock 13 286 464 minecraft:ochre_froglight
fill 13 286 465 13 300 465 minecraft:bookshelf
setblock 13 286 466 minecraft:ochre_froglight
fill 13 286 467 13 300 467 minecraft:bookshelf
fill 14 286 464 14 300 464 minecraft:bookshelf
setblock 14 286 465 minecraft:ochre_froglight
fill 14 286 466 14 300 466 minecraft:bookshelf
setblock 14 286 467 minecraft:ochre_froglight
fill 14 286 496 14 300 496 minecraft:bookshelf
setblock 14 286 497 minecraft:ochre_froglight
fill 14 286 498 14 300 498 minecraft:bookshelf
setblock 14 286 499 minecraft:ochre_froglight
fill 14 286 500 14 300 500 minecraft:bookshelf
setblock 14 286 501 minecraft:ochre_froglight
fill 14 286 502 14 300 502 minecraft:bookshelf
setblock 14 286 503 minecraft:ochre_froglight
fill 14 286 504 14 300 504 minecraft:bookshelf
setblock 15 286 464 minecraft:ochre_froglight
fill 15 286 465 15 300 465 minecraft:bookshelf
setblock 15 286 466 minecraft:ochre_froglight
fill 15 286 467 15 300 467 minecraft:bookshelf
setblock 15 286 496 minecraft:ochre_froglight
fill 15 286 497 15 300 497 minecraft:bookshelf
setblock 15 286 498 minecraft:ochre_froglight
fill 15 286 499 15 300 499 minecraft:bookshelf
setblock 15 286 500 minecraft:ochre_froglight
fill 15 286 501 15 300 501 minecraft:bookshelf
setblock 15 286 502 minecraft:ochre_froglight
fill 15 286 503 15 300 503 minecraft:bookshelf
setblock 15 286 504 minecraft:ochre_froglight
fill 16 286 464 16 300 464 minecraft:bookshelf
setblock 16 286 465 minecraft:ochre_froglight
fill 16 286 466 16 300 466 minecraft:bookshelf
setblock 16 286 467 minecraft:ochre_froglight
fill 16 286 496 16 300 496 minecraft:bookshelf
setblock 16 286 497 minecraft:ochre_froglight
fill 16 286 498 16 300 498 minecraft:bookshelf
setblock 16 286 499 minecraft:ochre_froglight
fill 16 286 500 16 300 500 minecraft:bookshelf
setblock 16 286 501 minecraft:ochre_froglight
fill 16 286 502 16 300 502 minecraft:bookshelf
setblock 16 286 503 minecraft:ochre_froglight
fill 16 286 504 16 300 504 minecraft:bookshelf
setblock 17 286 464 minecraft:ochre_froglight
fill 17 286 465 17 300 465 minecraft:bookshelf
setblock 17 286 466 minecraft:ochre_froglight
fill 17 286 467 17 300 467 minecraft:bookshelf
setblock 17 286 496 minecraft:ochre_froglight
fill 17 286 497 17 300 497 minecraft:bookshelf
setblock 17 286 498 minecraft:ochre_froglight
fill 17 286 499 17 300 499 minecraft:bookshelf
setblock 17 286 500 minecraft:ochre_froglight
fill 17 286 501 17 300 501 minecraft:bookshelf
setblock 17 286 502 minecraft:ochre_froglight
fill 17 286 503 17 300 503 minecraft:bookshelf
setblock 17 286 504 minecraft:ochre_froglight
fill 18 286 464 18 300 464 minecraft:bookshelf
setblock 18 286 465 minecraft:ochre_froglight
fill 18 286 466 18 300 466 minecraft:bookshelf
setblock 18 286 467 minecraft:ochre_froglight
fill 18 286 496 18 300 496 minecraft:bookshelf
setblock 18 286 497 minecraft:ochre_froglight
fill 18 286 498 18 300 498 minecraft:bookshelf
setblock 18 286 499 minecraft:ochre_froglight
fill 18 286 500 18 300 500 minecraft:bookshelf
setblock 18 286 501 minecraft:ochre_froglight
fill 18 286 502 18 300 502 minecraft:bookshelf
setblock 18 286 503 minecraft:ochre_froglight
fill 18 286 504 18 300 504 minecraft:bookshelf
setblock 19 286 464 minecraft:ochre_froglight
fill 19 286 465 19 300 465 minecraft:bookshelf
setblock 19 286 466 minecraft:ochre_froglight
fill 19 286 467 19 300 467 minecraft:bookshelf
setblock 19 286 496 minecraft:ochre_froglight
fill 19 286 497 19 300 497 minecraft:bookshelf
setblock 19 286 498 minecraft:ochre_froglight
fill 19 286 499 19 300 499 minecraft:bookshelf
setblock 19 286 500 minecraft:ochre_froglight
fill 19 286 501 19 300 501 minecraft:bookshelf
setblock 19 286 502 minecraft:ochre_froglight
fill 19 286 503 19 300 503 minecraft:bookshelf
setblock 19 286 504 minecraft:ochre_froglight
fill 20 286 464 20 300 464 minecraft:bookshelf
setblock 20 286 465 minecraft:ochre_froglight
fill 20 286 466 20 300 466 minecraft:bookshelf
setblock 20 286 467 minecraft:ochre_froglight
setblock 20 286 495 minecraft:ochre_froglight
fill 20 286 496 20 300 496 minecraft:bookshelf
setblock 20 286 497 minecraft:ochre_froglight
fill 20 286 498 20 300 498 minecraft:bookshelf
setblock 20 286 499 minecraft:ochre_froglight
fill 20 286 500 20 300 500 minecraft:bookshelf
setblock 20 286 501 minecraft:ochre_froglight
fill 20 286 502 20 300 502 minecraft:bookshelf
setblock 20 286 503 minecraft:ochre_froglight
fill 20 286 504 20 300 504 minecraft:bookshelf
fill 21 286 495 21 300 495 minecraft:bookshelf
setblock 21 286 496 minecraft:ochre_froglight
fill 21 286 497 21 300 497 minecraft:bookshelf
setblock 21 286 498 minecraft:ochre_froglight
fill 21 286 499 21 300 499 minecraft:bookshelf
setblock 21 286 500 minecraft:ochre_froglight
fill 21 286 501 21 300 501 minecraft:bookshelf
setblock 21 286 502 minecraft:ochre_froglight
fill 21 286 503 21 300 503 minecraft:bookshelf
setblock 21 286 504 minecraft:ochre_froglight
setblock 22 286 495 minecraft:ochre_froglight
fill 22 286 496 22 300 496 minecraft:bookshelf
setblock 22 286 497 minecraft:ochre_froglight
fill 22 286 498 22 300 498 minecraft:bookshelf
setblock 22 286 499 minecraft:ochre_froglight
fill 22 286 500 22 300 500 minecraft:bookshelf
setblock 22 286 501 minecraft:ochre_froglight
fill 22 286 502 22 300 502 minecraft:bookshelf
setblock 22 286 503 minecraft:ochre_froglight
fill 22 286 504 22 300 504 minecraft:bookshelf
fill 23 286 495 23 300 495 minecraft:bookshelf
setblock 23 286 496 minecraft:ochre_froglight
fill 23 286 497 23 300 497 minecraft:bookshelf
setblock 23 286 498 minecraft:ochre_froglight
fill 23 286 499 23 300 499 minecraft:bookshelf
setblock 23 286 500 minecraft:ochre_froglight
fill 23 286 501 23 300 501 minecraft:bookshelf
setblock 23 286 502 minecraft:ochre_froglight
fill 23 286 503 23 300 503 minecraft:bookshelf
setblock 23 286 504 minecraft:ochre_froglight
setblock 24 286 495 minecraft:ochre_froglight
fill 24 286 496 24 300 496 minecraft:bookshelf
setblock 24 286 497 minecraft:ochre_froglight
fill 24 286 498 24 300 498 minecraft:bookshelf
setblock 24 286 499 minecraft:ochre_froglight
fill 24 286 500 24 300 500 minecraft:bookshelf
setblock 24 286 501 minecraft:ochre_froglight
fill 24 286 502 24 300 502 minecraft:bookshelf
setblock 24 286 503 minecraft:ochre_froglight
fill 24 286 504 24 300 504 minecraft:bookshelf
setblock 25 286 464 minecraft:bookshelf
fill 25 286 495 25 300 495 minecraft:bookshelf
setblock 25 286 496 minecraft:ochre_froglight
fill 25 286 497 25 300 497 minecraft:bookshelf
setblock 25 286 498 minecraft:ochre_froglight
fill 25 286 499 25 300 499 minecraft:bookshelf
setblock 25 286 500 minecraft:ochre_froglight
fill 25 286 501 25 300 501 minecraft:bookshelf
setblock 25 286 502 minecraft:ochre_froglight
fill 25 286 503 25 300 503 minecraft:bookshelf
setblock 25 286 504 minecraft:ochre_froglight
setblock 26 286 495 minecraft:ochre_froglight
fill 26 286 496 26 300 496 minecraft:bookshelf
setblock 26 286 497 minecraft:ochre_froglight
fill 26 286 498 26 300 498 minecraft:bookshelf
setblock 26 286 499 minecraft:ochre_froglight
fill 26 286 500 26 300 500 minecraft:bookshelf
setblock 26 286 501 minecraft:ochre_froglight
fill 26 286 502 26 300 502 minecraft:bookshelf
setblock 26 286 503 minecraft:ochre_froglight
fill 26 286 504 26 300 504 minecraft:bookshelf
setblock 28 286 504 minecraft:bookshelf
setblock 32 286 464 minecraft:bookshelf
setblock 33 286 474 minecraft:ochre_froglight
fill 33 286 475 33 300 475 minecraft:bookshelf
setblock 33 286 476 minecraft:ochre_froglight
fill 33 286 477 33 300 477 minecraft:bookshelf
setblock 33 286 478 minecraft:ochre_froglight
fill 33 286 479 33 300 479 minecraft:bookshelf
setblock 33 286 480 minecraft:ochre_froglight
fill 33 286 481 33 300 481 minecraft:bookshelf
setblock 33 286 482 minecraft:ochre_froglight
fill 34 286 474 34 300 474 minecraft:bookshelf
setblock 34 286 475 minecraft:ochre_froglight
fill 34 286 476 34 300 476 minecraft:bookshelf
setblock 34 286 477 minecraft:ochre_froglight
fill 34 286 478 34 300 478 minecraft:bookshelf
setblock 34 286 479 minecraft:ochre_froglight
fill 34 286 480 34 300 480 minecraft:bookshelf
setblock 34 286 481 minecraft:ochre_froglight
fill 34 286 482 34 300 482 minecraft:bookshelf
setblock 35 286 474 minecraft:ochre_froglight
fill 35 286 475 35 300 475 minecraft:bookshelf
setblock 35 286 476 minecraft:ochre_froglight
fill 35 286 477 35 300 477 minecraft:bookshelf
setblock 35 286 478 minecraft:ochre_froglight
fill 35 286 479 35 300 479 minecraft:bookshelf
setblock 35 286 480 minecraft:ochre_froglight
fill 35 286 481 35 300 481 minecraft:bookshelf
setblock 35 286 482 minecraft:ochre_froglight
setblock 35 286 504 minecraft:bookshelf
fill 36 286 474 36 300 474 minecraft:bookshelf
setblock 36 286 475 minecraft:ochre_froglight
fill 36 286 476 36 300 476 minecraft:bookshelf
setblock 36 286 477 minecraft:ochre_froglight
fill 36 286 478 36 300 478 minecraft:bookshelf
setblock 36 286 479 minecraft:ochre_froglight
fill 36 286 480 36 300 480 minecraft:bookshelf
setblock 36 286 481 minecraft:ochre_froglight
fill 36 286 482 36 300 482 minecraft:bookshelf
setblock 37 286 474 minecraft:ochre_froglight
fill 37 286 475 37 300 475 minecraft:bookshelf
setblock 37 286 476 minecraft:ochre_froglight
fill 37 286 477 37 300 477 minecraft:bookshelf
setblock 37 286 478 minecraft:ochre_froglight
fill 37 286 479 37 300 479 minecraft:bookshelf
setblock 37 286 480 minecraft:ochre_froglight
fill 37 286 481 37 300 481 minecraft:bookshelf
setblock 37 286 482 minecraft:ochre_froglight
fill 38 286 474 38 300 474 minecraft:bookshelf
setblock 38 286 475 minecraft:ochre_froglight
fill 38 286 476 38 300 476 minecraft:bookshelf
setblock 38 286 477 minecraft:ochre_froglight
fill 38 286 478 38 300 478 minecraft:bookshelf
setblock 38 286 479 minecraft:ochre_froglight
fill 38 286 480 38 300 480 minecraft:bookshelf
setblock 38 286 481 minecraft:ochre_froglight
fill 38 286 482 38 300 482 minecraft:bookshelf
setblock 39 286 464 minecraft:bookshelf
setblock 39 286 474 minecraft:ochre_froglight
fill 39 286 475 39 300 475 minecraft:bookshelf
setblock 39 286 476 minecraft:ochre_froglight
fill 39 286 477 39 300 477 minecraft:bookshelf
setblock 39 286 478 minecraft:ochre_froglight
fill 39 286 479 39 300 479 minecraft:bookshelf
setblock 39 286 480 minecraft:ochre_froglight
fill 39 286 481 39 300 481 minecraft:bookshelf
setblock 39 286 482 minecraft:ochre_froglight
fill 39 286 487 40 286 491 minecraft:bookshelf
fill 40 286 474 40 300 474 minecraft:bookshelf
setblock 40 286 475 minecraft:ochre_froglight
fill 40 286 476 40 300 476 minecraft:bookshelf
setblock 40 286 477 minecraft:ochre_froglight
fill 40 286 478 40 300 478 minecraft:bookshelf
setblock 40 286 479 minecraft:ochre_froglight
fill 40 286 480 40 300 480 minecraft:bookshelf
setblock 40 286 481 minecraft:ochre_froglight
fill 40 286 482 40 300 482 minecraft:bookshelf
setblock 41 286 469 minecraft:bookshelf
setblock 41 286 474 minecraft:ochre_froglight
fill 41 286 475 41 300 475 minecraft:bookshelf
setblock 41 286 476 minecraft:ochre_froglight
fill 41 286 477 41 300 477 minecraft:bookshelf
setblock 41 286 478 minecraft:ochre_froglight
fill 41 286 479 41 300 479 minecraft:bookshelf
setblock 41 286 480 minecraft:ochre_froglight
fill 41 286 481 41 300 481 minecraft:bookshelf
setblock 41 286 482 minecraft:ochre_froglight
setblock 41 286 483 minecraft:bookshelf
fill 41 286 487 41 286 488 minecraft:bookshelf
setblock 41 286 490 minecraft:bookshelf
fill 41 286 492 41 287 492 minecraft:bookshelf
setblock 41 286 497 minecraft:bookshelf
fill 1 287 469 2 288 469 minecraft:bookshelf
fill 1 287 486 1 288 486 minecraft:bookshelf
fill 1 287 488 1 288 488 minecraft:bookshelf
fill 1 287 490 1 288 490 minecraft:bookshelf
schedule function dropper:buildpart/108_4 1t
